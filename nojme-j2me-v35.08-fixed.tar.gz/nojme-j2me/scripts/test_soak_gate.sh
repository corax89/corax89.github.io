#!/bin/bash
# v35.08: (a) 3-session soak, (b) logging gate: OFF => no log.txt, no [TRACE];
# ON => log.txt appears with the diag lines.
set -e
cd "$(dirname "$0")/.." || exit 1
BIN=./bin/switchui-verify
ok=1

echo "== (a) 3-session soak =="
D=/tmp/sw_3s
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/monleak/MonLeakTest.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy NOJME_LOG=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
# jar sits in the browser ROOT: each session eats exactly 2 A's (Open, select).
# Trailing B's (15 s apart) guarantee an exit lands at a menu after the last
# self-ended session; B's landing mid-game are harmless game-key events.
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,A:400,A:400,A:400,B:15000,B:15000,B:15000,B:15000,B:15000,B:15000,B:15000,B:15000"
timeout 170 "$BIN" > "$D/out.log" 2> "$D/err.log"; rc=$?
if [ $rc -ne 0 ] && [ $rc -ne 124 ]; then echo "FAIL: run rc=$rc"; ok=0; fi
n=$(grep -c "MONLEAK:DONE.*PASSED" "$D/err.log" || true)
[ "$n" -ge 3 ] || { echo "FAIL: full runs = $n (want 3)"; ok=0; }
f=$(grep -c "FATAL\|OPCODE FAIL\|SIGSEGV" "$D/err.log" || true)
[ "$f" -eq 0 ] || { echo "FAIL: $f VM errors/crashes"; ok=0; }
grep -q "menu exit" "$D/err.log" || { echo "FAIL: no clean menu exit"; ok=0; }
echo "soak: $n full runs, $f errors, exit rc=$rc"

echo "== (b1) logging OFF => silence =="
D=/tmp/sw_gateoff
rm -rf "$D"; mkdir -p "$D/roms"; cp scripts/testdosw/TestDosWrite.jar "$D/roms/"
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,A:400,B:6000"
export NOJME_LOGGING=0
timeout 60 "$BIN" > "$D/out.log" 2> "$D/err.log" || echo "(gateoff run rc=$?)"
[ -f "$D/log.txt" ] && { echo "FAIL: log.txt created with logging OFF"; ok=0; }
t=$(grep -c "\[TRACE\]" "$D/err.log" || true)
[ "$t" -eq 0 ] || { echo "FAIL: $t [TRACE] lines with logging OFF"; ok=0; }
echo "gateoff: log.txt $([ -f "$D/log.txt" ] && echo EXISTS || echo absent), $t trace lines"

echo "== (b2) logging ON => log.txt with diag =="
D=/tmp/sw_gateon
rm -rf "$D"; mkdir -p "$D/roms"; cp scripts/testdosw/TestDosWrite.jar "$D/roms/"
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_LOGGING=1
timeout 60 "$BIN" > "$D/out.log" 2> "$D/err.log" || echo "(gateon run rc=$?)"
[ -f "$D/log.txt" ] || { echo "FAIL: no log.txt with logging ON"; ok=0; }
grep -q "trace start" "$D/log.txt" || { echo "FAIL: no banner in log.txt"; ok=0; }
echo "gateon: log.txt $(wc -c < "$D/log.txt" 2>/dev/null || echo 0) bytes"

unset NOJME_LOGGING
[ $ok -eq 1 ] && echo "v35.08 SOAK+GATE: ALL CHECKS PASSED" || echo "v35.08 SOAK+GATE: FAILED"
exit $((1 - ok))
