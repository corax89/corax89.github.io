noJME v36.102-tickfix1 (2026-10-09)
===================================

ЗАДАЧА ПОЛЯ
-----------
«Первый же запуск мидлета привёл к вылету, возможно именно поэтому
invokeinterface был единственным invoke без inline-кэша, вот дамп,
эльф и бинарник» (Zombie Infection, Nintendo Switch; Atmosphere
crash report + nojme.nro + nojme_switch.elf из bin.zip).

ДИАГНОЗ ПО КРАШ-ДАМПУ (разобран до инструкции)
----------------------------------------------
* Atmosphere Crash Report v1.7: Result 0x4A8 (2168-0002), Data Abort
  @0x0, crashed thread tid=8ee. PC = nojme_switch+0x47140,
  LR = +0x46658, стек: interpret -> execute_method -> op_invokestatic.
* Смещения NRO = vaddr ELF проверены ДВУМЯ байтовыми паттернами
  (сдвиг 0) — символизация достоверна. На PC +0x47140 стоит:
      mrs x5, cntvct_el0          <<< FAULT
  с последующим blr x21 (вызов натива) и парным mrs x0, cntvct_el0 +
  64-битной дельтой и атомиками — это [GFXP-TICK] из v36.101:
  пара тайминга ALWAYS-ON телеметрии GFX-PERF вокруг КАЖДОГО натива.
* Регистры подтверждают СЦЕНУ: X21 = nojme_switch+0x5e320 =
  native_display_getDisplay (самый первый натив любого мидлета —
  Display.getDisplay(this) из startApp); в X16/X17 — обрезки strcmp
  "...edition/lcdui/Di" (резолв класса javax.microedition.lcdui.Display
  прямо перед вызовом). Перед blr стоит TLS-гейт вложенности
  (счётчик==0 -> таймированный путь) — рухнул ПЕРВЫЙ ЖЕ обёрнутый
  вызов ПЕРВОГО запуска мидлета. Всё сходится с репортом «первый же
  запуск — вылет».
* Сканирование всего бинарника: ровно 68 чтений CNTVCT_EL0 — все 68
  из моих обёрток (op_invokestatic/special/virtual/interface +
  gfxp_wrap_*), и НОЛЬ чтений CNTPCT_EL0 (кодовая база до v36.101
  системные счётчики не читала вообще).
* КОРЕНЬ: v36.101 [GFXP-TICK] читал ВИРТУАЛЬНЫЙ счётчик CNTVCT_EL0.
  На Horizon с EL0 доступен только ФИЗИЧЕСКИЙ CNTPCT_EL0 — ровно его
  читает libnx armGetSystemTick() (nx/include/switch/arm/counter.h,
  проверено по master switchbrew/libnx). Доступ к CNTVCT гейтится
  CNTKCTL_EL1.EL0VCTEN (=0 на Horizon) -> синхронный трап на первом
  же чтении -> фатал 2168-0002. На x86-хостах (где гонялись ВСЕ
  тесты v36.101) ветка __aarch64__ вообще не компилировалась —
  clock_gettime-путь, поэтому «0 предупреждений» дефект не поймал.
  Утверждение в моём же README v36.101 «те же регистры, что libnx
  armGetSystemTick» было ФАКТИЧЕСКИ НЕВЕРНЫМ — libnx читает CNTPCT.
* Гипотеза поля «invokeinterface был без IC, потому что IC его роняет»
  опровергнута конкретикой дампа: трап в ТАЙМЕРЕ обёртки, он равно
  бьёт по всем 6 обёрнутым сайтам диспетчера (static/interface/
  virtual/special + графические API) и не связан с логикой IC.
  IFACE-IC (как и ARG-LAYOUT/FRAME-DEPTH/FAST-RETURN) до краша
  просто НЕ УСПЕЛ выполниться ни разу — вылет был до первого
  интерфейсного вызова.

ФИКС v36.102 [GFXP-TICK-FIX]
----------------------------
include/gfxperf.h — выбор счётчика по ПЛАТФОРМЕ (одна правка лечит
все 68 сайтов сразу):
* __SWITCH__ (обе Switch-сборки NRO/libretro передают -D__SWITCH__ из
  Makefile) -> mrs cntpct_el0 — байт-в-байт то, что эмитит libnx
  armGetSystemTick();
* прочий aarch64-юзспейс (Linux/BSD, libretro-хосты) -> mrs cntvct_el0
  как было: там ядро наоборот открывает виртуальный счётчик (Linux
  vDSO читает CNTVCT_EL0), т.е. прежний выбор для Linux был ВЕРЕН —
  дефект был только в Horizon-ветке, которую свели с libnx;
* CNTFRQ_EL0 не тронут: это тот же регистр, что libnx
  armGetSystemTickFreq(), EL0-доступа не гейтится; кэш частоты и
  фолбэк 19.2 МГц (частота Horizon) — как в v36.101;
* switchui-verify (host x86 + -D__SWITCH__) не затронут: внешний гейт
  __aarch64__ ложен -> прежний clock_gettime-путь.

ПРОЦЕССНЫЙ ФИКС (чтобы класс бага не повторился)
------------------------------------------------
* Любая asm-вставка теперь обязана проходить aarch64 КРОСС-КОМПИЛЯЦИЮ:
  в это окружение установлен gcc-aarch64-linux-gnu 14.2 (deb,
  ys/aarch64-cross), собран верификатор scripts/gfxp_cross_test.c —
  компилируется ДВАЖДЫ (generic + -D__SWITCH__), objdump сверяет
  кодировки mrs: generic -> d53be04x (cntvct) + d53be00x (cntfrq),
  __SWITCH__ -> d53be02x (cntpct) + d53be00x. Кодировка упавшей
  инструкции в полевом бинарнике (d53be045 = mrs x5, cntvct_el0)
  совпадает с generic-путём — фикс подтверждён на уровне байтов.
* Урок: «компилируется без предупреждений на хосте» != «работает на
  платформе». Для платформо-зависимых вещей — сверка с эталонной
  реализацией libnx (сделана: counter.h) + кросс-компиляция обоих
  путей.

КОРРЕКТНОСТЬ (полная батарея v36.101 перегнана на v36.102)
----------------------------------------------------------
* fenceslow: 2 прохода (дефолт + NOJME_SPIN_BREAK_PAINT=0) — ALL
  CHECKS PASSED; fencewait — PASSED; spinbreak — CAUGHT @12001,
  PASSED; spinpause — 31950 кадров, 0 SPIN-BREAK, PASSED; spingate x3
  — PASSED; fencedeadlock — PASSED (GAME-DONE, rc=0).
* keybudget — 17 доставок, GAME-DONE, rc=0, 0 MON-WAIT-2с, 0
  KEY-BUDGET; imsloop — STEAL-GATE suppressed / B-ACQUIRED / RECOVERED
  catches=0 / PHASE2 / JOIN-CAP / DESTROYED; stealgate — A-SUPPRESSED
  25020 / B-STEAL 20025 / B-REACQUIRED / B-OWNER-EXIT-CLEAN /
  PHASES-DONE / DESTROYED; pssleep on/off — PASSED.
* Бит-в-бит против золотого v36.100: RetBench 4/4 (SUM-L
  5597742076056351744, SUM-D 3.999979998000101, SUM-F NaN, SUM-M
  -3739709241755009701); IfaceBench fix=1529307776 (IC-ON = IC-OFF).
  IfaceBench A/B: +12.4% (5.73M против 5.10M вызовов/с — как +13.9%
  в v36.101, в шуме измерения).
* TestVector 9 PASS, TestConcat 8 PASS, NEON-TEST 28 PASS / 0 FAIL,
  make check 33 OK.
* Сборки switchui-verify / j2me-headless / nojme_libretro.so — 0
  предупреждений; версия v36.102-tickfix1-2026-10-09 в бинарниках.
* aarch64 кросс-компиляция gfxperf (обе ветки) — OK, кодировки
  сверены (см. выше).

ЧТО ОЖИДАТЬ В ПОЛЕ
------------------
* Вылет на первом запуске исчезает: единственная инструкция, на которой
  падал процесс, заменена на libnx-эквивалент.
* Впервые полем будут реально исполнены оптимизации v36.101
  (IFACE-IC/ARG-LAYOUT/FRAME-DEPTH/FAST-RETURN) — до краша ни одна не
  успевала выполниться. Прогноз +20-40% FPS на тяжёлом уровне Zombie
  (3.6-5.8 -> ~4.5-8) в силе; прямой контроль: ivk=/ifc= в [VM-PERF]
  (ifc -> 0 после разогрева; ivk/vi ~ 1/10-1/15), плюс [GFX-PERF] nat=
  теперь честно меряется регистровым тиком (~2x10 нс, без SVC).
* Если (внезапно) появится визуальная/временная аномалия телеметрии —
  это диагностический, а не игровой путь; рубильники v36.100/101 в
  силе (env.txt на Switch).

СБОРКА
------
* Ядро: CORE_BUILD_ID=v36.102-tickfix1-2026-10-09 (признак в логе:
  «build=v36.102-tickfix1-2026-10-09»).
* NRO: make switchui (devkitPro, как обычно; правка — только заголовок
  include/gfxperf.h, пересборка полная по привычной схеме).
* Патч: v36.102-tickfix1.patch — на чистую v36.101 (patch -p1).
