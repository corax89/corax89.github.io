#!/bin/bash
# [YS-ASAN-LOOP] (yetifix5) Расширенный ASan-джорней — проверка ПОСЛЕ v36.47:
# пользователь всё ещё видит в Ryujinx "Invalid memory access at
# 0x20697465592F7365" (00:00:54.66x, 3x) на ИСПРАВЛЕННОЙ по докам сборке.
# Гипотеза: старый джорней (ys_asan_journey.sh) стоял в меню лишь ~20 c и
# не накрывал лупы менюшной музыки (END_OF_MEDIA из микшерного потока,
# рестарты трека, повторные started/stopped). Этот скрипт:
#   ФАЗА 1 — создание девайс-RMS (opt 144 б): язык English через -6;
#   ФАЗА 2 — диалог X(On) -> сплэш '5' -> 100 СЕКУНД в меню с музыкой
#            (счётчик sb в diag должен расти; если трек конечен —
#            END_OF_MEDIA и рестарты), пауза -> «Выйти» -> teardown;
#   ФАЗА 3 — ПОВТОРНЫЙ запуск (девайс-сценарий «белого экрана»), 60 c
#            в меню, выход. ASan ловит порчу в ЛЮБОЙ точке.
# Чистый результат = источник лога пользователя СТАРАЯ сборка NRO.
set -u
cd "$(dirname "$0")/.." || exit 1

UI=/tmp/ysinit_ui12345        # 16 (устройство 17 — добьём слэшем-префиксом нет: оставляем как есть, длина важна лишь для воспроизведения байтов пути, см. [PLAYERUPDATE-ARGS])
GAMES=/tmp/ysinit_games1234   # 21
SAVES=/tmp/ysinit_saves1234   # 21
YS="${YS_JAR:-/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar}"
[ -f "$YS" ] || { echo "FAIL: нет JAR: $YS"; exit 1; }

rm -rf "$UI" "$GAMES" "$SAVES"
mkdir -p "$UI" "$GAMES" "$SAVES"
cp "$YS" "$GAMES/Yeti Sports (00.02.51)[240x320].jar"

mk_ini() {  # $1 = audio
cat > "$UI/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=linear
audio=$1
vm_speed=normal
logging=on
battery=off
keyhint=off
saves_dir=$SAVES
EOF
}

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_MEDIA_DEBUG=1
export NOJME_SWITCH_BROWSE_ROOT="$GAMES"
export NOJME_SWITCH_UI_DIR="$UI"
export XDG_DATA_HOME="$UI/xdg"
export ASAN_OPTIONS=detect_leaks=0:abort_on_error=0:halt_on_error=1

BIN=./bin-init/switchui-verify
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (bin-init build)"; exit 1; }

echo "=== ФАЗА 1: создание RMS-состояния (язык English, opt 144 б) ==="
mk_ini off
unset NOJME_GAME_KEYS NOJME_FRONT_KEYS NOJME_COMPOSITE_DUMP_DIR 2>/dev/null || true
export NOJME_SWITCH_KEYS="A:1200,A:500,X:16000,EXIT:42000"
timeout -k 5 50 $BIN > /tmp/ysinit_p1_out.log 2> /tmp/ysinit_p1_err.log
echo "rc=$? (сессия создания состояния)"
ls "$SAVES"/*/ 2>/dev/null || { echo "SAVES EMPTY — фаза 1 не удалась"; exit 1; }
echo "RMS: $(ls "$SAVES"/*/ 2>/dev/null | tr '\n' ' ')"

echo
echo "=== ФАЗА 2: диалог X -> сплэш '5' -> 100 c в меню (музыка) -> выход ==="
mk_ini on
export NOJME_SWITCH_KEYS="A:1200,A:500"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
# t≈2с старт игры; диалог 2..13с; -6(X)=On в 6с; сплэш ~6.4..16с; '5' в 10с;
# меню+музыка с ~11с; сидим до 111с; PLUS=пауза 112с; DOWN,DOWN,A=«Выйти» 115с
export NOJME_GAME_KEYS="W:12000,-6:400,W:5000,53:300,W:100000"
export NOJME_FRONT_KEYS="PLUS:120000,DOWN:121000,DOWN:122000,DOWN:122500,A:123000"
timeout -k 5 136 $BIN > /tmp/ysinit_p2_out.log 2> /tmp/ysinit_p2_err.log
P2RC=$?
echo "rc=$P2RC"
grep -aE "ERROR: AddressSanitizer|SUMMARY: AddressSanitizer" /tmp/ysinit_p2_err.log | head -10 || echo "ASan: ошибок нет"
echo "--- медиа-события (log.txt) ---"
grep -aE "\[MEDIA\]" "$UI/log.txt" 2>/dev/null | head -30
echo "--- diag-хвост (sb = звук, должен расти) ---"
grep -a "diag:" "$UI/log.txt" 2>/dev/null | tail -4
echo "--- teardown/exit ---"
grep -aE "menu: |teardown|exit|game: " "$UI/log.txt" 2>/dev/null | tail -12

echo
echo "=== ФАЗА 3: повторный запуск (девайс-сценарий белого экрана) ==="
export NOJME_GAME_KEYS="W:12000,-6:400,W:5000,53:300,W:60000"
export NOJME_FRONT_KEYS="PLUS:80000,DOWN:81000,DOWN:82000,DOWN:82500,A:83000"
timeout -k 5 96 $BIN > /tmp/ysinit_p3_out.log 2> /tmp/ysinit_p3_err.log
P3RC=$?
echo "rc=$P3RC"
grep -aE "ERROR: AddressSanitizer|SUMMARY: AddressSanitizer" /tmp/ysinit_p3_err.log | head -10 || echo "ASan: ошибок нет"
grep -aE "game: |heap" "$UI/log.txt" 2>/dev/null | head -8

echo
echo "=== ИТОГ ==="
P2=$(grep -acE "ERROR: AddressSanitizer" /tmp/ysinit_p2_err.log || true)
P3=$(grep -acE "ERROR: AddressSanitizer" /tmp/ysinit_p3_err.log || true)
echo "ASan-ошибок: фаза2=${P2:-0} фаза3=${P3:-0}"
if [ "${P2:-0}" = "0" ] && [ "${P3:-0}" = "0" ]; then
  echo "VERDICT: дерево ЧИСТО на длинном лупе музыки + повторном запуске — лог пользователя от СТАРОЙ сборки NRO"
else
  echo "VERDICT: НАЙДЕНЫ ошибки ASan — смотреть /tmp/ysinit_p*_err.log"
fi
