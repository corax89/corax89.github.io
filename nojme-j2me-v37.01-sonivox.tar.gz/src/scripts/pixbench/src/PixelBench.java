import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Image;

/* v36.100 [ZGFX3] pixel-effects benchmark: reproduces the per-frame
 * graphics pattern of a heavy Gameloft 240x320 level (Zombie Infection):
 *   tiles   — ~150 opaque drawImage 32x32 (isometric tile floor)
 *   mirror  — ~80 drawRegion TRANS_MIRROR 48x48 (flipped sprites)
 *   alphaov — full-screen drawRGB processAlpha=true (fog/night overlay)
 *   tint    — full-screen getRGB + JAVA pixel loop + drawRGB opaque
 *             (damage-flash / palette-effect idiom)
 *   flash   — full-screen getRGB + JAVA loop + createRGBImage + drawImage
 *             (GLLib dynamic-effect idiom)
 *   rects   — 300 fillRect + 100 drawLine (HUD/bars)
 *   paint   — REAL repaint()+serviceRepaints() loop, paint() runs the
 *             tiles+alphaov workload (end-to-end pump cost)
 * Each phase prints "PX <name> n=<iters> ms=<total> fps=<per-s>".
 * All on the midlet thread (single-threaded, like the game). */
public class PixelBench extends MIDlet {
    int W = 240, H = 320;
    Image back;            /* offscreen buffer (mutable) */
    Image tileOpaque;      /* 32x32 opaque */
    Image sprAlpha;        /* 48x48 RGBA (soft edges) */
    int[] scratch;         /* full-screen RGB scratch */
    Canvas cv;
    int paintOps;
    volatile boolean paintStop;

    /* deterministic LCG — same "random" positions every run */
    int seed = 12345;
    int rnd(int m) { seed = seed * 1103515245 + 12345; int r = (seed >>> 16) & 0x7FFF; return r % m; }

    void mkassets() {
        back = Image.createImage(W, H);
        Graphics bg = back.getGraphics();
        bg.setColor(0x102030);
        bg.fillRect(0, 0, W, H);

        tileOpaque = Image.createImage(32, 32);
        Graphics tg = tileOpaque.getGraphics();
        tg.setColor(0x405060);
        tg.fillRect(0, 0, 32, 32);
        tg.setColor(0x607080);
        tg.fillRect(2, 2, 28, 28);
        tg.setColor(0x8090A0);
        tg.drawLine(0, 0, 31, 31);
        tg.drawLine(31, 0, 0, 31);

        int sw = 48, sh = 48;
        int[] px = new int[sw * sh];
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int dx = x - 24, dy = y - 24;
                int d2 = dx * dx + dy * dy;
                int a = 255 - (d2 * 255) / (24 * 24 + 24 * 24);
                if (a < 0) a = 0;
                px[y * sw + x] = (a << 24) | 0x30E0B0; /* teal glow */
            }
        }
        sprAlpha = Image.createRGBImage(px, sw, sh, true);

        scratch = new int[W * H];
    }

    void phase(String name, int iters, Runnable r) {
        System.gc();
        long t0 = System.currentTimeMillis();
        for (int i = 0; i < iters; i++) r.run();
        long ms = System.currentTimeMillis() - t0;
        double per = ms > 0 ? (double)iters * 1000.0 / (double)ms : 0.0;
        System.out.println("PX " + name + " n=" + iters + " ms=" + ms
                + " per_s=" + (int) per);
    }

    void runBench() {
        mkassets();
        final Graphics g = back.getGraphics();

        phase("tiles", 100, new Runnable() { public void run() {
            for (int i = 0; i < 150; i++)
                g.drawImage(tileOpaque, rnd(W - 32), rnd(H - 32), Graphics.LEFT | Graphics.TOP);
        }});

        phase("mirror", 100, new Runnable() { public void run() {
            for (int i = 0; i < 80; i++)
                g.drawRegion(sprAlpha, 0, 0, 48, 48, 2 /*TRANS_MIRROR*/,
                        rnd(W - 48), rnd(H - 48), Graphics.LEFT | Graphics.TOP);
        }});

        phase("alphaov", 60, new Runnable() { public void run() {
            for (int i = 0; i < W * H; i++) scratch[i] = 0x8C001030;
            g.drawRGB(scratch, 0, W, 0, 0, W, H, true);
        }});

        phase("tint", 60, new Runnable() { public void run() {
            back.getRGB(scratch, 0, W, 0, 0, W, H);
            for (int i = 0; i < W * H; i++) {
                int p = scratch[i];
                int r = (p >> 16) & 0xFF, gr = (p >> 8) & 0xFF, b = p & 0xFF;
                r = (r * 3) >> 2; gr = gr >> 1; b = (b * 3) >> 2;
                scratch[i] = 0xFF000000 | (r << 16) | (gr << 8) | b;
            }
            g.drawRGB(scratch, 0, W, 0, 0, W, H, false);
        }});

        phase("flash", 40, new Runnable() { public void run() {
            back.getRGB(scratch, 0, W, 0, 0, W, H);
            for (int i = 0; i < W * H; i++) {
                int p = scratch[i];
                int r = (p >> 16) & 0xFF, gr = (p >> 8) & 0xFF, b = p & 0xFF;
                int lum = (r * 30 + gr * 59 + b * 11) / 100;
                r = (r + lum) >> 1; gr = (gr + lum) >> 1; b = (b + lum) >> 1;
                scratch[i] = 0xFF000000 | (r << 16) | (gr << 8) | b;
            }
            Image fx = Image.createRGBImage(scratch, W, H, false);
            g.drawImage(fx, 0, 0, Graphics.LEFT | Graphics.TOP);
        }});

        phase("rects", 100, new Runnable() { public void run() {
            for (int i = 0; i < 300; i++) {
                g.setColor(rnd(0xFFFFFF));
                g.fillRect(rnd(W - 8), rnd(H - 8), 8, 8);
            }
            for (int i = 0; i < 100; i++) {
                g.setColor(rnd(0xFFFFFF));
                g.drawLine(rnd(W), rnd(H), rnd(W), rnd(H));
            }
        }});

        /* end-to-end paint pump: repaint()+serviceRepaints() with the
         * tiles+alphaov workload inside paint() */
        paintOps = 0;
        long t0 = System.currentTimeMillis();
        int frames = 0;
        while (System.currentTimeMillis() - t0 < 3000) {
            cv.repaint();
            cv.serviceRepaints();
            frames++;
        }
        long ms = System.currentTimeMillis() - t0;
        System.out.println("PX paint n=" + frames + " ms=" + ms
                + " fps=" + (int)((double)frames * 1000.0 / (double)ms)
                + " paintOps=" + paintOps);
        System.out.println("PX DONE");
    }

    public void startApp() {
        cv = new Canvas() {
            public void paint(Graphics gg) {
                paintOps++;
                for (int i = 0; i < 150; i++)
                    gg.drawImage(tileOpaque, rnd(W - 32), rnd(H - 32), Graphics.LEFT | Graphics.TOP);
                for (int i = 0; i < W * H; i++) scratch[i] = 0x8C001030;
                gg.drawRGB(scratch, 0, W, 0, 0, W, H, true);
                gg.drawImage(back, 0, 0, Graphics.LEFT | Graphics.TOP);
            }
        };
        Display.getDisplay(this).setCurrent(cv);
        runBench();
    }

    public void pauseApp() {}
    public void destroyApp(boolean unc) {}
}
