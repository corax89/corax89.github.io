#!/bin/bash
# v36.100 [ZGFX3]: run PixelBench.jar on switchui-verify (host baseline).
# Usage: test_pixbench.sh [label]
set -u
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/zpixbench
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/pixbench/PixelBench.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:1500,A:1900,EXIT:30000"
timeout -k 5 45 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

echo "== PX lines =="
grep -a "^PX \|PX " "$D/out.log" "$D/err.log" 2>/dev/null | head -20
echo "== diag (last 3) =="
grep -a "diag: loop=" "$D/err.log" | tail -3
echo "== build id =="
grep -a "logging enabled" "$D/err.log" | head -1
