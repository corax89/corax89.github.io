#!/bin/bash
# v36.87 E2E: [PG-CONTROLS] экран «Управление» (новый пункт меню паузы) +
# [STICK-DIAG] диагонали цифрового пути ввода -> ITU-T 1/3/7/9.
#
# ЧТО ПРОВЕРЯЕТСЯ (TestKeys.jar — Canvas, логирующий keyPressed:
# "[JK] pressed <code>"; [KEYIN] dispatch-трейс диспетчера кнопок):
#
#   КЕЙС 1 — ремап кнопки через UI + ЖИВОЕ применение + ПЕРСИСТЕНТНОСТЬ:
#     пауза -> «Управление» (DOWN×2 + A — пункт №2 из четырёх) ->
#     строка «A» (DOWN×2 + A) -> пикер -> «7» (DOWN×8 + A: словарь
#     По умолчанию,0,1,...,9 — «7» = индекс 8) -> B, B (резюм) ->
#     нажатие A в игре -> keyPressed('7' = 55) вместо встроенного '5';
#     [KEYIN] dispatch btn=0 -> key=55; pergame ini содержит btn.A=7.
#     Затем выход в меню (DOWN×3 + A — «Выйти» теперь 4-й пункт!),
#     релаунч (сессия 2) -> нажатие A -> СНОВА '7' — настройки
#     управления живут ПОВЕРХ ПЕРЕЗАПУСКОВ, ПО ОТДЕЛЬНОСТИ НА КАЖДЫЙ JAR.
#
#   КЕЙС 2 — диагонали через UI + зоны крестовины-цифр (swap=on):
#     swap=on в settings.ini (крестовина = путь ЦИФР); пауза ->
#     «Управление» -> строка «Диагонали стика» -> A (BOTH -> DIGITS) ->
#     B, B (резюм) -> UPON (зона UP: '2') -> +LEFTON (диагональ: release
#     '2', press '7') -> UPOFF (release '7', press '4') -> LEFTOFF
#     (release '4'); ini содержит diag=digits; в логе [KEYIN] dispatch
#     zone (зоны вместо поштучных кнопок) и главный лог v36.87
#     "[SWITCH] diagonals: only 1/3/7/9".
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/TestKeys.jar"
[ -f "$JAR" ] || bash scripts/keysjar/build.sh
[ -f "$JAR" ] || { echo "TestKeys.jar build failed"; exit 1; }

run_case() {
    local tag="$1" swap="$2" front="$3" sessions="$4" exit_ms="$5"
    local D=/tmp/sw_ctl_$tag
    rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
    cp "$JAR" "$D/roms/"
    cat > "$D/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
swap=$swap
EOF
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    NOJME_LOG=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D/roms" \
    NOJME_SWITCH_UI_DIR="$D" \
    XDG_DATA_HOME="$D/xdg" \
    NOJME_SWITCH_KEYS="A:600,A:800" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=$sessions \
    NOJME_SWITCH_AUTOTEST_EXIT_MS=$exit_ms \
    NOJME_FRONT_KEYS="$front" \
    timeout -k 5 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
    echo "$D"
}

ok=1
say() { if [ "$1" = 0 ]; then echo "  ok   $2"; else echo "  FAIL $2"; ok=0; fi; }
# v36.87: счёт ТОЛЬКО по err.log — он содержит И консоль ([JK]/[SWITCH]),
# И trace-строки ([KEYIN]/pause:/ctl:); log.txt дублирует trace и ломал
# бы счётчики (каждое событие посчиталось бы дважды).
cnt() { local n; n=$(grep -ahc "$1" "$2/err.log" 2>/dev/null || true); echo "${n:-0}"; }

# ---------- КЕЙС 1: ремап A -> '7' через экран «Управление» ----------
D=$(run_case remap off \
  "MINUS:5000,DOWN:400,DOWN:400,A:600,DOWN:500,DOWN:500,A:500,DOWN:300,DOWN:300,DOWN:300,DOWN:300,DOWN:300,DOWN:300,DOWN:300,DOWN:300,A:400,B:700,B:700,A:900,MINUS:3000,DOWN:400,DOWN:400,DOWN:400,A:800,A:5000,MINUS:4000,DOWN:400,DOWN:400,DOWN:400,A:800" \
  2 34000)
ALL="$D/err.log" # счёт/наличие — только err.log (см. cnt выше)
echo "--- кейс 1: ремап ($D)"
grep -ahq "JK] start" $ALL || { echo "FAIL: TestKeys.jar не стартовал"; ok=0; }
n=$(cnt "game: begin" "$D")
[ "$n" = "2" ] && say 0 "обе сессии стартовали (game: begin x$n)" || { say 1 "сессий $n (want 2)"; }
n=$(cnt "pause: ctl" "$D")
[ "$n" -ge 1 ] && say 0 "пункт «Управление» открыт из меню паузы (pause: ctl x$n)" || { say 1 "нет trace pause: ctl"; }
n=$(cnt "ctl: open" "$D")
[ "$n" -ge 1 ] && say 0 "экран «Управление» открылся (ctl: open x$n)" || { say 1 "нет trace ctl: open"; }
n=$(cnt "JK] pressed 55" "$D")
[ "$n" = "2" ] && say 0 "A в игре -> keyPressed('7') в ОБЕИХ сессиях (x$n)" || { say 1 "pressed 55 x$n (want 2 — ремап/персистентность)"; }
n=$(cnt "KEYIN] dispatch btn=0 -> key=55" "$D")
[ "$n" = "2" ] && say 0 "диспетчер: btn A -> key 55 ('7') x$n" || { say 1 "[KEYIN] dispatch btn=0 -> key=55 x$n (want 2)"; }
n=$(cnt "JK] pressed 53" "$D")
[ "$n" = "0" ] && say 0 "встроенный '5' от A больше НЕ приходит" || { say 1 "pressed 53 x$n (ремап не применился?)"; }
n=$(cnt "pause menu -> exit game" "$D")
[ "$n" = "2" ] && say 0 "выход через «Выйти» (DOWN×3) обе сессии (x$n)" || { say 1 "exit x$n (want 2 — навигация 4-го пункта?)"; }
PGINI="$D/pergame/TestKeys.jar.ini" # имя = <имя jar-файла>.ini
if [ -f "$PGINI" ]; then
    grep -q "^btn.A=7$" "$PGINI" && say 0 "pergame ini: btn.A=7 записан" || { say 1 "в pergame ini нет btn.A=7"; }
    grep -q "^diag=both$" "$PGINI" && say 0 "pergame ini: diag=both (дефолт не изменён кейсом)" || { say 1 "в pergame ini нет diag=both"; }
else
    say 1 "pergame ini не создан ($PGINI)"
fi

# ---------- КЕЙС 2: диагонали стика/крестовины через UI (swap=on) ----------
D=$(run_case diag on \
  "MINUS:5000,DOWN:400,DOWN:400,A:600,A:500,B:700,B:700,UPON:800,LEFTON:800,UPOFF:800,LEFTOFF:800,MINUS:3000,DOWN:400,DOWN:400,DOWN:400,A:800" \
  1 20000)
ALL="$D/err.log"
echo "--- кейс 2: диагонали ($D)"
grep -ahq "JK] start" $ALL || { echo "FAIL: TestKeys.jar не стартовал"; ok=0; }
grep -ahq "SWITCH] diagonals: pair + 1/3/7/9" $ALL && say 0 "стартовый лог: diagonals pair+1/3/7/9 (дефолт BOTH)" || { say 1 "нет стартового лога diagonals"; }
n=$(cnt "pause: ctl" "$D")
[ "$n" -ge 1 ] && say 0 "«Управление» открыт" || { say 1 "нет trace pause: ctl"; }
n=$(cnt "JK] pressed 50" "$D")
[ "$n" = "1" ] && say 0 "UPON (зона UP) -> keyPressed('2')" || { say 1 "pressed 50 x$n (want 1)"; }
n=$(cnt "JK] pressed 55" "$D")
[ "$n" = "1" ] && say 0 "UP+LEFT (диагональ) -> keyPressed('7')" || { say 1 "pressed 55 x$n (want 1 — диагональ!)"; }
n=$(cnt "JK] released 50" "$D")
[ "$n" = "1" ] && say 0 "переход UP -> UP+LEFT отпустил '2' (ровно одна цифра)" || { say 1 "released 50 x$n (want 1)"; }
n=$(cnt "JK] pressed 52" "$D")
[ "$n" = "1" ] && say 0 "UP отпущена (зона LEFT) -> keyPressed('4')" || { say 1 "pressed 52 x$n (want 1)"; }
n=$(cnt "JK] released 55" "$D")
[ "$n" = "1" ] && say 0 "выход из диагонали отпустил '7'" || { say 1 "released 55 x$n (want 1)"; }
n=$(cnt "JK] released 52" "$D")
[ "$n" = "1" ] && say 0 "центр отпустил '4'" || { say 1 "released 52 x$n (want 1)"; }
n=$(cnt "KEYIN] dispatch zone -> key=55" "$D")
[ "$n" -ge 1 ] && say 0 "трейс зон: [KEYIN] dispatch zone -> key=55" || { say 1 "нет zone-трейса диагонали"; }
for bad in -1 -2 -3 -4; do
  n=$(cnt "JK] pressed $bad" "$D")
  [ "$n" = "0" ] && say 0 "стрелка $bad от крестовины не пришла (swap=on: только цифры)" || { say 1 "pressed $bad x$n (крестовина шлёт стрелки?)"; }
done
PGINI="$D/pergame/TestKeys.jar.ini"
if [ -f "$PGINI" ]; then
    grep -q "^diag=digits$" "$PGINI" && say 0 "pergame ini: diag=digits записан" || { say 1 "в pergame ini нет diag=digits"; }
else
    say 1 "pergame ini не создан"
fi
n=$(cnt "pause menu -> exit game" "$D")
[ "$n" = "1" ] && say 0 "чистый выход через «Выйти»" || { say 1 "exit x$n (want 1)"; }

[ "$ok" = 1 ] && echo "CTL/STICK-DIAG: ALL CHECKS PASSED" || { echo "CTL/STICK-DIAG: CHECKS FAILED"; exit 1; }
