#!/bin/bash
# v36.103 [FAST-INVOKES]: DenseBench A/B — 27-instr/call Gameloft-density
# workload (Zombie field: ivk=300K/s at vi=8.2M/s). Default vs
# NOJME_FAST_INVOKES=0 on the SAME binary. Prints both medians + delta.
set -u
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/zdense
run_one() {
    rm -rf "$D"; mkdir -p "$D/roms"
    cp scripts/densebench/DenseBench.jar "$D/roms/"
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-} \
    NOJME_LOG=1 NOJME_LOGGING=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 NOJME_SWITCH_KEYS="A:400,A:800,EXIT:30000" \
    $1 timeout -k 5 45 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
    grep -a "est_calls/s=" "$D/err.log" | grep -o "est_calls/s=[0-9]*" | cut -d= -f2 | awk 'NF' | tail -n +3 | sort -n | awk '{a[NR]=$1} END{if(NR>0) print a[int((NR+1)/2)]; else print 0}'
}
med_on=$(run_one "")
med_off=$(run_one "env NOJME_FAST_INVOKES=0")
if [ -z "$med_on" ] || [ -z "$med_off" ] || [ "$med_on" = "0" ] || [ "$med_off" = "0" ]; then
    echo "DENSEBENCH: FAILED (on='${med_on}' off='${med_off}')"
    exit 1
fi
pct=$(python3 -c "print('%.1f' % ((float('$med_on')/float('$med_off')-1)*100))")
echo "DENSEBENCH: FAST-ON=${med_on} calls/s  FAST-OFF=${med_off} calls/s  delta=+${pct}%"
