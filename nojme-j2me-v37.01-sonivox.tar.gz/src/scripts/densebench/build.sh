#!/bin/bash
# v36.103 [FAST-INVOKES]: build DenseBench.jar (27-instr/call density).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
STUBS="$D/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/DenseBench.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: DNB, , DenseBench\r\nMIDlet-Name: DenseBench\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/DenseBench*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/DenseBench.jar" META-INF && zip -q "$D/DenseBench.jar" *.class )
echo "built: $D/DenseBench.jar"
