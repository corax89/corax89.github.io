package javax.microedition.lcdui;

public class Graphics {
    public static final int LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, HCENTER = 1, VCENTER = 2, BASELINE = 64;
    public void setColor(int rgb) {}
    public void setColor(int r, int g, int b) {}
    public int getColor() { return 0; }
    public void fillRect(int x, int y, int w, int h) {}
    public void drawRect(int x, int y, int w, int h) {}
    public void drawLine(int x1, int y1, int x2, int y2) {}
    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {}
    public void drawString(String s, int x, int y, int anchor) {}
    public void setClip(int x, int y, int w, int h) {}
    public void clipRect(int x, int y, int w, int h) {}
    public void translate(int x, int y) {}
    public void drawImage(Image img, int x, int y, int anchor) {}
    public void drawRegion(Image img, int x_src, int y_src, int width, int height,
                           int transform, int x_dest, int y_dest, int anchor) {}
    public void drawRGB(int[] rgbData, int offset, int scanlength, int x, int y,
                        int width, int height, boolean processAlpha) {}
}
