import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;

/* v36.103 [FAST-INVOKES]: DENSE call benchmark — models the Gameloft OO
 * density measured in the Zombie Infection field log: ~27 bytecode
 * instructions per Java call (ivk=300K/s at vi=8.2M/s), against
 * CallBench's ~1250 instr/call whose fat methods hide the call scaffold
 * on an out-of-order x86 host. Methods here are 5-30 bytecodes:
 * getters, field arithmetic, short update chains, virtual dispatch over
 * a 3-class hierarchy (PIC exercise), interface callbacks, private
 * (invokespecial) helpers and static utilities. */
public class DenseBench extends MIDlet {
    /* polymorphic hierarchy: 3 impls behind one call site */
    interface Entity { int update(int t); int kind(); }
    static class E1 implements Entity {
        int x, y, hp;
        public int update(int t) { x += t; y ^= t; hp -= 1; return x + y + hp; }
        public int kind() { return 1; }
    }
    static class E2 implements Entity {
        int a, b;
        public int update(int t) { a = a * 3 + t; b -= t; return a - b; }
        public int kind() { return 2; }
    }
    static class E3 implements Entity {
        int v;
        public int update(int t) { v ^= v << 1; v += t; return v; }
        public int kind() { return 3; }
    }

    static class Vec {
        int x, y;
        Vec(int x, int y) { this.x = x; this.y = y; }
        int dot(Vec o) { return x * o.x + y * o.y; }          /* virtual, short */
        int len2() { return x * x + y * y; }                   /* getter-ish */
        private int priv3(int v) { return v * 3 + 1; }         /* invokespecial */
        int via() { return priv3(len2()); }                    /* special chain */
    }

    /* static helpers, short bodies */
    static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static int mix(int a, int b) { return (a << 3) ^ (b >> 2) ^ (a + b); }

    Entity[] ents;
    Vec[] vecs;
    long acc;
    int frames;
    long t0;

    public DenseBench() {
        ents = new Entity[24];
        for (int i = 0; i < 24; i++) {
            switch (i & 3) {
                case 0: ents[i] = new E1(); break;
                case 1: ents[i] = new E2(); break;
                default: ents[i] = new E3(); break;
            }
        }
        vecs = new Vec[16];
        for (int i = 0; i < 16; i++) vecs[i] = new Vec(i, i * 3);
    }

    /* ~25 instr/call density: one update() per entity + short helpers */
    int tick(int t) {
        int s = 0;
        for (int i = 0; i < 24; i++) {
            Entity e = ents[i];
            s += e.update(t + i);          /* PIC: 3 classes, one site */
            s += e.kind();                 /* interface getter */
            s = clamp(s, -1000000, 1000000);
            s = mix(s, t);
        }
        for (int i = 0; i < 16; i++) {
            s += vecs[i].dot(vecs[(i + 1) & 15]);
            s += vecs[i].len2();
            s += vecs[i].via();
        }
        return s;
    }

    public void startApp() {
        acc = 0; frames = 0;
        t0 = System.currentTimeMillis();
        long tEnd = t0 + 12000;
        while (System.currentTimeMillis() < tEnd) {
            for (int k = 0; k < 200; k++) {
                acc += tick(frames + k);
            }
            frames++;
            if ((frames & 63) == 0) {
                long now = System.currentTimeMillis();
                /* ~57 calls/tick * 200 + ~110 = ~11500 calls per outer iter */
                System.out.println("DENSE frames=" + frames + " acc=" + acc +
                        " est_calls/s=" + (frames * 200 * 114L * 1000L / (now - t0 + 1)));
            }
        }
        long now = System.currentTimeMillis();
        System.out.println("DENSE DONE frames=" + frames + " ms=" + (now - t0) +
                " acc=" + acc);
        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
