#!/bin/bash
# v37.01 [RMS-ZOMBIE-HEAL]: E2E-тест лечения «зомби»-сохранений
# (bin/switchui-verify, SDL dummy). Полевой кейс: Bounce Tales (240x320)
# — «прохожу уровень, выхожу, открываю — только Новая игра»; стор 'game'
# валиден по CRC v3, но содержит одну ПУСТУЮ запись id=11 при next_id=12,
# а игра пишет прогресс жёстко в запись id 1.
# Сценарии (scripts/make_zombie_rms.py готовит сторы ДО запуска):
#   H1 сессия 1: TZ1 (зомби) -> [RMS-HEAL] в логе; идиома Bounce Tales
#      (load -> addRecord при пустом -> setRecord(1)) работает: Z1-* PASS.
#   H2 TZ2 (0 записей, next_id=11) -> тоже хил: addRecord получает id 1.
#   H3 TZ3 (здоровый, id=1 c данными) -> хил НЕ срабатывает, данные целы.
#   H4 TZ4 (записи с данными без id 1) -> хил НЕ трогает живые данные.
#   H5 сессия 2 (тот же каталог): прогресс TZ1/TZ2/TZ3 пережил
#      перезапуск процесса — сценарий пользователя «прошёл-вышел-открыл».
#   H6 A/B: NOJME_RMS_HEAL=0 + свежий зомби -> INVALID1 (старое
#      навсегда-сломанное поведение) — рубильник работает, баг
#      воспроизводится без хила.
# Успех = все проверки пройдены, ни одного SIGSEGV/зависания.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_rmsheal
rm -rf "$D"; mkdir -p "$D/roms/sub" "$D/rms"
cp scripts/testrmsz/TestRMSZ.jar "$D/roms/sub/" || { echo "RMSHEAL: FAIL — TestRMSZ.jar не собран (scripts/testrmsz/build.sh)"; exit 1; }

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# Каталог сохранений задаётся через ini настроек фронтенда (см. v36.106
# [RMS-SAVEGUARD]: verify-сборка и NOJME_RMS_DIR поверх setenv).
printf 'saves_dir=%s\n' "$D/rms" > "$D/switchui_settings.ini"
KEYS="A:400,A:400,A:400,EXIT:8000"

run_session() {  # $1 = метка, $2 = доп. env (KEY=VAL) или "-"
    local tag="$1"; shift
    local extra="$1"; shift
    if [ "$extra" = "-" ]; then
        env NOJME_SWITCH_KEYS="$KEYS" \
            timeout -k 5 40 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log"
    else
        env "$extra" NOJME_SWITCH_KEYS="$KEYS" \
            timeout -k 5 40 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log"
    fi
    echo $?
}

fail() { echo "RMSHEAL: FAIL — $*"; echo "RMSHEAL: FAILED"; exit 1; }
rz()    { grep -a "RZ:$1 " "$D/err_$2.log" | tail -1; }

# ---------- подготовка сторов (тот же формат v3+CRC, что пишет эмулятор) ----------
python3 scripts/make_zombie_rms.py "$D/rms/TestRMSZ" || fail "подготовка сторов"
[ -f "$D/rms/TestRMSZ/TZ1.rms" ] || fail "TZ1.rms не создан"

# ---------- H1-H4: сессия 1 (хил + идиома Bounce Tales) ----------
rc=$(run_session s1 -)
[ "$rc" = "0" ] || { echo "--- err_s1 tail:"; tail -15 "$D/err_s1.log"; fail "H1 rc=$rc"; }
grep -a "RMSZ: session 1" "$D/err_s1.log" >/dev/null || fail "H1: мидлет не запустился (нет session 1)"
grep -a "\[RMS-HEAL\].*TZ1" "$D/err_s1.log" >/dev/null || fail "H1: нет [RMS-HEAL] для TZ1"
grep -a "\[RMS-HEAL\].*TZ2" "$D/err_s1.log" >/dev/null || fail "H2: нет [RMS-HEAL] для TZ2"
if grep -a "\[RMS-HEAL\].*TZ3" "$D/err_s1.log" >/dev/null; then
    fail "H3: ложный [RMS-HEAL] здорового TZ3"
fi
if grep -a "\[RMS-HEAL\].*TZ4" "$D/err_s1.log" >/dev/null; then
    fail "H4: ложный [RMS-HEAL] TZ4 (живые данные)"
fi
rz Z1-LOAD s1  | grep -q "PASS" || fail "H1: $(rz Z1-LOAD s1)"
rz Z1-SAVE s1  | grep -q "PASS" || fail "H1: $(rz Z1-SAVE s1)"
rz Z1-RELOAD s1 | grep -q "PASS" || fail "H1: $(rz Z1-RELOAD s1)"
rz Z2-LOAD s1  | grep -q "PASS" || fail "H2: $(rz Z2-LOAD s1)"
rz Z2-SAVE s1  | grep -q "PASS" || fail "H2: $(rz Z2-SAVE s1)"
rz Z2-RELOAD s1 | grep -q "PASS" || fail "H2: $(rz Z2-RELOAD s1)"
rz Z3-LOAD s1  | grep -q "PASS" || fail "H3: $(rz Z3-LOAD s1)"
rz Z3-SAVE s1  | grep -q "PASS" || fail "H3: $(rz Z3-SAVE s1)"
rz Z4-DATA s1  | grep -q "PASS" || fail "H4: $(rz Z4-DATA s1)"
rz Z4-ID1 s1   | grep -q "PASS" || fail "H4: $(rz Z4-ID1 s1)"
rz Z5-OPEN s1  | grep -q "PASS" || fail "H7: $(rz Z5-OPEN s1)"
grep -a "RZ:DONE" "$D/err_s1.log" | grep -qv "/0$" && fail "H1: есть FAIL-строки: $(grep -a 'RZ:.*FAIL' "$D/err_s1.log" | head -3)"
echo "H1 OK: зомби TZ1 вылечен — идиома id-1 работает: $(rz Z1-LOAD s1 | sed 's/^RZ:[^ ]* //')"
echo "H2 OK: пустой TZ2 (stale next_id) вылечен: addRecord -> id 1"
echo "H3 OK: здоровый TZ3 не тронут хилом (данные целы)"
echo "H4 OK: TZ4 (данные без id 1) не тронут — InvalidRecordIDException по спеке"

# файл TZ1 после сессии: запись id=1 с маркером 1,14 (python-проверка байтов)
python3 - "$D/rms/TestRMSZ/TZ1.rms" <<'EOF' || fail "H1: TZ1.rms не содержит запись id=1 с прогрессом"
import struct, sys
d = open(sys.argv[1], 'rb').read()
magic, ver, nxt, cnt = struct.unpack_from('<IIII', d, 0)
assert magic == 0x524D5300 and ver == 3, "не v3"
off = 36  # 16 заголовок + 20 метаданных v2 (version, last_modified, authmode, writable)
found = False
for _ in range(cnt):
    rid, sz = struct.unpack_from('<II', d, off); off += 8
    data = d[off:off+sz]; off += sz
    if rid == 1 and data[:2] == bytes([1, 14]) and data[2:] == b'LEV2':
        found = True
assert found, "нет записи id=1 с LEV2"
EOF
echo "H1b OK: TZ1.rms на диске = запись id=1 {1,14,'LEV2'} (формат v3)"

# ---------- H7: [RMS-WAIT] плашка + отложенный флаш открытого стора ----------
grep -a "\[RMS-WAIT\]" "$D/err_s1.log" >/dev/null || fail "H7: нет [RMS-WAIT] при выходе с открытым dirty-стором (TZ5)"
python3 - "$D/rms/TestRMSZ/TZ5.rms" <<'EOF' || fail "H7: TZ5.rms не записан отложенным флашем (запись id=1 'DIRTY')"
import struct, sys
d = open(sys.argv[1], 'rb').read()
magic, ver, nxt, cnt = struct.unpack_from('<IIII', d, 0)
assert magic == 0x524D5300 and ver == 3 and cnt == 1, "не v3/не 1 запись"
rid, sz = struct.unpack_from('<II', d, 36)
assert rid == 1 and d[44:44+sz] == b'DIRTY', "нет записи id=1 DIRTY"
EOF
echo "H7 OK: [RMS-WAIT] показан при выходе; TZ5 доехал до диска отложенным флашем (id=1 'DIRTY')"

# ---------- H5: сессия 2 — персистентность через перезапуск процесса ----------
rc=$(run_session s2 -)
[ "$rc" = "0" ] || { echo "--- err_s2 tail:"; tail -15 "$D/err_s2.log"; fail "H5 rc=$rc"; }
grep -a "RMSZ: session 2" "$D/err_s2.log" >/dev/null || fail "H5: нет session 2"
rz P1-TZ1 s2 | grep -q "PASS" || fail "H5: $(rz P1-TZ1 s2)"
rz P2-TZ2 s2 | grep -q "PASS" || fail "H5: $(rz P2-TZ2 s2)"
rz P3-TZ3 s2 | grep -q "PASS" || fail "H5: $(rz P3-TZ3 s2)"
rz P1-SAVE s2 | grep -q "PASS" || fail "H5: $(rz P1-SAVE s2)"
grep -a "RZ:DONE" "$D/err_s2.log" | grep -qv "/0$" && fail "H5: есть FAIL-строки"
echo "H5 OK: прогресс пережил перезапуск процесса: TZ1=LEV2 TZ2=NEW1 TZ3=NEW3 (сценарий «прошёл-вышел-открыл»)"

# ---------- H6: A/B без хила — старое поведение воспроизводимо ----------
D2=/tmp/sw_rmsheal_ab
rm -rf "$D2"; mkdir -p "$D2/roms/sub" "$D2/rms"
cp scripts/testrmsz/TestRMSZ.jar "$D2/roms/sub/"
printf 'saves_dir=%s\n' "$D2/rms" > "$D2/switchui_settings.ini"
NOJME_SWITCH_BROWSE_ROOT="$D2/roms" NOJME_SWITCH_UI_DIR="$D2" \
  python3 scripts/make_zombie_rms.py "$D2/rms/TestRMSZ" >/dev/null || fail "H6: подготовка сторов"
# тот же bin/switchui-verify, но каталоги D2 и рубильник NOJME_RMS_HEAL=0
env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy NOJME_LOG=1 NOJME_LOGGING=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D2/roms" NOJME_SWITCH_UI_DIR="$D2" \
    NOJME_SWITCH_KEYS="$KEYS" NOJME_RMS_HEAL=0 \
    timeout -k 5 40 ./bin/switchui-verify > "$D2/out_ab.log" 2> "$D2/err_ab.log"
rc=$?
[ "$rc" = "0" ] || fail "H6 rc=$rc (сборка с рубильником упала)"
if grep -a "\[RMS-HEAL\]" "$D2/err_ab.log" >/dev/null; then
    fail "H6: рубильник NOJME_RMS_HEAL=0 не отключил хил"
fi
grep -aq "RZ:Z1-LOAD PASS" "$D2/err_ab.log" && fail "H6: без хила зомби НЕ должен читаться (Z1-LOAD PASS неожидаем)"
grep -aq "RZ:Z1-LOAD FAIL" "$D2/err_ab.log" || fail "H6: без хила ожидается Z1-LOAD FAIL (INVALID1) — воспроизведение бага"
echo "H6 OK: NOJME_RMS_HEAL=0 — баг воспроизводится (Z1-LOAD=INVALID1), рубильник работает"

# крашей нигде:
for f in "$D"/err_s*.log "$D2"/err_ab.log; do
    grep -aqi "segfault\|SIGSEGV" "$f" && fail "краш в $f"
done

echo ""
echo "RMSHEAL: ALL CHECKS PASSED (зомби вылечен, данные целы, персистентность подтверждена)"
