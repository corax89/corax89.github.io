#!/bin/bash
# BT-STALL repro: Bounce Tales — ловим сигнатуру «td m: nat=Thread.start
# age=<растёт>» из полевого лога v36.73 (сессия 2: age до 43917 мс,
# разблокировка ровно по pause: open).
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/Bounce Tales (240x320).jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/tbtstall
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/bt.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=on
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_TD_DEEP=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
# Запуск игры (A в браузере), затем редкие нажатия A в игру — как пользователь.
export NOJME_SWITCH_KEYS="A:3000"
export NOJME_FRONT_KEYS="A:15000,A:20000,A:25000,A:30000,A:40000,A:50000,A:60000,A:70000,A:80000,A:90000"
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN"; exit 1; }
( cd "$D" && timeout -k 10 105 "$BIN" > out.log 2> err.log ) || true
LOG="$D/sdmc:/switch/j2me/log.txt"
[ -s "$LOG" ] || { echo "FAIL: log.txt пуст/отсутствует"; exit 1; }
echo "== td m Thread.start ages =="
grep -E "td m: nat=java/lang/Thread.start" "$LOG" | head -40
echo "== worst age =="
grep -oE "td m: nat=java/lang/Thread.start age=[0-9]+" "$LOG" | grep -oE "[0-9]+$" | sort -n | tail -3
echo "== TSTART/VMPOOL/PAINT-LOCK/GC-STRAGGLER/SPIN-BREAK =="
grep -cE "TSTART|PAINT-LOCK|GC-STRAGGLER" "$LOG" || true
grep -E "SPIN-BREAK|VM-THREAD-DEATH" "$LOG" | head
echo "== err.log tail =="
tail -5 "$D/err.log" 2>/dev/null
