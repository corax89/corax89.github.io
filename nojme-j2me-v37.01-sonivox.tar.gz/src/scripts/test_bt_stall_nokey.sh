#!/bin/bash
# BT-STALL-NOKEY: как ведёт себя фаза загрузки БЕЗ нажатий — время или ввод?
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/Bounce Tales (240x320).jar"
D=/tmp/tbtnk
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame" "$D/sdmc:/switch/j2me/snaps"
cp "$JAR" "$D/sdmc:/switch/j2me/games/bt.jar"
touch "$D/sdmc:/switch/j2me/snap.flag"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=on
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_TD_DEEP=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:3000"
export NOJME_FRONT_KEYS="A:8000"
BIN="$PWD/bin/switchui-verify"
( cd "$D" && timeout -k 10 100 "$BIN" > out.log 2> err.log ) || true
LOG="$D/sdmc:/switch/j2me/log.txt"
echo "== RESOURCE timeline =="
grep -E "RESOURCE" "$LOG" | tail -6
echo "== [SCHED] sleep stats (t2) =="
grep -E "SCHED" "$D/err.log" | head -12
echo "== last frames =="
ls "$D/sdmc:/switch/j2me/snaps" | wc -l
