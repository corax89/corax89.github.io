/*
 * Measure Sonivox MIDI output level vs a full-scale reference.
 * Renders GoF_InGame.MID exactly like nojme's mix path
 * (221 stereo samples/cycle) at several EAS volume settings and
 * post-gain factors, printing per-setting peak levels.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#include "midi.h"

static uint8_t* read_file(const char* path, uint32_t* size) {
    FILE* f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t* buf = malloc(len);
    if (fread(buf, 1, len, f) != (size_t)len) { fclose(f); free(buf); return NULL; }
    fclose(f);
    *size = (uint32_t)len;
    return buf;
}

static void measure(const char* label, const char* path, float eas_volume,
                    float post_gain, int seconds) {
    midi_init(44100);
    uint32_t size = 0;
    uint8_t* data = read_file(path, &size);
    if (!data) { fprintf(stderr, "cannot read %s\n", path); return; }
    MidiFile* midi = midi_load(data, size);
    if (!midi) { fprintf(stderr, "midi_load failed\n"); free(data); return; }
    midi_set_volume(midi, eas_volume);
    midi_set_loop(midi, true);
    midi_play(midi);

    const int samples_per_cycle = 44100 / 200 + 1;   /* 221, same as media.c */
    int16_t* buf = malloc(samples_per_cycle * 2 * sizeof(int16_t));

    int cycles = seconds * 200;
    int32_t peak = 0;
    double sum2 = 0.0;
    uint64_t n_total = 0;
    for (int c = 0; c < cycles; c++) {
        memset(buf, 0, samples_per_cycle * 2 * sizeof(int16_t));
        midi_generate_samples(midi, buf, samples_per_cycle);
        for (int i = 0; i < samples_per_cycle * 2; i++) {
            int32_t s = (int32_t)lrintf(buf[i] * post_gain);
            if (s > 32767) s = 32767;
            if (s < -32768) s = -32768;
            int32_t a = s < 0 ? -s : s;
            if (a > peak) peak = a;
            sum2 += (double)s * s;
            n_total++;
        }
    }
    double rms = sqrt(sum2 / (double)n_total);
    printf("%-44s peak=%6d (%+.1f dBFS)  rms=%7.1f (%+.1f dBFS)\n",
           label, peak, 20.0 * log10((double)peak / 32767.0),
           rms, 20.0 * log10(rms / 32767.0));
    free(buf);
    midi_free(midi);   /* releases EAS instance */
    free(data);
}

int main(int argc, char** argv) {
    const char* path = argc > 1 ? argv[1] :
        "/home/z/my-project/work/gof/jar/data/sound/GoF_InGame.MID";
    const char* path2 = "/home/z/my-project/work/gof/jar/data/sound/GoF_Menu.MID";
    printf("reference: full-scale WAV sfx = 32767 peak (0.0 dBFS)\n");
    measure("GoF_InGame  EAS vol=0.90 (v36.90 default)", path, 0.90f, 1.0f, 20);
    measure("GoF_InGame  EAS vol=1.00 (real-device default)", path, 1.00f, 1.0f, 20);
    measure("GoF_InGame  EAS vol=0.90 + post x2.0", path, 0.90f, 2.0f, 20);
    measure("GoF_Menu    EAS vol=0.90 (v36.90 default)",
            "/home/z/my-project/work/gof/jar/data/sound/GoF_Menu.MID", 0.90f, 1.0f, 20);
    measure("GoF_Menu    EAS vol=1.00", path2, 1.00f, 1.0f, 20);
    return 0;
}
