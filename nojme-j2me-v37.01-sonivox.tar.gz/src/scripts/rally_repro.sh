#!/bin/bash
# Воспроизведение бага Rally 3D (Nokia): «гонка после загрузки сохранения —
# видна только модель машины». Хостовая verify-сборка + FRONT_KEYS-скрипт.
# Аргументы: $1 = суффикс прогона; RUN_SECONDS, EXTRA_ENV — снаружи.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/rally_repro_${1:-base}
rm -rf "$D"; mkdir -p "$D/roms"
cp "/home/z/my-project/rally3d/rally3d.jar" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
# Браузер: A — открыть roms, A — запустить jar
export NOJME_SWITCH_KEYS="A:400,A:600"
# Тайминг игрока из полевого лога (процесс = игра + ~3.15с):
#   меню ~9.5с; A(FIRE/'5') @10.4с; A @12.1с; гонка ~13с; B(RSK) @17с; далее газ/руль
FRONT="A:10200,A:1800,UP:600,RIGHT:900,LEFT:700,RIGHT:600,LEFT:600,UP:1500,UP:1500,B:2500,UP:800,B:1200,A:500"
export NOJME_FRONT_KEYS="$FRONT"
# Стеки застрявших потоков (как в GD-сессии)
export NOJME_SELF_STACK_EVERY=1
export NOJME_PAINTTIME=1
eval "${EXTRA_ENV:-true}"

RUN_SECONDS=${RUN_SECONDS:-45}
timeout -k 5 "$RUN_SECONDS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit=$rc  (log: $D/err.log)"
echo "=== NPE / исключения ==="
grep -an "EX-THROW\|EX-PROP\|paint() threw" "$D/err.log" | head -10
echo "=== showNotify / DISPLAY ==="
grep -an "DISPLAY\] Calling showNotify\|showNotify() completed\|hideNotify" "$D/err.log" | head -12
echo "=== фризы ==="
grep -an "SPIN-BREAK\|PAINT-BUDGET\|MON-WAIT\|STUCK\|MIDLET-STUCK\|NO-FRAME\|STM-SPIN\|stm eof\|SELFSTACK" "$D/err.log" | head -40
echo "=== td m / m3g (последние) ==="
grep -an "td m:" "$D/err.log" | tail -8
grep -an "td m3g" "$D/err.log" | tail -6
echo "=== ключевые события ==="
grep -an "game: begin\|frame: first\|VM-THREAD-DEATH\|RESOURCE\].*track\|RESOURCE\].*billboard\|RMS\]\|rms-\|KEYQ-SOFT\|session end" "$D/err.log" | head -40
echo "=== diag ==="
grep -an "diag: loop" "$D/err.log" | tail -6
