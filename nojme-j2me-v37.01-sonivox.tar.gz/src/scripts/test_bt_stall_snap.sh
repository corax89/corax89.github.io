#!/bin/bash
# BT-STALL + SNAP: покадровый дамп экрана во время «зависания» — что видит
# пользователь в фазе lang.xx-цикла (15-60 с).
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/Bounce Tales (240x320).jar"
D=/tmp/tbtsnap
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame" "$D/sdmc:/switch/j2me/snaps"
cp "$JAR" "$D/sdmc:/switch/j2me/games/bt.jar"
touch "$D/sdmc:/switch/j2me/snap.flag"     # NOJME_SNAP_DIR=.../snaps,ALL
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=off
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:3000"
export NOJME_FRONT_KEYS="A:22000,A:40000,A:60000"
BIN="$PWD/bin/switchui-verify"
( cd "$D" && timeout -k 10 90 "$BIN" > out.log 2> err.log ) || true
SN="$D/sdmc:/switch/j2me/snaps"
echo "== snap count: $(ls "$SN" 2>/dev/null | wc -l) =="
ls "$SN" 2>/dev/null | head -3; ls "$SN" 2>/dev/null | tail -3
