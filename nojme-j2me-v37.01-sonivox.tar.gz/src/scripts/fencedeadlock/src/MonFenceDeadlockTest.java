import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;

/**
 * v36.96 [FENCE-DEADLOCK-BREAK] e2e selftest — "very short pauses" root.
 *
 * Field evidence (log v36.95-midiloop1, Metal Slug 6 session, 5 pauses of
 * exactly ~1000-1029 ms):
 *   the frontend pump delivers a key INSIDE the EXIT-FENCE (frame-thread
 *   Java window) and blocks in monitorenter(at.a) — the game's input-state
 *   lock. The game thread t2 holds at.a inside its tiny input-sync section
 *   at.run() [605..700] (monitorenter@605 .. monitorexit@700, ~90 bytecodes
 *   of arraycopy + a 23-iteration merge loop) — LONGER than the 64-
 *   instruction slow-check interval, so the interpreter polls INSIDE the
 *   held section, sees g_vm_fiber_fence, and parks in
 *   jvm_frame_fence_wait_public(): the owner waits for OUR window while we
 *   wait for its monitor. Mutual deadlock, broken only by the v36.94
 *   KEY-BUDGET expiry (1 s) = the field "very short pauses"; pre-v36.94 the
 *   same deadlock ran 22.5 s (2.5 s fence-cap loop / MON-STEAL).
 *
 * This test reproduces the shape deterministically:
 *   - game thread: holds LOCK in a BUSY pure-Java loop for 2.5 s (slow-
 *     checks fire INSIDE the synchronized block — the fence poll site!),
 *     releases for 300 ms, repeats (canvas monitor never held);
 *   - KEYSCRIPT injects a key at frame 30: pump -> keyReleased ->
 *     synchronized(LOCK) — the exact at.h@197 shape.
 *
 * Expect (with v36.96):
 *   [FENCE-DEADLOCK] delivery abort ... owner fence-waiting  (fast breaks)
 *   NO [KEY-BUDGET] "exceeded" lines  (the break fires BEFORE the 200 ms
 *                                     budget ever expires)
 *   NO [MON-WAIT] waited=2000
 *   FENCEDEADLOCK:DELIVERED ...       (in a release window)
 *   FENCEDEADLOCK:DESTROYED, clean exit.
 *
 * Pre-v36.96 behavior: deliveries abort at the budget expiry ([KEY-BUDGET]
 * lines, 200 ms stalls each) or burn the whole budget (default 1000 in
 * v36.94/95) — the game thread stays fence-waited for the full budget.
 */
public class MonFenceDeadlockTest extends MIDlet implements Runnable {

    static final Object LOCK = new Object();   // аналог at.a (замок ввода)
    static volatile boolean stop = false;
    static int delivered = 0;
    static long startMs;

    public MonFenceDeadlockTest() { startMs = System.currentTimeMillis(); }

    public void startApp() {
        System.out.println("FENCEDEADLOCK:STARTAPP-BEGIN t=" + (System.currentTimeMillis() - startMs));
        Display.getDisplay(this).setCurrent(new FdCanvas());
        System.out.println("FENCEDEADLOCK:STARTAPP-CANVAS-SET");
        Thread t = new Thread(this);
        t.start();
        System.out.println("FENCEDEADLOCK:STARTAPP-THREAD-STARTED");
    }

    public void run() {
        System.out.println("FENCEDEADLOCK:GAME-LOOP-BEGIN");
        // «Игровой цикл»: ДЕРЖИТ замок ввода в ЧИСТО-JAVA busy-цикле 2.5 c
        // (slow-check стреляет ВНУТРИ synchronized — место фенс-парка),
        // отпускает на ~300 мс. Канву НЕ держим — как at.run() вне bl().
        while (!stop && System.currentTimeMillis() - startMs < 20000) {
            synchronized (LOCK) {
                byte[] b = new byte[23];
                byte[] c = new byte[23];
                System.arraycopy(b, 0, c, 0, 23);   // «key-sync» MS6 (натив)
                long deadline = System.currentTimeMillis() + 2500;
                // busy-spin: натив каждые ~несколько команд, slow-check
                // между ними — при установленном фенсе раннер встанет
                // в jvm_frame_fence_wait_public() с ЗАХВАЧЕННЫМ замком.
                while (System.currentTimeMillis() < deadline && !stop) { }
            }
            try { Thread.sleep(300); } catch (InterruptedException ie) { }
        }
        stop = true;
        System.out.println("FENCEDEADLOCK:GAME-DONE delivered=" + delivered);
        // Детерминированный финал: destroyApp через штатный notifyDestroyed
        // (headless-разбор v36.32 «VM threads exhausted» НЕ доставляет
        // destroyApp для естественно завершившегося мидлета).
        notifyDestroyed();
    }

    static class FdCanvas extends Canvas {
        protected void paint(Graphics g) {
            g.drawString("FD " + delivered, 5, 20, Graphics.TOP | Graphics.LEFT);
        }

        protected void keyReleased(int keyCode) {
            // аналог at.h(II)@196: monenter на замок СОСТОЯНИЯ ВВОДА
            synchronized (LOCK) {
                delivered++;
                long now = System.currentTimeMillis();
                System.out.println("FENCEDEADLOCK:DELIVERED k=" + keyCode
                        + " t=" + (now - startMs));
            }
        }
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) {
        stop = true;
        System.out.println("FENCEDEADLOCK:DESTROYED delivered=" + delivered);
    }
}
