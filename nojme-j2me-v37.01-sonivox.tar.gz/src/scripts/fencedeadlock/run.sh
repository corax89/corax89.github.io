#!/bin/bash
# Run the v36.96 [FENCE-DEADLOCK-BREAK] e2e selftest and judge the output.
#
# Shape: game thread holds LOCK in a busy pure-Java loop 2.5 s (slow-checks
# fire INSIDE the held section = the fence-poll site), releases 300 ms,
# repeats for 20 s. KEYSCRIPT injects -4 at frame 30 (~300 ms) -> the pump's
# keyReleased blocks on LOCK while the owner fence-waits = mutual deadlock.
#
# PASS criteria (v36.96):
#   - at least one [FENCE-DEADLOCK] line (deadlock detected and broken);
#   - ZERO [KEY-BUDGET] "exceeded" lines (break fires before the 200 ms
#     budget expires);
#   - ZERO "[MON-WAIT]" lines with waited>=2000;
#   - FENCEDEADLOCK:DELIVERED present (key delivered in a release window);
#   - FENCEDEADLOCK:DESTROYED present, exit 0.
#
# FAIL signature (pre-v36.96): [KEY-BUDGET] lines (budget expiry = the
# delivery never noticed the deadlock), or [MON-WAIT] 2000+.
set -u
D="$(cd "$(dirname "$0")" && pwd)"
BIN="${BIN:-$D/../../bin/j2me-headless}"
JAR="$D/MonFenceDeadlockTest.jar"
OUT="${1:-$D/out/run.log}"

[ -x "$BIN" ] || { echo "FAIL: headless binary not found: $BIN"; exit 2; }
[ -f "$JAR" ] || { echo "FAIL: test jar not built ($JAR) — run build.sh"; exit 2; }

NOJME_LOG=1 \
NOJME_HEADLESS_MAX_MS=45000 \
NOJME_HEADLESS_KEYSCRIPT="30:-4;900:-4;1800:-4" \
timeout 70 "$BIN" "$JAR" > "$OUT" 2>&1
RC=$?

FD=$(grep -c "FENCE-DEADLOCK" "$OUT" || true)
KB=$(grep -c "KEY-BUDGET" "$OUT" || true)
MW=$(grep -c "MON-WAIT.*waited=[2-9][0-9][0-9][0-9]" "$OUT" || true)
DLV=$(grep -c "FENCEDEADLOCK:DELIVERED" "$OUT" || true)
DST=$(grep -c "FENCEDEADLOCK:DESTROYED" "$OUT" || true)
DN=$(grep -c "FENCEDEADLOCK:GAME-DONE" "$OUT" || true)

echo "---- summary ----"
echo "FENCE-DEADLOCK lines : $FD"
echo "KEY-BUDGET lines     : $KB"
echo "MON-WAIT >=2s lines  : $MW"
echo "DELIVERED            : $DLV"
echo "DESTROYED            : $DST"
echo "GAME-DONE            : $DN"
echo "exit code            : $RC"
echo "-----------------"

ST=0
[ "$FD" -ge 1 ]  || { echo "FAIL: no [FENCE-DEADLOCK] lines — deadlock break never fired"; ST=1; }
[ "$KB" -eq 0 ]  || { echo "FAIL: [KEY-BUDGET] present — break is slower than the budget"; ST=1; }
[ "$MW" -eq 0 ]  || { echo "FAIL: [MON-WAIT] 2s+ — unbounded wait leaked"; ST=1; }
[ "$DLV" -ge 1 ] || { echo "FAIL: key never delivered"; ST=1; }
[ "$DST" -ge 1 ] || { echo "FAIL: destroyApp not reached"; ST=1; }
[ "$RC" -eq 0 ]  || { echo "FAIL: nonzero exit"; ST=1; }

[ $ST -eq 0 ] && echo "FENCEDEADLOCK: PASSED" || echo "FENCEDEADLOCK: FAILED"
exit $ST
