#!/bin/bash
# v36.104: RetBench golden checksums — interpreter-core changes must be
# BIT-EXACT against the v36.100/v36.101/v36.102/v36.103 goldens.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tret
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/retbench/RetBench.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:400,A:800,EXIT:20000"
timeout -k 5 30 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

fail=0
check() {
    got=$(grep -a "RB $1 " "$D/err.log" | tail -1 | sed "s/.*RB $1 //;s/\r//")
    if [ "$got" = "$2" ]; then
        echo "RETBENCH: $1 OK ($got)"
    else
        echo "RETBENCH: $1 MISMATCH got='$got' want='$2'"
        fail=1
    fi
}
check "SUM-L" "5597742076056351744"
check "SUM-D" "3.999979998000101"
check "SUM-F" "NaN"
check "SUM-M" "-3739709241755009701"
grep -aq "RB DONE" "$D/err.log" || { echo "RETBENCH: no DONE"; fail=1; }
exit $fail
