#!/bin/bash
# [POISON-JOURNEY] (Task 14 / v36.50) — ловим источник Ryujinx InvalidAccess
# 0x20697465592F7365 ("es/Yeti "), 0x636E756F422F7365 ("es/Bounc"),
# 0x6E692E73676E6974 ("tings.in" = settings.ini): пользователь доказал, что
# ошибка бывает ДО запуска любого мидлета (браузер) и при загрузке ДРУГОГО
# мидлета (адрес = фрагмент ЕГО пути, окна байтов 21-28 от начала строки
# "sdmc:/switch/j2me/..." во всех трёх случаях). Гипотеза: указатель,
# перезаписанный байтами пути (use-after-free / intra-struct overflow),
# разыменовывается во фронтенде — и, возможно, в JVM.
#
# Метод: bin-poison/switchui-verify (собран с -ftrivial-auto-var-init=pattern
# -fstack-protector-all -g) + glibc MALLOC_PERTURB_=165 (вся освобождённая
# и свежевыделенная память = 0xA5/0x5A) + LD_PRELOAD segvtrace.so (SIGSEGV с
# backtrace). Любой deref мусорного/освобождённого указателя = SEGV с точным
# стеком вызовов. ПУТИ УСТРОЙСТВА БАЙТ-В-БАЙТ: рабочий каталог содержит
# "sdmc:/switch/j2me/{games,saves,pergame}" как ОТНОСИТЕЛЬНЫЕ пути —
# browse_root/setenv("NOJME_RMS_DIR") получают ровно те же строки, что и на
# консоли ("sdmc:/switch/j2me/games/Yeti Sports (00.02.51)[240x320].jar").
#
# Фазы: C — только браузер (скролл, вход/выход из каталогов, ресканы) —
# полевой случай "до открытия мидлета"; A — Yeti x3 (диалог X -> сплэш '5' ->
# меню с музыкой -> пауза -> выход -> ПОВТОР); B — Bounce x2 + настройки.
# Любой [SEGVTRACE] в stderr = локализованный источник; егоfault_addr в ASCII
# покажет, чьи это были байты.
set -u
cd "$(dirname "$0")/.." || exit 1

YS="${YS_JAR:-/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar}"
BT="${BT_JAR:-/home/z/my-project/ys/bt.jar}"
[ -f "$YS" ] || { echo "FAIL: нет JAR Yeti: $YS"; exit 1; }
[ -f "$BT" ] || { echo "FAIL: нет JAR Bounce: $BT"; exit 1; }

W=${1:-/tmp/pj_work}
rm -rf "$W"
mkdir -p "$W/sdmc:/switch/j2me/games" "$W/sdmc:/switch/j2me/saves" "$W/sdmc:/switch/j2me/pergame"
cp "$YS" "$W/sdmc:/switch/j2me/games/Yeti Sports (00.02.51)[240x320].jar"
cp "$BT" "$W/sdmc:/switch/j2me/games/Bounce Tales (240x320).jar"
DUMMY=$(ls scripts/testdosw/TestDosWrite.jar 2>/dev/null || ls scripts/keysjar/out/TestKeys.jar 2>/dev/null | head -1)
[ -n "$DUMMY" ] && cp "$DUMMY" "$W/sdmc:/switch/j2me/games/Space Test.jar"
[ -n "$DUMMY" ] && cp "$DUMMY" "$W/sdmc:/switch/j2me/games/Zeta Test.jar"

cat > "$W/sdmc:/switch/j2me/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=linear
audio=on
vm_speed=turbo
lang=ru
games_dir=sdmc:/switch/j2me/games
saves_dir=sdmc:/switch/j2me/saves
logging=on
flip=auto
frame_counter=off
tex_filter=auto
swap=off
deadzone=50
battery=off
EOF

BIN=./bin-poison/switchui-verify
[ -x "$BIN" ] || { echo "FAIL: нет $BIN"; exit 1; }

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_MEDIA_DEBUG=1
# v36.60 [PSCAN-FLAG]: PTRSCAN-проходы прибора теперь опциональны
# (лаг меню после игровой сессии был именно ими). Джорней ВАЛИДИРУЕТ
# сканер — включаем явно.
export NOJME_PG_SCAN=1
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export XDG_DATA_HOME="$W/sdmc:/switch/j2me/xdg"
export MALLOC_PERTURB_=165
export LD_PRELOAD=/home/z/my-project/scripts/segvtrace.so

run() { # $1 name, $2 timeout, $3.. env pairs (KEY=VAL), then runs $BIN
    local name="$1"; shift
    local tmo="$1"; shift
    echo "=== ФАЗА $name (timeout ${tmo}s) ==="
    ( cd "$W" && env "$@" timeout -k 5 "$tmo" "$OLDPWD/$BIN" \
        > "/tmp/pj_${name}_out.log" 2> "/tmp/pj_${name}_err.log" )
    local rc=$?
    echo "rc=$rc"
    if rg -q "SEGVTRACE" "/tmp/pj_${name}_err.log"; then
        echo "!!!! SEGV В ФАЗЕ $name !!!!"
        rg -A22 "SEGVTRACE" "/tmp/pj_${name}_err.log" | head -60
        return 2
    fi
    rg -q "Segmentation fault" "/tmp/pj_${name}_err.log" && { echo "SEGV без трейса в $name"; return 2; }
    echo "чисто (ошибок памяти не поймано)"
    return 0
}

# ---- ФАЗА C: браузер без запуска игры (полевой случай 00:00:09, "tings.in") ----
# Скролл по 4 записям, вход в каталог [saves], выход наверх, повторное
# сканирование, возврат в главное меню, вход в настройки, MINUS (запись
# settings.ini), выход из приложения.
run C 40 \
    NOJME_SWITCH_KEYS="A:2500,DOWN:4000,DOWN:5000,DOWN:6000,DOWN:7000,UP:8000,B:9000,A:10000,B:11000,B:12000,DOWN:13500,A:14500,MINUS:16000,B:17500,EXIT:22000" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 \
    NOJME_SWITCH_AUTOTEST_EXIT_MS=2000 || exit 2

# ---- ФАЗА A: Yeti x3 (диалог -> сплэш -> меню с музыкой -> пауза -> выход) ----
# Сортировка: Bounce(0) Space(1) Yeti(2) Zeta(3) => DOWN,DOWN,A выбирает Yeti.
# MINUS в начале = запись settings.ini на БРАУЗЕРНОМ потоке (полевой случай).
run A 260 \
    NOJME_SWITCH_KEYS="MINUS:2500,A:5500,DOWN:7000,DOWN:8000,A:9000" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=3 \
    NOJME_SWITCH_AUTOTEST_EXIT_MS=8000 \
    NOJME_GAME_KEYS="W:12000,-6:400,W:5000,53:300,W:44000" \
    NOJME_FRONT_KEYS="PLUS:60000,DOWN:61000,DOWN:62000,DOWN:62500,A:63000" || exit 2

# ---- ФАЗА B: Bounce x2 (первая запись списка) ----
run B 150 \
    NOJME_SWITCH_KEYS="A:3500,A:5000" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=2 \
    NOJME_SWITCH_AUTOTEST_EXIT_MS=8000 \
    NOJME_GAME_KEYS="53:4000,W:16000" \
    NOJME_FRONT_KEYS="PLUS:24000,DOWN:25000,DOWN:26000,DOWN:26500,A:27000" || exit 2

echo
echo "=== Сводка ==="
for f in /tmp/pj_*_err.log; do
    n=$(rg -c "SEGVTRACE" "$f" 2>/dev/null || echo 0)
    echo "$f: SEGVTRACE=$n"
done
echo "log.txt устройства-модель: $W/sdmc:/switch/j2me/log.txt"
rg -a "ARGGUARD|SEGVTRACE|SURFACE-RECREATE|game: |menu: |settings: " "$W/sdmc:/switch/j2me/log.txt" 2>/dev/null | head -40
exit 0
