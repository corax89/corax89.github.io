#!/bin/bash
# test_switch_ondemand.sh — v36.77 [PERF-PRESENT]: проверка present-on-demand.
# Фаза A (ONDEMAND=1, дефолт новой версии, фиксируем явно):
#   - diag содержит pd= (новое поле);
#   - при статичной картинке pd растёт (пропуски работают), pr < loop;
#   - при живой игре контент доезжает (chg>=1 в поздних окнах) и нет [WEDGE].
# Фаза B (ONDEMAND=0 — режим отката):
#   - pd=0 во всех окнах, pr == loop (каждый цикл презентует, как в v36.76).
# Игра — TTRepro (GameCanvas + t2: render+flushGraphics+sleep(20)):
# ~50 сеттлов/с, между ними цикл крутится быстро — идеальный донор pd.
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="$PWD/scripts/ttrepro/TTRepro.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN"; exit 1; }

run_case() { # $1 = value of NOJME_PRESENT_ONDEMAND
    local D="/tmp/sw_ondemand_$1"
    rm -rf "$D"
    mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
    cp "$JAR" "$D/sdmc:/switch/j2me/games/AAATTRepro.jar"
    cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_black
filter=nearest
audio=on
logging=on
EOF
    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
    export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
    export NOJME_SWITCH_KEYS="A:600,A:800,B:16000"
    export NOJME_FRONT_KEYS=""
    export NOJME_PRESENT_ONDEMAND="$1"
    ( cd "$D" && timeout -k 10 40 "$BIN" > out.log 2> err.log ) || true
    echo "$D/sdmc:/switch/j2me/log.txt"
}

FAIL=0
echo "=== Фаза A: NOJME_PRESENT_ONDEMAND=1 ==="
LOGA=$(run_case 1)
[ -s "$LOGA" ] || { echo "FAIL(A): log.txt пуст"; exit 1; }
echo "-- diag-окна (loop/pr/pd) --"
grep -oE "loop=[0-9]+ pr=[0-9]+|pd=[0-9]+" "$LOGA" | paste - - 2>/dev/null | head -8
echo
# pd присутствует и ненулевой хоть в одном окне
grep -q "pd=" "$LOGA" || { echo "FAIL(A): нет поля pd= в diag"; FAIL=1; }
PDG=$(grep -oE "pd=[0-9]+" "$LOGA" grep -oE "pd=[1-9][0-9]*" 2>/dev/null | head -1)
PDNONZERO=$(grep -oE "pd=[1-9][0-9]*" "$LOGA" | head -1)
[ -n "$PDNONZERO" ] || { echo "FAIL(A): pd ни разу не был ненулевым"; FAIL=1; }
# контент доезжает: поздние окна с chg>=1 (или lvc>0 при прямом пути)
LATE=$(grep -oE "chg=[0-9]+" "$LOGA" | tail -4 | grep -c "chg=[1-9]")
[ "$LATE" -ge 2 ] || { echo "FAIL(A): поздние окна без chg>=1 — контент не доезжает?"; FAIL=1; }
# клина нет
grep -q "\[WEDGE\]" "$LOGA" && { echo "FAIL(A): сработал WEDGE-детектор (ложный?)"; FAIL=1; }
# pr < loop хотя бы в одном окне (present реже циклов)
PRLOOP=$(grep -oE "loop=[0-9]+ pr=[0-9]+" "$LOGA" | awk '{gsub(/loop=|pr=/,""); if ($1 > $2 + 10) c++} END{print c+0}')
[ "$PRLOOP" -ge 1 ] || { echo "FAIL(A): ни одного окна с loop>pr+10"; FAIL=1; }

echo "=== Фаза B: NOJME_PRESENT_ONDEMAND=0 (откат) ==="
LOGB=$(run_case 0)
[ -s "$LOGB" ] || { echo "FAIL(B): log.txt пуст"; exit 1; }
echo "-- diag-окна (loop/pr/pd) --"
grep -oE "loop=[0-9]+ pr=[0-9]+|pd=[0-9]+" "$LOGB" | paste - - 2>/dev/null | head -6
echo
# при отключённом on-demand: pd=0 везде, pr == loop
PDZ=$(grep -oE "pd=[0-9]+" "$LOGB" | grep -vc "pd=0" || true)
[ "${PDZ:-0}" = "0" ] || { echo "FAIL(B): pd ненулевой при ONDEMAND=0"; FAIL=1; }
SAME=$(grep -oE "loop=[0-9]+ pr=[0-9]+" "$LOGB" | awk '{gsub(/loop=|pr=/,""); if ($1 == $2) c++} END{print c+0}')
ALLW=$(grep -coE "loop=[0-9]+ pr=[0-9]+" "$LOGB" || echo 0)
[ "$ALLW" -ge 1 ] && [ "$SAME" = "$ALLW" ] || { echo "FAIL(B): не во всех окнах pr==loop ($SAME/$ALLW)"; FAIL=1; }
# контент доезжает и в режиме отката
LATEB=$(grep -oE "chg=[0-9]+" "$LOGB" | tail -4 | grep -c "chg=[1-9]")
[ "$LATEB" -ge 2 ] || { echo "FAIL(B): поздние окна без chg>=1"; FAIL=1; }

if [ "$FAIL" = "0" ]; then
    echo "ONDEMAND: ALL CHECKS PASSED"
else
    echo "ONDEMAND: FAILED"
fi
exit "$FAIL"
