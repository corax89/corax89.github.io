/* v36.63 [SPIN-BREAK-PAUSE-FRESH] selftest: детерминированное воспроизве-
 * дение ложного срабатывания спин-брейкера по закрытию меню паузы.
 * Сценарий (драйвер NOJME_FRONT_KEYS): MINUS (пауза эмулятора 2.5 с —
 * дольше порога NOJME_SPIN_BREAK_MS=1500), B (продолжить), A (нажатие
 * в игру). paint() начинается с чисто-Java преамбулы без единого
 * натива — первый slow-check (каждые 64 инструкции) случается ещё до
 * drawString и ДО фикса видел возраст, накопленный за всё время меню:
 * [SPIN-BREAK] вбрасывал RuntimeException в живой кадр. ДО фикса:
 * SP:SPINBREAK-CAUGHT в SYSOUT + [SPIN-BREAK] в логе. ПОСЛЕ фикса:
 * ни одного выстрела, кадры (SP:PAINTED-N) продолжают расти ПОСЛЕ
 * нажатия A (маркер SP:key — игра жива после закрытия меню).
 * Фоновый поток со sleep(50)-циклом имитирует игровой поток SCC:
 * после паузы не должен ловить ложный выстрел на выходе sleep-парка. */
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class SpinPauseTest extends MIDlet {
    static int frames = 0;

    public SpinPauseTest() { System.out.println("SP:ctor"); }

    public void startApp() {
        final Canvas c = new Canvas() {
            protected void paint(Graphics g) {
                /* чисто-Java преамбула: ~2-3 тыс. инструкций без нативов.
                 * До фикса именно здесь первый slow-check после закрытия
                 * меню ловил ложный возраст (длительность меню). */
                long sink = frames + 7;
                for (int i = 0; i < 300; i++) {
                    sink = sink * 1103515245L + 12345L + i;
                    sink ^= sink >> 3;
                }
                try {
                    if (sink == 42L) System.out.println("SP:impossible");
                    g.setColor(0, 0, 0);
                    g.fillRect(0, 0, getWidth(), getHeight());
                    g.setColor(80, 255, 80);
                    g.drawString("frame " + frames, 10, 10, 0);
                    frames++;
                    if (frames % 30 == 0) System.out.println("SP:PAINTED-" + frames);
                    repaint(); /* следующий кадр сразу — цикл живёт сам */
                } catch (RuntimeException e) {
                    System.out.println("SP:SPINBREAK-CAUGHT: " + e.getMessage());
                    repaint();
                }
            }
            protected void keyPressed(int k) { System.out.println("SP:key " + k); }
        };
        Display.getDisplay(this).setCurrent(c);
        /* t2: игровой поток SCC-класса — sleep-цикл с коротким байткодом.
         * Выходит из sleep-парка ПОСЛЕ закрытия меню и не должен получить
         * ложный возраст (native.c обновляет возраст на выходе парка). */
        new Thread(new Runnable() {
            public void run() {
                System.out.println("SP:thread-start");
                long sink = 0;
                while (true) {
                    try { Thread.sleep(50); } catch (Exception e) { return; }
                    sink += 1;
                    if (sink == 123456789L) System.out.println("SP:impossible2");
                }
            }
        }).start();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
