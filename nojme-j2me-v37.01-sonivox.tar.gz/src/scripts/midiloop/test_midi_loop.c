/*
 * [MIDI-LOOP-FIX] v36.95 — e2e regression test for looped MIDI playback.
 *
 * Bug: EAS_Render() keeps returning EAS_SUCCESS with a full sample buffer
 * after an SMF file reaches its end (silence + voice tails). nojme's only
 * EOF check sat inside the "r != EAS_SUCCESS || generated <= 0" branch,
 * which never fires at a normal end of file. Result: sequencer->playing
 * stayed true forever, mix_midi_player's loop-restart branch was dead
 * code, and EVERY game with setLoopCount(-1) MIDI music (Brick Breaker
 * Revolution 3D and friends) faded into permanent silence after the
 * first pass. END_OF_MEDIA for non-looping players was equally dead.
 *
 * This test replicates the mixer driver (media.c mix_midi_player) byte
 * for byte and asserts:
 *   phase 1  setLoopCount(-1): track restarts (~0.5 s SMF), audio stays
 *            non-silent in the LAST second of a 4 s run
 *            (pre-fix: 0 restarts, last second pure silence)
 *   phase 2  no loop: playing=false + end_reached=true at EOF
 *            (the END_OF_MEDIA trigger; pre-fix: never happens)
 *   phase 3  setLoopCount(2): player-level accounting stops after
 *            exactly 2 passes (mixer loops_remaining logic)
 *
 * Build: see scripts/midiloop/build.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#include "midi.h"

/* ------------------------------------------------------------------
 * Tiny in-memory SMF: format 0, division 480, tempo 120 (500000 us),
 * one track: NoteOn(60,100) @0, NoteOff(60) @+480 ticks -> 0.5 s.
 * ------------------------------------------------------------------ */
static uint8_t* make_test_midi(uint32_t* out_size) {
    static const uint8_t header[14] = {
        'M','T','h','d', 0,0,0,6, 0,0, 0,1, 0x01,0xE0 /* 480 */
    };
    static const uint8_t tempo_ev[] = {
        0x00, 0xFF,0x51,0x03, 0x07,0xA1,0x20   /* 500000 us/qn = 120 BPM */
    };
    static const uint8_t note_ev[] = {
        0x00, 0x90,60,100,                      /* note on  */
        0x83,0x60, 0x80,60,0,                   /* +480 ticks, note off */
        0x00, 0xFF,0x2F,0x00                    /* end of track */
    };
    uint32_t track_len = (uint32_t)(sizeof(tempo_ev) + sizeof(note_ev));
    uint32_t total = 14 + 8 + track_len;
    uint8_t* buf = malloc(total);
    uint8_t* p = buf;
    memcpy(p, header, 14); p += 14;
    *p++ = 'M'; *p++ = 'T'; *p++ = 'r'; *p++ = 'k';
    *p++ = (uint8_t)(track_len >> 24); *p++ = (uint8_t)(track_len >> 16);
    *p++ = (uint8_t)(track_len >> 8);  *p++ = (uint8_t)track_len;
    memcpy(p, tempo_ev, sizeof(tempo_ev)); p += sizeof(tempo_ev);
    memcpy(p, note_ev, sizeof(note_ev));   p += sizeof(note_ev);
    *out_size = total;
    return buf;
}

/* ------------------------------------------------------------------
 * Mixer driver replica: same sample chunk (221), same advance/generate/
 * restart sequence as media.c audio thread + mix_midi_player.
 * loop_count: -1 = infinite, 2 = finite, 1 = no loop.
 * ------------------------------------------------------------------ */
typedef struct {
    int restarts;          /* mixer loop restarts */
    int eof_events;        /* END_OF_MEDIA pushes (incl. final stop) */
    int stopped;           /* player-level stop reached */
} mixer_stats_t;

static void run_mixer(MidiFile* midi, double seconds, int loop_count,
                      mixer_stats_t* st,
                      double* rms_last_sec, double* rms_all) {
    const int samples_per_cycle = 44100 / 200 + 1;   /* 221, media.c */
    const int cycles = (int)(seconds * 200.0);
    const int last_sec_start = cycles - 200;         /* final 1 s window */
    int16_t* buf = malloc((size_t)samples_per_cycle * 2 * sizeof(int16_t));

    int loops_remaining = loop_count;
    double sum2_all = 0.0, sum2_last = 0.0;
    uint64_t n_all = 0, n_last = 0;   /* cycles, not samples */

    st->restarts = 0; st->eof_events = 0; st->stopped = 0;

    for (int c = 0; c < cycles; c++) {
        memset(buf, 0, (size_t)samples_per_cycle * 2 * sizeof(int16_t));

        /* --- media.c mix_midi_player (verbatim policy) --- */
        if (midi->sequencer->playing) {
            uint64_t audio_us =
                (uint64_t)samples_per_cycle * 1000000ULL / 44100;
            midi_advance_time(midi, audio_us);   /* no-op with sonivox */
        }
        midi_generate_samples(midi, buf, samples_per_cycle);

        double w = 0.0;
        for (int i = 0; i < samples_per_cycle * 2; i++) {
            double s = buf[i];
            w += s * s;
        }
        sum2_all += w; n_all += 1;
        if (c >= last_sec_start) {
            sum2_last += w; n_last += 1;
        }

        if (!midi->sequencer->playing) {
            if (loop_count != 1) {
                midi_play(midi);   /* loop restart (or restart-then-stop) */
                st->restarts++;
                if (loop_count > 0) {
                    loops_remaining--;
                    if (loops_remaining <= 0) {
                        st->stopped = 1;
                        st->eof_events++;
                        break;
                    }
                }
            } else {
                /* non-loop: mixer stops the player, pushes END_OF_MEDIA
                 * when the sequencer itself ran through */
                if (midi->sequencer->end_reached) {
                    midi->sequencer->end_reached = false;
                    st->eof_events++;
                }
                st->stopped = 1;
                break;
            }
        }
    }

    if (rms_all)      *rms_all      = n_all  ? sqrt(sum2_all / (double)n_all)  : 0.0;
    if (rms_last_sec) *rms_last_sec = n_last ? sqrt(sum2_last / (double)n_last) : 0.0;
    free(buf);
}

static uint8_t* read_file(const char* path, uint32_t* size) {
    FILE* f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t* buf = malloc(len);
    if (fread(buf, 1, len, f) != (size_t)len) { fclose(f); free(buf); return NULL; }
    fclose(f);
    *size = (uint32_t)len;
    return buf;
}

/* Real-file mode: test_midi_loop <file.mid>
 * Infinite-loop policy on a real game track: run for
 * 3 x duration + 1.5 s, require >= 2 restarts and non-silent tail. */
static int test_real_file(const char* path) {
    midi_init(44100);
    uint32_t size = 0;
    uint8_t* data = read_file(path, &size);
    if (!data) { fprintf(stderr, "cannot read %s\n", path); return 1; }
    MidiFile* midi = midi_load(data, size);
    if (!midi) { fprintf(stderr, "midi_load failed for %s\n", path); return 1; }
    unsigned dur = midi_get_duration_ms(midi);
    printf("=== real file %s (%u bytes, %u ms) ===\n", path, size, dur);
    midi_set_loop(midi, true);
    midi_play(midi);
    double seconds = (double)dur / 1000.0 * 3.0 + 1.5;
    mixer_stats_t st;
    double rms_last = 0.0;
    run_mixer(midi, seconds, -1, &st, &rms_last, NULL);
    printf("  run=%.1fs restarts=%d rms_last1s=%.1f playing=%d\n",
           seconds, st.restarts, rms_last,
           midi->sequencer->playing ? 1 : 0);
    int ok = (st.restarts >= 2) && (rms_last > 200.0);
    printf("  %s: real-file infinite loop\n", ok ? "PASS" : "FAIL");
    midi_free(midi);
    free(data);
    return ok ? 0 : 1;
}

static int failures = 0;
#define CHECK(cond, msg) do { \
    if (cond) printf("  PASS: %s\n", msg); \
    else { printf("  FAIL: %s\n", msg); failures++; } \
} while (0)

int main(int argc, char** argv) {
    if (argc > 1) return test_real_file(argv[1]);
    printf("=== [MIDI-LOOP-FIX] test_midi_loop ===\n");
    midi_init(44100);

    /* ---------------- phase 1: infinite loop ---------------- */
    {
        uint32_t size = 0;
        uint8_t* data = make_test_midi(&size);
        MidiFile* midi = midi_load(data, size);
        CHECK(midi != NULL, "midi_load parses the test SMF");
        if (!midi) return 1;
        printf("  duration: %u ms\n",
               (unsigned)midi_get_duration_ms(midi));

        midi_set_loop(midi, true);   /* media.c start(): looping=true  */
        midi_play(midi);

        mixer_stats_t st;
        double rms_last = 0.0, rms_all = 0.0;
        run_mixer(midi, 4.0, -1, &st, &rms_last, &rms_all);
        printf("  phase1: restarts=%d rms_all=%.1f rms_last1s=%.1f\n",
               st.restarts, rms_all, rms_last);

        CHECK(st.restarts >= 5,
              "infinite loop: mixer restarted the track (>=5 in 4 s)");
        CHECK(rms_last > 200.0,
              "infinite loop: LAST second of audio is NOT silence");
        midi_free(midi);
        free(data);
    }

    /* ---------------- phase 2: no loop ---------------- */
    {
        uint32_t size = 0;
        uint8_t* data = make_test_midi(&size);
        MidiFile* midi = midi_load(data, size);
        if (!midi) return 1;
        midi_set_loop(midi, false);
        midi_play(midi);

        mixer_stats_t st;
        run_mixer(midi, 1.5, 1, &st, NULL, NULL);
        printf("  phase2: stopped=%d eof_events=%d playing=%d\n",
               st.stopped, st.eof_events, midi->sequencer->playing ? 1 : 0);

        CHECK(st.stopped == 1, "no-loop: player stopped at EOF");
        CHECK(st.eof_events == 1,
              "no-loop: END_OF_MEDIA event would fire exactly once");
        CHECK(midi->sequencer->playing == false,
              "no-loop: sequencer playing=false after EOF");
        midi_free(midi);
        free(data);
    }

    /* ---------------- phase 3: setLoopCount(2) ---------------- */
    {
        uint32_t size = 0;
        uint8_t* data = make_test_midi(&size);
        MidiFile* midi = midi_load(data, size);
        if (!midi) return 1;
        midi_set_loop(midi, true);
        midi_play(midi);

        mixer_stats_t st;
        double rms_last = 0.0;
        run_mixer(midi, 4.0, 2, &st, &rms_last, NULL);
        printf("  phase3: restarts=%d stopped=%d eof_events=%d\n",
               st.restarts, st.stopped, st.eof_events);

        CHECK(st.restarts == 2, "loopCount=2: exactly 2 restarts");
        CHECK(st.stopped == 1, "loopCount=2: player stopped after 2 passes");
        CHECK(st.eof_events == 1,
              "loopCount=2: END_OF_MEDIA fired once at final stop");
        midi_free(midi);
        free(data);
    }

    printf("=== %s (%d failure%s) ===\n",
           failures ? "FAILED" : "PASSED", failures, failures == 1 ? "" : "s");
    return failures ? 1 : 0;
}
