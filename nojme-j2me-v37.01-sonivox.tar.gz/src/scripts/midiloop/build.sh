#!/bin/bash
# Build + run the [MIDI-LOOP-FIX] e2e test against the nojme tree.
# Usage: scripts/midiloop/build.sh [path-to-tree]
set -e
TREE="${1:-$(cd "$(dirname "$0")/../.." && pwd)}"
cd "$TREE"
OUT=/tmp/test_midi_loop
DEFS="-D NUM_OUTPUT_CHANNELS=2 -D _SAMPLE_RATE_22050 -D MAX_SYNTH_VOICES=32 \
      -D EAS_WT_SYNTH -D _8_BIT_SAMPLES -D _FILTER_ENABLED -D _REVERB_ENABLED \
      -D DLS_SYNTHESIZER -D JET_INTERFACE -D _IMELODY_PARSER -D _RTTTL_PARSER \
      -D _OTA_PARSER -D _XMF_PARSER -D _NO_DEBUG_PREPROCESSOR"
gcc -O1 -g -fno-omit-frame-pointer $DEFS \
    -include stdbool.h \
    -Wno-unused-parameter -Wno-stringop-truncation \
    -I include \
    -I src/include \
    -I src/midi/sonivox/include \
    -I src/midi/sonivox/host_src \
    -I src/midi/sonivox/lib_src \
    scripts/midiloop/test_midi_loop.c \
    src/midi/midi.c \
    src/jvm/debug_var.c \
    src/midi/sonivox/lib_src/*.c \
    src/midi/sonivox/host_src/eas_config.c \
    src/midi/sonivox/host_src/eas_report.c \
    src/midi/sonivox/eas_host_nojme.c \
    -lm -lpthread -o "$OUT" 2>&1
"$OUT"
