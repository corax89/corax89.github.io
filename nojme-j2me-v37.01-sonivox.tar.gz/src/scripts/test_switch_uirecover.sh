#!/bin/bash
# test_switch_uirecover.sh — v36.77 [UI-PRESENT-GUARD]: проверка
# самовосстановления ui-текстуры меню. Песочный крючок
# NOJME_UI_PRESENT_FAIL=2 имитирует два отказа аплоада подряд (первый и
# второй вызов ui_present) — guard обязан:
#   1) посчитать отказы ([UI-PRESENT-FAIL] с uipf>0 или молча),
#   2) пересоздать g_ui_tex ([UI-RECOVER] ui texture recreated),
#   3) повторить кадр в свежую текстуру — приложение продолжает жить,
#   4) полный e2e-сценарий (меню -> игра -> меню -> выход) не ломается.
set -u
cd "$(dirname "$0")/.." || exit 1
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (сначала make switchui-verify)"; exit 1; }

D=/tmp/sw_uirecover
rm -rf "$D"
mkdir -p "$D/roms/sub"
cp scripts/testdosw/TestDosWrite.jar "$D/roms/sub/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,EXIT:6000"
# СИМУЛЯЦИЯ: первые 2 ui_present — «отказ аплоада» (битая текстура),
# дальше реальные вызовы SDL (текстура уже пересоздана guard'ом).
export NOJME_UI_PRESENT_FAIL=2

( cd "$D" && timeout 60 "$BIN" > out.log 2> err.log )
rc=$?
echo "exit code: $rc (want 0)"

FAIL=0
[ "$rc" = "0" ] || { echo "FAIL: нештатный выход rc=$rc"; FAIL=1; }
# 1) guard сработал и пересоздал текстуру
if ! grep -q "\[UI-RECOVER\] ui texture recreated" "$D/err.log" "$D/log.txt" 2>/dev/null; then
    echo "FAIL: нет [UI-RECOVER] ui texture recreated"; FAIL=1
fi
# 2) отказы посчитаны
if ! grep -q "\[UI-PRESENT-FAIL\]" "$D/err.log" "$D/log.txt" 2>/dev/null; then
    echo "FAIL: нет [UI-PRESENT-FAIL] (отказы не посчитаны)"; FAIL=1
fi
# 3) e2e не сломан восстановлением
grep -q "TDW:DONE ALL DOS CHECKS PASSED" "$D/err.log" || { echo "FAIL: игра не выполнилась"; FAIL=1; }
grep -q "session complete — back to menu" "$D/err.log" || { echo "FAIL: нет возврата в меню"; FAIL=1; }
grep -q "menu session end (result=0)" "$D/err.log" || { echo "FAIL: приложение не вышло из меню"; FAIL=1; }
# 4) после пересоздания отказов больше нет (симуляция конечна — но
#    проверяем, что поздние present'ы не падали: строк RECOVER не
#    больше числа симулированных отказов + разумного запаса).
#    v36.81: считаем ТОЛЬКО log.txt (err.log дублирует те же события
#    с префиксом [TRACE] — прежний двойной счёт упирался в бюджет 4);
#    +1 легитимное пересоздание на каждую игровую сессию прибавил
#    [EXIT-FRESH] «menu entry» (свежая ui-текстура на входе в меню).
SESSIONS=$(grep -ac "game: session end" "$D/log.txt" 2>/dev/null || true)
NREC=$(grep -c "\[UI-RECOVER\] ui texture recreated" "$D/log.txt" 2>/dev/null || true)
echo "UI-RECOVER всего (log.txt): ${NREC:-0}; игровых сессий: ${SESSIONS:-0}"
[ "${NREC:-0}" -le $((4 + ${SESSIONS:-0})) ] || { echo "FAIL: слишком много пересозданий ($NREC) — реальный клин?"; FAIL=1; }

echo
echo "== [UI-PRESENT-FAIL]/[UI-RECOVER] строки =="
grep -h "UI-PRESENT-FAIL\|UI-RECOVER" "$D/err.log" "$D/log.txt" 2>/dev/null | head -6

if [ "$FAIL" = "0" ]; then
    echo "UIRECOVER: ALL CHECKS PASSED"
else
    echo "UIRECOVER: FAILED"; tail -20 "$D/err.log"
fi
exit "$FAIL"
