#!/bin/bash
# v36.98 [NATIVE-NOTE-FRESH]+[SPIN-BREAK-PAINT] e2e: TestFenceSlow.jar.
# paint() главного потока крутит чисто-Java busy-wait (реальная работа),
# воркер жив, но тикает РЕДКИМИ нативами (Thread.sleep(120) — полевая
# форма Gameloft-загрузки: циклы serviceRepaints с 250-мс нанослипами
# ВНУТРИ натива диспетчеризациями не считаются). Флаг встаёт на ~4 с:
# больше базового порога брейкера (1.5 с), меньше sibling-порога (12 с).
#
# ДВА прогона:
#   1) дефолт          — фикс должен держать ОБОИ пояса;
#   2) NOJME_SPIN_BREAK_PAINT=0 — пояс paint-гарда ВЫКЛЮЧЕН: выживание
#      держит ТОЛЬКО sibling-правило (штамп last_native_ms должен быть
#      честным на каждый вызов — это и есть регресс-тест v36.97 баги).
# PASS (оба): TFS:WAIT-OK, TFS:SURVIVED-ALL, НИ ОДНОГО [SPIN-BREAK].
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tfs
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/fencejar/TestFenceSlow.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
# ТУРБО-дилатация снов раннера (v36.85: /4) сжимает таймлайн воркера в 4 раза
# и на хосте флаг встаёт раньше порога брейкера — выключаем ради полевой формы.
export NOJME_TURBO_SLEEP_DIV=0
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:600,EXIT:20000"

rc=0
for pass in default nopaintguard; do
    P="$D/$pass"; mkdir -p "$P"
    if [ "$pass" = "nopaintguard" ]; then
        export NOJME_SPIN_BREAK_PAINT=0
    else
        unset NOJME_SPIN_BREAK_PAINT
    fi
    timeout -k 5 40 ./bin/switchui-verify > "$P/out.log" 2> "$P/err.log" || true
    ok=1
    grep -aq "TFS:WAIT-OK" "$P/err.log" || { echo "[$pass] FAIL: нет TFS:WAIT-OK (загрузка убита)"; ok=0; }
    grep -aq "TFS:WAIT-DEAD" "$P/err.log" && { echo "[$pass] FAIL: TFS:WAIT-DEAD"; ok=0; }
    grep -aq "TFS:SURVIVED-ALL" "$P/err.log" || { echo "[$pass] FAIL: нет TFS:SURVIVED-ALL"; ok=0; }
    n_break=$(grep -ac "SPIN-BREAK\]" "$P/err.log")
    [ "$n_break" -eq 0 ] || { echo "[$pass] FAIL: SPIN-BREAK сработал $n_break раз ( sibling/paint-гард не держат)"; ok=0; }
    grep -aq "TFS:flag-set" "$P/err.log" || { echo "[$pass] FAIL: нет TFS:flag-set (воркер не жил)"; ok=0; }
    echo "[$pass] WAIT-OK: $(grep -ac 'TFS:WAIT-OK' "$P/err.log"); $(grep -ao 'TFS:SURVIVED-ALL frames=[0-9]*' "$P/err.log" | head -1); SPIN-BREAK: $n_break"
    grep -a "TFS:\|SPIN-BREAK\]\|paint() threw" "$P/err.log" | head -8
    if [ $ok -eq 1 ]; then echo "[$pass] FENCESLOW E2E: PASSED"; else echo "[$pass] FENCESLOW E2E: FAILED"; rc=1; fi
done
[ $rc -eq 0 ] && echo "FENCESLOW E2E: ALL CHECKS PASSED" || echo "FENCESLOW E2E: FAILED"
exit $rc
