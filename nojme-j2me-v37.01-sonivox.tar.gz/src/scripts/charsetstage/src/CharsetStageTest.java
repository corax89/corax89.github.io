import javax.microedition.midlet.MIDlet;

/* v36.53 [LENIENT-UTF8] E2E (восстановлен в v36.62): декодирование
 * байтов через new String(byte[],int,int) с ПЛАТФОРМЕННЫМ дефолтом
 * (UTF-8) — путь, которым Doom RPG [Rus] строит строки из побайтового
 * шифра-заменителя (d.a: new String(a, 0, s2)).
 * Ожидаемые SYSOUT-строки:
 *   CS:103,111,192,235,252,33,65,   — осиротевшие lead 0xC0/0xEB/0xFC
 *                                     проходят сквозным widening (ДО
 *                                     фикса: 65533 = U+FFFD, буквы
 *                                     «пропадали» — глиф-атлас их не
 *                                     имеет);
 *   CS2:0,120                       — C0 80 -> U+0000 (modified UTF-8)
 *                                     не тронуто;
 *   CS3:1055,113                    — валидный UTF-8 (D0 9F = U+041F)
 *                                     не тронуто;
 *   CHARSETSTAGE:DONE */
public class CharsetStageTest extends MIDlet {

    static String codes(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0) sb.append(',');
            sb.append((int) s.charAt(i));
        }
        return sb.toString();
    }

    public void startApp() {
        /* паттерн шифра Doom RPG: одиночные байты 0xC0-0xFC без
         * continuation (атлас: 0xC0=В, 0xEB=Л, 0xFC=слот) */
        byte[] b = { 'g', 'o', (byte) 0xC0, (byte) 0xEB, (byte) 0xFC, '!', 'A' };
        System.out.println("CS:" + codes(new String(b, 0, b.length)));

        /* C0 80 -> U+0000 (modified UTF-8) — поведение сохранено */
        byte[] m = { (byte) 0xC0, (byte) 0x80, 'x' };
        System.out.println("CS2:" + codes(new String(m, 0, 3)));

        /* валидный 2-байтовый UTF-8 (U+041F «П») — не тронут */
        byte[] v = { (byte) 0xD0, (byte) 0x9F, 'q' };
        System.out.println("CS3:" + codes(new String(v, 0, 3)));

        System.out.println("CHARSETSTAGE:DONE");
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }
}
