#!/bin/bash
# Воспроизведение зависания загрузки Zombie Infection [240x320] на хостовой verify-сборке.
# Ключевая последовательность зеркарит полевой лог corax89 (2026-10-05):
#   игра: A@~1.9с, softL@+0.6, A@+5.5, softL@+1.7, softL@+1.0, softL@+0.8, softR@+3.7 → загрузка уровня → спин.
# Аргументы: $1 = суффикс прогона; RUN_SECONDS, NOJME_SPIN_BREAK_MS — снаружи.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/zombie_repro_${1:-base}
rm -rf "$D"; mkdir -p "$D/roms"
cp "/home/z/my-project/zi/zombie_ext/Zombie Infection [240x320] (SonyEricsson K800i [1MB]) (andrew-lviv.net).jar" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SCHED_TRACE=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
# Меню: A (браузер), A (запуск jar)
export NOJME_SWITCH_KEYS="A:400,A:600"
# Игра: A ~2c после старта, софт-клавиши — TAP-ы в поля (лево x=100, право x=1150, y=360)
FRONT="A:2000"
FRONT="$FRONT,TAP:100,360:600"
FRONT="$FRONT,A:5500"
FRONT="$FRONT,TAP:100,360:1700"
FRONT="$FRONT,TAP:100,360:1000"
FRONT="$FRONT,TAP:100,360:900"
FRONT="$FRONT,TAP:1150,360:3700"
# Катсцена: "PRESS ANY KEY" — пролистываем страницы
for i in $(seq 1 24); do FRONT="$FRONT,A:1500"; done
export NOJME_FRONT_KEYS="$FRONT"

RUN_SECONDS=${RUN_SECONDS:-90}
timeout -k 5 "$RUN_SECONDS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit=$rc"
echo "===keys==="
grep -aE "KEYIN.*dispatch|FRONTKEYS|margin tap|autotest key" "$D/err.log" | head -30
echo "=== freeze signatures ==="
grep -an "SPIN-BREAK\|PAINT-BUDGET\|MON-WAIT\|STUCK:\|MIDLET-STUCK\|THREAD-EXIT" "$D/err.log" | head -20
echo "=== resources ==="
grep -aE "RESOURCE" "$D/err.log" | tail -25
echo "=== session ==="
grep -an "game: begin\|game: session end\|midlet: start" "$D/err.log" | head -8
echo "=== лог: $D/err.log ==="
