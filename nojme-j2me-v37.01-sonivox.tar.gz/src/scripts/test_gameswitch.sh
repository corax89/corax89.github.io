#!/bin/bash
# v37.01 [RMS-GAME-SWITCH]: E2E смена игры в ОДНОМ процессе (Switch-фронтенд:
# игра A -> меню -> игра B). Проверяется, что таблица сторов RAM сбрасывается
# при смене имени игры ([RMS-GAME-SWITCH] в логе), вторая игра сохраняется
# штатно и процесс не падает. Игры: TestRMSG (стор TSG) затем TestRMSZ
# (сторы TZ1..TZ5 — в т.ч. заранее подготовленный зомби TZ1).
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_gameswitch
rm -rf "$D"; mkdir -p "$D/roms/sub" "$D/rms"
cp scripts/testrmsg/TestRMSG.jar scripts/testrmsz/TestRMSZ.jar "$D/roms/sub/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
printf 'saves_dir=%s\n' "$D/rms" > "$D/switchui_settings.ini"

# зомби-стор для второй игры (проверка: хил после смены игры работает)
python3 scripts/make_zombie_rms.py "$D/rms/TestRMSZ" >/dev/null || { echo "GAMESWITCH: FAIL — сторы"; exit 1; }

# Сценарий (TestRMSG завершается мгновенно и возвращает браузер в корень):
#   A1: вход в sub; A2: запуск TestRMSG (1-я игра, стор TSG);
#   A3: повторный вход в sub; DOWN: курсор на TestRMSZ; A4: запуск (2-я
#   игра — смена контекста => [RMS-GAME-SWITCH], зомби TZ1 => [RMS-HEAL]);
#   EXIT: закрыть приложение.
KEYS="A:600,A:600,A:9000,A:800,DOWN:800,A:600,DOWN:800,A:600,EXIT:20000"
env NOJME_SWITCH_KEYS="$KEYS" timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?

fail() { echo "GAMESWITCH: FAIL — $*"; echo "GAMESWITCH: FAILED"; exit 1; }
[ "$rc" = "0" ] || { echo "--- err tail:"; tail -12 "$D/err.log"; fail "rc=$rc"; }

grep -aqi "segfault\|SIGSEGV" "$D/err.log" && fail "краш"

# обе игры запустились
grep -aq "TSG:PERSIST" "$D/err.log" || fail "игра A (TestRMSG) не запускалась"
grep -aq "RZ:DONE" "$D/err.log" || fail "игра B (TestRMSZ) не запускалась"

# ГЛАВНОЕ: смена контекста при запуске второй игры
grep -aq "\[RMS-GAME-SWITCH\].*game='TestRMSZ'" "$D/err.log" || fail "нет [RMS-GAME-SWITCH] на TestRMSZ"
grep -a "\[RMS-GAME-SWITCH\]" "$D/err.log" | head -2

# хил зомби после смены игры по-прежнему работает
grep -aq "\[RMS-HEAL\].*TZ1" "$D/err.log" || fail "зомби TZ1 не вылечен после смены игры"

# сохранения второй игры доехали до диска (BT-идиома работает)
grep -aq "RZ:Z1-RELOAD PASS" "$D/err.log" || fail "идиома id-1 не работает в игре B"

echo "GAMESWITCH: ALL CHECKS PASSED (смена игры сбрасывает таблицу сторов, сейвы целы)"
