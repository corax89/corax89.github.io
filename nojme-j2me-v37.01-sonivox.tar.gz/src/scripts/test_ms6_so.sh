#!/bin/bash
# MS6-репро: запуск Metal Slug 6 (I-Play) с медиа-логом, аудит аудио-пути.
set -u
cd "$(dirname "$0")/.." || exit 1
# Производный jar: как в AB + патч at.class bM(I)Z -> return true
# (гейт «звук включён», scripts/patch_at_bm.py) — проверка ПОЛНОГО пути
# запуска: createPlayer -> Player.start -> реальное микширование.
BASE="${MS6_JAR:-scripts/ms6stage/Metal Slug 6 (I-Play)(1.0.1).jar}"
[ -f "$BASE" ] || { echo "SKIP: нет $BASE"; exit 0; }
JAR=/tmp/ms6_sound_on.jar
rm -rf /tmp/ms6mkso && mkdir -p /tmp/ms6mkso
unzip -q -o "$BASE" ding.mid at.class -d /tmp/ms6mkso
cp /tmp/ms6mkso/ding.mid /tmp/ms6mkso/musicStageSelect.mid
cp /tmp/ms6mkso/ding.mid /tmp/ms6mkso/musicStage1.mid
cp scripts/testaudio/res/t1.wav /tmp/ms6mkso/sfxMenuSelect.wav
python3 scripts/patch_at_bm.py /tmp/ms6mkso/at.class /tmp/ms6mkso/at.class
rm -f "$JAR"
cp "$BASE" "$JAR"
( cd /tmp/ms6mkso && zip -q "$JAR" musicStageSelect.mid musicStage1.mid sfxMenuSelect.wav at.class )
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/tms6so
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/ms6so.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=on
vm_speed=normal
logging=on
EOF
cat > "$D/sdmc:/switch/j2me/pergame/ms6so.jar.ini" <<'EOF'
res=240x320
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_MEDIA_DEBUG=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
# Прогрев + меню-навигация: A (старт/выбор), задержки, чтобы игра успела
# пройти заставки и попытаться играть звук/музыку.
export NOJME_SWITCH_KEYS="A:90000"
export NOJME_FRONT_KEYS="A:6000,A:6000,A:6000,A:8000,A:6000,A:8000,A:6000,A:8000"
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (make switchui-verify)"; exit 1; }
( cd "$D" && timeout -k 10 100 "$BIN" > out.log 2> err.log ) || true

LOG="$D/sdmc:/switch/j2me/log.txt"
ERR="$D/err.log"
[ -s "$LOG" ] || { echo "FAIL: log.txt пуст/отсутствует"; exit 1; }
ok=1
# (1) MIDI-файлы движка загрузились и распарсились
nmidi=$(grep -ac "midi_load size=" "$ERR")
[ "${nmidi:-0}" -ge 2 ] || { echo "FAIL: midi_load = $nmidi (<2)"; ok=0; }
# (2) WAV распарсен
grep -aq "WAV parsed" "$ERR" || { echo "FAIL: нет WAV parsed"; ok=0; }
# (3) плееры реально запущены
nstart=$(grep -ac "MEDIA\] Player.start" "$ERR")
[ "${nstart:-0}" -ge 3 ] || { echo "FAIL: Player.start = $nstart (<3)"; ok=0; }
# (4) синтез идёт: строки микширования с ненулевым peak
nmix=$(grep -ac "MEDIA\] mix id=" "$ERR")
[ "${nmix:-0}" -ge 5 ] || { echo "FAIL: mix-строк = $nmix (<5)"; ok=0; }
peak=$(grep -aoE "peak=[0-9]+" "$ERR" | head -20 | sed 's/peak=//' | sort -n | tail -1)
[ "${peak:-0}" -gt 500 ] || { echo "FAIL: max peak = ${peak:-0} (<=500 — синтез молчит)"; ok=0; }
echo "midi_load=$nmidi Player.start=$nstart mix=$nmix max_peak=$peak"
echo "--- [MEDIA] ключевые строки ---"
grep -a "MEDIA\] midi_load\|MEDIA\] WAV parsed\|MEDIA\] Player.start" "$ERR" | head -8
[ "$ok" = 1 ] && echo "MS6-SOUND-ON: ALL CHECKS PASSED" || { echo "MS6-SOUND-ON: FAILED"; exit 1; }
