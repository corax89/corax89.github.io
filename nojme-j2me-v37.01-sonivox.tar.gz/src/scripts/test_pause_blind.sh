#!/bin/bash
# v36.81 [PAUSE-FALLBACK] автотест: слепое меню паузы.
# (v36.82 [SW-ONLY]: стадия 2 самолечения — полный ребилд рендерера
# software->software; рендерер всегда программный, переключения режимов
# не существует; pergame ini больше НЕ получает render=software.)
# Сценарий (SpinPauseTest.jar, песочница switchui-verify):
#   меню: A -> A (браузер) -> запуск игры;
#   MINUS:6000 — пауза 6 с; NOJME_PAUSE_BLIND_SIM=1 имитирует полевой клин
#   (оверлей в готовый кадр не попадает):
#     проба 1 (t+1 с) -> [PAUSE-BLIND] streak 1 -> CPU-фон;
#     проба 2 (t+2 с) -> [PAUSE-BLIND] x2 -> самолечение WEDGE-стадией 2
#                          (полный ребилд рендерера) прямо из паузы;
#   B:2500 — резюм: игра продолжает работу на пересобранном рендерере
#   (SP:PAINTED-счётчик растёт ПОСЛЕ pause: close);
#   MINUS:1500,DOWN,DOWN,A — вторая пауза (лестница до stage 4) и выход;
#   EXIT:600 (меню) — чистое завершение приложения.
# Проверки:
#   1) rc=0; pause open/close 2/2; 0 STUCK
#   2) [PAUSE-BLIND] >= 3; самолечение из паузы; stage 2 = полный ребилд;
#      [RND-SWITCH] (wedge stage 2)
#   3) игра ЖИВА после резюма (SP:PAINTED между close и вторым open)
#   4) pergame ini этой игры НЕ содержит render= (ключ удалён в v36.82)
#   5) [EXIT-FRESH]: [RND-SWITCH] ... exit-reset (wedge fired this session)
#      + [MENU-FIRST] первого present меню после выхода
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="$PWD/scripts/spinpause/SpinPauseTest.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/sw_pauseblind
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/SpinPauseTest.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=off
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:600"
export NOJME_FRONT_KEYS="MINUS:6000,B:2500,MINUS:1500,DOWN:400,DOWN:400,DOWN:400,A:900"
export NOJME_PAUSE_BLIND_SIM=1
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (сначала scripts/build_verify_host.sh)"; exit 1; }
( cd "$D" && timeout -k 10 60 "$BIN" > out.log 2> err.log )
rc=$?
echo "exit code: $rc (want 0)"
LOG="$D/sdmc:/switch/j2me/log.txt"
ok=1
[ "$rc" = "0" ] || { echo "FAIL: ненулевой rc"; ok=0; }

OPENS=$(grep -acE "^[0-9]+ pause: open" "$LOG" 2>/dev/null || true)
CLOSES=$(grep -acE "^[0-9]+ pause: close" "$LOG" 2>/dev/null || true)
echo "pause open/close: $OPENS/$CLOSES (want 2/2)"
[ "$OPENS" = "2" ] && [ "$CLOSES" = "2" ] || { ok=0; echo "FAIL: паузы"; }

BLIND=$(grep -ac "PAUSE-BLIND" "$LOG" 2>/dev/null || true)
echo "[PAUSE-BLIND] строк: $BLIND (want >=3)"
[ "$BLIND" -ge 3 ] || { ok=0; echo "FAIL: слепота не поймана"; }

grep -q "wedge recovery right from the pause" "$LOG" 2>/dev/null || { ok=0; echo "FAIL: самолечение из паузы не запустилось"; }
# v36.82 [SW-ONLY]: стадия 2 = полный ребилд (рендерер всегда программный)
grep -q "stage 2: full renderer+textures rebuild" "$LOG" 2>/dev/null || { ok=0; echo "FAIL: стадия 2 (полный ребилд) не проведена"; }
grep -qE "\[RND-SWITCH\].*wedge stage 2" "$LOG" 2>/dev/null || { ok=0; echo "FAIL: [RND-SWITCH] переключения нет"; }

# игра жива после резюма: последняя diag-строка игровой сессии несёт fl>0
# (новые кадры доставлялись ПОСЛЕ software-переключения; SYSOUT троттлится
# и в коротком прогоне молчит — fl= честный счётчик за период)
LASTFL=$(awk '/^[0-9]+ diag:/ { if (match($0, /fl=[0-9]+/)) fl = substr($0, RSTART+3, RLENGTH-3) + 0 }
              /game: session end/ { print fl + 0; exit }' "$LOG" 2>/dev/null)
echo "fl= последней diag до session end: $LASTFL (want >=1)"
[ "$LASTFL" -ge 1 ] || { ok=0; echo "FAIL: игра не продолжила красить после ребилда"; }

# v36.82 [SW-ONLY]: pergame ini больше НЕ получает render= (настройки
# «Рендер» не существует; ключ удачно игнорируется, если остался от v36.81)
INI="$D/sdmc:/switch/j2me/pergame/SpinPauseTest.jar.ini"
if [ -f "$INI" ] && grep -q "^render=" "$INI" 2>/dev/null; then
    ok=0; echo "FAIL: render= записан в pergame ini (ключ удалён в v36.82)"; cat "$INI" 2>/dev/null
else
    echo "pergame ini без render=: OK"
fi

grep -qE "\[RND-SWITCH\].*exit-reset \(wedge fired this session\)" "$LOG" 2>/dev/null \
    || { ok=0; echo "FAIL: [EXIT-FRESH] ребилд после клина не проведён"; }
grep -q "MENU-FIRST" "$LOG" 2>/dev/null || { ok=0; echo "FAIL: [MENU-FIRST] бейкона нет"; }

STUCK=$(grep -ac "STUCK" "$LOG" 2>/dev/null || true)
[ "$STUCK" = "0" ] || { ok=0; echo "FAIL: STUCK-строки ($STUCK)"; }

echo "--- ключевые строки:"
grep -E "PAUSE-BLIND|WEDGE-RECOVER|RND-SWITCH|MENU-FIRST" "$LOG" 2>/dev/null | head -14

if [ "$ok" = "1" ]; then echo "ALL PASSED"; else echo "FAILED"; exit 1; fi
