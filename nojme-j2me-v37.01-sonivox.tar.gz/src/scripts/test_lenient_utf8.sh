#!/bin/bash
# v36.53/v36.62 [LENIENT-UTF8] юнит-тест: компилируется против РЕАЛЬНОГО
# src/jvm/charset.c (тот же код, что в NRO). 20 проверок: пасстрю
# осиротевших 2/3/4-байтовых lead, одиночного continuation и lead
# 0xF8-0xFF; валидные последовательности; C0 80 -> U+0000; overlong ->
# U+FFFD; обрезанный хвост; CESU-8; паттерн шифра Doom RPG 1:1;
# max_units-инвариант; ISO-8859-1 и энкодер нетронуты.
set -e
cd "$(dirname "$0")/.." || exit 1
gcc -std=c11 -Wall -Wextra -O1 -Isrc -Isrc/include -Iinclude -Isrc/jvm \
    scripts/test_lenient_utf8.c src/jvm/charset.c -o /tmp/test_lenient_utf8
/tmp/test_lenient_utf8
