import javax.microedition.midlet.MIDlet;

/* v36.101 [FAST-RETURN] proof: long/double/float returns through nested
 * call chains (3-4 deep), exercising the two-slot J/D convention of the
 * inlined LRETURN/DRETURN/FRETURN (low slot canonical, both slots = copy).
 * Deterministic checksums: SUM lines must match the pre-v36.101 values
 * (computed by the cold handlers) — any drift names the fast path. */
public class RetBench extends MIDlet {
    static long l0(long a) { return a + 1; }
    static long l1(long a) { return l0(a) * 3 - l0(a - 1); }
    static long l2(long a) { return l1(a) + l1(a + 2) * 2; }
    static long l3(long a) { return l2(a) ^ l2(a >> 1); }

    static double d0(double a) { return a * 1.5 + 0.25; }
    static double d1(double a) { return d0(a) - d0(a / 3.0); }
    static double d2(double a) { return d1(a) * d1(a + 1.0) + 7.0; }
    static double d3(double a) { return d2(a) / (d2(a / 2.0) + 1.0); }

    static float f0(float a) { return a * 2.5f + 1.5f; }
    static float f1(float a) { return f0(a) - f0(a / 3.0f); }

    static long mix(long a, double d, float f) { return a + (long) d + (long) f; }

    public void startApp() {
        System.out.println("RB start");
        long ls = 0;
        for (int i = 0; i < 200000; i++) ls = l3(ls + i);
        System.out.println("RB SUM-L " + ls);

        double ds = 0.5;
        for (int i = 0; i < 200000; i++) ds = d3(ds + i);
        System.out.println("RB SUM-D " + ds);

        float fs = 0.5f;
        for (int i = 0; i < 200000; i++) fs = f1(fs + i);
        System.out.println("RB SUM-F " + fs);

        long ms = 0;
        for (int i = 0; i < 50000; i++) ms = mix(l1(ms + i), d1(ms + i), f1(ms + i));
        System.out.println("RB SUM-M " + ms);
        System.out.println("RB DONE");
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
