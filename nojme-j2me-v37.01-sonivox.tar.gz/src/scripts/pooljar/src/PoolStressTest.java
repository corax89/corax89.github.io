/* v36.73 [VM-THREADPOOL] selftest: пул воркеров + coop-реап.
 * ФАЗА 1 (churn): 300 последовательных start+join — до фикса coop-таблица
 *   (128 слотов) забивалась трупами pthread-нитей на ~128-й итерации и
 *   Thread.start() молча переставал работать; теперь трупы помечаются
 *   TERMINATED и реапятся. Пул должен остаться на 1 воркере (переисполь-
 *   зование), а не плодить pthread'ы.
 * ФАЗА 2 (burst): 24 ОДНОВРЕМЕННЫХ потока, барьер notifyAll — пул растёт
 *   до нужного размера, все обязаны доработать.
 * ФАЗА 3 (join-семантика): isAlive после join == false, значение из
 *   потока доставлено (память между run() и join видна — JMM happens-
 *   before через join-бродкаст).
 * Финал: POOL-RESULT seq=<n> burst=<n> join=<0|1> fail=<n> — драйвер
 * грепает SYSOUT; любой fail>0 или отсутствие строк = FAIL. */
import javax.microedition.midlet.*;

public class PoolStressTest extends MIDlet {
    static Object burstGate = new Object();
    static int burstDone = 0;
    static int seqFail = 0;
    static int burstFail = 0;
    static int joinFail = 0;
    static int joinedValue = -1;

    static void nap(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { }
    }

    public void startApp() {
        /* ---- ФАЗА 1: 300 последовательных start+join ---- */
        for (int i = 0; i < 300; i++) {
            final int idx = i;
            Thread t = new Thread(new Runnable() {
                public void run() { }
            });
            t.start();
            try { t.join(); } catch (InterruptedException e) { }
            if (t.isAlive()) { seqFail++; }
            if ((idx % 100) == 99) System.out.println("POOL:seq-" + (idx + 1));
        }
        System.out.println("POOL:seq-done fail=" + seqFail +
                " workers=" + System.getProperty("nojme.pool.workers") +
                " idle=" + System.getProperty("nojme.pool.idle"));

        /* ---- ФАЗА 2: 24 одновременных, барьер notifyAll ---- */
        Thread[] ts = new Thread[24];
        for (int i = 0; i < 24; i++) {
            ts[i] = new Thread(new Runnable() {
                public void run() {
                    synchronized (burstGate) {
                        while (burstDone == 0) {
                            try { burstGate.wait(); } catch (InterruptedException e) { return; }
                        }
                    }
                }
            });
            ts[i].start();
        }
        nap(500);   /* дать всем дойти до wait() */
        for (int i = 0; i < 24; i++) {
            if (!ts[i].isAlive()) { burstFail++; }
        }
        synchronized (burstGate) {
            burstDone = 1;
            burstGate.notifyAll();
        }
        for (int i = 0; i < 24; i++) {
            try { ts[i].join(); } catch (InterruptedException e) { }
            if (ts[i].isAlive()) { burstFail++; }
        }
        System.out.println("POOL:burst-done fail=" + burstFail);

        /* ---- ФАЗА 3: join-семантика (видимость памяти) ---- */
        Thread jt = new Thread(new Runnable() {
            public void run() { nap(50); joinedValue = 4242; }
        });
        jt.start();
        try { jt.join(); } catch (InterruptedException e) { }
        if (jt.isAlive() || joinedValue != 4242) joinFail = 1;
        System.out.println("POOL:join-done fail=" + joinFail);

        /* ---- ФАЗА 4: стек-бюджет воркера (2 МБ на Switch) ----
         * Глубокая Java-рекурсия (450 кадров < гварда 500) обязана
         * пройти БЕЗ StackOverflowError — иначе бюджет стека воркера
         * меньше, чем требует интерпретатор (3+ нативных кадра на
         * Java-кадр), и реальная игра с глубокой вложенностью упрётся
         * в guard-страницу раньше гварда. */
        Thread rt = new Thread(new Runnable() {
            public void run() {
                try {
                    int d = recDepth(450);
                    System.out.println("POOL:rec-450 depth=" + d + " (no SOE)");
                } catch (StackOverflowError soe) {
                    System.out.println("POOL:rec-450 CAUGHT StackOverflowError");
                    recFail = 1;
                }
            }
        });
        rt.start();
        try { rt.join(); } catch (InterruptedException e) { }
        System.out.println("POOL:rec-done fail=" + recFail);

        System.out.println("POOL-RESULT seq=300 burst=24 join=" +
                (1 - joinFail) + " fail=" + (seqFail + burstFail + joinFail + recFail));
        notifyDestroyed();
    }

    static int recFail = 0;

    static int recDepth(int n) {
        if (n <= 0) return 0;
        return 1 + recDepth(n - 1);
    }

    public void pauseApp() { }
    public void destroyApp(boolean u) { }
}
