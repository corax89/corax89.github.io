#!/bin/bash
# v36.73 [VM-THREADPOOL] E2E: PoolStressTest на switchui-verify
# (host-сборка с -D__SWITCH__ — реальный путь пула + mprotect-guard).
# Аудит:
#   1) POOL-RESULT: fail=0 (300 churn + 24 burst + join-семантика);
#   2) пул НЕ плодит воркеров на churn: в логе ровно 1 [VMPOOL] shutdown
#      с "joined 1 worker(s)" — 300 последовательных стартов обошлись
#      ОДНИМ воркером (переиспользование доказано);
#   3) coop-реап: [THREADS] Reaped (трупы реапятся до переполнения 128);
#   4) 0 GC-SAFEPOINT-TIMEOUT / 0 ASAN.
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="scripts/pooljar/PoolStressTest.jar"
[ -f "$JAR" ] || bash scripts/pooljar/build.sh

D=/tmp/sw_poolstress
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/rms"
cp "$JAR" "$D/roms/"
cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
export NOJME_RMS_DIR="$D/rms"
export NOJME_SWITCH_KEYS="A:400,A:400,EXIT:9000"
export NOJME_FRONT_KEYS=""

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "== poolstress exit: $rc"

ok=1
ALLG() { grep -ahq "$1" "$D/err.log" "$D/out.log" 2>/dev/null; }

# 1) итоговая строка без отказов
ALLG "POOL-RESULT seq=300 burst=24 join=1 fail=0" || { echo "FAIL: нет POOL-RESULT fail=0"; ok=0; }
ALLG "POOL:seq-done fail=0" || { echo "FAIL: фаза seq (300 churn) с отказами"; ok=0; }
ALLG "POOL:burst-done fail=0" || { echo "FAIL: фаза burst (24) с отказами"; ok=0; }
ALLG "POOL:join-done fail=0" || { echo "FAIL: фаза join с отказами"; ok=0; }

# 2) один воркер на весь churn — переиспользование (пул сообщил об этом
#    САМ через nojme.pool.workers в POOL:seq-done) + shutdown подтвердил
grep -aq "POOL:seq-done fail=0 workers=1 idle=1" "$D/err.log" 2>/dev/null || { echo "FAIL: churn не переиспользовал воркера (ожидали workers=1 после 300 seq)"; ok=0; }
grep -a "VMPOOL" "$D/err.log" 2>/dev/null | head -2

# 3) coop-реап работал (труппы помечались и убирались)
if ! grep -aq "Reaped" "$D/err.log" "$D/out.log" 2>/dev/null; then
    echo "NOTE: Reaped нет (таблица не доходила до 128 — тоже допустимо, но проверь)"
fi

# 4) никаких GC-таймаутов и асан
grep -aq "GC-SAFEPOINT-TIMEOUT" "$D/err.log" 2>/dev/null && { echo "FAIL: GC-SAFEPOINT-TIMEOUT"; ok=0; }
grep -aq "AddressSanitizer" "$D/err.log" 2>/dev/null && { echo "FAIL: ASan"; ok=0; }

[ "$rc" = "0" ] || { echo "FAIL: rc=$rc (ожидали 0)"; ok=0; }

if [ $ok = 1 ]; then echo "POOLSTRESS E2E: ALL PASSED"; else echo "POOLSTRESS E2E: FAILED"; exit 1; fi
