#!/bin/bash
# [BATFIX] v36.41 E2E: настройки — «выход без сохранения НЕ применяет
# изменения» (репорт пользователя: «если выйти без сохранения они все
# равно применяются, только на одну сессию, они не должны применяться»).
#
# Сценарий (NOJME_SWITCH_KEYS, задержки накопительные от старта):
#   DOWN,A       -> экран Настройки
#   DOWN x4 -> «Звук»; A (on->off в РАБОЧЕЙ копии)
#   B            -> выход БЕЗ сохранения ([SET-EXIT]: рабочая копия
#                   откатывается, синглтон не трогается)
#   A            -> повторный вход в настройки (курсор сброшен)
#   DOWN x12 -> «Заряд аккумулятора»; A (не показывать -> значок)
#   DOWN,A на «Сохранить и выйти» -> ФИНАЛЬНЫЙ save
#
# ГЛАВНАЯ проверка: в сохранённом ini audio=on. Старый код применял
# правки из несохранённого выхода к сессии — рабочая копия оставалась
# с audio=off, и финальный «Сохранить» записал бы audio=off. Плюс:
# трассы «settings: exit without save (reverted)» и ровно один
# «settings: save», ini battery=icon, пиксель-тест значка (25%, жёлтая
# заливка + значок) в канве меню.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_setexit
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/uidump"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=on
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_BATTERY_MOCK=25:c
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_UI_DUMP_DIR="$D/uidump"
export NOJME_UI_DUMP_MAX=120
export XDG_DATA_HOME="$D/xdg"
# Хронология (движок: первый токен срабатывает на t~0, задержка = пауза
# ПОСЛЕ нажатия): DOWN@0,A@1200 (настройки) -> 4xDOWN@1900..4000 («Звук»)
# -> A@4700 (audio on->off) -> B@5400 (выход БЕЗ сохранения) -> A@6100
# (повторный вход) -> 12xDOWN@6800..14500 («Заряд аккумулятора», строка 12)
# -> A@15200 (не показывать -> значок) ->
# DOWN@15900 («Сохранить и выйти», строка 13 — v36.48: [KEYHINT-REMOVE]
# убрал строку «Подсказка управления», теперь 13, было 14) ->
# A@16600 (SAVE) -> EXIT@7700.
export NOJME_SWITCH_KEYS="DOWN:1200,A:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,A:700,B:700,A:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,DOWN:700,A:700,DOWN:700,A:700,EXIT:7700"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход)"
ok=1
[ "$rc" = "0" ] || { echo "FAIL: нечистый выход (rc=$rc)"; ok=0; }

ALL="$D/log.txt $D/err.log $D/out.log"

# --- 1) ini: финальный «Сохранить и выйти» записал battery=icon ---
grep -q "^battery=icon$" "$D/switchui_settings.ini" || {
  echo "FAIL: в settings.ini нет battery=icon"; ok=0; }

# --- 2) ГЛАВНОЕ: audio=on — правка из НЕСОХРАНЁННОГО выхода не протекла ---
grep -q "^audio=on$" "$D/switchui_settings.ini" || {
  echo "FAIL: audio=off в ini — несохранённая правка протекла в финальный save (СТАРЫЙ БАГ)"; ok=0; }

# --- 3) трассы выхода/сохранения ---
grep -aq "settings: exit without save (reverted)" "$D/log.txt" || {
  echo "FAIL: нет трассы «settings: exit without save (reverted)»"; ok=0; }
N_SAVE=$(grep -ac "settings: save" "$D/log.txt" 2>/dev/null || echo 0)
[ "$N_SAVE" = "1" ] || {
  echo "FAIL: «settings: save» встречается $N_SAVE раз (ожидался ровно 1)"; ok=0; }

# --- 4) значок заряда в правом верхнем углу канвы меню (значок, 25%) ---
# v36.43 [BATT-DEBOLT]: плашка «значок» без молнии: 48+2*12 = 72 =>
# px=1280-72-16=1192, py=8; корпус начинается на cx=px+12=1204 (рамка
# белая), заливка 25% => 10px жёлтых внутри; белой молнии больше нет.
python3 - "$D/uidump" <<'PYEOF'
import sys, glob, os
d = sys.argv[1]
files = sorted(glob.glob(os.path.join(d, "ui_*.ppm")))
if not files:
    print("FAIL: нет дампов канвы меню"); sys.exit(1)

def load(f):
    parts = open(f, "rb").read().split(b"\n", 3)
    w, h = map(int, parts[1].split())
    return w, h, parts[3]

def check(px_data, w, h):
    def pix(x, y):
        o = (y * w + x) * 3
        return (px_data[o], px_data[o+1], px_data[o+2])
    # рамка плашки + жёлтая заливка значка (v36.43: молнии больше нет)
    if pix(1192, 8) != (42, 48, 64): return False
    if pix(1204, 19) != (232, 236, 244): return False   # рамка корпуса (белая)
    yellow = any(pix(x, y) == (255, 197, 61)
                 for x in range(1206, 1216) for y in range(21, 39))
    white = any(pix(x, y) == (255, 255, 255)
                for x in range(1193, 1263) for y in range(9, 51))
    return yellow and not white

for f in files:
    w, h, px_data = load(f)
    if check(px_data, w, h):
        print("icon badge pixels: OK (%s)" % os.path.basename(f))
        sys.exit(0)
print("FAIL: значок заряда (25%, без молнии) не найден ни в одном дампе меню")
sys.exit(1)
PYEOF
[ $? -eq 0 ] || ok=0

grep -ahqi "segfault\|SIGSEGV" $ALL && { echo "FAIL: краш"; ok=0; }

echo ""
if [ "$ok" = "1" ]; then
  echo "=== SETTINGS-EXIT E2E: ALL PASSED ==="
else
  echo "=== SETTINGS-EXIT E2E: FAILURES (см. выше) ==="
  exit 1
fi
