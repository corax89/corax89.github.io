#!/usr/bin/env python3
"""Патч at.class: bM(I)Z -> always true (sound-enable gate)."""
import struct, sys

src = sys.argv[1]
dst = sys.argv[2]
data = bytearray(open(src, "rb").read())

pos = 10
cp_count = struct.unpack(">H", data[8:10])[0]
cp = [None] * cp_count
i = 1
while i < cp_count:
    tag = data[pos]; pos += 1
    if tag == 1:
        ln = struct.unpack(">H", data[pos:pos+2])[0]
        cp[i] = bytes(data[pos+2:pos+2+ln]).decode("utf-8", "replace")
        pos += 2 + ln
    elif tag in (7, 8, 16, 19, 20):
        pos += 2
    elif tag == 15:
        pos += 3
    elif tag in (3, 4, 9, 10, 11, 12, 17, 18):
        pos += 4
    elif tag in (5, 6):
        pos += 8; i += 1
    else:
        raise SystemExit(f"unknown tag {tag} at cp#{i}")
    i += 1

pos += 2 + 2 + 2  # access, this, super
ifc = struct.unpack(">H", data[pos:pos+2])[0]; pos += 2 + ifc * 2
fcount = struct.unpack(">H", data[pos:pos+2])[0]; pos += 2
for _ in range(fcount):
    pos += 6
    fac = struct.unpack(">H", data[pos:pos+2])[0]; pos += 2
    for _f in range(fac):
        falen = struct.unpack(">I", data[pos+2:pos+6])[0]
        pos += 6 + falen
mcount = struct.unpack(">H", data[pos:pos+2])[0]; pos += 2
found = False
for _ in range(mcount):
    name_i, desc_i = struct.unpack(">HH", data[pos+2:pos+6])
    pos += 6
    name = cp[name_i] or ""
    desc = cp[desc_i] or ""
    acount = struct.unpack(">H", data[pos:pos+2])[0]; pos += 2
    for _a in range(acount):
        an_i = struct.unpack(">H", data[pos:pos+2])[0]
        alen = struct.unpack(">I", data[pos+2:pos+6])[0]
        aname = cp[an_i] or ""
        body_off = pos + 6
        if name == "bM" and desc == "(I)Z" and aname == "Code" and not found:
            # Code: max_stack(2) max_locals(2) code_len(4) code...
            clen = struct.unpack(">I", data[body_off+4:body_off+8])[0]
            code_off = body_off + 8
            print(f"bM(I)Z code at {code_off}, len {clen}, was: {data[code_off:code_off+8].hex(' ')}")
            # iconst_1; ireturn; остальное — nop
            data[code_off] = 0x04
            data[code_off+1] = 0xAC
            for k in range(2, clen):
                data[code_off+k] = 0x00
            found = True
        pos += 6 + alen

if not found:
    raise SystemExit("bM(I)Z not found!")
open(dst, "wb").write(bytes(data))
print(f"patched -> {dst}")
