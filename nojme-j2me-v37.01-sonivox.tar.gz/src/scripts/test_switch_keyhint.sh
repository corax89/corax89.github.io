#!/bin/bash
# [KEYHINT-REMOVE] v36.48 E2E-регрессия: панель «Кнопки в игре» ([KEY-HINT]
# v36.45) УДАЛЕНА. Проверяем, что после удаления:
#   1) при keyhint=on в ini (старый файл с устройства) панель НЕ появляется
#      ни в одном игровом кадре (цвет рамки 0x4A5A6A в нижней полосе y>=545);
#   2) трейс "keyhint: shown" НЕ пишется;
#   3) ключ keyhint= молча принимается (загрузка настроек без шума);
#   4) сессия игры проходит чисто (game: session end).
# Если панель вдруг вернётся (регресс) — тест закричит.
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/TestKeys.jar"
[ -f "$JAR" ] || bash scripts/keysjar/build.sh
[ -f "$JAR" ] || { echo "TestKeys.jar build failed"; exit 1; }

ok=0
D=/tmp/sw_keyhint_rm
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/cd"
cp "$JAR" "$D/roms/"
cat > "$D/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
keyhint=on
EOF

SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
NOJME_LOG=1 NOJME_LOGGING=1 \
NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D" \
XDG_DATA_HOME="$D/xdg" \
NOJME_COMPOSITE_DUMP_DIR="$D/cd" NOJME_COMPOSITE_DUMP_MAX=25 \
NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:25000" \
timeout -k 5 32 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

# 1) пиксель-проверка: ни в одном игровом кадре нет рамки панели
python3 - "$D" <<'PY'
import sys, glob, os
import numpy as np
d = sys.argv[1]
def arr(p):
    with open(p,'rb') as f:
        assert f.readline().strip()==b'P6'
        w,h = map(int, f.readline().split()); f.readline()
        return np.frombuffer(f.read(), dtype=np.uint8).reshape(h,w,3).astype(np.int16)
fs = sorted(glob.glob(os.path.join(d,'cd','comp_*.ppm')))
present = []
for p in fs:
    n = int(os.path.basename(p)[5:9])
    if n < 5: continue              # меню/загрузка — не смотрим
    A = arr(p)
    strip = A[545:,:,:]
    m = int((np.abs(strip-np.array([74,90,106])).max(axis=2)<=12).sum())
    if m >= 100: present.append(n)
print(f"[rm] кадров с рамкой панели: {present}")
if present:
    print("[rm] FAIL: панель «Кнопки в игре» всё ещё рисуется — регрессия KEYHINT-REMOVE")
    sys.exit(1)
print("[rm] OK: панели нет ни в одном игровом кадре")
PY
[ $? = 0 ] || ok=1

# 2) трейс показа не пишется
if grep -ahq "keyhint: shown" "$D/log.txt" "$D/err.log" 2>/dev/null; then
    echo "[rm] FAIL: трейс 'keyhint: shown' появился"; ok=1
else
    echo "[rm] OK: трейса 'keyhint: shown' нет"
fi

# 3) ключ молча принят: загрузка настроек отчиталась без ругани на keyhint
if grep -ahq "unknown.*keyhint\|keyhint.*unknown" "$D/log.txt" "$D/err.log" "$D/out.log" 2>/dev/null; then
    echo "[rm] FAIL: keyhint= ругается как неизвестный ключ"; ok=1
else
    echo "[rm] OK: ключ keyhint= принят молча"
fi

# 4) сессия игры завершилась
if grep -ahq "game: session end" "$D/log.txt" "$D/err.log" 2>/dev/null; then
    echo "[rm] OK: сессия игры прошла и закрылась"
else
    echo "[rm] FAIL: game: session end не найден"; ok=1
fi

if [ "$ok" = 0 ]; then echo "KEYHINT-REMOVE E2E: ALL PASSED"; else echo "KEYHINT-REMOVE E2E: FAILURES"; exit 1; fi
