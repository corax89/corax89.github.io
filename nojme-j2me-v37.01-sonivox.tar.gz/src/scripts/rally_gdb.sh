#!/bin/bash
# Rally 3D: запуск репро в фон + через T секунд gdb-дамп всех потоков (C-стеки).
# Использование: bash scripts/rally_gdb.sh <суффикс> [сек_до_gdb] [сек_прогона]
set -u
SUF=${1:-gdb}
WAIT=${2:-25}
KILLAT=${3:-40}
D=/tmp/rally_gdb_$SUF
cd "$(dirname "$0")/.." || exit 1
rm -rf "$D"; mkdir -p "$D/roms"
cp "/home/z/my-project/rally3d/rally3d.jar" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:600"
# Меню ~9.5с: A (Continue), A (подтверждение) — далее газ/руль
FRONT="A:10200,A:1800,UP:600,RIGHT:900,LEFT:700,RIGHT:600,LEFT:600,UP:1500,UP:1500"
export NOJME_FRONT_KEYS="$FRONT"
# БЕЗ SELFSTACK-спама (он замедляет VM в разы); диаг остаются
unset NOJME_SELF_STACK_EVERY
export NOJME_PAINTTIME=1

./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" &
PID=$!
echo "PID=$PID — ждём ${WAIT}s, процесс под нагрузкой..."
sleep "$WAIT"
if ! kill -0 $PID 2>/dev/null; then echo "процесс умер до gdb"; exit 1; fi
echo "=== gdb attach ==="
gdb -p $PID -batch \
    -ex "set pagination off" \
    -ex "info threads" \
    -ex "thread apply all bt 22" \
    > "$D/gdb.txt" 2>&1
echo "gdb done -> $D/gdb.txt"
sleep 2
# второй дамп — убедиться, что состояние стабильное
gdb -p $PID -batch -ex "set pagination off" -ex "thread apply all bt 8" > "$D/gdb2.txt" 2>&1
kill -9 $PID 2>/dev/null
echo "=== err.log события ==="
grep -an "EX-THROW\|showNotify() on\|frame: first\|VM-THREAD-DEATH\|RESOURCE\].*mid\|RESOURCE\].*track\|KEYIN\] dispatch\|diag: loop\|game: begin" "$D/err.log" | grep -v PTRSCAN | tail -30
