/* v36.83 [ZFENCE-PAINT] selftest: paint() ЧИСТОЙ Java ждёт флага, который
 * ставит ВТОРОЙ поток (Gameloft-загрузка Zombie Infection: g.H case-117
 * busy-wait на времени скрипта, тикающем из g.run()). На сборках, где
 * EXIT-FENCE держит VM-раннеров всё окно paint, воркер замерзает на
 * 16k-инструкционном опросе, спин живёт до 1.5 с и его убивает
 * [SPIN-BREAK] — исключение разматывает paint мимо игрового гарда
 * повторного входа, загрузка мертва. На чиненой сборке fence в окне paint
 * не вооружается: воркер свободно тикает, флаг встаёт на ~400 мс, спин
 * выходит сам, кадры продолжаются.
 * PASS: TFW:WAIT-OK, TFW:SURVIVED-ALL, НИ ОДНОГО [SPIN-BREAK]. */
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TestFenceWait extends MIDlet {
    static int flag = 0;    /* 0 = ждём, 1 = воркер освободил */
    static int frames = 0;
    static Canvas c;
    static Thread worker;

    public TestFenceWait() { System.out.println("TFW:ctor"); }

    public void startApp() {
        c = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0, 0, 0);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(80, 255, 80);
                if (flag == 0) {
                    /* идиома загрузки: ЧИСТО-Java busy-wait в paint без
                     * единого натива (как g.H case-117) */
                    long spin = 0;
                    while (flag == 0) {
                        spin = spin + 1;
                        if (spin > 2000000000L) break;
                    }
                    if (flag != 0) {
                        System.out.println("TFW:WAIT-OK spins=" + spin);
                    } else {
                        System.out.println("TFW:WAIT-DEAD spins=" + spin);
                    }
                }
                frames++;
                g.drawString("f " + frames, 10, 10, 0);
                if (frames == 10) {
                    System.out.println("TFW:SURVIVED-ALL frames=" + frames);
                }
            }
            protected void keyPressed(int k) { System.out.println("TFW:key " + k); }
        };
        Display.getDisplay(this).setCurrent(c);
        worker = new Thread(new Runnable() {
            public void run() {
                System.out.println("TFW:worker-start");
                /* прогрев в стиле frame-limiter'a игры: цикл натив-вызовов
                 * (currentTimeMillis + yield), чтобы воркер регулярно
                 * подходил к опросу fence, пока главный поток в paint */
                long t0 = System.currentTimeMillis();
                while (System.currentTimeMillis() - t0 < 400) {
                    Thread.yield();
                }
                flag = 1;
                System.out.println("TFW:flag-set");
                /* дальше — тикер как игровой поток часов */
                while (frames < 10) {
                    try { Thread.sleep(60); } catch (Exception e) {}
                    c.repaint();
                }
                System.out.println("TFW:worker-done frames=" + frames);
            }
        });
        worker.start();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
