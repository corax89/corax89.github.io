/* v36.98 [NATIVE-NOTE-FRESH]+[SPIN-BREAK-PAINT] selftest: НИЗКОЧАСТОТНЫЙ
 * воркер + долгий busy-wait в paint — точная имитация полевого лога
 * v36.97 (Zombie Infection, SPIN-BREAK tid=1 site g.a@124).
 *
 * Отличие от TestFenceWait (v36.83): там воркер грелся ТЕСНЫМ yield-циклом
 * (тысячи нативов/с) — его last_native_ms оставался свежим даже при
 * [NATIVE-NOTE-LITE] (штамп раз в 32 вызова), и sibling-правило держало
 * порог x8. В ПОЛЕ воркер Gameloft-загрузки проводит цикл ВНУТРИ
 * serviceRepaints (250-мс нанослипы внутри натива — НЕ диспетчеризации) и
 * тяжёлой чистой Java между ними: единицы нативов в секунду. Штамп
 * «каждый 32-й» старел на СЕКУНДЫ, окно свежести 1200 мс захлопывалось,
 * sibling отваливался — и брейкер бил базовым порогом 1500 мс по
 * ЛЕГИТИМНОЙ загрузке на главном потоке: вечный экран загрузки.
 *
 * Здесь воркер тикает Thread.sleep(500) (2 натива/с — за всё окно ожидания
 * диспетчируется < 32 нативов, штамп «каждый 32-й» ЗАМЕРАЕТ намертво),
 * флаг встаёт на ~4 с (больше базового порога 1.5 с, меньше sibling-порога
 * 12 с). paint() главного потока крутит чисто-Java busy-wait (реальная
 * работа — счётчик, как панорамирование камеры).
 *
 * PASS: TFS:WAIT-OK, TFS:SURVIVED-ALL, НИ ОДНОГО [SPIN-BREAK].
 * На v36.97 (без фикса): SPIN-BREAK ~1.5-2 с, WAIT убит — репро баги. */
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TestFenceSlow extends MIDlet {
    static int flag = 0;    /* 0 = ждём, 1 = воркер освободил */
    static int frames = 0;
    static Canvas c;
    static Thread worker;

    public TestFenceSlow() { System.out.println("TFS:ctor"); }

    public void startApp() {
        c = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0, 0, 0);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(80, 255, 80);
                if (flag == 0) {
                    /* идиома загрузки Gameloft: ЧИСТО-Java busy-wait в
                     * paint с реальной работой (нет ни одного натива).
                     * Инкремент — НЕ экспонента: потолок 5e9 итераций ≈ 100+ с,
                     * флаг ждём на ~4 с. */
                    long spin = 0;
                    while (flag == 0) {
                        spin = spin + 1;
                        if (spin > 5000000000L) break;
                    }
                    if (flag != 0) {
                        System.out.println("TFS:WAIT-OK spins=" + spin);
                    } else {
                        System.out.println("TFS:WAIT-DEAD spins=" + spin);
                    }
                }
                frames++;
                g.drawString("f " + frames, 10, 10, 0);
                if (frames == 10) {
                    System.out.println("TFS:SURVIVED-ALL frames=" + frames);
                }
            }
            protected void keyPressed(int k) { System.out.println("TFS:key " + k); }
        };
        Display.getDisplay(this).setCurrent(c);
        worker = new Thread(new Runnable() {
            public void run() {
                System.out.println("TFS:worker-start");
                /* НИЗКАЯ частота нативов: сон кусками 500 мс (2 диспетчеризации
                 * нативов в секунду) — за 4-с окно ожидания < 32 вызовов,
                 * «каждый 32-й» штамп v36.97 замерзает на всё окно. Флаг на
                 * ~4 с: больше базового порога брейкера (1.5 с), меньше
                 * sibling-порога (12 с). */
                for (int i = 0; i < 8; i++) {
                    try { Thread.sleep(500); } catch (Exception e) {}
                }
                flag = 1;
                System.out.println("TFS:flag-set");
                /* дальше — тикер как игровой поток часов */
                while (frames < 10) {
                    try { Thread.sleep(60); } catch (Exception e) {}
                    c.repaint();
                }
                System.out.println("TFS:worker-done frames=" + frames);
            }
        });
        worker.start();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
