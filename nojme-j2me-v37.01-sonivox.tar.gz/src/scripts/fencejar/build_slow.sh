#!/bin/bash
# Build TestFenceSlow.jar — v36.98 [NATIVE-NOTE-FRESH] selftest
# (низкочастотный воркер + долгий busy-wait в paint — полевой лог v36.97).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out-slow"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
STUBS="$D/../keysjar/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestFenceSlow.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TFS, , TestFenceSlow\r\nMIDlet-Name: TestFenceSlow\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestFenceSlow*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestFenceSlow.jar" META-INF && zip -q "$D/TestFenceSlow.jar" *.class )
echo "built: $D/TestFenceSlow.jar"
