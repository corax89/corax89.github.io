import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/* TestConvSlots — v36.38-BT2 selftest: слоты long/double в быстром
 * диспатче интерпретатора (l2d/d2l/d2i + копирование обоих слотов
 * арифметикой ladd/lmul/dadd/...).
 *
 * Регрессия Bounce Tales: (int)Math.sqrt((double)((long)dx*dx+(long)dy*dy))
 * возвращал 0 для горизонтальных/вертикальных сегментов (l2d читал
 * устаревший верхний слот после ladd), а l2d/d2l/d2i протекали по +1
 * слоту на вызов (дрейф operand-стека -> выход за границы фрейма).
 *
 * Ожидаемые SYSOUT-строки: "CONV ok <имя>" / "CONV FAIL ..." и финал
 * "CONV-DONE fails=0".
 */
public class TestConvSlots extends MIDlet {
    static int fails = 0;

    static void p(String s) { System.out.println("CONV " + s); }

    static void chk(String name, long got, long want) {
        if (got != want) { fails++; p("FAIL " + name + " got=" + got + " want=" + want); }
        else p("ok " + name);
    }
    static void chkS(String name, String got, String want) {
        if (!got.equals(want)) { fails++; p("FAIL " + name + " got=" + got + " want=" + want); }
        else p("ok " + name);
    }

    public TestConvSlots() {}

    public void startApp() {
        // --- 1. ТОЧНЫЙ паттерн Bounce Tales: lmul;lmul;ladd;l2d;sqrt;d2i ---
        int dx = 0, dy = 30;
        chk("sqrt(dx=0,dy=30)", (int) Math.sqrt((double) ((long) dx * dx + (long) dy * dy)), 30);
        dx = 40; dy = 0;
        chk("sqrt(dx=40,dy=0)", (int) Math.sqrt((double) ((long) dx * dx + (long) dy * dy)), 40);
        dx = 3; dy = 4;
        chk("sqrt(dx=3,dy=4)", (int) Math.sqrt((double) ((long) dx * dx + (long) dy * dy)), 5);

        // --- 2. Нормализация с lshl/ldiv (второй блок c.a): (dx<<16)/dist ---
        dx = 12; dy = 35;
        int dist = (int) Math.sqrt((double) ((long) dx * dx + (long) dy * dy));
        int nx = (int) (((long) dx << 16) / (long) dist);
        int ny = (int) (((long) dy << 16) / (long) dist);
        // 12<<16=786432, /37 = 21254; 35<<16=2293760, /37 = 61993
        chk("norm-x", nx, 21254);
        chk("norm-y", ny, 61993);

        // --- 3. dadd;dcmpl: нижний слот после dadd (старый dcmpl читал мусор) ---
        double a = 1.0e10, b = -1.0e10, c = 0.5;
        chk("dadd>dcmpl false", (a + b) > c ? 1 : 0, 0);          // 0.0 > 0.5 => false
        chk("dadd>dcmpl true",  (a + b + 1.0) > c ? 1 : 0, 1);    // 1.0 > 0.5 => true
        // d2f после dadd (читает нижний слот)
        chkS("d2f after dadd", String.valueOf((float) (a + b + 0.25)), "0.25");

        // --- 4. d2i/d2l насыщение и NaN (JVMS J-2) ---
        chk("d2i NaN", (int) (0.0 / 0.0), 0);
        chk("d2i +inf", (int) 1e300, Integer.MAX_VALUE);
        chk("d2i -inf", (int) -1e300, Integer.MIN_VALUE);
        chk("d2l NaN", (long) (0.0 / 0.0), 0);
        chk("d2l +inf", (long) 1e300, Long.MAX_VALUE);
        chk("d2l -inf", (long) -1e300, Long.MIN_VALUE);

        // --- 5. l2d границы ---
        chkS("l2d MAX", Double.toString((double) Long.MAX_VALUE), "9.223372036854776E18");
        chkS("l2d MIN", Double.toString((double) Long.MIN_VALUE), "-9.223372036854776E18");
        // d2l round-trip в диапазоне точных long
        chk("d2l exact", (long) 1234567890123.0, 1234567890123L);

        // --- 6. lcmp после ladd/lshl (копии слотов) ---
        long la = 0x7FFFFFFFL, lb = 2L;
        chk("lcmp after ladd", (la + lb) > 0x7FFFFFFFL ? 1 : 0, 1);
        chk("lshl>>copy", ((la << 16) >> 16), 0x7FFFFFFFL);

        // --- 7. ДРЕЙФ-СТРЕСС: 300000 итераций l2d+d2i в одной рамке ---
        // Старый код утекал +1 слот за итерацию: max_stack рамки был бы
        // пробит через несколько сотен итераций (ASan/STK-OVER). Эталон
        // суммы: 45000150181 (для i от 1 до 300000, (int)sqrt(i*i+144)).
        long acc = 0;
        for (int i = 1; i <= 300000; i++) {
            acc += (int) Math.sqrt((double) ((long) i * i + 144L));
        }
        chk("drift-stress acc", acc, 45000150181L);

        p("CONV-DONE fails=" + fails);
        if (fails == 0) {
            new Thread() { public void run() { notifyDestroyed(); } }.start();
        }
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}
}
