#!/bin/bash
# Сборка TestConvSlots.jar — v36.38-BT2 selftest слотов long/double.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found"; exit 1; }
rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestConvSlots.java" \
    "$D/../testfinish/stubs/javax/microedition/midlet/"*.java \
    "$D/../testfinish/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"; rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestConvSlots\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestConvSlots*.class "$PKG/"
(cd "$PKG" && zip -q -r "$D/TestConvSlots.jar" .)
echo "Built $D/TestConvSlots.jar"
