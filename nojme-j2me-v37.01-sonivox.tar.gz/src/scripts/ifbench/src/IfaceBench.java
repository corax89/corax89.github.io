import javax.microedition.midlet.MIDlet;

/* v36.101 [IFACE-IC] proof benchmark: interface-dense workload.
 * Monomorphic interface call sites (the Gameloft callback shape) plus a
 * polymorphic site (4 impls round-robin) and a static-call control loop.
 * Reports iterations/s per phase; A/B with NOJME_IFACE_IC=0 isolates the
 * inline cache on the same binary. */
public class IfaceBench extends MIDlet {
    static volatile boolean stop = false;

    interface Op { int step(int x); int kind(); }

    static class Adder implements Op {
        int bias;
        public int step(int x) { return x + bias + 1; }
        public int kind() { return 1; }
    }
    static class Multer implements Op {
        int bias;
        public int step(int x) { return x * 3 + bias; }
        public int kind() { return 2; }
    }
    static class Xorer implements Op {
        int bias;
        public int step(int x) { return (x ^ 0x5A) + bias; }
        public int kind() { return 3; }
    }
    static class Slow implements Op {
        int bias;
        public int step(int x) { int a = x; for (int i = 0; i < 8; i++) a = a * 7 + i; return a + bias; }
        public int kind() { return 4; }
    }

    public void startApp() {
        System.out.println("IFB start");
        Adder a0 = new Adder(); a0.bias = 5;
        Op mono = a0;
        Op[] poly = { new Adder(), new Multer(), new Xorer(), new Slow() };
        for (int i = 0; i < 4; i++) { poly[i].step(1); poly[i].kind(); }
        long t0 = System.currentTimeMillis();
        long phase = 0, iters = 0, next = t0 + 1000;
        long acc = 0;
        /* v36.101 [IFACE-IC] correctness pin: FIXED-iteration checksum over
         * the same call mix — identical on every run and under both the IC
         * and the slow path (NOJME_IFACE_IC=0). A dispatch bug changes it. */
        for (int i = 0; i < 200000; i++) {
            acc = mono.step((int) acc);
            acc = mono.kind() + acc;
            acc = poly[i & 3].step((int) acc);
        }
        System.out.println("IFB fix=" + acc);
        while (!stop) {
            for (int i = 0; i < 10000; i++) {
                acc = mono.step((int) acc);          /* monomorphic iface */
                acc = mono.kind() + acc;
                acc = poly[i & 3].step((int) acc);   /* polymorphic iface */
            }
            iters += 10000;
            long now = System.currentTimeMillis();
            if (now >= next) {
                System.out.println("IFB " + phase + " iters=" + iters
                        + " calls_per_s=" + (iters * 3 * 1000L / (now - t0)));
                next = now + 1000;
                phase++;
                if (phase == 10) break;
            }
        }
        System.out.println("IFB acc=" + acc);
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
