#!/bin/bash
# v36.105 [SUPERI]: EffBench A/B — effects-scene workload (field tail of
# the v36.103 log: long pure-Java pixel loops, low call density). Prints
# median fps for the SAME binary under two env configurations:
#   run ""                              -> SUPERI fused pairs ON (default)
#   run "env NOJME_SUPERI=0"            -> no fusion (v36.104 semantics)
# BIT-EXACTNESS ORACLE (v36.105 fix): the per-checkpoint checksums
# (frames=32/64/96/...) printed by the SAME binary under both configs
# must match — the FINAL acc depends on how many frames fit in the fixed
# 12 s window (faster config legitimately completes more frames), so the
# old final-acc comparison false-positived as soon as the speedup grew.
set -u
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/zeff
run_one() {   # $1 = env prefix; sets MED_FPS/CHK (no subshell)
    rm -rf "$D"; mkdir -p "$D/roms"
    cp scripts/effbench/EffBench.jar "$D/roms/"
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-} \
    NOJME_LOG=1 NOJME_LOGGING=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 NOJME_SWITCH_KEYS="A:400,A:800,EXIT:15000" \
    $1 timeout -k 5 40 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
    MED_FPS=$(grep -a "fps=" "$D/err.log" | grep -o "fps=[0-9]*" | cut -d= -f2 | awk 'NF' | tail -n +3 | sort -n | awk '{a[NR]=$1} END{if(NR>0) print a[int((NR+1)/2)]; else print 0}')
    CHK=$(grep -a "println EFF frames=" "$D/err.log" | sed 's/.*println EFF //' | awk '{print $1 $2}' | sort)
}
run_one ""
ON_FPS=$MED_FPS; ON_CHK=$CHK
run_one "env NOJME_SUPERI=0"
OFF_FPS=$MED_FPS; OFF_CHK=$CHK
echo "EFFBENCH: SUPERI-ON  fps=${ON_FPS}"
echo "EFFBENCH: SUPERI-OFF fps=${OFF_FPS}"
if [ -z "$ON_FPS" ] || [ -z "$OFF_FPS" ] || [ "$ON_FPS" = "0" ] || [ "$OFF_FPS" = "0" ]; then
    echo "EFFBENCH: FAILED (on='${ON_FPS}' off='${OFF_FPS}')"
    exit 1
fi
pct=$(python3 -c "print('%.1f' % ((float('$ON_FPS')/float('$OFF_FPS')-1)*100))")
echo "EFFBENCH: delta=+${pct}%"
NON=$(echo "$ON_CHK" | grep -c .); NOFF=$(echo "$OFF_CHK" | grep -c .)
NMIN=$(( NON < NOFF ? NON : NOFF ))
if [ "$NMIN" -lt 3 ]; then
    echo "EFFBENCH: FAILED (too few checkpoints: on=$NON off=$NOFF)"
    exit 1
fi
NCOMMON=$(comm -12 <(echo "$ON_CHK") <(echo "$OFF_CHK") | grep -c .)
if [ "$NCOMMON" -lt "$NMIN" ]; then
    echo "EFFBENCH: CHECKSUM MISMATCH — common $NCOMMON of min $NMIN checkpoints"
    diff <(echo "$ON_CHK") <(echo "$OFF_CHK") | head -6
    exit 1
fi
echo "EFFBENCH: checkpoints OK ($NCOMMON/$NMIN bit-exact)"
