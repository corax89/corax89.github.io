#!/bin/bash
# v36.104: precise EffBench A/B — TWO binaries (v36.103 classic switch vs
# v36.104 threaded dispatch), fixed-frame metric from the DONE line.
# Usage: test_effbench_ab.sh [binary_a] [binary_b]
set -u
cd "$(dirname "$0")/../.." || exit 1
A="${1:-/tmp/switchui-verify-v36103}"
B="${2:-/tmp/switchui-verify-v36104}"
D=/tmp/zeff
run_one() {
    BIN="$1"; TAG="$2"
    rm -rf "$D"; mkdir -p "$D/roms"
    cp scripts/effbench/EffBench.jar "$D/roms/"
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-} \
    NOJME_LOG=1 NOJME_LOGGING=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 NOJME_SWITCH_KEYS="A:400,A:800,EXIT:15000" \
    timeout -k 5 40 "$BIN" > "$D/out.log" 2> "$D/err.log" || true
    DONE=$(grep -a "EFF DONE" "$D/err.log" | tail -1)
    FR=$(echo "$DONE" | grep -o "frames=[0-9]*" | cut -d= -f2)
    MS=$(echo "$DONE" | grep -o "ms=[0-9]*" | cut -d= -f2)
    ACC=$(echo "$DONE" | grep -o "acc=-\?[0-9]*" | cut -d= -f2)
    echo "  $TAG: frames=$FR ms=$MS acc=$ACC"
    FPS_FILE=$(python3 -c "print('%.3f' % ($FR * 1000.0 / ($MS + 1)))")
    echo "$FPS_FILE"
}
echo "EffBench A/B (two binaries, deterministic 12s runs):"
FA=$(run_one "$A" "A: $(basename $A)" | tail -1)
FB=$(run_one "$B" "B: $(basename $B)" | tail -1)
echo "A_fps=$FA  B_fps=$FB"
python3 -c "print('delta = %+.1f%%' % ((float('$FB')/float('$FA')-1)*100))"
