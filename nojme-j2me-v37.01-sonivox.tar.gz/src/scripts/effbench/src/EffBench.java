import javax.microedition.midlet.MIDlet;

/* v36.104 [THREADED-DISPATCH]: effects-scene benchmark. Models the
 * Zombie Infection field tail ("много графических эффектов", лог
 * v36.103): vi=21M/s at ivk=84-150K calls/s (~1250 instr/call) and
 * natives at 2.5% — the frame is burned by LONG STRAIGHT-LINE JAVA
 * PIXEL LOOPS inside paint, not by natives and not by call density.
 * Workload: full-screen 240x320 int[] passes in the Gameloft idiom:
 *   - src-over alpha fog (fixed-point 8.8, per-pixel mul/shr/and/or),
 *   - tint+flash with REAL idiv per pixel (javac never strength-reduces
 *     division by 256 — the fixed-point normalize idiom),
 *   - scanline wobble with LUT + clip branches (caload/if_icmp mix),
 *   - particle SoA update + additive 2x2 sparks with respawn idiv.
 * Per-ROW helper calls keep the invoke path exercised lightly (~6000
 * instr/call). Deterministic LCG — acc checksum is the bit-exact A/B
 * oracle for interpreter-core changes. */
public class EffBench extends MIDlet {
    static final int W = 240, H = 320;

    int[] dst;    /* backbuffer */
    int[] src;    /* effect layer */
    int[] fog;    /* fog alpha LUT */
    int[] wob;    /* wobble offset LUT */
    int[] px, py, pvx, pvy, plife, pcol;  /* particles (SoA) */
    int np;
    long acc;
    int frames;
    int frameNo;
    long seed;

    public EffBench() {
        dst = new int[W * H];
        src = new int[W * H];
        fog = new int[256];
        wob = new int[64];
        np = 600;
        px = new int[np]; py = new int[np];
        pvx = new int[np]; pvy = new int[np];
        plife = new int[np]; pcol = new int[np];
        seed = 0x12345678L;
        for (int i = 0; i < 256; i++) fog[i] = ((i * 3) ^ (i << 7)) & 255;
        for (int i = 0; i < 64; i++) wob[i] = (int) ((rnd() & 15) - 8);
        for (int i = 0; i < W * H; i++) {
            src[i] = (int) rnd();
            dst[i] = (int) rnd();
        }
        for (int i = 0; i < np; i++) {
            px[i] = (int) (rnd() & 1023) * W / 1024;
            py[i] = (int) (rnd() & 1023) * H / 1024;
            pvx[i] = (int) ((rnd() & 7) - 3);
            pvy[i] = (int) ((rnd() & 9) - 4);
            plife[i] = (int) ((rnd() & 255) + 20);
            pcol[i] = (int) (rnd() & 0xFFFFFF);
        }
    }

    long rnd() {
        seed = seed * 6364136223846793005L + 1442695040888963407L;
        return seed >>> 17;
    }

    /* pass 1: src-over alpha fog, 8.8 fixed point (one row per call) */
    void fogRow(int y, int fidx) {
        int base = y * W;
        for (int x = 0; x < W; x++) {
            int i = base + x;
            int s = src[i];
            int d = dst[i];
            int sa = (s >>> 24) * fog[(i + fidx) & 255];
            int a = sa >>> 8;
            if (a > 255) a = 255;
            if (a < 0) a = 0;
            int dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
            int sr = (s >> 16) & 255, sg = (s >> 8) & 255, sb = s & 255;
            int ia = 256 - a;
            dst[i] = 0xFF000000
                    | ((((dr * ia + sr * a) >>> 8) & 255) << 16)
                    | ((((dg * ia + sg * a) >>> 8) & 255) << 8)
                    | (((db * ia + sb * a) >>> 8) & 255);
        }
    }

    /* pass 2: tint + flash — REAL idiv per pixel (fixed-point normalize) */
    void tintRow(int y, int tint, int lum) {
        int base = y * W;
        for (int x = 0; x < W; x++) {
            int i = base + x;
            int d = dst[i];
            int r = (d >> 16) & 255, g = (d >> 8) & 255, b = d & 255;
            int l = (r * 77 + g * 151 + b * 28) >>> 8;
            int t = l * 1000 / (lum + 1);
            if (t > 255) t = 255;
            int it = 255 - tint;
            r = (r * tint + t * it) / 256;
            g = (g * tint + t * it) / 256;
            b = (b * tint + t * it) / 256;
            dst[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
    }

    /* pass 3: scanline wobble — LUT + clip branches (caload/if_icmp) */
    void wobbleRow(int y, int widx) {
        int base = y * W;
        int off = wob[widx & 63];
        for (int x = 0; x < W; x++) {
            int sx = x + off;
            if (sx < 0) sx = 0;
            else if (sx >= W) sx = W - 1;
            dst[base + x] = src[base + sx];
        }
    }

    /* pass 4: particle SoA update + additive 2x2 sparks with respawn */
    void particles() {
        for (int i = 0; i < np; i++) {
            int x = px[i], y = py[i];
            x += pvx[i];
            y += pvy[i];
            pvy[i] = pvy[i] + 3;              /* gravity */
            plife[i] = plife[i] - 1;
            if (x < 0 || x >= W || y < 0 || y >= H || plife[i] <= 0) {
                x = (int) (rnd() & 1023) * W / 1024;
                y = (int) (rnd() & 1023) * H / 1024;
                pvx[i] = (int) ((rnd() & 7) - 3);
                pvy[i] = (int) ((rnd() & 9) - 8);
                plife[i] = (int) ((rnd() & 255) + 20);
                pcol[i] = (int) (rnd() & 0xFFFFFF);
                continue;
            }
            px[i] = x;
            py[i] = y;
            int c = pcol[i];
            int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
            for (int dy = 0; dy < 2; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= H) continue;
                for (int dx = 0; dx < 2; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= W) continue;
                    int idx = yy * W + xx;
                    int d = dst[idx];
                    int r = ((d >> 16) & 255) + cr;
                    int g = ((d >> 8) & 255) + cg;
                    int b = (d & 255) + cb;
                    if (r > 255) r = 255;
                    if (g > 255) g = 255;
                    if (b > 255) b = 255;
                    dst[idx] = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
            }
        }
    }

    void renderFrame() {
        frameNo++;
        int fidx = frameNo * 11;
        for (int y = 0; y < H; y++) fogRow(y, fidx + y);
        int tint = 200 + ((frameNo * 7) & 55);
        int lum = (frameNo * 37) & 255;
        for (int y = 0; y < H; y++) tintRow(y, tint, lum);
        int widx = frameNo * 3;
        for (int y = 0; y < H; y++) wobbleRow(y, widx + y);
        particles();
        /* checksum probe: sparse deterministic sample of the buffer */
        acc += dst[0];
        acc += dst[W * H / 3];
        acc += dst[W * H / 2];
        acc += dst[W * H - 1];
        acc += dst[(frameNo * 997) % (W * H)];
    }

    public void startApp() {
        acc = 0; frames = 0; frameNo = 0;
        long t0 = System.currentTimeMillis();
        long tEnd = t0 + 12000;
        while (System.currentTimeMillis() < tEnd) {
            renderFrame();
            frames++;
            if ((frames & 31) == 0) {
                long now = System.currentTimeMillis();
                System.out.println("EFF frames=" + frames + " acc=" + acc +
                        " fps=" + (frames * 1000 / (now - t0 + 1)));
            }
        }
        long now = System.currentTimeMillis();
        System.out.println("EFF DONE frames=" + frames + " ms=" + (now - t0) +
                " acc=" + acc);
        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
