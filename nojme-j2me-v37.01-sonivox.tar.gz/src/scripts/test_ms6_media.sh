#!/bin/bash
# v36.86 MS6-репро #1: Metal Slug 6 (I-Play) с медиа-логом — доказательство,
# что игра ЗАПРАШИВАЕТ звуки, а jar их не содержит ([RESOURCE] jar-miss).
# Используется оригинальный jar из scripts/ms6stage/ (или MS6_JAR=...).
# Аудит: [RESOURCE] Looking for '/musicStageSelect.mid' -> FAILED jar-miss;
# createPlayer -> MediaException "Empty or unreadable" (игра молча скипает);
# сессия игры жива до конца (RMS, session end).
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="${MS6_JAR:-scripts/ms6stage/Metal Slug 6 (I-Play)(1.0.1).jar}"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/tms6
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/ms6.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=on
vm_speed=normal
logging=on
EOF
cat > "$D/sdmc:/switch/j2me/pergame/ms6.jar.ini" <<'EOF'
res=240x320
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_MEDIA_DEBUG=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
# Прогрев + меню-навигация: A (старт/выбор), задержки, чтобы игра успела
# пройти заставки и попытаться играть звук/музыку.
export NOJME_SWITCH_KEYS="A:90000"
export NOJME_FRONT_KEYS="A:6000,A:6000,A:6000,A:8000,A:6000,A:8000,A:6000,A:8000"
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (make switchui-verify)"; exit 1; }
( cd "$D" && timeout -k 10 100 "$BIN" > out.log 2> err.log ) || true

LOG="$D/sdmc:/switch/j2me/log.txt"
ERR="$D/err.log"
[ -s "$LOG" ] || { echo "FAIL: log.txt пуст/отсутствует"; exit 1; }
ok=1
# (1) игра дошла до меню и пыталась играть звук меню
grep -aq "RESOURCE\] Looking for: '/musicStageSelect.mid'" "$ERR" || {
    echo "FAIL: игра не запрашивала musicStageSelect.mid"; ok=0; }
# (2) файла в jar нет — честный jar-miss (это и есть причина тишины)
grep -aq "RESOURCE\] FAILED 'musicStageSelect.mid': jar-miss" "$LOG" || {
    echo "FAIL: нет jar-miss по musicStageSelect.mid"; ok=0; }
# (3) createPlayer по пустому потоку -> MediaException, игра пережила
grep -aq "Empty or unreadable media stream" "$LOG" || {
    echo "FAIL: нет MediaException empty stream"; ok=0; }
# (4) сессия дошла до конца: session end в логе
grep -aq "game: session end" "$LOG" || { echo "FAIL: сессия не завершилась штатно"; ok=0; }
# (5) сессия жива достаточно (меню+стадия): были RESOURCE-запросы графики
nres=$(grep -ac "RESOURCE\] Looking for" "$ERR")
[ "${nres:-0}" -ge 10 ] || { echo "FAIL: RESOURCE-запросов всего $nres (<10)"; ok=0; }
echo "ресурсов запрошено: $nres; jar-miss по звуку подтверждён: $(grep -ac "jar-miss" "$LOG")"
[ "$ok" = 1 ] && echo "MS6-MEDIA: ALL CHECKS PASSED" || { echo "MS6-MEDIA: FAILED"; exit 1; }
