package javax.microedition.media;

public class MediaException extends Exception {
    public MediaException() {}
    public MediaException(String s) { super(s); }
}
