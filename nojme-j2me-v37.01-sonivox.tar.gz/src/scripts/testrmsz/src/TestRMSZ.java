import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.InvalidRecordIDException;

/* v37.01 [RMS-ZOMBIE-HEAL] — репродуктор полевого бага Bounce Tales
 * (лог 2026-10-10: «прохожу уровень, выхожу, открываю — только Новая
 * игра») для scripts/test_rmsheal.sh (bin/switchui-verify, E2E).
 *
 * Мидлет использует РОВНО идиому сохранений Bounce Tales (декомпиляция
 * класса o): жёстко зашитый id записи 1 и «addRecord(null,0,0) только
 * если стор пуст». На «зомби»-сторе (одна ПУСТА запись с id != 1,
 * next_id > 1) эта идиома ломается навсегда: getNumRecords() > 0 =>
 * addRecord не вызывается, а getRecord(1)/setRecord(1) вечно кидают
 * InvalidRecordIDException. Хил v37.01 сбрасывает такой стор в свежее
 * состояние — следующий save получает id=1, цикл сохранений
 * восстанавливается.
 *
 * Сторы (файлы готовит scripts/make_zombie_rms.py ДО запуска):
 *   TZ1 — зомби (1 пустая запись id=11, next_id=12; полевой кейс);
 *   TZ2 — пустой стор с устаревшим next_id=11 (фабрика зомби);
 *   TZ3 — здоровый стор (запись id=1 с валидным префиксом 1,14);
 *   TZ4 — записи с данными, но БЕЗ id 1 (хил не должен трогать).
 * Сессия 2 (тот же каталог сохранений) проверяет ПЕРСИСТЕНТНОСТЬ:
 * прогресс TZ1 пережил перезапуск процесса — сценарий пользователя
 * от «Новой игры» до «Продолжить».
 */
public class TestRMSZ extends MIDlet {
    static int pass = 0, fail = 0;

    static void chk(String id, boolean cond, String detail) {
        if (cond) { pass++; System.out.println("RZ:" + id + " PASS " + detail); }
        else      { fail++; System.out.println("RZ:" + id + " FAIL " + detail); }
    }

    static String cls(Throwable t) { return t == null ? "-" : t.getClass().getName(); }

    /* Сохранение — дословно паттерн o.a(String, byte[]) из Bounce Tales. */
    static void btSave(String store, byte[] payload) throws Exception {
        RecordStore rs = RecordStore.openRecordStore(store, true);
        try {
            if (rs.getNumRecords() <= 0) {
                rs.addRecord(null, 0, 0); /* игра НЕ смотрит возвращённый id */
            }
            byte[] d = new byte[payload.length + 2];
            d[0] = 1; d[1] = 14; /* маркер версии сохранения Bounce Tales */
            System.arraycopy(payload, 0, d, 2, payload.length);
            rs.setRecord(1, d, 0, d.length); /* жёстко зашитый id 1 */
        } finally {
            rs.closeRecordStore();
        }
    }

    /* Загрузка — дословно паттерн o.a(String) из Bounce Tales. */
    static String btLoad(String store) {
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(store, false);
        } catch (Throwable t) {
            return "NOTFOUND:" + cls(t);
        }
        try {
            if (rs.getNumRecords() <= 0) return "EMPTY";
            try {
                byte[] d = rs.getRecord(1);
                if (d == null || d.length < 2 || d[0] != 1 || d[1] != 14)
                    return "BADFMT";
                return "OK:" + new String(d, 2, d.length - 2);
            } catch (InvalidRecordIDException e) {
                return "INVALID1"; /* ровно то, что видел пользователь */
            }
        } catch (Throwable t) {
            return "ERR:" + cls(t);
        } finally {
            try { rs.closeRecordStore(); } catch (Throwable t) { }
        }
    }

    void session1() {
        /* --- TZ1: зомби (полевой кейс Bounce Tales) --- */
        String z1 = btLoad("TZ1");
        chk("Z1-LOAD", z1.equals("EMPTY"),
            "zombie healed: store opens with 0 records (was INVALID1 forever), load=" + z1);
        try {
            btSave("TZ1", "LEV2".getBytes());
            chk("Z1-SAVE", true, "save with hardcoded id 1 succeeded");
        } catch (Throwable t) {
            chk("Z1-SAVE", false, "save threw " + cls(t));
        }
        String z1r = btLoad("TZ1");
        chk("Z1-RELOAD", z1r.equals("OK:LEV2"), "immediate reload=" + z1r);

        /* --- TZ2: пустой стор с устаревшим next_id --- */
        String z2 = btLoad("TZ2");
        chk("Z2-LOAD", z2.startsWith("NOTFOUND") || z2.equals("EMPTY"),
            "0-record store reads as no-save, load=" + z2);
        try {
            btSave("TZ2", "NEW1".getBytes());
            chk("Z2-SAVE", true, "save after stale next_id reset");
        } catch (Throwable t) {
            chk("Z2-SAVE", false, "save threw " + cls(t));
        }
        String z2r = btLoad("TZ2");
        chk("Z2-RELOAD", z2r.equals("OK:NEW1"), "reload=" + z2r);

        /* --- TZ3: здоровый стор — хил не должен вмешаться --- */
        String z3 = btLoad("TZ3");
        chk("Z3-LOAD", z3.equals("OK:OLD!"), "healthy store intact, load=" + z3);
        try {
            btSave("TZ3", "NEW3".getBytes());
            chk("Z3-SAVE", true, "healthy save");
        } catch (Throwable t) {
            chk("Z3-SAVE", false, "save threw " + cls(t));
        }

        /* --- TZ4: данные без id 1 — хил НЕ трогает живые данные --- */
        RecordStore rs4 = null;
        try {
            rs4 = RecordStore.openRecordStore("TZ4", false);
            int n = rs4.getNumRecords();
            byte[] r2 = rs4.getRecord(2);
            String s2 = (r2 == null) ? "-" : new String(r2);
            chk("Z4-DATA", n == 2 && "abc".equals(s2),
                "records with payload preserved: n=" + n + " r2=" + s2);
            try {
                rs4.getRecord(1);
                chk("Z4-ID1", false, "getRecord(1) must throw on this store");
            } catch (InvalidRecordIDException e) {
                chk("Z4-ID1", true, "InvalidRecordIDException (spec behavior kept)");
            }
        } catch (Throwable t) {
            chk("Z4-DATA", false, cls(t));
        } finally {
            try { if (rs4 != null) rs4.closeRecordStore(); } catch (Throwable t) { }
        }
        /* --- TZ5: стор остаётся ОТКРЫТЫМ и dirty на выходе --- */
        try {
            RecordStore rs5 = RecordStore.openRecordStore("TZ5", true);
            byte[] d5 = "DIRTY".getBytes();
            rs5.addRecord(d5, 0, d5.length);
            /* НАРОЧНО не закрываем: у выхода из сессии стор открыт и
             * помечен dirty — teardown обязан (а) показать плашку
             * [RMS-WAIT] «ожидается завершение сохранения» и (б) довести
             * запись до дискa отложенным флашем (midp_rms_session_reset). */
            chk("Z5-OPEN", true, "store left open+dirty on exit");
        } catch (Throwable t) {
            chk("Z5-OPEN", false, cls(t));
        }
    }

    void session2() {
        /* Персистентность через перезапуск ПРОЦЕССА — сценарий
         * пользователя: прошёл уровень, вышел, открыл — «Продолжить». */
        String p1 = btLoad("TZ1");
        chk("P1-TZ1", p1.equals("OK:LEV2"), "Bounce Tales progress survived restart, load=" + p1);
        String p2 = btLoad("TZ2");
        chk("P2-TZ2", p2.equals("OK:NEW1"), "TZ2 progress survived restart, load=" + p2);
        String p3 = btLoad("TZ3");
        chk("P3-TZ3", p3.equals("OK:NEW3"), "TZ3 updated save survived restart, load=" + p3);

        /* Зомби-файл после хила не должен вернуть INVALID1 обратно. */
        try {
            btSave("TZ1", "LEV3".getBytes());
            chk("P1-SAVE", true, "second-session save works");
        } catch (Throwable t) {
            chk("P1-SAVE", false, "save threw " + cls(t));
        }
    }

    public void startApp() {
        System.out.println("RMSZ-TEST-START");
        boolean second = btLoad("TZ1").startsWith("OK:");
        if (second) {
            System.out.println("RMSZ: session 2 (persistence)");
            session2();
        } else {
            System.out.println("RMSZ: session 1 (heal)");
            session1();
        }
        System.out.println("RZ:DONE " + pass + "/" + fail);
        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
