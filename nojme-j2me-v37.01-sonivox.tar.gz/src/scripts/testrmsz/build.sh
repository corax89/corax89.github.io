#!/bin/bash
# Build TestRMSZ.jar — репродуктор «зомби»-сохранений Bounce Tales для
# scripts/test_rmsheal.sh (v37.01 [RMS-ZOMBIE-HEAL]).
# Class version 48 (no stack maps); только класс теста — мидлет/rms
# поставляет эмулятор в рантайме. Стабы общие с TestRMS (../testrms).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

# стабы не дублируются: те же, что у TestRMS (../testrms/stubs)
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestRMSZ.java" \
    "$D/../testrms/stubs/javax/microedition/rms/"*.java \
    "$D/../testrms/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestRMSZ\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/"*.class "$PKG/"
rm -f "$D/TestRMSZ.jar"
( cd "$PKG" && zip -q -r "$D/TestRMSZ.jar" META-INF && zip -q "$D/TestRMSZ.jar" *.class )
echo "built: $D/TestRMSZ.jar"
