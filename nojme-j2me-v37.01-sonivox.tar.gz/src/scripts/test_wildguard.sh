#!/bin/bash
# [WILDGUARD] v36.50 unit test — см. test_wildguard.c. Компилируется против
# РЕАЛЬНОГО switch_font.c дерева (тот же код, что в NRO): порог, дефуз,
# репорт-канал. Отдельно проверяем, что бинарник фронтенда действительно
# содержит сильное определение nojme_wg_report (switch_trace.c).
set -e
cd "$(dirname "$0")/.." || exit 1
T=/tmp/wg_test
mkdir -p "$T"
gcc -std=c11 -Wall -Wextra -g -O1 -Isrc -Isrc/include -Iinclude \
    -o "$T/test_wildguard" scripts/test_wildguard.c src/switch/switch_font.c
"$T/test_wildguard"

echo "--- сильное определение nojme_wg_report в verify-бинарнике ---"
nm bin/switchui-verify | grep -i "nojme_wg_report" || { echo "FAIL: нет символа"; exit 1; }
echo "WILDGUARD E2E SYMBOL: OK"
