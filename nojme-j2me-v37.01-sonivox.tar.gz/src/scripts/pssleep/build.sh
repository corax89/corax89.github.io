#!/bin/bash
# Build TestPsSleep.jar — v36.99 [PSC-TURBO-SMALL] selftest.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
STUBS="$D/../keysjar/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestPsSleep.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TPS, , TestPsSleep\r\nMIDlet-Name: TestPsSleep\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestPsSleep*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestPsSleep.jar" META-INF && zip -q "$D/TestPsSleep.jar" *.class )
echo "built: $D/TestPsSleep.jar"
