import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;

/* v36.99 [PSC-TURBO-SMALL] selftest: paint() содержит МЕЛКИЕ сны
 * (5 мс — вне зоны клампа v36.84, который брал только >=10 мс).
 * В турбо на фронтенде (SINGLE-PUMP: paint крутит фронтенд) такие сны
 * должны укорачиваться до 1 мс (diag pss=), НЕ ломая кадры.
 * PASS-критерии (test_pssleep.sh):
 *   - PSS:PAINTED-* напечатаны (paint проходит, исключений нет);
 *   - diag pss= > 0 (кламп сработал);
 *   - ни одного STUCK, WAIT-OK не требуется. */
public class TestPsSleep extends MIDlet {
    static class C extends Canvas {
        int frames = 0;
        long t0 = System.currentTimeMillis();
        protected void paint(Graphics g) {
            g.setColor(0);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(0xFFFFFF);
            g.drawString("PSS " + frames, 8, 8, 20);
            /* хореография мелких снов — та самая, что на телефоне
             * отдавала CPU второму потоку, а в эмуляторе жгла кадр */
            try { Thread.sleep(5); } catch (InterruptedException ie) {}
            try { Thread.sleep(7); } catch (InterruptedException ie) {}
            try { Thread.sleep(3); } catch (InterruptedException ie) {}
            frames++;
            if ((frames % 40) == 0) {
                System.out.println("PSS:PAINTED-" + frames + " ms=" +
                        (System.currentTimeMillis() - t0));
            }
        }
    }
    static C c;
    public void startApp() {
        c = new C();
        Display.getDisplay(this).setCurrent(c);
        new Thread() {
            public void run() {
                for (;;) {
                    c.repaint();
                    try { c.serviceRepaints(); } catch (Throwable t) {}
                    try { Thread.sleep(30); } catch (InterruptedException ie) {}
                }
            }
        }.start();
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
