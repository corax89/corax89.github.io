nojme-j2me v36.74-streamfix1 (2026-10-04)
=========================================

Что это
  Полное дерево исходников эмулятора J2ME (J2ME Loader bloodline) для
  Nintendo Switch (Horizon, devkitA64 + libnx) поверх v36.73-threadpool1.

Сборка NRO
  make switchui          (devkitPro; признак сборки build=v36.74-streamfix1)

Что изменилось против v36.73
  1) [MMAN-GUARD] СБОРКА: threadpool.c больше не требует <sys/mman.h>
     (его нет в libnx — причина, по которой у вас не собиралось).
     Guard-страница стека воркера теперь через svcSetMemoryPermission;
     memalign вместо posix_memalign; при отказе — стек без guard, но
     пуловский (НЕ отказ запуска потока). Ручки: NOJME_VM_MPROTECT=0
     (без guard-страницы), NOJME_VM_NOGUARD=1 (совсем без своего стека).

  2) [STREAM-BATCH] КОРЕНЬ 45-секундной фазы Bounce Tales: стартовый
     автомат игры перепарсивал языковый файл ~25 000 раз, и каждый байт
     шёл через полную цепочку field-lookup'ов (~5 на байт). Хост-замер:
     121 130 407 нативных чтений за 45 с -> после фикса 26 567 (в 4500
     раз меньше), инструкции того же прогона 224M -> 433M. Затронуты:
     skipBytes, skip, read, readFully, readShort/Int/Long/UTF. Это же
     лечит грузные таймеры Zombie Infection (tj~320 мс).

  3) [LIVE-DELIVER]: экран больше не может замереть дольше ~0.5 с,
     пока игра рисует (страховка пути доставки settled-кадров).

  4) [TSTART-E]/[SETTLE-GATE]/td-deep: «вечный Thread.start» в логах
     оказался ДОБРОКАЧЕСТВЕННЫМ (idle GameCanvas-поток событий) — теперь
     это видно сразу; телеметрия для следующего полевого лога.

  Остаточное (не решено, инструментировано): меню Bounce Tales видно
  и анимируется, но не принимает ввод первые ~45-59 с. Кнопки в игру
  доставляются — ворота ввода в самом конечном автомате игры. Если
  повторится на этой сборке — пришлите log.txt: [TSTART-E]-строки и
  td m js=/exec= назовут, чего именно ждёт автомат.

Тесты этой сессии
  scripts/sleeptest (тайминги sleep/skipBytes), scripts/test_bt_stall*
  (хост-репро фазы), test_libnx_api.sh [4/4] (svcSetMemoryPermission).
  Регрессия: make check 33; switch-e2e, spinpause, poolstress,
  charsetstage, covstage, lenient-utf8, scc_pause, soak_gate — ALL
  PASSED; BT/SCC/meTests под ASAN — 0 репортов.
