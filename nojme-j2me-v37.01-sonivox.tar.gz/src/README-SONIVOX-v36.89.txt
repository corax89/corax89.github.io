════════════════════════════════════════════════════════════════════
 NOJME v36.89 — Sonivox (AOSP) MIDI engine integration
════════════════════════════════════════════════════════════════════

ЧТО ЭТО
-------
В сборку NOJME вкомпилирован открытый MIDI-синтезатор Sonivox из AOSP
(репозиторий external/sonivox, ветка arm-wt-22k, лицензия Apache 2.0).
Он заменяет самописный FM-синтезатор NOJME на полноценный семплерный
движок General MIDI со встроенным 22 кГц банком инструментов и
поддержкой загрузки внешних DLS-банков.

Простыми словами: вместо «электронного пианино»-звучания от FM
вы получаете реалистичные сэмплы фортепиано, струнных, духовых,
ударных и т.д. — тот же звук, что был в Android 1.x–8.x.

СОСТАВ ПАКЕТА
-------------
src/midi/sonivox/
├── lib_src/             ← 31 файл .c + .h из AOSP arm-wt-22k/lib_src
│                          (синтезатор, SMF/XMF/iMelody/RTTTL/OTA
│                          парсеры, DLS-bank загрузчик, Schroeder
│                          reverb, голосовой менеджер, микшер)
├── host_src/            ← конфиг + host-обвязка
│   ├── eas.h eas_types.h eas_reverb.h eas_chorus.h jet.h eas_build.h
│   │   eas_config.h eas_debugmsgs.h eas_host.h eas_report.h
│   ├── eas_config.c     ← список парсеров/эффектов (S_EAS_LIB_CONFIG)
│   ├── eas_report.c     ← логирование (заглушено через _NO_DEBUG_PREPROCESSOR)
│   ├── log/log.h       ← NOJME-стаб для AOSP <log/log.h>
│   └── cutils/log.h    ← NOJME-стаб для AOSP <cutils/log.h>
├── include/             ← публичные заголовки libsonivox/
│   └── eas.h eas_types.h eas_reverb.h jet.h
├── eas_host_nojme.c     ← NOJME memory-backed host wrapper + недостающие
│                          EAS_OpenMIDIStream / WriteMIDIStream /
│                          CloseMIDIStream (этих функций НЕ оказалось
│                          в AOSP-снапшоте — их пришлось дописать)
├── LICENSE-AOSP.txt     ← Apache 2.0 NOTICE (репозиторий external/sonivox)
└── LICENSE-arm-wt-22k.txt ← Apache 2.0 NOTICE (arm-wt-22k subdir)

src/midi/midi.c          ← Полная переработка: midi.c теперь тонкий
                          shim, делегирующий всё в Sonivox EAS API.
                          Старая FM-реализация сохранена как
                          src/midi/midi_legacy_fm.c.bak (1617 строк,
                          НЕ компилируется).

src/midi/midi.h          ← MidiFile struct расширен новыми полями
                          (eas_data, eas_stream, eas_locator,
                          is_midi_stream, leftover_buf, leftover_count)
                          в КОНЦЕ структуры — layout-совместимо с
                          старым кодом, обращения к midi->data,
                          midi->size, midi->sequencer остались
                          валидны.

Makefile                 ← Добавлены:
                          - SONIVOX_LIB_C / SONIVOX_HOST_C / SONIVOX_C_SRCS
                          - SONIVOX_INCS / SONIVOX_DEFS (см. ниже)
                          - Правила компиляции $(LR_OBJDIR)/midi/sonivox/%.o
                            и аналоги для app/headless/switch/switchui
                          - Правила для midi/%.o (для midi.c) с
                            добавкой SONIVOX_INCS+DEFS — иначе eas.h
                            не находится

scripts/test_sonivox.c   ← Дымовой тест: грузит крошечный SMF
                          (4 ноты C-E-G-C арпеджио), рендерит 1 с,
                          проверяет, что пик > 1000 (т.е. синтезатор
                          реально издаёт звук). Тот же тест для
                          midi_load_empty() + midi_note_on_file().

ФЛАГИ СБОРКИ (SONIVOX_DEFS)
---------------------------
  -DNUM_OUTPUT_CHANNELS=2   stereo output (22050 Hz bank распаковывается в 44100)
  -D_SAMPLE_RATE_44100       матч с AUDIO_SAMPLE_RATE в media.c
  -DMAX_SYNTH_VOICES=64      полифония
  -DEAS_WT_SYNTH             wavetable synth (использует встроенный wt_22khz банк)
  -D_8_BIT_SAMPLES           банк хранится как 8-bit PCM (маленький размер)
  -D_FILTER_ENABLED          резонансный фильтр в голосе
  -D_REVERB_ENABLED          Schroeder reverb (4 comb + 2 allpass)
  -DDLS_SYNTHESIZER          загрузка DLS банков (на будущее — внешние банки)
  -DJET_INTERFACE            JET API (нужно для одного из парсеров)
  -D_IMELODY_PARSER          iMelody рингтон-парсер
  -D_RTTTL_PARSER             RTTTL рингтон-парсер
  -D_OTA_PARSER               OTA рингтон-парсер
  -D_XMF_PARSER               XMF контейнер-парсер
  -D_NO_DEBUG_PREPROCESSOR    отключить verbose debug message table
  -include stdbool.h           Sonivox код использует `true` без include
  -Wno-unused-parameter        Sonivox местами не использует pEASData и т.п.
  -Wno-stringop-truncation     strncpy в eas_imelody.c спамит предупреждениями

НАМЕРЕННО ОТКЛЮЧЕНО (нет исходников в AOSP-снапшоте):
  _CHORUS_ENABLED  — нет eas_chorus.c (только заголовок eas_chorus.h)
  MMAPI_SUPPORT    — нет eas_tonecontrol.c
  _IMA_DECODER     — нет eas_imaadpcm.c / eas_ima_tables.c
  _WAVE_PARSER     — нет eas_wavefile.c
  _SMAF_PARSER     — нет eas_smaf.c
  _CMX_PARSER / _MFI_PARSER — нет eas_cmf.c
  NATIVE_EAS_KERNEL — УБРАН. Этот дефайн в оригинале указывает, что
                      WT_Interpolate/WT_VoiceGain/WT_VoiceFilter
                      предоставлены АРМ-ассемблером (файлы ARM-E_*.s).
                      Без ассемблера C-фолбэки в eas_wtengine.c НЕ
                      компилируются (guard `#if !defined(NATIVE_EAS_KERNEL)`).
                      Так что для всех не-ARM таргетов (x86_64, MinGW,
                      Switch aarch64, M17 ARMv7) — оставляем этот дефайн
                      выключенным, чтобы C-реализации собрались.

КАК ЭТО РАБОТАЕТ АРХИТЕКТУРНО
----------------------------
1) midi_load(data, size) из media.c:
   - alloc_sequencer() создаёт MidiSequencer (старые FM-поля обнулены,
     Sonivox их не использует)
   - EAS_Init(&eas_data) — создаёт независимый инстанс Sonivox
   - Создаётся nojme_eas_locator { handle, readAt, size } — callbacks,
     читающие прямо из memory (data,size). Никакого fopen!
   - EAS_OpenFile(eas_data, locator, &stream) — Sonivox сам парсит SMF
   - EAS_Prepare + EAS_ParseMetaData — получаем честную длительность

2) midi_load_empty() (для device://tone и device://midi):
   - EAS_Init + EAS_OpenMIDIStream (эта функция реализована в
     eas_host_nojme.c — в AOSP-снапшоте её не было, см. ниже)
   - Создаётся S_SYNTH через VMInitMIDI; midi_note_on_file и др.
     отправляют 2-3 байта через EAS_WriteMIDIStream, Sonivox
     парсит их через EAS_ParseMIDIStream в eParserModePlay.

3) midi_play() → EAS_Resume(stream)
   midi_stop() → EAS_Pause(stream)
   midi_set_volume() → EAS_SetVolume(stream, 0..100)
   midi_set_position_ms() → EAS_Locate(stream, ms)
   midi_get_duration_ms() → из total_time_us (взятой из EAS_ParseMetaData)

4) midi_generate_samples(midi, buf, samples):
   EAS_Render всегда отдаёт ровно BUFFER_SIZE_IN_MONO_SAMPLES фреймов
   (256 фреймов = 512 шортов при стерео 44100 Hz). Мы звеним её в
   цикле, пока не заполним запрошенный пользователем буфер, избыток
   складываем в leftover_buf (поле в MidiFile). Стерео-интерливинг
   встроен в Sonivox при NUM_OUTPUT_CHANNELS=2.

5) midi_advance_time() — no-op. Sonivox использует аудио-часы:
   EAS_Render одновременно парсит трек и рендерит сэмплы. Это
   совпадает с тем, что v36.27 в media.c требует («продвижение ровно
   на samples/44100 секунд синхронно с рендером»).

НЕДОСТАЮЩИЕ ФУНКЦИИ AOSP
------------------------
В vendored AOSP snapshot реализаций EAS_OpenMIDIStream / WriteMIDIStream /
CloseMIDIStream не оказалось — в eas.h они объявлены, но не реализованы
в lib_src/eas_public.c. Их приходится дописать самим. Это сделано в
src/midi/sonivox/eas_host_nojme.c (функции внизу файла):
  - EAS_OpenMIDIStream: VMInitMIDI + EAS_InitMIDIStream + слот в
    pEASData->streams[] (pParserModule=NULL, чтобы EAS_Render
    пропускал этот слот — он не SMF, а «живой» MIDI вход)
  - EAS_WriteMIDIStream: побайтовый EAS_ParseMIDIStream в eParserModePlay
  - EAS_CloseMIDIStream: VMMIDIShutdown + освобождение слота

Также Sonivox использует AOSP-специфичные заголовки <log/log.h> и
<cutils/log.h> (с макросами ALOGE, ALOGI, android_errorWriteLog и пр.).
Этих заголовков у нас нет — сделаны стабы:
  src/midi/sonivox/host_src/log/log.h        — гасит все ALOG* в no-op,
                                                android_errorWriteLog — empty stub
  src/midi/sonivox/host_src/cutils/log.h     — include "log/log.h"

MEMORY-BACKED FILE I/O
----------------------
Sonivox спроектирован под AOSP fs, но архитектурно EAS_FILE_LOCATOR —
это callback struct { handle, readAt, size }. NOJME держит весь
SMF уже в памяти (MidiFile.data), так что мы оборачиваем его в
nojme_loc_handle { const uint8_t *data; int size; } и передаём в
EAS_OpenFile. Никакого fopen на Switch / M17 / hbmenu не происходит.

ПРОВЕРКА СБОРКИ
--------------
На чистой системе без devkitPro:

  make platform=linux     # 2.4 МБ .so, все символы EAS_* в nm
  make headless            # 2.4 МБ standalone, те же символы

Проверка символов:
  nm bin/nojme_libretro.so | grep -E " EAS_" | wc -l   # ~50 функций
  nm bin/nojme_libretro.so | grep " midi_"             # ~25 функций
  nm bin/nojme_libretro.so | grep "U "                 # только libc/libm

Для Switch/M17/Windows — нужны их toolchain'ы (devkitPro, MinGW, arm-gcc).
Но правила сборки в Makefile для всех платформ добавлены зеркально
правилам AMR — поэтому ожидается, что они соберутся так же (Sonivox
кросс-платформенный чистый C).

ЛИЦЕНЗИОННАЯ ЧИСТОТА
--------------------
Sonivox — Apache 2.0. Не LGPL, не GPL. Это значит:
  - Статическая линковка в Switch NRO БЕЗ проблем
  - Поставка исходников вместе с NRO (как делается сейчас) ОК
  - Никаких обязательств по раскрытию NOJME-кода нет
  - NOTICE файлы сохранены в src/midi/sonivox/LICENSE-*.txt

Это контрастирует с FluidLite (LGPL-2.1) и WildMidi (LGPL-3.0),
которые для Switch статической линковки требуют либо динамической
линковки (невозможно в NRO), либо раскрытия объектников.

ВОЗМОЖНЫЕ НАСТРОЙКИ ДАЛЬШЕ
--------------------------
- Загрузить внешний DLS банк (Sonivox поддерживает через EAS_LoadDLS):
  у NOJME уже есть настройки в settings.ini — можно добавить опцию
  "midi_soundfont" или "midi_dls_bank" и подгружать банк с SD-карты
  для платформ, где FS доступна. На Switch — оставить встроенный
  22 кГц банк (он довольно приличный, ~2 МБ).

- Заменить банк на 44.1 кГц / 16-bit: для этого нужно либо найти
  в AOSP wt_44khz.c (он существует, но не входит в этот дроп),
  либо сгенерировать 16-битную версию wt_22khz.c. Это даст чуть
  лучшее отношение сигнал/шум на тихих голосах.

- Включить _CHORUS_ENABLED: требует eas_chorus.c, которого в этом
  дропе AOSP нет. Либо найти в более полном AOSP, либо написать
  стаб.

ЧТО ДЕЛАТЬ ДАЛЬШЕ
-----------------
1. Собрать и проверить на Switch: `make switch` → nojme_switch.nro
   (нужен devkitPro). Запустить J2ME-игру с midi-музыкой (Asphalt 3,
   Tower Bloxx, любая gameloft 2007-2009). Сравнить звучание с
   предыдущей FM-версией.

2. Если на Switch NRO не влезает из-за размера wt_22khz.c (~2 МБ
   бинарника после -O2) — нужно либо ужать банк (превратить в
   4-bit ADPCM, что поддерживает Sonivox), либо подгружать с SD.

3. Прислать баг-репорт, если конкретная игра звучит странно — Sonivox
   обычно играет GM-файлы корректно, но встречаются не-GM банки
   у некоторых J2ME-игр (Nokia-specific патчи), которые Sonivox
   может не распознать.

ОРИГИНАЛ SONIVOX
----------------
Источник: https://android.googlesource.com/platform/external/sonivox
Ветка: master (захват 2026-10-07)
Лицензия: Apache 2.0 (см. LICENSE-AOSP.txt)

════════════════════════════════════════════════════════════════════
