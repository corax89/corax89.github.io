noJME v36.100-zgfx3 (2026-10-09)
================================

ЗАДАЧА ПОЛЯ
-----------
«На свиче недоступен запуск с флагами, вот новый лог. В игре много
пиксельных эффектов, скорее всего именно они съедают весь бюджет и именно
обработку графики нужно ускорять» (Zombie Infection, лог v36.99-zperf2).

ДИАГНОЗ ПО НОВОМУ ЛОГУ (1352 строки, v36.99-zperf2)
---------------------------------------------------
* Фикс загрузки v36.98 в поле ПОДТВЕРЖДЁН повторно: обе фазы дошли до
  геймплея, 0 SPIN-BREAK.
* Тяжёлый уровень (m3_0=627K + m4_0=427K): loop=pr=18..29 за 5-с окно
  => 3.6-5.8 FPS. rj=444-935 мс (худший paint-насос), mx=463-956.
* ГЛАВНАЯ УЛИКА: vi=8.4M инстр/с в геймплее против vi=17-19M/с на чистом
  байткоде (6-с STUCK парсинга уровня: vi=17.3M/с). Половина времени
  кадра ВМ НЕ исполняет байткод => нативные вызовы + handshake.
* pss=0 (v36.99 кламп мелких снов НЕ виноват), gc=0, pv=249-596 мс/окно
  (present софтовым рендерером — известная цена v36.82), vvw=5000/5000
  (раннер t2 100% в serviceRepaints-handshake — дизайн игры).
* Итог: бюджет кадра уходит в НАТИВНУЮ графику внутри paint() —
  гипотеза пользователя о пиксельных эффектах подтверждена косвенно;
  прямо её доказывает новая телеметрия [GFX-PERF] (см. ниже).

ХОСТОВОЙ РЕПРОДУКТОР (scripts/pixbench)
---------------------------------------
PixelBench.jar — 240x320 мидлет, воспроизводящий кадр тяжёлого уровня
Gameloft: 150 опак-тайлов drawImage, 80 drawRegion TRANS_MIRROR с мягкой
альфой, полноэкранный drawRGB(processAlpha=true) «туман», getRGB+Java-
цикл+drawRGB «tint», getRGB+Java+createRGBImage+drawImage «flash»,
300 fillRect + 100 drawLine, и живой repaint+serviceRepaints цикл.
Прогон v36.99 (хост): полноэкранный alpha-оверлей 5.6 мс (скаляр),
createRGBImage 6 мс, зеркальные спрайты 0.7 мс/кадр — узкие места
найдены ДО правки кода.

ФИКСЫ v36.100
-------------
(1) [DRAWRGB-SCR-SPAN] render.c midp_blit_rgb — ГЛАВНЫЙ.
    drawRGB(processAlpha=1) на ЭКРАННОМ gfx (owner_image==NULL) шёл по
    точной Porter-Duff формуле blit_rgb_blend_px с ТРЕМЯ целочисленными
    делениями на пиксель (udiv ~10-20 тактов на A57: полноэкранный туман
    240x320 = ~230K делений = миллионы тактов за кадр). Но альфа экрана
    ВСЁ РАВНО сбрасывается стадией презентации (XRGB8888/RGB565)!
    Теперь экран берёт SIMD src-over спан span_src_over_span (как
    drawImage): нет делений, каналы те же +-2 младших бита, альфа 0xFF
    вместо 254 — неразличимо и всё равно отбрасывается при выводе.
    Спан применим и к ОБРАЗУ, который весь непрозрачен (alpha-скан:
    offscreen-буфер после фонового блита — идиома Gameloft): dstA==0xFF
    у каждого пикселя, точная формула дала бы outA 254/255; спан пишет
    0xFF => образ ОСТАЁТСЯ all-opaque и финальный drawImage берёт
    memcpy вместо бленда. Пиксели с alpha<0xFF до вызова остаются на
    точной формуле (их читают getRGB/блендинг).
    Рубильник: NOJME_DRAWRGB_SCR_SPAN=0 (старая семантика).
    ИЗМЕРЕНО на хосте (PixelBench [GFX-PERF]): экранный полноэкранный
    alpha-оверлей 5.6 мс -> 0.094 мс (x60); opaque-image alpha 0.52 ->
    0.12 мс (вкл. ре-скан); end-to-end paint-фаза 131 -> 141 FPS.
    На A57 ожидание: ~3-5 мс делений с кадра + memcpy-путь финального
    блита состава.

(2) [CREATERGB-FOLD] graphics.c midp_image_create_from_rgb.
    Скалярный цикл (ветвление process_alpha + побайтовый скан
    непрозрачности в каждом пикселе) -> memcpy + SIMD-стадии
    (bit-identical): processAlpha=0 => nojme_span_or_opaque
    (0xFF000000|src&0xFFFFFF), processAlpha=1 => memcpy +
    nojme_span_all_alpha_ff (точный OR-скан альфы). calloc -> malloc в
    midp_image_create: все пути заполняют пиксели до первого чтения
    (mutable — белый memset, immutable — циклы конверсии); 300-КБ
    обнуление полноэкранного createRGBImage было чистой тратой.
    ИЗМЕРЕНО: createRGBImage 6 мс -> 0.1 мс на полноэкранный вызов (x60).
    На A57: ~30-60 мс с эффект-кадра.

(3) [GFX-PERF] include/gfxperf.h + display.c/render.c/opcodes.c/
    switch_trace.c — ПОЛЕВАЯ ТЕЛЕМЕТРИЯ, всегда включённая
    (на Switch флаги недоступны — прямой вывод из отчёта пользователя).
    Каждые 5 с вместе с diag печатает:
      [GFX-PERF] di=.. dio=.. dri=.. drrot=.. dro=.. dras=../..мс
      drai=.. gr=.. crgb=.. ci=.. prim=.. fl=.. nat=../..мс
    di/dio — drawImage (всего/memcpy-опак), dri/drrot — drawRegion
    (всего/rot90-270), dro — drawRGB опак, dras — drawRGB-alpha быстрый
    спан, drai — drawRGB-alpha точная формула, gr — getRGB, crgb —
    createRGBImage, ci — createImage(w,h), prim — примитивы/текст,
    fl — flushGraphics, nat — ВСЕ нативы (знаменатель бюджета: nat_ms
    минус графика = прочие нативы). Хуки: тонкие обёртки в таблицах
    нативов (ранние return тоже считаются), тотал — на всех 6 сайтах
    диспетчеризации opcodes.c с TLS-защитой от вложенности
    (LayerManager.paint не считается дважды). Цена ~0.05% (2x25 нс
    clock_gettime + 2 атомика на вызов при худших наблюдённых ~50K/с).
    СЛЕДУЮЩИЙ полевой лог однозначно назовёт, ЧТО ест остаток кадра.

СБОРКА/ТЕСТЫ (хост)
-------------------
* make check 33 OK; сборки switchui-verify / j2me-headless /
  libretro platform=linux — 0 предупреждений.
* NEON-TEST самотест рендера: ALL PASS, включая НОВЫЙ кейс
  «creatergb stages» (bit-exact новых SIMD-стадий vs скаляр) и старые
  пиксельные A/B (fillTriangle/drawRegion xf/glyphs/getRGB/rgb565/
  11 растеризаторных режимов — 0 расхождений).
* Регрессии поведенческих фиксов — ВСЕ PASSED: fenceslow (2 прохода),
  fencewait, spinbreak (CAUGHT x2 @12001), spinpause (0 выстрелов),
  spingate x3, fencedeadlock, keybudget (41 FENCE-DEADLOCK / доставлено
  / GAME-DONE / rc=0 / 0 KEY-BUDGET), imsloop (RECOVERED catches=0 ->
  PHASE2 -> JOIN-CAP -> DESTROYED), stealgate (A-SUPPRESSED + B-STEAL +
  B-REACQUIRED + PHASES-DONE + DESTROYED), pssleep (on/off).
* whitebox-линковка switch_trace.c без ядра проверена вручную
  (слабые ссылки g_gfxp_* разрешаются в NULL, diag молчит).

ПОЛЕВОЕ ПРИМЕНЕНИЕ
------------------
Пересобрать NRO: make switchui (devkitPro). Признак в логе:
  build=v36.100-zgfx3-2026-10-09
Главный чек: Zombie Infection тяжёлый уровень — FPS должен подрасти
(экранные/опак-буферные alpha-эффекты подешевели в десятки раз;
createRGBImage-эффекты — тоже). Затем прислать log.txt: строка
[GFX-PERF] разложит остаток кадра по API и скажет, куда бить дальше
(кандидаты: drawRegion-rot, JAVA-циклы игры — это уже к интерпретатору,
present софтовым рендерером).
Запасной рубильник: NOJME_DRAWRGB_SCR_SPAN=0 (или строка в
sdmc:/switch/j2me/env.txt) возвращает точную формулу drawRGB.
