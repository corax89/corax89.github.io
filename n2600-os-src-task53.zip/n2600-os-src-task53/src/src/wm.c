/* wm.c — оконный менеджер N2600-OS.
 * Композитинг: backbuffer -> LFB. Перерисовываются только «грязные» области:
 * полный кадр нужен при перетаскивании/изменении z-порядка, в остальных
 * случаях обновляются только прямоугольники (курсор, текст, часы). */
#include "wm.h"
#include "fb.h"
#include "gfx2d.h"   /* [2D-ускорение]: аппаратный курсор (voodoo3/gma3600_2d) */
#include "mem.h"
#include "mouse.h"
#include "rtc.h"
#include "string.h"
#include "task.h"
#include "timer.h"
#include "sync.h"
#include "apps.h"
#include "e1000.h"
#include "net.h"
#include "sound.h"   /* [HDA-SWVOL] громкость для панели задач */
#include "utf8.h"
#include "ramfs.h"   /* THEME.CFG и WM.CFG (настройки интерфейса) */

/* ---------------- ПЕРФ/UX: константы анимаций и троттлинга ----------------
 * 1 тик = 1 мс (таймер 1000 Гц). Анимации — 3 шага по ~20 мс (~60 мс
 * всего): заметно глазу, но почти бесплатно (частичные касания).
 * Троттлинг перетаскивания: с содержимым — 25 мс (~40 кадр/с), в
 * быстром режиме (без канваса) — 12 мс. */
#define WM_ANIM_STEPS   3
#define WM_ANIM_MS      20
#define WM_MENU_ANIM_STEPS 3
#define WM_DRAG_MS_CONTENT 25
#define WM_DRAG_MS_FAST    12
#define WM_RESIZE_DEFER    24   /* попытка пересоздания canvas раз в
                                 * ~24 прохода главного цикла (~15-30 мс);
                                 * было 3 прохода — malloc мегабайта
                                 * сотни раз в секунду на Atom */

/* --------------------------- палитра интерфейса --------------------------- */
#define COL_ACCENT      fb_rgb(0x3E, 0x7D, 0xBF)
#define COL_BORDER      fb_rgb(0x34, 0x38, 0x3E)
#define COL_TITLE_FOC   fb_rgb(0x1E, 0x4A, 0x73)
#define COL_TITLE       fb_rgb(0x25, 0x2A, 0x30)
#define COL_CLOSE       fb_rgb(0x8C, 0x2E, 0x2E)
#define COL_CLOSE_HOT   fb_rgb(0xB0, 0x38, 0x38)
#define COL_TBAR        fb_rgb(0x12, 0x16, 0x1B)
#define COL_TBAR_LINE   fb_rgb(0x2C, 0x31, 0x38)
#define COL_BTN         fb_rgb(0x1B, 0x21, 0x27)
#define COL_BTN_ACT     fb_rgb(0x24, 0x43, 0x5F)
#define COL_MENU        fb_rgb(0x17, 0x1C, 0x22)
#define COL_MENU_LINE   fb_rgb(0x30, 0x36, 0x3E)
#define COL_MENU_HOT    fb_rgb(0x24, 0x43, 0x5F)
#define COL_TEXT        fb_rgb(0xE6, 0xEA, 0xEE)
#define COL_TEXT_DIM    fb_rgb(0x9A, 0xA3, 0xAC)

static window_t *wins[WM_MAX_WINDOWS];
static int nwin = 0;
static u32  win_serial_next = 1;   /* FIX [W1]: стабильный порядок таскбара */

static window_t *drag_win = NULL;
static int drag_dx = 0, drag_dy = 0;
static window_t *resize_win = NULL;   /* окно, размер которого меняем */
static int resize_start_w = 0, resize_start_h = 0;
static int resize_start_x = 0, resize_start_y = 0;
static window_t *pending_close = NULL;
static int menu_open = 0, menu_hover = -1;
/* СЕССИЯ 85: клавиатурный фокус меню Пуск (запрос пользователя: Win
 * открывает меню с фокусом, стрелки/Enter/Esc им управляют). -1 = нет;
 * меню_hover мыши — независим. Разделитель при навигации перескакивается. */
static int menu_kbd_sel = -1;

/* ---- анимация ЗАКРЫТИЯ меню Пуск: 0 = нет, иначе осталось шагов.
 * Меню логически закрыто (menu_open == 0) — клики проходят сквозь;
 * остаётся видимой нижняя полоса, уменьшающаяся к кнопке Пуск. ---- */
static int menu_closing = 0;

/* ---- анимация меню Пуск: 0 = нет, иначе осталось шагов ---- */
static int menu_anim = 0;
static u32 menu_anim_tick = 0;

/* ---- троттлинг перетаскивания/ресайза (1 тик = 1 мс) ---- */
static u32 last_drag_tick = 0;
static u32 last_resize_tick = 0;

/* НЕЯВНЫЙ ЗАХВАТ МЫШИ (сессия 20, FIX «скроллбар перестаёт скроллить»):
 * окно, в котором нажали ЛКМ. Пока кнопка удерживается, ВСЕ события
 * мыши (движение, чужие нажатия, отпускание) доставляются ЭТОМУ окну,
 * даже если курсор ушёл за его пределы — стандартное поведение
 * оконных систем (drag capture). Приложение гарантированно видит
 * отпускание и не остаётся в состоянии drag (ползунок скроллбара,
 * выделение текста, рисование мышью). */
static window_t *lmb_win = NULL;

static int cur_x = 0, cur_y = 0;        /* позиция курсора (последняя отрисованная) */

/* ---- мини-блокировки (см. комментарий в секции многопоточного WM) ---- */
static volatile int wm_glock = 0;
/* СЕССИЯ 79 [WM-NOSTALL]: сколько подряд кадров композитор не смог
 * взять wm_glock за отведённые мс (диагностика зависшего держателя). */
static u32 wm_glock_stall = 0;
static u32 wm_glock_stall_t0 = 0;   /* тик начала непрерывного занятости */
/* [WM-SEIZE]: дольше этого (мс) непрерывного занятости — отбор замка
 * у зависшей задачи (дольше sync-таймаута 20 с: честная фора). */
#define WM_GLOCK_SEIZE_MS 25000u

/* ---- мини-блокировки ----
 * ЕДИНАЯ реализация — sync.h (s_lock/s_unlock/s_trylock):
 *   * значение = владелец+1 → ждущий видит, КТО держит;
 *   * если владелец убит, держа блокировку (task_kill/ватчдог) —
 *     блокировка освобождается силой: раньше это НАМЕРТВО фризило
 *     kmain (composite ждёт wm_glock, wm_key ждёт qlock окна —
 *     а kmain делает мышь/клавиатуру/композитинг для всей системы);
 *   * если владелец завис внутри секции > 20 с — блокировка
 *     отбирается (busy-loop ватчдог не видит).
 * Обёртки оставлены, чтобы не менять ~40 мест вызова. */

static void wl_lock(volatile int *l)
{
    s_lock(l);
}

/* СЕССИЯ 79 [WM-NOSTALL]: ограниченная попытка захвата для горячего
 * пути kmain (запрос пользователя: «зависшие задачи не должны вешать
 * оконный менеджер»). Композитор/отправка событий НИКОГДА не ждут
 * зависшего держателя бесконечно: не успели за tmo мс — пропускаем
 * кадр/событие и продолжаем (следующий кадр догонит). */
static int wl_trylock_ms(volatile int *l, u32 tmo_ms)
{
    return s_trylock_ms(l, tmo_ms);
}

static void wl_unlock(volatile int *l)
{
    s_unlock(l);
}

/* СЕССИЯ 81 [KMAINFAULT-TEST]: флаг «уронить следующий кадр композитора».
 * Ставится командой kmainfault (apps.c) — детерминированная проверка
 * KMAIN-RECOVER (см. блок в wm_frame). */
static volatile int g_wm_fault_next_frame = 0;

void wm_test_kmain_fault(void)
{
    g_wm_fault_next_frame = 1;
}

/* СЕССИЯ 81 [KMAIN-RECOVER]: внешний отпуск wm_glock после CPU-исключения
 * в kmain. Композитор берёт glock на кадр (под ним — wins[], canvas,
 * compose); если кадр оборван исключением, замок «зависает занятым» и
 * следующий кадр ждет его вечно (bounded-trylock помогает, но
 * 25-секундный отбор — слишком дорогая цена за пропуск кадра).
 * Вызывается ТОЛЬКО из exc_panic (idt.c, BSP, IF=0) — конкуренции нет.
 * Счётчик stall тоже сбрасываем: «серия занятых кадров» начата этим
 * же сбоем, а не зависшим держателем.
 *
 * [KLOCK-NOSTEAL-СЕСТРА] (полевой лог VMware, сессия 2): значение
 * wm_glock = владелец+1 (sync.h) — отпускаем ТОЛЬКО владение kmain
 * (==1). Безусловный сброс снимал glock у ЖИВОЙ задачи другого ядра,
 * открывая окно параллельной секции (тот же класс «отбора», из-за
 * которого в поле молча погибал mquickjs). Чужой держатель жив и
 * отпустит замок сам — максимум один «занят» кадр композитора. */
void wm_glock_panic_release(void)
{
    extern void serial_puts(const char *s);
    if (wm_glock == 1) {              /* 1 = владелец kmain (task 0) */
        wm_glock = 0;
        serial_puts("[wm] wm_glock отпущена после исключения kmain\n");
    }
    wm_glock_stall = 0;
    wm_glock_stall_t0 = 0;
}

/* Попытка захвата с ограниченным числом повторов (для kmain):
 * никогда не блокируется надолго; мёртвого владельца чинит s_trylock. */
static int wl_trylock(volatile int *l, int spins)
{
    for (int i = 0; i < spins; i++) {
        if (s_trylock(l)) return 1;
    }
    return 0;
}


static int cursor_visible = 0;
static int blink_state = 0;
static int tooltip_win_idx = -1;         /* индекс окна для tooltip (-1 = нет) */
static int tooltip_timer = 0;            /* таймер показа tooltip (тики) */

/* ================= настройки интерфейса (WM.CFG на RAM disk) ================= */
#define WM_OPT_FILE "WM.CFG"

static int opt_drag_content = 1;   /* рисовать содержимое при перетаскивании */
static int opt_animations   = 1;   /* анимации меню и разворачивания окон */

int wm_opt_drag_content(void) { return opt_drag_content; }
int wm_opt_animations(void)   { return opt_animations; }

static int wm_opt_parse_int(const char *s, int def)
{
    int v = 0, any = 0;
    while (*s == ' ') s++;
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; any = 1; }
    return any ? v : def;
}

static void wm_opt_save(void)
{
    if (!ramfs_ready()) return;
    char buf[64];
    int L = snprintf(buf, sizeof(buf), "dragcontent=%d\nanim=%d\n",
                     opt_drag_content ? 1 : 0, opt_animations ? 1 : 0);
    ramfs_delete(WM_OPT_FILE);
    if (ramfs_create(WM_OPT_FILE, (u32)L + 1))
        ramfs_write(WM_OPT_FILE, buf, (u32)L + 1);
}

static void wm_opt_load(void)
{
    opt_drag_content = 1;
    opt_animations = 1;
    if (!ramfs_ready()) return;
    char buf[96];
    u32 n = ramfs_read(WM_OPT_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return;
    buf[n] = 0;
    const char *p = buf;
    while (*p) {
        const char *e = p;
        while (*e && *e != '\n' && *e != '\r') e++;
        char saved = *e;
        *(char *)e = 0;
        if (strncmp(p, "dragcontent=", 12) == 0)
            opt_drag_content = wm_opt_parse_int(p + 12, 1) ? 1 : 0;
        else if (strncmp(p, "anim=", 5) == 0)
            opt_animations = wm_opt_parse_int(p + 5, 1) ? 1 : 0;
        *(char *)e = saved;
        p = (*e) ? e + 1 : e;
    }
}

void wm_opt_set_drag_content(int on)
{
    on = on ? 1 : 0;
    if (opt_drag_content == on) return;
    opt_drag_content = on;
    wm_opt_save();
}

void wm_opt_set_animations(int on)
{
    on = on ? 1 : 0;
    if (opt_animations == on) return;
    opt_animations = on;
    wm_opt_save();
}

/* служебные действия (реализованы в kernel.c) */
extern void sys_reboot(void);
extern void sys_poweroff(void);

/* ------------------------------- курсор ------------------------------- */
static const char *cursor_map[19] = {
    "X           ",
    "XX          ",
    "X*X         ",
    "X**X        ",
    "X***X       ",
    "X****X      ",
    "X*****X     ",
    "X******X    ",
    "X*******X   ",
    "X********X  ",
    "X*****XXXXX ",
    "X**X**X     ",
    "X*X X**X    ",
    "XX  X**X    ",
    "X    X**X   ",
    "     X**X   ",
    "      XX    ",
    "            ",
    "            "
};

/* ПЕРФ (запрос пользователя): спаны курсора разбираются ОДИН раз при
 * инициализации (cursor_build_spans, вызов в wm_init), а не на каждый
 * кадр с курсором: draw_cursor — плоский цикл по готовым отрезкам. */
typedef struct {
    u8  x, y, len;
    u32 color;
} cursor_span_t;

static cursor_span_t cursor_spans[96];
static int cursor_nspans = 0;

static void cursor_build_spans(void)
{
    u32 black = fb_rgb(0, 0, 0), white = fb_rgb(0xFF, 0xFF, 0xFF);
    int max = (int)(sizeof(cursor_spans) / sizeof(cursor_spans[0]));
    cursor_nspans = 0;
    for (int r = 0; r < 19; r++) {
        int c = 0;
        while (c < 12) {
            char ch = cursor_map[r][c];
            if (ch == ' ') { c++; continue; }
            int start = c;
            while (c < 12 && cursor_map[r][c] == ch) c++;
            if (cursor_nspans >= max) return;
            cursor_spans[cursor_nspans].x = (u8)start;
            cursor_spans[cursor_nspans].y = (u8)r;
            cursor_spans[cursor_nspans].len = (u8)(c - start);
            cursor_spans[cursor_nspans].color = (ch == 'X') ? black : white;
            cursor_nspans++;
        }
    }
}

static void draw_cursor(void)
{
    /* ПЕРФ: раньше до 228 вызовов fb_fill_rect(1x1) на каждый кадр
     * с курсором; затем разбор спанов на каждый кадр. Теперь готовый
     * список отрезков (см. cursor_build_spans). */
    for (int i = 0; i < cursor_nspans; i++) {
        cursor_span_t *s = &cursor_spans[i];
        fb_fill_rect(cur_x + s->x, cur_y + s->y, s->len, 1, s->color);
    }
}

/* -------------------- частичные касания (ПЕРФ) --------------------
 * Вместо fb_touch_all() (полный кадр: фон + все окна + таскбар) каждая
 * операция помечает ТОЛЬКО изменённые области: прямоугольник окна,
 * полосу заголовка, таскбар или объединение старого/нового
 * прямоугольников. На 1280x600 полный кадр — сотни тысяч пикселей,
 * частичное касание — тысячи; на Atom это разница между «тормозит»
 * и «мгновенно». */

static void wm_touch_rect(int x, int y, int w, int h)
{
    if (w > 0 && h > 0) fb_touch(x, y, w, h);
}

static void wm_touch_taskbar(void)
{
    wm_touch_rect(0, (int)fb_height() - TBAR_H, (int)fb_width(), TBAR_H);
}

static void wm_touch_window(window_t *w)
{
    if (w && !w->minimized) wm_touch_rect(w->x, w->y, w->w, w->h);
}

static void wm_touch_title(window_t *w)
{
    if (w && !w->minimized) wm_touch_rect(w->x, w->y, w->w, TITLE_H + 2);
}

/* объединение двух прямоугольников (для maximize/unmaximize/drag:
 * вакантная полоса + новая позиция одним касанием) */
static void wm_touch_union_rect(int ax, int ay, int aw, int ah,
                                int bx, int by, int bw, int bh)
{
    if (aw <= 0 || ah <= 0) { wm_touch_rect(bx, by, bw, bh); return; }
    if (bw <= 0 || bh <= 0) { wm_touch_rect(ax, ay, aw, ah); return; }
    int x0 = ax < bx ? ax : bx;
    int y0 = ay < by ? ay : by;
    int x1 = (ax + aw) > (bx + bw) ? (ax + aw) : (bx + bw);
    int y1 = (ay + ah) > (by + bh) ? (ay + ah) : (by + bh);
    wm_touch_rect(x0, y0, x1 - x0, y1 - y0);
}

/* Единая модель фокуса (FIX несогласованности): заголовки, таскбар и
 * клавиатура считают фокусным одно и то же — верхнее НЕ свёрнутое
 * окно (раньше draw_window смотрел на wins[nwin-1], таскбар — на
 * top_visible_window, и при свёрнутом верхнем окна расходились). */
static int top_visible_window(void);
static int menu_visible_h(void);   /* анимация меню (используется в composite) */
static void menu_toggle(void);     /* кнопка «Меню» / клавиша Win */
static int menu_key_nav(const key_event_t *ev);  /* сессия 85: стрелки в меню */

static window_t *wm_focused_window(void)
{
    int idx = top_visible_window();
    return (idx >= 0) ? wins[idx] : NULL;
}

/* Касание областей при движении курсора: если старый и новый
 * прямоугольники курсора близко, одно объединённое касание дешевле
 * двух отдельных (меньше записей в списке dirty, меньше проходов
 * композитора). Порог подобран по площади: 2*12*19=456 px против
 * объединения. */
static void wm_touch_cursor_move(int ox, int oy, int nx, int ny)
{
    /* Сессия 84: при АППАРАТНОМ курсоре трогать область курсора не нужно
     * вовсе — плоскость курсора рисуется поверх кадра самой видеокартой.
     * Раньше на каждый ход мыши fb_touch вызывал перекомпоновку прямо-
     * угольника в compose (VRAM) + 2D-блит + ожидание простоя — из-за
     * этого курсор двигался медленнее, чем программный. */
    if (!cursor_visible || gfx2d_cursor_ready()) return;
    int x0 = ox < nx ? ox : nx;
    int y0 = oy < ny ? oy : ny;
    int x1 = (ox > nx ? ox : nx) + 12 - 1;
    int y1 = (oy > ny ? oy : ny) + 19 - 1;
    int uw = x1 - x0 + 1, uh = y1 - y0 + 1;
    if (uw * uh <= 700)
        fb_touch(x0, y0, uw, uh);
    else {
        fb_touch(ox, oy, 12, 19);
        fb_touch(nx, ny, 12, 19);
    }
}

/* ------------------------------ служебное ------------------------------ */

static int rect_intersect(int ax, int ay, int aw, int ah,
                          int bx, int by, int bw, int bh)
{
    return ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah;
}

static void win_content_rect(window_t *w, int *cx, int *cy, int *cw, int *ch)
{
    *cx = w->x + 1;
    *cy = w->y + TITLE_H + 1;
    *cw = w->w - 2;
    *ch = w->h - TITLE_H - 2;
}

int win_content_w(window_t *w) { return w->w - 2; }
int win_content_h(window_t *w) { return w->h - TITLE_H - 2; }

static int window_at(int x, int y)
{
    for (int i = nwin - 1; i >= 0; i--) {
        if (wins[i]->minimized) continue;     /* свёрнутые окна не ловят клики */
        if (x >= wins[i]->x && x < wins[i]->x + wins[i]->w &&
            y >= wins[i]->y && y < wins[i]->y + wins[i]->h)
            return i;
    }
    return -1;
}

static void raise_window(int idx)
{
    if (idx < 0 || idx == nwin - 1) return;
    int old_top = top_visible_window();
    window_t *old_focus = (old_top >= 0) ? wins[old_top] : NULL;
    /* [H1-FIX] (разбор гипотез зависаний): клик по окну — ГОРЯЧИЙ путь
     * kmain (wm_mouse_poll). Блокирующий wl_lock замораживал весь
     * рабочий стол до 20 с (SLOCK_STALE_TICKS), пока wm_glock держит
     * зависший поток (spin в s_lock спит, но kmain — единственный, кто
     * делает ввод/композитинг). Ограниченная попытка: не успели за 50 мс —
     * фокус поднимет следующий клик/кадр, kmain жив. */
    if (!wl_trylock_ms(&wm_glock, 50))
        return;
    /* под glock: исключение с win_create/удалениями из других потоков */
    window_t *w = wins[idx];
    for (int i = idx; i < nwin - 1; i++) wins[i] = wins[i + 1];
    wins[nwin - 1] = w;
    wl_unlock(&wm_glock);
    /* ПЕРФ: вместо полного кадра — само окно (в его прямоугольнике
     * открылись ранее закрытые части), прежнее фокусное (цвет
     * заголовка и ручки resize) и таскбар */
    wm_touch_window(w);
    if (old_focus && old_focus != w) wm_touch_window(old_focus);
    wm_touch_taskbar();
}

/* [MP3-SINGLE] (iteraciya 12) podnyat' sushchestvuyushchee okno iz CHUZHOGO
 * potoka (fajlovyj menedzher otkryvaet vtoroj MP3 — pleer odin, ego okno
 * podnimaetsya i perestavlyaetsya trekk vmesto vtorogo okna). Bez blokirovki
 * na vremya poiska: trylock 50 ms, ne uspeli — podnimet sleduyushchij klik. */
void wm_raise(window_t *w)
{
    if (!w) return;
    int idx = -1;
    if (!wl_trylock_ms(&wm_glock, 50)) return;
    for (int i = 0; i < nwin; i++)
        if (wins[i] == w) { idx = i; break; }
    wl_unlock(&wm_glock);
    if (idx < 0) return;                 /* okno uzhe zakryvaetsya */
    if (w->minimized) win_restore(w);    /* zamykanie beret samo */
    raise_window(idx);
}

/* Найти верхнее НЕ свёрнутое окно (для фокуса). */
static int top_visible_window(void)
{
    for (int i = nwin - 1; i >= 0; i--)
        if (!wins[i]->minimized) return i;
    return -1;
}

/* ========================================================================
 * Многопоточный WM: поток на каждое окно ( FIX всего семейства
 * «зависло одно приложение — встала вся система» ).
 *
 * Модель:
 *   win_create()      — создаёт окно + canvas (пиксельный буфер содержимого)
 *                       + ПОТОК (task_spawn) и подключает canvas как цель
 *                       рендера задачи (fb_task_canvas_attach).
 *   wm_key/mouse/halfsec — БОЛЬШЕ не вызывают колбэки приложений напрямую:
 *                       они кладут событие в очередь окна (win_post) и
 *                       будят поток (task_wake). kmain никогда не выполняет
 *                       код приложений — только композитит canvas'ы.
 *   Поток окна         — вынимает события, вызывает колбэки, рисует в
 *                       СВОЙ canvas; закончив работу — помечает need_draw;
 *                       если работы нет — спит (task_set_waiting_me + hlt).
 *   wm_frame (kmain)   — закрывает окна, пересоздаёт canvas при resize,
 *                       убирает мёртвые окна (reaper), композитит:
 *                       хром окна + blit canvas на экран.
 *
 * Блокировки (одного уровня, без вложенного ожидания):
 *   wm_glock — защищает wins[]/nwin (win_create из любого потока против
 *              kmain-итераций);
 *   qlock    — очередь событий окна (kmain кладёт / поток вынимает);
 *   rlock    — секция рендера canvas в потоке против пересоздания canvas
 *              в kmain (resize) и против blit'а в composite.
 *              kmain всегда берёт её try-ом и НИКОГДА не ждёт.
 * ======================================================================== */

extern void serial_puts(const char *s);

typedef enum { WEV_KEY = 1, WEV_MOUSE, WEV_TICK, WEV_CLOSE,
               WEV_MENU } wev_kind_t;   /* сессия 13: контекстное меню */

typedef struct {
    u8           kind;
    key_event_t  key;          /* WEV_KEY */
    int          mx, my;       /* WEV_MOUSE (координаты от содержимого) */
    u8           btn, changed;
    int          menu_id;      /* WEV_MENU */
    void        *menu_cb;      /* WEV_MENU: колбэк (исполнить в ЭТОМ потоке) */
    void        *menu_ctx;     /* WEV_MENU: пользовательский контекст */
} wev_t;

typedef struct {
    wev_t        q[24];
    volatile int head;         /* сюда пишем */
    volatile int tail;         /* отсюда читаем */
    volatile int qlock;
    volatile int rlock;        /* рендер canvas / realloc / blit */
    volatile int need_draw;    /* поток должен перерисовать canvas */
    volatile int closing;      /* CLOSE отправлен */
    volatile int dead;         /* поток завершился, память можно освободить */
    volatile int no_canvas;    /* сессия 12: canvas сознательно отключён от
                                * потока (c4gfx: рисует задача программы) —
                                * ожидать attach в потоке НЕ нужно */
    volatile int drawn_once;   /* сессия 85: поток УЖЕ отрисовал canvas
                                * хотя бы раз. Пока 0 — композитор НЕ
                                * рисует окно (поверх виден прежний кадр:
                                * рабочий стол/чужие окна), иначе первый
                                * кадр нового окна — тёмная заливка
                                * («окно мерцает чёрным при открытии») */
    volatile int drop_log;     /* ПЕРФ: сколько дропов уже залогировано
                                * (serial_putc ~87 мкс/символ — спам в
                                * горячем пути заминает kmain, см. win_post) */
} win_thr_t;

/* ---- очередь событий окна ----
 *
 * ПЕРФ (запрос пользователя, «hover-шторм»): мышь шлёт пакеты десятки-
 * сотни раз в секунду; каждое чистое ДВИЖЕНИЕ (changed == 0, кнопки не
 * менялись) не несёт истории — приложению важна только ПОСЛЕДНЯЯ
 * позиция. Поэтому:
 *   1) если последнее событие в очереди — тоже чистое движение, новое
 *      ПЕРЕЗАПИСЫВАЕТ его (коалесценция: очередь не растёт, поток окна
 *      обрабатывает одну пачку движений одним событием);
 *   2) при ПОЛНОЙ очереди чистое движение не дропается, а перезаписывает
 *      последнее (если оно тоже движение);
 *   3) СЕССИЯ 31 («клики теряются при обильной перерисовке»): при полной
 *      очереди ВАЖНОЕ событие (кнопка/клавиша/меню) больше НЕ дропается —
 *      вместо него выселяется самое старое чистое ДВИЖЕНИЕ (или TICK,
 *      если движений нет). Раньше приложение, занятое перерисовкой,
 *      копило в очереди движения; очередь заполнялась — и нажатия
 *      молча терялись (dropped). Теперь клик доходит всегда.
 *   4) дроп (только если в очереди вообще нечего выселять) логируется
 *      не более 3 раз на окно. */

static void win_post(window_t *w, const wev_t *ev)
{
    if (!w || w->task < 0) return;
    win_thr_t *t = (win_thr_t *)w->thr;
    if (!t) return;

    int motion = (ev->kind == WEV_MOUSE && ev->changed == 0);

    int dropped = 0;
    /* [WM-NOSTALL]: kmain не ждёт зависший поток окна — событие
     * теряется (окно занято >20 мс; очередь и так почти полна).
     * Раньше вечное ожидание qlock замораживало ввод ВСЕЙ системы. */
    if (!wl_trylock_ms(&t->qlock, 20)) {
        if (t->drop_log < 3) {
            t->drop_log++;
            serial_puts("[wm] qlock занят — событие пропущено (окно зависло?)\n");
        }
        return;
    }
    int cnt = (t->head - t->tail + 24) % 24;
    int last = (t->head - 1 + 24) % 24;
    int have_last = (cnt > 0);

    if (motion && have_last &&
        t->q[last].kind == WEV_MOUSE && t->q[last].changed == 0) {
        /* коалесценция: перезаписываем последнее чистое движение
         * (работает и при полной очереди — движение не дропается) */
        t->q[last] = *ev;
    } else if (cnt < 23) {
        t->q[t->head] = *ev;
        t->head = (t->head + 1) % 24;
    } else if (!motion) {
        /* Очередь полна, событие ВАЖНОЕ: выселяем чистое движение
         * (самое старое), иначе TICK. */
        int victim = -1;
        for (int k = 0; k < cnt; k++) {
            int idx = (t->tail + k) % 24;
            if (t->q[idx].kind == WEV_MOUSE && t->q[idx].changed == 0) {
                victim = idx;
                break;
            }
        }
        if (victim < 0) {
            for (int k = 0; k < cnt; k++) {
                int idx = (t->tail + k) % 24;
                if (t->q[idx].kind == WEV_TICK) { victim = idx; break; }
            }
        }
        if (victim >= 0) {
            /* сдвигаем хвост левее victim'а к tail (порядок сохраняем) */
            for (int idx = victim; idx != t->tail; idx = (idx - 1 + 24) % 24)
                t->q[idx] = t->q[(idx - 1 + 24) % 24];
            t->tail = (t->tail + 1) % 24;
            t->q[t->head] = *ev;
            t->head = (t->head + 1) % 24;
        } else {
            dropped = 1;
        }
    } else {
        dropped = 1;   /* движение при полной очереди без «последнего движения» */
    }
    wl_unlock(&t->qlock);
    if (dropped) {
        /* ПЕРФ: НЕ печатаем в serial из горячего пути (одна строка —
         * ~4.5 мс с cli, а дропы случаются именно под нагрузкой).
         * Счётчик в самой очереди; первые 3 дропа — по одному сообщению. */
        if (t->drop_log < 3) {
            t->drop_log++;
            serial_puts("[wm] event queue full, drop (window hung?)\n");
        }
        return;
    }
    task_wake(w->task);
}

/* Отправить CLOSE: даже если очередь забита — очищаем её (события
 * всё равно уже не нужны) и кладём CLOSE. */
static void win_post_close(window_t *w)
{
    if (!w || w->task < 0) return;
    win_thr_t *t = (win_thr_t *)w->thr;
    if (!t) return;

    /* [WM-NOSTALL]: CLOSE не ждём бесконечно: поток застрял в qlock —
     * ставим closing (выйдет на следующем витке) и не блокируем kmain. */
    if (!wl_trylock_ms(&t->qlock, 100)) {
        t->closing = 1;
        serial_puts("[wm] qlock занят: CLOSE отложен (поток окна завис)\n");
        task_wake(w->task);
        return;
    }
    t->tail = 0;
    t->head = 0;
    memset(&t->q[0], 0, sizeof(t->q[0]));
    t->q[0].kind = WEV_CLOSE;
    t->head = 1;
    t->closing = 1;
    wl_unlock(&t->qlock);
    task_wake(w->task);
}

/* ---- отложенное освобождение canvas (сессия 12) ----
 * Blit canvas в composite больше не берёт rlock (см. draw_window):
 * пока поток окна рисует, композитор может одновременно читать canvas.
 * Убрать rlock нельзя было раньше ещё и из-за освобождения: поток,
 * закрываясь, делал free(canvas), и композитор мог читать освобождённую
 * память. Теперь все освобождения canvas идут через этот список:
 * kmain (wm_frame) реально освобождает буфер через 3 кадра — к этому
 * моменту ни один blit физически не может держать старый указатель. */
#define WM_TRASH_MAX 48
static u32 *wm_trash[WM_TRASH_MAX];
static int   wm_trash_age[WM_TRASH_MAX];
static int   wm_trash_n = 0;

static void wm_canvas_trash_add(u32 *p)
{
    if (!p) return;
    if (wm_trash_n >= WM_TRASH_MAX) {   /* переполнение — освобождаем старейший */
        free(wm_trash[0]);
        for (int i = 1; i < WM_TRASH_MAX; i++) {
            wm_trash[i - 1] = wm_trash[i];
            wm_trash_age[i - 1] = wm_trash_age[i];
        }
        wm_trash_n--;
    }
    wm_trash[wm_trash_n] = p;
    wm_trash_age[wm_trash_n] = 0;
    wm_trash_n++;
}

/* Вызывается ТОЛЬКО из kmain (wm_frame): стареем на кадр, освобождаем
 * повзрослевшие до 3 кадров. */
static void wm_canvas_trash_tick(void)
{
    for (int i = 0; i < wm_trash_n; ) {
        if (++wm_trash_age[i] >= 3) {
            free(wm_trash[i]);
            wm_trash[i] = wm_trash[--wm_trash_n];
            continue;
        }
        i++;
    }
}

/* ---- поток окна ---- */

static void win_thread_fn(void *arg)
{
    window_t *w = (window_t *)arg;
    win_thr_t *t = (win_thr_t *)w->thr;

    /* Сессия 12 (FIX «окна прорисовываются сквозь друг друга»):
     * ждём подключения canvas-контекста ПЕРВЫМ делом. Между task_spawn()
     * и fb_task_canvas_attach() в win_create() нас могут вытеснить — и
     * тогда НУЖНЫЙ окну canvas ещё не подключён: рисовать в этот момент
     * НЕЛЬЗЯ — вывод уйдёт в ЭКРАННЫЙ контекст (запись [0]) с координатами
     * canvas, т.е. поверх левого верхнего угла экрана и всех окон, а
     * заодно испортит clip экранной записи для kmain. Ждём attach
     * (win_create делает его микросекундами позже) с ограничением
     * по времени — если слоты кончились (не бывает с 64), поток
     * просто не рисует (окно останется тёмным). */
    {
        int guard = 0;
        while (!fb_task_has_canvas(w->task) && !t->no_canvas &&
               guard++ < 2000)
            task_yield();
        /* норма: attach происходит микросекундами позже spawn.
         * no_canvas: окно c4gfx (canvas у задачи программы).
         * guard: страховка от зависания (рисовать не будем). */
    }

    for (;;) {
        /* [H3-FIX] (разбор гипотез): win_post_close мог поставить
         * closing=1, НЕ положив WEV_CLOSE (qlock был занят >100 мс).
         * Единственный легальный выход потока — WEV_CLOSE; без него
         * sleep-ветка ниже видит closing и никогда не спит: вечный
         * холостой busy-цикл, ватчдог его не убивает (last_active_tick
         * обновляется при каждом вытеснении) — утечка слота/стека/
         * canvas и 100% CPU на UI-приоритете. Теперь: closing и очередь
         * пуста — закрываемся сами, той же последовательностью, что и
         * WEV_CLOSE ниже. Если в очереди ещё есть события (в т.ч.
         * настоящий CLOSE) — сначала добираем их. */
        if (t->closing) {
            int do_close = 0;
            if (wl_trylock_ms(&t->qlock, 50)) {
                if (t->head == t->tail)
                    do_close = 1;      /* WEV_CLOSE так и не пришёл */
                wl_unlock(&t->qlock);
            }
            if (do_close) {
                if (w->on_close) w->on_close(w);
                wl_lock(&t->rlock);
                fb_task_canvas_detach(w->task);
                if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
                wl_unlock(&t->rlock);
                t->dead = 1;
                task_exit();           /* не вернёмся */
            }
        }
        /* 1) события (сначала добираем всё) */
        wev_t ev;
        int have = 0;
        wl_lock(&t->qlock);
        if (t->head != t->tail) {
            ev = t->q[t->tail];
            t->tail = (t->tail + 1) % 24;
            have = 1;
        }
        wl_unlock(&t->qlock);

        if (have) {
            switch (ev.kind) {
            case WEV_CLOSE:
                /* колбэк освобождает данные приложения в его потоке;
                 * canvas тоже освобождаем здесь (владелец — поток), но
                 * НЕ напрямую, а через trash-список (сессия 12): композитор
                 * мог читать этот canvas в момент закрытия (blit теперь
                 * lock-free) — освобождаем через 3 кадра, когда ни один
                 * blit уже не может его держать */
                if (w->on_close) w->on_close(w);
                wl_lock(&t->rlock);
                fb_task_canvas_detach(w->task);
                if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
                wl_unlock(&t->rlock);
                t->dead = 1;
                task_exit();               /* не вернёмся */
                break;
            case WEV_KEY:
                if (w->on_key) w->on_key(w, &ev.key);
                break;
            case WEV_MOUSE:
                /* СЕССИЯ 15: сначала событие предлагают ВИДЖЕТАМ окна
                 * (чекбоксы/радиобоксы получают нажатия мыши от WM).
                 * Съеденное виджетом событие в on_mouse не попадает. */
                if (!wm_widgets_dispatch(w, ev.mx, ev.my, ev.btn, ev.changed)
                    && w->on_mouse)
                    w->on_mouse(w, ev.mx, ev.my, ev.btn, ev.changed);
                break;
            case WEV_TICK:
                if (w->on_tick) w->on_tick(w);
                break;
            case WEV_MENU:
                /* контекстное меню (сессия 13): колбэк приложения
                 * исполняется в ПОТОКЕ ОКНА-ВЛАДЕЛЬЦА — без гонок */
                {
                    wm_menu_fn cb = (wm_menu_fn)ev.menu_cb;
                    if (cb) cb(ev.menu_id, ev.menu_ctx);
                }
                break;
            default:
                break;
            }
            continue;
        }

        /* 2) перерисовка canvas */
        if (t->need_draw) {
            t->need_draw = 0;
            /* [H7c-FIX] (разбор гипотез): canvas может быть отключён от
             * задачи (attach не удался в win_create / c4gfx-окно) — без
             * проверки fb_set_origin(0,0)+clip уводили вывод в ЭКРАННЫЙ
             * контекст: приложение рисовало поверх левого верхнего угла
             * экрана, попирая окна (см. комментарий выше про [0]). */
            if (!w->minimized && w->draw && w->canvas &&
                !t->no_canvas &&
                (w->task <= 0 || fb_task_has_canvas(w->task))) {
                wl_lock(&t->rlock);     /* vs realloc в kmain (resize) */
                fb_set_clip(0, 0, w->cvs_w - 1, w->cvs_h - 1);
                fb_set_origin(0, 0);
                w->draw(w);
                wl_unlock(&t->rlock);
                t->drawn_once = 1;      /* сессия 85: композитор может показать */
                /* НЕ win_invalidate (это зациклило бы need_draw), а прямой
                 * fb_touch — пометить область окна на экране */
                fb_touch(w->x, w->y, w->w, w->h);
            }
            continue;
        }

        /* 3) работы нет: спим до события (hlt; планировщик нас пропускает) */
        {
            int if_had;
            __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
            if (t->head != t->tail || t->need_draw || t->closing) {
                if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
                continue;
            }
            task_set_waiting_me();
            /* СЕССИЯ 75: сон с отпуском ядрового замка (иначе AP-задачи
             * не получают CPU, пока поток окна спит) */
            task_klock_release_me();
            __asm__ __volatile__("sti\n\thlt" ::: "memory");
            /* пробуждение: task_wake снял waiting, планировщик вернул нас */
            __asm__ __volatile__("cli" ::: "memory");
            task_klock_acquire_me();
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        }
    }
}

/* ---- zombie: окна, чей поток ещё не умер (ждём dead) ---- */
#define WM_ZOMBIE_MAX 64
static window_t *zombies[WM_ZOMBIE_MAX];
static int nzombie = 0;

/* ---- kill mailbox: диспетчер задач/ватчдог просят убить окно ---- */
#define WM_KILL_MAIL 16
static volatile int kill_mail[WM_KILL_MAIL];
static volatile int kill_mail_n = 0;
static volatile int kill_lock = 0;

void wm_request_kill(int task_idx)
{
    if (task_idx <= 0) return;
    wl_lock(&kill_lock);
    if (kill_mail_n < WM_KILL_MAIL) kill_mail[kill_mail_n++] = task_idx;
    wl_unlock(&kill_lock);
}

/* ---- ТЕСТ ЖИВУЧЕСТИ (команда spinlock в терминале) ----
 * Задача берёт wm_glock (главная блокировка оконного менеджера — её
 * ждёт composite в kmain КАЖДЫЙ кадр) и зависает в вечном цикле.
 * До фикса sync.h это НАМЕРТВО замораживало весь UI: kmain вечно
 * ждал блокировку, а с ним — мышь, клавиатуру и часы. Теперь s_lock
 * видит живого, но не отпускающего владельца и через 20 секунд
 * (SLOCK_STALE_TICKS) отбирает блокировку — система оживает.
 * Убить саму задачу: kill <N> / Del в диспетчере задач. */
static void glock_spin_fn(void *arg)
{
    (void)arg;
    wl_lock(&wm_glock);
    volatile u32 x = 0;
    for (;;) { x++; }   /* «зависли», держа блокировку */
}

int wm_test_glock_spin(void)
{
    return task_spawn("spinlock", glock_spin_fn, NULL);
}

int wm_task_of(window_t *w) { return w ? w->task : -1; }

window_t *wm_find_by_task(int task_idx)
{
    if (task_idx <= 0) return NULL;
    for (int i = 0; i < nwin; i++)
        if (wins[i] && wins[i]->task == task_idx) return wins[i];
    return NULL;
}

/* Обработка kill-запросов и вычистка мёртвых окон. Вызывается ТОЛЬКО
 * из kmain (wm_frame). */
void wm_pump_kills(void)
{
    /* 1) запросы на убийство (диспетчер задач, ватчдог) */
    for (;;) {
        int idx;
        wl_lock(&kill_lock);
        if (kill_mail_n <= 0) { wl_unlock(&kill_lock); break; }
        idx = kill_mail[--kill_mail_n];
        wl_unlock(&kill_lock);
        if (idx <= 0) continue;

        window_t *w = wm_find_by_task(idx);
        if (!w) continue;

        int ox = w->x, oy = w->y, ow = w->w, oh = w->h;

        /* [WM-NOSTALL]: удаление из wins[] — ограниченная попытка:
         * занято — запрос остаётся в kill_mail на следующий кадр. */
        if (!wl_trylock_ms(&wm_glock, 50)) continue;
        for (int i = 0; i < nwin; i++) {
            if (wins[i] == w) {
                for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
                nwin--;
                break;
            }
        }
        wl_unlock(&wm_glock);

        /* Данные приложения: поток мёртв, ничего не изменит.
         * ВАЖНО: rlock здесь НЕ берём — убитый поток мог умереть, держа
         * rlock, и никогда его не отпустит. Мёртвый поток никому больше
         * не конкурент: окно уже вне wins[], blit его не видит.
         * Сессия 12: canvas — через trash (мог читаться композитором). */
        if (w->on_close) w->on_close(w);
        fb_task_canvas_detach(idx);
        if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
        if (w->thr) { free(w->thr); w->thr = NULL; }
        free(w);
        /* ПЕРФ: вместо полного кадра — прежний прямоугольник окна,
         * таскбар и заголовок нового верхнего окна */
        wm_touch_rect(ox, oy, ow, oh);
        wm_touch_taskbar();
        {
            int nt = top_visible_window();
            if (nt >= 0) wm_touch_title(wins[nt]);
        }
    }

    /* 2) окна с уже умершим потоком (закрыты нормально: dead) */
    for (int zi = 0; zi < nzombie; ) {
        window_t *w = zombies[zi];
        win_thr_t *t = (win_thr_t *)w->thr;
        if (t && t->dead) {
            free(t);
            w->thr = NULL;
            free(w);
            zombies[zi] = zombies[--nzombie];   /* swap-remove */
            continue;                           /* без zi++ */
        }
        zi++;
    }

    /* 3) окна в wins[], чей поток убит ватчдогом/task_kill напрямую */
    for (int i = 0; i < nwin; ) {
        window_t *w = wins[i];
        if (w->task > 0 && task_finished(w->task) && !task_is_waiting(w->task)) {
            int ox = w->x, oy = w->y, ow = w->w, oh = w->h;
            /* [WM-NOSTALL]: ограниченная попытка — занято, попробуем
             * на следующем кадре (окно останется до успешного входа) */
            if (!wl_trylock_ms(&wm_glock, 50)) { i++; continue; }
            for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
            nwin--;
            wl_unlock(&wm_glock);
            if (w->on_close) w->on_close(w);
            /* rlock НЕ берём: поток мёртв (см. комментарий выше) */
            fb_task_canvas_detach(w->task);
            if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
            if (w->thr) { free(w->thr); w->thr = NULL; }
            free(w);
            /* ПЕРФ: частичные касания вместо полного кадра */
            wm_touch_rect(ox, oy, ow, oh);
            wm_touch_taskbar();
            {
                int nt = top_visible_window();
                if (nt >= 0) wm_touch_title(wins[nt]);
            }
            continue;
        }
        i++;
    }
}

/* ------------------------------- меню ------------------------------- */

#define MENU_W 210
#define MENU_ITEM_H 26

/* Приложение, скрытое из меню Пуск (высота меню — запрос пользователя);
 * из терминала и по двойному клику в «Файлах» доступно как раньше. */
#define MENU_HIDE_APP "Просмотр"

static int menu_app_visible(int i)
{
    return strcmp(app_table[i].name, MENU_HIDE_APP) != 0;
}

static int menu_visible_apps(void)
{
    int n = 0;
    for (int i = 0; i < app_table_count; i++)
        if (menu_app_visible(i)) n++;
    return n;
}

/* app_table-индекс n-го видимого приложения (для меню/действий) */
static int menu_nth_app(int n)
{
    for (int i = 0; i < app_table_count; i++) {
        if (!menu_app_visible(i)) continue;
        if (n-- == 0) return i;
    }
    return -1;
}

static int menu_items(void)
{
    /* видимые приложения + разделитель + Выключение («Перезагрузка»
     * убрана — запрос «одна из кнопок выключения лишняя») */
    return menu_visible_apps() + 2;
}

static int menu_sep_idx(void)
{
    return menu_visible_apps();   /* индекс разделителя в меню */
}

/* [MENU-H] (разбор кода пользователем, баг №4): честная высота —
 * 4 (верх) + nvis*26 (пункты) + 9 (разделитель) + 26 («Выключение»)
 * + 4 (низ). Прежняя формула items*26+17 давала (nvis+2)*26+17 —
 * на 26..30 px выше содержимого: пустая зона внизу рамки, клик по
 * ней закрывал меню без действия (menu_hit = -1). */
static int menu_height(void)
{
    int h = 8;   /* поля: 4 сверху + 4 снизу (как в draw_menu: y = my+4) */
    for (int i = 0; i < menu_items(); i++)
        h += (i == menu_sep_idx()) ? 9 : MENU_ITEM_H;
    return h;
}

static void menu_rect(int *mx, int *my, int *mw, int *mh)
{
    *mx = 4;
    *mw = MENU_W;
    *mh = menu_height();
    *my = (int)fb_height() - TBAR_H - *mh;
}

/* индекс пункта по экранным координатам (с учётом разделителя) или -1 */
static int menu_hit(int x, int y)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    if (x < mx || x >= mx + mw || y < my || y >= my + mh) return -1;
    int yy = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == menu_sep_idx()) { yy += 9; continue; }
        if (y >= yy && y < yy + MENU_ITEM_H) return i;
        yy += MENU_ITEM_H;
    }
    return -1;
}

/* ПЕРФ (hover): экранный прямоугольник ОДНОГО пункта меню — при смене
 * наведения касаем только старый и новый пункт вместо всего меню. */
static int menu_item_rect(int idx, int *rx, int *ry, int *rw, int *rh)
{
    int mx, my, mw, mh;
    if (idx < 0 || idx >= menu_items()) return 0;
    menu_rect(&mx, &my, &mw, &mh);
    int yy = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == menu_sep_idx()) {
            if (idx == i) {
                *rx = mx + 1; *ry = yy; *rw = mw - 2; *rh = 9;
                return 1;
            }
            yy += 9;
            continue;
        }
        if (i == idx) {
            *rx = mx + 2; *ry = yy; *rw = mw - 4; *rh = MENU_ITEM_H;
            return 1;
        }
        yy += MENU_ITEM_H;
    }
    return 0;
}

static void menu_action(int idx)
{
    int nvis = menu_visible_apps();
    if (idx >= 0 && idx < nvis) {
        int app = menu_nth_app(idx);
        if (app >= 0) apps_open(app);
    } else if (idx == nvis + 1) {
        sys_poweroff();
    }
}

/* ------------------------------ заголовки ------------------------------ */

/* ---------------- кнопки заголовка ----------------
 * Справа налево: [×] закрыть (x+w-22), [□/❐] развернуть (x+w-42),
 * [—] свернуть (x+w-62). Каждая 18x16, как и раньше у закрытия. */
#define TB_BTN_W   18
#define TB_BTN_H   16
#define TB_BTN_GAP 2   /* зазор между кнопками: 22-18=4... фактически 20-шаг */

static void title_btn_rects(window_t *w, int *close, int *maxb, int *minb)
{
    /* каждая возвращает x (y везде w->y+4) */
    if (close) *close = w->x + w->w - 22;
    if (maxb)  *maxb  = w->x + w->w - 42;
    if (minb)  *minb  = w->x + w->w - 62;
}

static void draw_close_icon(int bx, int by, u32 col)
{
    for (int k = 0; k < 9; k++) {
        fb_fill_rect(bx + k, by + k, 1, 1, col);
        fb_fill_rect(bx + 8 - k, by + k, 1, 1, col);
    }
}

/* Иконка «развернуть»: квадрат; при уже развёрнутом окне — два
 * квадрата (восстановление). */
static void draw_max_icon(int bx, int by, u32 col, int maximized)
{
    if (!maximized) {
        fb_rect(bx + 4, by + 3, 10, 10, col);
        fb_fill_rect(bx + 4, by + 3, 2, 2, col);
    } else {
        /* задний квадрат */
        fb_rect(bx + 2, by + 7, 9, 9, col);
        /* передний (с заливкой фона кнопки поверх) */
        fb_rect(bx + 6, by + 2, 10, 9, col);
        fb_hline(bx + 7, bx + 15, by + 3, col);
    }
}

/* Иконка «свернуть»: полоска внизу */
static void draw_min_icon(int bx, int by, u32 col)
{
    fb_hline(bx + 4, bx + 13, by + 11, col);
    fb_hline(bx + 4, bx + 13, by + 12, col);
}

static void draw_window(window_t *w)
{
    /* Единая модель фокуса: верхнее НЕ свёрнутое окно (как в таскбаре) */
    int focused = (wm_focused_window() == w);
    /* СЕССИЯ 15: цвета заголовка/рамки — из ТЕМЫ (вкладка «Тема»
     * в Настройках меняет их глобально для всех окон) */
    u32 title_col = focused ? wm_theme_title() : wm_theme_title_unfoc();
    u32 border_col = focused ? wm_theme_border() : COL_BORDER;

    fb_rect(w->x, w->y, w->w, w->h, border_col);

    /* ПЕРФ (запрос пользователя, «растеризация статики каждый кадр»):
     * заголовочная полоса (фон/текст/кнопки) растеризуется ТОЛЬКО когда
     * она пересекает текущий клип. Композитор рисует окно в узкий
     * dirty-прямоугольник (например, 12x19 курсора) — вне его fb_* всё
     * равно отсекают ПОСЛЕ прохода по глифам; здесь отсекаем ДО. */
    int cl_x0 = 0, cl_y0 = 0, cl_x1 = -1, cl_y1 = -1;
    fb_get_clip(&cl_x0, &cl_y0, &cl_x1, &cl_y1);
    int title_vis = rect_intersect(w->x + 1, w->y + 1, w->w - 2, TITLE_H,
                                   cl_x0, cl_y0,
                                   cl_x1 - cl_x0 + 1, cl_y1 - cl_y0 + 1);
    if (title_vis) {
        fb_fill_rect(w->x + 1, w->y + 1, w->w - 2, TITLE_H, title_col);
        fb_text(w->x + 8, w->y + (TITLE_H - 16) / 2, w->title,
                wm_theme_title_text(), -1);

        /* Три кнопки: [—] свернуть, [□] развернуть, [×] закрыть */
        int bx_close, bx_max, bx_min;
        title_btn_rects(w, &bx_close, &bx_max, &bx_min);
        int by = w->y + 4;
        u32 btn_bg = focused ? COL_BTN : fb_rgb(0x20, 0x25, 0x2B);
        u32 btn_fg = fb_rgb(0xC6, 0xCD, 0xD5);

        /* свернуть */
        fb_fill_rect(bx_min, by, TB_BTN_W, TB_BTN_H, btn_bg);
        fb_rect(bx_min, by, TB_BTN_W, TB_BTN_H, COL_BORDER);
        draw_min_icon(bx_min, by, btn_fg);

        /* развернуть/восстановить */
        fb_fill_rect(bx_max, by, TB_BTN_W, TB_BTN_H, w->maximized ? COL_BTN_ACT : btn_bg);
        fb_rect(bx_max, by, TB_BTN_W, TB_BTN_H, COL_BORDER);
        draw_max_icon(bx_max, by, btn_fg, w->maximized);

        /* закрыть */
        fb_fill_rect(bx_close, by, TB_BTN_W, TB_BTN_H,
                     (pending_close == w) ? COL_CLOSE_HOT : COL_CLOSE);
        draw_close_icon(bx_close + 4, by + 3, fb_rgb(0xF0, 0xD0, 0xD0));
    }

    /* Resize handle: правый нижний угол (диагональные полоски).
     * У развёрнутого окна скрыт — размер менять нельзя. */
    if (!w->maximized) {
        int rx = w->x + w->w - 9;
        int ry = w->y + w->h - 9;
        u32 hc = focused ? wm_theme_accent() : fb_rgb(0x50, 0x58, 0x62);
        for (int k = 0; k < 6; k++) {
            fb_fill_rect(rx + k, ry + 7, 1, 1, hc);
            fb_fill_rect(rx + 7, ry + k, 1, 1, hc);
            fb_fill_rect(rx + k + 1, ry + 5 - k, 1, 1, hc);
        }
    }

    int cx, cy, cw, ch;
    win_content_rect(w, &cx, &cy, &cw, &ch);
    /* КЛИП УЖЕ УСТАНОВЛЕН КОМПОЗИТОРОМ (окно ∩ dirty-область) — НЕ
     * расширяем его до полного content-rect: рисование за пределами
     * dirty — чистая потеря тактов на медленных CPU (Atom N2600), а с
     * compose-буфером эти пиксели всё равно не попали бы в LFB.
     * Все примитивы ниже клипуются сами. */

    /* Содержимое — canvas окна: его рисует ПОТОК окна (не kmain!).
     * Сессия 12: blit БЕЗ rlock. Раньше композитор брал rlock try-ом,
     * и если поток окна в этот момент перерисовывал canvas (а при
     * движении курсора потоки перерисовываются ПОСТОЯННО — hover),
     * содержимое заливалось ТЁМНЫМ — «окна мигали/пропадали при
     * движении курсора». Теперь blit идёт параллельно с рисованием:
     * одновременно виден кадр наполовину старый/новый (tearing) —
     * это нормальная цена lock-free композитинга без двойной
     * буферизации canvas, артефакт длится один кадр и незаметен.
     * От use-after-free защищает trash-список (освобождение через
     * 3 кадра, см. wm_canvas_trash_add).
     *
     * САНПРОСТРОЙКА РАЗМЕРА (FIX «окно сквозь окно»): canvas обязан
     * совпадать с content-rect. Раньше рассинхрон (canvas не успел за
     * ресайзом окна: trylock(rlock) не удался, поток занят, ...) давал
     * blit, покрывающий лишь ЧАСТЬ содержимого, — в «дыру» проступали
     * чужие окна/старые пиксели. Теперь: фон заливается на всю область,
     * поверх — что реально есть в canvas; потоку выставляется need_draw,
     * resize-цикл wm_frame подгонит размер. */
    {
        win_thr_t *t = (win_thr_t *)w->thr;
        int stale = w->canvas && (w->cvs_w != cw || w->cvs_h != ch);
        /* ПЕРФ/UX (настройка «Рисовать содержимое окна при
         * перетаскивании»): в быстром режиме тело перетаскиваемого
         * окна — однотонная заливка (без тяжёлого blit канваса);
         * при отпускании кнопки содержимое возвращается целиком. */
        int fast_drag = (w == drag_win && !wm_opt_drag_content());
        if (stale) {
            fb_fill_rect(cx, cy, cw, ch, wm_theme_win_bg());
            /* ПЕРФ: не перезаказываем перерисовку, пока предыдущая ещё
             * не исполнена потоком окна (иначе каждый кадр resize давал
             * лишний task_wake + повторную отрисовку canvas) */
            if (t && !t->need_draw) {
                t->need_draw = 1;
                if (w->task > 0) task_wake(w->task);
            }
        } else if (!w->canvas || fast_drag) {
            fb_fill_rect(cx, cy, cw, ch, wm_theme_win_bg());
        }
        if (w->canvas && !fast_drag)
            fb_blit_to_screen(w->canvas, w->cvs_w, w->cvs_h, cx, cy, cw, ch);
    }
}

/* FIX [W1]: стабильный порядок кнопок таскбара.
 * Раньше кнопки рисовались в порядке массива wins[], а raise_window()
 * ПЕРЕНОСИЛ окно в конец массива — клик по кнопке (или просто фокусировка
 * окна) «перескакивал» кнопку в самый правый угол. Теперь порядок кнопок —
 * по serial (времени создания окна): кнопка всегда на своём месте,
 * как в обычных ОС. */
static int taskbar_order(int *order, int max)
{
    int n = 0;
    for (int i = 0; i < nwin && n < max; i++) {
        if (!wins[i]) continue;
        int j = n - 1;
        while (j >= 0 && wins[order[j]]->serial > wins[i]->serial) {
            order[j + 1] = order[j];
            j--;
        }
        order[j + 1] = i;
        n++;
    }
    return n;
}

/* Обрезка UTF-8 строки до max_chars видимых СИМВОЛОВ; если обрезали —
 * в конец добавляется '.'. Символ никогда не рвётся посередине. */
static void utf8_clip(char *dst, const char *src, int max_chars)
{
    int cnt = 0, o = 0;
    const char *p = src;
    while (*p) {
        int adv = 1;
        if ((*p & 0xE0) == 0xC0 && p[1]) adv = 2;
        else if ((*p & 0xF0) == 0xE0 && p[1] && p[2]) adv = 3;
        if (cnt == max_chars - 1 && p[adv] != 0) {
            dst[o++] = '.';
            break;
        }
        if (cnt >= max_chars) break;
        for (int k = 0; k < adv; k++) dst[o++] = p[k];
        p += adv;
        cnt++;
    }
    dst[o] = 0;
}

/* ПЕРФ (запрос пользователя, «растеризация статики каждый кадр»):
 * композитор вызывает draw_taskbar при каждом dirty-прямоугольнике,
 * задевающем полосу (курсор над таскбаром, тик часов). Клип при этом —
 * узкая область; растеризация кнопок/текста вне её — чистые потери
 * (fb_* отсекают пиксели ПОСЛЕ прохода по глифам). Здесь пересечение
 * с клипом проверяется ДО отрисовки каждого элемента. */
static int tb_in_clip(int x, int w, int cl_x0, int cl_x1)
{
    return x <= cl_x1 && x + w - 1 >= cl_x0;
}

/* ---- раскладка таскбара: правая зарезервированная зона ----
 * Часы (8 симв.) + значок громкости + значок сети — кнопки окон
 * НЕ должны наезжать на трей (запрос пользователя). Используется
 * и в отрисовке, и в hit-тесте — рассинхрон невозможен. */
#define TB_CLOCK_W   (8 * 8)   /* "ЧЧ:ММ:СС" */
#define TB_NET_W     28        /* значок сети + отступы (см. draw_taskbar) */
#define TB_VOL_W     26        /* значок громкости + отступы [HDA-SWVOL] */
#define TB_RIGHT_GAP 6         /* зазор между кнопками и значком громкости */

static int taskbar_btn_end(void)
{
    return (int)fb_width() - 8 - TB_CLOCK_W - TB_NET_W - TB_VOL_W - TB_RIGHT_GAP;
}

/* [HDA-SWVOL] громкость: значок/панель определены ниже draw_taskbar */
static void vol_icon_rect(int *ix, int *iy, int *iw, int *ih);
static void draw_vol_icon(void);

/* Прямоугольник кнопки окна на таскбаре (для анимации свернуть/развернуть:
 * окно «улетает» в СВОЮ кнопку). 1 = кнопка видна. */
static int taskbar_button_rect(window_t *w, int *rbx, int *rby, int *rbw, int *rbh)
{
    int bx_start = 4 + 64 + 6;
    int bx_end   = taskbar_btn_end();
    int btn_min_w = 60;
    int btn_max_w = 140;
    int btn_h = 20;
    int by = (int)fb_height() - 24;
    int avail_w = bx_end - bx_start;
    int max_btns = avail_w / btn_min_w;
    if (max_btns < 1) max_btns = 1;

    int order[WM_MAX_WINDOWS];
    int nt = taskbar_order(order, WM_MAX_WINDOWS);
    int first_btn = 0;
    if (nt > max_btns) first_btn = nt - max_btns;
    int btn_w = (nt > max_btns) ? (avail_w / max_btns) : btn_max_w;
    if (btn_w > btn_max_w) btn_w = btn_max_w;
    if (btn_w < btn_min_w) btn_w = btn_min_w;

    for (int k = first_btn; k < nt; k++) {
        int bx = bx_start + (k - first_btn) * btn_w;
        int w_eff = btn_w;
        if (bx + w_eff > bx_end) w_eff = bx_end - bx;
        if (w_eff < 1) break;
        if (wins[order[k]] == w) {
            if (rbx) *rbx = bx;
            if (rby) *rby = by;
            if (rbw) *rbw = w_eff;
            if (rbh) *rbh = btn_h;
            return 1;
        }
    }
    return 0;
}

static void draw_taskbar(void)
{
    u32 H = fb_height(), W = fb_width();
    int cl_x0 = 0, cl_y0 = 0, cl_x1 = -1, cl_y1 = -1;
    fb_get_clip(&cl_x0, &cl_y0, &cl_x1, &cl_y1);

    fb_fill_rect(0, (int)H - TBAR_H, (int)W, TBAR_H, COL_TBAR);
    fb_hline(0, (int)W - 1, (int)H - TBAR_H, COL_TBAR_LINE);

    /* кнопка «Меню» */
    if (tb_in_clip(4, 64, cl_x0, cl_x1)) {
        fb_fill_rect(4, (int)H - 24, 64, 20, menu_open ? COL_BTN_ACT : COL_BTN);
        fb_rect(4, (int)H - 24, 64, 20, COL_MENU_LINE);
        fb_text(4 + (64 - 4 * 8) / 2, (int)H - 24 + 2, "Меню", COL_TEXT, -1);
    }

    /* Кнопки открытых окон — после кнопки Меню.
     * Порядок — по времени создания (taskbar_order), НЕ по z-порядку:
     * выделение не должно уезжать (FIX [W1]). */
    int bx_start = 4 + 64 + 6;     /* = 74 */
    int bx_end   = taskbar_btn_end();   /* часы + значок сети зарезервированы */
    int btn_max_w = 140;
    int btn_min_w = 60;
    int btn_h = 20;
    int by = (int)H - 24;

    int order[WM_MAX_WINDOWS];
    int nt = taskbar_order(order, WM_MAX_WINDOWS);

    /* Сколько кнопок помещается? */
    int avail_w = bx_end - bx_start;
    int max_btns = avail_w / btn_min_w;
    if (max_btns < 1) max_btns = 1;
    /* Если окон больше, чем помещается — показываем последние созданные */
    int first_btn = 0;
    if (nt > max_btns) first_btn = nt - max_btns;
    int btn_w = (nt > max_btns) ? (avail_w / max_btns) : btn_max_w;
    if (btn_w > btn_max_w) btn_w = btn_max_w;
    if (btn_w < btn_min_w) btn_w = btn_min_w;

    /* верхнее видимое окно — для подсветки активной кнопки */
    window_t *top_w = NULL;
    {
        int top = top_visible_window();
        if (top >= 0) top_w = wins[top];
    }

    for (int k = first_btn; k < nt; k++) {
        window_t *w = wins[order[k]];
        int bx = bx_start + (k - first_btn) * btn_w;
        int w_eff = btn_w;
        if (bx + w_eff > bx_end) w_eff = bx_end - bx;
        if (w_eff < 1) break;
        if (!tb_in_clip(bx, w_eff, cl_x0, cl_x1)) continue;   /* вне клипа */
        int focused = (w == top_w) && !w->minimized;
        u32 bg = focused ? COL_BTN_ACT
                : (w->minimized ? fb_rgb(0x14, 0x18, 0x1E) : COL_BTN);
        fb_fill_rect(bx, by, w_eff, btn_h, bg);
        fb_rect(bx, by, w_eff, btn_h, COL_MENU_LINE);
        /* Текст с обрезкой под ширину (UTF-8-безопасно) */
        char t[36];
        int max_chars = (w_eff - 8) / 8;
        if (max_chars < 1) max_chars = 1;
        if (max_chars > 34) max_chars = 34;
        utf8_clip(t, w->title, max_chars);
        fb_text(bx + 4, by + 2, t, focused ? COL_TEXT : COL_TEXT_DIM, -1);
    }

    /* часы */
    int h = 0, m = 0, s = 0;
    rtc_get_time(&h, &m, &s);
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", h, m, s);
    int clock_x = (int)W - 8 - (int)strlen(buf) * 8;
    int clock_vis = tb_in_clip(clock_x, (int)strlen(buf) * 8, cl_x0, cl_x1);
    if (clock_vis)
        fb_text(clock_x, (int)H - 22, buf, COL_TEXT_DIM, -1);

    /* ---------- значок сети (левее часов) ----------
     * Показываем состояние:
     *   - нет NIC:             серый значок с крестиком
     *   - есть NIC, нет IP:    жёлтый значок (предупреждение)
     *   - IP есть, нет линка: оранжевый
     *   - всё ок (link up):   зелёный с делениями сигнала
     * Рисуем 4 «полоски» разной высоты, как WiFi-значок, либо провод. */
    {
        int icon_x = (int)W - 8 - (int)strlen(buf) * 8 - 28;
        int icon_y = (int)H - 22;
        /* ПЕРФ: значок + мини-подпись IP (уходит левее значка) —
         * только если зона попадает в клип */
        if (tb_in_clip(icon_x - 72, 92, cl_x0, cl_x1)) {
            int nic_present = net_nic_present();
            u32 ip = net_get_ip();
            u32 tx = net_tx_packets();
            u32 rx = net_rx_packets();

            if (!nic_present) {
                /* серая иконка с крестиком */
                u32 col = fb_rgb(0x60, 0x68, 0x70);
                /* Рамка */
                fb_rect(icon_x, icon_y, 20, 16, col);
                /* X внутри */
                fb_hline(icon_x + 4, icon_x + 14, icon_y + 4, col);
                fb_hline(icon_x + 4, icon_x + 14, icon_y + 11, col);
                /* диагонали */
                for (int i = 0; i < 8; i++) {
                    fb_hline(icon_x + 4 + i, icon_x + 4 + i, icon_y + 4 + i, col);
                }
            } else if (ip == 0) {
                /* жёлтый треугольник-предупреждение */
                u32 col = fb_rgb(0xFF, 0xC0, 0x40);
                fb_fill_rect(icon_x, icon_y + 12, 20, 4, col);   /* подставка */
                for (int i = 0; i < 12; i++) {
                    fb_hline(icon_x + 4 + i, icon_x + 4 + i*2, icon_y + 11 - i, col);
                }
                /* восклицательный знак */
                fb_fill_rect(icon_x + 9, icon_y + 3, 2, 7, fb_rgb(0x12, 0x16, 0x1B));
                fb_fill_rect(icon_x + 9, icon_y + 11, 2, 2, fb_rgb(0x12, 0x16, 0x1B));
            } else {
                /* Зелёный значок: 4 столбика разной высоты = eth-метр активности
                 * Высоты: 4, 8, 12, 16 (как столбики сигнала) */
                u32 col = fb_rgb(0x60, 0xE0, 0x60);
                int heights[4] = { 4, 8, 12, 16 };
                int activity = (int)((tx + rx) & 0x3);   /* индикатор активности: 0..3 */
                for (int i = 0; i < 4; i++) {
                    int h_b = heights[i];
                    u32 c = (i <= activity) ? col : fb_rgb(0x30, 0x40, 0x30);
                    fb_fill_rect(icon_x + i * 4, icon_y + 16 - h_b, 3, h_b, c);
                }
                /* Подпись IP убрана с панели (запрос пользователя) —
                 * состояние сети видно по цвету/делениям значка; полный
                 * адрес — в Настройках → Сеть и в Терминале (ip). */
            }
        }
    }

    /* Подпись "N2600-OS" убрана — кнопки задач используют всю ширину */

    /* ---------- значок громкости (левее значка сети) ----------
     * [HDA-SWVOL] запрос пользователя: «добавь регулятор рядом со
     * значком вайфая». Корпус динамика + волны (2 шт = >=33%, +1 при
     * >=66%) либо крестик при 0. Щелчок — панель с ползунком. */
    {
        int ix, iy, iw, ih;
        vol_icon_rect(&ix, &iy, &iw, &ih);
        if (tb_in_clip(ix - 4, iw + 8, cl_x0, cl_x1))
            draw_vol_icon();
    }
}

/* ===================== громкость: значок + панель [HDA-SWVOL] =====================
 * Панель живёт НАД таскбаром (как «инициализация служб»), рисуется
 * в composite ПОСЛЕ окон. Открытие/закрытие — щелчком по значку,
 * закрытие — клик мимо панели. Ползунок тянется ЛКМ (vol_drag). */
#define VOL_PANEL_W  204
#define VOL_PANEL_H  58

static int vol_open = 0;    /* панель громкости открыта */
static int vol_drag = 0;    /* ЛКМ удерживается на ползунке */

/* значок: 20x16, левее значка сети */
static void vol_icon_rect(int *ix, int *iy, int *iw, int *ih)
{
    u32 W = fb_width(), H = fb_height();
    *ix = (int)W - 8 - TB_CLOCK_W - TB_NET_W - TB_VOL_W + 3;
    *iy = (int)H - 22;
    *iw = 20;
    *ih = 16;
}

/* панель НАД таскбаром, правый край у значка */
static void vol_panel_rect(int *px, int *py, int *pw, int *ph)
{
    int ix, iy, iw, ih;
    vol_icon_rect(&ix, &iy, &iw, &ih);
    *px = ix + iw / 2 - VOL_PANEL_W / 2;
    if (*px < 4) *px = 4;
    if (*px + VOL_PANEL_W > (int)fb_width() - 4)
        *px = (int)fb_width() - 4 - VOL_PANEL_W;
    *py = (int)fb_height() - TBAR_H - VOL_PANEL_H - 4;
    *pw = VOL_PANEL_W;
    *ph = VOL_PANEL_H;
}

static void draw_vol_icon(void)
{
    int ix, iy, iw, ih;
    vol_icon_rect(&ix, &iy, &iw, &ih);
    int pct = sound_get_volume();
    u32 col;
    if (vol_open)          col = wm_theme_accent();
    else if (!sound_present()) col = fb_rgb(0x55, 0x5D, 0x66);
    else if (pct > 0)      col = fb_rgb(0xC0, 0xC8, 0xD0);
    else                   col = fb_rgb(0x60, 0x68, 0x70);
    (void)iw; (void)ih;
    /* корпус динамика: диффузор + «рупор» */
    fb_fill_rect(ix, iy + 5, 4, 6, col);
    fb_fill_rect(ix + 4, iy + 3, 3, 10, col);
    fb_fill_rect(ix + 7, iy + 1, 2, 14, col);
    if (pct > 0 && sound_present()) {
        /* волны громкости */
        fb_fill_rect(ix + 11, iy + 5, 2, 6, col);
        if (pct >= 66)
            fb_fill_rect(ix + 14, iy + 3, 2, 10, col);
    } else {
        /* крестик (выключено) */
        for (int i = 0; i < 5; i++) {
            fb_fill_rect(ix + 11 + i, iy + 5 + i, 1, 1, col);
            fb_fill_rect(ix + 15 - i, iy + 5 + i, 1, 1, col);
        }
    }
}

static void draw_vol_panel(void)
{
    int px, py, pw, ph;
    vol_panel_rect(&px, &py, &pw, &ph);
    fb_fill_rect(px, py, pw, ph, fb_rgb(0x18, 0x1D, 0x24));
    fb_rect(px, py, pw, ph, COL_MENU_LINE);
    char buf[24];
    snprintf(buf, sizeof(buf), "Громкость: %d%%", sound_get_volume());
    fb_text(px + 8, py + 5, buf, COL_TEXT, -1);
    /* дорожка ползунка */
    int tx = px + 10, tw = pw - 20, ty = py + ph - 20;
    fb_fill_rect(tx, ty, tw, 8, fb_rgb(0x24, 0x2B, 0x33));
    int fill = (int)((u32)sound_get_volume() * (u32)(tw - 4) / 100u);
    if (fill > tw - 4) fill = tw - 4;
    if (fill > 0) fb_fill_rect(tx + 2, ty + 2, fill, 4, wm_theme_accent());
    int kx = tx + 2 + fill - 3;
    if (kx < tx) kx = tx;
    if (kx + 6 > tx + tw) kx = tx + tw - 6;
    fb_fill_rect(kx, ty - 2, 6, 12, fb_rgb(0xD0, 0xD8, 0xE0));
}

/* Проверить попадание клика в кнопку окна на таскбаре.
 * Возвращает индекс окна в wins[] или -1. Использует ТОТ ЖЕ стабильный
 * порядок (taskbar_order), что и отрисовка — FIX [W1]. */
static int taskbar_hit(int x, int y)
{
    u32 H = fb_height();
    if (y < (int)H - 24 || y >= (int)H - 4) return -1;

    int bx_start = 4 + 64 + 6;
    int bx_end   = taskbar_btn_end();
    int btn_min_w = 60;
    int btn_max_w = 140;
    int avail_w = bx_end - bx_start;
    int max_btns = avail_w / btn_min_w;
    if (max_btns < 1) max_btns = 1;

    int order[WM_MAX_WINDOWS];
    int nt = taskbar_order(order, WM_MAX_WINDOWS);

    int first_btn = 0;
    if (nt > max_btns) first_btn = nt - max_btns;
    int btn_w = (nt > max_btns) ? (avail_w / max_btns) : btn_max_w;
    if (btn_w > btn_max_w) btn_w = btn_max_w;
    if (btn_w < btn_min_w) btn_w = btn_min_w;

    for (int k = first_btn; k < nt; k++) {
        int bx = bx_start + (k - first_btn) * btn_w;
        int w_eff = btn_w;
        if (bx + w_eff > bx_end) w_eff = bx_end - bx;
        if (w_eff < 1) break;
        if (x >= bx && x < bx + w_eff) return order[k];
    }
    return -1;
}

static void draw_menu(void)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    fb_fill_rect(mx, my, mw, mh, COL_MENU);
    fb_rect(mx, my, mw, mh, COL_MENU_LINE);

    int y = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == menu_sep_idx()) {           /* разделитель */
            fb_hline(mx + 1, mx + mw - 2, y + 4, COL_MENU_LINE);
            y += 9;
            continue;
        }
        /* СЕССИЯ 85: подсветка — hover мыши ИЛИ клавиатурный фокус */
        int hot = (menu_open && (menu_hover == i || menu_kbd_sel == i));
        if (hot) fb_fill_rect(mx + 2, y, mw - 4, MENU_ITEM_H, COL_MENU_HOT);
        const char *name;
        if (i < menu_sep_idx()) {
            int app = menu_nth_app(i);
            name = (app >= 0) ? app_table[app].name : "";
        } else {
            name = "Выключение";
        }
        fb_text(mx + 12, y + (MENU_ITEM_H - 16) / 2, name,
                hot ? COL_TEXT : COL_TEXT_DIM, -1);
        y += MENU_ITEM_H;
    }
}

/* ===================== контекстное меню (сессия 13) =====================
 * ПЕРЕИСПОЛЬЗУЕМЫЙ компонент для приложений (запрос пользователя).
 * Открытие — из on_mouse потока окна (обычно по правой кнопке):
 *     wm_menu_open(w, mx, my, items, n, cb, uctx)
 * координаты mx,my — ОТНОСИТЕЛЬНО содержимого окна w (WM сам переводит
 * в экранные). Выбор пункта доставляется потоку владельца как WEV_MENU:
 * колбэк cb(id, uctx) исполняется в ЕГО потоке — данные приложения
 * не требуют блокировок. Закрытие: клик по пункту, Esc, клик мимо.
 * Другие приложения могут строить свои меню на этом же API. */
#define CMENU_ITEM_H 20

typedef struct {
    int  open;
    int  x, y, w, h;          /* экранные координаты бокса */
    int  hover;               /* индекс пункта под курсором или -1 */
    window_t *owner;          /* окно-владелец (для доставки WEV_MENU) */
    const wm_menu_item_t *items;
    int  n;
    wm_menu_fn cb;            /* колбэк приложения (исполнить в его потоке) */
    void *uctx;               /* контекст колбэка */
} cmenu_t;
static cmenu_t g_cmenu;

static void cmenu_geom(void)
{
    int maxw = 120;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (g_cmenu.items[i].label)
            /* ширина по СИМВОЛАМ (utf8_count_chars): strlen кириллицы
             * вдвое шире нарисованного — лишние пустые поля справа */
            maxw = (maxw > utf8_count_chars(g_cmenu.items[i].label, -1) * 8 + 34)
                   ? maxw : utf8_count_chars(g_cmenu.items[i].label, -1) * 8 + 34;
    }
    int hh = 6;
    for (int i = 0; i < g_cmenu.n; i++)
        hh += g_cmenu.items[i].label ? CMENU_ITEM_H : 9;
    g_cmenu.w = maxw;
    g_cmenu.h = hh + 2;
}

static void draw_cmenu(void)
{
    fb_fill_rect(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h, COL_MENU);
    fb_rect(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h, COL_MENU_LINE);
    int y = g_cmenu.y + 3;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (!g_cmenu.items[i].label) {          /* разделитель */
            fb_hline(g_cmenu.x + 1, g_cmenu.x + g_cmenu.w - 2, y + 4, COL_MENU_LINE);
            y += 9;
            continue;
        }
        int hot = (g_cmenu.hover == i) && !g_cmenu.items[i].disabled;
        if (hot) fb_fill_rect(g_cmenu.x + 2, y, g_cmenu.w - 4, CMENU_ITEM_H, COL_MENU_HOT);
        fb_text(g_cmenu.x + 12, y + (CMENU_ITEM_H - 16) / 2, g_cmenu.items[i].label,
                g_cmenu.items[i].disabled ? COL_TEXT_DIM : (hot ? COL_TEXT : COL_TEXT_DIM),
                -1);
        y += CMENU_ITEM_H;
    }
}

/* Индекс пункта по экранной точке (разделители пропускаются) */
static int cmenu_hit(int x, int y)
{
    if (x < g_cmenu.x || x >= g_cmenu.x + g_cmenu.w ||
        y < g_cmenu.y || y >= g_cmenu.y + g_cmenu.h)
        return -1;
    int yy = g_cmenu.y + 3;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (!g_cmenu.items[i].label) { yy += 9; continue; }
        if (y >= yy && y < yy + CMENU_ITEM_H) return i;
        yy += CMENU_ITEM_H;
    }
    return -1;
}

/* ПЕРФ (hover): прямоугольник одного пункта контекстного меню */
static int cmenu_item_rect(int idx, int *rx, int *ry, int *rw, int *rh)
{
    if (idx < 0 || idx >= g_cmenu.n || !g_cmenu.items[idx].label) return 0;
    int yy = g_cmenu.y + 3;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (!g_cmenu.items[i].label) { yy += 9; continue; }
        if (i == idx) {
            *rx = g_cmenu.x + 2; *ry = yy;
            *rw = g_cmenu.w - 4; *rh = CMENU_ITEM_H;
            return 1;
        }
        yy += CMENU_ITEM_H;
    }
    return 0;
}

void wm_menu_open(window_t *owner, int content_x, int content_y,
                  const wm_menu_item_t *items, int n, wm_menu_fn cb, void *uctx)
{
    if (!items || n <= 0 || !owner) return;
    /* контентные координаты -> экранные */
    int cx = 0, cy = 0, cw = 0, ch = 0;
    win_content_rect(owner, &cx, &cy, &cw, &ch);
    int sx = cx + content_x, sy = cy + content_y;

    memset(&g_cmenu, 0, sizeof(g_cmenu));
    g_cmenu.open = 1;
    g_cmenu.items = items;
    g_cmenu.n = n;
    g_cmenu.owner = owner;
    g_cmenu.cb = cb;
    g_cmenu.uctx = uctx;
    g_cmenu.hover = -1;
    cmenu_geom();
    g_cmenu.x = sx;
    g_cmenu.y = sy;
    if (g_cmenu.x + g_cmenu.w > (int)fb_width())
        g_cmenu.x = (int)fb_width() - g_cmenu.w - 2;
    if (g_cmenu.y + g_cmenu.h > (int)fb_height() - TBAR_H)
        g_cmenu.y = (int)fb_height() - TBAR_H - g_cmenu.h - 2;
    if (g_cmenu.x < 0) g_cmenu.x = 0;
    if (g_cmenu.y < 0) g_cmenu.y = 0;
    fb_touch(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h);
}

void wm_menu_close(void)
{
    if (!g_cmenu.open) return;
    int x = g_cmenu.x, y = g_cmenu.y, w_ = g_cmenu.w, h_ = g_cmenu.h;
    memset(&g_cmenu, 0, sizeof(g_cmenu));
    fb_touch(x, y, w_, h_);
}

int wm_menu_active(void) { return g_cmenu.open; }

/* ===================== чекбоксы (сессия 14) =====================
 * ПЕРЕИСПОЛЬЗУЕМЫЙ компонент. Состояние хранит приложение — компонент
 * только рисует и проверяет попадание клика. Рисует флажок в акцентном
 * цвете системы; рамка — светло-серая, подпись — цветом вызывающего. */
void wm_checkbox_draw(int x, int y, const char *label, int checked, u32 text_color)
{
    /* коробка 12x12 */
    fb_fill_rect(x, y, 12, 12, fb_rgb(0x0E, 0x12, 0x17));
    fb_rect(x, y, 12, 12, checked ? wm_theme_accent() : fb_rgb(0x55, 0x5E, 0x68));
    if (checked) {
        /* галочка из пиксельных сегментов (V с длинной правой ветвью) */
        u32 c = wm_theme_accent();
        fb_fill_rect(x + 3, y + 6, 2, 2, c);   /* левое плечо */
        fb_fill_rect(x + 4, y + 7, 2, 2, c);
        fb_fill_rect(x + 5, y + 8, 2, 2, c);   /* нижняя вершина */
        fb_fill_rect(x + 6, y + 7, 2, 2, c);
        fb_fill_rect(x + 7, y + 6, 2, 2, c);
        fb_fill_rect(x + 8, y + 5, 2, 2, c);   /* правое плечо вверх */
        fb_fill_rect(x + 9, y + 4, 2, 2, c);
    }
    if (label && label[0])
        fb_text(x + 18, y - 2, label, text_color, -1);
}

int wm_checkbox_hit(int mx, int my, int x, int y, const char *label)
{
    int w = 18 + utf8_count_chars(label, -1) * 8;
    if (w < 30) w = 30;
    return (mx >= x && mx < x + w && my >= y - 2 && my < y + 14);
}

/* ===================== вписанный текст и кнопки (сессия 20) =====================
 * Запрос пользователя: «переписать код кнопок, чтобы они гарантированно
 * держали текст внутри (при необходимости обрезали)».
 * Причина дефекта: центровка по strlen*8 считала кириллицу ДВАЖДЫ
 * (2 байта на символ при отрисовке 8 px на СИМВОЛ) — надписи («Новая»
 * в сапёре, «Сохранить» в диалогах) уезжали за пределы кнопки.
 *
 *   wm_text_fit    — текст, гарантированно уложенный в max_w px
 *                    (обрезка по СИМВОЛАМ UTF-8, символы не рвутся,
 *                    хвост обозначается «..»);
 *   wm_button_draw — кнопка: фон/рамка/подпись ПО ЦЕНТРУ, подпись
 *                    гарантированно внутри (обрезка как выше);
 *   wm_button_hit  — попадание курсора в кнопку. */
int wm_text_fit(int x, int y, const char *s, int max_w, u32 color, int center)
{
    if (!s || !s[0] || max_w < 8) return 0;

    const char *p = s;
    char buf[96];
    int tw = (int)fb_text_w(s);

    if (tw > max_w) {
        /* не помещается: сколько СИМВОЛОВ влезает с запасом на «..»
         * (символа «…» в шрифте нет — обозначаем двумя точками) */
        int max_chars = (max_w - 16) / 8;
        if (max_chars < 1) max_chars = 1;
        int nb = utf8_take_bytes(s, -1, max_chars);
        if (nb > (int)sizeof(buf) - 3) nb = (int)sizeof(buf) - 3;
        for (int i = 0; i < nb; i++) buf[i] = s[i];
        buf[nb] = '.'; buf[nb + 1] = '.'; buf[nb + 2] = 0;
        p = buf;
        tw = (int)fb_text_w(p);
        if (tw > max_w) {
            /* даже «..» не влезли (max_w < 24): один первый ЦЕЛЫЙ символ */
            int fl = utf8_seq_len((unsigned char)s[0]);
            if (fl > (int)sizeof(buf) - 1) fl = (int)sizeof(buf) - 1;
            for (int i = 0; i < fl; i++) buf[i] = s[i];
            buf[fl] = 0;
            p = buf;
            tw = (int)fb_text_w(p);
        }
    }

    int dx = center ? x + (max_w - tw) / 2 : x;
    fb_text(dx, y, p, color, -1);
    return tw;
}

void wm_button_draw(int x, int y, int w, int h, const char *label,
                    u32 bg, u32 fg, u32 border)
{
    if (w < 2 || h < 2) return;
    fb_fill_rect(x, y, w, h, bg);
    fb_rect(x, y, w, h, border);
    if (label && label[0] && h >= 12)
        wm_text_fit(x + 4, y + (h - 16) / 2, label, w - 8, fg, 1);
}

int wm_button_hit(int mx, int my, int x, int y, int w, int h)
{
    return mx >= x && mx < x + w && my >= y && my < y + h;
}

/* ===================== тема оформления (сессия 15) =====================
 * Три базовых цвета + производные. Всё хранится в ARGB (формат fb_rgb:
 * 0xFF000000 | r<<16 | g<<8 | b). Смена темы применяется ко ВСЕМ окнам:
 * приложения обязаны рисовать фон/текст через wm_theme_*() (переведены
 * все системные приложения сессией 15). THEME.CFG на RAM disk:
 *   winbg=RRGGBB / text=RRGGBB / title=RRGGBB   (hex, без 0x). */

#define THEME_FILE "THEME.CFG"

typedef struct {
    u32 win_bg, text, title;        /* базовые (настраиваются) */
    u32 win_bg_alt, text_dim, text_info, title_unfoc, title_text,
        accent, border, sel_bg;    /* производные (смешение) */
    /* Запрос: акцент и приглушённый текст выбираются в Настройках
     * явно. *_set = 1 — пользователь задал цвет вручную: производное
     * смешение для него НЕ вычисляется (перекрывает auto). */
    u32 accent_user, dim_user;
    int  accent_set, dim_set;
} wm_theme_t;

static wm_theme_t g_theme;

/* Базовые цвета стандартной тёмной темы (формат fb_rgb — ARGB).
 * fb_rgb() — функция, в статический инициализатор не годится. */
#define THEME_DEFAULT_BG    0xFF101318u   /* fb_rgb(0x10,0x13,0x18) */
#define THEME_DEFAULT_TEXT  0xFFE6EAEEu   /* fb_rgb(0xE6,0xEA,0xEE) */
#define THEME_DEFAULT_TITLE 0xFF1E4A73u   /* fb_rgb(0x1E,0x4A,0x73) */

/* Смешение цветов: fa = доля a (0..255). col_mix(a,b,255)=a. */
static u32 col_mix(u32 a, u32 b, int fa)
{
    if (fa < 0) fa = 0;
    if (fa > 255) fa = 255;
    int fb = 255 - fa;
    int r = ((int)((a >> 16) & 0xFF) * fa + (int)((b >> 16) & 0xFF) * fb) / 255;
    int g = ((int)((a >> 8) & 0xFF) * fa + (int)((b >> 8) & 0xFF) * fb) / 255;
    int bl = ((int)(a & 0xFF) * fa + (int)(b & 0xFF) * fb) / 255;
    return 0xFF000000u | ((u32)r << 16) | ((u32)g << 8) | (u32)bl;
}

/* число ВИДИМЫХ символов UTF-8 (кириллица = 2 байта, но 1 символ;
 * fb_text рисует 8 px на СИМВОЛ — hit-зоны должны считать так же,
 * а не strlen по байтам) — общая utf8_count_chars() из utf8.h */

static void apply_user(wm_theme_t *t);   /* форвард: определение ниже */

static void theme_recompute(void)
{
    wm_theme_t *t = &g_theme;
    /* СТАНДАРТНАЯ тема: производные — БАЙТ-В-БАЙТ прежняя палитра
     * N2600-OS (до сессии 15). Это важно не только для привычного вида:
     * OCR-регрессионные тесты и пиксельные проверки (цвет рамки окна)
     * опираются на точные значения. Смешение — только для ПОЛЬЗОВАТЕЛЬСКИХ
     * тем, где точных значений нет и контраст важнее совпадения. */
    if (t->win_bg == THEME_DEFAULT_BG && t->text == THEME_DEFAULT_TEXT &&
        t->title == THEME_DEFAULT_TITLE) {
        t->text_dim   = 0xFF9AA3ACu;   /* прежний fb_rgb(0x9A,0xA3,0xAC) */
        t->text_info  = 0xFF8AC8E8u;   /* прежний fb_rgb(0x8A,0xC8,0xE8) */
        t->win_bg_alt = 0xFF12161Bu;   /* прежний fb_rgb(0x12,0x16,0x1B) */
        t->title_unfoc = 0xFF252A30u;  /* прежний fb_rgb(0x25,0x2A,0x30) */
        t->title_text = t->text;
        t->accent     = 0xFF6FB3F2u;   /* прежний fb_rgb(0x6F,0xB3,0xF2) */
        t->border     = 0xFF3E7DBFu;   /* прежний COL_ACCENT (рамка окна) */
        t->sel_bg     = 0xFF24435Fu;   /* прежний fb_rgb(0x24,0x43,0x5F) */
        apply_user(&g_theme);          /* акцент/приглушённый из Настроек */
        return;
    }
    /* пользовательская тема: производные вычисляем смешением так,
     * чтобы сохранить читаемость при ЛЮБЫХ базовых цветах */
    /* затемнённый/приглушённый текст — к фону */
    t->text_dim   = col_mix(t->text, t->win_bg, 150);
    /* акцентный текст — к базовому тексту, с оттенком заголовка */
    t->text_info  = col_mix(t->text, t->title, 190);
    /* шапки внутри окна — чуть светлее фона */
    t->win_bg_alt = col_mix(t->win_bg, t->text, 14);
    /* неактивный заголовок — к фону окна */
    t->title_unfoc = col_mix(t->title, t->win_bg, 60);
    /* текст заголовка: контраст к цвету заголовка (свет или тьма) */
    t->title_text = t->text;
    /* акцент (галочки/вкладки) — светлее заголовка к тексту */
    t->accent = col_mix(t->title, t->text, 55);
    /* рамка активного окна — темнее акцента (к заголовку) */
    t->border = col_mix(t->title, t->text, 30);
    /* фон выделения — заголовок к фону окна */
    t->sel_bg = col_mix(t->title, t->win_bg, 65);
    apply_user(t);
}

/* Пользовательские акцент/приглушённый (если заданы в Настройках)
 * перекрывают вычисленные смешением значения. Отдельная функция,
 * чтобы покрыть и стандартную, и пользовательскую ветки. */
static void apply_user(wm_theme_t *t)
{
    if (t->accent_set) t->accent   = t->accent_user;
    if (t->dim_set)    t->text_dim = t->dim_user;
}

u32 wm_theme_win_bg(void)      { return g_theme.win_bg; }
u32 wm_theme_win_bg_alt(void)  { return g_theme.win_bg_alt; }
u32 wm_theme_text(void)        { return g_theme.text; }
u32 wm_theme_text_dim(void)    { return g_theme.text_dim; }
u32 wm_theme_text_info(void)   { return g_theme.text_info; }
u32 wm_theme_title(void)       { return g_theme.title; }
u32 wm_theme_title_unfoc(void) { return g_theme.title_unfoc; }
u32 wm_theme_title_text(void)  { return g_theme.title_text; }
u32 wm_theme_accent(void)      { return g_theme.accent; }
u32 wm_theme_border(void)      { return g_theme.border; }
u32 wm_theme_sel_bg(void)      { return g_theme.sel_bg; }

static void theme_save(void);   /* форвард: определение ниже */

u32 wm_theme_get_accent(void)  { return g_theme.accent; }
u32 wm_theme_get_dim(void)     { return g_theme.text_dim; }

/* Ручной акцент/приглушённый из палитры Настроек: применяется ко всем
 * окнам, сохраняется в THEME.CFG (accent=/dim=; отсутствие ключа —
 * автозначение). */
void wm_theme_set_accent(u32 c)
{
    g_theme.accent_user = c;
    g_theme.accent_set = 1;
    theme_recompute();
    theme_save();
    wm_invalidate_all();
}

void wm_theme_set_dim(u32 c)
{
    g_theme.dim_user = c;
    g_theme.dim_set = 1;
    theme_recompute();
    theme_save();
    wm_invalidate_all();
}

void wm_theme_get_rgb(u32 *win_bg, u32 *text, u32 *title)
{
    if (win_bg) *win_bg = g_theme.win_bg;
    if (text)   *text   = g_theme.text;
    if (title)  *title  = g_theme.title;
}

void wm_invalidate_all(void)
{
    /* [H1-FIX]: смена темы — блокирующий wl_lock подвешивал вызвавший
     * поток (окно Настроек) до 20 с при зависшем держателе. Ограниченные
     * попытки с короткими паузами (вызыватель — поток окна, может
     * спать; kmain здесь не участвует). Не дожались — полный кадр всё
     * равно заказываем, окна догонят следующей инвалидацией. */
    for (int attempt = 0; attempt < 10; attempt++) {
        if (wl_trylock_ms(&wm_glock, 50)) {
            for (int i = 0; i < nwin; i++) {
                window_t *w = wins[i];
                if (w) win_invalidate(w);
            }
            wl_unlock(&wm_glock);
            /* рамки/заголовки рисует композитор — нужен полный кадр */
            fb_touch_all();
            return;
        }
        task_msleep(20);
    }
    serial_puts("[wm] invalidate_all: wm_glock занята — окна обновятся позже\n");
    fb_touch_all();
}

/* hex "RRGGBB" -> u32 ARGB; 1 = успешно */
static int theme_parse_hex(const char *s, u32 *out)
{
    u32 v = 0;
    for (int i = 0; i < 6; i++) {
        char c = s[i];
        int d;
        if (c >= '0' && c <= '9') d = c - '0';
        else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
        else return 0;
        v = (v << 4) | (u32)d;
    }
    *out = 0xFF000000u | ((v & 0xFF0000u)) | (v & 0xFF00u) | ((v & 0xFFu));
    return 1;
}

/* «в обратную сторону» для THEME.CFG: ARGB -> "RRGGBB" */
static void theme_format_hex(u32 c, char *out /* >=8 байт */)
{
    static const char *h = "0123456789ABCDEF";
    u32 v = c & 0xFFFFFFu;
    out[0] = h[(v >> 20) & 0xF];
    out[1] = h[(v >> 16) & 0xF];
    out[2] = h[(v >> 12) & 0xF];
    out[3] = h[(v >> 8) & 0xF];
    out[4] = h[(v >> 4) & 0xF];
    out[5] = h[v & 0xF];
    out[6] = 0;
}

static void theme_save(void)
{
    if (!ramfs_ready()) return;
    char buf[160];
    char c1[8], c2[8], c3[8], c4[8], c5[8];
    theme_format_hex(g_theme.win_bg, c1);
    theme_format_hex(g_theme.text, c2);
    theme_format_hex(g_theme.title, c3);
    int L = snprintf(buf, sizeof(buf), "winbg=%s\ntext=%s\ntitle=%s\n",
                     c1, c2, c3);
    /* Ручные акцент/приглушённый пишутся ТОЛЬКО если заданы: старый
     * THEME.CFG (без ключей) и отсутствие ключа = авто-значения. */
    if (g_theme.accent_set) {
        theme_format_hex(g_theme.accent_user, c4);
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "accent=%s\n", c4);
    }
    if (g_theme.dim_set) {
        theme_format_hex(g_theme.dim_user, c5);
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "dim=%s\n", c5);
    }
    ramfs_delete(THEME_FILE);
    if (ramfs_create(THEME_FILE, (u32)L + 1))
        ramfs_write(THEME_FILE, buf, (u32)L + 1);
}

static void theme_apply(u32 win_bg, u32 text, u32 title)
{
    g_theme.win_bg = win_bg;
    g_theme.text = text;
    g_theme.title = title;
    theme_recompute();
}

void wm_theme_set(u32 win_bg, u32 text, u32 title)
{
    theme_apply(win_bg, text, title);
    theme_save();
    wm_invalidate_all();
}

void wm_theme_reset(void)
{
    g_theme.accent_set = 0;   /* акцент/приглушённый снова авто */
    g_theme.dim_set = 0;
    theme_apply(THEME_DEFAULT_BG, THEME_DEFAULT_TEXT, THEME_DEFAULT_TITLE);
    theme_save();
    wm_invalidate_all();
}

int wm_theme_load(void)
{
    theme_recompute();
    if (!ramfs_ready()) return 0;
    char buf[128];
    u32 n = ramfs_read(THEME_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    u32 bg = 0, tx = 0, ti = 0, ac = 0, dm = 0;
    int ac_set = 0, dm_set = 0;
    const char *p = buf;
    while (*p) {
        const char *e = p;
        while (*e && *e != '\n' && *e != '\r') e++;
        char saved = *e;
        *(char *)e = 0;
        if (strncmp(p, "winbg=", 6) == 0)      theme_parse_hex(p + 6, &bg);
        else if (strncmp(p, "text=", 5) == 0)  theme_parse_hex(p + 5, &tx);
        else if (strncmp(p, "title=", 6) == 0) theme_parse_hex(p + 6, &ti);
        else if (strncmp(p, "accent=", 7) == 0)
            ac_set = theme_parse_hex(p + 7, &ac);
        else if (strncmp(p, "dim=", 4) == 0)
            dm_set = theme_parse_hex(p + 4, &dm);
        *(char *)e = saved;
        p = (*e) ? e + 1 : e;
    }
    g_theme.accent_user = ac;  g_theme.accent_set = ac_set;
    g_theme.dim_user = dm;     g_theme.dim_set = dm_set;
    if (bg && tx && ti) {
        theme_apply(bg, tx, ti);
        return 1;
    }
    return 0;
}

/* ===================== виджеты: чекбоксы и радиобоксы (сессия 15) =====================
 * Виджеты ПОЛУЧАЮЩИЕ СОБЫТИЯ МЫШИ: WM вставил диспетчеризацию в цикл
 * потока окна (WEV_MOUSE) — до вызова on_mouse приложения. Приложение
 * только объявляет массив (win_widgets_set) и рисует (wm_widgets_draw).
 * Состояние (*value) принадлежит приложению; клик меняет его в ПОТОКЕ
 * ОКНА — гонок с draw/on_key нет. */

void win_widgets_set(window_t *w, wm_widget_t *widgets, int count)
{
    if (!w) return;
    if (count < 0) count = 0;
    /* вызывается потоком окна при создании — гонок нет; но очистим
     * и от старого массива на всякий повторный вызов */
    w->widgets = (count > 0) ? (void *)widgets : NULL;
    w->nwidgets = count;
}

void win_widgets_clear(window_t *w)
{
    if (!w) return;
    w->widgets = NULL;
    w->nwidgets = 0;
}

/* зона виджета: коробка/круг + подпись (высота 16) */
static int widget_hit(const wm_widget_t *g, int mx, int my)
{
    int w = 18 + utf8_count_chars(g->label, -1) * 8;
    if (w < 34) w = 34;
    return (mx >= g->x && mx < g->x + w && my >= g->y && my < g->y + 16);
}

int wm_widgets_dispatch(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    if (!w || !w->widgets || w->nwidgets <= 0) return 0;
    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT)) return 0;
    wm_widget_t *ws = (wm_widget_t *)w->widgets;
    /* ДВА прохода (сессия 15, FIX пересечения зон):
     * 1) точное попадание в МАРКЕР (кружок/квадрат 13x13) —
     *    перекрывающиеся подписи не мешают;
     * 2) иначе — первый виджет, чья зона (маркер+подпись) содержит
     *    точку. Зона считается по ВИДИМЫМ СИМВОЛАМ UTF-8, а не по
     *    байтам: strlen кириллицы вдвое шире отрисованного текста,
     *    и зона «Быстрое (оглавление)» перекрывала соседний
     *    радиобокс — клик по «Полное» доставался первому виджету. */
    for (int pass = 0; pass < 2; pass++) {
    for (int i = 0; i < w->nwidgets; i++) {
        wm_widget_t *g = &ws[i];
        if (g->hidden || !g->enabled || !g->value) continue;
        int in_marker = (mx >= g->x && mx < g->x + 13 &&
                         my >= g->y && my < g->y + 16);
        if (pass == 0 ? !in_marker : (in_marker || !widget_hit(g, mx, my)))
            continue;
        int changed_state = 0;
        if (g->type == WM_WIDGET_CHECK) {
            *g->value = *g->value ? 0 : 1;
            changed_state = 1;
        } else if (g->type == WM_WIDGET_RADIO) {
            if (*g->value != g->radio_value) {
                *g->value = g->radio_value;
                changed_state = 1;
            }
            /* клик по уже выбранному радиобоксу — событие съедено,
             * состояние не менялось (перерисовка не нужна) */
        }
        if (g->on_change) g->on_change(w, i, g->uctx);
        if (changed_state) win_invalidate(w);
        return 1;   /* событие мыши съедено виджетом */
    }
    }
    return 0;
}

/* окружность 12x12 (радиобокс) */
static void draw_radio_ring(int x, int y, u32 c)
{
    fb_hline(x + 3, x + 8, y, c);
    fb_hline(x + 2, x + 9, y + 1, c);
    fb_vline(x + 1, y + 2, y + 9, c);
    fb_vline(x + 10, y + 2, y + 9, c);
    fb_hline(x + 2, x + 9, y + 10, c);
    fb_hline(x + 3, x + 8, y + 11, c);
}

static void draw_radio_dot(int x, int y, u32 c)
{
    fb_fill_rect(x + 4, y + 3, 4, 6, c);
    fb_fill_rect(x + 3, y + 4, 6, 4, c);
}

void wm_widgets_draw(window_t *w)
{
    if (!w || !w->widgets || w->nwidgets <= 0) return;
    wm_widget_t *ws = (wm_widget_t *)w->widgets;
    u32 accent = wm_theme_accent();
    u32 dim = fb_rgb(0x55, 0x5E, 0x68);
    for (int i = 0; i < w->nwidgets; i++) {
        wm_widget_t *g = &ws[i];
        if (g->hidden) continue;
        int active = g->enabled && g->value;
        u32 label_col = active ? wm_theme_text() : wm_theme_text_dim();
        u32 mark_col = active ? accent : dim;
        if (g->type == WM_WIDGET_CHECK) {
            int checked = (g->value && *g->value);
            fb_fill_rect(g->x, g->y + 2, 12, 12, col_mix(wm_theme_win_bg(),
                                                wm_theme_text(), 24));
            fb_rect(g->x, g->y + 2, 12, 12, checked ? mark_col : dim);
            if (checked) {
                /* та же галочка, что у wm_checkbox_draw (проверенная) */
                int x = g->x, y = g->y + 2;
                fb_fill_rect(x + 3, y + 6, 2, 2, mark_col);
                fb_fill_rect(x + 4, y + 7, 2, 2, mark_col);
                fb_fill_rect(x + 5, y + 8, 2, 2, mark_col);
                fb_fill_rect(x + 6, y + 7, 2, 2, mark_col);
                fb_fill_rect(x + 7, y + 6, 2, 2, mark_col);
                fb_fill_rect(x + 8, y + 5, 2, 2, mark_col);
                fb_fill_rect(x + 9, y + 4, 2, 2, mark_col);
            }
        } else if (g->type == WM_WIDGET_RADIO) {
            int sel = (g->value && *g->value == g->radio_value);
            draw_radio_ring(g->x, g->y + 2, sel ? mark_col : dim);
            if (sel) draw_radio_dot(g->x, g->y + 2, mark_col);
        }
        if (g->label[0])
            fb_text(g->x + 18, g->y, g->label, label_col, -1);
    }
}

/* Прямоугольник tooltip при текущем положении курсора (сессия 12):
 * та же арифметика, что в composite — чтобы помечать на перерисовку
 * ровно то место, где tooltip рисуется. */
static void tooltip_rect(int *tx, int *ty, int *tw, int *th)
{
    const char *title = (tooltip_win_idx >= 0 && tooltip_win_idx < nwin)
                        ? wins[tooltip_win_idx]->title : "";
    *tw = utf8_count_chars(title, -1) * 8 + 12;
    *tx = cur_x + 14;
    *ty = cur_y - 20;
    if (*tx + *tw > (int)fb_width()) *tx = (int)fb_width() - *tw - 2;
    if (*ty < 0) *ty = cur_y + 20;
    *th = 18;
}

/* Полностью ли dirty-прямоугольник накрыт одним видимым окном:
 * тогда фон под ним рисовать НЕ нужно (все пиксели всё равно будут
 * перекрыты). Особенно выгодно при развёрнутом окне (браузер,
 * редактор, терминал): каждый мелкий dirty больше не гоняет blit
 * обоев впустую. */
/* СЕССИЯ 85 (мерцание «чёрным фоном» при рисовании окна поверх другого):
 * canvas нового окна создаётся с тёмной заливкой, а ПЕРВУЮ отрисовку
 * содержимого выполняет поток окна (need_draw). Пока она не случилась,
 * композитор рисовал окно тёмной заливкой поверх нижнего окна — на
 * 1..N кадров место «просвечивало чёрным». Теперь окно, чей canvas ещё
 * ни разу не отрисован, композитором ПРОПУСКАЕТСЯ (и не перекрывает
 * нижние окна в covered-оптимизации): на экране сохраняется прежний
 * кадр, а готовое окно появляется целиком, уже с содержимым. */
/* СЕССИЯ 85 (запрос пользователя): индикатор «инициализация служб» —
 * небольшая панель НАД часами (над таскбаром) с полосой прогресса;
 * показывает, какая часть фоновых служб уже отработала, и исчезает
 * при полной готовности. Счётчик ведёт kernel.c (wm_boot_progress).
 * Отрисовка — в composite (панель живёт над таскбаром). */
static int boot_total = 0;        /* всего шагов (0 = индикатор неактивен) */
static int boot_done = 0;         /* выполнено шагов */

/* Экранный прямоугольник панели индикатора (правый нижний угол,
 * сразу НАД таскбаром — «над часами»). */
static void wm_boot_rect(int *bx, int *by, int *bw, int *bh)
{
    u32 W = fb_width(), H = fb_height();
    *bw = 19 * 8 + 12;             /* подпись «инициализация служб» + поля */
    *bh = 30;                      /* подпись 10 + полоса 6 + поля */
    *bx = (int)W - 8 - *bw;
    *by = (int)H - TBAR_H - *bh - 2;
}

static void draw_boot_progress(void)
{
    int bx, by, bw, bh;
    wm_boot_rect(&bx, &by, &bw, &bh);
    if (bx < 0 || by < 0) return;
    fb_fill_rect(bx, by, bw, bh, fb_rgb(0x18, 0x1D, 0x24));
    fb_rect(bx, by, bw, bh, COL_MENU_LINE);
    fb_text(bx + 6, by + 4, "инициализация служб", COL_TEXT_DIM, -1);
    int bar_y = by + bh - 10, bar_h = 6, bar_w = bw - 12;
    fb_fill_rect(bx + 6, bar_y, bar_w, bar_h, fb_rgb(0x24, 0x2B, 0x33));
    int fill = (boot_total > 0) ? (int)((u32)boot_done * (u32)bar_w / (u32)boot_total) : 0;
    if (fill > 0) fb_fill_rect(bx + 6, bar_y, fill, bar_h, wm_theme_accent());
}

void wm_boot_progress(int done, int total)
{
    if (total <= 0) return;
    if (done > total) done = total;
    if (done < 0) done = 0;
    int was_active = (boot_total > 0 && boot_done < boot_total);
    boot_total = total;
    boot_done = done;
    int active = (boot_done < boot_total);
    if (active || was_active) {
        int bx, by, bw, bh;
        wm_boot_rect(&bx, &by, &bw, &bh);
        fb_touch(bx, by, bw, bh);          /* появление/обновление/исчезновение */
    }
}

static int win_ready(window_t *w)
{
    if (!w->canvas) return 1;                 /* без canvas — как раньше */
    win_thr_t *t = (win_thr_t *)w->thr;
    if (!t || t->no_canvas) return 1;         /* c4gfx: рисует задача */
    return t->drawn_once;
}

static int rect_covered_by_window(int rx0, int ry0, int rx1, int ry1)
{
    for (int i = nwin - 1; i >= 0; i--) {
        window_t *w = wins[i];
        if (!w || w->minimized || !win_ready(w)) continue;
        if (w->x <= rx0 && w->y <= ry0 &&
            w->x + w->w - 1 >= rx1 && w->y + w->h - 1 >= ry1)
            return 1;
    }
    return 0;
}

/* ================= Task 51 [OOM-OVERLAY]: аварийное сообщение
 * «нет памяти» БЕЗ аллокаций =================
 * Куча исчерпана -> окну-сообщению (msgbox) не хватает памяти на СВОЁ
 * окно: canvas 300x150x4 = 180 КиБ + стек задачи потока. Сообщение о
 * нехватке памяти само молча не показывалось (только serial), и запуск
 * приложения выглядел как «нажимаю — ничего не происходит». Теперь есть
 * последняя линия: оверлей рисуется КОМПОЗИТОРОМ поверх всего кадра из
 * СТАТИЧЕСКИХ буферов — ни одной аллокации ни при показе, ни при
 * отрисовке (состояние живёт в .bss — в памяти ВСЕГДА, как просил
 * пользователь). Закрытие: любая клавиша или кнопка мыши, либо
 * авто-таймаут 15 с. */

#define OOM_OV_MS      15000u   /* авто-скрытие, мс */
#define OOM_OV_LINES   5
#define OOM_OV_LCH     58       /* символов в строке (8 px/символ) */

static struct {
    int  active;
    u32  until;            /* тик авто-скрытия */
    char title[40];
    char lines[OOM_OV_LINES][OOM_OV_LCH + 1];
    int  nlines;
} oom_ov;

/* Показать оверлей (вызывается из failure-веток wm_msgbox — когда даже
 * окну-сообщению не хватило памяти). НИ ОДНОЙ аллокации. */
void wm_oom_overlay_show(const char *title, const char *text)
{
    oom_ov.active = 0;
    oom_ov.nlines = 0;
    oom_ov.title[0] = 0;
    strncpy(oom_ov.title, title ? title : "", sizeof(oom_ov.title) - 1);
    oom_ov.title[sizeof(oom_ov.title) - 1] = 0;
    const char *p = text ? text : "";
    while (*p && oom_ov.nlines < OOM_OV_LINES) {
        const char *nl = strchr(p, '\n');
        int len = nl ? (int)(nl - p) : (int)strlen(p);
        if (len > 0) {
            int take = utf8_take_bytes(p, len, OOM_OV_LCH);
            if (take > len) take = len;
            memcpy(oom_ov.lines[oom_ov.nlines], p, (u32)take);
            oom_ov.lines[oom_ov.nlines][take] = 0;
        }
        oom_ov.nlines++;
        if (!nl) break;
        p = nl + 1;
    }
    oom_ov.until = timer_ticks() + OOM_OV_MS;
    oom_ov.active = 1;
    fb_touch(0, 0, (int)fb_width(), (int)fb_height());
}

static void wm_oom_overlay_hide(void)
{
    if (!oom_ov.active) return;
    oom_ov.active = 0;
    fb_touch(0, 0, (int)fb_width(), (int)fb_height());   /* кадр без оверлея */
}

static void draw_oom_overlay(void)
{
    u32 W = fb_width(), H = fb_height();
    int pw = 470;
    if (pw > (int)W - 24) pw = (int)W - 24;
    int ph = 30 + oom_ov.nlines * 16 + 26;
    int px = ((int)W - pw) / 2;
    int py = ((int)H - TBAR_H - ph) / 2;
    if (py < 8) py = 8;

    /* тень, панель, рамка, шапка */
    fb_fill_rect(px + 4, py + 4, pw, ph, fb_rgb(0x05, 0x06, 0x08));
    fb_fill_rect(px, py, pw, ph, fb_rgb(0x18, 0x1E, 0x26));
    fb_rect(px, py, pw, ph, fb_rgb(0xC0, 0x3A, 0x3A));
    fb_fill_rect(px + 1, py + 1, pw - 2, 20, fb_rgb(0x8A, 0x28, 0x28));
    fb_text(px + 8, py + 3, oom_ov.title, fb_rgb(0xFF, 0xFF, 0xFF), -1);
    for (int i = 0; i < oom_ov.nlines; i++)
        fb_text(px + 10, py + 27 + i * 16, oom_ov.lines[i],
                wm_theme_text(), -1);
    fb_text(px + 10, py + ph - 18, "Любая клавиша или клик — закрыть",
            fb_rgb(0x78, 0x80, 0x8C), -1);
}

/* ----------------------------- композитинг ----------------------------- */
/* ЗАДАЧА 53 (запрос пользователя, «окклюзия»): ПОЛНОСТЬЮ ли окно w
 * закрыто ОКНАМИ ВЫШЕ (с индекса from_idx) в пределах dirty-прямоугольника?
 * Проверка — вычитанием прямоугольников верхних окон из видимой части w:
 * список непокрытых кусков опустел -> рисовать нечего (пиксели w всё
 * равно будут перекрыты). Раньше: (1) опечатка — нижняя граница видимой
 * части сравнивалась с rx1 вместо ry1, при типовых ШИРОКИХ dirty-полосах
 * (touch всего окна: 0..799 x y1..y2) граница выходила ЗА экран и
 * отсечение почти никогда не срабатывало; (2) закрытие требовало ОДНОГО
 * окна на всю видимую часть — комбинация двух-трёх перекрывающих окон
 * не отсекалась вовсе. Переполнение списка кусков (WM_OCC_MAX) трактуем
 * консервативно: считаем окно видимым (потеря перфа, не артефакт).
 * v не готов (canvas ещё не отрисован, сессия 85) — не накрывает: в
 * ЭТОМ кадре его рисовать не будем, нижние окна обязаны просвечивать. */
#define WM_OCC_MAX 16
static int win_fully_occluded(window_t *w, int from_idx,
                              int rx0, int ry0, int rx1, int ry1)
{
    /* видимая (в пределах dirty) часть окна */
    int wx0 = (w->x > rx0) ? w->x : rx0;
    int wy0 = (w->y > ry0) ? w->y : ry0;
    int wx1 = (w->x + w->w - 1 < rx1) ? w->x + w->w - 1 : rx1;
    int wy1 = (w->y + w->h - 1 < ry1) ? w->y + w->h - 1 : ry1;   /* [FIX rx1->ry1] */
    if (wx0 > wx1 || wy0 > wy1) return 1;    /* пересечения нет — пусто */

    /* непокрытые куски; начинаем с одного — вся видимая часть */
    int qx0[WM_OCC_MAX], qy0[WM_OCC_MAX], qx1[WM_OCC_MAX], qy1[WM_OCC_MAX];
    int nq = 0;
    qx0[nq] = wx0; qy0[nq] = wy0; qx1[nq] = wx1; qy1[nq] = wy1; nq++;

    for (int j = from_idx; j < nwin && nq > 0; j++) {
        window_t *v = wins[j];
        if (v->minimized || !win_ready(v)) continue;
        int vx1 = v->x + v->w - 1, vy1 = v->y + v->h - 1;
        int n = nq;
        nq = 0;
        for (int k = 0; k < n; k++) {
            int ax0 = qx0[k], ay0 = qy0[k], ax1 = qx1[k], ay1 = qy1[k];
            /* v не пересекает кусок — кусок остаётся целиком */
            if (v->x > ax1 || vx1 < ax0 || v->y > ay1 || vy1 < ay0) {
                if (nq >= WM_OCC_MAX) return 0;      /* консервативно */
                qx0[nq] = ax0; qy0[nq] = ay0; qx1[nq] = ax1; qy1[nq] = ay1; nq++;
                continue;
            }
            /* v режет кусок на до 4 полос вокруг пересечения */
            int ly0 = (v->y > ay0) ? v->y : ay0;
            int ly1 = (vy1 < ay1) ? vy1 : ay1;
            if (v->y > ay0) {                        /* полоса НАД v */
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = ay0; qx1[nq] = ax1; qy1[nq] = v->y - 1; nq++;
            }
            if (vy1 < ay1) {                         /* полоса ПОД v */
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = vy1 + 1; qx1[nq] = ax1; qy1[nq] = ay1; nq++;
            }
            if (v->x > ax0) {                        /* СЛЕВА от v */
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = ly0; qx1[nq] = v->x - 1; qy1[nq] = ly1; nq++;
            }
            if (vx1 < ax1) {                         /* СПРАВА от v */
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = vx1 + 1; qy0[nq] = ly0; qx1[nq] = ax1; qy1[nq] = ly1; nq++;
            }
        }
    }
    return (nq == 0);        /* ни одного непокрытого пикселя */
}

static void composite(int rx0, int ry0, int rx1, int ry1)
{
    u32 W = fb_width(), H = fb_height();

    if (!rect_covered_by_window(rx0, ry0, rx1, ry1))
        fb_blit_bg(rx0, ry0, rx1, ry1);

    /* ПЕРФ (запрос пользователя, «окклюзия», ЗАДАЧА 53): окна рисуются
     * снизу вверх, blit непрозрачен (полная копия canvas) — окно,
     * ПОЛНОСТЬЮ закрытое в пределах dirty-прямоугольника окнами ВЫШЕ
     * (одним или НЕСКОЛЬКИМИ вместе), не рисуем вовсе. */
    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (w->minimized) continue;     /* свёрнутые окна не отрисовываются */
        if (!win_ready(w)) continue;    /* сессия 85: canvas ещё не отрисован */
        if (!rect_intersect(w->x, w->y, w->w, w->h, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1))
            continue;
        if (win_fully_occluded(w, i + 1, rx0, ry0, rx1, ry1))
            continue;
        int cx0 = (w->x < rx0) ? rx0 : w->x;
        int cy0 = (w->y < ry0) ? ry0 : w->y;
        int cx1 = (w->x + w->w - 1 > rx1) ? rx1 : w->x + w->w - 1;
        int cy1 = (w->y + w->h - 1 > ry1) ? ry1 : w->y + w->h - 1;
        fb_set_clip(cx0, cy0, cx1, cy1);
        draw_window(w);
        fb_set_clip(rx0, ry0, rx1, ry1);
    }

    if (ry1 >= (int)H - TBAR_H) {
        fb_set_clip(rx0, (int)H - TBAR_H, rx1, (int)H - 1);
        draw_taskbar();
    }

    /* СЕССИЯ 85: панель «инициализация служб» над часами (исчезает
     * при полной готовности — область просто перекрашивается без неё) */
    if (boot_total > 0 && boot_done < boot_total) {
        int bx, by, bw, bh;
        wm_boot_rect(&bx, &by, &bw, &bh);
        if (bx <= rx1 && by <= ry1 && bx + bw - 1 >= rx0 && by + bh - 1 >= ry0) {
            int vx0 = bx > rx0 ? bx : rx0;
            int vy0 = by > ry0 ? by : ry0;
            int vx1 = (bx + bw - 1) < rx1 ? (bx + bw - 1) : rx1;
            int vy1 = (by + bh - 1) < ry1 ? (by + bh - 1) : ry1;
            fb_set_clip(vx0, vy0, vx1, vy1);
            draw_boot_progress();
        }
    }

    if (menu_open || menu_closing > 0) {
        int mx, my, mw, mh;
        menu_rect(&mx, &my, &mw, &mh);
        int vh = menu_visible_h();
        if (vh > 0 &&
            rect_intersect(mx, my + mh - vh, mw, vh,
                           rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            /* клип = dirty ∩ ВИДИМАЯ полоса меню: при закрытии
             * освободившиеся полосы рисуются без меню */
            int vx0 = mx > rx0 ? mx : rx0;
            int vy0 = (my + mh - vh) > ry0 ? (my + mh - vh) : ry0;
            int vx1 = (mx + mw - 1) < rx1 ? (mx + mw - 1) : rx1;
            int vy1 = (my + mh - 1) < ry1 ? (my + mh - 1) : ry1;
            if (vx0 <= vx1 && vy0 <= vy1) {
                fb_set_clip(vx0, vy0, vx1, vy1);
                draw_menu();
            }
        }
    }

    if (g_cmenu.open) {                       /* сессия 13: контекстное меню */
        if (rect_intersect(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h,
                           rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_cmenu();
        }
    }

    /* [HDA-SWVOL] панель громкости над таскбаром (регулятор у значка сети) */
    if (vol_open) {
        int px, py, pw, ph;
        vol_panel_rect(&px, &py, &pw, &ph);
        if (rect_intersect(px, py, pw, ph,
                           rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            int vx0 = px > rx0 ? px : rx0;
            int vy0 = py > ry0 ? py : ry0;
            int vx1 = (px + pw - 1) < rx1 ? (px + pw - 1) : rx1;
            int vy1 = (py + ph - 1) < ry1 ? (py + ph - 1) : ry1;
            if (vx0 <= vx1 && vy0 <= vy1) {
                fb_set_clip(vx0, vy0, vx1, vy1);
                draw_vol_panel();
            }
        }
    }

    /* Task 51 [OOM-OVERLAY]: аварийное сообщение поверх всего (кроме
     * курсора). Истёк таймаут — гасим здесь, композитор и так в кадре. */
    if (oom_ov.active) {
        if ((int)(timer_ticks() - oom_ov.until) >= 0) {
            oom_ov.active = 0;
            fb_touch(0, 0, (int)fb_width(), (int)fb_height());
        } else {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_oom_overlay();
        }
    }

    if (cursor_visible && !gfx2d_cursor_ready()) {
        if (rect_intersect(cur_x, cur_y, 12, 19, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_cursor();
        }
    }

    /* Tooltip: показываем полный заголовок окна при наведении на таскбар */
    if (tooltip_win_idx >= 0 && tooltip_win_idx < nwin && tooltip_timer > 3) {
        int tx, ty, tw, th;
        tooltip_rect(&tx, &ty, &tw, &th);
        fb_set_clip(0, 0, (int)fb_width() - 1, (int)fb_height() - 1);
        fb_fill_rect(tx, ty, tw, th, fb_rgb(0x33, 0x33, 0x33));
        fb_rect(tx, ty, tw, th, wm_theme_accent());
        fb_text(tx + 6, ty + 1, wins[tooltip_win_idx]->title,
                fb_rgb(0xFF, 0xFF, 0xFF), -1);
    }

    fb_set_clip(0, 0, (int)W - 1, (int)H - 1);
}

/* ================= анимации (запрос пользователя: только меню
 * Пуск и разворачивание окон; выключаются в Настройках) =================
 * Меню раскрывается снизу вверх (от кнопки Пуск) за 3 шага по ~20 мс
 * и ЗАКРЫВАЕТСЯ в обратную сторону (сворачивается вниз к Пуску).
 * Никакого альфа-смешения (нет на 32bpp без потерь) — чистая геометрия:
 * на каждом шаге касаем только НОВУЮ полосу меню (старые полосы уже
 * нарисованы и не трогаются) — стоимость анимации близка к нулю. */

static int menu_visible_h(void)
{
    int mh = menu_height();
    if (menu_anim <= 0 && menu_closing <= 0) return mh;
    int k;
    if (menu_closing > 0) k = menu_closing;              /* сжатие: полос остаётся k/steps */
    else                  k = WM_MENU_ANIM_STEPS - menu_anim + 1;
    if (k > WM_MENU_ANIM_STEPS) k = WM_MENU_ANIM_STEPS;
    if (k < 0) k = 0;
    return mh * k / WM_MENU_ANIM_STEPS;
}

/* Открыть меню Пуск (с анимацией или без) — вызывается из wm_mouse_poll/wm_key */
static void menu_open_animated(void)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    menu_closing = 0;
    if (wm_opt_animations()) {
        menu_anim = WM_MENU_ANIM_STEPS;
        menu_anim_tick = timer_ticks() + WM_ANIM_MS;
        int vh = menu_visible_h();
        fb_touch(mx, my + mh - vh, mw, vh);      /* первая полоса */
    } else {
        menu_anim = 0;
        fb_touch(mx, my, mw, mh);
    }
}

/* ЗАКРЫТЬ меню Пуск с анимацией (или мгновенно). Вызывающий уже снял
 * menu_open — меню логически закрыто, клики сквозь него проходят. */
static void menu_close_animated(void)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    menu_anim = 0;
    if (wm_opt_animations()) {
        menu_closing = WM_MENU_ANIM_STEPS;
        menu_anim_tick = timer_ticks() + WM_ANIM_MS;
        /* до первого шага меню остаётся на экране целиком; дальше
         * wm_menu_anim_tick касает только освободившиеся полосы */
    } else {
        menu_closing = 0;
        fb_touch(mx, my, mw, mh);
    }
}

/* Шаг анимации меню (раскрытие ИЛИ закрытие) — вызывается из wm_frame */
static void wm_menu_anim_tick(void)
{
    u32 now = timer_ticks();

    /* ---- закрытие: меню уходит вниз, к кнопке Пуск ---- */
    if (menu_closing > 0) {
        if ((int)(now - menu_anim_tick) < 0) return;
        int mx, my, mw, mh;
        menu_rect(&mx, &my, &mw, &mh);
        int vh_old = menu_visible_h();
        menu_closing--;
        int vh_new = menu_visible_h();
        if (vh_new < vh_old)
            fb_touch(mx, my + mh - vh_old, mw, vh_old - vh_new);  /* освободившаяся полоса */
        if (menu_closing <= 0) {
            menu_closing = 0;
            if (vh_new > 0)
                fb_touch(mx, my + mh - vh_new, mw, vh_new);       /* последняя полоса */
        }
        menu_anim_tick = now + WM_ANIM_MS;
        return;
    }

    if (!menu_open || menu_anim <= 0) return;
    if ((int)(now - menu_anim_tick) < 0) return;
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    menu_anim--;
    int k = WM_MENU_ANIM_STEPS - menu_anim + 1;
    if (menu_anim <= 0 || k >= WM_MENU_ANIM_STEPS) {
        menu_anim = 0;                            /* раскрыто полностью */
        fb_touch(mx, my, mw, mh);
    } else {
        int vh = mh * k / WM_MENU_ANIM_STEPS;
        fb_touch(mx, my + mh - vh, mw, vh);       /* новая полоса */
    }
    menu_anim_tick = now + WM_ANIM_MS;
}

/* Запуск анимации разворачивания окна: геометрия интерполируется от
 * (sx..sh) к (tx..th); canvas НЕ пересоздаётся до конца (anim_hold) —
 * draw_window рисует его crop в текущий (промежуточный) content-rect.
 * По завершении resize-цикл wm_frame подгонит canvas как обычно. */
static void wm_anim_start(window_t *w, int sx, int sy, int sw, int sh,
                          int tx, int ty, int tw, int th)
{
    w->anim_active = 1;
    w->anim_hold = 1;
    w->anim_to_min = 0;      /* новый сценарий анимации — прежний сброшен */
    w->anim_total = WM_ANIM_STEPS;
    w->anim_steps = WM_ANIM_STEPS;
    w->anim_sx = sx; w->anim_sy = sy; w->anim_sw = sw; w->anim_sh = sh;
    w->anim_tx = tx; w->anim_ty = ty; w->anim_tw = tw; w->anim_th = th;
    w->anim_next_tick = timer_ticks() + WM_ANIM_MS;
    w->x = sx; w->y = sy; w->w = sw; w->h = sh;
}

/* Шаг анимаций всех окон — вызывается из wm_frame (под glock) */
static void wm_anim_tick(void)
{
    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (!w || !w->anim_active) continue;
        if (w->minimized && !w->anim_to_min) {
            /* свёрнули во время анимации — отменить (кроме СВЁРТЫВАНИЯ:
             * там minimized ставится ТОЛЬКО на финальном шаге) */
            w->anim_active = 0;
            w->anim_hold = 0;
            w->anim_to_min = 0;
            continue;
        }
        u32 now = timer_ticks();
        if ((int)(now - w->anim_next_tick) < 0) continue;
        w->anim_steps--;
        int k = w->anim_total - w->anim_steps;    /* 1..total */
        if (w->anim_steps <= 0 || k >= w->anim_total) {
            /* финал: точная конечная геометрия */
            int ox = w->x, oy = w->y, ow = w->w, oh = w->h;
            w->x = w->anim_tx; w->y = w->anim_ty;
            w->w = w->anim_tw; w->h = w->anim_th;
            w->anim_active = 0;
            w->anim_hold = 0;
            if (w->anim_to_min) {
                /* анимация сворачивания в кнопку: окно исчезает,
                 * освобождённая площадь + таскбар перерисовываются */
                w->anim_to_min = 0;
                w->minimized = 1;
                w->resize_defer = 0;
                wm_touch_rect(ox, oy, ow, oh);
                wm_touch_taskbar();
                {
                    int nt2 = top_visible_window();
                    if (nt2 >= 0 && wins[nt2]) wm_touch_title(wins[nt2]);
                }
            } else {
                w->resize_defer = 0;   /* canvas подгонит resize-цикл немедленно */
                wm_touch_union_rect(ox, oy, ow, oh, w->x, w->y, w->w, w->h);
                wm_touch_taskbar();
                if (w->thr) {
                    ((win_thr_t *)w->thr)->need_draw = 1;
                    if (w->task > 0) task_wake(w->task);
                }
            }
        } else {
            int nx = w->anim_sx + (w->anim_tx - w->anim_sx) * k / w->anim_total;
            int ny = w->anim_sy + (w->anim_ty - w->anim_sy) * k / w->anim_total;
            int nw = w->anim_sw + (w->anim_tw - w->anim_sw) * k / w->anim_total;
            int nh = w->anim_sh + (w->anim_th - w->anim_sh) * k / w->anim_total;
            if (nw < 40) nw = 40;
            if (nh < 30) nh = 30;
            wm_touch_union_rect(w->x, w->y, w->w, w->h, nx, ny, nw, nh);
            w->x = nx; w->y = ny; w->w = nw; w->h = nh;
            w->anim_next_tick = now + WM_ANIM_MS;
        }
    }
}

void wm_frame(void)
{
    /* 0) kill-запросы (диспетчер задач/ватчдог) + вычистка мёртвых окон
     *    + старение trash-списка canvas'ов (сессия 12) */
    wm_pump_kills();
    wm_canvas_trash_tick();

    /* 1) отложенные закрытия — до отрисовки.
     * [WM-NOSTALL]: glock — ограниченная попытка; занят (зависший
     * держатель) — оставляем pending_close на следующий кадр. */
    if (pending_close) {
        window_t *w = pending_close;
        if (!wl_trylock_ms(&wm_glock, 50)) {
            wm_glock_stall++;
            if ((wm_glock_stall & 31) == 1)
                serial_puts("[wm] wm_glock занят — закрытие окна отложено\n");
        } else {
            int ox = w->x, oy = w->y, ow = w->w, oh = w->h;
            pending_close = NULL;
            for (int i = 0; i < nwin; i++) {
                if (wins[i] == w) {
                    for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
                    nwin--;
                    break;
                }
            }
            wl_unlock(&wm_glock);

            if (w->task > 0) {
                /* ПОТОК окна сам вызовет on_close (в своём контексте),
                 * отсоединит canvas, освободит их и умрёт (dead=1).
                 * Здесь лишь отправляем CLOSE и ждём смерти в zombies. */
                win_post_close(w);
                if (nzombie < WM_ZOMBIE_MAX) {
                    zombies[nzombie++] = w;
                } else {
                    serial_puts("[wm] zombie list overflow, leaking window\n");
                }
            } else {
                /* окно без потока (страховка) — старый путь */
                if (w->on_close) w->on_close(w);
                if (w->thr) free(w->thr);
                if (w->canvas) free(w->canvas);
                free(w);
            }
            /* ПЕРФ: вместо полного кадра — прежний прямоугольник окна,
             * таскбар (кнопка исчезла) и заголовок нового верхнего окна */
            wm_touch_rect(ox, oy, ow, oh);
            wm_touch_taskbar();
            {
                int nt = top_visible_window();
                if (nt >= 0) wm_touch_title(wins[nt]);
            }
        }
    }

    /* 2) resize: пересоздать canvas окон с изменившейся геометрией.
     * ПЕРФ (запрос пользователя): при интерактивном resize размер растёт
     * на КАЖДОМ ходе мыши — malloc мегабайта + полная заливка + trash +
     * attach каждый кадр. Теперь canvas пересоздаётся не чаще раза в 3
     * кадра (resize_defer); промежуточные кадры показывает stale-путь
     * draw_window (фон + canvas прежнего размера). rlock берём ОДНОЙ
     * попыткой: композитор никогда не ждёт поток приложения, неуспех —
     * просто ещё один кадр со старым canvas. */
    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (!w) continue;
        int ncw = w->w - 2;
        int nch = w->h - TITLE_H - 2;
        if (ncw < 1) ncw = 1;
        if (nch < 1) nch = 1;
        if (w->canvas && w->task > 0 && !w->fixed_size && !w->anim_hold &&
            (w->cvs_w != ncw || w->cvs_h != nch)) {
            if (w->resize_defer > 0) { w->resize_defer--; continue; }
            /* ПЕРФ (запрос пользователя, «resize_defer больше»): во время
             * активного ресайза malloc+заливка+attach НЕ каждый проход
             * главного цикла (было раз в 3 прохода — сотни раз в секунду),
             * а раз в ~24 прохода (~15-30 мс); рамка окна обновляется
             * каждый ход мыши, канвас догоняет с малой задержкой. */
            w->resize_defer = WM_RESIZE_DEFER;
            win_thr_t *t = (win_thr_t *)w->thr;
            if (t && wl_trylock(&t->rlock, 1)) {
                u32 *nc = (u32 *)malloc((u32)ncw * (u32)nch * 4);
                if (nc) {
                    u32 dark = wm_theme_win_bg();
                    /* ПЕРФ: заливка rep stosl (fill32 в fb.c недоступна
                     * извне — здесь свой rep stosl; раньше был цикл по
                     * слову с инкрементом) */
                    u32 words = (u32)ncw * (u32)nch;
#if defined(__i386__) || defined(__x86_64__)
                    {
                        u32 *p = nc;
                        __asm__ __volatile__("rep stosl"
                                             : "+D"(p), "+c"(words)
                                             : "a"(dark)
                                             : "memory");
                    }
#else
                    for (u32 k = 0; k < words; k++) nc[k] = dark;
#endif
                    /* СЕССИЯ 85 (мерцание при ресайзе поверх других окон):
                     * переносим СТАРОЕ содержимое в новый canvas — до
                     * перерисовки потоком окно показывает прежний кадр
                     * (обрезанный до новой геометрии), а не тёмную
                     * заливку на весь content-rect. */
                    if (w->canvas && w->cvs_w > 0 && w->cvs_h > 0) {
                        int cpw = (w->cvs_w < ncw) ? w->cvs_w : ncw;
                        int cph = (w->cvs_h < nch) ? w->cvs_h : nch;
                        for (int r = 0; r < cph; r++)
                            memcpy(nc + (u32)r * (u32)ncw,
                                   w->canvas + (u32)r * (u32)w->cvs_w,
                                   (u32)cpw * 4);
                    }
                    wm_canvas_trash_add(w->canvas);   /* старый — через trash (сессия 12) */
                    w->canvas = nc;
                    w->cvs_w = ncw;
                    w->cvs_h = nch;
                    fb_task_canvas_attach(w->task, nc, ncw, nch);
                    t->need_draw = 1;
                    task_wake(w->task);
                    fb_touch(w->x, w->y, w->w, w->h);
                }
                wl_unlock(&t->rlock);
            }
        }
    }

    if (!fb_ready()) return;

    /* Шаги анимаций (меню Пуск и разворачивание окон) — до выборки
     * dirty: касания шага попадут в ТЕКУЩИЙ кадр. anim_tick меняет
     * геометрию окон — под glock, как композитор.
     * [WM-NOSTALL]: занят — шаг анимации просто пропускаем. */
    if (wl_trylock_ms(&wm_glock, 20)) {
        wm_menu_anim_tick();
        wm_anim_tick();
        wl_unlock(&wm_glock);
    }

    /* Двойная буферизация композитора (FIX «лоскутного» композитинга):
     * 1) АТОМАРНО забираем СПИСОК dirty-прямоугольников (новые touch'и
     *    во время сборки кадра попадают в свежий список — на следующий
     *    кадр, а не теряются и не смешиваются с текущим);
     * 2) каждый прямоугольник пересобирается С НУЛЯ в compose-буфер
     *    (bg + все окна в z-порядке + таскбар + курсор) — внутри
     *    прямоугольника кадр АТОМАРЕН, чужие пиксели из прошлых кадров
     *    исключены по построению;
     * 3) один проход fb_flush_rects выносит готовые области в LFB.
     * [WM-NOSTALL]: glock — ОГРАНИЧЕННАЯ попытка (50 мс). Зависший
     * держатель (задача, застрявшая в win_create/удалении окна)
     * больше НЕ замораживает kmain: кадр пропускаем, dirty-список
     * НЕ забираем — прямоугольники дождутся следующего кадра.
     * Мышь/клавиатура/часы живут — «зависшая задача не вешает WM». */
    if (!wl_trylock_ms(&wm_glock, 50)) {
        wm_glock_stall++;
        if (wm_glock_stall == 1) wm_glock_stall_t0 = timer_ticks();
        if ((wm_glock_stall & 31) == 1) {
            char b[160];
            snprintf(b, sizeof(b),
                     "[wm] wm_glock занят %u кадров — композитор ждёт, "
                     "система жива\n", (unsigned)wm_glock_stall);
            serial_puts(b);
        }
        /* СЕССИЯ 79 [WM-SEIZE]: держатель жив, но не отпускает wm_glock
         * дольше WM_GLOCK_SEIZE_MS. sync.h отбирает зависшие блокировки
         * только у ЖДУЩИХ — композитор больше не ждёт (bounded-trylock),
         * значит некому запустить отбор. Отбираем сами: задача-виновник
         * убивается (kill; её поздний s_unlock не сбежит — s_unlock
         * сверяет владельца), замок освобождается, рендер оживает.
         * Тест: команда spinlock (glock_spin_fn держит замок вечно). */
        if ((u32)(timer_ticks() - wm_glock_stall_t0) > WM_GLOCK_SEIZE_MS) {
            int owner = (int)wm_glock - 1;
            char b[192];
            if (owner >= 0 && owner < MAX_TASKS) {
                snprintf(b, sizeof(b),
                         "[wm] wm_glock отобрана у задачи %d '%s' "
                         "(завис >%u c) — задача снята, рендер восстановлен\n",
                         owner, task_name(owner),
                         (unsigned)(WM_GLOCK_SEIZE_MS / 1000u));
                serial_puts(b);
                task_kill(owner);   /* системные защищены внутри kill */
            } else {
                snprintf(b, sizeof(b),
                         "[wm] wm_glock бесхозно зависла (>сек) — "
                         "принудительно освобождена\n");
                serial_puts(b);
            }
            wm_glock = 0;           /* отбор */
            wm_glock_stall = 0;
        }
        return;
    }
    wm_glock_stall = 0;
    fb_drect_t rects[FB_DIRTY_MAX];
    int nrects = fb_dirty_take(rects, FB_DIRTY_MAX);
    if (nrects <= 0) {
        wl_unlock(&wm_glock);
        return;
    }

    fb_mark_disable();
    for (int r = 0; r < nrects; r++) {
        fb_compose_begin(rects[r].x0, rects[r].y0, rects[r].x1, rects[r].y1);
        /* СЕССИЯ 81 [KMAINFAULT-TEST]: команда kmainfault ставит флаг —
         * следующий кадр композитора гарантированно падает с #0 В САМОМ
         * горячем месте: wm_glock уже занята, rt-цель переключена на
         * compose-буфер, marking выключен. Если KMAIN-RECOVER работает,
         * serial получит «[exc] kmain пережил #0 (eip=...)» + «[wm] glock
         * отпущена» + «[kmain] восстановление», а рабочий стол продолжит
         * рисовать следующим кадром. */
        if (g_wm_fault_next_frame) {
            g_wm_fault_next_frame = 0;
            {
                volatile int zero = 0, one = 1;
                volatile int q = one / zero;   /* вектор #0 */
                (void)q;
            }
        }
        composite(rects[r].x0, rects[r].y0, rects[r].x1, rects[r].y1);
        fb_compose_end();
    }
    wl_unlock(&wm_glock);
    fb_mark_enable();
    fb_flush_rects(fb_compose_buf() ? fb_compose_buf() : NULL, rects, nrects);
    /* back = то, что сейчас на экране: прямые выводы мимо композитора
     * (скриптовые fill_rect/flip, паники) видят актуальный кадр */
    fb_sync_back(rects, nrects);
}

/* ------------------------------- события ------------------------------- */

/* ---- Alt+Tab: переключение окон (запрос пользователя) ----
 * Снапшот видимых окон в z-порядке строится на ПЕРВОМ Alt+Tab (или после
 * паузы >700 мс) — повторные Tab при удержанном Alt идут по списку,
 * как в обычных ОС. Shift+Tab — в обратную сторону. Свёрнутые окна
 * не участвуют (доступны через панель задач). */
static int alttab_list[WM_MAX_WINDOWS];
static int alttab_n = 0;
static int alttab_pos = 0;
static u32 alttab_tick = 0;

static void wm_alttab(int dir)
{
    u32 now = timer_ticks();
    if (alttab_n <= 0 || (int)(now - alttab_tick) > 700 || alttab_pos >= alttab_n) {
        alttab_n = 0;
        /* [H1-FIX]: Alt+Tab — горячий путь kmain (wm_key). Блокирующий
         * wl_lock при зависшем держателе glock = до 20 с без ввода и
         * композитинга. Занято — пропускаем нажатие: снапшот построит
         * следующий Tab (после паузы список всё равно перестраивается). */
        if (!wl_trylock_ms(&wm_glock, 50))
            return;
        for (int i = nwin - 1; i >= 0 && alttab_n < WM_MAX_WINDOWS; i--)
            if (wins[i] && !wins[i]->minimized)
                alttab_list[alttab_n++] = i;
        wl_unlock(&wm_glock);
        alttab_pos = 0;
    }
    alttab_tick = now;
    if (alttab_n < 2) return;                 /* переключать не на что */
    alttab_pos += dir;
    if (alttab_pos < 0) alttab_pos = alttab_n - 1;
    if (alttab_pos >= alttab_n) alttab_pos = 0;
    int idx = alttab_list[alttab_pos];
    if (idx >= 0 && idx < nwin && wins[idx] && !wins[idx]->minimized)
        raise_window(idx);
}

#define KBD_TAB 0x0F

void wm_key(const key_event_t *ev)
{
    /* Task 51 [OOM-OVERLAY]: пока активен аварийный оверлей — он забирает
     * ВСЮ клавиатуру: любая клавиша закрывает (release глушится, чтобы
     * не «провалиться» в окно под оверлеем) */
    if (oom_ov.active) {
        if (!(ev->flags & KF_RELEASED)) wm_oom_overlay_hide();
        return;
    }

    /* ---- системные сочетания (не доходят до приложений) ---- */
    if (!(ev->flags & KF_RELEASED)) {
        /* Alt(+Shift)+Tab — цикл по окнам */
        if (ev->code == KBD_TAB && (ev->flags & KF_ALT)) {
            wm_alttab((ev->flags & KF_SHIFT) ? -1 : 1);
            return;
        }
        /* Win (левая/правая) — открыть/закрыть меню Пуск.
         * PS/2 и USB-клавиатуры дают коды KBD_LWIN/KBD_RWIN.
         * Автоповтор глушим (400 мс), иначе зажатая Win мигает меню. */
        if (ev->code == KBD_LWIN || ev->code == KBD_RWIN) {
            static u32 last_winkey = 0;
            u32 now = timer_ticks();
            if ((int)(now - last_winkey) < 400) return;
            last_winkey = now;
            menu_toggle();
            return;
        }
        /* СЕССИЯ 85: при открытом меню Пуск стрелки/Enter/Esc им управляют
         * (фокус ставится при открытии — см. menu_toggle) */
        if (menu_key_nav(ev)) return;

        /* [VOL-KEYS] итерация 7: открытая панель громкости управляется
         * клавиатурой — ←/→ (и ↑/↓) шаг ±5%, Esc закрывает. Прежде
         * стрелки уходили в окно под панелью, а сам ползунок двигался
         * только мышью. Перехват ДО доставки верхнему окну — панель
         * выше окон (рисуется в composite последней). */
        if (vol_open) {
            if (ev->code == KBD_LEFT || ev->code == KBD_RIGHT ||
                ev->code == KBD_UP   || ev->code == KBD_DOWN) {
                int dir = (ev->code == KBD_RIGHT || ev->code == KBD_UP) ? 5 : -5;
                int v = sound_get_volume() + dir;
                if (v < 0)   v = 0;
                if (v > 100) v = 100;
                sound_set_volume(v);
                int px, py, pw, ph;
                vol_panel_rect(&px, &py, &pw, &ph);
                fb_touch(px - 1, py - 1, pw + 2, ph + 2);
                return;
            }
            if (ev->ch == 0x1B || ev->code == 0x01) {   /* Esc */
                vol_open = 0;
                int px, py, pw, ph;
                vol_panel_rect(&px, &py, &pw, &ph);
                fb_touch(px - 1, py - 1, pw + 2, ph + 2);
                {
                    int vix, viy, viw, vih;
                    vol_icon_rect(&vix, &viy, &viw, &vih);
                    fb_touch(vix - 3, viy - 3, viw + 6, vih + 6);
                }
                return;
            }
        }
    }

    /* Находим верхнее не свёрнутое окно для фокуса */
    int top = top_visible_window();
    if (top < 0) return;
    window_t *w = wins[top];
    if (!w) return;

    /* Событие — в очередь ПОТОКА окна (колбэк выполнится в нём).
     * kmain больше не выполняет код приложений. */
    if (w->task > 0) {
        wev_t e;
        memset(&e, 0, sizeof(e));
        e.kind = WEV_KEY;
        e.key = *ev;
        win_post(w, &e);
    } else if (w->on_key) {
        w->on_key(w, ev);   /* страховка (окна без потока не бывает) */
    }
}

static void start_button_rect(int *bx, int *by, int *bw, int *bh)
{
    *bx = 4; *by = (int)fb_height() - 24; *bw = 64; *bh = 20;
}

/* Открыть/закрыть меню Пуск (кнопка «Меню» или клавиша Win).
 * Закрытие — С АНИМАЦИЕЙ (меню логически закрыто сразу).
 * СЕССИЯ 85: при открытии фокус сразу на первом пункте — стрелки
 * работают без предварительного клика. */
static void menu_toggle(void)
{
    int bx, by, bw, bh;
    start_button_rect(&bx, &by, &bw, &bh);
    menu_open = !menu_open;
    menu_hover = -1;
    menu_kbd_sel = menu_open ? 0 : -1;
    menu_anim = 0;
    if (menu_open) {
        menu_open_animated();
    } else {
        menu_close_animated();
    }
    fb_touch(bx, by, bw, bh);       /* кнопка «Меню» перекрасилась */
}

/* СЕССИЯ 85: клавиатурная навигация по открытому меню Пуск.
 * Возвращает 1, если клавиша обработана меню (до приложений не дошла). */
static int menu_key_nav(const key_event_t *ev)
{
    if (!menu_open) return 0;
    int n = menu_items();

    if (ev->code == KBD_UP || ev->code == KBD_DOWN ||
        ev->code == KBD_LEFT || ev->code == KBD_RIGHT) {
        int dir = (ev->code == KBD_DOWN || ev->code == KBD_RIGHT) ? 1 : -1;
        int sel = menu_kbd_sel;
        if (sel < 0) sel = (dir > 0) ? -1 : n;    /* с края — wrap */
        for (int k = 0; k < n; k++) {             /* разделитель перескакиваем */
            sel += dir;
            if (sel < 0) sel = n - 1;
            if (sel >= n) sel = 0;
            if (sel != menu_sep_idx()) break;
        }
        if (sel == menu_sep_idx()) sel = -1;
        int old = menu_kbd_sel;
        menu_kbd_sel = sel;
        menu_hover = -1;                          /* мышь не спорит с клавиатурой */
        int rx, ry, rw, rh;
        if (old >= 0 && menu_item_rect(old, &rx, &ry, &rw, &rh))
            fb_touch(rx, ry, rw, rh);
        if (sel >= 0 && menu_item_rect(sel, &rx, &ry, &rw, &rh))
            fb_touch(rx, ry, rw, rh);
        return 1;
    }

    if (ev->code == 0x1C /* Enter */) {
        if (menu_kbd_sel >= 0 && menu_kbd_sel < n) {
            int idx = menu_kbd_sel;
            menu_toggle();                        /* закрыть (с анимацией) */
            menu_action(idx);
        }
        return 1;
    }

    if (ev->code == 0x01 /* Esc */) {
        menu_toggle();
        return 1;
    }

    return 0;
}

/* То же, но координаты МОГУТ быть вне содержимого (отрицательные или
 * за границей): нужно при неявном захвате мыши — drag продолжается
 * за пределами окна, и приложение должно видеть реальные координаты
 * (скроллбар сам клампит их в желоб, hit-тесты просто промахиваются). */
static void post_mouse_raw(window_t *w, int x, int y, u8 btn, u8 changed)
{
    if (!w) return;
    int cx, cy, cw, ch;
    win_content_rect(w, &cx, &cy, &cw, &ch);
    if (w->task > 0) {
        wev_t e;
        memset(&e, 0, sizeof(e));
        e.kind = WEV_MOUSE;
        e.mx = x - cx;
        e.my = y - cy;
        e.btn = btn;
        e.changed = changed;
        win_post(w, &e);
    } else if (w->on_mouse) {
        w->on_mouse(w, x - cx, y - cy, btn, changed);
    }
}

/* Экранные координаты -> событие MOUSE в очередь потока окна
 * (координаты относительно содержимого). */
static void post_mouse(window_t *w, int x, int y, u8 btn, u8 changed)
{
    if (!w) return;
    int cx, cy, cw, ch;
    win_content_rect(w, &cx, &cy, &cw, &ch);
    if (x < cx || x >= cx + cw || y < cy || y >= cy + ch) return;
    if (w->task > 0) {
        wev_t e;
        memset(&e, 0, sizeof(e));
        e.kind = WEV_MOUSE;
        e.mx = x - cx;
        e.my = y - cy;
        e.btn = btn;
        e.changed = changed;
        win_post(w, &e);
    } else if (w->on_mouse) {
        w->on_mouse(w, x - cx, y - cy, btn, changed);
    }
}

void wm_mouse_poll(void)
{
    /* Обработка колёсика мыши: прокрутка фокусного окна */
    if (ms_wheel_event) {
        ms_wheel_event = 0;
        int wheel = ms_wheel;
        ms_wheel = 0;
        /* Находим фокусное окно и эмулируем PgUp/PgDn */
        int top = top_visible_window();
        if (top >= 0 && wins[top]) {
            window_t *w = wins[top];
            if (w->task > 0) {
                wev_t e;
                memset(&e, 0, sizeof(e));
                e.kind = WEV_KEY;
                e.key.code = (wheel > 0) ? 0x49 : 0x51;  /* PgUp / PgDn */
                e.key.flags = 0;
                e.key.ch = 0;
                win_post(w, &e);
            } else if (w->on_key) {
                key_event_t ev;
                memset(&ev, 0, sizeof(ev));
                ev.code = (wheel > 0) ? 0x49 : 0x51;
                w->on_key(w, &ev);
            }
        }
    }

    if (!ms_event && !ms_click_latch) return;
    ms_event = 0;

    int x = ms_x, y = ms_y;
    static u8 prev_btn = 0;
    u8 btn = ms_buttons;
    u8 changed = (u8)(btn ^ prev_btn);

    /* СЕССИЯ 31: клики, полностью уложившиеся между опросами. Если latch
     * фиксирует нажатие, которого не видно на уровне (нажали и отпустили
     * за один интервал) — доставляем гарантированный press-edge: в ЭТОМ
     * событии btn притворяется нажатым, prev_btn запоминает нажатое
     * состояние, и следующий опрос честно отдаст release-edge (приложения
     * на него не реагируют). Нажатия, у которых уровень ещё удерживается,
     * и так видны через changed — лишнего события не будет. */
    {
        u8 latched = ms_click_take();
        if (latched) {
            changed |= (u8)(latched & (u8)~btn);  /* нажатия, которых не видно на уровне */
            btn |= latched;                       /* притворяемся нажатым до release */
        }
    }
    prev_btn = btn;

    /* области курсора: старая+новая (объединённо, если близко) */
    wm_touch_cursor_move(cur_x, cur_y, x, y);
    cur_x = x; cur_y = y;
    /* [2D-ускорение]: аппаратная плоскость курсора следует за мышью */
    if (gfx2d_cursor_ready()) gfx2d_cursor_move(cur_x, cur_y);

    /* Task 51 [OOM-OVERLAY]: активный оверлей забирает мышь — любой
     * клик (нажатие или отпускание) закрывает, остальное глушится.
     * Курсор при этом продолжает двигаться (выше). */
    if (oom_ov.active) {
        ms_wheel_event = 0;
        if (changed) wm_oom_overlay_hide();
        return;
    }

    /* Сессия 12 (FIX tooltip): состояние tooltip обновляется ЗДЕСЬ, до
     * всех ранних return (перетаскивание/resize/меню/клики). Раньше
     * открытие меню «замораживало» активный tooltip — он продолжал
     * рисоваться ПОВЕРХ окон и меню, следуя за курсором, пока тот не
     * возвращался на таскбар. Плюс: вместо fb_touch_all() на каждое
     * движение (тяжёлый полный кадр при множестве окон) помечаем только
     * сам прямоугольник tooltip — старый и новый. */
    {
        static int tt_x = -1, tt_y = -1, tt_w = 0;   /* прошлый rect */
        int ti = (btn == 0 && !menu_open && !drag_win && !resize_win)
                 ? taskbar_hit(x, y) : -1;
        if (ti >= 0) {
            if (ti != tooltip_win_idx) {
                tooltip_win_idx = ti;
                tooltip_timer = 0;
            }
            if (tooltip_timer < 1000) tooltip_timer++;
        } else if (tooltip_win_idx >= 0) {
            tooltip_win_idx = -1;
            tooltip_timer = 0;
        }
        int show = (tooltip_win_idx >= 0 && tooltip_win_idx < nwin &&
                    tooltip_timer > 3);
        if (show) {
            int nx, ny, nw, nh;
            tooltip_rect(&nx, &ny, &nw, &nh);
            if (nx != tt_x || ny != tt_y) {
                if (tt_w > 0) fb_touch(tt_x, tt_y, tt_w, 18);   /* стереть старый */
                fb_touch(nx, ny, nw, nh);                       /* новый */
            }
            tt_x = nx; tt_y = ny; tt_w = nw;
        } else if (tt_w > 0) {
            fb_touch(tt_x, tt_y, tt_w, 18);   /* tooltip исчез — перерисовать */
            tt_x = -1; tt_y = -1; tt_w = 0;
        }
    }

    /* --- НЕЯВНЫЙ ЗАХВАТ МЫШИ (сессия 20): ЛКМ удерживается — все
     * события получает окно, где нажали. Блок СТРОГО до меню/таскбара/
     * драга заголовка: пока захвачено, остальной ввод не трогаем. --- */
    if (lmb_win) {
        int alive = !lmb_win->minimized;
        if (alive) {
            alive = 0;
            for (int i = 0; i < nwin; i++)
                if (wins[i] == lmb_win) { alive = 1; break; }
        }
        if (!alive) {
            lmb_win = NULL;              /* окно исчезло — захвата нет */
        } else {
            post_mouse_raw(lmb_win, x, y, btn, changed);
            if (!(btn & MSB_LEFT)) lmb_win = NULL;   /* отпустили — сняли */
            return;
        }
    }

    /* --- контекстное меню (сессия 13): меню забирает весь ввод --- */
    if (g_cmenu.open) {
        int hov = cmenu_hit(x, y);
        if (hov != g_cmenu.hover) {
            /* ПЕРФ: касаем только старый и новый пункт, не всё меню */
            int rx, ry, rw, rh;
            if (g_cmenu.hover >= 0 &&
                cmenu_item_rect(g_cmenu.hover, &rx, &ry, &rw, &rh))
                fb_touch(rx, ry, rw, rh);
            g_cmenu.hover = hov;
            if (hov >= 0 && cmenu_item_rect(hov, &rx, &ry, &rw, &rh))
                fb_touch(rx, ry, rw, rh);
        }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            /* активация пункта — доставка в поток владельца */
            if (hov >= 0 && !g_cmenu.items[hov].disabled &&
                g_cmenu.owner && g_cmenu.owner->task > 0) {
                wev_t e;
                memset(&e, 0, sizeof(e));
                e.kind = WEV_MENU;
                e.menu_id = g_cmenu.items[hov].id;
                e.menu_cb = (void *)g_cmenu.cb;    /* снять ДО close */
                e.menu_ctx = g_cmenu.uctx;
                win_post(g_cmenu.owner, &e);
            }
            wm_menu_close();
            return;                       /* клик проглатывается */
        }
        return;                            /* движение/прочее — меню живёт */
    }

    /* --- нажатие ПКМ: доставить окну (приложения открывают меню) --- */
    if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
        int wi = window_at(x, y);
        if (wi >= 0) {
            window_t *w = wins[wi];
            int cx, cy, cw, ch;
            win_content_rect(w, &cx, &cy, &cw, &ch);
            if (x >= cx && x < cx + cw && y >= cy && y < cy + ch)
                post_mouse(w, x, y, btn, changed);
        }
        return;
    }

    /* --- перетаскивание ползунка громкости [HDA-SWVOL] --- */
    if (vol_drag) {
        if (btn & MSB_LEFT) {
            int px, py, pw, ph;
            vol_panel_rect(&px, &py, &pw, &ph);
            int tx = px + 10, tw = pw - 20;
            int pct = (x - tx) * 100 / (tw - 4);
            if (pct < 0) pct = 0;
            if (pct > 100) pct = 100;
            sound_set_volume(pct);
            fb_touch(px, py, pw, ph);
        } else {
            vol_drag = 0;   /* отпустили */
        }
        return;
    }

    /* --- перетаскивание окна --- */
    if (drag_win && (btn & MSB_LEFT)) {
        int nx = x - drag_dx;
        int ny = y - drag_dy;
        int maxx = (int)fb_width() - 60;
        int maxy = (int)fb_height() - TBAR_H - TITLE_H;
        if (nx > maxx) nx = maxx;
        if (ny > maxy) ny = maxy;
        if (nx < -(drag_win->w - 60)) nx = -(drag_win->w - 60);
        if (ny < 0) ny = 0;
        if (nx != drag_win->x || ny != drag_win->y) {
            /* ПЕРФ (троттлинг): на медленном CPU каждый ход мыши давал
             * композитинг ДВУХ полных прямоугольников окна. Ограничиваем
             * частоту обновления позиции: с содержимым — 25 мс (~40 кадр/с),
             * в быстром режиме (тело залито фоном) — 12 мс. */
            u32 now = timer_ticks();
            int period = wm_opt_drag_content() ? WM_DRAG_MS_CONTENT
                                               : WM_DRAG_MS_FAST;
            if ((int)(now - last_drag_tick) >= period) {
                last_drag_tick = now;
                wm_touch_union_rect(drag_win->x, drag_win->y,
                                    drag_win->w, drag_win->h, nx, ny,
                                    drag_win->w, drag_win->h);
                drag_win->x = nx;
                drag_win->y = ny;
            }
        }
        if (changed & MSB_LEFT) { /* отпущено и нажато одновременно — не бывает */ }
        return;
    }
    if (drag_win && !(btn & MSB_LEFT)) {
        /* Отпустили: в быстром режиме содержимое не рисовалось —
         * возвращаем канвас одним касанием окна (композитор снова
         * начнёт блитить canvas, т.к. drag_win уже NULL). */
        window_t *dw = drag_win;
        drag_win = NULL;
        wm_touch_window(dw);
    }

    /* --- изменение размера окна (перетаскивание правого нижнего угла) --- */
    if (resize_win && (btn & MSB_LEFT)) {
        int nw = resize_start_w + (x - resize_start_x);
        int nh = resize_start_h + (y - resize_start_y);
        if (nw < 80) nw = 80;
        if (nh < 60) nh = 60;
        if (nw > (int)fb_width()) nw = (int)fb_width();
        if (nh > (int)fb_height() - TBAR_H) nh = (int)fb_height() - TBAR_H;
        if (nw != resize_win->w || nh != resize_win->h) {
            /* ПЕРФ: троттлинг — как у перетаскивания (рамка растёт не
             * чаще раза в 12 мс; канвас догоняет своим resize_defer) */
            u32 now = timer_ticks();
            if ((int)(now - last_resize_tick) >= WM_DRAG_MS_FAST) {
                last_resize_tick = now;
                wm_touch_union_rect(resize_win->x, resize_win->y,
                                    resize_win->w, resize_win->h,
                                    resize_win->x, resize_win->y, nw, nh);
                resize_win->w = nw;
                resize_win->h = nh;
                /* обновим prev геометрию (для сворачивания/восстановления) */
                resize_win->prev_w = nw;
                resize_win->prev_h = nh;
            }
        }
        return;
    }
    if (resize_win && !(btn & MSB_LEFT)) {
        resize_win = NULL;
    }

    /* --- нажатие ЛКМ --- */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        /* Двойной клик по заголовку — развернуть/восстановить окно.
         * Отслеживаем время и позицию предыдущего клика. */
        {
            static int last_click_x = -1000, last_click_y = -1000;
            static u32 last_click_tick = 0;
            u32 now = timer_ticks();
            if (now - last_click_tick < 300 &&        /* < 300 мс (1 тик = 1 мс) */
                x > last_click_x - 5 && x < last_click_x + 5 &&
                y > last_click_y - 5 && y < last_click_y + 5) {
                /* возможен double-click: проверим ниже, что это заголовок */
                int wi2 = window_at(x, y);
                if (wi2 >= 0 && y >= wins[wi2]->y &&
                    y < wins[wi2]->y + TITLE_H) {
                    int bx_c, bx_m, bx_n;
                    title_btn_rects(wins[wi2], &bx_c, &bx_m, &bx_n);
                    /* но не по кнопкам */
                    if (x < bx_n) {
                        win_toggle_maximize(wins[wi2]);
                        last_click_tick = 0;
                        return;
                    }
                }
            }
            last_click_x = x; last_click_y = y;
            last_click_tick = now;
        }

        /* меню открыто? — закрыть С АНИМАЦИЕЙ (и выполнить пункт) */
        if (menu_open) {
            int idx = menu_hit(x, y);
            menu_open = 0;
            menu_hover = -1;
            menu_kbd_sel = -1;              /* сессия 85: мышь сняла фокус */
            menu_anim = 0;
            menu_close_animated();
            if (idx >= 0) {
                menu_action(idx);
                return;
            }
            /* клик вне меню — обрабатывается дальше */
        }

        int bx, by, bw, bh;
        start_button_rect(&bx, &by, &bw, &bh);
        if (x >= bx && x < bx + bw && y >= by && y < by + bh) {
            menu_toggle();
            return;
        }

        /* [HDA-SWVOL] значок громкости на таскбаре — открыть/закрыть панель,
         * клик по панели — задать громкость, клик мимо панели — закрыть.
         * Блок ДО taskbar_hit: кнопки задач заканчиваются ЛЕВЕЕ значка
         * (taskbar_btn_end резервирует TB_VOL_W) — наезд невозможен. */
        {
            int ix, iy, iw, ih;
            vol_icon_rect(&ix, &iy, &iw, &ih);
            if (x >= ix - 3 && x < ix + iw + 3 &&
                y >= iy - 3 && y < iy + ih + 3) {
                vol_open = !vol_open;
                int px, py, pw, ph;
                vol_panel_rect(&px, &py, &pw, &ph);
                fb_touch(ix - 3, iy - 3, iw + 6, ih + 6);
                fb_touch(px - 1, py - 1, pw + 2, ph + 2);
                return;
            }
            if (vol_open) {
                int px, py, pw, ph;
                vol_panel_rect(&px, &py, &pw, &ph);
                if (x >= px && x < px + pw && y >= py && y < py + ph) {
                    vol_drag = 1;
                    int tx = px + 10, tw = pw - 20;
                    int pct = (x - tx) * 100 / (tw - 4);
                    if (pct < 0) pct = 0;
                    if (pct > 100) pct = 100;
                    sound_set_volume(pct);
                    fb_touch(px, py, pw, ph);
                    return;
                }
                /* клик мимо открытой панели — закрыть (и обработать далее) */
                vol_open = 0;
                fb_touch(px - 1, py - 1, pw + 2, ph + 2);
                {
                    int vix, viy, viw, vih;
                    vol_icon_rect(&vix, &viy, &viw, &vih);
                    fb_touch(vix - 3, viy - 3, viw + 6, vih + 6);
                }
            }
        }

        /* Клик по кнопке окна на таскбаре — переключение свернуть/развернуть */
        {
            int ti = taskbar_hit(x, y);
            if (ti >= 0) {
                window_t *w = wins[ti];
                int top = top_visible_window();
                if (w->minimized) {
                    /* Восстанавливаем и поднимаем наверх */
                    win_restore(w);
                    raise_window(ti);
                } else if (ti == top) {
                    /* Уже активное окно — сворачиваем */
                    win_minimize(w);
                } else {
                    /* Не в фокусе — поднимаем */
                    raise_window(ti);
                }
                /* ПЕРФ: частичные касания уже сделаны внутри
                 * win_minimize/win_restore/raise_window — полный кадр
                 * (fb_touch_all) здесь больше не нужен */
                return;
            }
        }

        int wi = window_at(x, y);
        if (wi >= 0) {
            window_t *w = wins[wi];
            raise_window(wi);
            /* Проверка: клик в правом нижнем углу (resize handle, 10x10)?
             * Развёрнутое окно ресайзить нельзя. */
            if (!w->maximized && !w->fixed_size &&
                x >= w->x + w->w - 10 && x < w->x + w->w &&
                y >= w->y + w->h - 10 && y < w->y + w->h) {
                resize_win = w;
                resize_start_x = x;
                resize_start_y = y;
                resize_start_w = w->w;
                resize_start_h = w->h;
                return;
            }
            if (y < w->y + TITLE_H) {
                /* три кнопки заголовка: [—] [□] [×] */
                int bx_close, bx_max, bx_min;
                title_btn_rects(w, &bx_close, &bx_max, &bx_min);
                int cby = w->y + 4;
                if (x >= bx_close && x < bx_close + TB_BTN_W &&
                    y >= cby && y < cby + TB_BTN_H) {
                    pending_close = w;
                    fb_touch(bx_close, cby, TB_BTN_W, TB_BTN_H);
                } else if (x >= bx_max && x < bx_max + TB_BTN_W &&
                           y >= cby && y < cby + TB_BTN_H) {
                    /* развернуть/восстановить */
                    win_toggle_maximize(w);
                } else if (x >= bx_min && x < bx_min + TB_BTN_W &&
                           y >= cby && y < cby + TB_BTN_H) {
                    /* свернуть */
                    win_minimize(w);
                } else if (!w->maximized) {
                    /* перетаскивание за заголовок (кроме развёрнутого) */
                    drag_win = w;
                    drag_dx = x - w->x;
                    drag_dy = y - w->y;
                }
                return;
            }
            int cx, cy, cw, ch;
            win_content_rect(w, &cx, &cy, &cw, &ch);
            if (x >= cx && x < cx + cw && y >= cy && y < cy + ch) {
                lmb_win = w;             /* неявный захват до отпускания */
                post_mouse(w, x, y, btn, changed);
            }
            return;
        }
        return;
    }

    /* --- отпускание ЛКМ --- */
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
        if (pending_close) {
            window_t *w = pending_close;
            int bx_close, bx_max, bx_min;
            title_btn_rects(w, &bx_close, &bx_max, &bx_min);
            int cby = w->y + 4;
            if (x >= bx_close && x < bx_close + TB_BTN_W &&
                y >= cby && y < cby + TB_BTN_H &&
                window_at(x, y) >= 0) {
                win_close(w);
            } else {
                pending_close = NULL;
                fb_touch(bx_close, cby, TB_BTN_W, TB_BTN_H);
            }
        }
        /* отдаём отпускание приложению */
        int wi = window_at(x, y);
        if (wi >= 0) {
            post_mouse(wins[wi], x, y, btn, changed);
        }
        return;
    }

    /* --- просто движение / hover меню --- */
    if (menu_open) {
        int hov = menu_hit(x, y);
        if (hov != menu_hover) {
            /* ПЕРФ: касаем только старый и новый пункт, не всё меню */
            int rx, ry, rw, rh;
            if (menu_hover >= 0 &&
                menu_item_rect(menu_hover, &rx, &ry, &rw, &rh))
                fb_touch(rx, ry, rw, rh);
            menu_hover = hov;
            if (hov >= 0 && menu_item_rect(hov, &rx, &ry, &rw, &rh))
                fb_touch(rx, ry, rw, rh);
        }
        return;
    }

    /* движение над окном — отдаём приложению (для рисования мышью) */
    int wi = window_at(x, y);
    if (wi >= 0) {
        post_mouse(wins[wi], x, y, btn, changed);
    }
}

void wm_halfsec(void)
{
    blink_state ^= 1;

    /* [HALFSEC-GLOCK] (зам. №6 разбора кода): итерация по wins[]/nwin —
     * ПОД wm_glock. После [CORE-BALANCE] потоки окон создаются и на AP
     * (win_create держит glock и меняет nwin/slots) — беззамочная
     * прогулка kmain по массиву гонялась с вставкой: указатель
     * «наполовину инициализированного» окна или устаревший nwin.
     * Bounded-trylock (как у композитора): не успели за 20 мс — этот
     * полусекундный проход пропускаем, следующий догонит (WEV_TICK —
     * событие «разбудить», а не «доставить ровно N раз»). Порядок
     * замков glock → qlock сохранён (win_post берёт qlock под ним) —
     * обратного порядка в коде нет. */
    int locked = wl_trylock_ms(&wm_glock, 20);

    /* on_tick — в очередь каждого окна (колбэк вызовет поток окна).
     * ПЕРФ (запрос пользователя): свёрнутые окна не получают WEV_TICK —
     * их канвас всё равно не виден; пробуждения и перерисовки не нужны. */
    if (locked) {
        for (int i = 0; i < nwin; i++) {
            window_t *w = wins[i];
            if (!w || !w->on_tick || w->minimized) continue;
            if (w->task > 0) {
                wev_t e;
                memset(&e, 0, sizeof(e));
                e.kind = WEV_TICK;
                win_post(w, &e);
            } else {
                w->on_tick(w);
            }
        }
        wl_unlock(&wm_glock);
    }

    /* часы в таскбаре (ПЕРФ: меняются обычно только СЕКУНДЫ — касаем
     * только изменившиеся символы вместо полосы 168 px на весь таскбар;
     * значок сети — только при смене состояния) */
    static int last_sec = -1;
    static char last_clock[9] = "";
    static int last_nic = -1;
    static u32 last_net_ip = 0, last_net_tr = 0;
    int h, m, s;
    rtc_get_time(&h, &m, &s);
    if (s != last_sec) {
        last_sec = s;
        char buf[16];
        snprintf(buf, sizeof(buf), "%02d:%02d:%02d", h, m, s);
        int clock_x = (int)fb_width() - 8 - 64;
        for (int i = 0; i < 8; i++)
            if (buf[i] != last_clock[i])
                fb_touch(clock_x + i * 8, (int)fb_height() - 22, 8, 16);
        memcpy(last_clock, buf, sizeof(last_clock));
    }
    {
        int nic = net_nic_present();
        u32 ip = net_get_ip();
        u32 tr = net_tx_packets() + net_rx_packets();
        if (nic != last_nic || ip != last_net_ip ||
            (tr & 0x3) != (last_net_tr & 0x3)) {
            last_nic = nic;
            last_net_ip = ip;
            last_net_tr = tr;
            /* зона значка (IP-подписи больше нет; та же арифметика, что
             * в draw_taskbar: icon_x = W-100, значок 20 px) */
            fb_touch((int)fb_width() - 108, (int)fb_height() - TBAR_H,
                     100, TBAR_H);
        }
    }
}

/* -------------------------------- API -------------------------------- */

window_t *win_create(const char *title, int x, int y, int ww, int wh,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data)
{
    /* Всё создание окна — под wm_glock: атомарная проверка свободного слота
     * wins[] и вставка (без TOCTOU между потоками, открывающими окна).
     * Время удержания ~1-2 мс (malloc canvas + memset) — приемлемо. */
    window_t *w = NULL;
    u32 *canvas = NULL;
    win_thr_t *thr = NULL;

    wl_lock(&wm_glock);
    if (nwin >= WM_MAX_WINDOWS) {
        wl_unlock(&wm_glock);
        /* СЕССИЯ 78 [WM-DIAG]: исчерпание окон (жалоба «окна закончились»
         * при запусках JS) раньше оставляло только msgbox. В serial —
         * кто запросил: видно, какой поток/скрипт плодит окна. */
        {
            extern void serial_puts(const char *s);
            char b[96];
            int t = task_current();
            snprintf(b, sizeof(b),
                     "[wm] ЛИМИТ ОКОН (%d): запрос от задачи %d '%s'\n",
                     (int)WM_MAX_WINDOWS, t, task_name(t));
            serial_puts(b);
        }
        wm_oom_report(1);              /* сессия 22: объясняем, а не молчим */
        return NULL;
    }

    w = (window_t *)malloc(sizeof(window_t));
    if (w) memset(w, 0, sizeof(window_t));
    if (w) {
        strncpy(w->title, title, sizeof(w->title) - 1);
        w->draw = draw;
        w->on_key = on_key;
        w->on_mouse = on_mouse;
        w->on_tick = on_tick;
        w->on_close = on_close;
        w->data = data;
        w->task = -1;
        w->serial = win_serial_next++;   /* FIX [W1]: стабильный таскбар */
    }

    /* геометрия: не даём окну выйти за экран */
    if (w) {
        u32 W = fb_width(), H = fb_height();
        if (ww > (int)W) ww = (int)W;
        if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x + ww > (int)W) x = (int)W - ww;
        if (y + wh > (int)H - TBAR_H) y = (int)H - TBAR_H - wh;
        w->x = x; w->y = y;
        w->w = ww; w->h = wh;
        w->minimized = 0;
        w->prev_x = x; w->prev_y = y; w->prev_w = ww; w->prev_h = wh;
    }

    /* ---- canvas + поток ---- */
    if (w) {
        int ncw = ww - 2;
        int nch = wh - TITLE_H - 2;
        if (ncw < 1) ncw = 1;
        if (nch < 1) nch = 1;
        canvas = (u32 *)malloc((u32)ncw * (u32)nch * 4);
        thr = (win_thr_t *)malloc(sizeof(win_thr_t));
        if (canvas && thr) {
            memset(thr, 0, sizeof(*thr));
            u32 dark = wm_theme_win_bg();
            u32 words = (u32)ncw * (u32)nch;
            for (u32 k = 0; k < words; k++) canvas[k] = dark;
            w->canvas = canvas;
            w->cvs_w = ncw;
            w->cvs_h = nch;
            w->thr = thr;
            thr->need_draw = 1;    /* первичная отрисовка */
        }
    }

    if (w && w->thr) {
        /* Имя задачи — заголовок окна, обрезанный по ГРАНИЦЕ UTF-8
         * символа (кириллица = 2 байта: обрезать посередине нельзя —
         * в диспетчере задач появится битый символ). */
        char tname[16];
        {
            const char *s = title;
            int o = 0;
            while (*s && o < 15) {
                int adv = 1;
                if ((*s & 0xE0) == 0xC0 && s[1]) adv = 2;
                else if ((*s & 0xF0) == 0xE0 && s[1] && s[2]) adv = 3;
                if (o + adv > 15) break;
                for (int k = 0; k < adv; k++) tname[o++] = s[k];
                s += adv;
            }
            tname[o] = 0;
        }
        int tid = task_spawn_prio(tname, win_thread_fn, w, TASK_PRIO_UI);
        if (tid > 0) {
            window_t *prev_top = (nwin > 0) ? wins[nwin - 1] : NULL;
            w->task = tid;
            if (!fb_task_canvas_attach(tid, w->canvas, w->cvs_w, w->cvs_h)) {
                /* слоты кончились (64): окно без canvas — поток не ждёт */
                win_set_no_canvas(w);
            }
            wins[nwin++] = w;          /* наверх стека */
            wl_unlock(&wm_glock);
            /* ПЕРФ: вместо полного кадра — новое окно, таскбар (новая
             * кнопка) и заголовок прежнего фокусного (цвет ушёл) */
            wm_touch_window(w);
            wm_touch_taskbar();
            if (prev_top && prev_top != w) wm_touch_title(prev_top);
            return w;
        }
        /* spawn не удался — вернуть всё */
        free(w->thr);
        free(w->canvas);
    }
    if (thr) free(thr);
    if (canvas) free(canvas);
    if (w) free(w);
    wl_unlock(&wm_glock);
    /* Сессия 22: окно не создалось (память/поток) — показываем сообщение
     * вместо молчаливого отказа. Приложение при этом НЕ откроется:
     * apps_launch увидит, что новых окон нет, но повторный отчёт будет
     * подавлен кулдауном 10 с. */
    wm_oom_report(0);
    return NULL;
}

void win_close(window_t *w)
{
    if (w) pending_close = w;
}

/* ==================== окно-сообщение (сессия 22) ====================
 * Запрос пользователя: «когда памяти не хватает на запуск приложения,
 * оно просто молча не запускается — добавь окно с информацией».
 *
 * wm_msgbox — маленькое диалоговое окно (заголовок, до 5 строк текста,
 * кнопка «ОК»), wm_oom_report — сообщение о причинах неудачного запуска
 * (нехватка памяти / лимит окон). Вызывается:
 *   - из НЕУДАЧНЫХ веток win_create (не хватило окну),
 *   - из apps_launch (реестр/лаунчер): окно приложения так и не появилось.
 * Рекурсия и шторм подавляются (флаг + кулдаун 10 с); если памяти нет
 * даже для самого окна-сообщения — последняя линия связи: serial-лог. */

#define MSGBOX_W        300
#define MSGBOX_H        150
#define MSGBOX_MAXLINES 5
#define MSGBOX_LINECH   60      /* символов в строке (8px/символ) */

typedef struct {
    char lines[MSGBOX_MAXLINES][MSGBOX_LINECH + 1];
    int  nlines;
    int  hot, pressed;
} wm_msgbox_t;

static void msgbox_draw(window_t *w)
{
    wm_msgbox_t *d = (wm_msgbox_t *) w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    for (int i = 0; i < d->nlines; i++)
        wm_text_fit(10, 8 + i * 16, d->lines[i], cw - 20,
                    wm_theme_text(), 0);

    /* кнопка «ОК» по центру внизу */
    int bx = (cw - 90) / 2, by = ch - 30;
    u32 bg = (d->pressed) ? wm_theme_sel_bg()
           : (d->hot)     ? fb_rgb(0x32, 0x60, 0x8E)
                          : wm_theme_title();
    wm_button_draw(bx, by, 90, 20, "ОК", bg, wm_theme_title_text(),
                   wm_theme_border());
}

static void msgbox_key(window_t *w, const key_event_t *ev)
{
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01 ||   /* Esc */
        ev->code == 0x1C || ev->ch == ' ')       /* Enter/Space */
        win_close(w);
}

static void msgbox_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    wm_msgbox_t *d = (wm_msgbox_t *) w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int bx = (cw - 90) / 2, by = ch - 30;

    int hot = wm_button_hit(mx, my, bx, by, 90, 20);
    if (hot != d->hot) { d->hot = hot; win_invalidate(w); }

    if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && hot) {
        d->pressed = 1;
        win_invalidate(w);
    }
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
        int wp = d->pressed;
        d->pressed = 0;
        if (wp && hot) { win_close(w); return; }
        win_invalidate(w);
    }
    if (!btn && d->pressed) {          /* ушли с отпущенной кнопкой */
        d->pressed = 0;
        win_invalidate(w);
    }
}

static void msgbox_close(window_t *w)
{
    free(w->data);
}

void wm_msgbox(const char *title, const char *text)
{
    wm_msgbox_t *d = (wm_msgbox_t *) malloc(sizeof(wm_msgbox_t));
    if (!d) {
        /* Task 51 [OOM-OVERLAY]: нет памяти даже под ДАННЫЕ сообщения —
         * безаллокационный оверлей теперь последняя линия связи
         * (раньше здесь был только serial, пользователь ничего не видел) */
        wm_oom_overlay_show(title, text);
        serial_puts("[wm] msgbox: нет памяти под данные сообщения — показан оверлей; текст:\n");
        serial_puts(text);
        serial_puts("\n");
        return;
    }
    memset(d, 0, sizeof(*d));
    d->hot = -1;                        /* pressed = 0 (не нажата) */

    /* разбор текста на строки (по '\n'), обрезка по символам UTF-8 */
    {
        const char *p = text;
        while (*p && d->nlines < MSGBOX_MAXLINES) {
            const char *nl = strchr(p, '\n');
            int len = nl ? (int) (nl - p) : (int) strlen(p);
            if (len > 0) {
                int take = utf8_take_bytes(p, len, MSGBOX_LINECH);
                if (take > len) take = len;
                memcpy(d->lines[d->nlines], p, (u32) take);
                d->lines[d->nlines][take] = 0;
            }
            d->nlines++;
            if (!nl) break;
            p = nl + 1;
        }
    }

    u32 W = fb_width(), H = fb_height();
    int wx = ((int) W - MSGBOX_W) / 2;
    int wy = ((int) H - TBAR_H - MSGBOX_H) / 2;
    if (wx < 0) wx = 0;
    if (wy < 0) wy = 0;

    window_t *w = win_create(title, wx, wy, MSGBOX_W, MSGBOX_H,
                             msgbox_draw, msgbox_key, msgbox_mouse,
                             NULL, msgbox_close, d);
    if (!w) {
        free(d);
        serial_puts("[wm] не удалось показать окно-сообщение (нет памяти) — "
                    "текст:\n");
        serial_puts(text);
        serial_puts("\n");
        /* Task 51 [OOM-OVERLAY]: окну сообщения не хватило памяти
         * (обычно — canvas 180 КиБ + стек задачи при исчерпанной куче).
         * Показываем оверлей из статики: сообщение о нехватке памяти
         * видно ВСЕГДА, даже когда куча пуста. */
        wm_oom_overlay_show(title, text);
    }
}

void wm_oom_report(int kind)
{
    static u32 last_tick;
    static int inside;

    if (inside) return;                       /* не рекурсируем */
    u32 now = timer_ticks();
    if (last_tick && now - last_tick < 10000) /* не чаще раза в 10 с (1 тик = 1 мс) */
        return;
    last_tick = now;
    inside = 1;

    if (kind < 0)                             /* авто-детект причины */
        kind = (nwin >= WM_MAX_WINDOWS) ? 1 : 0;

    if (kind == 1) {
        /* СЕССИЯ 82: число берём из WM_MAX_WINDOWS (не зашитое «32») —
         * текст всегда синхронен лимиту wins[]. */
        char text[220];
        snprintf(text, sizeof(text),
                 "Достигнут лимит открытых окон (%d).\n"
                 "Закройте ненужные окна и попробуйте\n"
                 "запустить приложение ещё раз.",
                 (int)WM_MAX_WINDOWS);
        wm_msgbox("Слишком много окон", text);
    } else {
        u32 largest = 0, nfree = 0;
        u32 total = mem_debug_walk(&largest, &nfree);
        char text[220];
        snprintf(text, sizeof(text),
                 "Недостаточно памяти для запуска приложения.\n"
                 "Закройте другие окна и попробуйте снова.\n"
                 "Свободно: %u КиБ (макс. блок %u КиБ)",
                 (unsigned) (total / 1024), (unsigned) (largest / 1024));
        wm_msgbox("Недостаточно памяти", text);
    }
    inside = 0;
}

/* wm_window_count() объявлена ниже, рядом с wm_window_visible_count */

/* Сессия 12: пометить окно как «без canvas у потока» — вызывается
 * c4gfx ПОСЛЕ win_create и ДО fb_task_canvas_detach(w->task):
 * поток окна не должен ждать attach, который сознательно отменён. */
void win_set_no_canvas(window_t *w)
{
    if (w && w->thr)
        ((win_thr_t *)w->thr)->no_canvas = 1;
}

void win_draw_now(window_t *w)
{
    if (!w || !w->thr) return;
    if (w->task <= 0 || w->task != task_current()) return;  /* только свой поток */
    win_thr_t *t = (win_thr_t *)w->thr;
    if (w->minimized || !w->draw || !w->canvas) return;
    /* [H7c-FIX]: canvas отключён от задачи (attach не удался / c4gfx) —
     * рисование уйдёт в ЭКРАННЫЙ контекст поверх левого верхнего угла.
     * Пропускаем (см. комментарий в win_thread_fn). */
    if (t->no_canvas || !fb_task_has_canvas(w->task)) return;
    t->need_draw = 0;
    wl_lock(&t->rlock);            /* vs realloc при resize (kmain) */
    fb_set_clip(0, 0, w->cvs_w - 1, w->cvs_h - 1);
    fb_set_origin(0, 0);
    w->draw(w);
    wl_unlock(&t->rlock);
    fb_touch(w->x, w->y, w->w, w->h);
}

void win_invalidate(window_t *w)
{
    if (!w) return;
    /* Новая семантика (многопоточный WM): помечаем canvas к перерисовке
     * и будим ПОТОК окна — он отрисует и сам пометит экранную область
     * (fb_touch) по завершении. Прямой fb_touch здесь убран: иначе экран
     * обновился бы со СТАРЫМ canvas. */
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
        return;
    }
    if (!w->minimized)
        fb_touch(w->x, w->y, w->w, w->h);   /* окно без потока (страховка) */
}

/* Свернуть окно (С АНИМАЦИЕЙ в кнопку таскбара — запрос пользователя):
 * геометрия интерполируется к прямоугольнику СВОЕЙ кнопки на панели;
 * окно всё это время рисуется (minimized ставится на финальном шаге).
 * prev_* запоминаются ДО старта анимации — восстановление вернёт их. */
void win_minimize(window_t *w)
{
    if (!w || w->minimized) return;
    if (w->anim_active && w->anim_to_min) {
        /* повторный minimize при идущей анимации сворачивания:
         * дособираем мгновенно (prev_* уже сохранены первым вызовом) */
        w->anim_active = 0;
        w->anim_hold = 0;
        w->anim_to_min = 0;
        w->minimized = 1;
        wm_touch_rect(w->x, w->y, w->w, w->h);
        wm_touch_taskbar();
        return;
    }
    if (w->anim_active) {
        /* клик по «свернуть» во время анимации разворачивания:
         * мгновенно завершаем её точной конечной геометрией */
        w->x = w->anim_tx; w->y = w->anim_ty;
        w->w = w->anim_tw; w->h = w->anim_th;
        w->anim_active = 0;
        w->anim_hold = 0;
        w->resize_defer = 0;
    }
    w->prev_x = w->x; w->prev_y = w->y;
    w->prev_w = w->w; w->prev_h = w->h;
    int ox = w->x, oy = w->y, ow = w->w, oh = w->h;
    int bx, by, bw, bh;
    if (wm_opt_animations() && taskbar_button_rect(w, &bx, &by, &bw, &bh) &&
        bw >= 40 && bh >= 20) {
        /* окно улетает в СВОЮ кнопку на панели; пока летит — остаётся
         * видимым (minimized=0), чтобы композитор его рисовал */
        w->minimized = 0;
        wm_anim_start(w, ox, oy, ow, oh, bx, by, bw, bh);
        w->anim_to_min = 1;
        wm_touch_taskbar();
    } else {
        w->minimized = 1;
        /* ПЕРФ: вместо полного кадра — прежний прямоугольник (под ним
         * открылся стол/окна), таскбар и заголовок нового верхнего окна */
        wm_touch_rect(ox, oy, ow, oh);
        wm_touch_taskbar();
        {
            int nt = top_visible_window();
            if (nt >= 0) wm_touch_title(wins[nt]);
        }
    }
}

/* Восстановить окно (С АНИМАЦИЕЙ из кнопки на панели — запрос):
 * стартуем из прямоугольника кнопки таскбара в прежнюю геометрию. */
void win_restore(window_t *w)
{
    if (!w || !w->minimized) return;
    if (w->anim_active) {
        /* обрыв незавершённой анимации (сворачивания/разворота) */
        w->anim_active = 0;
        w->anim_hold = 0;
        w->anim_to_min = 0;
    }
    int ot = top_visible_window();
    window_t *old_focus = (ot >= 0) ? wins[ot] : NULL;
    w->x = w->prev_x; w->y = w->prev_y;
    w->w = w->prev_w; w->h = w->prev_h;
    w->minimized = 0;
    /* пока окно было свёрнуто, canvas не обновлялся — перерисуем */
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
    }
    if (wm_opt_animations()) {
        int bx, by, bw, bh;
        if (taskbar_button_rect(w, &bx, &by, &bw, &bh) && bw >= 40 && bh >= 20)
            wm_anim_start(w, bx, by, bw, bh, w->x, w->y, w->w, w->h);
    }
    /* ПЕРФ: окно + таскбар + заголовок прежнего фокусного */
    wm_touch_window(w);
    wm_touch_taskbar();
    if (old_focus && old_focus != w) wm_touch_title(old_focus);
}

/* Отменить активную анимацию окна (без изменения геометрии). */
static void wm_anim_cancel(window_t *w)
{
    if (!w || !w->anim_active) return;
    w->anim_active = 0;
    w->anim_hold = 0;
    w->anim_to_min = 0;
    w->resize_defer = 0;
}

/* Развернуть окно на весь экран: заголовок и таскбар СОХРАНЯЮТСЯ,
 * содержимое занимает всю область над таскбаром. Прежняя геометрия
 * запоминается в prev_*. Canvas пересоздаётся в wm_frame (контроль
 * размера), окно получает need_draw. С анимацией (Настройки → Система)
 * геометрия интерполируется, canvas подгоняется в конце. */
void win_maximize(window_t *w)
{
    if (!w || w->maximized || w->fixed_size) return;
    wm_anim_cancel(w);   /* обрыв сворачивания/разворота — новый сценарий */
    int ox = w->x, oy = w->y, ow = w->w, oh = w->h;
    w->prev_x = w->x; w->prev_y = w->y;
    w->prev_w = w->w; w->prev_h = w->h;
    w->maximized = 1;
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
    }
    if (wm_opt_animations() && !w->minimized) {
        wm_anim_start(w, ox, oy, ow, oh,
                      0, 0, (int)fb_width(), (int)fb_height() - TBAR_H);
    } else {
        w->x = 0;
        w->y = 0;
        w->w = (int)fb_width();
        w->h = (int)fb_height() - TBAR_H;
        wm_touch_union_rect(ox, oy, ow, oh, w->x, w->y, w->w, w->h);
        wm_touch_taskbar();
    }
}

/* Вернуть окну прежний размер/позицию. */
void win_unmaximize(window_t *w)
{
    if (!w || !w->maximized) return;
    wm_anim_cancel(w);
    int ox = w->x, oy = w->y, ow = w->w, oh = w->h;
    w->maximized = 0;
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
    }
    if (wm_opt_animations() && !w->minimized) {
        wm_anim_start(w, ox, oy, ow, oh,
                      w->prev_x, w->prev_y, w->prev_w, w->prev_h);
    } else {
        w->x = w->prev_x; w->y = w->prev_y;
        w->w = w->prev_w; w->h = w->prev_h;
        wm_touch_union_rect(ox, oy, ow, oh, w->x, w->y, w->w, w->h);
        wm_touch_taskbar();
    }
}

void win_toggle_maximize(window_t *w)
{
    if (!w) return;
    if (w->maximized) win_unmaximize(w);
    else win_maximize(w);
}

int win_is_maximized(window_t *w)
{
    return w ? w->maximized : 0;
}

int win_is_minimized(window_t *w)
{
    return w ? w->minimized : 0;
}

void wm_init(void)
{
    nwin = 0;
    nzombie = 0;
    kill_mail_n = 0;
    drag_win = NULL;
    resize_win = NULL;
    pending_close = NULL;
    lmb_win = NULL;              /* неявный захват мыши (сессия 20) */
    menu_open = 0;
    menu_hover = -1;
    menu_kbd_sel = -1;
    menu_anim = 0;
    menu_closing = 0;
    cursor_visible = mouse_present();
    cur_x = (int)fb_width() / 2;
    cur_y = (int)fb_height() / 2;
    ms_x = cur_x;
    ms_y = cur_y;
    cursor_build_spans();        /* ПЕРФ: спаны курсора один раз */
    /* [2D-ускорение]: при активном аппаратном ускорителе курсор рисует
     * плоскость видеокарты (voodoo3/gma3600_2d), программный не нужен */
    if (gfx2d_cursor_ready()) {
        gfx2d_cursor_move(cur_x, cur_y);
        gfx2d_cursor_show(1);
    }
    /* Настройки интерфейса (перетаскивание/анимации) — из WM.CFG */
    wm_opt_load();
    /* СЕССИЯ 15: тема оформления (цвет окон/текста/заголовков) —
     * из THEME.CFG на RAM disk (сидируется из ISO при загрузке).
     * Должно идти ДО создания любых окон. */
    g_theme.win_bg = THEME_DEFAULT_BG;
    g_theme.text = THEME_DEFAULT_TEXT;
    g_theme.title = THEME_DEFAULT_TITLE;
    if (wm_theme_load())
        serial_puts("[wm] тема загружена из THEME.CFG\n");
    else
        theme_recompute();
}

int wm_blink(void) { return blink_state; }

int wm_window_count(void) { return nwin; }

int wm_window_visible_count(void)
{
    int n = 0;
    for (int i = 0; i < nwin; i++)
        if (!wins[i]->minimized) n++;
    return n;
}

const char *wm_window_title(int i)
{
    return (i >= 0 && i < nwin) ? wins[i]->title : "";
}

int wm_window_minimized(int i)
{
    return (i >= 0 && i < nwin) ? wins[i]->minimized : 0;
}

int wm_window_focused(int i)
{
    if (i < 0 || i >= nwin) return 0;
    int top = top_visible_window();
    return (i == top);
}

window_t *wm_window_at(int i)
{
    return (i >= 0 && i < nwin) ? wins[i] : NULL;
}
