/* c4.c — C in four functions (Robert Swierczek, https://github.com/rswier/c4).
 *
 * ПОРТ ДЛЯ N2600-OS (freestanding):
 *   - убран #define int long long (мы 32-битные, int и так вмещает указатель);
 *   - убраны stdio/stdlib/unistd/fcntl, используются наши string.h/mem.h;
 *   - printf() переадресован во внешний буфер (c4_out/c4_out_pos);
 *   - exit() делает __builtin_longjmp обратно в c4_run();
 *   - open/read/close не нужны: исходник передаётся в память;
 *   - точка входа: c4_run(src, out, out_max) вместо main(argc, argv).
 *
 * Поддержано подмножество C: char/short/int/unsigned/float/double/указатели,
 * struct/union (присваивание и передача по значению), if/while/for/do/
 * switch-case-default/break/continue, оператор «запятая», составные
 * присваивания (+= -= *= /= %= &= |= ^= <<= >>=), escape-последовательности
 * C89 (\n \t \r \xHH \NNN ...), прототипы функций (вызовы до определения),
 * variadic-функции (va_start/va_arg/va_end, cdecl-разворот аргументов),
 * конверсия аргументов по прототипу (C89 §6.3.2.2, int <-> double),
 * выражения, функции; VM-сисколы OPEN/READ/CLOS/PRTF/MALC/FREE/MSET/MCMP/EXIT.
 * Для PRTF: %d %u %s %c %x %f/%e/%g + флаги ширины/точности ('-', '0');
 * возвращаемое значение printf — число реально напечатанных символов.
 *
 * Соглашения вызова (см. «Val-назначение» в разборе параметров):
 *   НЕ-variadic: аргументы пушатся СЛЕВА НАПРАВО — первый параметр
 *     ГЛУБЖЕ всех (bp+3 при одном int-аргументе и более для следующих);
 *     LEA-операнд параметра q: Val_q = pcap - 1 - (ячейки параметров ПОСЛЕ q).
 *   VARIADIC (cdecl): блоки аргументов разворачиваются ЗАДОМ НАПЕРЁД
 *     (c4_fn_is_va + c4_va_rev_buf) — именованные параметры получают
 *     ФИКСИРОВАННЫЕ слоты bp+2.., vararg'и лежат ВЫШЕ; va_arg шагает по
 *     ячейкам вверх от &last_named. Поэтому Val_q у va = pcap - 1 - (ячейки
 *     ПЕРЕД q) — ДРУГАЯ формула, не «после». Вызов va-функции ДО её
 *     прототипа невозможен развернуть — диагностируется предупреждением
 *     (C89: без прототипа это UB).
 *
 * РАСШИРЕНИЯ СОВМЕСТИМОСТИ (сессия «c4 improvements»):
 *   1. const/static/volatile/extern — разбираются и игнорируются
 *      (квалификаторы перед типом в глобальных/локальных объявлениях);
 *   2. goto Label / Label: — переходы внутри одной функции;
 *   3. sizeof(выражение) — например sizeof(*p), sizeof(p[0]), sizeof(x+y);
 *   4. конкатенация смежных строковых литералов "abc" "def" + корректный
 *      NUL-терминатор (раньше строки длиной, кратной 4, склеивались
 *      с соседними без терминатора!);
 *   5. базовый #include "file" / <file> — текстовый препроцессор до
 *      компиляции (хост-хук c4_include_hook); #define NAME VALUE уже был.
 *
 * Script GUI API (мост в mquickjs_api.c, экс-CMScript): win_open/win_close/win_alive/
 * win_clear/win_rect/win_text/win_update/btn_add/btn_clicked/btn_set_label —
 * сисколы WOPEN..BSETLB (добавлены В КОНЕЦ списка опкодов; в native-пути
 * вызываются через kapi_t, в VM-пути — через таблицу c4_gui_api).
 */

#include "c4.h"
#include "sync.h"
#include "types.h"
#include "string.h"
#include "mem.h"
/* N2600-OS: заголовки для SDL2-подобных сисколов */
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"
#include "ramfs.h"
#include "c4gfx.h"   /* окно графики для kfill/ktext VM-пути */

/* hosted-хост (тесты на Linux): size_t 64-битный; ядро — u32 (string.h) */
#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#define C4_SZT mq_size_t
#else
#define C4_SZT u32
#endif

char *p, *lp, // текущая позиция в исходнике
     *data;   // указатель области data/bss

int *e, *le,  // текущая позиция в эмитируемом коде
    *id,      // разбираемый идентификатор
    *sym,     // таблица символов (простой список идентификаторов)
    tk,       // текущий токен
    ival,     // значение текущего токена
    ty,       // тип текущего выражения
    loc,      // смещение локальной переменной
    line,     // номер строки
    src,      // флаг печати исходника (не используется в нашей сборке)
    debug;    // флаг печати выполняемых инструкций
/* последний числовой литерал — вещественный?
 * 0 = int, 1 = float (суффикс f/F), 2 = double (по умолчанию для 1.5) */
double dval;
int    c4_num_dbl = 0;

// токены и классы (операторы — последние, в порядке приоритета)
enum {
  Num = 128, Fun, Sys, Glo, Loc, Id,
  Char, Else, Enum, If, Int, Return, Sizeof, While,
  For, Do, Break, Continue, Switch, Case, Default, Unsigned,
  /* Квалификаторы (игнорируются) и goto — регистрируются как ключевые
   * слова; диапазон Char..Auto обязан быть непрерывным (см. цикл
   * регистрации). Держать ВЫШЕ Comma/Assign (это НЕ операторы). */
  Goto, Const, Static, Volatile, Extern,
  /* C89: typedef и «мягкие» типы: signed (игнорируется), long/short
   * (алиас int), register/auto (игнорируются). void — настоящий тип
   * (1.4), struct/union — ключевые слова (3.1). Диапазон Char..Union
   * обязан быть непрерывным (цикл регистрации) и идти ДО Comma. */
  Typedef, Signed, Long, Short, Void, Register, Auto, Float, Double,
  Struct, Union,
  /* Псевдо-токен ИМЕНИ typedef (u32, string, ...); ключевое слово
   * typedef — отдельный токен Typedef. Не регистрируется лексером. */
  TdefName,
  /* Comma — НИЖЕ Assign: в c4 чем больше значение enum, тем выше
   * приоритет; у оператора «запятая» приоритет минимальный. */
  Comma,
  /* Составные присваивания — тот же уровень приоритета, что Assign */
  Assign, AddAssign, SubAssign, MulAssign, DivAssign, ModAssign,
  AndAssign, OrAssign, XorAssign, ShlAssign, ShrAssign,
  Cond, Lor, Lan, Or, Xor, And, Eq, Ne, Lt, Gt, Le, Ge, Shl, Shr, Add, Sub, Mul, Div, Mod, Inc, Dec, Brak,
  /* Диапазон метки case (расширение GCC): case 'a' ... 'z': — тройная
   * точка отдельным токеном, чтобы парсер case отличал её от одиночной
   * точки. */
  DotDotDot,
  /* C89: доступ к полям структур. Dot/Arrow — САМЫЕ ВЫСОКИЕ приоритеты
   * (в postfix-цикле expr): значения enum идут после всех операторов. */
  Dot, Arrow
};

// опкоды
enum { LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,
       OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,
       OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,
       /* N2600-OS: SDL2-подобные сисколы для c4-программ.
        * Имена: kinit, kquit, kdelay, kfill, ktext, kflip, krgb, kevent,
        *        kclear, kwidth, kheight, kmtime
        * Позволяют писать простые интерактивные программы. */
       KINIT,KQUIT,KDELAY,KFILL,KTEXT,KFLIP,KRGB,KEVENT,KCLEAR,KW,KH,KMTIME,
       /* Строковые операции */
       STRLEN,STRCPY,STRCMP,
       /* Логический (беззнаковый) сдвиг вправо: unsigned >> n.
       * ДОБАВЛЯТЬ ТОЛЬКО В КОНЕЦ: нумерация опкодов должна совпадать
       * с c4_x86.c и влияет на формат сохранённых бинарей. */
       USHR,
       /* CMScript GUI API (окна/кнопки) — WOPEN..BSETLB, ТОЛЬКО В КОНЦЕ.
       * Имена: win_open win_close win_alive win_clear win_rect win_text
       *        win_update btn_add btn_clicked btn_set_label
       * В native-коде эмитятся как call [edi+KAPI_WIN_*] (c4_x86.c),
       * в VM — через таблицу указателей c4_gui_api (ниже). */
       WOPEN,WCLOSE,WALIVE,WCLEAR,WRECT,WTEXT,WUPD,BADD,BCLICK,BSETLB,
       /* C89-расширения — ТОЛЬКО В КОНЕЦ, порядок = c4_x86.c:
       *  LS/ULS/SSH — short: загрузка знаковая/беззнаковая, запись;
       *  UDIV/UMOD/ULT/UGT/ULE/UGE — unsigned-семантика (1.3);
       *  JSRI — косвенный вызов call *a (указатели на функции, 3.3). */
       LS,ULS,SSH,UDIV,UMOD,ULT,UGT,ULE,UGE,JSRI,
       /* float/double (C89) — ТОЛЬКО В КОНЦЕ, порядок = c4_x86.c.
        * Модель: ВСЕ float-выражения считаются в double; double на стеке
        * VM = 2 ячейки (lo по МЕНЬШЕМУ адресу: push hi, затем lo);
        * float-переменные — 4 байта в памяти, double — 8.
        *  FLDI lo hi — пуш литерала; FLD0/FLD1 — пуш 0.0/1.0;
        *  FDUP/FDROP — дубликат/сброс double на вершине;
        *  FLD/FLDF — загрузка double/float по адресу в a (как LI/LC);
        *  FST/FSTF — запись double/float: значение снимается со стека
        *            (2 ячейки) + адрес (1), результат ОСТАЁТСЯ на стеке;
        *  FADD/FSUB/FMUL/FDIV — оба операнда на стеке (правый сверху);
        *  FNEG, FEQ/FNE/FLT/FLE/FGT/FGE (результат — int в a);
        *  ITOF/UTOF — int/unsigned (снимает 1 ячейку) → double;
        *  ITOF2 — [int][double] → [double][double] (левый int под real);
        *  FTOI — double → int в a (усечение, БЕЗ пуша);
        *  FRET/FRD — возврат double из функции (через статический слот);
        *  SCP n — копия struct по значению (n байт, C89);
        *  FABSC/SQRTC — fabs/sqrt in-place (результат — 2 ячейки на стеке;
        *            FRD после них не нужен);
        *  UTOF2 — как ITOF2, но левый int беззнаковый;
        *  FSTK/FSTKF — постфиксные d++/f++: стек [addr][old][new],
        *            запись new по addr (глубина 3), результат — old. */
       FLDI,FLD0,FLD1,FDUP,FDROP,FLD,FLDF,FST,FSTF,
       FADD,FSUB,FMUL,FDIV,FNEG,
       FEQ,FNE,FLT,FLE,FGT,FGE,
       ITOF,UTOF,FTOI,ITOF2,FRET,FRD,SCP,FABSC,SQRTC,UTOF2,FSTK,FSTKF };

/* Таблица GUI-функций для VM-пути (native-путь вызывает через kapi_t).
 * Тип c4_gui_api_t объявлен в c4.h. Хост (IDE/тесты) регистрирует
 * реализации; NULL = безопасные заглушки: win_open -> -1, win_alive -> 0
 * (окно «закрыто»), btn_clicked -> -1. */
c4_gui_api_t *c4_gui_api = 0;

/* Хост-хук для #include (см. c4_preprocess ниже). Регистрируется хостом
 * ДО компиляции; NULL = директивы #include пропускаются (старое поведение).
 *   name     — имя файла без кавычек/уголков;
 *   kind     — 0 для #include "name", 1 для #include <name>;
 *   includer — путь файла, из которого включают (для относительных путей);
 *   buf/max  — куда прочитать содержимое.
 * Возвращает длину содержимого (0 = файл не найден). */
u32 (*c4_include_hook)(const char *name, int kind, const char *includer,
                       char *buf, u32 max) = 0;

/* ---------- Типы (short/void/struct/funcptr) ----------
 * Базовые типы: CHAR=0, SHORT=1, INT=2, VOID=3. Каждая косвенность
 * добавляет PTR (4): char*=4, short*=5, int*=6, void*=7, char**=8...
 * Флаги: ARR (0x80) массив, UNSIGNED (0x100), ARR2 (0x200) второе
 * измерение (int m[A][B]), FPTR (0x400) указатель на функцию,
 * STRUCT (0x800) + индекс тега в битах 12+ (struct-тип).
 * Размер элемента указателя — через c4_esz (short* шагает по 2). */
enum { CHAR = 0, SHORT, INT, VOID };
#define PTR      4     /* первый уровень косвенности = char* */
/* float/double — ФЛАГИ поверх INT (не уровни косвенности,
 * чтобы не пересекаться с PTR): float = INT|FLT_F, double = INT|DBL_F,
 * float* = INT|FLT_F|PTR и т.д. Значения выражений — всегда double
 * (2 ячейки на стеке VM), float отличает только память/тип переменной. */
#define FLT_F    0x2000 /* float */
#define DBL_F    0x4000 /* double */
#define C4_REAL  (FLT_F | DBL_F)
/* маска «база + уровни PTR + STRUCT» — без флагов 0x2000/0x4000 */
#define C4_PTMASK 0x1FFF
#define ARR      0x80  /* массив */
#define UNSIGNED 0x100 /* беззнаковость */
#define ARR2     0x200 /* второе измерение массива */
#define FPTR     0x400 /* указатель на функцию */
#define ARR3     0x1000 /* третье измерение массива */
#define STRUCT   0x800 /* struct/union; тег = (t >> 16) & 0xFF */
#define C4_TAG(t)    (((t) >> 16) & 0xFF)
#define C4_MKSVAL(tg) (STRUCT | ((tg) << 16))
/* снять все флаги-модификаторы (оставить базу + уровень косвенности;
 * FLT_F/DBL_F — часть БАЗЫ, не снимаются — их маскирует C4_PTMASK) */
#define TY_CLEAN(t)  ((t) & ~(ARR | ARR2 | ARR3 | UNSIGNED | FPTR))
/* struct-ЗНАЧЕНИЕ (не указатель): STRUCT установлен и нет битов PTR.
 * 0xFFC = биты 2..11 (PTR-уровни | STRUCT): у значения там только STRUCT. */
#define IS_STVAL(t)  (((TY_CLEAN(t)) & 0xFFC) == STRUCT)
/* указатель вообще (вкл. struct*, вкл. funcptr) */
#define IS_PTR_T(t)  (IS_STVAL(t) ? 0 : (TY_CLEAN(t) & STRUCT) \
                                      ? (TY_CLEAN(t) & 0xFFC) >= PTR \
                                      : (TY_CLEAN(t) & C4_PTMASK) >= PTR)
#define IS_CPTR_T(t) (TY_CLEAN(t) == PTR)          /* char* (шаг 1 байт) */
#define IS_IPTR_T(t) (!IS_STVAL(t) && (TY_CLEAN(t) & STRUCT) \
                       ? 0 : (TY_CLEAN(t) & C4_PTMASK) > PTR)    /* шаг 4 */
/* real-ЗНАЧЕНИЕ (не указатель): float/double — выражения-вещественные */
#define IS_REAL_TY(t) ((t) & C4_REAL)
/* real-ЗНАЧЕНИЕ (double/float, но НЕ указатель на них): указатели на
 * float/double — обычные указатели (1 ячейка на стеке); сырая проверка
 * & C4_REAL ловит флаг у указателя и ломает стек (ITOF/FNEG/FRD/не-пуш
 * аргумента). ВСЕ семантические проверки выражений — через IS_REAL_VAL. */
#define IS_REAL_VAL(t) (((t) & C4_REAL) && !IS_PTR_T(t))

// смещения в записи идентификатора (Idsz = 14; +ArrSz/ArrD/ArrD2/SMark;
// +IsExt — «зарегистрирован extern-декларацией без инициализатора»)
enum { Tk, Hash, Name, Class, Type, Val, HClass, HType, HVal,
       ArrSz, ArrD, ArrD2, SMark, IsExt, Idsz };

/* ---------- прямые определения (используются до конца файла) ---------- */
static int c4_esz(int t);           /* размер базового типа (элемента) */
static int c4_sizeof_ty(int t);     /* sizeof типа без учёта in-flight ARR */
static int c4_ptr_step(int t);      /* шаг указателя t в байтах */
static int c4_tag_find(int *idrec);
static int c4_n_tags;

/* размер/загрузка/запись по типу ОПЕРАНДА: UNSIGNED/ARR-флаги
 * снимаются — SHORT|UNSIGNED тоже загружается ULS и пишется SSH.
 * float/double: СНАЧАЛА флаги, но ТОЛЬКО для не-указателей
 * (float* загружается как обычный указатель LI). */
#define C4_LOAD_OP(t)  (((t) & DBL_F && !IS_PTR_T(t)) ? FLD : \
                        ((t) & FLT_F && !IS_PTR_T(t)) ? FLDF : \
                        TY_CLEAN(t) == CHAR ? LC \
                        : TY_CLEAN(t) == SHORT ? (((t) & UNSIGNED) ? ULS : LS) : LI)
#define C4_STORE_OP(t) (((t) & DBL_F && !IS_PTR_T(t)) ? FST : \
                        ((t) & FLT_F && !IS_PTR_T(t)) ? FSTF : \
                        TY_CLEAN(t) == CHAR ? SC : TY_CLEAN(t) == SHORT ? SSH : SI)

/* Метки IMM-операндов — АДРЕСА В TEXT (имя функции как значение, 3.3):
 * VM исполняет их как абсолютные указатели, c4_x86 патчит через
 * call $+5/pop/add (позиционно-независимо). */
#define C4_MAX_IMM_TEXT 2048
u32 c4_imm_text_cells[C4_MAX_IMM_TEXT];
int c4_n_imm_text_cells = 0;
static void c4_imm_text_mark(int *cell)
{
    if (c4_n_imm_text_cells < C4_MAX_IMM_TEXT)
        c4_imm_text_cells[c4_n_imm_text_cells++] = (u32)(cell - le);
}

/* ---------- выходной буфер и escape через __builtin_longjmp ---------- */

/* ---------- struct/union (3.1): таблица тегов и полей ----------
 * Тег: имя, hash, union-флаг, размер, число полей. Поля: имя (указатель
 * в исходник — живёт всю компиляцию), hash, тип, смещение, размер
 * массива-поля. Выравнивание полей — естественное (1/2/4). */
#define C4_MAX_TAGS   48
#define C4_MAX_FIELDS 512
#define C4_TAG_FIELDS 32
static char *c4_tag_namep[C4_MAX_TAGS];
static int   c4_tag_hash[C4_MAX_TAGS];
static int   c4_tag_union[C4_MAX_TAGS];
static int   c4_tag_size_[C4_MAX_TAGS];   /* c4_tag_size — функция ниже */
static int   c4_tag_nf[C4_MAX_TAGS];
static char *c4_tag_fnamep[C4_MAX_TAGS][C4_TAG_FIELDS];
static int   c4_tag_fhash[C4_MAX_TAGS][C4_TAG_FIELDS];
static int   c4_tag_ftype[C4_MAX_TAGS][C4_TAG_FIELDS];
static int   c4_tag_foff[C4_MAX_TAGS][C4_TAG_FIELDS];
static int   c4_tag_farr[C4_MAX_TAGS][C4_TAG_FIELDS];   /* элементов (0=скаляр) */
static int   c4_tag_fbase[C4_MAX_TAGS][C4_TAG_FIELDS];  /* база поля (без ARR) */
static int   c4_nf_total = 0;

static int c4_tag_find(int *idrec)
{
    int i;
    if (!idrec) return -1;
    for (i = 0; i < c4_n_tags; i++)
        if (c4_tag_hash[i] == idrec[Hash] &&
            !memcmp(c4_tag_namep[i], (char *)(unsigned long)idrec[Name],
                    (u32)strlen(c4_tag_namep[i]) + 1)) return i;
    return -1;
}

static int c4_tag_create(int *idrec, int is_union)
{
    int tg;
    if (c4_n_tags >= C4_MAX_TAGS || c4_nf_total >= C4_MAX_FIELDS) return -1;
    tg = c4_n_tags++;
    if (idrec) {
        c4_tag_namep[tg] = (char *)(unsigned long)idrec[Name];
        c4_tag_hash[tg] = idrec[Hash];
    } else { c4_tag_namep[tg] = ""; c4_tag_hash[tg] = 0; }
    c4_tag_union[tg] = is_union;
    c4_tag_size_[tg] = 0;
    c4_tag_nf[tg] = 0;
    return tg;
}

static int c4_field_find(int tg, int *idrec)
{
    int i;
    for (i = 0; i < c4_tag_nf[tg]; i++)
        if (c4_tag_fhash[tg][i] == idrec[Hash] &&
            !memcmp(c4_tag_fnamep[tg][i], (char *)(unsigned long)idrec[Name],
                    (u32)strlen(c4_tag_fnamep[tg][i]) + 1)) return i;
    return -1;
}

static int c4_tag_size(int tg)
{
    return (tg >= 0 && tg < c4_n_tags) ? c4_tag_size_[tg] : 4;
}

/* Размер базового типа (элемента): CHAR 1, SHORT 2, INT 4, VOID 1 (GNU),
 * float 4, double 8, struct — размер тега. Указатели — 4. */
static int c4_esz(int t)
{
    t = TY_CLEAN(t);
    if (t & STRUCT) return c4_tag_size(C4_TAG(t));
    if ((t & C4_PTMASK) >= PTR) return 4;   /* любой указатель (double** — тоже) */
    if (t & DBL_F) return 8;
    if (t & FLT_F) return 4;
    if (t == CHAR) return 1;
    if (t == SHORT) return 2;
    if (t == VOID) return 1;
    return 4;
}

/* sizeof типа (без учёта in-flight массивов — те считают через
 * c4_arr_elems в sizeof-ветке expr). */
static int c4_sizeof_ty(int t)
{
    t = TY_CLEAN(t);
    if ((t & STRUCT) && (t & 0xFFC) == STRUCT) return c4_esz(t);  /* struct-значение */
    if ((t & C4_PTMASK) >= PTR) return 4;   /* любой указатель */
    if (t & DBL_F) return 8;
    if (t & FLT_F) return 4;
    return c4_esz(t);
}

/* Шаг указателя t (для p+i, p++, p+=i). Для funcptr-переменной шаг
 * фактически не используется; для УКАЗАТЕЛЯ НА funcptr (массив
 * int (*tab[n])(...)) — 4, что и даёт esz(pointee). */
static int c4_ptr_step(int t)
{
    return c4_esz(TY_CLEAN(t) - PTR);
}

/* In-flight подмассив (int m[A][B] после m[i]): байт-шаг следующего
 * индекса и число элементов текущего уровня. Сбрасываются в Id-ветке. */
static int c4_row1 = 0;
static int c4_row2 = 0;
static int c4_arr_elems = 0;
/* Размер in-flight подмассива в БАЙТАХ (m[i]/c[i][j] при распаде в
 * указатель — 1.1: sizeof(m[i]) честный). Ставится в точках распада,
 * потребляется в sizeof-ветке expr. */
static int c4_subarr_bytes = 0;

/* ---------- float/double ----------
 * double на стеке VM — 2 ячейки: lo по МЕНЬШЕМУ адресу (пуш: hi, затем
 * lo) — тогда *(double*)sp читает значение напрямую. Функции-хелперы
 * работают с указателем на вершину стека; арифметика — нативный double
 * компилятора (x87), безопасный под общим FPU-локом (imgsvc.h). */
static double c4_dret = 0.0;     /* слот возврата double (FRET/FRD) */

static void c4_push_d(int **spp, double d)
{
    union { double d; int w[2]; } u;
    u.d = d;
    *--(*spp) = u.w[1];          /* hi — глубже */
    *--(*spp) = u.w[0];          /* lo — на вершине */
}

static double c4_pop_d(int **spp)
{
    union { double d; int w[2]; } u;
    u.w[0] = (*spp)[0];
    u.w[1] = (*spp)[1];
    *spp += 2;
    return u.d;
}

static double c4_peek_d(int *sp)
{
    union { double d; int w[2]; } u;
    u.w[0] = sp[0];
    u.w[1] = sp[1];
    return u.d;
}

/* эмит double-литерала (FLDI lo hi) */
static void c4_emit_dlit(double d)
{
    union { double d; int w[2]; } u;
    u.d = d;
    *++e = FLDI; *++e = u.w[0]; *++e = u.w[1];
}

/* sqrt для VM (freestanding: libm нет) — Ньютон, квадратичная сходимость */
static double c4_sqrt(double x)
{
    double r;
    int k;
    if (x <= 0.0) return 0.0;
    r = (x < 1.0) ? 1.0 : x;
    for (k = 0; k < 48; k++) r = 0.5 * (r + x / r);
    return r;
}

/* Условие в if/while/for/?/&&/||: double-выражение лежит на стеке —
 * превращаем в int (a) через сравнение с 0.0 (C89: d != 0). */
static void c4_fcond(void)
{
    if (IS_REAL_VAL(ty)) { *++e = FLD0; *++e = FNE; ty = INT; }
}

/* Преобразование значения выражения (глобальный ty) к типу-приёмнику
 * dst ПЕРЕД записью: int→double (PSH;ITOF/UTOF), double→int (FTOI).
 * float↔double не требуют кода — FSTF/FST сами конвертируют. */
static void c4_conv_store(int dst)
{
    if (IS_REAL_VAL(dst)) {
        if (!IS_REAL_VAL(ty)) {
            *++e = PSH;
            *++e = (ty & UNSIGNED) ? UTOF : ITOF;
            ty = dst;
        }
    } else if (IS_REAL_VAL(ty)) {
        *++e = FTOI;
        ty = INT;
    }
}

/* Смешанная бинарная операция (после разбора правого операнда):
 * левый int + правый real → ITOF2 ([int][d] → [d][d]);
 * левый real + правый int → правый в a → PSH;ITOF/UTOF. */
static void c4_mix_real(int lt)
{
    if (!IS_REAL_VAL(lt) && IS_REAL_VAL(ty)) {
        /* левый int/unsigned под real: UTOF2 для unsigned (старший бит —
         * вес 2^32, а не знак) */
        *++e = (lt & UNSIGNED) ? UTOF2 : ITOF2;
    } else if (IS_REAL_VAL(lt) && !IS_REAL_VAL(ty)) {
        *++e = PSH;
        *++e = (ty & UNSIGNED) ? UTOF : ITOF;
    }
}

/* ---------- таблица сигнатур (типы параметров, для конверсии аргументов) ----------
 * C89 (§6.3.2.2): аргументы преобразуются по прототипу. Однопроходный
 * парсер хранит типы параметров каждой объявленной функции (до 16) в
 * побочной таблице; точка вызова конвертирует int↔double по ним. */
#define C4_MAX_FN_ARGS 16
#define C4_MAX_FN_SIGS 96
static struct { int *fid; int nt; int va; int ty[C4_MAX_FN_ARGS]; } c4_fn_sigs[C4_MAX_FN_SIGS];
static int c4_n_fn_sigs = 0;

static void c4_sig_record(int *fid, int nt, const int *tys)
{
    int i;
    if (!fid || nt <= 0) return;
    for (i = 0; i < c4_n_fn_sigs; i++)
        if (c4_fn_sigs[i].fid == fid) break;
    if (i == c4_n_fn_sigs) {
        if (c4_n_fn_sigs >= C4_MAX_FN_SIGS) return;
        c4_n_fn_sigs++;
    }
    c4_fn_sigs[i].fid = fid;
    c4_fn_sigs[i].nt = (nt > C4_MAX_FN_ARGS) ? C4_MAX_FN_ARGS : nt;
    c4_fn_sigs[i].va = 0;
    for (int k = 0; k < c4_fn_sigs[i].nt; k++) c4_fn_sigs[i].ty[k] = tys[k];
}

/* пометить функцию variadic (после c4_sig_record): если функцию УЖЕ
 * вызывали ДО прототипа (fixup с va_unaware), её variadic-раскладка на
 * тех вызовах не разворачивалась — проверка/предупреждение в
 * c4_va_check_unaware (объявлена ниже, рядом с реализацией: ей нужны
 * printf и c4_jsr_fixups) */
static void c4_sig_mark_va(int *fid)
{
    for (int i = 0; i < c4_n_fn_sigs; i++)
        if (c4_fn_sigs[i].fid == fid) { c4_fn_sigs[i].va = 1; break; }
}
static void c4_va_check_unaware(int *fid);   /* реализация после printf */

/* variadic ли функция (для cdecl-разворота аргументов в точке вызова) */
static int c4_fn_is_va(int *fid)
{
    for (int i = 0; i < c4_n_fn_sigs; i++)
        if (c4_fn_sigs[i].fid == fid) return c4_fn_sigs[i].va;
    return 0;
}

/* буфер перестановки блоков аргументов variadic-вызова (cdecl) */
#define C4_VA_REV_CELLS 2048
static int c4_va_rev_buf[C4_VA_REV_CELLS];

/* типы параметров функции: возвращает ЧИСЛО ИЗВЕСТНЫХ параметров
 * (0 = записи нет — аргументы передаются как есть, K&R-стиль) */
static int c4_fn_ptypes(int *fid, int *out)
{
    for (int i = 0; i < c4_n_fn_sigs; i++) {
        if (c4_fn_sigs[i].fid == fid) {
            for (int k = 0; k < C4_MAX_FN_ARGS; k++)
                out[k] = (k < c4_fn_sigs[i].nt) ? c4_fn_sigs[i].ty[k] : INT;
            return c4_fn_sigs[i].nt;
        }
    }
    return 0;
}

/* тип текущей функции (для return: конверсия/FRET) */
static int c4_fn_ret = INT;


/* пулы освобождаются на ВСЕХ путях выхода: EXIT, longjmp (exit()), все
 * return -1 парсера и лимит циклов (иначе протечка 4 x 256К = 1 МиБ
 * на каждый запуск) */
static int  *c4_pool_sym   = NULL;
static int  *c4_pool_text  = NULL;
static char *c4_pool_data  = NULL;
static int  *c4_pool_stack = NULL;

static void c4_free_pools(void)
{
    if (c4_pool_sym)   { free(c4_pool_sym);   c4_pool_sym = NULL; }
    if (c4_pool_text)  { free(c4_pool_text);  c4_pool_text = NULL; }
    if (c4_pool_data)  { free(c4_pool_data);  c4_pool_data = NULL; }
    if (c4_pool_stack) { free(c4_pool_stack); c4_pool_stack = NULL; }
}

static char *c4_out = 0;
static u32   c4_out_pos = 0;
static u32   c4_out_max = 0;
static void *c4_jmp[12];
static int   c4_exit_code = 0;

/* Когда не NULL — c4_run сохранит байт-код в RAMFS под этим именем
 * и сразу вернётся (не запуская VM). Формат файла:
 *   char magic[4] = "C4B1"
 *   u32  entry_offset_cells   (смещение main от начала text в int-ячейках)
 *   u32  text_len_cells       (длина text в int-ячейках)
 *   u32  data_len_bytes       (длина data в байтах)
 *   u8   text[text_len_cells * 4]
 *   u8   data[data_len_bytes]
 */
static const char *c4_save_bin_name = NULL;
/* Сохранённое начало data pool (для расчёта data_len при dump в файл) */
static char *data_pool_start = NULL;

/* Compile-only mode: c4_run после парсинга сохраняет байт-код в
 * caller-предоставленные буферы и возвращает без запуска VM. */
static int c4_compile_only = 0;
static u8 *c4_compile_bc_buf = NULL;
static u32  c4_compile_bc_max = 0;
static u32  c4_compile_bc_len_cells = 0;
static u8 *c4_compile_data_buf = NULL;
static u32  c4_compile_data_max = 0;
static u32  c4_compile_data_len = 0;
static u32  c4_compile_entry_cells = 0;
static int *c4_idmain_val_saved = NULL;

/* Метки IMM-операндов, ссылающихся на СЕГМЕНТ ДАННЫХ (строки и глобалы).
 * c4_x86 использует их, чтобы отличить адрес данных от обычной числовой
 * константы и сгенерировать релокацию (сегмент данных у каждого
 * скомпилированного бинарника — СВОЙ, выделяется loader'ом).
 * Индекс ячейки — в int-ячейках от начала пула text (le). */
#define C4_MAX_IMM_MARKS 8192
u32 c4_imm_data_cells[C4_MAX_IMM_MARKS];
int c4_n_imm_data_cells = 0;
/* Адрес data pool на момент компиляции (нужен c4_x86 для пересчёта
 * абсолютных адресов в смещения сегмента данных). */
u32 c4_compile_data_base = 0;
/* База текст-пула (le) на момент компиляции: операнды переходов в
 * байт-коде — абсолютные указатели le+cell; c4_x86 пересчитывает их
 * в индексы ячеек для карты {cell → x86 offset}. */
u32 c4_compile_text_base = 0;

/* --- Прототипы: вызовы функций до их определения ---
 * JSR с операндом 0 записывается сюда; после разбора всего файла
 * операнд патчится на id[Val] (либо ошибка «function not defined»). */
#define C4_MAX_JSR_FIXUPS 256
/* va_unaware — вызов сделан ДО того, как функция стала известна как
 * variadic (без прототипа/определения с «...»): вызов эмитился БЕЗ
 * cdecl-разворота аргументов — если функция окажется variadic, стек у
 * callee разъедется (C89: UB без прототипа; предупреждаем) */
static struct { int *cell; int *fid; int va_unaware; } c4_jsr_fixups[C4_MAX_JSR_FIXUPS];
static int c4_n_jsr_fixups = 0;

/* --- Текущая функция (для switch: скрытые слоты локалов) ---
 * i / loc / указатель на ENT — локали c4_run_impl, из stmt() они не
 * видны; синхронизируем в эти глобалы перед разбором тела функции. */
static int *c4_fn_ent = 0;   /* ячейка ENT текущей функции ([1] = операнд) */
static int  c4_fn_i = 0;     /* счётчик слотов локалов (синхронизирован с i) */
static int  c4_fn_loc = 0;   /* loc текущей функции */

static void c4_putc(char c)
{
    if (c4_out_pos + 1 < c4_out_max) c4_out[c4_out_pos++] = c;
}

/* Перенаправить вывод c4 (printf нативных программ и VM) во внешний
 * буфер БЕЗ запуска c4_run. Нужно loader'у: он захватывает вывод
 * нативного .bin (запуск через `run` / файловый менеджер) и показывает
 * его в окне. c4_capture_end() возвращает прежнее перенаправление. */
void c4_capture_begin(char *buf, u32 max)
{
    c4_out = buf;
    c4_out_pos = 0;
    c4_out_max = max;
    if (buf && max) buf[0] = 0;
}

u32 c4_capture_len(void)
{
    return c4_out_pos;
}

void c4_capture_end(void)
{
    if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0;
    c4_out = 0;
    c4_out_pos = 0;
    c4_out_max = 0;
}

static void c4_puts(const char *s)
{
    while (*s) c4_putc(*s++);
}

/* единое ядро чисел/флагов printf: обе printf ходят через общие хелперы
 * с ТОЧНЫМ возвратом длины и общим разбором флагов */

/* |u| в базе base (10/16) в прямом порядке; возвращает длину.
 * Значения всегда 32-битные (ячейки VM): 64-битное деление тянуло бы
 * __udivmoddi4 (int64_runtime) */
static int c4_utoa(unsigned u, int base, char *out)
{
    char rv[12]; int i = 0, n = 0;
    if (u == 0) rv[i++] = '0';
    while (u) {
        int d = (int)(u % (unsigned)base);
        rv[i++] = (char)(d < 10 ? '0' + d : 'a' - 10 + d);
        u /= (unsigned)base;
    }
    while (i > 0) out[n++] = rv[--i];
    return n;
}

/* готовая строка по флагам ширины (C89 §6.9.6.2):
 * left  — '-' выравнивание влево, добивка пробелами СПРАВА;
 * wzero — '0' добивка нулями (ПОСЛЕ знака, правое выравнивание);
 * wflag — общая ширина, знак считается. Возвращает число символов.
 * Знак учитывается не только '-', но и '+'/' ' (%05d от %+d = «+0042») */
static int c4_put_pad(const char *s, int sl, int wflag, int wzero, int left)
{
    int n = 0, pad = wflag - sl;
    if (left) {
        while (sl-- > 0) { c4_putc(*s++); n++; }
        while (pad-- > 0) { c4_putc(' '); n++; }
        return n;
    }
    if (wzero && sl > 0 &&
        (s[0] == '-' || s[0] == '+' || s[0] == ' ')) {
        c4_putc(*s); n++; s++; sl--;
    }
    while (pad-- > 0) { c4_putc(wzero ? '0' : ' '); n++; }
    while (sl-- > 0) { c4_putc(*s++); n++; }
    return n;
}

/* целое по флагам: sign=1 → знаковое (база 10), иначе |v|. Одна функция
 * на месте трёх (putint/putudec/puthex), с ТОЧНЫМ возвратом длины.
 * plus/space — флаги '+' и ' ' (C89 §6.9.6.2): знак положительного
 * числа ПЕЧАТАЕТСЯ; применимы только к знаковым преобразованиям
 * (у %f/%e/%g знак добавляет c4_printf_va — см. её %f-ветку) */
static int c4_put_num(long v, int base, int sign,
                      int wflag, int wzero, int left, int plus, int space)
{
    char b[26]; int n = 0;
    unsigned u;
    if (sign && v < 0) { u = (unsigned)(-v); b[n++] = '-'; }
    else {
        u = (unsigned)v;
        if (sign && plus) b[n++] = '+';
        else if (sign && space) b[n++] = ' ';
    }
    n += c4_utoa(u, base, b + n);
    return c4_put_pad(b, n, wflag, wzero, left);
}

/* разбор флагов/ширины/точности: "%-08.3e" → left=1, wflag=8, wzero=1,
 * prec=3. '+' и ' ' разбираются и ПРИМЕНЯЮТСЯ; если даны оба —
 * '+' сильнее (C89 §6.9.6.2). fmtp — за '%' */
static void c4_fmt_flags(const char **fmtp, int *wflag, int *wzero,
                         int *left, int *prec, int *plus, int *space)
{
    const char *f = *fmtp; int w = 0, z = 0, l = 0, pr = -1, pl = 0, sp = 0;
    for (;;) {
        if (*f == '-') { l = 1; f++; }
        else if (*f == '0') { z = 1; f++; }
        else if (*f == '+') { pl = 1; f++; }
        else if (*f == ' ') { sp = 1; f++; }
        else break;
    }
    while (*f >= '0' && *f <= '9') { w = w * 10 + (*f - '0'); f++; }
    if (*f == '.') {
        f++; pr = 0;
        while (*f >= '0' && *f <= '9') { pr = pr * 10 + (*f - '0'); f++; }
    }
    *wflag = w; *wzero = z; *left = l; *prec = pr;
    *plus = pl; *space = sp; *fmtp = f;
}


/* VM-printf — тонкая обёртка над c4_printf_va (единое форматирование
 * VM/native — иначе два независимых цикла расходились бы).
 * Раскладки: args_reversed[0] = ПОСЛЕДНИЙ source-arg (в VM-стеке
 * t[-cells]), args_reversed[actual-1] = первый (t[-2]); nargs — ячейки
 * ВКЛЮЧАЯ fmt (actual = nargs-1). Пуш hi, затем lo — lo глубже */
int c4_printf_va(const char *fmt, int nargs, int *args_reversed);

static int c4_vm_printf(const char *fmt, int *t, int cells)
{
    return c4_printf_va(fmt, cells, t - cells);
}

/* printf для самого компилятора (диагностика): полностью перекладываем на snprintf. */
static void c4_printf(const char *fmt, ...)
{
    if (c4_out_pos + 1 >= c4_out_max) return;
    int n;
    /* вычисляем через наш snprintf в свой микро-буфер, потом копируем */
    char buf[160];
    /* snprintf из string.h принимает (out, n, fmt, ...) — cdecl, va_list не нужен */
    extern int snprintf(char *out, C4_SZT n, const char *fmt, ...);
    /* локальное объявление vsnprintf делает файл самодостаточным и не
     * зависящим от порядка include'ов */
    extern int vsnprintf(char *out, C4_SZT n, const char *fmt,
                         __builtin_va_list ap);
    /* разбор формата и аргументов полностью делает vsnprintf (хоста/ядра);
     * результат — в микро-буфер, затем копия в c4_out */
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    n = vsnprintf(buf, sizeof(buf), fmt, ap);
    __builtin_va_end(ap);
    if (n < 0) return;
    for (int i = 0; i < n && c4_out_pos + 1 < c4_out_max; i++)
        c4_out[c4_out_pos++] = buf[i];
}

#define exit(x) do { c4_exit_code = (x); __builtin_longjmp(c4_jmp, 1); } while (0)
#define printf(...) c4_printf(__VA_ARGS__)

/* хелперы диагностики: вывод "%d: MSG\n"; err дополнительно exit(-1) */
static void c4_err(int l, const char *msg)
{
    printf("%d: %s\n", l, msg);
    exit(-1);
}
static void c4_warn(int l, const char *msg)
{
    printf("%d: warning: %s\n", l, msg);
}

/* в точке, где функция ВПЕРВЫЕ помечена variadic (... в определении/
 * прототипе), проверяем её fixup'ы: вызовы, сделанные ДО этого момента,
 * эмитились без cdecl-разворота аргументов — раскладка стека у callee
 * не совпадёт. C89 разрешает это как UB; предупреждаем (один раз на
 * функцию; флаги гасим, чтобы повторные прототипы не дублировали
 * сообщение) */
static void c4_va_check_unaware(int *fid)
{
    int warned = 0;
    for (int i = 0; i < c4_n_jsr_fixups; i++) {
        if (c4_jsr_fixups[i].fid == fid && c4_jsr_fixups[i].va_unaware) {
            if (!warned) {
                /* id[Name] — указатель ВНУТРЬ исходника (c4 не копирует
                 * имена, NUL-терминатора у идентификатора НЕТ): печатаем
                 * только символы идентификатора, а не «до конца буфера». */
                printf("%d: warning: variadic function '", line);
                {
                    const char *q = (const char *)(unsigned long)fid[Name];
                    while (*q == '_' || (*q >= 'a' && *q <= 'z') ||
                           (*q >= 'A' && *q <= 'Z') || (*q >= '0' && *q <= '9'))
                        c4_putc(*q++);
                }
                printf("' called without prototype; "
                       "earlier calls were NOT unrolled (C89 requires a prototype)\n");
                warned = 1;
            }
            c4_jsr_fixups[i].va_unaware = 0;
        }
    }
}

/* --- goto / метки (расширение 2) ---
 * goto эмитит JMP с нулевым операндом + запись в c4_goto_fixups;
 * определение метки (Name:) патчит все ждущие goto на (e+1).
 * Ключ — запись идентификатора в symtab (как у c4_jsr_fixups).
 * Таблицы сбрасываются при входе в каждую функцию; незакрытые
 * goto в конце функции = «undefined label». */
#define C4_MAX_GOTO_FIXUPS 128
static struct { int *cell; int *fsym; } c4_goto_fixups[C4_MAX_GOTO_FIXUPS];
static int c4_n_goto_fixups = 0;

/* --- глобальные инициализаторы: чанки-функции + boot-код до main --- */
#define C4_MAX_BOOT 256
static int *c4_boot_chunks[C4_MAX_BOOT];
static int  c4_n_boot = 0;
static u32  c4_boot_cell = 0;   /* индекс ячейки boot-кода (0 = нет) */
#define C4_MAX_LABELS 128
static struct { int *fsym; int *addr; } c4_labels[C4_MAX_LABELS];
static int c4_n_labels = 0;

static int *c4_label_find(int *fsym)
{
    for (int i = 0; i < c4_n_labels; i++)
        if (c4_labels[i].fsym == fsym) return c4_labels[i].addr;
    return 0;
}

static void c4_label_define(int *fsym)
{
    int *addr = (int *)(e + 1);   /* следующая эмитируемая ячейка */
    for (int i = 0; i < c4_n_labels; i++) {
        if (c4_labels[i].fsym == fsym) {
            printf("%d: duplicate label '%s'\n", line, (char *)(unsigned long)fsym[Name]);
            exit(-1);
        }
    }
    if (c4_n_labels < C4_MAX_LABELS) {
        c4_labels[c4_n_labels].fsym = fsym;
        c4_labels[c4_n_labels].addr = addr;
        c4_n_labels++;
    }
    /* патчим все ждущие goto на эту метку и УБИРАЕМ их из списка
     * (иначе патченые фиксапы давали ложное «undefined label») */
    int w = 0;
    for (int i = 0; i < c4_n_goto_fixups; i++) {
        if (c4_goto_fixups[i].fsym == fsym)
            *c4_goto_fixups[i].cell = (int)(unsigned long)addr;
        else
            c4_goto_fixups[w++] = c4_goto_fixups[i];
    }
    c4_n_goto_fixups = w;
}

/* Метка ли это? tk == Id; p указывает на символ сразу после
 * идентификатора — пропускаем пробелы и ищем ':'. */
static int c4_at_label(void);

/* --- Разворачивание #include (расширение 5) ---
 * Однопроходный лексер не умеет подгружать файлы посреди потока,
 * поэтому ДО компиляции строится развёрнутый исходник: каждая строка
 * #include "file" / <file> заменяется содержимым файла (рекурсивно,
 * глубина <= 8, результат <= 1 МиБ, защита от циклических включений).
 * Возвращает malloc'нутый буфер (освобождает вызывающий) или NULL,
 * если включений не было (компилируем исходный текст как есть). */
#define C4_INCL_MAX_DEPTH 8
#define C4_INCL_MAX_OUT   (1024 * 1024)
#define C4_INCL_MAX_FILE  (256 * 1024)

static int c4_incl_depth = 0;
static const char *c4_incl_chain[C4_INCL_MAX_DEPTH];   /* имена активных включений */

static char *c4_incl_out;
static u32   c4_incl_len, c4_incl_cap;

static int c4_incl_reserve(u32 extra)
{
    if (c4_incl_len + extra + 1 <= c4_incl_cap) return 1;
    u32 ncap = c4_incl_cap ? c4_incl_cap * 2 : 65536;
    while (ncap < c4_incl_len + extra + 1) ncap *= 2;
    if (ncap > C4_INCL_MAX_OUT + 4096) return 0;
    char *nb = (char *)malloc(ncap);
    if (!nb) return 0;
    if (c4_incl_out) { memcpy(nb, c4_incl_out, c4_incl_len); free(c4_incl_out); }
    c4_incl_out = nb;
    c4_incl_cap = ncap;
    return 1;
}

static void c4_incl_emit(const char *s, u32 n)
{
    if (!c4_incl_reserve(n)) return;
    memcpy(c4_incl_out + c4_incl_len, s, n);
    c4_incl_len += n;
    c4_incl_out[c4_incl_len] = 0;
}

/* --- C89: условная компиляция (#ifdef/#ifndef/#if/#else/#elif/#endif) ---
 * Текстовый препроцессор ведёт список имён #define (с числовым значением,
 * если указано) и вырезает неактивные ветки ДО компиляции. Include-гuards
 * (#ifndef X_H / #define X_H / ... / #endif) работают естественно.
 *
 * функциональные макросы #define F(a,b) — параметры,
 * тело, подстановка аргументов по границам идентификаторов, рекурсивное
 * раскрытие (глубина <= 6). Тело хранится и для объектных макросов
 * (не только числа: #define MASK (1<<3) теперь тоже раскрывается текстом). */
#define C4_MAX_DEFS 96
#define C4_DEF_NAME 64
#define C4_DEF_PARAMS 64
#define C4_DEF_BODY 256
static char c4_def_names[C4_MAX_DEFS][C4_DEF_NAME];
static int  c4_def_has_val[C4_MAX_DEFS];
static int  c4_def_vals[C4_MAX_DEFS];
static char c4_def_pnames[C4_MAX_DEFS][C4_DEF_PARAMS]; /* "a,b,c" */
static char c4_def_bodies[C4_MAX_DEFS][C4_DEF_BODY];
static u8   c4_def_func[C4_MAX_DEFS];
static int  c4_n_defs = 0;

static int c4_def_find(const char *name, u32 len)
{
    for (int i = 0; i < c4_n_defs; i++)
        if ((int)len == (int)strlen(c4_def_names[i]) &&
            !memcmp(c4_def_names[i], name, len)) return i;
    return -1;
}

static void c4_def_add(const char *name, u32 len, int has_val, int val,
                       const char *body, u32 blen, const char *params, u32 plen,
                       int is_func)
{
    if (len == 0 || len >= C4_DEF_NAME) return;
    int di = c4_def_find(name, len);
    if (di < 0) {
        if (c4_n_defs >= C4_MAX_DEFS) return;
        di = c4_n_defs++;
        memcpy(c4_def_names[di], name, len);
        c4_def_names[di][len] = 0;
        c4_def_has_val[di] = 0;
    }
    c4_def_has_val[di] = has_val;
    c4_def_vals[di] = val;
    c4_def_func[di] = (u8)is_func;
    if (blen >= C4_DEF_BODY) blen = C4_DEF_BODY - 1;
    memcpy(c4_def_bodies[di], body, blen);
    c4_def_bodies[di][blen] = 0;
    if (plen >= C4_DEF_PARAMS) plen = C4_DEF_PARAMS - 1;
    memcpy(c4_def_pnames[di], params, plen);
    c4_def_pnames[di][plen] = 0;
}

static void c4_def_del(const char *name, u32 len)
{
    int di = c4_def_find(name, len);
    if (di < 0) return;
    for (int i = di; i < c4_n_defs - 1; i++) {
        memcpy(c4_def_names[i], c4_def_names[i + 1], C4_DEF_NAME);
        c4_def_has_val[i] = c4_def_has_val[i + 1];
        c4_def_vals[i] = c4_def_vals[i + 1];
    }
    c4_n_defs--;
}

/* слово директивы: возвращает длину или 0; *body — после слова (пробелы
 * пропущены), *bend — конец строки. */
static int c4_dir_word(const char *q, const char *le,
                       const char **body, const char **bend)
{
    const char *w = q + 1;                       /* после '#' */
    while (w < le && (*w == ' ' || *w == '\t')) w++;
    const char *ws = w;
    while (w < le && ((*w >= 'a' && *w <= 'z') || (*w >= 'A' && *w <= 'Z') || *w == '_')) w++;
    if (w == ws) return 0;
    *body = w;
    while (*body < le && (**body == ' ' || **body == '\t')) (*body)++;
    *bend = le;
    return (int)(w - ws);
}

/* вычислитель #if: числа (dec/hex/oct), defined(NAME)/defined NAME,
 * имена макросов (их числовое значение), скобки, унарные ! - + ~,
 * бинарные по приоритетам: || && | ^ & == != < > <= >= << >> + - * / %.
 * Деление/остаток на ноль дают 0 (не падаем). Всё остальное = 0. */
static int c4_if_expr(const char **pp, const char *le);

static int c4_if_prim(const char **pp, const char *le)
{
    const char *p = *pp;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    int v;
    if (*p == '(') {
        p++;
        v = c4_if_expr(&p, le);
        while (p < le && (*p == ' ' || *p == '\t')) p++;
        if (*p == ')') p++;
    } else if (p + 7 <= le && !memcmp(p, "defined", 7) &&
               (p[7] == '(' || p[7] == ' ' || p[7] == '\t')) {
        p += 7;
        while (p < le && (*p == ' ' || *p == '\t')) p++;
        if (*p == '(') p++;
        const char *ns = p;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        v = (c4_def_find(ns, (u32)(p - ns)) >= 0) ? 1 : 0;
        while (p < le && (*p == ' ' || *p == '\t')) p++;
        if (*p == ')') p++;
    } else if (*p >= '0' && *p <= '9') {
        if (*p == '0' && (p[1] == 'x' || p[1] == 'X')) {
            p += 2; v = 0;
            while (p < le && (((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') ||
                               (*p >= 'A' && *p <= 'F'))))
                v = v * 16 + (*p & 15) + (*p >= 'A' ? 9 : 0), p++;
        } else if (*p == '0') {
            v = 0;
            while (p < le && *p >= '0' && *p <= '7') v = v * 8 + (*p++ - '0');
        } else {
            v = 0;
            while (p < le && *p >= '0' && *p <= '9') v = v * 10 + (*p++ - '0');
        }
    } else {
        const char *ns = p;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        int di = (p > ns) ? c4_def_find(ns, (u32)(p - ns)) : -1;
        v = (di >= 0 && c4_def_has_val[di]) ? c4_def_vals[di] : 0;
    }
    *pp = p;
    return v;
}

/* унарные префиксы #if: ! - + ~ (рекурсивно, перед prim) */
static int c4_if_unary(const char **pp, const char *le)
{
    const char *p = *pp;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    if (p < le && (*p == '!' || *p == '-' || *p == '+' || *p == '~')) {
        int op = *p++;
        *pp = p;
        int v = c4_if_unary(pp, le);
        if (op == '!') return !v;
        if (op == '-') return -v;      /* #define X -5 в #if теперь верен */
        if (op == '~') return ~v;
        return v;
    }
    *pp = p;
    return c4_if_prim(pp, le);
}

/* бинарный оператор #if: id (0 = нет) и приоритет *pr (больше = сильнее).
 * 1|| 2&& 3== 4!= 5<= 6>= 7<< 8>> 9| 10^ 11& 12< 13> 14+ 15- 16* 17/ 18%
 * (двухсимвольные проверяются первыми) */
static int c4_if_op(const char **pp, const char *le, int *pr)
{
    const char *p = *pp;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    int op = 0, q = 0;
    #define C4_OP2(a, b) (p + 1 < le && p[0] == (a) && p[1] == (b))
    if      (C4_OP2('|','|')) { op = 1;  q = 1;  p += 2; }
    else if (C4_OP2('&','&')) { op = 2;  q = 2;  p += 2; }
    else if (C4_OP2('=','=')) { op = 3;  q = 6;  p += 2; }
    else if (C4_OP2('!','=')) { op = 4;  q = 6;  p += 2; }
    else if (C4_OP2('<','=')) { op = 5;  q = 7;  p += 2; }
    else if (C4_OP2('>','=')) { op = 6;  q = 7;  p += 2; }
    else if (C4_OP2('<','<')) { op = 7;  q = 8;  p += 2; }
    else if (C4_OP2('>','>')) { op = 8;  q = 8;  p += 2; }
    else if (p < le) {
        switch (*p) {
        case '|': op = 9;  q = 3;  break;
        case '^': op = 10; q = 4;  break;
        case '&': op = 11; q = 5;  break;
        case '<': op = 12; q = 7;  break;
        case '>': op = 13; q = 7;  break;
        case '+': op = 14; q = 9;  break;
        case '-': op = 15; q = 9;  break;
        case '*': op = 16; q = 10; break;
        case '/': op = 17; q = 10; break;
        case '%': op = 18; q = 10; break;
        }
        if (op) p++;
    }
    #undef C4_OP2
    *pp = p;
    *pr = q;
    return op;
}

/* приоритетное восхождение (precedence climbing) для #if */
static int c4_if_bin(const char **pp, const char *le, int minq)
{
    int l = c4_if_unary(pp, le);
    for (;;) {
        const char *save = *pp;        /* откат, если оператор не взят */
        int q;
        int op = c4_if_op(pp, le, &q);
        if (!op || q < minq) { *pp = save; break; }
        int r = c4_if_bin(pp, le, q + 1);
        switch (op) {
        case 1:  l = (l || r); break;
        case 2:  l = (l && r); break;
        case 3:  l = (l == r); break;
        case 4:  l = (l != r); break;
        case 5:  l = (l <= r); break;
        case 6:  l = (l >= r); break;
        case 7:  l = (l << r); break;
        case 8:  l = (l >> r); break;
        case 9:  l = (l |  r); break;
        case 10: l = (l ^  r); break;
        case 11: l = (l &  r); break;
        case 12: l = (l <  r); break;
        case 13: l = (l >  r); break;
        case 14: l = (l +  r); break;
        case 15: l = (l -  r); break;
        case 16: l = (l *  r); break;
        case 17: l = r ? (l / r) : 0; break;
        case 18: l = r ? (l % r) : 0; break;
        }
    }
    return l;
}

static int c4_if_expr(const char **pp, const char *le)
{
    return c4_if_bin(pp, le, 1);
}

/* запомнить #define: имя, параметры (если "имя(..."), тело, число (для #if). */
static void c4_def_record(const char *body, const char *le)
{
    const char *p = body;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    const char *ns = p;
    while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                      (*p >= '0' && *p <= '9') || *p == '_')) p++;
    if (p == ns) return;
    u32 len = (u32)(p - ns);
    int has_val = 0, val = 0;
    const char *params = ""; u32 plen = 0;
    int is_func = 0;
    /* функциональный макрос ТОЛЬКО если '(' стоит ВПЛОТНУЮ к имени
     * (правило CPP): #define F(a,b) — функция, #define M (1) — объект */
    if (p < le && *p == '(') {
        is_func = 1;
        params = p + 1;
        const char *qe = p + 1;
        while (qe < le && *qe != ')') qe++;
        plen = (u32)(qe - params);
        p = (qe < le) ? qe + 1 : le;
    }
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    const char *bod = p;
    u32 blen = (u32)(le - bod);
    while (blen > 0 && (bod[blen-1] == ' ' || bod[blen-1] == '\t' ||
                        bod[blen-1] == '\r')) blen--;
    if (!is_func && blen && (*bod == '-' || (*bod >= '0' && *bod <= '9') ||
        *bod == '(' )) {
        const char *np = bod;
        int v = c4_if_unary(&np, le);   /* унарный '-'/скобки: #define X -5 */
        has_val = 1; val = v;
    }
    c4_def_add(ns, len, has_val, val, bod, blen, params, plen, is_func);
}

/* обработать условную директиву. Возвращает:
 *   0 — не условная директива (строку emits вызывающий);
 *   1 — условная директива (строка вырезана, лексер её не увидит);
 *   2 — #define/#undef в активной области: строку надо ВЫВЕСТИ
 *       (лексер регистрирует значение), имя уже запомнено;
 *   3 — #define/#undef/#include в НЕактивной области: строка вырезана. */
static int c4_incl_directive(const char *q, const char *le, int *cd,
                             int *cact, int *ctaken, int *cpar)
{
    const char *body, *bend;
    int wl = c4_dir_word(q, le, &body, &bend);
    if (!wl) return 0;
    int parent = (*cd == 0) ? 1 : cact[*cd - 1];
    /* диспетчеризация по ДЛИНЕ имени: имена одной длины взаимоисключающи,
     * группы switch(wl). Имя не опознано — как прежде: return parent ? 0 : 3
     * (неизвестные директивы, напр. #include) */
    switch (wl) {
    case 2:                                   /* #if (длина отсекает ifdef/ifndef) */
        if (!memcmp(q + 1, "if", 2) &&
            !(q + 1 + 2 <= le && (q[3] == 'd'))) {   /* не ifdef/ifndef (уже отсечено длиной) */
            const char *bp = body;
            int v = c4_if_expr(&bp, le);
            if (*cd < 32) { cpar[*cd] = parent; cact[*cd] = parent && v; ctaken[*cd] = v; (*cd)++; }
            return 1;
        }
        break;
    case 4:                                   /* #else / #elif */
        if (!memcmp(q + 1, "else", 4)) {
            if (*cd > 0) {
                cact[*cd - 1] = cpar[*cd - 1] && !ctaken[*cd - 1];
                ctaken[*cd - 1] = 1;
            }
            return 1;
        }
        if (!memcmp(q + 1, "elif", 4)) {
            if (*cd > 0) {
                if (!ctaken[*cd - 1]) {
                    const char *bp = body;
                    int v = c4_if_expr(&bp, le);
                    cact[*cd - 1] = cpar[*cd - 1] && v;
                    ctaken[*cd - 1] = v;
                } else {
                    cact[*cd - 1] = 0;
                }
            }
            return 1;
        }
        break;
    case 5:                                   /* #ifdef / #endif / #undef */
        if (!memcmp(q + 1, "ifdef", 5)) {
            const char *ns = body;
            const char *p = body;
            while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                              (*p >= '0' && *p <= '9') || *p == '_')) p++;
            int def = (c4_def_find(ns, (u32)(p - ns)) >= 0);
            if (*cd < 32) { cpar[*cd] = parent; cact[*cd] = parent && def; ctaken[*cd] = def; (*cd)++; }
            return 1;
        }
        if (!memcmp(q + 1, "endif", 5)) {
            if (*cd > 0) (*cd)--;
            return 1;
        }
        if (!memcmp(q + 1, "undef", 5)) {
            if (!parent) return 3;
            const char *ns = body;
            const char *p = body;
            while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                              (*p >= '0' && *p <= '9') || *p == '_')) p++;
            c4_def_del(ns, (u32)(p - ns));
            return 2;                     /* лексер строку пропустит сам */
        }
        break;
    case 6:                                   /* #ifndef / #define / #pragma */
        if (!memcmp(q + 1, "ifndef", 6)) {
            const char *ns = body;
            const char *p = body;
            while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                              (*p >= '0' && *p <= '9') || *p == '_')) p++;
            int def = (c4_def_find(ns, (u32)(p - ns)) >= 0);
            if (*cd < 32) { cpar[*cd] = parent; cact[*cd] = parent && !def; ctaken[*cd] = !def; (*cd)++; }
            return 1;
        }
        if (!memcmp(q + 1, "define", 6)) {
            if (!parent) return 3;
            c4_def_record(body, le);
            return 2;                     /* строку выводим — лексер зарегистрирует */
        }
        if (!memcmp(q + 1, "pragma", 6)) {
            /* #pragma once и прочие #pragma — строка вырезается (подавление
             * повторных включений делает c4_incl_expand, где есть имя файла) */
            return 1;
        }
        break;
    }
    return parent ? 0 : 3;   /* прочие директивы (#include...) */
}

/* ---------- 2.1: раскрытие макросов в строках кода ----------
 * c4_expand_line: сканирует [s, s+n), заменяет объектные макросы телом,
 * функциональные — телом с подставленными аргументами (аргументы —
 * сбалансированные по скобкам куски до запятой верхнего уровня), затем
 * рекурсивно разворачивает результат (глубина <= 6 — защита от рекурсии).
 * Строковые/символьные литералы не раскрываются. */

#define C4_EXP_MAXOUT 4096
static void c4_expand_line(const char *s, u32 n, char *out, u32 outmax, int depth);

/* подстановка параметров par ("a,b,c") в тело: имена параметров по
 * границам идентификаторов заменяются на аргументы */
static u32 c4_macro_subst(const char *body, u32 blen, const char *par,
                          char (*args)[512], u32 *alen, int nargs,
                          char *out, u32 outmax)
{
    u32 oi = 0;
    const char *p = body, *pe = body + blen;
    while (p < pe && oi + 1 < outmax) {
        if ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || *p == '_') {
            const char *ws = p;
            while (p < pe && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                              (*p >= '0' && *p <= '9') || *p == '_')) p++;
            u32 wl = (u32)(p - ws);
            /* номер параметра */
            int pi = 0, found = -1;
            const char *q = par;
            while (*q && pi < nargs) {
                while (*q == ' ' || *q == '\t') q++;
                const char *qs = q;
                while (*q && *q != ',') q++;
                const char *qe2 = q; while (qe2 > qs && (qe2[-1]==' '||qe2[-1]=='\t')) qe2--;
                if ((u32)(qe2 - qs) == wl && !memcmp(qs, ws, wl)) { found = pi; break; }
                pi++;
                if (*q == ',') q++;
            }
            if (found >= 0 && alen[found] < outmax) {
                if (oi + alen[found] + 1 >= outmax) break;
                memcpy(out + oi, args[found], alen[found]); oi += alen[found];
            } else {
                if (oi + wl + 1 >= outmax) break;
                memcpy(out + oi, ws, wl); oi += wl;
            }
            continue;
        }
        out[oi++] = *p++;
    }
    out[oi] = 0;
    return oi;
}

static void c4_expand_line(const char *s, u32 n, char *out, u32 outmax, int depth)
{
    u32 oi = 0;
    const char *p = s, *le = s + n;
    #define C4_PUT(ch_) do { if (oi + 1 < outmax) out[oi++] = (ch_); } while (0)
    while (p < le && oi + 1 < outmax) {
        if (*p == '"' || *p == '\'') {
            /* литерал — копировать как есть (с экранами) */
            char q2 = *p; C4_PUT(*p++);
            while (p < le && oi + 1 < outmax) {
                C4_PUT(*p);
                if (*p == '\\' && p + 1 < le) { p++; C4_PUT(*p++); continue; }
                p++;
                if (p[-1] == q2) break;
            }
            continue;
        }
        if ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || *p == '_') {
            const char *ws = p;
            while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                              (*p >= '0' && *p <= '9') || *p == '_')) p++;
            u32 wl = (u32)(p - ws);
            int di = c4_def_find(ws, wl);
            if (di < 0 || depth >= 6) {
                if (oi + wl + 1 < outmax) { memcpy(out + oi, ws, wl); oi += wl; }
                continue;
            }
            if (!c4_def_func[di]) {
                /* объектный: тело рекурсивно */
                char tmp[C4_EXP_MAXOUT / 4];
                c4_expand_line(c4_def_bodies[di], (u32)strlen(c4_def_bodies[di]),
                               tmp, sizeof(tmp), depth + 1);
                u32 tl = (u32)strlen(tmp);
                if (oi + tl + 1 < outmax) { memcpy(out + oi, tmp, tl); oi += tl; }
                continue;
            }
            /* функциональный: ждём '(' (пробелы/переводы строк) */
            {
                const char *q2 = p;
                while (q2 < le && (*q2 == ' ' || *q2 == '\t' || *q2 == '\n' ||
                                   *q2 == '\r' || *q2 == '\\')) q2++;
                if (q2 >= le || *q2 != '(') {
                    if (oi + wl + 1 < outmax) { memcpy(out + oi, ws, wl); oi += wl; }
                    continue;
                }
                q2++;
                /* аргументы: сбалансированные куски до ',' верхнего уровня */
                char args[8][512]; u32 alen[8]; int nargs = 0;
                int dep = 1;
                u32 ai = 0;
                while (q2 <= le && nargs < 8) {
                    if (q2 >= le) break;
                    if (*q2 == '(') dep++;
                    else if (*q2 == ')') { dep--; if (dep == 0) { args[nargs][ai] = 0; alen[nargs] = ai; nargs++; q2++; break; } }
                    else if (*q2 == ',' && dep == 1) { args[nargs][ai] = 0; alen[nargs] = ai; nargs++; ai = 0; q2++; continue; }
                    if (ai < sizeof(args[0]) - 1) args[nargs][ai++] = *q2;
                    q2++;
                }
                if (dep != 0) { /* незакрытые скобки — оставить имя как есть */
                    if (oi + wl + 1 < outmax) { memcpy(out + oi, ws, wl); oi += wl; }
                    continue;
                }
                /* подстановка параметров + рекурсивное раскрытие */
                char subst[C4_EXP_MAXOUT / 2];
                u32 sl = c4_macro_subst(c4_def_bodies[di], (u32)strlen(c4_def_bodies[di]),
                                        c4_def_pnames[di], args, alen, nargs,
                                        subst, sizeof(subst));
                char tmp[C4_EXP_MAXOUT / 2];
                c4_expand_line(subst, sl, tmp, sizeof(tmp), depth + 1);
                u32 tl = (u32)strlen(tmp);
                if (oi + tl + 1 < outmax) { memcpy(out + oi, tmp, tl); oi += tl; }
                p = q2;
                continue;
            }
        }
        C4_PUT(*p++);
    }
    out[oi] = 0;
    #undef C4_PUT
}

/* строка кода через раскрытие макросов, затем в выходной буфер */
static void c4_incl_emit_expanded(const char *s, u32 n)
{
    static char expbuf[C4_EXP_MAXOUT];
    c4_expand_line(s, n, expbuf, sizeof(expbuf), 0);
    c4_incl_emit(expbuf, (u32)strlen(expbuf));
}

/* --- 2.2: встроенные freestanding-заголовки (§5.1.2.1) ---
 * Отдаются, если хост-хук не нашёл файл (#include <...>). */
static u32 c4_builtin_header(const char *name, char *buf, u32 max)
{
    static const struct { const char *nm, *txt; } bh[] = {
        { "stddef.h",
          "typedef unsigned size_t;\n"
          "typedef int ptrdiff_t;\n"
          "#define NULL 0\n"
          "#define offsetof(t, m) ((int)(unsigned long)&(((t *)0)->m))\n" },
        { "limits.h",
          "#define CHAR_BIT 8\n#define SCHAR_MIN (-128)\n#define SCHAR_MAX 127\n"
          "#define UCHAR_MAX 255\n#define SHRT_MIN (-32768)\n#define SHRT_MAX 32767\n"
          "#define USHRT_MAX 65535\n#define INT_MAX 2147483647\n"
          "#define INT_MIN (-2147483647-1)\n#define UINT_MAX 4294967295U\n"
          "#define LONG_MAX 2147483647\n#define LONG_MIN (-2147483647-1)\n"
          "#define ULONG_MAX 4294967295U\n" },
        { "stdint.h",
          "typedef signed char int8_t;\ntypedef unsigned char uint8_t;\n"
          "typedef short int16_t;\ntypedef unsigned short uint16_t;\n"
          "typedef int int32_t;\ntypedef unsigned int uint32_t;\n"
          "typedef int intptr_t;\ntypedef unsigned int uintptr_t;\n" },
        { "stdbool.h", "typedef int bool;\n#define true 1\n#define false 0\n" },
        { "stdarg.h",
          /* ABI c4: именованные параметры variadic-функции в bp+2..,
           * vararg'и — ВЫШЕ (вызов пушится справа налево, cdecl).
           * va_list — ПОЯЧЕЧНЫЙ указатель (int*); va_arg шагает вверх
           * по ячейкам (double = 2 ячейки). va_start становится на
           * ячейку последнего именованного параметра. */
          "typedef int *va_list;\n"
          "#define va_start(ap, last) ((ap) = (int *)&(last) + sizeof(last) / sizeof(int))\n"
          "#define va_arg(ap, t) (*(t *)((int *)((ap) += sizeof(t) / sizeof(int)) - sizeof(t) / sizeof(int)))\n"
          "#define va_end(ap) ((ap) = 0)\n" },
        { "float.h",
          "#define FLT_RADIX 2\n#define FLT_MANT_DIG 24\n#define DBL_MANT_DIG 53\n"
          "#define FLT_DIG 6\n#define DBL_DIG 15\n"
          "#define FLT_MAX 3.40282346638528859812e+38F\n"
          "#define DBL_MAX 1.79769313486231570815e+308\n"
          "#define FLT_MIN 1.17549435082228750797e-38F\n"
          "#define DBL_MIN 2.22507385850720138309e-308\n"
          "#define FLT_EPSILON 1.19209289550781250000e-7F\n"
          "#define DBL_EPSILON 2.22044604925031308085e-16\n" },
        { "math.h", "double fabs(double x);\ndouble sqrt(double x);\n" },
        { "stdio.h", "int printf(const char *fmt, ...);\n" },
        { "string.h",
          "int strlen(const char *s);\nchar *strcpy(char *d, const char *s);\n"
          "int strcmp(const char *a, const char *b);\n"
          "void *memset(void *d, int c, unsigned n);\n"
          "int memcmp(const void *a, const void *b, unsigned n);\n" },
        { "stdlib.h", "#define NULL 0\nvoid *malloc(unsigned n);\nvoid free(void *p);\n" },
    };
    for (int i = 0; i < (int)(sizeof(bh) / sizeof(bh[0])); i++) {
        if (!strcmp(bh[i].nm, name)) {
            u32 L = (u32)strlen(bh[i].txt);
            if (L > max - 1) L = max - 1;
            memcpy(buf, bh[i].txt, L);
            return L;
        }
    }
    return 0;
}

/* список файлов с #pragma once */
#define C4_MAX_ONCE 16
static char c4_once_list[C4_MAX_ONCE][C4_DEF_NAME];
static int  c4_n_once = 0;

static int c4_was_once(const char *name)
{
    for (int i = 0; i < c4_n_once; i++)
        if (!strcmp(c4_once_list[i], name)) return 1;
    return 0;
}

static void c4_incl_expand(const char *src, const char *includer)
{
    int my_depth = c4_incl_depth;
    if (my_depth >= C4_INCL_MAX_DEPTH) return;
    c4_incl_depth = my_depth + 1;
    /* стек условной компиляции — локальный на файл (незакрытый #if
     * в одном заголовке не ломает остальные) */
    int cd = 0;
    int cact[32], ctaken[32], cpar[32];
    const char *p = src;
    while (*p) {
        const char *le = p;
        while (*le && *le != '\n') le++;          /* конец строки (не включая \n) */
        u32 line_len = (u32)(le - p);
        /* начало строки после пропуска пробелов */
        const char *q = p;
        while (q < le && (*q == ' ' || *q == '\t')) q++;
        if (*q != '#' && cd > 0 && !cact[cd - 1]) {
            /* НЕактивная область: обычные строки вырезаются (директивы
             * обработаны выше по стеку; #include/#define в неактивных
             * ветках дают dr == 3 и тоже вырезаются). */
            if (*le == '\n') c4_incl_emit("\n", 1);
            p = *le ? le + 1 : le;
            continue;
        }
        if (*q == '#') {
            /* #pragma once — до c4_incl_directive: нужно имя текущего файла
             * (c4_incl_chain[my_depth - 1]) для списка уже включённых */
            if (q + 7 <= le && !memcmp(q + 1, "pragma", 6) &&
                (q[7] == ' ' || q[7] == '\t')) {
                const char *pb = q + 7;
                while (pb < le && (*pb == ' ' || *pb == '\t')) pb++;
                if (le - pb >= 4 && !memcmp(pb, "once", 4)) {
                    const char *cn = c4_incl_chain[my_depth - 1];
                    if (cn && *cn && !c4_was_once(cn) && c4_n_once < C4_MAX_ONCE) {
                        u32 ol = (u32)strlen(cn);
                        if (ol >= C4_DEF_NAME) ol = C4_DEF_NAME - 1;
                        memcpy(c4_once_list[c4_n_once], cn, ol);
                        c4_once_list[c4_n_once][ol] = 0;
                        c4_n_once++;
                    }
                }
                if (*le == '\n') c4_incl_emit("\n", 1);
                p = *le ? le + 1 : le;
                continue;
            }
            int dr = c4_incl_directive(q, le, &cd, cact, ctaken, cpar);
            if (dr == 1 || dr == 3) {
                /* условная директива / неактивная строка: вырезаем,
                 * перевод строки оставляем (нумерация строк) */
                if (*le == '\n') c4_incl_emit("\n", 1);
                p = *le ? le + 1 : le;
                continue;
            }
            if (dr == 2) {
                /* активный #define/#undef: строка выводится как есть */
                c4_incl_emit(p, line_len);
                c4_incl_emit("\n", 1);
                p = *le ? le + 1 : le;
                continue;
            }
            if (q + 8 <= le && !memcmp(q + 1, "include", 7) &&
                (q[8] == ' ' || q[8] == '\t')) {
                /* #include "name" / <name> */
                const char *fn = q + 9;
                while (fn < le && (*fn == ' ' || *fn == '\t')) fn++;
                int kind = -1;
                char name[256]; u32 nl = 0;
                if (fn < le && *fn == '"') {
                    kind = 0; fn++;
                    while (fn < le && *fn != '"' && nl < sizeof(name) - 1) name[nl++] = *fn++;
                } else if (fn < le && *fn == '<') {
                    kind = 1; fn++;
                    while (fn < le && *fn != '>' && nl < sizeof(name) - 1) name[nl++] = *fn++;
                }
                if (kind >= 0) {
                    name[nl] = 0;
                    /* #pragma once: файл уже включался — пропустить целиком
                     * (повторные #define не должны выполняться) */
                    if (c4_was_once(name)) {
                        if (*le == '\n') c4_incl_emit("\n", 1);
                        p = *le ? le + 1 : le;
                        continue;
                    }
                    int cyclic = 0;
                    for (int i = 0; i < c4_incl_depth - 1; i++)
                        if (c4_incl_chain[i] && !strcmp(c4_incl_chain[i], name)) cyclic = 1;
                    static char buf[C4_INCL_MAX_FILE];
                    u32 got = 0;
                    if (!cyclic && c4_include_hook)
                        got = c4_include_hook(name, kind, includer, buf, sizeof(buf) - 1);
                    /* 2.2: встроенные freestanding-заголовки (<stddef.h> и др.) */
                    if (!got && kind == 1 && !cyclic)
                        got = c4_builtin_header(name, buf, sizeof(buf) - 1);
                    if (got) {
                        buf[got] = 0;
                        c4_incl_chain[c4_incl_depth - 1] = name;
                        c4_incl_expand(buf, name);
                        /* включённый файл обязан кончаться переводом строки */
                        if (c4_incl_len && c4_incl_out[c4_incl_len - 1] != '\n')
                            c4_incl_emit("\n", 1);
                        c4_incl_chain[c4_incl_depth - 1] = 0;
                    }
                    /* не найден/цикл — строка просто пропадает (не ломаем лексер).
                     * c4_incl_depth НЕ трогаем: рекурсивный вызов уже сбалансирован. */
                    if (*le == '\n') c4_incl_emit("\n", 1);  /* сохранить нумерацию строк */
                    p = *le ? le + 1 : le;
                    continue;
                }
                /* нераспознанный #include — копируем как есть (лексер пропустит) */
            }
        }
        /* строка кода: раскрытие макросов (2.1), затем в выход */
        c4_incl_emit_expanded(p, line_len);
        c4_incl_emit("\n", 1);
        p = *le ? le + 1 : le;
    }
    (void)includer;
    c4_incl_depth = my_depth;
}

/* Публичная точка: вернуть развёрнутый исходник или NULL (включений нет).
 * Работает и БЕЗ c4_include_hook: условная компиляция, #pragma once,
 * раскрытие макросов и встроенные заголовки не требуют хука; без хука
 * пропускаются только #include "файл" (встроенные <...> отдаются всегда). */
static char *c4_preprocess(const char *src)
{
    /* быстрый скан: нет ни одного "#include"/"#if"/"#define" (покрывает и
     * #ifdef/#ifndef/#elif/#pragma once/функциональные макросы) — не тратим
     * память. "#define" подключает препроцессор всегда: раскрытие макросов
     * текстом (2.1) требует прохода даже без include-ов. */
    if (!strstr(src, "#include") && !strstr(src, "#if") &&
        !strstr(src, "#define")) return 0;
    c4_incl_out = 0; c4_incl_len = 0; c4_incl_cap = 0;
    c4_incl_depth = 0;
    c4_incl_chain[0] = 0;
    c4_n_defs = 0;                 /* список #define — на одну компиляцию */
    c4_incl_expand(src, "");
    if (!c4_incl_out) return 0;
    c4_incl_reserve(1);
    c4_incl_out[c4_incl_len] = 0;
    return c4_incl_out;
}

/* Метка ли это? tk == Id; p указывает на символ сразу после
 * идентификатора — пропускаем пробелы и ищем ':'. */
static int c4_at_label(void)
{
    const char *q = p;
    while (*q == ' ' || *q == '\t' || *q == '\r' || *q == '\n') q++;
    return *q == ':';
}

/* Подглядеть символ ch сразу после текущего токена (через пробелы/
 * переводы строк). Нужно для различения f(void) и f(char c). */
static int c4_raw_peek(char ch)
{
    const char *q = p;
    while (*q == ' ' || *q == '\t' || *q == '\r' || *q == '\n') q++;
    return *q == ch;
}

/* Квалификаторы/классы памяти, разбираемые и игнорируемые (C89).
 * static внутри функций РЕАЛЕН (1.2): ловим в C4_EAT_QUALS. */
#define IS_QUAL(t) ((t) == Const || (t) == Static || (t) == Volatile || \
                    (t) == Extern || (t) == Register || (t) == Auto)

/* съесть квалификаторы, запомнив static для следующего c4_parse_decls */
#define C4_EAT_QUALS() do { \
    while (IS_QUAL(tk)) { \
        if (tk == Static) c4_decl_static = 1; \
        else if (tk == Extern) c4_decl_extern = 1; \
        next(); } \
} while (0)

static int c4_decl_static = 0;   /* флаг static для c4_parse_decls (1.2) */
/* флаг extern-декларации глобала (C89 §6.1.2.2): extern без
 * инициализатора — ССЫЛКА, не определение; за ней может следовать
 * настоящее определение («extern int x; int x = 5;»). Значим только на
 * глобальном уровне; c4_parse_decls гасит его */
static int c4_decl_extern = 0;

static int c4_base_type(void);              /* единый разбор базового типа */
static void c4_parse_typedef(void);
static void c4_parse_decls(int bt, int scope_push);
void expr(int lev);

/* --- Стек областей видимости (объявления во вложенных блоках, C89) ---
 * При объявлении в блоке запись символа сохраняется ЦЕЛИКОМ; при '}'
 * блока восстанавливается (LIFO). Перекрытие параметров, глобалов и
 * #define-констант работает корректно на любую глубину. */
#define C4_MAX_SCOPE 512
static int c4_scope_save[C4_MAX_SCOPE * Idsz];
static int *c4_scope_id[C4_MAX_SCOPE];
static int  c4_n_scope = 0;

static void c4_scope_push(int *sid)
{
    if (c4_n_scope >= C4_MAX_SCOPE) return;
    c4_scope_id[c4_n_scope] = sid;
    for (int k = 0; k < Idsz; k++)
        c4_scope_save[c4_n_scope * Idsz + k] = sid[k];
    c4_n_scope++;
}

static void c4_scope_pop_to(int base)
{
    while (c4_n_scope > base) {
        int *sid;
        c4_n_scope--;
        sid = c4_scope_id[c4_n_scope];
        for (int k = 0; k < Idsz; k++)
            sid[k] = c4_scope_save[c4_n_scope * Idsz + k];
    }
}

/* --- Сырые сканеры инициализаторов (размер int a[] = {...} / = "строка") ---
 * Однопроходный парсер не умеет «сначала посчитать, потом парсить»,
 * поэтому размер выводится сканом сырого текста. Учитывают строки,
 * символы и комментарии (чтобы запятые/кавычки внутри них не считались). */

/* Количество элементов в "{ e0, e1, ... }"; sv указывает на '{'. */
static int c4_count_init_list(const char *sv)
{
    int depth = 0, cnt = 1, in_str = 0, in_chr = 0;
    while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
    if (*sv != '{') return 1;
    sv++;
    while (*sv) {
        if (in_str) {
            if (*sv == '\\') sv++;
            else if (*sv == '"') in_str = 0;
        } else if (in_chr) {
            if (*sv == '\\') sv++;
            else if (*sv == '\'') in_chr = 0;
        } else if (*sv == '"') in_str = 1;
        else if (*sv == '\'') in_chr = 1;
        else if (*sv == '/' && sv[1] == '*') {
            sv += 2;
            while (*sv && !(sv[0] == '*' && sv[1] == '/')) sv++;
            if (*sv) sv++;
        } else if (*sv == '/' && sv[1] == '/') {
            while (*sv && *sv != '\n') sv++;
        } else if (*sv == '{') depth++;
        else if (*sv == '}') { if (depth == 0) break; depth--; }
        else if (*sv == ',' && depth == 0) cnt++;
        sv++;
    }
    return cnt;
}

/* Длина строкового инициализатора в БАЙТАХ (включая NUL); sv указывает
 * на открывающую кавычку. Смежные литералы "a" "b" склеиваются,
 * escape-последовательности считаются одним символом. */
static int c4_count_str_lit(const char *sv)
{
    int n = 0;
    for (;;) {
        while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
        if (*sv != '"') break;
        sv++;
        while (*sv && *sv != '"') {
            if (*sv == '\\') {
                sv++;
                if (*sv == 'x' || *sv == 'X') {
                    sv++;
                    while ((*sv >= '0' && *sv <= '9') || (*sv >= 'a' && *sv <= 'f') ||
                           (*sv >= 'A' && *sv <= 'F')) sv++;
                } else {
                    if (*sv) sv++;
                    while (*sv >= '0' && *sv <= '7') sv++;   /* \NNN — до 3 цифр */
                }
            } else sv++;
            n++;
        }
        if (*sv == '"') sv++; else break;   /* незакрытая строка — что успели */
    }
    return n + 1;   /* NUL-терминатор */
}


/* сканер хвоста вещественного литерала — общий для «1.5[...][e±N]» и
 * «.5[...][e±N]». Дробные цифры копим ЦЕЛЫМ и делим ОДИН раз
 * (накопление digit*0.1^k давало 3.25 = 3.2499999999999996); экспонента
 * — циклическим умножением/делением на 10 (>300 клампим) */
static double c4_scan_real_tail(double dv)
{
    if (*p == '.') {
        u64 fv = 0, fd = 1;
        p++;
        while (*p >= '0' && *p <= '9') {
            if (fd <= 100000000000000ULL) {
                fv = fv * 10 + (u64)(*p++ - '0');
                fd *= 10;
            } else p++;   /* >15 значащих цифр — лишние отбрасываем */
        }
        dv += (double)fv / (double)fd;
    }
    if (*p == 'e' || *p == 'E') {
        int es = 1, ev = 0;
        p++;
        if (*p == '+') p++; else if (*p == '-') { es = -1; p++; }
        while (*p >= '0' && *p <= '9') ev = ev * 10 + (*p++ - '0');
        /* клампинг экспоненты не молчаливый — диагностика через printf (канал
         * прочих предупреждений лексера) */
        if (ev > 300) {
            printf("%d: warning: exponent out of range in floating constant"
                   " (clamped to 300)\n", line);
            ev = 300;
        }
        while (ev-- > 0) { if (es > 0) dv *= 10.0; else dv /= 10.0; }
    }
    return dv;
}

void next()
{
  char *pp;

  while ((tk = *p) != 0) {
    ++p;
    if (tk == '\n') {
      if (src) {
        printf("%d: %.*s", line, p - lp, lp);
        lp = p;
        while (le < e) {
          printf("%8.4s", &"LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,"
                           "OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,"
                           "OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,"[*++le * 5]);
          if (*le <= ADJ) printf(" %d\n", *++le); else printf("\n");
        }
      }
      ++line;
    }
    else if (tk == '#') {
      /* сюда попадают только директивы, пропускаемые препроцессором дальше:
       * #error (C89, диагностическая остановка) и неизвестные #-строки
       * (например, #pragma, не покрытая «once»); «#define» раскрывается/
       * вырезается ДО лексера */
      if (p[0]=='e' && p[1]=='r' && p[2]=='r' && p[3]=='o' && p[4]=='r' &&
          (p[5]==' '||p[5]=='\t'||p[5]=='\r'||p[5]=='\n'||!p[5])) {
        /* #error message — диагностическая остановка компиляции (C89).
         * Неактивные ветки #if вырезаны препроцессором и сюда не дойдут. */
        char *m = p + 5;
        while (*m == ' ' || *m == '\t') m++;
        char *me = m;
        while (*me && *me != '\n' && *me != '\r') me++;
        printf("%d: #error: %.*s\n", line, (int)(me - m), m);
        exit(-1);
      }
      /* Пропускаем остаток строки (с учётом переноса \ в конце строки) */
      while (*p != 0 && *p != '\n') {
        if (*p == '\\' && (p[1] == '\n' || (p[1] == '\r' && p[2] == '\n'))) {
          p += (p[1] == '\r') ? 3 : 2;
          ++line;
          continue;
        }
        ++p;
      }
    }
    else if ((tk >= 'a' && tk <= 'z') || (tk >= 'A' && tk <= 'Z') || tk == '_') {
      pp = p - 1;
      while ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') || *p == '_')
        tk = tk * 147 + *p++;
      tk = (tk << 6) + (p - pp);
      id = sym;
      while (id[Tk]) {
        if (tk == id[Hash] && !memcmp((char *)id[Name], pp, p - pp)) {
          tk = id[Tk];
          if (tk == Num) ival = id[Val];  /* #define'd constant → set ival */
          return;
        }
        id = id + Idsz;
      }
      id[Name] = (int)(unsigned long)pp;
      id[Hash] = tk;
      tk = id[Tk] = Id;
      return;
    }
    else if (tk >= '0' && tk <= '9') {
      if ((ival = tk - '0') != 0) { while (*p >= '0' && *p <= '9') ival = ival * 10 + *p++ - '0'; }
      else if (*p == 'x' || *p == 'X') {
        while ((tk = *++p) && ((tk >= '0' && tk <= '9') || (tk >= 'a' && tk <= 'f') || (tk >= 'A' && tk <= 'F')))
          ival = ival * 16 + (tk & 15) + (tk >= 'A' ? 9 : 0);
      }
      else { while (*p >= '0' && *p <= '7') ival = ival * 8 + *p++ - '0'; }
      /* float/double литералы C89 — 1.5, 2., .5 не сюда (см. ветку '.'),
       * 1e3, 1.5e-2. Дробную часть и экспоненту считаем в double без strtod;
       * общий хвост — c4_scan_real_tail */
      c4_num_dbl = 0;
      if (*p == '.' || ((*p == 'e' || *p == 'E') &&
          (p[1] == '+' || p[1] == '-' || (p[1] >= '0' && p[1] <= '9')))) {
        dval = c4_scan_real_tail((double)ival);
        c4_num_dbl = 2;   /* без суффикса — double (C89 §6.4.4) */
      }
      /* суффиксы C89: U/L/... + f/F на вещественном литерале (float) */
      {
        int suff_f = 0;
        while (*p == 'u' || *p == 'U' || *p == 'l' || *p == 'L' || *p == 'f' || *p == 'F') {
          if (*p == 'f' || *p == 'F') suff_f = 1;
          p++;
        }
        if (c4_num_dbl && suff_f) c4_num_dbl = 1;
      }
      tk = Num;
      return;
    }
    else if (tk == '/') {
      if (*p == '/') {
        ++p;
        while (*p != 0 && *p != '\n') ++p;
      }
      else if (*p == '*') {
        /* Block comment: skip until matching */
        ++p; /* skip '*' */
        while (*p != 0) {
          if (*p == '*' && p[1] == '/') { p += 2; break; }
          ++p;
        }
      }
      else {
        if (*p == '=') { ++p; tk = DivAssign; } else tk = Div;
        return;
      }
    }
    else if (tk == '\'' || tk == '"') {
      pp = data;
      while (*p != 0 && *p != tk) {
        if ((ival = *p++) == '\\') {
          ival = *p++;
          /* Полный набор escape-последовательностей C89 */
          if      (ival == 'n') ival = '\n';
          else if (ival == 't') ival = '\t';
          else if (ival == 'r') ival = '\r';
          else if (ival == 'a') ival = 7;    /* bell */
          else if (ival == 'b') ival = 8;    /* backspace */
          else if (ival == 'f') ival = 12;   /* form feed */
          else if (ival == 'v') ival = 11;   /* vtab */
          else if (ival == '\\') ival = '\\';
          else if (ival == '\'') ival = '\'';
          else if (ival == '"') ival = '"';
          else if (ival == '?') ival = '?';
          else if (ival == 'x' || ival == 'X') {
            /* \xHH — шестнадцатеричный код */
            ival = 0;
            while ((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') || (*p >= 'A' && *p <= 'F'))
              ival = ival * 16 + (*p & 15) + (*p >= 'A' ? 9 : 0), p++;
          }
          else if (ival >= '0' && ival <= '7') {
            /* \NNN — восьмеричный код (включая \0) */
            ival -= '0';
            while (*p >= '0' && *p <= '7') ival = ival * 8 + (*p++ - '0');
          }
        }
        if (tk == '"') *data++ = (char)ival;
      }
      ++p;
      if (tk == '"') ival = (int)(unsigned long)pp; else tk = Num;
      return;
    }
    else if (tk == '=') { if (*p == '=') { ++p; tk = Eq; } else tk = Assign; return; }
    else if (tk == '+') { if (*p == '+') { ++p; tk = Inc; } else if (*p == '=') { ++p; tk = AddAssign; } else tk = Add; return; }
    else if (tk == '-') {
      if (*p == '-') { ++p; tk = Dec; }
      else if (*p == '=') { ++p; tk = SubAssign; }
      else if (*p == '>') { ++p; tk = Arrow; }   /* p->f (3.1) */
      else tk = Sub;
      return;
    }
    else if (tk == '!') { if (*p == '=') { ++p; tk = Ne; } return; }
    else if (tk == '<') {
      if (*p == '=') { ++p; tk = Le; }
      else if (*p == '<') { ++p; if (*p == '=') { ++p; tk = ShlAssign; } else tk = Shl; }
      else tk = Lt;
      return;
    }
    else if (tk == '>') {
      if (*p == '=') { ++p; tk = Ge; }
      else if (*p == '>') { ++p; if (*p == '=') { ++p; tk = ShrAssign; } else tk = Shr; }
      else tk = Gt;
      return;
    }
    else if (tk == '|') { if (*p == '|') { ++p; tk = Lor; } else if (*p == '=') { ++p; tk = OrAssign; } else tk = Or; return; }
    else if (tk == '&') { if (*p == '&') { ++p; tk = Lan; } else if (*p == '=') { ++p; tk = AndAssign; } else tk = And; return; }
    else if (tk == '^') { if (*p == '=') { ++p; tk = XorAssign; } else tk = Xor; return; }
    else if (tk == '%') { if (*p == '=') { ++p; tk = ModAssign; } else tk = Mod; return; }
    else if (tk == '*') { if (*p == '=') { ++p; tk = MulAssign; } else tk = Mul; return; }
    else if (tk == '[') { tk = Brak; return; }
    else if (tk == '?') { tk = Cond; return; }
    else if (tk == ',') { tk = Comma; return; }
    else if (tk == '.' && p[0] == '.' && p[1] == '.') {
      /* "..." — диапазон case (case 2 ... 6:) и varargs-параметры; p стоит на 2-й точке */
      p += 2; tk = DotDotDot; return;
    }
    else if (tk == '.' && p[0] >= '0' && p[0] <= '9') {
      /* вещественный литерал с ведущей точкой — .5, .5e2 (C89);
       * общий хвост — c4_scan_real_tail */
      dval = c4_scan_real_tail(0.0);
      c4_num_dbl = 2;
      while (*p == 'f' || *p == 'F' || *p == 'l' || *p == 'L') {
        if (*p == 'f' || *p == 'F') c4_num_dbl = 1;
        p++;
      }
      tk = Num;
      return;
    }
    else if (tk == '.') { tk = Dot; return; }   /* s.f — доступ к полю (3.1) */
    else if (tk == '~' || tk == ';' || tk == '{' || tk == '}' || tk == '(' || tk == ')' || tk == ']' || tk == ':') return;
  }
}

/* пропустить сбалансированные круглые скобки от текущего токена
 * (списки параметров/размерности в неразобранных деклараторах) */
static void c4_skip_parens(void)
{
    if (tk != '(') return;
    next();
    int dep = 1;
    while (dep > 0 && tk) {
        if (tk == '(') dep++;
        else if (tk == ')') dep--;
        next();
    }
}

/* переменная-указатель на функцию? (вызов op(x) идёт через postfix JSRI) */
static int id_is_fptr_var(int *d)
{
    return d && (d[Class] == Loc || d[Class] == Glo) && (d[Type] & FPTR);
}

/* Косвенный вызов (3.3). В a к моменту C4_ICALL — адрес функции, но
 * вычисление аргументов ЗАТИРАЕТ аккумулятор, поэтому цель пушится на
 * стек ПЕРВОЙ: [target][arg1]..[argN], затем JSRI (операнд = ЧИСЛО
 * ЯЧЕЕК аргументов — double-аргумент занимает 2) берёт цель с глубины
 * N. ADJ N+1 снимает аргументы вместе со слотом цели.
 * Возвращаемый тип — база funcptr (RET+PTR|FPTR - PTR); для
 * double-функции после вызова — FRD. */
#define C4_ICALL() do { \
    int nic_ = 0; \
    int fty_ = ty;   /* тип funcptr ДО аргументов — ty затрёт последний арг */ \
    *++e = PSH;                       /* цель — под аргументами */ \
    next();   /* '(' */ \
    while (tk != ')') { expr(Assign); \
        if (IS_REAL_VAL(ty)) { nic_ += 2; }   /* double — уже на стеке */ \
        else { *++e = PSH; nic_ += 1; } \
        if (tk == Comma) next(); } \
    next(); \
    *++e = JSRI; *++e = nic_; \
    *++e = ADJ; *++e = nic_ + 1; \
    ty = (TY_CLEAN(fty_) - PTR) | (fty_ & UNSIGNED); \
    if (IS_REAL_VAL(ty)) *++e = FRD; \
} while (0)

void expr(int lev)
{
  int t, *d;

  if (!tk) { c4_err(line, "unexpected eof in expression"); }
  else if (tk == Inc || tk == Dec) {
    /* ПРЕФИКСНЫЕ ++x / --x (новое): загрузить lvalue, +/- 1, сохранить,
     * результат — НОВОЕ значение (как в C). Для указателей шаг — размер
     * элемента (та же формула, что у постфиксной формы).
     * float/double: [addr][FLD*] → [addr][PSH][FLD*];
     * FLD1; FADD/FSUB; FST* — результат (новое значение) на стеке. */
    int op = tk;
    next(); expr(Inc);
    if ((ty & C4_REAL) && !IS_PTR_T(ty)) {
      if (*e == FLD || *e == FLDF) { int lop = *e; *e = PSH; *++e = lop; }
      else { printf("%d: bad lvalue in prefix %s\n", line, op == Inc ? "++" : "--"); exit(-1); }
      *++e = FLD1;
      *++e = (op == Inc) ? FADD : FSUB;
      *++e = C4_STORE_OP(ty);
    } else {
    if (*e == LC) { *e = PSH; *++e = LC; }
    else if (*e == LI) { *e = PSH; *++e = LI; }
    else if (*e == LS || *e == ULS) { int lop = *e; *e = PSH; *++e = lop; }
    else { printf("%d: bad lvalue in prefix %s\n", line, op == Inc ? "++" : "--"); exit(-1); }
    int stp = IS_STVAL(ty) ? 1 : (IS_PTR_T(ty) && !(ty & (ARR | ARR2))) ? c4_ptr_step(ty) : 1;
    *++e = PSH; *++e = IMM; *++e = stp;
    *++e = (op == Inc) ? ADD : SUB;
    *++e = C4_STORE_OP(ty);
    ty = (ty == CHAR) ? CHAR : (ty == SHORT ? SHORT : INT);
    }
  }
  else if (tk == Num) {
    if (c4_num_dbl) {
      c4_emit_dlit(dval);
      ty = INT | ((c4_num_dbl == 1) ? FLT_F : DBL_F);
    } else { *++e = IMM; *++e = ival; ty = INT; }
    next();
  }
  else if (tk == '"') {
    *++e = IMM; *++e = ival;
    /* метка: этот IMM-операнд — адрес строки в сегменте данных */
    if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS)
        c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le);
    next();
    while (tk == '"') next();   /* смежные литералы: символы дописываются в data подряд (конкатенация) */
    /* NUL-терминатор обязателен: при длине литерала, кратной 4, пул
     * выравнивается вплотную и терминатора не было бы вовсе —
     * printf("%s", "abcd") печатал мусор до конца пула. Один терминатор
     * на ВСЮ последовательность смежных литералов */
    *data++ = 0;
    data = (char *)((int)((unsigned long)data + sizeof(int)) & -sizeof(int)); ty = PTR;
  }
  else if (tk == Sizeof) {
    next();
    int has_paren = (tk == '(');
    if (has_paren) next();
    /* сохранить in-flight контекст массива — вложенные выражения его затрут */
    int save_row1 = c4_row1, save_arsz = c4_arr_elems;
    c4_row1 = 0; c4_arr_elems = 0; c4_subarr_bytes = 0;
    /* тип? (int/char/short/unsigned/void/enum/struct/typedef + указатели) */
    int b = c4_base_type();
    if (b >= 0) {
      ty = b;
      while (tk == Mul) { next(); ty = ty + PTR; }
      while (IS_QUAL(tk)) next();
      if (has_paren) { if (tk == ')') next(); else { c4_err(line, "close paren expected in sizeof"); } }
      *++e = IMM; *++e = c4_sizeof_ty(ty);
      ty = INT;
    } else {
      /* 1.1: sizeof(имя_массива) — размер ВСЕГО массива (ArrSz x элемент).
       * Распознаём до общего разбора выражения, пока распад не съел тип. */
      int *arr0 = 0;
      if (tk == Id && (id[Class] == Glo || id[Class] == Loc) &&
          (id[Type] & (ARR | ARR2)) &&
          (c4_raw_peek(')') || c4_raw_peek(';') || c4_raw_peek(',')))
        arr0 = id;
      /* sizeof("строка") — длина + NUL (C89). Строка УЖЕ в data (лексер
       * записал при разборе expr): считаем по факту в data — это честно
       * обрабатывает экранированные кавычки и смежные литералы. */
      int is_strlit = (tk == '"');
      int *save_e = e;
      int save_n_imm = c4_n_imm_data_cells;
      int save_n_jsr = c4_n_jsr_fixups;
      char *save_data = data;
      expr(has_paren ? Comma : Inc);
      int sz;
      if (c4_subarr_bytes) {
        sz = c4_subarr_bytes; c4_subarr_bytes = 0;   /* m[i] в полёте */
      } else if (arr0) {
        sz = arr0[ArrSz] * c4_esz(arr0[Type] & ~(ARR | ARR2));
      } else if (is_strlit && e == save_e + 2 && save_e[1] == IMM &&
                 c4_n_imm_data_cells == save_n_imm + 1) {
        /* длина строки из data (лексер уже записал) + NUL */
        const char *sc_ = (const char *)(unsigned long)save_e[2];
        sz = 0;
        while (sc_[sz]) sz++;
        sz += 1;
      } else if (ty & (ARR | ARR2 | ARR3)) {
        sz = c4_arr_elems * c4_esz(ty & ~(ARR | ARR2 | ARR3));  /* m[i] и подмассивы */
      } else {
        sz = c4_sizeof_ty(ty);
      }
      e = save_e;                       /* отбросить эмитированный код */
      c4_n_imm_data_cells = save_n_imm;
      c4_n_jsr_fixups = save_n_jsr;
      data = save_data;
      c4_row1 = save_row1; c4_arr_elems = save_arsz;
      if (has_paren) { if (tk == ')') next(); else { c4_err(line, "close paren expected in sizeof"); } }
      *++e = IMM; *++e = sz;
      ty = INT;
    }
  }
  else if (tk == Id) {
    d = id; next();
    if (tk == '(' && !(id_is_fptr_var(d))) {
      next();
      t = 0;
      /* конверсия аргументов по прототипу (C89 §6.3.2.2).
       * pty[i] — тип i-го параметра; отсутствие записи = int (K&R). */
      int pty[C4_MAX_FN_ARGS];
      int p_nt = c4_fn_ptypes(d, pty);   /* число ИЗВЕСТНЫХ (именованных) параметров */
      int narg = 0;
      /* variadic (C89 §6.5.2.2, cdecl): аргументы пушатся СПРАВА НАЛЕВО,
       * чтобы первый именованный параметр оказался в bp+2, а vararg'и —
       * выше него (иначе named-параметры статически не найти). Блоки кода
       * аргументов переставляются задом наперёд; Sys-вызовы (printf и др.)
       * НЕ разворачиваются — их VM-обработчики ждут порядок слева направо. */
      int va_call = (d[Class] != Sys) && c4_fn_is_va(d);
      /* Sys-float (fabs/sqrt): опкод работает IN-PLACE [x(2)] → [res(2)]
       * (как все float-опкоды), FRD после него НЕ нужен */
      int sys_real = 0;
      int nblk = 0;
      int bstart[C4_MAX_FN_ARGS], bend[C4_MAX_FN_ARGS];   /* смещения ячеек от le */
      int nj0 = c4_n_jsr_fixups;
      int ni0 = c4_n_imm_text_cells + c4_n_imm_data_cells;
      while (tk != ')') {
        int *as_ = e + 1;   /* начало блока аргумента (для va-разворота) */
        expr(Assign);
        /* C89 §6.3.2.2: конверсия аргумента — ТОЛЬКО по известному
         * прототипу (narg < p_nt); без прототипа и для «...» — как есть */
        int p_real = (p_nt > 0 && narg < p_nt && narg < C4_MAX_FN_ARGS)
                     ? (IS_REAL_VAL(pty[narg]) ? 1 : 0) : -1;
        if (IS_REAL_VAL(ty)) {
          if (p_real == 0) { *++e = FTOI; *++e = PSH; t += 1; }  /* → int-параметр */
          else if (p_real > 0 && d[Class] == Sys) { /* fabs/sqrt: опкод сам снимает арг */ }
          else t += 2;                                           /* double — уже на стеке */
        } else {
          if (p_real > 0) {
            *++e = PSH; *++e = (ty & UNSIGNED) ? UTOF : ITOF;
            if (d[Class] != Sys) t += 2;   /* Sys (fabs/sqrt) сам снимает конвертированное */
          }
          else { *++e = PSH; t += 1; }
        }
        if (nblk < C4_MAX_FN_ARGS) {
          bstart[nblk] = (int)(as_ - le);
          bend[nblk] = (int)(e - le);
          nblk++;
        }
        narg++;
        if (tk == Comma) next();
      }
      next();
      /* cdecl-разворот блоков аргументов (см. va_call выше). Пропускается,
       * если внутри аргументов появились JSR-fixup'ы или адресные метки —
       * их ячейки-привязки перестановка не переживёт (редкий случай). */
      if (va_call && nblk > 1 &&
          c4_n_jsr_fixups == nj0 &&
          c4_n_imm_text_cells + c4_n_imm_data_cells == ni0) {
        int c0_ = bstart[0];
        int total_ = (int)(e - le) - c0_ + 1;
        int ok_ = (total_ > 0 && total_ <= C4_VA_REV_CELLS);
        int k_;
        /* внутри региона не должно быть условных/безусловных переходов
         * (BZ/BNZ/JMP): их цели — АБСОЛЮТНЫЕ адреса ячеек, перестановка
         * их сломает (?: и &&/|| в аргументах — редкий случай, отходим) */
        for (k_ = c0_; ok_ && k_ <= (int)(e - le); ) {
          int op_ = le[k_];
          if (op_ == JMP || op_ == BZ || op_ == BNZ) ok_ = 0;
          k_ += (op_==LEA||op_==IMM||op_==JMP||op_==JSR||op_==BZ||op_==BNZ||
                 op_==ENT||op_==ADJ||op_==JSRI||op_==SCP||op_==FLDI) ? 2 : 1;
        }
        if (ok_) {
          for (k_ = 0; k_ < total_; k_++) c4_va_rev_buf[k_] = le[c0_ + k_];
          int *w_ = le + c0_;
          for (k_ = nblk - 1; k_ >= 0; k_--) {
            int len_ = bend[k_] - bstart[k_] + 1;
            memcpy(w_, c4_va_rev_buf + (bstart[k_] - c0_),
                   (u32)(len_ * (int)sizeof(int)));
            w_ += len_;
          }
        }
      }
      if (d[Class] == Sys) { *++e = d[Val]; sys_real = IS_REAL_VAL(d[Type]); }
      else if (d[Class] == Fun) {
        *++e = JSR; *++e = d[Val];
        /* Вызов по прототипу (Val==0): операнд допатчим после разбора
         * всех определений функций (см. c4_jsr_fixups). */
        if (d[Val] == 0 && c4_n_jsr_fixups < C4_MAX_JSR_FIXUPS) {
          c4_jsr_fixups[c4_n_jsr_fixups].cell = e;
          c4_jsr_fixups[c4_n_jsr_fixups].fid = d;
          c4_jsr_fixups[c4_n_jsr_fixups].va_unaware = !va_call;
          c4_n_jsr_fixups++;
        }
      }
      else { c4_err(line, "bad function call"); }
      if (t) { *++e = ADJ; *++e = t; }
      ty = d[Type];
      /* double-результат — на стек (FRD); для Sys-float (fabs/sqrt) не нужен —
       * опкод сам оставил результат на стеке */
      if (IS_REAL_VAL(ty) && !sys_real) *++e = FRD;
    }
    else if (d[Class] == Num) { *++e = IMM; *++e = d[Val]; ty = INT; }
    else if (d[Class] == Fun) {
      /* имя функции как значение (3.3): p = main; qsort(a, n, 4, cmp);
       * адрес функции в TEXT — метка для позиционно-независимого x86 */
      *++e = IMM; *++e = d[Val];
      c4_imm_text_mark(e);
      ty = (d[Type] + PTR) | FPTR;
    }
    else {
      if (d[Class] == Loc) { *++e = LEA; *++e = loc - d[Val]; }
      else if (d[Class] == Glo) {
          *++e = IMM; *++e = d[Val];
          /* метка: IMM-операнд глобала — адрес в сегменте данных */
          if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS)
              c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le);
      }
      else { c4_err(line, "undefined variable"); }
      ty = d[Type];
      if (ty & (ARR2 | ARR3)) {
        /* 2D/3D-массив: в полёте подмассив (m[i] → int[B][C]);
         * c4_row1 — шаг ТЕКУЩЕГО индекса, c4_row2 — следующего.
         * Без индексирования сразу — распад в указатель на элемент. */
        int base = ty & ~(ARR | ARR2 | ARR3);
        int esz = c4_esz(base);
        c4_row1 = (d[ArrD] * (d[ArrD2] ? d[ArrD2] : 1)) * esz;
        c4_row2 = d[ArrD2] ? d[ArrD2] * esz : esz;
        c4_arr_elems = d[ArrD] * (d[ArrD2] ? d[ArrD2] : 1);
        if (tk != Brak) {
          /* распад 2D/3D-массива целиком: sizeof((m)) = ArrSz*esz */
          c4_subarr_bytes = d[ArrSz] * esz;
          c4_arr_elems = 0;
          ty = (ty & ~(ARR | ARR2 | ARR3)) + PTR;
        }
      } else if (ty & ARR) {
        /* Массив 1D: IMM/LEA уже даёт адрес. Распад: ARR|INT → int*,
         * ARR|CHAR → char*, ARR|SHORT → short* */
        ty = (ty & ~ARR) + PTR;
      } else if (IS_STVAL(ty)) {
        /* struct-ЗНАЧЕНИЕ: адрес уже в a, БЕЗ загрузки (3.1);
         * поле/индекс добавит смещение, загрузку сделает последний доступ */
      } else {
        *++e = C4_LOAD_OP(ty);
      }
      /* op(x) — вызов через funcptr-переменную (3.3): токен '(' (40)
       * ниже приоритетов postfix-цикла, поэтому вызов — здесь */
      if (tk == '(' && (ty & FPTR)) { C4_ICALL(); }
    }
  }
  else if (tk == '(') {
    next();
    while (IS_QUAL(tk)) next();       /* (const char *)p */
    {
      int b = c4_base_type();
      if (b >= 0) {
        t = b;
        while (tk == Mul) { next(); t = t + PTR; }
        while (IS_QUAL(tk)) next();   /* char * const */
        if (tk == ')') next(); else { c4_err(line, "bad cast"); }
        expr(Inc);
        /* преобразования при касте (C89 §6.3.4):
         * int→double (PSH;ITOF/UTOF), double→int (FTOI, усечение),
         * (void)d — сброс double со стека. */
        if (IS_REAL_VAL(t)) {
          if (!IS_REAL_VAL(ty)) { *++e = PSH; *++e = (ty & UNSIGNED) ? UTOF : ITOF; }
          ty = t;
        } else if (t == VOID) {
          if (IS_REAL_VAL(ty)) { *++e = FDROP; }
          ty = VOID;
        } else if (IS_REAL_VAL(ty)) {
          *++e = FTOI;
          ty = t;
        } else ty = t;
      }
      else {
        expr(Comma);   /* (a, b) — оператор «запятая» допустим и в скобках */
        if (tk == ')') next(); else { c4_err(line, "close paren expected"); }
        /* (f)(x) / ((*f))(x) — функция в скобках и вызов (3.3) */
        if ((ty & FPTR) && tk == '(') { C4_ICALL(); }
      }
    }
  }
  else if (tk == Mul) {
    next(); expr(Inc);
    if (ty & FPTR) {
      /* *fp — обозначение функции (3.3): без загрузки, тип сохраняется;
       * (*fp)(x) — сразу косвенный вызов */
      if (tk == '(') { C4_ICALL(); }
    }
    else if (IS_PTR_T(ty)) {
      ty = (TY_CLEAN(ty) - PTR) | (ty & UNSIGNED);
      if (IS_STVAL(ty)) {
        /* *p где p — struct*: результат — struct-значение (адрес в a),
         * БЕЗ загрузки (3.1) */
      } else {
        *++e = C4_LOAD_OP(ty);
      }
    }
    else { c4_err(line, "bad dereference"); }
  }
  else if (tk == And) {
    next(); expr(Inc);
    /* ВНИМАНИЕ: после загрузок e стоит на опкоде, после IMM/LEA — на
     * ОПЕРАНДЕ (опкод в e[-1]). Проверки учитывают обе формы.
     * float/double загружается FLD/FLDF — убрать и его. */
    if (*e == LC || *e == LI || *e == LS || *e == ULS || *e == FLD || *e == FLDF) --e;
    else if (*e == ADD && e[-1] == IMM) e -= 2;   /* &s.f, &p->f: [..., IMM off, ADD] */
    else if (*e == ADD && e[-1] == MUL && e[-3] == IMM && e[-4] == PSH)
      e -= 4;                                     /* &a[i]: [PSH,IMM k,MUL,ADD] */
    else if (e[-1] == IMM || e[-1] == LEA) {
      /* &глобала/struct/массива: адрес уже в a ([IMM val] / [LEA off]) */
    }
    else { c4_err(line, "bad address-of"); }
    ty = ty + PTR;
  }
  else if (tk == '!') {
    next(); expr(Inc);
    if (IS_REAL_VAL(ty)) { *++e = FLD0; *++e = FEQ; }   /* !d — сравнение с 0.0 */
    else { *++e = PSH; *++e = IMM; *++e = 0; *++e = EQ; }
    ty = INT;
  }
  else if (tk == '~') {
    next(); expr(Inc);
    if (IS_REAL_VAL(ty)) { c4_err(line, "'~' on float/double"); }
    *++e = PSH; *++e = IMM; *++e = -1; *++e = XOR; ty = INT;
  }
  else if (tk == Add) { next(); expr(Inc); }   /* +d: тип операнда сохраняется */
  else if (tk == Sub) {
    next();
    if (tk == Num && c4_num_dbl) {
      /* -1.5 — отрицательный вещественный литерал */
      int dbl_ = c4_num_dbl;
      dval = -dval;
      next();
      c4_emit_dlit(dval);
      ty = INT | ((dbl_ == 1) ? FLT_F : DBL_F);
    }
    else if (tk == Num) { *++e = IMM; *++e = -ival; next(); ty = INT; }
    else {
      expr(Inc);
      if (IS_REAL_VAL(ty)) { *++e = FNEG; }                    /* -d */
      else { *++e = PSH; *++e = IMM; *++e = -1; *++e = MUL; }  /* -i */
      if (!IS_REAL_VAL(ty)) ty = INT;
    }
  }
  else if (tk == Inc || tk == Dec) {
    t = tk; next(); expr(Inc);
    if (*e == LC) { *e = PSH; *++e = LC; }
    else if (*e == LI) { *e = PSH; *++e = LI; }
    else { c4_err(line, "bad lvalue in pre-increment"); }
    *++e = PSH;
    *++e = IMM; *++e = IS_IPTR_T(ty) ? sizeof(int) : sizeof(char);
    *++e = (t == Inc) ? ADD : SUB;
    *++e = (ty == CHAR) ? SC : SI;
  }
  else { printf("%d: bad expression near: [%.40s]\n", line, p); exit(-1); }

  while (tk >= lev) { // "precedence climbing" or "Top Down Operator Precedence" method
    t = ty;
    if (tk == Comma) {
      /* Оператор «запятая»: левый операнд уже вычислен (в a или на стеке
       * для double — тогда сбрасываем его FDROP'ом), вычисляем правый. */
      if (IS_REAL_VAL(ty)) { *++e = FDROP; ty = INT; }
      next();
      expr(Assign);
    }
    else if (tk == Assign) {
      next();
      if (IS_STVAL(t)) {
        /* (C89 §6.3.2.3): struct-присваивание — SCP-копия.
         * Адрес lvalue УЖЕ в a (структура не загружается): [LEA off]
         * (локал), [IMM addr] (глобал), [..., IMM off, ADD] (поле/элемент),
         * [LI] (*p — загрузка УКАЗАТЕЛЯ = адрес struct). Пушим dst ДО
         * вычисления правой части: SCP снимает со стека src, затем dst. */
        if (e[-1] == LEA || e[-1] == IMM || *e == ADD || *e == LI) *++e = PSH;
        else { c4_err(line, "bad lvalue in assignment"); }
      }
      else if (*e == LC || *e == LI || *e == LS || *e == ULS || *e == FLD || *e == FLDF) *e = PSH;
      else { c4_err(line, "bad lvalue in assignment"); }
      expr(Assign);
      if (IS_STVAL(t)) {
        /* (C89 §6.3.2.3): присваивание структур — почленная копия */
        int szs = c4_tag_size(C4_TAG(TY_CLEAN(t)));
        *++e = PSH;                       /* src (адрес в a) */
        *++e = SCP; *++e = szs;
      } else {
        c4_conv_store(t);                 /* int↔double при необходимости */
        *++e = C4_STORE_OP(t);
      }
      ty = t;
    }
    else if (tk >= AddAssign && tk <= ShrAssign) {
      /* Составные присваивания: x += y; p -= 2; x <<= 3; u >>= 1; ...
       * Для unsigned (1.3): /= %= → UDIV/UMOD.
       * float/double: += -= *= /= → FADD/FSUB/FMUL/FDIV;
       * битовые/сдвиги/остаток на real — ошибка. */
      int op;
      switch (tk) {
        case AddAssign: op = IS_REAL_VAL(t) ? FADD : ADD; break;
        case SubAssign: op = IS_REAL_VAL(t) ? FSUB : SUB; break;
        case MulAssign: op = IS_REAL_VAL(t) ? FMUL : MUL; break;
        case DivAssign: op = IS_REAL_VAL(t) ? FDIV : (t & UNSIGNED) ? UDIV : DIV; break;
        case ModAssign: op = (t & UNSIGNED) ? UMOD : MOD; break;
        case AndAssign: op = AND; break;
        case OrAssign:  op = OR;  break;
        case XorAssign: op = XOR; break;
        case ShlAssign: op = SHL; break;
        default:        op = (t & UNSIGNED) ? USHR : SHR; break;
      }
      if (IS_REAL_VAL(t) &&
          (tk == ModAssign || tk == AndAssign || tk == OrAssign ||
           tk == XorAssign || tk == ShlAssign || tk == ShrAssign)) {
        c4_err(line, "invalid operands to compound assignment on float/double");
      }
      if (*e != LC && *e != LI && *e != LS && *e != ULS && *e != FLD && *e != FLDF) { c4_err(line, "bad lvalue in compound assignment"); }
      int lop = *e;
      next();
      *e = PSH;                        /* адрес переменной — на стек */
      *++e = lop;                      /* старое значение -> a / стек (double) */
      if (!IS_REAL_VAL(t)) *++e = PSH;  /* int/указатель: ... и на стек (левый операнд) */
      expr(Assign);
      if (IS_REAL_VAL(t)) {
        /* правый int → double (левый double уже на стеке) */
        if (!IS_REAL_VAL(ty)) { *++e = PSH; *++e = (ty & UNSIGNED) ? UTOF : ITOF; }
      } else {
      /* ptr += n / ptr -= n: правый операнд масштабируется
       * размером элемента (как в обычном + / -) */
      if (IS_REAL_VAL(ty)) { *++e = FTOI; ty = INT; }   /* int += double */
      if ((op == ADD || op == SUB) && IS_PTR_T(t) && !(t & (ARR | ARR2))) {
        *++e = PSH; *++e = IMM;
        *++e = c4_ptr_step(t);
        *++e = MUL;
      }
      }
      *++e = op;
      *++e = C4_STORE_OP(t);
      ty = t;
    }
    else if (tk == Cond) {
      c4_fcond();                      /* условие может быть double */
      next();
      *++e = BZ; d = ++e;
      expr(Assign);
      if (tk == ':') next(); else { c4_err(line, "conditional missing colon"); }
      *d = (int)(e + 3); *++e = JMP; d = ++e;
      expr(Cond);
      *d = (int)(e + 1);
    }
    else if (tk == Lor) { c4_fcond(); next(); *++e = BNZ; d = ++e; expr(Lan); c4_fcond(); ty = INT; }
    else if (tk == Lan) { c4_fcond(); next(); *++e = BZ;  d = ++e; expr(Or);  c4_fcond(); ty = INT; }
    else if (tk == Or)  { next(); *++e = PSH; expr(Xor);
        if ((t | ty) & C4_REAL) { c4_err(line, "invalid operands to '|'"); }
        *++e = OR;  ty = INT; }
    else if (tk == Xor) { next(); *++e = PSH; expr(And);
        if ((t | ty) & C4_REAL) { c4_err(line, "invalid operands to '^'"); }
        *++e = XOR; ty = INT; }
    else if (tk == And) { next(); *++e = PSH; expr(Eq);
        if ((t | ty) & C4_REAL) { c4_err(line, "invalid operands to '&'"); }
        *++e = AND; ty = INT; }
    else if (tk == Eq)  { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Lt);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FEQ; } else *++e = EQ;  ty = INT; }
    else if (tk == Ne)  { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Lt);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FNE; } else *++e = NE;  ty = INT; }
    else if (tk == Lt)  { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Shl);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FLT; }
        else { *++e = ((t | ty) & UNSIGNED) ? ULT : LT; }
        ty = INT; }
    else if (tk == Gt)  { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Shl);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FGT; }
        else { *++e = ((t | ty) & UNSIGNED) ? UGT : GT; }
        ty = INT; }
    else if (tk == Le)  { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Shl);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FLE; }
        else { *++e = ((t | ty) & UNSIGNED) ? ULE : LE; }
        ty = INT; }
    else if (tk == Ge)  { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Shl);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FGE; }
        else { *++e = ((t | ty) & UNSIGNED) ? UGE : GE; }
        ty = INT; }
    else if (tk == Shl) { next(); *++e = PSH; expr(Add);
        if ((t | ty) & C4_REAL) { c4_err(line, "invalid operands to '<<'"); }
        *++e = SHL; ty = INT; }
    else if (tk == Shr) { next(); *++e = PSH; expr(Add);
        if ((t | ty) & C4_REAL) { c4_err(line, "invalid operands to '>>'"); }
        *++e = (t & UNSIGNED) ? USHR : SHR; ty = INT; }
    else if (tk == Add) {
      next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Mul);
      if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) {
        c4_mix_real(t); *++e = FADD; ty = IS_REAL_VAL(t) ? t : ty;
      } else {
      /* масштаб правого операнда = размер элемента (short* шагает по 2,
       * struct* — по размеру структуры) */
      if (IS_PTR_T(t) && !(t & (ARR | ARR2))) {
          *++e = PSH; *++e = IMM;
          *++e = c4_ptr_step(t);
          *++e = MUL;
      }
      *++e = ADD;
      ty = t;
      }
    }
    else if (tk == Sub) {
      next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Mul);
      if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) {
        c4_mix_real(t); *++e = FSUB; ty = IS_REAL_VAL(t) ? t : ty;
      } else {
      if ((t & ~UNSIGNED) == (ty & ~UNSIGNED) && IS_PTR_T(t) && !(t & (ARR | ARR2))) {
          /* ptr - ptr: разность в элементах */
          *++e = SUB; *++e = PSH; *++e = IMM;
          *++e = c4_ptr_step(t);
          *++e = DIV; ty = INT;
      }
      else {
          if (IS_PTR_T(t) && !(t & (ARR | ARR2))) {
              /* ptr - int: масштабируем правый */
              *++e = PSH; *++e = IMM;
              *++e = c4_ptr_step(t);
              *++e = MUL;
          }
          *++e = SUB;
          ty = t;
      }
      }
    }
    else if (tk == Mul) { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Inc);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FMUL; ty = IS_REAL_VAL(t) ? t : ty; }
        else { *++e = MUL; ty = INT; } }
    else if (tk == Div) { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Inc);
        if (IS_REAL_VAL(t) || IS_REAL_VAL(ty)) { c4_mix_real(t); *++e = FDIV; ty = IS_REAL_VAL(t) ? t : ty; }
        else { *++e = (t | ty) & UNSIGNED ? UDIV : DIV; ty = INT; } }
    else if (tk == Mod) { next(); if (!IS_REAL_VAL(t)) *++e = PSH; expr(Inc);
        if ((t | ty) & C4_REAL) { printf("%d: invalid operands to '%%'\n", line); exit(-1); }
        *++e = (t | ty) & UNSIGNED ? UMOD : MOD; ty = INT; }
    else if (tk == Inc || tk == Dec) {
      /* Постфиксные ++/-- (C89 §6.5.2.4): результат — СТАРОЕ значение.
       * real — старое на стеке (FSTK); int/short/char — коррекция a после
       * записи: a = new ± step (как в оригинальном c4). */
      int op = tk;
      if ((ty & C4_REAL) && !IS_PTR_T(ty)) {
        if (*e == FLD || *e == FLDF) { int lop = *e; *e = PSH; *++e = lop; }
        else { c4_err(line, "bad lvalue in post-increment"); }
        /* [addr][old]; FDUP; FLD1; FADD; FSTK → старое значение на стеке
         * (FST тут нельзя: адрес погребён под old — FSTK снимает new и
         * пишет по адресу на глубине 3, результат — old) */
        *++e = FDUP;
        *++e = FLD1;
        *++e = (op == Inc) ? FADD : FSUB;
        *++e = ((ty & FLT_F) && !IS_PTR_T(ty)) ? FSTKF : FSTK;
        next();
        continue;   /* ty не меняется */
      }
      if (*e == LC) { *e = PSH; *++e = LC; }
      else if (*e == LI) { *e = PSH; *++e = LI; }
      else if (*e == LS || *e == ULS) { int lop = *e; *e = PSH; *++e = lop; }
      else { c4_err(line, "bad lvalue in post-increment"); }
      int stp = IS_STVAL(ty) ? 1 : (IS_PTR_T(ty) && !(ty & (ARR | ARR2))) ? c4_ptr_step(ty) : 1;
      *++e = PSH; *++e = IMM; *++e = stp;
      *++e = (op == Inc) ? ADD : SUB;
      *++e = C4_STORE_OP(ty);
      /* a = new; вернуть СТАРОЕ: [PSH new][IMM step][SUB/ADD] → a = old */
      *++e = PSH; *++e = IMM; *++e = stp;
      *++e = (op == Inc) ? SUB : ADD;
      next();
    }
    else if (tk == Brak) {
      next(); *++e = PSH; expr(Assign);
      if (tk == ']') next(); else { c4_err(line, "close bracket expected"); }
      if (t & ARR3) {
        /* 3D, первый индекс: шаг c4_row1; остаётся 2D-подмассив */
        *++e = PSH; *++e = IMM; *++e = c4_row1; *++e = MUL; *++e = ADD;
        int base = t & ~(ARR | ARR2 | ARR3);
        ty = base | ARR | ARR2 | (t & UNSIGNED);
        c4_row1 = c4_row2;                /* шаг следующего (второго) индекса */
        c4_row2 = c4_esz(base);
      } else if (t & ARR2) {
        /* 2D, первый индекс: шаг — c4_row1 байт (нужен от Id/поля);
         * результат — подмассив в полёте (без загрузки) */
        *++e = PSH; *++e = IMM; *++e = c4_row1; *++e = MUL; *++e = ADD;
        int base = t & ~(ARR | ARR2 | ARR3);
        c4_arr_elems = c4_row1 / c4_esz(base);  /* остаток уровня: m[i] = int[B] */
        ty = base | ARR | (t & UNSIGNED);
        c4_row1 = c4_row2;                /* следующий индекс шагает по элементу */
        c4_row2 = c4_esz(base);
      } else if (t & ARR) {
        /* последний уровень массива: шаг esz + ЗАГРУЗКА элемента */
        int base = t & ~(ARR | ARR2);
        int esz = c4_esz(base);
        if (esz == 1) { *++e = ADD; }
        else { *++e = PSH; *++e = IMM; *++e = esz; *++e = MUL; *++e = ADD; }
        ty = base | (t & UNSIGNED);
        if (IS_STVAL(ty)) { /* элемент — struct: адрес без загрузки */ }
        else { *++e = C4_LOAD_OP(ty); c4_arr_elems = 1; }
      } else if (IS_PTR_T(t)) {
        /* FPTR сохраняется: tab[0] у массива funcptr остаётся funcptr'ом */
        int pt = (TY_CLEAN(t) - PTR) | (t & (UNSIGNED | FPTR));
        int esz = c4_ptr_step(t);
        if (esz == 1 && !IS_STVAL(pt)) { *++e = ADD; }
        else { *++e = PSH; *++e = IMM; *++e = esz; *++e = MUL; *++e = ADD; }
        ty = pt;
        if (IS_STVAL(pt)) { /* массив структур: адрес элемента без загрузки */ }
        else { *++e = C4_LOAD_OP(ty); }
      }
      else { c4_err(line, "can't index subptr"); }
      /* in-flight массив в конце индексирования — распад в указатель:
       * m[i] как аргумент/операнд дальше работает как указатель.
       * Перед распадом запоминаем размер подмассива (sizeof(m[i]), 1.1) */
      if ((ty & (ARR | ARR2 | ARR3)) && tk != Brak) {
        c4_subarr_bytes = c4_arr_elems * c4_esz(ty & ~(ARR | ARR2 | ARR3));
        c4_arr_elems = 0;
        ty = ((ty & ~(ARR | ARR2 | ARR3)) + PTR) | (ty & UNSIGNED);
      }
      /* tab[1](x) — вызов funcptr после индексации (3.3) */
      if (tk == '(' && (ty & FPTR)) { C4_ICALL(); }
    }
    else if (tk == Dot || tk == Arrow) {
      /* 3.1: доступ к полю. s.f — s: struct-значение (a = адрес);
       * p->f — p: struct* (a = значение указателя = адрес struct). */
      int arw = (tk == Arrow);
      next();
      int v = TY_CLEAN(t);
      int ok = arw ? ((v & STRUCT) && (v & 0xFFC) != STRUCT)
                   : (IS_STVAL(t) && !(t & (ARR | ARR2)));
      if (!ok) {
        printf("%d: '%s' on non-struct\n", line, arw ? "->" : "."); exit(-1);
      }
      int tg = C4_TAG(v);
      if (tk != Id) { printf("%d: field name expected after '%s'\n", line, arw ? "->" : "."); exit(-1); }
      int fi = c4_field_find(tg, id);
      if (fi < 0) {
        printf("%d: struct has no field '%s'\n", line,
               (char *)(unsigned long)id[Name]); exit(-1);
      }
      next();
      *++e = PSH; *++e = IMM; *++e = c4_tag_foff[tg][fi]; *++e = ADD;
      ty = c4_tag_ftype[tg][fi];
      if (ty & ARR2) {
        /* 2D-поле невозможно (разбор полей — одно измерение); на всякий
         * случай — тот же код, что для 1D, без корректного шага */
        c4_row1 = c4_esz(c4_tag_fbase[tg][fi]);
        c4_arr_elems = c4_tag_farr[tg][fi];
      } else if (ty & ARR) {
        c4_arr_elems = c4_tag_farr[tg][fi];   /* для sizeof(s.f) */
      } else if (IS_STVAL(ty)) {
        /* поле — struct: адрес уже в a, без загрузки */
      } else {
        *++e = C4_LOAD_OP(ty);
      }
      /* s.cb(x) / p->cb(x) — вызов funcptr-поля (3.3) */
      if (tk == '(' && (ty & FPTR)) { C4_ICALL(); }
    }
    else return;
  }
}

/* Break/continue fixup stack: каждый break/continue генерирует JMP с placeholder.
 * После завершения цикла все pending break'и патчатся на адрес выхода,
 * все continue — на адрес следующей итерации. Поддерживает вложенные циклы. */
#define MAX_FIXUPS 64
#define MAX_LOOP_DEPTH 32
static int *break_fixups[MAX_FIXUPS];
static int n_break_fixups;
static int *cont_fixups[MAX_FIXUPS];
static int n_cont_fixups;

static int break_save[MAX_LOOP_DEPTH];
static int cont_save[MAX_LOOP_DEPTH];
static int loop_depth = 0;

static void push_loop(void) {
    if (loop_depth >= MAX_LOOP_DEPTH) return;
    break_save[loop_depth] = n_break_fixups;
    cont_save[loop_depth] = n_cont_fixups;
    loop_depth++;
}
static void patch_continue(int *loop_top) {
    if (loop_depth == 0) return;
    for (int i = cont_save[loop_depth - 1]; i < n_cont_fixups; i++)
        *cont_fixups[i] = (int)loop_top;
    n_cont_fixups = cont_save[loop_depth - 1];
}
static void pop_loop(int *loop_end) {
    if (loop_depth == 0) return;
    loop_depth--;
    for (int i = break_save[loop_depth]; i < n_break_fixups; i++)
        *break_fixups[i] = (int)loop_end;
    n_break_fixups = break_save[loop_depth];
    n_cont_fixups = cont_save[loop_depth];
}

/* таблица меток case ТЕКУЩЕГО switch — обнаружение дубликатов и
 * пересекающихся диапазонов. По C89 §6.8.4.2 десугаринг даёт приоритет
 * ПЕРВОЙ метке — вторая никогда не срабатывает: предупреждаем
 * (нефатально, поведение не меняем). Вложенные switch — стек базовых
 * индексов, как break_save/loop_depth */
#define C4_MAX_SW_CASES 256
static struct { int lo, hi; } c4_sw_cases[C4_MAX_SW_CASES];
static int c4_n_sw_cases = 0;
static int c4_sw_case_base[MAX_LOOP_DEPTH];
static int c4_sw_depth = 0;
static int c4_sw_case_ovf = 0;   /* переполнение таблицы — предупредить один раз */

/* Выход из switch: патчим ТОЛЬКО break'и. continue внутри switch
 * относится к объёмлющему циклу — их фикспейсы остаются висеть
 * до patch_continue внешнего while/for/do (pop_loop их бы обрезал). */
static void pop_switch(int *sw_end) {
    if (loop_depth == 0) return;
    loop_depth--;
    for (int i = break_save[loop_depth]; i < n_break_fixups; i++)
        *break_fixups[i] = (int)sw_end;
    n_break_fixups = break_save[loop_depth];
    /* вернуть таблицу case внешнего switch (вложенность) */
    if (c4_sw_depth > 0) {
        c4_sw_depth--;
        if (c4_sw_depth < MAX_LOOP_DEPTH)
            c4_n_sw_cases = c4_sw_case_base[c4_sw_depth];
    }
}

/* ---------- CONST-FOLD: константные выражения без отдельного парсера ----------
 * c4_fold_const: интерпретирует эмитированный хвост байт-кода [from..to]
 * как стек-машину (IMM кладёт в аккумулятор, PSH дублирует на стек,
 * бинарные операции снимают левый операнд со стека). Если весь хвост —
 * чистые вычисления, возвращается 1 и значение. Любая нагрузка
 * (LEA/LI/LC/SI/JSR/JMP/сисколы...) — «не константа», 0.
 * Работает на уровне байт-кода, поэтому одинаков для VM и native (x86). */
static int c4_fold_const(int *from, int *to, int *out)
{
    int st[32];                        /* стек операндов (выражения мелкие) */
    int sp = 0;
    int ax = 0;                        /* аккумулятор (как в VM c4) */
    for (int *c = from; c <= to; c++) {
        switch (*c) {
        case IMM: ax = *++c; break;
        case PSH: if (sp >= 32) return 0; st[sp++] = ax; break;
        case ADD: if (sp < 1) return 0; ax = st[--sp] + ax; break;
        case SUB: if (sp < 1) return 0; ax = st[--sp] - ax; break;
        case MUL: if (sp < 1) return 0; ax = st[--sp] * ax; break;
        case DIV: if (sp < 1 || !ax) return 0; ax = st[--sp] / ax; break;
        case MOD: if (sp < 1 || !ax) return 0; ax = st[--sp] % ax; break;
        case AND: if (sp < 1) return 0; ax = st[--sp] & ax; break;
        case OR:  if (sp < 1) return 0; ax = st[--sp] | ax; break;
        case XOR: if (sp < 1) return 0; ax = st[--sp] ^ ax; break;
        case SHL: if (sp < 1) return 0; ax = st[--sp] << ax; break;
        case SHR: if (sp < 1) return 0; ax = st[--sp] >> ax; break;
        case USHR: if (sp < 1) return 0; ax = (int)((unsigned)st[--sp] >> ax); break;
        /* unsigned-семантика (1.3) */
        case UDIV: if (sp < 1 || !ax) return 0; ax = (int)((u32)st[--sp] / (u32)ax); break;
        case UMOD: if (sp < 1 || !ax) return 0; ax = (int)((u32)st[--sp] % (u32)ax); break;
        case ULT: if (sp < 1) return 0; ax = ((u32)st[--sp] <  (u32)ax); break;
        case UGT: if (sp < 1) return 0; ax = ((u32)st[--sp] >  (u32)ax); break;
        case ULE: if (sp < 1) return 0; ax = ((u32)st[--sp] <= (u32)ax); break;
        case UGE: if (sp < 1) return 0; ax = ((u32)st[--sp] >= (u32)ax); break;
        case EQ: if (sp < 1) return 0; ax = (st[--sp] == ax); break;
        case NE: if (sp < 1) return 0; ax = (st[--sp] != ax); break;
        case LT: if (sp < 1) return 0; ax = (st[--sp] <  ax); break;
        case GT: if (sp < 1) return 0; ax = (st[--sp] >  ax); break;
        case LE: if (sp < 1) return 0; ax = (st[--sp] <= ax); break;
        case GE: if (sp < 1) return 0; ax = (st[--sp] >= ax); break;
        default: return 0;           /* обращение к памяти/вызов — не константа */
        }
    }
    if (sp) return 0;                /* висячие операнды — не свернулось */
    *out = ax;
    return 1;
}

/* c4_parse_const: разобрать текущее ПОЗИЦИЮ выражение как константу.
 * Выражение парсится обычным expr(Assign) во временный хвост текст-пула,
 * затем сворачивается (c4_fold_const) и ВЕСЬ код откатывается — тот же
 * приём, что в sizeof. Строковые литералы/глобалы дают IMM-метки в
 * сегменте данных — такие «константы» отвергаются проверкой счётчика
 * меток. Возвращает 0 и *out = значение, либо -1 (не константа). */
static int c4_parse_const(int *out)
{
    int *save_e = e;
    int save_imm = c4_n_imm_data_cells;
    int save_jsr = c4_n_jsr_fixups;
    char *save_data = data;
    int save_row1 = c4_row1, save_arsz = c4_arr_elems;
    c4_row1 = 0; c4_arr_elems = 0; c4_subarr_bytes = 0;
    expr(Assign);
    int v = 0;
    int ok = c4_fold_const(save_e + 1, e, &v) &&
             c4_n_imm_data_cells == save_imm;   /* без строк/адресов данных */
    e = save_e;                                 /* откат кода, меток, пула */
    c4_n_imm_data_cells = save_imm;
    c4_n_jsr_fixups = save_jsr;
    data = save_data;
    c4_row1 = save_row1; c4_arr_elems = save_arsz;
    if (!ok) return -1;
    *out = v;
    return 0;
}

void stmt()
{
  int *a, *b;
  int *c, *d;

  if (tk == If) {
    next();
    if (tk == '(') next(); else { c4_err(line, "open paren expected"); }
    expr(Assign);
    c4_fcond();                       /* double-условие → int (C89) */
    if (tk == ')') next(); else { c4_err(line, "close paren expected"); }
    *++e = BZ; b = ++e;
    stmt();
    if (tk == Else) { next(); *++e = JMP; a = ++e; *b = (int)(e + 1); stmt(); *a = (int)(e + 1); }
    else *b = (int)(e + 1);
  }
  else if (tk == While) {
    next();
    a = e + 1;
    if (tk == '(') next(); else { c4_err(line, "open paren expected"); }
    expr(Assign);
    c4_fcond();
    if (tk == ')') next(); else { c4_err(line, "close paren expected"); }
    *++e = BZ; b = ++e;
    push_loop();
    stmt();
    patch_continue(a);
    *++e = JMP; *++e = (int)a;
    *b = (int)(e + 1);
    pop_loop(e + 1);
  }
  else if (tk == For) {
    next();
    if (tk == '(') next(); else { c4_err(line, "open paren expected"); }
    if (tk == ';') next();   /* for (;;) */
    else {
      /* C99: for (int i = 0; ...) — объявление счётчика в заголовке
       * (переменная видна до конца функции — упрощение; c4_parse_decls
       * сам съедает ';') */
      int b = c4_base_type();
      if (b >= 0) c4_parse_decls(b, 1);
      else {
        expr(Comma);             /* for (i = 0, j = 10; ...) */
        if (IS_REAL_VAL(ty)) { *++e = FDROP; ty = INT; }   /* выражение-инструкция */
        if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
      }
    }
    a = e + 1;
    b = 0;
    if (tk != ';') {
      expr(Assign);
      c4_fcond();
      *++e = BZ; b = ++e;
    }
    if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
    if (tk != ')') {
      *++e = JMP; d = ++e;
      c = e + 1;
      expr(Comma);   /* for (...; ...; i++, j--) */
      if (IS_REAL_VAL(ty)) { *++e = FDROP; ty = INT; }
      *++e = JMP; *++e = (int)a;
      *d = (int)(e + 1);
    } else { c = 0; d = 0; }
    if (tk == ')') next(); else { c4_err(line, "close paren expected"); }
    push_loop();
    stmt();
    if (c) { *++e = JMP; *++e = (int)c; }
    else { *++e = JMP; *++e = (int)a; }
    if (b) *b = (int)(e + 1);
    if (c) patch_continue(c); else patch_continue(a);
    pop_loop(e + 1);
  }
  else if (tk == Do) {
    next();
    a = e + 1;
    push_loop();
    stmt();
    patch_continue(a);
    if (tk == While) next(); else { c4_err(line, "while expected"); }
    if (tk == '(') next(); else { c4_err(line, "open paren expected"); }
    expr(Assign);
    c4_fcond();
    if (tk == ')') next(); else { c4_err(line, "close paren expected"); }
    *++e = BNZ; *++e = (int)a;
    if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
    pop_loop(e + 1);
  }
  else if (tk == Break) {
    next();
    /* break вне цикла/switch — ошибка компиляции (C89 §6.8.6.1 — constraint):
     * иначе эмитился бы JMP 0, который никто не патчит (pop_loop патчит
     * только фикапы текущего цикла) — исполнение ушло бы по адресу 0 */
    if (loop_depth == 0) {
      c4_err(line, "'break' outside of loop or switch");
    }
    /* фиксап обязан указывать на ОПЕРАНД JMP, а не на ячейку опкода — иначе
     * патч затирает сам JMP адресом цели, и исполнение уходит в мусор */
    *++e = JMP;
    *++e = 0;
    break_fixups[n_break_fixups++] = e;  /* ячейка операнда — сюда цель */
    if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
  }
  else if (tk == Continue) {
    next();
    /* continue вне цикла — ошибка компиляции (C89 §6.8.6.2); switch циклом
     * НЕ является — внутри switch continue относится к внешнему циклу
     * (при loop_depth==0 — ошибка) */
    if (loop_depth == 0) {
      c4_err(line, "'continue' outside of loop");
    }
    *++e = JMP;
    *++e = 0;
    cont_fixups[n_cont_fixups++] = e;    /* операнд JMP (см. Break) */
    if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
  }
  else if (tk == Switch) {
    /* switch/case/default — десугаринг в цепочку сравнений со скрытыми
     * локальными слотами (однопроходный парсер без AST не может
     * «сначала все сравнения, потом все тела» — тела эмитятся в
     * исходном порядке, поэтому используется флаговая схема):
     *
     *   __sw = выражение;      __m = 0;        __df = 0;
     *   case K:  if (!__m && __sw == K) __m = 1;   if (__m) тело;
     *   default: if (__df) тело;   вход только «с конца»
     *   хвост-стаб: if (__df) конец; __df = 1; goto default-guard;
     *
     * Флаг __m даёт: grouped labels (case 1: case 2:), fallthrough
     * между телами (тело выполняется, если совпал любой случай выше),
     * пропуск уже проверенных case. Хвост-стаб маршрутизирует путь
     * «ничего не совпало» в default (в любой позиции — первой,
     * средней, последней) и защищает от повторного захода (цикл).
     * break патчится на конец switch (как у циклов); continue
     * внутри switch относится к внешнему циклу.
     *
     * Скрытые слоты выделяются из счётчика локалов с мгновенным
     * перпатчиванием операнда ENT (кадр функции растёт). */
    int sw_slot, m_slot, df_slot;
    int *pending = 0;      /* BZ «тело пропущено» → патчим на след. проверку */
    int *pd_pending = 0;    /* ссылка «пропущено» ПЕРЕД default — патчим позже */
    int *dguard = 0;        /* BZ-ячейка guard'а default (!(df||m) → мимо тела) */
    int has_default = 0;
    next();
    if (tk == '(') next(); else { c4_err(line, "open paren expected"); }
    c4_fn_i += 3;
    sw_slot = c4_fn_i - 2; m_slot = c4_fn_i - 1; df_slot = c4_fn_i;
    if (c4_fn_ent) c4_fn_ent[1] = c4_fn_i - c4_fn_loc;  /* кадр растёт */
    /* __sw = выражение (шаблон: LEA; PSH; expr; SI).
     * C89 §6.8.4.2: управляющее выражение switch — только целое. */
    *++e = LEA; *++e = c4_fn_loc - sw_slot; *++e = PSH;
    expr(Assign);
    if (ty & C4_REAL) { c4_err(line, "switch quantity not an integer"); }
    *++e = SI;
    if (tk == ')') next(); else { c4_err(line, "close paren expected"); }
    if (tk == '{') next(); else { c4_err(line, "open brace expected in switch"); }
    /* __m = 0; __df = 0 (ВАЖНО: оба флага обязаны обнуляться при КАЖДОМ
     * входе в switch — слоты кадра переживают итерации циклов (m) и
     * содержат мусор на первом входе (df); без сброса default-ветка
     * ломается со второй итерации / на грязном стеке). */
    *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = PSH; *++e = IMM; *++e = 0; *++e = SI;
    *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = PSH; *++e = IMM; *++e = 0; *++e = SI;
    push_loop();
    /* сохранить таблицу case внешнего switch (вложенность) */
    if (c4_sw_depth < MAX_LOOP_DEPTH)
        c4_sw_case_base[c4_sw_depth] = c4_n_sw_cases;
    c4_sw_depth++;
    while (tk != '}') {
      if (tk == Case) {
        next();
        /* CONST-FOLD: метка case — произвольное константное выражение:
         *   case 1+2:  case (1<<3):  case 'A'+1:  case FLAG|MASK:  case -7:
         * Выражение парсится обычным expr() во временный хвост пула и
         * сворачивается в константу (c4_parse_const; код откатывается).
         * Переменные/вызовы/строки — ошибка компиляции.
         *
         * ДИАПАЗОН (расширение GCC): case 2 ... 6: / case 'a' ... 'z':
         * — после нижней границы ожидаем токен DotDotDot и верхнюю
         * границу (тоже константное выражение). Сравнение __sw == K
         * заменяется на (__sw >= K) && (__sw <= K2) на тех же опкодах
         * (GE/LE/AND), так что VM- и x86-пути работают без изменений
         * бэкенда. Допустима запись и без пробелов (case 2...6:), т.к.
         * лексер узнаёт "..." непосредственно за числом. */
        int K, K2 = 0, is_range = 0;
        if (c4_parse_const(&K)) {
          c4_err(line, "bad case label (integer constant expression expected)");
        }
        if (tk == DotDotDot) {
          next();
          if (c4_parse_const(&K2)) {
            c4_err(line, "bad case range upper bound (integer constant expected)");
          }
          if (K2 < K)
            printf("%d: warning: case range %d ... %d is empty (lower bound greater)\n",
                   line, K, K2);
          is_range = 1;
        }
        if (tk == ':') next(); else { c4_err(line, "colon expected after case"); }
        /* дубликат case / пересечение диапазонов: сравнение с уже накопленными
         * метками ЭТОГО switch (от base до вершины) — метки вложенных switch
         * не смешиваются */
        {
            int base = (c4_sw_depth > 0 && c4_sw_depth <= MAX_LOOP_DEPTH)
                       ? c4_sw_case_base[c4_sw_depth - 1] : 0;
            int dup = 0;
            for (int ci = base; ci < c4_n_sw_cases; ci++) {
                if (K <= c4_sw_cases[ci].hi && K2 >= c4_sw_cases[ci].lo) { dup = 1; break; }
            }
            if (dup) {
                if (is_range)
                    printf("%d: warning: case range %d ... %d overlaps an earlier case label\n",
                           line, K, K2);
                else
                    printf("%d: warning: duplicate case value %d\n", line, K);
            }
            if (c4_n_sw_cases < C4_MAX_SW_CASES) {
                c4_sw_cases[c4_n_sw_cases].lo = K;
                c4_sw_cases[c4_n_sw_cases].hi = is_range ? K2 : K;
                c4_n_sw_cases++;
            } else if (!c4_sw_case_ovf) {
                c4_sw_case_ovf = 1;
                printf("%d: warning: too many case labels, "
                       "duplicate case detection disabled\n", line);
            }
        }
        /* сюда прыгает «тело предыдущего case пропущено» (или отложенная
         * ссылка перед default — она патчится тут же на новую проверку) */
        if (pending) *pending = (int)(e + 1);
        else if (pd_pending) { *pd_pending = (int)(e + 1); pd_pending = 0; }
        /* if (!__m && __sw == K) __m = 1;
         * для диапазона: if (!__m && __sw >= K && __sw <= K2) __m = 1; */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = LI;
        *++e = BNZ; int *bz = ++e;          /* __m != 0 → пропустить сравнение (сохранив флаг) */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = PSH;
        *++e = LEA; *++e = c4_fn_loc - sw_slot; *++e = LI;
        if (!is_range) {
          *++e = PSH; *++e = IMM; *++e = K; *++e = EQ;
        } else {
          /* (__sw >= K): __sw на стеке, IMM K в a, GE берёт левый со стека */
          *++e = PSH; *++e = IMM; *++e = K; *++e = GE;
          *++e = PSH;                        /* сохранить промежуточный итог */
          /* (__sw <= K2): __sw ещё раз из слота, LE — левый со стека */
          *++e = LEA; *++e = c4_fn_loc - sw_slot; *++e = LI;
          *++e = PSH; *++e = IMM; *++e = K2; *++e = LE;
          *++e = AND;                        /* итог: (ge) & (le), оба 0/1 */
        }
        *++e = SI;                          /* __m = результат сравнения */
        *bz = (int)(e + 1);
        /* if (__m) тело — иначе прыжок к следующей проверке */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = LI;
        *++e = BZ; pending = ++e;
      }
      else if (tk == Default) {
        next();
        if (tk == ':') next(); else { c4_err(line, "colon expected after default"); }
        if (has_default) { c4_err(line, "duplicate default label"); }
        /* Входящая ссылка «тело предыдущего case пропущено» патчим НЕ
         * сразу: если default окажется последней секцией, она должна
         * вести на хвост-стаб (путь «ничего не совпало»), а не мимо
         * тела. Откладываем до следующей секции / хвоста. */
        pd_pending = pending; pending = 0;
        /* guard: if (__df || __m) { __m = 1; тело default }
         * — fallthrough с совпавшим case выше (m=1) проваливается в
         * тело (строгая семантика C), поток «ещё проверяем» (0|0)
         * тело пропускает, вход с хвост-стаба (df=1) исполняет тело.
         * Установленный __m=1 даёт fallthrough ИЗ default в тела
         * нижележащих case (строгая семантика C). */
        *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = LI;
        *++e = PSH;
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = LI;
        *++e = OR;                             /* a = __df || __m */
        *++e = BZ; pending = ++e; dguard = e;  /* 0 → пропустить тело */
        /* df-вход (BZ не взят): __m = 1 — тела ниже идут по fallthrough */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = PSH;
        *++e = IMM; *++e = 1; *++e = SI;
        has_default = 1;
      }
      else stmt();
    }
    next();  /* '}' */
    if (has_default) {
      /* нормальный выход (fallthrough из последнего тела) — прыжок
       * за хвост-стаб, чтобы не провалиться в него */
      *++e = JMP; int *jend = ++e;
      /* сюда попадает «ни один case не совпал»: последний pending и
       * отложенная ссылка перед default (если default — последняя
       * секция). Первый заход ставит __df=1 и уходит на guard default
       * (тело исполнится; a=1 от SI — BZ guard'а будет пройден),
       * повторный (df уже 1) — сразу в конец (защита от цикла). */
      if (pending) *pending = (int)(e + 1);
      if (pd_pending) *pd_pending = (int)(e + 1);
      *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = LI;
      *++e = BNZ; int *again = ++e;      /* __df == 1 → конец */
      *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = PSH;
      *++e = IMM; *++e = 1; *++e = SI;   /* __df = 1 */
      *++e = JMP; *++e = (int)(dguard - 1);  /* на BZ-инструкцию guard'а */
      *again = (int)(e + 1);
      *jend = (int)(e + 1);
    } else {
      /* default нет: «ничего не совпало» → конец switch */
      if (pending) *pending = (int)(e + 1);
    }
    pop_switch(e + 1);
  }
  else if (tk == Return) {
    next();
    if (tk != ';') {
      /* return со значением в void-функции — diagnostic по C89 §6.6.6.4
       * (GCC: warning). Значение вычисляется (побочные эффекты сохраняются),
       * результат отбрасывается; не fatal */
      if (c4_fn_ret == VOID)
        c4_warn(line, "return with a value, in function returning void");
      expr(Comma);   /* return a, b; — легальный C */
      /* конверсия по типу функции (C89 §6.6.6.4) */
      if (IS_REAL_VAL(c4_fn_ret)) {
        if (!IS_REAL_VAL(ty)) { *++e = PSH; *++e = (ty & UNSIGNED) ? UTOF : ITOF; }
        *++e = FRET;                     /* double-результат — в c4_dret */
      } else {
        if (IS_REAL_VAL(ty)) *++e = FTOI;   /* double из int-функции — усечение */
        *++e = LEV;
      }
    } else {
      /* bare return в не-void функции — C89 §6.6.6.4 (constraint; GCC:
       * warning): иначе эмитился бы LEV и вызывающий прочитал бы МУСОР из a */
      if (c4_fn_ret != VOID)
        c4_warn(line, "'return' with no value, in function returning non-void");
      /* bare return в double-функции: возвращаем 0.0 (x87-стек чист) */
      if (IS_REAL_VAL(c4_fn_ret)) { *++e = FLD0; *++e = FRET; }
      else *++e = LEV;
    }
    if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
  }
  else if (tk == Goto) {
    /* РАСШИРЕНИЕ 2: goto Label; — переход внутри текущей функции.
     * JMP с нулевым операндом патчится при определении метки
     * (c4_label_define) или сразу, если метка уже определена выше. */
    next();
    if (tk != Id) { c4_err(line, "label name expected after goto"); }
    int *lsym = id;
    next();
    *++e = JMP;
    *++e = 0;
    int *tgt = c4_label_find(lsym);
    if (tgt) *e = (int)(unsigned long)tgt;      /* метка уже выше */
    else if (c4_n_goto_fixups < C4_MAX_GOTO_FIXUPS) {
      c4_goto_fixups[c4_n_goto_fixups].cell = e;
      c4_goto_fixups[c4_n_goto_fixups].fsym = lsym;
      c4_n_goto_fixups++;
    } else { c4_err(line, "too many gotos"); }
    if (tk == ';') next(); else { c4_err(line, "semicolon expected after goto"); }
  }
  else if (IS_QUAL(tk) || tk == Typedef) {
    /* Объявление в глубине блока (расширение C99; в C89 допустимы
     * только в начале блока — их разбирает ветка '{'). Переменная
     * видна до конца функции (упрощённая семантика C99). */
    C4_EAT_QUALS();
    if (tk == Typedef) { c4_parse_typedef(); }
    else {
      int b = c4_base_type();
      if (b < 0) { c4_err(line, "type expected after qualifier"); }
      c4_parse_decls(b, 1);
    }
  }
  else if (tk == Id && c4_at_label()) {
    /* РАСШИРЕНИЕ 2: метка Label: — патчит ждущие goto на (e+1).
     * Различение с выражением «x ? a : b»: peek делаем по сырому
     * тексту сразу после идентификатора. */
    int *lsym = id;
    next();   /* идентификатор */
    next();   /* ':' */
    c4_label_define(lsym);
  }
  else if (tk == '{') {
    next();
    /* C89: объявления в начале блока с собственной областью видимости
     * ({ int t = a; ... }) — при '}' записи символов восстанавливаются */
    int sbase = c4_n_scope;
    for (;;) {
      C4_EAT_QUALS();
      if (tk == Typedef) { c4_parse_typedef(); continue; }
      {
        int b = c4_base_type();
        if (b < 0) break;
        c4_parse_decls(b, 1);
      }
    }
    while (tk != '}') stmt();
    next();
    c4_scope_pop_to(sbase);
  }
  else if (tk == ';') {
    next();
  }
  else {
    /* Объявление в глубине блока (C99-расширение: int x = ...;
     * u32 v = ...;) или оператор-выражение. Токены типов (int/char/
     * unsigned/enum/typedef-имя) не могут начинать выражение, так что
     * различение однозначно. */
    int b = c4_base_type();
    if (b >= 0) {
      c4_parse_decls(b, 1);
    } else {
      expr(Comma);   /* оператор-выражение: допустим оператор «запятая» */
      if (IS_REAL_VAL(ty)) { *++e = FDROP; ty = INT; }   /* double-результат — сброс */
      if (tk == ';') next(); else { c4_err(line, "semicolon expected"); }
    }
  }
}

/* ---------- C89: единый разбор базового типа ---------- */

/* ---------- 3.1: struct/union ----------
 * struct [Tag] { поле; ... } — таблица тегов/полей с естественным
 * выравниванием; union — все поля со смещением 0. Возвращает тип
 * STRUCT | (тег << 12). Неполный тег (без тела) допустим для указателей. */
static int c4_parse_struct(int is_union)
{
    next();                          /* struct / union */
    int tg = -1;
    if (tk == Id) {
        /* после struct/union идентификатор — всегда имя тега
         * (C89); создаём при первом упоминании (неполный тип
         * легален для указателей: struct Node *next;) */
        tg = c4_tag_find(id);
        if (tg < 0) tg = c4_tag_create(id, is_union);
        if (tg < 0) { c4_err(line, "too many struct/union tags"); }
        next();
    }
    if (tk == '{') {
        if (tg < 0) tg = c4_tag_create(0, is_union);   /* анонимный */
        if (tg < 0) { c4_err(line, "too many struct/union tags"); }
        next();
        c4_tag_size_[tg] = 0;
        c4_tag_nf[tg] = 0;
        int ualign = 1;   /* макс. выравнивание полей (для паддинга union) */
        while (tk && tk != '}') {
            while (IS_QUAL(tk)) next();
            int fbt = c4_base_type();       /* рекурсия: вложенные struct */
            if (fbt < 0) {
                c4_err(line, "field type expected in struct");
            }
            for (;;) {
                int ft = fbt;
                while (tk == Mul) { next(); ft = ft + PTR; }
                int is_fp = 0;
                if (tk == '(' && c4_raw_peek('*')) {   /* int (*cb)(int); — поле-funcptr (3.1) */
                    next();
                    while (tk == Mul) next();
                    is_fp = 1;
                    ft = (fbt + PTR) | FPTR;
                }
                while (IS_QUAL(tk)) next();
                if (tk != Id) {
                    c4_err(line, "field name expected");
                }
                int *fid = id;
                next();
                if (is_fp) {   /* закрыть ')(' и список параметров указуемой */
                    if (tk == ')') next(); else {
                        c4_err(line, "')' expected in funcptr field");
                    }
                    c4_skip_parens();
                }
                int farr = 0;
                if (tk == Brak) {
                    next();
                    if (c4_parse_const(&farr) || farr < 0) {
                        c4_err(line, "bad array size in struct field");
                    }
                    if (tk == ']') next(); else {
                        c4_err(line, "']' expected in struct field");
                    }
                    if (farr < 1) farr = 1;
                }
                if (tk == ':') {
                    /* битовые поля не поддержаны: диагностируем сразу по месту (полная
                     * поддержка — большой кусок: упаковка/маскирование при каждой
                     * загрузке/записи) */
                    printf("%d: bit-fields are not supported "
                           "(declare plain fields instead)\n", line);
                    exit(-1);
                }
                /* смещение с естественным выравниванием (union — всегда 0).
                 * Размер поля-массива — esz*farr, НЕ al*farr: arr[i] индексируется
                 * шагом esz (для struct S arr[3] с sizeof(S)=12 выравнивание al=4
                 * дало бы fsz=12 вместо 36 — последующие поля наезжали на массив) */
                int esz_ = c4_esz(ft);
                int al = esz_ > 4 ? 4 : esz_;
                if (al < 1) al = 1;
                if (al > ualign) ualign = al;
                int fsz = farr ? esz_ * farr : esz_;
                int off;
                if (is_union) {
                    off = 0;
                    if (fsz > c4_tag_size_[tg]) c4_tag_size_[tg] = fsz;
                } else {
                    off = (c4_tag_size_[tg] + al - 1) & -al;
                    c4_tag_size_[tg] = off + fsz;
                }
                if (c4_tag_nf[tg] < C4_TAG_FIELDS && c4_nf_total < C4_MAX_FIELDS) {
                    int fi = c4_tag_nf[tg]++;
                    c4_tag_fnamep[tg][fi] = (char *)(unsigned long)fid[Name];
                    c4_tag_fhash[tg][fi] = fid[Hash];
                    c4_tag_ftype[tg][fi] = ft | (farr ? ARR : 0);
                    c4_tag_fbase[tg][fi] = ft;
                    c4_tag_foff[tg][fi] = off;
                    c4_tag_farr[tg][fi] = farr;
                    c4_nf_total++;
                } else {
                    c4_err(line, "too many struct fields");
                }
                if (tk == Comma) { next(); continue; }
                break;
            }
            if (tk == ';') next(); else {
                c4_err(line, "';' expected after struct field");
            }
        }
        next();   /* '}' */
        if (!is_union) c4_tag_size_[tg] = (c4_tag_size_[tg] + 3) & -4;
        else c4_tag_size_[tg] = (c4_tag_size_[tg] + ualign - 1) & -ualign;   /* C89: размер union кратен выравниванию */
        if (c4_tag_size_[tg] == 0) c4_tag_size_[tg] = 4;  /* пустой/неполный */
    } else if (tg < 0) {
        c4_err(line, "bad struct/union declaration");
    }
    return C4_MKSVAL(tg);
}

/* enum [Tag] { A, B = 5, C } — тело; тег пропускается, константы
 * регистрируются как Num (работают в case, размерах массивов и т.д.).
 * Допустимы отрицательные значения и значения-константы. */
static void c4_parse_enum(void)
{
    next();                          /* enum */
    if (tk != '{') next();           /* необязательный тег */
    if (tk != '{') return;           /* enum Tag x; — тип уже INT */
    next();
    int i_ev = 0;
    while (tk != '}') {
        if (tk != Id) { c4_err(line, "bad enum identifier"); }
        int *eid = id;               /* id затирается разбором значения */
        next();
        if (tk == Assign) {
            next();
            /* CONST-FOLD: значение — константное выражение
             * (enum { A = 1<<2, B = A*3 };) через c4_parse_const */
            if (c4_parse_const(&i_ev)) {
                c4_err(line, "bad enum initializer (integer constant expected)");
            }
        }
        /* id[Tk] = Num: лексер вернёт константу как число (case RED:,
         * int arr[SIZE]; ...) — как у #define-констант. */
        eid[Class] = Num; eid[Type] = INT; eid[Val] = i_ev++; eid[Tk] = Num;
        if (tk == Comma) next();
    }
    next();
}

/* Базовый тип начиная с текущего токена. Возвращает тип (CHAR/SHORT/INT/
 * VOID/STRUCT... с флагами) или -1, если токен — не тип (в этом случае
 * НИ ОДИН токен не потребляется). typedef-имя возвращает записанный тип.
 * «Мягкие» формы C89: signed игнорируется, long = int (i386),
 * unsigned long/long unsigned = unsigned int, unsigned char = char,
 * unsigned short = short|UNSIGNED. float/double — флаги
 * FLT_F/DBL_F поверх INT; long double ≡ double (без 80-бит x87). */
static int c4_base_type(void)
{
    int ty_ = -1, un = 0, seen = 0;
    for (;;) {
        if (tk == Char) { ty_ = CHAR; next(); }
        else if (tk == Short) { ty_ = SHORT; next(); }              /* 1.5 */
        else if (tk == Void) { ty_ = VOID; next(); }                /* 1.4 */
        else if (tk == Int || tk == Long) { if (ty_ < 0 || ty_ == VOID) ty_ = INT; next(); }
        else if (tk == Unsigned) { un = 1; next(); }
        else if (tk == Signed) { next(); }
        else if (tk == Float) { ty_ = INT | FLT_F; next(); }
        else if (tk == Double) { ty_ = INT | DBL_F; next(); }
        else if (tk == Enum) { c4_parse_enum(); ty_ = INT; }
        else if (tk == Struct) { ty_ = c4_parse_struct(0); }        /* 3.1 */
        else if (tk == Union) { ty_ = c4_parse_struct(1); }         /* 3.1 */
        else if (tk == TdefName) { ty_ = id[Type]; next(); }  /* typedef-имя */
        else break;
        seen = 1;
    }
    if (!seen) return -1;
    if (ty_ < 0) ty_ = INT;
    if (un && (ty_ == INT || ty_ == CHAR || ty_ == SHORT)) ty_ |= UNSIGNED;
    return ty_;
}

/* typedef int u32, *stringp, (*handler)(int); — регистрирует имена как
 * ТИПЫ (id[Tk] = Typedef, тип в id[Type]). Указатели, struct/union и
 * указатели на функции поддерживаются. Допустим и внутри функций. */
static void c4_parse_typedef(void)
{
    next();                          /* typedef */
    while (IS_QUAL(tk)) next();
    int bt = c4_base_type();
    if (bt < 0) { c4_err(line, "type expected after typedef"); }
    for (;;) {
        int ty_ = bt;
        int is_fp = 0;
        while (tk == Mul) { next(); ty_ = ty_ + PTR; }
        if (tk == '(' && c4_raw_peek('*')) {   /* typedef int (*h)(int); */
            next();
            while (tk == Mul) next();
            is_fp = 1;
            ty_ = (bt + PTR) | FPTR;
        }
        if (tk != Id) { c4_err(line, "bad typedef name"); }
        id[Class] = 0; id[Type] = ty_; id[Tk] = TdefName; id[Val] = 0;
        next();
        if (is_fp) {
            if (tk == ')') next(); else {
                c4_err(line, "')' expected in typedef of function pointer");
            }
            c4_skip_parens();          /* список параметров — пропустить */
        }
        if (tk == Comma) { next(); continue; }
        break;
    }
    if (tk == ';') next(); else { c4_err(line, "';' expected after typedef"); }
}

/* ---------- Эмит инициализатора глобального/static объекта ----------
 * Код записи собирается в отдельный «чанк»-функцию; при запуске boot-код
 * вызывает чанки до main (4.2/1.2 — общий механизм). Строковая
 * инициализация char-массива копируется прямо в сегмент данных вызывающим.
 * glo_id — запись символа (Val = адрес); base_ty — база элемента (без ARR). */
static void c4_emit_glob_init(int *glo_id, int base_ty, int is_arr,
                              int arr_elems)
{
    #define C4_GSTORE_AT(gid, off) do { \
        unsigned long a_ = (unsigned long)(gid)[Val] + (unsigned long)(off); \
        *++e = IMM; *++e = (int)a_; \
        if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS) \
            c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le); \
        *++e = PSH; \
    } while (0)
    #define C4_GSTORE(gid, bty, idx) \
        C4_GSTORE_AT(gid, (unsigned long)(idx) * (unsigned long)c4_esz(bty))

    int *chunk = e + 1;              /* начало чанка (ENT) */
    *++e = ENT; *++e = 0;            /* пролог чанка-функции */
    if (tk == '{') {
      /* список: { e0, e1, ... } */
      next();
      /* скалярная struct со списком {e0, e1, ...} — позиционная инициализация
       * ПО ПОЛЯМ (C89 §6.5.7): поле i_el получает тип/смещение из таблицы
       * тега (c4_tag_ftype/foff); пропущенные поля остаются нулями
       * (сегмент данных обнулён — «initialized as objects with static storage») */
      int is_struct = IS_STVAL(base_ty) && !is_arr;
      int stg = is_struct ? C4_TAG(TY_CLEAN(base_ty)) : -1;
      int st_nf = is_struct ? c4_tag_nf[stg] : 0;
      int i_el = 0;
      while (tk && tk != '}') {
        int fty = base_ty;           /* тип приёмника: base (массив) или поле (struct) */
        if (is_struct) {
          if (i_el >= st_nf) {
            c4_err(line, "too many initializers for struct");
          }
          fty = c4_tag_ftype[stg][i_el];
          if ((fty & ARR) || c4_tag_farr[stg][i_el]) {
            /* { 1, {2,3} } / char name[8] со своим списком — вложенные
             * списки не поддержаны парсером выражений */
            c4_err(line, "array member initializer in struct is not supported");
          }
          if (IS_STVAL(fty) && tk == '{') {
            /* вложенный struct-инициализатор ({...} в поле) не поддержан — явная
             * диагностика вместо невнятной ошибки expr (полная поддержка —
             * рекурсивный emit в подполе) */
            c4_err(line, "nested struct initializer is not supported (assign fields separately)");
          }
          C4_GSTORE_AT(glo_id, c4_tag_foff[stg][i_el]);
        } else {
          if (is_arr && i_el >= arr_elems) {
            c4_err(line, "too many initializers for array");
          }
          if (is_arr && IS_STVAL(base_ty) && tk == '{') {
            /* вложенный struct-инициализатор ({...} в элементе) не поддержан —
             * явная диагностика (причина — см. выше) */
            c4_err(line, "nested struct initializer is not supported (assign fields separately)");
          }
          C4_GSTORE(glo_id, base_ty, i_el);
        }
        expr(Assign);
        if (IS_STVAL(fty)) {
          /* поле/элемент-struct: присваивание копией через SCP
           * (для позиционного поля — из переменной) */
          *++e = PSH; *++e = SCP; *++e = c4_tag_size(C4_TAG(TY_CLEAN(fty)));
        } else {
          c4_conv_store(fty);        /* int↔double при необходимости */
          *++e = C4_STORE_OP(fty);
          if ((fty & C4_REAL) && !IS_PTR_T(fty)) { *++e = FDROP; }
        }
        i_el++;
        if (tk == Comma) next();
      }
      if (tk == '}') next(); else { c4_err(line, "'}' expected in initializer"); }
    } else {
      if (is_arr) {
        c4_err(line, "brace list expected in array initializer");
      }
      C4_GSTORE(glo_id, base_ty, 0);
      expr(Assign);
      if (IS_STVAL(base_ty)) {
        /* (C89): struct S g = other; — копия через SCP */
        *++e = PSH; *++e = SCP; *++e = c4_tag_size(C4_TAG(TY_CLEAN(base_ty)));
      } else {
        c4_conv_store(base_ty);
        *++e = C4_STORE_OP(base_ty);
        if ((base_ty & C4_REAL) && !IS_PTR_T(base_ty)) { *++e = FDROP; }
      }
    }
    *++e = LEV;                      /* эпилог чанка */
    if (c4_n_boot < C4_MAX_BOOT) {
      c4_boot_chunks[c4_n_boot++] = chunk;
    } else {
      c4_err(line, "too many global initializers");
    }
    #undef C4_GSTORE
    #undef C4_GSTORE_AT
}

/* ---------- C89: объявления локальных переменных ----------
 * Общий код для начала функции И начала вложенного блока (и C99-
 * объявлений в глубине блока). Разбирает деклараторы до ';':
 *   int x = 5, *p, a[10], b[] = {1,2}, m[3][4], (*fp)(int);
 * bt    — базовый тип (уже разобран c4_base_type);
 * scope_push — 1: вложенный блок (записи в стек областей видимости);
 *              0: начало функции (дубликаты — ошибка, откат через H*).
 * Слоты выделяются через c4_fn_i (кадр функции растёт, ENT патчится).
 * static-локалы (1.2) размещаются в сегменте данных (c4_decl_static). */
static void c4_parse_decls(int bt, int scope_push)
{
    int st = c4_decl_static;
    c4_decl_static = 0;
    c4_decl_extern = 0;   /* extern значим только для глобалов */
    if (tk == ';') {
        /* «struct S {...};» / «enum E {...};» — определение типа без
         * декларатора (разбор типа уже съел c4_base_type) */
        next();
        if (c4_fn_ent) c4_fn_ent[1] = c4_fn_i - c4_fn_loc;
        return;
    }
    for (;;) {
        int ty_ = bt;
        int is_fp = 0;
        while (tk == Mul) { next(); ty_ = ty_ + PTR; }
        if (tk == '(' && c4_raw_peek('*')) {   /* int (*fp)(int) (3.3) */
            next();
            while (tk == Mul) next();
            is_fp = 1;
            ty_ = (bt + PTR) | FPTR;
        }
        while (IS_QUAL(tk)) next();          /* char * const p */
        if (tk != Id) { printf("%d: bad local declaration (tk=%d)\n", line, tk); exit(-1); }
        if (st) {
            /* ---- static-локал (1.2): объект в сегменте данных ----
             * Класс Glo (как у глобала), запись восстановится по '}'
             * блока / в конце функции (SMark), данные живут всегда. */
            if (scope_push) c4_scope_push(id);
            id[HClass] = id[Class]; id[Class] = Glo; id[SMark] = 1;
            id[HType]  = id[Type];  id[Type] = ty_;
            id[HVal]   = id[Val];
            int *arr_id = id;
            next();
            int dims2 = 0, dims3 = 0, arr_elems = 0;
            if (is_fp) {   /* static int (*fp)(int) = f; */
                if (tk == ')') next(); else {
                    c4_err(line, "')' expected in function pointer declarator");
                }
                c4_skip_parens();
            }
            if (tk == Brak) {
                next();
                if (tk == ']') {
                    const char *sv = p;
                    while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
                    if (*sv == '=') {
                        sv++;
                        while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
                        if (*sv == '{') arr_elems = c4_count_init_list(sv);
                        else if (*sv == '"') arr_elems = c4_count_str_lit(sv);
                    }
                    next();   /* ']' */
                } else if (c4_parse_const(&arr_elems) || arr_elems < 0) {
                    c4_err(line, "bad array size (integer constant expected)");
                }
                if (tk == ']') next();
                if (arr_elems < 1) arr_elems = 1;
                {
                    int dd[2] = {0, 0};
                    int nd = 1;
                    while (tk == Brak && nd <= 2) {
                        next();
                        int dv = 0;
                        if (tk == ']' || c4_parse_const(&dv) || dv < 1) {
                            c4_err(line, "array dimension must be a constant");
                        }
                        if (tk == ']') next();
                        dd[nd - 1] = dv;
                        arr_elems *= dv;
                        nd++;
                    }
                    dims2 = dd[0]; dims3 = dd[1];
                }
                int esz = c4_esz(ty_ & ~(ARR | ARR2 | ARR3));
                data = data + esz * arr_elems;
                arr_id[Val] = (int)(unsigned long)data - esz * arr_elems;
                arr_id[Type] = ty_ | ARR | (dims2 ? ARR2 : 0) | (dims3 ? ARR3 : 0);
                arr_id[ArrSz] = arr_elems;
                arr_id[ArrD] = dims2;
                arr_id[ArrD2] = dims3;
            } else {
                id[Val] = (int)(unsigned long)data;
                data = data + c4_sizeof_ty(ty_);
            }
            if (tk == Assign) {
                next();
                if (arr_elems && (ty_ & ~ARR) == CHAR && tk == '"') {
                    int saddr = ival;
                    while (tk == '"') next();
                    int slen = 0;
                    while (((char *)(unsigned long)saddr)[slen]) slen++;
                    int n = slen + 1;
                    if (n > arr_elems) n = arr_elems;
                    memcpy((char *)(unsigned long)arr_id[Val],
                           (char *)(unsigned long)saddr, n);
                } else {
                    /* чанк В ТЕЛЕ функции: провалиться в него нельзя —
                     * обходим JMP'ом (исполнится один раз через boot) */
                    *++e = JMP; int *jover = ++e;
                    c4_emit_glob_init(arr_id, ty_ & ~(ARR | ARR2),
                                      arr_elems != 0, arr_elems);
                    *jover = (int)(e + 1);
                }
            }
            if (tk == Comma) { next(); continue; }
            break;
        }
        if (!scope_push && id[Class] == Loc) { c4_err(line, "duplicate local definition"); }
        if (scope_push) c4_scope_push(id);   /* откат при '}' блока */
        id[HClass] = id[Class]; id[Class] = Loc;
        id[HType]  = id[Type];  id[Type] = ty_;
        id[HVal]   = id[Val];   id[Val] = ++c4_fn_i;
        /* ВАЖНО: сохраняем указатель на запись, т.к. next() ниже (при
         * разборе [N]) может найти N как #define'Id-константу и
         * переключить id на запись N. */
        int *arr_id = id;
        /* struct-значение занимает несколько слотов кадра (12 байт = 3):
         * база обязана быть НИЖНИМ слотом (LEA loc-Val → минимальный адрес),
         * иначе рост вверх затирает saved-bp/параметры */
        {
            int vsz = c4_sizeof_ty(ty_);
            if (vsz > 4) c4_fn_i += (vsz + 3) / 4 - 1;
            if (vsz > 4) arr_id[Val] = c4_fn_i;
        }
        next();
        int dims2 = 0, dims3 = 0, arr_elems = 0;   /* 0 = не массив */
        if (tk == Brak) {
            next();
            if (tk == ']') {
                /* «[]»: размер выводится из инициализатора = {...} / = "стр" */
                const char *sv = p;
                while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
                if (*sv == '=') {
                    sv++;
                    while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
                    if (*sv == '{') arr_elems = c4_count_init_list(sv);
                    else if (*sv == '"') arr_elems = c4_count_str_lit(sv);
                }
                if (arr_elems < 1) {
                    c4_err(line, "local array size cannot be inferred");
                }
                next();   /* ']' */
            }
            else if (c4_parse_const(&arr_elems) || arr_elems < 0) {
                /* размер — константное выражение (int a[SIZE*2];) через
                 * c4_parse_const; переменные/отрицательные — ошибка */
                c4_err(line, "bad array size (integer constant expected)");
            }
            if (tk == ']') next();   /* закрывающая скобка */
            if (arr_elems < 1) arr_elems = 1;
            {
                int dd[2] = {0, 0};          /* 2-е и 3-е измерения */
                int nd = 1;
                while (tk == Brak && nd <= 2) {   /* [A][B][C] (3.2) */
                    next();
                    int dv = 0;
                    if (tk == ']' || c4_parse_const(&dv) || dv < 1) {
                        c4_err(line, "array dimension must be a constant");
                    }
                    if (tk == ']') next();
                    dd[nd - 1] = dv;
                    arr_elems *= dv;
                    nd++;
                }
                dims2 = dd[0]; dims3 = dd[1];
            }
            int esz = c4_esz(ty_ & ~(ARR | ARR2 | ARR3));
            /* слоты кадра: total*esz байт, округление вверх до ячеек */
            c4_fn_i += (arr_elems * esz + 3) / 4 - 1;
            arr_id[Val] = c4_fn_i;           /* база = НИЖНИЙ слот резервации */
            arr_id[Type] = ty_ | ARR | (dims2 ? ARR2 : 0) | (dims3 ? ARR3 : 0);
            arr_id[ArrSz] = arr_elems;
            arr_id[ArrD] = dims2;
            arr_id[ArrD2] = dims3;
        }
        if (is_fp) {
            /* закрывающая ')' и список параметров указываемой функции */
            if (tk == ')') next(); else {
                c4_err(line, "')' expected in function pointer declarator");
            }
            c4_skip_parens();
        }
        if (tk == Assign) {
            int offset = c4_fn_loc - arr_id[Val];   /* сохранить до смены id */
            next();
            if (arr_elems) {
                /* Инициализатор массива: C89 требует нулевые остатки —
                 * заливаем весь массив через memset-сискол, затем
                 * поэлементные записи. */
                int esz = c4_esz(ty_ & ~(ARR | ARR2));
                *++e = LEA; *++e = offset; *++e = PSH;
                *++e = IMM; *++e = 0; *++e = PSH;
                *++e = IMM; *++e = arr_elems * esz; *++e = PSH;
                *++e = MSET; *++e = ADJ; *++e = 3;
                /* АДРЕС ЭЛЕМЕНТА k: массивы с esz < 4 индексируются
                 * ПОБАЙТОВО (Brak при t==PTR не масштабирует), esz == 4 —
                 * по слотам (4 байта). Поэтому:
                 *   esz 4: LEA (offset + k) — ячейки;
                 *   esz 1/2: LEA offset; PSH; IMM k*esz; ADD — байты. */
                #define C4_LELEM(k_, es_) do { \
                    if ((es_) != 4) { *++e = LEA; *++e = offset; *++e = PSH; *++e = IMM; *++e = (k_) * (es_); *++e = ADD; } \
                    else            { *++e = LEA; *++e = offset + (k_); } \
                    *++e = PSH; \
                } while (0)

                if (tk == '{') {
                    next();
                    int i_el = 0;
                    int elt_ty = ty_ & ~(ARR | ARR2 | ARR3);
                    while (tk && tk != '}') {
                        if (i_el >= arr_elems) {
                            c4_err(line, "too many initializers for array");
                        }
                        if (IS_STVAL(elt_ty) && tk == '{') {
                            /* вложенный struct-инициализатор ({...} в элементе) не поддержан —
                             * явная диагностика (причина — см. выше) */
                            c4_err(line, "nested struct initializer is not supported (assign fields separately)");
                        }
                        C4_LELEM(i_el, esz);
                        expr(Assign);
                        /* элемент-struct — копия через SCP (SI складывал бы в элемент АДРЕС
                         * источника — мусор при чтении полей) */
                        if (IS_STVAL(elt_ty)) {
                            *++e = PSH; *++e = SCP;
                            *++e = c4_tag_size(C4_TAG(TY_CLEAN(elt_ty)));
                        } else {
                            c4_conv_store(elt_ty);            /* int↔double */
                            *++e = C4_STORE_OP(elt_ty);
                            if ((elt_ty & C4_REAL) && !IS_PTR_T(elt_ty)) { *++e = FDROP; }
                        }
                        i_el++;
                        if (tk == Comma) next();
                    }
                    if (tk == '}') next();
                    else { c4_err(line, "'}' expected in initializer"); }
                }
                else if (tk == '"' && (ty_ & ~ARR) == CHAR) {
                    /* char b[8] = "строка"; — строка УЖЕ лексирована
                     * (tk == '"' означает: ival = её адрес в данных) */
                    int saddr = ival;
                    while (tk == '"') next();      /* смежные литералы */
                    int slen = 0;
                    while (((char *)(unsigned long)saddr)[slen]) slen++;
                    int n = slen;                  /* NUL уже даст MSET */
                    if (n > arr_elems) n = arr_elems;
                    for (int ci = 0; ci < n; ci++) {
                        *++e = LEA; *++e = offset; *++e = PSH;
                        *++e = IMM; *++e = ci; *++e = ADD; *++e = PSH;
                        *++e = IMM; *++e = saddr + ci;
                        if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS)
                            c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le);
                        *++e = LC; *++e = SC;
                    }
                }
                else {
                    c4_err(line, "bad array initializer");
                }
                #undef C4_LELEM
            } else if (IS_STVAL(ty_)) {
                /* struct p = q; — почленная копия через SCP (адрес q в a после expr).
                 * struct p = {e0, e1, ...}; — позиционная инициализация ПО ПОЛЯМ
                 * (C89 §6.7.8) */
                int szs = c4_tag_size(C4_TAG(TY_CLEAN(ty_)));
                if (tk == '{') {
                    next();
                    int stg = C4_TAG(TY_CLEAN(ty_));
                    int i_f = 0;
                    while (tk && tk != '}') {
                        if (i_f >= c4_tag_nf[stg]) {
                            c4_err(line, "too many initializers for struct");
                        }
                        int fty = c4_tag_ftype[stg][i_f];
                        if ((fty & ARR) || c4_tag_farr[stg][i_f]) {
                            printf("%d: array member initializer in struct "
                                   "is not supported\n", line);
                            exit(-1);
                        }
                        if (IS_STVAL(fty) && tk == '{') {
                            /* вложенный struct-инициализатор ({...} в поле) не поддержан — явная
                             * диагностика (причина — см. выше) */
                            c4_err(line, "nested struct initializer is not supported (assign fields separately)");
                        }
                        /* адрес поля: LEA base; PSH; IMM foff; ADD; PSH */
                        *++e = LEA; *++e = offset; *++e = PSH;
                        *++e = IMM; *++e = c4_tag_foff[stg][i_f]; *++e = ADD;
                        *++e = PSH;
                        expr(Assign);
                        if (IS_STVAL(fty)) {
                            *++e = PSH; *++e = SCP;
                            *++e = c4_tag_size(C4_TAG(TY_CLEAN(fty)));
                        } else {
                            c4_conv_store(fty);
                            *++e = C4_STORE_OP(fty);
                            if ((fty & C4_REAL) && !IS_PTR_T(fty)) { *++e = FDROP; }
                        }
                        i_f++;
                        if (tk == Comma) next();
                    }
                    if (tk == '}') next();
                    else { c4_err(line, "'}' expected in initializer"); }
                } else {
                    *++e = LEA; *++e = offset; *++e = PSH;
                    expr(Assign);
                    *++e = PSH; *++e = SCP; *++e = szs;
                }
            } else {
                /* Скаляр: LEA offset; PSH; expr; SC/SSH/SI/FST*.
                 * FST/FSTF оставляют значение на стеке — для real сбрасываем
                 * FDROP'ом (инициализация — НЕ выражение-инструкция). */
                *++e = LEA; *++e = offset; *++e = PSH;
                expr(Assign);
                c4_conv_store(ty_);
                *++e = C4_STORE_OP(ty_);
                if ((ty_ & C4_REAL) && !IS_PTR_T(ty_)) { *++e = FDROP; }
            }
        }
        if (tk == Comma) { next(); continue; }
        break;
    }
    if (c4_fn_ent) c4_fn_ent[1] = c4_fn_i - c4_fn_loc;   /* кадр вырос */
    if (tk == ';') next(); else { c4_err(line, "';' expected after declaration"); }
}

/* интерпретатор c4 — на глобалах: компиляция идёт в задачах (два
 * редактора F9 одновременно), обёртка сериализует выполнение */
static volatile int c4_run_lock = 0;

/* x87-состояние ядра НЕ сохраняется планировщиком (imgsvc.h) —
 * double-арифметика VM (gcc компилирует в x87) обязана идти под общим
 * FPU-локом. Hosted-сборки (тесты) обходятся без него. */
#if !defined(__STDC_HOSTED__) || !__STDC_HOSTED__
extern void img_fpu_lock(void);
extern void img_fpu_unlock(void);
#define C4_FPU_LOCK()   img_fpu_lock()
#define C4_FPU_UNLOCK() img_fpu_unlock()
#else
#define C4_FPU_LOCK()   ((void)0)
#define C4_FPU_UNLOCK() ((void)0)
#endif

int c4_run(const char *src_text, char *out, u32 out_max);
static int c4_run_impl(const char *src_text, char *out, u32 out_max);

int c4_run(const char *src_text, char *out, u32 out_max)
{
    int rc;
    /* РАСШИРЕНИЕ 5: #include разворачивается ДО компиляции.
     * Развёрнутый буфер живёт до конца c4_run_impl (все пути выхода
     * проходят через возврат сюда — включая longjmp из exit()). */
    char *expanded = c4_preprocess(src_text);
    s_lock(&c4_run_lock);
    C4_FPU_LOCK();      /* double-опкоды VM — x87 под локом */
    rc = c4_run_impl(expanded ? expanded : src_text, out, out_max);
    C4_FPU_UNLOCK();
    s_unlock(&c4_run_lock);
    if (expanded) free(expanded);
    return rc;
}

static int c4_run_impl(const char *src_text, char *out, u32 out_max)
{
  int bt, poolsz, *idmain;
  int *pc, *sp, *bp, a, cycle;
  int i, *t, *t2;

  /* Сбрасываем ВСЕ глобальное состояние.
   * Важно: e, le, sym, data, sp могут быть dangling указателями
   * после предыдущего compile_only вызова (который их free()'нул). */
  c4_out = out; c4_out_pos = 0; c4_out_max = out_max;
  if (c4_out && c4_out_max) c4_out[0] = 0;
  c4_exit_code = 0;
  src = 0; debug = 0;
  n_break_fixups = 0;
  n_cont_fixups = 0;
  loop_depth = 0;
  c4_n_goto_fixups = 0;       /* сброс goto/меток (расширение 2) */
  c4_n_labels = 0;
  c4_n_scope = 0;             /* стек областей видимости (C89 блоки) */
  c4_n_boot = 0;              /* сброс глобальных инициализаторов */
  c4_boot_cell = 0;
  c4_n_imm_data_cells = 0;   /* сброс меток data-ссылок */
  c4_compile_data_base = 0;
  c4_compile_text_base = 0;
  c4_n_jsr_fixups = 0;        /* сброс ссылок на неопределённые функции */
  c4_n_fn_sigs = 0;          /* таблица сигнатур — в ОБЩЕМ блоке сброса, ДО любых c4_sig_record
   * (fabs/sqrt регистрируются ниже, при разборе имён; сброс ПОСЛЕ записи
   * стирал записи) */
  c4_n_sw_cases = 0;          /* таблица case (дубликаты) — общий сброс */
  c4_sw_depth = 0;
  c4_sw_case_ovf = 0;
  c4_fn_ent = 0; c4_fn_i = 0; c4_fn_loc = 0;
  /* Сброс dangling указателей */
  e = le = NULL;
  sym = NULL;
  data = NULL;
  id = NULL;
  tk = 0;
  ival = 0;
  ty = 0;
  loc = 0;
  line = 0;
  loop_depth = 0;

  if (__builtin_setjmp(c4_jmp) != 0) {
    /* сюда попадаем после exit() — возвращаем код; освобождаем пулы */
    c4_free_pools();
    if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0;
    return c4_exit_code;
  }

  poolsz = 256*1024;
  c4_free_pools();
  if (!(c4_pool_sym = sym = malloc(poolsz))) { printf("could not malloc(%d) symbol area\n", poolsz); return -1; }
  if (!(c4_pool_text = le = e = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) text area\n", poolsz); return -1; }
  if (!(c4_pool_data = data = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) data area\n", poolsz); return -1; }
  if (!(c4_pool_stack = sp = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) stack area\n", poolsz); return -1; }
  /* Сохраняем исходное начало data pool — нужно для расчёта data_len
   * при dump байт-кода в файл. */
  data_pool_start = data;

  memset(sym,  0, poolsz);
  memset(e,    0, poolsz);
  memset(data, 0, poolsz);

  p = "char else enum if int return sizeof while "
      "for do break continue switch case default unsigned "
      "goto const static volatile extern "
      "typedef signed long short void register auto float double struct union "
      "open read close printf malloc free memset memcmp exit "
      "kinit kquit kdelay kfill ktext kflip krgb kevent kclear kw kh kmtime "
      "strlen strcpy strcmp fabs sqrt "
      "win_open win_close win_alive win_clear win_rect win_text win_update "
      "btn_add btn_clicked btn_set_label "
      "delay "
      "main";
  i = Char; while (i <= Union) { next(); id[Tk] = i++; }
  i = OPEN; while (i <= STRCMP) { next(); id[Class] = Sys; id[Type] = INT; id[Val] = i++; }
  /* fabs/sqrt — double-функции (FABSC/SQRTC); их сигнатура — в таблице
   * c4_fn_sigs для конверсии аргументов (sqrt(4) работает) */
  { int *fabs_id = 0, *sqrt_id = 0;
    i = FABSC; while (i <= SQRTC) {
      next(); id[Class] = Sys; id[Type] = INT | DBL_F; id[Val] = i++;
      if (i == FABSC + 1) fabs_id = id; else sqrt_id = id;
    }
    if (fabs_id && sqrt_id) {
      int dsig[1]; dsig[0] = INT | DBL_F;
      c4_sig_record(fabs_id, 1, dsig);
      c4_sig_record(sqrt_id, 1, dsig);
    }
  }
  /* CMScript GUI API — сисколы WOPEN..BSETLB (окна/кнопки) */
  i = WOPEN; while (i <= BSETLB) { next(); id[Class] = Sys; id[Type] = INT; id[Val] = i++; }
  /* delay — дружелюбный алиас kdelay (последнее имя перед main) */
  next(); id[Class] = Sys; id[Type] = INT; id[Val] = KDELAY;
  /* main — ПОСЛЕ Sys-цикла, чтобы не получить Class=Sys
   * (void/struct/union — ключевые слова, зарегистрированы циклом выше) */
  next(); idmain = id;       /* main → запоминаем для проверки */

  /* Источник передан в память — не нужен open/read/close */
  lp = p = (char *)(unsigned long)src_text;
  line = 1;
  c4_n_tags = 0; c4_nf_total = 0;      /* таблицы struct/union (3.1) */
  c4_n_imm_text_cells = 0;             /* метки адресов функций (3.3) */
  c4_row1 = 0; c4_arr_elems = 0;       /* in-flight контекст массивов */
  c4_n_once = 0;                       /* #pragma once — на компиляцию */
  c4_decl_static = 0;
  c4_fn_ret = INT;
  next();
  while (tk) {
    bt = INT;
    /* квалификаторы/классы памяти C89 перед типом: static у глобала
     * эквивалентен обычному глобалу — флаг здесь же сбрасываем.
     * extern-флаг — ТОЖЕ на КАЖДОЕ объявление (сброс ДО C4_EAT_QUALS,
     * иначе «extern int x;» навсегда делало бы все последующие декларации
     * «extern» — дубликаты проходили бы) */
    c4_decl_extern = 0;
    C4_EAT_QUALS();
    c4_decl_static = 0;
    /* typedef int u32; — имя регистрируется как тип */
    if (tk == Typedef) { c4_parse_typedef(); continue; }
    {
      int b = c4_base_type();
      if (b >= 0) bt = b;          /* не тип — прежнее поведение (int) */
    }
    while (tk != ';' && tk != '}') {
      ty = bt;
      while (tk == Mul) { next(); ty = ty + PTR; }
      int gfp = 0;
      if (tk == '(' && c4_raw_peek('*')) {   /* int (*fp)(int); (3.3) */
        next();
        while (tk == Mul) next();
        gfp = 1;
        ty = (bt + PTR) | FPTR;
      }
      while (IS_QUAL(tk)) next();   /* char * const p; */
      if (tk != Id) { printf("%d: bad global declaration (tk=%d)\n", line, tk); goto fail; }
      /* Уже зарегистрированный сискол (Class==Sys — printf/win_open/...)
       * прототипом из заголовков НЕ перекрывается: объявление
       * пропускается целиком (имя + параметры + ';', без эмиссии кода). */
      if (id[Class] == Sys) {
        /* встроенная функция: пропустить объявление до ';'. ';' НЕ едим —
         * им завершится цикл деклараторов (как у прототипов). */
        next();
        if (tk == '(') {
          next();                    /* съесть '(' — иначе nest удвоится */
          int nest = 1;
          while (tk && nest > 0) {
            if (tk == '(') nest++;
            else if (tk == ')') nest--;
            next();
          }
        }
        goto fn_decl_done;
      }
      /* форма СТАРОЙ записи — ДО затирания id[Type]=ty ниже: проверки
       * переобъявления в глобальном пути сравнивают с ней */
      int prev_is_arr = 0, prev_arrsz = 0;
      if (id[Class] == Glo) {
        prev_is_arr = (id[Type] & ARR) && !IS_PTR_T(id[Type]);
        prev_arrsz = id[ArrSz];
      }
      /* повторное объявление допустимо ТОЛЬКО как «прототип, затем
       * определение» (Fun с Val==0 — см. разбор ниже) либо как
       * extern-последовательность (C89 §6.1.2.2):
       *   extern int x; int x = 5;   — декларация, затем определение;
       *   int x = 5; extern int x;   — определение, затем декларация;
       *   extern int x; extern int x; — повторные декларации.
       * Несовместимость типов при повторном объявлении НЕ проверяется */
      if (id[Class] && !(id[Class] == Fun && id[Val] == 0)) {
        int ok = 0;
        if (id[Class] == Glo && c4_decl_extern) ok = 1;
        else if (id[Class] == Glo && id[IsExt]) ok = 1;
        if (!ok) { printf("%d: duplicate global definition\n", line); goto fail; }
        if (id[Class] == Glo && c4_decl_extern && !id[IsExt]) {
          /* extern поверх УЖЕ ОПРЕДЕЛЁННОГО объекта — чистая декларация:
           * декларатор (размеры массива/инициализатор) пропускаем целиком,
           * слот и data НЕ трогаем — объект остаётся прежним. */
          while (tk && tk != ';' && tk != '}' && tk != Comma) next();
          goto fn_decl_done;
        }
      }
      next();
      id[Type] = ty;
      if (tk == '(') {
        int *fn_id = id;   /* ЗАПИСАЛИ: id затирается парсингом параметров */
        c4_fn_ret = ty;    /* тип возврата — для return (до затирания ty!) */
        id[Class] = Fun;
        id[Val] = (int)(e + 1);
        next();
        /* параметры собираются (тип/ячейки/старт-офсет), Val
         * назначается ПОСЛЕ ')'. double-параметр занимает 2 ячейки,
         * struct-параметр передаётся указателем (1 ячейка) и копируется
         * в локальные слоты (значения, C89). Максимум 16 параметров. */
        int *pid[C4_MAX_FN_ARGS]; int psz[C4_MAX_FN_ARGS]; int pst[C4_MAX_FN_ARGS];
        int pty_t[C4_MAX_FN_ARGS];
        int npn = 0, pcap = 0, has_va_ = 0;
        while (tk != ')') {
          /* f(void): настоящий токен void с последующей ')' — пустой
           * список параметров (C89), без фантомного слота (1.4). */
          if (tk == Void && c4_raw_peek(')')) { next(); break; }
          ty = INT;
          /* квалификаторы в параметрах: const void *a, unsigned long... */
          while (IS_QUAL(tk)) next();
          {
            int pbt = c4_base_type();
            if (pbt >= 0) ty = pbt;   /* K&R-стиль без типа: считаем int */
          }
          while (tk == Mul) { next(); ty = ty + PTR; }
          int pfp = 0;
          if (tk == '(' && c4_raw_peek('*')) {   /* int (*cb)(int) (3.3) */
            next();
            while (tk == Mul) next();
            pfp = 1;
            ty = (ty + PTR) | FPTR;
          }
          while (IS_QUAL(tk)) next();   /* char * const p */
          if (tk == DotDotDot) { next(); has_va_ = 1; break; }   /* variadic: доп. аргументы допустимы */
          if (npn >= C4_MAX_FN_ARGS) {
            printf("%d: too many parameters (max %d)\n", line, C4_MAX_FN_ARGS); goto fail;
          }
          /* размер аргумента в ячейках (struct — указатель = 1) */
          #define C4_PAR_SZ(ty_) (IS_STVAL(ty_) ? 1 \
                                  : (((ty_) & C4_REAL) && !IS_PTR_T(ty_)) ? 2 : 1)
          if (tk == Comma || tk == ')') {
            /* анонимный параметр (прототип): тип в сигнатуру, имя не объявляем */
            pst[npn] = pcap; pty_t[npn] = ty; pid[npn] = 0;
            psz[npn] = C4_PAR_SZ(ty); pcap += psz[npn]; npn++;
            if (pfp) {   /* закрыть ')(' ... ')' funcptr-прототипа */
              if (tk == ')') next();
              c4_skip_parens();
            }
            if (tk == Comma) next();
            continue;
          }
          if (tk != Id) { printf("%d: bad parameter declaration (tk=%d)\n", line, tk); goto fail; }
          if (id[Class] == Loc) { printf("%d: duplicate parameter definition\n", line); goto fail; }
          pst[npn] = pcap; pty_t[npn] = ty; pid[npn] = id; npn++;
          id[HClass] = id[Class]; id[Class] = Loc;
          id[HType]  = id[Type];  id[Type] = ty;
          id[HVal]   = id[Val];   /* Val назначается после ')' */
          int cur_ = npn - 1;
          next();
          if (tk == Brak) {   /* char argv[] / char argv[][16] — параметр-массив = указатель (4.2) */
            int *pid_ = id;   /* id может перезатереться next()'ом */
            while (tk == Brak) {   /* КАЖДАЯ группа [] добавляет уровень косвенности:
                                    * T x[] ≡ T *x; T x[][N] ≡ T ** (C89 §6.7.5.3) */
              next();
              while (tk && tk != ']') next();
              if (tk == ']') next();
              ty = ty + PTR;
            }
            pid_[Type] = ty;  /* тип уже записан выше — обновить */
            pty_t[cur_] = ty;
          }
          if (pfp) {   /* ')' + список параметров указываемой функции */
            if (tk == ')') next(); else {
              printf("%d: ')' expected in function pointer parameter\n", line); goto fail;
            }
            c4_skip_parens();
          }
          psz[cur_] = C4_PAR_SZ(ty); pcap += psz[cur_];
          #undef C4_PAR_SZ
          if (tk == Comma) next();
        }
        next();
        /* Val-назначение: параметр q занимает ячейки
         * [bp + s_q .. bp + s_q + psz_q - 1], s_q = 2 + размер параметров
         * ПОСЛЕ него; LEA-операнд = loc - s_q при loc = pcap + 1, т.е.
         * Val_q = pcap - 1 - after_q (при all-int даёт старое q). */
        {
          int after_ = 0;
          if (has_va_) {
            /* variadic (cdecl): аргументы пушатся СПРАВА НАЛЕВО — первый
             * именованный параметр в bp+2, vararg'и — ВЫШЕ него. Val_q
             * = pcap - 1 - (ячейки именованных ПЕРЕД q). */
            int bef_ = 0;
            for (int q_ = 0; q_ < npn; q_++) {
              if (pid[q_]) pid[q_][Val] = pcap - 1 - bef_;
              bef_ += psz[q_];
            }
          } else {
            for (int q_ = npn - 1; q_ >= 0; q_--) {
              if (pid[q_]) pid[q_][Val] = pcap - 1 - after_;
              after_ += psz[q_];
            }
          }
        }
        /* сигнатура для конверсии аргументов в точках вызова */
        c4_sig_record(fn_id, npn, pty_t);
        if (has_va_) { c4_sig_mark_va(fn_id); c4_va_check_unaware(fn_id); }
        i = pcap;          /* i теперь — суммарный размер параметров в ячейках */
        if (tk == ';') {
          /* Прототип функции: объявление без тела. ';' НЕ потребляем —
           * им завершится цикл деклараторов (как у int g;). Val=0
           * помечает «ещё не определена»: вызовы до определения дают
           * JSR 0 + запись в c4_jsr_fixups (патчится в конце файла).
           * Параметры уже записаны как Loc — возвращаем их прежние
           * атрибуты (как это делает конец разбора определения).
           * ВАЖНО: id указывает на ПОСЛЕДНИЙ параметр, а не на функцию —
           * поэтому патчим через сохранённый fn_id. */
          fn_id[Val] = 0;
          id = sym;
          while (id[Tk]) {
            if (id[Class] == Loc) {
              id[Class] = id[HClass]; id[Type] = id[HType]; id[Val] = id[HVal];
            }
            id = id + Idsz;
          }
          goto fn_decl_done;   /* пропустить разбор тела */
        }
        if (tk != '{') { printf("%d: bad function definition\n", line); goto fail; }
        loc = ++i;
        c4_fn_loc = loc;   /* синхронизация для switch (stmt() их не видит) */
        /* РАСШИРЕНИЕ 2: таблицы goto/меток — свои на каждую функцию */
        c4_n_goto_fixups = 0;
        c4_n_labels = 0;
        /* ENT (пролог) эмитится ПЕРВЫМ, с операндом-заглушкой (патчится после
         * разбора объявлений): иначе код инициализаторов `int x = expr;`
         * попадал бы ВЫШЕ ENT и исполнялся с bp ВЫЗЫВАЮЩЕГО — порча кадра,
         * локалы — мусор, VM сходит с рельсов */
        int *fn_ent = e + 1;
        c4_fn_ent = fn_ent;   /* для switch: перпатч операнда ENT */
        *++e = ENT; *++e = 0;
        /* Таблицы областей видимости/слоты — свои на каждую функцию */
        c4_n_scope = 0;
        c4_fn_i = i;          /* слоты теперь выделяет c4_parse_decls */
        /* (C89 §6.9.1): struct-параметры переданы указателем,
         * callee копирует в СВОИ слоты кадра (мутации не видны вызывающему).
         * Код копий — сразу за ENT, ДО init-объявлений (те могут читать
         * поля параметров). */
        for (int q_ = 0; q_ < npn; q_++) {
          if (pid[q_] && IS_STVAL(pid[q_][Type])) {
            int btsz = c4_tag_size(C4_TAG(TY_CLEAN(pid[q_][Type])));
            c4_fn_i += (btsz + 3) / 4;
            pid[q_][Val] = c4_fn_i;          /* база = НИЖНИЙ слот */
            *++e = LEA; *++e = loc - pid[q_][Val]; *++e = PSH;
            /* SRC — указатель-аргумент в слоте параметра: pst[q_] — смещение
             * ячейки среди запушенных аргументов. Обычный вызов (слева
             * направо): LEA-операнд = loc - pst[q_]; variadic (cdecl,
             * справа налево): параметр q в bp+2+pst[q_] → операнд 2+pst[q_].
             * (Голый pst[q_] читал bp+0 = saved-bp!) */
            *++e = LEA; *++e = has_va_ ? (2 + pst[q_]) : (loc - pst[q_]);
            *++e = LI; *++e = PSH;
            *++e = SCP; *++e = btsz;
          }
        }
        next();
        /* C89: объявления в начале функции (int x = 5, *p, a[10] = {...};
         * typedef ...; static int c = 0;) — общий код с вложенными блоками */
        for (;;) {
          C4_EAT_QUALS();
          if (tk == Typedef) { c4_parse_typedef(); continue; }
          {
            int b = c4_base_type();
            if (b < 0) break;
            c4_parse_decls(b, 0);
          }
        }
        i = c4_fn_i;
        fn_ent[1] = i - loc;   /* патчим операнд ENT */
        c4_fn_i = i;           /* синхронизация счётчика слотов для switch */
        while (tk != '}') stmt();
        /* double-функция без return — 0.0 (x87-стек чист) */
        if (IS_REAL_VAL(c4_fn_ret)) { *++e = FLD0; *++e = FRET; }
        else *++e = LEV;
        /* РАСШИРЕНИЕ 2: незакрытые goto — ошибка компиляции */
        if (c4_n_goto_fixups > 0) {
          int *fid = c4_goto_fixups[0].fsym;
          printf("%d: undefined label '%s'\n", line, (char *)(unsigned long)fid[Name]);
          goto fail;
        }
        c4_n_goto_fixups = 0;
        c4_n_labels = 0;
        id = sym;
        while (id[Tk]) {
          if (id[Class] == Loc || id[SMark]) {
            /* Loc — локали/параметры; SMark — static-локалы (1.2):
             * оба восстанавливают прежнюю запись (тень/видимость) */
            id[Class] = id[HClass];
            id[Type] = id[HType];
            id[Val] = id[HVal];
            id[SMark] = 0;
          }
          id = id + Idsz;
        }
      }
      else {
        /* повторная регистрация уже существующего Glo (определение после
         * extern-декларации) — СЛОТ ПЕРЕИСПОЛЬЗУЕТСЯ: обращения к объекту ДО
         * определения ссылаются на id[Val] и обязаны видеть тот же объект, что
         * и после определения (иначе «extern int x; int get(){return x;}
         * int x = 5;» читало бы чужой нулевой слот). id[Val] и data не трогаем */
        int reuse = (id[Class] == Glo);
        id[Class] = Glo;
        if (!reuse) id[Val] = (int)(unsigned long)data;
        id[IsExt] = c4_decl_extern;   /* extern без '=' — декларация */
        /* Сохраняем указатель на запись массива, т.к. next() ниже
         * может переключить id на другую запись (если размер —
         * #define'Id-константа). Без этого флаг ARR запишется не туда. */
        int *glo_id = id;
        int is_arr = 0, arr_elems = 1, dims2 = 0, dims3 = 0, base_ty = ty & ~(ARR | ARR2 | ARR3);

        /* funcptr-глобал: закрыть ')' и список параметров (3.3).
         * next() после имени уже сделан общим кодом — tk = ')' */
        if (gfp) {
          if (tk == ')') next(); else {
            printf("%d: ')' expected in function pointer declaration\n", line); goto fail;
          }
          c4_skip_parens();
        }

        /* Поддержка массивов: int a[10]; const char *MON[] = {...};
         * 2D (3.2): int m[3][4] — плоское размещение, ArrSz = A*B */
        if (tk == Brak) {
          is_arr = 1;
          next();
          if (tk == ']') {
            /* «[]»: размер выводится из инициализатора "= { ... }"
             * или "= \"строка\"" — сырой скан (однопроходный парсер
             * не умеет «сначала посчитать, потом парсить»). */
            const char *sv = p;
            while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
            if (*sv == '=') {
              sv++;
              while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
              if (*sv == '{') arr_elems = c4_count_init_list(sv);
              else if (*sv == '"') arr_elems = c4_count_str_lit(sv);
            }
            if (tk == ']') next();
          }
          /* размер — константное выражение (char buf[SIZE/2 + 1];) через
           * c4_parse_const; переменные — ошибка (C89) */
          else if (c4_parse_const(&arr_elems) || arr_elems < 0) {
            c4_err(line, "bad array size (integer constant expected)");
          }
          if (tk == ']') next();   /* закрывающая скобка */
          if (arr_elems < 1) arr_elems = 1;
          {
            int dd[2] = {0, 0};
            int nd = 1;
            while (tk == Brak && nd <= 2) {   /* int m[A][B][C] (3.2) */
              next();
              int dv = 0;
              if (tk == ']' || c4_parse_const(&dv) || dv < 1) {
                c4_err(line, "array dimension must be a constant");
              }
              if (tk == ']') next();
              dd[nd - 1] = dv;
              arr_elems *= dv;
              nd++;
            }
            dims2 = dd[0]; dims3 = dd[1];
          }
          int gesz = c4_esz(base_ty);
          if (reuse && prev_arrsz < arr_elems) {
            /* переобъявление с БОЛЬШИМ размером массива (в т.ч. скаляр → массив,
             * неполный extern char s[]) — слот уже размещён: расширять нельзя
             * (соседи в сегменте данных) */
            c4_err(line, "redeclaration with larger array size is not supported");
          }
          if (!reuse) data = data + gesz * arr_elems;
          /* base_ty, а НЕ ty: c4_parse_const внутри (expr) затирает
           * глобальный ty — иначе char G2[8] получает тип int[8]. */
          glo_id[Type] = base_ty | ARR | (dims2 ? ARR2 : 0) | (dims3 ? ARR3 : 0);
          glo_id[ArrSz] = arr_elems;
          glo_id[ArrD] = dims2;
          glo_id[ArrD2] = dims3;
        } else {
          if (reuse && prev_is_arr) {
            /* массив → скаляр — форма объекта меняется */
            c4_err(line, "redeclaration changes array to scalar");
          }
          if (!reuse) data = data + c4_sizeof_ty(ty);
        }

        /* ГЛОБАЛЬНЫЕ ИНИЦИАЛИЗАТОРЫ: int K = 5; const char *MSG = "...";
         * int A[3] = {1, 2, 3}; char S[] = "строка"; — код записи
         * собирается в отдельный «чанк»-функцию (c4_emit_glob_init);
         * при запуске boot-код вызывает чанки до main. Строковая
         * инициализация char-массива копируется прямо в сегмент данных. */
        if (tk == Assign || tk == '{') {
          /* extern С инициализатором — определение (C89 §6.7.2):
           * флаг декларации гасим */
          glo_id[IsExt] = 0;
        }
        if (tk == Assign) {
          next();
          if (is_arr && base_ty == CHAR && !dims2 && tk == '"') {
            /* char S[] = "abc"; / char S[10] = "hi"; — статическая
             * инициализация: строка уже лежит в сегменте данных (её
             * только что лексировали), копируем байты прямо в слот
             * массива. Остаток массива остаётся нулевым (C89). */
            int saddr = ival;
            while (tk == '"') next();      /* смежные литералы */
            int slen = 0;
            while (((char *)(unsigned long)saddr)[slen]) slen++;
            int n = slen + 1;              /* вместе с NUL */
            if (n > arr_elems) n = arr_elems;
            memcpy((char *)(unsigned long)glo_id[Val],
                   (char *)(unsigned long)saddr, n);
          } else {
            c4_emit_glob_init(glo_id, base_ty, is_arr, arr_elems);
          }
        }
      }
fn_decl_done: ;   /* сюда попадает разбор прототипа (без тела) */
      if (tk == Comma) next();
    }
    next();
  }

  /* Патчим вызовы функций, встреченные ДО их определения (прототипы).
   * К этому моменту разобраны все определения; незакрытые ссылки —
   * ошибка компиляции. Операнд JSR — абсолютный адрес байт-кода. */
  for (i = 0; i < c4_n_jsr_fixups; i++) {
    int *fid = c4_jsr_fixups[i].fid;
    if (fid[Val] == 0) {
      printf("%d: function '%s' used but not defined\n", line,
             (char *)(unsigned long)fid[Name]);
      goto fail;
    }
    *c4_jsr_fixups[i].cell = fid[Val];
  }

  if (!(pc = (int *)idmain[Val])) { printf("main() not defined\n"); goto fail; }

  /* Boot-код глобальных инициализаторов: JSR по чанкам, затем JMP main.
   * Точка входа смещается на boot, если инициализаторы были. */
  if (c4_n_boot > 0) {
    /* boot начнётся с ячейки e+1 (индекс от начала пула le) */
    c4_boot_cell = (u32)(((int)(unsigned long)(e + 1) - (int)(unsigned long)le) / (int)sizeof(int));
    for (int bi = 0; bi < c4_n_boot; bi++) {
      *++e = JSR;
      *++e = (int)(unsigned long)c4_boot_chunks[bi];
    }
    *++e = JMP;
    *++e = (int)(unsigned long)idmain[Val];
  }

  if (src) { if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0; c4_free_pools(); return 0; }


  /* ---------- N2600-OS: compile-only mode (для c4_x86.c) ----------
   * Если выставлен флаг c4_compile_only, мы сохраняем байт-код и сегмент
   * данных в caller-предоставленные буферы и возвращаемся БЕЗ запуска VM.
   * Это позволяет c4_compile() получить IR для дальнейшей обработки. */
  if (c4_compile_only) {
    u32 text_cells = (u32)((int)(unsigned long)e - (int)(unsigned long)le) / sizeof(int) + 1;
    u32 entry_cells = c4_boot_cell
        ? c4_boot_cell
        : (((u32)(unsigned long)idmain[Val] - (u32)(unsigned long)le) / sizeof(int));
    u32 data_len = 0;
    if (data_pool_start) {
      data_len = (u32)((unsigned long)data - (unsigned long)data_pool_start);
    }
    if (c4_compile_bc_buf && c4_compile_bc_max >= text_cells * 4) {
      memcpy(c4_compile_bc_buf, le, text_cells * 4);
      c4_compile_bc_len_cells = text_cells;
    }
    if (c4_compile_data_buf && c4_compile_data_max >= data_len) {
      memcpy(c4_compile_data_buf, data_pool_start, data_len);
      c4_compile_data_len = data_len;
    }
    c4_compile_entry_cells = entry_cells;
    c4_idmain_val_saved = (int *)idmain[Val];
    /* база сегмента данных для c4_x86 (пересчёт адресов в смещения) */
    if (data_pool_start)
        c4_compile_data_base = (u32)(unsigned long)data_pool_start;
    /* база текст-пула: цели переходов в байт-коде — указатели le+cell */
    c4_compile_text_base = (u32)(unsigned long)le;
    data_pool_start = NULL;
    c4_free_pools();
    return 0;
  }

  /* ---------- N2600-OS: сохранение байт-кода в .bin рядом с .c ---------- */
  if (c4_save_bin_name) {
    /* Точка входа main — абсолютный адрес idmain[Val]. Байт-код начинается
     * с le (pool start). Длина text в int-ячейках: (e - le) + 1.
     * Длина data = текущий data - data_pool_start (исходное начало). */
    u32 text_cells = (u32)((int)(unsigned long)e - (int)(unsigned long)le) / sizeof(int) + 1;
    u32 entry_cells = c4_boot_cell
        ? c4_boot_cell
        : (((u32)(unsigned long)idmain[Val] - (u32)(unsigned long)le) / sizeof(int));
    u32 data_len = 0;
    if (data_pool_start) {
      data_len = (u32)((unsigned long)data - (unsigned long)data_pool_start);
    }

    u32 total_size = 16 + text_cells * 4 + data_len;
    int saved = 0;
    if (ramfs_ready()) {
      ramfs_delete(c4_save_bin_name);
      if (ramfs_create(c4_save_bin_name, total_size)) {
        u8 *buf = (u8 *)malloc(total_size);
        if (buf) {
          buf[0]='C'; buf[1]='4'; buf[2]='B'; buf[3]='1';
          buf[4] = (u8)(entry_cells & 0xFF);
          buf[5] = (u8)((entry_cells >> 8) & 0xFF);
          buf[6] = (u8)((entry_cells >> 16) & 0xFF);
          buf[7] = (u8)((entry_cells >> 24) & 0xFF);
          buf[8]  = (u8)(text_cells & 0xFF);
          buf[9]  = (u8)((text_cells >> 8) & 0xFF);
          buf[10] = (u8)((text_cells >> 16) & 0xFF);
          buf[11] = (u8)((text_cells >> 24) & 0xFF);
          buf[12] = (u8)(data_len & 0xFF);
          buf[13] = (u8)((data_len >> 8) & 0xFF);
          buf[14] = (u8)((data_len >> 16) & 0xFF);
          buf[15] = (u8)((data_len >> 24) & 0xFF);
          memcpy(buf + 16, le, text_cells * sizeof(int));
          if (data_len > 0 && data_pool_start) {
            memcpy(buf + 16 + text_cells * 4, data_pool_start, data_len);
          }
          ramfs_write(c4_save_bin_name, buf, total_size);
          free(buf);
          saved = 1;
        }
      }
    }
    if (c4_out && c4_out_pos < c4_out_max) {
      if (saved) {
        char msg[96];
        extern int snprintf(char *out, C4_SZT n, const char *fmt, ...);
        snprintf(msg, sizeof(msg),
                 "[c4] compiled OK: %u text cells, %u data bytes, saved as %s",
                 (unsigned)text_cells, (unsigned)data_len, c4_save_bin_name);
        c4_puts(msg);
        c4_putc('\n');
      } else {
        c4_puts("[c4] failed to save binary (RAMFS error)\n");
      }
    }
    c4_save_bin_name = NULL;
    data_pool_start = NULL;
    c4_free_pools();
    return 0;
  }

  // setup stack
  bp = sp = (int *)((int)(unsigned long)sp + poolsz);
  *--sp = EXIT;
  *--sp = PSH; t2 = sp;
  /* 4.2: main(argc, argv) — обе формы C89. Соглашение вызова c4:
   * bp[1] — адрес возврата (у main его нет — кладём фейковый,
   * указывающий на трampoлину PSH;EXIT), bp[2] — ПОСЛЕДНИЙ параметр
   * (argv), bp[3] — предпоследний (argc). Массив argv кладём на стек
   * вызывающего: argv[1] = NULL, argv[0] = "". */
  *--sp = 0;                                   /* argv[1] = NULL */
  *--sp = (int)(unsigned long)"";              /* argv[0] */
  t = sp;                                      /* t = &argv[0] */
  *--sp = 1;                                   /* параметр argc (глубже argv) */
  *--sp = (int)(unsigned long)t;               /* параметр argv */
  *--sp = (int)(unsigned long)t2;              /* fake ret → PSH;EXIT */
  /* boot глобальных инициализаторов: стартуем с boot-кода, не с main */
  if (c4_boot_cell) pc = le + c4_boot_cell;

  /* run
   * ВАЖНО: после возврата из main() (LEV), pc указывает на СТЕК,
   * где лежат PSH+EXIT (см. setup ниже). Это НЕ байт-код!
   * Поэтому bounds check на pc НЕЛЬЗЯ делать — он даёт ложное срабатывание. */
  cycle = 0;
  while (1) {
    /* Лимит циклов: предотвращаем бесконечный цикл (10 млн) */
    if (cycle > 10000000) {
      printf("cycle limit exceeded (10M)! possible infinite loop\n");
      c4_free_pools();
      return -1;
    }
    i = *pc++; ++cycle;
    if (debug) {
      printf("%d> %.4s", cycle,
        &"LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,"
         "OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,"
         "OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,"[i * 5]);
      if (i <= ADJ) printf(" %d\n", *pc); else printf("\n");
    }
    if      (i == LEA) a = (int)(unsigned long)(bp + *pc++);
    else if (i == IMM) a = *pc++;
    else if (i == JMP) pc = (int *)*pc;
    else if (i == JSR) { *--sp = (int)(unsigned long)(pc + 1); pc = (int *)*pc; }
    /* JSRI <n>: цель — sp[n] (пуш была ДО аргументов). Адрес возврата =
     * pc+1 (после операнда). Слот цели снимет ADJ n+1. */
    else if (i == JSRI) {
        int n_ = *pc++;                  /* операнд: число аргументов */
        a = sp[n_];                      /* цель: пуш была ДО аргументов */
        *--sp = (int)(unsigned long)pc;  /* ret = ячейка после операнда */
        pc = (int *)a;
    }
    else if (i == BZ)  pc = a ? pc + 1 : (int *)*pc;
    else if (i == BNZ) pc = a ? (int *)*pc : pc + 1;
    else if (i == ENT) { *--sp = (int)(unsigned long)bp; bp = sp; sp = sp - *pc++; }
    else if (i == ADJ) sp = sp + *pc++;
    else if (i == LEV) { sp = bp; bp = (int *)*sp++; pc = (int *)*sp++; }
    else if (i == LI)  a = *(int *)a;
    else if (i == LC)  a = *(char *)a;
    else if (i == LS)  a = *(i16 *)(unsigned long)a;               /* short (1.5) */
    else if (i == ULS) a = *(u16 *)(unsigned long)a;               /* unsigned short */
    else if (i == SI)  *(int *)*sp++ = a;
    else if (i == SC)  a = *(char *)*sp++ = a;
    else if (i == SSH) *(i16 *)(unsigned long)*sp++ = (i16)a;      /* short (1.5) */
    else if (i == PSH) *--sp = a;

    else if (i == OR)  a = *sp++ |  a;
    else if (i == XOR) a = *sp++ ^  a;
    else if (i == AND) a = *sp++ &  a;
    else if (i == EQ)  a = *sp++ == a;
    else if (i == NE)  a = *sp++ != a;
    else if (i == LT)  a = *sp++ <  a;
    else if (i == GT)  a = *sp++ >  a;
    else if (i == LE)  a = *sp++ <= a;
    else if (i == GE)  a = *sp++ >= a;
    else if (i == SHL) a = *sp++ << a;
    else if (i == SHR) a = *sp++ >> a;
    else if (i == USHR) a = (int)((u32)*sp++ >> ((u32)a & 31u));  /* логический сдвиг: unsigned >> */
    else if (i == ADD) a = *sp++ +  a;
    else if (i == SUB) a = *sp++ -  a;
    else if (i == MUL) a = *sp++ *  a;
    else if (i == DIV) {
        /* деление на ноль в c4-программе → исключение #0 CPU → exc_panic →
         * ПАНИКА ВСЕЙ СИСТЕМЫ (VM не защищена setjmp) — нужен guard.
         * Внимание: делитель — аккумулятор a (правый операнд), делимое в стеке */
        if (a == 0) { printf("divide by zero\n"); exit(-1); }
        a = *sp++ /  a;
    }
    else if (i == MOD) {
        /* аналогично для остатка */
        if (a == 0) { printf("modulo by zero\n"); exit(-1); }
        a = *sp++ %  a;
    }
    /* --- unsigned-семантика (1.3): деление/остаток/сравнения без знака --- */
    else if (i == UDIV) {
        if (a == 0) { printf("divide by zero\n"); exit(-1); }
        a = (int)((u32)*sp++ / (u32)a);
    }
    else if (i == UMOD) {
        if (a == 0) { printf("modulo by zero\n"); exit(-1); }
        a = (int)((u32)*sp++ % (u32)a);
    }
    else if (i == ULT) a = (u32)*sp++ <  (u32)a;
    else if (i == UGT) a = (u32)*sp++ >  (u32)a;
    else if (i == ULE) a = (u32)*sp++ <= (u32)a;
    else if (i == UGE) a = (u32)*sp++ >= (u32)a;

    /* ============== float/double ==============
     * double на стеке = 2 ячейки (lo по меньшему адресу); арифметика —
     * нативный double (x87) под FPU-локом c4_run. */
    else if (i == FLDI) { *--sp = pc[1]; *--sp = pc[0]; pc += 2; }   /* hi глубже */
    else if (i == FLD0)  c4_push_d(&sp, 0.0);
    else if (i == FLD1)  c4_push_d(&sp, 1.0);
    else if (i == FDUP)  c4_push_d(&sp, c4_peek_d(sp));
    else if (i == FDROP) sp += 2;
    else if (i == FLD)  { c4_push_d(&sp, *(double *)(unsigned long)a); a = sp[0]; }
    else if (i == FLDF) { c4_push_d(&sp, (double)*(float *)(unsigned long)a); a = sp[0]; }
    else if (i == FST)  { double v_ = c4_pop_d(&sp); int ad_ = (int)*sp++;
                          *(double *)(unsigned long)ad_ = v_; c4_push_d(&sp, v_); }
    else if (i == FSTF) { double v_ = c4_pop_d(&sp); int ad_ = (int)*sp++;
                          float f_ = (float)v_; *(float *)(unsigned long)ad_ = f_;
                          c4_push_d(&sp, (double)f_); }
    else if (i == FADD) { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); c4_push_d(&sp, a_ + b_); }
    else if (i == FSUB) { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); c4_push_d(&sp, a_ - b_); }
    else if (i == FMUL) { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); c4_push_d(&sp, a_ * b_); }
    else if (i == FDIV) { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); c4_push_d(&sp, a_ / b_); }
    else if (i == FNEG) { double a_ = c4_pop_d(&sp); c4_push_d(&sp, -a_); }
    else if (i == FEQ)  { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); a = (a_ == b_); }
    else if (i == FNE)  { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); a = (a_ != b_); }
    else if (i == FLT)  { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); a = (a_ <  b_); }
    else if (i == FLE)  { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); a = (a_ <= b_); }
    else if (i == FGT)  { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); a = (a_ >  b_); }
    else if (i == FGE)  { double b_ = c4_pop_d(&sp), a_ = c4_pop_d(&sp); a = (a_ >= b_); }
    else if (i == ITOF) { double d_ = (double)*sp++; c4_push_d(&sp, d_); }
    else if (i == UTOF) { double d_ = (double)(unsigned)*sp++; c4_push_d(&sp, d_); }
    else if (i == FTOI) { a = (int)c4_pop_d(&sp); }        /* усечение к нулю */
    else if (i == ITOF2) {
        /* [int][double(2)] → [double(2)][double(2)]: правый сдвигается
         * на ячейку вниз, int под ним конвертируется. */
        union { double d; int w[2]; } u_;
        u_.d = (double)sp[2];
        sp[-1] = sp[0]; sp[0] = sp[1];   /* right: sp[0..1] → sp[-1..0] */
        sp[1] = u_.w[0]; sp[2] = u_.w[1];/* left_d: sp[1..2] */
        sp -= 1;
    }
    else if (i == UTOF2) {
        /* как ITOF2, но левый int — БЕЗЗНАКОВЫЙ (2^32-вес старшего бита) */
        union { double d; int w[2]; } u_;
        u_.d = (double)(unsigned)sp[2];
        sp[-1] = sp[0]; sp[0] = sp[1];
        sp[1] = u_.w[0]; sp[2] = u_.w[1];
        sp -= 1;
    }
    else if (i == FSTK) {
        /* постфиксные d++/--: стек [addr][old(2)][new(2)] — записать new
         * по addr (он ПОД old!), оставить old как результат */
        double v_ = c4_pop_d(&sp); int ad_ = sp[2];
        *(double *)(unsigned long)ad_ = v_;
        sp[2] = sp[1]; sp[1] = sp[0]; sp += 1;
    }
    else if (i == FSTKF) {
        /* то же для float-переменной (4 байта, результат — старый double) */
        double v_ = c4_pop_d(&sp); int ad_ = sp[2];
        *(float *)(unsigned long)ad_ = (float)v_;
        sp[2] = sp[1]; sp[1] = sp[0]; sp += 1;
    }
    else if (i == FRET) { c4_dret = c4_pop_d(&sp); sp = bp; bp = (int *)*sp++; pc = (int *)*sp++; }
    else if (i == FRD)  c4_push_d(&sp, c4_dret);
    else if (i == SCP)  { int n_ = *pc++; int *src_ = (int *)(unsigned long)*sp++;
                          int *dst_ = (int *)(unsigned long)*sp++;
                          memmove(dst_, src_, (u32)n_); a = (int)(unsigned long)dst_; }
    else if (i == FABSC) { /* in-place [x(2)] → [|x|(2)] — результат на стеке, как у всех float-опкодов */
                           double d_ = c4_pop_d(&sp); c4_push_d(&sp, d_ < 0.0 ? -d_ : d_); }
    else if (i == SQRTC) { c4_push_d(&sp, c4_sqrt(c4_pop_d(&sp))); }

    else if (i == OPEN || i == READ) a = -1; /* не поддерживается */
    else if (i == CLOS) a = 0;
    else if (i == PRTF) { t = sp + pc[1]; a = c4_vm_printf((const char *)(unsigned long)t[-1], t, pc[1]); }
    else if (i == MALC) a = (int)(unsigned long)malloc((u32)*sp);
    else if (i == FREE) free((void *)(unsigned long)*sp);
    else if (i == MSET) a = (int)(unsigned long)memset((void *)(unsigned long)sp[2], sp[1], (u32)*sp);
    else if (i == MCMP) a = memcmp((const void *)(unsigned long)sp[2], (const void *)(unsigned long)sp[1], (u32)*sp);
    else if (i == EXIT) { int code = *sp; /* код выхода читаем ДО free — sp указывает в пул стека */ if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0; c4_free_pools(); return code; }
    /* ============== N2600-OS: SDL2-подобные сисколы ============== */
    /* Стек c4 после всех PSH: sp[0]=последний аргумент, sp[1]=предыд., ...
     * ADJ потом всё уберет (sp += argcount). */
    else if (i == KINIT || i == KQUIT) a = 0;                  /* no-op: контекст уже есть */
    else if (i == KDELAY) {
        /* kdelay(ms): уступить CPU на ms миллисекунд
         * (1 тик = 1 мс при PIT 1000 Гц) */
        u32 start = timer_ticks();
        u32 need = (u32)*sp;
        if (need == 0) need = 1;
        while ((timer_ticks() - start) < need) task_yield();
        a = 0;
    }
    else if (i == KFILL) {
        /* kfill(x, y, w, h, color) — заливка прямоугольника.
         * Через c4gfx: ленивое окно с canvas (прямой вывод на экран
         * стирается композитором многопоточного WM). */
        c4_gfx_fill_rect(sp[4], sp[3], sp[2], sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == KTEXT) {
        /* ktext(x, y, s, fg, bg) — вывести строку */
        c4_gfx_text(sp[4], sp[3], (const char *)(unsigned long)sp[2],
                    (u32)sp[1], (int)sp[0]);
        a = 0;
    }
    else if (i == KFLIP) {
        /* kflip() — показать нарисованное (область окна на экране) */
        c4_gfx_flip(NULL);
        a = 0;
    }
    else if (i == KRGB) {
        /* krgb(r, g, b) — получить цвет; возвращает 32-битное ARGB */
        a = (int)fb_rgb((u8)sp[2], (u8)sp[1], (u8)sp[0]);
    }
    else if (i == KEVENT) {
        /* kevent(out_buf) — получить следующее событие ввода.
         * Возвращает 0=нет события, 1=клавиша, 2=мышь, 3=выход (Esc).
         * Формат буфера для клавиши: buf[0]=ch, buf[1]=code, buf[2]=flags
         * Формат для мыши: buf[0..3]=dx_lo, dx_hi, dy_lo, dy_hi, buf[4]=buttons */
        char *out = (char *)(unsigned long)sp[0];
        if (out) {
            /* события читаем из очереди ОКНА программы (c4gfx): глобальную
             * kbd-очередь вытягивает kmain (wm_key) — иначе события до c4-программ
             * не доходят */
            a = c4_gfx_event_poll(out);
        } else a = 0;
    }
    else if (i == KCLEAR) {
        /* kclear(color) — залить canvas цветом */
        c4_gfx_fill_screen((u32)*sp);
        a = 0;
    }
    else if (i == KW) {
        /* kwidth() — ширина области рисования (canvas окна) */
        a = (int)c4_gfx_width();
    }
    else if (i == KH) {
        /* kheight() — высота области рисования (canvas окна) */
        a = (int)c4_gfx_height();
    }
    else if (i == KMTIME) {
        /* kmtime() — текущее время в миллисекундах (1 тик = 1 мс) */
        a = (int)timer_ticks();
    }
    /* ===== Строковые операции ===== */
    else if (i == STRLEN) {
        /* strlen(s) — длина NUL-terminated строки */
        char *s = (char *)(unsigned long)sp[0];
        int len = 0;
        while (s && s[len]) len++;
        a = len;
    }
    else if (i == STRCPY) {
        /* strcpy(dst, src) — копирование строки */
        char *dst = (char *)(unsigned long)sp[1];
        char *src = (char *)(unsigned long)sp[0];
        if (dst && src) {
            int j = 0;
            while (src[j]) { dst[j] = src[j]; j++; }
            dst[j] = 0;
        }
        a = (int)(unsigned long)dst;
    }
    else if (i == STRCMP) {
        /* strcmp(a, b) — сравнение строк: 0=равны, <0=a<b, >0=a>b */
        char *a_s = (char *)(unsigned long)sp[1];
        char *b_s = (char *)(unsigned long)sp[0];
        a = 0;
        if (a_s && b_s) {
            int j = 0;
            while (a_s[j] && b_s[j] && a_s[j] == b_s[j]) j++;
            a = (int)(unsigned char)a_s[j] - (int)(unsigned char)b_s[j];
        }
    }
    /* ===== Script GUI API (VM-путь, через c4_gui_api; native — через kapi) ===== */
    else if (i == WOPEN) {
        const char *title = (const char *)(unsigned long)sp[4];
        a = (c4_gui_api && c4_gui_api->win_open)
            ? c4_gui_api->win_open(title, sp[3], sp[2], sp[1], (int)sp[0]) : -1;
    }
    else if (i == WCLOSE) {
        int id_w = (int)sp[0];
        if (c4_gui_api && c4_gui_api->win_close) c4_gui_api->win_close(id_w);
        a = 0;
    }
    else if (i == WALIVE) {
        int id_w = (int)sp[0];
        a = (c4_gui_api && c4_gui_api->win_alive) ? c4_gui_api->win_alive(id_w) : 0;
    }
    else if (i == WCLEAR) {
        if (c4_gui_api && c4_gui_api->win_clear) c4_gui_api->win_clear((int)sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == WRECT) {
        if (c4_gui_api && c4_gui_api->win_rect)
            c4_gui_api->win_rect((int)sp[5], sp[4], sp[3], sp[2], sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == WTEXT) {
        if (c4_gui_api && c4_gui_api->win_text)
            c4_gui_api->win_text((int)sp[4], sp[3], sp[2],
                                 (const char *)(unsigned long)sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == WUPD) {
        if (c4_gui_api && c4_gui_api->win_update) c4_gui_api->win_update((int)sp[0]);
        a = 0;
    }
    else if (i == BADD) {
        a = (c4_gui_api && c4_gui_api->btn_add)
            ? c4_gui_api->btn_add((int)sp[5], sp[4], sp[3], sp[2], sp[1],
                                  (const char *)(unsigned long)sp[0]) : -1;
    }
    else if (i == BCLICK) {
        a = (c4_gui_api && c4_gui_api->btn_clicked) ? c4_gui_api->btn_clicked((int)sp[0]) : -1;
    }
    else if (i == BSETLB) {
        if (c4_gui_api && c4_gui_api->btn_set_label)
            c4_gui_api->btn_set_label((int)sp[2], (int)sp[1],
                                      (const char *)(unsigned long)sp[0]);
        a = 0;
    }
    else { printf("unknown instruction = %d! cycle = %d\n", i, cycle); c4_free_pools(); return -1; }
  }

fail:
  /* метка обязана стоять ПОСЛЕДНЕЙ в c4_run — иначе нормальный путь
   * провалится в неё. Все ошибки компиляции освобождают пулы */
  c4_free_pools();
  return -1;
}


/* ---------- N2600-OS: c4_compile — вынести фазу компиляции отдельно ---------- */

/* c4_compile: скомпилировать исходник в байт-код (без запуска VM).
 *   src              — C-исходник (NUL-terminated)
 *   out              — буфер для диагностики ошибок
 *   out_max          — размер out
 *   bytecode         — куда записать пул байт-кода (int-ячейки)
 *   bytecode_max     — ёмкость в байтах
 *   bytecode_len_cells — записанная длина в int-ячейках (вых. параметр)
 *   data_seg         — куда записать сегмент данных
 *   data_seg_max     — ёмкость в байтах
 *   data_seg_len     — записанная длина в байтах (вых. параметр)
 *   entry_offset     — смещение main в int-ячейках от начала bytecode
 * Возвращает: 1 при успехе, 0 при ошибке компиляции. */
int c4_compile(const char *src, char *out, u32 out_max,
               void *bytecode, u32 bytecode_max, u32 *bytecode_len_cells,
               void *data_seg, u32 data_seg_max, u32 *data_seg_len,
               u32 *entry_offset)
{
    /* Настраиваем caller-буферы для c4_run (compile-only mode) */
    c4_compile_only = 1;
    c4_compile_bc_buf = (u8 *)bytecode;
    c4_compile_bc_max = bytecode_max;
    c4_compile_bc_len_cells = 0;
    c4_compile_data_buf = (u8 *)data_seg;
    c4_compile_data_max = data_seg_max;
    c4_compile_data_len = 0;
    c4_compile_entry_cells = 0;

    int r = c4_run(src, out, out_max);

    /* Сбрасываем флаги */
    c4_compile_only = 0;
    c4_compile_bc_buf = NULL;
    c4_compile_bc_max = 0;
    c4_compile_data_buf = NULL;
    c4_compile_data_max = 0;

    if (r != 0) {
        /* ошибка компиляции — c4_run вернул -1, диагностика в out */
        return 0;
    }

    /* Успешная компиляция — возвращаем результаты */
    if (bytecode_len_cells) *bytecode_len_cells = c4_compile_bc_len_cells;
    if (data_seg_len) *data_seg_len = c4_compile_data_len;
    if (entry_offset) *entry_offset = c4_compile_entry_cells;
    return 1;
}

/* c4_print_str: вывод строки в текущий выходной буфер c4 (если есть). */
void c4_print_str(const char *s, u32 len)
{
    if (!s) return;
    for (u32 i = 0; i < len; i++) c4_putc(s[i]);
}

/* c4_event_poll: опрос события ввода для c4-программ (нативных).
 * Паритет с VM-версией kevent: Esc → код 3 (выход). */
int c4_event_poll(void *out_buf)
{
    if (!out_buf) return 0;
    u8 *out = (u8 *)out_buf;
    key_event_t ev;
    if (kbd_pop(&ev)) {
        out[0] = ev.ch;
        out[1] = (u8)ev.code;
        out[2] = (u8)ev.flags;
        if (ev.ch == 0x1B || ev.code == 0x01) return 3;
        return 1;
    }
    return 0;
}

/* c4_printf_va: formatted print для native c4-программ.
 *   fmt           — форматная строка (с %d/%u/%s/%c/%x/%f/%e/%g)
 *   nargs         — число ЯЧЕЕК на стеке ВКЛЮЧАЯ fmt (как в c4 PRTF;
 *                   double-аргумент занимает 2 ячейки)
 *   args_reversed — массив ячеек (без fmt) в ОБРАТНОМ порядке:
 *                   args_reversed[0] = последняя ячейка последнего аргумента
 * Возвращает число записанных символов (в VM PRTF кладёт его в "a").
 * Запись идёт в текущий буфер c4_out.
 * Курсор cj — число ЯЧЕЕК source-аргументов, уже потреблённых; позиция
 * ячейки с индексом cj в args_reversed = actual-1-cj. Для double:
 * в source-порядке hi идёт раньше lo (пуш: hi, затем lo), поэтому
 *   hi = args[actual-1-cj], lo = args[actual-2-cj], cj += 2.
 * При НЕХВАТКЕ аргументов конверсия печатает 0/пустоту (паритет VM/native) */
int c4_printf_va(const char *fmt, int nargs, int *args_reversed)
{
    if (!fmt) return 0;
    int nprinted = 0;
    int actual = nargs - 1;   /* ячейки аргументов (без fmt) */
    if (actual < 0) actual = 0;
    int cj = 0;   /* курсор ячеек source-порядка */
    int wflag, wzero, left, prec;
    int plus, space;   /* флаги '+'/' ' */

    while (*fmt) {
        if (*fmt != '%') { c4_putc(*fmt++); nprinted++; continue; }
        fmt++;   /* skip '%' */
        c4_fmt_flags(&fmt, &wflag, &wzero, &left, &prec, &plus, &space);
        if (*fmt == 'l') fmt++;
        if (*fmt == 'd') {
            /* при нехватке аргументов печатаем 0 (с флагами) — паритет VM/native */
            int v = (cj < actual) ? args_reversed[actual - 1 - cj] : 0;
            cj++;
            nprinted += c4_put_num((long)v, 10, 1,
                                   wflag, wzero, left, plus, space);
            fmt++;
        }
        else if (*fmt == 'u') {
            unsigned v = (cj < actual) ? (unsigned)args_reversed[actual - 1 - cj] : 0;
            cj++;
            nprinted += c4_put_num((unsigned)v, 10, 0,
                                   wflag, wzero, left, 0, 0);
            fmt++;
        }
        else if (*fmt == 's') {
            const char *s = 0;
            if (cj < actual)
                s = (const char *)(unsigned long)args_reversed[actual - 1 - cj];
            cj++;
            int sl = 0; if (s) while (s[sl]) sl++;
            /* точность для %s (C89 §6.9.6.2): %.3s печатает не более 3 символов;
             * prec = -1, если не задана */
            if (prec >= 0 && sl > prec) sl = prec;
            nprinted += c4_put_pad(s ? s : "", sl, wflag, 0, left);
            fmt++;
        }
        else if (*fmt == 'c') {
            char cb[2];
            if (cj < actual) cb[0] = (char)args_reversed[actual - 1 - cj];
            else cb[0] = 0;
            cj++;
            nprinted += c4_put_pad(cb, 1, wflag, 0, left);
            fmt++;
        }
        else if (*fmt == 'x') {
            unsigned v = (cj < actual) ? (unsigned)args_reversed[actual - 1 - cj] : 0;
            cj++;
            nprinted += c4_put_num((unsigned)v, 16, 0,
                                   wflag, wzero, left, 0, 0);
            fmt++;
        }
        else if (*fmt == 'f' || *fmt == 'e' || *fmt == 'g') {
            /* double = 2 ячейки: hi первой в source-порядке (пуш hi, lo). Если ячеек
             * не хватает, печатаем 0.0 (u обнулён), а курсор cj сдвигается на 2
             * ВСЕГДА (иначе следующий %d читал бы чужой слот).
             * '+'/' ' НЕ идут в формат snprintf (мини-vsnprintf ядра печатал бы
             * «%+.6f» как мусор): знак добавляем сами; '-' у отрицательных ставит
             * snprintf */
            extern int snprintf(char *out, C4_SZT n, const char *fmt, ...);
            union { double d; int w[2]; } u;
            char fbuf[64], fs[12];
            int fi = 0, sl, j;
            u.w[0] = 0; u.w[1] = 0;
            if (cj + 1 < actual) {
                u.w[1] = args_reversed[actual - 1 - cj];   /* hi */
                u.w[0] = args_reversed[actual - 2 - cj];   /* lo */
            }
            cj += 2;
            fs[fi++] = '%'; fs[fi++] = '.';
            if (prec < 0) fs[fi++] = '6';
            else if (prec > 15) { fs[fi++] = '1'; fs[fi++] = '5'; }
            else if (prec >= 10) { fs[fi++] = (char)('0' + prec / 10);
                                   fs[fi++] = (char)('0' + prec % 10); }
            else fs[fi++] = (char)('0' + prec);
            fs[fi++] = *fmt; fs[fi] = 0;
            snprintf(fbuf, (C4_SZT)sizeof(fbuf), fs, u.d);
            sl = 0; while (fbuf[sl]) sl++;
            if ((plus || space) && sl > 0 && sl + 1 < (int)sizeof(fbuf) &&
                fbuf[0] != '-') {
                for (j = sl; j >= 0; j--) fbuf[j + 1] = fbuf[j];  /* сдвиг с NUL */
                fbuf[0] = plus ? '+' : ' ';
                sl++;
            }
            nprinted += c4_put_pad(fbuf, sl, wflag, wzero, left);
            fmt++;
        }
        else if (*fmt == '%') {
            c4_putc('%');
            nprinted++;
            fmt++;
        }
        else {
            /* Unknown format spec — output as-is */
            c4_putc('%');
            nprinted++;
            if (*fmt) { c4_putc(*fmt); nprinted++; fmt++; }
        }
    }
    return nprinted;
}

