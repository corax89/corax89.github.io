/* dfm.h — полноэкранный текстовый файловый менеджер для telnet N2600-OS
 * (Task 48). Адаптация модели dfm (Dylan Araps, dylanaraps/dfm, MIT) под
 * систему: канонический dfm рассчитан на POSIX (termios/dirent/arena) —
 * здесь воспроизведена его UI-МОДЕЛЬ (одна клавиша = одно действие,
 * vi-навигация, сортировки, поиск, перерисовка ANSI), а бэкенд — RAM disk,
 * ввод — посимвольный канал telnetd, вывод — тот же sink с \n → \r\n.
 *
 * Режимы:
 *   1 ОБЗОР    — полный экран (ANSI), посимвольный ввод: j/k/g/G движение,
 *                l/Enter открыть, h наверх, / поиск, s сорт, v вид,
 *                e правка, n новый файл, m каталог, d удалить, r обновить,
 *                q выход;
 *   2 РЕДАКТОР — построчный (ed-подобный, перенесён из tfm Task 46):
 *                l/v/s/a/d/w/wq/q; строка собирается telnetd;
 *   3 ПРОМПТ   — строка ввода для /, n, m (собирает telnetd);
 *   4 ПРОСМОТР — постраничный просмотр файла (j/k/g/G/Space/q).
 *
 * Модуль БЕЗ собственных потоков: все вызовы — из задачи telnetd
 * (последовательно по слотам, статические scratch-буферы допустимы).
 * Состояние встраивается в tnd_conn_t (статические слоты). */
#ifndef DFM_H
#define DFM_H

#include "types.h"
#include "ramfs.h"

#define DFM_ENTS_MAX  32     /* записей каталога в кэше */
#define DFM_ROWS      18     /* строк списка на экране */
#define DFM_CWD_MAX   100    /* текущий каталог (ramfs-путь, "" = корень) */
#define DFM_NAME_MAX  64     /* = RAMFS_NAME_MAX */
#define DFM_FILT_MAX  48     /* фильтр поиска */
#define DFM_ED_MAX    (16u * 1024u)   /* макс. размер файла в редакторе */
#define DFM_VIEW_MAX  (32u * 1024u)   /* макс. размер файла в просмотрщике */
#define DFM_MSG_MAX   72

/* mode: 0 = выкл, 1 = обзор, 2 = редактор, 3 = промпт, 4 = просмотр */
typedef struct dfm_s {
    int  mode;
    char cwd[DFM_CWD_MAX];     /* «», «www», «dir/sub» — без ведущего слеша */
    int  nents;                /* записей в кэше (уже после фильтра) */
    ramfs_dirent_t ents[DFM_ENTS_MAX];
    int  y;                    /* курсор по видимому списку */
    int  o;                    /* первая видимая строка окна */
    u8   sort;                 /* 0 имя, 1 имя↓, 2 размер, 3 размер↓ */
    u8   view;                 /* 0 имя, 1 имя+размер */
    char filt[DFM_FILT_MAX];   /* «» нет; «*abc» подстрока, иначе префикс */
    int  del_pending;          /* 1 = ждём y на удаление записи y */
    char msg[DFM_MSG_MAX];     /* строка состояния/ошибки */
    int  prompt_kind;          /* 0 нет, 1 поиск, 2 новый файл, 3 mkdir */
    /* просмотрщик */
    char vp_path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    char *vp;                  /* буфер файла (malloc) или 0 */
    u32  vp_len;
    u32  vp_top;               /* первая видимая строка (0-based) */
    u32  vp_lines;             /* всего строк в файле */
    int  vp_binary;            /* двоичный файл (текст не показываем) */
    /* редактор */
    char *ed;                  /* буфер файла (malloc) или 0 */
    u32   ed_len;
    int   ed_dirty;
    char  ed_path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    /* вывод (привязывается в dfm_enter; живёт до dfm_reset) */
    void (*out)(void *ud, const char *s);
    void *ud;
    /* сборка ESC-последовательности (стрелки) */
    u8   esc;
} dfm_t;

/* Сброс (выход/закрытие соединения); освобождает буферы редактора/просмотра. */
void dfm_reset(dfm_t *f);

/* 1 = менеджер активен (ввод идёт ему, а не shell). */
int  dfm_active(const dfm_t *f);

/* 1 = режим собирает СТРОКУ (редактор/промпт; telnetd использует свой
 * строковый ввод с эхом), 0 = посимвольный (обзор/просмотр). */
int  dfm_wants_line(const dfm_t *f);

/* Текст приглашения для режима строки (»/» поиска, «new:», «mkdir:»). */
void dfm_prompt_text(const dfm_t *f, char *out, int cap);

/* Войти в менеджер (перерисовать экран). out/ud запоминаются. */
void dfm_enter(dfm_t *f, void (*out)(void *ud, const char *s), void *ud);

/* Один байт ввода в ПОСИМВОЛЬНОМ режиме (обзор/просмотр; внутри —
 * сборка ESC-последовательностей стрелок). Перерисовывает экран. */
void dfm_key(dfm_t *f, unsigned char b);

/* Готовая строка из ПРОМПТА (поиск/новый файл/mkdir). */
void dfm_prompt_line(dfm_t *f, const char *line);

/* Готовая строка РЕДАКТОРА (l/v/s/a/d/w/wq/q). */
void dfm_edit_line(dfm_t *f, const char *line);

#endif /* DFM_H */
