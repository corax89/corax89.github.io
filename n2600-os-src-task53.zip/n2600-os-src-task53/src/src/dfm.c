/* dfm.c — полноэкранный текстовый файловый менеджер для telnet
 * (реализация, Task 48). Адаптация модели dfm (Dylan Araps,
 * dylanaraps/dfm, MIT-2.0) под N2600-OS: сама библиотека dfm
 * рассчитана на POSIX (termios, dirent, арену malloc, SIGWINCH) —
 * здесь её UI-модель воспроизведена над RAM disk и посимвольным
 * telnet-каналом. См. dfm.h (режимы, раскладка, встраивание).
 *
 * Правила строк: все snprintf с размерами, пути — только через
 * dfm_join/dfm_resolve с проверкой вместимости, индексы курсора
 * всегда клампятся к nents. Статические scratch-буферы безопасны:
 * весь модуль обслуживается ТОЛЬКО задачей telnetd (последовательно). */
#include "dfm.h"
#include "string.h"
#include "mem.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#define ANSI_CLR   "\033[H\033[2J"
#define ANSI_REV   "\033[7m"
#define ANSI_NORM  "\033[0m"

/* scratch для перечитывания каталога (одна задача telnetd) */
static ramfs_dirent_t dfm_scan_tmp[DFM_ENTS_MAX];
/* буфер сборки экрана (одна задача telnetd) */
static char dfm_draw_buf[4096];

/* ---------------- мелкие утилиты ---------------- */

static void dfm_say(dfm_t *f, const char *s)
{
    if (f->out) f->out(f->ud, s);
}

static void dfm_msg(dfm_t *f, const char *fmt, const char *a, unsigned b)
{
    snprintf(f->msg, sizeof(f->msg), fmt, a, b);
}

static char dfm_lo(char c)
{
    return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
}

/* регистронезависимое сравнение имён (ASCII) */
static int dfm_namecmp(const char *a, const char *b)
{
    while (*a && *b) {
        char ca = dfm_lo(*a), cb = dfm_lo(*b);
        if (ca != cb) return (int)(unsigned char)ca - (int)(unsigned char)cb;
        a++; b++;
    }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

/* dir + "/" + name (ramfs-путь без ведущего слеша). 0 = не влезло. */
static int dfm_join(char *out, int cap, const char *dir, const char *name)
{
    if (!dir[0]) {
        if ((int)strlen(name) >= cap) return 0;
        strcpy(out, name);
        return 1;
    }
    if (snprintf(out, (u32)cap, "%s/%s", dir, name) >= cap) return 0;
    return 1;
}

/* показать путь с ведущим слешем */
static void dfm_show(const char *path, char *out, int cap)
{
    if (!path[0]) snprintf(out, (u32)cap, "/");
    else          snprintf(out, (u32)cap, "/%s", path);
}

/* разрешить arg относительно cwd («.», «..», «/...», «dir/sub») */
static int dfm_resolve(const char *cwd, const char *arg, char *out, int cap)
{
    char acc[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (arg[0] == '/') acc[0] = 0;
    else snprintf(acc, sizeof(acc), "%s", cwd);
    const char *p = arg;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        char comp[DFM_NAME_MAX + 1];
        int ci = 0;
        while (*p && *p != '/' && ci < (int)sizeof(comp) - 1)
            comp[ci++] = *p++;
        comp[ci] = 0;
        if (!strcmp(comp, ".")) continue;
        if (!strcmp(comp, "..")) {
            char *sl = strrchr(acc, '/');
            if (sl) *sl = 0;
            else    acc[0] = 0;
            continue;
        }
        int L = (int)strlen(acc);
        if (L + 1 + ci >= (int)sizeof(acc)) return 0;
        if (L) acc[L++] = '/';
        strcpy(acc + L, comp);
    }
    if ((int)strlen(acc) >= cap) return 0;
    strcpy(out, acc);
    return 1;
}

/* «123» / «12.3К» / «1.2М» (u32 байт; людино-вид, как в dfm view=size) */
static void dfm_hsize(u32 sz, char *out, int cap)
{
    if (sz < 1024u)      snprintf(out, (u32)cap, "%uБ", (unsigned)sz);
    else if (sz < 1024u * 1024u)
        snprintf(out, (u32)cap, "%u.%uК", (unsigned)(sz >> 10),
                 (unsigned)((sz & 1023u) * 10u / 1024u));
    else
        snprintf(out, (u32)cap, "%u.%uМ", (unsigned)(sz >> 20),
                 (unsigned)((sz & (1024u * 1024u - 1u)) * 10u / (1024u * 1024u)));
}

/* ---------------- каталог: скан, фильтр, сортировка ---------------- */

/* 1 = запись проходит фильтр */
static int dfm_filter_ok(const dfm_t *f, const ramfs_dirent_t *e)
{
    const char *q = f->filt;
    if (!q[0]) return 1;
    if (*q == '*') {                       /* подстрока (dfm -q "*query") */
        q++;
        if (!q[0]) return 1;
        /* регистронезависимый strstr по имени */
        for (const char *n = e->name; *n; n++) {
            const char *a = n, *b = q;
            while (*a && *b && dfm_lo(*a) == dfm_lo(*b)) { a++; b++; }
            if (!*b) return 1;
        }
        return 0;
    }
    /* префикс (dfm -q query) */
    for (const char *n = e->name; ; n++, q++) {
        if (!*q) return 1;
        if (!*n) return 0;
        if (dfm_lo(*n) != dfm_lo(*q)) return 0;
    }
}

/* insertion sort: каталоги первыми, ключ по f->sort */
static void dfm_sort(dfm_t *f)
{
    for (int i = 1; i < f->nents; i++) {
        ramfs_dirent_t key = f->ents[i];
        int j = i - 1;
        while (j >= 0) {
            const ramfs_dirent_t *a = &f->ents[j], *b = &key;
            int c = 0;
            if (a->is_dir != b->is_dir) c = b->is_dir ? 1 : -1; /* каталоги вверх */
            else {
                switch (f->sort) {
                case 1:  c = dfm_namecmp(b->name, a->name); break;
                case 2:  c = (a->size < b->size) ? -1 : (a->size > b->size);
                         if (!c) c = dfm_namecmp(a->name, b->name);
                         break;
                case 3:  c = (a->size < b->size) ? 1 : (a->size > b->size);
                         if (!c) c = dfm_namecmp(a->name, b->name);
                         break;
                default: c = dfm_namecmp(a->name, b->name); break;
                }
            }
            if (c <= 0) break;
            f->ents[j + 1] = f->ents[j];
            j--;
        }
        f->ents[j + 1] = key;
    }
}

/* перечитать + отфильтровать + отсортировать; курсор по имени */
static void dfm_scan(dfm_t *f)
{
    char keep[DFM_NAME_MAX + 1];
    if (f->y >= 0 && f->y < f->nents)
        snprintf(keep, sizeof(keep), "%s", f->ents[f->y].name);
    else
        keep[0] = 0;

    f->nents = 0;
    if (ramfs_ready()) {
        int n = ramfs_list_dir(f->cwd[0] ? f->cwd : "/",
                               dfm_scan_tmp, DFM_ENTS_MAX);
        for (int i = 0; i < n && f->nents < DFM_ENTS_MAX; i++)
            if (dfm_filter_ok(f, &dfm_scan_tmp[i]))
                f->ents[f->nents++] = dfm_scan_tmp[i];
    }
    dfm_sort(f);

    /* восстановить курсор по имени (как fm_cursor_to в dfm) */
    f->y = 0;
    if (keep[0]) {
        for (int i = 0; i < f->nents; i++)
            if (!strcmp(f->ents[i].name, keep)) { f->y = i; break; }
    }
    if (f->y >= f->nents) f->y = f->nents - 1;
    if (f->y < 0) f->y = 0;
    f->o = f->y - DFM_ROWS / 2;
    if (f->o > f->nents - DFM_ROWS) f->o = f->nents - DFM_ROWS;
    if (f->o < 0) f->o = 0;
    f->del_pending = 0;
}

static const char *dfm_sort_name(u8 s)
{
    switch (s) {
    case 1:  return "имя↓";
    case 2:  return "размер";
    case 3:  return "размер↓";
    default: return "имя";
    }
}

static void dfm_set_msg(dfm_t *f, const char *s)
{
    snprintf(f->msg, sizeof(f->msg), "%s", s ? s : "");
}

/* ---------------- отрисовка ---------------- */

static void dfm_flush(dfm_t *f, char *buf, int *n)
{
    if (*n > 0) {
        buf[*n] = 0;
        dfm_say(f, buf);
        *n = 0;
    }
}

static void dfm_put(dfm_t *f, char *buf, int *n, const char *s)
{
    int L = 0;
    while (s[L]) L++;
    if (*n + L >= (int)sizeof(dfm_draw_buf) - 2) dfm_flush(f, buf, n);
    memcpy(buf + *n, s, (u32)L);
    *n += L;
}

static void dfm_draw(dfm_t *f)
{
    char *b = dfm_draw_buf;
    int n = 0;
    char line[DFM_NAME_MAX + 96];
    char show[DFM_CWD_MAX + 2];

    dfm_put(f, b, &n, ANSI_CLR);
    dfm_show(f->cwd, show, (int)sizeof(show));
    if (f->filt[0])
        snprintf(line, sizeof(line),
                 "dfm %s — %d эл. [сорт: %s | вид: %s] фильтр: %s",
                 show, f->nents, dfm_sort_name(f->sort),
                 f->view ? "имя+размер" : "имя", f->filt);
    else
        snprintf(line, sizeof(line),
                 "dfm %s — %d эл. [сорт: %s | вид: %s]",
                 show, f->nents, dfm_sort_name(f->sort),
                 f->view ? "имя+размер" : "имя");
    dfm_put(f, b, &n, line);
    dfm_put(f, b, &n, "\n----------------------------------------\n");

    if (f->nents == 0) {
        dfm_put(f, b, &n, "(пусто или фильтр не оставил записей)\n");
    }
    for (int i = f->o;
         i < f->nents && i < f->o + DFM_ROWS; i++) {
        const ramfs_dirent_t *e = &f->ents[i];
        char szs[16];
        dfm_hsize(e->size, szs, (int)sizeof(szs));
        if (f->view == 1 && !e->is_dir) {
            /* имя слева, размер справа (ширина колонки 40; наш snprintf
             * не умеет %*s — паддинг вручную) */
            char nm[DFM_NAME_MAX + 4];
            snprintf(nm, sizeof(nm), "%s%s", e->name,
                     e->is_dir ? "/" : "");
            int pad = 40 - (int)strlen(nm);
            int L2 = snprintf(line, sizeof(line), "%s", nm);
            for (int s = 0; s < pad && L2 < (int)sizeof(line) - 1; s++)
                line[L2++] = ' ';
            snprintf(line + L2, sizeof(line) - (u32)L2, "%s", szs);
        } else {
            snprintf(line, sizeof(line), "%s%s",
                     e->name, e->is_dir ? "/" : "");
        }
        if (i == f->y)
            dfm_put(f, b, &n, ANSI_REV);
        dfm_put(f, b, &n, i == f->y ? "> " : "  ");
        dfm_put(f, b, &n, line);
        if (i == f->y)
            dfm_put(f, b, &n, ANSI_NORM);
        dfm_put(f, b, &n, "\n");
    }
    /* пустые строки до низа окна — подпись не прыгает */
    for (int i = f->nents; i < f->o + DFM_ROWS; i++)
        dfm_put(f, b, &n, "\n");

    if (f->msg[0]) {
        dfm_put(f, b, &n, f->msg);
        dfm_put(f, b, &n, "\n");
    }
    dfm_put(f, b, &n,
            "j/k/стрелки движение  g/G верх/низ  l/Enter открыть  "
            "h наверх\n");
    dfm_put(f, b, &n,
            "/ поиск  s сорт  v вид  e правка  n файл  m каталог  "
            "d удалить\n");
    dfm_put(f, b, &n,
            "r обновить  q выход");
    dfm_flush(f, b, &n);
}

/* ---------------- действия ---------------- */

static void dfm_move(dfm_t *f, int d)
{
    if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
    int ny = f->y + d;
    if (ny < 0) ny = 0;
    if (ny >= f->nents) ny = f->nents - 1;
    f->y = ny;
    if (f->y < f->o) f->o = f->y;
    if (f->y >= f->o + DFM_ROWS) f->o = f->y - DFM_ROWS + 1;
    f->del_pending = 0;
    f->msg[0] = 0;
}

static void dfm_top(dfm_t *f)
{
    f->y = 0; f->o = 0;
    f->del_pending = 0;
    f->msg[0] = 0;
}

static void dfm_bottom(dfm_t *f)
{
    if (f->nents > 0) f->y = f->nents - 1;
    f->o = f->nents - DFM_ROWS;
    if (f->o < 0) f->o = 0;
    f->del_pending = 0;
    f->msg[0] = 0;
}

/* наверх (родитель); 1 = сменили каталог */
static int dfm_up(dfm_t *f)
{
    char *sl = strrchr(f->cwd, '/');
    if (sl) *sl = 0;
    else    f->cwd[0] = 0;
    f->del_pending = 0;
    f->msg[0] = 0;
    dfm_scan(f);
    return 1;
}

static void dfm_view_file(dfm_t *f, const ramfs_dirent_t *e);
static void dfm_view_draw(dfm_t *f);
static void dfm_ed_open_path(dfm_t *f, const char *path);

/* l/Enter на записи под курсором */
static void dfm_open(dfm_t *f)
{
    if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
    ramfs_dirent_t *e = &f->ents[f->y];
    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (e->is_dir) {
        if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
            dfm_set_msg(f, "Слишком длинный путь");
            return;
        }
        snprintf(f->cwd, sizeof(f->cwd), "%s", path);
        f->y = 0; f->o = 0;
        f->msg[0] = 0;
        f->del_pending = 0;
        dfm_scan(f);
        return;
    }
    if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
        dfm_set_msg(f, "Слишком длинный путь");
        return;
    }
    dfm_view_file(f, e);
}

/* ---------------- просмотрщик (режим 4) ---------------- */

static u32 dfm_count_lines(const char *b, u32 len)
{
    u32 n = 0;
    for (u32 i = 0; i < len; i++)
        if (b[i] == '\n') n++;
    if (len && b[len - 1] != '\n') n++;
    return n;
}

static void dfm_view_file(dfm_t *f, const ramfs_dirent_t *e)
{
    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
        dfm_set_msg(f, "Слишком длинный путь");
        return;
    }
    if (e->size > DFM_VIEW_MAX) {
        dfm_msg(f, "Файл больше %u КиБ просмотрщик не тянет (e — правка)",
                NULL, (unsigned)(DFM_VIEW_MAX / 1024));
        return;
    }
    char *buf = (char *)malloc(e->size ? e->size : 1);
    if (!buf) { dfm_set_msg(f, "Нет памяти под просмотр"); return; }
    u32 got = ramfs_read(path, buf, e->size ? e->size : 1);
    int binary = 0;
    for (u32 i = 0; i < got && i < 64; i++) {
        u8 c = (u8)buf[i];
        if (c < 32 && c != '\t' && c != '\n' && c != '\r') { binary = 1; break; }
    }
    if (binary) {
        free(buf);
        dfm_msg(f, "%s: двоичный файл (%u байт)", e->name, (unsigned)e->size);
        return;
    }
    if (f->vp) free(f->vp);
    f->vp = buf;
    f->vp_len = got;
    f->vp_top = 0;
    f->vp_lines = dfm_count_lines(buf, got);
    f->vp_binary = 0;
    snprintf(f->vp_path, sizeof(f->vp_path), "%s", path);
    f->mode = 4;
    f->msg[0] = 0;
    dfm_view_draw(f);        /* именно экран просмотра, НЕ обзора */
}

static void dfm_view_close(dfm_t *f)
{
    if (f->vp) { free(f->vp); f->vp = 0; }
    f->vp_len = 0;
    f->vp_top = 0;
    f->vp_lines = 0;
    f->mode = 1;
    f->msg[0] = 0;
    dfm_scan(f);
    dfm_draw(f);
}

/* строка no (0-based) буфера просмотра: off/len без \n */
static int dfm_view_line(const char *b, u32 len, u32 no, u32 *off, u32 *lno)
{
    u32 cur = 0, i = 0;
    while (i < len) {
        if (cur == no) {
            u32 j = i;
            while (j < len && b[j] != '\n') j++;
            *off = i; *lno = j - i;
            return 1;
        }
        while (i < len && b[i] != '\n') i++;
        if (i < len) i++;
        cur++;
    }
    return 0;
}

static void dfm_view_draw(dfm_t *f)
{
    char *b = dfm_draw_buf;
    int n = 0;
    char line[DFM_CWD_MAX + DFM_NAME_MAX + 64];
    char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
    dfm_put(f, b, &n, ANSI_CLR);
    dfm_show(f->vp_path, show, (int)sizeof(show));
    u32 last = f->vp_top + DFM_ROWS;
    snprintf(line, sizeof(line),
             "просмотр %s — строки %u..%u из %u",
             show, (unsigned)(f->vp_top + 1),
             (unsigned)(last < f->vp_lines ? last : f->vp_lines),
             (unsigned)f->vp_lines);
    dfm_put(f, b, &n, line);
    dfm_put(f, b, &n, "\n----------------------------------------\n");
    for (u32 r = 0; r < DFM_ROWS; r++) {
        u32 no = f->vp_top + r;
        u32 off = 0, L = 0;
        if (!dfm_view_line(f->vp, f->vp_len, no, &off, &L)) break;
        if (L > 96) L = 96;
        char seg[100];
        memcpy(seg, f->vp + off, L);
        seg[L] = 0;
        dfm_put(f, b, &n, seg);
        dfm_put(f, b, &n, "\n");
    }
    dfm_put(f, b, &n,
            "j/k прокрутка  Space страница  g/G верх/низ  q назад");
    dfm_flush(f, b, &n);
}

static void dfm_view_key(dfm_t *f, unsigned char b)
{
    switch (b) {
    case 'j':
        if (f->vp_top + DFM_ROWS < f->vp_lines) f->vp_top++;
        break;
    case 'k':
        if (f->vp_top > 0) f->vp_top--;
        break;
    case ' ':
        if (f->vp_top + DFM_ROWS < f->vp_lines) f->vp_top += DFM_ROWS;
        break;
    case 'g': f->vp_top = 0; break;
    case 'G':
        f->vp_top = (f->vp_lines > DFM_ROWS) ? f->vp_lines - DFM_ROWS : 0;
        break;
    case 'q': case 'h': case 0x03:
        dfm_view_close(f);
        return;
    default: return;
    }
    dfm_view_draw(f);
}

/* ---------------- редактор (построчный; из tfm Task 46) ---------------- */

static u32 dfm_ed_lines(const char *b, u32 len)
{
    u32 n = 0;
    for (u32 i = 0; i < len; i++)
        if (b[i] == '\n') n++;
    if (len && b[len - 1] != '\n') n++;
    return n;
}

static u32 dfm_ed_line_off(const char *b, u32 len, u32 no, u32 *out_len)
{
    u32 cur = 1, i = 0;
    while (i < len) {
        if (cur == no) {
            u32 j = i;
            while (j < len && b[j] != '\n') j++;
            *out_len = j - i;
            return i;
        }
        while (i < len && b[i] != '\n') i++;
        if (i < len) i++;
        cur++;
    }
    return 0;
}

static void dfm_ed_open_path(dfm_t *f, const char *path)
{
    if (f->ed) { dfm_set_msg(f, "Редактор уже открыт"); return; }
    f->ed = (char *)malloc(DFM_ED_MAX);
    if (!f->ed) { dfm_set_msg(f, "Нет памяти под редактор"); return; }
    f->ed_len = 0;
    f->ed_dirty = 0;
    ramfs_dirent_t de;
    if (ramfs_stat_ci(path, &de) && !de.is_dir && de.size > 0) {
        u32 cap = de.size < DFM_ED_MAX ? de.size : DFM_ED_MAX;
        f->ed_len = ramfs_read(path, f->ed, cap);
        f->ed[f->ed_len] = 0;
    }
    snprintf(f->ed_path, sizeof(f->ed_path), "%s", path);
    f->mode = 2;
    char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
    dfm_show(path, show, (int)sizeof(show));
    char line[DFM_CWD_MAX + DFM_NAME_MAX + 64];
    snprintf(line, sizeof(line), "Редактор: %s (%u байт, %u строк)",
             show, (unsigned)f->ed_len,
             (unsigned)dfm_ed_lines(f->ed, f->ed_len));
    dfm_say(f, line);
    if (f->ed_len == 0) dfm_say(f, "(файл пуст/новый)");
    dfm_say(f, "Команды: l - список строк; v <N> - показать строку;");
    dfm_say(f, "  s <N> <текст> - заменить строку; a <N> <текст> - вставить ПОСЛЕ строки N (a 0 - в начало);");
    dfm_say(f, "  d <N> - удалить строку; w - записать; wq - записать и выйти; q - выйти БЕЗ записи.");
    dfm_say(f, "  Строка ввода ограничена длиной telnet-строки (~80 символов).");
}

static void dfm_ed_save(dfm_t *f)
{
    /* перезапись: создать поверх (create после delete) */
    ramfs_delete(f->ed_path);
    if (!ramfs_create(f->ed_path, f->ed_len ? f->ed_len : 1)) {
        dfm_set_msg(f, "Не удалось создать файл (место/длина имени?)");
        dfm_say(f, f->msg);
        return;
    }
    if (f->ed_len && !ramfs_write(f->ed_path, f->ed, f->ed_len)) {
        ramfs_delete(f->ed_path);
        dfm_set_msg(f, "Ошибка записи");
        dfm_say(f, f->msg);
        return;
    }
    f->ed_dirty = 0;
    char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
    dfm_show(f->ed_path, show, (int)sizeof(show));
    char line[DFM_CWD_MAX + DFM_NAME_MAX + 48];
    snprintf(line, sizeof(line), "Записано: %s (%u байт)",
             show, (unsigned)f->ed_len);
    dfm_say(f, line);
}

static void dfm_ed_close(dfm_t *f, int saved)
{
    if (f->ed) free(f->ed);
    f->ed = 0;
    f->ed_len = 0;
    f->ed_dirty = 0;
    f->mode = 1;
    if (!saved) dfm_say(f, "Выход БЕЗ записи (правки потеряны)");
    dfm_scan(f);
    dfm_draw(f);
}

static void dfm_ed_list(dfm_t *f)
{
    char line[DFM_NAME_MAX + 24];
    u32 n = dfm_ed_lines(f->ed, f->ed_len);
    if (!n) { dfm_say(f, "(пусто)"); return; }
    u32 shown = 0;
    for (u32 no = 1; no <= n && shown < 200; no++, shown++) {
        u32 L = 0;
        u32 off = dfm_ed_line_off(f->ed, f->ed_len, no, &L);
        if (!off && L == 0 && no > 1) break;
        if (L > 80) L = 80;
        char seg[96];
        memcpy(seg, f->ed + off, L);
        seg[L] = 0;
        snprintf(line, sizeof(line), "%3u| %s", (unsigned)no, seg);
        dfm_say(f, line);
    }
    if (shown < n) {
        snprintf(line, sizeof(line), "... (показано %u из %u строк)",
                 shown, n);
        dfm_say(f, line);
    }
}

static int dfm_ed_insert(dfm_t *f, u32 after, const char *text)
{
    u32 tlen = (u32)strlen(text);
    if (f->ed_len + tlen + 1 > DFM_ED_MAX) return 0;
    u32 nlines = dfm_ed_lines(f->ed, f->ed_len);
    u32 off = 0;
    if (after > 0) {
        if (after <= nlines) {
            u32 L;
            off = dfm_ed_line_off(f->ed, f->ed_len, after, &L);
            off += L;
            if (off < f->ed_len) off++;
            else if (off > 0 && f->ed[off - 1] != '\n') {
                if (f->ed_len + 1 > DFM_ED_MAX) return 0;
                f->ed[off] = '\n';
                f->ed_len++;
                off++;
            }
        } else if (after == nlines + 1) {
            off = f->ed_len;
            if (off > 0 && f->ed[off - 1] != '\n') {
                if (f->ed_len + 1 > DFM_ED_MAX) return 0;
                f->ed[off] = '\n';
                f->ed_len++;
                off++;
            }
        } else return 0;
    }
    memmove(f->ed + off + tlen + 1, f->ed + off, f->ed_len - off);
    memcpy(f->ed + off, text, tlen);
    f->ed[off + tlen] = '\n';
    f->ed_len += tlen + 1;
    f->ed[f->ed_len] = 0;
    return 1;
}

static int dfm_ed_delete(dfm_t *f, u32 no)
{
    u32 L = 0;
    u32 off = dfm_ed_line_off(f->ed, f->ed_len, no, &L);
    if (!off && L == 0 && no > 1) return 0;
    u32 nl = (off + L < f->ed_len) ? 1 : 0;
    memmove(f->ed + off, f->ed + off + L + nl, f->ed_len - off - L - nl);
    f->ed_len -= L + nl;
    f->ed[f->ed_len] = 0;
    return 1;
}

static int dfm_ed_replace(dfm_t *f, u32 no, const char *text)
{
    if (!dfm_ed_delete(f, no)) return 0;
    return dfm_ed_insert(f, no - 1, text);
}

void dfm_edit_line(dfm_t *f, const char *line)
{
    if (f->mode != 2 || !f->ed) return;
    char cmd[DFM_CWD_MAX + 8];
    snprintf(cmd, sizeof(cmd), "%s", line ? line : "");

    char line2[DFM_NAME_MAX + 40];
    if (!strcmp(cmd, "q") || !strcmp(cmd, "quit")) {
        int was_dirty = f->ed_dirty;
        dfm_ed_close(f, 0);
        if (!was_dirty) dfm_say(f, "Выход из редактора");
        return;
    }
    if (!strcmp(cmd, "wq")) {
        dfm_ed_save(f);
        if (!f->ed_dirty) dfm_ed_close(f, 1);
        return;
    }
    if (!strcmp(cmd, "w") || !strcmp(cmd, "write")) { dfm_ed_save(f); return; }
    if (!strcmp(cmd, "l") || !strcmp(cmd, "list")) { dfm_ed_list(f); return; }
    if (cmd[0] == 'v' && (cmd[1] == ' ' || cmd[1] == 0)) {
        u32 no = 0;
        for (const char *p = cmd + 2; *p >= '0' && *p <= '9'; p++)
            no = no * 10 + (u32)(*p - '0');
        u32 L = 0;
        u32 off = no ? dfm_ed_line_off(f->ed, f->ed_len, no, &L) : 0;
        if (!no || (!off && L == 0 && no > 1)) {
            dfm_say(f, "Нет такой строки (l — список)");
        } else {
            if (L > 80) L = 80;
            char seg[96];
            memcpy(seg, f->ed + off, L);
            seg[L] = 0;
            snprintf(line2, sizeof(line2), "%3u| %s", (unsigned)no, seg);
            dfm_say(f, line2);
        }
        return;
    }
    if ((cmd[0] == 's' || cmd[0] == 'a') && cmd[1] == ' ') {
        u32 no = 0;
        const char *p = cmd + 2;
        while (*p >= '0' && *p <= '9') { no = no * 10 + (u32)(*p - '0'); p++; }
        while (*p == ' ') p++;
        const char *text = p;
        if (!text[0]) { dfm_say(f, "Нужен текст: s|a <N> <текст>"); return; }
        if (cmd[0] == 'a' && no == 0) {
            if (dfm_ed_insert(f, 0, text)) {
                f->ed_dirty = 1;
                dfm_say(f, "Вставлено в начало");
            } else dfm_say(f, "Нет места в буфере");
            return;
        }
        if (no == 0) { dfm_say(f, "Номер строки: 1..N"); return; }
        u32 n = dfm_ed_lines(f->ed, f->ed_len);
        if (no > n + (cmd[0] == 'a' ? 1 : 0)) {
            snprintf(line2, sizeof(line2), "Строк всего %u (l — список)", n);
            dfm_say(f, line2);
            return;
        }
        if (cmd[0] == 's') {
            if (dfm_ed_replace(f, no, text)) {
                f->ed_dirty = 1;
                snprintf(line2, sizeof(line2), "Строка %u заменена",
                         (unsigned)no);
                dfm_say(f, line2);
            } else dfm_say(f, "Нет такой строки");
        } else {
            if (dfm_ed_insert(f, no, text)) {
                f->ed_dirty = 1;
                snprintf(line2, sizeof(line2), "Вставлено после строки %u",
                         (unsigned)no);
                dfm_say(f, line2);
            } else dfm_say(f, "Нет места в буфере");
        }
        return;
    }
    if (cmd[0] == 'd' && cmd[1] == ' ') {
        u32 no = 0;
        for (const char *p = cmd + 2; *p >= '0' && *p <= '9'; p++)
            no = no * 10 + (u32)(*p - '0');
        if (!no || !dfm_ed_delete(f, no)) {
            dfm_say(f, "Нет такой строки (l — список)");
        } else {
            f->ed_dirty = 1;
            snprintf(line2, sizeof(line2), "Строка %u удалена",
                     (unsigned)no);
            dfm_say(f, line2);
        }
        return;
    }
    dfm_say(f, "Неизвестная команда редактора (l, v/s/a/d <N>, w, wq, q)");
}

/* ---------------- удаление ---------------- */

static void dfm_delete_cursor(dfm_t *f)
{
    if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
    ramfs_dirent_t *e = &f->ents[f->y];
    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
        dfm_set_msg(f, "Слишком длинный путь");
        return;
    }
    if (ramfs_delete(path)) {
        dfm_msg(f, "Удалено: %s", e->name, 0);
        dfm_scan(f);
    } else {
        dfm_set_msg(f, e->is_dir ? "Каталог не пуст (или не найден)"
                                  : "Не удалось удалить (не найден?)");
    }
    f->del_pending = 0;
}

/* ---------------- промпты (строковый режим) ---------------- */

void dfm_prompt_text(const dfm_t *f, char *out, int cap)
{
    switch (f->prompt_kind) {
    case 1:  snprintf(out, (u32)cap, "поиск: ");  break;
    case 2:  snprintf(out, (u32)cap, "new: ");    break;
    case 3:  snprintf(out, (u32)cap, "mkdir: ");  break;
    default: snprintf(out, (u32)cap, "? ");       break;
    }
}

void dfm_prompt_line(dfm_t *f, const char *line)
{
    if (f->mode != 3) return;
    int kind = f->prompt_kind;
    f->prompt_kind = 0;
    f->mode = 1;

    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (kind == 1) {                        /* поиск */
        snprintf(f->filt, sizeof(f->filt), "%s", line ? line : "");
        /* '*' в начале — как в dfm (подстрока); храним как ввели */
        dfm_scan(f);
        if (f->filt[0] && f->nents == 0)
            dfm_set_msg(f, "Фильтр: ни одной записи");
        dfm_draw(f);
        return;
    }
    if (kind == 2) {                        /* новый файл → редактор */
        if (!line || !line[0]) {
            dfm_set_msg(f, "Имя файла не задано");
            dfm_draw(f);
            return;
        }
        if (!dfm_resolve(f->cwd, line, path, (int)sizeof(path))) {
            dfm_set_msg(f, "Слишком длинный путь");
            dfm_draw(f);
            return;
        }
        ramfs_dirent_t ex;
        if (ramfs_stat_ci(path, &ex) && ex.is_dir) {
            dfm_set_msg(f, "Это имя занято каталогом");
            dfm_draw(f);
            return;
        }
        if (!ramfs_stat_ci(path, &ex)) {
            /* размер 0: файл ПУСТОЙ (иначе 1-й NUL-байт редактор сочтёт
             * строкой; ramfs_create нулевой размер принимает) */
            if (!ramfs_create(path, 0)) {
                dfm_set_msg(f, "Не удалось создать (место/имя?)");
                dfm_draw(f);
                return;
            }
            dfm_scan(f);
        }
        dfm_ed_open_path(f, path);
        return;
    }
    if (kind == 3) {                        /* mkdir */
        if (!line || !line[0]) {
            dfm_set_msg(f, "Имя каталога не задано");
            dfm_draw(f);
            return;
        }
        if (!dfm_resolve(f->cwd, line, path, (int)sizeof(path))) {
            dfm_set_msg(f, "Слишком длинный путь");
            dfm_draw(f);
            return;
        }
        if (ramfs_mkdir(path)) {
            char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
            dfm_show(path, show, (int)sizeof(show));
            dfm_msg(f, "Каталог создан: %s", show, 0);
            dfm_scan(f);
        } else {
            dfm_set_msg(f, "Не удалось (родителя нет/имя занято)");
        }
        dfm_draw(f);
        return;
    }
    dfm_draw(f);
}

/* ---------------- клавиатура обзора (режим 1) ---------------- */

static void dfm_browse_key(dfm_t *f, unsigned char b)
{
    switch (b) {
    case 'j': dfm_move(f, +1); return;
    case 'k': dfm_move(f, -1); return;
    case 'g': dfm_top(f);      return;
    case 'G': dfm_bottom(f);   return;
    case 'h': dfm_up(f);       return;
    case 'l': case '\r': case '\n':
        dfm_open(f);
        return;
    case 'r': case 0x0C:
        f->msg[0] = 0;
        dfm_scan(f);
        return;
    case 's':
        f->sort = (u8)((f->sort + 1) & 3);
        dfm_scan(f);
        return;
    case 'v':
        f->view = (u8)(f->view ? 0 : 1);
        f->msg[0] = 0;
        return;
    case '/':
        f->mode = 3;
        f->prompt_kind = 1;
        f->msg[0] = 0;
        dfm_say(f, "\n");
        return;
    case 'n':
        f->mode = 3;
        f->prompt_kind = 2;
        dfm_say(f, "\n");
        return;
    case 'm':
        f->mode = 3;
        f->prompt_kind = 3;
        dfm_say(f, "\n");
        return;
    case 'e': {
        if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
        ramfs_dirent_t *e = &f->ents[f->y];
        if (e->is_dir) { dfm_set_msg(f, "Это каталог (l — войти)"); return; }
        if (e->size > DFM_ED_MAX) {
            dfm_msg(f, "Файл больше %u КиБ редактор не тянет",
                    NULL, (unsigned)(DFM_ED_MAX / 1024));
            return;
        }
        char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
        if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
            dfm_set_msg(f, "Слишком длинный путь");
            return;
        }
        f->msg[0] = 0;
        dfm_say(f, "\n");
        dfm_ed_open_path(f, path);
        return;
    }
    case 'd':
        if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
        if (!f->del_pending) {
            f->del_pending = 1;
            dfm_msg(f, "Удалить %s? y — да, прочее — отмена",
                    f->ents[f->y].name, 0);
        }
        return;
    case 'y': case 'Y':
        if (f->del_pending) { dfm_delete_cursor(f); return; }
        break;
    case 'q': case 0x03:
        f->mode = 0;
        f->prompt_kind = 0;
        f->del_pending = 0;
        dfm_say(f, "\nВыход из файлового менеджера dfm\n");
        return;
    default:
        f->del_pending = 0;
        f->msg[0] = 0;
        return;
    }
}

/* ---------------- публичный ввод ---------------- */

void dfm_key(dfm_t *f, unsigned char b)
{
    if (f->mode == 4) {
        /* сборка стрелок в просмотрщике не нужна — простые клавиши;
         * ESC-последовательность проглатываем */
        if (b == 0x1B) { f->esc = 1; return; }
        if (f->esc == 1) {
            f->esc = 0;
            if (b == '[') { f->esc = 2; return; }
            return;
        }
        if (f->esc == 2) {
            f->esc = 0;
            switch (b) {
            case 'A': dfm_view_key(f, 'k'); return;
            case 'B': dfm_view_key(f, 'j'); return;
            case 'C': case 'D': default: return;
            }
        }
        dfm_view_key(f, b);
        return;
    }
    if (f->mode != 1) return;               /* строковые режимы — мимо */

    /* ESC-последовательности (стрелки): 1B 5B [A|B|C|D] */
    if (f->esc == 1) {
        f->esc = 0;
        if (b == '[') { f->esc = 2; return; }
        return;                              /* ESC + прочее — игнор */
    }
    if (f->esc == 2) {
        f->esc = 0;
        switch (b) {
        case 'A': dfm_move(f, -1); dfm_draw(f); return;
        case 'B': dfm_move(f, +1); dfm_draw(f); return;
        case 'C': dfm_open(f);     dfm_draw(f); return;
        case 'D': dfm_up(f);       dfm_draw(f); return;
        default: return;
        }
    }
    if (b == 0x1B) { f->esc = 1; return; }

    /* подтверждение удаления ловим ДО browse_key (y/g/Y — буквы) */
    if (f->del_pending && b != 'y' && b != 'Y') {
        f->del_pending = 0;
        dfm_set_msg(f, "Удаление отменено");
        dfm_draw(f);
        return;
    }
    dfm_browse_key(f, b);
    if (f->mode == 1) dfm_draw(f);
}

/* ---------------- жизненный цикл ---------------- */

void dfm_enter(dfm_t *f, void (*out)(void *ud, const char *s), void *ud)
{
    f->out = out;
    f->ud = ud;
    f->mode = 1;
    f->prompt_kind = 0;
    f->del_pending = 0;
    f->esc = 0;
    f->msg[0] = 0;
    f->y = 0;
    f->o = 0;
    dfm_scan(f);
    dfm_draw(f);
}

int dfm_active(const dfm_t *f)     { return f->mode ? 1 : 0; }
int dfm_wants_line(const dfm_t *f) { return (f->mode == 2 || f->mode == 3); }

void dfm_reset(dfm_t *f)
{
    if (f->ed) free(f->ed);
    if (f->vp) free(f->vp);
    memset(f, 0, sizeof(*f));
    f->mode = 0;
}
