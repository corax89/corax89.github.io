/* ntfs.c — драйвер NTFS (только чтение), сессия 11.
 *
 * ЗАЧЕМ: НЖМД нетбука ASUS X101CH размечен под Windows — раздел NTFS.
 * Драйвер читает структуру тома: boot-сектор → $MFT → записи FILE →
 * атрибуты. Каталоги собираются из $INDEX_ROOT (малые, resident) и
 * $INDEX_ALLOCATION (INDX-блоки в data runs). Файлы — $DATA resident
 * или non-resident (data runs + sparse + LZNT1-сжатие).
 *
 * Источники формата: linux-ntfs project (ntfs-3g), "NTFS Documentation"
 * (http://dubeyko.com/development/FileSystems/NTFS/ntfsdoc.pdf).
 *
 * Все чтения — через disk-слой (AHCI/ATA) с базой раздела из MBR.
 */
#include "ntfs.h"
#include "disk.h"
#include "mem.h"
#include "string.h"
#include "sync.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);

/* ============================ состояние тома ============================ */

static int   g_ready = 0;
static char  g_label[32] = "NTFS";
static char  g_error[64] = "";

static u32   g_part_base = 0;          /* LBA начала раздела */
static u32   g_part_sectors = 0;
static u8    g_spc = 1;                /* секторов в кластере */
static u32   g_cluster_sectors = 1;
static u64   g_mft_lcn = 0;            /* $MFT: кластер запуска */
static u32   g_mft_rec_size = 1024;    /* размер записи MFT, байт */
static u32   g_indx_size = 4096;       /* размер INDX-блока, байт */
static u8   *g_rec = NULL;             /* буфер записи MFT (fixup применён) */
static u8   *g_blk = NULL;             /* буфер INDX-блока / данных */
static u8   *g_blk2 = NULL;            /* второй буфер (чтение сжатых CU) */
static volatile int g_lock = 0;

/* ============================ маленькие хелперы ============================ */

static u16 rd16(const u8 *p) { return (u16)(p[0] | (p[1] << 8)); }
static u32 rd32(const u8 *p)
{
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}
static u64 rd64(const u8 *p) { return (u64)rd32(p) | ((u64)rd32(p + 4) << 32); }

int ntfs_ready(void)   { return g_ready; }

/* Сессия 12: снять монтирование — вызывается форматированием диска
 * (Настройки → Диски): NTFS-структур больше нет, файловый менеджер
 * должен забыть о старом разделе. */
void ntfs_invalidate(void) { g_ready = 0; }
const char *ntfs_label(void) { return g_label; }
const char *ntfs_error(void) { return g_error; }

static void ntfs_err(const char *msg)
{
    snprintf(g_error, sizeof(g_error), "%s", msg);
    serial_puts("[ntfs] ");
    serial_puts(msg);
    serial_puts("\n");
}

/* ============================ чтение секторов ============================ */

/* Сектор ВНУТРИ раздела (offset от начала раздела): rd_* добавляет
 * базу g_part_base сама — все LBA ниже относительные. */
static int rd_sector(u32 lba, void *buf)
{
    return disk_hdd_read(g_part_base + lba, 1, buf);
}

static int rd_sectors(u32 lba, int n, void *buf)
{
    u8 *p = (u8 *)buf;
    while (n-- > 0) {
        if (!rd_sector(lba++, p)) return 0;
        p += 512;
    }
    return 1;
}

/* ============================ fixup записи ============================ */

/* Применить Update Sequence Array: у записи MFT/INDX каждые 512 байт
 * последний u16 сектора заменён на USN; USA[i+1] содержит оригиналы.
 * Возвращает 1 при успехе. */
static int apply_fixup(u8 *buf, u32 size)
{
    if (size < 512 || (size % 512) != 0) return 0;
    u16 usn_off = rd16(buf + 4);
    u16 usn_cnt = rd16(buf + 6);
    u32 sectors = size / 512;
    if (usn_cnt != sectors + 1) return 0;
    if ((u32)usn_off + 2u * usn_cnt > size) return 0;
    const u8 *usa = buf + usn_off;
    u16 usn = rd16(usa);
    for (u32 s = 0; s < sectors; s++) {
        u8 *tail = buf + s * 512 + 510;
        if (rd16(tail) != usn) return 0;    /* запись битая */
        u16 orig = rd16(usa + 2 + s * 2);
        tail[0] = (u8)(orig & 0xFF);
        tail[1] = (u8)(orig >> 8);
    }
    return 1;
}

/* Прочитать запись MFT (номер записи, не MREF: низкие 48 бит).
 * Выполняется в g_rec (fixup применён). */
static int mft_read_record(u64 rec_no)
{
    u64 off = g_mft_lcn * (u64)g_cluster_sectors * 512u + rec_no * (u64)g_mft_rec_size;
    u32 lba = (u32)(off / 512u);
    if (!rd_sectors(lba, g_mft_rec_size / 512, g_rec)) return 0;
    if (memcmp(g_rec, "FILE", 4) != 0) return 0;
    if (!apply_fixup(g_rec, g_mft_rec_size)) return 0;
    if (!(rd16(g_rec + 0x16) & 0x0001)) return 0;   /* не in-use */
    return 1;
}

/* ============================ атрибуты ============================ */

typedef struct {
    u32 type;          /* 0x10/0x30/0x60/0x80/0x90/0xA0/0x100 */
    const u8 *hdr;     /* заголовок атрибута в записи */
    int non_res;       /* 1 = non-resident */
    /* resident: */
    const u8 *val;     /* значение */
    u32 val_len;
    /* non-resident: */
    u64 run_off;       /* смещение data runs от hdr */
    u64 alloc_sz, real_sz, init_sz;
    u16 flags;         /* 0x0001 compressed, 0x4000 sparse, 0x8000 encrypted */
    u16 comp_unit;     /* log2 кластеров в CU (0 = не сжат) */
} ntfs_attr_t;

/* Найти nth-й атрибут данного типа в записи. Возвращает 1 при успехе. */
static int attr_find(const u8 *rec, u32 type, int nth, ntfs_attr_t *out)
{
    u32 off = rd16(rec + 0x14);           /* offset to attributes */
    u32 used = rd32(rec + 0x18);
    int seen = 0;
    while (off + 8 <= used && off + 8 <= g_mft_rec_size) {
        u32 at = rd32(rec + off);
        if (at == 0xFFFFFFFF) break;      /* END */
        u32 len = rd32(rec + off + 4);
        if (len < 8 || off + len > g_mft_rec_size) break;
        if (at == type) {
            if (seen == nth) {
                memset(out, 0, sizeof(*out));
                out->type = at;
                out->hdr = rec + off;
                out->flags = rd16(rec + off + 0x0C);
                out->non_res = rec[off + 8];
                if (!out->non_res) {
                    out->val_len = rd32(rec + off + 0x10);
                    out->val = rec + off + rd16(rec + off + 0x14);
                } else {
                    out->run_off = rd16(rec + off + 0x20);
                    out->alloc_sz = rd64(rec + off + 0x28);
                    out->real_sz = rd64(rec + off + 0x30);
                    out->init_sz = rd64(rec + off + 0x38);
                    out->comp_unit = rd16(rec + off + 0x22);
                }
                return 1;
            }
            seen++;
        }
        off += len;
    }
    return 0;
}

/* Есть ли $ATTRIBUTE_LIST (атрибуты частями в других записях). */
static int attr_find_in_list(const u8 *rec, u32 type, ntfs_attr_t *out)
{
    ntfs_attr_t al;
    if (!attr_find(rec, 0x100, 0, &al)) return 0;
    if (al.non_res || al.val_len < 0x20) return 0;
    /* элементы: type u32, len u16, namelen u8, nameoff u8, VCN u64,
     * base MREF u64, [имя] — ищем элемент с нужным type и VCN=0 */
    u32 pos = 0;
    while (pos + 0x18 <= al.val_len) {
        const u8 *e = al.val + pos;
        u32 at = rd32(e);
        u32 elen = rd16(e + 4);
        if (elen < 0x18 || pos + elen > al.val_len) break;
        if (at == type && rd64(e + 8) == 0) {
            u64 base_mref = rd64(e + 0x10);
            u64 rec_no = base_mref & 0xFFFFFFFFFFFFull;
            if (!mft_read_record(rec_no)) return 0;
            if (!attr_find(g_rec, type, 0, out)) return 0;
            return 1;
        }
        pos += elen;
    }
    return 0;
}

/* ============================ data runs ============================ */

/* [NTFS-EXT] (полевой лог 17: «некоторые MP3 тут же ставятся на паузу»)
 * У фрагментированного файла список data runs не помещается в базовую
 * MFT-запись (1 КиБ): $DATA режется на ЭКСТЕНТЫ, хвост переносится в
 * дополнительные MFT-записи, перечисленные в $ATTRIBUTE_LIST (resident,
 * в базовой записи). Прежде читался только базовый экстент (VCN=0):
 * файл обрывался после нескольких сотен КиБ — плеер доигрывал обрывок
 * до EOF → finished → пауза; нефрагментированные игрались целиком —
 * отсюда «некоторые играют, некоторые встают».
 *
 * РАСКЛАДКА (сверено с эталонами): ntfs-3g runlist.c
 * ntfs_mapping_pairs_decompress_i начинает lcn=0 на КАЖДОЙ записи;
 * ntfs3 (fs/ntfs3/run.c) prev_lcn=0 на каждый буфер runs — цепочка
 * ОФСЕТОВ ПЕРЕЗАПУСКАЕТСЯ в каждой MFT-записи: первый офсет каждого
 * экстента — абсолютный LCN. Экстенты декодируются независимо и
 * склеиваются по VCN: lowest_vcn заголовка экстента = VCN из элемента
 * $ATTRIBUTE_LIST, highest_vcn — включительно, следующий экстент — с
 * highest+1. real_sz/флаги/comp_unit — всегда из БАЗОВОГО заголовка. */

#define NTFS_MAX_EXTENTS 16
#define NTFS_EXT_RUNS_MAX 1024       /* runs экстента <= записи MFT */

typedef struct {
    u64 start_vcn;                   /* lowest VCN экстента */
    u64 last_vcn;                    /* highest VCN (включительно) */
    const u8 *runs;                  /* mapping pairs (копия в g_ext_runs) */
    u32  runs_len;                   /* длина копии (до конца атрибута) */
    u64  mref;                       /* MFT-запись экстента (для логов) */
} ntfs_ext_t;

/* под блокировкой g_lock (заполняются load_data_extents на время чтения) */
static ntfs_ext_t g_exts[NTFS_MAX_EXTENTS];
static u8        *g_ext_runs = NULL;   /* NTFS_MAX_EXTENTS * 1 КиБ */

/* лог-помощник: не более 6 строк за загрузку (klog — кольцо) */
static u32 g_note_cnt = 0;
static void ntfs_note(const char *s)
{
    if (g_note_cnt++ >= 6u) return;
    serial_puts("[ntfs] ");
    serial_puts(s);
    serial_puts("\n");
}

/* Итератор по data runs: vcn → lcn. Возвращает 1, пока есть данные.
 * sparse-участки дают lcn = ~0 (заполнить нулями). */
typedef struct {
    const u8 *runs;      /* mapping pairs ТЕКУЩЕГО экстента */
    u32 pos;             /* позиция в потоке runs */
    u32 runs_len;        /* граница runs (конец атрибута/копии) */
    u64 vcn, last_vcn;   /* текущий/КОНЕЧНЫЙ VCN (последнего экстента) */
    i64 lcn;             /* LCN последнего run (накопительный, с 0 в каждом
                          * экстенте — цепочка офсетов перезапускается) */
    u64 run_vcn;         /* VCN начала текущего run */
    u64 run_len;
    /* [NTFS-EXT] таблица экстентов (NULL = один экстент из ntfs_attr_t) */
    const ntfs_ext_t *exts;
    int n_ext, ext_idx;
} run_iter_t;

static void runs_open(run_iter_t *it, const ntfs_attr_t *a)
{
    memset(it, 0, sizeof(*it));
    it->runs = a->hdr + a->run_off;
    u32 alen = rd32(a->hdr + 4);
    it->runs_len = (alen > (u32)a->run_off) ? (u32)(alen - a->run_off) : 0;
    it->last_vcn = rd64(a->hdr + 0x18);   /* end VCN (включительно) */
}

/* [NTFS-EXT] открыть итератор по таблице экстентов */
static void runs_open_multi(run_iter_t *it, const ntfs_ext_t *exts, int n)
{
    memset(it, 0, sizeof(*it));
    it->exts = exts;
    it->n_ext = n;
    it->runs = exts[0].runs;
    it->runs_len = exts[0].runs_len;
    it->last_vcn = exts[n - 1].last_vcn;  /* глобальный конец */
}

static int runs_next(run_iter_t *it)
{
    for (;;) {
        if (it->vcn > it->last_vcn) return 0;
        u8 hdr = (it->pos < it->runs_len) ? it->runs[it->pos] : 0;
        if (hdr == 0) {
            /* runs текущего экстента кончились: [NTFS-EXT] перейти к
             * следующему — цепочка офсетов ПЕРЕЗАПУСКАЕТСЯ (lcn снова
             * с 0), VCN продолжается со стыка highest+1 (проверен при
             * загрузке); для одиночного экстента (exts==NULL) — конец */
            if (it->exts && it->ext_idx + 1 < it->n_ext) {
                const ntfs_ext_t *e = &it->exts[++it->ext_idx];
                if (e->start_vcn != it->vcn) return 0;   /* разрыв — стой */
                it->runs = e->runs;
                it->runs_len = e->runs_len;
                it->pos = 0;
                it->lcn = 0;
                continue;
            }
            return 0;
        }
        const u8 *p = it->runs + it->pos;
        u8 len_sz = hdr & 0x0F;
        u8 off_sz = hdr >> 4;
        if (len_sz == 0 || len_sz > 8 || off_sz > 8) return 0;
        u32 adv = 1 + len_sz + off_sz;
        u64 len = 0;
        for (int i = 0; i < len_sz; i++) len |= (u64)p[1 + i] << (8 * i);
        i64 delta = 0;
        if (off_sz) {
            /* смещение со знаком (little-endian, старший байт знаковый) */
            u64 u = 0;
            for (int i = 0; i < off_sz; i++) u |= (u64)p[1 + len_sz + i] << (8 * i);
            u64 signbit = 1ull << (off_sz * 8 - 1);
            delta = (u & (signbit - 1)) - (i64)(u & signbit);
            it->lcn += delta;
        }
        it->pos += adv;
        it->run_vcn = it->vcn;
        it->run_len = len;
        it->vcn += len;
        return 1;
    }
}

/* LCN для VCN (внутри текущего run). ~0 = sparse. */
static u64 vcn_to_lcn(run_iter_t *it, u64 vcn)
{
    if (vcn < it->run_vcn || vcn >= it->run_vcn + it->run_len)
        return 0xFFFFFFFFFFFFFFFFull;
    if (it->lcn < 0) return 0xFFFFFFFFFFFFFFFFull;   /* sparse run */
    return (u64)it->lcn + (vcn - it->run_vcn);
}

/* ============================ имена ============================ */

/* Транслитерация кириллицы (UTF-16 0x0410-0x044F и 0x401/0x451). */
static const char *cyr_translit(u32 cp)
{
    static const char *upper[] = {
        "A", "B", "V", "G", "D", "E", "Zh", "Z", "I", "Yi", "K", "L", "M",
        "N", "O", "P", "R", "S", "T", "U", "F", "Kh", "Ts", "Ch", "Sh",
        "Shch", "'", "Y", "'", "E", "Yu", "Ya"
    };
    static const char *lower[] = {
        "a", "b", "v", "g", "d", "e", "zh", "z", "i", "yi", "k", "l", "m",
        "n", "o", "p", "r", "s", "t", "u", "f", "kh", "ts", "ch", "sh",
        "shch", "'", "y", "'", "e", "yu", "ya"
    };
    if (cp == 0x0401) return "Yo";
    if (cp == 0x0451) return "yo";
    if (cp >= 0x0410 && cp <= 0x042F) return upper[cp - 0x0410];
    if (cp >= 0x0430 && cp <= 0x044F) return lower[cp - 0x0430];
    return NULL;
}

/* UTF-16LE → ASCII в out (до max символов). */
static void utf16_to_ascii(const u8 *src, int chars, char *out, u32 max)
{
    u32 o = 0;
    for (int i = 0; i < chars && o + 1 < max; i++) {
        u32 cp = rd16(src + i * 2);
        if (cp < 0x80 && cp >= 0x20 && cp != '/' && cp != '*' &&
            cp != '?' && cp != '"' && cp != '<' && cp != '>' && cp != '|' &&
            cp != ':' && cp != '\\') {
            out[o++] = (char)cp;
        } else {
            const char *tr = cyr_translit(cp);
            if (tr) {
                while (*tr && o + 1 < max) out[o++] = *tr++;
            } else {
                out[o++] = '_';
            }
        }
    }
    out[o] = 0;
}

/* ============================ каталоги ============================ */

/* Внутреннее представление записи каталога. */
typedef struct {
    char name[NTFS_NAME_MAX + 1];
    u64  mref;
    u64  real_size;
    int  is_dir;
} ntfs_ent_t;

/* Добавить запись из элемента индекса (key = $FILE_NAME). */
static int ent_from_index_entry(const u8 *ent, ntfs_ent_t *out)
{
    u16 key_len = rd16(ent + 0x0A);
    if (key_len < 0x42) return 0;              /* пустой/служебный */
    const u8 *fn = ent + 0x10;
    u8 name_chars = fn[0x40];
    if (name_chars == 0) return 0;   /* u8 не бывает > 255 — вторая
                                      * половина проверки была мёртвой
                                      * (поле $FILE_NAME 0x40 = 1 байт) */
    u8 ns = fn[0x41];
    if (ns == 2) return 0;                     /* DOS-имя (8.3) — пропускаем */
    out->mref = rd64(ent) & 0xFFFFFFFFFFFFull;
    out->real_size = rd64(fn + 0x30);
    out->is_dir = (rd32(fn + 0x38) & 0x10) ? 1 : 0;
    utf16_to_ascii(fn + 0x42, name_chars, out->name, sizeof(out->name));
    return out->name[0] ? 1 : 0;
}

/* Обход элементов индекса в буфере (INDX-блок или INDEX_ROOT value). */
static int collect_entries(const u8 *start, const u8 *end,
                           ntfs_ent_t *out, int max, int *count)
{
    const u8 *p = start;
    while (p + 0x10 <= end && *count < max) {
        u16 ent_len = rd16(p + 8);
        if (ent_len < 0x10 || p + ent_len > end) break;
        u16 flags = rd16(p + 0x0C);
        if (!(flags & 0x0002)) {               /* last-маркер без key — мимо */
            ntfs_ent_t e;
            if (ent_from_index_entry(p, &e)) {
                out[(*count)++] = e;
            }
        }
        if (flags & 0x0002) break;             /* последний элемент */
        p += ent_len;
    }
    return 1;
}

/* Собрать все записи каталога (запись MFT уже в g_rec).
 * Малые каталоги: только $INDEX_ROOT. Большие: + все INDX-блоки из
 * $INDEX_ALLOCATION (полный обход allocation — все листья B-дерева). */
static int collect_dir(u64 dir_mref, ntfs_ent_t *out, int max)
{
    if (!mft_read_record(dir_mref)) {
        ntfs_err("каталог: запись MFT не читается");
        return -1;
    }

    ntfs_attr_t root;
    if (!attr_find(g_rec, 0x90, 0, &root) || root.non_res) {
        /* нет $INDEX_ROOT — не каталог */
        return -1;
    }
    int count = 0;

    /* $INDEX_ROOT value: +0x10 — элементы */
    const u8 *v = root.val;
    u32 vlen = root.val_len;
    if (vlen < 0x18) return -1;
    collect_entries(v + 0x10, v + vlen, out, max, &count);

    /* $INDEX_ALLOCATION: INDX-блоки */
    ntfs_attr_t alloc;
    if (attr_find(g_rec, 0xA0, 0, &alloc) && alloc.non_res) {
        u32 blk_secs = g_indx_size / 512;
        run_iter_t it;
        runs_open(&it, &alloc);
        while (runs_next(&it) && count < max) {
            for (u64 c = 0; c < it.run_len && count < max; c++) {
                /* FIX (was warning): it.lcn — i64 (sparse-run даёт
                 * отрицательный накопительный LCN); сравнивать надо
                 * ЗНАКОВОЕ значение, а не (u64)каст (всегда >= 0) —
                 * иначе sparse-дыры не отсекались и читался мусорный
                 * LBA. */
                u64 lcn = it.lcn >= 0 ? (u64)it.lcn + c
                                      : 0xFFFFFFFFFFFFFFFFull;
                if (lcn == 0xFFFFFFFFFFFFFFFFull) continue;   /* sparse */
                u32 lba = (u32)(lcn * g_cluster_sectors);
                if (!rd_sectors(lba, blk_secs, g_blk)) continue;
                if (memcmp(g_blk, "INDX", 4) != 0) continue;
                if (!apply_fixup(g_blk, g_indx_size)) continue;
                /* INDX: +0x18 начало элементов, конец = размер блока */
                collect_entries(g_blk + 0x18, g_blk + g_indx_size,
                                out, max, &count);
            }
        }
    }
    return count;
}

/* ============================ LZNT1 ============================ */

/* Декомпрессия LZNT1-потока in[0..in_len) в out (out_sz).
 * Формат: чанки; заголовок u16: бит15 = сжат, биты 0-11 =
 * (размер несжатого чанка / 4096) - 1. Токены: байт флагов на 8 токенов;
 * литерал = 1 байт; пара = u16: length = (w>>12)+3, offset = (w&0xFFF)+1
 * (offset в пределах ТЕКУЩЕГО чанка). Возвращает число записанных байт. */
static u32 lznt1_decompress(const u8 *in, u32 in_len, u8 *out, u32 out_sz)
{
    u32 ip = 0, op = 0;
    while (ip + 2 <= in_len && op < out_sz) {
        u16 hdr = rd16(in + ip);
        ip += 2;
        if (hdr == 0) break;
        u32 chunk_out = ((u32)(hdr & 0x0FFF) + 1) * 4096u;
        u32 chunk_start = op;
        if (!(hdr & 0x8000)) {
            /* несжатый чанк: копируем как есть */
            u32 n = chunk_out;
            if (n > in_len - ip) n = in_len - ip;
            if (n > out_sz - op) n = out_sz - op;
            memcpy(out + op, in + ip, n);
            ip += n;
            op += n;
            continue;
        }
        /* сжатый чанк: токены до заполнения chunk_out байт */
        while (op - chunk_start < chunk_out && ip < in_len &&
               op < out_sz) {
            u8 flags = in[ip++];
            for (int b = 0; b < 8; b++) {
                if (op - chunk_start >= chunk_out || ip >= in_len ||
                    op >= out_sz)
                    break;
                if (flags & 1) {
                    if (ip + 2 > in_len) return op;
                    u16 w = rd16(in + ip);
                    ip += 2;
                    u32 len = ((u32)w >> 12) + 3;
                    u32 back = ((u32)w & 0xFFF) + 1;
                    if (back > op - chunk_start) return op;   /* битый поток */
                    u32 src = op - back;
                    while (len-- > 0 && op < out_sz)
                        out[op++] = out[src++];
                } else {
                    out[op++] = in[ip++];
                }
                flags >>= 1;
            }
        }
    }
    return op;
}

/* ============================ чтение $DATA ============================ */

/* Прочитать non-resident $DATA в buf (до max байт).
 * Учитывает sparse (нулевые кластеры), сжатие (LZNT1 по CU),
 * реальный размер. n_ext — число экстентов в g_exts
 * ([NTFS-EXT], >= 1; собираются load_data_extents).
 * Возвращает число байт. */
static u32 read_data_nonres(const ntfs_attr_t *a, int n_ext, void *buf, u32 max,
                             ntfs_progress_fn cb, void *ctx)
{
    u64 want = a->real_sz < (u64)max ? a->real_sz : (u64)max;
    u8 *out = (u8 *)buf;
    u32 cu_sectors = a->comp_unit
        ? ((u32)1 << a->comp_unit) * g_cluster_sectors
        : 0;
    int compressed = (a->flags & 0x0001) != 0 && cu_sectors != 0;

    if (!compressed) {
        /* несжатый (возможно sparse): копируем кластеры */
        u32 done = 0;
        u64 vcn = 0;
        run_iter_t it;
        if (n_ext > 1) runs_open_multi(&it, g_exts, n_ext);   /* [NTFS-EXT] */
        else           runs_open(&it, a);
        while (done < (u32)want && runs_next(&it)) {
            for (u64 c = 0; c < it.run_len && done < (u32)want; c++, vcn++) {
                u64 lcn = vcn_to_lcn(&it, vcn);
                u32 in_cl = g_cluster_sectors * 512;
                u32 chunk = in_cl;
                if (chunk > (u32)want - done) chunk = (u32)want - done;
                if (lcn == 0xFFFFFFFFFFFFFFFFull) {
                    memset(out + done, 0, chunk);        /* sparse */
                } else {
                    u32 lba = (u32)(lcn * g_cluster_sectors);
                    if (!rd_sectors(lba, g_cluster_sectors, g_blk)) return done;
                    memcpy(out + done, g_blk, chunk);
                }
                done += chunk;
                if (cb) cb(ctx, done, (u32)want);       /* [FM-PROG] */
            }
        }
        return done;
    }

    /* сжатый: читаем по compression unit, декомпрессируем LZNT1.
     * Один итератор runs на весь файл (все экстенты [NTFS-EXT]);
     * CU выравнен по VCN. */
    u32 done = 0;
    u64 vcn = 0;
    run_iter_t it;
    if (n_ext > 1) runs_open_multi(&it, g_exts, n_ext);       /* [NTFS-EXT] */
    else           runs_open(&it, a);
    int runs_alive = 1;

    while (done < (u32)want) {
        u32 cu_bytes = 0;
        u32 cu_cap = cu_sectors * 512;

        /* собрать кластеры CU (sparse-дыры просто пропускаем:
         * LZNT1-поток их не содержит) */
        while (cu_bytes < cu_cap) {
            if (vcn >= it.run_vcn + it.run_len) {
                if (!runs_alive || !runs_next(&it)) { runs_alive = 0; break; }
            }
            if (vcn >= it.run_vcn + it.run_len) { runs_alive = 0; break; }
            u64 lcn = vcn_to_lcn(&it, vcn);
            if (lcn != 0xFFFFFFFFFFFFFFFFull) {
                u32 lba = (u32)(lcn * g_cluster_sectors);
                if (!rd_sectors(lba, g_cluster_sectors, g_blk2 + cu_bytes))
                    break;
                cu_bytes += g_cluster_sectors * 512;
            }
            vcn++;
        }

        if (cu_bytes == 0) {
            /* дальше данных нет (хвост sparse) — добиваем нулями */
            u32 chunk = (u32)want - done;
            u32 cu_out = cu_cap;
            if (chunk > cu_out) chunk = cu_out;
            memset(out + done, 0, chunk);
            done += chunk;
            if (!runs_alive) break;
            continue;
        }

        u32 left = (u32)want - done;
        u32 got = lznt1_decompress(g_blk2, cu_bytes, out + done, left);
        done += got;
        if (cb) cb(ctx, done, (u32)want);               /* [FM-PROG] */
        if (got < left && cu_bytes < cu_cap) break;   /* хвост файла */
    }
    return done;
}

/* Найти $DATA записи (в g_rec): сначала в самой записи, потом через
 * $ATTRIBUTE_LIST (большие/фрагментированные файлы). */
static int find_data_attr(ntfs_attr_t *out)
{
    if (attr_find(g_rec, 0x80, 0, out)) return 1;
    if (attr_find_in_list(g_rec, 0x80, out)) return 1;
    return 0;
}

/* [NTFS-EXT] собрать ВСЕ экстенты $DATA: базовый (уже найден attr_find)
 * + расширения из $ATTRIBUTE_LIST. Возвращает число экстентов (>= 1);
 * частичная цепочка (нечитаемая запись MFT / разрыв стыка) — громкий
 * лог, доступный префикс файла. Выполняется под g_lock; g_rec на время
 * перегружается записями расширений — runs КОПИРУЮТСЯ в g_ext_runs. */
static int load_data_extents(const ntfs_attr_t *base, const char *fname)
{
    static u32 s_ext_files = 0;          /* инфо-строка: 3 файла за загрузку */
    int n = 0;
    u32 stash = 0;
    int ext_list = 0;

    /* 1) базовый экстент (VCN 0) */
    {
        u32 alen = rd32(base->hdr + 4);
        u32 roff = (u32)base->run_off;
        u32 rlen = (alen > roff) ? (alen - roff) : 0;
        if (rlen > NTFS_EXT_RUNS_MAX) rlen = NTFS_EXT_RUNS_MAX;
        memcpy(g_ext_runs, base->hdr + roff, rlen);
        g_exts[0].start_vcn = rd64(base->hdr + 0x10);   /* = 0 по формату */
        g_exts[0].last_vcn  = rd64(base->hdr + 0x18);
        g_exts[0].runs = g_ext_runs;
        g_exts[0].runs_len = rlen;
        g_exts[0].mref = 0;
        n = 1;
        stash = NTFS_EXT_RUNS_MAX;
    }

    /* 2) расширения: элементы type=0x80, VCN>0, безымянные, по порядку */
    ntfs_attr_t al;
    if (attr_find(g_rec, 0x100, 0, &al) && !al.non_res && al.val_len >= 0x18) {
        ext_list = 1;
        u32 pos = 0;
        while (pos + 0x18 <= al.val_len && n < NTFS_MAX_EXTENTS) {
            const u8 *e = al.val + pos;
            u32 etype = rd32(e);
            u32 elen = rd16(e + 4);
            if (elen < 0x18 || pos + elen > al.val_len) break;
            pos += elen;
            if (etype != 0x80) continue;        /* не $DATA */
            if (e[6] != 0) continue;            /* именованный (ADS) — мимо */
            u64 vcn = rd64(e + 8);
            if (vcn == 0) continue;             /* базовый уже взят */
            u64 mref = rd64(e + 0x10) & 0xFFFFFFFFFFFFull;
            if (!mft_read_record(mref)) {
                char b[128];
                snprintf(b, sizeof(b),
                         "\"%s\": экстент %d не читается (MFT-запись %llu) — файл обрезан на VCN %llu",
                         fname ? fname : "?", n, (unsigned long long)mref,
                         (unsigned long long)g_exts[n - 1].last_vcn + 1u);
                ntfs_note(b);
                break;
            }
            ntfs_attr_t a;
            if (!attr_find(g_rec, 0x80, 0, &a) || !a.non_res) break;
            u64 lv = rd64(a.hdr + 0x10);        /* lowest_vcn заголовка */
            u64 hv = rd64(a.hdr + 0x18);
            if (lv != vcn || lv != g_exts[n - 1].last_vcn + 1) {
                char b[128];
                snprintf(b, sizeof(b),
                         "\"%s\": стык экстентов не сходится (VCN %llu != %llu) — файл обрезан",
                         fname ? fname : "?", (unsigned long long)lv,
                         (unsigned long long)g_exts[n - 1].last_vcn + 1u);
                ntfs_note(b);
                break;
            }
            u32 alen = rd32(a.hdr + 4);
            u32 roff = (u32)a.run_off;
            u32 rlen = (alen > roff) ? (alen - roff) : 0;
            if (rlen > NTFS_EXT_RUNS_MAX) rlen = NTFS_EXT_RUNS_MAX;
            if (stash + rlen > NTFS_MAX_EXTENTS * NTFS_EXT_RUNS_MAX) break;
            memcpy(g_ext_runs + stash, a.hdr + roff, rlen);
            g_exts[n].start_vcn = lv;
            g_exts[n].last_vcn  = hv;
            g_exts[n].runs = g_ext_runs + stash;
            g_exts[n].runs_len = rlen;
            g_exts[n].mref = mref;
            n++;
            stash += NTFS_EXT_RUNS_MAX;
        }
        if (n >= NTFS_MAX_EXTENTS) {
            char b[128];
            snprintf(b, sizeof(b),
                     "\"%s\": экстентов больше %d — хвост файла не читается",
                     fname ? fname : "?", NTFS_MAX_EXTENTS);
            ntfs_note(b);
        }
    }

    if (ext_list && s_ext_files < 3u) {
        s_ext_files++;
        char b[224];
        u32 o = (u32)snprintf(b, sizeof(b),
                              "\"%s\": $DATA фрагментирован: экстентов %d:",
                              fname ? fname : "?", n);
        for (int i = 0; i < n && i < 4 && o < sizeof(b); i++)
            o += (u32)snprintf(b + o, sizeof(b) - o, " %llu..%llu",
                               (unsigned long long)g_exts[i].start_vcn,
                               (unsigned long long)g_exts[i].last_vcn);
        if (n > 4 && o < sizeof(b))
            o += (u32)snprintf(b + o, sizeof(b) - o, " ...");
        if (o < sizeof(b))
            snprintf(b + o, sizeof(b) - o, " — читаем целиком");
        ntfs_note(b);
    }
    return n;
}

/* ============================ пути ============================ */

/* Сравнение имён без учёта регистра (ASCII). */
static int name_eq(const char *a, const char *b)
{
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'a' && ca <= 'z') ca = (char)(ca - 'a' + 'A');
        if (cb >= 'a' && cb <= 'z') cb = (char)(cb - 'a' + 'A');
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* Резолв ПОЛНОГО пути "/a/b/c" → MREF записи (5 = корень).
 * Возвращает ~0ull, если путь не существует. */
#define NTFS_MAX_ENTS 256

static u64 path_resolve(const char *path)
{
    if (!path || path[0] != '/') return ~0ull;

    u64 mref = 5;                          /* корень */
    char comp[NTFS_NAME_MAX + 1];
    const char *p = path;

    static ntfs_ent_t ents[NTFS_MAX_ENTS]; /* под блокировкой g_lock */
    for (;;) {
        while (*p == '/') p++;
        if (!*p) return mref;              /* «/» → корень */
        int cl = 0;
        while (*p && *p != '/' && cl < NTFS_NAME_MAX)
            comp[cl++] = *p++;
        comp[cl] = 0;
        while (*p && *p != '/') p++;       /* остаток слишком длинного */

        int n = collect_dir(mref, ents, NTFS_MAX_ENTS);
        if (n < 0) return ~0ull;
        int found = -1;
        for (int i = 0; i < n; i++)
            if (name_eq(ents[i].name, comp)) { found = i; break; }
        if (found < 0) return ~0ull;
        if (*p == 0 && !ents[found].is_dir) {
            /* файл в середине пути — ошибка только для каталогов;
             * для файлов это нормальный конец (возвращает mref) */
            return ents[found].mref;
        }
        if (!ents[found].is_dir) return ~0ull;
        mref = ents[found].mref;
    }
}

/* ============================ публичный API ============================ */

int ntfs_list(const char *path, ntfs_dirent_t *out, int max)
{
    if (!g_ready || !path) return -1;
    s_lock(&g_lock);
    static ntfs_ent_t ents[NTFS_MAX_ENTS];
    u64 mref = path_resolve(path);
    if (mref == ~0ull) { s_unlock(&g_lock); return -1; }
    int n = collect_dir(mref, ents, NTFS_MAX_ENTS);
    if (n > max) n = max;
    for (int i = 0; i < n; i++) {
        snprintf(out[i].name, sizeof(out[i].name), "%s", ents[i].name);
        out[i].size = (u32)ents[i].real_size;
        out[i].is_dir = ents[i].is_dir;
    }
    s_unlock(&g_lock);
    return n;
}

static u32 ntfs_read_file_common(const char *path, void *buf, u32 max,
                                 ntfs_progress_fn cb, void *ctx)
{
    if (!g_ready || !path || path[0] != '/') return 0;
    s_lock(&g_lock);
    u32 result = 0;

    /* родительский каталог + имя файла */
    const char *slash = path + strlen(path);
    while (slash > path && *slash != '/') slash--;
    const char *fname = (*slash == '/') ? slash + 1 : path;
    char parent[256];
    u32 plen = (u32)(slash - path);
    if (plen >= sizeof(parent)) plen = sizeof(parent) - 1;
    memcpy(parent, path, plen);
    parent[plen] = 0;
    if (parent[0] == 0) { parent[0] = '/'; parent[1] = 0; }

    static ntfs_ent_t ents[NTFS_MAX_ENTS];
    int n = collect_dir(path_resolve(parent), ents, NTFS_MAX_ENTS);
    if (n < 0) goto out;
    ntfs_ent_t *ent = NULL;
    for (int i = 0; i < n; i++)
        if (name_eq(ents[i].name, fname)) { ent = &ents[i]; break; }
    if (!ent || ent->is_dir) goto out;

    if (!mft_read_record(ent->mref)) goto out;
    ntfs_attr_t data;
    if (!find_data_attr(&data)) goto out;

    if (data.flags & 0x8000) {
        ntfs_err("файл зашифрован (EFS) — чтение невозможно");
        goto out;
    }
    if (!data.non_res) {
        u32 ncopy = data.val_len;
        if (ncopy > max) ncopy = max;
        memcpy(buf, data.val, ncopy);
        if (cb) cb(ctx, ncopy, ncopy);                  /* [FM-PROG] */
        result = ncopy;
    } else {
        /* [NTFS-EXT] полный набор экстентов $DATA (базовый + расширения
         * из $ATTRIBUTE_LIST) — раньше читался только VCN=0 */
        int nx = load_data_extents(&data, fname);
        if (nx < 1) nx = 1;                /* параноидально: базовый есть */
        result = read_data_nonres(&data, nx, buf, max, cb, ctx);
    }
out:
    s_unlock(&g_lock);
    return result;
}

u32 ntfs_read_file(const char *path, void *buf, u32 max)
{
    return ntfs_read_file_common(path, buf, max, NULL, NULL);
}

/* [FM-PROG]: чтение с колбэком прогресса (ntfs.h) */
u32 ntfs_read_file_prog(const char *path, void *buf, u32 max,
                        ntfs_progress_fn cb, void *cb_ctx)
{
    return ntfs_read_file_common(path, buf, max, cb, cb_ctx);
}

int ntfs_file_size(const char *path)
{
    if (!g_ready || !path || path[0] != '/') return -1;
    s_lock(&g_lock);
    int sz = -1;
    const char *slash = path + strlen(path);
    while (slash > path && *slash != '/') slash--;
    const char *fname = (*slash == '/') ? slash + 1 : path;
    char parent[256];
    u32 plen = (u32)(slash - path);
    if (plen >= sizeof(parent)) plen = sizeof(parent) - 1;
    memcpy(parent, path, plen);
    parent[plen] = 0;
    if (parent[0] == 0) { parent[0] = '/'; parent[1] = 0; }

    static ntfs_ent_t ents[NTFS_MAX_ENTS];
    int n = collect_dir(path_resolve(parent), ents, NTFS_MAX_ENTS);
    if (n < 0) { s_unlock(&g_lock); return -1; }
    for (int i = 0; i < n; i++)
        if (name_eq(ents[i].name, fname) && !ents[i].is_dir) {
            sz = (int)ents[i].real_size;
            break;
        }
    s_unlock(&g_lock);
    return sz;
}

/* ============================ init ============================ */

/* Сессия 25: part_index >= 0 — монтировать КОНКРЕТНЫЙ раздел из
 * disk_part(); part_index < 0 — авто-поиск первого NTFS-раздела. */
static int ntfs_init_ex(int part_index)
{
    g_ready = 0;
    g_error[0] = 0;
    if (!disk_hdd_present()) {
        snprintf(g_error, sizeof(g_error), "НЖМД не найден");
        return 0;
    }

    if (g_rec) free(g_rec);
    if (g_blk) free(g_blk);
    if (g_blk2) free(g_blk2);
    if (g_ext_runs) free(g_ext_runs);
    g_rec = (u8 *)malloc(4096);
    g_blk = (u8 *)malloc(8192);
    g_blk2 = (u8 *)malloc(65536 + 512);
    g_ext_runs = (u8 *)malloc(NTFS_MAX_EXTENTS * NTFS_EXT_RUNS_MAX);
    if (!g_rec || !g_blk || !g_blk2 || !g_ext_runs) {
        ntfs_err("нет памяти под буферы");
        return 0;
    }

    /* MBR/GPT (общий слой disk.c) → раздел с NTFS-сигнатурой */
    int part = -1;
    if (part_index >= 0) {
        if (part_index < disk_part_count() &&
            strcmp(disk_part_fstype(part_index), "NTFS") == 0)
            part = part_index;
    } else {
        for (int i = 0; i < disk_part_count(); i++) {
            if (strcmp(disk_part_fstype(i), "NTFS") == 0) { part = i; break; }
        }
    }
    if (part < 0) {
        snprintf(g_error, sizeof(g_error), "NTFS-раздел не найден");
        return 0;
    }
    g_part_base = disk_part(part)->start_lba;
    g_part_sectors = disk_part(part)->nsectors;

    /* boot-сектор NTFS */
    u8 bs[512];
    if (!rd_sector(0, bs)) return 0;
    if (memcmp(bs + 3, "NTFS    ", 8) != 0) {
        ntfs_err("нет сигнатуры NTFS");
        return 0;
    }
    u16 bps = rd16(bs + 0x0B);
    if (bps != 512) {
        ntfs_err("сектор не 512 байт");
        return 0;
    }
    g_spc = bs[0x0D];
    if (g_spc == 0 || (g_spc & (g_spc - 1))) {
        ntfs_err("нечётный размер кластера");
        return 0;
    }
    g_cluster_sectors = g_spc;
    g_mft_lcn = rd64(bs + 0x30);
    i8 rec_per_cl = (i8)bs[0x40];
    if (rec_per_cl < 0)
        g_mft_rec_size = (u32)1 << (-rec_per_cl);
    else if (rec_per_cl > 0)
        g_mft_rec_size = (u32)rec_per_cl * g_cluster_sectors * 512u;
    else
        g_mft_rec_size = 0;
    if (g_mft_rec_size < 256 || g_mft_rec_size > 4096 ||
        (g_mft_rec_size & 511)) {
        ntfs_err("странный размер записи MFT");
        return 0;
    }
    i8 cl_per_indx = (i8)bs[0x44];
    if (cl_per_indx < 0)
        g_indx_size = (u32)1 << (-cl_per_indx);
    else
        g_indx_size = (u32)cl_per_indx * g_cluster_sectors * 512u;
    if (g_indx_size < 512 || g_indx_size > 4096) {
        /* не критично: возьмём из INDEX_ROOT при чтении */
        g_indx_size = 4096;
    }
    if (g_indx_size > 8192) g_indx_size = 8192;

    /* $MFT читается? */
    if (!mft_read_record(0)) {
        ntfs_err("$MFT не читается");
        return 0;
    }

    /* метка тома: $Volume (запись 3), $VOLUME_NAME (0x60) */
    strcpy(g_label, "NTFS");
    if (mft_read_record(3)) {
        ntfs_attr_t vn;
        if (attr_find(g_rec, 0x60, 0, &vn) && !vn.non_res && vn.val_len) {
            int chars = (int)(vn.val_len / 2);
            if (chars > 30) chars = 30;
            utf16_to_ascii(vn.val, chars, g_label, sizeof(g_label));
        }
    }

    /* корень читается? */
    static ntfs_ent_t probe[4];
    if (collect_dir(5, probe, 4) < 0) {
        ntfs_err("корневой каталог не читается");
        return 0;
    }

    g_ready = 1;
    {
        char b[96];
        snprintf(b, sizeof(b),
                 "[ntfs] смонтирован: раздел %u МиБ, кластер %u сект., MFT-запись %u б., метка \"%s\"",
                 (unsigned)(g_part_sectors / 2048u), g_cluster_sectors,
                 g_mft_rec_size, g_label);
        serial_puts(b);
        serial_puts("\n");
    }
    return 1;
}

int ntfs_init(void)
{
    return ntfs_init_ex(-1);
}

/* Сессия 25: смонтировать КОНКРЕТНЫЙ раздел (индекс в disk_part()).
 * Вызывается файловым менеджером при выборе тома-кнопки. */
int ntfs_init_part(int part_index)
{
    return ntfs_init_ex(part_index);
}
