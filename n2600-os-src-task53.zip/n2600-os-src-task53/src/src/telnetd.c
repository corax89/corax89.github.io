/* telnetd.c — Telnet-сервер N2600-OS (итерация 7).
 *
 * RFC 854/855 в минимальном объёме:
 *   - на подключение отвечаем IAC WILL ECHO + WILL/DO SUPPRESS-GO-AHEAD
 *     (переводим клиента в character-at-a-time с серверным эхом);
 *   - все прочие WILL/DO отклоняем (WONT/DONT), SB..SE пропускаем,
 *     IAC IAC → литерал 0xFF;
 *   - строка собирается с эхом и правкой (Backspace/Ctrl+U), Enter
 *     ('\r') исполняет команду, Ctrl+C сбрасывает строку, Ctrl+D
 *     закрывает соединение.
 *
 * Исполнение команд — через headless-терминал (apps.h):
 * term_headless_create() + term_headless_sink(вывод → сокет) +
 * term_shell_exec(). Таблица команд та же, что в локальном окне
 * терминала; команды, требующие окна/REPL (js/ping/telnet/reboot/
 * poweroff), внутри term_exec/password-безопасно отказываются.
 *
 * Модель потоков: приём копирует байты в per-connection буфер
 * (контекст net_poll — main loop / любой net_poll), обслуживающая
 * задача «telnetd» (TASK_PRIO_BG, system) разбирает строки и
 * исполняет команды в СВОЁМ контексте — долгие команды не тормозят
 * ни main loop, ни WM. Отправка с ожиданием ACK (net_tcp_send_pending)
 * — стек держит один неотправленный сегмент.
 *
 * Структуры соединений — статические (3 клиента), headless-терминалы
 * создаются в telnetd_start() заранее: malloc в accept-колбэке
 * (контекст net_poll) не используется.
 */
#include "types.h"
#include "string.h"
#include "mem.h"
#include "timer.h"
#include "task.h"
#include "ramfs.h"
#include "net.h"
#include "apps.h"
#include "telnetd.h"
#include "dfm.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

#define TELNET_PORT    23
#define TELNETD_CONNS  3
#define TND_LINE_MAX   96                      /* длина строки ввода */
#define TND_INBUF      256                     /* буфер входа на клиента */
#define TND_IDLE_MS    (10u * 60u * 1000u)     /* 10 мин бездействия */

/* состояния IAC-разбора */
#define IAC_NONE 0
#define IAC_GOT  1      /* принят 0xFF, ждём команду */
#define IAC_OPT  2      /* ждём аргумент WILL/DO */

typedef struct {
    int             sock;          /* -1 = слот свободен */
    u32             gen;           /* поколение TCP-слота [GEN] */
    term_t         *term;          /* headless-терминал (вывод в сокет) */
    char            line[TND_LINE_MAX + 1];
    int             llen;
    int             iac;           /* IAC_NONE/GOT/OPT */
    unsigned char   iac_cmd;       /* WILL/DO, на который ждём аргумент */
    int             sb_skip;       /* внутри SB ... SE */
    /* Task 50 [TND-CHARMODE]: состояние согласования опций (RFC 854/857).
     * Раньше ответы клиенту шли ВСЛЕПУЮ: на его DO ECHO/DO SGA мы
     * отвечали WONT ECHO/WONT SGA, на его WILL SGA — DONT SGA. Этим мы
     * САМИ ОТМЕНЯЛИ собственное согласование character-at-a-time:
     * клиент возвращался в line-mode и слал строку только по Enter —
     * «в fm кнопки без реакции до Enter». Теперь держим состояние и
     * подтверждаем ровно то, что поддерживаем. */
    int             opt_will_echo; /* мы подтвердили WILL ECHO */
    int             opt_will_sga;  /* мы подтвердили WILL SGA  */
    int             opt_do_sga;    /* мы подтвердили DO SGA    */
    volatile int    inbuf_lock;
    char            inbuf[TND_INBUF];
    volatile int    inbuf_n;
    u32             last_tick;
    int             need_hello;    /* баннер ещё не отправлен (шлёт задача) */
    int             fm_mode;       /* Task 46/48: активен менеджер (dfm) */
    dfm_t           fm;            /* состояние файлового менеджера */
} tnd_conn_t;

static tnd_conn_t g_conns[TELNETD_CONNS];
static volatile int g_started = 0;
static volatile int g_want = 1;    /* ПО УМОЛЧАНИЮ ВКЛЮЧЁН */
static volatile int g_task_alive = 0;

static void tnd_conn_close(tnd_conn_t *c, const char *why);

/* ---------- вывод ---------- */

/* сырая отправка с ожиданием ACK предыдущего сегмента */
static void tnd_send_raw(int sock, u32 gen, const char *buf, u32 n)
{
    if (sock < 0) return;
    if (net_tcp_gen(sock) != gen) return;          /* слот потерян */
    net_tcp_send(sock, buf, n);
    int guard = 0;
    while (net_tcp_send_pending(sock) && guard++ < 2000) {
        net_poll();
        task_yield();
    }
    /* [TND-DIAG] (Task 42): если сегмент не ушёл за ~2 с — в dmesg:
     * видно, что канал/окно застряли (при этом система НЕ виснет —
     * только telnet-задача ждёт) */
    if (net_tcp_send_pending(sock)) {
        static int s_pend_logged = 0;
        if (s_pend_logged < 4) {
            s_pend_logged++;
            char lg[72];
            snprintf(lg, sizeof(lg),
                     "[telnetd] сегмент не ушёл за ~2 с (окно/канал) — жду\n");
            serial_puts(lg);
            klog_puts(lg);
        }
    }
}

/* строка: \n → \r\n, 0xFF → FF FF (IAC-экранирование) */
static void tnd_conn_send(tnd_conn_t *c, const char *s)
{
    if (c->sock < 0 || !s) return;
    char out[600];
    u32 on = 0;
    for (const char *p = s; *p; p++) {
        char ch = *p;
        if (on >= sizeof(out) - 3) {
            tnd_send_raw(c->sock, c->gen, out, on);
            on = 0;
        }
        if (ch == '\n') out[on++] = '\r';
        out[on++] = ch;
        if ((unsigned char)ch == 0xFF) out[on++] = (char)0xFF;
    }
    if (on) tnd_send_raw(c->sock, c->gen, out, on);
}

/* Task 50: отправить IAC <cmd> <opt> одной посылкой (без ре-эха) */
static void tnd_send_iac(tnd_conn_t *c, unsigned char cmd, unsigned char opt)
{
    char r[3];
    r[0] = (char)0xFF;
    r[1] = (char)cmd;
    r[2] = (char)opt;
    tnd_send_raw(c->sock, c->gen, r, 3);
}

/* sink headless-терминала: весь вывод команд уходит клиенту */
static void tnd_sink_put(void *ctx, const char *s)
{
    tnd_conn_send((tnd_conn_t *)ctx, s);
}

/* sink файлового менеджера (тот же канал, \n → \r\n в tnd_conn_send) */
static void tnd_fm_put(void *ctx, const char *s)
{
    tnd_conn_send((tnd_conn_t *)ctx, s);
}

/* ---------- вход ---------- */

/* приём данных (контекст net_poll): копируем в буфер клиента */
static void tnd_recv(int sock, u32 src_ip, u16 src_port,
                     const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    for (int i = 0; i < TELNETD_CONNS; i++) {
        tnd_conn_t *c = &g_conns[i];
        if (c->sock != sock) continue;
        if (net_tcp_gen(sock) != c->gen) return;   /* слот переиспользован */
        u32 f;
#ifndef HOST_TEST
        __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(f) :: "memory");
#else
        f = 0;                       /* хост-тест: однопоточно, без cli */
#endif
        for (u32 k = 0; k < len; k++) {
            if (c->inbuf_n < TND_INBUF)
                c->inbuf[c->inbuf_n++] = ((const char *)data)[k];
            /* переполнение (256 байт строчного ввода не бывает) —
             * новые байты теряем */
        }
#ifndef HOST_TEST
        if (f & 0x200) __asm__ __volatile__("sti" ::: "memory");
#endif
        c->last_tick = timer_ticks();
        return;
    }
}

/* забрать кусок из входного буфера (критическая секция) */
static int tnd_inbuf_take(tnd_conn_t *c, char *dst, int max)
{
    int n;
#ifndef HOST_TEST
    u32 f;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(f) :: "memory");
#else
    u32 f = 0;                   /* хост-тест: однопоточно, без cli */
#endif
    n = c->inbuf_n;
    if (n > max) n = max;
    if (n > 0) {
        memcpy(dst, c->inbuf, (u32)n);
        memmove(c->inbuf, c->inbuf + n, (u32)(c->inbuf_n - n));
        c->inbuf_n -= n;
    }
#ifndef HOST_TEST
    if (f & 0x200) __asm__ __volatile__("sti" ::: "memory");
#endif
    return n;
}

/* ---------- исполнение строки ---------- */

static void tnd_prompt(tnd_conn_t *c)
{
    /* Task 48: в режиме менеджера — приглашения редактора/промптов;
     * в полноэкранном режиме (обзор/просмотр) приглашения нет */
    if (c->fm_mode) {
        if (c->fm.mode == 2) {
            tnd_conn_send(c, c->fm.ed_dirty ? "ed*> " : "ed> ");
            return;
        }
        if (c->fm.mode == 3) {
            char p[16];
            dfm_prompt_text(&c->fm, p, (int)sizeof(p));
            tnd_conn_send(c, p);
            return;
        }
        return;                    /* обзор/просмотр — чистый экран */
    }
    tnd_conn_send(c, "n2600> ");
}

static void tnd_exec_line(tnd_conn_t *c)
{
    char cmd[TND_LINE_MAX + 1];
    strcpy(cmd, c->line);
    c->llen = 0;
    c->line[0] = 0;

    char *p = cmd;
    while (*p == ' ') p++;
    if (!*p) { tnd_prompt(c); return; }

    /* ---- Task 46/48: файловый менеджер (dfm, полноэкранный) ---- */
    if (c->fm_mode) {
        if (c->fm.mode == 2)
            dfm_edit_line(&c->fm, p);
        else if (c->fm.mode == 3)
            dfm_prompt_line(&c->fm, p);
        c->fm_mode = dfm_active(&c->fm);
        if (c->fm_mode && !dfm_wants_line(&c->fm))
            return;          /* вернулись в обзор — экран уже перерисован */
        tnd_prompt(c);
        return;
    }
    if (!strcmp(p, "fm") || !strcmp(p, "files")) {
        /* вход в менеджер: полноэкранный обзор (dfm, адаптация
         * dylanaraps/dfm) */
        c->fm_mode = 1;
        dfm_enter(&c->fm, tnd_fm_put, c);
        c->fm_mode = dfm_active(&c->fm);
        if (c->fm_mode && !dfm_wants_line(&c->fm)) return;
        tnd_prompt(c);
        return;
    }

    if (!strcmp(p, "exit") || !strcmp(p, "quit") || !strcmp(p, "logout")) {
        tnd_conn_close(c, "До встречи!");
        return;
    }
    if (!strcmp(p, "reboot") || !strcmp(p, "poweroff")) {
        /* удалённое выключение физической машины — запрещаем */
        tnd_conn_send(c,
            "reboot/poweroff через telnet запрещён — выполните локально\r\n");
        tnd_prompt(c);
        return;
    }

    {
        char lg[TND_LINE_MAX + 24];
        snprintf(lg, sizeof(lg), "[telnetd] exec: %s\n", p);
        serial_puts(lg);
        klog_puts(lg);
    }

    /* вывод команды идёт в sink (tnd_sink_put → сокет);
     * [TERM-SINK-NL] term_print теперь сам добавляет \n —
     * отдельный \r\n после команды больше не нужен */
    term_shell_exec(c->term, p);
    tnd_prompt(c);
}

/* ---------- обработка одного байта (IAC + строка) ---------- */

static void tnd_process_byte(tnd_conn_t *c, unsigned char b)
{
    if (c->iac == IAC_OPT) {
        /* Task 50 [TND-CHARMODE]: осмысленное согласование вместо слепых
         * отказов. Поддерживаем ровно то, что делаем:
         *   DO ECHO  → WILL ECHO (эхоим мы — строковый редактор shell),
         *   DO SGA   → WILL SGA  (Go-Ahead подавляем),
         *   WILL SGA → DO SGA    (и от клиента GA не нужен),
         *   прочее   → WONT/DONT (NAWS/TTYPE/LINEMODE/...).
         * Ответ шлём только при ИЗМЕНЕНИИ состояния — повторные WILL/DO
         * клиента больше не порождают противоречащих ответов. */
        if (c->iac_cmd == 0xFD) {                      /* клиент: DO <opt> */
            if (b == 0x01) {
                if (!c->opt_will_echo) {
                    c->opt_will_echo = 1;
                    tnd_send_iac(c, 0xFB, b);          /* WILL ECHO */
                }
            } else if (b == 0x03) {
                if (!c->opt_will_sga) {
                    c->opt_will_sga = 1;
                    tnd_send_iac(c, 0xFB, b);          /* WILL SGA */
                }
            } else {
                tnd_send_iac(c, 0xFC, b);              /* WONT <opt> */
            }
        } else {                                       /* клиент: WILL <opt> */
            if (b == 0x03) {
                if (!c->opt_do_sga) {
                    c->opt_do_sga = 1;
                    tnd_send_iac(c, 0xFD, b);          /* DO SGA */
                }
            } else {
                tnd_send_iac(c, 0xFE, b);              /* DONT <opt> */
            }
        }
        c->iac = IAC_NONE;
        return;
    }
    if (c->iac == IAC_GOT) {
        c->iac = IAC_NONE;
        /* Task 50 [TND-SBSE]: внутри SB сначала проверяем его окончание.
         * Раньше IAC SE разбирается в этой ветке как «прочее молча» и
         * sb_skip НЕ сбрасывался — после первого SB (NAWS/TTYPE от
         * клиента) сервер глотал ВЕСЬ ввод до конца сессии. */
        if (c->sb_skip) {
            if (b == 0xF0) c->sb_skip = 0;   /* IAC SE — конец SB */
            /* IAC IAC внутри SB — экранированный 0xFF, остаёмся в SB;
             * прочее — мусор внутри SB, игнорируем */
            return;
        }
        if (b == 0xFA) { c->sb_skip = 1; return; }          /* SB */
        if (b == 0xFB || b == 0xFD) {                        /* WILL/DO */
            c->iac = IAC_OPT;
            c->iac_cmd = b;
            return;
        }
        if (b == 0xFF) goto data;                            /* IAC IAC = 0xFF */
        return;                                              /* прочее молча */
    }
    if (c->sb_skip) {
        if (b == 0xFF) { c->iac = IAC_GOT; return; }
        if (b == 0xF0) c->sb_skip = 0;                       /* SE */
        return;
    }
    if (b == 0xFF) { c->iac = IAC_GOT; return; }

data:
    /* ---- Task 48: dfm в посимвольных режимах (обзор/просмотр) ----
     * Все байты — в менеджер (экран, ESC-стрелки); строковая сборка
     * (эхо/бэкспейс) здесь не нужна. Ctrl+D закрывает соединение,
     * Ctrl+C — выход из менеджера в shell. */
    if (c->fm_mode && !dfm_wants_line(&c->fm)) {
        if (b == 0x04) {
            tnd_conn_close(c, "exit (Ctrl+D)");
            return;
        }
        dfm_key(&c->fm, b);
        c->fm_mode = dfm_active(&c->fm);
        if (!c->fm_mode) {
            tnd_prompt(c);                   /* вышли из менеджера */
        } else if (dfm_wants_line(&c->fm)) {
            tnd_prompt(c);                   /* вошли в редактор/промпт */
        }
        return;
    }
    if (b == '\r') {                                         /* Enter */
        tnd_conn_send(c, "\r\n");
        tnd_exec_line(c);
        return;
    }
    if (b == '\n' || b == 0) return;                         /* после \r */
    if (b == 0x7F || b == 0x08) {                            /* Backspace */
        if (c->llen > 0) {
            c->line[--c->llen] = 0;
            tnd_conn_send(c, "\b \b");
        }
        return;
    }
    if (b == 0x15) {                                         /* Ctrl+U */
        while (c->llen > 0) {
            c->line[--c->llen] = 0;
            tnd_conn_send(c, "\b \b");
        }
        return;
    }
    if (b == 0x03) {                                         /* Ctrl+C */
        c->llen = 0;
        c->line[0] = 0;
        tnd_conn_send(c, "^C\r\n");
        tnd_prompt(c);
        return;
    }
    if (b == 0x04) {                                         /* Ctrl+D */
        tnd_conn_close(c, "exit (Ctrl+D)");
        return;
    }
    if (b < 32) return;                                      /* прочие управляющие */

    if (c->llen < TND_LINE_MAX) {
        char eb[2];
        eb[0] = (char)b;
        eb[1] = 0;
        c->line[c->llen++] = eb[0];
        c->line[c->llen] = 0;
        tnd_conn_send(c, eb);                                /* эхо */
    }
}

/* ---------- соединения ---------- */

static void tnd_conn_close(tnd_conn_t *c, const char *why)
{
    if (c->sock >= 0) {
        if (why) {
            tnd_conn_send(c, why);
            tnd_conn_send(c, "\r\n");
        }
        char lg[64];
        snprintf(lg, sizeof(lg), "[telnetd] соединение закрыто (слот %d)\n",
                 (int)(c - g_conns));
        serial_puts(lg);
        net_tcp_unpin(c->sock);
        net_tcp_close(c->sock);
    }
    c->sock = -1;
    c->inbuf_n = 0;
    c->llen = 0;
    c->line[0] = 0;
    c->iac = IAC_NONE;
    c->sb_skip = 0;
    /* Task 46/48: менеджер закрывается вместе с соединением */
    c->fm_mode = 0;
    dfm_reset(&c->fm);
    /* headless-терминал живёт в слоте постоянно (создан в start) —
     * только очищаем привязку sink-контекста не нужно: слот свой */
}

static void tnd_accept(int new_sock, u32 remote_ip, u16 remote_port)
{
    (void)remote_port;
    for (int i = 0; i < TELNETD_CONNS; i++) {
        tnd_conn_t *c = &g_conns[i];
        if (c->sock >= 0) continue;
        c->sock = new_sock;
        c->gen = net_tcp_gen(new_sock);
        net_tcp_pin(new_sock);                 /* [PIN] */
        c->llen = 0;  c->line[0] = 0;
        c->iac = IAC_NONE;
        c->sb_skip = 0;
        c->inbuf_n = 0;
        c->last_tick = timer_ticks();
        /* Баннер/IAC НЕ отправляем здесь: accept вызывается ИЗ net_poll
         * (kmain), а отправка с ожиданием ACK внутри net_poll дала бы
         * реентерабельный вход в стек. Отметим — баннер пришлёт задача
         * telnetd на первом же опросе (≤ 20 мс). */
        c->need_hello = 1;
        {
            char ipb[16], lg[80];
            net_ntoa(remote_ip, ipb, sizeof(ipb));
            snprintf(lg, sizeof(lg), "[telnetd] подключение от %s (слот %d)\n",
                     ipb, i);
            serial_puts(lg);
            klog_puts(lg);
        }
        return;
    }
    /* слотов нет — отказ */
    net_tcp_close(new_sock);
}

/* приветствие клиента (выполняется В ЗАДАЧЕ telnetd, не в net_poll) */
static void tnd_hello(tnd_conn_t *c)
{
    /* согласование character-at-a-time с серверным эхом (RFC 854/857);
     * DONT LINEMODE (34) — явный отказ от linemode для клиентов с ним
     * по умолчанию (PuTTY); [TND-CHARMODE] */
    static const char iac_init[] =
        "\xff\xfb\x01"                 /* IAC WILL ECHO */
        "\xff\xfb\x03"                 /* IAC WILL SGA */
        "\xff\xfd\x03"                 /* IAC DO  SGA */
        "\xff\xfe\x22";                /* IAC DONT LINEMODE */
    tnd_send_raw(c->sock, c->gen, iac_init, sizeof(iac_init) - 1);
    c->opt_will_echo = 1;
    c->opt_will_sga = 1;
    c->opt_do_sga = 1;
    tnd_conn_send(c, "N2600-OS telnet server\r\n");
    tnd_conn_send(c, "help - список команд; fm - файловый менеджер (dfm); exit - отключиться\r\n\r\n");
    tnd_prompt(c);
}

/* ---------- обслуживающая задача ---------- */

static void telnetd_task_fn(void *arg)
{
    (void)arg;
    g_task_alive = 1;
    for (;;) {
        if (!g_started) { task_msleep(200); continue; }
        for (int i = 0; i < TELNETD_CONNS; i++) {
            tnd_conn_t *c = &g_conns[i];
            if (c->sock < 0) continue;
            if (net_tcp_gen(c->sock) != c->gen) {
                tnd_conn_close(c, NULL);
                continue;
            }
            tcp_state_t st = net_tcp_state(c->sock);
            if (net_tcp_was_reset(c->sock) ||
                st == TCP_CLOSE_WAIT || st == TCP_LAST_ACK ||
                st == TCP_CLOSED) {
                tnd_conn_close(c, NULL);
                continue;
            }
            if (c->need_hello) {
                c->need_hello = 0;
                c->last_tick = timer_ticks();
                tnd_hello(c);
                continue;
            }
            if ((timer_ticks() - c->last_tick) > TND_IDLE_MS) {
                tnd_conn_close(c, "таймаут бездействия (10 мин)");
                continue;
            }
            char tmp[128];
            int n;
            while ((n = tnd_inbuf_take(c, tmp, (int)sizeof(tmp))) > 0)
                for (int k = 0; k < n; k++)
                    tnd_process_byte(c, (unsigned char)tmp[k]);
        }
        task_msleep(20);
    }
}

/* ---------- конфигурация/старт/стоп ---------- */

/* Строка "telnet=0" в SETTINGS.CFG отключает автостарт.
 * По умолчанию сервер ВКЛЮЧЁН (запрос пользователя). */
static void tnd_load_cfg(void)
{
    if (!ramfs_ready()) return;
    ramfs_dirent_t de;
    if (!ramfs_stat_ci("SETTINGS.CFG", &de) || de.is_dir) return;
    if (de.size == 0 || de.size > 8192) return;
    char *buf = (char *)malloc(de.size + 1);
    if (!buf) return;
    u32 n = ramfs_read("SETTINGS.CFG", buf, de.size);
    if (n == 0) { free(buf); return; }
    buf[n] = 0;
    for (char *p = buf; *p; ) {
        char *e = p;
        while (*e && *e != '\n' && *e != '\r') e++;
        char save = *e; *e = 0;
        if (strncmp(p, "telnet=", 7) == 0) {
            if (strcmp(p + 7, "0") == 0)      g_want = 0;
            else if (strcmp(p + 7, "1") == 0) g_want = 1;
        }
        *e = save;
        p = (*e) ? e + 1 : e;
    }
    free(buf);
}

static void tnd_slots_reset(void)
{
    for (int i = 0; i < TELNETD_CONNS; i++) {
        g_conns[i].sock = -1;
        g_conns[i].gen = 0;
        g_conns[i].term = NULL;
        g_conns[i].llen = 0;
        g_conns[i].line[0] = 0;
        g_conns[i].iac = IAC_NONE;
        g_conns[i].iac_cmd = 0;
        g_conns[i].sb_skip = 0;
        g_conns[i].opt_will_echo = 0;
        g_conns[i].opt_will_sga = 0;
        g_conns[i].opt_do_sga = 0;
        g_conns[i].inbuf_n = 0;
        g_conns[i].inbuf_lock = 0;
        g_conns[i].last_tick = 0;
        g_conns[i].need_hello = 0;
        g_conns[i].fm_mode = 0;
        dfm_reset(&g_conns[i].fm);
    }
}

static void tnd_spawn_task(void)
{
    if (g_task_alive) return;
    /* [TND-PRIO] (Task 43): задача telnetd — НЕ BG. Причина: kmain
     * (TASK_PRIO_UI) готов ВСЕГДА — hlt() не снимает готовность, поэтому
     * планировщик на каждом тике выбирает UI-уровень, а BG-задачи
     * получают ровно 1 тик из TASK_STARVE_TICKS=250 (анти-голодание),
     * хотя CPU всё это время простаивает в hlt (см. комментарий СЕССИИ 37
     * в kernel.c у wifi-задачи — тот же корень). На таких крошках эхо
     * каждого нажатия и каждый исходящий кусок задерживались на 250+ мс:
     * «буква в секунду при вводе, сообщение в секунду при выводе» при
     * загрузке CPU 1-2% (система простаивает — голодает только BG).
     * telnetd большую часть времени СПИТ (task_msleep(20) без данных) —
     * в waiting-состоянии он планировщик не занимает; UI-приоритет
     * активен лишь пока есть ввод/вывод (round-robin 1:1 с kmain).
     * Долгие команды тормозят GUI вдвое, но не «замораживают» его.
     * task_set_system — как раньше (ватчдог >5 с долгие команды не убивает). */
    int tid = task_spawn_prio("telnetd", telnetd_task_fn, NULL, TASK_PRIO_UI);
    if (tid > 0) task_set_system(tid);
}

int telnetd_start(void)
{
    if (g_started) return 0;
    tnd_slots_reset();
    /* headless-терминалы — ЗАРАНЕЕ (не в accept-колбэке) */
    for (int i = 0; i < TELNETD_CONNS; i++) {
        g_conns[i].term = term_headless_create();
        if (!g_conns[i].term) {
            serial_puts("[telnetd] нет памяти под терминалы\n");
            return -1;
        }
        term_headless_sink(g_conns[i].term, tnd_sink_put, &g_conns[i]);
    }
    if (net_tcp_listen(TELNET_PORT, tnd_accept, tnd_recv) < 0) {
        serial_puts("[telnetd] не удалось слушать :23\n");
        return -1;
    }
    g_started = 1;
    serial_puts("[telnetd] слушает :23 (shell как в локальном терминале)\n");
    klog_puts("[telnetd] слушает :23\n");
    return 0;
}

void telnetd_stop(void)
{
    if (!g_started) return;
    for (int i = 0; i < TELNETD_CONNS; i++)
        if (g_conns[i].sock >= 0)
            tnd_conn_close(&g_conns[i], "Сервер остановлен");
    net_tcp_unlisten(TELNET_PORT);
    g_started = 0;
    serial_puts("[telnetd] остановлен\n");
    klog_puts("[telnetd] остановлен\n");
}

void telnetd_autostart(void)
{
    tnd_load_cfg();
    if (!g_want) {
        serial_puts("[telnetd] отключён настройками (telnet=0 в SETTINGS.CFG)\n");
        klog_puts("[telnetd] отключён настройками\n");
        return;
    }
    if (telnetd_start() != 0) return;
    tnd_spawn_task();
}

int telnetd_wanted(void)  { return g_want; }
int telnetd_running(void) { return g_started; }

void telnetd_set_enabled(int on)
{
    g_want = on ? 1 : 0;
    if (g_want) {
        if (telnetd_start() == 0)
            tnd_spawn_task();
    } else {
        telnetd_stop();
    }
}
