/* kernel.c — точка входа N2600-OS.
 *
 * Multiboot-заголовок (AOUT_KLUDGE + VIDEO_MODE) лежит в секции .text.mb —
 * в самом начале образа, поэтому GRUB находит его в первых 8 КиБ плоского
 * бинарника, собираемого MinGW. GRUB выставляет VESA-режим по полям
 * заголовка (1280x600x32 + запасные), включает защищённый режим и передаёт
 * управление на kstart.
 */
#include "types.h"
#include "io.h"
#include "boot.h"
#include "gdt.h"
#include "idt.h"
#include "mem.h"
#include "timer.h"
#include "kbd.h"
#include "mouse.h"
#include "fb.h"
#include "wm.h"
#include "apps.h"
#include "string.h"
#include "kernel.h"
#include "mtrr.h"    /* mtrr_lfb_wc (Task 49: mtrr.c) */
#include "ata.h"
#include "ahci.h"
#include "disk.h"
#include "fat32.h"
#include "ntfs.h"
#include "iso9660.h"
#include "ramfs.h"
#include "imgres.h"  /* сессия 55: LOGO.PNG/IMG.JS в RAM disk */
#include "task.h"
#include "setjmp.h"   /* СЕССИЯ 81 [KMAIN-RECOVER]: setjmp-точка kmain */
#include "apipc.h"     /* ШАГ 4: IPI-syscall mailbox + поллинг в kmain */
#include "gma3600.h"   /* [GMA3600]: нативные 1024x600 на Cedarview (нетбук) */
#include "gma3600_2d.h"/* [Дисплей] GMA3600: снятие курсорных плоскостей + GTT (сессия 90) */
#include "gfx2d.h"
#include "hwinfo.h"   /* [hwinfo] hwdet-подобная диагностика ACPI/DSDT/SMBIOS (сессия 90) */
#include "usb.h"
#include "usb_ehci.h"   /* usb_ehci_hotplug_service (hot-plug wifi-задачи) */
#include "ath9k_wifi.h"
#include "e1000.h"
#include "ne2000.h"
#include "atl1c.h"
#include "virtio_net.h"
#include "net.h"
#include "net_httpd.h"
#include "telnetd.h"   /* итерация 7: telnet-сервер :23 (галочка в Настройках) */
#include "sound.h"
#include "font.h"
#include "sync.h"
#include "pci.h"
#include "smp.h"

/* Символы linker-скрипта: в C пишутся без ведущего подчёркивания
 * (COFF MinGW добавит его автоматически, совпадая с именами в скрипте). */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

/* --------------------------- служебное --------------------------- */

static const mb_info_t *g_mbi = NULL;

const mb_info_t *mb_info(void) { return g_mbi; }

void sys_reboot(void)
{
    cli();
    for (u32 i = 0; i < 100000 && (inb(0x64) & 0x02); i++) {}
    outb(0x64, 0xFE);
    for (;;)
        hlt();
}

void sys_poweroff(void)
{
    cli();
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    for (;;)
        hlt();
}

/* ============ СЕССИЯ 85: «инициализация служб» (панель над часами) ============
 * Каждый шаг загрузки/фонового сервиса вызывает boot_step(): панель в WM
 * показывает done/total и исчезает при полной готовности. Шаги подобраны
 * ДЕТЕРМИНИРОВАННЫМИ (завершаются всегда, пусть и с неудачей) — полоса
 * гарантированно доходит до конца: wifi-хук стоит на g_wifi_state=2
 * (после wifi_init, до цикла ожидания hot-plug), sata-хук — в конце
 * sata_task_fn. */
#define BOOT_STEPS_TOTAL 14   /* сессия 90: voodoo3-шаг удалён */
static int boot_steps_done = 0;
static void boot_step(void)
{
    boot_steps_done++;
    wm_boot_progress(boot_steps_done, BOOT_STEPS_TOTAL);
}

/* ------------------------------ kmain ------------------------------ */

/* ================= Рамфс-сидинг: /boot/ramdisk из ISO =================
 * Каталог рядом с ядром в ISO (/boot/ramdisk) копируется в RAM disk при
 * загрузке — каждый файл, если хватает места (ramfs_free_space).
 * Не поместившиеся/слишком большие файлы пропускаются с сообщением.
 * Выполняется однопоточно до sti() — без блокировок.
 *
 * FIX [R1] (пустой ramfs без сообщений): раньше ВСЕ причины пропуска
 * (нет ISO, нет /boot, нет /boot/ramdisk) сообщались ТОЛЬКО в serial
 * или молча — на экране не было ничего, ramfs оставался пустым «без
 * объяснений». Теперь каждая причина видна на экране (dbg_err).
 * Дополнительно: если с ISO ничего не скопировано, пробуем каталог
 * \RAMDISK на FAT32-диске (НЖМД) — см. ramfs_seed_from_fat32. */
#define RAMSEED_MAX_FILE (256 * 1024)

static int rs_ci_eq(char a, char b)
{
    if (a >= 'A' && a <= 'Z') a += 32;
    if (b >= 'A' && b <= 'Z') b += 32;
    return a == b;
}

static int rs_ci_same(const char *a, const char *b)
{
    while (*a && *b) {
        if (!rs_ci_eq(*a, *b)) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

static void rs_lower(char *dst, const char *src, int dstsz)
{
    int i = 0;
    while (src[i] && i < dstsz - 1) {
        char c = src[i];
        if (c >= 'A' && c <= 'Z') c += 32;
        dst[i++] = c;
    }
    dst[i] = 0;
}

/* Общая часть: скопировать один файл объёмом sz в RAM disk. */
static int rs_put_file(const char *name, u8 *data, u32 sz)
{
    char lname[80];
    rs_lower(lname, name, sizeof(lname));
    if (ramfs_create(lname, sz)) {
        ramfs_write(lname, data, sz);
        return 1;
    }
    return 0;
}

static void ramfs_seed_from_iso(void)
{
    if (!iso9660_ready() || !ramfs_ready()) {
        dbg_err("ramdisk: ISO/CD не найден — сидинг из ISO пропущен");
        return;
    }

    /* / -> boot */
    iso9660_dirent_t root[32];
    int n = iso9660_list_root(root, 32);
    u32 boot_lba = 0, boot_size = 0;
    int have_boot = 0;
    for (int i = 0; i < n; i++) {
        if (root[i].is_dir && rs_ci_same(root[i].name, "boot")) {
            boot_lba = root[i].first_lba;
            boot_size = root[i].size;
            have_boot = 1;
            break;
        }
    }
    if (!have_boot) {
        dbg_err("ramdisk: /boot не найден в ISO — сидинг пропущен");
        return;
    }

    /* /boot -> ramdisk */
    iso9660_dirent_t bd[64];
    int m = iso9660_list_dir(boot_lba, boot_size, 0, bd, 64);
    u32 rd_lba = 0, rd_size = 0;
    int have_rd = 0;
    for (int i = 0; i < m; i++) {
        if (bd[i].is_dir && rs_ci_same(bd[i].name, "ramdisk")) {
            rd_lba = bd[i].first_lba;
            rd_size = bd[i].size;
            have_rd = 1;
            break;
        }
    }
    if (!have_rd) {
        dbg_err("ramdisk: /boot/ramdisk не найден в ISO — сидинг пропущен");
        return;
    }

    /* файлы /boot/ramdisk -> RAM disk (имена с расширением, в нижнем регистре) */
    iso9660_dirent_t files[64];
    int k = iso9660_list_dir(rd_lba, rd_size, 1, files, 64);
    int copied = 0, skipped = 0;
    u32 total = 0;

    for (int i = 0; i < k; i++) {
        if (files[i].is_dir) continue;
        u32 sz = files[i].size;
        if (sz == 0) continue;

        if (sz > RAMSEED_MAX_FILE) {
            char buf[96];
            snprintf(buf, sizeof(buf),
                     "[ramseed] %s: %u KiB > лимита, пропущен",
                     files[i].name, (unsigned)(sz / 1024));
            dbg_err(buf);
            skipped++;
            continue;
        }
        if (sz > ramfs_free_space()) {
            char buf[96];
            snprintf(buf, sizeof(buf),
                     "[ramseed] %s: не хватает места в RAM disk (нужно %u, свободно %u)",
                     files[i].name, (unsigned)sz, (unsigned)ramfs_free_space());
            dbg_err(buf);
            skipped++;
            continue;
        }

        u8 *tmp = (u8 *)malloc(sz);
        if (!tmp) { skipped++; continue; }
        u32 got = iso9660_read_file(files[i].first_lba, sz, tmp, sz);
        if (got == 0) {
            free(tmp);
            skipped++;
            continue;
        }

        if (rs_put_file(files[i].name, tmp, sz)) {
            copied++;
            total += sz;
            /* Процесс загрузки: каждый скопированный файл виден на
             * экране И в dmesg (раньше — только итоговая строка). */
            {
                char b[96];
                snprintf(b, sizeof(b), "[ramdisk] + %s (%u байт)",
                         files[i].name, (unsigned)sz);
                dbg(b);
            }
        } else {
            skipped++;
        }
        free(tmp);
    }

    {
        char buf[96];
        snprintf(buf, sizeof(buf),
                 "ramdisk: /boot/ramdisk -> RAM disk: %d файлов, %u байт%s",
                 copied, (unsigned)total,
                 skipped ? ", часть пропущена" : "");
        if (copied) dbg(buf);
        else dbg_err(buf);
    }
}

/* FIX [R2]: сидинг из каталога \\RAMDISK на FAT32 (НЖМД).
 * Если ОС загружена БЕЗ ATAPI CD (например, с USB-флешки, которую
 * ядро читать не умеет), файлы для RAM disk можно положить на
 * FAT32-раздел жёсткого диска в каталог RAMDISK — они скопируются
 * отсюда. Вызывается только если из ISO не скопировано ни одного файла. */
static void ramfs_seed_from_fat32(void)
{
    if (!fat32_ready() || !ramfs_ready()) {
        dbg_err("ramdisk: FAT32-диск тоже недоступен — RAM disk пуст");
        return;
    }

    /* корень FAT32 -> каталог RAMDISK */
    fat32_dirent_t root[32];
    int n = fat32_list(fat32_root_cluster(), root, 32);
    u32 rd_cluster = 0;
    int have_rd = 0;
    for (int i = 0; i < n; i++) {
        if ((root[i].attr & 0x10) && rs_ci_same(root[i].name, "ramdisk")) {
            rd_cluster = root[i].first_cluster;
            have_rd = 1;
            break;
        }
    }
    if (!have_rd) {
        dbg_err("ramdisk: каталог RAMDISK на FAT32 не найден — сидинг пропущен");
        return;
    }

    fat32_dirent_t files[32];
    int k = fat32_list(rd_cluster, files, 32);
    int copied = 0, skipped = 0;
    u32 total = 0;

    for (int i = 0; i < k; i++) {
        if (files[i].attr & 0x10) continue;
        u32 sz = files[i].size;
        if (sz == 0 || sz > RAMSEED_MAX_FILE) { skipped++; continue; }
        if (sz > ramfs_free_space()) { skipped++; continue; }

        u8 *tmp = (u8 *)malloc(sz);
        if (!tmp) { skipped++; continue; }
        u32 got = fat32_read_file(files[i].first_cluster, sz, tmp, sz);
        if (got == 0) {
            free(tmp);
            skipped++;
            continue;
        }
        if (rs_put_file(files[i].name, tmp, sz)) {
            copied++;
            total += sz;
            {
                char b[96];
                snprintf(b, sizeof(b), "[ramdisk] + %s (%u байт)",
                         files[i].name, (unsigned)sz);
                dbg(b);
            }
        } else {
            skipped++;
        }
        free(tmp);
    }

    {
        char buf[96];
        snprintf(buf, sizeof(buf),
                 "ramdisk: FAT32 \\RAMDISK -> RAM disk: %d файлов, %u байт%s",
                 copied, (unsigned)total,
                 skipped ? ", часть пропущена" : "");
        if (copied) dbg(buf);
        else dbg_err(buf);
    }
}

/* ---------- настройки сети (RAM disk SETTINGS.CFG) ----------
 * Формат: строки "ключ=значение":
 *   adapter=auto|<имя NIC>            — приоритет адаптера (сессия 11)
 *   netmode=dhcp|static               — режим IP (сессия 27)
 *   ip=/mask=/gw=/dns=a.b.c.d         — статические адреса (сессия 27)
 * Загружаются ДО net_init (режим приоритета); статические адреса
 * netmon применяет к активному адаптеру, когда появится линк. */
#define SETTINGS_FILE "SETTINGS.CFG"

/* g_netmon_dhcp_redo объявлен здесь (выше), т.к. netcfg_use_static
 * и net_request_dhcp управляют им, а net_settings_load читает
 * статические адреса до запуска netmon. */
static volatile int g_netmon_dhcp_redo = 1;   /* 1 = нужен цикл DHCP */

/* Публичное: перезапросить DHCP (кнопка в Настройках, команда в терминале) */
void net_request_dhcp(void)
{
    net_dhcp_reset();
    g_netmon_dhcp_redo = 1;
}

/* ---------- статическая настройка IP (сессия 27) ----------
 * Настройки → Сеть: режим DHCP или статический (IP/маска/шлюз/DNS).
 * Значения хранятся здесь; netmon применяет их к активному адаптеру
 * (шаг 2) вместо DHCP — и повторно после смены адаптера
 * (netmon_adapter_changed снова взводит g_netmon_dhcp_redo).
 * Сохраняются в SETTINGS.CFG приложением «Настройки». */
static volatile int g_netcfg_static = 0;   /* 0 = DHCP, 1 = статический */
static u32 g_stat_ip, g_stat_mask, g_stat_gw, g_stat_dns;

int  netcfg_static_mode(void) { return g_netcfg_static; }

void netcfg_static_get(u32 *ip, u32 *mask, u32 *gw, u32 *dns)
{
    if (ip)   *ip   = g_stat_ip;
    if (mask) *mask = g_stat_mask;
    if (gw)   *gw   = g_stat_gw;
    if (dns)  *dns  = g_stat_dns;
}

void netcfg_use_static(int on)
{
    if (on) {
        g_netcfg_static = 1;
        net_dhcp_reset();             /* прервать текущую транзакцию */
        g_netmon_dhcp_redo = 1;       /* netmon применит статику */
    } else if (g_netcfg_static) {
        g_netcfg_static = 0;
        net_request_dhcp();           /* возврат к DHCP */
    }
}

void netcfg_set_static(u32 ip, u32 mask, u32 gw, u32 dns)
{
    g_stat_ip = ip;
    g_stat_mask = mask ? mask : 0xFFFFFF00u;   /* пусто → /24 */
    g_stat_gw = gw;
    g_stat_dns = dns;
    netcfg_use_static(1);
}

static void net_settings_load(void)
{
    if (!ramfs_ready()) return;
    char buf[256];
    u32 n = ramfs_read(SETTINGS_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return;
    buf[n] = 0;
    char *p = buf;
    while (*p) {
        char *e = p;
        while (*e && *e != '\n' && *e != '\r') e++;
        char saved = *e;
        *e = 0;
        if (memcmp(p, "adapter=", 8) == 0) {
            const char *v = p + 8;
            int mode = 0;                     /* "auto" */
            if (strcmp(v, "auto") != 0) {
                int idx = net_adapter_find(v);
                if (idx >= 0) mode = idx + 1;
            }
            net_settings_set_adapter(mode);
            {
                char b[80];
                snprintf(b, sizeof(b), "net: настройки: адаптер %s",
                         mode == 0 ? "авто" : v);
                dbg(b);
            }
        } else if (memcmp(p, "netmode=", 8) == 0) {
            const char *v = p + 8;
            g_netcfg_static = (strcmp(v, "static") == 0) ? 1 : 0;
            dbg(g_netcfg_static ? "net: настройки: режим статический"
                                : "net: настройки: режим DHCP");
        } else if (memcmp(p, "ip=", 3) == 0) {
            u32 v;
            if (net_aton(p + 3, &v)) g_stat_ip = v;
        } else if (memcmp(p, "mask=", 5) == 0) {
            u32 v;
            if (net_aton(p + 5, &v)) g_stat_mask = v;
        } else if (memcmp(p, "gw=", 3) == 0) {
            u32 v;
            if (net_aton(p + 3, &v)) g_stat_gw = v;
        } else if (memcmp(p, "dns=", 4) == 0) {
            u32 v;
            if (net_aton(p + 4, &v)) g_stat_dns = v;
        }
        *e = saved;
        p = (*e) ? e + 1 : e;
    }
}

/* ---------- фоновая задача сети netmon (сессия 11) ----------
 * Замена одноразового netcfg: теперь задача ПОСТОЯННАЯ.
 *   1) ждёт адаптер с линком (WiFi-ассоциация занимает секунды);
 *   2) получает адреса по DHCP на активном адаптере;
 *   3) следит за линком: адаптер потерял линк → авто-переключение
 *      на лучший (например lan без кабеля → wifi) и повтор DHCP.
 * Раньше DHCP безусловно уходил в ПЕРВЫЙ найденный NIC: на X101CH
 * это atl1c без кабеля — «не могу проверить работу сети», хотя WiFi
 * ассоциирован. */
static void netmon_adapter_changed(void)
{
    /* активный адаптер сменился (авто-переключение или выбор в Настройках):
     * сбрасываем адреса — они принадлежали другому сегменту */
    net_set_ip(0);
    net_set_gateway(0);
    /* [IP-CHG3] (Task 41, повтор Task 40): маска и DNS тоже принадлежали
     * прежнему сегменту — оставшиеся значения давали.route в чужую сеть
     * и резолв через чужой DNS до нового DHCP */
    net_set_netmask(0);
    net_dns_set_server(0);
    net_dhcp_reset();
    g_netmon_dhcp_redo = 1;
}

static void netmon_task_fn(void *arg)
{
    (void)arg;
    char ipbuf[16];
    u32 quiet_until = 0;                      /* анти-спам повторов DHCP */
    u32 backoff_ms = 5000;                    /* сессия 12: пауза между
                 * неудачами растёт 5→10→20→30 с (потолок), вместо
                 * безостановочного молотка DISCOVER каждые ~5 с.
                 * После успеха сбрасывается. */

    for (;;) {
        /* 1) ждать адаптер с линком (до 60 с, затем цикл повторится) */
        int waited = 0;
        while (!net_nic_present() ||
               !net_adapter_link(net_adapter_active())) {
            net_adapter_check();              /* автопереключение на лучший */
            if (g_netmon_dhcp_redo) break;    /* смена адаптера — наверх */
            task_msleep(20);
            if (++waited > 3000) break;
        }

        int link_up = net_nic_present() &&
                      net_adapter_link(net_adapter_active());

        /* 2) адреса на активном адаптере: статика (сессия 27) или DHCP */
        if (link_up && g_netmon_dhcp_redo) {
            g_netmon_dhcp_redo = 0;
            if (g_netcfg_static) {
                /* Статический режим: DHCP не запускаем, применяем
                 * сохранённые адреса (при пустой маске — /24). */
                net_set_ip(g_stat_ip);
                net_set_netmask(g_stat_mask ? g_stat_mask : 0xFFFFFF00u);
                net_set_gateway(g_stat_gw);
                if (g_stat_dns) net_dns_set_server(g_stat_dns);
                {
                    char b[96], ib[16];
                    net_ntoa(g_stat_ip, ib, sizeof(ib));
                    snprintf(b, sizeof(b), "netcfg: статический IP %s применён", ib);
                    dbg(b);
                }
                quiet_until = 0;
                backoff_ms = 5000;
                continue;                 /* к шагу 3 (монитор линка) */
            }
            dbg("netcfg: DHCP DISCOVER...");
            if (net_dhcp_acquire(8000)) {
                char b[96];
                net_ntoa(net_get_ip(), ipbuf, sizeof(ipbuf));
                snprintf(b, sizeof(b), "netcfg: DHCP ok, ip %s", ipbuf);
                dbg(b);
                net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
                snprintf(b, sizeof(b), "netcfg: gw %s", ipbuf);
                dbg(b);
                u32 dns = net_dns_server();
                if (dns) {
                    net_ntoa(dns, ipbuf, sizeof(ipbuf));
                    snprintf(b, sizeof(b), "netcfg: dns %s", ipbuf);
                    dbg(b);
                }
                quiet_until = 0;
                backoff_ms = 5000;            /* успех — сброс backoff */
            } else {
                /* логируем неудачу не чаще раза в 30 с (анти-спам serial) */
                if (quiet_until == 0 ||
                    (i32)(timer_ticks() - quiet_until) >= 0) {
                    dbg("netcfg: DHCP не ответил — адреса по умолчанию");
                    quiet_until = timer_ticks() + 3000;
                }
                task_msleep(backoff_ms);      /* пауза растёт с каждой неудачей */
                if (backoff_ms < 30000) backoff_ms *= 2;
                g_netmon_dhcp_redo = 1;       /* повторим позже */
            }
        }

        /* 3) монитор линка: 100 мс шаг, авто-переключение */
        for (int i = 0; i < 10 && !g_netmon_dhcp_redo; i++) {
            task_msleep(100);
            net_adapter_check();
        }
    }
}

/* ---------- фоновая задача WiFi (СЕССИЯ 15) ----------
 * Запрос пользователя: «на нетбуке долгая загрузка из-за ожидания wifi,
 * нужно вынести его после загрузки ОС». Раньше wifi_init() шёл
 * В БЛОКИРУЮЩЕМ режиме до рабочего стола: PCI-скан + cold reset +
 * INI-записи + калибровки AGC/NF (AR9485) занимают СЕКУНДЫ — как
 * COMRESET у SATA (сессия 11). Теперь инициализация идёт фоновой
 * задачей ПОСЛЕ старта ОС: рабочий стол поднимается сразу, адаптер
 * «доезжает» позже, WiFi-приложение/Настройки показывают статус
 * (wifi_pending()). Сеть достраивается сама:
 *   - ethernet есть при загрузке — net_init как раньше, wifi позже
 *     добавляется в реестр (net_adapter_rescan), netmon переключается
 *     по линку (авто) или вручную;
 *   - wifi — ЕДИНСТВЕННЫЙ NIC (нет ethernet-порта) — задача сама
 *     поднимает net_init + netmon, когда адаптер готов. */
static volatile int g_wifi_state = 0;   /* 0=не начата, 1=идёт, 2=готово */
static volatile int g_netmon_started = 0;

int wifi_pending(void) { return g_wifi_state != 2; }

/* Поднятие сети после того, как wifi-адаптер стал готов (общий код
 * для пути «найден при загрузке» и пути «подключён по hot-plug»). */
static void wifi_net_up(void)
{
    if (net_adapter_count() == 0) {
        /* единственный NIC: сеть ещё не поднята — поднимаем
         * (то же, что kmain делает при ethernet при загрузке) */
        net_settings_load();
        net_init();
        net_adapter_set_change_cb(netmon_adapter_changed);
        net_set_ip(0x0A00020F);
        net_set_gateway(0x0A000202);
        net_set_netmask(0xFFFFFF00);
    } else {
        /* ethernet уже поднял сеть — добавляем wifi в реестр:
         * netmon переключится по линку (авто-режим) */
        net_adapter_rescan();
    }
    /* netmon ещё не запущен? (при загрузке не было НИ ОДНОГО
     * адаптера — теперь есть) */
    if (!g_netmon_started && net_adapter_count() > 0) {
        int tid = task_spawn_prio("netmon", netmon_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) {
            task_set_system(tid);
            g_netmon_started = 1;
            dbg("wifi: netmon запущен (сеть поднята фоном)");
        }
    }
}

/* ---------- СЕССИЯ 35: hot-plug EHCI — отдельная фоновая задача ----------
 * Раньше порты EHCI обслуживала ТОЛЬКО wifi-задача (раз в 500 мс, ПОСЛЕ
 * wifi_init). Если probe-фаза (два полных PCI-скана + bring-up) шла
 * долго, CSC донгла оставался необслуженным — «адаптер не находится»
 * при живом железе. Теперь главный цикл раз в 500 мс проверяет CSC/работу
 * портов (два чтения PORTSC — копейки) и спавнит короткую BG-задачу.
 * Одновременно работает не более одной скан-задачи; на время bring-up
 * RTL8192EU (probe из wifi-задачи) скан замолкает — оба трогают один
 * async-список EHCI. */
static volatile int g_usb_scan_running = 0;

/* СЕССИЯ 40: жива ли wifi-задача (для повторного спавна восстановления):
 * инкремент на входе, декремент перед выходом в готовом состоянии;
 * цикл ожидания адаптера держит счётчик навсегда (задача жива). */
static volatile int g_wifi_task_alive = 0;
static volatile int g_wifi_spawn_pending = 0;

static void wifi_task_fn(void *arg);   /* сессия 40: forward — спавн ниже по коду */

static void wifi_task_spawn(void)
{
    g_wifi_spawn_pending = 1;
    task_spawn_prio("wifi", wifi_task_fn, NULL, TASK_PRIO_UI);
}

static void usb_hotplug_task_fn(void *arg)
{
    (void)arg;
    dbg("usb: скан портов EHCI (hot-plug)...");
    for (int i = 0; i < 60; i++) {                 /* до ~18 с */
        if (rtl8192eu_attached() && !rtl8192eu_ready())
            break;   /* wifi-задача поднимает адаптер — не лезть в async-список */
        (void)usb_ehci_hotplug_service();
        if (rtl8192eu_ready()) break;
        if (!usb_ehci_work_pending()) break;       /* все порты пусты/обработаны */
        task_msleep(300);
    }
    if (rtl8192eu_attached())
        dbg("usb: WiFi-устройство зааттачено — wifi-задача выполнит bring-up");
    dbg("usb: скан портов EHCI завершён");
    g_usb_scan_running = 0;
}

static void wifi_task_fn(void *arg)
{
    (void)arg;
    g_wifi_task_alive++;
    g_wifi_spawn_pending = 0;
    /* СЕССИЯ 40: адаптер клин (перестал отвечать по USB) — сначала сброс
     * ПОРТА и переперечисление (прошивку грузить бесполезно: клинит
     * USB-движок чипа), полный bring-up выполнится после нового attach. */
    if (rtl8192eu_wedged())
        rtl8192eu_recover_device();
    g_wifi_state = 1;
    dbg("wifi: фоновая инициализация Atheros...");
    /* СЕССИЯ 37 — КОРЕНЬ «адаптер не находится» (наблюдалось с сессии 34):
     * kmain (приоритет UI) готов ВСЕГДА — hlt() не снимает готовность
     * задачи, поэтому планировщик на КАЖДОМ тике видит best=0 и выбирает
     * UI-уровень; BG-задачи получают ровно 1 тик из TASK_STARVE_TICKS=250
     * (анти-голодание), хотя CPU всё это время простаивает в hlt. На таких
     * крошках PCI-скан Atheros (~30 мс чистого CPU) растягивался на ~8 с
     * wall-времени, а bring-up RTL8192EU (busy-задержки rtl_udelay/mdelay +
     * ~250 control-трансферов прошивки 32 КБ) — на МИНУТЫ: GUI всё это
     * время честно показывал «поиск адаптера», хотя enumeration была ОК.
     * Probe+bring-up — разовая операция на секунды: поднимаем задачу до UI
     * (round-robin с kmain — оба получают каждый второй тик), в цикле
     * ожидания hot-plug возвращаем BG. */
    task_set_priority(task_current(), TASK_PRIO_UI);
    wifi_init();
    g_wifi_state = 2;
    boot_step();                                  /* служба 13/14: wifi (фон) */

    if (wifi_present() && wifi_ready()) {
        dbg("wifi: адаптер готов (фон)");
        wifi_net_up();
        g_wifi_task_alive--;
        return;
    }

    /* Сессия 30 (hot-plug USB WiFi): в VMware адаптер часто подключают
     * ПОСЛЕ старта ВМ (VM -> Removable Devices -> Connect).
     * СЕССИЯ 35: перечисление портов EHCI живёт ОТДЕЛЬНО (usb_hotplug_task_fn,
     * спавнится главным циклом по CSC) — раньше оно было здесь, за
     * wifi_init, и CSC донгла не обслуживался, пока шли PCI-сканы/probe.
     * Эта задача теперь единственный prober: ждёт attach, раз в 2 с
     * пробует bring-up. Цикл бесконечный (спит 99.9% времени).
     * Сессия 57: сердцебиение «ждём USB-адаптер …» раз в 15 с убрано по
     * просьбе пользователя — серийный лог замусоривался. */
    {
        task_set_priority(task_current(), TASK_PRIO_BG);
        dbg("wifi: жду USB-адаптер (скан портов EHCI идёт в фоновой задаче)");
        int probes = 0;
        for (;;) {
            task_msleep(500);
            /* СЕССИЯ 40: ватчдог клина сработал во время ожидания —
             * сбрасываем порт и ждём переперечисления здесь же */
            if (rtl8192eu_wedged()) {
                rtl8192eu_recover_device();
                probes = 0;
                continue;
            }
            if (rtl8192eu_attached()) {
                if ((probes & 3) == 0) {
                    /* bring-up снова на UI — см. комментарий выше */
                    task_set_priority(task_current(), TASK_PRIO_UI);
                    int ok = rtl8192eu_probe();
                    task_set_priority(task_current(), TASK_PRIO_BG);
                    if (ok) {
                        dbg("wifi: адаптер подключён (hot-plug)");
                        wifi_net_up();
                        g_wifi_task_alive--;
                        return;
                    }
                    dbg("wifi: bring-up не удался — повтор через 2 с");
                }
                probes++;
            }
        }
    }
}

/* ---------- фоновая задача SATA (сессия 11) ----------
 * Раньше ahci_init выполнялся В БЛОКИРУЮЩЕМ режиме при загрузке:
 * на реальном железе (N2600 + HDD) COMRESET + раскрутка + IDENTIFY
 * занимали десятки секунд — рабочий стол появлялся только после.
 * Теперь инициализация SATA/НЖМД/файловых систем идёт в фоновой
 * задаче ПОСЛЕ старта ОС: UI поднимается сразу, диск «доезжает»
 * позже (кнопка [HDD] в Файлах активируется сама). Ядро пока
 * однопроцёрное (без SMP), поэтому «на другом ядре» выполнить
 * нельзя — фоновая задача с вытеснением даёт тот же эффект. */
static volatile int g_sata_state = 0;   /* 0=не запускалась, 1=идёт, 2=готово */

int sata_pending(void) { return g_sata_state != 2; }

static void sata_task_fn(void *arg)
{
    (void)arg;
    g_sata_state = 1;
    ahci_set_async(1);            /* ожидания с task_yield, не busy-loop */

    dbg("sata: фоновая инициализация AHCI...");
    if (ahci_init())
        dbg("sata: AHCI-контроллер найден");
    else
        dbg("sata: AHCI-контроллер не найден (IDE-only система)");

    if (disk_hdd_init()) {
        /* СЕССИЯ 73 [CONSOLE]: 96 -> 128 — запас под длинные модели НЖМД */
        char buf[128];
        snprintf(buf, sizeof(buf),
                 "disk: НЖМД через %s: %s, %u МиБ",
                 disk_hdd_bus(), disk_hdd_model(),
                 (unsigned)(disk_hdd_sectors() / 2048u));
        dbg(buf);
    } else {
        dbg("disk: НЖМД не найден ни через AHCI, ни через ATA");
    }

    /* файловые системы: FAT32 (раздел или superfloppy), затем NTFS */
    dbg("fat32_init (фон)...");
    if (fat32_init())
        dbg("fat32: ready");
    else
        dbg_err("fat32: not found");

    dbg("ntfs_init (фон)...");
    if (ntfs_init()) {
        char b[80];
        snprintf(b, sizeof(b), "ntfs: %s", ntfs_label());
        dbg(b);
    } else {
        dbg("ntfs: раздел не найден");
    }

    /* сидинг RAM disk с FAT32 (\RAMDISK) — если ещё пуст */
    {
        ramfs_dirent_t chk[8];
        if (ramfs_ready() && ramfs_list(chk, 8) == 0)
            ramfs_seed_from_fat32();
    }

    /* AHCI ATAPI CD: монтируем ISO, если при загрузке не смонтировали */
    if (!iso9660_ready() && ahci_cd_present())
        if (iso9660_init())
            dbg("iso9660: SATA CD смонтирован (фоново)");

    g_sata_state = 2;
    dbg("sata: инициализация дисков завершена");
    boot_step();                                  /* служба 14/14: sata (фон) */
    task_exit();
}


/* ==================== СЕССИЯ 81 [KMAIN-RECOVER] ====================
 * Запрос пользователя: «проверь, что такие исключения (например, #0 —
 * деление на ноль при трёх калькуляторах) уронят только приложение,
 * но не ядро с графическим интерфейсом». Изоляция исключений ЗАДАЧ
 * работает с сессии 79 ([PANIC-TASK]); осталась последняя дыра —
 * исключение в САМОМ kmain (композитор wm_frame, поллинги мыши/сети,
 * ватчдог — всё исполняется в контексте задачи 0): раньше это был
 * гарантированный красный экран и остановка системы.
 *
 * Теперь: kmain ставит setjmp-точку перед главным циклом; exc_panic
 * (idt.c) для ВОССТАНОВИМЫХ классов (#0 DE, #6 UD, #13 GP) в контексте
 * kmain отпускает всё, что мог держать прерванный кадр (wm_glock —
 * через wm_glock_panic_release, ядровый замок + PIC-маска, fb-конtext —
 * через fb_panic_reset) и делает longjmp сюда. Прерванный кадр
 * пропускается, цикл продолжается — как «skip frame» при занятом glock.
 *
 * Защита от клинча (баг фонтанит исключениями каждый кадр): повторное
 * восстановление разрешено не чаще раза в KMAIN_RECOVER_MIN_MS —
 * частые сбои уходят в честную панику, чтобы не маскировать регресс.
 * Отладка: каждый рецидив печатает в serial «[exc] kmain пережил #N
 * (eip=...): кадр пропущен» — EIP указывает точного виновника. */
#define KMAIN_RECOVER_MIN_MS 50u
static jmp_buf g_kmain_recover_jmp;
static volatile int  g_kmain_recover_armed = 0;
static volatile u32  g_kmain_last_recover_tick = 0;
static volatile u32  g_kmain_recovers = 0;

/* SMP-rework (диагностика QEMU): пульс kmain — не-static, читает task.c
 * в дампе [klock] FATAL и в сообщении миграции (см. task_watchdog_irq). */
volatile unsigned g_kmain_loops = 0;   /* итераций главного цикла */
volatile unsigned g_kmain_phase = 0;   /* 1=события 2=wifi 3=halfsec 4=guard 5=кадр 6=hlt */

/* Готово ли к восстановлению (вызывается из exc_panic, BSP, IF=0). */
int kmain_recover_ready(void)
{
    if (!g_kmain_recover_armed) return 0;
    u32 now = timer_ticks();
    if ((u32)(now - g_kmain_last_recover_tick) < KMAIN_RECOVER_MIN_MS)
        return 0;                       /* слишком часто — честная паника */
    g_kmain_last_recover_tick = now;
    g_kmain_recovers++;
    return 1;
}

/* Возврат в главный цикл (longjmp не возвращается). */
void kmain_recover_do(void)
{
    longjmp(g_kmain_recover_jmp, 1);
}

void kmain(u32 magic, const mb_info_t *mb)
{
    /* Первым делом — serial, чтобы поймать даже падение до gdt. */
    serial_init();
    serial_puts("\n\n=== N2600-OS boot ===\n");

    /* Журнал загрузки: первые вехи — до всего остального (dmesg покажет
     * даже то, что на экран пролетело за миллисекунды). */
    klog_puts("N2600-OS boot");
    {
        char kb[64];
        snprintf(kb, sizeof(kb), "multiboot magic=0x%08x", (unsigned)magic);
        klog_puts(kb);
    }

    /* Инициализируем ранний LFB-вывод из multiboot info.
     * Это позволяет писать текст ПРЯМО в фреймбуфер ДО fb_init,
     * что критично на реальном железе где GRUB уже выставил VESA-режим. */
    early_fb_init(mb);
    early_clear();
    early_puts("N2600-OS boot...\n");

    g_mbi = mb;

    early_puts("magic=");
    early_puthex(magic);
    early_puts("\n");

    if (magic != MB_BOOTLOADER_MAGIC) {
        early_puts("ERROR: bad multiboot magic\n");
        early_puts("expected=0x2BADB002\n");
        vga_fail("bad multiboot magic");
        return;
    }
    early_puts("magic OK\n");

    /* Выводим информацию о framebuffer из multiboot info */
    if (mb->flags & MBIF_FRAMEBUFFER) {
        early_puts("FB: ");
        early_putu(mb->framebuffer_width);
        early_putc('x');
        early_putu(mb->framebuffer_height);
        early_putc('x');
        early_putu(mb->framebuffer_bpp);
        early_puts(" @");
        early_puthex((u32)(u32)mb->framebuffer_addr);
        early_puts("\n");
    } else {
        early_puts("FB: NO framebuffer info!\n");
    }

    early_puts("gdt...");
    serial_puts("[boot] gdt_init...\n");
    gdt_init();
    early_puts("OK\n");

    early_puts("idt...");
    serial_puts("[boot] idt_init...\n");
    idt_init();
    early_puts("OK\n");

    early_puts("mem...");
    serial_puts("[boot] mem_init...\n");
    mem_init(mb);
    early_puts("OK\n");
    {
        char kb[64];
        snprintf(kb, sizeof(kb), "mem: RAM %u МиБ, куча %u МиБ",
                 (unsigned)mem_ram_mib(), (unsigned)(mem_heap_size() >> 20));
        klog_puts(kb);
    }

    /* Фреймбуфер поднимаем как можно раньше — нужен для экранной отладки. */
    early_puts("fb...");
    serial_puts("[boot] fb_init...\n");
    if (!fb_init(mb)) {
        early_puts("FAIL\n");
        vga_fail("no VESA framebuffer (need 16+ bpp mode)");
        return;
    }
    early_puts("OK\n");

    /* [GMA3600] (запрос пользователя: «инициализация 1024x600, устройство
     * на gma3600»): VBIOS GMA3600 по VBE отдаёт только 800x600x32 — нативный
     * 1024x600 ставим сами (sideband DPIO + pipe/plane, эталон gma500).
     * При любой неудаче — восстановление регистров и режим загрузчика.
     * LFB не меняется (VBIOS уже развернывает в него), меняются
     * timings/stride/размер и геометрия слоя fb. */
    {
        u32 gw = 0, gh = 0, gp = 0;
        if (gma3600_init(mb, &gw, &gh, &gp) && gw) {
            static mb_info_t mb_gma;      /* живёт до конца kmain */
            mb_gma = *mb;
            mb_gma.framebuffer_width  = gw;
            mb_gma.framebuffer_height = gh;
            mb_gma.framebuffer_pitch  = gp;
            mb_gma.framebuffer_bpp    = 32;
            mb = &mb_gma;               /* mtrr_lfb_wc посчитает новый размер */
            fb_reinit(mb_gma.framebuffer_addr, gw, gh, gp, 32);
            early_puts("gma3600: 1024x600 OK\n");
        } else {
            early_puts("gma3600: нет/откат\n");
        }
        dbg(gma3600_status());
    }

    /* [Дисплей] (сессия 90): voodoo3-ускорение удалено, SGX-эксперименты
     * сняты — остался только gma3600_2d (снятие курсорных плоскостей +
     * GTT). Все вызовы БЕЗОПАСНЫ: нет чипа — лог и программный рендер.
     * До mtrr_lfb_wc: WC-регион должен накрыть compose-буфер. */
    serial_puts("[boot] gma3600_2d: probe...\n");
    gma3600_2d_init();
    boot_step();                              /* служба 1/14: дисплей GMA3600 */

    /* [hwinfo] (сессия 90, идея hwdet bztsrc): разбор ACPI-таблиц
     * (RSDP/RSDT/XSDT, FADT/MADT/HPET/MCFG) + скан DSDT на устройства
     * (_HID/_ADR/_CRS: IO/IRQ/MMIO/DMA) + SMBIOS (DMI: вендор/плата/BIOS).
     * ТОЛЬКО ЧТЕНИЕ — без аппаратных записей. Данные для «Системной
     * информации» и лога. */
    serial_puts("[boot] hwinfo: ACPI/DSDT/SMBIOS...\n");
    hwinfo_init();

    /* ПЕРФ: Write-Combining для LFB через свободный переменный MTRR.
     * Обязательно ДО инициализации драйверов (BAR-скан/сизинг безопасен,
     * пока устройства неактивны). При любой сомнительной конфигурации
     * WC просто не включается (см. klog/dmesg: строка "mtrr:"). */
    mtrr_lfb_wc(mb);

    klog_screen_colors(fb_rgb(0xFF, 0xFF, 0x00), fb_rgb(0xFF, 0x60, 0x60));

    {
        char buf[80];
        snprintf(buf, sizeof(buf), "fb: %ux%u, %u bpp, pitch %u",
                 (unsigned)fb_width(), (unsigned)fb_height(),
                 (unsigned)fb_bpp(), (unsigned)fb_pitch());
        dbg(buf);
    }

    dbg("fb_make_bg...");    fb_make_bg();

    /* =======================================================================
     * ЗАЩИТА: Аппаратное маскирование IRQ 14 и 15 (ATA Primary/Secondary)
     * 0xA1 - порт данных Slave PIC. Биты 6 и 7 отвечают за IRQ 14 и 15.
     * Устанавливаем их в 1, чтобы прерывания от диска физически не дошли до CPU.
     * ======================================================================= */
    outb(0xA1, inb(0xA1) | 0xC0);
    dbg("IRQ14/15 masked");

        /* ---------- ATA (CD для загрузки) ----------
     * AHCI/SATA с сессии 11 НЕ блокирует загрузку: инициализация SATA-
     * контроллера, НЖМД и файловых систем (FAT32/NTFS) выполняется
     * ФОНОВОЙ задачей после старта ОС (см. sata_task_fn). ata_init
     * остаётся синхронным: он быстрый (пустые каналы отвечают сразу)
     * и нужен для ATAPI-CD (ISO9660 + сидинг ramfs при загрузке с CD). */
    dbg("ata_init...");
    {
        int r = ata_init();
        if (r) {
            char buf[80];
            if (ata_is_cdrom()) {
                snprintf(buf, sizeof(buf),
                         "ata: CD-ROM on port 0x%x, sel 0x%x (%s)",
                         (unsigned)ata_base_port(), (unsigned)ata_drive_sel(),
                         ata_model());
            } else {
                snprintf(buf, sizeof(buf),
                         "ata: HDD on port 0x%x, sel 0x%x, %s, sectors=%u",
                         (unsigned)ata_base_port(), (unsigned)ata_drive_sel(),
                         ata_model(), (unsigned)ata_sectors());
            }
            dbg(buf);
        } else {
            dbg_err("ata: NOT present (return 0)");
        }
        /* Диагностика дисков для dmesg/disks: отдельно НЖМД, если найден */
        if (ata_hdd_present()) {
            char buf[96];
            snprintf(buf, sizeof(buf),
                     "ata: HDD %s, %u секторов (%u МиБ)",
                     ata_hdd_model(), (unsigned)ata_hdd_sectors(),
                     (unsigned)(ata_hdd_sectors() / 2048u));
            dbg(buf);
        } else {
            dbg("ata: HDD не найден (только CD или пустые каналы)");
        }
        /* Сессия 13: командная строка ядра (GRUB: multiboot /boot/kernel.bin arg).
         * ataprobe — дамп регистров IDE (Bochs/железо: «почему CD не найден»);
         * bochs — вывод в serial дополнительной диагностики загрузки. */
        if ((mb->flags & MBIF_CMDLINE) && mb->cmdline) {
            const char *cl = (const char *)(u32)mb->cmdline;
            extern void ata_probe_diag(void);
            {
                char cb[96];
                extern int snprintf(char*, u32, const char*, ...);
                snprintf(cb, sizeof(cb), "[kmain] cmdline='%s'", cl);
                serial_puts(cb);
                serial_puts("\n");
            }
            if (strstr(cl, "ataprobe")) {
                dbg("cmdline: ataprobe");
                ata_probe_diag();
            }
            if (strstr(cl, "sandbox=off")) {
                extern void loader_set_sandbox(int on);
                loader_set_sandbox(0);
                dbg("cmdline: sandbox=off (бинарники без региона памяти)");
            }
        }
    }
    boot_step();                                  /* служба 2/14: ATA/CD */

    dbg("sata: инициализация AHCI/SATA отложена — фоновая задача после старта");

    /* ---------- ISO9660 ---------- */
    dbg("iso9660_init...");
    if (iso9660_init())
        dbg("iso9660: ready");
    else
        dbg_err("iso9660: not found (return 0)");
    boot_step();                                  /* служба 3/14: ISO9660 */

    /* ---------- RAMFS ---------- */
    dbg("ramfs_init...");
    if (ramfs_init()) {
        char buf[80];
        snprintf(buf, sizeof(buf), "ramfs: ready, %u МиБ",
                 (unsigned)(ramfs_total_space() / (1024 * 1024)));
        dbg(buf);
    } else {
        dbg_err("ramfs: init failed");
    }

    /* Сидинг RAM disk из /boot/ramdisk в ISO (если есть и влезает) */
    dbg("ramfs_seed_from_iso...");
    ramfs_seed_from_iso();
    /* Сессия 55: встроенные ресурсы (LOGO.PNG/IMG.JS) — только если
     * файлов ещё нет: у пересобранного ISO приоритет у /boot/ramdisk */
    imgres_seed();
    boot_step();                                  /* служба 4/14: ramfs+ресурсы */
    /* FIX [R2] (перенесено в sata_task, сессия 11): сидинг из \RAMDISK
     * на FAT32 требует НЖМД, который теперь инициализируется ФОНОВО —
     * вызов переехал в sata_task_fn после монтирования файловых систем. */
    /* ---------- периферия ---------- */
    /* СЕССИЯ 33: PIT 1000 Гц (1 тик = 1 мс) — точные короткие паузы
     * (task_msleep(1) больше не растягивается до 10 мс), плавнее UI,
     * честные тайминги USB/WiFi. Накладные расходы IRQ0 ~1% vCPU. */
    dbg("timer_init...");    timer_init(1000);
    timer_hz_selfcheck();    /* [TICK-CAL] (Task 48): фактический тик-рейт
                              * vs RTC — одна строка в dmesg, ответ на
                              * вопрос «не в таймингах ли дело» */
    dbg("kbd_init...");      kbd_init();
    dbg("mouse_init...");    mouse_init();
    if (mouse_present())
        dbg("mouse: present");
    else
        dbg_err("mouse: not present");
    boot_step();                                  /* служба 5/14: таймер+ввод */

    /* ---------- SMP (сессия 74) ----------
     * Детект топологии (CPUID: ядра/потоки SMT) + ACPI MADT (реальные
     * APIC ID) + включение LAPIC + запуск AP-ядер через INIT-SIPI.
     * Каждое AP-ядро получает общий GDT/IDT, LAPIC-таймер 1000 Гц
     * (учёт загрузки) и уходит в hlt-простой. LAPIC на BSP после
     * отправки SIPI ВЫКЛЮЧАЕТСЯ — путь прерываний BSP (PIC -> INTR)
     * остаётся ровно тем же. Все проверки с таймаутами: ядро, не
     * стартовавшее за ~0.5 с, помечается офлайн, загрузка продолжается.
     * Требует: idt_init (векторы 0x60/0xEF), mem_init, PIT (pit2 для
     * калибровки/таймаутов); до sti() — однопоточно. */
    dbg("smp_init...");
    smp_init(mb);
    boot_step();                                  /* служба 6/14: SMP */

    /* ---------- USB ---------- */
    /* Инициализируем UHCI-контроллеры и ищем HID-устройства.
     * Реальный опрос HID-отчётов требует полного QH-стека и прерываний —
     * здесь выполняется только детекция (события продолжают приходить
     * через PS/2-эмуляцию BIOS Legacy USB). */
    dbg("usb_init...");     usb_init();
    if (usb_controllers_found())
        dbg("usb: UHCI controller initialized");
    else
        dbg_err("usb: no UHCI controller (используется BIOS Legacy USB)");
    if (usb_devices_found() > 0) {
        char buf[80];
        snprintf(buf, sizeof(buf), "usb: %d device(s) detected", usb_devices_found());
        dbg(buf);
    }
    boot_step();                                  /* служба 7/14: USB */

    /* ---------- WiFi (СЕССИЯ 15: ФОНОВАЯ задача) ----------
     * Больше НЕ блокируем загрузку: инициализация Atheros (PCI-скан +
     * cold reset + INI + калибровки AGC/NF — СЕКУНДЫ на нетбуке)
     * идёт в wifi_task_fn ПОСЛЕ старта ОС (как SATA с сессии 11).
     * Если при загрузке ethernet-адаптеров нет, сеть поднимет сама
     * wifi-задача, когда адаптер будет готов (см. wifi_task_fn). */
    dbg("wifi: отложено в фоновую задачу (после старта ОС)");

    /* ---------- Ethernet: инициализируем ВСЕ драйверы ----------
     * Сессия 11: реестр адаптеров (net.c) сам выбирает активный по
     * линку — поэтому каждый драйвер должен отработать свой PCI-скан.
     * Раньше цепочка «e1000 ИЛИ virtio ИЛИ ne2000 ИЛИ atl1c» не давала
     * второму NIC зарегистрироваться (и WiFi не участвовал вообще). */
    dbg("e1000_init...");     e1000_init();
    dbg("virtio_net_init..."); virtio_net_init();
    dbg("ne2000_init...");    ne2000_init();

    /* Atheros L1c/L2c (AR813x/815x) — проводная сетевая карта ASUS X101CH
     * (AR8152 v2, PCI 1969:2062). В QEMU её нет — PCI-скан вернётся
     * мгновенно; на X101CH это единственный проводной NIC. */
    dbg("atl1c_init...");     atl1c_init();
    boot_step();                                  /* служба 8/14: драйверы NIC */

    /* wifi в этом условии НЕ участвует: его инициализация теперь
     * фоновая (сессия 15) — на момент загрузки он не готов. Если
     * ethernet нет, сеть поднимет wifi_task_fn позже. */
    if (e1000_present() || virtio_net_present() || ne2000_present() ||
        atl1c_present()) {
        /* Настройки приоритета адаптера из SETTINGS.CFG (RAM disk),
         * затем инициализация реестра NIC и выбор активного по линку */
        net_settings_load();
        dbg("net_init...");
        net_init();
        /* callback: смена адаптера → сброс адресов + повтор DHCP */
        net_adapter_set_change_cb(netmon_adapter_changed);
        /* IP, шлюз, маска (QEMU user-net) — умолчания до DHCP */
        net_set_ip(0x0A00020F);        /* 10.0.2.15 */
        net_set_gateway(0x0A000202);  /* 10.0.2.2  */
        net_set_netmask(0xFFFFFF00);  /* 255.255.255.0 */
        dbg("net: 10.0.2.15/24 gw 10.0.2.2 (умолчания до DHCP)");
    } else {
        dbg("net: ethernet NIC нет — сеть поднимет wifi-задача (фон)");
    }
    boot_step();                                  /* служба 9/14: сеть (net_init) */

    /* Встроенный HTTP-сервер: localhost для теста. Работает даже
     * БЕЗ NIC (loopback 127.0.0.1 замыкается внутри стека):
     * curl http://127.0.0.1/ , http://localhost/ из браузера,
     * а снаружи — через QEMU hostfwd=tcp::8080-:80. */
    dbg("httpd: listen :80...");
    net_httpd_start();
    boot_step();                                  /* служба 10/14: HTTP-сервер */

    /* ---------- звук (сессия 57) ---------- */
    /* ES1371 (VMware «Sound Blaster AudioPCI» / es1371-режим) или
     * Intel HDA (VMware hdaudio + настоящая ALC269VB). Проба PCI —
     * до многозадачности, безопасно по I/O. */
    dbg("sound: probe...");
    sound_init();
    boot_step();                                  /* служба 11/14: звук */

    /* ---------- многозадачность ---------- */
    /* task_init() создаёт TCB[0] для главной задачи и регистрирует IRQ0
     * на наш планировщик. Должно идти ДО sti(), чтобы первый IRQ0 уже
     * нашёл готовую таблицу задач. */
    dbg("task_init...");     task_init();

    /* ramfs КАК ОТДЕЛЬНЫЙ ПРОЦЕСС: задача-сервер «ramfs» (системная,
     * kill запрещён). После первого IRQ0 она заберёт владение ramdisk —
     * в диспетчере задач появится строка ramfs с честной памятью. */
    if (ramfs_server_start()) {
        char b[64];
        snprintf(b, sizeof(b), "ramfs: сервер запущен (задача %d)",
                 ramfs_server_task());
        dbg(b);
    } else {
        dbg_err("ramfs: не удалось запустить задачу-сервер");
    }

    /* ---------- СЕССИЯ 15: запуск фоновых задач сети ---------- */
    /* netmon: постоянный монитор сети (DHCP/линк/авто-переключение) */
    if (net_adapter_count() > 0) {
        int tid = task_spawn_prio("netmon", netmon_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) {
            task_set_system(tid);
            g_netmon_started = 1;
        }
    }

    /* wifi: инициализация Atheros ФОНОМ (сессия 15 — нетбук больше
     * не ждёт адаптер при загрузке; задача живёт до готовности,
     * затем WiFi опрашивается из главного цикла).
     * СЕССИЯ 40: через wifi_task_spawn() — ставит g_wifi_spawn_pending,
     * чтобы главный цикл не заспавнил вторую задачу до старта первой. */
    {
        /* СЕССИЯ 34: PRIO_BG — шторм перечисления/скана не тормозит UI */
        int tid = task_spawn_prio("wifi", wifi_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) {
            task_set_system(tid);
            g_wifi_spawn_pending = 1;   /* задача выставит alive на входе */
        }
    }

    /* ---------- фоновая инициализация SATA (сессия 11) ----------
     * Рабочий стол поднимается НЕЖДАЯ диск: AHCI/НЖМД/FAT32/NTFS
     * инициализируются параллельно в фоновой задаче (на реальном
     * железе COMRESET+раскрутка+IDENTIFY занимают десятки секунд). */
    {
        int tid = task_spawn_prio("sata", sata_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) task_set_system(tid);
    }

    /* ---------- итерация 7: telnet-сервер ----------
     * ПО УМОЛЧАНИЮ ВКЛЮЧЁН (отключение: "telnet=0" в SETTINGS.CFG или
     * галочка в Настройках → Сеть). Слушает :23, shell — как в
     * локальном терминале (headless term). */
    telnetd_autostart();

    boot_step();                                  /* служба 12/14: задачи+ramfs-сервер */

    /* ---------- оконный менеджер ---------- */
    dbg("wm_init...");       wm_init();
    /* При загрузке открываем ТОЛЬКО терминал.
     * Остальные приложения доступны через меню «Меню». */
    dbg("apps_open(terminal)...");
    apps_open(2);   /* Терминал */

    /* ---------- прерывания ---------- */
    dbg("irq setup...");
    mouse_install_irq();
    pic_unmask((u16)((1 << 0) | (1 << 1) | (1 << 2) | (1 << 12)));
    /* Сессия 12 (FIX «остатки boot-лога сквозь обои»): экранный вывод
     * dbg() выключается ДО sti(). Раньше флаг ставился ПОСЛЕ sti() —
     * между ними успевали стартовать фоновые задачи (sata/netmon) и
     * рисовали свои строки ПОВЕРХ обоев: обои уже были, но строки
     * оставались на экране до первого полного кадра, а при отсутствии
     * событий — висели минутами. Теперь после sti() ни одна фоновая
     * задача не может испортить экран. */
    klog_screen_off();          /* Task 49: экран-лог теперь в klog.c */
    sti();
    serial_puts("[boot] irq on, entering main loop\n");
    klog_puts("irq on, entering main loop");
    klog_puts("Загрузка завершена — система готова");
    /* СЕССИЯ 77 [SMP-BOOT-GATE]: загрузка закончена — разрешаем
     * планирование задач на AP-ядрах. До этого момента AP жили в idle
     * (учёт нагрузки идёт), все задачи исполнял BSP: фоновые задачи
     * больше не стартуют посреди boot-лога и не вешают BSP в s_lock
     * (sti;hlt при замаскированном IRQ0). Размещение новых задач —
     * по наименее нагруженному ядру (task_pick_core), уже созданные
     * (ramfs/wifi/sata) подхватит AP на ближайшем тике. */
    smp_tasks_enable();
    /* ШАГ 4 (SMP-rework): включить приём IPI на BSP (LAPIC virtual
     * wire, вектор 0x62) — доставка mailbox-«syscall» AP->BSP;
     * поллинг ap_syscall_poll() в главном цикле — страховка. */
    apipc_bsp_ipi_enable();
    /* СЕССИЯ 80 [SMP1-MSG]: при SMP=1 (одно ядро) прежняя строка
     * «планирование задач на AP включено» вводила в заблуждение —
     * AP-ядер нет и размещать задачи некуда, всё исполняет BSP.
     * Честная строка сразу показывает конфигурацию в serial-логе. */
    serial_puts(smp_cpu_count() > 1
                ? "[smp] планирование задач на AP включено\n"
                : "[smp] AP-ядер нет (SMP=1) — все задачи исполняет BSP\n");
    /* полная перерисовка: обои + окна + таскбар поверх последнего
     * состояния загрузочного лога */
    fb_touch_all();

    /* СЕССИЯ 81 [KMAIN-RECOVER]: точка возврата после восстановленного
     * исключения. Первый вход — 0 (нормальное продолжение загрузки);
     * повторные — возвраты из exc_panic: замки/fb-контекст уже отпущены,
     * просто продолжаем цикл (прерванный кадр/полу-тик пропущены).
     * setjmp returns_twice: изменяемые локальные переменные цикла (ev,
     * last_half) либо перезаписываются до использования, либо volatile. */
    {
        if (setjmp(g_kmain_recover_jmp) != 0) {
            /* ВАЖНО (репродукция verify81): exc_panic входит под cli(),
             * а freestanding longjmp восстанавливает ТОЛЬКО callee-saved
             * регистры + esp/eip — EFLAGS (и бит IF) НЕ трогает. Без sti
             * kmain возвращался в цикл с выключенными прерываниями:
             * IRQ0/клава/мышь мертвы, task_hlt_idle под cli не спит и не
             * отпускает замок — экран застывал до конца теста. Включаем
             * прерывания НЕМЕДЛЕННО: цикл с этой точки ожидает IF=1
             * (критические секции внутри делают свои cli/sti). */
            __asm__ __volatile__("sti" ::: "memory");
            /* Буфер 144 (полевой лог VMware): при 80 snprintf резал
             * кириллицу UTF-8 (2 байта/символ) ровно на «— ц», хвостовая
             * \n терялась и строки восстановления склеивались с [ahci]. */
            char rb[144];
            snprintf(rb, sizeof(rb),
                     "[kmain] восстановление после исключения #%u — цикл продолжен\n",
                     (unsigned)g_kmain_recovers);
            serial_puts(rb);
            klog_puts(rb);
        }
        g_kmain_recover_armed = 1;
    }

    /* главный цикл: события -> композитинг -> hlt до следующего прерывания */
    key_event_t ev;

    /* SMP-rework (диагностика QEMU-сессии): пульс kmain. Читается дампом
     * [klock] FATAL (task.c) и сообщением миграции — чтобы отличить
     * «kmain жив и крутится» от «kmain заморожен / не получает CPU».
     * Грубые записи без замков: гонка чтения даёт максимум рассинхрон
     * на одну итерацию — для посмертной диагностики приемлемо. */
    g_kmain_loops = 0;
    g_kmain_phase = 0;
    volatile u32 last_half = 0;
    for (;;) {
        g_kmain_loops++;
        g_kmain_phase = 1;   /* события ввода + опрос драйверов */
        ap_syscall_poll();   /* ШАГ 4: обслужить mailbox AP (IPI/поллинг) */

        while (kbd_pop(&ev))
            wm_key(&ev);

        wm_mouse_poll();
        usb_poll();        /* опрос HID (если что-то найдено) */
        wifi_poll();        /* опрос WiFi (сканирование) */
        net_poll();         /* опрос сети: приём и обработка Ethernet/ARP/IP/ICMP */
        net_httpd_poll();   /* сессия 60: FSM отправки файлов + idle-таймаут httpd */

        /* СЕССИЯ 40: авто-восстановление WiFi-адаптера. Адаптер перестал
         * отвечать по USB (ватчдог rtl8192eu) или донгл переподключили
         * после готовности — а wifi-задачи больше нет (она вышла после
         * wifi_net_up). Поднимаем новую: она сбросит порт, переперечислит
         * и выполнит полный bring-up.
         * СЕССИЯ 79 [WIFI-RESPAWN]: БЕЗ wifi_present() — раньше задача
         * возрождалась только при уже привязанном драйвере: если задача
         * погибала ДО первого адаптера (отбор klock у «спящей» — как в
         * логе пользователя), донгл потом подключали — attach делал
         * usbhot, но bring-up/скан никто не выполнял: wifi «умер»
         * навсегда. Задача дешёвая (BG, спит 500 мс) — держим её живой
         * всегда, пока ready==0. */
        g_kmain_phase = 2;   /* фоновый respawn wifi/usb */
        if (!wifi_ready() && !g_wifi_spawn_pending && g_wifi_task_alive == 0) {
            wifi_task_spawn();
        }

        g_kmain_phase = 3;   /* halfsec: ватчдог + wm_halfsec */
        u32 t = timer_ticks();
        if (t / 500 != last_half) {  /* 2 раза в секунду (1 тик = 1 мс) */
            last_half = t / 500;
            wm_halfsec();
            /* Ватчдог: kill задач, зависших > 5 секунд (5000 тиков по 1 мс).
             * Главная задача (task[0]) не проверяется. */
            int killed = task_watchdog(5000);
            if (killed > 0) {
                char buf[64];
                snprintf(buf, sizeof(buf), "[watchdog] killed %d hung task(s)", killed);
                serial_puts(buf);
            }
            /* СЕССИЯ 35: hot-plug EHCI не зависит от wifi-задачи: главный
             * цикл видит CSC/необслуженный порт и спавнит BG-скан.
             * СЕССИЯ 37: скан — не I/O-ожидание, а честные контрольные
             * трансферы и сбросы порта (сотни мс CPU): на BG-крошках
             * (1 тик из 250 при всегда-готовом kmain) перечисление
             * растягивалось с секунд до минут. Задача короткоживущая
             * и большую часть пауз спит (waiting) — UI-приоритет ей
             * ничего не стоит, а завершает скан в реальном времени. */
            if (usb_ehci_present() && !g_usb_scan_running &&
                (usb_ehci_csc_pending() || usb_ehci_work_pending())) {
                if (task_spawn_prio("usbhot", usb_hotplug_task_fn,
                                    NULL, TASK_PRIO_UI) > 0)
                    g_usb_scan_running = 1;
            }
        }

        {
            g_kmain_phase = 4;   /* сторож кучи (1 р/с) */
            /* Сессия 13 (диагностика порчи кучи): сторож в главном цикле.
             * СРАЗУ при обнаружении — serial + последний блок.
             * ПЕРФ (запрос пользователя): полный обход кучи на КАЖДЫЙ
             * проход главного цикла съедал CPU на Atom и рвал плавность
             * интерфейса — теперь раз в секунду (достаточно для
             * диагностики: порча ловится и на аллокациях).
             * БЕЗОПАСНОСТЬ (запрос пользователя): порча кучи НЕ должна
             * ронять ОС — раньше kmain замерзал навсегда (for(;;) hlt),
             * что убивало всю систему. Теперь: доклад ОДИН раз и
             * продолжение работы; аллокатор (mem.c) сам отказывается
             * работать с битыми блоками, так что система «хромает,
             * но живёт». */
            static u32 last_guard = 0;
            static int heap_corrupt_announced = 0;
            if (t - last_guard >= 1000) {   /* 1 тик = 1 мс */
                last_guard = t;
                /* Сессия 59: канарейки стеков РАНЬШЕ проверки кучи —
                 * переполнение стека задачи бьёт канарейку ДО того,
                 * как побьёт заголовок соседнего блока кучи. */
                extern void task_check_stack_canaries(void);
                task_check_stack_canaries();
                extern void mquickjs_sessions_reap(void);
                mquickjs_sessions_reap();   /* память убитых JS-задач */
                extern int mem_check_corrupt(void);
                extern void mem_dump_blocks(void);
                if (mem_check_corrupt()) {
                    extern void serial_puts(const char *s);
                    if (!heap_corrupt_announced) {
                        heap_corrupt_announced = 1;
                        serial_puts("[guard] ПОРЧА КУЧИ ОБНАРУЖЕНА (главный цикл) — "
                                    "ОС продолжает работу, битые блоки игнорируются\n");
                        mem_dump_blocks();
                    }
                }
            }
        }
        g_kmain_phase = 5;   /* композитинг кадра */
        wm_frame();
        g_kmain_phase = 6;   /* сон до прерывания */
        task_hlt_idle();     /* СЕССИЯ 75: сон с отпуском ядрового замка */
    }
}