/* tmfmt_test.c — хост-тест диспетчера задач N2600-OS.
 *
 * Компилирует НАСТОЯЩИЙ src/apps_taskmgr.c (#include) против заглушек.
 * Проверяет:
 *   1. Таблица: колонки Uptime/Mem/Статус у РУССКИХ и ASCII имён
 *      выровнены одинаково (регрессия «%-13s по байтам ломал таблицу»);
 *   2. Шапка таблицы стоит точно над колонками данных;
 *   3. tm_fmt_name: обрезка/дополнение по СИМВОЛАМ (кириллица не рвётся,
 *      ширина ровно TM_NAME_COLS символов);
 *   4. Мышь: ЛКМ выделяет, повторный ЛКМ/ПКМ-меню снимает задачу,
 *      системные задачи защищены;
 *   5. Сеть: сэмплы = дельта счётчиков байт; tm_fmt_rate («Б/с», «КБ/с»,
 *      «МБ/с»); подпись скорости у правого края графика;
 *   6. Регрессия off-by-one: mem_history пишется на тот же слот, что cpu.
 *
 * Сборка: run_tmfmt.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* типы/прототипы заглушек (window_t, wm_menu_fn, ...) */
#include "tm_stubs.h"

/* =================== ЗАХВАТ ВЫЗОВОВ fb_/wm_/task_ =================== */
#define CAP_MAX 512
typedef struct { int x, y; char text[128]; u32 color; } cap_text_t;
static cap_text_t cap_text[CAP_MAX];
static int cap_n;
static int cap_kill_slot;          /* task_kill */
static int cap_wmk_slot;           /* wm_request_kill */
static int cap_inv;                /* win_invalidate */
static struct {                    /* wm_menu_open */
    int active; int n; int ids[4]; int disabled[4];
    char labels[4][40]; void *uctx; wm_menu_fn cb; int x, y;
} cap_menu;

/* ---- реализация заглушек ---- */
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r << 16) | ((u32)g << 8) | b; }
static void cap_add(int x, int y, const char *s, u32 c)
{
    if (cap_n < CAP_MAX) {
        cap_text[cap_n].x = x; cap_text[cap_n].y = y;
        cap_text[cap_n].color = c;
        snprintf(cap_text[cap_n].text, sizeof(cap_text[cap_n].text), "%s", s);
        cap_n++;
    }
}
void fb_fill_rect(int x, int y, int w, int h, u32 color) { (void)x;(void)y;(void)w;(void)h;(void)color; }
void fb_rect(int x, int y, int w, int h, u32 color) { (void)x;(void)y;(void)w;(void)h;(void)color; }
void fb_hline(int x0, int x1, int y, u32 c) { (void)x0;(void)x1;(void)y;(void)c; }
void fb_vline(int x, int y0, int y1, u32 c) { (void)x;(void)y0;(void)y1;(void)c; }
void fb_text(int x, int y, const char *s, u32 color, int bg)
{ (void)bg; cap_add(x, y, s, color); }
u32  fb_text_w(const char *s)            /* как в fb.c: символы * 8 */
{ extern int utf8_count_chars_pub(const char *); return (u32)utf8_count_chars_pub(s) * 8; }
int  fb_width(void)  { return 1280; }
int  fb_height(void) { return 720; }

/* wm_* */
static u32 theme = 0x202020;
u32 wm_theme_win_bg(void)      { return theme; }
u32 wm_theme_win_bg_alt(void)  { return theme + 1; }
u32 wm_theme_text(void)        { return theme + 2; }
u32 wm_theme_text_info(void)   { return theme + 3; }
u32 wm_theme_title(void)       { return theme + 4; }
u32 wm_theme_accent(void)      { return theme + 5; }
u32 wm_theme_sel_bg(void)      { return theme + 6; }
window_t *win_create(const char *t, int x, int y, int w, int h,
                     win_draw_fn d, win_key_fn k, win_mouse_fn mo,
                     win_tick_fn ti, win_close_fn cl, void *data)
{ (void)t;(void)x;(void)y;(void)w;(void)h;(void)d;(void)k;(void)mo;(void)ti;(void)cl;(void)data; return NULL; }
void win_invalidate(window_t *w) { (void)w; cap_inv++; }
void win_close(window_t *w) { (void)w; }
int  win_content_w(window_t *w) { return w->cw; }
int  win_content_h(window_t *w) { return w->ch; }
void wm_request_kill(int task_idx) { cap_wmk_slot = task_idx; }
void wm_menu_open(window_t *owner, int cx, int cy, const wm_menu_item_t *items,
                  int n, wm_menu_fn cb, void *uctx)
{
    (void)owner;
    cap_menu.active = 1; cap_menu.n = n; cap_menu.cb = cb;
    cap_menu.uctx = uctx; cap_menu.x = cx; cap_menu.y = cy;
    for (int i = 0; i < n && i < 4; i++) {
        cap_menu.ids[i] = items[i].id;
        cap_menu.disabled[i] = items[i].disabled;
        snprintf(cap_menu.labels[i], sizeof(cap_menu.labels[i]), "%s",
                 items[i].label ? items[i].label : "(null)");
    }
}
int  wm_menu_active(void) { return cap_menu.active; }
int  wm_text_fit(int x, int y, const char *s, int max_w, u32 color, int center)
{
    /* упрощённо, но по СИМВОЛАМ: рисуем целиком, если влезает */
    int w = (int)fb_text_w(s);
    (void)center;
    if (w <= max_w) { cap_add(x, y, s, color); return w; }
    /* обрезать по символам до max_w - 16 (2 символа "..") */
    char buf[128]; int bytes = 0, chars = 0;
    int maxc = (max_w - 16) / 8; if (maxc < 1) maxc = 1;
    const char *p = s;
    while (*p && chars < maxc) {
        int adv = ((*p & 0xE0) == 0xC0) ? 2 : (((*p & 0xF0) == 0xE0) ? 3 : 1);
        for (int i = 0; i < adv && p[i]; i++) buf[bytes++] = p[i];
        p += adv; chars++;
    }
    buf[bytes++] = '.'; buf[bytes++] = '.'; buf[bytes] = 0;
    cap_add(x, y, buf, color);
    return bytes * 8;
}

/* ---- фальшивая таблица задач ---- */
typedef struct { int used, fin, sys; const char *name; u32 up; u32 mem; } ftask_t;
static ftask_t ft[MAX_TASKS];
static int ft_cur = 0;
static int ft_kill_rc = 1;   /* что возвращает task_kill */
int  task_used(int i)     { return ft[i].used; }
int  task_finished(int i) { return ft[i].fin; }
int  task_is_system(int i){ return ft[i].sys; }
const char *task_name(int i) { return ft[i].name; }
u32  task_uptime(int i)  { return ft[i].up; }
int  task_current(void)  { return ft_cur; }
int  task_count(void)
{ int n = 0; for (int i = 0; i < MAX_TASKS; i++) if (ft[i].used && !ft[i].fin) n++; return n; }
int  task_kill(int idx)  { cap_kill_slot = idx; ft[idx].fin = 1; return ft_kill_rc; }
int  task_spawn(const char *n, void (*f)(void *), void *a) { (void)n;(void)f;(void)a; return -1; }

/* Task 50+: колонка «Ядро» (task_core_live). Хост: ftask_t не хранит
 * ядро — отдаём 0 (BSP); проверка отрисовки колонки этого не касается. */
int  task_core_live(int idx) { (void)idx; return 0; }
int  task_cpu(int idx)       { (void)idx; return 0; }
int  task_on_cpu(int idx)    { (void)idx; return 0; }
int  smp_topo_cores(void)    { return 2; }
int  smp_topo_threads(void)  { return 1; }
int  smp_cpu_count(void)     { return 2; }
int  smp_cpu_load(int idx)   { (void)idx; return 5; }

u32  mem_used(void)      { return 4200000; }
u32  mem_heap_size(void) { return 10000000; }
u32  mem_task_used(int slot) { return ft[slot].mem; }
u32  uptime_sec(void)    { return 1234; }

/* ---- фальшивые сетевые счётчики ---- */
static u32 f_tx_bytes, f_rx_bytes;
u32 net_tx_bytes(void) { return f_tx_bytes; }
u32 net_rx_bytes(void) { return f_rx_bytes; }

/* =================== ТЕСТИРУЕМЫЙ КОД ОС =================== */
#include "apps_taskmgr.c"

/* публикация utf8-счётчика для fb_text_w */
int utf8_count_chars_pub(const char *s) { return utf8_count_chars(s, -1); }

/* =================== ХЕЛПЕРЫ ПРОВЕРОК =================== */
static int fails;
#define CHECK(cond, ...) do { \
    if (!(cond)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); \
                   printf(__VA_ARGS__); printf("\n"); } \
} while (0)

static int seq_len(unsigned char c)
{ if (c < 0x80) return 1; if ((c & 0xE0) == 0xC0) return 2; return 3; }

/* символ строки s по индексу (в СИМВОЛАХ) или -1. Безопасно к
 * обрезанной UTF-8-последовательности на конце (не заходит за NUL). */
static int char_at(const char *s, int col)
{
    int i = 0;
    while (*s && i < col) {
        s++; i++;
        while ((*s & 0xC0) == 0x80) s++;   /* продолжающие байты того же символа */
    }
    return *s ? (unsigned char)*s : -1;
}
/* байтовый офсет символа col (или -1) — так же безопасно к обрезке */
static int byte_off(const char *s, int col)
{
    int i = 0, off = 0;
    while (s[off] && i < col) {
        off++; i++;
        while ((s[off] & 0xC0) == 0x80) off++;
    }
    return s[off] ? off : -1;
}
static int is_digit(int c) { return c >= '0' && c <= '9'; }
static int is_digsp(int c) { return c == ' ' || (c >= '0' && c <= '9'); }
static void cap_reset(void) { cap_n = 0; cap_kill_slot = -1; cap_wmk_slot = -1; cap_inv = 0;
                              memset(&cap_menu, 0, sizeof(cap_menu)); }

/* найти текст, нарисованный на строке y (список задач) */
static const char *find_row(int y)
{
    for (int i = 0; i < cap_n; i++)
        if (cap_text[i].y == y && cap_text[i].x == 4)
            return cap_text[i].text;
    return NULL;
}

/* =================== ТЕСТЫ =================== */

static window_t make_win(void)
{
    window_t w; w.cw = 620; w.ch = 360; w.data = NULL; return w;
}

static void setup_tasks(void)
{
    memset(ft, 0, sizeof(ft));
    ft[0].used = 1; ft[0].name = "Диспетчер зад"; ft[0].up = 50000; ft[0].mem = 409600;
    ft[1].used = 1; ft[1].name = "Калькул";       ft[1].up = 300;   ft[1].mem = 102400;
    ft[2].used = 1; ft[2].name = "Шашки";         ft[2].up = 150;   ft[2].mem = 204800;
    ft[3].used = 1; ft[3].name = "browser";       ft[3].up = 99999; ft[3].mem = 819200;
    ft[4].used = 1; ft[4].name = "ramfs";         ft[4].up = 1;     ft[4].mem = 65536;
    ft[4].sys = 1;
    ft[5].used = 1; ft[5].name = "ОченьДлинноеИмяЗадачи"; ft[5].up = 42; ft[5].mem = 1000;
}

/* ТЕСТ 1+2: выравнивание колонок данных и шапки */
static void test_table_alignment(void)
{
    taskmgr_t m; memset(&m, 0, sizeof(m));
    window_t w = make_win(); w.data = &m;
    setup_tasks();
    cap_reset();
    tm_draw(&w);

    /* найти строки списка: рисуются на y = TM_LIST_Y0+2 + i*16, x=4 */
    int rows_found = 0;
    for (int i = 0; i < 6; i++) {
        int y = TM_LIST_Y0 + 2 + i * TM_ROW_H;
        const char *row = find_row(y);
        if (!row) continue;
        rows_found++;
        /* формат: %3d SP name(13) SP %6u SP %5u K SP %s
         * колонки (в СИМВОЛАХ): 0-2 idx, 3 sp, 4-16 имя, 17 sp,
         * 18-23 uptime, 24 sp, 25-29 mem, 30 'K', 31 sp, 32+ статус.
         * Числа ВЫРАВНЕНЫ ВПРАВО — ведущие пробелы допустимы. */
        CHECK(char_at(row, 3) == ' ', "row %d: col 3 not space", i);
        CHECK(char_at(row, 17) == ' ', "row %d: имя не выровнено по 13 симв. (col 17 != ' '): «%s»",
              i, row);
        int all_sp = 1;
        for (int c = 18; c <= 23; c++) {
            CHECK(is_digsp(char_at(row, c)), "row %d: uptime col %d мусор: «%s»", i, c, row);
            if (is_digit(char_at(row, c))) all_sp = 0;
        }
        CHECK(!all_sp, "row %d: поле uptime пустое: «%s»", i, row);
        CHECK(char_at(row, 24) == ' ', "row %d: col 24 not space", i);
        all_sp = 1;
        for (int c = 25; c <= 29; c++) {
            CHECK(is_digsp(char_at(row, c)), "row %d: mem col %d мусор: «%s»", i, c, row);
            if (is_digit(char_at(row, c))) all_sp = 0;
        }
        CHECK(!all_sp, "row %d: поле mem пустое: «%s»", i, row);
        CHECK(char_at(row, 30) == 'K', "row %d: col 30 != 'K': «%s»", i, row);
        CHECK(char_at(row, 31) == ' ', "row %d: col 31 not space", i);
        CHECK(char_at(row, 32) != -1, "row %d: статус пуст", i);
        /* имя не вылезает: символов до col 17 ровно 17 */
        int off17 = byte_off(row, 17);
        CHECK(off17 >= 0, "row %d: короче 17 символов: «%s»", i, row);
    }
    CHECK(rows_found == 6, "найдено %d строк из 6", rows_found);

    /* шапка: над колонками */
    const char *hdr = NULL;
    for (int i = 0; i < cap_n; i++)
        if (cap_text[i].y == TM_HDR_H + 1) { hdr = cap_text[i].text; break; }
    CHECK(hdr != NULL, "шапка не найдена");
    if (hdr) {
        int off;
        off = byte_off(hdr, 0);
        CHECK(off == 0 && char_at(hdr, 0) == 'I', "шапка начинается не с Idx");
        CHECK(byte_off(hdr, 4) >= 0, "шапка: нет col 4");
        /* "Uptime" на 18..23 */
        off = byte_off(hdr, 18);
        CHECK(off >= 0 && strncmp(hdr + off, "Uptime", 6) == 0,
              "шапка: Uptime не на колонке 18: «%s»", hdr);
        /* "Mem" на 25..27 */
        off = byte_off(hdr, 25);
        CHECK(off >= 0 && strncmp(hdr + off, "Mem", 3) == 0,
              "шапка: Mem не на колонке 25: «%s»", hdr);
        /* Task 50 [CORE-COL]: добавлена колонка «Ядро» — "Статус"
         * сместилась с 32 на 37-ю СИМВОЛЬНУЮ колонку (44-й байт, UTF-8) */
        off = byte_off(hdr, 37);
        CHECK(off >= 0 && strncmp(hdr + off, "Статус", 6) == 0,
              "шапка: Статус не на симв. колонке 37: «%s»", hdr);
    }
}

/* ТЕСТ 3: tm_fmt_name по символам */
static void test_fmt_name(void)
{
    char buf[64];

    /* русское короткое: 5 симв + 8 пробелов = 13 симв, 18 байт */
    tm_fmt_name(buf, sizeof(buf), "Шашки");
    CHECK(utf8_count_chars(buf, -1) == 13, "Шашки: %d симв", utf8_count_chars(buf, -1));
    CHECK(strlen(buf) == 18, "Шашки: байт %zu (ожидалось 18)", strlen(buf));

    /* русское 7 симв («Калькул» — ровно так режет wm заголовки): 14 байт + 6 sp */
    tm_fmt_name(buf, sizeof(buf), "Калькул");
    CHECK(utf8_count_chars(buf, -1) == 13, "Калькул: %d симв", utf8_count_chars(buf, -1));
    CHECK(strlen(buf) == 20, "Калькул: байт %zu (ожидалось 20)", strlen(buf));

    /* ASCII: 7 симв + 6 пробелов = 13 байт */
    tm_fmt_name(buf, sizeof(buf), "browser");
    CHECK(utf8_count_chars(buf, -1) == 13 && strlen(buf) == 13, "browser: «%s»", buf);

    /* длинное русское: обрезка до 13 символов БЕЗ разрыва символа */
    tm_fmt_name(buf, sizeof(buf), "ОченьДлинноеИмяЗадачи");
    CHECK(utf8_count_chars(buf, -1) == 13, "длинное: %d симв", utf8_count_chars(buf, -1));
    CHECK(strlen(buf) == 26, "длинное: байт %zu (ожидалось 26)", strlen(buf));
    CHECK(strncmp(buf, "ОченьДлинноеИмя", utf8_take_bytes("ОченьДлинноеИмя", -1, 13)) == 0,
          "длинное: содержимое обрезано неверно: «%s»", buf);

    /* пустое: 13 пробелов */
    tm_fmt_name(buf, sizeof(buf), "");
    CHECK(utf8_count_chars(buf, -1) == 13 && strlen(buf) == 13, "пустое: «%s»", buf);

    /* узкий буфер: не переполняется, символы не рвутся. 13 кириллических
     * символов — 26 байт, буфер 10: граница символа на 8 байтах
     * («Каль» = 4 символа) + 1 пробел = 9 байт; ранее здесь оставалась
     * ПОЛОВИНА символа и utf8_count_chars уходил за NUL (segv). */
    char small[10];
    tm_fmt_name(small, sizeof(small), "КалькуляторШашки");
    CHECK(strlen(small) == 9, "узкий буфер: %zu байт (ожидалось 9)", strlen(small));
    CHECK(strncmp(small, "Каль", 8) == 0, "узкий буфер: «%s»", small);
    /* каждый ведущий байт — валидное начало последовательности */
    for (const char *p = small; *p; p += seq_len((unsigned char)*p))
        CHECK((*p & 0xC0) != 0x80, "узкий буфер: разорванный UTF-8");
    /* счётчик символов не заходит за NUL: 4 буквы + 1 пробел */
    CHECK(utf8_count_chars(small, -1) == 5, "узкий буфер: счёт символов = %d",
          utf8_count_chars(small, -1));
}

/* ТЕСТ 4: мышь — выбор/снятие/меню/защита системных */
static void test_mouse(void)
{
    taskmgr_t m; memset(&m, 0, sizeof(m));
    window_t w = make_win(); w.data = &m;
    setup_tasks();
    tm_rebuild(&m);
    CHECK(m.slots_used == 6, "slots_used=%d (ожидалось 6)", m.slots_used);
    /* список: 0=kernel(Диспетчер зад), 1=Калькул, 2=Шашки, 3=browser, 4=ramfs(SYS), 5=ОченьДл... */

    /* --- ЛКМ по строке 2 («Шашки», y строки = TM_LIST_Y0+2+2*16) --- */
    cap_reset();
    int row_y = TM_LIST_Y0 + 2 + 2 * TM_ROW_H + 4;   /* +4: середина строки */
    tm_mouse(&w, 10, row_y, MSB_LEFT, MSB_LEFT);
    CHECK(m.sel == 2, "ЛКМ по строке 2: sel=%d", m.sel);
    CHECK(cap_kill_slot == -1, "ЛКМ по невыбранной не должна убивать");
    CHECK(cap_inv > 0, "нет перерисовки после выбора");

    /* --- повторный ЛКМ по той же строке — снятие задачи --- */
    cap_reset();
    tm_mouse(&w, 10, row_y, MSB_LEFT, MSB_LEFT);
    cap_reset(); m.sel = 2;
    tm_mouse(&w, 10, row_y, MSB_LEFT, MSB_LEFT);
    CHECK(cap_kill_slot == 2, "повторный ЛКМ: убит слот %d (ожидалось 2)", cap_kill_slot);
    CHECK(cap_wmk_slot == 2, "wm_request_kill(2) не вызван (%d)", cap_wmk_slot);
    CHECK(strstr(m.status, "убита") != NULL, "статус: «%s»", m.status);

    /* --- ЛКМ по пустому месту списка (ниже всех строк) — ничего --- */
    cap_reset(); m.sel = 0;
    tm_mouse(&w, 10, TM_LIST_Y0 + 2 + 7 * TM_ROW_H + 8, MSB_LEFT, MSB_LEFT);
    CHECK(m.sel == 0 && cap_kill_slot == -1, "клик мимо строк меняет sel/убивает");

    /* --- ПКМ по строке 1 («Калькул») — меню «Снять задачу» --- */
    cap_reset();
    row_y = TM_LIST_Y0 + 2 + 1 * TM_ROW_H + 4;
    tm_mouse(&w, 30, row_y, MSB_RIGHT, MSB_RIGHT);
    CHECK(cap_menu.active && cap_menu.n == 1, "ПКМ: меню не открыто");
    CHECK(strcmp(cap_menu.labels[0], "Снять задачу") == 0, "пункт: «%s»", cap_menu.labels[0]);
    CHECK(cap_menu.ids[0] == TMC_KILL, "id=%d", cap_menu.ids[0]);
    CHECK(cap_menu.disabled[0] == 0, "пункт для обычной задачи серый");
    CHECK(m.sel == 1, "ПКМ не выбрал строку");
    /* выбор пункта — колбэк в потоке окна (cb/uctx СОХРАНЯЕМ до cap_reset) */
    {
        wm_menu_fn cb1 = cap_menu.cb;
        void *uctx1 = cap_menu.uctx;
        cap_reset();
        cb1(TMC_KILL, uctx1);
    }
    CHECK(cap_kill_slot == 1, "меню: убит слот %d (ожидалось 1)", cap_kill_slot);

    /* --- ПКМ по системной задаче (ramfs) — пункт серый, kill запрещён --- */
    cap_reset();
    row_y = TM_LIST_Y0 + 2 + 4 * TM_ROW_H + 4;
    tm_mouse(&w, 30, row_y, MSB_RIGHT, MSB_RIGHT);
    CHECK(cap_menu.active, "ПКМ по системной: меню не открыто");
    CHECK(cap_menu.disabled[0] == 1, "пункт «Снять задачу» у системной не серый");
    {
        wm_menu_fn cb2 = cap_menu.cb;
        void *uctx2 = cap_menu.uctx;
        cap_reset();
        cb2(TMC_KILL, uctx2);
    }
    CHECK(cap_kill_slot == -1, "системная задача убита!");
    CHECK(strstr(m.status, "системная") != NULL, "статус: «%s»", m.status);

    /* --- ЛКМ-повтор по системной — отказ с сообщением --- */
    cap_reset();
    m.sel = 4;
    tm_mouse(&w, 10, TM_LIST_Y0 + 2 + 4 * TM_ROW_H + 4, MSB_LEFT, MSB_LEFT);
    CHECK(cap_kill_slot == -1, "повторный ЛКМ убил системную!");
    CHECK(strstr(m.status, "системная") != NULL, "статус: «%s»", m.status);

    /* --- клик по задаче 0 (ядро) — отказ --- */
    cap_reset();
    m.sel = 0;
    tm_mouse(&w, 10, TM_LIST_Y0 + 2 + 4, MSB_LEFT, MSB_LEFT);
    CHECK(cap_kill_slot == -1, "задача 0 убита!");
}

/* ТЕСТ 5: сеть — сэмплы и формат скорости */
static void test_net(void)
{
    taskmgr_t m; memset(&m, 0, sizeof(m));
    m.last_tx_bytes = f_tx_bytes = 1000;
    m.last_rx_bytes = f_rx_bytes = 2000;

    f_tx_bytes += 500; f_rx_bytes += 300;   /* +800 байт за интервал */
    tm_sample(&m);
    CHECK(m.net_history[0] == 800, "сэмпл 0: %u (ожидалось 800)", m.net_history[0]);
    CHECK(m.cpu_history_pos == 1, "pos=%d (ожидалось 1)", m.cpu_history_pos);

    f_tx_bytes += 1200; f_rx_bytes += 0;
    tm_sample(&m);
    CHECK(m.net_history[1] == 1200, "сэмпл 1: %u", m.net_history[1]);

    /* формат скорости (сэмпл*2 = байт/с) */
    char b[32];
    tm_fmt_rate(0, b, sizeof(b));        CHECK(strcmp(b, "0 Б/с") == 0, "rate: «%s»", b);
    tm_fmt_rate(512, b, sizeof(b));      CHECK(strcmp(b, "512 Б/с") == 0, "rate: «%s»", b);
    tm_fmt_rate(2048, b, sizeof(b));     CHECK(strcmp(b, "2.0 КБ/с") == 0, "rate: «%s»", b);
    tm_fmt_rate(1536, b, sizeof(b));     CHECK(strcmp(b, "1.5 КБ/с") == 0, "rate: «%s»", b);
    tm_fmt_rate(1048576, b, sizeof(b));  CHECK(strcmp(b, "1.0 МБ/с") == 0, "rate: «%s»", b);
    tm_fmt_rate(2621440, b, sizeof(b));  CHECK(strcmp(b, "2.5 МБ/с") == 0, "rate: «%s»", b);

    /* подпись у графика: последний сэмпл 1200 → 2400 Б/с → «2.3 КБ/с»,
     * прижата к правому краю графика */
    window_t w = make_win(); w.data = &m;
    setup_tasks();
    cap_reset();
    tm_draw(&w);
    int found = 0;
    for (int i = 0; i < cap_n; i++)
        if (strcmp(cap_text[i].text, "2.3 КБ/с") == 0) {
            found = 1;
            /* x правого края: graph_x = cw-204, метка прижата к gx+gw-2-lw */
            int gx = 620 - TM_GRAPH_W - 4;
            CHECK(cap_text[i].x == gx + TM_GRAPH_W - 2 - (int)fb_text_w("2.3 КБ/с"),
                  "NET-подпись x=%d", cap_text[i].x);
        }
    CHECK(found, "подпись скорости «2.3 КБ/с» не нарисована");

    /* третий график реально рисуется: NET под MEM (метки у левого края
     * каждого графика: gx+2) */
    int mem_y = TM_HDR_H + 2 + (TM_GRAPH_H + 4);
    int net_y = TM_HDR_H + 2 + 2 * (TM_GRAPH_H + 4);
    int lbl_net = 0, lbl_mem = 0, lbl_cpu = 0;
    int lx = 620 - TM_GRAPH_W - 4 + 2;
    for (int i = 0; i < cap_n; i++) {
        if (cap_text[i].x != lx) continue;
        if (cap_text[i].y == TM_HDR_H + 2 + 2) lbl_cpu = 1;
        if (cap_text[i].y == mem_y + 2) lbl_mem = 1;
        if (cap_text[i].y == net_y + 2) lbl_net = 1;
    }
    CHECK(lbl_cpu, "нет метки CPU");
    CHECK(lbl_mem, "нет метки MEM");
    CHECK(lbl_net, "нет метки NET (график сети не нарисован под остальными?)");
}

/* ТЕСТ 6: mem_history на том же слоте, что cpu (регрессия off-by-one) */
static void test_mem_same_slot(void)
{
    taskmgr_t m; memset(&m, 0, sizeof(m));
    m.last_tx_bytes = f_tx_bytes; m.last_rx_bytes = f_rx_bytes;
    tm_sample(&m);
    /* mem_used/heap = 4200000/10000000 = 42% */
    CHECK(m.mem_history[0] == 42, "mem_history[0]=%u (ожидалось 42 — на слоте CPU)",
          m.mem_history[0]);
}

int main(void)
{
    printf("[1] table_alignment\n"); fflush(stdout);
    test_table_alignment();
    printf("[2] fmt_name\n"); fflush(stdout);
    test_fmt_name();
    printf("[3] mouse\n"); fflush(stdout);
    test_mouse();
    printf("[4] net\n"); fflush(stdout);
    test_net();
    printf("[5] mem_same_slot\n"); fflush(stdout);
    test_mem_same_slot();

    if (fails) { printf("\nИТОГ: %d проверок провалено\n", fails); return 1; }
    printf("ИТОГ: все проверки пройдены\n");
    return 0;
}
