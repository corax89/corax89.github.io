#define _GNU_SOURCE
/* tnd_host.c — хост-тест Task 50: character-mode согласование telnetd
 * (RFC 854/857) + посимвольная работа dfm без Enter.
 *
 * Включает НАСТОЯЩИЙ telnetd.c (доступ к statics) с заглушками
 * net/task/timer/term (сигнатуры — из kernel-заголовков); dfm —
 * настоящий (dfm.c) с фальшивым ramfs (host-test/dfm/dfm_ramfs_stub.c).
 * Проверяем:
 *   A. баннер: WILL ECHO + WILL SGA + DO SGA + DONT LINEMODE;
 *   B. ответы на DO/WILL клиента осмысленные и БЕЗ дубликатов
 *      (регрессия Task 49: слепые WONT SGA/DONT SGA ломали char-mode);
 *   C. SB..SE и IAC IAC проглатываются;
 *   D. строка shell доходит до term_shell_exec с эхом;
 *   E. в fm ОДИН байт 'j' сразу перерисовывает экран (без Enter),
 *      стрелки (ESC [ B) листают, 'q' выходит;
 *   F. вход в редактор ('e') даёт строковый режим "ed> ";
 *   G. Ctrl+D закрывает соединение.
 */
#include <stdio.h>
#include <string.h>

#define HOST_TEST 1

/* malloc/free: сигнатуры mem.h (u32); в 64-битном ABI старшие биты RDI
 * обнуляются записью edi — символ glibc вызывает напрямую (как dfm_host.c).
 * <stdlib.h> сюда НЕ включаем, чтобы не спорить с mem.h о прототипе. */

/* ---------- захват вывода telnetd ---------- */
static unsigned char outbuf[256 * 1024];
static int outlen = 0;
static void out_reset(void) { outlen = 0; }
static int out_has_iac(unsigned char cmd, unsigned char opt)
{
    for (int i = 0; i + 2 < outlen; i++)
        if (outbuf[i] == 0xFF && outbuf[i + 1] == cmd &&
            outbuf[i + 2] == opt) return 1;
    return 0;
}

/* ---------- заглушки net (сигнатуры net.h) ---------- */
#include "types.h"
#include "net.h"
#include "timer.h"
#include "task.h"
#include "ramfs.h"
#include "dfm.h"
#include "apps.h"
static int  g_sock_valid = 1;
u32  net_tcp_gen(int sock)            { (void)sock; return 7; }
int  net_tcp_send(int sock, const void *buf, u32 n)
{
    (void)sock;
    if (outlen + (int)n < (int)sizeof(outbuf)) {
        memcpy(outbuf + outlen, buf, n);
        outlen += (int)n;
    }
    return (int)n;
}
int  net_tcp_send_pending(int sock)   { (void)sock; return 0; }
void net_poll(void) {}
void net_tcp_unpin(int sock)          { (void)sock; }
void net_tcp_pin(int sock)            { (void)sock; }
void net_tcp_close(int sock)          { (void)sock; g_sock_valid = 0; }
int  net_tcp_listen(u16 port, tcp_accept_cb_t cb, net_tcp_recv_cb_t rcb)
{ (void)port; (void)cb; (void)rcb; return 0; }
void net_tcp_unlisten(u16 port)       { (void)port; }
int  net_tcp_was_reset(int sock)      { (void)sock; return 0; }
tcp_state_t net_tcp_state(int sock)   { (void)sock; return TCP_ESTABLISHED; }
int  net_ntoa(u32 ip, char *out, u32 max)
{ (void)ip; snprintf(out, max, "10.0.2.2"); return 1; }

/* ---------- заглушки task/timer (сигнатуры task.h/timer.h) ---------- */
static u32 g_ticks = 1000;
u32 timer_ticks(void)                 { return g_ticks += 10; }
void task_yield(void) {}
void task_msleep(u32 ms)              { g_ticks += ms; }
int  task_spawn_prio(const char *name, void (*fn)(void *), void *arg, int prio)
{ (void)name; (void)fn; (void)arg; (void)prio; return 1; }
void task_set_system(int tid)         { (void)tid; }

/* ---------- заглушки apps (headless-терминал) ---------- */
static char exec_log[16][128];
static int  exec_n = 0;
struct term_s { int dummy; };   /* apps.h: typedef struct term_s term_t */
term_t *term_headless_create(void)    { static term_t t; return &t; }
void term_headless_free(term_t *t)    { (void)t; }
void term_headless_sink(term_t *t, void (*put)(void *ctx, const char *s),
                        void *ctx)
{ (void)t; (void)put; (void)ctx; }
void term_shell_exec(term_t *t, const char *line)
{
    (void)t;
    if (exec_n < 16) {
        snprintf(exec_log[exec_n], sizeof(exec_log[0]), "%s", line);
        exec_n++;
    }
}

/* ---------- заглушки прочего ---------- */
void serial_puts(const char *s)       { (void)s; }
void klog_puts(const char *s)         { (void)s; }

/* ---------- include НАСТОЯЩИХ telnetd.c и dfm.c ---------- */
#include "../../src/telnetd.c"

/* ---------- прогон байтов через приём + разбор (как задача) ---------- */
static tnd_conn_t *g_c;
static void feed(const void *data, int len)
{
    tnd_recv(g_c->sock, 0x0A000202, 4444, data, (u32)len);
    char tmp[128];
    int n;
    while ((n = tnd_inbuf_take(g_c, tmp, (int)sizeof(tmp))) > 0)
        for (int k = 0; k < n; k++)
            tnd_process_byte(g_c, (unsigned char)tmp[k]);
}


static int has_sub(const void *hay, int hlen, const char *needle)
{
    int nl = (int)strlen(needle);
    if (nl == 0) return 1;
    for (int i = 0; i + nl <= hlen; i++)
        if (memcmp((const char *)hay + i, needle, (size_t)nl) == 0) return 1;
    return 0;
}

static int fails = 0;
#define CHECK(cond, ...) do { \
    if (cond) { printf("  [OK] " __VA_ARGS__); printf("\n"); } \
    else { printf("  [FAIL] " __VA_ARGS__); printf("\n"); fails++; } \
} while (0)

int stub_seed(void);
int stub_write_raw(const char *path, const char *data);

int main(void)
{
    if (!stub_seed()) { printf("FAIL: сцена ramfs\n"); return 1; }
    /* старт: слоты, приём соединения, hello */
    telnetd_start();
    tnd_accept(1, 0x0A000202, 4444);
    g_c = &g_conns[0];
    CHECK(g_c->sock == 1, "accept: слот занят");
    out_reset();
    tnd_hello(g_c);

    /* A. баннер: IAC-посылка в начале */
    CHECK(outlen >= 12 &&
          outbuf[0] == 0xFF && outbuf[1] == 0xFB && outbuf[2] == 0x01,
          "баннер начинается с WILL ECHO");
    CHECK(out_has_iac(0xFB, 0x01) && out_has_iac(0xFB, 0x03) &&
          out_has_iac(0xFD, 0x03) && out_has_iac(0xFE, 0x22),
          "WILL ECHO + WILL SGA + DO SGA + DONT LINEMODE");
    CHECK(strstr((const char *)outbuf + 12, "N2600-OS telnet server") != NULL,
          "текст баннера на месте");

    /* B. ответы на клиента */
    out_reset();
    feed("\xff\xfd\x01", 3);              /* DO ECHO — уже согласовано */
    CHECK(outlen == 0, "DO ECHO: без повторного ответа (уже WILL ECHO)");

    out_reset();
    feed("\xff\xfb\x03", 3);              /* WILL SGA — уже согласовано */
    CHECK(outlen == 0, "WILL SGA: без ответа (уже DO SGA)");

    out_reset();
    feed("\xff\xfb\x03", 3);              /* повтор — дублей нет */
    CHECK(outlen == 0, "повторный WILL SGA: дублей нет");

    out_reset();
    feed("\xff\xfb\x22", 3);              /* WILL LINEMODE — отказ */
    CHECK(outlen == 3 && outbuf[0] == 0xFF && outbuf[1] == 0xFE &&
          outbuf[2] == 0x22, "WILL LINEMODE -> DONT LINEMODE");

    out_reset();
    feed("\xff\xfd\x18", 3);              /* DO TTYPE — отказ */
    CHECK(outlen == 3 && outbuf[0] == 0xFF && outbuf[1] == 0xFC &&
          outbuf[2] == 0x18, "DO TTYPE -> WONT TTYPE");

    out_reset();
    feed("\xff\xfb\x01", 3);              /* WILL ECHO клиента — эхоим мы */
    CHECK(outlen == 3 && outbuf[0] == 0xFF && outbuf[1] == 0xFE &&
          outbuf[2] == 0x01, "WILL ECHO клиента -> DONT ECHO");

    /* C. SB..SE и IAC IAC */
    out_reset();
    feed("\xff\xfa\x18\x00\x78\x74\x65\x72\x6d\xff\xf0", 11);
    out_reset();
    feed("\xff\xff", 2);                  /* IAC IAC = литерал 0xFF */
    CHECK(outlen == 2 && outbuf[0] == 0xFF && outbuf[1] == 0xFF,
          "SB..SE проглочен, IAC IAC -> литерал 0xFF (эхо FF FF)");
    feed("\x15", 1);                      /* Ctrl+U — очистить строку */

    /* D. строка shell */
    out_reset();
    exec_n = 0;
    feed("help\r", 5);
    CHECK(exec_n == 1 && !strcmp(exec_log[0], "help"),
          "строка shell дошла до term_shell_exec: '%s'",
          exec_n ? exec_log[0] : "");
    CHECK(outlen > 6 && strstr((const char *)outbuf, "help") != NULL,
          "эхо введённой строки ушло клиенту");

    /* E. fm: посимвольный режим */
    out_reset();
    feed("fm\r", 3);
    CHECK(g_c->fm_mode == 1, "вход в fm (fm_mode=1)");
    CHECK(outlen > 32 && memchr(outbuf, 0x1B, (size_t)outlen) != NULL,
          "dfm нарисовал экран (ANSI-вывод после 'fm')");

    /* ОДИН байт 'j' без Enter — курсор вниз: dfm ПЕРЕрисовал экран */
    out_reset();
    feed("j", 1);
    CHECK(g_c->fm_mode == 1, "fm_mode сохранён после 'j'");
    CHECK(outlen > 16 && memchr(outbuf, 0x1B, (size_t)outlen) != NULL,
          "клавиша 'j' БЕЗ Enter сразу перерисовала экран (%d байт)",
          outlen);

    /* стрелка вниз (ESC [ B) — тоже без Enter */
    out_reset();
    feed("\x1b[B", 3);
    CHECK(outlen > 16, "стрелка вниз (ESC[B) листает без Enter (%d)", outlen);

    /* 'd' — подтверждение удаления; 'n' отменяет */
    feed("d", 1);
    feed("n", 1);
    CHECK(g_c->fm_mode == 1, "после 'd'/'n' fm жив (отмена удаления)");

    /* F. редактор: 'e' на первом файле -> строковый режим */
    out_reset();
    feed("e", 1);
    CHECK(g_c->fm_mode == 1 && dfm_wants_line(&g_c->fm),
          "'e' перешёл в редактор (строковый режим)");
    CHECK(has_sub(outbuf, outlen, "ed>"),
          "приглашение ed> ушло клиенту");
    out_reset();
    feed("hello host\r", 11);
    CHECK(g_c->fm_mode == 1, "строка редактора принята");
    feed("q\r", 2);                       /* строка "q" в редакторе */
    out_reset();
    feed("q", 1);                         /* 'q' в обзоре — выход */
    CHECK(g_c->fm_mode == 0, "'q' в обзоре вышел из fm");
    CHECK(has_sub(outbuf, outlen, "n2600>"),
          "после выхода приглашение shell");

    /* G. Ctrl+D закрывает соединение */
    out_reset();
    feed("\x04", 1);
    CHECK(g_c->sock < 0, "Ctrl+D закрыл соединение");

    (void)g_sock_valid;
    printf("\n=== ИТОГ: %s (%d провалов) ===\n",
           fails ? "ЕСТЬ ОШИБКИ" : "ВСЕ ПРОВЕРКИ ПРОШЛИ", fails);
    return fails ? 1 : 0;
}
