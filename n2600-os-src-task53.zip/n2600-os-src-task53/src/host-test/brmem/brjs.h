/* brjs.h — JavaScript в браузере N2600-OS (Task 47). Header-only:
 * включается из mquickjs_api.c (ядро, ДО таблицы стдлиба — тела
 * js_br_* нужны c_function_table) и из хост-теста.
 *
 * Что даёт странице (поверх стандартной библиотеки MicroQuickJS):
 *   document.write(html)        — дописать HTML в страницу (вставляется
 *                                 на месте скрипта после его завершения);
 *   document.title              — чтение/запись (браузер забирает после);
 *   document.location.href      — адрес страницы (чтение);
 *   document.getElementById(id) — снимок поля формы: {id, value, type,
 *                                 name} (plain object, НЕ живой);
 *   document.setFieldValue(id, v) — записать значение поля обратно
 *                                 (текст/textarea; "1"/"true" у checkbox
 *                                 ставит галочку). Компенсация отсутствия
 *                                 в mquickjs C-аксессоров свойств;
 *   alert(text)                 — текст попадает в статус-строку браузера;
 *   fetch(url) / httpGet(url)   — СИНХРОННЫЙ GET (страница грузится в
 *                                 потоке окна — блокирует только его).
 *                                 Возвращает тело строкой, при ошибке —
 *                                 исключение. Отличие от стандарта:
 *                                 без Promise (в движке нет событийного
 *                                 цикла);
 *   setTimeout/clearTimeout     — заглушки (нет событийного цикла).
 *
 * onclick/js-атрибуты и javascript:-ссылки исполняются тем же контекстом
 * (brjs_eval после загрузки страницы). Дедлайн eval — защита от
 * зависших скриптов (окно живо, скрипт прерывается исключением).
 *
 * Привязка нативов: движок создаёт C-функции ТОЛЬКО по индексам
 * скомпилированной c_function_table (см. mqjs_stdlib_os.h, добавленные
 * в конце записи) — brjs_start() принимает базовый индекс и привязывает
 * функции к глобальному объекту по именам через JS_SetPropertyStr.
 *
 * Память: собственный пул (BRJS_POOL) с канарейками; порча пула ->
 * raw-free без JS_FreeContext (политика mquickjs_api.c). */
#ifndef BRJS_H
#define BRJS_H

#include "mquickjs.h"
#include "brform.h"

#ifdef HOST_TEST
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
unsigned int brjs_host_ticks(void);
int brjs_host_stack_range(unsigned int *lo, unsigned int *hi);
#define BRJS_TICKS()           brjs_host_ticks()
#define BRJS_STACK_RANGE(lo, hi) brjs_host_stack_range(lo, hi)
#define BRJS_YIELD()           ((void)0)
#else
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#define BRJS_TICKS()           timer_ticks()
#define BRJS_STACK_RANGE(lo, hi) task_stack_range(lo, hi)
#define BRJS_YIELD()           task_yield()
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

#define BRJS_POOL       (256u * 1024u)   /* основной пул контекста */
#define BRJS_GROW_CHUNK (64u * 1024u)    /* сегменты динамического роста */
#define BRJS_GROW_MAX   (512u * 1024u)
#define BRJS_WBUF_MAX   16384            /* буфер document.write */
#define BRJS_EVAL_MS    3000u            /* дедлайн одного eval */
#define BRJS_FETCH_MAX  16384

typedef struct {
    /* — предоставляется браузером — */
    void       *forms;             /* brf_forms_t* */
    const char *page_url;
    /* document.write (raw HTML; конвертирует браузер после eval) */
    char        wbuf_static[BRJS_WBUF_MAX];
    int         wlen;
    int         wovf;              /* буфер переполнялся */
    /* alert */
    char        alert[96];
    int         alert_n;
    /* синхронный GET (браузер даёт колбэк: URL разрешает сам) */
    int  (*fetch_fn)(void *ud, const char *url, char *out, int out_max);
    void       *fetch_ud;
    char        fetch_err[48];
    /* — внутреннее — */
    JSContext  *ctx;
    void       *pool;              /* пул + канарейки вокруг */
    u32         pool_size;
    u32         deadline;          /* тик дедлайна текущего eval */
    int         timed_out;         /* 1 = текущий eval прерван по таймауту */
    char        last_err[96];      /* сообщение исключения (для статуса) */
    char        title[64];         /* document.title после eval */
    int         alive;
} brjs_env_t;

/* ---------------- нативные функции (индексы c_function_table) ----------------
 * Порядок ОБЯЗАН совпадать с добавленными записями в mqjs_stdlib_os.h:
 *   0 br_write   1 br_getelem   2 br_setfield
 *   3 br_alert   4 br_fetch     5 br_stub
 */
#define BRJS_FN_WRITE     0
#define BRJS_FN_GETELEM   1
#define BRJS_FN_SETFIELD  2
#define BRJS_FN_ALERT     3
#define BRJS_FN_FETCH     4
#define BRJS_FN_STUB      5
#define BRJS_FN_COUNT     6

static JSValue js_br_write(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_getelem(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_setfield(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_alert(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_fetch(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_stub(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);

/* Тела js_br_* реально используются только в TU таблицы c_function_table
 * (mquickjs_api.c: brjs.h включается ДО mqjs_stdlib_os*.h). В прочих
 * включениях (apps_browser.c) они не используются — гасим
 * -Wunused-function атрибутом (безвреден и для использующего TU). */
#define BRJS_FN_UNUSED __attribute__((unused))

static int brjs_interrupt(JSContext *ctx, void *opaque)
{
    (void)ctx;                    /* сигнатура движка; дедлайн — через opaque */
    brjs_env_t *e = (brjs_env_t *)opaque;
    BRJS_YIELD();
    if (e && e->deadline && BRJS_TICKS() > e->deadline) {
        e->timed_out = 1;
        return 1;                    /* движок бросит исключение */
    }
    return 0;
}

static void *brjs_heap_alloc(size_t size)
{
    return malloc((u32)size);
}

static void brjs_heap_free(void *p)
{
    free(p);
}

/* ---------------- нативы ---------------- */

static brjs_env_t *brjs_env(JSContext *ctx)
{
    return (brjs_env_t *)JS_GetContextOpaque(ctx);
}

static BRJS_FN_UNUSED JSValue js_br_write(JSContext *ctx, JSValue *this_val,
                           int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    for (int i = 0; i < argc; i++) {
        size_t sl = 0;
        JSCStringBuf sb;
        const char *s = JS_ToCStringLen(ctx, &sl, argv[i], &sb);
        if (!s) return JS_EXCEPTION;
        if (e->wlen + (int)sl >= BRJS_WBUF_MAX - 1) {
            e->wovf = 1;
        } else {
            memcpy(e->wbuf_static + e->wlen, s, sl);
            e->wlen += (int)sl;
            e->wbuf_static[e->wlen] = 0;
        }
    }
    return JS_UNDEFINED;
}

static brf_field_t *brjs_field_by_id(brjs_env_t *e, const char *id)
{
    brf_forms_t *f = (brf_forms_t *)e->forms;
    if (!f || !id || !id[0]) return NULL;
    for (int i = 0; i < f->nfields; i++) {
        brf_field_t *fl = &f->fields[i];
        if (!strcmp(fl->id, id) || !strcmp(fl->name, id))
            return fl;
    }
    return NULL;
}

static BRJS_FN_UNUSED JSValue js_br_getelem(JSContext *ctx, JSValue *this_val,
                             int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 1) return JS_NULL;
    size_t sl = 0;
    JSCStringBuf sb;
    const char *id = JS_ToCStringLen(ctx, &sl, argv[0], &sb);
    if (!id) return JS_EXCEPTION;
    brf_field_t *fl = brjs_field_by_id(e, id);
    if (!fl) return JS_NULL;
    JSValue o = JS_NewObject(ctx);
    if (JS_IsException(o)) return o;
    JS_SetPropertyStr(ctx, o, "id", JS_NewString(ctx, fl->id));
    JS_SetPropertyStr(ctx, o, "name", JS_NewString(ctx, fl->name));
    JS_SetPropertyStr(ctx, o, "type", JS_NewString(ctx, fl->type));
    JS_SetPropertyStr(ctx, o, "value", JS_NewString(ctx, fl->value));
    return o;
}

static BRJS_FN_UNUSED JSValue js_br_setfield(JSContext *ctx, JSValue *this_val,
                              int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 2) return JS_UNDEFINED;
    size_t il = 0, vl = 0;
    JSCStringBuf sb1, sb2;
    const char *id = JS_ToCStringLen(ctx, &il, argv[0], &sb1);
    const char *val = JS_ToCStringLen(ctx, &vl, argv[1], &sb2);
    if (!id || !val) return JS_EXCEPTION;
    brf_field_t *fl = brjs_field_by_id(e, id);
    if (!fl) return JS_UNDEFINED;
    if (!strcmp(fl->type, "checkbox") || !strcmp(fl->type, "radio")) {
        fl->checked = (!strcmp(val, "1") || !strcmp(val, "true") ||
                       !strcmp(val, "checked") || !strcmp(val, "on"));
    } else if (!strcmp(fl->type, "select")) {
        /* выбрать вариант по value или label */
        for (int i = 0; i < fl->nopts; i++) {
            if (!strcmp(fl->opts[i], val)) { fl->opt_sel = i; break; }
        }
    } else {
        strncpy(fl->value, val, sizeof(fl->value) - 1);
        fl->value[sizeof(fl->value) - 1] = 0;
    }
    return JS_UNDEFINED;
}

static BRJS_FN_UNUSED JSValue js_br_alert(JSContext *ctx, JSValue *this_val,
                           int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc >= 1) {
        size_t sl = 0;
        JSCStringBuf sb;
        const char *s = JS_ToCStringLen(ctx, &sl, argv[0], &sb);
        if (s) {
            strncpy(e->alert, s, sizeof(e->alert) - 1);
            e->alert[sizeof(e->alert) - 1] = 0;
            e->alert_n++;
        }
    }
    return JS_UNDEFINED;
}

static BRJS_FN_UNUSED JSValue js_br_fetch(JSContext *ctx, JSValue *this_val,
                           int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 1 || !e->fetch_fn)
        return JS_ThrowError(ctx, JS_CLASS_ERROR, "fetch: нет адреса/канала");
    size_t sl = 0;
    JSCStringBuf sb;
    const char *url = JS_ToCStringLen(ctx, &sl, argv[0], &sb);
    if (!url || !url[0])
        return JS_ThrowError(ctx, JS_CLASS_ERROR, "fetch: пустой адрес");

    char *resp = (char *)malloc(BRJS_FETCH_MAX + 1);
    if (!resp)
        return JS_ThrowOutOfMemory(ctx);
    int n = e->fetch_fn(e->fetch_ud, url, resp, BRJS_FETCH_MAX);
    if (n < 0) {
        free(resp);
        return JS_ThrowError(ctx, JS_CLASS_ERROR, "fetch failed: %s",
                             e->fetch_err[0] ? e->fetch_err : "ошибка сети");
    }
    JSValue r = JS_NewStringLen(ctx, resp, (size_t)n);
    free(resp);
    return r;
}

static BRJS_FN_UNUSED JSValue js_br_stub(JSContext *ctx, JSValue *this_val,
                          int argc, JSValue *argv)
{
    (void)this_val;
    (void)argc;
    (void)argv;
    (void)ctx;
    return JS_UNDEFINED;      /* setTimeout/clearTimeout — заглушки */
}

/* ---------------- запуск/останов ---------------- */

/* Создать контекст и привязать глобальные объекты. cfunc_base — индекс
 * первой из BRJS_FN_COUNT записей brjs в c_function_table (см.
 * mqjs_stdlib_os.h / mqjs_br_cfunc_base()). 0 = успех. */
static BRJS_FN_UNUSED int brjs_start(brjs_env_t *e, const JSSTDLibraryDef *stdlib,
                      int cfunc_base)
{
    memset(e, 0, sizeof(*e));
    /* Task 51 [BRJS-CANARY]: раньше маллочилось BRJS_POOL + 4*16 — запас
     * только под ОДНУ канарейку (64 Б), а писались ОБЕ (pre перед пулом и
     * post СРАЗУ ЗА КОНЦОМ блока): 64 байта ЗА ГРАНИЦЕЙ аллокации на
     * КАЖДОМ brjs_start — порча заголовка соседнего блока кучи (в логах
     * это «ПОРЧА КУЧИ: блок size=0» и каскад «нет памяти» после страниц
     * с JS). Эталонный расчёт — mqjs_sess_alloc_pool: size + 2*16*4. */
    e->pool_size = BRJS_POOL + 8 * 16;      /* + канарейки с ОБОИХ краёв */
    e->pool = malloc(e->pool_size);
    if (!e->pool) return -1;

    /* канарейки (16 слов с каждой стороны пула) — как в mquickjs_api */
    u32 *pre = (u32 *)e->pool;
    u8 *mem = (u8 *)e->pool + 64;
    u32 *post = (u32 *)(mem + BRJS_POOL);
    for (int i = 0; i < 16; i++) {
        pre[i] = 0xB5F0CAFEu;
        post[i] = 0xB5F0CAFEu;
    }

    e->ctx = JS_NewContext(mem, BRJS_POOL, stdlib);
    if (!e->ctx) {
        free(e->pool);
        e->pool = NULL;
        return -1;
    }
    JS_EnableHeapGrowth(e->ctx, BRJS_GROW_CHUNK, BRJS_GROW_MAX,
                        brjs_heap_alloc, brjs_heap_free);
    JS_SetContextOpaque(e->ctx, e);
    JS_SetInterruptHandler(e->ctx, brjs_interrupt);
    {
        u32 lo = 0, hi = 0;
        if (BRJS_STACK_RANGE(&lo, &hi))
            JS_SetStackGuard(e->ctx, (void *)(unsigned long)(lo + 4096));
    }
    e->alive = 1;
    e->deadline = 0;

    /* привязать нативы и глобальные объекты */
    JSValue glob = JS_GetGlobalObject(e->ctx);
    if (JS_IsException(glob)) return -1;

    /* document */
    JSValue doc = JS_NewObject(e->ctx);
    if (!JS_IsException(doc)) {
        int idxs[3] = { BRJS_FN_WRITE, BRJS_FN_GETELEM, BRJS_FN_SETFIELD };
        const char *dn[3] = { "write", "getElementById", "setFieldValue" };
        for (int i = 0; i < 3; i++) {
            JSValue f = JS_NewCFunctionParams(e->ctx, cfunc_base + idxs[i],
                                              JS_UNDEFINED);
            if (!JS_IsException(f))
                JS_SetPropertyStr(e->ctx, doc, dn[i], f);
        }
        JSValue loc = JS_NewObject(e->ctx);
        if (!JS_IsException(loc)) {
            JS_SetPropertyStr(e->ctx, loc, "href",
                              JS_NewString(e->ctx,
                                           e->page_url ? e->page_url : ""));
            JS_SetPropertyStr(e->ctx, doc, "location", loc);
        }
        JS_SetPropertyStr(e->ctx, doc, "title", JS_NewString(e->ctx, ""));
        JS_SetPropertyStr(e->ctx, glob, "document", doc);
    }

    /* alert / fetch / httpGet / setTimeout-заглушки */
    {
        struct { int idx; const char *name; } binds[] = {
            { BRJS_FN_ALERT, "alert" },
            { BRJS_FN_FETCH, "fetch" },
            { BRJS_FN_FETCH, "httpGet" },
            { BRJS_FN_STUB,  "setTimeout" },
            { BRJS_FN_STUB,  "clearTimeout" },
        };
        for (unsigned i = 0; i < sizeof(binds) / sizeof(binds[0]); i++) {
            JSValue f = JS_NewCFunctionParams(e->ctx,
                                              cfunc_base + binds[i].idx,
                                              JS_UNDEFINED);
            if (!JS_IsException(f))
                JS_SetPropertyStr(e->ctx, glob, binds[i].name, f);
        }
    }
    return 0;
}

/* Исполнить код (страницы/onclick/javascript:). 0 = ок, -1 = ошибка JS
 * (текст в e->last_err), -2 = прерван по дедлайну. */
static BRJS_FN_UNUSED int brjs_eval(brjs_env_t *e, const char *code, const char *name)
{
    if (!e->alive || !code || !code[0]) return 0;
    e->timed_out = 0;
    e->deadline = BRJS_TICKS() + BRJS_EVAL_MS;
    size_t len = strlen(code);
    JSValue r = JS_Eval(e->ctx, code, len, name ? name : "page", 0);
    e->deadline = 0;
    int rc = 0;
    if (e->timed_out) {
        snprintf(e->last_err, sizeof(e->last_err),
                 "JS прерван по таймауту (%u мс)", (unsigned)BRJS_EVAL_MS);
        rc = -2;
    } else if (JS_IsException(r)) {
        JSValue ex = JS_GetException(e->ctx);
        size_t sl = 0;
        JSCStringBuf sb;
        const char *msg = JS_IsNull(ex) ? NULL
                          : JS_ToCStringLen(e->ctx, &sl, ex, &sb);
        snprintf(e->last_err, sizeof(e->last_err), "JS: %s",
                 msg && msg[0] ? msg : "исключение");
        rc = -1;
    }
    /* document.title -> env (браузер покажет в статусе) */
    {
        JSValue doc = JS_GetPropertyStr(e->ctx,
                                        JS_GetGlobalObject(e->ctx), "document");
        if (!JS_IsException(doc) && !JS_IsUndefined(doc)) {
            size_t tl = 0;
            JSCStringBuf sb;
            JSValue t = JS_GetPropertyStr(e->ctx, doc, "title");
            const char *ts = JS_ToCStringLen(e->ctx, &tl, t, &sb);
            if (ts) {
                strncpy(e->title, ts, sizeof(e->title) - 1);
                e->title[sizeof(e->title) - 1] = 0;
            }
        }
    }
    return rc;
}

/* Канарейки целы? 1 = да. */
static int brjs_pool_ok(brjs_env_t *e)
{
    if (!e->pool) return 1;
    u32 *pre = (u32 *)e->pool;
    u8 *mem = (u8 *)e->pool + 64;
    u32 *post = (u32 *)(mem + BRJS_POOL);
    for (int i = 0; i < 16; i++)
        if (pre[i] != 0xB5F0CAFEu || post[i] != 0xB5F0CAFEu)
            return 0;
    return 1;
}

/* Останов (порча пула -> raw-free, как в mquickjs_api). */
static BRJS_FN_UNUSED void brjs_stop(brjs_env_t *e)
{
    if (!e->alive) return;
    if (e->ctx && brjs_pool_ok(e)) {
        JS_FreeContext(e->ctx);
    }
    e->ctx = NULL;
    e->alive = 0;
    if (e->pool) free(e->pool);
    e->pool = NULL;
}

#endif /* BRJS_H */
