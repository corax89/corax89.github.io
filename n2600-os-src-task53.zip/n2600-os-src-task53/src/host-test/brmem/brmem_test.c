/* brmem_test.c — Task 51 [JS-FREE]: жизненный цикл памяти браузерного JS.
 *
 * Что проверяется НАСТОЯЩИМ кодом (не заглушками):
 *   - mquickjs.c     — движок (хостовая сборка, libc);
 *   - mqjs_stdlib_os.h — настоящая таблица стдлиба (мостовые js_*-функции
 *     никогда не вызываются тестом — на линкере
 *     --unresolved-symbols=ignore-all они становятся нулями);
 *   - brform.h       — разбор форм/скриптов страницы (brf_parse/brf_reset);
 *   - brjs.h         — brjs_start/eval/stop: пул 256 КиБ + канарейки +
 *     сегменты динамического роста (JS_EnableHeapGrowth -> malloc/free).
 *
 * Схема подсчёта: malloc/free переименованы макросами в счётчики
 * (одинаковые флаги у ВСЕХ единиц трансляции — здесь сборка единым TU).
 * Инвариант каждого теста: после brjs_stop()/brf_reset() число аллокаций
 * равно числу освобождений — «память возвращена системе». Раньше
 * закрытие окна браузера НЕ звало brjs_stop вовсе: пул 256 КиБ и до
 * 512 КиБ сегментов роста оставались занятыми навсегда (жалоба
 * пользователя «js забирает всю память и не отдаёт даже после закрытия
 * браузера»).
 *
 * Сборка/запуск: ./run_brmem.sh [asan]
 */
#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

/* ---------- счётчик аллокаций (malloc/free -> счётчики) ---------- */
static long g_allocs = 0, g_frees = 0, g_bytes = 0, g_peak = 0, g_cur = 0;

void *cnt_malloc(size_t n)
{
    g_allocs++;
    g_bytes += (long)n;
    g_cur += (long)n;
    if (g_cur > g_peak) g_peak = g_cur;
    /* realloc НЕ переименован — через него идём к настоящему аллокатору
     * (и ASan-овскому перехватчику при -fsanitize=address) */
    return realloc(0, n);
}

void cnt_free(void *p)
{
    if (p) {
        g_frees++;
    }
    p = realloc(p, 0); (void)p;  /* free(p) через realloc(p, 0) */
}

#define malloc cnt_malloc
#define free  cnt_free

/* ---------- типы ядра + НАСТОЯЩИЙ движок и таблицы ---------- */
/* Порядок как в mquickjs_api.c: движок, потом brjs.h (объявления
 * js_br_* — на них ссылается таблица стдлиба), потом таблица.
 * На хосте сборка 64-битная: JS_PTR64 + mqjs_stdlib_os64.h (64-битная
 * разметка ROM-таблицы, как в ядре 32-битная mqjs_stdlib_os.h). */
#define HOST_TEST 1
#include "types.h"
#include "mquickjs.c"            /* движок: cutils+dtoa+libm+mquickjs */
#include "brjs.h"                /* js_br_* (включает brform.h) */

#if defined(JS_PTR64)
#include "mquickjs_priv.h"
#include "bridge_decls.h"        /* мостовые функции таблицы (тела не нужны) */
#include "mqjs_stdlib_os64.h"    /* js_stdlib, 64-битная разметка */
#else
#include "mquickjs_priv.h"
#include "mqjs_stdlib_os.h"      /* js_stdlib, 32-битная разметка */
#endif

/* Базовый индекс браузерных записей в c_function_table:
 * 32-битный вариант даёт готовый JS_BR_CFUNC_BASE (brjs.h),
 * 64-битный — считаем от размера таблицы, как в mquickjs_api.c. */
#if defined(JS_PTR64)
static int BR_CFUNC_BASE(void)
{
    return (int)(sizeof(js_c_function_table) / sizeof(js_c_function_table[0]))
           - BRJS_FN_COUNT;
}
#else
static int BR_CFUNC_BASE(void) { return JS_BR_CFUNC_BASE; }
#endif

/* brjs HOST_TEST-хуки: тики = монотонные мс; диапазон стека — eval
 * выполняется на стеке main, guard от нижней границы (brjs_start ставит
 * lo+4096; на хосте стек большой — отдаём фактические границы). */
unsigned int brjs_host_ticks(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (unsigned int)(ts.tv_sec * 1000u + (unsigned)(ts.tv_nsec / 1000000u));
}

int brjs_host_stack_range(unsigned int *lo, unsigned int *hi)
{
    int probe = 0;
    /* lo < hi: движку нужна НИЖНЯЯ граница стека (guard). На x86-64
     * стек растёт вниз: нижняя граница — текущий кадр, верхняя —
     * приблизительно старт main. Guard не критичен для теста. */
    if (lo) *lo = (unsigned int)(unsigned long)&probe;
    if (hi) *hi = (unsigned int)(unsigned long)&probe + (8u * 1024u * 1024u);
    return 1;
}

/* ---------- каркас ---------- */
static int failures = 0;

#define CHECK(cond, msg) do { \
    if (!(cond)) { \
        printf("FAIL: %s (строка %d)\n", msg, __LINE__); \
        failures++; \
    } \
} while (0)

static long balance(void) { return g_allocs - g_frees; }

static brjs_env_t env;

/* ---------------- 1. жизненный цикл: start -> eval -> stop ---------------- */
static void test_lifecycle(void)
{
    long b0 = balance();

    CHECK(brjs_start(&env, &js_stdlib, BR_CFUNC_BASE()) == 0, "start ok");
    CHECK(env.alive && env.ctx && env.pool, "контекст и пул созданы");

    int rc = brjs_eval(&env, "var s = 0; for (var i = 0; i < 100; i++) s += i; s",
                       "sum");
    CHECK(rc == 0, "eval суммы 0..99");

    /* связка document.write (настоящие js_br_write из brjs.h) */
    env.wlen = 0;
    env.wovf = 0;
    env.wbuf_static[0] = 0;
    rc = brjs_eval(&env, "document.write(\"<b>hi</b>\");", "dwrite");
    CHECK(rc == 0, "document.write eval");
    CHECK(env.wlen == 9 && !env.wovf &&
          !strcmp(env.wbuf_static, "<b>hi</b>"), "document.write буфер");

    /* alert -> env.alert (статус-строка браузера) */
    rc = brjs_eval(&env, "alert(\"привет\");", "al");
    CHECK(rc == 0 && env.alert_n == 1 &&
          !strcmp(env.alert, "привет"), "alert");

    brjs_stop(&env);
    CHECK(!env.alive && !env.ctx && !env.pool, "stop: всё обнулено");
    CHECK(balance() == b0, "lifecycle: ВСЯ память возвращена");
    printf("  lifecycle: allocs=%ld peak=%ld байт — ок\n", g_allocs, g_peak);
}

/* ------------- 2. рост кучи: сегменты через malloc/free ------------- */
static void test_growth_segments(void)
{
    long b0 = balance();
    long bytes0 = g_bytes;

    CHECK(brjs_start(&env, &js_stdlib, BR_CFUNC_BASE()) == 0, "start2");

    /* строк много больше пула 256 КиБ: движок запросит сегменты роста
     * (64 КиБ кусками, до 512 КиБ) через brjs_heap_alloc -> cnt_malloc */
    int rc = brjs_eval(&env,
        "var a = []; for (var i = 0; i < 6000; i++) a.push('abcdefgh' + i);"
        "a.length", "grow");
    (void)rc;   /* OOM в середине — допустимо: проверяем ВОЗВРАТ памяти */
    CHECK(g_bytes - bytes0 > (long)BRJS_POOL,
          "рост: внешние аллокации > пула (сегменты выделялись)");

    brjs_stop(&env);
    CHECK(balance() == b0, "growth: пул+сегменты возвращены целиком");
    printf("  growth: пик %ld КБ — ок\n", g_peak / 1024);
}

/* ------------- 3. OOM-шторм: чистое исключение + полный возврат ------------- */
static void test_oom_clean(void)
{
    long b0 = balance();

    CHECK(brjs_start(&env, &js_stdlib, BR_CFUNC_BASE()) == 0, "start3");

    /* бесконечный рост до отказа кучи: движок бросает чистое
     * OutOfMemory-исключение (не abort, не порча) */
    int rc = brjs_eval(&env,
        "var a = []; for (;;) { a.push(new Array(501).join('x')); }",
        "oom");
    CHECK(rc != 0, "oom: исключение (не зависание)");
    CHECK(env.alive, "oom: движок жив после отказа");
    CHECK(env.last_err[0], "oom: текст ошибки для статуса");
    printf("  oom: rc=%d err=\"%.60s\"\n", rc, env.last_err);

    brjs_stop(&env);
    CHECK(balance() == b0, "oom: память (пул+сегменты) возвращена");
}

/* ------------- 4. байты скриптов страницы: brf_parse -> brf_reset ------------- */
static void test_brf_script_buffers(void)
{
    long b0 = balance();

    /* формат htmlconv: \001SCRIPT \n код \n \001/SCRIPT (+ INPUT/BUTTON/
     * SELECT/OPT как в Task 47/50) */
    static const char md[] =
        "заголовок страницы\n"
        "\001SCRIPT\n"
        "var x = 41;\n"
        "var y = x + 1;\n"
        "\001/SCRIPT\n"
        "текст между блоками\n"
        "\001FORM action=\"/go\" method=\"get\"\n"
        "\001INPUT type=\"text\" name=\"f\" value=\"hi\"\n"
        "\001SELECT name=\"s\"\n"
        "\001OPT value=\"1\" label=\"один\"\n"
        "\001OPT value=\"2\" label=\"два\" selected\n"
        "\001/SELECT\n"
        "\001BUTTON type=\"submit\" label=\"Найти\"\n"
        "\001/FORM\n";
    char buf[1024];
    memcpy(buf, md, sizeof(md));

    brf_forms_t f;
    memset(&f, 0, sizeof(f));
    int nl = brf_parse(&f, buf, (int)sizeof(md) - 1);
    CHECK(nl > 0, "brf_parse вернул длину");
    CHECK(f.nscripts == 1 && f.scripts[0].code != NULL,
          "скрипт собран (code malloc)");
    if (f.nscripts == 1 && f.scripts[0].code)
        CHECK(strstr(f.scripts[0].code, "var y = x + 1;") != NULL,
              "код скрипта на месте");
    CHECK(f.nfields >= 3, "поля формы собраны");
    CHECK(f.nforms == 1 && f.forms[0].used, "форма размечена");
    /* select: варианты и выбранный */
    {
        brf_field_t *sel = NULL;
        for (int i = 0; i < f.nfields; i++)
            if (!strcmp(f.fields[i].type, "select")) sel = &f.fields[i];
        CHECK(sel && sel->nopts == 2, "select: 2 варианта");
        CHECK(sel && sel->opt_sel == 1, "select: selected учтён");
    }

    /* инвариант Task 51: brf_reset возвращает буферы кода */
    brf_reset(&f);
    CHECK(balance() == b0, "brf_reset: буферы скриптов возвращены");
}

/* ------------- 5. циклы навигации/закрытия: 5 страниц подряд ------------- */
static void test_cycles(void)
{
    long b0 = balance();

    static const char page[] =
        "страница\n"
        "\001SCRIPT\nvar q = \"данные\"; document.write(q);\n\001/SCRIPT\n"
        "конец\n";
    for (int k = 0; k < 5; k++) {
        CHECK(brjs_start(&env, &js_stdlib, BR_CFUNC_BASE()) == 0,
              "цикл: start");
        env.wlen = 0;
        env.wovf = 0;
        env.wbuf_static[0] = 0;
        brjs_eval(&env, "document.write(\"строка N\");", "cyc");
        brjs_stop(&env);

        /* и страница со скриптом через brf (навигация чистит коды
         * через brf_parse -> brf_reset) */
        char buf[256];
        memcpy(buf, page, sizeof(page));
        brf_forms_t f;
        memset(&f, 0, sizeof(f));
        brf_parse(&f, buf, (int)sizeof(page) - 1);
        brf_reset(&f);
    }
    CHECK(balance() == b0, "5 циклов: ни одной утёкшей аллокации");
    printf("  cycles: 5 страниц подряд — ок\n");
}

/* ---------------- brjs_start повторно на НЕ остановленном env ---------------- */
static void test_reensure(void)
{
    /* br_js_ensure зовёт brjs_start только при !alive — но защита
     * самого brjs_start: он memset'ит env и маллочит новый пул.
     * Сценарий браузера: страница без JS -> ensure -> страница с JS.
     * Проверяем корректность повторного start после stop. */
    long b0 = balance();
    CHECK(brjs_start(&env, &js_stdlib, BR_CFUNC_BASE()) == 0, "re: start");
    brjs_stop(&env);
    CHECK(brjs_start(&env, &js_stdlib, BR_CFUNC_BASE()) == 0, "re: повторный start");
    CHECK(brjs_eval(&env, "1+1", "re") == 0, "re: eval после повтора");
    brjs_stop(&env);
    CHECK(balance() == b0, "re: повторный цикл без утечки");
}

int main(void)
{
    printf("== brmem: жизненный цикл памяти браузерного JS (Task 51) ==\n");

    test_lifecycle();
    test_growth_segments();
    test_oom_clean();
    test_brf_script_buffers();
    test_cycles();
    test_reensure();

    if (failures) {
        printf("ПРОВАЛЕНО проверок: %d\n", failures);
        return 1;
    }
    printf("ВСЕ ПРОВЕРКИ ПРОШЛИ (баланс аллокаций 0, утечек нет)\n");
    return 0;
}
