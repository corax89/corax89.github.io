/* bridge_decls.h — объявления мостовых функций таблицы стдлиба,
 * тела которых живут в ядре в mquickjs_api.c (сгенерировано по
 * члену JSCFunctionType). Тест эти функции НЕ вызывает — ссылки
 * гасятся --unresolved-symbols=ignore-all (становятся нулями). */
#ifndef BRIDGE_DECLS_H
#define BRIDGE_DECLS_H
JSValue js_btn_add(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_btn_clicked(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_btn_set_label(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_clear_screen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_console_log(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_delay(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_draw_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_fill_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_flip(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_free_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_get_color(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_heap_size(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_heap_used(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_draw(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_draw_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_free(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_pixel(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_img_w(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_malloc_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_memcmp_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_memset_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_print_int(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_ramfs_list(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_ramfs_read(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_ramfs_write(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_screen_height(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_screen_width(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_strlen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_uptime(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_alive(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_clear(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_close(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_img(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_img_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_open(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_win_update(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
JSValue js_date_constructor(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
#endif
