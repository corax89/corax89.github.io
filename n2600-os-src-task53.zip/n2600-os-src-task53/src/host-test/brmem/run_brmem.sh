#!/bin/sh
# run_brmem.sh — Task 51 [JS-FREE]: жизненный цикл памяти браузерного JS.
# Схема как в host-test/s55: НАСТОЯЩИЕ исходники копируются в каталог
# харнесса. Мостовые js_*-функции таблицы стдлиба тест не вызывает —
# на линкере они гасятся --unresolved-symbols=ignore-all.
# Использование: ./run_brmem.sh [asan]
set -e
cd "$(dirname "$0")"

SRC=../../src
[ -d "$SRC" ] || { SRC=../../n2600/src; }

for f in mquickjs.c mquickjs.h mquickjs_priv.h mqjs_stdlib_os.h \
         mqjs_stdlib_os64.h brjs.h brform.h types.h; do
    cp $SRC/$f .
done

FLAGS="-std=c99 -g -Wall -Wextra -Wno-unused-parameter -DJS_PTR64"
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address -fno-omit-frame-pointer"
    BIN=brmem_asan
else
    BIN=brmem
fi

# malloc/free -> счётчики; движок и таблицы в ЕДИНОМ TU с тестом,
# чтобы переименование было согласованным во всех включениях.
gcc $FLAGS -Dmalloc=cnt_malloc -Dfree=cnt_free \
    -Wno-unused-function \
    -Wl,--unresolved-symbols=ignore-all \
    brmem_test.c -o $BIN -lm

echo "== Запуск $BIN =="
./$BIN
