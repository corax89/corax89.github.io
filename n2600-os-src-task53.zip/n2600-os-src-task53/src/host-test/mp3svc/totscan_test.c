/* toscan_test.c — хост-тест mp3_total_frames_estimate (сессия 91).
 *
 * Проверяет ТОЧНЫЙ скан заголовков кадров на синтетических потоках:
 *   1) CBR MPEG1 L3 128k/44.1k — 10 кадров = 11520 сэмплов;
 *   2) VBR (320k↔128k) — прежняя CBR-формула врала, скан точен;
 *   3) ID3v2 (30 Б) + кадры + ID3v1 (128 Б) — теги не портят счёт;
 *   4) ложное синхрославо с «плохой» длиной — пропускается, кадры за ним
 *      находятся;
 *   5) MPEG2 L3 64k/22.05k (576 сэмплов/кадр, flen=72000*kbps/sr);
 *   6) чистый мусор — 0.
 * Функция читает только sampleRate + memory.pData/dataSize — структуру
 * drmp3 собираем руками (без декодера). Сам mp3svc.c — НАСТОЯЩИЙ.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mp3svc.h"
#include "dr_mp3.h"

static int failures = 0;

static void put32(u8 *b, u32 v) { b[0]=v>>24; b[1]=v>>16; b[2]=v>>8; b[3]=v; }

/* MPEG1 Layer III заголовок: sync FF FB, bri, sri=0(44100), pad */
static void hdr_m1(u8 *b, int bri, int pad) {
    b[0]=0xFF; b[1]=0xFB; b[2]=(u8)((bri<<4)|(0<<2)|(pad<<1)); b[3]=0x00;
}
/* MPEG2 Layer III: sync FF F3, bri, sri=0(22050), pad */
static void hdr_m2(u8 *b, int bri, int pad) {
    b[0]=0xFF; b[1]=0xF3; b[2]=(u8)((bri<<4)|(0<<2)|(pad<<1)); b[3]=0x00;
}
static u32 flen_m1(int kbps, int pad) { return 144000u*(u32)kbps/44100u + (u32)pad; }
static u32 flen_m2(int kbps, int pad) { return 72000u*(u32)kbps/22050u + (u32)pad; }

static u64 est(const u8 *buf, u32 len) {
    drmp3 m;
    memset(&m, 0, sizeof(m));
    m.sampleRate = 44100;
    m.memory.pData = buf;
    m.memory.dataSize = len;
    return mp3_total_frames_estimate(&m);
}

static void expect(const char *name, u64 got, u64 want) {
    int ok = (got == want);
    printf("%-46s got=%llu want=%llu %s\n", name,
           (unsigned long long)got, (unsigned long long)want,
           ok ? "OK" : "FAIL");
    if (!ok) failures++;
}

int main(void)
{
    /* ---- 1) CBR: 10 кадров 128k/44.1k, flen=417 ---- */
    {
        const int N = 10;
        u32 fl = flen_m1(128, 0);
        static u8 buf[64 * 1024];
        u32 pos = 0;
        for (int i = 0; i < N; i++) {
            hdr_m1(buf + pos, 9, 0);
            for (u32 j = 4; j < fl; j++) buf[pos + j] = 0x55;  /* не синхро */
            pos += fl;
        }
        expect("CBR 10x128k/44.1k", est(buf, pos), (u64)N * 1152u);
    }

    /* ---- 2) VBR: 5x320k + 5x128k, payload с случайными FF ---- */
    {
        static u8 buf[64 * 1024];
        u32 pos = 0;
        for (int i = 0; i < 10; i++) {
            int kbps = (i % 2) ? 128 : 320;
            u32 fl = flen_m1(kbps, 0);
            hdr_m1(buf + pos, kbps == 320 ? 14 : 9, 0);
            for (u32 j = 4; j < fl; j++) buf[pos + j] = (u8)((j & 1) ? 0x55 : 0xFF);
            buf[pos + fl - 1] = 0x55;          /* хвост не синхро */
            pos += fl;
        }
        expect("VBR 5x320k+5x128k/44.1k", est(buf, pos), 10u * 1152u);
    }

    /* ---- 3) ID3v2 (30 Б) + 5 кадров + ID3v1 (128 Б) ---- */
    {
        static u8 buf[64 * 1024];
        u32 pos = 0;
        memcpy(buf, "ID3", 3);
        buf[3] = 3; buf[4] = 0; buf[5] = 0;    /* ver 2.3, флаги 0 (без footer) */
        buf[6] = 0; buf[7] = 0; buf[8] = 0; buf[9] = 20;  /* synchsafe 20 */
        pos = 10 + 20;                          /* = 30 */
        for (int i = 0; i < 5; i++) {
            u32 fl = flen_m1(128, 0);
            hdr_m1(buf + pos, 9, 0);
            memset(buf + pos + 4, 0x33, fl - 4);
            pos += fl;
        }
        memcpy(buf + pos, "TAG", 3);
        memset(buf + pos + 3, 0x20, 125);
        pos += 128;
        expect("ID3v2+5 кадров+ID3v1", est(buf, pos), 5u * 1152u);
    }

    /* ---- 4) ложное синхрославо: FF FB 90 00 с длиной, за которой нет кадра ---- */
    {
        static u8 buf[64 * 1024];
        u32 pos = 0;
        hdr_m1(buf + pos, 9, 0);                /* фальшивый заголовок 128k */
        memset(buf + pos + 4, 'Z', 300);        /* за ним 300 байтов мусора  */
        pos += 304;
        hdr_m1(buf + pos, 9, 0);                /* настоящий одиночный кадр  */
        memset(buf + pos + 4, 0x55, flen_m1(128, 0) - 4);
        pos += flen_m1(128, 0);
        expect("ложный sync + 1 настоящий кадр", est(buf, pos), 1152u);
    }

    /* ---- 5) MPEG2 L3 64k/22.05k pad=1: flen=209, 576 сэмплов/кадр ---- */
    {
        static u8 buf[64 * 1024];
        u32 pos = 0;
        u32 fl = flen_m2(64, 1);
        for (int i = 0; i < 4; i++) {
            hdr_m2(buf + pos, 8, 1);
            memset(buf + pos + 4, 0x77, fl - 4);
            pos += fl;
        }
        expect("MPEG2 4x64k/22.05k", est(buf, pos), 4u * 576u);
    }

    /* ---- 6) чистый мусор ---- */
    {
        static u8 buf[1024];
        memset(buf, 0xAB, sizeof(buf));
        expect("мусор без кадров", est(buf, sizeof(buf)), 0u);
    }

    /* ---- 7) длинный CBR ~5.5 МБ (192k/44.1k, flen=626): скорость/точность ---- */
    {
        const int N = 8800;                    /* 8800*1152 = 10 137 600 сэмплов */
        u32 fl = flen_m1(192, 0);
        u8 *buf = (u8 *)malloc((size_t)fl * N + 16);
        u32 pos = 0;
        for (int i = 0; i < N; i++) {
            hdr_m1(buf + pos, 11, 0);          /* bri=11 -> 192k */
            memset(buf + pos + 4, 0x5A, fl - 4);
            pos += fl;
        }
        expect("CBR 8800x192k (~24 c @44.1k)", est(buf, pos), (u64)N * 1152u);
        free(buf);
    }

    printf(failures ? "\n=== ПРОВАЛОВ: %d ===\n" : "\n=== ВСЕ ТЕСТЫ ПРОШЛИ ===\n",
           failures);
    return failures ? 1 : 0;
}
