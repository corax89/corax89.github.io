#!/bin/sh
# run_flacsvc.sh — хост-тест flacsvc (Task 46): генерация FLAC (ffmpeg),
# эталонный s16le-декод, сборка теста, сверка lossless/формы.
set -e
cd "$(dirname "$0")"
TMP=gen
mkdir -p $TMP

# ---------- генерация тестовых FLAC ----------
# 1) синус 440 Гц + вторая гармоника, 16 бит, стерео 44.1к, 3 с
ffmpeg -v error -y -f lavfi -i "sine=frequency=440:duration=3:sample_rate=44100" \
       -f lavfi -i "sine=frequency=880:duration=3:sample_rate=44100" \
       -filter_complex "[0:a][1:a]amerge=inputs=2,volume=0.6[a]" \
       -map "[a]" -c:a flac -compression_level 8 $TMP/t16.flac
ffmpeg -v error -y -i $TMP/t16.flac -c:a pcm_s16le -f s16le $TMP/t16.ref.raw

# 2) 24 бита (dither при эталонном переводе в 16 — сверяем форму)
ffmpeg -v error -y -f lavfi -i "sine=frequency=330:duration=2:sample_rate=44100" \
       -f lavfi -i "sine=frequency=660:duration=2:sample_rate=44100" \
       -filter_complex "[0:a][1:a]amerge=inputs=2,volume=0.5[a]" \
       -map "[a]" -c:a flac -sample_fmt s32 -compression_level 8 $TMP/t24.flac
ffmpeg -v error -y -i $TMP/t24.flac -c:a pcm_s16le -f s16le $TMP/t24.ref.raw

# 3) 48 кГц стерео (Subset: blocksize 4608 тоже)
ffmpeg -v error -y -f lavfi -i "sine=frequency=1000:duration=2:sample_rate=48000" \
       -f lavfi -i "sine=frequency=2000:duration=2:sample_rate=48000" \
       -filter_complex "[0:a][1:a]amerge=inputs=2,volume=0.5[a]" \
       -map "[a]" -c:a flac -compression_level 8 $TMP/t48.flac
ffmpeg -v error -y -i $TMP/t48.flac -c:a pcm_s16le -f s16le $TMP/t48.ref.raw
# (8-бит FLAC ffmpeg-энкодером не создаётся; ветка bps<16 — зеркальный
#  сдвиг к 24-битному пути, риск минимальный)

# ---------- сборка ----------
gcc -O1 -g -fsanitize=address,undefined -Wall -Wextra \
    -o flacsvc_asan flacsvc_host.c ../../src/flacsvc.c ../../src/foxen-flac.c \
    -lm 2>build_warn.txt
gcc -O2 -Wall -Wextra -o flacsvc_bin flacsvc_host.c \
    ../../src/flacsvc.c ../../src/foxen-flac.c -lm 2>>build_warn.txt
cat build_warn.txt

# ---------- прогон ----------
fail=0
./flacsvc_bin $TMP/t16.flac $TMP/t16.ref.raw 2 || fail=1
./flacsvc_bin $TMP/t24.flac $TMP/t24.ref.raw 2 || fail=1
./flacsvc_bin $TMP/t48.flac $TMP/t48.ref.raw 2 || fail=1
echo "=== ASan/UBSan прогон (16 бит) ==="
ASAN_OPTIONS=detect_leaks=1 ./flacsvc_asan $TMP/t16.flac $TMP/t16.ref.raw 2 || fail=1
exit $fail
