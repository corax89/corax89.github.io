/* flacsvc_host.c — хост-тест обёртки flacsvc + foxen-flac (Task 46).
 *
 * Собирается на хосте с обычным malloc/free (types.h подменён).
 * Сценарии (файл + эталон передаёт скрипт run_flacsvc.sh):
 *   - 16-бит стерео 44.1к: декод ОБЯЗАН совпасть с ffmpeg байт-в-байт
 *     (FLAC lossless, округлений нет);
 *   - 24-бит / 8-бит: ffmpeg дизерит при переводе в s16 — сравниваем
 *     RMS формы (допуск) и долю больших расхождений;
 *   - flac_rewind: повторный декод идентичен первому;
 *   - усечённый файл: read не зацикливается, отдаёт сколько смог;
 *   - мусор: flac_open_mem отвергает. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

/* u8/u32/u64/i16 приходят из src/types.h (через flacsvc.h); uint32_t и
 * пр. из <stdint.h> дают те же типы — отдельных typedef здесь нет. */

#include "../../src/flacsvc.h"

static u8 *fread_all(const char *p, long *out_n) {
    FILE *f = fopen(p, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    if (n <= 0) { fclose(f); return NULL; }
    u8 *b = malloc((size_t)n);
    if (fread(b, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(b); return NULL; }
    fclose(f); *out_n = n; return b;
}

static int failures = 0;
#define CHECK(cond, name) do { \
    if (cond) printf("  OK  %s\n", name); \
    else { printf("  FAIL %s\n", name); failures++; } } while (0)

/* декод целиком в malloc-буфер (interleaved s16) */
static i16 *decode_all(void *ctx, u32 chans, long *out_frames) {
    long cap = 48000 * 10 * (long)chans;
    i16 *pcm = malloc((size_t)cap * sizeof(i16));
    long total = 0;
    u32 got;
    while ((got = flac_read_s16(ctx, pcm + total, 48000)) > 0) {
        total += (long)got * (long)chans;
        if (total + 48000 * (long)chans > cap) {
            cap *= 2;
            i16 *np = realloc(pcm, (size_t)cap * sizeof(i16));
            if (!np) { free(pcm); *out_frames = 0; return NULL; }
            pcm = np;
        }
    }
    *out_frames = chans ? total / (long)chans : 0;
    return pcm;
}

static int run_case(const char *flacpath, const char *refpath, int chans_expect)
{
    printf("== кейс %s (эталон %s) ==\n", flacpath, refpath);
    long n; u8 *data = fread_all(flacpath, &n);
    if (!data) { printf("  FAIL нет файла\n"); failures++; return 1; }
    printf("  файл: %ld байт\n", n);

    void *ctx = flac_open_mem(data, (u32)n);
    CHECK(ctx != NULL, ctx ? "flac_open_mem" : flac_errstr());
    if (!ctx) { free(data); failures++; return 1; }

    u32 ch = flac_channels(ctx), rate = flac_rate(ctx), bps = flac_bps(ctx);
    u64 tot = flac_total_frames(ctx);
    printf("  streaminfo: chans=%u rate=%u bps=%u total=%llu (%.2f c)\n",
           ch, rate, bps, (unsigned long long)tot,
           rate ? (double)tot / rate : 0.0);
    CHECK(ch == (u32)chans_expect, "каналы == ожиданию");
    CHECK(rate > 8000 && rate <= 192000, "частота в разумных пределах");
    CHECK(bps >= 8 && bps <= 32, "битность в пределах");
    CHECK(tot > 0, "STREAMINFO total > 0");

    long frames; i16 *pcm = decode_all(ctx, ch, &frames);
    CHECK(frames > 0, "декод выдал фреймы");
    printf("  декодировано фреймов: %ld (STREAMINFO %llu, дельта %lld)\n",
           frames, (unsigned long long)tot,
           (long long)frames - (long long)tot);
    CHECK((u64)((frames > (long)tot ? frames - (long)tot
                                  : (long)tot - frames)) <= (u64)(rate / 10 + 1),
          "длительность декода == STREAMINFO (+-0.1 c)");

    long rn; u8 *ref = fread_all(refpath, &rn);
    if (ref && frames > 0) {
        long rcnt = rn / 2;
        long ccnt = rcnt < (long)frames * (long)ch ? rcnt
                                                   : (long)frames * (long)ch;
        if (bps == 16) {
            long diff = 0, mx = 0;
            for (long i = 0; i < ccnt; i++) {
                i16 a = pcm[i];
                i16 b = (i16)(ref[2 * i] | (ref[2 * i + 1] << 8));
                long d = a - b; if (d < 0) d = -d;
                if (d > mx) mx = d;
                if (d) diff++;
            }
            printf("  16-бит: различий %ld из %ld, макс |d|=%ld\n",
                   diff, ccnt, mx);
            CHECK(diff == 0, "lossless: 16-бит декод == эталону байт-в-байт");
        } else {
            double s = 0; long big = 0;
            for (long i = 0; i < ccnt; i++) {
                int a = pcm[i];
                int b = (int)((short)(ref[2 * i] | (ref[2 * i + 1] << 8)));
                double d = a - b;
                s += d * d;
                if (d > 512 || d < -512) big++;
            }
            double rms = ccnt ? sqrt(s / (double)ccnt) : 0.0;
            printf("  %u-бит: RMS=%f, расхождений >512: %ld из %ld\n",
                   bps, rms, big, ccnt);
            CHECK(rms < 64.0 && (double)big * 1000.0 < (double)ccnt,
                  "форма совпадает (RMS<64)");
        }
    } else {
        printf("  (эталон не читается — сравнение пропущено)\n");
    }

    if (flac_rewind(ctx)) {
        long f2; i16 *pcm2 = decode_all(ctx, ch, &f2);
        CHECK(f2 == frames &&
              (frames == 0 ||
               memcmp(pcm, pcm2, (size_t)f2 * ch * sizeof(i16)) == 0),
              "rewind: повторный декод идентичен");
        free(pcm2);
    } else CHECK(0, "flac_rewind");

    free(pcm); free(ref);
    flac_close(ctx);

    /* усечённый файл: не зацикливается (ДО free(data) — буфер нужен) */
    {
        long cn = n / 2;
        u8 *cut = malloc((size_t)cn);
        memcpy(cut, data, (size_t)cn);
        void *c2 = flac_open_mem(cut, (u32)cn);
        CHECK(c2 != NULL, "усечённый файл открылся (STREAMINFO цел)");
        if (c2) {
            i16 buf[9600];               /* 4800 стерео-фреймов = 9600 сэмплов */
            u32 g, pass = 0, guard = 0;
            while ((g = flac_read_s16(c2, buf, 4800)) > 0) {
                pass += g;
                if (++guard > 2000) break;
            }
            printf("  усечённый: декодировано %u фреймов, err=\"%s\"\n",
                   pass, flac_errstr());
            CHECK(1, "усечённый: read завершился (guard)");
            flac_close(c2);
        }
        free(cut);
    }

    free(data);

    /* мусор */
    {
        u8 junk[256]; for (int i = 0; i < 256; i++) junk[i] = (u8)(i * 7);
        void *c3 = flac_open_mem(junk, sizeof(junk));
        CHECK(c3 == NULL, "мусор отвергнут");
        if (c3) flac_close(c3);
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 3) {
        fprintf(stderr, "usage: %s <file.flac> <ref_s16le.raw> [chans]\n", argv[0]);
        return 2;
    }
    run_case(argv[1], argv[2], argc > 3 ? atoi(argv[3]) : 2);
    printf("%s\n", failures ? "ЕСТЬ ПРОВАЛЫ" : "ВСЕ ТЕСТЫ ПРОШЛИ");
    return failures ? 1 : 0;
}
