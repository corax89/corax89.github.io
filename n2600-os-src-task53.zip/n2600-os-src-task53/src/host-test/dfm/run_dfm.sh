#!/bin/sh
# run_dfm.sh — хост-тест полноэкранного менеджера dfm (Task 48):
# ASan/UBSan + обычная сборка; заглушка ramfs имитирует плоскую таблицу.
set -e
cd "$(dirname "$0")"
gcc -O1 -g -fsanitize=address,undefined -Wall -Wextra -I../../src \
    -o dfm_asan dfm_host.c ../../src/dfm.c dfm_ramfs_stub.c 2>build_warn.txt
gcc -O2 -Wall -Wextra -I../../src \
    -o dfm_bin dfm_host.c ../../src/dfm.c dfm_ramfs_stub.c 2>>build_warn.txt
rg -v "builtin-declaration-mismatch|mem.h|boot.h|stdlib.h|\^\s*~|\+\+\+|note:" build_warn.txt || true
ASAN_OPTIONS=detect_leaks=1 ./dfm_asan
echo "=== обычная сборка ==="
./dfm_bin
