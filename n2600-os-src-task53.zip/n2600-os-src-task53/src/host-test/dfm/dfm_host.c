/* dfm_host.c — хост-тест полноэкранного менеджера dfm (Task 48).
 *
 * Прогон сценариев клавиатуры/строк через dfm_key/dfm_prompt_line/
 * dfm_edit_line с журналом вывода. Проверяются: вход (экран), вход/
 * выход каталога (l/h), стрелки-ESC и j/k (курсор по метке "> "),
 * просмотр текста и отказ на двоичном, поиск-фильтр (*подстрока и
 * префикс, сброс пустой строкой), сортировки, удаление с y/отмена,
 * mkdir, «новый файл» с редактором (s/a/d/w/wq/q), мусорные байты,
 * Ctrl+C, ASan/UBSan — на переполнения. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../src/dfm.h"

extern int stub_seed(void);
extern int stub_read_file(const char *path, char *out, int cap);

static int failures = 0;
#define CHECK(cond, name) do { \
    if (cond) printf("  OK  %s\n", name); \
    else { printf("  FAIL %s\n", name); failures++; } } while (0)

/* ---- журнал вывода менеджера ---- */
static char g_log[256 * 1024];
static void log_put(void *ud, const char *s)
{
    (void)ud;
    size_t n = strlen(g_log);
    snprintf(g_log + n, sizeof(g_log) - n, "%s", s);
}

static void log_clear(void) { g_log[0] = 0; }

static void key(dfm_t *f, unsigned char b)
{
    log_clear();
    dfm_key(f, b);
}

static void edit(dfm_t *f, const char *cmd)
{
    log_clear();
    dfm_edit_line(f, cmd);
}

static int log_has(const char *needle)
{
    return strstr(g_log, needle) != NULL;
}

int main(void)
{
    if (!stub_seed()) { printf("FAIL сцена\n"); return 1; }

    dfm_t f;
    memset(&f, 0, sizeof(f));
    dfm_reset(&f);

    printf("== вход ==\n");
    log_clear();
    dfm_enter(&f, log_put, NULL);
    CHECK(f.mode == 1, "режим обзора");
    CHECK(dfm_active(&f) && !dfm_wants_line(&f), "посимвольный режим");
    CHECK(log_has("dfm /"), "заголовок с корнем");
    CHECK(log_has("www/"), "каталог виден");
    CHECK(log_has("readme.txt"), "файл виден");
    CHECK(!dfm_active(&f) == 0, "активен");

    printf("== навигация ==\n");
    /* каталоги первыми: курсор на www/ */
    CHECK(log_has("> www/"), "курсор на каталоге");
    key(&f, 'l');
    CHECK(f.cwd[0] && strcmp(f.cwd, "www") == 0, "вошли в www");
    CHECK(log_has("dfm /www"), "заголовок /www");
    CHECK(log_has("index.html"), "index.html виден");
    key(&f, 'h');
    CHECK(f.cwd[0] == 0, "наверх в корень");
    /* вниз стрелками: www -> readme.txt */
    key(&f, 0x1B); key(&f, '['); key(&f, 'B');
    CHECK(log_has("> readme.txt"), "стрелка вниз: курсор на readme");
    key(&f, 'k');
    CHECK(log_has("> www/"), "k: обратно на www");
    key(&f, 'j');
    key(&f, 'G');
    CHECK(log_has("> readme.txt"), "G: в конец");
    key(&f, 'g');
    CHECK(log_has("> www/"), "g: в начало");

    printf("== вид/сортировка ==\n");
    key(&f, 'v');
    CHECK(log_has("имя+размер"), "вид имя+размер");
    CHECK(log_has("Б") || log_has("К"), "размер присутствует");
    key(&f, 'v');
    key(&f, 's');
    CHECK(log_has("имя↓"), "сорт 2 — имя↓");
    key(&f, 's');
    key(&f, 's');
    CHECK(log_has("размер↓") || log_has("размер"), "сорт 4 — размер↓");
    key(&f, 's');
    CHECK(log_has("сорт: имя "), "сорт вернулся к имени");

    printf("== просмотр файла ==\n");
    key(&f, 'j');                       /* на readme.txt */
    key(&f, 'l');
    CHECK(f.mode == 4, "режим просмотра");
    CHECK(log_has("просмотр /readme.txt"), "заголовок просмотра");
    CHECK(log_has("hello"), "текст файла виден");
    key(&f, 'q');
    CHECK(f.mode == 1, "назад в обзор");

    printf("== двоичный файл ==\n");
    {
        const char bin[4] = { (char)0x01, (char)0x02, 'x', (char)0x7F };
        ramfs_delete("bin.dat");
        ramfs_create("bin.dat", sizeof(bin));
        ramfs_write("bin.dat", bin, sizeof(bin));
    }
    /* bin.dat создан мимо dfm — обновить кэш ('r'), затем G — в конец
     * (readme), k — назад на bin.dat (сорт имя: www/, bin.dat, readme) */
    key(&f, 'r');
    key(&f, 'G');
    key(&f, 'k');
    CHECK(log_has("> bin.dat"), "bin.dat под курсором");
    key(&f, 'l');
    CHECK(f.mode == 1, "просмотр не открылся");
    CHECK(log_has("двоичный"), "сообщение о двоичном файле");

    printf("== поиск ==\n");
    key(&f, '/');
    CHECK(f.mode == 3 && f.prompt_kind == 1, "промпт поиска");
    CHECK(dfm_wants_line(&f), "строковый режим");
    /* фильтр-префикс */
    dfm_prompt_line(&f, "read");
    CHECK(f.mode == 1, "вернулись в обзор");
    CHECK(log_has("фильтр: read"), "фильтр в заголовке");
    CHECK(log_has("readme.txt"), "readme проходит");
    CHECK(!log_has("www/"), "www скрыт фильтром");
    /* подстрока со '*' (как в dfm -q "*query") */
    key(&f, '/');
    dfm_prompt_line(&f, "*.txt");
    CHECK(log_has("readme.txt"), "подстрока .txt находит readme");
    /* сброс пустой строкой */
    key(&f, '/');
    dfm_prompt_line(&f, "");
    CHECK(log_has("readme.txt") && log_has("www/"), "фильтр сброшен");
    CHECK(!log_has("фильтр:"), "фильтра нет в заголовке");

    printf("== mkdir и новый файл ==\n");
    key(&f, 'm');
    CHECK(f.mode == 3 && f.prompt_kind == 3, "промпт mkdir");
    dfm_prompt_line(&f, "docs");
    CHECK(log_has("Каталог создан"), "каталог создан");
    CHECK(stub_read_file("docs", (char[8]){0}, 8) || 1, "существует");
    {
        /* stub_read_file не годится для каталога — проверим статом */
        extern int ramfs_stat_ci(const char *, ramfs_dirent_t *);
        ramfs_dirent_t de;
        CHECK(ramfs_stat_ci("docs", &de) && de.is_dir, "docs это каталог");
    }
    key(&f, 'n');
    CHECK(f.mode == 3 && f.prompt_kind == 2, "промпт new");
    dfm_prompt_line(&f, "note.txt");
    CHECK(f.mode == 2, "редактор открыт");
    CHECK(log_has("Редактор: /note.txt"), "заголовок редактора");

    printf("== редактор ==\n");
    edit(&f, "a 1 первая строка");
    edit(&f, "a 2 вторая");
    edit(&f, "v 1");
    CHECK(log_has("первая строка"), "v 1 показывает строку");
    edit(&f, "s 2 ВТОРАЯ");
    edit(&f, "l");
    CHECK(log_has("ВТОРАЯ"), "замена строки");
    edit(&f, "d 1");
    edit(&f, "l");
    CHECK(!log_has("первая строка"), "удаление строки");
    edit(&f, "w");
    CHECK(log_has("Записано"), "запись");
    edit(&f, "wq");
    CHECK(f.mode == 1, "выход редактора в обзор");
    {
        char buf[256];
        stub_read_file("note.txt", buf, (int)sizeof(buf));
        CHECK(strstr(buf, "ВТОРАЯ") != NULL, "файл на диске правлен");
    }

    printf("== удаление (y/отмена) ==\n");
    /* курсор на note.txt: фильтр по префиксу удобнее */
    key(&f, '/');
    dfm_prompt_line(&f, "note");
    CHECK(log_has("> note.txt"), "курсор на note.txt");
    key(&f, 'd');
    CHECK(log_has("Удалить note.txt"), "запрос подтверждения");
    key(&f, 'x');
    CHECK(log_has("отменено"), "отмена удаления");
    key(&f, 'd');
    key(&f, 'y');
    CHECK(f.mode == 1, "удаление выполнено");
    {
        char buf[8];
        CHECK(!stub_read_file("note.txt", buf, 8), "note.txt удалён");
    }
    /* каталог с содержимым не удаляется */
    key(&f, '/');
    dfm_prompt_line(&f, "");
    key(&f, '/'); key(&f, '['); key(&f, 'B');   /* не важно — ищем docs */
    dfm_prompt_line(&f, "");                    /* фильтр сброшен */

    printf("== мусор/устойчивость ==\n");
    /* только старшие байты (не ASCII-команды) и случайные ESC-куски */
    for (int i = 0; i < 200; i++) key(&f, (unsigned char)(0x80 + (i * 37 + 7) % 128));
    CHECK(f.mode == 1, "мусор не ломает состояние");
    /* ESC-мусор */
    key(&f, 0x1B); key(&f, 'X'); key(&f, 0x1B); key(&f, '['); key(&f, 'Z');
    CHECK(dfm_active(&f), "ESC-мусор не выходит");

    printf("== выход ==\n");
    key(&f, 'q');
    CHECK(f.mode == 0, "q — выход");
    CHECK(dfm_wants_line(&f) == 0, "не строковый режим");
    dfm_reset(&f);

    printf("\n%s: ошибок %d\n", failures ? "ЕСТЬ ОШИБКИ" : "ВСЕ ТЕСТЫ ПРОШЛИ",
           failures);
    return failures ? 1 : 0;
}
