/* tfm_ramfs_stub.c — фальшивый ramfs для хост-теста tfm (Task 46).
 *
 * Минимальная реализация используемого tfm.c подмножества API ramfs.h:
 * плоская таблица полных путей (как в настоящем ramfs), heap-буферы.
 * Без блокировок/задач — тест однопоточный. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../src/ramfs.h"

#define STUB_MAX 64
#define STUB_DATA (128 * 1024)

typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    u32  size;
    u32  off;
    u8   is_dir;
    int  used;
} stub_ent_t;

static stub_ent_t ents[STUB_MAX];
static u8 databuf[STUB_DATA];
static u32 data_used = 0;

static void ci_copy(char *dst, const char *src)
{
    size_t n = strlen(src);
    if (n > RAMFS_NAME_MAX) n = RAMFS_NAME_MAX;
    for (size_t i = 0; i < n; i++)
        dst[i] = (src[i] >= 'A' && src[i] <= 'Z') ? (char)(src[i] + 32) : src[i];
    dst[n] = 0;
}

static stub_ent_t *stub_find(const char *name)
{
    char a[RAMFS_NAME_MAX + 1], b[RAMFS_NAME_MAX + 1];
    ci_copy(b, name);
    for (int i = 0; i < STUB_MAX; i++) {
        if (!ents[i].used) continue;
        ci_copy(a, ents[i].name);
        if (!strcmp(a, b)) return &ents[i];
    }
    return NULL;
}

int ramfs_ready(void) { return 1; }

int ramfs_create(const char *name, u32 size)
{
    if (stub_find(name)) return 0;
    for (int i = 0; i < STUB_MAX; i++) {
        if (ents[i].used) continue;
        if (data_used + size > STUB_DATA) return 0;
        snprintf(ents[i].name, sizeof(ents[i].name), "%s", name);
        ents[i].size = size;
        ents[i].off = data_used;
        ents[i].is_dir = 0;
        ents[i].used = 1;
        data_used += size;
        memset(databuf + ents[i].off, 0, size);
        return 1;
    }
    return 0;
}

int ramfs_write(const char *name, const void *buf, u32 size)
{
    stub_ent_t *e = stub_find(name);
    if (!e || e->is_dir) return 0;
    if (size > e->size) return 0;
    memcpy(databuf + e->off, buf, size);
    e->size = size;             /* как в реальном ramfs: размер по факту */
    return 1;
}

u32 ramfs_read(const char *name, void *buf, u32 max)
{
    stub_ent_t *e = stub_find(name);
    if (!e || e->is_dir) return 0;
    u32 n = e->size < max ? e->size : max;
    memcpy(buf, databuf + e->off, n);
    return n;
}

int ramfs_delete(const char *name)
{
    stub_ent_t *e = stub_find(name);
    if (!e) return 0;
    /* как в настоящем ramfs: каталог только ПУСТОЙ */
    if (e->is_dir) {
        char pre[RAMFS_NAME_MAX + 2];
        snprintf(pre, sizeof(pre), "%s/", e->name);
        u32 plen = strlen(pre);
        for (int i = 0; i < STUB_MAX; i++) {
            if (!ents[i].used || i == (int)(e - ents)) continue;
            if (strncmp(ents[i].name, pre, plen) == 0) return 0;
        }
    }
    e->used = 0;
    return 1;
}

int ramfs_mkdir(const char *path)
{
    if (stub_find(path)) return 0;
    /* родитель должен существовать (упрощённо: корень есть всегда) */
    char parent[RAMFS_NAME_MAX + 1];
    snprintf(parent, sizeof(parent), "%s", path);
    char *sl = strrchr(parent, '/');
    if (sl) {
        *sl = 0;
        if (!stub_find(parent)) return 0;
    }
    for (int i = 0; i < STUB_MAX; i++) {
        if (ents[i].used) continue;
        snprintf(ents[i].name, sizeof(ents[i].name), "%s", path);
        ents[i].size = 0;
        ents[i].is_dir = 1;
        ents[i].used = 1;
        return 1;
    }
    return 0;
}

int ramfs_list_dir(const char *dir, ramfs_dirent_t *out, int max)
{
    char pre[RAMFS_NAME_MAX + 2];
    u32 n = (u32)strlen(dir);
    if (n == 0 || (n == 1 && dir[0] == '/')) pre[0] = 0;
    else {
        if (dir[0] == '/') { dir++; n--; }
        memcpy(pre, dir, n);
        if (n && pre[n - 1] != '/') { pre[n] = '/'; pre[n + 1] = 0; }
        else pre[n] = 0;
    }
    u32 plen = strlen(pre);
    int count = 0;
    for (int i = 0; i < STUB_MAX && count < max; i++) {
        if (!ents[i].used) continue;
        if (plen && strncmp(ents[i].name, pre, plen) != 0) continue;
        const char *rest = ents[i].name + plen;
        if (strchr(rest, '/')) continue;
        if (!rest[0]) continue;
        snprintf(out[count].name, sizeof(out[count].name), "%s", rest);
        out[count].size = ents[i].size;
        out[count].is_dir = ents[i].is_dir;
        out[count].offset = ents[i].off;
        count++;
    }
    return count;
}

int ramfs_stat_ci(const char *name, ramfs_dirent_t *out)
{
    stub_ent_t *e = stub_find(name);
    if (!e) return 0;
    if (out) {
        snprintf(out->name, sizeof(out->name), "%s", e->name);
        out->size = e->size;
        out->is_dir = e->is_dir;
        out->offset = e->off;
    }
    return 1;
}

u32 ramfs_free_space(void)  { return STUB_DATA - data_used; }
u32 ramfs_total_space(void) { return STUB_DATA; }
int ramfs_file_count(void)
{
    int n = 0;
    for (int i = 0; i < STUB_MAX; i++) n += ents[i].used;
    return n;
}

/* ---------- помощники теста ---------- */

/* сцена: www/index.html + readme.txt; 1 = ок */
int stub_seed(void)
{
    memset(ents, 0, sizeof(ents));
    memset(databuf, 0, sizeof(databuf));
    data_used = 0;
    if (!ramfs_mkdir("www")) return 0;
    if (!ramfs_create("www/index.html", 64)) return 0;
    const char *idx = "<h1>N2600-OS</h1>\nwelcome\n";
    if (!ramfs_write("www/index.html", idx, (u32)strlen(idx))) return 0;
    if (!ramfs_create("readme.txt", 32)) return 0;
    if (!ramfs_write("readme.txt", "hello\n", 6)) return 0;
    return 1;
}

/* прочитать файл напрямую мимо tfm (для сверки записи) */
int stub_read_file(const char *path, char *out, int cap)
{
    u32 n = ramfs_read(path, out, (u32)(cap - 1));
    out[n] = 0;
    return n > 0 || stub_find(path) != NULL;
}

/* записать сырой текст (создав файл) — для сценария «хвост без \n» */
int stub_write_raw(const char *path, const char *data)
{
    ramfs_delete(path);
    if (!ramfs_create(path, (u32)strlen(data))) return 0;
    return ramfs_write(path, data, (u32)strlen(data));
}
