/* Хост-тест алгоритма окклюзии (Task 53, [WM-OCC]) — копия логики
 * win_fully_occluded из wm.c с массивом «окон»-прямоугольников.
 * Проверяем: одиночное накрытие, комбинированное (2 окна), частичное,
 * tall-narrow dirty (регрессия rx1->ry1), отсутствие пересечения,
 * переполнение списка кусков. */
#include <stdio.h>

typedef struct { int x, y, w, h; int minimized, ready; } win_t;

static win_t wins[16];
static int nwin;

#define WM_OCC_MAX 16
static int win_fully_occluded(win_t *w, int from_idx,
                              int rx0, int ry0, int rx1, int ry1)
{
    int wx0 = (w->x > rx0) ? w->x : rx0;
    int wy0 = (w->y > ry0) ? w->y : ry0;
    int wx1 = (w->x + w->w - 1 < rx1) ? w->x + w->w - 1 : rx1;
    int wy1 = (w->y + w->h - 1 < ry1) ? w->y + w->h - 1 : ry1;
    if (wx0 > wx1 || wy0 > wy1) return 1;

    int qx0[WM_OCC_MAX], qy0[WM_OCC_MAX], qx1[WM_OCC_MAX], qy1[WM_OCC_MAX];
    int nq = 0;
    qx0[nq] = wx0; qy0[nq] = wy0; qx1[nq] = wx1; qy1[nq] = wy1; nq++;

    for (int j = from_idx; j < nwin && nq > 0; j++) {
        win_t *v = &wins[j];
        if (v->minimized || !v->ready) continue;
        int vx1 = v->x + v->w - 1, vy1 = v->y + v->h - 1;
        int n = nq;
        nq = 0;
        for (int k = 0; k < n; k++) {
            int ax0 = qx0[k], ay0 = qy0[k], ax1 = qx1[k], ay1 = qy1[k];
            if (v->x > ax1 || vx1 < ax0 || v->y > ay1 || vy1 < ay0) {
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = ay0; qx1[nq] = ax1; qy1[nq] = ay1; nq++;
                continue;
            }
            int ly0 = (v->y > ay0) ? v->y : ay0;
            int ly1 = (vy1 < ay1) ? vy1 : ay1;
            if (v->y > ay0) {
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = ay0; qx1[nq] = ax1; qy1[nq] = v->y - 1; nq++;
            }
            if (vy1 < ay1) {
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = vy1 + 1; qx1[nq] = ax1; qy1[nq] = ay1; nq++;
            }
            if (v->x > ax0) {
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = ax0; qy0[nq] = ly0; qx1[nq] = v->x - 1; qy1[nq] = ly1; nq++;
            }
            if (vx1 < ax1) {
                if (nq >= WM_OCC_MAX) return 0;
                qx0[nq] = vx1 + 1; qy0[nq] = ly0; qx1[nq] = ax1; qy1[nq] = ly1; nq++;
            }
        }
    }
    return (nq == 0);
}

static int fails = 0;
static void check(const char *name, int got, int want)
{
    if (got != want) { printf("FAIL %s: got %d want %d\n", name, got, want); fails++; }
    else printf("ok   %s\n", name);
}

int main(void)
{
    /* [1] одно верхнее окно накрывает целиком */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };      /* w */
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };      /* v накрывает */
    check("одно окно накрывает", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 1);

    /* [2] частичное перекрытие — не отсекаем */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 100, 50, 0, 1 };
    check("частичное — видимо", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 0);

    /* [3] два окна накрывают ПОЛОВИНАМИ (старый код не отсекал) */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 100, 50, 0, 1 };
    wins[nwin++] = (win_t){ 0, 50, 100, 50, 0, 1 };
    check("двумя окнами", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 1);

    /* [4] dirty шире окна по Y: накрытие в пределах dirty достаточно */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 800, 600, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 800, 600, 0, 1 };
    check("dirty-полоса vs полное окно", win_fully_occluded(&wins[0], 1, 0, 0, 799, 99), 1);

    /* [5] tall-narrow dirty: v накрывает только верх 50 строк — окно
     * обязано остаться видимым (проверка регрессии rx1/ry1) */
    nwin = 0;
    wins[nwin++] = (win_t){ 40, 0, 21, 600, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 800, 50, 0, 1 };
    check("tall-narrow: v сверху — видимо", win_fully_occluded(&wins[0], 1, 45, 0, 55, 599), 0);

    /* [6] dirty вне окна — пусто (нечего рисовать) */
    nwin = 0;
    wins[nwin++] = (win_t){ 100, 100, 50, 50, 0, 1 };
    check("dirty вне окна", win_fully_occluded(&wins[0], 1, 0, 0, 50, 50), 1);

    /* [7] накрывающее окно свёрнуто — не накрывает */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 1, 1 };
    check("свёрнутое не накрывает", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 0);

    /* [8] накрывающее не готово (canvas не отрисован) — не накрывает */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 0 };
    check("не готовое не накрывает", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 0);

    /* [9] каскад: v накрыт u сверху — пиксели всё равно нарисует u */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };      /* w */
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };      /* v (накрывает w) */
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };      /* u (накрывает v) */
    check("каскад трёх окон", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 1);

    /* [10] перекрытие крестом: 4 окна по бокам, центр открыт — видимо */
    nwin = 0;
    wins[nwin++] = (win_t){ 40, 40, 20, 20, 0, 1 };      /* w */
    wins[nwin++] = (win_t){ 0, 40, 40, 20, 0, 1 };       /* слева */
    wins[nwin++] = (win_t){ 60, 40, 40, 20, 0, 1 };      /* справа */
    check("крест: центр открыт", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 0);

    /* [11] накрытие 4 окнами с ПЕРЕКРЫТИЕМ краёв w (каждое режет кусок):
     * верх (y 0..44), низ (y 55..99), лево широкий (x 0..49), право */
    nwin = 0;
    wins[nwin++] = (win_t){ 40, 40, 20, 20, 0, 1 };      /* w: 40..59 x 40..59 */
    wins[nwin++] = (win_t){ 40, 0, 20, 45, 0, 1 };       /* верх: y 0..44 */
    wins[nwin++] = (win_t){ 40, 55, 20, 45, 0, 1 };      /* низ: y 55..99 */
    wins[nwin++] = (win_t){ 0, 40, 50, 20, 0, 1 };       /* лево: x 0..49 */
    wins[nwin++] = (win_t){ 50, 40, 50, 20, 0, 1 };      /* право: x 50..99 */
    check("4 окна с перекрытием закрывают w", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 1);

    /* [12] шахматное накрытие 4 четвертями */
    nwin = 0;
    wins[nwin++] = (win_t){ 0, 0, 100, 100, 0, 1 };
    wins[nwin++] = (win_t){ 0, 0, 50, 50, 0, 1 };
    wins[nwin++] = (win_t){ 50, 0, 50, 50, 0, 1 };
    wins[nwin++] = (win_t){ 0, 50, 50, 50, 0, 1 };
    wins[nwin++] = (win_t){ 50, 50, 50, 50, 0, 1 };
    check("4 четверти", win_fully_occluded(&wins[0], 1, 0, 0, 799, 599), 1);

    printf(fails ? "\nЕСТЬ ПРОВАЛЫ: %d\n" : "\nВСЕ ПРОВЕРКИ ПРОШЛИ (%d провалов)\n", fails);
    return fails ? 1 : 0;
}
