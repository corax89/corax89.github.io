#!/bin/sh
# run_occ.sh — хост-тест алгоритма окклюзии композитора (Task 53 [WM-OCC]).
# Логика win_fully_occluded (wm.c) скопирована в occ_host.c 1:1 (без fb/z);
# при правке wm.c обновить копию. Запуск: ./run_occ.sh
set -e
cd "$(dirname "$0")"
gcc -O2 -Wall -Wextra -o occ_host occ_host.c
./occ_host
