/* rtlwifi_test.c — хост-тест драйвера RTL8192EU N2600-OS.
 *
 * Компилирует НАСТОЯЩИЕ src/rtl8192eu.c + src/wifi_core.c + src/wpa2.c
 * против СИМУЛЯТОРА USB-устройства RTL8192EU (usb_ehci_ctrl_xfer/
 * usb_ehci_bulk_xfer — заглушки уровня EHCI). Проверяет:
 *   1. attach: VID/PID 0bda:818b, разбор bulk-эндпоинтов;
 *   2. probe: полный bring-up, загрузка прошивки БАЙТ-В-БАЙТ (страницы
 *      в 0x1000 через vendor writeN = встроенный rtl8192eu_fw_data),
 *      запуск 8051 (MCU_WINT_INIT_READY), MAC из efuse;
 *   3. скан: смены каналов (RF 0x18), beacon -> список AP (SSID/защита);
 *      список ПЕРЕЖИВАЕТ повторный скан (регрессия «поиск заново»);
 *   4. подключение WPA2: AUTH REQ -> AUTH resp -> ASSOC REQ (SSID+RSN IE)
 *      -> ASSOC resp -> M1 -> M2 (MIC по PTK) -> M3 -> CONNECTED + CAM
 *      (PTK idx0 с TA=BSSID, GTK keyid) + M4;
 *   5. данные: wifi_net_send -> TX data кадр (ToDS+Protected, LLC/SNAP,
 *      BSSID/DA), RX data кадр -> wifi_net_recv Ethernet-кадр;
 *   6. дескриптор TX: чексумма (XOR 16 слов = 0), queue_sel (MGNT/BE),
 *      OWN/FIRST/LAST, pkt_offset=40;
 *   7. профиль: wifi_profile_save/load через RAM-заглушку ramfs.
 *
 * Сборка: run_rtlwifi.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "types.h"
#include "wifi_core.h"
#include "usb_ehci.h"
#include "wpa2.h"

/* ============ счётчики/проверки ============ */
static int fails, checks;
#define CHECK(cond, name) do { \
    checks++; if (cond) { printf("  ok  %s\n", name); } \
    else { fails++; printf("  FAIL %s (%s:%d)\n", name, __FILE__, __LINE__); } \
} while (0)

/* ============ симулятор устройства ============ */

/* vendor-регистры: байтовый файл 64 КиБ */
static u8 sim_regs[65536];
/* прошивка, записанная в RAM чипа (0x1000..) */
static u8 sim_fw_ram[65536];
static int sim_fw_written;
static int sim_fw_pages_mark;      /* содержимое REG_MCU_FW_DL+2 (page idx) */
static int sim_mcu_started;
static int sim_8051_reset_count;
static int sim_llt_done;
static u8 sim_rf_last_reg[2];
static u32 sim_cam_pending;
static int sim_fw_dl_active;
/* RF-регистры (2 пути) */
static u32 sim_rf[2][64];
/* efuse-карта (512 байт) */
static u8 sim_efuse[512];
/* CAM: 8 ячеек по 6 слов */
static u32 sim_cam[8][6];
static int sim_cam_writes;
/* TX-захваты */
#define TXCAP_MAX 64
static struct {
    int ep; int len;
    u8 desc[40];
    u8 frame[1600];
} sim_tx[TXCAP_MAX];
static int sim_tx_n;
/* очередь RX (кадры, которые «принял чип») */
#define RXQ_MAX 32
static u8 sim_rxq[RXQ_MAX][2048];
static int sim_rx_len[RXQ_MAX];
static int sim_rx_head, sim_rx_count;

/* константы, симулятору нужные */
#define S_REG_MCU_FW_DL     0x0080
#define S_REG_MCU_FW_DL_C   0x0082
#define S_REG_SYS_CFG       0x00F0
#define S_REG_HPON_FSM      0x00E0
#define S_REG_EFUSE_CTRL    0x0030   /* REG_EFUSE_CTRL реальный = 0x30 */
#define S_REG_EFUSE_ACCESS  0x0043
#define S_REG_AUTO_LLT      0x0224
#define S_REG_APS_FSMCO     0x0004
#define S_FW_BASE           0x1000
#define S_RF_MODE_AG        0x18

static const u8 sim_mac[6] = { 0x48, 0x5b, 0x39, 0x22, 0x33, 0x44 };
static const u8 sim_bssid[6] = { 0xc0, 0x25, 0xe9, 0x11, 0x22, 0x33 };
/* изменяемая копия: тест СЕССИИ 32 подключается к ДРУГОЙ точке (другой
 * BSSID — иначе парсер обновит запись HomeNet, а не создаст новую) */
static u8 cur_bssid[6];
static const char *sim_ssid = "HomeNet";
#define SIM_CHANNEL 6
#define SIM_PASS    "password123"

static u8 g_rx_eth_dst[6], g_rx_eth_src[6];

static void sim_reset(void) {
    memset(sim_regs, 0, sizeof(sim_regs));
    memset(sim_fw_ram, 0, sizeof(sim_fw_ram));
    memset(sim_rf, 0, sizeof(sim_rf));
    memset(sim_cam, 0, sizeof(sim_cam));
    memset(sim_efuse, 0xff, sizeof(sim_efuse));
    sim_tx_n = 0; sim_rx_head = 0; sim_rx_count = 0;
    sim_fw_written = 0; sim_fw_pages_mark = 0;
    sim_mcu_started = 0; sim_8051_reset_count = 0; sim_llt_done = 0;
    sim_fw_dl_active = 0; sim_rf_last_reg[0] = sim_rf_last_reg[1] = 0;
    sim_cam_pending = 0;
    sim_cam_writes = 0;

    /* SYS_CFG: версия 5 в битах 12-15, не тестовый, SPS_LDO_SEL=0 */
    sim_regs[S_REG_SYS_CFG + 0] = 0x25;
    sim_regs[S_REG_SYS_CFG + 1] = 0x50;   /* bit12 = версия (5<<12 = 0x5000) */
    /* HPON_FSM: bonding != 1T2R -> 8192EU (2T) */
    /* efuse-карта: rtl_id=0x8129 @0, tx power @0x10/0x3a, xtal @0xb9,
     * MAC @0xd7 */
    /* сырой поток efuse: 8-байтовые юниты карты; юнит >= 16 кодируется
     * расширенным заголовком (как в rtl8xxxu_read_efuse) */
    {
        int p = 0;
        u8 unit0[8]  = { 0x29, 0x81, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
        u8 unit26[8] = { 0, 0, 0, 0, 0, 0, 0, sim_mac[0] };
        u8 unit27[8] = { sim_mac[1], sim_mac[2], sim_mac[3],
                         sim_mac[4], sim_mac[5], 0xff, 0xff, 0xff };
        const u8 *units[3] = { unit0, unit26, unit27 };
        const int unitno[3] = { 0, 26, 27 };
        for (int u = 0; u < 3; u++) {
            sim_efuse[p++] = (u8)(0x0f | ((unitno[u] & 7) << 5));
            sim_efuse[p++] = (u8)(((unitno[u] & 0x18) << 1) | 0x00);
            memcpy(sim_efuse + p, units[u], 8);
            p += 8;
        }
    }
    /* EAPOL/данные от точки: eth dst = мы, src = AP (по умолчанию) */
    memcpy(g_rx_eth_dst, sim_mac, 6);
    memcpy(g_rx_eth_src, sim_bssid, 6);
}

/* --- efuse-чтение через REG_EFUSE_CTRL (бит 31 = готово, данные в байте 0) */
static void sim_efuse_trigger(u16 offset) {
    if (offset < 40) printf("    dbg: efuse_trigger off=%d data=%02x\n",
                            offset, sim_efuse[offset & 511]);
    /* хост little-endian: пишем данные в байты 0..3 регистра */
    /* ВАЖНО: байт0 = данные, бит31 (байт3) = готово; байты 1-2 (адрес)
     * НЕ трогаем — как на железе */
    sim_regs[S_REG_EFUSE_CTRL + 0] = sim_efuse[offset & 511];
    sim_regs[S_REG_EFUSE_CTRL + 3] |= 0x80;
}

/* vendor control (заглушка usb_ehci.c) */
int usb_ehci_ctrl_xfer(int addr, u8 bmReqType, u8 bReq,
                       u16 wValue, u16 wIndex, void *data, int len, int data_in) {
    (void)addr; (void)wIndex; (void)bReq;
    if (data_in) {
        /* чтение регистра: bmReqType 0xC5 */
        u16 a = wValue;
        if (a == S_REG_EFUSE_CTRL) {
            sim_efuse_trigger((u16)(sim_regs[S_REG_EFUSE_CTRL + 1] |
                                    ((sim_regs[S_REG_EFUSE_CTRL + 2] & 3) << 8)));
        }
        /* RF readback: LSSI_READBACK XA(0x8a0)/XB(0x8a4) — последнее
         * значение RF-регистра пути (упрощённая модель HSSI);
         * пишем в sim_regs — общий memcpy ниже отдаст значение */
        if (a == 0x08a0 || a == 0x08a4 || a == 0x08b8 || a == 0x08bc) {
            int rpath = (a == 0x08a0 || a == 0x08b8) ? 0 : 1;
            u32 v = sim_rf[rpath][sim_rf_last_reg[rpath] & 63];
            memcpy(sim_regs + a, &v, 4);
        }
        memset(data, 0, (size_t)len);
        memcpy(data, sim_regs + a, (size_t)len);
        /* спец-поведения регистров при чтении */
        if (a == S_REG_MCU_FW_DL) {
            u32 v;
            memcpy(&v, data, 4);
            if (sim_mcu_started) v |= 0x40;         /* MCU_WINT_INIT_READY */
            else if (sim_fw_written > 0) v |= 0x04; /* CSUM_REPORT после записи */
            memcpy(data, &v, 4);
        }
        if (a == S_REG_AUTO_LLT && sim_llt_done) {
            u32 v; memcpy(&v, data, 4); v &= ~0x10000u; memcpy(data, &v, 4);
        }
        if (a == S_REG_APS_FSMCO) {
            u32 v; memcpy(&v, data, 4);
            v |= 0x20000;                 /* PFM_READY (bit 17) всегда */
            if (v & 0x100) v &= ~0x100u;  /* MAC_ENABLE (bit 8) самосбрасывается */
            memcpy(data, &v, 4);
        }
        return len;
    }
    /* запись */
    u16 a = wValue;
    if (a == S_REG_MCU_FW_DL) {
        u32 v; memcpy(&v, data, 4);
        sim_fw_dl_active = (v & 1) != 0;    /* MCU_FW_DL_ENABLE */
    }
    if (a == S_REG_MCU_FW_DL + 2) {
        /* выбор страницы прошивки (0x82 = page idx, биты 0-2) */
        sim_fw_pages_mark = data ? ((u8 *)data)[0] & 7 : 0;
    }
    if (a >= S_FW_BASE && sim_fw_dl_active) {
        /* прошивка: vendor writeN блоками; страница выбирается 0x82 */
        u32 dst = (u32)sim_fw_pages_mark * 4096u + (a - S_FW_BASE);
        if (dst + (u32)len <= sizeof(sim_fw_ram))
            memcpy(sim_fw_ram + dst, data, (size_t)len);
        if ((int)(dst + (u32)len) > sim_fw_written)
            sim_fw_written = (int)(dst + (u32)len);
        return len;
    }
    if (len == 1) sim_regs[a] = ((u8 *)data)[0];
    else if (len == 2) {
        u16 v; memcpy(&v, data, 2);
        sim_regs[a] = (u8)(v & 0xff); sim_regs[a + 1] = (u8)(v >> 8);
    } else if (len == 4) {
        memcpy(sim_regs + a, data, 4);
    }
    /* спец-поведения при записи */
    if (a == S_REG_MCU_FW_DL) {
        u32 v; memcpy(&v, data, 4);
        /* MCU_FW_DL_READY (bit1) при снятом INIT_READY (bit6) — команда
         * «прошивка стартует» (сразу после неё эталон сбрасывает 8051) */
        if ((v & 0x02) && !(v & 0x40)) sim_mcu_started = 1;
        if (v == 0) { sim_mcu_started = 0; sim_fw_written = 0; }
    }
    if (a == S_REG_AUTO_LLT) {
        u32 v; memcpy(&v, data, 4);
        printf("    dbg: write AUTO_LLT %08x\n", (unsigned)v);
        if (v & 0x10000) sim_llt_done = 1;   /* AUTO_LLT_INIT_LLT = BIT(16) */
    }
    if (a == 0x001d) {   /* REG_RSV_CTRL+1 */
        sim_8051_reset_count++;              /* reset_8051 трогает 0x1D дважды */
    }
    if (a >= 0x800 && a <= 0x8ff && (a & 3) == 0 && getenv("RTL_TRACE"))
        printf("    dbg: W32 %04x <- %08x\n", a, *(unsigned *)data);
    /* RF-записи: LSSI PARM XA(0x840)/XB(0x844) = (reg<<20)|data */
    /* Security CAM: REG_CAM_WRITE (0x674) -> REG_CAM_CMD (0x670, WRITE) */
    if (a == 0x0674) {
        u32 v; memcpy(&v, data, 4);
        sim_cam_pending = v;
    }
    if (a == 0x0670) {
        u32 v; memcpy(&v, data, 4);
        if ((v & 0x80010000u) == 0x80010000u) {   /* POLLING|WRITE */
            int cell = (int)((v & 0x3FF8) >> 3) & 7;
            int word = (int)(v & 7);
            sim_cam[cell][word] = sim_cam_pending;
            sim_cam_writes++;
        }
    }
    if (a == 0x0840 || a == 0x0844) {
        u32 v; memcpy(&v, data, 4);
        int rpath = (a == 0x0840) ? 0 : 1;
        u8 rreg = (u8)((v >> 20) & 0x3f);
        u32 rdata = v & 0x000fffff;
        if (rreg < 64) sim_rf[rpath][rreg] = rdata;
        sim_rf_last_reg[rpath] = rreg;
    }
    return len;
}

/* bulk (заглушка usb_ehci.c) */
int usb_ehci_bulk_xfer(int addr, int ep, int ep_size, int data_in,
                       void *buf, int len) {
    (void)addr; (void)ep_size;
    if (data_in) {
        if (sim_rx_count == 0) return -1;      /* NAK/пусто */
        int n = sim_rx_len[sim_rx_head];
        if (n > len) n = len;
        memcpy(buf, sim_rxq[sim_rx_head], (size_t)n);
        sim_rx_head = (sim_rx_head + 1) % RXQ_MAX;
        sim_rx_count--;
        return n;
    }
    /* OUT: TX-кадр [desc40][frame] */
    if (sim_tx_n < TXCAP_MAX && len > 40) {
        memcpy(sim_tx[sim_tx_n].desc, buf, 40);
        sim_tx[sim_tx_n].len = len - 40;
        memcpy(sim_tx[sim_tx_n].frame, (u8 *)buf + 40, (size_t)(len - 40));
        sim_tx[sim_tx_n].ep = ep;
        sim_tx_n++;
    }
    return len;
}

/* Сессия 32: bulk с явным таймаутом — симулятору таймаут безразличен */
int usb_ehci_bulk_xfer_to(int addr, int ep, int ep_size, int data_in,
                          void *buf, int len, u32 timeout_us) {
    (void)timeout_us;
    return usb_ehci_bulk_xfer(addr, ep, ep_size, data_in, buf, len);
}

/* Сессия 40: постоянная RX-очередь — симулятор: arm запоминает буфер,
 * poll отдаёт кадр из очереди (или -1), rearm/disarm — состояние. */
static void *sim_rx_arm_buf;
static int   sim_rx_arm_len;
static int   sim_rx_armed;

int usb_ehci_rx_arm(int addr, int ep, int ep_size, void *buf, int len) {
    (void)addr; (void)ep; (void)ep_size;
    if (sim_rx_armed) return 1;
    if (!buf || len <= 0) return -1;
    sim_rx_arm_buf = buf;
    sim_rx_arm_len = len;
    sim_rx_armed = 1;
    return 1;
}

int usb_ehci_rx_poll(void) {
    if (!sim_rx_armed) return -1;
    if (sim_rx_count == 0) return -1;          /* данных нет — очередь ждёт */
    int n = sim_rx_len[sim_rx_head];
    if (n > sim_rx_arm_len) n = sim_rx_arm_len;
    memcpy(sim_rx_arm_buf, sim_rxq[sim_rx_head], (size_t)n);
    sim_rx_head = (sim_rx_head + 1) % RXQ_MAX;
    sim_rx_count--;
    return n;
}

int usb_ehci_rx_rearm(void) {
    if (!sim_rx_armed) return -1;
    return 1;
}

int usb_ehci_rx_disarm(void) {
    if (!sim_rx_armed) return 0;
    sim_rx_armed = 0;
    sim_rx_arm_buf = NULL;
    sim_rx_arm_len = 0;
    return 1;
}

int usb_ehci_reset_wifi_device(int addr) { (void)addr; return 1; }

/* СЕССИЯ 42: CLEAR_FEATURE(ENDPOINT_HALT) — симулятор: всегда ok */
int usb_ehci_clear_halt(int addr, int ep_addr) { (void)addr; (void)ep_addr; return 0; }

static void sim_inject_rx(const u8 *pkt, int len, u8 rxmcs) {
    if (sim_rx_count >= RXQ_MAX) return;
    u8 *dst = sim_rxq[(sim_rx_head + sim_rx_count) % RXQ_MAX];
    /* [rxdesc24][phystats 32][frame] */
    memset(dst, 0, 24 + 32);
    u32 w0 = (u32)len | (4u << 16) /* drvinfo_sz=4 */ ;
    /* rxmcs в слове 3, биты 0-6 */
    u32 w3 = rxmcs & 0x7f;
    memcpy(dst + 0, &w0, 4);
    memcpy(dst + 12, &w3, 4);
    /* PHY-статистика: CCK: cck_agc_rpt @+6 (lna 2 = -10, vga 18) */
    dst[24 + 6] = (u8)((2 << 5) | 18);
    dst[24 + 4] = 130;               /* pwdb_all (для OFDM) -> (130>>1)-110 = -45 */
    memcpy(dst + 24 + 32, pkt, (size_t)len);
    sim_rx_len[(sim_rx_head + sim_rx_count) % RXQ_MAX] = 24 + 32 + len;
    sim_rx_count++;
}

static u16 fc_of(int type, int subtype) {
    return (u16)((type << 2) | (subtype << 4));
}

/* beacon: SSID + DS Param (канал) + RSN IE (WPA2-PSK CCMP) */
static int make_beacon(u8 *f, const char *ssid, int channel, int wpa2) {
    memset(f, 0, 64);
    u16 fc = fc_of(0, 8);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memset(f + 4, 0xff, 6);                       /* DA */
    memcpy(f + 10, sim_bssid, 6);                 /* SA */
    memcpy(f + 16, sim_bssid, 6);                 /* BSSID */
    /* [24..35] timestamp, interval, cap */
    f[34] = 0x11; f[35] = 0x00;                   /* cap: ESS + privacy? нет */
    int p = 36;
    /* SSID */
    int sl = (int)strlen(ssid);
    f[p++] = 0; f[p++] = (u8)sl; memcpy(f + p, ssid, (size_t)sl); p += sl;
    /* DS Params */
    f[p++] = 3; f[p++] = 1; f[p++] = (u8)channel;
    if (wpa2) {
        /* RSN IE: ver1, group CCMP, pairwise CCMP x1, AKM PSK x1 */
        static const u8 rsn[] = {
            0x30, 18, 0x01, 0x00,
            0x00, 0x0F, 0xAC, 0x04,
            0x01, 0x00, 0x00, 0x0F, 0xAC, 0x04,
            0x01, 0x00, 0x00, 0x0F, 0xAC, 0x02,
        };
        memcpy(f + p, rsn, sizeof(rsn)); p += (int)sizeof(rsn);
    }
    return p;
}

/* mgmt-ответ (AUTH/ASSOC) от точки */
static int make_auth_resp(u8 *f, u16 status) {
    memset(f, 0, 40);
    u16 fc = fc_of(0, 11);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memcpy(f + 4, sim_mac, 6);                    /* DA = мы */
    memcpy(f + 10, cur_bssid, 6);
    memcpy(f + 16, cur_bssid, 6);
    f[24] = 0; f[25] = 0;                         /* algo = open */
    f[26] = 2; f[27] = 0;                         /* seq = 2 */
    f[28] = (u8)(status & 0xff); f[29] = (u8)(status >> 8);
    return 30;
}

static int make_assoc_resp_st(u8 *f, u16 status, u16 aid) {
    memset(f, 0, 40);
    u16 fc = fc_of(0, 1);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memcpy(f + 4, sim_mac, 6);
    memcpy(f + 10, cur_bssid, 6);
    memcpy(f + 16, cur_bssid, 6);
    f[26] = (u8)(status & 0xff); f[27] = (u8)(status >> 8);   /* status */
    f[28] = (u8)(aid & 0xff); f[29] = (u8)((aid >> 8) & 0x3f);
    return 30;
}

static int make_assoc_resp(u8 *f, u16 aid) {
    return make_assoc_resp_st(f, 0, aid);
}

/* СЕССИЯ 51: assoc-resp С RSN IE точки — как у Ralink RT2860
 * (группа TKIP, 2 пары {TKIP, CCMP}, AKM PSK). Ядро берёт этот IE
 * для эха в повторном M2 (Ralink сверяет IE в M2 с собственным). */
static int make_assoc_resp_rsn(u8 *f, u16 aid) {
    static const u8 rsn[26] = {
        0x30, 0x18,
        0x01, 0x00, 0x00, 0x0F, 0xAC, 0x02,       /* группа TKIP */
        0x02, 0x00,                               /* 2 pairwise */
        0x00, 0x0F, 0xAC, 0x02,                   /*   TKIP */
        0x00, 0x0F, 0xAC, 0x04,                   /*   CCMP */
        0x01, 0x00, 0x00, 0x0F, 0xAC, 0x02,       /* AKM PSK */
        0x00, 0x00                                /* RSN caps */
    };
    int n = make_assoc_resp(f, aid);
    memcpy(f + n, rsn, sizeof(rsn));
    return n + (int)sizeof(rsn);
}

/* данные от точки: FromDS + LLC/SNAP + payload; protected добавляет IV/MIC */
/* DA/SA ожидаемого eth (заполняет тест) */

static int make_data_from_ap(u8 *f, const u8 *eth_payload, u32 plen, int protected_) {
    memset(f, 0, 1600);
    f[0] = 0x08;                                  /* data */
    f[1] = 0x02;                                  /* FromDS */
    if (protected_) f[1] |= 0x40;
    memcpy(f + 4, g_rx_eth_dst, 6);               /* addr1 = DA */
    memcpy(f + 10, sim_bssid, 6);                 /* addr2 = BSSID */
    memcpy(f + 16, g_rx_eth_src, 6);              /* addr3 = SA */
    int p = 24;
    if (protected_) {
        memset(f + p, 0x77, 8); p += 8;           /* CCMP IV (симуляция) */
    }
    memcpy(f + p, "\xAA\xAA\x03\x00\x00\x00", 6); p += 6;
    memcpy(f + p, eth_payload, plen); p += (int)plen;
    if (protected_) {
        memset(f + p, 0x5A, 8); p += 8;           /* MIC (симуляция) */
    }
    return p;
}

/* last TX captures helpers */
static int last_tx_of_type(int type) {
    for (int i = sim_tx_n - 1; i >= 0; i--) {
        u16 fc = (u16)(sim_tx[i].frame[0] | (sim_tx[i].frame[1] << 8));
        if (((fc >> 2) & 3) == type) return i;
    }
    return -1;
}

/* ============ заглушки окружения ядра ============ */

/* snprintf/vsnprintf в сигнатуре ядра (u32) — локальный string.h
 * переименовывает объявления real-исходников в эти обёртки */
int test_vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap) {
    return vsnprintf(out, n, fmt, ap);
}
int test_snprintf(char *out, u32 n, const char *fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(out, n, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

static u32 fake_ticks;
u32 timer_ticks(void) { return fake_ticks; }
static void advance(int n) { fake_ticks += (u32)n; }

/* [W-AUTHDWELL]/[W-AUTH2] (догоняющая правка харнесса): машина
 * подключения идёт SCAN -> PREAUTH (окно 340 мс) -> PROBE (250 мс) ->
 * AUTH. Ждём ВСЕ промежуточные состояния; маяки не обязательны —
 * PREAUTH/PROBE доходят до AUTH по тайм-аутам окон. */
static void conn_wait_auth(int iters)
{
    for (int i = 0; i < iters; i++) {
        int st = wifi_conn_state();
        if (st != WIFI_CONN_SCAN && st != WIFI_CONN_PREAUTH &&
            st != WIFI_CONN_PROBE)
            break;
        advance(200); wifi_poll();
    }
}

void klog_puts(const char *s) { (void)s; }
void serial_puts(const char *s) { fputs(s, stdout); }   /* лог драйвера виден */
/* Task 49+: oslog (wifi_log пишет и в него; хост — мимо stdout, чтобы
 * не дублировать строки). */
void oslog_puts(const char *tag, const char *s) { (void)tag; (void)s; }
void oslogf(const char *tag, const char *fmt, ...)
{
    (void)tag; (void)fmt;   /* формат-хвост сознательно игнорируем */
}

/* Task 49+: единый слой задержек (delay.h). Хост: задержки — no-op,
 * тайминги теста ведутся по fake_ticks (usleep/useconds_t недоступны —
 * у харнесса свои заглушки заголовков). */
void delay_init(void) { }
u32  delay_io_per_us(void) { return 3; }
void delay_us(u32 us) { (void)us; }
void delay_ms(u32 ms) { (void)ms; }

/* ramfs: один файл WIFI.CFG */
static char ram_cfg[256];
static int ram_cfg_len;
int  ramfs_ready(void) { return 1; }
int  ramfs_delete(const char *name) { (void)name; ram_cfg_len = 0; return 1; }
int  ramfs_create(const char *name, u32 size) { (void)name; (void)size; return 1; }
int  ramfs_write(const char *name, const void *buf, u32 size) {
    (void)name;
    if (size > sizeof(ram_cfg)) return 0;
    memcpy(ram_cfg, buf, size); ram_cfg_len = (int)size;
    return 1;
}
u32  ramfs_read(const char *name, void *buf, u32 max) {
    (void)name;
    if (ram_cfg_len == 0) return 0;
    u32 n = (u32)ram_cfg_len; if (n > max) n = max;
    memcpy(buf, ram_cfg, n);
    return n;
}

/* ============ реальный код ============ */

/* Atheros на хосте не проверяем — wifi_init пойдёт в RTL */
int ath9k_wifi_probe(void) { return 0; }
int usb_ehci_present(void)  { return 1; }   /* EHCI «есть» */

#include "wpa2.c"
#include "rtl8192eu_fw.c"
#include "rtl8192eu.c"
/* wifi_core.c включаем отдельно (ниже) — он с rtl в одном TU, чтобы
 * видеть wifi_log и не дублировать wifi_* (в ядре их держат раздельные TU) */
#include "wifi_core.c"

/* ============ тесты ============ */

static void test_attach_and_probe(void) {
    printf("== attach + probe (прошивка, MAC, 8051) ==\n");
    sim_reset();

    /* конфигурация: interface class 0 (vendor), EP1 IN bulk 512,
     * EP2/EP3/EP4 OUT bulk 512 */
    static u8 cfg[64];
    memset(cfg, 0, sizeof(cfg));
    int p = 0;
    /* config descriptor (9 байт) */
    cfg[p++] = 9; cfg[p++] = 2; cfg[p++] = (u8)36; cfg[p++] = 0; /* wTotalLength */
    cfg[p++] = 1; cfg[p++] = 1; cfg[p++] = 0; cfg[p++] = 0x80;
    cfg[p++] = 50;
    /* endpoint IN EP1 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x81; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;
    /* endpoint OUT EP2 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x02; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;
    /* endpoint OUT EP3 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x03; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;
    /* endpoint OUT EP4 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x04; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;

    CHECK(usb_wifi_try_attach(12, 0x0bda, 0x818b, cfg, p) == 1,
          "usb_wifi_try_attach принял 0bda:818b");
    printf("    dbg: ep_in=%d nr_out=%d eps=%d %d %d count=%d\n",
           rtl.ep_in, rtl.nr_out_eps, rtl.out_ep[0], rtl.out_ep[1],
           rtl.out_ep[2], rtl.ep_tx_count);
    CHECK(usb_wifi_try_attach(13, 0x0bda, 0x8187, cfg, p) == 0,
          "чужой VID/PID отвергнут");
    CHECK(usb_wifi_try_attach(13, 0x0bda, 0x818c, cfg, p) == 1,
          "уже занято — повторный attach глушится");

    CHECK(rtl8192eu_probe() == 1, "rtl8192eu_probe принёс адаптер");
    CHECK(wifi_present() == 1 && wifi_ready() == 1, "wifi_present/ready");
    CHECK(strcmp(wifi_chip_name(), "RTL8192EU") == 0,
          "chip_name = RTL8192EU (2T2R bonding)");

    /* прямая диагностика efuse */
    {
        u8 b;
        int rc = rtl_read_efuse8(0, &b);
        printf("    dbg: rtl_read_efuse8(0) rc=%d val=%02x\n", rc, b);
        rc = rtl_read_efuse8(1, &b);
        printf("    dbg: rtl_read_efuse8(1) rc=%d val=%02x\n", rc, b);
        int r2 = rtl_read_efuse();
        printf("    dbg: rtl_read_efuse rc=%d map[0..3]=%02x %02x %02x %02x\n",
               r2, rtl.efuse_map[0], rtl.efuse_map[1], rtl.efuse_map[2],
               rtl.efuse_map[3]);
    }

    /* прошивка: байт-в-байт после 32-байтового заголовка */
    extern const u8 rtl8192eu_fw_data[];
    u32 fw_size = 32286u - 32u;
    printf("    dbg: fw_written=%d (ожидалось %d)\n", sim_fw_written, (int)fw_size);
    printf("    dbg: efuse_ok=%d map[0..7]=%02x %02x %02x %02x %02x %02x %02x %02x\n",
           rtl.efuse_ok, rtl.efuse_map[0], rtl.efuse_map[1], rtl.efuse_map[2],
           rtl.efuse_map[3], rtl.efuse_map[4], rtl.efuse_map[5],
           rtl.efuse_map[6], rtl.efuse_map[7]);
    printf("    dbg: map[D0..D7]=%02x %02x %02x %02x %02x %02x %02x %02x\n",
           rtl.efuse_map[0xd0], rtl.efuse_map[0xd1], rtl.efuse_map[0xd2],
           rtl.efuse_map[0xd3], rtl.efuse_map[0xd4], rtl.efuse_map[0xd5],
           rtl.efuse_map[0xd6], rtl.efuse_map[0xd7]);
    CHECK(sim_fw_written == (int)fw_size,
          "прошивка записана целиком (32254 б)");
    int bad = 0;
    for (u32 i = 0; i < fw_size; i++)
        if (sim_fw_ram[i] != rtl8192eu_fw_data[32 + i]) { bad++; break; }
    CHECK(bad == 0, "байты прошивки совпадают байт-в-байт");
    CHECK(sim_8051_reset_count >= 1, "8051 сбрасывался (старт прошивки)");
    CHECK(sim_mcu_started, "MCU стартовал (WINT_INIT_READY увиден)");

    /* MAC из efuse */
    u8 mac[6];
    wifi_net_get_mac(mac);
    CHECK(memcmp(mac, sim_mac, 6) == 0, "MAC из efuse (48:5b:39:22:33:44)");
}

static void test_scan_and_persist(void) {
    printf("== скан: каналы, beacon, список переживает повтор ==\n");
    /* скан стартует с канала 1 */
    fake_ticks += 100;
    wifi_scan_start();
    CHECK(wifi_scan_active(), "скан активен");

    /* RF 0x18 канал 1 записан? */
    printf("    dbg: sim_rf[0][0x18]=%06x sim_rf[1][0x18]=%06x\n",
           (unsigned)sim_rf[0][S_RF_MODE_AG], (unsigned)sim_rf[1][S_RF_MODE_AG]);
    CHECK((sim_rf[0][S_RF_MODE_AG] & 0xff) == 1, "RF channel = 1 (путь A)");

    /* прокручиваем до канала 6 */
    int cur = 1;
    while (cur < SIM_CHANNEL) {
        advance(200);          /* dwell 150 мс ([W-SCAN-DWELL] подняли с 110) + запас */
        wifi_poll();
        cur++;
    }
    CHECK((sim_rf[0][S_RF_MODE_AG] & 0xff) == SIM_CHANNEL,
          "скан дошёл до канала 6");

    /* beacon на канале 6 */
    u8 bcn[256];
    int bl = make_beacon(bcn, sim_ssid, SIM_CHANNEL, 1);
    if (getenv("RTL_TRACE")) {
        printf("    dbg: beacon[%d]:", bl);
        for (int i = 36; i < bl; i++) printf(" %02x", bcn[i]);
        printf("\n");
    }
    sim_inject_rx(bcn, bl, 0x00 /* CCK 1M */);
    advance(21);          /* гейт poll_rx — 20 мс (сессия 33) + запас */
    wifi_poll();

    wifi_ap_t aps[WIFI_MAX_APS];
    int n = wifi_scan_results(aps, WIFI_MAX_APS);
    CHECK(n >= 1, "сеть найдена");
    int found = -1;
    for (int i = 0; i < n; i++)
        if (strcmp(aps[i].ssid, sim_ssid) == 0) found = i;
    CHECK(found >= 0, "SSID \"HomeNet\" в списке");
    if (found >= 0) {
        CHECK(aps[found].channel == SIM_CHANNEL, "канал сети = 6");
        printf("    dbg: ap.sec=%d encrypted=%d cap=%04x\n",
               aps[found].sec, aps[found].encrypted, aps[found].capability);
        CHECK(aps[found].sec == WIFI_SEC_WPA2_PSK, "защита распознана (WPA2-PSK)");
    } else {
        return;   /* дальше без сети нет смысла */
    }

    /* завершаем скан до конца */
    while (cur < 14) {
        advance(200);
        wifi_poll();
        cur++;
    }
    /* [ATH-SCAN2]: маяков <10 — скан сам делает второй проход, ждём
     * его конца честным циклом (guard 120 проходов по 200 мс) */
    { int guard = 0;
      while (wifi_scan_active() && guard++ < 120) { advance(200); wifi_poll(); } }
    CHECK(!wifi_scan_active(), "скан завершён");

    /* ПОВТОРНЫЙ скан: список НЕ очищается (регрессия сессии 28) */
    wifi_scan_start();
    CHECK(wifi_scan_active(), "повторный скан активен");
    n = wifi_scan_results(aps, WIFI_MAX_APS);
    CHECK(n >= 1, "список сетей сохранён между сканами");
    wifi_disconnect();
}

static void test_connect_wpa2(void) {
    printf("== подключение WPA2-PSK (AUTH/ASSOC/M1-M4/CAM) ==\n");

    /* PMK/PTK считаем сами (как AP): pmk = PBKDF2(pass, ssid) */
    u8 pmk[32], ptk[48];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);

    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "wifi_connect_psk запущен");
    CHECK(wifi_conn_state() == WIFI_CONN_SCAN, "состояние = SCAN");

    /* скан завершится сам (адаптер уже на канале 6 — conn_step найдёт AP) */
    /* [ATH-SCAN2]: возможны два прохода; затем PREAUTH/PROBE до AUTH */
    if (getenv("RTL_TRACE")) { conn_wait_auth(300); }
    else { conn_wait_auth(300); }
    if (getenv("RTL_TRACE")) {
        char wl[4096];
        int n = wifi_log_tail(wl, (int)sizeof(wl), 400);
        printf("---- wifi log (conn debug) ----\n%.*s----\n", n, wl);
    }
    CHECK(wifi_conn_state() == WIFI_CONN_AUTH, "AUTH отправлен (точка найдена)");

    int t = last_tx_of_type(0);
    CHECK(t >= 0, "mgmt TX захвачен");
    if (t < 0) return;   /* дальше без кадра нет смысла */
    u16 fc = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
    CHECK((fc & 0x00F0) == 0x00B0, "это AUTH REQ (subtype 11)");
    CHECK(memcmp(sim_tx[t].frame + 10, sim_mac, 6) == 0, "addr2 = наш MAC");
    CHECK(memcmp(sim_tx[t].frame + 16, sim_bssid, 6) == 0, "addr3 = BSSID");
    /* дескриптор: mgmt -> queue MGNT */
    u32 qsel = (sim_tx[t].desc[5] & 0x1f);   /* txdw1 биты 12:8 */
    CHECK(qsel == TXDESC_QUEUE_MGNT, "mgmt уходит в очередь MGNT");

    /* AUTH ok -> ASSOC REQ */
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_ASSOC, "AUTH принят, ASSOC REQ");
    t = last_tx_of_type(0);
    fc = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
    CHECK((fc & 0x00F0) == 0x0000, "это ASSOC REQ (subtype 0)");
    {
        /* в ASSOC REQ должен быть RSN IE (WPA2) */
        int p = 24 + 2 + 2;
        int rsn = 0;
        while (p + 2 <= sim_tx[t].len) {
            if (sim_tx[t].frame[p] == 48) { rsn = 1; break; }
            p += 2 + sim_tx[t].frame[p + 1];
        }
        CHECK(rsn, "ASSOC REQ содержит RSN IE");
    }

    /* ASSOC ok -> 4WAY, ждём M1 */
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC001), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ASSOC ok, ждём 4-way");

    /* ---- M1 (от AP): ANonce, ACK, без MIC ---- */
    u8 anonce[32];
    memset(anonce, 0xA5, sizeof(anonce));
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key(m1, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK,
                                     anonce, (const u8 *)"\x01\x00\x00\x00\x00\x00\x00\x00",
                                     NULL, 0);
    /* FromDS data + LLC/SNAP + 888E */
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c /* 6M OFDM */);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M1 принят, ждём M3");

    printf("    dbg: после M1 state=%d tx_captures=%d\n",
           (int)wifi_conn_state(), sim_tx_n);
    /* ---- M2 (наш): проверить SNonce + MIC по PTK ---- */
    t = last_tx_of_type(2);
    CHECK(t >= 0, "EAPOL M2 передан (data TX)");
    u16 dfc = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
    CHECK((dfc & 0x0008) == 0x0008, "EAPOL = data ToDS");
    CHECK((dfc & 0x4000) == 0, "EAPOL НЕ Protected");
    /* СЕССИЯ 44: длина M2 строго по спецификации (kd = наш RSN IE 22 б):
     * тело EAPOL = 95+22 = 117, весь кадр = 14+4+95+22 = 135. Прежний
     * строитель добавлял +2 — строгие точки такой M2 отбрасывали */
    {
        const u8 *e = sim_tx[t].frame + 24 + 8;
        u32 blen = ((u32)e[2] << 8) | e[3];
        CHECK(blen == 95 + 22, "EAPOL Length M2 = 117 (95+RSN IE)");
    }
    /* вытащить SNonce из M2 (key data нулевой; nonce поле = смещение
     * eth14 + eapol 4 + keyhdr: nonce @ 99 байт кадра EAPOL) */
    u8 snonce[32];
    {
        /* M2 eth: [14 hdr][eapol ...]: eapol key nonce @ +14+ (99-14) */
        /* в 802.11: 24 hdr + LLC 6 + ethertype 2 + body */
        const u8 *e = sim_tx[t].frame + 24 + 8;
        /* eapol key hdr: ver type len(2) key_info(2) keylen(2) replay(8)
         * nonce(32) => nonce @ e+ 14 (eth src/dst восстановлены) + 21 */
        memcpy(snonce, e + 17, 32);
    }
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce, snonce, ptk);
    /* MIC в M2: последние 16 байт EAPOL-кадра */
    {
        const u8 *e = sim_tx[t].frame + 24 + 8;
        int elen = sim_tx[t].len - 24 - 8;
        /* e = начало EAPOL (802.11 hdr 24 + LLC/SNAP+888E 8).
         * eth-кадр = [dst src 888E][e]; MIC покрывает eth+14.. (сам EAPOL) */
        u8 mic[16];
        static u8 tmp[1600];
        memcpy(tmp + 14, e, (size_t)elen);
        memset(tmp + 95, 0, 16);          /* MIC в eth+95 */
        wpa2_eapol_mic(ptk, tmp, (u32)(elen + 14), mic);
        printf("    dbg: t.kck=");
        for (int q = 0; q < 16; q++) printf("%02x", ptk[q]);
        printf("\n");
        CHECK(memcmp(mic, e + 81, 16) == 0, "MIC M2 сходится (KCK)");
    }

    /* ---- M3: GTK KDE зашифрован KEK, MIC, Secure, Install.
     * СЕССИЯ 51: канонический GTK KDE (hostap): OUI4+keyid+reserved+GTK */
    u8 gtk[16];
    memset(gtk, 0x71, sizeof(gtk));
    u8 kde[32];
    kde[0] = 0xDD; kde[1] = 22;
    memcpy(kde + 2, "\x00\x0F\xAC\x01", 4);
    kde[6] = 0x01;                                 /* keyid 1 (как у реальных
                                                    * точек; 0 — парный) */
    kde[7] = 0x00;                                 /* reserved */
    memcpy(kde + 8, gtk, 16);
    u8 wrapped[40];
    wpa2_aes_wrap(ptk + 16, kde, 24, wrapped);     /* 24 байт + IV 8 = 32 */

    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key(m3, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK | WPA2_KI_MIC |
                                     WPA2_KI_SECURE | WPA2_KI_ENCR_DATA,
                                     anonce, (const u8 *)"\x02\x00\x00\x00\x00\x00\x00\x00",
                                     wrapped, 32);
    /* СЕССИЯ 44: M3 несёт replay counter M1+1 (точка инкрементирует:
     * M1 = 01, M3 = 02) и КОРРЕКТНУЮ длину тела 95+kd (без «+2»)
     * MIC по кадру с нулём в поле MIC */
    CHECK(m3len == 14 + 4 + 95 + 32, "длина M3 = 113+kd (без +2)");
    CHECK(((u32)m3[16] << 8 | m3[17]) == 95 + 32, "EAPOL Length M3 = 95+kd");
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);

    if (getenv("WIFI_PARSE_DBG")) {
        /* контрольная проверка: тот же расчёт, что у драйвера
         * (eb-подобный буфер: [12 нулей][888E][m3+12..], MIC=0) */
        u8 ctrl[1600];
        memset(ctrl, 0, sizeof(ctrl));
        memcpy(ctrl + 12, m3 + 12, (size_t)(m3len - 12));
        memset(ctrl + 95, 0, 16);
        u8 cmic[16];
        wpa2_eapol_mic(ptk, ctrl, (u32)m3len, cmic);
        printf("    dbg: ctrl-mic=%02x%02x%02x%02x (должен = mic3)\n",
               cmic[0], cmic[1], cmic[2], cmic[3]);
        printf("    dbg: m3[14..29]:");
        for (int q = 14; q < 30; q++) printf(" %02x", m3[q]);
        printf("\n    dbg: m3-full:");
        for (int q = 0; q < m3len; q++) printf("%02x", m3[q]);
        printf("\n    dbg: m3 mic3=%02x%02x%02x%02x\n",
               mic3[0], mic3[1], mic3[2], mic3[3]);
    }
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "M3 принят -> CONNECTED");
    CHECK(wifi_conn_secured() == 1, "ключи установлены (wifi_conn_secured)");

    /* CAM: СЕССИЯ 52 — PTK → ячейка 0 (keyid парного = 0, железо ищет
     * по keyid из IV), GTK keyid1 → ячейка 1 */
    int cam_ok = 0;
    for (int i = 0; i < 8; i++) {
        if (sim_cam[i][0] == 0 && sim_cam[i][1] == 0) continue;
        cam_ok = 1;
    }
    CHECK(sim_cam_writes >= 12, "CAM-записи выполнены (PTK+GTK)");
    CHECK(cam_ok, "CAM ячейки не пусты");
    /* PTK TK (ptk+32) должен оказаться в CAM (слова 2..5 ячейки idx0) */
    {
        u32 expect = (u32)ptk[32] | ((u32)ptk[33] << 8) |
                     ((u32)ptk[34] << 16) | ((u32)ptk[35] << 24);
        printf("    dbg: cam[0][0..5]=%08x %08x %08x %08x %08x %08x expect=%08x\n",
               (unsigned)sim_cam[0][0], (unsigned)sim_cam[0][1],
               (unsigned)sim_cam[0][2], (unsigned)sim_cam[0][3],
               (unsigned)sim_cam[0][4], (unsigned)sim_cam[0][5],
               (unsigned)expect);
        CHECK(sim_cam[0][2] == expect, "CAM[0] содержит PTK TK (CCMP)");
    }
    /* M4 передан */
    int t4 = last_tx_of_type(2);
    CHECK(t4 > t, "M4 передан");
    {   /* СЕССИЯ 44: M4 отвечает replay-счётчиком M3 (02) и телом 95 */
        const u8 *e4 = sim_tx[t4].frame + 24 + 8;
        CHECK(e4[9] == 0x02, "M4 несёт replay counter M3");
        CHECK(((u32)e4[2] << 8 | e4[3]) == 95, "EAPOL Length M4 = 95");
    }

    /* ---- данные: TX из стека ---- */
    u8 eth[64];
    memset(eth, 0, sizeof(eth));
    eth[0] = 0x10; eth[1] = 0x22; eth[2] = 0x33; eth[3] = 0x44; eth[4] = 0x55; eth[5] = 0x66;
    eth[6] = sim_mac[0]; eth[7] = sim_mac[1]; eth[8] = sim_mac[2];
    eth[9] = sim_mac[3]; eth[10] = sim_mac[4]; eth[11] = sim_mac[5];
    eth[12] = 0x08; eth[13] = 0x00;
    for (int i = 14; i < 64; i++) eth[i] = (u8)i;
    int r = wifi_net_send(eth, 64);
    CHECK(r == 64, "wifi_net_send вернул длину");
    int td = last_tx_of_type(2);
    CHECK(td >= 0, "data TX захвачен");
    dfc = (u16)(sim_tx[td].frame[0] | (sim_tx[td].frame[1] << 8));
    CHECK((dfc & 0x4000) != 0, "data кадр Protected (шифруется железом)");
    CHECK(memcmp(sim_tx[td].frame + 4, sim_bssid, 6) == 0, "addr1 = BSSID");
    CHECK(memcmp(sim_tx[td].frame + 16, eth, 6) == 0, "addr3 = DA");
    /* СЕССИЯ 51→52: IV-заголовок CCMP строим в софте, раскладка канон:
     * [PN5][PN4][00][0x20|kid][PN3][PN2][PN1][PN0] (mac80211 ccmp_pn2hdr,
     * PN старшим байтом вперёд). Первый кадр PN=1, keyid 0 */
    CHECK(memcmp(sim_tx[td].frame + 24,
                 "\x00\x00\x00\x20\x00\x00\x00\x01", 8) == 0,
          "CCMP IV-заголовок TX (PN=1 BE, keyid 0)");
    /* LLC/SNAP + ethertype 0800 — теперь ПОСЛЕ IV (+32) */
    CHECK(memcmp(sim_tx[td].frame + 32, "\xAA\xAA\x03\x00\x00\x00\x08\x00", 8) == 0,
          "LLC/SNAP + IPv4 ethertype (после IV)");
    /* второй/третий кадры — юникаст: PN растёт 2, 3 (без повторов) */
    {
        u8 eth2[64];
        memcpy(eth2, eth, sizeof(eth2));
        eth2[0] = 0x12;                        /* чётный DA — юникаст */
        CHECK(wifi_net_send(eth2, 64) == 64, "wifi_net_send #2");
        int td2 = last_tx_of_type(2);
        CHECK(td2 > td, "второй data TX захвачен");
        CHECK(memcmp(sim_tx[td2].frame + 24,
                     "\x00\x00\x00\x20\x00\x00\x00\x02", 8) == 0,
              "CCMP IV: PN вырос до 2 (без повторов)");
        u8 eth3[64];
        memcpy(eth3, eth2, sizeof(eth3));
        eth3[0] = 0x14;
        CHECK(wifi_net_send(eth3, 64) == 64, "wifi_net_send #3");
        int td3 = last_tx_of_type(2);
        CHECK(memcmp(sim_tx[td3].frame + 24,
                     "\x00\x00\x00\x20\x00\x00\x00\x03", 8) == 0,
              "CCMP IV: PN вырос до 3");
    }
    /* чексумма дескриптора: XOR 16 слов = 0 */
    {
        u16 *w = (u16 *)sim_tx[td].desc;
        u16 x = 0;
        for (int i = 0; i < 16; i++) x ^= w[i];
        CHECK(x == 0, "TX-дескриптор: чексумма (XOR слов) = 0");
    }
    u32 dq = (sim_tx[td].desc[5] & 0x1f);    /* txdw1 биты 12:8 */
    CHECK(dq == TXDESC_QUEUE_BE, "data уходит в очередь BE");

    /* ---- RX данных из сети ----
     * СЕССИЯ 51: DA = наш MAC (юникаст «нам»; eth[0]=0x10 — чужой
     * юникаст, такой кадр фильтр RX отбрасывает). Эти DA/SA остаются
     * и для инжекций M1/M3 в следующих тестах. */
    memcpy(g_rx_eth_dst, sim_mac, 6);        /* DA = мы */
    memcpy(g_rx_eth_src, sim_bssid, 6);      /* SA = точка */
    u8 dfr[1600];
    int dl = make_data_from_ap(dfr, eth + 12, 64 - 12, 1);
    sim_inject_rx(dfr, dl, 0x0c);
    advance(21); wifi_poll();
    u8 rxbuf[1600];
    u32 rn = wifi_net_recv(rxbuf, sizeof(rxbuf));
    CHECK(rn == 64, "wifi_net_recv вернул Ethernet-кадр");
    CHECK(rn >= 14 && memcmp(rxbuf, sim_mac, 6) == 0 &&
          memcmp(rxbuf + 6, sim_bssid, 6) == 0 &&
          memcmp(rxbuf + 12, eth + 12, 2) == 0,
          "Ethernet-заголовок верный (DA/SA/ethertype)");
}

static void test_profile(void) {
    printf("== профиль WIFI.CFG ==\n");
    /* psk установлен (мы подключены) — сохранение с паролем */
    wifi_profile_save(sim_ssid);
    char ssid[33], psk[65];
    CHECK(wifi_profile_load(ssid, sizeof(ssid)) == 1, "SSID читается из профиля");
    CHECK(strcmp(ssid, sim_ssid) == 0, "SSID совпадает");
    CHECK(wifi_profile_load_psk(psk, sizeof(psk)) == 1, "psk читается из профиля");
    CHECK(strcmp(psk, SIM_PASS) == 0, "psk совпадает");
}

static void test_ap_reject_password(void) {
    printf("== неверный пароль: M3 с плохим MIC -> FAILED ==\n");
    wifi_disconnect();
    CHECK(wifi_connect_psk(sim_ssid, "wrongpassword") == 1, "второе подключение");
    for (int i = 0; i < 40 && wifi_conn_state() != WIFI_CONN_AUTH; i++) {
        advance(200); wifi_poll();
    }
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC002), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "снова ждём 4-way");

    /* M1 заново (с другим ANonce) */
    u8 anonce2[32];
    memset(anonce2, 0x5A, sizeof(anonce2));
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key(m1, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK,
                                     anonce2, (const u8 *)"\x03\x00\x00\x00\x00\x00\x00\x00",
                                     NULL, 0);
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();

    /* наш M2 -> snonce */
    int t = last_tx_of_type(2);
    CHECK(t >= 0, "M2 отправлен");
    if (t < 0) return;
    u8 pmk[32], ptk[48], snonce[32];
    wpa2_pbkdf2_sha1((const u8 *)"wrongpassword", 13,
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);
    {
        const u8 *e = sim_tx[t].frame + 24 + 8;
        memcpy(snonce, e + 17, 32);
    }
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce2, snonce, ptk);

    /* M3 с МИК от ДРУГОГО ключа (AP думает, что пароль другой) */
    u8 gtk[16]; memset(gtk, 0x71, sizeof(gtk));
    u8 kde[32];
    kde[0] = 0xDD; kde[1] = 22;
    memcpy(kde + 2, "\x00\x0F\xAC\x01", 4);
    kde[6] = 0x00;
    kde[7] = 0x00;                                 /* reserved (СЕССИЯ 51) */
    memcpy(kde + 8, gtk, 16);
    u8 wrapped[40];
    wpa2_aes_wrap(ptk + 16, kde, 24, wrapped);
    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key(m3, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK | WPA2_KI_MIC |
                                     WPA2_KI_SECURE | WPA2_KI_ENCR_DATA,
                                     anonce2, (const u8 *)"\x04\x00\x00\x00\x00\x00\x00\x00",
                                     wrapped, 32);
    /* MIC по кадру с ДРУГИМ PMK (наш драйвер посчитает по "wrongpassword",
     * AP — по "password123" -> MIC не сойдётся) */
    u8 pmk_ap[32], ptk_ap[48];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk_ap, 32);
    wpa2_derive_ptk(pmk_ap, sim_bssid, sim_mac, anonce2, snonce, ptk_ap);
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk_ap, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_FAILED, "плохой MIC -> WIFI_CONN_FAILED");
}

/* ---- СЕССИЯ 32: маяк с настраиваемыми рейты/capability ---- */
static int make_beacon_rates(u8 *f, const char *ssid, int channel,
                             const u8 *r1, int r1len,
                             const u8 *r2, int r2len, u16 cap) {
    memset(f, 0, 128);
    u16 fc = fc_of(0, 8);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memset(f + 4, 0xff, 6);                       /* DA */
    memcpy(f + 10, cur_bssid, 6);
    memcpy(f + 16, cur_bssid, 6);
    f[34] = (u8)(cap & 0xff); f[35] = (u8)(cap >> 8);
    int p = 36;
    int sl = (int)strlen(ssid);
    f[p++] = 0; f[p++] = (u8)sl; memcpy(f + p, ssid, (size_t)sl); p += sl;
    f[p++] = 3; f[p++] = 1; f[p++] = (u8)channel; /* DS Params */
    if (r1len > 0) {
        f[p++] = 1; f[p++] = (u8)r1len;
        memcpy(f + p, r1, (size_t)r1len); p += r1len;
    }
    if (r2len > 0) {
        f[p++] = 50; f[p++] = (u8)r2len;
        memcpy(f + p, r2, (size_t)r2len); p += r2len;
    }
    return p;
}

static void test_assoc_rates_and_deauth_cap(void) {
    printf("== СЕССИЯ 32/38: рейты точки в ASSOC REQ + status=18 + DEAUTH-шторм ==\n");
    wifi_disconnect();
    {   /* ДРУГАЯ точка (другой BSSID): иначе parse_beacon обновит
         * запись HomeNet и OpenGNet в списке не появится */
        static const u8 nb[6] = { 0xc0, 0x25, 0xe9, 0x11, 0xaa, 0x55 };
        memcpy(cur_bssid, nb, 6);
    }

    /* g-only точка: basic 6/12/24 + ext 9..54, short preamble —
     * против СТАРОГО кода (хардкод basic 1/2/5.5/11) такая точка
     * отвечала ASSOC status=18; теперь рейты идут из маяка 1:1 */
    static const u8 r1[] = { 0x8C, 0x98, 0xB0 };            /* 6B 12B 24B */
    static const u8 r2[] = { 0x12, 0x24, 0x30, 0x48, 0x60, 0x6C };
    u8 bcn[128];
    int bl = make_beacon_rates(bcn, "OpenGNet", SIM_CHANNEL,
                               r1, (int)sizeof(r1), r2, (int)sizeof(r2),
                               0x0021 /* ESS + short preamble */);
    (void)bl;
    wifi_scan_start();
    CHECK(wifi_scan_active(), "скан активен");
    int cur = 1;
    while (cur < SIM_CHANNEL) { advance(200); wifi_poll(); cur++; }
    sim_inject_rx(bcn, bl, 0x00);
    advance(21); wifi_poll();
    while (cur <= 14) { advance(200); wifi_poll(); cur++; }
    { int guard = 0;
      while (wifi_scan_active() && guard++ < 120) { advance(200); wifi_poll(); } }
    CHECK(!wifi_scan_active(), "скан завершён");

    CHECK(wifi_connect_psk("OpenGNet", NULL) == 1, "подключение к открытой g-only сети");
    advance(21); wifi_poll();
    { int st = wifi_conn_state();
      CHECK(st == WIFI_CONN_AUTH || st == WIFI_CONN_PREAUTH,
            "AUTH сразу (кэш свежего скана — без полного рескана)"); }
    conn_wait_auth(60);   /* PREAUTH/PROBE окна — до AUTH */

    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_ASSOC, "AUTH ok, посылаем ASSOC REQ");

    int t = last_tx_of_type(0);
    CHECK(t >= 0, "ASSOC REQ захвачен");
    if (t >= 0) {
        u16 fcv = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
        CHECK(fcv == 0x0000, "FC = assoc request");
        u16 cap = (u16)(sim_tx[t].frame[24] | (sim_tx[t].frame[25] << 8));
        CHECK((cap & 0x0020) != 0, "Short Preamble зеркален из capability маяка");
        int p = 28;                           /* 24 hdr + 2 cap + 2 listen */
        int seen_ssid = 0;
        u8 got[24]; int got_n = 0;
        while (p + 2 <= sim_tx[t].len) {
            u8 tag = sim_tx[t].frame[p];
            u8 tl = sim_tx[t].frame[p + 1];
            if (tag == 0) seen_ssid = 1;
            else if ((tag == 1 || tag == 50) && got_n + tl <= (int)sizeof(got)) {
                memcpy(got + got_n, sim_tx[t].frame + p + 2, tl);
                got_n += tl;
            }
            p += 2 + tl;
        }
        /* СЕССИЯ 43: ОБЪЕДИНЕНИЕ ОТСОРТИРОВАНО по рейту (как у
         * wpa_supplicant): 1,2,5.5, рейты точки 6B 12B 24B (basic),
         * 9, 11, 18, 24B (basic), 36, 48, 54 */
        static const u8 want[] = { 0x02, 0x04, 0x0B, 0x8C, 0x12, 0x16,
                                   0x98, 0x24, 0xB0, 0x30, 0x48, 0x60,
                                   0x6C };
        CHECK(seen_ssid, "SSID IE на месте");
        CHECK(got_n == (int)sizeof(want) && memcmp(got, want, sizeof(want)) == 0,
              "рейты ASSOC REQ = отсортированное объединение (13)");
        int basic_ok = 0;
        for (int k = 0; k < got_n; k++) {
            if (got[k] == 0x8C) basic_ok |= 1;
            if (got[k] == 0x98) basic_ok |= 2;
            if (got[k] == 0xB0) basic_ok |= 4;
        }
        CHECK(basic_ok == 7,
              "basic-рейты точки (6/12/24) с её basic-битами сохранены");
    }

    /* ---- СЕССИЯ 38: отказ status=18 -> один ретрай с классическим
     * набором b/g (basic 1/2/5.5/11), потом успех ---- */
    sim_inject_rx(fr, make_assoc_resp_st(fr, 18, 0), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_ASSOC,
          "после status=18 — ретрай ассоциации (не FAILED)");
    t = last_tx_of_type(0);
    CHECK(t >= 0, "повторный ASSOC REQ захвачен");
    if (t >= 0) {
        int p = 28;
        u8 got2[24]; int got2_n = 0;
        while (p + 2 <= sim_tx[t].len) {
            u8 tag = sim_tx[t].frame[p];
            u8 tl = sim_tx[t].frame[p + 1];
            if ((tag == 1 || tag == 50) && got2_n + tl <= (int)sizeof(got2)) {
                memcpy(got2 + got2_n, sim_tx[t].frame + p + 2, tl);
                got2_n += tl;
            }
            p += 2 + tl;
        }
        static const u8 want2[] = { 0x82, 0x84, 0x8B, 0x0C, 0x12, 0x96, 0x18,
                                    0x24, 0x30, 0x48, 0x60, 0x6C };
        CHECK(got2_n == (int)sizeof(want2) && memcmp(got2, want2, sizeof(want2)) == 0,
              "повтор после 18 = классический полный b/g, отсортированный");
    }

    sim_inject_rx(fr, make_assoc_resp(fr, 0xC003), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "открытая g-only сеть: CONNECTED");

    /* ---- DEAUTH-шторм: точка отшивает reason=2. Раньше: скан→AUTH→
     * DEAUTH бесконечно (шторм из лога пользователя). Теперь после
     * 2 быстрых переподключений и 4 DEAUTH — FAILED. ---- */
    u8 de[32];
    u16 dfc = fc_of(0, 12);
    de[0] = (u8)(dfc & 0xff); de[1] = (u8)(dfc >> 8);
    memcpy(de + 4, sim_mac, 6);
    memcpy(de + 10, cur_bssid, 6);
    memcpy(de + 16, cur_bssid, 6);
    de[24] = 2; de[25] = 0;                    /* reason 2 */
    int deauths = 0, guard = 0;
    while (wifi_conn_state() != WIFI_CONN_FAILED && guard++ < 60) {
        if (wifi_conn_state() != WIFI_CONN_SCAN) {
            sim_inject_rx(de, 26, 0x00);
            deauths++;
        }
        advance(21); wifi_poll();
        int k = 0;
        while (wifi_scan_active() && k++ < 20) { advance(200); wifi_poll(); }
    }
    printf("    dbg: DEAUTH подано %d, итог state=%d scanning=%d\n",
           deauths, (int)wifi_conn_state(), wifi_scan_active());
    CHECK(deauths >= 5, "шторм реально подавался (>=5 DEAUTH)");
    CHECK(wifi_conn_state() == WIFI_CONN_FAILED,
          "после CONN_MAX_DEAUTH — FAILED (петля остановлена)");
    CHECK(!wifi_scan_active(), "рескан-петля не осталась жить");
    wifi_disconnect();
}

/* ---- СЕССИЯ 43: 11n-точка (селектор 0x7F + IE 45), смешанная
 * WPA+WPA2, группа TKIP, short slot. ASSOC REQ обязан содержать:
 * HT caps (45), RSN (48, группа TKIP) — RSN-only (СЕССИЯ 50: без WPA
 * IE), WMM (221/00:50:F2:02), cap с Short Slot Time, рейты БЕЗ 0x7F. --- */
static void test_wpa2_ht_assoc_elems(void) {
    printf("== СЕССИЯ 43: 11n+WPA2/WPA-смешанная точка (status=18) ==\n");
    wifi_disconnect();
    {
        static const u8 nb[6] = { 0xc0, 0x25, 0xe9, 0x43, 0x77, 0x21 };
        memcpy(cur_bssid, nb, 6);
    }

    /* маяк: рейты 1..54 (8+4) + селектор HT 0x7F в IE50 */
    static const u8 r1[] = { 0x82, 0x84, 0x8B, 0x96, 0x0C, 0x12, 0x18, 0x24 };
    static const u8 r2[] = { 0x30, 0x48, 0x60, 0x6C, 0x7F };
    u8 bcn[256];
    u16 fc = fc_of(0, 8);
    bcn[0] = (u8)(fc & 0xff); bcn[1] = (u8)(fc >> 8);
    memset(bcn + 4, 0xff, 6);
    memcpy(bcn + 10, cur_bssid, 6);
    memcpy(bcn + 16, cur_bssid, 6);
    bcn[34] = 0x31; bcn[35] = 0x04;           /* ESS+Privacy+ShortPrem+ShortSlot */
    int p = 36;
    const char *ssid = "SecureHT";
    int sl = (int)strlen(ssid);
    bcn[p++] = 0; bcn[p++] = (u8)sl; memcpy(bcn + p, ssid, (size_t)sl); p += sl;
    bcn[p++] = 3; bcn[p++] = 1; bcn[p++] = SIM_CHANNEL;
    bcn[p++] = 1; bcn[p++] = (u8)sizeof(r1);
    memcpy(bcn + p, r1, sizeof(r1)); p += (int)sizeof(r1);
    bcn[p++] = 50; bcn[p++] = (u8)sizeof(r2);
    memcpy(bcn + p, r2, sizeof(r2)); p += (int)sizeof(r2);
    {   /* RSN: ver1, группа TKIP, pairwise CCMP, AKM PSK, caps 0 */
        static const u8 rsn[] = {
            0x30, 20,
            0x01, 0x00,
            0x00, 0x0F, 0xAC, 0x02,
            0x01, 0x00, 0x00, 0x0F, 0xAC, 0x04,
            0x01, 0x00, 0x00, 0x0F, 0xAC, 0x02,
            0x00, 0x00
        };
        memcpy(bcn + p, rsn, sizeof(rsn)); p += (int)sizeof(rsn);
    }
    {   /* WPA IE (смешанный режим) */
        static const u8 wpaie[] = {
            0xDD, 24,
            0x00, 0x50, 0xF2, 0x01, 0x01, 0x00,
            0x00, 0x50, 0xF2, 0x02,
            0x01, 0x00, 0x00, 0x50, 0xF2, 0x04,
            0x01, 0x00, 0x00, 0x50, 0xF2, 0x02,
            0x00, 0x00
        };
        memcpy(bcn + p, wpaie, sizeof(wpaie)); p += (int)sizeof(wpaie);
    }
    {   /* HT Capabilities IE (45), 26 байт */
        bcn[p++] = 45; bcn[p++] = 26;
        memset(bcn + p, 0, 26); p += 26;
    }
    int bl = p;

    wifi_scan_start();
    int cur = 1;
    while (cur < SIM_CHANNEL) { advance(200); wifi_poll(); cur++; }
    sim_inject_rx(bcn, bl, 0x00);
    advance(21); wifi_poll();
    while (cur <= 14) { advance(200); wifi_poll(); cur++; }
    { int guard = 0;
      while (wifi_scan_active() && guard++ < 120) { advance(200); wifi_poll(); } }
    CHECK(!wifi_scan_active(), "скан завершён");

    CHECK(wifi_connect_psk("SecureHT", "password1") == 1, "подключение к SecureHT");
    /* [ATH-SCAN2] + [W-AUTHDWELL]: скан (до двух проходов), PREAUTH/PROBE */
    conn_wait_auth(300);
    CHECK(wifi_conn_state() == WIFI_CONN_AUTH, "AUTH отправлен");

    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_ASSOC, "AUTH ok -> ASSOC REQ");

    int t = last_tx_of_type(0);
    CHECK(t >= 0, "ASSOC REQ захвачен");
    if (t >= 0) {
        u16 cap = (u16)(sim_tx[t].frame[24] | (sim_tx[t].frame[25] << 8));
        CHECK((cap & 0x0400) != 0, "Short Slot Time зеркален (0x0400)");
        CHECK((cap & 0x0010) != 0, "Privacy зеркален (0x0010)");
        int q = 28;
        int ie_ht = 0, ie_rsn = 0, ie_wpa = 0, ie_wmm = 0, sel_in_rates = 0;
        u8 got[24]; int got_n = 0;
        while (q + 2 <= sim_tx[t].len) {
            u8 tag = sim_tx[t].frame[q];
            u8 tl = sim_tx[t].frame[q + 1];
            const u8 *v = sim_tx[t].frame + q + 2;
            if ((tag == 1 || tag == 50) && got_n + tl <= (int)sizeof(got)) {
                for (int k = 0; k < tl; k++) {
                    if (v[k] == 0x7F || v[k] == 0x7E) sel_in_rates = 1;
                    got[got_n++] = v[k];
                }
            } else if (tag == 45) ie_ht = 1;
            else if (tag == 48 && tl >= 8)
                ie_rsn = (memcmp(v + 2, "\x00\x0F\xAC\x02", 4) == 0);
            else if (tag == 221 && tl >= 7) {
                if (memcmp(v, "\x00\x50\xF2\x01", 4) == 0) ie_wpa = 1;
                if (memcmp(v, "\x00\x50\xF2\x02\x00", 5) == 0) ie_wmm = 1;
            }
            q += 2 + tl;
        }
        static const u8 want[] = { 0x82, 0x84, 0x8B, 0x0C, 0x12, 0x96, 0x18,
                                   0x24, 0x30, 0x48, 0x60, 0x6C };
        CHECK(got_n == (int)sizeof(want) && memcmp(got, want, sizeof(want)) == 0,
              "рейты = полный b/g отсортированный");
        CHECK(!sel_in_rates, "селектор 0x7F НЕ попал в рейты ASSOC REQ");
        CHECK(ie_ht, "HT Capabilities IE (45) в ASSOC REQ");
        CHECK(ie_rsn, "RSN IE (48) с группой TKIP (как у точки)");
        /* СЕССИЯ 50: RSN-only ассоциация — WPA IE больше НЕ шлём по
         * умолчанию (Ralink с двумя IE выбирает свой WPA-режим);
         * WPA IE возвращается только fallback'ом после отказа assoc */
        CHECK(!ie_wpa, "WPA IE НЕ в ассоциации (RSN-only, сессия 50)");
        CHECK(ie_wmm, "WMM IE (221/00:50:F2:02) в ASSOC REQ");
    }

    sim_inject_rx(fr, make_assoc_resp(fr, 0xC004), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY,
          "11n-точка приняла ассоциацию (ждём 4-way)");
    wifi_disconnect();
}

/* ---- СЕССИЯ 43: A-MSDU — QoS-кадр с двумя поддкадрами разворачивается
 * в два ethernet-кадра (HT-точки агрегируют данные) ---- */
static void test_amsdu_rx(void) {
    printf("== СЕССИЯ 43: A-MSDU RX ==\n");
    wifi_disconnect();
    {
        static const u8 nb[6] = { 0xc0, 0x25, 0xe9, 0x43, 0x77, 0x33 };
        memcpy(cur_bssid, nb, 6);
    }
    static const u8 r1[] = { 0x82, 0x84, 0x8B, 0x96 };
    static const u8 r2[] = { 0x0C, 0x12, 0x18, 0x24, 0x30, 0x48, 0x60, 0x6C };
    u8 bcn[160];
    int bl = make_beacon_rates(bcn, "OpenMSDU", SIM_CHANNEL,
                               r1, (int)sizeof(r1), r2, (int)sizeof(r2),
                               0x0021);
    wifi_scan_start();
    int cur = 1;
    while (cur < SIM_CHANNEL) { advance(200); wifi_poll(); cur++; }
    sim_inject_rx(bcn, bl, 0x00);
    advance(21); wifi_poll();
    while (cur <= 14) { advance(200); wifi_poll(); cur++; }
    CHECK(wifi_connect_psk("OpenMSDU", NULL) == 1, "подключение к открытой OpenMSDU");
    conn_wait_auth(60);                       /* SCAN->PREAUTH->PROBE->AUTH */
    CHECK(wifi_conn_state() == WIFI_CONN_AUTH, "AUTH отправлен (OpenMSDU)");
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC005), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "CONNECTED (открытая)");

    /* A-MSDU: QoS data FromDS, бит AMSDU в QoS ctrl */
    static const u8 da1[6] = { 0x02, 0x11, 0x22, 0x33, 0x44, 0x01 };
    static const u8 sa1[6] = { 0xc0, 0x25, 0xe9, 0x43, 0x77, 0x33 };
    static const u8 da2[6] = { 0x02, 0x11, 0x22, 0x33, 0x44, 0x02 };
    u8 pl[80];
    u8 ams[512];
    memset(ams, 0, sizeof(ams));
    ams[0] = 0x88; ams[1] = 0x02;              /* QoS data, FromDS */
    memcpy(ams + 4, sim_mac, 6);               /* addr1 = DA (мы) */
    memcpy(ams + 10, cur_bssid, 6);
    memcpy(ams + 16, sa1, 6);                  /* addr3 = SA */
    ams[24] = 0x00; ams[25] = 0x80;            /* QoS ctrl: A-MSDU present */
    int q = 26;
    /* поддкадр 1: LLC/SNAP + 10 байт данных (без паддинга: 18 % 4 == 2) */
    memcpy(ams + q, da1, 6); memcpy(ams + q + 6, sa1, 6);
    pl[0]=0xAA; pl[1]=0xAA; pl[2]=0x03; pl[3]=0; pl[4]=0; pl[5]=0;
    pl[6]=0x08; pl[7]=0x00;
    for (int k = 0; k < 10; k++) pl[8 + k] = (u8)(0x40 + k);
    u32 l1 = 8 + 10;
    ams[q + 12] = (u8)(l1 & 0xff); ams[q + 13] = (u8)(l1 >> 8);
    memcpy(ams + q + 14, pl, l1); q += 14 + (int)l1;
    q += (4 - (l1 & 3)) & 3;                   /* паддинг до 4 */
    /* поддкадр 2: 20 байт данных (28 % 4 == 0 — без паддинга) */
    memcpy(ams + q, da2, 6); memcpy(ams + q + 6, sa1, 6);
    for (int k = 0; k < 20; k++) pl[8 + k] = (u8)(0x60 + k);
    u32 l2 = 8 + 20;
    ams[q + 12] = (u8)(l2 & 0xff); ams[q + 13] = (u8)(l2 >> 8);
    memcpy(ams + q + 14, pl, l2); q += 14 + (int)l2;
    int alen = q;

    sim_inject_rx(ams, alen, 0x0c);
    advance(21); wifi_poll();

    u8 eth[1600];
    u32 n = wifi_net_recv(eth, sizeof(eth));
    CHECK(n == 14 + l1 - 8, "A-MSDU кадр 1: длина eth (14 + данные без LLC)");
    if (n == 14 + l1 - 8) {
        CHECK(memcmp(eth, da1, 6) == 0, "кадр 1: dst из поддкадра");
        CHECK(memcmp(eth + 6, sa1, 6) == 0, "кадр 1: src из поддкадра");
        CHECK(eth[12] == 0x08 && eth[13] == 0x00, "кадр 1: ethertype IPv4");
        CHECK(eth[14] == 0x40, "кадр 1: данные на месте");
    }
    n = wifi_net_recv(eth, sizeof(eth));
    CHECK(n == 14 + l2 - 8, "A-MSDU кадр 2: длина eth");
    if (n == 14 + l2 - 8) {
        CHECK(memcmp(eth, da2, 6) == 0, "кадр 2: dst из поддкадра");
        CHECK(eth[14] == 0x60, "кадр 2: данные на месте");
    }
    n = wifi_net_recv(eth, sizeof(eth));
    CHECK(n == 0, "A-MSDU: больше кадров нет");
    wifi_disconnect();
}

/* ============ СЕССИЯ 45: WPA-протокол (дескриптор 254) ============ */

static void test_wpa_crypto_vectors(void) {
    printf("== криптопримитивы WPA (MD5/HMAC-MD5/RC4/ct_equal/парсер) ==\n");
    /* RFC 2202, HMAC-MD5 */
    {   u8 key[16]; memset(key, 0x0b, 16);
        u8 mac[16];
        wpa2_hmac_md5(key, 16, (const u8 *)"Hi There", 8, mac);
        static const u8 exp[16] = { 0x92,0x94,0x72,0x7a,0x36,0x38,0xbb,0x1c,
                                    0x13,0xf4,0x8e,0xf8,0x15,0x8b,0xfc,0x9d };
        CHECK(memcmp(mac, exp, 16) == 0, "HMAC-MD5 RFC2202 #1");
    }
    {   u8 mac[16];
        wpa2_hmac_md5((const u8 *)"Jefe", 4,
                      (const u8 *)"what do ya want for nothing?", 28, mac);
        static const u8 exp[16] = { 0x75,0x0c,0x78,0x3e,0x6a,0xb0,0xb5,0x03,
                                    0xea,0xa8,0x6e,0x31,0x0a,0x5d,0xb7,0x38 };
        CHECK(memcmp(mac, exp, 16) == 0, "HMAC-MD5 RFC2202 #2");
    }
    {   u8 key[80]; memset(key, 0xaa, 80);
        u8 mac[16];
        wpa2_hmac_md5(key, 80,
                      (const u8 *)"Test Using Larger Than Block-Size Key - Hash Key First",
                      54, mac);
        static const u8 exp[16] = { 0x6b,0x1a,0xb7,0xfe,0x4b,0xd7,0xbf,0x8f,
                                    0x0b,0x62,0xe6,0xce,0x61,0xb9,0xd0,0xcd };
        CHECK(memcmp(mac, exp, 16) == 0, "HMAC-MD5 RFC2202 #6 (key>64)");
    }
    /* RC4: известный вектор */
    {   u8 buf[9];
        memcpy(buf, "Plaintext", 9);
        wpa2_rc4_skip((const u8 *)"Key", 3, 0, buf, 9);
        static const u8 exp[9] = { 0xBB,0xF3,0x16,0xE8,0xD9,0x40,0xAF,0x0A,0xD3 };
        CHECK(memcmp(buf, exp, 9) == 0, "RC4 вектор (Key/Plaintext)");
        u8 b2[9];
        memcpy(b2, "Plaintext", 9);
        wpa2_rc4_skip((const u8 *)"Key", 3, 256, b2, 9);
        CHECK(memcmp(b2, exp, 9) != 0, "RC4 skip=256 меняет поток");
        wpa2_rc4_skip((const u8 *)"Key", 3, 256, b2, 9);
        CHECK(memcmp(b2, "Plaintext", 9) == 0, "RC4 self-inverse (тот же skip)");
    }
    CHECK(wpa2_ct_equal("\x01\x02\x03", "\x01\x02\x03", 3) == 1, "ct_equal: равны");
    CHECK(wpa2_ct_equal("\x01\x02\x03", "\x01\x02\x04", 3) == 0, "ct_equal: не равны");
    /* парсер: дескриптор 254 принимается, 1 — нет */
    {   static const u8 rep[8] = { 1,0,0,0,0,0,0,0 };
        u8 m[256];
        u32 n = wpa2_build_eapol_key_ex(m, sim_bssid, sim_mac, 254,
                                        0x008a, 16, NULL, rep, NULL, 0);
        eapol_key_t k;
        CHECK(wpa2_parse_eapol_key(m, n, &k) == 1, "парсер: WPA-дескриптор 254");
        CHECK(k.desc_type == 254 && k.key_info == 0x008a, "поля M1 WPA прочитаны");
        m[18] = 1;
        CHECK(wpa2_parse_eapol_key(m, n, &k) == 0,
              "парсер: неизвестный дескриптор отброшен");
    }
}

/* Полное рукопожатие WPA-протокола (дескриптор 254, ver 2 = пара CCMP,
 * группа TKIP) — как у смешанной точки из лога пользователя
 * (desc=254 ki=0x008a). Канон: wpa_supplicant_process_1_of_4_wpa /
 * 3_of_4_wpa / 1_of_2_wpa. */
static void test_connect_wpa_mixed(void) {
    printf("== WPA (дескриптор 254): M1→M2→M3→M4→групповой ключ ==\n");
    wifi_disconnect();
    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "подключение к WPA-точке");
    for (int i = 0; i < 40 && wifi_conn_state() != WIFI_CONN_AUTH; i++) {
        advance(200); wifi_poll();
    }
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC003), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ждём 4-way (WPA)");

    u8 pmk[32];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);

    /* ---- M1: дескриптор 254, ver 2, ki=0x008a — точно как в логе ---- */
    u8 anonce[32];
    memset(anonce, 0xC3, sizeof(anonce));
    static const u8 rep1[8] = { 1,0,0,0,0,0,0,0 };
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key_ex(m1, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK,
                                        16, anonce, rep1, NULL, 0);
    m1[14] = 1;   /* как у реальной WPA-точки: EAPOL version 1 */
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "WPA M1 принят (дескриптор 254)");

    /* ---- M2: WPA IE в key data, дескриптор 254, Key Length = эхо ---- */
    int t = last_tx_of_type(2);
    CHECK(t >= 0, "EAPOL M2 передан (WPA)");
    const u8 *e = sim_tx[t].frame + 24 + 8;
    CHECK(e[0] == 1, "M2: EAPOL version = 1 (эхо точки)");
    CHECK(e[4] == 254, "M2: дескриптор 254");
    CHECK(((u32)e[2] << 8 | e[3]) == 95 + 26, "EAPOL Length M2 = 121 (95+WPA IE)");
    CHECK(e[7] == 0 && e[8] == 16, "M2: Key Length = 16 (эхо M1)");
    CHECK(e[9] == 0x01, "M2: replay counter M1");
    {   /* WPA IE (DD 18 00:50:F2:01) в key data (смещение 14+4+95 от eth) */
        u32 kd = 14 + 4 + 95 - 14;           /* от начала EAPOL */
        CHECK(e[kd] == 0xDD && e[kd + 1] == 24 &&
              memcmp(e + kd + 2, "\x00\x50\xF2\x01", 4) == 0,
              "M2: WPA IE в key data");
    }
    u8 snonce[32];
    memcpy(snonce, e + 17, 32);
    u8 ptk[48];
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce, snonce, ptk);
    {
        u8 mic[16];
        static u8 tmp[1600];
        int elen = sim_tx[t].len - 24 - 8;
        memcpy(tmp + 14, e, (size_t)elen);
        memset(tmp + 95, 0, 16);
        wpa2_eapol_mic(ptk, tmp, (u32)(elen + 14), mic);
        CHECK(memcmp(mic, e + 81, 16) == 0, "MIC M2 сходится (KCK, WPA)");
    }

    /* ---- M3: как в ЛОГЕ пользователя (ki=0x01ca = ver|pairwise|
     * install|ack|mic, БЕЗ Secure), key data ПУСТОЙ (GTK не в M3) ---- */
    static const u8 rep2[8] = { 2,0,0,0,0,0,0,0 };
    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key_ex(m3, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK | WPA2_KI_MIC |
                                        WPA2_KI_INSTALL,
                                        16, anonce, rep2, NULL, 0);
    m3[14] = 1;   /* как у реальной WPA-точки: EAPOL version 1 */
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY,
          "WPA: после M3 ещё ждём групповой ключ (не CONNECTED)");
    {   /* M4 передан: replay M3, Key Length эхо; Secure НЕ эхо — в M3 его
         * не было (ki=0x01ca), M4 = ver|pairwise|MIC = 0x010A */
        int t4 = last_tx_of_type(2);
        CHECK(t4 > t, "M4 передан (WPA)");
        const u8 *e4 = sim_tx[t4].frame + 24 + 8;
        CHECK(e4[0] == 1, "M4: EAPOL version = 1 (эхо)");
        CHECK(e4[4] == 254, "M4: дескриптор 254");
        CHECK(((u32)e4[2] << 8 | e4[3]) == 95, "EAPOL Length M4 = 95");
        CHECK(e4[7] == 0 && e4[8] == 16, "M4: Key Length = 16 (эхо)");
        CHECK(e4[9] == 0x02, "M4: replay counter M3");
        u16 ki4 = (u16)(((u32)e4[5] << 8) | e4[6]);
        CHECK(ki4 == 0x010A, "M4: ver|pairwise|MIC (Secure эхом = 0)");
    }

    /* ---- Групповой M1: GTK TKIP 32 б, AES-KW (ver 2) ---- */
    u8 gtk[32];
    memset(gtk, 0x9D, sizeof(gtk));
    u8 wrapped[40];
    wpa2_aes_wrap(ptk + 16, gtk, 32, wrapped);   /* 32 + IV 8 = 40 */
    static const u8 rep3[8] = { 3,0,0,0,0,0,0,0 };
    u8 m4[320];
    u32 m4len = wpa2_build_eapol_key_ex(m4, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_ACK |
                                        WPA2_KI_MIC | WPA2_KI_SECURE |
                                        (1u << 4),   /* keyidx 1 */
                                        32, NULL, rep3, wrapped, 40);
    m4[14] = 1;   /* EAPOL version 1 */
    memset(m4 + 14 + 81, 0, 16);
    u8 mic4[16];
    wpa2_eapol_mic(ptk, m4, (u32)m4len, mic4);
    memcpy(m4 + 14 + 81, mic4, 16);
    u8 d4[1600];
    sim_inject_rx(d4, make_data_from_ap(d4, m4 + 12, m4len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED,
          "групповой M1 принят → CONNECTED");
    CHECK(wifi_conn_secured() == 1, "ключи установлены (WPA)");
    {   int tg = last_tx_of_type(2);
        CHECK(tg > t, "групповой M2 передан");
        const u8 *eg = sim_tx[tg].frame + 24 + 8;
        CHECK(eg[4] == 254, "group-M2: дескриптор 254");
        CHECK(((u32)eg[2] << 8 | eg[3]) == 95, "EAPOL Length group-M2 = 95");
        CHECK(eg[7] == 0 && eg[8] == 32, "group-M2: Key Length = 32 (эхо)");
        CHECK(eg[9] == 0x03, "group-M2: replay counter группового M1");
        u16 kig = (u16)(((u32)eg[5] << 8) | eg[6]);
        CHECK((kig & WPA2_KI_SECURE) != 0 && (kig & WPA2_KI_MIC) != 0 &&
              (kig & WPA2_KI_KEY_TYPE) == 0,
              "group-M2: Secure+MIC без pairwise-бита");
    }
    {   u32 expect = (u32)gtk[0] | ((u32)gtk[1] << 8) |
                     ((u32)gtk[2] << 16) | ((u32)gtk[3] << 24);
        int found = 0;
        for (int i = 0; i < 8; i++)
            if (sim_cam[i][2] == expect) { found = 1; break; }
        CHECK(found, "CAM содержит GTK TK (TKIP)");
    }

    /* ---- REKEY: групповой M1 с ver 1 (RC4-путь, HMAC-MD5 MIC) ---- */
    {
        u8 gtk2[32];
        memset(gtk2, 0x3C, sizeof(gtk2));
        u8 kd2[32];
        memcpy(kd2, gtk2, 32);
        u8 ek[32];
        memset(ek, 0x11, 16);                    /* Key IV */
        memcpy(ek + 16, ptk + 16, 16);           /* KEK */
        wpa2_rc4_skip(ek, 32, 256, kd2, 32);
        static const u8 rep5[8] = { 5,0,0,0,0,0,0,0 };
        u8 m5[256];
        u32 m5len = wpa2_build_eapol_key_ex(m5, sim_mac, sim_bssid, 254,
                                            1 | WPA2_KI_ACK | WPA2_KI_MIC |
                                            WPA2_KI_SECURE | (1u << 4),
                                            32, NULL, rep5, kd2, 32);
        memcpy(m5 + 14 + 49, ek, 16);            /* Key IV в дескрипторе */
        m5[14] = 1;                              /* EAPOL version 1 */
        memset(m5 + 14 + 81, 0, 16);
        u8 mic5[16];
        wpa2_eapol_mic2(1, ptk, m5, (u32)m5len, mic5);
        memcpy(m5 + 14 + 81, mic5, 16);
        u8 d5[1600];
        sim_inject_rx(d5, make_data_from_ap(d5, m5 + 12, m5len - 12, 0), 0x0c);
        advance(21); wifi_poll();
        CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "rekey: состояние сохранено");
        {   int t5 = last_tx_of_type(2);
            CHECK(t5 > 0, "групповой M2 (rekey) передан");
            const u8 *e5 = sim_tx[t5].frame + 24 + 8;
            CHECK(e5[4] == 254, "group-M2 rekey: дескриптор 254");
            CHECK(e5[9] == 0x05, "group-M2 rekey: replay эхо");
            CHECK(e5[7] == 0 && e5[8] == 32, "group-M2 rekey: Key Length 32");
            u16 ki5 = (u16)(((u32)e5[5] << 8) | e5[6]);
            CHECK((ki5 & 7) == 1 && (ki5 & WPA2_KI_MIC) &&
                  (ki5 & WPA2_KI_SECURE) && !(ki5 & WPA2_KI_KEY_TYPE),
                  "group-M2 rekey: ver1+MIC+SECURE, без pairwise");
        }
        {   u32 expect = (u32)gtk2[0] | ((u32)gtk2[1] << 8) |
                         ((u32)gtk2[2] << 16) | ((u32)gtk2[3] << 24);
            int found = 0;
            for (int i = 0; i < 8; i++)
                if (sim_cam[i][2] == expect) { found = 1; break; }
            CHECK(found, "CAM: новый GTK (RC4-путь ver 1) установлен");
        }
    }
    advance(100); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "соединение стабильно");
    wifi_disconnect();
}

/* СЕССИЯ 47: некоторые WPA-точки кладут GTK прямо в M3 (KDE 00:50:F2:01)
 * и НЕ запускают групповое рукопожатие — ключи должны ставиться сразу
 * после M4. */
static void test_connect_wpa_gtk_in_m3(void) {
    printf("== WPA: GTK в M3 (KDE) — CONNECTED без группового M1 ==\n");
    wifi_disconnect();
    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "подключение (GTK в M3)");
    for (int i = 0; i < 40 && wifi_conn_state() != WIFI_CONN_AUTH; i++) {
        advance(200); wifi_poll();
    }
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC004), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ждём 4-way (GTK в M3)");

    u8 pmk[32];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);

    u8 anonce[32];
    memset(anonce, 0xE1, sizeof(anonce));
    static const u8 rep1[8] = { 1,0,0,0,0,0,0,0 };
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key_ex(m1, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK,
                                        16, anonce, rep1, NULL, 0);
    m1[14] = 1;
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M1 принят");

    int t = last_tx_of_type(2);
    CHECK(t >= 0, "M2 передан");
    const u8 *e = sim_tx[t].frame + 24 + 8;
    CHECK(e[0] == 1, "M2: EAPOL version = 1 (эхо)");
    u8 snonce[32];
    memcpy(snonce, e + 17, 32);
    u8 ptk[48];
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce, snonce, ptk);

    /* M3 с GTK KDE: DD 16 00:50:F2:01 [keyid][reserved] GTK16 */
    u8 gtk[16];
    memset(gtk, 0x5E, sizeof(gtk));
    u8 kd[32];
    kd[0] = 0xDD; kd[1] = 22;
    memcpy(kd + 2, "\x00\x50\xF2\x01", 4);
    kd[6] = 0x01; kd[7] = 0x00;                    /* keyid 1 (реальный) */
    memcpy(kd + 8, gtk, 16);
    static const u8 rep2[8] = { 2,0,0,0,0,0,0,0 };
    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key_ex(m3, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK | WPA2_KI_MIC |
                                        WPA2_KI_INSTALL,
                                        16, anonce, rep2, kd, 24);   /* DD+L+22 = полный элемент */
    m3[14] = 1;
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED,
          "M3 с GTK KDE → CONNECTED (без группового M1)");
    CHECK(wifi_conn_secured() == 1, "ключи установлены (GTK из M3)");
    {   int t4 = last_tx_of_type(2);
        CHECK(t4 > t, "M4 передан");
        const u8 *e4 = sim_tx[t4].frame + 24 + 8;
        CHECK(e4[0] == 1, "M4: EAPOL version = 1 (эхо)");
        CHECK(e4[4] == 254, "M4: дескриптор 254");
        CHECK(((u32)e4[2] << 8 | e4[3]) == 95, "EAPOL Length M4 = 95");
    }
    {   u32 expect = (u32)gtk[0] | ((u32)gtk[1] << 8) |
                     ((u32)gtk[2] << 16) | ((u32)gtk[3] << 24);
        int found = 0;
        for (int i = 0; i < 8; i++)
            if (sim_cam[i][2] == expect) { found = 1; break; }
        CHECK(found, "CAM содержит GTK из M3");
    }
    wifi_disconnect();
}


/* СЕССИЯ 48: TKIP-пара (ver 1) — PTK-64, MIC HMAC-MD5, групповой ключ
 * ver 1 (RC4). Родной режим старых WPA-точек (их WPA IE начинается
 * с TKIP). */
static void test_connect_wpa_tkip_pair(void) {
    printf("== WPA: TKIP-пара (ver 1): PTK-64 → групповой ключ RC4 ==\n");
    wifi_disconnect();
    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "подключение (TKIP-пара)");
    for (int i = 0; i < 40 && wifi_conn_state() != WIFI_CONN_AUTH; i++) {
        advance(200); wifi_poll();
    }
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC005), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ждём 4-way (TKIP-пара)");

    u8 pmk[32];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);

    /* M1: ver 1, ki=0x0089 = ver1|pairwise|ACK */
    u8 anonce[32];
    memset(anonce, 0xD4, sizeof(anonce));
    static const u8 rep1[8] = { 1,0,0,0,0,0,0,0 };
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key_ex(m1, sim_mac, sim_bssid, 254,
                                        1 | WPA2_KI_KEY_TYPE | WPA2_KI_ACK,
                                        16, anonce, rep1, NULL, 0);
    m1[14] = 1;
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M1 (ver 1, TKIP-пара) принят");

    /* M2: ki=0x0109, MIC = HMAC-MD5 по KCK из PTK-64 */
    int t = last_tx_of_type(2);
    CHECK(t >= 0, "M2 передан (TKIP-пара)");
    const u8 *e = sim_tx[t].frame + 24 + 8;
    CHECK(e[0] == 1, "M2: EAPOL version = 1 (эхо)");
    CHECK(e[4] == 254, "M2: дескриптор 254");
    {   u16 ki2 = (u16)(((u32)e[5] << 8) | e[6]);
        CHECK(ki2 == 0x0109, "M2: ki = ver1|pairwise|MIC");
    }
    u8 snonce[32];
    memcpy(snonce, e + 17, 32);
    u8 ptk[64];
    wpa2_derive_ptk_ex(pmk, sim_bssid, sim_mac, anonce, snonce, ptk, 64);
    {
        u8 mic[16];
        static u8 tmp[1600];
        int elen = sim_tx[t].len - 24 - 8;
        memcpy(tmp + 14, e, (size_t)elen);
        memset(tmp + 95, 0, 16);
        wpa2_eapol_mic2(1, ptk, tmp, (u32)(elen + 14), mic);
        CHECK(memcmp(mic, e + 81, 16) == 0, "MIC M2 сходится (HMAC-MD5, PTK-64)");
    }

    /* M3: ver 1, ki=0x01C9, без key data */
    static const u8 rep2[8] = { 2,0,0,0,0,0,0,0 };
    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key_ex(m3, sim_mac, sim_bssid, 254,
                                        1 | WPA2_KI_KEY_TYPE | WPA2_KI_ACK |
                                        WPA2_KI_MIC | WPA2_KI_INSTALL,
                                        16, anonce, rep2, NULL, 0);
    m3[14] = 1;
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic2(1, ptk, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY,
          "WPA: после M3 ждём групповой ключ (TKIP-пара)");
    {   int t4 = last_tx_of_type(2);
        CHECK(t4 > t, "M4 передан (TKIP-пара)");
        const u8 *e4 = sim_tx[t4].frame + 24 + 8;
        CHECK(e4[0] == 1, "M4: EAPOL version = 1 (эхо)");
        {   u16 ki4 = (u16)(((u32)e4[5] << 8) | e4[6]);
            CHECK(ki4 == 0x0109, "M4: ki = ver1|pairwise|MIC");
        }
        CHECK(e4[9] == 0x02, "M4: replay counter M3");
    }

    /* групповой M1: ver 1, ki=0x0391 (keyidx=1 — как у реальных точек),
     * GTK32 зашифрован RC4 (KeyIV||KEK, 256) */
    u8 gtk[32];
    memset(gtk, 0x6F, sizeof(gtk));
    u8 kd2[32];
    memcpy(kd2, gtk, 32);
    u8 ek[32];
    memset(ek, 0x22, 16);                    /* Key IV */
    memcpy(ek + 16, ptk + 16, 16);           /* KEK */
    wpa2_rc4_skip(ek, 32, 256, kd2, 32);
    static const u8 rep3[8] = { 3,0,0,0,0,0,0,0 };
    u8 m4[320];
    u32 m4len = wpa2_build_eapol_key_ex(m4, sim_mac, sim_bssid, 254,
                                        1 | WPA2_KI_ACK | WPA2_KI_MIC |
                                        WPA2_KI_SECURE | (1u << 4),
                                        32, NULL, rep3, kd2, 32);
    memcpy(m4 + 14 + 49, ek, 16);            /* Key IV в дескрипторе */
    m4[14] = 1;
    memset(m4 + 14 + 81, 0, 16);
    u8 mic4[16];
    wpa2_eapol_mic2(1, ptk, m4, (u32)m4len, mic4);
    memcpy(m4 + 14 + 81, mic4, 16);
    u8 d4[1600];
    sim_inject_rx(d4, make_data_from_ap(d4, m4 + 12, m4len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED,
          "групповой M1 (RC4, ver 1) → CONNECTED");
    CHECK(wifi_conn_secured() == 1, "ключи установлены (TKIP-пара)");
    {   u32 expect = (u32)ptk[32] | ((u32)ptk[33] << 8) |
                     ((u32)ptk[34] << 16) | ((u32)ptk[35] << 24);
        CHECK(sim_cam[0][2] == expect, "CAM[0] содержит TK TKIP-пары (СЕССИЯ 52)");
    }
    {   /* СЕССИЯ 52: бродкаст при TKIP-паре = PTK: TKIP IV keyid=0,
         * sec RC4, Michael в хвосте с TX-MIC (ptk+56) */
        u8 eth[80];
        memset(eth, 0, sizeof(eth));
        memset(eth, 0xff, 6);
        eth[6] = sim_mac[0]; eth[7] = sim_mac[1]; eth[8] = sim_mac[2];
        eth[9] = sim_mac[3]; eth[10] = sim_mac[4]; eth[11] = sim_mac[5];
        eth[12] = 0x08; eth[13] = 0x00;
        for (int i = 14; i < 80; i++) eth[i] = (u8)(i * 3);
        CHECK(wifi_net_send(eth, 80) == 80, "бродкаст TX (TKIP-пара)");
        int tb = last_tx_of_type(2);
        CHECK(tb >= 0, "бродкаст захвачен (TKIP-пара)");
        CHECK(memcmp(sim_tx[tb].frame + 24,
                     "\x00\x20\x01\x20\x00\x00\x00\x00", 8) == 0,
              "бродкаст TKIP IV (iv16=1, keyid=0 — PTK)");
        u32 sec = ((u32)sim_tx[tb].desc[6] << 16);
        CHECK((sec & 0x00C00000) == TXDESC_SEC_RC4,
              "бродкаст: sec_type = RC4 (TKIP-пара)");
        int fl = sim_tx[tb].len;
        u8 mic8[8];
        wpa2_tkip_michael(ptk + 56, eth, eth + 6,
                          sim_tx[tb].frame + 32, (u32)(fl - 32 - 8), mic8);
        CHECK(fl > 40 && memcmp(sim_tx[tb].frame + fl - 8, mic8, 8) == 0,
              "Michael в хвосте (TX-MIC = ptk+56)");
    }
    advance(100); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "соединение стабильно");
    wifi_disconnect();
}


/* СЕССИЯ 49: точка, сверяющая IE в key data M2 с СОБСТВЕННЫМ WPA IE —
 * после M3 мы повторяем M2 с эхом её IE (из key data M3), затем M4.
 * hostapd такой лишний M2 безболезненно роняет по состоянию. */
static void test_connect_wpa_ie_echo(void) {
    printf("== WPA: повторный M2 с WPA IE точки (после M3) ==\n");
    wifi_disconnect();
    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "подключение (эхо IE)");
    for (int i = 0; i < 40 && wifi_conn_state() != WIFI_CONN_AUTH; i++) {
        advance(200); wifi_poll();
    }
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC006), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ждём 4-way (эхо IE)");

    u8 pmk[32];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);

    /* M1 ver2 (как в логе: ki=0x008a) */
    u8 anonce[32];
    memset(anonce, 0xE7, sizeof(anonce));
    static const u8 rep1[8] = { 1,0,0,0,0,0,0,0 };
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key_ex(m1, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK,
                                        16, anonce, rep1, NULL, 0);
    m1[14] = 1;
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M1 принят");

    int t = last_tx_of_type(2);
    CHECK(t >= 0, "M2 передан");
    const u8 *e = sim_tx[t].frame + 24 + 8;
    CHECK(e[9] == 0x01, "M2: replay M1");
    u8 snonce[32];
    memcpy(snonce, e + 17, 32);
    u8 ptk[48];
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce, snonce, ptk);

    /* M3 с WPA IE ТОЧКИ в key data (28 б, как в логе пользователя) */
    static const u8 apie[28] = {
        0xDD, 0x1A, 0x00, 0x50, 0xF2, 0x01, 0x01, 0x00,
        0x00, 0x50, 0xF2, 0x02, 0x02, 0x00, 0x00, 0x50,
        0xF2, 0x02, 0x00, 0x50, 0xF2, 0x04, 0x01, 0x00,
        0x00, 0x50, 0xF2, 0x02 };
    static const u8 rep2[8] = { 2,0,0,0,0,0,0,0 };
    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key_ex(m3, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK | WPA2_KI_MIC |
                                        WPA2_KI_INSTALL,
                                        16, anonce, rep2, apie, 28);
    m3[14] = 1;
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M3 принят (ждём повтор M2)");

    /* повторный M2 (replay M1, kd = IE точки) + M4 (replay M3) */
    int t4 = -1;
    {   t4 = last_tx_of_type(2);
        CHECK(t4 > t, "кадры после M3 переданы");
        int tm2 = -1;
        for (int i = t4 - 1; i >= 0; i--) {
            u16 fc = (u16)(sim_tx[i].frame[0] | (sim_tx[i].frame[1] << 8));
            if (((fc >> 2) & 3) == 2) { tm2 = i; break; }
        }
        CHECK(tm2 >= 0 && tm2 < t4, "повторный M2 передан");
        if (tm2 >= 0) {
            const u8 *em = sim_tx[tm2].frame + 24 + 8;
            CHECK(em[9] == 0x01, "повторный M2: replay M1");
            CHECK(((u32)em[2] << 8 | em[3]) == 95 + 28,
                  "повторный M2: kd = 28 (IE точки)");
            CHECK(memcmp(em + 99, apie, 28) == 0,
                  "повторный M2: IE точки байт-в-байт");
            {   u8 mic[16];
                static u8 tmp[1600];
                int elen = sim_tx[tm2].len - 24 - 8;
                memcpy(tmp + 14, em, (size_t)elen);
                memset(tmp + 95, 0, 16);
                wpa2_eapol_mic(ptk, tmp, (u32)(elen + 14), mic);
                CHECK(memcmp(mic, em + 81, 16) == 0,
                      "MIC повторного M2 сходится (KCK)");
            }
        }
        const u8 *e4 = sim_tx[t4].frame + 24 + 8;
        CHECK(e4[9] == 0x02, "M4: replay M3");
    }

    /* второй M3 (ретрансляция точки) → только M4, без нового M2 */
    u8 d3b[1600];
    sim_inject_rx(d3b, make_data_from_ap(d3b, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    {   int t5 = last_tx_of_type(2);
        CHECK(t5 > t, "M4 (2) передан");
        const u8 *e5 = sim_tx[t5].frame + 24 + 8;
        CHECK(e5[9] == 0x02, "M4 (2): replay M3");
        int n_data = 0;
        for (int i = 0; i <= t5; i++) {
            u16 fc = (u16)(sim_tx[i].frame[0] | (sim_tx[i].frame[1] << 8));
            if (((fc >> 2) & 3) == 2) n_data++;
        }
        int n_data_before = 0;
        for (int i = 0; i <= t4; i++) {
            u16 fc = (u16)(sim_tx[i].frame[0] | (sim_tx[i].frame[1] << 8));
            if (((fc >> 2) & 3) == 2) n_data_before++;
        }
        CHECK(n_data == n_data_before + 1,
              "на второй M3 — только M4 (повторного M2 нет)");
    }

    /* групповой M1 (ver2, AES-KW GTK32) → CONNECTED */
    u8 gtk[32];
    memset(gtk, 0x8A, sizeof(gtk));
    u8 wrapped[40];
    wpa2_aes_wrap(ptk + 16, gtk, 32, wrapped);
    static const u8 rep3[8] = { 3,0,0,0,0,0,0,0 };
    u8 m4[320];
    u32 m4len = wpa2_build_eapol_key_ex(m4, sim_mac, sim_bssid, 254,
                                        WPA2_KI_VER_AES | WPA2_KI_ACK |
                                        WPA2_KI_MIC | WPA2_KI_SECURE |
                                        (1u << 4),   /* keyidx 1 */
                                        32, NULL, rep3, wrapped, 40);
    m4[14] = 1;
    memset(m4 + 14 + 81, 0, 16);
    u8 mic4[16];
    wpa2_eapol_mic(ptk, m4, (u32)m4len, mic4);
    memcpy(m4 + 14 + 81, mic4, 16);
    u8 d4[1600];
    sim_inject_rx(d4, make_data_from_ap(d4, m4 + 12, m4len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED,
          "групповой M1 → CONNECTED (эхо IE)");
    CHECK(wifi_conn_secured() == 1, "ключи установлены (эхо IE)");
    wifi_disconnect();
}

/* ---- СЕССИЯ 51: ретранслированные M1/M3, эхо RSN IE точки,
 * GTK KDE (канонический, keyid=1, TKIP 32), IV-заголовки TX
 * (CCMP/TKIP по mac80211), Michael MIC TX, RX-хвост по направлению. ---- */
static void test_m1_m3_retx_iv_michael(void) {
    printf("== СЕССИЯ 51: ретрансмиссии M1/M3, эхо RSN IE, IV/Michael ==\n");
    wifi_disconnect();
    memcpy(cur_bssid, sim_bssid, 6);       /* предыдущие тесты меняли */
    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "подключение (RSN IE точки)");
    conn_wait_auth(60);   /* PREAUTH/PROBE окна до AUTH */
    CHECK(wifi_conn_state() == WIFI_CONN_AUTH, "AUTH отправлен");
    u8 fr[512];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp_rsn(fr, 0xC010), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ждём ключи");
    CHECK(wc.ap_rsn_ie_len == 26, "RSN IE точки захвачен из assoc-resp (26 б)");

    /* ---- M1 (replay 01) → M2 с СВОИМ RSN IE (22 б) ---- */
    u8 pmk[32];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);
    u8 anonce[32]; memset(anonce, 0xB7, sizeof(anonce));
    static const u8 rep1[8] = { 1,0,0,0,0,0,0,0 };
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key(m1, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK,
                                     anonce, rep1, NULL, 0);
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M1 принят");
    int t = last_tx_of_type(2);
    CHECK(t >= 0, "первый M2 передан");
    {
        int tl = sim_tx[t].len;
        /* у этой точки (запись скана) группа CCMP — наш IE соберётся
         * с группой CCMP; сверяем с тем же вызовом билдера */
        u8 own_ie[24];
        u32 own_len = wpa2_build_rsn_ie(own_ie, wc.ap_group_tkip,
                                        wc.pairwise_tkip);
        CHECK(own_len == 22, "наш RSN IE = 22 б");
        CHECK(tl >= 24 + 8 + (int)own_len &&
              memcmp(sim_tx[t].frame + tl - own_len, own_ie, own_len) == 0,
              "первый M2 несёт СВОЙ RSN IE");
    }

    /* ---- ретрансмиссия M1 (тот же replay) → M2 с IE ТОЧКИ (26 б) ---- */
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    int t2 = last_tx_of_type(2);
    CHECK(t2 > t, "повторный M2 передан");
    {
        int tl = sim_tx[t2].len;
        CHECK(tl >= 24 + 8 + 26 &&
              memcmp(sim_tx[t2].frame + tl - 26, wc.ap_rsn_ie, 26) == 0,
              "повторный M2 несёт RSN IE ТОЧКИ (26 б, побайтно)");
        const u8 *e = sim_tx[t2].frame + 24 + 8;
        CHECK(memcmp(e + 9, rep1, 8) == 0, "повторный M2: replay = M1");
        u8 sn1[32], sn2[32];
        const u8 *e1 = sim_tx[t].frame + 24 + 8;
        memcpy(sn1, e1 + 17, 32);
        memcpy(sn2, e + 17, 32);
        CHECK(memcmp(sn1, sn2, 32) == 0, "SNonce не меняется между M2");
    }

    /* ---- M3 (RSN): GTK KDE канонический, keyid=1, TKIP 32 б ---- */
    u8 snonce[32];
    {
        const u8 *e = sim_tx[t].frame + 24 + 8;
        memcpy(snonce, e + 17, 32);
    }
    u8 ptk[48];
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce, snonce, ptk);
    u8 gtk[32];
    memset(gtk, 0x71, 16);         /* TK */
    memset(gtk + 16, 0x22, 8);     /* наш RX MIC (KDE: [TK][RX][TX]) */
    memset(gtk + 24, 0x33, 8);     /* наш TX MIC */
    u8 kde[48];
    kde[0] = 0xDD; kde[1] = 38;
    memcpy(kde + 2, "\x00\x0F\xAC\x01", 4);
    kde[6] = 0x01;                 /* keyid 1 */
    kde[7] = 0x00;                 /* reserved */
    memcpy(kde + 8, gtk, 32);
    u8 wrapped[64];
    wpa2_aes_wrap(ptk + 16, kde, 40, wrapped);   /* KEK = ptk+16; 40+8 = 48 */
    static const u8 rep2[8] = { 2,0,0,0,0,0,0,0 };
    u8 m3[320];
    u32 m3len = wpa2_build_eapol_key_ex(m3, sim_mac, sim_bssid, 2,
                                        WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                        WPA2_KI_ACK | WPA2_KI_MIC |
                                        WPA2_KI_INSTALL | WPA2_KI_SECURE |
                                        WPA2_KI_ENCR_DATA,
                                        0, anonce, rep2, wrapped, 48);
    m3[14] = 1;
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk, m3, (u32)m3len, mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "M3 (TKIP GTK, keyid 1) -> CONNECTED");
    CHECK(wc.gtk_is_tkip == 1 && wc.gtk_keyid == 1, "GTK TKIP 32 б, keyid=1 из KDE");

    /* CAM: ячейка 1 (keyid) — флаг группы BIT(6) + MAC=BSSID + свап MIC */
    CHECK((sim_cam[1][0] & 0x40) != 0, "GTK CAM: флаг группового ключа BIT(6)");
    {
        u32 mac01 = (u32)sim_bssid[0] << 16 | (u32)sim_bssid[1] << 24;
        u32 mac1  = (u32)sim_bssid[2] | (u32)sim_bssid[3] << 8 |
                    (u32)sim_bssid[4] << 16 | (u32)sim_bssid[5] << 24;
        CHECK((sim_cam[1][0] & 0xFFFF) == mac01 >> 16 ||
              (sim_cam[1][0] >> 16) == (mac01 >> 16),
              "GTK CAM: старшие байты MAC = BSSID");
        CHECK(sim_cam[1][1] == mac1, "GTK CAM: MAC записи = BSSID");
        u32 tx01 = (u32)gtk[24] | ((u32)gtk[25] << 8) |
                   ((u32)gtk[26] << 16) | ((u32)gtk[27] << 24);
        /* CAM-запись — 6 слов: ctrl+mac (0-1) и ТОЛЬКО 16 б ключа (2-5):
         * для TKIP это TK — Michael в софте (эталон rtl8xxxu) */
        u32 tk01 = (u32)gtk[0] | ((u32)gtk[1] << 8) |
                   ((u32)gtk[2] << 16) | ((u32)gtk[3] << 24);
        u32 tk23 = (u32)gtk[4] | ((u32)gtk[5] << 8) |
                   ((u32)gtk[6] << 16) | ((u32)gtk[7] << 24);
        u32 tk45 = (u32)gtk[8] | ((u32)gtk[9] << 8) |
                   ((u32)gtk[10] << 16) | ((u32)gtk[11] << 24);
        u32 tk67 = (u32)gtk[12] | ((u32)gtk[13] << 8) |
                   ((u32)gtk[14] << 16) | ((u32)gtk[15] << 24);
        CHECK(sim_cam[1][2] == tk01 && sim_cam[1][3] == tk23 &&
              sim_cam[1][4] == tk45 && sim_cam[1][5] == tk67,
              "GTK CAM: слова 2-5 = TK 16 б (Michael в софте)");
        (void)tx01;
        CHECK((sim_cam[0][0] & 0x40) == 0, "PTK CAM (ячейка 0): без флага группы");
    }

    /* ---- ретрансляция M3: тихий ресенд M4, БЕЗ переустановки ключей ---- */
    int cam_w = sim_cam_writes;
    int tx_n = sim_tx_n;
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(sim_cam_writes == cam_w, "повторный M3: ключи НЕ переустанавливаются");
    CHECK(sim_tx_n > tx_n, "повторный M3: M4 перепослан");

    /* ---- TX данных: СЕССИЯ 52 — бродкаст шифруется ПАРНЫМ ключом
     * (802.11i: станция защищает группо-адресованные MSDU к точке
     * парным шифром; точка перезашифрует GTK соседям). Пара CCMP →
     * IV keyid=0, sec AES, без Michael. Прежний вариант (GTK-TKIP,
     * keyid 1) точка не могла расшифровать — DHCP DISCOVER падал. */
    u8 eth[80];
    memset(eth, 0, sizeof(eth));
    memset(eth, 0xff, 6);                                  /* DA = бродкаст */
    eth[6] = sim_mac[0]; eth[7] = sim_mac[1]; eth[8] = sim_mac[2];
    eth[9] = sim_mac[3]; eth[10] = sim_mac[4]; eth[11] = sim_mac[5];
    eth[12] = 0x08; eth[13] = 0x00;
    for (int i = 14; i < 80; i++) eth[i] = (u8)(i * 3);
    CHECK(wifi_net_send(eth, 80) == 80, "бродкаст TX (DHCP DISCOVER-подобный)");
    int tb = last_tx_of_type(2);
    CHECK(tb >= 0, "бродкаст захвачен");
    {
        int fl = sim_tx[tb].len;
        CHECK(memcmp(sim_tx[tb].frame + 24,
                     "\x00\x00\x00\x20\x00\x00\x00\x01", 8) == 0,
              "бродкаст: CCMP IV (PN=1 BE, keyid 0 — PTK)");
        u32 sec = ((u32)sim_tx[tb].desc[6] << 16);   /* txdw1 биты 22:23 */
        CHECK((sec & 0x00C00000) == TXDESC_SEC_AES,
              "бродкаст: sec_type = AES/CCMP (PTK)");
        CHECK(fl == 24 + 8 + 6 + (80 - 12),
              "бродкаст CCMP: без Michael-хвоста");
        /* юникаст: тот же PTK — IV keyid 0, sec AES, PN вырос до 2 */
        u8 eth2[80];
        memcpy(eth2, eth, sizeof(eth2));
        eth2[0] = 0x10; eth2[1] = 0x22;        /* чётный DA — юникаст */
        CHECK(wifi_net_send(eth2, 80) == 80, "юникаст TX");
        int tu = last_tx_of_type(2);
        int fu = sim_tx[tu].len;
        CHECK(memcmp(sim_tx[tu].frame + 24,
                     "\x00\x00\x00\x20\x00\x00\x00\x02", 8) == 0,
              "юникаст: CCMP IV (PN=2, keyid 0)");
        u32 secu = ((u32)sim_tx[tu].desc[6] << 16);
        CHECK((secu & 0x00C00000) == TXDESC_SEC_AES,
              "юникаст: sec_type = AES/CCMP");
        CHECK(fu == 24 + 8 + 6 + (80 - 12), "юникаст CCMP: без Michael-хвоста");
    }

    /* ---- RX: юникаст CCMP при GTK-TKIP — хвост 8 (было 12) ---- */
    {
        u8 rpl[52];                              /* ethertype + 50 б данных */
        rpl[0] = 0x08; rpl[1] = 0x00;
        for (int i = 2; i < 52; i++) rpl[i] = (u8)(i + 1);
        memcpy(g_rx_eth_dst, sim_mac, 6);        /* юникаст нам */
        memcpy(g_rx_eth_src, sim_bssid, 6);
        u8 dfr[1600];
        int dl = make_data_from_ap(dfr, rpl, 52, 1);
        sim_inject_rx(dfr, dl, 0x0c);
        advance(21); wifi_poll();
        u8 rxbuf[1600];
        u32 rn = wifi_net_recv(rxbuf, sizeof(rxbuf));
        CHECK(rn == 64, "юникаст CCMP при GTK-TKIP: хвост 8 б (LLC цел)");
        CHECK(rn == 64 && memcmp(rxbuf + 14, rpl + 2, 50) == 0,
              "payload юникаста не обрезан");
    }

    /* ---- билдеры IV напрямую: граничные значения (mac80211-раскладка) ---- */
    {
        u8 iv[8];
        wpa2_tx_iv_ccmp(iv, 0x123456789abcULL, 0);
        /* СЕССИЯ 52: канон (mac80211/hostapd) — PN старшим байтом вперёд */
        static const u8 exp_c[8] = { 0x12, 0x34, 0x00, 0x20, 0x56, 0x78, 0x9a, 0xbc };
        CHECK(memcmp(iv, exp_c, 8) == 0, "ccmp_pn2hdr: вектор mac80211");
        wpa2_tx_iv_tkip(iv, 0xFFFFULL, 1);       /* iv16=0xffff, iv32=0 */
        static const u8 exp_t1[8] = { 0xff, 0x7f, 0xff, 0x60, 0, 0, 0, 0 };
        CHECK(memcmp(iv, exp_t1, 8) == 0, "tkip iv16=0xffff (TSC1|ext, байт1 &= 0x7f)");
        wpa2_tx_iv_tkip(iv, 0x10000ULL, 0);      /* iv16=0 после заворота, iv32=1 */
        static const u8 exp_t2[8] = { 0x00, 0x20, 0x00, 0x20, 1, 0, 0, 0 };
        CHECK(memcmp(iv, exp_t2, 8) == 0, "tkip: iv16=0 после заворота, iv32=1");
    }

    /* ---- Michael: дифференциальные векторы (scripts/michael_ref.py,
     * независимая реализация по IEEE 802.11i 8.5.3.2) ---- */
    {
        static const u8 k1[8] = { 0,1,2,3,4,5,6,7 };
        static const u8 da6[6] = { 0x02,0x02,0x02,0x02,0x02,0x02 };
        static const u8 sa6[6] = { 0xc0,0xc0,0xc0,0xc0,0xc0,0xc0 };
        u8 mic8[8];
        wpa2_tkip_michael(k1, da6, sa6, NULL, 0, mic8);
        static const u8 exp0[8] = { 0x90,0xc0,0xed,0x25,0x06,0xf2,0xde,0x8a };
        CHECK(memcmp(mic8, exp0, 8) == 0, "Michael: пустой MSDU (ref.py)");
        u8 msdu1[28];
        memcpy(msdu1, "\xAA\xAA\x03\x00\x00\x00\x08\x00", 8);
        for (int i = 8; i < 28; i++) msdu1[i] = (u8)(i - 8);
        wpa2_tkip_michael(k1, da6, sa6, msdu1, 28, mic8);
        static const u8 exp1[8] = { 0x00,0x44,0xc3,0xe2,0x5f,0x28,0x4c,0x0f };
        CHECK(memcmp(mic8, exp1, 8) == 0, "Michael: MSDU 28 б (ref.py)");
        static const u8 k2[8] = { 0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88 };
        static const u8 daf[6] = { 0xff,0xff,0xff,0xff,0xff,0xff };
        static const u8 sa2[6] = { 1,2,3,4,5,6 };
        u8 msdu2[64];
        for (int i = 0; i < 64; i++) msdu2[i] = (u8)((i * 7) & 0xff);
        wpa2_tkip_michael(k2, daf, sa2, msdu2, 64, mic8);
        static const u8 exp2[8] = { 0x36,0x62,0xca,0x1d,0xb9,0x0e,0x4b,0x7a };
        CHECK(memcmp(mic8, exp2, 8) == 0, "Michael: MSDU 64 б (ref.py)");
        u8 msdu3[41];
        memset(msdu3, 'A', 41);
        static const u8 kz[8] = { 0,0,0,0,0,0,0,0 };
        static const u8 dz[6] = { 0,0,0,0,0,0 };
        wpa2_tkip_michael(kz, dz, dz, msdu3, 41, mic8);
        static const u8 exp3[8] = { 0x52,0x7f,0xdc,0x70,0xed,0xe0,0x9b,0x5e };
        CHECK(memcmp(mic8, exp3, 8) == 0, "Michael: паддинг (41 б, ref.py)");
    }
    wifi_disconnect();
}

int main(void) {
    memcpy(cur_bssid, sim_bssid, 6);   /* по умолчанию — та же точка */
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("=== rtlwifi: RTL8192EU + wifi_core (хост-тест) ===\n");

    test_attach_and_probe();
    test_scan_and_persist();
    test_connect_wpa2();
    test_wpa_crypto_vectors();
    test_connect_wpa_mixed();
    test_connect_wpa_gtk_in_m3();
    test_connect_wpa_tkip_pair();
    test_connect_wpa_ie_echo();
    test_profile();
    test_ap_reject_password();
    test_assoc_rates_and_deauth_cap();
    test_wpa2_ht_assoc_elems();
    test_amsdu_rx();
    test_m1_m3_retx_iv_michael();

    printf("\n=== итог: проверок %d, провалов %d ===\n", checks, fails);
    return fails ? 1 : 0;
}
