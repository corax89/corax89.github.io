#!/bin/sh
# run_rtlwifi.sh — сборка и прогон хост-теста драйвера RTL8192EU
# (НАСТОЯЩИЕ src/rtl8192eu.c + src/wifi_core.c + src/wpa2.c против
#  симулятора USB-устройства; заголовки — настоящие, кроме kernel.h/
#  sync.h/io.h/timer.h — хост-заглушки).
# Использование: ./run_rtlwifi.sh          (обычный)
#                ./run_rtlwifi.sh asan     (AddressSanitizer + UBSan)
set -e
cd "$(dirname "$0")"

SRC=${SRC:-../../src}

# 1) свежие копии НАСТОЯЩИХ исходников и заголовков
for f in rtl8192eu.c wifi_core.c wpa2.c rtl8192eu_fw.c \
         types.h wifi_core.h usb_ehci.h wpa2.h \
         rtl8192eu_regs.h rtl8192eu_tables.h; do
    cp $SRC/$f .
done

# 2) хост-заглушки заголовков
# string.h/mem.h -> libc (настоящий string.h объявляет snprintf с u32);
# snprintf/vsnprintf переименовываются в тестовые обёртки (сигнатура ядра
# с u32 несовместима с libc size_t на 64-битном хосте)
cat > string.h <<'EOF'
#ifndef TEST_STRING_H
#define TEST_STRING_H
#include <string.h>
#define snprintf test_snprintf
#define vsnprintf test_vsnprintf
#endif
EOF
printf '#include <stdlib.h>\n' > mem.h
# kernel.h -> только klog_puts
cat > kernel.h <<'EOF'
#ifndef KERNEL_H
#define KERNEL_H
void klog_puts(const char *s);
#endif
EOF
# sync.h -> no-op блокировки (в ядре — inline asm x86-32)
cat > sync.h <<'EOF'
#ifndef SYNC_H
#define SYNC_H
static inline void s_lock(volatile int *l)   { (void)l; }
static inline void s_unlock(volatile int *l) { (void)l; }
#endif
EOF
# io.h -> порты недоступны на хосте (inb возвращает мусор — калибровка
# задержек уйдёт в консервативный fallback)
cat > io.h <<'EOF'
#ifndef IO_H
#define IO_H
static inline unsigned char inb(unsigned short p)  { (void)p; return 0xff; }
static inline void outb(unsigned short p, unsigned char v) { (void)p; (void)v; }
#endif
EOF
# timer.h -> только счётчик тиков
cat > timer.h <<'EOF'
#ifndef TIMER_H
#define TIMER_H
#include "types.h"
u32 timer_ticks(void);
#endif
EOF
# ramfs.h -> декларации для wifi_core (реализация в тесте)
cat > ramfs.h <<'EOF'
#ifndef RAMFS_H
#define RAMFS_H
#include "types.h"
int  ramfs_ready(void);
int  ramfs_create(const char *name, u32 size);
int  ramfs_write(const char *name, const void *buf, u32 size);
u32  ramfs_read(const char *name, void *buf, u32 max);
int  ramfs_delete(const char *name);
#endif
EOF

# 3) компиляция
FLAGS="-std=c99 -g -Wall -Wextra -Wno-unused-parameter -Wno-builtin-declaration-mismatch -I../../src"
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address,undefined -fno-omit-frame-pointer"
    BIN=rtlwifi_test_asan
else
    BIN=rtlwifi_test
fi
gcc $FLAGS rtlwifi_test.c -o $BIN

echo "== Запуск $BIN =="
if [ "$1" = "asan" ]; then
    ASAN_OPTIONS=detect_leaks=1 ./$BIN
else
    ./$BIN
fi
