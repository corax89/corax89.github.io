/* htmlconv.c — HTML -> Markdown конвертер (упрощённый) для N2600-OS.
 *
 * Поддерживаемые теги:
 *   <h1>-<h6>      -> # .. ###### (+ пробел), закрывающие теги дают перевод строки
 *   <p>            -> пустая строка, </p> -> перевод строки
 *   <br>           -> \n
 *   <hr>           -> ---
 *   <b>/<strong>   -> **      </b>/<strong> -> **
 *   <i>/<em>       -> *       </i>/<em>     -> *
 *   <code>         -> `       </code>       -> `
 *   <pre>          -> ``` \n  </pre>        -> ``` \n
 *   <ul>/<ol>      -> блочный вход в список, </ul>/</ol> -> выход из списка
 *   <li>           -> - или N. (с новой строки, с отступом при вложенности)
 *   <a href=...>   -> [       </a>          -> ](href) — ПОЛНАЯ markdown-
 *                     ссылка: браузер делает её кликабельной (сессия 55);
 *                     <a> без href даёт ]() как раньше
 *   <img src=...>  -> СТРОКА-МАРКЕР ![alt](src) собственным абзацем —
 *                     браузер грузит и показывает картинку (сессия 55);
 *                     <img> без src пропускается
 *
 * Task 47 (формы и скрипты в браузере):
 *   <form action=.. method=..>   -> \x01FORM action=".." method=".."
 *   </form>                      -> \x01/FORM
 *   <input ..>                   -> \x01INPUT type=".." name=".." value=".."
 *                                   id=".." ph=".." js=".." [checked]
 *   <textarea ..> .. </textarea> -> \x01TEXTAREA .. \n сырой текст \n \x01/TEXTAREA
 *   <select ..>                  -> \x01SELECT name=".."
 *   <option ..>текст             -> \x01OPT value=".." label=".." [selected]
 *   </select>                    -> \x01/SELECT
 *   <button ..>текст</button>    -> \x01BUTTON .. label=".."
 *   <script src="U">..</script>  -> \x01SCRIPTSRC src="U" (блок пропускается)
 *   <script>КОД</script>         -> \x01SCRIPT \n КОД (сырой) \n \x01/SCRIPT
 *   Маркеры (каждый — отдельной строкой) разбирает браузер (brform.h):
 *   поля форм получают якоря \x03 и рисуются контролами, скрипты
 *   исполняются движком MicroQuickJS (brjs.h). <label>/др. теги форм
 *   удаляются, их текст сохраняется.
 *
 * <script>/<style> без наших маркеров (style) и их содержимое
 * пропускаются до соответствующего тега; комментарии, DOCTYPE,
 * processing instructions пропускаются; прочие теги удаляются,
 * содержимое сохраняется.
 *
 * Entities:
 *   &amp; &lt; &gt; &quot; &nbsp; &#39; &apos;
 *   числовые: &#65; &#x41; и т.п. (не-ASCII печатается как '?')
 *
 * Примечание:
 *   Эта версия сознательно не делает полную поддержку ссылок с href,
 *   таблиц, blockquote и всех HTML-сущностей, чтобы не сильно раздувать код.
 */

#ifdef HOST_TEST
#include <string.h>   /* хостовой тест: стандартная библиотека */
#include <stdio.h>    /* snprintf (маркеры форм, Task 47) */
#include "types.h"    /* u32 в HC_PUT_ATTR/маркерах; тест-харнессы кладут
                       * копию types.h рядом (см. host-test/s55/run_s55.sh) */
#else
#include "string.h"   /* ядро: freestanding-версия (src/string.c) */
#include "types.h"
#endif

#include "htmlconv.h"

#define HTML_LIST_MAX 8

#define HC_MARK '\x01'   /* первый символ строки-маркера формы/скрипта */

/* Значение атрибута name в области атрибутов тега html[s..e)
 * (name в любом регистре). Значение — в кавычках или до пробела.
 * Возвращает длину значения (0 = атрибут не найден). */
static int html_attr(const char *html, int s, int e, const char *name,
                     char *out, int out_max)
{
    int i = s;
    int nl = 0;
    while (name[nl]) nl++;
    out[0] = 0;
    if (out_max <= 0) return 0;
    out[out_max - 1] = 0;

    while (i < e) {
        /* пропуск разделителей */
        while (i < e && (html[i] == ' ' || html[i] == '\t' ||
                         html[i] == '\n' || html[i] == '\r' ||
                         html[i] == '/'))
            i++;
        if (i >= e) break;

        /* имя атрибута */
        int ns = i;
        while (i < e && html[i] != '=' && html[i] != ' ' &&
               html[i] != '\t' && html[i] != '\n' && html[i] != '\r' &&
               html[i] != '>' && html[i] != '/')
            i++;

        /* сравнить с name (без регистра) */
        int match = (i - ns) == nl;
        if (match) {
            for (int j = 0; j < nl; j++) {
                char a = html[ns + j], b = name[j];
                if (a >= 'A' && a <= 'Z') a += 32;
                if (b >= 'A' && b <= 'Z') b += 32;
                if (a != b) { match = 0; break; }
            }
        }

        /* до '=' или к следующему атрибуту */
        int j2 = i;
        while (j2 < e && html[j2] != '=' && html[j2] != ' ' &&
               html[j2] != '\t' && html[j2] != '\n' && html[j2] != '\r')
            j2++;

        if (match && j2 < e && html[j2] == '=') {
            int vs = j2 + 1;
            while (vs < e && (html[vs] == ' ' || html[vs] == '\t')) vs++;
            int ve;
            if (vs < e && (html[vs] == '"' || html[vs] == '\'')) {
                char q = html[vs++];
                ve = vs;
                while (ve < e && html[ve] != q) ve++;
            } else {
                ve = vs;
                while (ve < e && html[ve] != ' ' && html[ve] != '\t' &&
                       html[ve] != '\n' && html[ve] != '\r' && html[ve] != '>')
                    ve++;
            }
            int len = ve - vs;
            if (len > out_max - 1) len = out_max - 1;
            if (len < 0) len = 0;
            if (len) memcpy(out, html + vs, (unsigned)len);
            out[len] = 0;
            return len;
        }

        /* не наш атрибут: продвинуться ЗА '=' и его значение (иначе
         * i залипает на '=' — бесконечный цикл; FIX сессии 55). */
        i = j2;
        if (i < e && html[i] == '=') {
            i++;
            if (i < e && (html[i] == '"' || html[i] == '\'')) {
                char q = html[i++];
                while (i < e && html[i] != q) i++;
                if (i < e) i++;          /* закрывающая кавычка */
            } else {
                while (i < e && html[i] != ' ' && html[i] != '\t' &&
                       html[i] != '\n' && html[i] != '\r' && html[i] != '>')
                    i++;
            }
        }
    }
    return 0;
}

/* Флаг-атрибут БЕЗ значения (checked/selected/disabled): 1 = имя
 * присутствует в области атрибутов (в любом регистре). */
static int html_attr_present(const char *html, int s, int e, const char *name)
{
    int nl = 0;
    while (name[nl]) nl++;
    int i = s;
    while (i < e) {
        while (i < e && (html[i] == ' ' || html[i] == '\t' ||
                         html[i] == '\n' || html[i] == '\r' ||
                         html[i] == '/'))
            i++;
        if (i >= e) break;
        int ns = i;
        while (i < e && html[i] != '=' && html[i] != ' ' &&
               html[i] != '\t' && html[i] != '\n' && html[i] != '\r' &&
               html[i] != '>' && html[i] != '/')
            i++;
        if (i - ns == nl) {
            int ok = 1;
            for (int j = 0; j < nl; j++) {
                char a = html[ns + j], b = name[j];
                if (a >= 'A' && a <= 'Z') a += 32;
                if (b >= 'A' && b <= 'Z') b += 32;
                if (a != b) { ok = 0; break; }
            }
            if (ok) return 1;
        }
        /* перепрыгнуть значение (как в html_attr) */
        int j2 = i;
        while (j2 < e && html[j2] != '=' && html[j2] != ' ' &&
               html[j2] != '\t' && html[j2] != '\n' && html[j2] != '\r')
            j2++;
        i = j2;
        if (i < e && html[i] == '=') {
            i++;
            if (i < e && (html[i] == '"' || html[i] == '\'')) {
                char q2 = html[i++];
                while (i < e && html[i] != q2) i++;
                if (i < e) i++;
            } else {
                while (i < e && html[i] != ' ' && html[i] != '\t' &&
                       html[i] != '\n' && html[i] != '\r' && html[i] != '>')
                    i++;
            }
        }
    }
    return 0;
}

/* Декодировать entities в значении атрибута (amp/lt/gt/quot/#39/apos)
 * и записать в out. Возвращает длину. */
static int html_attr_decode(const char *val, int vlen, char *out, int out_max)
{
    int o = 0;
    for (int i = 0; i < vlen && o < out_max - 1; ) {
        char c = val[i];
        if (c == '&') {
            int rem = vlen - i;
            if (rem >= 5 && !strncmp(val + i, "&amp;", 5)) { out[o++] = '&'; i += 5; continue; }
            if (rem >= 4 && !strncmp(val + i, "&lt;", 4))  { out[o++] = '<'; i += 4; continue; }
            if (rem >= 4 && !strncmp(val + i, "&gt;", 4))  { out[o++] = '>'; i += 4; continue; }
            if (rem >= 6 && !strncmp(val + i, "&quot;", 6)) { out[o++] = '"'; i += 6; continue; }
            if (rem >= 5 && !strncmp(val + i, "&#39;", 5)) { out[o++] = '\''; i += 5; continue; }
            if (rem >= 6 && !strncmp(val + i, "&apos;", 6)) { out[o++] = '\''; i += 6; continue; }
            if (rem >= 6 && !strncmp(val + i, "&nbsp;", 6)) { out[o++] = ' '; i += 6; continue; }
        }
        out[o++] = c;
        i++;
    }
    out[o] = 0;
    return o;
}

/* Макросы безопасного вывода.
 *
 * ВНИМАНИЕ: они используют локальные переменные функции:
 *   md, md_max, mi
 * и метку:
 *   finish
 *
 * ENSURE(n) проверяет, что в буфере есть место под ещё как минимум n байт.
 * PUT(c) безопасно пишет один байт.
 */

#define ENSURE(n) \
    do { \
        if ((md_max - 1 - mi) < (n)) \
            goto finish; \
    } while (0)

#define PUT(c) \
    do { \
        if (mi >= md_max - 1) \
            goto finish; \
        md[mi++] = (c); \
    } while (0)

#define PUT_STR(s) \
    do { \
        const char *_ps = (s); \
        while (*_ps) { \
            PUT(*_ps); \
            _ps++; \
        } \
    } while (0)

/* Task 47: лимит onclick в маркере (совпадает с BRF_JS_MAX в brform.h) */
#define HC_JS_MAX 96

/* Записать ' name="декодированное"' (пустое значение — ничего). */
#define HC_PUT_ATTR(nm) \
    do { \
        char hc_v[220]; \
        if (html_attr(html, attr_s, attr_e, nm, hc_v, (int)sizeof(hc_v)) > 0 && hc_v[0]) { \
            char hc_d[220]; \
            html_attr_decode(hc_v, (int)strlen(hc_v), hc_d, (int)sizeof(hc_d)); \
            ENSURE((int)strlen(nm) + (int)strlen(hc_d) + 6); \
            PUT(' '); \
            PUT_STR(nm); \
            PUT('='); \
            PUT('"'); \
            for (const char *hc_u = hc_d; *hc_u; hc_u++) { \
                if (*hc_u == '"') { \
                    PUT_STR("&quot;"); \
                } else if (*hc_u == '\n' || *hc_u == '\r' || *hc_u == HC_MARK) { \
                    PUT(' '); \
                } else { \
                    PUT(*hc_u); \
                } \
            } \
            PUT('"'); \
        } \
    } while (0)

/* Сбросить pending <option>: \x01OPT <attrs> label=".." */
#define HC_FLUSH_OPT() \
    do { \
        if (opt_mode && pend_attrs[0]) { \
            ENSURE((int)strlen(pend_attrs) + pend_len + 18); \
            PUT(HC_MARK); \
            PUT_STR("OPT"); \
            PUT_STR(pend_attrs); \
            PUT_STR(" label=\""); \
            for (int pu = 0; pu < pend_len; pu++) { \
                if (pend_label[pu] == '"') { PUT_STR("&quot;"); } \
                else { PUT(pend_label[pu]); } \
            } \
            PUT('"'); \
            EMIT_NL(); \
            pend_attrs[0] = 0; \
            pend_len = 0; \
        } \
    } while (0)

/* Удалить пробелы перед переводом строки, чтобы не было " \n". */
#define TRIM_SPACES() \
    do { \
        while (mi > 0 && md[mi - 1] == ' ') \
            --mi; \
    } while (0)

/* Перевод строки с удалением хвостовых пробелов. */
#define EMIT_NL() \
    do { \
        TRIM_SPACES(); \
        PUT('\n'); \
    } while (0)

/* Гарантировать хотя бы один перевод строки в конце вывода. */
#define ENSURE_NL() \
    do { \
        if (mi == 0 || md[mi - 1] != '\n') \
            EMIT_NL(); \
    } while (0)

/* Гарантировать пустую строку (два перевода строки в конце), но не
 * создавать пустые блоки в самом начале вывода.
 */
#define ENSURE_BLANK() \
    do { \
        if (mi > 0) { \
            ENSURE_NL(); \
            if (mi < 2 || md[mi - 2] != '\n') \
                PUT('\n'); \
        } \
    } while (0)

/* Как ENSURE_NL, но не удаляет хвостовые пробелы.
 * Нужно для закрытия <pre>, чтобы не потерять пробелы в коде.
 */
#define ENSURE_NL_RAW() \
    do { \
        if (mi == 0 || md[mi - 1] != '\n') \
            PUT('\n'); \
    } while (0)

int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    int mi = 0;
    int i = 0;

    int pre_mode = 0;
    int pre_first = 0;

    char tag[32];
    int tag_i;

    int t;
    char c;
    char a;
    char q;

    int list_depth = 0;
    unsigned char list_type[HTML_LIST_MAX];   /* 0 = ul, 1 = ol */
    int list_count[HTML_LIST_MAX];

    int is_style;
    const char *name;
    int nlen;
    int j;
    int k;
    char lc;
    char delim;
    int rem;
    int base;
    int start;
    int val;
    int digit;
    char e;

    char num[12];
    int v;
    int n;
    int depth;

    /* сессия 55: href последней открытой <a> и область атрибутов тега */
    char last_href[220];
    int  attr_s;
    int  attr_e;

    /* Task 47: формы/скрипты */
    int  ta_mode;                /* внутри <textarea>: сырой текст */
    int  opt_mode;               /* внутри <select>: копим option */
    int  btn_mode;               /* внутри <button>: копим подпись */
    char pend_attrs[128];        /* атрибуты pending option/button */
    char pend_label[64];
    int  pend_len;

    if (!html || !md || html_len <= 0 || md_max < 4) {
        if (md && md_max > 0)
            md[0] = 0;
        return 0;
    }

    last_href[0] = 0;
    ta_mode = 0;
    opt_mode = 0;
    btn_mode = 0;
    pend_attrs[0] = 0;
    pend_label[0] = 0;
    pend_len = 0;

    while (i < html_len) {
        if (mi >= md_max - 1)
            break;

        c = html[i];

        /* ------------------------------------------------------------
         * Обработка тегов.
         * ------------------------------------------------------------ */
        if (c == '<') {
            /* HTML-комментарий: <!-- ... -->
             * Пропускаем до -->.
             */
            if (html_len - i >= 4 &&
                html[i + 1] == '!' &&
                html[i + 2] == '-' &&
                html[i + 3] == '-') {

                i += 4;

                while (html_len - i >= 3 &&
                       !(html[i] == '-' &&
                         html[i + 1] == '-' &&
                         html[i + 2] == '>')) {
                    i++;
                }

                if (html_len - i >= 3)
                    i += 3;
                else
                    i = html_len;

                continue;
            }

            /* DOCTYPE, declaration, processing instruction:
             * <!DOCTYPE html>, <?xml ...?> и т.п.
             * Упрощённо пропускаем до '>'.
             */
            if (html_len - i >= 2 &&
                (html[i + 1] == '!' || html[i + 1] == '?')) {
                while (i < html_len && html[i] != '>')
                    i++;
                if (i < html_len)
                    i++;
                continue;
            }

            /* Читаем имя тега.
             * '/' в начале — часть имени закрывающего тега.
             * Пробельный символ или '/' после имени — начало атрибутов.
             */
            tag_i = 0;
            i++;

            while (i < html_len && html[i] != '>' && tag_i < 31) {
                if (html[i] == ' ' ||
                    html[i] == '\t' ||
                    html[i] == '\n' ||
                    html[i] == '\r') {
                    break;
                }

                if (html[i] == '/' && tag_i > 0)
                    break;

                tag[tag_i++] = html[i++];
            }

            tag[tag_i] = 0;

            /* Приводим имя тега к нижнему регистру.
             * Это убирает необходимость писать пары "h1"/"H1".
             */
            for (t = 0; t < tag_i; ++t) {
                if (tag[t] >= 'A' && tag[t] <= 'Z')
                    tag[t] = (char)(tag[t] | 0x20);
            }

            /* Область атрибутов: от конца имени до '>' (сессия 55:
             * нужна html_attr для href/src тегов <a> и <img>). */
            attr_s = i;

            /* Пропускаем атрибуты до '>'.
             * Учитываем кавычки, чтобы атрибут вида:
             *   title="foo > bar"
             * не ломал разбор.
             */
            q = 0;

            while (i < html_len) {
                a = html[i];

                if (q) {
                    if (a == q)
                        q = 0;
                } else if (a == '"' || a == '\'') {
                    q = a;
                } else if (a == '>') {
                    break;
                }

                i++;
            }

            attr_e = i;                    /* позиция '>' или конца html */

            if (i < html_len)
                i++;

            /* Пустой тег <> — просто пропускаем. */
            if (tag_i == 0)
                continue;

            /* Внутри <pre> игнорируем все теги, кроме </pre>.
             * Это заставляет <pre><code>...</code></pre> работать
             * как нормальный fenced code block без лишних `.
             * Task 47: внутри <textarea> — все теги, кроме </textarea>.
             * Внутри <option>/<button> (копим подпись) — все теги,
             * кроме собственных закрывающих/открывающих контролов. */
            if (ta_mode && strcmp(tag, "/textarea") != 0)
                continue;
            if (pre_mode && strcmp(tag, "/pre") != 0)
                continue;
            if ((opt_mode || btn_mode) &&
                strcmp(tag, "option") != 0 && strcmp(tag, "/option") != 0 &&
                strcmp(tag, "/select") != 0 &&
                strcmp(tag, "button") != 0 && strcmp(tag, "/button") != 0 &&
                strcmp(tag, "input") != 0 && strcmp(tag, "select") != 0 &&
                strcmp(tag, "textarea") != 0)
                continue;

            /* Пропуск содержимого <style> (и <script> с src — код
             * внешний, в md не нужен).
             *
             * Старая версия останавливалась на любом закрывающем теге.
             * Теперь ищем именно </style> / </script>.
             */
            is_style  = !strcmp(tag, "style");

            if (is_style) {
                name = "style";
                nlen = 5;

                while (i < html_len) {
                    if (html[i] == '<' &&
                        i + 1 < html_len &&
                        html[i + 1] == '/') {

                        j = i + 2;
                        k = 0;

                        while (j < html_len && k < nlen) {
                            lc = html[j];

                            if (lc >= 'A' && lc <= 'Z')
                                lc = (char)(lc | 0x20);

                            if (lc != name[k])
                                break;

                            j++;
                            k++;
                        }

                        if (k == nlen) {
                            delim = (j < html_len) ? html[j] : '>';

                            if (delim == '>' ||
                                delim == ' ' ||
                                delim == '\t' ||
                                delim == '\n' ||
                                delim == '\r' ||
                                delim == '/') {

                                while (j < html_len && html[j] != '>')
                                    j++;

                                if (j < html_len)
                                    j++;

                                i = j;
                                break;
                            }
                        }
                    }

                    i++;
                }

                continue;
            }

            /* Task 47: <script> — НЕ вырезаем. С src: маркер-строка
             * \x01SCRIPTSRC src=".." (браузер сам скачает и запустит).
             * Инлайн: \x01SCRIPT, сырой код, \x01/SCRIPT — код исполняет
             * MicroQuickJS (brjs.h). Прежняя версия уничтожала скрипты
             * на этапе конвертации. */
            if (!strcmp(tag, "script")) {
                char ssrc[200];
                int have_src = html_attr(html, attr_s, attr_e, "src",
                                         ssrc, (int)sizeof(ssrc)) > 0 && ssrc[0];
                if (have_src) {
                    if (mi > 0)
                        ENSURE_NL();
                    ENSURE(18);
                    PUT(HC_MARK);
                    PUT_STR("SCRIPTSRC src=\"");
                    for (const char *u = ssrc; *u; u++) {
                        if (*u == '"' || *u == ' ' ||
                            *u == '\n' || *u == '\r' || *u == HC_MARK)
                            break;
                        if (*u == '&' && !strncmp(u, "&amp;", 5)) {
                            PUT('&');
                            u += 4;
                            continue;
                        }
                        PUT(*u);
                    }
                    PUT('"');
                    EMIT_NL();
                    /* кода в теге нет — прыжок через блок до </script> */
                    {
                        while (i < html_len) {
                            if (html[i] == '<' &&
                                i + 1 < html_len &&
                                html[i + 1] == '/') {
                                j = i + 2;
                                k = 0;
                                while (j < html_len && k < 6) {
                                    lc = html[j];
                                    if (lc >= 'A' && lc <= 'Z')
                                        lc = (char)(lc | 0x20);
                                    if (lc != "script"[k])
                                        break;
                                    j++;
                                    k++;
                                }
                                if (k == 6) {
                                    delim = (j < html_len) ? html[j] : '>';
                                    if (delim == '>' || delim == ' ' ||
                                        delim == '\t' || delim == '\n' ||
                                        delim == '\r' || delim == '/') {
                                        while (j < html_len && html[j] != '>')
                                            j++;
                                        if (j < html_len)
                                            j++;
                                        i = j;
                                        break;
                                    }
                                }
                            }
                            i++;
                        }
                    }
                    continue;
                }

                /* инлайн-скрипт: маркер + сырой код + закрытие */
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(10);
                PUT(HC_MARK);
                PUT_STR("SCRIPT");
                EMIT_NL();
                while (i < html_len) {
                    if (html[i] == '<' &&
                        i + 1 < html_len &&
                        html[i + 1] == '/') {
                        j = i + 2;
                        k = 0;
                        while (j < html_len && k < 6) {
                            lc = html[j];
                            if (lc >= 'A' && lc <= 'Z')
                                lc = (char)(lc | 0x20);
                            if (lc != "script"[k])
                                break;
                            j++;
                            k++;
                        }
                        if (k == 6) {
                            delim = (j < html_len) ? html[j] : '>';
                            if (delim == '>' || delim == ' ' ||
                                delim == '\t' || delim == '\n' ||
                                delim == '\r' || delim == '/')
                                break;                 /* конец кода */
                        }
                    }
                    ENSURE(2);
                    PUT(html[i]);
                    i++;
                }
                while (i < html_len && html[i] != '>')
                    i++;
                if (i < html_len)
                    i++;
                ENSURE(13);
                /* Task 50 [HC-NL]: КОД может не кончаться '\n' — маркер
                 * \x01/SCRIPT обязан начинать СВОЮ строку, иначе brf_parse
                 * не увидит закрытие и состояние ST_SCRIPT съест весь
                 * остаток страницы. */
                if (mi == 0 || md[mi - 1] != '\n')
                    PUT('\n');
                PUT(HC_MARK);
                PUT_STR("/SCRIPT");
                EMIT_NL();
                continue;
            }

            /* --------------------------------------------------------
             * Преобразование тегов в Markdown.
             * -------------------------------------------------------- */

            /* Заголовки <h1> ... <h6> */
            if (tag[0] == 'h' &&
                tag[1] >= '1' &&
                tag[1] <= '6' &&
                tag[2] == 0) {

                v = tag[1] - '0';

                if (mi > 0)
                    ENSURE_NL();

                ENSURE(v + 1);

                while (v--)
                    PUT('#');

                PUT(' ');
            }

            /* Закрывающие заголовки </h1> ... </h6> */
            else if (tag[0] == '/' &&
                     tag[1] == 'h' &&
                     tag[2] >= '1' &&
                     tag[2] <= '6' &&
                     tag[3] == 0) {
                if (mi > 0)
                    ENSURE_NL();
            }

            /* Параграфы */
            else if (!strcmp(tag, "p")) {
                ENSURE_BLANK();
            } else if (!strcmp(tag, "/p")) {
                if (mi > 0)
                    ENSURE_NL();
            }

            /* <br> */
            else if (!strcmp(tag, "br")) {
                EMIT_NL();
            }

            /* <hr> */
            else if (!strcmp(tag, "hr")) {
                if (mi > 0)
                    ENSURE_NL();

                ENSURE(4);
                PUT('-');
                PUT('-');
                PUT('-');
                PUT('\n');
            }

            /* Жирный */
            else if (!strcmp(tag, "b") || !strcmp(tag, "strong")) {
                ENSURE(2);
                PUT('*');
                PUT('*');
            }

            /* Курсив */
            else if (!strcmp(tag, "i") || !strcmp(tag, "em")) {
                PUT('*');
            }

            /* Инлайн код */
            else if (!strcmp(tag, "code")) {
                PUT('`');
            }

            /* Открытие preformatted / code block */
            else if (!strcmp(tag, "pre")) {
                if (!pre_mode) {
                    if (mi > 0)
                        ENSURE_NL();

                    ENSURE(4);
                    PUT('`');
                    PUT('`');
                    PUT('`');
                    PUT('\n');

                    pre_mode = 1;
                    pre_first = 1;
                }
            }

            /* Закрытие pre */
            else if (!strcmp(tag, "/pre")) {
                if (pre_mode) {
                    ENSURE_NL_RAW();

                    ENSURE(4);
                    PUT('`');
                    PUT('`');
                    PUT('`');
                    PUT('\n');

                    pre_mode = 0;
                    pre_first = 0;
                }
            }

            /* Списки */
            else if (!strcmp(tag, "ul") || !strcmp(tag, "ol")) {
                if (mi > 0)
                    ENSURE_NL();

                if (list_depth < HTML_LIST_MAX) {
                    list_type[list_depth] = (unsigned char)
                        (!strcmp(tag, "ol") ? 1 : 0);
                    list_count[list_depth] = 0;
                    list_depth++;
                }
            }

            else if (!strcmp(tag, "/ul") || !strcmp(tag, "/ol")) {
                if (list_depth > 0)
                    list_depth--;

                if (mi > 0)
                    ENSURE_NL();
            }

            else if (!strcmp(tag, "li")) {
                if (mi > 0)
                    ENSURE_NL();

                /* Отступ для вложенных списков: 2 пробела на уровень. */
                for (depth = 1; depth < list_depth; ++depth) {
                    ENSURE(2);
                    PUT(' ');
                    PUT(' ');
                }

                /* Нумерация, если внутри <ol>. */
                if (list_depth > 0 && list_type[list_depth - 1]) {
                    v = ++list_count[list_depth - 1];
                    n = 0;

                    if (v == 0) {
                        PUT('0');
                    } else {
                        while (v > 0 && n < (int)sizeof(num)) {
                            num[n++] = (char)('0' + (v % 10));
                            v /= 10;
                        }

                        while (n > 0)
                            PUT(num[--n]);
                    }

                    PUT('.');
                    PUT(' ');
                } else {
                    ENSURE(2);
                    PUT('-');
                    PUT(' ');
                }
            }

            else if (!strcmp(tag, "/li")) {
                if (mi > 0)
                    ENSURE_NL();
            }

            /* Ссылки: с href (сессия 55) — браузер делает кликабельными.
             * ')' внутри href обрезается — маркер markdown ](url) кончается
             * первой скобкой (документированное ограничение). */
            else if (!strcmp(tag, "a")) {
                last_href[0] = 0;
                html_attr(html, attr_s, attr_e, "href",
                          last_href, (int)sizeof(last_href));
                PUT('[');
            } else if (!strcmp(tag, "/a")) {
                ENSURE(3);
                PUT(']');
                if (last_href[0]) {
                    PUT('(');
                    for (const char *u = last_href; *u; u++) {
                        if (*u == ')') break;
                        /* &amp; в атрибуте — это '&' в реальном URL */
                        if (*u == '&' && !strncmp(u, "&amp;", 5)) {
                            PUT('&');
                            u += 4;
                            continue;
                        }
                        PUT(*u);
                    }
                    PUT(')');
                } else {
                    PUT('(');
                    PUT(')');
                }
                last_href[0] = 0;
            }

            /* Картинки (сессия 55): маркер ![alt](src) отдельной строкой —
             * браузер распознаёт, грузит и показывает. Без src — пропуск. */
            else if (!strcmp(tag, "img")) {
                char src[220];
                char alt[64];
                if (html_attr(html, attr_s, attr_e, "src",
                              src, (int)sizeof(src)) > 0) {
                    alt[0] = 0;
                    html_attr(html, attr_s, attr_e, "alt",
                              alt, (int)sizeof(alt));
                    ENSURE_NL();
                    ENSURE(6);
                    PUT('!');
                    PUT('[');
                    for (const char *u = alt; *u; u++) {
                        if (*u == ']' || *u == '\n' || *u == '\r') break;
                        if (u - alt >= 48) break;
                        PUT(*u);
                    }
                    PUT(']');
                    PUT('(');
                    for (const char *u = src; *u; u++) {
                        if (*u == ')' || *u == '\n' || *u == '\r' ||
                            *u == '"' || *u == '<')
                            break;
                        if (*u == '&' && !strncmp(u, "&amp;", 5)) {
                            PUT('&');
                            u += 4;
                            continue;
                        }
                        PUT(*u);
                    }
                    PUT(')');
                    EMIT_NL();
                }
            }

            /* ---- Task 47: формы (маркеры разбирает brform.h) ---- */
            else if (!strcmp(tag, "form")) {
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(8);
                PUT(HC_MARK);
                PUT_STR("FORM");
                HC_PUT_ATTR("action");
                HC_PUT_ATTR("method");
                EMIT_NL();
            } else if (!strcmp(tag, "/form")) {
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(9);
                PUT(HC_MARK);
                PUT_STR("/FORM");
                EMIT_NL();
            } else if (!strcmp(tag, "input")) {
                char ttype[16];
                if (html_attr(html, attr_s, attr_e, "type", ttype,
                              (int)sizeof(ttype)) <= 0 || !ttype[0])
                    strcpy(ttype, "text");
                for (char *u = ttype; *u; u++)
                    if (*u >= 'A' && *u <= 'Z') *u = (char)(*u | 0x20);
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(12);
                PUT(HC_MARK);
                PUT_STR("INPUT type=\"");
                PUT_STR(ttype);
                PUT('"');
                HC_PUT_ATTR("name");
                HC_PUT_ATTR("value");
                HC_PUT_ATTR("id");
                if (!strcmp(ttype, "text") || !strcmp(ttype, "password") ||
                    !strcmp(ttype, "search"))
                    HC_PUT_ATTR("placeholder");
                HC_PUT_ATTR("onclick");
                if (html_attr_present(html, attr_s, attr_e, "checked")) {
                    ENSURE(9);
                    PUT_STR(" checked");
                }
                EMIT_NL();
            } else if (!strcmp(tag, "textarea")) {
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(13);
                PUT(HC_MARK);
                PUT_STR("TEXTAREA");
                HC_PUT_ATTR("name");
                HC_PUT_ATTR("id");
                HC_PUT_ATTR("placeholder");
                EMIT_NL();
                ta_mode = 1;
            } else if (!strcmp(tag, "/textarea")) {
                ta_mode = 0;
                ENSURE(14);
                /* Task 50 [HC-NL]: как у /SCRIPT — текст textarea может
                 * не кончаться '\n'; маркер закрытия обязан быть
                 * отдельной строкой. */
                if (mi == 0 || md[mi - 1] != '\n')
                    PUT('\n');
                PUT(HC_MARK);
                PUT_STR("/TEXTAREA");
                EMIT_NL();
            } else if (!strcmp(tag, "select")) {
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(12);
                PUT(HC_MARK);
                PUT_STR("SELECT");
                HC_PUT_ATTR("name");
                EMIT_NL();
                opt_mode = 1;
                pend_attrs[0] = 0;
                pend_len = 0;
                pend_label[0] = 0;
            } else if (!strcmp(tag, "/select")) {
                HC_FLUSH_OPT();
                opt_mode = 0;
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(12);
                PUT(HC_MARK);
                PUT_STR("/SELECT");
                EMIT_NL();
            } else if (!strcmp(tag, "option")) {
                HC_FLUSH_OPT();
                {
                    char vbuf[80];
                    int pa = 0;
                    pend_attrs[0] = 0;
                    if (html_attr(html, attr_s, attr_e, "value", vbuf,
                                  (int)sizeof(vbuf)) > 0) {
                        char dec[80];
                        html_attr_decode(vbuf, (int)strlen(vbuf), dec,
                                         (int)sizeof(dec));
                        int nr = (int)sizeof(pend_attrs) - pa;
                        int n2 = snprintf(pend_attrs + pa, (u32)nr,
                                          " value=\"%s\"", dec);
                        if (n2 < 0) n2 = 0;
                        if (n2 > nr - 1) n2 = nr - 1;
                        pa += n2;
                    }
                    if (html_attr_present(html, attr_s, attr_e, "selected")) {
                        int nr = (int)sizeof(pend_attrs) - pa;
                        if (nr > 10) { strcpy(pend_attrs + pa, " selected"); pa += 9; }
                    }
                    pend_len = 0;
                    pend_label[0] = 0;
                }
            } else if (!strcmp(tag, "/option")) {
                HC_FLUSH_OPT();
            } else if (!strcmp(tag, "button")) {
                char vbuf[80];
                int pa = 0;
                if (mi > 0)
                    ENSURE_NL();
                pend_attrs[0] = 0;
                {
                    char ttype[16];
                    if (html_attr(html, attr_s, attr_e, "type", ttype,
                                  (int)sizeof(ttype)) > 0 && ttype[0]) {
                        for (char *u = ttype; *u; u++)
                            if (*u >= 'A' && *u <= 'Z') *u = (char)(*u | 0x20);
                        int nr = (int)sizeof(pend_attrs) - pa;
                        int n2 = snprintf(pend_attrs + pa, (u32)nr,
                                          " type=\"%s\"", ttype);
                        if (n2 < 0) n2 = 0;
                        if (n2 > nr - 1) n2 = nr - 1;
                        pa += n2;
                    }
                }
                if (html_attr(html, attr_s, attr_e, "name", vbuf,
                              (int)sizeof(vbuf)) > 0) {
                    char dec[40];
                    html_attr_decode(vbuf, (int)strlen(vbuf), dec, (int)sizeof(dec));
                    int nr = (int)sizeof(pend_attrs) - pa;
                    int n2 = snprintf(pend_attrs + pa, (u32)nr, " name=\"%s\"", dec);
                    if (n2 < 0) n2 = 0;
                    if (n2 > nr - 1) n2 = nr - 1;
                    pa += n2;
                }
                if (html_attr(html, attr_s, attr_e, "value", vbuf,
                              (int)sizeof(vbuf)) > 0) {
                    char dec[48];
                    html_attr_decode(vbuf, (int)strlen(vbuf), dec, (int)sizeof(dec));
                    int nr = (int)sizeof(pend_attrs) - pa;
                    int n2 = snprintf(pend_attrs + pa, (u32)nr, " value=\"%s\"", dec);
                    if (n2 < 0) n2 = 0;
                    if (n2 > nr - 1) n2 = nr - 1;
                    pa += n2;
                }
                if (html_attr(html, attr_s, attr_e, "onclick", vbuf,
                              (int)sizeof(vbuf)) > 0) {
                    char dec[HC_JS_MAX];
                    html_attr_decode(vbuf, (int)strlen(vbuf), dec, (int)sizeof(dec));
                    int nr = (int)sizeof(pend_attrs) - pa;
                    int n2 = snprintf(pend_attrs + pa, (u32)nr, " js=\"%s\"", dec);
                    if (n2 < 0) n2 = 0;
                    if (n2 > nr - 1) n2 = nr - 1;
                    pa += n2;
                }
                btn_mode = 1;
                pend_len = 0;
                pend_label[0] = 0;
            } else if (!strcmp(tag, "/button")) {
                btn_mode = 0;
                if (mi > 0)
                    ENSURE_NL();
                ENSURE(11 + (int)strlen(pend_attrs) + pend_len + 12);
                PUT(HC_MARK);
                PUT_STR("BUTTON");
                PUT_STR(pend_attrs);
                PUT_STR(" label=\"");
                for (int pu = 0; pu < pend_len; pu++) {
                    if (pend_label[pu] == '"') {
                        PUT_STR("&quot;");
                    } else {
                        PUT(pend_label[pu]);
                    }
                }
                PUT('"');
                EMIT_NL();
                pend_attrs[0] = 0;
                pend_len = 0;
            }

            /* Закрывающие теги форматирования */
            else if (!strcmp(tag, "/b") || !strcmp(tag, "/strong")) {
                ENSURE(2);
                PUT('*');
                PUT('*');
            } else if (!strcmp(tag, "/i") || !strcmp(tag, "/em")) {
                PUT('*');
            } else if (!strcmp(tag, "/code")) {
                PUT('`');
            }

            /* Неизвестные теги просто удаляем. */

            continue;
        }

        /* ------------------------------------------------------------
         * Обработка HTML-entities.
         * ------------------------------------------------------------ */
        if (c == '&') {
            rem = html_len - i;

            if (rem >= 5 && !strncmp(html + i, "&amp;", 5)) {
                PUT('&');
                i += 5;
                continue;
            }

            if (rem >= 4 && !strncmp(html + i, "&lt;", 4)) {
                PUT('<');
                i += 4;
                continue;
            }

            if (rem >= 4 && !strncmp(html + i, "&gt;", 4)) {
                PUT('>');
                i += 4;
                continue;
            }

            if (rem >= 6 && !strncmp(html + i, "&quot;", 6)) {
                PUT('"');
                i += 6;
                continue;
            }

            if (rem >= 6 && !strncmp(html + i, "&nbsp;", 6)) {
                /* Выводим пробел, но избегаем дублей. */
                if (mi > 0 &&
                    md[mi - 1] != ' ' &&
                    md[mi - 1] != '\n') {
                    PUT(' ');
                }

                i += 6;
                continue;
            }

            if (rem >= 5 && !strncmp(html + i, "&#39;", 5)) {
                PUT('\'');
                i += 5;
                continue;
            }

            if (rem >= 6 && !strncmp(html + i, "&apos;", 6)) {
                PUT('\'');
                i += 6;
                continue;
            }

            /* Числовые сущности: &#65; &#x41; и т.п.
             *
             * Полноценный Unicode здесь не делаем:
             * - 32..126 печатаем как есть;
             * - пробельные коды превращаем в пробел;
             * - остальное печатаем как '?'.
             */
            if (rem >= 3 && html[i + 1] == '#') {
                j = i + 2;
                base = 10;

                if (j < html_len &&
                    (html[j] == 'x' || html[j] == 'X')) {
                    base = 16;
                    j++;
                }

                start = j;
                val = 0;

                while (j < html_len) {
                    e = html[j];
                    digit = -1;

                    if (e >= '0' && e <= '9') {
                        digit = e - '0';
                    } else if (base == 16 && e >= 'a' && e <= 'f') {
                        digit = e - 'a' + 10;
                    } else if (base == 16 && e >= 'A' && e <= 'F') {
                        digit = e - 'A' + 10;
                    }

                    if (digit < 0)
                        break;

                    if (val <= 0x110000) {
                        val = val * base + digit;
                        if (val > 0x110000)
                            val = 0x110000;
                    }

                    j++;
                }

                if (j > start && j < html_len && html[j] == ';') {
                    if (val == 9 || val == 10 || val == 13 || val == 160) {
                        if (mi > 0 &&
                            md[mi - 1] != ' ' &&
                            md[mi - 1] != '\n') {
                            PUT(' ');
                        }
                    } else if (val == 39) {
                        PUT('\'');
                    } else if (val >= 32 && val <= 126) {
                        PUT((char)val);
                    } else if (val != 0) {
                        PUT('?');
                    }

                    i = j + 1;
                    continue;
                }
            }

            /* Не распознали — ниже '&' будет выведен как обычный символ. */
        }

        /* ------------------------------------------------------
         * Task 47: накопление подписи option/button (до md не
         * доходит — попадёт в атрибут label маркера).
         * ------------------------------------------------------ */
        if (opt_mode || btn_mode) {
            char cc2 = c;
            if (cc2 == '\n' || cc2 == '\r' || cc2 == '\t') cc2 = ' ';
            if (cc2 == '&') {
                int rem2 = html_len - i;
                char dec = 0;
                int used = 0;
                if (rem2 >= 5 && !strncmp(html + i, "&amp;", 5)) { dec = '&'; used = 5; }
                else if (rem2 >= 4 && !strncmp(html + i, "&lt;", 4)) { dec = '<'; used = 4; }
                else if (rem2 >= 4 && !strncmp(html + i, "&gt;", 4)) { dec = '>'; used = 4; }
                else if (rem2 >= 6 && !strncmp(html + i, "&quot;", 6)) { dec = '"'; used = 6; }
                else if (rem2 >= 5 && !strncmp(html + i, "&#39;", 5)) { dec = '\''; used = 5; }
                else if (rem2 >= 6 && !strncmp(html + i, "&apos;", 6)) { dec = '\''; used = 6; }
                else if (rem2 >= 6 && !strncmp(html + i, "&nbsp;", 6)) { dec = ' '; used = 6; }
                if (used) {
                    if (dec != ' ' || (pend_len > 0 &&
                        pend_label[pend_len - 1] != ' ')) {
                        if (pend_len < (int)sizeof(pend_label) - 1)
                            pend_label[pend_len++] = dec;
                    }
                    i += used;
                    continue;
                }
            }
            if (cc2 == ' ' &&
                (pend_len == 0 || pend_label[pend_len - 1] == ' ')) {
                i++;
                continue;
            }
            if (pend_len < (int)sizeof(pend_label) - 1)
                pend_label[pend_len++] = cc2;
            i++;
            continue;
        }

        /* Task 47: внутри <textarea> — сырой текст (entities декодируем,
         * переносы сохраняем, пробелы НЕ сжимаем). */
        if (ta_mode) {
            if (c == '\r') { i++; continue; }
            if (c == '&') {
                int rem2 = html_len - i;
                if (rem2 >= 5 && !strncmp(html + i, "&amp;", 5)) { PUT('&'); i += 5; continue; }
                if (rem2 >= 4 && !strncmp(html + i, "&lt;", 4)) { PUT('<'); i += 4; continue; }
                if (rem2 >= 4 && !strncmp(html + i, "&gt;", 4)) { PUT('>'); i += 4; continue; }
                if (rem2 >= 6 && !strncmp(html + i, "&quot;", 6)) { PUT('"'); i += 6; continue; }
                if (rem2 >= 5 && !strncmp(html + i, "&#39;", 5)) { PUT('\''); i += 5; continue; }
            }
            PUT(c);
            i++;
            continue;
        }

        /* ------------------------------------------------------------
         * Внутри <pre> сохраняем текст как есть.
         * ------------------------------------------------------------ */
        if (pre_mode) {
            /* HTML часто игнорирует самый первый перевод строки сразу
             * после <pre>. Поступаем так же.
             */
            if (pre_first) {
                pre_first = 0;

                if (c == '\n') {
                    i++;
                    continue;
                }

                if (c == '\r') {
                    i++;
                    if (i < html_len && html[i] == '\n')
                        i++;
                    continue;
                }
            }

            PUT(c);
            i++;
            continue;
        }

        /* ------------------------------------------------------------
         * Сжатие пробелов и переводов строк вне <pre>.
         * ------------------------------------------------------------ */

        if (c == '\n' || c == '\r') {
            if (mi > 0 &&
                md[mi - 1] != '\n' &&
                md[mi - 1] != ' ') {
                PUT(' ');
            }

            i++;
            continue;
        }

        if (c == '\t') {
            if (mi > 0 && md[mi - 1] != ' ')
                PUT(' ');

            i++;
            continue;
        }

        /* Пропускаем пробел:
         * - в самом начале;
         * - если уже есть пробел;
         * - если он сразу после перевода строки.
         */
        if (c == ' ' &&
            (mi == 0 ||
             md[mi - 1] == ' ' ||
             md[mi - 1] == '\n')) {
            i++;
            continue;
        }

        /* Обычный символ. */
        PUT(c);
        i++;
    }

finish:
    md[mi] = 0;
    return mi;
}

#undef ENSURE
#undef PUT
#undef PUT_STR
#undef TRIM_SPACES
#undef EMIT_NL
#undef ENSURE_NL
#undef ENSURE_BLANK
#undef ENSURE_NL_RAW