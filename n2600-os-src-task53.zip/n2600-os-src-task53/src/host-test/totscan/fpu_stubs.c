#include "imgsvc.h"
void img_fpu_lock(void){}
void img_fpu_unlock(void){}
