/* realfile_test.c — кросс-проверка mp3_total_frames_estimate на реальных
 * файлах: мой скан против drmp3_get_pcm_frame_count (полный проход
 * декодером dr_mp3) и против ffprobe (вне программы, см. run-строку). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mp3svc.h"
#include "dr_mp3.h"

int main(int argc, char **argv)
{
    for (int a = 1; a < argc; a++) {
        FILE *f = fopen(argv[a], "rb");
        if (!f) { printf("%s: не открыть\n", argv[a]); continue; }
        fseek(f, 0, SEEK_END);
        long sz = ftell(f);
        fseek(f, 0, SEEK_SET);
        void *data = malloc((size_t)sz);
        if (fread(data, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); free(data); continue; }
        fclose(f);

        drmp3 *m = (drmp3 *)malloc(MP3_CTX_SIZE);
        memset(m, 0, sizeof(*m));
        void *ctx = m;
        if (!mp3_open_mem(data, (u32)sz, ctx)) {
            printf("%s: mp3_open_mem отказ (%s)\n", argv[a], mp3_errstr());
            free(data); free(m);
            continue;
        }
        u32 rate = mp3_rate(ctx);
        u64 mine = mp3_total_frames_estimate(ctx);
        u64 ref  = drmp3_get_pcm_frame_count(m);      /* полный проход декодером */
        double mine_s = rate ? (double)mine / rate : 0.0;
        double ref_s  = rate ? (double)ref / rate : 0.0;
        double d = (double)mine - (double)ref;
        printf("%-28s rate=%u скан=%llu (%.2f с) декодер=%llu (%.2f с) Δ=%lld (%.3f%%)\n",
               argv[a], rate,
               (unsigned long long)mine, mine_s,
               (unsigned long long)ref, ref_s,
               (long long)d,
               ref ? 100.0 * d / (double)ref : 0.0);
        free(m);
        free(data);
    }
    return 0;
}
