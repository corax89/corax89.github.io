/*
 * switch_trace.h — v34.91 «freeze triage»: lightweight stage diagnostics for
 * the Switch frontend.
 *
 * WHY: the user reports that on a Switch EMULATOR the frontend menu works
 * (navigation, MINUS language toggle — which already writes settings.ini to
 * sdmc:, proving the card is writable) but pressing A on «Открыть игру» /
 * «Настройки» freezes the app. The same paths pass the full host E2E
 * (test_switch_input: MINUS,A,A -> jar selected), so the freeze is
 * emulator-specific and cannot be reproduced in the sandbox. stderr is not
 * visible on an emulator, so this module turns the next user run into a
 * precise diagnosis:
 *
 *   1. sw_trace(stage)      — every stage goes to stderr AND a persistent
 *                              log file AND a one-line on-screen status
 *                              (drawn by the menu above the footer).
 *   2. sw_trace_flush()     — PRESENTS the stage line BEFORE a potentially
 *                              blocking action (directory scan, JAR read,
 *                              VM init). If the action hangs, the last
 *                              visible line names the culprit.
 *   3. sw_trace_heartbeat() — SDL timer thread appends "alive: <line>" to
 *                              the log every 2 s: alive-lines flowing while
 *                              the screen is frozen == the main thread is
 *                              stuck inside the named stage; lines stopped
 *                              == the whole process died inside it.
 *
 * Log file: sdmc:/switch/j2me/log.txt on __SWITCH__ (same directory as
 * settings.ini — proven writable by the MINUS toggle), $NOJME_SWITCH_UI_DIR/
 * log.txt on host verification builds (NOJME_SWITCH_TRACE), stderr-only
 * otherwise. Truncated once per process, capped at 256 KB, auto-disabled on
 * first write error — diagnostics must never make things worse.
 *
 * Desktop builds (no __SWITCH__, no NOJME_SWITCH_TRACE) get macro no-ops so
 * shared sources (main.c, sdl_graphics.c) compile unchanged everywhere.
 */
#ifndef SWITCH_TRACE_H
#define SWITCH_TRACE_H

#include <stdint.h>

#if defined(__SWITCH__) || defined(NOJME_SWITCH_TRACE)

/* Stage marker: fmt + args (printf subset, max ~150 chars). Writes the line
 * to stderr + the log file (timestamped) and stores it as the on-screen
 * status line (sw_trace_line). Thread-safe best effort; never blocks the
 * caller for longer than one small append write. */
void sw_trace(const char* fmt, ...);

/* v34.92: file/stderr logging gate (the on-screen status line stays live).
 * DEFAULT IS OFF — «логи по умолчанию выключены», включается настройкой
 * logs=on в settings.ini (пункт «Логи») или env NOJME_SWITCH_LOGS=1. */
void sw_trace_set_enabled(int on);

/* Current status line ("" before the first sw_trace). The menu renders it
 * every frame; sw_trace_flush() puts it on screen alone. */
const char* sw_trace_line(void);

/* Dark screen + the current stage line, PRESENTED immediately. Call right
 * BEFORE a potentially blocking action so a hang leaves the stage visible.
 * No-op when the UI canvas does not exist yet. */
void sw_trace_flush(void);

/* 2-second heartbeat logger (SDL timer thread). Idempotent. */
void sw_trace_heartbeat(void);

#else /* desktop: compile away */

#define sw_trace(...)        do { } while (0)
#define sw_trace_line()      ("")
#define sw_trace_flush()     do { } while (0)
#define sw_trace_heartbeat() do { } while (0)
#define sw_trace_set_enabled(on) do { (void)(on); } while (0)

#endif

#endif /* SWITCH_TRACE_H */
