/*
 * switch_common.h — shared settings model for the Nintendo Switch frontend.
 *
 * The Switch port (Makefile: platform=switch) is an SDL2 app: the same
 * core drives a 1280x720 window with an in-app menu system (game browser +
 * settings) implemented in src/switch/switch_ui.c. Settings persist to
 * <sdmc:/switch/j2me/settings.ini> on real hardware (plain file next to
 * the binary in non-Switch verification builds).
 */
#ifndef SWITCH_COMMON_H
#define SWITCH_COMMON_H

#include <stddef.h>

/* ---- Display scaling modes (settings item "Масштаб") ---- */
#define NOJME_SCALE_STRETCH   0  /* растянуть на весь экран (игнор пропорций) */
#define NOJME_SCALE_FIT_BLACK 1  /* пропорции сохранены, чёрный бордюр */
#define NOJME_SCALE_FIT_BLUR  2  /* пропорции сохранены, размытый фон вместо бордюра */
#define NOJME_SCALE_MODE_COUNT 3

/* ---- Game canvas filtering (settings item "Фильтр") ---- */
#define NOJME_FILTER_NEAREST 0  /* пиксельный (retro) */
#define NOJME_FILTER_LINEAR  1  /* сглаженный */
#define NOJME_FILTER_COUNT   2

/* ---- VM speed presets (settings item "Скорость VM") ----
 * Mirrors the libretro j2me_vm_speed option semantics: the value maps to
 * g_jvm_thread_budget (game-thread instruction budget per 16.6 ms slice):
 * original = 15000 (~0.9M instr/s, «телефонный» темп), fast = 90000
 * (default, ~5.4M instr/s), turbo = 0 (бюджет снят, потоки свободны). */
#define NOJME_VM_SPEED_ORIGINAL 0
#define NOJME_VM_SPEED_FAST     1
#define NOJME_VM_SPEED_TURBO    2
#define NOJME_VM_SPEED_COUNT    3

/* ---- UI language (v34.90): MINUS toggles RU/EN in every frontend screen.
 * Persisted as lang=ru|en in settings.ini; NOJME_SWITCH_LANG env overrides
 * for host verification builds. ---- */
#define NOJME_LANG_RU 0
#define NOJME_LANG_EN 1

/* ---- Switch frontend screen geometry ---- */
#define SWITCH_UI_WIDTH  1280
#define SWITCH_UI_HEIGHT 720

typedef struct {
    int scale_mode;          /* NOJME_SCALE_* */
    int filter;              /* NOJME_FILTER_* */
    int audio_enabled;       /* 1 = звук включён */
    int vm_speed;            /* NOJME_VM_SPEED_* */
    int lang;                /* NOJME_LANG_RU / NOJME_LANG_EN */
    int logs_enabled;        /* v34.92: 1 = писать log.txt (по умолчанию ВЫКЛ) */
    char games_dir[512];     /* стартовая папка браузера ("") = корень SD */
} SwitchSettings;

/* ---- v34.92 per-game settings ("индивидуальные настройки по минус") ----
 * Every field is a sentinel override: -1 = follow the global settings.ini
 * value; resolution 0x0 = auto (manifest hint / 240x320). Persisted to
 * <settings_dir>/pergame/<jar-name>.ini. */
typedef struct {
    int scale_mode;
    int filter;
    int audio_enabled;
    int vm_speed;
    int res_w, res_h;
} SwitchGameSettings;

/* Load the per-game overrides for a JAR path (missing keys = -1/0x0). */
void switch_game_settings_load(const char* jar_path, SwitchGameSettings* out);
/* Persist the per-game overrides. Returns 0 on success. */
int switch_game_settings_save(const char* jar_path, const SwitchGameSettings* s);
/* Merge per-game overrides into a copy of the current global settings. */
void switch_game_settings_merge(const SwitchGameSettings* p, SwitchSettings* out);
/* The in-game per-game settings screen (MINUS -> pause -> "Настройки игры"):
 * drives its own pump loop on the UI canvas. Returns when the user leaves. */
int switch_ui_game_settings_screen(void);
/* JAR of the running session (set by switch_game_settings_load); the pause
 * menu's settings screen persists against it. */
const char* switch_game_settings_current_jar(void);
/* Re-read the global settings.ini into the singleton (session teardown). */
void switch_settings_reload_from_disk(void);

/* v34.92 E2E seam: synthetic NOJME_SWITCH_KEYS tokens outside the menu
 * (in-game pause menu, frame pump). Production builds: always 0. */
unsigned switch_ui_autotest_keys(void);

/* Defaults: fit-with-black-borders, pixel filtering, audio on, fast VM. */
void switch_settings_defaults(SwitchSettings* s);

/* Singleton: loads settings.ini on first call. NULL-safe (returns defaults
 * if the file is missing/corrupt). */
const SwitchSettings* switch_settings_get(void);

/* Update the singleton (call switch_settings_save right after to persist). */
void switch_settings_set(const SwitchSettings* s);

/* Persist to settings.ini. Returns 0 on success. */
int switch_settings_save(const SwitchSettings* s);

/* Human-readable value names for the settings UI. */
const char* switch_scale_mode_name(int mode);
const char* switch_filter_name(int filter);
const char* switch_vm_speed_name(int speed);

/* ================= v34.90 UI language (RU/EN) ================= */

/* Current language (NOJME_LANG_*). Loads with the settings singleton. */
int switch_lang(void);

/* Toggle RU <-> EN, persist to settings.ini, return the NEW value. */
int switch_lang_toggle(void);

/* "Русский" / "English" — the language's own name. */
const char* switch_lang_name(int lang);

/* Localized UI string by id (enum SwitchTextId below). */
const char* switch_text(int id);

/* One-line top-left badge: current language + the MINUS hint, e.g.
 * "Язык: Русский   минус = English". Composed in the ACTIVE language. */
const char* switch_lang_badge_text(void);

/* String ids for every user-visible frontend string (RU + EN table in
 * switch_ui.c). Drawn with the embedded 8x16 font: ASCII + Cyrillic only
 * (no em-dash/ellipsis — those glyphs are not in the font). */
enum {
    ST_APP_TITLE = 0,
    ST_MENU_OPEN,
    ST_MENU_SETTINGS,
    ST_MENU_EXIT,
    ST_MENU_TAGLINE,
    ST_FOOTER_MAIN,
    ST_BROWSER_TITLE,
    ST_BROWSER_EMPTY,
    ST_BROWSER_TRUNC,
    ST_BROWSER_DIR,
    ST_FOOTER_BROWSER,      /* counts appended with %d/%d */
    ST_SETTINGS_TITLE,
    ST_SET_SCALE,
    ST_SET_FILTER,
    ST_SET_AUDIO,
    ST_SET_VM_SPEED,
    ST_SET_GAMES_DIR,
    ST_SET_SAVE,
    ST_VAL_ON,
    ST_VAL_OFF,
    ST_PREVIEW_LABEL,
    ST_FOOTER_SETTINGS,
    ST_DIRPICKER_TITLE,
    ST_DIRPICKER_THIS,
    ST_DIRPICKER_MAKE,
    ST_FOOTER_DIRPICKER,
    ST_PAUSE_TITLE,
    ST_PAUSE_RESUME,
    ST_PAUSE_EXIT,
    /* v34.92: pause menu items + per-game settings screen */
    ST_PAUSE_ITEM_RESUME,
    ST_PAUSE_ITEM_SETTINGS,
    ST_PAUSE_ITEM_EXIT,
    ST_FOOTER_PAUSE,
    ST_GSET_TITLE,
    ST_GSET_SCALE,
    ST_GSET_FILTER,
    ST_GSET_AUDIO,
    ST_GSET_VM_SPEED,
    ST_GSET_RES,
    ST_GSET_SAVE,
    ST_GSET_RESET,
    ST_GSET_GLOBAL,
    ST_GSET_RES_AUTO,
    ST_GSET_RESTART,
    ST_FOOTER_GSET,
    ST_SET_LOGS,
    ST_SCALE_STRETCH,
    ST_SCALE_FIT_BLACK,
    ST_SCALE_FIT_BLUR,
    ST_FILTER_LINEAR,
    ST_FILTER_NEAREST,
    ST_VM_ORIGINAL,
    ST_VM_FAST,
    ST_VM_TURBO,
    ST_TEXT_COUNT
};

#endif /* SWITCH_COMMON_H */
