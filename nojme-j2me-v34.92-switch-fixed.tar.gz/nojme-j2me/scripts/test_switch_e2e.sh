#!/bin/bash
# E2E автотест Switch-фронтенда (bin/switchui-verify, SDL dummy video).
# Сценарий (v34.92):
#   сессия 1: меню -> браузер -> sub -> TestDosWrite.jar (мгновенно
#             завершается) -> возврат в меню;
#   сессия 2: браузер -> sub -> TestPause.jar -> ДВА цикла
#             «MINUS пауза (VM запаркована) -> A продолжить» -> тикер
#             TestPause обязан ПРОДОЛЖИТЬ печатать после закрытия паузы и
#             дойти до «PAUSECHK done» (регрессия дедлока «вернуться в
#             игру нельзя»);
#   выход из приложения по B в меню.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_e2e
rm -rf "$D"; mkdir -p "$D/roms/sub"
cp scripts/testdosw/TestDosWrite.jar "$D/roms/sub/"
cp scripts/testpause/TestPause.jar   "$D/roms/sub/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# меню (обе сессии): A (браузер), A (войти в sub), A (выбрать jar) x2,
# затем B — выход из приложения, когда TestPause уже завершился
export NOJME_SWITCH_KEYS="A:500,A:400,A:400,A:500,A:400,DOWN:300,A:400,B:25000"
# в игре (свой поток токенов): MINUS пауза -> A продолжить, дважды
export NOJME_SWITCH_GAME_KEYS="MINUS:1500,A:1500,MINUS:1500,A:800"

timeout 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
grep -q "TDW:DONE ALL DOS CHECKS PASSED" "$D/err.log" || { echo "FAIL: TestDosWrite не выполнился"; ok=0; }
grep -q "game selected: .*TestDosWrite.jar" "$D/err.log" || { echo "FAIL: jar 1 не выбран"; ok=0; }
grep -q "game selected: .*TestPause.jar" "$D/err.log" || { echo "FAIL: jar 2 не выбран"; ok=0; }
grep -q "session complete — back to menu" "$D/err.log" || { echo "FAIL: нет возврата в меню"; ok=0; }
grep -q "menu session end (result=0)" "$D/err.log" || { echo "FAIL: приложение не вышло из меню"; ok=0; }
grep -q "\[SWITCH\] platform init OK" "$D/err.log" || { echo "FAIL: платформа не инициализировалась"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }

# v34.92: пауза/резюм
opens=$(grep -c "\[SWITCH\] pause menu open" "$D/err.log" || true)
closes=$(grep -c "\[SWITCH\] pause menu close" "$D/err.log" || true)
[ "$opens" -ge 2 ] || { echo "FAIL: пауза открылась $opens раз (хотим 2)"; ok=0; }
[ "$closes" -ge 2 ] || { echo "FAIL: пауза закрылась $closes раз (хотим 2)"; ok=0; }

# тикер TestPause продолжается ПОСЛЕ закрытия паузы (дедлок-регрессия)
last_close=$(grep -n "\[SWITCH\] pause menu close" "$D/err.log" | tail -1 | cut -d: -f1)
[ -n "$last_close" ] || { echo "FAIL: нет строки закрытия паузы"; ok=0; }
ticks_after=$(tail -n +"$last_close" "$D/err.log" | grep -c "PAUSECHK tick=" || true)
echo "PAUSECHK ticks after last resume: $ticks_after"
[ "$ticks_after" -ge 3 ] || { echo "FAIL: тикер не продолжил работу после паузы (дедлок?)"; ok=0; }
grep -q "PAUSECHK done" "$D/err.log" || { echo "FAIL: TestPause не дошёл до конца (VM встала)"; ok=0; }

# виртуальные часы: за паузу тикер не должен перескакивать (dtime шаг ~200мс,
# допуск 350мс на планировщик) — проверяем первый тик после резюма
first_after=$(tail -n +"$last_close" "$D/err.log" | grep -m1 -o "dtime=[0-9]*" | cut -d= -f2)
echo "first dtime after resume: $first_after"
[ -n "$first_after" ] && [ "$first_after" -lt 6000 ] || { echo "FAIL: часы прыгнули вперёд за паузу"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "SWITCH-UI E2E: ALL CHECKS PASSED"
else
    echo "SWITCH-UI E2E: FAILED — последние строки err.log:"; tail -25 "$D/err.log"
fi
exit $((1 - ok))
