#!/usr/bin/env python3
"""Minimal Java class disassembler for J2ME debugging (nojme project).
Usage: jdis2.py <classfile> [method-name-filter]
"""
import struct, sys, io

OPCODES = {
    0x00:'nop',0x01:'aconst_null',0x02:'iconst_m1',0x03:'iconst_0',0x04:'iconst_1',0x05:'iconst_2',
    0x06:'iconst_3',0x07:'iconst_4',0x08:'iconst_5',0x09:'lconst_0',0x0a:'lconst_1',
    0x0b:'fconst_0',0x0c:'fconst_1',0x0d:'fconst_2',0x0e:'dconst_0',0x0f:'dconst_1',
    0x10:'bipush',0x11:'sipush',0x12:'ldc',0x13:'ldc_w',0x14:'ldc2_w',
    0x15:'iload',0x16:'lload',0x17:'fload',0x18:'dload',0x19:'aload',
    0x1a:'iload_0',0x1b:'iload_1',0x1c:'iload_2',0x1d:'iload_3',
    0x1e:'lload_0',0x1f:'lload_1',0x20:'lload_2',0x21:'lload_3',
    0x22:'fload_0',0x23:'fload_1',0x24:'fload_2',0x25:'fload_3',
    0x26:'dload_0',0x27:'dload_1',0x28:'dload_2',0x29:'dload_3',
    0x2a:'aload_0',0x2b:'aload_1',0x2c:'aload_2',0x2d:'aload_3',
    0x2e:'iaload',0x2f:'laload',0x30:'faload',0x31:'daload',0x32:'aaload',0x33:'baload',0x34:'caload',0x35:'saload',
    0x36:'istore',0x37:'lstore',0x38:'fstore',0x39:'dstore',0x3a:'astore',
    0x3b:'istore_0',0x3c:'istore_1',0x3d:'istore_2',0x3e:'istore_3',
    0x3f:'lstore_0',0x40:'lstore_1',0x41:'lstore_2',0x42:'lstore_3',
    0x43:'fstore_0',0x44:'fstore_1',0x45:'fstore_2',0x46:'fstore_3',
    0x47:'dstore_0',0x48:'dstore_1',0x49:'dstore_2',0x4a:'dstore_3',
    0x4b:'astore_0',0x4c:'astore_1',0x4d:'astore_2',0x4e:'astore_3',
    0x4f:'iastore',0x50:'lastore',0x51:'fastore',0x52:'dastore',0x53:'aastore',0x54:'bastore',0x55:'castore',0x56:'sastore',
    0x57:'pop',0x58:'pop2',0x59:'dup',0x5a:'dup_x1',0x5b:'dup_x2',0x5c:'dup2',0x5d:'dup2_x1',0x5e:'dup2_x2',0x5f:'swap',
    0x60:'iadd',0x61:'ladd',0x62:'fadd',0x63:'dadd',0x64:'isub',0x65:'lsub',0x66:'fsub',0x67:'dsub',
    0x68:'imul',0x69:'lmul',0x6a:'fmul',0x6b:'dmul',0x6c:'idiv',0x6d:'ldiv',0x6e:'fdiv',0x6f:'ddiv',
    0x70:'irem',0x71:'lrem',0x72:'frem',0x73:'drem',0x74:'ineg',0x75:'lneg',0x76:'fneg',0x77:'dneg',
    0x78:'ishl',0x79:'lshl',0x7a:'ishr',0x7b:'lshr',0x7c:'iushr',0x7d:'lushr',
    0x7e:'iand',0x7f:'land',0x80:'ior',0x81:'lor',0x82:'ixor',0x83:'lxor',0x84:'iinc',
    0x85:'i2l',0x86:'i2f',0x87:'i2d',0x88:'l2i',0x89:'l2f',0x8a:'l2d',0x8b:'f2i',0x8c:'f2l',0x8d:'f2d',
    0x8e:'d2i',0x8f:'d2l',0x90:'d2f',0x91:'i2b',0x92:'i2c',0x93:'i2s',
    0x94:'lcmp',0x95:'fcmpl',0x96:'fcmpg',0x97:'dcmpl',0x98:'dcmpg',
    0x99:'ifeq',0x9a:'ifne',0x9b:'iflt',0x9c:'ifge',0x9d:'ifgt',0x9e:'ifle',
    0x9f:'if_icmpeq',0xa0:'if_icmpne',0xa1:'if_icmplt',0xa2:'if_icmpge',0xa3:'if_icmpgt',0xa4:'if_icmple',
    0xa5:'if_acmpeq',0xa6:'if_acmpne',0xa7:'goto',0xa8:'jsr',0xa9:'ret',
    0xaa:'tableswitch',0xab:'lookupswitch',
    0xac:'ireturn',0xad:'lreturn',0xae:'freturn',0xaf:'dreturn',0xb0:'areturn',0xb1:'return',
    0xb2:'getstatic',0xb3:'putstatic',0xb4:'getfield',0xb5:'putfield',
    0xb6:'invokevirtual',0xb7:'invokespecial',0xb8:'invokestatic',0xb9:'invokeinterface',0xba:'invokedynamic',
    0xbb:'new',0xbc:'newarray',0xbd:'anewarray',0xbe:'arraylength',0xbf:'athrow',
    0xc0:'checkcast',0xc1:'instanceof',0xc2:'monitorenter',0xc3:'monitorexit',
    0xc4:'wide',0xc5:'multianewarray',0xc6:'ifnull',0xc7:'ifnonnull',0xc8:'goto_w',0xc9:'jsr_w',
}

class Reader:
    def __init__(self, data): self.d = data; self.p = 0
    def u1(self): v = self.d[self.p]; self.p += 1; return v
    def u2(self): v = struct.unpack_from('>H', self.d, self.p)[0]; self.p += 2; return v
    def u4(self): v = struct.unpack_from('>I', self.d, self.p)[0]; self.p += 4; return v
    def s2(self): v = struct.unpack_from('>h', self.d, self.p)[0]; self.p += 2; return v
    def s4(self): v = struct.unpack_from('>i', self.d, self.p)[0]; self.p += 4; return v
    def read(self, n): v = self.d[self.p:self.p+n]; self.p += n; return v

def parse(data):
    r = Reader(data)
    magic = r.u4()
    assert magic == 0xCAFEBABE, hex(magic)
    r.u2(); r.u2()  # minor, major
    n = r.u2()
    cp = [None]*n
    i = 1
    while i < n:
        tag = r.u1()
        if tag == 1:  # utf8
            ln = r.u2(); cp[i] = ('Utf8', r.read(ln).decode('utf-8', 'replace'))
        elif tag == 3: cp[i] = ('Int', r.u4())
        elif tag == 4: cp[i] = ('Float', struct.unpack('>f', r.read(4))[0])
        elif tag == 5: cp[i] = ('Long', struct.unpack('>q', r.read(8))[0]); i += 1
        elif tag == 6: cp[i] = ('Double', struct.unpack('>d', r.read(8))[0]); i += 1
        elif tag == 7: cp[i] = ('Class', r.u2())
        elif tag == 8: cp[i] = ('String', r.u2())
        elif tag == 9: cp[i] = ('Field', r.u2(), r.u2())
        elif tag == 10: cp[i] = ('Method', r.u2(), r.u2())
        elif tag == 11: cp[i] = ('IfaceMethod', r.u2(), r.u2())
        elif tag == 12: cp[i] = ('NameType', r.u2(), r.u2())
        elif tag == 15: r.u1(); r.u2(); cp[i] = ('MH',)
        elif tag == 16: r.u2(); cp[i] = ('RT',)
        elif tag == 17: r.u2(); r.u2(); cp[i] = ('Dyn',)
        elif tag == 18: r.u2(); r.u2(); cp[i] = ('InvokeDyn',)
        else: raise ValueError(f'tag {tag}')
        i += 1
    def utf(i):
        return cp[i][1] if cp[i] and cp[i][0] == 'Utf8' else '?'
    def cls(i):
        e = cp[i]
        return utf(e[1]) if e and e[0] == 'Class' else '?'
    def entry_str(i):
        if not i or i >= n: return '?'
        e = cp[i]
        t = e[0]
        if t == 'Class': return cls(i)
        if t == 'String': return repr(utf(e[1]))
        if t == 'Int': return str(e[1])
        if t == 'Float': return str(e[1])
        if t == 'Long': return str(e[1])
        if t == 'Double': return str(e[1])
        if t in ('Field','Method','IfaceMethod'):
            nt = cp[e[2]]
            return f'{cls(e[1])}.{utf(nt[1])}:{utf(nt[2])}'
        if t == 'NameType': return f'{utf(e[1])}:{utf(e[2])}'
        return f'{t}?'
    acc = r.u2(); this_i = r.u2(); sup_i = r.u2()
    out = [f'class {cls(this_i)} extends {cls(sup_i) if sup_i else "-"} acc=0x{acc:x}']
    nif = r.u2()
    ifs = [cls(r.u2()) for _ in range(nif)]
    if ifs: out.append('implements ' + ', '.join(ifs))
    nf = r.u2()
    fields = []
    for _ in range(nf):
        fa, fn, fd = r.u2(), utf(r.u2()), utf(r.u2())
        na = r.u2()
        const = None
        for _ in range(na):
            an = utf(r.u2()); alen = r.u4(); ad = r.read(alen)
            if an == 'ConstantValue': const = entry_str(struct.unpack_from('>H', ad)[0])
        fields.append(f'  field {fn} : {fd} acc=0x{fa:x}' + (f' = {const}' if const else ''))
    out += fields
    nm = r.u2()
    for _ in range(nm):
        ma = r.u2(); mn = utf(r.u2()); md = utf(r.u2())
        out.append(f'method {mn} {md} acc=0x{ma:x}')
        na = r.u2()
        for _ in range(na):
            an = utf(r.u2()); alen = r.u4(); ad = r.read(alen)
            if an == 'Code':
                cr = Reader(ad)
                mx_s, mx_l, clen = cr.u2(), cr.u2(), cr.u4()
                code = cr.read(clen)
                out.append(f'  // max_stack={mx_s} max_locals={mx_l} codelen={clen}')
                p = 0
                while p < len(code):
                    op = code[p]
                    name = OPCODES.get(op, f'0x{op:02x}?')
                    start = p
                    p += 1
                    arg = ''
                    try:
                        if op in (0x10,): arg = str(struct.unpack_from('>b', code, p)[0]); p += 1
                        elif op in (0x11,): arg = str(struct.unpack_from('>h', code, p)[0]); p += 2
                        elif op in (0x12,): arg = entry_str(code[p]); p += 1
                        elif op in (0x13,0x14,0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xb8,0xbb,0xbd,0xc0,0xc1):
                            arg = entry_str(struct.unpack_from('>H', code, p)[0]); p += 2
                        elif op in (0x15,0x16,0x17,0x18,0x19,0x36,0x37,0x38,0x39,0x3a,0xa9):
                            arg = str(code[p]); p += 1
                        elif op == 0x84:
                            idx, c = struct.unpack_from('>Bb', code, p); p += 2; arg = f'{idx} {c:+d}'
                        elif 0x99 <= op <= 0xa8 or op in (0xc6,0xc7):
                            off = struct.unpack_from('>h', code, p)[0]; p += 2; arg = f'-> {start+off}'
                        elif op in (0xc8,0xc9):
                            off = struct.unpack_from('>i', code, p)[0]; p += 4; arg = f'-> {start+off}'
                        elif op == 0xb9:
                            idx, cnt, zero = struct.unpack_from('>HB', code, p); p += 4
                            arg = entry_str(idx) + f' count={cnt}'
                        elif op == 0xbc:
                            at = code[p]; p += 1; arg = f'atype={at}'
                        elif op == 0xc5:
                            idx, dims = struct.unpack_from('>HB', code, p); p += 3
                            arg = entry_str(idx) + f' dims={dims}'
                        elif op == 0xaa:  # tableswitch
                            pad = (4 - (p % 4)) % 4; p += pad
                            df = struct.unpack_from('>i', code, p)[0]; p += 4
                            lo = struct.unpack_from('>i', code, p)[0]; p += 4
                            hi = struct.unpack_from('>i', code, p)[0]; p += 4
                            offs = [struct.unpack_from('>i', code, p+4*k)[0] for k in range(hi-lo+1)]
                            p += 4*(hi-lo+1)
                            arg = f'lo={lo} hi={hi} ' + ' '.join(f'{lo+k}->{start+o}' for k, o in enumerate(offs))
                        elif op == 0xab:  # lookupswitch
                            pad = (4 - (p % 4)) % 4; p += pad
                            df = struct.unpack_from('>i', code, p)[0]; p += 4
                            np = struct.unpack_from('>i', code, p)[0]; p += 4
                            pairs = []
                            for k in range(np):
                                m = struct.unpack_from('>i', code, p)[0]
                                o = struct.unpack_from('>i', code, p+4)[0]
                                p += 8; pairs.append(f'{m}->{start+o}')
                            arg = 'default->' + str(start+df) + ' ' + ' '.join(pairs)
                        elif op == 0xc4:  # wide
                            wop = code[p]; p += 1
                            idx = struct.unpack_from('>H', code, p)[0]; p += 2
                            if wop == 0x84:
                                c = struct.unpack_from('>h', code, p)[0]; p += 2
                                arg = f'{OPCODES.get(wop,hex(wop))} {idx} {c:+d}'
                            else:
                                arg = f'{OPCODES.get(wop,hex(wop))} {idx}'
                    except Exception as e:
                        arg = f'<err {e}>'
                    out.append(f'    {start:5d}: {name} {arg}')
            elif an in ('Exceptions',):
                er = Reader(ad)
                cnt = er.u2()
                excs = [cls(er.u2()) for _ in range(cnt)]
                out.append(f'  // throws {", ".join(excs)}')
    return '\n'.join(out)

if __name__ == '__main__':
    data = open(sys.argv[1], 'rb').read()
    text = parse(data)
    filt = sys.argv[2] if len(sys.argv) > 2 else None
    if filt:
        keep, keep_flag = [], False
        for line in text.split('\n'):
            if line.startswith('method '):
                keep_flag = filt in line
            if keep_flag: keep.append(line)
        print('\n'.join(keep))
    else:
        print(text)
