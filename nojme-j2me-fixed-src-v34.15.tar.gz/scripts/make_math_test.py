#!/usr/bin/env python3
# Extracts the M3G math section from the REAL mobile3d.c and builds a
# standalone test harness around it, so the tested code is the production code.
import re, sys

src = open('/home/z/my-project/work/src/midp/mobile3d.c').read()

start_marker = "/* ============================================================================\n * M3G Math Functions"
end_marker = "/* ============================================================================\n * M3G Software Rasterizer"
i = src.index(start_marker)
j = src.index(end_marker)
math_block = src[i:j]

prologue = r'''
/* Test harness around the PRODUCTION math code extracted from mobile3d.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct {
    float m[16];  /* Column-major: m[col*4+row] */
} M3GTransform;

#define M3G_INLINE static inline

static int mat_near_identity(const M3GTransform* t, float eps) {
    for (int i = 0; i < 16; i++) {
        float want = (i % 5 == 0) ? 1.0f : 0.0f;
        if (fabsf(t->m[i] - want) > eps) return 0;
    }
    return 1;
}

'''
epilogue = r'''

/* ======================= TESTS ======================= */
static int g_failures = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { g_failures++; printf("FAIL: " __VA_ARGS__); printf(" (%s:%d)\n", __FILE__, __LINE__); } \
} while (0)

int main(void) {
    M3GTransform t, res, inv, view, cam;

    /* --- 1. invert: identity --- */
    m3g_transform_identity(&t);
    CHECK(m3g_transform_invert(&inv, &t) == 1, "identity invert");
    CHECK(mat_near_identity(&inv, 1e-6f), "identity inverse == identity");

    /* --- 2. invert: translation --- */
    m3g_transform_identity(&t);
    m3g_transform_translate(&t, 5.0f, -3.0f, 7.5f);
    CHECK(m3g_transform_invert(&inv, &t) == 1, "translation invert");
    m3g_transform_multiply(&res, &t, &inv);
    CHECK(mat_near_identity(&res, 1e-4f), "T * T^-1 == I (translation)");
    m3g_transform_multiply(&res, &inv, &t);
    CHECK(mat_near_identity(&res, 1e-4f), "T^-1 * T == I (translation)");

    /* --- 3. invert: rotation (90 deg around Y) --- */
    m3g_transform_identity(&t);
    m3g_transform_rotate(&t, 90.0f * 3.14159f / 180.0f, 0, 1, 0);
    CHECK(m3g_transform_invert(&inv, &t) == 1, "rotation invert");
    m3g_transform_multiply(&res, &t, &inv);
    CHECK(mat_near_identity(&res, 1e-4f), "R * R^-1 == I (rotation)");

    /* --- 4. invert: SCALED+ROTATED+TRANSLATED (the case the old
     *     transpose-based camera inverse got wrong) --- */
    m3g_transform_identity(&t);
    m3g_transform_scale(&t, 2.0f, 0.5f, 3.0f);
    m3g_transform_rotate(&t, 35.0f * 3.14159f / 180.0f, 1, 1, 0);
    m3g_transform_translate(&t, 10.0f, -4.0f, 2.0f);
    CHECK(m3g_transform_invert(&inv, &t) == 1, "rigid+scale invert");
    m3g_transform_multiply(&res, &t, &inv);
    CHECK(mat_near_identity(&res, 1e-3f), "M * M^-1 == I (scale+rot+trans)");

    /* --- 5. invert: singular matrix fails cleanly --- */
    memset(&t, 0, sizeof(t));
    CHECK(m3g_transform_invert(&inv, &t) == 0, "singular invert returns 0");

    /* --- 6. camera view from world: scaled camera transform.
     * Camera at (0,0,5) with uniform scale 2 — the world point (0,0,0)
     * must land at view (0,0,-5) regardless of the scale. */
    m3g_transform_identity(&t);
    m3g_transform_scale(&t, 2.0f, 2.0f, 2.0f);
    m3g_transform_translate(&t, 0, 0, 5.0f);
    m3g_camera_view_from_transform(&view, &t);
    {
        float p[4] = {0, 0, 0, 1};
        float out[4];
        m3g_transform_point(out, &view, p);
        CHECK(fabsf(out[0]) < 1e-4f && fabsf(out[1]) < 1e-4f &&
              fabsf(out[2] + 5.0f) < 1e-4f && fabsf(out[3] - 1.0f) < 1e-4f,
              "scaled camera: world origin -> view (0,0,-5), got (%f,%f,%f,%f)",
              out[0], out[1], out[2], out[3]);
    }

    /* --- 7. lookAt + invert round trip --- */
    m3g_transform_look_at(&view, 1.0f, 2.0f, 3.0f, -4.0f, 0.5f, 1.0f, 0.0f, 1.0f, 0.0f);
    CHECK(m3g_transform_invert(&cam, &view) == 1, "look_at invert");
    CHECK(fabsf(cam.m[12] - 1.0f) < 1e-3f &&
          fabsf(cam.m[13] - 2.0f) < 1e-3f &&
          fabsf(cam.m[14] - 3.0f) < 1e-3f,
          "camera world translation == eye, got (%f,%f,%f)",
          cam.m[12], cam.m[13], cam.m[14]);
    {
        float at[4] = {-4.0f, 0.5f, 1.0f, 1.0f};
        float out[4];
        m3g_transform_point(out, &view, at);
        CHECK(out[2] < 0.0f, "look target in front of camera (view z<0), got %f", out[2]);
    }
    {
        for (int c = 0; c < 3; c++) {
            float len = sqrtf(cam.m[c*4+0]*cam.m[c*4+0] +
                              cam.m[c*4+1]*cam.m[c*4+1] +
                              cam.m[c*4+2]*cam.m[c*4+2]);
            CHECK(fabsf(len - 1.0f) < 1e-3f, "cam_world column %d orthonormal (len=%f)", c, len);
        }
    }

    /* --- 8. perspective: near/far plane mapping, w == view distance. --- */
    m3g_transform_perspective(&t, 60.0f, 1.0f, 1.0f, 100.0f);
    {
        float out[4];
        m3g_transform_point(out, &t, (float[4]){0.5f, 0.5f, -5.0f, 1.0f});
        CHECK(fabsf(out[3] - 5.0f) < 1e-4f, "perspective w == -z_view (got %f, want 5)", out[3]);
        CHECK(out[2] > -out[3] && out[2] < out[3], "z inside clip range");
        m3g_transform_point(out, &t, (float[4]){0.0f, 0.0f, -1.0f, 1.0f});
        CHECK(fabsf(out[2] + out[3]) < 1e-3f * fmaxf(1.0f, out[3]),
              "point on near plane maps to ndc z ~ -w (got %f vs %f)", out[2], out[3]);
        m3g_transform_point(out, &t, (float[4]){0.0f, 0.0f, -100.0f, 1.0f});
        CHECK(fabsf(out[2] - out[3]) < 1e-2f * fmaxf(1.0f, out[3]),
              "point on far plane maps to ndc z ~ w (got %f vs %f)", out[2], out[3]);
    }

    /* --- 9. ortho: corners map to NDC corners --- */
    m3g_transform_ortho(&t, -10.0f, 10.0f, -10.0f, 10.0f, 1.0f, 100.0f);
    {
        float out[4];
        m3g_transform_point(out, &t, (float[4]){-10.0f, -10.0f, -1.0f, 1.0f});
        CHECK(fabsf(out[0] + 1.0f) < 1e-3f && fabsf(out[1] + 1.0f) < 1e-3f,
              "ortho left-bottom -> (-1,-1), got (%f,%f)", out[0], out[1]);
        m3g_transform_point(out, &t, (float[4]){10.0f, 10.0f, -1.0f, 1.0f});
        CHECK(fabsf(out[0] - 1.0f) < 1e-3f && fabsf(out[1] - 1.0f) < 1e-3f,
              "ortho right-top -> (1,1), got (%f,%f)", out[0], out[1]);
    }

    /* --- 10. camera view inverse on a YAW camera (rotation only) --- */
    m3g_transform_identity(&t);
    m3g_transform_rotate(&t, 90.0f * 3.14159f / 180.0f, 0, 1, 0);
    m3g_transform_translate(&t, 0, 0, 0);
    m3g_camera_view_from_transform(&view, &t);
    {
        float p[4] = {-5.0f, 0.0f, 0.0f, 1.0f};
        float out[4];
        m3g_transform_point(out, &view, p);
        CHECK(fabsf(out[0]) < 1e-3f && fabsf(out[1]) < 1e-3f && fabsf(out[2] + 5.0f) < 1e-3f,
              "yaw camera: (-5,0,0) -> view (0,0,-5), got (%f,%f,%f)",
              out[0], out[1], out[2]);
    }

    /* --- 11. getTransformTo-style composition: up = L_root * L_child --- */
    {
        M3GTransform L_parent, L_child, up;
        m3g_transform_identity(&L_parent);
        m3g_transform_translate(&L_parent, 10.0f, 0.0f, 0.0f);
        m3g_transform_identity(&L_child);
        m3g_transform_translate(&L_child, 0.0f, 5.0f, 0.0f);
        m3g_transform_identity(&up);
        m3g_transform_multiply(&up, &L_parent, &up);
        m3g_transform_multiply(&up, &L_child, &up);
        float p[4] = {1.0f, 2.0f, 3.0f, 1.0f};
        float out[4];
        m3g_transform_point(out, &up, p);
        CHECK(fabsf(out[0] - 11.0f) < 1e-4f && fabsf(out[1] - 7.0f) < 1e-4f &&
              fabsf(out[2] - 3.0f) < 1e-4f,
              "parent*child composition, got (%f,%f,%f)", out[0], out[1], out[2]);
    }

    if (g_failures == 0) {
        printf("ALL M3G MATH TESTS PASSED\n");
        return 0;
    }
    printf("%d FAILURE(S)\n", g_failures);
    return 1;
}
'''

open('/home/z/my-project/scripts/m3g_math_test.c', 'w').write(prologue + math_block + epilogue)
print("harness written: /home/z/my-project/scripts/m3g_math_test.c")
