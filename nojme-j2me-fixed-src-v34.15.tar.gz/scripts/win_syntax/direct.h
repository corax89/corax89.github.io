/* direct.h — stub for fake-host syntax checks (real MinGW provides it) */
#ifndef FAKE_DIRECT_H_STUB
#define FAKE_DIRECT_H_STUB
int _mkdir(const char*);
int _rmdir(const char*);
#endif
