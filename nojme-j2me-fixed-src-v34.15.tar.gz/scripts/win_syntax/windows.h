/*
 * windows.h — MINIMAL STUB for syntax-checking the _WIN32 code paths on a
 * Linux host (no mingw cross-compiler in the sandbox). NOT a real Windows
 * header; only what the project's _WIN32 branches touch, with shapes loose
 * enough for -fsyntax-only. Never used in real builds.
 */
#ifndef FAKE_WINDOWS_H_STUB
#define FAKE_WINDOWS_H_STUB

#include <stddef.h>
#include <stdio.h>  /* FILE for _wfopen */
#include <time.h>   /* struct tm / time_t for localtime_s, gmtime_s */

typedef unsigned long   DWORD;
typedef unsigned long   ULONG;
typedef long            LONG;
typedef unsigned long long ULONGLONG;
typedef long long       LONGLONG;
typedef int             BOOL;
typedef void*           LPVOID;
typedef void*           HANDLE;
typedef const char*     LPCSTR;
typedef size_t          SIZE_T;
typedef DWORD*          LPDWORD;

#define WINAPI
#define __declspec(x)
#define __stdcall
#define __cdecl
#define INFINITE        0xFFFFFFFFu
#define TLS_OUT_OF_INDEXES 0xFFFFFFFFu
#define WAIT_OBJECT_0   0u
#define WAIT_TIMEOUT    258u
#define TRUE  1
#define FALSE 0
#define MAX_PATH 260

typedef struct _FILETIME { DWORD dwLowDateTime; DWORD dwHighDateTime; } FILETIME;
typedef union  _ULARGE_INTEGER { struct { DWORD LowPart; DWORD HighPart; }; ULONGLONG QuadPart; } ULARGE_INTEGER;
typedef union  _LARGE_INTEGER  { LONGLONG QuadPart; } LARGE_INTEGER;
typedef struct _OVERLAPPED OVERLAPPED;

/* CRITICAL_SECTION / CONDITION_VARIABLE: opaque-ish struct with scalar first
 * member so `{ 0 }` static initialization type-checks like on MinGW. */
typedef struct _CRITICAL_SECTION { void* DebugInfo; long LockCount; long RecursionCount; void* OwningThread; } CRITICAL_SECTION;
typedef struct _CONDITION_VARIABLE { void* Ptr; } CONDITION_VARIABLE;

typedef DWORD (WINAPI *LPTHREAD_START_ROUTINE)(LPVOID);

BOOL       WINAPI SwitchToThread(void);
void       WINAPI Sleep(DWORD ms);
void       WINAPI MemoryBarrier(void);
void       WINAPI InitializeCriticalSection(CRITICAL_SECTION*);
void       WINAPI DeleteCriticalSection(CRITICAL_SECTION*);
void       WINAPI EnterCriticalSection(CRITICAL_SECTION*);
void       WINAPI LeaveCriticalSection(CRITICAL_SECTION*);
BOOL       WINAPI TryEnterCriticalSection(CRITICAL_SECTION*);
DWORD      WINAPI GetCurrentThreadId(void);
HANDLE     WINAPI GetCurrentThread(void);
LONG       WINAPI InterlockedCompareExchange(volatile LONG*, LONG, LONG);
LONG       WINAPI InterlockedExchange(volatile LONG*, LONG);
LONG       WINAPI InterlockedIncrement(volatile LONG*);
LONG       WINAPI InterlockedDecrement(volatile LONG*);
void       WINAPI InitializeConditionVariable(CONDITION_VARIABLE*);
BOOL       WINAPI WakeConditionVariable(CONDITION_VARIABLE*);
BOOL       WINAPI WakeAllConditionVariable(CONDITION_VARIABLE*);
BOOL       WINAPI SleepConditionVariableCS(CONDITION_VARIABLE*, CRITICAL_SECTION*, DWORD);
void       WINAPI GetSystemTimeAsFileTime(FILETIME*);
BOOL       WINAPI QueryPerformanceCounter(LARGE_INTEGER*);
BOOL       WINAPI QueryPerformanceFrequency(LARGE_INTEGER*);
ULONGLONG  WINAPI GetTickCount64(void);
HANDLE     WINAPI CreateThread(void*, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD);
DWORD      WINAPI WaitForSingleObject(HANDLE, DWORD);
BOOL       WINAPI CloseHandle(HANDLE);
HANDLE     WINAPI CreateEvent(void*, BOOL, BOOL, LPCSTR);
BOOL       WINAPI SetEvent(HANDLE);
DWORD      WINAPI TlsAlloc(void);
BOOL       WINAPI TlsFree(DWORD);
BOOL       WINAPI TlsSetValue(DWORD, LPVOID);
LPVOID     WINAPI TlsGetValue(DWORD);

/* Real MinGW declares these in <malloc.h> (pulled in by the CRT headers);
 * glibc does not — declare here so the fake-host syntax check matches. */
void*      _aligned_malloc(size_t size, size_t alignment);
void       _aligned_free(void* p);

/* winnt.h intrinsics + kernel32 extras used by threads.c / native.c */
typedef long long      LONG64;
typedef unsigned long long ULONG64;
typedef int            errno_t;
void       WINAPI YieldProcessor(void);
LONG64     WINAPI InterlockedCompareExchange64(volatile LONG64*, LONG64, LONG64);
LPVOID     WINAPI InterlockedCompareExchangePointer(LPVOID volatile*, LPVOID, LPVOID);
LONG       WINAPI InterlockedAdd(volatile LONG*, LONG);
DWORD      WINAPI GetTickCount(void);
errno_t    localtime_s(struct tm*, const time_t*);
errno_t    gmtime_s(struct tm*, const time_t*);

/* MinGW <string.h> declares the CRT _strdup (opcodes.c maps strdup to it) */
char*      _strdup(const char*);

/* rms.c uses Win32 one-time init + CRT _commit (real MinGW: winbase.h/io.h) */
typedef void* PVOID;
typedef struct _INIT_ONCE { PVOID Ptr; } INIT_ONCE, *PINIT_ONCE;
#define INIT_ONCE_STATIC_INIT { 0 }
#define CALLBACK
BOOL WINAPI InitOnceExecuteOnce(PINIT_ONCE, BOOL (WINAPI*)(PINIT_ONCE, PVOID, PVOID*), PVOID, PVOID*);
int  _commit(int fd);
FILE* _wfopen(const wchar_t*, const wchar_t*);
int  _fileno(FILE*);

/* rms.c directory scan (real MinGW: fileapi.h via windows.h) */
typedef char CHAR;
typedef struct _WIN32_FIND_DATAA {
    DWORD    dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD    nFileSizeHigh;
    DWORD    nFileSizeLow;
    DWORD    dwReserved0;
    DWORD    dwReserved1;
    CHAR     cFileName[MAX_PATH];
    CHAR     cAlternateFileName[14];
} WIN32_FIND_DATAA, *LPWIN32_FIND_DATAA;
#define INVALID_HANDLE_VALUE ((HANDLE)(~(size_t)0))
HANDLE WINAPI FindFirstFileA(const char*, LPWIN32_FIND_DATAA);
BOOL  WINAPI FindNextFileA(HANDLE, LPWIN32_FIND_DATAA);
BOOL  WINAPI FindClose(HANDLE);

#endif /* FAKE_WINDOWS_H_STUB */
