#!/bin/bash
# Syntax-check every libretro-target file with the user's Windows flags
# against the win_syntax stubs (catches unknown types/implicit decls in
# _WIN32 branches without a mingw cross-compiler).
cd "$(dirname "$0")/../.."
FLAGS="-Wall -Wextra -std=c11 -Iinclude -Isrc -Isrc/include -DLIBRETRO -DWIN32 -D_WIN32 -D_GNU_SOURCE -DJ2ME_DEBUG=0 -MMD -MP -D__USE_MINGW_ANSI_STDIO=1"
STUB="-Iscripts/win_syntax -include scripts/win_syntax/windows.h -include scripts/win_syntax/direct.h"
fail=0
for f in src/jvm/*.c src/midp/*.c src/libretro/*.c src/midi/*.c src/utils/*.c; do
  if ! gcc $FLAGS $STUB -fsyntax-only "$f" 2>/tmp/winsyn_err.txt; then
    echo "FAIL: $f"; head -5 /tmp/winsyn_err.txt; fail=1
  fi
done
[ $fail -eq 0 ] && echo "ALL WIN32 SYNTAX CHECKS PASSED"
exit $fail
