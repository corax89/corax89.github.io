#!/bin/bash
# v34.12: link-level audit of the libretro (WIN32) build WITHOUT a mingw
# cross-compiler. Compiles every libretro-target source to a real object
# with the user's Windows flags + win_syntax stubs, then checks that every
# undefined symbol in every object is either defined by another project
# object or belongs to the libc/WinAPI allowlist. Catches missing
# platform-twin definitions (e.g. jvm_dump_all_threads) in one pass.
cd "$(dirname "$0")/.." || exit 1
OUT=scripts/win_syntax/audit_obj
rm -rf "$OUT" && mkdir -p "$OUT"
FLAGS="-std=c11 -Iinclude -Isrc -Isrc/include -DLIBRETRO -DWIN32 -D_WIN32 -D_GNU_SOURCE -DJ2ME_DEBUG=0 -D__USE_MINGW_ANSI_STDIO=1 -O1 -w"
STUB="-Iscripts/win_syntax -include scripts/win_syntax/windows.h -include scripts/win_syntax/direct.h"

files=$(ls src/jvm/*.c src/midp/*.c src/libretro/*.c src/midi/*.c src/utils/*.c 2>/dev/null)
for f in $files; do
  o="$OUT/$(basename "${f%.c}").o"
  if ! gcc $FLAGS $STUB -c "$f" -o "$o" 2>"$OUT/$(basename "${f%.c}").err"; then
    echo "COMPILE FAIL: $f"; head -8 "$OUT/$(basename "${f%.c}").err"; exit 1
  fi
done

# Defined symbols (T=text, D=data, B=bss, R=rodata, W=weak)
nm --defined-only "$OUT"/*.o 2>/dev/null | awk '{print $NF}' | sort -u > "$OUT/.defined"
# Undefined symbols
nm --undefined-only "$OUT"/*.o 2>/dev/null | awk '{print $NF}' | sort -u > "$OUT/.undefined"

# Explicit allowlist: symbols resolved by the user's MSYS2 MinGW32 toolchain
# from system libs (winpthreads / msvcrt / libmingwex / kernel32), confirmed
# by the user's real `make -j6` run reaching the DLL link stage.
cat > "$OUT/.allowlist" <<'EOF'
CloseHandle
CreateEvent
CreateThread
DeleteCriticalSection
EnterCriticalSection
FindClose
FindFirstFileA
FindNextFileA
GetCurrentThread
GetCurrentThreadId
GetSystemTimeAsFileTime
GetTickCount
GetTickCount64
InitOnceExecuteOnce
InitializeConditionVariable
InitializeCriticalSection
InterlockedAdd
InterlockedCompareExchange
InterlockedCompareExchange64
InterlockedCompareExchangePointer
InterlockedDecrement
InterlockedExchange
InterlockedIncrement
LeaveCriticalSection
MemoryBarrier
MultiByteToWideChar
QueryPerformanceCounter
QueryPerformanceFrequency
SetEvent
Sleep
SleepConditionVariableCS
SwitchToThread
TlsAlloc
TlsFree
TlsGetValue
TlsSetValue
TryEnterCriticalSection
WaitForSingleObject
WakeAllConditionVariable
WakeByAddressAll
WakeByAddressSingle
WaitOnAddress
RtlUnwind
Snprintf
snprintf
sqrt
sqrtf
srand
usleep
utime
_fstat64
_alloca
__i686.get_pc_thunk.bx
pthread_mutex_init
pthread_mutex_lock
pthread_mutex_trylock
pthread_mutex_unlock
pthread_mutexattr_destroy
pthread_mutexattr_init
pthread_mutexattr_settype
pthread_once
pthread_self
pthread_create
pthread_join
pthread_detach
pthread_cond_init
pthread_cond_wait
pthread_cond_timedwait
pthread_cond_signal
pthread_cond_broadcast
pthread_cond_destroy
pthread_equal
pthread_exit
memset
memcpy
memmove
memcmp
malloc
calloc
realloc
free
strlen
strcmp
strncmp
strcpy
strncpy
strcat
strncat
strchr
strrchr
strstr
strdup
strerror
strtod
strtol
strtoul
abs
labs
llabs
exit
abort
qsort
bsearch
time
clock
fopen
fclose
fread
fwrite
fseek
ftell
feof
ferror
fflush
fprintf
fputs
fputc
fgetc
fgets
fputs
fseeko64
ftello64
remove
rename
sscanf
fscanf
vsnprintf
vfprintf
vprintf
printf
puts
putchar
getchar
sprintf
atoi
atol
atof
toupper
tolower
isdigit
isspace
isalpha
isalnum
ispunct
iscntrl
isprint
isxdigit
isupper
islower
pow
fmod
sin
cos
tan
asin
acos
atan
atan2
floor
ceil
log
log2
log10
exp
exp2
ldexp
frexp
modff
modf
round
trunc
fabs
fabsf
nan
nanf
inf
INFINITY
NAN
WakeConditionVariable
WideCharToMultiByte
YieldProcessor
_aligned_free
_aligned_malloc
_commit
_fileno
_mkdir
_strdup
_wfopen
acosf
atanf
cbrt
clock_gettime
cosf
exp2f
expf
fminf
fmodf
fopen64
freopen64
getenv
gettimeofday
gmtime_s
hypot
localtime
localtime_s
log2f
mktime
nanosleep
powf
pthread_mutex_destroy
sincos
sincosf
sinf
stat64
stderr
stdout
strcasecmp
strftime
strtof
strtok
tanf
timezone
ungetc
_GLOBAL_OFFSET_TABLE_
__assert_fail
__ctype_b_loc
__ctype_tolower_loc
__isoc23_sscanf
__isoc23_strtol
__isoc23_strtoull
EOF

missing=0
while read -r sym; do
  [ -z "$sym" ] && continue
  grep -qx "$sym" "$OUT/.defined" && continue
  grep -qx "$sym" "$OUT/.allowlist" && continue
  echo "UNRESOLVED: $sym"; missing=1
done < "$OUT/.undefined"

if [ $missing -eq 0 ]; then
  echo "ALL SYMBOLS RESOLVED (project-internal)"
else
  echo "^^^ these need definitions or allowlisting"
fi
exit $missing
