#!/bin/bash
# v36.29 E2E: [FONT-HEIGHT] + [FONT-2X] + [FORM-SCROLL] (TestFont.jar).
#
#  RUN A (канва, без GAME_KEYS): midlet сам измеряет пиксели через
#    Image.getRGB и печатает факты "[FF] ...":
#      fh=9        - Font.getHeight() = глиф 7px + 2px leading (раньше 7);
#      fhL=18      - LARGE = 2x метрики;
#      cw=5 cwL=10 - charWidth 2x;
#      sw=17 swL=34- stringWidth 2x (3*(5+1)-1 / 3*12-2);
#      gap=ok      - две строки через РОВНО getHeight() оставляют пустые
#                    строки между собой (при старом 7 соприкасались);
#      inkL=14     - LARGE 'H' рисуется 2x7=14 рядов чернил (2x рендер);
#      inkM=7      - MEDIUM не изменился (7 рядов).
#
#  RUN B1 (форма, без прокрутки): длинный StringItem (TOPMARK + 36 абзацев)
#    + Spacer(60) + ENDMARKER. Фокус self-heal встаёт на последний
#    НЕинтерактивный item — старый код прыгал в ХВОСТ текста. Проверки:
#      - ни одной строки "[FORM] scroll" (нет самопроизвольной прокрутки);
#      - в дампе канвы полоса y25..32 плотная (вид = ВЕРХ документа).
#
#  RUN B2 (форма, 20x DOWN): "[FORM] scroll 0 -> 33" и далее по шагам до
#    клампа; в последнем дампе: полоса Spacer'а пуста, ENDMARKER виден.
#
#  RUN C (форма, 6x DOWN + 8x UP): скролл возвращается в 0 (последняя
#    строка "-> 0"), вид снова = верх документа.
set -e
cd "$(dirname "$0")/.." || exit 1

run_session() {  # $1=dir $2=SWITCH_KEYS $3=FRONT_KEYS $4=GAME_KEYS $5=timeout $6=dumpdir
    rm -rf "$1"; mkdir -p "$1/roms" "$1/xdg"
    [ -n "$6" ] && mkdir -p "$6"
    cp scripts/fontjar/TestFont.jar "$1/roms/"
    cat > "$1/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF
    [ -n "$6" ] && export NOJME_GAME_DUMP_DIR="$6" || unset NOJME_GAME_DUMP_DIR
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    NOJME_LOG=1 NOJME_LOGGING=1 \
    NOJME_SWITCH_BROWSE_ROOT="$1/roms" NOJME_SWITCH_UI_DIR="$1" \
    XDG_DATA_HOME="$1/xdg" \
    NOJME_SWITCH_KEYS="$2" NOJME_FRONT_KEYS="$3" NOJME_GAME_KEYS="$4" \
    timeout -k 5 "$5" ./bin/switchui-verify > "$1/out.log" 2> "$1/err.log" || true
}

ok=1
fail() { echo "FAIL: $1"; ok=0; }
ALL_LOGS() { cat "$1/err.log" "$1/out.log" 2>/dev/null; }

echo "=== RUN A: canvas font metrics ==="
run_session /tmp/ff_a "A:1200,A:500,EXIT:10000" "MINUS:8000,DOWN:400,DOWN:400,A:900" "" 30 ""
A=$(ALL_LOGS /tmp/ff_a)
echo "$A" | grep -aq "FF] start"            || fail "A: TestFont не запустился"
echo "$A" | grep -aq "FF] fh=9"             || fail "A: getHeight() != 9 (leading не добавлен)"
echo "$A" | grep -aq "FF] fhL=18"           || fail "A: LARGE getHeight() != 18"
echo "$A" | grep -aq "FF] cw=5 cwL=10"      || fail "A: charWidth LARGE не 2x"
echo "$A" | grep -aq "FF] sw=17 swL=34"     || fail "A: stringWidth LARGE не 2x"
echo "$A" | grep -aq "FF] gap=ok"           || fail "A: строки через getHeight() соприкасаются (gap)"
echo "$A" | grep -aq "FF] inkL=14"          || fail "A: LARGE глиф не 2x (inkL != 14)"
echo "$A" | grep -aq "FF] inkM=7"           || fail "A: MEDIUM глиф изменился (inkM != 7)"
echo "$A" | grep -aq "session complete"     || fail "A: нет чистого выхода"

echo "=== RUN B1: форма без прокрутки — вид = верх документа ==="
run_session /tmp/ff_b1 "A:1200,A:500,EXIT:16000" "MINUS:13000,DOWN:400,DOWN:400,A:900" \
    "-5:800,-8:5000" 35 /tmp/ff_b1/dump
B1=$(ALL_LOGS /tmp/ff_b1)
echo "$B1" | grep -aq "FF] form=shown"      || fail "B1: форма не открылась"
if echo "$B1" | grep -aq "FORM] scroll"; then fail "B1: самопроизвольная прокрутка формы"; fi
python3 "$(dirname "$0")/fontform_bandcheck.py" /tmp/ff_b1/dump top >/dev/null \
    || fail "B1: начальный вид не верх документа (полоса y25..32 неплотная)"

echo "=== RUN B2: 20x DOWN — прокрутка до дна ==="
DOWN20=""; for i in $(seq 1 20); do DOWN20="$DOWN20-2:400,"; done
run_session /tmp/ff_b2 "A:1200,A:500,EXIT:20000" "MINUS:17500,DOWN:400,DOWN:400,A:900" \
    "-5:800,-8:1500,${DOWN20}-8:3500" 40 /tmp/ff_b2/dump
B2=$(ALL_LOGS /tmp/ff_b2)
echo "$B2" | grep -aq "FF] form=shown"      || fail "B2: форма не открылась"
echo "$B2" | grep -aq "FORM] scroll 0 -> 33" || fail "B2: первый шаг прокрутки не 0 -> 33"
SCROLLS=$(echo "$B2" | grep -a "FORM] scroll" | wc -l)
[ "$SCROLLS" -ge 15 ] || fail "B2: мало шагов прокрутки ($SCROLLS < 15)"
python3 "$(dirname "$0")/fontform_bandcheck.py" /tmp/ff_b2/dump bottom >/dev/null \
    || fail "B2: нижний вид не достигнут (Spacer/ENDMARKER не видны)"

echo "=== RUN C: 6x DOWN + 8x UP — возврат в 0 ==="
DOWN6="";  for i in $(seq 1 6);  do DOWN6="$DOWN6-2:400,";  done
UP8="";    for i in $(seq 1 8);  do UP8="$UP8-1:400,";      done
run_session /tmp/ff_c "A:1200,A:500,EXIT:20000" "MINUS:17000,DOWN:400,DOWN:400,A:900" \
    "-5:800,-8:1000,${DOWN6}${UP8}-8:2500" 40 /tmp/ff_c/dump
C=$(ALL_LOGS /tmp/ff_c)
echo "$C" | grep -aq "FF] form=shown"       || fail "C: форма не открылась"
LASTS=$(echo "$C" | grep -a "FORM] scroll" | tail -1)
echo "$LASTS" | grep -aq -- "-> 0 " || fail "C: прокрутка не вернулась в 0 (последняя: $LASTS)"
python3 "$(dirname "$0")/fontform_bandcheck.py" /tmp/ff_c/dump top >/dev/null \
    || fail "C: после DOWN+UP вид не вернулся к верху документа"

# крашей в логах быть не должно
for D in /tmp/ff_a /tmp/ff_b1 /tmp/ff_b2 /tmp/ff_c; do
    ALL_LOGS "$D" | grep -ahqi "segfault\|SIGSEGV" && fail "$D: краш"
done

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
