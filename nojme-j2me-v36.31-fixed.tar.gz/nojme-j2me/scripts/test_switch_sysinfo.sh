#!/bin/bash
# v36.30 E2E: user report on "Sys Info (MH)(1.1.0)":
#   1) скролл появился (v36.29 FORM-SCROLL работает), НО
#   2) «не работают софтовые левая и правая кнопки»,
#   3) «при выходе происходит вылет» (Atmosphère crash report: Data Abort
#      NULL deref в nojme_switch, стек = VM -> native -> high-region цепочка).
#
# TestSysInfo.jar (scripts/sysinfojar) мимикрит класс info-мидлетов:
# Form из 60 строк свойств (длинный текст -> скролл), 3 команды
# (Exit/Refresh/Copy), destroyApp пишет RMS. Три сессии:
#   A) ТАЧ: тап по левой софт-кнопке («Menu») -> командное меню -> Exit
#      -> commandAction -> destroyApp -> RMS -> notifyDestroyed (чистый выход).
#   B) ЖЕЛЕЗО: X (левый софт) открывает меню, B (правый софт) = Select
#      -> Exit; до этого DOWN-скролл формы ([FORM] scroll в логе).
#   C) ВЫЛЕТ-РЕПРО: выход через меню паузы (MINUS,DOWN,DOWN,A) — destroyApp
#      исполняется на frame-потоке. Ожидаем ЧИСТЫЙ выход, не краш.
set -u
cd "$(dirname "$0")/.." || exit 1

run_session() {
    local tag="$1" script_front="$2" keys_menu="$3" jar="${4:-TestSysInfo.jar}"
    local D=/tmp/sw_sysinfo_$tag
    rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
    cp "scripts/sysinfojar/$jar" "$D/roms/"

    cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
    export NOJME_SWITCH_UI_DIR="$D"
    export XDG_DATA_HOME="$D/xdg"
    export NOJME_SWITCH_KEYS="$keys_menu"
    export NOJME_FRONT_KEYS="$script_front"

    timeout -k 5 40 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
    local rc=$?
    echo "== session $tag exit code: $rc (0 clean; 124 timeout; 139 SEGV = CRASH REPRO)"
    echo "$rc" > "$D/rc"
    return 0
}

ok=1
WANT="${SESSIONS:-A B C D E F}"
run_if() { case " $WANT " in *" $1 "*) return 0;; *) return 1;; esac; }

# ---------- Session A: touch softbar + command menu + Exit ----------
# Канва 240x320 -> game rect (370,0,540,720), k=2.25.
# Левая софт-кнопка: канва (40,308) -> экран (460,693).
# Командное меню: menu_y=(320-70)/2=125, item0 = 130..150 -> (640,315).
if run_if A; then
run_if A && run_session A "TAP:460,693:4000,TAP:640,315:600" "A:1200,A:500,EXIT:5000"
DA=/tmp/sw_sysinfo_A
ALL_A="$DA/log.txt $DA/err.log $DA/out.log"
grep -ahq "SI] startApp" $ALL_A || { echo "FAIL[A]: TestSysInfo не запустился"; ok=0; }
grep -ahq "SI] filled items=64" $ALL_A || { echo "FAIL[A]: форма не заполнена (62 items)"; ok=0; }
grep -ahq "SI] cmd=Exit on Sys Info" $ALL_A || { echo "FAIL[A]: тап по софт-кнопке -> меню -> Exit не сработал"; ok=0; }
grep -ahq "SI] destroyApp u=true begin" $ALL_A || { echo "FAIL[A]: destroyApp не начался"; ok=0; }
grep -ahq "SI] rms saved" $ALL_A || { echo "FAIL[A]: RMS не сохранился в destroyApp"; ok=0; }
grep -ahq "SI] destroyApp end" $ALL_A || { echo "FAIL[A]: destroyApp не завершился"; ok=0; }
grep -ahq "session complete" $ALL_A || { echo "FAIL[A]: нет возврата в меню после Exit"; ok=0; }
fi

# ---------- Session B: hardware soft keys (FORM commands) + scroll ----------
# DOWN x3: фокус item0 (ExitItem) -> multiItem -> исчерпан -> [FORM] scroll.
# X (левый софт) открывает FORM-командное меню, B (правый софт) = Select -> Exit.
if run_if B; then
run_if B && run_session B "DOWN:4000,DOWN:400,DOWN:400,X:600,B:600" "A:1200,A:500,EXIT:5000"
DB=/tmp/sw_sysinfo_B
ALL_B="$DB/log.txt $DB/err.log $DB/out.log"
grep -ahq "SI] startApp" $ALL_B || { echo "FAIL[B]: не запустился"; ok=0; }
grep -ahq "FORM] scroll" $ALL_B || { echo "FAIL[B]: DOWN не проскроллил форму ([FORM] scroll нет)"; ok=0; }
grep -ahq "SI] cmd=Exit on Sys Info" $ALL_B || { echo "FAIL[B]: X->меню, B->Select не выполнил Exit (софт-кнопки не работают!)"; ok=0; }
grep -ahq "SI] rms saved" $ALL_B || { echo "FAIL[B]: RMS не сохранился"; ok=0; }
grep -ahq "session complete" $ALL_B || { echo "FAIL[B]: нет возврата в меню"; ok=0; }
fi

# ---------- Session C: exit via PAUSE MENU (crash repro) ----------
# MINUS -> пауза; DOWN,DOWN -> «Выйти»; A. destroyApp на frame-потоке.
# FRONT_KEYS: скролл вниз x3, потом MINUS,DOWN,DOWN,A.
if run_if C; then
run_if C && run_session C "DOWN:3500,DOWN:300,DOWN:300,MINUS:800,DOWN:400,DOWN:400,A:600" "A:1200,A:500,EXIT:5000"
DC=/tmp/sw_sysinfo_C
ALL_C="$DC/log.txt $DC/err.log $DC/out.log"
RCC=$(cat "$DC/rc" 2>/dev/null || echo "?")
if [ "$RCC" != "0" ]; then echo "FAIL[C]: rc=$RCC — вылет/таймаут при выходе через меню паузы"; ok=0; fi
grep -ahq "pause menu -> exit game" $ALL_C || { echo "FAIL[C]: выход из паузы не сработал"; ok=0; }
grep -ahq "SI] destroyApp u=true begin" $ALL_C || { echo "FAIL[C]: destroyApp не вызван"; ok=0; }
grep -ahq "SI] rms saved" $ALL_C || { echo "FAIL[C]: RMS не сохранился в destroyApp (пауза-выход)"; ok=0; }
grep -ahq "SI] destroyApp end" $ALL_C || { echo "FAIL[C]: destroyApp не завершился (пауза-выход)"; ok=0; }
grep -ahq "session complete" $ALL_C || { echo "FAIL[C]: нет возврата в меню"; ok=0; }
if grep -ahq "Segmentation fault\|SIGSEGV\|Data Abort" $ALL_C; then echo "FAIL[C]: краш-паттерн в логе"; ok=0; fi
fi

# ---------- Session D: touch on an ITEM command (StringItem button) ----------
# ExitItem — первый item формы (виден сразу). Канва (120,33) -> экран (640,74).
# Тап по item с 1-2 item-командами = fire default -> Exit -> destroyApp.
if run_if D; then
run_if D && run_session D "TAP:640,74:4000" "A:1200,A:500,EXIT:5000" TestSysInfoItems.jar
DD=/tmp/sw_sysinfo_D
ALL_D="$DD/log.txt $DD/err.log $DD/out.log"
RDD=$(cat "$DD/rc" 2>/dev/null || echo "?")
grep -ahq "SII] itemcmd=Exit on ExitItem" $ALL_D || { echo "FAIL[D]: тап по item-кнопке не вызвал itemcmd=Exit"; ok=0; }
grep -ahq "SII] rms saved" $ALL_D || { echo "FAIL[D]: RMS не сохранился"; ok=0; }
if [ "$RDD" != "0" ]; then echo "FAIL[D]: rc=$RDD — нечистый выход"; ok=0; fi
grep -ahq "session complete" $ALL_D || { echo "FAIL[D]: нет возврата в меню"; ok=0; }
fi

# ---------- Session E: hardware soft keys + item command menu ----------
# Фокус стартует на item 0 (ExitItem, 1 команда). DOWN -> multiItem (3 команды).
# X (левый софт) -> item-командное меню; B (правый софт) = Select -> ItemRefresh.
# Затем пауза -> Выйти (fence-стресс с открытым состоянием item-команд).
if run_if E; then
run_if E && run_session E "DOWN:4000,X:600,B:600,MINUS:1200,DOWN:400,DOWN:400,A:600" "A:1200,A:500,EXIT:5000" TestSysInfoItems.jar
DE=/tmp/sw_sysinfo_E
ALL_E="$DE/log.txt $DE/err.log $DE/out.log"
RCE=$(cat "$DE/rc" 2>/dev/null || echo "?")
grep -ahq "ITEMCMD] menu open (3 commands)" $ALL_E || { echo "FAIL[E]: X не открыл item-командное меню"; ok=0; }
grep -ahq "SII] itemcmd=ItemRefresh on MultiItem" $ALL_E || { echo "FAIL[E]: B не выбрал ItemRefresh в меню"; ok=0; }
grep -ahq "ITEMCMD] fire" $ALL_E || { echo "FAIL[E]: item-команда не выстрелила"; ok=0; }
grep -ahq "pause menu -> exit game" $ALL_E || { echo "FAIL[E]: выход из паузы не сработал"; ok=0; }
grep -ahq "SII] rms saved" $ALL_E || { echo "FAIL[E]: RMS не сохранился (пауза-выход после item-команд)"; ok=0; }
if [ "$RCE" != "0" ]; then echo "FAIL[E]: rc=$RCE — вылет/таймаут"; ok=0; fi
grep -ahq "session complete" $ALL_E || { echo "FAIL[E]: нет возврата в меню"; ok=0; }
fi

# ---------- Session F: hardware X fires item command directly ----------
# Фокус на item 0 (ExitItem, 1 команда): X = левый софт -> fire Exit.
if run_if F; then
run_if F && run_session F "X:4000" "A:1200,A:500,EXIT:5000" TestSysInfoItems.jar
DF=/tmp/sw_sysinfo_F
ALL_F="$DF/log.txt $DF/err.log $DF/out.log"
grep -ahq "SII] itemcmd=Exit on ExitItem" $ALL_F || { echo "FAIL[F]: X не выстрелил item-команду Exit (софт-кнопки мертвы?)"; ok=0; }
grep -ahq "session complete" $ALL_F || { echo "FAIL[F]: нет возврата в меню"; ok=0; }
fi

# ---------- Session G: tap on the softbar zone of an item-command form ----------
# Form БЕЗ form-команд, фокус на item0 (ExitItem): софтбар рисуется
# (метки item-команд). Тап левая треть канвы (40,308) -> экран (460,693).
if run_if G; then
run_session G "TAP:460,693:4000" "A:1200,A:500,EXIT:5000" TestSysInfoItems.jar
DG=/tmp/sw_sysinfo_G
ALL_G="$DG/log.txt $DG/err.log $DG/out.log"
RDG=$(cat "$DG/rc" 2>/dev/null || echo "?")
grep -ahq "SII] itemcmd=Exit on ExitItem" $ALL_G || { echo "FAIL[G]: тап по софтбару (item-команды) не сработал"; ok=0; }
if [ "$RDG" != "0" ]; then echo "FAIL[G]: rc=$RDG"; ok=0; fi
grep -ahq "session complete" $ALL_G || { echo "FAIL[G]: нет возврата в меню"; ok=0; }
fi

echo
if [ "$ok" = "1" ]; then echo "ALL PASSED"; else echo "FAILED"; exit 1; fi
