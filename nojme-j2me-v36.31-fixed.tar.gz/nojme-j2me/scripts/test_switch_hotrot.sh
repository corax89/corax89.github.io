#!/bin/bash
# v36.27 [HOT-ROTATION] E2E (отчёт: «переворот экрана применяется не тут же,
# а только после перезагрузки мидлета»).
#
# Сценарий (TestKeys.jar, ОДНА игровая сессия):
#   1. MINUS -> «Настройки игры» -> строка «Поворот экрана» (row 6) ->
#      A (off -> right)  => в логе "[SWITCH] hot rotation: off -> right"
#      ПРИ ЖИВОЙ СЕССИИ (перезапуска НЕТ).
#   2. B, B (продолжить) -> стрелки: при rot=1 (90 вправо) remap:
#      UP->LEFT(-3), DOWN->RIGHT(-4), LEFT->DOWN(-2), RIGHT->UP(-1).
#   3. Снова пауза -> настройки -> A (right -> left) -> B, B ->
#      UP обязано дать canvas RIGHT (-4).
#   4. Пауза -> Выйти -> чистый возврат в меню.
#
# Проверки: два hot-apply, НОЛЬ перезапусков ([JK] start ровно один),
# порядок pressed: -3,-4,-2,-1,-4, нет SURFACE-RECREATE, чистый выход.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_hotrot
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp "games/TestKeys.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
# меню: Открыть -> браузер -> первый jar
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_EXIT_MS=24000
# задержки ОТНОСИТЕЛЬНЫЕ (каждый токен — от предыдущего)
export NOJME_FRONT_KEYS="MINUS:5000,DOWN:400,A:400,DOWN:250,DOWN:250,DOWN:250,DOWN:250,DOWN:250,DOWN:250,A:400,B:400,B:400,UP:500,DOWN:400,LEFT:400,RIGHT:400,MINUS:600,DOWN:300,A:300,DOWN:250,DOWN:250,DOWN:250,DOWN:250,DOWN:250,DOWN:250,A:400,B:400,B:400,UP:500,MINUS:600,DOWN:300,DOWN:300,A:500"

timeout -k 5 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1
ALL="$D/log.txt $D/err.log $D/out.log"

grep -ahq "JK] start" $ALL || { echo "FAIL: TestKeys.jar не стартовал"; ok=0; }

# горячее применение оба раза
grep -ahq "hot rotation: off -> right" $ALL || { echo "FAIL: нет hot apply off->right"; ok=0; }
grep -ahq "hot rotation: right -> left" $ALL || { echo "FAIL: нет hot apply right->left"; ok=0; }

# перезапуска мидлета НЕТ: [JK] start ровно один раз
n_start=$(grep -ahc "JK] start" $ALL | awk '{s+=$1} END{print s+0}')
[ "$n_start" = "1" ] || { echo "FAIL: [JK] start встречается $n_start раз (мидлет перезапускался?)"; ok=0; }

# сессия не пересоздавалась
grep -ahq "SURFACE-RECREATE" $ALL && { echo "FAIL: SURFACE-RECREATE — сессия пересоздавалась"; ok=0; }

# remap стрелок: порядок pressed: -3,-4,-2,-1 (rot=1), затем -4 (rot=2, UP)
seq=$(grep -ah "JK] pressed" $ALL | sed 's/.*pressed \(-[0-9]*\).*/\1/' | tr '\n' ' ')
echo "pressed sequence: $seq"
[ "$seq" = "-3 -4 -2 -1 -4 " ] || { echo "FAIL: порядок remap не -3,-4,-2,-1,-4"; ok=0; }

# сессия завершена и вернулись в меню
grep -ahq "pause menu -> exit game" $ALL || { echo "FAIL: выход через меню паузы не случился"; ok=0; }
grep -ahq "session complete" $ALL || { echo "FAIL: сессия не завершилась чисто"; ok=0; }
grep -ahqi "segfault\|SIGSEGV" $ALL && { echo "FAIL: краш"; ok=0; }

[ "$ok" = "1" ] && echo "HOT ROTATION: ALL CHECKS PASSED" || { echo "HOT ROTATION: FAILED"; exit 1; }
