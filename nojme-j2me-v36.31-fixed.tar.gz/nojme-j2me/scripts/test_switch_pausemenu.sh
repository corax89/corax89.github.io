#!/bin/bash
# v36.19 автотест: ЕДИНОЕ меню паузы на кнопках + и -.
# Сценарий (sandbox, AsiaRally3D):
#   меню: A,A -> запуск игры
#   в игре: PLUS:8000 (открывает МЕНЮ ПАУЗЫ — раньше PLUS сразу открывал
#           настройки) -> DOWN:600 (курсор на «Настройки игры») ->
#           A:800 (pgset-экран ВНУТРИ паузы, VM остаётся запаркована) ->
#           B:800 (закрыть настройки -> НАЗАД В МЕНЮ ПАУЗЫ) ->
#           B:800 (пункт «Продолжить»... точнее B = продолжить) ->
#           MINUS:1500 (снова меню паузы — теперь минусом) ->
#           DOWN,DOWN,A (курсор на «Выйти» -> выход в меню)
# Проверки:
#   - PLUS и MINUS оба открывают меню паузы (pause: open x2)
#   - «Настройки игры» открывается и закрывается ВНУТРИ паузы
#     (pause: pgset, pgset: open/close; между ними НЕТ pause: close)
#   - КЛЮЧЕВОЕ (контракт вложенности v36.19): FE-PAUSE begin/end ровно по
#     паре на открытие/закрытие меню паузы — экран настроек НЕ добавляет
#     своей пары (раньше добавлял: скобки не вложимы)
#   - выход через пункт «Выйти» (pause menu -> exit game), чистая сессия
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_pausemenu
rm -rf "$D"; mkdir -p "$D/roms"
cp "games/AsiaRally3D.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:60000"
export NOJME_FRONT_KEYS="PLUS:8000,DOWN:600,A:800,B:800,B:800,MINUS:1500,DOWN:400,DOWN:400,A:900"

timeout -k 5 80 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
# меню паузы открывалось ДВАЖДЫ (PLUS и MINUS) и закрывалось дважды
# (grep с якорем «^<tick> pause:» — heartbeat «alive: pause: open» не считать)
OPENS=$(grep -acE "^[0-9]+ pause: open" "$D/log.txt" 2>/dev/null || true)
CLOSES=$(grep -acE "^[0-9]+ pause: close" "$D/log.txt" 2>/dev/null || true)
[ "${OPENS:-0}" -eq 2 ] || { echo "FAIL: pause: open = $OPENS (want 2: PLUS и MINUS)"; ok=0; }
[ "${CLOSES:-0}" -eq 2 ] || { echo "FAIL: pause: close = $CLOSES (want 2)"; ok=0; }

# «Настройки игры» открылись ВНУТРИ паузы: между pause: open (#1) и
# pause: close (#1) сидят pause: pgset + pgset: open + pgset: close
grep -aq "pause: pgset" "$D/log.txt" || { echo "FAIL: нет trace pause: pgset"; ok=0; }
grep -aq "pgset: open" "$D/log.txt" || { echo "FAIL: pgset-экран не открывался"; ok=0; }
grep -aq "pgset: close" "$D/log.txt" || { echo "FAIL: pgset-экран не закрылся"; ok=0; }
L_PO1=$(grep -anE "^[0-9]+:?[0-9 ]*pause: open"  "$D/log.txt" | head -1 | cut -d: -f1)
L_PC1=$(grep -anE "^[0-9]+:?[0-9 ]*pause: close" "$D/log.txt" | head -1 | cut -d: -f1)
L_PG=$(grep -anE "^[0-9]+:?[0-9 ]*pause: pgset"  "$D/log.txt" | head -1 | cut -d: -f1)
if [ -n "$L_PO1" ] && [ -n "$L_PC1" ] && [ -n "$L_PG" ]; then
    [ "$L_PO1" -lt "$L_PG" ] && [ "$L_PG" -lt "$L_PC1" ] || {
        echo "FAIL: pgset открыт НЕ внутри первой паузы ($L_PO1 < $L_PG < $L_PC1)"; ok=0; }
else
    echo "FAIL: не хватает маркеров паузы/pgset"; ok=0
fi

# КЛЮЧЕВОЕ: контракт вложенности — FE-PAUSE ровно 2 begin / 2 end
# (настройки игры не добавляют своей пары)
BEG=$(grep -ac "FE-PAUSE] begin" "$D/err.log" 2>/dev/null || true)
ENDS=$(grep -ac "FE-PAUSE] end"   "$D/err.log" 2>/dev/null || true)
[ "${BEG:-0}" -eq 2 ] || { echo "FAIL: FE-PAUSE begin = $BEG (want 2 — pgset не должен парковать сам)"; ok=0; }
[ "${ENDS:-0}" -eq 2 ] || { echo "FAIL: FE-PAUSE end = $ENDS (want 2)"; ok=0; }

# выход через пункт «Выйти», сессия завершилась чисто
grep -aq "pause menu -> exit game" "$D/err.log" || { echo "FAIL: нет выхода через «Выйти»"; ok=0; }
grep -aq "session complete — back to menu" "$D/err.log" || { echo "FAIL: сессия не завершилась чисто"; ok=0; }
grep -aqi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }
STUCK=$(grep -acE "^[0-9]+ STUCK:" "$D/log.txt" 2>/dev/null || true)
[ "${STUCK:-0}" -gt 0 ] && { echo "FAIL: STUCK в логе ($STUCK)"; ok=0; }

if [ "$ok" = 1 ]; then
    echo "SWITCH-PAUSEMENU E2E: ALL CHECKS PASSED"
else
    echo "--- log tail:"; tail -30 "$D/log.txt" 2>/dev/null
    echo "--- err tail:";  tail -20 "$D/err.log" 2>/dev/null
    exit 1
fi
