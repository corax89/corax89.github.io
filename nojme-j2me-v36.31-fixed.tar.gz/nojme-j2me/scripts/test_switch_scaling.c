/*
 * test_switch_scaling.c — unit tests for the pure Switch frontend math
 * (switch_scaling.c) + the embedded bitmap font (switch_font.c).
 * Builds on any host: gcc -I src -I include ...
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "switch/switch_scaling.h"
#include "switch/switch_common.h"
#include "switch/switch_font.h"

static int g_fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { g_fails++; printf("FAIL: " __VA_ARGS__); printf(" (%s:%d)\n", __FILE__, __LINE__); } \
} while (0)

static void test_game_rect(void) {
    int x, y, w, h;

    /* STRETCH: whole screen */
    switch_scaling_game_rect(NOJME_SCALE_STRETCH, 240, 320, 1280, 720, &x, &y, &w, &h);
    CHECK(x == 0 && y == 0 && w == 1280 && h == 720, "stretch fills screen, got %d,%d %dx%d", x, y, w, h);

    /* FIT 240x320 (3:4) on 1280x720 (16:9): height-limited -> 540x720 centered */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLACK, 240, 320, 1280, 720, &x, &y, &w, &h);
    CHECK(h == 720 && w == 540, "fit height-limited 540x720, got %dx%d", w, h);
    CHECK(x == (1280 - 540) / 2 && y == 0, "fit centered x=%d y=%d", x, y);
    double ar = (double)w / h, want = 240.0 / 320.0;
    CHECK(ar > want * 0.99 && ar < want * 1.01, "aspect preserved %.4f vs %.4f", ar, want);

    /* FIT wide canvas 320x240 -> width-limited 1280x960? no: 960 height fits */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLUR, 320, 240, 1280, 720, &x, &y, &w, &h);
    CHECK(w == 960 && h == 720, "fit width-limited 960x720, got %dx%d", w, h);
    CHECK(x == (1280 - 960) / 2 && y == 0, "fit wide centered");

    /* degenerate: 1x1 */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLACK, 1, 1, 1280, 720, &x, &y, &w, &h);
    CHECK(w >= 1 && h >= 1 && x >= 0 && y >= 0, "1x1 valid rect %d,%d %dx%d", x, y, w, h);

    /* extreme aspect 1000x10 */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLACK, 1000, 10, 1280, 720, &x, &y, &w, &h);
    CHECK(w <= 1280 && h <= 720, "extreme clamped %dx%d", w, h);
}

static void test_bg_size(void) {
    int bw, bh;
    switch_scaling_bg_size(240, 320, &bw, &bh);
    CHECK(bw == 30 && bh == 40, "bg 240x320 -> 30x40, got %dx%d", bw, bh);
    switch_scaling_bg_size(16, 16, &bw, &bh);
    CHECK(bw == 8 && bh == 8, "bg min 8x8, got %dx%d", bw, bh);
    switch_scaling_bg_size(3, 3, &bw, &bh);
    CHECK(bw == 3 && bh == 3, "bg tiny clamped to src, got %dx%d", bw, bh);
}

static void test_blur(void) {
    /* constant color stays constant through downsample + blur */
    enum { SW = 64, SH = 64, BW = 8, BH = 8 };
    uint32_t src[SW * SH], bg[BW * BH];
    for (int i = 0; i < SW * SH; i++) src[i] = 0xFF336699u;
    switch_scaling_blur_bg(src, SW, SH, bg, BW, BH, 3);
    for (int i = 0; i < BW * BH; i++) {
        CHECK(bg[i] == 0xFF336699u, "const frame -> const bg[%d]=0x%08X", i, bg[i]);
    }

    /* left half red / right half blue (split at ODD x so the boundary
     * is NOT aligned with the 8-wide box grid -> transition box mixes) */
    for (int y = 0; y < SH; y++)
        for (int x = 0; x < SW; x++)
            src[y * SW + x] = (x < 33) ? 0xFFFF0000u : 0xFF0000FFu;
    switch_scaling_blur_bg(src, SW, SH, bg, BW, BH, 0); /* downsample only */
    CHECK(((bg[0] >> 16) & 0xFF) == 0xFF && (bg[0] & 0xFF) == 0x00, "left edge pure red");
    CHECK((bg[BW - 1] & 0xFF) == 0xFF && ((bg[BW - 1] >> 16) & 0xFF) == 0x00, "right edge pure blue");
    /* transition column (covers x=32..39: 1 red + 7 blue): both channels present */
    {
        uint32_t mid = bg[4];
        int has_r = ((mid >> 16) & 0xFF) > 0, has_b = (mid & 0xFF) > 0;
        CHECK(has_r && has_b, "transition box mixes channels, got 0x%08X", mid);
    }
    /* alpha always opaque */
    for (int i = 0; i < BW * BH; i++)
        CHECK((bg[i] & 0xFF000000u) == 0xFF000000u, "alpha opaque");

    /* degenerate sizes must not crash */
    switch_scaling_blur_bg(src, SW, SH, bg, 1, 1, 2);
    switch_scaling_blur_bg(NULL, 0, 0, bg, BW, BH, 2);
    switch_scaling_blur_bg(src, SW, SH, NULL, BW, BH, 2);
    printf("PASS-CHECK degenerate blur no crash\n");
}

static void test_font(void) {
    CHECK(switch_font_w() == 8 && switch_font_h() == 16, "cell metrics 8x16");
    CHECK(switch_font_text_width("AB", 1) == 16, "width AB=16");
    CHECK(switch_font_text_width("Ёё", 2) == 32, "cyrillic width scale2=32");

    uint32_t cv[160 * 60];
    memset(cv, 0, sizeof(cv));
    int end = switch_font_draw_text(cv, 160, 60, 4, 4, "Привет, J2ME!", 0xFFFFFFFF, 0, 2);
    CHECK(end > 4, "draw advanced x=%d", end);
    int lit = 0;
    for (int i = 0; i < 160 * 60; i++) if (cv[i]) lit++;
    CHECK(lit > 100, "ink pixels > 100, got %d", lit);

    /* clipping: far off-canvas must not crash */
    switch_font_draw_text(cv, 160, 60, 10000, 10000, "X", 0xFFFFFFFF, 0, 2);
    printf("PASS-CHECK font clipping no crash\n");
}

/* ================= v36.14 Scale2x ================= */

static void scale2x_ref_pixel(const uint32_t* src, int w, int h, int x, int y,
                              uint32_t out[4]) {
    int ym = y > 0 ? y - 1 : 0, yp = y < h - 1 ? y + 1 : h - 1;
    int xm = x > 0 ? x - 1 : 0, xp = x < w - 1 ? x + 1 : w - 1;
    uint32_t B = src[(size_t)ym * w + x];
    uint32_t D = src[(size_t)y * w + xm];
    uint32_t E = src[(size_t)y * w + x];
    uint32_t F = src[(size_t)y * w + xp];
    uint32_t H = src[(size_t)yp * w + x];
    out[0] = out[1] = out[2] = out[3] = E;
    if (B != H && D != F) {
        if (D == B) out[0] = D;
        if (B == F) out[1] = F;
        if (D == H) out[2] = D;
        if (H == F) out[3] = H;
    }
}

static void test_scale2x(void) {
    /* 1) flat frame stays flat (37x23: odd sizes exercise the tail paths) */
    enum { W = 37, H = 23 };
    static uint32_t src[W * H];
    static uint32_t dst[2 * W * 2 * H];
    static uint32_t ref[2 * W * 2 * H];
    for (int i = 0; i < W * H; i++) src[i] = 0xFF336699u;
    switch_scaling_scale2x(src, W, H, dst);
    for (int i = 0; i < 4 * W * H; i++)
        CHECK(dst[i] == 0xFF336699u, "flat stays flat [%d]=0x%08X", i, dst[i]);

    /* 2) all-neighbors-different gradient: every 2x2 block is E itself */
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            src[y * W + x] = 0xFF000000u |
                (uint32_t)((y * 131 + x * 37 + 11) * 7 + 1);
    switch_scaling_scale2x(src, W, H, dst);
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            uint32_t u = src[y * W + x];
            CHECK(dst[(2 * y) * (2 * W) + 2 * x] == u,
                  "isolated E0 [%d,%d]", x, y);
            CHECK(dst[(2 * y) * (2 * W) + 2 * x + 1] == u,
                  "isolated E1 [%d,%d]", x, y);
            CHECK(dst[(2 * y + 1) * (2 * W) + 2 * x] == u,
                  "isolated E2 [%d,%d]", x, y);
            CHECK(dst[(2 * y + 1) * (2 * W) + 2 * x + 1] == u,
                  "isolated E3 [%d,%d]", x, y);
        }
    }

    /* 3) hard horizontal edge: top white / bottom black — no bleeding */
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            src[y * W + x] = (y < H / 2) ? 0xFFFFFFFFu : 0xFF000000u;
    switch_scaling_scale2x(src, W, H, dst);
    for (int y = 0; y < H; y++) {
        uint32_t want = (y < H / 2) ? 0xFFFFFFFFu : 0xFF000000u;
        for (int x = 0; x < W; x++)
            CHECK(dst[(2 * y) * (2 * W) + 2 * x] == want,
                  "h-edge row %d no bleed", y);
    }

    /* 4) public kernel == scalar reference on pseudorandom noise
     * (on aarch64 this is the real scalar-vs-NEON equivalence check) */
    unsigned rng = 0x12345678u;
    for (int i = 0; i < W * H; i++) {
        rng = rng * 1664525u + 1013904223u;
        src[i] = 0xFF000000u | (rng >> 8);
    }
    switch_scaling_scale2x(src, W, H, dst);
    switch_scaling_scale2x_scalar(src, W, H, ref);
    CHECK(memcmp(dst, ref, sizeof(dst)) == 0, "kernel == scalar (random)");

    /* 5) independent per-pixel recomputation of the reference rules */
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            uint32_t want[4];
            scale2x_ref_pixel(src, W, H, x, y, want);
            CHECK(dst[(2 * y) * (2 * W) + 2 * x] == want[0] &&
                  dst[(2 * y) * (2 * W) + 2 * x + 1] == want[1] &&
                  dst[(2 * y + 1) * (2 * W) + 2 * x] == want[2] &&
                  dst[(2 * y + 1) * (2 * W) + 2 * x + 1] == want[3],
                  "rules match [%d,%d]", x, y);
        }
    }

    /* 6) degenerate calls must not crash */
    switch_scaling_scale2x(NULL, 0, 0, dst);
    switch_scaling_scale2x(src, W, H, NULL);
    uint32_t one[1] = {0xFF112233u}, od[4];
    switch_scaling_scale2x(one, 1, 1, od);
    for (int i = 0; i < 4; i++) CHECK(od[i] == 0xFF112233u, "1x1 flat");
    printf("PASS-CHECK scale2x semantics + scalar/NEON equivalence\n");
}

/* v36.15: 90-degree rotation (per-game screen rotation). */
static void test_rotate90(void) {
    /* 3x2 known matrix (w=3, h=2):
     *   A B C
     *   D E F
     * CW ("90 right") -> display is 2 wide x 3 tall:
     *   D A
     *   E B
     *   F C
     * CCW ("90 left") -> display is 2 wide x 3 tall:
     *   C F
     *   B E
     *   A D */
    enum { W = 3, H = 2 };
    const uint32_t src[W * H] = { 'A', 'B', 'C', 'D', 'E', 'F' };
    uint32_t dst[H * W];
    memset(dst, 0, sizeof(dst));
    switch_scaling_rotate90(src, W, H, dst, 1);
    CHECK(dst[0] == 'D' && dst[1] == 'A', "CW col0 %c%c", dst[0], dst[1]);
    CHECK(dst[2] == 'E' && dst[3] == 'B', "CW col1 %c%c", dst[2], dst[3]);
    CHECK(dst[4] == 'F' && dst[5] == 'C', "CW col2 %c%c", dst[4], dst[5]);

    memset(dst, 0, sizeof(dst));
    switch_scaling_rotate90(src, W, H, dst, 2);
    CHECK(dst[0] == 'C' && dst[1] == 'F', "CCW col0 %c%c", dst[0], dst[1]);
    CHECK(dst[2] == 'B' && dst[3] == 'E', "CCW col1 %c%c", dst[2], dst[3]);
    CHECK(dst[4] == 'A' && dst[5] == 'D', "CCW col2 %c%c", dst[4], dst[5]);

    /* roundtrip: CW then CCW restores the original, on a non-square frame */
    {
        enum { RW = 5, RH = 3 };
        uint32_t s1[RW * RH], mid[RH * RW], back[RW * RH];
        for (int i = 0; i < RW * RH; i++) s1[i] = (uint32_t)(0xFF000000u | (i * 7 + 3));
        switch_scaling_rotate90(s1, RW, RH, mid, 1);
        switch_scaling_rotate90(mid, RH, RW, back, 2);
        CHECK(memcmp(s1, back, sizeof(s1)) == 0, "CW+CCW roundtrip");
        /* CW twice == 180 degrees: dst(x', y') = src(W-1-x, H-1-y) */
        switch_scaling_rotate90(mid, RH, RW, back, 1);
        for (int y = 0; y < RH; y++)
            for (int x = 0; x < RW; x++)
                CHECK(back[y * RW + x] == s1[(RH - 1 - y) * RW + (RW - 1 - x)],
                      "CW x2 == 180 at %d,%d", x, y);
    }
    /* degenerate guards: no crash, no write */
    {
        uint32_t d[4] = { 1, 2, 3, 4 };
        switch_scaling_rotate90(NULL, 2, 2, d, 1);
        switch_scaling_rotate90(d, 0, 2, d, 1);
        switch_scaling_rotate90(d, 2, 2, NULL, 1);
        switch_scaling_rotate90(d, 2, 2, d, 0); /* bad dir -> no-op */
        CHECK(d[0] == 1 && d[3] == 4, "guards leave dst untouched");
    }
    printf("PASS-CHECK rotate90 CW/CCW semantics + roundtrip\n");
}

int main(void) {
    test_game_rect();
    test_bg_size();
    test_blur();
    test_scale2x(); /* v36.14 */
    test_rotate90(); /* v36.15 */
    test_font();
    if (g_fails == 0) {
        printf("SWITCH-SCALING/FONT UNIT: ALL %s\n", "PASS");
        return 0;
    }
    printf("SWITCH-SCALING/FONT UNIT: %d FAILS\n", g_fails);
    return 1;
}
