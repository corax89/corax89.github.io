#!/bin/bash
# v36.27 [MIDI-TEMPO] автотест (отчёт: «музыка в Asphalt 3 3D замедлена /
# играют не все инструменты»).
#
# 1. Вырезает НАСТОЯЩИЕ MIDI из пака sound в games/"Asphalt 3 3D (1.1.5).jar"
#    (12 файлов за сигнатурой MThd; m1 = 2-я тема, темп 324324 мкс/долю).
# 2. Собирает host-харнесс scripts/miditempo/test_midi_tempo.c (только
#    midi.c — публичный API секвенсора, тот же код, что дергает
#    mix_midi_player) и прогоняет:
#    [T1] детерминизм темпа от пейсинга (0 мс vs 40 мс stalls -> PCM equal)
#    [T2] точность темпа 120 BPM (onset-детект по PCM: 250/312.5 мс)
#    [T3] running status после meta — все ноты звучат (было: десинк)
#    [T4] реальный m1.mid: длительность end-tick 57243 мс, позиция=рендер,
#         ненулевой PCM, детерминизм от пейсинга.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_miditempo
rm -rf "$D"; mkdir -p "$D"
JAR="games/Asphalt 3 3D (1.1.5).jar"

# --- вырезать m1.mid из пака sound (2-й MThd-блок) ---
python3 - "$JAR" "$D" <<'EOF'
import sys, zipfile, re
jar, outdir = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(jar)
sound = z.read('sound')
offs = [m.start() for m in re.finditer(b'MThd', sound)]
assert len(offs) >= 2, "sound pack: MThd blocks not found"
def carve(o):
    hl = int.from_bytes(sound[o+4:o+8], 'big')
    pos = o + 8 + hl
    ntr = int.from_bytes(sound[o+10:o+12], 'big')
    end = pos
    for _ in range(ntr):
        tl = int.from_bytes(sound[pos+4:pos+8], 'big')
        pos += 8 + tl
    return sound[o:pos]
m1 = carve(offs[1])
open(outdir + '/m1.mid', 'wb').write(m1)
print(f"carved m1.mid: {len(m1)} bytes (offset {offs[1]})")
EOF

# --- собрать харнесс (главный Makefile не трогаем) ---
gcc -Wall -Wextra -std=c11 -O2 -Iinclude -Isrc -Isrc/include \
    scripts/miditempo/test_midi_tempo.c src/midi/midi.c src/jvm/debug_var.c \
    -lm -o "$D/test_midi_tempo" 2> "$D/build.log" || {
    cat "$D/build.log"; echo "FAIL: harness build"; exit 1; }

# --- прогон ---
set +e
"$D/test_midi_tempo" "$D/m1.mid" > "$D/out.log" 2>&1
rc=$?
set -e
cat "$D/out.log"
echo "exit code: $rc (want 0)"
[ "$rc" = 0 ] || { echo "FAIL: midi tempo harness"; exit 1; }
echo "MIDI TEMPO: ALL CHECKS PASSED"
