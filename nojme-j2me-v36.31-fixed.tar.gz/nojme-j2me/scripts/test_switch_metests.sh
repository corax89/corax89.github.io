#!/bin/bash
# v36.31 E2E: MicroEmulator open test suite (org.microemu.tests) on NOJME.
# Covers the exact field-crash domains: exceptions on UI threads
# (ErrorHandling*), RMS usage (RecordStoreForm, store "meTestRecordStore"),
# runaway Thread + Timer (ThreadTestsForm; the Timer starts in the
# static-init of MainTestMIDlet, so EVERY session tears down with it).
# Navigation semantics (NOJME):
#   List: DOWN moves, A (FIRE) selects.
#   2 commands on a Displayable: X = command[0], B = command[1].
#   3+ commands: X opens the command menu, UP/DOWN select, B activates.
# Sessions:
#   A) ItemsOnForm: open item 0, B (add StringItem), X (Back), pause-exit.
#   B) ErrorHandlingForm: open item 1, menu -> "make error" (UNCAUGHT
#      IllegalArgumentException inside commandAction), pause-exit.
#   C) ErrorHandlingCanvas: open item 2 (paint exceptions class), keys,
#      pause-exit from a CANVAS context.
#   D) RecordStoreForm: open item 3, menu -> "Store" (create+add), menu ->
#      "Load" (read back), pause-exit; RMS file must exist on "disk".
#   E) ThreadTestsForm: open item 4, menu -> "start Thread" (runaway),
#      pause-exit WITH the live runaway thread + timer.
#   F) Whole-suite relaunch loop x3 (AUTOTEST_SESSIONS): session-end
#      stability with the static-init timer re-armed every session.
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="scripts/meTests/MicroEmuTests.jar"
[ -f "$JAR" ] || bash scripts/meTests/build.sh

run_session() {
    local tag="$1" script_front="$2" keys_menu="$3"
    local D=/tmp/sw_metests_$tag
    rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/rms"
    cp "$JAR" "$D/roms/"

    cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
    export NOJME_SWITCH_UI_DIR="$D"
    export XDG_DATA_HOME="$D/xdg"
    export NOJME_RMS_DIR="$D/rms"
    export NOJME_SWITCH_KEYS="$keys_menu"
    export NOJME_FRONT_KEYS="$script_front"

    timeout -k 5 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
    local rc=$?
    echo "== session $tag exit code: $rc (0 clean; 124 timeout; 139 SEGV = CRASH REPRO)"
    echo "$rc" > "$D/rc"
    return 0
}

ok=1
WANT="${SESSIONS:-A B C F}"
run_if() { case " $WANT " in *" $1 "*) return 0;; *) return 1;; esac; }
ALLG() { grep -ahq "$1" /tmp/sw_metests_$2/err.log /tmp/sw_metests_$2/out.log 2>/dev/null; }
NFAIL() { grep -ahq "$1" /tmp/sw_metests_$2/err.log /tmp/sw_metests_$2/out.log 2>/dev/null; }

# ---------- Session A: ItemsOnForm ----------
if run_if A; then
run_session A "A:3400,B:1200,X:1200,MINUS:900,DOWN:400,DOWN:400,A:900,EXIT:11000" "A:900,A:900,EXIT:6000"
grep -ahq "MainTestMIDlet static init" /tmp/sw_metests_A/err.log /tmp/sw_metests_A/out.log 2>/dev/null || { echo "FAIL[A]: suite не запустился (static init)"; ok=0; }
grep -ahq "runAwayTimer" /tmp/sw_metests_A/err.log /tmp/sw_metests_A/out.log 2>/dev/null || { echo "FAIL[A]: java.util.Timer (runAwayTimer) не тикает"; ok=0; }
grep -ahq "session complete" /tmp/sw_metests_A/err.log /tmp/sw_metests_A/out.log 2>/dev/null || { echo "FAIL[A]: нет возврата в меню после exit"; ok=0; }
fi

# ---------- Session B: AutoDriver (deterministic full-suite drive) ----------
# Drives the unmodified open suite's public panels directly: ItemsOnForm
# (LCDUI items), RecordStoreForm (RMS store/load/list), ErrorHandlingForm
# (CAUGHT + UNCAUGHT IllegalArgumentException in commandAction),
# ThreadTestsForm (runaway Thread), then notifyDestroyed with RMS state +
# runaway thread + timers alive -> destroyApp delivered twice (midlet's
# own direct call + the AMS delivery) -> clean teardown.
if run_if B; then
JARB="scripts/meTests/MicroEmuTestsAuto.jar"
run_session_b() {
    local D=/tmp/sw_metests_B
    rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/rms"
    cp "$JARB" "$D/roms/"
    cat > "$D/switchui_settings.ini" <<'EOF1'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF1
    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
    export NOJME_SWITCH_UI_DIR="$D"
    export XDG_DATA_HOME="$D/xdg"
    export NOJME_RMS_DIR="$D/rms"
    export NOJME_SWITCH_KEYS="A:900,A:900,EXIT:26000"
    export NOJME_FRONT_KEYS=""
    timeout -k 5 75 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
    local rc=$?
    echo "== session B exit code: $rc (0 clean; 124 timeout; 139 SEGV = CRASH REPRO)"
    echo "$rc" > "$D/rc"
}
run_session_b
DA=/tmp/sw_metests_B
grep -ahq "AUTO] steps done" $DA/err.log $DA/out.log 2>/dev/null || { echo "FAIL[B]: AutoDriver не дошёл до финального шага"; ok=0; }
grep -ahq "still alive" $DA/err.log $DA/out.log 2>/dev/null || true
grep -ahq "App will throw" $DA/err.log $DA/out.log 2>/dev/null || { echo "FAIL[B]: uncaught-throw шаг не выполнился"; ok=0; }
grep -ahq "runAwayThread" $DA/err.log $DA/out.log 2>/dev/null || { echo "FAIL[B]: runaway thread не стартовал"; ok=0; }
grep -ahq "session complete" $DA/err.log $DA/out.log 2>/dev/null || { echo "FAIL[B]: выход с RMS+thread+timer -> нечистый"; ok=0; }
grep -ah "AddressSanitizer" $DA/err.log 2>/dev/null | head -1 | grep -q . && { echo "FAIL[B]: ASAN-отчёт"; ok=0; }
fi

# ---------- Session C: AutoDriver relaunch loop x2 (RMS persistence) ----------
if run_if C; then
D=/tmp/sw_metests_C
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/rms"
cp scripts/meTests/MicroEmuTestsAuto.jar "$D/roms/"
cat > "$D/switchui_settings.ini" <<'EOF2'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF2
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
export NOJME_RMS_DIR="$D/rms"
export NOJME_SWITCH_AUTOTEST_SESSIONS=2
export NOJME_SWITCH_AUTOTEST_EXIT_MS=2000
export NOJME_SWITCH_KEYS="A:600,A:900"
export NOJME_FRONT_KEYS=""
timeout -k 5 120 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "== session C (auto relaunch) exit code: $rc"
n=$(grep -ah "AUTO] startApp" $D/err.log $D/out.log 2>/dev/null | wc -l)
echo "auto startApp count: $n (want >=2)"
[ "$n" -ge 2 ] || { echo "FAIL[C]: релаунч AutoDriver не прошли"; ok=0; }
grep -ahq "session complete" $D/err.log $D/out.log 2>/dev/null || { echo "FAIL[C]: нет чистого завершения"; ok=0; }
fi

# ---------- Session F: relaunch loop ----------
if run_if F; then
D=/tmp/sw_metests_F
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/rms"
cp "$JAR" "$D/roms/"
cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
export NOJME_RMS_DIR="$D/rms"
export NOJME_SWITCH_AUTOTEST_SESSIONS=3
export NOJME_SWITCH_AUTOTEST_EXIT_MS=3000
export NOJME_SWITCH_KEYS="A:600,A:900"
export NOJME_FRONT_KEYS=""
timeout -k 5 120 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "== session F exit code: $rc"
c=$(grep -ah "MainTestMIDlet static init" $D/err.log $D/out.log 2>/dev/null | wc -l)
echo "static-init count: $c (want >=3)"
[ "$c" -ge 3 ] || { echo "FAIL[F]: релаунчи сьюта не прошли"; ok=0; }
grep -ahq "menu session end" $D/err.log $D/out.log 2>/dev/null || { echo "FAIL[F]: нет завершения сессий меню"; ok=0; }
fi

if [ $ok -eq 1 ]; then
    echo "ME-TESTS: ALL CHECKS PASSED"
else
    echo "ME-TESTS: FAILED"
    for t in A B C F; do
        [ -d /tmp/sw_metests_$t ] && { echo "--- $t tail:"; tail -14 /tmp/sw_metests_$t/err.log 2>/dev/null; }
    done
fi
exit $((1 - ok))
