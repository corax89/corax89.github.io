#!/bin/bash
# Build TestSlowLoad.jar — v36.24 [BAD-LAUNCH-CLEANUP] selftest subject:
# a midlet stuck in its LOADING phase (30 s worker-thread sleep), so the
# driver can exit the session through the pause menu mid-load.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestSlowLoad.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TSL, , TestSlowLoad\r\nMIDlet-Name: TestSlowLoad\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestSlowLoad*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestSlowLoad.jar" META-INF && zip -q "$D/TestSlowLoad.jar" *.class )

echo "built: $D/TestSlowLoad.jar"
