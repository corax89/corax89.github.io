import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

/**
 * TestSlowLoad — v36.24 [BAD-LAUNCH-CLEANUP] selftest subject.
 *
 * Simulates a midlet stuck in its LOADING phase: startApp paints a
 * "LOADING..." canvas, then sleeps for a long time (the game is
 * "loading"). The test driver exits the session through the pause menu
 * while the midlet is still inside the sleep — the "запуск прерван на
 * этапе загрузки" scenario. The teardown must fully clean up; the NEXT
 * session (a good jar) must then run cleanly.
 *
 * Markers (stderr):
 *   [SLOWLOAD] session <n>: loading started  — painted + entered sleep
 *   [SLOWLOAD] session <n>: loading FINISHED — sleep ended (never happens
 *                              when the driver kills us mid-load)
 *   [SLOWLOAD] destroyed                     — destroyApp reached
 */
public class TestSlowLoad extends MIDlet {

    private static int sessionCount = 0;

    private class LoadCanvas extends Canvas implements Runnable {
        private int paintCount = 0;

        public void paint(Graphics g) {
            g.setColor(0x000080);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(0xFFFFFF);
            g.drawString("LOADING...", 10, 20, Graphics.TOP | Graphics.LEFT);
            g.drawString("paint #" + paintCount, 10, 40, Graphics.TOP | Graphics.LEFT);
            paintCount++;
            System.out.println("[SLOWLOAD] paint " + paintCount);
        }

        public void run() {
            // Simulate a long asset load: the session is killed mid-way.
            try {
                System.out.println("[SLOWLOAD] session " + sessionCount
                        + ": loading started");
                Thread.sleep(30000);
                System.out.println("[SLOWLOAD] session " + sessionCount
                        + ": loading FINISHED");
            } catch (InterruptedException ie) {
                System.out.println("[SLOWLOAD] load sleep interrupted");
            }
        }
    }

    protected void startApp() {
        sessionCount++;
        LoadCanvas c = new LoadCanvas();
        Display.getDisplay(this).setCurrent(c);
        // The canvas paints via the normal invalidate path; "loading" runs
        // on a worker thread so the frontend pump (and thus the pause menu)
        // stays alive while the session sits in its loading phase.
        new Thread(c).start();
    }

    protected void pauseApp() { }

    protected void destroyApp(boolean unconditional) {
        System.out.println("[SLOWLOAD] destroyed");
    }
}
