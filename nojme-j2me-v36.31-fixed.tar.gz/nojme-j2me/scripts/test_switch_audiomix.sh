#!/bin/bash
# v36.21 E2E: [CAP-REPORT] + MIXED-TYPE MIXING (midi + wav одновременно).
#
# TestAudio.jar (games/) через sandbox switchui-verify:
#   меню A,A -> тест сам прогоняет фазы и делает notifyDestroyed.
#
# Проверки:
#   [CAP-REPORT] (v36.21): System.getProperty() ИЗ JAVA-КОДА игры возвращает
#     microedition.m3g.version=1.1   (JSR-184 — раньше null -> "M3G недоступен")
#     microedition.media.version=1.0 (JSR-135 MMAPI — раньше null)
#     supports.mixing=true           (уже был)
#   [P10] ДВА плеера разных ТИПОВ (midi + wav) одновременно:
#     STATE_WAV=400 STATE_MIDI=400 и ОБА media-time продвинулись
#     (MT_WAV>500000 MK_MIDI>500000 микросекунд за ~1.2 c реального микса).
#     До v36.21 фаза P10 отсутствовала; миксер и так умел, но полевых
#     доказательств «разные типы вместе» не было.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_audiomix
rm -rf "$D"; mkdir -p "$D/roms"
cp "games/TestAudio.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=on
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800"
# тест сам завершается (notifyDestroyed); после ОДНОЙ игровой сессии меню
# простоев 5 с и чистый выход
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_AUTOTEST_EXIT_MS=5000

timeout -k 5 120 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"
grep -ah "TA:PROP m3g=1.1"        $ALL | head -1 | grep -q . || { echo "FAIL: m3g.version не 1.1"; ok=0; }
grep -ah "TA:PROP media=1.0"      $ALL | head -1 | grep -q . || { echo "FAIL: media.version не 1.0"; ok=0; }
grep -ah "TA:PROP mixing=true"    $ALL | head -1 | grep -q . || { echo "FAIL: supports.mixing не true"; ok=0; }
grep -ahq "PROP-MISS.*com.example.nonexistent.prop" $ALL || { echo "FAIL: [PROP-MISS] не сработал для неизвестного свойства"; ok=0; }

P10E=$(grep -ah "TA:P10:EARLY" $ALL | head -1)
P10=$(grep -ah "TA:P10:STATE_WAV=" $ALL | head -1)
echo "P10 early: $P10E"
echo "P10 final: $P10"
echo "$P10E" | grep -q "STATE_WAV=400" || { echo "FAIL: WAV player не STARTED на +300мс"; ok=0; }
echo "$P10E" | grep -q "STATE_MIDI=400" || { echo "FAIL: MIDI player не STARTED на +300мс"; ok=0; }

MT_W=$(echo "$P10" | sed -n 's/.*MT_WAV=\(-\?[0-9]*\).*/\1/p')
MT_M=$(echo "$P10" | sed -n 's/.*MT_MIDI=\(-\?[0-9]*\).*/\1/p')
echo "MT_WAV=${MT_W:-none} MT_MIDI=${MT_M:-none} (want >500000)"
[ -n "$MT_W" ] && [ "$MT_W" -gt 500000 ] || { echo "FAIL: WAV media-time не продвинулся"; ok=0; }
[ -n "$MT_M" ] && [ "$MT_M" -gt 500000 ] || { echo "FAIL: MIDI media-time не продвинулся"; ok=0; }

grep -ah "TA:DONE" $ALL | grep -q . || { echo "FAIL: тест не дошёл до TA:DONE"; ok=0; }
grep -ahq "UNCAUGHT EXCEPTION" $ALL && { echo "FAIL: незапланированное исключение"; ok=0; }

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
