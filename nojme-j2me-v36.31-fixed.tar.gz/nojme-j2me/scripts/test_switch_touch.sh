#!/bin/bash
# v36.26 E2E: [TOUCH-UI] — сенсорное управление для ВСЕХ элементов
# интерфейса. Два уровня одним прогоном TestTouch.jar:
#
#  ФРОНТЕНД (меню паузы): MINUS открывает паузу, тапы по строке «Выйти»
#  (двухфазная модель: выделить -> активировать) завершают игру.
#
#  MIDLET-UI (стандартный джава-интерфейс, канва 240x320, шрифт fh=9
#  (v36.29: getHeight() = глиф 7 + 2 leading), game rect fit_black
#  240x320 -> 1280x720 = (370,0,540,720), фактор 2.25):
#   1) тап по левой софт-кнопке («Menu», 3 команды) -> командное меню;
#   2) тап по пункту меню -> commandAction(GoList) -> List;
#   3) тап по строке 1 списка -> SELECT (listidx=1);
#   4) тап по правой софт-кнопке (BackForm) -> возврат на Form;
#   5) тап по TextField -> виртуальная клавиатура; тапы H, I, OK ->
#      itemStateChanged text=HI;
#   6) двойной тап по чекбоксу -> flags=10;
#   7) двойной тап по Gauge -> gauge=50 (значение по x);
#   8) меню -> About -> Alert; тап -> dismiss.
#
# Координаты тапов: канва -> экран (tx = 370 + cx*540/240; ty = cy*720/320).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_touch
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp scripts/touchjar/TestTouch.jar "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"

# Меню: A -> браузер, A -> TestTouch, EXIT -> чистый выход после возврата.
# (задержки последовательные; EXIT сработает, когда менеджер вернётся в меню)
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:4000"

# Сенсор в игре (FRONT_KEYS; первый токен — от старта процесса, далее зазоры):
export NOJME_FRONT_KEYS="TAP:460,690:5000,TAP:640,315:700,TAP:640,110:700,TAP:820,690:700,TAP:640,92:600,TAP:768,445:500,TAP:820,445:300,TAP:768,589:400,TAP:640,176:500,TAP:640,176:300,TAP:640,280:400,TAP:640,280:300,TAP:460,690:500,TAP:640,360:400,TAP:640,450:600,MINUS:1200,TAP:640,418:400,TAP:640,418:300"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1
ALL="$D/log.txt $D/err.log $D/out.log"

grep -ahq "TT] start" $ALL || { echo "FAIL: TestTouch не запустился"; ok=0; }
grep -ahq "TT] font=9" $ALL || { echo "FAIL: шрифт не 9px (v36.29 getHeight=7+2) — геометрия тапов неверна"; ok=0; }

# 1-2) софт-кнопка Menu + пункт командного меню
grep -ahq "TT] cmd=GoList on TForm" $ALL || { echo "FAIL: тап по софт-кнопке/командному меню не сработал (GoList)"; ok=0; }
# 3) List: тап по строке 1 -> SELECT
grep -ahq "TT] listidx=1" $ALL || { echo "FAIL: тап по строке List не выбрал index 1"; ok=0; }
# 4) правая софт-кнопка
grep -ahq "TT] cmd=BackForm on TList" $ALL || { echo "FAIL: тап по правой софт-кнопке не сработал (BackForm)"; ok=0; }
# 5) виртуальная клавиатура: H, I, OK
grep -ahq "TT] text=HI" $ALL || { echo "FAIL: ввод с виртуальной клавиатуры не дошёл (text=HI)"; ok=0; }
# 6) ChoiceGroup: тап по элементу = переключение
grep -ahq "TT] flags=10" $ALL || { echo "FAIL: тап по чекбоксу не переключил (flags=10)"; ok=0; }
# 7) Gauge: тап по полосе = значение по x
grep -ahq "TT] gauge=50" $ALL || { echo "FAIL: тап по Gauge не установил 50"; ok=0; }
# 8) Alert: тап = dismiss
grep -ahq "TT] cmd=About on TForm" $ALL || { echo "FAIL: About из командного меню"; ok=0; }
grep -ahq "TT] cmd=Dismiss on TAlert" $ALL || { echo "FAIL: тап не закрыл Alert"; ok=0; }
# фронтенд: тапы по меню паузы завершили игру
grep -ahq "pause menu -> exit game" $ALL || { echo "FAIL: тап по «Выйти» в меню паузы не сработал"; ok=0; }
grep -ahc "session complete — back to menu" $ALL >/dev/null || { echo "FAIL: нет возврата в меню"; ok=0; }
grep -ahq "menu exit — shutting down" $ALL || { echo "FAIL: чистый выход из меню не состоялся"; ok=0; }

# Canvas-канва НЕ должна была получить pointer-события от «чужих» тапов:
# ни одного pointerPressed в логе сессии (весь ввод ушёл в high-level UI).
if grep -ahq "pointerPressed" $ALL; then
  echo "FAIL: pointer-события протекли в канву мимо high-level UI"; ok=0
fi

# порядок: listidx строго между GoList и BackForm
F=$(grep -al "TT] cmd=GoList" $D/err.log 2>/dev/null | head -1)
if [ -n "$F" ]; then
  G=$(grep -an "TT] cmd=GoList" "$F" | head -1 | cut -d: -f1)
  L=$(grep -an "TT] listidx=1" "$F" | head -1 | cut -d: -f1)
  B=$(grep -an "TT] cmd=BackForm" "$F" | head -1 | cut -d: -f1)
  if [ -n "$G" ] && [ -n "$L" ] && [ -n "$B" ]; then
     [ "$G" -lt "$L" ] && [ "$L" -lt "$B" ] || { echo "FAIL: нарушен порядок List-сценария"; ok=0; }
  else
     echo "FAIL: не хватило строк сценария ($G/$L/$B)"; ok=0
  fi
fi

grep -ahqi "segfault\|SIGSEGV" $ALL && { echo "FAIL: краш"; ok=0; }

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
