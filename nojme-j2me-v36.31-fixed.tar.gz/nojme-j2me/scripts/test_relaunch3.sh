#!/bin/bash
# v35.12 repro: user report — "при повторном открытии мидлета он не
# загружается, а иногда происходит вылет" (trace v35.11: launch #2 OK,
# launch #3 -> init: jvm_create, init: jvm_init, init: FAILED -> crash).
#
# Drives THREE full game sessions of the SAME jar with the user flow:
#   menu A,A -> game -> MINUS (pause) -> B (exit to menu) -> menu A,A -> ...
# PASS = 3x "midlet: start" (init: jvm_init followed by sdl_init), no
# "init: FAILED", process survives to the timeout.
#
# usage: test_relaunch3.sh [jar] [seconds-per-session]
cd "$(dirname "$0")/.." || exit 1
JAR="${1:-games/Asphalt 3 3D (1.1.5).jar}"
SESS_MS="${2:-16000}"   # MINUS at ~16s of process time (game ~13s old)
SECS="${3:-80}"
D=/tmp/relaunch3
rm -rf "$D"; mkdir -p "$D/roms"
cp "$JAR" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# frontend menu script RESTARTS at every menu session (soak mode cap=3:
# menu sessions 1..3 each replay A,A -> same jar relaunched; session 4 idles).
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_SESSIONS=3
# wall-clock from process start: MINUS@16s, DOWN,DOWN,A («Выйти») @+1.2s,
# затем то же для сессий 2 и 3 (session 3 pause-exit just to end cleanly).
# v36.19: выход через пункт «Выйти» единого меню паузы (раньше B).
export NOJME_FRONT_KEYS="MINUS:${SESS_MS},DOWN:400,DOWN:400,A:800,MINUS:$((SESS_MS*2)),DOWN:400,DOWN:400,A:800,MINUS:$((SESS_MS*3)),DOWN:400,DOWN:400,A:800"

timeout -k 5 "$SECS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "rc=$rc (124=timeout, expected for a live app)"
echo "--- init/launch markers per session:"
grep -anE "game selected|init: jvm_create|init: jvm_init|init: sdl_init|init: FAILED|midlet: start|session end|menu: session start|jvm_destroy|heap" "$D/log.txt" 2>/dev/null | tail -40
echo "--- starts=$(grep -ac 'midlet: start' "$D/log.txt" 2>/dev/null)  failed=$(grep -ac 'init: FAILED' "$D/log.txt" 2>/dev/null)"
echo "--- err.log tail:"
tail -15 "$D/err.log" 2>/dev/null
