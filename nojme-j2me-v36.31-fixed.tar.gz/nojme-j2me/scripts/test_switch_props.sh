#!/bin/bash
# v36.26 E2E: [SYSPROPS] + locale-привязка.
#
# Запрос пользователя:
#   1) «microedition.locale всегда en — сделай, чтобы в switch версии он
#      зависел от настройки языка»;
#   2) «не установлены java.name java.version java.vm.name device.vendor
#      device.imei java.heap.size java.heap.free java.stack.size и подобные —
#      установи их для совместимости».
#
# TestProps.jar — MIDlet, печатающий [TP] key=value для всех ключей и
# завершающийся notifyDestroyed(). Запускается ДВАЖДЫ в одном процессе:
#   сессия 1 (язык RU по умолчанию)  -> обязана напечатать locale=ru;
#   MINUS в меню                      -> язык EN (persist в settings.ini);
#   сессия 2                          -> обязана напечатать locale=en.
#
# Дополнительно: ни один из запрошенных ключей не должен быть "<null>",
# java.stack.size=262144 (JAVA_STACK_SIZE), java.heap.size/free — числа,
# rt.totalMemory/rt.freeMemory (Runtime) — тоже числа.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_props
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp scripts/propsjar/TestProps.jar "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
# Меню-навигация (накопительные паузы от старта процесса):
#   t=1200 A -> браузер; t=1700 A -> sel=0 TestProps (сессия 1, RU)
#   (сессия завершается сама: notifyDestroyed сразу после печати)
#   t=5000 MINUS -> язык EN в меню; t=5700 A -> браузер; t=6200 A -> сессия 2 (EN)
#   t=9500 EXIT -> чистый выход
export NOJME_SWITCH_KEYS="A:1200,A:500,MINUS:3300,A:700,A:500,EXIT:3300"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"

# две сессии состоялись и обе завершились чисто
N_SESSIONS=$(grep -ahc "TP] start" $ALL | awk '{s+=$1} END {print s+0}')
[ "$N_SESSIONS" = "2" ] || { echo "FAIL: ожидалось 2 сессии TestProps, в логе $N_SESSIONS"; ok=0; }
N_DONE=$(grep -ahc "TP] done" $ALL | awk '{s+=$1} END {print s+0}')
[ "$N_DONE" = "2" ] || { echo "FAIL: обе сессии должны дойти до [TP] done ($N_DONE)"; ok=0; }
N_BACK=$(grep -ahc "session complete — back to menu" $ALL | awk '{s+=$1} END {print s+0}')
[ "$N_BACK" = "2" ] || { echo "FAIL: ожидалось 2 чистых возврата в меню, в логе $N_BACK"; ok=0; }

grep -ahq "TP] microedition.locale=ru" $ALL || { echo "FAIL: сессия 1 (RU) не увидела locale=ru"; ok=0; }
grep -ahq "TP] microedition.locale=en" $ALL || { echo "FAIL: сессия 2 (EN) не увидела locale=en"; ok=0; }

# порядок: ru СТРОГО в первой сессии, en — во второй
F=$(grep -al "TP] start" $D/err.log 2>/dev/null | head -1)
if [ -n "$F" ]; then
  S1=$(grep -an "TP] start" "$F" | sed -n 1p | cut -d: -f1)
  S2=$(grep -an "TP] start" "$F" | sed -n 2p | cut -d: -f1)
  LRU=$(grep -an "TP] microedition.locale=ru" "$F" | head -1 | cut -d: -f1)
  LEN=$(grep -an "TP] microedition.locale=en" "$F" | head -1 | cut -d: -f1)
  if [ -n "$S1" ] && [ -n "$S2" ] && [ -n "$LRU" ] && [ -n "$LEN" ]; then
     [ "$LRU" -lt "$S2" ] && [ "$LEN" -gt "$S2" ] \
       || { echo "FAIL: locale не переключился между сессиями (ru: $LRU, session2: $S2, en: $LEN)"; ok=0; }
  else
     echo "FAIL: не удалось сопоставить строки сессий/локали в err.log"; ok=0
  fi
fi

# НИ ОДНОГО <null> или исключения среди [TP]-строк — все ключи установлены
if grep -ahq "TP].*<null>" $ALL; then
  echo "FAIL: часть свойств вернула null:"; grep -ah "TP].*<null>" $ALL | sed 's/^/    /'; ok=0
fi
if grep -ahq "TP].*<throw" $ALL; then
  echo "FAIL: исключение при чтении свойств:"; grep -ah "TP].*<throw" $ALL | sed 's/^/    /'; ok=0
fi

# конкретные значения (запрос пользователя)
grep -ahq "TP] java.name=Java Platform, Micro Edition" $ALL || { echo "FAIL: java.name"; ok=0; }
grep -ahq "TP] java.version=1.4.2" $ALL || { echo "FAIL: java.version"; ok=0; }
grep -ahq "TP] java.vm.name=CLDC-HI" $ALL || { echo "FAIL: java.vm.name"; ok=0; }
grep -ahq "TP] device.vendor=Nokia" $ALL || { echo "FAIL: device.vendor"; ok=0; }
grep -ahq "TP] device.imei=000000000000000" $ALL || { echo "FAIL: device.imei"; ok=0; }
grep -ahq "TP] java.stack.size=262144" $ALL || { echo "FAIL: java.stack.size=262144"; ok=0; }
grep -ahE "TP] java.heap.size=[0-9]+" $ALL >/dev/null || { echo "FAIL: java.heap.size не число"; ok=0; }
grep -ahE "TP] java.heap.free=[0-9]+" $ALL >/dev/null || { echo "FAIL: java.heap.free не число"; ok=0; }
grep -ahE "TP] rt.totalMemory=[0-9]+" $ALL >/dev/null || { echo "FAIL: Runtime.totalMemory не число"; ok=0; }
grep -ahE "TP] rt.freeMemory=[0-9]+" $ALL >/dev/null || { echo "FAIL: Runtime.freeMemory не число"; ok=0; }

# heap.free <= heap.size (санити)
HS=$(grep -ahm1 "TP] java.heap.size=" $ALL | cut -d= -f2)
HF=$(grep -ahm1 "TP] java.heap.free=" $ALL | cut -d= -f2)
if [ -n "$HS" ] && [ -n "$HF" ] && [ "$HF" -gt "$HS" ]; then
  echo "FAIL: free ($HF) > size ($HS)"; ok=0
fi

# MINUS-тоггл пережил переключение (persist)
grep -ahq "^lang=en" "$D/switchui_settings.ini" || { echo "FAIL: settings.ini не сохранил lang=en"; ok=0; }

grep -ahqi "segfault\|SIGSEGV" $ALL && { echo "FAIL: краш"; ok=0; }

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
