#!/bin/bash
# Build MicroEmuTests.jar — the MicroEmulator manual-test MIDlet suite
# (org.microemu.tests, LGPL2.1/Apache2 — nikita36078/microemu fork, master).
# Tests: ItemsOnForm, ErrorHandlingForm, ErrorHandlingCanvas (throw in
# commandAction/keyPressed/paint), RecordStoreForm (RMS load/store/delete/
# list, store "meTestRecordStore"), ThreadTestsForm (runaway Thread +
# runaway java.util.Timer started in static-init!), PreporcessorTestCanvas,
# OverrideNewJSRCanvas (dynamic classload).
# This is the open-access J2ME test suite requested for batch 16; it is the
# closest open analog of the "exit with error" field crash: exceptions on
# UI threads + live runaway threads/timers at destroyApp time.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ME="${ME:-/tmp/me/microemu-master}"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found"; exit 1; }
[ -d "$ME/api" ] || { echo "microemu sources not found at $ME"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/api" "$OUT/test"

# Compile tests against NOJME compile-stubs (extended copy of sysinfojar
# stubs); java.* comes from the host JDK at compile time only. The stubs are
# NEVER packaged.
TEST_JAVA=$(find "$D/src" -name "*.java")
STUB_JAVA=$(find "$D/stubs" -name "*.java")
printf '%s\n' $TEST_JAVA $STUB_JAVA > "$OUT/test.files"
xargs -a "$OUT/test.files" java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT/test" 2> "$OUT/test.log" || { tail -30 "$OUT/test.log"; exit 1; }

# 3) Package
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: MicroEmuTests, , org.microemu.tests.MainTestMIDlet\r\nMIDlet-Name: MicroEmuTests\r\nMIDlet-Version: 2.0.4\r\nMIDlet-Vendor: microemu.org\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp -r "$OUT/test"/org "$PKG/"
cp -r "$OUT/test"/javax "$PKG/"
cp "$D/res/app-data.txt" "$PKG/"
( cd "$PKG" && zip -q -r "$D/MicroEmuTests.jar" META-INF org javax app-data.txt )

# Second jar: AutoDriverMIDlet as MIDlet-1 (deterministic driver for E2E)
PKG2="$OUT/pkg2"
rm -rf "$PKG2"; mkdir -p "$PKG2/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: MicroEmuTestsAuto, , org.microemu.tests.AutoDriverMIDlet\r\nMIDlet-Name: MicroEmuTestsAuto\r\nMIDlet-Version: 2.0.4\r\nMIDlet-Vendor: microemu.org\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG2/META-INF/MANIFEST.MF"
cp -r "$PKG"/org "$PKG2/"
cp -r "$PKG"/javax "$PKG2/"
cp "$D/res/app-data.txt" "$PKG2/"
( cd "$PKG2" && zip -q -r "$D/MicroEmuTestsAuto.jar" META-INF org javax app-data.txt )

echo "built: $D/MicroEmuTests.jar $D/MicroEmuTestsAuto.jar"
unzip -l "$D/MicroEmuTests.jar" | tail -2
