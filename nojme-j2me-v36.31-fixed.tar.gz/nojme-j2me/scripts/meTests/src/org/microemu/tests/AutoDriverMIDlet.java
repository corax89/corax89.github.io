/*  AutoDriverMIDlet — v36.31 NOJME batch-16 test driver.
 *
 *  Deterministic harness around the UNMODIFIED MicroEmulator open test
 *  suite (org.microemu.tests): instead of fragile sandbox soft-key/List
 *  navigation it drives the suite's own public test panels and their
 *  commandAction() directly — exactly what the soft keys would deliver —
 *  with java.util.Timer pacing. Covers the field-crash domains:
 *    - LCDUI items + commandAction dispatch (ItemsOnForm),
 *    - RMS open/add/load/list/delete (RecordStoreForm, "meTestRecordStore"),
 *    - UNCAUGHT IllegalArgumentException thrown inside commandAction
 *      (ErrorHandlingForm "make error") — the exit-with-error class,
 *    - runaway Thread + runaway Timer alive across the whole run
 *      (ThreadTestsForm), then notifyDestroyed with all of them live.
 *
 *  Everything is printed as [AUTO] lines so the E2E harness can verify.
 *  The original MainTestMIDlet stays the MIDlet-1 of MicroEmuTests.jar;
 *  this class ships in MicroEmuTestsAuto.jar (MIDlet-1 = AutoDriverMIDlet).
 */
package org.microemu.tests;

import java.util.Timer;
import java.util.TimerTask;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class AutoDriverMIDlet extends MIDlet implements MIDletUnderTests {

    private Timer timer;
    private int step = 0;
    private boolean started = false;

    private ItemsOnForm items;
    private ErrorHandlingForm errForm;
    private ErrorHandlingCanvas errCanvas;
    private RecordStoreForm rmsForm;
    private ThreadTestsForm threadForm;

    public AutoDriverMIDlet() {
        System.out.println("[AUTO] ctor");
    }

    /* MIDletUnderTests shim: panel back-commands land here */
    public void showMainPage() {
        System.out.println("[AUTO] showMainPage");
    }

    public void setCurrentDisplayable(Displayable nextDisplayable) {
        Display.getDisplay(this).setCurrent(nextDisplayable);
    }

    private void say(String s) {
        System.out.println("[AUTO] " + s);
    }

    protected void startApp() throws MIDletStateChangeException {
        say("startApp step=" + step);
        if (started) return;
        started = true;
        Manager.midletInstance = this;

        timer = new Timer();
        /* 1.2 s cadence: each step lands after the previous screen settled */
        timer.schedule(new TimerTask() { public void run() { stepItems(); } }, 1200);
        timer.schedule(new TimerTask() { public void run() { stepRmsStore(); } }, 2400);
        timer.schedule(new TimerTask() { public void run() { stepRmsLoad(); } }, 3600);
        timer.schedule(new TimerTask() { public void run() { stepRmsList(); } }, 4800);
        timer.schedule(new TimerTask() { public void run() { stepCatch(); } }, 6000);
        timer.schedule(new TimerTask() { public void run() { stepStartThread(); } }, 7200);
        /* the UNCAUGHT throw goes near the end — whatever survives it (per
         * the suite's own contract: "Emulator Should still work") still has
         * the RMS + thread state alive for the final exit */
        timer.schedule(new TimerTask() { public void run() { stepMakeError(); } }, 8400);
        timer.schedule(new TimerTask() { public void run() { stepCanvas(); } }, 9600);
        timer.schedule(new TimerTask() { public void run() { stepExit(); } }, 12000);
    }

    private void stepItems() {
        say("step: ItemsOnForm + add");
        items = new ItemsOnForm();
        setCurrentDisplayable(items);
        items.commandAction(ItemsOnForm.addCommand, items);
        items.commandAction(ItemsOnForm.addCommand, items);
    }

    private void stepRmsStore() {
        say("step: RecordStoreForm store");
        rmsForm = new RecordStoreForm();
        setCurrentDisplayable(rmsForm);
        rmsForm.commandAction(RecordStoreForm.storeCommand, rmsForm);
    }

    private void stepRmsLoad() {
        say("step: RecordStoreForm load");
        if (rmsForm != null) rmsForm.commandAction(RecordStoreForm.loadCommand, rmsForm);
    }

    private void stepRmsList() {
        say("step: RecordStoreForm list");
        if (rmsForm != null) rmsForm.commandAction(RecordStoreForm.listCommand, rmsForm);
        /* list() switches to the RecordStoreList screen; go back to the form */
        setCurrentDisplayable(rmsForm);
    }

    private void stepCatch() {
        say("step: ErrorHandlingForm catchException (caught internally)");
        errForm = new ErrorHandlingForm();
        setCurrentDisplayable(errForm);
        errForm.commandAction(ErrorHandlingForm.catchExceptionCommand, errForm);
    }

    private void stepStartThread() {
        say("step: ThreadTestsForm start Thread");
        threadForm = new ThreadTestsForm();
        setCurrentDisplayable(threadForm);
        threadForm.commandAction(ThreadTestsForm.startThreadCommand, threadForm);
    }

    private void stepMakeError() {
        say("step: ErrorHandlingForm make error (UNCAUGHT by design)");
        if (errForm != null) errForm.commandAction(ErrorHandlingForm.makeErrorCommand, errForm);
        say("step: still alive after uncaught throw");
    }

    private void stepCanvas() {
        say("step: ErrorHandlingCanvas show");
        errCanvas = new ErrorHandlingCanvas();
        setCurrentDisplayable(errCanvas);
    }

    private void stepExit() {
        say("steps done — RMS/thread/timer alive -> notifyDestroyed");
        try {
            destroyApp(true);
        } catch (MIDletStateChangeException e) {
            say("destroyApp threw: " + e);
        }
        notifyDestroyed();
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean unconditional) throws MIDletStateChangeException {
        say("destroyApp u=" + unconditional);
    }
}
