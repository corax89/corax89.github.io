package javax.microedition.rms;
public class RecordStoreNotFoundException extends RecordStoreException {
    public RecordStoreNotFoundException() {}
    public RecordStoreNotFoundException(String m) { super(m); }
}
