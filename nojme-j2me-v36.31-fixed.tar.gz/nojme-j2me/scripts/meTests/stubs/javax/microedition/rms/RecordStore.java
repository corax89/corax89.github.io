package javax.microedition.rms;
public class RecordStore {
    public static final int AUTHMODE_ANY = 1, AUTHMODE_PRIVATE = 0;
    public static RecordStore openRecordStore(String name, boolean create) throws RecordStoreException { return null; }
    public void closeRecordStore() throws RecordStoreException {}
    public int addRecord(byte[] data, int off, int len) throws RecordStoreException { return 0; }
    public void setRecord(int id, byte[] data, int off, int len) throws RecordStoreException {}
    public byte[] getRecord(int id) throws RecordStoreException { return null; }
    public int getNumRecords() throws RecordStoreException { return 0; }
    public void deleteRecord(int id) throws RecordStoreException {}
    public int[] getRecordIDs() throws RecordStoreException { return null; }
    public int getSize() throws RecordStoreException { return 0; }
    public int getSizeAvailable() throws RecordStoreException { return 0; }
    public void setMode(int mode, boolean writable) throws RecordStoreException {}
    public static void deleteRecordStore(String name) throws RecordStoreException {}
    public static String[] listRecordStores() { return null; }
}
