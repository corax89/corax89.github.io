package javax.microedition.lcdui;
public class Font {
    public static final int SIZE_SMALL = 8, SIZE_MEDIUM = 0, SIZE_LARGE = 16;
    public static Font getDefaultFont() { return new Font(); }
    public static Font getFont(int face, int style, int size) { return new Font(); }
    public int getHeight() { return 12; }
    public int stringWidth(String s) { return s == null ? 0 : s.length() * 6; }
}
