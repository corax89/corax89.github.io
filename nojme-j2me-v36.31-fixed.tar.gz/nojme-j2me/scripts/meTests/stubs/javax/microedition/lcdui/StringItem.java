package javax.microedition.lcdui;
public class StringItem extends Item {
    public StringItem() {}
    public StringItem(String label, String text) {}
    public String getText() { return null; }
    public void setText(String t) {}
}
