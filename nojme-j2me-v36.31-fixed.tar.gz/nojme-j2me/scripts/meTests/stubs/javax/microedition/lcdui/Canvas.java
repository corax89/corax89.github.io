package javax.microedition.lcdui;
public abstract class Canvas extends Displayable {
    protected boolean fullScreenMode = false;
    public static final int UP = -1, DOWN = -2, LEFT = -3, RIGHT = -4, FIRE = -5;
    public static final int GAME_A = -9, GAME_B = -8, GAME_C = -7, GAME_D = -6;
    protected abstract void paint(Graphics g);
    protected void keyPressed(int keyCode) {}
    protected void keyReleased(int keyCode) {}
    protected void keyRepeated(int keyCode) {}
    protected void showNotify() {}
    protected void hideNotify() {}
    public int getWidth() { return 240; }
    public int getHeight() { return 320; }
    public void setFullScreenMode(boolean mode) {}
    public int getGameAction(int keyCode) { return keyCode; }
    public void repaint() {}
    public void serviceRepaints() {}
    public void addCommand(Command cmd) {}
    public void setCommandListener(CommandListener l) {}
}
