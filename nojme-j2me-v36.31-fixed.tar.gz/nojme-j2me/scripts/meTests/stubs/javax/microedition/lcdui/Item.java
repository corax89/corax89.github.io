package javax.microedition.lcdui;
public class Item {
    public String getLabel() { return null; }
    public void setLabel(String l) {}
    public void addCommand(Command cmd) {}
    public void removeCommand(Command cmd) {}
    public void setDefaultCommand(Command cmd) {}
    public void setItemCommandListener(ItemCommandListener l) {}
}
