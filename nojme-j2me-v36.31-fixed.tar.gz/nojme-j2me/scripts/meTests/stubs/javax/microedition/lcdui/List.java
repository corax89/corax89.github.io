package javax.microedition.lcdui;
public class List extends Displayable {
    public static final int IMPLICIT = 3, EXCLUSIVE = 1, MULTIPLE = 2;
    public static final Command SELECT_COMMAND = new Command("Select", Command.OK, 1);
    public List(String title, int type) {}
    public int append(String s, Image img) { return 0; }
    public void delete(int i) {}
    public int size() { return 0; }
    public String getString(int i) { return null; }
    public int getSelectedIndex() { return 0; }
    public void setSelectedIndex(int i, boolean sel) {}
}
