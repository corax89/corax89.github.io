#!/bin/bash
# E2E regression: Battle Boats 3D (1.3.0)[128x160] level loading (v36.21).
#
# Bug: level load threw ClassCastException -> game drew its error screen
# "PROCESS: NULL::JAVA.LANG.CLASSCASTEXCEPTION" and never started the level.
# Root cause: Object3D.duplicate() zeroed userIDs (v34.18), but the game
# builds every boat from world.find(id).duplicate() and later does
# (Node)group.find(id) INSIDE that group. find() missed in the subtree and
# the out-of-spec global-registry fallback answered with an unrelated
# same-ID object (a VertexBuffer) -> (Node) cast exploded.
#
# This test navigates: splash -> "ENABLE SOUND?" YES -> profile YES ->
# menu CAMPAIGN (FIRE) -> boat screen START (LSK) -> briefing NEXT x5 ->
# OBJECTIVE dismiss (FIRE) and asserts the 3D level is up and no
# ClassCastException happened anywhere in the session.
set -e
cd "$(dirname "$0")/.." || exit 1

JAR="games/Battle Boats 3D (1.3.0)[128x160].jar"
[ -f "$JAR" ] || { echo "SKIP: $JAR not present"; exit 0; }

D=/tmp/sw_bb3d
rm -rf "$D"; mkdir -p "$D"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_HEADLESS_MAX_MS=80000
export NOJME_HEADLESS_IDLE=4000
export NOJME_HEADLESS_NOKEYS=1
export NOJME_HEADLESS_KEYSCRIPT="700:-6,1100:-6,1700:-5,2500:-6,3500:-6,3700:-6,3900:-6,4100:-6,4300:-6,4800:-5,5600:-5,6400:-1,7000:-1,7600:-3"
export NOJME_HEADLESS_SNAP_FRAMES=6500

timeout 120 env LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}" ./bin/j2me-headless "$JAR" > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
grep -qi "ClassCastException" "$D/err.log" && { echo "FAIL: ClassCastException всё ещё летит"; ok=0; }
grep -q "ClassCastException" "$D/out.log" 2>/dev/null && { echo "FAIL: ClassCastException в out.log"; ok=0; }
grep -qi "SIGSEGV\|segfault" "$D/err.log" && { echo "FAIL: краш"; ok=0; }
grep -q "renderWorld" "$D/err.log" || { echo "FAIL: 3D-мир не рендерился (renderWorld отсутствует)"; ok=0; }
# v36.21: after the fix every boat-part lookup (101..106, 66) resolves in the
# game group's own subtree; the global-registry fallback must NOT answer them.
grep -q "found userID=66 at .* (registry)" "$D/err.log" && { echo "FAIL: find(66) ушёл в global-registry fallback (userID не сохранился)"; ok=0; }
grep -q "found userID=66 at .* (recursive)" "$D/err.log" || { echo "FAIL: find(66) не найден в поддереве"; ok=0; }
# Level actually playable: gameplay keys fired -> ammo/timer HUD alive means
# the state machine advanced past loading; check the game ran 3D frames.
grep -q "Framebuffer:" "$D/err.log" || { echo "FAIL: нет итогового фреймбуфера"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "SWITCH-BB3D E2E: ALL CHECKS PASSED"
else
    echo "SWITCH-BB3D E2E: FAILED — хвост err.log:"; tail -25 "$D/err.log"
fi
exit $((1 - ok))
