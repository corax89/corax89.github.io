#!/bin/bash
# v36.17 автотест UI: 5 изменений экранов (sandbox, SDL dummy video).
#   1) в главном меню нет «MIDP2 мобильные игры на Nintendo Switch»
#   2) всплывающие подсказки настроек шрифтом x2 (полоса 514..660)
#   3) экран «Управление» — шрифт x2, две колонки
#   4) анимация курсора (быстрые UP/DOWN — код пути без краша)
#   5) «Настройки игры» (через ЕДИНОЕ меню паузы v36.19: PLUS -> DOWN -> A)
#      — прозрачный фон: виден кадр игры
# Скриншоты: NOJME_UI_DUMP_DIR (PPM-дамп канвы меню из sdl_switch_ui_present).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_ui3617
rm -rf "$D"; mkdir -p "$D/roms" "$D/dump1" "$D/dump2" "$D/pergame"
if [ -f "games/Gish - Reloaded [Rus].jar" ]; then cp "games/Gish - Reloaded [Rus].jar" "$D/roms/"; fi

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_UI_DUMP_MAX=60

# ---------- ТЕСТ 1: меню / настройки / управление (канва без игры) ----------
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_UI_DUMP_DIR="$D/dump1"
export NOJME_SWITCH_KEYS="DOWN:700,A:900,DOWN:500,UP:350,DOWN:350,DOWN:350,B:900,DOWN:400,A:900,B:900,EXIT:3000"
# старт -> dump главного меню; A -> Настройки (dump подсказки x2); UP/DOWN/
# DOWN/DOWN — анимация курсора + смена подсказок; B -> главное; DOWN,A ->
# «Управление» (dump 2 колонок); B -> главное; EXIT.
timeout 60 ./bin/switchui-verify > "$D/out1.log" 2> "$D/err1.log" || true
T1RC=$?
echo "test1 exit: $T1RC"

N1=$(ls "$D/dump1"/ui_*.ppm 2>/dev/null | wc -l)
echo "test1 dumps: $N1"

# ---------- ТЕСТ 2: прозрачный фон «Настроек игры» (Gish — кадр settles ~1.5 c) ----------
N2=0
if [ -f "$D/roms/Gish - Reloaded [Rus].jar" ]; then
    export NOJME_UI_DUMP_DIR="$D/dump2"
    export NOJME_UI_DUMP_MAX=80
    export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:60000"
    # в игре: PLUS:8000 (МЕНЮ ПАУЗЫ v36.19) -> DOWN:600 (пункт «Настройки
    # игры») -> A:800 (открыть per-game экран, фон = живой кадр) ->
    # DOWN/UP (анимация + подсказки поверх кадра) -> B:2000 (закрыть
    # настройки -> назад в меню паузы) -> B:12000 (продолжить) ->
    # MINUS пауза -> DOWN,DOWN,A («Выйти» -> в меню) -> EXIT догорает в меню
    export NOJME_FRONT_KEYS="PLUS:8000,DOWN:600,A:800,DOWN:3000,UP:2000,B:2000,B:12000,MINUS:1500,DOWN:400,DOWN:400,A:1500"
    timeout -k 5 100 ./bin/switchui-verify > "$D/out2.log" 2> "$D/err2.log" || true
    T2RC=$?
    echo "test2 exit: $T2RC"
    grep -q "pgset: open" "$D/err2.log" || { echo "FAIL: per-game экран не открывался"; echo "$T2RC" > /dev/null; exit 1; }
    grep -q "pgset: close" "$D/err2.log" || { echo "FAIL: per-game экран не закрылся"; exit 1; }
    grep -qi "segfault\|SIGSEGV" "$D/err2.log" && { echo "FAIL: краш"; exit 1; }
    N2=$(ls "$D/dump2"/ui_*.ppm 2>/dev/null | wc -l)
    echo "test2 dumps: $N2"
fi

# ---------- Пиксельные проверки ----------
python3 scripts/test_switch_ui3617_check.py "$D" "$N1" "$N2"
