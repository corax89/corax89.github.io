package javax.microedition.lcdui;
public class Gauge extends Item {
    public Gauge(String label, boolean interactive, int maxValue, int initialValue) {}
    public void setValue(int v) {}
    public int getValue() { return 0; }
    public int getMaxValue() { return 0; }
    public boolean isInteractive() { return false; }
}
