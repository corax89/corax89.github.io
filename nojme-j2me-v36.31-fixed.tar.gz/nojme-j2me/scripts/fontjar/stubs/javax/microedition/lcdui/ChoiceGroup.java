package javax.microedition.lcdui;
public class ChoiceGroup extends Item implements Choice {
    public ChoiceGroup(String label, int choiceType) {}
    public int append(String s, Image img) { return 0; }
    public int size() { return 0; }
    public String getString(int i) { return null; }
    public boolean isSelected(int i) { return false; }
    public void setSelectedIndex(int i, boolean sel) {}
    public int getSelectedFlags(boolean[] arr) { return 0; }
}
