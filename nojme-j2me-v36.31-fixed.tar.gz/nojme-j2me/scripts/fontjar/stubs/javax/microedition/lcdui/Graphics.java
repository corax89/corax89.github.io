package javax.microedition.lcdui;
public class Graphics {
    public static final int LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, HCENTER = 1, VCENTER = 2, BASELINE = 64;
    public void setColor(int rgb) {}
    public void setColor(int r, int g, int b) {}
    public void fillRect(int x, int y, int w, int h) {}
    public void drawRect(int x, int y, int w, int h) {}
    public void drawLine(int x1, int y1, int x2, int y2) {}
    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {}
    public void drawString(String s, int x, int y, int anchor) {}
    public void setClip(int x, int y, int w, int h) {}
    public void translate(int x, int y) {}
    public void setFont(Font f) {}
    public Font getFont() { return null; }
    public void drawImage(Image img, int x, int y, int anchor) {}
}
