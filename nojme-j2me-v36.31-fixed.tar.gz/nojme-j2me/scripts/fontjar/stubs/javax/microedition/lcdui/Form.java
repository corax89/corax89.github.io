package javax.microedition.lcdui;
public class Form extends Displayable {
    public Form(String title) {}
    public int append(Item item) { return 0; }
    public int append(String s) { return 0; }
    public void set(int i, Item item) {}
    public void delete(int i) {}
    public int size() { return 0; }
    public Item get(int i) { return null; }
    public void setItemStateListener(ItemStateListener l) {}
}
