package javax.microedition.lcdui;
public interface Choice {
    public static final int EXCLUSIVE = 1, MULTIPLE = 2, IMPLICIT = 3, POPUP = 4;
}
