package javax.microedition.lcdui;
public class Alert extends Displayable {
    public static final int FOREVER = -2;
    public Alert(String title) {}
    public Alert(String title, String text, Image image, AlertType type) {}
    public void setTimeout(int ms) {}
    public String getString() { return null; }
    public void setString(String s) {}
}
