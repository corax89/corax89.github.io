package javax.microedition.lcdui;
public class Image {
    public static Image createImage(String name) throws java.io.IOException { return null; }
    public static Image createImage(int width, int height) { return null; }
    public Graphics getGraphics() { return null; }
    public void getRGB(int[] rgbData, int offset, int scanlength, int x, int y, int width, int height) {}
    public int getWidth() { return 0; }
    public int getHeight() { return 0; }
}
