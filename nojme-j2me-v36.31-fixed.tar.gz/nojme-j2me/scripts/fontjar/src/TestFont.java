import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 * v36.29 TestFont — E2E proof of [FONT-HEIGHT] (getHeight() = 7px glyph box
 * + 2px leading = 9), [FONT-2X] (SIZE_LARGE renders/measures 2x) and
 * [FORM-SCROLL] (tall non-focusable Forms scroll with UP/DOWN).
 *
 * CANVAS phase: self-verifies pixels on an offscreen Image via getRGB and
 * prints "[FF] ..." facts:
 *   fh / fhL       - Font.getHeight() of default / LARGE
 *   cw / cwL       - Font.charWidth('H') of default / LARGE
 *   sw / swL       - Font.stringWidth("HHH") of default / LARGE
 *   gap=ok         - two lines spaced EXACTLY getHeight() apart leave the
 *                    leading rows blank (the old height=7 made them touch)
 *   inkL=14        - LARGE 'H' ink box = 2x7 rows (2x rendering proof)
 * FIRE switches to the FORM phase: one long StringItem (TOPMARK + 36
 * filler paragraphs) + Spacer(60px) + "ENDMARKER". Driven by
 * scripts/test_switch_fontform.sh via NOJME_GAME_KEYS; manual scrolling
 * prints "[FORM] scroll N -> M".
 */
public class TestFont extends MIDlet {

    Display d;
    Cv cv;
    Form form;
    boolean toForm = false;

    static final String LINE = "HHHH HHHH HHHH";
    static final Font FL = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_LARGE);

    public TestFont() {
        System.out.println("[FF] fh=" + Font.getDefaultFont().getHeight());
        System.out.println("[FF] fhL=" + FL.getHeight());
        System.out.println("[FF] cw=" + Font.getDefaultFont().charWidth('H')
                           + " cwL=" + FL.charWidth('H'));
        System.out.println("[FF] sw=" + Font.getDefaultFont().stringWidth("HHH")
                           + " swL=" + FL.stringWidth("HHH"));
    }

    protected void startApp() {
        System.out.println("[FF] start");
        d = Display.getDisplay(this);
        cv = new Cv();
        d.setCurrent(cv);
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean u) {}

    void buildForm() {
        form = new Form("FForm");
        StringBuffer sb = new StringBuffer();
        sb.append("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\r\n");
        for (int i = 1; i <= 36; i++) {
            sb.append("P");
            if (i < 10) sb.append('0');
            sb.append(i);
            sb.append(" aaaaa aaaaa aaaaa aaaaa aaaaa aaaaa aaaaa\r\n");
        }
        form.append(new StringItem(null, sb.toString()));
        form.append(new Spacer(10, 60));
        form.append(new StringItem(null, "ENDMARKER"));
        System.out.println("[FF] form=shown");
        d.setCurrent(form);
    }

    int inkRows(int[] px, int w, int h) {
        int rows = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (((px[y * w + x] >> 16) & 0xFF) < 128) { rows++; break; }
            }
        }
        return rows;
    }

    void offcheck() {
        Font f = Font.getDefaultFont();
        int fh = f.getHeight();

        /* gap proof: line 1 at y=1, line 2 at y=1+fh — the band between
         * the BOTTOM of line 1 (row 1+6=7) and the TOP of line 2 (1+fh)
         * must be blank. With the old fh=7 line 2 started at row 8 and
         * touched line 1 (descenders/caps on the same pixel row). */
        Image img = Image.createImage(80, 1 + fh + fh + 6);
        Graphics ig = img.getGraphics();
        ig.setColor(0xFFFFFF);
        ig.fillRect(0, 0, 80, img.getHeight());
        ig.setColor(0x000000);
        ig.drawString("HHHHH", 2, 1, Graphics.TOP | Graphics.LEFT);
        ig.drawString("HHHHH", 2, 1 + fh, Graphics.TOP | Graphics.LEFT);
        int w = img.getWidth(), h = img.getHeight();
        int[] px = new int[w * h];
        img.getRGB(px, 0, w, 0, 0, w, h);
        int gapBad = 0;
        for (int y = 8; y < 1 + fh; y++) {
            for (int x = 0; x < w; x++) {
                if (((px[y * w + x] >> 16) & 0xFF) < 128) { gapBad++; break; }
            }
        }
        System.out.println("[FF] gap=" + (gapBad == 0 ? "ok" : ("bad" + gapBad)));

        /* 2x proof: LARGE 'HH' ink box spans 2x7 rows starting at y=1 */
        Image img2 = Image.createImage(40, FL.getHeight() + 4);
        Graphics ig2 = img2.getGraphics();
        ig2.setColor(0xFFFFFF);
        ig2.fillRect(0, 0, 40, img2.getHeight());
        ig2.setColor(0x000000);
        ig2.setFont(FL);
        ig2.drawString("HH", 1, 1, Graphics.TOP | Graphics.LEFT);
        int w2 = img2.getWidth(), h2 = img2.getHeight();
        int[] px2 = new int[w2 * h2];
        img2.getRGB(px2, 0, w2, 0, 0, w2, h2);
        System.out.println("[FF] inkL=" + inkRows(px2, w2, h2));

        /* scale-1 reference: 'HH' ink box = 7 rows (unchanged medium font) */
        Image img3 = Image.createImage(40, fh + 4);
        Graphics ig3 = img3.getGraphics();
        ig3.setColor(0xFFFFFF);
        ig3.fillRect(0, 0, 40, img3.getHeight());
        ig3.setColor(0x000000);
        ig3.setFont(f);
        ig3.drawString("HH", 1, 1, Graphics.TOP | Graphics.LEFT);
        int w3 = img3.getWidth(), h3 = img3.getHeight();
        int[] px3 = new int[w3 * h3];
        img3.getRGB(px3, 0, w3, 0, 0, w3, h3);
        System.out.println("[FF] inkM=" + inkRows(px3, w3, h3));
    }

    public class Cv extends Canvas {
        boolean printed = false;

        protected void paint(Graphics g) {
            g.setColor(0xFFFFFF);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(0x000000);
            if (!printed) {
                printed = true;
                offcheck();
            }
            /* visible proof: 6 lines spaced EXACTLY by getHeight() */
            Font f = Font.getDefaultFont();
            int fh = f.getHeight();
            for (int i = 0; i < 6; i++) {
                g.drawString(LINE, 4, 8 + i * fh, Graphics.TOP | Graphics.LEFT);
            }
            /* 2x font below them */
            g.setFont(FL);
            g.drawString("BIG 2X", 4, 8 + 6 * fh + 8, Graphics.TOP | Graphics.LEFT);
            g.setFont(null);
        }

        protected void keyPressed(int keyCode) {
            if (keyCode == -5 && !toForm) {
                toForm = true;
                buildForm();
            }
        }
    }
}
