#!/bin/bash
# Build TestFont.jar — v36.29 selftest MIDlet: [FONT-HEIGHT] (getHeight()
# leading), [FONT-2X] (SIZE_LARGE = 2x rendering + metrics), [FORM-SCROLL]
# (tall non-focusable Form scrolled by UP/DOWN). Driven by
# scripts/test_switch_fontform.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestFont.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TF, , TestFont\r\nMIDlet-Name: TestFont\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestFont*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestFont.jar" META-INF && zip -q "$D/TestFont.jar" *.class )

echo "built: $D/TestFont.jar"
