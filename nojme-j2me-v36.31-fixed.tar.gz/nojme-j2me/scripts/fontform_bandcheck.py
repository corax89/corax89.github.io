#!/usr/bin/env python3
"""Band checker for scripts/test_switch_fontform.sh (v36.29 [FORM-SCROLL]).

Reads NOJME_GAME_DUMP_DIR PPM dumps (raw 240x320 game canvas, one per
second) and verifies the VIEW state by ink density of known bands:

  top    - the first content band (canvas y 25..32) holds the dense
           'MMMM...' TOPMARK paragraph line: view sits at the TOP of the
           document (scroll == 0). Requires >= 1 dump matching.
  bottom - the view reached the END of the document: the Spacer's 60px
           band above ENDMARKER is blank (y 222..266) while the ENDMARKER
           band (y 272..282) has ink. Requires >= 1 dump matching.

The last dump is checked first; any matching dump passes (the dump stream
may also contain the pre-FIRE canvas phase / earlier scroll states).
"""
import sys
import glob
import os


def load(path):
    data = open(path, 'rb').read()
    parts = data.split(b'\n', 3)
    if parts[0] != b'P6':
        raise ValueError(path + ': not P6')
    w, h = map(int, parts[1].split())
    return w, h, parts[3]


def band_dark(w, h, px, x0, y0, x1, y1):
    dark = tot = 0
    for y in range(y0, min(y1, h)):
        base = y * w
        for x in range(x0, min(x1, w)):
            o = (base + x) * 3
            tot += 1
            if px[o] < 128 and px[o + 1] < 128 and px[o + 2] < 128:
                dark += 1
    return dark / max(tot, 1)


def main():
    if len(sys.argv) != 3 or sys.argv[2] not in ('top', 'bottom'):
        print('usage: fontform_bandcheck.py <dumpdir> <top|bottom>')
        return 2
    files = sorted(glob.glob(os.path.join(sys.argv[1], 'game_*.ppm')))
    if not files:
        print('no dumps in', sys.argv[1])
        return 1
    # newest last (game_NNNN.ppm ascending in time)
    for path in reversed(files):
        try:
            w, h, px = load(path)
        except Exception as e:
            print('skip', path, e)
            continue
        if sys.argv[2] == 'top':
            # dense TOPMARK line right below the title (form at scroll 0).
            # (The canvas-phase dumps also have ink there, but those runs
            # have no GAME_KEYS — the form IS the first thing dumped.)
            if band_dark(w, h, px, 5, 25, 200, 32) > 0.35:
                print('top view OK:', os.path.basename(path))
                return 0
        else:
            blank = band_dark(w, h, px, 5, 222, 235, 266)   # Spacer area
            marker = band_dark(w, h, px, 5, 272, 235, 282)  # ENDMARKER
            if blank < 0.02 and marker > 0.04:
                print('bottom view OK:', os.path.basename(path),
                      'blank=%.3f marker=%.3f' % (blank, marker))
                return 0
    print('no dump matched view =', sys.argv[2])
    return 1


if __name__ == '__main__':
    sys.exit(main())
