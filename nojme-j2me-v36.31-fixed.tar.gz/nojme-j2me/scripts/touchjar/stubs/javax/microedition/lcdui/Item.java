package javax.microedition.lcdui;
public class Item {
    public String getLabel() { return null; }
    public void setLabel(String l) {}
}
