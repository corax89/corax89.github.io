import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;

/**
 * v36.26 TestTouch — E2E proof of [TOUCH-UI] on the MIDP high-level UI:
 * командное меню (тап по софт-кнопке), List (тап по строке -> SELECT),
 * TextField (тап -> виртуальная клавиатура -> набор тапами -> itemState),
 * ChoiceGroup (тап по элементу = переключение), Gauge (тап по полосе =
 * значение по x), Alert (тап = dismiss).
 *
 * Печатает "[TT] ..." в лог: шрифт (для расчёта координат тестом), факт
 * каждого события. Driven by scripts/test_switch_touch.sh.
 */
public class TestTouch extends MIDlet implements CommandListener, ItemStateListener {

    Display d;
    Form form;
    TextField name;
    ChoiceGroup flags;
    Gauge gauge;
    List list;
    Command goListCmd, aboutCmd, quitCmd, backCmd;

    public TestTouch() {
        System.out.println("[TT] font=" + Font.getDefaultFont().getHeight());
        d = Display.getDisplay(this);

        form = new Form("TForm");
        name = new TextField("Name", "", 20, TextField.ANY);
        flags = new ChoiceGroup("Flags", Choice.MULTIPLE);
        flags.append("Alpha", null);
        flags.append("Beta", null);
        gauge = new Gauge("Bar", true, 100, 10);
        form.append(name);
        form.append(flags);
        form.append(gauge);
        goListCmd = new Command("GoList", Command.SCREEN, 1);
        aboutCmd = new Command("About", Command.HELP, 2);
        quitCmd = new Command("Quit", Command.BACK, 3);
        form.addCommand(goListCmd);
        form.addCommand(aboutCmd);
        form.addCommand(quitCmd);
        form.setCommandListener(this);
        form.setItemStateListener(this);

        list = new List("TList", Choice.IMPLICIT);
        list.append("One", null);
        list.append("Two", null);
        list.append("Three", null);
        backCmd = new Command("BackForm", Command.BACK, 1);
        list.addCommand(backCmd);
        list.setCommandListener(this);
    }

    protected void startApp() {
        System.out.println("[TT] start");
        d.setCurrent(form);
    }

    public void commandAction(Command c, Displayable dd) {
        System.out.println("[TT] cmd=" + c.getLabel() + " on " + dd.getTitle());
        if (dd == list) {
            if (c.getLabel() != null && c.getLabel().equals("BackForm")) {
                d.setCurrent(form);
            } else {
                /* IMPLICIT-тап: какая строка выбрана — та и сработала */
                System.out.println("[TT] listidx=" + list.getSelectedIndex());
            }
            return;
        }
        if (c == goListCmd) {
            d.setCurrent(list);
        } else if (c == aboutCmd) {
            Alert a = new Alert("TAlert", "Tap to dismiss", null, AlertType.INFO);
            a.setTimeout(Alert.FOREVER);
            a.setCommandListener(this);
            d.setCurrent(a, form);
        } else if (c == quitCmd) {
            System.out.println("[TT] done");
            notifyDestroyed();
        }
    }

    public void itemStateChanged(Item it) {
        if (it == name) {
            System.out.println("[TT] text=" + name.getString());
        } else if (it == flags) {
            boolean[] st = new boolean[flags.size()];
            flags.getSelectedFlags(st);
            System.out.println("[TT] flags=" + (st[0] ? "1" : "0") + (st[1] ? "1" : "0"));
        } else if (it == gauge) {
            System.out.println("[TT] gauge=" + gauge.getValue());
        }
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean u) {}
}
