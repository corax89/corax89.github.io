#!/bin/bash
# Build TestTouch.jar — v36.26 [TOUCH-UI] selftest MIDlet: commands menu,
# List select, TextField -> virtual keyboard, ChoiceGroup toggle, Gauge
# value-by-tap, Alert dismiss. Driven by scripts/test_switch_touch.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestTouch.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TT, , TestTouch\r\nMIDlet-Name: TestTouch\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestTouch*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestTouch.jar" META-INF && zip -q "$D/TestTouch.jar" *.class )

echo "built: $D/TestTouch.jar"
