#!/bin/bash
# v36.22 E2E: [MC-RESET] — классы-стабы Mascot Capsule v3 должны получать
# СВОИ поля в КАЖДОЙ сессии (mtraHandle/figHandle/texHandle).
#
# Полевой сценарий: Treasure Towers, ВТОРОЙ запуск того же jar в одном
# процессе (меню -> игра -> выход -> игра). До фикса процесс-глобальная
# защёлка mc_stub_classes_ready пропускала init_mc_stub_classes() во второй
# сессии: классы создавались заново (fields_count=0, instance_size=24 =
# только ObjectHeader), нативный конструктор ActionTable МОЛЧА не мог
# записать mtraHandle, ActionTable.getNumFrames() возвращал 0, и игра
# делила на этот ноль — красный экран
#   "[ERROR] java/lang/ArithmeticException / by zero (c.d PC=23)"
# на ПОВТОРНОМ запуске. Первый запуск всегда был чистым.
#
# Проверки:
#   1. обе сессии стартовали;
#   2. ни одного "/ by zero" и ни одного умирания потока с необработанным
#      исключением;
#   3. сессия 2 дошла до полной загрузки ассетов ("loading sound:9") —
#      т.е. прошла "Init level 1", где раньше падала;
#   4. ноль "mc_set_int ... FAILED" и ноль "getNumFrames ... INVALID"
#      (диагностика v36.22: поля-стабы на месте в обеих сессиях);
#   5. процесс вышел чисто.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_ttrelaunch
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp "games/Treasure Towers (1.3)[128x160].jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_SESSIONS=2
export NOJME_SWITCH_AUTOTEST_EXIT_MS=20000
# wall-clock: сессия 1 стартует ~0.7 с, пауза на 8 с, «Выйти» ~8.8 с;
# сессия 2 стартует ~10.5 с, пауза на 25 с, «Выйти» ~25.8 с.
export NOJME_FRONT_KEYS="MINUS:8000,DOWN:400,DOWN:400,A:900,MINUS:25000,DOWN:400,DOWN:400,A:900"

timeout -k 5 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход)"
ok=1

N_SESSIONS=$(grep -ahc "\[SWITCH\] session: " "$D/err.log" | awk '{s+=$1} END{print s+0}')
echo "sessions started: $N_SESSIONS (want 2)"
[ "$N_SESSIONS" -eq 2 ] || { echo "FAIL: ожидалось 2 сессии"; ok=0; }

N_BYZERO=$(grep -ahc "by zero" "$D/err.log" "$D/log.txt" 2>/dev/null | awk '{s+=$1} END{print s+0}')
echo "'/ by zero' events: $N_BYZERO (want 0)"
[ "$N_BYZERO" -eq 0 ] || { echo "FAIL: ArithmeticException '/ by zero' на повторном запуске"; ok=0; }

N_DEATH=$(grep -ahc "terminated with uncaught exception" "$D/err.log" | awk '{s+=$1} END{print s+0}')
echo "uncaught thread deaths: $N_DEATH (want 0)"
[ "$N_DEATH" -eq 0 ] || { echo "FAIL: поток игры умер с необработанным исключением"; ok=0; }

# КЛЮЧЕВОЕ: сессия 2 прошла Init level и загрузила ВСЕ звуки
L2=$(grep -an "session: " "$D/err.log" | sed -n 2p | cut -d: -f1)
[ -n "$L2" ] || { echo "FAIL: не найден старт сессии 2"; ok=0; }
N_SND=$(tail -n +"$((L2+1))" "$D/err.log" | grep -ac "loading sound:9" || true)
echo "session-2 'loading sound:9' markers: $N_SND (want >=1)"
[ "$N_SND" -ge 1 ] || { echo "FAIL: сессия 2 не дошла до полной загрузки (Init level)"; ok=0; }

N_SETFAIL=$(grep -ahc "mc_set_int.*FAILED" "$D/err.log" | awk '{s+=$1} END{print s+0}')
N_HNDINV=$(grep -ahc "getNumFrames.*INVALID" "$D/err.log" | awk '{s+=$1} END{print s+0}')
echo "field-write failures: $N_SETFAIL, invalid handles: $N_HNDINV (want 0/0)"
[ "$N_SETFAIL" -eq 0 ] && [ "$N_HNDINV" -eq 0 ] || { echo "FAIL: поля классов-стабов Micro3D отсутствуют в одной из сессий"; ok=0; }

grep -ahq "EXITTRACE. main-returning" "$D/err.log" || { echo "FAIL: процесс не завершился чисто"; ok=0; }

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
