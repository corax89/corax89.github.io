import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.*;
import javax.microedition.rms.RecordStore;

/**
 * TestSysInfo — E2E mimic of "Sys Info (MH)(1.1.0)" class of MIDlets:
 * a Form FULL of system-property lines (long text -> scroll), soft-key
 * commands (Exit/Refresh/Copy -> both direct and menu mode), and an RMS
 * save inside destroyApp() (what info-midlets commonly do on exit).
 *
 * Prints "[SI] ..." markers consumed by scripts/test_switch_sysinfo.sh.
 */
public class TestSysInfo extends MIDlet implements CommandListener, ItemCommandListener {

    Display d;
    Form form;
    Command exitCmd;    /* EXIT type -> right soft key (direct... 3 cmds = menu mode) */
    Command refreshCmd; /* SCREEN type */
    Command copyCmd;    /* OK type */
    Command iExitCmd, iRefreshCmd, iCopyCmd, iExtraCmd; /* item-level commands */
    StringItem exitItem;     /* button-like StringItem with item commands */
    StringItem multiItem;    /* 3+ item commands -> item command menu */
    int refreshCount = 0;

    Thread worker;
    volatile boolean workerRun = true;

    public TestSysInfo() {
        System.out.println("[SI] ctor");
        d = Display.getDisplay(this);
    }

    private String prop(String k) {
        String v;
        try { v = System.getProperty(k); }
        catch (Throwable t) { return "<thr>"; }
        return (v == null) ? "null" : v;
    }

    private void fillForm() {
        /* v36.30 [ITEM-CMDS] coverage FIRST (visible at the top): actions on
         * ITEMS (not the Form) — the SysInfo-(MH)-style layout that exposed
         * the dead soft keys */
        exitItem = new StringItem("Exit: ", "[EXIT]");
        iExitCmd = new Command("Exit", Command.EXIT, 1);
        exitItem.addCommand(iExitCmd);
        exitItem.setDefaultCommand(iExitCmd);
        exitItem.setItemCommandListener(this);
        form.append(exitItem);

        multiItem = new StringItem("Multi: ", "[MENU]");
        iRefreshCmd = new Command("ItemRefresh", Command.ITEM, 1);
        iCopyCmd = new Command("ItemCopy", Command.ITEM, 2);
        iExtraCmd = new Command("ItemAbout", Command.HELP, 3);
        multiItem.addCommand(iRefreshCmd);
        multiItem.addCommand(iCopyCmd);
        multiItem.addCommand(iExtraCmd);
        multiItem.setItemCommandListener(this);
        form.append(multiItem);

        /* Typical SysInfo content: dozens of property lines -> long doc */
        String[] keys = {
            "microedition.platform", "microedition.configuration",
            "microedition.profiles", "microedition.locale",
            "microedition.encoding", "microedition.jtwi.version",
            "microedition.m3g.version", "microedition.media.version",
            "microedition.pim.version", "microedition.io.file.FileConnection.version",
            "microedition.connectionlimited", "microedition.chapi.version",
            "microedition.sip.version", "microedition.location.version",
            "microedition.global.version", "microedition.sensor.version",
            "microedition.amms.version", "microedition.m2g.version",
            "microedition.contacts.version", "microedition.event.version",
            "java.runtime.version", "java.vm.name", "java.vm.vendor",
            "java.vm.version", "java.platform", "java.protocol.handler.pkgs",
            "file.separator", "file.conn.privacy.root", "file.hidden",
            "file.mode", "file.supported", "bluetooth.api.version",
            "wireless.messaging.sms.smsc", "wireless.messaging.mms.mmsc",
            "wireless.messaging.version", "supportsvibration",
            "supportssoundoutput", "supportsrecording", "supportsvideo.capture",
            "supports.audio.capture", "supports.video.playback",
            "audio.encodings", "video.encodings", "video.snapshot.encodings",
            "streamable.contents", "device.model", "device.imei",
            "phone.imei", "platform", "build.number", "software.version",
            "com.sun.midp.publickeystore.WebPublicKeyStore",
            "com.motorola.CURRENT_DOCK_MODE", "com.nokia.memoryramfree",
            "com.nokia.mid.ui.softnotification", "com.sonyericsson.java.platform",
            "SamsungMIDletExcursion", "SI.HW", "SI.SW"
        };
        for (int i = 0; i < keys.length; i++) {
            form.append(keys[i] + " = " + prop(keys[i]));
        }
        form.append("--- line " + (keys.length + 1) + " ---");
        form.append("Total lines: " + (keys.length + 2));
        form.append("ENDMARKER-SI");
        System.out.println("[SI] filled items=" + form.size());
    }

    protected void startApp() {
        System.out.println("[SI] startApp");
        form = new Form("Sys Info");
        fillForm();
        exitCmd = new Command("Exit", Command.EXIT, 1);
        refreshCmd = new Command("Refresh", Command.SCREEN, 2);
        copyCmd = new Command("Copy", Command.OK, 3);
        form.addCommand(exitCmd);
        form.addCommand(refreshCmd);
        form.addCommand(copyCmd);
        form.setCommandListener(this);
        d.setCurrent(form);
        System.out.println("[SI] current set");
        /* v36.30 [EXIT-FENCE] stress: a live helper thread that keeps
         * interpreting while destroyApp runs on the frame thread — the
         * exact collision window from the user's crash report */
        worker = new Thread() {
            public void run() {
                int spin = 0;
                while (workerRun) {
                    spin++;
                    if (spin % 20 == 0) System.out.println("[SI] worker spin=" + spin);
                    try { Thread.sleep(30); } catch (InterruptedException ie) { break; }
                }
                System.out.println("[SI] worker done spin=" + spin);
            }
        };
        worker.start();
        System.out.println("[SI] worker started");
    }

    public void commandAction(Command c, Displayable dd) {
        String lbl = (c == null) ? "null" : c.getLabel();
        System.out.println("[SI] cmd=" + lbl + " on " + dd.getTitle());
        if (c == exitCmd) {
            System.out.println("[SI] exit requested");
            try { destroyApp(true); } catch (Throwable t) { System.out.println("[SI] destroy threw"); }
            notifyDestroyed();
        } else if (c == refreshCmd) {
            refreshCount++;
            fillForm();
            System.out.println("[SI] refreshed=" + refreshCount);
        } else if (c == copyCmd) {
            System.out.println("[SI] copy clicked");
        }
    }

    /* ItemCommandListener (MIDP 2.0): actions attached to ITEMS */
    public void commandAction(Command c, Item item) {
        String lbl = (c == null) ? "null" : c.getLabel();
        String who = (item == exitItem) ? "ExitItem"
                   : (item == multiItem) ? "MultiItem" : "?";
        System.out.println("[SI] itemcmd=" + lbl + " on " + who);
        if (c == iExitCmd) {
            System.out.println("[SI] item-exit requested");
            try { destroyApp(true); } catch (Throwable t) { System.out.println("[SI] destroy threw"); }
            notifyDestroyed();
        } else if (c == iRefreshCmd) {
            refreshCount++;
            System.out.println("[SI] item-refreshed=" + refreshCount);
        } else if (c == iCopyCmd) {
            System.out.println("[SI] item-copy clicked");
        } else if (c == iExtraCmd) {
            System.out.println("[SI] item-about clicked");
        }
    }

    /* Info-midlets typically persist "last run" stats on exit */
    protected void destroyApp(boolean unconditional) {
        System.out.println("[SI] destroyApp u=" + unconditional + " begin");
        workerRun = false;
        try {
            RecordStore rs = RecordStore.openRecordStore("sysinfo", true);
            byte[] rec1 = ("run=" + System.currentTimeMillis()).getBytes();
            int id = rs.addRecord(rec1, 0, rec1.length);
            byte[] rec2 = ("refreshes=" + refreshCount).getBytes();
            rs.setRecord(id, rec2, 0, rec2.length);
            int n = rs.getNumRecords();
            rs.closeRecordStore();
            System.out.println("[SI] rms saved n=" + n);
        } catch (Throwable t) {
            System.out.println("[SI] rms failed: " + t);
        }
        System.out.println("[SI] destroyApp end");
    }

    protected void pauseApp() {
        System.out.println("[SI] pauseApp");
    }
}
