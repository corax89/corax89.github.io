#!/bin/bash
# v36.24 E2E: [BAD-LAUNCH-CLEANUP] — неудачный/прерванный запуск НЕ отравляет
# следующий запуск (полевой отчёт: «повторный запуск мидлета приводит к
# вылету, какие-то ресурсы остаются заняты»).
#
# ЧЕТЫРЕ сессии в одном процессе, навигация менюшными клавишами:
#   1. AAA Broken.jar      — мусор вместо zip -> «No MIDlet class ...»,
#                             мгновенный возврат в меню БЕЗ error-экрана.
#   2. BBB BrokenClass.jar — валидный zip, НО класс-мусор -> «Failed to
#                             load class», возврат в меню.
#   3. CCC SlowLoad.jar    — стартует, уходит в 30-секундную «загрузку»
#                             (worker-поток), выходим через ЕДИНОЕ меню
#                             паузы (MINUS,DOWN,DOWN,A) посреди загрузки.
#   4. DDD Good.jar        — TestDosWrite, обязан ДОЖИТЬ до конца:
#                             «TDW:DONE ALL DOS CHECKS PASSED».
#
# Тайминг: NOJME_SWITCH_KEYS — накопительные паузы от старта процесса
# (позиция скрипта ПЕРЕЖИВАЕТ сессии); браузер при каждом открытии ставит
# курсор на 0, поэтому перед каждым выбором — DOWN'ы. NOJME_FRONT_KEYS
# взводится один раз на процесс; её окно (MINUS:30000...) попадает ВНУТРЬ
# сессии 3 (пауз-меню посреди «загрузки»).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_badlaunch
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp scripts/badlaunch/"AAA Broken.jar" "$D/roms/"
cp scripts/badlaunch/"BBB BrokenClass.jar" "$D/roms/"
cp scripts/badlaunch/"CCC SlowLoad.jar" "$D/roms/"
cp scripts/testdosw/TestDosWrite.jar "$D/roms/DDD Good.jar"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"

# --- меню-навигация (накопительные паузы) ---
#   t=1200  A -> открыть браузер;  t=1600 A -> sel=0: AAA Broken (провал)
#   t=3500  A -> браузер; t=3900 DOWN -> sel=1; t=5400 A -> BBB (провал)
#   t=8500  A -> браузер; DOWN,DOWN -> sel=2; t=10800 A -> CCC SlowLoad
#   t=36500 A -> браузер; DOWN x3 -> sel=3; t=39200 A -> DDD Good (TDW)
#   t=48500 EXIT -> чистый выход
export NOJME_SWITCH_KEYS="A:1200,A:400,A:1900,DOWN:400,A:1500,A:3100,DOWN:400,DOWN:400,A:1500,A:25700,DOWN:400,DOWN:400,DOWN:400,A:1500,EXIT:9300"
# --- фронтенд (внутри сессии 3: пауз-меню посреди загрузки -> «Выйти») ---
export NOJME_FRONT_KEYS="MINUS:30000,DOWN:400,DOWN:400,A:900"

timeout -k 5 75 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"
have() { grep -ahq "$1" $ALL; }

have "No MIDlet class specified or found in manifest" \
  || { echo "FAIL: сессия 1 (мусор-jar) не вернула «No MIDlet class»"; ok=0; }
# v36.24: битый класс теперь отклоняется ДЕТЕРМИНИРОВАННО (без stub-заглушки)
have "corrupt class file in JAR — refusing stub fallback" \
  || { echo "FAIL: сессия 2 (битый класс) не отклонена без заглушки"; ok=0; }
have "Failed to load class: pkg/TestBroken" \
  || { echo "FAIL: сессия 2 не вернула «Failed to load class»"; ok=0; }
have "SLOWLOAD] session 1: loading started" \
  || { echo "FAIL: сессия 3 не вошла в фазу загрузки"; ok=0; }
have "SLOWLOAD] destroyed" \
  || { echo "FAIL: destroyApp сессии 3 не достигнут"; ok=0; }
have "TDW:DONE ALL DOS CHECKS PASSED" \
  || { echo "FAIL: сессия 4 (хороший jar) не доиграла до TDW:DONE"; ok=0; }

N_BACK=$(grep -ahc "session complete — back to menu" $ALL | awk '{s+=$1} END{print s+0}')
echo "«back to menu» lines: $N_BACK (want >=4)"
[ "$N_BACK" -ge 4 ] || { echo "FAIL: не все сессии вернулись в меню"; ok=0; }

# КЛЮЧЕВАЯ проверка порядка: TDW:DONE должен появиться ПОСЛЕ обоих провалов
# и после прерванной загрузки (регрессия именно «следующий запуск»).
L_LAST_FAIL=$(grep -ahn "Failed to load class\|No MIDlet class" $ALL | tail -1 | cut -d: -f1)
L_TDW=$(grep -ahn "TDW:DONE" $ALL | head -1 | cut -d: -f1)
[ -n "$L_LAST_FAIL" ] && [ -n "$L_TDW" ] && [ "$L_TDW" -gt "$L_LAST_FAIL" ] \
  || { echo "FAIL: TDW:DONE не после провалов (порядок сессий нарушен)"; ok=0; }

if grep -aqiE "segfault|SIGSEGV|Segmentation" $ALL; then echo "FAIL: краш в логе"; ok=0; fi

[ "$ok" = 1 ] && echo "BAD-LAUNCH-CLEANUP: ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
