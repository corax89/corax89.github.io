NOJME v36.20 — J2ME-эмулятор для Nintendo Switch (NRO / hbloader)
==================================================================

ЧТО НОВОГО В v36.20 (по сравнению с v36.19)
-------------------------------------------
1) ФИКС SCALE2X: РАБОТАЕТ БЕЗ СГЛАЖИВАНИЯ
   Что было: Scale2x в v36.14-v36.19 фактически выполнялся, но его
   результат РАЗМЫВАЛСЯ при выводе: 2x-текстура создавалась с линейным
   режимом выборки (SDL_HINT_RENDER_SCALE_QUALITY="1" запекается в
   текстуру при создании), и финальное GPU-растяжение 2x-буфера до
   игрового прямоугольника добавляло билинейное сглаживание поверх
   Scale2x. Выглядело как «scale2x не работает» или «scale2x с мылом».
   Что стало:
     - 2x-текстура Scale2x создаётся с nearest-выборкой + явный
       SDL_SetTextureScaleMode(Nearest) — растяжение до игрового
       прямоугольника точечное, БЕЗ сглаживания. Чёткие пиксели,
       честный пиксель-арт, диагонали без «лестниц» — как и задумано
       для Scale2x.
     - В логе сессии теперь пишется «scale2x: ... (..., fit=nearest
       v36.20)» — по логу на приставке видно, что режим именно nearest.
   Доказывающие тесты (новые):
     - scripts/test_s2x_nosmooth.c — хост-тест на реальном ядре
       Scale2x: старая последовательность создания текстуры даёт 320
       «серых» (смешанных) пикселей на тестовой сетке, новая — 0.
     - scripts/test_switch_s2x.sh — E2E: сессия игры с filter=scale2x
       (глобально) и per-game вариантом (в <jar>.ini), выход через
       меню паузы, чистое завершение.

2) ФОН-БЛЮР (МАСШТАБ «ФОН С РАЗМЫТИЕМ») ВСЕГДА ГЛАДКИЙ
   Текстура размытой фон-заливки за letterbox создавалась с
   унаследованным nearest-режимом (при фильтрах «пиксельный»/«scale2x»)
   и становилась блочной. Теперь она всегда линейная (это намеренное
   размытие фона, к картинке игры отношения не имеет).

ЧТО БЫЛО В v36.19 (кратко, полная история — в FIXES.txt)
--------------------------------------------------------
   - Единое меню паузы на кнопках + и −: Продолжить / Настройки игры /
     Выйти. A или + — выбрать, B — продолжить, MINUS — язык, HOME —
     немедленный выход. Настройки игры открываются из паузы и
     возвращаются в неё; виртуальное время игры стоит всё время паузы.
   - Аудит путей по умолчанию: игры sdmc:/switch/j2me/games,
     сохранения sdmc:/switch/j2me/saves, настройки
     sdmc:/switch/j2me/settings.ini, per-game — sdmc:/switch/j2me/
     pergame/<имя>.jar.ini, лог — sdmc:/switch/j2me/log.txt.
   - Экран «Управление»: MINUS и PLUS подписаны «Меню паузы».

СБОРКА
------
Нужен devkitPro с devkitA64 (пакет switch-dev):
  make switchui        # NRO для приставки: bin/nojme_switch.nro

Хост-сборки/проверки:
  make headless        # безголовая сборка ядра
  make platform=linux  # libretro-ядро bin/nojme_libretro.so
  make switchui-verify SWITCHUI_SDL_CFLAGS=-I<SDL2-headers> \
       SWITCHUI_SDL_LIBS="-L<dir> -lSDL2"    # песочница фронтенда

АВТОТЕСТЫ (хост, песочница; новые — в начале списка)
  gcc -O2 -I src -I src/switch -I <SDL2-headers> \
      scripts/test_s2x_nosmooth.c src/switch/switch_scaling.c \
      -o test_s2x_nosmooth -lSDL2 -lm   # НОВЫЙ: доказательство «без сглаживания»
  scripts/test_switch_s2x.sh         # НОВЫЙ: E2E сессии с filter=scale2x
  scripts/test_switch_pausemenu.sh   # единое меню паузы +/−
  scripts/test_switch_fpsstrip.sh    # fps-полоса слева от игры
  scripts/test_switch_flipfps.sh     # живой флип 3D + счётчик
  scripts/test_switch_rotation.sh    # 176x220 + поворот экрана
  scripts/test_switch_ui3617.sh      # UI-пиксельные проверки
  scripts/test_switch_e2e.sh         # полный E2E фронтенда
  scripts/test_switch_input.sh       # ввод/настройки, 17 секций
  scripts/soak_close.sh              # открытие/закрытие игр, утечки
  scripts/win_symbol_audit.sh        # линк-аудит ядра

УСТАНОВКА НА ПРИСТАВКУ
----------------------
  1. Скопируйте bin/nojme_switch.nro на карту: switch/nojme.nro
  2. Игры (.jar) — в switch/j2me/games/ (создастся автоматически).
  3. Сохранения — switch/j2me/saves/, per-game настройки —
     switch/j2me/pergame/, лог — switch/j2me/log.txt.
  4. Запуск через hbmenu (Title Takeover / Game Reader — на ваш выбор).

СОВМЕСТИМОСТЬ
-------------
  settings.ini и pergame/*.ini от v36.14+ совместимы без изменений;
  filter=scale2x в старых файлах подхватывается как есть.
  vm_speed: свежая установка (без settings.ini) получает Турбо.

Известные особенности (не в v36.20, история):
  - Юнит-тест scripts/test_switch_scaling.c даёт 1 FAIL
    («cyrillic width scale2=32») — присутствует и на v36.19, на
    UI-тесты и картинку не влияет.

Полная история изменений: FIXES.txt (запись СЕССИЯ 64 — в конце файла).
