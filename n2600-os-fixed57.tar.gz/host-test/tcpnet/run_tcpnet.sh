#!/bin/sh
# run_tcpnet.sh — хост-тест TCP-стека против симулятора Linux-сервера.
# Использование: ./run_tcpnet.sh [asan]
set -e
cd "$(dirname "$0")"
SRC=${SRC:-../../src}

# настоящие исходники стека
cp $SRC/net.c $SRC/net.h $SRC/net_http.c .
# заголовки, которые включают net.c/net_http.c (настоящие)
for f in types.h sync.h task.h timer.h limits.h net_tls.h; do
    cp $SRC/$f .
done

# редиректы libc (как в tmfmt/setnet: наши прототипы конфликтуют с libc)
printf '#include <string.h>\n#include <stdio.h>\n#include <stdlib.h>\n' > string.h
printf '#include <stdlib.h>\n' > mem.h

# sync.h: настоящий содержит 32-битный inline-asm (pushf) — на x86_64
# хосте не собирается. Тест однопоточный — упрощённая версия.
cat > sync.h <<'EOF'
#ifndef SYNC_H
#define SYNC_H
#include "types.h"
static inline void s_lock(volatile int *l) { while (*l) { } *l = 1; }
static inline void s_unlock(volatile int *l) { *l = 0; }
static inline int s_trylock(volatile int *l) { if (*l) return 0; *l = 1; return 1; }
static inline int slock_owner_of(int v) { return v > 0; }
#endif
EOF

# заглушки заголовков NIC-драйверов (net.c их включает ради прототипов)
mk_stub_h() { printf '#ifndef %s_H\n#define %s_H\n#include "types.h"\n' "$1" "$1" > $1.h
cat >> $1.h <<EOF
static inline int ${2}_present(void) { return 0; }
static inline int ${2}_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
static inline u32 ${2}_recv(void *b, u32 m) { (void)b; (void)m; return 0; }
static inline int ${2}_link_up(void) { return 0; }
static inline void ${2}_get_mac(u8 *m) { (void)m; }
EOF
printf '#endif\n' >> $1.h; }
mk_stub_h e1000 e1000
mk_stub_h ne2000 ne2000
mk_stub_h virtio_net virtio_net
mk_stub_h atl1c atl1c

# ath9k_wifi.h: нужен только wifi_net_* (настоящий заголовок огромен)
cat > ath9k_wifi.h <<'EOF'
#ifndef ATH9K_WIFI_H
#define ATH9K_WIFI_H
#include "types.h"
int  wifi_present(void);
int  wifi_ready(void);
int  wifi_net_link(void);
void wifi_net_get_mac(u8 *m);
int  wifi_net_send(const void *buf, u32 len);
u32  wifi_net_recv(void *buf, u32 max);
#endif
EOF

FLAGS="-std=c99 -g -Wall -Wextra -Wno-unused-parameter -Wno-sign-compare"
BIN=tcpnet_test
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address,undefined -fno-omit-frame-pointer"
    BIN=tcpnet_test_asan
fi

gcc $FLAGS -o $BIN tcpnet_test.c net.c net_http.c
echo "== Запуск $BIN =="
./$BIN
