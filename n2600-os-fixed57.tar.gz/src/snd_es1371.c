/* snd_es1371.c — драйвер Ensoniq/Creative ES1371 (AudioPCI 97).
 *
 * Виртуальная звуковая карта VMware (sound.virtualDev="es1371",
 * «Sound Blaster AudioPCI») и реальный PCI-чип 1274:1371 / 1102:8938.
 * Карта регистров и последовательность инициализации — по драйверу
 * Linux sound/oss/es1371.c (даташет ES1371 1997).
 *
 * Реализован только PLAYBACK через DAC2 (16-bit stereo 44100, кольцевой
 * буфер из одного фрейма-дескриптора, режим loop). Без прерываний:
 * длительность воспроизведения ждём по PIT (простой API для теста).
 */
#include "types.h"
#include "io.h"
#include "pci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sound.h"

extern void serial_puts(const char *s);

/* ---------- регистры (I/O BAR0, 0x40 байт) ---------- */
#define ES_REG_CONTROL   0x00
#define ES_REG_STATUS    0x04
#define ES_REG_MEMPAGE   0x0c
#define ES_REG_SRCONV    0x10
#define ES_REG_CODEC     0x14
#define ES_REG_LEGACY    0x18
#define ES_REG_SCTRL     0x20
#define ES_REG_DAC1_SCNT 0x24
#define ES_REG_DAC2_SCNT 0x28
#define ES_REG_MEM_ADDR  0x34
#define ES_REG_MEM_DATA  0x38

/* CONTROL */
#define CTRL_SYNCRES  0x00004000u   /* AC97 warm reset */
#define CTRL_CCB_INTRM 0x00000400u
#define CTRL_DAC1_EN  0x00000040u
#define CTRL_DAC2_EN  0x00000020u
#define CTRL_ADC_EN   0x00000010u
/* SCTRL */
#define SCTRL_P2LOOPSEL 0x00004000u /* 0 = loop (кольцо) */
#define SCTRL_P2PAUSE   0x00001000u
#define SCTRL_P2DACSEN  0x00000040u
#define SCTRL_P2INTEN   0x00000200u
#define SCTRL_P2SEB     0x00000008u /* 16-bit */
#define SCTRL_P2SMB     0x00000004u /* stereo */
/* CODEC */
#define CODEC_WIP 0x40000000u
#define CODEC_RDY 0x80000000u
#define CODEC_PORD 0x00800000u
/* SRC */
#define SRC_RAMADDR_SHIFT 25
#define SRC_WE      0x01000000u
#define SRC_BUSY    0x00800000u
#define SRC_DIS     0x00400000u
#define SRC_DDAC1   0x00200000u
#define SRC_DDAC2   0x00100000u
#define SRC_DADC    0x00080000u
#define SRC_CTLMASK (SRC_DIS | SRC_DDAC1 | SRC_DDAC2 | SRC_DADC)
#define SRCREG_TRUNC_N    0x00
#define SRCREG_INT_REGS   0x01
#define SRCREG_VFREQ_FRAC 0x03
#define SRCREG_DAC1 0x70
#define SRCREG_DAC2 0x74
#define SRCREG_VOL_DAC1 0x7c
#define SRCREG_VOL_DAC2 0x7e
#define SRCREG_VOL_ADC  0x6c

/* страницы дескрипторов (MEMPAGE) */
#define ES_PAGE_DAC2 0x0c
/* смещения внутри страницы: DAC2 FRAMEADR 0x38, FRAMECNT 0x3c */
#define ES_OFF_DAC2_ADR 0x38
#define ES_OFF_DAC2_CNT 0x3c

static struct {
    u16 io;
    u32 ctrl;
    int ok;
} g_es;

static const char *es_name = "ES1371 (AudioPCI)";

static u32 es_in(u32 reg) { return inl((u16)(g_es.io + reg)); }
static void es_out(u32 reg, u32 v) { outl((u16)(g_es.io + reg), v); }

static void es_delay(u32 us)
{
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, us)) { }
}

/* ---------- SRC ---------- */
static u32 src_wait_ready(void)
{
    u32 r = 0;
    for (int t = 0; t < 4096; t++) {
        r = es_in(ES_REG_SRCONV);
        if (!(r & SRC_BUSY)) return r;
        es_delay(1);
    }
    return r;
}

static void src_write(u32 reg, u32 data)
{
    u32 r = src_wait_ready() & SRC_CTLMASK;
    r |= (reg << SRC_RAMADDR_SHIFT);
    r |= (data & 0xFFFF);
    es_out(ES_REG_SRCONV, r | SRC_WE);
}

static u32 src_read(u32 reg)
{
    u32 temp = src_wait_ready();
    u32 orig = temp & SRC_CTLMASK;
    es_out(ES_REG_SRCONV, orig | (reg << SRC_RAMADDR_SHIFT) | 0x10000u);
    temp = src_wait_ready();
    if ((temp & 0x00870000u) != (1u << 16)) {
        for (int i = 0; i < 4096; i++) {
            temp = es_in(ES_REG_SRCONV);
            if ((temp & 0x00870000u) == (1u << 16)) break;
        }
    }
    es_out(ES_REG_SRCONV, orig | (reg << SRC_RAMADDR_SHIFT));
    return temp & 0xFFFF;
}

static void set_dac2_rate(u32 rate)
{
    if (rate > 48000) rate = 48000;
    if (rate < 4000) rate = 4000;
    u32 freq = ((rate << 15) + 1500) / 3000;
    u32 r = (src_wait_ready() & SRC_CTLMASK) | SRC_DDAC2;
    es_out(ES_REG_SRCONV, r);
    src_write(SRCREG_DAC2 + SRCREG_INT_REGS,
              (src_read(SRCREG_DAC2 + SRCREG_INT_REGS) & 0x00FF) |
              ((freq >> 5) & 0xFC00));
    src_write(SRCREG_DAC2 + SRCREG_VFREQ_FRAC, freq & 0x7FFF);
    r = (src_wait_ready() & SRC_CTLMASK);
    es_out(ES_REG_SRCONV, r);
}

/* ---------- AC97 через регистр CODEC (с SRC-окном записи) ---------- */
static int ac97_wip_wait(void)
{
    for (int t = 0; t < 8192; t++)
        if (!(es_in(ES_REG_CODEC) & CODEC_WIP)) return 1;
    return 0;
}

static void ac97_write(u8 addr, u16 data)
{
    if (!ac97_wip_wait()) return;
    u32 x = src_wait_ready();
    es_out(ES_REG_SRCONV, (x & SRC_CTLMASK) | 0x10000u);
    for (int t = 0; t < 4096; t++)
        if ((es_in(ES_REG_SRCONV) & 0x00870000u) == 0) break;
    for (int t = 0; t < 4096; t++)
        if ((es_in(ES_REG_SRCONV) & 0x00870000u) == 0x10000u) break;
    es_out(ES_REG_CODEC,
           (((u32)addr << 16) & 0x007F0000u) | (u32)data);
    src_wait_ready();
    es_out(ES_REG_SRCONV, x);
    /* WIP после записи */
    for (int t = 0; t < 8192; t++)
        if (!(es_in(ES_REG_CODEC) & CODEC_WIP)) break;
}

/* ---------- init SRC RAM (по Linux src_init) ---------- */
static void src_init(void)
{
    src_wait_ready();
    es_out(ES_REG_SRCONV, SRC_DIS);
    for (u32 i = 0; i < 0x80; i++) src_write(i, 0);
    src_write(SRCREG_DAC1 + SRCREG_TRUNC_N, 16 << 4);
    src_write(SRCREG_DAC1 + SRCREG_INT_REGS, 16 << 10);
    src_write(SRCREG_DAC2 + SRCREG_TRUNC_N, 16 << 4);
    src_write(SRCREG_DAC2 + SRCREG_INT_REGS, 16 << 10);
    src_write(SRCREG_VOL_ADC, 1 << 12);
    src_write(SRCREG_VOL_ADC + 1, 1 << 12);
    src_write(SRCREG_VOL_DAC1, 1 << 12);
    src_write(SRCREG_VOL_DAC1 + 1, 1 << 12);
    src_write(SRCREG_VOL_DAC2, 1 << 12);
    src_write(SRCREG_VOL_DAC2 + 1, 1 << 12);
    (void)set_dac2_rate;    /* rate задаётся при воспроизведении */
    src_wait_ready();
    es_out(ES_REG_SRCONV, 0);
}

int snd_es1371_probe(void)
{
    g_es.ok = 0;
    g_es.io = 0;
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid == 0xFFFF) continue;
                int hit = (vid == 0x1274 && did == 0x1371) ||
                          (vid == 0x1102 && did == 0x8938) ||
                          (vid == 0x1102 && did == 0x5880);
                if (!hit) continue;
                u32 bar0 = pci_read32(bus, dev, fn, 0x10);
                if (!(bar0 & 1)) continue;          /* нужен I/O BAR */
                u16 io = (u16)(bar0 & 0xFFFCu);
                if (!io) continue;
                u16 cmd = pci_read16(bus, dev, fn, 0x04);
                pci_write16(bus, dev, fn, 0x04, (u16)(cmd | 0x5)); /* IO+BME */
                g_es.io = io;
                g_es.ok = 1;
                {
                    char b[80];
                    snprintf(b, sizeof(b), "[es1371] %04x:%04x io=%x\n",
                             vid, did, io);
                    serial_puts(b);
                }
                return 1;
            }
        }
    }
    return 0;
}

const char *snd_es1371_name(void) { return es_name; }

/* Воспроизведение: samples = frames * 2 (stereo) int16, rate, ms */
int snd_es1371_play(const i16 *samples, u32 frames, u32 rate, u32 ms)
{
    if (!g_es.ok) return -1;
    if (!samples || frames < 8) return -1;
    u32 bytes = frames * 4;
    if (bytes > 0x10000) bytes = 0x10000;      /* дескриптор: до 64К */

    u32 phys = (u32)(unsigned long)samples;
    if (phys & 3u) return -1;

    /* формат DAC2: 16-bit stereo, loop-кольцо, без прерываний */
    u32 sctrl = es_in(ES_REG_SCTRL);
    sctrl &= ~(SCTRL_P2LOOPSEL | SCTRL_P2PAUSE | SCTRL_P2DACSEN |
               SCTRL_P2INTEN);
    sctrl |= SCTRL_P2SEB | SCTRL_P2SMB;
    es_out(ES_REG_SCTRL, sctrl);

    /* дескриптор: страница 0x0c, адрес + счётчик (в dwords, -1) */
    es_out(ES_REG_MEMPAGE, ES_PAGE_DAC2);
    es_out(ES_REG_MEM_ADDR, phys);
    es_out(ES_REG_MEM_DATA, (bytes >> 2) - 1);

    /* частота */
    set_dac2_rate(rate);

    /* старт: SCOUNT до включения DAC2 и после (как в Linux; SCOUNT —
     * во ФРЕЙМАХ сэмплов: bytes>>2 для 16-bit stereo) */
    u32 dwords = bytes >> 2;
    es_out(ES_REG_DAC2_SCNT, dwords - 1);
    u32 ctrl = es_in(ES_REG_CONTROL);
    g_es.ctrl = ctrl;
    ctrl |= CTRL_DAC2_EN;
    es_out(ES_REG_CONTROL, ctrl);
    es_out(ES_REG_DAC2_SCNT, dwords - 1);

    /* ждём (PIT, 1 тик = 1 мс); кольцо крутится само */
    u32 t0 = timer_ticks();
    while ((timer_ticks() - t0) < ms) task_msleep(5);

    /* стоп */
    ctrl = es_in(ES_REG_CONTROL);
    ctrl &= ~CTRL_DAC2_EN;
    es_out(ES_REG_CONTROL, ctrl);
    return 0;
}

/* Инициализация кодека (вызывается после probe, при sound_init) */
void snd_es1371_codec_init(void)
{
    if (!g_es.ok) return;
    /* warm reset AC97 */
    u32 ctrl = es_in(ES_REG_CONTROL);
    ctrl |= CTRL_SYNCRES;
    es_out(ES_REG_CONTROL, ctrl);
    es_delay(2000);
    ctrl &= ~CTRL_SYNCRES;
    es_out(ES_REG_CONTROL, ctrl);
    es_delay(20000);

    /* AC97: полный сброс + громкости */
    ac97_write(0x00, 0x0000);     /* reset */
    es_delay(10000);
    ac97_write(0x02, 0x0808);     /* master volume ~-12dB */
    ac97_write(0x18, 0x0808);     /* PCM out volume */
    ac97_write(0x26, 0x0000);     /* power: всё включено */

    src_init();
}
