/* sound.h — звуковая подсистема N2600-OS (сессия 57).
 *
 * Два драйвера, выбирается найденный первым:
 *   - ES1371 (Ensoniq/Creative AudioPCI, PCI 1274:1371) — виртуальная
 *     карта VMware (sound.virtualDev = "es1371", режим по умолчанию для
 *     гостей до Workstation 8 и вариант «Sound Blaster AudioPCI»);
 *   - Intel HD Audio (класс 0x0403, напр. 8086:2668/27D8/293E) — режим
 *     VMware "hdaudio" (по умолчанию для новых гостей) И настоящая
 *     Realtek ALC269VB на реальном железе (нетбук N2600).
 *
 * API блокирующий (простой тест звука по кнопке в System Info):
 * тон синтезируется целочисленно (FPU не сохраняется между задачами).
 */
#ifndef SOUND_H
#define SOUND_H

#include "types.h"

int  sound_init(void);              /* probe PCI; 1 = устройство найдено */
int  sound_present(void);
const char *sound_device_name(void); /* "нет" если не найдено */
const char *sound_last_error(void);

/* Блокирующий тон: частота Hz, длительность ms. 0 = ок. */
int  sound_beep(u32 freq_hz, u32 ms);

/* Мелодия из четырёх нот (тест динамика по кнопке). */
int  sound_test_melody(void);

#endif /* SOUND_H */
