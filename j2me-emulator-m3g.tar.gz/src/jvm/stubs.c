/*
 * J2ME Emulator - Built-in Stub Classes
 * Generates minimal stub classes for J2ME API
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup - only on POSIX systems */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jvm.h"
#include "classfile.h"
#include "native.h"
#include "opcodes.h"  /* For ACC_* constants */
#include "debug.h"

/* Forward declarations */
static JavaClass* create_stub_class(JVM* jvm, const char* name, const char* super_name, uint16_t access_flags);

/* List of required J2ME stub classes */
static const struct {
    const char* name;
    const char* super;
    uint16_t flags;
} stub_classes[] = {
    /* Core Java classes */
    /* FIX: Object must be concrete (not abstract) to have a constructor */
    { "java/lang/Object", NULL, ACC_PUBLIC },
    { "java/lang/Class", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/String", "java/lang/Object", ACC_PUBLIC | ACC_FINAL },
    { "java/lang/StringBuilder", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/StringBuffer", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Exception", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/RuntimeException", "java/lang/Exception", ACC_PUBLIC },
    { "java/lang/Error", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Throwable", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/NullPointerException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/ClassCastException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/ArrayIndexOutOfBoundsException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IndexOutOfBoundsException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IllegalArgumentException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IllegalStateException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/NumberFormatException", "java/lang/IllegalArgumentException", ACC_PUBLIC },
    { "java/lang/ClassNotFoundException", "java/lang/Exception", ACC_PUBLIC },
    { "java/lang/OutOfMemoryError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/VirtualMachineError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/InternalError", "java/lang/VirtualMachineError", ACC_PUBLIC },
    { "java/lang/NoSuchMethodError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/NoSuchFieldError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/NoClassDefFoundError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/ClassFormatError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/VerifyError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/Integer", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Long", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Float", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Double", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Boolean", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Math", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/System", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Runtime", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Thread", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Runnable", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/lang/Cloneable", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/Random", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Vector", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Hashtable", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Enumeration", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/Timer", "java/lang/Object", ACC_PUBLIC },
    { "java/util/TimerTask", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    
    /* I/O classes */
    { "java/io/InputStream", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/io/OutputStream", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/io/Reader", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/io/InputStreamReader", "java/io/Reader", ACC_PUBLIC },
    { "java/io/BufferedReader", "java/io/Reader", ACC_PUBLIC },
    { "java/io/ByteArrayInputStream", "java/io/InputStream", ACC_PUBLIC },
    { "java/io/ByteArrayOutputStream", "java/io/OutputStream", ACC_PUBLIC },
    { "java/io/DataInputStream", "java/io/InputStream", ACC_PUBLIC },
    { "java/io/DataOutputStream", "java/io/OutputStream", ACC_PUBLIC },
    { "java/io/IOException", "java/lang/Exception", ACC_PUBLIC },
    { "java/io/EOFException", "java/io/IOException", ACC_PUBLIC },
    { "java/io/UTFDataFormatException", "java/io/IOException", ACC_PUBLIC },
    { "java/io/FileNotFoundException", "java/io/IOException", ACC_PUBLIC },
    { "java/io/InterruptedIOException", "java/io/IOException", ACC_PUBLIC },
    { "java/io/PrintStream", "java/io/OutputStream", ACC_PUBLIC },
    { "java/io/UnsupportedEncodingException", "java/io/IOException", ACC_PUBLIC },
    
    /* J2ME MIDlet API */
    { "javax/microedition/midlet/MIDlet", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/midlet/MIDletStateChangeException", "java/lang/Exception", ACC_PUBLIC },
    
    /* J2ME LCDUI API */
    { "javax/microedition/lcdui/Display", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Displayable", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Screen", "javax/microedition/lcdui/Displayable", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Canvas", "javax/microedition/lcdui/Displayable", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/game/GameCanvas", "javax/microedition/lcdui/Canvas", ACC_PUBLIC },
    { "javax/microedition/lcdui/game/Layer", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/game/Sprite", "javax/microedition/lcdui/game/Layer", ACC_PUBLIC },
    { "javax/microedition/lcdui/game/TiledLayer", "javax/microedition/lcdui/game/Layer", ACC_PUBLIC },
    { "javax/microedition/lcdui/game/LayerManager", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Graphics", "java/lang/Object", ACC_PUBLIC }, 
    { "javax/microedition/lcdui/Image", "java/lang/Object", ACC_PUBLIC | ACC_FINAL },
    { "javax/microedition/lcdui/Font", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Command", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/CommandListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/lcdui/Item", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Form", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/TextBox", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/List", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/Alert", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/AlertType", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Ticker", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Gauge", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/StringItem", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/TextField", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/ChoiceGroup", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/ImageItem", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/Spacer", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/DateField", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    
    /* J2ME RMS API */
    { "javax/microedition/rms/RecordStore", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/rms/RecordEnumeration", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreException", "java/lang/Exception", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreNotFoundException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreFullException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreNotOpenException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/InvalidRecordIDException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/RecordListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* J2ME Media API */
    { "javax/microedition/media/Manager", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/media/Player", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/PlayerImpl", "java/lang/Object", ACC_PUBLIC },  /* Concrete Player implementation */
    { "javax/microedition/media/Control", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/control/VolumeControl", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* Nokia UI/Sound API */
    { "com/nokia/mid/ui/FullCanvas", "javax/microedition/lcdui/Canvas", ACC_PUBLIC | ACC_ABSTRACT },
    { "com/nokia/mid/ui/DirectGraphics", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "com/nokia/mid/ui/DirectUtils", "java/lang/Object", ACC_PUBLIC },
    { "com/nokia/mid/sound/Sound", "java/lang/Object", ACC_PUBLIC },
    { "com/nokia/mid/sound/SoundListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* Additional java.lang wrapper classes */
    { "java/lang/Byte", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Short", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Character", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Void", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/SecurityException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/UnsupportedOperationException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/InterruptedException", "java/lang/Exception", ACC_PUBLIC },
    
    /* Additional java.util classes */
    { "java/util/Stack", "java/util/Vector", ACC_PUBLIC },
    { "java/util/Calendar", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/util/Date", "java/lang/Object", ACC_PUBLIC },
    { "java/util/TimeZone", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/util/Comparator", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/EventListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/NoSuchElementException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/util/TooManyListenersException", "java/lang/Exception", ACC_PUBLIC },
    
    /* J2ME IO (GCF - Generic Connection Framework) */
    { "javax/microedition/io/Connector", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/io/Connection", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/InputConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/OutputConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/StreamConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/StreamConnectionNotifier", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/ContentConnection", "javax/microedition/io/StreamConnection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/HttpConnection", "javax/microedition/io/ContentConnection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/HttpsConnection", "javax/microedition/io/HttpConnection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/SocketConnection", "javax/microedition/io/StreamConnection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/ServerSocketConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/DatagramConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/Datagram", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/io/PushRegistry", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/io/ConnectionNotFoundException", "java/io/IOException", ACC_PUBLIC },
    { "javax/microedition/io/SecurityInfo", "java/lang/Object", ACC_PUBLIC },
    
    /* J2ME PIM API (Personal Information Management) */
    { "javax/microedition/pim/PIM", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/pim/PIMItem", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/PIMList", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/Contact", "javax/microedition/pim/PIMItem", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/ContactList", "javax/microedition/pim/PIMList", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/Event", "javax/microedition/pim/PIMItem", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/EventList", "javax/microedition/pim/PIMList", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/ToDo", "javax/microedition/pim/PIMItem", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/ToDoList", "javax/microedition/pim/PIMList", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/pim/PIMException", "java/lang/Exception", ACC_PUBLIC },
    { "javax/microedition/pim/PIMFieldException", "javax/microedition/pim/PIMException", ACC_PUBLIC },
    { "javax/microedition/pim/UnsupportedFieldException", "javax/microedition/pim/PIMException", ACC_PUBLIC },
    
    /* J2ME Media additional controls */
    { "javax/microedition/media/control/VideoControl", "javax/microedition/media/Control", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/control/ToneControl", "javax/microedition/media/Control", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/control/MIDIControl", "javax/microedition/media/Control", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/Control", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/Controllable", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/MediaException", "java/lang/Exception", ACC_PUBLIC },
    { "javax/microedition/media/PlayerListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* J2ME LCDUI additional classes */
    { "javax/microedition/lcdui/CustomItem", "javax/microedition/lcdui/Item", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/ItemCommandListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/lcdui/ItemStateListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/lcdui/Choice", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/lcdui/Graphics$Translate", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Image$ImageData", "java/lang/Object", ACC_PUBLIC },
    
    /* J2ME Location API (JSR-179) */
    { "javax/microedition/location/Location", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/location/Coordinates", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/location/LocationProvider", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/location/LocationListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/location/Criteria", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/location/LocationException", "java/lang/Exception", ACC_PUBLIC },
    
    /* J2ME Bluetooth API (JSR-82) */
    { "javax/bluetooth/LocalDevice", "java/lang/Object", ACC_PUBLIC },
    { "javax/bluetooth/RemoteDevice", "java/lang/Object", ACC_PUBLIC },
    { "javax/bluetooth/DeviceClass", "java/lang/Object", ACC_PUBLIC },
    { "javax/bluetooth/DiscoveryAgent", "java/lang/Object", ACC_PUBLIC },
    { "javax/bluetooth/DiscoveryListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/bluetooth/ServiceRecord", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/bluetooth/UUID", "java/lang/Object", ACC_PUBLIC },
    { "javax/bluetooth/BluetoothConnectionException", "java/io/IOException", ACC_PUBLIC },
    { "javax/bluetooth/L2CAPConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/bluetooth/L2CAPConnectionNotifier", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    
    /* J2ME Wireless Messaging API (JSR-120) */
    { "javax/wireless/messaging/Message", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/wireless/messaging/TextMessage", "javax/wireless/messaging/Message", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/wireless/messaging/BinaryMessage", "javax/wireless/messaging/Message", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/wireless/messaging/MessageConnection", "javax/microedition/io/Connection", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/wireless/messaging/MessageListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* Siemens/Nokia specific extensions */
    { "com/siemens/mp/lcdui/Image", "java/lang/Object", ACC_PUBLIC },
    { "com/siemens/mp/game/Light", "java/lang/Object", ACC_PUBLIC },
    { "com/siemens/mp/game/Vibrator", "java/lang/Object", ACC_PUBLIC },
    { "com/siemens/mp/io/Connection", "java/lang/Object", ACC_PUBLIC },
    
    /* Motorola extensions */
    { "com/motorola/phone/Phone", "java/lang/Object", ACC_PUBLIC },
    { "com/motorola/phone/PhoneDisplay", "java/lang/Object", ACC_PUBLIC },
    { "com/motorola/phone/Vibrator", "java/lang/Object", ACC_PUBLIC },
    
    /* Samsung extensions */
    { "com/samsung/util/AudioClip", "java/lang/Object", ACC_PUBLIC },
    { "com/samsung/util/Vibration", "java/lang/Object", ACC_PUBLIC },
    
    { NULL, NULL, 0 }
};

/* Helper to ensure constant pool has space - only for stub classes during creation */
static void ensure_cp_capacity(JavaClass* clazz, size_t needed) {
    if (!clazz->constant_pool) {
        clazz->constant_pool_capacity = 64;
        clazz->constant_pool = (ConstantPoolEntry*)calloc(clazz->constant_pool_capacity, sizeof(ConstantPoolEntry));
        clazz->constant_pool_count = 1;  /* Index 0 unused */
    }
    
    if (clazz->constant_pool_count + needed >= clazz->constant_pool_capacity) {
        /* For stub classes, pre-allocate enough space */
        size_t new_cap = clazz->constant_pool_capacity + needed + 32;
        ConstantPoolEntry* new_pool = (ConstantPoolEntry*)calloc(new_cap, sizeof(ConstantPoolEntry));
        if (!new_pool) return;  /* Out of memory */
        
        /* Copy old entries */
        memcpy(new_pool, clazz->constant_pool, 
               clazz->constant_pool_count * sizeof(ConstantPoolEntry));
        
        free(clazz->constant_pool);
        clazz->constant_pool = new_pool;
        clazz->constant_pool_capacity = new_cap;
    }
}

/* Create a minimal constant pool entry for UTF8 */
static uint16_t add_utf8(JavaClass* clazz, const char* str) {
    if (!str) return 0;
    
    size_t len = strlen(str);
    
    /* Check if already exists */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        if (clazz->constant_pool[i].tag == CONSTANT_Utf8 &&
            clazz->constant_pool[i].info.utf8.length == len &&
            clazz->constant_pool[i].info.utf8.bytes &&
            memcmp(clazz->constant_pool[i].info.utf8.bytes, str, len) == 0) {
            return i;
        }
    }
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Utf8;
    clazz->constant_pool[index].info.utf8.length = (uint16_t)len;
    clazz->constant_pool[index].info.utf8.bytes = strdup(str);
    
    return index;
}

/* Create a minimal constant pool entry for Class */
static uint16_t add_class_ref(JavaClass* clazz, const char* name) {
    if (!name) return 0;
    
    uint16_t name_index = add_utf8(clazz, name);
    
    /* Check if already exists */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        if (clazz->constant_pool[i].tag == CONSTANT_Class &&
            clazz->constant_pool[i].info.class_info.name_index == name_index) {
            return i;
        }
    }
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Class;
    clazz->constant_pool[index].info.class_info.name_index = name_index;
    
    return index;
}

/* Create a NameAndType constant */
static uint16_t add_name_and_type(JavaClass* clazz, const char* name, const char* descriptor) {
    if (!name || !descriptor) return 0;
    
    uint16_t name_index = add_utf8(clazz, name);
    uint16_t descriptor_index = add_utf8(clazz, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_NameAndType;
    clazz->constant_pool[index].info.name_and_type.name_index = name_index;
    clazz->constant_pool[index].info.name_and_type.descriptor_index = descriptor_index;
    
    return index;
}

/* Create a Methodref constant */
static uint16_t add_method_ref(JavaClass* clazz, const char* class_name,
                               const char* name, const char* descriptor) {
    if (!class_name || !name || !descriptor) return 0;
    
    uint16_t class_index = add_class_ref(clazz, class_name);
    uint16_t name_and_type_index = add_name_and_type(clazz, name, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Methodref;
    clazz->constant_pool[index].info.ref_info.class_index = class_index;
    clazz->constant_pool[index].info.ref_info.name_and_type_index = name_and_type_index;
    
    return index;
}

/* Create a Fieldref constant */
static uint16_t add_field_ref(JavaClass* clazz, const char* class_name,
                              const char* name, const char* descriptor) {
    if (!class_name || !name || !descriptor) return 0;
    
    uint16_t class_index = add_class_ref(clazz, class_name);
    uint16_t name_and_type_index = add_name_and_type(clazz, name, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Fieldref;
    clazz->constant_pool[index].info.ref_info.class_index = class_index;
    clazz->constant_pool[index].info.ref_info.name_and_type_index = name_and_type_index;
    
    return index;
}

/* Ensure methods array has space */
static void ensure_methods_capacity(JavaClass* clazz) {
    if (!clazz->methods) {
        clazz->methods_capacity = 8;
        clazz->methods = (JavaMethod*)calloc(clazz->methods_capacity, sizeof(JavaMethod));
        clazz->methods_count = 0;
    }
    
    if (clazz->methods_count >= clazz->methods_capacity) {
        int new_cap = clazz->methods_capacity * 2;
        JavaMethod* new_methods = (JavaMethod*)calloc(new_cap, sizeof(JavaMethod));
        if (!new_methods) return;  /* Out of memory */
        
        /* Copy old entries */
        memcpy(new_methods, clazz->methods, 
               clazz->methods_count * sizeof(JavaMethod));
        
        free(clazz->methods);
        clazz->methods = new_methods;
        clazz->methods_capacity = new_cap;
    }
}

/* Create a stub method - returns index in methods array */
static int create_stub_method(JavaClass* clazz, const char* name,
                              const char* descriptor, uint16_t access_flags,
                              const uint8_t* code, uint32_t code_len) {
    if (!name || !descriptor) return -1;
    
    ensure_methods_capacity(clazz);
    
    int idx = clazz->methods_count++;
    JavaMethod* method = &clazz->methods[idx];
    
    memset(method, 0, sizeof(JavaMethod));
    
    method->name = strdup(name);
    method->descriptor = strdup(descriptor);
    method->name_index = add_utf8(clazz, name);
    method->descriptor_index = add_utf8(clazz, descriptor);
    method->access_flags = access_flags;
    method->attributes_count = 0;
    method->clazz = clazz;
    
    /* Create Code attribute if not abstract/native and code provided */
    if (!(access_flags & (ACC_ABSTRACT | ACC_NATIVE))) {
        /* === FIX: Calculate max_locals correctly === */
        int arg_slots = count_args(descriptor);
        int is_static = (access_flags & ACC_STATIC) != 0;
        
        /* Instance methods need 'this' + args. Static methods need just args. */
        method->code.max_locals = arg_slots + (is_static ? 0 : 1);
        
        method->code.max_stack = 2; /* Simple stub code usually doesn't need deep stack */
        method->code.code_length = code_len;
        method->code.code = (uint8_t*)malloc(code_len);
        if (method->code.code) {
            memcpy(method->code.code, code, code_len);
        }
    }
    
    return idx;
}

/* Create a stub class */
static JavaClass* create_stub_class(JVM* jvm, const char* name, const char* super_name, uint16_t access_flags) {
    if (!name) return NULL;
    
    JavaClass* clazz = (JavaClass*)calloc(1, sizeof(JavaClass));
    if (!clazz) return NULL;
    
    clazz->class_name = strdup(name);
    clazz->access_flags = access_flags;
    clazz->major_version = 47; /* JDK 1.3 */
    clazz->minor_version = 0;
    clazz->magic = 0xCAFEBABE;
    
    /* Initialize constant pool with space check */
    ensure_cp_capacity(clazz, 4);  /* Pre-allocate space for basic entries */
    
    /* Add this class */
    clazz->this_class = add_class_ref(clazz, name);
    
    /* Add super class */
    if (super_name) {
        clazz->super_class_index = add_class_ref(clazz, super_name);
        clazz->super_class_name = strdup(super_name);
    }
    
    /* Allocate methods array */
    ensure_methods_capacity(clazz);
    
    /* 
     * Add default constructor.
     * Constructors are needed for:
     * 1. Concrete classes (normal instantiation).
     * 2. Abstract classes (subclasses call super()).
     * Constructors are NOT needed for:
     * 1. Interfaces.
     * 2. System classes that should only be created via native factories (Image, etc).
     */
    bool add_constructor = !(access_flags & ACC_INTERFACE);
    
    /* List of classes that must NOT have a public constructor generated */
    if (strcmp(name, "javax/microedition/lcdui/Image") == 0 ||
        strcmp(name, "javax/microedition/lcdui/Graphics") == 0 ||
        strcmp(name, "javax/microedition/lcdui/Font") == 0 ||
        strcmp(name, "javax/microedition/lcdui/Display") == 0) {
        add_constructor = false;
    }
    
    /* Special case for String: needs multiple constructors */
    if (strcmp(name, "java/lang/String") == 0) {
        /* String() - empty string */
        uint8_t init_empty[1];
        init_empty[0] = 0xB1; /* return */
        create_stub_method(clazz, "<init>", "()V", ACC_PUBLIC, init_empty, 1);
        
        /* String(char[]) - from char array */
        uint8_t init_chars[5];
        init_chars[0] = 0x2A; /* aload_0 */
        init_chars[1] = 0xB7; /* invokespecial */
        init_chars[2] = 0x00; /* super index (will be fixed) */
        init_chars[3] = 0x01;
        init_chars[4] = 0xB1; /* return */
        create_stub_method(clazz, "<init>", "([C)V", ACC_PUBLIC, init_chars, 5);
        
        /* String(byte[]) - from byte array */
        create_stub_method(clazz, "<init>", "([B)V", ACC_PUBLIC, init_chars, 5);
        
        /* String(String) - copy constructor */
        create_stub_method(clazz, "<init>", "(Ljava/lang/String;)V", ACC_PUBLIC, init_chars, 5);
        
        /* String(StringBuffer) - from StringBuffer */
        create_stub_method(clazz, "<init>", "(Ljava/lang/StringBuffer;)V", ACC_PUBLIC, init_chars, 5);
        
        /* String(char[], int, int) - from char array with offset */
        create_stub_method(clazz, "<init>", "([CII)V", ACC_PUBLIC, init_chars, 5);
        
        /* String(byte[], int, int) - from byte array with offset */
        create_stub_method(clazz, "<init>", "([BII)V", ACC_PUBLIC, init_chars, 5);
    }
    
    if (add_constructor) {
        /* 
         * CRITICAL FIX: If this is java/lang/Object, the constructor must not call super.
         * It should just return.
         */
        if (super_name == NULL) {
            /* java/lang/Object constructor: just return */
            uint8_t init_code[1];
            init_code[0] = 0xB1; /* return */
            create_stub_method(clazz, "<init>", "()V", ACC_PUBLIC, init_code, 1);
        } else {
            /* Subclass constructor: aload_0, invokespecial super.<init>, return */
            const char* super = super_name;
            uint16_t super_init_ref = add_method_ref(clazz, super, "<init>", "()V");
            
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "()V", ACC_PUBLIC, init_code, 5);
        }
        
        /* Special case for GameCanvas: it needs a constructor (boolean) */
        if (strcmp(name, "javax/microedition/lcdui/game/GameCanvas") == 0) {
            /* public GameCanvas(boolean suppressKeyEvents) */
            /* Code: aload_0, invokespecial super.<init>(), return */
            /* The boolean argument is simply ignored in the stub. */
            
            uint16_t super_init_ref = add_method_ref(clazz, "javax/microedition/lcdui/Canvas", "<init>", "()V");
            
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            /* Descriptor (Z)V means takes boolean, returns void */
            create_stub_method(clazz, "<init>", "(Z)V", ACC_PUBLIC, init_code, 5);
        }
        
        /* Special case for List: needs constructor (String, int, String[], Image[]) */
        if (strcmp(name, "javax/microedition/lcdui/List") == 0) {
            /* public List(String title, int listType, String[] stringElements, Image[] imageElements) */
            /* Code: aload_0, invokespecial super.<init>(), return */
            /* The actual initialization is handled by native handler */
            
            uint16_t super_init_ref = add_method_ref(clazz, "javax/microedition/lcdui/Screen", "<init>", "()V");
            
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            /* Constructor: List(String title, int listType, String[] stringElements, Image[] imageElements) */
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;I[Ljava/lang/String;[Ljavax/microedition/lcdui/Image;)V", ACC_PUBLIC, init_code, 5);
        }
        
        /* Special case for Thread: needs constructors with name and runnable */
        if (strcmp(name, "java/lang/Thread") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/lang/Object", "<init>", "()V");
            
            /* Thread(String name) */
            uint8_t init_string_code[5];
            init_string_code[0] = 0x2A; /* aload_0 */
            init_string_code[1] = 0xB7; /* invokespecial */
            init_string_code[2] = (super_init_ref >> 8) & 0xFF;
            init_string_code[3] = super_init_ref & 0xFF;
            init_string_code[4] = 0xB1; /* return */
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;)V", ACC_PUBLIC, init_string_code, 5);
            
            /* Thread(Runnable target, String name) */
            uint8_t init_runnable_string_code[5];
            init_runnable_string_code[0] = 0x2A; /* aload_0 */
            init_runnable_string_code[1] = 0xB7; /* invokespecial */
            init_runnable_string_code[2] = (super_init_ref >> 8) & 0xFF;
            init_runnable_string_code[3] = super_init_ref & 0xFF;
            init_runnable_string_code[4] = 0xB1; /* return */
            create_stub_method(clazz, "<init>", "(Ljava/lang/Runnable;Ljava/lang/String;)V", ACC_PUBLIC, init_runnable_string_code, 5);
            
            /* Thread(Runnable target) - already has native handler, but add stub too */
            uint8_t init_runnable_code[5];
            init_runnable_code[0] = 0x2A; /* aload_0 */
            init_runnable_code[1] = 0xB7; /* invokespecial */
            init_runnable_code[2] = (super_init_ref >> 8) & 0xFF;
            init_runnable_code[3] = super_init_ref & 0xFF;
            init_runnable_code[4] = 0xB1; /* return */
            create_stub_method(clazz, "<init>", "(Ljava/lang/Runnable;)V", ACC_PUBLIC, init_runnable_code, 5);
        }
        
        /* Special case for Nokia Sound: needs default constructor () and constructor ([BI) */
        if (strcmp(name, "com/nokia/mid/sound/Sound") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/lang/Object", "<init>", "()V");
            
            /* Default constructor ()V - already added above, but we also need constructor with params */
            
            /* Constructor: Sound(byte[] data, int type) */
            uint8_t init_bytes_int_code[5];
            init_bytes_int_code[0] = 0x2A; /* aload_0 */
            init_bytes_int_code[1] = 0xB7; /* invokespecial */
            init_bytes_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_bytes_int_code[3] = super_init_ref & 0xFF;
            init_bytes_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "([BI)V", ACC_PUBLIC, init_bytes_int_code, 5);
            
            /* Constructor: Sound(byte[] data) - only data, no type */
            uint8_t init_bytes_code[5];
            init_bytes_code[0] = 0x2A; /* aload_0 */
            init_bytes_code[1] = 0xB7; /* invokespecial */
            init_bytes_code[2] = (super_init_ref >> 8) & 0xFF;
            init_bytes_code[3] = super_init_ref & 0xFF;
            init_bytes_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "([B)V", ACC_PUBLIC, init_bytes_code, 5);
            
            /* Constructor: Sound(byte[] data, int type, int frames) */
            uint8_t init_bytes_int_int_code[5];
            init_bytes_int_int_code[0] = 0x2A; /* aload_0 */
            init_bytes_int_int_code[1] = 0xB7; /* invokespecial */
            init_bytes_int_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_bytes_int_int_code[3] = super_init_ref & 0xFF;
            init_bytes_int_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "([BII)V", ACC_PUBLIC, init_bytes_int_int_code, 5);
            
            /* Constructor: Sound(int type, long data) - for tone sounds */
            uint8_t init_int_long_code[5];
            init_int_long_code[0] = 0x2A; /* aload_0 */
            init_int_long_code[1] = 0xB7; /* invokespecial */
            init_int_long_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_long_code[3] = super_init_ref & 0xFF;
            init_int_long_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(IJ)V", ACC_PUBLIC, init_int_long_code, 5);
            
            /* Constructor: Sound(int type, double data) - alternative */
            create_stub_method(clazz, "<init>", "(ID)V", ACC_PUBLIC, init_int_long_code, 5);
            
            /* Constructor: Sound(int) - just type */
            uint8_t init_int_code[5];
            init_int_code[0] = 0x2A; /* aload_0 */
            init_int_code[1] = 0xB7; /* invokespecial */
            init_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_code[3] = super_init_ref & 0xFF;
            init_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(I)V", ACC_PUBLIC, init_int_code, 5);
        }
        
        /* Special case for ByteArrayInputStream: needs constructor (byte[]) */
        if (strcmp(name, "java/io/ByteArrayInputStream") == 0) {
            /* public ByteArrayInputStream(byte[] buf)
             * Code: aload_0, invokespecial super.<init>(), aload_0, aload_1, putfield buf, 
             *       aload_0, aload_1.arraylength, putfield count, return
             * But simplified: just call super and the native handler will set fields
             */
            uint16_t super_init_ref = add_method_ref(clazz, "java/io/InputStream", "<init>", "()V");
            
            /* We need to add field reference for buf field - but since this is stub,
             * the native code will handle initialization. Just create minimal constructor. */
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "([B)V", ACC_PUBLIC, init_code, 5);
            
            /* Also add constructor with offset and length: (byte[], int, int) */
            uint8_t init_code_3[5];
            init_code_3[0] = 0x2A; /* aload_0 */
            init_code_3[1] = 0xB7; /* invokespecial */
            init_code_3[2] = (super_init_ref >> 8) & 0xFF;
            init_code_3[3] = super_init_ref & 0xFF;
            init_code_3[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "([BII)V", ACC_PUBLIC, init_code_3, 5);
        }
        
        /* Special case for ByteArrayOutputStream: needs default constructor */
        if (strcmp(name, "java/io/ByteArrayOutputStream") == 0) {
            /* Default constructor already added, but native handler initializes buffer */
        }
        
        /* Special case for Vector: needs constructors (int), (int, int) */
        if (strcmp(name, "java/util/Vector") == 0) {
            /* Constructor: Vector(int initialCapacity) */
            uint16_t super_init_ref = add_method_ref(clazz, "java/lang/Object", "<init>", "()V");
            
            uint8_t init_int_code[5];
            init_int_code[0] = 0x2A; /* aload_0 */
            init_int_code[1] = 0xB7; /* invokespecial */
            init_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_code[3] = super_init_ref & 0xFF;
            init_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(I)V", ACC_PUBLIC, init_int_code, 5);
            
            /* Constructor: Vector(int initialCapacity, int capacityIncrement) */
            uint8_t init_int_int_code[5];
            init_int_int_code[0] = 0x2A; /* aload_0 */
            init_int_int_code[1] = 0xB7; /* invokespecial */
            init_int_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_int_code[3] = super_init_ref & 0xFF;
            init_int_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(II)V", ACC_PUBLIC, init_int_int_code, 5);
        }
        
        /* Special case for Hashtable: needs constructor (int), (int, float) */
        if (strcmp(name, "java/util/Hashtable") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/lang/Object", "<init>", "()V");
            
            /* Constructor: Hashtable(int initialCapacity) */
            uint8_t init_int_code[5];
            init_int_code[0] = 0x2A; /* aload_0 */
            init_int_code[1] = 0xB7; /* invokespecial */
            init_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_code[3] = super_init_ref & 0xFF;
            init_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(I)V", ACC_PUBLIC, init_int_code, 5);
            
            /* Constructor: Hashtable(int initialCapacity, float loadFactor) */
            uint8_t init_int_float_code[5];
            init_int_float_code[0] = 0x2A; /* aload_0 */
            init_int_float_code[1] = 0xB7; /* invokespecial */
            init_int_float_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_float_code[3] = super_init_ref & 0xFF;
            init_int_float_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(IF)V", ACC_PUBLIC, init_int_float_code, 5);
        }
        
        /* Special case for StringBuffer: needs constructor (int) for capacity */
        if (strcmp(name, "java/lang/StringBuffer") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/lang/Object", "<init>", "()V");
            
            /* Constructor: StringBuffer(int capacity) */
            uint8_t init_int_code[5];
            init_int_code[0] = 0x2A; /* aload_0 */
            init_int_code[1] = 0xB7; /* invokespecial */
            init_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_code[3] = super_init_ref & 0xFF;
            init_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(I)V", ACC_PUBLIC, init_int_code, 5);
            
            /* Constructor: StringBuffer(String str) */
            uint8_t init_string_code[5];
            init_string_code[0] = 0x2A; /* aload_0 */
            init_string_code[1] = 0xB7; /* invokespecial */
            init_string_code[2] = (super_init_ref >> 8) & 0xFF;
            init_string_code[3] = super_init_ref & 0xFF;
            init_string_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;)V", ACC_PUBLIC, init_string_code, 5);
        }
        
        /* Special case for StringBuilder: needs constructor (int) for capacity */
        if (strcmp(name, "java/lang/StringBuilder") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/lang/Object", "<init>", "()V");
            
            /* Constructor: StringBuilder(int capacity) */
            uint8_t init_int_code[5];
            init_int_code[0] = 0x2A; /* aload_0 */
            init_int_code[1] = 0xB7; /* invokespecial */
            init_int_code[2] = (super_init_ref >> 8) & 0xFF;
            init_int_code[3] = super_init_ref & 0xFF;
            init_int_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(I)V", ACC_PUBLIC, init_int_code, 5);
            
            /* Constructor: StringBuilder(String str) */
            uint8_t init_string_code[5];
            init_string_code[0] = 0x2A; /* aload_0 */
            init_string_code[1] = 0xB7; /* invokespecial */
            init_string_code[2] = (super_init_ref >> 8) & 0xFF;
            init_string_code[3] = super_init_ref & 0xFF;
            init_string_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;)V", ACC_PUBLIC, init_string_code, 5);
        }
        
        /* Special case for DataInputStream: needs constructor (InputStream) */
        if (strcmp(name, "java/io/DataInputStream") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/io/InputStream", "<init>", "()V");
            
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/io/InputStream;)V", ACC_PUBLIC, init_code, 5);
        }
        
        /* Special case for InputStreamReader: needs constructor (InputStream) */
        if (strcmp(name, "java/io/InputStreamReader") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/io/Reader", "<init>", "()V");
            uint16_t in_field_ref = add_field_ref(clazz, "java/io/InputStreamReader", "in", "Ljava/io/InputStream;");
            
            /* Constructor: InputStreamReader(InputStream)
             * Code: aload_0, aload_1, putfield in, aload_0, invokespecial Reader.<init>, return
             */
            uint8_t init_code[10];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0x2B; /* aload_1 (InputStream) */
            init_code[2] = 0xB5; /* putfield */
            init_code[3] = (in_field_ref >> 8) & 0xFF;
            init_code[4] = in_field_ref & 0xFF;
            init_code[5] = 0x2A; /* aload_0 */
            init_code[6] = 0xB7; /* invokespecial */
            init_code[7] = (super_init_ref >> 8) & 0xFF;
            init_code[8] = super_init_ref & 0xFF;
            init_code[9] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/io/InputStream;)V", ACC_PUBLIC, init_code, 10);
            
            /* Constructor with encoding: InputStreamReader(InputStream, String) - same logic, ignore String */
            create_stub_method(clazz, "<init>", "(Ljava/io/InputStream;Ljava/lang/String;)V", ACC_PUBLIC, init_code, 10);
        }
        
        /* Special case for BufferedReader: needs constructor (Reader) */
        if (strcmp(name, "java/io/BufferedReader") == 0) {
            uint16_t super_init_ref = add_method_ref(clazz, "java/io/Reader", "<init>", "()V");
            uint16_t in_field_ref = add_field_ref(clazz, "java/io/BufferedReader", "in", "Ljava/io/Reader;");
            
            /* Constructor: BufferedReader(Reader)
             * Code: aload_0, aload_1, putfield in, aload_0, invokespecial Reader.<init>, return
             */
            uint8_t init_code[10];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0x2B; /* aload_1 (Reader) */
            init_code[2] = 0xB5; /* putfield */
            init_code[3] = (in_field_ref >> 8) & 0xFF;
            init_code[4] = in_field_ref & 0xFF;
            init_code[5] = 0x2A; /* aload_0 */
            init_code[6] = 0xB7; /* invokespecial */
            init_code[7] = (super_init_ref >> 8) & 0xFF;
            init_code[8] = super_init_ref & 0xFF;
            init_code[9] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/io/Reader;)V", ACC_PUBLIC, init_code, 10);
            create_stub_method(clazz, "<init>", "(Ljava/io/Reader;I)V", ACC_PUBLIC, init_code, 10);
        }
        
        /* Для классов исключений добавляем конструктор с сообщением */
        if (strstr(name, "Exception") || strstr(name, "Error")) {
            /* Конструктор с сообщением: super(msg) */
            uint16_t super_init_msg_ref = add_method_ref(clazz, super_name, "<init>", "(Ljava/lang/String;)V");
            
            uint8_t init_msg_code[6];
            init_msg_code[0] = 0x2A; /* aload_0 */
            init_msg_code[1] = 0x2B; /* aload_1 (загружаем сообщение) */
            init_msg_code[2] = 0xB7; /* invokespecial */
            init_msg_code[3] = (super_init_msg_ref >> 8) & 0xFF;
            init_msg_code[4] = super_init_msg_ref & 0xFF;
            init_msg_code[5] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;)V", ACC_PUBLIC, init_msg_code, 6);
            
            /* Конструктор с сообщением и причиной (Throwable) */
            uint16_t super_init_msg_throw_ref = add_method_ref(clazz, super_name, "<init>", "(Ljava/lang/String;Ljava/lang/Throwable;)V");
            
            uint8_t init_msg_throw_code[8];
            init_msg_throw_code[0] = 0x2A; /* aload_0 */
            init_msg_throw_code[1] = 0x2B; /* aload_1 (сообщение) */
            init_msg_throw_code[2] = 0x2C; /* aload_2 (причина) */
            init_msg_throw_code[3] = 0xB7; /* invokespecial */
            init_msg_throw_code[4] = (super_init_msg_throw_ref >> 8) & 0xFF;
            init_msg_throw_code[5] = super_init_msg_throw_ref & 0xFF;
            init_msg_throw_code[6] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;Ljava/lang/Throwable;)V", 
                              ACC_PUBLIC, init_msg_throw_code, 7);
        }
    }
    
    /* Mark as stub */
    clazz->is_stub = true;
    clazz->initialized = false;
    clazz->initializing = false;
    clazz->static_fields = NULL;
    clazz->static_fields_count = 0;
    clazz->static_fields_capacity = 0;
    
    return clazz;
}

/* Initialize built-in stub classes */
int init_stub_classes(JVM* jvm) {
    if (!jvm) return 0;
    
    int count = 0;
    
    /* ===== ПЕРВЫЙ ПРОХОД: Создаем все классы ===== */
    for (int i = 0; stub_classes[i].name != NULL; i++) {
        /* Check if already loaded */
        bool found = false;
        for (size_t j = 0; j < jvm->class_loader.count; j++) {
            if (jvm->class_loader.classes[j]->class_name &&
                strcmp(jvm->class_loader.classes[j]->class_name, stub_classes[i].name) == 0) {
                found = true;
                break;
            }
        }
        
        if (found) continue;
        
        JavaClass* stub = create_stub_class(jvm, stub_classes[i].name,
                                           stub_classes[i].super, stub_classes[i].flags);
        if (!stub) {
            CLASS_DEBUG(" Failed to create stub class: %s", stub_classes[i].name);
            continue;
        }
        
        /* Ensure class_loader has capacity */
        if (jvm->class_loader.count >= jvm->class_loader.capacity) {
            size_t new_cap = jvm->class_loader.capacity ? jvm->class_loader.capacity * 2 : 32;
            jvm->class_loader.classes = (JavaClass**)realloc(jvm->class_loader.classes,
                                   new_cap * sizeof(JavaClass*));
            if (jvm->class_loader.classes) {
                jvm->class_loader.capacity = new_cap;
            } else {
                free(stub);
                continue;
            }
        }
        
        jvm->class_loader.classes[jvm->class_loader.count++] = stub;
        count++;
        
        if (jvm->config.verbose_class) {
            CLASS_DEBUG(" Created stub class: %s", stub_classes[i].name);
        }
    }
    
    /* ===== ВТОРОЙ ПРОХОД: Разрешаем ссылки на суперклассы ===== */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
            /* Find super class in loaded classes */
            for (size_t j = 0; j < jvm->class_loader.count; j++) {
                if (jvm->class_loader.classes[j]->class_name &&
                    strcmp(jvm->class_loader.classes[j]->class_name, clazz->super_class_name) == 0) {
                    clazz->super_class = jvm->class_loader.classes[j];
                    if (jvm->config.verbose_class) {
                        CLASS_DEBUG(" Resolved %s -> super: %s", 
                                clazz->class_name, clazz->super_class->class_name);
                    }
                    break;
                }
            }
        }
    }
    
    /* ===== ТРЕТИЙ ПРОХОД: Добавляем поля к классам ===== */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (!clazz->class_name) continue;
        
        /* java.lang.System - статические поля */
        if (strcmp(clazz->class_name, "java/lang/System") == 0) {
            /* Создаем массив статических полей */
            static const char* sys_static_fields[][2] = {
                {"out", "Ljava/io/PrintStream;"},
                {"err", "Ljava/io/PrintStream;"},
                {"in", "Ljava/io/InputStream;"},
                {NULL, NULL}
            };
            
            int static_count = 0;
            while (sys_static_fields[static_count][0] != NULL) static_count++;
            
            clazz->static_fields = (JavaStaticField*)calloc(static_count, sizeof(JavaStaticField));
            clazz->static_fields_count = static_count;
            clazz->static_fields_capacity = static_count;
            
            for (int j = 0; j < static_count; j++) {
                clazz->static_fields[j].name = strdup(sys_static_fields[j][0]);
                clazz->static_fields[j].descriptor = strdup(sys_static_fields[j][1]);
                memset(&clazz->static_fields[j].value, 0, sizeof(JavaValue));
            }
            
            CLASS_DEBUG(" System class: added %d static fields", static_count);
        }
        
        /* java.lang.Integer needs value field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Integer") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("value");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].name_index = add_utf8(clazz, "value");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added value field to java/lang/Integer\n");
        }
        
        /* java.lang.Long needs value field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Long") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("value");
                clazz->fields[0].descriptor = strdup("J");  /* long */
                clazz->fields[0].name_index = add_utf8(clazz, "value");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            CLASS_DEBUG(" Added value field to java/lang/Long\n");
        }
        
        /* java.lang.Boolean needs value field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Boolean") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("value");
                clazz->fields[0].descriptor = strdup("Z");
                clazz->fields[0].name_index = add_utf8(clazz, "value");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Z");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added value field to java/lang/Boolean\n");
        }
        
        /* java.util.Random needs a seed field (long = 64-bit = 2 slots) */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/util/Random") == 0 && clazz->fields_count == 0) {
            /* Allocate fields array */
            clazz->fields_count = 1;  /* One field: seed (long) */
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("seed");
                clazz->fields[0].descriptor = strdup("J");  /* long */
                clazz->fields[0].name_index = add_utf8(clazz, "seed");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            CLASS_DEBUG(" Added seed field to java/util/Random\n");
        }
        
        /* java.lang.StringBuffer needs buffer and length fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/StringBuffer") == 0 && clazz->fields_count == 0) {
            /* Allocate fields array: [0] = buffer pointer, [1] = length */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buffer pointer (stored as reference) */
                clazz->fields[0].name = strdup("buffer");
                clazz->fields[0].descriptor = strdup("Ljava/lang/Object;");
                clazz->fields[0].name_index = add_utf8(clazz, "buffer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/Object;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: length (int) */
                clazz->fields[1].name = strdup("count");
                clazz->fields[1].descriptor = strdup("I");  /* int */
                clazz->fields[1].name_index = add_utf8(clazz, "count");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two JavaValue slots */
            }
            CLASS_DEBUG(" Added buffer/count fields to java/lang/StringBuffer\n");
        }
        
        /* javax.microedition.lcdui.Image needs native pointer field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Image") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            CLASS_DEBUG(" Added nativePeer field to javax/microedition/lcdui/Image\n");
        }
        
        /* javax.microedition.lcdui.Graphics needs native pointer field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Graphics") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            CLASS_DEBUG(" Added nativePeer field to javax/microedition/lcdui/Graphics\n");
        }
        
        /* javax.microedition.lcdui.Font needs native pointer field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Font") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            CLASS_DEBUG(" Added nativePeer field to javax/microedition/lcdui/Font\n");
        }
        
        /* javax.microedition.lcdui.game.Layer - abstract base class with x, y, width, height, visible */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/game/Layer") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 5;
            clazz->fields = (JavaField*)calloc(5, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: x (int) */
                clazz->fields[0].name = strdup("x");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].name_index = add_utf8(clazz, "x");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: y (int) */
                clazz->fields[1].name = strdup("y");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "y");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                /* Field 2: width (int) */
                clazz->fields[2].name = strdup("width");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "width");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                /* Field 3: height (int) */
                clazz->fields[3].name = strdup("height");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "height");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                /* Field 4: visible (boolean) */
                clazz->fields[4].name = strdup("visible");
                clazz->fields[4].descriptor = strdup("Z");
                clazz->fields[4].name_index = add_utf8(clazz, "visible");
                clazz->fields[4].descriptor_index = add_utf8(clazz, "Z");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 5;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/game/Layer\n");
        }
        
        /* javax.microedition.lcdui.game.Sprite - extends Layer, adds image, frameWidth, frameHeight, currentFrame */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/game/Sprite") == 0) {
            /* Sprite inherits Layer's 5 fields + adds 4 more */
            clazz->fields_count = 9;
            clazz->fields = (JavaField*)calloc(9, sizeof(JavaField));
            if (clazz->fields) {
                /* Inherited from Layer: x, y, width, height, visible (fields 0-4) */
                clazz->fields[0].name = strdup("x");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("y");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("width");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("height");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->fields[4].name = strdup("visible");
                clazz->fields[4].descriptor = strdup("Z");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                /* Sprite-specific fields */
                /* Field 5: image (Image) */
                clazz->fields[5].name = strdup("image");
                clazz->fields[5].descriptor = strdup("Ljavax/microedition/lcdui/Image;");
                clazz->fields[5].name_index = add_utf8(clazz, "image");
                clazz->fields[5].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/Image;");
                clazz->fields[5].access_flags = ACC_PRIVATE;
                
                /* Field 6: frameWidth (int) */
                clazz->fields[6].name = strdup("frameWidth");
                clazz->fields[6].descriptor = strdup("I");
                clazz->fields[6].name_index = add_utf8(clazz, "frameWidth");
                clazz->fields[6].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[6].access_flags = ACC_PRIVATE;
                
                /* Field 7: frameHeight (int) */
                clazz->fields[7].name = strdup("frameHeight");
                clazz->fields[7].descriptor = strdup("I");
                clazz->fields[7].name_index = add_utf8(clazz, "frameHeight");
                clazz->fields[7].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[7].access_flags = ACC_PRIVATE;
                
                /* Field 8: currentFrame (int) */
                clazz->fields[8].name = strdup("currentFrame");
                clazz->fields[8].descriptor = strdup("I");
                clazz->fields[8].name_index = add_utf8(clazz, "currentFrame");
                clazz->fields[8].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[8].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 9;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/game/Sprite\n");
        }
        
        /* javax.microedition.lcdui.game.TiledLayer - extends Layer */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/game/TiledLayer") == 0) {
            /* TiledLayer inherits Layer's 5 fields + adds own fields:
             * columns, rows, image, tileWidth, tileHeight, 
             * cellMap (int[]), animatedTiles (int[]), animatedTileCount */
            clazz->fields_count = 13;
            clazz->fields = (JavaField*)calloc(13, sizeof(JavaField));
            if (clazz->fields) {
                /* Inherited from Layer: x, y, width, height, visible (fields 0-4) */
                clazz->fields[0].name = strdup("x");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("y");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("width");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("height");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->fields[4].name = strdup("visible");
                clazz->fields[4].descriptor = strdup("Z");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                /* TiledLayer-specific fields */
                clazz->fields[5].name = strdup("columns");
                clazz->fields[5].descriptor = strdup("I");
                clazz->fields[5].access_flags = ACC_PRIVATE;
                
                clazz->fields[6].name = strdup("rows");
                clazz->fields[6].descriptor = strdup("I");
                clazz->fields[6].access_flags = ACC_PRIVATE;
                
                clazz->fields[7].name = strdup("image");
                clazz->fields[7].descriptor = strdup("Ljavax/microedition/lcdui/Image;");
                clazz->fields[7].access_flags = ACC_PRIVATE;
                
                clazz->fields[8].name = strdup("tileWidth");
                clazz->fields[8].descriptor = strdup("I");
                clazz->fields[8].access_flags = ACC_PRIVATE;
                
                clazz->fields[9].name = strdup("tileHeight");
                clazz->fields[9].descriptor = strdup("I");
                clazz->fields[9].access_flags = ACC_PRIVATE;
                
                /* Cell map: int[] storing tile index for each cell */
                clazz->fields[10].name = strdup("cellMap");
                clazz->fields[10].descriptor = strdup("[I");
                clazz->fields[10].access_flags = ACC_PRIVATE;
                
                /* Animated tiles: int[] mapping animated tile index -> static tile index */
                clazz->fields[11].name = strdup("animatedTiles");
                clazz->fields[11].descriptor = strdup("[I");
                clazz->fields[11].access_flags = ACC_PRIVATE;
                
                /* Number of animated tiles created */
                clazz->fields[12].name = strdup("animatedTileCount");
                clazz->fields[12].descriptor = strdup("I");
                clazz->fields[12].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 13;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/game/TiledLayer\n");
        }
        
        /* javax.microedition.lcdui.game.LayerManager */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/game/LayerManager") == 0) {
            /* LayerManager needs: layers array, viewX, viewY, viewWidth, viewHeight */
            clazz->fields_count = 5;
            clazz->fields = (JavaField*)calloc(5, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("viewX");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("viewY");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("viewWidth");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("viewHeight");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->fields[4].name = strdup("layerCount");
                clazz->fields[4].descriptor = strdup("I");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 5;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/game/LayerManager\n");
        }
        
        /* java.lang.Thread needs target, name, priority fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Thread") == 0) {
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: target (Runnable) */
                clazz->fields[0].name = strdup("target");
                clazz->fields[0].descriptor = strdup("Ljava/lang/Runnable;");
                clazz->fields[0].name_index = add_utf8(clazz, "target");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/Runnable;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: name (String) */
                clazz->fields[1].name = strdup("name");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "name");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                /* Field 2: priority (int) */
                clazz->fields[2].name = strdup("priority");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "priority");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 3;
            }
            CLASS_DEBUG(" Added target/name/priority fields to java/lang/Thread\n");
        }
        
        /* java.io.ByteArrayInputStream needs buffer and position fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/ByteArrayInputStream") == 0) {
            /* Fields: [0] = buf (byte[]), [1] = pos (int), [2] = count (int) */
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buf (byte[]) */
                clazz->fields[0].name = strdup("buf");
                clazz->fields[0].descriptor = strdup("[B");  /* byte array */
                clazz->fields[0].name_index = add_utf8(clazz, "buf");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[B");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                /* Field 1: pos (int) */
                clazz->fields[1].name = strdup("pos");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "pos");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PROTECTED;

                /* Field 2: count (int) */
                clazz->fields[2].name = strdup("count");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "count");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 3;  /* Three JavaValue slots */
            }
            CLASS_DEBUG(" Added buf/pos/count fields to java/io/ByteArrayInputStream\n");
        }
        
        /* java.io.ByteArrayOutputStream needs buffer and count fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/ByteArrayOutputStream") == 0) {
            /* Fields: [0] = buf (byte[]), [1] = count (int) */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buf (byte[]) */
                clazz->fields[0].name = strdup("buf");
                clazz->fields[0].descriptor = strdup("[B");  /* byte array */
                clazz->fields[0].name_index = add_utf8(clazz, "buf");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[B");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                /* Field 1: count (int) */
                clazz->fields[1].name = strdup("count");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "count");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* Two JavaValue slots */
            }
            CLASS_DEBUG(" Added buf/count fields to java/io/ByteArrayOutputStream\n");
        }
        
        /* java.io.InputStreamReader needs 'in' field for underlying InputStream */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/InputStreamReader") == 0) {
            /* Fields: [0] = in (InputStream) - reference to underlying InputStream */
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: in (InputStream reference) */
                clazz->fields[0].name = strdup("in");
                clazz->fields[0].descriptor = strdup("Ljava/io/InputStream;");
                clazz->fields[0].name_index = add_utf8(clazz, "in");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/io/InputStream;");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);  /* One JavaValue slot */
            }
            CLASS_DEBUG(" Added 'in' field to java/io/InputStreamReader\n");
        }
        
        /* java.io.BufferedReader needs in/reader field for underlying Reader */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/BufferedReader") == 0) {
            /* Fields: [0] = in (Reader reference) */
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: in (Reader reference) */
                clazz->fields[0].name = strdup("in");
                clazz->fields[0].descriptor = strdup("Ljava/io/Reader;");
                clazz->fields[0].name_index = add_utf8(clazz, "in");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/io/Reader;");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);  /* One JavaValue slot */
            }
            CLASS_DEBUG(" Added in field to java/io/BufferedReader\n");
        }
        
        /* java.io.DataOutputStream needs out field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/DataOutputStream") == 0) {
            /* Fields: [0] = out (OutputStream) */
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: out (OutputStream) */
                clazz->fields[0].name = strdup("out");
                clazz->fields[0].descriptor = strdup("Ljava/io/OutputStream;");
                clazz->fields[0].name_index = add_utf8(clazz, "out");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/io/OutputStream;");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);  /* One JavaValue slot */
            }
            CLASS_DEBUG(" Added out field to java/io/DataOutputStream\n");
        }

        /* javax.microedition.rms.RecordStore needs nativeHandle field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/rms/RecordStore") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: nativeHandle (int) - stores native record store handle */
                clazz->fields[0].name = strdup("nativeHandle");
                clazz->fields[0].descriptor = strdup("I");  /* int */
                clazz->fields[0].name_index = add_utf8(clazz, "nativeHandle");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);  /* One JavaValue slot */
            }
            CLASS_DEBUG(" Added nativeHandle field to javax/microedition/rms/RecordStore\n");
        }
        
        /* javax.microedition.lcdui.Form needs title and items fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Form") == 0) {
            /* Fields: [0] = title (String), [1] = items (Item[]) */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("items");
                clazz->fields[1].descriptor = strdup("[Ljavax/microedition/lcdui/Item;");
                clazz->fields[1].name_index = add_utf8(clazz, "items");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "[Ljavax/microedition/lcdui/Item;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;
            }
            CLASS_DEBUG(" Added title/items fields to javax/microedition/lcdui/Form\n");
        }
        
        /* javax.microedition.lcdui.List needs title, type, strings, selected, listener fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/List") == 0) {
            clazz->fields_count = 5;
            clazz->fields = (JavaField*)calloc(5, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("listType");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "listType");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("strings");
                clazz->fields[2].descriptor = strdup("[Ljava/lang/String;");
                clazz->fields[2].name_index = add_utf8(clazz, "strings");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "[Ljava/lang/String;");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("selected");
                clazz->fields[3].descriptor = strdup("[Z");
                clazz->fields[3].name_index = add_utf8(clazz, "selected");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "[Z");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->fields[4].name = strdup("listener");
                clazz->fields[4].descriptor = strdup("Ljavax/microedition/lcdui/CommandListener;");
                clazz->fields[4].name_index = add_utf8(clazz, "listener");
                clazz->fields[4].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/CommandListener;");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 5;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/List\n");
            
            /* Add static field SELECT_COMMAND */
            clazz->static_fields = (JavaStaticField*)calloc(1, sizeof(JavaStaticField));
            clazz->static_fields_count = 1;
            clazz->static_fields_capacity = 1;
            
            clazz->static_fields[0].name = strdup("SELECT_COMMAND");
            clazz->static_fields[0].descriptor = strdup("Ljavax/microedition/lcdui/Command;");
            memset(&clazz->static_fields[0].value, 0, sizeof(JavaValue));
            
            CLASS_DEBUG(" Added SELECT_COMMAND static field to List\n");
        }
        
        /* javax.microedition.lcdui.Alert needs title, text, image, type, timeout fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Alert") == 0) {
            clazz->fields_count = 5;
            clazz->fields = (JavaField*)calloc(5, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("image");
                clazz->fields[2].descriptor = strdup("Ljavax/microedition/lcdui/Image;");
                clazz->fields[2].name_index = add_utf8(clazz, "image");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/Image;");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("alertType");
                clazz->fields[3].descriptor = strdup("Ljavax/microedition/lcdui/AlertType;");
                clazz->fields[3].name_index = add_utf8(clazz, "alertType");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/AlertType;");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->fields[4].name = strdup("timeout");
                clazz->fields[4].descriptor = strdup("I");
                clazz->fields[4].name_index = add_utf8(clazz, "timeout");
                clazz->fields[4].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 5;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/Alert\n");
        }
        
        /* javax.microedition.lcdui.TextBox needs title, text, maxSize, constraints fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/TextBox") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("maxSize");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "maxSize");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("constraints");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "constraints");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 4;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/TextBox\n");
        }
        
        /* javax.microedition.lcdui.Item needs label field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Item") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added label field to javax/microedition/lcdui/Item\n");
        }
        
        /* javax.microedition.lcdui.StringItem needs label, text fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/StringItem") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/StringItem\n");
        }
        
        /* javax.microedition.lcdui.TextField needs label, text, maxSize, constraints fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/TextField") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("maxSize");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "maxSize");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("constraints");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "constraints");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 4;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/TextField\n");
        }
        
        /* javax.microedition.lcdui.ChoiceGroup needs label, type, strings, selected fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/ChoiceGroup") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("choiceType");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "choiceType");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("strings");
                clazz->fields[2].descriptor = strdup("[Ljava/lang/String;");
                clazz->fields[2].name_index = add_utf8(clazz, "strings");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "[Ljava/lang/String;");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("selected");
                clazz->fields[3].descriptor = strdup("[Z");
                clazz->fields[3].name_index = add_utf8(clazz, "selected");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "[Z");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 4;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/ChoiceGroup\n");
        }
        
        /* javax.microedition.lcdui.Gauge needs label, interactive, max, value fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Gauge") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("interactive");
                clazz->fields[1].descriptor = strdup("Z");
                clazz->fields[1].name_index = add_utf8(clazz, "interactive");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Z");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("maxValue");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "maxValue");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("value");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "value");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 4;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/Gauge\n");
        }
        
        /* javax.microedition.lcdui.Spacer needs width, height fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Spacer") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("width");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].name_index = add_utf8(clazz, "width");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("height");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "height");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/Spacer\n");
        }
        
        /* javax.microedition.lcdui.ImageItem needs label, image, layout, altText fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/ImageItem") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("image");
                clazz->fields[1].descriptor = strdup("Ljavax/microedition/lcdui/Image;");
                clazz->fields[1].name_index = add_utf8(clazz, "image");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/Image;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("layout");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "layout");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("altText");
                clazz->fields[3].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[3].name_index = add_utf8(clazz, "altText");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 4;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/ImageItem\n");
        }
        
        /* javax.microedition.lcdui.DateField needs label, mode, date fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/DateField") == 0) {
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("mode");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "mode");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("date");
                clazz->fields[2].descriptor = strdup("J");  /* long */
                clazz->fields[2].name_index = add_utf8(clazz, "date");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 3;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/DateField\n");
        }
        
        /* javax.microedition.lcdui.Ticker needs text field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Ticker") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("text");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "text");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added text field to javax/microedition/lcdui/Ticker\n");
        }
        
        /* javax.microedition.lcdui.Command needs label, type, priority fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Command") == 0) {
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("type");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "type");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("priority");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "priority");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 3;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/Command\n");
        }
        
        /* javax.microedition.lcdui.AlertType - just needs to exist */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/AlertType") == 0) {
            clazz->fields_count = 0;
            clazz->instance_size = sizeof(ObjectHeader);  /* Minimum size */
            CLASS_DEBUG(" Created javax/microedition/lcdui/AlertType\n");
        }
        
        /* javax.microedition.lcdui.Displayable needs commands array and listener */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Displayable") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: commands (Command[] array) */
                clazz->fields[0].name = strdup("commands");
                clazz->fields[0].descriptor = strdup("[Ljavax/microedition/lcdui/Command;");
                clazz->fields[0].name_index = add_utf8(clazz, "commands");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[Ljavax/microedition/lcdui/Command;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: listener (CommandListener) */
                clazz->fields[1].name = strdup("listener");
                clazz->fields[1].descriptor = strdup("Ljavax/microedition/lcdui/CommandListener;");
                clazz->fields[1].name_index = add_utf8(clazz, "listener");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/CommandListener;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/lcdui/Displayable\n");
        }
        
        /* com.nokia.mid.sound.Sound needs data and type fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "com/nokia/mid/sound/Sound") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("data");
                clazz->fields[0].descriptor = strdup("[B");  /* byte array */
                clazz->fields[0].name_index = add_utf8(clazz, "data");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[B");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("soundType");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "soundType");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;
            }
            CLASS_DEBUG(" Added fields to com/nokia/mid/sound/Sound\n");
        }
        
        /* javax.microedition.media.PlayerImpl - concrete Player implementation */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/media/PlayerImpl") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: playerId (int) */
                clazz->fields[0].name = strdup("playerId");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].name_index = add_utf8(clazz, "playerId");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;

                /* Field 1: state (int) */
                clazz->fields[1].name = strdup("state");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "state");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;

                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;
            }
            CLASS_DEBUG(" Added fields to javax/microedition/media/PlayerImpl\n");
        }
        
        /* com.nokia.mid.ui.DirectGraphics needs graphics reference */
        else if (clazz->class_name && strcmp(clazz->class_name, "com/nokia/mid/ui/DirectGraphics") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("graphics");
                clazz->fields[0].descriptor = strdup("Ljavax/microedition/lcdui/Graphics;");
                clazz->fields[0].name_index = add_utf8(clazz, "graphics");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/Graphics;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added fields to com/nokia/mid/ui/DirectGraphics\n");
        }
        
        /* com.nokia.mid.ui.DirectUtils - static utility class, no instance fields needed */
        else if (clazz->class_name && strcmp(clazz->class_name, "com/nokia/mid/ui/DirectUtils") == 0) {
            clazz->fields_count = 0;
            clazz->instance_size = sizeof(ObjectHeader);
            CLASS_DEBUG(" Created com/nokia/mid/ui/DirectUtils (static utility class)\n");
        }
        
        /* java.io.DataInputStream needs in field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/DataInputStream") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("in");
                clazz->fields[0].descriptor = strdup("Ljava/io/InputStream;");
                clazz->fields[0].name_index = add_utf8(clazz, "in");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/io/InputStream;");
                clazz->fields[0].access_flags = ACC_PROTECTED;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added in field to java/io/DataInputStream\n");
        }
        
        /* java.util.Vector needs elementData, elementCount, capacityIncrement fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/util/Vector") == 0) {
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: elementData (Object[]) */
                clazz->fields[0].name = strdup("elementData");
                clazz->fields[0].descriptor = strdup("[Ljava/lang/Object;");
                clazz->fields[0].name_index = add_utf8(clazz, "elementData");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[Ljava/lang/Object;");
                clazz->fields[0].access_flags = ACC_PROTECTED;
                
                /* Field 1: elementCount (int) */
                clazz->fields[1].name = strdup("elementCount");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "elementCount");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PROTECTED;
                
                /* Field 2: capacityIncrement (int) */
                clazz->fields[2].name = strdup("capacityIncrement");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "capacityIncrement");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PROTECTED;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 3;
            }
            CLASS_DEBUG(" Added fields to java/util/Vector\n");
        }
        
        /* java.util.Hashtable needs table, count, threshold, loadFactor fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/util/Hashtable") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: table (Entry[]) */
                clazz->fields[0].name = strdup("table");
                clazz->fields[0].descriptor = strdup("[Ljava/util/Hashtable$Entry;");
                clazz->fields[0].name_index = add_utf8(clazz, "table");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[Ljava/util/Hashtable$Entry;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: count (int) */
                clazz->fields[1].name = strdup("count");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "count");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                /* Field 2: threshold (int) */
                clazz->fields[2].name = strdup("threshold");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "threshold");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                /* Field 3: loadFactor (float) */
                clazz->fields[3].name = strdup("loadFactor");
                clazz->fields[3].descriptor = strdup("F");
                clazz->fields[3].name_index = add_utf8(clazz, "loadFactor");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "F");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 4;
            }
            CLASS_DEBUG(" Added fields to java/util/Hashtable\n");
        }
        
        /* java.util.Date needs time field (long) */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/util/Date") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("time");
                clazz->fields[0].descriptor = strdup("J");  /* long */
                clazz->fields[0].name_index = add_utf8(clazz, "time");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 2;  /* long = 2 slots */
            }
            CLASS_DEBUG(" Added time field to java/util/Date\n");
        }
        
        /* java.util.Calendar needs time and calendar fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/util/Calendar") == 0) {
            clazz->fields_count = 8;
            clazz->fields = (JavaField*)calloc(8, sizeof(JavaField));
            if (clazz->fields) {
                const char* field_names[] = {"time", "year", "month", "dayOfMonth", "hourOfDay", "minute", "second", "isSet"};
                const char* field_descs[] = {"J", "I", "I", "I", "I", "I", "I", "Z"};
                
                for (int i = 0; i < 8; i++) {
                    clazz->fields[i].name = strdup(field_names[i]);
                    clazz->fields[i].descriptor = strdup(field_descs[i]);
                    clazz->fields[i].name_index = add_utf8(clazz, field_names[i]);
                    clazz->fields[i].descriptor_index = add_utf8(clazz, field_descs[i]);
                    clazz->fields[i].access_flags = ACC_PROTECTED;
                }
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue) * 9;  /* long(2) + 7 ints */
            }
            CLASS_DEBUG(" Added fields to java/util/Calendar\n");
        }
        
        /* java.lang.Byte needs value field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Byte") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("value");
                clazz->fields[0].descriptor = strdup("B");
                clazz->fields[0].name_index = add_utf8(clazz, "value");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "B");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added value field to java/lang/Byte\n");
        }
        
        /* java.lang.Short needs value field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Short") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("value");
                clazz->fields[0].descriptor = strdup("S");
                clazz->fields[0].name_index = add_utf8(clazz, "value");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "S");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added value field to java/lang/Short\n");
        }
        
        /* java.lang.Character needs value field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Character") == 0 && clazz->fields_count == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("value");
                clazz->fields[0].descriptor = strdup("C");
                clazz->fields[0].name_index = add_utf8(clazz, "value");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "C");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(ObjectHeader) + sizeof(JavaValue);
            }
            CLASS_DEBUG(" Added value field to java/lang/Character\n");
        }
    }

    /* ===== ЧЕТВЕРТЫЙ ПРОХОД: Правильный расчет instance_size с учетом наследования ===== */
    /* 
     * CRITICAL FIX: instance_size должен включать все поля из всей иерархии классов.
     * Формула: instance_size = superclass->instance_size + own_instance_fields_size
     * Собственные поля класса - это те, что объявлены в самом классе (не унаследованы).
     */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        
        /* Считаем размер собственных полей экземпляра (не статических) */
        size_t own_fields_size = 0;
        if (clazz->fields) {
            for (uint16_t f = 0; f < clazz->fields_count; f++) {
                if (!(clazz->fields[f].access_flags & ACC_STATIC)) {
                    own_fields_size += sizeof(JavaValue);
                    /* Long и double занимают 2 слота */
                    if (clazz->fields[f].descriptor &&
                        (clazz->fields[f].descriptor[0] == 'J' || clazz->fields[f].descriptor[0] == 'D')) {
                        own_fields_size += sizeof(JavaValue);
                    }
                }
            }
        }
        
        /* Вычисляем правильный instance_size */
        size_t correct_size;
        if (clazz->super_class) {
            /* instance_size = размер суперкласса + собственные поля */
            correct_size = clazz->super_class->instance_size + own_fields_size;
        } else {
            /* java/lang/Object: только ObjectHeader + собственные поля */
            correct_size = sizeof(ObjectHeader) + own_fields_size;
        }
        
        /* Если текущий instance_size не совпадает, исправляем */
        if (clazz->instance_size != correct_size) {
            CLASS_DEBUG(" Fixed instance_size for %s: %zu -> %zu (super: %s, own_fields: %zu)\n",
                       clazz->class_name ? clazz->class_name : "?",
                       (size_t)clazz->instance_size, correct_size,
                       clazz->super_class ? clazz->super_class->class_name : "none",
                       own_fields_size);
            clazz->instance_size = correct_size;
        }
    }

    /* ===== ПЯТЫЙ ПРОХОД: Устанавливаем ObjectHeader для всех классов ===== */
    JavaClass* class_class = NULL;  /* java/lang/Class */
    
    /* Находим java/lang/Class */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Class") == 0) {
            class_class = clazz;
            break;
        }
    }

    if (class_class) {
        for (size_t i = 0; i < jvm->class_loader.count; i++) {
            JavaClass* clazz = jvm->class_loader.classes[i];
            /* Set header.clazz to java/lang/Class so this JavaClass* can be used as a Class object */
            clazz->header.clazz = class_class;
            /* Set a hashcode based on the pointer */
            clazz->header.hashcode = (jint)(uintptr_t)clazz ^ 0x5A5A5A5A;
            clazz->header.gc_mark = 0;
            clazz->header.reserved = 0;
        }
        /* java/lang/Class's header.clazz should point to itself */
        class_class->header.clazz = class_class;
        CLASS_DEBUG(" Initialized Class object headers for %zu classes", jvm->class_loader.count);
    }

    return count;
}

/* Get or create a stub class by name */
JavaClass* get_or_create_stub_class(JVM* jvm, const char* class_name) {
    if (!class_name || !jvm) return NULL;
    
    /* Check if already loaded */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        if (jvm->class_loader.classes[i]->class_name &&
            strcmp(jvm->class_loader.classes[i]->class_name, class_name) == 0) {
            return jvm->class_loader.classes[i];
        }
    }
    
    /* Determine super class based on class name */
    const char* super_name = "java/lang/Object";  /* Default */
    
    /* MIDP LCDUI hierarchy */
    if (strcmp(class_name, "javax/microedition/lcdui/game/GameCanvas") == 0) {
        super_name = "javax/microedition/lcdui/Canvas";
    } else if (strcmp(class_name, "javax/microedition/lcdui/game/Layer") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/game/Sprite") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/game/TiledLayer") == 0) {
        super_name = "javax/microedition/lcdui/game/Layer";
    } else if (strcmp(class_name, "javax/microedition/lcdui/game/LayerManager") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Canvas") == 0) {
        super_name = "javax/microedition/lcdui/Displayable";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Displayable") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Screen") == 0) {
        super_name = "javax/microedition/lcdui/Displayable";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Form") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/TextBox") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/List") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Alert") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Item") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/StringItem") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/TextField") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/ImageItem") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/ChoiceGroup") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/Gauge") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/Spacer") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/DateField") == 0) {
        super_name = "javax/microedition/lcdui/Item";
    }
    /* MIDP Media */
    else if (strcmp(class_name, "javax/microedition/media/Player") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/media/Control") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/media/control/VolumeControl") == 0) {
        super_name = "javax/microedition/media/Control";
    }
    /* RMS */
    else if (strcmp(class_name, "javax/microedition/rms/RecordStoreException") == 0) {
        super_name = "java/lang/Exception";
    } else if (strcmp(class_name, "javax/microedition/rms/RecordStoreNotFoundException") == 0 ||
               strcmp(class_name, "javax/microedition/rms/RecordStoreFullException") == 0 ||
               strcmp(class_name, "javax/microedition/rms/RecordStoreNotOpenException") == 0 ||
               strcmp(class_name, "javax/microedition/rms/InvalidRecordIDException") == 0) {
        super_name = "javax/microedition/rms/RecordStoreException";
    }
    /* Exceptions */
    else if (strcmp(class_name, "javax/microedition/midlet/MIDletStateChangeException") == 0) {
        super_name = "java/lang/Exception";
    }
    /* I/O Exceptions - EOFException extends IOException */
    else if (strcmp(class_name, "java/io/EOFException") == 0) {
        super_name = "java/io/IOException";
    }
    else if (strcmp(class_name, "java/io/UTFDataFormatException") == 0) {
        super_name = "java/io/IOException";
    }
    else if (strcmp(class_name, "java/io/FileNotFoundException") == 0) {
        super_name = "java/io/IOException";
    }
    else if (strcmp(class_name, "java/io/InterruptedIOException") == 0) {
        super_name = "java/io/IOException";
    }
    /* Security exceptions */
    else if (strcmp(class_name, "java/lang/SecurityException") == 0) {
        super_name = "java/lang/RuntimeException";
    }
    /* Unsupported operations */
    else if (strcmp(class_name, "java/lang/UnsupportedOperationException") == 0) {
        super_name = "java/lang/RuntimeException";
    }
    /* NegativeArraySizeException */
    else if (strcmp(class_name, "java/lang/NegativeArraySizeException") == 0) {
        super_name = "java/lang/RuntimeException";
    }
    /* ArithmeticException */
    else if (strcmp(class_name, "java/lang/ArithmeticException") == 0) {
        super_name = "java/lang/RuntimeException";
    }
    /* IllegalStateException */
    else if (strcmp(class_name, "java/lang/IllegalMonitorStateException") == 0) {
        super_name = "java/lang/RuntimeException";
    }
    /* LinkageError and subclasses */
    else if (strcmp(class_name, "java/lang/LinkageError") == 0) {
        super_name = "java/lang/Error";
    }
    else if (strcmp(class_name, "java/lang/NoSuchMethodError") == 0 ||
             strcmp(class_name, "java/lang/NoSuchFieldError") == 0 ||
             strcmp(class_name, "java/lang/NoClassDefFoundError") == 0) {
        super_name = "java/lang/Error";
    }
    else if (strcmp(class_name, "java/lang/ClassFormatError") == 0 ||
             strcmp(class_name, "java/lang/VerifyError") == 0) {
        super_name = "java/lang/Error";
    }
    
    /* JSR 184 M3G (Mobile 3D Graphics) class hierarchy */
    else if (strncmp(class_name, "javax/microedition/m3g/", 23) == 0) {
        /* Core M3G classes */
        if (strcmp(class_name, "javax/microedition/m3g/Object3D") == 0) {
            super_name = "java/lang/Object";
        } else if (strcmp(class_name, "javax/microedition/m3g/Transform") == 0) {
            super_name = "java/lang/Object";
        } else if (strcmp(class_name, "javax/microedition/m3g/Node") == 0) {
            super_name = "javax/microedition/m3g/Object3D";
        } else if (strcmp(class_name, "javax/microedition/m3g/Group") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/Camera") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/Mesh") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/Sprite3D") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/Light") == 0) {
            super_name = "javax/microedition/m3g/Node";
        } else if (strcmp(class_name, "javax/microedition/m3g/World") == 0) {
            super_name = "javax/microedition/m3g/Group";
        } else if (strcmp(class_name, "javax/microedition/m3g/IndexBuffer") == 0) {
            super_name = "java/lang/Object";
        } else if (strcmp(class_name, "javax/microedition/m3g/TriangleStripArray") == 0) {
            super_name = "javax/microedition/m3g/IndexBuffer";
        } else if (strcmp(class_name, "javax/microedition/m3g/Image2D") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/Background") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/Texture2D") == 0) {
            super_name = "javax/microedition/m3g/Object3D";
        } else if (strcmp(class_name, "javax/microedition/m3g/MorphingMesh") == 0 ||
                   strcmp(class_name, "javax/microedition/m3g/SkinnedMesh") == 0) {
            super_name = "javax/microedition/m3g/Mesh";
        }
        /* Other M3G classes extend Object */
    }
    
    /* Create stub class with proper super class */
    JavaClass* stub = create_stub_class(jvm, class_name, super_name, ACC_PUBLIC);
    if (!stub) return NULL;
    
    /* Ensure class_loader has capacity */
    if (jvm->class_loader.count >= jvm->class_loader.capacity) {
        size_t new_cap = jvm->class_loader.capacity ? jvm->class_loader.capacity * 2 : 32;
        jvm->class_loader.classes = (JavaClass**)realloc(jvm->class_loader.classes,
                               new_cap * sizeof(JavaClass*));
        if (!jvm->class_loader.classes) {
            free(stub);
            return NULL;
        }
        jvm->class_loader.capacity = new_cap;
    }
    
    jvm->class_loader.classes[jvm->class_loader.count++] = stub;
    
    /* Resolve super_class reference */
    if (stub->super_class == NULL && stub->super_class_name != NULL) {
        /* Try to find super class in loaded classes */
        for (size_t j = 0; j < jvm->class_loader.count; j++) {
            if (jvm->class_loader.classes[j]->class_name &&
                strcmp(jvm->class_loader.classes[j]->class_name, stub->super_class_name) == 0) {
                stub->super_class = jvm->class_loader.classes[j];
                break;
            }
        }
        /* If not found, create it recursively */
        if (stub->super_class == NULL && strcmp(stub->super_class_name, "java/lang/Object") != 0) {
            stub->super_class = get_or_create_stub_class(jvm, stub->super_class_name);
        }
    }

    /* Initialize header for Class object support */
    JavaClass* class_class = NULL;
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        if (jvm->class_loader.classes[i]->class_name &&
            strcmp(jvm->class_loader.classes[i]->class_name, "java/lang/Class") == 0) {
            class_class = jvm->class_loader.classes[i];
            break;
        }
    }
    if (class_class) {
        stub->header.clazz = class_class;
        stub->header.hashcode = (jint)(uintptr_t)stub ^ 0x5A5A5A5A;
    }

    if (jvm->config.verbose_class) {
        CLASS_DEBUG(" Auto-created stub class: %s (super: %s)", class_name, super_name);
    }

    return stub;
}