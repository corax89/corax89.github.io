/*
 * J2ME Emulator - MIDP2 Graphics API
 * Supports PNG, JPEG, BMP images via stb_image
 */

#define _USE_MATH_DEFINES
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* Enable graphics debug output */
#define GFX_DEBUG 0

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "midp.h"
#include "jvm.h"
#include "bitmap_font.h"
#include "stb_image.h"

/* Current graphics context */
static MidpGraphics* current_gfx = NULL;

/* Forward declaration */
static void set_pixel(MidpGraphics* gfx, int x, int y);

/* Draw a single character using the bitmap font (legacy single-byte) */
static void midp_graphics_draw_char(MidpGraphics* gfx, char c, int x, int y) {
    const uint8_t* char_data = get_char_data(c);
    
    for (int row = 0; row < FONT_HEIGHT; row++) {
        uint8_t row_data = char_data[row];
        for (int col = 0; col < FONT_WIDTH; col++) {
            /* MSB is leftmost pixel, so use (FONT_WIDTH - 1 - col) to get correct bit */
            if (row_data & (1 << (FONT_WIDTH - 1 - col))) {
                set_pixel(gfx, x + col, y + row);
            }
        }
    }
}

/* Draw a single character using Unicode codepoint */
static void midp_graphics_draw_char_unicode(MidpGraphics* gfx, int codepoint, int x, int y) {
    const uint8_t* char_data = get_char_data_unicode(codepoint);
    
    for (int row = 0; row < FONT_HEIGHT; row++) {
        uint8_t row_data = char_data[row];
        for (int col = 0; col < FONT_WIDTH; col++) {
            /* MSB is leftmost pixel, so use (FONT_WIDTH - 1 - col) to get correct bit */
            if (row_data & (1 << (FONT_WIDTH - 1 - col))) {
                set_pixel(gfx, x + col, y + row);
            }
        }
    }
}

/* Initialize MIDP2 */
int midp_init(JVM* jvm) {
    /* Initialize MIDP2 native methods */
    init_javax_microedition_lcdui_graphics(jvm);
    init_javax_microedition_lcdui_display(jvm);
    init_javax_microedition_lcdui_image(jvm);
    init_javax_microedition_lcdui_font(jvm);
    init_javax_microedition_lcdui_game_gamecanvas(jvm);
    init_javax_microedition_lcdui_form(jvm);  /* Form, TextField, ChoiceGroup, etc. */
    init_javax_microedition_rms(jvm);
    
    /* Initialize Java lang classes */
    extern void init_java_lang_integer(JVM* jvm);
    extern void init_java_util_random(JVM* jvm);
    init_java_lang_integer(jvm);
    init_java_util_random(jvm);
    
    /* Seed random number generator */
    srand((unsigned int)time(NULL));
    
    return JNI_OK;
}

/*
 * Graphics operations
 */

void midp_graphics_init(MidpGraphics* gfx, uint32_t* pixels, int width, int height) {
    gfx->pixels = pixels;
    gfx->width = width;
    gfx->height = height;
    gfx->clip_x = 0;
    gfx->clip_y = 0;
    gfx->clip_width = width;
    gfx->clip_height = height;
    gfx->translate_x = 0;
    gfx->translate_y = 0;
    gfx->rgb_color = 0x000000;
    gfx->alpha = 255;
    gfx->stroke_style = 0;
    gfx->font = 0;
}

void midp_graphics_set_clip(MidpGraphics* gfx, int x, int y, int width, int height) {
    gfx->clip_x = x;
    gfx->clip_y = y;
    gfx->clip_width = width;
    gfx->clip_height = height;
}

void midp_graphics_clip_rect(MidpGraphics* gfx, int x, int y, int width, int height) {
    /* Intersect with current clip */
    int x1 = gfx->clip_x > x ? gfx->clip_x : x;
    int y1 = gfx->clip_y > y ? gfx->clip_y : y;
    int x2 = (gfx->clip_x + gfx->clip_width) < (x + width) ? 
             (gfx->clip_x + gfx->clip_width) : (x + width);
    int y2 = (gfx->clip_y + gfx->clip_height) < (y + height) ?
             (gfx->clip_y + gfx->clip_height) : (y + height);
    
    gfx->clip_x = x1;
    gfx->clip_y = y1;
    gfx->clip_width = x2 - x1;
    gfx->clip_height = y2 - y1;
}

void midp_graphics_translate(MidpGraphics* gfx, int x, int y) {
    gfx->translate_x += x;
    gfx->translate_y += y;
}

void midp_graphics_set_color(MidpGraphics* gfx, int rgb, int alpha) {
    if (GFX_DEBUG) fprintf(stderr, "[GFX] setColor: RGB=0x%06X, alpha=%d\n", rgb & 0xFFFFFF, alpha);
    fflush(stderr);
    gfx->rgb_color = rgb & 0xFFFFFF;
    gfx->alpha = alpha;
}

static void set_pixel(MidpGraphics* gfx, int x, int y) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    if (x < gfx->clip_x || x >= gfx->clip_x + gfx->clip_width ||
        y < gfx->clip_y || y >= gfx->clip_y + gfx->clip_height) {
        return;
    }
    
    if (x < 0 || x >= gfx->width || y < 0 || y >= gfx->height) {
        return;
    }
    
    uint32_t color = (gfx->alpha << 24) | gfx->rgb_color;
    gfx->pixels[y * gfx->width + x] = color;
}

void midp_graphics_draw_line(MidpGraphics* gfx, int x1, int y1, int x2, int y2) {
    if (GFX_DEBUG) fprintf(stderr, "[GFX] drawLine: (%d,%d) -> (%d,%d), color=0x%06X\n", 
            x1, y1, x2, y2, gfx->rgb_color);
    fflush(stderr);
    x1 += gfx->translate_x;
    y1 += gfx->translate_y;
    x2 += gfx->translate_x;
    y2 += gfx->translate_y;
    
    /* Bresenham's line algorithm */
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = x1 < x2 ? 1 : -1;
    int sy = y1 < y2 ? 1 : -1;
    int err = dx - dy;
    
    while (true) {
        set_pixel(gfx, x1 - gfx->translate_x, y1 - gfx->translate_y);
        
        if (x1 == x2 && y1 == y2) break;
        
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
}

void midp_graphics_fill_rect(MidpGraphics* gfx, int x, int y, int w, int h) {
    if (GFX_DEBUG) fprintf(stderr, "[GFX] fillRect: (%d,%d) %dx%d, color=0x%06X, clip=(%d,%d %dx%d)\n", 
            x, y, w, h, gfx->rgb_color, gfx->clip_x, gfx->clip_y, gfx->clip_width, gfx->clip_height);
    fflush(stderr);
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    /* Clip to bounds */
    int x1 = x > gfx->clip_x ? x : gfx->clip_x;
    int y1 = y > gfx->clip_y ? y : gfx->clip_y;
    int x2 = (x + w) < (gfx->clip_x + gfx->clip_width) ? (x + w) : (gfx->clip_x + gfx->clip_width);
    int y2 = (y + h) < (gfx->clip_y + gfx->clip_height) ? (y + h) : (gfx->clip_y + gfx->clip_height);
    
    uint32_t color = (gfx->alpha << 24) | gfx->rgb_color;
    
    for (int py = y1; py < y2 && py < gfx->height; py++) {
        if (py < 0) continue;
        for (int px = x1; px < x2 && px < gfx->width; px++) {
            if (px < 0) continue;
            gfx->pixels[py * gfx->width + px] = color;
        }
    }
}

void midp_graphics_draw_rect(MidpGraphics* gfx, int x, int y, int w, int h) {
    midp_graphics_draw_line(gfx, x, y, x + w - 1, y);
    midp_graphics_draw_line(gfx, x, y + h - 1, x + w - 1, y + h - 1);
    midp_graphics_draw_line(gfx, x, y, x, y + h - 1);
    midp_graphics_draw_line(gfx, x + w - 1, y, x + w - 1, y + h - 1);
}

void midp_graphics_draw_arc(MidpGraphics* gfx, int x, int y, int w, int h,
                            int start_angle, int arc_angle) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    double cx = x + w / 2.0;
    double cy = y + h / 2.0;
    double rx = w / 2.0;
    double ry = h / 2.0;
    
    double start_rad = start_angle * M_PI / 180.0;
    double end_rad = (start_angle + arc_angle) * M_PI / 180.0;
    
    int steps = abs(arc_angle) * 2;
    double step = arc_angle > 0 ? (end_rad - start_rad) / steps : (start_rad - end_rad) / steps;
    
    for (int i = 0; i <= steps; i++) {
        double angle = start_rad + i * step;
        int px = (int)(cx + rx * cos(angle));
        int py = (int)(cy + ry * sin(angle));
        set_pixel(gfx, px - gfx->translate_x, py - gfx->translate_y);
    }
}

void midp_graphics_fill_arc(MidpGraphics* gfx, int x, int y, int w, int h,
                            int start_angle, int arc_angle) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    double cx = x + w / 2.0;
    double cy = y + h / 2.0;
    double rx = w / 2.0;
    double ry = h / 2.0;
    
    double start_rad = start_angle * M_PI / 180.0;
    double end_rad = (start_angle + arc_angle) * M_PI / 180.0;
    
    /* Fill using scanlines */
    for (int py = y; py < y + h && py < gfx->height; py++) {
        if (py < 0 || py < gfx->clip_y || py >= gfx->clip_y + gfx->clip_height) continue;
        
        for (int px = x; px < x + w && px < gfx->width; px++) {
            if (px < 0 || px < gfx->clip_x || px >= gfx->clip_x + gfx->clip_width) continue;
            
            double dx = (px - cx) / rx;
            double dy = (py - cy) / ry;
            
            if (dx * dx + dy * dy <= 1.0) {
                double angle = atan2(dy, dx);
                if (angle < 0) angle += 2 * M_PI;
                
                bool in_arc = false;
                if (arc_angle > 0) {
                    in_arc = (angle >= start_rad && angle <= end_rad);
                } else {
                    in_arc = (angle <= start_rad && angle >= end_rad);
                }
                
                if (in_arc) {
                    set_pixel(gfx, px - gfx->translate_x, py - gfx->translate_y);
                }
            }
        }
    }
}

void midp_graphics_draw_round_rect(MidpGraphics* gfx, int x, int y, int w, int h,
                                   int arc_w, int arc_h) {
    /* Draw lines */
    midp_graphics_draw_line(gfx, x + arc_w/2, y, x + w - arc_w/2 - 1, y);
    midp_graphics_draw_line(gfx, x + arc_w/2, y + h - 1, x + w - arc_w/2 - 1, y + h - 1);
    midp_graphics_draw_line(gfx, x, y + arc_h/2, x, y + h - arc_h/2 - 1);
    midp_graphics_draw_line(gfx, x + w - 1, y + arc_h/2, x + w - 1, y + h - arc_h/2 - 1);
    
    /* Draw arcs */
    midp_graphics_draw_arc(gfx, x, y, arc_w, arc_h, 90, 90);
    midp_graphics_draw_arc(gfx, x + w - arc_w, y, arc_w, arc_h, 0, 90);
    midp_graphics_draw_arc(gfx, x + w - arc_w, y + h - arc_h, arc_w, arc_h, 270, 90);
    midp_graphics_draw_arc(gfx, x, y + h - arc_h, arc_w, arc_h, 180, 90);
}

void midp_graphics_fill_round_rect(MidpGraphics* gfx, int x, int y, int w, int h,
                                   int arc_w, int arc_h) {
    /* Fill center */
    midp_graphics_fill_rect(gfx, x + arc_w/2, y, w - arc_w, h);
    midp_graphics_fill_rect(gfx, x, y + arc_h/2, arc_w/2, h - arc_h);
    midp_graphics_fill_rect(gfx, x + w - arc_w/2, y + arc_h/2, arc_w/2, h - arc_h);
    
    /* Fill corners */
    midp_graphics_fill_arc(gfx, x, y, arc_w, arc_h, 90, 90);
    midp_graphics_fill_arc(gfx, x + w - arc_w, y, arc_w, arc_h, 0, 90);
    midp_graphics_fill_arc(gfx, x + w - arc_w, y + h - arc_h, arc_w, arc_h, 270, 90);
    midp_graphics_fill_arc(gfx, x, y + h - arc_h, arc_w, arc_h, 180, 90);
}

void midp_graphics_draw_string(MidpGraphics* gfx, const char* str,
                               int x, int y, int anchor) {
    if (GFX_DEBUG) fprintf(stderr, "[GFX] drawString: str='%s', x=%d, y=%d, anchor=%d, color=0x%06X\n",
            str ? str : "(null)", x, y, anchor, gfx ? gfx->rgb_color : 0);
    fflush(stderr);
    
    if (!str || !gfx) return;
    
    int byte_len = strlen(str);
    if (byte_len == 0) return;
    
    /* Count characters (not bytes) using UTF-8 decoding */
    int char_count = utf8_strlen(str);
    if (char_count == 0) return;
    
    /* Prevent integer overflow - limit string length for safety */
    if (char_count > 4096) {
        char_count = 4096;  /* Truncate very long strings */
    }
    
    /* Calculate text dimensions based on character count */
    int text_width = char_count * (FONT_WIDTH + 1) - 1;  /* +1 for spacing between chars */
    int text_height = FONT_HEIGHT;
    
    /* Apply translation */
    int draw_x = x + gfx->translate_x;
    int draw_y = y + gfx->translate_y;
    
    /* MIDP2 anchor constants:
     * HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64
     */
    
    /* Apply horizontal anchor */
    if (anchor & 0x01) {        /* HCENTER = 1 */
        draw_x -= text_width / 2;
    } else if (anchor & 0x08) { /* RIGHT = 8 */
        draw_x -= text_width;
    }
    /* LEFT = 4 is default (no adjustment needed) */
    
    /* Apply vertical anchor */
    if (anchor & 0x02) {        /* VCENTER = 2 */
        draw_y -= text_height / 2;
    } else if (anchor & 0x40) { /* BASELINE = 64 */
        draw_y -= FONT_HEIGHT - 2;  /* Baseline is near bottom */
    } else if (anchor & 0x20) { /* BOTTOM = 32 */
        draw_y -= text_height;
    }
    /* TOP = 16 is default (no adjustment needed) */
    
    /* Debug output for anchor calculation */
    if (GFX_DEBUG) fprintf(stderr, "[GFX] drawString: char_count=%d, text_width=%d, draw_x=%d, draw_y=%d (anchor: HCENTER=%d RIGHT=%d LEFT=%d)\n",
            char_count, text_width, draw_x, draw_y, 
            (anchor & 0x01) ? 1 : 0, 
            (anchor & 0x08) ? 1 : 0,
            (anchor & 0x04) ? 1 : 0);
    fflush(stderr);
    
    /* Draw each character, decoding UTF-8 */
    /* Use a separate counter to limit drawn characters (prevents buffer issues) */
    int cur_x = draw_x;
    int i = 0;
    int chars_drawn = 0;
    while (i < byte_len && chars_drawn < char_count) {
        int codepoint = utf8_decode(str, &i, byte_len);
        if (codepoint >= 0) {
            midp_graphics_draw_char_unicode(gfx, codepoint, cur_x, draw_y);
            cur_x += FONT_WIDTH + 1;  /* +1 for spacing between characters */
            chars_drawn++;
        }
    }
}

void midp_graphics_draw_image(MidpGraphics* gfx, MidpImage* img,
                              int x, int y, int anchor) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    if (!img || !img->pixels) return;
    
    /* MIDP2 anchor constants:
     * HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64
     */
    
    /* Apply horizontal anchor */
    if (anchor & 0x01) {        /* HCENTER */
        x -= img->width / 2;
    } else if (anchor & 0x08) { /* RIGHT */
        x -= img->width;
    }
    /* LEFT = 4 is default */
    
    /* Apply vertical anchor */
    if (anchor & 0x02) {        /* VCENTER */
        y -= img->height / 2;
    } else if (anchor & 0x20) { /* BOTTOM */
        y -= img->height;
    }
    /* TOP = 16 is default */
    
    /* Copy pixels */
    for (int py = 0; py < img->height; py++) {
        int dst_y = y + py;
        if (dst_y < gfx->clip_y || dst_y >= gfx->clip_y + gfx->clip_height) continue;
        if (dst_y < 0 || dst_y >= gfx->height) continue;
        
        for (int px = 0; px < img->width; px++) {
            int dst_x = x + px;
            if (dst_x < gfx->clip_x || dst_x >= gfx->clip_x + gfx->clip_width) continue;
            if (dst_x < 0 || dst_x >= gfx->width) continue;
            
            uint32_t src_color = img->pixels[py * img->width + px];
            
            /* Alpha blending */
            uint8_t alpha = (src_color >> 24) & 0xFF;
            if (alpha == 255) {
                gfx->pixels[dst_y * gfx->width + dst_x] = src_color;
            } else if (alpha > 0) {
                uint32_t dst_color = gfx->pixels[dst_y * gfx->width + dst_x];
                uint8_t inv_alpha = 255 - alpha;
                
                uint8_t r = ((src_color >> 16) & 0xFF) * alpha / 255 + 
                           ((dst_color >> 16) & 0xFF) * inv_alpha / 255;
                uint8_t g = ((src_color >> 8) & 0xFF) * alpha / 255 +
                           ((dst_color >> 8) & 0xFF) * inv_alpha / 255;
                uint8_t b = (src_color & 0xFF) * alpha / 255 +
                           (dst_color & 0xFF) * inv_alpha / 255;
                
                gfx->pixels[dst_y * gfx->width + dst_x] = (0xFF << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }
}

/* Draw a region of an image with optional transform
 * MIDP2 Transform constants:
 * TRANS_NONE = 0, TRANS_MIRROR_ROT180 = 1, TRANS_MIRROR = 2, TRANS_ROT180 = 3
 * TRANS_MIRROR_ROT270 = 4, TRANS_ROT90 = 5, TRANS_ROT270 = 6, TRANS_MIRROR_ROT90 = 7
 */
void midp_graphics_draw_region(MidpGraphics* gfx, MidpImage* img,
                               int x_src, int y_src, int w, int h,
                               int transform, int x_dest, int y_dest, int anchor) {
    x_dest += gfx->translate_x;
    y_dest += gfx->translate_y;
    
    if (!img || !img->pixels) return;
    if (w <= 0 || h <= 0) return;
    if (x_src < 0 || y_src < 0 || x_src + w > img->width || y_src + h > img->height) return;
    
    /* Calculate output dimensions based on transform */
    int out_w = w;
    int out_h = h;
    
    /* Rotations 90 and 270 swap width and height */
    if (transform == 5 || transform == 6 || transform == 4 || transform == 7) {
        out_w = h;
        out_h = w;
    }
    
    /* Apply anchor */
    if (anchor & 0x01) {        /* HCENTER */
        x_dest -= out_w / 2;
    } else if (anchor & 0x08) { /* RIGHT */
        x_dest -= out_w;
    }
    
    if (anchor & 0x02) {        /* VCENTER */
        y_dest -= out_h / 2;
    } else if (anchor & 0x20) { /* BOTTOM */
        y_dest -= out_h;
    }
    
    /* Draw the region with transform */
    for (int py = 0; py < h; py++) {
        for (int px = 0; px < w; px++) {
            int src_x = x_src + px;
            int src_y = y_src + py;
            
            uint32_t src_color = img->pixels[src_y * img->width + src_x];
            uint8_t alpha = (src_color >> 24) & 0xFF;
            if (alpha == 0) continue;  /* Skip fully transparent pixels */
            
            /* Calculate destination coordinates based on transform */
            int dst_px, dst_py;
            
            switch (transform) {
                case 0: /* TRANS_NONE */
                    dst_px = px;
                    dst_py = py;
                    break;
                case 1: /* TRANS_MIRROR_ROT180 (flip horizontally then rotate 180) */
                    dst_px = w - 1 - px;
                    dst_py = h - 1 - py;
                    break;
                case 2: /* TRANS_MIRROR (flip horizontally) */
                    dst_px = w - 1 - px;
                    dst_py = py;
                    break;
                case 3: /* TRANS_ROT180 */
                    dst_px = w - 1 - px;
                    dst_py = h - 1 - py;
                    break;
                case 4: /* TRANS_MIRROR_ROT270 */
                    dst_px = h - 1 - py;
                    dst_py = px;
                    break;
                case 5: /* TRANS_ROT90 */
                    dst_px = py;
                    dst_py = h - 1 - px;
                    break;
                case 6: /* TRANS_ROT270 */
                    dst_px = h - 1 - py;
                    dst_py = w - 1 - px;
                    break;
                case 7: /* TRANS_MIRROR_ROT90 */
                    dst_px = py;
                    dst_py = px;
                    break;
                default:
                    dst_px = px;
                    dst_py = py;
                    break;
            }
            
            int dst_x = x_dest + dst_px;
            int dst_y = y_dest + dst_py;
            
            /* Clip check */
            if (dst_x < gfx->clip_x || dst_x >= gfx->clip_x + gfx->clip_width) continue;
            if (dst_y < gfx->clip_y || dst_y >= gfx->clip_y + gfx->clip_height) continue;
            if (dst_x < 0 || dst_x >= gfx->width || dst_y < 0 || dst_y >= gfx->height) continue;
            
            /* Alpha blending */
            if (alpha == 255) {
                gfx->pixels[dst_y * gfx->width + dst_x] = src_color;
            } else {
                uint32_t dst_color = gfx->pixels[dst_y * gfx->width + dst_x];
                uint8_t inv_alpha = 255 - alpha;
                
                uint8_t r = ((src_color >> 16) & 0xFF) * alpha / 255 + 
                           ((dst_color >> 16) & 0xFF) * inv_alpha / 255;
                uint8_t g = ((src_color >> 8) & 0xFF) * alpha / 255 +
                           ((dst_color >> 8) & 0xFF) * inv_alpha / 255;
                uint8_t b = (src_color & 0xFF) * alpha / 255 +
                           (dst_color & 0xFF) * inv_alpha / 255;
                
                gfx->pixels[dst_y * gfx->width + dst_x] = (0xFF << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }
}

/* Copy a region within the graphics context */
void midp_graphics_copy_area(MidpGraphics* gfx, int x_src, int y_src,
                             int w, int h, int x_dest, int y_dest, int anchor) {
    x_src += gfx->translate_x;
    y_src += gfx->translate_y;
    x_dest += gfx->translate_x;
    y_dest += gfx->translate_y;
    
    if (w <= 0 || h <= 0) return;
    
    /* Apply anchor for destination */
    if (anchor & 0x01) {        /* HCENTER */
        x_dest -= w / 2;
    } else if (anchor & 0x08) { /* RIGHT */
        x_dest -= w;
    }
    
    if (anchor & 0x02) {        /* VCENTER */
        y_dest -= h / 2;
    } else if (anchor & 0x20) { /* BOTTOM */
        y_dest -= h;
    }
    
    /* Allocate temporary buffer for copy (to handle overlapping regions) */
    uint32_t* temp = (uint32_t*)malloc(w * h * sizeof(uint32_t));
    if (!temp) return;
    
    /* Copy source to temp buffer */
    for (int py = 0; py < h; py++) {
        int src_y = y_src + py;
        if (src_y < 0 || src_y >= gfx->height) continue;
        
        for (int px = 0; px < w; px++) {
            int src_x = x_src + px;
            if (src_x < 0 || src_x >= gfx->width) continue;
            
            temp[py * w + px] = gfx->pixels[src_y * gfx->width + src_x];
        }
    }
    
    /* Copy from temp to destination */
    for (int py = 0; py < h; py++) {
        int dst_y = y_dest + py;
        if (dst_y < gfx->clip_y || dst_y >= gfx->clip_y + gfx->clip_height) continue;
        if (dst_y < 0 || dst_y >= gfx->height) continue;
        
        for (int px = 0; px < w; px++) {
            int dst_x = x_dest + px;
            if (dst_x < gfx->clip_x || dst_x >= gfx->clip_x + gfx->clip_width) continue;
            if (dst_x < 0 || dst_x >= gfx->width) continue;
            
            gfx->pixels[dst_y * gfx->width + dst_x] = temp[py * w + px];
        }
    }
    
    free(temp);
}

void midp_graphics_get_rgb(MidpGraphics* gfx, jint* rgb_data,
                           int offset, int scanlength, int x, int y, int w, int h) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    for (int py = 0; py < h; py++) {
        int src_y = y + py;
        if (src_y < 0 || src_y >= gfx->height) continue;
        
        for (int px = 0; px < w; px++) {
            int src_x = x + px;
            if (src_x < 0 || src_x >= gfx->width) continue;
            
            rgb_data[offset + py * scanlength + px] = 
                (jint)gfx->pixels[src_y * gfx->width + src_x];
        }
    }
}

/*
 * Image operations
 */

MidpImage* midp_image_create(int width, int height, bool mutable) {
    MidpImage* img = (MidpImage*)malloc(sizeof(MidpImage));
    if (!img) return NULL;
    
    img->pixels = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    if (!img->pixels) {
        free(img);
        return NULL;
    }
    
    img->width = width;
    img->height = height;
    img->mutable = mutable;
    img->alpha = true;
    
    return img;
}

MidpImage* midp_image_create_from_rgb(const jint* rgb, int width, int height,
                                       bool process_alpha) {
    MidpImage* img = midp_image_create(width, height, true);
    if (!img) return NULL;
    
    for (int i = 0; i < width * height; i++) {
        if (process_alpha) {
            img->pixels[i] = (uint32_t)rgb[i];
        } else {
            img->pixels[i] = 0xFF000000 | ((uint32_t)rgb[i] & 0xFFFFFF);
        }
    }
    
    img->alpha = process_alpha;
    return img;
}

void midp_image_destroy(MidpImage* img) {
    if (img) {
        free(img->pixels);
        free(img);
    }
}

void midp_image_get_rgb(MidpImage* img, jint* rgb, int offset, int scanlength,
                        int x, int y, int width, int height) {
    if (!img || !rgb) return;
    
    for (int py = 0; py < height; py++) {
        int src_y = y + py;
        if (src_y < 0 || src_y >= img->height) continue;
        
        for (int px = 0; px < width; px++) {
            int src_x = x + px;
            if (src_x < 0 || src_x >= img->width) continue;
            
            rgb[offset + py * scanlength + px] = 
                (jint)img->pixels[src_y * img->width + src_x];
        }
    }
}

MidpGraphics* midp_image_get_graphics(MidpImage* img) {
    if (!img || !img->mutable) return NULL;
    
    MidpGraphics* gfx = (MidpGraphics*)malloc(sizeof(MidpGraphics));
    if (!gfx) return NULL;
    
    midp_graphics_init(gfx, img->pixels, img->width, img->height);
    return gfx;
}

/* ============================================
 * Image decoding via stb_image
 * Supports: PNG, JPEG, BMP
 * ============================================ */

/* Check if data is a PNG */
static bool is_png(const uint8_t* data, int len) {
    static const uint8_t png_sig[8] = {0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};
    return len >= 8 && memcmp(data, png_sig, 8) == 0;
}

/* Check if data is a JPEG */
static bool is_jpeg(const uint8_t* data, int len) {
    return len >= 3 && data[0] == 0xFF && data[1] == 0xD8 && data[2] == 0xFF;
}

/* Check if data is a BMP */
static bool is_bmp(const uint8_t* data, int len) {
    return len >= 2 && data[0] == 'B' && data[1] == 'M';
}

/* Decode image data to RGBA pixels using stb_image */
MidpImage* midp_image_create_from_data(const uint8_t* data, int offset, int length) {
    if (!data || length < 8) return NULL;
    
    const uint8_t* img_data = data + offset;
    int img_len = length - offset;
    
    /* Check image format for logging */
    const char* format = "unknown";
    if (is_png(img_data, img_len)) format = "PNG";
    else if (is_jpeg(img_data, img_len)) format = "JPEG";
    else if (is_bmp(img_data, img_len)) format = "BMP";
    
    /* Decode using stb_image */
    int width, height, channels;
    uint8_t* pixels = stbi_load_from_memory(img_data, img_len, &width, &height, &channels, 4);
    
    if (!pixels) {
        fprintf(stderr, "[Image] Failed to decode %s: %s\n", format, stbi_failure_reason());
        return NULL;
    }
    
    fprintf(stderr, "[Image] Decoded %s: %dx%d (%d channels)\n", format, width, height, channels);
    
    /* Create MIDP image */
    MidpImage* img = midp_image_create(width, height, true);
    if (!img) {
        stbi_image_free(pixels);
        return NULL;
    }
    
    /* Convert from stb_image format (RGBA bytes) to our format (ARGB uint32_t) */
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int idx = (y * width + x) * 4;
            uint8_t r = pixels[idx];
            uint8_t g = pixels[idx + 1];
            uint8_t b = pixels[idx + 2];
            uint8_t a = pixels[idx + 3];
            
            /* Store as ARGB */
            img->pixels[y * width + x] = (a << 24) | (r << 16) | (g << 8) | b;
        }
    }
    
    img->alpha = (channels == 4);
    
    stbi_image_free(pixels);
    return img;
}

/*
 * Font operations
 */

MidpFont* midp_font_get_default(void) {
    static MidpFont default_font = {
        .face = FONT_FACE_SYSTEM,
        .style = FONT_STYLE_PLAIN,
        .size = FONT_SIZE_MEDIUM,
        .height = FONT_HEIGHT,
        .baseline = FONT_HEIGHT - 2,
        .native_font = NULL
    };
    return &default_font;
}

MidpFont* midp_font_get(int face, int style, int size) {
    MidpFont* font = (MidpFont*)malloc(sizeof(MidpFont));
    if (!font) return NULL;
    
    font->face = face;
    font->style = style;
    font->size = size;
    /* Use bitmap font dimensions */
    font->height = FONT_HEIGHT;
    font->baseline = FONT_HEIGHT - 2;
    font->native_font = NULL;
    
    return font;
}

int midp_font_string_width(MidpFont* font, const char* str) {
    if (!font || !str) return 0;
    /* Each character is FONT_WIDTH pixels + 1 pixel spacing */
    /* Count UTF-8 characters, not bytes */
    int char_count = utf8_strlen(str);
    /* Prevent integer overflow for very long strings */
    if (char_count > 4096) char_count = 4096;
    return char_count > 0 ? char_count * (FONT_WIDTH + 1) - 1 : 0;
}

int midp_font_char_width(MidpFont* font, jchar ch) {
    (void)ch;
    if (!font) return 0;
    return FONT_WIDTH;
}

int midp_font_height(MidpFont* font) {
    return font ? font->height : FONT_HEIGHT;
}

int midp_font_baseline_position(MidpFont* font) {
    return font ? font->baseline : FONT_HEIGHT - 2;
}

/*
 * Display operations
 */

void midp_display_get_dimensions(int* width, int* height) {
    if (width) *width = MIDP_DEFAULT_WIDTH;
    if (height) *height = MIDP_DEFAULT_HEIGHT;
}

bool midp_display_is_color(void) {
    return true;
}

int midp_display_num_colors(void) {
    return 65536;
}

int midp_display_num_alpha_levels(void) {
    return 256;
}
