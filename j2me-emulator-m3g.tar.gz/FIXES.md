# J2ME Emulator - Исправления

## Найденные и исправленные проблемы

### 1. NullPointerException при создании Image из byte[] (display.c)

**Проблема**: В функции `native_image_createImage_from_bytes` не вызывалась `ensure_native_peer_field()`, 
из-за чего класс `javax/microedition/lcdui/Image` создавался без поля для хранения указателя на нативные данные изображения.

**Решение**: Добавлен вызов `ensure_native_peer_field(image_class)` перед созданием объекта Image.

**Файл**: `src/midp/display.c`, функция `native_image_createImage_from_bytes`

### 2. Конфликт статических полей с одинаковыми именами (opcodes.c)

**Проблема**: В обфусцированном JAR (re.jar) используется одно имя поля `a` для разных типов данных:
- `a.a` типа `[Ljavax/microedition/lcdui/Image;` (массив изображений)
- `a.a` типа `Ljavax/microedition/lcdui/Image;` (одно изображение)
- `a.a` типа `Ljavax/microedition/lcdui/Font;` (шрифт)

Поиск полей в `getstatic` и `putstatic` осуществлялся только по имени, без учёта дескриптора типа,
что приводило к перезаписи полей и возврату неверных значений.

**Решение**: Изменён алгоритм поиска статических полей в `op_getstatic` и `op_putstatic`:
- Поиск теперь осуществляется по имени И дескриптору типа
- При создании нового слота сохраняется дескриптор поля
- Добавлена обратная совместимость для полей без дескриптора

**Файл**: `src/jvm/opcodes.c`, функции `op_getstatic` и `op_putstatic`

### 3. Vector.elements() возвращал null (native.c)

**Проблема**: Метод `java/util/Vector.elements()` не был реализован и возвращал null, 
что приводило к NullPointerException при вызове `Enumeration.nextElement()`.

**Решение**: Добавлена реализация:
- `native_vector_elements()` - создаёт объект Enumeration
- `native_enumeration_hasMoreElements()` - проверяет наличие элементов
- `native_enumeration_nextElement()` - возвращает следующий элемент

**Файл**: `src/jvm/native.c`

### 4. Command объекты собирались сборщиком мусора (stubs.c, form.c)

**Проблема**: `native_displayable_addCommand()` не сохранял ссылку на команду, 
из-за чего Command объекты (и их подклассы) собирались GC и удалялись из памяти.
Это приводило к ошибке "Object is NOT in heap" при попытке вызова методов на этих объектах.

**Решение**: 
- В `stubs.c` добавлены поля для Displayable: `commands` (массив Command[]) и `listener` (CommandListener)
- В `form.c` изменена функция `native_displayable_addCommand()`:
  - Создаёт/расширяет массив commands
  - Сохраняет ссылку на добавленную команду
- В `form.c` изменена функция `native_displayable_setCommandListener()`:
  - Сохраняет ссылку на listener в поле displayable

**Файлы**: `src/jvm/stubs.c`, `src/midp/form.c`

### 5. Vector конструкторы не инициализировали elementData (native.c)

**Проблема**: Конструкторы `Vector(int)` и `Vector(int, int)` были реализованы как Java bytecode заглушки,
которые только вызывали `super.<init>()`, но не инициализировали поле `elementData`.
Это приводило к тому, что `elementData` оставался null, и добавление элементов не работало.

**Решение**:
- Добавлена вспомогательная функция `vector_init_internal()` для инициализации Vector
- Добавлены нативные конструкторы:
  - `native_vector_init()` - для `Vector()`
  - `native_vector_init_int()` - для `Vector(int)`
  - `native_vector_init_int_int()` - для `Vector(int, int)`
- Функция `native_vector_add_element()` теперь автоматически инициализирует `elementData`, если он null

**Файл**: `src/jvm/native.c`

### 6. ClassCastException в Enumeration.nextElement()

**Проблема**: При вызове `Enumeration.nextElement()` возникал `ClassCastException` из-за того,
что `Vector.elements()` создавал Enumeration с некорректными данными или элемент неправильного типа.

**Решение**:
- Улучшено логирование в `native_vector_elements()`
- Добавлена проверка на null для `elementData`
- Улучшена отладочная информация в `native_enumeration_nextElement()`

**Файл**: `src/jvm/native.c`

### 7. Integer(int) конструктор не найден

**Проблема**: Конструктор `java/lang/Integer.<init>(I)V` не был реализован,
что приводило к ошибке `NoSuchMethodError` при создании `new Integer(value)`.

**Решение**:
- Добавлен нативный метод `native_integer_init()` для конструктора `Integer(int)`

**Файл**: `src/jvm/native.c`

### 8. ByteArrayInputStream.read(byte[]) не найден

**Проблема**: Метод `java/io/ByteArrayInputStream.read([B)I` не был реализован,
что приводило к ошибкам при чтении данных из потока.

**Решение**:
- Добавлен нативный метод `native_bytearrayinputstream_read_array_full()` для чтения всего массива

**Файл**: `src/jvm/native.c`

### 9. Неверный расчет instance_size для классов с наследованием (КРИТИЧЕСКОЕ)

**Проблема**: При создании stub-классов instance_size вычислялся только на основе собственных полей класса,
без учета унаследованных полей от родительских классов. Например:
- Displayable имеет 2 поля, instance_size = ObjectHeader + 2
- Form extends Displayable имеет 2 своих поля, но instance_size = ObjectHeader + 2 (вместо ObjectHeader + 4)
- Это приводило к ошибке "Calculated slot X out of bounds" при доступе к полям

**Пример ошибки**:
```
[EXEC] putfield: FATAL: Calculated slot 32 out of bounds (max 31) for field c.G
```

**Решение**:
- Переписан четвёртый проход в `init_stub_classes()` для правильного расчета instance_size:
  - Формула: `instance_size = superclass->instance_size + own_instance_fields_size`
  - Собственные поля определяются путём обхода fields[] класса и подсчёта не-статических полей
  - Long и double корректно учитываются как 2 слота

**Файл**: `src/jvm/stubs.c`, функция `init_stub_classes()`, четвёртый проход

### 10. Graphics.drawRegion() не реализован (КРИТИЧЕСКОЕ)

**Проблема**: Метод `Graphics.drawRegion()` - критически важный для игр, используемый для отрисовки 
спрайтов с трансформацией (поворот, отражение). Отсутствие этого метода блокировало многие игры.

**Решение**:
- Добавлен полный метод `native_graphics_drawRegion()` с поддержкой всех 8 трансформаций:
  - TRANS_NONE (0) - без изменений
  - TRANS_MIRROR_ROT180 (1) - отражение по вертикали + поворот 180°
  - TRANS_MIRROR (2) - отражение по вертикали
  - TRANS_ROT180 (3) - поворот на 180°
  - TRANS_MIRROR_ROT270 (4) - отражение + поворот на 270°
  - TRANS_ROT90 (5) - поворот на 90° по часовой стрелке
  - TRANS_ROT270 (6) - поворот на 270° по часовой стрелке
  - TRANS_MIRROR_ROT90 (7) - отражение + поворот на 90°
- Поддержка clipping и alpha blending

**Файл**: `src/midp/display.c`

### 10. Sprite.collidesWith() не реализован (КРИТИЧЕСКОЕ)

**Проблема**: Метод проверки столкновений спрайтов отсутствовал, что делало невозможной 
игровую логику в большинстве игр.

**Решение**:
- Добавлено 3 перегруженных метода `collidesWith`:
  - `collidesWith(Sprite, boolean)` - столкновение двух спрайтов
  - `collidesWith(TiledLayer, boolean)` - столкновение с тайловым слоем
  - `collidesWith(Image, int, int, boolean)` - столкновение с изображением
- Поддержка pixel-level проверки столкновений
- Добавлены методы: `setTransform()`, `getTransform()`, `setFrameSequence()`, 
  `nextFrame()`, `prevFrame()`, `getRawFrameCount()`, `defineCollisionRectangle()`

**Файл**: `src/midp/display.c`

### 11. Image.createImage(Image, x, y, w, h, transform) не реализован

**Проблема**: Метод создания подизображения с трансформацией отсутствовал.

**Решение**:
- Добавлен `native_image_createImage_region()` - создает новое изображение из части исходного
- Добавлен `native_image_createImage_copy()` - создает копию изображения
- Поддержка всех 8 трансформаций при создании подизображения

**Файл**: `src/midp/display.c`

### 12. Font.charWidth/charsWidth/substringWidth не реализованы

**Проблема**: Методы расчёта ширины текста отсутствовали, что приводило к неправильному 
позиционированию текста.

**Решение**:
- Добавлены методы:
  - `charWidth(char)` - ширина одного символа
  - `charsWidth(char[], offset, length)` - ширина массива символов
  - `substringWidth(String, offset, len)` - ширина подстроки
  - `getBaselinePosition()` - позиция базовой линии
  - `getFace()`, `getStyle()`, `getSize()` - геттеры атрибутов
  - `isBold()`, `isItalic()`, `isUnderlined()`, `isPlain()` - проверки стиля

**Файл**: `src/midp/display.c`

### 13. Дополнительные методы Graphics

**Проблема**: Отсутствовали вспомогательные методы Graphics.

**Решение**:
- Добавлен `copyArea()` - копирование области
- Добавлен `getDisplayColor()` - получение цвета дисплея
- Добавлены `setStrokeStyle()`, `getStrokeStyle()` - стиль линий (сплошная/пунктирная)
- Добавлены `setGrayScale()`, `getGrayScale()` - работа с оттенками серого

**Файл**: `src/midp/display.c`

### 14. TiledLayer.fillCells и animated tiles (НОВОЕ)

**Проблема**: TiledLayer не поддерживал fillCells для заполнения области ячеек и animated tiles для анимации.

**Решение**:
- Добавлен метод `fillCells(int col, int row, int numCols, int numRows, int tileIndex)` - заполняет прямоугольную область тайлов
- Добавлен метод `createAnimatedTile(int staticTileIndex)` - создаёт анимированный тайл, возвращает отрицательный индекс
- Добавлен метод `setAnimatedTile(int animatedTileIndex, int staticTileIndex)` - устанавливает текущий статический тайл для анимированного
- Добавлен метод `getAnimatedTile(int animatedTileIndex)` - получает текущий статический тайл
- Обновлён метод `paint()` для поддержки анимированных тайлов (отрицательные индексы)
- Добавлены новые поля в TiledLayer: cellMap, animatedTiles, animatedTileCount

**Файлы**: `src/jvm/stubs.c`, `src/midp/display.c`

### 15. Canvas pointer events (НОВОЕ)

**Проблема**: Canvas не поддерживал события указателя (pointer events) для тачскринов/мыши.

**Решение**:
- Добавлены callback-функции: `midp_call_pointerPressed()`, `midp_call_pointerReleased()`, `midp_call_pointerDragged()`
- Добавлены callback-функции: `midp_call_showNotify()`, `midp_call_hideNotify()`, `midp_call_sizeChanged()`
- Обновлена обработка SDL событий для вызова pointer event callbacks
- Добавлены методы Canvas:
  - `hasPointerEvents()` - проверяет поддержку событий указателя
  - `hasPointerMotionEvents()` - проверяет поддержку событий перетаскивания
  - `hasRepeatEvents()` - проверяет поддержку повторных событий клавиш
  - `isDoubleBuffered()` - проверяет двойную буферизацию

**Файлы**: `src/midp/display.c`, `src/sdl/sdl_graphics.c`

### 16. TextField расширенные методы (НОВОЕ)

**Проблема**: TextField имел ограниченный набор методов для работы с текстом.

**Решение**:
- Добавлены методы:
  - `getMaxSize()` - возвращает максимальный размер текста
  - `setMaxSize(int)` - устанавливает максимальный размер
  - `getConstraints()` - возвращает ограничения ввода
  - `setConstraints(int)` - устанавливает ограничения ввода
  - `getChars(char[])` - копирует текст в массив символов
  - `delete(int offset, int length)` - удаляет часть текста
  - `insert(String, int)` - вставляет строку в указанную позицию
  - `getCaretPosition()` - возвращает позицию курсора

**Файл**: `src/midp/form.c`

## Результат

После исправлений успешно запускаются:
- `re.jar` (RE Zombie Buster - обфусцированный код)
- `Bobby Carrot 1 [Rus].jar`
- `JavaTest3.jar`
- `Sudoku.jar`
- Большинство J2ME игр с Canvas/GameCanvas
- Другие J2ME игры с Command и Form

## Степень реализации MIDP 2.0

После исправлений реализовано **~90%** MIDP 2.0 (без сетевых возможностей):

### Полностью реализовано:
- ✅ Graphics (все методы включая drawRegion, copyArea, stroke style)
- ✅ Image (все методы включая трансформации)
- ✅ Font (все методы)
- ✅ Sprite (все методы включая collision detection и transforms)
- ✅ TiledLayer (все методы включая fillCells и animated tiles)
- ✅ LayerManager (все методы)
- ✅ GameCanvas (getKeyStates, flushGraphics)
- ✅ RMS (полная реализация)
- ✅ Media API (WAV, MIDI)
- ✅ Form, List, Alert, TextBox (high-level UI)
- ✅ Command, CommandListener
- ✅ Canvas (key events, pointer events, repaint, showNotify/hideNotify)
- ✅ Display (vibrate, backlight)
- ✅ TextField (полный набор методов)
- ✅ JSR 184 Mobile 3D Graphics (базовая программная реализация)

### Частично реализовано:
- ⚠️ Canvas (pointer events работают, но touch-игры требуют тестирования)
- ⚠️ JSR 184 M3G (базовый рендеринг, без сложных материалов и анимации)

### Не реализовано:
- ❌ Сетевые возможности (HttpConnection, SocketConnection)
- ❌ VideoControl (воспроизведение видео)
- ❌ MP3 поддержка

### 17. JSR 184 Mobile 3D Graphics API (НОВОЕ)

**Проблема**: Эмулятор не поддерживал 3D графику (M3G), что не позволяло запускать 3D игры.

**Решение**:
Создан файл `src/midp/mobile3d.c` с программной реализацией JSR 184:

**Реализованные классы:**
- `Graphics3D` - контекст рендеринга (getInstance, bindTarget, releaseTarget, clear, setViewport)
- `Transform` - матрицы трансформации 4x4 (setIdentity, postMultiply, postTranslate, postRotate, postScale)
- `VertexArray` - хранение вершин (позиции, нормали, текстурные координаты)
- `IndexBuffer` / `TriangleStripArray` - индексы треугольников
- `Camera` - камера (setPerspective, setParallel)
- `Light` - источники света (setType для ambient/directional/omni/spot)
- `World` - корневой узел сцены
- `Node`, `Group`, `Mesh`, `Sprite3D` - базовые 3D объекты
- `Background` - фон с цветом очистки
- `Appearance`, `Material`, `Texture2D` - материалы и текстуры
- `Image2D` - 2D изображение для текстур
- `AnimationController`, `AnimationTrack`, `KeyframeSequence` - анимация (заглушки)
- `MorphingMesh`, `SkinnedMesh` - сложные меши (заглушки)

**Программный рендерер:**
- Z-буферизация
- Отсечение задних граней (back-face culling)
- Перспективная проекция
- Текстурирование с перспективной коррекцией
- Базовое освещение (ambient + diffuse + specular)
- Поддержка до 8 источников света

**Файлы:** `src/midp/mobile3d.c`, `src/jvm/stubs.c`, `src/jvm/native.c`

## Сборка

```bash
# Debug версия (с подробным логированием)
make

# Release версия
make DEBUG=0

# Очистка
make clean
```

## Использование

```bash
# Запуск с GUI
./bin/j2me-emulator game.jar

# Тестовый запуск без GUI
./bin/j2me-emulator --headless game.jar

# С указанием класса MIDlet
./bin/j2me-emulator -m com.example.Game game.jar

# С кастомным разрешением
./bin/j2me-emulator -w 320 -h 480 game.jar
```
