import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.RecordStore;
import java.io.*;

public class ArrayTestMidlet extends MIDlet {
    Display display;
    private TestCanvas canvas;
    
    public void startApp() {
        display.setCurrent(canvas);
        new Thread(canvas).start();
    }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
    
    public ArrayTestMidlet() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
    }
}

final class TestCanvas extends Canvas implements Runnable {
    private ArrayTestMidlet midlet;
    
    // State machine
    private byte l = 0;
    private static final byte STATE_TESTS = 2;
    private static final byte STATE_RESULTS = 3;
    
    // Test results
    private byte[] o = new byte[30];
    private static final byte RESULT_PASS = 1;
    private static final byte RESULT_FAIL = 2;
    private static final byte RESULT_HANG = 3;  // New: test caused hang
    
    // Display flag
    public boolean d = false;
    
    // Exit flag
    public boolean e = false;
    
    // Screen dimensions
    private int i;
    private int j;
    
    // Soft key codes
    private int I = -6;
    private int J = -7;
    
    // Key state flags
    private boolean A, B, C, D, E, F, G, H;
    
    // Test state
    private int currentTest = 0;
    private int totalTests = 30;
    private int testDelay = 0;
    
    // Current test name for hang detection
    private String currentTestName = "init";
    
    // Log for failed tests only
    private String[] failLog = new String[30];
    private int failCount = 0;
    
    // Diagnostics
    private int repaintCount = 0;
    private int updateCallCount = 0;
    private int paintCount = 0;
    private boolean firstUpdateCalled = false;
    private boolean firstPaintCalled = false;
    private int loopCount = 0;
    
    // Bug detection
    private boolean showNotifyCalled = false;
    private boolean dWasEverTrue = false;
    private boolean repaintBlockedByDFlag = false;
    
    // Memory
    private Runtime runtime;
    private long minMemory = Long.MAX_VALUE;
    
    // Resource loading tests
    private Image testImage = null;
    private boolean imageLoadSuccess = false;
    private String imageLoadError = "";
    
    // Test names
    private String[] testNames;
    private String[] a;
    
    public TestCanvas(ArrayTestMidlet midlet) {
        this.midlet = midlet;
        this.runtime = Runtime.getRuntime();
        currentTestName = "constructor";
        
        this.k();
        
        try {
            this.I = Integer.parseInt(midlet.getAppProperty("X-SoftKey1"));
            this.J = Integer.parseInt(midlet.getAppProperty("X-SoftKey2"));
        } catch (Exception ex) {
            this.I = -6;
            this.J = -7;
        }
        
        this.setFullScreenMode(true);
        this.i = getWidth();
        this.j = getHeight();
        
        // Test image creation
        try {
            if (this.i > 0 && this.j > 0) {
                testImage = Image.createImage(this.i, this.j);
                imageLoadSuccess = (testImage != null);
            } else {
                testImage = Image.createImage(1, 1);
                imageLoadSuccess = (testImage != null);
            }
        } catch (Throwable t) {
            imageLoadError = t.getClass().getName();
            imageLoadSuccess = false;
        }
        
        for (int idx = 0; idx < this.o.length; idx++) {
            this.o[idx] = 0;
        }
        
        this.testNames = new String[] {
            "1. Safe null check",        // CRITICAL: Safe way to check null
            "2. NPE on null.equals",     // CRITICAL: This may hang!
            "3. NPE on null.toString",   // Similar issue
            "4. NPE on null.length",     // String length on null
            "5. NPE on null array",      // Array access on null
            "6. ClassCastException",
            "7. ArrayIndexBounds",
            "8. NegativeArraySize",
            "9. Arithmetic /zero",
            "10. d flag logic",
            "11. showNotify called",
            "12. d becomes true",
            "13. paint() works",
            "14. Thread starts",
            "15. Image create",
            "16. Image not null",
            "17. Resource stream",
            "18. Array create",
            "19. Large object",
            "20. Synchronization",
            "21. Thread sleep",
            "22. Thread yield",
            "23. System time",
            "24. System.gc",
            "25. Runtime",
            "26. Font default",
            "27. Graphics setColor",
            "28. Graphics drawLine",
            "29. Array copy",
            "30. Integer parse"
        };
        
        currentTestName = "ready";
        this.l = STATE_TESTS;
    }
    
    private void k() {
        this.a = new String[] {
            "NPE Hang Detection",
            "Testing...",
            "PASS",
            "FAIL",
            "Press FIRE",
            "Results",
            "HANG DETECTED!",
            "No bugs"
        };
    }
    
    public void run() {
        boolean var5 = true;
        
        while (!this.e) {
            loopCount++;
            long loopStart = System.currentTimeMillis();
            
            long freeMem = runtime.freeMemory();
            if (freeMem < minMemory) minMemory = freeMem;
            
            if (this.d && var5) {
                if (!dWasEverTrue) dWasEverTrue = true;
                repaintCount++;
                var5 = false;
                try {
                    this.repaint();
                    this.serviceRepaints();
                } catch (Exception ex) {}
            } else if (!this.d && var5) {
                repaintBlockedByDFlag = true;
            }
            
            updateCallCount++;
            boolean result = false;
            try {
                result = this.a();
            } catch (Throwable t) {
                // Unexpected exception in update
            }
            var5 |= result;
            
            long elapsed = System.currentTimeMillis() - loopStart;
            if (elapsed < 62L) {
                try {
                    Thread.sleep(62L - elapsed);
                } catch (Exception ex) {}
            }
            
            if (this.l == STATE_RESULTS && this.testDelay > 50) {
                this.e = true;
            }
        }
        
        midlet.notifyDestroyed();
    }
    
    private boolean a() {
        if (!firstUpdateCalled) firstUpdateCalled = true;
        
        switch (this.l) {
            case STATE_TESTS:
                return this.c();
            case STATE_RESULTS:
                return this.d();
            default:
                return false;
        }
    }
    
    private boolean c() {
        if (this.testDelay > 0) {
            this.testDelay--;
            return false;
        }
        
        if (this.currentTest < this.totalTests) {
            this.runTest();
            this.currentTest++;
            this.testDelay = 2;
            return true;
        } else {
            this.l = STATE_RESULTS;
            this.testDelay = 0;
            return true;
        }
    }
    
    private boolean d() {
        this.testDelay++;
        if (this.H && (this.E || this.F || this.G)) {
            this.e = true;
            return true;
        }
        return false;
    }
    
    private void runTest() {
        boolean pass = false;
        String failReason = "";
        currentTestName = testNames[this.currentTest];
        
        try {
            switch (this.currentTest) {
                // ===== CRITICAL NPE TESTS FIRST =====
                case 0: {
                    // SAFE null check - this should always work
                    String s = null;
                    pass = (s == null);  // Safe comparison
                    if (!pass) failReason = "null check failed";
                    break;
                }
                case 1: {
                    // CRITICAL: NPE on null.equals - MAY HANG ON SOME EMULATORS
                    // This is the bug pattern from original code!
                    try {
                        String s = null;
                        // Original code might do: if (s.equals("x"))
                        // This throws NPE - but some emulators HANG on NPE!
                        boolean eq = s.equals("test");
                        pass = false;
                        failReason = "NPE not thrown";
                    } catch (NullPointerException npe) {
                        pass = true;  // NPE is expected
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong exception: " + t.getClass().getName();
                    }
                    break;
                }
                case 2: {
                    // NPE on null.toString
                    try {
                        Object obj = null;
                        String s = obj.toString();
                        pass = false;
                        failReason = "NPE not thrown";
                    } catch (NullPointerException npe) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                case 3: {
                    // NPE on null.length
                    try {
                        String s = null;
                        int len = s.length();
                        pass = false;
                        failReason = "NPE not thrown";
                    } catch (NullPointerException npe) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                case 4: {
                    // NPE on null array access
                    try {
                        int[] arr = null;
                        int x = arr[0];
                        pass = false;
                        failReason = "NPE not thrown";
                    } catch (NullPointerException npe) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                // ===== OTHER EXCEPTION TESTS =====
                case 5: {
                    // ClassCastException
                    try {
                        Object obj = new Integer(5);
                        String s = (String)obj;
                        pass = false;
                        failReason = "ClassCast not thrown";
                    } catch (ClassCastException cce) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                case 6: {
                    // ArrayIndexOutOfBoundsException
                    try {
                        int[] arr = new int[5];
                        int x = arr[100];
                        pass = false;
                        failReason = "IndexBounds not thrown";
                    } catch (ArrayIndexOutOfBoundsException aioobe) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                case 7: {
                    // NegativeArraySizeException
                    try {
                        int[] arr = new int[-5];
                        pass = false;
                        failReason = "NegArray not thrown";
                    } catch (NegativeArraySizeException nase) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                case 8: {
                    // ArithmeticException
                    try {
                        int x = 10 / 0;
                        pass = false;
                        failReason = "Arithmetic not thrown";
                    } catch (ArithmeticException ae) {
                        pass = true;
                    } catch (Throwable t) {
                        pass = false;
                        failReason = "Wrong: " + t.getClass().getName();
                    }
                    break;
                }
                // ===== DISPLAY/THREAD TESTS =====
                case 9: {
                    pass = dWasEverTrue || showNotifyCalled || repaintBlockedByDFlag;
                    if (!pass) failReason = "d flag broken";
                    break;
                }
                case 10: {
                    pass = showNotifyCalled;
                    if (!pass) failReason = "showNotify not called";
                    break;
                }
                case 11: {
                    pass = dWasEverTrue || this.d;
                    if (!pass) failReason = "d never true";
                    break;
                }
                case 12: {
                    pass = paintCount > 0;
                    if (!pass) failReason = "paint() not called";
                    break;
                }
                case 13: {
                    pass = firstUpdateCalled;
                    if (!pass) failReason = "Thread not started";
                    break;
                }
                case 14: {
                    pass = imageLoadSuccess;
                    if (!pass) failReason = "Image err: " + imageLoadError;
                    break;
                }
                case 15: {
                    pass = testImage != null;
                    if (!pass) failReason = "Image null";
                    break;
                }
                case 16: {
                    // Resource stream
                    try {
                        InputStream is = getClass().getResourceAsStream("/x");
                        if (is != null) is.close();
                        pass = true;
                    } catch (Throwable t) {
                        pass = true;  // Mechanism works
                    }
                    break;
                }
                case 17: {
                    // Array create
                    try {
                        int[] arr = new int[10];
                        arr[0] = 1;
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "Array: " + t.getClass().getName();
                    }
                    break;
                }
                case 18: {
                    // Large object
                    try {
                        byte[] large = new byte[65536];
                        large[0] = 1;
                        pass = true;
                    } catch (OutOfMemoryError oom) {
                        pass = true;  // OK to be OOM
                    } catch (Throwable t) {
                        failReason = "Large: " + t.getClass().getName();
                    }
                    break;
                }
                case 19: {
                    // Synchronization
                    try {
                        Object lock = new Object();
                        synchronized (lock) {
                            lock.notify();
                        }
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "Sync: " + t.getClass().getName();
                    }
                    break;
                }
                case 20: {
                    // Thread sleep
                    try {
                        Thread.sleep(1);
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "Sleep: " + t.getClass().getName();
                    }
                    break;
                }
                case 21: {
                    // Thread yield
                    try {
                        Thread.yield();
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "Yield: " + t.getClass().getName();
                    }
                    break;
                }
                case 22: {
                    // System time
                    try {
                        long time = System.currentTimeMillis();
                        pass = time >= 0;
                    } catch (Throwable t) {
                        failReason = "Time: " + t.getClass().getName();
                    }
                    break;
                }
                case 23: {
                    // System.gc
                    try {
                        System.gc();
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "GC: " + t.getClass().getName();
                    }
                    break;
                }
                case 24: {
                    // Runtime
                    try {
                        Runtime rt = Runtime.getRuntime();
                        pass = rt != null;
                    } catch (Throwable t) {
                        failReason = "Runtime: " + t.getClass().getName();
                    }
                    break;
                }
                case 25: {
                    // Font
                    try {
                        Font f = Font.getDefaultFont();
                        pass = f != null;
                    } catch (Throwable t) {
                        failReason = "Font: " + t.getClass().getName();
                    }
                    break;
                }
                case 26: {
                    // Graphics setColor
                    try {
                        if (testImage != null) {
                            Graphics g = testImage.getGraphics();
                            g.setColor(0xFF0000);
                        }
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "SetColor: " + t.getClass().getName();
                    }
                    break;
                }
                case 27: {
                    // Graphics drawLine
                    try {
                        if (testImage != null) {
                            Graphics g = testImage.getGraphics();
                            g.drawLine(0, 0, 10, 10);
                        }
                        pass = true;
                    } catch (Throwable t) {
                        failReason = "DrawLine: " + t.getClass().getName();
                    }
                    break;
                }
                case 28: {
                    // Array copy
                    try {
                        int[] src = {1, 2, 3};
                        int[] dst = new int[3];
                        System.arraycopy(src, 0, dst, 0, 3);
                        pass = dst[0] == 1;
                    } catch (Throwable t) {
                        failReason = "ArrayCopy: " + t.getClass().getName();
                    }
                    break;
                }
                case 29: {
                    // Integer parse
                    try {
                        int x = Integer.parseInt("123");
                        pass = x == 123;
                    } catch (Throwable t) {
                        failReason = "Parse: " + t.getClass().getName();
                    }
                    break;
                }
            }
            
            this.o[this.currentTest] = pass ? RESULT_PASS : RESULT_FAIL;
            
            if (!pass && failCount < failLog.length) {
                failLog[failCount++] = testNames[this.currentTest] + ": " + failReason;
            }
            
        } catch (Throwable t) {
            this.o[this.currentTest] = RESULT_FAIL;
            if (failCount < failLog.length) {
                failLog[failCount++] = testNames[this.currentTest] + ": THROW " + t.getClass().getName();
            }
        }
        
        currentTestName = "done_" + currentTest;
    }
    
    public void paint(Graphics g) {
        if (!firstPaintCalled) firstPaintCalled = true;
        paintCount++;
        
        if (g == null) return;
        
        switch (this.l) {
            case STATE_TESTS:
                paintTests(g);
                break;
            case STATE_RESULTS:
                paintResults(g);
                break;
        }
    }
    
    private void paintTests(Graphics g) {
        g.setColor(0);
        g.fillRect(0, 0, i, j);
        
        int y = 10;
        g.setColor(0xFFFFFF);
        g.drawString(a[1], i >> 1, y, Graphics.TOP | Graphics.HCENTER);
        y += 25;
        
        int pw = (i - 20) * currentTest / totalTests;
        g.setColor(0x00AA00);
        g.fillRect(10, y, pw, 10);
        g.setColor(0x444444);
        g.fillRect(10 + pw, y, (i - 20) - pw, 10);
        y += 20;
        
        // Show current test (for hang detection!)
        g.setColor(0xFFFF00);
        g.drawString("NOW: " + currentTestName, 5, y, Graphics.TOP | Graphics.LEFT);
        y += 18;
        
        if (currentTest < totalTests && o[currentTest] != 0) {
            g.setColor(o[currentTest] == RESULT_FAIL ? 0xFF6666 : 0x66FF66);
            String st = o[currentTest] == RESULT_FAIL ? "FAIL" : "OK";
            g.drawString(st + ": " + testNames[currentTest], 5, y, Graphics.TOP | Graphics.LEFT);
        }
    }
    
    private void paintResults(Graphics g) {
        g.setColor(0);
        g.fillRect(0, 0, i, j);
        
        int y = 10;
        int failures = 0;
        for (int idx = 0; idx < totalTests; idx++) {
            if (o[idx] == RESULT_FAIL) failures++;
        }
        
        if (failures > 0) {
            g.setColor(0xFF0000);
            g.drawString(a[6] + " (" + failures + ")", i >> 1, y, Graphics.TOP | Graphics.HCENTER);
        } else {
            g.setColor(0x00FF00);
            g.drawString(a[7], i >> 1, y, Graphics.TOP | Graphics.HCENTER);
        }
        y += 18;
        
        g.setColor(0xFF8888);
        for (int idx = 0; idx < failCount && y < j - 35; idx++) {
            g.drawString(failLog[idx], 3, y, Graphics.TOP | Graphics.LEFT);
            y += 12;
        }
        
        if (failCount == 0) {
            g.setColor(0x00FF00);
            g.drawString("All tests passed!", 5, y, Graphics.TOP | Graphics.LEFT);
        }
        
        y = j - 30;
        g.setColor(0x888888);
        g.drawString("d=" + d + " paint=" + paintCount + " loop=" + loopCount, 3, y, Graphics.TOP | Graphics.LEFT);
        y += 12;
        g.drawString("lastTest=" + currentTestName, 3, y, Graphics.TOP | Graphics.LEFT);
    }
    
    public final void keyPressed(int keyCode) {
        if (keyCode == 0) return;
        H = true;
        
        if (keyCode == I) F = true;
        else if (keyCode == J) G = true;
        else {
            if (keyCode == 50) A = true;
            else if (keyCode == 56) B = true;
            else if (keyCode == 52) C = true;
            else if (keyCode == 54) D = true;
            else if (keyCode == 53) E = true;
            else {
                try {
                    int ga = getGameAction(keyCode);
                    if (ga == UP) A = true;
                    else if (ga == DOWN) B = true;
                    else if (ga == LEFT) C = true;
                    else if (ga == RIGHT) D = true;
                    else if (ga == FIRE) E = true;
                } catch (Exception ex) {}
            }
        }
    }
    
    public final void keyReleased(int keyCode) {
        if (keyCode == 0) return;
        
        if (keyCode == I) F = false;
        else if (keyCode == J) G = false;
        else {
            if (keyCode == 50) A = false;
            else if (keyCode == 56) B = false;
            else if (keyCode == 52) C = false;
            else if (keyCode == 54) D = false;
            else if (keyCode == 53) E = false;
            else {
                try {
                    int ga = getGameAction(keyCode);
                    if (ga == UP) A = false;
                    else if (ga == DOWN) B = false;
                    else if (ga == LEFT) C = false;
                    else if (ga == RIGHT) D = false;
                    else if (ga == FIRE) E = false;
                } catch (Exception ex) {}
            }
        }
    }
    
    public void showNotify() {
        showNotifyCalled = true;
        d = true;
    }
    
    public void hideNotify() {
        d = false;
    }
}
