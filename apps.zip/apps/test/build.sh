#!/bin/bash

# J2ME Build Script
# Pattern: Build script like build.bat from original

LIB_DIR="lib"
SRC_DIR="src"
CLS_DIR="classes"
BIN_DIR="bin"

# Create directories
mkdir -p $CLS_DIR
mkdir -p $BIN_DIR

# Compile
echo "Compiling..."
javac -bootclasspath $LIB_DIR/cldc_1.1.jar:$LIB_DIR/midp_2.0.jar \
      -source 1.3 -target 1.3 \
      -d $CLS_DIR \
      $SRC_DIR/*.java

if [ $? -ne 0 ]; then
    echo "Compilation failed!"
    exit 1
fi

# Create JAR
echo "Creating JAR..."
cd $CLS_DIR
jar cfm ../$BIN_DIR/ArrayTest.jar ../manifest.mf *.class
cd ..

# Create JAD
JAR_SIZE=$(stat -c%s "$BIN_DIR/ArrayTest.jar" 2>/dev/null || stat -f%z "$BIN_DIR/ArrayTest.jar")
cat > $BIN_DIR/ArrayTest.jad << EOF
MIDlet-1: ArrayTest,,ArrayTestMidlet
MIDlet-Name: ArrayTest
MIDlet-Version: 1.0.0
MIDlet-Vendor: Test
MicroEdition-Configuration: CLDC-1.1
MicroEdition-Profile: MIDP-2.0
MIDlet-Jar-URL: ArrayTest.jar
MIDlet-Jar-Size: $JAR_SIZE
EOF

echo "Build complete!"
echo "JAR: $BIN_DIR/ArrayTest.jar"
echo "JAD: $BIN_DIR/ArrayTest.jad"
