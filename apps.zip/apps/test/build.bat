@echo off
REM J2ME Build Script
REM Pattern: Build script like in original

set LIB_DIR=lib
set SRC_DIR=src
set CLS_DIR=classes
set BIN_DIR=bin

REM Create directories
if not exist %CLS_DIR% mkdir %CLS_DIR%
if not exist %BIN_DIR% mkdir %BIN_DIR%

REM Compile
echo Compiling...
javac -bootclasspath %LIB_DIR%/cldc_1.1.jar;%LIB_DIR%/midp_2.0.jar -source 1.3 -target 1.3 -d %CLS_DIR% %SRC_DIR%/*.java

if errorlevel 1 (
    echo Compilation failed!
    exit /b 1
)

REM Create JAR
echo Creating JAR...
cd %CLS_DIR%
jar cfm ../%BIN_DIR%/ArrayTest.jar ../manifest.mf *.class
cd ..

REM Create JAD
for %%A in (%BIN_DIR%/ArrayTest.jar) do set JAR_SIZE=%%~zA

echo MIDlet-1: ArrayTest,,ArrayTestMidlet> %BIN_DIR%/ArrayTest.jad
echo MIDlet-Name: ArrayTest>> %BIN_DIR%/ArrayTest.jad
echo MIDlet-Version: 1.0.0>> %BIN_DIR%/ArrayTest.jad
echo MIDlet-Vendor: Test>> %BIN_DIR%/ArrayTest.jad
echo MicroEdition-Configuration: CLDC-1.1>> %BIN_DIR%/ArrayTest/jad
echo MicroEdition-Profile: MIDP-2.0>> %BIN_DIR%/ArrayTest.jad
echo MIDlet-Jar-URL: ArrayTest.jar>> %BIN_DIR%/ArrayTest.jad
echo MIDlet-Jar-Size: %JAR_SIZE%>> %BIN_DIR%/ArrayTest.jad

echo Build complete!
echo JAR: %BIN_DIR%/ArrayTest.jar
echo JAD: %BIN_DIR%/ArrayTest.jad
