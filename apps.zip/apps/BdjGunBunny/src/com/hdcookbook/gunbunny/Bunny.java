
/*  
 * Copyright (c) 2008, Sun Microsystems, Inc.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of Sun Microsystems nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 *  Note:  In order to comply with the binary form redistribution 
 *         requirement in the above license, the licensee may include 
 *         a URL reference to a copy of the required copyright notice, 
 *         the list of conditions and the disclaimer in a human readable 
 *         file with the binary form of the code that is subject to the
 *         above license.  For example, such file could be put on a 
 *         Blu-ray disc containing the binary form of the code or could 
 *         be put in a JAR file that is broadcast via a digital television 
 *         broadcast medium.  In any event, you must include in any end 
 *         user licenses governing any code that includes the code subject 
 *         to the above license (in source and/or binary form) a disclaimer 
 *         that is at least as protective of Sun as the disclaimers in the 
 *         above license.
 * 
 *         A copy of the required copyright notice, the list of conditions and
 *         the disclaimer will be maintained at 
 *         https://hdcookbook.dev.java.net/misc/license.html .
 *         Thus, licensees may comply with the binary form redistribution
 *         requirement with a text file that contains the following text:
 * 
 *             A copy of the license(s) governing this code is located
 *             at https://hdcookbook.dev.java.net/misc/license.html
 */

package com.hdcookbook.gunbunny;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;


/**
 * This class manages the Bunny's state.  It knows when the bunny
 * is shooting and it controls the bunny's sprite and the carrot's sprite.
 * It knows about the turtle troooper squad and the turtle saucer, so it
 * can detect a hit.
 * 
 * @author Shant Mardigian
 * @author Bill Foote
 */
public class Bunny {
    ImageSprite bunnySprite;
    ImageSprite carrotSprite;
    
    TurtleTrooperSquad squad;
    TurtleSaucer saucer;
    
    int xloc = 872;
    int yloc = 775;
    int xSpeed = 0;
    int bunnyW = 0;
    boolean shooting = false;
    boolean startShot = false;
    int carrotY;
    int carrotX;
    
    int trooperHits = 0;
    int saucerHits = 0;

    private Rectangle hitRect = new Rectangle();
    
    
    public Bunny(Image bunnyImg, Image carrotBullet, TurtleTrooperSquad squad, 
    		 TurtleSaucer saucer)
    {
        this.bunnySprite = new ImageSprite(bunnyImg);
	bunnySprite.initPosition(xloc, yloc);
        this.carrotSprite = new ImageSprite(carrotBullet);
	this.carrotSprite.initImageOff();
	this.shooting = false;
        this.squad = squad;
        this.saucer = saucer;
        
        bunnyW = bunnyImg.getWidth(null);
    }

    /**
     * Called to move us from side to side when an arrow key is pressed.
     **/
    public synchronized void setXSpeed(int speed) {
	xSpeed = speed;
    }

    /**
     * Called to ask us to fire if we can, when the OK button is pressed.
     **/
    public synchronized void fire() {
	if (shooting) {
	    return;
	}
	startShot = true;
	carrotY = yloc + 10;
	carrotX = xloc + (bunnySprite.getWidth() - carrotSprite.getWidth()) / 2;
    }

    /**
     * Move our state to the next frame of animation.
     **/
    public void nextFrame(int numFrames) {
	if (xSpeed == 0) {
	    bunnySprite.nextFrame();
	} else {
	    xloc += xSpeed * numFrames;
	    if (xloc < 10) {
		xloc = 10;
	    } else if (xloc > 1650) {
		xloc = 1650;
	    }
	    bunnySprite.nextFrame(xloc, yloc);
	}
	if (startShot) {
	    shooting = true;
	    startShot = false;
	} else if (shooting) {
	    int dy = -22 * numFrames;
	    carrotSprite.getBounds(hitRect);
	    hitRect.height -= dy;
	    hitRect.y += dy;
	    boolean hit = squad.hitBy(hitRect);
	    if (hit) {
		trooperHits++;
	    } else if (saucer.hitBy(hitRect)) {
		hit = true;
		saucerHits++;
	    }
	    if (hit) {
		shooting = false;
	    } 
	}
	if (shooting) {
	    carrotY -= 22 * numFrames;
	    if (carrotY < 24) {
		shooting = false;
		carrotSprite.nextFrameOff();
	    } else {
		carrotSprite.nextFrame(carrotX, carrotY);
	    }
	} else {
	    carrotSprite.nextFrameOff();
	}
    }

    /**
     * Paint the two sprites we own, that is, the bunny and the carrot.
     **/
    public void paintFrame(Graphics2D g, boolean paintAll, Animator animator) {
	bunnySprite.paintFrame(g, paintAll, animator);
	carrotSprite.paintFrame(g, paintAll, animator);
    }
}
