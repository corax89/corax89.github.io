/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 

package com.sun.lwuit.uidemo;

import com.sun.lwuit.Button;
import com.sun.lwuit.ComboBox;
import com.sun.lwuit.Command;
import com.sun.lwuit.Component;
import com.sun.lwuit.Container;
import com.sun.lwuit.Dialog;
import com.sun.lwuit.Form;
import com.sun.lwuit.Label;
import com.sun.lwuit.TextArea;
import com.sun.lwuit.TextField;
import com.sun.lwuit.animations.CommonTransitions;
import com.sun.lwuit.animations.Transition;
import com.sun.lwuit.events.ActionEvent;
import com.sun.lwuit.events.ActionListener;
import com.sun.lwuit.layouts.BoxLayout;
import com.sun.lwuit.layouts.FlowLayout;

/**
 * Demonstrates the dialog box functionality 
 *
 * @author Shai Almog
 */
public class DialogDemo extends Demo {
    private static final String[] ALARM_TEXT = {"Alarm", "Confirmation", "Error", "Info", "Warning"};
    private static final int[] ALARM_VALUES = {
        Dialog.TYPE_ALARM, Dialog.TYPE_CONFIRMATION, 
        Dialog.TYPE_ERROR, Dialog.TYPE_INFO, Dialog.TYPE_WARNING
    };
    private static final String[] TINT_DESCRIPTION = {"Black", "White", "Red", "Green", "Blue"};
    private static final int[] TINT_COLOR = {0x8f000000, 0x8fffffff, 0x8fff0000, 0x8f00ff00, 0x8f0000ff};
    private static final String[] TRANSITION_TEXT = {"Slide Up", "Slide Down", "Fade", "None"};
    
    public String getName() {
        return "Dialogs";
    }

    protected String getHelp() {
        return "Dialog boxes are modal in the toolkit thus allowing the calling thread to block " +
            "even if it is the event dispatch thread. Dialogs can occupy parts of the screen that " +
            "can be defined by the developer";
    }

    
    protected void execute(final Form f) {
        f.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
       
        Button b = new Button("Show Dialog");
        b.getStyle().setBgTransparency(100);
        final ComboBox sound = new ComboBox(ALARM_TEXT);
        sound.getStyle().setBgTransparency(100);
        final ComboBox tint = new ComboBox(TINT_DESCRIPTION);
        tint.getStyle().setBgTransparency(100);
        final ComboBox transition = new ComboBox(TRANSITION_TEXT);
        transition.getStyle().setBgTransparency(100);
        final TextArea title = new TextField("Title");   
        title.getStyle().setBgTransparency(100);
        final TextArea body = new TextArea("This is the body of the alert....", 3, 20);
        body.getStyle().setBgTransparency(100);
        final TextField timeoutText = new TextField("0");
        timeoutText.setConstraint(TextArea.NUMERIC);
        timeoutText.setInputModeOrder(new String[] {"123"});
        timeoutText.getStyle().setBgTransparency(100);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                f.setTintColor(TINT_COLOR[tint.getSelectedIndex()]);
                Command okCommand = new Command("OK");
                Command cancelCommand = new Command("Cancel");
                int timeout = Integer.parseInt(timeoutText.getText());
                Transition transitionSelection = null;
                switch(transition.getSelectedIndex()) {
                case 0:
                    transitionSelection = CommonTransitions.createSlide(CommonTransitions.SLIDE_VERTICAL, true, 1000);
                    break;
                case 1:
                    transitionSelection = CommonTransitions.createSlide(CommonTransitions.SLIDE_VERTICAL, false, 1000);
                    break;
                case 2:
                    transitionSelection = CommonTransitions.createFade(400);
                    break;
                }
                Command result = Dialog.show(title.getText(), body.getText(), okCommand,
                    new Command[] {okCommand, cancelCommand}, ALARM_VALUES[sound.getSelectedIndex()], null, 
                    timeout, transitionSelection);
                if(result == okCommand) {
                    Dialog.show("Title", "OK Selected", "OK", null);
                } else {
                    if(result == null) {
                        Dialog.show("Title", "Dialog timed out", "OK", null);
                    } else {
                        Dialog.show("Title", "Cancel Selected", "OK", null);
                    }
                }
            }
        });

        Container largest = createPair("Transition", transition, 30);
        int largestW = largest.getComponentAt(0).getPreferredW();
        f.addComponent(createPair("Title", title, largestW));
        f.addComponent(createPair("Body", body, largestW));
        f.addComponent(createPair("Timeout", timeoutText, largestW));
        f.addComponent(createPair("Sound", sound, largestW));
        f.addComponent(createPair("Tint Color", tint, largestW));
        f.addComponent(largest);
        Label l = new Label("The button shows the appropriate dialog");
        l.getStyle().setBgTransparency(100);
        f.addComponent(l);
        Container buttonContainer = new Container(new FlowLayout(Component.CENTER));
        b.getStyle().setPadding(5, 5, 7, 7);
        buttonContainer.addComponent(b);
        f.addComponent(buttonContainer);

    }
}
