/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 

package com.sun.lwuit.uidemo;

import com.sun.lwuit.Button;
import com.sun.lwuit.Form;
import com.sun.lwuit.Graphics;
import com.sun.lwuit.Image;
import com.sun.lwuit.geom.Dimension;
import com.sun.lwuit.layouts.BoxLayout;
import com.sun.lwuit.util.Resources;
import java.io.IOException;

/**
 *
 * @author Shai Almog
 */
public class AnimationDemo extends Demo {

    public String getName() {
        return "Animations";
    }

    protected void execute(final Form f) {
        try {
            Resources images = UIDemoMIDlet.getResource("images");
            Image a = images.getImage("progress0.png");
            Image b = images.getImage("progress1.png");
            Image c = images.getImage("progress2.png");
            final Image[] secondAnimation = new Image[] {
                a, 
                b, 
                c, 
                a.rotate(90), 
                b.rotate(90), 
                c.rotate(90), 
                a.rotate(180), 
                b.rotate(180), 
                c.rotate(180), 
                a.rotate(270), 
                b.rotate(270), 
                c.rotate(270),
            };


            Button animation = new Button(UIDemoMIDlet.getResource("duke").getAnimation("duke3_1.gif"));
            animation.setBorderPainted(false);
            animation.getStyle().setBgTransparency(0);
            f.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
            f.addComponent(animation);

            Button animation2 = new Button() {

                        private int currentImage = 0;
                        private long lastInvoke;

                        public boolean animate() {
                            long current = System.currentTimeMillis();
                            if (current - lastInvoke > 50) {
                                lastInvoke = current;
                                currentImage++;
                                if (currentImage == secondAnimation.length) {
                                    currentImage = 0;
                                }
                                return true;
                            }
                            return false;
                        }

                        public void paint(Graphics g) {
                            g.drawImage(secondAnimation[currentImage], getX(), getY());
                        }
                    };

            animation2.setPreferredSize(new Dimension(secondAnimation[0].getWidth(), secondAnimation[0].getHeight()));
            animation2.setBorderPainted(false);
            animation2.getStyle().setBgTransparency(0);
            f.addComponent(animation2);

            f.registerAnimated(animation2);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
