/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
import javax.microedition.lcdui.Graphics;
import javax.microedition.media.control.VideoControl;

public class VideoCanvas extends MediaCanvas {

    private VideoControl vc;
    
    VideoCanvas(VideoControl vc) {
        this.vc = vc;
        vc.initDisplayMode(VideoControl.USE_DIRECT_VIDEO, this);
        vc.setVisible(true);
        centerVideo(getWidth(), getHeight());
    }

    public void paint(Graphics g) {
        g.setColor(getBackgroundColor());
        g.fillRect(0, 0, getWidth(), getHeight());
        drawMediaTitle(g);
        drawProgressBar(g);
    }
    
    private void centerVideo(int dispWidth, int dispHeight) {
        vc.setDisplayLocation((dispWidth - vc.getSourceWidth()) / 2,
                (dispHeight - vc.getSourceHeight()) / 2);
    }
    
    public int getProgressBarColor() {
        return 0xFFAA00;
    }
    
    public int getTextColor() {
        return 0xFFFF00;
    }
    
    public int getBackgroundColor() {
        return 0x000000;
    }

    protected void sizeChanged(int w, int h) {
        centerVideo(w, h);
    }
}
