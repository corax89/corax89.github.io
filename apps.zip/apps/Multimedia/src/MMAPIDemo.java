/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */

import javax.microedition.lcdui.*;
import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;
import javax.microedition.media.PlayerListener;
import javax.microedition.media.control.VideoControl;
import javax.microedition.midlet.MIDlet;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;

public class MMAPIDemo extends MIDlet 
        implements CommandListener, PlayerListener {
        
    private final Command exitCommand = new Command("Exit", Command.EXIT, 1);
    private final Command selectCommand = new Command("Select", Command.ITEM, 1);
    
    private List list;
    private Vector mediaFiles;
    private Player p;
    private MediaCanvas canvas;
    
    private class MediaFile {
        private String fileName;
        private String mimeType;
        private String title;
        
        public MediaFile(String title, String fileName, String mimeType) {
            this.fileName = fileName;
            this.mimeType = mimeType;
            this.title = title;
        }
        
        public String getFileName() {
            return fileName;
        }
        
        public String getMimeType() {
            return mimeType;
        }
        
        public String getTitle() {
            return title;
        }
    }
    
    private MediaFile getMediaFile(int index) {
        return (MediaFile) mediaFiles.elementAt(index);
    }
    
    private void initMediaFiles() {
        // TODO: move the strings to MIDlet properties
        mediaFiles = new Vector();
        mediaFiles.addElement(new MediaFile("AMR NarrowBand", 
                "amr-nb.amr", "audio/amr"));
        mediaFiles.addElement(new MediaFile("MIDI Song", 
                "pattern.mid", "audio/midi"));
        mediaFiles.addElement(new MediaFile("Wave audio file", 
                "test-wav.wav", "audio/x-wav"));
        mediaFiles.addElement(new MediaFile("Video MPEG", 
                "video.mpg", "video/mpeg"));
        mediaFiles.addElement(new MediaFile("Animated GIF",
                "animated.gif", "image/gif"));
    }

    private void initVideoCanvas(String title) throws MediaException {
        VideoControl vc = (VideoControl) p.getControl("VideoControl");
        if (vc != null) {
            canvas = new VideoCanvas(vc);
            canvas.init(this, p, title);
        }
    }
    
    private void initAudioCanvas(String title) throws MediaException {
        canvas = new AudioCanvas();
        canvas.init(this, p, title);
    }
    
    private void play(MediaFile mediaFile) {
        try {
            InputStream is = getClass().getResourceAsStream(mediaFile.getFileName());
            p = Manager.createPlayer(is, mediaFile.getMimeType());
            p.realize();
            
            if (mediaFile.getMimeType().startsWith("video") ||
                    mediaFile.getMimeType().startsWith("image")) {
                initVideoCanvas(mediaFile.getTitle());
            }
            else {
                initAudioCanvas(mediaFile.getTitle());
            }
            
            if (canvas != null) 
                Display.getDisplay(this).setCurrent(canvas);            
            
            p.addPlayerListener(this);
            p.prefetch();
            p.start();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public MMAPIDemo() {
        initMediaFiles();
        initList();
        Display.getDisplay(this).setCurrent(list);
    }
    
    private void initList() {
        list = new List("Select media file", Choice.IMPLICIT);
        list.setCommandListener(this);

        Enumeration mediaEnum = mediaFiles.elements();
        while (mediaEnum.hasMoreElements()) {
          list.append(((MediaFile) mediaEnum.nextElement()).getTitle(), null);
        }
        
        list.addCommand(exitCommand);
	list.addCommand(selectCommand);
    }
    
    public void playerUpdate(Player player, String event, Object data) {
        System.out.println("Received event " + event);
    }
    
    protected void startApp() {
    }
        
    protected void pauseApp() {
        if (p != null && p.getState() >= Player.STARTED) {
            try {
                canvas.stop();
                p.stop();
            }
            catch (MediaException me) {
                me.printStackTrace();
            }
        }
    }
    
    protected void destroyApp(boolean unconditional) {
    }
    
    private void stopAndClose(Player p) {
        if (p != null) {
            try {
                p.stop();
                p.close();
            }
            catch (MediaException me) {
                me.printStackTrace();
            }
        }
    }
    
    void cancelPlayback() {
        stopAndClose(p);
        p = null;
        Display.getDisplay(this).setCurrent(list);
    }
    
    public void commandAction(Command c, Displayable d) {
        if (c == exitCommand) {
            notifyDestroyed();
        }
        else if ((d == list && c == List.SELECT_COMMAND) || c == selectCommand) {
            play(getMediaFile(list.getSelectedIndex()));
	}
    }
}
