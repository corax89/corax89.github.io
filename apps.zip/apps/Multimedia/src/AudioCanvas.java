/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class AudioCanvas extends MediaCanvas {

    private Image image;
    
    AudioCanvas() {
        try {
            image=Image.createImage("/duke.png");
        }
        catch(Exception err) {
            System.out.println("Cannot create the Duke image: " + err);
        }
    }

    public void paint(Graphics g) {
        g.setColor(getBackgroundColor());
        g.fillRect(0, 0, getWidth(), getHeight());
        if (image != null) {
            int posX = (getWidth() - image.getWidth()) / 2;
            int posY = (getHeight() - image.getHeight()) / 2;
            g.drawImage(image, posX, posY, Graphics.LEFT | Graphics.TOP);
        }
        drawMediaTitle(g);
        drawProgressBar(g);
    }
        
    public int getProgressBarColor() {
        return 0x0000AA;
    }
    
    public int getTextColor() {
        return 0x0000BB;
    }
    
    public int getBackgroundColor() {
        return 0xFFFFFF;
    }

}
