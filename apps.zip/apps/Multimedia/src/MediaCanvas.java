/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */

import javax.microedition.lcdui.*;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;
import java.util.Timer;
import java.util.TimerTask;

public abstract class MediaCanvas extends Canvas implements CommandListener {
    
    private Player player; // a player associated with this canvas
    private Timer timer; // handles periodic repaints
    private MMAPIDemo parent;
    private String title;
    
    private final Command backCommand = new Command("Back", Command.BACK, 1);
    private final Command pauseCommand = new Command("Pause", Command.ITEM, 2);
    private final Command resumeCommand = new Command("Resume", Command.ITEM, 2);
    
    private static final int PROGRESS_BAR_X_OFFSET = 10;
    private static final int PROGRESS_BAR_Y_OFFSET = 15;
    private static final int PROGRESS_BAR_HEIGHT = 5;
    
    public abstract int getTextColor();
    public abstract int getBackgroundColor();
    public abstract int getProgressBarColor();
    
    public void setPlayer(Player player) {
        this.player = player;
    }
    
    public Player getPlayer() {
        return player;
    }
    
    public void setMediaTitle(String title) {
        this.title = title;
    }
    
    public String getMediaTitle() {
        return title;
    } 
    
    public void setParent(MMAPIDemo parent) {
        this.parent = parent;
    }
    
    public MMAPIDemo getParent() {
        return parent;
    }
    
    void drawProgressBar(Graphics g) {
        long mediaTime = 0;
        long duration = 0;

        int y = getHeight() - PROGRESS_BAR_Y_OFFSET;
        int fullWidth = getWidth() - 2*PROGRESS_BAR_X_OFFSET;
        int width = 0;

        try {
            mediaTime = player.getMediaTime();
            duration = player.getDuration();
            width = (int) (fullWidth * player.getMediaTime() / player.getDuration());
        } catch (IllegalStateException e) {
            /* ok, width set to 0 */
        }
        
        g.setColor(getProgressBarColor());
        g.drawRect(PROGRESS_BAR_X_OFFSET, y, fullWidth, PROGRESS_BAR_HEIGHT);
        g.fillRect(PROGRESS_BAR_X_OFFSET, y, width, PROGRESS_BAR_HEIGHT);
        drawTime(g);
    }
    
    void drawMediaTitle(Graphics g) {
        g.setColor(getTextColor());
        g.drawString("Now playing " + title, 
                10, 
                10, 
                Graphics.LEFT | Graphics.TOP);
    }
    
    private String formatTime(long ms) {
        // format the time in microseconds into (min : sec)
        String min = String.valueOf(ms / 60000000);
        String sec = String.valueOf(ms / 1000000 % 60);
        return (min.length() == 1 ? "0" + min : min)
                + ":" 
                + (sec.length() == 1 ? "0" + sec : sec);
    }
    
    private void drawTime(Graphics g) {
        long time = 0;
        long duration = 0;
        try {
            duration = player.getDuration();
            time = player.getMediaTime();
        } catch (IllegalStateException e) {
            /* never mind, set to 0 */
        }
        g.setColor(getTextColor());
        String timeString = formatTime(time)
                + " / " 
                + formatTime(duration);
        
        g.drawString(timeString, 
                getWidth() - PROGRESS_BAR_X_OFFSET, 
                getHeight() - PROGRESS_BAR_Y_OFFSET - PROGRESS_BAR_HEIGHT, 
                Graphics.RIGHT | Graphics.BOTTOM);
    }
    
    void init(MMAPIDemo parent, Player p, String title) {
        setMediaTitle(title);
        setParent(parent);
        setPlayer(p);
        createMenu();
        scheduleRepaints();
    }
    
    private void createMenu() {
        addCommand(backCommand);
        addCommand(pauseCommand);
        setCommandListener(this);
    }
    
    private class RepaintTask extends TimerTask {
        public void run() {
            repaint();
        }
    }
    
    void scheduleRepaints() {
        timer = new Timer();
        timer.schedule(new RepaintTask(), 0, 500);
    }
    
    void stop() {
        timer.cancel();
    }
    
    public void commandAction(Command c, Displayable d) {
        if (c == backCommand) {
            stop();
            parent.cancelPlayback();
        }
        else if (c == pauseCommand) {
            try {
                getPlayer().stop();
            }
            catch (MediaException me) {
                me.printStackTrace();
            }
            removeCommand(pauseCommand);
            addCommand(resumeCommand);
        }
        else if (c == resumeCommand) {
            try {
                getPlayer().start();
            }
            catch (MediaException me) {
                me.printStackTrace();
            }
            removeCommand(resumeCommand);
            addCommand(pauseCommand);
        }
    }
}
