/*
 *
 * Copyright (c) 2008, Sun Microsystems, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of Sun Microsystems nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.sun.perseus.demo;

import org.w3c.dom.Document;
import org.w3c.dom.svg.SVGElement;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.m2g.ExternalResourceHandler;
import javax.microedition.m2g.SVGImage;
import javax.microedition.m2g.ScalableGraphics;
import javax.microedition.m2g.ScalableImage;
import java.io.IOException;
import java.io.InputStream;

/**
 * Loads single image and allows obtaining it scaled to different sizes.
 */
public class ImageLoader {

    /**
     * SVG image used for scaling
     */
    private static final String IMAGE_SCALER_RESOURCE = "/svg/imageScaler.svg";
    /**
     * Name of the image element in image scaler
     */
    private static final String IMAGE_ELEMENT_ID = "image";
    /**
     * Loaded image
     */
    private SVGImage svgImage;

    /**
     * Loads image.
     *
     * @param url Image URL
     * @throws java.io.IOException if I/O error occurred 
     */
    public void loadImage (final String url) throws IOException {

        final InputStream is =
            ImageLoader.class.getResourceAsStream (IMAGE_SCALER_RESOURCE);
        if (is == null) {
            throw new IOException (
                "Resource " + IMAGE_SCALER_RESOURCE
                    + " doesn't exist!");
        }

        svgImage = (SVGImage) ScalableImage.createImage (
            is,
            new ExternalResourceHandler() {
                public void requestResource (
                    final ScalableImage scalableImage,
                    final String imageName) {
                }
            });

        final InputStream is2 = ImageLoader.class.getResourceAsStream (url);

        svgImage.requestCompleted ("image", is2);
    }

    /**
     * Returns previously loaded image scaled to the given size.
     *
     * @param width  Width to be scaled to
     * @param height Height to be scaled to
     * @return image scaled to given size
     */
    public Image getScaledImage (int width, int height) {
        final ScalableGraphics scalableGraphics = ScalableGraphics.createInstance ();
        final Image image = Image.createImage (width, height);
        final Graphics g = image.getGraphics ();

        final Document svgDocument = svgImage.getDocument ();
        final SVGElement imageElement = (SVGElement) svgDocument.getElementById (IMAGE_ELEMENT_ID);

        imageElement.setFloatTrait ("width", width);
        imageElement.setFloatTrait ("height", height);

        scalableGraphics.bindTarget (g);
        scalableGraphics.render (0, 0, svgImage);
        scalableGraphics.releaseTarget ();
        return image;
    }
}
