--------------------------------------------------------------------------------
                  Payment API (JSR 229 API) Demonstration
--------------------------------------------------------------------------------

1. Introduction
	
	JBricks is a brick game (Arkanoid) using JSR229 Payment API for buying 
	additional lives and levels.


2. Project Structure

	jbricks.jad	JAD file	
	jbricks.jpp	Payment Update file
	src folder	Sources


3. Usage

	It can be paid for additional lives and levels by Premium Priced SMS 
	(PPSMS). You can update info about prices. It uses HTTPS server integrated
  in SDK.


4. Required APIs
    
    JSR 139 - Connected Limited Device Configuration (CLDC) 1.1
    JSR 118 - Mobile Information Device Profile (MIDP) 2.0
    JSR 205 - Wireless Messaging API (WMA) 2.0
    JSR 229 - Payment API
