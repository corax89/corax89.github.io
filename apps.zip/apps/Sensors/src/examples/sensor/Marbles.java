/*
 *
 * Copyright (c) 2008, Sun Microsystems, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of Sun Microsystems nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package examples.sensor;

import java.io.IOException;
import java.util.Vector;

import javax.microedition.io.Connector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.TextBox;
import javax.microedition.midlet.MIDlet;
import javax.microedition.sensor.ChannelInfo;
import javax.microedition.sensor.Data;
import javax.microedition.sensor.DataListener;
import javax.microedition.sensor.SensorConnection;
import javax.microedition.sensor.SensorInfo;
import javax.microedition.sensor.SensorManager;

/**
 * The Marbles demo displays marbles on the screen and they accelerate as the
 * user moves the device.
 */
public class Marbles extends MIDlet implements DataListener, CommandListener {

    private static final Command CMD_NEW_GAME =
            new Command("New Game", Command.SCREEN, 1);
    private static final Command CMD_EXIT =
            new Command("Exit", Command.EXIT, 1);

    private MarblesBoard marblesBoard;
    private SensorConnection sensor;
    private String[] channelNames;
    private boolean sensorSelected;
    private List sensorSelector;
    private SensorInfo[] sensorInfos;

    /**
     * Initialize marbles board and detect accelerometer sensor.
     */
    public Marbles() throws IOException {
        if (System.getProperty("microedition.sensor.version") == null) {
            Display.getDisplay(this).setCurrent(
                    new Alert("JSR256 is not supported!"),
                    new TextBox("ERROR", "JSR256 is not supported!", 255, 0));
            return;
            // throw new IllegalArgumentException("JSR256 is not supported!");
        }
        marblesBoard = new MarblesBoard();
        marblesBoard.addCommand(CMD_EXIT);
        marblesBoard.addCommand(CMD_NEW_GAME);
        marblesBoard.setCommandListener(this);

        sensorInfos = getSensorInfos();
        if (sensorInfos == null) {
            Display.getDisplay(this).setCurrent(
                    new Alert("Valid accelerometer sensor not found"),
                    new TextBox("ERROR",
                            "Valid accelerometer sensor not found", 255, 0));
            return;
            // throw new IllegalArgumentException(
            // "Valid accelerometer sensor not found");
        }
        sensorSelector = new List("Select accelerometer:", List.EXCLUSIVE);
        for (int i = 0; i < sensorInfos.length; i++) {
            sensorSelector.append(sensorInfos[i].getUrl(), null);
        }
        sensorSelector.addCommand(CMD_EXIT);
        sensorSelector.addCommand(CMD_NEW_GAME);
        sensorSelector.setCommandListener(this);
    }

    public void startApp() {
        if (!sensorSelected) {
            Display.getDisplay(this).setCurrent(sensorSelector);
        } else {
            marblesBoard.resetBoard();
            Display.getDisplay(this).setCurrent(marblesBoard);
            sensor.setDataListener(this, 1);
        }
    }

    public void pauseApp() {
        sensor.removeDataListener();
    }

    public void destroyApp(boolean unconditional) {
        if (sensor != null) {
            try {
                sensor.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        notifyDestroyed();
    }

    public void commandAction(Command c, Displayable d) {
        if (d.equals(marblesBoard)) {
            if (CMD_NEW_GAME.equals(c)) {
                marblesBoard.resetBoard();
            } else if (CMD_EXIT.equals(c)) {
                marblesBoard.stop();
                destroyApp(false);
                notifyDestroyed();
            }
        } else if (d.equals(sensorSelector)) {
            if (CMD_NEW_GAME.equals(c)) {
                new Thread() {
                    public void run() {
                        int idx = sensorSelector.getSelectedIndex();
                        channelNames =
                                getSensorInfoChannelsNames(sensorInfos[idx]);
                        try {
                            sensor =
                                    (SensorConnection) Connector
                                            .open(sensorInfos[idx].getUrl());
                            marblesBoard.resetBoard();
                            Display.getDisplay(Marbles.this).setCurrent(
                                    marblesBoard);
                            marblesBoard.start();
                            sensor.setDataListener(Marbles.this, 1);
                            sensorSelected = true;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            } else if (CMD_EXIT.equals(c)) {
                destroyApp(false);
                notifyDestroyed();
            }
        }
    }

    /**
     * Un-scale the scaled value.
     */
    private final double unscaleValue(double scaledValue, int scale) {
        double mult = 1.0;
        for (int i = 0; i < Math.abs(scale); i++) {
            mult *= 10.0;
        }
        return (scale > 0) ? scaledValue * mult : scaledValue / mult;
    }

    /**
     * Forwards unscaled acceleration data to the marbles board.
     */
    public void dataReceived(SensorConnection sensor, Data[] data,
            boolean isDataLost) {
        double[] accel = new double[3];
        for (int i = 0; i < data.length; i++) {
            for (int c = 0; c < 3; c++) {
                if (channelNames[c].equals(data[i].getChannelInfo().getName())) {
                    double val;
                    switch (data[i].getChannelInfo().getDataType()) {
                    case ChannelInfo.TYPE_DOUBLE:
                        val = data[i].getDoubleValues()[0];
                        break;
                    case ChannelInfo.TYPE_INT:
                        val = data[i].getIntValues()[0];
                        break;
                    default:
                        val = 0;
                    }
                    accel[c] =
                            unscaleValue(val, data[i].getChannelInfo()
                                    .getScale());
                    break;
                }
            }
            // if (channelNames[0].equals(data[i].getChannelInfo().getName())) {
            // accel[0] =
            // unscaleValue(data[i].getDoubleValues()[0], data[i]
            // .getChannelInfo().getScale());
            // } else if (channelNames[1].equals(data[i].getChannelInfo()
            // .getName())) {
            // accel[1] =
            // unscaleValue(data[i].getDoubleValues()[0], data[i]
            // .getChannelInfo().getScale());
            // } else if (channelNames[2].equals(data[i].getChannelInfo()
            // .getName())) {
            // accel[2] =
            // unscaleValue(data[i].getDoubleValues()[0], data[i]
            // .getChannelInfo().getScale());
            // }
        }
        marblesBoard.accelerate(accel[0], accel[1], accel[2]);
    }

    /**
     * Detect appropriate sensor info.
     * 
     * @return if found valid {@link SensorInfo} is returned otherwise null
     */
    private SensorInfo[] getSensorInfos() {
        // Find all device accelerometers
        SensorInfo[] sensorInfos =
                SensorManager.findSensors("acceleration", null);
        Vector validInfos = new Vector();
        for (int i = 0; i < sensorInfos.length; i++) {
            if (getSensorInfoChannelsNames(sensorInfos[i]).length > 2) {
                validInfos.addElement(sensorInfos[i]);
            }
        }
        SensorInfo[] ret = null;
        if (validInfos.size() > 0) {
            ret = new SensorInfo[validInfos.size()];
            validInfos.copyInto(ret);
        }
        return ret;
    }

    /**
     * Detect valid channel names for sensor.
     * 
     * @param sensorInfo Sensor info for channel names detection
     * @return array of two appropriate channel names
     */
    private String[] getSensorInfoChannelsNames(SensorInfo sensorInfo) {
        Vector channelNames = new Vector();
        ChannelInfo[] channelInfos = sensorInfo.getChannelInfos();
        // Accelerometer must support at least 3 channels
        if (channelInfos.length > 2) {
            for (int i = 0; i < channelInfos.length; i++) {
                // The channel type must be double
                if (ChannelInfo.TYPE_DOUBLE == channelInfos[i].getDataType()
                        || ChannelInfo.TYPE_INT == channelInfos[i]
                                .getDataType()) {
                    channelNames.addElement(channelInfos[i].getName());
                }
            }
            // We found at least 3 double channels
            if (channelNames.size() > 2) {
                String[] names = new String[3];
                names[0] = (String) channelNames.elementAt(0);
                names[1] = (String) channelNames.elementAt(1);
                names[2] = (String) channelNames.elementAt(2);
                return names;
            }
        }
        return new String[0];
    }
}
