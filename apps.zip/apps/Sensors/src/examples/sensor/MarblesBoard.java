/*
 *
 * Copyright (c) 2008, Sun Microsystems, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of Sun Microsystems nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package examples.sensor;

import java.io.IOException;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;


public class MarblesBoard extends Canvas implements Runnable {

    private static final double PPCM = 80 * 100; // pixels per meter
    private static final long TICK_SLEEP_MILLIS = 5;

    final static double ROLLING_FRICTION = 0.001;
    /**
     * Marble mass in kg. This demo is optimized for marbles with equal masses.
     */
    final static double MARBLE_MASS = 0.000742179;

    /**
     * Multipliers convert m/s^2 to pixel/tick^2.
     */
    private final double accelMultX;
    private final double accelMultY;
    private final double accelMultZ;

    private Marble[] marble;
    private volatile boolean stop;

    private double accelX;
    private double accelY;
    private double accelZ;

    public MarblesBoard() throws IOException {
        // Tick cycles per s^2
        double d = (1000 / TICK_SLEEP_MILLIS) * (1000 / TICK_SLEEP_MILLIS);
        accelMultX = -1.0 * PPCM / d;
        accelMultY = 1.0 * PPCM / d;
        accelMultZ = -1.0 * PPCM / d;

        marble = new Marble[5];
        for (int i = 0; i < marble.length; i++) {
            marble[i] = new Marble();
        }
    }

    public synchronized void resetBoard() {
        accelX = 0;
        accelY = 0;
        marble[0].resetPosition(getWidth() * 0.5, getHeight() * 0.5);
        marble[1].resetPosition(getWidth() * 0.25, getHeight() * 0.5);
        marble[2].resetPosition(getWidth() * 0.75, getHeight() * 0.5);
        marble[3].resetPosition(getWidth() * 0.5, getHeight() * 0.25);
        marble[4].resetPosition(getWidth() * 0.5, getHeight() * 0.75);
        firstPaint = true;
    }

    public void start() {
        stop = false;
        resetBoard();
        new Thread(this).start();
    }

    public void stop() {
        stop = true;
    }

    public void run() {
        try {
            while (!stop) {
                calculatePositions();
                repaint();
                Thread.sleep(TICK_SLEEP_MILLIS);
            }
        } catch (InterruptedException e) {
        }
    }

    volatile boolean firstPaint = true;

    public void paint(Graphics g) {
        if (firstPaint) {
            g.setColor(0xbbbbff);
            g.fillRect(0, 0, getWidth(), getHeight());
            firstPaint = false;
        }
        for (int i = 0; i < marble.length; i++) {
            marble[i].clear(g);
        }
        for (int i = 0; i < marble.length; i++) {
            marble[i].paint(g);
        }
    }

    private static final int SMOOTH_CNT = 2;
    double avgX[] = new double[SMOOTH_CNT];
    double avgY[] = new double[SMOOTH_CNT];
    double avgZ[] = new double[SMOOTH_CNT];

    /**
     * Accelerate the board. This method uses simple smoothing algorithm to
     * remove jittering.
     * 
     * @param x X acceleration in in m/s^2
     * @param y Y acceleration in in m/s^2
     * @param z Z acceleration in in m/s^2
     */
    public synchronized void accelerate(double x, double y, double z) {
        double xx = x;
        double yy = y;
        double zz = z;
        for (int i = 0; i < avgX.length - 1; i++) {
            xx += avgX[i];
            yy += avgY[i];
            zz += avgZ[i];
            avgX[i] = avgX[i + 1];
            avgY[i] = avgY[i + 1];
            avgZ[i] = avgZ[i + 1];
        }
        avgX[avgX.length - 1] = x;
        avgY[avgY.length - 1] = y;
        avgZ[avgZ.length - 1] = z;
        xx /= avgX.length + 1;
        yy /= avgY.length + 1;
        zz /= avgZ.length + 1;

        accelX = xx * accelMultX;
        accelY = yy * accelMultY;
        accelZ = zz * accelMultZ;
    }

    private synchronized void calculatePositions() {
        for (int i = 0; i < marble.length; i++) {
            marble[i].accelerate(accelX, accelY, accelZ);
            marble[i].collideBorders(this);
        }
        for (int i = 0; i < marble.length; i++) {
            for (int j = i + 1; j < marble.length; j++) {
                marble[i].collide(marble[j]);
            }
        }
        for (int i = 0; i < marble.length; i++) {
            marble[i].calcNewPosition();
        }
    }

    static class Marble {

        private Image img;

        private Vector lastPos;
        private Vector pos;
        private Vector speed;

        private double bounceFriction;
        private double radius;

        public Marble() throws IOException {
            this(0, 0);
        }

        public Marble(double x, double y) throws IOException {
            img = Image.createImage("/black_marble.png");
            pos = new Vector(x, y);
            lastPos = new Vector(x, y);
            speed = new Vector(0, 0);
            radius = img.getWidth() / 2.0;
            bounceFriction = 0.5;
        }

        public void resetPosition(double x, double y) {
            speed = new Vector(0, 0);
            pos.setX(x - getRadius());
            pos.setY(y - getRadius());
        }

        public void paint(Graphics g) {
            lastPos = new Vector(pos);
            g.drawImage(img, (int) pos.getX(), (int) pos.getY(),
                    Graphics.HCENTER | Graphics.VCENTER);
        }

        public void clear(Graphics g) {
            g.setColor(0xbbbbff);
            g.fillRect((int) (lastPos.getX() - getRadius()), (int) (lastPos
                    .getY() - getRadius()), (int) (getRadius() * 2),
                    (int) (getRadius() * 2));
        }

        public void accelerate(double accelX, double accelY, double accelZ) {
            double frictionF = (Math.max(0, accelZ) * ROLLING_FRICTION * 2);
            speed.add(accelX, accelY);
            if (frictionF > 0 && speed.getLen2() > 0) {
                Vector friction = speed.inv().norm().mul(Math.sqrt(frictionF));
                speed.add(friction);
            }
        }

        public void calcNewPosition() {
            pos.add(speed);
        }

        public double getRadius() {
            return radius;
        }

        public void collideBorders(Canvas canvas) {
            Vector newPos = Vector.add(pos, speed);
            if (newPos.getY() - getRadius() < 0) {
                speed.setY(speed.getY() * (bounceFriction - 1));
                pos.setY(getRadius());
            } else if (newPos.getY() + getRadius() > canvas.getHeight()) {
                speed.setY(speed.getY() * (bounceFriction - 1));
                pos.setY(canvas.getHeight() - getRadius());
            }
            if (newPos.getX() - getRadius() < 0) {
                speed.setX(speed.getX() * (bounceFriction - 1));
                pos.setX(getRadius());
            } else if (newPos.getX() + getRadius() > canvas.getWidth()) {
                speed.setX(speed.getX() * (bounceFriction - 1));
                pos.setX(canvas.getWidth() - getRadius());
            }
        }

        public void collide(Marble marble) {
            Vector c1 = Vector.add(pos, speed);
            Vector c2 = Vector.add(marble.pos, marble.speed);

            double distance = getRadius() + marble.getRadius();
            if (Vector.sub(c1, c2).getLen2() < distance * distance) {
                Vector xAxis = Vector.sub(c2, c1).norm();

                Vector hitCenter = Vector.add(c1, c2).mul(0.5);
                pos = Vector.add(hitCenter, Vector.mul(xAxis, -getRadius()));
                marble.pos =
                        Vector.add(hitCenter, Vector.mul(xAxis, marble
                                .getRadius()));

                // u1x = xAxis * (xAxis dot speed)
                // u1y = speed - u1x
                Vector u1x = Vector.mul(xAxis, Vector.dot(xAxis, speed));
                Vector u1y = Vector.sub(speed, u1x);

                // u2x = -xAxis * (-xAxis dot marble.speed)
                // u2y = marble.speed - u2x
                Vector u2x =
                        Vector.mul(xAxis.inv(), Vector.dot(xAxis.inv(),
                                marble.speed));
                Vector u2y = Vector.sub(marble.speed, u2x);

                // Compute new velocities
                // v1x = (u1x + u2x - (u1x - u2x)) * 0.5;
                Vector v1x =
                        Vector.sub(Vector.add(u1x, u2x), Vector.sub(u1x, u2x))
                                .mul(0.5);
                // v2x = (u1x + u2x - (u2x - u1x)) * 0.5;
                Vector v2x =
                        Vector.sub(Vector.add(u1x, u2x), Vector.sub(u2x, u1x))
                                .mul(0.5);
                Vector v1y = u1y;
                Vector v2y = u2y;
                speed = Vector.add(v1x, v1y);
                marble.speed = Vector.add(v2x, v2y);
            }
        }
    }
}

class Vector {

    private double x;
    private double y;

    public Vector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Vector(Vector v) {
        this(v.getX(), v.getY());
    }

    public static Vector add(Vector a, Vector b) {
        return new Vector(a.getX() + b.getX(), a.getY() + b.getY());
    }

    public static Vector mul(Vector v, double d) {
        return new Vector(v.getX() * d, v.getY() * d);
    }

    public static double dot(Vector a, Vector b) {
        return a.getX() * b.getX() + a.getY() * b.getY();
    }

    public static Vector sub(Vector v1, Vector v2) {
        return new Vector(v1.getX() - v2.getX(), v1.getY() - v2.getY());
    }

    public Vector inv() {
        return new Vector(getX() * -1.0, getY() * -1.0);
    }

    public Vector norm() {
        double l = Math.sqrt(getX() * getX() + getY() * getY());
        return new Vector(getX() / l, getY() / l);
    }

    public double getY() {
        return y;
    }

    public double getX() {
        return x;
    }

    public Vector mul(double d) {
        return new Vector(getX() * d, getY() * d);
    }

    public void add(Vector vector) {
        add(vector.x, vector.y);
    }

    public void add(double d) {
        add(d, d);
    }

    public void add(double x, double y) {
        this.x += x;
        this.y += y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getLen2() {
        return getX() * getX() + getY() * getY();
    }

    public double getLen() {
        return Math.sqrt(getLen2());
    }

    public String toString() {
        return "[" + getX() + ";" + getY() + "]";
    }
}
