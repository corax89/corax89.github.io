/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

import java.io.ByteArrayInputStream;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 * A code sample demonstrating the usage of SAX for XML parsing.
 */
public class SAXSample implements ParseXML {

    private SampleMessageListener listener;

    public SAXSample(SampleMessageListener listener) {
        this.listener = listener;
    }
    
    
    /**
     * Parses the given XML string.
     */
    public void parseSampleXML(String xml) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(xml.getBytes());
            
            // obtain a SAX parser
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();
            
            // parse the XML using a subclass of DefaultHandler
            parser.parse(in, new DefaultHandler() {
                String title = null;
                String authors = null;
                String price = null;
                String isbn = null;
                String publisher = null;
                // a number representing the current XML element
                int inTag = 0;
                
                /**
                 * Called when an element starts in the XML stream.
                 */
                public void startElement(String uri, String localName, String qName, 
                        Attributes attributes) throws SAXException {
                    // read the book attributes if tag 'book' is encountered
                    if (SampleData.TAG_BOOK.equals(qName)) {
                        inTag = 1;
                        title = attributes.getValue(SampleData.ATTR_TITLE);
                        isbn = attributes.getValue(SampleData.ATTR_ISBN);
                    }
                    // otherwise just set the inTag value
                    if (SampleData.TAG_PRICE.equals(qName)) {
                        inTag = 4;
                    } else if (SampleData.TAG_AUTHOR.equals(qName)) {
                        inTag = 3;
                    } else if (SampleData.TAG_PUBLISHER.equals(qName)) {
                        inTag = 2;
                    } else inTag = 0;
                    
                }
                
                /**
                 * Called when text node appears in the XML stream.
                 */
                public void characters(char[] chars, 
                        int start, int length) throws SAXException {
                    // read the text
                    String text = new String(chars, start, length);
                    // and set the appropriate value
                    switch(inTag) {
                        case 2: 
                            publisher = text; 
                            break;
                        case 3: 
                            authors = (authors == null) ? text 
                                                        : authors + "," + text; 
                            break;
                        case 4: 
                            price = text; 
                            break;
                    }
                }
                             
                /**
                 * Called when tag is closed in the XML stream.
                 */
                public void endElement(String uri, String localName, 
                        String qName) throws SAXException {
                    inTag = 0;
                    // a book info was read, notify the user
                    if (SampleData.TAG_BOOK.equals(qName)) {
                        StringBuffer bookInfo = new StringBuffer();
                        bookInfo.append("Title: "+title);
                        bookInfo.append("\nAuthors: "+authors);
                        bookInfo.append("\nPublisher: "+publisher);
                        bookInfo.append("\nPrice: "+price);
                        bookInfo.append("\nISBN: "+isbn);
                        listener.writeToConsole(bookInfo.toString());
                    }
                    
                }
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
