/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 


package example.jsr280sample;

/**
 * Interface for parsing an XML string.
 */
public interface ParseXML {
    /**
     * Parses the given XML string.
     */
    void parseSampleXML(String xml);
    
}
