/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

import java.io.ByteArrayInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * A code sample demonstrating the usage of DOM for creating and parsing XML
 */
public class DOMSample implements CreateXML, ParseXML {
    
    private SampleMessageListener listener;

    public DOMSample(SampleMessageListener listener) {
        this.listener = listener;
    }
    
    /**
     * Creates and returns XML string containing the sample data.
     */
    public String createSampleXML() {
        try {
            
            // obtain a document builder
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // create a new document
            DOMImplementation impl = builder.getDOMImplementation();
            Document document = impl.createDocument(null, 
                    SampleData.TAG_BOOKSTORE, null);
            
            // text node that contains a new-line character
            // used for basic formatting for better readability
            Node newLine = document.createTextNode("\n");
            
            // crate DOM nodes for the sample data
            for(int i=0; i<SampleData.TITLES.length; i++) {
                // the book element with attributes
                Element book = document.createElement(SampleData.TAG_BOOK);
                book.setAttribute(SampleData.ATTR_TITLE, SampleData.TITLES[i]);
                book.setAttribute(SampleData.ATTR_ISBN, SampleData.ISBNs[i]);
                
                // authors of the book
                for(int j=0; j<SampleData.AUTHORS[i].length; j++) {
                    Element author = document.createElement(
                            SampleData.TAG_AUTHOR);
                    book.appendChild(newLine.cloneNode(false));
                    author.appendChild(document.createTextNode(
                            SampleData.AUTHORS[i][j]));
                    // add the author element to the book element
                    book.appendChild(author);                    
                }
                
                // the rest of the elements
                Element publisher = document.createElement(
                        SampleData.TAG_PUBLISHER);
                publisher.appendChild(document.createTextNode(
                        SampleData.PUBLISHERS[i]));
                Element price = document.createElement(
                        SampleData.TAG_PRICE);
                price.appendChild(document.createTextNode(
                        SampleData.PRICES[i]));
                book.appendChild(newLine.cloneNode(false));
                book.appendChild(publisher);
                book.appendChild(newLine.cloneNode(false));
                book.appendChild(price);
                book.appendChild(newLine.cloneNode(false));
                
                // add book to the root element
                
                document.getDocumentElement().appendChild(
                        newLine.cloneNode(false));
                document.getDocumentElement().appendChild(book);
            }
            document.getDocumentElement().appendChild(
                    newLine.cloneNode(false));
            return document.toString();
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
        
    }

    
    /**
     * Parses the given XML string.
     */
    public void parseSampleXML(String xml) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(xml.getBytes());
            // obtain a document builder
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            
            // create a document by parsing the string
            Document document = builder.parse(in);
            // obtain all 'book' elements
            NodeList list = document.getElementsByTagName(
                    SampleData.TAG_BOOK);
            int count = list.getLength();
            for(int i=0; i<count; i++) {
                String title = null;
                String authors = null;
                String price = null;
                String isbn = null;
                String publisher = null;
                Node bookNode = list.item(i);
                // obtain attributes of the book element
                NamedNodeMap attrs = bookNode.getAttributes();
                title = attrs.getNamedItem(
                        SampleData.ATTR_TITLE).getNodeValue();
                isbn = attrs.getNamedItem(
                        SampleData.ATTR_ISBN).getNodeValue();

                // obtain all sub-nodes of the book element
                NodeList childNodes = bookNode.getChildNodes();
                int childCount = childNodes.getLength();
                for(int j=0; j<childCount; j++) {
                    Node node = childNodes.item(j);
                    // skip all nodes except elements
                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                        // obtain the text inside the tag
                        String text = node.getFirstChild().getTextContent();
                        String nodeName = node.getNodeName();
                        
                        // fill the strings ith the data
                        if (SampleData.TAG_AUTHOR.equals(nodeName)) {
                            authors = (authors == null) ? text 
                                                        : authors + "," + text;
                        }
                        if (SampleData.TAG_PUBLISHER.equals(nodeName)) {
                            publisher = text;
                        }
                        if (SampleData.TAG_PRICE.equals(nodeName)) {
                            price = text;
                        }
                    }
                }
                StringBuffer bookInfo = new StringBuffer();
                bookInfo.append("Title: "+title);
                bookInfo.append("\nAuthors: "+authors);
                bookInfo.append("\nPublisher: "+publisher);
                bookInfo.append("\nPrice: "+price);
                bookInfo.append("\nISBN: "+isbn);
                
                // show the book info to the user
                listener.writeToConsole(bookInfo.toString());
                
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        
    }
   
    
    
}
