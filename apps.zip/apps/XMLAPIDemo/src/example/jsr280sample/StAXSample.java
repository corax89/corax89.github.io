/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

/**
 * A code sample demonstrating the usage of StAX for creating and parsing XML
 */
public class StAXSample implements CreateXML, ParseXML {
 
    private SampleMessageListener listener;

    public StAXSample(SampleMessageListener listener) {
        this.listener = listener;
    }
    
    /**
     * Creates and returns XML string containing the sample data.
     */
    public String createSampleXML() {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            // obtain an XML writer
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter writer = factory.createXMLStreamWriter(out);
            
            // write document header
            writer.writeStartDocument();
            // write comment
            writer.writeComment("\nJSR 280 Sample XML - created using StAX API\n");
            // start the root element
            writer.writeStartElement(SampleData.TAG_BOOKSTORE);
            // add at least some formatting for better readability
            writer.writeCharacters("\n");
            
            // create tags for sample data
            for(int i=0; i<SampleData.TITLES.length; i++) {
                // start the book element
                writer.writeStartElement(SampleData.TAG_BOOK);
                // write tke book attributes
                writer.writeAttribute(SampleData.ATTR_ISBN, 
                        SampleData.ISBNs[i]);
                writer.writeAttribute(SampleData.ATTR_TITLE, 
                        SampleData.TITLES[i]);
                writer.writeCharacters("\n");
                
                // add the authors
                for(int j=0; j<SampleData.AUTHORS[i].length; j++) {
                    writer.writeStartElement(SampleData.TAG_AUTHOR);
                    writer.writeCharacters(SampleData.AUTHORS[i][j]);
                    // not neccessary to specify element name when closing it
                    writer.writeEndElement();
                    writer.writeCharacters("\n");
                }
                // write the remaining data
                writer.writeStartElement(SampleData.TAG_PUBLISHER);
                writer.writeCharacters(SampleData.PUBLISHERS[i]);
                writer.writeEndElement();
                writer.writeCharacters("\n");
                writer.writeStartElement(SampleData.TAG_PRICE);
                writer.writeCharacters(SampleData.PRICES[i]);
                writer.writeEndElement();
                writer.writeCharacters("\n");
                writer.writeEndElement();
                writer.writeCharacters("\n");
            }
            // close the document and the streams
            writer.writeEndDocument();
            writer.flush();
            writer.close();
            out.close();
            // return the XML string
            return out.toString();
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    
    /**
     * Parses the given XML string.
     */
    public void parseSampleXML(String xml) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(xml.getBytes());

            // obtain an XML reader
            XMLInputFactory factory = XMLInputFactory.newInstance();
            XMLStreamReader reader = factory.createXMLStreamReader(in);

            String title = null;
            String authors = null;
            String price = null;
            String isbn = null;
            String publisher = null;
            // a number representing the current XML element
            int inTag = 0;
            // there are more events to be read
            while (reader.hasNext()) {
                // get the next XML event
                switch(reader.next()) {
                    // an element starts - set the inTag value accordingly
                    case XMLStreamConstants.START_ELEMENT : 
                        String qName = reader.getLocalName();
                        if (SampleData.TAG_BOOK.equals(qName)) {
                            inTag = 1; 
                        }
                        if (SampleData.TAG_PRICE.equals(qName)) {
                            inTag = 4; 
                        }
                        else if (SampleData.TAG_AUTHOR.equals(qName)) {
                            inTag = 3; 
                        }
                        else if (SampleData.TAG_PUBLISHER.equals(qName)) {
                            inTag = 2; 
                        } else inTag = 0;
                        break;
                    // an element ends - notify the user    
                    case XMLStreamConstants.END_ELEMENT : 
                        inTag = 0;
                        if (SampleData.TAG_BOOK.equals(
                                reader.getLocalName())) {
                            StringBuffer bookInfo = new StringBuffer();
                            bookInfo.append("Title: "+title);
                            bookInfo.append("\nAuthors: "+authors);
                            bookInfo.append("\nPublisher: "+publisher);
                            bookInfo.append("\nPrice: "+price);
                            bookInfo.append("\nISBN: "+isbn);
                            listener.writeToConsole(bookInfo.toString());
                        }
                        break;
                    // read the attributes 
                    // (we use attributes only in one tag so no further check is neccessary)    
                    case XMLStreamConstants.ATTRIBUTE : 
                        int count = reader.getAttributeCount();
                        for(int i=0; i<count; i++) {
                            String attrName = reader.getAttributeLocalName(i);
                            String attrValue = reader.getAttributeValue(i);
                            if (SampleData.ATTR_ISBN.equals(attrName)) {
                                isbn = attrValue;
                            } 
                            else if (SampleData.ATTR_TITLE.equals(attrName)) {
                                title = attrValue;
                            }
                        }
                        break;
                    // read the text node content to a variable according to current tag    
                    case XMLStreamConstants.CHARACTERS : 
                        switch(inTag) {
                            case 2: 
                                publisher = reader.getText(); 
                                break;
                            case 3: 
                                authors = (authors == null) 
                                    ? reader.getText() 
                                    : authors + ", " + reader.getText(); 
                                break;
                            case 4: 
                                price = reader.getText(); 
                                break;
                        }
                 }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
            
    }
    
}
