/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class JSR280SampleMidlet extends MIDlet implements CommandListener, SampleMessageListener {
    
    private Form form;
    private Alert infoAlert;
    private StringItem stringItem;
    
    private JSR280Sample sample;
    
    private Command createDOMCommand = new Command("Create XML using DOM", Command.ITEM, 1);
    private Command createStAXCommand = new Command("Create XML using StAX", Command.ITEM, 1);
    private Command parseStAXCommand = new Command("Parse XML using StAX", Command.ITEM, 1);
    private Command parseSAXCommand = new Command("Parse XML using SAX", Command.ITEM, 1);
    private Command parseDOMCommand = new Command("Parse XML using DOM", Command.ITEM, 1);
    private Command exitCommand = new Command("Exit", Command.EXIT, 1);
    
    
    /** Creates a new instance of the midlet */
    public JSR280SampleMidlet() {
        sample = new JSR280Sample(this);
    }
    
   /** Called by the system to indicate that a command has been invoked on a particular displayable.                      
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {    
        if (command == exitCommand) {
            exitMIDlet();                      
        }
        if (command == createDOMCommand) {
            sample.createDOM();  
            enableParseCommands();
        }
        if (command == createStAXCommand) {
            sample.createStAX();  
            enableParseCommands();
        }
        if (command == parseSAXCommand) {
            sample.parseSAX();                   
        }
        if (command == parseStAXCommand) {
            sample.parseStAX();                   
        }
        if (command == parseDOMCommand) {
            sample.parseDOM();                   
        }
    }                    
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {                         
        Display.getDisplay(this).setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }                        
    
    /**
     * Starts the MIDlet
     */
    public void startApp() {
        stringItem = new StringItem("", JSR280Sample.MES_INIT + "\n\n Use the menu to invoke the particular commands.");
        form = new Form(null);
        form.addCommand(createDOMCommand);
        form.addCommand(createStAXCommand);
        form.addCommand(exitCommand);
        form.setCommandListener(this);
        Display.getDisplay(this).setCurrent(form); 
        form.append(stringItem);
        infoAlert = new Alert("JSR280 Sample", "", null, AlertType.INFO);
        infoAlert.setTimeout(Alert.FOREVER);
    }
    

    /**
     * Called when the MIDlet is paused - do nothing.
     */
    public void pauseApp() {
    }
    
    /**
     * Called when the MIDlet is destroyed - do nothing.
     */
    public void destroyApp(boolean unconditional) {
    }

    /**
     * Displays info message on the screen.
     */
    public void showMessage(String message) {
        infoAlert.setString(message);
        Display.getDisplay(this).setCurrent(infoAlert);
    }

    /**
     * Writes the given string to the console.
     */
    public void writeToConsole(String message) {
        System.out.println(message);
    }
    
    /**
     * Enables the parsing commands when XML is available.
     */
    private void enableParseCommands() {
        form.addCommand(parseDOMCommand);
        form.addCommand(parseStAXCommand);
        form.addCommand(parseSAXCommand);
    }
    
    
}
