/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

/**
 * Interface for creating an XML string.
 */
public interface CreateXML {
    
    /**
     * Creates and returns XML string containing the sample data.
     */
    String createSampleXML();
}
