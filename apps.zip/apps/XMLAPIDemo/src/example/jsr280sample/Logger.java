/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 


package example.jsr280sample;


/**
 * Utility class for showing messages to the user.
 */
public class Logger {    
    public static void log(String message) {
        // Possible on both CDC and CLDC
        System.out.println(message);
    }
}
