/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

/**
 * Data for the JSR280 sample.
 */
public class SampleData {
    
    public static final String TAG_BOOKSTORE = "bookstore";
    public static final String TAG_BOOK = "book";
    public static final String TAG_AUTHOR = "author";
    public static final String TAG_PUBLISHER = "publisher";
    public static final String TAG_PRICE = "price";
    public static final String ATTR_ISBN = "ISBN";
    public static final String ATTR_TITLE = "title";
    
    public static final String [] TITLES = {
        "Thinking in Java (4th Edition)", 
        "Java In A Nutshell, 5th Edition",
        "Java Concurrency in Practice", 
        "Java Generics and Collections", 
        "Pro EJB 3: Java Persistence API", 
        "Java Development with Ant"} ;
    public static final String [][] AUTHORS = { 
        {"Bruce Eckel"}, 
        {"David Flanagan"}, 
        {"Brian Goetz", "Tim Peierls", 
                 "Joshua Bloch", "Joseph Bowbeer", 
                 "David Holmes", "Doug Lea" },
        {"Maurice Naftalin", "Philip Wadler"}, 
        {"Mike Keith","Merrick Schincariol" }, 
        {"Erik Hatcher", "Steve Loughran"}  } ;
    public static final String [] ISBNs = { 
        "978-0131872486", 
        "978-0596007737",
        "978-0321349606", 
        "978-0596527754", 
        "978-1590596456", 
        "978-1930110588"} ;
    public static final String [] PUBLISHERS = { 
        "Prentice Hall", 
        "O'Reilly Media", 
        "Addison-Wesley Professional", 
        "O'Reilly Media", 
        "Apress",
        "Manning Publications" } ;
    public static final String [] PRICES = {
        "$40.94" , 
        "$28.32", 
        "$32.99", 
        "$22.04", 
        "$28.34", 
        "$29.67"} ;
    
}
