/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 

package example.jsr280sample;

/**
 * A simple intefrace for showing messages to the user.
 */
public interface SampleMessageListener {
    void showMessage(String message);
    void writeToConsole(String message);
}
