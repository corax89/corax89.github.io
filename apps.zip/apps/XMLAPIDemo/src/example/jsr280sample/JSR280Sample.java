/*
 * Copyright (c) 2008 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */ 
 
 


package example.jsr280sample;


public class JSR280Sample {
    
    private String xml = null;
    
    private SampleMessageListener listener;
    private StAXSample staxSample;
    private SAXSample saxSample;
    private DOMSample domSample;
    
    
    /** Creates a new instance of JSR280Sample */
    public JSR280Sample(SampleMessageListener listener) {
        this.listener = listener;
        staxSample = new StAXSample(listener);
        saxSample = new SAXSample(listener);
        domSample = new DOMSample(listener);
    }
    
    public void createStAX() {
        xml = staxSample.createSampleXML();
        if (xml != null) {
            listener.writeToConsole(xml);
            listener.showMessage(MES_STAX_CREATED);
        }
    }

    public void createDOM() {
        xml = domSample.createSampleXML();
        if (xml != null) {
            listener.writeToConsole(xml);
            listener.showMessage(MES_DOM_CREATED);
        }
    }

    public void parseDOM() {
        domSample.parseSampleXML(xml);
        listener.showMessage(MES_DOM_PARSED);
    }

    public void parseStAX() {
        staxSample.parseSampleXML(xml);
        listener.showMessage(MES_STAX_PARSED);
    }

    public void parseSAX() {
        saxSample.parseSampleXML(xml);
        listener.showMessage(MES_SAX_PARSED);
    }
    
    public String getXML() {
        return xml;
    }
    
    public static final String MES_INIT = 
            "JSR280Sample uses DOM and StAX APIs\n" +
            " to create an XML sample and SAX, " +
            "\nDOM and StAX APIs\n to parse the sample.";
    
    public static final String MES_DOM_CREATED = 
            "XML string was created by DOM\n and dumped to console.";
    
    public static final String MES_DOM_PARSED =
            "XML string was parsed by DOM.\n" +
            "Parsing results were dumped\nto the console.";

    public static final String MES_SAX_PARSED =
            "XML string was parsed by SAX.\n" +
            "Parsing results were dumped\nto the console.";

    public static final String MES_STAX_CREATED =
            "XML string was created by StAX\n" +
            "and dumped to console.";
    
    public static final String MES_STAX_PARSED = 
            "XML string was created by StAX.\n" +
            "Parsing results were dumped\n to the console.";            
}
