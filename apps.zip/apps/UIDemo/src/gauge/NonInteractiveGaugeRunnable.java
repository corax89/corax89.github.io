/*
 *
 * Copyright (c) 2008, Sun Microsystems, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of Sun Microsystems nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package gauge;

import javax.microedition.lcdui.Gauge;


/**
 * This class implements a non-interactive gauge control
 * that moves automatically, between the min and max values.
 *
 * @version 2.0
 */
public class NonInteractiveGaugeRunnable extends Gauge implements Runnable {
    private int maxValue = 10;

    /**
     * This member indicates the number of units to move per
     * iteration. It is set to -1 when we reach a 100 and 1
     * when we reach 0.
     */
    private int delta = 1;
    private boolean done = false;

    /**
     * The constructor initializes the gauge.
     */
    public NonInteractiveGaugeRunnable (String label, int maxValue, int initialValue) {
        super (label, false, maxValue, initialValue);
        this.maxValue = maxValue;
        new Thread (this).start ();
    }

    /**
     * This method moves the gauge left and right.
     */
    public void run () {
        while (!done) {
            // decide whether the gauge should start moving
            // backwards or forwards.
            int newValue = getValue () + delta;

            if (newValue == maxValue) {
                delta = -1;
            }
            else if (newValue == 0) {
                delta = 1;
            }

            setValue (newValue);

            try {
                Thread.sleep (1000);
            }
            catch (InterruptedException err) {
            }
        }
    }

    void setDone () {
        done = true;
    }
}
