/*
 * @(#)Surface.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

package demos.j2d;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

/**
 * Surface is the base class for the 2d rendering demos.  Demos must
 * implement the render() method. Subclasses for Surface are
 * AnimatingSurface, ControlsSurface and AnimatingControlsSurface.
 */
public abstract class Surface extends Container {


    public Object AntiAlias = RenderingHints.VALUE_ANTIALIAS_ON;
    public Object Rendering = null;
    public AlphaComposite composite;
    public Color texture;
    public String perfStr;            // PerformanceMonitor
    public Image bimg;
    public int imageType;
    public String name;
    public boolean clearSurface = true;
    // Demos using animated GIFs that implement ImageObserver set dontThread.
    public boolean dontThread;
    public AnimatingSurface animating;

    protected long sleepAmount = 50;

    private long orig, start, frame;
    private boolean perfMonitor, outputPerf;
    private int biw, bih;
    private boolean clearOnce = true;
    private boolean toBeInitialized = true;

    Rectangle repaintArea = null;


    public Surface () {
        name = this.getClass ().getName ();
        name = name.substring (name.indexOf (".", 7) + 1);
        setImageType (0);

        // To launch an individual demo with the performance str output  :
        //    java -Djava2demo.perf= -cp Java2Demo.jar demos.Clipping.ClipAnim
        try {
            if (System.getProperty ("java2demo.perf") != null) {
                perfMonitor = outputPerf = true;
            }
        }
        catch (Exception ex) {
        }
        if (this instanceof AnimatingSurface) {
            animating = (AnimatingSurface) this;
        }
    }


    protected Image getImage (String name) {
        return DemoImages.getImage (name, this);
    }


    public int getImageType () {
        return imageType;
    }


    public void setImageType (int imgType) {
        if (imgType == 0) {
            if (this instanceof AnimatingSurface) {
                imageType = 2;
            }
            else {
                imageType = 1;
            }
        }
        else {
            imageType = imgType;
        }
        bimg = null;
    }


    public void setAntiAlias (boolean aa) {
        AntiAlias = aa
            ? RenderingHints.VALUE_ANTIALIAS_ON
            : RenderingHints.VALUE_ANTIALIAS_OFF;
    }


    public void setRendering (boolean rd) {
    }


    public void setTexture (Object obj) {
    }


    public void setComposite (boolean cp) {
        composite = cp
            ? AlphaComposite.getInstance (AlphaComposite.SRC_OVER, 0.5f)
            : null;
    }


    public void setMonitor (boolean pm) {
        perfMonitor = pm;
    }


    public void setSleepAmount (long amount) {
        sleepAmount = amount;
    }


    public long getSleepAmount () {
        return sleepAmount;
    }

    static boolean useBufferedImage =
        Boolean.getBoolean ("demos.j2d.bufimg.backbuffer");

    public Image createBufferedImage (int w, int h, int imgType) {
        Image bi;
        if (useBufferedImage) {
            bi = newBufferedImage (w, h, true);
        }
        else {
            bi = this.createImage (w, h);
        }

        biw = w;
        bih = h;
        return bi;
    }


    // Lookup tables for BYTE_BINARY 1, 2 and 4 bits.
    static byte[] lut1Arr = new byte[] {0, (byte) 255};
    static byte[] lut2Arr = new byte[] {0, (byte) 85, (byte) 170, (byte) 255};
    static byte[] lut4Arr = new byte[] {
        0, (byte) 17, (byte) 34, (byte) 51,
        (byte) 68, (byte) 85, (byte) 102, (byte) 119,
        (byte) 136, (byte) 153, (byte) 170, (byte) 187,
        (byte) 204, (byte) 221, (byte) 238, (byte) 255};


    public Graphics2D createGraphics2D (
        int width,
        int height,
        Image bi,
        Graphics g,
        Rectangle clip) {

        Graphics2D g2;

        if (bi != null) {
            g2 = (Graphics2D) bi.getGraphics ();
        }
        else {
            g2 = (Graphics2D) g;
        }

        g2.setClip (clip.x, clip.y, clip.width, clip.height);
        g2.setBackground (getBackground ());
        g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, AntiAlias);

        if (clearSurface || clearOnce) {
            g2.clearRect (clip.x, clip.y, clip.width, clip.height);
            clearOnce = true;
        }

        if (texture != null) {
            // set composite to opaque for texture fills
            g2.setComposite (AlphaComposite.SrcOver);
            g2.fillRect (clip.x, clip.y, clip.width, clip.height);
        }

        if (composite != null) {
            g2.setComposite (composite);
        }

        return g2;
    }

    // ...demos that extend Surface must implement this routine...
    public abstract void render (int w, int h, Graphics2D g2);


    public void update (Graphics g) {
        paint (g);
    }

    public void paint (Graphics g) {
        super.paint (g);

        Dimension d = getSize ();

        Rectangle usingClip = g.getClipBounds ();
        if (usingClip == null) {
            usingClip = new Rectangle (0, 0, d.width, d.height);
        }

        if (imageType == 1)
            bimg = null;
        else if (bimg == null || biw != d.width || bih != d.height) {
            bimg = createBufferedImage (
                d.width,
                d.height,
                BufferedImage.TYPE_INT_ARGB_PRE);
            clearOnce = true;
            toBeInitialized = true;
        }

        long start = System.currentTimeMillis ();
        if (toBeInitialized) {
            repaintArea = null;
            if (animating != null)
                animating.reset (d.width, d.height);
            toBeInitialized = false;
            startClock ();
        }

        if (animating != null && animating.thread != null) {
            // we count new area for next repaint
            repaintArea = animating.getFlipArea ();
            animating.step (d.width, d.height);
            Rectangle afterStep = animating.getFlipArea ();
            if (afterStep != null && repaintArea != null) {
                repaintArea = repaintArea.union (afterStep);
            }
            else {
                repaintArea = null;
            }
        }
        Graphics2D g2 = createGraphics2D (d.width, d.height, bimg, g, usingClip);

        render (d.width, d.height, g2);

        if (g2 != g)
            g2.dispose ();

        if (bimg != null) {
            ((Graphics2D) g).setComposite (AlphaComposite.Src);
            g.drawImage (
                bimg, //backimage
                usingClip.x, //dst
                usingClip.y,
                usingClip.x + usingClip.width,
                usingClip.y + usingClip.height,
                usingClip.x, //src
                usingClip.y,
                usingClip.x + usingClip.width,
                usingClip.y + usingClip.height,
                null // observer
            );
        }

        if (perfMonitor) {
            LogPerformance ();
        }
    }


    public void startClock () {
        orig = System.currentTimeMillis ();
        start = orig;
        frame = 0;
    }

    private static final int REPORTFRAMES = 30;

    private void LogPerformance () {
        if ((frame % REPORTFRAMES) == 0) {
            long end = System.currentTimeMillis ();
            long rel = (end - start);
            long tot = (end - orig);
            if (frame == 0) {
                perfStr = name + " " + rel + " ms";
                if (animating == null || animating.thread == null) {
                    frame = -1;
                }
            }
            else {
                String s1 = Float.toString ((REPORTFRAMES / (rel / 1000.0f)));
                s1 = (s1.length () < 4) ? s1.substring (0, s1.length ()) : s1.substring (0, 4);
                perfStr = name + " " + s1 + " fps";
            }
            if (outputPerf) {
                System.out.println (perfStr);
            }
            start = end;
        }
        ++frame;
    }


    public void verbose () {
        String str = "  " + name + " ";
        if (animating != null && animating.thread != null) {
            str = str.concat (" Running");
        }
        else if (this instanceof AnimatingSurface) {
            str = str.concat (" Stopped");
        }

        str = AntiAlias == RenderingHints.VALUE_ANTIALIAS_ON
            ? str.concat (" ANTIALIAS_ON ")
            : str.concat (" ANTIALIAS_OFF ");

        if (texture != null) {
            str = str.concat ("Texture ");
        }

        if (composite != null) {
            str = str.concat ("Composite=" + composite.getAlpha () + " ");
        }

        Runtime r = Runtime.getRuntime ();
        r.gc ();
        float freeMemory = (float) r.freeMemory ();
        float totalMemory = (float) r.totalMemory ();
        str = str.concat (((totalMemory - freeMemory) / 1024) + "K used");
        System.out.println (str);
    }


    public static void createDemoFrame (Surface surface) {
        final DemoPanel dp = new DemoPanel (surface);
        Frame f = new Frame ("Java2D Demo - " + surface.name);
        f.addWindowListener (
            new WindowAdapter() {
                public void windowClosing (WindowEvent e) {
                    System.exit (0);
                }

                public void windowDeiconified (WindowEvent e) {
                    dp.start ();
                }

                public void windowIconified (WindowEvent e) {
                    dp.stop ();
                }
            });
        f.add ("Center", dp);
        f.pack ();

        f.setSize (new Dimension (Java2DDemo.FRAME_WIDTH, Java2DDemo.FRAME_HEIGHT));
        f.setVisible (true);
        if (surface.animating != null) {
            surface.animating.start ();
        }
    }

    public static BufferedImage newBufferedImage (int width, int height) {
        return newBufferedImage (width, height, true);
    }

    public static BufferedImage newBufferedImage (
        int width, int height,
        boolean isOpaque) {
        return new BufferedImage (width, height, BufferedImage.TYPE_INT_ARGB_PRE);
    }
}
