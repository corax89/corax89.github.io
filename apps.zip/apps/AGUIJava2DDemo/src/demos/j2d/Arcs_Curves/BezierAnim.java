/*
 * @(#)BezierAnim.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

package demos.j2d.Arcs_Curves;

import demos.j2d.AnimatingSurface;

import java.awt.*;
import java.awt.geom.GeneralPath;


/**
 * Animated Bezier Curve with controls for different draw & fill paints.
 */
public class BezierAnim extends AnimatingSurface {

    private static final int NUMPTS = 6;
    protected BasicStroke solid = new BasicStroke (
        10.0f,
        BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND);
    private float animpts[] = new float[NUMPTS * 2];
    private float deltas[] = new float[NUMPTS * 2];
    protected Paint fillPaint, drawPaint;
    protected boolean doFill = true;
    protected boolean doDraw = true;
    protected GradientPaint gradient;
    protected BasicStroke stroke;

    public BezierAnim () {
        setBackground (Color.white);
        gradient = new GradientPaint (0, 0, Color.red, 200, 200, Color.yellow);
        fillPaint = gradient;
        drawPaint = Color.blue;
        stroke = solid;
    }


    public void animate (float[] pts, float[] deltas, int index, int limit) {
        float newpt = pts[index] + deltas[index];
        if (newpt <= 0) {
            newpt = -newpt;
            deltas[index] = (float) (Math.random () * 4.0 + 2.0);
        }
        else if (newpt >= (float) limit) {
            newpt = 2.0f * limit - newpt;
            deltas[index] = -(float) (Math.random () * 4.0 + 2.0);
        }
        pts[index] = newpt;
    }


    public void reset (int w, int h) {
        for (int i = 0; i < animpts.length; i += 2) {
            animpts[i + 0] = (float) (Math.random () * w);
            animpts[i + 1] = (float) (Math.random () * h);
            deltas[i + 0] = (float) (Math.random () * 6.0 + 4.0);
            deltas[i + 1] = (float) (Math.random () * 6.0 + 4.0);
            if (animpts[i + 0] > w / 2.0f) {
                deltas[i + 0] = -deltas[i + 0];
            }
            if (animpts[i + 1] > h / 2.0f) {
                deltas[i + 1] = -deltas[i + 1];
            }
        }
        gradient = new GradientPaint (0, 0, Color.red, w * .7f, h * .7f, Color.yellow);
    }

    public Rectangle getFlipArea () {

        float[] ctrlpts = animpts;
        int len = ctrlpts.length;
        float prevx = ctrlpts[len - 2];
        float prevy = ctrlpts[len - 1];
        float curx = ctrlpts[0];
        float cury = ctrlpts[1];
        float midx = (curx + prevx) / 2.0f;
        float midy = (cury + prevy) / 2.0f;
        GeneralPath gp = new GeneralPath (GeneralPath.WIND_NON_ZERO);
        gp.moveTo (midx, midy);
        for (int i = 2; i <= ctrlpts.length; i += 2) {
            float x1 = (midx + curx) / 2.0f;
            float y1 = (midy + cury) / 2.0f;
            prevx = curx;
            prevy = cury;
            if (i < ctrlpts.length) {
                curx = ctrlpts[i + 0];
                cury = ctrlpts[i + 1];
            }
            else {
                curx = ctrlpts[0];
                cury = ctrlpts[1];
            }
            midx = (curx + prevx) / 2.0f;
            midy = (cury + prevy) / 2.0f;
            float x2 = (prevx + midx) / 2.0f;
            float y2 = (prevy + midy) / 2.0f;
            gp.curveTo (x1, y1, x2, y2, midx, midy);
        }
        gp.closePath ();

        Rectangle bounds = gp.getBounds ();
        bounds.x -= 10;
        bounds.y -= 10;
        bounds.width += 20;
        bounds.height += 20;

        return bounds;
        //return new Rectangle(200,200, 200, 200);
    }

    public void step (int w, int h) {
        for (int i = 0; i < animpts.length; i += 2) {
            animate (animpts, deltas, i + 0, w);
            animate (animpts, deltas, i + 1, h);
        }
    }


    public void render (int w, int h, Graphics2D g2) {
        float[] ctrlpts = animpts;
        int len = ctrlpts.length;
        float prevx = ctrlpts[len - 2];
        float prevy = ctrlpts[len - 1];
        float curx = ctrlpts[0];
        float cury = ctrlpts[1];
        float midx = (curx + prevx) / 2.0f;
        float midy = (cury + prevy) / 2.0f;
        GeneralPath gp = new GeneralPath (GeneralPath.WIND_NON_ZERO);
        gp.moveTo (midx, midy);
        for (int i = 2; i <= ctrlpts.length; i += 2) {
            float x1 = (midx + curx) / 2.0f;
            float y1 = (midy + cury) / 2.0f;
            prevx = curx;
            prevy = cury;
            if (i < ctrlpts.length) {
                curx = ctrlpts[i + 0];
                cury = ctrlpts[i + 1];
            }
            else {
                curx = ctrlpts[0];
                cury = ctrlpts[1];
            }
            midx = (curx + prevx) / 2.0f;
            midy = (cury + prevy) / 2.0f;
            float x2 = (prevx + midx) / 2.0f;
            float y2 = (prevy + midy) / 2.0f;
            gp.curveTo (x1, y1, x2, y2, midx, midy);
        }
        gp.closePath ();
        if (doDraw) {
            g2.setPaint (drawPaint);
            g2.setStroke (stroke);
            g2.draw (gp);
        }
        if (doFill) {
            if (fillPaint instanceof GradientPaint) {
                fillPaint = gradient;
            }
            g2.setPaint (fillPaint);
            g2.fill (gp);
        }
    }


    public static void main (String argv[]) {
        createDemoFrame (new BezierAnim ());
    }


} // End BezierAnim class
