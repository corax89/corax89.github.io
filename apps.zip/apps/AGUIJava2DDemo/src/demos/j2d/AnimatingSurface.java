/*
 * @(#)AnimatingSurface.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */


package demos.j2d;

import java.awt.*;


/**
 * Demos that animate extend this class.
 */
public abstract class AnimatingSurface extends Surface implements Runnable {

    public Thread thread;

    public abstract void step (int w, int h);

    public abstract void reset (int newwidth, int newheight);

    public abstract Rectangle getFlipArea ();

    public void start () {
        if (thread == null && !dontThread) {
            thread = new Thread (this);
            thread.setPriority (Thread.MIN_PRIORITY);
            thread.setName (name + " Demo");
            thread.start ();
        }
    }


    public synchronized void stop () {
        if (thread != null) {
            thread.interrupt ();
        }
        thread = null;
        notifyAll ();
    }


    public void run () {
        synchronized (AnimatingSurface.this) {
            repaintArea = null;
        }

        Thread me = Thread.currentThread ();

        while (thread == me && !isShowing () || getSize ().width == 0) {
            try {
                Thread.sleep (200);
            }
            catch (InterruptedException e) {
            }
        }

        while (thread == me) {
            synchronized (AnimatingSurface.this) {
                if (repaintArea == null) {
                    repaint ();
                }
                else {
                    repaint (
                        repaintArea.x,
                        repaintArea.y,
                        repaintArea.width,
                        repaintArea.height);
                }
            }
            try {
                Thread.sleep (sleepAmount);
            }
            catch (InterruptedException e) {
            }
        }
        thread = null;
    }
}
