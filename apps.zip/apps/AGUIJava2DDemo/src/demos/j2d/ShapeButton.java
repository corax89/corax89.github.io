/*
 * @(#)ShapeButton.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */


package demos.j2d;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.util.HashMap;

class ShapeButton extends Component {
    Color outlineColor;
    Color normalFillColor;
    Color pressedFillColor;
    Stroke stroke;
    Shape shape;
    int width;
    int height;
    boolean pressed;

    public static final String BACK_SHAPE = "BACK";
    public static final String FORWARD_SHAPE = "FORWARD";
    public static final String HOME_SHAPE = "HOME";
    public static final String AA_SHAPE = "AA";
    public static final String EXIT_SHAPE = "EXIT";

    private static BasicStroke DEFAULT_STROKE = new BasicStroke (
        (float) 3.0,
        BasicStroke.CAP_SQUARE,
        BasicStroke.JOIN_MITER,
        (float) 10.0);

    ShapeButton (Color outline, Color fill) {
        this (
            outline,
            fill,
            DEFAULT_STROKE,
            createShape (null),
            20,
            20);
    }

    ShapeButton (Color outline, Color fill, String shapeType) {
        this (
            outline,
            fill,
            DEFAULT_STROKE,
            createShape (shapeType),
            20,
            20);
    }

    ShapeButton (
        Color outline,
        Color fill,
        Stroke stroke,
        Shape shape,
        int w,
        int h) {
        w += 6;
        h += 6;
        this.outlineColor = outline;
        this.normalFillColor = fill;
        this.pressedFillColor = fill.darker ().darker ();
        this.stroke = stroke;
        this.width = w;
        this.height = h;
        this.shape = shape;
        setSize (w, h);
        enableEvents (
            MouseEvent.MOUSE_CLICKED |
                MouseEvent.MOUSE_PRESSED |
                MouseEvent.MOUSE_RELEASED
        );

    }

    public Dimension getPreferredSize () {
        return new Dimension (width, height);
    }

    public void paint (Graphics g) {
        Dimension d = getSize ();
        Graphics2D g2 = (Graphics2D) g;
        g2.clearRect (0, 0, d.width, d.height);
        g2.setStroke (stroke);

        // draw outline 
        g.setColor (this.outlineColor);
        g2.draw (this.shape);

        if (this.pressed)
            g.setColor (this.pressedFillColor);
        else
            g.setColor (this.normalFillColor);

        // fill the shape 
        g2.fill (this.shape);
    }

    protected void processMouseEvent (MouseEvent e) {
        switch (e.getID ()) {
        case MouseEvent.MOUSE_CLICKED:
            break;

        case MouseEvent.MOUSE_PRESSED:
            pressed = true;
            repaint ();
            break;

        case MouseEvent.MOUSE_RELEASED:
            pressed = false;
            repaint ();
            break;
        }
        super.processMouseEvent (e);
    }

    static HashMap shapeMap = new HashMap ();

    static synchronized Shape createShape (String type) {
        Shape shape;

        int w = 20;
        int h = 20;

        AffineTransform tx = AffineTransform.getTranslateInstance (3, 3);
        if (type == null)
            type = "default";

        shape = (Shape) shapeMap.get (type);
        if (shape != null)
            return shape;

        if (type == FORWARD_SHAPE) {
            GeneralPath path = new GeneralPath ();
            path.moveTo (0, 0);
            path.lineTo (w, h / 2);
            path.lineTo (0, h);
            path.lineTo (0, (h - h / 4));
            path.lineTo (w / 2, h / 2);
            path.lineTo (0, h / 4);
            path.closePath ();
            shape = path.createTransformedShape (tx);
        }
        else if (type == BACK_SHAPE) {
            GeneralPath path = new GeneralPath ();
            path.moveTo (w, 0);
            path.lineTo (0, h / 2);
            path.lineTo (w, h);
            path.lineTo (w, (h - h / 4));
            path.lineTo (w / 2, h / 2);
            path.lineTo (w, h / 4);
            path.closePath ();
            shape = path.createTransformedShape (tx);
        }
        else if (type == HOME_SHAPE) {
            GeneralPath path = new GeneralPath ();
            path.moveTo (0, h);
            path.lineTo (0, h / 2);
            path.lineTo (w / 2, 0);
            path.lineTo (w, h / 2);
            path.lineTo (w, h);
            path.lineTo (w - (w / 4), h);
            path.lineTo (w - (w / 4), h - 3);
            path.quadTo (w / 2, h - 10, w / 4, h - 3);
            path.lineTo (w / 4, h);
            path.closePath ();
            shape = path.createTransformedShape (tx);
        }
        else if (type == AA_SHAPE) {
            GeneralPath path = new GeneralPath ();

            for (int i = 0; i < 2; i++) {
                float dx = (i == 0) ? 0 : w / 4;
                float dy = dx / 2;

                float hh = 3 * h / 4;

                path.moveTo (0 + dx, hh + dy);
                path.lineTo (w / 4 + dx, 0 + dy);
                path.lineTo (w / 2 + dx, hh + dy);
                path.lineTo (w / 2 - w / 16 + dx, hh + dy);
                path.lineTo (w / 4 + dx, hh / 8 + dy);
                path.lineTo (w / 16 + dx, hh + dy);
                path.closePath ();

                path.moveTo (w / 2 - w / 8 + dx, hh / 2 + dy);
                path.lineTo (w / 2 - w / 8 + dx, hh / 2 + hh / 8 + dy);
                path.lineTo (w / 8 + dx, hh / 2 + hh / 8 + dy);
                path.lineTo (w / 8 + dx, hh / 2 + dy);
                path.closePath ();
            }

            shape = path.createTransformedShape (tx);
        }
        else if (type == EXIT_SHAPE) {
            GeneralPath path = new GeneralPath ();
            int x = w / 2;
            int y = h / 2;
            path.moveTo (x - 2, 0);
            path.lineTo (x + 2, 0);
            path.lineTo (x + 2, y - 2);
            path.lineTo (w, y - 2);
            path.lineTo (w, y + 2);
            path.lineTo (x + 2, y + 2);
            path.lineTo (x + 2, h);
            path.lineTo (x - 2, h);
            path.lineTo (x - 2, y + 2);
            path.lineTo (0, y + 2);
            path.lineTo (0, y - 2);
            path.lineTo (x - 2, y - 2);
            path.closePath ();
            AffineTransform at = AffineTransform.getRotateInstance (
                40.,
                (double) x,
                (double) y);
            at.preConcatenate (tx);
            shape = path.createTransformedShape (at);
        }
        else {
            shape =
                new GeneralPath (new Rectangle (0, 0, w, h)).createTransformedShape (tx);
        }

        shapeMap.put (type, shape);
        return shape;
    }
}
