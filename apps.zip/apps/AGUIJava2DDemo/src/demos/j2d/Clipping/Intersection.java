/*
 * @(#)Intersection.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

package demos.j2d.Clipping;

import demos.j2d.AnimatingSurface;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;


/**
 * Animated intersection clipping of lines, an image and a textured rectangle.
 */
public class Intersection extends AnimatingSurface {

    private static final int HEIGHTDECREASE = 0;
    private static final int HEIGHTINCREASE = 1;
    private static final int WIDTHDECREASE = 2;
    private static final int WIDTHINCREASE = 3;

    private int xx, yy, ww, hh;
    private int direction = HEIGHTDECREASE;
    private int angdeg;
    private Shape textshape;
    private GeneralPath ovals;
    private Rectangle2D rectshape;
    protected boolean doIntersection = true;
    protected boolean doOvals = true;
    protected boolean doText;
    protected boolean threeSixty;


    public Intersection () {
        setBackground (Color.white);
    }

    public Rectangle getFlipArea () {
        return null;
    }

    public void reset (int w, int h) {
        xx = yy = 0;
        ww = w - 1;
        hh = h;
        direction = HEIGHTDECREASE;
        angdeg = 0;
        rectshape = new Rectangle (w / 4, h / 4, w / 2, h / 2);
        double sw = rectshape.getWidth ();
        double sh = rectshape.getHeight ();
        ovals = new GeneralPath ();
        ovals.append (new Ellipse2D.Float (10, 10, 20, 20), false);
        ovals.append (new Ellipse2D.Float (w - 30, 10, 20, 20), false);
        ovals.append (new Ellipse2D.Float (10, h - 30, 20, 20), false);
        ovals.append (new Ellipse2D.Float (w - 30, h - 30, 20, 20), false);
    }


    public void step (int w, int h) {
        if (direction == HEIGHTDECREASE) {
            yy += 2;
            hh -= 4;
            if (yy >= h / 2) {
                direction = HEIGHTINCREASE;
            }
        }
        else if (direction == HEIGHTINCREASE) {
            yy -= 2;
            hh += 4;
            if (yy <= 0) {
                direction = WIDTHDECREASE;
                hh = h - 1;
                yy = 0;
            }
        }
        if (direction == WIDTHDECREASE) {
            xx += 2;
            ww -= 4;
            if (xx >= w / 2) {
                direction = WIDTHINCREASE;
            }
        }
        else if (direction == WIDTHINCREASE) {
            xx -= 2;
            ww += 4;
            if (xx <= 0) {
                direction = HEIGHTDECREASE;
                ww = w - 1;
                xx = 0;
            }
        }
        if ((angdeg += 5) == 360) {
            angdeg = 0;
            threeSixty = true;
        }
    }


    public void render (int w, int h, Graphics2D g2) {

        Rectangle rect = new Rectangle (xx, yy, ww, hh);

        AffineTransform Tx = new AffineTransform ();
        Tx.rotate (Math.toRadians (angdeg), w / 2, h / 2);

        GeneralPath path = new GeneralPath ();
        if (doOvals) {
            path.append (ovals, false);
        }
        if (doText) {
            path.append (Tx.createTransformedShape (textshape), false);
        }
        else {
            path.append (Tx.createTransformedShape (rectshape), false);
        }

        if (doIntersection) {
            g2.clip (rect);
            g2.clip (path);
        }

        g2.setColor (Color.green);
        g2.fill (rect);

        Graphics2D g2d = (Graphics2D) g2.create ();
        try {
            g2d.setClip (new Rectangle (0, 0, w, h));
            g2d.setColor (Color.lightGray);
            g2d.draw (rect);
            g2d.setColor (Color.black);
            g2d.draw (path);
        }
        finally {
            g2d.dispose ();
        }
    }


    public static void main (String argv[]) {
        createDemoFrame (new Intersection ());
    }


} // End Intersection
