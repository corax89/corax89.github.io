/*
 * @(#)ClipAnim.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

package demos.j2d.Clipping;

import demos.j2d.AnimatingSurface;
import demos.j2d.Surface;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;


/**
 * Animated clipping of an image & composited shapes.
 */
public class ClipAnim extends AnimatingSurface {

    private static Image dimg, cimg;
    static TexturePaint texture;

    static {
        BufferedImage bi = Surface.newBufferedImage (5, 5, true);
        Graphics2D big = bi.createGraphics ();
        big.setBackground (Color.yellow);
        big.clearRect (0, 0, 5, 5);
        big.setColor (Color.red);
        big.fillRect (0, 0, 3, 3);
        texture = new TexturePaint (bi, new Rectangle (0, 0, 5, 5));
    }

    private AnimVal animval[] = new AnimVal[3];
    protected boolean doObjects = true;
    private Paint gradient;
    private int dukeX, dukeY;

    public Rectangle getFlipArea () {
        GeneralPath p1 = new GeneralPath ();
        GeneralPath p2 = new GeneralPath ();

        for (int i = 0; i < animval.length; i++) {
            if (animval[i].isSelected) {
                float x = animval[i].x;
                float y = animval[i].y;
                float ew = animval[i].ew;
                float eh = animval[i].eh;
                p1.append (new Ellipse2D.Float (x, y, ew, eh), false);
                p2.append (new Rectangle2D.Float (x + 5, y + 5, ew - 10, eh - 10), false);
            }
        }

        if (animval[0].isSelected || animval[1].isSelected ||
            animval[2].isSelected) {
            Rectangle r1 = p1.getBounds ();
            Rectangle r2 = p2.getBounds ();
            return r1.union (r2);
        }

        return null;
    }

    public ClipAnim () {

        cimg = getImage ("clouds.jpg");

        dimg = getImage ("dukeplug.gif");

        setBackground (Color.white);
        animval[0] = new AnimVal (true);
        animval[1] = new AnimVal (false);
        animval[2] = new AnimVal (false);
    }


    public void reset (int w, int h) {
        for (int i = 0; i < animval.length; i++) {
            animval[i].reset (w, h);
        }
        gradient = new GradientPaint (0, h / 2, Color.red, w * .4f, h * .9f, Color.yellow);
        dukeX = (int) (w * .25 - dimg.getWidth (this) / 2);
        dukeY = (int) (h * .25 - dimg.getHeight (this) / 2);
    }


    public void step (int w, int h) {
        for (int i = 0; i < animval.length; i++) {
            if (animval[i].isSelected) {
                animval[i].step (w, h);
            }
        }
    }


    public void render (int w, int h, Graphics2D g2) {
        System.gc ();

        GeneralPath p1 = new GeneralPath ();
        GeneralPath p2 = new GeneralPath ();

        Rectangle drawRect = null;

        for (int i = 0; i < animval.length; i++) {
            if (animval[i].isSelected) {
                float x = animval[i].x;
                float y = animval[i].y;
                float ew = animval[i].ew;
                float eh = animval[i].eh;
                p1.append (new Ellipse2D.Float (x, y, ew, eh), false);
                p2.append (new Rectangle2D.Float (x + 5, y + 5, ew - 10, eh - 10), false);
            }
        }

        if (animval[0].isSelected || animval[1].isSelected ||
            animval[2].isSelected) {
            g2.setClip (p1);
            g2.clip (p2);

            drawRect = p1.getBounds ().union (p2.getBounds ());
        }

        if (doObjects) {
            int w2 = w / 2;
            int h2 = h / 2;
            g2.drawImage (cimg, 0, 0, w2, h2, null);

            g2.drawImage (dimg, dukeX, dukeY, null);

            if (drawRect.intersects (new Rectangle (w2, 0, w2, h2))) {
                g2.setPaint (texture);
                g2.fillRect (w2, 0, w2, h2);
            }

            if (drawRect.intersects (new Rectangle (0, h2, w2, h2))) {
                g2.setPaint (gradient);
                g2.fillRect (0, h2, w2, h2);
            }

            if (drawRect.intersects (new Rectangle (w2, h2, w2, h2))) {
                g2.setColor (Color.lightGray);
                g2.fillRect (w2, h2, w2, h2);
            }

            if (drawRect.intersects (new Rectangle (w2, h2, w2 - 1, h2 - 1))) {
                g2.setColor (Color.red);
                g2.drawOval (w2, h2, w2 - 1, h2 - 1);
            }
        }
        else {
            g2.setColor (Color.lightGray);
            g2.fillRect (0, 0, w, h);
        }
    }


    public static void main (String argv[]) {
        createDemoFrame (new ClipAnim ());
    }


    public class AnimVal {
        float ix = 5.0f;
        float iy = 3.0f;
        float iw = 5.0f;
        float ih = 3.0f;
        float x, y;
        float ew, eh;   // ellipse width & height
        boolean isSelected;

        public AnimVal (boolean isSelected) {
            this.isSelected = isSelected;
        }


        public void step (int w, int h) {
            x += ix;
            y += iy;
            ew += iw;
            eh += ih;
            if (ew > w / 2) {
                ew = w / 2;
                iw = (float) (Math.random () * -w / 16 - 1);
            }
            if (ew < w / 8) {
                ew = w / 8;
                iw = (float) (Math.random () * w / 16 + 1);
            }
            if (eh > h / 2) {
                eh = h / 2;
                ih = (float) (Math.random () * -h / 16 - 1);
            }
            if (eh < h / 8) {
                eh = h / 8;
                ih = (float) (Math.random () * h / 16 + 1);
            }
            if ((x + ew) > w) {
                x = (w - ew) - 1;
                ix = (float) (Math.random () * -w / 32 - 1);
            }
            if (x < 0) {
                x = 2;
                ix = (float) (Math.random () * w / 32 + 1);
            }
            if ((y + eh) > h) {
                y = (h - eh) - 2;
                iy = (float) (Math.random () * -h / 32 - 1);
            }
            if (y < 0) {
                y = 2;
                iy = (float) (Math.random () * h / 32 + 1);
            }
        }


        public void reset (int w, int h) {
            x = (float) (Math.random () * w);
            y = (float) (Math.random () * h);
            ew = (float) ((Math.random () * w) / 2);
            eh = (float) ((Math.random () * h) / 2);
        }
    }


} // End ClipAnim
