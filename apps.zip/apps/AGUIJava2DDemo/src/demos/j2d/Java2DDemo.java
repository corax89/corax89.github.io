/*
 * @(#)Java2DDemo.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */


package demos.j2d;

import demos.j2d.Arcs_Curves.Arcs;
import demos.j2d.Arcs_Curves.BezierAnim;
import demos.j2d.Arcs_Curves.Curves;
import demos.j2d.Arcs_Curves.Ellipses;
import demos.j2d.Clipping.ClipAnim;
import demos.j2d.Clipping.Intersection;
import demos.j2d.Composite.ACimages;
import demos.j2d.Lines.Caps;
import demos.j2d.Lines.LineAnim;

import java.awt.*;
import java.awt.event.*;

public class Java2DDemo extends Frame {
    public static int FRAME_WIDTH = 640;
    public static int FRAME_HEIGHT = 480;

    public static boolean antialiasingOn = true;

    private DemoPanel[] demoPanels = null;
    private int runningDemo = 0;

    public static String[] demoNames = {
        "Ellipses",
        "Curves",
        "BezierAnim",
        "Arcs",
        "ACimages",
        "LineAnim",
        "ClipAnim",
        "Intersection",
        "Caps"
    };

    public static Class[] demoClass = {
        Ellipses.class,
        Curves.class,
        BezierAnim.class,
        Arcs.class,
        ACimages.class,
        LineAnim.class,
        ClipAnim.class,
        Intersection.class,
        Caps.class,
        About.class
    };

    private static int MAX_DEMOS = demoClass.length;

    public static ShapeButton[] buttons = {
        new ShapeButton (
            Color.black,
            Color.blue,
            ShapeButton.BACK_SHAPE),
        new ShapeButton (
            Color.black,
            Color.green,
            ShapeButton.HOME_SHAPE),
        new ShapeButton (
            Color.black,
            Color.blue,
            ShapeButton.FORWARD_SHAPE),
        new ShapeButton (
            Color.black,
            Color.yellow,
            ShapeButton.AA_SHAPE),
        new ShapeButton (
            Color.black,
            Color.red,
            ShapeButton.EXIT_SHAPE),
    };

    public static void main (String[] args) {
        Dimension d = Toolkit.getDefaultToolkit ().getScreenSize ();
        FRAME_WIDTH = d.width;
        FRAME_HEIGHT = d.height;
        if (args.length > 0)
            FRAME_WIDTH = Integer.parseInt (args[0]);
        if (args.length > 1)
            FRAME_HEIGHT = Integer.parseInt (args[1]);

        new Java2DDemo (demoClass.length - 1);
    }

    public Java2DDemo (int demo) {
        super ("AGUI-Java2D Demo");
        /* create all the demo panels */
        demoPanels = new DemoPanel[demoClass.length];

        this.addWindowListener (
            new WindowAdapter() {
                public void windowClosing (WindowEvent e) {
                    System.exit (0);
                }
            });

        createToolbar ();
        if (isJ2SE ()) {
            this.setSize (FRAME_WIDTH, FRAME_HEIGHT);
        }
        doLayout ();
        invalidate ();
        runDemo (demo); // Show about screen
        this.setVisible (true);
        repaint ();
    }

    private void createToolbar () {
        KeyAdapter keyListener = new KeyAdapter() {
            public void keyPressed (KeyEvent e) {

                int index = Java2DDemo.this.runningDemo;
                switch (e.getKeyCode ()) {
                case KeyEvent.VK_LEFT: // BACK
                    index--;
                    if (index < 0)
                        index = MAX_DEMOS - 2; // skip About
                    break;
                case KeyEvent.VK_RIGHT: // FORWARD
                    index++;
                    index = index % (MAX_DEMOS);
                    if (index == (MAX_DEMOS - 1)) // skip About
                        index = 0;
                    break;
                default:
                    return;
                }
                if (index >= 0 && index < demoPanels.length) {
                    if (Java2DDemo.this.runningDemo != index) {
                        if (Java2DDemo.this.runningDemo > -1) {
                            demoPanels[Java2DDemo.this.runningDemo].stop ();
                            Java2DDemo.this.remove (demoPanels[Java2DDemo.this.runningDemo]);
                        }
                        Java2DDemo.this.runDemo (index);
                    }
                }
            }
        };
        this.addKeyListener (keyListener);
        MouseAdapter mouseListener = new MouseAdapter() {
            public void mouseReleased (MouseEvent e) {
                ShapeButton b = (ShapeButton) e.getSource ();
                int demo_to_run = getDemoIndex (b);
                if (demo_to_run >= 0 && demo_to_run < demoPanels.length) {
                    if (runningDemo > -1 && runningDemo != demo_to_run) {
                        demoPanels[runningDemo].stop ();
                        Java2DDemo.this.remove (demoPanels[runningDemo]);
                        Java2DDemo.this.runDemo (demo_to_run);
                    }
                }
            }

            int getDemoIndex (ShapeButton cb) {
                int index;
                int i;
                for (i = 0; i < buttons.length; i++) {
                    if (cb == buttons[i])
                        break;
                }

                // get the current running demo
                index = Java2DDemo.this.runningDemo;

                switch (i) {
                case 0: // BACK
                    index--;
                    if (index < 0)
                        index = MAX_DEMOS - 2; // skip About
                    break;
                case 1: // HOME
                    index = MAX_DEMOS - 1;
                    break;
                case 2: // FORWARD
                    index++;
                    index = index % (MAX_DEMOS);
                    if (index == (MAX_DEMOS - 1)) // skip About
                        index = 0;
                    break;
                case 3: // ANTIALIASED
                    antialiasingOn = !antialiasingOn;
                    Surface surface = demoPanels[runningDemo].surface;
                    surface.setAntiAlias (antialiasingOn);
                    if (surface.animating == null) {
                        repaint ();
                    }
                    break;
                case 4: // EXIT
                    System.exit (0);
                }

                return index;
            }
        };

        Container toolbar = new Container ();
        toolbar.setLayout (new BorderLayout ());

        Container left_pane = new Container ();
        Container right_pane = new Container ();
        left_pane.setLayout (new FlowLayout (FlowLayout.CENTER, 10, 10));
        int i;
        for (i = 0; i < buttons.length - 2; i++) {
            left_pane.add (buttons[i]);
            buttons[i].addMouseListener (mouseListener);
        }

        right_pane.setLayout (new FlowLayout (FlowLayout.CENTER, 10, 10));

        for (; i < buttons.length; i++) {
            right_pane.add (buttons[i]);
            buttons[i].addMouseListener (mouseListener);
        }
        toolbar.add ("West", left_pane);
        toolbar.add ("East", right_pane);

        this.add ("North", toolbar);
        toolbar.setVisible (true);
    }

    private void runDemo (int demo) {
        if (runningDemo >= 0 && runningDemo < demoPanels.length && demoPanels[runningDemo] != null) {
            demoPanels[runningDemo] = null;
            System.gc ();
        }
        try {
            demoPanels[demo] = new DemoPanel (demoClass[demo].newInstance ());
            demoPanels[demo].setSize (FRAME_WIDTH, FRAME_HEIGHT);
        }
        catch (Exception ex) {
            ex.printStackTrace ();
            System.exit (1);
        }

        runningDemo = demo;
        this.add ("Center", demoPanels[demo]);
        this.validate ();
        Surface surface = demoPanels[runningDemo].surface;
        surface.setAntiAlias (antialiasingOn);
        surface.repaintArea = null;
        if (surface.animating != null) {
            surface.animating.start ();
        }
        else {
            // If it's not an animating surface, force redraw of the whole Frame
            repaint ();
        }
    }

    private static boolean isJ2SE () {
        try {
            Class.forName ("java.applet.Applet");
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
}
