/*
 * @(#)About.java	1.50 06/08/29
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

package demos.j2d;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

public class About extends Surface {

    BasicStroke wideStroke;
    BasicStroke thinStroke;
    BasicStroke thinnerStroke;
    BasicStroke thinnestStroke;
    Duke duke;
    Cloud bgCloud;
    Cloud[] clouds;
    Image origImage;
    Image javaLogoImage;
    float logoWidth;
    float logoHeight;

    static final Color PURPLE = new Color (0x7777AA);
    static final Color DARKER_PURPLE = PURPLE.darker ();
    static final Color DARK_ORANGE = Color.orange.darker ();
    static final Color TRANS_ORANGE = new Color (
        Color.orange.getRed (),
        Color.orange.getGreen (),
        Color.orange.getBlue (),
        200);

    public About () {
        setBackground (Color.white);
        thinnestStroke = new BasicStroke (
            (float) 2.0,
            BasicStroke.CAP_SQUARE,
            BasicStroke.JOIN_MITER,
            (float) 10.0);
        thinnerStroke = new BasicStroke (
            (float) 3.0,
            BasicStroke.CAP_SQUARE,
            BasicStroke.JOIN_MITER,
            (float) 10.0);
        thinStroke = new BasicStroke (
            (float) 6.0,
            BasicStroke.CAP_SQUARE,
            BasicStroke.JOIN_MITER,
            (float) 10.0);
        wideStroke = new BasicStroke (
            (float) 9.0,
            BasicStroke.CAP_SQUARE,
            BasicStroke.JOIN_MITER,
            (float) 10.0);

        origImage = getImage ("java_logo.gif");
        if (origImage != null) {
            this.logoWidth = (float) origImage.getWidth (null);
            this.logoHeight = (float) origImage.getHeight (null);
            javaLogoImage = origImage;
        }
    }

    static final int WIDTH = 300;
    static final int HEIGHT = 180;

    int width;
    int height;

    public void render (int w, int h, Graphics2D g2) {
        int x;
        int y;
        boolean dimension_changed = false;

        if (w < WIDTH)
            w = WIDTH;
        if (h < HEIGHT)
            h = HEIGHT;

        if ((w != this.width) || (h != this.height)) {
            dimension_changed = true;
            this.width = w;
            this.height = h;
        }

        double sx = (float) w / WIDTH;
        double sy = (float) h / HEIGHT;

        x = 210;
        y = 5;

        x = (int) ((float) (w * x) / (float) (WIDTH));
        y = (int) ((float) (h * y) / (float) (HEIGHT));


        if (dimension_changed || this.bgCloud == null) {
            this.bgCloud = new Cloud (x, y, thinnerStroke, sx, sy);
        }
        this.bgCloud.render (g2);

        g2.setStroke (wideStroke);
        g2.setColor (DARK_ORANGE);
        x = 200;
        y = 30;
        x = (int) ((float) (w * x) / (float) (WIDTH));
        y = (int) ((float) (h * y) / (float) (HEIGHT));
        Shape shape = new Ellipse2D.Float (
            x, y,
            (float) (40. * sx),
            (float) (40. * sy));
        g2.draw (shape);
        g2.setColor (TRANS_ORANGE);
        g2.fill (shape);

        if (dimension_changed || this.clouds == null) {
            this.clouds = new Cloud[2];

            x = 135;
            y = 30;
            x = (int) ((float) (w * x) / (float) (WIDTH));
            y = (int) ((float) (h * y) / (float) (HEIGHT));
            this.clouds[0] = new Cloud (x, y, thinnerStroke, sx * 0.75, sy * 0.75);

            x = 140;
            y = 5;
            x = (int) ((float) (w * x) / (float) (WIDTH));
            y = (int) ((float) (h * y) / (float) (HEIGHT));

            this.clouds[1] = new Cloud (x, y, thinnerStroke, sx * 0.35, sy * 0.35);
        }

        for (int c = 0; c < clouds.length; c++)
            this.clouds[c].render (g2);

        g2.setStroke (thinnerStroke);
        g2.setFont (new Font ("Dialog", Font.BOLD, 36));

        x = 125;
        y = 95;
        x = (int) ((float) (w * x) / (float) (WIDTH));
        y = (int) ((float) (h * y) / (float) (HEIGHT));

        g2.setPaint (createTexturePaint (Color.red, Color.yellow));
        g2.drawString ("AGUI", x, y);

        g2.setFont (new Font ("Dialog", Font.BOLD, 20));
        g2.setStroke (thinnestStroke);
        x = 115;
        y = 125;
        x = (int) ((float) (w * x) / (float) (WIDTH));
        y = (int) ((float) (h * y) / (float) (HEIGHT));
        int text_width = g2.getFontMetrics ().stringWidth ("2D Demo");
        GradientPaint gpaint = new GradientPaint (
            (float) x, (float) y,
            Color.red,
            (float) x + text_width, (float) y,
            DARKER_PURPLE);
        g2.setPaint (gpaint);
        g2.drawString ("2D Demo", x, y);

        x = 210;
        y = 95;
        x = (int) ((float) (w * x) / (float) (WIDTH));
        y = (int) ((float) (h * y) / (float) (HEIGHT));
        if (dimension_changed || this.duke == null)
            this.duke = new Duke (x, y, thinnerStroke, sx, sy);
        this.duke.render (g2);

        // can be null if the image is not found.
        x = 10;
        y = 95;
        x = (int) ((float) (w * x) / (float) (WIDTH));
        y = (int) ((float) (h * y) / (float) (HEIGHT));
        if (this.javaLogoImage != null) {
            if (dimension_changed && (sx > 1.0 || sy > 1.0)) {
                int img_w = (int) (this.logoWidth * sx);
                int img_h = (int) (this.logoHeight * sy);
                this.javaLogoImage = this.origImage.getScaledInstance (
                    img_w,
                    img_h,
                    Image.SCALE_SMOOTH);
                MediaTracker tracker = new MediaTracker (this);
                tracker.addImage (this.javaLogoImage, 0);
                try {
                    tracker.waitForID (0);
                }
                catch (InterruptedException e) {
                    e.printStackTrace ();
                }
            }
            g2.drawImage (this.javaLogoImage, x, y, null);
        }
    }

    public static Paint createTexturePaint (Color c1, Color c2) {
        BufferedImage bi = Surface.newBufferedImage (5, 5, false);
        Graphics2D big = bi.createGraphics ();
        big.setBackground (c1);
        big.clearRect (0, 0, 5, 5);
        big.setColor (c2);
        big.fillRect (0, 0, 3, 3);
        return new TexturePaint (bi, new Rectangle (0, 0, 5, 5));
    }

}

class Cloud {
    Stroke stroke;
    Shape cloud;

    public Cloud (int x, int y, Stroke stroke) {
        this (x, y, stroke, 1., 1.);
    }

    public Cloud (int x, int y, Stroke stroke, double sx, double sy) {
        AffineTransform transform = new AffineTransform ();
        transform.translate ((double) x, (double) y);
        transform.scale (sx, sy);
        this.stroke = stroke;
        this.cloud = getCloud (transform);
    }

    public void render (Graphics2D g2) {
        g2.setColor (Color.black);
        g2.setStroke (this.stroke);
        g2.draw (this.cloud);
        g2.setColor (Color.cyan.brighter ());
        g2.fill (this.cloud);
    }

    Shape getCloud (AffineTransform transform) {
        GeneralPath cloud = createCloud ();
        return cloud.createTransformedShape (transform);
    }

    static GeneralPath nonTxCloud;

    private static GeneralPath createCloud () {
        if (nonTxCloud == null) {
            GeneralPath path = new GeneralPath ();
            path.moveTo (15, 20);
            path.curveTo (0, 10, 30, 0, 45, 10);
            path.curveTo (48, 0, 57, 0, 60, 15);
            path.curveTo (90, 0, 90, 30, 70, 40);
            path.curveTo (90, 45, 90, 60, 70, 50);
            path.curveTo (65, 60, 35, 60, 30, 50);
            path.curveTo (28, 60, 17, 60, 15, 45);
            path.curveTo (2, 38, 2, 25, 15, 20);
            nonTxCloud = path;
        }

        return nonTxCloud;
    }

}

class Duke {
    static final double DEFAULT_SCALE_X = 0.384;
    static final double DEFAULT_SCALE_Y = 0.36;
    private static final BasicStroke DEFAULT_STROKE = new BasicStroke ();
    private static final int yOffset = 23;

    Stroke stroke;
    Shape body;
    Shape arms;
    Shape nose;
    Shape shine;
    Shape head;
    Shape bodyShadow;
    Shape armsShadow;

    public Duke () {
        this (0, 0);
    }

    public Duke (int x, int y) {
        this (x, y, DEFAULT_STROKE, 1., 1.);
    }

    public Duke (int x, int y, Stroke stroke) {
        this (x, y, stroke, 1., 1.);
    }

    public Duke (int x, int y, Stroke stroke, double sx, double sy) {
        sx *= DEFAULT_SCALE_X;
        sy *= DEFAULT_SCALE_Y;
        AffineTransform transform = new AffineTransform ();
        transform.translate ((double) x, (double) y);
        transform.scale (sx, sy);
        this.stroke = stroke;

        this.body = getBody (transform);
        this.arms = getArms (transform);
        this.nose = getNose (transform);
        this.shine = getNoseShine (transform);
        this.head = getHead (transform);
        this.bodyShadow = getShadow (this.body.getBounds (), this.body);
        this.armsShadow = getShadow (this.body.getBounds (), this.arms);
    }

    public void render (Graphics2D g2) {
        g2.setColor (Color.lightGray);
        g2.fill (this.bodyShadow);
        g2.draw (this.armsShadow);

        g2.setColor (Color.white);
        g2.fill (this.body);
        g2.setColor (Color.black);
        g2.setStroke (this.stroke);
        g2.draw (this.body);
        g2.draw (this.arms);
        g2.setColor (Color.red);
        g2.fill (this.nose);
        g2.setColor (Color.white);
        g2.fill (this.shine);
        g2.setColor (Color.black);
        g2.fill (this.head);
    }

    Shape getBody (AffineTransform transform) {
        GeneralPath body = createBody ();
        return body.createTransformedShape (transform);
    }

    Shape getArms (AffineTransform transform) {
        GeneralPath arms = createArms ();
        return arms.createTransformedShape (transform);
    }

    Shape getNose (AffineTransform transform) {
        GeneralPath nose = new GeneralPath (createNose ());
        return nose.createTransformedShape (transform);
    }

    Shape getNoseShine (AffineTransform transform) {
        GeneralPath shine = new GeneralPath (createNoseShine ());
        return shine.createTransformedShape (transform);
    }

    Shape getHead (AffineTransform transform) {
        GeneralPath head = new GeneralPath (createHead ());
        return head.createTransformedShape (transform);
    }

    static Shape getShadow (Rectangle bounds, Shape shape) {
        GeneralPath path;
        if (shape instanceof GeneralPath)
            path = (GeneralPath) shape;
        else
            path = new GeneralPath (shape);

        AffineTransform at = new AffineTransform ();
        at.setToTranslation (10, 10 + bounds.y + bounds.height);
        at.scale (1.0, 0.6);
        at.shear (-0.5, 0.);
        at.translate (0., -bounds.y - bounds.height);

        return path.createTransformedShape (at);
    }

    // Duke's body parts in user space. (Non Transformed)
    static GeneralPath nonTxBody;
    static GeneralPath nonTxArms;
    static Shape nonTxNoseShine;
    static Shape nonTxHead;

    private static GeneralPath createBody () {
        if (nonTxBody == null) {
            GeneralPath path = new GeneralPath ();
            path.moveTo (100, 25 - yOffset);
            path.curveTo (140, 60 - yOffset, 170, 200 - yOffset, 140, 200 - yOffset);
            path.curveTo (130, 200 - yOffset, 120, 175 - yOffset, 90, 175 - yOffset);
            path.curveTo (70, 175 - yOffset, 70, 200 - yOffset, 60, 200 - yOffset);
            path.curveTo (40, 200 - yOffset, 60, 60 - yOffset, 100, 25 - yOffset);
            nonTxBody = path;
        }

        return nonTxBody;
    }

    private static Shape createNose () {
        return new Ellipse2D.Float (70, 65, 60, 50);
    }

    private static GeneralPath createArms () {
        if (nonTxArms == null) {
            Shape left_arm = new CubicCurve2D.Float (
                138, 100 - yOffset,
                170, 135 - yOffset,
                180, 120 - yOffset,
                150, 140 - yOffset);
            Shape right_arm = new CubicCurve2D.Float (
                63, 100 - yOffset,
                33, 135 - yOffset,
                23, 120 - yOffset,
                53, 140 - yOffset);

            GeneralPath path = new GeneralPath (left_arm);
            path.append (right_arm, false);
            nonTxArms = path;
        }
        return nonTxArms;
    }

    private static Shape createNoseShine () {
        if (nonTxNoseShine == null) {
            AffineTransform t = new AffineTransform ();
            t.setToTranslation (90, 90 - 13);
            t.rotate (-Math.PI / 10);
            nonTxNoseShine = t.createTransformedShape (
                new Ellipse2D.Float (-12, -9, 24, 18));
        }
        return nonTxNoseShine;
    }

    private static Shape createHead () {
        if (nonTxHead == null) {
            Area h = new Area (createBody ());
            h.subtract (new Area (createNose ()));
            h.subtract (new Area (new Ellipse2D.Float (-50, 100, 300, 250)));
            nonTxHead = h;
        }
        return nonTxHead;
    }

}
