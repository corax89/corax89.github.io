/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package example.manyballs;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;

/**
 * Class periodically repainting the canvas with all the balls.
 */
public class Repainter implements Runnable {

    /* target display */
    private Display display;
    /* canvas to repaint */
    private Canvas canvas;
    /* whether the repainting is stopped */
    private boolean stop;

    /**
     * Creates a new instance of repainter.
     *
     * @param display Target display
     * @param canvas  Canvas to repaint
     */
    public Repainter (Display display, Canvas canvas) {
        this.display = display;
        this.canvas = canvas;
    }

    /**
     * Starts the repainter
     */
    public void start () {
        stop = false;
        run ();
    }

    /**
     * Stops the repainter
     */
    public void stop () {
        stop = true;
    }

    /**
     * Actual repainting process being performed serially with actual display
     * updates.
     */
    public void run () {

        if (stop) {
            return;
        }

        try {
            // avoid insane repainting
            Thread.sleep (5);
        }
        catch (InterruptedException e) {
            // Never mind
        }

        canvas.repaint ();
        display.callSerially (this);
    }
}
