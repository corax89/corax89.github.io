/*
 * @(#)ButtonDemo.java	1.54 06/05/31
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ItemListener;
import java.util.Vector;

/**
 * JButton, JRadioButton, JToggleButton, JCheckBox Demos
 */
public class ButtonDemo extends DemoModule implements ChangeListener {

    JPanel buttonPanel = new JPanel ();
    JPanel checkboxPanel = new JPanel ();
    JPanel radioButtonPanel = new JPanel ();

    Vector buttons = new Vector ();
    Vector checkboxes = new Vector ();
    Vector radiobuttons = new Vector ();

    Vector currentControls = buttons;

    JButton button;
    JCheckBox check;
    JRadioButton radio;

    EmptyBorder border1 = new EmptyBorder (1, 1, 1, 1);
    EmptyBorder border2 = new EmptyBorder (2, 2, 2, 2);

    ItemListener buttonDisplayListener = null;
    ItemListener buttonPadListener = null;

    Insets insets0 = new Insets (0, 0, 0, 0);
    Insets insets10 = new Insets (10, 10, 10, 10);

    /**
     * main method allows us to run as a standalone demo.
     */
    public static void main (String[] args) {
        ButtonDemo demo = new ButtonDemo (null);
        demo.mainImpl ();
    }

    /**
     * ButtonDemo Constructor
     */
    public ButtonDemo (SwingSet2 swingset) {
        // Set the title for this demo, and an icon used to represent this
        // demo inside the SwingSet2 app.
        super (swingset, "ButtonDemo", "toolbar/JButton.png");

        JPanel demo = getDemoPanel ();
        demo.setLayout (new BoxLayout (demo, BoxLayout.Y_AXIS));

        addButtons ();
        addRadioButtons ();
        addCheckBoxes ();
        currentControls = buttons;
    }

    public void addButtons () {
        getDemoPanel ().add (buttonPanel);

        buttonPanel.setLayout (new BoxLayout (buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBorder (border1);

        JPanel p1 = createVerticalPanel (true);
        p1.setAlignmentY (TOP_ALIGNMENT);
        buttonPanel.add (p1);

        // Image Buttons
        JPanel p3 = createHorizontalPanel (false);
        p1.add (p3);
        p3.setLayout (new BoxLayout (p3, BoxLayout.X_AXIS));
        p3.setBorder (
            new TitledBorder (
                null, getString ("ButtonDemo.imagebuttons"),
                TitledBorder.LEFT, TitledBorder.TOP));

        // home image button
        String description = getString ("ButtonDemo.phone");
        button = new JButton (createImageIcon ("buttons/b1.gif", description));
        button.setPressedIcon (createImageIcon ("buttons/b1p.gif", description));
        button.setRolloverIcon (createImageIcon ("buttons/b1r.gif", description));
        button.setDisabledIcon (createImageIcon ("buttons/b1d.gif", description));
        button.setMargin (new Insets (0, 0, 0, 0));
        p3.add (button);
        buttons.add (button);

        // write image button
        description = getString ("ButtonDemo.write");
        button = new JButton (createImageIcon ("buttons/b2.gif", description));
        button.setPressedIcon (createImageIcon ("buttons/b2p.gif", description));
        button.setRolloverIcon (createImageIcon ("buttons/b2r.gif", description));
        button.setDisabledIcon (createImageIcon ("buttons/b2d.gif", description));
        button.setMargin (new Insets (0, 0, 0, 0));
        p3.add (button);
        buttons.add (button);

        // write image button
        description = getString ("ButtonDemo.peace");
        button = new JButton (createImageIcon ("buttons/b3.gif", description));
        button.setPressedIcon (createImageIcon ("buttons/b3p.gif", description));
        button.setRolloverIcon (createImageIcon ("buttons/b3r.gif", description));
        button.setDisabledIcon (createImageIcon ("buttons/b3d.gif", description));
        button.setMargin (new Insets (0, 0, 0, 0));
        p3.add (button);
        buttons.add (button);

        currentControls = buttons;
    }

    public void addRadioButtons () {
        ButtonGroup group;

        getDemoPanel ().add (radioButtonPanel);

        radioButtonPanel.setLayout (new BoxLayout (radioButtonPanel, BoxLayout.Y_AXIS));

        JPanel p1 = createVerticalPanel (true);
        p1.setAlignmentY (TOP_ALIGNMENT);
        radioButtonPanel.add (p1);

        // Image Radio Buttons
        group = new ButtonGroup ();
        JPanel p3 = createHorizontalPanel (false);
        p1.add (p3);
        p3.setLayout (new BoxLayout (p3, BoxLayout.X_AXIS));
        p3.setBorder (
            new TitledBorder (
                null, getString ("ButtonDemo.imageradiobuttons"),
                TitledBorder.LEFT, TitledBorder.TOP));

        // image radio button 1
        String description = getString ("ButtonDemo.customradio");
        String text = getString ("ButtonDemo.radio1");
        radio = new JRadioButton (text, createImageIcon ("buttons/rb.gif", description));
        radio.setPressedIcon (createImageIcon ("buttons/rbp.gif", description));
        radio.setRolloverIcon (createImageIcon ("buttons/rbr.gif", description));
        radio.setRolloverSelectedIcon (createImageIcon ("buttons/rbrs.gif", description));
        radio.setSelectedIcon (createImageIcon ("buttons/rbs.gif", description));
        radio.setMargin (new Insets (0, 0, 0, 0));
        group.add (radio);
        p3.add (radio);
        radiobuttons.add (radio);

        // image radio button 2
        text = getString ("ButtonDemo.radio2");
        radio = new JRadioButton (text, createImageIcon ("buttons/rb.gif", description));
        radio.setPressedIcon (createImageIcon ("buttons/rbp.gif", description));
        radio.setRolloverIcon (createImageIcon ("buttons/rbr.gif", description));
        radio.setRolloverSelectedIcon (createImageIcon ("buttons/rbrs.gif", description));
        radio.setSelectedIcon (createImageIcon ("buttons/rbs.gif", description));
        radio.setMargin (new Insets (0, 0, 0, 0));
        group.add (radio);
        p3.add (radio);
        radiobuttons.add (radio);

        // image radio button 3
        text = getString ("ButtonDemo.radio3");
        radio = new JRadioButton (text, createImageIcon ("buttons/rb.gif", description));
        radio.setPressedIcon (createImageIcon ("buttons/rbp.gif", description));
        radio.setRolloverIcon (createImageIcon ("buttons/rbr.gif", description));
        radio.setRolloverSelectedIcon (createImageIcon ("buttons/rbrs.gif", description));
        radio.setSelectedIcon (createImageIcon ("buttons/rbs.gif", description));
        radio.setMargin (new Insets (0, 0, 0, 0));
        group.add (radio);
        radiobuttons.add (radio);
        p3.add (radio);

        currentControls = radiobuttons;
    }


    public void addCheckBoxes () {
        getDemoPanel ().add (checkboxPanel);


        checkboxPanel.setLayout (new BoxLayout (checkboxPanel, BoxLayout.Y_AXIS));
        checkboxPanel.setBorder (border1);

        JPanel p1 = createVerticalPanel (true);
        p1.setAlignmentY (TOP_ALIGNMENT);
        checkboxPanel.add (p1);

        // Image Radio Buttons
        JPanel p3 = createHorizontalPanel (false);
        p1.add (p3);
        p3.setLayout (new BoxLayout (p3, BoxLayout.X_AXIS));
        p3.setBorder (
            new TitledBorder (
                null, getString ("ButtonDemo.imagecheckboxes"),
                TitledBorder.LEFT, TitledBorder.TOP));

        // image checkbox 1
        String description = getString ("ButtonDemo.customcheck");
        String text = getString ("ButtonDemo.check1");
        check = new JCheckBox (text, createImageIcon ("buttons/cb.gif", description));
        check.setRolloverIcon (createImageIcon ("buttons/cbr.gif", description));
        check.setRolloverSelectedIcon (createImageIcon ("buttons/cbrs.gif", description));
        check.setSelectedIcon (createImageIcon ("buttons/cbs.gif", description));
        check.setMargin (new Insets (0, 0, 0, 0));
        p3.add (check);
        checkboxes.add (check);

        // image checkbox 2
        text = getString ("ButtonDemo.check2");
        check = new JCheckBox (text, createImageIcon ("buttons/cb.gif", description));
        check.setRolloverIcon (createImageIcon ("buttons/cbr.gif", description));
        check.setRolloverSelectedIcon (createImageIcon ("buttons/cbrs.gif", description));
        check.setSelectedIcon (createImageIcon ("buttons/cbs.gif", description));
        check.setMargin (new Insets (0, 0, 0, 0));
        p3.add (check);
        checkboxes.add (check);


        currentControls = checkboxes;
    }


    public void stateChanged (ChangeEvent e) {
        SingleSelectionModel model = (SingleSelectionModel) e.getSource ();
        if (model.getSelectedIndex () == 0) {
            currentControls = buttons;
        }
        else if (model.getSelectedIndex () == 1) {
            currentControls = radiobuttons;
        }
        else if (model.getSelectedIndex () == 2) {
            currentControls = checkboxes;
        }
    }

    public Vector getCurrentControls () {
        return currentControls;
    }
}
