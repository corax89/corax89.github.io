/*
 * @(#)TableDemo.java	1.54 06/05/31
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import java.awt.*;
import java.util.Vector;

/**
 * Table demo
 */
public class TableDemo extends DemoModule {
    JTable tableView;
    JScrollPane scrollpane;
    Dimension origin = new Dimension (0, 0);

    JLabel rowHeightLabel;

    JSlider rowHeightSlider;

    JPanel controlPanel;
    JScrollPane tableAggregate;

    final int INITIAL_ROWHEIGHT = 33;

    /**
     * main method allows us to run as a standalone demo.
     */
    public static void main (String[] args) {
        TableDemo demo = new TableDemo (null);
        demo.mainImpl ();
    }

    /**
     * TableDemo Constructor
     */
    public TableDemo (SwingSet2 swingset) {
        super (swingset, "TableDemo", "toolbar/JTable.png");

        getDemoPanel ().setLayout (new BorderLayout ());
        controlPanel = new JPanel (new FlowLayout (FlowLayout.LEFT));
        JPanel column1 = new JPanel (new ColumnLayout ());
        JPanel column2 = new JPanel (new ColumnLayout ());
        JPanel column3 = new JPanel (new ColumnLayout ());

        getDemoPanel ().add (controlPanel, BorderLayout.NORTH);
        Vector relatedComponents = new Vector ();

        rowHeightLabel = new JLabel (getString ("TableDemo.row_height_colon"));
        column2.add (rowHeightLabel);

        rowHeightSlider = new JSlider (JSlider.HORIZONTAL, 5, 100, INITIAL_ROWHEIGHT);

        rowHeightLabel.setLabelFor (rowHeightSlider);
        column2.add (rowHeightSlider);
        rowHeightSlider.addChangeListener (
            new ChangeListener() {
                public void stateChanged (ChangeEvent e) {
                    int height = ((JSlider) e.getSource ()).getValue ();
                    tableView.setRowHeight (height);
                    tableView.repaint ();
                }
            });
        controlPanel.add (column2);

        // Show that spacing controls are related
        relatedComponents.removeAllElements ();

        relatedComponents.add (rowHeightSlider);

        // Create the table.
        tableAggregate = createTable ();
        getDemoPanel ().add (tableAggregate, BorderLayout.CENTER);

    } // TableDemo()


    public JScrollPane createTable () {

        // final
        final String[] names = {
            getString ("TableDemo.first_name"),
            getString ("TableDemo.last_name"),
            getString ("TableDemo.favorite_color"),
            getString ("TableDemo.favorite_movie"),
        };

        NamedColor aqua = new NamedColor (new Color (127, 255, 212), getString ("TableDemo.aqua"));
        NamedColor beige = new NamedColor (new Color (245, 245, 220), getString ("TableDemo.beige"));
        NamedColor black = new NamedColor (Color.black, getString ("TableDemo.black"));
        NamedColor blue = new NamedColor (new Color (0, 0, 222), getString ("TableDemo.blue"));
        NamedColor eblue = new NamedColor (Color.blue, getString ("TableDemo.eblue"));
        NamedColor jfcblue = new NamedColor (new Color (204, 204, 255), getString ("TableDemo.jfcblue"));
        NamedColor jfcblue2 = new NamedColor (new Color (153, 153, 204), getString ("TableDemo.jfcblue2"));
        NamedColor cybergreen =
            new NamedColor (Color.green.darker ().brighter (), getString ("TableDemo.cybergreen"));
        NamedColor darkgreen = new NamedColor (new Color (0, 100, 75), getString ("TableDemo.darkgreen"));
        NamedColor forestgreen = new NamedColor (Color.green.darker (), getString ("TableDemo.forestgreen"));
        NamedColor gray = new NamedColor (Color.gray, getString ("TableDemo.gray"));
        NamedColor green = new NamedColor (Color.green, getString ("TableDemo.green"));
        NamedColor orange = new NamedColor (new Color (255, 165, 0), getString ("TableDemo.orange"));
        NamedColor purple = new NamedColor (new Color (160, 32, 240), getString ("TableDemo.purple"));
        NamedColor red = new NamedColor (Color.red, getString ("TableDemo.red"));
        NamedColor rustred = new NamedColor (Color.red.darker (), getString ("TableDemo.rustred"));
        NamedColor sunpurple = new NamedColor (new Color (100, 100, 255), getString ("TableDemo.sunpurple"));
        NamedColor suspectpink =
            new NamedColor (new Color (255, 105, 180), getString ("TableDemo.suspectpink"));
        NamedColor turquoise = new NamedColor (new Color (0, 255, 255), getString ("TableDemo.turquoise"));
        NamedColor violet = new NamedColor (new Color (238, 130, 238), getString ("TableDemo.violet"));
        NamedColor yellow = new NamedColor (Color.yellow, getString ("TableDemo.yellow"));

        // Create the dummy data (a few rows of names)
        final Object[][] data = {
            {"Mike", "Albers", green, getString ("TableDemo.brazil")},
            {"Mark", "Andrews", blue, getString ("TableDemo.curse")},
            {"Brian", "Beck", black, getString ("TableDemo.bluesbros")},
            {"Lara", "Bunni", red, getString ("TableDemo.airplane")},
            {"Roger", "Brinkley", blue, getString ("TableDemo.man")},
            {"Brent", "Christian", black, getString ("TableDemo.bladerunner")},
            {"Mark", "Davidson", darkgreen, getString ("TableDemo.brazil")},
            {"Jeff", "Dinkins", blue, getString ("TableDemo.ladyvanishes")},
            {"Ewan", "Dinkins", yellow, getString ("TableDemo.bugs")},
            {"Amy", "Fowler", violet, getString ("TableDemo.reservoir")},
            {"Hania", "Gajewska", purple, getString ("TableDemo.jules")},
            {"David", "Geary", blue, getString ("TableDemo.pulpfiction")},
            {"Eric", "Hawkes", blue, getString ("TableDemo.bladerunner")},
            {"Shannon", "Hickey", green, getString ("TableDemo.shawshank")},
            {"Earl", "Johnson", green, getString ("TableDemo.pulpfiction")},
            {"Robi", "Kahn", green, getString ("TableDemo.goodfellas")},
            {"Robert", "Kim", blue, getString ("TableDemo.mohicans")},
            {"Janet", "Koenig", turquoise, getString ("TableDemo.lonestar")},
            {"Jeff", "Kesselman", blue, getString ("TableDemo.stuntman")},
            {"Onno", "Kluyt", orange, getString ("TableDemo.oncewest")},
            {"Peter", "Korn", sunpurple, getString ("TableDemo.musicman")},
        };

        // Create a model of the data.
        TableModel dataModel = new AbstractTableModel() {
            public int getColumnCount () {
                return names.length;
            }

            public int getRowCount () {
                return data.length;
            }

            public Object getValueAt (int row, int col) {
                return data[row][col];
            }

            public String getColumnName (int column) {
                return names[column];
            }

            public Class getColumnClass (int c) {
                return getValueAt (0, c).getClass ();
            }

            public void setValueAt (Object aValue, int row, int column) {
                data[row][column] = aValue;
            }
        };

        // Create the table
        tableView = new JTable (dataModel);

        // Show colors by rendering them in their own color.
        class ColorTableCellRenderer extends JLabel implements TableCellRenderer {
            protected Border noFocusBorder = new EmptyBorder (1, 1, 1, 1);
            private Color unselectedForeground;
            private Color unselectedBackground;

            public ColorTableCellRenderer () {
                super ();
                setOpaque (true);
                setBorder (noFocusBorder);
            }

            public void setValue (Object value) {
                if (value instanceof NamedColor) {
                    NamedColor c = (NamedColor) value;
                    setBackground (c);
                    setForeground (c.getTextColor ());
                    setText (c.toString ());
                }
                else {
                    setText ((value == null) ? "" : value.toString ());
                }
            }

            public Component getTableCellRendererComponent (
                JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {

                if (isSelected) {
                    super.setForeground (table.getSelectionForeground ());
                    super.setBackground (table.getSelectionBackground ());
                }
                else {
                    super.setForeground (
                        (unselectedForeground != null) ? unselectedForeground
                            : table.getForeground ());
                    super.setBackground (
                        (unselectedBackground != null) ? unselectedBackground
                            : table.getBackground ());
                }

                setFont (table.getFont ());

                if (hasFocus) {
                    setBorder (new BevelBorder (BevelBorder.RAISED));
                    if (table.isCellEditable (row, column)) {
                        super.setForeground (Color.red);
                        super.setBackground (Color.green);
                    }

                }
                else {
                    setBorder (noFocusBorder);
                }

                setValue (value);

                return this;
            }


            public void setForeground (Color c) {
                super.setForeground (c);
                unselectedForeground = c;
            }

            public void setBackground (Color c) {
                super.setBackground (c);
                unselectedBackground = c;
            }

            public boolean isOpaque () {
                Color back = getBackground ();
                Component p = getParent ();
                if (p != null) {
                    p = p.getParent ();
                }
                // p should now be the JTable.
                boolean colorMatch = (back != null) && (p != null) &&
                    back.equals (p.getBackground ()) &&
                    p.isOpaque ();
                return !colorMatch && super.isOpaque ();
            }

            public void validate () {
            }

            public void revalidate () {
            }

            public void repaint (long tm, int x, int y, int width, int height) {
            }

            public void repaint (Rectangle r) {
            }

            protected void firePropertyChange (String propertyName, Object oldValue, Object newValue) {
                // Strings get interned...
                if (propertyName == "text") {
                    super.firePropertyChange (propertyName, oldValue, newValue);
                }
            }

            public void firePropertyChange (String propertyName, boolean oldValue, boolean newValue) {
            }

        }

        TableCellRenderer colorRenderer = new ColorTableCellRenderer ();

        // Create a combo box to show that you can use one in a table.
        JComboBox comboBox = new JComboBox ();
        comboBox.addItem (aqua);
        comboBox.addItem (beige);
        comboBox.addItem (black);
        comboBox.addItem (blue);
        comboBox.addItem (eblue);
        comboBox.addItem (jfcblue);
        comboBox.addItem (jfcblue2);
        comboBox.addItem (cybergreen);
        comboBox.addItem (darkgreen);
        comboBox.addItem (forestgreen);
        comboBox.addItem (gray);
        comboBox.addItem (green);
        comboBox.addItem (orange);
        comboBox.addItem (purple);
        comboBox.addItem (red);
        comboBox.addItem (rustred);
        comboBox.addItem (sunpurple);
        comboBox.addItem (suspectpink);
        comboBox.addItem (turquoise);
        comboBox.addItem (violet);
        comboBox.addItem (yellow);

        TableColumn colorColumn = tableView.getColumn (getString ("TableDemo.favorite_color"));

        colorColumn.setCellRenderer (colorRenderer);

        tableView.setRowHeight (INITIAL_ROWHEIGHT);

        scrollpane = new JScrollPane (tableView);
        return scrollpane;
    }

    class NamedColor extends Color {
        String name;

        public NamedColor (Color color, String name) {
            super (color.getRGB ());
            this.name = name;
        }

        public Color getTextColor () {
            int r = getRed ();
            int g = getGreen ();
            int b = getBlue ();
            if (r > 240 || g > 240) {
                return Color.black;
            }
            else {
                return Color.white;
            }
        }

        public String toString () {
            return name;
        }
    }

    class ColumnLayout implements LayoutManager {
        int xInset = 5;
        int yInset = 5;
        int yGap = 2;

        public void addLayoutComponent (String s, Component c) {
        }

        public void layoutContainer (Container c) {
            Insets insets = c.getInsets ();
            int height = yInset + insets.top;

            Component[] children = c.getComponents ();
            Dimension compSize;
            for (int i = 0; i < children.length; i++) {
                compSize = children[i].getPreferredSize ();
                children[i].setSize (compSize.width, compSize.height);
                children[i].setLocation (xInset + insets.left, height);
                height += compSize.height + yGap;
            }

        }

        public Dimension minimumLayoutSize (Container c) {
            Insets insets = c.getInsets ();
            int height = yInset + insets.top;
            int width = 0 + insets.left + insets.right;

            Component[] children = c.getComponents ();
            Dimension compSize;
            for (int i = 0; i < children.length; i++) {
                compSize = children[i].getPreferredSize ();
                height += compSize.height + yGap;
                width = Math.max (width, compSize.width + insets.left + insets.right + xInset * 2);
            }
            height += insets.bottom;
            return new Dimension (width, height);
        }

        public Dimension preferredLayoutSize (Container c) {
            return minimumLayoutSize (c);
        }

        public void removeLayoutComponent (Component c) {
        }
    }
}
