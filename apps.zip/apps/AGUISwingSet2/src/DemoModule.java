/*
 * @(#)DemoModule.java	1.54 06/05/31
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */


import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.SoftBevelBorder;
import java.awt.*;
import java.lang.reflect.Method;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * A generic SwingSet2 demo module
 */

public class DemoModule extends JPanel {

    // The preferred size of the demo
    private int PREFERRED_WIDTH = 680;
    private int PREFERRED_HEIGHT = 600;

    Border loweredBorder = new CompoundBorder (
        new SoftBevelBorder (SoftBevelBorder.LOWERED),
        new EmptyBorder (5, 5, 5, 5));

    // Premade convenience dimensions, for use wherever you need 'em.
    public static Dimension HGAP2 = new Dimension (2, 1);
    public static Dimension VGAP2 = new Dimension (1, 2);

    public static Dimension HGAP5 = new Dimension (5, 1);
    public static Dimension VGAP5 = new Dimension (1, 5);

    public static Dimension HGAP10 = new Dimension (10, 1);
    public static Dimension VGAP10 = new Dimension (1, 10);

    public static Dimension HGAP15 = new Dimension (15, 1);
    public static Dimension VGAP15 = new Dimension (1, 15);

    public static Dimension HGAP20 = new Dimension (20, 1);
    public static Dimension VGAP20 = new Dimension (1, 20);

    public static Dimension HGAP25 = new Dimension (25, 1);
    public static Dimension VGAP25 = new Dimension (1, 25);

    public static Dimension HGAP30 = new Dimension (30, 1);
    public static Dimension VGAP30 = new Dimension (1, 30);

    private SwingSet2 swingset = null;
    private JPanel panel = null;
    private String resourceName = null;
    private String iconPath = null;
    private String sourceCode = null;

    // Resource bundle for internationalized and accessible text
    private ResourceBundle bundle = null;

    public DemoModule (SwingSet2 swingset) {
        this (swingset, null, null);
    }

    public DemoModule (SwingSet2 swingset, String resourceName, String iconPath) {
        panel = new JPanel ();
        panel.setLayout (new BorderLayout ());

        this.resourceName = resourceName;
        if (SwingSet2.qvgaScreen) {
            StringBuffer sb = new StringBuffer (iconPath);

            sb.delete (sb.length () - 4, sb.length ());
            sb.append ("_min.png");
            this.iconPath = new String (sb);
        }
        else {
            this.iconPath = iconPath;
        }
        this.swingset = swingset;
    }

    public String getResourceName () {
        return resourceName;
    }

    public JPanel getDemoPanel () {
        return panel;
    }

    public SwingSet2 getSwingSet2 () {
        return swingset;
    }


    public String getString (String key) {
        String value = "nada";
        if (bundle == null) {
            if (getSwingSet2 () != null) {
                bundle = getSwingSet2 ().getResourceBundle ();
            }
            else {
                bundle = ResourceBundle.getBundle ("swingset");
            }
        }
        try {
            value = bundle.getString (key);
        }
        catch (MissingResourceException e) {
            System.out.println ("java.util.MissingResourceException: Couldn't find value for: " + key);
        }
        return value;
    }

    public char getMnemonic (String key) {
        return (getString (key)).charAt (0);
    }

    public ImageIcon createImageIcon (String filename, String description) {
        if (getSwingSet2 () != null) {
            return getSwingSet2 ().createImageIcon (filename, description);
        }
        else {
            String path = "images/" + filename;
            return new ImageIcon (getClass ().getResource (path), description);
        }
    }


    public String getSourceCode () {
        return sourceCode;
    }

    public String getName () {
        return getString (getResourceName () + ".name");
    }

    public Icon getIcon () {
        return createImageIcon (iconPath, getResourceName () + ".name");
    }


    public String getToolTip () {
        return getString (getResourceName () + ".tooltip");
    }

    public void mainImpl () {
        JFrame frame = new JFrame (getName ());

        frame.getContentPane ().setLayout (new BorderLayout ());
        frame.getContentPane ().add (getDemoPanel (), BorderLayout.CENTER);
        getDemoPanel ().setPreferredSize (new Dimension (PREFERRED_WIDTH, PREFERRED_HEIGHT));
        frame.pack ();
        frame.show ();
    }

    public JPanel createHorizontalPanel (boolean threeD) {
        JPanel p = new JPanel ();
        p.setLayout (new BoxLayout (p, BoxLayout.X_AXIS));
        p.setAlignmentY (TOP_ALIGNMENT);
        p.setAlignmentX (LEFT_ALIGNMENT);
        if (threeD) {
            p.setBorder (loweredBorder);
        }
        return p;
    }

    public JPanel createVerticalPanel (boolean threeD) {
        JPanel p = new JPanel ();
        p.setLayout (new BoxLayout (p, BoxLayout.Y_AXIS));
        p.setAlignmentY (TOP_ALIGNMENT);
        p.setAlignmentX (LEFT_ALIGNMENT);
        if (threeD) {
            p.setBorder (loweredBorder);
        }
        return p;
    }

    public static void main (String[] args) {
        DemoModule demo = new DemoModule (null);
        demo.mainImpl ();
    }

    public void init () {
    }

    static Frame oneTrueFrame = null;
    static JDesktopPane desktop = null;

    public static Container getRootContainer () {
        if (oneTrueFrame == null) {
            Window awtWindowR = null;
            try {
                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment ();
                GraphicsDevice[] devices = ge.getScreenDevices ();

                Method m = GraphicsDevice.class.getDeclaredMethod ("getWindow", new Class[] {});
                m.setAccessible (true);
                awtWindowR = (Window) m.invoke ((GraphicsDevice) devices[0], null);
            }
            catch (Exception e) {
                System.out.println ("#####Exception - getting Window from GraphicsDevice:" + e);
            }
            if (awtWindowR instanceof Frame) {
                /*
                ** found a window
                */
                oneTrueFrame = (Frame) awtWindowR;
            }
        }

        if (oneTrueFrame == null) {
            oneTrueFrame = new Frame ();

            desktop = new JDesktopPane ();
            desktop.setDoubleBuffered (true);
            desktop.setPreferredSize (new Dimension (oneTrueFrame.getWidth (), oneTrueFrame.getHeight ()));

            desktop.setVisible (true);
            oneTrueFrame.add (desktop);
            oneTrueFrame.setVisible (true);
        }
        else {
            if (desktop == null) {
                Component[] compArray = oneTrueFrame.getComponents ();
                for (int i = 0; i < compArray.length; i++) {
                    if (compArray[i] instanceof JDesktopPane) {
                        desktop = (JDesktopPane) compArray[i];
                        break;
                    }
                }
                if (desktop == null) {
                    desktop = new JDesktopPane ();
                    desktop.setDoubleBuffered (true);
                    desktop.setPreferredSize (
                        new Dimension (
                            oneTrueFrame.getWidth (), oneTrueFrame.getHeight ()));

                    oneTrueFrame.add (desktop);
                }
            }
        }
        return (desktop);
    }

}
