/*
 * @(#)SwingSet2.java	1.54 06/05/31
 * 
 * Copyright (c) 2008 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * -Redistribution of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduce the above copyright notice, 
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors may 
 * be used to endorse or promote products derived from this software without 
 * specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL 
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN")
 * AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST 
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, 
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY 
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, 
 * EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that this software is not designed, licensed or intended
 * for use in the design, construction, operation or maintenance of any
 * nuclear facility.
 */

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.lang.reflect.Constructor;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

/**
 * A demo that shows all of the Swing components.
 */
public class SwingSet2 extends JPanel {

    String[] demos = {
        "OptionPaneDemo",
        "ProgressBarDemo",
        "ScrollPaneDemo",
        "TableDemo",
        "ButtonDemo",
        "InternalFrameDemo",
        "TreeDemo",
    };

    void loadDemos () {
        for (int i = 0; i < demos.length; i++) {
            long time = System.currentTimeMillis ();
            System.out.print ("loading... " + demos[i]);
            loadDemo (demos[i]);
            System.out.println (" in " + (System.currentTimeMillis () - time) + "ms");
        }
    }

    // List of demos
    private Vector demosVector = new Vector ();

    // The preferred size of the demo
    protected static boolean qvgaScreen;
    private static final int VGA_PREFERRED_WIDTH = 620;
    private static final int VGA_PREFERRED_HEIGHT = 410;

    private static final int QVGA_PREFERRED_WIDTH = 225;
    private static final int QVGA_PREFERRED_HEIGHT = 260;

    protected static int preferred_width;
    protected static int preferred_height;

    // Box spacers
    private Dimension HGAP = new Dimension (1, 5);
    private Dimension VGAP = new Dimension (5, 1);

    // Resource bundle for internationalized and accessible text
    private ResourceBundle bundle;

    // A place to hold on to the visible demo
    private DemoModule currentDemo;
    private JPanel demoPanel;

    // Menus
    private JMenuBar menuBar;
    private JFrame frame;


    // To debug or not to debug, that is the question
    private boolean DEBUG = true;
    private int debugCounter;

    // The tab pane that holds the demo
    private JTabbedPane tabbedPane;

    private JEditorPane demoSrcPane;


    // contentPane cache, saved from the applet or application frame
    Container contentPane;


    public SwingSet2 (Object applet) {
        this (applet, null);
    }

    /**
     * SwingSet2 Constructor
     */
    public SwingSet2 (Object applet, GraphicsConfiguration gc) {

        // Create Frame here for app-mode so the splash screen can get the
        // GraphicsConfiguration from it in createSplashScreen()
        frame = createFrame (gc);

        setLayout (new BorderLayout ());

        // set the preferred size of the demo
        setPreferredSize (new Dimension (preferred_width, preferred_height));


        initializeDemo ();
        preloadFirstDemo ();

        // Start loading the rest of the demo in the background
        DemoLoadThread demoLoader = new DemoLoadThread (this);
        demoLoader.start ();

        showSwingSet2 ();

        frame.getContentPane ().requestFocus ();
    }


    /**
     * SwingSet2 Main. Called only if we're an application, not an applet.
     */
    public static void main (String[] args) {
        // Create SwingSet on the default monitor
        SwingSet2 swingset = new SwingSet2 (
            null, GraphicsEnvironment.
            getLocalGraphicsEnvironment ().
            getDefaultScreenDevice ().
            getDefaultConfiguration ());
    }

    // *******************************************************
    // *************** Demo Loading Methods ******************
    // *******************************************************


    public void initializeDemo () {
        menuBar = createMenus ();

        JFrame f = this.getFrame ();
        Container contentPane = f.getContentPane (); // save a reference to be restored later
        f.setLayeredPane (new JDesktopPane ()); // as a host for JOptionPane dialogs
        f.setContentPane (contentPane); // and rebind content pane
        f.setJMenuBar (menuBar);

        tabbedPane = new JTabbedPane ();
        add (tabbedPane, BorderLayout.CENTER);
        tabbedPane.getModel ().addChangeListener (new TabListener ());

        demoPanel = new JPanel ();
        demoPanel.setLayout (new BorderLayout ());
        demoPanel.setBorder (new EtchedBorder ());
        tabbedPane.addTab ("", null, demoPanel);
    }

    DemoModule currentTabDemo = null;

    class TabListener implements ChangeListener {
        public void stateChanged (ChangeEvent e) {
            SingleSelectionModel model = (SingleSelectionModel) e.getSource ();
            boolean srcSelected = model.getSelectedIndex () == 1;
            if (currentTabDemo != currentDemo && demoSrcPane != null && srcSelected) {
                demoSrcPane.setText (getString ("SourceCode.loading"));
                repaint ();
            }
        }
    }


    /**
     * Create menus
     */
    public JMenuBar createMenus () {
        // ***** create the menubar ****
        JMenuBar menuBar = new JMenuBar ();

        // ***** create File menu 
        JMenu fileMenu = menuBar.add (new JMenu (getString ("FileMenu.file_label")));
        fileMenu.setMnemonic (getMnemonic ("FileMenu.file_mnemonic"));

        createMenuItem (
            fileMenu, "FileMenu.open_label", "FileMenu.open_mnemonic",
            null);

        createMenuItem (
            fileMenu, "FileMenu.save_label", "FileMenu.save_mnemonic",
            null);

        createMenuItem (
            fileMenu, "FileMenu.save_as_label", "FileMenu.save_as_mnemonic",
            null);


        if (!isApplet ()) {
            fileMenu.addSeparator ();

            createMenuItem (
                fileMenu, "FileMenu.exit_label", "FileMenu.exit_mnemonic",
                new ExitAction (this)
            );
        }

        return menuBar;
    }

    /**
     * Creates a generic menu item
     */
    public JMenuItem createMenuItem (
        JMenu menu, String label, String mnemonic,
        Action action) {
        JMenuItem mi = menu.add (new JMenuItem (getString (label)));
        mi.setMnemonic (getMnemonic (mnemonic));

        mi.addActionListener (action);
        if (action == null) {
            mi.setEnabled (false);
        }
        return mi;
    }

    /**
     * Load the first demo. This is done separately from the remaining demos
     * so that we can get SwingSet2 up and available to the user quickly.
     */
    public void preloadFirstDemo () {
        DemoModule demo = addDemo (new SliderDemo (this));
        setDemo (demo);
    }


    /**
     * Add a demo to the toolbar
     */
    public DemoModule addDemo (DemoModule demo) {
        demosVector.addElement (demo);
        tabbedPane.addTab ("", demo.getIcon (), demo.getDemoPanel ());
        return demo;
    }


    /**
     * Sets the current demo
     */
    public void setDemo (DemoModule demo) {
        currentDemo = demo;

        JComponent currentDemoPanel = demo.getDemoPanel ();
        demoPanel.removeAll ();
        demoPanel.add (currentDemoPanel, BorderLayout.CENTER);

        tabbedPane.setSelectedIndex (0);
        tabbedPane.setTitleAt (0, demo.getName ());
        tabbedPane.setToolTipTextAt (0, demo.getToolTip ());
    }


    /**
     * Bring up the SwingSet2 demo by showing the frame (only
     * applicable if coming up as an application, not an applet);
     */
    public void showSwingSet2 () {
        if (!isApplet () && getFrame () != null) {
            // put swingset in a frame and show it

            JFrame f = getFrame ();
            f.setTitle (getString ("Frame.title"));
            f.getContentPane ().add (this, BorderLayout.CENTER);
            f.pack ();

            Rectangle screenRect = f.getGraphicsConfiguration ().getBounds ();
            Insets screenInsets = Toolkit.getDefaultToolkit ().getScreenInsets (
                f.getGraphicsConfiguration ());

            // Make sure we don't place the demo off the screen.
            int centerWidth = screenRect.width < f.getSize ().width ?
                screenRect.x :
                screenRect.x + screenRect.width / 2 - f.getSize ().width / 2;
            int centerHeight = screenRect.height < f.getSize ().height ?
                screenRect.y :
                screenRect.y + screenRect.height / 2 - f.getSize ().height / 2;

            if (screenInsets != null) {
                centerHeight = centerHeight < screenInsets.top ?
                    screenInsets.top : centerHeight;
            }

            f.setLocation (centerWidth, centerHeight);

            f.show ();
        }
    }

    // *******************************************************
    // ****************** Utility Methods ********************
    // *******************************************************

    /**
     * Loads a demo from a classname
     */
    void loadDemo (String classname) {
        DemoModule demo;
        try {
            Class demoClass = Class.forName (classname);
            Constructor demoConstructor = demoClass.getConstructor (new Class[] {SwingSet2.class});
            demo = (DemoModule) demoConstructor.newInstance (new Object[] {this});
            addDemo (demo);
        }
        catch (Exception e) {
            e.printStackTrace ();
            System.out.println ("Error occurred loading demo: " + classname);
            System.out.println ("Error : " + e);
        }
    }

    /**
     * Determines if this is an applet or application
     */
    public boolean isApplet () {
        return (false);
    }

    /**
     * Returns the applet instance
     */
    public SwingSet2 getApplet () {
        return null;
    }

    /**
     * Returns the frame instance
     */
    public JFrame getFrame () {
        return frame;
    }

    /**
     * Returns the menubar
     */
    public JMenuBar getMenuBar () {
        return menuBar;
    }

    /**
     * Returns the content pane wether we're in an applet
     * or application
     */
    public Container getContentPane () {
        if (contentPane == null) {
            if (getFrame () != null) {
                contentPane = getFrame ().getContentPane ();
            }
            else if (getApplet () != null) {
                contentPane = getApplet ().getContentPane ();
            }
        }
        return contentPane;
    }

    /**
     * Create a frame for SwingSet2 to reside in if brought up
     * as an application.
     */

    public static JFrame createFrame (GraphicsConfiguration gc) {
        Rectangle r = gc.getBounds ();

        if (r.width < VGA_PREFERRED_WIDTH || r.height < VGA_PREFERRED_HEIGHT) {
            qvgaScreen = true;
            preferred_width = QVGA_PREFERRED_WIDTH;
            preferred_height = QVGA_PREFERRED_HEIGHT;
        }
        else {
            qvgaScreen = false;
            preferred_width = VGA_PREFERRED_WIDTH;
            preferred_height = VGA_PREFERRED_HEIGHT;
        }
        return new JFrame ();
    }


    /**
     * This method returns a string from the demo's resource bundle.
     */
    public String getString (String key) {
        String value = null;
        try {
            value = getResourceBundle ().getString (key);
        }
        catch (MissingResourceException e) {
            System.out.println ("java.util.MissingResourceException: Couldn't find value for: " + key);
        }
        if (value == null) {
            value = "Could not find resource: " + key + "  ";
        }
        return value;
    }

    /**
     * Returns the resource bundle associated with this demo. Used
     * to get accessable and internationalized strings.
     */
    public ResourceBundle getResourceBundle () {
        if (bundle == null) {
            bundle = ResourceBundle.getBundle ("swingset");
        }
        return bundle;
    }

    /**
     * Returns a mnemonic from the resource bundle. Typically used as
     * keyboard shortcuts in menu items.
     */
    public char getMnemonic (String key) {
        return (getString (key)).charAt (0);
    }

    /**
     * Creates an icon from an image contained in the "images" directory.
     */
    public ImageIcon createImageIcon (String filename, String description) {
        String path = "images/" + filename;
        return new ImageIcon (getClass ().getResource (path));
    }

    /**
     * If DEBUG is defined, prints debug information out to std ouput.
     */
    public void debug (String s) {
        if (DEBUG) {
            System.out.println ((debugCounter++) + ": " + s);
        }
    }

    class ExitAction extends AbstractAction {
        SwingSet2 swingset;

        protected ExitAction (SwingSet2 swingset) {
            super ("ExitAction");
            this.swingset = swingset;
        }

        public void actionPerformed (ActionEvent e) {
            System.exit (0);
        }
    }

    class DemoLoadThread extends Thread {
        SwingSet2 swingset;

        public DemoLoadThread (SwingSet2 swingset) {
            this.swingset = swingset;
        }

        public void run () {
            swingset.loadDemos ();
        }
    }

}

