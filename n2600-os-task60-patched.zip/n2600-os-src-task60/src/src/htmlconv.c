/* htmlconv.c — HTML -> Markdown конвертер N2600-OS.
 *
 * Task 60 [HC-DOM]: ПОЛНОЕ ПЕРЕПИСЫВАНИЕ на базе DOM-парсера
 * html_parser.c (html_parse_begin/stream/end). Прежняя версия разбирала
 * HTML ручными эвристиками (сканирование '<', кавычек в атрибутах,
 * прыжки через <script>/<style>, комментарии) — на сложных страницах
 * эвристики расходились с реальной структурой, что вместе с тихой
 * обрезкой по ENSURE/PUT давало «просачивание скриптов» и потерю
 * контента (см. разбор Task 60: сценарии A/B/E/F).
 *
 * Теперь: html_parser строит дерево (теги, атрибуты с декодированными
 * entities, сырой код <script>/<textarea>, пропуск <style>/<template>),
 * а этот модуль ОБХОДИТ дерево итеративно (стек кадров в куче — стек
 * задачи не расходуется) и выдаёт тот же формат, что раньше:
 *
 *   Поддерживаемые теги (формат вывода НЕ менялся — brform.h/brpage.h
 *   и тесты продолжают читать прежние маркеры):
 *   <h1>-<h6> -> #..######; <p> -> пустая строка; <br> -> \n;
 *   <hr> -> ---; <b>/<strong> -> **; <i>/<em> -> *; <code> -> `;
 *   <pre> -> ```; <ul>/<ol>/<li> -> списки с нумерацией;
 *   <a href> -> [текст](href); <img src> -> строка ![alt](src);
 *   формы/скрипты -> маркеры \x01 (разбирает brform.h):
 *     \x01FORM action=".." method=".."
 *     \x01INPUT type=".." name=".." value=".." id=".." ph=".." js=".." [checked]
 *     \x01TEXTAREA .. \n сырой текст \n \x01/TEXTAREA
 *     \x01SELECT name=".." / \x01OPT value=".." label=".." / \x01/SELECT
 *     \x01BUTTON .. label=".."
 *     \x01SCRIPTSRC src="U"  /  \x01SCRIPT \n КОД \n \x01/SCRIPT
 *     \x01REFRESH content="N; url=U"
 *
 * Ключевые исправления Task 60:
 *   [HC-PAIR]  Маркерные строки пишутся АТОМАРНО (влезла строка целиком
 *              или не пишется вовсе — никаких полумаркетов «\x01INPUT
 *              type="te» при обрезке). Блоки \x01SCRIPT/\x01TEXTAREA
 *              резервируют место под закрывающий маркер ЗАРАНЕЕ; если
 *              буфер кончился посреди кода — закрывающий маркер
 *              дописывается, а при невозможности ВСЯ открывашка
 *              откатывается (mi = позиция до маркера). «Висячих»
 *              \x01SCRIPT больше не бывает (сценарий A из разбора).
 *   [HC-TRUNC] html_to_md2 сообщает обрезку через out-параметр
 *              truncated — браузер показывает «страница обрезана»,
 *              раньше статус выглядел как норма (сценарий 1.4/1.5).
 *   [HC-PH-JS] INPUT-маркер теперь пишет ph=".." и js=".." (как ожидает
 *              brf_attr); прежний код писал placeholder=".."/onclick="..",
 *              которые brf_attr НЕ читал — placeholder и onclick полей
 *              молча терялись.
 *   [HC-NOTRIM] Пробелы на стыках текстовых узлов сохраняются
 *              (парсер их больше не режет, нормализация — здесь).
 *
 * Не поддерживается (как и раньше): таблицы (текст без сепараторов),
 * blockquote, полная таблица entities (расширенные мнемоники даёт
 * html_parser.c: copy, mdash, laquo и т.д. — уже UTF-8).
 */

#ifdef HOST_TEST
#include <string.h>   /* хостовой тест: стандартная библиотека */
#include <stdio.h>
#include <stdlib.h>
#include "types.h"    /* u32; тест-харнессы кладут копию types.h рядом */
#else
#include "string.h"   /* ядро: freestanding-версия (src/string.c) */
#include "types.h"
#include "mem.h"
#endif

#include "htmlconv.h"
#include "html_parser.h"

#define HC_MARK '\x01'   /* первый символ строки-маркера формы/скрипта */

/* лимиты формата маркеров (согласованы с brform.h) */
#define HC_JS_MAX 96          /* onclick в маркере (BRF_JS_MAX) */
#define HC_LB_MAX 512         /* строковый конструктор маркера */
#define HC_LIST_MAX 16        /* максимальная глубина списков */
#define HC_HREF_MAX 220       /* href <a> (как last_href раньше) */
/* Глубина дерева ограничена парсером 128 уровнями (MAX_PARSE_DEPTH в
 * html_parser.c) + виртуальный корень; запас +4. */
#define HC_MAX_DEPTH 132

/* ---- кадры итеративного обхода дерева ---- */

enum {
    HC_K_PLAIN = 0,   /* обычный контейнер: текст нормализуем */
    HC_K_PRE,         /* внутри <pre>: текст сырой, элементы прозрачны */
    HC_K_SCRIPT,      /* внутри <script>: сырой код */
    HC_K_TA,          /* внутри <textarea>: сырое значение */
    HC_K_OPT,         /* внутри <option>: копим подпись */
    HC_K_BTN          /* внутри <button>: копим подпись */
};

typedef struct {
    HtmlElement *el;              /* элемент, чьи дети обходим */
    HtmlElement *next;            /* следующий необработанный ребёнок */
    int          kind;            /* HC_K_* */
    int          pre_first;       /* HC_K_PRE: пропустить ведущий \n */
    int          li_count;        /* UL/OL: счётчик номеров <li> */
    char         href[HC_HREF_MAX];   /* <a>: отложенный href */
    char         pend_attrs[128]; /* option/button: атрибуты маркера */
    char         label[64];       /* option/button: подпись */
    int          label_len;
} hc_frame_t;

typedef struct {
    char *md;
    int   md_max;
    int   mi;
    int   trunc;                  /* FIX [HC-TRUNC]: буфер исчерпан */
    /* FIX [HC-PAIR]: состояние открытых блоков */
    int   sc_open;                /* открыт \x01SCRIPT без закрытия */
    int   sc_pos;                 /* mi ДО открывающего маркера */
    int   ta_open;
    int   ta_pos;
    int   pre_depth;              /* вложенность <pre> */
    char  lb[HC_LB_MAX];          /* конструктор маркерной строки */
    int   lb_len;
} hc_ctx_t;

/* ================= примитивы вывода ================= */

static void hc_put(hc_ctx_t *ctx, char c)
{
    if (ctx->trunc) return;
    if (ctx->mi >= ctx->md_max - 1) { ctx->trunc = 1; return; }
    ctx->md[ctx->mi++] = c;
}

/* n байт целиком или ничего (с выставлением trunc) */
static void hc_put_n(hc_ctx_t *ctx, const char *s, int n)
{
    if (ctx->trunc || n <= 0) return;
    if (ctx->md_max - 1 - ctx->mi < n) { ctx->trunc = 1; return; }
    memcpy(ctx->md + ctx->mi, s, (u32)n);
    ctx->mi += n;
}

static void hc_put2(hc_ctx_t *ctx, char a, char b)
{
    if (ctx->trunc) return;
    if (ctx->md_max - 1 - ctx->mi < 2) { ctx->trunc = 1; return; }
    ctx->md[ctx->mi++] = a;
    ctx->md[ctx->mi++] = b;
}

static int hc_room(hc_ctx_t *ctx, int n)
{
    return !ctx->trunc && (ctx->md_max - 1 - ctx->mi >= n);
}

/* удалить пробелы перед переводом строки, чтобы не было " \n" */
static void hc_trim_sp(hc_ctx_t *ctx)
{
    while (ctx->mi > 0 && ctx->md[ctx->mi - 1] == ' ')
        ctx->mi--;
}

/* перевод строки с удалением хвостовых пробелов (старый EMIT_NL) */
static void hc_brk(hc_ctx_t *ctx)
{
    hc_trim_sp(ctx);
    hc_put(ctx, '\n');
}

/* гарантировать перевод строки в конце (старый ENSURE_NL; в старом
 * коде ВСЕ вызовы, кроме <img>, стояли под if (mi > 0) — пустой вывод
 * ведущего \n не даёт; для <img> — hc_brk напрямую) */
static void hc_ensure_nl(hc_ctx_t *ctx)
{
    if (ctx->mi == 0) return;
    if (ctx->md[ctx->mi - 1] != '\n')
        hc_brk(ctx);
}

/* как hc_ensure_nl, но без удаления пробелов (закрытие <pre>) */
static void hc_ensure_nl_raw(hc_ctx_t *ctx)
{
    if (ctx->mi == 0 || ctx->md[ctx->mi - 1] != '\n')
        hc_put(ctx, '\n');
}

/* гарантировать пустую строку (старый ENSURE_BLANK) */
static void hc_ensure_blank(hc_ctx_t *ctx)
{
    if (ctx->mi > 0) {
        hc_ensure_nl(ctx);
        if (ctx->mi < 2 || ctx->md[ctx->mi - 2] != '\n')
            hc_put(ctx, '\n');
    }
}

/* ================= строковый конструктор маркера ================= */

static void hc_lb_reset(hc_ctx_t *ctx)
{
    ctx->lb_len = 0;
    ctx->lb[0] = 0;
}

static void hc_lb_put(hc_ctx_t *ctx, char c)
{
    if (ctx->lb_len < HC_LB_MAX - 1) {
        ctx->lb[ctx->lb_len++] = c;
        ctx->lb[ctx->lb_len] = 0;
    }
}

static void hc_lb_str(hc_ctx_t *ctx, const char *s)
{
    while (*s) hc_lb_put(ctx, *s++);
}

/* значение атрибута маркера: '"' -> &quot;, \n/\r/\x01 -> ' ' */
static void hc_lb_attr(hc_ctx_t *ctx, const char *s)
{
    for (; *s; s++) {
        if (*s == '"')
            hc_lb_str(ctx, "&quot;");
        else if (*s == '\n' || *s == '\r' || *s == HC_MARK)
            hc_lb_put(ctx, ' ');
        else
            hc_lb_put(ctx, *s);
    }
}

/* Атомарная маркерная строка: конец текущей строки (с чисткой
 * хвостовых пробелов) + lb + '\n'. Строка целиком или trunc. */
static void hc_flush_line(hc_ctx_t *ctx)
{
    if (ctx->trunc) return;
    if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n') {
        hc_trim_sp(ctx);
        hc_put(ctx, '\n');
        if (ctx->trunc) return;
    }
    if (ctx->md_max - 1 - ctx->mi < ctx->lb_len + 1) {
        ctx->trunc = 1;
        return;
    }
    memcpy(ctx->md + ctx->mi, ctx->lb, (u32)ctx->lb_len);
    ctx->mi += ctx->lb_len;
    ctx->md[ctx->mi++] = '\n';
}

/* ================= утилиты ================= */

/* значение атрибута элемента по ключу (уже декодировано парсером) */
static const char *hc_attr(const HtmlElement *el, HtmlAttribKey key)
{
    const HtmlAttrib *a;
    for (a = el->attrib; a; a = a->next)
        if (a->key == key)
            return a->value;
    return NULL;
}

/* сравнение без регистра (для http-equiv="refresh") */
static int hc_ci_eq(const char *a, const char *b)
{
    for (;;) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca = (char)(ca | 0x20);
        if (cb >= 'A' && cb <= 'Z') cb = (char)(cb | 0x20);
        if (ca != cb) return 0;
        if (!ca) return 1;
        a++;
        b++;
    }
}

/* ---------------- текст ---------------- */

/* нормализованный текст: '\n'/\r/\t -> ' ', пробелы схлопываются,
 * \x01 (мусор из страницы) -> ' ' — как старое «сжатие пробелов» */
static void hc_text_norm(hc_ctx_t *ctx, const char *s)
{
    for (; *s; s++) {
        char c = *s;
        if (c == '\n' || c == '\r' || c == '\t') c = ' ';
        if (c == HC_MARK) c = ' ';
        if (c == ' ' && (ctx->mi == 0 ||
                         ctx->md[ctx->mi - 1] == ' ' ||
                         ctx->md[ctx->mi - 1] == '\n'))
            continue;
        hc_put(ctx, c);
    }
}

/* сырой текст (код скрипта, значение textarea, содержимое <pre>) */
static void hc_text_raw(hc_ctx_t *ctx, const char *s)
{
    for (; *s; s++)
        hc_put(ctx, *s);
}

/* подпись option/button: переносы/табы -> пробел, пробелы схлопываются */
static void hc_label_add(hc_frame_t *fr, const char *s)
{
    for (; *s; s++) {
        char c = *s;
        if (c == '\n' || c == '\r' || c == '\t') c = ' ';
        if (c == ' ' && (fr->label_len == 0 ||
                         fr->label[fr->label_len - 1] == ' '))
            continue;
        if (fr->label_len < (int)sizeof(fr->label) - 1)
            fr->label[fr->label_len++] = c;
    }
    fr->label[fr->label_len] = 0;
}

/* дописать " name=\"..\""-фрагмент в pend_attrs option/button */
static void hc_pa_add(hc_frame_t *nf, const char *name, const char *val,
                      int lower)
{
    char tmp[96];
    int k = 0;
    int l;
    if (!val || !*val) return;
    for (; val[k] && k < 94; k++)
        tmp[k] = (lower && val[k] >= 'A' && val[k] <= 'Z')
                 ? (char)(val[k] | 0x20) : val[k];
    tmp[k] = 0;
    l = (int)strlen(nf->pend_attrs);
    snprintf(nf->pend_attrs + l, sizeof(nf->pend_attrs) - (u32)l,
             " %s=\"%s\"", name, tmp);
}

/* ================= открытие/закрытие элементов ================= */

/* Открытие: выдаёт открывающую разметку/маркер. kind — режим кадра для
 * детей. Возврат: 1 = спуститься в детей (кадр создаётся даже для
 * пустого элемента — закрывающие эффекты обязаны сработать),
 * 0 = лист (спуск не нужен), -1 = поддерево пропустить (маркер уже
 * выдан: <script src>). frames/depth — для вычисления уровня <li>. */
static int hc_open_tag(hc_ctx_t *ctx, hc_frame_t *frames, int depth,
                       HtmlElement *el, hc_frame_t *nf, int *kind)
{
    const char *av;

    *kind = HC_K_PLAIN;

    switch (el->tag) {

    case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
    case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6: {
        /* теги H1..H6 идут подряд в enum html_parser.h */
        int v = (int)(el->tag - HTML_TAG_H1) + 1;
        hc_ensure_nl(ctx);
        for (int i = 0; i < v; i++) hc_put(ctx, '#');
        hc_put(ctx, ' ');
        return 1;
    }

    case HTML_TAG_P:
        hc_ensure_blank(ctx);
        return 1;

    case HTML_TAG_BR:
        hc_brk(ctx);
        return 0;

    case HTML_TAG_HR:
        hc_ensure_nl(ctx);
        hc_put_n(ctx, "---\n", 4);
        return 0;

    case HTML_TAG_B:
    case HTML_TAG_STRONG:
        hc_put2(ctx, '*', '*');
        return 1;

    case HTML_TAG_I:
    case HTML_TAG_EM:
        hc_put(ctx, '*');
        return 1;

    case HTML_TAG_CODE:
        hc_put(ctx, '`');
        return 1;

    case HTML_TAG_PRE:
        if (ctx->pre_depth == 0) {
            hc_ensure_nl(ctx);
            hc_put_n(ctx, "```\n", 4);
        }
        ctx->pre_depth++;
        *kind = HC_K_PRE;
        nf->pre_first = 1;
        return 1;

    case HTML_TAG_UL:
    case HTML_TAG_OL:
        hc_ensure_nl(ctx);
        nf->li_count = 0;
        return 1;

    case HTML_TAG_LI: {
        int lvl = 0;
        hc_frame_t *lf = NULL;
        for (int k = 0; k <= depth; k++) {
            HtmlTag t = frames[k].el->tag;
            if (t == HTML_TAG_UL || t == HTML_TAG_OL) {
                lvl++;
                lf = &frames[k];
            }
        }
        hc_ensure_nl(ctx);
        {
            int ind = lvl > 0 ? lvl - 1 : 0;
            if (ind > HC_LIST_MAX) ind = HC_LIST_MAX;
            for (int i = 0; i < ind; i++) hc_put2(ctx, ' ', ' ');
        }
        if (lvl > 0 && lf && lf->el->tag == HTML_TAG_OL) {
            int v = ++lf->li_count;
            char num[12];
            int n = 0;
            if (v <= 0) {
                hc_put(ctx, '0');
            } else {
                while (v > 0 && n < (int)sizeof(num)) {
                    num[n++] = (char)('0' + (v % 10));
                    v /= 10;
                }
                while (n > 0) hc_put(ctx, num[--n]);
            }
            hc_put(ctx, '.');
            hc_put(ctx, ' ');
        } else {
            hc_put2(ctx, '-', ' ');
        }
        return 1;
    }

    case HTML_TAG_A: {
        const char *h = hc_attr(el, HTML_ATTRIB_HREF);
        nf->href[0] = 0;
        if (h && *h) {
            int k = 0;
            for (; h[k] && k < HC_HREF_MAX - 1; k++) nf->href[k] = h[k];
            nf->href[k] = 0;
        }
        hc_put(ctx, '[');
        return 1;
    }

    case HTML_TAG_IMG: {
        const char *src = hc_attr(el, HTML_ATTRIB_SRC);
        const char *alt;
        if (!src || !*src) return 0;          /* без src — пропуск */
        alt = hc_attr(el, HTML_ATTRIB_ALT);
        hc_brk(ctx);                          /* старый unguarded ENSURE_NL */
        hc_lb_reset(ctx);
        hc_lb_put(ctx, '!');
        hc_lb_put(ctx, '[');
        if (alt) {
            for (int k = 0; alt[k] && k < 48; k++) {
                if (alt[k] == ']' || alt[k] == '\n' || alt[k] == '\r') break;
                hc_lb_put(ctx, alt[k]);
            }
        }
        hc_lb_put(ctx, ']');
        hc_lb_put(ctx, '(');
        for (const char *u = src; *u; u++) {
            if (*u == ')' || *u == '\n' || *u == '\r' ||
                *u == '"' || *u == '<')
                break;
            hc_lb_put(ctx, *u);
        }
        hc_lb_put(ctx, ')');
        hc_flush_line(ctx);
        return 0;
    }

    case HTML_TAG_INPUT: {
        /* FIX [HC-PH-JS]: маркер пишет ph=/js= — имена, которые реально
         * читает brf_attr (прежде писались placeholder=/onclick= и
         * молча терялись). */
        char ttype[16];
        hc_ensure_nl(ctx);
        if ((av = hc_attr(el, HTML_ATTRIB_TYPE)) && *av) {
            int k = 0;
            for (; av[k] && k < 15; k++)
                ttype[k] = (av[k] >= 'A' && av[k] <= 'Z')
                           ? (char)(av[k] | 0x20) : av[k];
            ttype[k] = 0;
        } else {
            strcpy(ttype, "text");
        }
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01INPUT type=\"");
        hc_lb_str(ctx, ttype);
        hc_lb_put(ctx, '"');
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_VALUE)) && *av) {
            hc_lb_str(ctx, " value=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ID)) && *av) {
            hc_lb_str(ctx, " id=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if (!strcmp(ttype, "text") || !strcmp(ttype, "password") ||
            !strcmp(ttype, "search")) {
            if ((av = hc_attr(el, HTML_ATTRIB_PLACEHOLDER)) && *av) {
                hc_lb_str(ctx, " ph=\""); hc_lb_attr(ctx, av);
                hc_lb_put(ctx, '"');
            }
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ONCLICK)) && *av) {
            hc_lb_str(ctx, " js=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if (hc_attr(el, HTML_ATTRIB_CHECKED))
            hc_lb_str(ctx, " checked");
        hc_flush_line(ctx);
        return 0;
    }

    case HTML_TAG_TEXTAREA: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01TEXTAREA");
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ID)) && *av) {
            hc_lb_str(ctx, " id=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        /* FIX [HC-PAIR]: резерв под закрывающий "\n\x01/TEXTAREA\n" */
        if (!hc_room(ctx, ctx->lb_len + 11 + 2)) {
            ctx->trunc = 1;
            return 1;              /* без маркера: текст пойдёт обычным */
        }
        ctx->ta_pos = ctx->mi;
        hc_flush_line(ctx);
        if (ctx->trunc) return 1;
        ctx->ta_open = 1;
        *kind = HC_K_TA;
        return 1;
    }

    case HTML_TAG_SELECT: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01SELECT");
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        hc_flush_line(ctx);
        return 1;
    }

    case HTML_TAG_OPTION: {
        const char *ov = hc_attr(el, HTML_ATTRIB_VALUE);
        nf->pend_attrs[0] = 0;
        if (ov && *ov) hc_pa_add(nf, "value", ov, 0);
        if (hc_attr(el, HTML_ATTRIB_SELECTED)) {
            int l = (int)strlen(nf->pend_attrs);
            if (l + 10 < (int)sizeof(nf->pend_attrs))
                strcpy(nf->pend_attrs + l, " selected");
        }
        nf->label[0] = 0;
        nf->label_len = 0;
        *kind = HC_K_OPT;
        return 1;
    }

    case HTML_TAG_BUTTON: {
        nf->pend_attrs[0] = 0;
        if ((av = hc_attr(el, HTML_ATTRIB_TYPE)) && *av)
            hc_pa_add(nf, "type", av, 1);
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av)
            hc_pa_add(nf, "name", av, 0);
        if ((av = hc_attr(el, HTML_ATTRIB_VALUE)) && *av)
            hc_pa_add(nf, "value", av, 0);
        if ((av = hc_attr(el, HTML_ATTRIB_ONCLICK)) && *av)
            hc_pa_add(nf, "js", av, 0);
        nf->label[0] = 0;
        nf->label_len = 0;
        *kind = HC_K_BTN;
        return 1;
    }

    case HTML_TAG_FORM: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01FORM");
        if ((av = hc_attr(el, HTML_ATTRIB_ACTION)) && *av) {
            hc_lb_str(ctx, " action=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_METHOD)) && *av) {
            hc_lb_str(ctx, " method=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        hc_flush_line(ctx);
        return 1;
    }

    case HTML_TAG_META: {
        /* FIX [META-REFRESH]: только http-equiv=refresh */
        const char *he = hc_attr(el, HTML_ATTRIB_HTTP_EQUIV);
        const char *co = hc_attr(el, HTML_ATTRIB_CONTENT);
        if (he && co && *co && hc_ci_eq(he, "refresh")) {
            hc_ensure_nl(ctx);
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01REFRESH content=\"");
            hc_lb_attr(ctx, co);
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
        }
        return 0;
    }

    case HTML_TAG_SCRIPT: {
        const char *src = hc_attr(el, HTML_ATTRIB_SRC);
        if (src && *src) {
            /* внешний код: маркер-строка, поддерево пропускаем */
            hc_ensure_nl(ctx);
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01SCRIPTSRC src=\"");
            for (const char *u = src; *u; u++) {
                if (*u == '"' || *u == ' ' || *u == '\n' || *u == '\r' ||
                    *u == HC_MARK)
                    break;
                hc_lb_put(ctx, *u);
            }
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
            return -1;
        }
        /* инлайн: маркер + сырой код + закрытие. FIX [HC-PAIR]: резерв
         * под закрывающий "\n\x01/SCRIPT\n" ЗАРАНЕЕ — блок либо
         * открывается с гарантией закрытия, либо не открывается. */
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01SCRIPT");
        if (!hc_room(ctx, ctx->lb_len + 10 + 2)) {
            ctx->trunc = 1;
            return 1;              /* без маркера: остаток — обычный текст */
        }
        ctx->sc_pos = ctx->mi;
        hc_flush_line(ctx);
        if (ctx->trunc) return 1;
        ctx->sc_open = 1;
        *kind = HC_K_SCRIPT;
        return 1;
    }

    default:
        /* нейтральные/неизвестные теги (html/head/div/span/table/title,
         * label, nav, ...) — разметку не выдаём, содержимое сохраняем */
        return 1;
    }
}

/* Закрытие элемента (кадр завершён) */
static void hc_close_frame(hc_ctx_t *ctx, hc_frame_t *fr)
{
    HtmlElement *el = fr->el;

    switch (el->tag) {

    case HTML_TAG_A: {
        hc_put(ctx, ']');
        if (fr->href[0]) {
            int hl = 0;
            while (fr->href[hl] && fr->href[hl] != ')') hl++;
            if (hc_room(ctx, hl + 2)) {
                hc_put(ctx, '(');
                hc_put_n(ctx, fr->href, hl);
                hc_put(ctx, ')');
            } else {
                ctx->trunc = 1;
            }
        } else if (hc_room(ctx, 2)) {
            hc_put(ctx, '(');
            hc_put(ctx, ')');
        } else {
            ctx->trunc = 1;
        }
        break;
    }

    case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
    case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6:
    case HTML_TAG_P:
    case HTML_TAG_LI:
    case HTML_TAG_UL:
    case HTML_TAG_OL:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_B:
    case HTML_TAG_STRONG:
        hc_put2(ctx, '*', '*');
        break;

    case HTML_TAG_I:
    case HTML_TAG_EM:
        hc_put(ctx, '*');
        break;

    case HTML_TAG_CODE:
        hc_put(ctx, '`');
        break;

    case HTML_TAG_PRE:
        ctx->pre_depth--;
        if (ctx->pre_depth == 0) {
            hc_ensure_nl_raw(ctx);
            hc_put_n(ctx, "```\n", 4);
        }
        break;

    case HTML_TAG_FORM:
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01/FORM");
        hc_flush_line(ctx);
        break;

    case HTML_TAG_SELECT:
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01/SELECT");
        hc_flush_line(ctx);
        break;

    case HTML_TAG_OPTION:
        if (fr->pend_attrs[0]) {
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01OPT");
            hc_lb_str(ctx, fr->pend_attrs);
            hc_lb_str(ctx, " label=\"");
            for (int i = 0; i < fr->label_len; i++) {
                if (fr->label[i] == '"') hc_lb_str(ctx, "&quot;");
                else hc_lb_put(ctx, fr->label[i]);
            }
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
        }
        break;

    case HTML_TAG_BUTTON:
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01BUTTON");
        hc_lb_str(ctx, fr->pend_attrs);
        hc_lb_str(ctx, " label=\"");
        for (int i = 0; i < fr->label_len; i++) {
            if (fr->label[i] == '"') hc_lb_str(ctx, "&quot;");
            else hc_lb_put(ctx, fr->label[i]);
        }
        hc_lb_put(ctx, '"');
        hc_flush_line(ctx);
        break;

    case HTML_TAG_SCRIPT:
        /* FIX [HC-PAIR]: закрывашка влезла (резерв был) — пишем; при
         * обрыве посреди кода (trunc) закрывашку допишет finish либо
         * блок откатится целиком. */
        if (ctx->sc_open && !ctx->trunc) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 9;
            if (ctx->md_max - 1 - ctx->mi >= need) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01/SCRIPT\n", 9);
                ctx->mi += 9;
                ctx->sc_open = 0;
            }
        }
        break;

    case HTML_TAG_TEXTAREA:
        if (ctx->ta_open && !ctx->trunc) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 11;
            if (ctx->md_max - 1 - ctx->mi >= need) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01/TEXTAREA\n", 11);
                ctx->mi += 11;
                ctx->ta_open = 0;
            }
        }
        break;

    default:
        break;
    }
}

/* инициализация кадра (перед hc_open_tag, чтобы он мог заполнить
 * href/pend_attrs нового кадра) */
static void hc_frame_init(hc_frame_t *nf, HtmlElement *el, int kind)
{
    nf->el = el;
    nf->next = el->child;
    nf->kind = kind;
    nf->pre_first = 0;
    nf->li_count = 0;
    nf->href[0] = 0;
    nf->pend_attrs[0] = 0;
    nf->label[0] = 0;
    nf->label_len = 0;
}

int html_to_md2(const char *html, int html_len, char *md, int md_max,
                int *truncated)
{
    hc_ctx_t ctx;
    hc_frame_t *frames;
    HtmlParseState *st;
    HtmlDocument *doc;
    int depth = 0;

    if (truncated) *truncated = 0;
    if (!md || md_max < 4) {
        if (md && md_max > 0) md[0] = 0;
        return 0;
    }
    md[0] = 0;
    if (!html || html_len <= 0) return 0;

    st = html_parse_begin();
    if (!st) return 0;
    html_parse_stream(st, NULL, html, (size_t)html_len);
    doc = html_parse_end(st);
    if (!doc || !doc->root_element) {
        if (doc) html_free_document(doc);
        return 0;
    }

    /* стек кадров — в КУЧЕ (не в стеке задачи: ~56 КиБ на 128 уровней) */
    frames = (hc_frame_t *)malloc((u32)sizeof(hc_frame_t) * (u32)HC_MAX_DEPTH);
    if (!frames) {
        html_free_document(doc);
        return 0;
    }

    memset(&ctx, 0, sizeof(ctx));
    ctx.md = md;
    ctx.md_max = md_max;
    hc_frame_init(&frames[0], doc->root_element, HC_K_PLAIN);

    for (;;) {
        hc_frame_t *fr = &frames[depth];
        HtmlElement *cur = fr->next;

        if (!cur) {
            if (depth == 0) break;
            hc_close_frame(&ctx, fr);
            depth--;
            continue;
        }
        fr->next = cur->sibling;

        if (ctx.trunc) continue;       /* структуру гасим, вывода нет */

        /* --- текстовый узел --- */
        if (cur->tag == HTML_TAG_NONE) {
            const char *tx = cur->text;
            if (!tx || !*tx) continue;
            switch (fr->kind) {
            case HC_K_PRE:
                if (fr->pre_first) {
                    fr->pre_first = 0;
                    if (tx[0] == '\n') tx++;   /* HTML5: первый \n после
                                                * <pre> игнорируется */
                }
                hc_text_raw(&ctx, tx);
                break;
            case HC_K_SCRIPT:
            case HC_K_TA:
                hc_text_raw(&ctx, tx);
                break;
            case HC_K_OPT:
            case HC_K_BTN:
                hc_label_add(fr, tx);
                break;
            default:
                hc_text_norm(&ctx, tx);
                break;
            }
            continue;
        }

        /* --- элемент внутри «сырого»/копящего контейнера: прозрачный
         *     спуск с тем же режимом --- */
        if (fr->kind == HC_K_PRE || fr->kind == HC_K_SCRIPT ||
            fr->kind == HC_K_TA || fr->kind == HC_K_OPT ||
            fr->kind == HC_K_BTN) {
            if (cur->child && depth + 1 < HC_MAX_DEPTH) {
                hc_frame_init(&frames[depth + 1], cur, fr->kind);
                depth++;
            }
            continue;
        }

        /* --- обычный контекст --- */
        if (depth + 1 < HC_MAX_DEPTH) {
            int r;
            hc_frame_init(&frames[depth + 1], cur, HC_K_PLAIN);
            r = hc_open_tag(&ctx, frames, depth, cur,
                            &frames[depth + 1], &frames[depth + 1].kind);
            if (r == 1)
                depth++;       /* кадр остаётся: закроется при выходе */
            /* r == 0 (лист) / r == -1 (поддерево пропущено): кадр не
             * нужен — effects уже выданы */
        } else {
            /* глубина исчерпана (не бывает: парсер ограничен 128) */
            int kind = HC_K_PLAIN;
            hc_frame_t tmp;
            memset(&tmp, 0, sizeof(tmp));
            (void)hc_open_tag(&ctx, frames, depth, cur, &tmp, &kind);
        }
    }

    /* FIX [HC-PAIR]: блоки, оборванные исчерпанием буфера посреди кода:
     * закрывашка дописывается, при нехватке места ВЕСЬ блок (включая
     * открывашку) откатывается — «висячий» \x01SCRIPT невозможен. */
    if (ctx.sc_open) {
        int need = (ctx.mi > 0 && ctx.md[ctx.mi - 1] != '\n' ? 1 : 0) + 9;
        if (md_max - 1 - ctx.mi >= need) {
            if (ctx.mi > 0 && ctx.md[ctx.mi - 1] != '\n')
                md[ctx.mi++] = '\n';
            memcpy(md + ctx.mi, "\x01/SCRIPT\n", 9);
            ctx.mi += 9;
        } else {
            ctx.mi = ctx.sc_pos;
        }
    }
    if (ctx.ta_open) {
        int need = (ctx.mi > 0 && ctx.md[ctx.mi - 1] != '\n' ? 1 : 0) + 11;
        if (md_max - 1 - ctx.mi >= need) {
            if (ctx.mi > 0 && ctx.md[ctx.mi - 1] != '\n')
                md[ctx.mi++] = '\n';
            memcpy(md + ctx.mi, "\x01/TEXTAREA\n", 11);
            ctx.mi += 11;
        } else {
            ctx.mi = ctx.ta_pos;
        }
    }
    md[ctx.mi] = 0;
    if (ctx.trunc && truncated) *truncated = 1;
    free(frames);
    html_free_document(doc);
    return ctx.mi;
}

int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    return html_to_md2(html, html_len, md, md_max, NULL);
}
