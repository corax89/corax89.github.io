/* brform.h — модель форм браузера N2600-OS (Task 47).
 * Header-only (ядро и хост-тест включают один и тот же код).
 *
 * Конвейер форм:
 *   1. htmlconv.c превращает теги форм в СТРОКИ-МАРКЕРЫ в Markdown,
 *      каждая на своей строке, с атрибутами в кавычках:
 *            \x01FORM action="..." method="get|post"
 *            \x01INPUT type="text" name="q" value="" id="..." ph="..." js="..." [checked]
 *            \x01TEXTAREA name="..." rows="N"
 *            <сырой текст>
 *            \x01/TEXTAREA
 *            \x01SELECT name="..."
 *            \x01OPT value="..." label="..." [selected]
 *            \x01/SELECT
 *            \x01BUTTON type="submit|button" name=".." value=".." js=".." label=".."
 *      и скрипты:
 *            \x01SCRIPTSRC src="..."
 *            \x01SCRIPT  <raw код>  \x01/SCRIPT
 *   2. brf_parse() сканирует md, собирает поля в brf_forms_t и заменяет
 *      строки-маркеры односимвольными якорями \x03 (как картинки \x02 в
 *      brpage.h): перенос строк даёт якорю свою строку отображения, где
 *      браузер рисует контрол. Скрипты собираются в список brf_script_t
 *      (код — malloc), их строки заменяются якорями \x04.
 *   3. Браузер по якорям (srcidx строк отображения) рисует поля, правит
 *      значения и отправляет форму: brf_serialize() даёт
 *      application/x-www-form-urlencoded строку для GET/POST.
 *
 * Парсер только СЖИМАЕТ md (маркер -> якорь/удаление) — in-place без
 * риска роста. Зависимости: types (u8/u32), mem (malloc/free), string,
 * как в brpage.h. */
#ifndef BRFORM_H
#define BRFORM_H

#include "types.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#ifdef HOST_TEST
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#else
#include "mem.h"
#include "string.h"
#endif

/* якоря строк в md (как BRP_IMG_MARK '\002') */
#define BRF_MARK       '\003'   /* якорь поля формы */
#define BRJ_MARK       '\004'   /* якорь скрипта */

#define BRF_MAX_FIELDS 16
#define BRF_MAX_FORMS  4
#define BRF_MAX_OPTS   6
#define BRF_VAL_MAX    100      /* значение поля (и textarea) */
#define BRF_NAME_MAX   28
#define BRF_ID_MAX     28
#define BRF_JS_MAX     96
#define BRF_LABEL_MAX  48
#define BRF_URL_MAX    200
#define BRJ_MAX        24       /* Task 60 [BRJ-BUDGET]: было 10 — на сложных
 * страницах «аналитика» занимала все слоты, и редиректор (11-й и
 * позже) молча уходил в ST_SKIP — не собирался и не исполнялся */
#define BRJ_CODE_MAX   65536    /* Task 60 [BRJ-BUDGET]: было 24576 — шесть
 * скриптов по ~5 КиБ съедали весь бюджет к четвёртому (T7b); куча
 * 512 МиБ, пул MicroQuickJS 256К+512К — скриптовый код копеечен */
#define BRJ_CHUNK      2048     /* стартовый буфер кода одного скрипта */
#define BRJ_GROW       4096     /* шаг роста буфера кода скрипта */
#define BRJ_SKIP_CAP   16384    /* Task 60 [BRJ-RESCUE]: лимит буфера
 * «спасаемого» скрипта (см. brf_parse: код из ST_SKIP копится сюда,
 * редиректор вытесняет несущественный скрипт) */

typedef struct {
    char action[BRF_URL_MAX];
    char method[8];              /* "get"/"post" (по умолчанию get) */
    int  used;
} brf_form_t;

typedef struct {
    char type[10];   /* text/password/checkbox/radio/hidden/submit/button/textarea/select */
    char name[BRF_NAME_MAX];
    char id[BRF_ID_MAX];
    char value[BRF_VAL_MAX];
    char ph[40];                 /* placeholder (подсказка) */
    char js[BRF_JS_MAX];         /* onclick-код */
    char label[BRF_LABEL_MAX];   /* подпись кнопки */
    char opts[BRF_MAX_OPTS][36]; /* варианты select */
    int  nopts;
    int  opt_sel;                /* выбранный вариант (-1 = нет) */
    int  checked;
    int  form;                   /* индекс формы (-1 = вне форм) */
    int  src_line;               /* строка md с якорем \x03 */
    int  row;                    /* строка отображения (заполняет браузер) */
} brf_field_t;

typedef struct {
    char src[BRF_URL_MAX];       /* src внешнего скрипта ("" = инлайн) */
    char *code;                  /* инлайн-код (malloc) или NULL */
    int  code_len;
    int  code_alloc;             /* FIX [BRJ-OVF]: выделено под code
                                  * (room = code_alloc - code_len - 1;
                                  * прежний room считался от ОБЩЕГО
                                  * бюджета и мог переполнить буфер) */
    int  src_line;               /* строка md с якорем \x04 */
    int  done;                   /* выполнен (не повторять) */
} brf_script_t;

typedef struct {
    brf_form_t   forms[BRF_MAX_FORMS];
    int          nforms;
    brf_field_t  fields[BRF_MAX_FIELDS];
    int          nfields;
    brf_script_t scripts[BRJ_MAX];
    int          nscripts;
    int          code_used;      /* байт кода занято (бюджет malloc) */
    /* FIX [META-REFRESH]: <meta http-equiv=refresh content="N;url=U">
     * — htmlconv выдает маркер \x01REFRESH, браузер делает переход */
    char         refresh_url[BRF_URL_MAX];
    int          refresh_delay;  /* секунды (браузер не ждёт) */
} brf_forms_t;

/* ---------------- утилиты ---------------- */

/* Декодировать HTML-entity в маркерном атрибуте: &amp; &lt; &gt; &quot;
 * &#39;/&apos; и числовые &#NN; (только ASCII). Пишет out (NUL) и
 * возвращает длину. */
static int brf_entity_decode(const char *s, int len, char *out, int out_max)
{
    int o = 0;
    if (out_max <= 0) return 0;
    for (int i = 0; i < len && o < out_max - 1; ) {
        if (s[i] == '&') {
            int handled = 0;
            static const char *ents[] = { "amp;", "lt;", "gt;", "quot;", "apos;" };
            static const char vals[]  = { '&', '<', '>', '"', '\'' };
            for (int k = 0; k < 5; k++) {
                int el = 0;
                while (ents[k][el]) el++;
                if (len - i >= el + 1 && strncmp(s + i + 1, ents[k], (u32)el) == 0) {
                    out[o++] = vals[k];
                    i += el + 1;
                    handled = 1;
                    break;
                }
            }
            if (!handled && len - i >= 3 && s[i + 1] == '#') {
                int j = i + 2, base = 10, val = 0, digits = 0;
                if (j < len && (s[j] == 'x' || s[j] == 'X')) { base = 16; j++; }
                while (j < len && s[j] != ';' && digits < 5) {
                    int d;
                    char c = s[j];
                    if (c >= '0' && c <= '9') d = c - '0';
                    else if (base == 16 && c >= 'a' && c <= 'f') d = c - 'a' + 10;
                    else if (base == 16 && c >= 'A' && c <= 'F') d = c - 'A' + 10;
                    else break;
                    val = val * base + d;
                    j++; digits++;
                }
                if (digits && j < len && s[j] == ';' &&
                    val >= 32 && val <= 126) {
                    out[o++] = (char)val;
                    i = j + 1;
                    handled = 1;
                }
            }
            if (handled) continue;
        }
        out[o++] = s[i++];
    }
    out[o] = 0;
    return o;
}

/* Атрибут маркера: формат "\x01KEY type=\"..\" name=.. checked" (флаг
 * без значения тоже атрибут). Возвращает длину значения (0 = нет
 * значения); *present = 1, если атрибут был вовсе. Значение —
 * entity-декод в out (может быть NULL).
 * Task 50 [BRF-EOL]: поиск ОГРАНИЧЕН СТРОКОЙ ('\n'/'\r' — конец):
 * строка передаётся как md+ls без NUL, и раньше перебор атрибутов
 * перетекал на следующие строки маркеров — поле получало js/value
 * ДРУГОГО контрола ниже по странице. */
#define BRF_EOL(c) ((c) == 0 || (c) == '\n' || (c) == '\r')

static int brf_attr(const char *line, const char *name,
                    char *out, int out_max, int *present)
{
    int i = 1;                        /* за \x01 */
    if (present) *present = 0;
    if (out && out_max > 0) out[0] = 0;
    while (!BRF_EOL(line[i]) && line[i] != ' ') i++; /* ключевое слово */
    while (!BRF_EOL(line[i])) {
        while (line[i] == ' ') i++;
        if (BRF_EOL(line[i])) break;
        int ns = i;
        while (!BRF_EOL(line[i]) && line[i] != '=' && line[i] != ' ') i++;
        int ne = i;
        int match = 0;
        {
            const char *a = line + ns;
            const char *b = name;
            while (a < line + ne && *b) {
                char ca = *a, cb = *b;
                if (ca >= 'A' && ca <= 'Z') ca += 32;
                if (cb >= 'A' && cb <= 'Z') cb += 32;
                if (ca != cb) break;
                a++; b++;
            }
            match = (a == line + ne) && (*b == 0);
        }
        if (match) {
            if (present) *present = 1;
            if (line[i] == '=') {
                i++;                                /* за '=' */
                if (line[i] == '"') {
                    i++;
                    int vs = i;
                    while (!BRF_EOL(line[i]) && line[i] != '"') i++;
                    if (out)
                        return brf_entity_decode(line + vs, i - vs,
                                                 out, out_max);
                    int vl = i - vs;
                    if (line[i]) i++;
                    return vl;
                }
                int vs = i;
                while (!BRF_EOL(line[i]) && line[i] != ' ') i++;
                if (out)
                    return brf_entity_decode(line + vs, i - vs,
                                             out, out_max);
                return i - vs;
            }
            if (out && out_max > 0) out[0] = 0;     /* флаг: значения нет */
            return 0;
        }
        /* чужой атрибут: пропустить со значением */
        if (line[i] == '=') {
            i++;
            if (line[i] == '"') {
                i++;
                while (!BRF_EOL(line[i]) && line[i] != '"') i++;
                if (line[i]) i++;
            } else {
                while (!BRF_EOL(line[i]) && line[i] != ' ') i++;
            }
        }
    }
    return 0;
}
#undef BRF_EOL

/* ---------------- urlencode / сериализация ---------------- */

/* application/x-www-form-urlencoded: [A-Za-z0-9-_.~] как есть,
 * ' ' -> '+', остальное -> %XX (по БАЙТАМ UTF-8). 1 = влезло. */
static int brf_urlencode(const char *s, char *out, int out_max)
{
    int o = 0;
    static const char hex[] = "0123456789ABCDEF";
    if (out_max <= 0) return 0;
    for (const char *p = s; *p; p++) {
        unsigned char c = (unsigned char)*p;
        char t[4];
        int n;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' ||
            c == '.' || c == '~') {
            t[0] = (char)c;
            n = 1;
        } else if (c == ' ') {
            t[0] = '+';
            n = 1;
        } else {
            t[0] = '%';
            t[1] = hex[c >> 4];
            t[2] = hex[c & 15];
            n = 3;
        }
        if (o + n >= out_max) return 0;
        for (int k = 0; k < n; k++) out[o++] = t[k];
    }
    out[o] = 0;
    return 1;
}

/* Собрать тело формы form_idx: "name=value&name2=value2" (urlencoded;
 * checkbox/radio без checked не идут, checked шлёт value или "on";
 * select — выбранный вариант; кнопки не сериализуются). 1 = ок. */
static __attribute__((unused)) int brf_serialize(const brf_forms_t *f, int form_idx,
                         char *out, int out_max)
{
    int o = 0;
    char enc[BRF_VAL_MAX * 3 + 4];
    if (out_max <= 0) return 0;
    out[0] = 0;
    for (int i = 0; i < f->nfields; i++) {
        const brf_field_t *fl = &f->fields[i];
        if (fl->form != form_idx) continue;
        if (!fl->name[0]) continue;
        const char *val;
        if (!strcmp(fl->type, "checkbox") || !strcmp(fl->type, "radio")) {
            if (!fl->checked) continue;
            val = fl->value[0] ? fl->value : "on";
        } else if (!strcmp(fl->type, "select")) {
            if (fl->opt_sel < 0 || fl->opt_sel >= fl->nopts) continue;
            val = fl->opts[fl->opt_sel];
        } else if (!strcmp(fl->type, "submit") ||
                   !strcmp(fl->type, "button") ||
                   !strcmp(fl->type, "reset")) {
            continue;
        } else {
            val = fl->value;             /* text/password/textarea/hidden */
        }
        if (!brf_urlencode(fl->name, enc, (int)sizeof(enc))) return 0;
        {
            int n = (int)strlen(enc);
            if (o + n >= out_max) return 0;
            memcpy(out + o, enc, (u32)n);
            o += n;
        }
        if (o + 1 >= out_max) return 0;
        out[o++] = '=';
        if (!brf_urlencode(val, enc, (int)sizeof(enc))) return 0;
        {
            int n = (int)strlen(enc);
            if (o + n >= out_max) return 0;
            memcpy(out + o, enc, (u32)n);
            o += n;
        }
        if (o + 1 >= out_max) return 0;
        out[o++] = '&';
    }
    if (o > 0 && out[o - 1] == '&') o--;     /* хвостовой '&' долой */
    out[o] = 0;
    return 1;
}

/* ---------------- brf_parse: маркеры -> модель ---------------- */

/* Освободить скриптовые буферы и обнулить модель. */
static void brf_reset(brf_forms_t *f)
{
    for (int i = 0; i < f->nscripts; i++) {
        if (f->scripts[i].code) free(f->scripts[i].code);
    }
    memset(f, 0, sizeof(*f));
}

/* Task 60 [BRJ-RESCUE]: код — редиректор? (location.href /
 * location.replace / document.location — без регистра). */
static int brf_is_redirect(const char *code, int len)
{
    static const char *const pats[] = {
        "location.href", "location.replace", "document.location", NULL
    };
    if (!code || len <= 0) return 0;
    for (int k = 0; pats[k]; k++) {
        int pl = 0;
        while (pats[k][pl]) pl++;
        for (int i = 0; i + pl <= len; i++) {
            int j = 0;
            while (j < pl) {
                char a = code[i + j], b = pats[k][j];
                if (a >= 'A' && a <= 'Z') a = (char)(a | 0x20);
                if (b >= 'A' && b <= 'Z') b = (char)(b | 0x20);
                if (a != b) break;
                j++;
            }
            if (j == pl) return 1;
        }
    }
    return 0;
}

/* [BRJ-RESCUE]: кандидат на вытеснение — собранный НЕ-редиректор с
 * code_alloc >= need (минимальный из подходящих), иначе — самый
 * большой. -1 = нет кандидата. */
static int brf_find_victim(const brf_forms_t *f, int need)
{
    int best = -1, best_alloc = 0;
    for (int i = 0; i < f->nscripts; i++) {
        const brf_script_t *sc = &f->scripts[i];
        if (!sc->code || brf_is_redirect(sc->code, sc->code_len))
            continue;
        if (sc->code_alloc >= need &&
            (best < 0 || sc->code_alloc < best_alloc)) {
            best = i;
            best_alloc = sc->code_alloc;
        }
    }
    if (best >= 0) return best;
    for (int i = 0; i < f->nscripts; i++) {
        const brf_script_t *sc = &f->scripts[i];
        if (!sc->code || brf_is_redirect(sc->code, sc->code_len))
            continue;
        if (best < 0 || sc->code_alloc > best_alloc) {
            best = i;
            best_alloc = sc->code_alloc;
        }
    }
    return best;
}

/* [BRJ-RESCUE]: спасти редиректор, чей SCRIPT-маркер пришёл при
 * исчерпанном бюджете (ST_SKIP): вытеснить несущественный скрипт.
 * Бюджет BRJ_CODE_MAX не превышается никогда. 1 = спасён. */
static int brf_rescue(brf_forms_t *f, const char *code, int len)
{
    int need, victim = -1;
    if (!code || len <= 0 || !brf_is_redirect(code, len)) return 0;
    need = len + 1;
    if (need > BRJ_SKIP_CAP) return 0;

    if (f->nscripts < BRJ_MAX && f->code_used + need <= BRJ_CODE_MAX) {
        victim = -1;               /* есть и слот, и бюджет кода */
    } else {
        victim = brf_find_victim(f, need);
        if (victim < 0) return 0;
    }

    if (victim >= 0) {
        brf_script_t *vc = &f->scripts[victim];
        f->code_used -= vc->code_alloc;
        free(vc->code);
        vc->code = NULL;
        vc->code_len = 0;
        vc->code_alloc = 0;
    }
    {
        brf_script_t *sc;
        int idx = (victim >= 0) ? victim : f->nscripts++;
        sc = &f->scripts[idx];
        memset(sc, 0, sizeof(*sc));
        sc->code = (char *)malloc((u32)need);
        if (!sc->code) {
            if (victim < 0) f->nscripts--;
            return 0;
        }
        memcpy(sc->code, code, (u32)len);
        sc->code[len] = 0;
        sc->code_len = len;
        sc->code_alloc = need;
        f->code_used += need;
    }
    return 1;
}

/* Проставить src_line полей/скриптов по якорям в финальном md
 * (якоря встречаются в порядке полей/скриптов). */
static void brf_reindex(brf_forms_t *f, const char *md, int md_len)
{
    int line = 0, fi = 0, si = 0;
    int pos = 0;
    while (pos < md_len) {
        int nl = pos;
        while (nl < md_len && md[nl] != '\n') nl++;
        if (md[pos] == BRF_MARK && fi < f->nfields) {
            f->fields[fi].src_line = line;
            fi++;
        } else if (md[pos] == BRJ_MARK && si < f->nscripts) {
            f->scripts[si].src_line = line;
            si++;
        }
        if (nl >= md_len) break;
        pos = nl + 1;
        line++;
    }
}

/* Разобрать маркеры в md (in-place; md ТОЛЬКО сжимается). Возвращает
 * новую длину. После склеек скриптами вызвать brf_reindex ещё раз. */
static __attribute__((unused)) int brf_parse(brf_forms_t *f, char *md, int md_len)
{
    int r = 0, w = 0;                 /* чтение/запись (w <= r всегда) */
    int cur_form = -1;
    int cur_field = -1;               /* поле, копящее контент */
    int open_script = -1;             /* индекс скрипта с открытым кодом */
    enum { ST_NONE, ST_TEXTAREA, ST_SELECT, ST_SCRIPT, ST_SKIP } st = ST_NONE;
    /* ST_SKIP — FIX [BRJ-OVF]: SCRIPT-маркер пришёл, когда бюджет
     * скриптов/кода исчерпан. Раньше st оставался ST_NONE, все строки
     * кода до \x01/SCRIPT уходили в passthrough и РЕНДЕРИЛИСЬ как текст
     * страницы (главная причина «просачивания скриптов» на сложных
     * страницах). Теперь код молча проглатывается до /SCRIPT. */
    /* Task 60 [BRJ-RESCUE]: проглоченный код КОПИРУЕТСЯ в skip_buf —
     * если это редиректор, при /SCRIPT он вытеснит несущественный
     * скрипт (см. brf_rescue). Раньше редиректор, пришедший 11-м,
     * терялся навсегда. */
    char *skip_buf = NULL;
    int    skip_len = 0, skip_cap = 0;

    brf_reset(f);

    while (r < md_len) {
        int ls = r;
        while (r < md_len && md[r] != '\n') r++;
        int le = r;
        int had_nl = (r < md_len);
        if (had_nl) r++;
        int llen = le - ls;
        if (llen > 0 && md[ls + llen - 1] == '\r') llen--;

        int drop = 0;                 /* строку в вывод не писать */
        char anchor = 0;              /* заменить строку якорем */
        int passthrough = 0;          /* строка остаётся как есть */

        /* Task 50 [BRF-STATE]: маркерная строка (\x01...) распознаётся
         * В ЛЮБОМ состоянии. Раньше st==ST_SELECT/ST_SCRIPT/ST_TEXTAREA
         * безусловно глотали все строки до конца страницы: закрывающие
         * маркеры /SELECT, /SCRIPT, /TEXTAREA обрабатывались только в
         * ветке ST_NONE и были недостижимы, поэтому состояние никогда
         * не сбрасывалось. Симптом: страница «не рендерится» после
         * первого <select>/<script>/<textarea> (всё содержимое
         * исчезало, поля форм пустые). */
        int is_ctl = (llen > 0 && md[ls] == '\x01');
        char kw[12];
        if (is_ctl) {
            int k = 1;
            while (k < llen && k < 11 && md[ls + k] != ' ') {
                kw[k - 1] = md[ls + k];
                k++;
            }
            kw[k - 1] = 0;
        }

        if ((st == ST_SCRIPT || st == ST_SKIP) &&
            !(is_ctl && !strcmp(kw, "/SCRIPT"))) {
            /* инлайн-код скрипта (закрытие — /SCRIPT ниже, в ветке
             * маркеров: сброс st и NUL-терм кода); ST_SKIP — код не
             * собираем, только глотаем строки.
             * FIX [BRJ-OVF]: room теперь от СОБСТВЕННОЙ аллокации
             * скрипта (code_alloc), а буфер растёт порциями BRJ_GROW
             * из общего бюджета (в ядре нет realloc — malloc+копия). */
            if (st == ST_SCRIPT && open_script >= 0 &&
                open_script < f->nscripts && f->scripts[open_script].code) {
                brf_script_t *sc = &f->scripts[open_script];
                int room = sc->code_alloc - sc->code_len - 1;
                /* Task 60 [BRJ-GROW-LOOP]: минифицированный JS одной
                 * строкой длиннее BRJ_GROW резался: рост был одиночным
                 * if (один шаг на строку). Растём, пока строка не
                 * влезет или бюджет не кончится. */
                while (llen > room &&
                       f->code_used + BRJ_GROW <= BRJ_CODE_MAX) {
                    int ncap = sc->code_alloc + BRJ_GROW;
                    char *nc = (char *)malloc((u32)ncap + 1);
                    if (!nc) break;
                    memcpy(nc, sc->code, (u32)sc->code_len);
                    nc[sc->code_len] = 0;
                    free(sc->code);
                    sc->code = nc;
                    sc->code_alloc = ncap;
                    f->code_used += BRJ_GROW;
                    room = ncap - sc->code_len - 1;
                }
                {
                    int n = llen;
                    if (n > room) n = room;
                    if (n > 0) {
                        memcpy(sc->code + sc->code_len, md + ls, (u32)n);
                        sc->code_len += n;
                    }
                    if (had_nl && sc->code_len + 1 < sc->code_alloc)
                        sc->code[sc->code_len++] = '\n';
                }
            }
            /* [BRJ-RESCUE]: копия проглоченного кода (до BRJ_SKIP_CAP) */
            if (st == ST_SKIP && llen > 0) {
                if (!skip_buf) {
                    skip_buf = (char *)malloc(BRJ_SKIP_CAP);
                    if (skip_buf) skip_cap = BRJ_SKIP_CAP;
                }
                if (skip_buf && skip_len + 1 < skip_cap) {
                    int n = llen;
                    if (n > skip_cap - skip_len - 1)
                        n = skip_cap - skip_len - 1;
                    if (n > 0) {
                        memcpy(skip_buf + skip_len, md + ls, (u32)n);
                        skip_len += n;
                        skip_buf[skip_len] = 0;
                    }
                }
            }
            drop = 1;
        } else if (st == ST_TEXTAREA &&
                   !(is_ctl && !strcmp(kw, "/TEXTAREA"))) {
            /* сырой текст textarea -> значение поля (прочие \x01-строки
             * внутрь значения — как раньше, защитно) */
            if (cur_field >= 0 && cur_field < f->nfields) {
                brf_field_t *fl = &f->fields[cur_field];
                int vl = (int)strlen(fl->value);
                for (int q = 0; q < llen && vl < BRF_VAL_MAX - 1; q++) {
                    char ch = md[ls + q];
                    if (ch == '\r') continue;
                    fl->value[vl++] = ch;
                }
                if (vl < BRF_VAL_MAX - 1)
                    fl->value[vl++] = '\n';
                fl->value[vl] = 0;
            }
            drop = 1;
        } else if (st == ST_SELECT && !is_ctl) {
            /* текст варианта — label уже в OPT; текстовых строк внутри
             * select htmlconv не создаёт, но защитно глотаем */
            drop = 1;
        } else if (is_ctl) {
            /* маркер — полная обработка (в т.ч. из ST_SELECT: OPT,
             * /SELECT; из ST_SCRIPT: /SCRIPT; из ST_TEXTAREA: /TEXTAREA) */

            if (!strcmp(kw, "FORM")) {
                if (f->nforms < BRF_MAX_FORMS) {
                    brf_form_t *fo = &f->forms[f->nforms];
                    memset(fo, 0, sizeof(*fo));
                    fo->used = 1;
                    brf_attr(md + ls, "action", fo->action,
                             (int)sizeof(fo->action), NULL);
                    brf_attr(md + ls, "method", fo->method,
                             (int)sizeof(fo->method), NULL);
                    if (!fo->method[0]) strcpy(fo->method, "get");
                    cur_form = f->nforms++;
                }
                drop = 1;
            } else if (!strcmp(kw, "/FORM")) {
                cur_form = -1;
                drop = 1;
            } else if (!strcmp(kw, "INPUT") || !strcmp(kw, "BUTTON")) {
                int is_btn = (kw[0] == 'B');
                if (f->nfields < BRF_MAX_FIELDS) {
                    brf_field_t *fl = &f->fields[f->nfields];
                    memset(fl, 0, sizeof(*fl));
                    fl->form = cur_form;
                    fl->opt_sel = -1;
                    if (is_btn) {
                        int pr = 0;
                        brf_attr(md + ls, "type", fl->type,
                                 (int)sizeof(fl->type), &pr);
                        if (!pr || !fl->type[0]) strcpy(fl->type, "submit");
                        brf_attr(md + ls, "label", fl->label,
                                 (int)sizeof(fl->label), NULL);
                    } else {
                        int pr = 0;
                        brf_attr(md + ls, "type", fl->type,
                                 (int)sizeof(fl->type), &pr);
                        if (!pr || !fl->type[0]) strcpy(fl->type, "text");
                    }
                    brf_attr(md + ls, "name", fl->name,
                             (int)sizeof(fl->name), NULL);
                    brf_attr(md + ls, "value", fl->value,
                             (int)sizeof(fl->value), NULL);
                    brf_attr(md + ls, "id", fl->id,
                             (int)sizeof(fl->id), NULL);
                    brf_attr(md + ls, "ph", fl->ph,
                             (int)sizeof(fl->ph), NULL);
                    brf_attr(md + ls, "js", fl->js,
                             (int)sizeof(fl->js), NULL);
                    {
                        int pr = 0;
                        brf_attr(md + ls, "checked", NULL, 0, &pr);
                        fl->checked = pr;
                    }
                    if (strcmp(fl->type, "hidden") != 0)
                        anchor = BRF_MARK;
                    cur_field = f->nfields;
                    f->nfields++;
                } else {
                    cur_field = -1;
                }
                drop = (anchor == 0);
            } else if (!strcmp(kw, "TEXTAREA")) {
                if (f->nfields < BRF_MAX_FIELDS) {
                    brf_field_t *fl = &f->fields[f->nfields];
                    memset(fl, 0, sizeof(*fl));
                    strcpy(fl->type, "textarea");
                    fl->form = cur_form;
                    fl->opt_sel = -1;
                    brf_attr(md + ls, "name", fl->name,
                             (int)sizeof(fl->name), NULL);
                    brf_attr(md + ls, "id", fl->id,
                             (int)sizeof(fl->id), NULL);
                    anchor = BRF_MARK;
                    cur_field = f->nfields;
                    f->nfields++;
                    st = ST_TEXTAREA;
                } else {
                    cur_field = -1;
                    st = ST_TEXTAREA;
                }
                drop = (anchor == 0);
            } else if (!strcmp(kw, "/TEXTAREA")) {
                st = ST_NONE;
                cur_field = -1;
                drop = 1;
            } else if (!strcmp(kw, "SELECT")) {
                if (f->nfields < BRF_MAX_FIELDS) {
                    brf_field_t *fl = &f->fields[f->nfields];
                    memset(fl, 0, sizeof(*fl));
                    strcpy(fl->type, "select");
                    fl->form = cur_form;
                    fl->opt_sel = -1;
                    brf_attr(md + ls, "name", fl->name,
                             (int)sizeof(fl->name), NULL);
                    anchor = BRF_MARK;
                    cur_field = f->nfields;
                    f->nfields++;
                    st = ST_SELECT;
                } else {
                    cur_field = -1;
                    st = ST_SELECT;
                }
                drop = (anchor == 0);
            } else if (!strcmp(kw, "OPT")) {
                if (cur_field >= 0 && cur_field < f->nfields) {
                    brf_field_t *fl = &f->fields[cur_field];
                    if (fl->nopts < BRF_MAX_OPTS) {
                        char lb[BRF_LABEL_MAX];
                        int oi = fl->nopts;
                        brf_attr(md + ls, "value", fl->opts[oi],
                                 (int)sizeof(fl->opts[oi]), NULL);
                        brf_attr(md + ls, "label", lb,
                                 (int)sizeof(lb), NULL);
                        if (lb[0] && !fl->opts[oi][0]) {
                            strncpy(fl->opts[oi], lb,
                                    sizeof(fl->opts[oi]) - 1);
                            fl->opts[oi][sizeof(fl->opts[oi]) - 1] = 0;
                        }
                        {
                            int pr = 0;
                            brf_attr(md + ls, "selected", NULL, 0, &pr);
                            if (pr) fl->opt_sel = oi;
                        }
                        fl->nopts++;
                    }
                }
                drop = 1;
            } else if (!strcmp(kw, "/SELECT")) {
                st = ST_NONE;
                cur_field = -1;
                drop = 1;
            } else if (!strcmp(kw, "SCRIPTSRC")) {
                if (f->nscripts < BRJ_MAX) {
                    brf_script_t *sc = &f->scripts[f->nscripts++];
                    memset(sc, 0, sizeof(*sc));
                    brf_attr(md + ls, "src", sc->src,
                             (int)sizeof(sc->src), NULL);
                    anchor = BRJ_MARK;
                }
                drop = (anchor == 0);
            } else if (!strcmp(kw, "SCRIPT")) {
                if (f->nscripts < BRJ_MAX) {
                    int cap = BRJ_CODE_MAX - f->code_used;
                    if (cap > BRJ_CHUNK) cap = BRJ_CHUNK;
                    if (cap > 128) {
                        brf_script_t *sc = &f->scripts[f->nscripts];
                        memset(sc, 0, sizeof(*sc));
                        sc->code = (char *)malloc((u32)cap + 1);
                        if (sc->code) {
                            sc->code[0] = 0;
                            sc->code_len = 0;
                            sc->code_alloc = cap;
                            f->code_used += cap;
                            open_script = f->nscripts;
                            f->nscripts++;
                            anchor = BRJ_MARK;
                            st = ST_SCRIPT;
                        } else {
                            st = ST_SKIP;   /* FIX [BRJ-OVF]: нет malloc */
                        }
                    } else {
                        st = ST_SKIP;       /* FIX [BRJ-OVF]: бюджет кода
                                             * исчерпан — глотаем до /SCRIPT */
                    }
                } else {
                    st = ST_SKIP;           /* FIX [BRJ-OVF]: лимит числа
                                             * скриптов исчерпан */
                }
                drop = 1;
            } else if (!strcmp(kw, "/SCRIPT")) {
                if (st == ST_SCRIPT || st == ST_SKIP) {
                    /* Task 60 [BRJ-RESCUE]: проглоченный код —
                     * редиректор? Вытесняем несущественный скрипт. */
                    if (st == ST_SKIP)
                        brf_rescue(f, skip_buf, skip_len);
                    if (open_script >= 0 && open_script < f->nscripts &&
                        f->scripts[open_script].code)
                        f->scripts[open_script].code[f->scripts[open_script].code_len] = 0;
                    open_script = -1;
                    st = ST_NONE;
                }
                drop = 1;
            } else if (!strcmp(kw, "REFRESH")) {
                /* FIX [META-REFRESH]: content="N; url=U" (урл может
                 * отсутствовать — тогда это просто перезагрузка) */
                char cont[300];
                if (brf_attr(md + ls, "content", cont,
                             (int)sizeof(cont), NULL) > 0 &&
                    !f->refresh_url[0]) {
                    int k = 0, d = 0;
                    while (cont[k] >= '0' && cont[k] <= '9' && d < 3600) {
                        d = d * 10 + (cont[k] - '0');
                        k++;
                    }
                    f->refresh_delay = d;
                    /* после ';' ищем url= (регистр не важен) */
                    while (cont[k] && cont[k] != ';') k++;
                    if (cont[k] == ';') k++;
                    while (cont[k] == ' ') k++;
                    if (k + 4 <= (int)sizeof(cont) - 1 &&
                        (cont[k] == 'u' || cont[k] == 'U') &&
                        (cont[k+1] == 'r' || cont[k+1] == 'R') &&
                        (cont[k+2] == 'l' || cont[k+2] == 'L') &&
                        cont[k+3] == '=') {
                        k += 4;
                        int o = 0;
                        while (cont[k] && o < (int)sizeof(f->refresh_url) - 1) {
                            char ch = cont[k++];
                            if (ch == ' ' && (!cont[k] || cont[k] == ' '))
                                break;      /* хвостовые пробелы */
                            f->refresh_url[o++] = ch;
                        }
                        f->refresh_url[o] = 0;
                        /* обрезать хвостовые пробелы */
                        while (o > 0 && f->refresh_url[o-1] == ' ')
                            f->refresh_url[--o] = 0;
                    }
                }
                drop = 1;
            } else {
                drop = 1;             /* неизвестный маркер — долой */
            }
        } else {
            passthrough = 1;
        }

        (void)drop;               /* drop-строки просто не пишутся ниже */
        /* ---- запись ---- */
        if (anchor) {
            if (w < md_len) md[w++] = anchor;
            if (had_nl && w < md_len) md[w++] = '\n';
        } else if (passthrough) {
            for (int q = ls; q < le; q++) md[w++] = md[q];
            if (had_nl && w < md_len) md[w++] = '\n';
        }
        /* drop — ничего (сжатие) */
    }

    md[w] = 0;
    brf_reindex(f, md, w);
    if (skip_buf) free(skip_buf);      /* [BRJ-RESCUE] */
    return w;
}

/* ---------------- Task 60: очистка md от «хвостов» маркеров ----------------
 *
 * Единственный brf_parse — при загрузке страницы (apps_browser.c).
 * Всё, что попало в md ПОСЛЕ него (вставки document.write, onclick-
 * сниппеты), содержит \x01-маркеры, которые brl_wrap/br_draw НЕ
 * фильтруют и рисуют как текст (главный канал утечки — сценарий E/F
 * из разбора Task 60). Очистители ниже закрывают канал. */

/* Убрать из md ВСЕ строки, начинающиеся с \x01 (маркеры форм/скриптов/
 * REFRESH). Блок \x01SCRIPT глотается целиком до \x01/SCRIPT или конца
 * буфера — как ST_SCRIPT в brf_parse. Якоря \x03/\x04 (одиночные
 * строки) НЕ трогаются. Возвращает новую длину. */
static int brf_scrub(char *md, int md_len)
{
    int r = 0, w = 0;
    int in_script = 0;
    while (r < md_len) {
        int ls = r;
        while (r < md_len && md[r] != '\n') r++;
        int le = r;
        int had_nl = (r < md_len);
        if (had_nl) r++;

        int is_ctl = (le > ls && md[ls] == '\x01');
        char kw[12] = "";
        if (is_ctl) {
            int k = 1;
            while (k < le - ls && k < 11 && md[ls + k] != ' ') {
                kw[k - 1] = md[ls + k];
                k++;
            }
            kw[k - 1] = 0;
        }

        if (in_script) {
            if (is_ctl && !strcmp(kw, "/SCRIPT")) in_script = 0;
            continue;                      /* код скрипта — долой */
        }
        if (is_ctl) {
            if (!strcmp(kw, "SCRIPT")) in_script = 1;
            continue;                      /* любые маркеры — долой */
        }
        for (int q = ls; q < le; q++) {
            char c = md[q];
            if (c == '\x01') c = ' ';      /* мусор внутри строки */
            md[w++] = c;
        }
        if (had_nl) md[w++] = '\n';
    }
    md[w] = 0;   /* вызыватели держат md с запасом под NUL (как brf_parse) */
    return w;
}

/* Убрать строки-якоря \x04 (одиночный символ на строке). Нужна перед
 * splice вывода document.write: якоря временной модели не должны
 * смещать brf_reindex основной (порядок якорей = порядок скриптов). */
static int brf_strip_script_anchors(char *md, int md_len)
{
    int r = 0, w = 0;
    while (r < md_len) {
        int ls = r;
        while (r < md_len && md[r] != '\n') r++;
        int le = r;
        int had_nl = (r < md_len);
        if (had_nl) r++;
        if (le - ls == 1 && md[ls] == BRJ_MARK)
            continue;
        for (int q = ls; q < le; q++) md[w++] = md[q];
        if (had_nl) md[w++] = '\n';
    }
    return w;
}

/* Усыновить формы/поля/refresh из временной модели document.write (в
 * пределах лимитов основной). Скрипты НЕ переносит (исполняются
 * отдельно, код в куче временной модели). Поля получают \x03-якоря,
 * уже оставленные в md вставки — brf_reindex после splice поставит им
 * src_line (порядок якорей в md совпадает с порядком усыновления). */
static void brf_adopt(brf_forms_t *dst, const brf_forms_t *src)
{
    for (int i = 0; i < src->nforms && dst->nforms < BRF_MAX_FORMS; i++)
        dst->forms[dst->nforms++] = src->forms[i];
    for (int i = 0; i < src->nfields && dst->nfields < BRF_MAX_FIELDS; i++)
        dst->fields[dst->nfields++] = src->fields[i];
    if (!dst->refresh_url[0] && src->refresh_url[0]) {
        memcpy(dst->refresh_url, src->refresh_url,
               sizeof(dst->refresh_url));
        dst->refresh_delay = src->refresh_delay;
    }
}

#endif /* BRFORM_H */
