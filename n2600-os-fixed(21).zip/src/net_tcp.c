/* net_tcp.c — TCP-слой стека N2600-OS (Task 49; вынесен из net.c).
 *
 * Самодостаточный TCP: заголовки/флаги, таблица сокетов, пины/поколения,
 * ретрансмиссии, connect/listen/close/send, разбор входящих сегментов и
 * loopback-пара (клиент-сервер без провода). Нижний слой — net.c:
 * net_send_ip (IP-датаграммы), inet_checksum_pseudo, net_get_ip/
 * net_dhcp_txn_active (наш адрес/флаг DHCP-транзакции) — объявления в
 * net_tcp.h. Публичный API (net.h) не менялся: net_tcp_* зовут telnetd,
 * net_httpd, net_http, net_dns как раньше. */
#include "types.h"
#include "string.h"
#include "mem.h"
#include "timer.h"
#include "net.h"
#include "net_tcp.h"
#include "sync.h"

extern void serial_puts(const char *);

/* listen-слоты: из бывшего блока forward-деклараций net.c */
typedef struct {
    int  in_use;
    u16  port;
    tcp_accept_cb_t cb;
    net_tcp_recv_cb_t recv_cb;   /* per-socket приём принятых соединений */
} tcp_listen_t;

#define NET_MAX_TCP_LISTEN 4
static tcp_listen_t g_tcp_listens[NET_MAX_TCP_LISTEN];

#define parse_tcp_options parse_tcp_options_impl
/* ===================== TCP ===================== */

typedef struct {
    u16 src_port;
    u16 dst_port;
    u32 seq;
    u32 ack;
    u8  data_offset;   /* верхние 4 бита — header length в 32-битных словах */
    u8  flags;
    u16 window;
    u16 checksum;
    u16 urgent;
} tcp_hdr_t;

#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
#define TCP_URG 0x20

static net_tcp_socket_t g_tcp_socks[NET_MAX_TCP_SOCKETS];
static net_tcp_recv_cb_t g_tcp_recv_cb = NULL;
static u32 g_tcp_next_isn = 0x1000;   /* initial seq number counter */

/* [IP-CHG2]: пометить сокеты, созданные под прежним адресом — после
 * миграции их чексуммы считает от ТЕКУЩЕГО адреса ([IP-CHG1]); флаг —
 * для приложений/диагностики (сокет самовосстанавливается). */
void net_tcp_mark_migrated(u32 ip)
{
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        if (g_tcp_socks[i].in_use && g_tcp_socks[i].local_ip != 0 &&
            g_tcp_socks[i].local_ip != ip)
            g_tcp_socks[i].ip_migrated = 1;
    }
}

/* Сессия 72 [GEN]: поколение слота — +1 при каждом захвате. Владельцы
 * (httpd_conn_t.gen) сверяют его с net_tcp_gen(sock): не совпало —
 * слот после захвата ссылки был освобождён и занят заново, ссылка
 * мертва (чужой сокет закрывать/слать нельзя). */
static u32 g_tcp_gen[NET_MAX_TCP_SOCKETS];
/* Сессия 72 [PIN]: слот закреплён владельцем (httpd принял соединение
 * и ещё не отдал его слоту обратно). Захватчики (net_tcp_connect,
 * loopback/wire accept) слоты с пином не берут — даже если пир или
 * таймер уже снял in_use, а владелец ещё не знает о смерти сокета.
 * Пин снимает только владелец (net_tcp_unpin_gen в httpd_slot_reset). */
static u8  g_tcp_pinned[NET_MAX_TCP_SOCKETS];

void net_tcp_pin(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    g_tcp_pinned[sock] = 1;
}

void net_tcp_unpin(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    g_tcp_pinned[sock] = 0;
}

/* Снять пин ТОЛЬКО своего поколения: ссылка, пережившая
 * переиспользование слота, не снимет чужой (новый) пин. */
void net_tcp_unpin_gen(int sock, u32 gen)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    if (g_tcp_gen[sock] == gen) g_tcp_pinned[sock] = 0;
}

u32 net_tcp_gen(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    return g_tcp_gen[sock];
}

/* Слот доступен для захвата: свободен И не закреплён владельцем. */
static int tcp_slot_free(int k)
{
    if (k < 0 || k >= NET_MAX_TCP_SOCKETS) return 0;
    return !g_tcp_socks[k].in_use && !g_tcp_pinned[k];
}

void net_tcp_set_callback(net_tcp_recv_cb_t cb) { g_tcp_recv_cb = cb; }

/* Итерация 7 [TCLIENT]: СОБСТВЕННЫЙ приём на клиентском сокете.
 * Прежде клиентские соединения (connect) всегда падали в глобальный
 * callback — единственный, и тот, кто регистрировал его последним,
 * забирал данные всех сокетов. telnet-клиенту нужен приём ТОЛЬКО
 * своего сокета, не трогая браузер/httpd. Механизм уже существовал
 * для accept-сокетов (s->recv_cb назначается из listen-таблицы) —
 * открываем его и для активных соединений. */
void net_tcp_set_sock_callback(int sock, net_tcp_recv_cb_t cb)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    g_tcp_socks[sock].recv_cb = cb;
}

const char *tcp_state_name(tcp_state_t s)
{
    static const char *names[] = {
        "CLOSED", "SYN_SENT", "SYN_RECEIVED", "ESTABLISHED",
        "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT", "LAST_ACK",
        "CLOSING", "TIME_WAIT"
    };
    if (s < (tcp_state_t)10) return names[s];
    return "?";
}

/* Отправить TCP-сегмент с заданными флагами и payload.
 * Если флаг SYN установлен, добавляем MSS option (default 1460).
 *
 * FIX [N1] (браузер не открывал http://<IP>): чексумма TCP НЕ считалась
 * (поле оставалось 0). В TCP (в отличие от UDP) нулевая чексумма НЕ
 * легитимна — серверы молча сбрасывают такие сегменты, включая SYN:
 * connect «висел» до таймаута → «Ошибка запроса». Теперь считаем
 * чексумму по псевдозаголовку (inet_checksum_pseudo — уже была в файле,
 * но не использовалась). */
static void tcp_send_segment(net_tcp_socket_t *s, u8 flags,
                             const void *data, u32 data_len)
{
    static u8 pkt[1500];
    static volatile int tcpseg_lock = 0;
    s_lock(&tcpseg_lock);
    tcp_hdr_t *tcp = (tcp_hdr_t *)pkt;
    tcp->src_port = (u16)((s->local_port >> 8) | (s->local_port << 8));
    tcp->dst_port = (u16)((s->remote_port >> 8) | (s->remote_port << 8));
    tcp->seq = (u32)((s->seq >> 24) | ((s->seq >> 8) & 0xFF00)
                   | ((s->seq << 8) & 0xFF0000) | (s->seq << 24));
    tcp->ack = (u32)((s->ack >> 24) | ((s->ack >> 8) & 0xFF00)
                   | ((s->ack << 8) & 0xFF0000) | (s->ack << 24));

    u32 hdr_len = 20;
    /* Для SYN добавляем MSS option (4 байта: type=2, len=4, value=1460) */
    if (flags & TCP_SYN) {
        u8 *opts = (u8 *)(pkt + 20);
        opts[0] = 2;  /* MSS option type */
        opts[1] = 4;  /* length */
        opts[2] = (u8)((s->mss >> 8) & 0xFF);
        opts[3] = (u8)(s->mss & 0xFF);
        /* Pad to 24 bytes (4 bytes option, divisible by 4) */
        hdr_len = 24;
    }

    tcp->data_offset = (u8)((hdr_len / 4) << 4);
    tcp->flags = flags;
    tcp->window = 0xFFFF;   /* max window */
    tcp->window = (u16)((tcp->window >> 8) | (tcp->window << 8));
    tcp->checksum = 0;
    tcp->urgent = 0;
    if (data && data_len > 0) {
        memcpy(pkt + hdr_len, data, data_len);
    }
    /* FIX [N1] + [IP-CHG1] (Task 41, повтор Task 40): src ПСЕВДОзаголовка
     * обязан совпадать с src IP-пакета (net_send_ip: dhcp_txn ? 0 : net_get_ip()).
     * Прежний расчёт по s->local_ip: сокет, созданный под другим адресом
     * (дефолт 10.0.2.15 до DHCP / старый сегмент после смены), уходил с
     * ВАЛИДНОЙ чексуммой для НЕВЕРНОГО src — сервер молча ронял сегменты
     * (никаких ошибок ни у нас, ни у него), соединение висело до таймаута.
     * Текущий адрес — всегда; сокеты с устаревшим local_ip
     * самовосстанавливаются. */
    {
        u32 tx_src = net_dhcp_txn_active() ? 0 : net_get_ip();
        u16 cs = inet_checksum_pseudo(tx_src, s->remote_ip,
                                      IP_PROTO_TCP, pkt, hdr_len + data_len);
        tcp->checksum = (u16)((cs << 8) | (cs >> 8));
    }
    net_send_ip(IP_PROTO_TCP, s->remote_ip, pkt, hdr_len + data_len);
    s_unlock(&tcpseg_lock);
}

/* FIX [N1b]: повторная отправка SYN, пока соединение не установлено.
 * Раньше net_tcp_timer() «ретранслировал» только счётчики (заглушка),
 * а первый SYN терялся при отсутствии ARP-записи (пакет молча
 * отбрасывался в net_send_ip) — ping выживал повторами, TCP — нет. */
void net_tcp_kick(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use || s->state != TCP_SYN_SENT) return;
    u32 cur = s->seq;             /* seq уже учёл +1 за SYN */
    s->seq = cur - 1;
    tcp_send_segment(s, TCP_SYN, NULL, 0);
    s->seq = cur;
    s->retransmit_tick = timer_ticks();
    s->retransmit_count++;
}

int net_tcp_connect(u32 dst_ip, u16 dst_port, u16 local_port)
{
    int i;
    for (i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        if (tcp_slot_free(i)) break;   /* [PIN]: закреплённые не трогаем */
    }
    if (i >= NET_MAX_TCP_SOCKETS) {
        /* диагностика в serial: какие состояния заняли все слоты
         * (утёкшие сокеты раньше были невидимы) */
        char msg[128];
        extern void serial_puts(const char *);
        int pos = 0;
        pos += snprintf(msg + pos, sizeof(msg) - pos,
                        "[net] tcp: нет свободных сокетов (%d занято):",
                        NET_MAX_TCP_SOCKETS);
        for (int k = 0; k < NET_MAX_TCP_SOCKETS && pos < (int)sizeof(msg) - 8; k++) {
            if (g_tcp_socks[k].in_use)
                pos += snprintf(msg + pos, sizeof(msg) - pos, " %d",
                                (int)g_tcp_socks[k].state);
        }
        serial_puts(msg);
        serial_puts("\n");
        return -1;
    }

    net_tcp_socket_t *s = &g_tcp_socks[i];
    s->in_use = 1;
    /* [C-STATE] [GEN]: живое состояние СРАЗУ после захвата. Раньше
     * между in_use=1 и назначением состояния вытеснение по IRQ0
     * оставляло слот с мусорным state==TCP_CLOSED — таймер считал его
     * «застрявшим» и освобождал, а серверная сторона loopback-пары
     * занимала ТОТ ЖЕ слот → пара замыкалась на себя. SYN_SENT даёт
     * таймеру лимит 15 с на handshake. */
    g_tcp_gen[i]++;                 /* [GEN]: новое поколение слота */
    s->state = TCP_SYN_SENT;
    s->local_ip = net_get_ip();
    s->local_port = local_port;
    s->remote_ip = dst_ip;
    s->remote_port = dst_port;
    s->seq = g_tcp_next_isn;
    g_tcp_next_isn += 64000;   /* increment ISN */
    {
        extern void serial_puts(const char *);
        char b[80];
        snprintf(b, sizeof(b), "[tcp] connect idx=%d isn=%u dst=%08x:%u\n",
                 i, (unsigned)(s->seq), (unsigned)dst_ip, (unsigned)dst_port);
        serial_puts(b);
    }
    /* [IP-CHG1] (Task 41, повтор Task 40): разовая подсказка в поле —
     * сегменты идут С ТЕКУЩИМ адресом (чексуммы от него же), даже если
     * сокет создавался при другом ([IP-CHG2] помечает такие
     * ip_migrated=1). Без этого соединения после смены IP висели молча. */
    {
        static int g_tcp_srcnote_done = 0;
        if (!g_tcp_srcnote_done && net_get_ip() != 0) {
            extern void klog_puts(const char *);
            char b[96], ib[16];
            net_ntoa(net_get_ip(), ib, sizeof(ib));
            snprintf(b, sizeof(b),
                     "[tcp] сокет создан при IP %s — сегменты идут с текущим адресом",
                     ib);
            serial_puts(b);
            serial_puts("\n");
            klog_puts(b);
            g_tcp_srcnote_done = 1;
        }
    }
    s->ack = 0;
    s->mss = 1460;
    s->window_scale = 0;
    s->retransmit_seq = 0;
    s->retransmit_tick = 0;
    s->retransmit_count = 0;
    s->retrans_len = 0;       /* FIX [TCP-R1]: без мусора от прошлого сокета */
    s->was_reset = 0;         /* FIX [TCP-R2]: сброс флага RST нового соединения */
    s->rst_ip = 0;            /* сессия 56: данные RST прошлого соединения */
    s->rst_port = 0;
    s->rst_ttl = 0;
    s->ip_migrated = 0;       /* [IP-CHG2]: новый сокет — без миграции */
    s->peer = -1;
    s->recv_cb = NULL;

    /* ---------- Loopback: 127.x / на себя ----------
     * Соединение замыкается внутри стека: если порт слушает локальный
     * сервер (например httpd) — создаем пару сокетов и «проигрываем»
     * handshake; нет слушателя — мгновенный «connection refused». */
    if (net_is_loopback(dst_ip)) {
        for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
            if (!g_tcp_listens[li].in_use) continue;
            if (g_tcp_listens[li].port != dst_port) continue;

            /* свободный сокет под серверную сторону */
            int j = -1;
            for (int k = 0; k < NET_MAX_TCP_SOCKETS; k++) {
                if (tcp_slot_free(k)) { j = k; break; }   /* [PIN] */
            }
            if (j < 0) break;   /* слотов нет — refuse */

            net_tcp_socket_t *srv = &g_tcp_socks[j];
            srv->in_use = 1;
            /* [C-STATE] [GEN]: живое состояние сразу (см. выше) —
             * вытеснение между захватом и ESTABLISHED не отдаст слот
             * таймеру и не подставит под пару чужой захватчик. */
            g_tcp_gen[j]++;
            srv->state = TCP_SYN_RECEIVED;
            srv->local_ip = dst_ip;
            srv->local_port = dst_port;
            srv->remote_ip = 0x7F000001u;       /* 127.0.0.1 */
            srv->remote_port = local_port;
            srv->seq = g_tcp_next_isn;
            g_tcp_next_isn += 64000;
            srv->ack = s->seq + 1;              /* SYN клиента */
            srv->mss = 1460;
            srv->window_scale = 0;
            srv->retransmit_seq = 0;
            srv->retransmit_tick = 0;
            srv->retransmit_count = 0;
            srv->retrans_len = 0;
            srv->was_reset = 0;
            srv->peer = i;
            srv->recv_cb = g_tcp_listens[li].recv_cb;

            /* клиентская сторона: SYN + SYN-ACK + ACK «состоялись» */
            s->seq += 1;
            s->ack = srv->seq + 1;
            s->peer = j;
            s->state = TCP_ESTABLISHED;
            srv->state = TCP_ESTABLISHED;

            /* уведомить сервер о входящем соединении */
            if (g_tcp_listens[li].cb)
                g_tcp_listens[li].cb(j, srv->remote_ip, local_port);
            return i;
        }
        /* слушателя нет — соединение отвергнуто */
        s->state = TCP_CLOSED;   /* клиент увидит «connection refused» */
        return i;
    }

    s->state = TCP_SYN_SENT;

    /* Send SYN with MSS option */
    tcp_send_segment(s, TCP_SYN, NULL, 0);
    s->seq += 1;   /* SYN consumes 1 seq */
    s->retransmit_seq = s->seq - 1;  /* SYN seq */
    s->retransmit_tick = timer_ticks();
    return i;
}

/* ===================== TCP Passive LISTEN ===================== */

int net_tcp_listen(u16 local_port, tcp_accept_cb_t cb,
                   net_tcp_recv_cb_t recv_cb)
{
    for (int i = 0; i < NET_MAX_TCP_LISTEN; i++) {
        if (!g_tcp_listens[i].in_use) {
            g_tcp_listens[i].in_use = 1;
            g_tcp_listens[i].port = local_port;
            g_tcp_listens[i].cb = cb;
            g_tcp_listens[i].recv_cb = recv_cb;
            return i;
        }
    }
    return -1;
}

/* Сессия 58: снять слушатель (Настройки → галочка «Веб-сервер»). */
void net_tcp_unlisten(u16 local_port)
{
    for (int i = 0; i < NET_MAX_TCP_LISTEN; i++) {
        if (g_tcp_listens[i].in_use && g_tcp_listens[i].port == local_port)
            g_tcp_listens[i].in_use = 0;
    }
}

/* Парсить TCP-опции (MSS, Window Scale, SACK-permitted) */
static void parse_tcp_options_impl(const u8 *opts, u32 opts_len,
                               net_tcp_socket_t *s)
{
    u32 i = 0;
    while (i < opts_len) {
        u8 type = opts[i];
        if (type == 0) break;  /* End of options */
        if (type == 1) { i++; continue; }  /* NOP */
        if (i + 1 >= opts_len) break;
        u8 len = opts[i+1];
        if (len < 2) break;
        if (type == 2 && len == 4 && i + 4 <= opts_len) {
            /* MSS option */
            s->mss = ((u16)opts[i+2] << 8) | opts[i+3];
            if (s->mss < 536) s->mss = 536;
            if (s->mss > 1460) s->mss = 1460;
        }
        else if (type == 3 && len == 3 && i + 3 <= opts_len) {
            /* Window Scale option */
            s->window_scale = opts[i+2];
        }
        i += len;
    }
}

void net_tcp_close(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use) return;

    /* ---------- loopback-пара ---------- */
    if (s->peer >= 0) {
        net_tcp_socket_t *p = &g_tcp_socks[s->peer];
        if (p->in_use && p->peer == sock) {
            /* Партнёр получает FIN: для наших клиентов это конец
             * данных — переводим его в CLOSED (приём уже доставлен
             * инлайн, HTTP/1.0-клиенты после FIN ничего не ждут). */
            p->peer = -1;
            p->state = TCP_CLOSED;   /* in_use остаётся: сокет закроет своё приложение */
        }
        s->peer = -1;
        s->state = TCP_CLOSED;
        s->in_use = 0;
        return;
    }

    if (s->state == TCP_ESTABLISHED) {
        tcp_send_segment(s, TCP_FIN | TCP_ACK, NULL, 0);
        s->seq += 1;
        s->state = TCP_FIN_WAIT_1;
    } else if (s->state == TCP_CLOSE_WAIT) {
        tcp_send_segment(s, TCP_FIN | TCP_ACK, NULL, 0);
        s->seq += 1;
        /* [TCP-CLOSEWAIT] close() из пассивного закрытия: наш FIN ушёл —
         * слот освобождаем СРАЗУ (как прежде из LAST_ACK). Финальный ACK
         * пира слоту не нужен (приложение уже отвязано), а пул из 8
         * сокетов не должен упираться в 3-секундный [FIN-TO] айджинг при
         * быстрой навигации. Поздний ACK/повтор FIN пира мимо 4-tuple
         * (слот закрыт или занят новым соединением) игнорируется молча. */
        s->state = TCP_CLOSED;
        s->in_use = 0;
    } else {
        s->state = TCP_CLOSED;
        s->in_use = 0;
    }
}

int net_tcp_send(int sock, const void *data, u32 len)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return -1;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    /* [TCP-CLOSEWAIT]: отправка разрешена и после FIN ПИРА
     * (CLOSE_WAIT — пассивное закрытие, наша сторона ещё шлёт; свой
     * FIN мы не посылали). Ломается только после нашего close(). */
    if (!s->in_use || (s->state != TCP_ESTABLISHED &&
                       s->state != TCP_CLOSE_WAIT)) return -1;

    /* ---------- loopback-пара: доставка партнёру без провода ---------- */
    if (s->peer >= 0) {
        net_tcp_socket_t *p = &g_tcp_socks[s->peer];
        /* партнёр в CLOSE_WAIT ещё принимает данные (его recv_cb жив;
         * свой FIN он не слал — httpd дочитывает ответ) */
        if (!p->in_use || (p->state != TCP_ESTABLISHED &&
                           p->state != TCP_CLOSE_WAIT)) return -1;
        int pidx = s->peer;
        if (p->recv_cb)
            p->recv_cb(s->peer, s->local_ip ? s->local_ip : 0x7F000001u,
                       s->local_port, data, len);
        else if (g_tcp_recv_cb)
            g_tcp_recv_cb(s->peer, s->local_ip ? s->local_ip : 0x7F000001u,
                          s->local_port, data, len);
        /* СЕССИЯ 61: колбэк мог ЗАКРЫТЬ/переиспользовать слоты (httpd
         * завершает соединение прямо внутри синхронной обработки
         * запроса; параллельная задача может занять освободившийся
         * индекс). Бухгалтерию seq/ack ведём только по живой паре. */
        if (s->in_use && s->peer == pidx) {
            s->seq += len;
            net_tcp_socket_t *p2 = &g_tcp_socks[pidx];
            if (p2->in_use && p2->peer == sock)
                p2->ack = s->seq;    /* партнёр подтверждает наши данные */
        }
        return (int)len;
    }

    u32 mss = s->mss ? s->mss : 1460;
    if (len > mss) len = mss;
    tcp_send_segment(s, TCP_PSH | TCP_ACK, data, len);
    s->seq += len;
    /* Track for retransmission */
    s->retransmit_seq = s->seq - len;
    s->retransmit_tick = timer_ticks();
    s->retransmit_count = 0;
    /* FIX [TCP-R1]: сохранить сегмент — таймер сможет его реально
     * переслать (раньше «ретрансмиссия» была только счётчиком). */
    if (data && len > 0) {
        u32 save = len < TCP_RETRANS_MAX ? len : TCP_RETRANS_MAX;
        memcpy(s->retrans_buf, data, save);
        s->retrans_len = (u16)save;
    }
    return (int)len;
}

tcp_state_t net_tcp_state(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return TCP_CLOSED;
    if (!g_tcp_socks[sock].in_use) return TCP_CLOSED;
    return g_tcp_socks[sock].state;
}

/* Сессия 60 (FSM httpd): есть ли сегмент данных, ещё не подтверждённый
 * пиром. Пока pending == 1, следующий кусок слать нельзя: буфер
 * ретрансляции один (retrans_buf), потерянный кусок больше не
 * восстановить — отправка файла идёт «стоп-и-ждём» по одному сегменту,
 * следующий — только после ACK (сброс retransmit_seq в tcp_input). */
int net_tcp_send_pending(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    const net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use) return 0;
    return (s->retransmit_seq != 0) ? 1 : 0;
}

/* FIX [TCP-R2]: признак сброса соединения. Читается и после того, как
 * сокет переведён в CLOSED (в том числе когда net_tcp_timer уже
 * освободил слот): флаг живёт до следующего net_tcp_connect. */
int net_tcp_was_reset(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    return g_tcp_socks[sock].was_reset;
}

/* Сессия 56: источник последнего RST (для сообщений браузера/клиента).
 * was_reset живёт до следующего net_tcp_connect на этот слот. */
int net_tcp_rst_info(int sock, u32 *ip, u16 *port, u8 *ttl)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->was_reset) return 0;
    if (ip)   *ip   = s->rst_ip;
    if (port) *port = s->rst_port;
    if (ttl)  *ttl  = s->rst_ttl;
    return 1;
}

/* TCP retransmission timer — проверяет все сокеты на таймаут.
 *
 * FIX [утечка сокетов, реальное железо]: сокет, застрявший в любом
 * промежуточном состоянии, раньше жил ВЕЧНО. Каждый неудачный connect
 * (например, при невалидном адресе источника до фикса DHCP) навсегда
 * занимал слот из 8 — после нескольких попыток net_tcp_connect()
 * мгновенно возвращал -1 («connect 0 мс, сокет -1» в HTTP Trace).
 * Теперь каждое переходное состояние имеет возрастной лимит: смена
 * состояния фиксируется в теневом массиве, просроченное — сброс. */
void net_tcp_timer(void)
{
    static u32 shadow_state[NET_MAX_TCP_SOCKETS];
    static u32 shadow_tick[NET_MAX_TCP_SOCKETS];
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        net_tcp_socket_t *s = &g_tcp_socks[i];
        if (!s->in_use) {
            shadow_state[i] = 0;
            continue;
        }
        if (s->state != shadow_state[i]) {
            shadow_state[i] = s->state;
            shadow_tick[i] = timer_ticks();
        }
        u32 age = timer_ticks() - shadow_tick[i];
        int aged_out = 0;
        switch (s->state) {
            case TCP_SYN_SENT:
            case TCP_SYN_RECEIVED:
                if (age >= 15000) aged_out = 1;   /* 15 с на handshake (1 тик = 1 мс) */
                break;
            case TCP_FIN_WAIT_1:
            case TCP_FIN_WAIT_2:
            case TCP_LAST_ACK:
                /* [FIN-TO] (отчёт, баг 5): было 30 с — при 8 слотах
                 * NET_MAX_TCP_SOCKETS мёртвый пир (FIN уходит в пустоту,
                 * ACK не приходит никогда; ретрансмиссия FIN в стеке
                 * не делается — только данные в ESTABLISHED) занимал
                 * слот полминуты: четыре неудачных fetch = половина
                 * пула в подвешенном состоянии. Живой пир ACK-ает FIN
                 * за <100 мс; 3 с — это ~30 RTT, дальше сидеть
                 * бессмысленно. FIN_WAIT_2 сюда же: приложение уже
                 * сказало close() — дочитывать серверу больше нечего. */
                if (age >= 3000) aged_out = 1;    /* 3 с на закрытие (1 тик = 1 мс) */
                break;
            case TCP_TIME_WAIT:
                if (age >= 10000) aged_out = 1;   /* 10 с (2×MSL упрощённо; 1 тик = 1 мс) */
                break;
            case TCP_CLOSE_WAIT:
                if (age >= 60000) aged_out = 1;   /* 60 с грейс на дочитку (1 тик = 1 мс) */
                break;
            default:
                break;
        }
        if (aged_out) {
            s->state = TCP_CLOSED;
            s->in_use = 0;
            continue;
        }
        if (s->state == TCP_CLOSED) {
            /* застрявший CLOSED (в т.ч. loopback-refuse): приложение
             * уже увидело отказ — освобождаем слот, иначе утечка */
            s->in_use = 0;
            continue;
        }
        if (s->retransmit_seq == 0) continue;
        if (s->retransmit_tick == 0) continue;
        /* Timeout: 1 second initially, doubling on each retransmit */
        u32 timeout_ticks = 1000u;  /* 1 с (1 тик = 1 мс, сессия 33) */
        for (int j = 0; j < s->retransmit_count; j++) timeout_ticks *= 2;
        if (timeout_ticks > 64000u) timeout_ticks = 64000u;  /* cap at 64s */
        if ((timer_ticks() - s->retransmit_tick) < timeout_ticks) continue;
        /* FIX [TCP-R1]: РЕАЛЬНАЯ ретрансмиссия последнего сегмента данных.
         * Раньше здесь только инкрементировался счётчик, а данные НЕ
         * пересылались: потерянный GET не восстанавливался — сервер
         * молчал, клиент висел до «response timeout». */
        /* [TCP-CLOSEWAIT]: сегмент, отправленный уже после FIN пира
         * (досылка ответа/close_notify), тоже подлежит ретрансмиссии */
        if (s->retrans_len > 0 &&
            (s->state == TCP_ESTABLISHED || s->state == TCP_CLOSE_WAIT)) {
            u32 cur = s->seq;
            s->seq = s->retransmit_seq;
            tcp_send_segment(s, TCP_PSH | TCP_ACK, s->retrans_buf,
                             s->retrans_len);
            s->seq = cur;
        }
        s->retransmit_count++;
        s->retransmit_tick = timer_ticks();
        if (s->retransmit_count > 8) {
            /* Too many retransmits — abort */
            s->was_reset = 1;   /* для клиента это выглядит как сброс */
            s->state = TCP_CLOSED;
            s->in_use = 0;
        }
    }
}

void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < 20) return;
    /* FIX (сессия 60): порты читаем БАЙТАМИ — payload начинается на
     * нечётном смещении (Ethernet 14 + IP 20 = 34), доступ к u16 через
     * packed tcp_hdr_t — невыровненный (UBSan хост-харнесса ругался).
     * На i386 это работало, но байтовое чтение корректно везде. */
    u16 src_port = (u16)(((u32)payload[0] << 8) | payload[1]);
    u16 dst_port = (u16)(((u32)payload[2] << 8) | payload[3]);
    u32 seq = ((u32)(payload[4]) << 24) | ((u32)(payload[5]) << 16)
            | ((u32)(payload[6]) << 8) | (u32)payload[7];
    u32 ack = ((u32)(payload[8]) << 24) | ((u32)(payload[9]) << 16)
            | ((u32)(payload[10]) << 8) | (u32)payload[11];
    u8  flags = payload[13];
    u8  hdr_len = (u8)((payload[12] >> 4) * 4);
    if (hdr_len < 20 || hdr_len > len) return;

    u32 data_len = len - hdr_len;
    const u8 *data = payload + hdr_len;
    const u8 *opts = payload + 20;
    u32 opts_len = hdr_len > 20 ? (hdr_len - 20) : 0;

    u32 src_ip = ((u32)ip->src_ip[0] << 24) | ((u32)ip->src_ip[1] << 16)
               | ((u32)ip->src_ip[2] << 8) | (u32)ip->src_ip[3];

    /* Check for passive LISTEN first — if incoming SYN on a listening port */
    if ((flags & TCP_SYN) && !(flags & TCP_ACK)) {
        for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
            if (!g_tcp_listens[li].in_use) continue;
            if (g_tcp_listens[li].port != dst_port) continue;

            /* FIX сессия 7 (двойной accept): повторный SYN (ретрансмиссия
             * клиента после потери нашего SYN-ACK) раньше создавал ВТОРОЙ
             * сокет того же соединения: handshake завершался по одному
             * сокету, а данные матчились в ДРУГОЙ (с чужим seq) —
             * «сервер не отвечает». Теперь повторный SYN только повторяет
             * SYN-ACK на УЖЕ существующем сокете. */
            for (int j = 0; j < NET_MAX_TCP_SOCKETS; j++) {
                net_tcp_socket_t *es = &g_tcp_socks[j];
                if (!es->in_use) continue;
                if (es->local_port != dst_port) continue;
                if (es->remote_ip != src_ip) continue;
                if (es->remote_port != src_port) continue;
                if (es->state == TCP_SYN_RECEIVED || es->state == TCP_ESTABLISHED) {
                    tcp_send_segment(es, TCP_SYN | TCP_ACK, NULL, 0);
                    return;
                }
            }

            /* Accept connection — find a free socket */
            int si = -1;
            for (int j = 0; j < NET_MAX_TCP_SOCKETS; j++) {
                if (tcp_slot_free(j)) { si = j; break; }   /* [PIN] */
            }
            if (si < 0) {
                /* No free sockets — send RST */
                net_tcp_socket_t tmp;
                memset(&tmp, 0, sizeof(tmp));
                tmp.local_ip = net_get_ip();
                tmp.local_port = dst_port;
                tmp.remote_ip = src_ip;
                tmp.remote_port = src_port;
                tmp.ack = seq + 1;
                tcp_send_segment(&tmp, TCP_RST | TCP_ACK, NULL, 0);
                return;
            }
            /* Create new socket in SYN_RECEIVED state */
            net_tcp_socket_t *s = &g_tcp_socks[si];
            s->in_use = 1;
            /* [C-STATE] [GEN]: живое состояние сразу после захвата
             * (см. net_tcp_connect) — SYN_RECEIVED даёт таймеру лимит
             * 15 с на завершение handshake. */
            g_tcp_gen[si]++;
            s->state = TCP_SYN_RECEIVED;
            s->local_ip = net_get_ip();
            s->local_port = dst_port;
            s->remote_ip = src_ip;
            s->remote_port = src_port;
            s->seq = g_tcp_next_isn;
            g_tcp_next_isn += 64000;
            s->ack = seq + 1;
            s->mss = 1460;
            s->window_scale = 0;
            s->retransmit_seq = 0;
            s->retransmit_count = 0;
            s->retrans_len = 0;
            s->was_reset = 0;
            s->peer = -1;
            s->recv_cb = g_tcp_listens[li].recv_cb;  /* per-socket приём */
            {
                extern void serial_puts(const char *);
                char b[80];
                snprintf(b, sizeof(b), "[tcp] accept idx=%d isn=%u from %08x:%u\n",
                         si, (unsigned)s->seq, (unsigned)src_ip, (unsigned)src_port);
                serial_puts(b);
            }
            /* Parse peer's TCP options (MSS, WS, SACK-permitted) */
            if (opts_len > 0) parse_tcp_options(opts, opts_len, s);
            /* Send SYN-ACK */
            tcp_send_segment(s, TCP_SYN | TCP_ACK, NULL, 0);
            s->seq += 1;  /* SYN consumes 1 seq */
            s->state = TCP_SYN_RECEIVED;
            /* Note: callback is called when handshake completes (ESTABLISHED) */
            return;
        }
    }

    /* Find matching socket */
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        net_tcp_socket_t *s = &g_tcp_socks[i];
        if (!s->in_use) continue;
        if (s->remote_ip != src_ip) continue;
        if (s->remote_port != src_port) continue;
        if (s->local_port != dst_port) continue;

        /* FIX [TCP-R2]: RST в ЛЮБОМ состоянии означает, что соединения
         * больше нет. Раньше сегмент с RST молча игнорировался в
         * TCP_ESTABLISHED: клиент висел до полного таймаута
         * («response timeout» при живом отказе сервера/шлюза — так
         * выглядел «пропавший ответ» в браузере). */
        if (flags & TCP_RST) {
            /* Сессия 53: КТО сбросил соединение. TTL подсказывает
             * источник: ~64 — наша же сеть (роутер/фильтр/локальная
             * машина), заметно меньше — интернет-хост за NAT. */
            {
                extern void serial_puts(const char *);
                char ipb[20], msg[96];
                net_ntoa(src_ip, ipb, sizeof(ipb));
                snprintf(msg, sizeof(msg),
                         "[tcp] RST from %s ttl=%u (%08x:%u)\n",
                         ipb, ip->ttl, (unsigned)src_ip, (unsigned)src_port);
                serial_puts(msg);
            }
            s->was_reset = 1;
            s->retrans_len = 0;
            /* сессия 56: запомнить источник для net_tcp_rst_info() */
            s->rst_ip = src_ip;
            s->rst_port = src_port;
            s->rst_ttl = ip->ttl;
            s->state = TCP_CLOSED;
            return;
        }

        switch (s->state) {
            case TCP_SYN_SENT:
                /* Wait for SYN-ACK */
                if ((flags & (TCP_SYN | TCP_ACK)) == (TCP_SYN | TCP_ACK)) {
                    s->ack = seq + 1;
                    /* Parse peer's options */
                    if (opts_len > 0) parse_tcp_options(opts, opts_len, s);
                    /* Send ACK */
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                    s->state = TCP_ESTABLISHED;
                    s->retransmit_seq = 0;  /* SYN-ACK received */
                } else if (flags & TCP_RST) {
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_SYN_RECEIVED:
                /* Wait for ACK to complete 3-way handshake */
                if (flags & TCP_ACK) {
                    s->state = TCP_ESTABLISHED;
                    s->retransmit_seq = 0;
                    /* Call accept callback */
                    for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
                        if (g_tcp_listens[li].in_use &&
                            g_tcp_listens[li].port == dst_port &&
                            g_tcp_listens[li].cb) {
                            g_tcp_listens[li].cb(i, src_ip, src_port);
                            break;
                        }
                    }
                    /* If data came with the ACK, process it */
                    if (data_len > 0) {
                        s->ack = seq + data_len;
                        if (s->recv_cb)
                            s->recv_cb(i, src_ip, src_port, data, data_len);
                        else if (g_tcp_recv_cb)
                            g_tcp_recv_cb(i, src_ip, src_port, data, data_len);
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    }
                }
                return;
            case TCP_ESTABLISHED:
                /* Clear retransmit on ACK */
                if ((flags & TCP_ACK) && s->retransmit_seq != 0 &&
                    ack >= s->retransmit_seq) {
                    s->retransmit_seq = 0;
                    s->retransmit_count = 0;
                    s->retrans_len = 0;   /* FIX [TCP-R1]: данные подтверждены */
                }
                if (data_len > 0) {
                    /* FIX [T-ord]: приём ТОЛЬКО сегментов по порядку.
                     * Раньше принимался ЛЮБОЙ сегмент: повторная передача
                     * сервера (наш ACK потерялся — обычное дело на реальной
                     * сети) продублировала данные в буфер HTTP-клиента,
                     * а дыра в последовательности пропускалась молча —
                     * браузер получал битый ответ. Теперь:
                     *   seq == s->ack         — новый сегмент, принять;
                     *   seq+len <= s->ack     — старый дубль, повторный ACK;
                     *   seq > s->ack          — дыра, ACK текущего
                     *                           (сервер перешлёт сегмент). */
                    if (seq == s->ack) {
                        s->ack = seq + data_len;
                        if (s->recv_cb)
                            s->recv_cb(i, src_ip, src_port, data, data_len);
                        else if (g_tcp_recv_cb)
                            g_tcp_recv_cb(i, src_ip, src_port, data, data_len);
                        /* Send ACK */
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    } else {
                        /* дубль или дыра — подтверждаем текущий ack */
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    }
                }
                if (flags & TCP_FIN) {
                    /* [TCP-FINHOLE] FIX (критический): FIN принимаем
                     * только БЕЗ дыр в данных — seq+data_len == s->ack
                     * (всё до FIN получено). Прежде s->ack ставился НА
                     * FIN (fin_ack) даже при дыре: сервер считал ВСЁ
                     * доставленным и больше не ретранслировал, а
                     * ретрансмиссия потерянного сегмента отбрасывалась
                     * (состояние уже LAST_ACK). Ответ навсегда
                     * обрезался: «сервер закрыл соединение, принято
                     * 144 б» на ya.ru/локальных серверах, при потере
                     * сегмента в burst (кольцо NIC 32×2048 б при
                     * медленной отрисовке внутри колбэка приёма). */
                    if (seq + data_len == s->ack) {
                        /* FIN: подтверждаем ВПЕРЁД */
                        s->ack = seq + data_len + 1;
                        /* [TCP-CLOSEWAIT] FIX (критический): пассивное
                         * закрытие — ESTABLISHED -> CLOSE_WAIT, БЕЗ
                         * немедленного своего FIN. Прежде стек тут же
                         * отвечал ACK|FIN и уходил в LAST_ACK, из-за
                         * чего net_tcp_send (строго ESTABLISHED) отказывал
                         * ЛЮБУЮ отправку после FIN сервера: TLS-сценарий
                         * CDN «alert + FIN посреди сессии» (сервер шлёт
                         * close_notify/ответ и закрывает свою сторону,
                         * наш close_notify уже не проходил — фатальный
                         * каскад «tcp send failed»), а ответ после FIN
                         * (полуоткрытая запись) не досылался. По RFC 793
                         * в CLOSE_WAIT приложение ещё МОЖЕТ слать данные;
                         * свой FIN уходит только из net_tcp_close()
                         * (CLOSE_WAIT -> LAST_ACK — ветка ниже в close). */
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                        s->state = TCP_CLOSE_WAIT;
                    } else {
                        /* дыра/старый дубль FIN: обычный ACK текущей
                         * позиции — сервер ретранслирует данные (RTO),
                         * FIN придёт повторно и закроет соединение */
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    }
                }
                return;
            case TCP_FIN_WAIT_1:
                /* Got ACK for our FIN? */
                if ((flags & TCP_ACK) && ack == s->seq) {
                    s->state = TCP_FIN_WAIT_2;
                }
                if (flags & TCP_FIN) {
                    s->ack = seq + data_len + 1;
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                    s->state = TCP_TIME_WAIT;
                    /* No TIME_WAIT duration in this simple impl — close */
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_LAST_ACK:
                /* Wait for ACK of our FIN */
                if ((flags & TCP_ACK) && ack == s->seq) {
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_CLOSE_WAIT:
                /* [TCP-CLOSEWAIT]: мы уже подтвердили FIN пира (и можем
                 * ещё ДОСЫЛАТЬ свои данные). Повторный FIN/дубль сегмента
                 * здесь — потерялся наш ACK: подтверждаю ещё раз, данные
                 * после FIN не принимаю. */
                if (flags & TCP_FIN)
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                return;
            default:
                return;
        }
    }
    /* No matching socket — if SYN, send RST (we don't accept incoming connections) */
    if (flags & TCP_SYN) {
        /* Send RST */
        net_tcp_socket_t tmp;
        memset(&tmp, 0, sizeof(tmp));
        tmp.local_ip = net_get_ip();
        tmp.local_port = dst_port;
        tmp.remote_ip = src_ip;
        tmp.remote_port = src_port;
        tmp.seq = 0;
        tmp.ack = seq + (data_len > 0 ? data_len : 0) + ((flags & (TCP_SYN | TCP_FIN)) ? 1 : 0);
        tcp_send_segment(&tmp, TCP_RST | TCP_ACK, NULL, 0);
    }
    /* FIX (сессия 57): RST, к которому НЕ нашлось сокета, раньше молча
     * игнорировался — «connection refused» в логе выглядел беспричинным
     * (RST приходил, но его источник/порт не совпадали с 4-tuple нашего
     * сокета: чужой MAC в ARP-кэше, ротация портов, RST от роутера/точки
     * доступа). Теперь видно КТО и КУДА шлёт сброс — сравниваем с dst
     * из строки «[tcp] connect». */
    else if (flags & TCP_RST) {
        extern void serial_puts(const char *);
        char ipb[20], msg[112];
        net_ntoa(src_ip, ipb, sizeof(ipb));
        snprintf(msg, sizeof(msg),
                 "[tcp] RST from %s:%u ttl=%u — нет сокета (несовпал 4-tuple)\n",
                 ipb, (unsigned)src_port, (unsigned)ip->ttl);
        serial_puts(msg);
    }
}
