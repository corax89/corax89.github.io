/* net_http.c — простой HTTP/1.0 клиент для N2600-OS (+ трассировка).
 *
 * Реализован только метод GET. Запрос:
 *   GET <path> HTTP/1.0\r\n
 *   Host: <hostname>\r\n
 *   User-Agent: N2600-OS/0.1\r\n
 *   Connection: close\r\n
 *   \r\n
 *
 * Транзакция завершается, когда:
 *   - сервер закрыл соединение (FIN) — классический HTTP/1.0 путь;
 *   - получено тело целиком по Content-Length (многие HTTP/1.1-серверы
 *     держат соединение открытым — раньше клиент ждал таймаут 10 с);
 *   - наступила «тишина»: 1.5 с без новых данных (сервер молчит,
 *     но соединение держит) — раньше это тоже висело до таймаута.
 *
 * net_http_get_traced() дополнительно заполняет http_trace_t: точные
 * байты запроса, сырой ответ и тайминги фаз (DNS/ARP/connect/recv) —
 * приложение HTTP Trace показывает, на какой стадии запрос отвалился.
 */
#include "net.h"
#include "net_tls.h"
#include "sync.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "gunzip.h"     /* Task 67 [HTTP-GZIP]: распаковка ответов сервера */

extern void serial_puts(const char *s);
extern void net_poll(void);

/* Буфер для накопления HTTP-ответа */
static char *g_http_buf = NULL;
static u32   g_http_buf_len = 0;
static u32   g_http_buf_max = 0;
static int   g_http_sock = -1;
static int   g_http_done = 0;

/* Анализ ответа: где кончаются заголовки и каков Content-Length.
 * Заполняется по мере поступления данных (http_tcp_recv). */
static int   g_hdr_end = -1;        /* индекс '\n' последней строки заголовка + 1 */
static u32   g_content_length = 0;  /* 0 = неизвестен */
static int   g_have_content_length = 0;
/* Task 60 [HTTP-TRUNC]: 1 = ответ НЕ влез в буфер вызывающего
 * (break при g_http_buf_len >= max-1). Раньше n == max-1 был
 * неотличим от «сервер сам прислал столько» — браузер молча терял
 * хвост (п. 1.1 разбора Task 60). */
static int   g_http_truncated = 0;

/* FIX [HTTP-CHUNKED] (Task 65): декодер Transfer-Encoding: chunked.
 * Прежде клиент HTTP/1.0 получал chunked-ответ КАК ЕСТЬ: тело было
 * перемешано с hex-размерами чанков ("2000\r\n<данные>\r\n..."),
 * github.com (и многие CDN) отвечают chunked даже HTTP/1.0-клиенту —
 * браузер показывал мусор. Теперь тело декодируется НА ЛЕТУ:
 * состояние — внутри http_tcp_recv (см. ch_feed):
 *   CH_SIZE   читаем hex-строку размера (до '\n'; расширения после ';'
 *             игнорируем), 0 = конец (далее trailer-блок);
 *   CH_DATA   отдаём g_ch_rem байт тела в буфер вызывающего;
 *   CH_CRLF   съедаем '\r'/'\n' после чанка (терпимы лишние);
 *   CH_TRAIL  съедаем trailer-строки до ПУСТОЙ (конец ответа,
 *             g_http_done=1). Обрыв соединения тоже завершает.
 * g_chunked: 0 = не chunked, 1 = декодируем, -1 = протокол сломан
 * (глотаем остаток молча — лучше, чем мусор на экране).
 * Буфер вызывающего: [заголовки][декодированное тело] — декодер
 * пишется поверх сырых байтов (вывод <= входа, вперёд безопасно). */
#define CH_SIZE  0
#define CH_DATA  1
#define CH_CRLF  2
#define CH_TRAIL 3
static int  g_chunked = 0;
static int  g_ch_state = CH_SIZE;
static u32  g_ch_rem = 0;        /* осталось байт текущего чанка */
static char g_ch_line[24];       /* hex-строка размера */
static u32  g_ch_line_len = 0;
static int  g_ch_sol = 1;        /* начало строки trailer-блока */

/* Task 68 [HTTP-STREAM]: режим потоковой выдачи тела. Вместо
 * накопления в g_http_buf каждый ДЕКОДИРОВАННЫЙ байт отдаётся
 * колбэку g_stream_sink (chunked) / напрямую (не-chunked). NULL =
 * обычный буферизованный режим (curl/imgsvc/httpd/POST — как было).
 * Объявления ЗДЕСЬ — внутри вырезки generated_chunked.inc, чтобы
 * ch_put_out (ниже) компилировался и в хост-тесте. */
static int (*g_stream_sink)(void *ud, const char *data, u32 len) = NULL;
static void *g_stream_ud = NULL;
static int   g_stream_aborted = 0;

static int  g_chunk_end = 0;     /* пустая строка trailer видена */

/* Текущая трассировка (NULL = обычный вызов без записи) */
static http_trace_t *g_trace = NULL;
static u32 g_http_t0 = 0;       /* тик старта транзакции (для t_first_ms) */

/* Текст последней ошибки (для браузера/терминала). FIX [N1d]: раньше все
 * сбои возвращали -1 без объяснений — «Ошибка запроса (код -1)»
 * не помогал диагностике. */
static char g_http_err[48] = "ok";

/* ================ Task 67 [HTTP-COOKIE]: простая cookie-банка ================
 * Сессионные cookies (без Expires/Max-Age — живут до перезагрузки ОС):
 *   - Set-Cookie ответов разбирается ПОСЛЕ приёма (host уже известен);
 *   - запросы получают Cookie: name=value; ... для совпадающих
 *     домена (точное или поддомен) и пути (path-match RFC 6265).
 * Атрибуты Secure/HttpOnly/SameSite игнорируются (нечего защищать:
 * TLS-канал один и тот же для всех, скриптового доступа к документу
 * из JS-движка страницы нет). */
#define HTTP_JAR_MAX 24
#define HTTP_COOKIE_DOMAIN_MAX 64
#define HTTP_COOKIE_PATH_MAX   32
#define HTTP_COOKIE_NAME_MAX   32
#define HTTP_COOKIE_VALUE_MAX  96
typedef struct {
    int  used;
    char domain[HTTP_COOKIE_DOMAIN_MAX];   /* без ведущей точки */
    char path[HTTP_COOKIE_PATH_MAX];       /* всегда начинается с '/' */
    char name[HTTP_COOKIE_NAME_MAX];
    char value[HTTP_COOKIE_VALUE_MAX];
} http_cookie_t;
static http_cookie_t g_jar[HTTP_JAR_MAX];
static int           g_jar_rr = 0;      /* ротация вытеснения */

/* Cookie применима к (host, path)? 1 = да. */
static int http_cookie_match(const http_cookie_t *c,
                             const char *host, const char *path)
{
    /* домен: точное совпадение или host.endsWith("."+domain) */
    if (c->domain[0]) {
        int dl = (int)strlen(c->domain);
        int hl = (int)strlen(host);
        if (hl < dl) return 0;
        if (hl > dl) {
            if (host[hl - dl - 1] != '.') return 0;
            if (strcmp(host + hl - dl, c->domain) != 0) return 0;
        } else if (strcmp(host, c->domain) != 0) {
            return 0;
        }
    }
    /* путь: path == cpath, либо path начинается с cpath и граница — '/' */
    if (c->path[0]) {
        int pl = (int)strlen(c->path);
        if (strncmp(path, c->path, (u32)pl) != 0) return 0;
        if (path[pl] != 0 && path[pl] != '/' &&
            !(pl > 0 && c->path[pl - 1] == '/')) return 0;
    }
    return 1;
}

static void http_jar_put(const char *domain, const char *path,
                         const char *name, const char *value)
{
    int free_slot = -1;
    /* обновить существующую (domain+path+name) */
    for (int i = 0; i < HTTP_JAR_MAX; i++) {
        if (!g_jar[i].used) {
            if (free_slot < 0) free_slot = i;
            continue;
        }
        if (!strcmp(g_jar[i].domain, domain) &&
            !strcmp(g_jar[i].path, path) &&
            !strcmp(g_jar[i].name, name)) {
            strncpy(g_jar[i].value, value, sizeof(g_jar[i].value) - 1);
            g_jar[i].value[sizeof(g_jar[i].value) - 1] = 0;
            return;
        }
    }
    int slot = free_slot;
    if (slot < 0) {
        slot = g_jar_rr % HTTP_JAR_MAX;
        g_jar_rr++;
    }
    http_cookie_t *c = &g_jar[slot];
    memset(c, 0, sizeof(*c));
    c->used = 1;
    strncpy(c->domain, domain, sizeof(c->domain) - 1);
    strncpy(c->path, path, sizeof(c->path) - 1);
    strncpy(c->name, name, sizeof(c->name) - 1);
    strncpy(c->value, value, sizeof(c->value) - 1);
}

/* Сравнение начала строки без учёта регистра (локальный helper банки). */
static int br_ci_starts(const char *s, const char *pre, int n)
{
    for (int i = 0; i < n; i++) {
        char a = s[i], b = pre[i];
        if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
        if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
        if (a != b) return 0;
    }
    return 1;
}

/* Task 67 [HTTP-GZIP]: Content-Encoding: gzip в заголовках [0, hdr_end)?
 * Ключ обязан начинаться с НАЧАЛА СТРОКИ (как [TE-ANCHOR]) — иначе
 * сработал бы внутри значений других заголовков. */
static int http_detect_gzip(const char *hdrs, int hdr_end)
{
    for (int i = 0; i + 18 < hdr_end; i++) {
        if (i > 0 && hdrs[i - 1] != '\n') continue;
        if (!br_ci_starts(hdrs + i, "content-encoding:", 17)) continue;
        const char *v = hdrs + i + 17;
        const char *e = hdrs + hdr_end;
        while (v < e && (*v == ' ' || *v == '\t')) v++;
        return (v + 4 <= e && br_ci_starts(v, "gzip", 4));
    }
    return 0;
}

/* ═══════════════ Task 68 [HTTP-STREAM] ═══════════════
 * Потоковый приём: тело (после декодирования chunked, а для gzip —
 * после распаковки В КОНЦЕ приёма) отдаётся колбэку вызывателя.
 * g_http_buf в этом режиме — буфер ЗАГОЛОВКОВ (16 КиБ: ya.ru шлёт
 * до ~6 КиБ); тело в нём не задерживается. Пределы: сжатый ответ
 * больше GZ_STREAM_ACC_MAX — честный отказ (не молчаливая обрезка). */
#define GZ_STREAM_ACC_MAX (3u * 1024u * 1024u)
#define GZ_STREAM_OUT_MAX (6u * 1024u * 1024u)
#define HTTP_HDRBUF_MAX   (16u * 1024u)
static char             g_hdrbuf[HTTP_HDRBUF_MAX];
static net_http_hdr_fn  g_stream_hdr_cb = NULL;
static void            *g_stream_hdr_ud = NULL;
static int              g_stream_hdr_called = 0;
static u32              g_stream_raw_got = 0;    /* сырых байт тела пришло */
static u32              g_stream_delivered = 0;  /* отдано колбэку тела */
static int              g_gz_mode = 0;           /* приёмник — накопитель gzip:
                                                  * в delivered НЕ считается
                                                  * (сжатые байты — не для
                                                  * вызывателя) */
static gz_u8           *g_gz_acc = NULL;         /* накопитель gzip */
static u32              g_gz_len = 0, g_gz_cap = 0;
/* [HTTP-LASTSTAT] FIX: значения ПОСЛЕДНЕЙ ЗАВЕРШЁННОЙ транзакции.
 * Прежде net_http_raw_received()/net_http_content_length() читали
 * «живые» g_stream_raw_got/g_content_length ПОСЛЕ выхода из запроса,
 * а HTTP_TXN_DETACH (вызывается при каждом выходе) их ОБНУЛЯЛ —
 * браузер всегда показывал «сеть 0 КБ» и «получено 0» и не мог
 * отличить полный ответ от обрыва по длине. */
static u32              g_last_raw_got = 0;
static u32              g_last_content_length = 0;

static void http_err(const char *msg);   /* fwd (определена ниже) */

/* Код статуса из начала ответа ("HTTP/1.1 200 OK" -> 200). */
static int http_status_code(const char *buf, u32 n)
{
    if (n < 12 || memcmp(buf, "HTTP/", 5) != 0) return 0;
    const char *p = buf + 5;
    const char *e = buf + n;
    while (p < e && *p != ' ') p++;
    while (p < e && *p == ' ') p++;
    int v = 0, ok = 0;
    while (p < e && *p >= '0' && *p <= '9' && v < 1000) {
        v = v * 10 + (*p - '0');
        p++;
        ok = 1;
    }
    return ok ? v : 0;
}

/* Приёмник gzip: копит СЖАТЫЙ ответ до конца транзакции. */
static int http_gz_sink(void *ud, const char *data, u32 len)
{
    (void)ud;
    if (g_gz_len + len > GZ_STREAM_ACC_MAX) {
        http_err("gzip: сжатых > 3 МиБ");
        return -1;
    }
    if (g_gz_len + len > g_gz_cap) {
        u32 ncap = g_gz_cap ? g_gz_cap : 65536;
        while (ncap < g_gz_len + len) ncap *= 2;
        gz_u8 *np = (gz_u8 *)malloc(ncap);
        if (!np) {
            http_err("gzip: нет памяти под накопитель");
            return -1;
        }
        if (g_gz_acc) {
            memcpy(np, g_gz_acc, g_gz_len);
            free(g_gz_acc);
        }
        g_gz_acc = np;
        g_gz_cap = ncap;
    }
    memcpy(g_gz_acc + g_gz_len, data, len);
    g_gz_len += len;
    return 0;
}

/* CL-ответ получен целиком (потоковый режим, не chunked).
 * FIX [HTTP-HDRCB-LOG]:Diagnostic в serial — раньше в потоке завершение
 * по CL было невидимо (лог был только в буферизованном пути), и «ответ
 * пришёл целиком» нельзя было отличить от обрыва. */
static void http_stream_cl_check(void)
{
    if (!g_chunked && g_stream_raw_got > 0 && g_have_content_length &&
        g_hdr_end >= 0 && g_stream_raw_got >= g_content_length) {
        if (!g_http_done) {
            char b[80];
            snprintf(b, sizeof(b),
                     "[http] recv: Content-Length выполнен (%u б)\n",
                     (unsigned)g_stream_raw_got);
            serial_puts(b);
        }
        g_http_done = 1;
    }
}

u32 net_http_raw_received(void)
{
    /* [HTTP-LASTSTAT]: честные цифры последней завершённой транзакции
     * (внутри идущей транзакции это значение ещё старое — колбэки
     * считают прогресс по своим локальным счётчикам). */
    return g_last_raw_got;
}

/* Разобрать заголовки [0, hdr_end) сырого ответа и сложить Set-Cookie
 * в банку. Атрибут Path/Domain учитываются; без Domain — host запроса
 * (по RFC 6265 host-only). */
static void http_store_cookies(const char *host, const char *hdrs, int hdr_end)
{
    int p = 0;
    while (p < hdr_end) {
        int eol = p;
        while (eol < hdr_end && hdrs[eol] != '\n') eol++;
        int linelen = eol - p;
        if (linelen > 11 && br_ci_starts(hdrs + p, "set-cookie:", 11)) {
            const char *v = hdrs + p + 11;
            const char *ve = hdrs + eol;
            while (v < ve && (*v == ' ' || *v == '\t')) v++;
            /* av-pair: NAME=VALUE до ';' */
            const char *eq = v;
            while (eq < ve && *eq != '=' && *eq != ';') eq++;
            if (eq < ve && *eq == '=') {
                char name[HTTP_COOKIE_NAME_MAX];
                char value[HTTP_COOKIE_VALUE_MAX];
                int nl = (int)(eq - v);
                if (nl > 0 && nl < (int)sizeof(name)) {
                    memcpy(name, v, (u32)nl); name[nl] = 0;
                    int vn = 0;
                    const char *vp = eq + 1;
                    while (vp < ve && *vp != ';' &&
                           vn < (int)sizeof(value) - 1)
                        value[vn++] = *vp++;
                    while (vn > 0 && (value[vn-1] == ' ' || value[vn-1] == '\r'))
                        vn--;
                    value[vn] = 0;
                    /* атрибуты: Path=/x Domain=y (регистр без учёта) */
                    char domain[HTTP_COOKIE_DOMAIN_MAX];
                    char path[HTTP_COOKIE_PATH_MAX];
                    strncpy(domain, host, sizeof(domain) - 1);
                    domain[sizeof(domain) - 1] = 0;
                    strncpy(path, "/", sizeof(path) - 1);
                    const char *ap = vp;
                    while (ap < ve) {
                        while (ap < ve && (*ap == ';' || *ap == ' ' || *ap == '\r')) ap++;
                        const char *ase = ap;
                        while (ase < ve && *ase != ';') ase++;
                        int alen = (int)(ase - ap);
                        if (alen > 5 && br_ci_starts(ap, "path=", 5)) {
                            const char *pv = ap + 5;
                            int pe = alen;
                            while (pe > 5 && (ap[pe-1] == ' ' || ap[pe-1] == '\r')) pe--;
                            int pn = pe - 5;
                            if (pn > 0 && pn < (int)sizeof(path) && pv[0] == '/') {
                                memcpy(path, pv, (u32)pn); path[pn] = 0;
                            }
                        } else if (alen > 7 && br_ci_starts(ap, "domain=", 7)) {
                            const char *dv = ap + 7;
                            int de = alen;
                            while (de > 7 && (ap[de-1] == ' ' || ap[de-1] == '\r')) de--;
                            int dn = de - 7;
                            if (dn > 0 && dn < (int)sizeof(domain)) {
                                if (*dv == '.') { dv++; dn--; }
                                if (dn > 0) {
                                    memcpy(domain, dv, (u32)dn); domain[dn] = 0;
                                }
                            }
                        }
                        ap = ase;
                    }
                    http_jar_put(domain, path, name, value);
                }
            }
        }
        p = eol + 1;
    }
}

/* Записать "Cookie: k=v; ...\r\n" в buf (если есть что) — длина приписки. */
static int http_cookie_header(const char *host, const char *path,
                              char *buf, int buf_max)
{
    int n = 0;
    for (int i = 0; i < HTTP_JAR_MAX; i++) {
        if (!g_jar[i].used) continue;
        if (!http_cookie_match(&g_jar[i], host, path)) continue;
        int need = (int)strlen(g_jar[i].name) + (int)strlen(g_jar[i].value) + 4;
        if (n == 0) {
            if (buf_max < 9) break;
            memcpy(buf, "Cookie: ", 8);
            n = 8;
        }
        if (n + need + 2 > buf_max) break;      /* не влезает — хватит */
        if (/* не первая пара */ n > 8) buf[n++] = ';', buf[n++] = ' ';
        n += snprintf(buf + n, (u32)(buf_max - n), "%s=%s",
                      g_jar[i].name, g_jar[i].value);
    }
    if (n > 0 && n + 2 < buf_max) {
        buf[n++] = '\r';
        buf[n++] = '\n';
        buf[n] = 0;
    }
    return n;
}

const char *net_http_errstr(void) { return g_http_err; }

/* Task 60 [HTTP-TRUNC]: Content-Length последнего ответа (0 = заголовка
 * не было/не успел прийти). Валидно сразу после net_http_get/post
 * (до старта следующей транзакции). */
u32 net_http_content_length(void)
{
    /* [HTTP-LASTSTAT]: см. net_http_raw_received() */
    return g_last_content_length;
}

/* Один байт ДЕКОДИРОВАННОГО тела в буфер вызывающего. */
static __attribute__((unused)) void ch_put_out(int c)
{
    if (g_stream_sink) {                      /* [HTTP-STREAM] */
        char b = (char)c;
        if (!g_stream_aborted &&
            g_stream_sink(g_stream_ud, &b, 1) != 0)
            g_stream_aborted = 1;
        else if (!g_gz_mode)
            g_stream_delivered += 1;   /* [HTTP-LASTDEL] */
        return;
    }
    if (g_http_truncated) return;
    if (g_http_buf_len >= g_http_buf_max - 1) {
        g_http_truncated = 1;      /* [HTTP-TRUNC] */
        return;
    }
    g_http_buf[g_http_buf_len++] = (char)c;
}

/* [HTTP-STREAM] то же ПОРЦИЕЙ (CH_DATA: без вызова колбэка на каждый
 * байт). Поведение в буферизованном режиме ИДЕНТИЧНО побайтовому
 * (границы trunc — на том же байте). */
static void ch_put_out_n(const unsigned char *src, u32 n)
{
    if (g_stream_sink) {
        if (g_stream_aborted) return;
        if (g_stream_sink(g_stream_ud, (const char *)src, n) != 0)
            g_stream_aborted = 1;
        else if (!g_gz_mode)
            g_stream_delivered += n;   /* [HTTP-LASTDEL] */
        return;
    }
    for (u32 k = 0; k < n; k++) {
        if (g_http_truncated) return;
        if (g_http_buf_len >= g_http_buf_max - 1) {
            g_http_truncated = 1;
            return;
        }
        g_http_buf[g_http_buf_len++] = (char)src[k];
    }
}

/* Протокол chunked сломан: глотаем остаток (не портим экран).
 * FIX [CH-LOG] (Task 65): раньше молча — невозможно было понять, почему
 * страница «из одной строки» (тело проглочено). Теперь причина в serial. */
static void ch_broken(void)
{
    char b[80];
    g_chunked = -1;
    g_http_done = 1;
    snprintf(b, sizeof(b),
             "[http] chunked сломан: state=%d rem=%u len=%u — тело проглочено\n",
             g_ch_state, (unsigned)g_ch_rem, (unsigned)g_http_buf_len);
    serial_puts(b);
}

/* Скормить декодеру n сырых байтов тела (после конца заголовков).
 * Читает из src, пишет в g_http_buf поверх (out <= in на каждом шаге).
 * Вызывается и для хвоста, уже лежащего в буфере (in-place), и для
 * новых сегментов. */
static void ch_feed(const unsigned char *src, u32 n)
{
    for (u32 i = 0; i < n; i++) {
        if (g_chunked != 1) return;      /* сломан/выключен — глотаем */
        int c = src[i];
        switch (g_ch_state) {
        case CH_SIZE:
            if (c == '\n') {
                g_ch_line[g_ch_line_len] = 0;
                u32 v = 0;
                int ok = (g_ch_line_len > 0);
                for (u32 k = 0; k < g_ch_line_len; k++) {
                    char h = g_ch_line[k];
                    if (h == ';' || h == ' ' || h == '\t' || h == '\r') break;
                    int dv;
                    if (h >= '0' && h <= '9')      dv = h - '0';
                    else if (h >= 'a' && h <= 'f') dv = h - 'a' + 10;
                    else if (h >= 'A' && h <= 'F') dv = h - 'A' + 10;
                    else { ok = 0; break; }
                    v = v * 16u + (u32)dv;
                    if (v > 0x00FFFFFFu) { ok = 0; break; }  /* абсурд */
                }
                g_ch_line_len = 0;
                if (!ok) { ch_broken(); return; }
                if (v == 0) {
                    g_ch_state = CH_TRAIL;
                    g_ch_sol = 1;
                } else {
                    g_ch_rem = v;
                    g_ch_state = CH_DATA;
                }
            } else if (g_ch_line_len < sizeof(g_ch_line) - 1) {
                g_ch_line[g_ch_line_len++] = (char)c;
            } else {
                ch_broken();           /* строка размера не по формату */
                return;
            }
            break;

        case CH_DATA: {
            u32 avail = n - i;
            u32 take = avail < g_ch_rem ? avail : g_ch_rem;
            ch_put_out_n(src + i, take);   /* [HTTP-STREAM] порцией */
            i += take;
            g_ch_rem -= take;
            /* 'i' указывает на байт ПОСЛЕ чанка; for-инкремент сдвинет ещё
             * на 1 — компенсируем: если следующий байт существует,
            * это '\r'/'\n' — его обработает CH_CRLF, поэтому откат. */
            if (take > 0) i--;
            if (g_ch_rem == 0) g_ch_state = CH_CRLF;
            break;
        }

        case CH_CRLF:
            /* после данных чанка ждём CRLF; терпимы '\r', пустые... нет:
             * строго '\r' или '\n' (лишний CR игнорируем, LF завершает) */
            if (c == '\n') g_ch_state = CH_SIZE;
            /* '\r' просто пропускаем */
            break;

        case CH_TRAIL:
            /* trailer-блок: строки "Name: value" до ПУСТОЙ. '\r' игнорируем,
             * '\n' завершает строку: пустая = конец ответа. */
            if (c == '\r') break;
            if (c == '\n') {
                if (g_ch_sol) {           /* строка была пустой */
                    g_chunk_end = 1;
                    g_http_done = 1;
                    return;
                }
                g_ch_sol = 1;             /* новая строка */
            } else {
                g_ch_sol = 0;             /* внутри строки-трейлера */
            }
            break;
        }
    }
}

/* Обнаружить Transfer-Encoding: chunked в разобранных заголовках
 * [0, g_hdr_end). Вызывается ОДИН раз — при первом нахождении конца
 * заголовков.
 * FIX [TE-ANCHOR] (Task 65): раньше "Transfer-Encoding:" искался В ЛЮБОМ
 * месте блока заголовков — в том числе ВНУТРИ ЗНАЧЕНИЙ других заголовков
 * (Access-Control-Allow-Headers: ..., Transfer-Encoding и т.п.) и в
 * echoed-заголовках страниц-ошибок. Ложное обнаружение на НЕ-chunked
 * ответе приводит к ch_broken() на первом же байте тела ("<!DOCT" —
 * не hex) — тело глотается ЦЕЛИКОМ, браузер показывает пустую страницу
 * ("строк: 1") с флагом «обрезано». Теперь ключ обязан начинаться с
 * НАЧАЛА СТРОКИ (позиция 0 или сразу после '\n'). */
static void http_detect_chunked(void)
{
    if (g_chunked || g_hdr_end < 0 || !g_http_buf) return;
    const char *hl[] = { "Transfer-Encoding:", "transfer-encoding:" };
    for (int k = 0; k < 2 && !g_chunked; k++) {
        u32 L = (u32)strlen(hl[k]);
        for (int i = 0; i + (int)L < g_hdr_end; i++) {
            if (i > 0 && g_http_buf[i - 1] != '\n') continue;   /* [TE-ANCHOR] */
            if (memcmp(g_http_buf + i, hl[k], L) != 0) continue;
            /* значение до конца строки, без учёта регистра ищем "chunked" */
            const char *v = g_http_buf + i + L;
            const char *e = g_http_buf + g_hdr_end;
            const char *nl = v;
            while (nl < e && *nl != '\n') nl++;
            for (const char *p = v; p + 6 < nl; p++) {
                char a = p[0], b = p[1], c2 = p[2], d = p[3], e2 = p[4], f = p[5], g = p[6];
                if (a == 'c' || a == 'C') {
                    if ((b|0x20)=='h' && (c2|0x20)=='u' && (d|0x20)=='n' &&
                        (e2|0x20)=='k' && (f|0x20)=='e' && (g|0x20)=='d') {
                        g_chunked = 1;
                        serial_puts("[http] TE: chunked — тело декодируем на лету\n");
                        break;
                    }
                }
            }
            break;
        }
    }
}

/* Task 60 [HTTP-TRUNC]: 1 = последний ответ обрезан по лимиту буфера
 * вызывающего — получено max-1 байт, хвост потерян. */
int net_http_truncated(void)
{
    return g_http_truncated;
}

static void http_err(const char *msg);   /* fwd: определена ниже */

/* Сессия 56: отказ с ИСТОЧНИКОМ RST — «connection refused (RST
 * 192.168.0.1 ttl=64)» прямо в статусе браузера. TTL различает
 * источник: ~64 — наша же сеть (роутер/фильтр/DNS-синкхол),
 * заметно меньше — хост в интернете за NAT. */
static void http_err_rst(const char *what, int sock)
{
    u32 rip; u16 rport; u8 rttl;
    char msg[64];
    if (net_tcp_rst_info(sock, &rip, &rport, &rttl)) {
        char ipb[20];
        net_ntoa(rip, ipb, sizeof(ipb));
        snprintf(msg, sizeof(msg), "%s (RST %s ttl=%u)",
                 what, ipb, (unsigned)rttl);
        http_err(msg);
    } else {
        http_err(what);
    }
}

static void http_err(const char *msg)
{
    strncpy(g_http_err, msg, sizeof(g_http_err) - 1);
    g_http_err[sizeof(g_http_err) - 1] = 0;
    serial_puts("[http] ");
    serial_puts(msg);
    serial_puts("\n");
    if (g_trace) {
        strncpy(g_trace->error, msg, sizeof(g_trace->error) - 1);
        g_trace->error[sizeof(g_trace->error) - 1] = 0;
    }
}

/* Сколько мс прошло от старта транзакции (сессия 33: 1 тик = 1 мс) */
static u32 ms_since(u32 start_tick)
{
    return timer_ticks() - start_tick;
}

/* Поиск конца заголовков "\r\n\r\n" и Content-Length в накопленном
 * буфере. Вызывается после каждого приёма. */
static void http_scan_headers(void)
{
    if (g_hdr_end >= 0 || !g_http_buf || g_http_buf_len == 0) return;

    /* ищем \r\n\r\n начиная с уже просмотренных позиций (буфер только
     * растёт, можно сканировать с нуля — ответы маленькие) */
    u32 n = g_http_buf_len;
    for (u32 i = 0; i + 3 < n; i++) {
        if (g_http_buf[i]     == '\r' && g_http_buf[i + 1] == '\n' &&
            g_http_buf[i + 2] == '\r' && g_http_buf[i + 3] == '\n') {
            g_hdr_end = (int)i + 4;
            break;
        }
    }
    if (g_hdr_end < 0) return;

    /* Content-Length: в заголовках (g_http_buf[0..hdr_end)) */
    const char *hl[] = { "Content-Length:", "content-length:" };
    for (int k = 0; k < 2 && !g_have_content_length; k++) {
        u32 L = (u32)strlen(hl[k]);
        for (int i = 0; i + (int)L <= g_hdr_end - 1; i++) {
            if (memcmp(g_http_buf + i, hl[k], L) == 0) {
                u32 v = 0; int ok = 0;
                const char *p = g_http_buf + i + L;
                while (p < g_http_buf + g_hdr_end && (*p == ' ' || *p == '\t')) p++;
                while (p < g_http_buf + g_hdr_end && *p >= '0' && *p <= '9') {
                    v = v * 10u + (u32)(*p - '0');
                    p++;
                    ok = 1;
                }
                if (ok) {
                    g_content_length = v;
                    g_have_content_length = 1;
                }
                break;
            }
        }
    }
}

/* TCP receive callback — копирует данные в буфер (+ копию трассировки) */
static void http_tcp_recv(int sock, u32 src_ip, u16 src_port,
                            const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    if (!data || len == 0) return;

    /* СЕССИЯ 68 (фикс порчи кучи): доставка может прийти ПОСЛЕ того,
     * как транзакция закончилась по таймауту (ответ теперь собирает
     * httpd в контексте kmain — см. net_httpd.c) и вызывающий уже
     * ОСВОБОДИЛ response-буфер. Проверяем, что данные принадлежат
     * ТЕКУЩЕЙ транзакции (живому сокету); чужие/мёртвые игнорируем. */
    if (sock != g_http_sock || g_http_sock < 0) return;
    (void)sock;

    /* первый байт ответа — время от старта транзакции (трассировка) */
    if (g_trace && g_http_buf_len == 0 && g_trace->t_first_ms == 0) {
        g_trace->t_first_ms = timer_ticks() - g_http_t0;   /* 1 тик = 1 мс */
        strncpy(g_trace->stage, "recv", sizeof(g_trace->stage) - 1);
    }

    if (!g_http_buf) return;

    /* FIX [HTTP-CHUNKED]: заголовки уже разобраны и ответ chunked —
     * новые байты идут СРАЗУ в декодер (сырые в буфер не пишутся).
     * Копия в трассировку — сырая (для диагностики чанков). */
    if (g_chunked == 1 && g_hdr_end >= 0) {
        if (g_trace && g_trace->resp_copy && g_trace->resp_max) {
            u32 rroom = g_trace->resp_max - g_trace->resp_len;
            if (rroom) {
                u32 rcopy = len < rroom ? len : rroom;
                memcpy(g_trace->resp_copy + g_trace->resp_len, data, rcopy);
                g_trace->resp_len += rcopy;
                g_trace->resp_copy[g_trace->resp_len] = 0;
            }
        }
        ch_feed((const unsigned char *)data, len);
        return;
    }

    /* Task 68 [HTTP-STREAM]: заголовки уже отданы, ответ не-chunked —
     * куски тела идут СРАЗУ в приёмник (в g_http_buf не пишутся:
     * там только заголовки). */
    if (g_stream_sink && g_hdr_end >= 0) {
        if (g_trace && g_trace->resp_copy && g_trace->resp_max) {
            u32 rroom = g_trace->resp_max - g_trace->resp_len;
            if (rroom) {
                u32 rcopy = len < rroom ? len : rroom;
                memcpy(g_trace->resp_copy + g_trace->resp_len, data, rcopy);
                g_trace->resp_len += rcopy;
                g_trace->resp_copy[g_trace->resp_len] = 0;
            }
        }
        g_stream_raw_got += len;
        if (!g_stream_aborted &&
            g_stream_sink(g_stream_ud, (const char *)data, len) != 0)
            g_stream_aborted = 1;
        else if (!g_gz_mode)
            g_stream_delivered += len;   /* [HTTP-LASTDEL]: честный rc */
        if (g_stream_aborted) g_http_done = 1;    /* колбэк прервал */
        http_stream_cl_check();
        return;
    }

    u32 room = g_http_buf_max - 1 - g_http_buf_len;   /* Task 66 [HTTP-NUL]: было max-len —
                                                      * ответ мог дорасти до max, и
                                                      * NUL-терминация затирала
                                                      * ПОСЛЕДНИЙ байт данных */
    if (room == 0) return;
    u32 copy = len < room ? len : room;
    memcpy(g_http_buf + g_http_buf_len, data, copy);
    g_http_buf_len += copy;

    /* копия сырого ответа для трассировки */
    if (g_trace && g_trace->resp_copy && g_trace->resp_max) {
        u32 rroom = g_trace->resp_max - g_trace->resp_len;
        if (rroom) {
            u32 rcopy = len < rroom ? len : rroom;
            memcpy(g_trace->resp_copy + g_trace->resp_len, data, rcopy);
            g_trace->resp_len += rcopy;
            g_trace->resp_copy[g_trace->resp_len] = 0;
        }
    }

    http_scan_headers();

    /* [HTTP-HDRCB] FIX (критический): hdr-колбэк (br_stream_hdr) был
     * СОХРАНЁН (g_stream_hdr_cb), но НЕ ВЫЗЫВАЛСЯ НИ РАЗУ — вызов потерялся
     * при интеграции потокового парсера. Итог: в потоковом режиме НЕ
     * работали редиректы (302 показывался как пустая/текстовая страница
     * вместо перехода по Location), определение Content-Type (бинарные
     * ответы — картинки/mp3 — рисовались как мусорный текст) и
     * авто-переход http->https по 400/403/426. Колбэк зовётся ОДИН раз —
     * ровно здесь, при первом найденном конце заголовков. Возврат != 0 —
     * аборт приёма (редирект/TLS-up/бинарник): хвост сегмента не
     * доставляем, транзакция завершается кодом -2. */
    if (g_stream_hdr_cb && g_hdr_end >= 0 && !g_stream_hdr_called) {
        int st = http_status_code(g_http_buf, (u32)g_hdr_end);
        g_stream_hdr_called = 1;
        if (g_stream_hdr_cb(g_stream_hdr_ud, st, g_http_buf,
                            (u32)g_hdr_end) != 0) {
            g_stream_aborted = 1;
            g_http_done = 1;
            if (g_trace)
                strncpy(g_trace->stage, "done", sizeof(g_trace->stage) - 1);
            return;
        }
    }

    /* [HTTP-GZSINK] FIX (критический): http_gz_sink существовал, но НИКОГДА
     * не подключался — сжатый ответ (Accept-Encoding: gzip) шёл колбэку
     * ВЫЗЫВАТЕЛЯ В СЖАТОМ ВИДЕ: конвертер получал бинарный мусор
     * («обрезанный код»), а распаковка в конце транзакции пропускалась
     * (накопитель пуст). Теперь при Content-Encoding: gzip приёмник
     * переключается на накопитель; в конце транзакции (см. ниже по коду)
     * тело распаковывается и отдаётся колбэку порциями. */
    if (g_stream_hdr_cb && g_hdr_end >= 0 && g_gz_acc == NULL &&
        !g_stream_aborted && http_detect_gzip(g_http_buf, (u32)g_hdr_end)) {
        g_stream_sink = http_gz_sink;
        g_gz_mode = 1;
    }

    /* FIX [HTTP-CHUNKED]: конец заголовков только что найден. Если
     * сервер отвечает chunked, хвост буфера [hdr_end..len) — СЫРОЕ
     * chunked-тело: декодируем НА МЕСТЕ (запись с позиции hdr_end,
     * вывод <= входа). Дальнейшие сегменты придут веткой выше. */
    if (g_hdr_end >= 0 && g_chunked == 0) {
        http_detect_chunked();
        if (g_chunked == 1) {
            u32 raw_body = g_http_buf_len - (u32)g_hdr_end;
            g_http_buf_len = (u32)g_hdr_end;   /* пишем с начала тела */
            g_have_content_length = 0;         /* CL с chunked не критерен */
            if (raw_body > 0)
                ch_feed((const unsigned char *)g_http_buf + g_hdr_end,
                        raw_body);
        } else if (g_stream_hdr_cb && !g_stream_aborted) {
            /* [HTTP-TAIL] FIX (критический): тело, пришедшее В ОДНОМ
             * СЕГМЕНТЕ с заголовками (маленькие/быстрые ответы — весь
             * ответ укладывается в один пакет), прежде НАВСЕГДА
             * оставалось в буфере заголовков: колбэку тела не отдавалось
             * НИЧЕГО — страница была пустой или начиналась с середины
             * («обрезанный код»). Отдаём хвост приёмнику (в потоке),
             * буфер снова держит только заголовки. */
            u32 tail = g_http_buf_len - (u32)g_hdr_end;
            if (tail > 0 && g_stream_sink) {
                g_stream_raw_got += tail;
                if (g_stream_sink(g_stream_ud, g_http_buf + (u32)g_hdr_end,
                                  tail) != 0)
                    g_stream_aborted = 1;
                else if (!g_gz_mode)
                    g_stream_delivered += tail;   /* [HTTP-LASTDEL] */
            }
            g_http_buf_len = (u32)g_hdr_end;
            if (g_stream_aborted) {
                g_http_done = 1;
                if (g_trace)
                    strncpy(g_trace->stage, "done",
                            sizeof(g_trace->stage) - 1);
                return;
            }
            http_stream_cl_check();
        }
    }

    /* Тело получено целиком по Content-Length — можно заканчивать,
     * не дожидаясь закрытия соединения (HTTP/1.1 keep-alive).
     * Для chunked длину тела знает только декодер (конец — пустая
     * trailer-строка).
     * [HTTP-TAIL]: в потоке хвост уже отдан приёмнику, буфер снова
     * держит только заголовки — «тело» здесь 0, и блок срабатывает
     * лишь для честного CL:0 (пустой ответ). Завершение по CL>0 в
     * потоке делает http_stream_cl_check(). */
    if (!g_chunked && g_have_content_length && g_hdr_end >= 0) {
        u32 body = g_http_buf_len - (u32)g_hdr_end;
        if (body >= g_content_length) {
            g_http_done = 1;
            if (g_trace) strncpy(g_trace->stage, "done", sizeof(g_trace->stage) - 1);
            {
                char b[80];
                snprintf(b, sizeof(b),
                         "[http] recv: Content-Length выполнен (%u б)\n",
                         (unsigned)g_http_buf_len);
                serial_puts(b);
            }
        }
    }
}

static void tr_set_stage(http_trace_t *tr, const char *st)
{
    if (tr) strncpy(tr->stage, st, sizeof(tr->stage) - 1);
}

/* Адаптер: расшифрованные движком TLS данные -> тот же накопитель,
 * что и у обычного HTTP (http_tcp_recv). Сигнатуры различаются. */
static void http_tls_sink(const void *data, u32 len)
{
    http_tcp_recv(g_http_sock, 0, 0, data, len);
}

static int net_http_req_impl(const char *method, const char *host, u16 port,
                             const char *path, const char *body, u32 body_len,
                             const char *content_type,
                             char *response, u32 max_len, u32 max_ms,
                             http_trace_t *tr, int allow_gzip,
                             int stream_mode,
                             net_http_hdr_fn hdr_cb, net_http_body_fn body_cb,
                             void *stream_ud)
{
    if (!host || !path) return -1;
    if (!stream_mode && (!response || max_len == 0)) return -1;
    /* Task 62 [POST-LEN]: body_len задан явно (multipart с нулями);
     * 0 = классическая strlen-семантика (urlencoded-формы). */
    if (body && body_len == 0) body_len = (u32)strlen(body);

    /* СЕССИЯ 68: завершение транзакции — отключить приёмник данных,
     * чтобы поздняя доставка (ретрансмиссия, досланный хвост ответа
     * после таймаута — теперь httpd отвечает из kmain асинхронно)
     * не писала в ОСВОБОЖДЁННЫЙ вызывающим response-буфер. Вызывается
     * перед каждым выходом net_http_get_impl. */
    #define HTTP_TXN_DETACH() do { \
        /* [HTTP-LASTSTAT]: запомнить цифры завершённой транзакции ДО \
         * обнуления — их читают net_http_raw_received()/\
         * net_http_content_length() после выхода из запроса. */ \
        g_last_raw_got = g_stream_raw_got; \
        g_last_content_length = g_have_content_length ? g_content_length : 0; \
        g_http_buf = NULL; g_http_buf_len = 0; g_http_buf_max = 0; \
        g_http_sock = -1; g_http_done = 0; g_hdr_end = -1; \
        g_content_length = 0; g_have_content_length = 0; \
        g_chunked = 0; g_ch_state = CH_SIZE; g_ch_rem = 0; \
        g_ch_line_len = 0; g_chunk_end = 0; g_ch_sol = 1; \
        g_stream_sink = NULL; g_stream_ud = NULL; g_stream_aborted = 0; \
        g_stream_hdr_cb = NULL; g_stream_hdr_ud = NULL; \
        g_stream_hdr_called = 0; \
        g_stream_raw_got = 0; g_stream_delivered = 0; g_gz_mode = 0; \
        if (g_gz_acc) { free(g_gz_acc); g_gz_acc = NULL; } \
        g_gz_len = 0; g_gz_cap = 0; \
        net_tcp_set_callback(NULL); \
    } while (0)

    strcpy(g_http_err, "ok");
    g_trace = tr;
    if (tr) {
        tr->stage[0] = 0;
        tr->error[0] = 0;
        tr->sock = -1;
        tr->syn_kicks = 0;
        tr->req_len = 0;
        tr->resp_len = 0;
        tr->t_dns_ms = 0;
        tr->t_arp_ms = 0;
        tr->t_connect_ms = 0;
        tr->t_first_ms = 0;
        tr->t_total_ms = 0;
        tr->resolved_ip = 0;
        tr->result = -1;
        if (tr->resp_copy && tr->resp_max) tr->resp_copy[0] = 0;
    }

    u32 t0 = timer_ticks();
    g_http_t0 = t0;

    /* 1. Разрешить хост → IP */
    u32 ip = 0;
    /* Сначала пробуем как IP-строку */
    if (!net_aton(host, &ip)) {
        tr_set_stage(tr, "dns");
        /* Пробуем через DNS */
        if (!net_dns_resolve(host, &ip, max_ms / 2)) {
            http_err("cannot resolve host");
            if (tr) tr->t_total_ms = ms_since(t0);
            g_trace = NULL;
            return -1;
        }
        if (tr) {
            tr->t_dns_ms = ms_since(t0);
            tr->resolved_ip = ip;
        }
        /* FIX (сессия 57): DNS-синкхол/блокировщик (AdGuard, Pi-hole,
         * провайдерский фильтр) отвечает на ЛЮБОЕ имя адресом-заглушкой:
         * 127.0.0.1 / 0.0.0.0 / broadcast. Соединение с такой заглушкой
         * давало «connection refused» без видимой причины. Теперь это
         * честная диагностика. Литерал 127.0.0.1 (loopback) не трогаем —
         * пользователь мог ввести его сам.
         * FIX (сессия 63): "localhost" сюда приходит ПО ЗАМЫСЛУ с
         * адресом 127.0.0.1 (net_dns_resolve, без DNS-сервера) — это не
         * синкхол, а loopback: раньше даже с настроенной сетью
         * http://localhost/ получал «DNS: заглушка/блокировка». */
        if (!net_host_is_loopback(host) &&
            (ip == 0 || (ip >> 24) == 127 || ip == 0xFFFFFFFFu)) {
            char ipb[20], msg[80];
            net_ntoa(ip, ipb, sizeof(ipb));
            snprintf(msg, sizeof(msg),
                     "DNS: %s — заглушка/блокировка, не хост", ipb);
            http_err(msg);
            if (tr) tr->t_total_ms = ms_since(t0);
            g_trace = NULL;
            return -1;
        }
    } else if (tr) {
        tr->resolved_ip = ip;   /* литерал: DNS не нужен */
    }

    /* 1b. FIX [N1c]: дождаться ARP (первый пакет иначе молча теряется).
     * ping повторяет запросы и потому работает; TCP-connect — нет. */
    {
        tr_set_stage(tr, "arp");
        u32 t_arp0 = timer_ticks();
        if (!net_wait_arp(ip, max_ms / 2)) {
            http_err("no ARP reply (gateway?)");
            if (tr) {
                tr->t_arp_ms = ms_since(t_arp0);
                tr->t_total_ms = ms_since(t0);
            }
            g_trace = NULL;
            return -1;
        }
        if (tr) tr->t_arp_ms = ms_since(t_arp0);
    }

    /* 2. Подготовить буфер и callback */
    if (stream_mode) {
        /* [HTTP-STREAM]: буфер только под ЗАГОЛОВКИ; тело — колбэку */
        g_http_buf = g_hdrbuf;
        g_http_buf_max = HTTP_HDRBUF_MAX;
        g_stream_hdr_cb = hdr_cb;
        g_stream_hdr_ud = stream_ud;
        g_stream_hdr_called = 0;
        g_stream_raw_got = 0;
        g_stream_delivered = 0;
        g_gz_len = 0;
        g_gz_cap = 0;
        g_gz_acc = NULL;
        g_stream_sink = body_cb;       /* до определения gzip — тело мимо */
        g_stream_ud = stream_ud;
        g_stream_aborted = 0;
        g_gz_mode = 0;
    } else {
        g_http_buf = response;
        g_stream_sink = NULL;          /* буферизованный режим */
        g_stream_ud = NULL;
        g_stream_aborted = 0;
    }
    g_http_buf_len = 0;
    g_http_buf_max = stream_mode ? HTTP_HDRBUF_MAX : max_len;
    g_http_done = 0;
    g_http_sock = -1;
    g_hdr_end = -1;
    g_content_length = 0;
    g_have_content_length = 0;
    g_http_truncated = 0;      /* [HTTP-TRUNC] */
    g_chunked = 0;             /* [HTTP-CHUNKED] */
    g_ch_state = CH_SIZE;
    g_ch_rem = 0;
    g_ch_line_len = 0;
    g_chunk_end = 0;
    g_ch_sol = 1;
    net_tcp_set_callback(http_tcp_recv);

    /* 3. TCP connect. Локальный порт — ротация: прежний сокет может
     * ещё висеть в LAST_ACK и занять тот же порт. */
    static u16 lport = 40000;
    u16 use_port = lport++;
    if (lport > 40500) lport = 40000;
    int sock = net_tcp_connect(ip, port, use_port);
    if (sock < 0) {
        http_err("cannot open TCP socket");
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }
    g_http_sock = sock;
    if (tr) tr->sock = sock;
    /* FIX (сессия 57): в serial видна КАЖДАЯ транзакция — раньше по двум
     * подряд «[tcp] connect» невозможно было понять, кто их сделал
     * (страница + редирект, страница + картинка imgsvc и т.п.). */
    {
        char b[292];
        snprintf(b, sizeof(b), "[http] GET http%s://%s:%u%s\n",
                 (port == 443) ? "s" : "", host, (unsigned)port, path);
        serial_puts(b);
    }

    /* Ждём соединения (3-way handshake) — неблокирующее.
     * FIX [N1b]: каждые 500 мс повторяем SYN, пока SYN_SENT —
     * первый SYN мог потеряться. */
    u32 start = timer_ticks();
    u32 need = max_ms / 4;               /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    u32 last_kick = timer_ticks();
    int kicks = 0;                       /* сессия 57: для диагноза таймаута */
    tr_set_stage(tr, "connect");
    while ((timer_ticks() - start) < need) {
        if (net_tcp_state(sock) == TCP_ESTABLISHED) break;
        if (net_tcp_state(sock) == TCP_CLOSED) {
            /* сессия 56: показываем КТО отказал (источник RST + ttl) */
            http_err_rst("connection refused", sock);
            if (tr) {
                tr->t_connect_ms = ms_since(start);
                tr->t_total_ms = ms_since(t0);
            }
            g_trace = NULL;
            HTTP_TXN_DETACH();
            return -1;
        }
        if (timer_ticks() - last_kick >= 500) {  /* 500 мс (1 тик = 1 мс) */
            net_tcp_kick(sock);
            kicks++;
            if (tr) tr->syn_kicks++;
            last_kick = timer_ticks();
        }
        net_poll();
        task_yield();
    }
    if (net_tcp_state(sock) != TCP_ESTABLISHED) {
        /* FIX (сессия 57): таймаут с ДЕТАЛЯМИ — состояние сокета и число
         * SYN-повторов (0 = SYN вообще не ушёл/ARP-проблема, >=2 = SYN
         * уходил, ответа нет — сеть/фаервол). */
        {
            char b[96];
            snprintf(b, sizeof(b), "connect timeout (state=%s, syn=%d)",
                     tcp_state_name(net_tcp_state(sock)), kicks);
            http_err(b);
        }
        net_tcp_close(sock);
        if (tr) {
            tr->t_connect_ms = ms_since(start);
            tr->t_total_ms = ms_since(t0);
        }
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }
    if (tr) tr->t_connect_ms = ms_since(start);

    /* 3b. TLS-рукопожатие (HTTPS). Порт 443 => шифруем сессию.
     * Сюда попадаем уже с ESTABLISHED TCP; движок BearSSL поверх. */
    int use_tls = (port == 443);
    if (use_tls) {
        tr_set_stage(tr, "tls");
        tls_set_sink(http_tls_sink);
        net_tcp_set_callback(tls_tcp_recv);
        if (!tls_start(sock, host, max_ms / 2)) {
            http_err(tls_errstr());
            if (tr) tr->t_total_ms = ms_since(t0);
            net_tcp_close(sock);
            g_trace = NULL;
            HTTP_TXN_DETACH();
            return -1;
        }
    }

    /* 4. Отправить HTTP запрос (GET или POST; Task 47 — POST для
     * форм браузера: application/x-www-form-urlencoded). Тело POST
     * отправляется ОТДЕЛЬНЫМ сегментом после заголовков (req-буфер
     * на стеке ограничен).
     * FIX [REQ-CLAMP] (Task 67): прежде буфер был 512, а каждая приписка
     * делала rl += snprintf(...) БЕЗ промежуточного клампа — длинный path
     * (Task 66 расширил до 380) + Host до 128 могли дать rl > 512 уже на
     * строке Host:, и СЛЕДУЮЩИЙ snprintf получал ОТРИЦАТЕЛЬНЫЙ размер
     * ((size_t)огромный) — запись за границей стека. Теперь 1024 байта
     * (Host+Path+Cookie) и кламп после КАЖДОЙ приписки: запрос в худшем
     * случае обрезается, но запись за буфер невозможна. */
    char req[1024];
    int rl = 0;
#define REQ_ADD(...) do { \
        if (rl >= (int)sizeof(req) - 1) break; \
        int w_ = snprintf(req + rl, (u32)(sizeof(req) - rl), __VA_ARGS__); \
        if (w_ < 0) w_ = 0; \
        rl += w_; \
        if (rl > (int)sizeof(req) - 1) rl = (int)sizeof(req) - 1; \
    } while (0)
    REQ_ADD("%s %s HTTP/1.0\r\n", method, path);
    REQ_ADD("Host: %s\r\n", host);
    REQ_ADD("User-Agent: N2600-OS/0.1\r\n");
    /* Task 67 [HTTP-COOKIE]: cookies банки, совпадающие с (host, path) */
    rl += http_cookie_header(host, path, req + rl, (int)sizeof(req) - rl);
    if (rl > (int)sizeof(req) - 1) rl = (int)sizeof(req) - 1;
    /* Task 67 [HTTP-GZIP]: сжатый ответ просит ВЫЗЫВАТЕЛЬ (net_http_get_gzip):
     * curl/imgsvc читают в маленький буфер — распаковка туда не помещается. */
    if (allow_gzip)
        REQ_ADD("Accept-Encoding: gzip\r\n");
    if (body && body_len) {
        REQ_ADD("Content-Type: %s\r\n",
                content_type && content_type[0] ? content_type
                                                : "application/x-www-form-urlencoded");
        REQ_ADD("Content-Length: %u\r\n", (unsigned)body_len);
    }
    REQ_ADD("Connection: close\r\n");
    REQ_ADD("\r\n");
#undef REQ_ADD
    if (rl < 0) rl = 0;
    if ((u32)rl > sizeof(req)) rl = (int)sizeof(req) - 1;

    /* копия точных байтов запроса для трассировки */
    if (tr && tr->req_copy && tr->req_max) {
        u32 c = (u32)rl < tr->req_max ? (u32)rl : tr->req_max - 1;
        memcpy(tr->req_copy, req, c);
        tr->req_copy[c] = 0;
        tr->req_len = (u32)rl;
    }

    int sent;
    if (use_tls) {
        sent = tls_send_all(req, (u32)rl) ? (int)rl : -1;
    } else {
        sent = net_tcp_send(sock, req, (u32)rl);
    }
    /* тело POST — порциями по MSS с ожиданием ACK (Task 62 [POST-LEN]):
     * буфер ретрансляции в стеке ОДИН (retrans_buf), слать следующий
     * сегмент можно только после подтверждения предыдущего; раньше тело
     * уходило ОДНИМ вызовом net_tcp_send — на деле уходило не больше MSS,
     * хвост молча терялся (multipart > 1460 байт не доезжал целиком). */
    if (sent >= 0 && body && body_len) {
        u32 off = 0;
        while (off < body_len) {
            if (use_tls) {
                if (!tls_send_all(body + off, body_len - off)) { sent = -1; break; }
                off = body_len;
                break;
            }
            int s2 = net_tcp_send(sock, body + off, body_len - off);
            if (s2 <= 0) { sent = -1; break; }
            off += (u32)s2;
            if (off >= body_len) break;
            /* ждём ACK предыдущего сегмента (не дольше 4 с) */
            u32 t_ack = timer_ticks();
            while (net_tcp_send_pending(sock)) {
                tcp_state_t st2 = net_tcp_state(sock);
                /* [TCP-CLOSEWAIT]: досылка тела после FIN сервера законна */
                if (st2 != TCP_ESTABLISHED && st2 != TCP_CLOSE_WAIT) {
                    sent = -1; break;
                }
                if (timer_ticks() - t_ack > 4000) { sent = -1; break; }
                net_poll();
                task_yield();
            }
            if (sent < 0) break;
            {
                tcp_state_t st3 = net_tcp_state(sock);
                if (st3 != TCP_ESTABLISHED && st3 != TCP_CLOSE_WAIT) {
                    sent = -1; break;
                }
            }
        }
    }
    if (sent < 0) {
        http_err("send failed");
        net_tcp_close(sock);
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }
    if (tr) {
        tr->req_len = (u32)sent;
        tr_set_stage(tr, "sent");
    }

    /* 5. Ждём ответ: до закрытия соединения, до полного тела по
     * Content-Length или до «тишины» 5 с (сервер молчит).
     * В TLS-режиме данные проходят через насос движка (tls_pump),
     * который расшифровывает рекорды и отдаёт plaintext в http_tls_sink. */
    start = timer_ticks();
    need = max_ms;                       /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    u32 last_data_tick = timer_ticks();
    /* [HTTP-STREAM]: прогресс приёма — сырые байты тела (буфер держит
     * только заголовки и больше не растёт после hdr_end) */
    u32 last_len = stream_mode ? g_stream_raw_got : g_http_buf_len;
    while ((timer_ticks() - start) < need) {
        if (stream_mode && g_hdr_end < 0 &&
            g_http_buf_len >= g_http_buf_max - 1) {
            http_err("заголовки > 16 КиБ");
            if (use_tls) tls_shutdown();
            net_tcp_close(sock);
            if (tr) tr->t_total_ms = ms_since(t0);
            g_trace = NULL;
            HTTP_TXN_DETACH();
            return -1;
        }
        if (!stream_mode && g_http_buf_len >= g_http_buf_max - 1) {
            g_http_truncated = 1;   /* [HTTP-TRUNC]: буфер заполнен */
            break;
        }
        if (net_tcp_state(sock) == TCP_CLOSED) {
            g_http_done = 1;
            tr_set_stage(tr, "done");
            {
                char b[80];
                snprintf(b, sizeof(b),
                         "[http] recv: сервер закрыл соединение, принято %u б\n",
                         (unsigned)g_http_buf_len);
                serial_puts(b);
            }
            break;
        }
        /* [TCP-CLOSEWAIT]/[HTTP-FINEND]: FIN сервера теперь переводит
         * сокет в CLOSE_WAIT (пассивное закрытие, наш FIN не отправлен).
         * Для HTTP/1.0 Connection: close FIN = КОНЕЦ ОТВЕТА: заканчиваем
         * сразу, а не ждём 5-секундную «тишину»/полный таймаут. Данные
         * до FIN уже доставлены колбэком (порядок TCP гарантирован). */
        if (net_tcp_state(sock) == TCP_CLOSE_WAIT) {
            /* [TLS-FLUSH]: перед выходом прокачать движок — последние
             * рекорды могли лежать в ring не расшифрованными (FIN идёт
             * ПОСЛЕ данных, но расшифровка асинхронна). */
            if (use_tls) {
                for (int i = 0; i < 8; i++) tls_pump();
            }
            g_http_done = 1;
            tr_set_stage(tr, "done");
            {
                char b[80];
                snprintf(b, sizeof(b),
                         "[http] recv: FIN сервера (CLOSE_WAIT), принято %u б\n",
                         (unsigned)g_http_buf_len);
                serial_puts(b);
            }
            break;
        }
        if (g_http_done) break;                 /* Content-Length выполнен */
        if (g_http_buf_len >= g_http_buf_max - 1) {
            g_http_truncated = 1;   /* [HTTP-TRUNC]: буфер заполнен */
            break;
        }
        /* «тишина»: данные приходили, но новых нет — забираем
         * что есть (FIX: HTTP/1.1 keep-alive серверы не закрывают сокет,
         * раньше клиент висел до полного таймаута).
         * FIX [SILENCE-3S] (Task 65): было 1.5 с — CDN (QRATOR и др.)
         * паузируют поток между burst'ами дольше.
         * FIX [SILENCE-5S] (Task 66): 3 с всё ещё мало — на загруженном
         * канале burst'ы большой страницы приходят с паузами > 3 с,
         * и ответ обрывался на середине (страница «из одной строки»:
         * заголовки+head до первого гигантского <script>). 5 с.
         * Task 68: в потоковом режиме прогресс — по raw-байтам тела. */
        u32 prog = stream_mode ? g_stream_raw_got : g_http_buf_len;
        if (prog != last_len) {
            last_len = prog;
            last_data_tick = timer_ticks();
        } else if (prog > 0 &&
                   (timer_ticks() - last_data_tick) >= 5000) {   /* тишина 5 с */
            tr_set_stage(tr, "done");
            {
                /* Task 66 [RECV-DIAG]: по serial теперь видно, ПОЧЕМУ
                 * приём закончился (тишина/CL/closed) — раньше «страница
                 * из одной строки» была без объяснений */
                char b[96];
                snprintf(b, sizeof(b),
                         "[http] recv: тишина 5с, принято %u б (%s)\n",
                         (unsigned)g_http_buf_len, use_tls ? "tls" : "plain");
                serial_puts(b);
            }
            break;
        }
        if (use_tls) {
            tls_pump();       /* расшифровка/отправка рекордов движка */
            if (strcmp(tls_errstr(), "ok") != 0) {
                if (g_hdr_end < 0) {
                    /* движок доложил ошибку ДО заголовков — честный сбой
                     * транзакции (MAC/reset/переполнение ring) */
                    http_err(tls_errstr());
                    tls_shutdown();
                    net_tcp_close(sock);
                    if (tr) tr->t_total_ms = ms_since(t0);
                    g_trace = NULL;
                    return -1;
                }
                /* [TLS-TRUNC] FIX: обрыв TLS-сессии В СЕРЕДИНЕ тела
                 * (после заголовков) — это усечение, а не тихий успех:
                 * помечаем truncated и заканчиваем приём (брейк выйдет
                 * с частичным телом; браузер покажет «получено X из Y»). */
                g_http_truncated = 1;
                break;
            }
        }
        net_poll();
        task_yield();
    }

    /* FIX [TCP-R2]: соединение сброшено (RST сервера/шлюза) и данных
     * нет — это живой отказ, а не «тишина в сети». Раньше RST в
     * TCP_ESTABLISHED игнорировался, и клиент выжидал ВСЕ 10 секунд,
     * после чего говорил «response timeout» — что вводило в заблуждение
     * («сервер молчит», хотя на самом деле он ответил отказом). */
    if ((stream_mode ? g_stream_raw_got : g_http_buf_len) == 0 &&
        net_tcp_was_reset(sock)) {
        /* сессия 56: источник RST в сообщении */
        http_err_rst("connection reset", sock);
        if (use_tls) tls_shutdown();
        net_tcp_close(sock);
        if (tr) {
            tr->t_total_ms = ms_since(t0);
            strncpy(tr->error, "connection reset", sizeof(tr->error) - 1);
        }
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }

    if (!g_http_done && (stream_mode ? (g_stream_raw_got == 0 &&
                                       g_hdr_end < 0)
                                     : (g_http_buf_len == 0))) {
        http_err("response timeout");
        if (use_tls) tls_shutdown();
        net_tcp_close(sock);
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }

    /* Сессия 72 [S-69]: «НЕМОЙ» rc=0. Соединение закрылось БЕЗ данных
     * (done ставится по CLOSED/FIN, тело пусто) — раньше транзакция
     * молча возвращала 0: браузер показывал «Ошибка: ok», причина
     * терялась. Классические подписи: self-pair/сбитая пара loopback
     * (сервер закрыл свою сторону, не ответив) либо обрыв сервера.
     * Теперь честный отказ с диагностикой. */
    if ((stream_mode ? (g_stream_raw_got == 0 && g_hdr_end < 0)
                     : (g_http_buf_len == 0))) {
        char b[48];
        snprintf(b, sizeof(b), "пустой ответ (closed, state=%s)",
                 tcp_state_name(net_tcp_state(sock)));
        http_err(b);
        if (use_tls) tls_shutdown();
        net_tcp_close(sock);
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }

    /* FIX [TRUNC-HONEST] (Task 65): обрез ПО ТЕЛУ, а не только по буферу.
     * Раньше truncated ставился ТОЛЬКО при заполнении буфера. Если ответ
     * обрывался по «тишине»/сбросу ПОСЛЕ заголовков (TLS-затык — см.
     * [TLS-RING]), вызывающий получал заголовки + кусок тела и считал
     * ответ ЦЕЛЫМ: браузер честно конвертировал обрывок (или показывал
     * «строк: 1» на пустом теле) без всякого намёка на потерю хвоста.
     * Теперь неполное тело (по Content-Length) либо незавершённый
     * chunked (нет пустой trailer-строки) помечаются truncated=1 —
     * браузер покажет «получено X из Y байт / ОБРЕЗАНО». */
    if (!g_http_truncated && g_hdr_end >= 0) {
        u32 got = stream_mode ? g_stream_raw_got
                              : (g_http_buf_len - (u32)g_hdr_end);
        if (g_chunked == 1) {
            if (!g_chunk_end) g_http_truncated = 1;
        } else if (g_have_content_length && got < g_content_length) {
            g_http_truncated = 1;
        }
    }

    /* Task 67 [HTTP-COOKIE]: Set-Cookie ответа -> банка (host известен;
     * читаем ТОЛЬКО заголовки, до распаковки тела). Task 68: в потоке
     * заголовки лежат в g_http_buf (hdrbuf). */
    if (g_hdr_end >= 0)
        http_store_cookies(host, g_http_buf, g_hdr_end);

    /* Task 68 [HTTP-STREAM]: gzip — распаковать накопитель и отдать
     * колбэку порциями (в буфере вызывателя страницы НЕТ полного тела).
     * [HTTP-GZFAIL] FIX 2: сбой распаковки (битый/обрезанный gzip) или
     * нехватка памяти — ЧЕСТНАЯ ошибка транзакции (-1), а не «успех»
     * с 0/частичными байтами: прежде вызывающий получал rc>=0 (пустую
     * страницу) без всякого сообщения об ошибке. */
    int gz_fail = 0;
    if (stream_mode && !g_stream_aborted && g_gz_acc && g_gz_len > 0) {
        gz_u8 *out = (gz_u8 *)malloc(GZ_STREAM_OUT_MAX);
        if (!out) {
            g_http_truncated = 1;
            http_err("gzip: нет памяти под распаковку");
            gz_fail = 1;
        } else {
            gz_u32 out_len = 0;
            if (gz_inflate_gzip(g_gz_acc, g_gz_len,
                                out, GZ_STREAM_OUT_MAX, &out_len) == 0 &&
                out_len > 0) {
                g_content_length = out_len;      /* честный «X из Y» */
                g_have_content_length = 1;
                u32 off = 0;
                while (off < out_len && !g_stream_aborted) {
                    u32 take = out_len - off;
                    if (take > 32768) take = 32768;
                    if (body_cb(stream_ud, (const char *)out + off,
                                take) != 0)
                        g_stream_aborted = 1;
                    else
                        g_stream_delivered += take;
                    off += take;
                }
                {
                    char b[64];
                    snprintf(b, sizeof(b),
                             "[http] stream: gzip %u -> %u байт\n",
                             (unsigned)g_gz_len, (unsigned)out_len);
                    serial_puts(b);
                }
            } else {
                g_http_truncated = 1;
                http_err("gzip: тело не распаковано (битый/обрезан)");
                gz_fail = 1;
            }
            free(out);
        }
    }

    /* Task 67 [HTTP-GZIP]: Content-Encoding: gzip -> распаковать тело НА
     * МЕСТЕ (временный буфер из кучи; вывод <= g_http_buf_max-hdr_end-1).
     * Раз after-chunked: тело уже декодировано из chunked. Полный CL
     * (по сжатому размеру) уже проверен выше — если тело пришло целиком,
     * член gzip обычно полный; неудача распаковки честно помечается
     * truncated (браузер покажет «получено X из Y»). */
    if (!stream_mode && g_hdr_end >= 0 &&
        g_http_buf_len > (u32)g_hdr_end &&
        http_detect_gzip(g_http_buf, g_hdr_end)) {
        u32 raw_body = g_http_buf_len - (u32)g_hdr_end;
        u32 out_cap  = g_http_buf_max - (u32)g_hdr_end - 1;
        gz_u8 *out = (gz_u8 *)malloc(out_cap ? out_cap : 1);
        if (!out) {
            g_http_truncated = 1;
            serial_puts("[http] gzip: нет памяти под распаковку\n");
        } else {
            gz_u32 out_len = 0;
            if (gz_inflate_gzip((const gz_u8 *)response + g_hdr_end,
                                raw_body, out, out_cap, &out_len) == 0 &&
                out_len > 0 && out_len <= out_cap) {
                memcpy(response + g_hdr_end, out, out_len);
                g_http_buf_len = (u32)g_hdr_end + out_len;
                g_content_length = out_len;        /* честный «X из Y» */
                g_have_content_length = 1;
                {
                    char b[64];
                    snprintf(b, sizeof(b), "[http] gzip: %u -> %u байт\n",
                             (unsigned)raw_body, (unsigned)out_len);
                    serial_puts(b);
                }
            } else {
                g_http_truncated = 1;
                serial_puts("[http] gzip: не распакован (битый/обрезан)\n");
            }
            free(out);
        }
    }

    /* NUL-terminate (Task 68: в потоке буфер вызывателя — не наш) */
    if (!stream_mode) {
        if (g_http_buf_len < g_http_buf_max) {
            response[g_http_buf_len] = 0;
        } else {
            response[g_http_buf_max - 1] = 0;
            g_http_buf_len = g_http_buf_max - 1;
        }
    }

    if (tr) {
        if (g_http_buf_len > 0 && tr->t_first_ms == 0)
            tr->t_first_ms = ms_since(t0);       /* грубая оценка */
        tr->t_total_ms = ms_since(t0);
        tr->resp_len = stream_mode ? g_stream_delivered : g_http_buf_len;
        tr->result = (int)tr->resp_len;
        tr_set_stage(tr, "done");
        if (gz_fail) tr->result = -1;   /* [HTTP-GZFAIL] */
    }

    /* Закрыть сокет если ещё открыт. Сессия 58: вызываем ВСЕГДА —
     * net_tcp_close безопасен и для уже CLOSED слота (loopback-сервер
     * закрывает свою сторону сразу после ответа: клиентский слот
     * оставался in_use=1 до ближайшего net_poll, при серии loopback-
     * запросов без промежуточных опросов это исчерпывало пул из 8
     * сокетов). */
    if (use_tls) {
        tls_shutdown();      /* close_notify (best-effort) */
    }
    net_tcp_close(sock);
    {
        /* [HTTP-STREAM]: прервано колбэком -> -2; gzip-сбой -> -1
         * ([HTTP-GZFAIL]); иначе отдано байт */
        int rc = gz_fail
                 ? -1
                 : (stream_mode
                    ? (g_stream_aborted ? -2 : (int)g_stream_delivered)
                    : (int)g_http_buf_len);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return rc;
    }
}

/* Одна HTTP-транзакция на систему: всё состояние клиента (буфер
 * накопления, сокет, колбэк) — глобальное в этом модуле. Раньше все
 * вызовы шли из kmain (сингл-поток), теперь — из потоков приложений
 * (браузер, терминал). Параллельные вызовы выстраиваются в очередь
 * (ожидают спя, hlt). */
static volatile int http_busy_lock = 0;

int net_http_get(const char *host, u16 port, const char *path,
                  char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("GET", host, port, path, NULL, 0, NULL,
                           response, max_len, max_ms, NULL, 0,
                           0, NULL, NULL, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}

/* Task 67 [HTTP-GZIP]: GET с Accept-Encoding: gzip (браузер; буфер
 * вызывающего должен вмещать РАСПАКОВАННЫЙ ответ). */
int net_http_get_gzip(const char *host, u16 port, const char *path,
                      char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("GET", host, port, path, NULL, 0, NULL,
                           response, max_len, max_ms, NULL, 1,
                           0, NULL, NULL, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}

/* Task 68 [HTTP-STREAM]: потоковый GET — тело колбэками (см. net.h). */
int net_http_get_stream(const char *host, u16 port, const char *path,
                        u32 max_ms, int allow_gzip,
                        net_http_hdr_fn hdr_cb, net_http_body_fn body_cb,
                        void *ud)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("GET", host, port, path, NULL, 0, NULL,
                           NULL, 0, max_ms, NULL, allow_gzip,
                           1, hdr_cb, body_cb, ud);
    s_unlock(&http_busy_lock);
    return rc;
}

int net_http_get_traced(const char *host, u16 port, const char *path,
                          char *response, u32 max_len, u32 max_ms,
                          http_trace_t *tr)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("GET", host, port, path, NULL, 0, NULL,
                           response, max_len, max_ms, tr, 0,
                           0, NULL, NULL, NULL);
    if (tr) tr->result = rc;
    s_unlock(&http_busy_lock);
    return rc;
}

/* Task 47: POST (формы браузера). body — уже закодированное тело
 * (application/x-www-form-urlencoded собирает brf_serialize, brform.h).
 * content_type может быть NULL (подставится form-urlencoded).
 * Возвращает число байт ответа (с заголовками) или -1 (см. errstr). */
int net_http_post(const char *host, u16 port, const char *path,
                   const char *body, const char *content_type,
                   char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("POST", host, port, path, body, 0, content_type,
                           response, max_len, max_ms, NULL, 0,
                           0, NULL, NULL, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}

/* Task 62 [POST-LEN]: POST с телом ЯВНОЙ длины (multipart/form-data
 * с нулями — загрузка файлов на httpd). body_len байт отправляется
 * порциями по MSS с ожиданием ACK. */
int net_http_post_len(const char *host, u16 port, const char *path,
                      const char *body, u32 body_len, const char *content_type,
                      char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("POST", host, port, path, body, body_len, content_type,
                           response, max_len, max_ms, NULL, 0,
                           0, NULL, NULL, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}
