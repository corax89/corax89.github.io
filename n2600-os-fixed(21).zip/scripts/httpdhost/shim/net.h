/* shim: net.h для host-тестов httpd (TCP-стек заглушается).
 * Слушатель/сокеты — fake: тест сам доставляет данные в recv_cb
 * (как loopback-пара) и собирает исходящие в per-socket буфер. */
#ifndef SHIM_NET_H
#define SHIM_NET_H
#include "types.h"

#define TCP_CLOSED      0
#define TCP_ESTABLISHED 1
/* [TCP-CLOSEWAIT] пассивное закрытие: клиент послал FIN, сервер ещё
 * досылает ответ (RFC 793 half-close) — проверяется тестом R-HALF */
#define TCP_CLOSE_WAIT  2

typedef int tcp_state_t;

typedef void (*net_tcp_recv_cb_t)(int sock, u32 src_ip, u16 src_port,
                                  const void *data, u32 len);
typedef void (*tcp_accept_cb_t)(int new_sock, u32 remote_ip, u16 remote_port);

int  net_tcp_listen(u16 local_port, tcp_accept_cb_t cb,
                    net_tcp_recv_cb_t recv_cb);
void net_tcp_unlisten(u16 local_port);

void net_tcp_pin(int sock);
void net_tcp_unpin(int sock);
void net_tcp_unpin_gen(int sock, u32 gen);
u32  net_tcp_gen(int sock);
tcp_state_t net_tcp_state(int sock);
int  net_tcp_send(int sock, const void *data, u32 len);
int  net_tcp_send_pending(int sock);
void net_tcp_close(int sock);

/* прочее, что тянет net_httpd.c */
u32  net_get_ip(void);
u32  net_get_gateway(void);
u32  net_get_netmask(void);
u32  net_dns_server(void);
int  net_nic_present(void);
const char *net_nic_name(void);
void net_ntoa(u32 ip, char *out, u32 out_max);
u32  net_tx_packets(void);
u32  net_rx_packets(void);

typedef enum {
    DHCP_INIT = 0, DHCP_SELECTING, DHCP_REQUESTING,
    DHCP_BOUND, DHCP_RENEWING, DHCP_REBINDING
} dhcp_state_t;
dhcp_state_t net_dhcp_state(void);

typedef struct { u32 ip; u8 mac[6]; } net_arp_entry_t;
#define NET_ARP_CACHE_SIZE 16
int net_arp_dump(net_arp_entry_t *out, int max_entries);
#endif /* SHIM_NET_H */
