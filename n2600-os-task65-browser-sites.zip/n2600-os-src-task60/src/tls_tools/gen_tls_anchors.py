#!/usr/bin/env python3
# gen_tls_anchors.py — сводный tls_anchors.h из Mozilla CA bundle (curl.se/ca)
# + дополнительные корни (extra_roots/*.pem), удалённые из бандла, но
# по-прежнему валидные и используемые сайтами (DigiCert Global Root CA и др.).
#
# Самодостаточный скрипт: нужен только python3 + cryptography
# (brssl и openssl НЕ требуются). Формат вывода полностью совместим
# с прежним (brssl ta): массивы TA{i}_DN / TA{i}_RSA_N / TA{i}_RSA_E /
# TA{i}_EC_Q и сводный массив TAs[].
#
# Запуск:
#   python3 gen_tls_anchors.py [cacert.pem] [extra_dir] [out.h]
# По умолчанию:
#   bundle: ./cacert.pem   extra: ./extra_roots   out: ./tls_anchors.h
import os
import re
import sys
from datetime import datetime, timezone

from cryptography import x509
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from cryptography.hazmat.primitives.asymmetric import ec

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'cacert.pem')
EXTRA = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, 'extra_roots')
OUT = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, 'tls_anchors.h')

CURVE_MAP = {
    'secp256r1': 'BR_EC_secp256r1',
    'secp384r1': 'BR_EC_secp384r1',
    'secp521r1': 'BR_EC_secp521r1',
}


def load_certs_from_text(txt):
    pems = re.findall(
        r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',
        txt, re.S)
    return [x509.load_pem_x509_certificate(p.encode()) for p in pems]


def subj_display(c):
    """Короткая строка субъекта для комментариев."""
    cn = c.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
    if cn:
        return cn[0].value
    ou = c.subject.get_attributes_for_oid(x509.NameOID.ORGANIZATIONAL_UNIT_NAME)
    if ou:
        return ou[0].value
    return c.subject.rfc4514_string()[:60] or '?'


def hex_block(data, indent):
    lines = []
    per = 12
    for i in range(0, len(data), per):
        chunk = data[i:i + per]
        lines.append(indent + ', '.join('0x%02X' % b for b in chunk) + ',')
    return '\n'.join(lines)


def main():
    certs = []
    for pem in load_certs_from_text(open(BUNDLE, encoding='utf-8').read()):
        certs.append(('bundle', pem))
    if os.path.isdir(EXTRA):
        for fn in sorted(os.listdir(EXTRA)):
            if fn.lower().endswith(('.pem', '.crt', '.cer')):
                p = os.path.join(EXTRA, fn)
                for pem in load_certs_from_text(open(p, encoding='utf-8').read()):
                    certs.append((fn, pem))

    now = datetime.now(timezone.utc)
    seen = set()
    anchors = []          # (cert, source)
    skipped_expired = []
    skipped_dup = []
    for src, c in certs:
        # пропуск просроченных/ещё не действующих
        nb = c.not_valid_before_utc
        na = c.not_valid_after_utc
        if na <= now or nb > now:
            skipped_expired.append((subj_display(c), src))
            continue
        # дедупликация по субъекту+ключу
        try:
            dn = c.subject.public_bytes(Encoding.DER)
            spki = c.public_key().public_bytes(
                Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
        except Exception:
            skipped_dup.append((subj_display(c), src, 'unsupported key'))
            continue
        key = (dn, spki)
        if key in seen:
            skipped_dup.append((subj_display(c), src, 'dup'))
            continue
        seen.add(key)
        pk = c.public_key()
        if not isinstance(pk, (ec.EllipticCurvePublicKey,)) and not hasattr(pk, 'key_size'):
            skipped_dup.append((subj_display(c), src, 'unknown key type'))
            continue
        anchors.append((c, src))

    parts = []
    gen_date = now.strftime('%Y-%m-%d')
    parts.append(
        '/* tls_anchors.h — доверенные корневые CA для N2600-OS.\n'
        ' * Формат: br_x509_trust_anchor (BearSSL). Сгенерировано\n'
        ' * tls_tools/gen_tls_anchors.py (самодостаточный, python3+cryptography)\n'
        ' * из корней Mozilla CA store (curl.se/ca) + tls_tools/extra_roots/\n'
        ' * (валидные корни, удалённые из бандла: DigiCert Global Root CA и др.).\n'
        ' * Тот же файл используется и хост-тестом.\n'
        ' *\n'
        ' * Генерация: ' + gen_date + ', якорей: ' + str(len(anchors)) + '.\n'
        ' * Обновление: скачать https://curl.se/ca/cacert.pem рядом со скриптом,\n'
        ' * при необходимости добавить PEM в extra_roots/, запустить скрипт и\n'
        ' * перенести tls_anchors.h в src/.\n'
        ' */\n'
        '#ifndef TLS_ANCHORS_H\n'
        '#define TLS_ANCHORS_H\n\n'
        '#include "bearssl.h"\n')

    entries = []
    for i, (c, src) in enumerate(anchors):
        pk = c.public_key()
        nb = c.not_valid_before_utc.strftime('%Y-%m-%d')
        na = c.not_valid_after_utc.strftime('%Y-%m-%d')
        dn = c.subject.public_bytes(Encoding.DER)
        disp = subj_display(c).replace('/*', '').replace('*/', '')
        parts.append('\n/* ---- %s (%s %d bit, %s..%s) ---- */\n'
                     % (disp, type(pk).__name__, pk.key_size, nb, na))
        parts.append('\nstatic const unsigned char TA%d_DN[] = {\n%s\n};\n'
                     % (i, hex_block(dn, '        ')))
        if isinstance(pk, ec.EllipticCurvePublicKey):
            curve = CURVE_MAP.get(pk.curve.name)
            if curve is None:
                print('SKIP (кривая %s): %s' % (pk.curve.name, disp),
                      file=sys.stderr)
                continue
            q = pk.public_bytes(Encoding.X962, PublicFormat.UncompressedPoint)
            parts.append('\nstatic const unsigned char TA%d_EC_Q[] = {\n%s\n};\n'
                         % (i, hex_block(q, '        ')))
            entries.append(
                '{\n'
                '{ (unsigned char *)TA%d_DN, sizeof TA%d_DN },\n'
                'BR_X509_TA_CA,\n'
                '{\n'
                'BR_KEYTYPE_EC,\n'
                '{ .ec = {\n'
                '%s,\n'
                '(unsigned char *)TA%d_EC_Q, sizeof TA%d_EC_Q,\n'
                '} }\n'
                '}\n'
                '},  /* %s */' % (i, i, curve, i, i, disp))
        else:  # RSA
            nums = pk.public_numbers()
            klen = (pk.key_size + 7) // 8
            n = nums.n.to_bytes(klen, 'big')
            e = nums.e.to_bytes((nums.e.bit_length() + 7) // 8, 'big')
            parts.append('\nstatic const unsigned char TA%d_RSA_N[] = {\n%s\n};\n'
                         % (i, hex_block(n, '        ')))
            parts.append('\nstatic const unsigned char TA%d_RSA_E[] = {\n%s\n};\n'
                         % (i, hex_block(e, '        ')))
            entries.append(
                '{\n'
                '{ (unsigned char *)TA%d_DN, sizeof TA%d_DN },\n'
                'BR_X509_TA_CA,\n'
                '{\n'
                'BR_KEYTYPE_RSA,\n'
                '{ .rsa = {\n'
                '(unsigned char *)TA%d_RSA_N, sizeof TA%d_RSA_N,\n'
                '(unsigned char *)TA%d_RSA_E, sizeof TA%d_RSA_E,\n'
                '} }\n'
                '}\n'
                '},  /* %s */' % (i, i, i, i, i, i, disp))

    parts.append('\n/* ---- сводный массив доверенных якорей ---- */\n')
    parts.append('static const br_x509_trust_anchor TAs[] = {\n')
    parts.append('\n'.join(entries))
    parts.append('\n};\n\n')
    parts.append('#define TAs_NUM   %d\n\n' % len(entries))
    parts.append('#endif /* TLS_ANCHORS_H */\n')

    with open(OUT, 'w', encoding='utf-8') as f:
        f.write(''.join(parts))

    print('OK: %s  якорей: %d  размер: %d байт'
          % (OUT, len(entries), os.path.getsize(OUT)))
    if skipped_expired:
        print('просроченные/недействующие (пропущены):')
        for s, src in skipped_expired:
            print('  -', s[:60], '(%s)' % src)
    if skipped_dup:
        print('прочие пропущенные:')
        for row in skipped_dup:
            print('  -', row[0][:60], row[1:])


if __name__ == '__main__':
    main()
