#!/bin/sh
# build_boot.sh — сборка загрузчиков N2600-OS.
#
# Артефакты (каждый сектор — строго 512 байт, stage2 — строго 8704):
#   boot.bin      stage 1: сектор дискеты / «суперфлоппи» HDD-USB (BPB FAT12)
#   boot_pbr.bin  stage 1: VBR раздела (без BPB, ядро с part_start+18)
#   stage2.bin    stage 2: логика загрузки ядра, видео, mb_info, вход в PM
#   mbr.bin       MBR: активный раздел -> VBR
#
# Требуется только binutils (as/ld/objcopy).
set -e
cd "$(dirname "$0")"

AS=as
LD=ld
OBJCOPY=objcopy
if ! as --32 -o /dev/null /dev/null 2>/dev/null; then
    if command -v i686-w64-mingw32-as >/dev/null 2>&1; then
        AS=i686-w64-mingw32-as
        LD=i686-w64-mingw32-ld
        OBJCOPY=i686-w64-mingw32-objcopy
    fi
fi

STAGE2_SECTORS=17
STAGE2_BYTES=$((STAGE2_SECTORS * 512))

build_sect() {	# build_sect <src> <out> <extra defines> [ttext]
    src=$1; out=$2; extra=$3; ttext=${4:-0x7C00}
    $AS --32 $extra -o "b1.o" "$src"
    $LD -m elf_i386 -Ttext=$ttext -e _start -o "b1.elf" "b1.o"
    $OBJCOPY -O binary "b1.elf" "$out"
    sz=$(wc -c < "$out")
    if [ "$sz" -ne 512 ]; then
        echo "ОШИБКА: $out = ${sz} байт (должно быть ровно 512)" >&2
        exit 1
    fi
    echo "  $out  OK (512)"
}

echo "Сборка загрузчиков:"
build_sect boot.S    boot.bin     ""
build_sect boot.S    boot_pbr.bin "--defsym VBR_PARTITION=1"

# stage2: собирается на 0x7E00, дополняется до 17 секторов
$AS --32 -o b2.o stage2.S
$LD -m elf_i386 -Ttext=0x7E00 -e _start -o b2.elf b2.o
$OBJCOPY -O binary b2.elf stage2.bin
sz=$(wc -c < stage2.bin)
if [ "$sz" -gt "$STAGE2_BYTES" ]; then
    echo "ОШИБКА: stage2.bin = ${sz} байт (лимит ${STAGE2_BYTES})" >&2
    exit 1
fi
truncate -s "$STAGE2_BYTES" stage2.bin
echo "  stage2.bin  OK (${sz} -> ${STAGE2_BYTES} байт)"

build_sect mbr.S     mbr.bin      "" 0x600
rm -f b1.o b1.elf b2.o b2.elf
echo "[OK] boot/boot.bin, boot/boot_pbr.bin, boot/stage2.bin, boot/mbr.bin"
