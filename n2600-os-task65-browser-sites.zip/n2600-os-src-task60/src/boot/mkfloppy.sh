#!/bin/sh
# mkfloppy.sh — собрать загрузочную дискету 1.44 МБ с N2600-OS.
#
# Раскладка: LBA 0 = boot.bin (stage 1), LBA 1..17 = stage2.bin,
#            LBA 18..  = kernel.bin.
# Использование: ./mkfloppy.sh [kernel.bin] [floppy.img]
set -e
ORIG=$PWD
cd "$(dirname "$0")"
# относительные аргументы разрешаем от исходного каталога
absp() { case "$1" in /*) printf "%s" "$1";; *) printf "%s" "$ORIG/$1";; esac; }

K=$(absp "${1:-../kernel.bin}")
OUT=$(absp "${2:-../floppy.img}")
STAGE2=stage2.bin
BOOT=boot.bin

[ -f "$BOOT" ]   || { echo "Нет $BOOT — сначала build_boot.sh" >&2; exit 1; }
[ -f "$STAGE2" ] || { echo "Нет $STAGE2 — сначала build_boot.sh" >&2; exit 1; }
[ -f "$K" ]      || { echo "Нет ядра $K — сначала build.sh" >&2; exit 1; }

SZ=$(wc -c < "$K")
SEC=$(( (SZ + 511) / 512 ))
if [ "$SEC" -gt $((2880 - 18)) ]; then
    echo "ОШИБКА: ядро $SEC секторов не влезает в 1.44МБ дискету (лимит 2862)" >&2
    exit 1
fi

# Образ: 2880 секторов, нули
dd if=/dev/zero of="$OUT" bs=512 count=2880 2>/dev/null
# stage 1 (сектор 0)
dd if="$BOOT" of="$OUT" bs=512 conv=notrunc 2>/dev/null
# stage 2 (секторы 1..17)
dd if="$STAGE2" of="$OUT" bs=512 seek=1 conv=notrunc 2>/dev/null
# ядро (сектор 18)
dd if="$K" of="$OUT" bs=512 seek=18 conv=notrunc 2>/dev/null
# ksec: число секторов ядра — dword по смещению 512+4 (в stage 2)
B0=$(printf '%03o' $((SEC & 255))); B1=$(printf '%03o' $(((SEC >> 8) & 255))); B2=$(printf '%03o' $(((SEC >> 16) & 255)))
printf "\\$B0\\$B1\\$B2\\000" | dd of="$OUT" bs=1 seek=516 conv=notrunc 2>/dev/null

echo "[OK] $OUT: дискета 1.44МБ, ядро $SZ байт ($SEC секторов, LBA 18+)"
echo "     Запись на дискету: dd if=$OUT of=/dev/fd0 bs=512 (или rawwritewin на Windows)"
