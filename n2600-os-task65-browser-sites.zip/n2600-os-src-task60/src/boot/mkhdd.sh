#!/bin/sh
# mkhdd.sh — собрать загрузочный HDD/USB-образ N2600-OS.
#
# Режимы:
#   ./mkhdd.sh raw   [kernel.bin] [out.img] [размер_МБ]  — «суперфлоппи»:
#       без таблицы разделов, stage1 в LBA 0, ядро с LBA 18.
#       Готовый образ можно записать dd на весь диск/флешку.
#   ./mkhdd.sh part  [kernel.bin] [out.img] [размер_МБ]  — с разделом:
#       mbr.bin в LBA 0 (запись раздела патчится), boot_pbr.bin в LBA 32
#       (начало раздела), ядро с LBA 32+18.
#
# Оба образа грузятся и с USB (Rufus в режиме DD, или dd, или balenaEtcher).
set -e
ORIG=$PWD
cd "$(dirname "$0")"
# относительные аргументы разрешаем от исходного каталога
absp() { case "$1" in /*) printf "%s" "$1";; *) printf "%s" "$ORIG/$1";; esac; }

MODE=${1:-raw}
K=$(absp "${2:-../kernel.bin}")
OUT=$(absp "${3:-../n2600-${MODE}.img}")
MB=${4:-8}

[ -f "$K" ] || { echo "Нет ядра $K — сначала build.sh" >&2; exit 1; }

SZ=$(wc -c < "$K")
SEC=$(( (SZ + 511) / 512 ))
KBASE_OFF=$((18 * 512))
KBASE2_OFF=$((50 * 512))

case "$MODE" in
raw)
    TOTAL=$((MB * 2048))                    # секторов
    [ "$TOTAL" -ge $((18 + SEC)) ] || { echo "Диск мал для ядра" >&2; exit 1; }
    dd if=/dev/zero of="$OUT" bs=512 count=$TOTAL 2>/dev/null
    dd if=boot.bin   of="$OUT" bs=512 conv=notrunc 2>/dev/null
    dd if=stage2.bin of="$OUT" bs=512 seek=1  conv=notrunc 2>/dev/null
    dd if="$K"       of="$OUT" bs=512 seek=18 conv=notrunc 2>/dev/null
    B0=$(printf '%03o' $((SEC & 255))); B1=$(printf '%03o' $(((SEC >> 8) & 255))); B2=$(printf '%03o' $(((SEC >> 16) & 255)))
    printf "\\$B0\\$B1\\$B2\\000" | dd of="$OUT" bs=1 seek=516 conv=notrunc 2>/dev/null
    echo "[OK] $OUT: суперфлоппи ${MB}МБ, ядро с LBA 18 ($SEC секторов)"
    echo "     dd if=$OUT of=/dev/sdX bs=4M  (или Rufus -> DD-режим)"
    ;;
part)
    PART=32                                 # LBA начала раздела
    TOTAL=$((MB * 2048))
    [ "$TOTAL" -ge $((PART + 18 + SEC)) ] || { echo "Диск мал для ядра" >&2; exit 1; }
    dd if=/dev/zero of="$OUT" bs=512 count=$TOTAL 2>/dev/null
    dd if=mbr.bin     of="$OUT" bs=512 conv=notrunc 2>/dev/null
    dd if=boot_pbr.bin of="$OUT" bs=512 seek=$PART conv=notrunc 2>/dev/null
    dd if=stage2.bin  of="$OUT" bs=512 seek=$((PART + 1)) conv=notrunc 2>/dev/null
    dd if="$K"        of="$OUT" bs=512 seek=$((PART + 18)) conv=notrunc 2>/dev/null
    # ksec в stage2 (offset PART*512 + 512 + 4)
    B0=$(printf '%03o' $((SEC & 255))); B1=$(printf '%03o' $(((SEC >> 8) & 255))); B2=$(printf '%03o' $(((SEC >> 16) & 255)))
    printf "\\$B0\\$B1\\$B2\\000" | dd of="$OUT" bs=1 seek=$((PART * 512 + 516)) conv=notrunc 2>/dev/null
    # запись раздела 1 @0x1BE: 0x80, CHS start(hd0,sect32,cyl0), тип 0xDA,
    # CHS end (фликтж), LBA=PART, размер=TOTAL-PART
    python3 - "$OUT" "$PART" "$TOTAL" <<'PYEOF'
import struct, sys
out, part, total = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
img = open(out, "r+b")
entry = bytes([0x80, 0x00, 0x20, 0x00, 0xDA, 0xFE, 0xFF, 0xFF]) \
      + struct.pack("<II", part, total - part)
img.seek(0x1BE)
img.write(entry)
img.close()
PYEOF
    echo "[OK] $OUT: ${MB}МБ, раздел 1 @LBA $PART (bootable, тип 0xDA), ядро с LBA $((PART + 18))"
    ;;
*)
    echo "Режим: raw | part" >&2
    exit 1
    ;;
esac
