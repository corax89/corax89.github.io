@echo off
chcp 437 >nul
:: ============================================================
::  N2600-OS: MinGW kernel build for Windows
::  Uses compiler at: C:\msys64\mingw32\bin
::  Result: kernel.bin (flat multiboot image for GRUB)
:: ============================================================
setlocal

set TOOLCHAIN=C:\msys64\mingw32\bin
set CC=%TOOLCHAIN%\gcc.exe
set OBJCOPY=%TOOLCHAIN%\objcopy.exe

:: Add toolchain to PATH so helper utilities (cc1, as, ld) can find their DLLs
set PATH=%TOOLCHAIN%;%PATH%

if not exist "%CC%" (
  echo [ERROR] gcc not found at: %CC%
  echo Make sure MSYS2 and the mingw-w64-i686-toolchain package are installed.
  pause
  exit /b 1
)

if not exist build mkdir build

:: CLEANUP: remove all old object files to avoid linking garbage
del build\*.o 2>nul

:: Test compiler functionality
echo int main(void){return 0;} > build\_probe.c
"%CC%" -m32 -c build\_probe.c -o build\_probe.o >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Compiler is not working.
  del build\_probe.c 2>nul
  pause
  exit /b 1
)
del build\_probe.c build\_probe.o 2>nul

:: =========================================================================
:: ÊÐÈÒÈ×ÅÑÊÈ ÂÀÆÍÛÅ ÔËÀÃÈ ÄËß OSDEV:
:: -march=i686       : Öåëåâàÿ àðõèòåêòóðà (áàçîâàÿ 32-áèòíàÿ)
:: -mno-sse          : ÇÀÏÐÅÒ èíñòðóêöèé SSE (âûçûâàåò #UD â VMware áåç CR4)
:: -mno-sse2         : ÇÀÏÐÅÒ èíñòðóêöèé SSE2
:: -mno-mmx          : ÇÀÏÐÅÒ èíñòðóêöèé MMX
:: -mno-3dnow        : ÇÀÏÐÅÒ èíñòðóêöèé 3DNow!
:: Îñòàëüíûå ôëàãè îòêëþ÷àþò çàâèñèìîñòè îò ñòàíäàðòíîé áèáëèîòåêè è çàùèòû, 
:: êîòîðûõ íåò â íàøåì ïðîñòîì ÿäðå.
:: =========================================================================
set CFLAGS=-m32 -march=i686 -mtune=atom -mno-sse -mno-sse2 -mno-mmx -mno-3dnow -mno-sse3 -mno-ssse3 -mno-avx -ffreestanding -fno-pic -fno-pie -fno-stack-protector -fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe -O2 -Wall -Wextra -Isrc
rem [CPUID-SIMD] baseline: SIMD only in target("sse2") functions (fb.c)
rem and explicit inline asm (fxsave/fxrstor in task.c/cpu.c).
rem [WIFI-DBG-GATE] (Task 43): polevaya otladka WiFi/DHCP - po umolchaniyu VYKLYUCHENA.
rem Vklyuchenie: set WIFI_DEBUG=1 pered build.bat (ili -DWIFI_DEBUG=1 v CFLAGS).
if "%WIFI_DEBUG%"=="1" set CFLAGS=%CFLAGS% -DWIFI_DEBUG=1

echo [1/3] Compiling sources...
for %%f in (src\*.c) do call :cc "%%f"
if errorlevel 1 goto :fail

echo [2/3] Linking...
:: -nostdlib ãàðàíòèðóåò, ÷òî íå áóäóò ïîäêëþ÷åíû ñòàíäàðòíûå áèáëèîòåêè C
"%CC%" -m32 -nostdlib -Wl,-T,linker.ld -Wl,--image-base=0x100000 -o build\kernel.tmp.exe build\*.o
if errorlevel 1 goto :fail

echo [3/3] Extracting flat binary...
"%OBJCOPY%" -O binary build\kernel.tmp.exe kernel.bin
if errorlevel 1 goto :fail

echo.
echo [OK] Done: kernel.bin
echo Next: copy kernel.bin to isodir\boot\ and build os.iso
pause
exit /b 0

:: ==== per-file compile: -w for vendored mquickjs.c amalgamation
::      (foxen-flac.c: freestanding, ¡¥§ assert.h)
:cc
set "EXTRA="
if "%~n1"=="mquickjs" set "EXTRA=-w"
if "%~n1"=="foxen-flac" set "EXTRA=-DNDEBUG"
echo   CC %~1
"%CC%" %CFLAGS% %EXTRA% -c %1 -o "build\%~n1.o"
if errorlevel 1 exit /b 1
goto :eof

:fail
echo.
echo [ERROR] Build failed, see messages above.
pause
exit /b 1