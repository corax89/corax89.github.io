# Загрузчик N2600-OS без GRUB

Собственный компактный загрузчик: **2 сектора кода (512 Б + 1346 Б)** +
kernel.bin. Позволяет грузить ОС с дискеты, HDD/USB-флешки (Rufus DD) или
из раздела диска. GRUB-путь (`os.iso` через `makeiso.sh`) работает как
раньше и от загрузчика не зависит — все три способа взаимозаменяемы.

## Состав (каталог `boot/`)

| Файл | Размер | Роль |
|------|--------|------|
| `boot.S`    | 512 Б | **stage 1** — загрузочный сектор: грузит stage 2, пишет контракт в 0x510/0x514, прыжок в 0x7E00 |
| `stage2.S`  | 1346→8704 Б | **stage 2** — A20, unreal mode, загрузка ядра, парс multiboot-заголовка, обнуление .bss, VBE-видеорежим, mb_info, вход в PM |
| `mbr.S`     | 512 Б | MBR для разбитого диска: активный раздел → VBR (ESI = LBA раздела) |
| `boot.bin` | 512 Б | stage 1, собранный для дискеты/суперфлоппи |
| `boot_pbr.bin` | 512 Б | stage 1, собранный как VBR раздела (`-DVBR_PARTITION`) |
| `stage2.bin` | 8704 Б | stage 2, дополненный до 17 секторов |
| `build_boot.sh` | — | сборка (нужен только binutils: as/ld/objcopy) |
| `mkfloppy.sh` | — | образ дискеты 1.44 МБ |
| `mkhdd.sh` | — | образ HDD/USB (режимы `raw` и `part`) |

## Как это работает

```
BIOS ──> stage 1 (0x7C00)          512 Б, BPB FAT12 для дискеты
              │ читает 17 секторов (stage 2) в 0x7E00
              │ дискета: CHS (дорожка 0);  HDD/USB: INT 13h AH=42h, LBA
              ▼
         stage 2 (0x7E00)          ~1.3 КБ
              │ A20 (порт 0x92) + unreal mode (SS/FS = 4 ГБ)
              │ читает kernel.bin чанками в 0x20000, копирует на 0x100000
              │ парсит multiboot-заголовок ядра (load/load_end/bss_end/entry)
              │ обнуляет .bss, сканирует VESA-режимы (лучший 32bpp LFB),
              │ собирает mb_info (framebuffer + mem_upper) @0x500
              ▼
         защищённый режим: EAX=0x2BADB002, EBX=0x500, jmp entry
```

Контракт для ядра тот же, что у GRUB (multiboot 0.6.96): ядро получает
magic + указатель на `mb_info_t` с фреймбуфером — поэтому `kernel.bin`
один и тот же и для GRUB, и для собственного загрузчика.

### Раскладка носителя

```
LBA 0        stage 1 (boot.bin / boot_pbr.bin)
LBA 1..17    stage 2
LBA 18..     kernel.bin          (число секторов — dword @512+4 образа)
```

Для раздела всё то же самое со сдвигом на LBA начала раздела
(mbr.bin передаёт его в ESI, boot_pbr прибавляет смещения).

### Важно

* stage 2 ищет multiboot-заголовок в первых 8 КиБ ядра — работает с
  AOUT_KLUDGE (в kernel.bin он есть всегда, см. `src/kernel.c`).
* Стартовая сигнатура stage 2 = `EB 06` («jmp main») — она же проверяется
  stage 1: первый байт сектора обязан быть кодом.
* `.bss` ядра обнуляет загрузчик (GRUB делал это по `bss_end_addr`).

## Сборка

```sh
sh build.sh            # ядро + загрузчик + floppy.img + n2600-raw.img
# или по частям:
sh boot/build_boot.sh
sh boot/mkfloppy.sh kernel.bin floppy.img
sh boot/mkhdd.sh raw  kernel.bin n2600-raw.img  8
sh boot/mkhdd.sh part kernel.bin n2600-part.img 8
```

`build.sh` собирает загрузчик автоматически, если в системе есть binutils
(as/ld/objcopy — есть и в MinGW); при недоступности GRUB-путь продолжает
работать.

## Установка и загрузка

### Дискета
```sh
dd if=floppy.img of=/dev/fd0 bs=512
# Windows: rawwritewin / WinImage
```

### USB/HDD целиком («суперфлоппи», режим raw)
```sh
dd if=n2600-raw.img of=/dev/sdX bs=4M    # ВНИМАНИЕ: весь диск затирается!
# Windows: Rufus -> выбор образа -> режим DD, или balenaEtcher
```

### Диск с разделом (режим part)
```sh
dd if=n2600-part.img of=/dev/sdX bs=4M
# или вручную: dd mbr.bin в сектор 0, boot_pbr.bin в начало раздела
```
Таблица разделов: одна загрузочная запись (тип 0xDA «non-FS data»),
LBA 32. Ядро и stage 2 лежат внутри раздела.

### Через GRUB (без изменений)
```sh
sh makeiso.sh            # os.iso, isohybrid — Rufus DD/ISO работает
# либо с установленного диска:
menuentry "N2600-OS" {
    multiboot /n2600/kernel.bin
}
```

### QEMU
```sh
qemu-system-i386 -fda floppy.img
qemu-system-i386 -hda n2600-raw.img
qemu-system-i386 -cdrom os.iso
```

## Замечания

* **RAM disk**: при загрузке с дискеты/HDD RAM disk пустой (приложения
  сидят в ISO). Ядро это штатно обрабатывает — доступна консоль и REPL;
  приложения — только при загрузке через os.iso (ramdisk из ISO).
* **Геометрия дискеты**: CHS-путь берёт секторов/дорожку и головки из BPB
  stage 1 (@0x7C18/0x7C1A) — при носителях с другой геометрией поправьте
  BPB в boot.S (для 1.44 МБ уже верно).
* **A20** включается через порт 0x92; на экзотике без fast-A20 может
  понадобиться метод через контроллер клавиатуры (не реализован ради
  компактности).
* **Тесты**: `scripts/test_boot_unicorn.py` — эмуляция всей цепочки
  (unicorn + мини-BIOS): дискета CHS, HDD LBA, отсутствие LBA-ext,
  отсутствие VBE, VBR с ESI. Запуск: `python3 scripts/test_boot_unicorn.py`.
