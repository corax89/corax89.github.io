#!/usr/bin/env python3
"""patch_iso_kernel_only.py — заменить /boot/kernel.bin в готовом os.iso,
НЕ трогая хвост (ramdisk/grub.cfg уже актуальны в prebuilt/os.iso).

Новое ядро должно помещаться в старый экстент (новый размер <= старого).
Правится только 4-байтовое поле размера в каталогах PVD (ISO9660) и
SVD (Joliet). El Torito / isohybrid-MBR / ramdisk не затрагиваются.
"""
import os
import struct
import sys

SECT = 2048
HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))


def find_kernel_records(data):
    """Вернуть [(vd_type, sec, record_off, size)] для /boot/kernel.bin."""
    out = []
    sec = 16
    while True:
        vd = data[sec * SECT:(sec + 1) * SECT]
        if vd[1:6] != b"CD001":
            break
        t = vd[0]
        if t in (1, 2):
            root_lba = struct.unpack("<I", vd[156 + 2:156 + 6])[0]
            root_size = struct.unpack("<I", vd[156 + 10:156 + 14])[0]
            # обход каталогов в глубину
            stack = [(root_lba, root_size, "")]
            while stack:
                lba, size, path = stack.pop()
                off = lba * SECT
                end = off + size
                p = off
                while p < end:
                    ln = data[p]
                    if ln == 0:
                        # перейти к следующему сектору
                        p = ((p // SECT) + 1) * SECT
                        continue
                    name_len = data[p + 32]
                    flags = data[p + 25]
                    f_lba = struct.unpack("<I", data[p + 2:p + 6])[0]
                    f_size = struct.unpack("<I", data[p + 10:p + 14])[0]
                    name = data[p + 33:p + 33 + name_len]
                    if flags & 2:  # каталог
                        if name not in (b"\x00", b"\x01"):
                            if t == 2:  # Joliet: имена в UTF-16BE
                                nm = name.decode("utf-16-be", "replace")
                            else:
                                nm = name.decode("ascii", "replace")
                            stack.append((f_lba, f_size, path + "/" + nm))
                    else:
                        if t == 2:  # Joliet
                            nm = name.decode("utf-16-be", "replace").split(";")[0]
                        else:
                            nm = name.decode("ascii", "replace").split(";")[0]
                        if (path + "/" + nm) == "/boot/kernel.bin":
                            out.append((t, sec, p, f_size))
                    p += ln
        if t == 255:
            break
        sec += 1
    return out


def main():
    iso_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PROJ, "prebuilt", "os.iso")
    ker_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(PROJ, "kernel.bin")
    data = bytearray(open(iso_path, "rb").read())
    ker = open(ker_path, "rb").read()

    recs = find_kernel_records(data)
    if not recs:
        print("ERROR: /boot/kernel.bin не найден")
        return 1
    t0, sec0, off0, old_size = recs[0]
    lba = struct.unpack("<I", data[off0 + 2:off0 + 6])[0]
    if len(ker) > old_size:
        print(f"ERROR: новое ядро {len(ker)} > старого экстента {old_size}")
        return 1
    # записать ядро в экстент (хвост экстента — нули)
    abs_off = lba * SECT
    nsect = (len(ker) + SECT - 1) // SECT
    data[abs_off:abs_off + nsect * SECT] = b"\x00" * (nsect * SECT)
    data[abs_off:abs_off + len(ker)] = ker
    # править размер в обоих томах
    for (t, sec, off, size) in recs:
        if size != old_size:
            print(f"WARN: размер записи {size} != {old_size}")
        data[off + 10:off + 14] = struct.pack("<I", len(ker))
        print(f"  {'SVD' if t == 2 else 'PVD'}: record @{off}: {size} -> {len(ker)}")
    with open(iso_path, "wb") as f:
        f.write(data)
    print(f"OK: {iso_path}: ядро {len(ker)} байт по LBA {lba} (старое {old_size})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
