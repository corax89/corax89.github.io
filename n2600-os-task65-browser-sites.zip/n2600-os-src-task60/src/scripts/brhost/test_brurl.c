/* test_brurl.c — хост-тест URL-логики браузера N2600-OS (Task 61).
 *
 * Покрывает РЕАЛЬНЫЙ код:
 *   - src/brurl.h      (br_parse_host, br_http_status, br_parse_redirect,
 *                       br_split_url — разбор адреса как в адресной
 *                       строке/ссылке/Location);
 *   - src/imgsvc.c     (img_url_resolve, img_norm_url_path,
 *                       img_url_encode_path, img_parse_http — путь
 *                       картинки через img_decode_url c заглушкой сети);
 *   - src/brform.h     (brf_parse: meta-refresh content="N; url=U").
 *
 * Сценарии «популярных сайтов», которые раньше ломались:
 *   [BR-REDIR2] цепочки 301/302 (лимит 4 не хватал), длинный Location;
 *   [BR-2SLASH] двойные слеши в путях ("host//a", Location "/a//b");
 *   [BR-NOSLASH]/[BR-URL1SLASH] "http:/host" (одинарный слеш),
 *               "HTTP://YA.RU" (верхний регистр), "?page=2" (только query);
 *   [BR-PCT]    пробелы и кириллица в путях (ломали request-line);
 *   [BR-REFRESHQ] meta refresh url='...' в кавычках, "url = ...".
 *
 * Сборка/запуск: sh run.sh
 */
#define HOST_TEST 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "net.h"      /* shim: прототипы сети для заглушек */
#include "ramfs.h"    /* shim: ramfs_dirent_t */
#include "brurl.h"
#include "brform.h"
#include "imgsvc.h"

/* ---------- заглушки зависимостей imgsvc.c ---------- */

static char g_last_http_path[300];   /* перехват пути GET из imgsvc */

int net_http_get(const char *host, u16 port, const char *path,
                 char *response, u32 max_len, u32 max_ms)
{
    (void)host; (void)port; (void)response; (void)max_len; (void)max_ms;
    snprintf(g_last_http_path, sizeof(g_last_http_path), "%s", path);
    return -1;                       /* сеть недоступна — хватаем путь */
}
int net_http_post(const char *host, u16 port, const char *path,
                  const char *body, const char *content_type,
                  char *response, u32 max_len, u32 max_ms)
{ (void)host;(void)port;(void)path;(void)body;(void)content_type;
  (void)response;(void)max_len;(void)max_ms; return -1; }
const char *net_http_errstr(void) { return "host test: сеть заглушена"; }
int  net_host_is_loopback(const char *h) { (void)h; return 0; }
int  net_nic_present(void) { return 1; }        /* сеть «есть» — доходим до GET */
u32  net_get_ip(void) { return 0xC0A80101u; }
void net_ntoa(u32 ip, char *out, int out_max)
{ (void)ip; if (out && out_max > 0) snprintf(out, (size_t)out_max, "0.0.0.0"); }
u32  timer_ticks(void) { static u32 t; return ++t; }

int  ramfs_list(ramfs_dirent_t *out, int max) { (void)out; (void)max; return 0; }
int  ramfs_create(const char *n, u32 s) { (void)n; (void)s; return 0; }
int  ramfs_write(const char *n, const void *b, u32 s) { (void)n;(void)b;(void)s; return 0; }
u32  ramfs_read(const char *n, void *b, u32 m) { (void)n;(void)b;(void)m; return 0; }
int  ramfs_delete(const char *n) { (void)n; return 0; }

/* stb_image: только чтобы слинковать imgsvc.c (декод в тестах не зовём);
 * stbi_uc = unsigned char (см. stb_image.h) */
int stbi_info_from_memory(const unsigned char *b, int l, int *x, int *y, int *c)
{ (void)b;(void)l;(void)x;(void)y;(void)c; return 0; }
unsigned char *stbi_load_from_memory(const unsigned char *b, int l, int *x,
                                     int *y, int *c, int rq)
{ (void)b;(void)l;(void)x;(void)y;(void)c;(void)rq; return NULL; }

/* ---------- каркас ---------- */

static int PASS = 0, FAIL = 0;

static void CHECK(const char *name, int ok, const char *detail)
{
    if (ok) { PASS++; printf("  [PASS] %s\n", name); }
    else    { FAIL++; printf("  [FAIL] %s — %s\n", name, detail ? detail : ""); }
}

static void check_str(const char *name, const char *got, const char *want)
{
    char d[700];
    snprintf(d, sizeof(d), "получено \"%s\", ожидалось \"%s\"",
             got ? got : "(null)", want);
    CHECK(name, got && strcmp(got, want) == 0, d);
}

int main(void)
{
    /* ================= img_url_resolve ================= */
    printf("img_url_resolve:\n");
    {
        char out[512];

        /* [BR-REDIR2]: схема в верхнем регистре — раньше клеилась
         * к хосту страницы ("http://ya.ru/HTTPS://...") */
        img_url_resolve("http://ya.ru/dir/page",
                        "HTTPS://WWW.EX.COM/A//B/./C", out, (int)sizeof(out));
        check_str("верхний регистр схемы + // в пути",
                  out, "HTTPS://WWW.EX.COM/A/B/C");

        /* [BR-URL1SLASH]: одинарный слеш после схемы (битые Location) */
        img_url_resolve("http://ya.ru/", "http:/example.com/x",
                        out, (int)sizeof(out));
        check_str("одинарный слеш http:/ чинится", out, "http://example.com/x");
        img_url_resolve("http://ya.ru/", "https:/example.com",
                        out, (int)sizeof(out));
        check_str("одинарный слеш https:/ чинится", out, "https://example.com");

        /* [BR-QREL]: "?page=2" — тот же путь, а не каталог */
        img_url_resolve("http://h.ru/dir/page", "?pg=2", out, (int)sizeof(out));
        check_str("query-only ?pg=2 остаётся на пути страницы",
                  out, "http://h.ru/dir/page?pg=2");

        /* прежнее поведение — регрессия */
        img_url_resolve("http://ya.ru/", "//cdn.site.ru/lib.js",
                        out, (int)sizeof(out));
        check_str("схемо-относительный //host", out, "http://cdn.site.ru/lib.js");
        img_url_resolve("http://h/dir/page", "/root/x", out, (int)sizeof(out));
        check_str("абсолютный путь от корня", out, "http://h/root/x");
        img_url_resolve("http://h/dir/page", "img/a b.png", out, (int)sizeof(out));
        check_str("относительный путь (пробел сохраняется до кодирования)",
                  out, "http://h/dir/img/a b.png");
        img_url_resolve("http://h/dir//p", "x.png", out, (int)sizeof(out));
        check_str("двойной слеш в базе свернулся", out, "http://h/dir/x.png");
        img_url_resolve("http://h/dir/a/../b", "http://h//c", out, (int)sizeof(out));
        check_str("абсолютный rel нормализуется", out, "http://h/c");

        /* локальная страница RAM disk — прежнее поведение */
        img_url_resolve("docs/page.md", "img/x.png", out, (int)sizeof(out));
        check_str("локальная база: соседний каталог", out, "docs/img/x.png");
        img_url_resolve("docs/page.md", "/logo.png", out, (int)sizeof(out));
        check_str("локальная база: корень RAM disk", out, "logo.png");

        /* пустой rel — база как есть */
        img_url_resolve("http://h/dir/page", "", out, (int)sizeof(out));
        check_str("пустой rel -> база", out, "http://h/dir/page");
    }

    /* ================= img_norm_url_path ================= */
    printf("img_norm_url_path:\n");
    {
        struct { const char *in, *want; } cases[] = {
            { "/a//b",            "/a/b" },
            { "/a//b/",           "/a/b/" },
            { "/a/./b",           "/a/b" },
            { "/a/b/../c",        "/a/c" },
            { "/a/b/../../c",     "/c" },
            { "/../x",            "/x" },
            { "/a/../../..",      "/" },
            { "/",                "/" },
            { "//",               "/" },
            { "/dir/",            "/dir/" },
            { "/a//b/?q=1",       "/a/b/?q=1" },
            { "/?x",              "/?x" },
            { "/dir/./x.png",     "/dir/x.png" },
            { "/s?next=/a//b",    "/s?next=/a//b" },   /* query не трогаем! */
            { "/s?d=aHR0//XA==",  "/s?d=aHR0//XA==" }, /* base64 в query */
        };
        for (size_t i = 0; i < sizeof(cases)/sizeof(cases[0]); i++) {
            char buf[700];
            snprintf(buf, sizeof(buf), "%s", cases[i].in);
            img_norm_url_path(buf, (int)sizeof(buf));
            char nm[64];
            snprintf(nm, sizeof(nm), "«%s»", cases[i].in);
            check_str(nm, buf, cases[i].want);
        }
    }

    /* ================= img_url_encode_path ================= */
    printf("img_url_encode_path:\n");
    {
        char out[700];

        img_url_encode_path("/a b/c", out, (int)sizeof(out));
        check_str("пробел -> %20", out, "/a%20b/c");

        img_url_encode_path("/wiki/Россия", out, (int)sizeof(out));
        check_str("кириллица UTF-8 -> %XX",
                  out, "/wiki/%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D1%8F");

        img_url_encode_path("/a%2Fb", out, (int)sizeof(out));
        check_str("готовый %2F не кодируется дважды", out, "/a%2Fb");

        img_url_encode_path("/100%?x", out, (int)sizeof(out));
        check_str("голый % -> %25, ? начинает query", out, "/100%25?x");

        img_url_encode_path("/s?x= a&b", out, (int)sizeof(out));
        check_str("пробел в query кодируется, & и = живут",
                  out, "/s?x=%20a&b");

        img_url_encode_path("/a=b;c@d&e!f$g~h'i(j)k,l-m_n.o/p", out,
                            (int)sizeof(out));
        check_str("RFC-safe символы не тронуты", out,
                  "/a=b;c@d&e!f$g~h'i(j)k,l-m_n.o/p");

        img_url_encode_path("\"<>[]\\^`{}|", out, (int)sizeof(out));
        check_str("небезопасная пунктуация кодируется", out,
                  "%22%3C%3E%5B%5D%5C%5E%60%7B%7D%7C");

        /* ёмкость: обрезание без переполнения */
        {
            char small[8];
            int el = img_url_encode_path("/abcdefghijklmn", small,
                                         (int)sizeof(small));
            CHECK("стоп по ёмкости", el < (int)sizeof(small) &&
                  strlen(small) == (size_t)el, small);
        }
    }

    /* ================= br_split_url (адресная строка/ссылки) ================= */
    printf("br_split_url:\n");
    {
        char host[128], path[256];
        u16 port;

        /* [BR-2SLASH]: главный сценарий «двух слешей в путях» */
        CHECK("ya.ru//a/./b -> /a/b",
              br_split_url("ya.ru//a/./b", 0, host, (int)sizeof(host),
                           &port, path, (int)sizeof(path)) &&
              !strcmp(host, "ya.ru") && port == 80 &&
              !strcmp(path, "/a/b"),
              path);
        check_str("  путь", path, "/a/b");

        CHECK("хвостовой '/' сохраняется",
              br_split_url("h/dir/", 0, host, 128, &port, path, 256) &&
              !strcmp(path, "/dir/"), path);

        CHECK("?query после хоста -> /?query",
              br_split_url("ya.ru?x=1", 0, host, 128, &port, path, 256) &&
              !strcmp(host, "ya.ru") && !strcmp(path, "/?x=1"), path);

        CHECK("голый хост -> /",
              br_split_url("ya.ru", 0, host, 128, &port, path, 256) &&
              !strcmp(host, "ya.ru") && !strcmp(path, "/"), path);

        CHECK("порт по умолчанию 443 для https",
              br_split_url("ya.ru/a", 1, host, 128, &port, path, 256) &&
              port == 443 && !strcmp(path, "/a"), path);

        CHECK("явный порт перезаписывает дефолт",
              br_split_url("ya.ru:8080/x", 0, host, 128, &port, path, 256) &&
              port == 8080, path);

        CHECK("неверный порт отвергается",
              !br_split_url("ya.ru:80a/x", 0, host, 128, &port, path, 256),
              "");

        /* [BR-PCT]: пробел и кириллица в пути запроса */
        CHECK("кодирование пробела и UTF-8",
              br_split_url("h.ru/фото 1.png", 0, host, 128, &port,
                           path, 256) &&
              !strcmp(path, "/%D1%84%D0%BE%D1%82%D0%BE%201.png"), path);

        CHECK("%2F не дублируется",
              br_split_url("h/a%2Fb", 0, host, 128, &port, path, 256) &&
              !strcmp(path, "/a%2Fb"), path);
    }

    /* ================= br_parse_redirect / br_http_status ================= */
    printf("br_parse_redirect:\n");
    {
        int code = 0;
        char loc[512];
        int n;
#define RESP(s) ((int)strlen(s))

        /* R1: канонический nginx 301 */
        n = br_parse_redirect(
            "HTTP/1.1 301 Moved Permanently\r\n"
            "Server: nginx\r\n"
            "Date: Wed, 28 Oct 2026 10:00:00 GMT\r\n"
            "Location: https://www.example.com/\r\n"
            "Content-Length: 0\r\n\r\n",
            RESP("HTTP/1.1 301 Moved Permanently\r\n"
                 "Server: nginx\r\n"
                 "Date: Wed, 28 Oct 2026 10:00:00 GMT\r\n"
                 "Location: https://www.example.com/\r\n"
                 "Content-Length: 0\r\n\r\n"),
            &code, loc, (int)sizeof(loc));
        CHECK("R1: nginx 301 абсолютный Location",
              n == 301 && code == 301 && !strcmp(loc, "https://www.example.com/"),
              loc);

        /* R2: только \n, заголовок в нижнем регистре */
        n = br_parse_redirect("HTTP/1.0 302\nserver: x\ncache-control: no-cache\n"
                              "location: /next?a=1\n\nbody",
                              RESP("HTTP/1.0 302\nserver: x\ncache-control: no-cache\n"
                                   "location: /next?a=1\n\nbody"),
                              &code, loc, (int)sizeof(loc));
        CHECK("R2: lowercase + \\n-only", n == 302 && !strcmp(loc, "/next?a=1"),
              loc);

        /* R3: не-редирект */
        n = br_parse_redirect("HTTP/1.1 200 OK\r\nLocation: /x\r\n\r\n", 40,
                              &code, loc, (int)sizeof(loc));
        CHECK("R3: 200 не редирект", n == 0, "");

        /* R4: 302 без Location */
        n = br_parse_redirect("HTTP/1.1 302 Found\r\n\r\n", 25,
                              &code, loc, (int)sizeof(loc));
        CHECK("R4: нет Location -> 0", n == 0, "");

        /* R5: таб после двоеточия, 303 */
        n = br_parse_redirect("HTTP/1.1 303 See Other\r\nlocation:\t/x\r\n\r\n",
                              RESP("HTTP/1.1 303 See Other\r\nlocation:\t/x\r\n\r\n"),
                              &code, loc, (int)sizeof(loc));
        CHECK("R5: 303 + таб", n == 303 && !strcmp(loc, "/x"), loc);

        /* R6: 307 и 308 */
        n = br_parse_redirect("HTTP/1.1 307 Temporary Redirect\r\nLocation: /y\r\n\r\n",
                              RESP("HTTP/1.1 307 Temporary Redirect\r\nLocation: /y\r\n\r\n"),
                              &code, loc, (int)sizeof(loc));
        CHECK("R6a: 307", n == 307 && !strcmp(loc, "/y"), loc);
        n = br_parse_redirect("HTTP/1.1 308 Permanent Redirect\r\nLocation: /z\r\n\r\n",
                              RESP("HTTP/1.1 308 Permanent Redirect\r\nLocation: /z\r\n\r\n"),
                              &code, loc, (int)sizeof(loc));
        CHECK("R6b: 308", n == 308 && !strcmp(loc, "/z"), loc);

        /* R7: длинный tracking-Location (350 байт) — раньше не влезал
         * в буфер вызывающего и редирект терялся */
        {
            char resp[600];
            char big[400];
            for (int i = 0; i < 340; i++) big[i] = (char)('a' + i % 26);
            big[340] = 0;
            int l = snprintf(resp, sizeof(resp),
                             "HTTP/1.1 302 Found\r\nLocation: /go?u=%s\r\n\r\n",
                             big);
            n = br_parse_redirect(resp, l, &code, loc, (int)sizeof(loc));
            CHECK("R7: длинный Location (350) разбирается",
                  n == 302 && (int)strlen(loc) == 346, loc);
        }

        /* R8: Location с пробелом внутри */
        n = br_parse_redirect("HTTP/1.1 302\r\nLocation: /a b.html\r\n\r\n",
                              RESP("HTTP/1.1 302\r\nLocation: /a b.html\r\n\r\n"),
                              &code, loc, (int)sizeof(loc));
        CHECK("R8: Location с пробелом", n == 302 && !strcmp(loc, "/a b.html"),
              loc);

        CHECK("R9: HTTP/1.1  302 (двойной пробел)",
              br_http_status("HTTP/1.1  302 X", 15) == 302, "");
        CHECK("R10: статус мусор -> 0", br_http_status("garbage", 7) == 0, "");
    }

    /* ================= br_parse_host ================= */
    printf("br_parse_host:\n");
    {
        char h[64];
        u16 port = 80;
        snprintf(h, sizeof(h), "ya.ru");
        CHECK("H1: без порта — дефолт не тронут",
              br_parse_host(h, &port) && !strcmp(h, "ya.ru") && port == 80, "");
        snprintf(h, sizeof(h), "ya.ru:8080");
        port = 80;
        CHECK("H2: порт 8080",
              br_parse_host(h, &port) && !strcmp(h, "ya.ru") && port == 8080, "");
        snprintf(h, sizeof(h), "h:0");
        CHECK("H3: порт 0 отвергнут", !br_parse_host(h, &port), "");
        snprintf(h, sizeof(h), "h:99999");
        CHECK("H4: порт 99999 отвергнут", !br_parse_host(h, &port), "");
        snprintf(h, sizeof(h), "h:80a");
        CHECK("H5: мусор в порту отвергнут", !br_parse_host(h, &port), "");
    }

    /* ================= meta refresh (brf_parse) ================= */
    printf("meta refresh:\n");
    {
        struct { const char *marker, *want_url; int want_delay; const char *name; }
        cases[] = {
            { "\x01REFRESH content=\"0; url='https://x.ru/a'\"\n",
              "https://x.ru/a", 0, "F1: url в одинарных кавычках" },
            { "\x01REFRESH content=\"5; URL = /next\"\n",
              "/next", 5, "F2: URL = с пробелами" },
            { "\x01REFRESH content=\"0;url=/a//b\"\n",
              "/a//b", 0, "F3: // в url сохраняется" },
            { "\x01REFRESH content=\"10\"\n",
              "", 10, "F4: без url — просто перезагрузка" },
            { "\x01REFRESH content=\"0; url=https://x.ru/a\"\n",
              "https://x.ru/a", 0, "F5: обычный вид" },
            { "\x01REFRESH content=\"0; url=&quot;https://x.ru/b&quot;\"\n",
              "https://x.ru/b", 0, "F6: url в &quot;-кавычках" },
            { "\x01REFRESH content=\"30;URL=http://ya.ru\"\n",
              "http://ya.ru", 30, "F7: URL= без пробела" },
            { "\x01REFRESH content=\"0;\turl =\t/x\"\n",
              "/x", 0, "F8: табы" },
            { "\x01REFRESH content=\"0; url='https://x.ru/статья 2'\"\n",
              "https://x.ru/статья 2", 0, "F9: кавычки + пробел в пути" },
        };
        for (size_t i = 0; i < sizeof(cases)/sizeof(cases[0]); i++) {
            char md[512];
            brf_forms_t forms;
            int ml = snprintf(md, sizeof(md), "%s", cases[i].marker);
            memset(&forms, 0, sizeof(forms));
            brf_parse(&forms, md, ml);
            char d[700];
            snprintf(d, sizeof(d), "url=\"%s\" (delay %d), ожидалось \"%s\" (%d)",
                     forms.refresh_url, forms.refresh_delay,
                     cases[i].want_url, cases[i].want_delay);
            CHECK(cases[i].name,
                  strcmp(forms.refresh_url, cases[i].want_url) == 0 &&
                  forms.refresh_delay == cases[i].want_delay, d);
            brf_reset(&forms);
        }
    }

    /* ================= img_decode_url: путь картинки ================= */
    printf("img_decode_url (путь GET через заглушку сети):\n");
    {
        img_t img;
        /* двойной слеш + точечные сегменты + кириллица (пробел imgsvc
         * традиционно вырезает из src до разбора — поведение не менял) */
        g_last_http_path[0] = 0;
        img_decode_url("http://h.ru//foto/./albom/фото 1.png", NULL, &img);
        check_str("путь картинки нормализован и закодирован",
                  g_last_http_path, "/foto/albom/%D1%84%D0%BE%D1%82%D0%BE1.png");

        g_last_http_path[0] = 0;
        img_decode_url("HTTP://H.RU:8080//a/./b?x=1", NULL, &img);
        CHECK("верхний регистр схемы/хоста + порт + //",
              !strcmp(g_last_http_path, "/a/b?x=1"),
              g_last_http_path);

        /* относительная ссылка на сетевой странице: разрешение против
         * базы, затем нормализация/кодирование в img_parse_http */
        g_last_http_path[0] = 0;
        img_decode_url("img//big/../p.png", "http://h.ru/dir/page", &img);
        check_str("относительная картинка -> resolved+normalized",
                  g_last_http_path, "/dir/img/p.png");
    }

    printf("\nИтог: %d PASS, %d FAIL\n", PASS, FAIL);
    return FAIL ? 1 : 0;
}
