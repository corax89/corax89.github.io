/* shim: sync.h для host-тестов (замок — no-op, тесты однопоточные) */
#ifndef SHIM_SYNC_H
#define SHIM_SYNC_H
static inline void s_lock(volatile int *l)   { (void)l; }
static inline void s_unlock(volatile int *l) { (void)l; }
#endif
