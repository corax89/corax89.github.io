/* shim: net.h для host-тестов (сеть заглушается) */
#ifndef SHIM_NET_H
#define SHIM_NET_H
#include "types.h"

int  net_http_get(const char *host, u16 port, const char *path,
                  char *response, u32 max_len, u32 max_ms);
int  net_http_post(const char *host, u16 port, const char *path,
                   const char *body, const char *content_type,
                   char *response, u32 max_len, u32 max_ms);
const char *net_http_errstr(void);
int  net_host_is_loopback(const char *host);
int  net_nic_present(void);
u32  net_get_ip(void);
void net_ntoa(u32 ip, char *out, int out_max);
#endif
