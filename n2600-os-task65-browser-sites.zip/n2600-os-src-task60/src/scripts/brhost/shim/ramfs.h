/* shim: ramfs.h для host-тестов (пустой RAM disk; тесты URL-логики
 * не зависят от содержимого) */
#ifndef SHIM_RAMFS_H
#define SHIM_RAMFS_H
#include "types.h"

#define RAMFS_NAME_MAX 64

typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    u32  size;
} ramfs_dirent_t;

int  ramfs_list(ramfs_dirent_t *out, int max);
int  ramfs_create(const char *name, u32 size);
int  ramfs_write(const char *name, const void *buf, u32 size);
u32  ramfs_read(const char *name, void *buf, u32 max);
int  ramfs_delete(const char *name);
#endif
