/* shim: string.h для host-тестов (замена kernel string.h).
 * include_next — уходим на системный <string.h> мимо -Ishim. */
#ifndef SHIM_STRING_H
#define SHIM_STRING_H
#include_next <string.h>
#include <stdio.h>
#endif
