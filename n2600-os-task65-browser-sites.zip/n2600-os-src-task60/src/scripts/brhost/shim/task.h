/* shim: task.h для host-тестов (imgsvc.c включает, но не использует) */
#ifndef SHIM_TASK_H
#define SHIM_TASK_H
#endif
