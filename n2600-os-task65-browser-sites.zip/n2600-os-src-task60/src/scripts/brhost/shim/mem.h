/* shim: mem.h для host-тестов (замена kernel mem.h) */
#ifndef SHIM_MEM_H
#define SHIM_MEM_H
#include <stdlib.h>
#include <string.h>
#endif
