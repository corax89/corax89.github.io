/* test_symtab_host.c — host-тест sym_lookup по реальной сгенерированной
 * таблице (build/symtab/symtab.c). Запускается после сборки.
 * Сборка: gcc -m32 -Isrc -o /tmp/test_symtab scripts/test_symtab_host.c build/symtab/symtab.o
 */
#include <stdio.h>
#include <string.h>
#include "symtab.h"

static int fails = 0;
static void chk(int cond, const char *what)
{
    if (!cond) { printf("  FAIL: %s\n", what); fails++; }
}

int main(void)
{
    /* граничные случаи */
    chk(sym_count() > 1000, "sym_count > 1000");
    chk(sym_lookup(0x000u, 0) == 0, "адрес 0 -> NULL");
    chk(sym_lookup(0xFFF00u, 0) == 0, "адрес ниже первого символа -> NULL");

    /* точное попадание в несколько известных функций: sym_lookup(addr)
     * обязан вернуть ИМЕННО эту функцию (адреса функций монотонны и
     * уникальны для начала функции) */
    const char *names[] = { "kmain", "exc_panic", "wm_frame", "fb_flush_rects",
                            "gma3600_2d_ram_to_screen", "voodoo3_init",
                            "gfx2d_active", "task_schedule" };
    int found_any = 0;
    for (unsigned i = 0; i < sizeof(names)/sizeof(names[0]); i++) {
        /* найти адрес этой функции перебором (тест — вне ядра) */
        extern int sym_count(void);
        /* прямой доступ к таблице невозможен (static) — ищем через
         * сканирование адресов: берём addr из stdout nm нельзя; поэтому
         * проверяем через известный адрес kmain, полученный снаружи */
        (void)names[i];
    }
    (void)found_any;

    /* известные адреса из nm (вставляются сборочным скриптом ниже) */
    struct { u32 addr; const char *name; } known[] = {
#ifdef KNOWN_SYMBOLS
#include "known_syms.h"
#endif
    };
    if (sizeof(known) / sizeof(known[0]) == 0) {
        printf("  (известные адреса не переданы — пропускаем точечные проверки)\n");
    }
    for (unsigned i = 0; i < sizeof(known)/sizeof(known[0]); i++) {
        u32 off = 0xFFFFFFFFu;
        const char *s = sym_lookup(known[i].addr, &off);
        printf("  %08x -> %s+0x%x (ожидалось %s)\n",
               (unsigned)known[i].addr, s ? s : "(null)", (unsigned)off, known[i].name);
        chk(s && strcmp(s, known[i].name) == 0, "имя совпало");
        chk(off == 0, "смещение 0 в начале функции");
        /* середина функции: то же имя, смещение > 0. Функции бывают и
         * крошечные (sym_count ~6 байт) — mid-проверку гоняем только по
         * большой функции kmain. */
        if (strcmp(known[i].name, "kmain") == 0) {
            s = sym_lookup(known[i].addr + 0x40, &off);
            chk(s && strcmp(s, "kmain") == 0, "имя в середине функции");
            chk(off == 0x40, "смещение 0x40");
        }
    }
    if (fails) { printf("ИТОГ: ПРОВАЛ (%d)\n", fails); return 1; }
    printf("ИТОГ: все проверки symtab пройдены\n");
    return 0;
}
