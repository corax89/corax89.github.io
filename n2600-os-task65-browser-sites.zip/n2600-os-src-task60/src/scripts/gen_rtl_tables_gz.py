#!/usr/bin/env python3
"""gen_rtl_tables_gz.py — генерация rtl8192eu_tables.h со СЖАТЫМИ таблицами.

Инициализационные таблицы RTL8192EU ({addr,val}) в сумме занимают ~4.5КБ
.runtime; gzip -9 даёт ~2КБ. Формат нового заголовка:
  - один gzip-блоб rtl8192eu_tab_gz[] (весь поток таблиц);
  - на каждую таблицу макрос ИМЕНИ, дающий указатель на её место в
    РАСПАКОВАННОМ буфере rtl8192eu_tab_plain[] (.bss драйвера);
  - распаковка — gz_inflate_gzip() один раз (rtl_tabs_ready() в rtl8192eu.c).
Все потребители ходят по таблицам до сентинела (0xffff/0xffffffff или
0xff/0xffffffff), поэтому указатели полностью заменяют массивы.

Запуск: python3 scripts/gen_rtl_tables_gz.py
"""
import gzip, io, os, re, struct, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TBL_H = os.path.join(BASE, "src", "rtl8192eu_tables.h")

def read_tables():
    """[(name, type, packed_bytes)] в порядке объявления."""
    text = open(TBL_H, encoding='utf-8', errors='replace').read()
    # вырезаем текущую реализацию: массивы начинаются после typedef'ов
    body = text[text.index("#endif /* RTL8192EU_TABLES_H */"):] if False else text
    pat = re.compile(r'static const (rtl_tab8_entry_t|rtl_tab_entry_t)\s+(\w+)\[\]\s*=\s*\{(.*?)\};', re.S)
    out = []
    for m in pat.finditer(body):
        typ, name, src = m.group(1), m.group(2), m.group(3)
        blob = b""
        for a, v in re.findall(r'\{\s*(0[xX][0-9a-fA-F]+|\d+)\s*,\s*(0[xX][0-9a-fA-F]+|\d+)\s*\}', src):
            a_i, v_i = int(a, 0), int(v, 0)
            if typ == "rtl_tab_entry_t":
                blob += struct.pack("<HxxI", a_i, v_i)     # u16 addr, pad, u32 val
            else:
                blob += struct.pack("<HBB", a_i, v_i & 0xFF, 0)  # u16 addr, u8 val, pad
        # сентинел-проверки (как в потребителях rtl8192eu.c):
        # 32-битные таблицы: BB/AGC — {0xffff, 0xffffffff}, RF — {0xff, 0xffffffff}
        if typ == "rtl_tab_entry_t":
            last = blob[-8:]
            ok = (last[4:] == b"\xff\xff\xff\xff"
                  and last[:2] in (b"\xff\xff", b"\xff\x00")
                  and last[2:4] == b"\x00\x00")
            assert ok, f"{name}: нет сентинела в конце"
        else:
            last = blob[-4:]
            assert last == b"\xff\xff\xff\x00", f"{name}: нет сентинела (tab8) в конце"
        out.append((name, typ, blob))
    assert len(out) == 5, f"ожидалось 5 таблиц, найдено {len(out)}"
    return out

def gz9(data):
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', compresslevel=9, mtime=0) as f:
        f.write(data)
    return buf.getvalue()

def main():
    tables = read_tables()
    stream = b"".join(t[2] for t in tables)
    total = len(stream)
    gzb = gz9(stream)

    L = []
    w = L.append
    w('/* rtl8192eu_tables.h — init-таблицы RTL8192EU для N2600-OS.')
    w(' * Сгенерировано scripts/gen_rtl_tables_gz.py из эталонного драйвера')
    w(' * Linux rtl8xxxu (GPLv2, файлы rtl8xxxu_8192e.c, редакция 6.6),')
    w(' * предыдущий (НЕсжатый) вариант — scripts/gen_rtl_tables.py.')
    w(' *')
    w(' * [GZIP-TAB] (Task 63): таблицы хранятся ОДНИМ gzip-блобом:')
    w(' *   %d -> %d байт (экономия %d байт kernel.bin).' % (total, len(gzb), total - len(gzb)))
    w(' * Распаковка один раз в rtl8192eu_tab_plain[] (.bss) —')
    w(' * rtl_tabs_ready() (rtl8192eu.c) перед первым использованием.')
    w(' * Имена таблиц — теперь МАКРОСЫ-указатели в распакованный буфер:')
    w(' * все потребители ходят до сентинела, sizeof не используется.')
    w(' *')
    w(' * rtl8192e_mac_init_table   — MAC-регистры (байтовые записи)')
    w(' * rtl8192eu_phy_init_table  — BB/OFDM регистры (32-бит)')
    w(' * rtl8xxxu_agc_8192eu_std_table — AGC таблица')
    w(' * rtl8192eu_radio[a/b]_init_table — RF (косвенно через HSSI)')
    w(' * Формат записей прежний: {addr, value}; конец = сентинел. */')
    w('#ifndef RTL8192EU_TABLES_H')
    w('#define RTL8192EU_TABLES_H')
    w('')
    w('#include "types.h"')
    w('')
    w('typedef struct { u16 addr; u32 val; } rtl_tab_entry_t;')
    w('typedef struct { u16 addr; u8  val; } rtl_tab8_entry_t;')
    w('')
    w('#define RTL8192EU_TAB_WORDS   %du   /* u32-слов в распакованном буфере */' % (total // 4))
    w('#define RTL8192EU_TAB_GZ_SIZE %du   /* сжатый блоб (gzip -9) */' % len(gzb))
    w('')
    w('/* блоб (ниже) и буфер распаковки объявлены в rtl8192eu.c */')
    for name, typ, blob in tables:
        off = sum(len(t[2]) for t in tables[:[t[0] for t in tables].index(name)])
        cnt = len(blob) // (8 if typ == "rtl_tab_entry_t" else 4)
        w('/* %s: %d записей, оффсет %d (байт) */' % (name, cnt, off))
        w('#define %s ((const %s *)(const void *)(rtl8192eu_tab_plain + %du))'
          % (name, typ, off))
    w('')
    w('/* сжатые таблицы (gzip -9): */')
    w('static const u8 rtl8192eu_tab_gz[RTL8192EU_TAB_GZ_SIZE] = {')
    for i in range(0, len(gzb), 20):
        w('    ' + ','.join('0x%02x' % b for b in gzb[i:i + 20]) + ',')
    w('};')
    w('')
    w('#endif /* RTL8192EU_TABLES_H */')

    open(TBL_H, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print(f"rtl8192eu_tables.h: {total} -> {len(gzb)} байт gzip (экономия {total-len(gzb)})")
    return 0

if __name__ == "__main__":
    sys.exit(main())
