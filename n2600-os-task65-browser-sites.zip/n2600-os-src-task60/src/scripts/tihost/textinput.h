/* textinput.h — переиспользуемый ОДНОСТРОЧНЫЙ виджет ввода текста
 * N2600-OS (Task 64 [TI-WIDGET]). Header-only ЯДРО (без отрисовки —
 * она в textinput.c), самодостаточно: работает в ядре и в хост-тестах.
 *
 * ЗАЧЕМ. Клавиатура шлёт кириллицу СЕРИЕЙ UTF-8-байтов (2 байта на
 * букву), а самодельные поля ввода в терминале/диалогах/браузере
 * считали БАЙТЫ: курсор уезжал на два символа, Backspace стирал
 * ПОЛБУКВЫ (битый UTF-8), русский ввод в диалоги вообще не проходил
 * (фильтр 0x20..0x7F). Каждый чинил по-своему. Теперь ОДИН виджет:
 *
 *   - буфер ВНЕШНИЙ (embedder даёт char[] — виджет НЕ аллоцирует);
 *   - курсор в БАЙТАХ, всегда на границе символа (utf8_align_back);
 *   - перемещение/удаление — по СИМВОЛАМ (не байтам);
 *   - вставка в произвольную позицию (не только append);
 *   - лимит в СИМВОЛАХ (max_chars) и/или ёмкость буфера (cap байт);
 *   - Ctrl+V — вставка из буфера обмена через paste_fn (embedder
 *     подставляет clip_text_get; в хост-тестах — свой);
 *   - режим password (отрисовка '*' — в textinput.c).
 *
 * ПРАВИЛО ДЛЯ ВСТРОЯТЕЛЕЙ (терминал, диалоги, браузер, скриптовые
 * окна): рисует embedder (ti_draw_box/ti_draw_inline из textinput.c
 * или своими примитивами), клавиши — ti_key, текст — ti_text.
 *
 * C API (виджет): ti_init/ti_reset/ti_key/ti_text/ti_chars/
 *   ti_cur_char/ti_insert_bytes/ti_backspace/ti_delete/ti_move/
 *   ti_home/ti_end/ti_view_off/ti_draw_box/ti_draw_inline.
 *
 * JS API (скриптовые окна, mquickjs_api.c): ti_add(win,x,y,w,maxlen)
 *   — поле в окне скрипта; ti_get(win) — строка; ti_set(win,s) —
 *   записать; ti_entered(win) — 1, если в поле нажали Enter.
 *   (Один виджет на окно; фокус — клик по полю, Enter отдаётся
 *   скрипту через флаг.)
 */
#ifndef TEXTINPUT_H
#define TEXTINPUT_H

#include "types.h"
#include "kbd.h"
#include "utf8.h"

/* Отрисовка (textinput.c — только ядро; в хост-тестах не линкуется). */
struct ti_s;
void ti_draw_box(struct ti_s *ti, int x, int y, int w, int h, int focused);
int  ti_draw_inline(struct ti_s *ti, int x, int y, int max_px, u32 fg);

#ifdef __cplusplus
extern "C" {
#endif

/* ---- результаты ti_key (что сделал виджет) ---- */
#define TI_K_IGNORE  0   /* клавиша не для виджета — решает embedder */
#define TI_K_EATEN   1   /* обработана (вставка/курсор/удаление) */
#define TI_K_ENTER   2   /* Enter (текст не тронут) */
#define TI_K_ESC     3   /* Esc (embedder: снять фокус/закрыть диалог) */

/* Виджет: НЕ владеет буфером, только указатель. Копируйте структуру
 * осторожно (buf остаётся общим) — лучше держать ti_t в одном месте. */
typedef struct ti_s {
    char *buf;               /* внешний буфер, NUL-терминирован */
    int   cap;               /* ёмкость буфера В БАЙТАХ (вкл. место под '\0') */
    int   len;               /* занято байт (без '\0') */
    int   cur;               /* курсор, БАЙТЫ, всегда на границе символа */
    int   max_chars;         /* лимит СИМВОЛОВ (0 = без лимита, кроме cap) */
    int   password;          /* 1 = рисовать '*' вместо символов */
    int   multiline;         /* 1 = Enter вставляет '\n' (textarea),
                              * а не отдаётся embedder'у как TI_K_ENTER */
    int   rejected;          /* 1 = последний ввод НЕ поместился (embedder
                              * показывает «Слишком длинное имя»); сброс —
                              * любая успешная вставка/удаление */
    int   view_off;          /* байтовое смещение первого видимого символа
                              * (считает ti_view_off, использует отрисовка) */
    /* Ctrl+V: откуда брать буфер обмена (NULL = вставка выключена).
     * Возвращает NUL-терминированный текст или NULL. */
    const char *(*paste_fn)(void);
} ti_t;

/* Привязать внешний буфер (cap — полная ёмкость, включая '\0'). */
static inline void ti_init(ti_t *ti, char *buf, int cap)
{
    ti->buf = buf;
    ti->cap = cap > 0 ? cap : 1;
    ti->len = 0;
    ti->cur = 0;
    ti->max_chars = 0;
    ti->password = 0;
    ti->multiline = 0;
    ti->rejected = 0;
    ti->view_off = 0;
    ti->paste_fn = (const char *(*)(void))0;
    buf[0] = 0;
}

/* Заменить текст целиком (курсор в конец). */
static inline void ti_reset(ti_t *ti, const char *text)
{
    int i = 0;
    if (text)
        while (text[i] && i < ti->cap - 1) { ti->buf[i] = text[i]; i++; }
    ti->buf[i] = 0;
    ti->len = i;
    ti->cur = i;
    ti->rejected = 0;
    ti->view_off = 0;
}

static inline const char *ti_text(const ti_t *ti) { return ti->buf; }
static inline int         ti_len(const ti_t *ti)  { return ti->len; }

/* Число СИМВОЛОВ во всём тексте (кириллица = 1, не 2). */
static inline int ti_chars(const ti_t *ti)
{
    return utf8_count_chars(ti->buf, ti->len);
}

/* Позиция курсора в СИМВОЛАХ от начала строки (для пиксельных карт). */
static inline int ti_cur_char(const ti_t *ti)
{
    return utf8_count_chars(ti->buf, ti->cur);
}

/* Убедиться, что cur — на границе символа (после внешних правок buf). */
static inline void ti_snap(ti_t *ti)
{
    if (ti->cur < 0) ti->cur = 0;
    if (ti->cur > ti->len) ti->cur = ti->len;
    ti->cur = utf8_align_back(ti->buf, ti->cur);
}

/* Вставить n байт (UTF-8-строка s) В ПОЗИЦИЮ КУРСОРА. Контроль:
 *  - не превысить cap (обрезка — по границе символа);
 *  - не превысить max_chars СИМВОЛОВ;
 *  - управляющие байты (<0x20 и 0x7F) пропускаются.
 * Возвращает число ВСТАВЛЕННЫХ байт (0 = не поместилось; rejected=1). */
static inline int ti_insert_bytes(ti_t *ti, const char *s, int n)
{
    int room = ti->cap - 1 - ti->len;
    /* запас по СИМВОЛАМ до max_chars (вставка идёт в курсор — до него) */
    int lim_chars = ti->max_chars > 0
                        ? ti->max_chars - utf8_count_chars(ti->buf, ti->cur)
                        : 0;
    int inserted = 0, i = 0;
    ti->rejected = 0;
    while (i < n && s[i]) {
        unsigned char c = (unsigned char)s[i];
        int need = utf8_seq_len(c);       /* место под ЦЕЛЫЙ символ */
        int adv = need;
        if (n > 1 && adv > n - i) break;  /* paste: не рвать символ на хвосте */
        if (n == 1) adv = 1;              /* событие kbd — ОДИН байт (серия
                                           * событий склеится в символ) */
        if ((c < 0x20 && !(c == '\n' && ti->multiline)) || c == 0x7F)
            { i++; continue; }               /* управляющие ('\n' в
                                              * multiline — исключение) */
        /* Продолжающий байт (0x80..0xBF) валиден ТОЛЬКО если завершает
         * начатую перед курсором последовательность (иначе — «сирота»:
         * его lead был отвергнут капом/лимитом — не портить UTF-8). */
        if ((c & 0xC0) == 0x80) {
            int back = 0;          /* cont-байтов между lead'ом и курсором */
            int seq = 0;           /* длина seq lead'а (0 = lead'а нет) */
            while (back < 3 && ti->cur - 1 - back >= 0) {
                unsigned char pb =
                    (unsigned char)ti->buf[ti->cur - 1 - back];
                if ((pb & 0xC0) == 0x80) { back++; continue; }
                if      ((pb & 0xE0) == 0xE0) seq = 3;   /* lead 3-байтной */
                else if ((pb & 0xC0) == 0xC0) seq = 2;   /* lead 2-байтной */
                break;                                   /* ASCII/мусор: 0 */
            }
            if (seq < 2 || back >= seq - 1) {
                ti->rejected = 1;        /* ввод не принят целиком */
                i++;
                continue;
            }
        }
        /* не влезает по байтам (проверка под целый символ: иначе у края
         * оставался бы «повисший» lead-байт — битый UTF-8) */
        if (need > room) { ti->rejected = 1; break; }
        if (ti->max_chars > 0 && lim_chars <= 0) { ti->rejected = 1; break; }
        /* сдвинуть хвост вправо на adv (включая '\0') */
        for (int k = ti->len; k >= ti->cur; k--)
            ti->buf[k + adv] = ti->buf[k];
        for (int k = 0; k < adv; k++)
            ti->buf[ti->cur + k] = s[i + k];
        ti->cur += adv;
        ti->len += adv;
        room -= adv;
        lim_chars--;
        inserted += adv;
        i += adv;
    }
    ti->buf[ti->len] = 0;
    return inserted;
}

/* Удобство: вставить один ASCII-символ. */
static inline int ti_insert_char(ti_t *ti, char ch)
{
    return ti_insert_bytes(ti, &ch, 1);
}

/* Backspace: удалить СИМВОЛ ПЕРЕД курсором (целый UTF-8). */
static inline int ti_backspace(ti_t *ti)
{
    ti->rejected = 0;
    if (ti->cur <= 0) return 0;
    int start = utf8_align_back(ti->buf, ti->cur - 1);
    int cut = ti->cur - start;
    for (int k = start; k <= ti->len - cut; k++)
        ti->buf[k] = ti->buf[k + cut];
    ti->len -= cut;
    ti->cur = start;
    return 1;
}

/* Delete: удалить СИМВОЛ НА курсоре. */
static inline int ti_delete(ti_t *ti)
{
    ti->rejected = 0;
    if (ti->cur >= ti->len) return 0;
    int adv = utf8_seq_len((unsigned char)ti->buf[ti->cur]);
    if (ti->cur + adv > ti->len) adv = ti->len - ti->cur;
    for (int k = ti->cur; k <= ti->len - adv; k++)
        ti->buf[k] = ti->buf[k + adv];
    ti->len -= adv;
    return 1;
}

/* Курсор влево/вправо НА СИМВОЛ (dir < 0 — влево). */
static inline int ti_move(ti_t *ti, int dir)
{
    if (dir < 0) {
        if (ti->cur <= 0) return 0;
        ti->cur = utf8_align_back(ti->buf, ti->cur - 1);
    } else {
        if (ti->cur >= ti->len) return 0;
        ti->cur += utf8_seq_len((unsigned char)ti->buf[ti->cur]);
        if (ti->cur > ti->len) ti->cur = ti->len;
    }
    return 1;
}

static inline void ti_home(ti_t *ti) { ti->cur = 0; }
static inline void ti_end(ti_t *ti)  { ti->cur = ti->len; }

/* Окно видимости: сместить view_off так, чтобы курсор был виден при
 * ширине avail_chars СИМВОЛОВ (возвращает view_off, байты). */
static inline int ti_view_off(ti_t *ti, int avail_chars)
{
    if (avail_chars < 1) avail_chars = 1;
    int total = utf8_count_chars(ti->buf, ti->len);
    int curc = utf8_count_chars(ti->buf, ti->cur);
    if (total <= avail_chars) { ti->view_off = 0; return 0; }
    /* окно [view_char, view_char+avail); держим курсор внутри */
    int view_char = utf8_count_chars(ti->buf, ti->view_off);
    if (curc < view_char) view_char = curc;
    if (curc >= view_char + avail_chars) view_char = curc - avail_chars + 1;
    if (view_char > total - avail_chars) view_char = total - avail_chars;
    if (view_char < 0) view_char = 0;
    ti->view_off = utf8_take_bytes(ti->buf, ti->len, view_char);
    return ti->view_off;
}

/* ГЛАВНЫЙ ВХОД: обработать клавишу. Возвращает TI_K_*.
 * Обрабатывает: печатные ASCII + UTF-8-байты (>=0x80; серия событий
 * от kbd склеивается в символ сама), Backspace/Delete, стрелки,
 * Home/End, Ctrl+V (через paste_fn). Enter/Esc — КОДЫ embedder'у. */
static inline int ti_key(ti_t *ti, const key_event_t *ev)
{
    if (ev->flags & KF_RELEASED) return TI_K_IGNORE;

    if (ev->code == 0x1C || ev->ch == '\n' || ev->ch == '\r') {
        if (ti->multiline && ev->ch != '\r') {
            char nl = '\n';
            ti_insert_bytes(ti, &nl, 1);   /* исключение из фильтра <0x20 */
            return TI_K_EATEN;
        }
        return TI_K_ENTER;
    }
    if (ev->ch == 0x1B || ev->code == 0x01)
        return TI_K_ESC;

    if (ev->code == 0x0E || ev->ch == '\b') {           /* Backspace */
        ti_backspace(ti);
        return TI_K_EATEN;
    }
    if (ev->code == 0x53) {                             /* Delete */
        ti_delete(ti);
        return TI_K_EATEN;
    }
    if (ev->code == KBD_LEFT)  { ti_move(ti, -1); return TI_K_EATEN; }
    if (ev->code == KBD_RIGHT) { ti_move(ti, +1); return TI_K_EATEN; }
    if (ev->code == 0x47) { ti_home(ti); return TI_K_EATEN; }  /* Home */
    if (ev->code == 0x4F) { ti_end(ti);  return TI_K_EATEN; }  /* End */

    /* Ctrl+V — вставка из буфера обмена (если embedder дал paste_fn) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'v' || ev->ch == 'V' || ev->code == 0x2F)) {
        if (ti->paste_fn) {
            const char *t = ti->paste_fn();
            if (t && t[0]) {
                int n = 0;
                while (t[n]) n++;
                ti_insert_bytes(ti, t, n);
            }
        }
        return TI_K_EATEN;
    }

    /* Ctrl+X/C/A и прочие ctrl-комбинации — НЕ для виджета */
    if (ev->flags & KF_CTRL) return TI_K_IGNORE;

    if ((ev->ch >= 0x20 && ev->ch < 0x7F) || (unsigned char)ev->ch >= 0x80) {
        ti_insert_bytes(ti, &ev->ch, 1);
        return TI_K_EATEN;
    }
    return TI_K_IGNORE;
}

#ifdef __cplusplus
}
#endif

#endif /* TEXTINPUT_H */
