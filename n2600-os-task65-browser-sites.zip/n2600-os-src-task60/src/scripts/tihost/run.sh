#!/bin/sh
# run.sh — хост-тест ЯДРА виджета ввода текста (Task 64 [TI-WIDGET])
# на РЕАЛЬНОМ src/textinput.h (+ src/utf8.h, shim kbd.h/types.h).
# Запуск: sh scripts/tihost/run.sh
set -e
cd "$(dirname "$0")"
[ -f shim/kbd.h ] || mkdir -p shim && cp ../../src/kbd.h shim/kbd.h
cp ../../src/types.h .
cp ../../src/utf8.h .
cp ../../src/textinput.h .
gcc -DHOST_TEST -g -O1 -fsanitize=address,undefined -Ishim -I. \
    -o test_textinput test_textinput.c
./test_textinput
