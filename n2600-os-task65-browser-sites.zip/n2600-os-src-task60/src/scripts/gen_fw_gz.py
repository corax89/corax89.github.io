#!/usr/bin/env python3
"""gen_fw_gz.py — генерация rtl8192eu_fw.c со СЖАТОЙ (gzip) прошивкой.

Читает РАСПАКОВАННУЮ прошивку из оригинального rtl8192eu_fw.c
(массив rtl8192eu_fw_data[RTL8192EU_FW_SIZE]), сжимает gzip -9 и
записывает новый rtl8192eu_fw.c с массивом rtl8192eu_fw_gz[].
Распаковка в ядре: gz_inflate_gzip() при загрузке драйвера
(см. rtl8192eu.c, rtl_fw_get()).

Запуск:  python3 scripts/gen_fw_gz.py            (обновляет src/rtl8192eu_fw.c)
Проверка: python3 scripts/gen_fw_gz.py --check   (только сверить, не писать)
"""
import io, gzip, os, re, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FW_C = os.path.join(BASE, "src", "rtl8192eu_fw.c")

def read_original():
    text = open(FW_C, encoding='utf-8', errors='replace').read()
    m = re.search(r'#define\s+RTL8192EU_FW_SIZE\s+(\d+)u', text)
    assert m, "RTL8192EU_FW_SIZE not found"
    size = int(m.group(1))
    m = re.search(r'const u8\s+rtl8192eu_fw_data\[[^\]]*\]\s*=\s*\{(.*?)\};', text, re.S)
    assert m, "fw array not found"
    vals = re.findall(r'0[xX][0-9a-fA-F]{1,2}', m.group(1))
    data = bytes(int(v, 0) for v in vals)
    assert len(data) == size, f"array {len(data)} != {size}"
    return data

def gz9(data):
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', compresslevel=9, mtime=0) as f:
        f.write(data)
    return buf.getvalue()

def emit(data, gzb):
    lines = []
    w = lines.append
    w('/* rtl8192eu_fw.c — прошивка RTL8192EU (rtlwifi/rtl8192eu_nic.bin),')
    w(' * встроена в ядро: ОС не читает файлы с диска до поднятия WiFi.')
    w(' * Источник: linux-firmware (GPL), версия 35.7, подпись 0x92e1,')
    w(' * размер 32286 байт (вместе с 32-байтовым заголовком прошивки).')
    w(' *')
    w(' * [GZIP-FW] (Task 63) прошивка хранится СЖАТОЙ (gzip -9, RFC 1952):')
    w(' *   %d -> %d байт (экономия %d байт kernel.bin).' % (len(data), len(gzb), len(data) - len(gzb)))
    w(' * Распаковка — gz_inflate_gzip() из gunzip.c (общий с PNG-декодером')
    w(' * и ini-таблицами движок), один раз при загрузке драйвера, см.')
    w(' * rtl_fw_get() в rtl8192eu.c: буфер rtl_fw_plain[] в .bss.')
    w(' * Регенерация: python3 scripts/gen_fw_gz.py (исходник массива —')
    w(' * распакованный rtl8192eu_fw_data из git-истории / linux-firmware). */')
    w('#include "types.h"')
    w('')
    w('#define RTL8192EU_FW_SIZE %du        /* распакованная прошивка */' % len(data))
    w('#define RTL8192EU_FW_GZ_SIZE %du     /* сжатый блоб (gzip) */' % len(gzb))
    w('')
    w('const u8 rtl8192eu_fw_gz[RTL8192EU_FW_GZ_SIZE] = {')
    for i in range(0, len(gzb), 20):
        chunk = gzb[i:i + 20]
        w('    ' + ','.join('0x%02x' % b for b in chunk) + ',')
    w('};')
    return '\n'.join(lines) + '\n'

def main():
    data = read_original()
    gzb = gz9(data)
    # самопроверка распаковки до записи
    dec = gzip.decompress(gzb)
    assert dec == data, "gzip roundtrip failed"
    out = emit(data, gzb)
    if "--check" in sys.argv:
        cur = open(FW_C, encoding='utf-8').read()
        print("CHECK:", "OK (файл актуален)" if cur == out else "УСТАРЕЛ (нужен запуск без --check)")
        return 0
    open(FW_C, 'w', encoding='utf-8').write(out)
    print(f"rtl8192eu_fw.c: {len(data)} -> {len(gzb)} байт gzip (экономия {len(data)-len(gzb)})")
    return 0

if __name__ == "__main__":
    sys.exit(main())
