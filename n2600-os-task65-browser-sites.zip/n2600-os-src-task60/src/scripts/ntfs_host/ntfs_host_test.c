/* ntfs_host_test.c — host-тесты слоя дисков/NTFS N2600-OS (Task 55).
 *
 * Freestanding x86-64-бинарник (-nostdlib, syscall): компилируется
 * ВМЕСТЕ с НАСТОЯЩИМИ src/disk.c, src/ntfs.c, src/string.c.
 *   - shim/sync.h (первым в -I) тенирует src/sync.h — no-op локи;
 *   - ahci/ata подменяются заглушками поверх файла-образа.
 *
 * Проверяется ПОЛНЫЙ путь, как в ОС:
 *   part_scan_impl (MBR/EBR/GPT) → disk_part_fstype → ntfs_init(_part)
 *   → ntfs_list("/") / ntfs_list("/big") → ntfs_read_file.
 */
#include "types.h"

/* ===================== системные вызовы x86-64 ========================== */
static long sys_call3(long n, long a, long b, long c)
{
    long r;
    __asm__ __volatile__("syscall"
                         : "=a"(r)
                         : "a"(n), "D"(a), "S"(b), "d"(c)
                         : "rcx", "r11", "memory");
    return r;
}
#define SYS_EXIT   60
#define SYS_READ   0
#define SYS_WRITE  1
#define SYS_OPEN   2
#define SYS_CLOSE  3
#define SYS_LSEEK  8

static long sys_open(const char *p)  { return sys_call3(SYS_OPEN, (long)p, 0, 0); }
static long sys_read(int fd, void *b, long n) { return sys_call3(SYS_READ, fd, (long)b, n); }
static long sys_write(int fd, const void *b, long n) { return sys_call3(SYS_WRITE, fd, (long)b, n); }
static long sys_lseek(int fd, long off, int wh) { return sys_call3(SYS_LSEEK, fd, off, wh); }
static void sys_exit(int c) { sys_call3(SYS_EXIT, c, 0, 0); __builtin_unreachable(); }
static long sys_close(int fd) { return sys_call3(SYS_CLOSE, fd, 0, 0); }

static void print(const char *s)
{
    long n = 0;
    while (s[n]) n++;
    sys_write(1, s, n);
}
void serial_puts(const char *s) { print(s); }

/* ===================== куча (bump) ===================================== */
static u8  g_heap[8 * 1024 * 1024];
static u32 g_heap_pos;
void *malloc(u32 n)
{
    n = (n + 15u) & ~15u;
    if (g_heap_pos + n > sizeof(g_heap)) return 0;
    void *p = &g_heap[g_heap_pos];
    g_heap_pos += n;
    return p;
}
void free(void *p) { (void)p; }

#include "string.h"   /* freestanding-ветка: strcmp/memcpy/snprintf… */

/* ===================== 64-битные div/mod (хвост для -m32) =============== */
#pragma GCC diagnostic ignored "-Wunused-function"
static u64 udivmod64(u64 n, u64 d, u64 *rem)
{
    u64 q = 0, r = 0;
    if (!d) return 0;
    for (int i = 63; i >= 0; i--) {
        r = (r << 1) | ((n >> i) & 1ull);
        if (r >= d) { r -= d; q |= (1ull << i); }
    }
    if (rem) *rem = r;
    return q;
}
u64 __udivdi3(u64 n, u64 d) { return udivmod64(n, d, 0); }
u64 __umoddi3(u64 n, u64 d) { u64 r; udivmod64(n, d, &r); return r; }
u64 __udivmoddi4(u64 n, u64 d, u64 *rem) { return udivmod64(n, d, rem); }
long long __divdi3(long long a, long long b)
{
    int neg = (a < 0) != (b < 0);
    u64 r = udivmod64(a < 0 ? -a : a, b < 0 ? -b : b, 0);
    return neg ? -(long long)r : (long long)r;
}
long long __moddi3(long long a, long long b)
{
    u64 r;
    udivmod64(a < 0 ? -a : a, b < 0 ? -b : b, &r);
    return a < 0 ? -(long long)r : (long long)r;
}

/* ===================== заглушки ATA/AHCI поверх файла ================== */
static int g_fd = -1;
static u32 g_sectors = 0;

int  ahci_hdd_present(void) { return g_fd >= 0; }
int  ahci_cd_present(void)  { return 0; }
u32  ahci_hdd_sectors(void) { return g_sectors; }
const char *ahci_hdd_model(void) { return "HOST-TEST-IMG"; }
int  ahci_read_hdd(u32 lba, u8 count, void *buf)
{
    if (g_fd < 0) return 0;
    if (sys_lseek(g_fd, (long)lba * 512, 0) < 0) return 0;
    long total = (long)count * 512, got = 0;
    while (got < total) {
        long r = sys_read(g_fd, (char *)buf + got, total - got);
        if (r <= 0) break;
        got += r;
    }
    return got == total;
}
int  ahci_write_hdd(u32 lba, u8 count, const void *buf)
{ (void)lba; (void)count; (void)buf; return 1; }
int  ahci_read_cd(u32 lba, void *buf) { (void)lba; (void)buf; return 0; }

int  ata_present(void)      { return 0; }
int  ata_hdd_present(void)  { return 0; }
int  ata_is_hdd_active(void){ return 0; }
u32  ata_hdd_sectors(void)  { return 0; }
const char *ata_hdd_model(void) { return ""; }
int  ata_read_hdd(u32 lba, u8 count, void *buf)
{ (void)lba; (void)count; (void)buf; return 0; }
int  ata_write_hdd(u32 lba, u8 count, const void *buf)
{ (void)lba; (void)count; (void)buf; return 0; }
int  ata_read(u32 lba, u8 count, void *buf)
{ (void)lba; (void)count; (void)buf; return 0; }

/* ===================== тестируемые модули (реальные) =================== */
#include "disk.h"
#include "ntfs.h"

static int fat32_is_usb_stub(void) { return 0; }

/* Видимость диска в файловом менеджере — реплика fm_scan_vols()
 * (Task 55: NTFS/exFAT-superfloppy стал видимым; синхронизировано
 * с файловым менеджером после фикса). */
static int fm_visible_vols(void)
{
    if (!disk_hdd_present()) return 0;
    int np = disk_part_count(), vols = 0;
    for (int i = 0; i < np; i++) {
        const char *fs = disk_part_fstype(i);
        if (strcmp(fs, "NTFS") == 0 || strcmp(fs, "FAT32") == 0 ||
            strcmp(fs, "exFAT") == 0)
            vols++;
    }
    if (vols == 0) {
        const char *sf = disk_superfloppy_fs();
        if (sf[0] == 'N' || sf[0] == 'e' ||
            (!fat32_is_usb_stub() && 0))
            vols++;   /* superfloppy-том (NTFS/exFAT/FAT32) */
    }
    return vols;
}

static int g_pass, g_fail;

static void CHECK(int cond, const char *what)
{
    print("  [");
    print(cond ? "ok" : "ПРОВАЛ");
    print("] ");
    print(what);
    print("\n");
    if (cond) g_pass++; else g_fail++;
}

static void print_dec(long v)
{
    char b[16];
    int i = 15;
    b[i--] = 0;
    if (v == 0) b[i--] = '0';
    while (v) { b[i--] = (char)('0' + v % 10); v /= 10; }
    print(&b[i + 1]);
}

static void print_hex2(u8 v)
{
    static const char hx[] = "0123456789ABCDEF";
    char b[3] = { hx[v >> 4], hx[v & 15], 0 };
    print(b);
}

static void dump_entries(const char *tag, const char *path)
{
    static ntfs_dirent_t ents[256];
    int n = ntfs_list(path, ents, 256);
    print("    "); print(tag); print(": ");
    if (n < 0) { print("ОШИБКА (-1)\n"); return; }
    print_dec(n);
    print(" записей:");
    for (int i = 0; i < n && i < 9; i++) {
        print(" ");
        print(ents[i].name);
        if (ents[i].is_dir) print("/");
    }
    if (n > 9) print(" ...");
    print("\n");
}

static u8 g_buf[400000];

static int check_file(const char *path, u32 expect, u8 (*pattern)(int))
{
    u32 got = ntfs_read_file(path, g_buf, sizeof(g_buf));
    if (got != expect) {
        print("    !! "); print(path); print(": прочитано ");
        print_dec((long)got); print(" из "); print_dec((long)expect);
        print(" байт\n");
        return 0;
    }
    for (u32 i = 0; i < expect; i++)
        if (g_buf[i] != pattern(i)) {
            print("    !! "); print(path);
            print(": данные не совпали на смещении "); print_dec((long)i);
            print("\n");
            return 0;
        }
    print("    ok "); print(path);
    print(": "); print_dec((long)expect); print(" байт, содержимое совпало\n");
    return 1;
}

static u8 pat_img(int i) { return (u8)((i * 3 + 5) & 0xFF); }
static u8 pat_big(int i) { return (u8)((i * 7 + 13) & 0xFF); }
static u8 pat_ent(int i) { return (u8)((i * 11 + 1) & 0xFF); }
static u8 pat_x(int i)   { (void)i; return 'x'; }


static void test_image(const char *path)
{
    print("\n===== "); print(path); print(" =====\n");
    if (g_fd >= 0) sys_close(g_fd);
    g_fd = (int)sys_open(path);
    if (g_fd < 0) { print("  !! образ не открыт\n"); return; }
    g_sectors = (u32)(sys_lseek(g_fd, 0, 2) / 512);

    /* 1. Разметка */
    disk_part_rescan();
    int np = disk_part_count();
    print("  разделов: "); print_dec(np); print("\n");
    for (int i = 0; i < np; i++) {
        const disk_part_t *p = disk_part(i);
        print("    #"); print_dec(i);
        print(": type=0x"); print_hex2(p->type);
        print(" lba="); print_dec((long)p->start_lba);
        print(" nsec="); print_dec((long)p->nsectors);
        print(p->gpt ? " GPT" : " MBR");
        print(" fs="); print(disk_part_fstype(i));
        print("\n");
    }

    /* 2. Видимость в FM */
    int nv = fm_visible_vols();
    print("  FM: томов-кнопок="); print_dec(nv);
    if (nv == 0) print("   <-- ДИСК НЕ ВИДЕН В ФАЙЛОВОМ МЕНЕДЖЕРЕ");
    print("\n");

    /* 3. Монтирование (авто) + листинги + чтение */
    int ok = ntfs_init();
    CHECK(ok, "ntfs_init() смонтировал том");
    if (!ok) {
        print("    ошибка: "); print(ntfs_error()); print("\n");
        return;
    }
    print("    метка: "); print(ntfs_label()); print("\n");
    dump_entries("корень /", "/");
    dump_entries("каталог /big", "/big");

    static ntfs_dirent_t e[64];
    int nr = ntfs_list("/", e, 64);
    CHECK(nr == 9, "в корне ровно 9 записей (7 файлов + big + small)");
    int nb = ntfs_list("/big", e, 64);
    CHECK(nb == 40, "в /big ровно 40 файлов (INDX-блок прочитан)");
    int ns = ntfs_list("/small", e, 64);
    CHECK(ns == 3, "в /small ровно 3 файла ($INDEX_ROOT прочитан)");

    check_file("/image.img", 40 * 1024, pat_img);
    check_file("/bigfile.bin", 300000, pat_big);
    check_file("/big/file39", 32, pat_ent);
    check_file("/small/s01", 16, pat_x);

    /* 4. Монтирование каждого NTFS-раздела по индексу (клик тома в FM) */
    for (int i = 0; i < np; i++) {
        if (strcmp(disk_part_fstype(i), "NTFS") != 0) continue;
        print("  ntfs_init_part("); print_dec(i); print("): ");
        int pok = ntfs_init_part(i);
        print(pok ? "ok\n" : "ОШИБКА\n");
        if (pok && np > 1)
            dump_entries("    корень тома", "/");
    }
}

static int run(void)
{
    static const char *imgs[] = {
        "scripts/ntfs-imgs/ntfs_mbr1.img",
        "scripts/ntfs-imgs/ntfs_superfloppy.img",
        "scripts/ntfs-imgs/ntfs_mbr2.img",
        "scripts/ntfs-imgs/ntfs_gpt.img",
        "scripts/ntfs-imgs/ntfs_mbr_logical.img",
        "scripts/ntfs-imgs/ntfs_4k.img",
    };
    print("=== N2600-OS host-тесты: disk.c + ntfs.c (реальный код) ===\n");
    for (int i = 0; i < (int)(sizeof(imgs) / sizeof(imgs[0])); i++)
        test_image(imgs[i]);
    print("\n=== ИТОГ: passed="); print_dec(g_pass);
    print(" failed="); print_dec(g_fail); print(" ===\n");
    return g_fail ? 1 : 0;
}

__attribute__((noreturn)) void _start(void)
{
    /* гарантируем 16-байтовое выравнивание стека (SSE movaps в -O1/-O2) */
    __asm__ __volatile__("and $-16, %%rsp" ::: "rsp");
    sys_exit(run());
}
