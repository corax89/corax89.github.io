#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_ntfs_images.py — генератор синтетических NTFS-дисков для host-тестов
драйвера ntfs.c/disk.c (N2600-OS, Task 55).

Строит КОРРЕКТНЫЕ по спецификации NTFS-тома (boot sector, $MFT с fixup,
$INDEX_ROOT / $INDEX_ALLOCATION + INDX, resident/non-resident $DATA,
фрагментированные runs) внутри разных схем разметки диска:

  ntfs_mbr1.img          — MBR, ОДИН первичный NTFS-раздел
  ntfs_superfloppy.img   — NTFS прямо с LBA 0, БЕЗ таблицы разделов
  ntfs_mbr2.img          — MBR, ДВА первичных NTFS-раздела
  ntfs_gpt.img           — GPT (защитная MBR): MSR + NTFS «basic data»
  ntfs_mbr_logical.img   — MBR: первичный NTFS + логический NTFS в extended
  ntfs_4k.img            — MBR, один NTFS с кластерами 4 КиБ (spc=8)

Содержимое каждого тома: 7 файлов в корне (в т.ч. кириллица, resident и
non-resident, фрагментированный 300К bigfile.bin) + каталог "big" с 40
файлами (вынуждает $INDEX_ALLOCATION/INDX).

Тома — «тестовые»: Windows их не примонтирует (нет $Secure/$UpCase и т.п.),
но структура ровно та, что читает драйвер N2600-OS.
"""
import os
import struct
import zlib

SECT = 512
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ntfs-imgs")
os.makedirs(OUT, exist_ok=True)

MFT_REC = 1024
NREC = 96          # записей MFT (по 1 КиБ)
STD_INFO = bytes(72)
VOL_BYTES = 32 * 1024 * 1024

CUR_SPC = 8
CUR_INDX_CPB = 1


def u16(v): return struct.pack("<H", v & 0xFFFF)
def u32(v): return struct.pack("<I", v & 0xFFFFFFFF)
def u64(v): return struct.pack("<Q", v & 0xFFFFFFFFFFFFFFFF)
def utf16(s): return s.encode("utf-16-le")
def align8(n): return (n + 7) & ~7


def nbits(v):
    return max(1, (int(v).bit_length() + 7) // 8)


def signed_bytes(delta):
    """Минимальное число байт, вмещающих delta КАК ЗНАКОВОЕ (data runs:
    офсет — знаковый, старший бит старшего байта — знак)."""
    for osz in range(1, 9):
        lo = -(1 << (osz * 8 - 1))
        hi = (1 << (osz * 8 - 1)) - 1
        if lo <= delta <= hi:
            return osz
    return 8


# ---------------------------------------------------------------- атрибуты
def attr_resident(atype, val, name=b""):
    nlen = len(name)
    hdr = 0x18
    voff = hdr + nlen
    total = align8(voff + len(val))
    a = bytearray(total)
    struct.pack_into("<I", a, 0x00, atype)
    struct.pack_into("<I", a, 0x04, total)
    a[0x08] = 0
    a[0x09] = nlen
    struct.pack_into("<H", a, 0x0A, hdr)
    struct.pack_into("<H", a, 0x0C, 0)
    struct.pack_into("<H", a, 0x0E, 0)
    struct.pack_into("<I", a, 0x10, len(val))
    struct.pack_into("<H", a, 0x14, voff)
    a[hdr:hdr + nlen] = name
    a[voff:voff + len(val)] = val
    return bytes(a)


def runs_encode(runs):
    """runs: [(len_clusters, lcn_or_None)] → mapping pairs."""
    out = bytearray()
    lcn = 0
    for ln, l in runs:
        lsz = nbits(ln)
        if l is None:
            out.append(lsz)
            out += ln.to_bytes(lsz, "little")
        else:
            delta = l - lcn
            lcn = l
            osz = signed_bytes(delta)   # офсет ЗНАКОВЫЙ: бит 7 — знак!
            out.append(lsz | (osz << 4))
            out += ln.to_bytes(lsz, "little")
            out += (delta & ((1 << (osz * 8)) - 1)).to_bytes(osz, "little")
    out.append(0)
    return bytes(out)


def attr_nonresident(atype, runs, real_sz, name=b""):
    r = runs_encode(runs)
    nlen = len(name)
    hdr = 0x40
    roff = hdr + nlen
    total = align8(roff + len(r))
    a = bytearray(total)
    clus_sz = CUR_SPC * SECT
    nclus = sum(l for l, _ in runs)
    struct.pack_into("<I", a, 0x00, atype)
    struct.pack_into("<I", a, 0x04, total)
    a[0x08] = 1
    a[0x09] = nlen
    struct.pack_into("<H", a, 0x0A, hdr)
    struct.pack_into("<H", a, 0x0C, 0)
    struct.pack_into("<H", a, 0x0E, 0)
    struct.pack_into("<Q", a, 0x10, 0)
    struct.pack_into("<Q", a, 0x18, max(0, nclus - 1))
    struct.pack_into("<H", a, 0x20, roff)
    struct.pack_into("<H", a, 0x22, 0)
    struct.pack_into("<Q", a, 0x28, nclus * clus_sz)
    struct.pack_into("<Q", a, 0x30, real_sz)
    struct.pack_into("<Q", a, 0x38, real_sz)
    a[hdr:hdr + nlen] = name
    a[roff:roff + len(r)] = r
    return bytes(a)


def file_name_attr(parent_rec, name, size, is_dir):
    v = bytearray(0x42)
    struct.pack_into("<Q", v, 0x00, parent_rec | (1 << 48))
    for i in range(4):
        struct.pack_into("<Q", v, 0x08 + i * 8, 0x01C0000000000000)
    struct.pack_into("<Q", v, 0x28, size)
    struct.pack_into("<Q", v, 0x30, size)
    struct.pack_into("<I", v, 0x38, 0x10000001 if is_dir else 0x10000000)
    v[0x40] = len(name)
    v[0x41] = 1 if any(ord(c) > 127 for c in name) else 3
    v += utf16(name)
    return attr_resident(0x30, bytes(v))


def index_entry(rec_no, name, size, is_dir, last=False):
    key = bytearray(0x42)
    struct.pack_into("<Q", key, 0x00, rec_no | (1 << 48))
    for i in range(4):
        struct.pack_into("<Q", key, 0x08 + i * 8, 0x01C0000000000000)
    struct.pack_into("<Q", key, 0x28, size)
    struct.pack_into("<Q", key, 0x30, size)
    struct.pack_into("<I", key, 0x38, 0x10 if is_dir else 0)
    key[0x40] = len(name)
    key[0x41] = 1 if any(ord(c) > 127 for c in name) else 3
    key += utf16(name)
    total = align8(0x10 + len(key))
    ent = bytearray(0x10)
    struct.pack_into("<Q", ent, 0x00, rec_no | (1 << 48))
    struct.pack_into("<H", ent, 0x08, total)
    struct.pack_into("<H", ent, 0x0A, len(key))
    struct.pack_into("<H", ent, 0x0C, 0x0002 if last else 0x0000)
    ent += key
    ent += bytes(total - len(ent))
    return bytes(ent)


def end_entry():
    e = bytearray(0x10)
    struct.pack_into("<H", e, 0x08, 0x10)
    struct.pack_into("<H", e, 0x0C, 0x0002)
    return bytes(e)


def index_root(entries, has_alloc):
    val = bytearray()
    val += u32(0x30)
    val += u32(1)
    val += u32(4096)
    val += bytes([CUR_INDX_CPB])
    val += bytes(3)
    ih = bytearray(16)
    body = b"".join(entries)
    struct.pack_into("<I", ih, 0x00, 0x10)
    struct.pack_into("<I", ih, 0x04, len(body))
    struct.pack_into("<I", ih, 0x08, 4096)
    ih[0x0C] = 1 if has_alloc else 0
    val += ih
    val += body
    return attr_resident(0x90, bytes(val), b"$I30")


def apply_fixup(block, usn):
    nsec = len(block) // 512
    usa_off = struct.unpack_from("<H", block, 4)[0]
    origs = []
    for s in range(nsec):
        origs.append(block[s * 512 + 510:s * 512 + 512])
        block[s * 512 + 510:s * 512 + 512] = u16(usn)
    block[usa_off:usa_off + 2] = u16(usn)
    for i, o in enumerate(origs):
        block[usa_off + 2 + i * 2:usa_off + 4 + i * 2] = o


def mft_record(attrs, is_dir=False):
    body = bytearray(MFT_REC)
    struct.pack_into("<I", body, 0x00, 0x454C4946)      # "FILE"
    struct.pack_into("<H", body, 0x04, 0x30)            # USA offset
    struct.pack_into("<H", body, 0x06, MFT_REC // 512 + 1)
    struct.pack_into("<Q", body, 0x08, 0)
    struct.pack_into("<H", body, 0x10, 1)               # sequence
    struct.pack_into("<H", body, 0x12, 1)               # link count
    # attrs ПОСЛЕ USA: 0x30 + (nsec+1)*2 = 0x36 → выравниваем до 0x38
    off = 0x38
    struct.pack_into("<H", body, 0x14, off)
    struct.pack_into("<H", body, 0x16, 0x0003 if is_dir else 0x0001)
    blob = b"".join(attrs) + u32(0xFFFFFFFF) + bytes(4)
    struct.pack_into("<I", body, 0x18, off + len(blob))
    struct.pack_into("<I", body, 0x1C, MFT_REC)
    struct.pack_into("<Q", body, 0x20, 0)
    body[off:off + len(blob)] = blob
    apply_fixup(body, 1)
    return bytes(body)


def indx_block(entries, indx_size=4096):
    blk = bytearray(indx_size)
    blk[0:4] = b"INDX"
    struct.pack_into("<H", blk, 0x04, 0x28)
    struct.pack_into("<H", blk, 0x06, indx_size // 512 + 1)
    struct.pack_into("<Q", blk, 0x08, 0)
    body = b"".join(entries)
    # entries_offset ОТ INDEX_HEADER (0x10); USA живёт по пути
    eoff = 0x28 + 2 * (indx_size // 512 + 1)
    eoff = align8(eoff) - 0x10
    struct.pack_into("<I", blk, 0x10, eoff)
    struct.pack_into("<I", blk, 0x14, len(body))
    struct.pack_into("<I", blk, 0x18, indx_size)
    blk[0x1C] = 0
    start = 0x10 + eoff
    blk[start:start + len(body)] = body
    apply_fixup(blk, 1)
    return bytes(blk)


# ---------------------------------------------------------------- том NTFS
def build_volume(spc):
    """Одинаковое содержимое: 7 файлов в корне + каталог big (40 файлов)."""
    global CUR_SPC, CUR_INDX_CPB
    CUR_SPC = spc
    CUR_INDX_CPB = 1 if spc >= 8 else 8   # INDX = 4096 байт
    clus = spc * SECT
    size = VOL_BYTES
    nclus = size // clus
    vol = bytearray(size)

    MFT_LCN = 16
    MFT_CLUS = NREC * MFT_REC // clus
    MIRR_LCN, LOG_LCN = 8, 9
    INDX_CLUS = (4096 + clus - 1) // clus
    INDX_LCN = MFT_LCN + MFT_CLUS + 1        # INDX каталога "big"
    INDX2_LCN = INDX_LCN + INDX_CLUS         # INDX корня
    # база области данных: за MFT и обоими INDX — без наложений при любом spc
    DATA_BASE = INDX2_LCN + INDX_CLUS + 8

    readme = b"Hello from NTFS test volume!\n" * 4
    small = b"\xAA" * 100
    otchot = "Годовой отчёт, тест кириллицы\n".encode("utf-8")
    fayl = b"\x55" * 50
    notes = b"# Notes\nTask 55 host test.\n"
    imgfile = bytes((i * 3 + 5) & 0xFF for i in range(40 * 1024))
    bigfile = bytes((i * 7 + 13) & 0xFF for i in range(300000))
    bigent = bytes((i * 11 + 1) & 0xFF for i in range(32))

    # фрагментированный bigfile: 3 несмежных прогона (позиции от DATA_BASE)
    bf_cl = (300000 + clus - 1) // clus
    per = bf_cl // 3
    img_cl = (40 * 1024 + clus - 1) // clus
    bf_runs = [(per, DATA_BASE),
               (per, DATA_BASE + 400),
               (bf_cl - 2 * per, DATA_BASE + 800)]
    img_runs = [(img_cl, DATA_BASE + 1200)]

    def wr_clus(lcn, data):
        off = lcn * clus
        vol[off:off + len(data)] = data   # len(data) может быть > кластера (INDX)

    idx = 0
    for ln, l in bf_runs:
        for c in range(ln):
            wr_clus(l + c, bigfile[idx * clus:(idx + 1) * clus])
            idx += 1
    img_cl = (40 * 1024 + clus - 1) // clus
    img_lcn = img_runs[0][1]
    for c in range(img_cl):
        wr_clus(img_lcn + c, imgfile[c * clus:(c + 1) * clus])

    # ---- записи MFT
    recs = {}
    nxt = [6]

    def alloc_rec(name):
        recs[name] = nxt[0]
        nxt[0] += 1
        return recs[name]

    for nm in ("readme.txt", "data_small.bin", "Отчёт.txt", "Файл.dat",
               "notes.md", "image.img", "bigfile.bin"):
        alloc_rec(nm)
    big_rec = alloc_rec("big")
    small_rec = alloc_rec("small")
    for i in range(40):
        alloc_rec("file%02d" % i)
    for i in range(3):
        alloc_rec("s%02d" % i)

    sizes = {"readme.txt": len(readme), "data_small.bin": len(small),
             "Отчёт.txt": len(otchot), "Файл.dat": len(fayl),
             "notes.md": len(notes), "image.img": 40 * 1024,
             "bigfile.bin": 300000}

    rec_mft = mft_record([attr_nonresident(0x80, [(MFT_CLUS, MFT_LCN)],
                                           MFT_CLUS * clus)])
    rec_mirr = mft_record([attr_nonresident(0x80, [(1, MIRR_LCN)],
                                            4 * MFT_REC)])
    rec_log = mft_record([attr_nonresident(0x80, [(1, LOG_LCN)], clus)])
    rec_vol = mft_record([
        attr_resident(0x10, STD_INFO),
        attr_resident(0x60, utf16("TESTVOL")),
    ])

    root_ents = []
    for nm in ("Отчёт.txt", "Файл.dat", "notes.md", "data_small.bin",
               "readme.txt", "image.img", "bigfile.bin"):
        root_ents.append(index_entry(recs[nm], nm, sizes[nm], False))
    root_ents.append(index_entry(big_rec, "big", 0, True))
    root_ents.append(index_entry(small_rec, "small", 0, True))
    root_ents.append(end_entry())
    # корень НЕ влезает в MFT-запись (9 записей ~1.1 КиБ > 1 КиБ) —
    # индекс корня тоже в INDX-блоке, как у больших каталогов Windows
    wr_clus(INDX2_LCN, indx_block(root_ents, 4096))
    rec_root = mft_record([
        attr_resident(0x10, STD_INFO),
        file_name_attr(5, ".", 0, True),
        index_root([end_entry()], True),
        attr_nonresident(0xA0, [(1, INDX2_LCN)], 4096, b"$I30"),
    ], is_dir=True)

    big_ents = [index_entry(recs["file%02d" % i], "file%02d" % i, 32, False)
                for i in range(40)]
    big_ents.append(end_entry())
    wr_clus(INDX_LCN, indx_block(big_ents, 4096))
    rec_big = mft_record([
        attr_resident(0x10, STD_INFO),
        file_name_attr(5, "big", 0, True),
        index_root([end_entry()], True),
        attr_nonresident(0xA0, [(1, INDX_LCN)], 4096, b"$I30"),
    ], is_dir=True)

    # small: индекс целиком в $INDEX_ROOT (путь малых каталогов)
    small_ents = [index_entry(recs["s%02d" % i], "s%02d" % i, 16, False)
                  for i in range(3)]
    small_ents.append(end_entry())
    rec_small = mft_record([
        attr_resident(0x10, STD_INFO),
        file_name_attr(5, "small", 0, True),
        index_root(small_ents, False),
    ], is_dir=True)

    resident = {"readme.txt": readme, "data_small.bin": small,
                "Отчёт.txt": otchot, "Файл.dat": fayl, "notes.md": notes}

    def small_file_rec(nm, rec_no, parent, data):
        return mft_record([
            attr_resident(0x10, STD_INFO),
            file_name_attr(parent, nm, len(data), False),
            attr_resident(0x80, data),
        ])

    recs_bytes = {0: rec_mft, 1: rec_mirr, 2: rec_log, 3: rec_vol,
                  5: rec_root, big_rec: rec_big, small_rec: rec_small}
    for nm, data in resident.items():
        recs_bytes[recs[nm]] = small_file_rec(nm, recs[nm], 5, data)
    recs_bytes[recs["image.img"]] = mft_record([
        attr_resident(0x10, STD_INFO),
        file_name_attr(5, "image.img", 40 * 1024, False),
        attr_nonresident(0x80, img_runs, 40 * 1024),
    ])
    recs_bytes[recs["bigfile.bin"]] = mft_record([
        attr_resident(0x10, STD_INFO),
        file_name_attr(5, "bigfile.bin", 300000, False),
        attr_nonresident(0x80, bf_runs, 300000),
    ])
    for i in range(40):
        nm = "file%02d" % i
        recs_bytes[recs[nm]] = small_file_rec(nm, recs[nm], big_rec, bigent)
    for i in range(3):
        nm = "s%02d" % i
        recs_bytes[recs[nm]] = small_file_rec(nm, recs[nm], small_rec, b"x" * 16)

    mft_off = MFT_LCN * clus
    for r in range(NREC):
        b = recs_bytes.get(r)
        if b:
            assert len(b) == MFT_REC, "запись %d: %d != %d" % (r, len(b), MFT_REC)
            vol[mft_off + r * MFT_REC:mft_off + (r + 1) * MFT_REC] = b
    mirr_off = MIRR_LCN * clus
    vol[mirr_off:mirr_off + 4 * MFT_REC] = vol[mft_off:mft_off + 4 * MFT_REC]

    # ---- boot sector
    bs = bytearray(SECT)
    bs[0:3] = b"\xEB\x52\x90"
    bs[3:11] = b"NTFS    "
    struct.pack_into("<H", bs, 0x0B, SECT)
    bs[0x0D] = spc
    struct.pack_into("<Q", bs, 0x28, nclus)
    struct.pack_into("<Q", bs, 0x30, MFT_LCN)
    struct.pack_into("<Q", bs, 0x38, MIRR_LCN)
    bs[0x40] = 0xF6                      # -10 → 1024
    bs[0x44] = CUR_INDX_CPB
    struct.pack_into("<Q", bs, 0x48, 0x0123456789ABCDEF)
    bs[510:512] = b"\x55\xAA"
    vol[0:SECT] = bs
    return bytes(vol)


# ---------------------------------------------------------------- разметка
def write_mbr_entry(img, idx, ptype, start, nsec):
    off = 0x1BE + idx * 16
    img[off + 4] = ptype
    struct.pack_into("<I", img, off + 8, start)
    struct.pack_into("<I", img, off + 12, nsec)


def save(path, img):
    open(path, "wb").write(img)
    print("  %-26s %6.1f МиБ" % (os.path.basename(path), len(img) / 1048576))


def main():
    v_sp1 = build_volume(1)          # кластеры 512 байт
    v_sp8 = build_volume(8)          # кластеры 4 КиБ (Windows default)
    SP1 = VOL_BYTES // SECT
    SP2 = 2 * SP1

    print("Генерация NTFS-образов в %s:" % OUT)

    # 1. MBR + один первичный NTFS
    img = bytearray((SP1 + 2048) * SECT)
    img[510:512] = b"\x55\xAA"
    write_mbr_entry(img, 0, 0x07, 2048, SP1)
    img[2048 * SECT:2048 * SECT + len(v_sp1)] = v_sp1
    save(os.path.join(OUT, "ntfs_mbr1.img"), img)

    # 2. superfloppy NTFS (без MBR)
    save(os.path.join(OUT, "ntfs_superfloppy.img"), v_sp1)

    # 3. MBR + два первичных NTFS
    img = bytearray((SP2 + 4096) * SECT)
    img[510:512] = b"\x55\xAA"
    write_mbr_entry(img, 0, 0x07, 2048, SP1)
    write_mbr_entry(img, 1, 0x07, 2048 + SP1 + 2048, SP1)
    img[2048 * SECT:2048 * SECT + len(v_sp1)] = v_sp1
    base2 = 2048 + SP1 + 2048
    img[base2 * SECT:base2 * SECT + len(v_sp8)] = v_sp8
    save(os.path.join(OUT, "ntfs_mbr2.img"), img)

    # 4. GPT: MSR (16 МиБ) + basic data NTFS — как форматирует Windows
    msr_secs = 16 * 1024 * 1024 // SECT
    data_start = 2048 + msr_secs
    total = data_start + SP1 + 2048
    img = bytearray(total * SECT)
    img[510:512] = b"\x55\xAA"
    write_mbr_entry(img, 0, 0xEE, 1, total - 1)
    hdr = bytearray(SECT)
    hdr[0:8] = b"EFI PART"
    struct.pack_into("<I", hdr, 8, 0x10000)
    struct.pack_into("<I", hdr, 12, 92)
    struct.pack_into("<Q", hdr, 24, 1)
    struct.pack_into("<Q", hdr, 32, total - 1)
    struct.pack_into("<Q", hdr, 40, 2)
    struct.pack_into("<Q", hdr, 48, total - 34)
    img[0x38 + SECT:0x48 + SECT] = bytes(range(16))       # disk guid
    struct.pack_into("<Q", hdr, 72, 2)
    struct.pack_into("<I", hdr, 80, 128)
    struct.pack_into("<I", hdr, 84, 128)
    ent = bytearray(128 * 128)
    GUID_MSR = bytes.fromhex("58af5ce73cf7894dad8af7f41eb4ed1b")
    GUID_DATA = bytes.fromhex("a2a0d0ebe5b9334487c068b6b72699c7")
    for i, (g, s, n, nm) in enumerate([
            (GUID_MSR, 2048, msr_secs, ""),
            (GUID_DATA, data_start, SP1, "DATA")]):
        e = i * 128
        ent[e:e + 16] = g
        ent[e + 16:e + 32] = bytes(range(16))
        struct.pack_into("<Q", ent, e + 32, s)
        struct.pack_into("<Q", ent, e + 40, s + n - 1)
        raw = nm.encode("utf-16-le")[:72]
        ent[e + 56:e + 56 + len(raw)] = raw
    struct.pack_into("<I", hdr, 88, zlib.crc32(ent) & 0xFFFFFFFF)
    img[2 * SECT:2 * SECT + len(ent)] = ent
    struct.pack_into("<I", hdr, 16, zlib.crc32(hdr[0:92]) & 0xFFFFFFFF)
    img[SECT:2 * SECT] = hdr
    img[data_start * SECT:data_start * SECT + len(v_sp8)] = v_sp8
    save(os.path.join(OUT, "ntfs_gpt.img"), img)

    # 5. MBR: первичный NTFS + логический NTFS (extended)
    ext_start = 2048 + SP1 + 2048
    vol_log = build_volume(8)
    disk = bytearray((ext_start + 2048 + SP1) * SECT)
    disk[510:512] = b"\x55\xAA"
    write_mbr_entry(disk, 0, 0x07, 2048, SP1)
    write_mbr_entry(disk, 1, 0x0F, ext_start, 2048 + SP1)
    disk[2048 * SECT:2048 * SECT + len(v_sp1)] = v_sp1
    ebr = bytearray(SECT)
    ebr[510:512] = b"\x55\xAA"
    write_mbr_entry(ebr, 0, 0x07, 2048, SP1)   # относительно EBR
    disk[ext_start * SECT:(ext_start + 1) * SECT] = ebr
    lstart = ext_start + 2048
    disk[lstart * SECT:lstart * SECT + len(vol_log)] = vol_log
    save(os.path.join(OUT, "ntfs_mbr_logical.img"), disk)

    # 6. MBR + NTFS с 4К-кластерами
    img = bytearray((SP1 + 2048) * SECT)
    img[510:512] = b"\x55\xAA"
    write_mbr_entry(img, 0, 0x07, 2048, SP1)
    img[2048 * SECT:2048 * SECT + len(v_sp8)] = v_sp8
    save(os.path.join(OUT, "ntfs_4k.img"), img)

    print("Готово.")


if __name__ == "__main__":
    main()
