/* shim/sync.h — no-op локи для host-тестов (тенирует src/sync.h) */
#ifndef SYNC_SHIM_H
#define SYNC_SHIM_H
static inline void s_lock(volatile int *l)   { (void)l; }
static inline void s_unlock(volatile int *l) { (void)l; }
static inline int  s_trylock(volatile int *l){ (void)l; return 1; }
static inline int  s_trylock_ms(volatile int *l, unsigned tmo) { (void)l; (void)tmo; return 1; }
extern void serial_puts(const char *s);
#endif
