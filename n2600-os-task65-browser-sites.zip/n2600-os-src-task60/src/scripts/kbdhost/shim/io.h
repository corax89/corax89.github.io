/* shim: io.h для host-тестов kbd (порты заглушены) */
#ifndef SHIM_IO_H
#define SHIM_IO_H
#include "types.h"
static inline u8 inb(u16 port) { (void)port; return 0; }
static inline void outb(u16 port, u8 val) { (void)port; (void)val; }
#endif
