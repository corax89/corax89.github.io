/* shim: idt.h для host-тестов kbd */
#ifndef SHIM_IDT_H
#define SHIM_IDT_H
#include "types.h"
typedef void (*irq_handler_t)(void);
static inline void irq_install(int irq, irq_handler_t h) { (void)irq; (void)h; }
#endif
