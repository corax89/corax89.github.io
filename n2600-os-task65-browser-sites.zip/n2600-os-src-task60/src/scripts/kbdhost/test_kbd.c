/* test_kbd.c — хост-тест раскладки EN/RU и переключения по CapsLock
 * (Task 62 [KB-RU]) на РЕАЛЬНОМ src/kbd.c.
 *
 * Проверяется kbd_lookup (юникод по скан-коду с учётом раскладки):
 *   EN: буквы/регистр/знаки; RU (ЙЦУКЕН): буквы, Shift-регистр,
 *   цифровой ряд с Shift (! " № ; % : ? * ( ) _ +), ё/Ё, х/ъ/ж/э,
 *   "./,", "\", клавиши вне русской таблицы (fallback в EN).
 *   Переключение: kbd_layout_toggle (0 <-> 1).
 * Сборка: sh scripts/kbdhost/run.sh
 */
#include <stdio.h>
#include <string.h>
#include "kbd.h"

static int g_pass = 0, g_fail = 0;
#define CHECK(name, cond) do { \
    if (cond) { g_pass++; printf("  [PASS] %s\n", name); } \
    else      { g_fail++; printf("  [FAIL] %s  (%s:%d)\n", name, __FILE__, __LINE__); } \
} while (0)

int main(void)
{
    printf("== host-тест раскладки EN/RU (Task 62 [KB-RU]) ==\n");

    /* ---------- EN (по умолчанию) ---------- */
    CHECK("старт: EN", kbd_layout_current() == 0);
    CHECK("EN: q -> q", kbd_lookup(0x10, 0) == 'q');
    CHECK("EN: Shift+q -> Q", kbd_lookup(0x10, 1) == 'Q');
    CHECK("EN: 2 -> 2", kbd_lookup(0x03, 0) == '2');
    CHECK("EN: Shift+2 -> @", kbd_lookup(0x03, 1) == '@');
    CHECK("EN: [ -> [", kbd_lookup(0x1A, 0) == '[');
    CHECK("EN: / -> /", kbd_lookup(0x35, 0) == '/');
    CHECK("EN: пробел", kbd_lookup(0x39, 0) == ' ');

    /* ---------- переключение CapsLock (wm_key вызывает toggle) ---------- */
    CHECK("toggle -> RU", kbd_layout_toggle() == 1);
    CHECK("layout: RU", kbd_layout_current() == 1);

    /* ---------- RU: буквы ЙЦУКЕН ---------- */
    CHECK("RU: q -> й", kbd_lookup(0x10, 0) == 0x0439);
    CHECK("RU: Shift+q -> Й", kbd_lookup(0x10, 1) == 0x0419);
    CHECK("RU: w -> ц", kbd_lookup(0x11, 0) == 0x0446);
    CHECK("RU: f -> а", kbd_lookup(0x21, 0) == 0x0430);
    CHECK("RU: Shift+f -> А", kbd_lookup(0x21, 1) == 0x0410);
    CHECK("RU: z -> я", kbd_lookup(0x2C, 0) == 0x044F);
    CHECK("RU: m -> ь", kbd_lookup(0x32, 0) == 0x044C);
    CHECK("RU: [ -> х", kbd_lookup(0x1A, 0) == 0x0445);
    CHECK("RU: ] -> ъ", kbd_lookup(0x1B, 0) == 0x044A);
    CHECK("RU: ; -> ж", kbd_lookup(0x27, 0) == 0x0436);
    CHECK("RU: ' -> э", kbd_lookup(0x28, 0) == 0x044D);
    CHECK("RU: ` -> ё", kbd_lookup(0x29, 0) == 0x0451);
    CHECK("RU: Shift+` -> Ё", kbd_lookup(0x29, 1) == 0x0401);
    CHECK("RU: , -> б", kbd_lookup(0x33, 0) == 0x0431);
    CHECK("RU: . -> ю", kbd_lookup(0x34, 0) == 0x044E);
    CHECK("RU: / -> .", kbd_lookup(0x35, 0) == 0x002E);
    CHECK("RU: Shift+/ -> ,", kbd_lookup(0x35, 1) == 0x002C);
    CHECK("RU: \\ -> \\", kbd_lookup(0x2B, 0) == 0x005C);
    CHECK("RU: Shift+\\ -> /", kbd_lookup(0x2B, 1) == 0x002F);

    /* ---------- RU: цифровой ряд ---------- */
    CHECK("RU: 1 -> 1", kbd_lookup(0x02, 0) == '1');
    CHECK("RU: 7 -> 7", kbd_lookup(0x08, 0) == '7');
    CHECK("RU: Shift+2 -> \"", kbd_lookup(0x03, 1) == 0x0022);
    CHECK("RU: Shift+3 -> №", kbd_lookup(0x04, 1) == 0x2116);
    CHECK("RU: Shift+4 -> ;", kbd_lookup(0x05, 1) == 0x003B);
    CHECK("RU: Shift+6 -> :", kbd_lookup(0x07, 1) == 0x003A);
    CHECK("RU: Shift+7 -> ?", kbd_lookup(0x08, 1) == 0x003F);
    CHECK("RU: Shift+8 -> *", kbd_lookup(0x09, 1) == 0x002A);
    CHECK("RU: Shift+0 -> )", kbd_lookup(0x0B, 1) == 0x0029);
    CHECK("RU: Shift+- -> _", kbd_lookup(0x0C, 1) == 0x005F);
    CHECK("RU: Shift+= -> +", kbd_lookup(0x0D, 1) == 0x002B);

    /* ---------- RU: клавиши вне русской таблицы — fallback в EN ---------- */
    CHECK("RU: Tab -> \\t", kbd_lookup(0x0F, 0) == '\t');
    CHECK("RU: Enter -> \\n", kbd_lookup(0x1C, 0) == '\n');
    CHECK("RU: пробел", kbd_lookup(0x39, 0) == ' ');
    CHECK("RU: вне 128 -> 0", kbd_lookup(200, 0) == 0);

    /* ---------- обратно в EN ---------- */
    CHECK("toggle -> EN", kbd_layout_toggle() == 0);
    CHECK("layout: EN", kbd_layout_current() == 0);
    CHECK("EN после возврата: q -> q", kbd_lookup(0x10, 0) == 'q');
    CHECK("EN после возврата: Shift+3 -> #", kbd_lookup(0x04, 1) == '#');

    printf("\nИтого: %d PASS, %d FAIL\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
