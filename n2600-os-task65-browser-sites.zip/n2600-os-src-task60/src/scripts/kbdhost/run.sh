#!/bin/sh
# run.sh — хост-тест раскладки EN/RU и переключения по CapsLock
# (Task 62 [KB-RU]) на РЕАЛЬНОМ src/kbd.c. Запуск: sh scripts/kbdhost/run.sh
set -e
cd "$(dirname "$0")"
# kbd.c копируется рядом: #include "io.h"/"idt.h" возьмут shim-версии
cp ../../src/kbd.c ../../src/kbd.h ../../src/types.h .
gcc -DHOST_TEST -g -O1 -fsanitize=address,undefined -Ishim -I. \
    -o test_kbd test_kbd.c kbd.c
./test_kbd
