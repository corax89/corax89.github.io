/* kbd.c — драйвер клавиатуры PS/2 (скан-код набор 1, раскладки EN/RU)
 *
 * Task 62 [KB-RU]: переключение раскладки ПО CAPSLOCK (английская
 * <-> русская ЙЦУКЕН). Клавиша CapsLock больше НЕ меняет регистр —
 * она СОВСЕМ переключает раскладку (регистр — Shift в обеих).
 * Кириллица уходит в приложения как UTF-8 (2–3 байта на букву —
 * события ch=байту, внутренние строки ОС UTF-8).
 * Индикатор раскладки — на панели задач (wm.c, draw_taskbar).
 * USB-клавиатуры (usb.c) пользуются kbd_lookup() — тот же маппинг. */
#include "kbd.h"
#include "io.h"
#include "idt.h"

#define RING_SIZE 64

static volatile key_event_t ring[RING_SIZE];
static volatile u32 r_head = 0, r_tail = 0;

static u8 shift_state = 0, ctrl_state = 0, alt_state = 0;
/* Task 62 [KB-RU]: caps_state упразднён — CapsLock переключает раскладку
 * (см. wm_key: событие кода 0x3A вызывает kbd_layout_toggle()). */
static int layout_state = 0;      /* 0 = EN, 1 = RU (ЙЦУКЕН) */
static int e0_prefix = 0;

/* скан-код -> символ (набор 1, без Shift), ровно 128 элементов */
static const unsigned char sc_map[128] = {
    /* 00 */ 0, 0x1B, '1','2','3','4','5','6','7','8','9','0','-','=',
    /* 0E */ '\b',
    /* 0F */ '\t','q','w','e','r','t','y','u','i','o','p','[',']',
    /* 1C */ '\n',
    /* 1D */ 0,
    /* 1E */ 'a','s','d','f','g','h','j','k','l',';','\'','`',
    /* 2A */ 0,
    /* 2B */ '\\',
    /* 2C */ 'z','x','c','v','b','n','m',',','.','/',
    /* 36 */ 0,
    /* 37 */ '*',
    /* 38 */ 0,
    /* 39 */ ' ',
    /* 3A..7F */ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0
};

/* скан-код -> символ с Shift */
static const unsigned char sc_map_shift[128] = {
    /* 00 */ 0, 0x1B, '!','@','#','$','%','^','&','*','(',')','_','+',
    /* 0E */ '\b',
    /* 0F */ '\t','Q','W','E','R','T','Y','U','I','O','P','{','}',
    /* 1C */ '\n',
    /* 1D */ 0,
    /* 1E */ 'A','S','D','F','G','H','J','K','L',':','"','~',
    /* 2A */ 0,
    /* 2B */ '|',
    /* 2C */ 'Z','X','C','V','B','N','M','<','>','?',
    /* 36 */ 0,
    /* 37 */ '*',
    /* 38 */ 0,
    /* 39 */ ' ',
    /* 3A..7F */ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0
};

/* ---- Task 62 [KB-RU]: русская раскладка ЙЦУКЕН ----
 * ru_low/ru_up — юникод-код символа по скан-коду (без/с Shift).
 * 0 = клавиши нет в русской таблице — берём из EN-таблиц.
 * Цифровой ряд с Shift — по русской традиции: ! " № ; % : ? * ( ) _ + */
static const u16 ru_low[128] = {
    /* 00 */ 0, 0, '1','2','3','4','5','6','7','8','9','0','-','=',
    /* 0E */ '\b',
    /* 0F */ '\t', 0x0439, 0x0446, 0x0443, 0x043A, 0x0435, 0x043D,
             0x0433, 0x0448, 0x0449, 0x0437, 0x0445, 0x044A,
    /* 1C */ '\n',
    /* 1D */ 0,
    /* 1E */ 0x0444, 0x044B, 0x0432, 0x0430, 0x043F, 0x0440,
             0x043E, 0x043B, 0x0434, 0x0436, 0x044D, 0x0451,
    /* 2A */ 0,
    /* 2B */ '\\',
    /* 2C */ 0x044F, 0x0447, 0x0441, 0x043C, 0x0438, 0x0442,
             0x044C, 0x0431, 0x044E, 0x002E,
    /* 36 */ 0,
    /* 37 */ '*',
    /* 38 */ 0,
    /* 39 */ ' ',
    /* 3A..7F */ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0
};
static const u16 ru_up[128] = {
    /* 00 */ 0, 0, '!','"',0x2116,';','%',':','?','*','(',')','_','+',
    /* 0E */ '\b',
    /* 0F */ '\t', 0x0419, 0x0426, 0x0423, 0x041A, 0x0415, 0x041D,
             0x0413, 0x0428, 0x0429, 0x0417, 0x0425, 0x042A,
    /* 1C */ '\n',
    /* 1D */ 0,
    /* 1E */ 0x0424, 0x042B, 0x0412, 0x0410, 0x041F, 0x0420,
             0x041E, 0x041B, 0x0414, 0x0416, 0x042D, 0x0401,
    /* 2A */ 0,
    /* 2B */ '/',
    /* 2C */ 0x042F, 0x0427, 0x0421, 0x041C, 0x0418, 0x0422,
             0x042C, 0x0411, 0x042E, 0x002C,
    /* 36 */ 0,
    /* 37 */ '*',
    /* 38 */ 0,
    /* 39 */ ' ',
    /* 3A..7F */ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0
};

/* Юникод-код клавиши с учётом ТЕКУЩЕЙ раскладки (0 = нет символа).
 * Публичная: используется и USB-драйвером (usb.c dispatch_keyboard). */
u32 kbd_lookup(u8 sc, int shift)
{
    if (sc >= 128) return 0;
    if (layout_state == 1) {
        u16 v = shift ? ru_up[sc] : ru_low[sc];
        if (v) return v;
        /* нет в русской таблице — как в EN (скобки, ~, | и пр.) */
    }
    u8 base = sc_map[sc];
    if (base >= 'a' && base <= 'z')
        return shift ? (u32)(base - 'a' + 'A') : (u32)base;
    return shift ? (u32)sc_map_shift[sc] : (u32)base;
}

int kbd_layout_current(void) { return layout_state; }

int kbd_layout_toggle(void)
{
    layout_state ^= 1;
    return layout_state;
}

static void push_event(u8 code, char ch, u8 flags);   /* fwd */

/* Закодировать юникод-код в UTF-8 и добавить события в ring (кириллица
 * — 2 байта, № — 3). Все события несут ОДИН скан-код и те же flags:
 * приложения склеивают байты в строку. */
static void push_utf8(u8 code, u32 cp, u8 flags)
{
    char buf[4];
    int n = 0;
    if (cp < 0x80) {
        buf[n++] = (char)cp;
    } else if (cp < 0x800) {
        buf[n++] = (char)(0xC0 | (cp >> 6));
        buf[n++] = (char)(0x80 | (cp & 0x3F));
    } else {
        buf[n++] = (char)(0xE0 | (cp >> 12));
        buf[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
        buf[n++] = (char)(0x80 | (cp & 0x3F));
    }
    for (int i = 0; i < n; i++)
        push_event(code, buf[i], flags);
}

static void push_event(u8 code, char ch, u8 flags)
{
    u32 h = r_head;
    u32 nh = (h + 1) % RING_SIZE;
    if (nh == r_tail) return;         /* буфер полон — теряем */
    ring[h].code = code;
    ring[h].ch = ch;
    ring[h].flags = flags;
    r_head = nh;
}

/* Публичная обёртка для push_event — используется USB-HID драйвером
 * для инжекции событий от USB-клавиатуры в общий kbd ring. */
void kbd_push_event(u8 code, char ch, u8 flags)
{
    push_event(code, ch, flags);
}

static void kbd_irq(void)
{
    u8 sc = inb(0x60);

    if (e0_prefix) {
        e0_prefix = 0;
        switch (sc) {
        case 0x48: push_event(KBD_UP, 0, shift_state); return;
        case 0x4B: push_event(KBD_LEFT, 0, shift_state); return;
        case 0x4D: push_event(KBD_RIGHT, 0, shift_state); return;
        case 0x50: push_event(KBD_DOWN, 0, shift_state); return;
        case 0x1C: push_event(0x1C, '\n', shift_state); return;
        /* Win-клавиши: нажатие открывает/закрывает меню Пуск
         * (release — E0 DB/E0 DC — намеренно игнорируются) */
        case 0x5B: push_event(KBD_LWIN, 0, 0); return;
        case 0x5C: push_event(KBD_RWIN, 0, 0); return;
        default: return; /* прочие E0-коды не используем */
        }
    }

    switch (sc) {
    case 0x2A: case 0x36: shift_state |= KF_SHIFT; return;
    case 0xAA: case 0xB6: shift_state &= (u8)~KF_SHIFT; return;
    case 0x1D: ctrl_state |= KF_CTRL; return;
    case 0x9D: ctrl_state &= (u8)~KF_CTRL; return;
    case 0x38: alt_state |= KF_ALT; return;
    case 0xB8: alt_state &= (u8)~KF_ALT; return;
    case 0x3A:
        /* Task 62 [KB-RU]: CapsLock = ПЕРЕКЛЮЧЕНИЕ РАСКЛАДКИ.
         * Сам toggle делает wm_key (kmain) по событию кода 0x3A —
         * единая точка и для PS/2, и для USB (индикатор обновится).
         * release (0xBA) сюда не попадает — проверка ниже. */
        if (!(sc & 0x80)) push_event(0x3A, 0, 0);
        return;
    case 0xE0: e0_prefix = 1; return;
    default: break;
    }

    u8 rel = 0, code = sc;
    if (code & 0x80) { rel = KF_RELEASED; code &= 0x7F; }

    u8 flags = (u8)(shift_state | ctrl_state | alt_state | rel);
    if (code >= 0x47 && code <= 0x53) {
        /* numpad — игнорируем */
        if (!rel) push_event(code, 0, flags);
        return;
    }

    if (!rel) {
        /* Task 62 [KB-RU]: символ — по ТЕКУЩЕЙ раскладке (EN или RU); кириллица
         * уходит серией UTF-8-байтов. Регистр — по Shift (CapsLock больше
         * не влияет на регистр — он переключает раскладку). */
        u32 cp = kbd_lookup(code, (shift_state & KF_SHIFT) ? 1 : 0);
        if (cp) push_utf8(code, cp, flags);
        else push_event(code, 0, flags);
    }
}

void kbd_init(void)
{
    /* осушаем буфер контроллера от мусора после GRUB */
    for (int i = 0; i < 64 && (inb(0x64) & 1); i++) (void)inb(0x60);
    irq_install(1, kbd_irq);
}

int kbd_pop(key_event_t *out)
{
    if (r_tail == r_head) return 0;
    *out = ring[r_tail];
    r_tail = (r_tail + 1) % RING_SIZE;
    return 1;
}
