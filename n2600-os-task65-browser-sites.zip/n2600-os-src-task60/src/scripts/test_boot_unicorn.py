#!/usr/bin/env python3
# test_boot_unicorn.py — эмуляционный тест загрузчика N2600-OS.
#
# Эмулирует: boot.bin (stage 1) -> stage2.bin -> передачу в ядро,
# с "мини-BIOS" на хуках unicorn: INT 13h (CHS + LBA ext), INT 10h
# (teletype + VBE 4F01/4F02), INT 15h E801.
#
# Проверяются:
#   1. дискета (DL=0, CHS): ядро на 0x100000, bss=0, mb_info, VBE-режим,
#      финальные EAX/EBX/EIP
#   2. HDD/USB суперфлоппи (DL=0x80, LBA ext)
#   3. HDD без LBA ext -> чистый halt с ошибкой 'L'
#   4. цепочка MBR -> VBR (boot_pbr) с ESI=32
#   5. VBE недоступен -> flags без MBIF_FRAMEBUFFER
#
# Запуск: python3 scripts/test_boot_unicorn.py

import struct, subprocess, sys, os
import unicorn as uc_mod
from unicorn import *
from unicorn.x86_const import *

# Корень дерева ОС: скрипт живёт в <корень>/scripts/ (внутри дерева);
# fallback — прежняя схема <workspace>/n2600-os.
_HERE = os.path.dirname(os.path.abspath(__file__))
_UP = os.path.dirname(_HERE)
ROOT = _UP if os.path.isdir(os.path.join(_UP, "boot")) \
    else os.path.join(_UP, "n2600-os")
BOOT = os.path.join(ROOT, "boot")

MB_MAGIC      = 0x1BADB002
MBIF_FB       = 0x1000
MBIF_MEM      = 0x0001
KERNEL_BASE   = 0x100000
PAYLOAD_LEN   = 0x40000          # 256 КиБ фейкового ядра
BSS_LEN       = 0x8000
ENTRY         = KERNEL_BASE + 0x30
MBI           = 0x500
KBASE_RAM     = 0x510
PHYSBASE      = 0xFD000000

# VBE-таблица режимов "как у SeaBIOS"
VBE_MODES = {
    0x110: (640, 480, 15), 0x111: (640, 480, 16), 0x112: (640, 480, 32),
    0x113: (800, 600, 15), 0x114: (800, 600, 16), 0x115: (800, 600, 32),
    0x116: (1024, 768, 15), 0x117: (1024, 768, 16), 0x118: (1024, 768, 32),
    0x119: (1280, 1024, 15), 0x11A: (1280, 1024, 16), 0x11B: (1280, 1024, 24),
}
BEST_MODE = 0x118          # 1024x768x32 — максимум площади среди 32bpp


def make_fake_kernel():
    """Фейковый kernel.bin: multiboot-заголовок + детерминированная мякоть."""
    flags = 0x00010003          # ALIGN|MEMINFO|AOUT_KLUDGE
    hdr = struct.pack(
        "<12I",
        MB_MAGIC, flags, (-(MB_MAGIC + flags)) & 0xFFFFFFFF,
        KERNEL_BASE, KERNEL_BASE, KERNEL_BASE + PAYLOAD_LEN,
        KERNEL_BASE + PAYLOAD_LEN + BSS_LEN, ENTRY,
        0, 0, 0, 0,
    )
    payload = bytes((i * 7 + 13) & 0xFF for i in range(PAYLOAD_LEN - len(hdr)))
    return hdr + payload


def rdd(n):
    return struct.pack("<I", n)


# ---------------------------------------------------------------------------
# Мини-BIOS на UC_HOOK_INTR: в этом unicorn хук ЗАМЕНЯЕТ векторинг —
# после его возврата CPU продолжает с текущими регистрами, поэтому сервис
# просто правит регистры/память/флаги. Записи регистров персистентны
# (проверено в т.ч. на циклах).
# ---------------------------------------------------------------------------

class MiniBios:
    def __init__(self, disk, drive, lba_ext=True, vbe_ok=True):
        self.disk = disk
        self.drive = drive
        self.lba_ext = lba_ext
        self.vbe_ok = vbe_ok
        self.out = ""
        self.mode_set = None
        self.reads = []
        self.chs_reads = 0

    def rd(self, uc, addr, n):
        return bytes(uc.mem_read(addr, n))

    def wr(self, uc, addr, data):
        uc.mem_write(addr, bytes(data))

    def set_cf(self, uc, on):
        fl = uc.reg_read(UC_X86_REG_EFLAGS)
        fl = (fl | 0x0001) if on else (fl & ~0x0001)
        uc.reg_write(UC_X86_REG_EFLAGS, fl | 2)

    def intr(self, uc, intno, data):
        if intno == 0x10:
            self.int10(uc)
        elif intno == 0x13:
            self.int13(uc)
        elif intno == 0x15:
            self.int15(uc)

    # ---------- INT 10h ----------
    def int10(self, uc):
        eax = uc.reg_read(UC_X86_REG_EAX)
        ah, al = (eax >> 8) & 0xFF, eax & 0xFF
        if ah == 0x0E:
            self.out += chr(al)
        elif ah == 0x4F and al == 0x01:      # Return VBE Mode Information
            cx = uc.reg_read(UC_X86_REG_ECX) & 0xFFFF
            esb = (uc.reg_read(UC_X86_REG_ES) & 0xFFFF) * 16
            di = uc.reg_read(UC_X86_REG_EDI) & 0xFFFF
            mode = cx & 0x01FF
            if self.vbe_ok and mode in VBE_MODES:
                w, h, bpp = VBE_MODES[mode]
                buf = bytearray(256)
                struct.pack_into("<H", buf, 0x00, 0x00DB)   # attrs+LFB
                struct.pack_into("<H", buf, 0x10, w * 4)    # pitch
                struct.pack_into("<H", buf, 0x12, w)
                struct.pack_into("<H", buf, 0x14, h)
                buf[0x18] = 1
                buf[0x19] = bpp
                buf[0x1A] = 1
                buf[0x1B] = 6                               # direct color
                buf[0x27] = 8
                struct.pack_into("<I", buf, 0x28, PHYSBASE)
                self.wr(uc, esb + di, buf)
                uc.reg_write(UC_X86_REG_EAX, 0x004F)
            else:
                uc.reg_write(UC_X86_REG_EAX, 0x014F)
        elif ah == 0x4F and al == 0x02:      # Set VBE Mode
            bx = uc.reg_read(UC_X86_REG_EBX) & 0xFFFF
            if self.vbe_ok and (bx & 0x01FF) in VBE_MODES:
                self.mode_set = bx
                uc.reg_write(UC_X86_REG_EAX, 0x004F)
            else:
                uc.reg_write(UC_X86_REG_EAX, 0x014F)

    # ---------- INT 13h ----------
    def int13(self, uc):
        eax = uc.reg_read(UC_X86_REG_EAX)
        ah = (eax >> 8) & 0xFF
        if ah == 0x41:
            bx = uc.reg_read(UC_X86_REG_EBX) & 0xFFFF
            if self.lba_ext and bx == 0x55AA:
                uc.reg_write(UC_X86_REG_EBX, 0xAA55)
                uc.reg_write(UC_X86_REG_EAX, 0x2100)
                uc.reg_write(UC_X86_REG_ECX, 0x0007)
                self.set_cf(uc, False)
            else:
                self.set_cf(uc, True)
        elif ah == 0x42:
            ds = (uc.reg_read(UC_X86_REG_DS) & 0xFFFF) * 16
            si = uc.reg_read(UC_X86_REG_ESI) & 0xFFFF
            dap = self.rd(uc, ds + si, 16)
            cnt, off, seg = struct.unpack_from("<HHH", dap, 2)
            lba = struct.unpack_from("<Q", dap, 8)[0]
            n = cnt * 512
            if lba * 512 + n > len(self.disk):
                self.set_cf(uc, True)
                uc.reg_write(UC_X86_REG_EAX, 0x0400)
                return
            self.wr(uc, seg * 16 + off, self.disk[lba * 512: lba * 512 + n])
            self.reads.append((lba, cnt))
            uc.reg_write(UC_X86_REG_EAX, 0x0042)
            self.set_cf(uc, False)
        elif ah == 0x02:
            ecx = uc.reg_read(UC_X86_REG_ECX)
            edx = uc.reg_read(UC_X86_REG_EDX)
            cnt = eax & 0xFF
            cyl = ((ecx >> 8) & 0xFF) | ((ecx & 0xC0) << 2)
            sect = ecx & 0x3F
            head = (edx >> 8) & 0xFF
            lba = (cyl * 2 + head) * 18 + (sect - 1)
            esb = (uc.reg_read(UC_X86_REG_ES) & 0xFFFF) * 16
            bx = uc.reg_read(UC_X86_REG_EBX) & 0xFFFF
            n = cnt * 512
            if lba * 512 + n > len(self.disk):
                self.set_cf(uc, True)
                uc.reg_write(UC_X86_REG_EAX, 0x0400)
                return
            self.wr(uc, esb + bx, self.disk[lba * 512: lba * 512 + n])
            self.chs_reads += cnt
            uc.reg_write(UC_X86_REG_EAX, 0x0002)
            self.set_cf(uc, False)
        elif ah == 0x00:
            self.set_cf(uc, False)
        else:
            self.set_cf(uc, True)

    # ---------- INT 15h ----------
    def int15(self, uc):
        if (uc.reg_read(UC_X86_REG_EAX) & 0xFFFF) == 0xE801:
            uc.reg_write(UC_X86_REG_EAX, 0x3C00)   # 15360 КБ (1М..16М)
            uc.reg_write(UC_X86_REG_EBX, 0x07FF)   # 2047 блока по 64К
            uc.reg_write(UC_X86_REG_ECX, 0x3C00)
            uc.reg_write(UC_X86_REG_EDX, 0x07FF)
            self.set_cf(uc, False)
        else:
            self.set_cf(uc, True)


def build_disk(kind, kernel):
    """Собрать образ диска по раскладке загрузчика."""
    stage2 = open(os.path.join(BOOT, "stage2.bin"), "rb").read()
    assert len(stage2) == 8704
    ksec = (len(kernel) + 511) // 512
    if kind in ("floppy", "hdd"):
        boot = open(os.path.join(BOOT, "boot.bin"), "rb").read()
        img = bytearray(boot + stage2)
        img += bytearray(18 * 512 - len(img))       # ядро с LBA 18
        img += kernel
        img += bytearray(512 * 4)                   # хвост
        struct.pack_into("<I", img, 512 + 4, ksec)  # ksec @ stage2+4
        if kind == "floppy":
            img += bytearray(2880 * 512 - len(img))
        return bytes(img)
    elif kind == "part":
        mbr = bytearray(open(os.path.join(BOOT, "mbr.bin"), "rb").read())
        pbr = open(os.path.join(BOOT, "boot_pbr.bin"), "rb").read()
        PART = 32
        # запись раздела 1: bootable, CHS, тип 0xDA, LBA=PART, размер
        total = PART + 18 + ksec + 64
        mbr[0x1BE:0x1CE] = (bytes([0x80, 0x00, 0x20, 0x00, 0xDA, 0xFE, 0xFF, 0xFF])
                           + rdd(PART) + rdd(total - PART))
        img = bytearray(mbr)
        img += bytearray(PART * 512 - len(img))
        img += pbr + stage2
        img += bytearray(18 * 512 - (512 + 8704))   # ядро с PART+18
        img += kernel
        img += bytearray(512 * 4)
        # ksec лежит в stage2: смещение PART*512 + 512 + 4
        struct.pack_into("<I", img, PART * 512 + 512 + 4, ksec)
        img += bytearray(512 * 8)
        return bytes(img)
    raise ValueError(kind)


def run_emu(disk, drive, start_eip=0x7C00, lba_ext=True, vbe_ok=True,
            kind="floppy", max_steps=300_000_000):
    """
    Гибридная схема обслуживания INT (обходит кворки unicorn 2.1.4):

      * UC_HOOK_INTR в этом unicorn ЗАМЕНЯЕТ векторинг, но срабатывает на
        границе TB — в циклах с INT внутри записи регистров из хука
        «опаздывают» на итерацию;
      * поэтому код-хук останавливает эмуляцию ПЕРЕД инструкцией INT,
        Python исполняет сервис МЕЖДУ emu_start (записи регистров между
        вызовами emu_start абсолютно надёжны), а затем INT исполняется и
        проглатывается no-op UC_HOOK_INTR (векторинга нет вообще).
    """
    uc = Uc(UC_ARCH_X86, UC_MODE_16)
    uc.mem_map(0, 0x4000000)                       # 64 МБ плоско
    bios = MiniBios(disk, drive, lba_ext=lba_ext, vbe_ok=vbe_ok)
    uc.hook_add(UC_HOOK_INTR, lambda u, intno, ud: None)  # глотатель INT

    state = {"stopped": None}

    # Карта INT-инструкций: линейный адрес -> номер прерывания.
    # Собирается из бинарей — нет ложных срабатываний на 0xCD в данных.
    int_map = {}
    if kind == "part":
        # mbr после релокации исполняется в 0x600 (0x7C00-копия к тому
        # моменту больше не исполняется, а 0x7C00 займёт VBR!)
        blobs = ((0x600,  open(os.path.join(BOOT, "mbr.bin"), "rb").read()),
                 (0x7C00, open(os.path.join(BOOT, "boot_pbr.bin"), "rb").read()))
    else:
        blobs = ((0x7C00, disk[:512]),)
    blobs += ((0x7E00, open(os.path.join(BOOT, "stage2.bin"), "rb").read()),)
    for base, blob in blobs:
        for off, b in enumerate(blob):
            if b == 0xCD and off + 1 < len(blob) and 0x10 <= blob[off + 1] <= 0x20:
                int_map[base + off] = blob[off + 1]

    def stepper(u, addr, size, ud):
        if addr == ENTRY:
            state["stopped"] = "kernel"
            u.emu_stop()
            return
        if addr in int_map:
            u.emu_stop()

    # диапазон широкий: MBR релоцируется в 0x600, VBR/стейджи в 0x7C00+
    uc.hook_add(UC_HOOK_CODE, stepper, begin=0x0, end=0xA0000)

    def kernel_entry_hook(u, ad, sz, ud):
        state["stopped"] = "kernel"
        u.emu_stop()
    uc.hook_add(UC_HOOK_CODE, kernel_entry_hook,
                begin=KERNEL_BASE, end=KERNEL_BASE + 0x100)

    # начальное состояние: real mode
    if kind == "part":
        # имитация результата работы mbr.bin: VBR уже в 0x7C00,
        # ESI = LBA раздела (соглашение Microsoft)
        uc.mem_write(0x7C00, open(os.path.join(BOOT, "boot_pbr.bin"), "rb").read())
        uc.reg_write(UC_X86_REG_ESI, 32)
    else:
        uc.mem_write(0x7C00, disk[:512])
    uc.reg_write(UC_X86_REG_EIP, start_eip)
    for r in (UC_X86_REG_CS, UC_X86_REG_DS, UC_X86_REG_ES, UC_X86_REG_SS,
              UC_X86_REG_FS, UC_X86_REG_GS):
        uc.reg_write(r, 0)
    uc.reg_write(UC_X86_REG_ESP, 0x7C00)
    uc.reg_write(UC_X86_REG_EDX, drive)            # DL = boot drive (BIOS)
    uc.reg_write(UC_X86_REG_EFLAGS, 0x202)
    uc.reg_write(UC_X86_REG_CR0, 0x10)             # PE=0

    err = None
    eip = start_eip
    steps = 0
    while True:
        steps += 1
        if steps > 20000:                          # защита от вечного цикла INT
            err = "too many INT restarts"
            break
        try:
            uc.emu_start(eip, 1 << 62, 0, max_steps)
        except UcError as e:
            err = f"{e} @ eip=0x{uc.reg_read(UC_X86_REG_EIP):x}"
            break
        eip = uc.reg_read(UC_X86_REG_EIP)
        if state["stopped"] == "kernel":
            break
        # останов перед INT: сервис ПОЛНОСТЬЮ заменяет инструкцию —
        # применяем эффекты и перепрыгиваем INT (сам он не исполняется)
        if eip in int_map:
            bios.intr(uc, int_map[eip], None)      # записи регистров надёжны
            eip += 2
        else:
            break                                  # неожиданный останов
    return bios, state, err, uc


def load_symbols():
    """Символы stage2 (через nm отладочной сборки)."""
    subprocess.run(["as", "--32", "-o", "/tmp/t_s2.o",
                    os.path.join(BOOT, "stage2.S")], check=True)
    subprocess.run(["ld", "-m", "elf_i386", "-Ttext=0x7E00", "-e", "_start",
                    "-o", "/tmp/t_s2.elf", "/tmp/t_s2.o"], check=True)
    out = subprocess.run(["nm", "/tmp/t_s2.elf"], check=True,
                         capture_output=True, text=True).stdout
    sym = {}
    for line in out.splitlines():
        parts = line.split()
        if len(parts) == 3:
            sym[parts[2]] = int(parts[0], 16)
    if "halt_spin" not in sym:
        raise RuntimeError("halt_spin не найден")
    return sym


def check_common(bios, uc, label, errs, expect_fb=True):
    # 1) ядро на месте
    kernel = FAKE_KERNEL
    mem = bytes(uc.mem_read(KERNEL_BASE, len(kernel)))
    if mem != kernel:
        diff = next(i for i in range(len(kernel)) if mem[i] != kernel[i])
        errs.append(f"{label}: ядро по 0x100000 не совпадает (первое различие @{diff:#x})")
    # 2) bss обнулён
    bss = bytes(uc.mem_read(KERNEL_BASE + PAYLOAD_LEN, BSS_LEN))
    if any(bss):
        errs.append(f"{label}: .bss не обнулён")
    # 3) mb_info
    mbi = bytes(uc.mem_read(MBI, 116))
    flags, mem_lower, mem_upper = struct.unpack_from("<III", mbi, 0)
    want_flags = (MBIF_MEM | MBIF_FB) if expect_fb else MBIF_MEM
    if flags != want_flags:
        errs.append(f"{label}: mb flags = {flags:#x}, ожидалось {want_flags:#x}")
    if mem_upper != 146368:
        errs.append(f"{label}: mem_upper = {mem_upper}, ожидалось 146368")
    fb_addr, = struct.unpack_from("<Q", mbi, 88)
    pitch, width, height = struct.unpack_from("<III", mbi, 96)
    bpp, fbtype = mbi[108], mbi[109]
    if expect_fb:
        if (fb_addr, pitch, width, height, bpp, fbtype) != \
           (PHYSBASE, 4096, 1024, 768, 32, 1):
            errs.append(f"{label}: fb поля: addr={fb_addr:#x} pitch={pitch} "
                        f"w={width} h={height} bpp={bpp} type={fbtype}")
    return mbi


def check_final_regs(uc, label, errs):
    eax = uc.reg_read(UC_X86_REG_EAX) & 0xFFFFFFFF
    ebx = uc.reg_read(UC_X86_REG_EBX) & 0xFFFFFFFF
    eip = uc.reg_read(UC_X86_REG_EIP)
    cs_sel = uc.reg_read(UC_X86_REG_CS)
    if eax != 0x2BADB002:
        errs.append(f"{label}: EAX={eax:#x} (не multiboot magic)")
    if ebx != MBI:
        errs.append(f"{label}: EBX={ebx:#x} (не 0x500)")
    if eip != ENTRY:
        errs.append(f"{label}: EIP={eip:#x} (не entry {ENTRY:#x})")
    if cs_sel != 0x18:
        errs.append(f"{label}: CS={cs_sel:#x} (не 0x18)")


FAKE_KERNEL = make_fake_kernel()
SYM = load_symbols()
HALT_SPIN = SYM["halt_spin"]
FAILURES = []


def run_case(name, *args, **kw):
    print(f"--- тест: {name}")
    want_char = kw.pop("want_char", None)
    bios, state, err, uc = run_emu(*args, **kw)
    errs = []
    if state["stopped"] == "kernel":
        check_common(bios, uc, name, errs, expect_fb=kw.get("vbe_ok", True))
        check_final_regs(uc, name, errs)
        print(f"    VBE set mode: {bios.mode_set:#06x}" if bios.mode_set
              else "    VBE set mode: нет")
        print(f"    INT13h: LBA-чанков {len(bios.reads)}, CHS-секторов {bios.chs_reads}")
    else:
        if err:
            print(f"    останов: {err}")
        eip = uc.reg_read(UC_X86_REG_EIP)
        if not (HALT_SPIN <= eip <= HALT_SPIN + 4):
            errs.append(f"{name}: аварийный останов ВНЕ halt_spin (eip={eip:#x})")
        if want_char and not bios.out.rstrip().endswith(want_char):
            errs.append(f"{name}: в выводе нет кода ошибки '{want_char}': '{bios.out}'")
        print(f"    teletype: '{bios.out}'")
    if errs:
        FAILURES.extend(errs)
        for e in errs:
            print(f"    [FAIL] {e}")
    else:
        print("    [OK]")


def want_char_not_in(out, ch):
    return not out.rstrip().endswith(ch)


if __name__ == "__main__":
    print(f"halt_spin stage2 = {HALT_SPIN:#x}")
    print(f"фейковое ядро: {len(FAKE_KERNEL)} байт ({(len(FAKE_KERNEL)+511)//512} секторов)")

    run_case("дискета (CHS)", build_disk("floppy", FAKE_KERNEL), 0x00,
             kind="floppy")
    run_case("HDD суперфлоппи (LBA)", build_disk("hdd", FAKE_KERNEL), 0x80,
             kind="hdd")
    run_case("HDD без LBA ext -> halt 'L'", build_disk("hdd", FAKE_KERNEL), 0x80,
             kind="hdd", lba_ext=False, want_char="L")
    run_case("VBE недоступен -> flags без FB", build_disk("hdd", FAKE_KERNEL), 0x80,
             kind="hdd", vbe_ok=False)
    run_case("VBR с ESI=32 (после mbr.bin)", build_disk("part", FAKE_KERNEL), 0x80,
             kind="part", start_eip=0x7C00)

    print()
    if FAILURES:
        print(f"ИТОГ: {len(FAILURES)} ПРОВАЛ(ОВ)")
        sys.exit(1)
    print("ИТОГ: все тесты пройдены")
