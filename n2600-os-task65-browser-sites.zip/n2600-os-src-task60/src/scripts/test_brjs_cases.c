/* Изолированные кейсы с корректным порядком page_url ДО brjs_start */
#define HOST_TEST 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef unsigned int  u32;
typedef unsigned char u8;
typedef short i16;

#include "../src/mquickjs.h"
#include "../src/brform.h"
#include "mqjs_host_stubs.h"
#include "../src/brjs.h"
#include "../src/mqjs_stdlib_os64.h"

#define CFUNC_BASE ((int)(sizeof(js_c_function_table) / sizeof(js_c_function_table[0])) - 6)

unsigned int brjs_host_ticks(void) { static unsigned t; return t += 10; }
int brjs_host_stack_range(unsigned int *lo, unsigned int *hi)
{ *lo = 0x10000000u; *hi = 0x7F000000u; return 1; }

static brjs_env_t e;

static void fresh(void)
{
    if (e.alive) brjs_stop(&e);
    memset(&e, 0, sizeof(e));
    if (brjs_start(&e, (const JSSTDLibraryDef *)&js_stdlib, CFUNC_BASE) != 0) {
        printf("brjs_start FAIL\n");
        exit(1);
    }
    brjs_set_page_url(&e, "https://test.example/page.html");  /* ПОСЛЕ start */
}

int main(void)
{
    int fails = 0;
#define CHECK(c, m) do { printf("%s: %s\n", (c) ? "OK" : "FAIL", m); if (!(c)) fails++; } while (0)

    /* P0: href изначально = page_url; скрипт без навигации не даёт nav */
    fresh();
    brjs_eval(&e, "var x = 1;", "p0");
    CHECK(!e.nav_pending, "P0: скрипт без навигации — nav нет");
    brjs_eval(&e, "alert(':' + location.href + ':');", "p0b");
    CHECK(strcmp(e.alert, ":https://test.example/page.html:") == 0,
           "P0b: href == page_url");

    /* P1: String() в MicroQuickJS возвращает undefined (особенность
     * движка, НЕ баг фикса) — фикс нигде String не использует */
    fresh();
    brjs_eval(&e, "alert(typeof String + '/' + String('ab'));", "p1");
    printf("   p1 (info) alert='%s'\n", e.alert);

    /* P2: location.href= */
    fresh();
    brjs_eval(&e, "location.href = 'https://go.example/next';", "p2");
    CHECK(e.nav_pending && strcmp(e.nav_url, "https://go.example/next") == 0,
          "P2: location.href=");

    /* P3: location.replace() */
    fresh();
    brjs_eval(&e, "location.replace('/relative/one');", "p3");
    if (!e.nav_pending || strcmp(e.nav_url, "/relative/one") != 0)
        printf("   p3 err='%s'\n", e.last_err);
    CHECK(e.nav_pending && strcmp(e.nav_url, "/relative/one") == 0,
          "P3: location.replace()");

    /* P4: window.location.href= */
    fresh();
    brjs_eval(&e, "window.location.href = 'https://go.example/w';", "p4");
    if (!e.nav_pending || strcmp(e.nav_url, "https://go.example/w") != 0)
        printf("   p4 err='%s'\n", e.last_err);
    CHECK(e.nav_pending && strcmp(e.nav_url, "https://go.example/w") == 0,
          "P4: window.location.href=");

    /* P5: window.location.replace() */
    fresh();
    brjs_eval(&e, "window.location.replace('/r2');", "p5");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/r2") == 0,
          "P5: window.location.replace()");

    /* P6: document.write/alert без навигации */
    fresh();
    brjs_eval(&e, "document.write('<b>hi</b>'); alert('ok');", "p6");
    CHECK(!e.nav_pending && e.wlen > 0 &&
          strcmp(e.wbuf_static, "<b>hi</b>") == 0, "P6: write+alert, nav нет");

    /* P7: self-href без навигации */
    fresh();
    brjs_eval(&e, "location.href = 'https://test.example/page.html';", "p7");
    CHECK(!e.nav_pending, "P7: self-href — nav нет");

    /* P8: document.location.href= */
    fresh();
    brjs_eval(&e, "document.location.href = '/d1';", "p8");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/d1") == 0,
          "P8: document.location.href=");

    /* P9: исключение до присвоения — nav нет */
    fresh();
    brjs_eval(&e, "undefined_fn(); location.href='/never';", "p9");
    CHECK(!e.nav_pending, "P9: исключение прерывает до присвоения");

    /* P10: fetch жив */
    fresh();
    brjs_eval(&e, "var r = fetch('u');", "p10");
    CHECK(!e.nav_pending, "P10: fetch, nav нет");

    brjs_stop(&e);
    printf(fails ? "\n%d FAILURES\n" : "\nALL ISOLATED CASES PASSED\n", fails);
    return fails != 0;
}
