/* hd_imgaccess.h — доступ к RAM-образу из main.c (определяется в hostdisk.c). */
#ifndef HD_IMGACCESS_H
#define HD_IMGACCESS_H
u8 *test_image(void);
#endif
