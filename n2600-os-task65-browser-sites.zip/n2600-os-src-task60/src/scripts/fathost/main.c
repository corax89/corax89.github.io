/* main.c — хост-тест исправлений FAT32 (task57): [FAT32-CLSTFIX],
 * [FAT-LFN40], [FAT-LEAK], [FMT-OOB], [FMT-DEINIT], [FAT-SAFEWRITE].
 * Компилируется С РЕАЛЬНЫМИ fat32.c/exfat.c/fat32_format.c + шимы. */
#include <string.h>
extern int printf(const char *fmt, ...);   /* без <stdio.h>: glibc snprintf(size_t) конфликтует с ядровым u32 */
#include "fat32.h"
#include "fat32_format.h"
#include "disk.h"

static int PASS = 0, FAIL = 0;
#define CHECK(name, ok, ...) do { \
    if (ok) { PASS++; printf("  [PASS] %s\n", name); } \
    else    { FAIL++; printf("  [FAIL] %s — ", name); printf(__VA_ARGS__); printf("\n"); } \
} while (0)

static u32 fmt_fat_size = 0, fmt_data_start = 0, fmt_total = 0;

extern u8 *test_image(void);        /* доступ к образу для сырого парсинга */
#include "hd_imgaccess.h"

/* ---- парс BPB из образа (сырой) ---- */
static void parse_bpb(void)
{
    u8 *img = test_image();
    fmt_total     = (u32)img[32] | ((u32)img[33] << 8) | ((u32)img[34] << 16) | ((u32)img[35] << 24);
    fmt_fat_size  = (u32)img[36] | ((u32)img[37] << 8) | ((u32)img[38] << 16) | ((u32)img[39] << 24);
    u8 spc        = img[13];
    u8 nfat       = img[16];
    fmt_data_start = 32 + nfat * fmt_fat_size;
    (void)spc;
}

/* ---- число свободных кластеров по FAT в образе ---- */
static u32 fat_free_count(void)
{
    u8 *img = test_image();
    u32 total_cl = (fmt_total - fmt_data_start);      /* spc=1 */
    u32 free_n = 0;
    for (u32 c = 2; c < total_cl + 2; c++) {
        u32 off = fmt_fat_size * 0;                    /* FAT1 начинается с LBA 32 */
        u64 fat_lba = 32 + off + c / 128;              /* 4 байта/энтри, 512/4=128 */
        u32 e_off = (c % 128) * 4;
        u32 v = (u32)img[fat_lba * 512 + e_off] |
                ((u32)img[fat_lba * 512 + e_off + 1] << 8) |
                ((u32)img[fat_lba * 512 + e_off + 2] << 16) |
                ((u32)img[fat_lba * 512 + e_off + 3] << 24);
        if ((v & 0x0FFFFFFFu) == 0) free_n++;
    }
    return free_n;
}

/* ---- сырой разбор LFN-записей в кластере каталога ---- */
/* cluster_lba — LBA первого сектора кластера; печатает/считает 0x40 */
static int lfn_0x40_count(u32 cluster_lba, u32 spc)
{
    u8 *img = test_image();
    int cnt = 0;
    for (u32 s = 0; s < spc; s++) {
        u8 *sec = img + (u64)(cluster_lba + s) * 512;
        for (u32 off = 0; off + 32 <= 512; off += 32) {
            u8 *e = sec + off;
            if (e[0] == 0x00 || e[0] == 0xE5) continue;
            if (e[11] == 0x0F && (e[0] & 0x40)) cnt++;
        }
    }
    return cnt;
}

int main(void)
{
    printf("=== хост-тест исправлений FAT32 (task57) ===\n");

    /* ---------- 1. Форматирование ([FMT-OOB], [FMT-DEINIT]) ---------- */
    printf("[1] fat32_format_hdd (ASan следит за OOB-чтениями)\n");
    hd_reset_stats();
    int rc = fat32_format_hdd(NULL, NULL, 0);
    CHECK("формат возвращён OK", rc == FAT32_FMT_OK, "rc=%d", rc);
    CHECK("нет OOB за образ", !hd_oob_seen(), "oob");
    CHECK("[FMT-DEINIT] том снят после формата", !fat32_ready(), "ready=%d", fat32_ready());
    parse_bpb();
    printf("    (total=%u fat=%u data_start=%u)\n",
           (unsigned)fmt_total, (unsigned)fmt_fat_size, (unsigned)fmt_data_start);

    /* ---------- 2. Монтирование superfloppy ---------- */
    printf("[2] fat32_init\n");
    CHECK("смонтировалась", fat32_init() == 1, "init failed");
    CHECK("готова", fat32_ready(), "not ready");
    CHECK("нет OOB при монтировании", !hd_oob_seen(), "oob");

    /* ---------- 3. [FAT-LFN40]: длинное имя, 0x40 только на первой ---------- */
    printf("[3] LFN 0x40 только на первой физической записи\n");
    {
        const char *nm = "ОченьДлинноеИмяФайла12345.txt";
        char content[300];
        memset(content, 'A', sizeof(content));
        u32 w = fat32_write_file(0, nm, content, sizeof(content));
        CHECK("файл записан", w == sizeof(content), "w=%u", (unsigned)w);

        u32 root = fat32_root_cluster();     /* = 2 */
        u32 cl_lba = fmt_data_start + (root - 2);   /* spc=1 */
        int cnt40 = lfn_0x40_count(cl_lba, 1);
        CHECK("0x40 ровно на ОДНОЙ LFN-записи", cnt40 == 1, "cnt40=%d", cnt40);

        /* первая физическая LFN имеет наибольший seq и несёт 0x40 */
        u8 *sec = test_image() + (u64)cl_lba * 512;
        u8 *e0 = NULL;
        for (u32 off = 0; off + 32 <= 512; off += 32) {
            u8 *e = sec + off;
            if (e[0] != 0x00 && e[0] != 0xE5 && e[11] == 0x0F) { e0 = e; break; }
        }
        CHECK("первая LFN найдена", e0 != NULL, "нет");
        if (e0) {
            CHECK("у неё seq=3 и бит 0x40",
                  (e0[0] & 0x1F) == 3 && (e0[0] & 0x40), "byte0=0x%02x", e0[0]);
        }
        /* вторая/третья — без 0x40 */
        u8 *e1 = e0 + 32, *e2 = e0 + 64;
        if (e0 && e1[11] == 0x0F && e2[11] == 0x0F) {
            CHECK("seq2/seq3 без 0x40",
                  (e1[0] & 0x40) == 0 && (e2[0] & 0x40) == 0,
                  "b1=0x%02x b2=0x%02x", e1[0], e2[0]);
        }
        /* имя читается листингом */
        fat32_dirent_t ents[32];
        u32 n = fat32_list(0, ents, 32);
        int found = 0;
        for (u32 i = 0; i < n; i++)
            if (!strcmp(ents[i].name, nm)) found = 1;
        CHECK("LFN читается fat32_list", found, "n=%u", (unsigned)n);
    }

    /* ---------- 4. [FAT32-CLSTFIX]: заполнение до конца без порчи ---------- */
    printf("[4] заполнение диска до отказа (кластерные границы)\n");
    {
        char big[64 * 1024];
        memset(big, 'B', sizeof(big));
        u32 files = 0, total_written = 0;
        for (int i = 0; i < 20000; i++) {
            char nm[32];
            /* уникальный 8.3-базис: fill_XXXXX.bin сводился бы к одному
             * SFN "FILL_0~N" (лимит 100 коллизий) — тест упирался не в
             * конец диска, а в лимит генератора имён */
            snprintf(nm, sizeof(nm), "F%05d.DAT", i);
            u32 w = fat32_write_file(0, nm, big, sizeof(big));
            if (w != sizeof(big)) break;
            files++; total_written += w;
        }
        printf("    записано %u файлов (%u КиБ)\n",
               (unsigned)files, (unsigned)(total_written / 1024));
        CHECK("диск заполнился до отказа", files > 500, "files=%u", (unsigned)files);
        CHECK("ни одной записи за пределы тома", !hd_oob_seen(), "oob!");

        /* перемонтирование + полная проверка читаемости: порча FAT2/корня
         * (старый баг) сделала бы часть файлов нечитаемой */
        fat32_deinit();
        CHECK("перемонтировалась после заполнения", fat32_init() == 1, "init");
        fat32_dirent_t ents[64];
        u32 n = fat32_list(0, ents, 64);
        CHECK("корень читается после заполнения", n > 0, "n=%u", (unsigned)n);
        /* выборочно проверяем содержимое первого и последнего файла */
        int bad = 0, checked = 0;
        char buf[64 * 1024];
        for (u32 i = 0; i < n && checked < 8; i++) {
            if (ents[i].attr & 0x10) continue;
            if (strncmp(ents[i].name, "F0", 2) != 0) continue;
            u32 rd = fat32_read_file(ents[i].first_cluster, ents[i].size,
                                     buf, sizeof(buf));
            if (rd != ents[i].size) { bad++; continue; }
            for (u32 k = 0; k < rd; k++)
                if (buf[k] != 'B') { bad++; break; }
            checked++;
        }
        CHECK("содержимое файлов цело (8/8 проверено, 0 битых)",
              checked == 8 && bad == 0, "checked=%d bad=%d", checked, bad);

        /* ёмкость: остался хвост < 128 кластеров (последний 64К-файл
         * целиком не влез — это корректный отказ «места нет», а не порча);
         * малый файл в хвост ещё помещается */
        u32 fc = fat_free_count();
        CHECK("хвост < 128 кластеров (64К-файл больше не влезает)",
              fc < 128, "free=%u", (unsigned)fc);
        {
            char tail[32 * 1024];
            memset(tail, 'C', sizeof(tail));
            u32 w = fat32_write_file(0, "TAILDAT.FIL", tail, sizeof(tail));
            CHECK("малый файл в хвост помещается", w == sizeof(tail), "w=%u", (unsigned)w);
            u32 fc2 = fat_free_count();
            CHECK("после него снова отказ на 64К",
                  fat32_write_file(0, "TAILBIG.FIL", tail, sizeof(tail)) != sizeof(tail),
                  "влез?!");
            (void)fc2;
        }
    }

    /* ---------- 5. [FAT-SAFEWRITE]: неудача перезаписи сохраняет старое ---------- */
    printf("[5] перезапись при нехватке места — старое содержимое цело\n");
    {
        /* диск полон: освободим один файл (~64 КиБ), затем попробуем
         * перезаписать ДРУГОЙ файл 2 МиБ — должно не влезть */
        fat32_dirent_t ents[64];
        u32 n = fat32_list(0, ents, 64);
        u32 freed = 0;
        for (u32 i = 0; i < n && !freed; i++) {
            if ((ents[i].attr & 0x10) == 0 &&
                !strncmp(ents[i].name, "F0", 2)) {
                CHECK("удалён один файл", fat32_delete(0, ents[i].name) == 1, "del");
                freed = 1;
            }
        }
        CHECK("есть что удалять", freed, "нет");

        /* жертва — второй fill_файл; читаем его содержимое ДО попытки */
        fat32_dirent_t victim;
        memset(&victim, 0, sizeof(victim));
        CHECK("жертва найдена", fat32_find_entry(0, "F00001.DAT", &victim) == 1, "нет");
        char before[64 * 1024];
        u32 rd = fat32_read_file(victim.first_cluster, victim.size, before, sizeof(before));
        CHECK("содержимое жертвы прочитано", rd == victim.size && rd > 0, "rd=%u", (unsigned)rd);

        static char huge[2 * 1024 * 1024];
        memset(huge, 'Z', sizeof(huge));
        u32 w = fat32_write_file(0, "F00001.DAT", huge, sizeof(huge));
        CHECK("перезапись 2 МиБ не влезла", w != sizeof(huge), "w=%u", (unsigned)w);

        char after[64 * 1024];
        rd = fat32_read_file(victim.first_cluster, victim.size, after, sizeof(after));
        CHECK("[FAT-SAFEWRITE] старое содержимое цело",
              rd == victim.size && rd > 0 && memcmp(before, after, rd) == 0,
              "rd=%u", (unsigned)rd);
    }

    /* ---------- 6. [FAT-LEAK]: откат при I/O-ошибке не теряет кластеры ---------- */
    printf("[6] I/O-ошибка при росте каталога — кластеры не утекают\n");
    {
        /* уходим в подкаталог с длинным именем (рост корня уже был? —
         * создаём новый каталог в КОНЦЕ заполненного диска после удаления
         * нескольких файлов: свободные кластеры разбросаны) */
        u32 free_before = fat_free_count();

        /*mkdir с длинным именем: needs 3 LFN + 1 → и рост каталога,
         * и set_fat(tail,nc): вооружаем фолт на 3-й записи (после
         * set_fat(nc,EOC) двух копий FAT) — упадёт set_fat(tail,nc) */
        hd_fault_arm(2, 1);                 /* skip 2 записи, fail 1 */
        int ok = fat32_mkdir(0, "КаталогСДлиннымИменемДляТестаОтката");
        hd_fault_disarm();
        CHECK("mkdir с фолтом вернул отказ", ok == 0, "ok=%d", ok);

        u32 free_after = fat_free_count();
        CHECK("[FAT-LEAK] свободных кластеров столько же, сколько было",
              free_after == free_before,
              "before=%u after=%u", (unsigned)free_before, (unsigned)free_after);

        /* и ФС жива: создаём файл после сбоя */
        char t[100]; memset(t, 'T', sizeof(t));
        CHECK("ФС работоспособна после отката",
              fat32_write_file(0, "after_fault.bin", t, sizeof(t)) == sizeof(t), "w");
    }

    printf("\n=== ИТОГ: PASS=%d FAIL=%d ===\n", PASS, FAIL);
    return FAIL ? 1 : 0;
}
