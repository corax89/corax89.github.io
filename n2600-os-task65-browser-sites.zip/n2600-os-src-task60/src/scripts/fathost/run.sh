#!/bin/sh
# run.sh — хост-тест FAT32 на РЕАЛЬНЫХ src/src/fat32.c|exfat.c|fat32_format.c
# (ASan/UBSan): [FAT32-CLSTFIX] [FAT-LFN40] [FAT-LEAK] [FMT-OOB]
# [FMT-DEINIT] [FAT-SAFEWRITE]. 29 проверок. Детали — main.c.
set -e
cd "$(dirname "$0")"
cp ../../src/fat32.c ../../src/exfat.c ../../src/fat32_format.c .
cp ../../src/fat32.h ../../src/exfat.h ../../src/fat32_format.h ../../src/types.h ../../src/sync.h .
gcc -g -O1 -fno-builtin -fsanitize=address,undefined -Ishim -I. \
    -o fathost main.c hostdisk.c fat32.c exfat.c fat32_format.c
./fathost
