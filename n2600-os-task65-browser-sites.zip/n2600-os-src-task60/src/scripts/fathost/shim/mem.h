#ifndef SHIM_MEM_H
#define SHIM_MEM_H
#include "types.h"
void *malloc(u32 n);
void  free(void *p);
#endif
