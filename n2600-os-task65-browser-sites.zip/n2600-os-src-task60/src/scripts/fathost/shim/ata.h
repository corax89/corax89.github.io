#ifndef SHIM_ATA_H
#define SHIM_ATA_H
#include "types.h"
int   ata_hdd_present(void);
int   ata_read(u32 lba, u8 count, void *buf);
int   ata_read_hdd(u32 lba, u8 count, void *buf);
#endif
