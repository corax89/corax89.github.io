/* Шим-заголовки для хост-теста fat32 (заменяют ядерные диск/память). */
#ifndef SHIM_DISK_H
#define SHIM_DISK_H
#include "types.h"
typedef struct { u32 start_lba; u32 sectors; } disk_part_t;  /* минималка */
int  disk_hdd_present(void);
int  disk_hdd_read(u32 lba, u8 count, void *buf);
int  disk_hdd_write(u32 lba, u8 count, const void *buf);
u32  disk_hdd_sectors(void);
const disk_part_t *disk_part(int i);
int  disk_part_count(void);
const char *disk_part_fstype(int i);
/* хуки теста */
void hd_reset_stats(void);
u32  hd_writes(void);
int  hd_oob_seen(void);
void hd_fault_arm(int skip, int fails);   /* после skip записей — fail fails подряд */
void hd_fault_disarm(void);
#endif
