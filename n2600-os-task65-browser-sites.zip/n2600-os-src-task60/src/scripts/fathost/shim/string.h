/* Шим string.h: glibc-строка; stdio НЕ тянем (glibc snprintf(size_t)
 * конфликтует с ядровой сигнатурой — реализацию с u32 даёт hostdisk.c). */
#ifndef SHIM_STRING_H
#define SHIM_STRING_H
#include "types.h"
#include_next <string.h>
int snprintf(char *out, u32 n, const char *fmt, ...);
#endif
