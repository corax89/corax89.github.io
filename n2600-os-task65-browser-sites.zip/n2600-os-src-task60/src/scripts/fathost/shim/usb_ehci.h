#ifndef SHIM_USB_H
#define SHIM_USB_H
#include "types.h"
int  usb_ehci_read_sector(u32 lba, void *buf);
int  usb_ehci_write_sector(u32 lba, const void *buf);
int  usb_ehci_storage_ready(void);
#endif
