#!/usr/bin/env python3
"""Хост-тест «крошек» (сессия 62): извлекает РЕАЛЬНУЮ fm_path_comp из
src/fileman.c и РЕАЛЬНУЮ fd_path_comp из src/filedlg.c, проверяет
разбор пути (общая логика кликабельных частей адреса), а также
идентичность парсера пути в обоих файлах.
Запуск: python3 scripts/test_crumbs_host.py (из корня n2600-os)."""
import re
import subprocess
import sys
import tempfile
import os

FM = "src/fileman.c"
FD = "src/filedlg.c"

def extract(path, fname):
    src = open(path, encoding="utf-8").read()
    m = re.search(r"static int " + fname + r"\(.*?\n\}", src, re.S)
    if not m:
        print("FAIL: %s не найдена в %s" % (fname, path))
        sys.exit(1)
    return m.group(0).replace("static int " + fname, "int " + fname, 1)

fm_fn = extract(FM, "fm_path_comp")
fd_fn = extract(FD, "fd_path_comp")

# парсер пути в обоих файлах обязан быть идентичным (кроме имени)
fm_body = fm_fn[fm_fn.index("{"):]
fd_body = fd_fn[fd_fn.index("{"):]
if fm_body != fd_body:
    print("FAIL: тела fm_path_comp и fd_path_comp расходятся — править оба файла")
    sys.exit(1)
print("ok: fm_path_comp и fd_path_comp идентичны")

cases = [
    ("/a/b/c", 1, "a"),
    ("/a/b/c", 2, "b"),
    ("/a/b/c", 3, "c"),
    ("/a/b/c", 4, None),      # глубже пути — нет
    ("/", 1, None),           # корень — компонент нет
    ("", 1, None),            # пустой путь
    ("/games", 1, "games"),
    ("/games/saves/slot 1", 3, "slot 1"),
    ("//double//slash", 2, "slash"),   # двойные слэши пропускаются
]

main_c = r'''
#include <stdio.h>
#include <string.h>
static int failures = 0;
static void expect(const char *path, int seg, const char *want)
{
    char out[16];
    int ok = fm_path_comp(path, seg, out, sizeof(out));
    if (want == NULL) {
        if (ok) { printf("FAIL: (\"%s\", %d) -> \"%s\", ожидалась неудача\n",
                         path, seg, out); failures++; }
        else printf("ok: (\"%s\", %d) -> нет сегмента\n", path, seg);
    } else if (!ok || strcmp(out, want) != 0) {
        printf("FAIL: (\"%s\", %d) -> \"%s\", ожидалось \"%s\"\n",
               path, seg, ok ? out : "(нет)", want);
        failures++;
    } else {
        printf("ok: (\"%s\", %d) -> \"%s\"\n", path, seg, out);
    }
}
/* обрезка по буферу: out[16], имя длиннее — режется без переполнения */
static void expect_trunc(void)
{
    char out[16];
    memset(out, 'X', sizeof(out));
    int ok = fm_path_comp("/abcdefghijklmnop", 1, out, sizeof(out));
    if (!ok || strlen(out) != 15 || strncmp(out, "abcdefghijklmno", 15) != 0
        || out[15] != 0) {
        printf("FAIL: обрезка: \"%s\" len=%zu ok=%d\n", out, strlen(out), ok);
        failures++;
    } else {
        printf("ok: обрезка длинного имени до буфера (\"%s\")\n", out);
    }
}
int main(void) {
''' + "".join('    expect("%s", %d, %s);\n' % (
        p.replace('"', '\\"'), s, "NULL" if w is None else '"%s"' % w)
    for p, s, w in cases) + r'''    expect_trunc();
    printf(failures ? "\nИТОГ: ЕСТЬ ОШИБКИ (%d)\n" : "\nИТОГ: все проверки пройдены\n",
           failures);
    return failures != 0;
}
'''

with tempfile.TemporaryDirectory() as td:
    cpath = os.path.join(td, "t.c")
    binp = os.path.join(td, "t")
    open(cpath, "w", encoding="utf-8").write(
        "#include <string.h>\n" + fm_fn + "\n" + main_c)
    r = subprocess.run(["gcc", "-Wall", "-Wextra", "-o", binp, cpath],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print("FAIL: компиляция:\n" + r.stderr)
        sys.exit(1)
    if r.stderr.strip():
        print("warnings:\n" + r.stderr)
    sys.exit(subprocess.run([binp]).returncode)
