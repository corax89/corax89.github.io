/* test_pipeline.c — СКВОЗНОЙ хост-тест сессии 66:
 * HTML-файл -> htmlconv (кнопки/формы/onclick) -> brjs_extract
 * (виджеты/скрипты/якоря). Проверяет интеграцию компонентов БЕЗ
 * движка: htmlconv строит reader-конструкции, brjs их разбирает.
 *
 * Сборка: gcc -DHOST_TEST -fsanitize=address,undefined -Isrc \
 *             -o test_pipeline test_pipeline.c && ./test_pipeline
 */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../src/htmlconv.c"
#undef HOST_TEST

typedef unsigned int u32;
typedef unsigned char u8;
typedef short i16;
#include "utf8.h"
#include "brlines.h"
#define BRJS_NO_ENGINE
#include "brjs.h"

static int fails = 0, total = 0;
#define CHECK(cond, msg) do { \
    total++; \
    if (cond) printf("PASS %s\n", msg); \
    else { printf("FAIL %s (строка %d)\n", msg, __LINE__); fails++; } \
} while (0)

static const char *DEMO =
    "<html><head><title>t</title></head><body>"
    "<h1>Демо</h1>"
    "<button class=\"button-primary\" "
    "onclick=\"document.location='/wikimirror/'\">Перейти</button>"
    "<form action=\"/echo\" method=\"get\">"
    "<input name=\"name\" value=\"мир\">"
    "<select name=\"lang\"><option value=\"ru\" selected>Русский</option>"
    "<option value=\"en\">English</option></select>"
    "<input type=\"hidden\" name=\"v\" value=\"66\">"
    "<input type=\"submit\" value=\"OK\">"
    "</form>"
    "</body></html>";

int main(void)
{
    printf("=== pipeline: htmlconv -> brjs_extract ===\n");

    /* 1. конвертация */
    char md[8192];
    int n = html_to_md(DEMO, (int)strlen(DEMO), md, (int)sizeof(md));
    CHECK(n > 0, "html_to_md вернул текст");

    /* 2. извлечение (как в browser_load_content) */
    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    n = brjs_extract(&js, md, n, NULL);

    /* 3. состав: кнопка + 3 виджета формы (text/select/button submit).
     * Авто-id: btn1 (кнопка), f2 (форма — autoid=2), in3 (submit). */
    CHECK(js.nw == 4, "виджетов 4 (кнопка onclick + text + select + submit)");
    CHECK(js.nraw == 1, "payload'ов 1 (скрипт onclick)");

    /* 4. кнопка с onclick */
    int fb = -1, ft = -1, fs = -1, fsub = -1;
    for (int i = 0; i < js.nw; i++) {
        if (!strcmp(js.w[i].id, "btn1")) fb = i;
        if (!strcmp(js.w[i].id, "name")) ft = i;
        if (!strcmp(js.w[i].id, "lang")) fs = i;
        if (!strcmp(js.w[i].id, "in3"))  fsub = i;
    }
    CHECK(fb >= 0, "кнопка onclick имеет id btn1");
    if (fb >= 0) {
        CHECK(js.w[fb].kind == BRJS_W_BUTTON, "btn1 — widget=button");
        CHECK(!strcmp(js.w[fb].label, "Перейти"), "btn1 label=Перейти");
    }
    CHECK(ft >= 0 && js.w[ft].kind == BRJS_W_TEXT &&
          !strcmp(js.w[ft].value, "мир") &&
          !strcmp(js.w[ft].form, "f2"),
          "поле name: text, default=мир, form=f2");
    CHECK(fs >= 0 && js.w[fs].kind == BRJS_W_SELECT &&
          js.w[fs].noptions == 2 &&
          !strcmp(js.w[fs].options[js.w[fs].sel], "ru"),
          "select lang: 2 опции, выбран ru (selected)");
    CHECK(fsub >= 0 && js.w[fsub].kind == BRJS_W_BUTTON &&
          !strcmp(js.w[fsub].action, "/echo?v=66") &&
          !strcmp(js.w[fsub].method, "get") &&
          !strcmp(js.w[fsub].form, "f2"),
          "submit: action=/echo?v=66 (hidden запечён), method=get");

    /* 5. скрипт onclick */
    CHECK(js.nraw == 1 && js.raw[0].json &&
          strstr(js.raw[0].json, "\"trigger\":\"click:btn1\"") &&
          strstr(js.raw[0].json, "document.location='/wikimirror/'"),
          "payload: триггер click:btn1, код document.location=...");

    /* 6. привязка якорей: 4 виджета + 1 raw-скрипт = 5 строк-якорей
     * (скриптовый якорь остаётся пустой строкой) */
    int anchors = 0;
    for (int i = 0; i < n; i++)
        if (md[i] == BRJS_MARK) anchors++;
    CHECK(anchors == 5, "в md 5 якорей (4 виджета + якорь скрипта)");
    CHECK(strstr(md, "```reader-input") == NULL,
          "fenced-блоки вырезаны из md");
    CHECK(strstr(md, "<!--@r:") == NULL,
          "payload-комментарии вырезаны из md");
    CHECK(strstr(md, "onclick") == NULL,
          "исходный onclick не попал в видимый текст");

    /* 7. симуляция привязки brjs_scan (без движка): очередь по порядку */
    /* k-й якорь -> order[k]; виджеты созданы extract'ом ДО якорей */
    CHECK(js.norder >= 4, "очередь привязки заполнена");

    /* 8. querystring формы после правки поля */
    brjs_copy(js.w[ft].value, BRJS_VALUE_MAX, "вася", -1);
    {
        char q[128];
        brjs_form_query(&js, "f2", q, (int)sizeof(q));
        CHECK(strcmp(q, "name=%D0%B2%D0%B0%D1%81%D1%8F&lang=ru") == 0,
              "query формы: name=вася&lang=ru (submit и hidden вне)");
    }

    brjs_page_reset(&js);   /* освободить raw-JSON (чистота ASAN) */

    printf("=== %d/%d passed, %d failed ===\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
