/* Общие заглушки для хост-тестбеда c4 (ramfs/serial/loader) */
#include "types.h"
#include "string.h"
struct window;
void serial_puts(const char *s) { (void)s; }
int ramfs_ready(void) { return 0; }
int ramfs_delete(const char *n) { (void)n; return 0; }
int ramfs_create(const char *n, u32 s) { (void)n; (void)s; return 0; }
int ramfs_write(const char *n, const void *b, u32 s) { (void)n; (void)b; (void)s; return 0; }
u32 ramfs_read(const char *n, void *b, u32 m) { (void)n; (void)b; (void)m; return 0; }
int loader_spawn(const char *name, struct window *win) { (void)name; (void)win; return -1; }
u32 timer_ticks(void) { static u32 t; return ++t; }
void task_yield(void) { }
void task_msleep(u32 ms) { (void)ms; }
int kbd_pop(void *ev) { (void)ev; return 0; }
void fb_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void fb_text(int x, int y, const char *s, u32 fg, int bg) { (void)x;(void)y;(void)s;(void)fg;(void)bg; }
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r<<16)|((u32)g<<8)|b; }
void fb_touch_all(void) { }
void fb_flush(void) { }
int fb_width(void) { return 800; }
int fb_height(void) { return 600; }
void fb_fill_screen(u32 c) { (void)c; }

/* Task 54: SDL2-диспетчер (sdl2.c не собирается на хосте — это ядро).
 * Хост-тесты SDL-опкоды не исполняют; заглушка держит линковку. */
int c4_sdl_call(int op, const int *args) { (void)op; (void)args; return 0; }
