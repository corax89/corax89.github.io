#!/usr/bin/env python3
"""Verify os.iso: read PVD, find /boot/kernel.bin record, extract extent,
compare md5 with kernel.bin on disk. Read-only check."""
import struct, sys, hashlib

ISO = sys.argv[1] if len(sys.argv) > 1 else "/home/z/my-project/work/src/os.iso"
REF = sys.argv[2] if len(sys.argv) > 2 else "/home/z/my-project/work/src/kernel.bin"

data = open(ISO, "rb").read(64 * 1024 * 1024)

def pvd_off():
    # PVD: сектор 16, тип 1, "CD001"
    for s in range(16, 32):
        off = s * 2048
        if data[off + 1:off + 6] == b"CD001" and data[off] == 1:
            return off
    return None

p = pvd_off()
if p is None:
    print("ERROR: PVD not found"); sys.exit(1)
volid = data[p + 40:p + 72].decode("ascii", "replace").strip()
print(f"PVD @sector {p//2048}, volume id: '{volid}'")

def parse_dir(off, size):
    """возвращает {name_lower: (lba, size)} для записей каталога"""
    end = off + size
    out = {}
    o = off
    while o < end:
        ln = data[o]
        if ln == 0:
            # остаток сектора пропускаем
            o = (o // 2048 + 1) * 2048
            continue
        lba = struct.unpack("<I", data[o + 2:o + 6])[0]
        sz = struct.unpack("<I", data[o + 10:o + 14])[0]
        flags = data[o + 25]
        nlen = data[o + 32]
        name = data[o + 33:o + 33 + nlen]
        if name not in (b"\x00", b"\x01"):
            nm = name.decode("ascii", "replace").lower().split(";")[0]
            out[nm] = (lba, sz, flags)
        o += ln
    return out

root_dir = struct.unpack("<I", data[p + 158:p + 162])[0]
root_size = struct.unpack("<I", data[p + 166:p + 170])[0]
root = parse_dir(root_dir * 2048, root_size)
print("root entries:", ", ".join(sorted(root)))

if "boot" not in root:
    print("ERROR: no /boot on ISO"); sys.exit(1)
blba, bsz, _ = root["boot"]
boot = parse_dir(blba * 2048, bsz)
print("boot entries:", ", ".join(sorted(boot)))

if "kernel.bin" not in boot:
    print("ERROR: no /boot/kernel.bin on ISO"); sys.exit(1)
klba, ksz, _ = boot["kernel.bin"]
print(f"/boot/kernel.bin: lba={klba} ({klba*2048:#x}), size={ksz}")

ext = data[klba * 2048: klba * 2048 + ksz]
ref = open(REF, "rb").read()
m1, m2 = hashlib.md5(ext).hexdigest(), hashlib.md5(ref).hexdigest()
print(f"iso extent md5 : {m1}")
print(f"kernel.bin md5 : {m2}")
print("MATCH" if (m1 == m2 and len(ext) == len(ref)) else "*** MISMATCH ***")
sys.exit(0 if m1 == m2 else 1)
