/* test_e2e_task60.c — E2E: html_to_md2 -> brf_parse (как в браузере при
 * загрузке страницы). Проверяем: скрипты собраны, в md не осталось
 * \x01-маркеров, rescue редиректора работает, brf_scrub чистит вставки.
 *
 * gcc -DHOST_TEST -fsanitize=address,undefined -g test_e2e_task60.c \
 *     ../src/html_parser.c -o test_e2e
 */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include "../src/htmlconv.c"
#include "../src/brform.h"
#undef HOST_TEST

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails = 0, total = 0;

static void ok(const char *name, int cond)
{
    total++;
    if (cond) printf("PASS %s\n", name);
    else { fails++; printf("FAIL %s\n", name); }
}

int main(void)
{
    /* --- E2E: сложная страница: 12 скриптов + редиректор 13-м --- */
    {
        char doc[16384];
        int o = 0;
        char md[16384];
        brf_forms_t forms;
        int ml;
        o += snprintf(doc + o, sizeof(doc) - o, "<h1>Page</h1>");
        for (int i = 0; i < 12; i++)
            o += snprintf(doc + o, sizeof(doc) - o,
                          "<p>sec %d</p><script>var a%d = %d;"
                          " analytics(%d);</script>", i, i, i, i);
        o += snprintf(doc + o, sizeof(doc) - o,
                      "<script>location.href = \"/next.html\";</script>"
                      "<p>tail</p>");
        ml = html_to_md2(doc, o, md, (int)sizeof(md), NULL);
        memset(&forms, 0, sizeof(forms));
        ml = brf_parse(&forms, md, ml);
        ok("E2E: all 13 scripts collected", forms.nscripts == 13);
        ok("E2E: no \\x01 markers left in md", strchr(md, '\x01') == NULL);
        ok("E2E: tail content preserved", strstr(md, "tail") != NULL);
        /* 13-й — редиректор: старый код с BRJ_MAX=10 терял его */
        ok("E2E: redirector rescued (last script)",
           forms.scripts[forms.nscripts - 1].code &&
           strstr(forms.scripts[forms.nscripts - 1].code,
                  "location.href") != NULL);
        brf_reset(&forms);
    }

    /* --- E2E: перегруз кода: 10 скриптов по ~7 КиБ + редиректор --- */
    {
        char *doc = (char *)malloc(131072);
        char *md = (char *)malloc(262144);
        brf_forms_t forms;
        int o = 0, ml;
        o += snprintf(doc + o, 1024, "<p>big</p>");
        for (int i = 0; i < 10; i++) {
            o += snprintf(doc + o, 128, "<script>/* pad%d */", i);
            for (int k = 0; k < 7000; k++)
                doc[o++] = (char)('a' + (k % 26));
            o += snprintf(doc + o, 32, ";\n</script>");
        }
        o += snprintf(doc + o, 256,
                      "<script>location.replace(\"/go\");</script><p>end</p>");
        ml = html_to_md2(doc, o, md, 262144, NULL);
        memset(&forms, 0, sizeof(forms));
        ml = brf_parse(&forms, md, ml);
        ok("E2E-big: budget overflow, redirector rescued",
           brf_is_redirect(forms.scripts[0].code, forms.scripts[0].code_len));
        ok("E2E-big: script count still bounded", forms.nscripts <= BRJ_MAX);
        ok("E2E-big: no markers leaked", strchr(md, '\x01') == NULL);
        ok("E2E-big: end content kept", strstr(md, "end") != NULL);
        brf_reset(&forms);
        free(doc);
        free(md);
    }

    /* --- E2E: document.write-канал: конвертация вставки с <script> ---
     * (имитация br_docwrite_emit: convert -> brf_parse(tmp) ->
     *  strip anchors -> scrub) */
    {
        const char *whtml =
            "<b>inserted</b><script>location.href=\"/r\";</script>"
            "<input type=\"text\" name=\"q\">";
        char wmd[4096];
        brf_forms_t tmp;
        int wl;
        wl = html_to_md2(whtml, (int)strlen(whtml), wmd,
                         (int)sizeof(wmd), NULL);
        memset(&tmp, 0, sizeof(tmp));
        wl = brf_parse(&tmp, wmd, wl);
        wl = brf_strip_script_anchors(wmd, wl);
        ok("DW: script extracted from insertion",
           tmp.nscripts == 1 && strstr(tmp.scripts[0].code, "location.href"));
        ok("DW: field extracted from insertion", tmp.nfields == 1);
        ok("DW: no \\x04 anchors in spliced md", strchr(wmd, '\x04') == NULL);
        ok("DW: no \\x01 markers in spliced md", strchr(wmd, '\x01') == NULL);
        ok("DW: visible content kept",
           strstr(wmd, "inserted") != NULL);
        {
            brf_forms_t main_f;
            memset(&main_f, 0, sizeof(main_f));
            brf_adopt(&main_f, &tmp);
            ok("DW: adopt field", main_f.nfields == 1 &&
               !strcmp(main_f.fields[0].name, "q"));
        }
        brf_reset(&tmp);
    }

    /* --- brf_scrub: вставка с обрывом посреди SCRIPT --- */
    {
        char dirtied[512];
        int dl;
        strcpy(dirtied, "text before\n\x01SCRIPT\nvar half =\nmore text\n");
        dl = (int)strlen(dirtied);
        dl = brf_scrub(dirtied, dl);
        ok("SCRUB: dangling SCRIPT block swallowed",
           strchr(dirtied, '\x01') == NULL &&
           strstr(dirtied, "text before") != NULL &&
           strstr(dirtied, "var half") == NULL);
        /* --- scrub не трогает якоря --- */
        strcpy(dirtied, "a\n\x03\nb\n\x04\nc\n\x01INPUT type=\"text\"\nd\n");
        dl = (int)strlen(dirtied);
        dl = brf_scrub(dirtied, dl);
        ok("SCRUB: anchors \\x03/\\x04 kept",
           strchr(dirtied, '\x03') && strchr(dirtied, '\x04') &&
           strchr(dirtied, '\x01') == NULL);
    }

    printf("=== E2E %d/%d passed, %d failed ===\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
