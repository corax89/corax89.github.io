/* shim: timer.h — растущие тики (1 мс за вызов poll в тесте) */
#ifndef SHIM_TIMER_H
#define SHIM_TIMER_H
#include "types.h"
u32 timer_ticks(void);
#endif /* SHIM_TIMER_H */
