/* shim: string.h — прототипы libc для host-тестов (freestanding-версия
 * ядра заменяется стандартной) */
#ifndef SHIM_STRING_H
#define SHIM_STRING_H
#include <stddef.h>
#include <stdarg.h>

void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int   memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
char *strcpy(char *d, const char *s);
char *strncpy(char *d, const char *s, size_t n);
char *strcat(char *d, const char *s);
int   strcmp(const char *a, const char *b);
int   strncmp(const char *a, const char *b, size_t n);
char *strstr(const char *h, const char *n);
char *strchr(const char *s, int c);
int   snprintf(char *out, size_t n, const char *fmt, ...);
#endif /* SHIM_STRING_H */
