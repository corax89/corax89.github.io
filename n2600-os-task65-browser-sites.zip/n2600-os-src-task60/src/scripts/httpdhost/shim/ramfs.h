/* shim: ramfs.h для host-тестов httpd — in-memory файловая система
 * (реализация в test_httpd.c). API совпадает с src/ramfs.h. */
#ifndef SHIM_RAMFS_H
#define SHIM_RAMFS_H
#include "types.h"

#define RAMFS_NAME_MAX 64

typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    u32  size;
    int  is_dir;
} ramfs_dirent_t;

int  ramfs_ready(void);
int  ramfs_mkdir(const char *path);
int  ramfs_create(const char *name, u32 size);
int  ramfs_write(const char *name, const void *buf, u32 size);
u32  ramfs_read(const char *name, void *buf, u32 max);
int  ramfs_delete(const char *name);
int  ramfs_stat_ci(const char *name, ramfs_dirent_t *out);
u32  ramfs_free_space(void);
u32  ramfs_total_space(void);
int  ramfs_file_count(void);
int  ramfs_list(ramfs_dirent_t *out, int max);
#endif /* SHIM_RAMFS_H */
