/* shim: mem.h — обычная куча хоста */
#ifndef SHIM_MEM_H
#define SHIM_MEM_H
#include <stdlib.h>
void *kmalloc(u32 size);
void  kfree(void *p);
#endif /* SHIM_MEM_H */
