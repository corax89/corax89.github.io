#!/bin/sh
# run.sh — хост-тест файлового сервера httpd (Task 62) на РЕАЛЬНОМ
# src/net_httpd.c (ASan/UBSan): загрузка файлов POST /upload,
# Chrome-заголовки >1КБ, большие тела, GET файлов, ошибки.
# Запуск: sh scripts/httpdhost/run.sh
set -e
cd "$(dirname "$0")"
# net_httpd.c копируется рядом (как в brhost): чтобы его #include "mem.h"
# и "net.h" взяли shim-версии, а не заголовки ядра из src/
cp ../../src/net_httpd.c ../../src/net_httpd.h ../../src/types.h .
gcc -DHOST_TEST -g -O1 -fsanitize=address,undefined -Ishim -I. \
    -o test_httpd test_httpd.c net_httpd.c
./test_httpd
