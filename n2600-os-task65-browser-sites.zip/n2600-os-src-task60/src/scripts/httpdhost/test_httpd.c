/* test_httpd.c — хост-тест файлового сервера httpd (Task 62) на РЕАЛЬНОМ
 * src/net_httpd.c (ASan/UBSan).
 *
 * Воспроизведение и регрессия проблем «загрузки файлов через httpd»:
 *   R1  GET /                              — 200, index.html
 *   R2  POST /upload малый (curl-стиль)    — 200, файл в www
 *   R3  POST /upload Chrome-заголовки >1КБ + тело в тех же сегментах —
 *       200, содержимое совпало (раньше тело ТЕРЯЛОСЬ: req-буфер 1024
 *       переполнялся, избыток данных первого сегмента пропадал —
 *       need_respond не наступал, 30 с тишины, разрыв без ответа)
 *   R4  POST /upload тело 20 КБ            — 200, байт-в-байт
 *   R5  POST boundary в кавычках           — 200
 *   R6  GET /<file.bin> (20 КБ)            — 200, CL и содержимое
 *   R7  POST два файла в одной форме       — оба в www
 *   R8  POST без Content-Length            — 400
 *   R9  POST Content-Length 70000          — 400, сервер жив
 *   R10 filename с пробелами/кириллицей    — файл создан (sanitized)
 *
 * TCP — fake: recv_cb доставляется синхронно (как loopback-пара),
 * исходящее собирается в per-socket буфер, ACK мгновенный.
 * Сборка: sh scripts/httpdhost/run.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "net.h"        /* shim */
#include "ramfs.h"      /* shim */
#include "mem.h"
#include "timer.h"
#include "net_httpd.h"  /* реальный */

/* ========================= шим: память ========================= */
void *kmalloc(u32 size) { return malloc(size); }
void  kfree(void *p) { free(p); }

/* ========================= шим: таймер ========================= */
static u32 g_ticks = 1000;
u32 timer_ticks(void) { return g_ticks; }

/* ========================= шим: сеть ========================= */
#define TMAX_SOCKS 8
typedef struct {
    int   used;
    tcp_state_t st;
    u32   gen;
    int   pinned;
    char *out;  u32 out_len, out_cap;
} tsock_t;
static tsock_t g_s[TMAX_SOCKS];
static tcp_accept_cb_t  g_accept_cb = NULL;
static net_tcp_recv_cb_t g_recv_cb = NULL;
static int g_listen_port = -1;

int net_tcp_listen(u16 port, tcp_accept_cb_t cb, net_tcp_recv_cb_t recv_cb)
{
    g_listen_port = (int)port;
    g_accept_cb = cb;
    g_recv_cb = recv_cb;
    return 0;
}
void net_tcp_unlisten(u16 port) { (void)port; g_listen_port = -1; g_accept_cb = NULL; }

void net_tcp_pin(int sock) { if (sock >= 0 && sock < TMAX_SOCKS) g_s[sock].pinned = 1; }
void net_tcp_unpin(int sock) { if (sock >= 0 && sock < TMAX_SOCKS) g_s[sock].pinned = 0; }
void net_tcp_unpin_gen(int sock, u32 gen)
{
    if (sock >= 0 && sock < TMAX_SOCKS && g_s[sock].gen == gen) g_s[sock].pinned = 0;
}
u32 net_tcp_gen(int sock) { return (sock >= 0 && sock < TMAX_SOCKS) ? g_s[sock].gen : 0; }
tcp_state_t net_tcp_state(int sock)
{
    return (sock >= 0 && sock < TMAX_SOCKS) ? g_s[sock].st : TCP_CLOSED;
}
int net_tcp_send_pending(int sock) { (void)sock; return 0; }   /* ACK мгновенный */
void net_tcp_close(int sock)
{
    if (sock < 0 || sock >= TMAX_SOCKS) return;
    g_s[sock].st = TCP_CLOSED;
    g_s[sock].pinned = 0;
}

int net_tcp_send(int sock, const void *data, u32 len)
{
    if (sock < 0 || sock >= TMAX_SOCKS || !g_s[sock].used) return -1;
    if (g_s[sock].out_len + len > g_s[sock].out_cap) {
        u32 nc = g_s[sock].out_cap ? g_s[sock].out_cap : 4096;
        while (g_s[sock].out_len + len > nc) nc *= 2;
        g_s[sock].out = (char *)realloc(g_s[sock].out, nc);
        g_s[sock].out_cap = nc;
    }
    memcpy(g_s[sock].out + g_s[sock].out_len, data, len);
    g_s[sock].out_len += len;
    return (int)len;
}

u32 net_get_ip(void) { return 0xC0A80121u; }   /* 192.168.1.33 */
u32 net_get_gateway(void) { return 0xC0A80101u; }
u32 net_get_netmask(void) { return 0xFFFFFF00u; }
u32 net_dns_server(void) { return 0; }
int net_nic_present(void) { return 1; }
const char *net_nic_name(void) { return "e1000"; }
void net_ntoa(u32 ip, char *out, u32 max)
{ snprintf(out, max, "%u.%u.%u.%u", (ip>>24)&255, (ip>>16)&255, (ip>>8)&255, ip&255); }
u32 net_tx_packets(void) { return 0; }
u32 net_rx_packets(void) { return 0; }
dhcp_state_t net_dhcp_state(void) { return DHCP_BOUND; }
int net_arp_dump(net_arp_entry_t *out, int max_entries) { (void)out; (void)max_entries; return 0; }

void serial_puts(const char *s) { (void)s; }

/* ========================= шим: ramfs (in-memory) ========================= */
#define TRFS_MAX 64
typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    char *data;
    u32   size;
    int   is_dir;
    int   used;
} trfs_t;
static trfs_t g_f[TRFS_MAX];

static int trfs_ci_eq(const char *a, const char *b)
{
    while (*a || *b) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 0;
        a++; b++;
    }
    return 1;
}
static trfs_t *trfs_find(const char *name)
{
    for (int i = 0; i < TRFS_MAX; i++)
        if (g_f[i].used && trfs_ci_eq(g_f[i].name, name)) return &g_f[i];
    return NULL;
}
int ramfs_ready(void) { return 1; }
int ramfs_mkdir(const char *path)
{
    if (trfs_find(path)) return 0;
    for (int i = 0; i < TRFS_MAX; i++)
        if (!g_f[i].used) {
            memset(&g_f[i], 0, sizeof(g_f[i]));
            snprintf(g_f[i].name, sizeof(g_f[i].name), "%s", path);
            g_f[i].is_dir = 1; g_f[i].used = 1;
            return 1;
        }
    return 0;
}
int ramfs_create(const char *name, u32 size)
{
    if (trfs_find(name)) return 0;
    if ((u32)strlen(name) > RAMFS_NAME_MAX) return 0;
    for (int i = 0; i < TRFS_MAX; i++)
        if (!g_f[i].used) {
            memset(&g_f[i], 0, sizeof(g_f[i]));
            snprintf(g_f[i].name, sizeof(g_f[i].name), "%s", name);
            g_f[i].data = size ? (char *)calloc(1, size) : NULL;
            g_f[i].size = size; g_f[i].used = 1;
            return 1;
        }
    return 0;
}
int ramfs_write(const char *name, const void *buf, u32 size)
{
    trfs_t *f = trfs_find(name);
    if (!f || f->is_dir) return 0;
    if (size > f->size) return 0;
    if (size) memcpy(f->data, buf, size);
    f->size = size;
    return 1;
}
u32 ramfs_read(const char *name, void *buf, u32 max)
{
    trfs_t *f = trfs_find(name);
    if (!f || f->is_dir) return 0;
    u32 n = f->size < max ? f->size : max;
    if (n) memcpy(buf, f->data, n);
    return n;
}
int ramfs_delete(const char *name)
{
    trfs_t *f = trfs_find(name);
    if (!f) return 0;
    free(f->data);
    f->used = 0;
    return 1;
}
int ramfs_stat_ci(const char *name, ramfs_dirent_t *out)
{
    trfs_t *f = trfs_find(name);
    if (!f) return 0;
    snprintf(out->name, sizeof(out->name), "%s", f->name);
    out->size = f->size;
    out->is_dir = f->is_dir;
    return 1;
}
u32 ramfs_free_space(void) { return 4u * 1024 * 1024; }
u32 ramfs_total_space(void) { return 4u * 1024 * 1024; }
int ramfs_file_count(void)
{
    int n = 0;
    for (int i = 0; i < TRFS_MAX; i++) if (g_f[i].used && !g_f[i].is_dir) n++;
    return n;
}
int ramfs_list(ramfs_dirent_t *out, int max)
{
    int n = 0;
    for (int i = 0; i < TRFS_MAX && n < max; i++)
        if (g_f[i].used && !g_f[i].is_dir) {
            snprintf(out[n].name, sizeof(out[n].name), "%s", g_f[i].name);
            out[n].size = g_f[i].size;
            n++;
        }
    return n;
}

/* ========================= тестовый «клиент» ========================= */
static int g_next_sock = 0;
static int test_connect(void)
{
    if (!g_accept_cb) { fprintf(stderr, "нет listen!\n"); exit(2); }
    int sock = -1;
    for (int i = 0; i < TMAX_SOCKS; i++)
        if (!g_s[i].used) { sock = i; break; }
    if (sock < 0) { fprintf(stderr, "нет слотов\n"); exit(2); }
    memset(&g_s[sock], 0, sizeof(g_s[sock]));
    g_s[sock].used = 1;
    g_s[sock].st = TCP_ESTABLISHED;
    g_s[sock].gen = 1 + (u32)sock * 7;
    g_next_sock = sock;
    g_accept_cb(sock, 0xC0A80145u, 51512);   /* httpd занял слот */
    return sock;
}
static void test_send(int sock, const void *data, u32 len)
{
    if (!g_recv_cb) { fprintf(stderr, "нет recv_cb\n"); exit(2); }
    g_recv_cb(sock, 0xC0A80145u, 51512, data, len);
}
/* прокачать httpd: до N итераций poll (тик +2 мс за итерацию) */
static void test_pump(int iters)
{
    for (int i = 0; i < iters; i++) {
        g_ticks += 2;
        net_httpd_poll();
    }
}
static void test_reset_sock(int sock)
{
    if (sock >= 0 && sock < TMAX_SOCKS) {
        free(g_s[sock].out);
        memset(&g_s[sock], 0, sizeof(g_s[sock]));
    }
}

/* ========================= проверки ========================= */
static int g_pass = 0, g_fail = 0;
#define CHECK(name, cond) do { \
    if (cond) { g_pass++; printf("  [PASS] %s\n", name); } \
    else      { g_fail++; printf("  [FAIL] %s  (%s:%d)\n", name, __FILE__, __LINE__); } \
} while (0)

typedef struct {
    int   sock;
    char *resp;    /* весь ответ (заголовки+тело) */
    u32   resp_len;
} http_resp_t;

static const char *resp_status(const http_resp_t *r)
{
    if (!r->resp || r->resp_len < 12) return "";
    static char st[40];
    u32 n = 0;
    for (u32 i = 9; i < r->resp_len && r->resp[i] != '\r' && n < 39; i++)
        st[n++] = r->resp[i];
    st[n] = 0;
    return st;
}
static const char *resp_body(const http_resp_t *r, u32 *blen)
{
    if (!r->resp) { *blen = 0; return ""; }
    for (u32 i = 0; i + 3 < r->resp_len; i++)
        if (r->resp[i] == '\r' && r->resp[i+1] == '\n' &&
            r->resp[i+2] == '\r' && r->resp[i+3] == '\n') {
            *blen = r->resp_len - (i + 4);
            return r->resp + i + 4;
        }
    *blen = 0;
    return "";
}

/* одна HTTP-сессия: connect, отправка запроса кусками по seg,
 * pump до ответа (или исчерпания). req_len — байтовая длина. */
static void http_txn_len(const char *req, u32 req_len, u32 seg, http_resp_t *out)
{
    memset(out, 0, sizeof(*out));
    int sock = test_connect();
    /* тело может быть больше сегмента — шлём кусками, как реальный TCP */
    u32 off = 0;
    int guard = 0;
    while (off < req_len && guard++ < 200) {
        u32 n = req_len - off;
        if (n > seg) n = seg;
        test_send(sock, req + off, n);
        off += n;
        test_pump(4);
    }
    test_pump(400);   /* дослать остатки/respond */
    if (g_s[sock].out) {
        out->sock = sock;
        out->resp = g_s[sock].out;
        out->resp_len = g_s[sock].out_len;
    } else {
        out->sock = sock;   /* ответа нет (таймаут/разрыв) */
    }
}
static void http_txn(const char *req, u32 seg, http_resp_t *out)
{
    http_txn_len(req, (u32)strlen(req), seg, out);
}

/* построить multipart-тело: 1-2 файла, данные произвольные (с нулями) */
static u32 build_multipart(char *buf, u32 cap, const char *bnd,
                           const char *fname1, const char *data1, u32 dlen1,
                           const char *fname2, const char *data2, u32 dlen2)
{
    u32 o = 0;
    o += (u32)snprintf(buf + o, cap - o, "--%s\r\n", bnd);
    o += (u32)snprintf(buf + o, cap - o,
                       "Content-Disposition: form-data; name=\"file\"; "
                       "filename=\"%s\"\r\n"
                       "Content-Type: application/octet-stream\r\n\r\n",
                       fname1);
    memcpy(buf + o, data1, dlen1); o += dlen1;
    o += (u32)snprintf(buf + o, cap - o, "\r\n");
    if (fname2) {
        o += (u32)snprintf(buf + o, cap - o, "--%s\r\n", bnd);
        o += (u32)snprintf(buf + o, cap - o,
                           "Content-Disposition: form-data; name=\"file2\"; "
                           "filename=\"%s\"\r\n\r\n", fname2);
        memcpy(buf + o, data2, dlen2); o += dlen2;
        o += (u32)snprintf(buf + o, cap - o, "\r\n");
    }
    o += (u32)snprintf(buf + o, cap - o, "--%s--\r\n", bnd);
    return o;
}

/* ===== реалистичные заголовки Chrome (суммарно >1КБ) ===== */
static const char CHROME_TPL[] =
    "POST /upload HTTP/1.1\r\n"
    "Host: 192.168.1.33\r\n"
    "Connection: keep-alive\r\n"
    "Content-Length: %u\r\n"
    "Cache-Control: max-age=0\r\n"
    "sec-ch-ua: \"Chromium\";v=\"124\", \"Google Chrome\";v=\"124\", "
    "\"Not-A.Brand\";v=\"99\"\r\n"
    "sec-ch-ua-mobile: ?0\r\n"
    "sec-ch-ua-platform: \"Windows\"\r\n"
    "Upgrade-Insecure-Requests: 1\r\n"
    "Origin: http://192.168.1.33\r\n"
    "Content-Type: multipart/form-data; boundary=%s\r\n"
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36\r\n"
    "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,"
    "image/avif,image/webp,image/apng,*/*;q=0.8,"
    "application/signed-exchange;v=b3;q=0.7\r\n"
    "Referer: http://192.168.1.33/\r\n"
    "Accept-Encoding: gzip, deflate\r\n"
    "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7\r\n"
    "Cookie: sessionid=380a2fbc9f2f6a7d5584e2b1a3c5d6e7; "
    "csrftoken=Zx9Yw8Vv7Uu6Tt5Ss4Rr3Qq2Pp1Oo0Nn; theme=dark; "
    "sidebar=collapsed; lang=ru-RU; tz=Europe/Minsk; "
    "last_search=n2600%20os%20browser%20task62%20httpd%20upload\r\n"
    "\r\n";

int main(void)
{
    printf("== host-тест httpd: загрузка файлов (Task 62) ==\n");
    net_httpd_start();
    CHECK("сервер стартовал (www/index.html создан)",
          ramfs_stat_ci("www/index.html", &(ramfs_dirent_t){0}));

    /* ---------- R1: GET / ---------- */
    {
        http_resp_t r;
        http_txn("GET / HTTP/1.1\r\nHost: x\r\n\r\n", 1460, &r);
        CHECK("R1 GET /: 200", strcmp(resp_status(&r), "200 OK") == 0);
        u32 bl; const char *b = resp_body(&r, &bl);
        CHECK("R1 GET /: index.html в теле",
              bl > 0 && strstr(b, "file server") != NULL);
        test_reset_sock(r.sock);
    }

    /* ---------- R2: POST малый, curl-стиль ---------- */
    {
        char body[4096], req[8192];
        char data1[300];
        for (int i = 0; i < 300; i++) data1[i] = (char)('a' + (i % 26));
        u32 blen = build_multipart(body, sizeof(body),
                                   "curlBnd123",
                                   "small.txt", data1, 300, NULL, NULL, 0);
        int hl = snprintf(req, sizeof(req),
                          "POST /upload HTTP/1.1\r\n"
                          "Host: x\r\n"
                          "Content-Type: multipart/form-data; boundary=curlBnd123\r\n"
                          "Content-Length: %u\r\n\r\n", blen);
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, (u32)hl + blen, 1460, &r);
        CHECK("R2 POST малый: 200", strcmp(resp_status(&r), "200 OK") == 0);
        ramfs_dirent_t de;
        CHECK("R2 POST малый: файл в www", ramfs_stat_ci("www/small.txt", &de));
        char got[400];
        u32 gn = ramfs_read("www/small.txt", got, sizeof(got));
        CHECK("R2 POST малый: содержимое совпало",
              gn == 300 && memcmp(got, data1, 300) == 0);
        test_reset_sock(r.sock);
    }

    /* ---------- R3: Chrome-заголовки >1КБ, тело в тех же сегментах ---------- */
    {
        char body[8192], req[16384];
        char data1[2000];
        for (int i = 0; i < 2000; i++) data1[i] = (char)((i * 7) & 0xFF);
        u32 blen = build_multipart(body, sizeof(body),
                                   "----WebKitFormBoundaryAaBbCcDdEeFfGgHh",
                                   "chrome.txt", data1, 2000, NULL, NULL, 0);
        int hl = snprintf(req, sizeof(req), CHROME_TPL, blen,
                          "----WebKitFormBoundaryAaBbCcDdEeFfGgHh");
        u32 hlen = (u32)hl;
        CHECK("R3 prep: заголовки >1КБ (реалистично)", hlen > 1024);
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, hlen + blen, 1460, &r);   /* сегменты как реальный TCP */
        CHECK("R3 Chrome-заголовки: 200 (раньше — тишина/разрыв)",
              strcmp(resp_status(&r), "200 OK") == 0);
        ramfs_dirent_t de;
        CHECK("R3 Chrome-заголовки: файл в www",
              ramfs_stat_ci("www/chrome.txt", &de) && de.size == 2000);
        char *got = (char *)malloc(2100);
        u32 gn = ramfs_read("www/chrome.txt", got, 2100);
        CHECK("R3 Chrome-заголовки: содержимое байт-в-байт",
              gn == 2000 && memcmp(got, data1, 2000) == 0);
        free(got);
        test_reset_sock(r.sock);
    }

    /* ---------- R4: тело 20 КБ ---------- */
    {
        char *body = (char *)malloc(256 * 1024);
        char *req  = (char *)malloc(256 * 1024);
        char *data1 = (char *)malloc(20480);
        for (int i = 0; i < 20480; i++)
            data1[i] = (char)((i * 31 + 7) & 0xFF);
        u32 blen = build_multipart(body, 256 * 1024, "bigBnd",
                                   "big.bin", data1, 20480, NULL, NULL, 0);
        int hl = snprintf(req, 256 * 1024,
                          "POST /upload HTTP/1.0\r\n"
                          "Content-Type: multipart/form-data; boundary=bigBnd\r\n"
                          "Content-Length: %u\r\n\r\n", blen);
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, (u32)hl + blen, 1460, &r);
        CHECK("R4 20КБ: 200", strcmp(resp_status(&r), "200 OK") == 0);
        ramfs_dirent_t de;
        CHECK("R4 20КБ: размер верный",
              ramfs_stat_ci("www/big.bin", &de) && de.size == 20480);
        char *got = (char *)malloc(21000);
        u32 gn = ramfs_read("www/big.bin", got, 21000);
        CHECK("R4 20КБ: содержимое байт-в-байт",
              gn == 20480 && memcmp(got, data1, 20480) == 0);
        free(got); free(body); free(req); free(data1);
        test_reset_sock(r.sock);
    }

    /* ---------- R5: boundary в кавычках ---------- */
    {
        char body[4096], req[8192];
        char data1[100];
        memset(data1, 'Q', 100);
        u32 blen = build_multipart(body, sizeof(body), "quotedBnd",
                                   "q.dat", data1, 100, NULL, NULL, 0);
        int hl = snprintf(req, sizeof(req),
                          "POST /upload HTTP/1.0\r\n"
                          "Content-Type: multipart/form-data; "
                          "boundary=\"quotedBnd\"\r\n"
                          "Content-Length: %u\r\n\r\n", blen);
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, (u32)hl + blen, 1460, &r);
        CHECK("R5 boundary в кавычках: 200",
              strcmp(resp_status(&r), "200 OK") == 0);
        CHECK("R5 boundary в кавычках: файл в www",
              ramfs_stat_ci("www/q.dat", &(ramfs_dirent_t){0}));
        test_reset_sock(r.sock);
    }

    /* ---------- R6: GET загруженного 20КБ-файла ---------- */
    {
        http_resp_t r;
        http_txn("GET /big.bin HTTP/1.1\r\nHost: x\r\n\r\n", 1460, &r);
        CHECK("R6 GET /big.bin: 200", strcmp(resp_status(&r), "200 OK") == 0);
        char cl[64] = "";
        if (r.resp) {
            const char *p = strstr(r.resp, "Content-Length: ");
            if (p) snprintf(cl, sizeof(cl), "%s", p + 16);
        }
        CHECK("R6 GET /big.bin: Content-Length = 20480",
              strncmp(cl, "20480", 5) == 0);
        u32 bl; const char *b = resp_body(&r, &bl);
        int ok = bl == 20480;
        if (ok)
            for (u32 i = 0; i < bl; i++)
                if ((unsigned char)b[i] !=
                    (unsigned char)((i * 31 + 7) & 0xFF)) { ok = 0; break; }
        CHECK("R6 GET /big.bin: содержимое байт-в-байт", ok);
        test_reset_sock(r.sock);
    }

    /* ---------- R7: два файла в одной форме ---------- */
    {
        char body[8192], req[16384];
        char d1[500], d2[300];
        for (int i = 0; i < 500; i++) d1[i] = (char)('A' + (i % 26));
        for (int i = 0; i < 300; i++) d2[i] = (char)(i & 0x7F);
        u32 blen = build_multipart(body, sizeof(body), "twoBnd",
                                   "one.txt", d1, 500, "two.txt", d2, 300);
        int hl = snprintf(req, sizeof(req),
                          "POST /upload HTTP/1.0\r\n"
                          "Content-Type: multipart/form-data; boundary=twoBnd\r\n"
                          "Content-Length: %u\r\n\r\n", blen);
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, (u32)hl + blen, 700, &r);
        CHECK("R7 два файла: 200", strcmp(resp_status(&r), "200 OK") == 0);
        CHECK("R7 два файла: один в www",
              ramfs_stat_ci("www/one.txt", &(ramfs_dirent_t){0}));
        CHECK("R7 два файла: второй в www",
              ramfs_stat_ci("www/two.txt", &(ramfs_dirent_t){0}));
        char got[600];
        CHECK("R7 два файла: содержимое первого",
              ramfs_read("www/one.txt", got, sizeof(got)) == 500 &&
              memcmp(got, d1, 500) == 0);
        test_reset_sock(r.sock);
    }

    /* ---------- R8: POST без Content-Length ---------- */
    {
        char body[1024], req[2048];
        u32 blen = build_multipart(body, sizeof(body), "noclBnd",
                                   "n.txt", "x", 1, NULL, NULL, 0);
        int hl = snprintf(req, sizeof(req),
                          "POST /upload HTTP/1.0\r\n"
                          "Content-Type: multipart/form-data; boundary=noclBnd\r\n"
                          "\r\n");
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, (u32)hl + blen, 1460, &r);
        CHECK("R8 без Content-Length: 400",
              strcmp(resp_status(&r), "400 Bad Request") == 0);
        test_reset_sock(r.sock);
    }

    /* ---------- R9: Content-Length 70000 (лимит 64К) ---------- */
    {
        char *body = (char *)malloc(72000);
        memset(body, 'Z', 72000);
        char req[512];
        int hl = snprintf(req, sizeof(req),
                          "POST /upload HTTP/1.0\r\n"
                          "Content-Type: multipart/form-data; boundary=limBnd\r\n"
                          "Content-Length: 70000\r\n\r\n");
        http_resp_t r;
        /* шлём заголовок + первую тысячу тела (остаток реальный клиент
         * шлёт, но сервер уже отвечает 400) */
        int sock = test_connect();
        test_send(sock, req, (u32)hl);
        test_send(sock, body, 1000);
        test_pump(200);
        if (g_s[sock].out) {
            r.sock = sock; r.resp = g_s[sock].out; r.resp_len = g_s[sock].out_len;
        } else { r.sock = sock; r.resp = NULL; r.resp_len = 0; }
        CHECK("R9 CL=70000: 400",
              strcmp(resp_status(&r), "400 Bad Request") == 0);
        test_reset_sock(r.sock);
        free(body);
    }

    /* ---------- R10: имя файла с пробелами и кириллицей ---------- */
    {
        char body[4096], req[8192];
        u32 blen = build_multipart(body, sizeof(body), "ruBnd",
                                   "отчёт за 2026.txt", "OK!", 3, NULL, NULL, 0);
        int hl = snprintf(req, sizeof(req),
                          "POST /upload HTTP/1.0\r\n"
                          "Content-Type: multipart/form-data; boundary=ruBnd\r\n"
                          "Content-Length: %u\r\n\r\n", blen);
        memcpy(req + hl, body, blen);
        http_resp_t r;
        http_txn_len(req, (u32)hl + blen, 1460, &r);
        CHECK("R10 имя с пробелами/кириллицей: 200",
              strcmp(resp_status(&r), "200 OK") == 0);
        /* sanitize: пробел -> '_', кириллица остаётся (UTF-8 печатные) */
        ramfs_dirent_t de;
        int found = 0;
        ramfs_dirent_t list[TRFS_MAX > 32 ? 32 : TRFS_MAX];
        int n = ramfs_list(list, 32);
        for (int i = 0; i < n; i++)
            if (strstr(list[i].name, "2026.txt") &&
                strstr(list[i].name, "отчёт"))
                found = 1;
        CHECK("R10 имя sanitized и файл записан", found ||
              (ramfs_stat_ci("www/отчёт_за_2026.txt", &de)));
        test_reset_sock(r.sock);
    }

    /* ---------- финал: сервер жив после всех ошибок ---------- */
    {
        http_resp_t r;
        http_txn("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n", 1460, &r);
        CHECK("сервер жив после ошибок: /hello 200",
              strcmp(resp_status(&r), "200 OK") == 0);
        test_reset_sock(r.sock);
    }

    printf("\nИтого: %d PASS, %d FAIL\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
