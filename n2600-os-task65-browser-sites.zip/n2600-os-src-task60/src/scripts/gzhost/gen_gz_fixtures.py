#!/usr/bin/env python3
"""gen_gz_fixtures.py — фикстуры для хост-теста gunzip (Task 63).

Генерирует в scripts/gzhost/fixtures/:
  1) PNG-набор (все color types / depths / фильтры / Adam7 / stored-блоки /
     битые потоки) + manifest.json с ожидаемым содержимым (crc32 RGBA-полотна);
  2) zlib-потоки (levels 0/1/6/9) и gzip-потоки (FNAME / FEXTRA+FHCRC+FNAME)
     + raw DEFLATE;
  3) expected.h — константы (crc32/размеры) для C-теста.
"""
import gzip, io, json, os, struct, zlib

BASE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(BASE, "fixtures")
os.makedirs(FIX, exist_ok=True)

manifest = []          # png: {name, w, h, rgba_crc32, expect_fail}
consts = {}            # для expected.h

# ---------------- PNG writer ----------------

def paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc: return a
    if pb <= pc: return b
    return c

def filter_row(ftype, row, prev, bpp):
    out = bytearray([ftype])
    n = len(row)
    for i in range(n):
        x = row[i]
        a = row[i - bpp] if i >= bpp else 0
        b = prev[i] if prev else 0
        c = prev[i - bpp] if (prev and i >= bpp) else 0
        if ftype == 0: f = x
        elif ftype == 1: f = (x - a) & 0xFF
        elif ftype == 2: f = (x - b) & 0xFF
        elif ftype == 3: f = (x - ((a + b) >> 1)) & 0xFF
        else: f = (x - paeth(a, b, c)) & 0xFF
        out.append(f)
    return bytes(out)

def chunk(typ, data):
    c = struct.pack(">I", len(data)) + typ + data
    return c + struct.pack(">I", zlib.crc32(typ + data) & 0xFFFFFFFF)

PALETTE_16 = [(i * 16, 255 - i * 16, (i * 7) % 256) for i in range(16)]
TRNS_16 = bytes([0, 128, 255, 64])    # первые 4 индекса с альфой

def expand_rgba(px, ctype, depth):
    if not isinstance(px, (tuple, list)): px = (px,)
    maxv = (1 << depth) - 1 if depth < 16 else 0xFFFF
    scale = {1: 0xFF, 2: 0x55, 4: 0x11}.get(depth, 0)
    def sc(v):
        if depth == 16: return (v >> 8) & 0xFF   # stb берёт старший байт
        if depth == 8: return v & 0xFF
        return ((v & maxv) * scale) & 0xFF
    if ctype == 0:
        g = sc(px[0]); return bytes((g, g, g, 255))
    if ctype == 2:
        return bytes((sc(px[0]), sc(px[1]), sc(px[2]), 255))
    if ctype == 3:
        idx = px[0]
        r, g, b = PALETTE_16[idx]
        a = TRNS_16[idx] if idx < len(TRNS_16) else 255
        return bytes((r, g, b, a))
    if ctype == 4:
        g, a = sc(px[0]), sc(px[1]); return bytes((g, g, g, a))
    if ctype == 6:
        return bytes((sc(px[0]), sc(px[1]), sc(px[2]), sc(px[3])))
    raise ValueError(ctype)

def pack_row(px_list, depth):
    px_list = [px if isinstance(px, (tuple, list)) else (px,) for px in px_list]
    if depth == 16:
        out = bytearray()
        for px in px_list:
            for ch in px: out += struct.pack(">H", ch & 0xFFFF)
        return bytes(out)
    if depth == 8:
        out = bytearray()
        for px in px_list:
            for ch in px: out.append(ch & 0xFF)
        return bytes(out)
    bits_per_px = depth
    per_byte = 8 // bits_per_px
    out = bytearray()
    for i in range(0, len(px_list), per_byte):
        b = 0
        grp = px_list[i:i + per_byte]
        for j, px in enumerate(grp):
            b = (b << bits_per_px) | (px[0] & maxv0(depth))
        pad = per_byte - len(grp)
        b <<= bits_per_px * pad
        out.append(b)
    return bytes(out)

def maxv0(depth): return (1 << depth) - 1

def build_raw(w, h, depth, ctype, pixel_fn, filters, interlace):
    nchan = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    bpp = max(1, (nchan * depth) // 8)
    exp = bytearray()

    def emit_pass_rows(rows_ft):
        pass

    if not interlace:
        prev = None
        rows = []
        for y in range(h):
            px = [pixel_fn(x, y) for x in range(w)]
            data = pack_row(px, depth)
            ftype = filters[y % len(filters)]
            fdata = filter_row(ftype, data, prev, bpp)
            rows.append((ftype, fdata))
            prev = data
        for y in range(h):
            for x in range(w):
                exp += expand_rgba(pixel_fn(x, y), ctype, depth)
        return rows, bpp, bytes(exp)

    # Adam7
    passes = [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    rows = []
    for (xo, yo, xs, ys) in passes:
        pw = len(range(xo, w, xs))
        ph = len(range(yo, h, ys))
        if pw == 0 or ph == 0: continue
        prev = None    # строки разных пассов разной длины — prev только внутри пасса
        for py in range(ph):
            y = yo + py * ys
            px = [pixel_fn(xo + k * xs, y) for k in range(pw)]
            data = pack_row(px, depth)
            ftype = filters[py % len(filters)]
            rows.append((ftype, filter_row(ftype, data, prev, bpp)))
            prev = data
    for y in range(h):
        for x in range(w):
            exp += expand_rgba(pixel_fn(x, y), ctype, depth)
    return rows, bpp, bytes(exp)

def png_write(name, w, h, depth, ctype, raw_rows_ftyped, bpp,
              palette=None, trns=None, interlace=0, comp_level=9):
    # filter_row УЖЕ возвращает [ftype]+данные — не добавляем байт ещё раз
    payload = b"".join(d for f, d in raw_rows_ftyped)
    ihdr = struct.pack(">IIBBBBB", w, h, depth, ctype, 0, 0, interlace)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
    if palette: png += chunk(b"PLTE", b"".join(struct.pack("BBB", *p) for p in palette))
    if trns is not None: png += chunk(b"tRNS", trns)
    png += chunk(b"IDAT", zlib.compress(payload, comp_level))
    png += chunk(b"IEND", b"")
    open(os.path.join(FIX, name + ".png"), "wb").write(png)
    return png

def add_png(name, w, h, depth, ctype, pixel_fn, level=9, interlace=0,
            palette=None, trns=None, expect_fail=False):
    rows, bpp, exp = build_raw(w, h, depth, ctype, pixel_fn, [0,1,2,3,4,0,1,2], interlace)
    png_write(name, w, h, depth, ctype, rows, bpp, palette, trns, interlace, level)
    if expect_fail:
        p = open(os.path.join(FIX, name + ".png"), "rb").read()
        if name == "corrupt_truncated":
            p = p[:len(p) // 2]
        else:
            i = p.index(b"IDAT") + 4
            p = p[:i + 10] + bytes([p[i + 10] ^ 0x5A]) + p[i + 11:]
        open(os.path.join(FIX, name + ".png"), "wb").write(p)
    manifest.append({"name": name, "w": w, "h": h,
                     "rgba_crc32": zlib.crc32(exp) & 0xFFFFFFFF,
                     "rgba_len": len(exp), "expect_fail": expect_fail})

# ---------------- набор изображений ----------------

add_png("gray8_33x17", 33, 17, 8, 0, lambda x, y: (x * 7 + y * 3) & 0xFF)
add_png("rgb8_64x64", 64, 64, 8, 2, lambda x, y: ((x * 4) & 0xFF, (y * 4) & 0xFF, (x ^ y) & 0xFF))
add_png("rgba8_48x32", 48, 32, 8, 6,
        lambda x, y: ((x * 5) & 0xFF, (y * 8) & 0xFF, 128, (x * y) & 0xFF))
add_png("pal8_40x40", 40, 40, 8, 3,
        lambda x, y: ((x + y) % 16,), palette=PALETTE_16, trns=TRNS_16)
add_png("gray1_35x9", 35, 9, 1, 0, lambda x, y: ((x + y) % 2,))
add_png("gray2_11x7", 11, 7, 2, 0, lambda x, y: ((x * y) % 4,))
add_png("gray4_23x11", 23, 11, 4, 0, lambda x, y: ((x + 2 * y) % 16,))
add_png("rgb16_9x5", 9, 5, 16, 2,
        lambda x, y: (x * 7000 + y, y * 9000, 12345))
add_png("gray16_7x3", 7, 3, 16, 0, lambda x, y: (x * 8000 + y * 500,))
add_png("il_rgb8_37x23", 37, 23, 8, 2,
        lambda x, y: ((x * 6) & 0xFF, (y * 11) & 0xFF, (x + y) & 0xFF), interlace=1)
add_png("il_pal8_29x19", 29, 19, 8, 3,
        lambda x, y: ((x * 3 + y) % 16,), interlace=1, palette=PALETTE_16, trns=TRNS_16)
add_png("stored_gray8_41x13", 41, 13, 8, 0, lambda x, y: (x * 3 + y) & 0xFF, level=0)
add_png("big_ramp_300x200", 300, 200, 8, 2,
        lambda x, y: ((x * x + y) & 0xFF, (x // 2 + y * 2) & 0xFF, (x + y * 3) & 0xFF), level=6)
add_png("corrupt_truncated", 20, 10, 8, 0, lambda x, y: (x + y) & 0xFF, expect_fail=True)
add_png("corrupt_idat_bit", 20, 10, 8, 0, lambda x, y: (x + y) & 0xFF, expect_fail=True)

# ---------------- zlib / gzip / raw потоки ----------------

payload = bytes(((i * 31 + (i >> 3)) & 0xFF) for i in range(60000)) * 2

for lvl in (0, 1, 6, 9):
    z = zlib.compress(payload, lvl)
    open(os.path.join(FIX, f"zlib_l{lvl}.bin"), "wb").write(z)
    consts[f"zlib_l{lvl}_crc32"] = zlib.crc32(payload) & 0xFFFFFFFF
    consts[f"zlib_l{lvl}_len"] = len(payload)

buf = io.BytesIO()
with gzip.GzipFile(filename="fixture_name.bin", mode="wb", compresslevel=9,
                   fileobj=buf, mtime=0) as f:
    f.write(payload)
open(os.path.join(FIX, "gzip_fname.bin"), "wb").write(buf.getvalue())
consts["gzip_fname_crc32"] = zlib.crc32(payload) & 0xFFFFFFFF
consts["gzip_fname_len"] = len(payload)

co = zlib.compressobj(9, zlib.DEFLATED, -15)
body = co.compress(payload) + co.flush()
extra = struct.pack("<HH", 0x0001, 4) + b"ABCD"
hdr = b"\x1f\x8b\x08" + bytes([0x02 | 0x04 | 0x08]) + struct.pack("<I", 0) + b"\x02\x03"
hdr += struct.pack("<H", len(extra)) + extra + b"custom.bin\x00"
hdr += struct.pack("<H", zlib.crc32(hdr) & 0xFFFF)
gzb = hdr + body + struct.pack("<II", zlib.crc32(payload) & 0xFFFFFFFF, len(payload) & 0xFFFFFFFF)
open(os.path.join(FIX, "gzip_full.bin"), "wb").write(gzb)
consts["gzip_full_crc32"] = zlib.crc32(payload) & 0xFFFFFFFF
consts["gzip_full_len"] = len(payload)

co = zlib.compressobj(9, zlib.DEFLATED, -15)
open(os.path.join(FIX, "raw_deflate.bin"), "wb").write(co.compress(payload) + co.flush())
consts["raw_crc32"] = zlib.crc32(payload) & 0xFFFFFFFF
consts["raw_len"] = len(payload)

zeros = b"\x00" * 200000
open(os.path.join(FIX, "zlib_zeros.bin"), "wb").write(zlib.compress(zeros, 9))
consts["zlib_zeros_len"] = len(zeros)
consts["zlib_zeros_crc32"] = zlib.crc32(zeros) & 0xFFFFFFFF

open(os.path.join(FIX, "err_badmagic.bin"), "wb").write(b"\x1f\x8c\x08\x00" + b"\x00" * 20)
g = open(os.path.join(FIX, "gzip_fname.bin"), "rb").read()
open(os.path.join(FIX, "err_truncated.bin"), "wb").write(g[:len(g) // 2])
bad = bytearray(g); bad[-6] ^= 0xFF
open(os.path.join(FIX, "err_badcrc.bin"), "wb").write(bytes(bad))

# ---------------- expected.h / manifest ----------------

lines = ["/* expected.h — константы для test_gunzip.c (генерировано",
         "   gen_gz_fixtures.py — НЕ редактировать вручную) */", ""]
for k, v in consts.items():
    lines.append(f"#define EXP_{k.upper()} {v}u")
open(os.path.join(BASE, "expected.h"), "w").write("\n".join(lines) + "\n")

json.dump(manifest, open(os.path.join(FIX, "manifest.json"), "w"), indent=1)

# manifest.h для C-теста
mh = ["/* manifest.h — сгенерировано gen_gz_fixtures.py */",
      "static const struct {",
      "    const char *name; int w, h; unsigned crc32, len; int expect_fail;",
      "} g_pngs[] = {"]
for m in manifest:
    mh.append('    { "%s", %d, %d, %uu, %du, %d },'
              % (m["name"], m["w"], m["h"], m["rgba_crc32"], m["rgba_len"],
                 1 if m["expect_fail"] else 0))
mh.append("};")
open(os.path.join(BASE, "manifest.h"), "w").write("\n".join(mh) + "\n")

print(f"фикстур: {len(manifest)} PNG, {len(consts)} констант -> {FIX}")
