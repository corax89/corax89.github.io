/* ref_expected.h — эталон из task62 (генерирует run.sh) */
#define REF_FW_LEN        32286u
#define REF_FW_CRC32      921219479u
#define REF_INI_LEN       26080u
#define REF_INI_CRC32     3235337317u
#define REF_RTLTAB_LEN    4536u
#define REF_RTLTAB_CRC32  431861379u
