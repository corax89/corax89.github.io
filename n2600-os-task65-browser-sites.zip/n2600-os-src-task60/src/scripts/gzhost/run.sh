#!/bin/sh
# run.sh — хост-тест gunzip (Task 63): движок zlib/gzip вынесен из
# stb_image.h в src/gunzip.c; прошивка RTL8192EU и ini/таблицы WiFi
# сжаты gzip. Тест проверяет распаковку РЕАЛЬНЫХ блобов ядра (CRC
# против эталона из task62), zlib/gzip/raw-потоки, ошибки, рост
# буфера и ПОБАЙТНУЮ эквивалентность PNG-декодирования с не патченным
# stb. Запуск: sh scripts/gzhost/run.sh
set -e
cd "$(dirname "$0")"

ZIP=../../../download/n2600-os-task62-httpd-kbd-cursor.zip
[ -f "$ZIP" ] || ZIP=/home/z/my-project/download/n2600-os-task62-httpd-kbd-cursor.zip

echo "[1/4] эталонные данные из task62 -> ref_expected.h"
mkdir -p ref_orig
unzip -o -q "$ZIP" 'n2600-os-src-task60/src/src/rtl8192eu_fw.c' \
    'n2600-os-src-task60/src/src/ath9k_ini_data.h' \
    'n2600-os-src-task60/src/src/rtl8192eu_tables.h' -d ref_orig/
mv ref_orig/n2600-os-src-task60/src/src/* ref_orig/ 2>/dev/null || true
rm -rf ref_orig/n2600-os-src-task60

python3 - <<'EOF'
import gzip, io, re, struct, zlib

def c_bytes(text, arr):
    m = re.search(r'const u8\s+' + arr + r'\[[^\]]*\]\s*=\s*\{(.*?)\};', text, re.S)
    vals = re.findall(r'0[xX][0-9a-fA-F]{1,2}', m.group(1))
    return bytes(int(v, 0) for v in vals)

def c_u32_arrays(text):
    """все static const u32 name[][N] -> конкатенация слов (LE)"""
    out = b""
    for m in re.finditer(r'static const u32\s+\w+\[\]\[(\d)\]\s*=\s*\{(.*?)\};', text, re.S):
        nums = re.findall(r'0[xX][0-9a-fA-F]+|\b\d{1,10}\b', m.group(2))
        out += b"".join(struct.pack("<I", int(v, 0) & 0xFFFFFFFF) for v in nums)
    return out

def c_struct_tables(text):
    """rtl8192eu_tables.h: эмуляция C-layout таблиц"""
    out = b""
    for m in re.finditer(r'static const (rtl_tab8_entry_t|rtl_tab_entry_t)\s+\w+\[\]\s*=\s*\{(.*?)\};', text, re.S):
        typ, body = m.group(1), m.group(2)
        for a, v in re.findall(r'\{\s*(0[xX][0-9a-fA-F]+|\d+)\s*,\s*(0[xX][0-9a-fA-F]+|\d+)\s*\}', body):
            a_i, v_i = int(a, 0), int(v, 0)
            out += struct.pack("<HxxI", a_i, v_i) if typ == "rtl_tab_entry_t" \
                   else struct.pack("<HBB", a_i, v_i & 0xFF, 0)
    return out

fw   = c_bytes(open("ref_orig/rtl8192eu_fw.c", encoding='utf-8', errors='replace').read(), "rtl8192eu_fw_data")
ini  = c_u32_arrays(open("ref_orig/ath9k_ini_data.h", encoding='utf-8', errors='replace').read())
tabs = c_struct_tables(open("ref_orig/rtl8192eu_tables.h", encoding='utf-8', errors='replace').read())

L = ["/* ref_expected.h — эталон из task62 (генерирует run.sh) */",
     f"#define REF_FW_LEN        {len(fw)}u",
     f"#define REF_FW_CRC32      {zlib.crc32(fw) & 0xFFFFFFFF}u",
     f"#define REF_INI_LEN       {len(ini)}u",
     f"#define REF_INI_CRC32     {zlib.crc32(ini) & 0xFFFFFFFF}u",
     f"#define REF_RTLTAB_LEN    {len(tabs)}u",
     f"#define REF_RTLTAB_CRC32  {zlib.crc32(tabs) & 0xFFFFFFFF}u"]
open("ref_expected.h", "w").write("\n".join(L) + "\n")
print(f"  fw={len(fw)}B ini={len(ini)}B tables={len(tabs)}B")
EOF

echo "[2/4] фикстуры"
python3 gen_gz_fixtures.py

echo "[3/4] сборка"
# референсный stb: pristine из task62 + переименование публичных символов
unzip -o -q "$ZIP" 'n2600-os-src-task60/src/src/stb_image.h' -d ref_orig2/
cp ref_orig2/n2600-os-src-task60/src/src/stb_image.h stb_image_ref.h
rm -rf ref_orig2

# референсный TU: глобальные stbi* символы переименовываются в
# stbi_ref_* (--redefine-syms по списку из nm — только ОПРЕДЕЛЁННЫЕ
# глобальные; undefined-ссылки malloc/__asan_* не трогаем)
gcc -DGZ_HOST -O1 -g -fsanitize=address,undefined -I. -c stb_impl_ref.c -o stb_impl_ref.o
nm stb_impl_ref.o | awk '$2 ~ /^[TDBR]$/ && $3 ~ /^stbi_/ {n=$3; sub(/^stbi_/, "", n); print $3" stbi_ref_"n}' > redef_syms.txt
objcopy --redefine-syms=redef_syms.txt stb_impl_ref.o

FLAGS="-DGZ_HOST -O1 -g -fsanitize=address,undefined -I. -I../../src"
gcc $FLAGS -c test_gunzip.c      -o test_gunzip.o
gcc $FLAGS -c ../../src/gunzip.c -o gunzip.o
gcc $FLAGS -c stb_impl_new.c     -o stb_impl_new.o
gcc $FLAGS -c ../../src/rtl8192eu_fw.c -o fw_gz.o
gcc -fsanitize=address,undefined -o test_gunzip \
    test_gunzip.o gunzip.o stb_impl_new.o stb_impl_ref.o fw_gz.o

echo "[4/4] запуск"
./test_gunzip fixtures
