/* test_gunzip.c — хост-тест вынесенного zlib/gzip-движка (Task 63).
 *
 * Проверяет:
 *   1. gz_inflate_gzip на РЕАЛЬНЫХ блобах ядра: сжатая прошивка
 *      RTL8192EU, gzip-таблицы RTL8192EU, gzip-ini-таблицы ath9k
 *      (CRC-32 распакованного сверяется с оригиналом из эталонного
 *      task62-архива — см. run.sh, ref_expected.h);
 *   2. gz_inflate_zlib / gz_inflate_raw / gz_inflate_gzip на
 *      сгенерированных потоках (уровни 0/1/6/9, stored-блоки, FNAME/
 *      FEXTRA/FHCRC-заголовки gzip);
 *   3. рост буфера gz_zlib_decode_alloc_hdr (старт 64 байта -> 200К);
 *   4. ошибки: битый magic, обрезанный поток, битый CRC, малый out_cap;
 *   5. PNG-эквивалентность: патченный stb_image.h (через gunzip.c)
 *      декодирует 15 PNG (все color types, depth 1/2/4/8/16, Adam7,
 *      stored-блоки, 2 битых) — побайтно совпадает с НЕпатченным stb
 *      (референс, свой встроенный zlib) и с ожидаемым RGBA из Python.
 *
 * Сборка/запуск: sh run.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef GZ_HOST
#define GZ_HOST
#endif
#include "../../src/gunzip.h"

#include "expected.h"
#include "manifest.h"
#include "ref_expected.h"

/* размер gz-прошивки определяется в rtl8192eu_fw.c; сюда — дублируем
 * (run.sh сверяет распакованную длину с эталоном REF_FW_LEN) */
#ifndef RTL8192EU_FW_GZ_SIZE
#define RTL8192EU_FW_GZ_SIZE 20733u
#endif

/* gz-блобы ядра: прошивка — отдельная TU (rtl8192eu_fw.c), таблицы и
 * ini — статические массивы в заголовках. */
extern const unsigned char rtl8192eu_fw_gz[];
#include "../../src/rtl8192eu_tables.h"
#include "../../src/ath9k_ini_data.h"

/* PNG-декодеры: новый (через gunzip.c) и референсный (не патченный) */
extern unsigned char *stbi_load_from_memory(const unsigned char *buffer, int len,
                                            int *x, int *y, int *comp, int req);
extern void           stbi_image_free(void *retval);
extern const char    *stbi_failure_reason(void);
extern unsigned char *stbi_ref_load_from_memory(const unsigned char *b, int len,
                                                int *x, int *y, int *c, int rq);
extern void           stbi_ref_image_free(void *p);

#include <stdarg.h>

static int pass, fail;
static const char *g_fix;

static void check(const char *fmt, int cond, ...)
{
    va_list ap;
    va_start(ap, cond);
    printf("  [%s] ", cond ? "PASS" : "FAIL");
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    if (cond) pass++; else fail++;
}

static unsigned char *read_file(const char *path, int *len)
{
    FILE *f = fopen(path, "rb");
    unsigned char *buf;
    long n;
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); n = ftell(f); fseek(f, 0, SEEK_SET);
    buf = (unsigned char *)malloc((size_t)n ? (size_t)n : 1);
    if (!buf) { fclose(f); return NULL; }
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { free(buf); fclose(f); return NULL; }
    fclose(f);
    *len = (int)n;
    return buf;
}

/* ---------------- 1. блобы ядра ---------------- */

static void test_kernel_blobs(void)
{
    static unsigned char out[512 * 1024];
    unsigned len = 0;

    printf("== gzip-блобы ядра (сверка с эталоном task62) ==\n");

    /* прошивка RTL8192EU: gz_inflate_gzip проверяет CRC/ISIZE сама,
     * здесь дополнительно сверяем длину и CRC с оригиналом */
    {
        int rc = gz_inflate_gzip(rtl8192eu_fw_gz, RTL8192EU_FW_GZ_SIZE,
                                 out, sizeof(out), &len);
        check("RTL8192EU: прошивка распакована", rc == 0);
        check("RTL8192EU: длина == эталону", len == REF_FW_LEN);
        check("RTL8192EU: CRC-32 == эталону",
              gz_crc32(out, len) == REF_FW_CRC32);
        /* fw-заголовок: подпись 0x92e1 (первый u16 LE) */
        check("RTL8192EU: подпись 0x92e1",
              (out[0] | (out[1] << 8)) == 0x92e1);
    }

    /* таблицы RTL8192EU */
    {
        int rc = gz_inflate_gzip(rtl8192eu_tab_gz, RTL8192EU_TAB_GZ_SIZE,
                                 out, sizeof(out), &len);
        check("RTL8192EU: таблицы распакованы", rc == 0);
        check("RTL8192EU: длина таблиц == эталону",
              len == RTL8192EU_TAB_WORDS * 4 && len == REF_RTLTAB_LEN);
        check("RTL8192EU: CRC-32 таблиц == эталону",
              gz_crc32(out, len) == REF_RTLTAB_CRC32);
        /* первая запись MAC-таблицы: addr 0x0011 val 0xeb (tab8) */
        check("RTL8192EU: первая запись MAC-таблицы",
              out[0] == 0x11 && out[1] == 0x00 && out[2] == 0xeb && out[3] == 0x00);
    }

    /* ini-таблицы ath9k */
    {
        int rc = gz_inflate_gzip(ath9k_ini_gz, ATH_INI_GZ_SIZE,
                                 out, sizeof(out), &len);
        check("ath9k: ini-таблицы распакованы", rc == 0);
        check("ath9k: длина ini == эталону",
              len == ATH_INI_WORDS * 4 && len == REF_INI_LEN);
        check("ath9k: CRC-32 ini == эталону",
              gz_crc32(out, len) == REF_INI_CRC32);
        /* первая строка ar9285Modes_9285_1_2: {0x00001030, 0x00000230, ...} */
        {
            unsigned w0 = out[0] | (out[1] << 8) | (out[2] << 16) | (out[3] << 24);
            unsigned w1 = out[4] | (out[5] << 8) | (out[6] << 16) | (out[7] << 24);
            check("ath9k: первая строка ini {1030,0230}",
                  w0 == 0x00001030u && w1 == 0x00000230u);
        }
    }
}

/* ---------------- 2/3/4. потоки zlib/gzip/raw + ошибки ---------------- */

static void test_streams(void)
{
    static unsigned char out[512 * 1024];
    unsigned len = 0;
    char path[512];

    printf("== zlib/gzip/raw потоки ==\n");

    for (int i = 0; i < 4; i++) {
        static const char *lv[4] = { "l0", "l1", "l6", "l9" };
        snprintf(path, sizeof(path), "%s/zlib_%s.bin", g_fix, lv[i]);
        int flen; unsigned char *p = read_file(path, &flen);
        if (!p) { check("zlib файл прочитан", 0); continue; }
        unsigned crc = 0;
        crc = (i == 0) ? EXP_ZLIB_L0_CRC32 : (i == 1) ? EXP_ZLIB_L1_CRC32 :
              (i == 2) ? EXP_ZLIB_L6_CRC32 : EXP_ZLIB_L9_CRC32;
        unsigned elen = (i == 0) ? EXP_ZLIB_L0_LEN : (i == 1) ? EXP_ZLIB_L1_LEN :
                        (i == 2) ? EXP_ZLIB_L6_LEN : EXP_ZLIB_L9_LEN;
        int rc = gz_inflate_zlib(p, (unsigned)flen, out, sizeof(out), &len);
        check("zlib %s: распакован", rc == 0 && len == elen &&
              gz_crc32(out, len) == crc, lv[i]);
        free(p);
    }

    snprintf(path, sizeof(path), "%s/raw_deflate.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        unsigned consumed = 0;
        int rc = gz_inflate_raw(p, (unsigned)flen, out, sizeof(out), &len, &consumed);
        check("raw deflate: распакован", rc == 0 && len == EXP_RAW_LEN &&
              consumed == (unsigned)flen && gz_crc32(out, len) == EXP_RAW_CRC32);
        free(p);
    }

    snprintf(path, sizeof(path), "%s/gzip_fname.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        int rc = gz_inflate_gzip(p, (unsigned)flen, out, sizeof(out), &len);
        check("gzip FNAME: распакован", rc == 0 && len == EXP_GZIP_FNAME_LEN &&
              gz_crc32(out, len) == EXP_GZIP_FNAME_CRC32);
        free(p);
    }

    snprintf(path, sizeof(path), "%s/gzip_full.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        int rc = gz_inflate_gzip(p, (unsigned)flen, out, sizeof(out), &len);
        check("gzip FEXTRA+FHCRC+FNAME: распакован",
              rc == 0 && len == EXP_GZIP_FULL_LEN &&
              gz_crc32(out, len) == EXP_GZIP_FULL_CRC32);
        free(p);
    }

    printf("== рост выходного буфера (alloc-путь) ==\n");
    snprintf(path, sizeof(path), "%s/zlib_zeros.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        unsigned char *big = gz_zlib_decode_alloc_hdr(p, (unsigned)flen, 64, &len, 1);
        check("alloc: 64 байта выросли в 200000",
              big != NULL && len == EXP_ZLIB_ZEROS_LEN &&
              gz_crc32(big, len) == EXP_ZLIB_ZEROS_CRC32);
        free(big);
        free(p);
    }

    printf("== ошибки ==\n");
    snprintf(path, sizeof(path), "%s/err_badmagic.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        check("gzip: битый magic -> -1",
              gz_inflate_gzip(p, (unsigned)flen, out, sizeof(out), &len) == -1);
        free(p);
    }
    snprintf(path, sizeof(path), "%s/err_truncated.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        check("gzip: обрезанный поток -> -1",
              gz_inflate_gzip(p, (unsigned)flen, out, sizeof(out), &len) == -1);
        free(p);
    }
    snprintf(path, sizeof(path), "%s/err_badcrc.bin", g_fix);
    {
        int flen; unsigned char *p = read_file(path, &flen);
        check("gzip: битый CRC в трейлере -> -1",
              gz_inflate_gzip(p, (unsigned)flen, out, sizeof(out), &len) == -1);
        free(p);
    }
    /* малый out_cap на фиксированном буфере: прошивка в 1000 байт */
    {
        static unsigned char small[1000];
        check("gzip: переполнение out_cap -> -1",
              gz_inflate_gzip(rtl8192eu_fw_gz, RTL8192EU_FW_GZ_SIZE,
                              small, sizeof(small), &len) == -1);
    }
}

/* ---------------- 5. PNG-эквивалентность ---------------- */

static void test_png(void)
{
    char path[512];
    printf("== PNG: патченный stb (gunzip.c) vs референс и ожидание ==\n");
    for (unsigned i = 0; i < sizeof(g_pngs) / sizeof(g_pngs[0]); i++) {
        int flen; unsigned char *p;
        snprintf(path, sizeof(path), "%s/%s.png", g_fix, g_pngs[i].name);
        p = read_file(path, &flen);
        if (!p) { check("PNG прочитан", 0); continue; }

        int nx, ny, nc, rx, ry, rc2;
        unsigned char *nimg = stbi_load_from_memory(p, flen, &nx, &ny, &nc, 4);
        unsigned char *rimg = stbi_ref_load_from_memory(p, flen, &rx, &ry, &rc2, 4);

        if (g_pngs[i].expect_fail) {
            check("PNG %s: битый поток -> NULL (новый)", nimg == NULL, g_pngs[i].name);
            check("PNG %s: битый поток -> NULL (референс)", rimg == NULL, g_pngs[i].name);
        } else if (!nimg || !rimg) {
            printf("      (новый=%p ref=%p причина=%s)\n", (void*)nimg, (void*)rimg,
                   nimg ? "-" : stbi_failure_reason());
            check("PNG %s: декодирован", 0, g_pngs[i].name);
        } else {
            /* ВАЖНО: comp (nc/rc2) — исходное число каналов файла, а не
             * req_comp; данные при req=4 всегда RGBA (4 байта/пиксель). */
            int same = (nx == rx && ny == ry &&
                        memcmp(nimg, rimg, (size_t)nx * ny * 4) == 0);
            int crcok = ((unsigned)nx * (unsigned)ny * 4u == g_pngs[i].len) &&
                        gz_crc32(nimg, (unsigned)nx * ny * 4) == g_pngs[i].crc32;
            if (!crcok || !same)
                printf("      (%s: new %dx%d ref %dx%d crc %s)\n", g_pngs[i].name,
                       nx, ny, rx, ry, crcok ? "ok" : "MISMATCH");
            check("PNG %s: == референсу и ожиданию", same && crcok, g_pngs[i].name);
        }
        free(nimg);
        free(rimg);
        free(p);
    }
}

int main(int argc, char **argv)
{
    g_fix = (argc > 1) ? argv[1] : "fixtures";
    printf("test_gunzip: движок zlib/gzip + PNG-эквивалентность\n");
    test_kernel_blobs();
    test_streams();
    test_png();
    printf("\nИтог: %d PASS, %d FAIL\n", pass, fail);
    return fail ? 1 : 0;
}
