/* stb_impl_ref.c — хост-сборка НЕпатченного (эталонного) stb_image.h
 * из task62: PNG декодируется ВСТРОЕННЫМ в stb zlib-движком. Служит
 * референсом для сравнения с новым путём (gunzip.c). Публичные символы
 * переименованы -D-флагами из run.sh, чтобы не конфликтовать с новым TU. */
#include <stdlib.h>
#include <string.h>

#define STBI_NO_STDIO
#define STBI_NO_SIMD
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_MAX_DIMENSIONS 8192
#define STBI_NO_THREAD_LOCALS
#define STBI_ASSERT(x) ((void)0)

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image_ref.h"
