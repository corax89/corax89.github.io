/* stb_impl_new.c — хост-сборка ПАТЧЕННОГО stb_image.h (Task 63):
 * PNG-декодер получает inflate из gunzip.c (GZ_HOST). Конфигурация —
 * аналог src/stb_image.c, но на libc (хост). */
#include <stdlib.h>
#include <string.h>

#define STBI_NO_STDIO
#define STBI_NO_SIMD
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_MAX_DIMENSIONS 8192
#define STBI_NO_THREAD_LOCALS
#define STBI_ASSERT(x) ((void)0)

#define STB_IMAGE_IMPLEMENTATION
#include "../../src/stb_image.h"
