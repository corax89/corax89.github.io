#!/usr/bin/env python3
"""gen_mqjs.py — генерация исходников MicroQuickJS для ядра N2600-OS
из single-file amalgamation (mquickjs_single.zip, corax89.github.io).

Сессия 64: CMScript заменён на MicroQuickJS (bellard/mquickjs, MIT).

Что делается:
  1. src/mqjs_engine.c   — ядро движка: cutils.c + dtoa.c + libm.c +
                           mquickjs.c (строки 1..27683 amalgamation).
                           CLI-часть (readline.c, readline_tty.c, mqjs.c)
                           НЕ включается — она не нужна в ядре.
     - <stdlib.h>/<stdio.h>/<string.h>/<math.h>/<assert.h>/<ctype.h>/
       <inttypes.h>/<setjmp.h> -> "mqjs_libc.h" (фристендинг-шим ядра);
       <stdarg.h> остаётся (GCC даёт её во freestanding).
     - блок "inlined: mquickjs.h" заменяется на #include "mqjs.h",
       чтобы мост (mqjs_api.c) и движок не дублировали декларации.
     - ПРИНУДИТЕЛЬНО включается JS_PTR64: single-file amalgamation
       сгенерирован с 64-битными ROM-таблицами (js_stdlib_table —
       uint64_t, индексы атомов в 64-битных единицах). На i386 движок
       обязан жить в том же формате: JSValue/JSWord = uint64_t.
  2. src/mqjs.h          — публичный API движка (блок "inlined: mquickjs.h"
                           с заменой <inttypes.h> на "mqjs_libc.h").
  3. src/mqjs_stdlib.h   — сгенерированные таблицы стандарта
                           (блок "inlined: mqjs_stdlib.h", строки
                           29051..31749): js_stdlib_table, js_c_function_table,
                           js_stdlib (JSSTDLibraryDef). Включается ТОЛЬКО
                           из mqjs_api.c (таблицы static).

Запуск:  python3 scripts/gen_mqjs.py <path-to-mquickjs_single.c>
"""
import re
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))
# корень дерева ОС: 1-й аргумент (по умолчанию — рядом с scripts/)
ROOT = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(HERE)
SRC = os.path.join(ROOT, "src")

PROVENANCE = """/* mqjs_engine.c — MicroQuickJS (bellard/mquickjs, MIT) для ядра N2600-OS.
 *
 * СГЕНЕРИРОВАНО скриптом scripts/gen_mqjs.py из single-file amalgamation
 * mquickjs_single.zip (https://github.com/corax89/corax89.github.io,
 * upstream https://github.com/bellard/mquickjs, commit 6d4d7eb).
 * НЕ ПРАВИТЬ ВРУЧНУЮ — править генератор и перегенерировать.
 *
 * Состав: cutils.c + dtoa.c + libm.c (вся математика внутри, хостовый
 * libm не нужен) + mquickjs.c. CLI-часть (readline/mqjs.c) исключена.
 *
 * Отличия от оригинала (все — в шапке/инклюдах, код не тронут):
 *   1. libc-заголовки заменены на "mqjs_libc.h" (фристендинг-шим ядра:
 *      malloc/free -> куча ядра, printf -> serial, setjmp/longjmp —
 *      своя i386-реализация, assert -> паника).
 *   2. Блок "inlined: mquickjs.h" вынесен в src/mqjs.h (общий с мостом).
 *   3. JS_PTR64 форсирован: amalgamation собран с 64-битными
 *      ROM-таблицами стандарта (mqjs_stdlib.h — uint64_t), поэтому
 *      движок обязан использовать JSValue/JSWord = uint64_t даже на i386.
 *
 * SPDX-License-Identifier: MIT
 * Copyright (c) Fabrice Bellard, Charlie Gordon and contributors
 */
"""

def read_lines(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.readlines()

def find_section(lines, marker):
    """Возвращает (start, end) индексы строк блока begin/end inlined."""
    bs = be = -1
    for i, l in enumerate(lines):
        if bs < 0 and marker in l and "begin inlined" in l:
            bs = i
        elif bs >= 0 and marker in l and "end inlined" in l:
            be = i
            break
    if bs < 0 or be < 0:
        raise RuntimeError("section not found: " + marker)
    return bs, be

def find_source_end(lines, source_name):
    """Индекс строки ПЕРЕД заголовком следующего SOURCE FILE."""
    for i, l in enumerate(lines):
        if "SOURCE FILE:" in l and source_name in l:
            # начало блока: "/****" выше, перед ним пустая строка;
            # контент заканчивается строкой ПЕРЕД пустой (i - 2, exclusive)
            return max(0, i - 2)
    raise RuntimeError("source not found: " + source_name)

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src_path = sys.argv[1]
    os.makedirs(SRC, exist_ok=True)
    lines = read_lines(src_path)

    # ---- 0. mqjs_priv.h: внутренние определения движка ----------------
    # (нужны mqjs_stdlib.h: JS_MTAG_*, JS_VALUE_ARRAY_HEADER, JS_ROM_VALUE;
    #  плюс прототипы js_global_isNaN/isFinite из стандлиба)
    pb, pe = find_section(lines, "mquickjs_priv.h")
    priv = []
    skip_h = False
    for l in lines[pb:pe + 1]:
        if "begin inlined: mquickjs_priv.h" in l or "end inlined: mquickjs_priv.h" in l:
            continue
        if "begin inlined: mquickjs.h" in l:
            skip_h = True
            priv.append('  #include "mqjs.h"\n')
            continue
        if "end inlined: mquickjs.h" in l:
            skip_h = False
            continue
        if skip_h:
            continue
        priv.append(l)
    priv_text = "".join(priv)
    # N2600-OS: оригинальный макрос (JSWord)((uintptr_t)ptr + 1) не является
    # константным выражением для статических инициализаторов на i386, где
    # uintptr_t 32 бита, а JSWord 64 (двойной каст). Прямой каст
    # указателя в JSWord GNU C принимает как address constant.
    priv_text = priv_text.replace(
        "#define JS_VALUE_FROM_PTR(ptr) (JSWord)((uintptr_t)(ptr) + 1)",
        "#define JS_VALUE_FROM_PTR(ptr) ((JSWord)(ptr) + 1) /* N2600-OS: см. шапку */")
    mqjs_priv = (
        "/* mqjs_priv.h — внутренние определения MicroQuickJS (извлечено из\n"
        " * amalgamation скриптом scripts/gen_mqjs.py). Нужны мосту ради\n"
        " * макросов ROM-таблиц (JS_MTAG_*, JS_VALUE_ARRAY_HEADER, JS_ROM_VALUE),\n"
        " * которыми пользуется mqjs_stdlib.h, и прототипов js_global_isNaN/isFinite.\n"
        " * N2600-OS: JS_VALUE_FROM_PTR переписан ((JSWord)ptr + 1) — двойной\n"
        " * каст через uintptr_t не проходит константным выражением на i386.\n"
        " * SPDX-License-Identifier: MIT\n"
        " */\n#ifndef MQJS_PRIV_H\n#define MQJS_PRIV_H\n\n"
        + priv_text + "\n#endif /* MQJS_PRIV_H */\n"
    )
    with open(os.path.join(SRC, "mqjs_priv.h"), "w", encoding="utf-8") as f:
        f.write(mqjs_priv)
    print("src/mqjs_priv.h    :", len(mqjs_priv.splitlines()), "lines")

    # ---- 0b. mqjs_libm.h: декларации js_sin/js_pow/... (нужны таблице
    #        стандарта: Math.* реализованы как .f_f функции движка) --------
    lb, le = find_section(lines, "libm.h")
    libm_h = []
    for l in lines[lb:le + 1]:
        if "begin inlined: libm.h" in l or "end inlined: libm.h" in l:
            continue
        libm_h.append(l)
    mqjs_libm = (
        "/* mqjs_libm.h — декларации математических функций движка\n"
        " * (извлечено scripts/gen_mqjs.py; нужны mqjs_stdlib.h для Math.*).\n"
        " * SPDX-License-Identifier: MIT\n"
        " */\n#ifndef MQJS_LIBM_H\n#define MQJS_LIBM_H\n\n"
        + "".join(libm_h) + "\n#endif /* MQJS_LIBM_H */\n"
    )
    with open(os.path.join(SRC, "mqjs_libm.h"), "w", encoding="utf-8") as f:
        f.write(mqjs_libm)
    print("src/mqjs_libm.h    :", len(mqjs_libm.splitlines()), "lines")

    # ---- 1. mqjs.h: блок inlined: mquickjs.h --------------------------
    hb, he = find_section(lines, "mquickjs.h")
    hdr = lines[hb:he + 1]
    # убрать маркеры "=====" и заменить include
    out = []
    for l in hdr:
        if "begin inlined: mquickjs.h" in l or "end inlined: mquickjs.h" in l:
            continue
        l = l.replace("#include <inttypes.h>", '#include "mqjs_libc.h"')
        out.append(l)
    # форсировать JS_PTR64: ROM-таблицы amalgamation (mqjs_stdlib.h)
    # сгенерированы в 64-битном формате — движок обязан жить в нём
    # и на i386 (JSValue/JSWord = uint64_t).
    text = "".join(out)
    pat = re.compile(
        r"#if INTPTR_MAX >= INT64_MAX\s*\n"
        r"#define JS_PTR64[^\n]*\n"
        r"#endif\s*\n"
    )
    text, n64h = pat.subn(
        "/* N2600-OS (генератор): JS_PTR64 форсирован — ROM-таблицы\n"
        " * стандарта (mqjs_stdlib.h) сгенерированы в 64-битном формате\n"
        " * (uint64_t), поэтому и на i386 JSValue/JSWord = uint64_t. */\n"
        "#define JS_PTR64 /* pointers are 64 bit wide instead of 32 bit wide */\n",
        text,
    )
    if n64h != 1:
        raise RuntimeError("JS_PTR64 block not found in mquickjs.h (%d)" % n64h)
    mqjs_h = (
        "/* mqjs.h — публичный API MicroQuickJS (извлечено из amalgamation).\n"
        " * СГЕНЕРИРОВАНО scripts/gen_mqjs.py — не править вручную.\n"
        " * SPDX-License-Identifier: MIT\n"
        " */\n"
        "#ifndef MQJS_H\n#define MQJS_H\n\n" + text + "\n#endif /* MQJS_H */\n"
    )
    with open(os.path.join(SRC, "mqjs.h"), "w", encoding="utf-8") as f:
        f.write(mqjs_h)
    print("src/mqjs.h          :", len(mqjs_h.splitlines()), "lines")

    # ---- 2. mqjs_stdlib.h: блок inlined: mqjs_stdlib.h ----------------
    # На x86_64 (хост-харнессы) — исходные const-таблицы (ROM-значения
    # (JSWord)(uintptr_t)&tab[n]+1 константны). На i386 (ядро, -fno-pic)
    # cast ptr->u64 в статическом инициализаторе НЕ константен — поэтому
    # в i386-ветке ROM-значения заменяются нулями/JS_UNDEFINED и
    # прописываются рантайм-фикступом (mq_rom_fixup, данные js_rom_fixups_*).
    sb, se = find_section(lines, "mqjs_stdlib.h")
    std_text = "".join(lines[sb + 1:se])   # без строк-маркеров =====

    def split_entries(body):
        """Разбить тело { ... } на записи по запятым верхнего уровня,
        сохраняя комментарии (прикреплены к своей записи)."""
        entries = []
        cur = []
        depth = 0
        in_comment = False
        i = 0
        while i < len(body):
            c = body[i]
            if in_comment:
                cur.append(c)
                if body[i:i+2] == "*/":
                    cur.append("/"); i += 2; in_comment = False
                    continue
                i += 1
                continue
            if body[i:i+2] == "/*":
                in_comment = True
                cur.append("/*"); i += 2
                continue
            if c in "([{":
                depth += 1
            elif c in ")]}":
                depth -= 1
            elif c == "," and depth == 0:
                entries.append("".join(cur))
                cur = []
                i += 1
                continue
            cur.append(c)
            i += 1
        if "".join(cur).strip():
            entries.append("".join(cur))
        # комментарий-фрагмент (только /*...*/ и пробелы) приклеить к
        # ПРЕДЫДУЩЕЙ записи: иначе он становится "пустой записью" и
        # сдвигает индексы фиксступов относительно реального массива C
        merged = []
        for e in entries:
            body = re.sub(r"/\*.*?\*/", "", e, flags=re.S).strip()
            if not body and merged:
                merged[-1] = merged[-1].rstrip() + " " + e.strip()
            else:
                merged.append(e)
        return merged

    def body_of(text, decl):
        """Тело массива между '{' и закрывающей '};' после декларации decl."""
        i = text.find(decl)
        if i < 0:
            raise RuntimeError("decl not found: " + decl[:50])
        j = text.find("{", i + len(decl))
        k = text.find("};", j)
        return text[j + 1:k], text[:j + 1], text[k:]

    # --- таблица js_stdlib_table ---
    tab_body, tab_pre, tab_post = body_of(std_text, "js_stdlib_table[]")
    tab_entries = split_entries(tab_body)
    rom_re = re.compile(r"JS_ROM_VALUE\((\d+)\)")
    fixups_tab = []
    out_entries = []
    for e in tab_entries:
        if not e.strip() and tab_entries.index(e) != len(tab_entries) - 1:
            raise RuntimeError("empty entry in js_stdlib_table (index shift)")
        m = rom_re.search(e)
        if m:
            fixups_tab.append((len(out_entries), int(m.group(1))))
            # сохранить ТОЛЬКО комментарии (значение заменяется нулём;
            # коммент может стоять и ПЕРЕД значением в исходнике)
            comments = re.findall(r"/\*.*?\*/", e, flags=re.S)
            com = " ".join(c.strip() for c in comments)
            out_entries.append(("0 " + com) if com else "0")
        else:
            out_entries.append(e.strip())
    n_tab = len(out_entries)

    # --- таблица js_c_function_table ---
    cft_body, cft_pre, cft_post = body_of(std_text, "js_c_function_table[]")
    cft_entries = split_entries(cft_body)
    fixups_cft = []
    out_cft = []
    for e in cft_entries:
        m = rom_re.search(e)
        if m:
            fixups_cft.append((len(out_cft), int(m.group(1))))
            e = rom_re.sub("JS_UNDEFINED", e)
        out_cft.append(e.strip())
    n_cft = len(out_cft)

    fixlines_tab = ",\n".join("    {%d, %d}" % f for f in fixups_tab)
    fixlines_cft = ",\n".join("    {%d, %d}" % f for f in fixups_cft)

    # i386-ветка: не-const таблицы + данные фикступов
    i386 = (
        "/* N2600-OS i386: cast ptr->u64 не константен при -fno-pic, поэтому\n"
        " * ROM-значения прописываются рантайм-фикступом mq_rom_fixup()\n"
        " * (мост вызывает его один раз до JS_NewContext). Таблица в .data. */\n"
        "#ifndef JS_CLASS_COUNT\n#define JS_CLASS_COUNT JS_CLASS_USER\n#endif\n\n"
        "static JSWord js_stdlib_table[] = {\n"
        + ",\n".join(out_entries) + "\n};\n\n"
        "static const JSCFunctionDef js_c_function_table[] = {\n"
        + ",\n".join(out_cft) + "\n};\n\n"
        "static const JSCFinalizer js_c_finalizer_table[JS_CLASS_COUNT - JS_CLASS_USER] = {\n};\n\n"
        "/* {индекс записи, смещение ROM-атома} */\n"
        "static const unsigned int js_rom_fixups_tab[%d][2] = {\n%s\n};\n"
        "static const unsigned int js_rom_fixups_cft[%d][2] = {\n%s\n};\n\n"
        "const JSSTDLibraryDef js_stdlib = {\n"
        "  js_stdlib_table,\n"
        "  js_c_function_table,\n"
        "  js_c_finalizer_table,\n"
        "  2026,\n  64,\n  554,\n  1937,\n"
        "  JS_CLASS_COUNT,\n};\n" % (len(fixups_tab), fixlines_tab, len(fixups_cft), fixlines_cft)
    )

    mqjs_std = (
        "/* mqjs_stdlib.h — сгенерированные ROM-таблицы стандарта MicroQuickJS\n"
        " * (атомы, объекты std, таблица C-функций). Извлечено из amalgamation\n"
        " * скриптом scripts/gen_mqjs.py. Включается ТОЛЬКО из моста (mqjs_api.c\n"
        " * / хост-харнес): таблицы static, функции CLI (js_print/js_gc/...)\n"
        " * должны быть объявлены ДО включения. 64-битный формат — см. JS_PTR64.\n"
        " * SPDX-License-Identifier: MIT\n"
        " */\n#ifndef MQJS_STDLIB_H\n#define MQJS_STDLIB_H\n\n"
        "#if defined(__LP64__)\n"
        + std_text +
        "#else\n"
        + i386 +
        "#endif /* __LP64__ */\n\n"
        "#endif /* MQJS_STDLIB_H */\n"
    )
    with open(os.path.join(SRC, "mqjs_stdlib.h"), "w", encoding="utf-8") as f:
        f.write(mqjs_std)
    print("src/mqjs_stdlib.h   :", len(mqjs_std.splitlines()), "lines,",
          "ROM fixups: tab", len(fixups_tab), "cft", len(fixups_cft))

    # ---- 3. mqjs_engine.c: движок (до readline.c) ----------------------
    end = find_source_end(lines, "readline.c")
    body = lines[:end]

    # выбросить guard amalgamation: #ifndef/#define MQUICKJS_SINGLE_AMALGAMATED
    # открывается в шапке, а закрывается в самом конце файла (после mqjs.c) —
    # в урезанном движке он остался бы незакрытым
    body = [l for l in body
            if "MQUICKJS_SINGLE_AMALGAMATED" not in l]

    # заменить блоки inlined на include. priv содержит ВЛОЖЕННЫЙ mquickjs.h
    # (и оба закрываются в разное время) — считаем вложенность счётчиком;
    # mqjs_priv.h сам включает mqjs.h, поэтому вложенный блок просто съедается.
    res = []
    skip = 0
    for l in body:
        if "begin inlined: mquickjs_priv.h" in l:
            skip += 1
            res.append('#include "mqjs_priv.h"\n')
            continue
        if "begin inlined: libm.h" in l:
            skip += 1
            res.append('#include "mqjs_libm.h"\n')
            continue
        if "begin inlined: mquickjs.h" in l:
            # вложенный в priv — уже включён через mqjs_priv.h -> mqjs.h
            skip += 1
            continue
        if skip > 0 and ("end inlined: mquickjs.h" in l or "end inlined: mquickjs_priv.h" in l or "end inlined: libm.h" in l):
            skip -= 1
            continue
        if skip > 0:
            continue
        res.append(l)

    # заменить libc-инклюды на шим (stdarg.h остаётся — GCC freestanding)
    REPL = {
        "#include <stdlib.h>":   '#include "mqjs_libc.h"',
        "#include <stdio.h>":    '#include "mqjs_libc.h"',
        "#include <string.h>":   '#include "mqjs_libc.h"',
        "#include <math.h>":     '#include "mqjs_libc.h"',
        "#include <assert.h>":   '#include "mqjs_libc.h"',
        "#include <ctype.h>":    '#include "mqjs_libc.h"',
        "#include <inttypes.h>": '#include "mqjs_libc.h"',
        "#include <setjmp.h>":   '#include "mqjs_libc.h"',
    }
    nrep = 0
    for i, l in enumerate(res):
        s = l.strip()
        if s in REPL:
            res[i] = REPL[s] + "\n"
            nrep += 1

    # форсировать JS_PTR64
    n64 = 0
    for i, l in enumerate(res):
        if "#if INTPTR_MAX >= INT64_MAX" in l and n64 == 0:
            res[i] = ("/* N2600-OS (генератор): JS_PTR64 форсирован — ROM-таблицы\n"
                      " * (mqjs_stdlib.h) сгенерированы в 64-битном формате. */\n"
                      "#define JS_PTR64  /* pointers are 64 bit wide instead of 32 bit wide */\n")
            # съесть последующие 2 строки (#define JS_PTR64 и #endif)
            j = i + 1
            while j < len(res) and "#endif" not in res[j]:
                if "#define JS_PTR64" in res[j]:
                    res[j] = ""
                j += 1
            if j < len(res):
                res[j] = ""
            n64 = 1

    eng = PROVENANCE + "".join(res)
    with open(os.path.join(SRC, "mqjs_engine.c"), "w", encoding="utf-8") as f:
        f.write(eng)
    print("src/mqjs_engine.c   :", len(eng.splitlines()), "lines,",
          "includes replaced:", nrep, ", JS_PTR64 forced:", n64)

if __name__ == "__main__":
    main()
