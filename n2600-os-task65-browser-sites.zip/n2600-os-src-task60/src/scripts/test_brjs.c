/* test_brjs.c — хост-тест brjs.h (извлечение/якоря/лейаут) БЕЗ движка
 * (BRJS_NO_ENGINE): проверяет то, что не требует QuickJS.
 *
 * Сборка:  gcc -O2 -Wall -Wextra -I../src -o test_brjs test_brjs.c
 * (из каталога scripts/). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* kernel-заголовки на хосте: достаточно своих typedef'ов */
typedef unsigned int u32;
typedef unsigned char u8;
typedef short i16;
#include "utf8.h"
#include "brlines.h"
#define BRJS_NO_ENGINE
#include "brjs.h"

static int failures = 0;

#define CHECK(cond, msg) do { \
    if (!(cond)) { \
        printf("FAIL: %s (строка %d)\n", msg, __LINE__); \
        failures++; \
    } \
} while (0)

/* b64-кодировщик для теста (дистрибутивная форма payload'ов) */
static void b64enc(const char *in, char *out)
{
    static const char A[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                            "abcdefghijklmnopqrstuvwxyz0123456789+/";
    int len = (int)strlen(in);
    int o = 0;
    for (int i = 0; i < len; i += 3) {
        int b0 = (u8)in[i];
        int b1 = (i + 1 < len) ? (u8)in[i + 1] : 0;
        int b2 = (i + 2 < len) ? (u8)in[i + 2] : 0;
        out[o++] = A[b0 >> 2];
        out[o++] = A[((b0 & 3) << 4) | (b1 >> 4)];
        out[o++] = (i + 1 < len) ? A[((b1 & 15) << 2) | (b2 >> 6)] : '=';
        out[o++] = (i + 2 < len) ? A[b2 & 63] : '=';
    }
    out[o] = 0;
}

static void test_b64(void)
{
    char enc[256], dec[128];
    const char *samples[] = {
        "", "f", "fo", "foo", "foob", "fooba", "foobar",
        "{\"v\":1,\"t\":\"input\",\"id\":\"step\"}",
        "Кириллица UTF-8 — 2 байта на символ",
    };
    for (int i = 0; i < (int)(sizeof(samples) / sizeof(samples[0])); i++) {
        b64enc(samples[i], enc);
        int n = brjs_b64dec(enc, (int)strlen(enc), dec, (int)sizeof(dec) - 1);
        CHECK(n == (int)strlen(samples[i]), "b64: длина");
        if (n >= 0) {
            dec[n] = 0;
            CHECK(strcmp(dec, samples[i]) == 0, "b64: содержимое");
        }
    }
    /* URL-безопасный алфавит */
    int n = brjs_b64dec("a-b_", 4, dec, (int)sizeof(dec));
    CHECK(n == 3, "b64: url-алфавит");
    CHECK(brjs_b64dec("!!!", 3, dec, (int)sizeof(dec)) == -1, "b64: мусор");
}

static void test_extract_fenced(void)
{
    static const char md[] =
        "# Демо\n"
        "\n"
        "Текст перед.\n"
        "\n"
        "```reader-input id=step widget=number label=\"Шаг\" default=2\n"
        "```\n"
        "\n"
        "```reader-script id=inc trigger=click:go\n"
        "let n = 0;\n"
        "reader.out(\"o\", String(n));\n"
        "```\n"
        "\n"
        "Текст после.\n";

    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[1024];
    memcpy(buf, md, sizeof(md));
    int len = brjs_extract(&js, buf, (int)sizeof(md) - 1, NULL);
    buf[len] = 0;

    CHECK(js.nw == 1, "fenced: 1 input");
    CHECK(js.ns == 1, "fenced: 1 script");
    CHECK(js.norder == 1, "fenced: в очереди только виджеты (скрипты \
безпозиционны)");
    CHECK(js.w[0].kind == BRJS_W_NUMBER, "fenced: вид number");
    CHECK(strcmp(js.w[0].id, "step") == 0, "fenced: id=step");
    CHECK(strcmp(js.w[0].label, "Шаг") == 0, "fenced: label из кавычек");
    CHECK(strcmp(js.w[0].value, "2") == 0, "fenced: default=2");
    CHECK(strcmp(js.w[0].bind, "step") == 0, "fenced: bind по умолчанию = id");
    CHECK(strcmp(js.s[0].trigger, "click:go") == 0, "fenced: trigger");
    CHECK(js.s[0].code && strstr(js.s[0].code, "reader.out"), "fenced: тело скрипта");

    /* в md не осталось разметки, зато есть якоря \003 */
    CHECK(strstr(buf, "reader-input") == NULL, "fenced: блок вырезан");
    CHECK(strstr(buf, "let n = 0") == NULL, "fenced: код вырезан");
    CHECK(strchr(buf, '\003') != NULL, "fenced: якорь стоит");
    CHECK(strstr(buf, "Текст перед") && strstr(buf, "Текст после"),
          "fenced: текст сохранён");

    /* лейаут: привяжем виджет к строке якоря вручную */
    brl_list_t L;
    memset(&L, 0, sizeof(L));
    {
        int li2 = 0, pos2 = 0;
        while (pos2 < len) {
            char *nl = strchr(buf + pos2, '\n');
            int llen2 = nl ? (int)(nl - (buf + pos2)) : len - pos2;
            if (llen2 == 1 && buf[pos2] == '\003') {
                js.w[0].src_line = li2;   /* первый якорь = виджет 0 */
                break;
            }
            li2++;
            pos2 = nl ? (int)(nl - buf) + 1 : len;
        }
    }
    brl_wrap(buf, len, 40, &L);
    brjs_layout(&js, &L);
    int anchors = 0;
    for (int i = 0; i < L.nlines; i++)
        if (L.cls[i] == BRL_CLS_WID) anchors++;
    CHECK(anchors >= 1, "лейаут: якорная строка помечена WID");
    brl_free(&L);
    brjs_page_reset(&js);
}

static void test_extract_payload(void)
{
    /* base64-payload "t":"script" в дистрибутивной форме: без движка виджет не
     * создаётся, НО anchor ставится и payload копится (nraw). */
    const char *json = "{\"v\":1,\"t\":\"input\",\"id\":\"step\","
                       "\"widget\":\"number\",\"label\":\"Шаг\",\"default\":1}";
    char b64[256];
    b64enc(json, b64);

    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[1024];
    int n = snprintf(buf, sizeof(buf),
                     "# T\n\n<!--@r:%s-->\n\nхвост\n", b64);
    int len = brjs_extract(&js, buf, n, NULL);
    buf[len] = 0;

    CHECK(js.nraw == 1, "payload: накоплен");
    CHECK(js.nraw == 1 && js.raw[0].json &&
          strstr(js.raw[0].json, "\"step\"") != NULL,
          "payload: декодирован");
    CHECK(strstr(buf, "base64") == NULL && strstr(buf, "@r:") == NULL,
          "payload: комментарий вырезан");
    CHECK(strchr(buf, '\003') != NULL, "payload: якорь стоит");
    CHECK(strstr(buf, "хвост") != NULL, "payload: текст после цел");
    brjs_page_reset(&js);
}

static void test_inline_ignored(void)
{
    /* НЕ standalone-комментарий: payload НЕ в очередь, комментарий вырезан */
    const char *json = "{\"v\":1,\"t\":\"input\",\"id\":\"x\"}";
    char b64[256];
    b64enc(json, b64);

    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[512];
    int n = snprintf(buf, sizeof(buf), "строка с <!--@r:%s--> внутри\n", b64);
    int len = brjs_extract(&js, buf, n, NULL);
    buf[len] = 0;
    CHECK(js.nraw == 0, "inline: не в очередь");
    CHECK(js.norder == 0, "inline: нет якоря");
    CHECK(strstr(buf, "@r:") == NULL, "inline: комментарий вырезан");
    CHECK(strstr(buf, "строка с  внутри") != NULL, "inline: текст цел");
    brjs_page_reset(&js);
}

static void test_meta_and_frontmatter(void)
{
    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[512];
    int n = snprintf(buf, sizeof(buf),
                     "---\nreader:\n  version: 1\n---\n# Заголовок\n"
                     "[//]: # (метаданные)\nтекст\n");
    int len = brjs_extract(&js, buf, n, NULL);
    buf[len] = 0;
    CHECK(strstr(buf, "reader:") == NULL, "fm: скрыт");
    CHECK(strstr(buf, "метаданные") == NULL, "ref-style: скрыт");
    CHECK(strstr(buf, "# Заголовок") != NULL, "fm: текст цел");
    CHECK(strstr(buf, "текст") != NULL, "ref: текст цел");
    brjs_page_reset(&js);
}

static void test_code_fence_protected(void)
{
    /* <!--@r:...--> ВНУТРИ обычного ```-блока не извлекается */
    const char *json = "{\"v\":1,\"t\":\"input\",\"id\":\"x\"}";
    char b64[256];
    b64enc(json, b64);

    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[512];
    int n = snprintf(buf, sizeof(buf),
                     "```js\n<!--@r:%s-->\n```\n", b64);
    int len = brjs_extract(&js, buf, n, NULL);
    buf[len] = 0;
    CHECK(js.nraw == 0, "fence: payload защищён");
    CHECK(strstr(buf, "@r:") != NULL, "fence: пример не тронут");
    brjs_page_reset(&js);
}

static void test_select_and_check(void)
{
    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[512];
    int n = snprintf(buf, sizeof(buf),
        "```reader-input id=t widget=select label=\"Тема\" "
        "options=\"dark,light,auto\" default=light\n"
        "```\n"
        "```reader-input id=c widget=checkbox label=\"Согласен\" default=true\n"
        "```\n");
    brjs_extract(&js, buf, n, NULL);
    CHECK(js.nw == 2, "select/check: 2 виджета");
    CHECK(js.w[0].kind == BRJS_W_SELECT && js.w[0].noptions == 3,
          "select: 3 варианта");
    CHECK(js.w[0].sel == 1 && strcmp(js.w[0].value, "light") == 0,
          "select: default=light выбран");
    CHECK(js.w[1].kind == BRJS_W_CHECK && js.w[1].value[0] == '1',
          "check: default=true");
    /* переключения */
    brjs_apply_action(&js, &js.w[0], BRJS_ACT_CYCLE);
    CHECK(strcmp(js.w[0].value, "auto") == 0, "select: цикл вперёд");
    brjs_apply_action(&js, &js.w[1], BRJS_ACT_TOGGLE);
    CHECK(js.w[1].value[0] == '0', "check: снят");
    brjs_set_value(&js, "t", "dark");
    CHECK(strcmp(js.w[0].value, "dark") == 0, "set_value: select по значению");
    int type = -1;
    char v[BRJS_VALUE_MAX];
    CHECK(brjs_get_value(&js, "c", v, (int)sizeof(v), &type) && type == 2,
          "get_value: тип bool");
    CHECK(brjs_get_value(&js, "нет", v, (int)sizeof(v), &type) == 0,
          "get_value: нет такого");
    brjs_page_reset(&js);
}

static void test_output_widget(void)
{
    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[256];
    int n = snprintf(buf, sizeof(buf),
        "```reader-input id=o widget=output label=\"Вывод\"\n```\n");
    brjs_extract(&js, buf, n, NULL);
    CHECK(js.nw == 1 && js.w[0].kind == BRJS_W_OUTPUT, "output: создан");
    brjs_set_output(&js, "o", "строка1\nстрока2\nстрока3", -1);
    CHECK(js.w[0].rows == 0, "output: rows считает лейаут");
    CHECK(brjs_widget_rows(&js.w[0]) == 3, "output: 3 строки");
    CHECK(js.layout_dirty, "output: dirty выставлен");
    brjs_set_output(&js, "", "второй", -1);  /* без id — первый output */
    CHECK(strcmp(js.w[0].out, "второй") == 0, "output: запись без id");
    brjs_page_reset(&js);
}

static void test_quotes_and_escapes(void)
{
    /* JS-код с "-->" и "<!--" внутри payload — base64 спасает от
     * досрочного закрытия комментария (главная причина кодирования) */
    const char *json = "{\"v\":1,\"t\":\"script\",\"id\":\"d\","
                       "\"trigger\":\"load\",\"code\":\"if (a-- > b) {}\"}";
    char b64[256];
    b64enc(json, b64);
    CHECK(strchr(b64, '-') == NULL && strchr(b64, '<') == NULL,
          "b64: нет опасных символов");

    brjs_page_t js;
    memset(&js, 0, sizeof(js));
    char buf[512];
    int n = snprintf(buf, sizeof(buf), "<!--@r:%s-->\n", b64);
    brjs_extract(&js, buf, n, NULL);
    CHECK(js.nraw == 1 && js.raw[0].json &&
          strstr(js.raw[0].json, "a-- > b") != NULL,
          "payload: '-->' внутри пережил транспорт");
    brjs_page_reset(&js);
}

/* --- СЕССИЯ 66: формы — urlenc и сборка query --- */
static void test_form_query(void)
{
    brjs_page_t js;
    char q[256];
    memset(&js, 0, sizeof(js));

    int wu = brjs_widget_alloc(&js);
    js.w[wu].kind = BRJS_W_TEXT;
    strcpy(js.w[wu].id, "user");
    strcpy(js.w[wu].bind, "user");
    strcpy(js.w[wu].form, "login");
    strcpy(js.w[wu].value, "иван");

    int wp = brjs_widget_alloc(&js);
    js.w[wp].kind = BRJS_W_CHECK;
    strcpy(js.w[wp].id, "save");
    strcpy(js.w[wp].form, "login");
    js.w[wp].value[0] = '1';
    js.w[wp].value[1] = 0;

    int wb = brjs_widget_alloc(&js);
    js.w[wb].kind = BRJS_W_BUTTON;
    strcpy(js.w[wb].id, "go");
    strcpy(js.w[wb].form, "login");

    int w2 = brjs_widget_alloc(&js);
    js.w[w2].kind = BRJS_W_TEXT;
    strcpy(js.w[w2].id, "other");
    strcpy(js.w[w2].form, "f2");
    strcpy(js.w[w2].value, "x");

    int n = brjs_form_query(&js, "login", q, (int)sizeof(q));
    CHECK(n > 0, "form query построен");
    CHECK(strcmp(q,
          "user=%D0%B8%D0%B2%D0%B0%D0%BD&save=1") == 0,
          "form query: порядок+кодировка, кнопка и чужая форма вне");

    char e[32];
    brjs_urlenc("a b&c=d/e", e, (int)sizeof(e));
    CHECK(strcmp(e, "a%20b%26c%3Dd%2Fe") == 0, "urlenc спецсимволов");
    brjs_urlenc("ok-._~", e, (int)sizeof(e));
    CHECK(strcmp(e, "ok-._~") == 0, "urlenc безопасные без изменений");
    brjs_page_reset(&js);
}

int main(void)
{
    test_b64();
    test_extract_fenced();
    test_extract_payload();
    test_inline_ignored();
    test_meta_and_frontmatter();
    test_code_fence_protected();
    test_select_and_check();
    test_output_widget();
    test_quotes_and_escapes();
    test_form_query();
    if (failures == 0) {
        printf("test_brjs: ВСЕ ТЕСТЫ ПРОЙДЕНЫ\n");
        return 0;
    }
    printf("test_brjs: %d провалов\n", failures);
    return 1;
}
