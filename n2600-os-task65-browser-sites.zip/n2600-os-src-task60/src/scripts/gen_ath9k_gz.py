#!/usr/bin/env python3
"""gen_ath9k_gz.py — генерация ath9k_ini_data.h со СЖАТЫМИ ini-таблицами.

21 массив `static const u32 name[][cols]` (~26КБ runtime) сжимаются в один
gzip-блоб (~7.5КБ). Вместо массивов заголовок определяет метаданные:
    #define <имя>__off   <слово-оффсет в распакованном буфере>
    #define <имя>__rows  <строк>
    #define <имя>__ncols <колонок>
Макрос INI_WRITE в ath9k_wifi.c склеивает токены (arr##__off и т.д.) и
читает таблицу из распакованного буфера ath9k_ini_plain[] (.bss).
Распаковка — gz_inflate_gzip() один раз при старте ath9k-драйвера.

Запуск: python3 scripts/gen_ath9k_gz.py
"""
import gzip, io, os, re, struct, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INI_H = os.path.join(BASE, "src", "ath9k_ini_data.h")

def read_arrays():
    """[(name, cols, [words...])] в порядке объявления."""
    text = open(INI_H, encoding='utf-8', errors='replace').read()
    pat = re.compile(r'static const u32\s+(\w+)\[\]\[(\d)\]\s*=\s*\{(.*?)\};', re.S)
    out = []
    for m in pat.finditer(text):
        name, cols_s, body = m.group(1), m.group(2), m.group(3)
        cols = int(cols_s)
        nums = re.findall(r'0[xX][0-9a-fA-F]+|\b\d{1,10}\b', body)
        assert len(nums) % cols == 0, f"{name}: {len(nums)} значений не кратно {cols}"
        words = [int(v, 0) & 0xFFFFFFFF for v in nums]
        # строки все длиной cols
        for r in range(0, len(words), cols):
            row = words[r:r + cols]
            # первый элемент каждой строки — адрес регистра (не 0xffffffff)
            assert row[0] != 0xFFFFFFFF, f"{name}: строка {r//cols} — мусорный адрес"
        out.append((name, cols, words))
    assert len(out) == 21, f"ожидалось 21 массивов, найдено {len(out)}"
    return out

def gz9(data):
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', compresslevel=9, mtime=0) as f:
        f.write(data)
    return buf.getvalue()

def main():
    arrays = read_arrays()
    stream = b"".join(struct.pack("<%dI" % len(w), *w) for _, _, w in arrays)
    total_words = sum(len(w) for _, _, w in arrays)
    gzb = gz9(stream)

    L = []
    w = L.append
    w('/* ath9k_ini_data.h — НАСТОЯЩИЕ init-значения Atheros ath9k.')
    w(' *')
    w(' * Извлечены из Linux (GPLv2), drivers/net/wireless/ath/ath9k/:')
    w(' *   ar9002_initvals.h, ar9485_initvals.h, ar9330_1p1_initvals.h')
    w(' * скриптом scripts/gen_ath9k_ini.py; сжаты scripts/gen_ath9k_gz.py.')
    w(' * НЕ редактировать вручную: значения проверены по исходникам')
    w(' * эталонного драйвера.')
    w(' *')
    w(' * [GZIP-INI] (Task 63): таблицы хранятся ОДНИМ gzip-блобом:')
    w(' *   %d -> %d байт (экономия %d байт kernel.bin).' % (total_words * 4, len(gzb), total_words * 4 - len(gzb)))
    w(' * Распаковка один раз в ath9k_ini_plain[] (.bss) при старте')
    w(' * драйвера — ath_ini_ready() (ath9k_wifi.c, перед ath_bringup).')
    w(' * Вместо массивов — метаданные таблицы: __off/__rows/__ncols.')
    w(' * Макрос INI_WRITE (ath9k_wifi.c) склеивает токены и обращается')
    w(' * к буферу; формат строк { reg, val[, col1..col4] } прежний:')
    w(' * 5-колоночные массивы: колонка 4 = 2.4 ГГц HT20 (наш режим). */')
    w('#ifndef ATH9K_INI_DATA_H')
    w('#define ATH9K_INI_DATA_H')
    w('')
    w('#include "types.h"')
    w('')
    w('/* буфер распаковки и блоб объявлены в ath9k_wifi.c / здесь */')
    w('#define ATH_INI_WORDS   %du   /* u32-слов в распакованном буфере */' % total_words)
    w('#define ATH_INI_GZ_SIZE %du   /* сжатый блоб (gzip -9) */' % len(gzb))
    w('extern u32 ath9k_ini_plain[];    /* определён в ath9k_wifi.c */')
    w('')
    for name, cols, words in arrays:
        off_words = sum(len(x[2]) for x in arrays[:[x[0] for x in arrays].index(name)])
        w('/* %s: %d строк x %d колонок, оффсет %d слов */'
          % (name, len(words) // cols, cols, off_words))
        w('#define %s__off   %du' % (name, off_words))
        w('#define %s__rows  %du' % (name, len(words) // cols))
        w('#define %s__ncols %du' % (name, cols))
    w('')
    w('/* сжатые ini-таблицы (gzip -9, порядок == порядок метаданных): */')
    w('static const u8 ath9k_ini_gz[ATH_INI_GZ_SIZE] = {')
    for i in range(0, len(gzb), 20):
        w('    ' + ','.join('0x%02x' % b for b in gzb[i:i + 20]) + ',')
    w('};')
    w('')
    w('#endif /* ATH9K_INI_DATA_H */')

    open(INI_H, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print(f"ath9k_ini_data.h: {total_words*4} -> {len(gzb)} байт gzip (экономия {total_words*4-len(gzb)})")
    return 0

if __name__ == "__main__":
    sys.exit(main())
