#!/bin/sh
# N2600-OS: сборка ядра (Linux/macOS).
# Использует тот же MinGW-тулчейн, что и Windows (i686-w64-mingw32-*),
# а при его отсутствии — системный gcc -m32.
set -e
cd "$(dirname "$0")"

if command -v i686-w64-mingw32-gcc >/dev/null 2>&1; then
    CC=i686-w64-mingw32-gcc
    OBJCOPY=i686-w64-mingw32-objcopy
elif command -v gcc >/dev/null 2>&1; then
    CC=gcc
    OBJCOPY=objcopy
else
    echo "Не найден компилятор (нужен i686-w64-mingw32-gcc или gcc)" >&2
    exit 1
fi
echo "Использую: $CC"

CFLAGS="-m32 -march=i686 -mtune=atom \
-mno-sse -mno-sse2 -mno-mmx -mno-3dnow -mno-sse3 -mno-ssse3 -mno-avx \
-ffreestanding -fno-pic -fno-pie -fno-stack-protector \
-fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe \
-O2 -Wall -Wextra -Isrc"
# [CPUID-SIMD] baseline: -march=i686 + -mno-* ГАРАНТИРУЕТ, что компилятор
# не вставит SIMD-инструкции в произвольную функцию (иначе первый же тик
# таймера терял бы xmm-состояние, а старые CPU получали бы #UD).
# SIMD живёт ТОЛЬКО в функциях с __attribute__((target("sse2"))) (fb.c)
# и в явно выписанном inline-asm (fxsave/fxrstor в task.c, cpu.c).

# [WIFI-DBG-GATE] (Task 43): полевая отладка WiFi/DHCP — по умолчанию
# ВЫКЛЮЧЕНА. Включение: WIFI_DEBUG=1 sh build.sh (или -DWIFI_DEBUG=1).
# Подробности: комментарий [WIFI-DBG-GATE] в src/wifi_core.h.
if [ "$WIFI_DEBUG" = "1" ]; then
    CFLAGS="$CFLAGS -DWIFI_DEBUG=1"
    echo "Полевая отладка WiFi: ВКЛЮЧЕНА (WIFI_DEBUG=1)"
fi

mkdir -p build

echo "[1/3] Компиляция..."
for f in src/*.c; do
    # MicroQuickJS (src/mquickjs.c, ~28k строк амальгамации) собирается с
    # -Os: экономит ~60 КиБ в kernel.bin (важно для in-place обновления
    # os.iso через scripts/update_iso.py), скорость интерпретатора
    # практически не меняется (hot loop и так компактен).
    # -w для mquickjs.c: вендорский амальгамат (fdlibm + ~200 стандартных
    # сигнатур builtin'ов) даёт сотни -Wunused-parameter/-Wsign-compare —
    # подавляем на уровне сборки, наш glue (mquickjs_api.c) остаётся чистым.
    EXTRA="-Os"
    case "$f" in
        */mquickjs.c) EXTRA="-Os -w" ;;
        */mquickjs_api.c) ;;
        */foxen-flac.c) EXTRA="-DNDEBUG" ;;
        *) EXTRA="" ;;
    esac
    echo "  CC $f"
    $CC $CFLAGS $EXTRA -c "$f" -o "build/$(basename "${f%.c}").o"
done

echo "[2/3] Линковка..."
# -no-pie: gcc по умолчанию линкует PIE — появляются .rel.dyn/.dynamic,
# и абсолютные адреса остаются НЕприменёнными релокациями (для bare-metal
# ядра это ломает указатели: релокации некому применять).
$CC -m32 -nostdlib -no-pie -Wl,-T,linker.ld -Wl,--image-base=0x100000 \
    -o build/kernel.tmp.exe build/*.o

echo "[3/3] Плоский бинарник..."
# --only-section=.text: в .bss лежат статические пулы (~1 МиБ) — их НЕ нужно
# писать в файл: GRUB обнуляет bss сам по AOUT_KLUDGE (bss_end_addr в
# multiboot-заголовке). Без флага objcopy раздувает kernel.bin нулями.
$OBJCOPY -O binary --only-section=.text build/kernel.tmp.exe kernel.bin

echo "[OK] Готово: kernel.bin"

# Task 64 [MEM-DIAG]: карта символов для разбора dmesg-отчётов
# («вызов из 0x0010abcd» в [mem] строках ищется здесь: nm -n)
if command -v nm >/dev/null 2>&1; then
    nm -n build/kernel.tmp.exe > build/kernel.map 2>/dev/null || true
    echo "[OK] Карта символов: build/kernel.map"
fi

# --- собственный загрузчик (дискета / HDD-суперфлоппи / раздел) ---
# GRUB-путь (os.iso через makeiso.sh) работает как раньше и не зависит
# от этого шага. Загрузчик собирается binutils'ом (as/ld есть в MinGW).
if sh boot/build_boot.sh; then
    sh boot/mkfloppy.sh kernel.bin floppy.img || true
    sh boot/mkhdd.sh raw  kernel.bin n2600-raw.img  8 || true
else
    echo "[!] boot/binutils недоступны - загрузчик пропущен (GRUB-путь работает)"
fi
