# PATCHES.md — патчи поверх task55-fixed (сессия от 2026-10-29)

## 1. FIX [TLS-ANCHORS]: handshake failed (engine err 62)

**Причина.** Err 62 = `BR_ERR_X509_NOT_TRUSTED`: валидатор X.509 не строил
цепочку до доверенного корня. В `src/tls_anchors.h` было всего **9** корней
(Amazon 1, DigiCert G2, GTS R1/R4, GlobalSign ECC R5, ISRG X1/X2,
Microsoft RSA 2017, SSL.com ECC 2022). Сайты, чьи цепочки уходят в другие
корни, не проходили рукопожатие вовсе: воспроизведено хост-тестом
(tls_tools/tlstest_online.c) на живых серверах — **ya.ru** (цепочка
GlobalSign GCC E46 2025 -> GlobalSign Root E46), **github.com** (Sectigo
Public Server Authentication CA DV E36 -> Sectigo Root E46),
**apple.com** — все давали ровно `err 62` со старым набором и проходят
с новым.

**Что сделано.**
- `tls_tools/gen_tls_anchors.py` переписан: самодостаточный
  (python3 + cryptography, brssl/openssl не нужны), читает
  Mozilla CA bundle (https://curl.se/ca/cacert.pem) и
  `tls_tools/extra_roots/*.pem`, пропускает просроченные/не CA,
  дедуплицирует, выводит совместимый формат (TA{i}_DN/TA{i}_RSA_N/
  TA{i}_RSA_E/TA{i}_EC_Q + TAs[]).
- Новый `src/tls_anchors.h`: **120 якорей** (полный Mozilla-набор
  2026-10-29). Размер исходника ~397 КиБ, в kernel.bin +~55 КиБ.
- `tls_tools/extra_roots/` — корни, УДАЛЁННЫЕ из Mozilla-бандла, но
  валидные и всё ещё раздаваемые сайтами (добавлены в набор):
  **DigiCert Global Root CA** (до 2031), **DigiCert High Assurance
  EV Root CA** (до 2031). Без них не валидируются классические
  DigiCert-цепочки (много .gov/.edu/банков).
- `src/net_tls.c`: PINNED-дата fallback'а CMOS обновлена (2026-10-29).
- Проверка на живых серверах (хост-тест, тот же якорный файл и движок,
  что в ядре): ya.ru, google, github, wikipedia, cloudflare, microsoft,
  apple, vk.com, mail.ru, dzen.ru, music.yandex.ru, belpost.by,
  onliner.by, cdn.jsdelivr.net — handshake OK.

Остаются непокрытыми (осознанно): корни, удалённые Mozilla из-за
комплаенса (Entrust — дистраст 2024), просроченные (Baltimore —
истёк 2025-05-12) и российские ГОСТ-цепочки (GOST-наборы — BearSSL их
не умеет; для них нужен отдельный движок).

## 2. [BR-TLSUP]+[BR-SLASH]: авто-переход http->https и слеши

apps_browser.c:

- **[BR-TLSUP]** авто-повтор запроса через HTTPS (порт 443), один на
  переход (loopback не переключается — локальный httpd не умеет TLS).
  Триггеры расширены по сравнению с сессией 58:
  (a) сетевой отказ на :80 — `connection refused/reset`,
      `connect timeout`, **`response timeout`**, **`пустой ответ`**
      (раньше — только первые два);
  (b) сервер ОТВЕТИЛ на plain http кодом **400/403/426** — сайт жив,
      но только по TLS (nginx «plain HTTP request was sent to HTTPS
      port» = 400, Cloudflare-заглушки 403, RFC 2817 = 426);
  (c) 301/302/303/307/308 с `Location: https://...` следуются и так
      (сессия 56) — глубина цепочки общая (до 4).
  Понижения https->http нет.
- `br_http_status()` — общий парсер кода статуса (для
  br_parse_redirect и (b)).
- **[BR-SLASH]** хост обрезается и на `?`: `http://ya.ru?x=1` раньше
  склеивал query с хостом (DNS-запрос `ya.ru?x=1` не резолвился).
  Путь всегда начинается с `/`: голый хост -> `/` (как было),
  `?query` после хоста -> `/?query` (как Location без пути).

## 3. FIX [BR-LONGPAGE]: обрезание длинных страниц

Длинные страницы обрезались в ТРЁХ местах (текст терялся молча):

| Лимит | Было | Стало | Где |
|---|---|---|---|
| HTTP-ответ целиком (заголовки+тело) | 16 КиБ (`BR_FETCH_MAX`) | 256 КиБ | apps_browser.c |
| Выход HTML->Markdown (`html_to_md` честно останавливается на `md_max`) | всегда 8 КиБ (`BR_MD_MAX`) | `len*2 + 8 КиБ` для HTML | apps_browser.c |
| Не-HTML текст / файл RAM disk / хранение исходника для Save | 64 КиБ (`BR_FILE_MAX`) | 256 КиБ | apps_browser.c |
| Картинок на страницу (`BRP_MAX_IMGS`) | 12 | 24 | brpage.h |
| Ссылок на страницу (`BRP_MAX_LINKS`) | 48 | 128 | brpage.h |

Память: пиково ~1,8 МиБ на загрузку страницы 256 КиБ (resp + md-буфер +
store + src + строки отображения), всё освобождается; куча 512 МиБ.
imgsvc и раньше грузил картинки по 512 КиБ (`IMG_FETCH_MAX`).

Дополнительно: убран дубль объявления `static fb_ctx_t fb_recs[...]`
в fb.c (строки 55-56 исходника) — ошибка компиляции, task55-fixed
в таком виде не собирался.

## 4. [CPUID-SIMD]: трёхуровневый CPUID-диспетчер

- **Уровень 0** (нет SSE — Pentium MMX/K6-2): всё как раньше, скаляр +
  `rep stosl`. Ничего не ломается.
- **Уровень 1** (SSE, нет SSE2 — PII/PIII): fxsave/fxrstor в планировщике.
- **Уровень 2** (SSE2+ — Pentium 4/Core/Atom N2600): movdqa/movntdq.

Новые файлы: `src/cpu.c`, `src/cpu.h`.

- `cpu_detect()` вызывается в kmain ДО fb_init (видно в dmesg/serial:
  `[cpu] fpu=1 fxsr=1 sse=1 sse2=1 — уровень 2 (SSE2)`).
- `cpu_fpu_enable()` ставит CR0.EM/TS=0, MP/ET=1 и CR4.OSFXSR|OSXMMEXCPT —
  на BSP (cpu_detect) И на каждом AP (smp_ap_main; CR4 per-CPU, после
  INIT у AP сброшен — без этого movntdq/fxrstor на AP получили бы #UD).
- **fb.c**: `fill32_sse2` (средние n, 32<=n<4096; большие — rep stosl),
  `copy_row_sse2` (fb_blit_bg / fb_blit_to_screen / fb_sync_back),
  `blit_row_wc_sse2` с **movntdq** в LFB в `fb_flush_rects` (32bpp) —
  WC-буферы LFB (mtrr_lfb_wc) теперь реально используются; `sfence`
  ОДИН на пачку прямоугольников.
- **task.c**: FPU/x87/XMM-состояние сохраняется при переключении задач —
  `fpu_state[512] __attribute__((aligned(16)))` в TCB,
  `fxsave/fxrstor` (CPU с FXSR) либо `fnsave/frstor` (x87 без FXSR),
  ничего — CPU без FPU. Раньше состояние НЕ сохранялось вовсе: любая
  задача с float портила FPU-состояние соседей (латентный баг, см.
  комментарий в fb_blit_rgba). fnsave НЕ вызывается при next==cur
  (он реинициализирует FPU). Переиспользованный слот задачи получает
  `fpu_init=0`; первое исполнение — дефолтное состояние (fninit +
  MXCSR=0x1F80) из cpu.c, иначе fxrstor нулевого образа дал бы #GP.
- **ISR не трогали**: с `-mno-sse` ни один обработчик не использует xmm —
  единственная точка сохранения состояния — планировщик.
- **Compile-time baseline**: `-march=i686 -mno-sse -mno-sse2 -mno-mmx
  -mno-3dnow -mno-sse3 -mno-ssse3 -mno-avx` в build.sh И build.bat —
  компилятор не вставит SIMD никуда, кроме функций с
  `__attribute__((target("sse2")))` (fb.c) и явного inline-asm.
  Проверено дизассемблированием: xmm-инструкции только в
  fill32_sse2/copy_row_sse2/blit_row_wc_sse2 + sfence в fb_flush_rects.
- MMX сознательно не тянется (emms в горячем пути, штраф переключений).
- **Профилирование**: `-DWM_PROFILE` (обе сборки) — fb_flush_rects и
  fb_blit_bg каждые 512 вызовов печатают среднее в тиках в serial/dmesg.


## 5. Task 58: Sysinfo "(sse2)" + 8 фиксов FAT32/fileman

- **[SYSINFO-SSE2]** gfx2d.c: строка GPU показывает уровень SIMD
  («(WC: да, sse2)»; VESA-ветка — «(sse2)»/«(скаляр)»).
- **[FAT32-CLSTFIX]** fat32.c: total_clusters = (total − data_start)/spc —
  раньше завышение давало запись за пределы FAT1/тома при заполнении диска
  (критично, проверено хост-тестом: старый код пишет за конец образа).
- **[FAT-LFN40]** fat32.c: 0x40 только на первой LFN-записи — совместимость
  каталогов с Windows/Linux (критично).
- **[FMT-OOB]** fat32_format.c: fmt_write_span удалена (OOB-чтение
  512-байтного буфера — ASan global-buffer-overflow), вызовы заменены на
  fmt_zero_span.
- **[FMT-DEINIT]** fat32_format.c: снятие монтирования до форматирования.
- **[FM-VIEWERISO]** fileman.c: sizeof(viewer_t) в viewer_open_iso.
- **[FM-VOLBTN]** fileman.c: сброс depth при смене тома кнопкой.
- **[FAT-LEAK]** fat32.c: откат кластеров при I/O-ошибке роста каталога
  (find_free_slots, alloc_chain).
- **[FAT-SAFEWRITE]** fat32.c: новая цепочка файла выделяется до
  освобождения старой.
- Хост-тест: **scripts/fathost/run.sh** — 29/29 на реальных исходниках
  (ASan/UBSan); регрессия на старом коде: 4 FAIL + ASan overflow.

## Сборка

`sh build.sh` (Linux) или `build.bat` (Windows) — ядро пересобрано,
`src/kernel.bin` в архиве обновлён (1433128 байт).

## Как проверить выигрыш

- N2600/Real HW: развёрнутое окно (1280x560) — ожидается 1.8-2.5x на
  fb_flush_rects (проверять на железе: QEMU не эмулирует WC полностью).
- Pentium III: уровень 1, копии через SSE — без movntdq.
- Pentium MMX/K6-2: уровень 0, поведение идентично прежнему.
- dmesg: строка `[cpu] ... — уровень N` показывает выбранный путь.
