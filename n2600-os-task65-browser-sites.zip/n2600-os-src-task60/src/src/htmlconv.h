/* htmlconv.h — HTML -> Markdown конвертер N2600-OS.
 *
 * Выделен из apps_browser.c в отдельный модуль:
 *   1) конвертер нужен и браузеру, и терминалу (curl), и хостовому тесту
 *      (scripts/test_htmlconv.c) — единая точка правды;
 *   2) буфер результата передаётся ВЫЗЫВАЮЩИМ (раньше был static char
 *      md[8192] внутри браузера — общий на все окна, см. FIX [H2]).
 *
 * Соглашения:
 *   html_to_md2(html, html_len, md, md_max, *truncated) — все границы
 *   проверяются, результат НЕ выходит за md_max-2, всегда
 *   NUL-терминирован (md[len]=0). Возвращает длину результата. При
 *   нехватке места — обрезка, *truncated (если не NULL) = 1: вызыватель
 *   (браузер) обязан показать «страница обрезана» вместо молчаливой
 *   потери хвоста (FIX [HC-TRUNC], Task 60).
 *   html_to_md(...) — обёртка над html_to_md2 (truncated == NULL).
 *
 * Task 60 [HC-DOM]: разбор входа выполняет html_parser.c (DOM-парсер),
 * htmlconv обходит дерево и выдаёт Markdown/маркеры. Прежние ручные
 * эвристики (сканирование '<', кавычек, комментариев, прыжков через
 * script/style) убраны. Маркерные строки \x01... пишутся АТОМАРНО
 * (строка целиком или никак), блоки \x01SCRIPT/\x01TEXTAREA
 * гарантированно закрываются либо откатываются целиком — «висячих»
 * маркеров больше не бывает (FIX [HC-PAIR], Task 60).
 */
#ifndef HTMLCONV_H
#define HTMLCONV_H

#ifdef __cplusplus
extern "C" {
#endif

int html_to_md(const char *html, int html_len, char *md, int md_max);
int html_to_md2(const char *html, int html_len, char *md, int md_max,
                int *truncated);

#ifdef __cplusplus
}
#endif

#endif /* HTMLCONV_H */
