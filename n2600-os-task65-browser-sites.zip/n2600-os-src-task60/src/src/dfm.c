/* dfm.c — полноэкранный текстовый файловый менеджер для telnet
 * (реализация, Task 48). Адаптация модели dfm (Dylan Araps,
 * dylanaraps/dfm, MIT-2.0) под N2600-OS: сама библиотека dfm
 * рассчитана на POSIX (termios, dirent, арена malloc, SIGWINCH) —
 * здесь её UI-модель воспроизведена над RAM disk и посимвольным
 * telnet-каналом. См. dfm.h (режимы, раскладка, встраивание).
 *
 * Правила строк: все snprintf с размерами, пути — только через
 * dfm_join/dfm_resolve с проверкой вместимости, индексы курсора
 * всегда клампятся к nents. Статические scratch-буферы безопасны:
 * весь модуль обслуживается ТОЛЬКО задачей telnetd (последовательно).
 *
 * Мышь: SGR (1000+1006). Включается на входе в 1/4, гасится в 2/3 и
 * при выходе. Парсер SGR встроен в общую ESC-машину dfm_key.
 * Кликабельные подсказки: help-строки рисуются как [X]-кнопки; при
 * отрисовке регистрируются hotspot-прямоугольники (dfm_btn_t), при
 * SGR-клике — hit-test и синтез клавиши. Полностью пересобираются
 * в dfm_draw / dfm_view_draw.
 * Цвета: ANSI_HDR/ANSI_DIR/ANSI_KEY/ANSI_MSG — для шапки, папок,
 * кнопок, сообщений; выбранная строка — ANSI_REV без цвета. */
#include "dfm.h"
#include "string.h"
#include "mem.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#define ANSI_CLR   "\033[H\033[2J"
#define ANSI_REV   "\033[7m"
#define ANSI_NORM  "\033[0m"
#define ANSI_HDR   "\033[1;32m"   /* заголовок — bold green */
#define ANSI_DIR   "\033[1;34m"   /* каталог — bold blue  */
#define ANSI_KEY   "\033[1;33m"   /* кнопка/клавиша — bold yellow */
#define ANSI_MSG   "\033[33m"     /* сообщение — yellow   */

/* scratch для перечитывания каталога (одна задача telnetd) */
static ramfs_dirent_t dfm_scan_tmp[DFM_ENTS_MAX];
/* буфер сборки экрана (одна задача telnetd) */
static char dfm_draw_buf[4096];

/* ---------------- мелкие утилиты ---------------- */

static void dfm_say(dfm_t *f, const char *s)
{
    if (f->out) f->out(f->ud, s);
}

static void dfm_msg(dfm_t *f, const char *fmt, const char *a, unsigned b)
{
    snprintf(f->msg, sizeof(f->msg), fmt, a, b);
}

static char dfm_lo(char c)
{
    return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
}

/* регистронезависимое сравнение имён (ASCII) */
static int dfm_namecmp(const char *a, const char *b)
{
    while (*a && *b) {
        char ca = dfm_lo(*a), cb = dfm_lo(*b);
        if (ca != cb) return (int)(unsigned char)ca - (int)(unsigned char)cb;
        a++; b++;
    }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

/* dir + "/" + name (ramfs-путь без ведущего слеша). 0 = не влезло. */
static int dfm_join(char *out, int cap, const char *dir, const char *name)
{
    if (!dir[0]) {
        if ((int)strlen(name) >= cap) return 0;
        strcpy(out, name);
        return 1;
    }
    if (snprintf(out, (u32)cap, "%s/%s", dir, name) >= cap) return 0;
    return 1;
}

/* показать путь с ведущим слешем */
static void dfm_show(const char *path, char *out, int cap)
{
    if (!path[0]) snprintf(out, (u32)cap, "/");
    else          snprintf(out, (u32)cap, "/%s", path);
}

/* разрешить arg относительно cwd («.», «..», «/...», «dir/sub») */
static int dfm_resolve(const char *cwd, const char *arg, char *out, int cap)
{
    char acc[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (arg[0] == '/') acc[0] = 0;
    else snprintf(acc, sizeof(acc), "%s", cwd);
    const char *p = arg;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        char comp[DFM_NAME_MAX + 1];
        int ci = 0;
        while (*p && *p != '/' && ci < (int)sizeof(comp) - 1)
            comp[ci++] = *p++;
        comp[ci] = 0;
        if (!strcmp(comp, ".")) continue;
        if (!strcmp(comp, "..")) {
            char *sl = strrchr(acc, '/');
            if (sl) *sl = 0;
            else    acc[0] = 0;
            continue;
        }
        int L = (int)strlen(acc);
        if (L + 1 + ci >= (int)sizeof(acc)) return 0;
        if (L) acc[L++] = '/';
        strcpy(acc + L, comp);
    }
    if ((int)strlen(acc) >= cap) return 0;
    strcpy(out, acc);
    return 1;
}

/* «123» / «12.3К» / «1.2М» (u32 байт; людино-вид, как в dfm view=size) */
static void dfm_hsize(u32 sz, char *out, int cap)
{
    if (sz < 1024u)      snprintf(out, (u32)cap, "%uБ", (unsigned)sz);
    else if (sz < 1024u * 1024u)
        snprintf(out, (u32)cap, "%u.%uК", (unsigned)(sz >> 10),
                 (unsigned)((sz & 1023u) * 10u / 1024u));
    else
        snprintf(out, (u32)cap, "%u.%uМ", (unsigned)(sz >> 20),
                 (unsigned)((sz & (1024u * 1024u - 1u)) * 10u / (1024u * 1024u)));
}

/* видимых строк в просмотрщике (2 шапки + rows) */
static int dfm_view_rows(const dfm_t *f)
{
    int r = f->rows + 2;
    if (r < 4) r = 4;
    return r;
}

/* ---------------- мышь: вкл/выкл (SGR 1000+1006) ---------------- */

static void dfm_mouse_on(dfm_t *f)
{
    if (f->out && f->mouse) f->out(f->ud, "\033[?1000h\033[?1006h");
}

static void dfm_mouse_off(dfm_t *f)
{
    if (f->out && f->mouse) f->out(f->ud, "\033[?1000l\033[?1006l");
}

/* ---------------- каталог: скан, фильтр, сортировка ---------------- */

static int dfm_filter_ok(const dfm_t *f, const ramfs_dirent_t *e)
{
    const char *q = f->filt;
    if (!q[0]) return 1;
    if (*q == '*') {
        q++;
        if (!q[0]) return 1;
        for (const char *n = e->name; *n; n++) {
            const char *a = n, *b = q;
            while (*a && *b && dfm_lo(*a) == dfm_lo(*b)) { a++; b++; }
            if (!*b) return 1;
        }
        return 0;
    }
    for (const char *n = e->name; ; n++, q++) {
        if (!*q) return 1;
        if (!*n) return 0;
        if (dfm_lo(*n) != dfm_lo(*q)) return 0;
    }
}

static void dfm_sort(dfm_t *f)
{
    for (int i = 1; i < f->nents; i++) {
        ramfs_dirent_t key = f->ents[i];
        int j = i - 1;
        while (j >= 0) {
            const ramfs_dirent_t *a = &f->ents[j], *b = &key;
            int c = 0;
            if (a->is_dir != b->is_dir) c = b->is_dir ? 1 : -1;
            else {
                switch (f->sort) {
                case 1:  c = dfm_namecmp(b->name, a->name); break;
                case 2:  c = (a->size < b->size) ? -1 : (a->size > b->size);
                         if (!c) c = dfm_namecmp(a->name, b->name);
                         break;
                case 3:  c = (a->size < b->size) ? 1 : (a->size > b->size);
                         if (!c) c = dfm_namecmp(a->name, b->name);
                         break;
                default: c = dfm_namecmp(a->name, b->name); break;
                }
            }
            if (c <= 0) break;
            f->ents[j + 1] = f->ents[j];
            j--;
        }
        f->ents[j + 1] = key;
    }
}

static void dfm_scan(dfm_t *f)
{
    char keep[DFM_NAME_MAX + 1];
    if (f->y >= 0 && f->y < f->nents)
        snprintf(keep, sizeof(keep), "%s", f->ents[f->y].name);
    else
        keep[0] = 0;

    f->nents = 0;
    if (ramfs_ready()) {
        int n = ramfs_list_dir(f->cwd[0] ? f->cwd : "/",
                               dfm_scan_tmp, DFM_ENTS_MAX);
        for (int i = 0; i < n && f->nents < DFM_ENTS_MAX; i++)
            if (dfm_filter_ok(f, &dfm_scan_tmp[i]))
                f->ents[f->nents++] = dfm_scan_tmp[i];
    }
    dfm_sort(f);

    f->y = 0;
    if (keep[0]) {
        for (int i = 0; i < f->nents; i++)
            if (!strcmp(f->ents[i].name, keep)) { f->y = i; break; }
    }
    if (f->y >= f->nents) f->y = f->nents - 1;
    if (f->y < 0) f->y = 0;
    f->o = f->y - f->rows / 2;
    if (f->o > f->nents - f->rows) f->o = f->nents - f->rows;
    if (f->o < 0) f->o = 0;
    f->del_pending = 0;
}

static const char *dfm_sort_name(u8 s)
{
    switch (s) {
    case 1:  return "имя↓";
    case 2:  return "размер";
    case 3:  return "размер↓";
    default: return "имя";
    }
}

static void dfm_set_msg(dfm_t *f, const char *s)
{
    snprintf(f->msg, sizeof(f->msg), "%s", s ? s : "");
}

/* ---------------- отрисовка: утилиты + help-кнопки ---------------- */

static void dfm_flush(dfm_t *f, char *buf, int *n)
{
    if (*n > 0) {
        buf[*n] = 0;
        dfm_say(f, buf);
        *n = 0;
    }
}

static void dfm_put(dfm_t *f, char *buf, int *n, const char *s)
{
    int L = 0;
    while (s[L]) L++;
    if (*n + L >= (int)sizeof(dfm_draw_buf) - 2) dfm_flush(f, buf, n);
    memcpy(buf + *n, s, (u32)L);
    *n += L;
}

/* видимых колонок в C-строке (UTF-8 codepoints; ANSI-SGR пропускается) */
static int dfm_vislen(const char *s)
{
    int cols = 0, i = 0;
    while (s[i]) {
        unsigned char c = (unsigned char)s[i];
        if (c == 0x1B && s[i + 1] == '[') {
            i += 2;
            while (s[i] && ((unsigned char)s[i] < 0x40 ||
                            (unsigned char)s[i] > 0x7E)) i++;
            if (s[i]) i++;
            continue;
        }
        if ((c & 0xC0) != 0x80) cols++;
        i++;
    }
    return cols;
}

/* Эмитит plain-текст, продвигает *col на видимую ширину */
static void dfm_help_text(dfm_t *f, char *b, int *n, int *col, const char *text)
{
    dfm_put(f, b, n, text);
    *col += dfm_vislen(text);
}

/* Рисует «[label]» в жёлтом, регистрирует hotspot в (row, *col..*col+L+1). */
static void dfm_help_btn(dfm_t *f, char *b, int *n, int row, int *col,
                         char key, const char *label)
{
    int L = (int)strlen(label);
    if (f->nbtn < DFM_BTN_MAX) {
        f->btn[f->nbtn].row = (u16)row;
        f->btn[f->nbtn].col_start = (u16)(*col);
        f->btn[f->nbtn].col_end = (u16)(*col + L + 1);
        f->btn[f->nbtn].key = (u8)key;
        f->nbtn++;
    }
    dfm_put(f, b, n, ANSI_KEY "[");
    dfm_put(f, b, n, label);
    dfm_put(f, b, n, "]" ANSI_NORM);
    *col += L + 2;
}

/* Подсказки обзора (3 строки). help_row — абсолютная 1-based строка
 * первой подсказки; nbtn сбрасывается здесь. */
static void dfm_browse_help(dfm_t *f, char *b, int *n, int help_row)
{
    f->nbtn = 0;
    int col;

    col = 1;                                /* ряд 0 */
    dfm_help_btn(f, b, n, help_row,     &col, 'j',    "j");
    dfm_help_text(f, b, n, &col, " вниз  ");
    dfm_help_btn(f, b, n, help_row,     &col, 'k',    "k");
    dfm_help_text(f, b, n, &col, " вверх  ");
    dfm_help_btn(f, b, n, help_row,     &col, 'g',    "g");
    dfm_help_text(f, b, n, &col, " начало  ");
    dfm_help_btn(f, b, n, help_row,     &col, 'G',    "G");
    dfm_help_text(f, b, n, &col, " конец  ");
    dfm_help_btn(f, b, n, help_row,     &col, '\r',   "Enter");
    dfm_help_text(f, b, n, &col, " открыть  ");
    dfm_help_btn(f, b, n, help_row,     &col, 'h',    "h");
    dfm_help_text(f, b, n, &col, " наверх\n");

    col = 1;                                /* ряд 1 */
    dfm_help_btn(f, b, n, help_row + 1, &col, '/',    "/");
    dfm_help_text(f, b, n, &col, " поиск  ");
    dfm_help_btn(f, b, n, help_row + 1, &col, 's',    "s");
    dfm_help_text(f, b, n, &col, " сорт  ");
    dfm_help_btn(f, b, n, help_row + 1, &col, 'v',    "v");
    dfm_help_text(f, b, n, &col, " вид  ");
    dfm_help_btn(f, b, n, help_row + 1, &col, 'e',    "e");
    dfm_help_text(f, b, n, &col, " правка  ");
    dfm_help_btn(f, b, n, help_row + 1, &col, 'n',    "n");
    dfm_help_text(f, b, n, &col, " новый  ");
    dfm_help_btn(f, b, n, help_row + 1, &col, 'm',    "m");
    dfm_help_text(f, b, n, &col, " каталог  ");
    dfm_help_btn(f, b, n, help_row + 1, &col, 'd',    "d");
    dfm_help_text(f, b, n, &col, " удалить\n");

    col = 1;                                /* ряд 2 */
    dfm_help_btn(f, b, n, help_row + 2, &col, 'r',    "r");
    dfm_help_text(f, b, n, &col, " обновить  ");
    dfm_help_btn(f, b, n, help_row + 2, &col, 'q',    "q");
    dfm_help_text(f, b, n, &col, " выход  ");
    dfm_help_text(f, b, n, &col,
        "(клик=[X] команда, ПКМ=наверх, колесо=листать)");
}

/* Подсказки просмотрщика (1 строка). */
static void dfm_view_help(dfm_t *f, char *b, int *n, int help_row)
{
    f->nbtn = 0;
    int col = 1;
    dfm_help_btn(f, b, n, help_row, &col, 'j',  "j");
    dfm_help_text(f, b, n, &col, " вниз  ");
    dfm_help_btn(f, b, n, help_row, &col, 'k',  "k");
    dfm_help_text(f, b, n, &col, " вверх  ");
    dfm_help_btn(f, b, n, help_row, &col, ' ',  "Space");
    dfm_help_text(f, b, n, &col, " страница  ");
    dfm_help_btn(f, b, n, help_row, &col, 'g',  "g");
    dfm_help_text(f, b, n, &col, " начало  ");
    dfm_help_btn(f, b, n, help_row, &col, 'G',  "G");
    dfm_help_text(f, b, n, &col, " конец  ");
    dfm_help_btn(f, b, n, help_row, &col, 'q',  "q");
    dfm_help_text(f, b, n, &col, " назад");
}

static void dfm_draw(dfm_t *f)
{
    char *b = dfm_draw_buf;
    int n = 0;
    char line[DFM_NAME_MAX + 96];
    char show[DFM_CWD_MAX + 2];

    dfm_put(f, b, &n, ANSI_CLR);
    dfm_show(f->cwd, show, (int)sizeof(show));
    if (f->filt[0])
        snprintf(line, sizeof(line),
                 "dfm %s — %d эл. [сорт: %s | вид: %s] фильтр: %s",
                 show, f->nents, dfm_sort_name(f->sort),
                 f->view ? "имя+размер" : "имя", f->filt);
    else
        snprintf(line, sizeof(line),
                 "dfm %s — %d эл. [сорт: %s | вид: %s]",
                 show, f->nents, dfm_sort_name(f->sort),
                 f->view ? "имя+размер" : "имя");
    dfm_put(f, b, &n, ANSI_HDR);
    dfm_put(f, b, &n, line);
    dfm_put(f, b, &n, ANSI_NORM "\n");
    dfm_put(f, b, &n, "----------------------------------------\n");

    if (f->nents == 0) {
        dfm_put(f, b, &n, "(пусто или фильтр не оставил записей)\n");
    }
    for (int i = f->o; i < f->nents && i < f->o + f->rows; i++) {
        const ramfs_dirent_t *e = &f->ents[i];
        char szs[16];
        dfm_hsize(e->size, szs, (int)sizeof(szs));
        if (f->view == 1 && !e->is_dir) {
            char nm[DFM_NAME_MAX + 4];
            snprintf(nm, sizeof(nm), "%s%s", e->name,
                     e->is_dir ? "/" : "");
            int pad = 40 - (int)strlen(nm);
            int L2 = snprintf(line, sizeof(line), "%s", nm);
            for (int s = 0; s < pad && L2 < (int)sizeof(line) - 1; s++)
                line[L2++] = ' ';
            snprintf(line + L2, sizeof(line) - (u32)L2, "%s", szs);
        } else {
            snprintf(line, sizeof(line), "%s%s",
                     e->name, e->is_dir ? "/" : "");
        }
        if (i == f->y) {
            dfm_put(f, b, &n, ANSI_REV);
            dfm_put(f, b, &n, "> ");
            dfm_put(f, b, &n, line);
            dfm_put(f, b, &n, ANSI_NORM);
        } else {
            if (e->is_dir) dfm_put(f, b, &n, ANSI_DIR);
            dfm_put(f, b, &n, "  ");
            dfm_put(f, b, &n, line);
            if (e->is_dir) dfm_put(f, b, &n, ANSI_NORM);
        }
        dfm_put(f, b, &n, "\n");
    }
    for (int i = f->nents; i < f->o + f->rows; i++)
        dfm_put(f, b, &n, "\n");

    if (f->msg[0]) {
        dfm_put(f, b, &n, ANSI_MSG);
        dfm_put(f, b, &n, f->msg);
        dfm_put(f, b, &n, ANSI_NORM "\n");
    }

    /* help_row: 2 строки шапки + f->rows строк списка (+1 если msg) */
    int help_row = 3 + f->rows + (f->msg[0] ? 1 : 0);
    dfm_browse_help(f, b, &n, help_row);
    dfm_flush(f, b, &n);
}

/* ---------------- действия ---------------- */

static void dfm_move(dfm_t *f, int d)
{
    if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
    int ny = f->y + d;
    if (ny < 0) ny = 0;
    if (ny >= f->nents) ny = f->nents - 1;
    f->y = ny;
    if (f->y < f->o) f->o = f->y;
    if (f->y >= f->o + f->rows) f->o = f->y - f->rows + 1;
    f->del_pending = 0;
    f->msg[0] = 0;
}

static void dfm_top(dfm_t *f)
{
    f->y = 0; f->o = 0;
    f->del_pending = 0;
    f->msg[0] = 0;
}

static void dfm_bottom(dfm_t *f)
{
    if (f->nents > 0) f->y = f->nents - 1;
    f->o = f->nents - f->rows;
    if (f->o < 0) f->o = 0;
    f->del_pending = 0;
    f->msg[0] = 0;
}

static int dfm_up(dfm_t *f)
{
    char *sl = strrchr(f->cwd, '/');
    if (sl) *sl = 0;
    else    f->cwd[0] = 0;
    f->del_pending = 0;
    f->msg[0] = 0;
    dfm_scan(f);
    return 1;
}

static void dfm_view_file(dfm_t *f, const ramfs_dirent_t *e);
static void dfm_view_draw(dfm_t *f);
static void dfm_ed_open_path(dfm_t *f, const char *path);

static void dfm_open(dfm_t *f)
{
    if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
    ramfs_dirent_t *e = &f->ents[f->y];
    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (e->is_dir) {
        if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
            dfm_set_msg(f, "Слишком длинный путь");
            return;
        }
        snprintf(f->cwd, sizeof(f->cwd), "%s", path);
        f->y = 0; f->o = 0;
        f->msg[0] = 0;
        f->del_pending = 0;
        dfm_scan(f);
        return;
    }
    if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
        dfm_set_msg(f, "Слишком длинный путь");
        return;
    }
    dfm_view_file(f, e);
}

/* ---------------- просмотрщик (режим 4) ---------------- */

static u32 dfm_count_lines(const char *b, u32 len)
{
    u32 n = 0;
    for (u32 i = 0; i < len; i++)
        if (b[i] == '\n') n++;
    if (len && b[len - 1] != '\n') n++;
    return n;
}

static void dfm_view_file(dfm_t *f, const ramfs_dirent_t *e)
{
    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
        dfm_set_msg(f, "Слишком длинный путь");
        return;
    }
    if (e->size > DFM_VIEW_MAX) {
        dfm_msg(f, "Файл больше %u КиБ просмотрщик не тянет (e — правка)",
                NULL, (unsigned)(DFM_VIEW_MAX / 1024));
        return;
    }
    char *buf = (char *)malloc(e->size ? e->size : 1);
    if (!buf) { dfm_set_msg(f, "Нет памяти под просмотр"); return; }
    u32 got = ramfs_read(path, buf, e->size ? e->size : 1);
    int binary = 0;
    for (u32 i = 0; i < got && i < 64; i++) {
        u8 c = (u8)buf[i];
        if (c < 32 && c != '\t' && c != '\n' && c != '\r') { binary = 1; break; }
    }
    if (binary) {
        free(buf);
        dfm_msg(f, "%s: двоичный файл (%u байт)", e->name, (unsigned)e->size);
        return;
    }
    if (f->vp) free(f->vp);
    f->vp = buf;
    f->vp_len = got;
    f->vp_top = 0;
    f->vp_lines = dfm_count_lines(buf, got);
    f->vp_binary = 0;
    snprintf(f->vp_path, sizeof(f->vp_path), "%s", path);
    f->mode = 4;
    f->msg[0] = 0;
    dfm_mouse_on(f);
    dfm_view_draw(f);
}

static void dfm_view_close(dfm_t *f)
{
    if (f->vp) { free(f->vp); f->vp = 0; }
    f->vp_len = 0;
    f->vp_top = 0;
    f->vp_lines = 0;
    f->mode = 1;
    f->msg[0] = 0;
    dfm_mouse_on(f);
    dfm_scan(f);
    dfm_draw(f);
}

static int dfm_view_line(const char *b, u32 len, u32 no, u32 *off, u32 *lno)
{
    u32 cur = 0, i = 0;
    while (i < len) {
        if (cur == no) {
            u32 j = i;
            while (j < len && b[j] != '\n') j++;
            *off = i; *lno = j - i;
            return 1;
        }
        while (i < len && b[i] != '\n') i++;
        if (i < len) i++;
        cur++;
    }
    return 0;
}

static void dfm_view_draw(dfm_t *f)
{
    char *b = dfm_draw_buf;
    int n = 0;
    char line[DFM_CWD_MAX + DFM_NAME_MAX + 64];
    char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
    int vr = dfm_view_rows(f);

    dfm_put(f, b, &n, ANSI_CLR);
    dfm_show(f->vp_path, show, (int)sizeof(show));
    u32 last = f->vp_top + (u32)vr;
    snprintf(line, sizeof(line),
             "просмотр %s — строки %u..%u из %u",
             show, (unsigned)(f->vp_top + 1),
             (unsigned)(last < f->vp_lines ? last : f->vp_lines),
             (unsigned)f->vp_lines);
    dfm_put(f, b, &n, ANSI_HDR);
    dfm_put(f, b, &n, line);
    dfm_put(f, b, &n, ANSI_NORM "\n");
    dfm_put(f, b, &n, "----------------------------------------\n");

    /* help_row = 3 (2 шапки) + фактическое число строк контента */
    int help_row = 3;
    for (int r = 0; r < vr; r++) {
        u32 no = f->vp_top + (u32)r;
        u32 off = 0, L = 0;
        if (!dfm_view_line(f->vp, f->vp_len, no, &off, &L)) break;
        if (L > 96) L = 96;
        char seg[100];
        memcpy(seg, f->vp + off, L);
        seg[L] = 0;
        dfm_put(f, b, &n, seg);
        dfm_put(f, b, &n, "\n");
        help_row++;
    }
    dfm_view_help(f, b, &n, help_row);
    dfm_flush(f, b, &n);
}

static void dfm_view_scroll(dfm_t *f, int delta)
{
    int vr = dfm_view_rows(f);
    int maxtop = (int)f->vp_lines - vr;
    int nt = (int)f->vp_top + delta;
    if (maxtop < 0) maxtop = 0;
    if (nt < 0) nt = 0;
    if (nt > maxtop) nt = maxtop;
    if ((u32)nt != f->vp_top) {
        f->vp_top = (u32)nt;
        dfm_view_draw(f);
    }
}

static void dfm_view_key(dfm_t *f, unsigned char b)
{
    switch (b) {
    case 'j': dfm_view_scroll(f, +1); return;
    case 'k': dfm_view_scroll(f, -1); return;
    case ' ':
        dfm_view_scroll(f, dfm_view_rows(f)); return;
    case 'g': dfm_view_scroll(f, -(int)f->vp_top); return;
    case 'G': {
        int vr = dfm_view_rows(f);
        int maxtop = (int)f->vp_lines - vr;
        if (maxtop < 0) maxtop = 0;
        dfm_view_scroll(f, maxtop - (int)f->vp_top);
        return;
    }
    case 'q': case 'h': case 0x03:
        dfm_view_close(f);
        return;
    default: return;
    }
}

/* ---------------- редактор (построчный; из tfm Task 46) ---------------- */

static u32 dfm_ed_lines(const char *b, u32 len)
{
    u32 n = 0;
    for (u32 i = 0; i < len; i++)
        if (b[i] == '\n') n++;
    if (len && b[len - 1] != '\n') n++;
    return n;
}

static u32 dfm_ed_line_off(const char *b, u32 len, u32 no, u32 *out_len)
{
    u32 cur = 1, i = 0;
    while (i < len) {
        if (cur == no) {
            u32 j = i;
            while (j < len && b[j] != '\n') j++;
            *out_len = j - i;
            return i;
        }
        while (i < len && b[i] != '\n') i++;
        if (i < len) i++;
        cur++;
    }
    return 0;
}

static void dfm_ed_open_path(dfm_t *f, const char *path)
{
    if (f->ed) { dfm_set_msg(f, "Редактор уже открыт"); return; }
    f->ed = (char *)malloc(DFM_ED_MAX);
    if (!f->ed) { dfm_set_msg(f, "Нет памяти под редактор"); return; }
    f->ed_len = 0;
    f->ed_dirty = 0;
    ramfs_dirent_t de;
    if (ramfs_stat_ci(path, &de) && !de.is_dir && de.size > 0) {
        u32 cap = de.size < DFM_ED_MAX ? de.size : DFM_ED_MAX;
        f->ed_len = ramfs_read(path, f->ed, cap);
        f->ed[f->ed_len] = 0;
    }
    snprintf(f->ed_path, sizeof(f->ed_path), "%s", path);
    f->mode = 2;
    dfm_mouse_off(f);           /* telnetd собирает строку своим эхо-вводом */
    char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
    dfm_show(path, show, (int)sizeof(show));
    char line[DFM_CWD_MAX + DFM_NAME_MAX + 64];
    snprintf(line, sizeof(line), "Редактор: %s (%u байт, %u строк)",
             show, (unsigned)f->ed_len,
             (unsigned)dfm_ed_lines(f->ed, f->ed_len));
    dfm_say(f, line);
    if (f->ed_len == 0) dfm_say(f, "(файл пуст/новый)");
    dfm_say(f, "Команды: l - список строк; v <N> - показать строку;");
    dfm_say(f, "  s <N> <текст> - заменить строку; a <N> <текст> - вставить ПОСЛЕ строки N (a 0 - в начало);");
    dfm_say(f, "  d <N> - удалить строку; w - записать; wq - записать и выйти; q - выйти БЕЗ записи.");
    dfm_say(f, "  Строка ввода ограничена длиной telnet-строки (~80 символов).");
}

static void dfm_ed_save(dfm_t *f)
{
    ramfs_delete(f->ed_path);
    if (!ramfs_create(f->ed_path, f->ed_len ? f->ed_len : 1)) {
        dfm_set_msg(f, "Не удалось создать файл (место/длина имени?)");
        dfm_say(f, f->msg);
        return;
    }
    if (f->ed_len && !ramfs_write(f->ed_path, f->ed, f->ed_len)) {
        ramfs_delete(f->ed_path);
        dfm_set_msg(f, "Ошибка записи");
        dfm_say(f, f->msg);
        return;
    }
    f->ed_dirty = 0;
    char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
    dfm_show(f->ed_path, show, (int)sizeof(show));
    char line[DFM_CWD_MAX + DFM_NAME_MAX + 48];
    snprintf(line, sizeof(line), "Записано: %s (%u байт)",
             show, (unsigned)f->ed_len);
    dfm_say(f, line);
}

static void dfm_ed_close(dfm_t *f, int saved)
{
    if (f->ed) free(f->ed);
    f->ed = 0;
    f->ed_len = 0;
    f->ed_dirty = 0;
    f->mode = 1;
    if (!saved) dfm_say(f, "Выход БЕЗ записи (правки потеряны)");
    dfm_mouse_on(f);
    dfm_scan(f);
    dfm_draw(f);
}

static void dfm_ed_list(dfm_t *f)
{
    char line[DFM_NAME_MAX + 24];
    u32 n = dfm_ed_lines(f->ed, f->ed_len);
    if (!n) { dfm_say(f, "(пусто)"); return; }
    u32 shown = 0;
    for (u32 no = 1; no <= n && shown < 200; no++, shown++) {
        u32 L = 0;
        u32 off = dfm_ed_line_off(f->ed, f->ed_len, no, &L);
        if (!off && L == 0 && no > 1) break;
        if (L > 80) L = 80;
        char seg[96];
        memcpy(seg, f->ed + off, L);
        seg[L] = 0;
        snprintf(line, sizeof(line), "%3u| %s", (unsigned)no, seg);
        dfm_say(f, line);
    }
    if (shown < n) {
        snprintf(line, sizeof(line), "... (показано %u из %u строк)",
                 shown, n);
        dfm_say(f, line);
    }
}

static int dfm_ed_insert(dfm_t *f, u32 after, const char *text)
{
    u32 tlen = (u32)strlen(text);
    if (f->ed_len + tlen + 1 > DFM_ED_MAX) return 0;
    u32 nlines = dfm_ed_lines(f->ed, f->ed_len);
    u32 off = 0;
    if (after > 0) {
        if (after <= nlines) {
            u32 L;
            off = dfm_ed_line_off(f->ed, f->ed_len, after, &L);
            off += L;
            if (off < f->ed_len) off++;
            else if (off > 0 && f->ed[off - 1] != '\n') {
                if (f->ed_len + 1 > DFM_ED_MAX) return 0;
                f->ed[off] = '\n';
                f->ed_len++;
                off++;
            }
        } else if (after == nlines + 1) {
            off = f->ed_len;
            if (off > 0 && f->ed[off - 1] != '\n') {
                if (f->ed_len + 1 > DFM_ED_MAX) return 0;
                f->ed[off] = '\n';
                f->ed_len++;
                off++;
            }
        } else return 0;
    }
    memmove(f->ed + off + tlen + 1, f->ed + off, f->ed_len - off);
    memcpy(f->ed + off, text, tlen);
    f->ed[off + tlen] = '\n';
    f->ed_len += tlen + 1;
    f->ed[f->ed_len] = 0;
    return 1;
}

static int dfm_ed_delete(dfm_t *f, u32 no)
{
    u32 L = 0;
    u32 off = dfm_ed_line_off(f->ed, f->ed_len, no, &L);
    if (!off && L == 0 && no > 1) return 0;
    u32 nl = (off + L < f->ed_len) ? 1 : 0;
    memmove(f->ed + off, f->ed + off + L + nl, f->ed_len - off - L - nl);
    f->ed_len -= L + nl;
    f->ed[f->ed_len] = 0;
    return 1;
}

static int dfm_ed_replace(dfm_t *f, u32 no, const char *text)
{
    if (!dfm_ed_delete(f, no)) return 0;
    return dfm_ed_insert(f, no - 1, text);
}

void dfm_edit_line(dfm_t *f, const char *line)
{
    if (f->mode != 2 || !f->ed) return;
    char cmd[DFM_CWD_MAX + 8];
    snprintf(cmd, sizeof(cmd), "%s", line ? line : "");

    char line2[DFM_NAME_MAX + 40];
    if (!strcmp(cmd, "q") || !strcmp(cmd, "quit")) {
        int was_dirty = f->ed_dirty;
        dfm_ed_close(f, 0);
        if (!was_dirty) dfm_say(f, "Выход из редактора");
        return;
    }
    if (!strcmp(cmd, "wq")) {
        dfm_ed_save(f);
        if (!f->ed_dirty) dfm_ed_close(f, 1);
        return;
    }
    if (!strcmp(cmd, "w") || !strcmp(cmd, "write")) { dfm_ed_save(f); return; }
    if (!strcmp(cmd, "l") || !strcmp(cmd, "list")) { dfm_ed_list(f); return; }
    if (cmd[0] == 'v' && (cmd[1] == ' ' || cmd[1] == 0)) {
        u32 no = 0;
        for (const char *p = cmd + 2; *p >= '0' && *p <= '9'; p++)
            no = no * 10 + (u32)(*p - '0');
        u32 L = 0;
        u32 off = no ? dfm_ed_line_off(f->ed, f->ed_len, no, &L) : 0;
        if (!no || (!off && L == 0 && no > 1)) {
            dfm_say(f, "Нет такой строки (l — список)");
        } else {
            if (L > 80) L = 80;
            char seg[96];
            memcpy(seg, f->ed + off, L);
            seg[L] = 0;
            snprintf(line2, sizeof(line2), "%3u| %s", (unsigned)no, seg);
            dfm_say(f, line2);
        }
        return;
    }
    if ((cmd[0] == 's' || cmd[0] == 'a') && cmd[1] == ' ') {
        u32 no = 0;
        const char *p = cmd + 2;
        while (*p >= '0' && *p <= '9') { no = no * 10 + (u32)(*p - '0'); p++; }
        while (*p == ' ') p++;
        const char *text = p;
        if (!text[0]) { dfm_say(f, "Нужен текст: s|a <N> <текст>"); return; }
        if (cmd[0] == 'a' && no == 0) {
            if (dfm_ed_insert(f, 0, text)) {
                f->ed_dirty = 1;
                dfm_say(f, "Вставлено в начало");
            } else dfm_say(f, "Нет места в буфере");
            return;
        }
        if (no == 0) { dfm_say(f, "Номер строки: 1..N"); return; }
        u32 n = dfm_ed_lines(f->ed, f->ed_len);
        if (no > n + (cmd[0] == 'a' ? 1 : 0)) {
            snprintf(line2, sizeof(line2), "Строк всего %u (l — список)", n);
            dfm_say(f, line2);
            return;
        }
        if (cmd[0] == 's') {
            if (dfm_ed_replace(f, no, text)) {
                f->ed_dirty = 1;
                snprintf(line2, sizeof(line2), "Строка %u заменена",
                         (unsigned)no);
                dfm_say(f, line2);
            } else dfm_say(f, "Нет такой строки");
        } else {
            if (dfm_ed_insert(f, no, text)) {
                f->ed_dirty = 1;
                snprintf(line2, sizeof(line2), "Вставлено после строки %u",
                         (unsigned)no);
                dfm_say(f, line2);
            } else dfm_say(f, "Нет места в буфере");
        }
        return;
    }
    if (cmd[0] == 'd' && cmd[1] == ' ') {
        u32 no = 0;
        for (const char *p = cmd + 2; *p >= '0' && *p <= '9'; p++)
            no = no * 10 + (u32)(*p - '0');
        if (!no || !dfm_ed_delete(f, no)) {
            dfm_say(f, "Нет такой строки (l — список)");
        } else {
            f->ed_dirty = 1;
            snprintf(line2, sizeof(line2), "Строка %u удалена",
                     (unsigned)no);
            dfm_say(f, line2);
        }
        return;
    }
    dfm_say(f, "Неизвестная команда редактора (l, v/s/a/d <N>, w, wq, q)");
}

/* ---------------- удаление ---------------- */

static void dfm_delete_cursor(dfm_t *f)
{
    if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
    ramfs_dirent_t *e = &f->ents[f->y];
    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
        dfm_set_msg(f, "Слишком длинный путь");
        return;
    }
    if (ramfs_delete(path)) {
        dfm_msg(f, "Удалено: %s", e->name, 0);
        dfm_scan(f);
    } else {
        dfm_set_msg(f, e->is_dir ? "Каталог не пуст (или не найден)"
                                  : "Не удалось удалить (не найден?)");
    }
    f->del_pending = 0;
}

/* ---------------- промпты (строковый режим) ---------------- */

void dfm_prompt_text(const dfm_t *f, char *out, int cap)
{
    switch (f->prompt_kind) {
    case 1:  snprintf(out, (u32)cap, ANSI_HDR "поиск:" ANSI_NORM " ");  break;
    case 2:  snprintf(out, (u32)cap, ANSI_HDR "new:" ANSI_NORM " ");    break;
    case 3:  snprintf(out, (u32)cap, ANSI_HDR "mkdir:" ANSI_NORM " ");  break;
    default: snprintf(out, (u32)cap, "? ");       break;
    }
}

void dfm_prompt_line(dfm_t *f, const char *line)
{
    if (f->mode != 3) return;
    int kind = f->prompt_kind;
    f->prompt_kind = 0;
    f->mode = 1;

    char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    if (kind == 1) {
        snprintf(f->filt, sizeof(f->filt), "%s", line ? line : "");
        dfm_scan(f);
        if (f->filt[0] && f->nents == 0)
            dfm_set_msg(f, "Фильтр: ни одной записи");
        dfm_mouse_on(f);
        dfm_draw(f);
        return;
    }
    if (kind == 2) {
        if (!line || !line[0]) {
            dfm_set_msg(f, "Имя файла не задано");
            dfm_mouse_on(f);
            dfm_draw(f);
            return;
        }
        if (!dfm_resolve(f->cwd, line, path, (int)sizeof(path))) {
            dfm_set_msg(f, "Слишком длинный путь");
            dfm_mouse_on(f);
            dfm_draw(f);
            return;
        }
        ramfs_dirent_t ex;
        if (ramfs_stat_ci(path, &ex) && ex.is_dir) {
            dfm_set_msg(f, "Это имя занято каталогом");
            dfm_mouse_on(f);
            dfm_draw(f);
            return;
        }
        if (!ramfs_stat_ci(path, &ex)) {
            if (!ramfs_create(path, 0)) {
                dfm_set_msg(f, "Не удалось создать (место/имя?)");
                dfm_mouse_on(f);
                dfm_draw(f);
                return;
            }
            dfm_scan(f);
        }
        dfm_ed_open_path(f, path);
        return;
    }
    if (kind == 3) {
        if (!line || !line[0]) {
            dfm_set_msg(f, "Имя каталога не задано");
            dfm_mouse_on(f);
            dfm_draw(f);
            return;
        }
        if (!dfm_resolve(f->cwd, line, path, (int)sizeof(path))) {
            dfm_set_msg(f, "Слишком длинный путь");
            dfm_mouse_on(f);
            dfm_draw(f);
            return;
        }
        if (ramfs_mkdir(path)) {
            char show[DFM_CWD_MAX + DFM_NAME_MAX + 4];
            dfm_show(path, show, (int)sizeof(show));
            dfm_msg(f, "Каталог создан: %s", show, 0);
            dfm_scan(f);
        } else {
            dfm_set_msg(f, "Не удалось (родителя нет/имя занято)");
        }
        dfm_mouse_on(f);
        dfm_draw(f);
        return;
    }
    dfm_mouse_on(f);
    dfm_draw(f);
}

/* ---------------- клавиатура обзора (режим 1) ---------------- */

static void dfm_browse_key(dfm_t *f, unsigned char b)
{
    switch (b) {
    case 'j': dfm_move(f, +1); return;
    case 'k': dfm_move(f, -1); return;
    case 'g': dfm_top(f);      return;
    case 'G': dfm_bottom(f);   return;
    case 'h': dfm_up(f);       return;
    case 'l': case '\r': case '\n':
        dfm_open(f);
        return;
    case 'r': case 0x0C:
        f->msg[0] = 0;
        dfm_scan(f);
        return;
    case 's':
        f->sort = (u8)((f->sort + 1) & 3);
        dfm_scan(f);
        return;
    case 'v':
        f->view = (u8)(f->view ? 0 : 1);
        f->msg[0] = 0;
        return;
    case '/':
        f->mode = 3;
        f->prompt_kind = 1;
        f->msg[0] = 0;
        dfm_mouse_off(f);
        dfm_say(f, "\n");
        return;
    case 'n':
        f->mode = 3;
        f->prompt_kind = 2;
        dfm_mouse_off(f);
        dfm_say(f, "\n");
        return;
    case 'm':
        f->mode = 3;
        f->prompt_kind = 3;
        dfm_mouse_off(f);
        dfm_say(f, "\n");
        return;
    case 'e': {
        if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
        ramfs_dirent_t *e = &f->ents[f->y];
        if (e->is_dir) { dfm_set_msg(f, "Это каталог (l — войти)"); return; }
        if (e->size > DFM_ED_MAX) {
            dfm_msg(f, "Файл больше %u КиБ редактор не тянет",
                    NULL, (unsigned)(DFM_ED_MAX / 1024));
            return;
        }
        char path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
        if (!dfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
            dfm_set_msg(f, "Слишком длинный путь");
            return;
        }
        f->msg[0] = 0;
        dfm_say(f, "\n");
        dfm_ed_open_path(f, path);
        return;
    }
    case 'd':
        if (f->nents == 0) { dfm_set_msg(f, "Каталог пуст"); return; }
        if (!f->del_pending) {
            f->del_pending = 1;
            dfm_msg(f, "Удалить %s? y — да, прочее — отмена",
                    f->ents[f->y].name, 0);
        }
        return;
    case 'y': case 'Y':
        if (f->del_pending) { dfm_delete_cursor(f); return; }
        break;
    case 'q': case 0x03:
        dfm_mouse_off(f);
        f->mode = 0;
        f->prompt_kind = 0;
        f->del_pending = 0;
        dfm_say(f, "\nВыход из файлового менеджера dfm\n");
        return;
    default:
        f->del_pending = 0;
        f->msg[0] = 0;
        return;
    }
}

/* ---------------- мышь: событие ---------------- */

void dfm_mouse_event(dfm_t *f, u32 b, u32 mx, u32 my, int press)
{
    if (!f->mouse) return;
    u8 btn = (u8)(b & 3);

    /* ---- просмотрщик (4): колесо + клики по подсказкам ---- */
    if (f->mode == 4) {
        if (b & 64) {                    /* колесо → прокрутка */
            dfm_view_scroll(f, btn == 0 ? -3 : +3);
            return;
        }
        if (!press || btn != 0) return;
        for (int i = 0; i < f->nbtn; i++) {
            if ((int)my == (int)f->btn[i].row &&
                (int)mx >= (int)f->btn[i].col_start &&
                (int)mx <= (int)f->btn[i].col_end) {
                dfm_view_key(f, f->btn[i].key);   /* сам перерисует */
                return;
            }
        }
        return;
    }
    if (f->mode != 1) return;           /* в 2/3 мышь должна быть OFF */

    /* ---- колесо: движение по списку ---- */
    if (b & 64) {
        dfm_move(f, btn == 0 ? -1 : +1);
        dfm_draw(f);
        return;
    }
    if (!press) return;

    /* любой клик снимает ожидание удаления (как любая не-'y' клавиша) */
    if (f->del_pending) {
        f->del_pending = 0;
        dfm_set_msg(f, "Удаление отменено");
    }

    /* ---- клик по подсказке [X] ---- */
    if (btn == 0) {
        for (int i = 0; i < f->nbtn; i++) {
            if ((int)my == (int)f->btn[i].row &&
                (int)mx >= (int)f->btn[i].col_start &&
                (int)mx <= (int)f->btn[i].col_end) {
                dfm_browse_key(f, f->btn[i].key);
                if (f->mode == 1) dfm_draw(f);
                return;
            }
        }
    }

    /* ---- ПКМ → наверх ---- */
    if (btn == 2) {
        dfm_up(f);
        dfm_draw(f);
        return;
    }
    if (btn != 0) { dfm_draw(f); return; }

    /* ---- ЛКМ по строке списка: my (1-based) → row. Шапка = 2 строки ---- */
    int row = (int)my - 3;
    if (row < 0 || row >= f->rows) { dfm_draw(f); return; }
    int idx = f->o + row;
    if (idx < 0 || idx >= f->nents) { dfm_draw(f); return; }

    if (idx == f->y) {
        dfm_open(f);                /* повторный клик = Enter */
    } else {
        f->y = idx;
        f->msg[0] = 0;
    }
    dfm_draw(f);
}

/* ---------------- публичный ввод ---------------- */

void dfm_key(dfm_t *f, unsigned char b)
{
    /* ---- SGR-мышь: ESC [ < b ; x ; y M|m ---- */
    if (f->mstate == 1) {
        if (b >= '0' && b <= '9') {
            f->mval[f->midx] = f->mval[f->midx] * 10u + (u32)(b - '0');
            return;
        }
        if (b == ';' && f->midx < 2) { f->midx++; return; }
        if (b == 'M' || b == 'm') {
            u32 mb = f->mval[0], mx = f->mval[1], my = f->mval[2];
            int press = (b == 'M');
            f->mstate = 0;
            f->midx = 0;
            f->mval[0] = f->mval[1] = f->mval[2] = 0;
            dfm_mouse_event(f, mb, mx, my, press);
            return;
        }
        f->mstate = 0;
        f->midx = 0;
        return;
    }

    if (f->esc == 1) {
        f->esc = 0;
        if (b == '[') { f->esc = 2; return; }
        return;
    }
    if (f->esc == 2) {
        f->esc = 0;
        if (b == '<') {
            f->mstate = 1;
            f->midx = 0;
            f->mval[0] = f->mval[1] = f->mval[2] = 0;
            return;
        }
        switch (b) {
        case 'A':
            if (f->mode == 4) dfm_view_key(f, 'k');
            else if (f->mode == 1) { dfm_move(f, -1); dfm_draw(f); }
            return;
        case 'B':
            if (f->mode == 4) dfm_view_key(f, 'j');
            else if (f->mode == 1) { dfm_move(f, +1); dfm_draw(f); }
            return;
        case 'C':
            if (f->mode == 1) { dfm_open(f); dfm_draw(f); }
            return;
        case 'D':
            if (f->mode == 1) { dfm_up(f);   dfm_draw(f); }
            return;
        default: return;
        }
    }
    if (b == 0x1B) { f->esc = 1; return; }

    if (f->mode == 4) { dfm_view_key(f, b); return; }
    if (f->mode != 1) return;

    if (f->del_pending && b != 'y' && b != 'Y') {
        f->del_pending = 0;
        dfm_set_msg(f, "Удаление отменено");
        dfm_draw(f);
        return;
    }
    dfm_browse_key(f, b);
    if (f->mode == 1) dfm_draw(f);
}

/* ---------------- жизненный цикл ---------------- */

void dfm_enter(dfm_t *f, void (*out)(void *ud, const char *s), void *ud)
{
    f->out = out;
    f->ud = ud;
    f->mode = 1;
    f->prompt_kind = 0;
    f->del_pending = 0;
    f->esc = 0;
    f->mstate = 0;
    f->midx = 0;
    f->msg[0] = 0;
    f->y = 0;
    f->o = 0;
    if (f->rows <= 0) f->rows = DFM_ROWS;
    if (f->cols <= 0) f->cols = 80;
    dfm_scan(f);
    dfm_draw(f);
    dfm_mouse_on(f);
}

int dfm_active(const dfm_t *f)     { return f->mode ? 1 : 0; }
int dfm_wants_line(const dfm_t *f) { return (f->mode == 2 || f->mode == 3); }

void dfm_resize(dfm_t *f, int term_rows, int term_cols)
{
    int r = term_rows - 5;                   /* 2 шапки + 3 помощи */
    if (r < 1) r = 1;
    f->rows = r;
    f->cols = (term_cols > 0) ? term_cols : 80;

    if (f->y < f->o) f->o = f->y;
    if (f->y >= f->o + f->rows) f->o = f->y - f->rows + 1;
    if (f->o > f->nents - f->rows) f->o = f->nents - f->rows;
    if (f->o < 0) f->o = 0;

    if (f->mode == 4) {
        int vr = dfm_view_rows(f);
        int maxtop = (int)f->vp_lines - vr;
        if (maxtop < 0) maxtop = 0;
        if ((int)f->vp_top > maxtop) f->vp_top = (u32)maxtop;
    }

    if (f->mode == 1)      dfm_draw(f);
    else if (f->mode == 4) dfm_view_draw(f);
}

void dfm_reset(dfm_t *f)
{
    dfm_mouse_off(f);
    if (f->ed) free(f->ed);
    if (f->vp) free(f->vp);
    memset(f, 0, sizeof(*f));
    f->mode = 0;
}