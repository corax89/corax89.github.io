/* pci.c — доступ к PCI конфигурационному пространству (Task 49).
 *
 * Тела ПЕРЕЕХАЛИ из usb.c: раньше реализация pci_read32/16/8 и
 * pci_write32/16 жила в usb.c, поэтому КАЖДЫЙ драйвер, включающий
 * pci.h (ath9k_wifi, rtl8192eu, usb_ehci, snd_hda, e1000, atl1c, ahci…),
 * при линковке тянул за собой весь usb.o с UHCI-хостом. Теперь это
 * самостоятельная единица; usb.c остаётся обычным клиентом pci.h.
 * pci_ids.h (таблица lookup) не затронут. */
#include "pci.h"
#include "io.h"

#define PCI_ADDR  0xCF8
#define PCI_DATA  0xCFC

u32 pci_read32(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return inl(PCI_DATA);
}

u16 pci_read16(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return (u16)((inl(PCI_DATA) >> ((reg & 2) * 8)) & 0xFFFF);
}

u8 pci_read8(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return (u8)((inl(PCI_DATA) >> ((reg & 3) * 8)) & 0xFF);
}

void pci_write32(int bus, int dev, int func, int reg, u32 val)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    outl(PCI_DATA, val);
}

void pci_write16(int bus, int dev, int func, int reg, u16 val)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    u32 old = inl(PCI_DATA);
    u32 shift = (reg & 2) * 8;
    u32 mask = 0xFFFFu << shift;
    u32 new = (old & ~mask) | (((u32)val) << shift);
    outl(PCI_DATA, new);
}
