/* apps_sysinfo.c — «Системная информация» (Task 49; вынесен из apps.c):
 * панели CPU/памяти/дисков/сети/звука и бенчмарк. */
/* apps.c — реестр приложений + «О программе», «Терминал», «Системная информация» */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "gfx2d.h"   /* СЕССИЯ 85: GPU в системной информации */
#include "mem.h"
#include "timer.h"
#include "string.h"
#include "mouse.h"
#include "kernel.h"
#include "utf8.h"
#include "ramfs.h"
#include "mqjs_os.h"   /* QuickJS: REPL и запуск .js (замена CMScript) */
#include "task.h"
#include "mouse.h"
#include "sound.h"
extern void serial_puts(const char *s);

#include "loader.h"
#include "usb.h"
#include "usb_ehci.h"
#include "e1000.h"
#include "net.h"
#include "ne2000.h"
#include "timer.h"
#include "c4.h"
#include "c4gfx.h"
#include "pci.h"
#include "ath9k_wifi.h"
#include "wpa2.h"
#include "hwinfo.h"  /* сессия 90: hwdet-подобная диагностика ACPI/DSDT/SMBIOS/CPU */
#include "apipc.h"   /* SMP-rework: ap_syscall_do (тест mailbox/IPI) */
#include "smp.h"     /* SMP-rework: smp_current_cpu */
#include "ata.h"
#include "ahci.h"
#include "disk.h"
#include "iso9660.h"
#include "fat32.h"
#include "ntfs.h"
#include "smp.h"
#include <cpuid.h>   /* GCC/MinGW: встроенные обёртки над инструкцией CPUID */

/* ========================= СИСТЕМНАЯ ИНФОРМАЦИЯ ========================= */
#define SI_LINES 64    /* сессия 90: +DMI/ACPI/устройства/кэш/TSC */
#define SI_LINE_W 60

typedef struct {
    char lines[SI_LINES][SI_LINE_W];
    u32  colors[SI_LINES];
    int  scroll;
    wm_scrollbar_t sb;         /* общий виджет полосы прокрутки */
    /* сессия 57: тесты по кнопкам (CPU-скорость, звук) */
    char cpu_res[SI_LINE_W];   /* результат бенчмарка */
    char snd_res[SI_LINE_W];   /* результат звукового теста */
    int  busy;                 /* 1 = тест выполняется */
} sysinfo_t;

static const u32 C_LABEL = 0, C_VALUE = 1, C_ACCENT = 2;

static void si_put(sysinfo_t *d, int row, const char *s, u32 which)
{
    if (row < 0 || row >= SI_LINES) return;
    strncpy(d->lines[row], s, SI_LINE_W - 1);
    d->lines[row][SI_LINE_W - 1] = 0;
    d->colors[row] = which;
}

static void si_draw(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x12, 0x15, 0x19));
    fb_fill_rect(0, 0, cw, 2, fb_rgb(0x3E, 0x7D, 0xBF));

    u32 col_label = wm_theme_text_dim();
    u32 col_value = wm_theme_text();
    u32 col_accent = wm_theme_accent();
    u32 col_warn = fb_rgb(0xFF, 0xE0, 0x60);

    /* сессия 57: нижняя панель кнопок — фиксированная, не скроллится */
    int btn_h = 20;
    int list_h = ch - btn_h - 8;

    int vis = list_h / 18;
    if (vis < 1) vis = 1;
    int max_scroll = SI_LINES - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (d->scroll > max_scroll) d->scroll = max_scroll;
    if (d->scroll < 0) d->scroll = 0;

    int start = d->scroll;
    int end = start + vis;
    if (end > SI_LINES) end = SI_LINES;

    /* Полоса прокрутки — общий виджет wm_scrollbar (цвет из темы).
     * ПОРЯДОК ПОНЯТЕН (ФИКС сессии 17): pos=0 — верх списка
     * (раньше формула была инвертирована — ползунок ехал наоборот). */
    wm_scrollbar_draw(&d->sb, cw - 7, 4, 5, list_h - 4, d->scroll,
                      max_scroll, vis);

    int text_w = cw - 12;  /* оставляем место под скроллбар */
    int y = 12;
    for (int i = start; i < end; i++, y += 18) {
        u32 c;
        if (d->colors[i] == C_LABEL) c = col_label;
        else if (d->colors[i] == C_VALUE) c = col_value;
        else if (d->colors[i] == C_ACCENT) c = col_accent;
        else c = col_warn;
        fb_text(10, y, d->lines[i], c, -1);
        (void)text_w;
    }

    /* --- кнопки тестов (сессия 57) --- */
    int by = ch - btn_h - 4;
    fb_hline(0, cw - 1, by - 4, fb_rgb(0x2C, 0x31, 0x38));
    int busy = d->busy;
    /* [Тест CPU] */
    fb_fill_rect(8, by, 92, btn_h, busy ? fb_rgb(0x1E, 0x26, 0x30)
                                        : fb_rgb(0x24, 0x30, 0x40));
    fb_rect(8, by, 92, btn_h, col_accent);
    fb_text(18, by + 5, busy ? "Измеряю..." : "Тест CPU",
            busy ? col_label : col_value, -1);
    /* [Тест звука] */
    fb_fill_rect(106, by, 104, btn_h, busy ? fb_rgb(0x1E, 0x26, 0x30)
                                           : fb_rgb(0x24, 0x30, 0x40));
    fb_rect(106, by, 104, btn_h, col_accent);
    fb_text(116, by + 5, busy ? "Играю..." : "Тест звука",
            busy ? col_label : col_value, -1);
    /* результаты справа/на строке выше кнопок */
    if (d->cpu_res[0])
        fb_text(220, by, d->cpu_res, col_accent, -1);
    if (d->snd_res[0])
        fb_text(220, by + 10, d->snd_res, col_accent, -1);
}

static void si_key(window_t *w, const key_event_t *ev)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    int chh = win_content_h(w);
    int list_h = chh - 20 - 8;
    int vis = list_h / 18;
    if (vis < 1) vis = 1;
    int max_scroll = SI_LINES - vis;
    if (max_scroll < 0) max_scroll = 0;

    /* ФИКС сессии 17: scroll — первая видимая строка. Раньше PgUp
     * увеличивал его (листало ВНИЗ), Home/End вели себя наоборот.
     * ЗАДАЧА 53: PgUp/PgDn — страница (раньше PgUp листал 1 строку
     * при PgDn-странице — несимметрично); СТРЕЛКИ —
     * WM_KEY_SCROLL_LINES строк. */
    if (ev->code == 0x49) {                        /* PgUp — страница */
        d->scroll -= vis;
        if (d->scroll < 0) d->scroll = 0;
        win_invalidate(w);
    }
    else if (ev->code == KBD_UP) {                 /* вверх — несколько строк */
        d->scroll -= WM_KEY_SCROLL_LINES;
        if (d->scroll < 0) d->scroll = 0;
        win_invalidate(w);
    }
    else if (ev->code == 0x51) {  /* PgDn — страница */
        d->scroll += vis;
        if (d->scroll > max_scroll) d->scroll = max_scroll;
        win_invalidate(w);
    }
    else if (ev->code == KBD_DOWN) {               /* вниз — несколько строк */
        d->scroll += WM_KEY_SCROLL_LINES;
        if (d->scroll > max_scroll) d->scroll = max_scroll;
        win_invalidate(w);
    }
}

static u32 si_bench_mips(u32 ms);   /* fwd: определения после si_tick */
static u32 si_bench_mem(u32 ms);

static void si_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    int cw = win_content_w(w), chh = win_content_h(w);

    /* --- сессия 57: кнопки тестов --- */
    int by = chh - 20 - 4;
    if (mx >= 0 && my >= by) {
        if ((changed & MSB_LEFT) && !d->busy) {
            if (wm_button_hit(mx, my, 8, by, 92, 20)) {
                d->busy = 1;
                snprintf(d->cpu_res, sizeof(d->cpu_res), "CPU: считаю...");
                win_invalidate(w);
                u32 mips = si_bench_mips(500);
                u32 mbps = si_bench_mem(400);
                snprintf(d->cpu_res, sizeof(d->cpu_res),
                         "CPU: %u.%02u MIPS, mem %u МБ/с",
                         mips / 1000, (mips % 1000) / 10, mbps);
                d->busy = 0;
                win_invalidate(w);
                return;
            }
            if (wm_button_hit(mx, my, 106, by, 104, 20)) {
                d->busy = 1;
                snprintf(d->snd_res, sizeof(d->snd_res), "Звук: играю...");
                win_invalidate(w);
                if (!sound_present()) {
                    snprintf(d->snd_res, sizeof(d->snd_res),
                             "Звук: %s", sound_last_error());
                } else {
                    int rc = sound_test_melody();
                    /* [SND-STREAMTEST]: вторая фаза — тот же звук через
                     * ПОТОКОВЫЙ путь (как MP3-плеер): отличает «HW-тракт
                     * хрипит» от «декод/файл хрипит» по одному нажатию */
                    int rc2 = sound_stream_test();
                    snprintf(d->snd_res, sizeof(d->snd_res),
                             (rc == 0 && rc2 == 0) ? "Звук: ок — %s"
                                                   : "Звук: ошибка — %s",
                             sound_device_name());
                }
                d->busy = 0;
                win_invalidate(w);
                return;
            }
        }
        return;   /* ниже кнопок список не скроллится */
    }

    if (mx < 0 || my < 0) {
        /* сессия 20 (захват мыши): отпускание за пределами окна — полосе */
        if (d->sb.dragging)
            wm_scrollbar_mouse(&d->sb, mx, my, btn, changed);
        return;
    }
    if (mx >= cw - 9 || d->sb.dragging) {
        int np = wm_scrollbar_mouse(&d->sb, mx, my, btn, changed);
        if (np >= 0) { d->scroll = np; win_invalidate(w); }
    }
}

/* сессия 57: компактный бенчмарк CPU (ЦЕЛОЧИСЛЕННЫЙ — x87 не
 * сохраняется между задачами). MIPS через LCG-конвейер
 * (умножение+сложение+xor — типичная целочисленная нагрузка)
 * и memcpy-пропускная способность памяти (МБ/с). */
static u32 si_bench_mips(u32 ms)
{
    u32 t0 = timer_ticks();
    u32 iters = 0;
    volatile u32 x = 0x12345678u;
    while ((u32)(timer_ticks() - t0) < ms) {
        for (int i = 0; i < 20000; i++) {
            x = x * 1664525u + 1013904223u;
            x ^= x >> 13;
        }
        iters += 20000;
    }
    u32 dt = timer_ticks() - t0;
    if (dt == 0) dt = 1;
    return iters / dt;        /* кило-итераций/мс ≈ млн оп/с */
}

static u32 si_bench_mem(u32 ms)
{
    enum { N = 128 * 1024 };
    static u8 *a = 0, *b = 0;
    if (!a) { a = (u8 *)malloc(N); b = (u8 *)malloc(N); }
    if (!a || !b) return 0;
    for (int i = 0; i < N; i++) a[i] = (u8)i;
    u32 t0 = timer_ticks();
    u32 copies = 0;
    while ((u32)(timer_ticks() - t0) < ms) {
        memcpy(b, a, N);
        copies++;
    }
    u32 dt = timer_ticks() - t0;
    if (dt == 0) dt = 1;
    return (u32)(((u64)copies * (u64)N) / (u64)dt / 1024);  /* МБ/с */
}

static void si_tick(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    u32 up = uptime_sec();
    char line[SI_LINE_W];
    snprintf(line, sizeof(line), "Uptime: %02u:%02u:%02u  Tasks: %d  Heap: %uK/%uK",
             up / 3600, (up / 60) % 60, up % 60,
             task_count(),
             (unsigned)(mem_used() / 1024),
             (unsigned)(mem_heap_size() / 1024));
    strncpy(d->lines[SI_LINES - 1], line, SI_LINE_W - 1);
    win_invalidate(w);
}

void app_sysinfo_open(void)
{
    sysinfo_t *d = (sysinfo_t *)malloc(sizeof(sysinfo_t));
    if (!d) return;
    memset(d, 0, sizeof(sysinfo_t));

    char brand[52], vend[16], line[SI_LINE_W];
    cpu_get_brand(brand);
    cpu_get_vendor(vend);

    int r = 0;
    si_put(d, r++, "=== N2600-OS 0.1 ===", C_ACCENT);
    si_put(d, r++, "", C_VALUE);

    /* Система (SMBIOS/DMI) — сессия 90, по мотивам hwdet */
    si_put(d, r++, "--- Система (SMBIOS) ---", C_LABEL);
    if (hwinfo_dmi_bios()[0] || hwinfo_dmi_system()[0]) {
        if (hwinfo_dmi_bios()[0]) {
            snprintf(line, sizeof(line), "BIOS: %s", hwinfo_dmi_bios());
            si_put(d, r++, line, C_VALUE);
        }
        if (hwinfo_dmi_system()[0]) {
            snprintf(line, sizeof(line), "Система: %s", hwinfo_dmi_system());
            si_put(d, r++, line, C_VALUE);
        }
        if (hwinfo_dmi_board()[0]) {
            snprintf(line, sizeof(line), "Плата: %s", hwinfo_dmi_board());
            si_put(d, r++, line, C_VALUE);
        }
        if (hwinfo_dmi_cpu()[0]) {
            snprintf(line, sizeof(line), "Сокет: %s", hwinfo_dmi_cpu());
            si_put(d, r++, line, C_VALUE);
        }
    } else {
        si_put(d, r++, "SMBIOS не найден", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* CPU */
    si_put(d, r++, "--- CPU ---", C_LABEL);
    snprintf(line, sizeof(line), "Brand: %s", brand);
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Vendor: %s, лог. ЦП: %d (%d онлайн)",
             vend, smp_cpu_count(), smp_online_count());
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Топология: %d %s / %d %s на ядро",
             smp_topo_cores(),
             (smp_topo_cores() % 10 == 1 && smp_topo_cores() % 100 != 11) ? "ядро" : "ядра",
             smp_topo_threads(),
             (smp_topo_threads() % 10 == 1 && smp_topo_threads() % 100 != 11) ? "поток" : "потока");
    si_put(d, r++, line, C_VALUE);
    /* сессия 90: частота TSC (калибровка по PIT) + кэш + фичи */
    {
        unsigned mhz = hwinfo_tsc_mhz();
        if (mhz) {
            snprintf(line, sizeof(line), "TSC: ~%u МГц", mhz);
            si_put(d, r++, line, C_VALUE);
        }
        char cb[48];
        hwinfo_cpu_cache(cb, sizeof(cb));
        snprintf(line, sizeof(line), "Кэш: %s", cb);
        si_put(d, r++, line, C_VALUE);
        char fb[56];
        hwinfo_cpu_features(fb, sizeof(fb));
        snprintf(line, sizeof(line), "Фичи: %s", fb);
        si_put(d, r++, line, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Memory */
    si_put(d, r++, "--- Memory ---", C_LABEL);
    snprintf(line, sizeof(line), "RAM: %u MiB", (unsigned)mem_ram_mib());
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Heap: %u / %u KiB used",
             (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* ACPI (сессия 90: hwdet-подобный разбор таблиц + устройств DSDT) */
    si_put(d, r++, "--- ACPI (hwdet) ---", C_LABEL);
    {
        char sb[64];
        hwinfo_acpi_summary(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        hwinfo_acpi_tables(sb, sizeof(sb));
        if (sb[0] && strcmp(sb, "-")) {
            snprintf(line, sizeof(line), "Таблицы: %s", sb);
            si_put(d, r++, line, C_VALUE);
        }
        hwinfo_acpi_dsdt(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        snprintf(line, sizeof(line), "Устройств в DSDT: %d (с _HID: %d)",
                 hwinfo_dev_total(), hwinfo_dev_hid());
        si_put(d, r++, line, C_VALUE);
        for (int i = 0; i < hwinfo_dev_hid() && i < 8; i++) {
            char db[64];
            if (hwinfo_dev_get(i, db, sizeof(db))) {
                snprintf(line, sizeof(line), " %s", db);
                si_put(d, r++, line, C_VALUE);
            }
        }
        hwinfo_madt_summary(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        hwinfo_fadt_summary(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        hwinfo_hpet_summary(sb, sizeof(sb));
        if (sb[0]) si_put(d, r++, sb, C_VALUE);
        hwinfo_mcfg_summary(sb, sizeof(sb));
        if (sb[0]) si_put(d, r++, sb, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Display */
    si_put(d, r++, "--- Display ---", C_LABEL);
    snprintf(line, sizeof(line), "Screen: %ux%u, %u bpp, pitch %u",
             (unsigned)fb_width(), (unsigned)fb_height(),
             (unsigned)fb_bpp(), (unsigned)fb_pitch());
    si_put(d, r++, line, C_VALUE);
    /* СЕССИЯ 85: GPU (запрос пользователя) */
    snprintf(line, sizeof(line), "GPU: %s", gfx2d_gpu_info());
    si_put(d, r++, line, C_VALUE);

    {
        const mb_info_t *mb = mb_info();
        const char *ldr = (mb && (mb->flags & MBIF_BOOTLDR))
            ? (const char *)(unsigned long)mb->boot_loader_name : "n/a";
        snprintf(line, sizeof(line), "Bootloader: %s", ldr);
        si_put(d, r++, line, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Input */
    si_put(d, r++, "--- Input ---", C_LABEL);
    snprintf(line, sizeof(line), "PS/2 Mouse: %s",
             mouse_present() ? "present" : "not found");
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "USB keyboard: %s",
             usb_keyboard_present() ? "yes" : "no");
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "USB mouse: %s",
             usb_mouse_present() ? "yes" : "no");
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* USB */
    si_put(d, r++, "--- USB ---", C_LABEL);
    snprintf(line, sizeof(line), "UHCI: %s, EHCI: %s, Devs: %d",
             usb_controllers_found() ? "yes" : "no",
             usb_ehci_present() ? "yes" : "no",
             usb_devices_found());
    si_put(d, r++, line, C_VALUE);
    if (usb_ehci_storage_ready()) {
        si_put(d, r++, "USB flash: READY", C_VALUE);
    } else {
        si_put(d, r++, "USB flash: not detected", C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Network */
    si_put(d, r++, "--- Network ---", C_LABEL);
    if (net_nic_present()) {
        u8 mac[6];
        net_get_mac(mac);
        snprintf(line, sizeof(line), "NIC: %s", net_nic_name());
        si_put(d, r++, line, C_VALUE);
        snprintf(line, sizeof(line), "MAC: %02x:%02x:%02x:%02x:%02x:%02x",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        si_put(d, r++, line, C_VALUE);
        char ipbuf[16];
        u32 ip = net_get_ip();
        if (ip == 0) {
            si_put(d, r++, "IP: not configured", C_ACCENT);
        } else {
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "IP: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
            net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Mask: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
            net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "GW: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
        }
        snprintf(line, sizeof(line), "TX: %u, RX: %u",
                 (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
        si_put(d, r++, line, C_VALUE);
    } else {
        si_put(d, r++, "NIC: not found", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* WiFi */
    si_put(d, r++, "--- WiFi ---", C_LABEL);
    if (wifi_present()) {
        snprintf(line, sizeof(line), "Chip: %s", wifi_chip_name());
        si_put(d, r++, line, C_VALUE);
    } else {
        si_put(d, r++, "WiFi: not found", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* Sound (сессия 57; сессия 58: подробнее + причина если нет) */
    si_put(d, r++, "--- Sound ---", C_LABEL);
    if (sound_present()) {
        snprintf(line, sizeof(line), "Device: %s", sound_device_name());
        si_put(d, r++, line, C_VALUE);
        si_put(d, r++, "PCI, playback 16-bit stereo (тест ниже)", C_VALUE);
    } else {
        si_put(d, r++, "Device: not found", C_VALUE);
        snprintf(line, sizeof(line), "Причина: %s", sound_last_error());
        si_put(d, r++, line, C_ACCENT);
    }
    si_put(d, r++, "Тесты — кнопки внизу окна (CPU/звук)", C_ACCENT);

    si_put(d, r++, "", C_VALUE);
    si_put(d, r++, "Uptime: 00:00:00", C_VALUE);

    u32 W = fb_width(), H = fb_height();
    int ww = 8 * SI_LINE_W + 20;
    int wh = 16 * 18 + 24 + TITLE_H + 2;  /* показываем 16 строк, остальные — скроллом */
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("System Info", 16, 16, ww, wh,
               si_draw, si_key, si_mouse, si_tick, NULL, d);
}
