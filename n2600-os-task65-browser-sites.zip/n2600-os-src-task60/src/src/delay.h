/* delay.h — единый слой задержек драйверов (Task 49).
 *
 * ДО: пять копий калиброванного задержечного слоя — ahci.c
 * (a_delay_calibrate/a_udelay), ath9k_wifi.c (w_udelay_calibrate/
 * w_udelay; калибровка ЗАКРЫВАЛА GATE2 и не делала resync — дедлайны
 * timer.c могли замереть), rtl8192eu.c (rtl_udelay_calibrate/
 * rtl_udelay/rtl_mdelay), atl1c.c (a_calibrate/a_udelay/a_msleep,
 * единицы нс), плюс PIT2-опросные uhci_udelay (usb.c) и hd_delay
 * (snd_hda.c). Пять перепрограммок канала 2 вразнобой = гонка с
 * [PIT2-RESYNC] (фантомные +65536 тиков дедлайнам).
 *
 * ТЕПЕРЬ: одна калибровка (delay_init, идемпотентна, GATE2 остаётся
 * открытым по конвенции timer.c + timer_pit2_resync после перепрограммки)
 * и два входа:
 *   delay_us(us) — до 30 мкс включительно: калиброванный цикл
 *     inb(0x80) (дёшево, субмикросекундная гранулярность — прежнее
 *     поведение коротких задержек PHY/MDIO-поллинга);
 *     длиннее 30 мкс: опрос PIT канала 2 через timer_poll_* (как
 *     uhci_udelay/hd_delay) — точно, независимо от калибровки, не
 *     плывёт при SMI/пробках на порту 0x80 (полевой факт [TXWAIT2]).
 *   delay_ms(ms) — один PIT2-дедлайн на весь интервал.
 *
 * Работает и до sti(): timer_poll_* и калибровке нужен только
 * latch-чтение счётчика (см. timer.h). */
#ifndef DELAY_H
#define DELAY_H

#include "types.h"

/* Калибровать (один раз; повторные вызовы — no-op). Драйверы зовут
 * на месте прежних *_calibrate(). */
void delay_init(void);

void delay_us(u32 us);
void delay_ms(u32 ms);

/* Для диагностики: итераций inb(0x80) на 1 мкс (после delay_init). */
u32  delay_io_per_us(void);

#endif /* DELAY_H */
