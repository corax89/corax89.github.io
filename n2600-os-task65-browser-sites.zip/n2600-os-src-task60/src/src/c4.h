/* c4.h — встроенный в N2600-OS компилятор/VM c4 (Robert Swierczek, порт).
 *
 * c4 — «C in four functions»: компилятор подмножества C в собственный
 * байт-код + стековая виртуальная машина, исполняющая этот байт-код.
 * Оригинал: https://github.com/rswier/c4
 *
 * В этой версии c4 встроен в ядро N2600-OS: исходник передаётся в память,
 * вывод (printf) направляется в предоставленный вызывающим буфер.
 * Поддерживается подмножество C: char/int/pointer, if/while/return,
 * функции, выражения; из «сискалов» VM — malloc/free/memset/memcmp/printf/
 * exit. Этого достаточно, чтобы компилировать и запускать простые программы.
 */
#ifndef C4_H
#define C4_H

#include "types.h"

/* Скомпилировать и выполнить исходник src.
 *   src         — C-исходник (NUL-terminated).
 *   out         — буфер под вывод printf() из выполняемой программы;
 *                 в этот же буфер пишутся сообщения об ошибках компиляции.
 *   out_max     — размер буфера out.
 * Возвращает: 0 при успехе (exit(0) или падение main), иначе -1. */
int c4_run(const char *src, char *out, u32 out_max);

/* Только скомпилировать исходник, не запуская VM.
 *   src         — C-исходник (NUL-terminated).
 *   out         — буфер для диагностики ошибок.
 *   out_max     — размер out.
 *   bytecode    — куда записать готовый байт-код (сегмент text).
 *   bytecode_max — ёмкость буфера байт-кода.
 *   bytecode_len — записанная длина байт-кода (в int-ячейках).
 *   data_seg    — куда записать сегмент данных (глобальные переменные).
 *   data_seg_max — ёмкость data_seg.
 *   data_seg_len — записанная длина (в байтах).
 *   entry_offset — смещение main в байт-коде (в int-ячейках от начала).
 * Возвращает: 0 при успехе, -1 при ошибке компиляции. */
int c4_compile(const char *src, char *out, u32 out_max,
               void *bytecode, u32 bytecode_max, u32 *bytecode_len,
               void *data_seg, u32 data_seg_max, u32 *data_seg_len,
               u32 *entry_offset);

/* Формат .bin (C4N1), сохраняемый c4_compile_to_file:
 *   char magic[4] = "C4N1"
 *   u32  code_size          (байт машинного кода, entry в начале)
 *   u32  data_size          (байт сегмента данных)
 *   u32  n_relocs           (число релокаций данных)
 *   u8   code[code_size]
 *   u8   data[data_size]    (у каждого бинарника — СВОЙ блок в памяти)
 *   u32  relocs[n_relocs]   (смещения imm32 в коде: значение += база data)
 * loader_spawn() распознаёт магию, выделяет отдельные блоки под код и
 * данные и применяет релокации — перекомпиляция одной программы
 * больше НЕ затирает данные работающих.
 * Запускается через loader_spawn() как обычное flat-binary приложение.
 *   source_name — имя файла исходника (например "prog.c").
 *   src         — C-исходник (NUL-terminated).
 *   out         — буфер для диагностики.
 *   out_max     — размер out.
 * Возвращает: 0 при успехе, -1 при ошибке. */
int c4_compile_to_file(const char *source_name, const char *src,
                      char *out, u32 out_max);

/* Сгенерировать native x86 flat-binary из c4 исходника.
 *   src         — C-исходник (NUL-terminated).
 *   diag        — буфер для диагностики ошибок.
 *   diag_max    — размер diag.
 *   out_buf     — куда записать машинный код.
 *   out_max     — ёмкость out_buf.
 *   out_size    — записанная длина (в байтах).
 * Возвращает: 0 при успехе, -1 при ошибке компиляции. */
int c4_compile_to_native(const char *src, char *diag, u32 diag_max,
                         void *out_buf, u32 out_max, u32 *out_size);

/* Загрузить c4-бинарник из RAMFS и запустить его как отдельное приложение
 * через loader_spawn(). Бинарник должен быть native flat-binary
 * (сгенерирован c4_compile_to_file).
 *   bin_name    — имя файла в RAMFS (например "prog.bin")
 *   win         — окно для приложения (NULL = создать потом)
 * Возвращает: tid задачи (>=1), или -1 при ошибке. */
int c4_load_and_run(const char *bin_name, void *win);

/* ----- Функции времени выполнения для native c4-программ (экспортируются
 * через kapi_t). Вызываются из сгенерированного x86-кода. ----- */

/* Вывод строки в буфер "текущей программы" — зависит от вызывающего
 * контекста (терминал, редактор). */
void c4_print_str(const char *s, u32 len);

/* Опрос события ввода (клавиатура). Записывает в out_buf[0..2]:
 *   [0]=ch, [1]=code, [2]=flags. Возвращает 0=нет события, 1=клавиша. */
int c4_event_poll(void *out_buf);

/* Формат вывода для native c4-программ:
 *   fmt          — форматная строка (с %d/%s/%c/%x)
 *   nargs        — число аргументов ВКЛЮЧАЯ fmt (как в c4 PRTF)
 *   args_reversed — указатель на массив аргументов в ОБРАТНОМ порядке
 *                  (как они лежат на стеке c4: первый элемент = последний
 *                  аргумент в source, и т.д.). fmt НЕ входит в массив.
 * Возвращает число записанных символов (как printf). */
int c4_printf_va(const char *fmt, int nargs, int *args_reversed);

/* Захват вывода c4 без запуска VM (для нативных .bin в loader'е). */
void c4_capture_begin(char *buf, u32 max);
u32  c4_capture_len(void);
void c4_capture_end(void);

/* Task 54: ЕДИНЫЙ диспетчер SDL2-функций для c4-программ (реализация —
 * sdl2.c). Номера операций — enum C4_SDL_IDX_* в sdl_ops.h; аргументы
 * в ОБРАТНОМ порядке (args[0] = последний аргумент вызова, как на
 * стеке c4). VM-путь (c4.c) и native-путь (c4_x86.c через kapi_t) —
 * оба идут через эту функцию. */
int c4_sdl_call(int op, const int *args_reversed);

/* Служебные данные для c4_x86 (метки IMM-операндов, ссылающихся на
 * сегмент данных, и база data pool на момент компиляции). */
#define C4_MAX_IMM_MARKS 8192
extern u32 c4_imm_data_cells[C4_MAX_IMM_MARKS];
extern int c4_n_imm_data_cells;
extern u32 c4_compile_data_base;
extern u32 c4_compile_text_base;   /* база текст-пула (цели переходов — le+cell) */

/* --- Расширения совместимости (хост-хуки) ---
 * c4_include_hook: хук #include (регистрируется хостом ДО компиляции).
 *   name — имя файла без кавычек/уголков; kind: 0="name", 1=<name>;
 *   includer — путь включающего файла ("" для корневого исходника);
 *   buf/max — куда прочитать содержимое; возврат: длина (0 = не найден). */
extern u32 (*c4_include_hook)(const char *name, int kind, const char *includer,
                              char *buf, u32 max);

/* GUI-мост для VM-пути (native-путь вызывает через kapi_t) */
typedef struct c4_gui_api {
    int  (*win_open)(const char *title, int x, int y, int w, int h);
    void (*win_close)(int id);
    int  (*win_alive)(int id);
    void (*win_clear)(int id, u32 color);
    void (*win_rect)(int id, int x, int y, int w, int h, u32 color);
    void (*win_text)(int id, int x, int y, const char *s, u32 color);
    void (*win_update)(int id);
    int  (*btn_add)(int id, int x, int y, int w, int h, const char *label);
    int  (*btn_clicked)(int id);
    void (*btn_set_label)(int id, int btn, const char *label);
} c4_gui_api_t;
extern c4_gui_api_t *c4_gui_api;

/* Сессия 56: заполнить c4_gui_api реализациями c4k_* (cmscript_api.c).
 * Вызывается из kapi_fill (loader.c); idempotent. */
void c4_gui_init(void);

#endif /* C4_H */
