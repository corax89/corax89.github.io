/* idt.h — таблица прерываний, PIC, обработчики IRQ */
#ifndef IDT_H
#define IDT_H

#include "types.h"

typedef void (*irq_handler_t)(void);

void idt_init(void);            /* IDT + PIC (все IRQ замаскированы) */
void idt_load_ap(void);         /* сессия 74: загрузить готовый IDT на AP */
void irq_install(int n, irq_handler_t fn);
void pic_unmask(u16 irq_mask);  /* бит i = разрешить IRQ i */
void pic_mask_update(u16 irq_mask);

#endif