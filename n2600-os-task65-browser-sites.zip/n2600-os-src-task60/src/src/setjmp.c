/* setjmp.c — реализация setjmp/longjmp для i386 (см. src/setjmp.h).
 *
 * Используется только движком MicroQuickJS. Соглашение о вызовах i386:
 * аргументы в стеке, callee-saved регистры ebx/esi/edi/ebp.
 *
 * setjmp(env):
 *   env[0] = ebx, env[1] = esi, env[2] = edi,
 *   env[3] = ebp, env[4] = esp (до вызова setjmp), env[5] = адрес возврата.
 *
 * longjmp(env, val): восстанавливает регистры и делает jmp на env[5] с
 * eax = val (0 заменяется на 1, как требует стандарт C). */
#include "setjmp.h"

#ifdef __i386__

__attribute__((returns_twice))
int setjmp(jmp_buf env)
{
    (void)env;   /* аргумент asm читает напрямую со стека (4(%esp)) */
    __asm__ volatile(
        "movl 4(%%esp), %%eax\n"     /* env */
        "movl %%ebx,  0(%%eax)\n"
        "movl %%esi,  4(%%eax)\n"
        "movl %%edi,  8(%%eax)\n"
        "movl %%ebp, 12(%%eax)\n"
        "leal 4(%%esp), %%ecx\n"     /* esp на момент вызова setjmp */
        "movl %%ecx, 16(%%eax)\n"
        "movl (%%esp), %%ecx\n"      /* адрес возврата */
        "movl %%ecx, 20(%%eax)\n"
        "xorl %%eax, %%eax\n"
        ::: "ecx", "memory", "cc");
    return 0;
}

__attribute__((noreturn))
void longjmp(jmp_buf env, int val)
{
    (void)env; (void)val;   /* аргументы asm читает напрямую со стека */
    __asm__ volatile(
        "movl 4(%%esp), %%eax\n"     /* env */
        "movl 8(%%esp), %%edx\n"     /* val */
        "movl  0(%%eax), %%ebx\n"
        "movl  4(%%eax), %%esi\n"
        "movl  8(%%eax), %%edi\n"
        "movl 12(%%eax), %%ebp\n"
        "movl 16(%%eax), %%esp\n"
        "testl %%edx, %%edx\n"
        "jnz 1f\n"
        "movl $1, %%edx\n"
        "1:\n"
        "jmp *20(%%eax)\n"
        ::: "eax", "edx", "memory");
    __builtin_unreachable();
}

#endif /* __i386__ */
