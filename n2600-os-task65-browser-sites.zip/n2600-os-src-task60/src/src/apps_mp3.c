/* apps_mp3.c — MP3-плеер N2600-OS (сессия 60, диалог сессии 63).
 *
 * Компактный проигрыватель: игра/пауза, стоп, ползунок позиции
 * (перетаскивание = поиск) и кнопка «Открыть…» — СТАНДАРТНЫЙ файловый
 * диалог ОС (filedlg, RAM/HDD/USB). Выбор любого .mp3 из папки делает
 * плейлистом ВСЮ папку — появляются кнопки «Пред»/«След» и счётчик
 * «N/M» (для FAT32 размеры/кластеры запоминаются при сканировании,
 * для RAM disk — из ramfs_list_dir).
 *
 * Декодирование — dr_mp3 (src/dr_mp3.h, основная библиотека ОС, см.
 * mp3svc.c) или libfoxenflac (Task 46, см. flacsvc.c) — формат
 * выбирается по магии файла ("fLaC")/расширению .flac; вывод —
 * потоковое воспроизведение sound_stream_chunk() (DMA-кольцо драйвера
 * переключается по кускам, щелчков нет; см. sound.h).
 *
 * FLAC: seek libfoxenflac не поддерживает — ползунок работает ТОЛЬКО
 * на просмотр (позиция/длительность из STREAMINFO), клик по дорожке
 * игнорируется; Стоп возвращает декодер на начало (flac_rewind —
 * fx_flac_reset, без перевыделения памяти).
 *
 * Архитектура: окно работает в СВОЕМ потоке WM (колбэки draw/key/mouse),
 * декодирование+подача звука — отдельная задача «mp3play» (task_spawn).
 * Обмен — только атомарные флаги/счётчики u32 в состоянии mp3p_t
 * (playing/quit/seek_req/played_out): u32 на i386 атомарен, u64 между
 * потоками не передаётся. Смена трека: задача останавливается (quit=1,
 * ожидание task_alive==0 — как в mp3p_close), после замены ctx/data
 * задача перезапускается (task_spawned=0).
 *
 * FPU: декодирование dr_mp3 идёт под общим FPU-локом imgsvc (внутри
 * mp3svc); ресэмплер и вся остальная логика — целочисленные.
 *
 * Открытие: файловый менеджер → двойной клик по .mp3 —
 * app_mp3_open_with(имя, данные, длина) с ПЕРЕДАЧЕЙ ВЛАДЕНИЯ буфером
 * (плеер сам его освобождает); из лаунчера — пустое окно с «Открыть…».
 *
 * Диалог (filedlg) отдаёт максимум FD_READ_MAX байт содержимого — для
 * mp3 этого мало, поэтому содержимое из колбэка освобождается, а файл
 * перечитывается ЦЕЛИКОМ (до MP3P_READ_MAX, как FM_MP3_READ_MAX в
 * fileman) по данным fd_pick_t: RAM disk — ramfs_read по пути; FAT32 —
 * fat32_find_entry по кластеру каталога (pick->cluster) + fat32_read_file.
 *
 * Сессия 91 (полевой отчёт: «кнопка играет долю секунды», «длительность
 * врёт», «плейлист без автоперехода»):
 *   1) [MP3-EDGE] кнопки срабатывали ДВАЖДЫ за клик: WM доставляет окну
 *      ОБА края ЛКМ (нажатие И отпускание, см. wm.c «отдаём отпускание
 *      приложению»), а блок кнопок фильтровал только changed без btn —
 *      press включал playing=1, release тут же выключал. Теперь канонный
 *      фильтр всех приложений: (changed && btn) — только край нажатия.
 *   2) [MP3-TOT] длительность — точный проход по заголовкам кадров
 *      (mp3svc.c), прежде CBR-формула по битрейту ПЕРВОГО кадра врала
 *      на VBR в обе стороны.
 *   3) [MP3-AUTO] автопереход плейлиста: EOF задачи ставит next_req,
 *      тик окна (2 Гц) включает следующий трек списка (циклически).
 */
#include "types.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sync.h"      /* [MP3-SINGLE] s_lock/s_unlock */
#include "apps.h"
#include "mp3svc.h"
#include "flacsvc.h"
#include "sound.h"
#include "mouse.h"
#include "kbd.h"
#include "filedlg.h"
#include "fat32.h"
#include "ramfs.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#define MP3P_W 460
#define MP3P_H 200

#define OUT_CHUNK 8192   /* выходных стерео-фреймов на кусок
                          * (186 мс @ 44.1 кГц / 171 мс @ 48 кГц;
                          * лимиты колец: ES137x 16384, HDA 8192) */
/* [MP3-CHUNK] входных фреймов на кусок — считаем ОТ куска выхода и
 * частоты файла (8192 при 48 кГц, ~7528 при 44.1 кГц): прежние
 * фиксированные 4608 (4 × 1152) покрывали лишь 56–61% куска — остаток
 * fill_out добивал повтором последнего сэмпла (DC), темп плыл,
 * стыки трещали, на 44.1 кГц файл играл на 0.56× скорости. */
#define MP3_IN_MAX (OUT_CHUNK + 16)

#define MP3P_READ_MAX (24u * 1024u * 1024u)  /* как FM_MP3_READ_MAX в fileman */
#define MP3P_LIST_MAX 64                     /* треков в плейлисте папки */

typedef struct {
    char name[64];
    u32  size;             /* размер файла (для malloc/чтения) */
    u32  cluster;          /* FAT32: первый кластер файла (0 = ramfs) */
} mp3p_item_t;

typedef struct {
    char     name[64];
    char    *data;             /* файл MP3/FLAC (владелец — плеер) */
    u32      len;
    void    *ctx;              /* opaque drmp3 ЛИБО контекст flacsvc
                                * (см. is_flac); 0 = трек не выбран */
    u8       is_flac;          /* 1 = декодер FLAC (flacsvc), 0 = dr_mp3 */
    u8       diag_seek;        /* FLAC: «seek недоступен» напечатан 1 раз */
    u32      chans;            /* каналов в файле: 1..2 */
    u32      rate;             /* частота файла, Гц */
    u32      total_frames;     /* оценка длительности, фреймов файла */
    u32      total_sec;        /* оценка длительности, секунд */
    /* --- разделяемое с задачей воспроизведения (только u32!) --- */
    volatile int  playing;
    volatile int  finished;     /* файл доигран до конца */
    volatile int  next_req;     /* [MP3-AUTO] EOF при активном плейлисте:
                                 * тик окна включит следующий трек */
    volatile int  quit;
    volatile int  task_alive;
    volatile int  task_spawned; /* защита от двойного task_spawn */
    volatile u32  task_seq;     /* [MP3-DIAG3] номер экземпляра задачи (лог) */
    u32           chunk_n;      /* [MP3-CHUNKCHK] счётчик кусков (суммы) */
    /* [MP3-DIAG4] диагностика НА ЭКЗЕМПЛЯР (прежде static на функцию:
     * первый за загрузку плеер печатал, остальные молчали) */
    u8            diag_first;   /* «первый кусок» уже напечатан */
    u8            diag_busy;    /* «поток занят» уже напечатан */
    u8            diag_neg1;    /* «stream_chunk = -1» уже напечатан */
    volatile u32  task_spawn_tick; /* [MP3-SPAWN2] тик запуска задачи */
    volatile int  stop_req;
    volatile int  seek_req;
    volatile u32  seek_frame;   /* цель поиска, фреймов файла */
    volatile u32  played_out;   /* выходных фреймов воспроизведено */
    int           dragging;     /* ползунок тащат (только поток окна) */
    window_t     *w;
    /* --- плейлист папки + диалог (поток окна; диалог — свой поток) --- */
    int           dlg;          /* открыт файловый диалог — ввод игнорировать */
    int           is_ram;       /* источник — RAM disk */
    u32           dir_cluster;  /* FAT32: кластер папки (0 = ramfs/нет) */
    char          dir[200];     /* путь папки (для ramfs) */
    mp3p_item_t   list[MP3P_LIST_MAX];
    int           list_n;
    int           list_cur;     /* текущий трек плейлиста (-1 = нет) */
} mp3p_t;

static void mp3p_open_dialog(mp3p_t *p);   /* вперед: системный диалог */

/* [MP3-SINGLE] (iteraciya 12) EDINSTVENNYJ ekzemplyar pleyera. Polevoj
 * log 12: dva okna pleyera (dvojnoj klik po drugomu MP3 v fajlovom
 * menedzhere) = dve zadachi nad ODNYM HDA-potokom: vtoraya poluchala -2
 * i gasila DMA pervoj cherez nichejnyj pause()/stop() — «slyshen tol'ko
 * tresk». Teper' otkrytie lyubogo MP3 podnimaet SUSHCHESTVUYUSHCHEE okno
 * i perestavlyaet trekk (mp3p_swap_track — tot zhe put', chto i dialog). */
static volatile int g_player_lock = 0;
static mp3p_t *g_player = 0;

/* [MP3-DIAG] отладка плеера (полевой тест: «mp3 вообще не проигрывается»
 * — по логу видно, спавнилась ли задача, декодирует ли она и есть ли
 * сигнал в выводе). [MP3-KLOG] (полевой лог итерации 11: в дампе dmesg
 * строки [mp3] ОТСУТСТВОВАЛИ — прежде печать шла только в serial,
 * мимо кольца klog, которое и копирует dmesg) — пишем В klog + serial,
 * одной строкой (serial_puts атомарен на строку, как в wifi_log). */
extern void serial_puts(const char *s);
extern void klog_puts(const char *s);
static void mp3p_logf(const char *fmt, ...)
{
    char b[176];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(b, sizeof(b), fmt, ap);
    __builtin_va_end(ap);
    char k[192];
    snprintf(k, sizeof(k), "[mp3] %s", b);
    serial_puts(k);
    serial_puts("\n");
    klog_puts(k);
}

/* ---------------- утилиты ---------------- */

static void mp3p_fmt_time(char *out, u32 n, u32 sec)
{
    snprintf(out, n, "%u:%02u", sec / 60u, sec % 60u);
}

/* имя кончается на «.ext»? (без учета регистра, как name_ext_is в fileman) */
static int mp3p_is_mp3(const char *name)
{
    int L = (int)strlen(name), el = 3;
    if (L <= el) return 0;
    const char *dot = name + L - el - 1;
    if (*dot != '.') return 0;
    for (int i = 0; i < el; i++) {
        char a = dot[1 + i], b = "mp3"[i];
        if (a >= 'A' && a <= 'Z') a += 32;
        if (a != b) return 0;
    }
    return 1;
}

/* .flac (без учета регистра)? */
static int mp3p_is_flac(const char *name)
{
    int L = (int)strlen(name), el = 4;
    if (L <= el) return 0;
    const char *dot = name + L - el - 1;
    if (*dot != '.') return 0;
    for (int i = 0; i < el; i++) {
        char a = dot[1 + i], b = "flac"[i];
        if (a >= 'A' && a <= 'Z') a += 32;
        if (a != b) return 0;
    }
    return 1;
}

/* аудиофайл плеера (.mp3/.flac) — для плейлиста папки */
static int mp3p_is_audio(const char *name)
{
    return mp3p_is_mp3(name) || mp3p_is_flac(name);
}

/* FLAC по содержимому (магия "fLaC") или по имени? */
static int mp3p_looks_flac(const char *name, const char *data, u32 len)
{
    if (len >= 4 && data[0] == 'f' && data[1] == 'L' &&
        data[2] == 'a' && data[3] == 'C') return 1;
    return mp3p_is_flac(name);
}

/* dir + "/" + name (или просто name, если dir = "/" или пуст) */
static void mp3p_join(char *out, int n, const char *dir, const char *name)
{
    if (!dir[0] || (dir[0] == '/' && !dir[1]))
        snprintf(out, (u32)n, "%s", name);
    else
        snprintf(out, (u32)n, "%s/%s", dir, name);
}

/* Заполнить выходной кусок РОВНО out_frames стерео-фреймов:
 * mono→stereo + линейный ресэмплер 16.16 (целочисленный, без FPU).
 * Если входа не хватило (конец файла) — добить тишиной. */
static void mp3p_fill_out(const i16 *in, u32 in_got, u32 chans,
                          u32 srate, u32 orate,
                          i16 *out, u32 out_frames)
{
    if (srate == orate) {
        for (u32 i = 0; i < out_frames; i++) {
            i16 l = 0, r = 0;
            if (in_got) {
                u32 j = (i < in_got) ? i : (in_got - 1);
                l = in[j * chans];
                r = (chans == 2) ? in[j * 2 + 1] : l;
            }
            out[2 * i]     = l;
            out[2 * i + 1] = r;
        }
        return;
    }
    u32 step = (u32)(((u64)srate << 16) / orate);
    u32 pos = 0;
    for (u32 i = 0; i < out_frames; i++) {
        i16 l = 0, r = 0;
        if (in_got) {
            u32 idx  = pos >> 16;
            u32 frac = pos & 0xFFFF;
            u32 j0 = (idx < in_got) ? idx : (in_got - 1);
            u32 j1 = (idx + 1 < in_got) ? idx + 1 : j0;
            i32 l0 = in[j0 * chans], l1 = in[j1 * chans];
            i32 r0 = (chans == 2) ? in[j0 * 2 + 1] : l0;
            i32 r1 = (chans == 2) ? in[j1 * 2 + 1] : l0;
            l = (i16)(l0 + (((l1 - l0) * (i32)frac) >> 16));
            r = (i16)(r0 + (((r1 - r0) * (i32)frac) >> 16));
            pos += step;
        }
        out[2 * i]     = l;
        out[2 * i + 1] = r;
    }
}

/* ---------------- задача воспроизведения ---------------- */

/* [MP3-FILECHK] целостность ФАЙЛА (полевой лог 16: кольцо идеально,
 * beep чист, а MP3 хрипит — проверяем СОДЕРЖИМОЕ: проход по заголовкам
 * MPEG-кадров от ID3-тега до конца; длина кадра считается из заголовка.
 * Порча на границах секторов/кластеров (NTFS-путь, усечение) даёт
 * десинки на регулярных смещениях — в логе видно по X%512/X%4096.) */
static void mp3_file_check(const u8 *d, u32 len)
{
    u32 pos = 0, frames = 0, bad = 0;
    u32 first_bad = 0xFFFFFFFFu;
    if (len > 10 && d[0] == 'I' && d[1] == 'D' && d[2] == '3') {
        u32 sz = ((u32)(d[6] & 0x7F) << 21) | ((u32)(d[7] & 0x7F) << 14) |
                 ((u32)(d[8] & 0x7F) << 7)  |  (u32)(d[9] & 0x7F);
        pos = 10 + sz;
        if (d[5] & 0x10) pos += 10;                  /* footer */
    }
    while (pos + 4 <= len && frames < 200000) {
        if (d[pos] == 0xFF && (d[pos + 1] & 0xE0) == 0xE0) {
            u8 h2 = d[pos + 1], h3 = d[pos + 2];
            u32 ver  = (h2 >> 3) & 3;                /* 3=MPEG1, 2=MPEG2, 0=2.5 */
            u32 layer= (h2 >> 1) & 3;                /* 1 = Layer III */
            u32 bri  = (h3 >> 4) & 0xF;
            u32 sri  = (h3 >> 2) & 3;
            u32 pad  = (h3 >> 1) & 1;
            static const u32 br1[16] = { 0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0 };
            static const u32 br2[16] = { 0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0 };
            static const u32 sr1[4]  = { 44100, 48000, 32000, 0 };
            u32 br = (ver == 3) ? br1[bri] : br2[bri];
            u32 sr = sr1[sri];
            if (ver == 2) sr /= 2;                   /* MPEG2 */
            else if (ver == 0) sr /= 4;              /* MPEG2.5 */
            if (br == 0 || sr == 0 || layer == 0) {  /* мусорный заголовок */
                if (first_bad == 0xFFFFFFFFu) first_bad = pos;
                bad++; pos++; continue;
            }
            /* [MP3-FILECHK2] длина кадра = 144000*kbps/sr (MPEG1, 1152
             * сэмплов) или 72000*kbps/sr (MPEG2/2.5, 576); битрейт тут в
             * КИЛОбитах/с, поэтому множитель ×1000: прежде «144*br/sr»
             * давало 0-1 байт и КАЖДЫЙ кадр считался десинком — отчёт
             * «файл ПОРЧЕН 100%» был ложным на любом целом файле. */
            u32 flen = (ver == 3 ? 144000u : 72000u) * br / sr + pad;
            if (flen < 4) {
                if (first_bad == 0xFFFFFFFFu) first_bad = pos;
                bad++; pos++; continue;
            }
            if (pos + flen > len) break;             /* нормальный хвост */
            frames++;
            pos += flen;
        } else {
            if (first_bad == 0xFFFFFFFFu) first_bad = pos;
            bad++; pos++;
        }
    }
    u32 total = frames + bad;
    char b[176];
    if (bad == 0)
        snprintf(b, sizeof(b),
                 "MP3: файл цел: кадров %u, десинков 0 (len=%u)",
                 frames, len);
    else
        snprintf(b, sizeof(b),
                 "MP3: ФАЙЛ ПОРЧЕН?: кадров %u, десинков %u из %u (%u%%), "
                 "первый @ %u (%%512=%u, %%4096=%u), len=%u",
                 frames, bad, total,
                 total ? bad * 100u / total : 0,
                 first_bad == 0xFFFFFFFFu ? 0u : first_bad,
                 (first_bad == 0xFFFFFFFFu ? 0u : first_bad) % 512u,
                 (first_bad == 0xFFFFFFFFu ? 0u : first_bad) % 4096u,
                 len);
    mp3p_logf("%s", b);
}

/* закрыть декодер текущего формата (без освобождения data) */
static void mp3p_close_ctx(mp3p_t *p)
{
    if (!p->ctx) return;
    if (p->is_flac) flac_close(p->ctx);
    else { mp3_close(p->ctx); free(p->ctx); }
    p->ctx = 0;
}

static void mp3p_task(void *arg)
{
    mp3p_t *p = (mp3p_t *)arg;
    p->task_alive = 1;

    /* [HDA-RATE] запрос частоты потока под ФАЙЛ: HDA ставит нативный
     * 44.1 кГц (файл 44.1 играет на своём ходе — прежде поток всегда
     * был 48 кГц и в нём всё звучало на 8.8% быстрее/выше). Возврат —
     * ФАКТИЧЕСКИЙ рейт (неподдержанный, напр. 8 кГц — 48000: тогда
     * ниже работает целочисленный ресэмплер). */
    u32 orate = sound_stream_set_rate(p->rate ? p->rate : 48000u);
    if (!orate) {
        /* [MP3-DIAG] звуковой поток недоступен — прежде выход был молчаливым */
        mp3p_logf("MP3: звуковой поток недоступен (rate=0) — воспроизведение невозможно");
        p->task_alive = 0;
        return;
    }

    i16 *stage = (i16 *)malloc((u32)MP3_IN_MAX * 2 * (u32)sizeof(i16));
    i16 *bufa  = (i16 *)malloc((u32)OUT_CHUNK * 2 * (u32)sizeof(i16));
    i16 *bufb  = (i16 *)malloc((u32)OUT_CHUNK * 2 * (u32)sizeof(i16));
    if (!stage || !bufa || !bufb) {
        /* [MP3-DIAG] отказ malloc — раньше задача умирала молча: «ползунок
         * не двигается» без единой строки в serial */
        mp3p_logf("MP3: задача умерла — malloc %s%s%s (%u+%u+%u б)",
                  stage ? "" : "stage ", bufa ? "" : "bufa ",
                  bufb ? "" : "bufb",
                  (unsigned)((u32)MP3_IN_MAX * 2 * (u32)sizeof(i16)),
                  (unsigned)((u32)OUT_CHUNK * 2 * (u32)sizeof(i16)),
                  (unsigned)((u32)OUT_CHUNK * 2 * (u32)sizeof(i16)));
        if (stage) free(stage);
        if (bufa)  free(bufa);
        if (bufb)  free(bufb);
        p->task_alive = 0;
        return;
    }

    int cur = 0;        /* какой из двух кусков готовится */
    int stream_on = 0;  /* DAC активен (не на паузе) */
    u32 chunk_ms = (u32)(((u64)OUT_CHUNK * 1000u) / orate);
    u32 next_t = 0;
    /* [MP3-DIAG3] однократный отчёт о старте воспроизведения, С НОМЕРОМ
     * экземпляра: две строки «стартовала» подряд в полевом логе итерации
     * 11 значили, что первая задача УМЕРЛА молча (путь выхода не логи-
     * ровался вовсе) — теперь виден и старт, и выход каждой задачи. */
    mp3p_logf("%s: задача #%u стартовала: rate=%u orate=%u chans=%u len=%u",
              p->is_flac ? "FLAC" : "MP3",
              (unsigned)p->task_seq,
              (unsigned)p->rate, (unsigned)orate, (unsigned)p->chans,
              (unsigned)p->len);
    /* [MP3-FILECHK] один проход по файлу (~1-3 мс на МиБ) — сразу видно,
     * цел ли файл, из которого декодирует плеер (только MP3: проход по
     * заголовкам MPEG-кадров к FLAC неприменим) */
    if (!p->is_flac && p->data && p->len >= 8)
        mp3_file_check((const u8 *)p->data, p->len);

    while (!p->quit) {
        if (p->stop_req) {
            p->stop_req = 0;
            p->playing = 0;
            p->finished = 0;
            p->played_out = 0;
            /* FLAC: seek нет — декодер сбрасывается на начало потока */
            if (p->is_flac) flac_rewind(p->ctx);
            else mp3_seek(p->ctx, 0);
            if (stream_on) { sound_stream_stop(); stream_on = 0; }
            if (p->w) win_invalidate(p->w);
            continue;
        }
        if (p->seek_req) {
            p->seek_req = 0;
            if (p->is_flac) {
                /* libfoxenflac не умеет позиционирование: в начало —
                 * умеем (rewind), в середину — нет */
                if (p->seek_frame == 0) {
                    flac_rewind(p->ctx);
                    p->played_out = 0;
                } else if (!p->diag_seek) {
                    p->diag_seek = 1;
                    mp3p_logf("FLAC: позиционирование недоступно "
                              "(libfoxenflac) — ползунок только на просмотр");
                }
            } else {
                mp3_seek(p->ctx, p->seek_frame);
                p->played_out = (u32)(((u64)p->seek_frame * orate) /
                                      (p->rate ? p->rate : orate));
            }
            if (p->w) win_invalidate(p->w);
        }
        if (!p->playing) {
            if (stream_on) { sound_stream_pause(1); stream_on = 0; }
            task_msleep(30);
            next_t = 0;                       /* после паузы — заново */
            continue;
        }

        if (!stream_on) {
            if (p->finished) { p->playing = 0; continue; }
            sound_stream_pause(0);
            stream_on = 1;
            next_t = 0;
        }

        /* темп: кусок стартует каждые ~90% chunk_ms — 10% запаса под
         * джиттер планировщика, при опоздании кольцо просто долистает */
        if (!next_t) next_t = timer_ticks();
        if ((i32)(timer_ticks() - next_t) < 0) {
            task_msleep(1);
            continue;
        }
        next_t += chunk_ms - chunk_ms / 10;
        if ((i32)(timer_ticks() - next_t) > (i32)chunk_ms)
            next_t = timer_ticks();           /* сильно отстали — заново */

        /* [MP3-CHUNK] декодируем РОВНО вход на кусок выхода (дробный шаг
         * — по 1 фрейму в хвосте), EOF раньше нормы — fill_out добьёт
         * хвост конца файла. p->chans==0 страхуемся двойкой. */
        u32 chans  = p->chans ? p->chans : 2;
        u32 srate  = p->rate ? p->rate : orate;
        u32 need_in = (u32)(((u64)OUT_CHUNK * srate + orate - 1) / orate) + 2u;
        if (need_in > MP3_IN_MAX) need_in = MP3_IN_MAX;
        u32 got = 0;
        u32 t_dec0 = timer_ticks();          /* [MP3-DIAG3] время декода */
        while (got < need_in) {
            /* FLAC — целочисленный libfoxenflac (flacsvc), MP3 — dr_mp3;
             * оба отдают s16 interleaved в один stage-буфер */
            u32 g = p->is_flac
                ? flac_read_s16(p->ctx, stage + got * chans, need_in - got)
                : mp3_read_s16(p->ctx, stage + got * chans, need_in - got);
            if (g == 0) break;
            got += g;
        }
        u32 dec_ms = timer_ticks() - t_dec0;
        if (got == 0) {
            /* [MP3-DIAG5] «некоторые файлы тут же ставятся на паузу» —
             * это ветка EOF на ПЕРВОМ куске. Печатаем до 3 раз за загрузку
             * С МАГИЕЙ файла: «ID3x» = только тег/обрезок, FF Fx = кадр
             * MPEG. Прежде печатали один раз и без деталей. */
            static int s_eof_logged = 0;
            if (s_eof_logged < 3) {
                s_eof_logged++;
                u8 m0 = 0, m1 = 0, m2 = 0, m3 = 0;
                if (p->data && p->len >= 4) {
                    m0 = (u8)p->data[0]; m1 = (u8)p->data[1];
                    m2 = (u8)p->data[2]; m3 = (u8)p->data[3];
                }
                mp3p_logf("MP3: декодер вернул 0 (конец/ошибка) — len=%u rate=%u chans=%u магия=%02x %02x %02x %02x",
                          (unsigned)p->len, (unsigned)p->rate, (unsigned)p->chans,
                          m0, m1, m2, m3);
            }
            p->finished = 1;
            p->playing = 0;
            if (stream_on) { sound_stream_stop(); stream_on = 0; }
            /* [MP3-AUTO] трек доиграл при активном плейлисте — просим окно
             * включить следующий (сам задача сменить трек не может: swap
             * ждёт её смерти). Тик окна подхватит не позже 0.5 с. */
            if (p->list_n > 1) p->next_req = 1;
            if (p->w) win_invalidate(p->w);
            continue;
        }
        mp3p_fill_out(stage, got, chans, srate, orate,
                      cur ? bufb : bufa, OUT_CHUNK);
        /* [MP3-CHUNKCHK] контрольные суммы первых кусков декода:
         * воспроизведение того же файла должно дать ТЕ ЖЕ суммы
         * (детерминизм декода/FPU); сверяем со строками [sndtest] */
        if (p->chunk_n < 3) {
            u32 cs = 0;
            const i16 *s = cur ? bufb : bufa;
            for (u32 i = 0; i < OUT_CHUNK * 2u; i++)
                cs = cs * 31u + (u32)(u16)s[i];
            mp3p_logf("MP3: кусок %u cs=%08x (декод)", p->chunk_n, cs);
        }
        p->chunk_n++;
        /* [MP3-DIAG] амплитуда ПЕРВОГО куска: 0 = тишина в декодере/
         * ресэмплере (для отличия «нет сигнала» от «сигнал есть, тракт
         * глух»); заодно логируем результат sound_stream_chunk */
        {
            /* [MP3-DIAG4] флаги НА ЭКЗЕМПЛЯР (mp3p_t), не static */
            int src;
            i16 *outc = cur ? bufb : bufa;
            src = sound_stream_chunk(outc, OUT_CHUNK);
            if (src == -2) {
                /* [MP3-DIAG3] HDA-поток занят ДРУГОЙ задачей плеера */
                if (!p->diag_busy) {
                    p->diag_busy = 1;
                    mp3p_logf("MP3: звуковой поток занят другим плеером — воспроизведение остановлено (Stop в нём)");
                }
                p->playing = 0;
                continue;
            }
            if (src == -1 && !p->diag_neg1) {
                /* [MP3-DIAG4] -1 = переполнение/ошибка DMA — прежде
                 * молча продолжали слать куски */
                p->diag_neg1 = 1;
                mp3p_logf("MP3: stream_chunk вернул -1 (переполнение/ошибка драйвера)");
            }
            if (!p->diag_first) {
                p->diag_first = 1;
                i32 mx = 0;
                for (u32 i = 0; i < OUT_CHUNK * 2u; i++) {
                    i32 a = outc[i] < 0 ? -(i32)outc[i] : (i32)outc[i];
                    if (a > mx) mx = a;
                }
                mp3p_logf("MP3: первый кусок: got=%u/%u фреймов, ампл.=%d, декод=%u мс, stream_chunk=%d",
                          (unsigned)got, (unsigned)need_in, (int)mx,
                          (unsigned)dec_ms, src);
            }
            if (src == 0)
                stream_on = 1;
        }
        p->played_out += OUT_CHUNK;
        cur ^= 1;
    }

    if (stream_on) sound_stream_stop();
    free(stage);
    free(bufa);
    free(bufb);
    /* [MP3-DIAG3] выход задачи теперь ВИДЕН в логе: полевой лог 11
     * показывал вторую «стартовала» без предшествующего события — причина
     * смерти задачи была невидима (exit по quit=1 не логировался) */
    mp3p_logf("MP3: задача #%u завершена (quit=%d)",
              (unsigned)p->task_seq, (int)p->quit);
    p->task_alive = 0;
    p->task_spawned = 0;   /* [MP3-SPAWN]: разрешаем следующий спавн */
}

static void mp3p_ensure_task(mp3p_t *p)
{
    static volatile u32 s_seq = 0;   /* [MP3-DIAG3] счётчик экземпляров */
    /* task_spawned ставится ДО spawn: два быстрых клика не должны
     * породить вторую задачу над тем же состоянием (двойной free).
     * [MP3-SPAWN] (полевой лог итерации 10: «mp3 вообще не проигрывается,
     * ползунок не двигается»): ПОСЛЕ остановки (Stop/смена трека не через
     * swap) задача выходила с task_alive=0, но task_spawned оставался 1 —
     * ensure_task навсегда отказывался спавнить — UI мёртв до смены трека.
     * 1) сброс latch при выходе задачи (см. конец mp3p_task);
     * 2) проверяем результат task_spawn (слот/стек могли кончиться — с
     *    итерации 7 добавился telnetd и его клиенты); при неудаче latch
     *    сбрасываем и логируем — следующий клик попробует снова. */
    if (p->ctx && !p->task_alive && sound_stream_rate()) {
        /* [MP3-SPAWN2] (разбор полевого лога 13): между task_spawn и
         * task_alive=1 (первая строка задачи) есть окно. Повторный
         * вызов в этом окне видел task_spawned=1, «чинил latch» и
         * спавнил ВТОРУЮ задачу над тем же mp3p_t. Окно < 500 мс —
         * считаем spawn «в полёте» и выходим. */
        if (p->task_spawned &&
            (u32)(timer_ticks() - p->task_spawn_tick) < 500u)
            return;
        if (p->task_spawned) {
            /* latch протек (задача умерла без сброса) — чиним и логируем */
            p->task_spawned = 0;
            mp3p_logf("MP3: перезапуск задачи плеера (latch после смерти задачи)");
        }
        p->task_spawned = 1;
        p->task_spawn_tick = timer_ticks();   /* [MP3-SPAWN2] */
        p->task_seq = ++s_seq;
        /* [MP3-PRIO] (полевой лог 14: треск при одновременном WiFi-скане):
         * плеер — задача почти реального времени (кусок 170 мс, декод
         * ~12 мс, а у BG-задач бюджет 1 тик из 250) — поднимаем до UI:
         * при декоде ~7% CPU это безопасно, и flow control кольца HDA
         * больше не упирается в голодание задачи */
        int rc = task_spawn_prio("mp3play", mp3p_task, p, TASK_PRIO_UI);
        if (rc < 0) {
            p->task_spawned = 0;
            mp3p_logf("MP3: task_spawn не удался (%d) — нет слота/стека, повтор на следующем клике", rc);
        }
    } else if (p->ctx && !p->task_alive && !sound_stream_rate()) {
        /* [MP3-DIAG] Play при мёртвом аудио-тракте — прежде молчаливо игнорировался */
        mp3p_logf("MP3: Play без звукового потока (rate=0) — аудио-тракт не поднят");
    }
}

static void mp3p_toggle(mp3p_t *p)
{
    if (!p->ctx) {                           /* трек не выбран — диалог */
        mp3p_open_dialog(p);
        return;
    }
    if (p->finished) {                       /* повтор с начала */
        p->finished = 0;
        p->next_req = 0;                     /* [MP3-AUTO] явно включили — не переставлять трек */
        p->played_out = 0;
        p->seek_frame = 0;
        p->seek_req = 1;
        p->playing = 1;
        mp3p_ensure_task(p);
        return;
    }
    p->playing = !p->playing;
    mp3p_ensure_task(p);
}

static void mp3p_do_stop(mp3p_t *p)
{
    p->playing = 0;
    p->finished = 0;
    p->next_req = 0;                     /* [MP3-AUTO] Стоп — автопереход отменён */
    p->played_out = 0;
    if (p->task_alive) {
        p->stop_req = 1;                     /* остановит DAC и задачу */
    } else if (p->ctx) {
        /* задача не бежит — сами; FLAC — сброс декодера (seek нет) */
        if (p->is_flac) flac_rewind(p->ctx);
        else mp3_seek(p->ctx, 0);
        sound_stream_stop();
    }
}

/* ---------------- смена трека / плейлист ---------------- */

/* Остановить задачу и заменить трек в ТЕМ ЖЕ состоянии/окне.
 * data — владение переходит плееру (в т.ч. при ошибке открытия).
 * 0 = ок, -1 = не удалось (задача не остановилась / bad mp3). */
static int mp3p_swap_track(mp3p_t *p, const char *name, char *data, u32 len)
{
    p->playing = 0;
    if (p->task_alive) {
        p->quit = 1;                         /* задача сама остановит DAC */
        int waited = 0;
        while (p->task_alive && waited < 1500) { task_msleep(5); waited += 5; }
        if (p->task_alive) return -1;        /* не дождались — ничего не меняем */
    }
    if (p->ctx) mp3p_close_ctx(p);
    if (p->data) { free(p->data); p->data = 0; }

    p->quit = 0; p->finished = 0; p->played_out = 0;
    p->seek_req = 0; p->seek_frame = 0; p->stop_req = 0;
    p->next_req = 0;                     /* [MP3-AUTO] */
    p->task_spawned = 0; p->dragging = 0;
    p->chunk_n = 0;                 /* [MP3-CHUNKCHK] */
    p->diag_seek = 0;                /* [FLAC] подсказка — раз на трек */

    if (name) {
        strncpy(p->name, name, sizeof(p->name) - 1);
        p->name[sizeof(p->name) - 1] = 0;
    }
    p->data = data;
    p->len = len;

    /* [FLAC] формат — по магии "fLaC"/расширению: у FLAC контекст
     * создаётся внутри flacsvc (malloc), у MP3 — как раньше */
    p->is_flac = mp3p_looks_flac(name, data, len) ? 1 : 0;
    if (p->is_flac) {
        p->ctx = flac_open_mem(data, len);
        if (!p->ctx) {
            const char *err = flac_errstr();
            snprintf(p->name, sizeof(p->name), "%s: %s",
                     name ? name : "?", err ? err : "не удалось открыть");
            p->data = 0; p->len = 0;
            free(data);
            return -1;
        }
    } else {
        p->ctx = malloc(MP3_CTX_SIZE);
        if (!p->ctx || !mp3_open_mem(data, len, p->ctx)) {
            const char *err = mp3_errstr();
            snprintf(p->name, sizeof(p->name), "%s: %s",
                     name ? name : "?", err ? err : "не удалось открыть");
            if (p->ctx) { free(p->ctx); p->ctx = 0; }
            p->data = 0; p->len = 0;
            free(data);
            return -1;
        }
    }
    if (p->is_flac) {
        p->chans = flac_channels(p->ctx);
        p->rate  = flac_rate(p->ctx);
        u64 tf   = flac_total_frames(p->ctx);   /* STREAMINFO, без декода */
        p->total_frames = (u32)tf;
        p->total_sec = p->rate ? (u32)(tf / p->rate) : 0;
    } else {
        p->chans = mp3_channels(p->ctx);
        p->rate = mp3_rate(p->ctx);
        u64 tf = mp3_total_frames_estimate(p->ctx);
        p->total_frames = (u32)tf;
        p->total_sec = p->rate ? (u32)(tf / p->rate) : 0;
    }
    return 0;
}

/* Прочитать трек плейлиста целиком (malloc; 0 = не удалось). */
static char *mp3p_read_item(mp3p_t *p, int idx, u32 *out_len)
{
    if (idx < 0 || idx >= p->list_n) return 0;
    u32 cap = p->list[idx].size;
    if (!cap) return 0;
    if (cap > MP3P_READ_MAX) cap = MP3P_READ_MAX;
    char *buf = (char *)malloc(cap);
    if (!buf) return 0;
    u32 got;
    if (p->dir_cluster) {
        got = fat32_read_file(p->list[idx].cluster, p->list[idx].size,
                              buf, cap);
    } else {
        char path[224];
        mp3p_join(path, sizeof(path), p->dir, p->list[idx].name);
        got = ramfs_read(path, buf, cap);
    }
    if (!got) { free(buf); return 0; }
    *out_len = got;
    return buf;
}

/* Включить трек плейлиста по индексу (с циклическим переходом). */
static void mp3p_play_index(mp3p_t *p, int idx)
{
    if (!p->list_n || p->dlg) return;
    if (idx < 0) idx = p->list_n - 1;
    if (idx >= p->list_n) idx = 0;
    p->list_cur = idx;
    u32 len;
    char *data = mp3p_read_item(p, idx, &len);
    if (!data) return;
    if (mp3p_swap_track(p, p->list[idx].name, data, len) == 0) {
        p->playing = 1;
        mp3p_ensure_task(p);
    }
    if (p->w) win_invalidate(p->w);
}

/* Сканировать папку выбранного файла на .mp3 → плейлист. */
static void mp3p_scan_folder(mp3p_t *p, const fd_pick_t *pick)
{
    p->list_n = 0;
    p->list_cur = -1;
    p->next_req = 0;                 /* [MP3-AUTO] старый запрос — к новой папке неприменим */
    p->is_ram = (pick->source == FD_SRC_RAMFS);
    p->dir_cluster = p->is_ram ? 0 : pick->cluster;
    snprintf(p->dir, sizeof(p->dir), "%s", pick->dir);

    /* списки каталогов — в куче (fat32_dirent_t ~272 Б, на стеке задачи
     * окна 32 КБ много записей не удержать) */
    fat32_dirent_t *fents = (fat32_dirent_t *)malloc(sizeof(fat32_dirent_t) * 80);
    ramfs_dirent_t *rents = (ramfs_dirent_t *)malloc(sizeof(ramfs_dirent_t) * 80);
    if (!fents || !rents) {
        if (fents) free(fents);
        if (rents) free(rents);
        return;
    }
    if (!p->is_ram && pick->cluster) {
        int n = fat32_list(pick->cluster, fents, 80);
        for (int i = 0; i < n && p->list_n < MP3P_LIST_MAX; i++) {
            if (fents[i].attr & 0x10) continue;              /* каталог */
            if (!mp3p_is_audio(fents[i].name)) continue;
            mp3p_item_t *it = &p->list[p->list_n++];
            strncpy(it->name, fents[i].name, sizeof(it->name) - 1);
            it->name[sizeof(it->name) - 1] = 0;
            it->size = fents[i].size;
            it->cluster = fents[i].first_cluster;
        }
    } else if (p->is_ram) {
        int n = ramfs_list_dir(pick->dir, rents, 80);
        for (int i = 0; i < n && p->list_n < MP3P_LIST_MAX; i++) {
            if (rents[i].is_dir) continue;
            if (!mp3p_is_audio(rents[i].name)) continue;
            mp3p_item_t *it = &p->list[p->list_n++];
            strncpy(it->name, rents[i].name, sizeof(it->name) - 1);
            it->name[sizeof(it->name) - 1] = 0;
            it->size = rents[i].size;
            it->cluster = 0;
        }
    }
    free(fents);
    free(rents);
}

/* ---------------- системный файловый диалог ---------------- */

static void mp3p_open_cancel(void *ctx)
{
    ((mp3p_t *)ctx)->dlg = 0;
}

static void mp3p_open_ok(void *ctx, const fd_pick_t *pick, char *content, int len)
{
    mp3p_t *p = (mp3p_t *)ctx;
    if (content) { free(content); content = 0; }     /* перечитаем целиком */
    (void)len;

    mp3p_scan_folder(p, pick);

    /* текущий трек — выбранный в диалоге файл */
    int idx = 0;
    for (int i = 0; i < p->list_n; i++)
        if (strcmp(p->list[i].name, pick->name) == 0) { idx = i; break; }
    p->list_cur = idx;

    u32 flen;
    char *data = mp3p_read_item(p, idx, &flen);
    if (data && mp3p_swap_track(p, p->list[idx].name, data, flen) == 0) {
        p->playing = 1;
        mp3p_ensure_task(p);
    }
    p->dlg = 0;                                      /* ввод снова активен */
    if (p->w) win_invalidate(p->w);
}

static void mp3p_open_dialog(mp3p_t *p)
{
    if (p->dlg) return;
    p->dlg = 1;
    filedlg_open("Открыть аудио", ".mp3,.flac", NULL,
                 mp3p_open_ok, mp3p_open_cancel, p);
}

/* ---------------- окно плеера ---------------- */

/* [MP3-STRETCH] (Task 54): интерфейс РАСТЯГИВАЮЩИЙСЯ — геометрия всех
 * рядов считается ОТ ФАКТИЧЕСКОГО РАЗМЕРА окна при каждой отрисовке и
 * клике (раньше ряды были прибиты к константам 92/130/166, и при
 * resize/maximize плеер оставался «компактным» в левом верхнем углу,
 * не занимая отведённое пространство). Одна функция считает раскладку
 * для draw И mouse — попадания кликов всегда совпадают с картинкой. */
typedef struct {
    int tx, ty, tw, th;      /* ползунок позиции */
    int by, bh;              /* ряд основных кнопок (играть/стоп/открыть) */
    int bx[3], bw[3];        /* их x и ширины */
    int ly, lh;              /* ряд плейлиста (пред/след + счётчик) */
    int lx[2], lw[2];        /* кнопки пред/след */
    int cx3;                 /* начало зоны счётчика/имени трека */
    int sy;                  /* статусная строка */
} mp3p_layout_t;

static void mp3p_layout_list(window_t *w, mp3p_layout_t *L); /* fwd */

static void mp3p_layout(window_t *w, mp3p_layout_t *L)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    int m = 24;                       /* боковые поля */

    /* снизу вверх: статус -> плейлист -> кнопки; при нехватке высоты
     * ряды «съезжаются» вниз и подрезаются клипом canvas — без краха */
    L->sy = ch - 20;
    L->ly = ch - 58;  L->lh = 26;
    L->by = ch - 98;  L->bh = 28;

    /* ползунок: во всю ширину между шапкой и кнопками */
    L->tx = m; L->tw = cw - 2 * m;
    L->ty = 58; L->th = 8;
    if (L->tw < 40) { L->tx = 0; L->tw = cw > 40 ? cw : 40; }

    /* основные кнопки: равные доли ширины, последняя добирает остаток */
    int gap = 12;
    int avail = cw - 2 * m - 2 * gap;
    int bw = avail / 3;
    if (bw < 56) bw = 56;
    L->bx[0] = m;        L->bw[0] = bw;
    L->bx[1] = m + bw + gap;        L->bw[1] = bw;
    L->bx[2] = m + 2 * (bw + gap);
    L->bw[2] = cw - m - L->bx[2];
    if (L->bw[2] < 56) L->bw[2] = 56;

    mp3p_layout_list(w, L);
}

/* хелпер ряда плейлиста; вызывается из mp3p_layout (draw и mouse)
 * считают раскладку ОДНИМ вызовом mp3p_layout */
static void mp3p_layout_list(window_t *w, mp3p_layout_t *L)
{
    int cw = win_content_w(w);
    int m = 24, gap = 12;
    int bw = (cw - 2 * m - 2 * gap - 90) / 2;
    if (bw < 56) bw = 56;
    L->lx[0] = m;             L->lw[0] = bw;
    L->lx[1] = m + bw + gap;  L->lw[1] = bw;
    L->cx3 = L->lx[1] + bw + gap;
}

static void mp3p_draw(window_t *w)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    u32 bg = wm_theme_win_bg();
    fb_fill_rect(0, 0, cw, ch, bg);

    /* [MP3-STRETCH] единая раскладка под ТЕКУЩИЙ размер окна */
    mp3p_layout_t L;
    mp3p_layout(w, &L);

    /* имя файла */
    wm_text_fit(10, 8, p->name, cw - 20, wm_theme_text_dim(), 0);

    /* время */
    u32 orate = sound_stream_rate();
    u32 played_sec = orate ? p->played_out / orate : 0;
    if (p->total_sec && played_sec > p->total_sec) played_sec = p->total_sec;
    char t1[16], t2[16], line[40];
    mp3p_fmt_time(t1, sizeof(t1), played_sec);
    mp3p_fmt_time(t2, sizeof(t2), p->total_sec);
    snprintf(line, sizeof(line), "%s / %s", t1, t2);
    fb_text(cw / 2 - (int)fb_text_w(line) / 2, 32, line, wm_theme_text(), -1);

    /* ползунок позиции (на всю ширину окна) */
    int tx = L.tx, tw = L.tw, ty = L.ty, th = L.th;
    fb_fill_rect(tx, ty, tw, th, wm_theme_win_bg_alt());
    fb_rect(tx, ty, tw, th, wm_theme_text_dim());
    if (p->total_sec) {
        int fw = (int)(((u64)tw * played_sec) / p->total_sec);
        if (fw > tw) fw = tw;
        if (fw > 0) fb_fill_rect(tx, ty, fw, th, wm_theme_accent());
        int kx = tx + fw - 5;
        if (kx < tx) kx = tx;
        if (kx > tx + tw - 10) kx = tx + tw - 10;
        fb_fill_rect(kx, ty - 4, 10, th + 8, wm_theme_accent());
        fb_rect(kx, ty - 4, 10, th + 8, wm_theme_text());
    }

    /* кнопки: игра/пауза + стоп + открыть — растянуты по ширине ряда */
    wm_button_draw(L.bx[0], L.by, L.bw[0], L.bh, p->playing ? "Пауза" : "Играть",
                   wm_theme_win_bg_alt(), wm_theme_text(), wm_theme_text_dim());
    wm_button_draw(L.bx[1], L.by, L.bw[1], L.bh, "Стоп",
                   wm_theme_win_bg_alt(), wm_theme_text(), wm_theme_text_dim());
    wm_button_draw(L.bx[2], L.by, L.bw[2], L.bh, "Открыть…",
                   wm_theme_win_bg_alt(), wm_theme_accent(), wm_theme_text_dim());

    /* плейлист папки: пред/след + счётчик + имя трека */
    if (p->list_n > 0) {
        wm_button_draw(L.lx[0], L.ly, L.lw[0], L.lh, "◀ Пред",
                       wm_theme_win_bg_alt(), wm_theme_text(),
                       wm_theme_text_dim());
        wm_button_draw(L.lx[1], L.ly, L.lw[1], L.lh, "След ▶",
                       wm_theme_win_bg_alt(), wm_theme_text(),
                       wm_theme_text_dim());
        snprintf(line, sizeof(line), "%d / %d", p->list_cur + 1, p->list_n);
        fb_text(L.cx3, L.ly + 6, line, wm_theme_accent(), -1);
        wm_text_fit(L.cx3 + (int)fb_text_w(line) + 10, L.ly + 6,
                    p->list[p->list_cur].name,
                    cw - (L.cx3 + (int)fb_text_w(line) + 10) - 10,
                    wm_theme_text_dim(), 0);
    }

    /* статусная строка (у нижнего края, на всю ширину) */
    char st[96];
    if (!orate)
        snprintf(st, sizeof(st), "Звуковое устройство не найдено");
    else if (!p->ctx)
        snprintf(st, sizeof(st), "Файл не выбран — «Открыть…» или клавиша O");
    else if (p->finished)
        snprintf(st, sizeof(st), "Готово. «Играть» — ещё раз");
    else if (p->is_flac)
        snprintf(st, sizeof(st),
                 "FLAC (libfoxenflac) • файл %u Гц %s %u бит • выход %u Гц • seek нет",
                 p->rate, p->chans == 2 ? "stereo" : "mono",
                 (unsigned)flac_bps(p->ctx), orate);
    else
        snprintf(st, sizeof(st), "dr_mp3 • файл %u Гц %s • выход %u Гц",
                 p->rate, p->chans == 2 ? "stereo" : "mono", orate);
    wm_text_fit(24, L.sy, st, cw - 48, wm_theme_text_dim(), 0);
    (void)ch;
}

static void mp3p_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    if (p->dlg) { p->dragging = 0; return; }     /* открыт диалог — ввод не наш */
    if (mx < 0 || my < 0) { p->dragging = 0; return; }

    /* [MP3-STRETCH] попадания — по той же раскладке, что и отрисовка */
    mp3p_layout_t L;
    mp3p_layout(w, &L);
    int tx = L.tx, tw = L.tw, ty = L.ty, th = L.th;

    /* ползунок: клик и перетаскивание по дорожке (с допуском по вертикали).
     * FLAC — только просмотр: позиционирования у libfoxenflac нет. */
    if (!p->is_flac && my >= ty - 6 && my <= ty + th + 6 &&
        mx >= tx && mx <= tx + tw) {
        if (btn & MSB_LEFT) {
            p->dragging = 1;
            if (p->total_frames && !p->finished && p->ctx) {
                int rel = mx - tx;
                if (rel < 0) rel = 0;
                if (rel > tw) rel = tw;
                p->seek_frame = (u32)(((u64)(u32)rel * p->total_frames) / (u32)tw);
                p->seek_req = 1;
            }
            win_invalidate(w);
        }
    } else if (p->dragging && !(btn & MSB_LEFT)) {
        p->dragging = 0;
    }

    /* [MP3-EDGE] ТОЛЬКО край нажатия: WM доставляет окну ОБА края ЛКМ
     * (нажатие и отпускание — wm.c «отдаём отпускание приложению»),
     * фильтр «changed без btn» давал ДВА срабатывания за клик: «Играть»
     * становилось «Пауза» и тут же обратно — трек играл долю секунды.
     * Канонный фильтр всех приложений ОС — (changed && btn). */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        if (wm_button_hit(mx, my, L.bx[0], L.by, L.bw[0], L.bh)) {
            mp3p_toggle(p);
            win_invalidate(w);
        } else if (wm_button_hit(mx, my, L.bx[1], L.by, L.bw[1], L.bh)) {
            mp3p_do_stop(p);
            win_invalidate(w);
        } else if (wm_button_hit(mx, my, L.bx[2], L.by, L.bw[2], L.bh)) {
            mp3p_open_dialog(p);
        } else if (p->list_n > 0
                   && wm_button_hit(mx, my, L.lx[0], L.ly, L.lw[0], L.lh)) {
            mp3p_play_index(p, p->list_cur - 1);
        } else if (p->list_n > 0
                   && wm_button_hit(mx, my, L.lx[1], L.ly, L.lw[1], L.lh)) {
            mp3p_play_index(p, p->list_cur + 1);
        }
    }
}

static void mp3p_key(window_t *w, const key_event_t *ev)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    if (p->dlg) return;                          /* диалог сам разбирает ввод */
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == 0x39) {                     /* Space: игра/пауза */
        mp3p_toggle(p);
        win_invalidate(w);
        return;
    }
    if (ev->ch == 'O' || ev->ch == 'o') {       /* открыть файл/папку */
        mp3p_open_dialog(p);
        return;
    }
    if (p->list_n > 0) {
        if (ev->code == KBD_LEFT)  { mp3p_play_index(p, p->list_cur - 1); return; }
        if (ev->code == KBD_RIGHT) { mp3p_play_index(p, p->list_cur + 1); return; }
    }
}

static void mp3p_tick(window_t *w)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    /* [MP3-AUTO] автопереход плейлиста: трек доиграл (EOF задачи поставил
     * next_req) — включаем следующий трек списка (циклически). Тик 2 Гц:
     * пауза между треками до ~0.5 с + чтение файла. */
    if (p->next_req && !p->dlg) {
        p->next_req = 0;
        mp3p_play_index(p, p->list_cur + 1);
        return;                      /* play_index сам инвалидирует окно */
    }
    win_invalidate(w);          /* 2 Гц: ход ползунка/времени */
}

static void mp3p_close(window_t *w)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    s_lock(&g_player_lock);              /* [MP3-SINGLE] */
    if (g_player == p) g_player = 0;
    s_unlock(&g_player_lock);
    p->quit = 1;
    int waited = 0;
    while (p->task_alive && waited < 1500) { task_msleep(5); waited += 5; }
    mp3p_close_ctx(p);
    if (p->data) free(p->data);
    free(p);
}

/* ---------------- точки входа ---------------- */

/* Создать окно плеера над уже заполненным состоянием. */
static void mp3p_create_window(mp3p_t *p)
{
    u32 W = fb_width(), H = fb_height();
    int ww = MP3P_W, wh = MP3P_H;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - 28) wh = (int)H - 28;
    char title[80];
    snprintf(title, sizeof(title), "Плеер: %s", p->name);
    p->w = win_create(title, 80, 60, ww, wh,
                      mp3p_draw, mp3p_key, mp3p_mouse, mp3p_tick, mp3p_close, p);
}

/* Открыть MP3 из памяти (владение буфером data переходит плееру). */
void app_mp3_open_with(const char *name, const char *data, u32 len)
{
    if (!data || len == 0) {
        if (data) free((void *)data);
        app_outwin_open("Аудиоплеер", "Файл пуст.\n", 11);
        return;
    }

        /* [MP3-SINGLE]: pleyer uzhe otkryt - podnimaem okno i perestavlyaem
     * trekk; vtoroe okno ne sozdayotsya nikogda */
    s_lock(&g_player_lock);
    mp3p_t *ex = g_player;
    if (ex) {
        wm_raise(ex->w);
        if (mp3p_swap_track(ex, name, (char *)data, len) == 0) {
            ex->playing = 1;
            mp3p_ensure_task(ex);
        } else {
            free((void *)data);   /* swap не принял — владение осталось у нас */
        }
        if (ex->w) win_invalidate(ex->w);
        s_unlock(&g_player_lock);
        return;
    }
    s_unlock(&g_player_lock);

    mp3p_t *p = (mp3p_t *)malloc(sizeof(mp3p_t));
    if (!p) { free((void *)data); return; }
    memset(p, 0, sizeof(mp3p_t));

    if (name && name[0]) {
        strncpy(p->name, name, sizeof(p->name) - 1);
        p->name[sizeof(p->name) - 1] = 0;
    } else {
        strcpy(p->name, "track.mp3");
    }
    p->data = (char *)data;      /* владение буфером — у плеера */
    p->len = len;

    /* [FLAC] формат — по магии/расширению (swap_track делал бы то же,
     * но здесь трек ещё не в плейлисте — открываем напрямую) */
    p->is_flac = mp3p_looks_flac(p->name, data, len) ? 1 : 0;
    if (p->is_flac) {
        p->ctx = flac_open_mem(data, len);
        if (!p->ctx) {
            const char *err = flac_errstr();
            char msg[128];
            int n = snprintf(msg, sizeof(msg), "%s: %s\n", p->name,
                             err ? err : "не удалось открыть");
            free(p->data);
            free(p);
            app_outwin_open("Аудиоплеер", msg, (u32)(n > 0 ? n : 0));
            return;
        }
    } else {
        p->ctx = malloc(MP3_CTX_SIZE);
        if (!p->ctx || !mp3_open_mem(data, len, p->ctx)) {
            const char *err = mp3_errstr();
            char msg[128];
            int n = snprintf(msg, sizeof(msg), "%s: %s\n", p->name,
                             err ? err : "не удалось открыть");
            if (p->ctx) free(p->ctx);
            free(p->data);
            free(p);
            app_outwin_open("Аудиоплеер", msg, (u32)(n > 0 ? n : 0));
            return;
        }
    }

    if (p->is_flac) {
        p->chans = flac_channels(p->ctx);
        p->rate  = flac_rate(p->ctx);
        u64 tf   = flac_total_frames(p->ctx);
        p->total_frames = (u32)tf;
        p->total_sec = p->rate ? (u32)(tf / p->rate) : 0;
    } else {
        p->chans = mp3_channels(p->ctx);
        p->rate = mp3_rate(p->ctx);
        u64 tf = mp3_total_frames_estimate(p->ctx);
        p->total_frames = (u32)tf;
        p->total_sec = p->rate ? (u32)(tf / p->rate) : 0;
    }

    mp3p_create_window(p);
    s_lock(&g_player_lock);              /* [MP3-SINGLE] registraciya */
    if (!g_player) g_player = p;
    s_unlock(&g_player_lock);
}

/* Из лаунчера: пустой плеер с кнопкой «Открыть…» (системный диалог). */
void app_mp3_open(void)
{
        /* [MP3-SINGLE]: uzhe est' okno - prosto podnyaem */
    s_lock(&g_player_lock);
    mp3p_t *ex = g_player;
    s_unlock(&g_player_lock);
    if (ex) { wm_raise(ex->w); win_invalidate(ex->w); return; }

    mp3p_t *p = (mp3p_t *)malloc(sizeof(mp3p_t));
    if (!p) return;
    memset(p, 0, sizeof(mp3p_t));
    strcpy(p->name, "— файл не выбран —");
    mp3p_create_window(p);
}
