/* SDL.h — минимальный drop-in для SDL2-совместимых приложений на N2600-OS.
 *
 * Поддерживается: окно+рендерер (software), surface, текстура,
 * клавиатура/мышь, события, таймеры. Аудио/джойстики/хаптика — нет.
 * Формат пикселей всегда ARGB8888 (u32). */
#ifndef SDL_H
#define SDL_H

#include "types.h"

#define SDL_MAJOR_VERSION 2
#define SDL_MINOR_VERSION 0
#define SDL_PATCHLEVEL    20

typedef int SDL_bool;
#define SDL_FALSE 0
#define SDL_TRUE  1
typedef u8  Uint8;  typedef i8  Sint8;
typedef u16 Uint16; typedef i16 Sint16;
typedef u32 Uint32; typedef i32 Sint32;
typedef u64 Uint64; typedef i64 Sint64;

/* ---- Init ---- */
#define SDL_INIT_TIMER   0x0001
#define SDL_INIT_AUDIO   0x0010
#define SDL_INIT_VIDEO   0x0020
#define SDL_INIT_EVENTS  0x4000
#define SDL_INIT_EVERYTHING 0xFFFF

/* ---- Window flags ---- */
#define SDL_WINDOW_FULLSCREEN   0x0001
#define SDL_WINDOW_SHOWN        0x0004
#define SDL_WINDOW_BORDERLESS   0x0010
#define SDL_WINDOW_RESIZABLE    0x0020

/* ---- Renderer flags ---- */
#define SDL_RENDERER_SOFTWARE     0x0001
#define SDL_RENDERER_PRESENTVSYNC 0x0004

/* ---- Textures ---- */
#define SDL_PIXELFORMAT_ARGB8888   0x16362004u
#define SDL_PIXELFORMAT_RGBA8888   0x16462004u
#define SDL_TEXTUREACCESS_STATIC    0
#define SDL_TEXTUREACCESS_STREAMING 1
#define SDL_BLENDMODE_NONE  0
#define SDL_BLENDMODE_BLEND 1

/* ---- Button bits (SDL_GetMouseState) ---- */
#define SDL_BUTTON_LEFT   1
#define SDL_BUTTON_MIDDLE 2
#define SDL_BUTTON_RIGHT  3
#define SDL_BUTTON_LMASK  (1u << (SDL_BUTTON_LEFT  - 1))
#define SDL_BUTTON_MMASK  (1u << (SDL_BUTTON_MIDDLE - 1))
#define SDL_BUTTON_RMASK  (1u << (SDL_BUTTON_RIGHT - 1))

/* ---- Key modifiers ---- */
#define KMOD_NONE   0x0000
#define KMOD_LSHIFT 0x0001
#define KMOD_RSHIFT 0x0002
#define KMOD_SHIFT  0x0003
#define KMOD_LCTRL  0x0040
#define KMOD_RCTRL  0x0080
#define KMOD_CTRL   0x00C0
#define KMOD_LALT   0x0100
#define KMOD_RALT   0x0200
#define KMOD_ALT    0x0300

/* ---- Scancodes (подмножество, совпадает с SDL2) ---- */
enum {
    SDL_SCANCODE_UNKNOWN = 0,
    SDL_SCANCODE_A=4, SDL_SCANCODE_B, SDL_SCANCODE_C, SDL_SCANCODE_D,
    SDL_SCANCODE_E,   SDL_SCANCODE_F, SDL_SCANCODE_G, SDL_SCANCODE_H,
    SDL_SCANCODE_I,   SDL_SCANCODE_J, SDL_SCANCODE_K, SDL_SCANCODE_L,
    SDL_SCANCODE_M,   SDL_SCANCODE_N, SDL_SCANCODE_O, SDL_SCANCODE_P,
    SDL_SCANCODE_Q,   SDL_SCANCODE_R, SDL_SCANCODE_S, SDL_SCANCODE_T,
    SDL_SCANCODE_U,   SDL_SCANCODE_V, SDL_SCANCODE_W, SDL_SCANCODE_X,
    SDL_SCANCODE_Y,   SDL_SCANCODE_Z,
    SDL_SCANCODE_1=30, SDL_SCANCODE_2, SDL_SCANCODE_3, SDL_SCANCODE_4,
    SDL_SCANCODE_5,    SDL_SCANCODE_6, SDL_SCANCODE_7, SDL_SCANCODE_8,
    SDL_SCANCODE_9,    SDL_SCANCODE_0,
    SDL_SCANCODE_RETURN=40, SDL_SCANCODE_ESCAPE, SDL_SCANCODE_BACKSPACE,
    SDL_SCANCODE_TAB=43, SDL_SCANCODE_SPACE,
    SDL_SCANCODE_MINUS, SDL_SCANCODE_EQUALS,
    SDL_SCANCODE_LEFTBRACKET, SDL_SCANCODE_RIGHTBRACKET,
    SDL_SCANCODE_BACKSLASH, SDL_SCANCODE_SEMICOLON, SDL_SCANCODE_APOSTROPHE,
    SDL_SCANCODE_GRAVE, SDL_SCANCODE_COMMA, SDL_SCANCODE_PERIOD,
    SDL_SCANCODE_SLASH, SDL_SCANCODE_CAPSLOCK,
    SDL_SCANCODE_RIGHT=79, SDL_SCANCODE_LEFT, SDL_SCANCODE_DOWN,
    SDL_SCANCODE_UP,
    SDL_SCANCODE_LCTRL=224, SDL_SCANCODE_LSHIFT, SDL_SCANCODE_LALT,
    SDL_SCANCODE_RCTRL=228, SDL_SCANCODE_RSHIFT, SDL_SCANCODE_RALT,
    SDL_NUM_SCANCODES = 512
};

/* ---- Прямоугольник / точка / цвет ---- */
typedef struct SDL_Rect  { int x, y, w, h; } SDL_Rect;
typedef struct SDL_Point { int x, y; } SDL_Point;
typedef struct SDL_Color { Uint8 r, g, b, a; } SDL_Color;

/* ---- Forward decls ---- */
typedef struct SDL_Window   SDL_Window;
typedef struct SDL_Renderer SDL_Renderer;
typedef struct SDL_Texture  SDL_Texture;
typedef struct SDL_Surface  SDL_Surface;

/* ---- Surface ---- */
struct SDL_Surface {
    Uint32 flags;
    int    w, h, pitch;
    void  *pixels;
    Uint32 Rmask, Gmask, Bmask, Amask;
    Uint32 colorkey;      /* 0 = нет прозрачности */
    int    has_colorkey;
    void  *_priv;
};

/* ---- События (layout совместим с SDL2) ---- */
enum {
    SDL_QUIT            = 0x100,
    SDL_KEYDOWN         = 0x300,
    SDL_KEYUP           = 0x301,
    SDL_MOUSEMOTION     = 0x400,
    SDL_MOUSEBUTTONDOWN = 0x401,
    SDL_MOUSEBUTTONUP   = 0x402,
};

typedef struct { Uint32 type, timestamp; Uint8 scancode; Sint32 keycode;
                 Uint16 mod; Uint16 repeat; } SDL_KeyboardEvent;
typedef struct { Uint32 type, timestamp; Sint32 x, y, xrel, yrel;
                 Uint32 state; } SDL_MouseMotionEvent;
typedef struct { Uint32 type, timestamp; Uint8 button, state, clicks;
                 Sint32 x, y; } SDL_MouseButtonEvent;
typedef struct { Uint32 type, timestamp; } SDL_QuitEvent;

typedef union SDL_Event {
    Uint32 type;
    SDL_KeyboardEvent    key;
    SDL_MouseMotionEvent motion;
    SDL_MouseButtonEvent button;
    SDL_QuitEvent        quit;
    Uint8 padding[56];
} SDL_Event;

/* ---- API ---- */
int  SDL_Init(Uint32 flags);
void SDL_Quit(void);
void SDL_QuitSubSystem(Uint32 flags);
const char *SDL_GetError(void);
void SDL_SetError(const char *fmt, ...);
void SDL_ClearError(void);

SDL_Window *SDL_CreateWindow(const char *title, int x, int y, int w, int h, Uint32 flags);
void SDL_DestroyWindow(SDL_Window *w);
void SDL_GetWindowSize(SDL_Window *w, int *ww, int *hh);
void SDL_SetWindowTitle(SDL_Window *w, const char *title);
SDL_Surface *SDL_GetWindowSurface(SDL_Window *w);
int  SDL_UpdateWindowSurface(SDL_Window *w);

SDL_Renderer *SDL_CreateRenderer(SDL_Window *w, int idx, Uint32 flags);
void SDL_DestroyRenderer(SDL_Renderer *r);
int  SDL_SetRenderDrawColor(SDL_Renderer *r, Uint8 rr, Uint8 gg, Uint8 bb, Uint8 aa);
int  SDL_GetRendererOutputSize(SDL_Renderer *r, int *w, int *h);
int  SDL_RenderClear(SDL_Renderer *r);
int  SDL_RenderFillRect(SDL_Renderer *r, const SDL_Rect *rect);
int  SDL_RenderDrawRect(SDL_Renderer *r, const SDL_Rect *rect);
int  SDL_RenderDrawLine(SDL_Renderer *r, int x0, int y0, int x1, int y1);
int  SDL_RenderDrawPoint(SDL_Renderer *r, int x, int y);
int  SDL_RenderCopy(SDL_Renderer *r, SDL_Texture *t,
                    const SDL_Rect *src, const SDL_Rect *dst);
void SDL_RenderPresent(SDL_Renderer *r);

SDL_Texture *SDL_CreateTexture(SDL_Renderer *r, Uint32 format, int access, int w, int h);
SDL_Texture *SDL_CreateTextureFromSurface(SDL_Renderer *r, SDL_Surface *s);
void SDL_DestroyTexture(SDL_Texture *t);
int  SDL_UpdateTexture(SDL_Texture *t, const SDL_Rect *rect, const void *pixels, int pitch);
int  SDL_LockTexture(SDL_Texture *t, const SDL_Rect *rect, void **pixels, int *pitch);
void SDL_UnlockTexture(SDL_Texture *t);

SDL_Surface *SDL_CreateRGBSurface(Uint32 flags, int w, int h, int depth,
                                   Uint32 Rmask, Uint32 Gmask,
                                   Uint32 Bmask, Uint32 Amask);
void SDL_FreeSurface(SDL_Surface *s);
int  SDL_LockSurface(SDL_Surface *s);
void SDL_UnlockSurface(SDL_Surface *s);
int  SDL_SetColorKey(SDL_Surface *s, int flag, Uint32 key);
int  SDL_BlitSurface(SDL_Surface *src, const SDL_Rect *srcrect,
                     SDL_Surface *dst, SDL_Rect *dstrect);
SDL_Surface *SDL_LoadBMP(const char *path);

int  SDL_PollEvent(SDL_Event *e);
int  SDL_WaitEvent(SDL_Event *e);
int  SDL_WaitEventTimeout(SDL_Event *e, int ms);
int  SDL_PushEvent(SDL_Event *e);

const Uint8 *SDL_GetKeyboardState(int *numkeys);
Uint32 SDL_GetMouseState(int *x, int *y);

void SDL_Delay(Uint32 ms);
Uint32 SDL_GetTicks(void);
Uint64 SDL_GetPerformanceCounter(void);
Uint64 SDL_GetPerformanceFrequency(void);

/* Помощник интеграции с apps.c — спавнит задачу и НЕ блокирует вызывающего. */
int SDL_RunApp(int (*sdl_main)(int, char**), int argc, char **argv);

#endif /* SDL_H */
