/* textinput.c — отрисовка виджета ввода текста (Task 64 [TI-WIDGET]).
 * ЯДРО (буфер/курсор/клавиши) — header-only в textinput.h; здесь только
 * fb-примитивы, чтобы хост-тесты ядро виджета собирали без fb.h.
 *
 * Два вида отрисовки:
 *   ti_draw_box    — поле с рамкой (диалоги файлов, формы, скриптовые
 *                    окна, пароль WiFi): фон, рамка (акцент при
 *                    фокусе), текст с окном видимости вокруг курсора,
 *                    мигающая каретка-полоска, режим password ('*').
 *   ti_draw_inline — строка ввода БЕЗ рамки (терминал: "> приглашение"
 *                    уже нарисовано embedder'ом): тот же текст+каретка.
 */
#include "textinput.h"
#include "fb.h"
#include "wm.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#define TI_CHAR_W 8     /* шрифт ОС моноширинный 8x16: кириллица тоже 8 px */
#define TI_ROW_H  16

/* Общий хвост отрисовки: маскировка пароля (в buf вызывающего — НЕ
 * меняем виджет), окно видимости, каретка. Возвращает px-позицию
 * каретки относительно x0, или -1 (курсора нет). */
static int ti_draw_text_at(const ti_t *ti, int x0, int y, int max_px,
                           u32 fg, int focused)
{
    char shown[260];
    int max_chars = max_px / TI_CHAR_W;
    if (max_chars < 1) max_chars = 1;
    if (max_chars > (int)sizeof(shown) - 8) max_chars = (int)sizeof(shown) - 8;

    /* окно видимости: виджет держит view_off, пересчитываем (курсор
     * мог остаться на месте, а ширина поля — измениться) */
    int from = ti_view_off((ti_t *)ti, max_chars);
    int total = utf8_count_chars(ti->buf, ti->len);
    int view_chars = total - utf8_count_chars(ti->buf, from);
    if (view_chars > max_chars) view_chars = max_chars;
    if (view_chars < 0) view_chars = 0;

    /* взять view_chars СИМВОЛОВ с позиции from (не рвать UTF-8) */
    int take = utf8_take_bytes(ti->buf + from, ti->len - from, view_chars);
    if (take > (int)sizeof(shown) - 8) take = (int)sizeof(shown) - 8;
    if (take < 0) take = 0;
    if (ti->password) {
        int nch = utf8_count_chars(ti->buf + from, take);
        if (nch > (int)sizeof(shown) - 2) nch = (int)sizeof(shown) - 2;
        for (int i = 0; i < nch; i++) shown[i] = '*';
        shown[nch] = 0;
    } else {
        for (int i = 0; i < take; i++) shown[i] = ti->buf[from + i];
        shown[take] = 0;
    }
    fb_text(x0, y, shown, fg, -1);

    if (!focused) return -1;
    /* каретка: px = (символов от начала окна до курсора) * 8 */
    int curc = utf8_count_chars(ti->buf, ti->cur);
    int fromc = utf8_count_chars(ti->buf, from);
    int cpos = curc - fromc;
    if (cpos < 0) cpos = 0;
    if (cpos > max_chars) cpos = max_chars;
    return cpos * TI_CHAR_W;
}

/* Поле с рамкой. focused: рамка акцентом + мигающая каретка. */
void ti_draw_box(ti_t *ti, int x, int y, int w, int h, int focused)
{
    fb_fill_rect(x, y, w, h, wm_theme_win_bg());
    fb_rect(x, y, w, h, focused ? wm_theme_accent()
                                : fb_rgb(0x2C, 0x31, 0x38));
    int tx = x + 4, ty = y + (h - TI_ROW_H) / 2 + 1;
    int max_px = w - 8;
    if (max_px < TI_CHAR_W) max_px = TI_CHAR_W;

    int cx = ti_draw_text_at(ti, tx, ty, max_px,
                             focused ? wm_theme_text() : wm_theme_text_dim(),
                             focused);
    if (focused && cx >= 0 && wm_blink())
        fb_fill_rect(tx + cx, ty, 2, TI_ROW_H - 2, wm_theme_text());
}

/* Строка без рамки (терминал). Возвращает px-смещение каретки от x0
 * (embedder рисует каретку сам, если хочет) или -1. */
int ti_draw_inline(ti_t *ti, int x0, int y, int max_px, u32 fg)
{
    int cx = ti_draw_text_at(ti, x0, y, max_px, fg, 1);
    if (cx >= 0 && wm_blink())
        fb_fill_rect(x0 + cx, y, 8, TI_ROW_H, fg);
    return cx;
}
