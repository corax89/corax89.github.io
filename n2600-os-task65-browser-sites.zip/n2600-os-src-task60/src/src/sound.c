/* sound.c — ядро звуковой подсистемы: выбор драйвера + синтез тона.
 *
 * Синтез БЕЗ FPU (x87 не сохраняется при переключении задач): четверть-
 * волновая таблица Q15 + фазовый аккумулятор. Формат вывода у всех
 * драйверов одинаковый: 16-bit stereo, правый = левый.
 *
 * Драйверы (сессия 58):
 *   1) ES1371/ES1373 (PCI 1274:1371, 1274:5880, 1102:8938/5880) —
 *      VMware «Sound Blaster AudioPCI», 86Box/PCem «Sound Blaster PCI 128»;
 *   2) ES1370 (PCI 1274:5000) — QEMU `-device es1370`;
 *   3) Intel HDA (класс 0x0403) — VMware «hdaudio» + Realtek ALC269VB.
 *
 * Кольцевой буфер содержит ЦЕЛОЕ число периодов тона — стык при
 * зацикливании бесшовный, щелчков нет.
 */
#include "sound.h"
#include "types.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

/* Сессия 88 [SND-LOG]: строки подсистемы звука и в klog (dmesg) —
 * раньше только serial, из-за чего блок звука в загрузочном логе
 * выглядел пустым. */
static void snd_msg(const char *s)
{
    serial_puts(s);
    serial_puts("\n");
    klog_puts(s);
}

/* probes/players от драйверов */
int snd_es1371_probe(void);                       /* 1 = найден */
const char *snd_es1371_name(void);
int snd_es1371_play(const i16 *samples, u32 frames, u32 rate, u32 ms);
void snd_es1371_codec_init(void);
/* поток (сессия 60) */
int  snd_es1371_stream(const i16 *samples, u32 frames, u32 rate);
void snd_es1371_stream_pause(int on);
void snd_es1371_stream_stop(void);

int snd_es1370_probe(void);                       /* QEMU -device es1370 */
const char *snd_es1370_name(void);
int snd_es1370_play(const i16 *samples, u32 frames, u32 rate, u32 ms);
int  snd_es1370_stream(const i16 *samples, u32 frames, u32 rate);
void snd_es1370_stream_pause(int on);
void snd_es1370_stream_stop(void);

int snd_hda_probe(void);
const char *snd_hda_name(void);
int snd_hda_play(const i16 *samples, u32 frames, u32 rate, u32 ms);
int snd_hda_init(void);
int  snd_hda_stream(const i16 *samples, u32 frames, u32 rate);
void snd_hda_stream_pause(int on);
void snd_hda_stream_stop(void);
u32  snd_hda_stream_set_rate(u32 want);   /* [HDA-RATE] */
u32  snd_hda_stream_rate(void);           /* [HDA-RATE] */
/* [HDA-SWVOL] мастер-громкость (софтверное масштабирование) */
void snd_hda_set_volume(int percent);
int  snd_hda_get_volume(void);

/* [SND-VOL] софт-громкость ES137x (реализация внизу файла) */
static void snd_vol_scale_inplace(i16 *buf, u32 frames);
static const i16 *snd_vol_stage(const i16 *src, u32 frames);

static int         g_driver = 0;   /* 0 = нет, 1 = es1371, 2 = es1370, 3 = hda */
static const char *g_err = "нет HDA/ES137x на PCI";

const char *sound_last_error(void) { return g_err; }
const char *sound_device_name(void)
{
    if (g_driver == 1) return snd_es1371_name();
    if (g_driver == 2) return snd_es1370_name();
    if (g_driver == 3) return snd_hda_name();
    return "нет";
}
int sound_present(void) { return g_driver != 0; }

int sound_init(void)
{
    if (snd_es1371_probe()) {
        g_driver = 1;
        snd_es1371_codec_init();
        snd_msg("[sound] ES1371/1373 готов");
        return 1;
    }
    if (snd_es1370_probe()) {
        g_driver = 2;
        snd_msg("[sound] ES1370 готов");
        return 1;
    }
    if (snd_hda_probe()) {
        if (snd_hda_init()) {
            g_driver = 3;
            snd_msg("[sound] Intel HDA готов");
            return 1;
        }
        g_err = "HDA: кодек не ответил";
        snd_msg("[sound] HDA-контроллер есть, кодек не ответил");
        return 0;
    }
    g_err = "нет HDA/ES137x на PCI";
    snd_msg("[sound] звуковых устройств не найдено (PCI)");
    return 0;
}

/* ---------- четверть-волновая таблица: sin(i*pi/512), Q15 ---------- */
static const i16 g_sin_q15[129] = {
    0, 201, 402, 603, 804, 1005, 1206, 1407, 1608,
    1809, 2009, 2210, 2410, 2611, 2811, 3012, 3212, 3412,
    3612, 3811, 4011, 4210, 4410, 4609, 4808, 5007, 5205,
    5404, 5602, 5800, 5998, 6195, 6393, 6590, 6786, 6983,
    7179, 7375, 7571, 7767, 7962, 8157, 8351, 8545, 8739,
    8933, 9126, 9319, 9512, 9704, 9896, 10087, 10278, 10469,
    10659, 10849, 11039, 11228, 11417, 11605, 11793, 11980, 12167,
    12353, 12539, 12725, 12910, 13094, 13279, 13462, 13645, 13828,
    14010, 14191, 14372, 14553, 14732, 14912, 15090, 15269, 15446,
    15623, 15800, 15976, 16151, 16325, 16499, 16673, 16846, 17018,
    17189, 17360, 17530, 17700, 17869, 18037, 18204, 18371, 18537,
    18703, 18868, 19032, 19195, 19357, 19519, 19680, 19841, 20000,
    20159, 20317, 20475, 20631, 20787, 20942, 21096, 21250, 21403,
    21554, 21705, 21856, 22005, 22154, 22301, 22448, 22594, 22739,
    22884, 23027, 23170
};

/* один отсчёт синуса: phase 0..2^32 отображается в 0..2*pi */
static inline i16 sine_at(u32 phase)
{
    u32 idx = phase >> 23;              /* 0..511 (512 четвертей по 128) */
    i16 v;
    switch (idx >> 7) {                 /* квадрант */
    default:
    case 0: v =  g_sin_q15[idx & 127]; break;
    case 1: v =  g_sin_q15[128 - (idx & 127)]; break;
    case 2: v = -g_sin_q15[idx & 127]; break;
    case 3: v = -g_sin_q15[128 - (idx & 127)]; break;
    }
    return (i16)((v * 28000) >> 15);    /* ~85% полной шкалы: прежде 43%
                                         * (-7.4 дБ) — полевой лог итерации 9:
                                         * «звук очень тихий даже на 100%»,
                                         * тракт и так без усиления */
}

/* Заполнить кольцо: ЦЕЛОЕ число периодов => бесшовный луп.
 * frames выбирается вызывающим (sound_beep: rate/freq округлённо). */
static void fill_tone(i16 *buf, u32 frames, u32 rate, u32 freq)
{
    u32 dphase = (u32)(((u64)freq << 32) / rate);
    u32 phase = 0;
    for (u32 i = 0; i < frames; i++) {
        i16 v = sine_at(phase);
        buf[2 * i]     = v;
        buf[2 * i + 1] = v;
        phase += dphase;
    }
}

int sound_beep(u32 freq_hz, u32 ms)
{
    if (g_driver == 0) { g_err = "нет HDA/ES137x на PCI"; return -1; }
    if (freq_hz < 20 || freq_hz > 15000) freq_hz = 440;
    if (ms == 0) ms = 100;

    /* ES1371/ES1370 работают на 44100, HDA — на 48000 (оба — целые
     * периоды) */
    u32 rate = (g_driver == 3) ? 48000 : 44100;
    u32 frames = (rate + freq_hz / 2) / freq_hz;
    if (frames < 16) frames = 16;
    if (frames > rate) frames = rate;
    /* Сессия 58: кольцо драйвера не больше 64 КиБ (16384 фрейма) —
     * усечение ДО заполнения, чтобы в кольце осталось ЦЕЛОЕ число
     * периодов (иначе щелчок на стыке лупа) */
    if (frames > 16384) frames = 16384;

    u32 bytes = frames * 4;               /* 16-bit stereo */
    i16 *buf = (i16 *)malloc(bytes);
    if (!buf) { g_err = "нет памяти под буфер"; return -1; }
    fill_tone(buf, frames, rate, freq_hz);
    /* [SND-VOL] громкость и на ES137x (буфер наш — правим на месте);
     * HDA масштабирует сам в hda_vol_copy */
    if (g_driver == 1 || g_driver == 2) snd_vol_scale_inplace(buf, frames);

    int rc;
    if (g_driver == 1)
        rc = snd_es1371_play(buf, frames, rate, ms);
    else if (g_driver == 2)
        rc = snd_es1370_play(buf, frames, rate, ms);
    else
        rc = snd_hda_play(buf, frames, rate, ms);
    free(buf);
    if (rc == 0) g_err = "ok";
    return rc;
}

int sound_test_melody(void)
{
    /* Ноты подобраны так, что при обоих rate (44100 и 48000) в кольцо
     * помещается ЦЕЛОЕ число кадров периода (например 480 Гц: 92 кадра
     * при 44100, 100 кадров при 48000) — стык лупа бесшовный. */
    static const struct { u32 f, ms; } notes[] = {
        { 480, 160 },    /* A4 */
        { 600, 160 },    /* ~D5 */
        { 800, 160 },    /* ~G5 */
        { 960, 240 },    /* ~B5 */
    };
    for (int i = 0; i < 4; i++) {
        int rc = sound_beep(notes[i].f, notes[i].ms);
        if (rc != 0) return rc;
        task_msleep(30);
    }
    return 0;
}

/* ================= потоковое воспроизведение (сессия 60) ================= */

u32 sound_stream_rate(void)
{
    if (g_driver == 1 || g_driver == 2) return 44100;   /* ES1371/ES1370 */
    if (g_driver == 3) return snd_hda_stream_rate();    /* [HDA-RATE] */
    return 0;
}

/* [HDA-RATE] запрос частоты потока под файл: HDA ставит нативный
 * формат (44.1 кГц — свой ход, без ресэмпла и без сдвига скорости);
 * возвращает ФАКТИЧЕСКИЙ рейт (неподдержанный — 48000, ресэмпл на
 * вызывающем). Вызывать ДО первого sound_stream_chunk. */
u32 sound_stream_set_rate(u32 want)
{
    if (g_driver == 1 || g_driver == 2) return 44100;
    if (g_driver == 3) return snd_hda_stream_set_rate(want);
    return 0;
}

int sound_stream_chunk(const i16 *stereo, u32 frames)
{
    if (g_driver == 0 || !stereo || frames < 8) {
        g_err = "нет HDA/ES137x на PCI";
        return -1;
    }
    int rc;
    if (g_driver == 1) {
        /* [SND-VOL] масштабируем в чередующийся staging — DMA ES1371
         * читает отданный буфер напрямую до СЛЕДУЮЩЕГО вызова */
        const i16 *out = snd_vol_stage(stereo, frames);
        rc = snd_es1371_stream(out, frames, 44100);
    } else if (g_driver == 2) {
        const i16 *out = snd_vol_stage(stereo, frames);
        rc = snd_es1370_stream(out, frames, 44100);
    } else
        rc = snd_hda_stream(stereo, frames, 48000);
    if (rc == 0) g_err = "ok";
    return rc;
}

void sound_stream_pause(int on)
{
    if (g_driver == 1)      snd_es1371_stream_pause(on);
    else if (g_driver == 2) snd_es1370_stream_pause(on);
    else if (g_driver == 3) snd_hda_stream_pause(on);
}

/* ---------- [SND-STREAMTEST] РЕШАЮЩИЙ ЭКСПЕРИМЕНТ ----------
 * (полевой лог 16: кольцо ИДЕАЛЬНО — lead=360 мс стабильно, ждём-полно
 * ровно по одному на кусок, 0 пропусков, 0 потерь кругов — а MP3 хрипит;
 * beep при этом чист). Тот же ПОТОКОВЫЙ тракт (кольцо + DMA + текущий
 * SD_FMT), но сигнал СИНТЕЗИРУЕМЫЙ (Q15-NCO, без FPU), не декод:
 *   - стрим-тест ЧИСТЫЙ  -> HW-тракт исправен, виновато СОДЕРЖИМОЕ MP3
 *                          (файл/декод) — копаем файл/декод;
 *   - стрим-тест ХРИПИТ  -> HW-тракт потока (DMA/позиция/формат кодека).
 * Две фазы: 44.1к (нативный путь MP3) и 48к. Контрольные суммы кусков
 * в dmesg: одинаковые при повторе = декод/синтез детерминированы.
 * Блокирует вызывающего ~6 с (кнопка «Тест звука» показывает «Играю...»). */
int sound_stream_test(void)
{
    if (g_driver == 0) { g_err = "нет HDA/ES137x на PCI"; return -1; }
    i16 *buf = (i16 *)malloc((u32)8192 * 2u * sizeof(i16));
    if (!buf) { g_err = "нет памяти под буфер теста"; return -1; }
    static const u32 rates[2] = { 44100u, 48000u };
    char b[160];
    int any = 0;
    for (int ph = 0; ph < 2; ph++) {
        u32 orate;
        if (g_driver == 3) orate = sound_stream_set_rate(rates[ph]);
        else               orate = sound_stream_rate();   /* ES137x: 44.1 фикс */
        if (!orate) continue;
        any = 1;
        u32 dphase = (u32)(((u64)440u << 32) / orate);
        u32 phase = 0;
        u32 t0 = timer_ticks();
        u32 chunks = 0;
        while ((u32)(timer_ticks() - t0) < 3000u) {
            for (u32 i = 0; i < 8192; i++) {
                i16 v = sine_at(phase);
                phase += dphase;
                buf[2 * i]     = v;
                buf[2 * i + 1] = v;
            }
            if (chunks < 2) {
                u32 cs = 0;
                for (u32 i = 0; i < 8192u * 2u; i++)
                    cs = cs * 31u + (u32)(u16)buf[i];
                snprintf(b, sizeof(b), "[sndtest] %s: кусок %u cs=%08x",
                         rates[ph] == 44100u ? "44.1к" : "48к", chunks, cs);
                snd_msg(b);
            }
            if (sound_stream_chunk(buf, 8192) != 0) break;
            chunks++;
        }
        sound_stream_stop();
        snprintf(b, sizeof(b),
                 "[sndtest] фаза %s: кусков %u — хрип в этой фазе = HW-тракт "
                 "потока, чисто = содержимое MP3",
                 rates[ph] == 44100u ? "44.1к" : "48к", chunks);
        snd_msg(b);
    }
    free(buf);
    if (!any) { g_err = "поток недоступен"; return -1; }
    g_err = "ok";
    return 0;
}

void sound_stream_stop(void)
{
    if (g_driver == 1)      snd_es1371_stream_stop();
    else if (g_driver == 2) snd_es1370_stream_stop();
    else if (g_driver == 3) snd_hda_stream_stop();
}

/* ---------- [HDA-SWVOL] мастер-громкость ----------
 * Итерация 7 [SND-VOL]: громкость применяется на ВСЕХ драйверах.
 *   - HDA: собственный множитель драйвера (hda_vol_copy в DMA-кольцо);
 *   - ES1371/ES1370 (VMware «Sound Blaster AudioPCI», QEMU es1370):
 *     масштабирование в sound.c — ДО отдачи драйверу. Прежде громкость
 *     была no-op на ES137x, и ползунок на панели задач «не реагировал»
 *     (sound_get_volume всегда возвращал 100).
 * Для stream() DMA читает буфер ВЫЗЫВАЮЩЕГО напрямую — поэтому
 * масштабируем в ЧЕРЕДУЮЩИЕСЯ staging-буферы (двойная буферизация,
 * как у самого плеера): DMA играет staging[N], следующий кусок пишется
 * в staging[N+1] — контракт «буфер живёт до следующего вызова» не
 * нарушается. Для beep() буфер наш и временный — правим на месте.
 * Отказ malloc → работа без громкости (прямо из буфера вызывающего). */
static int  g_es_vol = 100;          /* процентов, 0..100 (ES137x) */
static i16 *g_vol_stg[2] = { 0, 0 };
static int  g_vol_stg_flip = 0;

#define VOL_STG_FRAMES 16384u        /* = максимум ES137x-куска (64 КиБ) */

void sound_set_volume(int percent)
{
    if (percent < 0)   percent = 0;
    if (percent > 100) percent = 100;
    if (g_driver == 3) { snd_hda_set_volume(percent); return; }
    g_es_vol = percent;
}

int sound_get_volume(void)
{
    if (g_driver == 3) return snd_hda_get_volume();
    return g_es_vol;
}

/* масштабированная копия stereo s16 (та же математика, что hda_vol_copy) */
static void snd_vol_copy(i16 *dst, const i16 *src, u32 frames)
{
    if (g_es_vol >= 100) {
        memcpy(dst, src, frames * 4u);
        return;
    }
    if (g_es_vol <= 0) {
        memset(dst, 0, frames * 4u);
        return;
    }
    for (u32 i = 0; i < frames * 2u; i++)
        dst[i] = (i16)(((i32)src[i] * (i32)g_es_vol) / 100);
}

/* ES137x: подготовить кусок с громкостью. Возвращает буфер для DMA
 * (staging) или исходный, если staging недоступен. */
static const i16 *snd_vol_stage(const i16 *src, u32 frames)
{
    if (g_es_vol >= 100) return src;
    if (frames > VOL_STG_FRAMES) frames = VOL_STG_FRAMES;
    for (int k = 0; k < 2; k++) {
        if (!g_vol_stg[k]) {
            g_vol_stg[k] = (i16 *)malloc(VOL_STG_FRAMES * 4u + 8u);
            if (g_vol_stg[k])
                g_vol_stg[k] = (i16 *)(((unsigned long)g_vol_stg[k] + 3ul)
                                       & ~3ul);   /* DMA требует выравнивание 4 */
        }
    }
    if (!g_vol_stg[0] || !g_vol_stg[1]) return src;   /* без громкости */
    g_vol_stg_flip ^= 1;
    snd_vol_copy(g_vol_stg[g_vol_stg_flip], src, frames);
    return g_vol_stg[g_vol_stg_flip];
}

/* масштабировать НАШ временный буфер на месте (sound_beep) */
static void snd_vol_scale_inplace(i16 *buf, u32 frames)
{
    if (g_es_vol >= 100 || g_es_vol <= 0) {
        if (g_es_vol <= 0) memset(buf, 0, frames * 4u);
        return;
    }
    snd_vol_copy(buf, buf, frames);
}
