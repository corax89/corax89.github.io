/* apipc.c — ШАГ 4 (SMP-rework): инфраструктура IPI-syscall (BSP-исполнитель).
 *
 * Реализация per-core mailbox (см. apipc.h) + IPI-стаб на BSP.
 * Вектор IPI: 0x62 (0x60 занят LAPIC-таймером AP — расхождение с
 * примером разбора вынужденное: тот предлагал 0x60 для syscall).
 *
 * IPI-стаб (ap_ipi_stub) зеркален irq_stub_0: IPI может прервать на
 * BSP любую задачу, включая песочницу c4 (сегментная база SS) — без
 * пересчёта ESP по task_region_base кадр ломался бы (#GP). */
#include "apipc.h"
#include "smp.h"
#include "io.h"
#include "string.h"
#include "timer.h"
#include "mem.h"
#include "task.h"
#include "kernel.h"

extern void serial_puts(const char *s);

#define APIPC_IPI_VEC 0x62u    /* фиксированный: 0x60 = LAPIC-таймер AP */

/* [0] не используется: BSP не отправляет самому себе. */
static ap_syscall_t ap_syscall[SMP_MAX_CPUS];
static volatile int apipc_poll_lock = 0;   /* reentrancy: kmain vs IPI */

/* ---------- исполнение (только на BSP) ---------- */
static u32 apipc_dispatch(int op, u32 a, u32 b, u32 c)
{
    switch (op) {
    case APIPC_NOP:    return a + b + c;
    case APIPC_MALLOC: return (u32)(unsigned long)malloc((u32)a);
    case APIPC_FREE:   free((void *)(unsigned long)a); return 0;
    case APIPC_UPTIME: return timer_ticks();
    default:
        serial_puts("[apipc] неизвестный op\n");
        return 0;
    }
}

/* ---------- AP: запрос + ожидание ---------- */
u32 ap_syscall_do(int op, u32 a, u32 b, u32 c)
{
    if (!smp_this_cpu_is_ap()) {
        /* BSP (или SMP нет): исполнить локально — тот же код, тот же
         * результат, пересылать самому себе не нужно. */
        return apipc_dispatch(op, a, b, c);
    }
    int me = smp_current_cpu();
    if (me <= 0)
        return apipc_dispatch(op, a, b, c);   /* ядро не опознано */
    ap_syscall_t *s = &ap_syscall[me];
    s->op = op; s->arg1 = a; s->arg2 = b; s->arg3 = c;
    __asm__ __volatile__("" ::: "memory");     /* publish до pending */
    s->pending = 1;
    smp_ipi_send_bsp();                       /* быстрый путь; поллинг — страховка */
    while (s->pending)
        __asm__ __volatile__("pause" ::: "memory");
    return s->result;
}

/* ---------- BSP: обслуживание mailbox ---------- */
void ap_syscall_poll(void)
{
    if (!smp_ready()) return;                 /* до smp_init — неактивно */
    if (__sync_lock_test_and_set(&apipc_poll_lock, 1))
        return;                               /* уже в poll (IPI/kmain) */
    for (int c = 1; c < SMP_MAX_CPUS; c++) {
        ap_syscall_t *s = &ap_syscall[c];
        if (!s->pending) continue;
        s->result = apipc_dispatch(s->op, s->arg1, s->arg2, s->arg3);
        __asm__ __volatile__("" ::: "memory"); /* result до снятия pending */
        s->pending = 0;
    }
    __sync_lock_release(&apipc_poll_lock);
}

/* ---------- BSP: включение приёма IPI (пере-включение LAPIC) ---------- */
void apipc_bsp_ipi_enable(void)
{
#if APIPC_BSP_IPI_ENABLE
    if (!smp_ready()) return;
    if (smp_bsp_lapic_ipi_enable()) {
        serial_puts("[apipc] IPI-путь активен: LAPIC BSP включён "
                    "(virtual wire), вектор 0x62; поллинг kmain — страховка\n");
    }
#else
    serial_puts("[apipc] IPI выключен (APIPC_BSP_IPI_ENABLE=0): "
                "доставка опросом из kmain\n");
#endif
}

/* ---------- IPI-обработчик BSP (вектор 0x62) ----------
 * C-часть: EOI (IPI пришёл через LAPIC) + обслуживание mailbox.
 * Возвращает тот же кадр (переключения контекста нет). */
u32 ap_ipi_irq_c(u32 *saved_esp)
{
    smp_lapic_bsp_eoi();
    ap_syscall_poll();
    return (u32)(unsigned long)saved_esp;
}

__attribute__((naked, used)) void ap_ipi_stub(void)
{
    __asm__ __volatile__(
        "pusha\n\t"                  /* сохранить EAX,ECX,EDX,EBX,ESP_orig,EBP,ESI,EDI */
        "pushl %ss\n\t"             /* сегменты прерванной задачи (в её стеке) */
        "pushl %ds\n\t"
        "pushl %es\n\t"
        /* Защита памяти: сегменты данных — на ядро, затем пересчёт ESP
         * по региону песочницы (кадр зеркален irq_stub_0 — IPI может
         * прервать на BSP в т.ч. задачу-песочницу). */
        "movl $0x10, %ecx\n\t"
        "movw %cx, %ds\n\t"
        "movw %cx, %es\n\t"
        "movl cur_task, %eax\n\t"
        "movl task_region_base(,%eax,4), %eax\n\t"
        "addl %eax, %esp\n\t"
        "movw %cx, %ss\n\t"
        "cld\n\t"
        "pushl %esp\n\t"             /* arg: указатель на кадр */
        "call _ap_ipi_irq_c\n\t"    /* обработать mailbox; кадр тот же */
        "movl %eax, %esp\n\t"        /* (переключения нет — вернули свой же) */
        "movl cur_task, %eax\n\t"
        "movl task_region_base(,%eax,4), %ecx\n\t"
        "popl %es\n\t"               /* сегменты прерванной задачи */
        "popl %ds\n\t"
        "popl %eax\n\t"              /* слот SS задачи */
        "movw %ax, %ss\n\t"
        "subl %ecx, %esp\n\t"       /* ESP = смещение в регионе (ядро: -0) */
        "popa\n\t"
        "iret\n\t"
    );
}
