/* loader.c — загрузчик flat-binary приложений с диска.
 *
 * Простая модель: приложение представляет собой скомпилированный
 * в flat-binary машинный код, экспортирующий точку входа:
 *
 *     void entry(kapi_t *k, struct window *w);
 *
 * Загрузчик:
 *   1) читает файл из RAMFS в malloc-буфер (исполняемый, т.к. NX нет на x86-32);
 *   2) валидирует первые байты (должны быть prologue + jmp/call)
 *   3) создаёт kapi_t с указателями на функции ядра;
 *   4) порождает новую задачу через task_spawn();
 *   5) задача вызывает entry(&kapi, win) под защитой setjmp —
 *      если приложение вызывает исключение CPU, задача завершается
 *      корректно, а ядро продолжает работать.
 */
#include "loader.h"
#include "kapi.h"
#include "task.h"
#include "mem.h"
#include "ramfs.h"
#include "string.h"
#include "fb.h"
#include "wm.h"
#include "timer.h"
#include "kernel.h"
#include "c4.h"
#include "sdl_ops.h"  /* Task 54: C4_SDL_OP_COUNT / C4_SDL_IDX_* */
#include "apps.h"   /* app_outwin_open: окно вывода нативных c4-программ */
#include "mp3svc.h" /* kapi_mp3_*: MP3-декодер для приложений (сессия 60) */
#include "imgsvc.h" /* img_fpu_lock/unlock: FPU-лок для native c4 (сессия 74) */
#include "c4gfx.h"  /* окно графики c4-программ */
#include "kbd.h"
#include "idt.h"
#include "gdt.h"   /* песочница: сегменты задач */

extern void serial_puts(const char *s);
extern int  vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* ===================== песочница нативных c4-программ =====================
 *
 * ЗАЩИТА ПАМЯТИ (flat-модель без MMU): скомпилированный c4-код раньше
 * мог записать ЛЮБОЙ адрес 4 ГБ — в т.ч. поверх таблицы задач, GDT,
 * стека ядра. Теперь каждому C4N1-бинарнику выделяется ЕДИНЫЙ регион
 * (kapi-копия + стабы + данные + куча + стек), а задача на время
 * entry() работает с DS/ES/SS = свой дескриптор GDT [base, base+size):
 *
 *   - запись/чтение мимо региона → #GP → exc_panic → longjmp в loader
 *     → приложение погибает, ядро и соседи живут;
 *   - ВСЕ указатели внутри приложения — СМЕЩЕНИЯ от базы региона
 *     (релоки данных патчатся смещением, kapi-обёртки прибавляют базу);
 *   - вызовы kapi идут через сгенерированные стабы (push fn; jmp core),
 *     core переключает DS/ES на ядро — функции ядра работают как обычно.
 *
 * Планировщик (irq_stub_0, task.c) пересчитывает ESP при смене базы SS
 * (task_region_base[]) — прерывания корректно вытесняют песочницу.
 */

#define SB_HEAP_SZ   (64 * 1024)   /* куча kapi->malloc внутри региона */
#define SB_STACK_SZ  (16 * 1024)   /* стек приложения внутри региона */

u8 *sb_region[MAX_TASKS];       /* база региона (NULL = без песочницы) НЕ static: на него смотрит asm (см. linker.ld) */
static u32 sb_region_size[MAX_TASKS];
static u8 *sb_arena[MAX_TASKS];        /* bump-указатель кучи (АБСОЛЮТНЫЙ) */
static u8 *sb_arena_end[MAX_TASKS];

static u8 *sb_base(int t)
{
    return (t >= 0 && t < MAX_TASKS) ? sb_region[t] : NULL;
}

/* Указатель приложения: смещение < размера региона → абсолютный адрес.
 * Значения >= размера региона считаем АБСОЛЮТНЫМИ адресами ядра
 * (пример: строка "divide by zero" внутри кода — адрес кучи >> региона). */
static void *sb_ptr(u32 off)
{
    int t = task_current();
    u8 *b = sb_base(t);
    if (!b) return (void *)(unsigned long)off;
    if (off >= sb_region_size[t]) return (void *)(unsigned long)off;
    return b + off;
}

/* ---------- ядро-обёртки kapi (работают с сегментами ядра) ---------- */

/* malloc в песочнице: bump-аллокатор внутри региона, возвращает СМЕЩЕНИЕ */
static void *sb_malloc(u32 n)
{
    int t = task_current();
    if (t < 0 || t >= MAX_TASKS || !sb_region[t]) return NULL;
    u32 sz = (n + 7u) & ~7u;
    if (sb_arena[t] + sz > sb_arena_end[t]) return NULL;
    u32 off = (u32)(unsigned long)(sb_arena[t] - sb_region[t]);
    sb_arena[t] += sz;
    return (void *)(unsigned long)off;
}

static void sb_free(u32 p) { (void)p; /* регион освобождается целиком */ }

static void *sb_memset(u32 dst, int c, u32 n)
{
    memset(sb_ptr(dst), c, n);
    return (void *)(unsigned long)dst;
}

static int sb_memcmp(u32 a, u32 b, u32 n)
{
    return memcmp(sb_ptr(a), sb_ptr(b), n);
}

static void *sb_memcpy(u32 dst, u32 src, u32 n)
{
    memcpy(sb_ptr(dst), sb_ptr(src), n);
    return (void *)(unsigned long)dst;
}

static u32 sb_strlen(u32 s) { return strlen((const char *)sb_ptr(s)); }

static int sb_strcmp(u32 a, u32 b)
{
    return strcmp((const char *)sb_ptr(a), (const char *)sb_ptr(b));
}

static u32 sb_strcpy(u32 dst, u32 src)
{
    strcpy((char *)sb_ptr(dst), (const char *)sb_ptr(src));
    return dst;
}

static void sb_fb_text(int x, int y, u32 s_off, u32 fg, int bg)
{
    c4_gfx_text(x, y, (const char *)sb_ptr(s_off), fg, bg);
}

static void sb_c4_print_str(u32 s_off, u32 len)
{
    c4_print_str((const char *)sb_ptr(s_off), len);
}

static int sb_c4_event_poll(u32 buf_off)
{
    return c4_gfx_event_poll(sb_ptr(buf_off));
}

/* ---- [SB-SDL] (Task 54): SDL2-диспетчер для ПЕСОЧНИЦЫ ----
 * Аргументы-указатели приложения приходят СМЕЩЕНИЯМИ региона (стек
 * приложения живёт в сегменте песочницы); хэндлы ядра (win/ren/tex) —
 * уже линейные адреса. Маска на операцию: бит i => a[i] — указатель в
 * память приложения (a[0] = ПОСЛЕДНИЙ аргумент вызова, как на стеке
 * c4). Ноль не переводится (легальный NULL: rect==0 и т.п.); sb_ptr
 * сама пропускает значения >= размера региона (хэндлы ядра). */
static u32 sb_sdl_xlate(u32 v)
{
    return v ? (u32)(unsigned long)sb_ptr(v) : 0;
}

static int sb_c4_sdl_call(u32 op, u32 args_off)
{
    static const u64 ptr_args[C4_SDL_OP_COUNT] = {
        /* порядок бит = индексы a[] (a[0] — последний аргумент вызова) */
        [C4_SDL_IDX_SDLCREATEWIN]  = 1ull << 5,                 /* title */
        [C4_SDL_IDX_SDLGETWINSIZE] = (1ull << 0) | (1ull << 1), /* h, w */
        [C4_SDL_IDX_SDLSETWINTITLE] = 1ull << 0,                /* title */
        [C4_SDL_IDX_SDLGETRENDOUT] = (1ull << 0) | (1ull << 1), /* h, w */
        [C4_SDL_IDX_SDLRENDFILLRECT] = 1ull << 0,               /* rect */
        [C4_SDL_IDX_SDLRENDDRAWRECT] = 1ull << 0,               /* rect */
        [C4_SDL_IDX_SDLRENDCOPY]  = (1ull << 0) | (1ull << 1),  /* dst, src */
        [C4_SDL_IDX_SDLUPDTEX]    = (1ull << 1) | (1ull << 2),  /* pixels, rect */
        [C4_SDL_IDX_SDLLOCKTEX]   = (1ull << 0) | (1ull << 1) | (1ull << 2),
        [C4_SDL_IDX_SDLBLITSURF]  = (1ull << 0) | (1ull << 2),  /* dstrect, srcrect */
        [C4_SDL_IDX_SDLLOADBMP]   = 1ull << 0,                  /* path */
        [C4_SDL_IDX_SDLPOLLEVENT] = 1ull << 0,                  /* event */
        [C4_SDL_IDX_SDLWAITEVENT] = 1ull << 0,                  /* event */
        [C4_SDL_IDX_SDLWAITEVTO]  = 1ull << 1,                  /* event */
        [C4_SDL_IDX_SDLPUSHEVENT] = 1ull << 0,                  /* event */
        [C4_SDL_IDX_SDLGETKBSTATE] = 1ull << 0,                 /* numkeys */
        [C4_SDL_IDX_SDLGETMOUSESTATE] = (1ull << 0) | (1ull << 1),
        [C4_SDL_IDX_SDLRUNAPP]    = (1ull << 0) | (1ull << 2),  /* argv, fn */
    };
    int a8[8];
    int *a = (int *)sb_ptr(args_off);
    u64 mask;

    if (op >= C4_SDL_OP_COUNT) return 0;
    mask = ptr_args[op];
    for (int i = 0; i < 8; i++) a8[i] = a[i];
    for (int i = 0; i < 8; i++)
        if (mask & (1ull << i))
            a8[i] = (int)sb_sdl_xlate((u32)a8[i]);
    return c4_sdl_call((int)op, a8);
}

/* printf: %s-аргументы приходят СМЕЩЕНИЯМИ региона — переводим в
 * абсолютные до вызова ядра. Порядок в массиве — обратный (см. PRTF). */
static int sb_c4_printf_va(u32 fmt_off, int nargs, u32 args_off)
{
    int *args = (int *)sb_ptr(args_off);
    int fmtargs[16];
    int actual = nargs - 1;
    if (actual < 0) actual = 0;
    if (actual > 16) actual = 16;
    for (int i = 0; i < actual; i++) fmtargs[i] = args[i];

    const char *fmt = (const char *)sb_ptr(fmt_off);
    int argidx = 0, i = 0;
    while (fmt && fmt[i] && argidx < actual) {
        if (fmt[i] != '%') { i++; continue; }
        i++;
        char c = fmt[i];
        if (c == 's')
            fmtargs[actual - 1 - argidx] = (int)(unsigned long)sb_ptr((u32)fmtargs[actual - 1 - argidx]);
        if (c == 'd' || c == 's' || c == 'c' || c == 'x') argidx++;
        if (c) i++;
    }
    return c4_printf_va(fmt, nargs, fmtargs);
}

/* snprintf из песочницы: указатели — смещения. ВАЖНО: %s не переводится
 * (кодогенератор c4 snprintf не вызывает — только ручные .bin; для них
 * есть путь без песочницы). */
static int sb_snprintf(u32 out_off, u32 n, u32 fmt_off, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt_off);
    int r = vsnprintf((char *)sb_ptr(out_off), n,
                      (const char *)sb_ptr(fmt_off), ap);
    __builtin_va_end(ap);
    return r;
}

/* Порождать задачи из песочницы нельзя: функция задачи исполнялась бы
 * с сегментами ядра поверх смещений-указателей приложения. */
static int sb_task_spawn(u32 name, u32 fn, u32 arg)
{
    (void)name; (void)fn; (void)arg;
    return -1;
}

/* ---------- универсальный переходник в ядро ----------
 *
 * Стаб в регионе (сессия 14):  pushl $<tid>; pushl $<fn>; jmp sb_thunk_core
 * Стек на входе core: [fn][tid][ret_приложения][args...] (SS=песочница, ESP=смещение)
 *
 * СЕССИЯ 59 (exc #13 @ sb_thunk_core на VMware, eip=0x184bf2, байты 2e 89):
 * ГЛАВНАЯ ПРИЧИНА падений найдена — записи в таблицы ядра шли через
 * CS-override (movl %eax, %cs:sb_retaddr...). Сегмент CS=0x08 — КОДОВЫЙ
 * (GDT access 0x9A): чтение через него допустимо (readable), но ЗАПИСЬ
 * в кодовый сегмент ВСЕГДА #GP по архитектуре x86. VMware проверяет
 * честно — любой kapi-вызов из песочницы падал на первой же записи.
 * QEMU TCG и v86-стенд эту проверку пропускали, поэтому автотесты
 * «exit 0» не ловили баг. Фикс: DS -> ядро ДО любых обращений к ядру;
 * значения ret_app/ES/SS приложения предварительно снимаются (ret_app и
 * ES — через стек приложения, SS — регистром до переключения).
 *
 * Прежде tid брался из cur_task — любое повреждение этого слота давало
 * дикий индекс в таблицах sb_*. Теперь tid приходит СО СТАБА (ядро
 * сгенерировало его в регионе при spawn: надёжный источник),
 * проверяется по границе и дублируется в EBX (callee-saved: переживает
 * call *%edx — GCC ABI сохраняет EBX в C-функциях; IRQ-стабы тоже).
 * Эпилог берёт tid из EBX, НЕ из cur_task.
 *
 * Слот [fn] по-прежнему снимается в EDX ДО вызова — иначе fn получил бы
 * смещённые параметры. Инварианты: DS == SS у всех задач; kapi-вызовы
 * не переключают задачу; аппаратные прерывания в любой точке окна
 * безопасны (их стабы сами переключают DS на ядро и не лезут в таблицы).
 * Регистры ESI/EDI/EBP не трогаются: кодогенератор c4 держит в них
 * kapi/win/кадр на протяжении всей программы. */
u32 sb_seg_es[MAX_TASKS] __attribute__((used)); /* исходный ES задачи на время kapi-вызова */
u32 sb_seg_ss[MAX_TASKS] __attribute__((used)); /* исходный SS (=DS) задачи */
u32 sb_retaddr[MAX_TASKS] __attribute__((used)); /* адрес возврата приложения: снимается со стека, чтобы fn видел СВОИ аргументы */

/* tid-граница для асм-сравнения: SB_TID_LIMIT = 256 (= MAX_TASKS).
 * В асм-строках ниже — литерал 256; при изменении MAX_TASKS поправить
 * и его (компилятор не видит асм-литералы). */
#define SB_TID_LIMIT 256

/* МинGW (i386 PE) добавляет к C-символам префикс «_», ELF — нет. Без
 * этого ссылки на таблицы из inline-asm дают «undefined reference to
 * `g_sb_sel` / `sb_region_size` / `g_sb_entry` / `g_sb_win`» при сборке
 * под Windows (build.bat): ld ищет g_sb_sel, а в объектнике лежит
 * _g_sb_sel. __USER_LABEL_PREFIX__ раскрывается ровно в нужный префикс
 * (пусто на ELF, «_» на PE) — на Linux-сборке строки не меняются. */
#define LDR_STR2(x) #x
#define LDR_STR(x)  LDR_STR2(x)
#define ASM_SYM(x)  LDR_STR(__USER_LABEL_PREFIX__) #x

__attribute__((naked, used)) static void sb_thunk_core(void)
{
    __asm__ __volatile__(
        "popl %edx\n\t"                  /* EDX = fn */
        "popl %ecx\n\t"                  /* ECX = tid (со стаба) */
        "popl %eax\n\t"                  /* EAX = ret_приложения → [args] */
        "cli\n\t"
        /* DS ещё сегмент ПРИЛОЖЕНИЯ: писать в ядро через него нельзя.
         * Читаем границы tid, копим значения приложения и ПЕРЕКЛЮЧАЕМ
         * DS на ядро ДО единственной записи в таблицы (сессия 59). */
        "cmpl $256, %ecx\n\t"           /* SB_TID_MAX: выход за таблицы */
        "jae 3f\n\t"
        "movl %ecx, %ebx\n\t"           /* tid в callee-saved EBX (сессия 14) */
        "pushl %eax\n\t"                 /* ret_app → стек приложения (SS=приложения) */
        "movw %es, %cx\n\t"              /* CX = ES приложения */
        "pushl %ecx\n\t"                 /* ES → стек приложения: [es][ret_app] */
        "movl $0x10, %ecx\n\t"
        "movw %cx, %ds\n\t"              /* DS = ядро: дальше пишем обычной адресацией */
        "movw %cx, %es\n\t"              /* ES = ядро */
        "movw %ss, %cx\n\t"              /* CX = SS приложения (до переключения) */
        "movl %ecx, " ASM_SYM(sb_seg_ss) "(,%ebx,4)\n\t"
        "popl %ecx\n\t"                  /* ECX = ES приложения (SS ещё приложения) */
        "movl %ecx, " ASM_SYM(sb_seg_es) "(,%ebx,4)\n\t"
        "popl %ecx\n\t"                  /* ECX = ret_приложения */
        "movl %ecx, " ASM_SYM(sb_retaddr) "(,%ebx,4)\n\t"
        "movl $0, " ASM_SYM(task_region_base) "(,%ebx,4)\n\t" /* задача в контексте ядра */
        "movl " ASM_SYM(sb_region) "(,%ebx,4), %ecx\n\t"  /* база региона */
        "addl %ecx, %esp\n\t"            /* ESP = абсолютный → [args] */
        "movl $0x10, %ecx\n\t"
        "movw %cx, %ss\n\t"              /* SS = ядро: контекст согласован */
        "sti\n\t"
        "call *%edx\n\t"                 /* fn(args): [core_ret][args] ✓ */
        /* ---- возврат fn: EAX = результат; DS/ES/SS = ядро ---- */
        "cli\n\t"
        "movl %eax, %edx\n\t"            /* EDX = результат */
        "movl %ebx, %eax\n\t"            /* tid из EBX (НЕ cur_task — сессия 14) */
        "cmpl $256, %eax\n\t"
        "jae 4f\n\t"
        "movl " ASM_SYM(sb_retaddr) "(,%eax,4), %ecx\n\t"  /* ecx = ret_приложения */
        "pushl %ecx\n\t"                 /* [ret_app][args] (SS=ядро, абс) */
        "movzwl " ASM_SYM(sb_seg_es) "(,%eax,4), %ecx\n\t"  /* ecx = ES приложения */
        "pushl %ecx\n\t"                 /* [es_sel][ret_app][args] */
        "movl " ASM_SYM(sb_region) "(,%eax,4), %ecx\n\t"  /* база */
        "movl %ecx, " ASM_SYM(task_region_base) "(,%eax,4)\n\t" /* снова в песочнице */
        "subl %ecx, %esp\n\t"            /* ESP = смещение → [es_sel] */
        "movzwl " ASM_SYM(sb_seg_ss) "(,%eax,4), %ecx\n\t"  /* ecx = SS/DS приложения */
        "movw %cx, %ss\n\t"              /* SS = приложения */
        "movw %cx, %ds\n\t"
        "popl %ecx\n\t"                  /* ecx = es_sel (SS=приложения, смещение) */
        "movw %cx, %es\n\t"              /* ES = приложения */
        "movl %edx, %eax\n\t"            /* результат → EAX */
        "sti\n\t"
        "ret\n\t"                        /* → приложение */
        "3:\n\t"                         /* недопустимый tid: отклонить вызов (-1) */
        "pushl %eax\n\t"                 /* ret_app */
        "movl $0xFFFFFFFF, %eax\n\t"     /* результат «отказ» */
        "sti\n\t"
        "ret\n\t"
        "4:\n\t"                         /* tid потерян (недостижимо): упасть
         * ВНУТРИ приложения — загрузчик поймает через exc_panic */
        "movw $0x00, %ax\n\t"
        "movw %ax, %ds\n\t"              /* #GP(0) → перехват приложения */
        "movw %ax, %es\n\t"
        "hlt\n\t"
    );
}

/* ---------- вход в песочницу и выход ----------
 *
 * [NAKED-PARAMS] (отчёт, баг 7): раньше naked-функция с 6 параметрами
 * читала их по ЖЁСТКИМ смещениям 20..40(%esp) — это работает, только
 * пока компилятор кладёт аргументы на стек в точности как ожидается
 * (GCC документирует naked-функции с параметрами как поведение без
 * гарантий: пролог/раскладка не определены). Теперь обычная функция
 * + расширенный asm-блок в духе уже существующих per-task массивов
 * (sb_region[me] и т.д.): region/size вызывающий уже положил в
 * sb_region[]/sb_region_size[], sel/entry/win — в g_sb_*[]; asm
 * получает ЕДИНСТВЕННЫЙ вход «me» и вычитывает остальное из своей
 * строки таблиц. Вход читается первой инструкцией после cli — до
 * первого затирания любого регистра; ранний clobber "=&a" исключает
 * размещение входа в eax (выход). Слот me принадлежит только этой
 * задаче — SMP-гонок нет.
 *
 * Логика прежняя (1:1 со старым asm): переключает DS/ES/SS на сегмент
 * задачи и ESP на вершину стека региона (смещение), вызывает
 * entry(kapi=0, win). Все прерывания корректны: irq_stub_0
 * пересчитывает базу SS (task_region_base). Возврат — с
 * восстановлением сегментов и стека; EAX = код возврата.
 * «me» переживает вызов приложения на СОБСТВЕННОМ стеке ядра
 * (push перед переключением / pop после возврата). */
/* НЕ static + used: массив смотрится только из asm-строк ниже —
 * GCC считает C-записи мёртвыми (чтений из C-кода нет) и убирает
 * хранилище; идиома sb_seg_es[] выше */
u32 g_sb_sel[MAX_TASKS] __attribute__((used));     /* селектор сегмента задачи */
u32 g_sb_entry[MAX_TASKS] __attribute__((used));   /* точка входа приложения */
u32 g_sb_win[MAX_TASKS] __attribute__((used));     /* окно (входной регистр c4) */

static int sandbox_run(int (*entry)(kapi_t *, void *),
                       void *win, u8 *region,
                       u32 size, u16 sel, int me)
{
    int rc;

    if (me < 0 || me >= MAX_TASKS) return -1;
    g_sb_sel[me]   = (u32)sel;      /* уже растянут до 32 бит */
    g_sb_entry[me] = (u32)(unsigned long)entry;
    g_sb_win[me]   = (u32)(unsigned long)win;
    sb_region[me]      = region;    /* источник истины — параметры */
    sb_region_size[me] = size;

    __asm__ __volatile__(
        "pushl %%ebx\n\t"
        "pushl %%esi\n\t"
        "pushl %%edi\n\t"
        "pushl %%ebp\n\t"
        "cli\n\t"
        "movl  %1, %%eax\n\t"                 /* me = ВХОД (номер 1: %0 — выход rc); вход прочитан первым */
        "pushl %%eax\n\t"                     /* me → стек ядра: переживёт песочницу */
        "movl  " ASM_SYM(sb_region) "(,%%eax,4), %%ecx\n\t"        /* region */
        "movl  %%ecx, " ASM_SYM(task_region_base) "(,%%eax,4)\n\t"
        "movl  " ASM_SYM(g_sb_sel) "(,%%eax,4), %%ebx\n\t"         /* селектор сегмента */
        "movl  " ASM_SYM(sb_region_size) "(,%%eax,4), %%ecx\n\t"   /* size = вершина стека (смещение) */
        "movl  " ASM_SYM(g_sb_entry) "(,%%eax,4), %%edx\n\t"       /* entry */
        "movl  " ASM_SYM(g_sb_win) "(,%%eax,4), %%esi\n\t"         /* win */
        "movl  %%esp, %%ebp\n\t"              /* абсолютный кадр (ebp = scratch) */
        "movw  %%bx, %%ds\n\t"
        "movw  %%bx, %%es\n\t"
        "movw  %%bx, %%ss\n\t"                /* база региона; ESP пересчитываем сразу */
        "movl  %%ecx, %%esp\n\t"              /* ESP = смещение вершины стека */
        "xorl  %%edi, %%edi\n\t"              /* kapi-копия лежит по смещению 0 */
        "pushl %%esi\n\t"                     /* arg2: win (значение) */
        "pushl $0\n\t"                        /* arg1: kapi = смещение 0 */
        "sti\n\t"                             /* внутри песочницы прерывания работают */
        "call  *%%edx\n\t"                    /* → приложение; EAX = код возврата */
        "cli\n\t"
        "movl  %%eax, %%edx\n\t"              /* СОХРАНИТЬ rc ДО затирания AX селектором */
        "movw  $0x10, %%ax\n\t"
        "movw  %%ax, %%ds\n\t"
        "movw  %%ax, %%es\n\t"
        "movw  %%ax, %%ss\n\t"
        "movl  %%ebp, %%esp\n\t"              /* вернуть кадр loader'а */
        "popl  %%eax\n\t"                     /* me вернулся со стека ядра */
        "movl  $0, " ASM_SYM(task_region_base) "(,%%eax,4)\n\t"
        "movl  %%edx, %%eax\n\t"              /* код возврата — в EAX для C-вызова */
        "popl  %%ebp\n\t"
        "popl  %%edi\n\t"
        "popl  %%esi\n\t"
        "popl  %%ebx\n\t"
        "sti\n\t"
        : "=&a"(rc)
        : "r"(me)
        : "ecx", "edx", "memory", "cc");
    return rc;
}

/* Хук переиспользования слота: задача убита ватчдогом/kill внутри
 * песочницы — её регион никто не освободил. */
static void sb_slot_cleanup(int tid)
{
    if (tid < 0 || tid >= MAX_TASKS) return;
    if (sb_region[tid]) {
        free(sb_region[tid]);
        sb_region[tid] = NULL;
        sb_arena[tid] = NULL;
        sb_arena_end[tid] = NULL;
    }
}

typedef struct {
    int  (*entry)(kapi_t *k, void *win);   /* возвращает exit-код (EAX) */
    kapi_t  kapi;
    void   *win;
    void   *code;     /* загруженный машинный код (освобождается в on_done) */
    u32     code_size;
    void   *data;     /* сегмент данных C4N1 (отдельный блок; NULL для старых .bin) */
    u32     data_size;
    char    name[32]; /* имя файла — для заголовка окна вывода и serial */
    /* песочница (защита памяти): регион = kapi-копия + стабы + данные
     * + куча + стек; NULL → исполнять как раньше (сегменты ядра) */
    void   *sandbox;
    u32     sandbox_size;
    u32     sandbox_arena_off;   /* смещение кучи внутри региона */
} loader_ctx_t;

/* ===================== Защита от падения приложений ===================== */
/* FIX [L1]: ПЕРЕ-ЗАДАЧНЫЙ setjmp-буфер. Раньше был ОДИН глобальный
 * g_app_jmp на всю систему: второе запущенное приложение перезаписывало
 * буфер первого; исключение в первом longjmp-нулось в кадр ВТОРОГО
 * (кросс-задачная порча стека), а нормальное завершение первого
 * снимало защиту у всех. Теперь буфер индексируется task_current(). */
#include "task.h"
/* ВНИМАНИЕ: буфер __builtin_setjmp должен вмещать НЕ МЕНЕЕ 5 указателей
 * (требование GCC) — даём 8 слов на задачу; 2 слов мало (порча соседей в BSS). */
static void *g_app_jmp[MAX_TASKS][8];  /* буфер setjmp на задачу */
static int   g_app_active_map[MAX_TASKS] = {0};
static u32   g_app_exc_num_map[MAX_TASKS] = {0};
static u32   g_app_exc_eip_map[MAX_TASKS] = {0};   /* EIP сбоя (сессия 13) */

/* Сессия 13: управление песочницей (cmdline sandbox=off — GRUB «без
 * песочницы»: старый режим памяти, релоки абсолютные, сегменты ядра).
 * Нужно для диагностики #exc13 на машинах, где QEMU-норма не работает. */
static int g_loader_sandbox = 1;
void loader_set_sandbox(int on) { g_loader_sandbox = on ? 1 : 0; }

/* Запомнить EIP сбоя текущей задачи (вызывает exc_panic из idt.c). */
void loader_set_app_eip(u32 eip)
{
    int t = task_current();
    if (t < 0 || t >= MAX_TASKS) return;
    g_app_exc_eip_map[t] = eip;
}

/* Получить адрес jmp-буфера для ТЕКУЩЕЙ задачи (для idt.c) */
void **loader_get_app_jmp(void)
{
    int t = task_current();
    if (t < 0 || t >= MAX_TASKS) return NULL;
    return g_app_active_map[t] ? g_app_jmp[t] : NULL;
}

/* Установить/снять флаг активного приложения (для текущей задачи) */
void loader_set_app_active(int active, u32 exc_num)
{
    int t = task_current();
    if (t < 0 || t >= MAX_TASKS) return;
    g_app_active_map[t] = active;
    g_app_exc_num_map[t] = exc_num;
}

/* Заполняем таблицу API ядра для передаваемого приложения. */
void kapi_fill(kapi_t *k)
{
    k->fb_fill_rect  = fb_fill_rect;
    k->fb_rect       = fb_rect;
    k->fb_hline      = fb_hline;
    k->fb_text       = fb_text;
    k->fb_char       = fb_char;
    k->fb_rgb        = fb_rgb;
    k->fb_width      = fb_width;
    k->fb_height     = fb_height;
    k->fb_fill_screen = fb_fill_screen;
    k->win_content_w = win_content_w;
    k->win_content_h = win_content_h;
    k->win_invalidate = win_invalidate;
    k->malloc        = malloc;
    k->free          = free;
    k->uptime_sec    = uptime_sec;
    k->timer_ticks   = timer_ticks;
    k->task_yield    = task_yield;
    k->task_spawn    = task_spawn;
    k->snprintf      = snprintf;
    k->strlen        = strlen;
    k->strcmp        = strcmp;
    k->strcpy        = strcpy;
    k->memcmp        = memcmp;
    k->memset        = memset;
    k->memcpy        = memcpy;
    k->c4_print_str  = c4_print_str;
    k->c4_printf_va  = c4_printf_va;
    k->msleep        = task_msleep;
    /* сессия 56 (обновление c4): GUI из c4-программ — тот же движок
     * окон, что у CMScript (c4k_* в cmscript_api.c) */
    k->win_open       = c4k_win_open;
    k->win_close      = c4k_win_close;
    k->win_alive      = c4k_win_alive;
    k->win_clear      = c4k_win_clear;
    k->win_rect       = c4k_win_rect;
    k->win_text       = c4k_win_text;
    k->win_update     = c4k_win_update;
    k->btn_add        = c4k_btn_add;
    k->btn_clicked    = c4k_btn_clicked;
    k->btn_set_label  = c4k_btn_set_label;
    /* сессия 60: MP3-декодер dr_mp3 для приложений (mp3svc.c) */
    k->mp3_open_mem   = kapi_mp3_open_mem;
    k->mp3_close      = kapi_mp3_close;
    k->mp3_channels   = kapi_mp3_channels;
    k->mp3_rate       = kapi_mp3_rate;
    k->mp3_read_s16   = kapi_mp3_read_s16;
    k->mp3_seek       = kapi_mp3_seek;
    k->mp3_total_frames = kapi_mp3_total;
    /* сессия 74: общий FPU-лок для native c4-программ с float-кодом
     * (x87-состояние не сохраняется планировщиком — imgsvc.h) */
    k->fpu_lock       = img_fpu_lock;
    k->fpu_unlock     = img_fpu_unlock;
    /* Task 54: SDL2-подмножество для c4-программ (диспетчер — sdl2.c) */
    k->sdl_call       = c4_sdl_call;
    c4_gui_init();   /* VM-путь c4.c: та же таблица */

    /* Графика c4-программ — через ОКНО с canvas (c4gfx): прямой вывод
     * на экран стирается композитором многопоточного WM. kevent читает
     * события из очереди окна (kbd_pop вытягивается kmain раньше). */
    k->fb_fill_rect   = c4_gfx_fill_rect;
    k->fb_text        = c4_gfx_text;
    k->fb_fill_screen = c4_gfx_fill_screen;
    k->fb_width       = c4_gfx_width;
    k->fb_height      = c4_gfx_height;
    k->win_invalidate = c4_gfx_flip;
    k->c4_event_poll  = c4_gfx_event_poll;
}

void *loader_load(const char *name, u32 *out_size)
{
    if (!ramfs_ready() || !name) return NULL;

    /* Сначала узнаем размер (через list — find-функции в ramfs нет в публичном API). */
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    u32 size = 0;
    int found = 0;
    for (int i = 0; i < n; i++) {
        if (strcmp(ents[i].name, name) == 0) {
            size = ents[i].size;
            found = 1;
            break;
        }
    }
        if (!found || size == 0) return NULL;

    u8 *buf = (u8 *)malloc(size);
    if (!buf) return NULL;
    u32 got = ramfs_read(name, buf, size);
    if (got == 0) {
        free(buf);
        return NULL;
    }
    if (out_size) *out_size = got;
    return buf;
}

/* Валидация первых байтов бинарника.
 * c4_x86 генерирует entry stub:
 *   55              push ebp
 *   89 E5           mov ebp, esp
 *   8B 7D 08        mov edi, [ebp+8]
 *   8B 75 0C        mov esi, [ebp+12]
 *   E9 ?? ?? ?? ??  jmp rel32  (к main body)
 * Проверяем первые 9 байт и 10-й = E9 (jmp) или E8 (call).
 *
 * Если бинарник сгенерирован другим компилятором (GCC flat-binary):
 *   Может начинаться с 55 89 E5 (push ebp; mov ebp,esp) — это тоже валидно. */
static int validate_binary(const u8 *code, u32 size)
{
    if (!code || size < 6) return 0;

    /* Вариант 1: c4_x86 entry stub (push ebp; mov ebp,esp; ...) */
    if (code[0] == 0x55 && code[1] == 0x89 && code[2] == 0xE5) {
        /* Стандартный prologue. Проверим что дальше что-то разумное. */
        if (size >= 10 && (code[9] == 0xE9 || code[9] == 0xE8 ||
                           code[9] == 0x83 || code[9] == 0xC7)) {
            return 1;  /* jmp rel32 / call / sub esp / mov edi */
        }
        /* Или прямой call (GCC-style): 55 89 E5 83 EC XX */
        if (size >= 6 && code[3] == 0x83 && code[4] == 0xEC) {
            return 1;
        }
        /* Минимум: prologue присутствует, дальше любой код */
        return 1;
    }

    /* Вариант 2: сразу jump/call (если бинарник начинается с перехода) */
    if (code[0] == 0xE9 || code[0] == 0xE8) return 1;

    /* Вариант 3: mov edi, imm32 (B8) — тоже валидный старт */
    if (code[0] == 0xB8) return 1;

    /* Вариант 4: первые байты — NOP (90) или push (50-57) */
    if (code[0] == 0x90) return 1;
    /* [POP-RANGE] (отчёт, баг 6): 0x58-0x5F — это POP (EAX..EDI), а
     * не push! Валидная программа начинается с PUSH (сохранение
     * регистров), POP первым байтом снимает мусор со стека — такое
     * начало у ЛЮБОГО осмысленного кода отсутствует; зато так
     * начинаются данные/битые файлы, принятые за приложение. Диапазон
     * сужен до честных push 0x50-0x57. */
    if (code[0] >= 0x50 && code[0] <= 0x57) return 1;

    return 0;  /* невалидный старт */
}

/* ---------- построение региона песочницы ----------
 *
 * Возвращает malloc-блок или NULL (нехватка памяти → старый путь без
 * песочницы). Смещения:
 *   0                    kapi-копия (указатели на СТАБЫ в этом же регионе)
 *   off_thunks           29 стабов «pushl fn; jmp sb_thunk_core»
 *   off_data             сегмент данных C4N1 (релоки патчатся СМЕЩЕНИЕМ)
 *   off_arena            куча kapi->malloc (bump)
 *   region_size-SB..     стек приложения (вершина = конец региона)
 * Все указатели, которые видит приложение, — СМЕЩЕНИЯ от базы региона. */
static void *sb_build_region(const u8 *data_img, u32 dsz, u32 *out_size,
                             u32 *out_off_data, u32 *out_off_arena)
{
    u32 n_entries = sizeof(kapi_t) / 4;
    u32 off_kapi  = 0;
    u32 off_thunks = sizeof(kapi_t);
    u32 thunks_sz = n_entries * 15;   /* сессия 14: pushl tid + pushl fn + jmp rel32 */
    u32 off_data  = (off_thunks + thunks_sz + 3u) & ~3u;
    u32 off_arena = (off_data + dsz + 3u) & ~3u;
    u32 off_stack = off_arena + SB_HEAP_SZ;
    u32 total     = off_stack + SB_STACK_SZ;

    u8 *region = (u8 *)malloc(total);
    if (!region) return NULL;
    memset(region, 0, total);

    /* kapi-копия: адрес «настоящей» функции (или обёртки) для каждого поля */
    void *target[64];   /* Task 54: расширено (mp3/fpu/sdl_call) — было 48,*/
                        /* покрывало поля 0..47 при sizeof(kapi_t)/4 = 49 */
    kapi_t proto;
    kapi_fill(&proto);
    target[0]  = (void *)c4_gfx_fill_rect;       /* fb_fill_rect */
    target[1]  = (void *)fb_rect;                 /* fb_rect */
    target[2]  = (void *)fb_hline;                /* fb_hline */
    target[3]  = (void *)sb_fb_text;              /* fb_text — указатель! */
    target[4]  = (void *)fb_char;                 /* fb_char */
    target[5]  = (void *)fb_rgb;                  /* fb_rgb */
    target[6]  = (void *)c4_gfx_width;            /* fb_width */
    target[7]  = (void *)c4_gfx_height;           /* fb_height */
    target[8]  = (void *)c4_gfx_fill_screen;      /* fb_fill_screen */
    target[9]  = (void *)win_content_w;           /* win_content_w (win — значение) */
    target[10] = (void *)win_content_h;           /* win_content_h */
    target[11] = (void *)c4_gfx_flip;             /* win_invalidate (win — значение) */
    target[12] = (void *)sb_malloc;               /* malloc → смещение */
    target[13] = (void *)sb_free;                 /* free */
    target[14] = (void *)uptime_sec;              /* uptime_sec */
    target[15] = (void *)timer_ticks;             /* timer_ticks */
    target[16] = (void *)task_yield;              /* task_yield */
    target[17] = (void *)sb_task_spawn;           /* task_spawn — запрещено */
    target[18] = (void *)sb_snprintf;             /* snprintf — указатели */
    target[19] = (void *)sb_strlen;               /* strlen */
    target[20] = (void *)sb_strcmp;               /* strcmp */
    target[21] = (void *)sb_strcpy;               /* strcpy */
    target[22] = (void *)sb_memcmp;               /* memcmp */
    target[23] = (void *)sb_memset;               /* memset */
    target[24] = (void *)sb_memcpy;               /* memcpy */
    target[25] = (void *)sb_c4_print_str;         /* c4_print_str */
    target[26] = (void *)sb_c4_event_poll;        /* c4_event_poll */
    target[27] = (void *)sb_c4_printf_va;         /* c4_printf_va */
    target[28] = (void *)task_msleep;             /* msleep */
    /* сессия 56 (обновление c4): CMScript GUI для c4-программ.
    * c4k_* безопасны из любой задачи (sg_lock), вызовов с указателями
    * из песочницы не боятся: строки читают только под sg_lock на
    * копирование (sg_copy_str) — как и все указательные стабы выше,
    * полагаемся на валидность данных приложения. */
    target[29] = (void *)c4k_win_open;            /* win_open */
    target[30] = (void *)c4k_win_close;           /* win_close */
    target[31] = (void *)c4k_win_alive;           /* win_alive */
    target[32] = (void *)c4k_win_clear;           /* win_clear */
    target[33] = (void *)c4k_win_rect;            /* win_rect */
    target[34] = (void *)c4k_win_text;            /* win_text */
    target[35] = (void *)c4k_win_update;          /* win_update */
    target[36] = (void *)c4k_btn_add;             /* btn_add */
    target[37] = (void *)c4k_btn_clicked;         /* btn_clicked */
    target[38] = (void *)c4k_btn_set_label;       /* btn_set_label */
    /* [SB-KAPI-GAP] (Task 54): поля 39..48 раньше МОЛЧА уходили в
     * fallback task_msleep (i >= 39) — MP3-декодер, FPU-лок и SDL2 в
     * sandbox-программах были неработоспособны «тихо». Явно задаём все
     * оставшиеся поля kapi_t (loader_task_fn/dispatcher path). */
    target[39] = (void *)kapi_mp3_open_mem;       /* mp3_open_mem */
    target[40] = (void *)kapi_mp3_close;          /* mp3_close */
    target[41] = (void *)kapi_mp3_channels;       /* mp3_channels */
    target[42] = (void *)kapi_mp3_rate;           /* mp3_rate */
    target[43] = (void *)kapi_mp3_read_s16;       /* mp3_read_s16 */
    target[44] = (void *)kapi_mp3_seek;           /* mp3_seek */
    target[45] = (void *)kapi_mp3_total;          /* mp3_total_frames */
    target[46] = (void *)img_fpu_lock;            /* fpu_lock */
    target[47] = (void *)img_fpu_unlock;          /* fpu_unlock */
    target[48] = (void *)sb_c4_sdl_call;          /* sdl_call (SDL2) */
    (void)proto;

    /* генерация стабов (сессия 14): pushl $tid; pushl $fn; jmp rel32.
     * tid вписывается позже — в loader_task_fn, когда задача создана
     * (стабы принадлежат региону Задачи; источник — ядро, доверяем). */
    for (u32 i = 0; i < n_entries; i++) {
        u8 *stub = region + off_thunks + i * 15;
        u32 fn = (i < 49) ? (u32)(unsigned long)target[i]
                          : (u32)(unsigned long)task_msleep;
        stub[0] = 0x68;                          /* push imm32 (tid, патчится) */
        stub[1] = 0;
        stub[2] = 0;
        stub[3] = 0;
        stub[4] = 0;
        stub[5] = 0x68;                          /* push imm32 (fn) */
        stub[6] = (u8)(fn & 0xFF);
        stub[7] = (u8)((fn >> 8) & 0xFF);
        stub[8] = (u8)((fn >> 16) & 0xFF);
        stub[9] = (u8)((fn >> 24) & 0xFF);
        u32 next = (u32)(unsigned long)(stub + 15);
        u32 core = (u32)(unsigned long)&sb_thunk_core;
        u32 rel = core - next;
        stub[10] = 0xE9;                         /* jmp rel32 */
        stub[11] = (u8)(rel & 0xFF);
        stub[12] = (u8)((rel >> 8) & 0xFF);
        stub[13] = (u8)((rel >> 16) & 0xFF);
        stub[14] = (u8)((rel >> 24) & 0xFF);
        /* kapi-копия: АБСОЛЮТНЫЙ адрес стаба (код вызывает его как код) */
        u32 *slot = (u32 *)(region + off_kapi + i * 4);
        *slot = (u32)(unsigned long)stub;
    }

    /* сегмент данных */
    if (dsz) memcpy(region + off_data, data_img, dsz);

    *out_size = total;
    *out_off_data = off_data;
    *out_off_arena = off_arena;
    return region;
}

/* Тело новой задачи: вызвать entry() под защитой setjmp, затем завершить. */
static void loader_task_fn(void *arg)
{
    loader_ctx_t *ctx = (loader_ctx_t *)arg;

    /* Вывод нативных c4-программ (printf): захватываем в буфер, чтобы
     * показать пользователю в окне и продампить в serial. Консольные
     * программы (win == NULL) РАНЬШЕ вообще теряли весь вывод —
     * c4_out устанавливался только в c4_run (путь редактора F9). */
    char *cap = (char *)malloc(8192);
    if (cap) c4_capture_begin(cap, 8192);

    /* Устанавливаем setjmp для перехвата исключений.
     * Если приложение вызовет #GP/#PF/#UD и т.д., exc_panic
     * (в idt.c) сделает __builtin_longjmp(g_app_jmp, 1)
     * вместо halt — и мы попадём сюда, после if. */
    int me = task_current();   /* FIX [L1]: буфер СВОЕЙ задачи */
    int rc = 0;
    int crashed = 0;
    if (me >= 0 && me < MAX_TASKS && __builtin_setjmp(g_app_jmp[me]) == 0) {
        /* Нормальный путь: выполняем приложение. Код возврата — в EAX
         * (entry() возвращает int; в c4 это exit-код main). */
        loader_set_app_active(1, 0);
        c4_gfx_set_name(ctx->name);   /* заголовок окна графики */
        if (ctx->entry) {
            if (ctx->sandbox) {
                /* ЗАЩИТА ПАМЯТИ: нативный c4-код исполняется в сегменте
                 * своего региона — запись мимо региона = #GP = смерть
                 * приложения, ядро и соседи живут. */
                u8 *region = (u8 *)ctx->sandbox;
                u32 rsize  = ctx->sandbox_size;
                gdt_set_task_region(me, (u32)(unsigned long)region, rsize);
                sb_region[me] = region;
                sb_region_size[me] = rsize;
                sb_arena[me] = region + ctx->sandbox_arena_off;
                sb_arena_end[me] = region + ctx->sandbox_arena_off + SB_HEAP_SZ;
                {
                    /* СЕССИЯ 14: вписать tid ЭТОЙ задачи в стабы региона —
                     * надёжный источник для sb_thunk_core (вместо cur_task) */
                    u32 n_entries = sizeof(kapi_t) / 4;
                    u32 off_thunks = sizeof(kapi_t);
                    for (u32 i = 0; i < n_entries; i++) {
                        u8 *sb = region + off_thunks + i * 15 + 1;
                        sb[0] = (u8)(me & 0xFF);
                        sb[1] = (u8)((me >> 8) & 0xFF);
                        sb[2] = (u8)((me >> 16) & 0xFF);
                        sb[3] = (u8)((me >> 24) & 0xFF);
                    }
                }
                {
                    char msg[96];
                    snprintf(msg, sizeof(msg),
                             "[loader] sandbox %s: region %x..%x (seg %x)\n",
                             ctx->name, (unsigned)(unsigned long)region,
                             (unsigned)((unsigned long)region + rsize),
                             (unsigned)gdt_task_selector(me));
                    serial_puts(msg);
                }
                rc = sandbox_run(ctx->entry, ctx->win, region, rsize,
                                 gdt_task_selector(me), me);
                gdt_clear_task_region(me);
                sb_region[me] = NULL;
            } else {
                rc = ctx->entry(&ctx->kapi, ctx->win);
            }
        }
        c4_gfx_detach();              /* canvas остаётся у окна (кадр виден) */
        loader_set_app_active(0, 0);
        /* СЕССИЯ 82 [SG-ORPHAN]: приложение завершено — его script-GUI
         * окна закрываются, слоты g_sgw[] не утекают. */
        sg_win_release_owner(task_current());
    } else {
        crashed = 1;
        /* Исключение в приложении! exc_panic сделал longjmp сюда.
         * Номер исключения exc_panic уже записал в g_app_exc_num_map[].
         * me пересчитываем заново: __builtin_setjmp регистры не сохраняет.
         *
         * ЗАЩИТА ПАМЯТИ: longjmp вернул ESP/EBP на стек loader'а, но
         * DS/ES/SS могут остаться СЕГМЕНТАМИ ПЕСОЧНИЦЫ (база = регион):
         * любой push/pop ушёл бы по адресу base+esp в чужую память.
         * exc_panic уже сделал cli() — сразу возвращаем сегменты ядра
         * и гасим регион в task_region_base (иначе IRQ0 на ядрной
         * задаче с базой региона пересчитал бы ESP неправильно). */
        __asm__ __volatile__(
            "movw $0x10, %%ax\n\t"
            "movw %%ax, %%ds\n\t"
            "movw %%ax, %%es\n\t"
            "movw %%ax, %%ss\n\t"
            ::: "eax", "memory");
        {
            int me2 = task_current();
            if (me2 >= 0 && me2 < MAX_TASKS) {
                task_set_region_base(me2, 0);
                if (sb_region[me2]) {
                    gdt_clear_task_region(me2);
                    sb_region[me2] = NULL;
                }
            }
        }
        int me2 = task_current();
        u32 exc = (me2 >= 0 && me2 < MAX_TASKS) ? g_app_exc_num_map[me2] : 0;
        u32 feip = (me2 >= 0 && me2 < MAX_TASKS) ? g_app_exc_eip_map[me2] : 0;
        c4_gfx_detach();              /* FIX: canvas не должен висеть на умирающей задаче */
        loader_set_app_active(0, 0);
        /* СЕССИЯ 82 [SG-ORPHAN]: авария — окна приложения всё равно
         * умирают вместе с задачей (зомби-окно + течённый слот — нет) */
        sg_win_release_owner(task_current());
        /* FIX (многопоточный WM): если у задачи был canvas — отключить,
         * иначе сообщение о падению уйдёт в canvas невидимого окна. */
        fb_task_canvas_detach(me2);
        serial_puts("[loader] app crashed (exception caught)\n");
        {
            /* Сессия 13: полный адрес сбоя — экран + serial + klog(dmesg):
             * по eip можно найти инструкцию в дампе (bindump) — так
             * пользователь сможет сообщить точную причину #exc13. */
            char kbuf[224];
            extern void klog_puts(const char *s);
            extern int  snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(kbuf, sizeof(kbuf),
                     "[loader] приложение '%s' упало: exc #%u @ eip=%08x\n"
                     "  eip внутри ядра — kapi-переход sb_thunk_core (сессия 59):\n"
                     "  записи в таблицы ядра больше не идут через CS-override\n"
                     "  (запись в кодовый сегмент = #GP на VMware). Если падение\n"
                     "  повторилось — см. строку [exc] выше: ds/es = сегменты\n"
                     "  приложения, байты инструкции в поле code=.\n",
                     ctx->name, (unsigned)exc, (unsigned)feip);
            serial_puts(kbuf);
            klog_puts(kbuf);
            if (fb_ready()) {
                char buf[96];
                snprintf(buf, sizeof(buf), "App crashed: exc #%u @ eip=%08x",
                         (unsigned)exc, (unsigned)feip);
                fb_fill_rect(0, (int)fb_height() - 60, 480, 20, fb_rgb(0x80, 0x10, 0x10));
                fb_text(4, (int)fb_height() - 56, buf, fb_rgb(0xFF, 0xFF, 0xFF), -1);
                fb_touch_all();
                fb_flush();
            }
        }
    }

    /* Захваченный вывод: serial (диагностика/автотесты) + окно пользователю.
     * Длину снимаем ДО c4_capture_end (тот обнуляет позицию). */
    if (cap) {
        u32 cap_len = c4_capture_len();
        c4_capture_end();
        char hdr[64];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(hdr, sizeof(hdr), "[c4out:%s] exit code: ", ctx->name);
        serial_puts(hdr);
        if (crashed) serial_puts("CRASH");
        else { char n[12]; snprintf(n, sizeof(n), "%d", rc); serial_puts(n); }
        serial_puts("\n");
        if (cap_len > 0) {
            char hdr2[56];
            snprintf(hdr2, sizeof(hdr2), "[c4out:%s] ---\n", ctx->name);
            serial_puts(hdr2);
            serial_puts(cap);
            char title[48];
            snprintf(title, sizeof(title), "Вывод %s (exit %d)",
                     ctx->name, crashed ? -1 : rc);
            app_outwin_open(title, cap, cap_len);
        }
        free(cap);
    }

    /* Освобождаем выделенную под код/данные память */
    if (ctx->code) free(ctx->code);
    if (ctx->data) free(ctx->data);
    if (ctx->sandbox) free(ctx->sandbox);
    free(ctx);
    task_exit();
}

int loader_spawn(const char *name, struct window *win)
{
    /* Регистрируем хук очистки песочниц (kill/ватчдог внутри региона) */
    static int sb_hook_installed = 0;
    if (!sb_hook_installed) {
        task_set_slot_cleanup_hook(sb_slot_cleanup);
        sb_hook_installed = 1;
    }

    u32 size = 0;
    void *code = loader_load(name, &size);
    if (!code) return -1;

    void *data = NULL;
    u32   data_size = 0;
    void *sandbox = NULL;
    u32   sandbox_size = 0;
    u32   sandbox_arena_off = 0;

    /* ---------- Формат C4N1 (native c4): код + СВОЙ сегмент данных +
     * релокации. Раньше код ссылался на СТАТИЧЕСКИЙ data_pool
     * компилятора в ядре — любая перекомпиляция затирала данные ВСЕХ
     * запущенных бинарников (и они читали мусор). Теперь данные —
     * отдельный блок на бинарник, а imm32-адреса патчатся по reloc-списку. */
    if (size >= 16 && ((u8 *)code)[0] == 'C' && ((u8 *)code)[1] == '4' &&
        ((u8 *)code)[2] == 'N' && ((u8 *)code)[3] == '1') {
        const u8 *raw = (const u8 *)code;
        u32 code_size = raw[4] | (raw[5] << 8) | ((u32)raw[6] << 16) | ((u32)raw[7] << 24);
        u32 dsz       = raw[8] | (raw[9] << 8) | ((u32)raw[10] << 16) | ((u32)raw[11] << 24);
        u32 n_rel     = raw[12] | (raw[13] << 8) | ((u32)raw[14] << 16) | ((u32)raw[15] << 24);
        if (code_size == 0 || code_size > size ||
            16u + code_size + dsz + n_rel * 4u > size) {
            serial_puts("[loader] C4N1 header corrupted\n");
            free(code);
            return -1;
        }
        u8 *cbuf = (u8 *)malloc(code_size);
        if (!cbuf) { free(code); return -1; }
        memcpy(cbuf, raw + 16, code_size);

        /* ---------- ЗАЩИТА ПАМЯТИ: регион песочницы ----------
         * Все C4N1-бинарники исполняются в своём сегменте [base,base+size).
         * При нехватке памяти — откат на старый путь (dbuf отдельным
         * блоком, релоки абсолютные, сегменты ядра). */
        u32 off_data = 0, off_arena = 0, rsize = 0;
        /* Сессия 13: sandbox=off (GRUB «без песочницы») — старый режим:
         * данные отдельным блоком, релоки АБСОЛЮТНЫЕ, сегменты ядра. */
        if (!g_loader_sandbox) {
            serial_puts("[loader] sandbox=off: регион НЕ строится (cmdline)\n");
        } else {
            sandbox = sb_build_region(raw + 16 + code_size, dsz,
                                      &rsize, &off_data, &off_arena);
        }
        u8 *dbuf;
        if (sandbox) {
            dbuf = (u8 *)sandbox + off_data;   /* данные — внутри региона */
            sandbox_size = rsize;
            sandbox_arena_off = off_arena;
        } else {
            serial_puts("[loader] sandbox: нет памяти — БЕЗ защиты сегментов\n");
            dbuf = NULL;
            if (dsz > 0) {
                dbuf = (u8 *)malloc(dsz);
                if (!dbuf) { free(cbuf); free(code); return -1; }
                memcpy(dbuf, raw + 16 + code_size, dsz);
            }
            data_size = dsz;
            data = dbuf;
        }
        /* Релокации: в коде лежат СМЕЩЕНИЯ в сегменте данных.
         * Песочница: прибавляем СМЕЩЕНИЕ данных внутри региона (все
         * указатели приложения — смещения от базы региона).
         * Без песочницы: прибавляем АБСОЛЮТНЫЙ адрес блока данных. */
        const u8 *rel = raw + 16 + code_size + dsz;
        int rel_ok = 1;
        u32 add = sandbox ? off_data : (u32)(unsigned long)dbuf;
        for (u32 i = 0; i < n_rel; i++) {
            u32 off = rel[i*4] | (rel[i*4+1] << 8) | (rel[i*4+2] << 16) | (rel[i*4+3] << 24);
            if (off + 4 > code_size) { rel_ok = 0; break; }
            u32 *imm = (u32 *)(cbuf + off);
            *imm += add;
        }
        if (!rel_ok) {
            serial_puts("[loader] C4N1 bad relocation\n");
            free(cbuf);
            if (sandbox) free(sandbox);
            else { if (dbuf) free(dbuf); }
            free(code);
            return -1;
        }
        free(code);            /* исходный образ больше не нужен */
        code = cbuf;
        size = code_size;
        if (!sandbox) { data = dbuf; data_size = dsz; }
        {
            char msg[96];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            if (sandbox)
                snprintf(msg, sizeof(msg),
                         "[loader] C4N1: code %u + data %u + %u relocs (sandbox %u байт)\n",
                         (unsigned)code_size, (unsigned)dsz, (unsigned)n_rel,
                         (unsigned)rsize);
            else
                snprintf(msg, sizeof(msg),
                         "[loader] C4N1: code %u + data %u + %u relocs\n",
                         (unsigned)code_size, (unsigned)dsz, (unsigned)n_rel);
            serial_puts(msg);
        }
    } else {
        /* Валидация (только для старого «сырого» формата) */
        if (!validate_binary((const u8 *)code, size)) {
            char msg[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            (void)msg;
            serial_puts("[loader] binary validation failed\n");
            /* Покажем первые байты для диагностики */
            {
                char hex[40];
                int p = 0;
                for (int i = 0; i < 8 && i < (int)size; i++)
                    p += snprintf(hex + p, sizeof(hex) - p, "%02x ",
                                   (unsigned)((u8 *)code)[i]);
                serial_puts("[loader] first bytes: ");
                serial_puts(hex);
                serial_puts("\n");
            }
            free(code);
            return -1;
        }
    }

    loader_ctx_t *ctx = (loader_ctx_t *)malloc(sizeof(loader_ctx_t));
    if (!ctx) {
        free(code);
        if (data) free(data);
        if (sandbox) free(sandbox);
        return -1;
    }
    kapi_fill(&ctx->kapi);
    ctx->entry = (int (*)(kapi_t *, void *))code;
    ctx->win   = win;
    ctx->code  = code;
    ctx->code_size = size;
    ctx->data = data;
    ctx->data_size = data_size;
    ctx->sandbox = sandbox;
    ctx->sandbox_size = sandbox_size;
    ctx->sandbox_arena_off = sandbox_arena_off;
    {
        u32 i = 0;
        while (name && name[i] && i < sizeof(ctx->name) - 1) {
            ctx->name[i] = name[i];
            i++;
        }
        ctx->name[i] = 0;
    }

    int tid = task_spawn(name, loader_task_fn, ctx);
        if (tid < 0) {
        free(code);
        if (data) free(data);
        if (sandbox) free(sandbox);
        free(ctx);
        return -1;
    }
    return tid;
}
