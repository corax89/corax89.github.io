/* mtrr.h — WC-тип памяти для LFB (реализация в mtrr.c, Task 49). */
#ifndef MTRR_H
#define MTRR_H

#include "types.h"
#include "boot.h"

/* Настроить WC на LFB из multiboot-информации (безопасно звать один
 * раз из kmain после fb_init; при отсутствии MTRR — no-op). */
void mtrr_lfb_wc(const mb_info_t *mb);

int  mtrr_lfb_wc_enabled(void);      /* 1 = WC включён (диагностика) */
void mtrr_lfb_wc_extra(u32 bytes);   /* расширить WC на доп. объём */

#endif /* MTRR_H */
