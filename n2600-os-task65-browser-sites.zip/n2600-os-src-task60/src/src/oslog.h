/* oslog.h — общий слой префиксного лога (Task 49).
 *
 * ДО: каждая подсистема собирала «[тег] строка» сама: wifi_log (одна
 * serial_puts ради атомарности + klog без хвостового \n), snd_log
 * (ДВЕ serial_puts — префикс мог вклиниться чужой строкой, урок
 * [CONSOLE] Сессии 73), dbg/dbg_err (serial+klog+экран — свой экран
 * не выносится: у kernel.c своё состояние dbg_y/прокрутки).
 *
 * ТЕПЕРЬ: oslog_puts/oslogf — единое ядро «[тег] строка»: ОДНА
 * serial_puts (атомарно на строку) + klog_puts (dmesg). Экранный
 * вывод и специализированные кольца (журнал приложения WiFi) остаются
 * у владельцев — они не «обвязка», а состояние.
 * Совместимость: wifi_log/snd_log сохраняют свои API. */
#ifndef OSLOG_H
#define OSLOG_H

/* "[tag] s\n" — serial ОДНОЙ печатью (атомарность строки), затем klog
 * (dmesg; хвостовой \n снимается — klog_puts добавляет свой). */
void oslog_puts(const char *tag, const char *s);

/* oslog_puts с форматированием (буфер 160 байт, как у klog-лимита). */
void oslogf(const char *tag, const char *fmt, ...);

#endif /* OSLOG_H */
