/* snd_es1370.c — драйвер ENSONIQ AudioPCI ES1370 (PCI 1274:5000).
 *
 * Сессия 58: «драйвер Sound Blaster PCI 128 (ES1373) для теста на другом
 * эмуляторе». ES1371/ES1373 (1274:1371) уже покрыт snd_es1371.c — он же
 * «Sound Blaster AudioPCI» VMware и «Sound Blaster PCI 128» в 86Box/PCem.
 * ES1370 — это QEMU `-device es1370` (Ensoniq AudioPCI, тот же чип, что
 * «Sound Blaster PCI 64»), поэтому добавлен для тестирования звука в QEMU.
 *
 * Карта регистров — по hw/audio/es1370.c QEMU (и ALSA CHIP1370):
 *   0x00 CONTROL, 0x04 STATUS, 0x0c MEMPAGE, 0x20 SERIAL (SCTRL),
 *   0x24/0x28/0x2c DAC1/DAC2/ADC_SCOUNT,
 *   страница MEM_PAGE=0x0c: 0x30/0x34 DAC1 FRAMEADR/FRAMECNT,
 *                           0x38/0x3c DAC2 FRAMEADR/FRAMECNT.
 *
 * Отличия от ES1371:
 *   - частота DAC2 задаётся делителем PCLKDIV в CONTROL (без SRC):
 *     PCLKDIV = 1411200/rate - 2 (QEMU DAC2_SRTODIV);
 *   - AC97-кодек QEMU не эмулирует (записи в 0x10 игнорируются),
 *     громкость фиксирована — инициализация кодека не нужна;
 *   - FRAMECNT: пишем размер в dword - 1 (как в ALSA CHIP1370);
 *   - SCOUNT — во фреймах (QEMU хранит (val<<16)|val).
 *
 * Без прерываний, API как у es1371: loop-кольцо, стоп снятием DAC2_EN.
 */
#include "types.h"
#include "io.h"
#include "pci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sound.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

/* ---------- регистры (I/O BAR0, 0x40 байт) ---------- */
#define E0_REG_CONTROL 0x00
#define E0_REG_STATUS  0x04
#define E0_REG_MEMPAGE 0x0c
#define E0_REG_CODEC   0x10
#define E0_REG_SCTRL   0x20
#define E0_REG_DAC1_SC 0x24
#define E0_REG_DAC2_SC 0x28
#define E0_REG_ADC_SC  0x2c
/* страница 0x0c: фреймы DAC1/DAC2 */
#define E0_REG_DAC1_ADR 0x30
#define E0_REG_DAC1_CNT 0x34
#define E0_REG_DAC2_ADR 0x38
#define E0_REG_DAC2_CNT 0x3c

/* CONTROL */
#define E0_CTRL_PCLKDIV 0x1fff0000u  /* sh 16: делитель DAC2/ADC */
#define E0_CTRL_DAC_SYNC 0x00000800u
#define E0_CTRL_CCB_INTRM 0x00000400u
#define E0_CTRL_DAC1_EN 0x00000040u
#define E0_CTRL_DAC2_EN 0x00000020u
#define E0_CTRL_ADC_EN  0x00000010u
#define E0_CTRL_CDC_EN  0x00000002u
/* SCTRL — те же биты, что и у ES1371 */
#define E0_SCTRL_P2ENDINC 0x00380000u
#define E0_SCTRL_P2STINC  0x00070000u
#define E0_SCTRL_P2LOOPSEL 0x00004000u
#define E0_SCTRL_P2PAUSE   0x00001000u
#define E0_SCTRL_P2INTEN   0x00000200u
#define E0_SCTRL_P2DACSEN  0x00000040u
#define E0_SCTRL_P2FMT     0x0000000cu
#define E0_SCTRL_P2SEB     0x00000008u
#define E0_SCTRL_P2SMB     0x00000004u

#define E0_PAGE_DAC 0x0c

static struct {
    u16 io;
    int ok;
} g_e0;

static const char *e0_name = "ES1370 (QEMU AudioPCI)";

static u32 e0_in(u32 reg) { return inl((u16)(g_e0.io + reg)); }
static void e0_out(u32 reg, u32 v) { outl((u16)(g_e0.io + reg), v); }

int snd_es1370_probe(void)
{
    g_e0.ok = 0;
    g_e0.io = 0;
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid == 0xFFFF) continue;
                if (!(vid == 0x1274 && (did == 0x5000 || did == 0x1370)))
                    continue;
                u32 bar0 = pci_read32(bus, dev, fn, 0x10);
                if (!(bar0 & 1)) continue;          /* нужен I/O BAR */
                u16 io = (u16)(bar0 & 0xFFFCu);
                if (!io) continue;
                u16 cmd = pci_read16(bus, dev, fn, 0x04);
                pci_write16(bus, dev, fn, 0x04, (u16)(cmd | 0x5)); /* IO+BME */
                g_e0.io = io;
                g_e0.ok = 1;
                {
                    char b[80];
                    snprintf(b, sizeof(b), "[es1370] %04x:%04x io=%x\n",
                             vid, did, io);
                    serial_puts(b);
                    klog_puts(b);
                }
                return 1;
            }
        }
    }
    return 0;
}

const char *snd_es1370_name(void) { return e0_name; }

/* Воспроизведение: samples = frames * 2 (stereo) int16, rate, ms */
int snd_es1370_play(const i16 *samples, u32 frames, u32 rate, u32 ms)
{
    if (!g_e0.ok) return -1;
    if (!samples || frames < 8) return -1;
    u32 bytes = frames * 4;
    if (bytes > 0x10000) { bytes = 0x10000; frames = bytes >> 2; }

    u32 phys = (u32)(unsigned long)samples;
    if (phys & 3u) return -1;
    if (rate < 4000) rate = 4000;
    if (rate > 48000) rate = 48000;

    /* 1. DAC2 выключен */
    u32 ctrl = e0_in(E0_REG_CONTROL);
    ctrl &= ~E0_CTRL_DAC2_EN;
    e0_out(E0_REG_CONTROL, ctrl);

    /* 2. Дескриптор: страница 0x0c, FRAMEADR + FRAMECNT (dword-1) */
    e0_out(E0_REG_MEMPAGE, E0_PAGE_DAC);
    e0_out(E0_REG_DAC2_ADR, phys);
    e0_out(E0_REG_DAC2_CNT, (bytes >> 2) - 1);

    /* 3. Формат: 16-bit stereo, loop-кольцо, END_INC=2, ST_INC=0 */
    u32 sctrl = e0_in(E0_REG_SCTRL);
    sctrl &= ~(E0_SCTRL_P2LOOPSEL | E0_SCTRL_P2PAUSE | E0_SCTRL_P2DACSEN |
               E0_SCTRL_P2INTEN | E0_SCTRL_P2FMT | E0_SCTRL_P2ENDINC |
               E0_SCTRL_P2STINC);
    sctrl |= E0_SCTRL_P2SEB | E0_SCTRL_P2SMB;   /* 16-bit stereo */
    sctrl |= (2u << 19);                        /* P2ENDINC = 2 */
    e0_out(E0_REG_SCTRL, sctrl);

    /* 4. Счётчик сэмплов: фреймов-1 */
    e0_out(E0_REG_DAC2_SC, frames - 1);

    /* 5. Частота DAC2: PCLKDIV = 1411200/rate - 2 (с округлением) */
    u32 div = (1411200u + rate / 2u) / rate;
    if (div < 2u) div = 2u;
    div -= 2u;
    if (div > 0x1fffu) div = 0x1fffu;
    ctrl &= ~E0_CTRL_PCLKDIV;
    ctrl |= (div << 16);

    /* 6. Старт: DAC2_EN (+ CDC_EN — serial-интерфейс кодека) */
    ctrl |= E0_CTRL_DAC2_EN | E0_CTRL_CDC_EN;
    e0_out(E0_REG_CONTROL, ctrl);

    /* ждём (PIT, 1 тик = 1 мс); кольцо крутится само */
    u32 t0 = timer_ticks();
    while ((timer_ticks() - t0) < ms) task_msleep(5);

    /* стоп */
    ctrl = e0_in(E0_REG_CONTROL);
    ctrl &= ~E0_CTRL_DAC2_EN;
    e0_out(E0_REG_CONTROL, ctrl);
    return 0;
}

/* ================= потоковое воспроизведение (сессия 60) =================
 * Та же модель, что у ES1371 (см. snd_es1371.c): приложение передаёт
 * куски поочерёдно, переключение кольца — пауза DAC2 → дескриптор →
 * пуск. Буфер вызывающего живёт до следующего вызова stream(). */

int snd_es1370_stream(const i16 *samples, u32 frames, u32 rate)
{
    if (!g_e0.ok || !samples || frames < 8) return -1;
    u32 bytes = frames * 4;
    if (bytes > 0x10000) bytes = 0x10000;
    frames = bytes >> 2;

    u32 phys = (u32)(unsigned long)samples;
    if (phys & 3u) return -1;
    if (rate < 4000) rate = 4000;
    if (rate > 48000) rate = 48000;

    int running = (e0_in(E0_REG_CONTROL) & E0_CTRL_DAC2_EN) != 0;

    if (running) {
        e0_out(E0_REG_SCTRL, e0_in(E0_REG_SCTRL) | E0_SCTRL_P2PAUSE);
    } else {
        e0_out(E0_REG_CONTROL, e0_in(E0_REG_CONTROL) & ~E0_CTRL_DAC2_EN);
    }

    e0_out(E0_REG_MEMPAGE, E0_PAGE_DAC);
    e0_out(E0_REG_DAC2_ADR, phys);
    e0_out(E0_REG_DAC2_CNT, (bytes >> 2) - 1);

    u32 sctrl = e0_in(E0_REG_SCTRL);
    sctrl &= ~(E0_SCTRL_P2LOOPSEL | E0_SCTRL_P2DACSEN | E0_SCTRL_P2INTEN |
               E0_SCTRL_P2FMT | E0_SCTRL_P2ENDINC | E0_SCTRL_P2STINC);
    sctrl |= E0_SCTRL_P2SEB | E0_SCTRL_P2SMB | (2u << 19);
    e0_out(E0_REG_SCTRL, sctrl);

    e0_out(E0_REG_DAC2_SC, frames - 1);

    u32 ctrl = e0_in(E0_REG_CONTROL);
    u32 div = (1411200u + rate / 2u) / rate;
    if (div < 2u) div = 2u;
    div -= 2u;
    if (div > 0x1fffu) div = 0x1fffu;
    ctrl &= ~E0_CTRL_PCLKDIV;
    ctrl |= (div << 16);

    if (running) {
        e0_out(E0_REG_CONTROL, ctrl);                       /* делитель */
        e0_out(E0_REG_SCTRL, e0_in(E0_REG_SCTRL) & ~E0_SCTRL_P2PAUSE);
    } else {
        ctrl |= E0_CTRL_DAC2_EN | E0_CTRL_CDC_EN;
        e0_out(E0_REG_CONTROL, ctrl);
    }
    return 0;
}

/* Пауза с сохранением позиции. */
void snd_es1370_stream_pause(int on)
{
    if (!g_e0.ok) return;
    u32 sctrl = e0_in(E0_REG_SCTRL);
    if (on) e0_out(E0_REG_SCTRL, sctrl | E0_SCTRL_P2PAUSE);
    else    e0_out(E0_REG_SCTRL, sctrl & ~E0_SCTRL_P2PAUSE);
}

/* Полный стоп. */
void snd_es1370_stream_stop(void)
{
    if (!g_e0.ok) return;
    e0_out(E0_REG_CONTROL, e0_in(E0_REG_CONTROL) & ~E0_CTRL_DAC2_EN);
}
