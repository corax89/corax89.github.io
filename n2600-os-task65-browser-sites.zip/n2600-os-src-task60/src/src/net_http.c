/* net_http.c — простой HTTP/1.0 клиент для N2600-OS (+ трассировка).
 *
 * Реализован только метод GET. Запрос:
 *   GET <path> HTTP/1.0\r\n
 *   Host: <hostname>\r\n
 *   User-Agent: N2600-OS/0.1\r\n
 *   Connection: close\r\n
 *   \r\n
 *
 * Транзакция завершается, когда:
 *   - сервер закрыл соединение (FIN) — классический HTTP/1.0 путь;
 *   - получено тело целиком по Content-Length (многие HTTP/1.1-серверы
 *     держат соединение открытым — раньше клиент ждал таймаут 10 с);
 *   - наступила «тишина»: 1.5 с без новых данных (сервер молчит,
 *     но соединение держит) — раньше это тоже висело до таймаута.
 *
 * net_http_get_traced() дополнительно заполняет http_trace_t: точные
 * байты запроса, сырой ответ и тайминги фаз (DNS/ARP/connect/recv) —
 * приложение HTTP Trace показывает, на какой стадии запрос отвалился.
 */
#include "net.h"
#include "net_tls.h"
#include "sync.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);
extern void net_poll(void);

/* Буфер для накопления HTTP-ответа */
static char *g_http_buf = NULL;
static u32   g_http_buf_len = 0;
static u32   g_http_buf_max = 0;
static int   g_http_sock = -1;
static int   g_http_done = 0;

/* Анализ ответа: где кончаются заголовки и каков Content-Length.
 * Заполняется по мере поступления данных (http_tcp_recv). */
static int   g_hdr_end = -1;        /* индекс '\n' последней строки заголовка + 1 */
static u32   g_content_length = 0;  /* 0 = неизвестен */
static int   g_have_content_length = 0;
/* Task 60 [HTTP-TRUNC]: 1 = ответ НЕ влез в буфер вызывающего
 * (break при g_http_buf_len >= max-1). Раньше n == max-1 был
 * неотличим от «сервер сам прислал столько» — браузер молча терял
 * хвост (п. 1.1 разбора Task 60). */
static int   g_http_truncated = 0;

/* FIX [HTTP-CHUNKED] (Task 65): декодер Transfer-Encoding: chunked.
 * Прежде клиент HTTP/1.0 получал chunked-ответ КАК ЕСТЬ: тело было
 * перемешано с hex-размерами чанков ("2000\r\n<данные>\r\n..."),
 * github.com (и многие CDN) отвечают chunked даже HTTP/1.0-клиенту —
 * браузер показывал мусор. Теперь тело декодируется НА ЛЕТУ:
 * состояние — внутри http_tcp_recv (см. ch_feed):
 *   CH_SIZE   читаем hex-строку размера (до '\n'; расширения после ';'
 *             игнорируем), 0 = конец (далее trailer-блок);
 *   CH_DATA   отдаём g_ch_rem байт тела в буфер вызывающего;
 *   CH_CRLF   съедаем '\r'/'\n' после чанка (терпимы лишние);
 *   CH_TRAIL  съедаем trailer-строки до ПУСТОЙ (конец ответа,
 *             g_http_done=1). Обрыв соединения тоже завершает.
 * g_chunked: 0 = не chunked, 1 = декодируем, -1 = протокол сломан
 * (глотаем остаток молча — лучше, чем мусор на экране).
 * Буфер вызывающего: [заголовки][декодированное тело] — декодер
 * пишется поверх сырых байтов (вывод <= входа, вперёд безопасно). */
#define CH_SIZE  0
#define CH_DATA  1
#define CH_CRLF  2
#define CH_TRAIL 3
static int  g_chunked = 0;
static int  g_ch_state = CH_SIZE;
static u32  g_ch_rem = 0;        /* осталось байт текущего чанка */
static char g_ch_line[24];       /* hex-строка размера */
static u32  g_ch_line_len = 0;
static int  g_ch_sol = 1;        /* начало строки trailer-блока */
static int  g_chunk_end = 0;     /* пустая строка trailer видена */

/* Текущая трассировка (NULL = обычный вызов без записи) */
static http_trace_t *g_trace = NULL;
static u32 g_http_t0 = 0;       /* тик старта транзакции (для t_first_ms) */

/* Текст последней ошибки (для браузера/терминала). FIX [N1d]: раньше все
 * сбои возвращали -1 без объяснений — «Ошибка запроса (код -1)»
 * не помогал диагностике. */
static char g_http_err[48] = "ok";

const char *net_http_errstr(void) { return g_http_err; }

/* Task 60 [HTTP-TRUNC]: Content-Length последнего ответа (0 = заголовка
 * не было/не успел прийти). Валидно сразу после net_http_get/post
 * (до старта следующей транзакции). */
u32 net_http_content_length(void)
{
    return g_have_content_length ? g_content_length : 0;
}

/* Один байт ДЕКОДИРОВАННОГО тела в буфер вызывающего. */
static void ch_put_out(int c)
{
    if (g_http_truncated) return;
    if (g_http_buf_len >= g_http_buf_max - 1) {
        g_http_truncated = 1;      /* [HTTP-TRUNC] */
        return;
    }
    g_http_buf[g_http_buf_len++] = (char)c;
}

/* Протокол chunked сломан: глотаем остаток (не портим экран). */
static void ch_broken(void)
{
    g_chunked = -1;
    g_http_done = 1;
}

/* Скормить декодеру n сырых байтов тела (после конца заголовков).
 * Читает из src, пишет в g_http_buf поверх (out <= in на каждом шаге).
 * Вызывается и для хвоста, уже лежащего в буфере (in-place), и для
 * новых сегментов. */
static void ch_feed(const unsigned char *src, u32 n)
{
    for (u32 i = 0; i < n; i++) {
        if (g_chunked != 1) return;      /* сломан/выключен — глотаем */
        int c = src[i];
        switch (g_ch_state) {
        case CH_SIZE:
            if (c == '\n') {
                g_ch_line[g_ch_line_len] = 0;
                u32 v = 0;
                int ok = (g_ch_line_len > 0);
                for (u32 k = 0; k < g_ch_line_len; k++) {
                    char h = g_ch_line[k];
                    if (h == ';' || h == ' ' || h == '\t' || h == '\r') break;
                    int dv;
                    if (h >= '0' && h <= '9')      dv = h - '0';
                    else if (h >= 'a' && h <= 'f') dv = h - 'a' + 10;
                    else if (h >= 'A' && h <= 'F') dv = h - 'A' + 10;
                    else { ok = 0; break; }
                    v = v * 16u + (u32)dv;
                    if (v > 0x00FFFFFFu) { ok = 0; break; }  /* абсурд */
                }
                g_ch_line_len = 0;
                if (!ok) { ch_broken(); return; }
                if (v == 0) {
                    g_ch_state = CH_TRAIL;
                    g_ch_sol = 1;
                } else {
                    g_ch_rem = v;
                    g_ch_state = CH_DATA;
                }
            } else if (g_ch_line_len < sizeof(g_ch_line) - 1) {
                g_ch_line[g_ch_line_len++] = (char)c;
            } else {
                ch_broken();           /* строка размера не по формату */
                return;
            }
            break;

        case CH_DATA: {
            u32 avail = n - i;
            u32 take = avail < g_ch_rem ? avail : g_ch_rem;
            for (u32 k = 0; k < take; k++) ch_put_out(src[i + k]);
            i += take;
            g_ch_rem -= take;
            /* 'i' указывает на байт ПОСЛЕ чанка; for-инкремент сдвинет ещё
             * на 1 — компенсируем: если следующий байт существует,
            * это '\r'/'\n' — его обработает CH_CRLF, поэтому откат. */
            if (take > 0) i--;
            if (g_ch_rem == 0) g_ch_state = CH_CRLF;
            break;
        }

        case CH_CRLF:
            /* после данных чанка ждём CRLF; терпимы '\r', пустые... нет:
             * строго '\r' или '\n' (лишний CR игнорируем, LF завершает) */
            if (c == '\n') g_ch_state = CH_SIZE;
            /* '\r' просто пропускаем */
            break;

        case CH_TRAIL:
            /* trailer-блок: строки "Name: value" до ПУСТОЙ. '\r' игнорируем,
             * '\n' завершает строку: пустая = конец ответа. */
            if (c == '\r') break;
            if (c == '\n') {
                if (g_ch_sol) {           /* строка была пустой */
                    g_chunk_end = 1;
                    g_http_done = 1;
                    return;
                }
                g_ch_sol = 1;             /* новая строка */
            } else {
                g_ch_sol = 0;             /* внутри строки-трейлера */
            }
            break;
        }
    }
}

/* Обнаружить Transfer-Encoding: chunked в разобранных заголовках
 * [0, g_hdr_end). Вызывается ОДИН раз — при первом нахождении конца
 * заголовков. */
static void http_detect_chunked(void)
{
    if (g_chunked || g_hdr_end < 0 || !g_http_buf) return;
    const char *hl[] = { "Transfer-Encoding:", "transfer-encoding:" };
    for (int k = 0; k < 2 && !g_chunked; k++) {
        u32 L = (u32)strlen(hl[k]);
        for (int i = 0; i + (int)L < g_hdr_end; i++) {
            if (memcmp(g_http_buf + i, hl[k], L) != 0) continue;
            /* значение до конца строки, без учёта регистра ищем "chunked" */
            const char *v = g_http_buf + i + L;
            const char *e = g_http_buf + g_hdr_end;
            const char *nl = v;
            while (nl < e && *nl != '\n') nl++;
            for (const char *p = v; p + 6 < nl; p++) {
                char a = p[0], b = p[1], c2 = p[2], d = p[3], e2 = p[4], f = p[5], g = p[6];
                if (a == 'c' || a == 'C') {
                    if ((b|0x20)=='h' && (c2|0x20)=='u' && (d|0x20)=='n' &&
                        (e2|0x20)=='k' && (f|0x20)=='e' && (g|0x20)=='d') {
                        g_chunked = 1;
                        break;
                    }
                }
            }
            break;
        }
    }
}

/* Task 60 [HTTP-TRUNC]: 1 = последний ответ обрезан по лимиту буфера
 * вызывающего — получено max-1 байт, хвост потерян. */
int net_http_truncated(void)
{
    return g_http_truncated;
}

static void http_err(const char *msg);   /* fwd: определена ниже */

/* Сессия 56: отказ с ИСТОЧНИКОМ RST — «connection refused (RST
 * 192.168.0.1 ttl=64)» прямо в статусе браузера. TTL различает
 * источник: ~64 — наша же сеть (роутер/фильтр/DNS-синкхол),
 * заметно меньше — хост в интернете за NAT. */
static void http_err_rst(const char *what, int sock)
{
    u32 rip; u16 rport; u8 rttl;
    char msg[64];
    if (net_tcp_rst_info(sock, &rip, &rport, &rttl)) {
        char ipb[20];
        net_ntoa(rip, ipb, sizeof(ipb));
        snprintf(msg, sizeof(msg), "%s (RST %s ttl=%u)",
                 what, ipb, (unsigned)rttl);
        http_err(msg);
    } else {
        http_err(what);
    }
}

static void http_err(const char *msg)
{
    strncpy(g_http_err, msg, sizeof(g_http_err) - 1);
    g_http_err[sizeof(g_http_err) - 1] = 0;
    serial_puts("[http] ");
    serial_puts(msg);
    serial_puts("\n");
    if (g_trace) {
        strncpy(g_trace->error, msg, sizeof(g_trace->error) - 1);
        g_trace->error[sizeof(g_trace->error) - 1] = 0;
    }
}

/* Сколько мс прошло от старта транзакции (сессия 33: 1 тик = 1 мс) */
static u32 ms_since(u32 start_tick)
{
    return timer_ticks() - start_tick;
}

/* Поиск конца заголовков "\r\n\r\n" и Content-Length в накопленном
 * буфере. Вызывается после каждого приёма. */
static void http_scan_headers(void)
{
    if (g_hdr_end >= 0 || !g_http_buf || g_http_buf_len == 0) return;

    /* ищем \r\n\r\n начиная с уже просмотренных позиций (буфер только
     * растёт, можно сканировать с нуля — ответы маленькие) */
    u32 n = g_http_buf_len;
    for (u32 i = 0; i + 3 < n; i++) {
        if (g_http_buf[i]     == '\r' && g_http_buf[i + 1] == '\n' &&
            g_http_buf[i + 2] == '\r' && g_http_buf[i + 3] == '\n') {
            g_hdr_end = (int)i + 4;
            break;
        }
    }
    if (g_hdr_end < 0) return;

    /* Content-Length: в заголовках (g_http_buf[0..hdr_end)) */
    const char *hl[] = { "Content-Length:", "content-length:" };
    for (int k = 0; k < 2 && !g_have_content_length; k++) {
        u32 L = (u32)strlen(hl[k]);
        for (int i = 0; i + (int)L <= g_hdr_end - 1; i++) {
            if (memcmp(g_http_buf + i, hl[k], L) == 0) {
                u32 v = 0; int ok = 0;
                const char *p = g_http_buf + i + L;
                while (p < g_http_buf + g_hdr_end && (*p == ' ' || *p == '\t')) p++;
                while (p < g_http_buf + g_hdr_end && *p >= '0' && *p <= '9') {
                    v = v * 10u + (u32)(*p - '0');
                    p++;
                    ok = 1;
                }
                if (ok) {
                    g_content_length = v;
                    g_have_content_length = 1;
                }
                break;
            }
        }
    }
}

/* TCP receive callback — копирует данные в буфер (+ копию трассировки) */
static void http_tcp_recv(int sock, u32 src_ip, u16 src_port,
                            const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    if (!data || len == 0) return;

    /* СЕССИЯ 68 (фикс порчи кучи): доставка может прийти ПОСЛЕ того,
     * как транзакция закончилась по таймауту (ответ теперь собирает
     * httpd в контексте kmain — см. net_httpd.c) и вызывающий уже
     * ОСВОБОДИЛ response-буфер. Проверяем, что данные принадлежат
     * ТЕКУЩЕЙ транзакции (живому сокету); чужие/мёртвые игнорируем. */
    if (sock != g_http_sock || g_http_sock < 0) return;
    (void)sock;

    /* первый байт ответа — время от старта транзакции (трассировка) */
    if (g_trace && g_http_buf_len == 0 && g_trace->t_first_ms == 0) {
        g_trace->t_first_ms = timer_ticks() - g_http_t0;   /* 1 тик = 1 мс */
        strncpy(g_trace->stage, "recv", sizeof(g_trace->stage) - 1);
    }

    if (!g_http_buf) return;

    /* FIX [HTTP-CHUNKED]: заголовки уже разобраны и ответ chunked —
     * новые байты идут СРАЗУ в декодер (сырые в буфер не пишутся).
     * Копия в трассировку — сырая (для диагностики чанков). */
    if (g_chunked == 1 && g_hdr_end >= 0) {
        if (g_trace && g_trace->resp_copy && g_trace->resp_max) {
            u32 rroom = g_trace->resp_max - g_trace->resp_len;
            if (rroom) {
                u32 rcopy = len < rroom ? len : rroom;
                memcpy(g_trace->resp_copy + g_trace->resp_len, data, rcopy);
                g_trace->resp_len += rcopy;
                g_trace->resp_copy[g_trace->resp_len] = 0;
            }
        }
        ch_feed((const unsigned char *)data, len);
        return;
    }

    u32 room = g_http_buf_max - g_http_buf_len;
    if (room == 0) return;
    u32 copy = len < room ? len : room;
    memcpy(g_http_buf + g_http_buf_len, data, copy);
    g_http_buf_len += copy;

    /* копия сырого ответа для трассировки */
    if (g_trace && g_trace->resp_copy && g_trace->resp_max) {
        u32 rroom = g_trace->resp_max - g_trace->resp_len;
        if (rroom) {
            u32 rcopy = len < rroom ? len : rroom;
            memcpy(g_trace->resp_copy + g_trace->resp_len, data, rcopy);
            g_trace->resp_len += rcopy;
            g_trace->resp_copy[g_trace->resp_len] = 0;
        }
    }

    http_scan_headers();

    /* FIX [HTTP-CHUNKED]: конец заголовков только что найден. Если
     * сервер отвечает chunked, хвост буфера [hdr_end..len) — СЫРОЕ
     * chunked-тело: декодируем НА МЕСТЕ (запись с позиции hdr_end,
     * вывод <= входа). Дальнейшие сегменты придут веткой выше. */
    if (g_hdr_end >= 0 && g_chunked == 0) {
        http_detect_chunked();
        if (g_chunked == 1) {
            u32 raw_body = g_http_buf_len - (u32)g_hdr_end;
            g_http_buf_len = (u32)g_hdr_end;   /* пишем с начала тела */
            g_have_content_length = 0;         /* CL с chunked не критерен */
            if (raw_body > 0)
                ch_feed((const unsigned char *)g_http_buf + g_hdr_end,
                        raw_body);
        }
    }

    /* Тело получено целиком по Content-Length — можно заканчивать,
     * не дожидаясь закрытия соединения (HTTP/1.1 keep-alive).
     * Для chunked длину тела знает только декодер (конец — пустая
     * trailer-строка). */
    if (!g_chunked && g_have_content_length && g_hdr_end >= 0) {
        u32 body = g_http_buf_len - (u32)g_hdr_end;
        if (body >= g_content_length) {
            g_http_done = 1;
            if (g_trace) strncpy(g_trace->stage, "done", sizeof(g_trace->stage) - 1);
        }
    }
}

static void tr_set_stage(http_trace_t *tr, const char *st)
{
    if (tr) strncpy(tr->stage, st, sizeof(tr->stage) - 1);
}

/* Адаптер: расшифрованные движком TLS данные -> тот же накопитель,
 * что и у обычного HTTP (http_tcp_recv). Сигнатуры различаются. */
static void http_tls_sink(const void *data, u32 len)
{
    http_tcp_recv(g_http_sock, 0, 0, data, len);
}

static int net_http_req_impl(const char *method, const char *host, u16 port,
                             const char *path, const char *body, u32 body_len,
                             const char *content_type,
                             char *response, u32 max_len, u32 max_ms,
                             http_trace_t *tr)
{
    if (!host || !path || !response || max_len == 0) return -1;
    /* Task 62 [POST-LEN]: body_len задан явно (multipart с нулями);
     * 0 = классическая strlen-семантика (urlencoded-формы). */
    if (body && body_len == 0) body_len = (u32)strlen(body);

    /* СЕССИЯ 68: завершение транзакции — отключить приёмник данных,
     * чтобы поздняя доставка (ретрансмиссия, досланный хвост ответа
     * после таймаута — теперь httpd отвечает из kmain асинхронно)
     * не писала в ОСВОБОЖДЁННЫЙ вызывающим response-буфер. Вызывается
     * перед каждым выходом net_http_get_impl. */
    #define HTTP_TXN_DETACH() do { \
        g_http_buf = NULL; g_http_buf_len = 0; g_http_buf_max = 0; \
        g_http_sock = -1; g_http_done = 0; g_hdr_end = -1; \
        g_content_length = 0; g_have_content_length = 0; \
        g_chunked = 0; g_ch_state = CH_SIZE; g_ch_rem = 0; \
        g_ch_line_len = 0; g_chunk_end = 0; g_ch_sol = 1; \
        net_tcp_set_callback(NULL); \
    } while (0)

    strcpy(g_http_err, "ok");
    g_trace = tr;
    if (tr) {
        tr->stage[0] = 0;
        tr->error[0] = 0;
        tr->sock = -1;
        tr->syn_kicks = 0;
        tr->req_len = 0;
        tr->resp_len = 0;
        tr->t_dns_ms = 0;
        tr->t_arp_ms = 0;
        tr->t_connect_ms = 0;
        tr->t_first_ms = 0;
        tr->t_total_ms = 0;
        tr->resolved_ip = 0;
        tr->result = -1;
        if (tr->resp_copy && tr->resp_max) tr->resp_copy[0] = 0;
    }

    u32 t0 = timer_ticks();
    g_http_t0 = t0;

    /* 1. Разрешить хост → IP */
    u32 ip = 0;
    /* Сначала пробуем как IP-строку */
    if (!net_aton(host, &ip)) {
        tr_set_stage(tr, "dns");
        /* Пробуем через DNS */
        if (!net_dns_resolve(host, &ip, max_ms / 2)) {
            http_err("cannot resolve host");
            if (tr) tr->t_total_ms = ms_since(t0);
            g_trace = NULL;
            return -1;
        }
        if (tr) {
            tr->t_dns_ms = ms_since(t0);
            tr->resolved_ip = ip;
        }
        /* FIX (сессия 57): DNS-синкхол/блокировщик (AdGuard, Pi-hole,
         * провайдерский фильтр) отвечает на ЛЮБОЕ имя адресом-заглушкой:
         * 127.0.0.1 / 0.0.0.0 / broadcast. Соединение с такой заглушкой
         * давало «connection refused» без видимой причины. Теперь это
         * честная диагностика. Литерал 127.0.0.1 (loopback) не трогаем —
         * пользователь мог ввести его сам.
         * FIX (сессия 63): "localhost" сюда приходит ПО ЗАМЫСЛУ с
         * адресом 127.0.0.1 (net_dns_resolve, без DNS-сервера) — это не
         * синкхол, а loopback: раньше даже с настроенной сетью
         * http://localhost/ получал «DNS: заглушка/блокировка». */
        if (!net_host_is_loopback(host) &&
            (ip == 0 || (ip >> 24) == 127 || ip == 0xFFFFFFFFu)) {
            char ipb[20], msg[80];
            net_ntoa(ip, ipb, sizeof(ipb));
            snprintf(msg, sizeof(msg),
                     "DNS: %s — заглушка/блокировка, не хост", ipb);
            http_err(msg);
            if (tr) tr->t_total_ms = ms_since(t0);
            g_trace = NULL;
            return -1;
        }
    } else if (tr) {
        tr->resolved_ip = ip;   /* литерал: DNS не нужен */
    }

    /* 1b. FIX [N1c]: дождаться ARP (первый пакет иначе молча теряется).
     * ping повторяет запросы и потому работает; TCP-connect — нет. */
    {
        tr_set_stage(tr, "arp");
        u32 t_arp0 = timer_ticks();
        if (!net_wait_arp(ip, max_ms / 2)) {
            http_err("no ARP reply (gateway?)");
            if (tr) {
                tr->t_arp_ms = ms_since(t_arp0);
                tr->t_total_ms = ms_since(t0);
            }
            g_trace = NULL;
            return -1;
        }
        if (tr) tr->t_arp_ms = ms_since(t_arp0);
    }

    /* 2. Подготовить буфер и callback */
    g_http_buf = response;
    g_http_buf_len = 0;
    g_http_buf_max = max_len;
    g_http_done = 0;
    g_http_sock = -1;
    g_hdr_end = -1;
    g_content_length = 0;
    g_have_content_length = 0;
    g_http_truncated = 0;      /* [HTTP-TRUNC] */
    g_chunked = 0;             /* [HTTP-CHUNKED] */
    g_ch_state = CH_SIZE;
    g_ch_rem = 0;
    g_ch_line_len = 0;
    g_chunk_end = 0;
    g_ch_sol = 1;
    net_tcp_set_callback(http_tcp_recv);

    /* 3. TCP connect. Локальный порт — ротация: прежний сокет может
     * ещё висеть в LAST_ACK и занять тот же порт. */
    static u16 lport = 40000;
    u16 use_port = lport++;
    if (lport > 40500) lport = 40000;
    int sock = net_tcp_connect(ip, port, use_port);
    if (sock < 0) {
        http_err("cannot open TCP socket");
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }
    g_http_sock = sock;
    if (tr) tr->sock = sock;
    /* FIX (сессия 57): в serial видна КАЖДАЯ транзакция — раньше по двум
     * подряд «[tcp] connect» невозможно было понять, кто их сделал
     * (страница + редирект, страница + картинка imgsvc и т.п.). */
    {
        char b[292];
        snprintf(b, sizeof(b), "[http] GET http%s://%s:%u%s\n",
                 (port == 443) ? "s" : "", host, (unsigned)port, path);
        serial_puts(b);
    }

    /* Ждём соединения (3-way handshake) — неблокирующее.
     * FIX [N1b]: каждые 500 мс повторяем SYN, пока SYN_SENT —
     * первый SYN мог потеряться. */
    u32 start = timer_ticks();
    u32 need = max_ms / 4;               /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    u32 last_kick = timer_ticks();
    int kicks = 0;                       /* сессия 57: для диагноза таймаута */
    tr_set_stage(tr, "connect");
    while ((timer_ticks() - start) < need) {
        if (net_tcp_state(sock) == TCP_ESTABLISHED) break;
        if (net_tcp_state(sock) == TCP_CLOSED) {
            /* сессия 56: показываем КТО отказал (источник RST + ttl) */
            http_err_rst("connection refused", sock);
            if (tr) {
                tr->t_connect_ms = ms_since(start);
                tr->t_total_ms = ms_since(t0);
            }
            g_trace = NULL;
            HTTP_TXN_DETACH();
            return -1;
        }
        if (timer_ticks() - last_kick >= 500) {  /* 500 мс (1 тик = 1 мс) */
            net_tcp_kick(sock);
            kicks++;
            if (tr) tr->syn_kicks++;
            last_kick = timer_ticks();
        }
        net_poll();
        task_yield();
    }
    if (net_tcp_state(sock) != TCP_ESTABLISHED) {
        /* FIX (сессия 57): таймаут с ДЕТАЛЯМИ — состояние сокета и число
         * SYN-повторов (0 = SYN вообще не ушёл/ARP-проблема, >=2 = SYN
         * уходил, ответа нет — сеть/фаервол). */
        {
            char b[96];
            snprintf(b, sizeof(b), "connect timeout (state=%s, syn=%d)",
                     tcp_state_name(net_tcp_state(sock)), kicks);
            http_err(b);
        }
        net_tcp_close(sock);
        if (tr) {
            tr->t_connect_ms = ms_since(start);
            tr->t_total_ms = ms_since(t0);
        }
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }
    if (tr) tr->t_connect_ms = ms_since(start);

    /* 3b. TLS-рукопожатие (HTTPS). Порт 443 => шифруем сессию.
     * Сюда попадаем уже с ESTABLISHED TCP; движок BearSSL поверх. */
    int use_tls = (port == 443);
    if (use_tls) {
        tr_set_stage(tr, "tls");
        tls_set_sink(http_tls_sink);
        net_tcp_set_callback(tls_tcp_recv);
        if (!tls_start(sock, host, max_ms / 2)) {
            http_err(tls_errstr());
            if (tr) tr->t_total_ms = ms_since(t0);
            net_tcp_close(sock);
            g_trace = NULL;
            HTTP_TXN_DETACH();
            return -1;
        }
    }

    /* 4. Отправить HTTP запрос (GET или POST; Task 47 — POST для
     * форм браузера: application/x-www-form-urlencoded). Тело POST
     * отправляется ОТДЕЛЬНЫМ сегментом после заголовков (req-буфер
     * на стеке ограничен). */
    char req[512];
    int rl = 0;
    rl += snprintf(req + rl, sizeof(req) - rl, "%s %s HTTP/1.0\r\n",
                   method, path);
    rl += snprintf(req + rl, sizeof(req) - rl, "Host: %s\r\n", host);
    rl += snprintf(req + rl, sizeof(req) - rl, "User-Agent: N2600-OS/0.1\r\n");
    if (body && body_len) {
        rl += snprintf(req + rl, sizeof(req) - rl,
                       "Content-Type: %s\r\n",
                       content_type && content_type[0] ? content_type
                                                       : "application/x-www-form-urlencoded");
        rl += snprintf(req + rl, sizeof(req) - rl, "Content-Length: %u\r\n",
                       (unsigned)body_len);
    }
    rl += snprintf(req + rl, sizeof(req) - rl, "Connection: close\r\n");
    rl += snprintf(req + rl, sizeof(req) - rl, "\r\n");
    if (rl < 0) rl = 0;
    if ((u32)rl > sizeof(req)) rl = (int)sizeof(req) - 1;

    /* копия точных байтов запроса для трассировки */
    if (tr && tr->req_copy && tr->req_max) {
        u32 c = (u32)rl < tr->req_max ? (u32)rl : tr->req_max - 1;
        memcpy(tr->req_copy, req, c);
        tr->req_copy[c] = 0;
        tr->req_len = (u32)rl;
    }

    int sent;
    if (use_tls) {
        sent = tls_send_all(req, (u32)rl) ? (int)rl : -1;
    } else {
        sent = net_tcp_send(sock, req, (u32)rl);
    }
    /* тело POST — порциями по MSS с ожиданием ACK (Task 62 [POST-LEN]):
     * буфер ретрансляции в стеке ОДИН (retrans_buf), слать следующий
     * сегмент можно только после подтверждения предыдущего; раньше тело
     * уходило ОДНИМ вызовом net_tcp_send — на деле уходило не больше MSS,
     * хвост молча терялся (multipart > 1460 байт не доезжал целиком). */
    if (sent >= 0 && body && body_len) {
        u32 off = 0;
        while (off < body_len) {
            if (use_tls) {
                if (!tls_send_all(body + off, body_len - off)) { sent = -1; break; }
                off = body_len;
                break;
            }
            int s2 = net_tcp_send(sock, body + off, body_len - off);
            if (s2 <= 0) { sent = -1; break; }
            off += (u32)s2;
            if (off >= body_len) break;
            /* ждём ACK предыдущего сегмента (не дольше 4 с) */
            u32 t_ack = timer_ticks();
            while (net_tcp_send_pending(sock)) {
                if (net_tcp_state(sock) != TCP_ESTABLISHED) { sent = -1; break; }
                if (timer_ticks() - t_ack > 4000) { sent = -1; break; }
                net_poll();
                task_yield();
            }
            if (sent < 0) break;
            if (net_tcp_state(sock) != TCP_ESTABLISHED) { sent = -1; break; }
        }
    }
    if (sent < 0) {
        http_err("send failed");
        net_tcp_close(sock);
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }
    if (tr) {
        tr->req_len = (u32)sent;
        tr_set_stage(tr, "sent");
    }

    /* 5. Ждём ответ: до закрытия соединения, до полного тела по
     * Content-Length или до «тишины» 1.5 с (сервер молчит).
     * В TLS-режиме данные проходят через насос движка (tls_pump),
     * который расшифровывает рекорды и отдаёт plaintext в http_tls_sink. */
    start = timer_ticks();
    need = max_ms;                       /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    u32 last_data_tick = timer_ticks();
    u32 last_len = g_http_buf_len;
    while ((timer_ticks() - start) < need) {
        if (net_tcp_state(sock) == TCP_CLOSED) {
            g_http_done = 1;
            tr_set_stage(tr, "done");
            break;
        }
        if (g_http_done) break;                 /* Content-Length выполнен */
        if (g_http_buf_len >= g_http_buf_max - 1) {
            g_http_truncated = 1;   /* [HTTP-TRUNC]: буфер заполнен */
            break;
        }
        /* «тишина»: данные приходили, но новых нет 1.5 с — забираем
         * что есть (FIX: HTTP/1.1 keep-alive серверы не закрывают сокет,
         * раньше клиент висел до полного таймаута) */
        if (g_http_buf_len != last_len) {
            last_len = g_http_buf_len;
            last_data_tick = timer_ticks();
        } else if (g_http_buf_len > 0 &&
                   (timer_ticks() - last_data_tick) >= 1500) {   /* тишина 1.5 с */
            tr_set_stage(tr, "done");
            break;
        }
        if (use_tls) {
            tls_pump();       /* расшифровка/отправка рекордов движка */
            if (g_http_buf_len == 0 && strcmp(tls_errstr(), "ok") != 0) {
                /* движок доложил ошибку (MAC/reset/переполнение ring) */
                http_err(tls_errstr());
                tls_shutdown();
                net_tcp_close(sock);
                if (tr) tr->t_total_ms = ms_since(t0);
                g_trace = NULL;
                return -1;
            }
        }
        net_poll();
        task_yield();
    }

    /* FIX [TCP-R2]: соединение сброшено (RST сервера/шлюза) и данных
     * нет — это живой отказ, а не «тишина в сети». Раньше RST в
     * TCP_ESTABLISHED игнорировался, и клиент выжидал ВСЕ 10 секунд,
     * после чего говорил «response timeout» — что вводило в заблуждение
     * («сервер молчит», хотя на самом деле он ответил отказом). */
    if (g_http_buf_len == 0 && net_tcp_was_reset(sock)) {
        /* сессия 56: источник RST в сообщении */
        http_err_rst("connection reset", sock);
        if (use_tls) tls_shutdown();
        net_tcp_close(sock);
        if (tr) {
            tr->t_total_ms = ms_since(t0);
            strncpy(tr->error, "connection reset", sizeof(tr->error) - 1);
        }
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }

    if (!g_http_done && g_http_buf_len == 0) {
        http_err("response timeout");
        if (use_tls) tls_shutdown();
        net_tcp_close(sock);
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }

    /* Сессия 72 [S-69]: «НЕМОЙ» rc=0. Соединение закрылось БЕЗ данных
     * (done ставится по CLOSED/FIN, тело пусто) — раньше транзакция
     * молча возвращала 0: браузер показывал «Ошибка: ok», причина
     * терялась. Классические подписи: self-pair/сбитая пара loopback
     * (сервер закрыл свою сторону, не ответив) либо обрыв сервера.
     * Теперь честный отказ с диагностикой. */
    if (g_http_buf_len == 0) {
        char b[48];
        snprintf(b, sizeof(b), "пустой ответ (closed, state=%s)",
                 tcp_state_name(net_tcp_state(sock)));
        http_err(b);
        if (use_tls) tls_shutdown();
        net_tcp_close(sock);
        if (tr) tr->t_total_ms = ms_since(t0);
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return -1;
    }

    /* FIX [TRUNC-HONEST] (Task 65): обрез ПО ТЕЛУ, а не только по буферу.
     * Раньше truncated ставился ТОЛЬКО при заполнении буфера. Если ответ
     * обрывался по «тишине»/сбросу ПОСЛЕ заголовков (TLS-затык — см.
     * [TLS-RING]), вызывающий получал заголовки + кусок тела и считал
     * ответ ЦЕЛЫМ: браузер честно конвертировал обрывок (или показывал
     * «строк: 1» на пустом теле) без всякого намёка на потерю хвоста.
     * Теперь неполное тело (по Content-Length) либо незавершённый
     * chunked (нет пустой trailer-строки) помечаются truncated=1 —
     * браузер покажет «получено X из Y байт / ОБРЕЗАНО». */
    if (!g_http_truncated && g_hdr_end >= 0) {
        u32 got = g_http_buf_len - (u32)g_hdr_end;
        if (g_chunked == 1) {
            if (!g_chunk_end) g_http_truncated = 1;
        } else if (g_have_content_length && got < g_content_length) {
            g_http_truncated = 1;
        }
    }

    /* NUL-terminate */
    if (g_http_buf_len < g_http_buf_max) {
        response[g_http_buf_len] = 0;
    } else {
        response[g_http_buf_max - 1] = 0;
        g_http_buf_len = g_http_buf_max - 1;
    }

    if (tr) {
        if (g_http_buf_len > 0 && tr->t_first_ms == 0)
            tr->t_first_ms = ms_since(t0);       /* грубая оценка */
        tr->t_total_ms = ms_since(t0);
        tr->resp_len = g_http_buf_len;
        tr->result = (int)g_http_buf_len;
        tr_set_stage(tr, "done");
    }

    /* Закрыть сокет если ещё открыт. Сессия 58: вызываем ВСЕГДА —
     * net_tcp_close безопасен и для уже CLOSED слота (loopback-сервер
     * закрывает свою сторону сразу после ответа: клиентский слот
     * оставался in_use=1 до ближайшего net_poll, при серии loopback-
     * запросов без промежуточных опросов это исчерпывало пул из 8
     * сокетов). */
    if (use_tls) {
        tls_shutdown();      /* close_notify (best-effort) */
    }
    net_tcp_close(sock);
    {
        int rc = (int)g_http_buf_len;
        g_trace = NULL;
        HTTP_TXN_DETACH();
        return rc;
    }
}

/* Одна HTTP-транзакция на систему: всё состояние клиента (буфер
 * накопления, сокет, колбэк) — глобальное в этом модуле. Раньше все
 * вызовы шли из kmain (сингл-поток), теперь — из потоков приложений
 * (браузер, терминал). Параллельные вызовы выстраиваются в очередь
 * (ожидают спя, hlt). */
static volatile int http_busy_lock = 0;

int net_http_get(const char *host, u16 port, const char *path,
                  char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("GET", host, port, path, NULL, 0, NULL,
                           response, max_len, max_ms, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}

int net_http_get_traced(const char *host, u16 port, const char *path,
                          char *response, u32 max_len, u32 max_ms,
                          http_trace_t *tr)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("GET", host, port, path, NULL, 0, NULL,
                           response, max_len, max_ms, tr);
    if (tr) tr->result = rc;
    s_unlock(&http_busy_lock);
    return rc;
}

/* Task 47: POST (формы браузера). body — уже закодированное тело
 * (application/x-www-form-urlencoded собирает brf_serialize, brform.h).
 * content_type может быть NULL (подставится form-urlencoded).
 * Возвращает число байт ответа (с заголовками) или -1 (см. errstr). */
int net_http_post(const char *host, u16 port, const char *path,
                   const char *body, const char *content_type,
                   char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("POST", host, port, path, body, 0, content_type,
                           response, max_len, max_ms, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}

/* Task 62 [POST-LEN]: POST с телом ЯВНОЙ длины (multipart/form-data
 * с нулями — загрузка файлов на httpd). body_len байт отправляется
 * порциями по MSS с ожиданием ACK. */
int net_http_post_len(const char *host, u16 port, const char *path,
                      const char *body, u32 body_len, const char *content_type,
                      char *response, u32 max_len, u32 max_ms)
{
    int rc;
    s_lock(&http_busy_lock);
    rc = net_http_req_impl("POST", host, port, path, body, body_len, content_type,
                           response, max_len, max_ms, NULL);
    s_unlock(&http_busy_lock);
    return rc;
}
