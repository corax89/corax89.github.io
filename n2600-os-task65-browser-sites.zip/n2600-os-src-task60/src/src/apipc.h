/* apipc.h — ШАГ 4 (SMP-rework): инфраструктура IPI-syscall AP -> BSP.
 *
 * РОЛЬ (архитектура «BSP = kernel/UI/IRQ, AP = user-compute»):
 * AP-ядра выполняют только вычисления; операции, требующие BSP,
 * оформляются запросом в per-core mailbox и IPI (вектор 0x62 —
 * 0x60 из примера разбора занят LAPIC-таймером AP, smp.c).
 *
 * СТАТУС: ИНФРАСТРУКТУРА. Перевод горячих путей (malloc/free на AP,
 * screen_fill и пр.) на этот канал — следующий этап; пока куча и так
 * SMP-безопасна (heap_lock), и прямой вызов с AP корректен.
 *
 * Доставка двухрежимная:
 *   1) IPI 0x62 на BSP — если apipc_bsp_ipi_enable() пере-включил
 *      LAPIC BSP (virtual wire: путь PIC->LINT0->INTR не меняется);
 *      латентность ~10-20 мкс;
 *   2) опрос ap_syscall_poll() из главного цикла kmain — всегда;
 *      страховка от потерянного IPI (латентность ~кадра).
 *
 * ap_syscall_do() на AP ждёт результата спином (pause). Если BSP
 * погиб, вызывающий зависнет — как любой syscall в dead-ядре; для
 * инфраструктуры принято (перевод путей — со сторожевыми таймаутами).
 */
#ifndef APIPC_H
#define APIPC_H

#include "types.h"

/* Демо-набор операций (инфраструктура): полный словарь — на следующем
 * этапе, когда AP-кода начнёт переводиться на mailbox. */
#define APIPC_NOP     0   /* result = arg1+arg2+arg3 (проверка пути)     */
#define APIPC_MALLOC  1   /* BSP выделяет; result = указатель (или 0)    */
#define APIPC_FREE    2   /* BSP освобождает arg1                        */
#define APIPC_UPTIME  3   /* result = timer_ticks()                      */

typedef struct {
    volatile int pending;      /* 1 = ждёт обработки BSP                 */
    volatile int op;           /* APIPC_*                                */
    volatile u32 arg1, arg2, arg3;
    volatile u32 result;
} ap_syscall_t;

/* «Syscall» от лица исполняющейся задачи. На AP: кладёт запрос в
 * per-core mailbox, шлёт IPI BSP и ждёт result. На BSP: исполняется
 * напрямую (пересылать самому себе не нужно). */
u32 ap_syscall_do(int op, u32 a, u32 b, u32 c);

/* BSP: обслужить все ожидающие mailbox. Вызывается из kmain-цикла и
 * из IPI-обработчика (вектор 0x62); повторный вход пропускается. */
void ap_syscall_poll(void);

/* 1 = включить приём IPI на BSP (пере-включение LAPIC, virtual wire).
 * При 0 доставка — только опросом из kmain.
 *
 * ДЕФОЛТ 0 (VMware-сессия, полевые логи пользователя): пере-включение
 * LAPIC BSP в virtual wire в VMware изредка доставляло событие LINT0
 * ФИКСИРОВАННЫМ прерыванием с вектором из ПОЛЯ ВЕКТОРА LVT — а при
 * LINT0=0x700 поле вектора равно 0x00, и CPU входил в gate #0 как
 * «деление на ноль» (25+ фантомных #0 на инструкциях без деления:
 * movsb, cli-после-hlt, shr-после-rdmsr). Каскад: kmain терял кадры,
 * задача usbhot была снята, task_lock утекал через KMAIN-RECOVER.
 * В QEMU того же билда — ноль случаев (эмуляция LAPIC отличается).
 * При IPI=0 LAPIC BSP остаётся ВЫКЛЮЧЕННЫМ (путь прерываний как до
 * SMP — стабильный), mailbox доставляется поллингом из kmain-цикла.
 * Фантомы дополнительно гасятся проверкой опкода в exc_panic
 * (idt.c, [PHANTOM-DE]) — даже с IPI=1 система возобновит кадр. */
#define APIPC_BSP_IPI_ENABLE 0
void apipc_bsp_ipi_enable(void);

#endif /* APIPC_H */
