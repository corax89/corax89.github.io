/* mqjs_page.h — персистентная JS-сессия СТРАНИЦЫ БРАУЗЕРА (reader).
 *
 * Зачем: браузер рендерит Markdown и не умеет ни input'ов, ни скриптов.
 * Эта надстройка над mquickjs_api.c даёт страницам собственный движок
 * с УЗКИМ API (объект reader.*) вместо общего API ОС (см. mqjs_os.h):
 *
 *   reader.get(id)        -> значение input'а (number|bool|string)
 *   reader.set(id, val)   -> поменять значение виджета (без события)
 *   reader.out(id, text)  -> записать текст в виджет "output"
 *   reader.print(text...) -> в консоль страницы (Ctrl+J в браузере)
 *   reader.status(text)   -> строка статуса браузера
 *   reader.go(url)        -> переход (ОТЛОЖЕННЫЙ: после возврата из
 *                            скрипта — внутри скрипта окно не трогаем)
 *   reader.url()          -> адрес текущей страницы (document.location.href)
 *
 * Сессия 66: поверх reader.* движок ставит БРАУЗЕРНЫЙ ШИМ (тот же
 * контекст, JS-бутстрап mqjs_reader_install_dom в mquickjs_api.c):
 *
 *   window/self/top === globalThis; location (и window.location=, и
 *   document.location='...' — навигация через reader.go);
 *   document.location.href/assign/replace; document.URL;
 *   document.getElementById(id) — заглушка элемента: value читается/
 *   пишется через reader.get/set, onclick запоминается и вызывается
 *   при клике по виджету-кнопке с тем же id (мост __dispatchClick);
 *   document.write/writeln -> консоль; alert/confirm/prompt;
 *   navigator.userAgent. Настоящего DOM нет: скрипты с fetch/событиями/
 *   таймерами DOM получат осмысленные пустые заглушки вместо ошибок.
 *
 * Песочница (безопасность, слои — всё уже есть в проекте):
 *   1. API-ограничение: опасные глобальные функции ОС (ramfs_*, win_*,
 *      img_*, fb-рисование, malloc/free...) УДАЛЯЮТСЯ из глобального
 *      объекта (mqjs_reader_restrict) — страница их не видит. Полный
 *      API остаётся только у "unsafe"-страниц из RAM disk.
 *   2. Канарейки пула движка + raw-free при порче (mquickjs_api.c).
 *   3. Перехват CPU-исключений (#UD/#GP) — longjmp в задачу окна.
 *   4. C-stack guard (JS_SetStackGuard).
 *   5. Session reaper: память убитой (ватчдогом) задачи окна
 *      освобождается из главного цикла.
 *   6. Скрипты исполняются СИНХРОННО в потоке СВОЕГО окна —
 *      никаких postMessage/worker: нет ни IPC, ни гонок.
 *
 * Контекст живёт, пока открыта страница (состояние скриптов
 * сохраняется между событиями: клик/ввод/load).
 */
#ifndef MQJS_PAGE_H
#define MQJS_PAGE_H

#include "mqjs_os.h"
#include "mquickjs.h"

/* Мост движок -> браузер: реализуется в apps_browser.c (обёртки над
 * brjs_*), передаётся в mqjs_page_start(). Все колбэки вызываются В
 * ПОТОКЕ ОКНА (из reader_* внутри eval) — гонок нет. */
typedef struct {
    /* значение input'а: buf заполняется, *type: 0=string 1=number 2=bool.
     * 1 = виджет найден, 0 = нет такого id. */
    int  (*get_input)(void *ui, const char *id, char *buf, int buf_max,
                      int *type);
    /* поменять значение виджета. 1 = ok. */
    int  (*set_input)(void *ui, const char *id, const char *val);
    /* записать текст в виджет output (текст может содержать '\n'). */
    int  (*set_output)(void *ui, const char *id, const char *text, int len);
    /* строка статуса браузера */
    void (*status)(void *ui, const char *text);
    /* адрес текущей страницы (для reader.url()/document.location.href) */
    void (*get_url)(void *ui, char *buf, int buf_max);
    /* отложенный переход (внутри скрипта окно НЕ закрывается) */
    void (*navigate)(void *ui, const char *url);
} mqjs_reader_vt_t;

/* Создать сессию страницы для ТЕКУЩЕЙ задачи (поток окна браузера).
 *   out/out_max — буфер консоли страницы (владелец — браузер; сюда
 *                 пишутся print/console.log и ошибки скриптов);
 *   unsafe      — 1 = НЕ удалять полный API ОС (только локальные
 *                 страницы RAM disk; сетевым страницам не даётся);
 *   vt/ui       — мост к браузеру (см. выше).
 * Возвращает контекст или NULL (нет памяти/нет свободных сессий). */
JSContext *mqjs_page_start(char *out, u32 out_max, int unsafe,
                           const mqjs_reader_vt_t *vt, void *ui);

/* Исполнить код страницы (код из payload'а). Ошибки/исключения пишутся
 * в консоль страницы. Возвращает 0 = ok, -1 = JS-исключение,
 * -2 = фатал движка (контекст МЁРТВ: mqjs_page_stop НЕ вызывать,
 * сессия уже разобрана; память буферов остаётся за браузером). */
int  mqjs_page_eval(JSContext *ctx, const char *src, size_t len,
                    const char *name);

/* Разобрать JSON-payload (payload из <!--@r:base64-->). Возвращает
 * объект/значение или JS_EXCEPTION. */
JSValue mqjs_page_json(JSContext *ctx, const char *json, size_t len);

/* Закрыть сессию (свободно вызывать только если mqjs_page_eval не
 * возвращал -2). Браузер после этого освобождает СВОИ буферы. */
void mqjs_page_stop(JSContext *ctx);

#endif /* MQJS_PAGE_H */
