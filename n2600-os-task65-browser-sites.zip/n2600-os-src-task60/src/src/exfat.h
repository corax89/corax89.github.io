/* exfat.h — чтение и ЗАПИСЬ exFAT (сессия 75).
 *
 * Запрос пользователя: «добавь чтение и запись exFat». Реализация —
 * отдельный модуль с тем же блоком примитивов, что у FAT32 (список,
 * чтение, поиск, создание, mkdir, удаление, запись файла целиком);
 * подключается как «личность» (personality) fat32.c: все вызовы
 * fat32_* на exFAT-томе прозрачно уходят сюда, поэтому файловый
 * менеджер, диалоги и Настройки НЕ менялись.
 *
 * Поддержано:
 *   - VBR (сигнатура "EXFAT   "), bps 512/1024/2048/4096 (через
 *     несколько физических 512-секторов), кластеры до 1 МиБ;
 *   - FAT-цепочки (полные 32-битные записи, EOC = 0xFFFFFFFF) и
 *     NoFatChain-объекты (непрерывные) — чтение обоих форматов;
 *   - наборы записей каталога: 0x85 File + 0xC0 Stream + 0xC1 Name,
 *     контрольная сумма набора, хэш имени (UpCase-таблица с тома,
 *     запасной встроенный апкейс — ASCII/латиница/кириллица/греческий);
 *   - битовая карта занятости (0x81) с записью изменённых секторов,
 *     запасной путь — скан FAT;
 *   - метка тома (0x83), метки времени (RTC, формат FAT);
 *   - запись: создание/перезапись файлов, mkdir, удаление (снятие
 *     бита InUse у всех записей набора + освобождение цепочки);
 *     новые цепочки всегда FAT-управляемые (совместимость).
 *
 * Не поддерживается (осознанно):TexFAT, права/тонкие метаданные,
 * форматирование тома, кластеры > 1 МиБ.
 */
#ifndef EXFAT_H
#define EXFAT_H

#include "types.h"
#include "fat32.h"      /* fat32_dirent_t */

/* Проверить загрузочный сектор: 1 = это exFAT (сигнатура + 55AA). */
int  exfat_probe(const u8 *bs512);

/* Смонтировать том: разбирает VBR, читает метку/UpCase/битовую карту.
 * rd/wr — чтение/запись ФИЗИЧЕСКОГО 512-байтного сектора тома
 * (база раздела применяется вызывающей стороной, как у fat32). */
int  exfat_mount(int (*rd)(u32 lba, void *buf),
                 int (*wr)(u32 lba, const void *buf));
void exfat_detach(void);            /* снять монтирование, освободить буферы */

int  exfat_ready(void);
u32  exfat_root_cluster(void);
const char *exfat_label(void);
int  exfat_writable(void);

/* Перечислить каталог (без служебных записей), до max записей. */
int  exfat_list(u32 dir_cluster, fat32_dirent_t *out, int max);

/* Прочитать файл (не более max байт) -> число прочитанных байт. */
u32  exfat_read_file(u32 first_cluster, u32 size, void *buf, u32 max);

/* [FM-PROG]: чтение с колбэком прогресса (после каждого кластера). */
typedef int (*exfat_progress_fn)(void *ctx, u32 done, u32 total);
u32  exfat_read_file_prog(u32 first_cluster, u32 size, void *buf, u32 max,
                          exfat_progress_fn cb, void *cb_ctx);

/* Найти запись по имени (без учёта регистра). 1 = найдено. */
int  exfat_find_entry(u32 dir_cluster, const char *name, fat32_dirent_t *out);

/* Создать каталог / пустой файл. 1 = ок. */
int  exfat_mkdir(u32 dir_cluster, const char *name);
int  exfat_create_file(u32 dir_cluster, const char *name);

/* Записать файл целиком (создать или ПЕРЕЗАПИСАТЬ). len при успехе, 0 —
 * ошибка. Лимит 4 МиБ за вызов (буфер вызывающей стороны). */
u32  exfat_write_file(u32 dir_cluster, const char *name,
                      const void *buf, u32 len);

/* Удалить файл или ПУСТОЙ каталог. 1 = ок. */
int  exfat_delete(u32 dir_cluster, const char *name);

#endif /* EXFAT_H */
