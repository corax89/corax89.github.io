/* apps_taskmgr.c — диспетчер задач N2600-OS.
 *
 * Показывает список всех активных задач (task[0] = главная), их имена,
 * uptime в тиках, ЗАНЯТУЮ ПАМЯТЬ (КБ, учёт по владельцу блока кучи —
 * см. mem.c), ЯДРО-ИСПОЛНИТЕЛЬ (колонка «Ядро», VMware-сессия — запрос
 * пользователя: живое ядро с меткой «*» для работающих сейчас задач;
 * миграции AP<->BSP видны в реальном времени) и статус (RUN/idle/zombie).
 *
 * Графики (правая колонка, сверху вниз):
 *   CPU — история загрузки процессора (idle-процент, сэмпл раз в 0.5 с);
 *   MEM — использование кучи в процентах;
 *   NET — передача данных по сети: байт за интервал (tx+rx), график
 *         с АВТОМАСШТАБОМ по максимуму окна, справа — текущая скорость
 *         в человекочитаемом виде (Б/с, КБ/с, МБ/с). Счётчики байт —
 *         net_tx_bytes()/net_rx_bytes() (net.c).
 *
 * Управление:
 *   МЫШЬ (запрос пользователя): ЛКМ по строке — выделить; повторный
 *   клик ЛКМ по уже выделенной строке или ПКМ по строке (пункт
 *   «Снять задачу» в контекстном меню) — завершить процесс;
 *   Стрелки Up/Down, PgUp/PgDn — навигация по списку;
 *   Del (0x53) — убить выбранную задачу (через task_kill());
 *   Esc — закрыть окно.
 *
 * Форматирование таблицы: колонка «Имя» выравнивается по ЧИСЛУ
 * СИМВОЛОВ UTF-8 (utf8_take_bytes/utf8_count_chars), а не по байтам —
 * snprintf %-13s дополнял по БАЙТАМ, русские имена (2 байта/символ)
 * сдвигали колонки Uptime/Mem/Ядро/Статус и «ломали» таблицу. Шрифт ОС
 * моноширинный (8 px на СИМВОЛ), поэтому колонки совпадают только при
 * выравнивании по символам.
 *
 * Окно обновляется 2 раза в секунду через on_tick. Текущая задача
 * (task_current()) подсвечивается фоном.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mem.h"
#include "mouse.h"
#include "net.h"
#include "string.h"
#include "task.h"
#include "timer.h"
#include "smp.h"
#include "utf8.h"

#define TM_ROWS 20
#define TM_COLS 76
#define TM_HDR_H 22
#define TM_GRAPH_H 50     /* высота каждого графика */
#define TM_GRAPH_W 200   /* ширина графика */
#define TM_GRAPH_SAMPLES 64
#define TM_NAME_COLS 13  /* ширина колонки «Имя» в СИМВОЛАХ */
#define DEL_KEY 0x53      /* скан-код Delete */

/* Геометрия строки списка (общая для отрисовки и hit-теста мыши).
 * СЕССИЯ 75: блок «загрузка ядер» перенесён ПОД ГРАФИКИ (запрос
 * пользователя — там много свободного места); список начинается
 * сразу под шапкой. СЕССИЯ 82: блок — панель-подложка, ПО ОДНОЙ
 * строке на ядро (см. tm_draw_cores). */
#define TM_LIST_Y0  (TM_HDR_H + 18)          /* верх области списка */
#define TM_ROW_H    16                        /* высота строки */

typedef struct {
    int scroll;
    int sel;            /* выбранный индекс в списке активных задач */
    int  slots_used;    /* для хранение массива slot-индексов */
    int  slot_idx[256]; /* отображение список-позиция -> task slot */
    char status[128];   /* имя задачи в сообщении до 15 байт + текст */
    /* График загрузки CPU */
    u32  cpu_history[TM_GRAPH_SAMPLES];
    int  cpu_history_pos;
    u32  last_idle_uptime;
    u32  last_total_uptime;
    /* График использования памяти */
    u32  mem_history[TM_GRAPH_SAMPLES];
    /* График сети: байт за интервал (0.5 с), tx+rx; масштаб — при
     * отрисовке (авто по максимуму окна) */
    u32  net_history[TM_GRAPH_SAMPLES];
    u32  last_tx_bytes;
    u32  last_rx_bytes;
} taskmgr_t;

static const char *tm_status_str(int idx, int cur)
{
    if (!task_used(idx))       return "free";
    if (task_finished(idx))    return "zombie";
    if (task_is_system(idx))   return "SYS";   /* ramfs и прочие службы */
    if (idx == cur)            return "RUN";
    if (task_on_cpu(idx))      return "RUN";   /* [CORE-COL]: работает на AP */
    return "idle";
}

/* Перестроить отображение «позиция в списке -> slot» */
static void tm_rebuild(taskmgr_t *m)
{
    m->slots_used = 0;
    for (int i = 0; i < MAX_TASKS; i++) {
        if (task_used(i) && !task_finished(i)) {
            m->slot_idx[m->slots_used] = i;
            m->slots_used++;
            if (m->slots_used >= 256) break;
        }
    }
    if (m->sel >= m->slots_used) m->sel = m->slots_used - 1;
    if (m->sel < 0) m->sel = 0;
    if (m->scroll > m->sel) m->scroll = m->sel;
}

/* Колонка «Имя»: обрезать до TM_NAME_COLS СИМВОЛОВ и дополнить
 * пробелами до TM_NAME_COLS символов. Выравнивание по символам UTF-8,
 * НЕ по байтам (см. шапку файла — почему %-13s ломал таблицу). */
static void tm_fmt_name(char *out, int outsz, const char *name)
{
    /* байты первых TM_NAME_COLS символов (символы не рвутся) */
    int take = utf8_take_bytes(name, -1, TM_NAME_COLS);
    if (take > outsz - 1) {
        /* буфер уже, чем 13 кириллических символов: откат к ГРАНИЦЕ
         * символа — нельзя оставлять половину UTF-8-последовательности
         * (иначе utf8_count_chars проходит «сквозь» NUL и портит память) */
        take = utf8_align_back(name, outsz - 1);
        if (take <= 0) take = 1;
    }
    if (take < 0) take = 0;
    memcpy(out, name, (unsigned)take);
    out[take] = '\0';
    int chars = utf8_count_chars(out, -1);
    while (chars < TM_NAME_COLS && take < outsz - 1) {
        out[take++] = ' ';
        chars++;
    }
    out[take] = '\0';
}

static void tm_sample(taskmgr_t *m)
{
    /* Сэмплирование загрузки CPU.
     * СЕССИЯ 82 [TM-DELTA]: задача умерла -> её uptime ВЫЧИТАется из
     * total: беззнаковая дельта (total - last) заворачивалась в ~4e9,
     * d_idle*100 переполнялся — после КАЖДОГО закрытия приложения
     * график CPU показывал бессмысленный скачок. Теперь дельта
     * считается только при монотонном росте обоих счётчиков. */
    u32 total = 0;
    u32 idle = 0;
    for (int i = 0; i < MAX_TASKS; i++) {
        if (task_used(i) && !task_finished(i)) {
            u32 up = task_uptime(i);
            total += up;
            if (i == 0) idle = up;
        }
    }
    u32 d_total = (total >= m->last_total_uptime) ?
                  total - m->last_total_uptime : 0;
    u32 d_idle  = (idle >= m->last_idle_uptime) ?
                  idle - m->last_idle_uptime : 0;
    m->last_total_uptime = total;
    m->last_idle_uptime = idle;
    if (d_idle > d_total) d_idle = d_total;
    u32 cpu_pct = 0;
    if (d_total > 0) cpu_pct = 100 - (d_idle * 100 / d_total);
    m->cpu_history[m->cpu_history_pos] = cpu_pct;

    /* Сэмплирование памяти: mem_used / mem_heap_size * 100. Пишем на
     * ТОТ ЖЕ слот, что и CPU: раньше mem_history заполнялся на слот
     * pos+1 (после продвижения позиции) — график MEM был сдвинут на
     * один сэмпл относительно CPU. */
    extern u32 mem_used(void);
    extern u32 mem_heap_size(void);
    u32 heap = mem_heap_size();
    u32 used = mem_used();
    u32 mem_pct = (heap > 0) ? (used * 100 / heap) : 0;
    m->mem_history[m->cpu_history_pos] = mem_pct;

    /* Сэмплирование сети: дельта tx+rx байт за интервал (0.5 с).
     * Беззнаковое вычитание корректно и при завороте u32-счётчиков. */
    u32 tx = net_tx_bytes();
    u32 rx = net_rx_bytes();
    m->net_history[m->cpu_history_pos] =
        (tx - m->last_tx_bytes) + (rx - m->last_rx_bytes);
    m->last_tx_bytes = tx;
    m->last_rx_bytes = rx;

    /* Продвижение позиции — ПОСЛЕ записи всех трёх графиков */
    m->cpu_history_pos = (m->cpu_history_pos + 1) % TM_GRAPH_SAMPLES;
}

/* Отрисовка одного графика. history — кольцевой буфер сэмплов;
 * vmax — значение на верхней кромке (100 для CPU/MEM, автомасштаб для
 * сети); cur_label — подпись текущего значения у правого края;
 * cur_color — её цвет. */
static void tm_draw_graph(taskmgr_t *m, u32 *history, const char *label,
                          const char *cur_label, u32 cur_color, u32 vmax,
                          int gx, int gy, int gw, int gh)
{
    /* Фон графика */
    fb_fill_rect(gx, gy, gw, gh, wm_theme_win_bg());
    fb_rect(gx, gy, gw, gh, fb_rgb(0x2C, 0x31, 0x38));

    /* Сетка: 3 горизонтальные линии (25%, 50%, 75%) */
    for (int p = 25; p < 100; p += 25) {
        int ly = gy + gh - (p * (gh - 4) / 100) - 2;
        fb_hline(gx + 1, gx + gw - 2, ly, fb_rgb(0x1A, 0x1E, 0x24));
    }

    /* Метка */
    fb_text(gx + 2, gy + 2, label, wm_theme_text_info(), -1);

    /* Подпись текущего значения у правого края (ширина по СИМВОЛАМ —
     * кириллица в подписи скорости «КБ/с» занимает 2 байта) */
    if (cur_label && cur_label[0]) {
        int lw = (int)fb_text_w(cur_label);
        if (lw > gw - 4) lw = gw - 4;
        fb_text(gx + gw - 2 - lw, gy + 2, cur_label, cur_color, -1);
    }

    /* График: линия из 64 точек, значение 0..vmax */
    int n = TM_GRAPH_SAMPLES;
    if (n > gw - 2) n = gw - 2;
    u32 denom = (vmax > 0) ? vmax : 1;    /* защита от деления на 0 */
    int px = -1, py = -1;
    for (int i = 0; i < n; i++) {
        int idx = (m->cpu_history_pos + i) % TM_GRAPH_SAMPLES;
        u32 val = history[idx];
        if (val > denom) val = denom;         /* кламп всплесков */
        int x = gx + 1 + (i * (gw - 2) / n);
        int y = gy + gh - 2 - (int)(val * (u32)(gh - 4) / denom);
        if (y < gy + 2) y = gy + 2;
        if (y > gy + gh - 2) y = gy + gh - 2;
        if (px >= 0) {
            if (x > px) {
                for (int xi = px; xi <= x; xi++)
                    fb_fill_rect(xi, y, 1, 1, wm_theme_accent());
            }
            if (y != py) {
                int y0 = (y < py) ? y : py;
                int y1 = (y < py) ? py : y;
                fb_vline(x, y0, y1, wm_theme_accent());
            }
        }
        px = x; py = y;
    }
}

/* Текущее значение графика (последний сэмпл кольца) */
static u32 tm_graph_cur(taskmgr_t *m, u32 *history)
{
    return history[(m->cpu_history_pos + TM_GRAPH_SAMPLES - 1) % TM_GRAPH_SAMPLES];
}

/* Скорость сети в человекочитаемом виде: «N Б/с», «N.N КБ/с», «N.N МБ/с».
 * Сэмпл — байт за 0.5 с, поэтому байт/с = сэмпл * 2. */
static void tm_fmt_rate(u32 bytes_per_s, char *out, int sz)
{
    if (bytes_per_s >= 1024u * 1024) {
        unsigned whole = bytes_per_s >> 20;
        unsigned frac = ((bytes_per_s & 0xFFFFFu) * 10) >> 20;
        snprintf(out, sz, "%u.%u МБ/с", whole, frac);
    } else if (bytes_per_s >= 1024) {
        unsigned whole = bytes_per_s >> 10;
        unsigned frac = ((bytes_per_s & 0x3FFu) * 10) >> 10;
        snprintf(out, sz, "%u.%u КБ/с", whole, frac);
    } else {
        snprintf(out, sz, "%u Б/с", (unsigned)bytes_per_s);
    }
}

/* ---------------- загрузка ядер (сессии 74/75, ПЕРЕРАБОТКА 82) ----------------
 * Запрос пользователя: «подложка под надпись о загрузке ядер +
 * разнести на несколько строк, равных количеству ядер». Было:
 * «Ядра, %: 0:12 1:4» голым текстом без фона, 4 ядра в строке, и
 * ОШИБКА ЕДИНИЦ (сессия 75): ширина подписи в ПИКСЕЛЯХ (72) шла как
 * вертикальный отступ первой строки — значения рисовались в четырёх
 * строках ПОД подписью. Теперь: панель в стиле графиков (фон +
 * рамка = подложка), по строке на ядро («Ядро 0: 12%»), справа —
 * мини-бар загрузки. Ядро 0 (BSP) — оценка планировщика (последний
 * сэмпл графика CPU); AP-ядра — честные измерения LAPIC-таймера
 * (smp_cpu_load, -1 = офлайн). Цвет строки — по её загрузке. */
static int tm_core_pct(taskmgr_t *m, int i)
{
    if (i <= 0) return (int)tm_graph_cur(m, m->cpu_history);
    return smp_cpu_load(i);          /* -1 = офлайн */
}

static void tm_draw_cores(taskmgr_t *m, int x0, int y0, int maxw, int maxh)
{
    int n = smp_cpu_count();
    if (n < 1) n = 1;
    int line_h = 16;
    int pad = 6;

    /* сколько строк-ядер помещается до подвала (максимум SMP_MAX_CPUS;
     * при нехватке высоты показываем первые — окно не резиновое) */
    int max_lines = (maxh - pad * 2 - line_h) / line_h;
    if (max_lines < 1) max_lines = 1;
    if (n > max_lines) n = max_lines;

    int panel_h = pad * 2 + line_h + n * line_h;

    /* ПОДЛОЖКА: фон + рамка — единый стиль с графиками (запрос) */
    fb_fill_rect(x0, y0, maxw, panel_h, wm_theme_win_bg_alt());
    fb_rect(x0, y0, maxw, panel_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(x0 + 4, y0 + pad - 1, "Ядра, %:", wm_theme_text_info(), -1);

    int bar_w = 64, bar_h = 8;
    for (int i = 0; i < n; i++) {
        int pct = tm_core_pct(m, i);
        int ly = y0 + pad + line_h + i * line_h;
        char line[48];
        if (pct < 0) snprintf(line, sizeof(line), "Ядро %d: —", i);
        else         snprintf(line, sizeof(line), "Ядро %d: %d%%", i, pct);
        u32 c = pct > 80 ? fb_rgb(0xFF, 0x60, 0x60) :
                pct > 50 ? fb_rgb(0xFF, 0xE0, 0x60) :
                           wm_theme_text_info();
        fb_text(x0 + 8, ly, line, c, -1);
        if (pct >= 0) {
            /* мини-бар загрузки: заполнение = pct% (деления — только
             * на константы: клампов достаточно, #0 исключён) */
            int bx = x0 + maxw - 8 - bar_w;
            int by = ly + (line_h - bar_h) / 2;
            fb_fill_rect(bx, by, bar_w, bar_h, fb_rgb(0x1A, 0x1E, 0x24));
            int fill = pct * bar_w / 100;
            if (fill > 0) fb_fill_rect(bx, by, fill, bar_h, c);
        }
    }
}

/* «… | 2 ядра / 4 потока» для шапки (только когда ядер > 1) */
static const char *tm_plural(int n, const char *one, const char *few,
                             const char *many)
{
    int m10 = n % 10, m100 = n % 100;
    if (m10 == 1 && m100 != 11) return one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
    return many;
}

static void tm_draw(window_t *w)
{
    taskmgr_t *m = (taskmgr_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int cur = task_current();
    int active = task_count();

    tm_rebuild(m);

    /* Шапка */
    fb_fill_rect(0, 0, cw, TM_HDR_H, wm_theme_title());
    char hdr[128];
    {
        char topo[48] = "";
        int  lc = smp_cpu_count();
        if (lc > 1) {
            int co = smp_topo_cores(), th = smp_topo_threads();
            snprintf(topo, sizeof(topo), " | %d %s / %d %s",
                     co, tm_plural(co, "ядро", "ядра", "ядер"),
                     th, tm_plural(th, "поток", "потока", "потоков"));
        }
        snprintf(hdr, sizeof(hdr), "Диспетчер задач: %d активных из %d слотов%s",
                 active, MAX_TASKS, topo);
    }
    fb_text(8, 3, hdr, wm_theme_text(), -1);

    /* График загрузки CPU (правая часть окна) */
    int graph_x = cw - TM_GRAPH_W - 4;
    int graph_y = TM_HDR_H + 2;
    {
        u32 pct = tm_graph_cur(m, m->cpu_history);
        char lbl[16];
        snprintf(lbl, sizeof(lbl), "%u%%", (unsigned)pct);
        tm_draw_graph(m, m->cpu_history, "CPU", lbl,
                      pct > 80 ? fb_rgb(0xFF, 0x60, 0x60) :
                      pct > 50 ? fb_rgb(0xFF, 0xE0, 0x60) :
                                 fb_rgb(0x90, 0xEE, 0x90),
                      100, graph_x, graph_y, TM_GRAPH_W, TM_GRAPH_H);
    }

    /* График загрузки памяти (под CPU) */
    int mem_y = graph_y + TM_GRAPH_H + 4;
    {
        u32 pct = tm_graph_cur(m, m->mem_history);
        char lbl[16];
        snprintf(lbl, sizeof(lbl), "%u%%", (unsigned)pct);
        tm_draw_graph(m, m->mem_history, "MEM", lbl,
                      pct > 80 ? fb_rgb(0xFF, 0x60, 0x60) :
                      pct > 50 ? fb_rgb(0xFF, 0xE0, 0x60) :
                                 fb_rgb(0x90, 0xEE, 0x90),
                      100, graph_x, mem_y, TM_GRAPH_W, TM_GRAPH_H);
    }

    /* График сети (под памятью; запрос пользователя). Автомасштаб по
     * максимуму окна, но не меньше 64 Б/сэмпл (128 Б/с) — иначе мелкий
     * трафик рисовался бы сплошным нулём. */
    int net_y = mem_y + TM_GRAPH_H + 4;
    {
        u32 vmax = 64;
        for (int i = 0; i < TM_GRAPH_SAMPLES; i++)
            if (m->net_history[i] > vmax) vmax = m->net_history[i];
        char lbl[24];
        tm_fmt_rate(tm_graph_cur(m, m->net_history) * 2, lbl, sizeof(lbl));
        tm_draw_graph(m, m->net_history, "NET", lbl,
                      fb_rgb(0x90, 0xEE, 0x90),
                      vmax, graph_x, net_y, TM_GRAPH_W, TM_GRAPH_H);
    }

    /* СЕССИЯ 82: проценты загрузки ядер — панель-подложка ПОД
     * ГРАФИКАМИ в правой колонке, ПО ОДНОЙ СТРОКЕ на ядро (запрос
     * пользователя); список задач начинается сразу под шапкой. */
    {
        int cy = net_y + TM_GRAPH_H + 8;
        int avail = ch - 14 - cy - 2;      /* до подвала включительно */
        if (avail < 0) avail = 0;
        tm_draw_cores(m, graph_x, cy, TM_GRAPH_W, avail);
    }

    /* Заголовок списка задач. Колонки строго под формат строки
     * "%3d имя(13) %6u %5uK %4s %s": Idx 0-2, Имя 4-16, Uptime 18-23,
     * Mem 25-29 (K на 30), Ядро 32-35, Статус с 37. Пробелы собираются
     * кусками в кавычках, чтобы число колонок было видно явно. */
    int list_x = 0;
    int list_w = graph_x - 4;
    fb_fill_rect(list_x, TM_HDR_H, list_w, 18, wm_theme_win_bg_alt());
    fb_text(list_x + 4, TM_HDR_H + 1,
            "Idx Имя" "           " "Uptime" " " "Mem" "    " "Ядро" " " "Статус",
            wm_theme_text(), -1);

    /* Список задач */
    int area_y0 = TM_LIST_Y0;
    int area_h  = ch - area_y0 - 14;
    int vis = area_h / TM_ROW_H;
    if (vis < 1) vis = 1;
    fb_fill_rect(list_x, area_y0, list_w, area_h, wm_theme_win_bg());

    int y = area_y0 + 2;
    int vis_max = (vis < m->slots_used) ? vis : m->slots_used;
    for (int i = 0; i < vis_max; i++) {
        int slot = m->slot_idx[m->scroll + i];
        if (slot < 0 || slot >= MAX_TASKS) break;
        char line[100];
        char name_col[TM_NAME_COLS * 3 + 2];   /* 13 симв. * 3 байта + NUL */
        u32 up = task_uptime(slot);
        u32 mem = mem_task_used(slot);          /* память задачи, байты */
        const char *st = tm_status_str(slot, cur);
        /* VMware-сессия [CORE-COL] (запрос пользователя): колонка
         * «Ядро» — на каком ядре НАХОДИТСЯ процесс. Живое значение
         * (task_core_live): работающая сейчас задача — ядро-
         * исполнитель с меткой «*» (0* = BSP, 1* = AP1); остальная —
         * назначенное ядро (миграции голодающих AP1->BSP видны). */
        char corebuf[8];
        int core = task_core_live(slot);
        if (core < 0)            snprintf(corebuf, sizeof(corebuf), "?");
        else if (task_on_cpu(slot) || slot == cur)
                                 snprintf(corebuf, sizeof(corebuf), "%d*", core);
        else                     snprintf(corebuf, sizeof(corebuf), "%d", core);
        /* Имя — по СИМВОЛАМ до 13 (кириллица не сдвигает колонки) */
        tm_fmt_name(name_col, sizeof(name_col), task_name(slot));
        snprintf(line, sizeof(line), "%3d %s %6u %5uK %4s %s",
                 slot, name_col, (unsigned)(up / 1000),   /* 1 тик = 1 мс */
                 (unsigned)(mem / 1024), corebuf, st);
        u32 fg = (slot == cur) ? wm_theme_accent()
                : wm_theme_text();
        int is_sel = (i == (m->sel - m->scroll));
        if (slot == cur)
            fb_fill_rect(list_x, y, list_w, TM_ROW_H, wm_theme_sel_bg());
        if (is_sel && slot != cur)
            fb_fill_rect(list_x, y, list_w, TM_ROW_H, fb_rgb(0x33, 0x4A, 0x60));
        if (is_sel)
            fb_rect(list_x, y, list_w, TM_ROW_H, fb_rgb(0xFF, 0xFF, 0xFF));
        fb_text(list_x + 4, y, line, fg, -1);
        y += TM_ROW_H;
    }

    /* Подвал: статус (результат убийства/подсказка) слева, куча и
     * uptime справа. Текст на ch-16 (не ch-12): глиф 16 пикселей и при
     * ch-12 нижние 4 ряда обрезались клипом canvas — «хвосты» букв
     * (у, р, /, запятая) исчезали. */
    fb_fill_rect(0, ch - 14, cw, 14, wm_theme_win_bg_alt());
    char right[80];
    snprintf(right, sizeof(right), "куча: %u из %u КиБ | uptime: %u сек",
             (unsigned)(mem_used() / 1024),
             (unsigned)(mem_heap_size() / 1024),
             (unsigned)uptime_sec());
    int rw = (int)fb_text_w(right);
    fb_text(cw - 4 - rw, ch - 16, right, wm_theme_text_info(), -1);
    /* m->status раньше вообще не рисовался — результат «убито/не
     * удалось» был виден только по исчезновению строки. Теперь слева,
     * обрезка по СИМВОЛАМ до доступной ширины (wm_text_fit). */
    wm_text_fit(4, ch - 16, m->status, cw - rw - 12, wm_theme_text(), 0);
}

static void tm_tick(window_t *w)
{
    taskmgr_t *m = (taskmgr_t *)w->data;
    tm_sample(m);
    win_invalidate(w);
}

/* ===================== мышь (запрос пользователя) ===================== */

/* Убить выбранную задачу. Общий путь для Del, повторного клика ЛКМ и
 * пункта контекстного меню. */
static void tm_kill_sel(window_t *w, taskmgr_t *m)
{
    if (m->sel < 0 || m->sel >= m->slots_used) return;
    int slot = m->slot_idx[m->sel];
    if (slot <= 0) {
        strcpy(m->status, "Задачу 0 (ядро) убить нельзя");
        win_invalidate(w);
        return;
    }
    /* Системные задачи (ramfs-сервер) убивать НЕЛЬЗЯ: их смерть
     * блокирует файловые операции всей ОС. */
    if (task_is_system(slot)) {
        snprintf(m->status, sizeof(m->status),
                 "Задача #%d (%s) — системная, убийство запрещено",
                 slot, task_name(slot));
        win_invalidate(w);
        return;
    }
    int r = task_kill(slot);
    /* Если это поток окна — попутно убрать и окно (иначе мёртвое окно
     * останется висеть на экране). */
    wm_request_kill(slot);
    if (r) {
        snprintf(m->status, sizeof(m->status),
                 "Задача #%d (%s) убита", slot, task_name(slot));
    } else {
        snprintf(m->status, sizeof(m->status),
                 "Не удалось убить задачу #%d", slot);
    }
    /* Список перестроится на следующем tm_rebuild */
    win_invalidate(w);
}

/* Строка списка под курсором (my — координата содержимого) или -1.
 * Геометрия — та же, что в tm_draw: область с TM_LIST_Y0, первая
 * строка на +2, шаг TM_ROW_H. */
static int tm_hit_row(taskmgr_t *m, window_t *w, int my)
{
    int list_y0 = TM_LIST_Y0;
    int area_h = win_content_h(w) - list_y0 - 14;
    if (my < list_y0 || my >= list_y0 + area_h) return -1;
    int row = (my - list_y0 - 2) / TM_ROW_H;
    if (row < 0) row = 0;
    int idx = m->scroll + row;
    return (idx >= 0 && idx < m->slots_used) ? idx : -1;
}

/* Контекстное меню строки (как в «Файлах»): «Снять задачу». */
enum { TMC_KILL = 1 };
static wm_menu_item_t tm_menu_items[2];

static void tm_menu_cb(int id, void *uctx)
{
    /* Гарантия wm_menu_open: колбэк исполняется в ПОТОКЕ ОКНА-владельца,
     * поэтому доступ к m->status/win_invalidate безопасен. */
    window_t *w = (window_t *)uctx;
    taskmgr_t *m = (taskmgr_t *)w->data;
    if (id == TMC_KILL) tm_kill_sel(w, m);
}

static void tm_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    taskmgr_t *m = (taskmgr_t *)w->data;

    /* ПКМ по строке — контекстное меню с «Снять задачу»; для
     * системных задач (и слота 0) пункт серый. */
    if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
        int idx = tm_hit_row(m, w, my);
        if (idx >= 0 && !wm_menu_active()) {
            if (idx != m->sel) {
                m->sel = idx;
                win_invalidate(w);
            }
            int slot = m->slot_idx[idx];
            tm_menu_items[0].label = "Снять задачу";
            tm_menu_items[0].id = TMC_KILL;
            tm_menu_items[0].disabled = (u8)(slot <= 0 || task_is_system(slot));
            tm_menu_items[1].label = NULL;   /* конец списка */
            tm_menu_items[1].id = 0;
            tm_menu_items[1].disabled = 0;
            wm_menu_open(w, mx, my, tm_menu_items, 1, tm_menu_cb, w);
        }
        return;
    }

    /* ЛКМ по строке — выделение; клик по УЖЕ выделенной строке —
     * снять задачу (конвенция «Файлов»: клик по выбранному =
     * действие; двойной клик не нужен). */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        int idx = tm_hit_row(m, w, my);
        if (idx < 0) return;
        if (idx != m->sel) {
            m->sel = idx;
            win_invalidate(w);
        } else {
            tm_kill_sel(w, m);
        }
    }
}

static void tm_key(window_t *w, const key_event_t *ev)
{
    taskmgr_t *m = (taskmgr_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    if (ev->code == KBD_UP) {
        if (m->sel > 0) {
            m->sel--;
            if (m->sel < m->scroll) m->scroll = m->sel;
        }
        win_invalidate(w);
        return;
    }
    if (ev->code == KBD_DOWN) {
        if (m->sel + 1 < m->slots_used) {
            m->sel++;
            int vis = (win_content_h(w) - TM_HDR_H - 14) / TM_ROW_H;
            if (m->sel >= m->scroll + vis) m->scroll = m->sel - vis + 1;
        }
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x49) {  /* PgUp */
        m->sel -= 8; if (m->sel < 0) m->sel = 0;
        if (m->scroll > m->sel) m->scroll = m->sel;
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x51) {  /* PgDn */
        m->sel += 8;
        if (m->sel >= m->slots_used) m->sel = m->slots_used - 1;
        int vis = (win_content_h(w) - TM_HDR_H - 14) / TM_ROW_H;
        if (m->sel >= m->scroll + vis) m->scroll = m->sel - vis + 1;
        win_invalidate(w);
        return;
    }
    if (ev->code == DEL_KEY) {  /* Del — убить выбранную задачу */
        tm_kill_sel(w, m);
        return;
    }
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
}

static void tm_close(window_t *w)
{
    if (w->data) free(w->data);
}

void app_taskmgr_open(void)
{
    taskmgr_t *m = (taskmgr_t *)malloc(sizeof(taskmgr_t));
    if (!m) return;
    m->scroll = 0;
    m->sel = 0;
    m->slots_used = 0;
    memset(m->slot_idx, 0, sizeof(m->slot_idx));
    memset(m->cpu_history, 0, sizeof(m->cpu_history));
    memset(m->mem_history, 0, sizeof(m->mem_history));
    memset(m->net_history, 0, sizeof(m->net_history));
    m->cpu_history_pos = 0;
    m->last_idle_uptime = 0;
    m->last_total_uptime = 0;
    /* Снимки счётчиков НА СТАРТЕ: иначе первый сэмпл показал бы весь
     * трафик с момента загрузки ОС одним всплеском. */
    m->last_tx_bytes = net_tx_bytes();
    m->last_rx_bytes = net_rx_bytes();
    strcpy(m->status,
           "ЛКМ — выбрать; повторный ЛКМ/ПКМ — снять задачу; Del — снять");

    u32 W = fb_width(), H = fb_height();
    int ww = TM_COLS * 8 + 12;
    int wh = TM_ROWS * 16 + TM_HDR_H + 16 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    win_create("Диспетчер задач", 100, 40, ww, wh,
               tm_draw, tm_key, tm_mouse, tm_tick, tm_close, m);
}
