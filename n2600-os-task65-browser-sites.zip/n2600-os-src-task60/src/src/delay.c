/* delay.c — единый слой задержек драйверов (реализация, Task 49).
 * См. delay.h (мотивация: 5 копий калибровок, гонка с [PIT2-RESYNC],
 * у ath9k калибровка закрывала GATE2 без resync). */
#include "delay.h"
#include "io.h"
#include "timer.h"
#include "string.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

static volatile u32 g_io_per_us = 3;   /* итераций inb(0x80) на 1 мкс */
static volatile int g_done = 0;
static volatile int g_lock = 0;        /* cmpxchg: калибровка идёт */

/* latch-чтение счётчика канала 2 (без IRQ, работает до sti) */
static u16 pit2_latch(void)
{
    outb(0x43, 0x80);                  /* latch канал 2 */
    return (u16)(inb(0x42) | (inb(0x42) << 8));
}

u32 delay_io_per_us(void) { return g_io_per_us; }

void delay_init(void)
{
    if (g_done) return;
    int expected = 0;
    __asm__ __volatile__("lock cmpxchgl %2, %0"
                         : "+m"(g_lock), "+a"(expected)
                         : "r"(1)
                         : "memory", "cc");
    if (expected != 0) {               /* другой поток калибрует */
        for (u32 i = 0; i < 8000000u && !g_done; i++)
            __asm__ __volatile__("pause" ::: "memory");
        return;
    }
    if (g_done) { __asm__ __volatile__("movl $0, %0" : "=m"(g_lock)); return; }

    u8 p61 = inb(0x61);
    outb(0x61, (u8)((p61 | 0x01) & ~0x02));   /* GATE2=1, динамик выкл */
    outb(0x43, 0xB4);                  /* канал 2, режим 2, binary */
    outb(0x42, 0xFF); outb(0x42, 0xFF);/* делитель 65535 */

    u32 best = 0;
    for (int s = 0; s < 4 && !best; s++) {
        u32 n = 2000;
        u16 t0 = pit2_latch();
        for (u32 i = 0; i < n; i++) (void)inb(0x80);
        u16 t1 = pit2_latch();
        u32 dt = (u32)((t0 - t1) & 0xFFFF);
        if (dt < 8 || dt > 60000) continue;   /* глюк чтения */
        u32 per_us = (u32)(((u64)n * 1193182u) / 1000000u / dt);
        if (per_us > best) best = per_us;
    }
    /* [PIT2-RESYNC]: GATE2 оставляем ОТКРЫТЫМ (конвенция timer.c —
     * закрытие могло заморозить счётчик: дедлайны timer переставали
     * истекать) и переозначаем базу оборотов — перепрограммка канала
     * (0xB4 + 0xFFFF) иначе даёт фантомные +65536 тиков (~55 мс) всем
     * ждущим. Это и есть фикс пропущенного resync у ath9k. */
    outb(0x61, (u8)((p61 | 0x01) & ~0x02));
    timer_pit2_resync();

    if (best == 0) best = 8;           /* PIT молчит — консервативно */
    if (best > 2000) best = 2000;
    g_io_per_us = best + 1;            /* +1: небольшой запас */
    g_done = 1;
    __asm__ __volatile__("movl $0, %0" : "=m"(g_lock));

    {
        char b[72];
        snprintf(b, sizeof(b),
                 "калибровка задержек: %u итераций/мкс (delay.c)\n",
                 (unsigned)best);
        serial_puts(b);
        klog_puts(b);
    }
}

void delay_us(u32 us)
{
    if (!us) return;
    if (us <= 30) {
        /* короткие: калиброванный порт 0x80 — субмкc-гранулярность,
         * накладные расходы PIT-опроса (~2-3 мкс) были бы заметны */
        volatile u32 n = us * g_io_per_us;
        while (n-- > 0) (void)inb(0x80);
        return;
    }
    /* длинные: PIT канал 2 через timer_poll_* — точно и без влияния
     * SMI/пробок порта 0x80 (тот же путь, что uhci_udelay/hd_delay) */
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, us)) { }
}

void delay_ms(u32 ms)
{
    if (!ms) return;
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, ms * 1000u)) { }
}
