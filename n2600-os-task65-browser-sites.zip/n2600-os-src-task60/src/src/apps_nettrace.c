/* apps_nettrace.c — HTTP Trace: трассировка HTTP-запроса и ответа.
 *
 * Зачем: браузер показывает только итог («Ошибка запроса: connect
 * timeout»), но не видно, ГДЕ именно запрос отвалился и какие байты
 * реально ушли/пришли. Это приложение выполняет тот же GET через
 * net_http_get_traced() и показывает:
 *   - таймлайн фаз: DNS -> ARP -> TCP connect (+число доотправок SYN)
 *     -> отправка запроса -> первый байт ответа -> итог;
 *   - ТОЧНЫЕ байты отправленного запроса (заголовки как есть);
 *   - сырой ответ: статус-строку, заголовки, hex-дамп начала тела;
 *   - причину сбоя с последней достигнутой стадией («arp», «connect»,
 *     «recv»...).
 *
 * Каждое окно — отдельный поток (многопоточный WM): трассировка не
 * блокирует систему; можно открыть несколько окон с разными адресами.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "net.h"
#include "timer.h"
#include "mouse.h"

#define NT_COLS 90
#define NT_ROWS 512
#define NT_HDR 22           /* высота строки адреса */
#define NT_STATUS_H 16
#define NT_ADDR_MAX 118
#define NT_FETCH_MAX 16384  /* буфер ответа на время запроса */
#define NT_RESP_COPY_MAX 8192
#define NT_REQ_COPY_MAX 1024

typedef struct {
    char lines[NT_ROWS][NT_COLS + 1];
    int  nlines;
    int  scroll;
    int  fetching;          /* 1 = идёт запрос (в потоке этого окна) */
    char url[128];          /* последний адрес */
    char status[96];
    /* адресная строка */
    char addr[NT_ADDR_MAX + 1];
    int  addr_len;
    int  addr_focus;
    wm_scrollbar_t sb;      /* общий виджет полосы прокрутки */
    window_t *win;
} nettrace_t;

/* ---------- вывод в буфер строк ---------- */

static void nt_clear(nettrace_t *n)
{
    n->nlines = 0;
    n->scroll = 0;
}

static void nt_add(nettrace_t *n, const char *s)
{
    if (n->nlines >= NT_ROWS) {
        /* кольцевой сдвиг: выкидываем самое старое */
        memmove(n->lines[0], n->lines[1], sizeof(n->lines[0]) * (NT_ROWS - 1));
        n->nlines = NT_ROWS - 1;
    }
    strncpy(n->lines[n->nlines], s, NT_COLS);
    n->lines[n->nlines][NT_COLS] = 0;
    n->nlines++;
}

/* Добавить текст с разбиением по '\n' (длинные строки режем по NT_COLS). */
static void nt_add_text(nettrace_t *n, const char *s, int len)
{
    int i = 0;
    while (i < len && s[i]) {
        int start = i;
        while (i < len && s[i] != '\n' && (i - start) < NT_COLS) i++;
        int L = i - start;
        if (L > NT_COLS) L = NT_COLS;
        char buf[NT_COLS + 1];
        /* убрать хвостовой '\r' (HTTP-строки CRLF) */
        if (L > 0 && s[start + L - 1] == '\r') L--;
        memcpy(buf, s + start, (u32)L);
        buf[L] = 0;
        nt_add(n, buf);
        if (i < len && s[i] == '\n') i++;
    }
}

/* hex-дамп: 16 байт на строку «XX XX ... |ascii|» */
static void nt_add_hex(nettrace_t *n, const u8 *p, u32 len)
{
    u32 off = 0;
    while (off < len) {
        char line[NT_COLS + 1];
        int pos = 0;
        pos += snprintf(line + pos, sizeof(line) - pos, "%04x  ", (unsigned)off);
        for (u32 k = 0; k < 16; k++) {
            if (off + k < len)
                pos += snprintf(line + pos, sizeof(line) - pos, "%02x ", p[off + k]);
            else
                pos += snprintf(line + pos, sizeof(line) - pos, "   ");
            if (k == 7) pos += snprintf(line + pos, sizeof(line) - pos, " ");
        }
        pos += snprintf(line + pos, sizeof(line) - pos, " |");
        for (u32 k = 0; k < 16 && off + k < len; k++) {
            char c = (char)p[off + k];
            line[pos++] = (c >= 0x20 && c < 0x7F) ? c : '.';
        }
        pos += snprintf(line + pos, sizeof(line) - pos, "|");
        nt_add(n, line);
        off += 16;
    }
}

/* ---------- парсинг URL (как в браузере) ---------- */

static int nt_parse_host(char *host, u16 *port)
{
    /* ЗАДАЧА 53 (ФИКС «https открывает порт 80», как в браузере): порт
     * по умолчанию ставит ВЫЗЫВАЮЩИЙ (443 для https, 80 для http);
     * здесь перезаписываем его ТОЛЬКО при явном ":порт". Раньше
     * безусловное *port = 80 затирало 443 — запрос https шёл на 80. */
    char *colon = strchr(host, ':');
    if (!colon) return 1;
    *colon = 0;
    u32 p = 0;   /* u32: проверка «> 65535» иначе мертва (u16 не переполняется) */
    for (const char *q = colon + 1; *q; q++) {
        if (*q < '0' || *q > '9') return 0;
        p = p * 10 + (u32)(*q - '0');
        if (p > 65535) return 0;
    }
    if (p == 0) return 0;
    *port = (u16)p;
    return 1;
}

/* ---------- выполнение запроса с трассировкой ---------- */

static void nt_go(nettrace_t *n, const char *addr)
{
    char host[128];
    char path[256];
    const char *p = addr;

    n->addr_focus = 0;
    while (*p == ' ') p++;
    if (!*p) { win_invalidate(n->win); return; }

    strncpy(n->url, p, sizeof(n->url) - 1);
    n->url[sizeof(n->url) - 1] = 0;

    if (!strncmp(p, "https://", 8)) { p += 8; }
    else if (!strncmp(p, "http://", 7)) p += 7;

    int hi = 0;
    while (*p && *p != '/' && hi < 127) host[hi++] = *p++;
    host[hi] = 0;
    /* порт по умолчанию: 443 для https, 80 для http (явный :порт важнее) */
    int use_tls = (!strncmp(addr, "https://", 8)) ? 1 : 0;
    u16 port = use_tls ? 443 : 80;
    if (!nt_parse_host(host, &port)) {
        nt_clear(n);
        nt_add(n, "Неверный порт в адресе (пример: http://10.0.2.2:8080/)");
        win_invalidate(n->win);
        return;
    }
    if (!*p) p = "/";
    strncpy(path, p, 255);
    path[255] = 0;
    if (!path[0]) strcpy(path, "/");

    if (!host[0]) {
        nt_clear(n);
        nt_add(n, "Пустой хост");
        win_invalidate(n->win);
        return;
    }
    /* СЕССИЯ 63: трассировку loopback (127.0.0.1, localhost) выполняем
     * и без NIC/настроенного IP — весь путь проходит внутри стека. */
    if (!net_host_is_loopback(host) &&
        (!net_nic_present() || net_get_ip() == 0)) {
        nt_clear(n);
        nt_add(n, "Сеть не настроена (см. ipconfig / dhcp в терминале)");
        win_invalidate(n->win);
        return;
    }

    /* статус до блокирующего запроса (мы в потоке своего окна) */
    n->fetching = 1;
    snprintf(n->status, sizeof(n->status),
             "Запрос %s://%s:%u%s ...", use_tls ? "https" : "http",
             host, (unsigned)port, path);
    win_draw_now(n->win);

    /* буферы */
    char *resp = (char *)malloc(NT_FETCH_MAX);
    char *reqc = (char *)malloc(NT_REQ_COPY_MAX);
    char *respc = (char *)malloc(NT_RESP_COPY_MAX);
    http_trace_t tr;
    memset(&tr, 0, sizeof(tr));
    tr.req_copy = reqc;
    tr.req_max = NT_REQ_COPY_MAX;
    tr.resp_copy = respc;
    tr.resp_max = NT_RESP_COPY_MAX;

    if (!resp || !reqc || !respc) {
        n->fetching = 0;
        snprintf(n->status, sizeof(n->status), "Нет памяти под буферы");
        if (resp) free(resp);
        if (reqc) free(reqc);
        if (respc) free(respc);
        win_invalidate(n->win);
        return;
    }

    int r = net_http_get_traced(host, port, path, resp, NT_FETCH_MAX, 12000, &tr);
    n->fetching = 0;

    /* ---------- отчёт ---------- */
    nt_clear(n);

    nt_add(n, "================ HTTP TRACE ================");
    {
        char line[NT_COLS + 1];
        snprintf(line, sizeof(line), "URL   : %s://%s:%u%s",
                 use_tls ? "https" : "http", host, (unsigned)port, path);
        nt_add(n, line);
    }

    /* IP и тайминги фаз */
    {
        char ipb[16];
        net_ntoa(tr.resolved_ip, ipb, sizeof(ipb));
        char line[NT_COLS + 1];
        snprintf(line, sizeof(line), "IP    : %s  (DNS: %u мс)",
                 tr.resolved_ip ? ipb : "не разрешён",
                 (unsigned)tr.t_dns_ms);
        nt_add(n, line);
        snprintf(line, sizeof(line), "ARP   : %u мс", (unsigned)tr.t_arp_ms);
        nt_add(n, line);
        snprintf(line, sizeof(line), "TCP   : connect %u мс (SYN повторов: %d, сокет %d)",
                 (unsigned)tr.t_connect_ms, tr.syn_kicks, tr.sock);
        nt_add(n, line);
        snprintf(line, sizeof(line), "Ответ : первый байт через %u мс, всего %u мс",
                 (unsigned)tr.t_first_ms, (unsigned)tr.t_total_ms);
        nt_add(n, line);
    }

    /* результат */
    if (r > 0) {
        char line[NT_COLS + 1];
        snprintf(line, sizeof(line), "ИТОГ  : OK, получено %d байт (стадия: %s)",
                 r, tr.stage);
        nt_add(n, line);
    } else {
        char line[NT_COLS + 1];
        snprintf(line, sizeof(line),
                 "ИТОГ  : ОШИБКА (код %d), стадия: %s",
                 r, tr.stage[0] ? tr.stage : "-");
        nt_add(n, line);
        snprintf(line, sizeof(line), "Причина: %s",
                 tr.error[0] ? tr.error : net_http_errstr());
        nt_add(n, line);
        nt_add(n, "Подсказки:");
        nt_add(n, " ARP мс>0 и обрыв на connect — сервер не отвечает/фильтр");
        nt_add(n, " 'connection refused' — порт закрыт");
        nt_add(n, " 'response timeout' — соединение есть, сервер молчит");
        nt_add(n, " 'connection reset' — сервер/шлюз сбросил соединение (RST)");
    }

    /* точный запрос */
    nt_add(n, "");
    {
        char line[NT_COLS + 1];
        snprintf(line, sizeof(line), "=== ЗАПРОС (%u байт) ===",
                 (unsigned)tr.req_len);
        nt_add(n, line);
    }
    if (tr.req_len > 0 && reqc[0])
        nt_add_text(n, reqc, (int)strlen(reqc));
    else
        nt_add(n, "(запрос не был отправлен)");

    /* сырой ответ */
    nt_add(n, "");
    {
        char line[NT_COLS + 1];
        snprintf(line, sizeof(line), "=== СЫРОЙ ОТВЕТ (%u байт) ===",
                 (unsigned)tr.resp_len);
        nt_add(n, line);
    }
    if (tr.resp_len > 0 && respc[0]) {
        /* заголовки — как текст */
        char *hdr_end = strstr(respc, "\r\n\r\n");
        int hdr_len = hdr_end
                    ? (int)(hdr_end - respc) + 4
                    : (int)strlen(respc);
        if (hdr_len > 2048) hdr_len = 2048;
        nt_add_text(n, respc, hdr_len);
        nt_add(n, "");
        nt_add(n, "--- hex-дамп первых 256 байт ответа ---");
        nt_add_hex(n, (const u8 *)respc, tr.resp_len < 256 ? tr.resp_len : 256);
    } else {
        nt_add(n, "(ответа нет — ни одного байта не получено)");
    }

    snprintf(n->status, sizeof(n->status),
             "%s | строк: %d | PgUp/PgDn — прокрутка",
             r > 0 ? "Готово" : "Ошибка", n->nlines);

    free(resp);
    free(reqc);
    free(respc);
    win_invalidate(n->win);
}

/* ---------- отрисовка ---------- */

static void nt_draw(window_t *w)
{
    nettrace_t *n = (nettrace_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* --- строка адреса --- */
    fb_fill_rect(0, 0, cw, NT_HDR, fb_rgb(0x16, 0x1C, 0x24));
    fb_hline(0, cw - 1, NT_HDR - 1, fb_rgb(0x2C, 0x31, 0x38));

    int box_x = 4, box_y = 3, box_w = cw - 68, box_h = 16;
    fb_fill_rect(box_x, box_y, box_w, box_h,
                 n->addr_focus ? wm_theme_win_bg() : fb_rgb(0x1E, 0x24, 0x2C));
    fb_rect(box_x, box_y, box_w, box_h,
            n->addr_focus ? wm_theme_accent() : fb_rgb(0x34, 0x3A, 0x42));

    char shown[NT_ADDR_MAX + 2];
    int max_chars = (box_w - 12) / 8;
    if (max_chars < 4) max_chars = 4;
    if (max_chars > NT_ADDR_MAX) max_chars = NT_ADDR_MAX;
    const char *src = n->addr_focus ? n->addr
                     : (n->addr[0] ? n->addr : "http://10.0.2.2:8080/");
    int sl = (int)strlen(src);
    int from = 0;
    if (sl > max_chars) from = sl - max_chars;
    int tl = sl - from;
    memcpy(shown, src + from, (u32)tl);
    shown[tl] = 0;
    if (n->addr_focus && wm_blink()) {
        shown[tl] = '_';
        shown[tl + 1] = 0;
    }
    fb_text(box_x + 6, box_y + 1, shown,
            n->addr_focus ? wm_theme_text() : wm_theme_text_dim(), -1);

    /* кнопка GO */
    fb_fill_rect(cw - 60, 3, 56, 16, wm_theme_sel_bg());
    fb_rect(cw - 60, 3, 56, 16, fb_rgb(0x3E, 0x7D, 0xBF));
    fb_text(cw - 60 + 20, 5, n->fetching ? "..." : "GO",
            wm_theme_text(), -1);

    /* --- содержимое --- */
    fb_fill_rect(0, NT_HDR, cw, ch - NT_HDR - NT_STATUS_H, wm_theme_win_bg());
    int vis = (ch - NT_HDR - NT_STATUS_H) / 16;
    if (vis < 1) vis = 1;
    int max_scroll = n->nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (n->scroll > max_scroll) n->scroll = max_scroll;
    if (n->scroll < 0) n->scroll = 0;

    int y = NT_HDR + 2;
    for (int i = n->scroll; i < n->nlines && (i - n->scroll) < vis; i++, y += 16) {
        u32 col = wm_theme_text();
        const char *L = n->lines[i];
        if (L[0] == '=') col = wm_theme_accent();
        else if (!strncmp(L, "ИТОГ", 4) || !strncmp(L, "Причина", 7))
            col = fb_rgb(0xFF, 0xE0, 0x60);
        else if (!strncmp(L, "---", 3) || !strncmp(L, "===", 3))
            col = fb_rgb(0x8F, 0xC8, 0xFF);
        fb_text(4, y, L, col, -1);
    }

    /* полоса прокрутки — общий виджет wm_scrollbar (цвет из темы);
     * раньше здесь были только индикаторы ^/v */
    wm_scrollbar_draw(&n->sb, cw - 7, NT_HDR + 2, 5,
                      ch - NT_HDR - NT_STATUS_H - 4, n->scroll, max_scroll, vis);

    /* --- статус --- */
    fb_fill_rect(0, ch - NT_STATUS_H, cw, NT_STATUS_H, wm_theme_win_bg_alt());
    fb_text(4, ch - NT_STATUS_H + 1, n->status, wm_theme_text_info(), -1);
}

/* ---------- ввод ---------- */

static void nt_key(window_t *w, const key_event_t *ev)
{
    nettrace_t *n = (nettrace_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* Ctrl+L — фокус на адрес */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'l' || ev->ch == 'L' || ev->ch == 0x0C)) {
        n->addr_focus = 1;
        win_invalidate(w);
        return;
    }

    if (n->addr_focus) {
        if (ev->ch == 0x1B || ev->code == 0x01) {          /* Esc */
            n->addr_focus = 0;
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n') {          /* Enter — GO */
            nt_go(n, n->addr);
            return;
        }
        if (ev->code == 0x0E) {                            /* Backspace */
            if (n->addr_len > 0) {
                n->addr[--n->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        if (ev->ch >= 0x20 && ev->ch < 0x7F && !(ev->flags & KF_CTRL)) {
            if (n->addr_len < NT_ADDR_MAX) {
                n->addr[n->addr_len++] = ev->ch;
                n->addr[n->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        return;
    }

    /* прокрутка
     * ФИКС сессии 17: раньше PgUp листало ВНИЗ, а Home/End были
     * перепутаны. scroll — первая видимая строка. */
    int ch = win_content_h(w);
    int vis = (ch - NT_HDR - NT_STATUS_H) / 16;
    if (vis < 1) vis = 1;
    int max_scroll = n->nlines - vis;
    if (max_scroll < 0) max_scroll = 0;

    if (ev->code == 0x49) {                                /* PgUp */
        n->scroll -= vis;
        if (n->scroll < 0) n->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x51) {                         /* PgDn */
        n->scroll += vis;
        if (n->scroll > max_scroll) n->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == KBD_UP) {
        /* ЗАДАЧА 53: стрелки — несколько строк, не 1 */
        if (n->scroll > 0) {
            n->scroll -= WM_KEY_SCROLL_LINES;
            if (n->scroll < 0) n->scroll = 0;
        }
        win_invalidate(w);
    } else if (ev->code == KBD_DOWN) {
        if (n->scroll < max_scroll) {
            n->scroll += WM_KEY_SCROLL_LINES;
            if (n->scroll > max_scroll) n->scroll = max_scroll;
        }
        win_invalidate(w);
    } else if (ev->code == 0x47) {                         /* Home */
        n->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x4F) {                         /* End */
        n->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->ch == 0x1B || ev->code == 0x01) {
        win_close(w);
    } else if (ev->ch == 'g' || ev->ch == 'G') {           /* G — повторить */
        if (n->addr[0]) nt_go(n, n->addr);
    }
}

static void nt_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    nettrace_t *n = (nettrace_t *)w->data;
    if (my < 0 || mx < 0) return;
    int cw = win_content_w(w);

    if (my < NT_HDR) {
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            if (mx >= cw - 60) {
                if (!n->fetching) nt_go(n, n->addr);      /* кнопка GO */
            } else {
                if (!n->addr_focus) {
                    n->addr_focus = 1;
                    win_invalidate(w);
                }
            }
        }
        return;
    }
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && n->addr_focus) {
        n->addr_focus = 0;
        win_invalidate(w);
    }

    /* полоса прокрутки (сессия 17); сессия 20: при drag полосу не
     * отпускаем — события с любыми координатами (захват мыши) */
    int cw2 = win_content_w(w), chh = win_content_h(w);
    if ((mx >= cw2 - 9 && my >= NT_HDR && my < chh - NT_STATUS_H) ||
        n->sb.dragging) {
        int np = wm_scrollbar_mouse(&n->sb, mx, my, btn, changed);
        if (np >= 0) { n->scroll = np; win_invalidate(w); }
    }
}

static void nt_close(window_t *w)
{
    nettrace_t *n = (nettrace_t *)w->data;
    if (n) free(n);
}

void app_nettrace_open(void)
{
    nettrace_t *n = (nettrace_t *)malloc(sizeof(nettrace_t));
    if (!n) return;
    memset(n, 0, sizeof(nettrace_t));
    n->win = NULL;

    u32 W = fb_width(), H = fb_height();
    int ww = NT_COLS * 8 + 12;
    int wh = 26 * 16 + NT_HDR + NT_STATUS_H + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    /* подсказка-заглушка до первого запроса */
    nt_add(n, "HTTP Trace — трассировка HTTP-запроса/ответа.");
    nt_add(n, "");
    nt_add(n, "Введите адрес (http://host[:port]/path) и нажмите");
    nt_add(n, "Enter или GO — увидите тайминги фаз, точные байты");
    nt_add(n, "запроса, заголовки ответа и hex-дамп начала тела.");
    nt_add(n, "");
    nt_add(n, "Если браузер пишет «Ошибка запроса» — запустите");
    nt_add(n, "трассировку того же адреса здесь: будет видно, на");
    nt_add(n, "какой стадии всё останавливается (DNS/ARP/connect/приём).");
    nt_add(n, "");
    nt_add(n, "Пример (QEMU user-net, сервер на хосте):");
    nt_add(n, "  http://10.0.2.2:8080/");
    snprintf(n->status, sizeof(n->status),
             "Ctrl+L — адрес, G — повторить, Esc — выход");

    window_t *win = win_create("HTTP Trace", 60, 60, ww, wh,
                               nt_draw, nt_key, nt_mouse, NULL, nt_close, n);
    if (win) n->win = win;
}
