/* fat32_format.c — форматирование НЖМД в FAT32 (сессия 12, переработана 13).
 *
 * Сессия 12: superfloppy — загрузочный сектор, FSInfo, обе копии FAT
 * (обнуленные), корневой каталог. Данные пользователя НЕ затираются
 * физически, но становятся недоступны — в UI обязательное предупреждение.
 *
 * Сессия 13: ДВА РЕЖИМА (запрос пользователя):
 *   FAT32_FMT_QUICK — «быстрое»: только структуры ФС («оглавление»):
 *     загрузочный сектор + FSInfo + копии + FAT + корневой кластер.
 *     Содержимое диска не очищается (как «быстрое форматирование» Windows).
 *   FAT32_FMT_FULL — «полное»: то же + очистка НУЛЯМИ всей области данных
 *     (как полное форматирование; на больших дисках долго — прогресс-бар
 *     показывает продвижение).
 *
 * Сессия 13: запись ПАКЕТАМИ по 128 секторов (64 КиБ) — раньше FAT
 * обнулялся по одному сектору (2×fat_size одиночных команд записи:
 * на реальном диске это минуты). Теперь команд записи в 128 раз меньше;
 * AHCI: один PRDT-элемент описывает весь буфер (до 4 МиБ), ATA: PIO
 * многосекторная запись.
 *
 * Раскладка (superfloppy — вся плоскость диска, без MBR):
 *   LBA 0        — загрузочный сектор (BPB)
 *   LBA 1        — FSInfo
 *   LBA 2..5     — зарезервировано (нули)
 *   LBA 6        — копия загрузочного сектора
 *   LBA 7        — копия FSInfo
 *   LBA 8..31    — зарезервировано (нули)
 *   LBA 32       — FAT #1 (fat_size секторов)
 *   FAT #2       — сразу за первой копией
 *   данные       — cluster 2 = корневой каталог (один кластер нулей)
 */
#include "fat32_format.h"
#include "fat32.h"      /* FIX [FMT-DEINIT]: fat32_deinit перед форматом */
#include "disk.h"
#include "mem.h"
#include "string.h"
#include "task.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);

/* Размер пакета записи. 128 секторов = 64 КиБ; AHCI-путь принимает
 * до 128 (один PRDT на весь буфер), ATA-PIO — до 255. */
#define FMT_CHUNK 128

/* Выбор секторов на кластер (см. комментарий в шапке fat32.c). */
static u8 fmt_pick_spc(u32 total_secs)
{
    static const u8 spcs[] = { 1, 2, 4, 8, 16, 32 };
    u8 best = 32;
    for (int i = 0; i < 6; i++) {
        u32 clusters = total_secs / spcs[i];
        if (clusters >= 65525u && clusters <= 16u * 1024 * 1024)
            return spcs[i];
        if (clusters < 65525u)
            best = spcs[i];   /* слишком маленький диск — берём что есть */
    }
    return best;
}

/* Собрать загрузочный сектор FAT32 в buf[512]. */
static void fmt_build_boot(u8 *bs, u32 total_secs, u8 spc, u32 fat_size,
                           u32 vol_id)
{
    memset(bs, 0, 512);
    bs[0] = 0xEB; bs[1] = 0x58; bs[2] = 0x90;      /* jmp + nop */
    memcpy(bs + 3, "N2600OS", 8);                  /* OEM-имя */
    bs[11] = 0x00; bs[12] = 0x02;                  /* bytes/sector = 512 */
    bs[13] = spc;                                  /* sectors/cluster */
    bs[14] = 32; bs[15] = 0;                       /* reserved = 32 */
    bs[16] = 2;                                    /* FAT-копий: 2 */
    bs[17] = 0; bs[18] = 0;                        /* root entries (FAT32=0) */
    bs[19] = 0; bs[20] = 0;                        /* total16 = 0 */
    bs[21] = 0xF8;                                 /* media = HDD */
    bs[22] = 0; bs[23] = 0;                        /* fatsz16 = 0 */
    bs[24] = 0x3F; bs[25] = 0x00;                  /* sectors/track */
    bs[26] = 0xFF; bs[27] = 0x00;                  /* heads */
    bs[28] = 0; bs[29] = bs[30] = bs[31] = 0;      /* hidden = 0 (superfloppy) */
    bs[32] = (u8)(total_secs);                     /* total32 */
    bs[33] = (u8)(total_secs >> 8);
    bs[34] = (u8)(total_secs >> 16);
    bs[35] = (u8)(total_secs >> 24);
    bs[36] = (u8)(fat_size);                       /* fatsz32 */
    bs[37] = (u8)(fat_size >> 8);
    bs[38] = (u8)(fat_size >> 16);
    bs[39] = (u8)(fat_size >> 24);
    bs[40] = 0; bs[41] = 0;                        /* extflags: без зеркалирования */
    bs[42] = 0; bs[43] = 0;                        /* fsver = 0 */
    bs[44] = 2; bs[45] = 0; bs[46] = 0; bs[47] = 0;/* root cluster = 2 */
    bs[48] = 1; bs[49] = 0;                        /* FSInfo = LBA 1 */
    bs[50] = 6; bs[51] = 0;                        /* backup boot = LBA 6 */
    bs[64] = 0x80;                                 /* drive number (BIOS HDD) */
    bs[66] = 0x29;                                 /* extended boot signature */
    bs[67] = (u8)(vol_id);                         /* volume id */
    bs[68] = (u8)(vol_id >> 8);
    bs[69] = (u8)(vol_id >> 16);
    bs[70] = (u8)(vol_id >> 24);
    memcpy(bs + 71, "N2600-OS   ", 11);            /* метка тома */
    memcpy(bs + 82, "FAT32   ", 8);                /* тип ФС */
    bs[510] = 0x55; bs[511] = 0xAA;
}

/* Сектор FSInfo: количество свободных кластеров неизвестно (0xFFFFFFFF),
 * следующий свободный — 3 (корневой каталог 2, после него). */
static void fmt_build_fsinfo(u8 *fs)
{
    memset(fs, 0, 512);
    fs[0] = 0x52; fs[1] = 0x52; fs[2] = 0x64; fs[3] = 0x41;   /* "RRdA" */
    fs[484] = 0x72; fs[485] = 0x72; fs[486] = 0x41; fs[487] = 0x61; /* "rrAa" */
    fs[488] = 0xFF; fs[489] = 0xFF; fs[490] = 0xFF; fs[491] = 0xFF; /* free */
    fs[492] = 0x03; fs[493] = 0; fs[494] = 0; fs[495] = 0;    /* next free */
    fs[508] = 0x00; fs[509] = 0x00; fs[510] = 0x55; fs[511] = 0xAA;
}

/* FIX [FMT-OOB] (анализ task57): прежняя fmt_write_span(lba, n, buf)
 * передавала cnt (до 128) прямо в disk_hdd_write, которая читает
 * cnt*512 байт, а вызовы передавали 512-байтный буфер sec — OOB-чтение
 * до 64 КиБ за его пределами, на диск уходил мусор в reserved-секторах
 * (LBA 3..5, 9..31). Единственные вызовы писали нули — заменены на
 * fmt_zero_span (полный 64-килобайтный нулевой буфер + прогресс/yield);
 * функция удалена как мёртвая и опасная. */

/* Обнулить диапазон [lba, lba+n) пакетами по FMT_CHUNK секторов,
 * с отчётом прогресса: cb(done_out, total, ctx). */
static int fmt_zero_span(u32 lba, u32 n, u32 base_done, u32 total,
                         fat32_fmt_progress_t cb, void *ctx)
{
    /* нулевой буфер 64 КиБ (bss — не раздувает kernel.bin) */
    static u8 zbuf[FMT_CHUNK * 512];
    u32 done = 0;
    u32 chunks = 0;
    while (n > 0) {
        u32 cnt = (n > FMT_CHUNK) ? FMT_CHUNK : n;
        if (!disk_hdd_write(lba, (u8)cnt, zbuf)) return 0;
        lba += cnt;
        n -= cnt;
        done += cnt;
        chunks++;
        if (cb) cb(base_done + done, total, ctx);
        if ((chunks & 1023u) == 0) {
            /* диагностика больших очисток (сессия 13) */
            extern void serial_puts(const char *s);
            extern int  snprintf(char *o, u32 n, const char *fm, ...);
            char db[72];
            snprintf(db, sizeof(db), "[fmt] zero %u%%: %u/%u секторов\n",
                     (unsigned)(done * 100u / (done + n)),
                     (unsigned)done, (unsigned)(done + n));
            serial_puts(db);
        }
        if ((chunks & 7u) == 0)
            task_yield();          /* не душим систему на больших дисках */
    }
    return 1;
}

int fat32_format_hdd(fat32_fmt_progress_t cb, void *ctx, int full)
{
    if (!disk_hdd_present()) return FAT32_FMT_NO_DISK;
    /* FIX [FMT-DEINIT] (анализ task57): снять старое монтирование ДО
     * записи структур: раньше при неудачном форматировании том оставался
     * смонтированным со старым bpb/FAT-кэшем поверх полузаписанного
     * диска (дальнейшие операции писали по устаревшим адресам). Успешный
     * путь и так делает deinit+init (set_run_format), теперь безопасен
     * и неудачный. */
    fat32_deinit();
    u32 total = disk_hdd_sectors();
    if (total < 65525u + 64) return FAT32_FMT_TOO_SMALL;

    u8 spc = fmt_pick_spc(total);

    /* размер FAT с одной итерацией уточнения (кластеры зависят от
     * размера FAT, размер FAT — от кластеров; сходится за 2 шага) */
    u32 fat_size = 0;
    for (int it = 0; it < 4; it++) {
        u32 clusters = (total - 32 - 2 * fat_size) / spc;
        u32 need = (clusters * 4 + 511) / 512 + 2;
        if (need == fat_size) break;
        fat_size = need;
    }
    if (fat_size == 0 || 32 + 2 * fat_size + spc >= total)
        return FAT32_FMT_TOO_SMALL;

    char logb[96];
    snprintf(logb, sizeof(logb),
             "[fmt] FAT32 %s: %u секторов, spc=%u, FAT=%u секторов\r\n",
             full ? "полное" : "быстрое", (unsigned)total,
             (unsigned)spc, (unsigned)fat_size);
    serial_puts(logb);

    u32 vol_id = 0;
    extern u32 timer_ticks(void);
    vol_id = timer_ticks() * 2654435761u;

    static u8 sec[512];        /* общий буфер сектора (поток один) */
    u32 data_start = 32 + 2 * fat_size;

    /* объём работы для прогресса: метаданные (+ область данных, если полное) */
    u32 meta_secs = 32 + 2 * fat_size + spc;
    u32 data_secs = (full && total > data_start + spc)
                    ? (total - data_start - spc) : 0;
    u32 work_total = meta_secs + data_secs;
    u32 work_done = 0;
    if (cb) cb(0, work_total, ctx);

    /* --- загрузочный сектор + копия --- */
    fmt_build_boot(sec, total, spc, fat_size, vol_id);
    if (!disk_hdd_write(0, 1, sec)) return FAT32_FMT_IO_ERR;
    if (!disk_hdd_write(6, 1, sec)) return FAT32_FMT_IO_ERR;
    work_done += 2;
    if (cb) cb(work_done, work_total, ctx);

    /* --- FSInfo + копия --- */
    fmt_build_fsinfo(sec);
    if (!disk_hdd_write(1, 1, sec)) return FAT32_FMT_IO_ERR;
    if (!disk_hdd_write(7, 1, sec)) return FAT32_FMT_IO_ERR;
    work_done += 2;
    if (cb) cb(work_done, work_total, ctx);

    /* --- зарезервированные сектора (нули, пакетами) --- */
    /* FIX [FMT-OOB]: fmt_write_span(2,4,sec)/(8,24,sec) читали 4/24
     * сектора из 512-байтного буфера — заменены на fmt_zero_span. */
    if (!fmt_zero_span(2, 4, work_done, work_total, cb, ctx))
        return FAT32_FMT_IO_ERR;    /* 2..5 */
    if (!fmt_zero_span(8, 24, work_done, work_total, cb, ctx))
        return FAT32_FMT_IO_ERR;    /* 8..31 */
    work_done += 28;
    if (cb) cb(work_done, work_total, ctx);

    /* --- FAT-копии: первый сектор с записями 0..2, дальше нули пакетами --- */
    static u8 fat0[FMT_CHUNK * 512];
    memset(fat0, 0, sizeof(fat0));
    fat0[0] = 0xF8; fat0[1] = 0xFF; fat0[2] = 0xFF; fat0[3] = 0x0F; /* media */
    fat0[4] = 0xFF; fat0[5] = 0xFF; fat0[6] = 0xFF; fat0[7] = 0x0F; /* EOC */
    fat0[8] = 0xFF; fat0[9] = 0xFF; fat0[10] = 0xFF; fat0[11] = 0x0F;/* root=EOC */
    for (int copy = 0; copy < 2; copy++) {
        u32 base = 32 + (u32)copy * fat_size;
        if (!disk_hdd_write(base, 1, fat0)) return FAT32_FMT_IO_ERR;
        work_done += 1;
        /* остаток копии: [base+1, base+fat_size) — нули пакетами */
        if (fat_size > 1) {
            if (!fmt_zero_span(base + 1, fat_size - 1,
                               work_done, work_total, cb, ctx))
                return FAT32_FMT_IO_ERR;
        }
        work_done = 32 + (u32)copy * fat_size + fat_size;
        if (cb) cb(work_done, work_total, ctx);
    }

    /* --- корневой каталог: cluster 2 (spc секторов нулей) --- */
    if (!fmt_zero_span(data_start, spc, work_done, work_total, cb, ctx))
        return FAT32_FMT_IO_ERR;
    work_done += spc;
    if (cb) cb(work_done, work_total, ctx);

    /* --- ПОЛНОЕ: очистка всей области данных нулями --- */
    if (data_secs > 0) {
        if (!fmt_zero_span(data_start + spc, data_secs,
                           work_done, work_total, cb, ctx))
            return FAT32_FMT_IO_ERR;
        work_done += data_secs;
    }

    serial_puts("[fmt] FAT32: структуры записаны\r\n");
    return FAT32_FMT_OK;
}
