/* boot.c — самая ранняя часть ядра (Task 49; вынесена из kernel.c):
 * multiboot-заголовок, входная точка kstart, COM1-вывод и ранний
 * вывод на экран (VGA text + LFB) до инициализации fb/WM.
 * kernel.c остаётся: kmain, фоновые задачи, сидинг ramfs. */
#include "types.h"
#include "io.h"
#include "boot.h"
#include "string.h"
#include "font.h"
#include "timer.h"
#include "kernel.h"
#include "smp.h"        /* [SER-XCORE2]: smp_current_cpu для ser_xcore_cpu */

/* Символы linker-скрипта (COFF MinGW добавит ведущее подчёркивание сам). */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

/* --------------------- multiboot-заголовок --------------------- */

void kstart(void);

#define MB_FLAGS (MB_FLAG_ALIGN | MB_FLAG_MEMINFO | MB_FLAG_VIDEO_MODE | MB_FLAG_AOUT_KLUDGE)

/* При флаге VIDEO_MODE GRUB2 читает из заголовка ещё 4 поля (байты 32..47):
 * mode_type (0 = фреймбуфер), width, height, depth.
 * Устанавливаем width=height=depth=0 → GRUB выберет ЛЮБОЙ доступный
 * 32-битный VESA-режим из gfxpayload (см. grub.cfg). Это надёжнее, чем
 * хардкодить 1280x600 — на реальном железе такого режима может не быть. */
__attribute__((section(".text.mb"), used, aligned(4)))
static const u32 mb_header[12] = {
    MB_MAGIC,
    MB_FLAGS,
    (u32)(0u - (MB_MAGIC + MB_FLAGS)),
    (u32)(unsigned long)load_start,   /* header_addr */
    (u32)(unsigned long)load_start,   /* load_addr   */
    (u32)(unsigned long)load_end,     /* load_end_addr */
    (u32)(unsigned long)bss_end,      /* bss_end_addr */
    (u32)(unsigned long)kstart,       /* entry_addr  */
    0,                                /* mode_type: 0 = линейный фреймбуфер */
    0,                                /* width=0: GRUB выберет из gfxpayload */
    0,                                /* height=0 */
    0                                 /* depth=0 */
};

/* ------------------------- входная точка ------------------------- */

/* Единственная asm-вставка потока управления: настраиваем стек и зовём C.
 * naked обязателен — нельзя допустить пролог с обращением к стеку до его настройки. */
__attribute__((naked, section(".text.ks"), used, noinline))
void kstart(void)
{
    __asm__ __volatile__(
        "movl $_stack_top, %esp\n"
        "pushl %ebx\n"      /* multiboot info */
        "pushl %eax\n"      /* magic */
        "call _kmain\n"
        "1:\n"
        "hlt\n"
        "jmp 1b");
}

/* ========================================================================
 * Отладка: COM1 (serial) + экран (после fb_init)
 * ======================================================================== */

/* ---------- COM1 ---------- */
#define COM1 0x3F8

void serial_init(void)
{
    outb(COM1 + 1, 0x00);   /* отключить прерывания */
    outb(COM1 + 3, 0x80);   /* DLAB=1 */
    outb(COM1 + 0, 0x03);   /* делитель = 3 -> 38400 бод */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);   /* 8N1 */
    outb(COM1 + 2, 0xC7);   /* FIFO 14 байт, очистить */
    outb(COM1 + 4, 0x0B);   /* RTS/DSR */
}

void serial_putc(char c)
{
    /* СЕССИЯ 78 [SER-TMO]: раньше — вечный спин «ждём THR empty». Функцию
     * зовут из кода, держащего ядровый замок и cli (диагностика ватчдога,
     * klock/sync-логи): зависание UART-эмуляции намертво замораживало
     * ВСЮ систему (замок не отпускался, ватчдог стоял). Теперь дедлайн
     * по pit2 (реальное время, работает под cli): 100 мс — порт не
     * отвечает, байт бросаем, ядро живёт. */
    u32 dl = timer_poll_deadline();
    while (!(inb(COM1 + 5) & 0x20)) {
        if (timer_poll_expired(dl, 100000)) break;   /* >100 мс — сдаёмся */
    }
    outb(COM1, (u8)c);
}

/* [SER-XCORE] (сессия 79 + полевой лог VMware сессии 2): межъядерный
 * замок вывода в COM1 — ОДНА строка атомарна между ядрами. Вынесен
 * из serial_puts в файловую область: диагностика исключений
 * (panic_puts, idt.c) берёт его ОДНОЙ попыткой без спина —
 * перекрёстное смешивание байтов [exc]-строк с выводом задач
 * другого ядра исчезает, а тупик невозможен (занят = печатаем как
 * есть: держатель на этом же ядре возобновится только после
 * нашего возврата из исключения). */
static volatile int ser_xcore = 0;
/* [SER-XCORE2] (Task 52, полевой лог VMware 4 ядра): ядро-держатель.
 * Нужно для распознавания рекурсии (см. serial_puts): при cli-владении
 * «держатель на моём ядре, а я жду» возможен ТОЛЬКО рекурсивный вызов
 * (вытеснение держателя исключено — он держит замок под cli). */
static volatile int ser_xcore_cpu = -1;

void serial_puts(const char *s)
{
    /* Сессия 13: АТОМАРНАЯ печать строки. Раньше несколько потоков
     * печатали ПОСИМВОЛЬНО вперемешку (boot-лог и [term]-строки резались
     * друг по другу: "em]" вместо "[mem]") — тесты не находили свои
     * маркеры.
     *
     * СЕССИЯ 79 [SER-XCORE]: cli сериализует только СВОЁ ядро. При SMP
     * второе ядро писало в COM1 ПАРАЛЛЕЛЬНО — строки klock-ватчдога и
     * диагностики смешивались байтами (в логе пользователя: мусор
     * «[[klkoclko]c ...» = два «[klock] ОТБОР замка...» друг по друге).
     * Теперь: межъядерный cmpxchg-замок на строку.
     *
     * [SER-XCORE2] (Task 52, полевой лог VMware 4 ядра: «фоноЛsmp]»,
     * «²ая инициализация» — каша строк + спины ~1 с в IRQ0): cmpxchg
     * без cli оставлял держателя ВЫТЕСНЯЕМЫМ: IRQ0 того же ядра
     * прерывал задачу посреди строки, обработчик (балансировка smp,
     * ватчдог) звал serial_puts, не брал замок, крутился до 20М пауз
     * (~1 с тиков в пол!) и «печатал поверх» своей строки. Теперь
     * владение замком ВСЕГДА под cli (IF честно сохраняется — вызовы
     * из cli-контекстов не меняют состояние): держатель не вытесняется,
     * его строка дописывается до конца; ждущее ядро ждёт ровно реальное
     * время строки (~до 17 мс на 38400), а не таймаут. Спин оставлен
     * как страховка от умершего чужого держателя. cli-секция на длину
     * строки теряет тики (1000 Гц, строка ~17 мс ≈ до 16 тиков) — это
     * дешевле кашистого лога, недоставленных diag-строк и секундных
     * остановок IRQ0: сериальный вывод — диагностика, не хот-путь. */
    {
        int if_had;
        int my_cpu = smp_current_cpu();
        __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
        int expected = 0;
        __asm__ __volatile__("lock cmpxchgl %2, %0"
                             : "+m"(ser_xcore), "+a"(expected)
                             : "r"(1)
                             : "memory", "cc");
        int mine = (expected == 0);
        if (mine) ser_xcore_cpu = my_cpu;
        u32 spins = 0;
        while (!mine) {
            /* [SER-XCORE2]: владелец на СВОЁМ ядре при cli-владении =
             * рекурсивный вызов (держатель — мы же, глубже по стеку).
             * Спин был бы гарантированным таймаутом: печатаем как есть,
             * строка кашистая, но без ~1 с остановки ядра. */
            if (ser_xcore_cpu == my_cpu) break;
            if (++spins > 20000000u) break;      /* ~сек: сдаёмся */
            __asm__ __volatile__("pause" ::: "memory");
            expected = 0;
            __asm__ __volatile__("lock cmpxchgl %2, %0"
                                 : "+m"(ser_xcore), "+a"(expected)
                                 : "r"(1)
                                 : "memory", "cc");
            mine = (expected == 0);
            if (mine) ser_xcore_cpu = my_cpu;
        }

        while (*s) {
            if (*s == '\n') serial_putc('\r');
            serial_putc(*s++);
        }

        if (mine) {
            ser_xcore_cpu = -1;
            __asm__ __volatile__("movl $0, %0" : "=m"(ser_xcore) :: "memory");
        }
        if (if_had & 0x200)
            __asm__ __volatile__("sti" ::: "memory");
    }
}

/* [PANIC-SER] (полевой лог VMware, сессия 2): попытка межъядерной
 * атомарности для диагностики исключений БЕЗ спина и без риска
 * тупика (см. panic_puts в idt.c). 1 = замок наш (обязан вернуть
 * serial_xcore_rel). 0 = занят — печатать как есть. */
int serial_xcore_try(void)
{
    int expected = 0;
    __asm__ __volatile__("lock cmpxchgl %2, %0"
                         : "+m"(ser_xcore), "+a"(expected)
                         : "r"(1)
                         : "memory", "cc");
    if (expected == 0) {
        /* [SER-XCORE2]: держатель фиксируется и на паник-пути —
         * иначе рекурсивный serial_puts из паники не опознаёт
         * владельца как своё ядро и молотит 20М пауз под cli. */
        ser_xcore_cpu = smp_current_cpu();
        return 1;
    }
    return 0;
}

void serial_xcore_rel(void)
{
    ser_xcore_cpu = -1;
    __asm__ __volatile__("movl $0, %0" : "=m"(ser_xcore) :: "memory");
}


/* --------------------- ранний вывод (VGA text + LFB) --------------------- */

/* GRUB может выставить VESA-режим ДО прыжка в ядро. В этом случае
 * VGA-текстовый буфер 0xB8000 невидим — visible = linear framebuffer (LFB).
 * Поэтому ранний вывод идёт в ДВА места:
 *   1. VGA text buffer (0xB8000) — работает если GRUB оставил text mode
 *   2. LFB напрямую — работает если GRUB выставил VESA-режим
 * LFB-адрес берётся из multiboot info (framebuffer_addr).
 */

static volatile u16 * const vga_text = (volatile u16 *)0xB8000;
static int early_row = 0;
static int early_col = 0;

/* LFB info — заполняется в early_fb_init() из multiboot info */
static volatile u32 *early_lfb = NULL;
static u32 early_lfb_w = 0;
static u32 early_lfb_h = 0;
static u32 early_lfb_pitch = 0;
static u32 early_lfb_bpp = 0;

/* Инициализация раннего framebuffer-вывода из multiboot info.
 * Вызывается в самом начале kmain — ДО gdt_init. */
void early_fb_init(const mb_info_t *mb)
{
    if (!mb) return;
    if (!(mb->flags & MBIF_FRAMEBUFFER)) return;
    if (mb->framebuffer_type != MB_FT_RGB) return;
    if (mb->framebuffer_bpp < 16) return;
    if (!mb->framebuffer_addr || !mb->framebuffer_width) return;

    early_lfb = (volatile u32 *)(u32)mb->framebuffer_addr;
    early_lfb_w = mb->framebuffer_width;
    early_lfb_h = mb->framebuffer_height;
    early_lfb_pitch = mb->framebuffer_pitch;
    early_lfb_bpp = mb->framebuffer_bpp;
}

/* Нарисовать один пиксель в LFB. Цвет = 0x00RRGGBB (32-bit). */
static void early_fb_pixel(int x, int y, u32 color)
{
    if (!early_lfb || x < 0 || y < 0 ||
        (u32)x >= early_lfb_w || (u32)y >= early_lfb_h) return;

    if (early_lfb_bpp == 32) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 4;
        dst[off]     = (u8)(color);        /* B */
        dst[off+1]   = (u8)(color >> 8);   /* G */
        dst[off+2]   = (u8)(color >> 16);  /* R */
    }
    else if (early_lfb_bpp == 24) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 3;
        dst[off]     = (u8)(color);
        dst[off+1]   = (u8)(color >> 8);
        dst[off+2]   = (u8)(color >> 16);
    }
    else if (early_lfb_bpp == 16) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 2;
        u8 r = (u8)((color >> 16) & 0xFF);
        u8 g = (u8)((color >> 8) & 0xFF);
        u8 b = (u8)(color & 0xFF);
        u16 c = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
        dst[off] = (u8)(c & 0xFF);
        dst[off+1] = (u8)((c >> 8) & 0xFF);
    }
}

/* Нарисовать один символ 8x16 в LFB. */
static void early_fb_char(int x, int y, char c, u32 fg, u32 bg)
{
    if (!early_lfb) return;
    if (c < 0x20 || c > 0x7E) c = '?';
    const unsigned char *glyph = font8x16[(int)c - 0x20];
    for (int row = 0; row < 16; row++) {
        unsigned char bits = glyph[row];
        for (int col = 0; col < 8; col++) {
            u32 color = (bits & (0x80 >> col)) ? fg : bg;
            early_fb_pixel(x + col, y + row, color);
        }
    }
}

/* Очистить экран: заполнить LFB одним цветом + VGA text буфер. */
void early_clear(void)
{
    /* VGA text buffer */
    for (int i = 0; i < 80 * 25; i++) vga_text[i] = 0x1F00u;
    early_row = 0;
    early_col = 0;

    /* LFB */
    if (early_lfb) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 total = early_lfb_h * early_lfb_pitch;
        /* Цвет фона: ЧЁРНЫЙ (сессия 56: пользователь просил заливать
         * весь экран чёрным, т.к. лог пишется поверх мусора от GRUB;
         * тёмно-синий 0x000028 меняли на чистый чёрный) */
        u8 b = 0x00, g = 0x00, r = 0x00;
        if (early_lfb_bpp == 32) {
            for (u32 i = 0; i + 3 < total; i += 4) {
                dst[i] = b; dst[i+1] = g; dst[i+2] = r; dst[i+3] = 0;
            }
        }
        else if (early_lfb_bpp == 24) {
            for (u32 i = 0; i + 2 < total; i += 3) {
                dst[i] = b; dst[i+1] = g; dst[i+2] = r;
            }
        }
        else if (early_lfb_bpp == 16) {
            u16 c = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
            for (u32 i = 0; i + 1 < total; i += 2) {
                dst[i] = (u8)(c & 0xFF);
                dst[i+1] = (u8)((c >> 8) & 0xFF);
            }
        }
    }
}

/* Вывести строку в ОБА буфера: VGA text + LFB. */
#define EARLY_FG 0x00FFFF00u   /* жёлтый текст */
#define EARLY_BG 0x00000000u   /* сессия 56: ЧЁРНЫЙ фон (был тёмно-синий) */

/* Прокрутить ранний LFB-экран на одну текстовую строку (16 px) вверх.
 * Работает при любом bpp (16/24/32): строка = early_lfb_pitch байт. */
static void early_fb_scroll(void)
{
    if (!early_lfb) return;
    u32 shift = 16u * early_lfb_pitch;
    u32 total = early_lfb_h * early_lfb_pitch;
    if (shift >= total) return;
    volatile u8 *base = (volatile u8 *)early_lfb;
    for (u32 i = 0; i < total - shift; i++) base[i] = base[i + shift];
    /* нижние 16 строк — цвет фона раннего вывода (сессия 56: чёрный) */
    int bppb = (int)(early_lfb_bpp / 8);
    if (bppb < 2) bppb = 2;
    for (u32 i = total - shift; i + 2 < total; i += (u32)bppb) {
        base[i]     = 0x00;   /* B */
        base[i + 1] = 0x00;   /* G */
        base[i + 2] = 0x00;   /* R */
        if (bppb == 4) base[i + 3] = 0;
    }
}

/* Последняя видимая текстовая строка: VGA — 25, LFB может быть меньше
 * (например 600px / 16 = 37 → ограничиваем 25, чтобы оба буфера
 * прокручивались синхронно одним счётчиком early_row). */
static int early_max_row(void)
{
    int mr = 25;
    if (early_lfb && early_lfb_h >= 48) {
        int lr = (int)(early_lfb_h / 16) - 1;
        if (lr < mr) mr = lr;
    }
    return mr;
}

/* Перевод строки ранней консоли: скролл обоих буферов при выходе
 * за последнюю строку (раньше LFB просто переставал рисовать —
 * «начальный лог уходит за низ экрана» в VESA-режиме GRUB). */
static void early_nl(void)
{
    early_col = 0;
    early_row++;
    int mr = early_max_row();
    if (early_row >= mr) {
        /* VGA text buffer */
        for (int i = 0; i < 80 * 24; i++)
            vga_text[i] = vga_text[i + 80];
        for (int i = 80 * 24; i < 80 * 25; i++)
            vga_text[i] = 0x1F00u;
        /* LFB */
        early_fb_scroll();
        early_row = mr - 1;
    }
}

void early_puts(const char *s)
{
    while (*s) {
        char c = *s++;

        /* --- перевод строки: оба буфера + прокрутка --- */
        if (c == '\n') {
            early_nl();
            continue;
        }
        if (early_col >= 80) {
            early_nl();
        }

        vga_text[early_row * 80 + early_col] = (u16)(0x1F00u | (u8)c);

        /* --- LFB (если доступен) --- */
        if (early_lfb && early_lfb_w >= 8) {
            int x = early_col * 8;
            int y = early_row * 16;
            early_fb_char(x, y, c, EARLY_FG, EARLY_BG);
        }

        early_col++;
    }
}

void early_putc(char c)
{
    char buf[2] = { c, 0 };
    early_puts(buf);
}

void early_putu(u32 v)
{
    char buf[12];
    int i = 0;
    if (v == 0) { early_putc('0'); return; }
    while (v) { buf[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) early_putc(buf[i]);
}

void early_puthex(u32 v)
{
    const char *h = "0123456789ABCDEF";
    early_puts("0x");
    for (int i = 28; i >= 0; i -= 4)
        early_putc(h[(v >> i) & 0xF]);
}

void vga_fail(const char *msg)
{
    /* serial — первым делом */
    serial_puts("[FATAL] ");
    serial_puts(msg);
    serial_puts("\n");

    /* Ранний вывод в VGA + LFB */
    early_clear();
    early_puts("=== N2600-OS FATAL ===\n");
    early_puts(msg);
    early_puts("\n\nSystem halted.");

    /* QEMU debug port */
    for (const char *p = msg; *p; p++) outb(0xE9, (u8)*p);

    for (;;)
        hlt();
}
