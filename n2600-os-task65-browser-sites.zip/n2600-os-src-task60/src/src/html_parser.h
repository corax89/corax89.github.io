/* html_parser.h — простой потоковый HTML-парсер с низким потреблением
 * памяти (восстановленный заголовок по html_parser.c; в архиве task59
 * файл отсутствовал).
 *
 * Архитектура (см. html_parser.c):
 *   - html_parse_begin()      — создать состояние парсера;
 *   - html_parse_stream()     — скормить кусок HTML (можно весь сразу);
 *   - html_parse_end()        — завершить: получить HtmlDocument (DOM);
 *   - html_free_document()    — освободить дерево.
 *
 * Дерево: каждый элемент — HtmlElement (tag + атрибуты + text + дети/
 * соседи). Текстовые узлы имеют tag == HTML_TAG_NONE и заполненный text.
 * <script> даёт элемент с ОДНИМ текстовым ребёнком — СЫРОЙ код без
 * декодирования entities (нужно конвертеру htmlconv.c). <style> и
 * <template> пропускаются целиком (см. skip_raw_content).
 *
 * Зависимости в ядре: mem.h (malloc/free), string.h (snprintf и пр.),
 * types.h — всё шимится внутри html_parser.c при сборке без HOST_TEST.
 */
#ifndef HTML_PARSER_H
#define HTML_PARSER_H

#ifdef __cplusplus
extern "C" {
#endif

/* Task 60 [HP-KERNEL]: в freestanding-ядре size_t нет — на i686 он
 * совпадает с u32 (unsigned int), как и mq_size_t в string.h. */
#ifdef HOST_TEST
#include <stddef.h>
#else
#include "types.h"
typedef u32 size_t;
#endif

/* ---------------- типы тегов ---------------- */

typedef enum {
    HTML_TAG_NONE = 0,      /* текстовый узел (только text) */
    HTML_TAG_UNKNOWN,
    HTML_TAG_HTML, HTML_TAG_HEAD, HTML_TAG_TITLE, HTML_TAG_BODY,
    HTML_TAG_DIV, HTML_TAG_SPAN, HTML_TAG_P, HTML_TAG_BR, HTML_TAG_HR,
    HTML_TAG_H1, HTML_TAG_H2, HTML_TAG_H3, HTML_TAG_H4, HTML_TAG_H5,
    HTML_TAG_H6,
    HTML_TAG_A, HTML_TAG_IMG,
    HTML_TAG_TABLE, HTML_TAG_THEAD, HTML_TAG_TBODY, HTML_TAG_TFOOT,
    HTML_TAG_TR, HTML_TAG_TD, HTML_TAG_TH,
    HTML_TAG_UL, HTML_TAG_OL, HTML_TAG_LI,
    HTML_TAG_FORM, HTML_TAG_INPUT, HTML_TAG_BUTTON, HTML_TAG_SELECT,
    HTML_TAG_OPTION, HTML_TAG_TEXTAREA,
    HTML_TAG_SCRIPT, HTML_TAG_STYLE, HTML_TAG_LINK, HTML_TAG_META,
    HTML_TAG_PRE, HTML_TAG_CODE, HTML_TAG_BLOCKQUOTE, HTML_TAG_ADDRESS,
    HTML_TAG_STRONG, HTML_TAG_EM, HTML_TAG_B, HTML_TAG_I, HTML_TAG_U,
    HTML_TAG_S, HTML_TAG_SUB, HTML_TAG_SUP,
    HTML_TAG_LABEL, HTML_TAG_CANVAS, HTML_TAG_IFRAME,
    HTML_TAG_KBD, HTML_TAG_VAR, HTML_TAG_SAMP, HTML_TAG_ABBR,
    HTML_TAG_CITE, HTML_TAG_Q, HTML_TAG_DFN, HTML_TAG_SMALL,
    HTML_TAG_BIG, HTML_TAG_DEL, HTML_TAG_INS, HTML_TAG_CENTER,
    HTML_TAG_FONT, HTML_TAG_BASE, HTML_TAG_NOSCRIPT,
    HTML_TAG_DT, HTML_TAG_DD,
    HTML_TAG_HEADER, HTML_TAG_FOOTER, HTML_TAG_NAV, HTML_TAG_MAIN,
    HTML_TAG_SECTION, HTML_TAG_ARTICLE, HTML_TAG_ASIDE,
    HTML_TAG_FIGURE, HTML_TAG_FIGCAPTION,
    HTML_TAG_DETAILS, HTML_TAG_SUMMARY, HTML_TAG_OBJECT,
    HTML_TAG_SVG, HTML_TAG_RECT, HTML_TAG_CIRCLE, HTML_TAG_ELLIPSE,
    HTML_TAG_LINE, HTML_TAG_POLYLINE, HTML_TAG_POLYGON, HTML_TAG_PATH,
    HTML_TAG_G, HTML_TAG_TEXT, HTML_TAG_TSPAN, HTML_TAG_DEFS,
    HTML_TAG_USE
} HtmlTag;

/* ---------------- типы атрибутов ---------------- */

typedef enum {
    HTML_ATTRIB_NONE = 0,
    HTML_ATTRIB_CUSTOM,     /* имя не из таблицы — см. key_name */
    HTML_ATTRIB_ID, HTML_ATTRIB_CLASS, HTML_ATTRIB_STYLE,
    HTML_ATTRIB_HREF, HTML_ATTRIB_SRC,
    HTML_ATTRIB_ONCLICK, HTML_ATTRIB_ONLOAD, HTML_ATTRIB_ONERROR,
    HTML_ATTRIB_WIDTH, HTML_ATTRIB_HEIGHT, HTML_ATTRIB_ALT,
    HTML_ATTRIB_TITLE, HTML_ATTRIB_TYPE, HTML_ATTRIB_NAME,
    HTML_ATTRIB_VALUE, HTML_ATTRIB_PLACEHOLDER, HTML_ATTRIB_DISABLED,
    HTML_ATTRIB_CHECKED, HTML_ATTRIB_SELECTED, HTML_ATTRIB_MULTIPLE,
    HTML_ATTRIB_SIZE, HTML_ATTRIB_MAXLENGTH, HTML_ATTRIB_MIN,
    HTML_ATTRIB_MAX, HTML_ATTRIB_STEP, HTML_ATTRIB_ROWS,
    HTML_ATTRIB_COLS, HTML_ATTRIB_COLSPAN, HTML_ATTRIB_ROWSPAN,
    HTML_ATTRIB_BORDER, HTML_ATTRIB_CELLPADDING, HTML_ATTRIB_CELLSPACING,
    HTML_ATTRIB_ALIGN, HTML_ATTRIB_VALIGN, HTML_ATTRIB_BGCOLOR,
    HTML_ATTRIB_COLOR, HTML_ATTRIB_REL, HTML_ATTRIB_CONTENT,
    HTML_ATTRIB_CHARSET, HTML_ATTRIB_HTTP_EQUIV, HTML_ATTRIB_TARGET,
    HTML_ATTRIB_DOWNLOAD, HTML_ATTRIB_ACTION, HTML_ATTRIB_METHOD,
    HTML_ATTRIB_DATA
} HtmlAttribKey;

/* ---------------- отображение по умолчанию ---------------- */

enum { DISPLAY_INLINE = 0, DISPLAY_BLOCK = 1 };

/* ---------------- структуры ---------------- */

typedef struct HtmlAttrib {
    HtmlAttribKey  key;
    char          *key_name;   /* для HTML_ATTRIB_CUSTOM (malloc) */
    char          *value;      /* уже с декодированными entities */
    void          *user_data;
    struct HtmlAttrib *next;
} HtmlAttrib;

typedef struct HtmlElement {
    HtmlTag       tag;         /* HTML_TAG_NONE = текстовый узел */
    char         *id;          /* значение атрибута id (или NULL) */
    char         *text;        /* текст узла (malloc) или NULL */
    HtmlAttrib   *attrib;      /* список атрибутов */
    struct HtmlElement *parent;
    struct HtmlElement *child;   /* первый ребёнок */
    struct HtmlElement *sibling; /* следующий сосед */
    int           display;     /* DISPLAY_INLINE / DISPLAY_BLOCK */
} HtmlElement;

typedef struct HtmlDocument {
    HtmlElement *root_element;   /* виртуальный корень */
} HtmlDocument;

/* Состояние потокового парсера (опакечено: определено в .c) */
typedef struct HtmlParseState HtmlParseState;

/* ---------------- API ---------------- */

/* Потоковый разбор: begin -> stream(*) -> end. buffer — владелец
 * входного потока для zero-copy (можно NULL: конвертер кладёт NULL). */
HtmlParseState* html_parse_begin(void);
void            html_parse_stream(HtmlParseState *state, char *buffer,
                                  const char *data, size_t len);
HtmlDocument*   html_parse_end(HtmlParseState *state);
void            html_free_document(HtmlDocument *doc);

/* Утилиты над деревом */
HtmlElement*    html_find_element(HtmlElement *element, const char *id);
void            html_free_element(HtmlElement *el);

/* Конструкторы (используются парсером; оставлены публичными как в
 * исходном API) */
HtmlElement*    html_new_element(HtmlTag tag, HtmlElement *parent,
                                 const char *id, const char *text,
                                 HtmlAttrib *attrib, HtmlElement *sibling);
HtmlAttrib*     html_new_attrib(HtmlAttribKey key, const char *key_name,
                                const char *value);
void            html_free_attribs(HtmlAttrib *attrib);

/* Декодировать entities в строке in-place (&amp; &#NN; &#xNN; и таблица
 * именных: copy, nbsp, mdash...). Возвращает новую длину. */
int             html_decode_entities(char *str);

/* Имя тега <-> enum (без регистра) */
HtmlTag         html_tag_from_string(const char *name, int len);
const char*     html_tag_to_string(HtmlTag tag);
HtmlAttribKey   html_attrib_key_from_string(const char *name, int len);
int             html_tag_is_void(HtmlTag tag);
int             html_tag_is_inline(HtmlTag tag);

/* Отладочные (в production — заглушки) */
int             html_count_elements(HtmlElement *el);
int             html_count_text_nodes(HtmlElement *el);
void            html_print_tree(HtmlElement *el, int indent);
void            html_dump_tree(HtmlElement *el);

#ifdef __cplusplus
}
#endif

#endif /* HTML_PARSER_H */
