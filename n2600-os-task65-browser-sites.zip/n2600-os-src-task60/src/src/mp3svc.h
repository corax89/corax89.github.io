/* mp3svc.h — сервис MP3-декодирования N2600-OS (сессия 60).
 *
 * Обёртка над dr_mp3 (src/dr_mp3.h, вендор dr_libs v0.7.4) — ОСНОВНАЯ
 * библиотека декодирования MP3 для всех приложений:
 *   - нативный MP3-плеер (apps_mp3.c);
 *   - kapi-функции mp3_* — приложения c4/CMScript (буфер контекста
 *     malloc'ится через kapi->malloc размера MP3_CTX_SIZE);
 *   - будущие приложения.
 *
 * Всё декодирование выполняется под общим FPU-локом imgsvc
 * (внутренний синтезатор dr_mp3 — float, планировщик не сохраняет x87).
 * Вход — целиком файл в памяти (malloc); dr_mp3 читает по месту,
 * без копий. */
#ifndef MP3SVC_H
#define MP3SVC_H

#include "types.h"

/* Opaque-контекст drmp3: приложения выделяют буфер такого размера
 * (kapi->malloc) и передают его во все mp3_*-функции. sizeof(drmp3)
 * проверяется STATIC_ASSERT-ом в mp3svc.c. */
#define MP3_CTX_SIZE  33024
#define MP3_CTX_ALIGN 8

/* Открыть MP3 из памяти (data остаётся владельцем буфера и должен
 * жить, пока контекст открыт). 1 = успех. */
int  mp3_open_mem(const void *data, u32 len, void *ctx);

/* Закрыть контекст (без освобождения ctx — его освобождает владелец). */
void mp3_close(void *ctx);

u32  mp3_channels(const void *ctx);     /* 1..2 */
u32  mp3_rate(const void *ctx);         /* Гц, обычно 44100 */

/* Позиция в PCM-фреймах от начала. */
u64  mp3_tell(const void *ctx);

/* Позиционирование (фрейм от начала). 1 = успех. */
int  mp3_seek(void *ctx, u64 frame);

/* Читать PCM-фреймы: s16 interleaved, channels каналов на фрейм.
 * Возвращает число прочитанных фреймов (0 = конец/ошибка). */
u32  mp3_read_s16(void *ctx, i16 *pcm, u32 frames);

/* Длительность в PCM-фреймах: точный проход по заголовкам MPEG-кадров
 * (файл в памяти; CBR и VBR — одинаково точно). 0 = кадры не найдены. */
u64  mp3_total_frames_estimate(const void *ctx);

/* Текст последней ошибки (для сообщений в UI). */
const char *mp3_errstr(void);

/* ---------- kapi-обёртки (сессия 60) ----------
 * u32-интерфейс для приложений c4/CMScript (см. kapi.h, поля mp3_*).
 * Отличия от прямого API: позиция/total — u32 (хватает на ~27 часов
 * аудио), seek/total — код результата и оценка в фреймах. */
int  kapi_mp3_open_mem(const void *data, u32 len, void *ctx);
void kapi_mp3_close(void *ctx);
u32  kapi_mp3_channels(const void *ctx);
u32  kapi_mp3_rate(const void *ctx);
u32  kapi_mp3_read_s16(void *ctx, i16 *pcm, u32 frames);
u32  kapi_mp3_seek(void *ctx, u32 frame);
u32  kapi_mp3_total(const void *ctx);

#endif /* MP3SVC_H */
