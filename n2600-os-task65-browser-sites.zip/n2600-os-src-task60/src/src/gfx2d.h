/* gfx2d.h — общий слой графики.
 *
 * СЕССИЯ 90: 2D/3D-ускорение снято по запросу пользователя (SGX-эксперименты
 * на X101CH давали чёрный экран с перезагрузкой; Voodoo3-ускорение решено
 * убрать). Отрисовка — программная compose-модель fb.c + WC MTRR; курсор —
 * программный (wm.c).
 *
 * API курсора оставлен no-op'ами: wm.c вызывает его безусловно, а
 * gfx2d_cursor_ready() == 0 включает программный путь. */
#ifndef GFX2D_H
#define GFX2D_H

#include "types.h"

/* Аппаратный курсор активен? Всегда 0 — wm.c рисует программный курсор. */
int  gfx2d_cursor_ready(void);
void gfx2d_cursor_move(int x, int y);   /* no-op */
void gfx2d_cursor_show(int on);         /* no-op */

/* Имя GPU/статус рендера для «Системной информации» (статический буфер). */
const char *gfx2d_gpu_info(void);

#endif /* GFX2D_H */
