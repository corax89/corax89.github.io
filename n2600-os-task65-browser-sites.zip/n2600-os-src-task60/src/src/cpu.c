/* cpu.c — CPUID-диспетчер N2600-OS: детекция возможностей CPU и включение
 * FPU/SSE (см. cpu.h — трёхуровневый SIMD-план).
 *
 * Почему это нужно именно ядром:
 *  - fb.c получил SSE2-ветки (fill32/copy/blit_row_wc с movntdq) — xmm-состояние
 *    обязано переживать вытеснение: планировщик делает fxsave/fxrstor (task.c);
 *  - fxsave/fxrstor и SSE2-инструкции требуют CR4.OSFXSR=1 (иначе #UD / XMM
 *    не сохраняются), x87 требует CR0.EM=0/TS=0 — выставляем на КАЖДОМ ядре
 *    (CR4 per-CPU: BSP в cpu_detect, AP в smp_ap_main -> cpu_fpu_enable);
 *  - задачи, ещё ни разу не исполнявшиеся, не могут fxrstor-ить нули
 *    (MXCSR=0 невалиден) — cpu_detect захватывает дефолтное состояние
 *    (fninit + MXCSR=0x1F80) и раздаёт его планировщиком.
 */
#include "cpu.h"
#include "types.h"
#include "string.h"     /* memcpy */
#include "kernel.h"     /* klog_puts */
#include <cpuid.h>

extern void serial_puts(const char *s);

int cpu_has_fpu  = 0;
int cpu_has_fxsr = 0;
int cpu_has_sse  = 0;
int cpu_has_sse2 = 0;

/* Дефолтное FPU-состояние (fxsave-образ = 512 байт, fnsave-образ занимает
 * первые 108). Выравнивание 16 обязательно для fxsave/fxrstor (#GP иначе). */
static u8 g_fpu_default[512] __attribute__((aligned(16)));
static int g_fpu_default_ok = 0;
static const u32 g_mxcsr_default = 0x1F80u;   /* все исключения замаскированы */

void cpu_fpu_default_get(u8 *dst512)
{
    if (dst512 && g_fpu_default_ok)
        memcpy(dst512, g_fpu_default, 512);
}

int cpu_fpu_default_ready(void)
{
    return g_fpu_default_ok;
}

/* Включить FPU/SSE на ТЕКУЩЕМ ядре (см. cpu.h). */
void cpu_fpu_enable(void)
{
    u32 cr0, cr4;

    /* CR0: TS=0 (без #NM), EM=0 (x87 не эмулируется, а исполняется),
     * MP=1 (FWAIT уважает TS — на будущее), ET=1 (сопроцессор есть). */
    __asm__ __volatile__("movl %%cr0, %0" : "=r"(cr0) :: "memory");
    cr0 &= ~(1u << 2);          /* ~TS */
    cr0 &= ~(1u << 3);          /* ~EM */
    cr0 |=  (1u << 1);          /* MP  */
    cr0 |=  (1u << 4);          /* ET  */
    __asm__ __volatile__("movl %0, %%cr0" :: "r"(cr0) : "memory");

    /* CR4.OSFXSR (бит 9): fxsave/fxrstor сохраняют/восстанавливают XMM,
     * SSE/SSE2-инструкции не дают #UD. OSXMMEXCPT (бит 10): вектор #XM
     * легален (наши MXCSR всегда с замаскированными исключениями, но
     * выставим честно — так требует SDM для ОС, использующей SSE). */
    if (cpu_has_fxsr) {
        __asm__ __volatile__("movl %%cr4, %0" : "=r"(cr4) :: "memory");
        cr4 |= (1u << 9);
        cr4 |= (1u << 10);
        __asm__ __volatile__("movl %0, %%cr4" :: "r"(cr4) : "memory");
    }
}

void cpu_detect(void)
{
    u32 a, b, c, d;
    char buf[64];

    /* CPUID нет (ранние 486 и хуже) — уровень 0, всё как раньше */
    if (!__get_cpuid(0, &a, &b, &c, &d)) {
        serial_puts("[cpu] CPUID недоступен: скалярный путь\n");
        klog_puts("cpu: CPUID нет — уровень 0 (скаляр)");
        return;
    }
    if (a < 1) {
        serial_puts("[cpu] leaf 1 нет: скалярный путь\n");
        return;
    }
    if (!__get_cpuid(1, &a, &b, &c, &d))
        return;

    cpu_has_fpu  = (int)((d >> 0)  & 1u);
    cpu_has_fxsr = (int)((d >> 24) & 1u);
    cpu_has_sse  = (int)((d >> 25) & 1u);      /* уровень 1 */
    cpu_has_sse2 = (int)((d >> 26) & 1u);      /* уровень 2 */

    /* Включить на BSP + захватить дефолтное состояние для новых задач */
    if (cpu_has_fpu)
        cpu_fpu_enable();

    if (cpu_has_fxsr) {
        __asm__ __volatile__("fninit");
        if (cpu_has_sse)
            __asm__ __volatile__("ldmxcsr %0" :: "m"(g_mxcsr_default) : "memory");
        __asm__ __volatile__("fxsave %0" : "=m"(g_fpu_default) :: "memory");
        g_fpu_default_ok = 1;
    } else if (cpu_has_fpu) {
        /* fnsave-образ: 108 байт x87-состояния (fninit уже сделал сброс) */
        __asm__ __volatile__("fninit");
        __asm__ __volatile__("fnsave %0" : "=m"(g_fpu_default) :: "memory");
        g_fpu_default_ok = 1;
    }

    /* В dmesg/serial видно, какой путь выбран (уровень 0/1/2) */
    snprintf(buf, sizeof(buf),
             "cpu: fpu=%d fxsr=%d sse=%d sse2=%d — уровень %s",
             cpu_has_fpu, cpu_has_fxsr, cpu_has_sse, cpu_has_sse2,
             cpu_has_sse2 ? "2 (SSE2)" : (cpu_has_sse ? "1 (SSE)" : "0"));
    serial_puts("[cpu] ");
    serial_puts(buf + 5);   /* без префикса "cpu: " в serial */
    serial_puts("\n");
    klog_puts(buf);
}
