/* gma3600.h — нативная инициализация дисплея GMA3600 (Cedarview, CDV)
 * на нетбуках Atom D2xxx/N2xxx: 1024x600 на LVDS-панели.
 *
 * Эталон: Linux gma500 (GPL-2.0): cdv_intel_display.c, psb_intel_reg.h,
 * cdv_device.c, gma_display.c, drm_modes.c (GTF). Все адреса/биты/порядок
 * записи сверены с деревом v6.1 (см. комментарии в gma3600.c).
 *
 * Вызывается из kmain ПОСЛЕ fb_init (режим загрузчика GRUB/VBE уже
 * отображается) и ДО mtrr_lfb_wc/fb_make_bg. При любой неудаче (нет
 * устройства, DPLL не захватился) драйвер восстанавливает ВСЕ
 * затронутые регистры и возвращает 0 — ОС остаётся на режиме
 * загрузчика (например 800x600 от VBE), деградации нет.
 */
#ifndef GMA3600_H
#define GMA3600_H

#include "types.h"
#include "boot.h"

/* Вернуть 1 = режим переключён (out_* заполнены новой геометрией),
 * 0 = переключение не состоялось (остаёмся на режиме загрузчика).
 * out_w/out_h/out_pitch допускается NULL. */
int  gma3600_init(const mb_info_t *mb, u32 *out_w, u32 *out_h, u32 *out_pitch);

/* Последняя строка состояния (для dbg/лога в kmain). */
const char *gma3600_status(void);

#endif /* GMA3600_H */
