/* net.c — минимальный TCP/IP стек для N2600-OS.
 *
 * Реализация: Ethernet + ARP + IPv4 + ICMP.
 *
 * Драйвер NIC абстрагирован: сетевой цикл читает пакеты из e1000_recv()
 * и передаёт сюда в net_poll(). Отправка идёт через e1000_send().
 *
 * Кэш ARP хранит 16 записей (IP->MAC). При отсутствии записи в кэше
 * отправляется ARP-запрос и пакет ставится на паузу (для простоты — просто
 * теряется, в однозадачной системе повторяется вызывающим).
 *
 * Чек-суммы IP/ICMP — простые 16-битные над IP-заголовком/ICMP.
 *
 * Сессия 12 (стабильность IP при DHCP): у стека появился «транзакционный»
 * режим DHCP (net_dhcp_txn_begin/end): на время DISCOVER/REQUEST исходящий
 * IP-адрес считается 0.0.0.0 (как требует RFC 2131 фаза INIT), но
 * g_net.ip — видимый приложениям/Настройкам адрес — НЕ обнуляется.
 * Раньше каждые ~5 с повтор DHCP стирал IP: «адрес теряется каждые
 * несколько секунд». Теперь адрес остаётся до успешной замены/сброса.
 */
#include "net.h"
#include "net_tcp.h"      /* TCP-слой: net_tcp.c; общие внутренности */
#include "sync.h"
#include "e1000.h"
#include "ne2000.h"
#include "virtio_net.h"
#include "atl1c.h"
#include "ath9k_wifi.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);

/* ---------- Реестр NIC-адаптеров (сессия 11) ----------
 * Раньше активный NIC выбирался ЖЁСТКО: e1000 → virtio → ne2000 → atl1c,
 * а WiFi вообще не участвовал. На X101CH это давало «приоритет у lan,
 * хотя он никуда не подключен»: стек сидел на atl1c без линка, а WiFi
 * не мог получить IP. Теперь все NIC регистрируются в реестре, а выбор
 * идёт по СОСТОЯНИЮ ЛИНКА: ethernet с линком > WiFi (ассоциирован) >
 * первый найденный. Ручной выбор (Настройки/терминал) перекрывает авто. */
typedef int (*nic_send_fn)(const void *buf, u32 len);
typedef u32 (*nic_recv_fn)(void *buf, u32 max);
typedef int (*nic_link_fn)(void);
typedef void (*nic_mac_fn)(u8 *);

/* get_mac у драйверов возвращает разное (int/void) — выравниваем
 * сигнатуры обёртками, чтобы реестр был однородным. */
static void nm_e1000_mac(u8 *m)  { e1000_get_mac(m); }
static void nm_virtio_mac(u8 *m) { virtio_net_get_mac(m); }
static void nm_ne2000_mac(u8 *m) { ne2000_get_mac(m); }
static void nm_atl1c_mac(u8 *m)  { atl1c_get_mac(m); }
static void nm_wifi_mac(u8 *m)   { wifi_net_get_mac(m); }

typedef struct {
    const char *name;         /* имя в Настройках/терминале */
    nic_send_fn send;
    nic_recv_fn recv;
    nic_link_fn link;         /* NULL = линк всегда есть (эмулированные) */
    nic_mac_fn  get_mac;
    int wired;                /* 1 = ethernet: приоритет при равном линке */
} net_nic_def_t;

#define NET_MAX_NICS 5
static const net_nic_def_t g_nic_defs[NET_MAX_NICS] = {
    { "e1000",  e1000_send,     e1000_recv,     e1000_link_up,  nm_e1000_mac,  1 },
    { "virtio", virtio_net_send,virtio_net_recv,NULL,           nm_virtio_mac, 1 },
    { "ne2000", ne2000_send,    ne2000_recv,    NULL,           nm_ne2000_mac, 1 },
    { "atl1c",  atl1c_send,     atl1c_recv,     atl1c_link_up,  nm_atl1c_mac,  1 },
    { "wifi",   wifi_net_send,  wifi_net_recv,  wifi_net_link,  nm_wifi_mac,   0 },
};

static int g_nic_present[NET_MAX_NICS];    /* найден при init */
static int g_nic_count = 0;
static int g_active = -1;                  /* индекс активного адаптера */
static nic_send_fn g_nic_send = NULL;
static nic_recv_fn g_nic_recv = NULL;

/* режим приоритета: 0 = авто (по линку), 1..N = ручной (индекс+1) */
static int g_adapter_mode = 0;
static volatile int g_adapter_lock = 0;
/* callback смены адаптера: ядро перезапускает DHCP (netmon) */
static void (*g_adapter_change_cb)(void) = NULL;

/* ---------- состояние стека ---------- */
typedef struct {
    u8  mac[6];        /* наш MAC */
    u32 ip;            /* наш IP (host order, 0=не настроен) */
    u32 netmask;       /* маска подсети */
    u32 gateway;       /* шлюз по умолчанию */
    /* Кэш ARP */
    u32 arp_cache_ip[16];
    u8  arp_cache_mac[16][6];
    /* Статистика */
    u32 tx_packets;
    u32 rx_packets;
    u32 tx_bytes;    /* байт отправлено (кадры целиком, для графиков) */
    u32 rx_bytes;    /* байт принято (кадры целиком, для графиков) */
    u32 arp_rx;
    u32 icmp_rx;
    /* Callback для ICMP-ответов */
    net_icmp_cb_t icmp_cb;
    /* Сессия 12: транзакция DHCP идёт — исходящий IP = 0.0.0.0 */
    int dhcp_txn;
} net_state_t;

static net_state_t g_net;

/* отложенный пакет (объявлен ниже, в секции FIX сессии 7) */
static u32 g_pending_len;
static u32 g_pending_dst_ip;
/* [IP-CHG2] (Task 41): замок отложенного пакета поднят наверх —
 * net_set_ip теперь сбрасывает g_pending при смене адреса */
static volatile int pending_lock = 0;

/* ---------- 16-битная Internet checksum (RFC 1071) ---------- */
static u16 inet_checksum(const void *data, u32 len, u32 initial)
{
    u32 sum = initial;
    const u8 *p = (const u8 *)data;
    for (u32 i = 0; i + 1 < len; i += 2) {
        sum += ((u32)p[i] << 8) | p[i+1];
    }
    if (len & 1) {
        sum += (u32)p[len - 1] << 8;
    }
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)(~sum & 0xFFFF);
}

u16 inet_checksum_pseudo(u32 src_ip, u32 dst_ip, u8 proto,
                                  const void *data, u32 len)
{
    /* Псевдо-заголовок для UDP/TCP (12 байт): src_ip, dst_ip, zero, proto, len */
    u32 sum = 0;
    sum += (src_ip >> 16) & 0xFFFF;
    sum += src_ip & 0xFFFF;
    sum += (dst_ip >> 16) & 0xFFFF;
    sum += dst_ip & 0xFFFF;
    sum += (u32)proto;
    sum += len;
    return inet_checksum(data, len, sum);
}

/* ---------- Реестр адаптеров: публичный API ---------- */

int net_adapter_count(void) { return g_nic_count; }

int net_adapter_present(int i)
{
    return (i >= 0 && i < NET_MAX_NICS) ? g_nic_present[i] : 0;
}

const char *net_adapter_name(int i)
{
    if (i < 0 || i >= NET_MAX_NICS) return "?";
    if (i == NET_MAX_NICS - 1 && g_nic_present[i]) return "wifi";
    return g_nic_defs[i].name;
}

/* Состояние линка адаптера (для таблицы в Настройках). */
int net_adapter_link(int i)
{
    if (i < 0 || i >= NET_MAX_NICS || !g_nic_present[i]) return 0;
    return g_nic_defs[i].link ? g_nic_defs[i].link() : 1;
}

int net_adapter_active(void) { return g_active; }

/* Режим приоритета: 0 = авто, 1..N = ручной (индекс+1). */
int net_adapter_mode(void) { return g_adapter_mode; }
int net_adapter_manual_idx(void) { return g_adapter_mode - 1; }

void net_adapter_set_change_cb(void (*cb)(void)) { g_adapter_change_cb = cb; }

/* Установить режим приоритета ДО net_init (из SETTINGS.CFG при загрузке):
 * только сохраняет режим — применение произойдёт в net_init. */
void net_settings_set_adapter(int mode)
{
    if (mode >= 0 && mode <= NET_MAX_NICS)
        g_adapter_mode = mode;
}

/* Поиск адаптера по имени ("e1000".."atl1c", "wifi") — индекс или -1. */
int net_adapter_find(const char *name)
{
    if (!name) return -1;
    for (int i = 0; i < NET_MAX_NICS; i++)
        if (strcmp(g_nic_defs[i].name, name) == 0) return i;
    return -1;
}

/* Выбор лучшего адаптера (авто-политика):
 * 1) ethernet с линком (в порядке регистрации);
 * 2) WiFi с линком (ассоциирован);
 * 3) любой найденный (без линка — ждём в netmon). */
static int net_adapter_pick(void)
{
    int best = -1;
    for (int i = 0; i < NET_MAX_NICS; i++) {
        if (!g_nic_present[i] || !g_nic_defs[i].wired) continue;
        if (!g_nic_defs[i].link || g_nic_defs[i].link())
            return i;
    }
    for (int i = 0; i < NET_MAX_NICS; i++) {
        if (!g_nic_present[i] || g_nic_defs[i].wired) continue;
        if (g_nic_defs[i].link && g_nic_defs[i].link())
            best = i;
    }
    if (best >= 0) return best;
    for (int i = 0; i < NET_MAX_NICS; i++)
        if (g_nic_present[i]) return i;
    return -1;
}

/* Очистить ARP-кэш и отложенный пакет (при смене адаптера старые записи
 * чужого сегмента недействительны). */
static void arp_cache_clear(void)
{
    memset(g_net.arp_cache_ip, 0, sizeof(g_net.arp_cache_ip));
    g_pending_len = 0;
    g_pending_dst_ip = 0;
}

/* Применить адаптер idx как активный (MAC, send/recv, чистка кэша). */
static void net_adapter_apply(int idx, const char *why)
{
    if (idx < 0 || idx >= NET_MAX_NICS || !g_nic_present[idx]) return;
    s_lock(&g_adapter_lock);
    g_active = idx;
    g_nic_send = g_nic_defs[idx].send;
    g_nic_recv = g_nic_defs[idx].recv;
    g_nic_defs[idx].get_mac(g_net.mac);
    arp_cache_clear();
    s_unlock(&g_adapter_lock);
    {
        char b[80];
        snprintf(b, sizeof(b), "[net] активный адаптер: %s (%s)",
                 g_nic_defs[idx].name, why);
        serial_puts(b);
        serial_puts("\n");
    }
}

/* Установить режим приоритета: mode=0 (авто) или 1..N (ручной, индекс+1).
 * Возвращает 1, если активный адаптер ИЗМЕНИЛСЯ (надо перезапустить DHCP). */
int net_adapter_set_mode(int mode)
{
    if (mode < 0 || mode > NET_MAX_NICS) return 0;
    if (mode > 0 && !g_nic_present[mode - 1]) return 0;
    g_adapter_mode = mode;
    int old = g_active;
    if (mode == 0)
        net_adapter_apply(net_adapter_pick(), "авто-приоритет");
    else
        net_adapter_apply(mode - 1, "выбор пользователя");
    if (g_active != old) {
        if (g_adapter_change_cb) g_adapter_change_cb();
        return 1;
    }
    return 0;
}

/* Периодическая проверка (netmon): в авто-режиме переключиться, если
 * текущий адаптер потерял линк, а другой — поднял. Возвращает 1 при
 * переключении. Избавляет от «DHCP ушёл в мёртвый lan». */
int net_adapter_check(void)
{
    if (g_adapter_mode != 0 || g_active < 0) return 0;
    if (net_adapter_link(g_active)) return 0;    /* работает — не трогаем */
    int best = net_adapter_pick();
    if (best >= 0 && best != g_active) {
        net_adapter_apply(best, "потеря линка, авто");
        if (g_adapter_change_cb) g_adapter_change_cb();
        return 1;
    }
    return 0;
}

/* СЕССИЯ 15: пересканировать реестр адаптеров. WiFi инициализируется
 * ФОНОВОЙ задачей ПОСЛЕ старта ОС (нетбук больше не ждёт адаптер при
 * загрузке) — в момент net_init его ещё не было. Когда адаптер стал
 * ready, ядро вызывает эту функцию: wifi появляется в реестре, и
 * netmon сам переключится на него по линку (net_adapter_check).
 * Ethernet-флаги после загрузки не меняются — добавляем только wifi. */
int net_adapter_rescan(void)
{
    if (wifi_present() && wifi_ready() && !g_nic_present[4]) {
        g_nic_present[4] = 1;
        g_nic_count++;
        serial_puts("[net] адаптер wifi зарегистрирован (фон. init завершён)\n");
    }
    return g_nic_count;
}

/* ---------- Инициализация ---------- */
void net_init(void)
{
    memset(&g_net, 0, sizeof(g_net));
    g_net.netmask = 0xFFFFFF00u;   /* 255.255.255.0 по умолчанию */
    g_net.gateway = 0;
    g_net.ip = 0;

    /* Регистрируем ВСЕ найденные NIC-драйверы (сессия 11: WiFi тоже) */
    g_nic_count = 0;
    memset(g_nic_present, 0, sizeof(g_nic_present));
    if (e1000_present())     g_nic_present[0] = 1;
    if (virtio_net_present())g_nic_present[1] = 1;
    if (ne2000_present())    g_nic_present[2] = 1;
    if (atl1c_present())     g_nic_present[3] = 1;
    if (wifi_present() && wifi_ready()) g_nic_present[4] = 1;
    for (int i = 0; i < NET_MAX_NICS; i++) g_nic_count += g_nic_present[i];

    g_nic_send = NULL;
    g_nic_recv = NULL;
    g_active = -1;

    if (g_nic_count == 0) {
        serial_puts("[net] init done, NIC не найден\n");
        return;
    }

    /* Режим из настроек (SETTINGS.CFG): "adapter=auto" или "adapter=<имя>";
     * загрузчик вызвал net_settings_load() до net_init. При отсутствии — авто. */
    if (g_adapter_mode > 0 && !g_nic_present[g_adapter_mode - 1])
        g_adapter_mode = 0;    /* настроенного адаптера нет — авто */

    if (g_adapter_mode == 0)
        net_adapter_apply(net_adapter_pick(), "авто-приоритет");
    else
        net_adapter_apply(g_adapter_mode - 1, "настройки");

    serial_puts("[net] init done, адаптеров: ");
    {
        char b[16];
        snprintf(b, sizeof(b), "%d, mac=", g_nic_count);
        serial_puts(b);
        const char *h = "0123456789abcdef";
        char buf[20];
        int p = 0;
        for (int i = 0; i < 6; i++) {
            buf[p++] = h[(g_net.mac[i]>>4)&0xF];
            buf[p++] = h[g_net.mac[i]&0xF];
            if (i < 5) buf[p++] = ':';
        }
        buf[p] = 0;
        serial_puts(buf);
        serial_puts("\n");
    }
}

/* [IP-CHG2] (Task 41, повтор Task 40): реакция подсистем на смену IP.
 * При ФАКТИЧЕСКОЙ смене адреса:
 *  - ARP-кэш стирается: записи принадлежали прежнему сегменту;
 *  - отложенный пакет (g_pending, ждущий ARP-ответ) сбрасывается —
 *    он построен со старым адресом/маршрутом;
 *  - TCP-сокеты, созданные под прежним адресом, помечаются
 *    ip_migrated=1 (чексуммы сегментов всё равно считают ТЕКУЩИЙ
 *    адрес — [IP-CHG1] в tcp_send_segment).
 * Тот же адрес — no-op: DHCP-продления и повторы не будят стек. */
void net_tcp_mark_migrated(u32 ip);   /* net_tcp.c: миграция TCP-сокетов */

void net_set_ip(u32 ip)
{
    u32 old = g_net.ip;
    if (ip == old) return;
    g_net.ip = ip;
    {
        extern void klog_puts(const char *);
        char b[80], a1[16], a2[16];
        net_ntoa(old, a1, sizeof(a1));
        net_ntoa(ip, a2, sizeof(a2));
        snprintf(b, sizeof(b), "[net] IP: %s -> %s (ARP кэш сброшен)",
                 a1, a2);
        serial_puts(b);
        serial_puts("\n");
        klog_puts(b);
    }
    arp_cache_clear();
    s_lock(&pending_lock);
    g_pending_len = 0;          /* отложенный пакет устарел вместе */
    g_pending_dst_ip = 0;       /* со старым адресом/маршрутом */
    s_unlock(&pending_lock);
    net_tcp_mark_migrated(ip);
}
u32  net_get_ip(void)    { return g_net.ip; }

/* Сессия 12: транзакция DHCP — исходящий src-IP 0.0.0.0 без стирания
 * настроенного адреса (см. комментарий в шапке файла). */
void net_dhcp_txn_begin(void) { g_net.dhcp_txn = 1; }
void net_dhcp_txn_end(void)   { g_net.dhcp_txn = 0; }
int  net_dhcp_txn_active(void) { return g_net.dhcp_txn; }   /* net_tcp.c */

int net_nic_present(void)
{
    return (g_active >= 0);
}

const char *net_nic_name(void)
{
    if (g_active >= 0) return g_nic_defs[g_active].name;
    if (g_nic_count > 0) return "нет активного";
    return "no NIC";
}
void net_set_gateway(u32 gw) { g_net.gateway = gw; }
u32  net_get_gateway(void)  { return g_net.gateway; }
void net_set_netmask(u32 m) { g_net.netmask = m; }
u32  net_get_netmask(void) { return g_net.netmask; }

/* ---------- Loopback (127.0.0.1 / свой IP) ---------- */
int net_is_loopback(u32 ip)
{
    if ((ip >> 24) == 127) return 1;          /* 127.0.0.0/8 */
    if (g_net.ip != 0 && ip == g_net.ip) return 1;  /* на себя */
    return 0;
}

/* СЕССИЯ 63: loopback-хост по ИМЕНИ — "localhost" (или "localhost.")
 * и IP-литерал 127.x.x.x. Приложения (браузер, curl, ping, imgsvc,
 * nettrace) обязаны пускать такие адреса БЕЗ NIC и без настроенного IP:
 * TCP/ICMP для них замыкается внутри стека (net_is_loopback), провода
 * и ARP не требуется — иначе «Сеть не настроена» на 127.0.0.1. */
int net_host_is_loopback(const char *host)
{
    if (!host || !host[0]) return 0;
    if (!strcmp(host, "localhost") || !strcmp(host, "localhost."))
        return 1;
    u32 ip;
    if (net_aton(host, &ip) && (ip >> 24) == 127) return 1;
    return 0;
}
void net_get_mac(u8 out_mac[6]) { memcpy(out_mac, g_net.mac, 6); }
void net_set_icmp_callback(net_icmp_cb_t cb) { g_net.icmp_cb = cb; }
u32  net_tx_packets(void) { return g_net.tx_packets; }
u32  net_rx_packets(void) { return g_net.rx_packets; }
u32  net_tx_bytes(void)  { return g_net.tx_bytes; }
u32  net_rx_bytes(void)  { return g_net.rx_bytes; }

/* ---------- ARP кэш дамп ---------- */
int net_arp_dump(net_arp_entry_t *out, int max_entries)
{
    int count = 0;
    for (int i = 0; i < NET_ARP_CACHE_SIZE && count < max_entries; i++) {
        if (g_net.arp_cache_ip[i] != 0) {
            out[count].ip = g_net.arp_cache_ip[i];
            memcpy(out[count].mac, g_net.arp_cache_mac[i], 6);
            count++;
        }
    }
    return count;
}

/* ---------- Парсинг IP-адреса ---------- */
int net_aton(const char *str, u32 *out_ip)
{
    u32 a, b, c, d;
    int n = 0;
    /* Ручной sscanf: %d.%d.%d.%d */
    const char *p = str;
    u32 vals[4];
    int idx = 0;
    u32 cur = 0;
    int any = 0;
    while (*p && idx < 4) {
        if (*p >= '0' && *p <= '9') {
            cur = cur * 10 + (u32)(*p - '0');
            any = 1;
            if (cur > 255) return 0;
        } else if (*p == '.') {
            if (!any) return 0;
            vals[idx++] = cur;
            cur = 0;
            any = 0;
        } else {
            return 0;
        }
        p++;
    }
    if (!any || idx != 3) return 0;
    vals[idx++] = cur;
    a = vals[0]; b = vals[1]; c = vals[2]; d = vals[3];
    (void)a; (void)b; (void)c; (void)d;
    (void)n;
    *out_ip = (vals[0] << 24) | (vals[1] << 16) | (vals[2] << 8) | vals[3];
    return 1;
}

int net_ntoa(u32 ip, char *out, u32 out_max)
{
    if (out_max < 16) return 0;
    u8 a = (u8)((ip >> 24) & 0xFF);
    u8 b = (u8)((ip >> 16) & 0xFF);
    u8 c = (u8)((ip >> 8) & 0xFF);
    u8 d = (u8)(ip & 0xFF);
    /* Ручное форматирование */
    int p = 0;
    u8 vals[4] = { a, b, c, d };
    for (int i = 0; i < 4; i++) {
        u8 v = vals[i];
        char tmp[4];
        int L = 0;
        if (v == 0) { tmp[L++] = '0'; }
        else {
            while (v > 0 && L < 3) { tmp[L++] = (char)('0' + v % 10); v /= 10; }
        }
        while (L > 0) out[p++] = tmp[--L];
        if (i < 3) out[p++] = '.';
    }
    out[p] = 0;
    return p;
}

/* ---------- Отложенный пакет (FIX сессия 7) ----------
 * Первый пакет к НОВОМУ адресату отправляется ДО ARP-разрешения и
 * раньше МОЛЧА ТЕРЯЛСЯ (в net_send_ip: нет записи → только ARP-запрос).
 * Это роняло SYN-ACK сервера: клиент повторял SYN, создавался ВТОРОЙ
 * сокет — и соединение зависало на чужом seq. Теперь пакет (один слот)
 * сохраняется и уходит сразу после ARP-ответа (flush в arp_cache_add). */
static u8  g_pending_pkt[NET_PKT_MAX];
/* g_pending_len / g_pending_dst_ip / pending_lock объявлены выше
 * (используются arp_cache_clear в реестре адаптеров и net_set_ip) */
static int send_eth(const u8 dst[6], u16 ethertype, const void *payload, u32 len);

/* ---------- ARP кэш ---------- */
static int arp_cache_lookup(u32 ip, u8 out_mac[6])
{
    for (int i = 0; i < 16; i++) {
        if (g_net.arp_cache_ip[i] == ip && ip != 0) {
            memcpy(out_mac, g_net.arp_cache_mac[i], 6);
            return 1;
        }
    }
    return 0;
}

static void arp_cache_add(u32 ip, const u8 mac[6])
{
    if (ip == 0) return;
    /* Ищем существующую запись */
    int slot = -1;
    for (int i = 0; i < 16; i++) {
        if (g_net.arp_cache_ip[i] == ip) { slot = i; break; }
    }
    if (slot < 0) {
        /* Ищем свободный слот */
        for (int i = 0; i < 16; i++) {
            if (g_net.arp_cache_ip[i] == 0) { slot = i; break; }
        }
    }
    if (slot < 0) {
        /* Заменяем первую запись (FIFO-замена без учёта времени — простота) */
        slot = 0;
    }
    g_net.arp_cache_ip[slot] = ip;
    memcpy(g_net.arp_cache_mac[slot], mac, 6);

    /* FIX сессия 7: отложенный пакет, ждавший ЭТОГО адресата, — в сеть */
    if (g_pending_len && g_pending_dst_ip == ip) {
        u8  pcopy[NET_PKT_MAX];
        u32 plen;
        s_lock(&pending_lock);
        plen = g_pending_len;
        memcpy(pcopy, g_pending_pkt, plen);
        g_pending_len = 0;
        g_pending_dst_ip = 0;
        s_unlock(&pending_lock);
        if (plen)
            send_eth(mac, ETHERTYPE_IPV4, pcopy, plen);
    }
}

/* ---------- Отправка Ethernet-кадра ---------- */
/* FIX (многозадачность): frame — СТАТИЧЕСКИЙ буфер, общий для всех задач
 * (раньше все отправки шли из kmain — теперь и из потоков приложений).
 * То же для pkt в net_send_ip. Две отдельные блокировки (без вложенного
 * ожидания друг на друга: порядок всегда send_ip -> send_eth). */
static volatile int net_eth_lock = 0;
static volatile int net_ip_lock = 0;

static int send_eth(const u8 dst_mac[6], u16 ethertype, const void *payload, u32 payload_len)
{
    static u8 frame[NET_PKT_MAX];
    int rc;
    if (payload_len + 14 > NET_PKT_MAX) return -1;
    s_lock(&net_eth_lock);
    memcpy(frame, dst_mac, 6);
    memcpy(frame + 6, g_net.mac, 6);
    frame[12] = (u8)(ethertype >> 8);
    frame[13] = (u8)(ethertype & 0xFF);
    memcpy(frame + 14, payload, payload_len);
    /* FIX (сессия 57): ДОБИТЬ кадр до минимума Ethernet 60 байт.
     * Наши SYN = 58 байт (14+20+24 с MSS), ACK = 54 байт. Кадры короче
     * 60 байт настоящие мосты/NIC (в т.ч. часть точек доступа и USB-
     * свистков) молча отбрасывают — хендшейк не завершается, а стек
     * видит «сервер молчит». ARP (42 байта) выживал только потому, что
     * broadcast-кадры мосты пропускают охотнее unicast. */
    u32 flen = 14 + payload_len;
    if (flen < 60) {
        memset(frame + flen, 0, 60 - flen);
        flen = 60;
    }
    if (!g_nic_send) { s_unlock(&net_eth_lock); return -1; }
    rc = g_nic_send(frame, flen);
    if (rc > 0) { g_net.tx_packets++; g_net.tx_bytes += flen; }
    s_unlock(&net_eth_lock);
    return rc;
}

/* ---------- ARP ---------- */
int net_send_arp_request(u32 target_ip)
{
    if (g_net.ip == 0) return -1;
    arp_pkt_t arp;
    /* FIX [N2] (ARP-запросы игнорировались всеми стеками): htype/ptype/oper
     * писались как НАТИВНЫЕ LE-числа: 0x0001 превращалось в байты [01,00],
     * а на проводе нужно [00,01]. QEMU/slirp и реальные стеки читают
     * ar_op = 0x0100 вместо 1 (REQUEST) и молча отбрасывали запрос —
     * ARP-таблица не заполнялась НИКОГДА (поэтому же «вис» TCP-connect).
     * Пишем поля сразу сетевым порядком байт (как в reply ниже). */
    arp.htype = 0x0100;   /* 0x0001 BE: байты [00,01] = Ethernet */
    arp.ptype = 0x0008;   /* 0x0800 BE: байты [08,00] = IPv4 */
    arp.hlen  = 6;
    arp.plen  = 4;
    arp.oper  = 0x0100;   /* 0x0001 BE: request */
    memcpy(arp.sha, g_net.mac, 6);
    arp.spa[0] = (u8)((g_net.ip >> 24) & 0xFF);
    arp.spa[1] = (u8)((g_net.ip >> 16) & 0xFF);
    arp.spa[2] = (u8)((g_net.ip >> 8) & 0xFF);
    arp.spa[3] = (u8)(g_net.ip & 0xFF);
    memset(arp.tha, 0, 6);
    arp.tpa[0] = (u8)((target_ip >> 24) & 0xFF);
    arp.tpa[1] = (u8)((target_ip >> 16) & 0xFF);
    arp.tpa[2] = (u8)((target_ip >> 8) & 0xFF);
    arp.tpa[3] = (u8)(target_ip & 0xFF);

    /* Broadcast destination */
    u8 bcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
    return send_eth(bcast, ETHERTYPE_ARP, &arp, sizeof(arp));
}

/* FIX [N1c]: дождаться разрешения MAC-адреса для IP (с учётом шлюза).
 *
 * Проблема: net_send_ip() при отсутствии записи в ARP-кэше МОЛЧА теряет
 * пакет (посылается только ARP-запрос). ping это переживает — команда
 * повторяет запрос; TCP-connect — нет: единственный SYN терялся,
 * ретрансляции не было → «Ошибка запроса» при первом обращении к любому
 * новому адресу. Функция посылает ARP-запросы с интервалом и ждёт ответа
 * (net_poll обрабатывает входящие, task_yield отдаёт CPU). */
int net_wait_arp(u32 ip, u32 max_ms)
{
    u8 mac[6];
    if (net_is_loopback(ip)) return 1;   /* loopback — без ARP */
    if (g_net.ip == 0) return 0;

    /* Куда реально пойдёт пакет: напрямую или через шлюз */
    u32 route = ip;
    if ((ip & g_net.netmask) != (g_net.ip & g_net.netmask)) {
        if (g_net.gateway == 0) return 0;
        route = g_net.gateway;
    }
    if (arp_cache_lookup(route, mac)) return 1;

    u32 start = timer_ticks();
    u32 need = max_ms;               /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    for (;;) {
        net_send_arp_request(route);
        /* 100 мс между ARP-запросами */
        u32 t0 = timer_ticks();
        while (timer_ticks() - t0 < 100) {
            net_poll();
            task_yield();
            if (arp_cache_lookup(route, mac)) return 1;
        }
        if (timer_ticks() - start >= need) break;
    }
    return arp_cache_lookup(route, mac);
}

static void net_handle_udp(const ip_hdr_t *ip, const u8 *payload, u32 len);
void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len);   /* net_tcp.c */

static void net_handle_arp(const eth_hdr_t *eth, const u8 *payload, u32 len)
{
    (void)eth;
    (void)len;
    if (len < sizeof(arp_pkt_t)) return;
    const arp_pkt_t *arp = (const arp_pkt_t *)payload;

    u16 oper = (arp->oper << 8) | (arp->oper >> 8);
    /* normalise: network order — oper уже 16-битное поле, big-endian.
     * На little-endian нам нужно перевернуть. */
    oper = (u16)((arp->oper >> 8) | (arp->oper << 8));

    u32 sender_ip = ((u32)arp->spa[0] << 24) | ((u32)arp->spa[1] << 16)
                   | ((u32)arp->spa[2] << 8) | (u32)arp->spa[3];

    /* Добавим в кэш отправителя */
    arp_cache_add(sender_ip, arp->sha);

    if (oper == 1) {
        /* ARP request: если запрос адресован нам — отвечаем */
        u32 target_ip = ((u32)arp->tpa[0] << 24) | ((u32)arp->tpa[1] << 16)
                       | ((u32)arp->tpa[2] << 8) | (u32)arp->tpa[3];
        if (target_ip == g_net.ip) {
            arp_pkt_t reply;
            reply.htype = 0x0001;
            reply.ptype = 0x0800;
            reply.hlen = 6;
            reply.plen = 4;
            reply.oper = 0x0002;   /* reply (little-endian, перевернётся ниже) */
            memcpy(reply.sha, g_net.mac, 6);
            memcpy(reply.spa, arp->tpa, 4);
            memcpy(reply.tha, arp->sha, 6);
            memcpy(reply.tpa, arp->spa, 4);
            /* Convert oper to network order */
            reply.oper = (u16)((0x0002 << 8) | (0x0002 >> 8));
            /* Convert htype and ptype too — но мы записали 0x0001 и 0x0800,
             * что в little-endian выглядит как 0x0100 и 0x0008.
             * На самом деле правильнее — изначально писать big-endian. */
            reply.htype = 0x0100;  /* 0x0001 в big-endian */
            reply.ptype = 0x0008;  /* 0x0800 в big-endian */
            send_eth(arp->sha, ETHERTYPE_ARP, &reply, sizeof(reply));
        }
    }
    g_net.arp_rx++;
}

/* ---------- IP ---------- */
void net_send_ip(u8 proto, u32 dst_ip, const void *payload, u32 payload_len)
{
    static u8 pkt[NET_PKT_MAX];
    if (payload_len + 20 > NET_PKT_MAX - 14) return;

    /* loopback: на провод не идёт — данные доставляет слой выше
     * (TCP-пара в net_tcp_send / ICMP-эхо в net_send_icmp_echo) */
    if (net_is_loopback(dst_ip)) return;

    s_lock(&net_ip_lock);

    /* IP header */
    ip_hdr_t *ip = (ip_hdr_t *)pkt;
    ip->ver_ihl = 0x45;
    ip->tos = 0;
    ip->tot_len = (u16)(20 + payload_len);
    ip->tot_len = (u16)((ip->tot_len << 8) | (ip->tot_len >> 8));
    /* Сессия 21: уникальный ID на пакет вместо жёсткого 0x1234 —
     * одинаковый id на всех пакетах портит фрагментацию-дефрагментацию
     * промежуточных узлов и выглядит как крафтовый трафик для IDS. */
    {
        static u16 g_ip_id = 0;
        g_ip_id++;
        ip->id = (u16)((g_ip_id << 8) | (g_ip_id >> 8));
    }
    ip->flags_frag = 0x4000;  /* Don't Fragment */
    ip->flags_frag = (u16)((ip->flags_frag << 8) | (ip->flags_frag >> 8));
    ip->ttl = 64;
    ip->protocol = proto;
    {
        u32 src = g_net.dhcp_txn ? 0 : g_net.ip;   /* сессия 12: DHCP шлёт с 0.0.0.0 */
        ip->src_ip[0] = (u8)((src >> 24) & 0xFF);
        ip->src_ip[1] = (u8)((src >> 16) & 0xFF);
        ip->src_ip[2] = (u8)((src >> 8) & 0xFF);
        ip->src_ip[3] = (u8)(src & 0xFF);
    }
    ip->dst_ip[0] = (u8)((dst_ip >> 24) & 0xFF);
    ip->dst_ip[1] = (u8)((dst_ip >> 16) & 0xFF);
    ip->dst_ip[2] = (u8)((dst_ip >> 8) & 0xFF);
    ip->dst_ip[3] = (u8)(dst_ip & 0xFF);
    ip->checksum = 0;
    u16 cs = inet_checksum(ip, 20, 0);
    ip->checksum = (u16)((cs << 8) | (cs >> 8));

    /* Payload */
    memcpy(pkt + 20, payload, payload_len);

    /* Резолвим MAC */
    u8 dst_mac[6];
    if (dst_ip == 0xFFFFFFFFu) {
        /* FIX [DHCP-1]: ограниченный broadcast (255.255.255.255) —
         * НИКОГДА не через шлюз и без ARP: напрямую в L2-broadcast.
         * Раньше такой пакет «маршрутизировался» через шлюз, ARP для
         * шлюза при нашем ip=0.0.0.0 отказывал (см. net_send_arp_request)
         * — DHCP DISCOVER МОЛЧА терялся, ничего не выходило в сеть. */
        u8 bcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
        send_eth(bcast, ETHERTYPE_IPV4, pkt, 20 + payload_len);
        s_unlock(&net_ip_lock);
        return;
    }
    u32 route_ip = dst_ip;
    if ((dst_ip & g_net.netmask) != (g_net.ip & g_net.netmask)) {
        /* Не в нашей подсети — отправляем через шлюз */
        if (g_net.gateway != 0) {
            route_ip = g_net.gateway;
        }
    }
    if (!arp_cache_lookup(route_ip, dst_mac)) {
        /* Нет в кэше — ARP-запрос; пакет раньше ТЕРЯЛСЯ (первый SYN-ACK
         * сервера, первый ответ UDP/ICMP). FIX сессия 7: откладываем
         * (один слот) — arp_cache_add отправит его сразу после ответа. */
        net_send_arp_request(route_ip);
        if (g_pending_len == 0 && 20 + payload_len <= sizeof(g_pending_pkt)) {
            s_lock(&pending_lock);
            if (g_pending_len == 0) {
                memcpy(g_pending_pkt, pkt, 20 + payload_len);
                g_pending_len = 20 + payload_len;
                g_pending_dst_ip = route_ip;
            }
            s_unlock(&pending_lock);
        }
        s_unlock(&net_ip_lock);
        return;
    }

    send_eth(dst_mac, ETHERTYPE_IPV4, pkt, 20 + payload_len);
    s_unlock(&net_ip_lock);
}

/* ---------- ICMP ---------- */
int net_send_icmp_echo(u32 target_ip, u16 id, u16 seq, const void *payload, u32 payload_len)
{
    static u8 pkt[NET_PKT_MAX - 20];
    static volatile int icmp_lock = 0;
    if (payload_len + 8 > sizeof(pkt)) return -1;
    s_lock(&icmp_lock);
    icmp_hdr_t *icmp = (icmp_hdr_t *)pkt;
    icmp->type = ICMP_TYPE_ECHO_REQUEST;
    icmp->code = 0;
    icmp->checksum = 0;
    /* id и seq — уже big-endian, сохраняем как есть */
    icmp->id = (u16)((id << 8) | (id >> 8));
    icmp->seq = (u16)((seq << 8) | (seq >> 8));
    if (payload && payload_len > 0) {
        memcpy(pkt + 8, payload, payload_len);
    }
    u16 cs = inet_checksum(pkt, 8 + payload_len, 0);
    icmp->checksum = (u16)((cs << 8) | (cs >> 8));

    if (net_is_loopback(target_ip)) {
        /* loopback ping: эхо-ответ формируется мгновенно —
         * пакет никуда не уходит, сразу дёргаем callback ping-а */
        s_unlock(&icmp_lock);
        if (g_net.icmp_cb)
            g_net.icmp_cb(target_ip, id, seq, payload, payload_len);
        return 1;
    }

    net_send_ip(IP_PROTO_ICMP, target_ip, pkt, 8 + payload_len);
    s_unlock(&icmp_lock);
    return 0;
}

static void net_handle_icmp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < sizeof(icmp_hdr_t)) return;
    const icmp_hdr_t *icmp = (const icmp_hdr_t *)payload;

    u16 icmp_cs = (u16)((icmp->checksum << 8) | (icmp->checksum >> 8));
    u16 calc_cs = inet_checksum(icmp, len, 0);
    (void)icmp_cs; (void)calc_cs;

    if (icmp->type == ICMP_TYPE_ECHO_REQUEST) {
        /* Отвечаем echo reply */
        u32 src_ip = ((u32)ip->src_ip[0] << 24)
                   | ((u32)ip->src_ip[1] << 16)
                   | ((u32)ip->src_ip[2] << 8)
                   | (u32)ip->src_ip[3];

        /* Строим echo reply */
        static u8 reply[NET_PKT_MAX - 20];
        if (len > sizeof(reply)) len = sizeof(reply);
        memcpy(reply, payload, len);
        reply[0] = ICMP_TYPE_ECHO_REPLY;
        reply[1] = 0;
        reply[2] = 0; reply[3] = 0;  /* checksum */
        u16 cs = inet_checksum(reply, len, 0);
        reply[2] = (u8)(cs & 0xFF);   /* little-endian byte order on wire... actually big-endian */
        reply[3] = (u8)((cs >> 8) & 0xFF);
        /* Actually wire format is big-endian: high byte first */
        reply[2] = (u8)((cs >> 8) & 0xFF);
        reply[3] = (u8)(cs & 0xFF);

        net_send_ip(IP_PROTO_ICMP, src_ip, reply, len);
    } else if (icmp->type == ICMP_TYPE_ECHO_REPLY) {
        /* Получен ответ на наш ping */
        u32 src_ip = ((u32)ip->src_ip[0] << 24)
                   | ((u32)ip->src_ip[1] << 16)
                   | ((u32)ip->src_ip[2] << 8)
                   | (u32)ip->src_ip[3];
        u16 id = (u16)((icmp->id << 8) | (icmp->id >> 8));
        u16 seq = (u16)((icmp->seq << 8) | (icmp->seq >> 8));
        if (g_net.icmp_cb) {
            g_net.icmp_cb(src_ip, id, seq, payload + 8, len - 8);
        }
    }
    g_net.icmp_rx++;
}

/* ---------- Обработка входящих пакетов ---------- */
static void net_handle_packet(const u8 *frame, u32 len)
{
    if (len < 14) return;
    eth_hdr_t eth;
    memcpy(&eth, frame, 14);
    u16 ethertype = (u16)((eth.ethertype << 8) | (eth.ethertype >> 8));

    /* Игнорируем кадры, не адресованные нам (broadcast или наш MAC) */
    int to_us = 0;
    if (memcmp(eth.dst, g_net.mac, 6) == 0) to_us = 1;
    if (memcmp(eth.dst, "\xFF\xFF\xFF\xFF\xFF\xFF", 6) == 0) to_us = 1;
    if (!to_us) return;

    const u8 *payload = frame + 14;
    u32 payload_len = len - 14;

    if (ethertype == ETHERTYPE_ARP) {
        net_handle_arp(&eth, payload, payload_len);
    } else if (ethertype == ETHERTYPE_IPV4) {
        if (payload_len < 20) return;
        const ip_hdr_t *ip = (const ip_hdr_t *)payload;
        /* Проверим, что пакет адресован нам (или broadcast) */
        u32 dst_ip = ((u32)ip->dst_ip[0] << 24) | ((u32)ip->dst_ip[1] << 16)
                   | ((u32)ip->dst_ip[2] << 8) | (u32)ip->dst_ip[3];
        if (dst_ip != g_net.ip && dst_ip != 0xFFFFFFFFu) {
            /* FIX [DHCP-2]: пока наш IP не настроен (0.0.0.0, фаза DHCP),
             * принимаем unicast-пакеты: часть DHCP-серверов (в т.ч.
             * slirp) шлёт OFFER/ACK на ПРЕДЛАГАЕМЫЙ адрес, а не в
             * broadcast — фильтр молча съедал их.
             * Сессия 12: то же и ВО ВРЕМЯ транзакции DHCP, когда старый
             * адрес ещё виден (не обнуляем его) — OFFER приходит на
             * предлагаемый НОВЫЙ адрес, который != нашему текущему. */
            if (g_net.ip != 0 && !g_net.dhcp_txn) {
                /* Не нам — игнорируем */
                return;
            }
        }
        /* Длина IP-пакета (host order) */
        u16 ip_len = (u16)((ip->tot_len >> 8) | (ip->tot_len << 8)); /* FIX [N3] */
        if (ip_len < 20 || ip_len > payload_len) return;

        /* Сессия 21: ИСПРАВНАЯ длина заголовка (IHL). Раньше payload
         * всегда брался с offset 20: IP-пакеты с опциями (IHL>5 —
         * встречаются у роутеров/фаерволов) парсились по СМЕЩЁННОМУ
         * заголовку и молча терялись протокольными обработчиками. */
        u8 ihl = (u8)((ip->ver_ihl & 0x0F) * 4);
        if (ihl < 20 || ihl > ip_len) return;

        const u8 *ip_payload = payload + ihl;
        u32 ip_payload_len = ip_len - ihl;

        if (ip->protocol == IP_PROTO_ICMP) {
            net_handle_icmp(ip, ip_payload, ip_payload_len);
        }
        else if (ip->protocol == IP_PROTO_UDP) {
            net_handle_udp(ip, ip_payload, ip_payload_len);
        }
        else if (ip->protocol == IP_PROTO_TCP) {
            net_handle_tcp(ip, ip_payload, ip_payload_len);
        }
    }
}

void net_poll(void)
{
    /* FIX (гонка приёма): net_poll вызывают ОДНОВРЕМЕННО kmain (главный
     * цикл) и потоки окон (wait-циклы http-клиента: browser/curl/nettrace).
     * Раньше буфер приёма был static — общий на всех: два concurrent
     * net_poll калечили пакеты друг друга и состояние TCP-сокетов
     * («браузер не получает ответ»). Теперь всё тело под блокировкой;
     * ожидающий спит (hlt) и не жжёт CPU. */
    static volatile int net_poll_lock = 0;
    if (!g_nic_recv) return;
    s_lock(&net_poll_lock);
    /* FIX [DHCP-3]: ветка «ip == 0 → все пакеты в корзину» ломала DHCP:
     * клиент на время DISCOVER ставит 0.0.0.0 (net_set_ip(0)) — и все
     * OFFER/ACK немедленно выбрасывались прямо из кольца NIC. Пакеты
     * обрабатываем всегда; фильтр по dst-IP в net_handle_packet сам
     * решает, наши они или нет (при ip=0 принимает всё — фаза DHCP). */
    static u8 buf[NET_PKT_MAX];
    for (int i = 0; i < 8; i++) {
        u32 n = g_nic_recv(buf, sizeof(buf));
        if (n == 0) break;
        g_net.rx_packets++;
        g_net.rx_bytes += n;
        net_handle_packet(buf, n);
    }
    net_tcp_timer();
    s_unlock(&net_poll_lock);
}

/* ===================== UDP ===================== */

typedef struct {
    u16 src_port;
    u16 dst_port;
    u16 length;
    u16 checksum;   /* 0 = no checksum */
} udp_hdr_t;

static net_udp_socket_t g_udp_socks[NET_MAX_UDP_SOCKETS];
static net_udp_recv_cb_t g_udp_recv_cb = NULL;   /* fallback: нет сокета под порт */
static int g_udp_last_open = -1;                 /* Сессия 21: последний открытый */

/* Сессия 21 (demux UDP): callback привязывается к ПОСЛЕДНЕМУ открытому
 * сокету. Раньше был ОДИН глобальный cb: DNS-сокет получал DHCP-пакеты
 * и LAN-шум (NetBIOS/mDNS/SSDP) — «[dns] txid mismatch»; DHCP-клиент
 * после первого net_dns_resolve() вообще переставал получать ответы
 * (его cb перетирали) — продление/повтор DHCP висели. Теперь каждый
 * сокет получает только пакеты на СВОЙ порт. */
void net_udp_set_callback(net_udp_recv_cb_t cb)
{
    if (g_udp_last_open >= 0 && g_udp_last_open < NET_MAX_UDP_SOCKETS &&
        g_udp_socks[g_udp_last_open].in_use) {
        g_udp_socks[g_udp_last_open].cb = cb;
        return;
    }
    g_udp_recv_cb = cb;   /* сокетов нет — глобальный fallback */
}

int net_udp_open(u16 local_port)
{
    for (int i = 0; i < NET_MAX_UDP_SOCKETS; i++) {
        if (!g_udp_socks[i].in_use) {
            g_udp_socks[i].in_use = 1;
            g_udp_socks[i].local_ip = g_net.ip;
            g_udp_socks[i].local_port = local_port;
            g_udp_socks[i].remote_ip = 0;
            g_udp_socks[i].remote_port = 0;
            g_udp_socks[i].cb = NULL;
            g_udp_last_open = i;
            return i;
        }
    }
    return -1;
}

void net_udp_close(int sock)
{
    if (sock < 0 || sock >= NET_MAX_UDP_SOCKETS) return;
    g_udp_socks[sock].in_use = 0;
    g_udp_socks[sock].cb = NULL;
    if (g_udp_last_open == sock) g_udp_last_open = -1;
}

int net_udp_send(int sock, u32 dst_ip, u16 dst_port, const void *data, u32 len)
{
    static u8 pkt[1500];
    static volatile int udp_lock = 0;
    if (sock < 0 || sock >= NET_MAX_UDP_SOCKETS) return -1;
    if (!g_udp_socks[sock].in_use) return -1;
    if (len > 1472) return -1;   /* MTU 1500 - 20 IP - 8 UDP */
    s_lock(&udp_lock);
    udp_hdr_t *udp = (udp_hdr_t *)pkt;
    udp->src_port = (u16)((g_udp_socks[sock].local_port >> 8) | (g_udp_socks[sock].local_port << 8));
    udp->dst_port = (u16)((dst_port >> 8) | (dst_port << 8));
    u16 total = (u16)(8 + len);
    udp->length = (u16)((total >> 8) | (total << 8));
    udp->checksum = 0;
    memcpy(pkt + 8, data, len);

    g_udp_socks[sock].remote_ip = dst_ip;
    g_udp_socks[sock].remote_port = dst_port;

    net_send_ip(IP_PROTO_UDP, dst_ip, pkt, 8 + len);
    s_unlock(&udp_lock);
    return (int)len;
}

static void net_handle_udp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < 8) return;
    const udp_hdr_t *udp = (const udp_hdr_t *)payload;
    u16 src_port = (u16)((udp->src_port >> 8) | (udp->src_port << 8)); /* FIX [N3] */
    u16 dst_port = (u16)((udp->dst_port >> 8) | (udp->dst_port << 8)); /* FIX [N3] */
    u16 udp_len = (u16)((udp->length >> 8) | (udp->length << 8)); /* FIX [N3] */
    if (udp_len > len) udp_len = (u16)len;
    if (udp_len < 8) return;
    u32 data_len = udp_len - 8;
    const u8 *data = payload + 8;

    u32 src_ip = ((u32)ip->src_ip[0] << 24) | ((u32)ip->src_ip[1] << 16)
               | ((u32)ip->src_ip[2] << 8) | (u32)ip->src_ip[3];

    /* Сессия 21: demux по dst_port — пакет идёт СОКЕТУ с этим портом
     * (и только ему). Нет сокета — глобальный fallback (обычно NULL:
     * LAN-шум на чужие порты больше не будит ни DNS, ни DHCP). */
    for (int i = 0; i < NET_MAX_UDP_SOCKETS; i++) {
        if (g_udp_socks[i].in_use && g_udp_socks[i].local_port == dst_port) {
            if (g_udp_socks[i].cb)
                g_udp_socks[i].cb(src_ip, src_port, dst_port, data, data_len);
            return;
        }
    }
    if (g_udp_recv_cb) {
        g_udp_recv_cb(src_ip, src_port, dst_port, data, data_len);
    }
}

