/* term.h — совместимость со старой внешней копией headless-терминала
 * (Task 45).
 *
 * Настоящая реализация терминала (полноценный term_t: экранная сетка,
 * VT-режим, скроллбек, sink-вывод для telnetd) живёт в apps.c, публичный
 * API — в apps.h:
 *   typedef struct term_s term_t;                (непрозрачный указатель)
 *   term_t *term_headless_create(void);
 *   void    term_headless_free(term_t *t);
 *   void    term_headless_sink(term_t *t,
 *                  void (*put)(void *ctx, const char *s), void *ctx);
 *   void    term_shell_exec(term_t *t, const char *line);
 *
 * Прежние локальные копии term.c/term.h объявляли тот же API с ДРУГОЙ
 * структурой (struct term_hd), другим порядком аргументов колбэка
 * ((const char*, void*) вместо (void*, const char*)) и другим типом
 * возврата term_shell_exec (int вместо void) — при сборке это давало
 * «conflicting types for 'term_t'» и дубли символов с apps.c. Этот
 * заголовок ничего не переобъявляет: только подключает apps.h и
 * добавляет имена старого API поверх реализаций apps.c/term.c. */
#ifndef TERM_H
#define TERM_H

#include "apps.h"

/* ---- старые имена (эпоха task43) поверх реализаций apps.c ----
 * term_headless_destroy        — синоним term_headless_free;
 * term_headless_banner         — приветствие; telnetd шлёт его сам
 *                                (tnd_hello -> «N2600-OS telnet server»),
 *                                здесь пусто для совместимости;
 * term_headless_exit_requested — старый флаг выхода; в текущей схеме
 *                                telnetd закрывает сессию сам (команда
 *                                exit обрабатывается его строковым
 *                                фильтром), всегда 0. */
void term_headless_destroy(term_t *t);
void term_headless_banner(term_t *t);
int  term_headless_exit_requested(term_t *t);

#endif /* TERM_H */
