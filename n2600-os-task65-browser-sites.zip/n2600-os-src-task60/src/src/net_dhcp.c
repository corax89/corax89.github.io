/* net_dhcp.c — DHCP-клиент для автоматической настройки IP.
 *
 * Поток:
 *   1. Клиент отправляет DHCP DISCOVER (broadcast UDP: src=68, dst=67)
 *   2. DHCP-сервер отвечает DHCP OFFER (с IP-адресом, опциями)
 *   3. Клиент отправляет DHCP REQUEST (з запрошенным IP)
 *   4. DHCP-сервер отвечает DHCP ACK (подтверждает, с lease/опциями)
 *
 * Поддержанные DHCP-опции:
 *   1  = Subnet Mask
 *   3  = Router (Gateway)
 *   6  = DNS Server
 *   51 = IP Address Lease Time
 *   53 = DHCP Message Type
 *   54 = Server Identifier
 *
 * Не поддержано: RENEW/REBIND (lease renewal), DHCPRELEASE.
 */
#include "net.h"
#include "sync.h"
#include "e1000.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);
extern void net_poll(void);

/* [WIFI-DBG-GATE] (Task 43): трассы «мимо: ...» (чужие DHCP-бродкасты
 * соседей/дубли) — под WIFI_DEBUG (см. wifi_core.h; флаг общий).
 * Без флага: кольцо/[DHCP-RTX1]/milestone-печатя работают как раньше,
 * только LAN-шум не захламляет dmesg. */
#ifndef WIFI_DEBUG
#define WIFI_DEBUG 0
#endif

/* DHCP пакеты */
#define DHCP_BOOTREQUEST  1
#define DHCP_BOOTREPLY    2

#define DHCP_OPT_SUBNET   1
#define DHCP_OPT_ROUTER   3
#define DHCP_OPT_DNS      6
#define DHCP_OPT_LEASE    51
#define DHCP_OPT_MSGTYPE  53
#define DHCP_OPT_SERVER   54
#define DHCP_OPT_END      255
#define DHCP_OPT_PAD      0

#define DHCP_MAGIC_COOKIE 0x63538263u  /* в little-endian */

/* DHCP-сообщение (RFC 2131) — 300 байт минимум. */
typedef struct __attribute__((packed)) {
    u8  op;
    u8  htype;
    u8  hlen;
    u8  hops;
    u32 xid;
    u16 secs;
    u16 flags;
    u32 ciaddr;
    u32 yiaddr;
    u32 siaddr;
    u32 giaddr;
    u8  chaddr[16];
    u8  sname[64];
    u8  file[128];
    u8  magic[4];   /* 0x63, 0x82, 0x53, 0x63 */
    u8  options[312];
} dhcp_pkt_t;

/* Состояние DHCP */
static dhcp_state_t g_dhcp_state = DHCP_INIT;
static u32 g_dhcp_xid = 0x12345678;
static u32 g_dhcp_offered_ip = 0;
static u32 g_dhcp_server_id = 0;
static u32 g_dhcp_lease_time = 0;
static u32 g_dhcp_dns_server = 0;

/* ---- печать, видимая В ЛОГЕ ПОЛЯ (dmesg/klog): прежние [dhcp]-строки
 * [DHCP-DBG1] шли ТОЛЬКО в serial — в журнале пользователя их не было,
 * и невозможно было понять, на каком шаге DHCP молчал (поле 27.10:
 * OFFER печатался драйвером «RX prot op=2 xid=наш», а клиент — молчал) */
extern void klog_puts(const char *s);
static void dhcp_log(const char *s)
{
    serial_puts(s);
    serial_puts("\n");
    klog_puts(s);
}

/* ---- [DHCP-Q1] (Task 41): кольцо ПРИНЯТЫХ ответов (4 слота) ----
 * Прежний одиночный буфер терял кадры ДВУМЯ способами: (1) новый пакет
 * перезаписывал непрочитанный; (2) dhcp_take_reply_msgtype поглощал
 * (ready=0) и выбрасывал ЛЮБОЙ пакет (мусор/чужой xid/короткий) —
 * потребление без разбора. Поле 27.10: OFFER печатался мостом драйвера
 * («RX prot ... op=2 sp=67 dp=68 xid=НАШ»), а «DHCP не ответил» — кадр
 * гиб между мостом и разбором. Кольцо + потребление только
 * разобранного слота снимают оба механизма потерь. */
#define DHCP_RX_SLOTS 4
#define DHCP_RX_BUF   600
static u8  g_dhcp_rx[DHCP_RX_SLOTS][DHCP_RX_BUF];
static u32 g_dhcp_rx_len[DHCP_RX_SLOTS];
static volatile u8 g_dhcp_rx_ready[DHCP_RX_SLOTS];
static volatile int g_dhcp_rx_wr = 0;
static volatile int dhcp_rx_lock = 0;
static u32 g_dhcp_garbage = 0;           /* съедено мимо транзакции */
static u32 g_dhcp_garbage_log __attribute__((unused)) = 0; /* лимит печатей мимо (6/транзакцию) */

/* Снимок ПОСЛЕДНЕГО ПРИНЯТОГО пакета (для разбора OFFER/ACK в
 * net_dhcp_acquire — кольцо отдаёт копию через dhcp_take_reply_msgtype,
 * продюсер её не тронет) */
static u8  g_dhcp_rx_cur[DHCP_RX_BUF];
static u32 g_dhcp_cur_len = 0;  /* длина принятого (для трасс/логов) */
static int g_dhcp_cur_valid = 0; /* есть ли валидный снимок */

/* UDP-сокет для DHCP (порт 68) */
static int g_dhcp_sock = -1;

/* Callback для входящих UDP-пакетов на порт 68 (продюсер кольца) */
static void dhcp_udp_cb(u32 src_ip, u16 src_port, u16 dst_port,
                         const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    if (dst_port != 68) return;
    if (len > DHCP_RX_BUF) len = DHCP_RX_BUF;
    s_lock(&dhcp_rx_lock);
    int slot = g_dhcp_rx_wr;
    memcpy(g_dhcp_rx[slot], data, len);
    /* без старья за хвостом пакета: парсер опций сканирует до END,
     * мусор от предыдущего пакета мог выдать ложный msgtype */
    if (len < DHCP_RX_BUF)
        memset(g_dhcp_rx[slot] + len, 0, DHCP_RX_BUF - len);
    g_dhcp_rx_len[slot] = len;
    g_dhcp_rx_ready[slot] = 1;        /* флаг — ПОСЛЕ данных */
    g_dhcp_rx_wr = (slot + 1) % DHCP_RX_SLOTS;
    s_unlock(&dhcp_rx_lock);
}

/* Парсинг DHCP-опций */
/* IPs в DHCP-пакете лежат СЕТЕВЫМ порядком (big-endian), а packed-поле
 * u32 читается процессором как little-endian: 10.0.2.15 (0A 00 02 0F)
 * превращается в 0x0F02000A. В результате мы ЗАПРАШИВАЛИ 15.2.0.10 —
 * сервер честно отвечал NAK («requested a...»). Переставляем байты. */
static u32 dhcp_be_to_host(u32 v)
{
    return ((v & 0xFF) << 24) | ((v & 0xFF00) << 8)
         | ((v >> 8) & 0xFF00) | (v >> 24);
}

static int dhcp_parse_options(const u8 *opts, u32 opts_len, u8 *out_msgtype,
                              u32 *out_server_id, u32 *out_subnet,
                              u32 *out_router, u32 *out_dns, u32 *out_lease)
{
    u32 i = 0;
    while (i < opts_len) {
        u8 type = opts[i++];
        if (type == DHCP_OPT_PAD) continue;
        if (type == DHCP_OPT_END) break;
        if (i >= opts_len) break;
        u8 len = opts[i++];
        if (i + len > opts_len) break;
        switch (type) {
            case DHCP_OPT_MSGTYPE:
                if (len >= 1 && out_msgtype) *out_msgtype = opts[i];
                break;
            case DHCP_OPT_SERVER:
                if (len >= 4 && out_server_id) {
                    *out_server_id = ((u32)opts[i] << 24) | ((u32)opts[i+1] << 16)
                                  | ((u32)opts[i+2] << 8) | (u32)opts[i+3];
                }
                break;
            case DHCP_OPT_SUBNET:
                if (len >= 4 && out_subnet) {
                    *out_subnet = ((u32)opts[i] << 24) | ((u32)opts[i+1] << 16)
                                | ((u32)opts[i+2] << 8) | (u32)opts[i+3];
                }
                break;
            case DHCP_OPT_ROUTER:
                if (len >= 4 && out_router) {
                    *out_router = ((u32)opts[i] << 24) | ((u32)opts[i+1] << 16)
                                | ((u32)opts[i+2] << 8) | (u32)opts[i+3];
                }
                break;
            case DHCP_OPT_DNS:
                if (len >= 4 && out_dns) {
                    *out_dns = ((u32)opts[i] << 24) | ((u32)opts[i+1] << 16)
                             | ((u32)opts[i+2] << 8) | (u32)opts[i+3];
                }
                break;
            case DHCP_OPT_LEASE:
                if (len >= 4 && out_lease) {
                    *out_lease = ((u32)opts[i] << 24) | ((u32)opts[i+1] << 16)
                              | ((u32)opts[i+2] << 8) | (u32)opts[i+3];
                }
                break;
        }
        i += len;
    }
    return 1;
}

/* Собрать DHCP-пакет (DISCOVER или REQUEST) */
static u32 build_dhcp_packet(u8 msgtype, u32 requested_ip, u32 server_id,
                              u8 *out_buf, u32 out_max)
{
    if (out_max < sizeof(dhcp_pkt_t)) return 0;
    dhcp_pkt_t *p = (dhcp_pkt_t *)out_buf;
    memset(p, 0, sizeof(*p));

    p->op = DHCP_BOOTREQUEST;
    p->htype = 1;   /* Ethernet */
    p->hlen = 6;
    p->hops = 0;
    p->xid = g_dhcp_xid;
    p->secs = 0;
    p->flags = 0x0080;   /* broadcast (big-endian) */
    p->ciaddr = 0;
    p->yiaddr = 0;
    p->siaddr = 0;
    p->giaddr = 0;

    u8 mac[6];
    net_get_mac(mac);   /* MAC АКТИВНОГО NIC (не только e1000 —
                          * прежде в chaddr попадал мусор/нули на
                          * virtio/ne2000, часть DHCP-серверов на это
                          * отвечает отказом) */
    memcpy(p->chaddr, mac, 6);
    /* sname, file — нули */

    /* Magic cookie */
    p->magic[0] = 0x63; p->magic[1] = 0x82; p->magic[2] = 0x53; p->magic[3] = 0x63;

    /* Options */
    u8 *opts = p->options;
    u32 oi = 0;
    /* Option 53: Message Type */
    opts[oi++] = DHCP_OPT_MSGTYPE;
    opts[oi++] = 1;
    opts[oi++] = msgtype;
    /* Option 50: Requested IP Address (for REQUEST) */
    if (requested_ip != 0) {
        opts[oi++] = 50;  /* Requested IP Address */
        opts[oi++] = 4;
        opts[oi++] = (u8)((requested_ip >> 24) & 0xFF);
        opts[oi++] = (u8)((requested_ip >> 16) & 0xFF);
        opts[oi++] = (u8)((requested_ip >> 8) & 0xFF);
        opts[oi++] = (u8)(requested_ip & 0xFF);
    }
    /* Option 54: Server Identifier (for REQUEST) */
    if (server_id != 0) {
        opts[oi++] = DHCP_OPT_SERVER;
        opts[oi++] = 4;
        opts[oi++] = (u8)((server_id >> 24) & 0xFF);
        opts[oi++] = (u8)((server_id >> 16) & 0xFF);
        opts[oi++] = (u8)((server_id >> 8) & 0xFF);
        opts[oi++] = (u8)(server_id & 0xFF);
    }
    /* Option 55: Parameter Request List (что мы хотим получить) */
    opts[oi++] = 55;
    opts[oi++] = 4;
    opts[oi++] = DHCP_OPT_SUBNET;   /* 1: Subnet Mask */
    opts[oi++] = DHCP_OPT_ROUTER;   /* 3: Router */
    opts[oi++] = DHCP_OPT_DNS;       /* 6: DNS */
    opts[oi++] = DHCP_OPT_LEASE;    /* 51: Lease Time */
    /* End */
    opts[oi++] = DHCP_OPT_END;

    return sizeof(dhcp_pkt_t);
}

/* Сессия 21: забрать входящий DHCP-пакет и разобрать его тип.
 * Возвращает msgtype (1..6) только для СВОЕЙ транзакции
 * (op==BOOTREPLY и xid==наш), иначе 0 и пакет выбрасывается.
 * Зачем: на корпоративной LAN к порту 68 приходят бродкасты
 * OFFER/ACK ЧУЖИХ DHCP-клиентов и дубли нашего сервера — раньше
 * любой такой пакет принимался «как есть»: чужой xid давал
 * «xid mismatch», дубликат OFFER в фазе ACK — «not an ACK», и вся
 * попытка DHCP РОНЯЛАСЬ (в логе пользователя: «not an ACK» на
 * первой попытке, вторая — BOUND). */
static u8 dhcp_take_reply_msgtype(u32 *out_len)
{
    *out_len = 0;
    for (int n = 0; n < DHCP_RX_SLOTS; n++) {
        if (!g_dhcp_rx_ready[n]) continue;
        /* слот забирается В ЛЮБОМ случае: совпал — разбираем дальше,
         * мусор — освобождаем слот, но НЕ вслепую: причина видна в
         * dmesg ([DHCP-DBG1]) — раньше мусор поглощал одиночный ready,
         * и шанс настоящего OFFER/ACK терялся вместе с ним */
        static u8 snap[DHCP_RX_BUF];
        s_lock(&dhcp_rx_lock);
        if (!g_dhcp_rx_ready[n]) { s_unlock(&dhcp_rx_lock); continue; }
        g_dhcp_rx_ready[n] = 0;
        u32 len = g_dhcp_rx_len[n];
        memcpy(snap, g_dhcp_rx[n], len);
        s_unlock(&dhcp_rx_lock);

        if (len < 240) {   /* короче фиксированной части BOOTP */
            g_dhcp_garbage++;
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): LAN-шум — под флагом */
            if (g_dhcp_garbage_log < 6) {
                g_dhcp_garbage_log++;
                char b[96];
                snprintf(b, sizeof(b),
                         "[dhcp] мимо: короткий пакет len=%u (<240) — срез хвоста/UDP len?",
                         (unsigned)len);
                dhcp_log(b);
            }
#endif
            continue;
        }
        const dhcp_pkt_t *rp = (const dhcp_pkt_t *)snap;
        if (rp->op != DHCP_BOOTREPLY) {
            g_dhcp_garbage++;
#if WIFI_DEBUG
            if (g_dhcp_garbage_log < 6) {
                g_dhcp_garbage_log++;
                char b[96];
                snprintf(b, sizeof(b),
                         "[dhcp] мимо: op=%u (не BOOTREPLY) xid=%08x",
                         (unsigned)rp->op, (unsigned)rp->xid);
                dhcp_log(b);
            }
#endif
            continue;
        }
        if (rp->xid != g_dhcp_xid) {   /* чужая транзакция — шум */
            g_dhcp_garbage++;
#if WIFI_DEBUG
            if (g_dhcp_garbage_log < 6) {
                g_dhcp_garbage_log++;
                char b[112];
                snprintf(b, sizeof(b),
                         "[dhcp] мимо: чужой xid=%08x (наш %08x)",
                         (unsigned)rp->xid, (unsigned)g_dhcp_xid);
                dhcp_log(b);
            }
#endif
            continue;
        }
        u8 mt = 0;
        dhcp_parse_options(rp->options, sizeof(rp->options),
                           &mt, NULL, NULL, NULL, NULL, NULL);
        if (mt == 0) {
            g_dhcp_garbage++;
#if WIFI_DEBUG
            if (g_dhcp_garbage_log < 6) {
                g_dhcp_garbage_log++;
                dhcp_log("[dhcp] мимо: наш xid, но без опции 53 (msgtype=0)");
            }
#endif
            continue;
        }
        /* принятый пакет — в снимок вызывающему */
        memcpy(g_dhcp_rx_cur, snap, len);
        if (len < DHCP_RX_BUF)
            memset(g_dhcp_rx_cur + len, 0, DHCP_RX_BUF - len);
        g_dhcp_cur_len = len;
        g_dhcp_cur_valid = 1;
        *out_len = len;
        return mt;
    }
    return 0;
}

/* Ожидать ACK (с фильтрацией по dhcp_take_reply_msgtype).
 * Возвращает: >0 — длина ACK; -1 — таймаут; -2 — получен NAK
 * (сервер отказал — нужно начинать заново с DISCOVER и новым xid).
 * Сессия 21: дублирующийся OFFER (сервер ретранслировал OFFER, пока
 * мы строили REQUEST) и чужие бродкасты больше НЕ РОНЯЮТ попытку
 * (раньше это был лог «not an ACK» из boot-лога пользователя) —
 * игнорируем их и продолжаем ждать. */
static int wait_for_dhcp_reply(u32 max_ms, const u8 *req_pkt, u32 req_len)
{
    u32 start = timer_ticks();
    u32 need = max_ms;               /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    u32 last_tx = timer_ticks();     /* REQUEST ушёл у вызывающего */
    int retx = 0;
    while ((timer_ticks() - start) < need) {
        u32 rlen = 0;
        u8 mt = dhcp_take_reply_msgtype(&rlen);
        if (mt == 5) {                 /* DHCPACK — наша транзакция */
            g_dhcp_cur_len = rlen;
            {
                char b[64];
                snprintf(b, sizeof(b), "[dhcp] ACK принят (len=%u)",
                         (unsigned)rlen);
                dhcp_log(b);
            }
            return (int)rlen;
        }
        if (mt == 6) {                 /* DHCPNAK */
            dhcp_log("[dhcp] NAK — нужен новый DISCOVER");
            return -2;
        }
        /* mt==0 (шум/чужие/дубли OFFER) и прочие типы — ждать дальше */
        /* [DHCP-RTX1] (Task 41): REQUEST может не дойти или уйти в эфир
         * с задержкой (поле 27.10: точка отшивала станцию ПРЯМО на
         * REQUEST — ACK не уходил вовсе; между OFFER и REQUEST на эфире
         * ~500 мс). Повторяем REQUEST раз в 600 мс, до 6 раз: сервер
         * идемпотентен (RFC 2131 — повтор REQUEST той же транзакции
         * безопасен, ACK придёт снова). */
        if (req_pkt && req_len && retx < 6 &&
            (timer_ticks() - last_tx) >= 600) {
            net_udp_send(g_dhcp_sock, 0xFFFFFFFFu, 67, req_pkt, req_len);
            last_tx = timer_ticks();
            retx++;
            {
                char b[64];
                snprintf(b, sizeof(b), "[dhcp] REQUEST повтор #%u",
                         (unsigned)retx);
                dhcp_log(b);
            }
        }
        net_poll();
        task_yield();
    }
    {
        char b[96];
        snprintf(b, sizeof(b),
                 "[dhcp] ACK не получен за %u мс (мимо съедено: %u)",
                 (unsigned)need, (unsigned)g_dhcp_garbage);
        dhcp_log(b);
    }
    return -1;
}

/* Шаг 1: DISCOVER с ретрансляциями — один broadcast может потеряться
 * (занятая сеть, теряющий свич/мост). Шлём DISCOVER каждые 1.5 с,
 * пока не истечёт окно ожидания OFFER. */
static int wait_offer_with_retry(u32 max_ms)
{
    u32 window = max_ms / 2;
    u32 start = timer_ticks();
    u32 last_tx = 0xFFFFFFFFu;   /* ещё не слали */
    static u8 discover_pkt[600];

    for (;;) {
        u32 elapsed_ms = (timer_ticks() - start);   /* 1 тик = 1 мс (сессия 33) */
        if (elapsed_ms >= window) break;

        if (last_tx == 0xFFFFFFFFu ||
            (timer_ticks() - last_tx) >= 1500) {
            u32 discover_len = build_dhcp_packet(1, 0, 0,
                                                 discover_pkt, sizeof(discover_pkt));
            net_udp_send(g_dhcp_sock, 0xFFFFFFFFu, 67,
                         discover_pkt, discover_len);
            last_tx = timer_ticks();
        }

        /* ждём до ближайшего события: ответа или момента ретрансмита.
         * Сессия 21: принимаем ТОЛЬКО СВОЙ OFFER (mt==2) — чужие
         * бродкасты/дубли выбрасываем и ждём дальше. */
        u32 t0 = timer_ticks();
        while ((timer_ticks() - t0) < 150) {  /* 150 мс квант (1 тик = 1 мс) */
            u32 rlen = 0;
            u8 mt = dhcp_take_reply_msgtype(&rlen);
            if (mt == 2) {                     /* DHCPOFFER, наш xid */
                g_dhcp_cur_len = rlen;
                {
                    /* [DHCP-DBG1]: видно в dmesg — снимает спор «OFFER
                     * печатался драйвером, но клиент молчал» */
                    char b[64];
                    snprintf(b, sizeof(b), "[dhcp] OFFER принят (len=%u)",
                             (unsigned)rlen);
                    dhcp_log(b);
                }
                return (int)rlen;
            }
            /* прочее (шум/чужие) — в корзину и ждать */
            net_poll();
            task_yield();
        }
    }
    /* последний шанс: вдруг ответ уже в буфере */
    {
        u32 rlen = 0;
        u8 mt = dhcp_take_reply_msgtype(&rlen);
        if (mt == 2) {
            g_dhcp_cur_len = rlen;
            {
                char b[64];
                snprintf(b, sizeof(b), "[dhcp] OFFER принят (len=%u, поздний)",
                         (unsigned)rlen);
                dhcp_log(b);
            }
            return (int)rlen;
        }
    }
    return -1;
}

int net_dhcp_acquire(u32 max_ms)
{
    if (!net_nic_present()) return 0;

    /* Открываем UDP-сокет на порту 68 */
    if (g_dhcp_sock < 0) {
        g_dhcp_sock = net_udp_open(68);
        if (g_dhcp_sock < 0) {
            serial_puts("[dhcp] cannot open UDP socket 68\n");
            return 0;
        }
        net_udp_set_callback(dhcp_udp_cb);
    }
    /* [DHCP-Q1]: кольцо ответов — чистые слоты + счётчики транзакции */
    s_lock(&dhcp_rx_lock);
    for (int i = 0; i < DHCP_RX_SLOTS; i++) g_dhcp_rx_ready[i] = 0;
    g_dhcp_rx_wr = 0;
    s_unlock(&dhcp_rx_lock);
    g_dhcp_cur_valid = 0;
    g_dhcp_cur_len = 0;
    g_dhcp_garbage = 0;
    g_dhcp_garbage_log = 0;

    /* Сессия 21: новая транзакция — новый xid (LCG вместо статического
     * 0x12345678+сбросы): сервер видит свежую транзакцию, а повторные
     * попытки не путаются с ответами на старые пакеты в очереди. */
    g_dhcp_xid = g_dhcp_xid * 1103515245u + 12345u;

    /* Сессия 12 (FIX «IP теряется каждые несколько секунд»): НЕ стираем
     * настроенный адрес на время транзакции. Раньше здесь стояло
     * net_set_ip(0) + восстановление в конце: пока DHCP не отвечал
     * (мёртвый сегмент/повторы), netmon каждые ~5 с запускал новую
     * попытку — и адрес «мигал»: 4 с пусто, 5 с на месте. Теперь —
     * транзакционный флаг: исходящий IP = 0.0.0.0 (RFC 2131), а
     * видимый адрес остаётся до успешного обновления. */
    u32 saved_ip = net_get_ip();
    net_dhcp_txn_begin();
#define DHCP_TXN_END() do { net_dhcp_txn_end(); } while (0)

    /* Шаг 1: DISCOVER (с ретрансляциями) */
    dhcp_log("[dhcp] DISCOVER (xid ожидается в ответах)");
    g_dhcp_state = DHCP_SELECTING;
    int r = wait_offer_with_retry(max_ms);
    if (r <= 0) {
        char b[96];
        snprintf(b, sizeof(b),
                 "[dhcp] OFFER не получен за %u мс (мимо съедено: %u)",
                 (unsigned)(max_ms / 2), (unsigned)g_dhcp_garbage);
        dhcp_log(b);
        (void)saved_ip;
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }

    /* Парсим OFFER — [DHCP-Q1]: из снимка принятого пакета */
    dhcp_pkt_t *offer = (dhcp_pkt_t *)g_dhcp_rx_cur;
    if (offer->op != DHCP_BOOTREPLY) {
        serial_puts("[dhcp] not a BOOTREPLY\n");
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }
    if (offer->xid != g_dhcp_xid) {
        serial_puts("[dhcp] xid mismatch\n");
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }
    g_dhcp_offered_ip = dhcp_be_to_host(offer->yiaddr);   /* FIX: порядок байт! */
    /* Парсим опции OFFER */
    u8 msgtype = 0;
    u32 server_id = 0, subnet = 0, router = 0, dns = 0, lease = 0;
    dhcp_parse_options(offer->options, sizeof(offer->options),
                       &msgtype, &server_id, &subnet, &router, &dns, &lease);
    if (msgtype != 2) {  /* 2 = OFFER */
        serial_puts("[dhcp] not an OFFER\n");
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }
    g_dhcp_server_id = server_id;
    g_dhcp_lease_time = lease;
    g_dhcp_dns_server = dns;

    /* Шаг 2: REQUEST */
    {
        char b[96], ib[16];
        net_ntoa(g_dhcp_offered_ip, ib, sizeof(ib));
        snprintf(b, sizeof(b), "[dhcp] REQUEST отправлен (запрашиваем %s)", ib);
        dhcp_log(b);
    }
    g_dhcp_state = DHCP_REQUESTING;
    static u8 request_pkt[600];
    u32 request_len = build_dhcp_packet(3, g_dhcp_offered_ip, g_dhcp_server_id,
                                         request_pkt, sizeof(request_pkt));
    /* Broadcast REQUEST (стандарт требует broadcast) */
    net_udp_send(g_dhcp_sock, 0xFFFFFFFFu, 67, request_pkt, request_len);

    /* Ждём ACK (с фильтрацией: дубли OFFER/чужие пакеты не мешают;
     * NAK — немедленный отказ попытки; [DHCP-RTX1] — REQUEST
     * ретранслируется внутри окна) */
    r = wait_for_dhcp_reply(max_ms / 2, request_pkt, request_len);
    if (r == -2) {
        /* NAK: адрес/параметры отказаны — попытка закрыта; следующая
         * попытка netmon начнёт с DISCOVER и новым xid */
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }
    if (r <= 0) {
        dhcp_log("[dhcp] ACK не пришел (см. причину выше)");
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }

    /* Парсим ACK — из снимка принятого пакета */
    dhcp_pkt_t *ack = (dhcp_pkt_t *)g_dhcp_rx_cur;
    if (ack->op != DHCP_BOOTREPLY || ack->xid != g_dhcp_xid) {
        serial_puts("[dhcp] ACK invalid\n");
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }
    msgtype = 0;
    subnet = 0; router = 0; dns = 0; lease = 0;
    dhcp_parse_options(ack->options, sizeof(ack->options),
                       &msgtype, NULL, &subnet, &router, &dns, &lease);
    if (msgtype != 5) {  /* 5 = ACK */
        serial_puts("[dhcp] not an ACK\n");
        DHCP_TXN_END();
        g_dhcp_state = DHCP_INIT;
        return 0;
    }

    /* Устанавливаем полученные параметры (yiaddr — сетевой порядок!) */
    u32 our_ip = dhcp_be_to_host(ack->yiaddr);   /* FIX: порядок байт */
    if (our_ip == 0) our_ip = g_dhcp_offered_ip;
    if (lease > 0) g_dhcp_lease_time = lease;
    if (dns > 0) g_dhcp_dns_server = dns;

    net_dhcp_txn_end();          /* сначала выключаем 0.0.0.0-режим */
    net_set_ip(our_ip);
    if (subnet != 0) net_set_netmask(subnet);
    if (router != 0) net_set_gateway(router);
    if (dns != 0) net_dns_set_server(dns);

    g_dhcp_state = DHCP_BOUND;
    {
        char b[80], ib[16];
        net_ntoa(our_ip, ib, sizeof(ib));
        snprintf(b, sizeof(b), "[dhcp] BOUND: IP %s настроен", ib);
        dhcp_log(b);
    }
    return 1;
}

dhcp_state_t net_dhcp_state(void)
{
    return g_dhcp_state;
}

/* Сброс транзакции DHCP (сессия 11): вызывается при смене активного
 * адаптера — новая транзакция с новым xid, иначе сервер отвечает на
 * старый exchange (или молчит). */
void net_dhcp_reset(void)
{
    g_dhcp_state = DHCP_INIT;
    g_dhcp_xid++;
    g_dhcp_offered_ip = 0;
    g_dhcp_server_id = 0;
    /* [DHCP-Q1]: сброс кольца ответов */
    s_lock(&dhcp_rx_lock);
    for (int i = 0; i < DHCP_RX_SLOTS; i++) g_dhcp_rx_ready[i] = 0;
    g_dhcp_rx_wr = 0;
    s_unlock(&dhcp_rx_lock);
    g_dhcp_cur_valid = 0;
    g_dhcp_cur_len = 0;
}
