/* oslog.c — общий слой префиксного лога (реализация, Task 49). См. oslog.h. */
#include "oslog.h"
#include "string.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

void oslog_puts(const char *tag, const char *s)
{
    char full[180];
    if (!tag) tag = "log";
    if (!s) s = "";
    snprintf(full, sizeof(full), "[%s] %s\n", tag, s);
    serial_puts(full);                    /* ОДНА печать — атомарно на строку */
    u32 fl = (u32)strlen(full);
    if (fl && full[fl - 1] == '\n') full[fl - 1] = 0;
    klog_puts(full);                      /* без хвостового \n (dmesg без пустых) */
}

void oslogf(const char *tag, const char *fmt, ...)
{
    char b[160];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(b, sizeof(b), fmt, ap);
    __builtin_va_end(ap);
    oslog_puts(tag, b);
}
