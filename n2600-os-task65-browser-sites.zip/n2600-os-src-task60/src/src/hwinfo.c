/* hwinfo.c — hwdet-подобная диагностика железа (сессия 90).
 * См. hwinfo.h: ACPI-таблицы + AML-скан DSDT + SMBIOS + CPUID/TSC.
 * ТОЛЬКО ЧТЕНИЕ: любые обращения к памяти — константные, аппаратных
 * записей нет (порты/MMIO не трогаем в принципе). */
#include "types.h"
#include "string.h"
#include "timer.h"
#include "hwinfo.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

static void hw_log(const char *s)
{
    serial_puts("[boot] ");
    serial_puts(s);
    serial_puts("\n");
    klog_puts(s);
}

static void hw_logf(const char *fmt, ...)
{
    char b[128];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(b, sizeof(b), fmt, ap);
    __builtin_va_end(ap);
    hw_log(b);
}

/* ============================ ACPI-таблицы ============================ */

/* RSDP: "RSD PTR " + чексумма. Найти: EBDA (0x40E) и E0000-FFFFF.
 * GCC [8+]: разыменование литерального адреса 0x40E (BDA) отвергается
 * -Warray-bounds — глушим ТОЛЬКО здесь (как в smp.c; доступ корректен:
 * плоская модель памяти, BDA всегда по 0x400). */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Warray-bounds"
static int rsdp_checksum_ok(const u8 *p)
{
    u8 sum = 0;
    for (int i = 0; i < 20; i++) sum = (u8)(sum + p[i]);
    return sum == 0;
}

static const u8 *rsdp_find(void)
{
    /* EBDA: сегмент в слове 0x40E, обычно 9FC0-9F80 (1 КиБ) */
    u32 ebda = ((u32)*(const volatile u16 *)0x40Eu) << 4;
    if (ebda >= 0x80000 && ebda < 0x9F000) {
        for (u32 a = ebda; a + 20 <= ebda + 0x400; a += 16)
            if (!memcmp((const void *)(unsigned long)a, "RSD PTR ", 8) &&
                rsdp_checksum_ok((const u8 *)a))
                return (const u8 *)a;
    }
    for (u32 a = 0xE0000u; a + 20 <= 0xFFFFFu; a += 16)
        if (!memcmp((const void *)(unsigned long)a, "RSD PTR ", 8) &&
            rsdp_checksum_ok((const u8 *)a))
            return (const u8 *)a;
    return 0;
}
#pragma GCC diagnostic pop

/* Заголовок ACPI-таблицы (hwdet acpi_t) */
typedef struct {
    char     sig[4];
    u32      len;
    u8       rev;
    u8       chksum;
    char     oem[6];
    char     oemtid[8];
    u32      oemrev;
    u32      cid;
    u32      crev;
} __attribute__((packed)) acpi_hdr_t;

#define ACPI_MAX_TABLES 16
static struct {
    char  sig[5];
    u8    rev;
    u32   len;
    int   chk_ok;
} tbl[ACPI_MAX_TABLES];
static int      tbl_count   = 0;
static char     acpi_oem[7] = "";
static int      acpi_rev    = 0;
static const u8 *fadt_p     = 0;
static const u8 *madt_p     = 0;
static const u8 *hpet_p     = 0;
static const u8 *mcfg_p     = 0;
static const u8 *dsdt_p     = 0;
static u32       dsdt_len   = 0;

static int hdr_checksum_ok(const acpi_hdr_t *h)
{
    const u8 *p = (const u8 *)h;
    u8 sum = 0;
    if (h->len < sizeof(acpi_hdr_t) || h->len > (1u << 20)) return 0;
    for (u32 i = 0; i < h->len; i++) sum = (u8)(sum + p[i]);
    return sum == 0;
}

/* Пройти контейнер (RSDT: u32-записи, XSDT: u64) и собрать таблицы */
static void walk_container(const u8 *base, int is_xsdt)
{
    if (!base) return;
    const acpi_hdr_t *h = (const acpi_hdr_t *)base;
    u32 hlen = h->len;
    if (hlen < 44 || hlen > (1u << 20)) return;
    u32 entries = (hlen - sizeof(acpi_hdr_t)) / (is_xsdt ? 8u : 4u);
    const u8 *p = base + sizeof(acpi_hdr_t);
    for (u32 i = 0; i < entries && tbl_count < ACPI_MAX_TABLES; i++) {
        u32 addr;
        if (is_xsdt) {
            addr = (u32)(*(const u64 *)(p + i * 8) & 0xFFFFFFFFu);
        } else {
            addr = *(const u32 *)(p + i * 4);
        }
        if (!addr || addr < 0x1000) continue;
        const acpi_hdr_t *t = (const acpi_hdr_t *)(unsigned long)addr;
        if (memcmp(t->sig, "RSDT", 4) == 0 || memcmp(t->sig, "XSDT", 4) == 0)
            continue;
        int dup = 0;
        for (int j = 0; j < tbl_count; j++)
            if (!memcmp(tbl[j].sig, t->sig, 4) &&
                tbl[j].len == t->len) { dup = 1; break; }
        if (dup) continue;      /* одинаковые SSDT не размножаем в списке */
        int idx = tbl_count++;
        memcpy(tbl[idx].sig, t->sig, 4);
        tbl[idx].sig[4]  = 0;
        tbl[idx].rev     = t->rev;
        tbl[idx].len     = t->len;
        tbl[idx].chk_ok  = hdr_checksum_ok(t);
        if (!memcmp(t->sig, "FACP", 4)) fadt_p = (const u8 *)t;
        else if (!memcmp(t->sig, "APIC", 4)) madt_p = (const u8 *)t;
        else if (!memcmp(t->sig, "HPET", 4)) hpet_p = (const u8 *)t;
        else if (!memcmp(t->sig, "MCFG", 4)) mcfg_p = (const u8 *)t;
    }
}

static void acpi_scan(void)
{
    const u8 *rsdp = rsdp_find();
    if (!rsdp) {
        hw_log("[hwinfo] ACPI: RSDP не найден (эмулятор/старый BIOS)");
        return;
    }
    acpi_rev = rsdp[15];
    memcpy(acpi_oem, rsdp + 9, 6);
    acpi_oem[6] = 0;
    /* OEM ID в заголовках обычно информативнее; берём из RSDP */

    if (acpi_rev >= 2) {
        u64 xsdt = *(const u64 *)(rsdp + 24);
        if (xsdt && xsdt < 0x100000000ull) walk_container((const u8 *)(unsigned long)xsdt, 1);
    }
    if (tbl_count == 0) {
        u32 rsdt = *(const u32 *)(rsdp + 16);
        if (rsdt) walk_container((const u8 *)(unsigned long)rsdt, 0);
    }

    /* DSDT: из FADT (поле +40, X-поле +140 для rev 2+) */
    if (fadt_p) {
        u32 frev = fadt_p[9];
        u64 dsdt64 = 0;
        if (frev >= 2) dsdt64 = *(const u64 *)(fadt_p + 140);
        u32 dsdt32 = *(const u32 *)(fadt_p + 40);
        u64 d = dsdt64 ? dsdt64 : (u64)dsdt32;
        if (d && d < 0x100000000ull) {
            const acpi_hdr_t *t = (const acpi_hdr_t *)(unsigned long)d;
            if (!memcmp(t->sig, "DSDT", 4) && t->len > sizeof(acpi_hdr_t) &&
                t->len < (1u << 20)) {
                dsdt_p   = (const u8 *)t;
                dsdt_len = t->len - sizeof(acpi_hdr_t);
                /* DSDT тоже в списке таблиц (для сводки чексуммы) */
                if (tbl_count < ACPI_MAX_TABLES) {
                    int idx = tbl_count++;
                    memcpy(tbl[idx].sig, "DSDT", 5);
                    tbl[idx].rev    = t->rev;
                    tbl[idx].len    = t->len;
                    tbl[idx].chk_ok = hdr_checksum_ok(t);
                }
            }
        }
    }
}

void hwinfo_acpi_summary(char *out, int n)
{
    if (!tbl_count && !dsdt_p) {
        snprintf(out, n, "ACPI: нет (RSDP не найден)");
        return;
    }
    snprintf(out, n, "ACPI %u.%u, таблиц %d, OEM %s",
             (unsigned)(acpi_rev >= 2 ? 2u : 1u), 0u,
             tbl_count, acpi_oem[0] ? acpi_oem : "n/a");
}

void hwinfo_acpi_tables(char *out, int n)
{
    int w = 0;
    out[0] = 0;
    for (int i = 0; i < tbl_count && w < n - 6; i++) {
        int w2 = snprintf(out + w, n - w, "%s%s ", w ? "" : "", tbl[i].sig);
        if (w2 < 0 || w2 >= n - w) break;
        w += w2;
    }
    if (w == 0) snprintf(out, n, "-");
}

void hwinfo_acpi_dsdt(char *out, int n)
{
    if (!dsdt_p) { snprintf(out, n, "DSDT: нет"); return; }
    int idx = -1;
    for (int i = 0; i < tbl_count; i++)
        if (!memcmp(tbl[i].sig, "DSDT", 4)) { idx = i; break; }
    snprintf(out, n, "DSDT %u КиБ rev %u, chk %s",
             (unsigned)(dsdt_len >> 10),
             idx >= 0 ? (unsigned)tbl[idx].rev : (unsigned)dsdt_p[9],
             idx >= 0 ? (tbl[idx].chk_ok ? "OK" : "BAD!") : "n/a");
}

/* FADT: профиль (смещение 45), SCI_INT (46), PM1a_CNT (64) */
void hwinfo_fadt_summary(char *out, int n)
{
    if (!fadt_p) { snprintf(out, n, "FADT: нет"); return; }
    static const char *prof[] = {
        "Unspec", "Desktop", "Mobile", "Workstation", "Ent.Server",
        "SMB", "App.Server", "Perf.Server" };
    u8 pr = fadt_p[45];
    u16 sci = *(const u16 *)(fadt_p + 46);
    u32 pm1a = *(const u32 *)(fadt_p + 64);
    snprintf(out, n, "FADT: %s, SCI %u, PM1a_CNT %04x",
             pr < 8 ? prof[pr] : "Other",
             (unsigned)sci, (unsigned)pm1a);
}

/* MADT: LAPIC-адрес (36), записи с 44 */
void hwinfo_madt_summary(char *out, int n)
{
    if (!madt_p) { snprintf(out, n, "MADT: нет"); return; }
    u32 len = ((const acpi_hdr_t *)madt_p)->len;
    u32 lapic = *(const u32 *)(madt_p + 36);
    u32 lapic_n = 0, ioapic_n = 0;
    u32 ioapic_addr = 0;
    const u8 *p   = madt_p + 44;
    const u8 *end = madt_p + len;
    while (p + 2 <= end) {
        u8 type = p[0], el = p[1];
        if (el < 2 || p + el > end) break;
        if (type == 0 && el >= 8 && (p[4] & 1)) lapic_n++;          /* LAPIC enabled */
        if (type == 9 && el >= 16 && (p[12] & 1)) lapic_n++;        /* X2APIC */
        if (type == 1 && el >= 12) {
            ioapic_n++;
            if (!ioapic_addr) ioapic_addr = *(const u32 *)(p + 4);
        }
        p += el;
    }
    if (ioapic_n)
        snprintf(out, n, "MADT: %u LAPIC, %u IOAPIC @%08x",
                 (unsigned)lapic_n, (unsigned)ioapic_n, (unsigned)ioapic_addr);
    else
        snprintf(out, n, "MADT: %u LAPIC, LAPIC @%08x",
                 (unsigned)lapic_n, (unsigned)lapic);
}

void hwinfo_hpet_summary(char *out, int n)
{
    if (!hpet_p) { snprintf(out, n, ""); return; }
    u8 as = hpet_p[44];                     /* GAS: address space id */
    u64 base = *(const u64 *)(hpet_p + 48);
    if (as == 0 && base)
        snprintf(out, n, "HPET @%08x", (unsigned)(u32)base);
    else
        snprintf(out, n, "");
}

void hwinfo_mcfg_summary(char *out, int n)
{
    if (!mcfg_p) { snprintf(out, n, ""); return; }
    u64 base = *(const u64 *)(mcfg_p + 44);
    if (base)
        snprintf(out, n, "PCIe ECAM @%08x", (unsigned)(u32)base);
    else
        snprintf(out, n, "");
}

/* ===================== DSDT: AML-скан устройств ===================== */
/* Идея hwdet: платформа сама перечисляет свои устройства в DSDT
 * (Device() с _HID/_ADR и _CRS). Полный AML-интерпретатор не нужен —
 * достаточно РАЗОРАТЬ поток именованных объектов. Сканируются:
 *   Device (0x5B82), Processor (0x5B83), PowerRes (0x5B84),
 *   ThermalZone (0x5B85), Scope (0x10), Name (0x08).
 * Method()-тела пропускаются (динамику не вычисляем), поля Field
 * пропускаются по PkgLength. За пределы буфера не выходим. */

#define HW_MAX_DEV 48

typedef struct {
    char hid[12];        /* "PNP0303"/"ACPI0003"/"CPU"; "" = нет _HID   */
    char name[5];        /* имя объекта (NameSeg, 4 символа)            */
    u32  adr;            /* _ADR (0xFFFFFFFF = нет)                     */
    int  n_io, n_irq, n_mem, n_dma;
    u16  io_base[4];
    u8   io_len[4];
    u8   irq[4];
    u32  mem_base, mem_len;
} hwdev_t;

static hwdev_t dev[HW_MAX_DEV];
static int  dev_n     = 0;      /* записанных устройств              */
static int  dev_total = 0;      /* всего Device()/Processor()/TZ/PR  */

static const char *pnp_name(const char *id)
{
    static const struct { const char *id; const char *ru; } t[] = {
        { "PNP0000", "PIC (контроллер прерываний)" },
        { "PNP0001", "EISA-PIC" },
        { "PNP0003", "IOAPIC" },
        { "PNP0100", "Системный таймер (PIT)" },
        { "PNP0103", "HPET-таймер" },
        { "PNP0200", "DMA-контроллер" },
        { "PNP0202", "DMA (32-бит)" },
        { "PNP0300", "Клавиатура (8042)" },
        { "PNP0303", "Клавиатура PS/2" },
        { "PNP0306", "Клавиатура PS/2" },
        { "PNP0343", "Клавиатура PS/2" },
        { "PNP0F03", "Мышь (serial)" },
        { "PNP0F13", "Мышь PS/2" },
        { "MSFT0001", "Тачпад (PS/2 precision)" },
        { "SYN0002", "Тачпад Synaptics" },
        { "PNP0400", "LPT-порт" },
        { "PNP0401", "LPT-порт (ECP)" },
        { "PNP0501", "COM-порт 16550A" },
        { "PNP0502", "COM-порт" },
        { "PNP0700", "Контроллер НГМД" },
        { "PNP0800", "Системный динамик" },
        { "PNP0B00", "RTC/CMOS" },
        { "PNP0C01", "Карта памяти системы" },
        { "PNP0C02", "Зарезерв. ресурсы платы" },
        { "PNP0C04", "Сопроцессор x87" },
        { "PNP0C08", "ACPI-оборудование" },
        { "PNP0C09", "Встроенный контроллер (EC)" },
        { "PNP0C0A", "Батарея" },
        { "PNP0C0B", "Вентилятор/тепло" },
        { "PNP0C0D", "Датчик крышки" },
        { "PNP0C0E", "Кнопка сна" },
        { "PNP0C0F", "PCI-линк прерываний" },
        { "PNP0C14", "WMI" },
        { "PNP0A03", "PCI-шина (мост)" },
        { "PNP0A05", "PCI-контейнер" },
        { "PNP0A06", "PCI-контейнер" },
        { "PNP0A08", "PCIe-хост-мост" },
        { "ACPI0001", "SMBus 1.0" },
        { "ACPI0002", "SMBus 1.0" },
        { "ACPI0003", "Блок питания (AC)" },
        { "ACPI0005", "SMBus 2.0" },
        { "ATK0100", "ASUS ACPI (хоткеи)" },
        { "ATK0110", "ASUS ACPI (датчики)" },
        { "ENE0100", "EC (ENE)" },
        { 0, 0 }
    };
    for (int i = 0; t[i].id; i++)
        if (!strcmp(t[i].id, id)) return t[i].ru;
    return 0;
}

/* PkgLength: *len ВКЛЮЧАЕТ байт-заголовок и доп. байты.
 * Возвращает число съеденных байтов. */
static const u8 *aml_pkglen(const u8 *p, const u8 *end, u32 *len)
{
    if (p >= end) { *len = 0; return end; }
    u8 b = *p++;
    if ((b >> 6) == 0) { *len = b & 0x3F; return p; }
    u32 n = b >> 6;
    u32 L = b & 0x0F;
    for (u32 i = 1; i <= n && p < end; i++, p++) L |= (u32)(*p) << (4 * i);
    *len = L;
    return p;
}

/* NamePath: последний NameSeg -> out[5]; возврат после него */
static const u8 *aml_namepath(const u8 *p, const u8 *end, char out[5])
{
    out[0] = 0;
    if (p >= end) return end;
    u8 c = *p++;
    if (c == '\\' || c == '^') {
        while (p < end && (*p == '^')) p++;      /* '\' может быть и с '^' */
        if (p >= end) return end;
        c = *p++;
    }
    if (c == 0x2F) {                             /* MultiNamePrefix */
        if (p >= end) return end;
        u8 cnt = *p++;
        for (u8 i = 0; i < cnt; i++) {
            if (p + 4 > end) return end;
            if (i + 1 == cnt || out[0] == 0) {
                memcpy(out, p, 4);
                out[4] = 0;
            }
            p += 4;
        }
        return p;
    }
    if (c == 0x2E) {                             /* DualNamePrefix */
        if (p + 8 > end) return end;
        memcpy(out, p + 4, 4);
        out[4] = 0;
        return p + 8;
    }
    /* NameSeg: 4 байта, ведущий уже съеден */
    out[0] = (char)c;
    if (p + 3 > end) return end;
    out[1] = (char)p[0];
    out[2] = (char)p[1];
    out[3] = (char)p[2];
    out[4] = 0;
    return p + 3;
}

/* EisaId (упакованный PNP) -> "PNPxxxx" (дешифровка по ACPI-спеке) */
static void eisa_decode(u32 v, char out[8])
{
    static const char hex[] = "0123456789ABCDEF";
    out[0] = (char)('@' + ((v >> 26) & 0x1F));
    out[1] = (char)('@' + ((v >> 21) & 0x1F));
    out[2] = (char)('@' + ((v >> 16) & 0x1F));
    out[3] = hex[(v >> 12) & 0xF];
    out[4] = hex[(v >>  8) & 0xF];
    out[5] = hex[(v >>  4) & 0xF];
    out[6] = hex[ v        & 0xF];
    out[7] = 0;
}

/* Разобрать ресурсный шаблон (_CRS) в запись устройства */
static void crs_parse(const u8 *p, u32 len, hwdev_t *d)
{
    const u8 *end = p + len;
    while (p + 1 <= end) {
        u8 b0 = *p;
        if (b0 == 0x79) break;                   /* EndTag */
        if (b0 & 0x80) {                         /* крупный элемент */
            if (p + 3 > end) break;
            u32 type = b0 & 0x7Fu;
            u32 L = (u32)p[1] | ((u32)p[2] << 8);
            const u8 *d0 = p + 3;
            if (d0 + L > end) break;
            if (type == 0x06 && L >= 9) {        /* Memory32Fixed */
                u32 base = (u32)d0[1] | ((u32)d0[2] << 8) |
                           ((u32)d0[3] << 16) | ((u32)d0[4] << 24);
                u32 ml   = (u32)d0[5] | ((u32)d0[6] << 8) |
                           ((u32)d0[7] << 16) | ((u32)d0[8] << 24);
                if (!d->n_mem) { d->mem_base = base; d->mem_len = ml; }
                d->n_mem++;
            } else if (type == 0x09 && L >= 3) { /* Extended IRQ */
                u8 cnt = d0[2];
                for (u8 i = 0; i < cnt; i++) {
                    u32 irq = (u32)d0[3 + 4 * i] |
                              ((u32)d0[4 + 4 * i] << 8) |
                              ((u32)d0[5 + 4 * i] << 16) |
                              ((u32)d0[6 + 4 * i] << 24);
                    if (irq < 256 && d->n_irq < 4) d->irq[d->n_irq++] = (u8)irq;
                }
            }
            p = d0 + L;
        } else {                                 /* малый элемент */
            u32 type = (b0 >> 3) & 0x0Fu;
            u32 L = b0 & 0x07;
            const u8 *d0 = p + 1;
            if (d0 + L > end) break;
            if (type == 0x04 && L >= 2) {        /* IRQ */
                u16 mask = (u16)(d0[0] | (d0[1] << 8));
                for (int i = 0; i < 16; i++)
                    if (mask & (1u << i) && d->n_irq < 4)
                        d->irq[d->n_irq++] = (u8)i;
            } else if (type == 0x05) {           /* DMA */
                d->n_dma++;
            } else if (type == 0x08 && L >= 7) { /* IO */
                u16 base = (u16)(d0[1] | (d0[2] << 8));
                if (d->n_io < 4) {
                    d->io_base[d->n_io] = base;
                    d->io_len[d->n_io]  = d0[6];
                    d->n_io++;
                }
            } else if (type == 0x09 && L >= 3) { /* Fixed IO */
                u16 base = (u16)(d0[0] | (d0[1] << 8));
                if (d->n_io < 4) {
                    d->io_base[d->n_io] = base;
                    d->io_len[d->n_io]  = d0[2];
                    d->n_io++;
                }
            }
            p = d0 + L;
        }
    }
}

/* TermArg (упрощённо): kind 1 = целое, 2 = строка, 0 = прочее/не понял */
static const u8 *aml_value(const u8 *p, const u8 *end,
                           u32 *ival, char *sval, int ssz, int *kind)
{
    *kind = 0;
    if (p >= end) return end;
    u8 op = *p++;
    switch (op) {
    case 0x00: *ival = 0; *kind = 1; break;              /* ZeroOp */
    case 0x01: *ival = 1; *kind = 1; break;              /* OneOp  */
    case 0x0A: if (p < end) { *ival = *p++; *kind = 1; } break;
    case 0x0B: if (p + 2 <= end) {
                   *ival = (u32)p[0] | ((u32)p[1] << 8);
                   p += 2; *kind = 1;
               } break;
    case 0x0C: if (p + 4 <= end) {
                   *ival = (u32)p[0] | ((u32)p[1] << 8) |
                           ((u32)p[2] << 16) | ((u32)p[3] << 24);
                   p += 4; *kind = 1;
               } break;
    case 0x0E: if (p + 8 <= end) {                       /* QWordConst */
                   *ival = (u32)p[0] | ((u32)p[1] << 8) |
                           ((u32)p[2] << 16) | ((u32)p[3] << 24);
                   p += 8; *kind = 1;
               } break;
    case 0x0D: {                                         /* StringPrefix */
                   int i = 0;
                   while (p < end && *p && i < ssz - 1) sval[i++] = (char)*p++;
                   sval[i] = 0;
                   if (p < end) p++;                     /* NUL */
                   *kind = 2;
               } break;
    case 0x5B: if (p < end) p++; break;                  /* ext-оп: пропустить */
    default:   break;                                    /* NamePath и пр. */
    }
    return p;
}

static hwdev_t *dev_new(const char *name)
{
    dev_total++;
    if (dev_n >= HW_MAX_DEV) return 0;
    hwdev_t *d = &dev[dev_n++];
    memset(d, 0, sizeof(*d));
    d->adr = 0xFFFFFFFFu;
    if (name) {
        d->name[0] = name[0]; d->name[1] = name[1];
        d->name[2] = name[2]; d->name[3] = name[3];
        d->name[4] = 0;
    }
    return d;
}

/* Обход DefinitionBlock; обрабатывает только именованные объекты */
static void aml_walk(const u8 *p, const u8 *end, int depth)
{
    hwdev_t *cur = 0;
    while (p < end) {
        u8 b = *p;
        if (b == 0x5B) {                                  /* ExtOp */
            if (p + 2 > end) return;
            u8 b2 = p[1];
            if (b2 == 0x82 || b2 == 0x83 || b2 == 0x84 || b2 == 0x85) {
                /* Device/Processor/PowerRes/ThermalZone: pkglen + имя */
                u32 L = 0;
                const u8 *q = aml_pkglen(p + 2, end, &L);
                if (L < 5 || q + L > end) return;
                if (depth < 8) {
                    char nm[5];
                    const u8 *q2 = aml_namepath(q, q + L, nm);
                    hwdev_t *saved = cur;
                    cur = dev_new(nm);
                    if (b2 == 0x83 && cur) strcpy(cur->hid, "CPU");
                    /* тело: Name/Device/Scope внутри (у Processor тоже
                     * могут быть Name) */
                    aml_walk(q2, q + L, depth + 1);
                    cur = saved;
                }
                p = q + L;
                continue;
            }
            if (b2 == 0x80) {                             /* OpRegion */
                char nm[5];
                const u8 *q = aml_namepath(p + 2, end, nm);
                u32 iv; int kind; char sv[8];
                q = aml_value(q, end, &iv, sv, sizeof(sv), &kind);  /* тип региона */
                q = aml_value(q, end, &iv, sv, sizeof(sv), &kind);  /* смещение */
                q = aml_value(q, end, &iv, sv, sizeof(sv), &kind);  /* длина */
                p = q;
                continue;
            }
            if (b2 == 0x86 || b2 == 0x87 || b2 == 0x88) { /* Field/IndexField/BankField */
                u32 L = 0;
                const u8 *q = aml_pkglen(p + 2, end, &L);
                if (L < 2 || q + L > end) return;
                p = q + L;                                /* тело не разбираем */
                continue;
            }
            p += 2;                                       /* прочие ext-опы */
            continue;
        }
        if (b == 0x10) {                                  /* Scope */
            u32 L = 0;
            const u8 *q = aml_pkglen(p + 1, end, &L);
            if (L < 5 || q + L > end) return;
            if (depth < 8) {
                char nm[5];
                const u8 *q2 = aml_namepath(q, q + L, nm);
                aml_walk(q2, q + L, depth + 1);
            }
            p = q + L;
            continue;
        }
        if (b == 0x14) {                                  /* Method: пропустить */
            u32 L = 0;
            const u8 *q = aml_pkglen(p + 1, end, &L);
            if (L < 5 || q + L > end) return;
            p = q + L;
            continue;
        }
        if (b == 0x06) {                                  /* Alias */
            char nm[5];
            p = aml_namepath(p + 1, end, nm);
            p = aml_namepath(p, end, nm);
            continue;
        }
        if (b == 0x08) {                                  /* Name */
            char nm[5];
            const u8 *q = aml_namepath(p + 1, end, nm);
            u32 iv = 0;
            char sv[16];
            int kind = 0;
            if (q >= end) return;
            if (q < end && *q == 0x11) {                  /* Buffer (_CRS) */
                u32 L = 0;
                const u8 *bq = aml_pkglen(q + 1, end, &L);
                if (L < 2 || bq + L > end) return;
                /* BufferSize TermArg (обычно WordConst), затем данные */
                u32 bs = 0;
                const u8 *data = aml_value(bq, bq + L, &bs, sv, sizeof(sv), &kind);
                if (cur && (!strcmp(nm, "_CRS") || !strcmp(nm, "_PRS"))) {
                    if (data < bq + L)
                        crs_parse(data, (u32)((bq + L) - data), cur);
                }
                p = bq + L;
                continue;
            }
            q = aml_value(q, end, &iv, sv, sizeof(sv), &kind);
            if (cur) {
                if (!strcmp(nm, "_HID") && cur->hid[0] == 0) {
                    if (kind == 1) eisa_decode(iv, cur->hid);
                    else if (kind == 2) {
                        strncpy(cur->hid, sv, sizeof(cur->hid) - 1);
                        cur->hid[sizeof(cur->hid) - 1] = 0;
                    }
                } else if (!strcmp(nm, "_ADR") && kind == 1) {
                    cur->adr = iv;
                }
            }
            p = q;
            continue;
        }
        if (b == 0x0D) {                                  /* строка вне Name */
            p++;
            while (p < end && *p) p++;
            if (p < end) p++;
            continue;
        }
        if (b >= 0x0A && b <= 0x0C) {                     /* константы */
            static const u8 sz[3] = { 1, 2, 4 };
            p += 1 + sz[b - 0x0A];
            continue;
        }
        if (b == 0x0E) { p += 9; continue; }
        if (b == 0x12 || b == 0x13) {                     /* Package */
            u32 L = 0;
            const u8 *q = aml_pkglen(p + 1, end, &L);
            if (L < 1 || q + L > end) return;
            p = q + L;
            continue;
        }
        p++;                                              /* ресинхронизация */
    }
}

/* Обёртки системной информации об устройствах */
int hwinfo_dev_total(void) { return dev_total; }
int hwinfo_dev_hid(void)
{
    int k = 0;
    for (int i = 0; i < dev_n; i++)
        if (dev[i].hid[0]) k++;
    return k;
}

/* idx-е устройство С _HID (по порядку записи); 1 = строка записана */
int hwinfo_dev_get(int idx, char *out, int n)
{
    if (idx < 0) return 0;
    int k = -1, found = -1;
    for (int i = 0; i < dev_n; i++) {
        if (!dev[i].hid[0]) continue;
        if (++k == idx) { found = i; break; }
    }
    if (found < 0) return 0;
    hwdev_t *d = &dev[found];
    const char *ru = pnp_name(d->hid);
    char res[44];
    int w = 0;
    res[0] = 0;
    for (int i = 0; i < d->n_io && i < 2; i++) {
        int w2 = snprintf(res + w, sizeof(res) - w, "%s%x+%x",
                          w ? "," : " IO",
                          (unsigned)d->io_base[i], (unsigned)d->io_len[i]);
        if (w2 < 0 || w2 >= (int)sizeof(res) - w) break;
        w += w2;
    }
    for (int i = 0; i < d->n_irq && i < 3; i++) {
        int w2 = snprintf(res + w, sizeof(res) - w, "%s%u",
                          w ? "," : " IRQ", (unsigned)d->irq[i]);
        if (w2 < 0 || w2 >= (int)sizeof(res) - w) break;
        w += w2;
    }
    if (d->n_mem && w < (int)sizeof(res) - 16) {
        int w2 = snprintf(res + w, sizeof(res) - w, " MEM %x+%x",
                          (unsigned)d->mem_base, (unsigned)d->mem_len);
        if (w2 < 0 || w2 >= (int)sizeof(res) - w) { res[w] = 0; }
    }
    if (!w && d->n_dma)
        snprintf(res, sizeof(res), " DMA x%d", d->n_dma);
    if (!w && d->adr != 0xFFFFFFFFu)
        snprintf(res, sizeof(res), " ADR %02x.%x",
                 (unsigned)((d->adr >> 16) & 0xFF),
                 (unsigned)(d->adr & 0xFFFF));
    if (ru)
        snprintf(out, n, "%s [%s]%s", ru, d->hid, res);
    else if (!strcmp(d->hid, "CPU"))
        snprintf(out, n, "Процессор %s%s", d->name, res);
    else
        snprintf(out, n, "Устр. %s [%s]%s", d->name, d->hid, res);
    return 1;
}

/* ========================= SMBIOS (DMI) ========================= */
/* Сканируем F0000-FFFFF и EBDA на якорь "_SM_" (2.x) / "_SM3_" (3.0),
 * затем структуры Type 0 (BIOS), 1 (система), 2 (плата), 4 (CPU).
 * Только чтение; строки в статических буферах. */

static char dmi_bios[44], dmi_sys[44], dmi_board[44], dmi_cpu[44];

/* Скопировать idx-ю строку структуры (1-based) */
static void dmi_str(const u8 *s, u32 hdrlen, u32 idx, char *out, int n)
{
    out[0] = 0;
    if (!idx) return;
    const u8 *p = s + hdrlen;
    u32 i = 1;
    while (p < s + 0xFFFF) {
        if (!*p) {                       /* конец очередного элемента */
            if (i >= idx) return;        /* строка idx была пустой */
            i++;
            p++;
            continue;
        }
        if (i == idx) {
            int k = 0;
            while (p[k] && k < n - 1) { out[k] = (char)p[k]; k++; }
            out[k] = 0;
            return;
        }
        p++;
    }
}

static void dmi_parse(const u8 *tab, u32 len)
{
    const u8 *p = tab, *end = tab + len;
    int n = 0;
    while (p + 4 <= end && n < 64) {
        u8 type = p[0], hdrlen = p[1];
        if (hdrlen < 4 || p + hdrlen > end) break;
        if (type == 127) break;                      /* End-of-Table */
        if (type == 0 && hdrlen >= 0x12 && !dmi_bios[0]) {
            char a[28] = "", b[20] = "", c[14] = "";
            dmi_str(p, hdrlen, p[4], a, sizeof(a));   /* вендор BIOS  */
            dmi_str(p, hdrlen, p[5], b, sizeof(b));   /* версия       */
            dmi_str(p, hdrlen, p[8], c, sizeof(c));   /* дата выпуска */
            snprintf(dmi_bios, sizeof(dmi_bios), "%s %s (%s)",
                     a[0] ? a : "n/a", b[0] ? b : "-",
                     c[0] ? c : "-");
        } else if (type == 1 && hdrlen >= 0x08 && !dmi_sys[0]) {
            char a[26] = "", b[18] = "";
            dmi_str(p, hdrlen, p[4], a, sizeof(a));   /* производитель */
            dmi_str(p, hdrlen, p[5], b, sizeof(b));   /* продукт       */
            snprintf(dmi_sys, sizeof(dmi_sys), "%s %s",
                     a[0] ? a : "n/a", b[0] ? b : "");
        } else if (type == 2 && hdrlen >= 0x08 && !dmi_board[0]) {
            char a[20] = "", b[24] = "";
            dmi_str(p, hdrlen, p[4], a, sizeof(a));
            dmi_str(p, hdrlen, p[5], b, sizeof(b));
            snprintf(dmi_board, sizeof(dmi_board), "%s %s",
                     a[0] ? a : "n/a", b[0] ? b : "");
        } else if (type == 4 && hdrlen >= 0x1A && !dmi_cpu[0]) {
            char a[16] = "", b[20] = "";
            u16 mhz = *(const u16 *)(p + 0x16);       /* текущая частота */
            dmi_str(p, hdrlen, p[4], a, sizeof(a));   /* сокет      */
            dmi_str(p, hdrlen, p[7], b, sizeof(b));   /* произв.    */
            snprintf(dmi_cpu, sizeof(dmi_cpu), "%s, %s%s%u МГц",
                     a[0] ? a : "сокет n/a", b[0] ? b : "",
                     b[0] ? ", " : "", (unsigned)mhz);
        }
        /* пропустить строки: две NUL подряд после форматной части */
        const u8 *q = p + hdrlen;
        while (q + 1 < end && !(q[0] == 0 && q[1] == 0)) q++;
        if (q + 2 > end) break;
        p = q + 2;
        n++;
    }
}

static void dmi_scan(void)
{
    /* 1) EBDA (0x40E, максимум 0x400 байт) 2) F0000-FFFFF.
     * Чтение BDA — см. rsdp_find: доступ корректен, глушим локально. */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Warray-bounds"
    u32 ebda = ((u32)*(const volatile u16 *)0x40Eu) << 4;
#pragma GCC diagnostic pop
    if (ebda < 0x80000 || ebda >= 0x9F000) ebda = 0x9FC00u;
    u32 ebda_end = ebda + 0x400;
    if (ebda_end > 0xA0000u) ebda_end = 0xA0000u;
    for (u32 a = ebda; a + 16 <= ebda_end; a += 16) {
        const u8 *p = (const u8 *)(unsigned long)a;
        if (p[0] == '_' && p[1] == 'S' && p[2] == 'M' && p[3] == '_') {
            u32 len = p[5];                        /* длина точки входа 2.x */
            u8 sum = 0;
            for (u32 i = 0; i < len && i < 0x20; i++) sum = (u8)(sum + p[i]);
            if (sum == 0 && len >= 0x0F) {
                u32 tlen = (u32)p[0x16] | ((u32)p[0x17] << 8);
                u32 taddr = *(const u32 *)(p + 0x18);
                if (taddr && taddr >= 0x1000 && tlen && tlen < 0x10000)
                    dmi_parse((const u8 *)(unsigned long)taddr, tlen);
            }
            if (dmi_sys[0]) return;
        }
    }
    for (u32 a = 0xF0000u; a + 16 <= 0x100000u; a += 16) {
        const u8 *p = (const u8 *)(unsigned long)a;
        if (p[0] == '_' && p[1] == 'S' && p[2] == 'M' && p[3] == '_') {
            u32 len = p[5];
            u8 sum = 0;
            for (u32 i = 0; i < len && i < 0x20; i++) sum = (u8)(sum + p[i]);
            if (sum == 0 && len >= 0x0F) {
                u32 tlen = (u32)p[0x16] | ((u32)p[0x17] << 8);
                u32 taddr = *(const u32 *)(p + 0x18);
                if (taddr && taddr >= 0x1000 && tlen && tlen < 0x10000)
                    dmi_parse((const u8 *)(unsigned long)taddr, tlen);
            }
            if (dmi_sys[0]) return;
        }
    }
}

const char *hwinfo_dmi_bios(void)  { return dmi_bios; }
const char *hwinfo_dmi_system(void){ return dmi_sys; }
const char *hwinfo_dmi_board(void) { return dmi_board; }
const char *hwinfo_dmi_cpu(void)   { return dmi_cpu; }

/* ============================ CPU (CPUID) ============================ */

static void cpuid_raw(u32 leaf, u32 sub, u32 *a, u32 *b, u32 *c, u32 *d)
{
    __asm__ __volatile__("cpuid"
                         : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d)
                         : "a"(leaf), "c"(sub));
}

void hwinfo_cpu_features(char *out, int n)
{
    u32 a, b, c, d;
    out[0] = 0;
    int w = 0;
#define ADDF(cond, s) do { if (w < n - 12 && (cond)) { \
        int w2 = snprintf(out + w, n - w, "%s%s", w ? " " : "", s); \
        if (w2 > 0 && w2 < n - w) w += w2; } } while (0)
    cpuid_raw(1, 0, &a, &b, &c, &d);
    ADDF(d & (1u << 4),  "TSC");
    ADDF(d & (1u << 5),  "MSR");
    ADDF(d & (1u << 6),  "PAE");
    ADDF(d & (1u << 9),  "APIC");
    ADDF(d & (1u << 19), "CLFSH");
    ADDF(d & (1u << 23), "MMX");
    ADDF(d & (1u << 25), "SSE");
    ADDF(d & (1u << 26), "SSE2");
    ADDF(d & (1u << 28), "HTT");
    ADDF(c & (1u << 0),  "SSE3");
    ADDF(c & (1u << 9),  "SSSE3");
    ADDF(c & (1u << 19), "SSE4.1");
    ADDF(c & (1u << 20), "SSE4.2");
    ADDF(c & (1u << 30), "RDRAND");
    cpuid_raw(0x80000001u, 0, &a, &b, &c, &d);
    ADDF(d & (1u << 29), "x86-64");
    ADDF(d & (1u << 20), "NX");
#undef ADDF
    if (!w) snprintf(out, n, "-");
}

void hwinfo_cpu_cache(char *out, int n)
{
    u32 a, b, c, d, maxl;
    out[0] = 0;
    cpuid_raw(0, 0, &maxl, &b, &c, &d);
    unsigned l1d = 0, l1i = 0, l2 = 0, l3 = 0;
    if (maxl >= 4) {
        for (u32 i = 0; i < 16; i++) {
            cpuid_raw(4, i, &a, &b, &c, &d);
            u32 type = a & 0x1Fu;
            if (!type) break;
            u32 lvl   = (a >> 5) & 7;
            u32 ways  = ((b >> 22) & 0x3FF) + 1;
            u32 part  = ((b >> 12) & 0x3FF) + 1;
            u32 line  = (b & 0xFFF) + 1;
            u32 sets  = c + 1;
            u32 kb    = (ways * part * line * sets) >> 10;
            if (lvl == 1) {
                if (type == 1) l1d = kb;
                else if (type == 2) l1i = kb;
                else { if (!l1d) l1d = kb; if (!l1i) l1i = kb; }
            } else if (lvl == 2) l2 = kb;
            else if (lvl == 3) l3 = kb;
        }
    } else {
        /* Фолбэк: leaf 2 (дескрипторы ALU) — старые/простые CPU */
        cpuid_raw(2, 0, &a, &b, &c, &d);
        const u8 bytes[16] = {
            (u8)(a >> 8), (u8)(a >> 16), (u8)(a >> 24),
            (u8)b, (u8)(b >> 8), (u8)(b >> 16), (u8)(b >> 24),
            (u8)c, (u8)(c >> 8), (u8)(c >> 16), (u8)(c >> 24),
            (u8)d, (u8)(d >> 8), (u8)(d >> 16), (u8)(d >> 24)
        };
        for (int i = 0; i < 15; i++) {
            switch (bytes[i]) {
            case 0x2A: l1i = 32; break;
            case 0x2C: l1d = 32; break;
            case 0x30: l1i = 32; break;
            case 0x41: l2 = 128; break;
            case 0x42: l2 = 256; break;
            case 0x43: l2 = 512; break;
            case 0x44: l2 = 1024; break;
            case 0x45: l2 = 2048; break;
            case 0x49: l3 = 4096; break;
            case 0x66: l1d = 8;  break;
            case 0x67: l1d = 16; break;
            case 0x68: l1d = 32; break;
            default: break;
            }
        }
    }
    if (l1d || l1i || l2 || l3) {
        char *w = out;
        int left = n;
        int wrote = 0;
        if (l1d) { int k = snprintf(w, left, "%sL1d %uK", wrote ? " " : "", l1d);
                   if (k > 0 && k < left) { w += k; left -= k; wrote = 1; } }
        if (l1i) { int k = snprintf(w, left, "%sL1i %uK", wrote ? " " : "", l1i);
                   if (k > 0 && k < left) { w += k; left -= k; wrote = 1; } }
        if (l2)  { int k = snprintf(w, left, "%sL2 %uK",  wrote ? " " : "", l2);
                   if (k > 0 && k < left) { w += k; left -= k; wrote = 1; } }
        if (l3)  { int k = snprintf(w, left, "%sL3 %uK",  wrote ? " " : "", l3);
                   if (k > 0 && k < left) { w += k; left -= k; wrote = 1; } }
    } else
        snprintf(out, n, "н/д");
}

/* Частота TSC: ленивая калибровка по тикам PIT (100 мс, 1000 Гц) */
unsigned hwinfo_tsc_mhz(void)
{
    static int  done = 0;
    static unsigned mhz = 0;
    if (done) return mhz;
    done = 1;
    u32 a, b, c, d;
    cpuid_raw(1, 0, &a, &b, &c, &d);
    if (!(d & (1u << 4))) return 0;              /* нет TSC */
    u32 lo0, hi0, lo1, hi1;
    __asm__ __volatile__("rdtsc" : "=a"(lo0), "=d"(hi0));
    u32 t0 = timer_ticks();
    while ((u32)(timer_ticks() - t0) < 100)      /* 100 мс при 1000 Гц */
        __asm__ __volatile__("pause");
    __asm__ __volatile__("rdtsc" : "=a"(lo1), "=d"(hi1));
    u64 d0 = ((u64)hi0 << 32) | lo0;
    u64 d1 = ((u64)hi1 << 32) | lo1;
    if (d1 < d0) return 0;
    u64 dt = d1 - d0;                            /* циклов за ~100 мс */
    mhz = (unsigned)((dt + 50000u) / 100000u);   /* -> МГц */
    if (!mhz) mhz = 1;
    return mhz;
}

/* ============================ hwinfo_init ============================ */

void hwinfo_init(void)
{
    memset(tbl, 0, sizeof(tbl));
    tbl_count = 0;
    dev_n = dev_total = 0;

    acpi_scan();

    if (tbl_count) {
        hw_logf("[hwinfo] ACPI %u: таблиц %d, OEM %s",
                (unsigned)(acpi_rev >= 2 ? 2u : 1u), tbl_count,
                acpi_oem[0] ? acpi_oem : "n/a");
    }
    if (dsdt_p) {
        aml_walk(dsdt_p + sizeof(acpi_hdr_t), dsdt_p + sizeof(acpi_hdr_t) + dsdt_len, 0);
        int chk = -1;
        for (int i = 0; i < tbl_count; i++)
            if (!memcmp(tbl[i].sig, "DSDT", 4)) { chk = tbl[i].chk_ok; break; }
        hw_logf("[hwinfo] DSDT: %u КиБ, устройств %d (с _HID %d), chk %s",
                (unsigned)(dsdt_len >> 10), dev_total, hwinfo_dev_hid(),
                chk == 1 ? "OK" : chk == 0 ? "BAD" : "n/a");
    }

    dmi_scan();
    if (dmi_sys[0])
        hw_logf("[hwinfo] DMI: %s (BIOS %s)", dmi_sys, dmi_bios[0] ? dmi_bios : "n/a");
    else
        hw_log("[hwinfo] DMI: SMBIOS не найден");
}

