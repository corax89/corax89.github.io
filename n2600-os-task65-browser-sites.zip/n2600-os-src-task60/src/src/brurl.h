/* brurl.h — разбор HTTP-ответов и URL-хостов для браузера N2600-OS.
 * Header-only (ядро и хост-тест включают один и тот же код).
 *
 * Вынесено из apps_browser.c (сессии 56/79) для хост-тестирования
 * (scripts/brhost/test_brurl.c): разбор статуса, редиректов и host:port
 * — чистые строковые функции без зависимостей от ядра.
 *
 * Task 61 [BR-REDIR2]: лимит цепочки редиректов поднят 4 -> 8
 * (популярные сайты: http:// -> https:// -> www -> canonical -> /
 * — 4 переходов не хватало, браузер показывал пустое тело 302). */
#ifndef BRURL_H
#define BRURL_H

#include "types.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#ifdef HOST_TEST
#include <string.h>
#include <stdio.h>
#else
#include "string.h"
#endif

#include "imgsvc.h"   /* img_norm_url_path / img_url_encode_path (Task 61) */

/* Максимум переходов по цепочке 301/302/303/307/308 (было 4) */
#define BR_REDIR_MAX 8

/* Разобрать "host" или "host:port" → хост и порт.
 * ЗАДАЧА 53 (ФИКС «https открывает порт 80»): порт ПО УМОЛЧАНИЮ
 * ставит ВЫЗЫВАЮЩИЙ (80 для http, 443 для https) ДО вызова; функция
 * перезаписывает его ТОЛЬКО когда порт указан явно ("host:port"). */
static int br_parse_host(char *host, u16 *port)
{
    char *colon = strchr(host, ':');
    if (!colon) return 1;
    *colon = 0;
    u32 p = 0;   /* u32: u16 переполнялся бы ДО проверки > 65535 (-Wtype-limits) */
    for (const char *q = colon + 1; *q; q++) {
        if (*q < '0' || *q > '9') return 0;
        p = p * 10 + (u32)(*q - '0');
        if (p > 65535) return 0;
    }
    if (p == 0) return 0;
    *port = (u16)p;
    return 1;
}

static int br_ci_ncmp(const char *a, const char *b, int n)
{
    for (int i = 0; i < n; i++) {
        char ca = a[i], cb = b[i];
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 1;
    }
    return 0;
}

/* [BR-TLSUP] (сессия 79): код статуса HTTP-ответа (100..599) или 0.
 * Общий парсер для br_parse_redirect и авто-перехода http->https.
 * Task 61 [BR-REDIR2] ГЛАВНЫЙ ФИКС: раньше разбор кода начинался с
 * позиции 5 — сразу после "HTTP/", то есть с ВЕРСИИ ПРОТОКОЛА:
 * "HTTP/1.1 302" парсился как "1.1" и падал на точке -> 0. Из-за
 * этого 301/302/303/307/308 не обрабатывались ВООБЩЕ (пользователь
 * видел сырой ответ/пустую страницу), а авто-переход http->https по
 * коду 400/403/426 не срабатывал. Теперь: пропускаем версию до
 * пробела, пробелы, затем три цифры кода. */
static int br_http_status(const char *resp, int len)
{
    if (!resp || len < 12 || strncmp(resp, "HTTP/", 5) != 0) return 0;
    int i = 5;
    while (i < len && resp[i] != ' ' && resp[i] != '\r' && resp[i] != '\n')
        i++;                                 /* версия протокола "1.1" */
    while (i < len && resp[i] == ' ') i++;   /* пробелы перед кодом */
    if (i + 3 > len) return 0;
    int code = 0;
    for (int k = 0; k < 3; k++) {
        char c = resp[i + k];
        if (c < '0' || c > '9') return 0;
        code = code * 10 + (c - '0');
    }
    return code;
}

/* Сессия 56: распознать редирект в сыром HTTP-ответе. Заполняет loc
 * (буфер вызывающего) значением заголовка Location и возвращает код
 * статуса (301/302/303/307/308) или 0 (нет редиректа/нет Location).
 * loc может быть относительным — разрешает вызывающий.
 * [BR-REDIR2]: буфер loc у вызывающего — 512 байт (длинные
 * tracking-Location раньше целиком не влезали и редирект терялся). */
static int br_parse_redirect(const char *resp, int len, int *out_code,
                             char *loc, int loc_max)
{
    if (!resp || !loc || loc_max < 8) return 0;
    int code = br_http_status(resp, len);
    if (code != 301 && code != 302 && code != 303 &&
        code != 307 && code != 308) return 0;

    /* конец заголовков: \r\n\r\n или \n\n.
     * FIX [HDR-LIMIT] (Task 65): скан ограничивался 2 КиБ — у крупных
     * сайтов (ya.ru: заголовки 6215 байт на финальном 200; редиректные
     * ответы тоже подрастают) Location за пределами 2 КиБ терялся и
     * вместо страницы показывался сырой ответ редиректа. Лимит 16 КиБ
     * (больше заголовков по RFC-практике не бывает). */
    int hdr_end = len;
    for (int p = 0; p < len && p < 16384; p++) {
        if (p + 3 < len && resp[p] == '\r' && resp[p + 1] == '\n' &&
            resp[p + 2] == '\r' && resp[p + 3] == '\n') {
            hdr_end = p; break;
        }
        if (p + 1 < len && resp[p] == '\n' && resp[p + 1] == '\n') {
            hdr_end = p; break;
        }
    }

    /* строка "location: ..." (без учёта регистра) до конца заголовков */
    for (int p = 0; p < hdr_end; ) {
        int eol = p;
        while (eol < hdr_end && resp[eol] != '\n') eol++;
        if (eol - p > 9 && br_ci_ncmp(resp + p, "location:", 9) == 0) {
            const char *v = resp + p + 9;
            const char *ve = resp + eol;
            while (v < ve && (*v == ' ' || *v == '\t')) v++;
            int vl = (int)(ve - v);
            while (vl > 0 && (v[vl - 1] == '\r' || v[vl - 1] == ' '))
                vl--;
            if (vl > 0 && vl < loc_max) {
                memcpy(loc, v, (u32)vl);
                loc[vl] = 0;
                *out_code = code;
                return code;
            }
            return 0;
        }
        p = eol + 1;
    }
    return 0;
}

/* Task 61: разбор адреса ПОСЛЕ схемы ("ya.ru:8080/dir//x?q") на хост,
 * порт и путь. Хост обрезается на '/' и '?' ([BR-SLASH], сессия 79);
 * порт по умолчанию — 443 для https, 80 для http (ЗАДАЧА 53: его
 * ставит вызывающий через use_tls, br_parse_host перезаписывает
 * только явный "host:port"); путь всегда начинается с '/';
 * "?query" после хоста -> "/?query".
 * [BR-2SLASH]: путь нормализуется ("//"->"/", "./"/"../") — двойной
 * слеш больше не прилипает к запросу и адресной строке.
 * [BR-PCT]: путь процентно кодируется (пробел, кириллица UTF-8,
 * кавычки) — раньше ломали request-line ("GET /a b HTTP/1.0" = 400).
 * 1 = успех; 0 = неверный порт. */
static int br_split_url(const char *p, int use_tls,
                        char *host, int host_max, u16 *port,
                        char *path, int path_max)
{
    int hi = 0;

    if (!p || !host || !path || host_max < 2 || path_max < 2) return 0;

    *port = use_tls ? 443 : 80;
    while (*p && *p != '/' && *p != '?' && hi < host_max - 1)
        host[hi++] = *p++;
    host[hi] = 0;
    if (!br_parse_host(host, port)) return 0;

    if (*p == '?') {
        int pl = 0;
        path[pl++] = '/';
        while (*p && pl < path_max - 1) path[pl++] = *p++;
        path[pl] = 0;
    } else {
        if (!*p) p = "/";
        strncpy(path, p, (u32)path_max - 1);
        path[path_max - 1] = 0;
    }

    /* нормализация (//, ./, ../) + percent-кодирование небезопасных байт */
    img_norm_url_path(path, path_max);
    {
        char enc[512];
        int el = img_url_encode_path(path, enc, (int)sizeof(enc));
        if (el > 0 && el < path_max) memcpy(path, enc, (u32)el + 1);
    }
    return 1;
}

#endif /* BRURL_H */
