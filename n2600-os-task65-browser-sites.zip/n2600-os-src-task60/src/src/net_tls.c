/* net_tls.c — TLS-сессия поверх TCP-стека N2600-OS (движок: BearSSL).
 *
 * Архитектура обмена:
 *
 *   TCP (net_tcp)  --tls_tcp_recv-->  staging-ring (шифротекст)
 *                                            |
 *   tls_pump():   ring -> recvrec_ack -> engine -> recvapp_buf -> sink()
 *                 sendapp_buf <- ack <- (tls_send_all)
 *                 sendrec_buf -> net_tcp_send (куски <= MSS)
 *
 * Все отладочные печати — за #ifdef TLS_DEBUG (включать: -DTLS_DEBUG).
 *
 * Энтропия: br_prng_seeder_system() реализован здесь (в движке его
 * ОС-зависимая версия исключена при амальгамации): смесь rdtsc, тиков
 * таймера, MAC-адреса, IP, RTC и адресов стека прокручивается через
 * HMAC-DRBG движка.
 *
 * Время для проверки сертификатов: дата+время CMOS; дни считаются от
 * нулевой эры (как ожидает br_x509_minimal_set_time: unix_days + 719528).
 * Если CMOS даёт неправдоподобный год — берётся зафиксированная дата
 * сборки (PINNED_*), чтобы валидация оставалась возможной.
 */
#include "net_tls.h"
#include "net.h"
#include "rtc.h"
#include "string.h"
#include "timer.h"
#include "task.h"

#include "bearssl.h"
#include "tls_anchors.h"

extern void serial_puts(const char *s);
extern void net_poll(void);

/* ================== отладка ================== */
#ifdef TLS_DEBUG
#define TLS_DBG(s)  do { serial_puts("[tls] "); serial_puts(s); serial_puts("\n"); } while (0)
#define TLS_DBGX(s, v) do { char _b[64]; snprintf(_b, sizeof _b, "[tls] %s %u\n", s, (unsigned)(v)); serial_puts(_b); } while (0)
#else
#define TLS_DBG(s)      do {} while (0)
#define TLS_DBGX(s, v)  do {} while (0)
#endif

/* ================== состояние сессии ================== */

/* Двунаправленный I/O-буфер движка (максимум для полных рекордов) */
static unsigned char g_iobuf[BR_SSL_BUFSIZE_BIDI];

static br_ssl_client_context   g_cc;
static br_x509_minimal_context g_xc;

static int  g_sock = -1;            /* TCP-сокет сессии */
static int  g_active = 0;           /* сессия идёт */
static int  g_failed = 0;           /* движок в ошибке */

static void (*g_sink)(const void *data, u32 len) = 0;

static char g_tls_err[64] = "ok";

const char *tls_errstr(void) { return g_tls_err; }
int  tls_is_active(void) { return g_active; }

static void tls_fail(const char *msg)
{
    strncpy(g_tls_err, msg, sizeof(g_tls_err) - 1);
    g_tls_err[sizeof(g_tls_err) - 1] = 0;
    serial_puts("[tls] ");
    serial_puts(msg);
    serial_puts("\n");
}

static void tls_fail_err(const char *prefix, int err)
{
    char b[80];
    snprintf(b, sizeof b, "%s (engine err %d)", prefix, err);
    tls_fail(b);
}

/* ================== staging-ring шифротекста ==================
 * Кадры, доставленные TCP-callback'ом, ждут здесь до tls_pump().
 * Размер — с запасом на burst нескольких полных рекордов подряд.
 * Переполнение = потеря кадра = порча потока: считаем и фиксируем.
 *
 * FIX [TLS-RING] (Task 65): было 16384 — МЕНЬШЕ максимального TLS-рекорда
 * в проводе (16384 полезных + ~34 оверхеда = 16418!). habr.com/ru/feed/
 * шлёт ПОДРЯД 21 рекорд ровно по 16384: burst TCP-сегментов между
 * tls_pump() (kmain/feed тоже кормит ring через net_poll — 8 пакетов за
 * вызов) легко превышал ring, хвост рекорда МОЛЧА выбрасывался,
 * движок ждал недостающие байты рекорда вечно (MAC-ошибки нет!),
 * net_http возвращал только заголовки — браузер показывал страницу
 * из ОДНОЙ пустой строки («строк: 1»). Теперь 256 КиБ (запас на
 * burst ~175 пакетов) + drain сразу в tcp-callback (см. tls_tcp_recv):
 * ring не накапливает ни одного полного рекорда. */
#define CT_RING 262144u  /* степень двойки! */
static unsigned char g_ct[CT_RING];
static volatile u32  g_ct_r = 0;   /* чтение (pump) */
static volatile u32  g_ct_w = 0;   /* запись (callback) */
static volatile u32  g_ct_ovf = 0;

static u32 ring_put(const unsigned char *src, u32 len)
{
    u32 w = g_ct_w, r = g_ct_r;
    u32 used = w - r;
    u32 room = CT_RING - used;
    if (len > room) {
        g_ct_ovf++;
        len = room;
    }
    for (u32 i = 0; i < len; i++) {
        g_ct[(w + i) & (CT_RING - 1)] = src[i];
    }
    g_ct_w = w + len;
    return len;
}

static u32 ring_pop(unsigned char *dst, u32 max)
{
    u32 r = g_ct_r, w = g_ct_w;
    u32 avail = w - r;
    if (max > avail) max = avail;
    for (u32 i = 0; i < max; i++) {
        dst[i] = g_ct[(r + i) & (CT_RING - 1)];
    }
    g_ct_r = r + max;
    return max;
}

/* TCP-callback на время сессии: шифротекст -> ring.
 * FIX [TLS-RING]: ПОСЛЕ постановки в ring сразу выталкиваем данные
 * в движок (только ПРИЁМНАЯ часть pump: ring -> recvrec -> sink).
 * ring кормится из kmain/net_poll БЕЗ оглядки на браузерный цикл —
 * без drain burst легко превышал ring. drain_recv НЕ отправляет
 * TCP-пакеты (recvrec_ack только потребляет) — реентерабельность
 * net_poll не нарушается. */
static void tls_drain_recv(void);
void tls_tcp_recv(int sock, u32 src_ip, u16 src_port,
                  const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    if (!g_active || sock != g_sock || !data || len == 0) return;
    ring_put((const unsigned char *)data, len);
    tls_drain_recv();
}

/* ================== энтропия (сидер для HMAC-DRBG движка) ================== */

static u32 rdtsc_u32(void)
{
    return (u32)__builtin_ia32_rdtsc();
}

static int tls_os_seed(const br_prng_class **ctx)
{
    unsigned char buf[64];
    u32 acc = 0x9E3779B9u;

    /* rdtsc: у VMware TSC виртуальный, но с высокой скоростью —
     * младшие биты дают достаточно хаоса для сидирования */
    for (int i = 0; i < 8; i++) {
        acc ^= rdtsc_u32();
        acc *= 2654435761u;
        acc ^= acc >> 13;
        buf[i * 4 + 0] = (unsigned char)acc;
        buf[i * 4 + 1] = (unsigned char)(acc >> 8);
        buf[i * 4 + 2] = (unsigned char)(acc >> 16);
        buf[i * 4 + 3] = (unsigned char)(acc >> 24);
    }
    u32 t = timer_ticks() * 2654435761u;
    int h = 0, mi = 0, s = 0;
    rtc_get_time(&h, &mi, &s);
    t ^= (u32)h * 3600u + (u32)mi * 60u + (u32)s;
    buf[32] = (unsigned char)t;
    buf[33] = (unsigned char)(t >> 8);
    buf[34] = (unsigned char)(t >> 16);
    buf[35] = (unsigned char)(t >> 24);

    u8 mac[6];
    net_get_mac(mac);
    for (int i = 0; i < 6; i++) buf[36 + i] = mac[i];
    u32 ip = net_get_ip();
    buf[42] = (unsigned char)ip;
    buf[43] = (unsigned char)(ip >> 8);
    buf[44] = (unsigned char)(ip >> 16);
    buf[45] = (unsigned char)(ip >> 24);
    /* адрес стека — ASLR-подобный вклад */
    u32 sp = (u32)(unsigned long)&buf;
    buf[46] = (unsigned char)sp;
    buf[47] = (unsigned char)(sp >> 8);

    (*ctx)->update(ctx, buf, sizeof buf);
    return 1;
}

/* Движок зовёт это из br_ssl_engine_init_rand() при рукопожатии */
br_prng_seeder br_prng_seeder_system(const char **name)
{
    if (name) *name = "n2600-os";
    return &tls_os_seed;
}

/* ================== время для X.509 ================== */

/* Дни от 1970-01-01 (алгоритм Howard Hinnant, days_from_civil) */
static u32 days_from_civil(int y, int m, int d)
{
    y -= m <= 2;
    int era = (y >= 0 ? y : y - 399) / 400;
    unsigned yoe = (unsigned)(y - era * 400);            /* [0, 399] */
    unsigned doy = (153u * (unsigned)(m + (m > 2 ? -3 : 9)) + 2u) / 5u
                 + (unsigned)d - 1u;                     /* [0, 365] */
    unsigned doe = yoe * 365u + yoe / 4u - yoe / 100u + doy;
    return (u32)era * 146097u + doe - 719468u;
}

/* Фиксированная дата на случай сбойного CMOS (дата генерации амальгамы) */
#define PINNED_Y 2026
#define PINNED_M 10
#define PINNED_D 29

static void tls_set_validation_time(void)
{
    int y = 0, mo = 0, d = 0, h = 0, mi = 0, s = 0;
    int ok = rtc_get_date(&y, &mo, &d);
    rtc_get_time(&h, &mi, &s);
    if (!ok || y < 2024 || y > 2040 || mo < 1 || mo > 12) {
        TLS_DBG("CMOS date implausible, using pinned date");
        y = PINNED_Y; mo = PINNED_M; d = PINNED_D;
    }
    u32 days = days_from_civil(y, mo, d) + 719528u;
    u32 secs = (u32)h * 3600u + (u32)mi * 60u + (u32)s;
    br_x509_minimal_set_time(&g_xc, days, secs);   /* (ctx, days, seconds) */
    TLS_DBGX("validation days", days);
}

/* ================== насос ================== */

/* Один проход по состояниям движка. Возвращает 1, если что-то сделали. */
static int pump_once(void)
{
    if (!g_active) return 0;
    unsigned st = br_ssl_engine_current_state(&g_cc.eng);
    int busy = 0;

    /* 1. Выталкивание готовых записей в TCP (куски <= MSS) */
    if (st & BR_SSL_SENDREC) {
        size_t len;
        unsigned char *buf = br_ssl_engine_sendrec_buf(&g_cc.eng, &len);
        int sent = net_tcp_send(g_sock, buf, (u32)len);
        if (sent > 0) {
            br_ssl_engine_sendrec_ack(&g_cc.eng, (u32)sent);
            busy = 1;
            TLS_DBGX("rec -> tcp", (u32)sent);
        } else {
            g_failed = 1;
            tls_fail("tcp send failed (engine records)");
            return 0;
        }
    }

    /* 2. Подача шифротекста из ring в движок */
    st = br_ssl_engine_current_state(&g_cc.eng);
    if (st & BR_SSL_RECVREC) {
        size_t len;
        unsigned char *buf = br_ssl_engine_recvrec_buf(&g_cc.eng, &len);
        u32 got = ring_pop(buf, (u32)len);
        if (got > 0) {
            br_ssl_engine_recvrec_ack(&g_cc.eng, got);
            busy = 1;
            TLS_DBGX("ct -> engine", got);
        }
    }

    /* 3. Выдача расшифрованных данных приложению */
    st = br_ssl_engine_current_state(&g_cc.eng);
    if (st & BR_SSL_RECVAPP) {
        size_t len;
        unsigned char *buf = br_ssl_engine_recvapp_buf(&g_cc.eng, &len);
        if (g_sink && len > 0) {
            g_sink(buf, (u32)len);
        }
        br_ssl_engine_recvapp_ack(&g_cc.eng, len);
        busy = 1;
    }

    return busy;
}

/* FIX [TLS-RING]: ПРИЁМНАЯ часть насоса (шаги 2-3 pump_once без отправки
 * TCP) — вызывается из tls_tcp_recv СРАЗУ после ring_put: данные не
 * ждут браузерного tls_pump и не копятся в ring. Реентерабельность
 * net_poll не нарушается: recvrec_ack/recvapp_ack только потребляют
 * байты движка, TCP не трогают. Вызов может прийти внутри net_poll
 * (callback-цепочка) — состояние ring/движка консистентно (мы в одном
 * потоке выполнения между пакетами). */
static void tls_drain_recv(void)
{
    if (!g_active || g_failed) return;
    for (int i = 0; i < 32; i++) {
        unsigned st = br_ssl_engine_current_state(&g_cc.eng);
        if (st == BR_SSL_CLOSED) return;
        if (!(st & (BR_SSL_RECVREC | BR_SSL_RECVAPP))) return;
        int busy = 0;
        if (st & BR_SSL_RECVREC) {
            size_t len;
            unsigned char *buf = br_ssl_engine_recvrec_buf(&g_cc.eng, &len);
            u32 got = ring_pop(buf, (u32)len);
            if (got > 0) {
                br_ssl_engine_recvrec_ack(&g_cc.eng, got);
                busy = 1;
            }
        }
        st = br_ssl_engine_current_state(&g_cc.eng);
        if (st & BR_SSL_RECVAPP) {
            size_t len;
            unsigned char *buf = br_ssl_engine_recvapp_buf(&g_cc.eng, &len);
            if (g_sink && len > 0)
                g_sink(buf, (u32)len);
            br_ssl_engine_recvapp_ack(&g_cc.eng, len);
            busy = 1;
        }
        if (!busy) return;
    }
}

void tls_pump(void)
{
    if (!g_active || g_failed) return;
    /* выталкиваем пока есть что (рекорд до 16 КиБ = ~12 MSS-кусков) */
    for (int i = 0; i < 24; i++) {
        unsigned st = br_ssl_engine_current_state(&g_cc.eng);
        if (st == BR_SSL_CLOSED) {
            g_active = 0;
            return;
        }
        if (!(st & (BR_SSL_SENDREC | BR_SSL_RECVAPP)))
            break;                    /* RECVREC требует новых данных — ниже */
        if (!pump_once())
            break;
    }
    /* подача шифротекста, если он уже в ring */
    pump_once();
}

/* ================== публичные операции ================== */

int tls_start(int sock, const char *hostname, u32 max_ms)
{
    if (sock < 0 || !hostname || !hostname[0]) {
        tls_fail("bad args");
        return 0;
    }
    g_sock = sock;
    g_active = 1;
    g_failed = 0;
    g_ct_r = g_ct_w = g_ct_ovf = 0;
    strncpy(g_tls_err, "ok", sizeof g_tls_err - 1);
    g_tls_err[sizeof g_tls_err - 1] = 0;

    br_ssl_client_init_full(&g_cc, &g_xc, TAs, TAs_NUM);
    br_ssl_engine_set_buffer(&g_cc.eng, g_iobuf, sizeof g_iobuf, 1);
    tls_set_validation_time();

    /* отсечь лишние наборы (3DES/CCM/статический ECDH не предлагаем) */
    static const uint16_t suites[] = {
        BR_TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256,
        BR_TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,
        BR_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
        BR_TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
        BR_TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
        BR_TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
        BR_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,
        BR_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256,
        BR_TLS_RSA_WITH_AES_128_GCM_SHA256,
        BR_TLS_RSA_WITH_AES_128_CBC_SHA256,
        BR_TLS_RSA_WITH_AES_128_CBC_SHA
    };
    br_ssl_engine_set_suites(&g_cc.eng, suites,
                             sizeof suites / sizeof suites[0]);

    TLS_DBGX("trust anchors", (u32)TAs_NUM);
    if (!br_ssl_client_reset(&g_cc, hostname, 0)) {
        tls_fail("client reset failed");
        g_active = 0;
        return 0;
    }
    TLS_DBG("handshake: start");

    u32 t0 = timer_ticks();
    for (;;) {
        unsigned st = br_ssl_engine_current_state(&g_cc.eng);
        if (st == BR_SSL_CLOSED) {
            tls_fail_err("handshake failed",
                         br_ssl_engine_last_error(&g_cc.eng));
            g_active = 0;
            return 0;
        }
        if (st & BR_SSL_SENDAPP) {
            TLS_DBG("handshake ok");
            return 1;
        }
        pump_once();
        net_poll();          /* приём шифротекста -> callback -> ring */
        task_yield();
        if ((u32)(timer_ticks() - t0) > max_ms) {
            tls_fail("handshake timeout");
            g_active = 0;
            return 0;
        }
    }
}

int tls_send_all(const void *data, u32 len)
{
    if (!g_active || g_failed) return 0;
    const unsigned char *p = (const unsigned char *)data;
    u32 left = len;

    while (left > 0) {
        size_t len_out;
        unsigned char *buf = br_ssl_engine_sendapp_buf(&g_cc.eng, &len_out);
        if (buf == NULL || len_out == 0) {
            /* места нет — протолкнуть движок и подождать */
            pump_once();
            net_poll();
            task_yield();
            continue;
        }
        u32 chunk = left < (u32)len_out ? left : (u32)len_out;
        memcpy(buf, p, chunk);
        br_ssl_engine_sendapp_ack(&g_cc.eng, chunk);
        p += chunk;
        left -= chunk;
        if (left == 0) {
            /* последний байт — рекорд должен уйти сразу (иначе сервер
             * ждёт запрос, а данные висят в буфере движка) */
            br_ssl_engine_flush(&g_cc.eng, 1);
        }
        pump_once();
    }
    /* добить отправку записей полностью */
    for (int i = 0; i < 64; i++) {
        unsigned st = br_ssl_engine_current_state(&g_cc.eng);
        if (!(st & BR_SSL_SENDREC)) break;
        pump_once();
        net_poll();
        task_yield();
    }
    TLS_DBGX("app data sent", len);
    return !g_failed;
}

void tls_set_sink(void (*sink)(const void *data, u32 len))
{
    g_sink = sink;
}

void tls_shutdown(void)
{
    if (!g_active) return;
    br_ssl_engine_close(&g_cc.eng);
    /* best-effort: отправить close_notify, не ждём ответа */
    for (int i = 0; i < 16; i++) {
        unsigned st = br_ssl_engine_current_state(&g_cc.eng);
        if (st == BR_SSL_CLOSED) break;
        if (!(st & BR_SSL_SENDREC)) break;
        if (!pump_once()) break;
        net_poll();
        task_yield();
    }
    TLS_DBG("shutdown");
    g_active = 0;
    g_sink = 0;
}
