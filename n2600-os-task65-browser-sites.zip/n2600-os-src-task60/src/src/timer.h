/* timer.h — системный таймер PIT */
#ifndef TIMER_H
#define TIMER_H

#include "types.h"

void timer_init(int hz);          /* IRQ0 */
u32  timer_ticks(void);           /* тики (hz в секунду) */
u32  uptime_sec(void);            /* секунд с загрузки */
void timer_hz_selfcheck(void);    /* [TICK-CAL]: фактический тик-рейт vs RTC
                                   * (одна печать в dmesg; ~1-2 с при старте) */

/* Сессия 14: опросы устройств с реальным временем ожидания.
 *
 * Проблема: драйверы (PS/2, e1000) ждут готовности счётчиком итераций
 * «inb». На VMware каждый доступ к порту = VM-exit (~2-10 мкс): цикл
 * 200000 итераций при ПУСТОМ буфере выжигал СЕКУНДЫ на каждую проверку
 * (долгая «загрузка с ожиданием мыши»). На v86 счётчик тоже не стабилен
 * (JIT). Решение — дедлайны по PIT каналу 2 (1.193182 МГц, свободный
 * счётчик, работает ДО sti — прерывания не нужны). Использование:
 *
 *   u32 dl = timer_poll_deadline();
 *   while (!timer_poll_expired(dl, 10000)) {   // мкс
 *       if (inb(0x64) & 1) return 1;           // готово — выйти
 *   }
 *   return 0;                                  // таймаут
 */
void timer_pit2_resync(void);             /* [PIT2-RESYNC]: после чужой
                                  * перепрограммки канала 2 (калибровки
                                  * драйверов) — переозначить базу оборотов */
u32  timer_poll_deadline(void);           /* снимок «старт» */
int  timer_poll_expired(u32 start, u32 max_us); /* 1 = прошло > max_us */
u32  timer_pit2_probe(void);               /* ЗОНД: тики pit2 за цикл — 0 = заморожен */

#endif
