/* gma3600_2d.c — GMA3600/Cedarview: УПРОЩЁННЫЙ дисплейный модуль.
 *
 * СЕССИЯ 90 (запрос пользователя: «Это кончилось черным экраном и
 * перезагрузкой. Думаю стоит отказаться от 3д и 2д ускорения, вернись к
 * упрощенной версии с правильной инициализацией экрана в 1024 на 600»):
 *
 *   ВСЕ эксперименты с 3D/2D-ускорением сняты:
 *     - sgx545.c УДАЛЁН (проба микроядра PowerVR: SOFT_RESET, BIF_*,
 *       EVENT_KICK — на X101CH давала чёрный экран и перезагрузку);
 *     - записи в окно SGX (MMIO+0x80000) не делаются ВООБЩЕ: ни
 *       CLKGATECTL, ни CORE_ID-проба, ни сбросы. Дисплейный блок
 *       (gma3600.c: 1024x600 через sideband DPIO, pipe B, LVDS) не
 *       тронут — он подтверждён на железе сессиями 83-87.
 *     - voodoo3.c УДАЛЁН (2D-blit + аппаратный курсор Voodoo3 для
 *       86Box) — тоже программный рендер.
 *
 *   Что осталось (всё это работало в сессии 87, лог X101CH):
 *     1. Аппаратные курсорные плоскости СНЯТЫ: в CURACNTR (0x70080) и
 *        CURBCNTR (0x700C0) пишется CURSOR_MODE_DISABLE — иначе курсорная
 *        плоскость фетчит чужую память и даёт «полосатый квадрат 64x64».
 *        Курсор рисует wm.c ПРОГРАММНО тем же движком, что и весь
 *        интерфейс (compose + fb_flush_rects, WC MTRR).
 *     2. GTT-диагностика (только ЧТЕНИЕ PGETBL): при выключенном GTT
 *        адреса поверхностей — физические.
 *     3. Честный статус WC MTRR (mtrr_lfb_wc_enabled).
 *
 *   Отрисовка: программная compose-модель + Write-Combining на LFB
 *   (ускорение от MTRR, не от GPU). Для «полей/блитов» аппаратных
 *   движков нет: у Cedarview 2D/3D — только через микроядро PowerVR
 *   (init-скрипты UM, отчёт corax89 11.3-11.5) — подъём требует полного
 *   переноса PVR Services и остаётся ЗА пределами проекта.
 *
 * Безопасность: при отсутствии GMA3600 (86Box) модуль молчит.
 */
#include "types.h"
#include "pci.h"
#include "string.h"
#include "timer.h"
#include "kernel.h"
#include "gma3600_2d.h"

extern void serial_puts(const char *s);

/* Доступ к gma3600.c (BAR0 MMIO + активная труба) */
extern int  gma3600_active(void);
extern u32  gma3600_mmio_base(void);
extern int  gma3600_pipe(void);

/* --- регистры курсорных плоскостей (для отключения) --- */
/* A: 0x70080, B: 0x700C0 (CURxCNTR; отчёт corax89 Прил. А.1) */
#define CUR_CNTR(p)   (0x70080u + (u32)(p) * 0x40u)
#define CMODE_DISABLE 0x00u
#define PGETBL_CTL    0x2020u

static u32 g2_mmio = 0;
static int g2_on = 0;           /* модуль активен (GMA3600 есть) */

static inline u32 r32(u32 off)
{
    return *(volatile u32 *)(unsigned long)(g2_mmio + off);
}
static inline void w32(u32 off, u32 v)
{
    *(volatile u32 *)(unsigned long)(g2_mmio + off) = v;
    (void)r32(off);                     /* постинг */
}

int gma3600_2d_active(void) { return g2_on; }

static void g2_log(const char *s)
{
    serial_puts("[boot] ");
    serial_puts(s);
    serial_puts("\n");
    klog_puts(s);
}

static void g2_logf(const char *fmt, ...)
{
    char b[160];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(b, sizeof(b), fmt, ap);
    __builtin_va_end(ap);
    g2_log(b);
}

int gma3600_2d_init(void)
{
    g2_on = 0;
    g2_mmio = 0;

    if (!gma3600_active()) {
        serial_puts("[boot] gma3600_2d: нет GMA3600 — модуль молчит\n");
        klog_puts("gma3600_2d: нет GMA3600 — модуль молчит");
        return 0;
    }
    g2_mmio = gma3600_mmio_base();

    /* 1. Аппаратный курсор: СНЯТЬ на обеих трубах (сессия 87). После
     *    этого wm.c рисует программный курсор тем же путём, что и весь
     *    интерфейс. */
    w32(CUR_CNTR(0), CMODE_DISABLE);
    w32(CUR_CNTR(1), CMODE_DISABLE);
    g2_logf("gma3600_2d: аппаратный курсор отключён (CURACNTR=%08x, "
            "CURBCNTR=%08x) — курсор программный (wm.c)",
            (unsigned)r32(CUR_CNTR(0)), (unsigned)r32(CUR_CNTR(1)));

    /* 2. GTT-диагностика (только чтение): при выключенном GTT адреса
     *    поверхностей — физические. */
    u32 pgetbl = r32(PGETBL_CTL);
    if (!(pgetbl & 1u))
        g2_logf("gma3600_2d: GTT выключен (PGETBL %08x)",
                (unsigned)(pgetbl & 0xFFFFF000u));
    else
        g2_logf("gma3600_2d: GTT включён (PGETBL %08x)",
                (unsigned)(pgetbl & 0xFFFFF000u));

    /* 3. СЕССИЯ 90: 3D/2D-ускорение снято по запросу пользователя
     *    (SGX-эксперименты давали чёрный экран на X101CH). Никаких
     *    записей в окно SGX больше нет. */
    g2_on = 1;
    extern int mtrr_lfb_wc_enabled(void);
    g2_log(mtrr_lfb_wc_enabled()
               ? "gma3600_2d: модуль активен: рендер программный (compose), LFB — WC MTRR"
               : "gma3600_2d: модуль активен: рендер программный (compose), LFB без WC (см. mtrr)");
    return 1;
}
