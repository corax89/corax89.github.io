/* mem.c — скан карты памяти Multiboot + простой аллокатор (first-fit со слиянием)
 *
 * Учёт памяти ПО ЗАДАЧАМ (диспетчер задач показывает «Mem»):
 * поле used блока хранит task_idx+1 владельца (0 = блок свободен).
 * malloc атрибутирует блок текущей задаче; task_spawn переносит владение
 * стеком новой задачи (mem_reassign); mem_task_used() суммирует блоки. */
#include "mem.h"
#include "string.h"
#include "io.h"
#include "task.h"
#include "timer.h"
#include "oslog.h"      /* Task 64 [MEM-DIAG]: отчёты — serial + dmesg */

/* символы linker-скрипта: в C пишем без подчёркивания, COFF добавит '_' */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

static u32 heap_start = 0, heap_end = 0, heap_pos = 0;
static u64 ram_total = 0;

typedef struct {
    u32 size;   /* полный размер блока, включая заголовок */
    u32 used;
} mblock_t;

#define MBLOCK_HDR sizeof(mblock_t)
#define ALIGN8(x)  (((x) + 7u) & ~7u)

static u32 align_up(u32 v, u32 a) { return (v + a - 1) & ~(a - 1); }

void mem_init(const mb_info_t *mb)
{
    u32 kend = align_up((u32)(unsigned long)bss_end, 4096);
    u32 best_start = 0, best_size = 0;

    ram_total = 0;

    if (mb->flags & MBIF_MMAP) {
        const u8 *p = (const u8 *)(unsigned long)mb->mmap_addr;
        const u8 *endp = p + mb->mmap_length;
        while (p + 4 <= endp) {
            const mb_mmap_t *e = (const mb_mmap_t *)p;
            if (e->size < 20) break;
            /* [MEM-FIX3] (Task 54, проверка отчёта п.3): p += e->size + 4
             * при e->size ~ 0xFFFFFFFC заворачивалось в 0 — вечный цикл
             * на BSP. Граница записи: её длина не должна выходить за
             * конец карты (и сама p+4+e->size не должна завернуть). */
            if ((u64)(unsigned long)(endp - p) < (u64)e->size + 4u) break;
            if (e->type == 1) {
                u64 reg_end = e->addr + e->len;
                ram_total += e->len;
                /* ищем самый большой пригодный кусок выше конца ядра */
                if (reg_end > (u64)kend + 0x1000000u) { /* >16МБ после ядра */
                    u64 hs = (e->addr > kend) ? e->addr : kend;
                    u64 sz = reg_end - hs;
                    /* [MEM-FIX4/5] (Task 54, проверка отчёта п.4-5): ОС
                     * 32-битная — регион/куча обрезаются к 4 ГиБ, иначе
                     * (u32)sz терял старшие байты (sz=4ГиБ -> 0 -> куча
                     * нулевого размера), а heap_start+cap мог завернуть
                     * heap_end ВНИЗ. */
                    if (hs > 0xFFFFFFFFull) continue;
                    if (reg_end > 0x100000000ull) reg_end = 0x100000000ull;
                    sz = reg_end - hs;
                    if (sz > (u64)best_size) {
                        best_size = (u32)sz;
                        best_start = (u32)hs;
                    }
                }
            }
            p += e->size + 4;
        }
    }
    if (!best_start && (mb->flags & MBIF_MEM) && mb->mem_upper > 2048) {
        /* запасной путь: mem_upper (КБ выше 1М) */
        u32 top = 0x100000u + mb->mem_upper * 1024u;
        if (top > kend + 0x400000u) {
            best_start = (kend > 0x200000u) ? kend : 0x200000u;
            best_size = top - best_start;
        }
    }
    if (!best_start) {
        /* крайний случай: 32 МиБ начиная с 2М (обычно не сработает лишь на экзотике).
         * [MEM-FIX6] (Task 54, проверка отчёта п.6): не опускаться НИЖЕ
         * конца ядра — иначе куча ложится ПОВЕРХ ядра (bss_end ~ 2+ МиБ). */
        best_start = (kend > 0x200000u) ? kend : 0x200000u;
        best_size  = 0x2000000u;
    }

    heap_start = align_up(best_start, 4096);
    /* не захватываем больше 512 МиБ — на реальном железе за картой могут быть дыры */
    u32 cap = (best_size > 0x20000000u) ? 0x20000000u : best_size;
    /* [MEM-FIX8] (Task 54, проверка отчёта п.8): cap кратен 8 — иначе
     * первый блок получал size, не кратный 8, blk_hdr_ok падал и
     * аллокатор умирал с первого malloc. Заодно не даём heap_end
     * перелиться 32-битное пространство (heap_start ~ 4 ГиБ). */
    cap &= ~7u;
    if ((u64)heap_start + (u64)cap > 0xFFFFFFFFull)
        cap = (u32)(0xFFFFFFFFull - (u64)heap_start + 1ull) & ~7u;
    heap_end = heap_start + cap;
    if (heap_end <= heap_start) return;   /* вырожденный случай — без кучи */

    /* первый пустой блок на весь регион */
    mblock_t *b = (mblock_t *)heap_start;
    b->size = heap_end - heap_start;
    b->used = 0;
    heap_pos = heap_start;
}

/* ШАГ 2 (SMP-rework): собственный спинлок кучи.
 *
 * Замена FIX [M1] (cli): cli глушит прерывания ТОЛЬКО СВОЕГО ядра — на
 * SMP второе ядро (AP) спокойно исполняет malloc/free ПАРАЛЛЕЛЬНО и
 * пишет b->used/b->size в тот же linked list (следствие — «ПОРЧА КУЧИ:
 * блок size=0»). Куча больше не зависит ни от klock, ни от cli:
 * единственная защита — heap_lock (lock xchg acquire / store release),
 * критические секции — микросекунды, замок НИКОГДА не держится через
 * hlt/msleep. Работает и на BSP, и на AP, и из IRQ-контекста. */
static volatile int heap_lock = 0;

static void heap_acq(void)
{
    while (__sync_lock_test_and_set(&heap_lock, 1))   /* lock xchg */
        __asm__ __volatile__("pause" ::: "memory");
}
static void heap_rel(void)
{
    __sync_lock_release(&heap_lock);                  /* store-release */
}

/* Сессия 59: ЗДОРОВЬЕ ЗАГОЛОВКА БЛОКА. Порча кучи (лог пользователя:
 * «блок size=0 — запись мимо буфера») раньше проявлялась как ШТОРМ
 * сообщений на каждый malloc/free и полный паралич аллокатора. Теперь
 * walk останавливается на любом нездоровом заголовке (size < HDR,
 * не кратен 8 или выходит за heap_end), а диагностика печатается ОДИН
 * раз (лесипка), чтобы serial оставался читаемым для поиска виновника.
 * Возвращает 1 = заголовок здоров. */
static volatile int heap_corrupt_reported = 0;

static int blk_hdr_ok(const mblock_t *b)
{
    u32 sz = b->size;
    if (sz < MBLOCK_HDR) return 0;
    if (sz & 7u) return 0;                          /* выравнивание 8 */
    if ((u32)(unsigned long)b + sz > heap_end) return 0;
    return 1;
}

/* Вызывается ИЗ-ПОД heap_lock (malloc/free): дамп без повторного захвата. */
static void mem_dump_blocks_locked(void);
static void heap_report_corrupt(const mblock_t *b, const char *where)
{
    if (heap_corrupt_reported) return;
    heap_corrupt_reported = 1;
    extern void serial_puts(const char *s);
    char tb[160];
    extern int snprintf(char*,u32,const char*,...);
    snprintf(tb, sizeof(tb),
             "[mem] ПОРЧА КУЧИ (%s): блок %x size=%u used=%u — walk остановлен, "
             "проверь канарейки стеков ниже в логе\n",
             where, (unsigned)(unsigned long)b,
             (unsigned)b->size, (unsigned)b->used);
    serial_puts(tb);
    mem_dump_blocks_locked();
}

/* ================= Task 64 [MEM-DIAG]: исчерпание памяти =================
 * Жалоба: «места в системе больше нет», хотя mem/диспетчер задач
 * показывают полкучы свободно. Причина, как правило, НЕФРАГМЕНТИРОВАННОСТЬ:
 * free-дырки малы (наибольший блок << суммарно свободного), и первый
 * first-fit отказ под большой запрос. Прежде отказ молчал — теперь
 * при КАЖДОМ отказе malloc пишет в dmesg (oslog) полный разбор:
 *   - кто просил (задача + адрес вызова — сверяется с build/kernel.map);
 *   - занято/свободно/наибольший свободный блок/число дырок;
 *   - ВЕРДИКТ: фрагментация / места реально нет / порча кучи;
 *   - топ-5 владельцев памяти (по задачам).
 * Ограничение частоты: не чаще раза в 2 с (иначе retry-циклы
 * затопили бы журнал), счётчик отказов — всегда. */
static volatile u32 mem_fail_n = 0;          /* всего отказов malloc */
static u32 mem_fail_last_tick = 0;           /* tick последнего отчёта */

#define MEM_DIAG_PERIOD_TICKS 200u           /* 2 с при 100 Гц */

/* Статистика кучи БЕЗ захвата замка (вызывается ИЗ-ПОД heap_lock). */
static void mem_stats_locked(u32 *used, u32 *freeb, u32 *largest, u32 *nfree)
{
    u32 u = 0, f = 0, lg = 0, nf = 0;
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* порча — стоп */
        if (b->used) u += b->size;
        else {
            f += b->size;
            nf++;
            if (b->size > lg) lg = b->size;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    if (used)   *used = u;
    if (freeb)  *freeb = f;
    if (largest)*largest = lg;
    if (nfree)  *nfree = nf;
}

/* Топ-5 владельцев (задачи) по занятой памяти. ИЗ-ПОД heap_lock. */
static void mem_top_owners_locked(char *out, int cap)
{
    static u32 sum[MAX_TASKS + 1];              /* +1: used=0xFFFFFFFF (вне задач) */
    memset(sum, 0, sizeof(sum));
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;
        if (b->used) {
            u32 o = b->used - 1;
            if (o == 0xFFFFFFFEu) o = MAX_TASKS;  /* сентинел вне задач */
            if (o < MAX_TASKS + 1) sum[o] += b->size;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    out[0] = 0;
    int pos = 0;
    for (int k = 0; k < 5; k++) {
        int best = -1;
        for (int i = 0; i <= MAX_TASKS; i++)
            if (sum[i] && (best < 0 || sum[i] > sum[best]))
                best = i;
        if (best < 0 || sum[best] == 0) break;
        u32 val = sum[best];
        sum[best] = 0;                       /* не брать снова */
        const char *nm = (best == MAX_TASKS) ? "<вне задач>"
                                             : task_name(best);
        char line[96];
        extern int snprintf(char*,u32,const char*,...);
        snprintf(line, sizeof(line), "%s#%d '%s' %uК",
                 k ? ", " : "", best, nm, (unsigned)(val / 1024));
        int l = 0;
        while (line[l] && pos < cap - 1) out[pos++] = line[l++];
    }
    out[pos] = 0;
}

/* Полный отчёт об отказе. ВЫЗЫВАЕТСЯ ИЗ-ПОД heap_LOCK (из malloc). */
static void mem_report_exhaust_locked(u32 need, void *caller)
{
    mem_fail_n++;
    u32 now = timer_ticks();
    if (mem_fail_last_tick &&
        (u32)(now - mem_fail_last_tick) < MEM_DIAG_PERIOD_TICKS)
        return;                                  /* лимит частоты */
    mem_fail_last_tick = now;

    u32 used = 0, freeb = 0, largest = 0, nfree = 0;
    mem_stats_locked(&used, &freeb, &largest, &nfree);

    int t = task_current();
    const char *tname = (t >= 0) ? task_name(t) : "<вне задач>";

    char top[220];
    mem_top_owners_locked(top, (int)sizeof(top));

    oslogf("mem", "ОТКАЗ malloc: нужно %u байт, задача %d '%s', вызов из %x",
           (unsigned)need, t, tname, (unsigned)(unsigned long)caller);
    oslogf("mem", "куча %uК: занято %uК, свободно %uК",
           (unsigned)((heap_end - heap_start) / 1024),
           (unsigned)(used / 1024), (unsigned)(freeb / 1024));
    oslogf("mem", "дырок %u, наибольший свободный блок %uК (запрос %u байт)",
           (unsigned)nfree, (unsigned)(largest / 1024), (unsigned)need);

    const char *verdict;
    if (largest >= need) {
        /* first-fit обязан был найти — заголовки врут: порча */
        verdict = "ВЕРДИКТ: ПОРЧА (блок есть, first-fit не нашёл) — см. канарейки/дамп";
        mem_dump_blocks_locked();
    } else if (freeb >= need + MBLOCK_HDR) {
        verdict = "ВЕРДИКТ: ФРАГМЕНТАЦИЯ (суммарно свободно, дырки мельче запроса)";
    } else {
        verdict = "ВЕРДИКТ: места реально нет (суммарно меньше запроса)";
    }
    oslogf("mem", "%s", verdict);
    oslogf("mem", "топ владельцев: %s", top);
    oslogf("mem", "всего отказов malloc с загрузки: %u", (unsigned)mem_fail_n);
}

void *malloc(u32 n)
{
    if (!heap_start || n == 0) return NULL;
    /* [MEM-FIX1] (Task 54, проверка отчёта п.1): переполнение u32 в
     * ALIGN8(n)+HDR при n ~ 4 ГиБ давало need=8 и «успешную» аллокацию
     * нулевого размера (порча кучи первым же memcpy). Грубая граница по
     * размеру кучи + явная проверка заворота need. */
    if (n > heap_end - heap_start) return NULL;
    u32 need = ALIGN8(n) + MBLOCK_HDR;
    if (need < MBLOCK_HDR) return NULL;      /* заворот ALIGN8+HDR */

    heap_acq();

    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        /* Сессия 59: порча кучи — нездоровый заголовок (size=0 у
         * пользователя был частным случаем). Останавливаем walk,
         * диагностируем ОДИН раз и отказываемся от аллокации. */
        if (!blk_hdr_ok(b)) {
            heap_report_corrupt(b, "malloc");
            heap_rel();
            return NULL;
        }
        if (!b->used && b->size >= need) {
            /* расщепление, если остаток вмещает ещё один блок */
            if (b->size >= need + MBLOCK_HDR + 16) {
                mblock_t *nb = (mblock_t *)((u8 *)b + need);
                nb->size = b->size - need;
                nb->used = 0;
                b->size = need;
            }
            /* владелец: текущая задача (+1; kmain = задача 0 → 1).
             * [SLOCK-NO-TASK] (сопровождение бага №3): контекст ВНЕ задач
             * (AP-idle: task_current() == -1) дал бы used=0 = «блок
             * СВОБОДЕН» — следующий malloc расщепил бы ЖИВОЙ блок.
             * Кодируем отдельным значением 0xFFFFFFFF. */
            {
                int t = task_current();
                b->used = (u32)(t + 1);
                if (!b->used) b->used = 0xFFFFFFFFu;
            }
            heap_rel();
            return (u8 *)b + MBLOCK_HDR;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    /* Task 64 [MEM-DIAG]: отказ — полный разбор в dmesg (лимит частоты
     * внутри; счётчик — всегда). __builtin_return_address(0) — адрес
     * ВЫЗЫВАЮЩЕГО malloc (ядро -fno-pic: адрес статичен, ищется в
     * build/kernel.map: nm -n build/kernel.tmp.exe). */
    mem_report_exhaust_locked(need, __builtin_return_address(0));
    heap_rel();
    return NULL;
}

void free(void *p)
{
    if (!p) return;
    heap_acq();
    mblock_t *b = (mblock_t *)((u8 *)p - MBLOCK_HDR);
    /* Сессия 59: дикий free (указатель мимо кучи / не выровнен /
     * заголовок нездоров) раньше молча писал used=0 в чужую память.
     * Теперь отказ с диагностикой — запись НЕ делается. */
    if ((u32)(unsigned long)p < heap_start + MBLOCK_HDR ||
        (u32)(unsigned long)p >= heap_end ||
        ((u32)(unsigned long)p & 7u)) {
        /* [MEM-FIX7] (Task 54, проверка отчёта п.7): дикий указатель вне
         * кучи — НЕ читаем b->size/b->used ( heap_report_corrupt печатал
         * мусор из чужой памяти по адресу p-HDR ). Печатаем только сам
         * указатель. */
        heap_corrupt_reported = 1;
        extern void serial_puts(const char *s);
        char tb[96];
        extern int snprintf(char*,u32,const char*,...);
        snprintf(tb, sizeof(tb),
                 "[mem] ДИКИЙ free: указатель %x вне кучи [%x..%x)\n",
                 (unsigned)(unsigned long)p,
                 (unsigned)heap_start, (unsigned)heap_end);
        serial_puts(tb);
        heap_rel();
        return;
    }
    if (!blk_hdr_ok(b)) {
        heap_report_corrupt(b, "free");
        heap_rel();
        return;
    }
    if (!b->used) {
        /* двойной free — слияние уже сделано, просто игнорируем */
        heap_rel();
        return;
    }
    b->used = 0;

    /* слияние с последующими свободными.
     * [MEM-FIX2] (Task 54, проверка отчёта п.2): заголовок next НЕ
     * проверялся — при порче (size==0 && used==0) цикл не продвигался
     * (b->size += 0) и зависал навсегда, держа heap_lock. Теперь перед
     * чтением next->used/size проверяем blk_hdr_ok(next) — нездоровый
     * сосед останавливает слияние (диагностику не дублируем: ходовой
     * malloc/free уже репортит порчу своего заголовка). */
    mblock_t *next;
    for (;;) {
        next = (mblock_t *)((u8 *)b + b->size);
        if ((u32)(unsigned long)next >= heap_end) break;
        if (!blk_hdr_ok(next)) break;               /* порча — не трогаем */
        if (next->used) break;
        b->size += next->size;
    }
    heap_rel();
}

u32 mem_used(void)
{
    u32 used = 0;
    if (!heap_start) return 0;
    heap_acq();                     /* ШАГ 2: обход кучи — тоже под замком */
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* сессия 59: порча — стоп */
        if (b->used) used += b->size;
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_rel();
    return used;
}

/* Перенести владение уже выделенным блоком на другую задачу.
 * Используется task_spawn: стек новой задачи выделяется в контексте
 * ПОРОЖДАЮЩЕЙ задачи — переносим на нового владельца. */
void mem_reassign(void *p, int task_idx)
{
    if (!p) return;
    heap_acq();
    mblock_t *b = (mblock_t *)((u8 *)p - MBLOCK_HDR);
    /* [MEM-FIX9/10] (Task 54, проверка отчёта п.9-10): проверить
     * здоровье заголовка; task_idx == -1 (вне задач) — кодировать
     * сентинелом 0xFFFFFFFF, а не used=0 (иначе блок «освобождался»
     * без слияния и учёта). */
    if ((u32)(unsigned long)b >= heap_start &&
        (u32)(unsigned long)b < heap_end &&
        blk_hdr_ok(b) && b->used) {
        b->used = (task_idx < 0) ? 0xFFFFFFFFu : (u32)(task_idx + 1);
    }
    heap_rel();
}

/* Суммарная память, занятая задачей task_idx (один проход по куче). */
u32 mem_task_used(int task_idx)
{
    u32 used = 0;
    u32 owner = (u32)(task_idx + 1);
    if (!heap_start) return 0;
    heap_acq();
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* сессия 59 */
        if (b->used == owner) used += b->size;
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_rel();
    return used;
}

u32 mem_heap_size(void) { return heap_end - heap_start; }

u32 mem_ram_mib(void) { return (u32)(ram_total >> 20); }

/* Task 64 [MEM-DIAG]: счётчик отказов malloc (для `mem -v`/диспетчера). */
u32 mem_fail_count(void)
{
    return mem_fail_n;
}


/* Сессия 13 (диагностика): обход кучи — свободные байты/блоки/макс.блок */
u32 mem_debug_walk(u32 *largest, u32 *nfree)
{
    u32 free_total = 0;
    u32 lg = 0, nf = 0;
    if (!heap_start) return 0;
    heap_acq();
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* сессия 59 */
        if (!b->used) {
            free_total += b->size;
            nf++;
            if (b->size > lg) lg = b->size;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_rel();
    if (largest) *largest = lg;
    if (nfree) *nfree = nf;
    return free_total;
}


/* Сессия 13 (диагностика): полный дамп блоков кучи в serial.
 * ШАГ 2: разделён на internal (без замка — зовётся из heap_report_corrupt,
 * которая уже держит heap_lock; повторный захват само-дедлокнул бы) и
 * публичный mem_dump_blocks (захватывает замок сам). */
static void mem_dump_blocks_locked(void)
{
    extern void serial_puts(const char *s);
    mblock_t *b = (mblock_t *)heap_start;
    int n = 0;
    while ((u32)(unsigned long)b < heap_end && n < 200) {
        char tb[96];
        extern int snprintf(char*,u32,const char*,...);
        snprintf(tb, sizeof(tb), "  blk %x size=%u owner=%u%s\n",
                 (unsigned)(unsigned long)b, (unsigned)b->size,
                 (unsigned)(b->used ? b->used - 1 : 0xFFFFFFFFu),
                 b->used ? "" : " (free)");
        serial_puts(tb);
        if (!blk_hdr_ok(b)) {
            serial_puts("  ...(заголовок побит — walk стоп, блоки выше не видны)\n");
            break;
        }
        b = (mblock_t *)((u8 *)b + b->size);
        n++;
    }
}

void mem_dump_blocks(void)
{
    if (!heap_start) return;
    heap_acq();
    mem_dump_blocks_locked();
    heap_rel();
}


/* Сессия 13: сторож — есть ли size==0 (порча)? 1 = есть */
int mem_check_corrupt(void)
{
    if (!heap_start) return 0;
    heap_acq();
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) {                   /* сессия 59: любая порча */
            heap_rel();
            return 1;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_rel();
    return 0;
}
