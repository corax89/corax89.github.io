/* sdl_ops.h — нумерация SDL2-операций c4 (Task 54).
 *
 * ЕДИНЫЙ источник порядка для трёх потребителей:
 *   - c4.c     (VM-путь: имена сисколов + диспетчер VM-цикла);
 *   - c4_x86.c (native-путь: emit call [edi+KAPI_SDL_CALL] с номером op);
 *   - sdl2.c   (диспетчер c4_sdl_call — switch по C4_SDL_IDX_*).
 *
 * Порядок X-макроса МЕНЯТЬ ТОЛЬКО ДОБАВЛЕНИЕМ В КОНЕЦ: номера зашиты
 * в сгенерированные .bin (как и у остальных опкодов c4). */
#ifndef SDL_OPS_H
#define SDL_OPS_H

/* инициализация/ошибки */
#define C4_SDL_OP_LIST(X) \
    X(SDLINIT)  X(SDLQUIT)  X(SDLQUITSUB) \
    X(SDLGETERR) X(SDLSETERR) X(SDLCLRERR) \
    /* окно */ \
    X(SDLCREATEWIN) X(SDLDESTROYWIN) X(SDLGETWINSIZE) X(SDLSETWINTITLE) \
    X(SDLGETWINSURF) X(SDLUPDWINSURF) \
    /* рендерер */ \
    X(SDLCREATEREND) X(SDLDESTROYREND) X(SDLSETDRAWCOLOR) \
    X(SDLGETRENDOUT) \
    X(SDLRENDCLR) X(SDLRENDFILLRECT) X(SDLRENDDRAWRECT) \
    X(SDLRENDDRAWLINE) X(SDLRENDDRAWPOINT) X(SDLRENDCOPY) \
    X(SDLRENDPRESENT) \
    /* текстуры */ \
    X(SDLCREATETEX) X(SDLCREATETEXFS) X(SDLDESTROYTEX) X(SDLUPDTEX) \
    X(SDLLOCKTEX) X(SDLUNLOCKTEX) \
    /* surface */ \
    X(SDLCREATERGBSURF) X(SDLFREESURF) X(SDLLOCKSURF) X(SDLUNLOCKSURF) \
    X(SDLSETCOLORKEY) X(SDLBLITSURF) X(SDLLOADBMP) \
    /* события */ \
    X(SDLPOLLEVENT) X(SDLWAITEVENT) X(SDLWAITEVTO) X(SDLPUSHEVENT) \
    /* ввод */ \
    X(SDLGETKBSTATE) X(SDLGETMOUSESTATE) \
    /* время */ \
    X(SDLDELAY) X(SDLGETTICKS) X(SDLGETPERFCNT) X(SDLGETPERFFREQ) \
    /* запуск приложения */ \
    X(SDLRUNAPP)

/* индексы 0..N-1 в порядке списка: C4_SDL_IDX_SDLINIT == 0, ... */
enum {
#define C4_SDL_IDX(nm) C4_SDL_IDX_##nm,
C4_SDL_OP_LIST(C4_SDL_IDX)
#undef C4_SDL_IDX
    C4_SDL_OP_COUNT            /* число операций (последний индекс + 1) */
};

#endif /* SDL_OPS_H */
