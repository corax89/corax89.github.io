/* clipboard.c — общесистемный текстовый буфер обмена (см. clipboard.h). */
#include "types.h"
#include "string.h"
#include "sync.h"
#include "clipboard.h"

static char clip_buf[CLIP_TEXT_MAX + 1];
static int  clip_len = 0;
static volatile int clip_lock = 0;

void clip_text_set(const char *data, int len)
{
    s_lock(&clip_lock);
    if (!data || len == 0) {
        clip_buf[0] = 0;
        clip_len = 0;
        s_unlock(&clip_lock);
        return;
    }
    if (len < 0) len = strlen(data);
    if (len > CLIP_TEXT_MAX) len = CLIP_TEXT_MAX;
    /* рез по границе символа UTF-8: не оставляем половину буквы */
    while (len > 0 && ((unsigned char)data[len] & 0xC0) == 0x80) len--;
    memcpy(clip_buf, data, (u32)len);
    clip_buf[len] = 0;
    clip_len = len;
    s_unlock(&clip_lock);
}

const char *clip_text_get(void)
{
    return clip_buf;
}

int clip_text_len(void)
{
    return clip_len;
}

void clip_text_clear(void)
{
    s_lock(&clip_lock);
    clip_buf[0] = 0;
    clip_len = 0;
    s_unlock(&clip_lock);
}
