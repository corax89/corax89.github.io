/* kernel.h — глобальные службы ядра */
#ifndef KERNEL_H
#define KERNEL_H

#include "types.h"
#include "boot.h"

const mb_info_t *mb_info(void);
void sys_reboot(void);
void sys_poweroff(void);

/* Журнал загрузки (klog): кольцевой буфер строк. Каждая строка dbg()/
 * dbg_err() + ключевые вехи kmain попадают сюда; команда dmesg в
 * терминале выводит журнал целиком («процесс загрузки»). */
void        klog_puts(const char *s);       /* добавить строку (без \n) */
const char *klog_get(void);                 /* весь журнал, '\n'-разделённый */
int         klog_line_count(void);

/* Task 49: serial/ранний вывод — boot.c; klog-экран — klog.c
 * (раньше всё это было static в kernel.c). */
void serial_init(void);
void early_fb_init(const mb_info_t *mb);
void early_clear(void);
void early_puts(const char *s);
void early_putc(char c);
void early_putu(u32 v);
void early_puthex(u32 v);
void vga_fail(const char *msg);       /* печатает и останавливается */
void dbg(const char *s);              /* serial + klog + экран (до WM) */
void dbg_err(const char *s);
void klog_screen_off(void);           /* погасить экранный лог (после WM) */
void klog_screen_colors(u32 ok, u32 err);

/* Сессия 11: 0/1 = фоновая инициализация SATA идёт/не идёт (fileman
 * показывает «инициализация...» вместо пустого списка до готовности). */
int sata_pending(void);

/* Сессия 15: 0/1 = фоновая инициализация WiFi идёт/не идёт (нетбук
 * больше НЕ ждёт адаптер при загрузке: PCI-скан + сброс + калибровки
 * AR9485 занимали секунды — рабочий стол поднимается сразу, адаптер
 * «доезжает» позже; WiFi-приложение и Настройки показывают статус). */
int wifi_pending(void);

/* Сессия 11: перезапросить DHCP на активном адаптере (netmon). */
void net_request_dhcp(void);

/* Сессия 27: статическая настройка IP (Настройки → Сеть, SETTINGS.CFG).
 * Пока включён статический режим, netmon НЕ запускает DHCP, а применяет
 * сохранённые адреса к активному адаптеру (повторно — после его смены). */
int  netcfg_static_mode(void);                 /* 1 = статический, 0 = DHCP */
void netcfg_use_static(int on);                /* переключить режим */
void netcfg_set_static(u32 ip, u32 mask, u32 gw, u32 dns); /* применить */
void netcfg_static_get(u32 *ip, u32 *mask, u32 *gw, u32 *dns); /* для UI */

#endif
