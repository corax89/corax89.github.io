/* gfx2d.c — общий слой графики.
 *
 * СЕССИЯ 90 (запрос пользователя: «откажись от 3д и 2д ускорения...
 * (так же удали ускорение для voodoo 3)»): бэкенды 2D-ускорения удалены
 * (voodoo3.c — blit compose->LFB + аппаратный курсор для 86Box;
 * gma3600 SGX-эксперименты — чёрный экран на X101CH).
 *
 * Осталось только:
 *   - no-op API курсора (wm.c вызывает, но готовность = 0 -> рисует
 *     программный курсор сама, тем же движком, что и весь интерфейс);
 *   - строка статуса GPU для «Системной информации». */
#include "gfx2d.h"
#include "fb.h"
#include "cpu.h"       /* cpu_has_sse2 — уровень SIMD-диспетчера fb.c */
#include "string.h"

/* Аппаратного курсора больше нет нигде — wm.c рисует программный. */
int  gfx2d_cursor_ready(void) { return 0; }
void gfx2d_cursor_move(int x, int y) { (void)x; (void)y; }
void gfx2d_cursor_show(int on)       { (void)on; }

/* Статус GPU/рендера для «Системной информации».
 * [SYSINFO-SSE2]: при активном уровне 2 (SSE2-диспетчер fb.c: movdqa/
 * movntdq, в т.ч. стриминг в WC-LFB) показываем это в строке GPU. */
const char *gfx2d_gpu_info(void)
{
    extern int gma3600_active(void);

    static char buf[112];
    const char *simd = cpu_has_sse2 ? ", sse2" : (cpu_has_sse ? ", sse" : "");
    if (gma3600_active()) {
        extern int mtrr_lfb_wc_enabled(void);
        snprintf(buf, sizeof(buf), "Intel GMA3600 (Cedarview) %ux%u, софт (WC: %s%s)",
                 (unsigned)fb_width(), (unsigned)fb_height(),
                 mtrr_lfb_wc_enabled() ? "да" : "нет", simd);
    } else {
        snprintf(buf, sizeof(buf), "VESA LFB %ux%u, программный рендер (%s)",
                 (unsigned)fb_width(), (unsigned)fb_height(),
                 simd[0] ? simd + 2 : "скаляр");
    }
    return buf;
}
