/* flacsvc.h — сервис FLAC-декодирования N2600-OS (Task 46).
 *
 * Обёртка над libfoxenflac (src/foxen-flac.c, вендор astoeckel/
 * libfoxenflac, LGPL-2.1+) — декодирование FLAC для аудио-приложений:
 *   - нативный плеер (apps_mp3.c) — .flac рядом с .mp3;
 *   - будущие приложения.
 *
 * libfoxenflac — чисто целочисленный потоковый декодер без malloc
 * внутри (буфер декодера даёт вызывающий — fx_flac_size), без FPU
 * и без stdio: идеально для freestanding-ядра.
 *
 * Вход — ЦЕЛИКОМ файл в памяти (как у mp3svc): плеер получает буфер
 * от файлового менеджера/диалога и передаёт во владение. Декодер
 * читает по месту, выход — s16 interleaved (как у mp3svc).
 *
 * Позиционирование (seek) libfoxenflac не поддерживает: flac_rewind
 * сбрасывает декодер на начало (fx_flac_reset + позиция файла 0). */
#ifndef FLACSVC_H
#define FLACSVC_H

#include "types.h"

/* Открыть FLAC из памяти (data остаётся владельцем буфера и должен
 * жить, пока контекст открыт). Контекст создаётся внутри (malloc);
 * NULL = не FLAC/битый файл (детали — flac_errstr). */
void *flac_open_mem(const void *data, u32 len);

/* Закрыть контекст (освобождает всё, что выделял flac_open_mem). */
void   flac_close(void *ctx);

u32    flac_channels(const void *ctx);   /* 1..2 (многоканальные — отказ при открытии) */
u32    flac_rate(const void *ctx);       /* Гц, напр. 44100 */
u32    flac_bps(const void *ctx);        /* бит на сэмпл из STREAMINFO (8..32) */

/* Всего PCM-фреймов (сэмплов на канал) из STREAMINFO; 0 = нет данных. */
u64    flac_total_frames(const void *ctx);

/* Читать PCM-фреймы: s16 interleaved, channels каналов на фрейм.
 * Возвращает число прочитанных фреймов (0 = конец/ошибка). */
u32    flac_read_s16(void *ctx, i16 *pcm, u32 frames);

/* Сброс декодера на начало потока (аналог mp3_seek(ctx,0)). 1 = успех. */
int    flac_rewind(void *ctx);

/* Текст последней ошибки (для сообщений в UI). */
const char *flac_errstr(void);

#endif /* FLACSVC_H */
