/* sdl2.c — минимальная реализация SDL2-совместимого слоя поверх N2600-OS.
 *
 * Архитектура:
 *   - SDL_CreateWindow → win_create(...): ОС спавнит поток окна.
 *   - Колбэки win_thread_fn (sdl_key_cb / sdl_mouse_cb / sdl_close_cb)
 *     кладут SDL_Event в очередь окна (lock-free-ish через спинлок).
 *   - Поток SDL-приложения (main) крутит свой цикл и вызывает SDL_PollEvent,
 *     SDL_RenderPresent, SDL_Delay.
 *   - SDL_RenderPresent пишет в canvas окна и зовёт fb_touch — kmain
 *     композитит в LFB без участия SDL-кода.
 *
 * Ограничения: один «основной» window (SDL2 и так редко используют
 * несколько), только software-рендеринг, только ARGB8888.
 *
 * Task 54 (интеграция):
 *   - окно создаётся с fixed_size = 1: canvas заполняет ЗАДАЧА
 *     приложения (как у c4gfx) — resize-цикл wm_frame не должен
 *     пересоздавать canvas под пишущей задачей;
 *   - c4_sdl_call(): единый диспетчер для c4-программ — VM-путь (c4.c)
 *     и native-путь (c4_x86.c через kapi_t) вызывают ВСЕ функции этого
 *     файла через один вызов c4_sdl_call(op, args_reversed), где
 *     args_reversed[0] = ПОСЛЕДНИЙ аргумент вызова (стек c4). */
#include "SDL.h"
#include "sdl_ops.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sync.h"
#include "kbd.h"
#include "mouse.h"
#include "ramfs.h"     /* SDL_LoadBMP: чтение из ramfs */

extern void serial_puts(const char *s);

/* ================= внутренние типы ================= */

struct SDL_Window;
struct SDL_Renderer {
    struct SDL_Window *window;
    Uint32 *pixels;         /* backbuffer */
    int     w, h;
    Uint8   r, g, b, a;
};

struct SDL_Texture {
    Uint32 *pixels;
    int     w, h;
    struct SDL_Window *window;
    int     locked;
};

#define SDL_EVQ_SIZE 128

struct SDL_Window {
    window_t *os_win;
    int w, h;                          /* размер canvas */
    SDL_Renderer *renderer;
    SDL_Surface  *surface;             /* lazy */
    SDL_Event events[SDL_EVQ_SIZE];
    volatile int ev_head, ev_tail, ev_lock;
    volatile int closing;
    Uint8  keys[SDL_NUM_SCANCODES];
    int    mouse_x, mouse_y;
    Uint32 mouse_state;                /* SDL_BUTTON_*MASK */
    char   title[64];
};

static SDL_Window *g_primary = NULL;
static char g_error[128] = "";

/* ================= утилиты ================= */

static void sp_lock(volatile int *l) {
    while (__sync_lock_test_and_set(l, 1))
        __asm__ __volatile__("pause" ::: "memory");
}
static void sp_unlock(volatile int *l) {
    __sync_lock_release(l);
}

static void seterr(const char *s) {
    int i = 0;
    while (s[i] && i < (int)sizeof(g_error) - 1) { g_error[i] = s[i]; i++; }
    g_error[i] = 0;
}
const char *SDL_GetError(void) { return g_error; }
void SDL_SetError(const char *fmt, ...) { (void)fmt; /* упрощено */ }
void SDL_ClearError(void) { g_error[0] = 0; }

/* PS/2 set 1 → SDL scancode. Возвращает 0 при неизвестном коде. */
static Uint8 ps2_to_sdl(Uint8 code) {
    switch (code) {
    case 0x01: return SDL_SCANCODE_ESCAPE;
    case 0x0E: return SDL_SCANCODE_BACKSPACE;
    case 0x0F: return SDL_SCANCODE_TAB;
    case 0x1C: return SDL_SCANCODE_RETURN;
    case 0x39: return SDL_SCANCODE_SPACE;
    case 0x2A: return SDL_SCANCODE_LSHIFT;
    case 0x36: return SDL_SCANCODE_RSHIFT;
    case 0x1D: return SDL_SCANCODE_LCTRL;
    case 0x38: return SDL_SCANCODE_LALT;
    /* буквы */
    case 0x1E: return SDL_SCANCODE_A; case 0x30: return SDL_SCANCODE_B;
    case 0x2E: return SDL_SCANCODE_C; case 0x20: return SDL_SCANCODE_D;
    case 0x12: return SDL_SCANCODE_E; case 0x21: return SDL_SCANCODE_F;
    case 0x22: return SDL_SCANCODE_G; case 0x23: return SDL_SCANCODE_H;
    case 0x17: return SDL_SCANCODE_I; case 0x24: return SDL_SCANCODE_J;
    case 0x25: return SDL_SCANCODE_K; case 0x26: return SDL_SCANCODE_L;
    case 0x32: return SDL_SCANCODE_M; case 0x31: return SDL_SCANCODE_N;
    case 0x18: return SDL_SCANCODE_O; case 0x19: return SDL_SCANCODE_P;
    case 0x10: return SDL_SCANCODE_Q; case 0x13: return SDL_SCANCODE_R;
    case 0x1F: return SDL_SCANCODE_S; case 0x14: return SDL_SCANCODE_T;
    case 0x16: return SDL_SCANCODE_U; case 0x2F: return SDL_SCANCODE_V;
    case 0x11: return SDL_SCANCODE_W; case 0x2D: return SDL_SCANCODE_X;
    case 0x15: return SDL_SCANCODE_Y; case 0x2C: return SDL_SCANCODE_Z;
    /* цифры верхнего ряда */
    case 0x02: return SDL_SCANCODE_1; case 0x03: return SDL_SCANCODE_2;
    case 0x04: return SDL_SCANCODE_3; case 0x05: return SDL_SCANCODE_4;
    case 0x06: return SDL_SCANCODE_5; case 0x07: return SDL_SCANCODE_6;
    case 0x08: return SDL_SCANCODE_7; case 0x09: return SDL_SCANCODE_8;
    case 0x0A: return SDL_SCANCODE_9; case 0x0B: return SDL_SCANCODE_0;
    /* стрелки — ОС-коды (см. KBD_UP/DOWN/LEFT/RIGHT в kbd.h) */
    case KBD_UP:    return SDL_SCANCODE_UP;
    case KBD_DOWN:  return SDL_SCANCODE_DOWN;
    case KBD_LEFT:  return SDL_SCANCODE_LEFT;
    case KBD_RIGHT: return SDL_SCANCODE_RIGHT;
    }
    return 0;
}

static int push_event(SDL_Window *w, const SDL_Event *e) {
    sp_lock(&w->ev_lock);
    int next = (w->ev_head + 1) % SDL_EVQ_SIZE;
    if (next == w->ev_tail) { sp_unlock(&w->ev_lock); return 0; }
    w->events[w->ev_head] = *e;
    w->ev_head = next;
    sp_unlock(&w->ev_lock);
    return 1;
}

static int pop_event(SDL_Window *w, SDL_Event *e) {
    sp_lock(&w->ev_lock);
    if (w->ev_head == w->ev_tail) { sp_unlock(&w->ev_lock); return 0; }
    *e = w->events[w->ev_tail];
    w->ev_tail = (w->ev_tail + 1) % SDL_EVQ_SIZE;
    sp_unlock(&w->ev_lock);
    return 1;
}

/* ================= колбэки окна (поток win_thread_fn) ================= */

static void sdl_draw_cb(window_t *ow) {
    (void)ow;
    /* Canvas пишется из SDL-потока через SDL_RenderPresent. Здесь — no-op,
     * нужен только чтобы wm.c выставил drawn_once и окно стало видимым. */
}

static void sdl_key_cb(window_t *ow, const key_event_t *ev) {
    SDL_Window *w = (SDL_Window *)ow->data;
    if (!w) return;
    /* ps2_to_sdl валиден по построению (Uint8, 0..255 < SDL_NUM_SCANCODES)
     * — отдельная проверка диапазона не нужна и была бы всегда ложной. */
    Uint8 sc = ps2_to_sdl((Uint8)(ev->code & 0xFF));

    SDL_Event e;
    memset(&e, 0, sizeof(e));
    int released = (ev->flags & KF_RELEASED) != 0;
    e.type = released ? SDL_KEYUP : SDL_KEYDOWN;
    e.key.timestamp = timer_ticks();
    e.key.scancode  = sc;
    e.key.keycode   = ev->ch ? (Sint32)(Uint8)ev->ch : (Sint32)sc;
    e.key.mod = 0;
    if (ev->flags & KF_SHIFT) e.key.mod |= KMOD_SHIFT;
    if (ev->flags & KF_ALT)   e.key.mod |= KMOD_ALT;

    if (sc) w->keys[sc] = released ? 0 : 1;
    push_event(w, &e);
}

static void sdl_mouse_cb(window_t *ow, int mx, int my, u8 btn, u8 changed) {
    SDL_Window *w = (SDL_Window *)ow->data;
    if (!w) return;

    /* Состояние кнопок → маска SDL */
    Uint32 new_state = 0;
    if (btn & MSB_LEFT)   new_state |= SDL_BUTTON_LMASK;
    if (btn & MSB_RIGHT)  new_state |= SDL_BUTTON_RMASK;
    if (btn & MSB_MID)    new_state |= SDL_BUTTON_MMASK;

    /* Движение */
    if (mx != w->mouse_x || my != w->mouse_y) {
        SDL_Event e;
        memset(&e, 0, sizeof(e));
        e.type = SDL_MOUSEMOTION;
        e.motion.timestamp = timer_ticks();
        e.motion.x     = mx;
        e.motion.y     = my;
        e.motion.xrel  = mx - w->mouse_x;
        e.motion.yrel  = my - w->mouse_y;
        e.motion.state = new_state;
        push_event(w, &e);
    }
    w->mouse_x = mx;
    w->mouse_y = my;

    /* Кнопки: changed — биты переходов */
    Uint8 pressed  = (Uint8)(changed & btn);
    Uint8 released = (Uint8)(changed & ~btn);
    if (pressed & MSB_LEFT)   { SDL_Event e; memset(&e,0,sizeof e);
        e.type = SDL_MOUSEBUTTONDOWN; e.button.timestamp = timer_ticks();
        e.button.button = SDL_BUTTON_LEFT;  e.button.state = 1;
        e.button.clicks = 1; e.button.x = mx; e.button.y = my; push_event(w, &e); }
    if (released & MSB_LEFT)  { SDL_Event e; memset(&e,0,sizeof e);
        e.type = SDL_MOUSEBUTTONUP; e.button.timestamp = timer_ticks();
        e.button.button = SDL_BUTTON_LEFT;  e.button.state = 0;
        e.button.x = mx; e.button.y = my; push_event(w, &e); }
    if (pressed & MSB_RIGHT)  { SDL_Event e; memset(&e,0,sizeof e);
        e.type = SDL_MOUSEBUTTONDOWN; e.button.timestamp = timer_ticks();
        e.button.button = SDL_BUTTON_RIGHT; e.button.state = 1;
        e.button.clicks = 1; e.button.x = mx; e.button.y = my; push_event(w, &e); }
    if (released & MSB_RIGHT) { SDL_Event e; memset(&e,0,sizeof e);
        e.type = SDL_MOUSEBUTTONUP; e.button.timestamp = timer_ticks();
        e.button.button = SDL_BUTTON_RIGHT; e.button.state = 0;
        e.button.x = mx; e.button.y = my; push_event(w, &e); }

    w->mouse_state = new_state;
}

static void sdl_close_cb(window_t *ow) {
    SDL_Window *w = (SDL_Window *)ow->data;
    if (!w) return;
    w->closing = 1;
    SDL_Event e; memset(&e, 0, sizeof(e));
    e.type = SDL_QUIT;
    e.quit.timestamp = timer_ticks();
    push_event(w, &e);
}

static void sdl_tick_cb(window_t *ow) { (void)ow; }

/* ================= SDL API ================= */

int SDL_Init(Uint32 flags) {
    (void)flags;
    return 0;
}
void SDL_Quit(void) {
    if (g_primary) { /* приложение само должно вызвать SDL_DestroyWindow */ }
    g_primary = NULL;
}
void SDL_QuitSubSystem(Uint32 flags) { (void)flags; }

SDL_Window *SDL_CreateWindow(const char *title, int x, int y,
                             int w, int h, Uint32 flags) {
    (void)flags;
    if (w < 8) w = 8;
    if (h < 8) h = 8;

    SDL_Window *sw = (SDL_Window *)malloc(sizeof(*sw));
    if (!sw) { seterr("SDL_CreateWindow: out of memory"); return NULL; }
    memset(sw, 0, sizeof(*sw));

    sw->os_win = win_create(title, x, y, w, h,
                            sdl_draw_cb, sdl_key_cb, sdl_mouse_cb,
                            sdl_tick_cb, sdl_close_cb, sw);
    if (!sw->os_win) {
        free(sw);
        seterr("SDL_CreateWindow: win_create failed");
        return NULL;
    }
    /* [SDL-FIXED] canvas заполняет задача приложения (SDL_RenderPresent),
     * поэтому resize/maximize для окна ЗАПРЕЩЕНЫ — иначе wm_frame
     * пересоздаст canvas под пишущей задачей (модель c4gfx, см. wm.h). */
    sw->os_win->fixed_size = 1;
    sw->w = win_content_w(sw->os_win);
    sw->h = win_content_h(sw->os_win);
    if (title) {
        int i = 0;
        while (title[i] && i < (int)sizeof(sw->title) - 1) {
            sw->title[i] = title[i]; i++;
        }
        sw->title[i] = 0;
    }
    g_primary = sw;
    return sw;
}

void SDL_DestroyWindow(SDL_Window *w) {
    if (!w) return;
    if (w->os_win) win_close(w->os_win);   /* WM сам разберёт canvas и поток */
    if (w->surface) { free(w->surface); w->surface = NULL; }
    if (w->renderer) SDL_DestroyRenderer(w->renderer);
    if (g_primary == w) g_primary = NULL;
    free(w);
}

void SDL_GetWindowSize(SDL_Window *w, int *ww, int *hh) {
    if (ww) *ww = w ? w->w : 0;
    if (hh) *hh = w ? w->h : 0;
}

void SDL_SetWindowTitle(SDL_Window *w, const char *title) {
    if (!w || !title) return;
    int i = 0;
    while (title[i] && i < (int)sizeof(w->title) - 1) {
        w->title[i] = title[i]; i++;
    }
    w->title[i] = 0;
    if (w->os_win) strncpy(w->os_win->title, title, sizeof(w->os_win->title) - 1);
}

/* ---- Window surface (прямой доступ к canvas) ---- */
SDL_Surface *SDL_GetWindowSurface(SDL_Window *w) {
    if (!w || !w->os_win) return NULL;
    if (w->surface) return w->surface;
    SDL_Surface *s = (SDL_Surface *)malloc(sizeof(*s));
    if (!s) return NULL;
    memset(s, 0, sizeof(*s));
    s->w = w->w;
    s->h = w->h;
    s->pitch = w->w * 4;
    s->pixels = w->os_win->canvas;
    s->Rmask = 0x00FF0000; s->Gmask = 0x0000FF00;
    s->Bmask = 0x000000FF; s->Amask = 0xFF000000;
    w->surface = s;
    return s;
}

int SDL_UpdateWindowSurface(SDL_Window *w) {
    if (!w || !w->os_win) return -1;
    fb_touch(w->os_win->x, w->os_win->y, w->os_win->w, w->os_win->h);
    return 0;
}

/* ---- Renderer ---- */
SDL_Renderer *SDL_CreateRenderer(SDL_Window *w, int idx, Uint32 flags) {
    (void)idx; (void)flags;
    if (!w) return NULL;
    SDL_Renderer *r = (SDL_Renderer *)malloc(sizeof(*r));
    if (!r) return NULL;
    memset(r, 0, sizeof(*r));
    r->window = w;
    r->w = w->w;
    r->h = w->h;
    r->pixels = (Uint32 *)malloc((Uint32)r->w * r->h * 4);
    if (!r->pixels) { free(r); return NULL; }
    memset(r->pixels, 0, (Uint32)r->w * r->h * 4);
    r->a = 255;
    w->renderer = r;
    return r;
}

void SDL_DestroyRenderer(SDL_Renderer *r) {
    if (!r) return;
    if (r->window && r->window->renderer == r) r->window->renderer = NULL;
    if (r->pixels) free(r->pixels);
    free(r);
}

int SDL_SetRenderDrawColor(SDL_Renderer *r, Uint8 rr, Uint8 gg, Uint8 bb, Uint8 aa) {
    if (!r) return -1;
    r->r = rr; r->g = gg; r->b = bb; r->a = aa;
    return 0;
}

int SDL_GetRendererOutputSize(SDL_Renderer *r, int *w, int *h) {
    if (!r) return -1;
    if (w) *w = r->w;
    if (h) *h = r->h;
    return 0;
}

static Uint32 draw_color(SDL_Renderer *r) {
    return fb_rgb(r->r, r->g, r->b);
}

int SDL_RenderClear(SDL_Renderer *r) {
    if (!r) return -1;
    Uint32 col = draw_color(r);
    Uint32 *p = r->pixels;
    Uint32 n = (Uint32)r->w * r->h;
    for (Uint32 i = 0; i < n; i++) *p++ = col;
    return 0;
}

int SDL_RenderFillRect(SDL_Renderer *r, const SDL_Rect *rect) {
    if (!r) return -1;
    int x0 = 0, y0 = 0, x1 = r->w, y1 = r->h;
    if (rect) {
        x0 = rect->x; y0 = rect->y;
        x1 = rect->x + rect->w; y1 = rect->y + rect->h;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > r->w) x1 = r->w;
        if (y1 > r->h) y1 = r->h;
    }
    Uint32 col = draw_color(r);
    for (int yy = y0; yy < y1; yy++) {
        Uint32 *row = r->pixels + (Uint32)yy * r->w;
        for (int xx = x0; xx < x1; xx++) row[xx] = col;
    }
    return 0;
}

int SDL_RenderDrawRect(SDL_Renderer *r, const SDL_Rect *rect) {
    if (!r || !rect) return -1;
    SDL_Rect top    = { rect->x, rect->y, rect->w, 1 };
    SDL_Rect bottom = { rect->x, rect->y + rect->h - 1, rect->w, 1 };
    SDL_Rect left   = { rect->x, rect->y, 1, rect->h };
    SDL_Rect right  = { rect->x + rect->w - 1, rect->y, 1, rect->h };
    SDL_RenderFillRect(r, &top);
    SDL_RenderFillRect(r, &bottom);
    SDL_RenderFillRect(r, &left);
    SDL_RenderFillRect(r, &right);
    return 0;
}

int SDL_RenderDrawLine(SDL_Renderer *r, int x0, int y0, int x1, int y1) {
    if (!r) return -1;
    Uint32 col = draw_color(r);
    int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    int sx = x0 < x1 ? 1 : -1;
    int dy = y0 > y1 ? y0 - y1 : y1 - y0;
    int sy = y0 < y1 ? 1 : -1;
    int err = dx - dy;
    for (;;) {
        if (x0 >= 0 && x0 < r->w && y0 >= 0 && y0 < r->h)
            r->pixels[(Uint32)y0 * r->w + x0] = col;
        if (x0 == x1 && y0 == y1) break;
        int e2 = err * 2;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 <  dx) { err += dx; y0 += sy; }
    }
    return 0;
}

int SDL_RenderDrawPoint(SDL_Renderer *r, int x, int y) {
    if (!r || x < 0 || y < 0 || x >= r->w || y >= r->h) return -1;
    r->pixels[(Uint32)y * r->w + x] = draw_color(r);
    return 0;
}

int SDL_RenderCopy(SDL_Renderer *r, SDL_Texture *t,
                   const SDL_Rect *src, const SDL_Rect *dst) {
    if (!r || !t) return -1;
    int sx = 0, sy = 0, sw2 = t->w, sh = t->h;
    int dx = 0, dy = 0, dw = t->w, dh = t->h;
    if (src) { sx = src->x; sy = src->y; sw2 = src->w; sh = src->h; }
    if (dst) { dx = dst->x; dy = dst->y; dw = dst->w; dh = dst->h; }
    if (sw2 <= 0 || sh <= 0 || dw <= 0 || dh <= 0) return 0;

    for (int yy = 0; yy < dh; yy++) {
        int ty = dy + yy;
        if (ty < 0 || ty >= r->h) continue;
        int sry = sy + (int)((long)yy * sh / dh);
        if (sry < 0 || sry >= t->h) continue;
        Uint32 *srow = t->pixels + (Uint32)sry * t->w;
        Uint32 *drow = r->pixels + (Uint32)ty * r->w;
        for (int xx = 0; xx < dw; xx++) {
            int tx = dx + xx;
            if (tx < 0 || tx >= r->w) continue;
            int srx = sx + (int)((long)xx * sw2 / dw);
            if (srx < 0 || srx >= t->w) continue;
            Uint32 c = srow[srx];
            if ((c >> 24) == 0) continue;   /* A=0 — прозрачно */
            drow[tx] = c;
        }
    }
    return 0;
}

void SDL_RenderPresent(SDL_Renderer *r) {
    if (!r || !r->window || !r->window->os_win) return;
    SDL_Window *w = r->window;
    if (w->closing) return;

    u32 *canvas = w->os_win->canvas;
    int cw = w->os_win->cvs_w;
    int ch = w->os_win->cvs_h;
    if (!canvas) return;

    int copy_w = r->w < cw ? r->w : cw;
    int copy_h = r->h < ch ? r->h : ch;
    for (int yy = 0; yy < copy_h; yy++) {
        memcpy(canvas + (u32)yy * cw,
               r->pixels + (u32)yy * r->w,
               (u32)copy_w * 4);
    }
    fb_touch(w->os_win->x, w->os_win->y, w->os_win->w, w->os_win->h);
}

/* ---- Textures ---- */
SDL_Texture *SDL_CreateTexture(SDL_Renderer *r, Uint32 format, int access,
                               int w, int h) {
    (void)format; (void)access;
    if (!r || w <= 0 || h <= 0) return NULL;
    SDL_Texture *t = (SDL_Texture *)malloc(sizeof(*t));
    if (!t) return NULL;
    t->w = w; t->h = h; t->window = r->window; t->locked = 0;
    t->pixels = (Uint32 *)malloc((u32)w * h * 4);
    if (!t->pixels) { free(t); return NULL; }
    memset(t->pixels, 0, (u32)w * h * 4);
    return t;
}

SDL_Texture *SDL_CreateTextureFromSurface(SDL_Renderer *r, SDL_Surface *s) {
    if (!r || !s || !s->pixels) return NULL;
    SDL_Texture *t = (SDL_Texture *)malloc(sizeof(*t));
    if (!t) return NULL;
    t->w = s->w; t->h = s->h; t->window = r->window; t->locked = 0;
    t->pixels = (Uint32 *)malloc((u32)s->w * s->h * 4);
    if (!t->pixels) { free(t); return NULL; }
    /* предполагаем ARGB8888-совместимый surface (u32 на пиксель) */
    for (int y = 0; y < s->h; y++)
        memcpy(t->pixels + (u32)y * s->w,
               (Uint8*)s->pixels + (u32)y * s->pitch,
               (u32)s->w * 4);
    return t;
}

void SDL_DestroyTexture(SDL_Texture *t) {
    if (!t) return;
    if (t->pixels) free(t->pixels);
    free(t);
}

int SDL_UpdateTexture(SDL_Texture *t, const SDL_Rect *rect,
                      const void *pixels, int pitch) {
    if (!t || !pixels) return -1;
    int rx = 0, ry = 0, rw = t->w, rh = t->h;
    if (rect) { rx = rect->x; ry = rect->y; rw = rect->w; rh = rect->h; }
    if (rx < 0 || ry < 0 || rw <= 0 || rh <= 0) return -1;
    if (rx + rw > t->w) rw = t->w - rx;
    if (ry + rh > t->h) rh = t->h - ry;
    for (int y = 0; y < rh; y++) {
        memcpy(t->pixels + (u32)(ry + y) * t->w + rx,
               (const Uint8 *)pixels + (u32)y * pitch,
               (u32)rw * 4);
    }
    return 0;
}

int SDL_LockTexture(SDL_Texture *t, const SDL_Rect *rect, void **pixels, int *pitch) {
    if (!t || !pixels || !pitch) return -1;
    t->locked = 1;
    *pixels = t->pixels;
    *pitch  = t->w * 4;
    (void)rect;
    return 0;
}
void SDL_UnlockTexture(SDL_Texture *t) { if (t) t->locked = 0; }

/* ---- Surfaces ---- */
SDL_Surface *SDL_CreateRGBSurface(Uint32 flags, int w, int h, int depth,
                                  Uint32 Rmask, Uint32 Gmask,
                                  Uint32 Bmask, Uint32 Amask) {
    (void)flags; (void)depth;
    if (w <= 0 || h <= 0) return NULL;
    SDL_Surface *s = (SDL_Surface *)malloc(sizeof(*s));
    if (!s) return NULL;
    memset(s, 0, sizeof(*s));
    s->w = w; s->h = h; s->pitch = w * 4;
    s->Rmask = Rmask; s->Gmask = Gmask; s->Bmask = Bmask; s->Amask = Amask;
    s->pixels = malloc((u32)w * h * 4);
    if (!s->pixels) { free(s); return NULL; }
    memset(s->pixels, 0, (u32)w * h * 4);
    return s;
}

void SDL_FreeSurface(SDL_Surface *s) {
    if (!s) return;
    if (s->pixels && !s->_priv) free(s->pixels);  /* window surface НЕ освобождаем */
    free(s);
}
int SDL_LockSurface(SDL_Surface *s)   { (void)s; return 0; }
void SDL_UnlockSurface(SDL_Surface *s){ (void)s; }

int SDL_SetColorKey(SDL_Surface *s, int flag, Uint32 key) {
    if (!s) return -1;
    s->has_colorkey = flag;
    s->colorkey = key;
    return 0;
}

int SDL_BlitSurface(SDL_Surface *src, const SDL_Rect *srcrect,
                    SDL_Surface *dst, SDL_Rect *dstrect) {
    if (!src || !dst || !src->pixels || !dst->pixels) return -1;
    int sx = 0, sy = 0, sw2 = src->w, sh = src->h;
    int dx = dstrect ? dstrect->x : 0;
    int dy = dstrect ? dstrect->y : 0;
    if (srcrect) { sx = srcrect->x; sy = srcrect->y; sw2 = srcrect->w; sh = srcrect->h; }
    if (sw2 <= 0 || sh <= 0) return 0;

    for (int y = 0; y < sh; y++) {
        int ty = dy + y;
        if (ty < 0 || ty >= dst->h) continue;
        int sry = sy + y;
        if (sry < 0 || sry >= src->h) continue;
        Uint32 *srow = (Uint32 *)((Uint8 *)src->pixels + (u32)sry * src->pitch);
        Uint32 *drow = (Uint32 *)((Uint8 *)dst->pixels + (u32)ty * dst->pitch);
        for (int x = 0; x < sw2; x++) {
            int tx = dx + x;
            if (tx < 0 || tx >= dst->w) continue;
            int srx = sx + x;
            if (srx < 0 || srx >= src->w) continue;
            Uint32 c = srow[srx];
            if (src->has_colorkey && c == src->colorkey) continue;
            if (((c >> 24) & 0xFF) == 0) continue;   /* A=0 */
            drow[tx] = c;
        }
    }
    return 0;
}

SDL_Surface *SDL_LoadBMP(const char *path) {
    /* BMP читаем из ramfs. Максимум 4 МиБ — практический потолок. */
    if (!path) return NULL;
    const Uint32 max_size = 4u * 1024u * 1024u;
    Uint8 *buf = (Uint8 *)malloc(max_size);
    if (!buf) return NULL;
    u32 n = ramfs_read(path, buf, max_size);
    if (n < 54 || buf[0] != 'B' || buf[1] != 'M') { free(buf); return NULL; }

    u32 off    = *(Uint32 *)(buf + 10);
    Sint32 bmp_w  = *(Sint32 *)(buf + 18);
    Sint32 bmp_h  = *(Sint32 *)(buf + 22);
    Uint16 bpp    = *(Uint16 *)(buf + 28);
    if ((bpp != 24 && bpp != 32) || bmp_w <= 0 || bmp_w > 4096) { free(buf); return NULL; }

    int abs_h = bmp_h < 0 ? -bmp_h : bmp_h;
    if (abs_h > 4096) { free(buf); return NULL; }
    int row_sz = ((bmp_w * bpp + 31) / 32) * 4;
    if (off + (u32)row_sz * abs_h > n) { free(buf); return NULL; }

    SDL_Surface *s = SDL_CreateRGBSurface(0, bmp_w, abs_h, 32,
                                          0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
    if (!s) { free(buf); return NULL; }
    for (int y = 0; y < abs_h; y++) {
        int sy_src = (bmp_h > 0) ? (abs_h - 1 - y) : y;
        const Uint8 *src_row = buf + off + (u32)sy_src * row_sz;
        Uint32 *dst_row = (Uint32 *)((Uint8 *)s->pixels + (u32)y * s->pitch);
        int step = bpp / 8;
        for (int x = 0; x < bmp_w; x++) {
            Uint8 B = src_row[x * step + 0];
            Uint8 G = src_row[x * step + 1];
            Uint8 R = src_row[x * step + 2];
            Uint8 A = (bpp == 32) ? src_row[x * step + 3] : 0xFF;
            dst_row[x] = ((u32)A << 24) | ((u32)R << 16) |
                         ((u32)G << 8) | B;
        }
    }
    free(buf);
    return s;
}

/* ---- Events ---- */
int SDL_PollEvent(SDL_Event *e) {
    if (!e) {
        /* SDL-семантика: PollEvent(NULL) только выкачивает очередь */
        SDL_Event drain;
        while (g_primary && pop_event(g_primary, &drain)) { }
        return g_primary ? 1 : 0;
    }
    if (!g_primary) return 0;
    if (pop_event(g_primary, e)) return 1;
    /* дать потоку окна и kmain поработать */
    task_yield();
    return 0;
}

int SDL_WaitEvent(SDL_Event *e) {
    for (;;) {
        if (SDL_PollEvent(e)) return 1;
        task_msleep(1);
    }
}

int SDL_WaitEventTimeout(SDL_Event *e, int ms) {
    u32 t0 = timer_ticks();
    for (;;) {
        if (SDL_PollEvent(e)) return 1;
        if ((int)(timer_ticks() - t0) >= ms) return 0;
        task_msleep(1);
    }
}

int SDL_PushEvent(SDL_Event *e) {
    if (!g_primary || !e) return -1;
    return push_event(g_primary, e) ? 1 : 0;
}

/* ---- Input state ---- */
const Uint8 *SDL_GetKeyboardState(int *numkeys) {
    if (numkeys) *numkeys = SDL_NUM_SCANCODES;
    return g_primary ? g_primary->keys : NULL;
}

u32 SDL_GetMouseState(int *x, int *y) {
    if (!g_primary) { if (x) *x = 0; if (y) *y = 0; return 0; }
    if (x) *x = g_primary->mouse_x;
    if (y) *y = g_primary->mouse_y;
    return g_primary->mouse_state;
}

/* ---- Time ---- */
void SDL_Delay(Uint32 ms) { if (ms) task_msleep(ms); }
Uint32 SDL_GetTicks(void) { return timer_ticks(); }
Uint64 SDL_GetPerformanceCounter(void) { return (Uint64)timer_ticks() * 1000ull; }
Uint64 SDL_GetPerformanceFrequency(void) { return 1000000ull; }

/* ---- Интеграция с apps.c ---- */

typedef struct {
    int (*fn)(int, char **);
    int argc;
    char **argv;
} sdl_run_arg_t;

static void sdl_run_task(void *a) {
    sdl_run_arg_t *r = (sdl_run_arg_t *)a;
    int (*f)(int, char **) = r->fn;
    int argc = r->argc;
    char **argv = r->argv;
    free(r);
    f(argc, argv);
    /* приложение само должно вызвать SDL_DestroyWindow и SDL_Quit;
     * после возврата — поток завершается автоматически */
}

int SDL_RunApp(int (*sdl_main)(int, char **), int argc, char **argv) {
    sdl_run_arg_t *a = (sdl_run_arg_t *)malloc(sizeof(*a));
    if (!a) return -1;
    a->fn = sdl_main; a->argc = argc; a->argv = argv;
    int tid = task_spawn_prio("sdlapp", sdl_run_task, a, TASK_PRIO_UI);
    if (tid <= 0) { free(a); return -1; }
    return 0;
}

/* ======================================================================
 * c4-диспетчер (Task 54): ЕДИНАЯ точка вызова SDL-функций из c4-программ.
 *
 *   op  — номер операции (sdl_ops.h: C4_SDL_IDX_*, 0..C4_SDL_OP_COUNT-1);
 *   a   — аргументы вызова В ОБРАТНОМ порядке: a[0] = ПОСЛЕДНИЙ аргумент
 *         исходного вызова (стек c4), т.е. для
 *             SDL_CreateWindow(title, x, y, w, h)
 *         a[4]=title, a[3]=x, a[2]=y, a[1]=w, a[0]=h.
 *
 * VM-путь (c4.c) вызывает напрямую; native-путь (c4_x86.c) — через
 * kapi_t->sdl_call (loader.c: kapi_fill). Указатели приходят как int.
 * ====================================================================== */
int c4_sdl_call(int op, const int *a)
{
    if (!a) return 0;
    switch (op) {
    /* ---- init/ошибки ---- */
    case C4_SDL_IDX_SDLINIT:   return SDL_Init((Uint32)a[0]);
    case C4_SDL_IDX_SDLQUIT:   SDL_Quit(); return 0;
    case C4_SDL_IDX_SDLQUITSUB: SDL_QuitSubSystem((Uint32)a[0]); return 0;
    case C4_SDL_IDX_SDLGETERR:
        return (int)(unsigned long)SDL_GetError();
    case C4_SDL_IDX_SDLSETERR: return 0;            /* форматные строки не поддерживаем */
    case C4_SDL_IDX_SDLCLRERR: SDL_ClearError(); return 0;

    /* ---- окно ---- */
    case C4_SDL_IDX_SDLCREATEWIN:
        /* SDL_CreateWindow(title, x, y, w, h, flags) — 6 аргументов:
         * a[5]=title, a[4]=x, a[3]=y, a[2]=w, a[1]=h, a[0]=flags */
        return (int)(unsigned long)SDL_CreateWindow(
            (const char *)(unsigned long)a[5], a[4], a[3], a[2], a[1],
            (Uint32)a[0]);
    case C4_SDL_IDX_SDLDESTROYWIN:
        SDL_DestroyWindow((SDL_Window *)(unsigned long)a[0]); return 0;
    case C4_SDL_IDX_SDLGETWINSIZE: {
        SDL_Window *w = (SDL_Window *)(unsigned long)a[2];
        SDL_GetWindowSize(w, (int *)(unsigned long)a[1],
                             (int *)(unsigned long)a[0]);
        return 0;
    }
    case C4_SDL_IDX_SDLSETWINTITLE:
        SDL_SetWindowTitle((SDL_Window *)(unsigned long)a[1],
                           (const char *)(unsigned long)a[0]);
        return 0;
    case C4_SDL_IDX_SDLGETWINSURF:
        return (int)(unsigned long)
            SDL_GetWindowSurface((SDL_Window *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLUPDWINSURF:
        return SDL_UpdateWindowSurface((SDL_Window *)(unsigned long)a[0]);

    /* ---- рендерер ---- */
    case C4_SDL_IDX_SDLCREATEREND:
        return (int)(unsigned long)SDL_CreateRenderer(
            (SDL_Window *)(unsigned long)a[2], a[1], (Uint32)a[0]);
    case C4_SDL_IDX_SDLDESTROYREND:
        SDL_DestroyRenderer((SDL_Renderer *)(unsigned long)a[0]); return 0;
    case C4_SDL_IDX_SDLSETDRAWCOLOR:
        return SDL_SetRenderDrawColor((SDL_Renderer *)(unsigned long)a[4],
                                      (Uint8)a[3], (Uint8)a[2],
                                      (Uint8)a[1], (Uint8)a[0]);
    case C4_SDL_IDX_SDLGETRENDOUT: {
        SDL_Renderer *r = (SDL_Renderer *)(unsigned long)a[2];
        return SDL_GetRendererOutputSize(r, (int *)(unsigned long)a[1],
                                            (int *)(unsigned long)a[0]);
    }
    case C4_SDL_IDX_SDLRENDCLR:
        return SDL_RenderClear((SDL_Renderer *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLRENDFILLRECT:
        return SDL_RenderFillRect((SDL_Renderer *)(unsigned long)a[1],
                                  (const SDL_Rect *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLRENDDRAWRECT:
        return SDL_RenderDrawRect((SDL_Renderer *)(unsigned long)a[1],
                                  (const SDL_Rect *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLRENDDRAWLINE:
        return SDL_RenderDrawLine((SDL_Renderer *)(unsigned long)a[4],
                                  a[3], a[2], a[1], a[0]);
    case C4_SDL_IDX_SDLRENDDRAWPOINT:
        return SDL_RenderDrawPoint((SDL_Renderer *)(unsigned long)a[2],
                                   a[1], a[0]);
    case C4_SDL_IDX_SDLRENDCOPY:
        return SDL_RenderCopy((SDL_Renderer *)(unsigned long)a[3],
                              (SDL_Texture *)(unsigned long)a[2],
                              (const SDL_Rect *)(unsigned long)a[1],
                              (const SDL_Rect *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLRENDPRESENT:
        SDL_RenderPresent((SDL_Renderer *)(unsigned long)a[0]); return 0;

    /* ---- текстуры ---- */
    case C4_SDL_IDX_SDLCREATETEX:
        return (int)(unsigned long)SDL_CreateTexture(
            (SDL_Renderer *)(unsigned long)a[4], (Uint32)a[3], a[2], a[1], a[0]);
    case C4_SDL_IDX_SDLCREATETEXFS:
        return (int)(unsigned long)SDL_CreateTextureFromSurface(
            (SDL_Renderer *)(unsigned long)a[1],
            (SDL_Surface *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLDESTROYTEX:
        SDL_DestroyTexture((SDL_Texture *)(unsigned long)a[0]); return 0;
    case C4_SDL_IDX_SDLUPDTEX:
        return SDL_UpdateTexture((SDL_Texture *)(unsigned long)a[3],
                                 (const SDL_Rect *)(unsigned long)a[2],
                                 (const void *)(unsigned long)a[1], a[0]);
    case C4_SDL_IDX_SDLLOCKTEX: {
        SDL_Texture *t = (SDL_Texture *)(unsigned long)a[3];
        return SDL_LockTexture(t, (const SDL_Rect *)(unsigned long)a[2],
                               (void **)(unsigned long)a[1],
                               (int *)(unsigned long)a[0]);
    }
    case C4_SDL_IDX_SDLUNLOCKTEX:
        SDL_UnlockTexture((SDL_Texture *)(unsigned long)a[0]); return 0;

    /* ---- surface ---- */
    case C4_SDL_IDX_SDLCREATERGBSURF:
        return (int)(unsigned long)SDL_CreateRGBSurface(
            (Uint32)a[7], a[6], a[5], a[4],
            (Uint32)a[3], (Uint32)a[2], (Uint32)a[1], (Uint32)a[0]);
    case C4_SDL_IDX_SDLFREESURF:
        SDL_FreeSurface((SDL_Surface *)(unsigned long)a[0]); return 0;
    case C4_SDL_IDX_SDLLOCKSURF:
        return SDL_LockSurface((SDL_Surface *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLUNLOCKSURF:
        SDL_UnlockSurface((SDL_Surface *)(unsigned long)a[0]); return 0;
    case C4_SDL_IDX_SDLSETCOLORKEY:
        return SDL_SetColorKey((SDL_Surface *)(unsigned long)a[2],
                               a[1], (Uint32)a[0]);
    case C4_SDL_IDX_SDLBLITSURF:
        return SDL_BlitSurface((SDL_Surface *)(unsigned long)a[3],
                               (const SDL_Rect *)(unsigned long)a[2],
                               (SDL_Surface *)(unsigned long)a[1],
                               (SDL_Rect *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLLOADBMP:
        return (int)(unsigned long)
            SDL_LoadBMP((const char *)(unsigned long)a[0]);

    /* ---- события ---- */
    case C4_SDL_IDX_SDLPOLLEVENT:
        return SDL_PollEvent((SDL_Event *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLWAITEVENT:
        return SDL_WaitEvent((SDL_Event *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLWAITEVTO:
        return SDL_WaitEventTimeout((SDL_Event *)(unsigned long)a[1], a[0]);
    case C4_SDL_IDX_SDLPUSHEVENT:
        return SDL_PushEvent((SDL_Event *)(unsigned long)a[0]);

    /* ---- ввод ---- */
    case C4_SDL_IDX_SDLGETKBSTATE:
        return (int)(unsigned long)SDL_GetKeyboardState((int *)(unsigned long)a[0]);
    case C4_SDL_IDX_SDLGETMOUSESTATE: {
        u32 st = SDL_GetMouseState((int *)(unsigned long)a[1],
                                   (int *)(unsigned long)a[0]);
        return (int)st;
    }

    /* ---- время ---- */
    case C4_SDL_IDX_SDLDELAY: SDL_Delay((Uint32)a[0]); return 0;
    case C4_SDL_IDX_SDLGETTICKS: return (int)SDL_GetTicks();
    case C4_SDL_IDX_SDLGETPERFCNT:  return (int)SDL_GetPerformanceCounter();
    case C4_SDL_IDX_SDLGETPERFFREQ: return (int)SDL_GetPerformanceFrequency();

    /* ---- запуск приложения (только native-путь: fn — адрес в .bin) ---- */
    case C4_SDL_IDX_SDLRUNAPP:
        return SDL_RunApp((int (*)(int, char **))(unsigned long)a[2],
                          a[1], (char **)(unsigned long)a[0]);

    default: return 0;
    }
}
