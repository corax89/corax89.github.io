/* klog.c — журнал загрузки и загрузочный экран-лог (Task 49; вынесен
 * из kernel.c): кольцевой буфер dmesg (klog_*), dbg/dbg_err с выводом
 * в serial + klog + экран (до старта WM; g_screen_log_off гасит экран).
 * serial-функции живут в boot.c — символы глобальные, extern как раньше. */
#include "types.h"
#include "string.h"
#include "fb.h"
#include "smp.h"
#include "sync.h"
#include "kernel.h"

extern void serial_puts(const char *s);
extern void serial_putc(char c);

/* ---------- Экранный debug ---------- */

static int  dbg_y = 0;              /* текущая строка вывода на экране */
static u32  dbg_color_ok  = 0;      /* кэшируем цвета после fb_init */
static u32  dbg_color_err = 0;

/* ---------- Журнал загрузки (klog) ----------
 * Кольцевое хранилище строк: переполнение выбрасывает САМЫЕ СТАРЫЕ
 * строки (memmove). Читается командой dmesg в терминале — это и есть
 * «процесс загрузки», который пролетает на экране слишком быстро. */
/* [KLOG64] (полевой лог итерации 11: «при дампе dmesg копируется только
 * 16 КБ» — это не копирование, это РАЗМЕР КОЛЬЦА: старые строки
 * вытеснялись). 16 -> 64 КБ: скан WiFi генерит ~2 КБ за проход, буфер
 * теперь держит несколько сканов/подключений + весь boot-процесс. */
#define KLOG_SIZE 65536
static char  klog_buf[KLOG_SIZE];
static int   klog_len = 0;
static volatile int klog_lock = 0;

void klog_puts(const char *s)
{
    if (!s) return;
    /* ШАГ 6: был s_lock (cli + владелец+1). Секция микросекундная,
     * dead-owner-восстановление не нужно: честный cmpxchg-спинлок
     * (smp.h) — работает на любом ядре и из IRQ-контекста. */
    smp_spin_lock(&klog_lock);

    u32 sl = (u32)strlen(s);
    if (sl > 200) sl = 200;               /* защита от ошибочных вызовов */
    /* освободить место: выкидываем старые строки целиком */
    while (klog_len + (int)sl + 1 >= KLOG_SIZE) {
        char *nl = (char *)memchr(klog_buf, '\n', (u32)klog_len);
        if (!nl) { klog_len = 0; break; }  /* ни одной полной строки — сброс */
        int drop = (int)(nl - klog_buf) + 1;
        memmove(klog_buf, klog_buf + drop, (u32)(klog_len - drop));
        klog_len -= drop;
    }
    memcpy(klog_buf + klog_len, s, sl);
    klog_len += (int)sl;
    klog_buf[klog_len++] = '\n';
    klog_buf[klog_len] = 0;

    smp_spin_unlock(&klog_lock);
}

const char *klog_get(void) { return klog_buf; }

/* [EXC-KLOG] (итерация 12) лучшие усилия: строка паники/исключения в
 * klog (dmesg), ЕСЛИ замок свободен одной попыткой. Полевой лог 11:
 * пользователь копирует dmesg, а дампы исключений уходили ТОЛЬКО в
 * serial — «смерть задачи mp3play» была невидима в dmesg полностью.
 * Из исключения НЕЛЬЗЯ спинить на замке: виновник мог умереть ВНУТРИ
 * klog_puts, держа klog_lock (спин = вечный цикл на этом ядре).
 * Занято = молча выходим (serial-дубль уже напечатан panic_puts). */
void klog_try_puts(const char *s)
{
    if (!s) return;                       /* klog_buf — статический массив */
    if (!smp_trylock(&klog_lock)) return;
    u32 sl = (u32)strlen(s);
    if (sl > 200) sl = 200;
    while (klog_len + (int)sl + 1 >= KLOG_SIZE) {
        char *nl = (char *)memchr(klog_buf, '\n', (u32)klog_len);
        if (!nl) { klog_len = 0; break; }
        int drop = (int)(nl - klog_buf) + 1;
        memmove(klog_buf, klog_buf + drop, (u32)(klog_len - drop));
        klog_len -= drop;
    }
    memcpy(klog_buf + klog_len, s, sl);
    klog_len += (int)sl;
    klog_buf[klog_len++] = '\n';
    klog_buf[klog_len] = 0;
    smp_spin_unlock(&klog_lock);
}

int klog_line_count(void)
{
    int n = 0;
    for (int i = 0; i < klog_len; i++)
        if (klog_buf[i] == '\n') n++;
    return n;
}

/* Вывести строку одновременно в serial, на экран (если fb готов)
 * и в журнал загрузки (dmesg).
 * Сессия 11: dbg зовут и ФОНОВЫЕ задачи (sata/netmon) — сериализуем,
 * чтобы строки из разных потоков не калечили друг друга. */
static volatile int dbg_lock = 0;

/* Сессия 11: после старта WM экранный вывод dbg ОТКЛЮЧАЕМ — иначе
 * фоновые задачи (sata/netmon) рисовали бы свой лог ПОВЕРХ окон.
 * serial + klog (dmesg) продолжают работать. */
static volatile int g_screen_log_off = 0;

void dbg(const char *s)
{
    s_lock(&dbg_lock);
    /* serial */
    serial_puts("[boot] ");
    serial_puts(s);
    serial_putc('\n');

    /* klog — чтобы dmesg показал процесс загрузки */
    klog_puts(s);

    /* screen: у нижнего края — ПРОКРУТКА ВВЕРХ, чтобы начальный лог
     * всегда был читаем (раньше строки уходили за экран снизу) */
    if (fb_ready() && !g_screen_log_off) {
        if (dbg_y + 16 > (int)fb_height()) {
            fb_scroll_up(16);
            dbg_y = (int)fb_height() - 16;
        }
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_ok, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
    s_unlock(&dbg_lock);
}

/* Вывести ошибку (красным) */
void dbg_err(const char *s)
{
    s_lock(&dbg_lock);
    serial_puts("[ERR ] ");
    serial_puts(s);
    serial_putc('\n');

    klog_puts(s);

    if (fb_ready() && !g_screen_log_off) {
        if (dbg_y + 16 > (int)fb_height()) {
            fb_scroll_up(16);
            dbg_y = (int)fb_height() - 16;
        }
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_err, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
    s_unlock(&dbg_lock);
}

/* Task 49: доступ из kernel.c (раньше переменные были static в нём же) */
void klog_screen_off(void)   { g_screen_log_off = 1; }
void klog_screen_colors(u32 ok, u32 err)
{
    dbg_color_ok  = ok;
    dbg_color_err = err;
}
