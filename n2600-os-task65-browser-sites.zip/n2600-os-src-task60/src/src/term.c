/* term.c — тонкая совместимость со старой внешней копией headless-
 * терминала (Task 45).
 *
 * Вся реализация терминала — в apps.c: структура term_s (экран, VT-режим,
 * скроллбек, sink), term_headless_create/free/sink, term_shell_exec
 * (та же таблица команд, что в локальном терминале). Этот файл больше
 * НЕ содержит собственной версии терминала: прежде параллельные
 * реализации конфликтовали с apps.h (другая структура term_hd, другой
 * порядок аргументов колбэка) и дублировали символы apps.c.
 *
 * Здесь только имена старого API, которых в apps.c нет — см. term.h. */
#include "term.h"

void term_headless_destroy(term_t *t)
{
    term_headless_free(t);
}

void term_headless_banner(term_t *t)
{
    (void)t;   /* приветствие шлёт сам telnetd (tnd_hello) */
}

int term_headless_exit_requested(term_t *t)
{
    (void)t;   /* выход обрабатывает telnetd (команда exit в его фильтре) */
    return 0;
}
