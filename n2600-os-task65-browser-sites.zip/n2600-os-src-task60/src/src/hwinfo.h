/* hwinfo.h — hwdet-подобная диагностика железа (сессия 90).
 *
 * Идея заимствована из hwdet.h bzt (https://gitlab.com/bztsrc/hwdet,
 * GPLv3+): ОС узнаёт железо из описания самой платы — ACPI DSDT/SSDT —
 * а не из слепого скана портов. Здесь реализован БЕЗОПАСНЫЙ (только
 * чтение) поднабор:
 *
 *   1. ACPI: RSDP -> RSDT/XSDT -> список таблиц с контролем чексумм;
 *      FADT (версия/профиль/SCI/PM1a/DSDT), MADT (LAPIC/IOAPIC),
 *      HPET, MCFG (PCIe ECAM).
 *   2. DSDT: AML-сканер именованных объектов (Device/Processor/
 *      ThermalZone/Scope/Name): _HID (EisaId/строка), _ADR, _UID и
 *      СТАТИЧЕСКИЕ _CRS (ResourceTemplate: IO/FixedIO/IRQ/DMA/
 *      Memory32Fixed/ExtIRQ). Динамические _CRS (Method) не
 *      вычисляются — только считаются. Итог: список устройств с
 *      человекочитаемыми именами (таблица PNP/ACPI ID — по мотивам
 *      aml_drvname hwdet).
 *   3. SMBIOS (DMI): BIOS/система/плата/процессор — скан F0000-FFFFF
 *      и EBDA на "_SM_"/"_SM3_", структуры Type 0/1/2/4.
 *   4. CPU-экстры: CPUID-фичи, размеры кэша (leaf 4, фолбэк leaf 2),
 *      частота TSC (ленивая калибровка по PIT-тикам).
 *
 * Всё выполняется ОДИН раз при загрузке (hwinfo_init), кроме TSC —
 * при первом обращении. Аппаратных записей НЕТ: чёрный экран сессий
 * 88-89 был от записей в SGX, здесь их не существует в принципе. */
#ifndef HWINFO_H
#define HWINFO_H

#include "types.h"

void hwinfo_init(void);         /* разбор ACPI/DMI/AML (быстро, только чтение) */

/* --- SMBIOS (DMI) --- */
const char *hwinfo_dmi_bios(void);      /* "American Megatrends 0307 (2011)" или "" */
const char *hwinfo_dmi_system(void);    /* "ASUSTeK COMPUTER INC. X101CH" или "" */
const char *hwinfo_dmi_board(void);     /* "ASUSTeK X101CH" или "" */
const char *hwinfo_dmi_cpu(void);       /* "FCBGA559, Intel, 1600 МГц" или "" */

/* --- ACPI: сводки (строки в буфере вызывающего) --- */
void hwinfo_acpi_summary(char *out, int n);  /* "ACPI 2.0, таблиц 13, OEM ASUSTeK" */
void hwinfo_acpi_tables (char *out, int n);  /* "FACP APIC MCFG HPET ..." */
void hwinfo_acpi_dsdt   (char *out, int n);  /* "DSDT 39 КиБ rev 2 chk OK" */
void hwinfo_madt_summary(char *out, int n);  /* "MADT: 4 LAPIC, 1 IOAPIC @FEC00000" */
void hwinfo_fadt_summary(char *out, int n);  /* "FADT: профиль Mobile, SCI 9" */
void hwinfo_hpet_summary(char *out, int n);  /* "HPET @FED00000" или "" */
void hwinfo_mcfg_summary(char *out, int n);  /* "PCIe ECAM @E0000000" или "" */

/* --- устройства из DSDT (только с _HID; Processor() -> hid "CPU") --- */
int  hwinfo_dev_total(void);            /* всего именованных устройств */
int  hwinfo_dev_hid(void);              /* с _HID */
int  hwinfo_dev_get(int idx, char *out, int n);  /* 1 = строка записана */

/* --- CPU --- */
void hwinfo_cpu_features(char *out, int n); /* "TSC MSR APIC SSE2 SSE3 ..." */
void hwinfo_cpu_cache   (char *out, int n); /* "L1d 24К L1i 32К L2 512К" */
unsigned hwinfo_tsc_mhz(void);              /* 0 = нет TSC/замер не удался */

#endif /* HWINFO_H */
