/* net_tcp.h — внутренний интерфейс TCP-слоя (Task 49).
 *
 * После расщепления net.c: IP/ARP/ICMP/UDP живут в net.c, TCP — в
 * net_tcp.c. Этот заголовок — ТОЛЬКО cross-boundary (оба файла включают
 * его): экспорт нижнего слоя TCP-у и точки входа входящего TCP.
 * Публичный API сокетов по-прежнему в net.h. */
#ifndef NET_TCP_H
#define NET_TCP_H

#include "types.h"
#include "net.h"

/* --- из net.c (нижний слой) --- */

/* 16-битная чексумма с псевдозаголовком TCP/UDP (RFC 1071 + RFC 768). */
u16  inet_checksum_pseudo(u32 src_ip, u32 dst_ip, u8 proto,
                          const void *data, u32 len);

/* Отправить IP-датаграмму (бывший static net_send_ip: маршрутизация,
 * фрагментация-отказ, ARP-резолв, loopback-ветка). */
void net_send_ip(u8 proto, u32 dst_ip, const void *payload, u32 payload_len);

/* Флаг «идёт DHCP-транзакция» (исходящий IP = 0.0.0.0 до её конца). */
int  net_dhcp_txn_active(void);

/* --- из net_tcp.c (точка входа входящего TCP) --- */

/* Разобрать входящий TCP-сегмент (вызывается из dispatch net.c). */
void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len);

/* Миграция сокетов при смене нашего IP (вызывается из net_set_ip). */
void net_tcp_mark_migrated(u32 ip);

#endif /* NET_TCP_H */
