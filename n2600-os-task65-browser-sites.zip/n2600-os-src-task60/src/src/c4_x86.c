/* c4_x86.c — x86-кодогенератор: превращает байт-код c4 в настоящий
 * flat-binary исполняемый файл для N2600-OS.
 *
 *   1) c4.c парсит исходник и строит IR (байт-код) в пуле `e`.
 *   2) Этот файл проходит по IR и эмитит эквивалентный x86 машинный код.
 *   3) Результат — flat-binary с точкой входа int entry(kapi_t *k, void *win),
 *      который запускается через loader_spawn() как обычное приложение.
 *
 * Соглашения по регистрам (32-bit cdecl):
 *   EAX = аккумулятор "a" (в c4 VM) — НЕ пушится результатами операций
 *   ESP = виртуальный стек (по 4 байта на ячейку, как в c4)
 *   EBP = base pointer "bp" (для локальных переменных)
 *   EDI = сохранённый указатель kapi_t* (передаётся при entry)
 *   ESI = сохранённый указатель win (передаётся при entry)
 *   EBX = кадр entry() — для unwind из exit() с любой глубины вызовов
 *
 * СООТВЕТСТВИЕ МОДЕЛИ c4 VM (главное после фиксов):
 *   - IMM/LEA кладут результат в EAX (a), ПУШ делает только PSH;
 *   - бинарные операторы: pop ecx (ЛЕВЫЙ операнд), xchg для
 *     некоммутативных, результат в EAX;
 *   - syscall: аргументы на стеке в c4-порядке ([ESP]=последний),
 *     перед вызовом копируются в cdecl-порядок ([ESP]=первый),
 *     оригиналы снимает следующий в байт-коде ADJ;
 *   - результат syscall'а остаётся в EAX (= "a"), БЕЗ пуша.
 *
 * Формат .bin (C4N1): [magic 'C4N1'][u32 code_size][u32 data_size]
 *   [u32 n_relocs][code][data][relocs: u32 code_off...].
 * Сегмент данных у каждого бинарника СВОЙ: loader выделяет отдельный
 * блок, копирует данные и патчит imm32-адреса данных (relocs) —
 * перекомпиляция одной программы больше НЕ затирает данные другой.
 */
#include "c4.h"
#include "kapi.h"
#include "sdl_ops.h"  /* Task 54: C4_SDL_OP_LIST / C4_SDL_IDX_* */
#include "types.h"
#include "string.h"
#include "mem.h"
#include "sync.h"
#include "ramfs.h"
#include "loader.h"

extern void serial_puts(const char *s);

/* ---------- opcode enum (должен совпадать с c4.c) ---------- */
enum {
  LEA, IMM, JMP, JSR, BZ, BNZ, ENT, ADJ, LEV, LI, LC, SI, SC, PSH,
  OR, XOR, AND, EQ, NE, LT, GT, LE, GE, SHL, SHR, ADD, SUB, MUL, DIV, MOD,
  OPEN, READ, CLOS, PRTF, MALC, FREE, MSET, MCMP, EXIT,
  KINIT, KQUIT, KDELAY, KFILL, KTEXT, KFLIP, KRGB, KEVENT,
  KCLEAR, KW, KH, KMTIME,
  STRLEN, STRCPY, STRCMP,
  /* Логический (беззнаковый) сдвиг вправо — должен совпадать с c4.c
   * (добавлять только в конец, см. комментарий там) */
  USHR,
  /* Script GUI API (окна/кнопки) — ТОЛЬКО В КОНЦЕ, в порядке c4.c */
  WOPEN, WCLOSE, WALIVE, WCLEAR, WRECT, WTEXT, WUPD, BADD, BCLICK, BSETLB,
  /* ТОЛЬКО В КОНЦЕ, порядок = c4.c:
   *  LS/ULS/SSH — short: movsx/movzx word, store word;
   *  UDIV/UMOD — div (беззнаковое), ULT/UGT/ULE/UGE — setb/a/be/ae;
   *  JSRI — call eax (косвенный вызов, указатели на функции). */
  LS, ULS, SSH, UDIV, UMOD, ULT, UGT, ULE, UGE, JSRI,
  /* ТОЛЬКО В КОНЦЕ, порядок = c4.c:
   * double на стеке VM = 2 ячейки (x87 — переходно); сравнения —
   * fcompp + fnstsw/sahf + setcc. FABSC/SQRTC — fabs/fsqrt in-place. */
  FLDI, FLD0, FLD1, FDUP, FDROP, FLD, FLDF, FST, FSTF,
  FADD, FSUB, FMUL, FDIV, FNEG,
  FEQ, FNE, FLT, FLE, FGT, FGE,
  ITOF, UTOF, FTOI, ITOF2, FRET, FRD, SCP, FABSC, SQRTC, UTOF2, FSTK, FSTKF,
  /* Task 54: SDL2-подмножество — ТОЛЬКО В КОНЦЕ, порядок = sdl_ops.h
   * (= c4.c). Все операции эмитятся как call [edi+KAPI_SDL_CALL] с
   * номером op и указателем на аргументы (стек c4). */
#define C4_SDL_OP_ENUM(nm) nm,
  C4_SDL_OP_LIST(C4_SDL_OP_ENUM)
#undef C4_SDL_OP_ENUM
};

/* Смещения полей в kapi_t (в байтах, чтобы генерировать [edi+offset]).
 * Контролируются STATIC_ASSERT-ами ниже — при изменении kapi_t сборка
 * упадёт сразу, а не «вызовы уйдут в чужие поля» в рантайме. */
#define KAPI_FB_FILL_RECT    0
#define KAPI_FB_RECT         4
#define KAPI_FB_HLINE        8
#define KAPI_FB_TEXT         12
#define KAPI_FB_CHAR         16
#define KAPI_FB_RGB          20
#define KAPI_FB_WIDTH        24
#define KAPI_FB_HEIGHT       28
#define KAPI_FB_FILL_SCREEN  32
#define KAPI_WIN_CONTENT_W   36
#define KAPI_WIN_CONTENT_H   40
#define KAPI_WIN_INVALIDATE  44
#define KAPI_MALLOC          48
#define KAPI_FREE            52
#define KAPI_UPTIME_SEC      56
#define KAPI_TIMER_TICKS     60
#define KAPI_TASK_YIELD      64
#define KAPI_TASK_SPAWN      68
#define KAPI_SNPRINTF        72
#define KAPI_STRLEN          76
#define KAPI_STRCMP          80
#define KAPI_STRCPY         84
#define KAPI_MEMCMP          88
#define KAPI_MEMSET          92
#define KAPI_MEMCPY          96
#define KAPI_C4_PRINT_STR    100
#define KAPI_C4_EVENT_POLL   104
#define KAPI_C4_PRINTF_VA    108
#define KAPI_MSLEEP          112

/* Script GUI API (окна/кнопки) — поля kapi_t добавлены В КОНЕЦ;
 * имена в c4-программах: win_open/win_close/win_alive/win_clear/
 * win_rect/win_text/win_update/btn_add/btn_clicked/btn_set_label */
#define KAPI_WIN_OPEN        116
#define KAPI_WIN_CLOSE       120
#define KAPI_WIN_ALIVE       124
#define KAPI_WIN_CLEAR       128
#define KAPI_WIN_RECT        132
#define KAPI_WIN_TEXT        136
#define KAPI_WIN_UPDATE      140
#define KAPI_BTN_ADD         144
#define KAPI_BTN_CLICKED     148
#define KAPI_BTN_SET_LABEL   152

/* MP3-декодер dr_mp3 (mp3svc.c) — поля kapi_t зарезервированы
 * для приложений c4/QuickJS-скриптов; пока без intrinsics в c4-компиляторе,
 * смещения зафиксированы для стабильности ABI. */
#define KAPI_MP3_OPEN_MEM    156
#define KAPI_MP3_CLOSE       160
#define KAPI_MP3_CHANNELS    164
#define KAPI_MP3_RATE        168
#define KAPI_MP3_READ_S16    172
#define KAPI_MP3_SEEK        176
#define KAPI_MP3_TOTAL       180

/* общий FPU-лок для native c4-программ с float-кодом
 * (x87-состояние не сохраняется планировщиком — см. imgsvc.h) */
#define KAPI_FPU_LOCK        184
#define KAPI_FPU_UNLOCK      188

/* Task 54: единый диспетчер SDL2 (c4_sdl_call в sdl2.c) */
#define KAPI_SDL_CALL        192

/* Если layout kapi_t разъехался с константами — сборка обязана упасть. */
STATIC_ASSERT(__builtin_offsetof(kapi_t, fb_fill_rect)   == KAPI_FB_FILL_RECT,   kapi_off_0);
STATIC_ASSERT(__builtin_offsetof(kapi_t, fb_text)        == KAPI_FB_TEXT,        kapi_off_12);
STATIC_ASSERT(__builtin_offsetof(kapi_t, win_invalidate) == KAPI_WIN_INVALIDATE, kapi_off_44);
STATIC_ASSERT(__builtin_offsetof(kapi_t, malloc)         == KAPI_MALLOC,         kapi_off_48);
STATIC_ASSERT(__builtin_offsetof(kapi_t, memset)         == KAPI_MEMSET,         kapi_off_92);
STATIC_ASSERT(__builtin_offsetof(kapi_t, c4_print_str)   == KAPI_C4_PRINT_STR,   kapi_off_100);
STATIC_ASSERT(__builtin_offsetof(kapi_t, c4_printf_va)   == KAPI_C4_PRINTF_VA,   kapi_off_108);
STATIC_ASSERT(__builtin_offsetof(kapi_t, msleep)         == KAPI_MSLEEP,         kapi_off_112);
STATIC_ASSERT(__builtin_offsetof(kapi_t, win_open)       == KAPI_WIN_OPEN,       kapi_off_116);
STATIC_ASSERT(__builtin_offsetof(kapi_t, btn_set_label)  == KAPI_BTN_SET_LABEL,  kapi_off_152);
STATIC_ASSERT(__builtin_offsetof(kapi_t, mp3_open_mem)   == KAPI_MP3_OPEN_MEM,   kapi_off_156);
STATIC_ASSERT(__builtin_offsetof(kapi_t, mp3_total_frames) == KAPI_MP3_TOTAL,    kapi_off_180);
STATIC_ASSERT(__builtin_offsetof(kapi_t, fpu_lock)        == KAPI_FPU_LOCK,     kapi_off_184);
STATIC_ASSERT(__builtin_offsetof(kapi_t, fpu_unlock)      == KAPI_FPU_UNLOCK,   kapi_off_188);
STATIC_ASSERT(__builtin_offsetof(kapi_t, sdl_call)         == KAPI_SDL_CALL,     kapi_off_192);

/* ---------- эмиттер x86 машинного кода ---------- */
/* переполнение буфера эмиттера — не молча: фиксируется флагом и
 * в конце кодогенерации превращается в ошибку */
typedef struct {
    u8 *buf;
    u32 pos;
    u32 cap;
    int of;      /* 1 = было переполнение */
} emitter_t;

static inline void em1(emitter_t *em, u8 b) {
    if (em->pos < em->cap) em->buf[em->pos++] = b;
    else em->of = 1;
}
static inline void em4(emitter_t *em, u32 v) {
    em1(em, v & 0xFF);
    em1(em, (v >> 8) & 0xFF);
    em1(em, (v >> 16) & 0xFF);
    em1(em, (v >> 24) & 0xFF);
}

/* push imm32: 68 imm32 */
static inline void em_push_imm32(emitter_t *em, u32 val) { em1(em, 0x68); em4(em, val); }
/* push eax: 50 */
static inline void em_push_eax(emitter_t *em) { em1(em, 0x50); }
/* pop eax: 58 */
static inline void em_pop_eax(emitter_t *em) { em1(em, 0x58); }
/* pop ecx: 59 */
static inline void em_pop_ecx(emitter_t *em) { em1(em, 0x59); }
/* mov eax, imm32: B8 imm32 */
static inline void em_mov_eax_imm32(emitter_t *em, u32 val) { em1(em, 0xB8); em4(em, val); }
/* mov eax, [eax]: 8B 00 (load int through pointer, LI) */
static inline void em_mov_eax_deref_eax(emitter_t *em) { em1(em, 0x8B); em1(em, 0x00); }
/* movsx eax, byte [eax]: 0F BE 00 (load SIGNED char through pointer, LC) */
static inline void em_movsx_eax_byte_deref_eax(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xBE); em1(em, 0x00);
}
/* mov [ecx], eax: 89 01 (store int, SI) */
static inline void em_mov_deref_ecx_eax(emitter_t *em) { em1(em, 0x89); em1(em, 0x01); }
/* mov [ecx], al: 88 01 (store char, SC) */
static inline void em_mov_deref_ecx_al(emitter_t *em) { em1(em, 0x88); em1(em, 0x01); }
/* movsx eax, al: 0F BE C0 (sign-extend al to eax — char знаковый в c4) */
static inline void em_movsx_eax_al(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xBE); em1(em, 0xC0);
}

/* Арифметика: pop ecx; <op> eax, ecx */
static inline void em_add_eax_ecx(emitter_t *em) { em1(em, 0x01); em1(em, 0xC8); }
static inline void em_sub_eax_ecx(emitter_t *em) { em1(em, 0x29); em1(em, 0xC8); }
static inline void em_imul_eax_ecx(emitter_t *em) { em1(em, 0x0F); em1(em, 0xAF); em1(em, 0xC1); }
static inline void em_xor_eax_ecx(emitter_t *em) { em1(em, 0x31); em1(em, 0xC8); }
static inline void em_or_eax_ecx(emitter_t *em)  { em1(em, 0x09); em1(em, 0xC8); }
static inline void em_and_eax_ecx(emitter_t *em) { em1(em, 0x21); em1(em, 0xC8); }
static inline void em_cdq(emitter_t *em) { em1(em, 0x99); }
static inline void em_idiv_ecx(emitter_t *em) { em1(em, 0xF7); em1(em, 0xF9); }
static inline void em_xor_edx_edx(emitter_t *em) { em1(em, 0x31); em1(em, 0xD2); }
static inline void em_xor_eax_eax(emitter_t *em) { em1(em, 0x31); em1(em, 0xC0); }
static inline void em_div_ecx(emitter_t *em) { em1(em, 0xF7); em1(em, 0xF1); }   /* беззнаковое */
static inline void em_mov_eax_edx(emitter_t *em) { em1(em, 0x89); em1(em, 0xD0); }
static inline void em_cmp_eax_ecx(emitter_t *em) { em1(em, 0x39); em1(em, 0xC8); }
static inline void em_setcc_eax(emitter_t *em, u8 op) {
    em1(em, 0x0F); em1(em, op); em1(em, 0xC0);
    em1(em, 0x0F); em1(em, 0xB6); em1(em, 0xC0);
}
static inline void em_xchg_eax_ecx(emitter_t *em) { em1(em, 0x91); }
static inline void em_shl_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xE0); }
/* SHR в c4 — АРИФМЕТИЧЕСКИЙ сдвиг (int знаковый): sar eax, cl = D3 F8.
 * USHR — ЛОГИЧЕСКИЙ сдвиг (unsigned): shr eax, cl = D3 E8 */
static inline void em_sar_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xF8); }
static inline void em_shr_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xE8); }
static inline void em_test_eax_eax(emitter_t *em) { em1(em, 0x85); em1(em, 0xC0); }
static inline void em_test_ecx_ecx(emitter_t *em) { em1(em, 0x85); em1(em, 0xC9); }
/* short: movsx/movzx eax, word [eax]; mov word [ecx], ax */
static inline void em_movsx_eax_word_deref_eax(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xBF); em1(em, 0x00);
}
static inline void em_movzx_eax_word_deref_eax(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xB7); em1(em, 0x00);
}
static inline void em_mov_deref_ecx_ax(emitter_t *em) {
    em1(em, 0x66); em1(em, 0x89); em1(em, 0x01);
}
/* call eax (косвенный вызов JSRI) */
static inline void em_call_eax(emitter_t *em) { em1(em, 0xFF); em1(em, 0xD0); }

/* ---------- float/double: x87-эмиттеры ----------
 * Соглашение: double-ЗНАЧЕНИЕ выражения — в ST0; float/double-переменные —
 * 4/8 байт в памяти; double-аргументы — 8 байт на стеке ячеек (2 ячейки). */
/* add esp, imm8: 83 C4 imm8 */
static inline void em_add_esp_imm8(emitter_t *em, u8 v) { em1(em, 0x83); em1(em, 0xC4); em1(em, v); }
static inline void em_fld_qword_eax(emitter_t *em)  { em1(em, 0xDD); em1(em, 0x00); }  /* fld qword [eax] */
static inline void em_fld_dword_eax(emitter_t *em)  { em1(em, 0xD9); em1(em, 0x00); }  /* fld dword [eax] */
static inline void em_fstp_qword_eax(emitter_t *em) { em1(em, 0xDD); em1(em, 0x18); }  /* fstp qword [eax] */
static inline void em_fstp_dword_eax(emitter_t *em) { em1(em, 0xD9); em1(em, 0x18); }  /* fstp dword [eax] */
static inline void em_fld_qword_esp(emitter_t *em)  { em1(em, 0xDD); em1(em, 0x04); em1(em, 0x24); }
static inline void em_fild_dword_esp(emitter_t *em) { em1(em, 0xDB); em1(em, 0x04); em1(em, 0x24); }
static inline void em_fstp_qword_esp(emitter_t *em) { em1(em, 0xDD); em1(em, 0x1C); em1(em, 0x24); }
static inline void em_faddp(emitter_t *em) { em1(em, 0xDE); em1(em, 0xC1); }  /* st1 = st1 + st0; pop */
static inline void em_fsubp(emitter_t *em) { em1(em, 0xDE); em1(em, 0xE9); }  /* st1 = st1 - st0; pop */
static inline void em_fmulp(emitter_t *em) { em1(em, 0xDE); em1(em, 0xC9); }
static inline void em_fdivp(emitter_t *em) { em1(em, 0xDE); em1(em, 0xF9); }  /* st1 = st1 / st0 */
static inline void em_fchs(emitter_t *em)  { em1(em, 0xD9); em1(em, 0xE0); }
static inline void em_fabs_(emitter_t *em) { em1(em, 0xD9); em1(em, 0xE1); }
static inline void em_fsqrt(emitter_t *em) { em1(em, 0xD9); em1(em, 0xFA); }
static inline void em_fninit(emitter_t *em) { em1(em, 0xDB); em1(em, 0xE3); }  /* fninit (осторожно: D9 FB — это fsincos, НЕ fninit;
 * fsincos растит x87-стек на мусоре) */
/* сравнение: st1 (ЛЕВЫЙ) vs st0 (правый), оба снимаются → флаги → setcc */
static inline void em_fcmp2(emitter_t *em) {
    em1(em, 0xD9); em1(em, 0xC9);   /* fxch st1: st0=левый, st1=правый */
    em1(em, 0xDE); em1(em, 0xD9);   /* fcompp: сравнить и снять оба */
    em1(em, 0xDF); em1(em, 0xE0);   /* fnstsw ax: C0→CF, C2→PF, C3→ZF */
    em1(em, 0x9E);                  /* sahf */
}
static inline void em_itof2(emitter_t *em) {
    /* контракт VM (c4.c ITOF2): input [r.lo][r.hi][int] → output
     * [r.lo][r.hi][d.lo][d.hi] — int ПОТРЕБЛЯЕТСЯ, r сдвигается на 4 байта вниз */
    em1(em, 0x83); em1(em, 0xEC); em1(em, 0x04);                 /* sub esp,4 */
    em1(em, 0x8B); em1(em, 0x54); em1(em, 0x24); em1(em, 0x04);  /* mov edx,[esp+4] (r.lo) */
    em1(em, 0x89); em1(em, 0x14); em1(em, 0x24);                 /* mov [esp],edx */
    em1(em, 0x8B); em1(em, 0x4C); em1(em, 0x24); em1(em, 0x08);  /* mov ecx,[esp+8] (r.hi) */
    em1(em, 0x89); em1(em, 0x4C); em1(em, 0x24); em1(em, 0x04);  /* mov [esp+4],ecx */
    em1(em, 0xDB); em1(em, 0x44); em1(em, 0x24); em1(em, 0x0C);  /* fild dword [esp+12] (int) */
    em1(em, 0xDD); em1(em, 0x5C); em1(em, 0x24); em1(em, 0x08);  /* fstp qword [esp+8] */
}
/* UTOF2: [int][double(2)] → [double(2)][double(2)] — левый БЕЗЗНАКОВЫЙ
 * (при старшем бите коррекция +2^32 после fild/fstp) */
static inline void em_utof2(emitter_t *em) {
    em1(em, 0x83); em1(em, 0xEC); em1(em, 0x04);                 /* sub esp,4 */
    em1(em, 0x8B); em1(em, 0x54); em1(em, 0x24); em1(em, 0x04);  /* mov edx,[esp+4] (r.lo) */
    em1(em, 0x89); em1(em, 0x14); em1(em, 0x24);                 /* mov [esp],edx */
    em1(em, 0x8B); em1(em, 0x4C); em1(em, 0x24); em1(em, 0x08);  /* mov ecx,[esp+8] (r.hi) */
    em1(em, 0x89); em1(em, 0x4C); em1(em, 0x24); em1(em, 0x04);  /* mov [esp+4],ecx */
    em1(em, 0x8B); em1(em, 0x44); em1(em, 0x24); em1(em, 0x0C);  /* mov eax,[esp+12] (int) */
    em1(em, 0xDB); em1(em, 0x44); em1(em, 0x24); em1(em, 0x0C);  /* fild dword [esp+12] */
    em1(em, 0xDD); em1(em, 0x5C); em1(em, 0x24); em1(em, 0x08);  /* fstp qword [esp+8] — d(int) */
    em1(em, 0x85); em1(em, 0xC0);                                /* test eax, eax */
    em1(em, 0x79); em1(em, 0x18);                                /* jns L1 (+24) */
    em_push_imm32(em, 0x41F00000u);          /* hi 2^32 — ПЕРВЫМ (глубже) */
    em_push_imm32(em, 0x00000000u);          /* lo 2^32 — на вершине */
    /* little-endian qword [esp] = lo | hi<<32 = 0x41F0000000000000 = 2^32 */
    em_fld_qword_esp(em);                                       /* fld qword [esp] */
    /* после двух пушей d(int) лежит на [esp+0x10] (под 2^32 и r(2)) */
    em1(em, 0xDC); em1(em, 0x44); em1(em, 0x24); em1(em, 0x10);  /* fadd qword [esp+16] — +d */
    em1(em, 0xDD); em1(em, 0x5C); em1(em, 0x24); em1(em, 0x10);  /* fstp qword [esp+16] */
    em_add_esp_imm8(em, 8);                                      /* снять 2 пуша */
    /* L1: стек [r(2)][d(2)] — int потреблён (как в ITOF2) */
}
/* SCP n: [dst][src] → почленная копия n байт (struct assignment, C89).
 * esi/edi (kapi/win) сохраняются. Результат: eax = dst. */
static inline void em_scp(emitter_t *em, u32 n) {
    em_pop_ecx(em);                              /* src */
    em1(em, 0x5A);                               /* pop edx — dst */
    em1(em, 0x56);                               /* push esi */
    em1(em, 0x57);                               /* push edi */
    em1(em, 0x89); em1(em, 0xD7);                /* mov edi, edx */
    em1(em, 0x89); em1(em, 0xCE);                /* mov esi, ecx */
    em1(em, 0xB9); em4(em, n);                   /* mov ecx, n */
    em1(em, 0xFC);                               /* cld */
    em1(em, 0xF3); em1(em, 0xA4);                /* rep movsb */
    em1(em, 0x5F);                               /* pop edi */
    em1(em, 0x5E);                               /* pop esi */
    em1(em, 0x89); em1(em, 0xD0);                /* mov eax, edx (результат — dst) */
}
/* mov eax, [edi + off] — общая часть emit_syscall / em_call_kapi /
 * KFLIP / PRTF */
static inline void em_load_kapi(emitter_t *em, u32 kapi_offset) {
    if (kapi_offset <= 127) {
        em1(em, 0x8B); em1(em, 0x47); em1(em, (u8)kapi_offset);
    } else {
        em1(em, 0x8B); em1(em, 0x87); em4(em, kapi_offset);
    }
}
/* call через kapi + возврат (для fpu lock/unlock в стабе входа) */
static inline void em_call_kapi(emitter_t *em, u32 kapi_offset) {
    em_load_kapi(em, kapi_offset);
    em1(em, 0xFF); em1(em, 0xD0);   /* call eax */
}

/* jmp rel32: E9 rel32 — возвращает offset поля rel32 для последующего патча */
static inline u32 em_jmp_rel32(emitter_t *em) {
    em1(em, 0xE9);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* jz rel32: 0F 84 rel32 */
static inline u32 em_jz_rel32(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0x84);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* jnz rel32: 0F 85 rel32 */
static inline u32 em_jnz_rel32(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0x85);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* call rel32: E8 rel32 */
static inline u32 em_call_rel32(emitter_t *em) {
    em1(em, 0xE8);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* add esp, imm32: 81 C4 imm32 */
static inline void em_add_esp_imm32(emitter_t *em, u32 v) { em1(em, 0x81); em1(em, 0xC4); em4(em, v); }

/* enter: push ebp; mov ebp, esp; sub esp, size */
static inline void em_enter(emitter_t *em, u32 size) {
    em1(em, 0x55);
    em1(em, 0x89); em1(em, 0xE5);
    if (size > 0) {
        if (size <= 127) {
            em1(em, 0x83); em1(em, 0xEC); em1(em, (u8)size);
        } else {
            em1(em, 0x81); em1(em, 0xEC); em4(em, size);
        }
    }
}
/* lea eax, [ebp + disp]: 8D 45 disp8 (3 байта) / 8D 85 disp32 (6 байт) —
 * смещения локалов/параметров кадра обычно вписываются в imm8 */
static inline void em_lea_eax_ebp(emitter_t *em, i32 disp) {
    if (disp >= -128 && disp <= 127) {
        em1(em, 0x8D); em1(em, 0x45); em1(em, (u8)disp);
    } else {
        em1(em, 0x8D); em1(em, 0x85); em4(em, (u32)disp);
    }
}

/* ---------- таблица relocation (переходы байт-код → x86) ---------- */
typedef struct {
    u32 src_x86_offset;      /* где записано rel32 (подлежит патчу) */
    u32 target_bc_cell;      /* индекс int-ячейки в байт-коде */
} reloc_t;

/* все таблицы кодогенерации — в куче: единый scratch-блок, выделяется
 * в c4_compile_to_native под c4_codegen_lock, освобождается на ВСЕХ
 * выходах (иначе ~430КБ BSS жили бы в ядре постоянно, а компиляция —
 * редкое событие) */
#define MAX_RELOCS 8192
static reloc_t *g_relocs;
static int g_n_relocs = 0;

/* переполнение таблицы — ошибка компиляции в конце (set_diag + -1), не молча */
static int g_overflow = 0;

/* Фикспейсы переходов на эпилог деления на ноль (jmp divzero) */
#define MAX_DIVFIX 512
static u32 *g_divfix;
static int g_n_divfix = 0;

/* Релокации сегмента данных: x86-offset imm32, значение = смещение
 * в сегменте данных (loader добавит базу выделенного блока данных). */
#define MAX_DATA_RELOCS 8192
static u32 *g_data_relocs;
static int g_n_data_relocs = 0;

/* Релокации TEXT-адресов: имя функции как значение.
 * Эмитится call $+5; pop eax; add eax, rel32 — rel32 патчится ПОСЛЕ
 * прохода (цель может быть впереди): {позиция rel32, позиция pop, ячейка цели}. */
#define MAX_TEXT_FIX 2048
typedef struct { u32 rel_pos, pop_pos, bc_target; } textfix_t;
static textfix_t *g_textfix;
static int g_n_textfix = 0;

/* копия c4_imm_text_cells, отсортированная ПОСЛЕ c4_compile —
 * imm_cell_is_text работает бинарным поиском */
static u32 *g_text_sorted;
static int  g_n_text_sorted = 0;

static void text_cells_sort(void) {
    extern u32 c4_imm_text_cells[];
    extern int  c4_n_imm_text_cells;
    int n = c4_n_imm_text_cells;
    int i, j;
    if (n > MAX_TEXT_FIX) n = MAX_TEXT_FIX;
    for (i = 0; i < n; i++) g_text_sorted[i] = c4_imm_text_cells[i];
    /* вставками: n <= 2048; метки идут по мере кодогена — массив почти
     * упорядочен, сортировка вырождается в O(n) */
    for (i = 1; i < n; i++) {
        u32 v = g_text_sorted[i];
        for (j = i - 1; j >= 0 && g_text_sorted[j] > v; j--)
            g_text_sorted[j + 1] = g_text_sorted[j];
        g_text_sorted[j + 1] = v;
    }
    g_n_text_sorted = n;
}

static int imm_cell_is_text(u32 operand_cell) {
    int lo = 0, hi = g_n_text_sorted - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        u32 c = g_text_sorted[mid];
        if (c == operand_cell) return 1;
        if (c < operand_cell) lo = mid + 1; else hi = mid - 1;
    }
    return 0;
}

/* ---------- карта {bc_cell → x86_offset} ---------- */
typedef struct {
    u32 bc_cell;
    u32 x86_offset;
} bc_map_t;

#define MAX_MAPS 16384
static bc_map_t *g_map;
static int g_n_maps = 0;

/* bc-ячейки карты СТРОГО монотонны (запись — вверху главного цикла, bc
 * растёт), дубликатов нет: bc_to_x86 — бинарный поиск, bc_map_add — O(1) */
static u32 bc_to_x86(u32 bc_cell) {
    int lo = 0, hi = g_n_maps - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        u32 c = g_map[mid].bc_cell;
        if (c == bc_cell) return g_map[mid].x86_offset;
        if (c < bc_cell) lo = mid + 1; else hi = mid - 1;
    }
    return 0xFFFFFFFFu;
}

static void bc_map_add(u32 bc_cell, u32 x86_offset) {
    if (g_n_maps < MAX_MAPS) {
        g_map[g_n_maps].bc_cell = bc_cell;
        g_map[g_n_maps].x86_offset = x86_offset;
        g_n_maps++;
    } else {
        g_overflow = 1;   /* карта переполнена — новые цели не резолвятся */
    }
}

/* цели переходов в байт-коде — АБСОЛЮТНЫЕ указатели (le + cell); карта
 * построена на индексах ячеек, пересчёт по базе текст-пула */
/* граница нормализации — по ФАКТИЧЕСКОЙ длине байт-кода */
static u32 g_bc_len_cells = 0;

/* пулы байт-кода/данных — в куче; заполняются c4_compile, читаются
 * сканами и главным циклом */
static int *g_bc_pool;
static u8  *g_data_pool;

static u32 bc_norm_target(u32 target) {
    extern u32 c4_compile_text_base;
    u32 base = c4_compile_text_base;
    u32 lim = g_bc_len_cells ? g_bc_len_cells : 65536u;   /* защитный фолбэк */
    if (base && target >= base && target < base + lim * 4u) {
        return (target - base) >> 2;   /* / sizeof(int) */
    }
    return target;   /* уже индекс (или что-то странное — пусть карта решит) */
}

static void add_reloc(u32 src, u32 target_bc) {
    if (g_n_relocs < MAX_RELOCS) {
        g_relocs[g_n_relocs].src_x86_offset = src;
        g_relocs[g_n_relocs].target_bc_cell = bc_norm_target(target_bc);
        g_n_relocs++;
    } else {
        g_overflow = 1;
    }
}

/* битовая карта целей переходов: peephole-слияние «PSH;IMM v;binop →
 * op eax,v» и no-op JMP допустимы ТОЛЬКО если ни одна из поглощаемых
 * ячеек — не цель JMP/JSR/BZ/BNZ (иначе переход попадёт в середину
 * слитой последовательности или на ячейку без записи в карте).
 * Обход — синхронно транслятору, опкоды с операндом (1 ячейка):
 * LEA/IMM/JMP/JSR/BZ/BNZ/ENT/ADJ, JSRI, SCP; FLDI — 2; остальные — 1 */
#define BC_MAX_CELLS 65536
static u8 *g_jump_target;    /* битмап BC_MAX_CELLS/8 — scratch-блок */

static void mark_jump_targets(void) {
    u32 bc = 1;
    u32 i;
    for (i = 0; i < BC_MAX_CELLS / 8; i++) g_jump_target[i] = 0;
    while (bc < g_bc_len_cells) {
        int op = g_bc_pool[bc++];
        if (op == JMP || op == JSR || op == BZ || op == BNZ) {
            u32 t = bc_norm_target((u32)g_bc_pool[bc++]);
            if (t < BC_MAX_CELLS) g_jump_target[t >> 3] |= (u8)(1u << (t & 7));
        } else if ((op >= LEA && op <= ADJ) || op == JSRI || op == SCP) {
            bc += 1;                       /* опкод + операнд */
        } else if (op == FLDI) {
            bc += 2;                       /* lo hi */
        }
    }
}

static int is_jump_target(u32 cell) {
    if (cell >= BC_MAX_CELLS) return 0;
    return (g_jump_target[cell >> 3] >> (cell & 7)) & 1;
}

/* ячейка-операнд IMM ссылается на сегмент данных (строки/глобалы)?
 * Метки ставит компилятор c4.c */
/* ---------- генерация syscall (вызов через kapi) ----------
 *
 * Аргументы лежат на стеке в ПОРЯДКЕ c4: [ESP] = последний аргумент,
 * [ESP+4*(n-1)] = первый. cdecl ждёт [ESP] = первый аргумент.
 *
 * Реверс: последовательность push [esp + 8*(k-1)] для k=1..n кладёт
 * копии аргументов в правильном cdecl-порядке ПОВЕРХ оригиналов
 * (доказано индукцией: на шаге k читается [esp0 + 4*(k-1)] = аргумент
 * n-k+1; последний пуш — первый аргумент → он на вершине).
 *
 * После вызова КОПИИ снимаются здесь; оригиналы снимает следующий в
 * байт-коде ADJ. Результат остаётся в EAX (= "a" виртуальной машины),
 * БЕЗ пуша (в VM syscall не кладёт результат на стек). */
static void emit_syscall(emitter_t *em, u32 kapi_offset, int n_args) {
    /* n <= 1 — копии аргументов не нужны: n == 1 — единственный аргумент УЖЕ
     * в [esp], ровно там, где его ждёт cdecl (массовый случай: MALC/FREE/
     * KDELAY/KEVENT/...). load_kapi+call+cleanup вынесены из веток —
     * машинный код тот же, дублирования нет */
    if (n_args > 1) {
        /* 1. Реверс аргументов */
        int k;
        for (k = 1; k <= n_args; k++) {
            u32 d = 8u * (u32)(k - 1);
            if (d <= 127) {
                em1(em, 0xFF); em1(em, 0x74); em1(em, 0x24); em1(em, (u8)d);
            } else {
                em1(em, 0xFF); em1(em, 0xB4); em1(em, 0x24); em4(em, d);
            }
        }
    }
    /* disp8 требует ModRM 0x47 (mod=01), а не 0x87 (mod=10 = disp32 — декодер
     * съел бы 4 лишних байта, и весь последующий код превратился в мусор) */
    em_load_kapi(em, kapi_offset);
    /* call eax */
    em1(em, 0xFF); em1(em, 0xD0);
    if (n_args > 1) {
        /* 3. Снять только КОПИИ (n_args*4); оригиналы снимает ADJ */
        u32 cleanup = (u32)n_args * 4u;
        if (cleanup <= 127) em_add_esp_imm8(em, (u8)cleanup);
        else em_add_esp_imm32(em, cleanup);
    }
    /* результат в EAX; НЕ пушим — снимет следующий в байт-коде ADJ */
}

static void set_diag(char *diag, u32 diag_max, const char *m) {
    if (diag && diag_max) {
        u32 L = (u32)strlen(m);
        if (L >= diag_max) L = diag_max - 1;
        memcpy(diag, m, L);
        diag[L] = 0;
    }
}

/* табличная диспетчеризация сравнений: группы EQ/NE, LT/GT/LE/GE,
 * ULT/UGT/ULE/UGE, FEQ..FGE — одинаковая раскладка, отличался только
 * код условия (16 однотипных case в switch).
 * kind: 0 — int (левый операнд снимается со стека, результат — int в a);
 *       1 — float (два double по 2 ячейки, результат — int в a).
 * xchg: некоммутативные сравнения — ЛЕВЫЙ снимается pop'ом в ecx,
 *       нужен xchg eax,ecx */
typedef struct { u8 op; u8 kind; u8 xchg; u8 cc; u8 pf; } c4x86_cmp_t;
/* pf (только kind==1): коррекция unordered (NaN) до IEEE-семантики.
 * fcompp при NaN даёт C0=C2=C3=1 → после sahf CF=PF=ZF=1:
 *   0 — коррекция не нужна (FGT/FGE на unordered и так false);
 *   1 — unordered → false: setnp cl; and al,cl  (FEQ/FLT/FLE);
 *   2 — unordered → true:  setp  cl; or  al,cl  (FNE).
 * +5 байт на сравнение */
static const c4x86_cmp_t g_cmp_ops[] = {
    { EQ,  0, 0, 0x94, 0 }, { NE,  0, 0, 0x95, 0 },
    { LT,  0, 1, 0x9C, 0 }, { GT,  0, 1, 0x9F, 0 }, { LE,  0, 1, 0x9E, 0 }, { GE,  0, 1, 0x9D, 0 },
    { ULT, 0, 1, 0x92, 0 }, { UGT, 0, 1, 0x97, 0 }, { ULE, 0, 1, 0x96, 0 }, { UGE, 0, 1, 0x93, 0 },
    { FEQ, 1, 0, 0x94, 1 }, { FNE, 1, 0, 0x95, 2 },
    { FLT, 1, 0, 0x92, 1 }, { FLE, 1, 0, 0x96, 1 }, { FGT, 1, 0, 0x97, 0 }, { FGE, 1, 0, 0x93, 0 },
};

static const c4x86_cmp_t *cmp_lookup(int op) {
    u32 n = (u32)(sizeof(g_cmp_ops) / sizeof(g_cmp_ops[0]));
    for (u32 i = 0; i < n; i++)
        if (g_cmp_ops[i].op == op) return &g_cmp_ops[i];
    return 0;
}

/* ---------- главный кодогенератор ---------- */
/* размеры регионов единого scratch-блока (куча); худший одиночный аллок
 * 256КБ (bc_pool) — размер уже проверен c4_compile_to_file (out_buf 256КБ) */
#define C4X_BC_SZ    (65536u * sizeof(int))
#define C4X_DATA_SZ  65536u
#define C4X_MAP_SZ   (MAX_MAPS * sizeof(bc_map_t))
#define C4X_REL_SZ   (MAX_RELOCS * sizeof(reloc_t))
#define C4X_DREL_SZ  (MAX_DATA_RELOCS * 4u)
#define C4X_TFIX_SZ  (MAX_TEXT_FIX * sizeof(textfix_t))
#define C4X_DFIX_SZ  (MAX_DIVFIX * 4u)
#define C4X_JT_SZ    (BC_MAX_CELLS / 8)
#define C4X_TSRT_SZ  (MAX_TEXT_FIX * 4u)
#define C4X_SCRATCH_SZ (C4X_BC_SZ + C4X_DATA_SZ + C4X_MAP_SZ + C4X_REL_SZ + \
                        C4X_DREL_SZ + C4X_TFIX_SZ + C4X_DFIX_SZ + C4X_JT_SZ + \
                        C4X_TSRT_SZ)

int c4_compile_to_native(const char *src, char *diag, u32 diag_max,
                         void *out_buf, u32 out_max, u32 *out_size)
{
    u32 bc_len_cells = 0;
    u32 data_len = 0;
    u32 entry_cells = 0;
    u8 *scratch_base;
    u8 *sc;

    /* Сериализация: c4_compile (внутри) берёт c4_run_lock, но пулы/
     * таблицы ЭТОГО модуля живут и после его завершения — без второй
     * блокировки два окна-редактора, компилирующие одновременно,
     * калечили бы байт-код друг друга. */
    static volatile int c4_codegen_lock = 0;
    s_lock(&c4_codegen_lock);

    if (diag && diag_max) diag[0] = 0;
    g_overflow = 0;

    scratch_base = (u8 *)malloc(C4X_SCRATCH_SZ);
    if (!scratch_base) {
        set_diag(diag, diag_max, "c4_x86: no memory for codegen pools");
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    sc = scratch_base;
    g_bc_pool     = (int *)sc;        sc += C4X_BC_SZ;
    g_data_pool   = sc;               sc += C4X_DATA_SZ;
    g_map         = (bc_map_t *)sc;   sc += C4X_MAP_SZ;
    g_relocs      = (reloc_t *)sc;    sc += C4X_REL_SZ;
    g_data_relocs = (u32 *)sc;        sc += C4X_DREL_SZ;
    g_textfix     = (textfix_t *)sc;  sc += C4X_TFIX_SZ;
    g_divfix      = (u32 *)sc;        sc += C4X_DFIX_SZ;
    g_jump_target = sc;               sc += C4X_JT_SZ;
    g_text_sorted = (u32 *)sc;

    if (!c4_compile(src, diag, diag_max,
                    g_bc_pool, C4X_BC_SZ, &bc_len_cells,
                    g_data_pool, C4X_DATA_SZ, &data_len,
                    &entry_cells)) {
        free(scratch_base);
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    g_bc_len_cells = bc_len_cells;   /* до сканов — граница bc_norm_target */

    emitter_t em = { (u8 *)out_buf, 0, out_max, 0 };
    g_n_relocs = 0;
    g_n_maps = 0;
    g_n_divfix = 0;
    g_n_data_relocs = 0;
    g_n_textfix = 0;
    g_n_text_sorted = 0;
    text_cells_sort();     /* сортировка для imm_cell_is_text */
    mark_jump_targets();   /* карта целей для peephole/no-op JMP */

    /* FPU-лок — только для программ с float-кодом (иначе не-float программа
     * держала бы глобальный лок всё время работы). Скан СТРОГИЙ: после
     * опкода с немедленным операндом его операнды ПРОПУСКАЮТСЯ — байт-код
     * просматривается как ОПКОДНЫЙ ПОТОК, а не плоский массив (иначе
     * операнд «IMM 130» ложно включал лок). Опкоды с операндом (1 ячейка):
     * LEA/IMM/JMP/JSR/BZ/BNZ/ENT/ADJ (0..7), PRTF, JSRI, SCP; FLDI —
     * 2 ячейки (lo hi). SCP в диапазон FLDI..FSTKF попадает, но float'ом
     * НЕ является */
    int bc_has_float = 0;
    /* Старт С ЯЧЕЙКИ 1 — pool[0] НЕ используется (см. транслятор ниже:
     * «u32 bc = 1; pool[0] is unused in c4»). Поток опкодов начинается
     * с ячейки 1: JSR boot-чанков или ENT main. Пропуск реального
     * float-опкода невозможен: обход синхронен транслятору. */
    for (u32 si = 1; si < bc_len_cells; ) {
        int o = g_bc_pool[si];
        if (o >= FLDI && o <= FSTKF && o != SCP) { bc_has_float = 1; break; }
        if ((o >= LEA && o <= ADJ) || o == PRTF || o == JSRI || o == SCP)
            si += 2;                 /* опкод + операнд */
        else
            si += 1;
    }

    /* База сегмента данных на момент компиляции — IMM-операнды строк и
     * глобалов содержат абсолютные адреса data_pool компилятора; мы
     * переписываем их на смещения и релоцируем при загрузке. */
    extern u32 c4_compile_data_base;
    u32 data_base = c4_compile_data_base;

    /* Entry stub: int entry(kapi_t *k, void *win)
     *   55            push ebp
     *   89 E5         mov ebp, esp
     *   53            push ebx                 ; сохранить EBX вызывателя (cdecl)
     *   89 EB         mov ebx, ebp             ; EBX = кадр entry (unwind для exit)
     *   8B 7D 08      mov edi, [ebp+8]         ; kapi
     *   8B 75 0C      mov esi, [ebp+12]        ; win
     *   E8 rel32      call main                ; НАСТОЯЩИЙ адрес возврата
     *   5B            pop ebx                  ; восстановить EBX вызывателя
     *   C9            leave                    ; esp=entry ebp; pop ebp
     *   C3            ret                      ; → в loader (EAX = код возврата)
     * 
     * call rel32 кладёт НАСТОЯЩИЙ адрес возврата — код position-independent;
     * unwind из exit() (mov esp,ebx) не зависит от способа входа. */
    em1(&em, 0x55);                                  /* push ebp */
    em1(&em, 0x89); em1(&em, 0xE5);                   /* mov ebp, esp */
    em1(&em, 0x53);                                   /* push ebx */
    em1(&em, 0x89); em1(&em, 0xEB);                   /* mov ebx, ebp */
    em1(&em, 0x8B); em1(&em, 0x7D); em1(&em, 0x08);   /* mov edi, [ebp+8] */
    em1(&em, 0x8B); em1(&em, 0x75); em1(&em, 0x0C);   /* mov esi, [ebp+12] */
    /* x87 планировщиком не сохраняется — ВСЯ float-программа исполняется
     * под общим FPU-локом (mp3/img ждут своей очереди); лок — только при
     * float-опкодах */
    if (bc_has_float) em_call_kapi(&em, KAPI_FPU_LOCK);   /* fpu_lock() */
    /* 4.2: main(argc, argv) — строим argv[] позиционно-независимо:
     *   E8 05000000    call L1        ; кладёт адрес L1 в стек
     * L1: 59           pop ecx        ; ecx = &L1
     *   83 C1 d8       add ecx, imm8  ; ecx = &"prog" (строка в хвосте стаба)
     *   51             push ecx       ; argv[0]
     *   6A 00          push 0         ; argv[1] = NULL
     *   89 E1          mov ecx, esp   ; ecx = &argv[0]
     *   51             push ecx       ; аргумент argv
     *   6A 01          push 1         ; аргумент argc
     *   E8 rel32       call main
     *   83 C4 10       add esp, 16    ; снять argc+argv+2 слова массива
     * (для main без параметров лишние слоты снимаются здесь же — cdecl) */
    u32 call_l1_pos = em.pos;
    em1(&em, 0xE8); em4(&em, 0);                      /* call L1 */
    u32 l1_pos = em.pos;
    em1(&em, 0x59);                                   /* pop ecx */
    u32 add_pos = em.pos;
    em1(&em, 0x83); em1(&em, 0xC1); em1(&em, 0x00);   /* add ecx, imm8 (патчим) */
    em1(&em, 0x51);                                   /* push ecx (argv[0]) */
    em1(&em, 0x6A); em1(&em, 0x00);                   /* push 0 */
    em1(&em, 0x89); em1(&em, 0xE1);                   /* mov ecx, esp */
    /* порядок c4: параметр 0 (argc) — глубже всех, т.е. пушится ПЕРВЫМ */
    em1(&em, 0x6A); em1(&em, 0x01);                   /* push 1 (argc) */
    em1(&em, 0x51);                                   /* push ecx (argv) */
    u32 entry_call_offset = em_call_rel32(&em);       /* call main (patched later) */
    /* после main — сброс x87 (мусор от float-кода) и отпускание FPU-лока;
     * результат main в EAX — сохраняем; fninit/unlock — только у
     * float-программ */
    if (bc_has_float) {
        em_fninit(&em);
        em1(&em, 0x50);                                   /* push eax */
        em_call_kapi(&em, KAPI_FPU_UNLOCK); /* fpu_unlock() */
        em_pop_eax(&em);
    }
    em_add_esp_imm8(&em, 16);                         /* снять аргументы+argv */
    em1(&em, 0x5B);                                   /* pop ebx */
    em1(&em, 0xC9);                                   /* leave */
    em1(&em, 0xC3);                                   /* ret */
    /* строка argv[0] в хвосте стаба (адрес считается от L1) */
    { static const char prog[] = "prog";
      for (int i = 0; i < (int)sizeof(prog); i++) em1(&em, (u8)prog[i]); /* 5 байт с NUL */ }
    /* патчим call L1 (rel32 = 5 байт вперёд) и add ecx, imm8 */
    {
        i32 rel = (i32)l1_pos - (i32)(call_l1_pos + 5);
        em.buf[call_l1_pos + 1] = (u8)(rel & 0xFF);
        em.buf[call_l1_pos + 2] = (u8)((rel >> 8) & 0xFF);
        em.buf[call_l1_pos + 3] = (u8)((rel >> 16) & 0xFF);
        em.buf[call_l1_pos + 4] = (u8)((rel >> 24) & 0xFF);
        /* ecx = адрес возврата call = l1_pos (инструкция pop); строка
         * "prog" лежит сразу после ret стаба */
        u32 prog_off = em.pos - 5;                    /* начало "prog" */
        i32 d = (i32)prog_off - (i32)l1_pos;          /* от адреса в ecx */
        em.buf[add_pos + 2] = (u8)(d & 0xFF);
    }

    /* Single pass: emit each c4 opcode as x86 */
    u32 bc = 1;  /* pool[0] is unused in c4 */
    while (bc < bc_len_cells) {
        /* Record map BEFORE emitting (jump targets at this cell resolve here) */
        bc_map_add(bc, em.pos);

        int op = g_bc_pool[bc++];
        /* сравнения (EQ/NE/LT/GT/LE/GE, ULT..UGE, FEQ..FGE) — таблица g_cmp_ops.
         * В c4 a = *sp++ OP a — pop это ЛЕВЫЙ операнд, EAX — правый;
         * для некоммутативных операций нужен xchg (задан в таблице) */
        const c4x86_cmp_t *ci = cmp_lookup(op);
        if (ci) {
            if (ci->kind == 0) {
                em_pop_ecx(&em);
                if (ci->xchg) em_xchg_eax_ecx(&em);
                em_cmp_eax_ecx(&em);
                em_setcc_eax(&em, ci->cc);
            } else {
                /* float: pop right(2), pop left(2) → int в eax (a).
                 * em_fcmp2 ждёт: st0=ПРАВЫЙ, st1=ЛЕВЫЙ — грузим left первым. */
                em1(&em, 0xDD); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x08); /* fld qword [esp+8] (left) */
                em_fld_qword_esp(&em);                                          /* fld qword [esp] (right) */
                em_fcmp2(&em);
                /* setcc+pf-коррекция обязаны читать флаги СРАЗУ после sahf: add
                 * затирает CF/ZF/PF; cleanup стека — в конце ветки */
                em_setcc_eax(&em, ci->cc);
                /* pf-коррекция unordered (NaN) — см. g_cmp_ops.pf.
                 * ecx здесь свободен (scratch), результат живёт в al. */
                if (ci->pf == 1) {
                    em1(&em, 0x0F); em1(&em, 0x9B); em1(&em, 0xC1);   /* setnp cl */
                    em1(&em, 0x20); em1(&em, 0xC8);                   /* and al, cl */
                } else if (ci->pf == 2) {
                    em1(&em, 0x0F); em1(&em, 0x9A); em1(&em, 0xC1);   /* setp cl */
                    em1(&em, 0x08); em1(&em, 0xC8);                   /* or al, cl */
                }
                em_add_esp_imm8(&em, 16);
            }
        }
        else switch (op) {
            case IMM: {
                u32 val = (u32)g_bc_pool[bc++];
                /* TEXT-адрес (имя функции как значение, 3.3): эмитим
                 * позиционно-независимо: call $+5; pop eax; add eax, rel32.
                 * rel32 патчится после прохода через bc-карту. */
                if (imm_cell_is_text(bc - 1)) {
                    em1(&em, 0xE8); em4(&em, 0);          /* call $+5 */
                    u32 pop_pos = em.pos;
                    em1(&em, 0x58);                        /* pop eax */
                    em1(&em, 0x05);                        /* add eax, imm32 */
                    u32 rel_pos = em.pos;
                    em4(&em, 0);
                    if (g_n_textfix < MAX_TEXT_FIX) {
                        g_textfix[g_n_textfix].rel_pos = rel_pos;
                        g_textfix[g_n_textfix].pop_pos = pop_pos;
                        g_textfix[g_n_textfix].bc_target = val;
                        g_n_textfix++;
                    } else {
                        g_overflow = 1;   /* не молча */
                    }
                    break;
                }
                /* ссылка на сегмент данных (строка/глобал) → смещение + релокация:
                 * loader подставит базу данных БИНАРНЫХ программ */
                if (data_base != 0 && val >= data_base && val < data_base + data_len) {
                    u32 x86_imm_off = em.pos + 1;   /* поле imm32 после B8 */
                    if (g_n_data_relocs < MAX_DATA_RELOCS)
                        g_data_relocs[g_n_data_relocs++] = x86_imm_off;
                    else
                        g_overflow = 1;   /* не молча */
                    val = val - data_base;           /* смещение в сегменте данных */
                }
                /* IMM кладёт значение в EAX (аккумулятор "a"), НЕ в стек —
                 * пуш в c4 делает только PSH */
                em_mov_eax_imm32(&em, val);
                break;
            }
            case LEA: {
                i32 offset = (i32)g_bc_pool[bc++];
                i32 disp = offset * 4;
                /* LEA = a = &local, БЕЗ пуша */
                em_lea_eax_ebp(&em, disp);
                break;
            }
            case JMP: {
                u32 target = (u32)g_bc_pool[bc++];
                /* JMP на следующую ячейку — no-op (артефакт пустых if/else/while-веток):
                 * -5 байт и минус релокация. Цель через bc_norm_target — она может быть
                 * и абсолютным указателем, и индексом */
                if (bc_norm_target(target) == bc) break;
                u32 src = em_jmp_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case JSR: {
                u32 target = (u32)g_bc_pool[bc++];
                u32 src = em_call_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case BZ: {
                u32 target = (u32)g_bc_pool[bc++];
                em_test_eax_eax(&em);
                u32 src = em_jz_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case BNZ: {
                u32 target = (u32)g_bc_pool[bc++];
                em_test_eax_eax(&em);
                u32 src = em_jnz_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case ENT: {
                u32 size = (u32)g_bc_pool[bc++];
                em_enter(&em, size * 4);
                break;
            }
            case ADJ: {
                u32 n = (u32)g_bc_pool[bc++];
                u32 cleanup = n * 4;
                if (cleanup <= 127) em_add_esp_imm8(&em, (u8)cleanup);
                else em_add_esp_imm32(&em, cleanup);
                break;
            }
            case LEV: {
                em1(&em, 0xC9); em1(&em, 0xC3);   /* leave; ret */
                break;
            }
            case LI: {
                em_mov_eax_deref_eax(&em);
                break;
            }
            case LC: {
                /* char в c4 ЗНАКОВЫЙ: movsx, а не movzx */
                em_movsx_eax_byte_deref_eax(&em);
                break;
            }
            case LS: {
                /* short знаковый: movsx eax, word [eax] */
                em_movsx_eax_word_deref_eax(&em);
                break;
            }
            case ULS: {
                /* unsigned short: movzx eax, word [eax] */
                em_movzx_eax_word_deref_eax(&em);
                break;
            }
            case SSH: {
                /* запись short: pop ecx; mov word [ecx], ax */
                em_pop_ecx(&em);
                em_mov_deref_ecx_ax(&em);
                break;
            }
            case SI: {
                em_pop_ecx(&em);
                em_mov_deref_ecx_eax(&em);
                break;
            }
            case SC: {
                em_pop_ecx(&em);
                em_mov_deref_ecx_al(&em);
                em_movsx_eax_al(&em);
                break;
            }
            case PSH: {
                /* peephole: «PSH; IMM v; комм.биноп» → «op eax, v» (левый операнд в eax
                 * НЕ пушится). Частейший паттерн (x = y + 3): было push eax; mov eax,v;
                 * pop ecx; op = 10 байт и 2 memory-op, стало op eax,v = 5 байт (MUL —
                 * imul = 6) и 0 memory-op. Условия: ни одна из 4 поглощаемых ячеек
                 * (PSH, IMM, операнд, binop) — не цель перехода; IMM-операнд — не
                 * text/data-ссылка (иначе терялась бы релокация). Только коммутативные:
                 * SUB дал бы v-left вместо left-v (паттерн «IMM;PSH;binop» в c4-
                 * байткоде недостижим: после PSH всегда идёт код правого операнда) */
                if (bc + 2 < bc_len_cells && g_bc_pool[bc] == IMM &&
                    !is_jump_target(bc - 1) && !is_jump_target(bc) &&
                    !is_jump_target(bc + 1) && !is_jump_target(bc + 2)) {
                    u32 v = (u32)g_bc_pool[bc + 1];
                    int b2 = g_bc_pool[bc + 2];
                    if (!imm_cell_is_text(bc + 1) &&
                        !(data_base != 0 && v >= data_base && v < data_base + data_len)) {
                        if (b2 == ADD) { em1(&em, 0x05); em4(&em, v); bc += 3; break; }
                        if (b2 == OR)  { em1(&em, 0x0D); em4(&em, v); bc += 3; break; }
                        if (b2 == AND) { em1(&em, 0x25); em4(&em, v); bc += 3; break; }
                        if (b2 == XOR) { em1(&em, 0x35); em4(&em, v); bc += 3; break; }
                        if (b2 == MUL) { em1(&em, 0x69); em1(&em, 0xC0); em4(&em, v); bc += 3; break; }
                    }
                }
                em_push_eax(&em);
                break;
            }
            case OR:  em_pop_ecx(&em); em_or_eax_ecx(&em); break;
            case XOR: em_pop_ecx(&em); em_xor_eax_ecx(&em); break;
            case AND: em_pop_ecx(&em); em_and_eax_ecx(&em); break;
            case SHL:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_shl_eax_cl(&em);
                break;
            case SHR:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_sar_eax_cl(&em);   /* арифметический сдвиг: int знаковый */
                break;
            case USHR:
                /* логический сдвиг: unsigned >> n (флаг UNSIGNED в c4.c) */
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_shr_eax_cl(&em);
                break;
            case UDIV:
                /* беззнаковое деление (1.3): xor edx,edx; div ecx + guard */
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_test_ecx_ecx(&em);
                em1(&em, 0x75); em1(&em, 0x05); /* jnz +5 (мимо jmp divzero) */
                {
                    u32 src = em_jmp_rel32(&em);
                    if (g_n_divfix < MAX_DIVFIX) g_divfix[g_n_divfix++] = src;
                    else g_overflow = 1;   /* не молча */
                }
                em_xor_edx_edx(&em);
                em_div_ecx(&em);
                break;
            case UMOD:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_test_ecx_ecx(&em);
                em1(&em, 0x75); em1(&em, 0x05);
                {
                    u32 src = em_jmp_rel32(&em);
                    if (g_n_divfix < MAX_DIVFIX) g_divfix[g_n_divfix++] = src;
                    else g_overflow = 1;   /* не молча */
                }
                em_xor_edx_edx(&em);
                em_div_ecx(&em);
                em_mov_eax_edx(&em);
                break;
            /* ULT/UGT/ULE/UGE — таблица g_cmp_ops */
            case JSRI: {
                /* косвенный вызов (3.3): цель — [esp + 4*n] (пуш была до
                 * аргументов); параметры на стеке в c4-порядке — как у
                 * прямого JSR. Слот цели снимет следующий ADJ n+1. */
                u32 n = (u32)g_bc_pool[bc++];
                u32 d = n * 4u;
                if (d <= 127) {
                    em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, (u8)d);  /* mov eax,[esp+d] */
                } else {
                    em1(&em, 0x8B); em1(&em, 0x84); em1(&em, 0x24); em4(&em, d);
                }
                em_call_eax(&em);   /* call eax */
                break;
            }
            /* ---------- float/double: x87 ---------- */
            /* ===== float/double — МОДЕЛЬ СТЕКА c4 =====
             * Все float-выражения считаются в double; double на стеке VM =
             * 2 ЯЧЕЙКИ (FLD/FLDI/ITOF пушат, FADD/FDIV попают) — включая границу
             * сисколов (PRTF: c4_printf_va читает ЯЧЕЙКИ со стека). x87 используется
             * ПЕРЕХОДНО (загрузка-операция-выгрузка), глубина x87 <= 3 на любой опкод */
            case FLDI: {
                /* литерал: [pc]=lo,[pc+1]=hi → push hi; push lo
                 * (VM: *--sp=pc[1]; *--sp=pc[0] — hi глубже) */
                u32 lo = (u32)g_bc_pool[bc++], hi = (u32)g_bc_pool[bc++];
                em_push_imm32(&em, hi);
                em_push_imm32(&em, lo);
                break;
            }
            case FLD0:                              /* push 0.0 — два dword-нуля, 4 байта без x87 */
                em1(&em, 0x6A); em1(&em, 0x00);     /* push 0 (lo) */
                em1(&em, 0x6A); em1(&em, 0x00);     /* push 0 (hi) */
                break;
            case FLD1:                              /* push 1.0 = 0x3FF0000000000000, 7 байт */
                em_push_imm32(&em, 0x3FF00000u);    /* hi */
                em1(&em, 0x6A); em1(&em, 0x00);     /* push 0 (lo) */
                break;
            case FDUP:                              /* копия верхнего double без x87: push [esp+4] ×2 */
                em1(&em, 0xFF); em1(&em, 0x74); em1(&em, 0x24); em1(&em, 0x04);
                em1(&em, 0xFF); em1(&em, 0x74); em1(&em, 0x24); em1(&em, 0x04);
                break;
            case FDROP:                             /* снять верхний double */
                em_add_esp_imm8(&em, 8);
                break;
            case FLD:                               /* а — адрес: push *(double*)a */
                em_fld_qword_eax(&em);
                em1(&em, 0x83); em1(&em, 0xEC); em1(&em, 0x08);
                em_fstp_qword_esp(&em);
                em1(&em, 0x8B); em1(&em, 0x04); em1(&em, 0x24); /* mov eax,[esp] (a=lo, как VM) */
                break;
            case FLDF: {                            /* а — адрес: push (double)*(float*)a */
                em_fld_dword_eax(&em);
                em1(&em, 0x83); em1(&em, 0xEC); em1(&em, 0x08);
                em_fstp_qword_esp(&em);
                em1(&em, 0x8B); em1(&em, 0x04); em1(&em, 0x24);
                break;
            }
            case FST: {   /* [v(2)][addr] → *addr=v; остаётся [v(2)] — как VM */
                /* VM-семантика НЕ «снять адрес», а СДВИГ значения на ячейку вверх (v
                 * перезаписывается в слот addr, c4_push_d пишет [sp+4..b]): результат
                 * обязан быть top-выровнен — иначе break'ается присваивание-как-
                 * выражение (x = (d=2.5)+1.0). Целочисленная реализация (значение уже
                 * в памяти): mov eax,[esp+8]; mov edx,[esp]; mov ecx,[esp+4];
                 * mov [eax],edx; mov [eax+4],ecx; mov [esp+4],edx; mov [esp+8],ecx;
                 * add esp,4 */
                em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x08); /* mov eax,[esp+8] (addr) */
                em1(&em, 0x8B); em1(&em, 0x14); em1(&em, 0x24);                 /* mov edx,[esp] (v.lo) */
                em1(&em, 0x8B); em1(&em, 0x4C); em1(&em, 0x24); em1(&em, 0x04); /* mov ecx,[esp+4] (v.hi) */
                em1(&em, 0x89); em1(&em, 0x10);                                 /* mov [eax],edx */
                em1(&em, 0x89); em1(&em, 0x48); em1(&em, 0x04);                 /* mov [eax+4],ecx */
                em1(&em, 0x89); em1(&em, 0x54); em1(&em, 0x24); em1(&em, 0x04); /* mov [esp+4],edx (новый v.lo) */
                em1(&em, 0x89); em1(&em, 0x4C); em1(&em, 0x24); em1(&em, 0x08); /* mov [esp+8],ecx (новый v.hi) */
                em1(&em, 0x83); em1(&em, 0xC4); em1(&em, 0x04);                 /* add esp,4 */
                break;
            }
            case FSTF: {  /* то же, запись float (4 байта); результат — (double)(float)v, как в VM */
                /* адрес снят + результат ПРОКОНВЕРТИРОВАН через float (VM:
                 * c4_push_d((double)f_)). Итог пишется сразу в позицию после снятия
                 * адреса ([esp+4..b]) — top-aligned, как в FST */
                em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x08); /* mov eax,[esp+8] (addr) */
                em_fld_qword_esp(&em);                                          /* fld qword [esp] (v) */
                em_fstp_dword_eax(&em);                                         /* *(float*)addr = (float)v */
                em_fld_dword_eax(&em);                                          /* fld dword [eax] — (double)f */
                em1(&em, 0xDD); em1(&em, 0x5C); em1(&em, 0x24); em1(&em, 0x04); /* fstp qword [esp+4] — новая позиция */
                em1(&em, 0x83); em1(&em, 0xC4); em1(&em, 0x04);                 /* add esp,4 */
                break;
            }
            case FSTK: {                            /* [new(2)][old(2)][addr] → *addr=new; остаётся old */
                /* порядок обязателен: add esp,12 СДВИГАЕТ esp ДО stores — наружу уходят
                 * [old.lo][old.hi] с новой вершины (stores ПОСЛЕ add уходили бы поверх
                 * записанного: [old.hi][addr]). Размер тот же (22 байта) */
                em_fld_qword_esp(&em);                              /* st0 = new */
                em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x10); /* mov eax,[esp+16] (addr) */
                em_fstp_qword_eax(&em);                             /* *addr = new */
                em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x08); /* mov eax,[esp+8] (old.lo) */
                em1(&em, 0x8B); em1(&em, 0x54); em1(&em, 0x24); em1(&em, 0x0C); /* mov edx,[esp+12] (old.hi) */
                em_add_esp_imm8(&em, 12);                           /* esp → новая вершина ДО stores */
                em1(&em, 0x89); em1(&em, 0x04); em1(&em, 0x24);   /* [esp]=old.lo */
                em1(&em, 0x89); em1(&em, 0x54); em1(&em, 0x24); em1(&em, 0x04); /* [esp+4]=old.hi */
                break;
            }
            case FSTKF: {                           /* то же, запись float (4 байта) */
                em_fld_qword_esp(&em);
                em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x10);
                em_fstp_dword_eax(&em);
                em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x08);
                em1(&em, 0x8B); em1(&em, 0x54); em1(&em, 0x24); em1(&em, 0x0C);
                em_add_esp_imm8(&em, 12);           /* add до stores (см. FSTK) */
                em1(&em, 0x89); em1(&em, 0x04); em1(&em, 0x24);
                em1(&em, 0x89); em1(&em, 0x54); em1(&em, 0x24); em1(&em, 0x04);
                break;
            }
            case FADD: case FSUB: case FMUL: case FDIV: {
                /* [right(2)][left(2)] → [left OP right(2)]; -8 байт */
                em1(&em, 0xDD); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 0x08); /* fld qword [esp+8] (left) */
                em_fld_qword_esp(&em);                                             /* fld qword [esp] (right) */
                if (op == FADD) em_faddp(&em);
                else if (op == FSUB) em_fsubp(&em);
                else if (op == FMUL) em_fmulp(&em);
                else em_fdivp(&em);
                em1(&em, 0xDD); em1(&em, 0x5C); em1(&em, 0x24); em1(&em, 0x08);   /* fstp qword [esp+8] */
                em_add_esp_imm8(&em, 8);
                break;
            }
            case FNEG:                              /* смена знака верхнего double */
                em_fld_qword_esp(&em);
                em_fchs(&em);
                em_fstp_qword_esp(&em);
                break;
            /* FEQ/FNE/FLT/FLE/FGT/FGE — таблица g_cmp_ops */
            case ITOF:                               /* pop int → push double */
                em_fild_dword_esp(&em);
                em_add_esp_imm8(&em, 4);
                em1(&em, 0x83); em1(&em, 0xEC); em1(&em, 0x08);
                em_fstp_qword_esp(&em);
                break;
            case UTOF: {
                /* pop unsigned → push double (x87 не умеет fild unsigned:
                 * старший бит установлен — прибавляем 2^32) */
                em_fild_dword_esp(&em);
                em1(&em, 0x8B); em1(&em, 0x04); em1(&em, 0x24);  /* mov eax,[esp] */
                em_add_esp_imm8(&em, 4);
                em1(&em, 0x85); em1(&em, 0xC0);                   /* test eax,eax */
                em1(&em, 0x79); em1(&em, 0x12);                   /* jns +18 → L1 (5+5+3+2+3) */
                em_push_imm32(&em, 0x41F00000u);                  /* hi 2^32 */
                em_push_imm32(&em, 0x00000000u);                  /* lo 2^32: [esp]=lo,[esp+4]=hi */
                em_fld_qword_esp(&em);
                em_faddp(&em);
                em_add_esp_imm8(&em, 8);
                /* L1: */
                em1(&em, 0x83); em1(&em, 0xEC); em1(&em, 0x08);
                em_fstp_qword_esp(&em);
                break;
            }
            case FTOI:                                /* pop double → eax (усечение) */
                em1(&em, 0xF2); em1(&em, 0x0F); em1(&em, 0x2C);   /* cvttsd2si eax, qword [esp] */
                em1(&em, 0x04); em1(&em, 0x24);
                em_add_esp_imm8(&em, 8);
                break;
            case ITOF2: em_itof2(&em); break;                  /* [int][double] → [double][double] (уже ячеечная) */
            case UTOF2: em_utof2(&em); break;
            case FRET:
                /* pop double (результат) → st0 (перенос через leave/ret);
                 * FRD в точке вызова выгрузит его в ячейки. */
                em_fld_qword_esp(&em);
                em_add_esp_imm8(&em, 8);
                em1(&em, 0xC9); em1(&em, 0xC3);   /* leave; ret */
                break;
            case FRD:
                /* результат double-функции (st0 от FRET) → 2 ячейки */
                em1(&em, 0x83); em1(&em, 0xEC); em1(&em, 0x08);
                em_fstp_qword_esp(&em);
                break;
            case SCP: {
                u32 n = (u32)g_bc_pool[bc++];
                em_scp(&em, n);
                break;
            }
            case FABSC:   /* in-place [x(2)] → [|x|(2)] — контракт «float-опкод оставляет результат
             * на стеке 2 ячейками»; FRD после FABSC/SQRTC не эмитится (c4.c: Sys-float),
             * ST0-зависимости нет */
                em_fld_qword_esp(&em);
                em_fabs_(&em);
                em_fstp_qword_esp(&em);
                break;
            case SQRTC:   /* in-place — см. FABSC */
                em_fld_qword_esp(&em);
                em_fsqrt(&em);
                em_fstp_qword_esp(&em);
                break;
            case ADD: em_pop_ecx(&em); em_add_eax_ecx(&em); break;
            case SUB: em_pop_ecx(&em); em_xchg_eax_ecx(&em); em_sub_eax_ecx(&em); break;
            case MUL: em_pop_ecx(&em); em_imul_eax_ecx(&em); break;
            case DIV:
                /* делитель — правый операнд (после xchg в ECX). idiv по нулю — #DE →
                 * паника всей системы; в VM программа завершается ошибкой. Эмитим guard:
                 * нулевой делитель → печать + exit(-1) */
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);          /* eax=делимое, ecx=делитель */
                em_test_ecx_ecx(&em);
                em1(&em, 0x75); em1(&em, 0x05); /* jnz +5 (мимо jmp divzero) */
                {
                    u32 src = em_jmp_rel32(&em);
                    if (g_n_divfix < MAX_DIVFIX) g_divfix[g_n_divfix++] = src;
                    else g_overflow = 1;   /* не молча */
                }
                em_cdq(&em);
                em_idiv_ecx(&em);
                break;
            case MOD:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_test_ecx_ecx(&em);
                em1(&em, 0x75); em1(&em, 0x05);
                {
                    u32 src = em_jmp_rel32(&em);
                    if (g_n_divfix < MAX_DIVFIX) g_divfix[g_n_divfix++] = src;
                    else g_overflow = 1;   /* не молча */
                }
                em_cdq(&em);
                em_idiv_ecx(&em);
                em_mov_eax_edx(&em);
                break;
            case EXIT:
                /* exit(code): unwind на кадр entry с ЛЮБОЙ глубины вызовов (EBX = кадр
                 * entry) и возврат в loader; EAX = код возврата.
                 *   pop eax; (fninit; unlock); mov esp,ebx; mov ebx,[ebx-4]; pop ebp; ret
                 * fninit+unlock — только у float-программ: безлочная x87-мутация
                 * (состояние планировщиком не сохраняется, см. imgsvc.h); unlock
                 * НЕВЗЯТОГО спинлока тихо портит состояние (кража лока у mp3/img) */
                em_pop_eax(&em);
                if (bc_has_float) {
                    em1(&em, 0x50);                        /* push eax (сохранить код) */
                    em_fninit(&em);                       
                    em_call_kapi(&em, KAPI_FPU_UNLOCK);    /* отпустить FPU-лок */
                    em_pop_eax(&em);                       /* 58 — восстановить код */
                }
                em1(&em, 0x89); em1(&em, 0xDC);   /* mov esp, ebx */
                em1(&em, 0x8B); em1(&em, 0x5B); em1(&em, 0xFC); /* mov ebx,[ebx-4] */
                em1(&em, 0x5D);                    /* pop ebp */
                em1(&em, 0xC3);                    /* ret */
                break;
            case OPEN: case READ:
                /* одноячеечные опкоды VM (как PRTF): не съедаем следующую ячейку
                 * (это ADJ!). VM возвращает -1 */
                em_mov_eax_imm32(&em, 0xFFFFFFFFu);
                break;
            case CLOS:
                /* VM: CLOS → a = 0 (паритет close()); xor eax,eax — 2 байта против 5 */
                em_xor_eax_eax(&em);
                break;
            case PRTF: {
                /* printf(fmt, args...) через kapi->c4_printf_va.
                 * В байт-коде PRTF одноячеечный; nargs подсматриваем в
                 * аргументе следующего ADJ (не потребляя).
                 * cdecl: c4_printf_va(fmt, nargs, args_reversed):
                 *   args_reversed[0] = последний аргумент source = [esp]
                 *   fmt (первый аргумент, глубже всех) = [esp+4*(n-1)] */
                u32 nargs = (u32)g_bc_pool[bc + 1];  /* peek, don't consume! */
                /* защитно: парсер всегда кладёт fmt (nargs >= 1), но при nargs==0 imm32
                 * ниже ушёл бы в underflow (8 + 0xFFFFFFFF*4) */
                if (nargs == 0) nargs = 1;
                /* 1. lea eax,[esp] — указатель на аргументы (в ОБРАТНОМ
                 *    порядке, как лежат на стеке c4) */
                em1(&em, 0x8D); em1(&em, 0x04); em1(&em, 0x24);
                /* 2. push args_ptr (аргумент 3) */
                em_push_eax(&em);
                /* 3. push nargs (аргумент 2): imm8 = 2 байта против 5 у imm32
                 *    (nargs — число ячеек printf-вызова, обычно 1..15) */
                if (nargs <= 127) { em1(&em, 0x6A); em1(&em, (u8)nargs); }
                else em_push_imm32(&em, nargs);
                /* 4. mov eax, [esp + 8 + (nargs-1)*4] — fmt (аргумент 1):
                 *    8 байт сверху — только что запушенные args_ptr+nargs;
                 *    disp8-форма (8B 44 24) — 4 байта против 7 у disp32 */
                {
                    u32 d_ = 8u + (nargs - 1u) * 4u;
                    if (d_ <= 127) {
                        em1(&em, 0x8B); em1(&em, 0x44); em1(&em, 0x24);
                        em1(&em, (u8)d_);
                    } else {
                        em1(&em, 0x8B); em1(&em, 0x84); em1(&em, 0x24);
                        em4(&em, d_);
                    }
                }
                /* 5. push fmt */
                em_push_eax(&em);
                /* 6. mov eax, [edi+KAPI_C4_PRINTF_VA]; call eax */
                em_load_kapi(&em, KAPI_C4_PRINTF_VA);
                em1(&em, 0xFF); em1(&em, 0xD0);
                /* 7. снять ТОЛЬКО 3 временных (12 байт) — аргументы снимет следующий
                 * ADJ; результат (число символов) в EAX = "a", не пушим */
                em_add_esp_imm8(&em, 12);
                break;
            }
            case MALC:  emit_syscall(&em, KAPI_MALLOC, 1); break;
            case FREE:  emit_syscall(&em, KAPI_FREE, 1); break;
            case MSET:  emit_syscall(&em, KAPI_MEMSET, 3); break;
            case MCMP:  emit_syscall(&em, KAPI_MEMCMP, 3); break;
            case KINIT: case KQUIT:
                /* a = 0; стек не трогаем (лишний push сдвигал стек); xor eax,eax —
                 * 2 байта против 5 у mov imm32 (флаги между опкодами мертвы) */
                em_xor_eax_eax(&em);
                break;
            case KDELAY:
                /* kdelay(ms): честный sleep через kapi->msleep (task_yield не даёт паузы) */
                emit_syscall(&em, KAPI_MSLEEP, 1);
                break;
            case KFILL:  emit_syscall(&em, KAPI_FB_FILL_RECT, 5); break;
            case KTEXT:  emit_syscall(&em, KAPI_FB_TEXT, 5); break;
            case KFLIP: {
                /* kflip(): перерисовать окно — win_invalidate(win).
                 * Результат: a = 0 (как в VM), БЕЗ пуша. */
                em1(&em, 0x56);   /* push esi (win) */
                em_load_kapi(&em, KAPI_WIN_INVALIDATE);  
                em1(&em, 0xFF); em1(&em, 0xD0);
                em_add_esp_imm8(&em, 4);
                em_xor_eax_eax(&em);   /* xor eax,eax: a = 0 (как в VM) */
                break;
            }
            case KRGB:  emit_syscall(&em, KAPI_FB_RGB, 3); break;
            case KEVENT: emit_syscall(&em, KAPI_C4_EVENT_POLL, 1); break;
            case KCLEAR: emit_syscall(&em, KAPI_FB_FILL_SCREEN, 1); break;
            case KW:    emit_syscall(&em, KAPI_FB_WIDTH, 0); break;
            case KH:    emit_syscall(&em, KAPI_FB_HEIGHT, 0); break;
            case KMTIME:
                /* a = timer_ticks() * 10; без стека */
                emit_syscall(&em, KAPI_TIMER_TICKS, 0);
                em1(&em, 0x6B); em1(&em, 0xC0); em1(&em, 10);  /* imul eax,10 */
                break;
            case STRLEN: emit_syscall(&em, KAPI_STRLEN, 1); break;
            case STRCPY: emit_syscall(&em, KAPI_STRCPY, 2); break;
            case STRCMP: emit_syscall(&em, KAPI_STRCMP, 2); break;
            /* Script GUI API: win_open(title,x,y,w,h) и т.д.
             * Порядок аргументов на стеке c4: sp[0] = последний. */
            case WOPEN:  emit_syscall(&em, KAPI_WIN_OPEN, 5); break;
            case WCLOSE: emit_syscall(&em, KAPI_WIN_CLOSE, 1); break;
            case WALIVE: emit_syscall(&em, KAPI_WIN_ALIVE, 1); break;
            case WCLEAR: emit_syscall(&em, KAPI_WIN_CLEAR, 2); break;
            case WRECT:  emit_syscall(&em, KAPI_WIN_RECT, 6); break;
            case WTEXT:  emit_syscall(&em, KAPI_WIN_TEXT, 5); break;
            case WUPD:   emit_syscall(&em, KAPI_WIN_UPDATE, 1); break;
            case BADD:   emit_syscall(&em, KAPI_BTN_ADD, 6); break;
            case BCLICK: emit_syscall(&em, KAPI_BTN_CLICKED, 1); break;
            case BSETLB: emit_syscall(&em, KAPI_BTN_SET_LABEL, 3); break;
            /* ===== Task 54: SDL2-подмножество (sdl2.c) =====
             * Единая передача: c4_sdl_call(op, args_reversed). Аргументы
             * УЖЕ на нативном стеке ([esp] = последний аргумент вызова —
             * та же раскладка, что у PRTF). Эмитим:
             *   lea eax,[esp]; push eax (args_ptr); push op (imm32);
             *   mov eax,[edi+KAPI_SDL_CALL]; call eax; add esp,8.
             * Оригиналы аргументов снимет следующий ADJ байт-кода. */
            case SDLINIT: case SDLQUIT: case SDLQUITSUB:
            case SDLGETERR: case SDLSETERR: case SDLCLRERR:
            case SDLCREATEWIN: case SDLDESTROYWIN: case SDLGETWINSIZE:
            case SDLSETWINTITLE: case SDLGETWINSURF: case SDLUPDWINSURF:
            case SDLCREATEREND: case SDLDESTROYREND: case SDLSETDRAWCOLOR:
            case SDLGETRENDOUT:
            case SDLRENDCLR: case SDLRENDFILLRECT: case SDLRENDDRAWRECT:
            case SDLRENDDRAWLINE: case SDLRENDDRAWPOINT: case SDLRENDCOPY:
            case SDLRENDPRESENT:
            case SDLCREATETEX: case SDLCREATETEXFS: case SDLDESTROYTEX:
            case SDLUPDTEX: case SDLLOCKTEX: case SDLUNLOCKTEX:
            case SDLCREATERGBSURF: case SDLFREESURF: case SDLLOCKSURF:
            case SDLUNLOCKSURF: case SDLSETCOLORKEY: case SDLBLITSURF:
            case SDLLOADBMP:
            case SDLPOLLEVENT: case SDLWAITEVENT: case SDLWAITEVTO:
            case SDLPUSHEVENT:
            case SDLGETKBSTATE: case SDLGETMOUSESTATE:
            case SDLDELAY: case SDLGETTICKS: case SDLGETPERFCNT:
            case SDLGETPERFFREQ:
            case SDLRUNAPP: {
                em1(&em, 0x8D); em1(&em, 0x04); em1(&em, 0x24);  /* lea eax,[esp] */
                em_push_eax(&em);                                /* push args_ptr */
                em_push_imm32(&em, (u32)(op - SDLINIT));         /* push op */
                em_load_kapi(&em, KAPI_SDL_CALL);
                em1(&em, 0xFF); em1(&em, 0xD0);                  /* call eax */
                em_add_esp_imm8(&em, 8);                         /* op + args_ptr */
                break;
            }
            default:
                /* Неизвестный опкод — падаем на месте, а не эмитим nop
                 * (тихое расхождение с VM хуже явной ошибки). */
                set_diag(diag, diag_max, "c4_x86: unknown opcode in bytecode");
                free(scratch_base);   /* пулы — в куче */
                s_unlock(&c4_codegen_lock);
                return -1;
        }
        if (em.of) {
            set_diag(diag, diag_max, "c4_x86: output buffer overflow");
            free(scratch_base);
            s_unlock(&c4_codegen_lock);
            return -1;
        }
    }

    /* эпилог деления на ноль: печать "divide by zero\n" через
     * kapi->c4_print_str (строка встроена в код — адрес получаем трюком
     * call $+5/pop) и exit(-1): unwind в loader. Кадр: EBX (entry) жив —
     * его не трогаем до самого выхода. Смещение строки до "pop eax"
     * ПАТЧИТСЯ (жёсткая константа ломалась бы при изменении раскладки стаба) */
    if (g_n_divfix > 0) {
        u32 divzero_pos = em.pos;
        em1(&em, 0xE8); em4(&em, 0);            /* call $+5 */
        u32 dz_pop_pos = em.pos;                 /* адрес pop eax (его кладёт call) */
        em1(&em, 0x58);                          /* pop eax (адрес pop) */
        u32 dz_add_pos = em.pos;
        em1(&em, 0x05);
        em4(&em, 0);                             /* add eax, imm32 (патчим ниже) */
        em1(&em, 0x6A); em1(&em, 15);            /* push 15 (len) */
        em1(&em, 0x50);                          /* push eax (строка) */
        em1(&em, 0x8B); em1(&em, 0x47); em1(&em, (u8)KAPI_C4_PRINT_STR);
        em1(&em, 0xFF); em1(&em, 0xD0);          /* call c4_print_str */
        em_add_esp_imm8(&em, 8);
        em_mov_eax_imm32(&em, 0xFFFFFFFFu);      /* eax = -1 (код выхода) */
        em1(&em, 0x50);                          /* push eax — сохранить код */
        /* fninit/unlock — только у float-программ (см. кейс EXIT) */
        if (bc_has_float) {
            em_fninit(&em);                      /* x87 — чистый */
            em_call_kapi(&em, KAPI_FPU_UNLOCK);
        }
        em_pop_eax(&em);
        em1(&em, 0x89); em1(&em, 0xDC);          /* mov esp, ebx */
        em1(&em, 0x8B); em1(&em, 0x5B); em1(&em, 0xFC); /* mov ebx,[ebx-4] */
        em1(&em, 0x5D);                          /* pop ebp */
        em1(&em, 0xC3);                          /* ret */
        u32 dz_str_pos = em.pos;
        /* строка "divide by zero\n" */
        {
            static const char dz[] = "divide by zero\n";
            for (int i = 0; dz[i]; i++) em1(&em, (u8)dz[i]);
        }
        /* патч add eax, imm32: от адреса pop-инструкции до строки */
        {
            i32 d = (i32)dz_str_pos - (i32)dz_pop_pos;
            em.buf[dz_add_pos + 1] = (u8)(d & 0xFF);
            em.buf[dz_add_pos + 2] = (u8)((d >> 8) & 0xFF);
            em.buf[dz_add_pos + 3] = (u8)((d >> 16) & 0xFF);
            em.buf[dz_add_pos + 4] = (u8)((d >> 24) & 0xFF);
        }
        /* патчим все jmp divzero */
        for (int i = 0; i < g_n_divfix; i++) {
            u32 src = g_divfix[i];
            if (src + 4 > em.cap) continue;
            i32 rel = (i32)divzero_pos - (i32)(src + 4);
            em.buf[src]   = (u8)(rel & 0xFF);
            em.buf[src+1] = (u8)((rel >> 8) & 0xFF);
            em.buf[src+2] = (u8)((rel >> 16) & 0xFF);
            em.buf[src+3] = (u8)((rel >> 24) & 0xFF);
        }
    }

    /* Patch entry stub call → main_offset */
    u32 main_x86 = bc_to_x86(entry_cells);
    if (main_x86 == 0xFFFFFFFFu) {
        set_diag(diag, diag_max, "c4_x86: main offset not found in map");
        free(scratch_base);
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    if (main_x86 >= entry_call_offset + 4) {
        i32 rel = (i32)main_x86 - (i32)(entry_call_offset + 4);
        em.buf[entry_call_offset]   = (u8)(rel & 0xFF);
        em.buf[entry_call_offset+1] = (u8)((rel >> 8) & 0xFF);
        em.buf[entry_call_offset+2] = (u8)((rel >> 16) & 0xFF);
        em.buf[entry_call_offset+3] = (u8)((rel >> 24) & 0xFF);
    } else {
        set_diag(diag, diag_max, "c4_x86: bad main offset");
        free(scratch_base);
        s_unlock(&c4_codegen_lock);
        return -1;
    }

    /* Patch all relocations */
    for (int i = 0; i < g_n_relocs; i++) {
        u32 target_x86 = bc_to_x86(g_relocs[i].target_bc_cell);
        if (target_x86 == 0xFFFFFFFFu) continue;
        u32 src = g_relocs[i].src_x86_offset;
        if (src + 4 > em.cap) continue;
        i32 rel = (i32)target_x86 - (i32)(src + 4);
        em.buf[src]   = (u8)(rel & 0xFF);
        em.buf[src+1] = (u8)((rel >> 8) & 0xFF);
        em.buf[src+2] = (u8)((rel >> 16) & 0xFF);
        em.buf[src+3] = (u8)((rel >> 24) & 0xFF);
    }

    /* Patch TEXT-адресов функций (3.3): eax = pop_pos; rel = target - pop_pos */
    for (int i = 0; i < g_n_textfix; i++) {
        u32 target_x86 = bc_to_x86(bc_norm_target(g_textfix[i].bc_target));
        u32 rel_pos = g_textfix[i].rel_pos;
        u32 pop_pos = g_textfix[i].pop_pos;
        if (target_x86 == 0xFFFFFFFFu || rel_pos + 4 > em.cap) continue;
        i32 rel = (i32)target_x86 - (i32)pop_pos;
        em.buf[rel_pos]     = (u8)(rel & 0xFF);
        em.buf[rel_pos + 1] = (u8)((rel >> 8) & 0xFF);
        em.buf[rel_pos + 2] = (u8)((rel >> 16) & 0xFF);
        em.buf[rel_pos + 3] = (u8)((rel >> 24) & 0xFF);
    }

    if (em.of) {
        set_diag(diag, diag_max, "c4_x86: output buffer overflow");
        free(scratch_base);
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    /* переполнение любой таблицы (карта/релокации/textfix/divfix/
     * data-relocs) — ошибка компиляции: дропнутая релокация оставляла бы
     * rel32 = 0 → прыжок по мусору */
    if (g_overflow) {
        set_diag(diag, diag_max, "c4_x86: codegen table overflow");
        free(scratch_base);
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    if (out_size) *out_size = em.pos;

    /* Копия сегмента данных и reloc-списка — вызывающий (c4_compile_to_file)
     * кладёт их в C4N1-контейнер. */
    extern u8  c4_x86_data_out[65536];
    extern u32 c4_x86_data_out_len;
    extern u32 c4_x86_data_relocs_out[8192];
    extern int  c4_x86_n_data_relocs_out;
    c4_x86_data_out_len = 0;
    if (data_len > sizeof(c4_x86_data_out)) data_len = sizeof(c4_x86_data_out);
    if (data_len) memcpy(c4_x86_data_out, g_data_pool, data_len);
    c4_x86_data_out_len = data_len;
    c4_x86_n_data_relocs_out = g_n_data_relocs;
    for (int i = 0; i < g_n_data_relocs; i++)
        c4_x86_data_relocs_out[i] = g_data_relocs[i];

    free(scratch_base);   /* scratch-блок освобождён */
    s_unlock(&c4_codegen_lock);
    return 0;
}

/* Выходные данные последней компиляции (сегмент данных + релокации).
 * Заполняются под c4_codegen_lock — читать сразу после успешного
 * c4_compile_to_native. */
u8  c4_x86_data_out[65536];
u32 c4_x86_data_out_len = 0;
u32 c4_x86_data_relocs_out[8192];
int c4_x86_n_data_relocs_out = 0;

/* ---------- сохранение в RAMFS (формат C4N1) ---------- */
int c4_compile_to_file(const char *source_name, const char *src,
                      char *out, u32 out_max)
{
    /* буфер в куче — две одновременные компиляции не калечат друг друга */
    u8 *out_buf = (u8 *)malloc(256 * 1024);
    u32 out_size = 0;
    if (!out_buf) {
        set_diag(out, out_max, "c4: no memory for codegen buffer");
        return -1;
    }
    if (c4_compile_to_native(src, out, out_max, out_buf, 256 * 1024, &out_size) != 0) {
        free(out_buf);
        return -1;
    }
    if (out_size == 0) {
        free(out_buf);
        set_diag(out, out_max, "c4: compiled output is empty");
        return -1;
    }

    extern u8  c4_x86_data_out[65536];
    extern u32 c4_x86_data_out_len;
    extern u32 c4_x86_data_relocs_out[8192];
    extern int  c4_x86_n_data_relocs_out;
    u32 data_len = c4_x86_data_out_len;
    u32 n_rel = (u32)c4_x86_n_data_relocs_out;
    if (n_rel > 8192) n_rel = 8192;

    /* C4N1: magic | code_size | data_size | n_relocs | code | data | relocs */
    u32 total = 16 + out_size + data_len + n_rel * 4;
    u8 *bin = (u8 *)malloc(total);
    if (!bin) {
        free(out_buf);
        set_diag(out, out_max, "c4: no memory for binary image");
        return -1;
    }
    bin[0] = 'C'; bin[1] = '4'; bin[2] = 'N'; bin[3] = '1';
    bin[4] = (u8)(out_size & 0xFF);         bin[5]  = (u8)((out_size >> 8) & 0xFF);
    bin[6] = (u8)((out_size >> 16) & 0xFF); bin[7]  = (u8)((out_size >> 24) & 0xFF);
    bin[8] = (u8)(data_len & 0xFF);         bin[9]  = (u8)((data_len >> 8) & 0xFF);
    bin[10] = (u8)((data_len >> 16) & 0xFF); bin[11] = (u8)((data_len >> 24) & 0xFF);
    bin[12] = (u8)(n_rel & 0xFF);           bin[13] = (u8)((n_rel >> 8) & 0xFF);
    bin[14] = (u8)((n_rel >> 16) & 0xFF);   bin[15] = (u8)((n_rel >> 24) & 0xFF);
    memcpy(bin + 16, out_buf, out_size);
    if (data_len) memcpy(bin + 16 + out_size, c4_x86_data_out, data_len);
    for (u32 i = 0; i < n_rel; i++) {
        u32 v = c4_x86_data_relocs_out[i];
        u8 *p = bin + 16 + out_size + data_len + i * 4;
        p[0] = (u8)(v & 0xFF); p[1] = (u8)((v >> 8) & 0xFF);
        p[2] = (u8)((v >> 16) & 0xFF); p[3] = (u8)((v >> 24) & 0xFF);
    }
    free(out_buf);

    char bin_name[64];
    {
        const char *base = source_name;
        for (const char *p = source_name; *p; p++) {
            if (*p == '/' || *p == '\\') base = p + 1;
        }
        u32 i = 0;
        while (base[i] && base[i] != '.' && i < sizeof(bin_name) - 5) {
            bin_name[i] = base[i];
            i++;
        }
        bin_name[i] = '.'; bin_name[i+1] = 'b'; bin_name[i+2] = 'i';
        bin_name[i+3] = 'n'; bin_name[i+4] = 0;
    }

    if (!ramfs_ready()) {
        free(bin);
        set_diag(out, out_max, "RAMFS not ready");
        return -1;
    }

    ramfs_delete(bin_name);
    if (!ramfs_create(bin_name, total)) {
        free(bin);
        set_diag(out, out_max, "ramfs_create failed");
        return -1;
    }
    if (!ramfs_write(bin_name, bin, total)) {
        free(bin);
        set_diag(out, out_max, "ramfs_write failed");
        return -1;
    }
    free(bin);

    if (out && out_max) {
        char msg[96];
#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
        extern int snprintf(char *out, mq_size_t n, const char *fmt, ...);
#else
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
#endif
        snprintf(msg, sizeof(msg),
                 "[c4] native binary saved: %s (code %u + data %u + %u relocs)",
                 bin_name, (unsigned)out_size, (unsigned)data_len, (unsigned)n_rel);
        u32 L = (u32)strlen(msg);
        if (L >= out_max) L = out_max - 1;
        memcpy(out, msg, L);
        out[L] = 0;
    }
    (void)serial_puts;
    return 0;
}

/* ---------- запуск native c4-бинарника через loader ---------- */
int c4_load_and_run(const char *bin_name, void *win)
{
    return loader_spawn(bin_name, (struct window *)win);
}
