/* apps.c — реестр приложений + «О программе», «Терминал», «Системная информация» */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "gfx2d.h"   /* СЕССИЯ 85: GPU в системной информации */
#include "mem.h"
#include "timer.h"
#include "string.h"
#include "mouse.h"
#include "kernel.h"
#include "utf8.h"
#include "ramfs.h"
#include "mqjs_os.h"   /* QuickJS: REPL и запуск .js (замена CMScript) */
#include "task.h"
#include "mouse.h"
#include "sound.h"
extern void serial_puts(const char *s);

#include "loader.h"
#include "usb.h"
#include "usb_ehci.h"
#include "e1000.h"
#include "net.h"
#include "ne2000.h"
#include "timer.h"
#include "c4.h"
#include "c4gfx.h"
#include "ath9k_wifi.h"
#include "wpa2.h"
#include "hwinfo.h"  /* сессия 90: hwdet-подобная диагностика ACPI/DSDT/SMBIOS/CPU */
#include "apipc.h"   /* SMP-rework: ap_syscall_do (тест mailbox/IPI) */
#include "smp.h"     /* SMP-rework: smp_current_cpu */
#include "ata.h"
#include "ahci.h"
#include "disk.h"
#include "iso9660.h"
#include "fat32.h"
#include "ntfs.h"
#include "smp.h"
#include <cpuid.h>   /* GCC/MinGW: встроенные обёртки над инструкцией CPUID */

/* ------------------------------ реестр ------------------------------ */
const app_def_t app_table[] = {
    { "О программе",            app_about_open   },
    { "Файлы",                  app_files_open   },
    { "Терминал",               app_term_open    },
    { "Редактор C",             app_editor_open  },
    { "QuickJS",                app_quickjs_open },
    { "Диспетчер задач",        app_taskmgr_open },
    { "WiFi Scanner",           app_wifi_open     },
    { "Браузер",                app_browser_open  },
    { "HTTP Trace",             app_nettrace_open },
    { "Системная информация",   app_sysinfo_open },
    { "Настройки",              app_settings_open },
    { "MP3 плеер",              app_mp3_open      },   /* сессия 60 */
    { "Просмотр",               app_imgview_open  },   /* сессия 60 */
    { "Игры",                   app_games_open    },
};
const int app_table_count = (int)(sizeof(app_table) / sizeof(app_table[0]));

void apps_open(int idx)
{
    if (idx >= 0 && idx < app_table_count)
        apps_launch(app_table[idx].open_fn);
}

/* Сессия 22 (запрос пользователя): «на системах с небольшим количеством
 * оперативной памяти, когда памяти не хватает на запуск приложения, оно
 * просто молча не запускается — добавь окно с информацией».
 *
 * Все ЗАПУСКИ приложений идут через apps_launch: если после open_fn()
 * ни одного нового окна не появилось — выделить память не удалось
 * (или превышен лимит окон) и мы показываем окно-сообщение вместо
 * молчания. Внутри самого open_fn свои отказы (если вдруг будут) уже
 * сообщает wm_oom_report из win_create, а повтор тут гасится кулдауном. */
void apps_launch(void (*fn)(void))
{
    if (!fn) return;
    int before = wm_window_count();
    fn();
    if (wm_window_count() == before)
        wm_oom_report(-1);
}

/* Запустить приложение по имени */
int app_spawn_by_name(const char *name)
{
    if (!name || !*name) return 0;
    for (int i = 0; i < app_table_count; i++) {
        if (strcmp(app_table[i].name, name) == 0) {
            apps_launch(app_table[i].open_fn);
            return 1;
        }
    }
    /* Пробуем по английским именам */
    if (!strcmp(name, "terminal") || !strcmp(name, "term")) {
        apps_launch(app_term_open); return 1;
    }
    if (!strcmp(name, "files") || !strcmp(name, "fileman")) {
        apps_launch(app_files_open); return 1;
    }
    if (!strcmp(name, "editor")) {
        apps_launch(app_editor_open); return 1;
    }
    if (!strcmp(name, "browser")) {
        apps_launch(app_browser_open); return 1;
    }
    if (!strcmp(name, "nettrace") || !strcmp(name, "trace") ||
        !strcmp(name, "httptrace")) {
        apps_launch(app_nettrace_open); return 1;
    }
    if (!strcmp(name, "sysinfo")) {
        apps_launch(app_sysinfo_open); return 1;
    }
    if (!strcmp(name, "taskmgr")) {
        apps_launch(app_taskmgr_open); return 1;
    }
    /* Task 54: help терминала обещает «player» — добавили имя (и «mp3») */
    if (!strcmp(name, "player") || !strcmp(name, "mp3")) {
        app_mp3_open();
        return 1;
    }
    if (!strcmp(name, "settings") || !strcmp(name, "настройки")) {
        apps_launch(app_settings_open); return 1;
    }
    if (!strcmp(name, "games") || !strcmp(name, "игры")) {
        apps_launch(app_games_open); return 1;
    }
    if (!strcmp(name, "mines") || !strcmp(name, "minesweeper") ||
        !strcmp(name, "сапер") || !strcmp(name, "сапёр")) {
        apps_launch(app_mines_open); return 1;
    }
    return 0;
}

/* --------------------------- CPU (CPUID) --------------------------- */
void cpu_get_vendor(char out[16])
{
    unsigned a, b, c, d;
    if (!__get_cpuid(0, &a, &b, &c, &d)) { strcpy(out, "-"); return; }
    memcpy(out, &b, 4);
    memcpy(out + 4, &d, 4);
    memcpy(out + 8, &c, 4);
    out[12] = 0;
}

void cpu_get_brand(char out[52])
{
    unsigned a, b, c, d;
    char *p = out;
    unsigned max_ext = 0;
    if (__get_cpuid(0x80000000,  &a,  &b,  &c,  &d)) max_ext = a;
    if (max_ext  >= 0x80000004) {
        for (unsigned leaf = 0x80000002; leaf  <= 0x80000004; leaf++) {
            __get_cpuid(leaf,  &a,  &b,  &c,  &d);
            memcpy(p,  &a, 4); memcpy(p + 4,  &b, 4);
            memcpy(p + 8,  &c, 4); memcpy(p + 12,  &d, 4);
            p += 16;
        }
        *p = 0;
        /*  обрезаем ведущие пробелы */
        char *s = out;
        while (*s == ' ') s++;
        if (s != out) memmove(out, s, strlen(s) + 1);
        return;
    }
    strcpy(out,  "неизвестный процессор ");
}

int cpu_get_cores(void)
{
    unsigned a, b, c, d;
    if (__get_cpuid(1, &a, &b, &c, &d)) return (int)((b >> 16) & 0xFF);
    return 1;
}

/* ============================== О ПРОГРАММЕ ============================== */
typedef struct {
    char cpu[52];
} about_data_t;

static void about_draw(window_t *w)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    (void)cw; (void)ch;
    fb_fill_rect(0, 0, win_content_w(w), win_content_h(w), fb_rgb(0x12, 0x15, 0x1A));
    fb_fill_rect(0, 0, win_content_w(w), 3, fb_rgb(0x3E, 0x7D, 0xBF));

    const char *name = "N2600-OS";
    int nx = (win_content_w(w) - (int)strlen(name) * 16) / 2;
    u32 c = wm_theme_accent();
    for (const char *p = name; *p; p++, nx += 16)
        fb_char2x(nx, 18, (unsigned char)*p, c);

    fb_text(16, 64, "Простая оконная ОС на чистом C", wm_theme_text(), -1);
    fb_text(16, 84, "Сборка: MinGW (i686), multiboot + GRUB", wm_theme_text_dim(), -1);
    fb_text(16, 104, "Цель: Intel Atom N2600, VESA 1280x600x32", wm_theme_text_dim(), -1);

    about_data_t *d = (about_data_t *)w->data;
    char line[64];
    snprintf(line, sizeof(line), "CPU: %s", d->cpu);
    fb_text(16, 132, line, wm_theme_text_dim(), -1);

    fb_text(16, win_content_h(w) - 24, "Лицензия: MIT, 2026", fb_rgb(0x50, 0x58, 0x62), -1);
}

void app_about_open(void)
{
    about_data_t *d = (about_data_t *)malloc(sizeof(about_data_t));
    if (!d) return;
    cpu_get_brand(d->cpu);
    u32 W = fb_width();
    int ww = 360, wh = 200;
    win_create("О программе", (int)W - ww - 40, 40, ww, wh,
               about_draw, NULL, NULL, NULL, NULL, d);
}
