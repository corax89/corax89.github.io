/* cpu.h — CPUID-диспетчер N2600-OS (трёхуровневый SIMD-план).
 *
 * Уровни (флаги читаются CPUID.1:EDX):
 *   0 — нет SSE  (Pentium MMX, K6-2): скалярные циклы + rep stosl, как раньше;
 *   1 — SSE      (Pentium II/III): fxsave/fxrstor в планировщике, копии через
 *                  movups/movaps (заполняется по потребности);
 *   2 — SSE2+    (Pentium 4, Core, Atom N2600): movdqa/movntdq в fb.c —
 *                  в т.ч. movntdq в write-combining LFB (mtrr_lfb_wc).
 *
 * Compile-time baseline (-mno-sse -mno-sse2 -mno-mmx ... в build.sh/build.bat)
 * гарантирует, что компилятор НЕ вставит SIMD-инструкции в произвольную
 * функцию (иначе первый же тик таймера терял бы xmm без FXSAVE — и сломал бы
 * старые CPU с #UD). SIMD живёт ТОЛЬКО в функциях с
 * __attribute__((target("sse2"))) (fb.c) и в явно выписанном inline-asm
 * (task.c: fxsave/fxrstor). Состояние xmm/x87 между задачами сохраняет
 * планировщик (task.c), CR4.OSFXSR на каждом ядре ставит cpu_fpu_enable().
 */
#ifndef CPU_H
#define CPU_H

#include "types.h"

/* Заполняются cpu_detect() на BSP до fb_init/task_init. AP-ядра той же
 * машины — то же семейство, флаги глобальные (детект на AP не повторяется). */
extern int cpu_has_fpu;    /* x87 FPU            (CPUID.1:EDX[0])  */
extern int cpu_has_fxsr;   /* fxsave/fxrstor     (CPUID.1:EDX[24]) */
extern int cpu_has_sse;    /* SSE  — уровень 1   (CPUID.1:EDX[25]) */
extern int cpu_has_sse2;   /* SSE2 — уровень 2   (CPUID.1:EDX[26]) */

/* Детект + включение на BSP + захват дефолтного FPU-состояния.
 * Вызывать в kmain ДО fb_init (fb.c читает cpu_has_sse2 при первом flush). */
void cpu_detect(void);

/* Включить FPU/SSE на ТЕКУЩЕМ ядре: CR0.EM/TS=0, MP/ET=1; при fxsr —
 * CR4.OSFXSR|OSXMMEXCPT=1. CR4/CR0 per-CPU: BSP вызывает из cpu_detect(),
 * каждое AP — из smp_ap_main() (после INIT у AP CR4 сброшен: без этого
 * fxsave не сохранял бы XMM, а SSE2-инструкции дали бы #UD). */
void cpu_fpu_enable(void);

/* Дефолтное FPU-состояние (fninit + MXCSR=0x1F80), захвачено cpu_detect.
 * Задача, ещё ни разу не исполнявшаяся, получает его ПЕРЕД первым
 * fxrstor/frstor (иначе fxrstor прочитал бы нули: MXCSR=0 невалиден). */
void cpu_fpu_default_get(u8 *dst512);
int  cpu_fpu_default_ready(void);

#endif /* CPU_H */
