/* flacsvc.c — сервис FLAC-декодирования (реализация, Task 46).
 *
 * Единственная единица трансляции с libfoxenflac (foxen-flac.c).
 * Конфигурация под freestanding-ядро:
 *   - буфер декодера — куча ядра (fx_flac_size(max_block, chans) байт);
 *   - libfoxenflac сам ничего не выделяет и не зовёт libc — только
 *     ассерты, отключённые в вендор-копии (freestanding);
 *   - декодер целочисленный, FPU не нужен (в отличие от dr_mp3),
 *     FPU-лок imgsvc не берётся.
 *
 * Формат вывода libfoxenflac: interleaved int32, сэмпл прижат К
 * СТАРШИМ битам (32-bit, left-justified; см. финальный сдвиг
 * «32 - sample_size» в foxen-flac.c). Здесь он конвертируется в
 * s16: raw = s >> (32-bps); s16 = нормализация к 16 битам.
 *
 * STREAMINFO разбирается вручную ДО создания декодера: из него
 * берутся частота/каналы/битность/длительность и максимальный блок
 * (размер буфера декодера). Это точные данные спецификации FLAC
 * (блок STREAMINFO всегда первый, 34 байта). */
#include "flacsvc.h"
#include "mem.h"
#include "string.h"
#include "foxen-flac.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

/* Лимиты поддержки: стерео/моно и блок не больше 16384 (FLAC Subset
 * разрешает 4608 при <=48 кГц и 16384 выше; блоки 65535 — редчайший
 * случай, честно отказываем). Буфер декодера при 16384x2 — ~143 КиБ. */
#define FLACSVC_MAX_BLOCK 16384u
#define FLACSVC_MAX_CHAN  2u

typedef struct {
    const u8   *file;          /* весь файл (владелец — плеер) */
    u32         file_len;
    u32         file_pos;      /* сколько байт уже скормлено декодеру */
    fx_flac_t  *dec;            /* декодер (внутри dec_buf) */
    void       *dec_buf;        /* malloc под fx_flac_size(...) */
    i32        *i32buf;         /* staging: interleaved int32 одного кадра */
    u32         i32_cap;       /* сэмплов в i32buf (max_block*chans) */
    u32         i32_pos;       /* прочитано сэмплов из i32buf */
    u32         i32_len;       /* валидно сэмплов в i32buf */
    u32         chan;
    u32         rate;
    u32         bps;
    u64         total_frames;  /* из STREAMINFO */
    u8          eof;           /* поток доигран */
    u8          err;
} flac_ctx_t;

/* ---------------- ошибки ---------------- */

static char g_flac_err[96] = "";

static void flac__seterr(const char *msg)
{
    if (msg) {
        strncpy(g_flac_err, msg, sizeof(g_flac_err) - 1);
        g_flac_err[sizeof(g_flac_err) - 1] = 0;
    }
}

const char *flac_errstr(void) { return g_flac_err; }

/* ---------------- STREAMINFO (ручной разбор) ---------------- */

/* Разобрать заголовок STREAMINFO: magic "fLaC" + первый блок метаданных.
 * off — смещение данных STREAMINFO внутри файла. 1 = успех. */
static int flac__parse_streaminfo(const u8 *p, u32 len, u32 off,
                                  u32 *rate, u32 *chans, u32 *bps,
                                  u64 *total, u32 *max_block)
{
    if (off + 4 + 34 > len) return 0;         /* блок STREAMINFO = 34 байта */
    const u8 *b = p + off;
    u32 mb = ((u32)b[2] << 8) | b[3];         /* max block size */
    u32 r  = ((u32)b[10] << 12) | ((u32)b[11] << 4) | (b[12] >> 4);
    u32 c  = (u32)((b[12] >> 1) & 7) + 1;
    u32 w  = (((u32)(b[12] & 1) << 4) | (b[13] >> 4)) + 1;
    u64 n  = ((u64)(b[13] & 0x0F) << 32) | ((u64)b[14] << 24) |
             ((u64)b[15] << 16) | ((u64)b[16] << 8) | (u64)b[17];
    if (!r || !c || !w || c > 8) return 0;    /* мусор */
    if (w < 4 || w > 32) return 0;
    *rate = r; *chans = c; *bps = w; *total = n; *max_block = mb;
    return 1;
}

/* ---------------- API ---------------- */

void *flac_open_mem(const void *data, u32 len)
{
    if (!data || len < 42) { flac__seterr("нет данных"); return NULL; }
    if (len > 512u * 1024u * 1024u) { flac__seterr("файл слишком велик"); return NULL; }
    const u8 *p = (const u8 *)data;
    if (p[0] != 'f' || p[1] != 'L' || p[2] != 'a' || p[3] != 'C') {
        flac__seterr("не FLAC (нет magic fLaC)");
        return NULL;
    }
    /* первый блок метаданных обязан быть STREAMINFO (type 0) */
    if ((p[4] & 0x7F) != 0) { flac__seterr("STREAMINFO не первый блок"); return NULL; }

    u32 rate = 0, chans = 0, bps = 0, max_block = 0;
    u64 total = 0;
    if (!flac__parse_streaminfo(p, len, 8, &rate, &chans, &bps, &total, &max_block)) {
        flac__seterr("битый STREAMINFO");
        return NULL;
    }
    if (chans > FLACSVC_MAX_CHAN) {
        flac__seterr("только моно/стерео FLAC");
        return NULL;
    }
    if (max_block > FLACSVC_MAX_BLOCK) {
        /* практические файлы (flac -8, CD-рипы) укладываются в 4608;
         * кадр больше лимита — честная ошибка декодера */
        flac__seterr("block size > 16384 не поддержан");
        return NULL;
    }

    flac_ctx_t *c = (flac_ctx_t *)malloc(sizeof(flac_ctx_t));
    if (!c) { flac__seterr("нет памяти (ctx)"); return NULL; }
    memset(c, 0, sizeof(*c));

    u32 dsize = fx_flac_size(max_block, (u8)chans);
    if (!dsize) { free(c); flac__seterr("fx_flac_size=0"); return NULL; }
    c->dec_buf = malloc(dsize);
    c->i32_cap = max_block * chans;
    c->i32buf  = (i32 *)malloc(c->i32_cap * sizeof(i32));
    if (!c->dec_buf || !c->i32buf) {
        if (c->dec_buf) free(c->dec_buf);
        if (c->i32buf) free(c->i32buf);
        free(c);
        flac__seterr("нет памяти (декодер)");
        return NULL;
    }
    memset(c->dec_buf, 0, dsize);   /* выравнивание внутри делает fx_flac_init */

    c->file = p;
    c->file_len = len;
    c->file_pos = 0;
    c->chan = chans;
    c->rate = rate;
    c->bps = bps;
    c->total_frames = total;
    c->dec = fx_flac_init(c->dec_buf, (u16)max_block, (u8)chans);
    if (!c->dec) {
        free(c->dec_buf); free(c->i32buf); free(c);
        flac__seterr("fx_flac_init не удался");
        return NULL;
    }
    g_flac_err[0] = 0;
    return c;
}

void flac_close(void *ctx)
{
    flac_ctx_t *c = (flac_ctx_t *)ctx;
    if (!c) return;
    if (c->dec_buf) free(c->dec_buf);
    if (c->i32buf) free(c->i32buf);
    free(c);
}

u32 flac_channels(const void *ctx)
{
    const flac_ctx_t *c = (const flac_ctx_t *)ctx;
    return c ? c->chan : 0;
}

u32 flac_rate(const void *ctx)
{
    const flac_ctx_t *c = (const flac_ctx_t *)ctx;
    return c ? c->rate : 0;
}

u32 flac_bps(const void *ctx)
{
    const flac_ctx_t *c = (const flac_ctx_t *)ctx;
    return c ? c->bps : 0;
}

u64 flac_total_frames(const void *ctx)
{
    const flac_ctx_t *c = (const flac_ctx_t *)ctx;
    return c ? c->total_frames : 0;
}

int flac_rewind(void *ctx)
{
    flac_ctx_t *c = (flac_ctx_t *)ctx;
    if (!c || !c->dec) return 0;
    fx_flac_reset(c->dec);       /* декодер в FLAC_INIT */
    c->file_pos = 0;             /* поток скормим заново */
    c->i32_pos = 0;
    c->i32_len = 0;
    c->eof = 0;
    c->err = 0;
    g_flac_err[0] = 0;
    return 1;
}

/* Переложить из staging в pcm с нормализацией битности.
 * n_smps — число int32-сэмплов (кратно каналам не обязано быть). */
static u32 flac__drain(flac_ctx_t *c, i16 *pcm, u32 frames)
{
    u32 avail = c->i32_len - c->i32_pos;
    u32 want = frames * c->chan;
    u32 n = (avail < want) ? avail : want;
    /* нормализация: сэмпл прижат к старшим битам (left-justified) */
    u32 down = 32u - c->bps;          /* сначала снять старший сдвиг */
    if (c->bps > 16) down += (c->bps - 16);   /* лишняя точность — долой */
    u32 up = (c->bps < 16) ? (16u - c->bps) : 0;  /* 8/12 бит — растянуть */
    const i32 *s = c->i32buf + c->i32_pos;
    for (u32 i = 0; i < n; i++) {
        i32 v = s[i];
        if (up) v = (i32)((u32)v << up);
        i16 o = (i16)(v >> down);
        pcm[i] = o;
    }
    c->i32_pos += n;
    return n / c->chan;
}

u32 flac_read_s16(void *ctx, i16 *pcm, u32 frames)
{
    flac_ctx_t *c = (flac_ctx_t *)ctx;
    if (!c || !pcm || frames == 0) return 0;
    if (c->err) return 0;

    u32 got = 0;
    u32 guard = 0;                    /* защита от вечного цикла */
    while (got < frames) {
        /* 1) staging не пуст — сначала выгружаем его */
        if (c->i32_pos < c->i32_len) {
            got += flac__drain(c, pcm + got * c->chan, frames - got);
            continue;
        }
        if (c->eof || c->err) break;

        /* 2) прогон декодера: кусок входа -> staging */
        u32 in_len = c->file_len - c->file_pos;
        u32 out_cap = c->i32_cap;
        c->i32_pos = 0;
        c->i32_len = 0;
        u32 pos_before = c->file_pos;
        fx_flac_state_t st = fx_flac_process(c->dec,
                                             c->file + c->file_pos, &in_len,
                                             c->i32buf, &out_cap);
        c->file_pos += in_len;
        c->i32_len = out_cap;

        if (st == FLAC_ERR) {
            c->err = 1;
            flac__seterr("декодер сообщил об ошибке потока");
            break;
        }
        /* Конца потока как отдельного состояния в libfoxenflac нет:
         * конец = нет ни выданных сэмплов, ни потреблённого входа,
         * при исчерпанном файле (обработчик состояния вернул false). */
        if (out_cap == 0 && c->file_pos == pos_before &&
            c->file_pos >= c->file_len) {
            c->eof = 1;
            break;
        }
        if (++guard > 1000000u) {     /* страховка: не крутимся вечно */
            c->err = 1;
            flac__seterr("декодер зациклился");
            break;
        }
    }
    return got;
}
