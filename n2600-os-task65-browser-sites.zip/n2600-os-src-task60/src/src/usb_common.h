/* usb_common.h — общий протокольный слой USB (Task 49).
 *
 * ДО: дескрипторы (device/config/iface/endpoint) и usb_request_t были
 * продублированы в usb.c (UHCI) и usb_ehci.c (EHCI) — при расхождении
 * копий (правка одной) парсер второго хоста молча читал мусор, а
 * значения стандартных запросов (bRequest/wValue/wIndex) жили в 8+
 * местах. Транспорты у хостов РАЗНЫЕ (у UHCI — low_speed и max_pkt,
 * у EHCI — qTD-цепочки), поэтому переносимы НЕ функции отправки, а
 * СТРУКТУРЫ и БИЛДЕРЫ запросов: заполнение usb_request_t — единое,
 * отправка — у каждого хоста своя (тонкая, 3-4 строки).
 *
 * Header-only: структуры POD, билдеры static inline. */
#ifndef USB_COMMON_H
#define USB_COMMON_H

#include "types.h"

/* ---------- дескрипторы USB (spec 9.6; packed) ---------- */

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 bcdUSB;
    u8 bDeviceClass, bDeviceSubClass, bDeviceProtocol;
    u8 bMaxPacketSize0;
    u16 idVendor, idProduct, bcdDevice;
    u8 iManufacturer, iProduct, iSerial;
    u8 bNumConfigurations;
} usb_device_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 wTotalLength;
    u8 bNumInterfaces, bConfigValue, iConfiguration, bmAttributes;
    u8 bMaxPower;
} usb_config_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bInterfaceNumber, bAlternateSetting;
    u8 bNumEndpoints, bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol;
    u8 iInterface;
} usb_iface_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bEndpointAddress, bmAttributes;
    u16 wMaxPacketSize;
    u8 bInterval;
} usb_ep_desc_t;

/* ---------- стандартные запросы (setup-packet, 8 байт) ---------- */

typedef struct __attribute__((packed)) {
    u8 bmRequestType;
    u8 bRequest;
    u16 wValue;
    u16 wIndex;
    u16 wLength;
} usb_request_t;

/* билдеры: ЕДИНСТВЕННОЕ место со значениями полей */
static inline void usb_req_get_descriptor(usb_request_t *r, u8 type, u8 idx,
                                          int len)
{
    r->bmRequestType = 0x80;           /* IN, Standard, Device */
    r->bRequest = 6;                   /* GET_DESCRIPTOR */
    r->wValue = (u16)((type << 8) | idx);
    r->wIndex = 0;
    r->wLength = (u16)len;
}

static inline void usb_req_set_address(usb_request_t *r, u8 new_addr)
{
    r->bmRequestType = 0x00;           /* OUT, Standard, Device */
    r->bRequest = 5;                   /* SET_ADDRESS */
    r->wValue = new_addr;
    r->wIndex = 0;
    r->wLength = 0;
}

static inline void usb_req_set_configuration(usb_request_t *r, u8 config)
{
    r->bmRequestType = 0x00;           /* OUT, Standard, Device */
    r->bRequest = 9;                   /* SET_CONFIGURATION */
    r->wValue = config;
    r->wIndex = 0;
    r->wLength = 0;
}

static inline void usb_req_set_idle(usb_request_t *r, int ifc)
{
    r->bmRequestType = 0x21;           /* OUT, Class, Interface */
    r->bRequest = 0x0A;                /* SET_IDLE (HID class) */
    r->wValue = 0;
    r->wIndex = (u16)ifc;
    r->wLength = 0;
}

static inline void usb_req_set_protocol_boot(usb_request_t *r, int ifc)
{
    r->bmRequestType = 0x21;           /* OUT, Class, Interface */
    r->bRequest = 0x0B;                /* SET_PROTOCOL (HID) */
    r->wValue = 0;                     /* 0 = Boot Protocol */
    r->wIndex = (u16)ifc;
    r->wLength = 0;
}

#endif /* USB_COMMON_H */
