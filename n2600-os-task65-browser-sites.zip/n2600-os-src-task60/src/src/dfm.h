/* dfm.h — полноэкранный текстовый файловый менеджер для telnet N2600-OS
 * (Task 48). Адаптация модели dfm (Dylan Araps, dylanaraps/dfm, MIT) под
 * систему: канонический dfm рассчитан на POSIX (termios/dirent/arena) —
 * здесь воспроизведена его UI-МОДЕЛЬ (одна клавиша = одно действие,
 * vi-навигация, сортировки, поиск, перерисовка ANSI), а бэкенд — RAM disk,
 * ввод — посимвольный канал telnetd, вывод — тот же sink с \n → \r\n.
 *
 * Режимы (мышь активна только в 1 и 4; в 2/3 — выключена, т.к. telnetd
 * собирает строку своим эхо-вводом и ESC-последовательности от мыши
 * попали бы в строку):
 *   1 ОБЗОР    — полный экран (ANSI), посимвольный ввод; мышь:
 *                клик по [X] в подсказке = команда X; клик по строке
 *                списка = выбрать / повторный = Enter; ПКМ = наверх;
 *                колесо = движение по списку;
 *   2 РЕДАКТОР — построчный (ed-подобный, из tfm Task 46): l/v/s/a/d/w/wq/q;
 *   3 ПРОМПТ   — строка ввода для /, n, m;
 *   4 ПРОСМОТР — постраничный просмотр (j/k/g/G/Space/q + колесо мыши +
 *                клик по [X] в подсказке).
 *
 * Модуль БЕЗ собственных потоков: все вызовы — из задачи telnetd
 * (последовательно по слотам, статические scratch-буферы допустимы).
 * Состояние встраивается в tnd_conn_t (статические слоты). */
#ifndef DFM_H
#define DFM_H

#include "types.h"
#include "ramfs.h"

#define DFM_ENTS_MAX  32     /* записей каталога в кэше */
#define DFM_ROWS      18     /* строк списка по умолчанию (перекрывается f->rows) */
#define DFM_CWD_MAX   100    /* текущий каталог (ramfs-путь, "" = корень) */
#define DFM_NAME_MAX  64     /* = RAMFS_NAME_MAX */
#define DFM_FILT_MAX  48     /* фильтр поиска */
#define DFM_ED_MAX    (16u * 1024u)   /* макс. размер файла в редакторе */
#define DFM_VIEW_MAX  (32u * 1024u)   /* макс. размер файла в просмотрщике */
#define DFM_MSG_MAX   72
#define DFM_BTN_MAX   16     /* кликабельных подсказок на экране (обзор: 15, просмотр: 6) */

/* Кликабельный хотспот на help-строке. row/col — 1-based абсолютные
 * координаты экрана; col_end включительно. key — символ, который
 * синтезируется при попадании (передаётся в dfm_browse_key/dfm_view_key). */
typedef struct {
    u16 row;
    u16 col_start;
    u16 col_end;
    u8  key;
} dfm_btn_t;

/* mode: 0 = выкл, 1 = обзор, 2 = редактор, 3 = промпт, 4 = просмотр */
typedef struct dfm_s {
    int  mode;
    char cwd[DFM_CWD_MAX];     /* «», «www», «dir/sub» — без ведущего слеша */
    int  nents;                /* записей в кэше (уже после фильтра) */
    ramfs_dirent_t ents[DFM_ENTS_MAX];
    int  y;                    /* курсор по видимому списку */
    int  o;                    /* первая видимая строка окна */
    u8   sort;                 /* 0 имя, 1 имя↓, 2 размер, 3 размер↓ */
    u8   view;                 /* 0 имя, 1 имя+размер */
    char filt[DFM_FILT_MAX];   /* «» нет; «*abc» подстрока, иначе префикс */
    int  del_pending;          /* 1 = ждём y на удаление записи y */
    char msg[DFM_MSG_MAX];     /* строка состояния/ошибки */
    int  prompt_kind;          /* 0 нет, 1 поиск, 2 новый файл, 3 mkdir */
    /* просмотрщик */
    char vp_path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    char *vp;                  /* буфер файла (malloc) или 0 */
    u32  vp_len;
    u32  vp_top;               /* первая видимая строка (0-based) */
    u32  vp_lines;             /* всего строк в файле */
    int  vp_binary;            /* двоичный файл (текст не показываем) */
    /* редактор */
    char *ed;                  /* буфер файла (malloc) или 0 */
    u32   ed_len;
    int   ed_dirty;
    char  ed_path[DFM_CWD_MAX + DFM_NAME_MAX + 2];
    /* вывод (привязывается в dfm_enter; живёт до dfm_reset) */
    void (*out)(void *ud, const char *s);
    void *ud;
    /* сборка ESC-последовательности (стрелки и SGR-мышь) */
    u8   esc;                  /* 0 нет, 1 после ESC, 2 после ESC[ */
    /* экран/мышь (Task 48+) */
    int  rows;                 /* видимых строк списка (term_rows - 5) */
    int  cols;                 /* ширина терминала */
    u8   mouse;                /* 1 = включить SGR-мышь (opt-in: см. dfm_enter) */
    u8   mstate;               /* парсер SGR: 0=off, 1=после ESC[< */
    u32  mval[3];              /* накопители: b; x; y */
    u8   midx;                 /* текущий индекс 0..2 */
    /* кликабельные подсказки — пересобираются в каждом dfm_draw/_view_draw */
    u8   nbtn;                 /* 0..DFM_BTN_MAX; 0 = нет на экране */
    dfm_btn_t btn[DFM_BTN_MAX];
} dfm_t;

/* Сброс (выход/закрытие соединения); освобождает буферы редактора/просмотра,
 * гасит мышь, обнуляет структуру. */
void dfm_reset(dfm_t *f);

/* 1 = менеджер активен (ввод идёт ему, а не shell). */
int  dfm_active(const dfm_t *f);

/* 1 = режим собирает СТРОКУ (редактор/промпт; telnetd использует свой
 * строковый ввод с эхом), 0 = посимвольный (обзор/просмотр). */
int  dfm_wants_line(const dfm_t *f);

/* Текст приглашения для режима строки (поиск/new:/mkdir:). Содержит ANSI
 * (цвет), telnetd должен выводить строку «как есть» без санитайза. */
void dfm_prompt_text(const dfm_t *f, char *out, int cap);

/* Войти в менеджер (перерисовать экран). out/ud запоминаются.
 * Поле f->mouse должно быть выставлено ДО вызова (см. dfm_enter в .c). */
void dfm_enter(dfm_t *f, void (*out)(void *ud, const char *s), void *ud);

/* Один байт ввода в ПОСИМВОЛЬНОМ режиме (обзор/просмотр; внутри —
 * сборка ESC-последовательностей стрелок и SGR-мыши). Перерисовывает экран. */
void dfm_key(dfm_t *f, unsigned char b);

/* Готовая строка из ПРОМПТА (поиск/новый файл/mkdir). */
void dfm_prompt_line(dfm_t *f, const char *line);

/* Готовая строка РЕДАКТОРА (l/v/s/a/d/w/wq/q). */
void dfm_edit_line(dfm_t *f, const char *line);

/* Смена размера терминала (NAWS/SIGWINCH из telnetd). Пересчитывает
 * f->rows = term_rows - 5, клампит offsets, перерисовывает активный экран
 * (в режимах 2/3 — только сохраняет; следующий dfm_draw использует новые). */
void dfm_resize(dfm_t *f, int term_rows, int term_cols);

/* Разбор одного события SGR-мыши (b, mx, my — 1-based, как в протоколе;
 * press=1 для 'M', 0 для 'm'). Обычно вызывается автоматически из dfm_key;
 * публично — на случай, если telnetd захочет разбирать SGR сам. */
void dfm_mouse_event(dfm_t *f, u32 b, u32 mx, u32 my, int press);

#endif /* DFM_H */