/* string.c — реализация минимальной библиотеки строк */
#include "string.h"

void *memset(void *dst, int c, u32 n)
{
    u8 *d = (u8 *)dst;
    while (n--) *d++ = (u8)c;
    return dst;
}

void *memcpy(void *dst, const void *src, u32 n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    while (n--) *d++ = *s++;
    return dst;
}

void *memmove(void *dst, const void *src, u32 n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    if (d < s) {
        while (n--) *d++ = *s++;
    } else if (d > s) {
        d += n; s += n;
        while (n--) *--d = *--s;
    }
    return dst;
}

int memcmp(const void *a, const void *b, u32 n)
{
    const u8 *pa = (const u8 *)a, *pb = (const u8 *)b;
    while (n--) {
        if (*pa != *pb) return (int)*pa - (int)*pb;
        pa++; pb++;
    }
    return 0;
}

/* memchr: первый байт c в первых n байтах s (NULL = не найден).
 * Нужен klog (поиск '\n' в кольцевом буфере журнала загрузки). */
void *memchr(const void *s, int c, u32 n)
{
    const u8 *p = (const u8 *)s;
    while (n--) {
        if (*p == (u8)c) return (void *)p;
        p++;
    }
    return NULL;
}

u32 strlen(const char *s)
{
    u32 n = 0;
    while (*s++) n++;
    return n;
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (int)(u8)*a - (int)(u8)*b;
}

int strncmp(const char *a, const char *b, u32 n)
{
    while (n && *a && *a == *b) { a++; b++; n--; }
    return n ? (int)(u8)*a - (int)(u8)*b : 0;
}

char *strcpy(char *dst, const char *src)
{
    char *d = dst;
    while ((*d++ = *src++) != 0) {}
    return dst;
}

char *strncpy(char *dst, const char *src, u32 n)
{
    char *d = dst;
    while (n && *src) { *d++ = *src++; n--; }
    while (n--) *d++ = 0;
    return dst;
}

char *strchr(const char *s, int c) {
   while (*s) {
           if (*s == (char)c) return (char *)s;
           s++;
   }
   return (c == '\0') ? (char *)s : NULL;
}

/* Сессия 13: последнее вхождение символа (ramfs mkdir: родитель пути). */
char *strrchr(const char *s, int c)
{
    const char *last = NULL;
    if (!s) return NULL;
    while (*s) {
        if (*s == (char)c) last = s;
        s++;
    }
    /* NUL-терминатор тоже считается для c==0 (семантика strrchr) */
    if (c == 0) return (char *)s;
    return (char *)last;
}

/* strstr: первое вхождение needle в hay (NULL = не найден).
 * Нужно HTTP Trace (поиск конца заголовков "\r\n\r\n" в ответе).
 * Пустая needle возвращает hay (как в стандартном libc). */
char *strstr(const char *hay, const char *needle)
{
    if (!needle || !needle[0]) return (char *)hay;
    u32 nl = strlen(needle);
    for (const char *p = hay; *p; p++) {
        if (*p == needle[0] && strncmp(p, needle, nl) == 0)
            return (char *)p;
    }
    return NULL;
}

/* ---- мини-vsnprintf: %s %c %d %u %x %X %p %%, флаги '-' и '0',
 * ширина до 2 цифр, точность %.N для %s, модификаторы l/ll игнорируются.
 *
 * FIX [P1] (мусор в диспетчере задач): раньше флаг '-' НЕ поддерживался —
 * формат "%-12s" выводился как литеральный текст "%-12s", БЕЗ потребления
 * аргумента. Все последующие спецификаторы сдвигались на один аргумент:
 * "%8u" печатал указатель имени как число, а "%s" в графе «Статус»
 * разыменовывал ЗНАЧЕНИЕ UPTIME как указатель → случайные символы,
 * меняющиеся каждые полсекунды. Теперь: левое выравнивание + ширина для
 * %s (и всех типов), 'll' пропускается целиком (низ 32 бит — на x86-32
 * vararg 64-бит лежит двумя слотами, младший первым), %.N обрезает строку. */

static int put_char(char *out, u32 n, u32 *pos, char c)
{
    if (*pos + 1 < n) out[*pos] = c;
    (*pos)++;
    return 1;
}

static int put_str(char *out, u32 n, u32 *pos, const char *s, int max_chars)
{
    int cnt = 0;
    if (max_chars >= 0) {
        /* СЕССИЯ 73 [CONSOLE]: %.N не рвёт UTF-8 символ — граница
         * отступает к началу последовательности (прежде "%.7s" у
         * кириллицы оставлял в конце обрубок lead-байта) */
        int lim = 0;
        while (lim < max_chars && s[lim]) {
            unsigned char c = (unsigned char)s[lim];
            int adv = (c & 0xE0) == 0xC0 ? 2 : (c & 0xF0) == 0xE0 ? 3 : 1;
            if (lim + adv > max_chars) break;
            lim += adv;
        }
        max_chars = lim;
    }
    while (*s && (max_chars < 0 || cnt < max_chars)) {
        put_char(out, n, pos, *s++);
        cnt++;
    }
    return cnt;
}

static int put_pad(char *out, u32 n, u32 *pos, char pad, int count)
{
    int cnt = 0;
    while (count-- > 0) { put_char(out, n, pos, pad); cnt++; }
    return cnt;
}

static int put_num(char *out, u32 n, u32 *pos, u64 val, int base, int upper,
                   int neg, char pad, int width)
{
    char buf[24];                       /* 64-битное восьмеричное — до 22 цифр */
    const char *digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int i = 0, cnt = 0;
    if (val == 0) buf[i++] = '0';
    while (val) { buf[i++] = digits[val % (u64)base]; val /= (u64)base; }
    if (neg) { put_char(out, n, pos, '-'); cnt++; width--; }
    while (width > i) { put_char(out, n, pos, pad); cnt++; width--; }
    while (i--) { put_char(out, n, pos, buf[i]); cnt++; }
    return cnt;
}

/* ---- СЕССИЯ 61: поддержка %f/%e/%g ----
 * Прежде float-спецификаторы печатались литералом ("%g" в выводе
 * CMScript: print("x: " + 3.5) давал "x: %g"). Форматирование — через
 * x87-разложение double и ЦЕЛОЧИСЛЕННУЮ печать u64 (деление —
 * __udivdi3/__umoddi3 из int64_runtime.c). FPU в ядре всегда включён
 * (CR0.TS не ставится, переключение контекста не сохраняет x87) —
 * тот же уровень, что и float-арифметика самого CMScript. */
static int put_u64_dec(char *out, u32 n, u32 *pos, unsigned long long v)
{
    char buf[24];
    int i = 0, cnt = 0;
    if (v == 0) buf[i++] = '0';
    while (v) {
        buf[i++] = (char)('0' + (int)(v % 10ULL));
        v /= 10ULL;
    }
    while (i--) { put_char(out, n, pos, buf[i]); cnt++; }
    return cnt;
}

/* печать в готовый буфер (нужна для выравнивания по ширине) */
static int render_double(char *buf, u32 bufsz, double v, int prec, char spec)
{
    u32 pos = 0;
    if (v != v) { put_str(buf, bufsz, &pos, "nan", -1); goto done; }
    if (v == v * 2.0 && v != 0.0) {              /* бесконечность */
        if (v < 0) put_char(buf, bufsz, &pos, '-');
        put_str(buf, bufsz, &pos, "inf", -1);
        goto done;
    }
    if (v < 0) { put_char(buf, bufsz, &pos, '-'); v = -v; }

    if (spec == 'e' || (spec == 'g' && (v >= 1.0e15 || (v != 0.0 && v < 1.0e-4)))) {
        /* ---- %e: d.dddE±ee ---- */
        int exp = 0;
        if (prec < 0) prec = 6;
        if (prec > 15) prec = 15;
        if (v > 0.0) {
            while (v >= 10.0) { v /= 10.0; exp++; }
            while (v < 1.0)   { v *= 10.0; exp--; }
        }
        /* округление mantissa*10^prec; перенос 9.99.. -> 10.0 */
        double scale = 1.0;
        for (int i = 0; i < prec; i++) scale *= 10.0;
        unsigned long long m = (unsigned long long)(v * scale + 0.5);
        if (m > 0 && m >= (unsigned long long)(scale * 10.0)) { m /= 10ULL; exp++; }
        unsigned long long hi = (prec > 0) ? m / (unsigned long long)scale : m;
        put_u64_dec(buf, bufsz, &pos, hi);
        if (prec > 0) {
            unsigned long long lo = m % (unsigned long long)scale;
            char tail[20];
            int t = 0;
            for (int i = 0; i < prec; i++) { tail[t++] = (char)('0' + (int)(lo % 10ULL)); lo /= 10ULL; }
            put_char(buf, bufsz, &pos, '.');
            while (t--) put_char(buf, bufsz, &pos, tail[t]);
            if (spec == 'g') {
                /* %g: убрать хвостовые нули мантиссы и точку */
                u32 dot = pos;
                for (u32 k = 0; k < pos; k++)
                    if (buf[k] == '.') { dot = k; break; }
                if (dot < pos) {
                    while (pos > dot + 1 && buf[pos - 1] == '0') pos--;
                    if (pos == dot + 1) pos = dot;
                }
            }
        }
        put_char(buf, bufsz, &pos, 'e');
        put_char(buf, bufsz, &pos, exp < 0 ? '-' : '+');
        int ae = exp < 0 ? -exp : exp;
        if (ae < 10) put_char(buf, bufsz, &pos, '0');
        put_u64_dec(buf, bufsz, &pos, (unsigned long long)ae);
    } else {
        /* ---- %f: d.ddd ---- */
        if (v >= 1.0e18) {
            /* не влезает в u64 — печатаем в экспоненциальном виде */
            return render_double(buf, bufsz, v, prec < 0 ? 5 : (prec > 0 ? prec - 1 : 0), 'e');
        }
        if (prec < 0) prec = 6;
        if (prec > 15) prec = 15;
        if (spec == 'g') {
            /* %g: значащие цифры -> меньшая из точностей по порядку */
            if (prec == 0) prec = 1;
            if (prec > 15) prec = 15;
            double av = v;
            int e = 0;
            if (av > 0.0) {
                while (av >= 10.0) { av /= 10.0; e++; }
                while (av < 1.0)   { av *= 10.0; e--; }
            }
            if (e < prec) {
                int pf = prec - 1 - e;
                if (pf < 0) pf = 0;
                prec = pf;
            } else {
                /* здесь не должны оказаться (проверка диапазона выше),
                 * но страховка */
                prec = prec - 1;
                if (prec < 0) prec = 0;
            }
        }
        u64 scale = 1;
        for (int i = 0; i < prec; i++) scale *= 10ULL;
        u64 ip = (u64)v;
        double fr = v - (double)ip;
        u64 fp = (u64)(fr * (double)scale + 0.5);
        if (fp >= scale) { ip += 1ULL; fp -= scale; }   /* перенос округления */
        put_u64_dec(buf, bufsz, &pos, ip);
        if (prec > 0) {
            char tail[20];
            int t = 0;
            u64 lo = fp;
            for (int i = 0; i < prec; i++) { tail[t++] = (char)('0' + (int)(lo % 10ULL)); lo /= 10ULL; }
            put_char(buf, bufsz, &pos, '.');
            while (t--) put_char(buf, bufsz, &pos, tail[t]);
            if (spec == 'g') {
                /* %g: убрать хвостовые нули ПРАВЕЕ точки и саму точку
                 * (нули целой части трогать нельзя: 100 -> "100", не "1") */
                u32 dot = pos;
                for (u32 k = 0; k < pos; k++)
                    if (buf[k] == '.') { dot = k; break; }
                if (dot < pos) {
                    while (pos > dot + 1 && buf[pos - 1] == '0') pos--;
                    if (pos == dot + 1) pos = dot;   /* "." тоже убрать */
                }
            }
        }
    }
done:
    if (bufsz) buf[(pos < bufsz) ? pos : bufsz - 1] = 0;
    return (int)pos;
}

int vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap)
{
    u32 pos = 0;
    if (n) out[0] = 0;

    while (*fmt) {
        if (*fmt != '%') { put_char(out, n, &pos, *fmt++); continue; }
        fmt++;
        if (*fmt == 0) break;

        /* флаги */
        int left_align = 0;
        char pad = ' ';
        for (;;) {
            if (*fmt == '-') { left_align = 1; fmt++; }
            else if (*fmt == '0') { pad = '0'; fmt++; }
            else break;
        }
        /* ширина */
        int width = 0;
        while (*fmt >= '0' && *fmt <= '9' && width < 99) {
            width = width * 10 + (*fmt - '0');
            fmt++;
        }
        /* точность (только для %s: обрезка строки); '*' не поддерживаем */
        int prec = -1;
        if (*fmt == '.') {
            fmt++;
            prec = 0;
            while (*fmt >= '0' && *fmt <= '9' && prec < 999) {
                prec = prec * 10 + (*fmt - '0');
                fmt++;
            }
        }
        /* модификаторы длины: l/ll — СЕССИЯ 61: 64-битные значения
         * читаются ЧЕРЕЗ __builtin_va_arg(ap, long long) — корректно
         * и для gcc, и для mingw (прежде 'll' пропускался и печатались
         * только младшие 32 бита: print(4294967296) давал "0"). */
        int is_ll = 0;
        while (*fmt == 'l') { is_ll = 1; fmt++; }

        switch (*fmt) {
        case 's': {
            const char *s = __builtin_va_arg(ap, const char *);
            if (!s) s = "(null)";
            /* длина с учётом точности */
            int slen = 0;
            while (s[slen] && (prec < 0 || slen < prec)) slen++;
            if (left_align) {
                put_str(out, n, &pos, s, prec);
                put_pad(out, n, &pos, ' ', width - slen);
            } else {
                put_pad(out, n, &pos, ' ', width - slen);
                put_str(out, n, &pos, s, prec);
            }
            break;
        }
        case 'c': {
            char c = (char)__builtin_va_arg(ap, int);
            if (left_align) {
                put_char(out, n, &pos, c);
                put_pad(out, n, &pos, ' ', width - 1);
            } else {
                put_pad(out, n, &pos, ' ', width - 1);
                put_char(out, n, &pos, c);
            }
            break;
        }
        case 'd': {
            if (is_ll) {
                i64 v = __builtin_va_arg(ap, i64);
                u64 uv = (v < 0) ? (u64)(-v) : (u64)v;
                if (left_align) {
                    int w = put_num(out, n, &pos, uv, 10, 0, v < 0, ' ', 0);
                    put_pad(out, n, &pos, ' ', width - w - (v < 0 ? 1 : 0));
                } else {
                    put_num(out, n, &pos, uv, 10, 0, v < 0, pad, width);
                }
            } else {
                i32 v = __builtin_va_arg(ap, i32);
                u32 uv = (v < 0) ? (u32)(-v) : (u32)v;
                if (left_align) {
                    int w = put_num(out, n, &pos, uv, 10, 0, v < 0, ' ', 0);
                    put_pad(out, n, &pos, ' ', width - w - (v < 0 ? 1 : 0));
                } else {
                    put_num(out, n, &pos, uv, 10, 0, v < 0, pad, width);
                }
            }
            break;
        }
        case 'u': {
            u64 v = is_ll ? (u64)__builtin_va_arg(ap, unsigned long long)
                          : (u64)__builtin_va_arg(ap, u32);
            if (left_align) {
                int w = put_num(out, n, &pos, v, 10, 0, 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w);
            } else {
                put_num(out, n, &pos, v, 10, 0, 0, pad, width);
            }
            break;
        }
        case 'x': {
            u64 v = is_ll ? (u64)__builtin_va_arg(ap, unsigned long long)
                          : (u64)__builtin_va_arg(ap, u32);
            if (left_align) {
                int w = put_num(out, n, &pos, v, 16, 0, 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w);
            } else {
                put_num(out, n, &pos, v, 16, 0, 0, pad, width);
            }
            break;
        }
        case 'X': {
            u64 v = is_ll ? (u64)__builtin_va_arg(ap, unsigned long long)
                          : (u64)__builtin_va_arg(ap, u32);
            if (left_align) {
                int w = put_num(out, n, &pos, v, 16, 1, 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w);
            } else {
                put_num(out, n, &pos, v, 16, 1, 0, pad, width);
            }
            break;
        }
        case 'p': {
            put_str(out, n, &pos, "0x", -1);
            put_num(out, n, &pos, (u32)(unsigned long)__builtin_va_arg(ap, void *),
                    16, 0, 0, '0', 8);
            break;
        }
        /* СЕССИЯ 61: %f/%e/%g — вещественные. Сначала в tmp-буфер
         * (render_double), затем выравнивание по ширине. */
        case 'f': case 'e': case 'g': {
            double v = __builtin_va_arg(ap, double);
            char tmp[512];
            int len = render_double(tmp, (u32)sizeof(tmp), v, prec, *fmt);
            if (left_align) {
                put_str(out, n, &pos, tmp, -1);
                put_pad(out, n, &pos, ' ', width - len);
            } else {
                put_pad(out, n, &pos, ' ', width - len);
                put_str(out, n, &pos, tmp, -1);
            }
            break;
        }
        case '%':
            put_char(out, n, &pos, '%');
            break;
        default:
            put_char(out, n, &pos, '%');
            put_char(out, n, &pos, *fmt);
            break;
        }
        fmt++;
    }
    if (n) {
        u32 end = (pos < n) ? pos : n - 1;
        /* СЕССИЯ 73 [CONSOLE]: при обрезке не оставлять ОБРУБОК
         * многобайтового UTF-8 символа. Прежде «…837632 сек» + обрезанный
         * lead байт давали мусорный глиф в сериал-консоли, а съеденный
         * '\n' клеил следующее сообщение к обрезанному хвосту. */
        if (pos >= n && end > 0) {
            u32 j = end - 1;
            unsigned char c = (unsigned char)out[j];
            if ((c & 0xC0) == 0x80) {              /* продолжающий байт */
                while (j > 0 && ((unsigned char)out[j] & 0xC0) == 0x80) j--;
                if (((unsigned char)out[j] & 0xE0) == 0xC0) {
                    int need = ((unsigned char)out[j] & 0xF0) == 0xE0 ? 3 : 2;
                    if ((int)(end - j) < need) end = j;   /* lead без хвоста */
                }
            } else if ((c & 0xE0) == 0xC0 || (c & 0xF0) == 0xE0) {
                end = j;                           /* голый lead на конце */
            }
        }
        out[end] = 0;
    }
    return (int)pos;
}

int snprintf(char *out, u32 n, const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(out, n, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

unsigned utf8_next(const char **ps)
{
    const unsigned char *s = (const unsigned char *)*ps;
    unsigned c;
    if (s[0] < 0x80) {
        c = s[0];
        *ps += 1;
    } else if ((s[0] & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
        c = ((unsigned)(s[0] & 0x1F) << 6) | (s[1] & 0x3F);
        *ps += 2;
    } else {
        c = '?';
        do { *ps += 1; } while (((**ps) & 0xC0) == 0x80);
    }
    return c;
}
