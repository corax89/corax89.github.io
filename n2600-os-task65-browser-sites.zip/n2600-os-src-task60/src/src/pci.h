/* pci.h — минимальный доступ к PCI конфигурационному пространству.
 *
 * С Task 49 реализация — в pci.c (раньше тела жили в usb.c, и каждый
 * драйвер с pci.h тянул при линковке весь usb.o).
 */
#ifndef PCI_H
#define PCI_H

#include "types.h"

u32  pci_read32(int bus, int dev, int func, int reg);
u16  pci_read16(int bus, int dev, int func, int reg);
u8   pci_read8(int bus, int dev, int func, int reg);
void pci_write32(int bus, int dev, int func, int reg, u32 val);
void pci_write16(int bus, int dev, int func, int reg, u16 val);

#endif /* PCI_H */
