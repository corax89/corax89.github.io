/* mtrr.c — Write-Combining MTRR для линейного фреймбуфера (Task 49;
 * вынесен из kernel.c, блок [ПЕРФ]). См. mtrr.h. */
#include "types.h"
#include "boot.h"
#include "pci.h"
#include "string.h"
#include "mtrr.h"
#include <cpuid.h>

extern void klog_puts(const char *s);
extern void serial_puts(const char *);

/* ==================== MTRR: Write-Combining для LFB (ПЕРФ) ====================
 * При типе памяти UC/WT каждая запись в LFB тянет за собой чтение строки
 * кэша из RAM (read-for-ownership): кадр 1280x600x32 = 3 МиБ — это ~6 МиБ
 * лишнего трафика на каждый flush. Тип WC разрешает процессору объединять
 * записи пакетами по 64 байта — fb_flush_rects (копия compose→LFB) ускоряется
 * в разы, перетаскивание окон становится плавным.
 *
 * БЕЗОПАСНОСТЬ: если хоть одна проверка не проходит, WC просто НЕ
 * включается (ядро работает как раньше):
 *   1) CPUID подтверждает MTRR;
 *   2) диапазон после выравнивания целиком внутри MMIO-дыры
 *      [0xC0000000, 0xFEC00000) — не задевает RAM (ниже) и
 *      IOAPIC/LAPIC/HPET (0xFEC00000+);
 *   3) диапазон не пересекает MMIO BAR устройств (WC объединяет записи и
 *      допускает упреждающие чтения — для регистров устройств это поломка).
 *      BAR'ы измеряются штатным sizing'ом; сам BAR фреймбуфера (тот, что
 *      СОДЕРЖИТ LFB) исключением разрешён;
 *   4) есть свободный переменный MTRR (PHYSMASK без valid-бита).
 * Всё выполняется ДО инициализации драйверов (BAR'ы устройств неактивны,
 * sizing безопасен). Fixed-range MTRR не трогаются вовсе. */

static void msr_write(u32 msr, u64 v)
{
    __asm__ __volatile__("wrmsr"
                         :: "c"(msr), "a"((u32)v), "d"((u32)(v >> 32))
                         : "memory");
}

static u64 msr_read(u32 msr)
{
    u32 lo, hi;
    __asm__ __volatile__("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((u64)hi << 32) | (u64)lo;
}

/* Размер MMIO BAR (штатный sizing: записать 0xFFFFFFFF, прочитать маску,
 * восстановить). Устройства в этот момент ещё не инициализированы. */
static u64 mtrr_bar_size(int bus, int dev, int fn, u32 reg, int is64)
{
    u32 olo = pci_read32(bus, dev, fn, reg);
    u32 ohi = is64 ? pci_read32(bus, dev, fn, reg + 4) : 0;
    pci_write32(bus, dev, fn, reg, 0xFFFFFFFFu);
    u32 mlo = pci_read32(bus, dev, fn, reg);
    u64 size;
    if (is64) {
        pci_write32(bus, dev, fn, reg + 4, 0xFFFFFFFFu);
        u32 mhi = pci_read32(bus, dev, fn, reg + 4);
        pci_write32(bus, dev, fn, reg + 4, ohi);
        size = (~(((u64)mhi << 32) | (mlo & 0xFFFFFFF0u))) + 1ULL;
    } else {
        size = (u64)((~(mlo & 0xFFFFFFF0u)) + 1u);
    }
    pci_write32(bus, dev, fn, reg, olo);
    if (size == 0 || size > (1ULL << 32)) size = 0x1000;   /* мусор в конфиге */
    return size;
}

/* 1 = диапазон [b, b+sz) пересекает хоть один MMIO BAR (кроме самого
 * BAR'а фреймбуфера — тот по определению содержит LFB). Сканируются
 * шины 0..63: покрывает все ВМ и практически всё реальное железо ОС. */
static int mtrr_bar_overlap(u64 b, u64 sz)
{
    u64 e = b + sz;
    for (int bus = 0; bus < 64; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            int multifunc = 0;
            for (int fn = 0; fn < 8; fn++) {
                if (fn > 0 && !multifunc) break;
                u32 vd = pci_read32(bus, dev, fn, 0x00);
                if ((vd & 0xFFFF) == 0xFFFF) {
                    if (fn == 0) break;          /* слот пуст */
                    continue;
                }
                u8 hdr = pci_read8(bus, dev, fn, 0x0E);
                if (fn == 0) multifunc = (hdr & 0x80) != 0;
                int nbars = (hdr & 0x7F) == 0 ? 6        /* обычное устройство */
                          : (hdr & 0x7F) == 1 ? 2        /* PCI-мост */
                          : 1;                           /* CardBus и пр. */
                u32 reg = 0x10;
                for (int bi = 0; bi < nbars; bi++, reg += 4) {
                    u32 lo = pci_read32(bus, dev, fn, reg);
                    if (lo & 1u) continue;               /* port IO — не MMIO */
                    int is64 = ((lo >> 1) & 3) == 2;
                    if (is64) {
                        u32 hi = pci_read32(bus, dev, fn, reg + 4);
                        u64 base = ((u64)hi << 32) | (lo & 0xFFFFFFF0u);
                        u64 bsz = mtrr_bar_size(bus, dev, fn, reg, 1);
                        if (base != 0) {
                            /* BAR фреймбуфера содержит LFB — это он и есть */
                            int is_fb = (base <= b) && (base + bsz > b);
                            if (!is_fb && base < e && base + bsz > b) return 1;
                        }
                        bi++; reg += 4;                  /* старшая половина */
                    } else {
                        u64 base = lo & 0xFFFFFFF0u;
                        if (base == 0) continue;         /* BAR не назначен */
                        u64 bsz = mtrr_bar_size(bus, dev, fn, reg, 0);
                        int is_fb = (base <= b) && (base + bsz > b);
                        if (!is_fb && base < e && base + bsz > b) return 1;
                    }
                }
            }
        }
    }
    return 0;
}

/* 1 = диапазон [b, b+sz) пересекает ДОСТУПНУЮ RAM из карты Multiboot;
 * -1 = карты нет (неизвестно). WC над кэшируемой RAM недопустим
 * (некогерентность/потеря данных); MMIO-регионы вне PCI BAR'ов
 * отфильтровываются верхней границей 0xFEC00000 (IOAPIC/LAPIC).
 * СЕССИЯ 88: замена жёсткого нижнего порога 0xC0000000 — на X101CH
 * апертура LFB ниже, и весь интерфейс рисовался в uncached-память. */
static int mtrr_ram_overlap(const mb_info_t *mb, u64 b, u64 sz)
{
    if (!(mb->flags & MBIF_MMAP) || !mb->mmap_addr || !mb->mmap_length)
        return -1;                          /* карты нет — неизвестно */
    const u8 *p = (const u8 *)(unsigned long)mb->mmap_addr;
    const u8 *endp = p + mb->mmap_length;
    u64 e = b + sz;
    while (p + 4 <= endp) {
        const mb_mmap_t *en = (const mb_mmap_t *)p;
        if (en->size < 20) break;
        if (en->type == 1) {                /* Available RAM */
            u64 s = en->addr, t = en->addr + en->len;
            if (s < e && b < t) return 1;
        }
        p += en->size + 4;
    }
    return 0;
}

static void mtrr_lfb_wc_extra_impl(u32 bytes);

/* СЕССИЯ 83 [FIX-EXC13]: доп. размер WC-региона (compose в VRAM Voodoo3).
 * СЕССИЯ 90: voodoo3.c удалён — механизм оставлен (кто-то может
 * потребоваться позже), но вызвать его больше некому. */
static u32 g_mtrr_wc_extra = 0;
static int  g_mtrr_wc_on   = 0;             /* СЕССИЯ 88: WC для LFB включён */
int mtrr_lfb_wc_enabled(void) { return g_mtrr_wc_on; }
static void mtrr_lfb_wc_extra_impl(u32 bytes)
{
    if (bytes > g_mtrr_wc_extra) g_mtrr_wc_extra = bytes;
}

void mtrr_lfb_wc_extra(u32 bytes)
{
    mtrr_lfb_wc_extra_impl(bytes);
}

void mtrr_lfb_wc(const mb_info_t *mb)
{
    if (!(mb->flags & MBIF_FRAMEBUFFER) ||
        mb->framebuffer_type != MB_FT_RGB ||
        mb->framebuffer_bpp < 16)
        return;                          /* headless RAM-буфер — WC не нужен */

    u32 ca, cb, cc, cd;
    if (!__get_cpuid(1, &ca, &cb, &cc, &cd) || !(cd & (1u << 12))) {
        klog_puts("mtrr: CPU без MTRR — WC не включён");
        return;
    }

    u64 base = mb->framebuffer_addr;
    u64 fbsz = (u64)mb->framebuffer_pitch * (u64)mb->framebuffer_height;
    if (g_mtrr_wc_extra > fbsz) fbsz = g_mtrr_wc_extra;   /* compose в VRAM */

    u32 cap = (u32)msr_read(0xFE);       /* MTRRCAP */
    int nvar = (int)(cap & 0xFF);
    if (nvar <= 0) {
        klog_puts("mtrr: нет переменных MTRR — WC не включён");
        return;
    }

    /* размер вверх до степени двойки, база вниз; диапазон обязан
     * целиком накрывать LFB */
    u64 sz = 0x40000;                    /* минимум 256 КиБ */
    while (sz < fbsz) sz <<= 1;
    u64 b = base & ~(sz - 1);
    while (b + sz < base + fbsz && sz < 0x10000000ULL) {
        sz <<= 1;
        b = base & ~(sz - 1);
    }
    if (b + sz < base + fbsz) {
        klog_puts("mtrr: LFB не накрывается выровненным диапазоном — WC не включён");
        return;
    }

    /* СЕССИЯ 88: прежде WC разрешался только в жёстком окне
     * [0xC0000000, 0xFEC00000) — на X101CH апертура LFB НИЖЕ 0xC0000000,
     * проверка отрабатывала отказ, и ВЕСЬ UI (окна, курсор, фон) рисовался
     * в uncached-память. Теперь верхняя граница прежняя (IOAPIC 0xFEC00000,
     * LAPIC 0xFEE00000 выше неё), вместо нижней — запрет перекрытия с
     * ДОСТУПНОЙ RAM по карте Multiboot (WC над RAM = потеря записи),
     * PCI BAR'ы проверяет mtrr_bar_overlap. */
    if (b + sz > 0xFEC00000ULL) {
        klog_puts("mtrr: LFB выше IOAPIC (0xFEC00000) — WC не включён");
        return;
    }
    {
        int ramov = mtrr_ram_overlap(mb, b, sz);
        if (ramov > 0) {
            klog_puts("mtrr: диапазон WC пересекает доступную RAM — WC не включён");
            return;
        }
        if (ramov < 0 && b < 0xC0000000ULL) {
            /* карты памяти нет — прежняя консервативная нижняя граница */
            klog_puts("mtrr: нет карты памяти, LFB ниже 0xC0000000 — WC не включён");
            return;
        }
    }

    if (mtrr_bar_overlap(b, sz)) {
        klog_puts("mtrr: диапазон пересекает PCI BAR устройства — WC не включён");
        return;
    }

    /* MTRRdefType: включён ли механизм MTRR (бит E). Fixed-range
     * enable (бит 10) НЕ трогаем никогда. */
    u64 def = msr_read(0x2FF);
    if (!(def & 0x800ULL))
        msr_write(0x2FF, def | 0x800ULL);

    int idx = -1;
    for (int i = 0; i < nvar; i++) {
        if (!(msr_read(0x201 + (u32)i * 2) & 0x800ULL)) { idx = i; break; }
    }
    if (idx < 0) {
        klog_puts("mtrr: свободных переменных MTRR нет — WC не включён");
        return;
    }

    {
        int if_had;
        __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");

        /* СЕССИЯ 83 [FIX-EXC13] — ПРИЧИНА ПАНИКИ «ИСКЛЮЧЕНИЕ #13» НА НЕТБУКЕ.
         * Раньше: msr_write(0x201+2i, (~(sz-1)) | 0x800) писал в MTRRphysMask
         * СТАРШУЮ ПОЛОВИНУ 0xFFFFFFFF — но биты [63:PhysAddrBits] маски
         * ЗАРЕЗЕРВИРОВАНЫ и обязаны быть нулями: на Atom N2600 (36 бит)
         * такая запись даёт #GP(0). В дампе паники это видно напрямую:
         *   ecx=00000207 (MTRRphysMask3), eax=ffc00800 (~4МБ|valid),
         *   edx=ffffffff — зарезервированные биты. QEMU/86Box MTRR не
         * проверяют, поэтому эмулятор не падал, а железо падало.
         * Теперь: ширина физадреса — CPUID 0x80000008 (Saltwell: 36),
         * маска обрезается до него; перед записью — проверка. */
        u32 pabits = 36;
        {
            u32 xa = 0, xb2 = 0, xc2 = 0, xd2 = 0;
            if (__get_cpuid(0x80000008, &xa, &xb2, &xc2, &xd2)) {
                u32 p = xa & 0xFFu;
                if (p >= 12 && p <= 62) pabits = p;
            }
        }
        u64 lim  = ((((u64)1) << pabits) - 1ULL);
        u64 mval = (~(sz - 1)) & lim;
        mval |= 0x800ULL;                                  /* valid */
        if ((mval >> pabits) || ((b & ~0xFFFULL) > lim)) {
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
            klog_puts("mtrr: маска вне физического диапазона — WC не включён");
            return;
        }
        msr_write(0x200 + (u32)idx * 2, (b & ~0xFFULL) | 1ULL);  /* тип 1 = WC */
        msr_write(0x201 + (u32)idx * 2, mval);                   /* маска+valid */
        __asm__ __volatile__("cpuid"
                             :: : "eax", "ebx", "ecx", "edx", "memory");
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        g_mtrr_wc_on = 1;
    }

    /* ВНИМАНИЕ: мини-snprintf ОС не умеет %llx (модификатор l
     * пропускается, аргумент читается как u32) — base всегда < 4 ГиБ
     * (MMIO-дыра), поэтому печатаем через %x от u32. */
    char log[96];
    snprintf(log, sizeof(log),
             "mtrr: LFB WC: base=0x%08x size=%u KiB (MTRR#%d)",
             (u32)b, (unsigned)(sz >> 10), idx);
    klog_puts(log);
}
