/* sdl2_demo.c4.c — пример SDL2-программы для c4 N2600-OS (Task 54).
 *
 * Запуск:
 *   - в редакторе C: Файлы -> открыть -> вставить текст -> F9 (VM-путь);
 *   - в терминале:   cc sdl2_demo.c4.c  и  run SDL2_DEMO.BIN (native).
 *
 * Программа рисует движущийся прямоугольник в СВОЁМ окне через
 * SDL_Renderer, опрашивает клавиатуру (Esc/окно закрыто — выход).
 *
 * #include "SDL.h" работает БЕЗ файлов на диске: заголовок встроен в
 * компилятор c4 (c4_builtin_header). Все функции SDL_* — сисколы
 * (sdl2.c через c4_sdl_call).
 *
 * Особенности c4-версии SDL:
 *   - SDL_Event уплощён: поля события читаются через int*:
 *       int *f = (int *)&ev;
 *       f[0] = type; f[1] = timestamp; f[2] = scancode | x | button;
 *       f[3] = keycode | y;
 *   - окно имеет фиксированный размер (fixed_size): resize не
 *     поддержан, canvas пишет задача программы (модель c4gfx);
 *   - SDL_RunApp предназначен для native-программ (fn — адрес в .bin);
 *     в VM-пути просто вызывайте SDL_* прямо из main().
 */

#include "SDL.h"

int main() {
    int win;
    int ren;
    struct SDL_Event ev;
    int *f;
    int quit;
    int x, y, dx, dy;
    Uint8 r, g, b;
    struct SDL_Rect rc;
    int frame;

    SDL_Init(SDL_INIT_EVERYTHING);

    win = SDL_CreateWindow("SDL2 c4 demo", 100, 80, 320, 240,
                           SDL_WINDOW_SHOWN);
    if (win == 0) {
        printf("no window\n");
        return 1;
    }
    ren = SDL_CreateRenderer(win, 0, SDL_RENDERER_SOFTWARE);
    if (ren == 0) {
        printf("no renderer\n");
        SDL_DestroyWindow(win);
        SDL_Quit();
        return 1;
    }

    x = 20; y = 20; dx = 3; dy = 2;
    quit = 0;
    frame = 0;

    while (quit == 0) {
        while (SDL_PollEvent(&ev)) {
            f = (int *)&ev;
            if (f[0] == SDL_QUIT) quit = 1;
            if (f[0] == SDL_KEYDOWN) {
                if (f[2] == SDL_SCANCODE_ESCAPE) quit = 1;
            }
        }
        if (quit != 0) break;

        r = (frame * 3) & 255;
        g = (frame * 5) & 255;
        b = 128;

        SDL_SetRenderDrawColor(ren, 24, 28, 34, 255);
        SDL_RenderClear(ren);

        rc.x = x; rc.y = y; rc.w = 48; rc.h = 48;
        SDL_SetRenderDrawColor(ren, r, g, b, 255);
        SDL_RenderFillRect(ren, &rc);
        SDL_RenderDrawRect(ren, &rc);

        SDL_SetRenderDrawColor(ren, 255, 220, 90, 255);
        SDL_RenderDrawLine(ren, 0, 0, 319, 239);
        SDL_RenderDrawLine(ren, 319, 0, 0, 239);

        SDL_RenderPresent(ren);
        SDL_Delay(16);

        x = x + dx;
        y = y + dy;
        if (x < 0)   { x = 0;   dx = 0 - dx; }
        if (y < 0)   { y = 0;   dy = 0 - dy; }
        if (x > 272) { x = 272; dx = 0 - dx; }
        if (y > 192) { y = 192; dy = 0 - dy; }

        frame = frame + 1;
        if (frame > 1800) quit = 1;   /* страховка: ~30 c и выход */
    }

    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
    printf("sdl2 demo done, %d frames\n", frame);
    return 0;
}
