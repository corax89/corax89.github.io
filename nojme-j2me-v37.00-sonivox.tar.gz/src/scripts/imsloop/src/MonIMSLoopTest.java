import javax.microedition.midlet.MIDlet;

/**
 * v36.91 [MON-EXIT-FREE]+[JOIN-CAP] e2e selftest — the Metal Slug 6 (I-Play)
 * exit-hang family in miniature.
 *
 * Field chain (log 2026-10-07): the game thread holds the key-state monitor
 * across a long operation; the frontend blocks on it for 20 s until MON-STEAL
 * force-releases; the owner's own monitorexit then throws
 * IllegalMonitorStateException; the compiler-generated handler of the
 * synchronized block (astore; aload; monitorexit; athrow — Metal Slug:
 * at.run [606,709)->704) catches its OWN IllegalMonitorStateException from
 * monitorexit@708 and loops forever: IMS -> handler -> monitorexit -> IMS ...
 * ("[SPIN-BREAK] site at.run@708 ... catch recovers" — it never recovers).
 * The game's destroyApp() does Thread.join() on that thread -> the app never
 * exits, only a kill helps.
 *
 * This test:
 *   1. thread "holder"  — holds LOCK for 25 s inside synchronized (sleeps);
 *   2. thread "contender" — blocks on LOCK; at 20 s the VM's MON-STEAL
 *      force-releases it, contender acquires and releases (monitor now free);
 *   3. holder wakes at 25 s and executes monitorexit on the STOLEN monitor:
 *      pre-v36.91 -> IMS loop (RECOVERED never printed, holder spins
 *      forever); v36.91 [MON-EXIT-FREE] -> already-free monitor treated as
 *      released -> holder continues and prints IMSLOOP:RECOVERED;
 *   4. holder then starts "spinner" (a thread that never exits);
 *   5. destroyApp(): holder.join(30000) (bounded), then spinner.join()
 *      (unbounded) — v36.91 [JOIN-CAP] aborts it after 5 s and the session
 *      tears down cleanly (IMSLOOP:DESTROYED, process exit).
 *
 * PASS: [MON-STEAL] + IMSLOOP:RECOVERED + IMSLOOP:PHASE2 + [JOIN-CAP] +
 * IMSLOOP:DESTROYED + clean process exit.
 */
public class MonIMSLoopTest extends MIDlet {
    static final Object LOCK = new Object();
    volatile boolean stop = false;
    volatile boolean phase2 = false;
    Thread holderThread;
    Thread spinnerThread;

    protected void startApp() {
        holderThread = new Thread(new Runnable() { public void run() {
            int catches = 0;
            long t0 = System.currentTimeMillis();
            while (!stop) {
                try {
                    synchronized (LOCK) {
                        if (!phase2) {
                            long h0 = System.currentTimeMillis();
                            while (System.currentTimeMillis() - h0 < 25000) {
                                try { Thread.sleep(100); }
                                catch (InterruptedException ie) {}
                            }
                        } else {
                            try { Thread.sleep(50); }
                            catch (InterruptedException ie) {}
                        }
                    }
                } catch (Throwable t) {
                    catches++;
                    if (catches <= 3)
                        System.out.println("IMSLOOP: catch #" + catches + ": " + t);
                }
                if (!phase2 && System.currentTimeMillis() - t0 >= 25000) {
                    System.out.println("IMSLOOP:RECOVERED catches=" + catches);
                    phase2 = true;
                    spinnerThread = new Thread(new Runnable() { public void run() {
                        while (true) {
                            try { Thread.sleep(1000); }
                            catch (InterruptedException ie) { return; }
                        }
                    }}, "spinner");
                    spinnerThread.start();
                    System.out.println("IMSLOOP:PHASE2 started");
                    /* give the frame thread a moment, then drive the AMS
                     * exit path: notifyDestroyed -> destroyApp(true) ->
                     * holder.join(30000) + spinner.join() [JOIN-CAP] */
                    try { Thread.sleep(2000); } catch (InterruptedException ie) {}
                    System.out.println("IMSLOOP:NOTIFY-DESTROYED");
                    notifyDestroyed();
                }
            }
            System.out.println("IMSLOOP:A-EXIT");
        }}, "holder");
        holderThread.start();

        new Thread(new Runnable() { public void run() {
            synchronized (LOCK) {
                System.out.println("IMSLOOP:B-ACQUIRED (post-steal)");
            }
        }}, "contender").start();

        System.out.println("IMSLOOP: started");
    }

    protected void pauseApp() {}

    protected void destroyApp(boolean unconditional) {
        stop = true;
        /* notifyDestroyed delivers destroyApp INLINE on the calling thread
         * (the holder here) — never join self. The field scenario joins
         * from the frame thread (l.destroyApp@0). */
        if (holderThread != null && Thread.currentThread() != holderThread) {
            try { holderThread.join(30000); } catch (InterruptedException ie) {}
        }
        if (spinnerThread != null) {
            /* join() WITHOUT timeout on a thread that never exits — the
             * exact field pattern; [JOIN-CAP] must bound it. */
            try { spinnerThread.join(); } catch (InterruptedException ie) {}
        }
        System.out.println("IMSLOOP:DESTROYED");
    }
}
