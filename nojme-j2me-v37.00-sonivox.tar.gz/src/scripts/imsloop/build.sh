#!/bin/bash
# Build MonIMSLoopTest.jar — v36.91 [MON-EXIT-FREE]+[JOIN-CAP] selftest.
# Run:  NOJME_LOG=1 NOJME_HEADLESS_MAX_MS=120000 timeout 90 ./bin/j2me-headless \
#        scripts/imsloop/MonIMSLoopTest.jar
# Expect (v36.92 [STEAL-GATE] semantics — the 25 s holder sleeps = ALIVE owner,
# so the steal is SUPPRESSED and the block exits naturally):
#   [STEAL-GATE] "steal suppressed" (owner alive), IMSLOOP:RECOVERED
#   catches=0 (NO IMS needed anymore), IMSLOOP:PHASE2, [JOIN-CAP],
#   IMSLOOP:DESTROYED, clean exit.
# v36.91-and-earlier behavior: [MON-STEAL] at 20 s (sleep-loop owner was
# treated as hung), IMS via stolen monitorexit, RECOVERED via the catch path.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/MonIMSLoopTest.java" \
    "$D/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: M, , MonIMSLoopTest\r\nMIDlet-Name: M\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/MonIMSLoopTest"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/MonIMSLoopTest.jar" META-INF && zip -q "$D/MonIMSLoopTest.jar" *.class )
echo "built: $D/MonIMSLoopTest.jar"
