#!/bin/bash
# v36.103 [DEEP-NOCSPLIT]: build RecBench.jar (deep-recursion correctness).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
OUT="$D/out"
STUBS="$D/../densebench/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/RecBench.java" \
    "$STUBS/javax/microedition/midlet/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: R, , RecBench\r\nMIDlet-Name: RecBench\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/RecBench*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/RecBench.jar" META-INF && zip -q "$D/RecBench.jar" *.class )
echo "built: $D/RecBench.jar"
