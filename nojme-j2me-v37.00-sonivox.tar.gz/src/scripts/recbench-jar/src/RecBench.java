import javax.microedition.midlet.MIDlet;
public class RecBench extends MIDlet {
    static long deep(int n) { return n <= 0 ? 0 : n + deep(n - 1); }
    static long deepV(Object o, int n) { return n <= 0 ? 1 : deepV(o, n - 1); }
    static int deepI(int n) { return n <= 0 ? 7 : deepI(n - 1) + 1; }
    public void startApp() {
        int[] ds = {100, 110, 150, 200, 255, 256, 257, 300, 511, 512, 513, 600, 1000, 1500, 2000};
        int bad = 0;
        for (int i = 0; i < ds.length; i++) {
            int n = ds[i];
            long expect = (long)n * (n + 1) / 2;
            try {
                long s = deep(n);
                boolean ok = (s == expect);
                if (!ok) bad++;
                System.out.println("REC:d" + n + "=" + (ok ? "OK" : ("WRONG+" + (s - expect))));
            } catch (Throwable t) { System.out.println("REC:d" + n + " caught " + t); }
        }
        try { System.out.println("REC:i2000=" + deepI(2000)); } catch (Throwable t) { System.out.println("REC:i2000 caught " + t); }
        try { System.out.println("REC:v1500=" + deepV(new Object(), 1500)); } catch (Throwable t) { System.out.println("REC:v1500 caught " + t); }
        try { System.out.println("REC:d5000=" + deep(5000)); } catch (Throwable t) { System.out.println("REC:d5000 caught " + t); }
        System.out.println("REC:DONE bad=" + bad);
        notifyDestroyed();
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
