#!/bin/bash
# v36.103 [FAST-INVOKES]/[DEEP-NOCSPLIT]: deep-recursion correctness.
# PASS: every depth d100..d2000 sums OK, i2000/v1500 correct, d5000 =
# CAUGHT java.lang.StackOverflowError (no SIGSEGV), bad=0.
set -u
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/zrecb
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/recbench-jar/RecBench.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1 NOJME_SWITCH_KEYS="A:400,A:800,EXIT:20000"
timeout -k 5 30 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
out=$(grep -a "REC:" "$D/err.log" | grep -v TRACE)
echo "$out"
ok=$(echo "$out" | grep -c "=OK")
so=$(echo "$out" | grep -c "d5000 caught java.lang.StackOverflowError")
bad=$(echo "$out" | grep -c "WRONG")
if [ "$ok" -ge 15 ] && [ "$so" = "1" ] && [ "$bad" = "0" ] && echo "$out" | grep -q "DONE bad=0"; then
    echo "RECBENCH: ALL PASSED"
else
    echo "RECBENCH: FAILED (ok=$ok so=$so bad=$bad)"
    exit 1
fi
