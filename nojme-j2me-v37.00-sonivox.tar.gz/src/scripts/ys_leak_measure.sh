#!/bin/bash
# [YS-LEAK-MEASURE] (yetifix4) Измерение роста C-хипа во время долгого сидения
# в главном меню Yeti (устройство: 248MB T0 / 155MB после teardown за 183с).
# На ИСПРАВЛЕННОМ коде (PLAYERUPDATE-ARGS). RSS сэмплируется каждые 5с.
# Аргумент: on|off — audio (музыка меню = источник media-событий).
set -u
cd "$(dirname "$0")/../nojme/nojme-j2me" || exit 1

AUDIO="${1:-on}"
UI=/tmp/ysfix4ui1234
GAMES=/tmp/ysfix4games1234567
SAVES=/tmp/ysfix4saves1234567
YS="/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar"

rm -rf "$UI" "$GAMES" "$SAVES"
mkdir -p "$UI" "$GAMES" "$SAVES/Yeti Sports (00.02.51)[240x320]"
cp "$YS" "$GAMES/Yeti Sports (00.02.51)[240x320].jar" || exit 1
cp /tmp/ys_nameflow/saves/"Yeti Sports (00.02.51)[240x320]"/*.rms \
   "$SAVES/Yeti Sports (00.02.51)[240x320]/" 2>/dev/null

cat > "$UI/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=linear
audio=$AUDIO
vm_speed=normal
logging=on
battery=off
keyhint=on
saves_dir=$SAVES
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$GAMES"
export NOJME_SWITCH_UI_DIR="$UI"
export XDG_DATA_HOME="$UI/xdg"

# меню -> запуск -> X в диалоге -> '5' сплэш -> МЕНЮ 145с (музыка крутится)
export NOJME_SWITCH_KEYS="A:1200,A:500"
export NOJME_GAME_KEYS="W:7000,53:400,W:3000,-6:400,W:11000,53:300"

DUR=150
./bin/switchui-verify > /tmp/ys_leak_out.log 2> /tmp/ys_leak_err.log &
PID=$!
RSSF=/tmp/ys_leak_rss.txt
: > "$RSSF"
( for i in $(seq 1 $((DUR/5))); do
    sleep 5
    [ -d /proc/$PID ] || break
    R=$(grep VmRSS /proc/$PID/status 2>/dev/null | awk '{print $2}')
    H=$(grep -c "fl=" /dev/null)
    echo "$(date +%s) $R" >> "$RSSF"
  done ) &
MON=$!
wait $PID 2>/dev/null
kill $MON 2>/dev/null
echo "=== RSS-таймлайн (КБ) audio=$AUDIO ==="
cat "$RSSF"
echo "=== финал ==="
tail -3 "$RSSF"
