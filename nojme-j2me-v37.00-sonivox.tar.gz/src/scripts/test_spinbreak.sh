#!/bin/bash
# v36.57 [SPIN-BREAK]+[PAINT-BUDGET] e2e: TestSpinBreak.jar на switchui-verify.
# Спин 8с в synchronized на игровом потоке, paint берёт тот же монитор.
# PASS: CAUGHT-SPIN-BREAK ×3, SURVIVED-ALL, кадры после спинов, ни одного
# STUCK > 5с, фронтенд жив (PAINT-BUDGET или живые repaints в фазе спина).
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tsb
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/spinjar/TestSpinBreak.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:600,EXIT:30000"
timeout -k 5 70 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

ok=1
n_break=$(grep -ac "CAUGHT-SPIN-BREAK" "$D/err.log")
grep -aq "SURVIVED-ALL" "$D/err.log" || { echo "FAIL: поток не выжил (нет SURVIVED-ALL)"; ok=0; }
[ "$n_break" -ge 2 ] || { echo "FAIL: SPIN-BREAK сработал $n_break раз (<2)"; ok=0; }
stuck=$(grep -ac "STUCK:" "$D/err.log")
[ "$stuck" -eq 0 ] || { echo "FAIL: STUCK строк: $stuck"; ok=0; }
grep -aq "SPIN-BREAK\]" "$D/err.log" || { echo "FAIL: нет [SPIN-BREAK] трейс-строки"; ok=0; }
frames_after=$(grep -a "SURVIVED-ALL frames=" "$D/err.log" | sed 's/.*frames=//' | tr -d '\r')
echo "SPIN-BREAK поймано: $n_break; кадров всего: $frames_after; PAINT-BUDGET: $(grep -ac 'PAINT-BUDGET' "$D/err.log"); MON-STEAL: $(grep -ac 'MON-STEAL' "$D/err.log")"
grep -a "SPIN-BREAK\]\|PAINT-BUDGET\|CAUGHT-SPIN-BREAK\|SURVIVED-ALL" "$D/err.log" | grep -av alive | head -10
[ $ok -eq 1 ] && echo "SPINBREAK E2E: ALL CHECKS PASSED" || echo "SPINBREAK E2E: FAILED"
exit $((1-ok))
