#!/bin/bash
# v36.53/v36.62 [LENIENT-UTF8] E2E-автотест: CharsetStageTest через фронтенд
# switchui-verify — НАСТОЯЩИЙ путь new String(byte[],int,int) с платформенным
# дефолтом UTF-8 (как Doom RPG [Rus]: d.a -> new String(a, 0, s2)).
# Проверки SYSOUT:
#   CS:103,111,192,235,252,33,65  — осиротевшие lead 0xC0/0xEB/0xFC идут
#     сквозным widening (ДО фикса: 65533 = U+FFFD — «пропадающие буквы»);
#   CS2:0,120                     — C0 80 -> U+0000 (modified UTF-8) цел;
#   CS3:1055,113                  — валидный UTF-8 (U+041F) цел;
#   CHARSETSTAGE:DONE.
set -e
cd "$(dirname "$0")/.." || exit 1
T=$(pwd)
BIN="$T/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (scripts/build_verify_host.sh)"; exit 1; }
JAR="$T/scripts/charsetstage/CharsetStageTest.jar"
[ -f "$JAR" ] || bash "$T/scripts/charsetstage/build.sh" >/dev/null

W=$(mktemp -d /tmp/charsetstage_run.XXXX)
mkdir -p "$W/sdmc:/switch/j2me/games"
cp "$JAR" "$W/sdmc:/switch/j2me/games/"
(
    cd "$W" || exit 1
    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
    export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
    export NOJME_SWITCH_KEYS="A:500,A:500,EXIT:8000"
    timeout -k 5 30 "$BIN" > out.log 2>&1 || true
)
L=$(mktemp -u /tmp/charsetstage_out.XXXX)
cp "$W/out.log" "$L"
rm -rf "$W"

grep -q "\[SYSOUT\] CS:103,111,192,235,252,33,65" "$L" || { echo "FAIL: пасстрю шифр-байтов не работает (ожидалось 192/235/252, не 65533)"; grep "CS:" "$L"; exit 1; }
grep -q "\[SYSOUT\] CS2:0,120" "$L" || { echo "FAIL: C0 80 -> U+0000 сломан"; exit 1; }
grep -q "\[SYSOUT\] CS3:1055,113" "$L" || { echo "FAIL: валидный UTF-8 затронут"; exit 1; }
grep -q "\[SYSOUT\] CHARSETSTAGE:DONE" "$L" || { echo "FAIL: нет DONE"; exit 1; }
echo "CHARSETSTAGE: ALL CHECKS PASSED (widening 192/235/252, C080=U+0, valid UTF-8 intact)"
