import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

/* v36.106 [RMS-SAVEGUARD] — репродуктор персистентности RMS для
 * scripts/test_rmsguard.sh (bin/switchui-verify, E2E).
 *
 * В отличие от TestRMS (спека JSR 118, стор УДАЛЯЕТСЯ в конце), этот
 * мидлет ОСТАВЛЯЕТ данные на диске и каждой сессией:
 *   - открывает/создаёт стор "TSG";
 *   - если есть записи — читает ПОСЛЕДНЮЮ (id = n) и печатает её содержимое
 *     (ожидается "r<n-1>" — маркер прошлой сессии);
 *   - добавляет новую запись "r<n>" (мутация -> dirty -> сохранение на
 *     teardown сессии);
 *   - печатает "TSG:PERSIST n=<итог> prev=<прочитано|none>" и "TSG:DONE".
 *
 * Оракул теста: после порчи .rms и восстановления из .rms.old поле prev
 * показывает ДАННЫЕ ВОССТАНОВЛЕННОГО состояния (минус последняя сессия —
 * ровно семантика «прошлый прогресс важнее последнего сохранения»). */
public class TestRMSG extends MIDlet {
    static String cls(Throwable t) { return t == null ? "-" : t.getClass().getName(); }

    public void startApp() {
        String prev = "none";
        int n = 0;
        String err = "";
        try {
            RecordStore rs = RecordStore.openRecordStore("TSG", true);
            n = rs.getNumRecords();
            if (n > 0) {
                try {
                    byte[] b = rs.getRecord(n); /* последняя добавленная: id монотонны */
                    if (b != null) prev = new String(b);
                } catch (Throwable t) { prev = "ERR:" + cls(t); }
            }
            byte[] add = ("r" + n).getBytes();
            rs.addRecord(add, 0, add.length);
            rs.closeRecordStore();
        } catch (Throwable t) {
            err = " TSG:ERR " + cls(t);
        }
        System.out.println("TSG:PERSIST n=" + (n + 1) + " prev=" + prev + err);
        System.out.println("TSG:DONE");
        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
