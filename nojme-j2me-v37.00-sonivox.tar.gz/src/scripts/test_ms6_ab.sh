#!/bin/bash
# MS6-репро: запуск Metal Slug 6 (I-Play) с медиа-логом, аудит аудио-пути.
set -u
cd "$(dirname "$0")/.." || exit 1
# Производный jar: оригинал + подложенные звуковые файлы под именами,
# которые движок ожидает (musicStageSelect.mid / musicStage1.mid = копии
# ding.mid из этого же jar; sfxMenuSelect.wav = тестовый wav).
BASE="${MS6_JAR:-scripts/ms6stage/Metal Slug 6 (I-Play)(1.0.1).jar}"
[ -f "$BASE" ] || { echo "SKIP: нет $BASE"; exit 0; }
JAR=/tmp/ms6_fixed.jar
rm -rf /tmp/ms6mk && mkdir -p /tmp/ms6mk
unzip -q -o "$BASE" ding.mid -d /tmp/ms6mk
cp /tmp/ms6mk/ding.mid /tmp/ms6mk/musicStageSelect.mid
cp /tmp/ms6mk/ding.mid /tmp/ms6mk/musicStage1.mid
cp scripts/testaudio/res/t1.wav /tmp/ms6mk/sfxMenuSelect.wav
rm -f "$JAR"
cp "$BASE" "$JAR"
( cd /tmp/ms6mk && zip -q "$JAR" musicStageSelect.mid musicStage1.mid sfxMenuSelect.wav )
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/tms6ab
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/ms6ab.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=on
vm_speed=normal
logging=on
EOF
cat > "$D/sdmc:/switch/j2me/pergame/ms6ab.jar.ini" <<'EOF'
res=240x320
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_MEDIA_DEBUG=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
# Прогрев + меню-навигация: A (старт/выбор), задержки, чтобы игра успела
# пройти заставки и попытаться играть звук/музыку.
export NOJME_SWITCH_KEYS="A:90000"
export NOJME_FRONT_KEYS="A:6000,A:6000,A:6000,A:8000,A:6000,A:8000,A:6000,A:8000"
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (make switchui-verify)"; exit 1; }
( cd "$D" && timeout -k 10 100 "$BIN" > out.log 2> err.log ) || true

LOG="$D/sdmc:/switch/j2me/log.txt"
ERR="$D/err.log"
[ -s "$LOG" ] || { echo "FAIL: log.txt пуст/отсутствует"; exit 1; }
ok=1
# AB: файлы на месте -> ранние попытки звука БОЛЬШЕ не дают MediaException
# (в отличие от оригинального jar), загрузка успешно парсится
grep -aq "midi_load size=" "$ERR" || { echo "FAIL: нет midi_load"; ok=0; }
grep -aq "WAV parsed" "$ERR" || { echo "FAIL: нет WAV parsed"; ok=0; }
nms=$(awk 'match($0, /[0-9]+ .EX-THROW. javax.microedition.media.MediaException "Empty/) { print }' "$LOG" | awk -F'[ ]' '$1 < 40000' | wc -l)
[ "${nms:-0}" -eq 0 ] || { echo "FAIL: ранние (<40 c) MediaException по пустым потокам = $nms (подложенные файлы не подхватились)"; ok=0; }
echo "midi_load/WAV parsed подтверждены; ранних empty-stream MediaException: $nms (хотим 0)"
[ "$ok" = 1 ] && echo "MS6-AB: ALL CHECKS PASSED" || { echo "MS6-AB: FAILED"; exit 1; }
