#!/bin/bash
# v37.00 [SAVE-WAIT] smoke: ручной выход из игры (меню паузы -> «Выйти»)
# обязан показать экран «ожидается завершение сохранения» и чисто
# вернуться в меню фронтенда. Проверки:
#   1) трейс «save-wait: shown» (экран выдан ДО destroyApp);
#   2) «[SWITCH] pause menu -> exit game» (путь ручного выхода);
#   3) «game: session end» (teardown дошёл до конца);
#   4) НЕТ «[UI-PRESENT-FAIL] save-wait» (кадр дошёл до рендерера);
#   5) строки RU/EN в бинарнике (таблица ST_SAVE_WAIT собрана).
# Использование: test_savewait.sh [метка]
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/zsavewait
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/benchjar/Bench.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
# фронтенд-автотест: A выбирает/запускает игру, EXIT закрывает меню после
# возврата (позиция скрипта переживает сессию — v34.91 default semantics).
export NOJME_SWITCH_KEYS="A:1500,A:500,EXIT:25000"
# кнопочный сценарий В ИГРЕ (FRONT_KEYS достаёт до игрового насоса):
# MINUS открывает меню паузы, DOWN x3 — «Выйти», A подтверждает.
export NOJME_FRONT_KEYS="MINUS:6000,DOWN:900,DOWN:300,DOWN:300,A:700"
timeout -k 5 45 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

ok=0
grep -aq "save-wait: shown" "$D/err.log"                && ok=$((ok+1))
grep -aq "pause menu -> exit game" "$D/err.log"         && ok=$((ok+1))
grep -aq "game: session end" "$D/err.log"               && ok=$((ok+1))
grep -aq "UI-PRESENT-FAIL. save-wait" "$D/err.log"      || ok=$((ok+1))
# строки ищем в бинарнике напрямую (grep -a): `strings` в C-локали
# НЕ выводит кириллицу (байты >0x7F не считаются printable)
grep -aq "ожидается завершение сохранения" ./bin/switchui-verify \
                                                        && ok=$((ok+1))
grep -aq "Waiting for save to complete" ./bin/switchui-verify \
                                                        && ok=$((ok+1))
echo "SAVEWAIT[$1]: $ok/6 checks"
grep -a "save-wait\|pause menu -> exit\|session end\|UI-PRESENT-FAIL\|menu exit" \
     "$D/err.log" | head -8
[ "$ok" -eq 6 ] || exit 1
exit 0
