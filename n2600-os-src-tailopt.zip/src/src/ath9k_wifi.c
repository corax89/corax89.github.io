/* ath9k_wifi.c — драйвер Atheros WiFi (порт Linux ath9k, GPLv2) для N2600-OS.
 *
 * Поддерживаемые чипы (PCI vendor 0x168c):
 *   AR9285 (002b), AR9287 (002e) — семейство Owl
 *   AR9485 (0032)                — семейство Sowl (AR9003)
 *
 * СЕССИЯ 28: чипо-независимая часть (журнал, скан, beacon-парсер,
 * машина подключения, WPA2-PSK, мост 802.11<->Ethernet) вынесена в
 * wifi_core.c — здесь остался только «железный» код: probe PCI,
 * bring-up (reset/PLL/ini/калибровки), DMA RX, TX-дескрипторы,
 * keycache, смена канала. Драйвер регистрирует wifi_hw_ops_t через
 * wifi_core_bind() (см. ath9k_wifi_probe в конце файла).
 *
 * Приём — polling (без прерываний): wifi_poll() из главного цикла.
 * Подробный журнал этапов доступен приложению WiFi и dmesg (wifi_log_tail).
 *
 * Источник: Linux (GPLv2) drivers/net/wireless/ath/ath9k/. Лицензия GPL.
 */
#include "ath9k_wifi.h"
#include "wifi_core.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "kernel.h"
#include "sync.h"
#include "ath9k_ini_data.h"
#include "wpa2.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);
extern int  vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* ================= регистры (сверены с reg.h/mac.h Linux ath9k) ================= */

/* MAC DMA / global */
#define AR_CR               0x0008
#define AR_CR_RXE_OWL       0x00000004    /* pre-AR9003 */
#define AR_CR_RXE_SOWL      0x0000000C    /* AR9003+ */
#define AR_CR_RXD           0x00000020
#define AR_RXDP             0x000C        /* RX desc pointer (owl) */
#define AR_HP_RXDP          0x0074        /* EDMA HP FIFO (sowl) */
#define AR_LP_RXDP          0x0078        /* EDMA LP FIFO (sowl) */
#define AR_CFG              0x0014
#define AR_CFG_AP_ADHOC_IND 0x00000020
#define AR_IER              0x0024        /* global int enable (0 = тишина) */
#define AR_ISR              0x0080
#define AR_ISR_S0           0x0084   /* QCU_TXOK 9:0 | QCU_TXDESC 25:16 */
#define AR_ISR_S0_QCU_TX    0x03FF03FFu
#define AR_ISR_S1           0x0088   /* QCU_TXERR 9:0 | QCU_TXEOL 25:16 */
#define AR_TXCFG            0x0030
#define AR_RXCFG            0x0034
#define AR_RXCFG_ZLFDMA     0x00000010   /* сброс RX-DMA при PHY-err (ref reg.h) */
#define AR_PHY_ERR          0x810c       /* маски PHY-ошибок: кадр с ошибкой
                                          * тайминга кладётся в RX-кольцо */
#define AR_PHY_ERR_OFDM_TIMING  0x00020000
#define AR_PHY_ERR_CCK_TIMING   0x02000000
#define AR_DATABUF_SIZE     0x0060
#define AR_GTXTO            0x0064
#define AR_CST              0x006C
#define AR_RXFIFO_CFG       0x8114
#define AR_D0_QCUMASK       0x1000

#define AR_RC               0x4000        /* bus reset (pre-AR9003) */
#define AR_RC_AHB           0x00000001
#define AR_WA               0x4004        /* AR9003+ work-around */
#define AR_SREV_REG         0x4020
#define AR_AHB_MODE         0x4024
#define AR_AHB_PREFETCH     0x00000004
#define AR_GPIO_IN_EN_VAL   0x4054
#define AR_GPIO_JTAG_DIS    0x00020000
#define AR_OBS              0x4080

/* RTC (Owl/AR9003 merged MAC: absolute offset от BAR0) */
#define AR_RTC_RC           0x7000
#define AR_RTC_RC_MAC_WARM  0x00000001
#define AR_RTC_RC_MAC_COLD  0x00000002
#define AR_RTC_PLL_CONTROL  0x7014
#define AR_RTC_RESET        0x7040
#define AR_RTC_RESET_EN     0x00000001
#define AR_RTC_STATUS       0x7044
#define AR_RTC_STATUS_M     0x0000000f
#define AR_RTC_STATUS_ON    0x00000002
#define AR_RTC_SLEEP_CLK    0x7048
#define AR_RTC_FORCE_DERIVED_CLK 0x2
#define AR_RTC_FORCE_WAKE   0x704c
#define AR_RTC_FORCE_WAKE_EN     0x00000001
#define AR_RTC_FORCE_WAKE_ON_INT 0x00000002

/* PCU */
#define AR_STA_ID0          0x8000
#define AR_STA_ID1          0x8004
#define AR_STA_ID1_STA_AP       0x00010000
#define AR_STA_ID1_ADHOC        0x00020000
#define AR_STA_ID1_PWR_SAV      0x00040000
#define AR_STA_ID1_KSRCH_MODE   0x10000000
#define AR_STA_ID1_PRES_SEQNUM  0x20000000
#define AR_STA_ID1_RTS_USE_DEF  0x00800000  /* [W-STAID1DEF] RTS/CTS/ACK ПКУ на дефолтной антенне (эталон reg.h) */
#define AR_STA_ID1_CRPT_MIC     0x08000000  /* [W-STAID1] HW-Michael (эталон sta_id1_defaults) */
#define AR_STA_ID1_MCAST_KSRCH  0x80000000  /* [W-STAID1DEF] кейсерч для multicast (групповой TKIP RX) */
#define AR_RSSI_THR         0x8018       /* [W-PCUDUMP] порог RSSI + beacon-miss (эталон: 0x700) */
#define AR_BSS_ID0          0x8008
#define AR_BSS_ID1          0x800C
#define AR_BSSMSKL          0x80E0
#define AR_BSSMSKU          0x80E4
#define AR_RX_FILTER        0x803C
#define AR_MCAST_FIL0       0x8040
#define AR_MCAST_FIL1       0x8044
#define AR_DIAG_SW          0x8048
#define AR_DIAG_RX_DIS      0x00000020
#define AR_DIAG_RX_ABORT    0x02000000
#define AR_DIAG_ACK_DIS     0x00000002  /* [W-STAID1] запрет аппаратного ACK */
#define AR_DIAG_CTS_DIS     0x00000004  /* [W-STAID1] запрет аппаратного CTS */
#define AR_DEF_ANTENNA      0x8058
#define AR_2040_MODE        0x8318
#define AR_SELFGEN_MASK     0x832c
#define AR_PCU_MISC_MODE2   0x8344
#define AR_PCU_MM2_ADHOC_KEYID  0x00000040
#define AR_PCU_MM2_CFP_IGNORE   0x00000080
#define AR_PCU_MM2_HWWAR1       0x00100000
#define AR_PCU_MM2_MGMT_CRYPTO      0x00000002  /* [W-MM2CRYPT] шифровать mgmt железом */
#define AR_PCU_MM2_NO_CRYPTO_NONDATA 0x00000004 /* [W-MM2CRYPT] НЕ шифровать не-данные (mgmt/ctrl) */
#define AR_AGG_WEP_ENABLE_FIX   0x00000008
#define AR_AGG_WEP_ENABLE       0x00020000

#define RXF_UCAST   0x00000001
#define RXF_MCAST   0x00000002
#define RXF_BCAST   0x00000004
#define RXF_CONTROL 0x00000008
#define RXF_BEACON  0x00000010
#define RXF_PROM    0x00000020
#define RXF_PHYERR  0x00000100  /* [W-PHYERRFILT] доставлять PHY-ошибочные кадры (диагностика «немых» потерь) */

/* [W-IFSTIME] Глобальные тайминги MAC + таймаут ACK/CTS (эталон reg.h).
 * Полевой лог итерации 5: INI программирует 0x8014 (AR_TIME_OUT) = 0 и
 * НЕ программирует SIFS/SLOT — после сброса окно ожидания ACK = 0:
 * кадр уходит (SendTimestamp пишется, TXE гаснет), но ACK железо не
 * засчитывает НИКОГДА (DataFailCnt=7, ExcessiveRetries) при слышимой
 * точке. В Linux это перепрограммирует ath9k_hw_init_global_settings. */
#define AR_TIME_OUT          0x8014
#define AR_TIME_OUT_ACK_M    0x00003FFFu
#define AR_TIME_OUT_ACK_S    0
#define AR_TIME_OUT_CTS_M    0x3FFF0000u
#define AR_TIME_OUT_CTS_S    16
#define AR_USEC              0x801c
#define AR_USEC_USEC_M       0x0000007Fu
#define AR_USEC_TX_LAT       0x007FC000u
#define AR_USEC_TX_LAT_S     14
#define AR_USEC_RX_LAT       0x1F800000u
#define AR_USEC_RX_LAT_S     23
#define AR_D_GBL_IFS_SIFS    0x1030
#define AR_D_GBL_IFS_SLOT    0x1070

/* PHY (Owl) */
#define AR_PHY_TURBO        0x9804
#define AR_PHY_FC_DYN2040_EN    0x00000008
#define AR_PHY_FC_HT_EN         0x00000040
#define AR_PHY_FC_SHORT_GI_40   0x00000080
#define AR_PHY_FC_WALSH         0x00000100
#define AR_PHY_FC_SINGLE_LTF1   0x00000200
#define AR_PHY_FC_DAC_FIFO      0x00000800
#define AR_PHY_TIMING3      0x9814
#define AR_PHY_TIMING3_DSC_MAN  0xFFFE0000
#define AR_PHY_TIMING3_DSC_MAN_S 17
#define AR_PHY_TIMING3_DSC_EXP  0x0001E000
#define AR_PHY_TIMING3_DSC_EXP_S 13
#define AR_PHY_ACTIVE       0x981C
#define AR_PHY_ACTIVE_EN    0x00000001
#define AR_PHY_ADC_CTL      0x982C
#define AR_PHY_ADC_OFF_PWDADC 0x00008000
#define AR_PHY_ADC_SERIAL_CTL 0x9830
#define AR_PHY_SEL_EXT_RADIO  0x00000001
#define AR_AGC_CTL_OWL      0x9860
#define AR_PHY_CCA          0x9864
#define AR_PHY_SYNTH_CONTROL 0x9874
#define AR_PHY_RX_DELAY     0x9914
#define AR_PHY_RX_DELAY_MSK 0x00003FFF
#define AR_PHY_HALFGI       0x99D0
#define AR_PHY_HALFGI_DSC_MAN 0x0007FFF0
#define AR_PHY_HALFGI_DSC_MAN_S 4
#define AR_PHY_HALFGI_DSC_EXP 0x0000000F
#define AR_PHY_HALFGI_DSC_EXP_S 0
#define AR_PHY_RFBUS_REQ   0x997C
#define AR_PHY_RFBUS_GRANT 0x9C20
#define AR_PHY_RX_CHAINMASK 0x99a4
#define AR_PHY_MODE         0xA200
#define AR_PHY_MODE_DYNAMIC 0x04
#define AR_PHY_CCK_TX_CTRL  0xA204
#define AR_PHY_CCK_JAPAN    0x00000010
#define AR_PHY_FORCE_CLKEN_CCK 0xA22C
#define AR_PHY_CCK_MRC_MUX  0x00000040
#define AR_PHY_TPCRG1       0xA258
#define AR_PHY_TPCRG1_PD_CAL 0x00400000
#define AR_PHY_CL_CAL_CTL   0xA358
#define AR_PHY_CL_CAL_EN    0x00000002
#define AR_PHY_PAR_CAL_EN   0x00000001
#define AR_PHY_CAL_CHAINMASK 0xA39C

/* AGC_CONTROL bits (общие для семейств) */
#define AGC_CAL         0x00000001
#define AGC_NF          0x00000002
#define AGC_ENABLE_NF   0x00008000
#define AGC_FLTR_CAL    0x00010000
#define AGC_NO_UPDATE_NF 0x00020000

/* PHY (AR9003/Sowl) */
#define AR_AGC_CTL_SOWL    0xa2c4
#define AR_PHY_GEN_CTRL    0xa204   /* AR_SM_BASE(0xa200)+4 — в Owl тут CCK_TX_CTRL */
#define AR_PHY_GC_GF_DETECT 0x00000400
#define AR_PHY_CCA_0_SOWL  0x9e1c   /* AR_AGC_BASE(0x9e00)+0x1c */
#define AR_PHY_65NM_SYNTH4 0x1608c
#define AR_PHY_65NM_SYNTH7 0x16098
#define AR_PHY_SYNTH4_LONG_SHIFT 0x00000002  /* bit 1 (AR9485) */

/* BB DPLL (Sowl) */
#define AR_CH0_BB_DPLL1    0x16180
#define AR_DPLL1_REFDIV    0xF8000000
#define AR_DPLL1_REFDIV_S  27
#define AR_DPLL1_NINI      0x07FC0000
#define AR_DPLL1_NINI_S    18
#define AR_DPLL1_NFRAC     0x0003FFFF
#define AR_CH0_BB_DPLL2    0x16184
#define AR_DPLL2_LOCAL_PLL 0x40000000
#define AR_DPLL2_LOCAL_S   30
#define AR_DPLL2_KI        0x3C000000
#define AR_DPLL2_KI_S      26
#define AR_DPLL2_KD        0x03F80000
#define AR_DPLL2_KD_S      19
#define AR_DPLL2_EN_NEGTRIG 0x00040000
#define AR_DPLL2_EN_NEGTRIG_S 18
#define AR_DPLL2_PLL_PWD   0x00010000
#define AR_DPLL2_PLL_PWD_S 16
#define AR_DPLL2_OUTDIV    0x0000E000
#define AR_DPLL2_OUTDIV_S  13
#define AR_CH0_BB_DPLL3    0x16188
#define AR_DPLL3_PHASE     0x3F800000
#define AR_DPLL3_PHASE_S   23

/* ================= конфигурация драйвера ================= */

#define WIFI_NUM_RXDESC   32        /* кольцо дескрипторов (owl). [W-RXDESC32]
                                    * было 16: во время спина ожидания TxDone
                                    * (до 30 мс) задача poll стоит, на занятом
                                    * канале приходят кадры — кольцо 16 могло
                                    * ЗАКРУТИТЬСЯ и затереть юникаст-ответ точки
                                    * (AUTH/ASSOC), пришедший сразу после TX.
                                    * 32 x 2408 б ≈ 77 КиБ кучи — приемлемо */
#define WIFI_RXBUF_SZ     2408      /* 2344 (max 802.11) + запас */
#define WIFI_EDMA_ST_LEN  44        /* sizeof(ar9003_rxs) */
#define WIFI_EDMA_BUFS    4         /* буферов на очередь (sowl) */
#define WIFI_TS_RING      8         /* записей TX-статуса (sowl, сессия 15) */
#define WIFI_EDMA_QUEUES  2         /* HP + LP */
#define WIFI_SCAN_DWELL   220       /* мс на канал [W-DWELL2]: 2+ интервала маяка
                                    * (~102-113 мс) + перестройка — прежде 110 мс
                                    * ≈ один интервал: маяк регулярно проскакивал
                                    * между окнами. Проход 14×220 = ~3.1 с */
#define WIFI_LOG_LINES    28
#define WIFI_LOG_LINE     96
#define AH_WAIT_TIMEOUT_US 10000    /* как AH_WAIT_TIMEOUT в ath9k */

/* ---- TX (сессия 11): очередь QCU/DCU 0 + дескрипторы AR5416 ---- */
#define AR_Q0_TXDP          0x0800
#define AR_QTXDP(q)         (AR_Q0_TXDP + ((u32)(q) << 2))
#define AR_Q_TXE            0x0840
#define AR_Q_TXE_M          0x000003FF
#define AR_Q_TXD            0x0880
#define AR_PCU_TXBUF_CTRL       0x8340   /* слов в PCU TX-буфере */
#define AR_PCU_TXBUF_USABLE         0x700u  /* эталон hw.c (полный) */
#define AR_9285_PCU_TXBUF_USABLE    0x380u  /* AR9285: FIFO вдвое меньше */
#define AR_Q0_MISC          0x09c0
#define AR_QMISC(q)         (AR_Q0_MISC + ((u32)(q) << 2))
#define AR_Q_MISC_DCU_EARLY_TERM_REQ 0x00000800

#define AR_D0_QCUMASK       0x1000
#define AR_DQCUMASK(q)      (AR_D0_QCUMASK + ((u32)(q) << 2))
#define AR_D_QCUMASK        0x000003FF
#define AR_D0_LCL_IFS       0x1040
#define AR_DLCL_IFS(q)      (AR_D0_LCL_IFS + ((u32)(q) << 2))
#define AR_D_LCL_IFS_CWMIN      0x000003FF
#define AR_D_LCL_IFS_CWMIN_S    0
#define AR_D_LCL_IFS_CWMAX      0x000FFC00
#define AR_D_LCL_IFS_CWMAX_S    10
#define AR_D_LCL_IFS_AIFS       0x0FF00000
#define AR_D_LCL_IFS_AIFS_S     20
#define AR_D0_RETRY_LIMIT   0x1080
#define AR_DRETRY_LIMIT(q)  (AR_D0_RETRY_LIMIT + ((u32)(q) << 2))
#define AR_D_RETRY_LIMIT_FR_SH       0x0000000F
#define AR_D_RETRY_LIMIT_FR_SH_S     0
#define AR_D_RETRY_LIMIT_STA_SH      0x00003F00
#define AR_D_RETRY_LIMIT_STA_SH_S    8
#define AR_D_RETRY_LIMIT_STA_LG      0x000FC000
#define AR_D_RETRY_LIMIT_STA_LG_S    14
#define AR_D0_MISC          0x1100
#define AR_DMISC(q)         (AR_D0_MISC + ((u32)(q) << 2))
#define AR_D_MISC_FRAG_WAIT_EN      0x00000100
#define AR_D_MISC_CW_BKOFF_EN       0x00001000
#define AR_D_MISC_BKOFF_THRESH      0x0000003F

/* INIT-константы mac.h эталона: AIFS=2, CWMIN=15, CWMAX=1023, SSH=32, SLG=32 */
#define AT_INIT_AIFS      2
#define AT_INIT_CWMIN     15
#define AT_INIT_CWMAX     1023
#define AT_INIT_SSH_RETRY 32
#define AT_INIT_SLG_RETRY 32

/* ---- дескриптор AR5416 (owl): layout 1:1 из mac.h struct ar5416_desc ---- */
typedef struct {
    u32 link;
    u32 data;
    u32 ctl0, ctl1, ctl2, ctl3, ctl4, ctl5, ctl6, ctl7, ctl8, ctl9, ctl10, ctl11;
    u32 st[10];    /* tx status 0..9 (пишет железо) */
} owl_txdesc_t;    /* 96 байт */

/* ===================== TX для AR9003/AR9485 (СЕССИЯ 15) =====================
 * AR9485 (sowl) — семейство ar9003: ДРУГОЙ формат TX-дескриптора
 * (24 слова + pad до кэш-линии 128 байт) и статусное КОЛЬЦО вместо
 * статуса в самом дескрипторе. Layout 1:1 из ar9003_mac.h эталона
 * (struct ar9003_txc / struct ar9003_txs):
 *   info  = (0x168c<<16) | TxRxDesc(15) | CtrlStat(14) | (qcu<<8) | 0x17
 *   ctl3  = buf_len << 16;  ctl10 = чексумма (info+link+data0+ctl3+...)
 *   ctl11 = FrameLen | XmitPower0 | DestIdxValid | RTS/CTS
 *   ctl12 = DestIdx | FrameType | NoAck
 *   ctl13 = tries 0..3;  ctl14 = rate 0..3;  ctl17 = EncrType (биты 26-27)
 *   ctl19 = Not_Sounding (всегда — не TxBF)
 * Статус: железо пишет sowl_txs_t в кольцо [AR_Q_STATUS_RING_START..END),
 * готовность = status8 bit0 (AR_TxDone), успех = status3 bit0
 * (AR_FrmXmitOK); после чтения запись чистится (как
 * ath9k_hw_clear_txstatus). Кольцо программируется ДО включения
 * очередей: ath9k_hw_reset_txstatus_ring. */
typedef struct {
    u32 info;     /* дескриптор: DescId|TxRxDesc|CtrlStat|TxQcuNum|desc_len */
    u32 link;     /* 0 = конец списка */
    u32 data0;    /* буфер кадра (физ. = лин. адрес) */
    u32 ctl3;     /* buf_len[27:16] */
    u32 data1, ctl5, data2, ctl7, data3, ctl9;   /* 0: один буфер на кадр */
    u32 ctl10;    /* контрольная сумма указателей (16 бит) */
    u32 ctl11;    /* FrameLen | XmitPower0 | DestIdxValid | RTS/CTS */
    u32 ctl12;    /* DestIdx | FrameType | NoAck */
    u32 ctl13;    /* XmitDataTries 0..3 | DurUpdateEna */
    u32 ctl14;    /* XmitRate 0..3 */
    u32 ctl15, ctl16;  /* PacketDur 0..3 (RTS/CTS; без RTS = 0) */
    u32 ctl17;    /* EncrType (биты 26-27): 0=CLR, 2=AES(CCMP) */
    u32 ctl18;    /* rate flags / ChainSel / RTSCTSRate (0 = legacy) */
    u32 ctl19;    /* Not_Sounding */
    u32 ctl20, ctl21, ctl22, ctl23;   /* XmitPower 1..3 (0) */
    u32 pad[8];   /* до 128 байт (кэш-линия) */
} sowl_txdesc_t;   /* 128 байт */

typedef struct {
    u32 info;     /* DescId|TxRxDesc|TxQcuNum */
    u32 status1;  /* TxDescId */
    u32 status2;  /* RSSI ctl0-2 / BaStatus */
    u32 status3;  /* FrmXmitOK | ExcessiveRetries | Filtered | DataFailCnt */
    u32 status4;  /* timestamp */
    u32 status5, status6;   /* BA bitmap low/high */
    u32 status7;  /* RSSI combined */
    u32 status8;  /* TxDone | FinalTxIdx | SeqNum | TxTid */
} sowl_txs_t;     /* 36 байт */

/* биты TX-статуса ar9003 (mac.h эталона; имена TXS_* не конфликтуют) */
#define TXS3_FrmXmitOK        0x00000001u
#define TXS3_ExcessiveRetries 0x00000002u
#define TXS3_Filtered         0x00000008u
#define TXS8_TxDone           0x00000001u
/* AR_Q_STATUS_RING_START/END (reg.h эталона, 0x830/0x834):
 * END = адрес ЗА последней записью кольца */
#define AR_Q_STATUS_RING_START 0x0830
#define AR_Q_STATUS_RING_END   0x0834

/* ctl0 */
#define TXD_FrameLen       0x00000FFF
#define TXD_XmitPower0     0x003F0000
#define TXD_XmitPower0_S   16
/* ctl1 */
#define TXD_TxMore         0x00001000
#define TXD_FrameType      0x00F00000
#define TXD_FrameType_S    20
#define TXD_NoAck          0x01000000
/* ctl2 */
#define TXD_XmitDataTries0 0x000F0000
#define TXD_XmitDataTries0_S 16
#define TXD_XmitDataTries1 0x00F00000
#define TXD_XmitDataTries1_S 20
#define TXD_XmitDataTries2 0x0F000000
#define TXD_XmitDataTries2_S 24
#define TXD_XmitDataTries3 0xF0000000
#define TXD_XmitDataTries3_S 28
#define TXD_DurUpdateEna   0x00008000
/* ctl3 */
/* ctl7 [W-CHAINSEL]: выбор TX-цепочки PHY для рейта серии (эталон
 * ar9002_set_txdesc -> set11nChainSel; кодировка — битовая маска цепей,
 * как в RX/CAL/SELFGEN-регистрах: 1 = цепь A). 0 = «ни одной цепочки». */
#define TXD_ChainSel0      0x0000001C
#define TXD_ChainSel0_S    2
#define TXD_RTSCTSRate     0x0FF00000
#define TXD_RTSCTSRate_S   20
#define TXD_XmitRate0      0x000000FF
#define TXD_XmitRate0_S    0
#define TXD_XmitRate1      0x0000FF00
#define TXD_XmitRate1_S    8
#define TXD_XmitRate2      0x00FF0000
#define TXD_XmitRate2_S    16
#define TXD_XmitRate3      0xFF000000
#define TXD_XmitRate3_S    24
/* status */
#define TXS_FrmXmitOK      0x00000001   /* st[1] */
#define TXS_ExcessiveRetries 0x00000002
#define TXS_Filtered       0x00000008
#define TXS_TxDone         0x00000001   /* st[9] */
/* сессия 12 (WPA2): шифрование в TX-дескрипторе (mac.h эталона):
 * ctl0: DestIdxValid (бит 30) — запись keycache [W-TXDESC: БЫЛ В CTL1 —
 *   а там бит 30 = AR_IsAggr; исправлено сверкой с ar9002_mac.c]
 * ctl1: DestIdx (биты 13-17);
 * ctl6: EncrType (биты 26-27): 0=CLR, 1=WEP, 2=AES(CCMP), 3=TKIP */
#define TXD_DestIdx        0x000FE000
#define TXD_DestIdx_S      13
#define TXD_DestIdxValid   0x40000000
#define TXD_ClrDestMask    0x01000000   /* ctl0 бит 24 [W-CCMPTX] */
#define TXD_EncrType       0x0C000000   /* ctl6 */
#define TXD_EncrType_S     26
#define TXD_ENCR_AES       2
#define TXD_ENCR_TKIP      3   /* ctl6 EncrType: 3 = TKIP (сессия 25) */

/* ---- keycache (сессия 12: WPA2-CCMP, рег. 0x8800+n*32) ----
 * Раскладка как в ath_key.c (hostap): KEY0..KEY4 — ключ с
 * «рваными» словами (KEY1/KEY3 — 16-битные!), TYPE = CCM(6),
 * MAC0/MAC1 — адрес, сдвинутый вправо на бит, + VALID(0x8000).
 * Парный ключ (PTK): запись 4 с MAC = BSSID (декодирует юникаст
 * по TA). Групповой (GTK): запись = keyid, MAC = 0 + VALID
 * (default-key: выбирается по keyid из CCMP-заголовка кадра). */
#define KC_PTK_ENTRY   4
#define AR_KEYTABLE_BASE      0x8800u
#define AR_KEYTABLE_TYPE_CCM  6u
#define AR_KEYTABLE_VALID     0x8000u

/* ---- legacy-рейты (rc.c эталона, hw-коды 5416) ---- */
#define RATE_CCK_1M        0x1B
#define RATE_CCK_2M        0x1A
#define RATE_CCK_5_5M      0x19
#define RATE_CCK_11M       0x18
#define RATE_OFDM_6M       0x0B

/* ---- EEPROM (PCI: косвенный доступ, [pci.c: ath_pci_eeprom_read]) ---- */
#define AR5416_EEPROM_OFFSET  0x2000
#define AR5416_EEPROM_S       2
#define AR_EEPROM_STAT_OWL    0x407C
#define AR_EEPROM_STAT_SOWL   0x4084
#define EEST_BUSY             0x00010000
#define EEST_PROT_ACCESS      0x00040000
#define EEST_VAL              0x0000FFFF

/* ---- 802.11 ---- */
#define WIFI_TX_QUEUE      0          /* QCU/DCU 0 (данные) */
#define WIFI_TXBUF_SZ      2360       /* 24 hdr + LLC/SNAP 8 + 1500 + запас */
/* [W-FCSLEN] (полевой лог ESP32-сниффера, канал esp32test): в КАЖДОМ
 * исходящем кадре последние 4 байта на проводе — мусор из окна FCS:
 * у AUTH REQ тело читается точкой как alg=0, txn=0, status=<мусор>
 * (эталонный билдер шлёт alg=0, txn=1, status=0 — сверено с
 * [W-AUTHDUMP]) — точка ACK-ит кадр, но молча отбрасывает; у PROBE REQ
 * портится IE Supported Rates (82 84 8B 96 -> мусор). ПРИЧИНА:
 * AR_FrameLen (ctl0) — ЭТО ДЛИНА КАДРА В ЭФИРЕ ВМЕСТЕ С АВТО-FCS.
 * Эталон ath9k xmit.c: framelen = skb->len + FCS_LEN при buf_len =
 * skb->len; мы писали FrameLen = BufLen = len → PCU передавал только
 * (FrameLen-4) байт данных, хвост замещался. Фикс: FrameLen = len + 4
 * (owl ctl0 / sowl ctl11); BufLen (ctl1) остаётся len. Шифрованным
 * кадрам, возможно, нужен ещё хвост криптодвижка (MIC/ICV) — сверить
 * длину на эфире сниффером после завершения 4-way. */
#define WIFI_FCS_LEN       4          /* байт FCS, добавляемых железом */
#define WIFI_NET_RXQ       8          /* кадров Ethernet в кольце к net.c */
#define WIFI_NET_RXSZ      1600
/* тайминги ассоциации (тики = мс при 1000 Гц, сессия 33) */
#define CONN_4WAY_TO     5000  /* 5 с на шаг рукопожатия */
#define CONN_MAX_4WAY    3     /* попыток рукопожатия */
#define CONN_AUTH_TO       600         /* 600 мс на попытку AUTH/ASSOC */
#define CONN_MAX_ATTEMPTS  3
#define CONN_SCAN_TRIES    3          /* проходов скана при поиске сети */
#define CONN_BEACON_LOST   6000       /* 6 с без маяков = связь потеряна */

typedef enum { CHIP_NONE = 0, CHIP_AR9285, CHIP_AR9287, CHIP_AR9485 } wifi_chip_t;

/* RX-дескриптор AR5416 (owl): layout 1:1 из mac.h struct ar5416_desc.
 * status: st[0]=RSSIAnt00/01/02+rate, st[1]=DataLen+More, st[4]=RSSICombined,
 * st[8]=Done/FrameOK/CRCErr/PHYErr... */
typedef struct {
    u32 link;    /* следующий дескриптор (физ. адрес) */
    u32 data;    /* буфер (физ. адрес) */
    u32 ctl0;
    u32 ctl1;    /* BufLen (0xFFF) */
    u32 st[9];   /* RX status 0..8 (пишет железо) */
} owl_rxdesc_t;  /* 52 байта */

typedef struct {
    int      present;
    u32      mmio_base;
    u16      pci_devid;
    wifi_chip_t chip;
    u32      srev_raw;
    int      ready;          /* bring-up завершён успешно */
    int      chan;           /* [ATH-CC] текущий/запрошенный канал (индекс в
                              * wc_channel_freq): bring-up после неудачи fastcc
                              * обязан настраивать ЭТОТ канал, а не 0 */
    int      clk25;          /* AR9485: опорник 25 МГц (влияет на synth) */
    int      is_sowl;        /* семейство AR9003 */
    u8       mac[6];         /* наш MAC (из EEPROM) */

    /* ---- TX (owl): один дескриптор + буфер, передача по одному кадру ---- */
    void        *txdesc_raw;
    owl_txdesc_t *txdesc;    /* выровненный */
    u8          *txbuf;      /* буфер кадра 802.11 (без статуса) */
    volatile int tx_lock;

    /* ---- TX (sowl/AR9485): дескриптор ar9003 + статусное кольцо ---- */
    void          *stxdesc_raw;
    sowl_txdesc_t *stxdesc;          /* выровнен до 128 (кэш-линия) */
    u8            *stxbuf;
    void          *tsring_raw;
    sowl_txs_t    *tsring;           /* WIFI_TS_RING записей, выровнено */
    int            ts_tail;          /* след. запись статуса (наша) */

    /* RX (owl): кольцо дескрипторов */
    void         *rxdesc_raw;
    owl_rxdesc_t *rxdesc;                  /* выровненная база */
    void         *rxbuf_raw[WIFI_NUM_RXDESC];
    u8           *rxbuf[WIFI_NUM_RXDESC];  /* выровненные буферы */
    int           rx_head;

    /* RX (sowl): EDMA FIFO — буферы, буфер = [статус 44 б][кадр] */
    u8 *edbuf[WIFI_EDMA_QUEUES][WIFI_EDMA_BUFS];
    int ed_head[WIFI_EDMA_QUEUES];

    /* rx-арбитраж: kmain и приложение читают одновременно */
    volatile int rx_lock;
} ath9k_t;

static ath9k_t ath;

static const char *ath_bringup(void);
static int ath_fastcc(int ch_idx);
static int ath_gtk_is_tkip;   /* GTK TKIP -> EncrType TX-дескриптора (set в keys_install) */

/* частоты 2.4 ГГц — общий wc_channel_freq (wifi_core.h) */
#define channel_freq wc_channel_freq
#define NUM_CHANNELS WC_NUM_CHANNELS

/* ================= MMIO / задержки ================= */

static inline u32 reg32(u32 addr) {
    return *(volatile u32 *)(unsigned long)(ath.mmio_base + addr);
}
static inline void regw(u32 addr, u32 val) {
    *(volatile u32 *)(unsigned long)(ath.mmio_base + addr) = val;
}
static inline void reg_set(u32 addr, u32 bits) { regw(addr, reg32(addr) | bits); }
static inline void reg_clr(u32 addr, u32 bits) { regw(addr, reg32(addr) & ~bits); }
static inline void reg_rmw(u32 addr, u32 set, u32 clr) {
    regw(addr, (reg32(addr) & ~clr) | set);
}
static inline void reg_rmw_field(u32 addr, u32 mask, u32 shift, u32 val) {
    regw(addr, (reg32(addr) & ~mask) | ((val << shift) & mask));
}

/* io-задержка через порт 0x80. Скорость inb(0x80) сильно зависит от
 * платформы (от ~150 нс на современных чипсетах до ~1 мкс на старых),
 * а аналоговые сдвиговые регистры 0x7800..0x78a0 требуют честные
 * 100 мкс между записями — иначе радио запрограммировано «частично»
 * и приёмник глухой. Поэтому задержка КАЛИБРУЕТСЯ по PIT каналу 2
 * (свободен; тикает с фиксированной частотой 1.193182 МГц).
 * Калибровка работает и до sti() — нужен только latch-чтение счётчика. */
static volatile u32 g_io_per_us = 3;   /* итераций inb(0x80) на 1 мкс */

static u16 pit2_count(void) {
    outb(0x43, 0x80);                  /* latch канал 2 */
    return (u16)(inb(0x42) | (inb(0x42) << 8));
}

static void w_udelay_calibrate(void) {
    u8 p61 = inb(0x61);
    outb(0x61, (p61 | 0x01) & ~0x02);  /* GATE2=1, динамик выкл */
    outb(0x43, 0xB4);                  /* канал 2, режим 2, binary */
    outb(0x42, 0xFF); outb(0x42, 0xFF);/* делитель 65535 */

    u32 best = 0;
    for (int s = 0; s < 4; s++) {
        u32 n = 2000;
        u16 t0 = pit2_count();
        for (u32 i = 0; i < n; i++) (void)inb(0x80);
        u16 t1 = pit2_count();
        u32 dt = (u32)((t0 - t1) & 0xFFFF);
        if (dt < 8 || dt > 60000) continue;   /* глюк чтения */
        /* dt тиков * 0.838 нс/тик = прошло мкс; итераций/мкс = n/dt*1.193 */
        u32 per_us = (u32)(((u64)n * 1193182u) / 1000000u / dt);
        if (per_us > best) best = per_us;
    }
    outb(0x61, p61);                   /* вернуть GATE2 */

    if (best == 0) best = 8;           /* PIT молчит — консервативно */
    if (best > 2000) best = 2000;
    g_io_per_us = best + 1;            /* +1: небольшой запас */
    {
        char b[64];
        snprintf(b, sizeof(b), "калибровка задержек: %u итераций/мкс", (unsigned)best);
        wifi_log("%s", b);
    }
}

static void w_udelay(int us) {
    if (us <= 0) return;
    volatile u32 n = (u32)us * g_io_per_us;
    while (n-- > 0) (void)inb(0x80);
}

/* ожидание условия в регистре (аналог ath9k_hw_wait) */
static int hw_wait(u32 addr, u32 mask, u32 val, u32 timeout_us) {
    u32 t = 0;
    while ((reg32(addr) & mask) != val) {
        w_udelay(10);
        t += 10;
        if (t >= timeout_us) return 0;
    }
    return 1;
}

/* задержка стабилизации синтезатора: RX_DELAY в единицах 100 нс
 * [hw.c: ath9k_hw_synth_delay — hw_delay/10 + BASE_ACTIVATE_DELAY(100)] */
static void synth_delay_wait(void) {
    u32 d = reg32(AR_PHY_RX_DELAY) & AR_PHY_RX_DELAY_MSK;
    w_udelay((int)d / 10 + 100);
}

/* ================= power-on / reset (RTC) ================= */

/* Пробуждение RTC + cold/warm reset MAC [hw.c: ath9k_hw_set_reset_power_on
 * и ath9k_hw_set_reset]. Возвращает 0 при успехе, иначе код-строка. */
static const char *ath_reset(int cold) {
    /* AR9003+: регистр work-around перед сбросом */
    if (ath.is_sowl) {
        u32 wa = reg32(AR_WA) | (1 << 14) | (1 << 17);
        regw(AR_WA, wa);
        w_udelay(10);
    }

    regw(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN | AR_RTC_FORCE_WAKE_ON_INT);
    if (!ath.is_sowl) {
        regw(AR_RC, AR_RC_AHB);       /* AHB reset (pre-AR9003) */
        regw(AR_RTC_RESET, 0);
        w_udelay(2);
        regw(AR_RC, 0);
        regw(AR_RTC_RESET, AR_RTC_RESET_EN);
        if (!hw_wait(AR_RTC_STATUS, AR_RTC_STATUS_M, AR_RTC_STATUS_ON,
                     AH_WAIT_TIMEOUT_US))
            return "RTC не просыпается (power-on)";
    }

    /* warm/cold reset через RTC_RC */
    regw(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN | AR_RTC_FORCE_WAKE_ON_INT);
    if (!ath.is_sowl) regw(AR_RC, AR_RC_AHB);
    u32 rst = AR_RTC_RC_MAC_WARM | (cold ? AR_RTC_RC_MAC_COLD : 0);
    regw(AR_RTC_RC, rst);
    w_udelay(ath.is_sowl ? 50 : 100);
    regw(AR_RTC_RC, 0);
    if (!hw_wait(AR_RTC_RC, 0x3, 0, AH_WAIT_TIMEOUT_US))
        return "RTC_RC залип в reset";
    if (!ath.is_sowl) regw(AR_RC, 0);
    return 0;
}

/* [hw.c: ath9k_hw_set_power_awake] */
static const char *ath_power_awake(void) {
    reg_set(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN);
    w_udelay(50);
    for (int i = 0; i < 200; i++) {           /* до 10 мс */
        if ((reg32(AR_RTC_STATUS) & AR_RTC_STATUS_M) == AR_RTC_STATUS_ON)
            break;
        w_udelay(50);
        reg_set(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN);
    }
    if ((reg32(AR_RTC_STATUS) & AR_RTC_STATUS_M) != AR_RTC_STATUS_ON)
        return "не выходит из sleep";
    reg_clr(AR_STA_ID1, AR_STA_ID1_PWR_SAV);
    return 0;
}

/* [W-PCUDUMP] (полевой лог с [W-BSSID]: BSSID в железо пишется, но ACK на
 * юникаст от точки по-прежнему не уходит — DEAUTH дошёл с retry-битом;
 * лог Windows на ТОМ ЖЕ AR9285 показывает retry=0 на своих кадрах —
 * железо ACK-способно, значит разница в состоянии регистров. Сверка
 * с ath9k reg.h/ath5k/pcu.c выявила отличия, всё остальное совпало.)
 * Полный дамп состояния ПКУ при каждой записи BSSID (не при disconnect):
 * адресный матч (STA_ID0/BSS_ID/маска) + управляющие регистры (USEC
 * латентности RX->TX — путь ACK-ответа, TXBUF, MM2-крипто-биты,
 * RSSI-порог, DIAG_SW — ACK_DIS 0x2 полностью запрещает ACK). */
static void ath_pcu_dump(void) {
    u32 id0 = reg32(AR_STA_ID0), id1 = reg32(AR_STA_ID1);
    u32 b0 = reg32(AR_BSS_ID0), b1 = reg32(AR_BSS_ID1);
    u32 us = reg32(AR_USEC);
    wifi_log("PCU: ID0=%02x:%02x:%02x:%02x:%02x:%02x (наш MAC) "
             "ID1cfg=%08x BSS_ID=%02x:%02x:%02x:%02x:%02x:%02x msk=%08x:%04x",
             (unsigned)(id0 & 0xFF), (unsigned)((id0 >> 8) & 0xFF),
             (unsigned)((id0 >> 16) & 0xFF), (unsigned)((id0 >> 24) & 0xFF),
             (unsigned)(id1 & 0xFF), (unsigned)((id1 >> 8) & 0xFF),
             (unsigned)(id1 & 0xFFFF0000u),
             (unsigned)(b0 & 0xFF), (unsigned)((b0 >> 8) & 0xFF),
             (unsigned)((b0 >> 16) & 0xFF), (unsigned)((b0 >> 24) & 0xFF),
             (unsigned)(b1 & 0xFF), (unsigned)((b1 >> 8) & 0xFF),
             (unsigned)reg32(AR_BSSMSKL),
             (unsigned)(reg32(AR_BSSMSKU) & 0xFFFFu));
    wifi_log("PCU ctl: USEC=%08x (usec=%u tx_lat=%u rx_lat=%u) TXBUF=%x "
             "MM2=%08x RSSI=%x DIAG=%08x FILT=%x TO=%08x",
             (unsigned)us,
             (unsigned)((us & 0x7Fu) + 1u),
             (unsigned)((us & AR_USEC_TX_LAT) >> AR_USEC_TX_LAT_S),
             (unsigned)((us & AR_USEC_RX_LAT) >> AR_USEC_RX_LAT_S),
             (unsigned)reg32(AR_PCU_TXBUF_CTRL),
             (unsigned)reg32(AR_PCU_MISC_MODE2),
             (unsigned)reg32(AR_RSSI_THR),
             (unsigned)reg32(AR_DIAG_SW),
             (unsigned)reg32(AR_RX_FILTER),
             (unsigned)reg32(AR_TIME_OUT));
}

/* [hw.c: ath9k_hw_init_pll] — 2.4 ГГц, HT20 */
static void ath_init_pll(void) {
    if (ath.chip == CHIP_AR9485) {
        /* BB DPLL: ki=0x4, kd=0x40, refdiv=5, nini=0x58, nfrac=0,
         * outdiv=1, local_pll=1, en_negtrig=1, phase=0x6 */
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_PLL_PWD, AR_DPLL2_PLL_PWD_S, 1);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_KD, AR_DPLL2_KD_S, 0x40);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_KI, AR_DPLL2_KI_S, 0x4);
        reg_rmw_field(AR_CH0_BB_DPLL1, AR_DPLL1_REFDIV, AR_DPLL1_REFDIV_S, 0x5);
        reg_rmw_field(AR_CH0_BB_DPLL1, AR_DPLL1_NINI, AR_DPLL1_NINI_S, 0x58);
        reg_rmw_field(AR_CH0_BB_DPLL1, AR_DPLL1_NFRAC, 0, 0);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_OUTDIV, AR_DPLL2_OUTDIV_S, 0x1);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_LOCAL_PLL, AR_DPLL2_LOCAL_S, 0x1);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_EN_NEGTRIG, AR_DPLL2_EN_NEGTRIG_S, 0x1);
        reg_rmw_field(AR_CH0_BB_DPLL3, AR_DPLL3_PHASE, AR_DPLL3_PHASE_S, 0x6);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_PLL_PWD, AR_DPLL2_PLL_PWD_S, 0);
        w_udelay(1000);
    }
    /* PLL 2.4 ГГц: refdiv=5, div=0x2c → 0x142C (формула одинакова для
     * ar9002 [ar9002_hw_compute_pll_control] и ar9003) */
    regw(AR_RTC_PLL_CONTROL, (5u << 10) | 0x2cu);
    if (ath.chip == CHIP_AR9485) w_udelay(1000);
    w_udelay(100);
    regw(AR_RTC_SLEEP_CLK, AR_RTC_FORCE_DERIVED_CLK);
}

/* ================= применение ini-массивов ================= */

/* Запись массива с задержками как в эталоне: DO_DELAY (каждые 64 записи
 * udelay(1)) и 100 мкс на аналоговые регистры 0x7800..0x78a0
 * (analog shift reg — Owl). [ar5008_phy.c: ar5008_hw_process_ini] */
#define INI_WRITE(arr, col) \
    ini_write((const u32 *)(arr), \
              (int)(sizeof(arr) / sizeof((arr)[0])), \
              (int)(sizeof((arr)[0]) / sizeof(u32)), (col))

static void ini_write(const u32 *arr, int rows, int ncols, int col) {
    int writes = 0;
    for (int i = 0; i < rows; i++) {
        u32 r = arr[i * ncols];
        u32 v = arr[i * ncols + col];
        regw(r, v);
        if (r >= 0x7800 && r < 0x78a0) w_udelay(100);   /* analog shift */
        if (++writes % 64 == 0) w_udelay(1);
    }
}

/* Owl (AR9285/AR9287): process_ini для 2.4 ГГц HT20 → колонка 4.
 * ADDAC-массив для AR9285/9287 не используется (только до AR9160),
 * но финальное состояние ADC_SERIAL_CTL — как в эталоне: INTERNAL_ADDAC. */
static const char *owl_process_ini(void) {
    regw(0x9800, 0x00000007);              /* AR_PHY(0): доступ к аналог. чипам */
    regw(AR_PHY_ADC_SERIAL_CTL, AR_PHY_SEL_EXT_RADIO);
    regw(AR_PHY_ADC_SERIAL_CTL, 0);        /* SEL_INTERNAL_ADDAC (как эталон) */

    if (ath.chip == CHIP_AR9285) {
        INI_WRITE(ar9285Modes_9285_1_2, 4);
        INI_WRITE(ar9285Modes_original_tx_gain_9285_1_2, 4);
        INI_WRITE(ar9285Common_9285_1_2, 1);
    } else {
        /* AR9287: modes + common + RX gain + TX gain (колонка 4) */
        INI_WRITE(ar9287Modes_9287_1_1, 4);
        INI_WRITE(ar9287Modes_rx_gain_9287_1_1, 4);
        INI_WRITE(ar9287Modes_tx_gain_9287_1_1, 4);
        INI_WRITE(ar9287Common_9287_1_1, 1);
        /* CCK FIR коэффициенты: обычные (2412-2472) / Япония (2484)
         * ставятся при выборе канала — по умолчанию normal */
        INI_WRITE(ar9287Common_normal_cck_fir_coeff_9287_1_1, 1);
    }
    return 0;
}

/* Sowl (AR9485): порядок ar9003_hw_process_ini — цикл по группам
 * PRE→CORE→POST, в каждой SOC→MAC→BB→RADIO [ar9003_hw.c: init_mode_regs
 * + ar9003_phy.c: process_ini]. Колонка 4 = 2.4 ГГц HT20. */
static const char *sowl_process_ini(void) {
    /* PRE: SOC preamble + BB pre */
    INI_WRITE(ar9485_1_1_soc_preamble, 1);
    INI_WRITE(ar9485_1_1, 1);
    /* CORE: MAC + BB + Radio */
    INI_WRITE(ar9485_1_1_mac_core, 1);
    INI_WRITE(ar9485_1_1_baseband_core, 1);
    INI_WRITE(ar9485_1_1_radio_core, 1);
    /* POST: MAC + BB + Radio postamble */
    INI_WRITE(ar9331_1p1_mac_postamble, 4);
    INI_WRITE(ar9485_1_1_baseband_postamble, 4);
    INI_WRITE(ar9485_1_1_radio_postamble, 1);
    /* RX gain (кол.1) + TX gain (кол.4) + PCIe PHY */
    INI_WRITE(ar9485Common_wo_xlna_rx_gain_1_1, 1);
    INI_WRITE(ar9485Modes_low_ob_db_tx_gain_1_1, 4);
    INI_WRITE(ar9485_1_1_pcie_phy_clkreq_disable_L1, 1);
    return 0;
}

/* ================= канал / PHY ================= */

/* [ar5008_phy.c: ar5008_hw_override_ini] — RX_DIS/RX_ABORT ставим до RXE,
 * PCU_MISC_MODE2: без multicast-keyid поиска, CFP_IGNORE */
static void ath_override_ini(void) {
    reg_set(AR_DIAG_SW, AR_DIAG_RX_DIS | AR_DIAG_RX_ABORT);
    if (ath.is_sowl) {
        u32 val = reg32(AR_PCU_MISC_MODE2) & ~AR_PCU_MM2_ADHOC_KEYID;
        val |= AR_AGG_WEP_ENABLE_FIX | AR_AGG_WEP_ENABLE | AR_PCU_MM2_CFP_IGNORE;
        /* [W-MM2CRYPT] (эталон hw.c ath9k_hw_... для 9160+: mgmt НЕ
         * шифруются железом и не-данные не проходят кейсерч-шифрование;
         * у нас ini клал 0x00481043 с MGMT_CRYPTO_ENABLE=1 — единственное
         * остаточное расхождение с Linux в PCU-регистрах) */
        val &= ~AR_PCU_MM2_MGMT_CRYPTO;
        val |= AR_PCU_MM2_NO_CRYPTO_NONDATA;
        regw(AR_PCU_MISC_MODE2, val);
    } else {
        u32 val = reg32(AR_PCU_MISC_MODE2) & ~AR_PCU_MM2_ADHOC_KEYID;
        val &= ~AR_PCU_MM2_HWWAR1;
        val |= AR_PCU_MM2_CFP_IGNORE;
        /* [W-MM2CRYPT] — см. ветку sowl выше */
        val &= ~AR_PCU_MM2_MGMT_CRYPTO;
        val |= AR_PCU_MM2_NO_CRYPTO_NONDATA;
        regw(AR_PCU_MISC_MODE2, val);
    }
}

/* [ar5008_phy.c: ar5008_hw_set_channel_regs / ar9003: set_channel_regs]
 * 2.4 ГГц HT20: TURBO/GEN_CTRL = HT_EN|SHORT_GI_40|SINGLE_LTF1|WALSH */
static void ath_set_channel_regs(void) {
    if (ath.is_sowl) {
        /* сохранить INI-настройки, выключить Green Field detection */
        u32 phymode = reg32(AR_PHY_GEN_CTRL);
        phymode |= AR_PHY_FC_HT_EN | AR_PHY_FC_SHORT_GI_40 |
                   AR_PHY_FC_SINGLE_LTF1;
        phymode &= ~AR_PHY_GC_GF_DETECT;
        regw(AR_PHY_GEN_CTRL, phymode);
    } else {
        u32 phymode = AR_PHY_FC_HT_EN | AR_PHY_FC_SHORT_GI_40 |
                      AR_PHY_FC_SINGLE_LTF1 | AR_PHY_FC_WALSH;
        if (ath.chip == CHIP_AR9285) {   /* DAC FIFO бит из INI [owl-специфика] */
            phymode |= reg32(AR_PHY_TURBO) & AR_PHY_FC_DAC_FIFO;
        }
        regw(AR_PHY_TURBO, phymode);
    }
    regw(AR_2040_MODE, 0);               /* HT20 */
    regw(AR_GTXTO, 25u << 16);
    regw(AR_CST, 0xFu << 16);
}

/* [ar5008/ar9003: init_chain_masks] — AR9285/AR9485 = 1T1R.
 * СЕССИЯ 15: AR_SELFGEN_MASK пишется и для ar9003 (эталон
 * ar9003_hw_set_chain_masks пишет TX-маску в SELFGEN) — раньше для
 * sowl пропуск (RX работало и так), для TX нужна. */
static void ath_chain_masks(void) {
    regw(AR_PHY_RX_CHAINMASK, 1);
    regw(AR_PHY_CAL_CHAINMASK, 1);
    regw(AR_SELFGEN_MASK, 1);
}

/* [ar5008/ar9003: set_rfmode] — 2.4 ГГц → DYNAMIC (CCK+OFDM) */
static void ath_set_rfmode(void) {
    regw(AR_PHY_MODE, AR_PHY_MODE_DYNAMIC);
}

/* [hw.c: ath9k_hw_set_delta_slope] — целочисленно, как в эталоне */
static void ath_delta_slope(int freq) {
    u32 clock_mhz_scaled = 0x64000000u;      /* 100 МГц << 25 */
    u32 coef = clock_mhz_scaled / (u32)freq;

    /* get_delta_slope_vals */
    u32 exp;
    for (exp = 31; exp > 0; exp--)
        if ((coef >> exp) & 1) break;
    exp = 14 - (exp - 24);                  /* COEF_SCALE_S = 24 */
    u32 man = coef + (1u << (24 - exp - 1));
    man >>= (24 - exp);
    u32 ds_exp = exp - 16;
    reg_rmw_field(AR_PHY_TIMING3, AR_PHY_TIMING3_DSC_MAN, AR_PHY_TIMING3_DSC_MAN_S, man);
    reg_rmw_field(AR_PHY_TIMING3, AR_PHY_TIMING3_DSC_EXP, AR_PHY_TIMING3_DSC_EXP_S, ds_exp);

    coef = (9u * coef) / 10u;               /* short GI */
    for (exp = 31; exp > 0; exp--)
        if ((coef >> exp) & 1) break;
    exp = 14 - (exp - 24);
    man = coef + (1u << (24 - exp - 1));
    man >>= (24 - exp);
    ds_exp = exp - 16;
    reg_rmw_field(AR_PHY_HALFGI, AR_PHY_HALFGI_DSC_MAN, AR_PHY_HALFGI_DSC_MAN_S, man);
    reg_rmw_field(AR_PHY_HALFGI, AR_PHY_HALFGI_DSC_EXP, AR_PHY_HALFGI_DSC_EXP_S, ds_exp);
}

/* синтезатор: Owl [ar9002_hw_set_channel] / Sowl [ar9003_hw_set_channel] */
static void ath_set_synth(int ch_idx) {
    u32 freq = channel_freq[ch_idx];

    if (!ath.is_sowl) {
        /* CHANSEL_2G(freq) = freq * 0x10000 / CHANSEL_DIV, CHANSEL_DIV = 15
         * [phy.h: #define CHANSEL_DIV 15 — одинаково во всех ядрах v3.2..v6.1].
         * Формула: F = (3/4)*40МГц*(chansel/2^17) → chansel = F*0x10000/15.
         * ВАЖНО: раньше делили на 10 — синтезатор настраивался на 1.5× частоты
         * (канал 1 = 2412 МГц уходил на 3618 МГц!). Приёмник был ГЛУХ на
         * всех каналах: 0 кадров, 0 маяков, 0 CRC — при полностью исправной
         * остальной инициализации. */
        u32 chan_sel = (u32)freq * 0x10000u / 15u;
        u32 reg = reg32(AR_PHY_SYNTH_CONTROL) & 0xc0000000u;
        reg |= (1u << 29)        /* bMode (2 ГГц) */
             | (1u << 28)        /* fracMode */
             | (0u << 26)        /* aModeRefSel */
             | chan_sel;
        regw(AR_PHY_SYNTH_CONTROL, reg);
        /* [W-SYNTHCK] (полевой лог: большинство каналов 0 кадров):
         * контрольный обратный отсчёт — запись синтезатора ДОЛЖНА
         * прочитаться обратно той же. Если MMIO-запись не прижилась
         * (гонка с RFBUS/PHY-сбросом), радио остаётся на ПРОШЛОМ
         * канале: скан «слушает» ch N, физически принимая другой.
         * Рейт-лимит: первые 3 несовпадения всегда, дальше раз в 5 с
         * (одинаковое значение = одна и та же поломка). */
        {
            static u32 s_last = 0;
            static int s_logged = 0;
            u32 rb = reg32(AR_PHY_SYNTH_CONTROL);
            if (rb != reg) {
                u32 now = timer_ticks();
                if (s_logged < 3 || (u32)(now - s_last) >= 5000u) {
                    s_last = now;
                    s_logged++;
                    wifi_log("СИНТЕЗАТОР: записано %x, читается %x — "
                             "канал НЕ перестроен!",
                             (unsigned)reg, (unsigned)rb);
                }
            }
        }
        /* канал 14 (Япония): channel spreading. AR9285 — бит CCK_JAPAN,
        * AR9287 — свой cckfir-массив (как в эталоне, бит не трогаем) */
        if (ath.chip == CHIP_AR9287) {
            if (freq == 2484)
                INI_WRITE(ar9287Common_japan_2484_cck_fir_coeff_9287_1_1, 1);
            else
                INI_WRITE(ar9287Common_normal_cck_fir_coeff_9287_1_1, 1);
        } else {
            if (freq == 2484) reg_set(AR_PHY_CCK_TX_CTRL, AR_PHY_CCK_JAPAN);
            else              reg_clr(AR_PHY_CCK_TX_CTRL, AR_PHY_CCK_JAPAN);
        }
    } else {
        /* AR9485: div = 120 (опорник 40 МГц) или 75 (25 МГц) */
        u32 div = ath.clk25 ? 75u : 120u;
        u32 f4 = (u32)freq * 4u;
        u32 chan_sel = (f4 / div) << 17;
        chan_sel |= ((f4 % div) * 0x20000u) / div;
        regw(AR_PHY_SYNTH_CONTROL, 1u << 29);              /* bMode */
        reg_set(AR_PHY_65NM_SYNTH4, AR_PHY_SYNTH4_LONG_SHIFT);
        u32 v = (chan_sel << 2) | (1u << 30);              /* fracMode */
        regw(AR_PHY_65NM_SYNTH7, v);
        regw(AR_PHY_65NM_SYNTH7, v | (1u << 31));          /* load synth */
    }
}

/* [ar5008/ar9003: init_bb] — активация PHY + ожидание синтезатора */
static void ath_init_bb(void) {
    regw(AR_PHY_ACTIVE, AR_PHY_ACTIVE_EN);
    synth_delay_wait();
}

/* ================= калибровки ================= */

/* CL-калибровка AR9285 [ar9002_calib.c: ar9285_hw_cl_cal, ветка HT20] */
static const char *owl_cl_cal(void) {
    reg_set(AR_PHY_CL_CAL_CTL, AR_PHY_CL_CAL_EN | AR_PHY_PAR_CAL_EN);
    reg_set(AR_PHY_TURBO, AR_PHY_FC_DYN2040_EN);
    reg_clr(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_FLTR_CAL);
    reg_clr(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_CAL);
    reg_set(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL);
    if (!hw_wait(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL, 0,
                 AH_WAIT_TIMEOUT_US))
        return "CL-калибровка (1) не завершается";
    reg_clr(AR_PHY_TURBO, AR_PHY_FC_DYN2040_EN);
    reg_clr(AR_PHY_CL_CAL_CTL, AR_PHY_PAR_CAL_EN);
    reg_clr(AR_PHY_CL_CAL_CTL, AR_PHY_CL_CAL_EN);  /* [эталон: HT20-ветка
        * снимает CL_CAL_ENABLE сразу после первой калибровки — вторая
        * (FLTR/AGC) идёт уже без carrier-leakage-триггера] */
    reg_clr(AR_PHY_ADC_CTL, AR_PHY_ADC_OFF_PWDADC);
    reg_set(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_FLTR_CAL);
    reg_set(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_CAL);
    reg_set(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL);
    if (!hw_wait(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL, 0,
                 AH_WAIT_TIMEOUT_US))
        return "CL-калибровка (2) не завершается";
    reg_set(AR_PHY_ADC_CTL, AR_PHY_ADC_OFF_PWDADC);
    reg_clr(AR_PHY_CL_CAL_CTL, AR_PHY_CL_CAL_EN);
    reg_clr(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_FLTR_CAL);
    return 0;
}

/* AGC-калибровка AR9287 [ar9002_calib.c: ar9002_hw_init_cal, ветка 9287:
 * FLTR_CAL + AGC (без PWDADC-переключений — они не для 9287_11+)] */
static const char *kite_agc_cal(void) {
    u32 agc = AR_AGC_CTL_OWL;
    reg_set(agc, AGC_FLTR_CAL);
    reg_set(agc, AGC_CAL);
    if (!hw_wait(agc, AGC_CAL, 0, AH_WAIT_TIMEOUT_US))
        return "AGC-калибровка (9287) не завершается";
    reg_clr(agc, AGC_FLTR_CAL);
    return 0;
}

/* AGC-калибровка Sowl [ar9003_calib.c: ar9003_hw_init_cal_pcoem,
 * только RX-существенная часть: CL-toggle + AGC] */
static const char *sowl_agc_cal(void) {
    u32 agc = ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL;
    u32 rx_delay = 0;
    int have_cl = (reg32(AR_PHY_CL_CAL_CTL) & AR_PHY_CL_CAL_EN) != 0;

    ath_chain_masks();               /* для калибровки — аппаратная маска (1) */
    if (have_cl) {
        rx_delay = reg32(AR_PHY_RX_DELAY);
        regw(AR_PHY_ACTIVE, 0);      /* BB off/on вокруг CL cal [эталон] */
        w_udelay(5);
        regw(AR_PHY_RX_DELAY, AR_PHY_RX_DELAY_MSK);
        regw(AR_PHY_ACTIVE, AR_PHY_ACTIVE_EN);
    }
    reg_set(agc, AGC_CAL);
    if (!hw_wait(agc, AGC_CAL, 0, AH_WAIT_TIMEOUT_US)) {
        ath_chain_masks();
        return "AGC-калибровка не завершается";
    }
    if (have_cl) {
        regw(AR_PHY_RX_DELAY, rx_delay);
        w_udelay(5);
    }
    ath_chain_masks();               /* вернуть рабочую маску (та же 1) */
    return 0;
}

/* Запись NF (dBm) в поле [8:0] CCA-регистра — ПОЛНОСТЬЮ как в эталоне:
 * reg = (reg & ~0x1ff) | ((nfval << 1) & 0x1ff)  [calib.c: loadnf].
 * ВНИМАНИЕ: раньше здесь был двойной сдвиг (reg_rmw_field уже сдвигает,
 * а значение ещё раз умножалось на 2) — вместо -50 дБм писалось
 * -100 дБм, вместо номинала -118 — вообще +20 дБм. Порог CCA
 * оказывался НИЖЕ реального шума → CCA постоянно busy → приёмник
 * ГЛУХОЙ на всех каналах (0 кадров, 0 маяков, 0 CRC). */
static void nf_set(u32 cca_reg, int dbm) {
    regw(cca_reg, (reg32(cca_reg) & ~0x1ffu) |
                  (((u32)(i32)dbm << 1) & 0x1ffu));
}

/* Чтение NF (dBm) — поле MINCCA_PWR [28:20], 9-битное со знаком.
 * [ar9002_phy.c: ar9002_hw_do_getnf: MS(reg, AR9280_PHY_MINCCA_PWR=0x1FF00000,
 * shift 20) + sign_extend32(nf, 8); ar9003 — то же поле AR_PHY_CH_MINCCA_PWR].
 * ВАЖНО: поле [8:0] — write-only загрузка номинала (loadnf пишет туда
 * значение<<1), а железо отдаёт ИЗМЕРЕННЫЙ NF именно в [28:20], причём
 * уже в dBm — делить на 2 НЕЛЬЗЯ. Раньше читались биты [8:0] — т.е.
 * возвращалось то, что сами записали (постоянно -50), и это ещё и
 * делилось на 2. */
static int nf_get(u32 cca_reg) {
    i32 v = (i32)((reg32(cca_reg) >> 20) & 0x1ffu);
    if (v & 0x100) v -= 0x200;
    /* санитизация как в эталоне [calib.c: ath9k_hw_nf_sanitize]:
     * значения вне разумного диапазона → номинал (калибровка ещё
     * не завершилась / регистр не обновился) */
    if (v > -60 || v < -127) {
        if (ath.is_sowl) return -110;
        return (ath.chip == CHIP_AR9287) ? -112 : -118;
    }
    return v;
}

/* noise floor: загрузка номинала + запуск калибровки
 * [calib.c: ath9k_hw_loadnf + ath9k_hw_start_nfcal].
 * Для 1T1R HT20 используется только цепь 0 (CCA / CCA_0). */
static void ath_nf_load_start(void) {
    u32 agc = ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL;
    u32 cca = ath.is_sowl ? AR_PHY_CCA_0_SOWL : AR_PHY_CCA;
    int nominal = -118;                       /* AR9285 */
    if (ath.chip == CHIP_AR9287) nominal = -112;
    if (ath.is_sowl) nominal = -110;          /* AR9003 */

    u32 agc_ctl = reg32(agc);
    nf_set(cca, nominal);
    if (agc_ctl & AGC_NF) reg_clr(agc, AGC_NF);       /* прервать текущую */
    reg_clr(agc, AGC_ENABLE_NF);
    reg_clr(agc, AGC_NO_UPDATE_NF);
    reg_set(agc, AGC_NF);
    int timed_out = 1;
    for (int j = 0; j < 22200; j++) {         /* ≤ 222 мс, как в эталоне */
        if (!(reg32(agc) & AGC_NF)) { timed_out = 0; break; }
        w_udelay(10);
    }
    if (timed_out)
        wifi_log("ВНИМАНИЕ: загрузка NF не завершилась (AGC=%x)",
                 (unsigned)reg32(agc));

    /* «Вернуть максимум»: maxCCAPower = -50 дБм — это начальное (и
     * максимальное) значение следующей NF-калибровки железа. Не путать
     * с порогом CCA: именно -50 (как в эталоне), НЕ ниже! */
    nf_set(cca, -50);

    /* start_nfcal */
    reg_set(agc, AGC_ENABLE_NF);
    reg_clr(agc, AGC_NO_UPDATE_NF);
    reg_set(agc, AGC_NF);
}

/* [W-QUIET] тихий режим bring-up: при скане bring-up выполняется на
 * КАЖДЫЙ канал (14 раз за проход) — детальные строки (reset/PLL/ini/
 * калибровка/NF) в логе подавляются, остаются ошибки и сводка скана.
 * Первый (загрузочный) и PREAUTH bring-up остаются подробными. */
static int g_bringup_quiet = 0;

/* ================= [W-TXPOW-v2] (полевой лог: «TX отказ — точка не
 * отвечает», st=702/0) — таблица TX-мощности =================
 * [ИСПРАВЛЕНО: прежде драйвер писал мощность в 0xa368+ — у AR9002
 * ТАКИХ регистров TX-мощности НЕ СУЩЕСТВУЕТ. По эталону Linux
 * ar9002_phy.h: 0xa3a8 = AR_PHY_MASK2_M_16_30 (маска интерливера,
 * затиралась значением 63!), 0xa368-0xa37c — не определены вовсе.]
 * Настоящие адреса [ar9002_phy.h:209-211, 456-457, 560-561; записи —
 * eeprom_4k.c:620-660, ath9k_hw_4k_set_txpower]:
 *   RATE1 0x9934 — OFDM 6/9/12/18   (поля 6 бит @ 0/8/16/24)
 *   RATE2 0x9938 — OFDM 24/36/48/54
 *   RATE3 0xa234 — CCK 1L/XR/2L/2S  (1 Мбит — [5:0]!)
 *   RATE4 0xa238 — CCK 5.5L/5.5S/11L/11S
 *   RATE5 0xa38c / RATE6 0xa390 — HT20 MCS0-3 / MCS4-7
 *   MAX   0x993c — потолок MAX_RATE_POWER (63), TPC выкл.
 * Поля — 4 рейта по 6 бит (ATH9K_POW_SM: ((r)&0x3f)<<s) на байтовых
 * границах; при значениях < 64 байтовая упаковка эквивалентна.
 * INI-массивы эти регистры не трогают — после сброса там нули, PA
 * фактически молчал, и точка не слышала AUTH (ExcessiveRetries x7,
 * DataFailCnt=7 — в точности полевой лог). Без калибровочных данных
 * EEPROM ставим безопасные 15 дБм на все рейты (EIRP-лимит 20 дБм
 * с запасом на усиление антенны).
 * Шкала (eeprom_4k.c ~615): ratesArray -= AR5416_PWR_TABLE_OFFSET_DB*2,
 * OFFSET = -5 дБ => в регистр пишется 2*дБм + 10; 40 (0x28) = 15 дБм.
 * Путь sowl (AR9485) не трогаем: у него своя схема мощности. */
#define AR_PHY_POWER_TX_RATE1      0x9934
#define AR_PHY_POWER_TX_RATE2      0x9938
#define AR_PHY_POWER_TX_RATE3      0xa234
#define AR_PHY_POWER_TX_RATE4      0xa238
#define AR_PHY_POWER_TX_RATE5      0xa38c
#define AR_PHY_POWER_TX_RATE6      0xa390
#define AR_PHY_POWER_TX_RATE_MAX   0x993c
#define ATH_TXPOW_HALF_DB          40    /* 15 дБм в шкале эталона:
                                          * 2*дБм + 10 (offset -5 дБ,
                                          * AR5416_PWR_TABLE_OFFSET_DB) */
#define ATH_MAX_RATE_POWER         63    /* MAX_RATE_POWER эталона */

static void ath_txpow_program(void) {
    /* [W-TXPOW-v2] 4 рейта по 6 бит на байтовых границах, маска 0x3f —
     * ровно как ATH9K_POW_SM в эталоне */
    u32 v4 = (ATH_TXPOW_HALF_DB & 0x3Fu) |
             ((ATH_TXPOW_HALF_DB & 0x3Fu) << 8) |
             ((ATH_TXPOW_HALF_DB & 0x3Fu) << 16) |
             ((ATH_TXPOW_HALF_DB & 0x3Fu) << 24);
    regw(AR_PHY_POWER_TX_RATE1, v4);
    regw(AR_PHY_POWER_TX_RATE2, v4);
    regw(AR_PHY_POWER_TX_RATE3, v4);
    regw(AR_PHY_POWER_TX_RATE4, v4);
    regw(AR_PHY_POWER_TX_RATE5, v4);
    regw(AR_PHY_POWER_TX_RATE6, v4);
    regw(AR_PHY_POWER_TX_RATE_MAX, ATH_MAX_RATE_POWER);
    /* контроль записи: читаем НАСТОЯЩИЕ регистры (RATE3 и MAX) —
     * в полевом логе по прежним (мусорным) адресам было 78040181/0.
     * В тихом режиме (скан) строка подавляется — видна при загрузке */
    if (!g_bringup_quiet)
        wifi_log("TX-мощность записана: RATE1/2=%08x/%08x RATE3=%08x MAX=%x",
                 (unsigned)reg32(AR_PHY_POWER_TX_RATE1),
                 (unsigned)reg32(AR_PHY_POWER_TX_RATE2),
                 (unsigned)reg32(AR_PHY_POWER_TX_RATE3),
                 (unsigned)reg32(AR_PHY_POWER_TX_RATE_MAX));
}

/* ================= MAC / DMA конфигурация ================= */

/* [hw.c: ath9k_hw_set_dma] + init_queues (только DCU-маски) +
 * reset_opmode [hw.c: ath9k_hw_reset_opmode упрощённо для станции] */
static void ath_mac_dma_config(void) {
    /* прерывания не используем: polling; линия IRQ держится тихой */
    regw(AR_IER, 0);
    regw(AR_ISR, 0xFFFFFFFFu);

    /* режим станции: поиск станций, сохранение seqnum */
    reg_rmw(AR_STA_ID1,
            AR_STA_ID1_KSRCH_MODE | AR_STA_ID1_PRES_SEQNUM,
            AR_STA_ID1_STA_AP | AR_STA_ID1_ADHOC | AR_STA_ID1_PWR_SAV);
    reg_clr(AR_CFG, AR_CFG_AP_ADHOC_IND);
    regw(AR_DEF_ANTENNA, 1);

    /* BSSID = broadcast (сканируем все сети), multicast-фильтр открыт */
    regw(AR_BSS_ID0, 0xFFFFFFFFu);
    regw(AR_BSS_ID1, 0x0000FFFFu);
    regw(AR_MCAST_FIL0, 0xFFFFFFFFu);
    regw(AR_MCAST_FIL1, 0xFFFFFFFFu);

    /* DMA: AHB без prefetch, burst 128 байт, RX FIFO threshold */
    reg_set(AR_AHB_MODE, AR_AHB_PREFETCH);
    reg_rmw(AR_TXCFG, 5, 7);          /* DMASZ_128B */
    reg_rmw(AR_RXCFG, 5, 7);          /* DMASZ_128B */
    if (!ath.is_sowl) regw(AR_RXFIFO_CFG, 0x200);
    for (int i = 0; i < 10; i++)      /* DQCUMASK */
        regw(AR_D0_QCUMASK + (u32)i * 4, 1u << i);
    regw(AR_OBS, 8);
}

/* ================= приём: DMA RX ================= */

/* Owl: кольцо из WIFI_NUM_RXDESC дескрипторов, замкнутое само на себя
 * (HAL-стиль; BA-проблема 11n для сканера неактуальна). */
static int owl_rx_arm(void) {
    if (!ath.rxdesc) {
        ath.rxdesc_raw = malloc(sizeof(owl_rxdesc_t) * WIFI_NUM_RXDESC + 16);
        if (!ath.rxdesc_raw) return 0;
        ath.rxdesc = (owl_rxdesc_t *)
            (((u32)(unsigned long)ath.rxdesc_raw + 15) & ~15u);
        for (int i = 0; i < WIFI_NUM_RXDESC; i++) {
            ath.rxbuf_raw[i] = malloc(WIFI_RXBUF_SZ + 16);
            if (!ath.rxbuf_raw[i]) return 0;
            ath.rxbuf[i] = (u8 *)
                (((u32)(unsigned long)ath.rxbuf_raw[i] + 15) & ~15u);
        }
    }
    if (!ath.rxdesc) return 0;
    for (int i = 0; i < WIFI_NUM_RXDESC; i++) {
        owl_rxdesc_t *d = &ath.rxdesc[i];
        u8 *buf = ath.rxbuf[i];
        memset(d, 0, sizeof(*d));
        d->data = (u32)(unsigned long)buf;
        d->ctl1 = WIFI_RXBUF_SZ;
        owl_rxdesc_t *next = &ath.rxdesc[(i + 1) % WIFI_NUM_RXDESC];
        d->link = (u32)(unsigned long)next;
    }
    ath.rx_head = 0;
    regw(AR_RXDP, (u32)(unsigned long)&ath.rxdesc[0]);
    return 1;
}

/* Sowl: EDMA FIFO — адреса буферов пишутся в HP/LP RXDP, кадр приходит
 * в буфер с 44-байтовым статусным префиксом [recv.c + ar9003_mac.c]. */
static int sowl_rx_arm(void) {
    regw(AR_DATABUF_SIZE, WIFI_RXBUF_SZ & 0xFFF);
    for (int q = 0; q < WIFI_EDMA_QUEUES; q++) {
        u32 rxdp = (q == 0) ? AR_HP_RXDP : AR_LP_RXDP;
        for (int i = 0; i < WIFI_EDMA_BUFS; i++) {
            if (!ath.edbuf[q][i]) {
                u8 *raw = (u8 *)malloc(WIFI_EDMA_ST_LEN + WIFI_RXBUF_SZ + 16);
                if (!raw) return 0;
                ath.edbuf[q][i] = (u8 *)(((u32)(unsigned long)raw + 15) & ~15u);
            }
            u8 *buf = ath.edbuf[q][i];
            memset(buf, 0, WIFI_EDMA_ST_LEN);
            regw(rxdp, (u32)(unsigned long)buf);
        }
        ath.ed_head[q] = 0;
    }
    return 1;
}

/* фильтр приёма: всё + маяки + promiscuous (сканер) + запуск DMA RX */
static int ath_rx_start(void) {
    if (ath.is_sowl && !sowl_rx_arm()) return 0;
    if (!ath.is_sowl && !owl_rx_arm()) return 0;

    regw(AR_RX_FILTER, RXF_UCAST | RXF_MCAST | RXF_BCAST |
                       RXF_CONTROL | RXF_BEACON | RXF_PROM);
    /* снимать RX_DIS/RX_ABORT только ПОСЛЕ включения RXE [эталон:
     * override_ini + ar9002_hw_rx_enable + startpcureceive] */
    regw(AR_CR, ath.is_sowl ? AR_CR_RXE_SOWL : AR_CR_RXE_OWL);
    reg_clr(AR_DIAG_SW, AR_DIAG_RX_DIS | AR_DIAG_RX_ABORT);
    return 1;
}

/* ================= опрос RX (из wifi_poll -> ops->poll_rx) ================= */

/* [W-RSSI-NF] Нормализация RSSI к ЗНАКОВОМУ dBm.
 * Эталон ath9k_cmn_process_rssi: rxs->signal = ah->noise + rs_rssi —
 * байт RSSI дескриптора ОТНОСИТЕЛЕН шумового пола (сильный кадр ~35..65,
 * еле слышимый ~85..95), а не |dBm|. Прежнее «-raw» совпадало с эталоном
 * только при raw=59 (полевой лог: одна и та же точка показывала -35 и
 * -59 в разных проходах, слабые всегда -100). Нет измерения (raw 0 или
 * 0x80 = ATH9K_RSSI_BAD) → -100 (конвенция UI «слабый»). */
static int g_nf_dbm = -100;        /* NF текущего канала (пишет bring-up) */

static inline i8 ath_rssi_dbm(u8 raw)
{
    if (raw == 0 || raw == 0x80) return (i8)-100;
    int dbm = g_nf_dbm + (int)raw;
    if (dbm > -20)  dbm = -20;     /* сильнее -20 дБм не бывает */
    if (dbm < -110) dbm = -110;    /* ниже -110 — за пределами чуствительности */
    return (i8)dbm;
}

/* Owl: обходим дескрипторы по порядку, пока не встретим незавершённый. */
static void owl_rx_poll(void) {
    if (!ath.rxdesc) return;
    int budget = 48;   /* [W9-RXBUDGET]: 16 -> 48 — шторм PHY-err соседа
                        * (сотни descriptor'ов/с) не должен доживать до
                        * следующей итерации kmain */
    while (budget-- > 0) {
        owl_rxdesc_t *d = &ath.rxdesc[ath.rx_head];
        if (!(d->st[8] & 0x00000001)) break;    /* не Done */
        u32 flags = d->st[8];
        u32 dlen = d->st[1] & 0x00000FFF;
        i8 rssi = ath_rssi_dbm((u8)(d->st[4] >> 24));   /* [W-RSSI-NF] */
        u8 rxr = (u8)(d->st[0] >> 24);   /* [W-RXRATE] PHY-рейт из статуса-0 */
        /* [W-DECEAPOL]: бит 3 (0x8) = DecryptCRCError при не-FrameOK —
         * ПКУ с KSRCH_MODE не нашёл ключа (M1/M3 приходят ДО установки
         * ключей 4-way). Считаем ЗДЕСЬ: значение нужно и в TRACE-блоке
         * ниже (метка « D» у data/ok-печатей), и в условии доставки
         * после него — объявление после TRACE-блока не компилировалось
         * (use before declaration в [W-M1VIEW]-ветке). */
        int dec_err = (flags & 0x00000008) && !(flags & 0x00000004) &&
                      !(flags & 0x00000010);
        /* [W-ASOCTRACE] (HomeWifi/byfly: ACK на каждый ASSOC REQ, ответа
         * нет ни в одном окне 600 мс): 300 мс после каждого TX ASSOC REQ
         * пишем ВСЁ пришедшее — годное/CRC/прочее. Оконная статистика не
         * различает «ответ пришёл битым» от «ответа не было», а по этим
         * строкам видно сразу. Лимит 10 строк на бурст (ID = номер
         * запроса), чтобы шум эфира не забил журнал. */
        {
            u32 tr_burst = 0;
            if (wc_assoc_trace_active(&tr_burst)) {
                static u32 s_tr_burst = 0;
                static int s_tr_cnt = 0;
                if (tr_burst != s_tr_burst) { s_tr_burst = tr_burst; s_tr_cnt = 0; }
                if (s_tr_cnt < 10) {
                    s_tr_cnt++;
                    if ((flags & 0x00000002) && dlen >= 2) {
                        const u8 *tfr = (const u8 *)(unsigned long)d->data;
                        u16 tfc = (u16)(tfr[0] | ((u16)tfr[1] << 8));
                        u8 ttype = (u8)((tfc >> 2) & 0x3u); /* 0 mgmt 1 ctl 2 data */
                        if (ttype == 1 && dlen >= 12) {
                            /* [W-TRACEADDR]: control-кадры — A1 (RA) и, где есть,
                             * A2 (TA). В поле HomeWifi в окнах ASSOC шли RTS/CTS/ACK
                             * на уровне точки (rssi -82); без адресов не отличить
                             * «RTS К НАМ» (защита перед RSP — наш CTS не ушёл) от
                             * чужого трафика. */
                            int two = ((tfc & 0x00FCu) == 0x00B0u ||  /* RTS */
                                       (tfc & 0x00FCu) == 0x0080u ||  /* BAR */
                                       (tfc & 0x00FCu) == 0x0090u);   /* BA */
                            if (two && dlen >= 16)
                                wifi_log("TRACE: ctl fc=%04x "
                                         "A1=%02x:%02x:%02x:%02x:%02x:%02x "
                                         "A2=%02x:%02x:%02x:%02x:%02x:%02x rssi=%d r=%02x",
                                         (unsigned)tfc,
                                         tfr[4], tfr[5], tfr[6], tfr[7], tfr[8], tfr[9],
                                         tfr[10], tfr[11], tfr[12], tfr[13], tfr[14], tfr[15],
                                         (int)rssi, (unsigned)rxr);
                            else
                                wifi_log("TRACE: ctl fc=%04x "
                                         "A1=%02x:%02x:%02x:%02x:%02x:%02x rssi=%d r=%02x",
                                         (unsigned)tfc,
                                         tfr[4], tfr[5], tfr[6], tfr[7], tfr[8], tfr[9],
                                         (int)rssi, (unsigned)rxr);
                        } else if (ttype == 2 && dlen >= 10 &&
                                   memcmp(tfr + 4, ath.mac, 6) == 0) {
                            /* [W-M1VIEW] (полевой лог esp32test: сразу после
                             * ASSOC REQ пришёл DATA-кадр fc=0208 (FromDS) с
                             * A1=наш MAC — вероятный EAPOL M1: AP засчитала
                             * ассоциацию и начала рукопожатие, пока мы ждали
                             * ASSOC-RSP; DEAUTH reason=15 HomeWifi = 4-way
                             * timeout). Печатаем тело data-кадра к нам:
                             * LLC AA AA 03 000000 888E = EAPOL — тогда
                             * [W-M1ASSOC] перехватит его в ядре. */
                            u32 h = ((tfc & 0x0090u) == 0x0080u) ? 26u : 24u;
                            u32 shown = 0;
                            char hex[3 * 16 + 1];
                            for (u32 k = 0; k + h < (u32)dlen && k < 16u; k++) {
                                snprintf(hex + 3 * k, sizeof(hex) - 3 * k,
                                         "%02x ", (unsigned)tfr[h + k]);
                                shown = k + 1;
                            }
                            if (shown) hex[3 * shown - 1] = 0;
                            wifi_log("TRACE: data fc=%04x%s to-me len=%u rssi=%d "
                                     "r=%02x body[%u]=%s",
                                     (unsigned)tfc, dec_err ? " D" : "",
                                     (unsigned)dlen, (int)rssi,
                                     (unsigned)rxr,
                                     (unsigned)(dlen > h ? dlen - h : 0), hex);
                        } else if (dlen >= 24) {
                            /* [W-TRACEADDR] mgmt/data: seq + retry-бит — ретрай
                             * означает «наш ACK на предыдущую копию не дошёл» */
                            wifi_log("TRACE: ok fc=%04x%s%s seq=%u len=%u rssi=%d r=%02x",
                                     (unsigned)tfc, (tfc & 0x0400u) ? " R" : "",
                                     dec_err ? " D" : "",
                                     (unsigned)((tfr[22] | ((u16)tfr[23] << 8)) >> 4),
                                     (unsigned)dlen, (int)rssi, (unsigned)rxr);
                        } else {
                            wifi_log("TRACE: ok fc=%04x len=%u rssi=%d",
                                     (unsigned)tfc, (unsigned)dlen, (int)rssi);
                        }
                    } else if (flags & 0x00000004) {
                        wifi_log("TRACE: crc len=%u rssi=%d r=%02x",
                                 (unsigned)dlen, (int)rssi, (unsigned)rxr);
                    } else {
                        wifi_log("TRACE: err flags=%08x len=%u rssi=%d r=%02x",
                                 (unsigned)flags, (unsigned)dlen, (int)rssi,
                                 (unsigned)rxr);
                    }
                }
            }
        }
        /* [W-DECEAPOL] (поле HomeWifi: «RX err flags=80000009 len=139» —
         * это и есть теряемые EAPOL M1/M3 ~139 байт): ПКУ с KSRCH_MODE
         * ищет ключ для КАЖДОГО data-кадра; до установки ключей (M1/M3
         * приходят ДО них!) key search miss помечает кадр DecryptCRCError
         * при не-FrameOK. Linux такие кадры доставляет (EAPOL-исключение
         * в ieee80211). Доставляем dec-err без CRC/PHY-ошибки — ядро само
         * отфильтрует мусор. Условие: FrameOK ИЛИ dec_err (вычислен
         * выше, перед TRACE-блоком). */
        if ((flags & 0x00000002) || dec_err) {  /* FrameOK | decrypt-err */
            if (dlen >= 2 && dlen <= WIFI_RXBUF_SZ) {
                /* [W-RXUCDIAG2] (полевой лог итерации 11: точка ACK-ит наши
                 * кадры (st1=1 = FrmXmitOK = ACK получен, ref_mac.h:464),
                 * но AUTH-ответ не дошёл до парсера). Лимитер итерации 10
                 * «8 всегда + 1/5 с» съедался соседским мусором (ACK/CTS
                 * чужих станций) ещё в скане — ответ точки попадал в
                 * ПОДАВЛЕННОЕ окно. Теперь раздельно:
                 *  - mgmt (type 0): первые 16 всегда, дальше не чаще 1/с
                 *    — mgmt-кадров в эфире единицы в секунду, а пропустить
                 *    AUTH/ASSOC-ответ НЕЛЬЗЯ; печатаем DA/SA/BSSID —
                 *    сразу видно, кто и кому;
                 *  - данные/управление: 4 + 1/10 с (ценности мало, шумят). */
                /* [W-LOGCHG2] (итерация 12, запрос «логи компактнее»):
                 * полевой лог 11 был забит probe-кадрами (fc=0040/0050)
                 * чужих станций — 90% строк без единого бита пользы.
                 * Пробы больше НЕ печатаются никогда: они есть в
                 * статистике скана (mgmt/кадры), а решающие кадры
                 * AUTH/DEAUTH/ASSOC/ACTION печатаются всегда. */
                static int  s_uc_logged = 0, s_mgmt_logged = 0;
                static u32  s_uc_last = 0, s_mgmt_last = 0;
                const u8 *fr = (const u8 *)(unsigned long)d->data;
                u16 fc = (u16)(fr[0] | ((u16)fr[1] << 8));
                int is_beacon = ((fc & 0x00FCu) == 0x0080u);
                int is_probe  = ((fc & 0x00FCu) == 0x0040u ||  /* probe req */
                                 (fc & 0x00FCu) == 0x0050u);   /* probe resp */
                if (!is_beacon && !is_probe && (fc & 0x000Cu) == 0u) { /* mgmt */
                    if (s_mgmt_logged < 8 ||
                        (u32)(timer_ticks() - s_mgmt_last) > 1000u) {
                        s_mgmt_logged++;
                        s_mgmt_last = timer_ticks();
                        if (dlen >= 24)
                            wifi_log("RX mgmt: fc=%04x%s seq=%u len=%u "
                                     "DA=%02x:%02x:%02x:%02x:%02x:%02x "
                                     "SA=%02x:%02x:%02x:%02x:%02x:%02x "
                                     "BSSID=%02x:%02x:%02x:%02x:%02x:%02x rssi=%d r=%02x",
                                     (unsigned)fc, (fc & 0x0400u) ? " R" : "",
                                     (unsigned)((fr[22] | ((u16)fr[23] << 8)) >> 4),
                                     (unsigned)dlen,
                                     fr[4], fr[5], fr[6], fr[7], fr[8], fr[9],
                                     fr[10], fr[11], fr[12], fr[13], fr[14], fr[15],
                                     fr[16], fr[17], fr[18], fr[19], fr[20], fr[21],
                                     (int)rssi, (unsigned)rxr);
                        else
                            wifi_log("RX mgmt: fc=%04x len=%u rssi=%d",
                                     (unsigned)fc, (unsigned)dlen, (int)rssi);
                        /* [W-DEAUTHREASON]: причина deauth/disassoc от точки.
                         * HomeWifi прислал DEAUTH ПОСЛЕ 6 безответных ASSOC —
                         * reason различает сценарии: 2 = «класс 2 без
                         * аутентификации» (точка НЕ считала нас аутентифи-
                         * цированными — проблема AUTH-состояния), 7 = «класс
                         * 3 без ассоциации», 4/5 = inactivity (точка
                         * АССОЦИИРОВАЛА нас, а ответ потерялся на пути к
                         * нам — копать PHY/RX после TX). */
                        if (dlen >= 26 &&
                            ((fc & 0x00FCu) == 0x00C0u ||
                             (fc & 0x00FCu) == 0x00A0u))
                            wifi_log("  %s reason=%u",
                                     (fc & 0x00FCu) == 0x00C0u ? "DEAUTH"
                                                               : "DISASSOC",
                                     (unsigned)(fr[24] |
                                                ((u16)fr[25] << 8)));
                    }
                } else if (!is_beacon && !is_probe) {          /* data/ctrl */
                    if (s_uc_logged < 4 ||
                        (u32)(timer_ticks() - s_uc_last) > 30000u) {
                        s_uc_logged++;
                        s_uc_last = timer_ticks();
                        wifi_log("RX не-маяк: fc=%04x len=%u DA=%02x:%02x:%02x:%02x:%02x:%02x rssi=%d",
                                 (unsigned)fc, (unsigned)dlen,
                                 fr[4], fr[5], fr[6], fr[7], fr[8], fr[9], (int)rssi);
                    }
                }
                wc_rx_frame((const u8 *)(unsigned long)d->data, (int)dlen, rssi);
            }
        } else if (flags & 0x00000004) {
            /* [W-CRCDIAG] (лог HomeWifi: 6 окон ASSOC без единого ответа
             * точки при тишине в TX-диагностике — ACK был): длина/rssi
             * CRC-битых кадров. Если точка ОТВЕЧАЕТ, но ответ коверкается
             * на PHY — сразу после каждого запроса будут длины ~120-260 б
             * с rssi точки; мусор эфира даёт случайные длины. Троттлинг:
             * первые 8 всегда, дальше 1/5 с (скан даёт сотни CRC/канал). */
            {
                static int s_crc_logged = 0;
                static u32 s_crc_last = 0;
                if (s_crc_logged < 8 ||
                    (u32)(timer_ticks() - s_crc_last) > 5000u) {
                    s_crc_logged++;
                    s_crc_last = timer_ticks();
                    wifi_log("RX CRC-битый: len=%u rssi=%d r=%02x",
                             (unsigned)dlen, (int)rssi, (unsigned)rxr);
                }
            }
            wc_rx_err(1);                       /* CRC/PHY */
        } else {
            /* [W-CRCDIAG]: прочие ошибки (не CRC) — промахи декрипта
             * keycache тоже сюда; первые 8 печатаем, дальше молча.
             * [W-PHYERR] (26.10): теперь сюда придут и PHY-err тайминга
             * (AR_PHY_ERR маски открыты) — именно они могут оказаться
             * «невидимым» ASSOC-RSP/M1-ретраями точки. «8 навсегда»
             * заменил на 8 + 1/5 с: одна строка за окном ассоциации
             * гарантирует видимость флагов/рейта на протяжении всей
             * попытки. */
            {
                static int s_oth_logged = 0;
                static u32 s_oth_last = 0;
                u32 now = timer_ticks();
                if (s_oth_logged < 8 || (u32)(now - s_oth_last) > 5000u) {
                    s_oth_logged++;
                    s_oth_last = now;
                    wifi_log("RX err: flags=%08x len=%u rssi=%d r=%02x",
                             (unsigned)flags, (unsigned)dlen, (int)rssi,
                             (unsigned)rxr);
                }
            }
            wc_rx_err(0);
        }
        /* перевзвести дескриптор (HW ушёл дальше по кольцу) */
        d->st[0] = d->st[1] = d->st[2] = d->st[3] = d->st[4] = 0;
        d->st[5] = d->st[6] = d->st[7] = d->st[8] = 0;
        d->ctl1 = WIFI_RXBUF_SZ;
        ath.rx_head = (ath.rx_head + 1) % WIFI_NUM_RXDESC;
    }
}

/* Sowl: буферы в FIFO по порядку; статусный префикс 44 б. */
static void sowl_rx_poll(void) {
    static const u32 rxdp_reg[WIFI_EDMA_QUEUES] = { AR_HP_RXDP, AR_LP_RXDP };
    for (int q = 0; q < WIFI_EDMA_QUEUES; q++) {
        if (!ath.edbuf[q][0]) continue;
        int budget = 4;
        while (budget-- > 0) {
            int h = ath.ed_head[q];
            u8 *base = ath.edbuf[q][h];
            volatile u32 *st = (volatile u32 *)base;
            if (!(st[10] & 0x00000001)) break;          /* не Done */
            if (((st[0] >> 16) & 0xFFFF) != 0x168c) break; /* не RX-статус */
            u32 dlen = st[2] & 0x00000FFF;
            i8 rssi = ath_rssi_dbm((u8)(st[5] >> 24));      /* [W-RSSI-NF] */
            if (st[10] & 0x00000002) {                  /* FrameOK */
                if (dlen >= 2 && dlen <= WIFI_RXBUF_SZ)
                    wc_rx_frame(base + WIFI_EDMA_ST_LEN, (int)dlen, rssi);
            } else if (st[10] & 0x00000004) {
                /* [W-CRCDIAG-sowl]: как в owl_rx_poll — длина/rssi битых */
                {
                    static int s_crc_logged = 0;
                    static u32 s_crc_last = 0;
                    if (s_crc_logged < 8 ||
                        (u32)(timer_ticks() - s_crc_last) > 5000u) {
                        s_crc_logged++;
                        s_crc_last = timer_ticks();
                        wifi_log("RX CRC-битый: len=%u rssi=%d",
                                 (unsigned)dlen, (int)rssi);
                    }
                }
                wc_rx_err(1);
            } else {
                wc_rx_err(0);
            }
            /* вернуть буфер в FIFO */
            memset(base, 0, WIFI_EDMA_ST_LEN);
            regw(rxdp_reg[q], (u32)(unsigned long)base);
            ath.ed_head[q] = (h + 1) % WIFI_EDMA_BUFS;
        }
    }
}

/* ================= сканирование ================= */

/* быстрая смена канала (RFBUS) [hw.c: ath9k_hw_channel_change,
 * без смены полосы: только regs+synth+delta+BB+NF] */
static int __attribute__((unused)) ath_fastcc(int ch_idx) {
    regw(AR_PHY_RFBUS_REQ, 0x00000001);
    if (!hw_wait(AR_PHY_RFBUS_GRANT, 0x1, 0x1, AH_WAIT_TIMEOUT_US)) {
        /* [ATH-DIAG] таймаут гранта логируется ЯВНО: прежде fallback
         * молча уходил в полный bring-up, и «прилипание» к каналу 1
         * было невидимо в логе */
        wifi_log("fastcc: RFBUS grant не пришёл за %d мс — полный bring-up",
                 AH_WAIT_TIMEOUT_US / 1000);
        return 0;
    }

    ath_set_channel_regs();
    ath_set_synth(ch_idx);
    ath_delta_slope(wc_channel_freq[ch_idx]);
    reg_clr(AR_PHY_FORCE_CLKEN_CCK, AR_PHY_CCK_MRC_MUX);   /* no spur */
    ath_init_bb();
    synth_delay_wait();
    regw(AR_PHY_RFBUS_REQ, 0);
    /* [W-CCCAL] (полевой лог AR9285: dwell ch 1 — 0 кадров, маяк той же
     * точки ловится только в окне перестройки на ch 2 с -55 dBm):
     * после bring-up калибровки CL/AGC выполнялись и RX работал; fastcc
     * их пропускал — приёмник деградировал до «глухого» на весь dwell.
     * Возвращаем калибровку в каждый переход (та же последовательность,
     * что и в bring-up, ~пара мс на канал — [W-CCSTAT] покажет новое
     * среднее время). Отступление от эталона осознанное: у Linux
     * состояние PHY живёт между сменами канала по-другому. */
    if (ath.is_sowl)
        sowl_agc_cal();
    else if (ath.chip == CHIP_AR9287)
        kite_agc_cal();
    else
        owl_cl_cal();
    /* [W-TXPOW]: мощность обязана перепрограммироваться после каждой
     * перестройки (как set_txpower в эталоне) */
    if (!ath.is_sowl)
        ath_txpow_program();
    ath_nf_load_start();
    return 1;
}

/* [W-FASTCC-OFF] Выключатель быстрой смены канала. Полевой лог: fastcc
 * «формально успешен» (RFBUS-грант приходит, 11-12 мс), но RX после
 * него глух — второй скан дал 0 кадров на ВСЕХ каналах, PREAUTH на
 * канале точки — 0 маяков; полный bring-up на ТОМ ЖЕ канале слух
 * возвращает (3 маяка за 340 мс). Даже добавленные в fastcc калибровки
 * (CL/AGC + txpow + NF) проблему не закрыли. Плейсхолдер-фикс по
 * полевой диагностике: на время скана/подключения fastcc не
 * использовать — полный ath_bringup() на каждый канал. Стоимость
 * ~50-150 мс на канал при dwell 220 мс (скан ~5 с вместо ~3.3 с) —
 * корректность важнее. Код fastcc сохранён (его txpow теперь тоже
 * пишет правильные регистры): для экспериментов включить 1. */
#define ATH_USE_FASTCC 0

/* ---- ops->set_channel: fastcc, при неудаче полный bring-up ----
 * [ATH-CC] ГЛАВНАЯ находка: bring-up всегда настраивал канал 0, поэтому
 * при провале fastcc (RFBUS-грант не пришёл) радио «прилипало» к каналу 1:
 * скан видел только сети канала 1, точка на другом канале не подключалась
 * (AUTH без ответа). Теперь запрошенный канал запоминается ДО bring-up —
 * полный init настраивает ЕГО.
 *
 * [W-CCSTAT] (полевой лог AR9285: «большинство каналов 0 кадров»):
 * статистика смен канала за проход — сколько fastcc, сколько полных
 * bring-up, сколько мс занимает перестройка (должна быть единицы мс;
 * каждое переключение срезает время «слушания» из dwell-окна 110 мс —
 * если перестройка занимает ~100 мс, канал фактически глух весь кадр).
 * Итог печатается ОДНОЙ строкой при начале следующего прохода
 * (первый set_channel(0) после накопленной статистики). */
static struct {
    int switches;     /* перестроек в накопленной статистике */
    int fastcc;       /* из них быстрых */
    int bringups;     /* полных bring-up (медленных) */
    u32 total_ms;     /* суммарное время перестроек */
    u32 max_ms;       /* самая долгая */
} g_ccstat;

static int ath_ops_set_channel(int ch_idx) {
    if (ch_idx < 0 || ch_idx >= WC_NUM_CHANNELS) return 0;
    /* [W-CCSTAT]: начало нового прохода (канал 0 после накопленных
     * перестроек) — отпечатать итог ПРОШЛОГО и обнулить */
    if (ch_idx == 0 && g_ccstat.switches > 0) {
        char b[128];
        snprintf(b, sizeof(b),
                 "смен канала: %d (fastcc %d, bring-up %d), "
                 "время ср %u мс / макс %u мс",
                 g_ccstat.switches, g_ccstat.fastcc, g_ccstat.bringups,
                 g_ccstat.switches ? g_ccstat.total_ms / (u32)g_ccstat.switches : 0,
                 g_ccstat.max_ms);
        wifi_log("%s", b);
        memset(&g_ccstat, 0, sizeof(g_ccstat));
    }
    /* [W-SAMECH] (полевой лог AR9285: dwell ch 1 стабильно 0 кадров, маяк
     * ловится только в окне ch 2, но PREAUTH на ch 1 принимает 3 маяка
     * за 340 мс): скан стартует с set_channel(0) при радио УЖЕ на канале 1
     * (после init и после PREAUTH) — выполнялся fastcc «на тот же канал».
     * Linux так никогда не делает: ath9k_hw_do_fastcc() при совпадении
     * канала делает «goto fail» (полный reset вместо fastcc). Лишний
     * RFBUS-цикл + перезапись синтезатора тем же значением + калибровки
     * — состояние PHY после этого не гарантировано. Если радио уже
     * поднято и стоит на запрошенном канале — НЕ трогаем вовсе. */
    if (ath.ready && ch_idx == ath.chan) return 1;
    u32 t0 = timer_ticks();
    ath.chan = ch_idx;              /* bring-up (если будет) — на ЭТОТ канал */
#if ATH_USE_FASTCC
    int ok = ath_fastcc(ch_idx);
    if (!ok) ok = (ath_bringup() == 0);
#else
    /* [W-FASTCC-OFF] всегда полный bring-up: детальные строки подавлены
     * (W-QUIET), останется одна сводная «bring-up ch N: ok (NF=…)» */
    g_bringup_quiet = 1;
    int ok = (ath_bringup() == 0);
    g_bringup_quiet = 0;
#endif
    {
        u32 dt = (u32)(timer_ticks() - t0);
        g_ccstat.switches++;
#if ATH_USE_FASTCC
        if (ok) g_ccstat.fastcc++; else g_ccstat.bringups++;
#else
        g_ccstat.bringups++;
#endif
        g_ccstat.total_ms += dt;
        if (dt > g_ccstat.max_ms) g_ccstat.max_ms = dt;
        /* медленная перестройка: съедает dwell-окно — видно сразу.
         * [W-FASTCC-OFF] для полного bring-up 50-150 мс — НОРМА, порог
         * предупреждения поднят до 400 мс */
#if ATH_USE_FASTCC
        if (dt > 50u)
#else
        if (dt > 400u)
#endif
            wifi_log("ch %d: перестройка %u мс — медленно%s",
                     ch_idx + 1, (unsigned)dt,
                     ok ? "" : " (bring-up)");
    }
    return ok;
}

/* ===================== TX + подключение (сессия 11) ===================== */

/* ---- чтение EEPROM (PCI, косвенный доступ) [pci.c: ath_pci_eeprom_read] ----
 * Запрос: чтение регистра по адресу AR5416_EEPROM_OFFSET + (word << 2),
 * ожидание снятия BUSY|PROT_ACCESS в статусе, данные — младшие 16 бит. */
static int eeprom_read_word(int word, u16 *out) {
    u32 stat_reg = ath.is_sowl ? AR_EEPROM_STAT_SOWL : AR_EEPROM_STAT_OWL;
    (void)reg32(AR5416_EEPROM_OFFSET + ((u32)word << AR5416_EEPROM_S));
    for (int t = 0; t < 20000; t += 20) {      /* до 20 мс */
        u32 v = reg32(stat_reg);
        if (!(v & (EEST_BUSY | EEST_PROT_ACCESS))) {
            *out = (u16)(v & EEST_VAL);
            return 1;
        }
        w_udelay(20);
    }
    return 0;
}

/* MAC-адрес из EEPROM.
 * [W-EEP4K] (сверка с эталоном Linux eeprom.h: struct base_eep_header_4k,
 * __packed — v6.6, строки 313-329): раскладка 4K-заголовка
 *   length(0-1) checksum(2-3) version(4-5) opCapFlags(6) eepMisc(7)
 *   regDmn[2](8-11) macAddr[6](12-17) ... deviceType(30) txGainType(31)
 * т.е. MAC — СЛОВА 6-8 ОТ НАЧАЛА КАРТЫ (прежде читались слова 4-6 — это
 * regDmn[0..1] + первые 2 байта MAC: в поле получился «локальный»
 * адрес 16:8c:00:2b:50:08 — мусор из regDmn). Порядок байтов — LE:
 * macAddr[0] = МЛАДШИЙ байт слова 6 (Linux читает слова прямо в
 * __le16-структуру без swab; прежде брали старший байт).
 * Начало карты: у Linux eeprom_4k.c eep_start_loc = 64 для чтения из
 * EEPROM (не flash) — пробуем оба варианта (карта @ слово 0 и @ слово
 * 64), берём первый валидный (unicast, не ноль, не FF); сырые слова
 * печатаются в лог — сразу видно, совпадает ли MAC с наклейкой.
 *  - Sowl (AR9485, формат AR9300): слова 1-3 — как прежде (работает в поле). */
/* [W-EEP4K-v2] тип TX-усиления из карты EEPROM: 0 = low power,
 * 1 = high power [eeprom_4k.c: EEP_TXGAIN_TYPE, байт 31 заголовка];
 * 0xFFFFFFFF = не прочитано. Понадобится для выбора tx-gain таблицы. */
static u32 g_txgain_type = 0xFFFFFFFFu;

/* =====================================================================
 * [W-EEP4K-v3] Карта EEPROM AR9285 (4K): поиск + дамп + board values
 * + PDADC. Полевой лог v2: «EEPROM: magic НЕ найден» при заведомо
 * рабочих чтениях слов (MAC-фолбэк слова 6-8 читался). Причины могли
 * быть две: (а) карта лежит НЕ по слову 0/64 (сдвиг окна/OTP-начало),
 * (б) у карты слово 0 вообще не magic. v3 решает это так:
 *   1) ОДНОКРАТНЫЙ дамп сырых слов 0..31 и 64..79 в журнал — по нему
 *      видно всё: magic, length/checksum/version, custData, начало
 *      modal-заголовка (antCtrl), калибровочные pier'ы;
 *   2) СКАН magic 0x5aa5/0xa55a по словам 0..127 — если карта сдвинута
 *      на K слов, база карты = K+64;
 *   3) Контрольная сумма КАК В ЭТАЛОНЕ: ath9k_hw_nvram_validate_checksum
 *      (eeprom.c) XOR-ит слова 0..el-1 ОТ НАЧАЛА EEPROM (не от базы
 *      карты!), el = min(length/2, SIZE_EEPROM_4K); v2 считал сумму по
 *      словам ОТ БАЗЫ — расхождение с эталоном;
 *   4) После валидации карта читается ЦЕЛИКОМ в структуру (1:1
 *      eeprom.h v6.6, __packed, LE) — offsets больше не считаются
 *      вручную, MAC/txGainType/modal/pdadc берутся полями.
 * [W-EEP4K-v4] ПОЛЕВОЙ ЛОГ v3 (X101CH): дамп слов читается (слово 0 =
 *      a55a, слова 4-5 = 168c 002b — PCI VID/DID Atheros), но «magic НЕ
 *      найден», а length кандидата @64 = 7801 = swab16(0x0178). Причина
 *      найдена: в v3 swap-полярность была ИЗНАНКУ. Эталон (eeprom.c:
 *      ath9k_hw_nvram_swap_data): raw == 0xa55a -> LE (свопа НЕТ),
 *      raw == 0x5aa5 -> BE (своп ВСЕХ слов). Карта X101CH — LE, v3
 *      свопил её length 0x0178 -> 0x7801 и отбрасывал ВАЛИДНУЮ карту.
 *      Исправлено. Дополнительно: checksum считается как в эталоне —
 *      по словам карты ОТ БАЗЫ (data[] заполняется с eep_start_loc=64),
 *      абсолютный вариант — фолбэк; при несходстве обеих сумма
 *      печатается, а карта принимается с предупреждением, если
 *      length/version/MAC выглядят подлинными (у 4K-карточек с
 *      нестандартной прошивкой XOR бывает != 0xffff — важно не
 *      блокировать board values + PDADC, которые ждут валидации).
 * ===================================================================== */
#define AR5416_EEP4K_MAX_CHAINS         1
#define AR5416_EEP4K_NUM_PD_GAINS       2
#define AR5416_PD_GAINS_IN_MASK         4
#define AR5416_PD_GAIN_ICEPTS           5
#define AR5416_NUM_PDADC_VALUES         128
#define AR5416_MAX_PWR_RANGE_IN_HALF_DB 64
#define AR5416_BCHAN_UNUSED             0xFF
#define AR5416_EEP4K_NUM_2G_CAL_PIERS   3
#define EEP4K_NUM_TP                    3
#define AR5416_EEP4K_NUM_CTLS           12
#define AR5416_EEP4K_NUM_BAND_EDGES     4
#define AR_EEPROM_MODAL_SPURS           5
#define EEP4K_MAX_RATE_POWER            63
#define AR5416_EEP_MINOR_VER_2          2
#define AR5416_EEP_MINOR_VER_3          3

/* --- регистры PHY [ar9002_phy.h / reg.h v6.6, адреса сверены] --- */
#define AR_PHY_RF_CTL2                  0x9824
#define AR_PHY_TX_END_DATA_START        0x000000FF
#define AR_PHY_TX_END_DATA_START_S      0
#define AR_PHY_TX_END_PA_ON             0x0000FF00
#define AR_PHY_TX_END_PA_ON_S           8
#define AR_PHY_RF_CTL3                  0x9828
#define AR_PHY_TX_END_TO_A2_RX_ON       0x00FF0000
#define AR_PHY_TX_END_TO_A2_RX_ON_S     16
#define AR_PHY_RF_CTL4                  0x9834
#define AR_PHY_RF_CTL4_TX_END_XPAA_OFF  0x00FF0000
#define AR_PHY_RF_CTL4_TX_END_XPAA_OFF_S 16
#define AR_PHY_RF_CTL4_FRAME_XPAA_ON    0x000000FF
#define AR_PHY_RF_CTL4_FRAME_XPAA_ON_S  0
#define AR_PHY_SETTLING                 0x9844
#define AR_PHY_SETTLING_SWITCH          0x00003F80
#define AR_PHY_SETTLING_SWITCH_S        7
#define AR_PHY_RXGAIN                   0x9848
#define AR9280_PHY_RXGAIN_TXRX_ATTEN    0x00003F80
#define AR9280_PHY_RXGAIN_TXRX_ATTEN_S  7
#define AR9280_PHY_RXGAIN_TXRX_MARGIN   0x001FC000
#define AR9280_PHY_RXGAIN_TXRX_MARGIN_S 14
#define AR_PHY_DESIRED_SZ               0x9850
#define AR_PHY_DESIRED_SZ_ADC           0x000000FF
#define AR_PHY_DESIRED_SZ_ADC_S         0
#define AR9280_PHY_CCA_THRESH62         0x000FF000
#define AR9280_PHY_CCA_THRESH62_S       12
#define AR_PHY_TIMING_CTRL4(_i)         (0x9920u + ((u32)(_i) << 12))
#define AR_PHY_TIMING_CTRL4_IQCORR_Q_Q_COFF   0x01F
#define AR_PHY_TIMING_CTRL4_IQCORR_Q_Q_COFF_S 0
#define AR_PHY_TIMING_CTRL4_IQCORR_Q_I_COFF   0x7E0
#define AR_PHY_TIMING_CTRL4_IQCORR_Q_I_COFF_S 5
#define AR_PHY_SWITCH_CHAIN_0           0x9960
#define AR_PHY_SWITCH_COM               0x9964
#define AR_PHY_MULTICHAIN_GAIN_CTL      0x99ac
#define AR_PHY_9285_ANT_DIV_CTL_ALL     0x7f000000
#define AR_PHY_9285_ANT_DIV_CTL         0x01000000
#define AR_PHY_9285_ANT_DIV_CTL_S       24
#define AR_PHY_9285_ANT_DIV_ALT_LNACONF   0x06000000
#define AR_PHY_9285_ANT_DIV_ALT_LNACONF_S 25
#define AR_PHY_9285_ANT_DIV_MAIN_LNACONF  0x18000000
#define AR_PHY_9285_ANT_DIV_MAIN_LNACONF_S 27
#define AR_PHY_9285_ANT_DIV_ALT_GAINTB    0x20000000
#define AR_PHY_9285_ANT_DIV_ALT_GAINTB_S  29
#define AR_PHY_9285_ANT_DIV_MAIN_GAINTB   0x40000000
#define AR_PHY_9285_ANT_DIV_MAIN_GAINTB_S 30
#define AR_PHY_EXT_CCA0                0x99b8
#define AR_PHY_EXT_CCA0_THRESH62       0x000000FF
#define AR_PHY_EXT_CCA0_THRESH62_S     0
#define AR_PHY_CCK_DETECT              0xA208
#define AR_PHY_CCK_DETECT_BB_ENABLE_ANT_FAST_DIV    0x2000
#define AR_PHY_CCK_DETECT_BB_ENABLE_ANT_FAST_DIV_S  13
#define AR_PHY_GAIN_2GHZ               0xA20C
#define AR_PHY_GAIN_2GHZ_XATTEN2_MARGIN   0x003E0000
#define AR_PHY_GAIN_2GHZ_XATTEN2_MARGIN_S 17
#define AR_PHY_GAIN_2GHZ_XATTEN1_MARGIN   0x0001F000
#define AR_PHY_GAIN_2GHZ_XATTEN1_MARGIN_S 12
#define AR_PHY_GAIN_2GHZ_XATTEN2_DB    0x00000FC0
#define AR_PHY_GAIN_2GHZ_XATTEN2_DB_S  6
#define AR_PHY_GAIN_2GHZ_XATTEN1_DB    0x0000003F
#define AR_PHY_GAIN_2GHZ_XATTEN1_DB_S  0
#define AR_PHY_TPCRG1_NUM_PD_GAIN      0x0000c000
#define AR_PHY_TPCRG1_NUM_PD_GAIN_S    14
#define AR_PHY_TPCRG1_PD_GAIN_1        0x00030000
#define AR_PHY_TPCRG1_PD_GAIN_1_S      16
#define AR_PHY_TPCRG1_PD_GAIN_2        0x000C0000
#define AR_PHY_TPCRG1_PD_GAIN_2_S      18
#define AR_PHY_TPCRG1_PD_GAIN_3        0x00300000
#define AR_PHY_TPCRG1_PD_GAIN_3_S      20
#define AR_PHY_TPCRG5                  0xA26C
#define AR_PHY_TPCRG5_PD_GAIN_OVERLAP  0x0000000F
#define AR_PHY_TPCRG5_PD_GAIN_OVERLAP_S 0
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_1 0x000003F0
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_1_S 4
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_2 0x0000FC00
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_2_S 10
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_3 0x003F0000
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_3_S 16
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_4 0xFC000000
#define AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_4_S 22
#define AR_PHY_TX_PWRCTRL8             0xa278
#define AR_PHY_TX_PWRCTRL9             0xa27C
#define AR_PHY_TX_PWRCTRL10            0xa394
#define AR_PHY_CH0_TX_PWRCTRL11        0xa398
#define AR_PHY_CH0_TX_PWRCTRL12        0xa3dc
#define AR_PHY_CH0_TX_PWRCTRL13        0xa3e0
#define AR9285_AN_RF2G3                0x7828
#define AR9285_AN_RF2G3_OB_0           0x00E00000
#define AR9285_AN_RF2G3_OB_0_S         21
#define AR9285_AN_RF2G3_OB_1           0x001C0000
#define AR9285_AN_RF2G3_OB_1_S         18
#define AR9285_AN_RF2G3_OB_2           0x00038000
#define AR9285_AN_RF2G3_OB_2_S         15
#define AR9285_AN_RF2G3_OB_3           0x00007000
#define AR9285_AN_RF2G3_OB_3_S         12
#define AR9285_AN_RF2G3_OB_4           0x00000E00
#define AR9285_AN_RF2G3_OB_4_S         9
#define AR9285_AN_RF2G3_DB1_0          0x000001C0
#define AR9285_AN_RF2G3_DB1_0_S        6
#define AR9285_AN_RF2G3_DB1_1          0x00000038
#define AR9285_AN_RF2G3_DB1_1_S        3
#define AR9285_AN_RF2G3_DB1_2          0x00000007
#define AR9285_AN_RF2G3_DB1_2_S        0
#define AR9285_AN_RF2G4                0x782C
#define AR9285_AN_RF2G4_DB1_3          0xE0000000
#define AR9285_AN_RF2G4_DB1_3_S        29
#define AR9285_AN_RF2G4_DB1_4          0x1C000000
#define AR9285_AN_RF2G4_DB1_4_S        26
#define AR9285_AN_RF2G4_DB2_0          0x03800000
#define AR9285_AN_RF2G4_DB2_0_S        23
#define AR9285_AN_RF2G4_DB2_1          0x00700000
#define AR9285_AN_RF2G4_DB2_1_S        20
#define AR9285_AN_RF2G4_DB2_2          0x000E0000
#define AR9285_AN_RF2G4_DB2_2_S        17
#define AR9285_AN_RF2G4_DB2_3          0x0001C000
#define AR9285_AN_RF2G4_DB2_3_S        14
#define AR9285_AN_RF2G4_DB2_4          0x00003800
#define AR9285_AN_RF2G4_DB2_4_S        11
/* таблица PDADC: AR_PHY_BASE(0x9800) + (672<<2) = 0xA280, 32 dword'а */
#define AR_PHY_PDADC_TABLE             (0x9800u + (672u << 2))

/* --- структуры 1:1 из eeprom.h v6.6 (LE-хост, packed) --- */
typedef struct {
    u16 length;        /* слово 0: длина карты в байтах */
    u16 checksum;      /* слово 1 */
    u16 version;       /* слово 2: major[15:12], minor[11:0] */
    u8  opCapFlags;    /* 6 */
    u8  eepMisc;       /* 7 */
    u16 regDmn[2];     /* 8-11 */
    u8  macAddr[6];    /* 12-17 = слова 6..8 */
    u8  rxMask;        /* 18 */
    u8  txMask;        /* 19 */
    u16 rfSilent;      /* 20-21 */
    u16 blueToothOptions; /* 22-23 */
    u16 deviceCap;     /* 24-25 */
    u32 binBuildNumber;/* 26-29 */
    u8  deviceType;    /* 30 */
    u8  txGainType;    /* 31: 0 = low power, 1 = high power */
} __attribute__((__packed__)) eep4k_base_t;

typedef struct {
    u32 antCtrlChain[AR5416_EEP4K_MAX_CHAINS];
    u32 antCtrlCommon;
    u8  antennaGainCh[AR5416_EEP4K_MAX_CHAINS];
    u8  switchSettling;
    u8  txRxAttenCh[AR5416_EEP4K_MAX_CHAINS];
    u8  rxTxMarginCh[AR5416_EEP4K_MAX_CHAINS];
    u8  adcDesiredSize;
    u8  pgaDesiredSize;
    u8  xlnaGainCh[AR5416_EEP4K_MAX_CHAINS];
    u8  txEndToXpaOff;
    u8  txEndToRxOn;
    u8  txFrameToXpaOn;
    u8  thresh62;
    u8  noiseFloorThreshCh[AR5416_EEP4K_MAX_CHAINS];
    u8  xpdGain;
    u8  xpd;
    u8  iqCalICh[AR5416_EEP4K_MAX_CHAINS];
    u8  iqCalQCh[AR5416_EEP4K_MAX_CHAINS];
    u8  pdGainOverlap;
    u8  ob_0:4, ob_1:4;
    u8  db1_0:4, db1_1:4;
    u8  xpaBiasLvl;
    u8  txFrameToDataStart;
    u8  txFrameToPaOn;
    u8  ht40PowerIncForPdadc;
    u8  bswAtten[AR5416_EEP4K_MAX_CHAINS];
    u8  bswMargin[AR5416_EEP4K_MAX_CHAINS];
    u8  swSettleHt40;
    u8  xatten2Db[AR5416_EEP4K_MAX_CHAINS];
    u8  xatten2Margin[AR5416_EEP4K_MAX_CHAINS];
    u8  db2_0:4, db2_1:4;
    u8  version;
    u8  ob_2:4, ob_3:4;
    u8  ob_4:4, antdiv_ctl1:4;
    u8  db1_2:4, db1_3:4;
    u8  db1_4:4, antdiv_ctl2:4;
    u8  db2_2:4, db2_3:4;
    u8  db2_4:4, reserved:4;
    u8  tx_diversity;
    u8  flc_pwr_thresh;
    u8  bb_scale_smrt_antenna;
    u8  futureModal[1];
    struct { u16 spurChan; u8 spurRangeLow; u8 spurRangeHigh; } spurChans[AR_EEPROM_MODAL_SPURS];
} __attribute__((__packed__)) eep4k_modal_t;

/* фиксируем раскладку: эталон (Linux eeprom.h v6.6) даёт ровно 376 байт
 * (base 32 + custData 20 + modal 68 + pier'ы/target powers/ctl) */
_Static_assert(sizeof(eep4k_base_t) == 32,  "eep4k base layout");
_Static_assert(sizeof(eep4k_modal_t) == 68, "eep4k modal layout");

typedef struct {
    u8 pwrPdg[AR5416_EEP4K_NUM_PD_GAINS][AR5416_PD_GAIN_ICEPTS];
    u8 vpdPdg[AR5416_EEP4K_NUM_PD_GAINS][AR5416_PD_GAIN_ICEPTS];
} __attribute__((__packed__)) eep4k_calper_t;

typedef struct { u8 bChannel; u8 tPow2x[4]; } __attribute__((__packed__)) eep4k_tpow_leg_t;
typedef struct { u8 bChannel; u8 tPow2x[8]; } __attribute__((__packed__)) eep4k_tpow_ht_t;
typedef struct { u8 bChannel; u8 ctl; } __attribute__((__packed__)) eep4k_ctl_edge_t;
typedef struct { eep4k_ctl_edge_t ctlEdges[AR5416_EEP4K_MAX_CHAINS][AR5416_EEP4K_NUM_BAND_EDGES]; } __attribute__((__packed__)) eep4k_ctldata_t;

typedef struct {
    eep4k_base_t baseEepHeader;
    u8 custData[20];
    eep4k_modal_t modalHeader;
    u8 calFreqPier2G[AR5416_EEP4K_NUM_2G_CAL_PIERS];
    eep4k_calper_t calPierData2G[AR5416_EEP4K_MAX_CHAINS][AR5416_EEP4K_NUM_2G_CAL_PIERS];
    eep4k_tpow_leg_t calTargetPowerCck[EEP4K_NUM_TP];
    eep4k_tpow_leg_t calTargetPower2G[EEP4K_NUM_TP];
    eep4k_tpow_ht_t calTargetPower2GHT20[EEP4K_NUM_TP];
    eep4k_tpow_ht_t calTargetPower2GHT40[EEP4K_NUM_TP];
    u8 ctlIndex[AR5416_EEP4K_NUM_CTLS];
    eep4k_ctldata_t ctlData[AR5416_EEP4K_NUM_CTLS];
    u8 padding;
} __attribute__((__packed__)) eep4k_map_t;

#define EEP4K_MAP_WORDS (sizeof(eep4k_map_t) / 2)
_Static_assert(sizeof(eep4k_map_t) == 376, "eep4k full map layout");

static eep4k_map_t g_eep4k;               /* карта (swap при необходимости выполнен) */
static int  g_eep4k_ok   = 0;             /* карта валидна (checksum сошлась) */
static int  g_eep4k_base = -1;            /* слово начала карты в EEPROM */
static int  g_eep4k_swap = 0;             /* 1 = BE-карта (raw magic 0x5aa5) */

/* дамп сырых слов + статусы чтения: слова 0..31 и 64..79, по 8 в строке.
 * Статус-биты регистра 0x407c (BUSY/PROT/ABSENT) — индикация «EEPROM
 * отсутствует/защищён» прямо в журнале. */
static void eeprom_dump_words(void) {
    static const int ranges[2][2] = { {0, 32}, {64, 80} };
    int nbusy = 0, nfail = 0;
    u32 stat_reg = ath.is_sowl ? AR_EEPROM_STAT_SOWL : AR_EEPROM_STAT_OWL;
    u32 last_stat = reg32(stat_reg);
    wifi_log("EEPROM статус 0x%x: %08x (бит19=ABSENT, 18=PROT, 16=BUSY)",
             (unsigned)stat_reg, (unsigned)last_stat);
    for (int r = 0; r < 2; r++) {
        for (int start = ranges[r][0]; start < ranges[r][1]; start += 8) {
            char line[100];
            int pos = 0;
            pos += snprintf(line, sizeof(line), "EEPROM[%3d..%2d]:",
                            start, start + 7);
            for (int i = 0; i < 8; i++) {
                u16 w;
                if (eeprom_read_word(start + i, &w))
                    pos += snprintf(line + pos, sizeof(line) - pos,
                                    " %04x", (unsigned)w);
                else {
                    pos += snprintf(line + pos, sizeof(line) - pos, " ----");
                    nfail++;
                }
            }
            wifi_log("%s", line);
        }
    }
    if (nfail) wifi_log("EEPROM: %d чтений не завершились (BUSY-таймаут)",
                        nfail);
    (void)nbusy;
}

/* «Карта похожа на подлинную» без checksum (length уже проверен
 * вызывающим): версия major=14 и MAC base+6..8 — unicast, не ноль/FF.
 * 4K-карточки с нестандартной (OTP-подобной) прошивкой дают XOR !=
 * 0xffff; блокировать на этом board values + PDADC нельзя — поэтому
 * предупреждаем и принимаем. */
static int eep4k_looks_genuine(int base, int swap) {
    u16 w;
    u8 mac[6];
    int i;
    if (!eeprom_read_word(base + 2, &w)) return 0;
    if (swap) w = (u16)((w >> 8) | (w << 8));
    if ((w >> 12) != 0xEu) return 0;          /* version major != 14 */
    for (i = 0; i < 3; i++) {
        if (!eeprom_read_word(base + 6 + i, &w)) return 0;
        if (swap) w = (u16)((w >> 8) | (w << 8));
        mac[2 * i]     = (u8)(w & 0xFF);      /* LE: macAddr[0] = младший */
        mac[2 * i + 1] = (u8)(w >> 8);
    }
    if (mac[0] & 1) return 0;
    {
        u32 orv = 0, andv = 0xFFu;
        for (i = 0; i < 6; i++) { orv |= mac[i]; andv &= mac[i]; }
        if (orv == 0 || andv == 0xFFu) return 0;
    }
    return 1;
}

/* XOR-контрольная сумма: слово-слово XOR == 0xffff [eeprom.c:
 * ath9k_hw_nvram_validate_checksum — суммируются слова МАССИВА КАРТЫ,
 * т.е. от eep_start_loc]. from_abs=1 — слова 0..el-1 от начала EEPROM
 * (фолбэк на нестандартное окно), иначе — от базы карты (эталон).
 * Сумма возвращается через out_sum для журнала. */
static int eeprom_checksum_ok(int base, int el, int from_abs, u16 *out_sum) {
    u32 sum = 0;
    int start = from_abs ? 0 : base;
    for (int i = 0; i < el; i++) {
        u16 w;
        if (!eeprom_read_word(start + i, &w)) {
            if (out_sum) *out_sum = 0;
            return 0;
        }
        if (g_eep4k_swap) w = (u16)((w >> 8) | (w << 8));
        sum ^= w;
    }
    if (out_sum) *out_sum = (u16)sum;
    return (sum & 0xFFFFu) == 0xFFFFu;
}

/* [W-EEP4K-v3] поиск карты: magic-скан + кандидаты базы + checksum.
 * Сигнатура совместима с v2 (вызывается из read_mac_from_eeprom). */
static int eeprom_map_probe(int *out_base, int *out_swap, u16 *out_hdr3) {
    int magic_at = -1, swap = 0;
    u16 w0;

    eeprom_dump_words();

    /* magic: AR5416_EEPROM_MAGIC = 0xa55a [eeprom.c:
     * ath9k_hw_nvram_swap_data]: raw == 0xa55a -> LE-карта (свопа НЕТ),
     * swab16(raw) == 0xa55a (raw == 0x5aa5) -> BE-карта (своп ВСЕХ слов).
     * [W-EEP4K-v4] в v3 ветки были перепутаны: карта с raw 0xa55a
     * считалась BE и отбрасывалась. Скан 0..127 — на случай сдвига
     * окна чтения (диагностика + обход). */
    for (int i = 0; i < 128; i++) {
        if (!eeprom_read_word(i, &w0)) continue;
        if (w0 == 0xa55au)      { magic_at = i; swap = 0; break; }
        if (w0 == 0x5aa5u)      { magic_at = i; swap = 1; break; }
    }
    if (magic_at < 0) {
        wifi_log("EEPROM: magic 0x5aa5/0xa55a НЕ найден в словах 0..127 "
                 "— карта недоступна через это окно (см. дамп выше)");
        return 0;
    }
    g_eep4k_swap = swap;
    if (magic_at != 0)
        wifi_log("EEPROM: magic найден @ слово %d (swap=%d) — "
                 "окно чтения сдвинуто, база карты = %d+64",
                 magic_at, swap, magic_at);

    /* кандидаты базы карты: 64 (eep_start_loc, Linux eeprom_4k.c),
     * 0 (flash) и, при сдвиге, magic_at+64 / magic_at */
    int cand[4];
    int ncand = 0;
    if (magic_at == 0) { cand[ncand++] = 64; cand[ncand++] = 0; }
    else { cand[ncand++] = magic_at + 64; cand[ncand++] = magic_at;
           cand[ncand++] = 64; cand[ncand++] = 0; }

    for (int c = 0; c < ncand; c++) {
        int base = cand[c];
        u16 lw;
        u32 el;
        if (!eeprom_read_word(base, &lw)) continue;
        if (swap) lw = (u16)((lw >> 8) | (lw << 8));
        el = (u32)lw / 2u;
        if (el == 0 || el > EEP4K_MAP_WORDS) {
            if (lw != 0 && lw != 0xFFFFu)
                wifi_log("EEPROM: кандидат @%d: length=%04x вне диапазона",
                         base, (unsigned)lw);
            continue;
        }
        /* эталон — checksum ОТ БАЗЫ карты (Linux data[] = слова с
         * eep_start_loc); абсолютный вариант — фолбэк */
        u16 sum_rel = 0, sum_abs = 0;
        int ok_rel = eeprom_checksum_ok(base, (int)el, 0, &sum_rel);
        int ok_abs = ok_rel ? 0
                   : eeprom_checksum_ok(base, (int)el, 1, &sum_abs);
        if (!ok_rel && !ok_abs) {
            if (eep4k_looks_genuine(base, swap)) {
                wifi_log("EEPROM: кандидат @%d: checksum НЕ сошлась "
                         "(sum=%04x abs=%04x) — принята по length/"
                         "version/MAC (предупреждение)",
                         base, (unsigned)sum_rel, (unsigned)sum_abs);
            } else {
                wifi_log("EEPROM: кандидат @%d: checksum НЕ сошлась "
                         "(sum=%04x abs=%04x, len=%u слов)", base,
                         (unsigned)sum_rel, (unsigned)sum_abs,
                         (unsigned)el);
                continue;
            }
        }
        /* читаем карту целиком */
        int good = 1;
        for (u32 i = 0; i < EEP4K_MAP_WORDS; i++) {
            u16 w;
            if (!eeprom_read_word(base + (int)i, &w)) { good = 0; break; }
            ((u16 *)&g_eep4k)[i] = swap ? (u16)((w >> 8) | (w << 8)) : w;
        }
        if (!good) {
            wifi_log("EEPROM: чтение карты @%d оборвалось", base);
            continue;
        }
        g_eep4k_ok = 1;
        g_eep4k_base = base;
        *out_base = base;
        *out_swap = swap;
        for (int i = 0; i < 3; i++)
            out_hdr3[i] = ((u16 *)&g_eep4k)[i];
        wifi_log("EEPROM: карта @ слово %d ВАЛИДНА (%s, "
                 "len=%u слов, ver=%04x, %d байт)",
                 base,
                 ok_rel ? "checksum от базы (эталон)" :
                 ok_abs ? "checksum абсолютная (фолбэк)" :
                          "checksum НЕ сошлась — принято по length/"
                          "version/MAC",
                 (unsigned)el,
                 (unsigned)g_eep4k.baseEepHeader.version,
                 (int)sizeof(eep4k_map_t));
        return 1;
    }
    wifi_log("EEPROM: magic найден @%d, но ни один кандидат не прошёл "
             "length/checksum — fallback", magic_at);
    return 0;
}

/* =====================================================================
 * [W-BOARD4K] Установка board values из modal-заголовка — порт 1:1
 * ath9k_hw_4k_set_board_values + ath9k_hw_4k_set_gain (eeprom_4k.c
 * v6.6). Запускается в bring-up ПОСЛЕ ini-массивов и настройки канала,
 * ДО init_bb/калибровки — как в ath9k_hw_reset. Правит ровно те
 * регистры, что перечислены в ar9002_phy.h: SWITCH_COM 0x9964,
 * SWITCH_CHAIN_0 0x9960, SETTLING 0x9844, RXGAIN 0x9848,
 * DESIRED_SZ 0x9850 и т.д. — до этого антеннный коммутатор и gain-
 * конфигурация оставались на ini-умолчаниях.
 * ===================================================================== */
static u32 phy_rmw(u32 addr, u32 mask, u32 val) {
    u32 v = reg32(addr);
    v = (v & ~mask) | (val & mask);
    regw(addr, v);
    return v;
}
static u32 phy_rmw_field(u32 addr, u32 mask, u32 shift, u32 val) {
    return phy_rmw(addr, mask, val << shift);
}

static void ath_4k_set_gain(u8 txRxAttenLocal) {
    eep4k_modal_t *m = &g_eep4k.modalHeader;
    int rev3 = ((g_eep4k.baseEepHeader.version & 0xFFFu) >= AR5416_EEP_MINOR_VER_3);

    phy_rmw(AR_PHY_SWITCH_CHAIN_0, 0xFFFFFFFFu, m->antCtrlChain[0]);

    phy_rmw(AR_PHY_TIMING_CTRL4(0),
            AR_PHY_TIMING_CTRL4_IQCORR_Q_Q_COFF |
            AR_PHY_TIMING_CTRL4_IQCORR_Q_I_COFF,
            ((u32)m->iqCalICh[0] << AR_PHY_TIMING_CTRL4_IQCORR_Q_I_COFF_S) |
            ((u32)m->iqCalQCh[0] << AR_PHY_TIMING_CTRL4_IQCORR_Q_Q_COFF_S));

    if (rev3) {
        txRxAttenLocal = m->txRxAttenCh[0];
        for (int c = 0; c < 2; c++) {          /* блок 0 и +0x1000 */
            u32 a = AR_PHY_GAIN_2GHZ + (u32)c * 0x1000u;
            phy_rmw_field(a, AR_PHY_GAIN_2GHZ_XATTEN1_MARGIN,
                          AR_PHY_GAIN_2GHZ_XATTEN1_MARGIN_S, m->bswMargin[0]);
            phy_rmw_field(a, AR_PHY_GAIN_2GHZ_XATTEN1_DB,
                          AR_PHY_GAIN_2GHZ_XATTEN1_DB_S, m->bswAtten[0]);
            phy_rmw_field(a, AR_PHY_GAIN_2GHZ_XATTEN2_MARGIN,
                          AR_PHY_GAIN_2GHZ_XATTEN2_MARGIN_S, m->xatten2Margin[0]);
            phy_rmw_field(a, AR_PHY_GAIN_2GHZ_XATTEN2_DB,
                          AR_PHY_GAIN_2GHZ_XATTEN2_DB_S, m->xatten2Db[0]);
        }
    }

    phy_rmw_field(AR_PHY_RXGAIN, AR9280_PHY_RXGAIN_TXRX_ATTEN,
                  AR9280_PHY_RXGAIN_TXRX_ATTEN_S, txRxAttenLocal);
    phy_rmw_field(AR_PHY_RXGAIN, AR9280_PHY_RXGAIN_TXRX_MARGIN,
                  AR9280_PHY_RXGAIN_TXRX_MARGIN_S, m->rxTxMarginCh[0]);
    phy_rmw_field(AR_PHY_RXGAIN + 0x1000u, AR9280_PHY_RXGAIN_TXRX_ATTEN,
                  AR9280_PHY_RXGAIN_TXRX_ATTEN_S, txRxAttenLocal);
    phy_rmw_field(AR_PHY_RXGAIN + 0x1000u, AR9280_PHY_RXGAIN_TXRX_MARGIN,
                  AR9280_PHY_RXGAIN_TXRX_MARGIN_S, m->rxTxMarginCh[0]);
}

/* [W-LOGCHG] bring-up печатает одинаковые строки на КАЖДОМ канале
 * (3 строки x 14 каналов x каждый скан/подключение ≈ 5 КБ —
 * полевой лог итерации 11: полезные строки выталкивались из
 * кольца klog). Печатаем только если строка ИЗМЕНИЛАСЬ с прошлой
 * печати того же рода (у PDADC границы зависят от канала). */
static int wifi_log_changed(char *memo, int memosz, const char *text)
{
    if (strncmp(memo, text, (u32)memosz) == 0) return 0;
    snprintf(memo, (u32)memosz, "%s", text);
    return 1;
}
static char s_memo_eep[160], s_memo_pd[160], s_memo_tm[160];

static void ath_4k_set_board_values(void) {
    eep4k_modal_t *m = &g_eep4k.modalHeader;
    eep4k_base_t *b = &g_eep4k.baseEepHeader;
    u8 ob[5], db1[5], db2[5];
    u8 txRxAttenLocal = 23;

    regw(AR_PHY_SWITCH_COM, m->antCtrlCommon);
    ath_4k_set_gain(txRxAttenLocal);

    /* антенная диверсити (modal version >= 3) */
    if (m->version >= 3) {
        u8 adc1 = m->antdiv_ctl1, adc2 = m->antdiv_ctl2;
        u32 v = reg32(AR_PHY_MULTICHAIN_GAIN_CTL);
        v &= ~AR_PHY_9285_ANT_DIV_CTL_ALL;
        v |= ((u32)adc1 << AR_PHY_9285_ANT_DIV_CTL_S) |
             ((u32)adc2 << AR_PHY_9285_ANT_DIV_ALT_LNACONF_S) |
             ((u32)(adc2 >> 2) << AR_PHY_9285_ANT_DIV_MAIN_LNACONF_S) |
             ((u32)(adc1 >> 1) << AR_PHY_9285_ANT_DIV_ALT_GAINTB_S) |
             ((u32)(adc1 >> 2) << AR_PHY_9285_ANT_DIV_MAIN_GAINTB_S);
        regw(AR_PHY_MULTICHAIN_GAIN_CTL, v);
        v = reg32(AR_PHY_CCK_DETECT);
        v &= ~AR_PHY_CCK_DETECT_BB_ENABLE_ANT_FAST_DIV;
        v |= ((u32)(adc1 >> 3) << AR_PHY_CCK_DETECT_BB_ENABLE_ANT_FAST_DIV_S);
        regw(AR_PHY_CCK_DETECT, v);
    }

    /* bias-таблицы OB/DB по modal version (2+: индивидуальные, 1: ob_1,
     * 0: ob_0) [eeprom_4k.c 826-859] */
    if (m->version >= 2) {
        ob[0] = m->ob_0;  ob[1] = m->ob_1;  ob[2] = m->ob_2;
        ob[3] = m->ob_3;  ob[4] = m->ob_4;
        db1[0] = m->db1_0; db1[1] = m->db1_1; db1[2] = m->db1_2;
        db1[3] = m->db1_3; db1[4] = m->db1_4;
        db2[0] = m->db2_0; db2[1] = m->db2_1; db2[2] = m->db2_2;
        db2[3] = m->db2_3; db2[4] = m->db2_4;
    } else if (m->version == 1) {
        ob[0] = m->ob_0; ob[1] = ob[2] = ob[3] = ob[4] = m->ob_1;
        db1[0] = m->db1_0; db1[1] = db1[2] = db1[3] = db1[4] = m->db1_1;
        db2[0] = m->db2_0; db2[1] = db2[2] = db2[3] = db2[4] = m->db2_1;
    } else {
        for (int i = 0; i < 5; i++) {
            ob[i] = m->ob_0; db1[i] = m->db1_0; db2[i] = m->db2_0;
        }
    }

    /* AR9285 (не 9271): аналоговые bias AR9285_AN_RF2G3/4 [864-964] */
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_OB_0, AR9285_AN_RF2G3_OB_0_S, ob[0]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_OB_1, AR9285_AN_RF2G3_OB_1_S, ob[1]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_OB_2, AR9285_AN_RF2G3_OB_2_S, ob[2]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_OB_3, AR9285_AN_RF2G3_OB_3_S, ob[3]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_OB_4, AR9285_AN_RF2G3_OB_4_S, ob[4]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_DB1_0, AR9285_AN_RF2G3_DB1_0_S, db1[0]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_DB1_1, AR9285_AN_RF2G3_DB1_1_S, db1[1]);
    phy_rmw_field(AR9285_AN_RF2G3, AR9285_AN_RF2G3_DB1_2, AR9285_AN_RF2G3_DB1_2_S, db1[2]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB1_3, AR9285_AN_RF2G4_DB1_3_S, db1[3]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB1_4, AR9285_AN_RF2G4_DB1_4_S, db1[4]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB2_0, AR9285_AN_RF2G4_DB2_0_S, db2[0]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB2_1, AR9285_AN_RF2G4_DB2_1_S, db2[1]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB2_2, AR9285_AN_RF2G4_DB2_2_S, db2[2]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB2_3, AR9285_AN_RF2G4_DB2_3_S, db2[3]);
    phy_rmw_field(AR9285_AN_RF2G4, AR9285_AN_RF2G4_DB2_4, AR9285_AN_RF2G4_DB2_4_S, db2[4]);

    /* тайминги и пороги [961-1005] */
    phy_rmw_field(AR_PHY_SETTLING, AR_PHY_SETTLING_SWITCH,
                  AR_PHY_SETTLING_SWITCH_S, m->switchSettling);
    phy_rmw_field(AR_PHY_DESIRED_SZ, AR_PHY_DESIRED_SZ_ADC,
                  AR_PHY_DESIRED_SZ_ADC_S, m->adcDesiredSize);
    phy_rmw(AR_PHY_RF_CTL4,
            AR_PHY_RF_CTL4_TX_END_XPAA_OFF | AR_PHY_RF_CTL4_FRAME_XPAA_ON,
            ((u32)m->txEndToXpaOff << AR_PHY_RF_CTL4_TX_END_XPAA_OFF_S) |
            ((u32)m->txFrameToXpaOn << AR_PHY_RF_CTL4_FRAME_XPAA_ON_S));
    phy_rmw_field(AR_PHY_RF_CTL3, AR_PHY_TX_END_TO_A2_RX_ON,
                  AR_PHY_TX_END_TO_A2_RX_ON_S, m->txEndToRxOn);
    phy_rmw_field(AR_PHY_CCA, AR9280_PHY_CCA_THRESH62,
                  AR9280_PHY_CCA_THRESH62_S, m->thresh62);
    phy_rmw_field(AR_PHY_EXT_CCA0, AR_PHY_EXT_CCA0_THRESH62,
                  AR_PHY_EXT_CCA0_THRESH62_S, m->thresh62);
    if ((g_eep4k.baseEepHeader.version & 0xFFFu) >= AR5416_EEP_MINOR_VER_2) {
        phy_rmw_field(AR_PHY_RF_CTL2, AR_PHY_TX_END_DATA_START,
                      AR_PHY_TX_END_DATA_START_S, m->txFrameToDataStart);
        phy_rmw_field(AR_PHY_RF_CTL2, AR_PHY_TX_END_PA_ON,
                      AR_PHY_TX_END_PA_ON_S, m->txFrameToPaOn);
    }
    if (m->version >= 3) {
        /* HT40 не используется (станция 20 МГц) — swSettleHt40 не пишем */
        (void)m->swSettleHt40;
    }

    /* bb_desired_scale при txGainType==0 [1007-1031] */
    {
        u8 scale = m->bb_scale_smrt_antenna & 0x1Fu;
        if ((b->txGainType == 0) && (scale != 0)) {
            u32 mask, pwrctrl, clr;
            mask = (1u << 0) | (1u << 5) | (1u << 10) | (1u << 15) |
                   (1u << 20) | (1u << 25);
            pwrctrl = mask * scale;
            clr = mask * 0x1fu;
            phy_rmw(AR_PHY_TX_PWRCTRL8, pwrctrl | clr, pwrctrl);
            phy_rmw(AR_PHY_TX_PWRCTRL10, pwrctrl | clr, pwrctrl);
            phy_rmw(AR_PHY_CH0_TX_PWRCTRL12, pwrctrl | clr, pwrctrl);
            mask = (1u << 0) | (1u << 5) | (1u << 15);
            pwrctrl = mask * scale;
            clr = mask * 0x1fu;
            phy_rmw(AR_PHY_TX_PWRCTRL9, pwrctrl | clr, pwrctrl);
            mask = (1u << 0) | (1u << 5);
            pwrctrl = mask * scale;
            clr = mask * 0x1fu;
            phy_rmw(AR_PHY_CH0_TX_PWRCTRL11, pwrctrl | clr, pwrctrl);
            phy_rmw(AR_PHY_CH0_TX_PWRCTRL13, pwrctrl | clr, pwrctrl);
        }
    }
    {
        char tmp[160];
        snprintf(tmp, sizeof(tmp),
                 "EEPROM board values применены (SWITCH_COM=%08x "
                 "antGain=%u settle=%u atten=%u modal_ver=%u txGainType=%u)",
                 (unsigned)m->antCtrlCommon,
                 (unsigned)m->antennaGainCh[0],
                 (unsigned)m->switchSettling,
                 (unsigned)m->txRxAttenCh[0],
                 (unsigned)m->version,
                 (unsigned)b->txGainType);
        if (wifi_log_changed(s_memo_eep, (int)sizeof(s_memo_eep), tmp))
            wifi_log("%s", tmp);
    }
}

/* =====================================================================
 * [W-PDADC4K] Калибровочная таблица PDADC — порт ath9k_hw_set_4k_power_
 * cal_table + ath9k_hw_get_gain_boundaries_pdadcs (eeprom_4k.c/eeprom.c
 * v6.6, только ветка 4K/AR9285). Без этой таблицы аналоговый тракт
 * передатчика (PA) работает на сбросовых умолчаниях: per-rate регистры
 * 0x9934+ задают ЦЕЛЕВУЮ мощность, а PDADC-таблица (0xA280, 128 байт) —
 * реальное соответствие «индекс мощности -> код ЦАП». Запуск — в
 * bring-up непосредственно ПЕРЕД записью per-rate регистров (порядок
 * как в ath9k_hw_4k_set_txpower: cal_table -> rate regs).
 * ===================================================================== */
static void ath9k_fill_vpd_table(u8 pwrMin, u8 pwrMax, const u8 *pPwrList,
                                 const u8 *pVpdList, u16 numIntercepts,
                                 u8 *pRetVpdList) {
    u16 idxL = 0, idxR = 0;
    u8 currPwr = pwrMin;
    /* [W-PDADC-FIX] страховка от мусорных pwr-пиров: число точек <= 64
     * (размер строки vpdTableX); у валидных карт (max-min)/2+1 <= 33 */
    u32 vpd_cnt = ((u32)(pwrMax - pwrMin) / 2u) + 1u;
    if (vpd_cnt > AR5416_MAX_PWR_RANGE_IN_HALF_DB)
        vpd_cnt = AR5416_MAX_PWR_RANGE_IN_HALF_DB;
    for (u16 i = 0; i < vpd_cnt; i++) {
        u16 k;
        /* get_lower_upper_index (инлайн) */
        if (currPwr <= pPwrList[0]) idxL = idxR = 0;
        else if (currPwr >= pPwrList[numIntercepts - 1])
            idxL = idxR = (u16)(numIntercepts - 1);
        else {
            idxL = idxR = 0;
            for (u16 j = 0; j < numIntercepts - 1; j++) {
                if (pPwrList[j] == currPwr) { idxL = idxR = j; break; }
                if (currPwr < pPwrList[j + 1]) { idxL = j; idxR = (u16)(j + 1); break; }
            }
        }
        if (idxR < 1) idxR = 1;
        if (idxL == numIntercepts - 1) idxL = (u16)(numIntercepts - 2);
        if (pPwrList[idxL] == pPwrList[idxR])
            k = pVpdList[idxL];
        else
            k = (u16)(((currPwr - pPwrList[idxL]) * pVpdList[idxR] +
                       (pPwrList[idxR] - currPwr) * pVpdList[idxL]) /
                      (pPwrList[idxR] - pPwrList[idxL]));
        pRetVpdList[i] = (u8)k;
        currPwr += 2;
    }
}

static int ath9k_interpolate16(u16 target, u16 srcLeft, u16 srcRight,
                               int targetLeft, int targetRight) {
    if (srcRight == srcLeft) return targetLeft;
    return (int)(((target - srcLeft) * targetRight +
                  (srcRight - target) * targetLeft) / (srcRight - srcLeft));
}

static u8 vpdTableL[AR5416_PD_GAINS_IN_MASK][AR5416_MAX_PWR_RANGE_IN_HALF_DB];
static u8 vpdTableR[AR5416_PD_GAINS_IN_MASK][AR5416_MAX_PWR_RANGE_IN_HALF_DB];
static u8 vpdTableI[AR5416_PD_GAINS_IN_MASK][AR5416_MAX_PWR_RANGE_IN_HALF_DB];

static void ath9k_get_gain_boundaries_pdadcs(u8 bChanSynth,
                                             const eep4k_calper_t *pRaw,
                                             const u8 *bChans, u16 availPiers,
                                             u16 tPdGainOverlap,
                                             u16 *pPdGainBoundaries,
                                             u8 *pPDADCValues,
                                             u16 numXpdGains) {
    u16 numPiers = 0, idxL = 0, idxR = 0;
    u8 minPwrT4[AR5416_PD_GAINS_IN_MASK];
    u8 maxPwrT4[AR5416_PD_GAINS_IN_MASK];
    u16 k = 0;
    int ss;
    int vpdStep, tmpVal;
    u16 sizeCurrVpdTable, maxIndex, tgtIndex;
    int minDelta = 0;
    int match = 0;

    for (numPiers = 0; numPiers < availPiers; numPiers++)
        if (bChans[numPiers] == AR5416_BCHAN_UNUSED) break;

    /* get_lower_upper_index по bChannel пиров */
    if (bChanSynth <= bChans[0]) { idxL = idxR = 0; match = 1; }
    else if (bChanSynth >= bChans[numPiers - 1]) {
        idxL = idxR = (u16)(numPiers - 1); match = 1;
    } else {
        for (u16 j = 0; j < numPiers - 1; j++) {
            if (bChans[j] == bChanSynth) { idxL = idxR = j; match = 1; break; }
            if (bChanSynth < bChans[j + 1]) { idxL = j; idxR = (u16)(j + 1); break; }
        }
    }

    if (match) {
        for (u16 i = 0; i < numXpdGains; i++) {
            minPwrT4[i] = pRaw[idxL].pwrPdg[i][0];
            maxPwrT4[i] = pRaw[idxL].pwrPdg[i][AR5416_PD_GAIN_ICEPTS - 1];
            ath9k_fill_vpd_table(minPwrT4[i], maxPwrT4[i],
                                 pRaw[idxL].pwrPdg[i], pRaw[idxL].vpdPdg[i],
                                 AR5416_PD_GAIN_ICEPTS, vpdTableI[i]);
        }
    } else {
        for (u16 i = 0; i < numXpdGains; i++) {
            const u8 *pPwrL = pRaw[idxL].pwrPdg[i];
            const u8 *pVpdL = pRaw[idxL].vpdPdg[i];
            const u8 *pPwrR = pRaw[idxR].pwrPdg[i];
            const u8 *pVpdR = pRaw[idxR].vpdPdg[i];

            minPwrT4[i] = (pPwrL[0] > pPwrR[0]) ? pPwrL[0] : pPwrR[0];
            maxPwrT4[i] = (pPwrL[AR5416_PD_GAIN_ICEPTS - 1] <
                           pPwrR[AR5416_PD_GAIN_ICEPTS - 1]) ?
                          pPwrL[AR5416_PD_GAIN_ICEPTS - 1] :
                          pPwrR[AR5416_PD_GAIN_ICEPTS - 1];

            ath9k_fill_vpd_table(minPwrT4[i], maxPwrT4[i], pPwrL, pVpdL,
                                 AR5416_PD_GAIN_ICEPTS, vpdTableL[i]);
            ath9k_fill_vpd_table(minPwrT4[i], maxPwrT4[i], pPwrR, pVpdR,
                                 AR5416_PD_GAIN_ICEPTS, vpdTableR[i]);

            for (u16 j = 0; j <= (maxPwrT4[i] - minPwrT4[i]) / 2; j++)
                vpdTableI[i][j] = (u8)ath9k_interpolate16(
                    bChanSynth, bChans[idxL], bChans[idxR],
                    vpdTableL[i][j], vpdTableR[i][j]);
        }
    }

    for (u16 i = 0; i < numXpdGains; i++) {
        pPdGainBoundaries[i] = (i == (numXpdGains - 1))
            ? (u16)(maxPwrT4[i] / 2)
            : (u16)((maxPwrT4[i] + minPwrT4[i + 1]) / 4);
        if (pPdGainBoundaries[i] > EEP4K_MAX_RATE_POWER)
            pPdGainBoundaries[i] = EEP4K_MAX_RATE_POWER;

        minDelta = 0;
        if (i == 0)
            ss = (int)(0 - (minPwrT4[i] / 2));   /* AR9285: 9280_20_OR_LATER */
        else
            ss = (int)((pPdGainBoundaries[i - 1] - (minPwrT4[i] / 2)) -
                       tPdGainOverlap + 1 + minDelta);

        vpdStep = (int)vpdTableI[i][1] - (int)vpdTableI[i][0];
        if (vpdStep < 1) vpdStep = 1;

        while ((ss < 0) && (k < (AR5416_NUM_PDADC_VALUES - 1))) {
            tmpVal = (int)vpdTableI[i][0] + ss * vpdStep;
            pPDADCValues[k++] = (u8)((tmpVal < 0) ? 0 : tmpVal);
            ss++;
        }

        sizeCurrVpdTable = (u16)((maxPwrT4[i] - minPwrT4[i]) / 2 + 1);
        tgtIndex = (u16)(pPdGainBoundaries[i] + tPdGainOverlap -
                         (minPwrT4[i] / 2));
        maxIndex = (tgtIndex < sizeCurrVpdTable) ? tgtIndex : sizeCurrVpdTable;

        while ((ss < (int)maxIndex) && (k < (AR5416_NUM_PDADC_VALUES - 1)))
            pPDADCValues[k++] = vpdTableI[i][ss++];

        /* [W-PDADC-FIX] у валидных карт sizeCurrVpdTable >= 2; при
         * вырожденном pier (size 1) индекс [-1] недопустим — шаг = 1 */
        if (sizeCurrVpdTable >= 2) {
            vpdStep = (int)vpdTableI[i][sizeCurrVpdTable - 1] -
                      (int)vpdTableI[i][sizeCurrVpdTable - 2];
        } else {
            vpdStep = 1;
        }
        if (vpdStep < 1) vpdStep = 1;

        if (tgtIndex >= maxIndex) {
            while ((ss <= (int)tgtIndex) &&
                   (k < (AR5416_NUM_PDADC_VALUES - 1))) {
                tmpVal = (int)vpdTableI[i][sizeCurrVpdTable - 1] +
                         (ss - maxIndex + 1) * vpdStep;
                pPDADCValues[k++] = (u8)((tmpVal > 255) ? 255 : tmpVal);
                ss++;
            }
        }
    }
    /* [W-PDADC-FIX] недостающие границы = КОПИЯ ПОСЛЕДНЕЙ (эталон
     * eeprom.c: pdGainBoundaries[i] = pdGainBoundaries[i-1]), а не 58 */
    while (numXpdGains < AR5416_PD_GAINS_IN_MASK) {
        pPdGainBoundaries[numXpdGains] =
            pPdGainBoundaries[numXpdGains - 1];
        numXpdGains++;
    }
    /* [W-PDADC-FIX] КРИТИЧНО: в порте был потерян k++ (у Linux:
     * pdadcValues[k] = pdadcValues[k-1], k++). Циклы выше ограничены
     * k<127, поэтому хвост выполняется ВСЕГДА — без инкремента он
     * крутился вечно: wifi-задача замирала сразу после «калибровка ok»
     * (полевой лог v4: строки «PDADC: таблица записана»/«TX-мощность»
     * не появились, система жива — преempt на 4 ядрах). */
    while (k < AR5416_NUM_PDADC_VALUES) {
        pPDADCValues[k] = pPDADCValues[k - 1];
        k++;
    }
}

static void ath_4k_power_cal_table(void) {
    const eep4k_calper_t *pRawDataset;
    u16 pdGainOverlap_t2;
    static u8 pdadcValues[AR5416_NUM_PDADC_VALUES];
    u16 gainBoundaries[AR5416_PD_GAINS_IN_MASK];
    u16 numXpdGain = 0, xpdGainValues[AR5416_EEP4K_NUM_PD_GAINS] = {0, 0};
    u16 xpdMask = g_eep4k.modalHeader.xpdGain;
    int minor = (int)(g_eep4k.baseEepHeader.version & 0xFFFu);

    if (minor >= AR5416_EEP_MINOR_VER_2)
        pdGainOverlap_t2 = g_eep4k.modalHeader.pdGainOverlap;
    else
        pdGainOverlap_t2 = (reg32(AR_PHY_TPCRG5) &
                            AR_PHY_TPCRG5_PD_GAIN_OVERLAP) >>
                           AR_PHY_TPCRG5_PD_GAIN_OVERLAP_S;

    /* выбор рабочих pd-gain по маске xpdGain [eeprom_4k.c 310-320] */
    for (u16 i = 1; i <= AR5416_PD_GAINS_IN_MASK; i++) {
        if ((xpdMask >> (AR5416_PD_GAINS_IN_MASK - i)) & 1) {
            if (numXpdGain >= AR5416_EEP4K_NUM_PD_GAINS) break;
            xpdGainValues[numXpdGain] =
                (u16)(AR5416_PD_GAINS_IN_MASK - i);
            numXpdGain++;
        }
    }
    if (numXpdGain == 0) {
        wifi_log("PDADC: xpdGain маска %04x пуста — таблица не пишем",
                 (unsigned)xpdMask);
        return;
    }

    phy_rmw_field(AR_PHY_TPCRG1, AR_PHY_TPCRG1_NUM_PD_GAIN,
                  AR_PHY_TPCRG1_NUM_PD_GAIN_S, (numXpdGain - 1) & 0x3);
    phy_rmw_field(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_GAIN_1,
                  AR_PHY_TPCRG1_PD_GAIN_1_S, xpdGainValues[0]);
    phy_rmw_field(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_GAIN_2,
                  AR_PHY_TPCRG1_PD_GAIN_2_S, xpdGainValues[1]);
    phy_rmw_field(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_GAIN_3,
                  AR_PHY_TPCRG1_PD_GAIN_3_S, 0);

    /* одна цепочка (4K): txMask & 1 */
    if (g_eep4k.baseEepHeader.txMask & 1) {
        pRawDataset = &g_eep4k.calPierData2G[0][0];
        ath9k_get_gain_boundaries_pdadcs(
            (u8)(channel_freq[ath.chan] - 2300),     /* FREQ2FBIN, 2ГГц */
            pRawDataset, g_eep4k.calFreqPier2G,
            AR5416_EEP4K_NUM_2G_CAL_PIERS, pdGainOverlap_t2,
            gainBoundaries, pdadcValues, numXpdGain);

        regw(AR_PHY_TPCRG5,
             ((u32)pdGainOverlap_t2 << AR_PHY_TPCRG5_PD_GAIN_OVERLAP_S) |
             ((u32)gainBoundaries[0] << AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_1_S) |
             ((u32)gainBoundaries[1] << AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_2_S) |
             ((u32)gainBoundaries[2] << AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_3_S) |
             ((u32)gainBoundaries[3] << AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_4_S));

        for (u16 j = 0; j < 32; j++) {
            u32 reg32v = (u32)pdadcValues[4 * j] |
                         ((u32)pdadcValues[4 * j + 1] << 8) |
                         ((u32)pdadcValues[4 * j + 2] << 16) |
                         ((u32)pdadcValues[4 * j + 3] << 24);
            regw(AR_PHY_PDADC_TABLE + 4u * j, reg32v);
        }
        {
            char tmp[160];
            snprintf(tmp, sizeof(tmp),
                     "PDADC: таблица записана @%x (pdGains=%u overlap=%u "
                     "границы %u/%u/%u/%u, pdadc[0..3]=%u %u %u %u)",
                     (unsigned)AR_PHY_PDADC_TABLE,
                     (unsigned)numXpdGain, (unsigned)pdGainOverlap_t2,
                     (unsigned)gainBoundaries[0], (unsigned)gainBoundaries[1],
                     (unsigned)gainBoundaries[2], (unsigned)gainBoundaries[3],
                     (unsigned)pdadcValues[0], (unsigned)pdadcValues[1],
                     (unsigned)pdadcValues[2], (unsigned)pdadcValues[3]);
            if (wifi_log_changed(s_memo_pd, (int)sizeof(s_memo_pd), tmp))
                wifi_log("%s", tmp);
        }
    } else {
        wifi_log("PDADC: txMask=%02x без цепочки 0 — таблица не пишем",
                 (unsigned)g_eep4k.baseEepHeader.txMask);
    }
}

static void read_mac_from_eeprom(void) {
    u16 w[3] = {0, 0, 0};
    u16 base_raw[3] = {0, 0, 0};
    int ok = 0;
    int base_used = 0;

    if (ath.is_sowl) {
        for (int i = 0; i < 3; i++)
            if (!eeprom_read_word(1 + i, &w[i])) { ok = 0; break; } else ok = 1;
        if (ok) {
            /* AR9300: macAddr[0] — старший байт слова (как прежде) */
            ath.mac[0] = (u8)(w[0] >> 8); ath.mac[1] = (u8)(w[0] & 0xFF);
            ath.mac[2] = (u8)(w[1] >> 8); ath.mac[3] = (u8)(w[1] & 0xFF);
            ath.mac[4] = (u8)(w[2] >> 8); ath.mac[5] = (u8)(w[2] & 0xFF);
            base_used = 1;
        }
    } else {
        /* [W-EEP4K-v3] ПЕРВИЧНО: карта по MAGIC+checksum (скан 0..127 +
         * дамп сырых слов — см. eeprom_map_probe). Если карта валидна —
         * MAC и txGainType читаются ИЗ СТРУКТУРЫ g_eep4k (все офсеты
         * гарантированы _Static_assert'ами). Fallback — прежний
         * перебор по валидности MAC. */
        int base = 0, swap = 0;
        u16 hdr3[3] = {0, 0, 0};
        if (eeprom_map_probe(&base, &swap, hdr3)) {
            int good = 1;
            const u8 *mac = g_eep4k.baseEepHeader.macAddr;
            ath.mac[0] = mac[0]; ath.mac[1] = mac[1]; ath.mac[2] = mac[2];
            ath.mac[3] = mac[3]; ath.mac[4] = mac[4]; ath.mac[5] = mac[5];
            /* сырые слова MAC для сверки с наклейкой — из карты */
            {
                const u16 *mw = (const u16 *)&g_eep4k;
                w[0] = mw[6]; w[1] = mw[7]; w[2] = mw[8];
            }
            if ((ath.mac[0] & 1) ||
                (ath.mac[0] | ath.mac[1] | ath.mac[2] |
                 ath.mac[3] | ath.mac[4] | ath.mac[5]) == 0)
                good = 0;              /* групповой/нулевой — мусор */
            if (good) {
                const u8  *m  = (const u8 *)&g_eep4k;
                const u16 *mw = (const u16 *)&g_eep4k;
                char cd[21];
                int k;
                ok = 1; base_used = 2;     /* 2 = найденная карта */
                wifi_log("EEPROM: magic ok, карта @ слово %d "
                         "(len=%04x chk=%04x ver=%04x)",
                         base, (unsigned)hdr3[0], (unsigned)hdr3[1],
                         (unsigned)hdr3[2]);
                /* [W-EEP4K-v4] диагностика карты: custData (ASCII),
                 * opCapFlags/maxPower и начало modal-заголовка
                 * (antCtrlChain lo/hi, antCtrlCommon lo/hi) */
                for (k = 0; k < 20; k++) {
                    u8 ch = m[32 + k];
                    cd[k] = (ch >= 0x20 && ch < 0x7f) ? (char)ch : '.';
                }
                cd[20] = 0;
                wifi_log("EEPROM custData=\"%s\" opCap=%02x maxPwr=%u",
                         cd, (unsigned)m[6], (unsigned)m[24]);
                wifi_log("EEPROM modal[0..3]=%04x %04x %04x %04x",
                         (unsigned)mw[26], (unsigned)mw[27],
                         (unsigned)mw[28], (unsigned)mw[29]);
            }
            /* txGainType: байт 31 base-заголовка: 0 = low power,
             * 1 = high power [eeprom_4k.c EEP_TXGAIN_TYPE] */
            if (good) {
                g_txgain_type = g_eep4k.baseEepHeader.txGainType;
                wifi_log("EEPROM txGainType=%u%s",
                         (unsigned)g_txgain_type,
                         (g_txgain_type <= 1u) ? "" :
                             " — НЕОЖИДАННО (допустимы 0/1)");
            }
        }
        if (!ok) {
            /* fallback: прежний перебор по валидности MAC (magic нет) */
            static const int bases[2] = { 6, 70 };
            for (int b = 0; b < 2 && !ok; b++) {
                int good = 1;
                for (int i = 0; i < 3; i++)
                    if (!eeprom_read_word(bases[b] + i, &w[i])) { good = 0; break; }
                for (int i = 0; i < 3; i++) base_raw[i] = w[i];
                if (!good) continue;
                ath.mac[0] = (u8)(w[0] & 0xFF); ath.mac[1] = (u8)(w[0] >> 8);
                ath.mac[2] = (u8)(w[1] & 0xFF); ath.mac[3] = (u8)(w[1] >> 8);
                ath.mac[4] = (u8)(w[2] & 0xFF); ath.mac[5] = (u8)(w[2] >> 8);
                if ((ath.mac[0] & 1) ||
                    (ath.mac[0] | ath.mac[1] | ath.mac[2] |
                     ath.mac[3] | ath.mac[4] | ath.mac[5]) == 0)
                    continue;
                ok = 1; base_used = b;
                wifi_log("EEPROM: карта не валидирована — MAC по валидности (fallback)");
            }
            if (!ok)
                for (int i = 0; i < 3; i++) w[i] = base_raw[i];
        }
    }
    if (ok) {
        if ((ath.mac[0] & 1) || (ath.mac[0] | ath.mac[1] | ath.mac[2] |
                                  ath.mac[3] | ath.mac[4] | ath.mac[5]) == 0)
            ok = 0;    /* групповой/нулевой адрес — мусор (sowl-путь) */
    }
    if (!ok) {
        /* запасной адрес: локально-администрируемый, детерминированный */
        ath.mac[0] = 0x02;
        ath.mac[1] = 0x1A;
        ath.mac[2] = 0x2B;
        ath.mac[3] = (u8)(ath.srev_raw >> 16);
        ath.mac[4] = (u8)(ath.srev_raw >> 8);
        ath.mac[5] = (u8)(ath.pci_devid);
        wifi_log("EEPROM MAC не читается — локальный адрес 02:1a:2b:..");
    }
    wifi_log("MAC %02x:%02x:%02x:%02x:%02x:%02x (EEPROM%s, слова %s)",
             ath.mac[0], ath.mac[1], ath.mac[2],
             ath.mac[3], ath.mac[4], ath.mac[5],
             ok ? "" : ", fallback",
             ath.is_sowl ? "1-3" :
                 (ok ? (base_used == 2 ? "карты+6..8" :
                        (base_used ? "70-72" : "6-8")) : "n/a"));
    if (!ath.is_sowl)
        wifi_log("EEPROM сырые слова (MAC): %04x %04x %04x — сверить с наклейкой",
                 (unsigned)w[0], (unsigned)w[1], (unsigned)w[2]);
}

/* [W-IFSTIME] Глобальные тайминги MAC — порт ath9k_hw_init_global_settings
 * (ветка 2.4 ГГц без half/quarter; в эталоне вызывается в КОНЦЕ reset).
 * INI (см. ath9k_ar9285_ini.h) пишет 0x8014 = 0 и не трогает SIFS/SLOT —
 * поле ACK-таймаута оставалось нулевым: DCU не ждал ACK вовсе.
 * Единицы — такты MAC: тактовая 2.4 ГГц HT20 = 44 МГц (пишем USEC=43 —
 * как эталон: common->clockrate-1), латентности rx/tx — эталонные 37/54.
 * Таймауты: ACK = slot+SIFS с эталонной поправкой 2.4 ГГц
 * (+64-SIFS-slot) = 64 мкс; CTS = 48 мкс. */
static void ath_global_ifs_setup(void) {
    const u32 sifs_us = 10, slot_us = 20;
    u32 old_to = reg32(AR_TIME_OUT);
    u32 usec = reg32(AR_USEC);
    u32 rx_lat = (usec & AR_USEC_RX_LAT) >> AR_USEC_RX_LAT_S;
    u32 tx_lat = (usec & AR_USEC_TX_LAT) >> AR_USEC_TX_LAT_S;
    if (rx_lat == 0) rx_lat = 37;   /* эталон 2.4 ГГц HT20 (0x12e0002b): rx_lat */
    if (tx_lat == 0) tx_lat = 127;  /* [W-USEC127] было 54 (взято из 5ГГц-столбцов), эталон 2.4 ГГц HT20 = 127 */
    regw(AR_USEC, 43u |
                  (rx_lat << AR_USEC_RX_LAT_S) |
                  (tx_lat << AR_USEC_TX_LAT_S));
    u32 rate = (reg32(AR_USEC) & AR_USEC_USEC_M) + 1u;   /* тактов за мкс */
    regw(AR_D_GBL_IFS_SIFS, sifs_us * rate);
    regw(AR_D_GBL_IFS_SLOT, slot_us * rate);
    u32 ack_us = slot_us + sifs_us + (64 - sifs_us - slot_us);   /* = 64 */
    u32 cts_us = slot_us + sifs_us + (48 - sifs_us - slot_us);   /* = 48 */
    regw(AR_TIME_OUT,
         (((u32)(ack_us * rate) << AR_TIME_OUT_ACK_S) & AR_TIME_OUT_ACK_M) |
         (((u32)(cts_us * rate) << AR_TIME_OUT_CTS_S) & AR_TIME_OUT_CTS_M));
    {
        char tmp[160];
        snprintf(tmp, sizeof(tmp),
                 "Тайминги MAC: SIFS=%u такт (%u мкс), SLOT=%u такт (%u мкс), "
                 "ACK=%u мкс, CTS=%u мкс (AR_TIME_OUT: было %08x, стало %08x)",
                 sifs_us * rate, sifs_us, slot_us * rate, slot_us,
                 ack_us, cts_us, old_to, reg32(AR_TIME_OUT));
        if (wifi_log_changed(s_memo_tm, (int)sizeof(s_memo_tm), tmp))
            wifi_log("%s", tmp);
    }
}

/* ---- настройка TX-очереди QCU/DCU 0 [mac.c: ath9k_hw_resettxqueue] ---- */
static void ath_tx_queue_setup(void) {
    int q = WIFI_TX_QUEUE;
    regw(AR_DQCUMASK(q), 1u << q);                    /* QCU q -> DCU q */
    regw(AR_DLCL_IFS(q),
         ((u32)AT_INIT_AIFS  << AR_D_LCL_IFS_AIFS_S) |
         ((u32)AT_INIT_CWMIN << AR_D_LCL_IFS_CWMIN_S) |
         ((u32)AT_INIT_CWMAX << AR_D_LCL_IFS_CWMAX_S));
    regw(AR_DRETRY_LIMIT(q),
         ((u32)AT_INIT_SSH_RETRY << AR_D_RETRY_LIMIT_STA_SH_S) |
         ((u32)AT_INIT_SLG_RETRY << AR_D_RETRY_LIMIT_STA_LG_S) |
         (10u << AR_D_RETRY_LIMIT_FR_SH_S));          /* INIT_SH_RETRY */
    regw(AR_QMISC(q), AR_Q_MISC_DCU_EARLY_TERM_REQ);
    regw(AR_DMISC(q), AR_D_MISC_CW_BKOFF_EN |
                      AR_D_MISC_FRAG_WAIT_EN |
                      (2u & AR_D_MISC_BKOFF_THRESH));
    regw(AR_Q_TXE, 0);                                /* очереди стоят */
    regw(AR_QTXDP(q), 0);

    if (!ath.is_sowl) {
        if (!ath.txdesc) {
            ath.txdesc_raw = malloc(sizeof(owl_txdesc_t) + 31);
            if (ath.txdesc_raw) {
                ath.txdesc = (owl_txdesc_t *)
                    (((u32)(unsigned long)ath.txdesc_raw + 15) & ~15u);
                memset(ath.txdesc, 0, sizeof(owl_txdesc_t));
            }
            ath.txbuf = (u8 *)malloc(WIFI_TXBUF_SZ);
        }
        return;
    }

    /* ---- СЕССИЯ 15: TX для AR9003/AR9485 — дескриптор ar9003 +
     * статусное кольцо. Порядок как в эталоне: память кольца чистится,
     * затем программируются AR_Q_STATUS_RING_START/END (до включения
     * очередей — ath9k_hw_reset_txstatus_ring). */
    if (!ath.stxdesc) {
        ath.stxdesc_raw = malloc(sizeof(sowl_txdesc_t) + 127);
        if (ath.stxdesc_raw) {
            ath.stxdesc = (sowl_txdesc_t *)
                (((u32)(unsigned long)ath.stxdesc_raw + 127) & ~127u);
            memset(ath.stxdesc, 0, sizeof(sowl_txdesc_t));
        }
        ath.stxbuf = (u8 *)malloc(WIFI_TXBUF_SZ);
    }
    if (!ath.tsring) {
        ath.tsring_raw = malloc(sizeof(sowl_txs_t) * WIFI_TS_RING + 31);
        if (ath.tsring_raw) {
            ath.tsring = (sowl_txs_t *)
                (((u32)(unsigned long)ath.tsring_raw + 31) & ~31u);
            for (int i = 0; i < WIFI_TS_RING; i++)
                memset(&ath.tsring[i], 0, sizeof(sowl_txs_t));
        }
    }
    if (!ath.stxdesc || !ath.stxbuf || !ath.tsring) {
        wifi_log("TX(sowl): нет памяти под дескриптор/статус-кольцо");
        return;
    }
    ath.ts_tail = 0;
    regw(AR_Q_STATUS_RING_START, (u32)(unsigned long)ath.tsring);
    regw(AR_Q_STATUS_RING_END,
         (u32)(unsigned long)ath.tsring +
         (u32)sizeof(sowl_txs_t) * WIFI_TS_RING);
}

/* Записать наш MAC в STA_ID0/1 (нужно для аппаратных ACK и RX-фильтра) */
static void ath_set_sta_id(void) {
    regw(AR_STA_ID0, (u32)ath.mac[0] | ((u32)ath.mac[1] << 8) |
                     ((u32)ath.mac[2] << 16) | ((u32)ath.mac[3] << 24));
    u32 v = reg32(AR_STA_ID1) & 0xFFFF0000u;   /* конфиг-биты не трогаем */
    v |= (u32)ath.mac[4] | ((u32)ath.mac[5] << 8);
    /* [W-STAID1] все три эталонных бита ath9k_hw_reset_opmode (hw.c):
     * RTS_USE_DEF — автономные RTS/CTS/ACK ПКУ излучаются через дефолтную
     *   антенну (без него ПКУ не знает, через какую цепь излучать CTS —
     *   корень-кандидат «наш CTS/ACK не уходит»);
     * CRPT_MIC — HW-Michael-проверка (эталонные sta_id1_defaults);
     * MCAST_KSRCH — кейсерч групповых ключей по BSSID (RX TKIP/CCMP mcast).
     * Michael дублируется софтом ([W-TKIPSW]) — двойная проверка безвредна. */
    v |= AR_STA_ID1_RTS_USE_DEF | AR_STA_ID1_CRPT_MIC | AR_STA_ID1_MCAST_KSRCH;
    regw(AR_STA_ID1, v);
    /* [W-STAID1] очистка запретов ACK/CTS (AR_DIAG_SW): ACK_DIS=0x2
     * полностью запрещает аппаратный ACK, CTS_DIS=0x4 — CTS; после сброса
     * могут остаться от отладочных путей — снимаем и логируем */
    {
        u32 diag = reg32(AR_DIAG_SW);
        if (diag & (AR_DIAG_ACK_DIS | AR_DIAG_CTS_DIS)) {
            regw(AR_DIAG_SW, diag & ~(AR_DIAG_ACK_DIS | AR_DIAG_CTS_DIS));
            wifi_log("DIAG: сняты ACK_DIS/CTS_DIS (было %08x)", (unsigned)diag);
        }
    }
}

/* [W-MACROT] смена нашего MAC на лету (повтор подключения с чистой
 * записью в точке): STA_ID0/1 + копия в ath.mac (ACK-корреляция и
 * RX-фильтр железа сверяются с этими регистрами). */
static void ath_set_mac(const u8 *mac) {
    memcpy(ath.mac, mac, 6);
    ath_set_sta_id();
}

/* [W-BSSID] BSSID+AID в железо (ath5k/pcu.c: ath5k_hw_set_associd;
 * ath9k/hw.c: ath9k_hw_set_bssid — пишутся ВМЕСТЕ со STA_ID0/1 при
 * КАЖДОМ reset/bss-change, потому эталонным стекам этот шаг незаметен):
 *   AR_BSS_ID0 = LE32(bssid[0..3]), AR_BSS_ID1 = LE16(bssid[4..5]) |
 *   (aid & 0x3FFF) << 16, маска AR_BSSMSKL/U = ff:ff:ff:ff:ff:ff.
 * У нас это НИКОГДА не писалось: ini клал нули, ath_mac_dma_config —
 * FF:FF:FF:FF:FF:FF «на скан», hook set_bssid (объявлен в итерации 14,
 * реализован в rtl8192eu) в ops ath9k отсутствовал и не вызывался —
 * 9 итераций мёртвый интерфейс. Следствия в поле:
 *  — PCU не с чем сверять BSSID-матч: юникаст-ответы точки (AUTH-RSP/
 *    ASSOC-RSP/EAPOL M1) НЕ ACK-ятся — сниффер показывает ASSOC-RSP
 *    только с retry=1 (серия неподтверждённых ответов), строгий AP
 *    после неё откатывает станцию и молчит (0 из 6 → DEAUTH), мягкий
 *    ESP32 держит запись — потому ассоциация «пробивалась»;
 *  — keycache-поиск ключа RX (KSRCH_MODE) матчит ячейки по BSSID —
 *    RX-декрипт данных без верного BSS_ID не заработает никогда.
 * aid = 0 — до ассоциации; полный BSSID+aid — после ASSOC-RSP. */
static void ath_set_bssid(const u8 *bssid, u16 aid) {
    regw(AR_BSSMSKL, 0xFFFFFFFFu);
    regw(AR_BSSMSKU, 0x0000FFFFu);
    regw(AR_BSS_ID0, (u32)bssid[0] | ((u32)bssid[1] << 8) |
                     ((u32)bssid[2] << 16) | ((u32)bssid[3] << 24));
    regw(AR_BSS_ID1, (u32)bssid[4] | ((u32)bssid[5] << 8) |
                     ((u32)(aid & 0x3FFFu) << 16));
    /* [W-PCUDUMP]: дамп при реальном BSSID (скан-сброс FF:FF.. не шумит) */
    if ((bssid[0] | bssid[1] | bssid[2] | bssid[3] | bssid[4] | bssid[5]) != 0)
        ath_pcu_dump();
}

/* [W-TXDIAG] (запрос: «при необходимости добавь логирование»):
 * различаем ДВЕ причины отказа TX (полевой лог AR9285: «AUTH не
 * отправлен (TX отказ)» — без деталей):
 *   txdone=0 — TxDone НЕ пришёл за 150 мс: кадр не покинул DCU.
 *     Дескриптор/очередь стоят (DCU ждал продолжение TxMore, QTXDP
 *     не взята, кли-счётчик заморожен) — железо молчит, это НЕ эфир.
 *     Показываем состояние очереди: QTXDP (взяла ли DCU дескриптор)
 *     и TXE (бит включения).
 *   txdone=1 — статус получен, но FrmXmitOK=0: кадр УШЁЛ в эфир,
 *     ACK от точки нет. Причины: не тот канал (точка на другом),
 *     мощность/помехи, точка отфильтровала кадр (Filtered = её
 *     BSSID-фильтр), ретраи исчерпаны (ExcessiveRetries).
 * st_a/st_b — статусные слова ДО очистки (owl: st[1]/st[9]; sowl:
 * status3/status8). Рейт-лимит: первые 3 отказа всегда, дальше раз
 * в 5 с — шторм ретраев подключения (AUTH ~1/с) не заливает serial
 * и 28-строчный журнал приложения. */
static void ath_tx_fail_diag(int txdone, int hw_rate, int tries,
                             u32 st_a, u32 st_b)
{
    static u32 s_last = 0;
    static int s_logged = 0;
    u32 now = timer_ticks();
    if (s_logged >= 3 && (u32)(now - s_last) < 5000u) return;
    s_last = now;
    s_logged++;

    if (!txdone) {
        wifi_log("TX отказ: TxDone не пришёл — очередь стоит: "
                 "QTXDP=%x TXE=%x rate=%x tries=%d",
                 (unsigned)reg32(AR_QTXDP(WIFI_TX_QUEUE)),
                 (unsigned)reg32(AR_Q_TXE),
                 (unsigned)hw_rate, tries);
    } else {
        const char *why = "нет ACK (эфир/канал/точка)";
        if (st_a & TXS_ExcessiveRetries)
            why = "ретраи исчерпаны — точка не отвечает";
        if (st_a & TXS_Filtered)
            why = "отфильтровано точкой (не её BSSID/канал?)";
        wifi_log("TX отказ: кадр ушёл, %s: st=%x/%x rate=%x tries=%d",
                 why, (unsigned)st_a, (unsigned)st_b,
                 (unsigned)hw_rate, tries);
    }
}

/* [W-CCMPTX] хвост шифра, который ДОПИСЫВАЕТ железо ПОВЕРХ буфера:
 * CCMP — MIC 8; TKIP — Michael-MIC 8 + ICV 4. Эталон ath_tx_prepare
 * (xmit.c:2296): frmlen = skb->len + FCS_LEN + hw_key->icv_len. Буфер
 * содержит hdr+IV+данные (IV строим в софте — СЕССИЯ 52), MIC/ICV
 * дописывает криптодвижок PCU — без них в FrameLen кадр уходит
 * ОБРЕЗАННЫМ (хвост отброшен). Для TKIP с SW-MIC (8192EU) хвост считает
 * rtl-путь сам — сюда он не попадает (keyidx Atheros). */
static u32 ath_cipher_tail(int keyidx) {
    if (keyidx < 0) return 0;
    if (keyidx != KC_PTK_ENTRY && ath_gtk_is_tkip) return 12;  /* TKIP */
    return 8;                                                  /* CCMP */
}

/* ---- передача одного кадра 802.11 (семейство Owl) ----
 * rates[4]/tries[4] — серия рейтов с падением; rate[i]==0 — серия не задана.
 * noack = 1 для broadcast/multicast (ACK не ждём).
 * keyidx = -1 — без шифрования; 0..127 — запись keycache (WPA2, сессия 12):
 * железо само строит CCMP-заголовок с PN и шифрует кадр.
 * Возвращает 1 при подтверждении (ACK получен / кадр ушёл). */
static int owl_tx_frame(const u8 *frame, u32 len, u8 hw_rate,
                        int tries, int noack, int keyidx)
{
    if (!ath.txdesc || !ath.txbuf) return 0;
    if (len > WIFI_TXBUF_SZ) return 0;

    s_lock(&ath.tx_lock);
    memcpy(ath.txbuf, frame, len);

    owl_txdesc_t *d = ath.txdesc;
    memset(d, 0, sizeof(*d));
    d->link = 0;                                   /* конец списка */
    d->data = (u32)(unsigned long)ath.txbuf;
    /* [W-TXDESC] (полевой лог AR9285: AUTH уходил без шифрования —
     * DestIdxValid не был задет; ПЕРВЫЙ же зашифрованный кадр (EAPOL M2,
     * keyidx=KC_PTK_ENTRY) уходил бы с битом 30 ctl1 = AR_IsAggr — точка
     * отбросила бы его как «агрегат» и WPA2 не взлетел бы никогда).
     * Эталон (Linux mac.h + ar9002_mac.c: ar9002_set_txdesc):
     *   ds_ctl0: FrameLen | XmitPower0 | DestIdxValid(0x40000000) | ...
     *   ds_ctl1: BufLen | DestIdx(17:13) | FrameType | NoAck | IsAggr(0x40000000)
     * DestIdxValid — БИТ 30 CTL0, а не ctl1.
     * [W-TXPOW]: XmitPower0 40 = 15 дБм в шкале эталона (2*дБм + 10,
     * ratesArray -= PWR_TABLE_OFFSET*2 при offset -5 дБ; прежде 30 —
     * это ~10 дБм). */
    /* [W-CCMPTX] (сниффер ESP32, WPA2-сессия: DHCP DISCOVER ушёл с битом
     * Protected и CCMP-заголовком (PN=1,2), но ТЕЛО — открытым текстом:
     * точка молча роняет «защищённый» кадр, DHCP не отвечает).
     * Две причины по эталону (ar9002_set_txdesc + ath_tx_prepare):
     *  1) AR_ClrDestMask (бит 24 ctl0): без него PCU сверяет адрес
     *     назначения с MAC ячейки keycache и шифрует ТОЛЬКО при
     *     совпадении. У PTK-ячейки MAC = BSSID, у DHCP DISCOVER
     *     DA = ff:ff:ff:ff:ff:ff — сверка провалена, кадр уходит
     *     ОТКРЫТЫМ (что и видно в сниффере). ClrDestMask снимает сверку:
     *     станция шифрует к точке ВСЁ парным ключом (802.11i 12.5.x,
     *     mac80211 ieee80211_tx_h_select_key берёт ptk и для bcast).
     *  2) FrameLen включает хвост шифра (ath_cipher_tail): MIC дописывает
     *     железо — без него кадр передаётся обрезанным. */
    d->ctl0 = (((len + ath_cipher_tail(keyidx) + WIFI_FCS_LEN) & TXD_FrameLen) |
              (40u << TXD_XmitPower0_S) |
              (keyidx >= 0 ? (TXD_DestIdxValid | TXD_ClrDestMask) : 0));
    /* [W-TXMORE] (полевой лог AR9285: «AUTH не отправлен (TX отказ)» —
     * ПЕРВОЕ же выполнение owl-TX в поле; путь никогда не проверялся:
     * все прежние полевые чипы были AR9485/sowl): TxMore=1 означает
     * «у кадра есть ПРОДОЛЖЕНИЕ в следующем дескрипторе/буфере» —
     * у нас кадр ОДНОбуферный, а link=0: DCU либо ждал продолжение
     * вечно (TxDone не приходил), либо ронял кадр с ошибкой. Эталон
     * (ath9k) НЕ ставит TxMore для одно буферных кадров. Бит убран. */
    d->ctl1 = (len & TXD_FrameLen) |
              (noack ? TXD_NoAck : 0) |             /* FrameType NORMAL = 0 */
              (keyidx >= 0 ? (((u32)keyidx << TXD_DestIdx_S) & TXD_DestIdx) : 0);
    d->ctl2 = ((u32)(tries & 0xF) << TXD_XmitDataTries0_S);
    d->ctl3 = (u32)hw_rate;
    /* [W-CHAINSEL] (полевой лог итерации 9: st1=0x702 — DataFailCnt=7,
     * RSSI-поля 0x80 «не измерялись», ACK не приходил НИКОГДА). Эталон
     * ar9002_set_txdesc заполняет ChainSel для КАЖДОГО рейта серии —
     * выбор TX-цепочки PHY. ОС слала ctl7=0 = «ни одной цепочки» → PHY
     * не передавал кадр, MAC отсчитывал 7 таймаутов ACK в пустоту (и
     * завершение статуса могло подвисать без финального слова). 1T1R:
     * цепь A (1<<2). RTSCTSRate (биты 23:16) — как ath9k: младший
     * базовый рейт (1M); без RTS/CTS железом не используется. */
    d->ctl7 = (1u << TXD_ChainSel0_S) | ((u32)RATE_CCK_1M << TXD_RTSCTSRate_S);
    /* сессия 12/25: тип шифрования в ctl6 (0=CLR по умолчанию — memset).
     * PTK — всегда CCMP; GTK — CCMP или TKIP (смешанный режим). */
    if (keyidx >= 0) {
        u32 encr = TXD_ENCR_AES;
        if (keyidx != KC_PTK_ENTRY && ath_gtk_is_tkip)
            encr = TXD_ENCR_TKIP;                  /* 3 */
        d->ctl6 |= (encr << TXD_EncrType_S);
    }

    /* [W-TXISR] (полевые логи итераций 5/9: TxDone(status9.0) ЗАПАЗДЫВАЕТ
     * относительно фактического завершения — st1 уже финален (DataFailCnt),
     * а st9 приходил через десятки мс или не приходил в окно опроса вовсе;
     * при этом статус кадра остаётся в дескрипторе). Эталон завершение
     * кадра видит по ISR: AR_ISR_S0 (QCU_TXOK/TXDESC) и AR_ISR_S1
     * (QCU_TXERR/TXEOL); не-RAC чипы чистят биты записью прочитанного
     * (ar9002_mac.c: get_isr). Прерывания ОС не использует — биты в ISR
     * ставятся независимо от маски IMR. Порядок: строгий TxDone; если за
     * 10 мс после бита ISR TxDone не встал — кадр завершён (done=2). */
    {
        u32 s0 = reg32(AR_ISR_S0), s1 = reg32(AR_ISR_S1);
        if (s0) regw(AR_ISR_S0, s0);   /* хвосты прошлых завершений — до постановки */
        if (s1) regw(AR_ISR_S1, s1);
    }
    regw(AR_QTXDP(WIFI_TX_QUEUE), (u32)(unsigned long)d);
    regw(AR_Q_TXE, 1u << WIFI_TX_QUEUE);

    /* [W-TXDONE-STRICT] (полевой лог: «TX: завершён по TxDone=3
     * (st1=702 st9=0)» — завершение по эвристике «TXE погас + st1 != 0»
     * при НЕУСТАНОВЛЕННОМ TxDone). Эталон (ar9002_mac.c: proc_txdesc)
     * считает кадр завершённым ТОЛЬКО по status9.0 (AR_TxDone): без него
     * статусные слова — не финальные. Ждём только TxDone; погасшую TXE
     * фиксируем отдельно — это диагностика, а не признак завершения. */
    int done = 0, ok = 0, txe_gone = 0, isr_seen = 0, isr_ms = 0;
    for (int t = 0; t < 30000; t += 50) {          /* до 30 мс */
        if (d->st[9] & TXS_TxDone) { done = 1; break; }
        /* [W9-TXDONE-STRICT2] ([W-TXISR] полевой факт: st1 УЖЕ финален
         * (FrmXmitOK/DataFailCnt), а st9.0 TxDone запаздывает на десятки
         * мс — всё это время kmain стоит в wait-цикле, wifi_poll не
         * крутится, ответы точки копятся в кольце без разбора, а RX-зазор
         * [W-RXLAT] растёт до 50-170 мс). st1 != 0 = статус записан =
         * кадр завершён на MAC-уровне: выходим СРАЗУ. */
        if (d->st[1] & 0x00000FFFu) { done = 1; break; }
        if (!isr_seen) {
            u32 s0 = reg32(AR_ISR_S0), s1 = reg32(AR_ISR_S1);
            if (s0) regw(AR_ISR_S0, s0);
            if (s1) regw(AR_ISR_S1, s1);
            if ((s0 | s1) & AR_ISR_S0_QCU_TX) { isr_seen = 1; isr_ms = t; }
        }
        w_udelay(50);
    }
    if (!done && isr_seen) isr_ms = 30;   /* петля 2: t в мс — новая база */
    if (!done) {   /* щедрый запас: 300 мс (полевой лог итерации 5:
                    * 7 ретраев 1M на занятом эфире заняли ~152 мс —
                    * прежнего окна 150 мс Т-ТОЛЬКО не хватало) */
        for (int t = 30; t < 300; t += 1) {
            if (d->st[9] & TXS_TxDone) { done = 1; break; }
            if (d->st[1] & 0x00000FFFu) { done = 1; break; }  /* [W9-TXDONE-STRICT2] */
            if (!isr_seen) {
                u32 s0 = reg32(AR_ISR_S0), s1 = reg32(AR_ISR_S1);
                if (s0) regw(AR_ISR_S0, s0);
                if (s1) regw(AR_ISR_S1, s1);
                if ((s0 | s1) & AR_ISR_S0_QCU_TX) { isr_seen = 1; isr_ms = t; }
            } else if (t - isr_ms >= 10) { done = 2; break; }  /* 10 мс после ISR */
            if (!txe_gone && !(reg32(AR_Q_TXE) & (1u << WIFI_TX_QUEUE)))
                txe_gone = 1;
            w_udelay(1000);
        }
    }
    if (!done && txe_gone) {
        /* TXE погасла (очередь отработала), TxDone не встал — нетипично.
         * [W-TXDUMP2] Дампим ПОЛНЫЙ дескриптор (ctl + статус + 2 слова
         * после): полевой лог итерации 5 показал, что железо пишет
         * статусные слова В структуру (st[1]=702 = ExcessiveRetries +
         * DataFailCnt=7, st[9]=142b c TxDone=1 пришли МЕЖДУ печатью
         * «st9=0» и дампом), но точки отсчёта layout'а (ctl12/13 =
         * status0/1 по mac.h эталона) в дамп не попадали. Теперь
         * видны ОБЕ зоны — вопрос раскладки закроется одним логом. */
        static int s_raw = 0;
        if (s_raw < 2) {
            s_raw++;
            u32 *w = (u32 *)(unsigned long)d;
            wifi_log("TX: TXE погасла, TxDone(status9.0) НЕ установлен "
                     "(st1=%x st9=%x) — сырые слова дескриптора:",
                     (unsigned)d->st[1], (unsigned)d->st[9]);
            wifi_log("TX ctl0-3:   %08x %08x %08x %08x",
                     w[2], w[3], w[4], w[5]);
            wifi_log("TX ctl4-7:   %08x %08x %08x %08x",
                     w[6], w[7], w[8], w[9]);
            wifi_log("TX ctl8-11:  %08x %08x %08x %08x",
                     w[10], w[11], w[12], w[13]);
            wifi_log("TX ctl12-13: %08x %08x (по mac.h эталона это status0/1)",
                     w[14], w[15]);
            wifi_log("TX st0-4:    %08x %08x %08x %08x %08x",
                     w[16], w[17], w[18], w[19], w[20]);
            wifi_log("TX st5-9:    %08x %08x %08x %08x %08x",
                     w[21], w[22], w[23], w[24], w[25]);
            wifi_log("TX +2слова:  %08x %08x", w[26], w[27]);
        }
    }
    {
        static int s_logged = 0, s_isr_logged = 0;
        if (done == 1 && s_logged < 4) {
            s_logged++;
            wifi_log("TX: TxDone (st1=%x st9=%x)",
                     (unsigned)d->st[1], (unsigned)d->st[9]);
        }
        if (done == 2 && s_isr_logged < 4) {
            s_isr_logged++;
            wifi_log("TX: завершено по ISR (S0/S1), TxDone запаздывает "
                     "(st1=%x st9=%x) — статус финален",
                     (unsigned)d->st[1], (unsigned)d->st[9]);
        }
    }
    if (done) ok = (d->st[1] & TXS_FrmXmitOK) ? 1 : 0;
    else ok = noack;      /* noack-кадр могли передать, статуса не дождались */
    if (done) {
        extern void wc_tx_done_note(void);   /* [W-RXLAT] */
        wc_tx_done_note();
    }
    /* [W-TXDIAG] (запрос: «добавь логирование»): различаем ДВЕ причины
     * отказа — «TxDone не пришёл» (очередь/дескриптор стоят) и «ушёл,
     * но ACK нет» (эфир/канал/точка). Рейт-лимит: 3 всегда, дальше
     * раз в 5 с — шторм ретраев не захламляет serial. */
    if (!ok) ath_tx_fail_diag(done, (int)hw_rate, tries,
                              d->st[1], d->st[9]);
    regw(AR_Q_TXE, 0);
    s_unlock(&ath.tx_lock);
    return ok;
}

/* ---- передача одного кадра 802.11 (AR9003/AR9485, СЕССИЯ 15) ----
 * Та же семантика, что owl_tx_frame, но дескриптор ar9003 (24 слова +
 * чексумма указателей) и статус приходит в КОЛЬЦЕ (не в дескрипторе).
 * Запрос пользователя: «нужно реализовать WPA2» — на нетбуке ASUS
 * X101CH стоит AR9485, и до этой сессии подключение было запрещено
 * («TX пока не поддержан»): без TX нет ни AUTH/ASSOC, ни 4-way
 * рукопожатия. Формат — 1:1 из ar9003_mac.c эталона (ar9003_set_txdesc). */
static int sowl_tx_frame(const u8 *frame, u32 len, u8 hw_rate,
                         int tries, int noack, int keyidx)
{
    if (!ath.stxdesc || !ath.stxbuf || !ath.tsring) return 0;
    if (len > WIFI_TXBUF_SZ) return 0;

    s_lock(&ath.tx_lock);
    memcpy(ath.stxbuf, frame, len);

    sowl_txdesc_t *d = ath.stxdesc;
    memset(d, 0, sizeof(*d));
    d->info = (0x168cu << 16) |            /* DescId = Atheros */
              (1u << 15) |                 /* TxRxDesc = TX */
              (1u << 14) |                 /* CtrlStat = контрольный */
              ((u32)WIFI_TX_QUEUE << 8) |  /* TxQcuNum */
              0x17u;                       /* desc_len (в словах) */
    d->link = 0;                           /* конец списка */
    d->data0 = (u32)(unsigned long)ath.stxbuf;
    d->ctl3 = ((u32)len << 16) & 0x0FFF0000u;
    {
        u32 sum = d->info + d->link + d->data0 + d->ctl3 +
                  d->data1 + d->ctl5 + d->data2 + d->ctl7 +
                  d->data3 + d->ctl9;
        d->ctl10 = ((sum & 0xFFFFu) + (sum >> 16)) & 0xFFFFu;
    }
    /* ctl11: FrameLen | XmitPower0 (30 = 15 dBm) | DestIdxValid
     * [W-CCMPTX]: хвост шифра в FrameLen + ClrDestMask (бит 24) — перенос
     * раскладки owl ctl0 на ctl11 (DestIdxValid перенесён так же). */
    d->ctl11 = (((len + ath_cipher_tail(keyidx) + WIFI_FCS_LEN) & 0x0FFFu) |
                (30u << 16) |                                    /* [W-FCSLEN] */
                (keyidx >= 0 ? (0x40000000u | 0x01000000u) : 0));
    /* ctl12: DestIdx | FrameType(NORMAL=0) | NoAck */
    d->ctl12 = (keyidx >= 0 ? (((u32)keyidx << 13) & 0x000FE000u) : 0) |
               (noack ? 0x01000000u : 0);
    /* ctl13: попытки (основной рейт); DurUpdateEna не нужен —
     * duration в заголовке кадра ставим сами (owl-путь работает так) */
    d->ctl13 = ((u32)(tries & 0xF) << 16);
    /* ctl14: серия из одного рейта */
    d->ctl14 = (u32)hw_rate;
    /* ctl17: EncrType (биты 26-27): 2 = AES/CCMP, 3 = TKIP — как owl ctl6 */
    if (keyidx >= 0) {
        u32 encr = 2u;
        if (keyidx != KC_PTK_ENTRY && ath_gtk_is_tkip)
            encr = 3u;
        d->ctl17 |= (encr << 26);
    }
    d->ctl19 = 0x20000000u;                /* Not_Sounding (всегда) */

    regw(AR_QTXDP(WIFI_TX_QUEUE), (u32)(unsigned long)d);
    regw(AR_Q_TXE, 1u << WIFI_TX_QUEUE);

    /* ждём TxDone в статусном кольце (status8 bit0); записи выдаются
     * по порядку отправок — TX сериализован tx_lock + один дескриптор */
    sowl_txs_t *ts = &ath.tsring[ath.ts_tail];
    int done = 0, ok = 0;
    u32 diag_a = 0, diag_b = 0;   /* [W-TXDIAG-sowl]: статусы до очистки */
    for (int t = 0; t < 30000; t += 50) {          /* до 30 мс... */
        if (ts->status8 & TXS8_TxDone) { done = 1; break; }
        w_udelay(50);
    }
    if (!done) {   /* щедрый запас: 150 мс (ретраи 11Mx4) */
        for (int t = 30; t < 150; t += 5) {
            if (ts->status8 & TXS8_TxDone) { done = 1; break; }
            w_udelay(5000);
        }
    }
    if (done) {
        ok = (ts->status3 & TXS3_FrmXmitOK) ? 1 : 0;
        /* очистить запись и подвинуть хвост (ath9k_hw_clear_txstatus).
         * [W-TXDIAG-sowl]: статусы снимаются ДО memset — иначе
         * диагностика отказа всегда видит нули */
        diag_a = ts->status3;
        diag_b = ts->status8;
        memset(ts, 0, sizeof(*ts));
        ath.ts_tail = (ath.ts_tail + 1) % WIFI_TS_RING;
    } else {
        ok = noack;   /* noack-кадр могли передать, статуса не дождались */
        /* [ATH-TXTS] слот потребляется ВСЕГДА: статус мог прийти ПОСЛЕ
         * таймаута и оставался в кольце — следующий кадр читал ЧУЖОЙ
         * TxDone мгновенно, кольцо рассинхронизировалось навсегда
         * (AUTH/EAPOL переставали подтверждаться после первой потери) */
        diag_a = ts->status3;
        diag_b = ts->status8;
        memset(ts, 0, sizeof(*ts));
        ath.ts_tail = (ath.ts_tail + 1) % WIFI_TS_RING;
    }
    if (!ok) ath_tx_fail_diag(done, (int)hw_rate, tries,
                              diag_a, diag_b);
    regw(AR_Q_TXE, 0);
    s_unlock(&ath.tx_lock);
    return ok;
}

/* ДИСПЕТЧЕР: путь TX по семейству чипа (owl = AR9285/9287, sowl = AR9485) */

/* логический CCK/OFDM-рейт -> hw-код 5416 [rc.c эталона]
 * [W-RATEMAP] (поле: «TX отказ: rate=0» на попытке 6M): карта имела 4
 * записи, а WCRATE_6M = 4 — ath_rate_hw(WCRATE_6M) читал ПАМЯТЬ ЗА
 * ГРАНИЦЕЙ (мусорный hw-код → DCU отказ). Стало 5 записей + проверка
 * диапазона. У rtl_rate_hw карта 5-записей была изначально. */
static u8 ath_rate_hw(wc_rate_t r) {
    static const u8 map[5] = { RATE_CCK_1M, RATE_CCK_2M, RATE_CCK_5_5M,
                               RATE_CCK_11M, RATE_OFDM_6M };
    return ((unsigned)r <= WCRATE_6M) ? map[(int)r] : RATE_CCK_1M;
}

static int ath_ops_tx_frame(const u8 *frame, u32 len, wc_rate_t rate,
                            int tries, int noack, int keyidx) {
    u8 hw = ath_rate_hw(rate);
    if (ath.is_sowl)
        return sowl_tx_frame(frame, len, hw, tries, noack, keyidx);
    return owl_tx_frame(frame, len, hw, tries, noack, keyidx);
}

/* ---- RX-фильтры (ops) ---- */
/* фильтры RX: [W-RXCTRL] бит CONTROL ОБЯЗАТЕЛЕН в обоих режимах — ACK
 * (как и RTS/CTS) — управляющий кадр, без бита CONTROL железо
 * отбрасывает его ДО дескриптора и TX никогда не видит подтверждения
 * (FreeBSD/madwifi ставят CONTROL безусловно; в Linux его добавляет
 * mac80211 через FIF_CONTROL). Побочное: ACK-кадры попадают в очередь
 * RX — парсер wifi_core их просто пропускает. */
static void ath_rx_filter_promisc(void) {
    regw(AR_RX_FILTER, RXF_UCAST | RXF_MCAST | RXF_BCAST |
                       RXF_CONTROL | RXF_BEACON | RXF_PROM);
    /* [W-PHYERR] в скане PHY-err не нужны (шторм ошибок тайминга),
     * маски сбрасываем — как ath9k_hw_setrxfilter без PHYERR-бита */
    regw(AR_PHY_ERR, 0);
    reg_clr(AR_RXCFG, AR_RXCFG_ZLFDMA);
}

static void ath_rx_filter_bss(void) {
    /* [W-RXPROM-BSS] (полевой лог итерации 9/10: TX AUTH подтверждён точкой
     * (st1=1 = FrmXmitOK — ACK получен!), а ответа нет — юникаст-ответ
     * теряется ДО парсера. Фильтр UCAST + STA_ID0/1 выглядят корректно,
     * но приём юникаста у нас НИКОГДА не был проверен (скан видит только
     * маяки/бродкаст). Пока не локализуем, включаем PROM и в режиме BSS:
     * промискуитет проходит мимо DA-фильтра совсем; парсер wifi_core
     * фильтрует по BSSID, так что корректность не страдает. Диагностика
     * [W-RXUCDIAG] покажет в логе, доходят ли юникаст-кадры до драйвера.
     * [W-HWACK] (полевой лог esp32test: AUTH-ответ — юникаст DA=мы —
     * ПРИНЯТ и распознан; приём юникаста подтверждён, повод держать PROM
     * отпал). PROM-бит ЗАПРЕЩАЕТ PCU слать аппаратные ACK: точка 6 раз
     * отвечала на ASSOC-REQ без единого ACK с нашей стороны, ретраи
     * ответов тонули (ESP32: 6× безобидный «event id=63» — mesh-событие
     * обработки станции, esp-idf#2916). Теперь в режиме BSS фильтр БЕЗ
     * PROM: PCU сам ACK-ит юникаст на наш MAC (STA_ID0/1 записаны
     * ath_set_mac при инициализации). Скан возвращает PROM через
     * rx_filter_promisc(). */
    regw(AR_RX_FILTER, RXF_UCAST | RXF_MCAST | RXF_BCAST |
                       RXF_CONTROL | RXF_BEACON);
    /* [W-PHYERR-BSSOFF] (Task 36): диагностическое окно [W-PHYERR] закрыто —
     * оно дало свой ответ (за всё время наблюдений НЕ принят НИ ОДИН
     * HT/MCS-кадр; «прочие» HomeWifi = HT-трафик соседей; вопрос рейта RSP
     * решается командами 'B'/'f' скетча v9, а не доставкой PHY-err).
     * ВАЖНЕЕ: доставка PHY-err в режиме BSS — ЕДИНСТВЕННОЕ отклонение
     * конфигурации RX от состояния ПОБЕДНОГО esp32test (Task 30: assoc +
     * 4-way + DHCP, FILT=1f, AR_PHY_ERR не писался никогда) и от эталона
     * (mac80211 не запрашивает FIF_PLCPFAIL в штатных операциях —
     * ath9k_hw_setrxfilter держит AR_PHY_ERR=0 для STA). Полевая
     * хронология: победа без [W-PHYERR] (Task 30) -> включение (Task 32)
     * -> ASSOC-RSP 0/18 (Tasks 34-35+). Механизм урона правдоподобен:
     * RSP приходит в хвосте НАШЕЙ передачи (~1-3 мс), когда AGC досылает
     * ложные timing-триггеры собственного TX-хвоста — с открытыми масками
     * CCK/OFDM_TIMING этот мусор попадает в RX FIFO/DMA рядом с самой
     * RSP (на Owl PHY-err-кадр идёт через тот же FIFO и тот же пайплайн
     * дескрипторов). Возвращаем байт-в-байт эталонное состояние STA
     * (AR_PHY_ERR=0 + ZLFDMA=0 — ветка else ath9k_hw_setrxfilter).
     * Если когда-нибудь понадобится вернуть диагностику — три строки:
     *   regw(AR_RX_FILTER, ... | RXF_PHYERR);
     *   regw(AR_PHY_ERR, AR_PHY_ERR_OFDM_TIMING | AR_PHY_ERR_CCK_TIMING);
     *   reg_set(AR_RXCFG, AR_RXCFG_ZLFDMA); */
    regw(AR_PHY_ERR, 0);
    reg_clr(AR_RXCFG, AR_RXCFG_ZLFDMA);
    regw(AR_MCAST_FIL0, 0);
    regw(AR_MCAST_FIL1, 0);
}

/* ================= keycache (сессия 12: WPA2) =================
 * Раскладка как в ath_key.c (hostap): KEY0..KEY4 — ключ с «рваными»
 * словами (KEY1/KEY3 — 16-битные!), TYPE (base+20) = CCM(6)/TKIP(4),
 * MAC0/MAC1 (base+24/28) — адрес, сдвинутый вправо на бит,
 * + VALID(0x8000). Парный ключ (PTK): запись 4 с MAC = BSSID
 * (декодирует юникаст по TA). Групповой (GTK): запись = keyid,
 * MAC = 0 + VALID (default key: выбор по keyid из кадра). */
/* [W9-TKIPTYPE] (поле 27.10: assoc/4-way ок, DHCP нет; ВСЕ напечатанные
 * защищённые кадры — с TKIP-IV в буфере = железо НЕ расшифровало ни один
 * GTK-кадр точки). Причина найдена сверкой с эталоном ath/reg.h v5.15:
 * TYPE_TKIP = 4, а не 2! (40=0, 104=1, 128=3, TKIP=4, AES=5, CCM=6,
 * CLR=7). Значение 2 — НЕСУЩЕСТВУЮЩИЙ тип шифра: PCU не признавал
 * запись ключом TKIP и пропускал GTK-кадры нерасшифрованными. CCMP=6 у
 * нас был верен — поэтому TX-шифрование (M2/M4) и работало, а RX-декрипт
 * не работал НИКОГДА (в т.ч. в «победной» сессии Task 30 — печать
 * «RX защищ. data» с IV в буфере была и там, вывод «RX-decrypt работает»
 * был ошибочен: печать срабатывает и для НЕрасшифрованных кадров). */
#define AR_KEYTABLE_TYPE_TKIP  4u

static int ath_gtk_is_tkip = 0;   /* GTK TKIP -> EncrType TX-дескриптора */

/* MAC-часть записи: mac_or_null != 0 — юникаст (матч по TA),
 * NULL — default key (выбор по keyid из заголовка кадра). */
static void ath_keycache_mac(int entry, const u8 *mac_or_null)
{
    u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
    u32 mac0 = 0, mac1 = 0;
    if (mac_or_null) {
        mac0 = (u32)mac_or_null[0] | ((u32)mac_or_null[1] << 8) |
               ((u32)mac_or_null[2] << 16) | ((u32)mac_or_null[3] << 24);
        mac1 = (u32)mac_or_null[4] | ((u32)mac_or_null[5] << 8);
        mac0 >>= 1;                            /* MAC сдвинут вправо на бит */
        mac0 |= (mac1 & 1) << 31;
        mac1 >>= 1;
        mac1 |= AR_KEYTABLE_VALID;             /* unicast: матч по TA */
    } else {
        mac1 = AR_KEYTABLE_VALID;              /* default key (по keyid) */
    }
    regw(base + 24, mac0);
    regw(base + 28, mac1);
}

/* Запись ключа CCMP (16 б) в keycache. */
static void ath_keycache_write(int entry, const u8 *key16, const u8 *mac_or_null) {
    u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
    /* «рваные» слова — как ath_hw_set_keycache_entry (hostap):
     * KEY0=le32(k[0..3]) KEY1=le16(k[4..5]) KEY2=le32(k[6..9])
     * KEY3=le16(k[10..11]) KEY4=le32(k[12..15]) */
    regw(base + 0,  (u32)key16[0] | ((u32)key16[1] << 8) |
                    ((u32)key16[2] << 16) | ((u32)key16[3] << 24));
    regw(base + 4,  (u32)key16[4] | ((u32)key16[5] << 8));
    regw(base + 8,  (u32)key16[6] | ((u32)key16[7] << 8) |
                    ((u32)key16[8] << 16) | ((u32)key16[9] << 24));
    regw(base + 12, (u32)key16[10] | ((u32)key16[11] << 8));
    regw(base + 16, (u32)key16[12] | ((u32)key16[13] << 8) |
                    ((u32)key16[14] << 16) | ((u32)key16[15] << 24));
    regw(base + 20, AR_KEYTABLE_TYPE_CCM);    /* TYPE = AES-CCM */
    ath_keycache_mac(entry, mac_or_null);
}

/* Сессия 25 -> [W9-TKIPTYPE]: ключ TKIP в keycache, раскладка — ТЕПЕРЬ
 * байт-в-байт с эталоном (ath/key.c v5.15, ath_hw_set_keycache_entry,
 * ветка MIC_COMBINED — у AR9285 она включена):
 *   запись entry — TK (16 б): KEY0/1 = key[47:0], KEY2/3 = key[95:48],
 *     KEY4 = key[127:96], TYPE = TKIP(4);
 *   запись entry+64 — MIC-ключи: KEY0 = RX MIC[31:0], KEY1 = TX[31:16],
 *     KEY2 = RX MIC[63:32], KEY3 = TX[15:0], KEY4 = TX[63:32],
 *     TYPE = CLR(7); MAC0/MAC1 записи — reserved = 0 (НЕ VALID!);
 *   протокол записи: СНАЧАЛА инвертированные KEY0/1 (~key — защита от
 *     Michael-ошибок при параллельном доступе), затем KEY2/3, KEY4+TYPE,
 *     MAC, MIC-запись — и В САМОМ КОНЦЕ правильные KEY0/1 (эталон:
 *     «Write the correct (un-inverted) key[47:0] last»). */
static void ath_keycache_write_tkip(int entry, const u8 *key32,
                                    const u8 *mac_or_null)
{
    u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
    /* key32 = TK(16) + RX MIC(8) @16 + TX MIC(8) @24 (PRF-порядок) */
    u32 key0 = (u32)key32[0] | ((u32)key32[1] << 8) |
               ((u32)key32[2] << 16) | ((u32)key32[3] << 24);
    u32 key1 = (u32)key32[4] | ((u32)key32[5] << 8);
    u32 key2 = (u32)key32[6] | ((u32)key32[7] << 8) |
               ((u32)key32[8] << 16) | ((u32)key32[9] << 24);
    u32 key3 = (u32)key32[10] | ((u32)key32[11] << 8);
    u32 key4 = (u32)key32[12] | ((u32)key32[13] << 8) |
               ((u32)key32[14] << 16) | ((u32)key32[15] << 24);

    regw(base + 0, ~key0);              /* инвертированные key[47:0] — первыми */
    regw(base + 4, ~key1);
    regw(base + 8, key2);               /* key[95:48] */
    regw(base + 12, key3);
    regw(base + 16, key4);              /* key[127:96] */
    regw(base + 20, AR_KEYTABLE_TYPE_TKIP);
    ath_keycache_mac(entry, mac_or_null);

    /* MIC-запись (entry+64 — эталон, НЕ entry+1!) */
    u32 mbase = AR_KEYTABLE_BASE + (u32)(entry + 64) * 32;
    regw(mbase + 0,  (u32)key32[16] | ((u32)key32[17] << 8) |
                     ((u32)key32[18] << 16) | ((u32)key32[19] << 24));
    regw(mbase + 4,  (u32)key32[26] | ((u32)key32[27] << 8));  /* TX[31:16] */
    regw(mbase + 8,  (u32)key32[20] | ((u32)key32[21] << 8) |
                     ((u32)key32[22] << 16) | ((u32)key32[23] << 24));
    regw(mbase + 12, (u32)key32[24] | ((u32)key32[25] << 8));  /* TX[15:0] */
    regw(mbase + 16, (u32)key32[28] | ((u32)key32[29] << 8) |
                     ((u32)key32[30] << 16) | ((u32)key32[31] << 24));
    regw(mbase + 20, 7 /* AR_KEYTABLE_TYPE_CLR */);
    regw(mbase + 24, 0);                /* MAC записи MIC — reserved */
    regw(mbase + 28, 0);                /* (эталон: 0/0, БЕЗ VALID) */

    /* финал: правильные (неинвертированные) key[47:0] — включает TKIP */
    regw(base + 0, key0);
    regw(base + 4, key1);
}

/* ---- ops->keys_install / keys_clear ---- */
static int ath_keys_install(const u8 *bssid, const u8 *ptk, int ptk_is_tkip,
                            const u8 *gtk, int gtk_is_tkip, int gtk_keyid) {
    ath_gtk_is_tkip = gtk_is_tkip;
    /* PTK: CCMP — TK (ptk+32, 16 б); TKIP-пара (СЕССИЯ 48) — ptk+32 как
     * [TK16][RX MIC8][TX MIC8] (PRF-порядок: RX на +48, TX на +56),
     * ровно формат ath_keycache_write_tkip */
    if (ptk_is_tkip) {
        ath_keycache_write_tkip(KC_PTK_ENTRY, ptk + 32, bssid);
        wifi_log("PTK TKIP (64 б) -> запись %d+MIC", KC_PTK_ENTRY);
    } else {
        ath_keycache_write(KC_PTK_ENTRY, ptk + 32, bssid);
    }
    if (gtk_is_tkip) {
        /* [W9-TKIPTYPE]: MIC-запись теперь entry+64 — конфликтов с
         * ячейками 0..7 больше нет при любом keyid */
        ath_keycache_write_tkip(gtk_keyid & 3, gtk, NULL);
        wifi_log("GTK TKIP (32 б) -> запись %d+MIC", gtk_keyid & 3);
    } else {
        ath_keycache_write(gtk_keyid & 3, gtk, NULL);
    }
    return 1;
}

static void ath_keys_clear(void) {
    if (!ath.ready) return;
    /* [W9-TKIPTYPE]: MIC-записи TKIP теперь в entry+64 (эталон) —
     * чистим и их: 0..7 ключи + 64..71 MIC */
    for (int entry = 0; entry < 8; entry++) {
        u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
        for (int w = 0; w < 7; w++)
            regw(base + (u32)w * 4, 0);
        regw(base + 20, 7 /* CLR */);
    }
    for (int entry = 64; entry < 72; entry++) {
        u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
        for (int w = 0; w < 7; w++)
            regw(base + (u32)w * 4, 0);
        regw(base + 20, 7 /* CLR */);
    }
    ath_gtk_is_tkip = 0;
}

/* ---- AR9485: скан увидел 0 кадров — попробовать опорник 25 МГц;
 * [ATH-SCAN2] иначе (мало маяков) — просто второй проход: на загруженном
 * эфире маяк периодически сдвигается за край окна 110 мс, и сеть
 * пропускается. Раньше pass-2 был только у AR9485 (и только при 0
 * кадров), AR9285/9287 второго прохода не имели вовсе. */
static int ath_scan_retry(u32 frames_seen) {
    if (ath.is_sowl && !ath.clk25 && frames_seen == 0) {
        wifi_log("ни одного кадра — AR9485: пробую опорник 25 МГц");
        ath.clk25 = 1;
        if (ath_bringup()) {
            wifi_log("повторный init не удался");
            ath.clk25 = 0;
            ath_bringup();            /* вернуть рабочую конфигурацию */
            return 0;
        }
        return 1;
    }
    return 0;
}

/* ================= полный bring-up =================
 * Порядок — как ath9k_hw_reset для 2.4 ГГц HT20 станции (TX-очередь
 * и MAC из EEPROM добавлены в сессии 11 для ассоциации). */
static const char *ath_bringup(void) {
    const char *err;
    static char errbuf[64];
    int nf;

    if ((err = ath_reset(1))) { snprintf(errbuf, sizeof(errbuf), "reset: %s", err); return errbuf; }
    if (!g_bringup_quiet)
        wifi_log("reset ok (RTC status=%x)", reg32(AR_RTC_STATUS) & 0xF);

    if ((err = ath_power_awake())) { snprintf(errbuf, sizeof(errbuf), "power: %s", err); return errbuf; }

    ath_init_pll();
    if (!g_bringup_quiet)
        wifi_log("PLL настроен (0x%x)", reg32(AR_RTC_PLL_CONTROL));

    reg_set(AR_GPIO_IN_EN_VAL, AR_GPIO_JTAG_DIS);
    regw(AR_PHY_ACTIVE, 0);                       /* mark_phy_inactive */

    if (ath.is_sowl) sowl_process_ini();
    else             owl_process_ini();
    if (!g_bringup_quiet)
        wifi_log("ini-массивы записаны (%s)", ath.is_sowl ? "AR9485" : ath.chip == CHIP_AR9285 ? "AR9285" : "AR9287");

    ath_override_ini();
    ath_set_channel_regs();
    ath_chain_masks();
    ath_set_rfmode();
    /* [ATH-CC] канал — запрошенный (ath.chan), а не всегда 0: прежде
     * fallback bring-up после неудачи fastcc возвращал радио на канал 1 */
    ath_delta_slope(channel_freq[ath.chan]);

    /* [W-BOARD4K] board values из EEPROM modal-заголовка (как в
     * ath9k_hw_reset: после ini/настройки канала, до init_bb и
     * калибровки). Без них антенный коммутатор (SWITCH_COM/CHAIN),
     * RXGAIN-атенюация и bias'ы OB/DB остаются на ini-умолчаниях. */
    if (!ath.is_sowl && ath.chip == CHIP_AR9285 && g_eep4k_ok)
        ath_4k_set_board_values();

    /* [W-PCUTXBUF] (эталон hw.c ath9k_hw_reset: «reduce the number of
     * usable entries in PCU TXBUF to avoid wrap around issues»): у AR9285
     * PCU TX-буфер вдвое меньше — usable 0x380 слов; без записи после
     * сбоса остаётся ini-умолчание полного буфера. */
    regw(AR_PCU_TXBUF_CTRL,
         (!ath.is_sowl && ath.chip == CHIP_AR9285) ? AR_9285_PCU_TXBUF_USABLE
                                                   : AR_PCU_TXBUF_USABLE);
    ath_mac_dma_config();
    ath_set_sta_id();               /* наш MAC (EEPROM) — ACK + RX-фильтр */
    ath_tx_queue_setup();           /* QCU/DCU 0: данные + mgmt */
    /* [W-IFSTIME] ПОСЛЕ ini (тот пишет 0x8014=0) — тайминги ACK/SIFS/SLOT */
    ath_global_ifs_setup();
    ath_set_synth(ath.chan);        /* [ATH-CC] см. выше — не хардкод канала 1 */
    ath_init_bb();

    if (ath.is_sowl)      err = sowl_agc_cal();
    else if (ath.chip == CHIP_AR9287) err = kite_agc_cal();
    else                  err = owl_cl_cal();
    if (err) { snprintf(errbuf, sizeof(errbuf), "%s", err); return errbuf; }
    if (!g_bringup_quiet)
        wifi_log("калибровка ok (AGC=%x)", reg32(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL));

    /* [W-TXPOW-v2]: таблица per-rate по НАСТОЯЩИМ адресам (см. блок
     * комментариев у функции); контроль записи логирует сама функция.
     * [W-PDADC4K]: сначала калибровочная таблица PDADC из EEPROM —
     * порядок как в ath9k_hw_4k_set_txpower: power_cal_table -> rate regs */
    if (!ath.is_sowl) {
        u32 before3 = reg32(AR_PHY_POWER_TX_RATE3);
        u32 beforeM = reg32(AR_PHY_POWER_TX_RATE_MAX);
        if (ath.chip == CHIP_AR9285 && g_eep4k_ok)
            ath_4k_power_cal_table();
        ath_txpow_program();
        if (!g_bringup_quiet)
            wifi_log("TX-мощность: 15 дБм (до: RATE3=%08x MAX=%x)",
                     (unsigned)before3, (unsigned)beforeM);
    }

    ath_nf_load_start();

    if (!ath_rx_start()) {
        snprintf(errbuf, sizeof(errbuf), "нет памяти под RX-буферы");
        return errbuf;
    }

    /* диагностика в журнал: значения ключевых регистров после init */
    {
        u32 cca = ath.is_sowl ? AR_PHY_CCA_0_SOWL : AR_PHY_CCA;
        nf = nf_get(cca);
        g_nf_dbm = nf;   /* [W-RSSI-NF] база для перевода RSSI в dBm */
        if (g_bringup_quiet) {
            /* [W-QUIET] одна сводная строка вместо 6 детальных */
            wifi_log("bring-up ch %u: ok (NF=%d dBm)", (unsigned)ath.chan + 1u, nf);
        } else {
            wifi_log("RX поднят: SREV=%x RXDP=%x FILT=%x",
                     reg32(AR_SREV_REG),
                     reg32(AR_RXDP),
                     reg32(AR_RX_FILTER));
            wifi_log("NF после калибровки: %d dBm (CCA=%x), AGC=%x",
                     nf, (unsigned)reg32(cca),
                     (unsigned)reg32(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL));
        }
    }
    ath.ready = 1;
    wc_set_state(1, 1);
    return 0;
}

/* ================= probe (PCI) + привязка к wifi_core ================= */

static void ath_poll_rx_dispatch(void);
static void ath_full_reset(void);
static int ath_scan_retry(u32 frames_seen);
static int ath_keys_install(const u8 *bssid, const u8 *ptk, int ptk_is_tkip,
                            const u8 *gtk, int gtk_is_tkip, int gtk_keyid);
static void ath_keys_clear(void);
static void ath_rx_filter_promisc(void);
static void ath_rx_filter_bss(void);
static int ath_ops_set_channel(int ch_idx);
static int ath_ops_tx_frame(const u8 *frame, u32 len, wc_rate_t rate,
                            int tries, int noack, int keyidx);

static const wifi_hw_ops_t ath_ops = {
    .poll_rx           = ath_poll_rx_dispatch,
    .set_channel       = ath_ops_set_channel,
    .tx_frame          = ath_ops_tx_frame,
    .rx_filter_promisc = ath_rx_filter_promisc,
    .rx_filter_bss     = ath_rx_filter_bss,
    .keys_install      = ath_keys_install,
    .keys_clear        = ath_keys_clear,
    .full_reset        = ath_full_reset,
    .set_mac           = ath_set_mac,
    .set_bssid         = ath_set_bssid,    /* [W-BSSID] */
    .scan_retry        = ath_scan_retry,
    .tkip_sw_mic       = 0,     /* [W-TKIPSW]: Michael в железе (TX-MIC keycache) */
};

static void ath_poll_rx_dispatch(void) {
    if (ath.is_sowl) sowl_rx_poll();
    else             owl_rx_poll();
}

static void ath_full_reset(void) {
    ath_bringup();
}

int ath9k_wifi_probe(void) {
    memset(&ath, 0, sizeof(ath));

    serial_puts("[wifi] init: поиск Atheros (168c:002b/002e/0032)...\n");

    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                if ((id & 0xFFFF) != 0x168c) {
                    if (func == 0) {
                        u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                        if (!(hdr & 0x80)) break;
                    }
                    continue;
                }
                u32 devid = (id >> 16) & 0xFFFF;
                if (devid != 0x002b && devid != 0x002e && devid != 0x0032)
                    continue;

                ath.pci_devid = (u16)devid;
                ath.present = 1;
                char cname[36];
                if (devid == 0x002b)      { ath.chip = CHIP_AR9285; strcpy(cname, "Atheros AR9285"); }
                else if (devid == 0x002e) { ath.chip = CHIP_AR9287; strcpy(cname, "Atheros AR9287"); }
                else                      { ath.chip = CHIP_AR9485; ath.is_sowl = 1; strcpy(cname, "Atheros AR9485"); }
                wc_set_chip_name(cname);

                u32 bar0 = pci_read32(bus, dev, func, 0x10);
                ath.mmio_base = bar0 & 0xFFFFFFF0u;

                u16 cmd = pci_read16(bus, dev, func, 0x04);
                cmd |= 0x0006;                     /* Bus Master + Memory Space */
                pci_write16(bus, dev, func, 0x04, cmd);

                wifi_log("%s на шине %d:%d.%d, MMIO=%x",
                         cname, bus, dev, func, (unsigned)ath.mmio_base);

                if (!ath.mmio_base) {
                    wifi_log("BAR0 пуст — карта не активна BIOS'ом");
                    return 0;
                }

                ath.srev_raw = reg32(AR_SREV_REG);
                {
                    u32 v = ath.srev_raw & 0xFF;
                    u32 ver, rev;
                    if (v == 0xFF) {                    /* Owl+: версия в старших битах */
                        ver = (ath.srev_raw & 0xFFFC0000u) >> 12;
                        rev = (ath.srev_raw & 0x00000F00u) >> 8;
                    } else {                             /* ранние чипы */
                        ver = (v & 0xF0) >> 4;
                        rev = v & 0x7;
                    }
                    wifi_log("SREV=%x (MAC %x.%d)",
                             (unsigned)ath.srev_raw, (unsigned)ver, (int)rev);
                }

                w_udelay_calibrate();       /* честные мкс до первого сброса */

                read_mac_from_eeprom();     /* MAC нужен для STA_ID и TX */
                wc_set_mac(ath.mac);

                const char *err = ath_bringup();
                if (err) {
                    ath.ready = 0;
                    wc_set_state(1, 0);
                    wifi_log("INIT FAILED: %s", err);
                    return 0;               /* карта есть, но не поднялась */
                }
                wifi_core_bind(&ath_ops);
                return 1;               /* одно WiFi-устройство достаточно */
            }
        }
    }
    return 0;    /* адаптер Atheros не найден */
}
