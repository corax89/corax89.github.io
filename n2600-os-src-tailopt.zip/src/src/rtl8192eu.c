/* rtl8192eu.c — драйвер USB WiFi Realtek RTL8192EU/8191EU для N2600-OS.
 *
 * Порт минимального bring-up + скана + TX/RX из эталонного драйвера
 * Linux rtl8xxxu (GPLv2, drivers/net/wireless/realtek/rtl8xxxu,
 * редакция 6.6: rtl8xxxu_core.c + rtl8xxxu_8192e.c). Имена регистров
 * и таблиц сохранены 1:1 (rtl8192eu_regs.h / rtl8192eu_tables.h —
 * сгенерированы scripts/gen_rtl_regs.py / gen_rtl_tables.py).
 *
 * Что реализовано:
 *   - USB attach (0bda:818b RTL8192EU, 0bda:818b... см. IDs) через EHCI
 *     (usb_ehci_ctrl_xfer / usb_ehci_bulk_xfer, vendor-запросы 0xC5/0x45)
 *   - EFUSE: MAC, индексы мощности (полный разбор rtl8192eu_efuse)
 *   - Power-on (LDO/crystal AFE/APS FSM), identify chip (8192E/8191E)
 *   - Загрузка встроенной прошивки rtl8192eu_nic.bin (rtl8192eu_fw.c,
 *     32286 байт, v35.7) + запуск 8051
 *   - MAC init (таблица), LLT auto, BB/AGC/RF init (таблицы), enable_rf
 *   - LC + IQ калибровки (пути A/B), thermal meter
 *   - Полный init_device (RCR/фильтры/EDCA/SIFS/retry/beacon/CAM reset)
 *   - Смена канала (gen2, 20 МГц), скан 1-14 из wifi_core
 *   - TX: дескриптор rtl8xxxu_txdesc40 + кадр 802.11 bulk OUT по очередям
 *     (queue_sel MGNT/HIGH/BE/BK...), чексумма дескриптора
 *   - RX: bulk IN, разбор rtl8xxxu_rxdesc24 (в т.ч. цепочки пакетов в
 *     одном URB), PHY-статистика (RSSI CCK/OFDM)
 *   - WPA2: ключи в Security CAM (PTK по TA точки, GTK broadcast)
 *
 * Не реализовано: AP-mode beacon, HT40, power saving, AMPDU-агрегация
 * (AGG_BREAK), H2C rate mask (RA прошивки с дефолтами), BT-coexistence.
 *
 * Приём — polling: bulk IN каждые ~2 тика главного цикла (пустой
 * endpoint NAK-ится, поэтому таймаут трансфера короткий).
 * Чипо-независимая логика — wifi_core.c (wifi_hw_ops_t).
 *
 * Источник: Linux (GPLv2). Лицензия GPL.
 */
#include "types.h"
#include "wifi_core.h"
#include "usb_ehci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "sync.h"
#include "kernel.h"
#include "io.h"
#include "rtl8192eu_regs.h"
#include "rtl8192eu_tables.h"

/* пути RF (enum rtl8xxxu_rfpath эталона) */
#define RF_PATH_A 0
#define RF_PATH_B 1

__attribute__((unused))   /* заготовка под broadcast-TX (GTK/групповые) */
static const u8 bcast_mac[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static int rtl_gtk_is_tkip = 0;   /* GTK TKIP -> хвост RX-кадра 12/8 */
/* СЕССИЯ 52: алгоритм ПАРНОГО шифра для SEC-битов TX-дескриптора —
 * данные шифруются всегда PTK (802.11i STA-правило), т.е. RC4 если
 * пара TKIP, AES если CCMP */
static int rtl_ptk_is_tkip = 0;

/* смещение версии чипа в SYS_CFG (маска 0xf000 — биты 12-15) */
#define SYS_CFG_CHIP_VERSION_SHIFT 12
/* длина содержимого EFUSE (эталон: EFUSE_REAL_CONTENT_LEN_8723A) */
#define RTL_EFUSE_CONTENT_LEN 512

/* [DEDUP] (отчёт, баг 8): до фикса эти блоки были продублированы
 * (макросы SYS_CFG/EFUSE — дважды, декларации rtl_udelay/rtl_mdelay —
 * трижды, хвостовая декларация rtl_full_reset после определения):
 * артефакты слияния версий файла. GCC молча пропускал идентичные
 * повторы, но при ЛЮБОМ расхождении копий (правка одной из них)
 * компиляция бы молча взяла последнюю. */
static void rtl_udelay(int us);
static void rtl_mdelay(int ms);

/* page-выровненный буфер (EHCI пишет 4K-страницы в buffer[]).
 * unsigned long: на 32-битном ядре это 32 бита (как u32), а на
 * 64-битном хосте (харнесс rtlwifi) указатель не усекается. */
static u8 *rtl_page_alloc(int size) {
    u8 *raw = (u8 *)malloc((u32)size + 4096);
    if (!raw) return NULL;
    return (u8 *)(((unsigned long)raw + 4095) & ~(unsigned long)4095u);
}

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);

/* ---- USB vendor-доступ Realtek (rtl8xxxu_core.c) ---- */
#define RTL_USB_READ        0xC5
#define RTL_USB_WRITE       0x45
#define RTL_USB_CMD_REQ     0x05
#define RTL_USB_CTRL_TIMEOUT_ITER   20000   /* итераций опроса qTD */

/* прошивка (rtl8192eu_fw.c) */
extern const u8  rtl8192eu_fw_data[];
#define RTL8192EU_FW_SIZE   32286u

/* fw-заголовок (struct rtl8xxxu_firmware_header, 32 байта) */
typedef struct __attribute__((packed)) {
    u16 signature;
    u8  category;
    u8  function;
    u16 major_version;
    u8  minor_version;
    u8  reserved1;
    u8  month, date, hour, minute;
    u16 ramcodesize;
    u16 reserved2;
    u32 svn_idx;
    u32 reserved3, reserved4, reserved5;
    u8  data[];
} rtl_fw_header_t;

/* ================= состояние драйвера ================= */

#define RTL_MAX_TXBUF   1600        /* кадр 802.11 + запас */
/* СЕССИЯ 42: 16К как у эталонных драйверов Realtek (MAX_RECVBUF_SZ /
 * 16K-URB). EHCI qTD покрывает до 20К (5 page-указателей по 4К).
 * Раньше буфер был ровно 4К: прошивка агрегирует несколько принятых
 * кадров в один bulk-поток — при накоплении > 4К qTD завершался по
 * заполнению буфера прямо ВОТРЕ СЕРЕДИНЫ кадра (DBE при пересечении
 * границы страницы), а устройство оставалось с недоставленным пакетом.
 * 16К снимает оба эффекта: цепочка кадров парсится из одного qTD
 * (rtl_parse_rx уже умеет), DBE практически исключён. */
#define RTL_RXBUF_SZ    16384

/* TX-очереди (как TXDESC_QUEUE_* в дескрипторе) */
#define RTL_NQUEUES     8           /* BK/BE/VI/VO/BEACON/HIGH/MGNT/CMD */
#define RQ_BK 0
#define RQ_BE 1
#define RQ_VI 2
#define RQ_VO 3
#define RQ_BEACON 4
#define RQ_HIGH 5
#define RQ_MGNT 6
#define RQ_CMD  7

typedef struct {
    int  attached;          /* устройство найдено и занято */
    int  addr;              /* USB address */
    int  ep_in;             /* bulk IN endpoint номер (без 0x80) */
    int  ep_in_size;
    int  ep_out_size;
    int  nr_out_eps;
    u8   out_ep[4];         /* номера bulk OUT endpoints по порядку */
    int  ep_tx_high_q, ep_tx_normal_q, ep_tx_low_q;
    int  ep_tx_count;

    int  ready;             /* полный bring-up прошёл */
    char chip_name[24];     /* 8192EU / 8191EU */
    int  tx_paths;          /* 2 = 8192EU, 1 = 8191E */
    int  chip_cut;

    /* efuse (struct rtl8192eu_efuse, 512 байт) */
    u8   efuse_map[512];
    int  efuse_ok;
    u8   mac[6];
    u8   cck_pwr_a[6], cck_pwr_b[6];
    u8   ht40_pwr_a[5], ht40_pwr_b[5];
    u8   ht20_diff_a, ht20_diff_b;    /* ht20_ofdm_1s_diff.b (nibbles) */
    u8   xtal_cap;

    /* TX */
    u8  *txbuf;             /* [txdesc40 40 б][кадр] — 4K-выровнен */
    volatile int tx_lock;

    /* RX */
    u8  *rxbuf;             /* 4K-выровнен (одна страница) */
    int  poll_gate;         /* тик последнего bulk-опроса */
    int  wedged;            /* сессия 40: адаптер перестал отвечать по USB */
    int  io_fail;           /* сессия 40: подряд неудачных регистровых операций */
    int  rx_fail_streak;    /* сессия 41: подряд сорвавшихся RX-очередей (-2) */
    int  zero_scan_streak;  /* сессия 41: подряд завершённых сканов с 0 кадров */

    /* мощность/канал */
    int  channel;           /* текущий канал (1-14), 0 = не задан */

    /* страницы TX-буфера (fops) */
    u8   total_page_num, page_hi, page_lo, page_norm;
} rtl_t;

static rtl_t rtl;

/* "RTL8192EU" == 2T2R, "RTL8191EU" == 1T2R (bonding) */

/* ================= USB регистровый доступ ================= */

static u32 rtl_read(int len, u16 addr) {
    u32 v = 0;
    /* СЕССИЯ 42: 3 попытки с паузой 10 мс — EP0 периодически XactErr'ит
     * под нагрузкой (занят приёмом страницы прошивки/IQK), один сбой не
     * должен рвать инициализацию и счётчик io_fail. */
    for (int attempt = 0; attempt < 3; attempt++) {
        if (attempt) rtl_mdelay(10);
        v = 0;
        if (usb_ehci_ctrl_xfer(rtl.addr, RTL_USB_READ, RTL_USB_CMD_REQ,
                               addr, 0, &v, len, 1) >= 0) {
            rtl.io_fail = 0;
            return v;
        }
    }
    if (rtl.ready) rtl.io_fail++;   /* ватчдог клина (только в работе) */
    return 0;
}

static u8 rtl_r8(u16 addr)  { return (u8)rtl_read(1, addr); }
static u16 rtl_r16(u16 addr){ return (u16)rtl_read(2, addr); }
static u32 rtl_r32(u16 addr){ return rtl_read(4, addr); }

static int rtl_write(int len, u16 addr, u32 val) {
    /* СЕССИЯ 42: 3 попытки с паузой 10 мс — см. rtl_read. */
    for (int attempt = 0; attempt < 3; attempt++) {
        if (attempt) rtl_mdelay(10);
        if (usb_ehci_ctrl_xfer(rtl.addr, RTL_USB_WRITE, RTL_USB_CMD_REQ,
                               addr, 0, &val, len, 0) >= 0) {
            rtl.io_fail = 0;
            return 0;
        }
    }
    if (rtl.ready) rtl.io_fail++;   /* ватчдог клина (только в работе) */
    return -1;
}

static int rtl_w8 (u16 addr, u8 v)  { return rtl_write(1, addr, v); }
static int rtl_w16(u16 addr, u16 v) { return rtl_write(2, addr, v); }
static int rtl_w32(u16 addr, u32 v) { return rtl_write(4, addr, v); }

/* writeN — блок в память чипа (прошивка), чанки по 128 (fops->writeN_block_size) */
static int rtl_write_n(u16 addr, const u8 *buf, int len) {
    const int bs = 128;
    int off = 0;
    while (off < len) {
        int chunk = len - off;
        if (chunk > bs) chunk = bs;
        if (usb_ehci_ctrl_xfer(rtl.addr, RTL_USB_WRITE, RTL_USB_CMD_REQ,
                               (u16)(addr + off), 0,
                               (void *)(buf + off), chunk, 0) < 0)
            return -1;
        off += chunk;
    }
    return len;
}

/* ---- RF (косвенно через HSSI, rtl8xxxu_read_rfreg/write_rfreg) ---- */

typedef struct {
    u16 hssiparm1, hssiparm2, lssiparm, hspiread, lssiread;
} rtl_rfregs_t;

static const rtl_rfregs_t rtl_rfregs[2] = {
    { REG_FPGA0_XA_HSSI_PARM1, REG_FPGA0_XA_HSSI_PARM2,
      REG_FPGA0_XA_LSSI_PARM, REG_HSPI_XA_READBACK,
      REG_FPGA0_XA_LSSI_READBACK },
    { REG_FPGA0_XB_HSSI_PARM1, REG_FPGA0_XB_HSSI_PARM2,
      REG_FPGA0_XB_LSSI_PARM, REG_HSPI_XB_READBACK,
      REG_FPGA0_XB_LSSI_READBACK },
};

static u32 rtl_read_rfreg(int path, u8 reg) {
    const rtl_rfregs_t *rf = &rtl_rfregs[path & 1];
    u32 hssia = rtl_r32(REG_FPGA0_XA_HSSI_PARM2);
    u32 val32 = (path == RF_PATH_A) ? hssia : rtl_r32(rf->hssiparm2);
    val32 &= ~FPGA0_HSSI_PARM2_ADDR_MASK;
    val32 |= ((u32)reg << FPGA0_HSSI_PARM2_ADDR_SHIFT);
    val32 |= FPGA0_HSSI_PARM2_EDGE_READ;
    hssia &= ~FPGA0_HSSI_PARM2_EDGE_READ;
    rtl_w32(REG_FPGA0_XA_HSSI_PARM2, hssia);
    rtl_udelay(10);
    rtl_w32(rf->hssiparm2, val32);
    rtl_udelay(100);
    hssia |= FPGA0_HSSI_PARM2_EDGE_READ;
    rtl_w32(REG_FPGA0_XA_HSSI_PARM2, hssia);
    rtl_udelay(10);
    u32 v = rtl_r32(rf->hssiparm1);
    u32 retval;
    if (v & FPGA0_HSSI_PARM1_PI)
        retval = rtl_r32(rf->hspiread);
    else
        retval = rtl_r32(rf->lssiread);
    return retval & 0xFFFFFu;
}

static int rtl_write_rfreg(int path, u8 reg, u32 data) {
    const rtl_rfregs_t *rf = &rtl_rfregs[path & 1];
    data &= FPGA0_LSSI_PARM_DATA_MASK;
    u32 dataaddr = ((u32)reg << FPGA0_LSSI_PARM_ADDR_SHIFT) | data;
    /* 8192E: перед записью RF — запрет энергосбережения (эталон) */
    u32 ps = rtl_r32(REG_FPGA0_POWER_SAVE);
    rtl_w32(REG_FPGA0_POWER_SAVE, ps & ~0x20000u);
    rtl_w32(rf->lssiparm, dataaddr);
    rtl_udelay(1);
    ps = rtl_r32(REG_FPGA0_POWER_SAVE);
    rtl_w32(REG_FPGA0_POWER_SAVE, ps | 0x20000u);
    return 0;
}

/* ================= EFUSE (rtl8xxxu_read_efuse + parse) ================= */

/* EFUSE_REAL_CONTENT_LEN и EFUSE_MAP_LEN из regs header */

static int rtl_read_efuse8(u16 offset, u8 *data) {
    rtl_w8(REG_EFUSE_CTRL + 1, (u8)(offset & 0xff));
    u8 val8 = rtl_r8(REG_EFUSE_CTRL + 2);
    val8 &= 0xfc;
    val8 |= (u8)((offset >> 8) & 0x03);
    rtl_w8(REG_EFUSE_CTRL + 2, val8);

    val8 = rtl_r8(REG_EFUSE_CTRL + 3);
    rtl_w8(REG_EFUSE_CTRL + 3, (u8)(val8 & 0x7f));

    int i = 0;
    u32 val32 = rtl_r32(REG_EFUSE_CTRL);
    for (i = 0; i < 500; i++) {
        val32 = rtl_r32(REG_EFUSE_CTRL);
        if (val32 & BIT(31)) break;
    }
    if (i >= 500) return -1;
    rtl_udelay(50);
    val32 = rtl_r32(REG_EFUSE_CTRL);
    *data = (u8)(val32 & 0xff);
    return 0;
}

static int rtl_read_efuse(void) {
    u16 val16 = rtl_r16(REG_9346CR);
    (void)val16;    /* EEPROM boot — только диагностика, нам не важно */

    rtl_w8(REG_EFUSE_ACCESS, EFUSE_ACCESS_ENABLE);

    val16 = rtl_r16(REG_SYS_ISO_CTRL);
    if (!(val16 & SYS_ISO_PWC_EV12V)) {
        val16 |= SYS_ISO_PWC_EV12V;
        rtl_w16(REG_SYS_ISO_CTRL, val16);
    }
    val16 = rtl_r16(REG_SYS_FUNC);
    if (!(val16 & SYS_FUNC_ELDR)) {
        val16 |= SYS_FUNC_ELDR;
        rtl_w16(REG_SYS_FUNC, val16);
    }
    val16 = rtl_r16(REG_SYS_CLKR);
    if (!(val16 & SYS_CLK_LOADER_ENABLE) || !(val16 & SYS_CLK_ANA8M)) {
        val16 |= (SYS_CLK_LOADER_ENABLE | SYS_CLK_ANA8M);
        rtl_w16(REG_SYS_CLKR, val16);
    }

    memset(rtl.efuse_map, 0xff, sizeof(rtl.efuse_map));

    u16 efuse_addr = 0;
    int ret = 0;
    while (efuse_addr < RTL_EFUSE_CONTENT_LEN) {
        u8 header, extheader, val8;
        u16 offset, map_addr;
        u8 word_mask;

        if (rtl_read_efuse8(efuse_addr++, &header) || header == 0xff)
            goto exit;

        if ((header & 0x1f) == 0x0f) {          /* extended header */
            offset = (header & 0xe0) >> 5;
            if (rtl_read_efuse8(efuse_addr++, &extheader)) { ret = -1; goto exit; }
            if ((extheader & 0x0f) == 0x0f) continue;   /* все слова disabled */
            offset |= ((extheader & 0xf0) >> 1);
            word_mask = extheader & 0x0f;
        } else {
            offset = (header >> 4) & 0x0f;
            word_mask = header & 0x0f;
        }

        map_addr = offset * 8;
        for (int i = 0; i < 4; i++) {
            if (word_mask & BIT(i)) {
                map_addr += 2;
                continue;
            }
            if (rtl_read_efuse8(efuse_addr++, &val8)) { ret = -1; goto exit; }
            if (map_addr >= sizeof(rtl.efuse_map) - 1) { ret = -1; goto exit; }
            rtl.efuse_map[map_addr++] = val8;
            if (rtl_read_efuse8(efuse_addr++, &val8)) { ret = -1; goto exit; }
            rtl.efuse_map[map_addr++] = val8;
        }
    }
exit:
    rtl_w8(REG_EFUSE_ACCESS, EFUSE_ACCESS_DISABLE);
    if (ret == 0) rtl.efuse_ok = 1;
    return ret;
}

/* struct rtl8192eu_efuse — смещения из эталона (rtl8xxxu.h) */
#define EF8129_RTL_ID      0x8129

static void rtl_parse_efuse(void) {
    u8 *m = rtl.efuse_map;
    u16 rtl_id = (u16)(m[0] | (m[1] << 8));
    if (rtl_id != EF8129_RTL_ID) {
        wifi_log("efuse: rtl_id=%04x (ожидался %04x) — использую дефолты",
                 rtl_id, EF8129_RTL_ID);
        return;
    }
    /* tx_power_index_A @0x10: cck[6], ht40[5], ht20_ofdm_1s_diff, pwr_diff[3] */
    memcpy(rtl.cck_pwr_a,  m + 0x10, 6);
    memcpy(rtl.ht40_pwr_a, m + 0x16, 5);
    rtl.ht20_diff_a = (u8)((m[0x1b] >> 4) & 0x0f);   /* struct rtl8723au_idx: a:4, b:4 (LE) */
    /* tx_power_index_B @0x3a */
    memcpy(rtl.cck_pwr_b,  m + 0x3a, 6);
    memcpy(rtl.ht40_pwr_b, m + 0x40, 5);
    rtl.ht20_diff_b = (u8)((m[0x45] >> 4) & 0x0f);
    /* xtal_k @0xb9 */
    rtl.xtal_cap = m[0xb9] & 0x3f;
    /* mac_addr @0xd7 */
    memcpy(rtl.mac, m + 0xd7, 6);
    if ((rtl.mac[0] & 1) ||
        (rtl.mac[0] | rtl.mac[1] | rtl.mac[2] | rtl.mac[3] | rtl.mac[4] | rtl.mac[5]) == 0) {
        wifi_log("efuse MAC невалиден — локальный адрес 02:1a:2b:..");
        rtl.mac[0] = 0x02; rtl.mac[1] = 0x1a; rtl.mac[2] = 0x2b;
        rtl.mac[3] = 0x8e; rtl.mac[4] = 0x92; rtl.mac[5] = 0xe1;
    }
}

/* мощность по группам каналов (rtl8xxxu_gen2_channel_to_group):
 * 1-3 -> 0, 4-9 -> 1, 10-14 -> 2 */
static int rtl_channel_group(int channel) {
    if (channel >= 1 && channel <= 3) return 0;
    if (channel >= 4 && channel <= 9) return 1;
    return 2;
}

/* rtl8192e_set_tx_power: индексы мощности в TX AGC регистры */
static void rtl_set_tx_power(int channel, int ht40) {
    int group = rtl_channel_group(channel);
    u8 cck, ofdmbase, mcsbase;
    u32 val32, ofdm, mcs;

    cck = rtl.cck_pwr_a[group];
    val32 = rtl_r32(REG_TX_AGC_A_CCK1_MCS32);
    val32 &= 0xffff00ff;
    val32 |= ((u32)cck << 8);
    rtl_w32(REG_TX_AGC_A_CCK1_MCS32, val32);

    val32 = rtl_r32(REG_TX_AGC_B_CCK11_A_CCK2_11);
    val32 &= 0xff;
    val32 |= (((u32)cck << 8) | ((u32)cck << 16) | ((u32)cck << 24));
    rtl_w32(REG_TX_AGC_B_CCK11_A_CCK2_11, val32);

    ofdmbase = rtl.ht40_pwr_a[group];
    ofdmbase += rtl.ht20_diff_a;      /* упрощение: работаем в HT20 */
    ofdm = (u32)ofdmbase | ((u32)ofdmbase << 8) | ((u32)ofdmbase << 16) |
           ((u32)ofdmbase << 24);
    rtl_w32(REG_TX_AGC_A_RATE18_06, ofdm);
    rtl_w32(REG_TX_AGC_A_RATE54_24, ofdm);

    mcsbase = rtl.ht40_pwr_a[group] + (ht40 ? 0 : rtl.ht20_diff_a);
    mcs = (u32)mcsbase | ((u32)mcsbase << 8) | ((u32)mcsbase << 16) |
          ((u32)mcsbase << 24);
    rtl_w32(REG_TX_AGC_A_MCS03_MCS00, mcs);
    rtl_w32(REG_TX_AGC_A_MCS07_MCS04, mcs);
    rtl_w32(REG_TX_AGC_A_MCS11_MCS08, mcs);
    rtl_w32(REG_TX_AGC_A_MCS15_MCS12, mcs);

    if (rtl.tx_paths > 1) {
        cck = rtl.cck_pwr_b[group];
        val32 = rtl_r32(REG_TX_AGC_B_CCK1_55_MCS32);
        val32 &= 0xff;
        val32 |= (((u32)cck << 8) | ((u32)cck << 16) | ((u32)cck << 24));
        rtl_w32(REG_TX_AGC_B_CCK1_55_MCS32, val32);

        val32 = rtl_r32(REG_TX_AGC_B_CCK11_A_CCK2_11);
        val32 &= 0xffffff00;
        val32 |= cck;
        rtl_w32(REG_TX_AGC_B_CCK11_A_CCK2_11, val32);

        ofdmbase = rtl.ht40_pwr_b[group] + rtl.ht20_diff_b;
        ofdm = (u32)ofdmbase | ((u32)ofdmbase << 8) | ((u32)ofdmbase << 16) |
               ((u32)ofdmbase << 24);
        rtl_w32(REG_TX_AGC_B_RATE18_06, ofdm);
        rtl_w32(REG_TX_AGC_B_RATE54_24, ofdm);

        mcsbase = rtl.ht40_pwr_b[group] + (ht40 ? 0 : rtl.ht20_diff_b);
        mcs = (u32)mcsbase | ((u32)mcsbase << 8) | ((u32)mcsbase << 16) |
              ((u32)mcsbase << 24);
        rtl_w32(REG_TX_AGC_B_MCS03_MCS00, mcs);
        rtl_w32(REG_TX_AGC_B_MCS07_MCS04, mcs);
        rtl_w32(REG_TX_AGC_B_MCS11_MCS08, mcs);
        rtl_w32(REG_TX_AGC_B_MCS15_MCS12, mcs);
    }
}

/* ================= задержки (порт 0x80, калибровка по PIT) ================= */

static u16 rtl_pit2_count(void) {
    outb(0x43, 0x80);                  /* latch канал 2 */
    return (u16)(inb(0x42) | (inb(0x42) << 8));
}

static u32 g_rtl_io_per_us = 4;

static void rtl_udelay_calibrate(void) {
    u8 p61 = inb(0x61);
    outb(0x61, (p61 | 0x01) & ~0x02);  /* GATE2=1, динамик выкл */
    outb(0x43, 0xB4);                  /* канал 2, режим 2, binary */
    outb(0x42, 0xFF); outb(0x42, 0xFF);/* делитель 65535 */

    u32 best = 0;
    for (int s = 0; s < 4; s++) {
        u32 n = 2000;
        u16 t0 = rtl_pit2_count();
        for (u32 i = 0; i < n; i++) (void)inb(0x80);
        u16 t1 = rtl_pit2_count();
        u32 dt = (u32)((t0 - t1) & 0xFFFF);
        if (dt < 8 || dt > 60000) continue;
        u32 per_us = (u32)(((u64)n * 1193182u) / 1000000u / dt);
        if (per_us > best) best = per_us;
    }
    /* [PIT2-RESYNC]: GATE2 оставляем открытым (конвенция timer.c), базу
     * оборотов переозначаем после перепрограммки канала 2. */
    outb(0x61, (u8)((p61 | 0x01) & ~0x02));
    timer_pit2_resync();
    if (best == 0) best = 4;           /* PIT молчит — консервативно */
    if (best > 2000) best = 2000;
    g_rtl_io_per_us = best + 1;
}

static void rtl_udelay(int us) {
    if (us <= 0) return;
    volatile u32 n = (u32)us * g_rtl_io_per_us;
    while (n-- > 0) (void)inb(0x80);
}

static void rtl_mdelay(int ms) {
    for (int i = 0; i < ms; i++) rtl_udelay(1000);
}

/* ================= identify + power-on ================= */

/* rtl8192eu_identify_chip: версия/бондинг/чип */
static int rtl_identify_chip(void) {
    u32 sys_cfg = rtl_r32(REG_SYS_CFG);
    rtl.chip_cut = (int)((sys_cfg & SYS_CFG_CHIP_VERSION_MASK) >>
                         SYS_CFG_CHIP_VERSION_SHIFT);
    if (sys_cfg & SYS_CFG_TRP_VAUX_EN) {
        wifi_log("тестовый чип (TRP_VAUX_EN) — не поддержан");
        return -1;
    }
    u32 bonding = rtl_r32(REG_HPON_FSM) & HPON_FSM_BONDING_MASK;
    if (bonding == HPON_FSM_BONDING_1T2R) {
        strcpy(rtl.chip_name, "RTL8191EU");
        rtl.tx_paths = 1;
    } else {
        strcpy(rtl.chip_name, "RTL8192EU");
        rtl.tx_paths = 2;
    }
    wifi_log("%s (cut %d, %dT2R, SYS_CFG=%08x)",
             rtl.chip_name, rtl.chip_cut, rtl.tx_paths,
             (unsigned)sys_cfg);
    return 0;
}

/* rtl8192e_crystal_afe_adjust */
static void rtl_crystal_afe_adjust(void) {
    u8 val8 = rtl_r8(REG_AFE_PLL_CTRL);
    val8 &= 0xfb;
    rtl_w8(REG_AFE_PLL_CTRL, val8);

    u32 val32 = rtl_r32(REG_AFE_CTRL4);
    val32 &= 0xfffffc7f;
    rtl_w32(REG_AFE_CTRL4, val32);

    val8 = rtl_r8(REG_AFE_PLL_CTRL);
    val8 &= 0xbf;
    rtl_w8(REG_AFE_PLL_CTRL, val8);

    val32 = rtl_r32(REG_AFE_CTRL4);
    val32 &= 0xffdfffff;
    rtl_w32(REG_AFE_CTRL4, val32);
}

/* rtl8192e_disabled_to_emu */
static void rtl_disabled_to_emu(void) {
    u8 val8 = rtl_r8(REG_APS_FSMCO + 1);
    val8 &= (u8)~(BIT(3) | BIT(4));
    rtl_w8(REG_APS_FSMCO + 1, val8);
}

/* rtl8192e_emu_to_active */
static int rtl_emu_to_active(void) {
    u8 val8;
    int count;

    /* disable HWPDN 0x04[15]=0 */
    val8 = rtl_r8(REG_APS_FSMCO + 1);
    val8 &= (u8)~BIT(7);
    rtl_w8(REG_APS_FSMCO + 1, val8);

    /* disable SW LPS 0x04[10]=0 */
    val8 = rtl_r8(REG_APS_FSMCO + 1);
    val8 &= (u8)~BIT(2);
    rtl_w8(REG_APS_FSMCO + 1, val8);

    /* disable WL suspend */
    val8 = rtl_r8(REG_APS_FSMCO + 1);
    val8 &= (u8)~(BIT(3) | BIT(4));
    rtl_w8(REG_APS_FSMCO + 1, val8);

    /* wait till 0x04[17] = 1 power ready */
    for (count = 500; count; count--) {
        u32 val32 = rtl_r32(REG_APS_FSMCO);
        if (val32 & BIT(17)) break;
        rtl_udelay(10);
    }
    if (!count) { wifi_log("power: нет PFM_READY"); return -1; }

    /* release WLON reset 0x04[16]=1 */
    val8 = rtl_r8(REG_APS_FSMCO + 2);
    val8 |= BIT(0);
    rtl_w8(REG_APS_FSMCO + 2, val8);

    /* set, then poll until 0 (MAC ENABLE самосбрасывается) */
    u32 val32 = rtl_r32(REG_APS_FSMCO);
    val32 |= APS_FSMCO_MAC_ENABLE;
    rtl_w32(REG_APS_FSMCO, val32);

    for (count = 500; count; count--) {
        val32 = rtl_r32(REG_APS_FSMCO);
        if ((val32 & APS_FSMCO_MAC_ENABLE) == 0) return 0;
        rtl_udelay(10);
    }
    wifi_log("power: MAC не ожил");
    return -1;
}

/* rtl8192eu_power_on */
static int rtl_power_on(void) {
    u32 val32 = rtl_r32(REG_SYS_CFG);
    if (val32 & SYS_CFG_SPS_LDO_SEL) {
        rtl_w8(REG_LDO_SW_CTRL, 0xc3);
    } else {
        /* Raise 1.2V voltage */
        val32 = rtl_r32(REG_8192E_LDOV12_CTRL);
        val32 &= 0xff0fffff;
        val32 |= 0x00500000;
        rtl_w32(REG_8192E_LDOV12_CTRL, val32);
        rtl_w8(REG_LDO_SW_CTRL, 0x83);
    }

    rtl_crystal_afe_adjust();
    rtl_disabled_to_emu();

    int ret = rtl_emu_to_active();
    if (ret) return ret;

    rtl_w16(REG_CR, 0x0000);

    /* Enable MAC DMA/WMAC/SCHEDULE/SEC block + 32k calibration */
    u16 val16 = rtl_r16(REG_CR);
    val16 |= (CR_HCI_TXDMA_ENABLE | CR_HCI_RXDMA_ENABLE |
              CR_TXDMA_ENABLE | CR_RXDMA_ENABLE |
              CR_PROTOCOL_ENABLE | CR_SCHEDULE_ENABLE |
              CR_MAC_TX_ENABLE | CR_MAC_RX_ENABLE |
              CR_SECURITY_ENABLE | CR_CALTIMER_ENABLE);
    rtl_w16(REG_CR, val16);
    return 0;
}

/* rtl8xxxu_reset_8051 */
static void rtl_reset_8051(void) {
    u8 val8 = rtl_r8(REG_RSV_CTRL + 1);
    val8 &= (u8)~BIT(0);
    rtl_w8(REG_RSV_CTRL + 1, val8);

    u16 sys_func = rtl_r16(REG_SYS_FUNC);
    sys_func &= (u16)~SYS_FUNC_CPU_ENABLE;
    rtl_w16(REG_SYS_FUNC, sys_func);

    val8 = rtl_r8(REG_RSV_CTRL + 1);
    val8 |= BIT(0);
    rtl_w8(REG_RSV_CTRL + 1, val8);

    sys_func |= SYS_FUNC_CPU_ENABLE;
    rtl_w16(REG_SYS_FUNC, sys_func);
}

/* ================= прошивка ================= */

/* rtl8xxxu_download_firmware */
static int rtl_download_firmware(void) {
    const rtl_fw_header_t *fw = (const rtl_fw_header_t *)rtl8192eu_fw_data;
    u32 fw_size = RTL8192EU_FW_SIZE - sizeof(rtl_fw_header_t);
    const u8 *fwptr = fw->data;

    u8 val8 = rtl_r8(REG_SYS_FUNC + 1);
    val8 |= 4;
    rtl_w8(REG_SYS_FUNC + 1, val8);

    /* 8051 enable */
    u16 val16 = rtl_r16(REG_SYS_FUNC);
    val16 |= SYS_FUNC_CPU_ENABLE;
    rtl_w16(REG_SYS_FUNC, val16);

    val8 = rtl_r8(REG_MCU_FW_DL);
    if (val8 & MCU_FW_RAM_SEL) {
        wifi_log("прошивка уже работает — сброс MCU");
        rtl_w8(REG_MCU_FW_DL, 0x00);
        rtl_reset_8051();
    }

    /* MCU firmware download enable */
    val8 = rtl_r8(REG_MCU_FW_DL);
    val8 |= MCU_FW_DL_ENABLE;
    rtl_w8(REG_MCU_FW_DL, val8);

    /* 8051 reset */
    u32 val32 = rtl_r32(REG_MCU_FW_DL);
    val32 &= ~BIT(19);
    rtl_w32(REG_MCU_FW_DL, val32);

    /* Reset firmware download checksum */
    val8 = rtl_r8(REG_MCU_FW_DL);
    val8 |= MCU_FW_DL_CSUM_REPORT;
    rtl_w8(REG_MCU_FW_DL, val8);

    u32 pages = fw_size / RTL_FW_PAGE_SIZE;
    u32 remainder = fw_size % RTL_FW_PAGE_SIZE;

    /* СЕССИЯ 42: страницы с ретраями (3 попытки, пауза 20 мс) и паузой
     * 100 мкс между страницами — EP0 занят обработкой предыдущей страницы;
     * один XactErr больше не рвёт всю загрузку («сбой записи страницы 2»
     * из лога). Эталон целиком повторяет загрузку при -EAGAIN (до 5 раз) —
     * у нас общий init тоже ретраится снаружи, страниц достаточно. */
    for (u32 i = 0; i < pages; i++) {
        int ok = 0;
        for (int attempt = 0; attempt < 3 && !ok; attempt++) {
            if (attempt) rtl_mdelay(20);
            val8 = (u8)(rtl_r8(REG_MCU_FW_DL + 2) & 0xF8);
            val8 |= (u8)i;
            rtl_w8(REG_MCU_FW_DL + 2, val8);
            if (rtl_write_n(REG_FW_START_ADDRESS, fwptr, RTL_FW_PAGE_SIZE) >= 0)
                ok = 1;
        }
        if (!ok) {
            wifi_log("прошивка: сбой записи страницы %u (3 попытки)", (unsigned)i);
            goto fw_abort;
        }
        fwptr += RTL_FW_PAGE_SIZE;
        rtl_udelay(100);
    }
    if (remainder) {
        int ok = 0;
        for (int attempt = 0; attempt < 3 && !ok; attempt++) {
            if (attempt) rtl_mdelay(20);
            val8 = (u8)(rtl_r8(REG_MCU_FW_DL + 2) & 0xF8);
            val8 |= (u8)pages;
            rtl_w8(REG_MCU_FW_DL + 2, val8);
            if (rtl_write_n(REG_FW_START_ADDRESS, fwptr, (int)remainder) >= 0)
                ok = 1;
        }
        if (!ok) {
            wifi_log("прошивка: сбой записи хвоста (3 попытки)");
            goto fw_abort;
        }
    }
fw_abort:
    /* MCU firmware download disable */
    val16 = rtl_r16(REG_MCU_FW_DL);
    val16 &= (u16)~MCU_FW_DL_ENABLE;
    rtl_w16(REG_MCU_FW_DL, val16);
    return 0;
}

/* rtl8xxxu_start_firmware */
static int rtl_start_firmware(void) {
    u16 reg_mcu_fw_dl = REG_MCU_FW_DL;

    int i;
    u32 val32 = 0;
    for (i = 0; i < 1000; i++) {
        val32 = rtl_r32(reg_mcu_fw_dl);
        if (val32 & MCU_FW_DL_CSUM_REPORT) break;
        rtl_udelay(100);
    }
    if (i == 1000) {
        wifi_log("прошивка: чексумма не подтвердилась");
        return -1;
    }

    val32 = rtl_r32(reg_mcu_fw_dl);
    val32 |= MCU_FW_DL_READY;
    val32 &= ~MCU_WINT_INIT_READY;
    rtl_w32(reg_mcu_fw_dl, val32);

    /* Reset 8051 — иначе прошивка не стартует на 8192eu (эталон) */
    rtl_reset_8051();

    for (i = 0; i < 1000; i++) {
        val32 = rtl_r32(reg_mcu_fw_dl);
        if (val32 & MCU_WINT_INIT_READY) break;
        rtl_udelay(100);
    }
    if (i == 1000) {
        wifi_log("прошивка: не стартовала (MCU_WINT_INIT_READY=0)");
        return -1;
    }
    rtl_w8(REG_HMTFR, 0x0f);      /* init H2C command */
    return 0;
}

/* ================= init (MAC/BB/RF/калибровки) ================= */

/* rtl8xxxu_init_mac по rtl8192e_mac_init_table */
static int rtl_init_mac(void) {
    for (int i = 0; ; i++) {
        u16 reg = rtl8192e_mac_init_table[i].addr;
        u8 val = (u8)rtl8192e_mac_init_table[i].val;
        if (reg == 0xffff && val == 0xff) break;
        if (rtl_w8(reg, val)) {
            wifi_log("MAC init: сбой на reg %04x", reg);
            return -1;
        }
    }
    return 0;
}

static int rtl_init_phy_regs(const rtl_tab_entry_t *tab) {
    for (int i = 0; ; i++) {
        u16 reg = tab[i].addr;
        u32 val = tab[i].val;
        if (reg == 0xffff && val == 0xffffffff) break;
        if (rtl_w32(reg, val)) return -1;
        rtl_udelay(1);
    }
    return 0;
}

/* rtl8xxxu_init_phy_rf по radioa/radiob */
static int rtl_init_rf_table(const rtl_tab_entry_t *tab, int path) {
    for (int i = 0; ; i++) {
        u8 reg = (u8)tab[i].addr;
        u32 val = tab[i].val;
        if (reg == 0xff && val == 0xffffffff) break;
        rtl_write_rfreg(path, reg, val);
        rtl_udelay(1);
    }
    return 0;
}

/* rtl8192eu_init_phy_bb */
static void rtl_init_phy_bb(void) {
    u16 val16 = rtl_r16(REG_SYS_FUNC);
    val16 |= SYS_FUNC_BB_GLB_RSTN | SYS_FUNC_BBRSTB | SYS_FUNC_DIO_RF;
    rtl_w16(REG_SYS_FUNC, val16);

    u8 val8 = RF_ENABLE | RF_RSTB | RF_SDMRSTB;
    rtl_w8(REG_RF_CTRL, val8);

    val16 = rtl_r16(REG_SYS_FUNC);
    val16 |= (SYS_FUNC_USBA | SYS_FUNC_USBD | SYS_FUNC_DIO_RF |
              SYS_FUNC_BB_GLB_RSTN | SYS_FUNC_BBRSTB);
    rtl_w16(REG_SYS_FUNC, val16);
    rtl_w8(REG_RF_CTRL, (u8)(RF_ENABLE | RF_RSTB | RF_SDMRSTB));

    rtl_init_phy_regs(rtl8192eu_phy_init_table);
    rtl_init_phy_regs(rtl8xxxu_agc_8192eu_std_table);
}

/* rtl8192eu_init_phy_rf */
static int rtl_init_phy_rf(void) {
    if (rtl_init_rf_table(rtl8192eu_radioa_init_table, RF_PATH_A)) return -1;
    if (rtl_init_rf_table(rtl8192eu_radiob_init_table, RF_PATH_B)) return -1;
    return 0;
}

/* rtl8192e_enable_rf */
static void rtl_enable_rf(void) {
    u32 val32 = rtl_r32(REG_RX_WAIT_CCA);
    val32 |= (BIT(22) | BIT(23));
    rtl_w32(REG_RX_WAIT_CCA, val32);

    u8 val8 = rtl_r8(REG_GPIO_MUXCFG);
    val8 |= BIT(5);
    rtl_w8(REG_GPIO_MUXCFG, val8);

    /* WLAN action by PTA */
    rtl_w8(REG_WLAN_ACT_CONTROL_8723B, 0x04);

    val32 = rtl_r32(REG_PWR_DATA);
    val32 |= PWR_DATA_EEPRPAD_RFE_CTRL_EN;
    rtl_w32(REG_PWR_DATA, val32);

    val32 = rtl_r32(REG_RFE_BUFFER);
    val32 |= (BIT(0) | BIT(1));
    rtl_w32(REG_RFE_BUFFER, val32);

    rtl_w8(REG_RFE_CTRL_ANTA_SRC, 0x77);

    val32 = rtl_r32(REG_LEDCFG0);
    val32 &= ~BIT(24);
    val32 |= BIT(23);
    rtl_w32(REG_LEDCFG0, val32);

    /* Fix external switch Main->S1, Aux->S0 */
    val8 = rtl_r8(REG_PAD_CTRL1);
    val8 &= (u8)~BIT(0);
    rtl_w8(REG_PAD_CTRL1, val8);

    /* Fix transmission failure of rtl8192e */
    rtl_w8(REG_TXPAUSE, 0x00);
}

/* rtl8xxxu_init_queue_reserved_page */
static void rtl_init_queue_reserved_page(void) {
    u32 hq = 0, lq = 0, nq = 0, pubq;
    if (rtl.ep_tx_high_q)   hq = rtl.page_hi;
    if (rtl.ep_tx_low_q)    lq = rtl.page_lo;
    if (rtl.ep_tx_normal_q) nq = rtl.page_norm;

    rtl_w32(REG_RQPN_NPQ, (nq << RQPN_NPQ_SHIFT) | (0u << RQPN_EPQ_SHIFT));

    pubq = rtl.total_page_num - hq - lq - nq - 1;
    u32 val32 = RQPN_LOAD;
    val32 |= (hq << RQPN_HI_PQ_SHIFT);
    val32 |= (lq << RQPN_LO_PQ_SHIFT);
    val32 |= (pubq << RQPN_PUB_PQ_SHIFT);
    rtl_w32(REG_RQPN, val32);
}

/* rtl8xxxu_init_queue_priority (общая часть: TRXDMA_CTRL + маппинг
 * очередей на OUT-эндпоинты) */
static int rtl_init_queue_priority(void) {
    u16 hi = 0, lo = 0;
    int hip = 0, mgp = 0, bkp = 0, bep = 0, vip = 0, vop = 0;

    switch (rtl.ep_tx_count) {
    case 1:
        if (rtl.ep_tx_high_q)        hi = TRXDMA_QUEUE_HIGH;
        else if (rtl.ep_tx_low_q)    hi = TRXDMA_QUEUE_LOW;
        else if (rtl.ep_tx_normal_q) hi = TRXDMA_QUEUE_NORMAL;
        else return -1;
        break;
    case 2:
        if (rtl.ep_tx_high_q && rtl.ep_tx_low_q) {
            hi = TRXDMA_QUEUE_HIGH; lo = TRXDMA_QUEUE_LOW;
        } else if (rtl.ep_tx_normal_q && rtl.ep_tx_low_q) {
            hi = TRXDMA_QUEUE_NORMAL; lo = TRXDMA_QUEUE_LOW;
        } else if (rtl.ep_tx_high_q && rtl.ep_tx_normal_q) {
            hi = TRXDMA_QUEUE_HIGH; lo = TRXDMA_QUEUE_NORMAL;
        } else return -1;
        break;
    case 3:
    default:   /* >3 EPs — используем первые три */
        hi = TRXDMA_QUEUE_HIGH;
        lo = TRXDMA_QUEUE_LOW;
        break;
    }
    /* индексы EP: HIGH(3)^3=0, NORMAL(2)^3=1, LOW(1)^3=2;
     * 2 EPs — приоритеты 0 и 1 (эталон: bkp=bep=1) */
    hip = hi ^ 3;
    mgp = hip;
    vip = hip;
    vop = hip;
    if (rtl.ep_tx_count >= 3) { bkp = lo ^ 3; bep = bkp; }
    else if (rtl.ep_tx_count == 2) { bkp = 1; bep = 1; }

    u16 val16 = (u16)(rtl_r16(REG_TRXDMA_CTRL) & 0x7);
    val16 |= (u16)((vop << TRXDMA_CTRL_VOQ_SHIFT) |
                   (vip << TRXDMA_CTRL_VIQ_SHIFT) |
                   (bep << TRXDMA_CTRL_BEQ_SHIFT) |
                   (bkp << TRXDMA_CTRL_BKQ_SHIFT) |
                   (mgp << TRXDMA_CTRL_MGQ_SHIFT) |
                   (hip << TRXDMA_CTRL_HIQ_SHIFT));
    rtl_w16(REG_TRXDMA_CTRL, val16);
    return 0;
}

/* rtl8xxxu_auto_llt_table */
static int rtl_llt_init(void) {
    u32 val32 = rtl_r32(REG_AUTO_LLT);
    val32 |= AUTO_LLT_INIT_LLT;
    rtl_w32(REG_AUTO_LLT, val32);
    for (int i = 500; i; i--) {
        val32 = rtl_r32(REG_AUTO_LLT);
        if (!(val32 & AUTO_LLT_INIT_LLT)) return 0;
        rtl_udelay(4);
    }
    wifi_log("LLT init не завершился");
    return -1;
}

/* rtl8xxxu_gen2_usb_quirks */
static void rtl_usb_quirks(void) {
    u32 val32 = rtl_r32(REG_TXDMA_OFFSET_CHK);
    val32 |= TXDMA_OFFSET_DROP_DATA_EN;
    rtl_w32(REG_TXDMA_OFFSET_CHK, val32);
}

/* rtl8723a_phy_lc_calibrate (has_s0s1=0 для 8192e) */
static void rtl_lc_calibrate(void) {
    u32 lstf = rtl_r32(REG_OFDM1_LSTF);
    u32 rf_amode = 0, rf_bmode = 0;

    if (lstf & OFDM_LSTF_MASK) {
        rtl_w32(REG_OFDM1_LSTF, lstf & ~OFDM_LSTF_MASK);
        rf_amode = rtl_read_rfreg(RF_PATH_A, RF6052_REG_AC);
        rtl_write_rfreg(RF_PATH_A, RF6052_REG_AC,
                        (rf_amode & 0x8ffff) | 0x10000);
        if (rtl.tx_paths > 1) {
            rf_bmode = rtl_read_rfreg(RF_PATH_B, RF6052_REG_AC);
            rtl_write_rfreg(RF_PATH_B, RF6052_REG_AC,
                            (rf_bmode & 0x8ffff) | 0x10000);
        }
    } else {
        rtl_w8(REG_TXPAUSE, 0xff);
    }

    u32 val32 = rtl_read_rfreg(RF_PATH_A, RF6052_REG_MODE_AG);
    val32 |= 0x08000;
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_MODE_AG, val32);

    rtl_mdelay(100);

    if (lstf & OFDM_LSTF_MASK) {
        rtl_w32(REG_OFDM1_LSTF, lstf);
        rtl_write_rfreg(RF_PATH_A, RF6052_REG_AC, rf_amode);
        if (rtl.tx_paths > 1)
            rtl_write_rfreg(RF_PATH_B, RF6052_REG_AC, rf_bmode);
    } else {
        rtl_w8(REG_TXPAUSE, 0x00);
    }
}

/* ================= IQ калибровка (rtl8xxxu_8192e.c) ================= */

static int rtl_iqk_path_a(void) {
    u32 reg_eac, reg_e94, reg_e9c;
    int result = 0;

    /* TX IQK, PA/PAD controlled by 0x0 */
    rtl_w32(REG_FPGA0_IQK, 0x00000000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_GAIN_CCA, 0x00180);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_RCK_OS, 0x20000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G2, 0x07f77);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);

    rtl_w32(REG_TX_IQK_TONE_A, 0x18008c1c);
    rtl_w32(REG_RX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_TX_IQK_TONE_B, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_B, 0x38008c1c);

    rtl_w32(REG_TX_IQK_PI_A, 0x82140303);
    rtl_w32(REG_RX_IQK_PI_A, 0x68160000);

    /* LO calibration setting */
    rtl_w32(REG_IQK_AGC_RSP, 0x00462911);

    /* One shot, path A LOK & IQK */
    rtl_w32(REG_IQK_AGC_PTS, 0xf9000000);
    rtl_w32(REG_IQK_AGC_PTS, 0xf8000000);
    rtl_mdelay(10);

    reg_eac = rtl_r32(REG_RX_POWER_AFTER_IQK_A_2);
    reg_e94 = rtl_r32(REG_TX_POWER_BEFORE_IQK_A);
    reg_e9c = rtl_r32(REG_TX_POWER_AFTER_IQK_A);

    if (!(reg_eac & BIT(28)) &&
        ((reg_e94 & 0x03ff0000) != 0x01420000) &&
        ((reg_e9c & 0x03ff0000) != 0x00420000))
        result |= 0x01;
    return result;
}

static int rtl_rx_iqk_path_a(void) {
    u32 reg_ea4, reg_eac, reg_e94, reg_e9c, val32;
    int result = 0;

    rtl_w32(REG_FPGA0_IQK, 0x00);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G2, 0xf1173);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G2, 0xf1173);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_GAIN_CCA, 0x00980);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_PAD_TXG, 0x511e0);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);

    rtl_w32(REG_TX_IQK, 0x01007c00);
    rtl_w32(REG_RX_IQK, 0x01004800);

    rtl_w32(REG_TX_IQK_TONE_A, 0x18008c1c);
    rtl_w32(REG_RX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_TX_IQK_TONE_B, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_B, 0x38008c1c);

    rtl_w32(REG_TX_IQK_PI_A, 0x8216031f);
    rtl_w32(REG_RX_IQK_PI_A, 0x6816031f);

    rtl_w32(REG_IQK_AGC_RSP, 0x0046a911);

    rtl_w32(REG_IQK_AGC_PTS, 0xf9000000);
    rtl_w32(REG_IQK_AGC_PTS, 0xf8000000);
    rtl_mdelay(10);

    reg_eac = rtl_r32(REG_RX_POWER_AFTER_IQK_A_2);
    reg_e94 = rtl_r32(REG_TX_POWER_BEFORE_IQK_A);
    reg_e9c = rtl_r32(REG_TX_POWER_AFTER_IQK_A);

    if (!(reg_eac & BIT(28)) &&
        ((reg_e94 & 0x03ff0000) != 0x01420000) &&
        ((reg_e9c & 0x03ff0000) != 0x00420000)) {
        result |= 0x01;
    } else {
        rtl_w32(REG_FPGA0_IQK, 0x00000000);
        rtl_write_rfreg(RF_PATH_A, RF6052_REG_GAIN_CCA, 0x180);
        return 0;
    }

    val32 = 0x80007c00 |
            (reg_e94 & 0x03ff0000) | ((reg_e9c >> 16) & 0x03ff);
    rtl_w32(REG_TX_IQK, val32);

    rtl_w32(REG_FPGA0_IQK, 0x00000000);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G2, 0xf7ff2);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G2, 0xf7ff2);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_GAIN_CCA, 0x00980);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_PAD_TXG, 0x510e0);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);

    rtl_w32(REG_RX_IQK, 0x01004800);

    rtl_w32(REG_TX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_A, 0x18008c1c);
    rtl_w32(REG_TX_IQK_TONE_B, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_B, 0x38008c1c);

    rtl_w32(REG_TX_IQK_PI_A, 0x821608ff);
    rtl_w32(REG_RX_IQK_PI_A, 0x281608ff);

    rtl_w32(REG_IQK_AGC_RSP, 0x0046a891);

    rtl_w32(REG_IQK_AGC_PTS, 0xf9000000);
    rtl_w32(REG_IQK_AGC_PTS, 0xf8000000);
    rtl_mdelay(10);

    reg_eac = rtl_r32(REG_RX_POWER_AFTER_IQK_A_2);
    reg_ea4 = rtl_r32(REG_RX_POWER_BEFORE_IQK_A_2);

    rtl_w32(REG_FPGA0_IQK, 0x00000000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_GAIN_CCA, 0x180);

    if (!(reg_eac & BIT(27)) &&
        ((reg_ea4 & 0x03ff0000) != 0x01320000) &&
        ((reg_eac & 0x03ff0000) != 0x00360000))
        result |= 0x02;
    return result;
}

static int rtl_iqk_path_b(void) {
    u32 reg_eac, reg_eb4, reg_ebc;
    int result = 0;

    rtl_w32(REG_FPGA0_IQK, 0x00000000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_GAIN_CCA, 0x00180);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_RCK_OS, 0x20000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G2, 0x07f77);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);

    rtl_w32(REG_TX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_TX_IQK_TONE_B, 0x18008c1c);
    rtl_w32(REG_RX_IQK_TONE_B, 0x38008c1c);

    rtl_w32(REG_TX_IQK_PI_B, 0x82140303);
    rtl_w32(REG_RX_IQK_PI_B, 0x68160000);

    rtl_w32(REG_IQK_AGC_RSP, 0x00462911);

    rtl_w32(REG_IQK_AGC_PTS, 0xfa000000);
    rtl_w32(REG_IQK_AGC_PTS, 0xf8000000);
    rtl_mdelay(1);

    reg_eac = rtl_r32(REG_RX_POWER_AFTER_IQK_A_2);
    reg_eb4 = rtl_r32(REG_TX_POWER_BEFORE_IQK_B);
    reg_ebc = rtl_r32(REG_TX_POWER_AFTER_IQK_B);

    if (!(reg_eac & BIT(31)) &&
        ((reg_eb4 & 0x03ff0000) != 0x01420000) &&
        ((reg_ebc & 0x03ff0000) != 0x00420000))
        result |= 0x01;
    return result;
}

static int rtl_rx_iqk_path_b(void) {
    u32 reg_eac, reg_eb4, reg_ebc, reg_ec4, reg_ecc, val32;
    int result = 0;

    rtl_w32(REG_FPGA0_IQK, 0x00000000);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G2, 0xf1173);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G2, 0xf1173);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_GAIN_CCA, 0x00980);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_PAD_TXG, 0x511e0);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);

    rtl_w32(REG_TX_IQK, 0x01007c00);
    rtl_w32(REG_RX_IQK, 0x01004800);

    rtl_w32(REG_TX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_TX_IQK_TONE_B, 0x18008c1c);
    rtl_w32(REG_RX_IQK_TONE_B, 0x38008c1c);

    rtl_w32(REG_TX_IQK_PI_B, 0x8216031f);
    rtl_w32(REG_RX_IQK_PI_B, 0x6816031f);

    rtl_w32(REG_IQK_AGC_RSP, 0x0046a911);

    rtl_w32(REG_IQK_AGC_PTS, 0xfa000000);
    rtl_w32(REG_IQK_AGC_PTS, 0xf8000000);
    rtl_mdelay(10);

    reg_eac = rtl_r32(REG_RX_POWER_AFTER_IQK_A_2);
    reg_eb4 = rtl_r32(REG_TX_POWER_BEFORE_IQK_B);
    reg_ebc = rtl_r32(REG_TX_POWER_AFTER_IQK_B);

    if (!(reg_eac & BIT(31)) &&
        ((reg_eb4 & 0x03ff0000) != 0x01420000) &&
        ((reg_ebc & 0x03ff0000) != 0x00420000)) {
        result |= 0x01;
    } else {
        rtl_w32(REG_FPGA0_IQK, 0x00000000);
        rtl_write_rfreg(RF_PATH_B, RF6052_REG_GAIN_CCA, 0x180);
        return 0;
    }

    val32 = 0x80007c00 |
            (reg_eb4 & 0x03ff0000) | ((reg_ebc >> 16) & 0x03ff);
    rtl_w32(REG_TX_IQK, val32);

    rtl_w32(REG_FPGA0_IQK, 0x00000000);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_TXPA_G2, 0xf7ff2);

    rtl_write_rfreg(RF_PATH_A, RF6052_REG_WE_LUT, 0x800a0);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_RCK_OS, 0x30000);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G1, 0x0000f);
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_TXPA_G2, 0xf7ff2);

    rtl_write_rfreg(RF_PATH_B, RF6052_REG_GAIN_CCA, 0x00980);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_PAD_TXG, 0x510e0);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);

    rtl_w32(REG_RX_IQK, 0x01004800);

    rtl_w32(REG_TX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_A, 0x38008c1c);
    rtl_w32(REG_TX_IQK_TONE_B, 0x38008c1c);
    rtl_w32(REG_RX_IQK_TONE_B, 0x18008c1c);

    rtl_w32(REG_TX_IQK_PI_B, 0x821608ff);
    rtl_w32(REG_RX_IQK_PI_B, 0x281608ff);

    rtl_w32(REG_IQK_AGC_RSP, 0x0046a891);

    rtl_w32(REG_IQK_AGC_PTS, 0xfa000000);
    rtl_w32(REG_IQK_AGC_PTS, 0xf8000000);
    rtl_mdelay(10);

    reg_eac = rtl_r32(REG_RX_POWER_AFTER_IQK_A_2);
    reg_ec4 = rtl_r32(REG_RX_POWER_BEFORE_IQK_B_2);
    reg_ecc = rtl_r32(REG_RX_POWER_AFTER_IQK_B_2);

    rtl_w32(REG_FPGA0_IQK, 0x00000000);
    rtl_write_rfreg(RF_PATH_B, RF6052_REG_GAIN_CCA, 0x180);

    if (!(reg_eac & BIT(30)) &&
        ((reg_ec4 & 0x03ff0000) != 0x01320000) &&
        ((reg_ecc & 0x03ff0000) != 0x00360000))
        result |= 0x02;
    return result;
}

/* rtl8192eu_phy_iqcalibrate: обёртка с сохранением/восстановлением ADDA */
static void rtl_phy_iq_calibrate(void) {
    static const u32 adda_regs[16] = {
        REG_FPGA0_XCD_SWITCH_CTRL, REG_BLUETOOTH,
        REG_RX_WAIT_CCA, REG_TX_CCK_RFON,
        REG_TX_CCK_BBON, REG_TX_OFDM_RFON,
        REG_TX_OFDM_BBON, REG_TX_TO_RX,
        REG_TX_TO_TX, REG_RX_CCK,
        REG_RX_OFDM, REG_RX_WAIT_RIFS,
        REG_RX_TO_RX, REG_STANDBY,
        REG_SLEEP, REG_PMPD_ANAEN
    };
    static const u32 iqk_mac_regs[4] = {
        REG_TXPAUSE, REG_BEACON_CTRL,
        REG_BEACON_CTRL_1, REG_GPIO_MUXCFG
    };
    static const u32 iqk_bb_regs[9] = {
        REG_OFDM0_TRX_PATH_ENABLE, REG_OFDM0_TR_MUX_PAR,
        REG_FPGA0_XCD_RF_SW_CTRL, REG_CONFIG_ANT_A, REG_CONFIG_ANT_B,
        REG_FPGA0_XAB_RF_SW_CTRL, REG_FPGA0_XA_RF_INT_OE,
        REG_FPGA0_XB_RF_INT_OE, REG_CCK0_AFE_SETTING
    };
    u32 adda_backup[16], mac_backup[4], bb_backup[9];
    u32 val32;
    int path_a_ok = 0, path_b_ok = 0;
    int retry = 2;
    u8 xa_agc = (u8)(rtl_r32(REG_OFDM0_XA_AGC_CORE1) & 0xff);
    u8 xb_agc = (u8)(rtl_r32(REG_OFDM0_XB_AGC_CORE1) & 0xff);

    /* сохранить параметры */
    for (int i = 0; i < 16; i++) adda_backup[i] = rtl_r32(adda_regs[i]);
    for (int i = 0; i < 3; i++) mac_backup[i] = rtl_r8(iqk_mac_regs[i]);
    mac_backup[3] = rtl_r32(iqk_mac_regs[3]);
    for (int i = 0; i < 9; i++) bb_backup[i] = rtl_r32(iqk_bb_regs[i]);

    /* path ADDA on (2T: 0x0fc01616) */
    rtl_w32(adda_regs[0], 0x0fc01616);
    for (int i = 1; i < 16; i++) rtl_w32(adda_regs[i], 0x0fc01616);

    /* MAC calibration */
    rtl_w8(iqk_mac_regs[0], 0x3f);
    for (int i = 1; i < 3; i++)
        rtl_w8(iqk_mac_regs[i], (u8)(mac_backup[i] & ~BIT(3)));
    rtl_w8(iqk_mac_regs[3], (u8)(mac_backup[3] & ~BIT(5)));

    val32 = rtl_r32(REG_CCK0_AFE_SETTING);
    val32 |= 0x0f000000;
    rtl_w32(REG_CCK0_AFE_SETTING, val32);

    rtl_w32(REG_OFDM0_TRX_PATH_ENABLE, 0x03a05600);
    rtl_w32(REG_OFDM0_TR_MUX_PAR, 0x000800e4);
    rtl_w32(REG_FPGA0_XCD_RF_SW_CTRL, 0x22208200);

    val32 = rtl_r32(REG_FPGA0_XAB_RF_SW_CTRL);
    val32 |= (FPGA0_RF_PAPE | (FPGA0_RF_PAPE << FPGA0_RF_BD_CTRL_SHIFT));
    rtl_w32(REG_FPGA0_XAB_RF_SW_CTRL, val32);

    val32 = rtl_r32(REG_FPGA0_XA_RF_INT_OE);
    val32 |= BIT(10);
    rtl_w32(REG_FPGA0_XA_RF_INT_OE, val32);
    val32 = rtl_r32(REG_FPGA0_XB_RF_INT_OE);
    val32 |= BIT(10);
    rtl_w32(REG_FPGA0_XB_RF_INT_OE, val32);

    rtl_w32(REG_FPGA0_IQK, 0x80800000);
    rtl_w32(REG_TX_IQK, 0x01007c00);
    rtl_w32(REG_RX_IQK, 0x01004800);

    for (int i = 0; i < retry && !path_a_ok; i++)
        path_a_ok = rtl_iqk_path_a();
    for (int i = 0; i < retry; i++) {
        if (rtl_rx_iqk_path_a() == 0x03) { path_a_ok = 0x03; break; }
    }
    if (path_a_ok) wifi_log("IQK: путь A ok (%x)", path_a_ok);
    else           wifi_log("IQK: путь A НЕ прошёл (RX работает, но хуже)");

    if (rtl.tx_paths > 1) {
        /* Path A into standby */
        rtl_w32(REG_FPGA0_IQK, 0x00000000);
        rtl_write_rfreg(RF_PATH_A, RF6052_REG_AC, 0x10000);
        rtl_w32(REG_FPGA0_IQK, 0x80800000);

        for (int i = 0; i < retry && !path_b_ok; i++)
            path_b_ok = rtl_iqk_path_b();
        for (int i = 0; i < retry; i++) {
            if (rtl_rx_iqk_path_b() == 0x03) { path_b_ok = 0x03; break; }
        }
        if (path_b_ok) wifi_log("IQK: путь B ok (%x)", path_b_ok);
        else           wifi_log("IQK: путь B не прошёл");
    }

    rtl_w32(REG_FPGA0_IQK, 0x00000000);

    /* восстановить параметры */
    for (int i = 0; i < 16; i++) rtl_w32(adda_regs[i], adda_backup[i]);
    for (int i = 0; i < 3; i++) rtl_w8(iqk_mac_regs[i], (u8)mac_backup[i]);
    rtl_w32(iqk_mac_regs[3], mac_backup[3]);
    for (int i = 0; i < 9; i++) rtl_w32(iqk_bb_regs[i], bb_backup[i]);

    /* Restore RX initial gain */
    val32 = rtl_r32(REG_OFDM0_XA_AGC_CORE1);
    val32 &= 0xffffff00;
    rtl_w32(REG_OFDM0_XA_AGC_CORE1, val32 | 0x50);
    rtl_w32(REG_OFDM0_XA_AGC_CORE1, val32 | xa_agc);

    if (rtl.tx_paths > 1) {
        val32 = rtl_r32(REG_OFDM0_XB_AGC_CORE1);
        val32 &= 0xffffff00;
        rtl_w32(REG_OFDM0_XB_AGC_CORE1, val32 | 0x50);
        rtl_w32(REG_OFDM0_XB_AGC_CORE1, val32 | xb_agc);
    }

    /* Load 0xe30 IQC default value */
    rtl_w32(REG_TX_IQK_TONE_A, 0x01008c00);
    rtl_w32(REG_RX_IQK_TONE_A, 0x01008c00);
}

/* ================= смена канала (gen2, 20 МГц) ================= */

static int rtl_set_channel(int ch_idx) {
    if (ch_idx < 0 || ch_idx >= WC_NUM_CHANNELS) return 0;
    int channel = ch_idx + 1;

    u16 rf_mode_bw = rtl_r16(REG_WMAC_TRXPTCL_CTL);
    rf_mode_bw &= (u16)~WMAC_TRXPTCL_CTL_BW_MASK;
    rf_mode_bw |= WMAC_TRXPTCL_CTL_BW_20;
    rtl_w16(REG_WMAC_TRXPTCL_CTL, rf_mode_bw);

    u32 val32 = rtl_r32(REG_FPGA0_RF_MODE);
    val32 &= ~FPGA_RF_MODE;
    rtl_w32(REG_FPGA0_RF_MODE, val32);

    val32 = rtl_r32(REG_FPGA1_RF_MODE);
    val32 &= ~FPGA_RF_MODE;
    rtl_w32(REG_FPGA1_RF_MODE, val32);

    val32 = rtl_r32(REG_OFDM0_TX_PSDO_NOISE_WEIGHT);
    val32 &= ~(BIT(30) | BIT(31));
    rtl_w32(REG_OFDM0_TX_PSDO_NOISE_WEIGHT, val32);

    for (int p = 0; p < 2; p++) {
        val32 = rtl_read_rfreg(p, RF6052_REG_MODE_AG);
        val32 &= ~MODE_AG_CHANNEL_MASK;
        val32 |= (u32)channel;
        rtl_write_rfreg(p, RF6052_REG_MODE_AG, val32);
    }

    rtl_w8(REG_DATA_SUBCHANNEL, 0);

    /* SIFS: HT (0x0e) */
    rtl_w8(REG_SIFS_CCK + 1, 0x0e);
    rtl_w8(REG_SIFS_OFDM + 1, 0x0e);
    rtl_w16(REG_R2T_SIFS, 0x0808);
    rtl_w16(REG_T2T_SIFS, 0x0a0a);

    for (int p = 0; p < 2; p++) {
        val32 = rtl_read_rfreg(p, RF6052_REG_MODE_AG);
        val32 &= ~MODE_AG_BW_MASK;
        val32 |= MODE_AG_BW_20MHZ_8723B;
        rtl_write_rfreg(p, RF6052_REG_MODE_AG, val32);
    }

    rtl_set_tx_power(channel, 0);
    rtl.channel = channel;
    return 1;
}

/* ================= полный init (rtl8xxxu_init_device для 8192E) ================= */

static int rtl_init_device(void) {
    u8 val8;
    u16 val16;
    u32 val32;

    /* power_on (needs_full_init — всегда полный) */
    if (rtl_power_on()) return -1;

    rtl_init_queue_reserved_page();

    if (rtl_init_queue_priority()) {
        wifi_log("неожиданная конфигурация OUT-эндпоинтов");
        return -1;
    }

    /* RX page boundary */
    rtl_w16(REG_TRXFF_BNDY + 2, 0x3cff);

    if (rtl_download_firmware()) return -1;
    if (rtl_start_firmware()) return -1;

    if (rtl_init_mac()) return -1;

    rtl_init_phy_bb();

    if (rtl_init_phy_rf()) return -1;

    rtl_enable_rf();   /* PWR_DATA/RFE/антенный коммутатор (8192e_enable_rf) */

    /* RFSW Control — для 8192E НЕ пишем REG_FPGA0_TX_INFO (эталон) */
    val32 = FPGA0_RF_TRSW | FPGA0_RF_TRSWB | FPGA0_RF_ANTSW |
            FPGA0_RF_ANTSWB |
            ((FPGA0_RF_ANTSW | FPGA0_RF_ANTSWB) << FPGA0_RF_BD_CTRL_SHIFT);
    val32 |= (FPGA0_RF_PAPE | (FPGA0_RF_PAPE << FPGA0_RF_BD_CTRL_SHIFT));
    rtl_w32(REG_FPGA0_XAB_RF_SW_CTRL, val32);
    /* 0x860/0x864 — тоже пропускаются для 8192E */

    /* TX buffer boundary */
    val8 = (u8)(rtl.total_page_num + 1);
    rtl_w8(REG_TXPKTBUF_BCNQ_BDNY, val8);
    rtl_w8(REG_TXPKTBUF_MGQ_BDNY, val8);
    rtl_w8(REG_TXPKTBUF_WMAC_LBK_BF_HD, val8);
    rtl_w8(REG_TRXFF_BNDY, val8);
    rtl_w8(REG_TDECTRL + 1, val8);
    /* PBP для 8192E НЕ пишется (эталон) */

    if (rtl_llt_init()) return -1;
    rtl_usb_quirks();

    /* Unit in 8 bytes: RX PHY status */
    rtl_w8(REG_RX_DRVINFO_SZ, 4);

    /* 8192E: прерывания выключены (polling) */
    rtl_w32(REG_HIMR0, 0x00);
    rtl_w32(REG_HIMR1, 0x00);

    /* MAC адрес + режим станции */
    for (int i = 0; i < 6; i++)
        rtl_w8(REG_MACID + i, rtl.mac[i]);
    val8 = rtl_r8(REG_MSR);
    val8 &= (u8)~MSR_LINKTYPE_MASK;
    val8 |= MSR_LINKTYPE_STATION;
    rtl_w8(REG_MSR, val8);

    /* WMAC: принимать физ. матч/mcast/bcast/mgmt, PHY-статус */
    val32 = RCR_ACCEPT_PHYS_MATCH | RCR_ACCEPT_MCAST | RCR_ACCEPT_BCAST |
            RCR_ACCEPT_MGMT_FRAME | RCR_HTC_LOC_CTRL |
            RCR_APPEND_PHYSTAT | RCR_APPEND_ICV | RCR_APPEND_MIC;
    rtl_w32(REG_RCR, val32);

    /* multicast — всё (init_reg_rxfltmap не задан для 8192eu) */
    rtl_w32(REG_MAR, 0xffffffff);
    rtl_w32(REG_MAR + 4, 0xffffffff);

    /* Init adaptive controls: RRSR — CCK 1M для ответов */
    val32 = rtl_r32(REG_RESPONSE_RATE_SET);
    val32 &= ~RESPONSE_RATE_BITMAP_ALL;
    val32 |= RESPONSE_RATE_RRSR_CCK_ONLY_1M;
    rtl_w32(REG_RESPONSE_RATE_SET, val32);

    /* CCK = 0x0a, OFDM = 0x10 */
    val16 = (u16)(((0x10 << SPEC_SIFS_CCK_SHIFT) & SPEC_SIFS_CCK_MASK) |
                  ((0x10 << SPEC_SIFS_OFDM_SHIFT) & SPEC_SIFS_OFDM_MASK));
    rtl_w16(REG_SPEC_SIFS, val16);
    val16 = (u16)(((0x30 << RETRY_LIMIT_SHORT_SHIFT) & RETRY_LIMIT_SHORT_MASK) |
                  ((0x30 << RETRY_LIMIT_LONG_SHIFT) & RETRY_LIMIT_LONG_MASK));
    rtl_w16(REG_RETRY_LIMIT, val16);
    val16 = (u16)(((0x0a << SPEC_SIFS_CCK_SHIFT) & SPEC_SIFS_CCK_MASK) |
                  ((0x10 << SPEC_SIFS_OFDM_SHIFT) & SPEC_SIFS_OFDM_MASK));
    rtl_w16(REG_SPEC_SIFS, val16);

    /* EDCA */
    rtl_w16(REG_MAC_SPEC_SIFS, 0x100a);
    rtl_w16(REG_SIFS_CCK, 0x100a);
    rtl_w16(REG_SIFS_OFDM, 0x100a);
    rtl_w32(REG_EDCA_BE_PARAM, 0x005ea42b);
    rtl_w32(REG_EDCA_BK_PARAM, 0x0000a44f);
    rtl_w32(REG_EDCA_VI_PARAM, 0x005ea324);
    rtl_w32(REG_EDCA_VO_PARAM, 0x002fa226);

    /* rate fallback retry */
    rtl_w32(REG_DARFRC, 0x00000000);
    rtl_w32(REG_DARFRC + 4, 0x10080404);
    rtl_w32(REG_RARFRC, 0x04030201);
    rtl_w32(REG_RARFRC + 4, 0x08070605);

    val8 = rtl_r8(REG_FWHW_TXQ_CTRL);
    val8 |= FWHW_TXQ_CTRL_AMPDU_RETRY;
    rtl_w8(REG_FWHW_TXQ_CTRL, val8);

    rtl_w8(REG_ACKTO, 0x40);

    /* beacon params (STA — не шлём, но регистры инициализируем) */
    val16 = (u16)(BEACON_DISABLE_TSF_UPDATE | (BEACON_DISABLE_TSF_UPDATE << 8));
    rtl_w16(REG_BEACON_CTRL, val16);
    rtl_w16(REG_TBTT_PROHIBIT, 0x6404);
    rtl_w8(REG_DRIVER_EARLY_INT, DRIVER_EARLY_INT_TIME);
    rtl_w8(REG_BEACON_DMA_TIME, BEACON_DMA_ATIME_INT_TIME);
    rtl_w16(REG_BEACON_TCFG, 0x660F);

    /* CCK + OFDM включены */
    val32 = rtl_r32(REG_FPGA0_RF_MODE);
    val32 |= (FPGA_RF_MODE_CCK | FPGA_RF_MODE_OFDM);
    rtl_w32(REG_FPGA0_RF_MODE, val32);

    /* Invalidate all CAM entries */
    rtl_w32(REG_CAM_CMD, CAM_CMD_POLLING | BIT(30));

    /* мощность канала 6, 20 МГц */
    rtl_set_tx_power(1, 0);

    rtl_w8(REG_HWSEQ_CTRL, 0xff);
    rtl_w32(REG_BAR_MODE_CTRL, 0x0201ffff);
    rtl_w16(REG_FAST_EDCA_CTRL, 0);

    /* 8192E: 0x4c6[3] RTS BW = Data BW; reset USB mode switch */
    val8 = rtl_r8(REG_QUEUE_CTRL);
    val8 &= (u8)~BIT(3);
    rtl_w8(REG_QUEUE_CTRL, val8);
    rtl_w8(REG_ACLK_MON, 0x00);

    rtl_lc_calibrate();
    rtl_phy_iq_calibrate();

    /* thermal meter (gen2) */
    rtl_write_rfreg(RF_PATH_A, RF6052_REG_T_METER_8723B, 0x37cf8);

    /* NAV_UPPER 30000us */
    rtl_w8(REG_NAV_UPPER, (u8)((30000 + NAV_UPPER_UNIT - 1) / NAV_UPPER_UNIT));

    rtl_w8(REG_USB_HRPWM, 0x00);

    /* ack для переданных mgmt-кадров (эталон, конец init_device) */
    val32 = rtl_r32(REG_FWHW_TXQ_CTRL);
    val32 |= FWHW_TXQ_CTRL_XMIT_MGMT_ACK;
    rtl_w32(REG_FWHW_TXQ_CTRL, val32);

    /* СЕССИЯ 42, КРИТИЧНО: «Fix LDPC rx hang issue» из эталона
     * (rtl8xxxu_init_device, ветка RTL8192E). Подъём LDO 1.2В и запас
     * AFE — БЕЗ НЕГО RX у RTL8192E/8192EU ВИСНЕТ: сначала кадры идут,
     * потом RX-движок замолкает навсегда (bulk-in не отвечает, EP0 жив)
     * — ровно наш симптом «первый скан виден, дальше 0 кадров».
     * Рег. запись идёт ПОСЛЕ LC/IQ калибровок — как в эталоне. */
    rtl_w8(REG_8192E_LDOV12_CTRL, 0x75);
    val32 = rtl_r32(REG_AFE_MISC);
    val32 &= 0xfff00fff;
    val32 |= 0x0007e000;
    rtl_w32(REG_AFE_MISC, val32);

    /* 0x824[9] == 0x82C[9] обязаны совпадать, иначе некорректный CCK RSSI
     * (эталон: «those registers setting should be equal») */
    {
        u32 xa = rtl_r32(REG_FPGA0_XA_HSSI_PARM2);
        int cck_type = (int)((xa >> 9) & 1u);
        u32 xb = rtl_r32(REG_FPGA0_XB_HSSI_PARM2);
        if (((xb >> 9) & 1u) != (u32)cck_type) {
            if (cck_type) xb |= FPGA0_HSSI_PARM2_CCK_HIGH_PWR;
            else          xb &= ~(u32)FPGA0_HSSI_PARM2_CCK_HIGH_PWR;
            rtl_w32(REG_FPGA0_XB_HSSI_PARM2, xb);
        }
        val32 = rtl_r32(REG_AGC_RPT);
        if (cck_type) val32 |= AGC_RPT_CCK;
        else          val32 &= ~(u32)AGC_RPT_CCK;
        rtl_w32(REG_AGC_RPT, val32);
    }

    rtl.channel = 0;
    return 0;
}

/* ================= TX: дескриптор v2 (40 б) + bulk OUT ================= */

/* rtl8xxxu_calc_tx_desc_csum: XOR по 16-битным словам первых 32 байт */
static u16 rtl_tx_desc_csum(u8 *desc) {
    u16 csum = 0;
    desc[30] = 0; desc[31] = 0;        /* поле csum (смещение 30, le16) */
    u16 *p = (u16 *)desc;
    for (int i = 0; i < 16; i++)
        csum ^= p[i];
    /* csum |= csum (у эталона старшие биты зарезервированы под флаги) */
    return csum;
}

/* выбор очереди + OUT-эндпоинт (rtl8xxxu_queue_select + pipe_out) */
static int rtl_queue_ep(u16 fc, int noack_unused, int *out_queue) {
    (void)noack_unused;
    u8 type = (u8)((fc >> 2) & 0x3);
    u8 subtype = (u8)((fc >> 4) & 0xF);
    int q;
    int prio;    /* индекс в out_ep[]: 0=HIGH, 1=NORMAL, 2=LOW */
    if (type == 0 && subtype == 8) {          /* beacon (не шлём в STA) */
        q = TXDESC_QUEUE_BEACON;  prio = 0;
    } else if (type == 0) {                   /* management */
        q = TXDESC_QUEUE_MGNT;    prio = 0;
    } else {
        q = TXDESC_QUEUE_BE;      prio = 2;    /* данные — BE/BK очередь */
    }
    if (rtl.ep_tx_count <= 0) return -1;
    if (prio >= rtl.ep_tx_count) prio = 0;    /* 1 EP: всё в первый */
    *out_queue = q;
    return rtl.out_ep[prio];
}

/* логический рейтинг -> код DESC_RATE_*
 * [W-TXRATE] добавлен OFDM 6 (точки с b-рейтами off не слышат CCK) */
static u8 rtl_rate_hw(wc_rate_t r) {
    static const u8 map[5] = { DESC_RATE_1M, DESC_RATE_2M,
                               DESC_RATE_5_5M, DESC_RATE_11M, DESC_RATE_6M };
    return ((unsigned)r <= WCRATE_6M) ? map[(int)r] : DESC_RATE_1M;
}

static int rtl_tx_frame(const u8 *frame, u32 len, wc_rate_t rate,
                        int tries, int noack, int keyidx) {
    (void)tries; (void)noack;   /* ретраи — прошивка */
    if (!rtl.attached || !rtl.ready) return 0;
    if (!rtl.txbuf) return 0;
    if (len > RTL_MAX_TXBUF) return 0;
    if (len < 2) return 0;

    int q, ep = rtl_queue_ep((u16)(frame[0] | (frame[1] << 8)), noack, &q);
    if (ep <= 0) return 0;

    s_lock(&rtl.tx_lock);
    u8 *d = rtl.txbuf;                 /* дескриптор 40 б */
    u8 *f = rtl.txbuf + 40;            /* кадр */
    memset(d, 0, 40);
    memcpy(f, frame, len);

    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    u8 type = (u8)((fc >> 2) & 0x3);
    /* СЕССИЯ 51: EAPOL-кадры (LLC/SNAP + ethertype 888E) — на
     * ФИКСИРОВАННОМ рейте драйвера (11M), как management: firmware
     * rate-adaptation стартует с высокого рейта и первые M2/M4
     * терялись (в поле — 11-13 ретрансляций M1 до первого принятого
     * M2; 11M — базовый, принимается всегда). */
    int is_eapol = (type == 2 && len >= 32 &&
                    frame[24] == 0xAA && frame[25] == 0xAA &&
                    frame[26] == 0x03 && frame[27] == 0x00 &&
                    frame[28] == 0x00 && frame[29] == 0x00 &&
                    frame[30] == 0x88 && frame[31] == 0x8E);

    /* txdw0 (байт 3): OWN | FIRST | LAST | BROADMULTICAST */
    d[3] = (u8)(TXDESC_OWN | TXDESC_FIRST_SEGMENT | TXDESC_LAST_SEGMENT);
    if (frame[4] & 1)                  /* DA mcast/bcast */
        d[3] |= (u8)TXDESC_BROADMULTICAST;

    /* pkt_size (le16, байты 0-1), pkt_offset (байт 2) = 40 */
    d[0] = (u8)(len & 0xFF);
    d[1] = (u8)((len >> 8) & 0xFF);
    d[2] = 40;

    /* txdw1 (le32 @4): queue_sel << 8 | sec type | macid */
    u32 txdw1 = ((u32)q << TXDESC_QUEUE_SHIFT);
    if (keyidx >= 0) {
        /* sec в txdw1 (биты 23:22): AES=11, RC4/TKIP=01 (эталон).
         * СЕССИЯ 52: keyidx>=0 = «шифровать парным» (data, у нас всегда
         * PTK после 802.11i-правила) — алгоритм по парному шифру;
         * keyidx==-1 = EAPOL/mgmt, всегда открытым текстом. */
        if (rtl_ptk_is_tkip)
            txdw1 |= TXDESC_SEC_RC4;       /* TKIP-пара */
        else
            txdw1 |= TXDESC_SEC_AES;       /* CCMP-пара */
    }
    d[4] = (u8)(txdw1 & 0xFF);
    d[5] = (u8)((txdw1 >> 8) & 0xFF);
    d[6] = (u8)((txdw1 >> 16) & 0xFF);
    d[7] = (u8)((txdw1 >> 24) & 0xFF);

    /* txdw2 (le32 @8): AGG_BREAK (без AMPDU) */
    u32 txdw2 = TXDESC40_AGG_BREAK;
    d[8]  = (u8)(txdw2 & 0xFF);
    d[9]  = (u8)((txdw2 >> 8) & 0xFF);
    d[10] = (u8)((txdw2 >> 16) & 0xFF);
    d[11] = (u8)((txdw2 >> 24) & 0xFF);

    /* txdw3 (le32 @12): seq (кадр f[22]/f[23]), USE_DRIVER_RATE для mgmt */
    u16 sn = (u16)((frame[22] >> 4) | (frame[23] << 4));
    u32 txdw3 = ((u32)sn << TXDESC40_SEQ_SHIFT) & TXDESC40_SEQ_MASK;
    u32 txdw4 = 0;
    if (type == 0 || is_eapol) {
        txdw4 |= (u32)rtl_rate_hw(rate);            /* mgmt/EAPOL: фикс-рейт */
        txdw3 |= TXDESC40_USE_DRIVER_RATE;
        txdw4 |= (6u << TXDESC40_RETRY_LIMIT_SHIFT) |
                 TXDESC40_RETRY_LIMIT_ENABLE;
    } else {
        txdw4 |= 0x1f << TXDESC40_DATA_RATE_FB_SHIFT;  /* RA прошивки */
    }
    d[12] = (u8)(txdw3 & 0xFF);
    d[13] = (u8)((txdw3 >> 8) & 0xFF);
    d[14] = (u8)((txdw3 >> 16) & 0xFF);
    d[15] = (u8)((txdw3 >> 24) & 0xFF);
    d[16] = (u8)(txdw4 & 0xFF);
    d[17] = (u8)((txdw4 >> 8) & 0xFF);
    d[18] = (u8)((txdw4 >> 16) & 0xFF);
    d[19] = (u8)((txdw4 >> 24) & 0xFF);
    /* txdw5..7 (@20..27) = 0; txdw8 (@32) = 0 (seq ставим сами);
     * txdw9 (@36): seq (по v2 — тут тоже дублируется у эталона) */
    u32 txdw9 = ((u32)sn << TXDESC40_SEQ_SHIFT) & TXDESC40_SEQ_MASK;
    d[36] = (u8)(txdw9 & 0xFF);
    d[37] = (u8)((txdw9 >> 8) & 0xFF);
    d[38] = (u8)((txdw9 >> 16) & 0xFF);
    d[39] = (u8)((txdw9 >> 24) & 0xFF);

    /* чексумма по первым 32 байтам */
    u16 csum = rtl_tx_desc_csum(d);
    d[30] = (u8)(csum & 0xFF);
    d[31] = (u8)((csum >> 8) & 0xFF);

    int r = usb_ehci_bulk_xfer_to(rtl.addr, ep, rtl.ep_out_size, 0,
                                  rtl.txbuf, (int)len + 40, 500000);
    s_unlock(&rtl.tx_lock);
    return (r == (int)(len + 40)) ? 1 : 0;
}

/* ================= RX: bulk IN + разбор rxdesc24 ================= */

/* rtl8xxxu_rxdesc24 — bitfields как в эталоне (x86 LE) */
typedef struct __attribute__((packed)) {
    u32 pktlen:14;
    u32 crc32:1;
    u32 icverr:1;
    u32 drvinfo_sz:4;
    u32 security:3;
    u32 qos:1;
    u32 shift:2;
    u32 phy_stats:1;
    u32 swdec:1;
    u32 ls:1;
    u32 fs:1;
    u32 eor:1;
    u32 own:1;

    u32 macid:7;
    u32 dummy1_0:1;
    u32 tid:4;
    u32 dummy1_1:1;
    u32 amsdu:1;
    u32 rxid_match:1;
    u32 paggr:1;
    u32 a1fit:4;
    u32 chkerr:1;
    u32 ipver:1;
    u32 tcpudp:1;
    u32 chkvld:1;
    u32 pam:1;
    u32 pwr:1;
    u32 more_data:1;
    u32 more_frag:1;
    u32 type:2;
    u32 mc:1;
    u32 bc:1;

    u32 seq:12;
    u32 frag:4;
    u32 rx_is_qos:1;
    u32 dummy2_0:1;
    u32 wlanhd_iv_len:6;
    u32 dummy2_1:4;
    u32 rpt_sel:1;
    u32 dummy2_2:3;

    u32 rxmcs:7;
    u32 dummy3_0:3;
    u32 htc:1;
    u32 eosp:1;
    u32 bssidfit:2;
    u32 dummy3_1:2;
    u32 usb_agg_pktnum:8;
    u32 dummy3_2:5;
    u32 pattern_match:1;
    u32 unicast_match:1;
    u32 magic_match:1;

    u32 splcp:1;
    u32 ldcp:1;
    u32 stbc:1;
    u32 dummy4_0:1;
    u32 bw:2;
    u32 dummy4_1:26;

    u32 tsfl;              /* timestamp (младшие 32 б) */
} rtl_rxdesc24_t;   /* 24 байта */

/* struct rtl8723au_phy_stats (поля, нужные для RSSI) */
typedef struct __attribute__((packed)) {
    u8 path_agc[2];        /* {gain:7, trsw:1} x2 */
    u8 ch_corr[2];
    u8 cck_sig_qual_ofdm_pwdb_all;
    u8 cck_agc_rpt_ofdm_cfosho_a;
    u8 cck_rpt_b_ofdm_cfosho_b;
    u8 reserved_1;
    u8 noise_power_db_msb;
    i8 path_cfotail[2];
    u8 pcts_mask[2];
    i8 stream_rxevm[2];
    u8 path_rxsnr[2];
    u8 noise_power_db_lsb;
    u8 reserved_2[3];
    u8 stream_csi[2];
    u8 stream_target_csi[2];
    i8 sig_evm;
    u8 reserved_3;
    u8 agc_tail;           /* биты sgi_en и пр. — не нужны */
} rtl_phy_stats_t;

static const i8 rtl_lna_gain_table0[8] = { 15, 9, -10, -21, -23, -27, -43, -44 };

static int rtl_cck_rssi(const rtl_phy_stats_t *ph) {
    u8 cck_agc_rpt = ph->cck_agc_rpt_ofdm_cfosho_a;
    u8 lna_idx = (u8)((cck_agc_rpt >> 5) & 0x7);
    u8 vga_idx = (u8)(cck_agc_rpt & 0x1f);
    i8 lna_gain = rtl_lna_gain_table0[lna_idx & 7];
    return (int)(lna_gain - (i8)(2 * vga_idx));
}

/* разбор одного URB (цепочка пакетов по 8-байтному выравниванию) */
static void rtl_parse_rx(u8 *buf, int urb_len) {
    int off = 0;
    while (urb_len - off >= (int)sizeof(rtl_rxdesc24_t)) {
        rtl_rxdesc24_t *rx = (rtl_rxdesc24_t *)(buf + off);
        if (rx->pktlen == 0 || rx->pktlen > 2400) break;
        int drvinfo_sz = rx->drvinfo_sz * 8;
        int desc_shift = rx->shift;
        int pkt_offset = (int)((rx->pktlen + drvinfo_sz + desc_shift +
                                sizeof(rtl_rxdesc24_t) + 7) & ~7);
        if (rx->rpt_sel) {
            /* C2H — прошивочные отчёты, игнорируем */
        } else if (rx->crc32 || rx->icverr) {
            wc_rx_err(1);
        } else {
            int rssi;
            const rtl_phy_stats_t *ph =
                (const rtl_phy_stats_t *)(buf + off + sizeof(rtl_rxdesc24_t));
            if (rx->rxmcs < DESC_RATE_6M)
                rssi = rtl_cck_rssi(ph);
            else
                rssi = (int)((ph->cck_sig_qual_ofdm_pwdb_all >> 1) - 110);
            if (rssi > 0) rssi = -40;      /* защита от мусора PHY */
            const u8 *frame = buf + off + sizeof(rtl_rxdesc24_t) +
                              drvinfo_sz + desc_shift;
            wc_rx_frame(frame, (int)rx->pktlen, (i8)rssi);
        }
        off += pkt_offset;
    }
}

/* Ватчдог клина (сессия 41, вынесен из rtl_poll_rx): если подряд не
 * отвечают регистровые операции (EP0 молчит, каждый таймаут 200 мс)
 * ИЛИ стабильно мёртв RX (rx_fail_streak >= 3 форсит io_fail) — адаптер
 * клин. Помечаем мёртвым: главный цикл переспавнит wifi-задачу
 * (present=1, ready=0), та сбросит ПОРТ и переперечислит, потом полный
 * bring-up. Вызывается из КАЖДОЙ ветки rtl_poll_rx — раньше форс из
 * -2-ветки терялся (ранний return до проверки). */
static void rtl_wedge_check(void) {
    if (rtl.io_fail < 8) return;
    rtl.io_fail = 0;
    rtl.rx_fail_streak = 0;
    wifi_log("RTL: адаптер перестал отвечать по USB (регистры/RX) — "
             "сброс порта и полный bring-up");
    usb_ehci_rx_disarm();
    rtl.ready = 0;
    rtl.wedged = 1;
    wc_set_state(1, 0);
}

static void rtl_poll_rx(void) {
    if (!rtl.attached || !rtl.ready || !rtl.rxbuf) return;
    /* СЕССИЯ 40: RX на ПОСТОЯННОЙ очереди EHCI — трансфер живёт в
     * контроллере, пока не придут данные; таймаутов и абортов больше
     * НЕТ. Раньше каждый пустой опрос через 25 мс вырывал QH из
     * async-кольца с qTD ещё ACTIVE — abort на середине DMA во время
     * скана клинил прошивку (EP0+EP4 молчали до переподключения).
     * Гейт снижен 20 -> 2 мс: опрос — чтение токена qTD, цена нулевая. */
    u32 now = timer_ticks();
    if ((int)(now - rtl.poll_gate) < 2) return;
    rtl.poll_gate = now;

    if (usb_ehci_rx_arm(rtl.addr, rtl.ep_in, rtl.ep_in_size,
                        rtl.rxbuf, RTL_RXBUF_SZ) != 1)
        return;                          /* очередь не встала — на следующем проходе */

    int n = usb_ehci_rx_poll();
    if (n == -1) {                       /* данных ещё нет — очередь ждёт сама */
        rtl_wedge_check();               /* регистровый ватчдог не спим */
        return;
    }
    if (n == -3) {
        /* СЕССИЯ 42: 3 с тишины при живом EP0 (qTD так и не завершился,
         * ошибок шины НЕТ) — тихий канал, ШТАТНАЯ ситуация. Очередь уже
         * снята и пересоберётся на следующем проходе; эскалация сюда
         * попасть не должна, счётчик проводных сбоев сбрасываем. */
        rtl.rx_fail_streak = 0;
        return;
    }
    if (n == -2) {
        /* СЕССИЯ 41/42: RX-очередь сорвалась ОШИБКОЙ НА ШИНЕ
         * (XactErr/halt/DBE — устройство не отвечало на IN, 3 попытки).
         * СЕССИЯ 42: счётчик больше НЕ сбрасывается при живом EP0 —
         * раньше это превращало глухой EP4 в бесконечный цикл
         * «clear_halt → rearm → XactErr» (шторм «EP0 жив» из лога) и
         * порты сбрасывались только через минуты, когда умирал и EP0.
         * Теперь: 1-й сбой — clear_halt + проба EP0 (может вылечить
         * STALL/рассинхрон toggle), 3 подряд — принудительный сброс
         * ПОРТА (лечение клина USB-движка чипа). */
        rtl.rx_fail_streak++;
        if (rtl.rx_fail_streak == 1) {
            int ch = usb_ehci_clear_halt(rtl.addr, rtl.ep_in | 0x80);
            int f0 = rtl.io_fail;
            (void)rtl_r16(REG_CR);                    /* проба чтения EP0 */
            int ep0_ok = (ch == 0) && (rtl.io_fail == f0);
            wifi_log("RTL: RX-очередь сорвалась (1/3) — clear_halt=%s, EP0 %s",
                     ch < 0 ? "сбой" : "ok", ep0_ok ? "жив" : "мёртв");
            if (!ep0_ok && rtl.ready)
                rtl.io_fail += 6;                     /* к ватчдогу сразу */
        } else {
            wifi_log("RTL: RX-очередь сорвалась (%d/3)", rtl.rx_fail_streak);
        }
        if (rtl.rx_fail_streak >= 3) {
            wifi_log("RTL: 3 проводных сбоя RX подряд — сброс порта и bring-up");
            rtl.io_fail = 8;                          /* путь ватчдога */
        }
        rtl_wedge_check();               /* форс сработает ЗДЕСЬ */
        return;                  /* переоружим на следующем проходе */
    }
    if (n > 0) {
        rtl_parse_rx(rtl.rxbuf, n);      /* n = РЕАЛЬНО принятые байты (остаток в token) */
        rtl.zero_scan_streak = 0;        /* RX жив — «глухие» сканы не в счёт */
    }
    rtl.rx_fail_streak = 0;              /* живой кадр/успех — счётчик сброшен */
    usb_ehci_rx_rearm();
    rtl_wedge_check();
}

/* ================= Security CAM (WPA2 ключи) ================= */

/* rtl8xxxu_cam_write: cipher_nibble: CCMP=4 (0x000FAC04), TKIP=2.
 * СЕССИЯ 51: group=1 → в ctrl добавляется BIT(6) (флаг группового
 * ключа, как в эталоне rtl8xxxu: `if (!PAIRWISE) ctrl |= BIT(6)`),
 * а MAC записи = BSSID (эталон кладёт bssid и для group-ключа).
 * Без этих битов железо не сопоставляет групповой ключ с входящими
 * TKIP-бродкастами точки — OFFER/ARP от точки терялись. */
#define CAM_CTRL_GROUP_KEY 0x40   /* BIT(6) ctrl-слова CAM */

static void rtl_cam_write(int keyidx, int cipher_nibble,
                          const u8 *key32, const u8 *mac, int group) {
    u32 addr = (u32)keyidx << CAM_CMD_KEY_SHIFT;
    u32 ctrl = ((u32)cipher_nibble << 2) | (u32)keyidx | CAM_WRITE_VALID;
    if (group) ctrl |= CAM_CTRL_GROUP_KEY;

    for (int j = 5; j >= 0; j--) {
        u32 val32;
        switch (j) {
        case 0:
            val32 = ctrl | ((u32)mac[0] << 16) | ((u32)mac[1] << 24);
            break;
        case 1:
            val32 = (u32)mac[2] | ((u32)mac[3] << 8) |
                    ((u32)mac[4] << 16) | ((u32)mac[5] << 24);
            break;
        default: {
            int i = (j - 2) << 2;
            val32 = (u32)key32[i] | ((u32)key32[i + 1] << 8) |
                    ((u32)key32[i + 2] << 16) | ((u32)key32[i + 3] << 24);
            break;
        }
        }
        rtl_w32(REG_CAM_WRITE, val32);
        rtl_w32(REG_CAM_CMD, CAM_CMD_POLLING | CAM_CMD_WRITE | (addr + (u32)j));
        rtl_udelay(100);
    }
}

static int rtl_keys_install(const u8 *bssid, const u8 *ptk, int ptk_is_tkip,
                            const u8 *gtk, int gtk_is_tkip, int gtk_keyid) {
    rtl_gtk_is_tkip = gtk_is_tkip;
    rtl_ptk_is_tkip = ptk_is_tkip;

    u16 val16 = rtl_r16(REG_CR);
    val16 |= CR_SECURITY_ENABLE;
    rtl_w16(REG_CR, val16);

    u8 val8 = SEC_CFG_TX_SEC_ENABLE | SEC_CFG_TXBC_USE_DEFKEY |
              SEC_CFG_RX_SEC_ENABLE | SEC_CFG_RXBC_USE_DEFKEY;
    val8 |= SEC_CFG_TX_USE_DEFKEY | SEC_CFG_RX_USE_DEFKEY;
    rtl_w8(REG_SECURITY_CFG, val8);

    /* PTK: СЕССИЯ 52 — CAM-ЯЧЕЙКА 0 (была 4 «по конвенции ядра»):
     * lookup ключа в 8192EU идёт по keyid из IV-заголовка кадра (SECCFG
     * *_USE_DEFKEY = «все ключи — default key»), а keyid парного ключа
     * ПО СТАНДАРТУ равен 0 (и в наших IV, и в кадрах точки). С PTK в
     * ячейке 4 железо брало ПУСТУЮ CAM[0] — весь юникаст TX/RX был
     * мёртв (бродкасты RX работали — keyid 1 = GTK в ячейке 1).
     * CCMP-пара: 16 б (TK). TKIP-пара (СЕССИЯ 48): 32 б
     * [TK][TX MIC][RX MIC] — у нас TX = ptk+56, RX = ptk+48. */
    static u8 ptk_cam[32];
    rtl_ptk_is_tkip = ptk_is_tkip;
    memcpy(ptk_cam, ptk + 32, 16);
    if (ptk_is_tkip) {
        memcpy(ptk_cam + 16, ptk + 56, 8);    /* наш TX MIC */
        memcpy(ptk_cam + 24, ptk + 48, 8);    /* наш RX MIC */
        rtl_cam_write(0, 2, ptk_cam, bssid, 0);
    } else {
        rtl_cam_write(0, 4, ptk_cam, bssid, 0);
    }

    /* GTK: keyid от точки; CCMP 16 б или TKIP 32 б
     * (GTK из KDE: [TK][RX MIC][TX MIC] — CAM ждёт [TK][TX][RX],
     * свап как в wpa_supplicant.install_gtk). MAC = BSSID + флаг
     * группы (BIT(6)) — по эталону rtl8xxxu.
     * СЕССИЯ 52: GTK keyid=0 конфликтует с PTK в CAM[0] (keyid-lookup,
     * одна ячейка на индекс). Реальные точки дают GTK keyid 1-3; при
     * 0 приоритет отдаём ПАРНОМУ ключу (юникаст важнее бродкастов). */
    static u8 gtk_cam[32];
    int gtk_idx = gtk_keyid & 3;
    if (gtk_idx == 0) {
        wifi_log("GTK keyid=0 — редкий случай: CAM[0] остаётся за PTK, "
                 "бродкасты точки могут не расшифровываться");
    } else if (gtk_is_tkip) {
        memcpy(gtk_cam, gtk, 16);                 /* TK */
        memcpy(gtk_cam + 16, gtk + 24, 8);        /* TX MIC */
        memcpy(gtk_cam + 24, gtk + 16, 8);        /* RX MIC */
        rtl_cam_write(gtk_idx, 2, gtk_cam, bssid, 1);
    } else {
        memcpy(gtk_cam, gtk, 16);
        rtl_cam_write(gtk_idx, 4, gtk_cam, bssid, 1);
    }
    if (gtk_idx == 0)
        wifi_log("CAM: PTK(cam0) + GTK НЕ записана (keyid=0)");
    else
        wifi_log("CAM: PTK(cam0) + GTK(cam%d, keyid=%d%s) записаны",
                 gtk_idx, gtk_keyid, gtk_is_tkip ? ", TKIP" : "");
    return 1;
}

static void rtl_keys_clear(void) {
    for (int idx = 0; idx < 4; idx++) {
        rtl_w32(REG_CAM_WRITE, 0x00000000);
        rtl_w32(REG_CAM_CMD, CAM_CMD_POLLING | CAM_CMD_WRITE |
                             ((u32)idx << CAM_CMD_KEY_SHIFT));
    }
    rtl_gtk_is_tkip = 0;
    rtl_ptk_is_tkip = 0;
}

/* ================= RX-фильтры (ops) ================= */

static void rtl_rx_filter_promisc(void) {
    /* скан/ждём всё: физ-матч + mcast + bcast + mgmt */
    u32 val32 = RCR_ACCEPT_PHYS_MATCH | RCR_ACCEPT_MCAST | RCR_ACCEPT_BCAST |
                RCR_ACCEPT_MGMT_FRAME | RCR_HTC_LOC_CTRL |
                RCR_APPEND_PHYSTAT | RCR_APPEND_ICV | RCR_APPEND_MIC;
    rtl_w32(REG_RCR, val32);
}

static void rtl_rx_filter_bss(void) {
    /* STA: тот же RCR — юникаст фильтруется по REG_MACID,
     * бродкасты нужны (DHCP/ARP), mgmt — маяки/AUTH/ASSOC */
    rtl_rx_filter_promisc();
}

/* [W-BSSID]: у RTL матчинг/фильтрация - в прошивке, отдельной записи
 * BSSID в регистры не требуется (заглушка). */
static void rtl_set_bssid(const u8 *bssid, u16 aid) {
    (void)bssid; (void)aid;
}

/* ================= ops + probe ================= */

static void rtl_full_reset(void);

/* СЕССИЯ 41: полный скан завершился с 0 кадров. У живого RX в среде
 * хотя бы с одной точкой такого не бывает (маяки идут каждые ~100 мс —
 * у пользователя 5-6 сетей на ch 5/7/8). Два «глухих» скана подряд
 * (без единого кадра между ними) = RX-движок мёртв — клин, лечится
 * только сбросом ПОРТА (см. rtl_wedge_check). Заодно пробуем EP0:
 * если мёртв и он — сообщаем об этом в лог. Возвращает 1 — просим
 * второй проход скана (даём RX ещё один шанс перед сбросом).
 *
 * [STREAK-FRAMES] (регрессия после фикса бага 9): [ATH-SCAN2] зовёт
 * сюда и сканы с ЖИВЫМ эфиром — мало маяков (<10), но кадры ЕСТЬ.
 * Раньше pass-2 в целом не работал (wc.pass застревал в 2), и этот
 * дефект был невидим: ЛЮБОЙ мало-маяковый скан наращивал серию
 * «глухих» — два домашних скана подряд = ложный сброс порта на
 * полностью исправном адаптере. Клин — это только 0 КАДРОВ ВООБЩЕ;
 * слышимый эфир серию обнуляет, а pass-2 (маяк мог уйти за край
 * окна 110 мс) всё равно разрешён. */
static int rtl_scan_retry(u32 frames_seen) {
    if (frames_seen > 0) {
        /* эфир слышен: RX жив, серии «глухих» нет — просто повтор */
        rtl.zero_scan_streak = 0;
        wifi_log("RTL: скан %u кадр(ов), маяков мало — второй проход (без счёта серии)",
                 (unsigned)frames_seen);
        return 1;
    }
    rtl.zero_scan_streak++;
    int f0 = rtl.io_fail;
    (void)rtl_r16(REG_CR);                       /* проба EP0 */
    int ep0_ok = (rtl.io_fail == f0);
    wifi_log("RTL: скан 0 кадров (подряд %d), EP0 %s",
             rtl.zero_scan_streak, ep0_ok ? "жив" : "мёртв");
    if (rtl.zero_scan_streak >= 2 || !ep0_ok) {
        wifi_log("RTL: RX глух при %s EP0 — сброс порта и полный bring-up",
                 ep0_ok ? "живом" : "мёртвом");
        rtl.io_fail = 8;
        rtl_wedge_check();
        return 0;
    }
    return 1;
}

/* [W-MACROT] у RTL MAC живёт в прошивке — ротация не поддержана;
 * сеттинг ослепительно прошёл с локальным MAC и без неё (wifi_core
 * сама делает вызов необязательным: set_mac == NULL допустим). */
static void rtl_set_mac(const u8 *mac) {
    (void)mac;
}

static const wifi_hw_ops_t rtl_ops = {
    .poll_rx           = rtl_poll_rx,
    .set_channel       = rtl_set_channel,
    .tx_frame          = rtl_tx_frame,
    .rx_filter_promisc = rtl_rx_filter_promisc,
    .rx_filter_bss     = rtl_rx_filter_bss,
    .set_bssid         = rtl_set_bssid,
    .keys_install      = rtl_keys_install,
    .keys_clear        = rtl_keys_clear,
    .full_reset        = rtl_full_reset,
    .set_mac           = rtl_set_mac,
    .scan_retry        = rtl_scan_retry,
    .tkip_sw_mic       = 1,     /* [W-TKIPSW]: железо 8192EU делает только RC4/ICV */
};

/* VID/PID устройств Realtek 8192E USB (эталон: usb_device_id таблица) */
static const u16 rtl_known_ids[][2] = {
    { 0x0bda, 0x818b },   /* TP-Link TL-WN822N v4/v5 и др. — RTL8192EU */
    { 0x0bda, 0x818c },   /* RTL8192EU (alt) */
    { 0x2357, 0x0107 },   /* TP-Link TL-WN822N v5 */
    { 0x2357, 0x0108 },   /* TP-Link TL-WN822N v5 (alt) */
    { 0x2357, 0x0109 },   /* TP-Link TL-WN823N v3 */
    { 0x2357, 0x0126 },   /* TP-Link TL-WN823N v3 (alt) */
    { 0, 0 }
};

static void rtl_full_reset(void) {
    wifi_log("RTL: полный bring-up заново");
    rtl.ready = 0;
    wc_set_state(1, 0);
    if (rtl_init_device()) {
        wifi_log("RTL: повторный init не удался");
        return;
    }
    rtl.ready = 1;
    wc_set_state(1, 1);
}

int rtl8192eu_probe(void) {
    /* Повторный вызов на живом адаптере — без изменений (hot-plug цикл
     * wifi-задачи зовёт probe только после CSC/новой перечисления, но
     * подстрахуемся: ре-инициализация живого адаптера недопустима). */
    if (rtl.attached && rtl.ready) return 1;
    /* ВАЖНО: НЕ memset(rtl)! Attach уже произошёл в перечислении EHCI
     * (usb_init при загрузке, задолго до фонового wifi_init) — он
     * заполнил addr/эндпоинты. Здесь только константы TX-страниц. */
    rtl.total_page_num = TX_TOTAL_PAGE_NUM_8192E;
    rtl.page_hi = TX_PAGE_NUM_HI_PQ_8192E;
    rtl.page_lo = TX_PAGE_NUM_LO_PQ_8192E;
    rtl.page_norm = TX_PAGE_NUM_NORM_PQ_8192E;

    if (!usb_ehci_present()) {
        wifi_log("RTL: EHCI не найден — USB WiFi недоступен");
        return 0;
    }
    if (!rtl.attached) {
        wifi_log("RTL: устройство RTL8192EU не найдено на шине USB");
        return 0;
    }
    if (rtl.ep_in <= 0 || rtl.nr_out_eps <= 0) {
        wifi_log("RTL: не найдены bulk-эндпоинты");
        return 0;
    }

    rtl_udelay_calibrate();

    /* буферы: RX — ровно страница (EHCI page-указатели), TX — 4K-выровнен.
     * СЕССИЯ 40: переиспользуем уже выделенные (раньше каждый повторный
     * probe утекал страницу RX+TX — при ватчдоге/повторных bring-up
     * набегало; данные в буферах невалидны только до первого заполнения). */
    if (!rtl.rxbuf) rtl.rxbuf = rtl_page_alloc(RTL_RXBUF_SZ);
    if (!rtl.txbuf) rtl.txbuf = rtl_page_alloc(RTL_MAX_TXBUF + 64);
    if (!rtl.rxbuf || !rtl.txbuf) {
        wifi_log("RTL: нет памяти под буферы USB");
        return 0;
    }

    wifi_log("RTL: %s на USB addr %d (EPin=%d/%d, OUT EP: %d%d%d)",
             rtl.chip_name[0] ? rtl.chip_name : "8192EU", rtl.addr,
             rtl.ep_in, rtl.ep_in_size,
             rtl.out_ep[0], rtl.nr_out_eps > 1 ? rtl.out_ep[1] : 0,
             rtl.nr_out_eps > 2 ? rtl.out_ep[2] : 0);

    if (rtl_identify_chip()) return 0;

    /* прошивка уже должна быть доступна (встроена в ядро) */
    {
        const rtl_fw_header_t *fw = (const rtl_fw_header_t *)rtl8192eu_fw_data;
        u16 sig = fw->signature;
        if ((sig & 0xfff0) != 0x92e0) {
            wifi_log("RTL: неверная подпись прошивки %04x", sig);
            return 0;
        }
        wifi_log("RTL: прошивка v%d.%d (sig %04x, %u б)",
                 fw->major_version, fw->minor_version, sig,
                 (unsigned)(RTL8192EU_FW_SIZE - sizeof(rtl_fw_header_t)));
    }

    if (rtl_init_device()) {
        wifi_log("RTL: init не удался");
        rtl.ready = 0;
        wc_set_state(1, 0);
        return 0;
    }

    /* EFUSE: MAC + мощность (после init — efuse-доступ требует питания) */
    if (rtl_read_efuse() == 0) {
        rtl_parse_efuse();
        if (rtl.mac[0]) {
            wc_set_mac(rtl.mac);
            /* MAC в железо (после efuse — точнее дефолта) */
            for (int i = 0; i < 6; i++)
                rtl_w8(REG_MACID + i, rtl.mac[i]);
            rtl_set_tx_power(rtl.channel ? rtl.channel : 1, 0);
        }
        wifi_log("RTL: MAC %02x:%02x:%02x:%02x:%02x:%02x (efuse%s)",
                 rtl.mac[0], rtl.mac[1], rtl.mac[2],
                 rtl.mac[3], rtl.mac[4], rtl.mac[5],
                 rtl.efuse_ok ? "" : " нет");
    } else {
        wc_set_mac(rtl.mac);   /* дефолт из parse/attach */
        wifi_log("RTL: efuse не прочитан — MAC дефолтный");
    }

    rtl.ready = 1;
    wc_set_chip_name(rtl.chip_name);
    wc_set_state(1, 1);
    wifi_core_bind(&rtl_ops);
    return 1;
}

/* ---- СЕССИЯ 33: адаптер зааттачен перечислением (для wifi-задачи: отличать
 * «устройства нет на шине» от «зааттачен, но bring-up ещё не завершён») ---- */
int rtl8192eu_attached(void) { return rtl.attached ? 1 : 0; }

/* ---- СЕССИЯ 35: bring-up завершён. Скан-задача EHCI на это время
 * замолкает (probe гоняет control/bulk по тому же async-списку —
 * одновременное обслуживание портов недопустимо). ---- */
int rtl8192eu_ready(void) { return (rtl.attached && rtl.ready) ? 1 : 0; }

/* ---- СЕССИЯ 40: адаптер клин (перестал отвечать по USB). wifi-задача
 * перед bring-up обязана вызвать rtl8192eu_recover_device(). ---- */
int rtl8192eu_wedged(void) { return rtl.wedged ? 1 : 0; }

/* СЕССИЯ 40: восстановление после клина — сброс ПОРТА (прошивку грузить
 * заново бесполезно: клинит USB-движок чипа, а не 8051) + полная
 * очистка состояния драйвера. Перечисление hot-plug зааттачит устройство
 * заново, wifi-задача выполнит полный bring-up. */
void rtl8192eu_recover_device(void) {
    wifi_log("RTL: восстановление — сброс порта USB и переперечисление");
    usb_ehci_rx_disarm();
    usb_ehci_reset_wifi_device(rtl.addr);
    rtl.attached = 0;
    rtl.ready = 0;
    rtl.wedged = 0;
    rtl.io_fail = 0;
    rtl.rx_fail_streak = 0;
    rtl.addr = 0;
    rtl.ep_in = 0;
    rtl.ep_in_size = 0;
    rtl.ep_out_size = 0;
    rtl.nr_out_eps = 0;
    rtl.ep_tx_high_q = rtl.ep_tx_normal_q = rtl.ep_tx_low_q = 0;
    rtl.ep_tx_count = 0;
    rtl.channel = 0;
    wc_set_state(1, 0);
}

/* ---- attach из перечисления EHCI (usb_ehci.c) ---- */
int usb_wifi_try_attach(int addr, u16 vid, u16 pid,
                        const u8 *cfgbuf, int cfg_total) {
    int known = 0;
    for (int i = 0; rtl_known_ids[i][0]; i++)
        if (rtl_known_ids[i][0] == vid && rtl_known_ids[i][1] == pid) {
            known = 1;
            break;
        }
    if (!known) return 0;
    /* СЕССИЯ 40: устройство переподключили (перечисление после сброса
     * порта/выдёргивания) — прежнее состояние недействительно (адрес,
     * эндпоинты, прошивка чипа), переаттачиваем с нуля. */
    if (rtl.attached) {
        wifi_log("RTL: устройство переаттачивается (addr %d -> %d) — сброс состояния",
                 rtl.addr, addr);
        usb_ehci_rx_disarm();
        rtl.attached = 0;
        rtl.ready = 0;
        rtl.wedged = 0;
        rtl.io_fail = 0;
        rtl.rx_fail_streak = 0;
        rtl.ep_in = 0;
        rtl.ep_in_size = 0;
        rtl.ep_out_size = 0;
        rtl.nr_out_eps = 0;
        rtl.ep_tx_high_q = rtl.ep_tx_normal_q = rtl.ep_tx_low_q = 0;
        rtl.ep_tx_count = 0;
        wc_set_state(1, 0);
    }

    /* разбираем bulk-эндпоинты (все OUT — по очередям TX) */
    int i = 0;
    while (i + 2 <= cfg_total) {
        u8 dlen = cfgbuf[i], dtyp = cfgbuf[i + 1];
        if (dlen == 0) break;
        if (dtyp == 5 && i + 7 <= cfg_total) {
            u8 ep_addr = cfgbuf[i + 2];
            u8 ep_attr = cfgbuf[i + 3];
            u16 ep_sz = (u16)(cfgbuf[i + 4] | (cfgbuf[i + 5] << 8));
            if ((ep_attr & 0x03) == 0x02) {       /* bulk */
                if (ep_addr & 0x80) {
                    if (!rtl.ep_in) {
                        rtl.ep_in = ep_addr & 0x0F;
                        rtl.ep_in_size = ep_sz;
                    }
                } else {
                    if (rtl.nr_out_eps < 4) {
                        rtl.out_ep[rtl.nr_out_eps++] = (u8)(ep_addr & 0x0F);
                        rtl.ep_out_size = ep_sz;
                    }
                }
            }
        }
        i += dlen;
    }
    rtl.attached = 1;
    rtl.addr = addr;
    /* флаги очередей — как rtl8xxxu_config_endpoints_no_sie:
     * 3+ OUT EP: low+normal+high; 2: normal+high; 1: high */
    if (rtl.nr_out_eps >= 3) {
        rtl.ep_tx_low_q = rtl.ep_tx_normal_q = rtl.ep_tx_high_q = 1;
        rtl.ep_tx_count = 3;
    } else if (rtl.nr_out_eps == 2) {
        rtl.ep_tx_normal_q = rtl.ep_tx_high_q = 1;
        rtl.ep_tx_count = 2;
    } else if (rtl.nr_out_eps == 1) {
        rtl.ep_tx_high_q = 1;
        rtl.ep_tx_count = 1;
    }
    return 1;
}
