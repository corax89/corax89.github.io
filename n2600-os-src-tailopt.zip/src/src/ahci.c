/* ahci.c — AHCI/SATA-драйвер (HDD и ATAPI CD).
 *
 * ЗАЧЕМ: в VMware диски по умолчанию — SATA (AHCI), а не IDE. Легаси-ATA
 * драйвер такие диски не видит вообще — «кроме ramfs нет дисков». На
 * реальном современном железе SATA тоже стандарт. Этот драйвер:
 *   - сканирует PCI на AHCI-контроллер (class 01:06, Intel ICH9/VMware);
 *   - перечисляет до 32 портов, находит SATA-диски (SIG 0x101) и
 *     ATAPI (SIG 0xEB140101);
 *   - IDENTIFY DEVICE → модель/размер;
 *   - чтение секторов READ DMA EXT (0x25) через командные таблицы AHCI;
 *   - ATAPI READ(12) для SATA-приводов (как ISO-источник);
 *   - всё POLLING-ом (без IRQ) — проще и надёжнее на старте.
 *
 * Память: CLB требует выравнивания 1024, FIS-приёмник 256, командная
 * таблица 128 — выделяем с запасом и выравниваем указатели вручную.
 * Физические адреса == виртуальным (ядро работает без пейджинга или с
 * identity-отображением).
 */
#include "ahci.h"
#include "io.h"
#include "string.h"
#include "pci.h"
#include "mem.h"
#include "timer.h"
#include "task.h"
#include "sync.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);

/* ---------- регистры HBA (ABAR) ---------- */
#define HBA_CAP   0x00   /* биты 0-4: NP-1 (число портов), бит31: SSS (spin-up) */
#define HBA_GHC   0x04   /* бит31 AE (AHCI enable), бит0 HR (reset) */
#define HBA_IS    0x08
#define HBA_PI    0x0C   /* порты, реализованные в железе (битмаска) */
#define HBA_VS    0x10

/* ---------- регистры порта (0x100 + i*0x80) ---------- */
#define PxCLB   0x00
#define PxCLBU  0x04
#define PxFB    0x08
#define PxFBU   0x0C
#define PxIS    0x10
#define PxIE    0x14
#define PxCMD   0x18   /* ST(0), SUD(1), FRE(4), FR(14), CR(15), ICC(28-31) */
#define PxTFD   0x20
#define PxSIG   0x24
#define PxSSTS  0x28   /* DET(0-3): 3 = устройство на линии */
#define PxSCTL  0x2C
#define PxSERR  0x30
#define PxSACT  0x34
#define PxCI    0x38

#define PxCMD_ST  (1u << 0)
#define PxCMD_SUD (1u << 1)
#define PxCMD_FRE (1u << 4)
#define PxCMD_FR  (1u << 14)
#define PxCMD_CR  (1u << 15)

#define PxIS_DHRS (1u << 0)   /* D2H Register FIS received */
#define PxIS_PSS  (1u << 1)   /* PIO Setup FIS */
#define PxIS_DPS  (1u << 5)   /* DMA Setup FIS */
#define PxIS_TFES (1u << 30)  /* Task File Error */

#define PxTFD_BSY (1u << 7)
#define PxTFD_DRQ (1u << 3)
#define PxSCTL_DET 0x0000000Fu

#define AHCI_CAP_SSS (1u << 31)   /* staggered spin-up supported */

/* ---------- командный список / таблица ---------- */
typedef struct __attribute__((packed)) {
    /* DW0: CFL[4:0], A(5), W(6), P(7), R(8), B(9), C(10), reserved */
    u16 flags_cfl;      /* см. поля ниже */
    u16 prdtl;          /* число записей PRDT */
    u32 prdbc;          /* передано байт */
    u32 ctba;           /* адрес командной таблицы */
    u32 ctbau;
    u32 reserved[4];
} ahci_cmd_hdr_t;
#define HDR_CFL(x)  ((x) & 0x1F)
#define HDR_CFL_SET(v) ((u16)(v))
#define HDR_A  (1u << 5)
#define HDR_W  (1u << 6)
#define HDR_C  (1u << 10)

typedef struct __attribute__((packed)) {
    u32 dba;      /* физ. адрес буфера данных */
    u32 dbau;
    u32 reserved;
    u32 dbc;      /* биты 0-21: число байт - 1; бит31: i (interrupt) */
} ahci_prdt_t;

typedef struct __attribute__((packed)) {
    u8  cfis[64];    /* FIS (H2D — 20 байт, остальное резерв) */
    u8  acmd[16];    /* ATAPI command descriptor */
    u8  reserved[48];
    ahci_prdt_t prdt[1];
} ahci_cmd_table_t;

#define CMD_TABLE_SIZE (sizeof(ahci_cmd_table_t))   /* ~80+16 байт */

/* ---------- состояние драйвера ---------- */
static volatile u32 *g_abar = NULL;   /* ABAR (BAR5) */
static int  g_ahci_present = 0;

typedef struct {
    int   used;
    int   pidx;        /* индекс порта HBA */
    int   is_atapi;
    u32   sectors;
    char  model[41];
    /* выровненные блоки памяти порта */
    void  *raw_cl;                      /* освобождаемый сырой блок */
    volatile ahci_cmd_hdr_t *cl;        /* командный список (1024-align) */
    void  *raw_fb;
    volatile u8 *fb;                    /* FIS-приёмник (256-align) */
    void  *raw_ct;
    volatile ahci_cmd_table_t *ct;      /* командная таблица (128-align) */
    void  *raw_buf;
    u8    *buf;                         /* буфер данных (2048-align не нужен) */
} ahci_port_t;

static ahci_port_t g_disk;    /* первый SATA-диск */
static ahci_port_t g_cd;      /* первый ATAPI */

static u32 rd32(u32 off)          { return g_abar[off / 4]; }
static void wr32(u32 off, u32 v)  { g_abar[off / 4] = v; }
static u32 prd32(int p, u32 off)  { return g_abar[(0x100 + (u32)p * 0x80 + off) / 4]; }
static void pwr32(int p, u32 off, u32 v) { g_abar[(0x100 + (u32)p * 0x80 + off) / 4] = v; }

/* ================= временные задержки (реальные, не итерации) =========
 * ПРОБЛЕМА СТАРОГО КОДА: все ожидания были циклами фиксированного числа
 * итераций MMIO-чтений (AHCI_TIMEOUT = 4 000 000). На реальном железе
 * (Atom N2600 + NM10) одно MMIO-чтение занимает сотни нс — 4M итераций
 * это СЕКУНДЫ, а 16M (ожидание команды) — ДЕСЯТКИ СЕКУНД. Итог:
 * «полминуты горит лампочка диска, потом дисков нет» — драйвер молотил
 * пустые циклы по зависшему после BIOS порту. Теперь все таймауты —
 * В МИЛЛИСЕКУНДАХ, калибровка по PIT каналу 2 (1.193182 МГц) — работает
 * до sti() и до timer_init (нужен только latch-чтение счётчика). */

static u16 pit2_read(void) {
    outb(0x43, 0x80);
    return (u16)(inb(0x42) | (inb(0x42) << 8));
}

static volatile u32 g_io_per_us = 3;   /* итераций inb(0x80) на 1 мкс */

static void a_delay_calibrate(void)
{
    u8 p61 = inb(0x61);
    outb(0x61, (p61 | 0x01) & ~0x02);  /* GATE2=1, динамик выкл */
    outb(0x43, 0xB4);                  /* канал 2, режим 2, binary */
    outb(0x42, 0xFF); outb(0x42, 0xFF);

    u32 best = 0;
    for (int s = 0; s < 4; s++) {
        u32 n = 2000;
        u16 t0 = pit2_read();
        for (u32 i = 0; i < n; i++) (void)inb(0x80);
        u16 t1 = pit2_read();
        u32 dt = (u32)((t0 - t1) & 0xFFFF);
        if (dt < 8 || dt > 60000) continue;
        u32 per_us = (u32)(((u64)n * 1193182u) / 1000000u / dt);
        if (per_us > best) best = per_us;
    }
    /* [PIT2-RESYNC] GATE2 оставляем ОТКРЫТЫМ (конвенция timer.c/ath9k:
     * раньше outb(0x61, p61) мог заморозить счётчик канала 2, если до
     * нас его никто не открыл — дедлайны timer.c переставали истекать) и
     * переозначаем базу оборотов: наша перепрограммка канала (0xB4 +
     * 0xFFFF) иначе даёт фантомные +65536 тиков (~55 мс) всем ждущим. */
    outb(0x61, (u8)((p61 | 0x01) & ~0x02));
    timer_pit2_resync();

    if (best == 0) best = 8;           /* PIT молчит — консервативно */
    if (best > 2000) best = 2000;
    g_io_per_us = best + 1;
}

static void a_udelay(int us)
{
    if (us <= 0) return;
    volatile u32 n = (u32)us * g_io_per_us;
    while (n-- > 0) (void)inb(0x80);
}

/* ---------- асинхронный режим (сессия 11) ----------
 * AHCI-инициализация теперь идёт в ФОНОВОЙ задаче (sata) — грузить
 * UI ожиданием COMRESET/IDENTIFY больше никто не должен. В этом режиме
 * все миллисекундные ожидания выполняются через планировщик
 * (task_msleep), а не busy-loop: система остаётся отзывчивой, пока
 * диск раскручивается. До sti()/tasking вызовы идут по-прежнему
 * калиброванными циклами. */
static volatile int g_async_waits = 0;

void ahci_set_async(int on) { g_async_waits = on; }

/* ожидание ~1 мс: планировщик в фоне, busy-loop при раннем вызове */
static void wait_ms(void)
{
    if (g_async_waits) {
        task_msleep(1);
    } else {
        a_udelay(1000);
    }
}

static int pwait_reg(int p, u32 off, u32 mask, u32 val, int timeout_ms)
{
    if (g_async_waits) {
        /* Сессия 33: task_msleep(1) теперь спит ЧЕСТНЫЙ 1 мс (PIT 1000 Гц) —
         * считаем дедлайн прямо в тиках (1 тик = 1 мс). */
        u32 start = timer_ticks();
        u32 need = (u32)timeout_ms + 1u;
        for (;;) {
            if ((prd32(p, off) & mask) == val) return 1;
            if (timer_ticks() - start >= need) break;
            task_msleep(1);
        }
        return (prd32(p, off) & mask) == val;
    }
    for (int t = 0; t < timeout_ms; t++) {
        if ((prd32(p, off) & mask) == val) return 1;
        a_udelay(1000);
    }
    return (prd32(p, off) & mask) == val;
}

/* Выровненный malloc: выделяет size + align и возвращает выровнутый указатель.
 * Сырой указатель сохраняется в *raw для free(). */
static void *amalloc(u32 size, u32 align, void **raw)
{
    u8 *p = (u8 *)malloc(size + align);
    if (!p) return NULL;
    *raw = p;
    u32 addr = (u32)(unsigned long)p;
    u32 aligned = (addr + align - 1) & ~(align - 1);
    memset((void *)aligned, 0, size);
    return (void *)aligned;
}

/* Остановить движок порта (по спецификации AHCI 1.3.1 §10.4.2).
 * Таймауты — реальные (500 мс на шаг), а не счётчики итераций. */
static int port_stop(int pidx)
{
    u32 cmd = prd32(pidx, PxCMD);
    if (cmd & PxCMD_ST)
        pwr32(pidx, PxCMD, cmd & ~PxCMD_ST);
    if (!pwait_reg(pidx, PxCMD, PxCMD_CR, 0, 500))
        return 0;
    cmd = prd32(pidx, PxCMD);
    if (cmd & PxCMD_FRE)
        pwr32(pidx, PxCMD, cmd & ~PxCMD_FRE);
    if (!pwait_reg(pidx, PxCMD, PxCMD_FR, 0, 500))
        return 0;
    return 1;
}

/* COMRESET — аппаратный сброс линии (AHCI 1.3.1 §10.4.1).
 * Спасает от порта, зависшего после BIOS/GRUB (BSY/DRQ стоят, CR/FR
 * не падают): движок нельзя перезапустить, пока устройство держит
 * линию занятой — сначала сброс, потом остановка/запуск. */
static int port_comreset(int pidx)
{
    pwr32(pidx, PxSERR, 0xFFFFFFFFu);          /* сброс ошибок линии */
    pwr32(pidx, PxSCTL, 0x300 | 1);            /* DET=1 (reset), IPM=3 */
    a_udelay(1500);                            /* ≥ 1 мс по спецификации */
    u32 sctl = prd32(pidx, PxSCTL);
    pwr32(pidx, PxSCTL, sctl & ~PxSCTL_DET);   /* DET=0 */
    /* Ждём установления связи: DET=3 (device + PHY) */
    if (!pwait_reg(pidx, PxSSTS, 0xF, 3, 2000))
        return 0;
    pwr32(pidx, PxSERR, 0xFFFFFFFFu);
    for (int i = 0; i < 10; i++) wait_ms();    /* стабилизация + сигнатура */
    return 1;
}

/* Запустить движок порта: CLB/FB -> FRE (ждать FR) -> ST (ждать CR).
 * §10.3.1: FRE ДОЛЖЕН быть установлен ДО ST — иначе контроллер
 * игнорирует ST (наблюдалось на реальном ICH-классе: CI зависал и
 * IDENTIFY отваливался по таймауту). */
static int port_start(int pidx, ahci_port_t *ap)
{
    pwr32(pidx, PxCLB, (u32)(unsigned long)ap->cl);
    pwr32(pidx, PxCLBU, 0);
    pwr32(pidx, PxFB, (u32)(unsigned long)ap->fb);
    pwr32(pidx, PxFBU, 0);
    pwr32(pidx, PxIS, 0xFFFFFFFFu);   /* сброс статусов */
    pwr32(pidx, PxIE, 0);             /* прерывания не нужны (polling) */

    u32 cmd = prd32(pidx, PxCMD);
    pwr32(pidx, PxCMD, (cmd | PxCMD_SUD) & ~PxCMD_ST);
    cmd = prd32(pidx, PxCMD);
    pwr32(pidx, PxCMD, cmd | PxCMD_FRE);
    pwait_reg(pidx, PxCMD, PxCMD_FR, PxCMD_FR, 200);
    pwr32(pidx, PxCMD, prd32(pidx, PxCMD) | PxCMD_ST);
    if (!pwait_reg(pidx, PxCMD, PxCMD_CR, PxCMD_CR, 200))
        return 0;
    return 1;
}

/* Ждать завершения команды slot 0: CI.0 сбросится или ошибка TFES.
 * Таймаут — 5 секунд реального времени (диск может раскручиваться).
 * Сессия 11: в фоновом режиме ожидание идёт через планировщик. */
static int wait_cmd_done(int pidx)
{
    if (g_async_waits) {
        u32 start = timer_ticks();
        u32 need = 5000u + 1u;                 /* 5 с в тиках (1 тик = 1 мс) */
        for (;;) {
            u32 ci = prd32(pidx, PxCI);
            u32 is = prd32(pidx, PxIS);
            if (is & PxIS_TFES) return 0;      /* ошибка task file */
            if ((ci & 1) == 0) return 1;       /* слот свободен = готово */
            if (timer_ticks() - start >= need) return 0;
            task_msleep(1);
        }
    }
    int ms = 0;
    for (;;) {
        u32 ci = prd32(pidx, PxCI);
        u32 is = prd32(pidx, PxIS);
        if (is & PxIS_TFES) return 0;          /* ошибка task file */
        if ((ci & 1) == 0) return 1;           /* слот свободен = готово */
        if (ms >= 5000) return 0;
        a_udelay(1000);
        ms++;
    }
}

/* Заполнить H2D register FIS */
static void fis_h2d(u8 *cfis, u8 command, u8 lba48, u64 lba, u16 count,
                    u8 dev, u8 feature)
{
    (void)lba48;   /* режим 28/48-бит кодируется САМИМ опкодом (0x24/0x25/
                    * 0x35 = *EXT); в Register FIS (AHCI 1.3.1 §5.2.1)
                    * отдельного бита LBA48 нет — параметр оставлен для
                    * читаемости вызовов. */
    memset(cfis, 0, 20);
    cfis[0] = 0x27;            /* тип: reg H2D */
    cfis[1] = 0x80;            /* C=1: обновить command block */
    cfis[2] = command;
    cfis[3] = feature;         /* feature L */
    cfis[4] = (u8)(lba & 0xFF);           /* LBA 0 */
    cfis[5] = (u8)((lba >> 8) & 0xFF);    /* LBA 1 */
    cfis[6] = (u8)((lba >> 16) & 0xFF);   /* LBA 2 */
    cfis[7] = dev | 0x40;      /* dev: LBA бит */
    /* FIX: раскладка байтов H2D register FIS (AHCI 1.3.1 §5.2.1):
     * байт 8-10 = LBA 31..47, байт 11 = Features 15:8,
     * байты 12/13 = Count 7:0 / 15:8 — ВСЕГДА. Раньше count писал
     * в байт 11 (feature_H), а count_L оставался 0 — READ DMA EXT
     * «читал 0 секторов»: CI сбрасывался без ошибки, данных не было. */
    cfis[8]  = (u8)((lba >> 24) & 0xFF);   /* LBA 31:24 */
    cfis[9]  = (u8)((lba >> 32) & 0xFF);   /* LBA 39:32 */
    cfis[10] = (u8)((lba >> 40) & 0xFF);   /* LBA 47:40 */
    cfis[11] = 0;                          /* Features 15:8 */
    cfis[12] = (u8)(count & 0xFF);         /* Count 7:0 */
    cfis[13] = (u8)(count >> 8);           /* Count 15:8 */
}

/* Выполнить команду через слот 0. Возвращает 1 при успехе.
 * Сессия 11: port_cmd вызывается ИЗ фоновой задачи sata, И из потоков
 * окон (fileman читает каталог/файл) — сериализуем блокировкой:
 * командная таблица/слот 0 у порта ОДИН, конкурентные команды калечили
 * бы друг друга. */
static volatile int g_port_lock = 0;

static int port_cmd(ahci_port_t *ap, u8 command, u8 atapi,
                    const u8 *cdb, u64 lba, u16 count, u8 feature,
                    void *out, u32 out_len)
{
    int pidx = ap->pidx;
    s_lock(&g_port_lock);
    /* таблица уже обнулена; заполняем FIS */
    if (atapi) {
        fis_h2d((u8 *)ap->ct->cfis, 0xA0 /* PACKET */, 0, 0, 0, 0, 0);
        /* ATAPI: feature = DMA? используем PIO-передачу пакета */
        ap->ct->cfis[3] = 0;             /* feature: PIO */
        ap->ct->cfis[12] = (u8)(out_len & 0xFF);   /* byte count low */
        ap->ct->cfis[13] = (u8)(out_len >> 8);     /* byte count high */
        if (cdb) memcpy((void *)ap->ct->acmd, cdb, 12);
    } else {
        fis_h2d((u8 *)ap->ct->cfis, command,
                (command == 0x25 || command == 0x24 || command == 0x35) ? 1 : 0,
                lba, count, 0, feature);
    }

    /* заголовок слота 0.
     * Сессия 12: бит W (write) обязателен для команд ЗАПИСИ (WRITE
     * DMA EXT 0x35) — он говорит HBA, что данные читаются ИЗ памяти
     * В устройство. Без него HBA затягивал бы мусор из буфера вместо
     * записи реальных секторов. */
    {
        int is_write = (command == 0x35);
        ahci_cmd_hdr_t *h = (ahci_cmd_hdr_t *)ap->cl;
        h[0].flags_cfl = HDR_CFL_SET(5) | (atapi ? HDR_A : 0) |
                         (is_write ? HDR_W : 0);
        h[0].prdtl = out_len ? 1 : 0;
        h[0].prdbc = 0;
        h[0].ctba  = (u32)(unsigned long)ap->ct;
        h[0].ctbau = 0;
    }

    /* PRDT: буфер данных */
    if (out_len) {
        ap->ct->prdt[0].dba = (u32)(unsigned long)(out ? out : ap->buf);
        ap->ct->prdt[0].dbau = 0;
        ap->ct->prdt[0].reserved = 0;
        ap->ct->prdt[0].dbc = (out_len - 1) & 0x3FFFFF;
    }

    pwr32(pidx, PxIS, 0xFFFFFFFFu);       /* сброс старых статусов */
    pwr32(pidx, PxCI, 1);                 /* пуск слота 0 */
    if (!wait_cmd_done(pidx)) {
        char b[96];
        snprintf(b, sizeof(b),
                 "[ahci] command timeout/error (cmd=0x%x) CI=%x IS=%x TFD=%x SERR=%x lba=%llu\n",
                 command, prd32(pidx, PxCI), prd32(pidx, PxIS),
                 prd32(pidx, PxTFD), prd32(pidx, PxSERR), lba);
        serial_puts(b);
        pwr32(pidx, PxCI, 0);
        pwr32(pidx, PxSERR, prd32(pidx, PxSERR));   /* сброс SERR */
        s_unlock(&g_port_lock);
        return 0;
    }
    pwr32(pidx, PxSERR, prd32(pidx, PxSERR));
    s_unlock(&g_port_lock);
    return 1;
}

/* ATAPI READ(12) CDB */
static void cdb_read12(u8 *cdb, u32 lba, u32 blocks)
{
    memset(cdb, 0, 12);
    cdb[0] = 0xBE;                          /* READ(12) */
    cdb[2] = (u8)(lba >> 24);
    cdb[3] = (u8)((lba >> 16) & 0xFF);
    cdb[4] = (u8)((lba >> 8) & 0xFF);
    cdb[5] = (u8)(lba & 0xFF);
    cdb[6] = (u8)(blocks >> 24);
    cdb[7] = (u8)((blocks >> 16) & 0xFF);
    cdb[8] = (u8)((blocks >> 8) & 0xFF);
    cdb[9] = (u8)(blocks & 0xFF);
}

/* Разбор IDENTIFY: модель (слова 27-46), сектора 48-бит (100-103) */
static void parse_identify(ahci_port_t *ap, const u16 *id)
{
    char *d = ap->model;
    const u16 *src = id + 27;
    for (int i = 0; i < 20; i++) {
        d[i * 2]     = (char)(src[i] >> 8);
        d[i * 2 + 1] = (char)(src[i] & 0xFF);
    }
    d[40] = 0;
    /* трим пробелов по краям */
    char *e = d + strlen(d);
    while (e > d && *(e - 1) == ' ') *--e = 0;
    char *s = d;
    while (*s == ' ') s++;
    if (s > d) memmove(d, s, strlen(s) + 1);

    u64 sec48 = ((u64)id[100] << 0)  | ((u64)id[101] << 16)
              | ((u64)id[102] << 32) | ((u64)id[103] << 48);
    u32 sec28 = (u32)id[60] | ((u32)id[61] << 16);
    ap->sectors = (sec48 > 0 && sec48 < 0xFFFFFFFFull)
                      ? (u32)sec48 : (sec28 ? sec28 : (u32)sec48);
}

/* Инициализация одного порта: память + корректный перезапуск движка.
 * Порядок (AHCI 1.3.1 + практика Linux ahci):
 *   1) если устройство держит линию (BSY/DRQ в TFD) — COMRESET;
 *   2) port_stop (ST→CR=0, FRE→FR=0, по 500 мс); если не остановился —
 *      COMRESET и вторая попытка;
 *   3) port_start (CLB/FB, FRE→FR, ST→CR). */
static int port_setup(int pidx, ahci_port_t *ap)
{
    memset(ap, 0, sizeof(*ap));
    ap->pidx = pidx;
    ap->cl = (volatile ahci_cmd_hdr_t *)amalloc(32 * sizeof(ahci_cmd_hdr_t), 1024, &ap->raw_cl);
    ap->fb = (volatile u8 *)amalloc(256, 256, &ap->raw_fb);
    ap->ct = (volatile ahci_cmd_table_t *)amalloc(sizeof(ahci_cmd_table_t), 128, &ap->raw_ct);
    ap->buf = (u8 *)malloc(8192);
    if (!ap->cl || !ap->fb || !ap->ct || !ap->buf) {
        if (ap->raw_cl) free(ap->raw_cl);
        if (ap->raw_fb) free(ap->raw_fb);
        if (ap->raw_ct) free(ap->raw_ct);
        if (ap->buf) free(ap->buf);
        return 0;
    }

    /* Устройство застряло в команде после BIOS/GRUB? — сначала COMRESET */
    u32 tfd = prd32(pidx, PxTFD);
    if (tfd & (PxTFD_BSY | PxTFD_DRQ)) {
        serial_puts("[ahci] порт завис после BIOS (TFD=");
        {
            char b[12];
            snprintf(b, sizeof(b), "%x", tfd);
            serial_puts(b);
        }
        serial_puts(") — COMRESET\n");
        port_comreset(pidx);
    }

    if (!port_stop(pidx)) {
        serial_puts("[ahci] движок не останавливается — COMRESET и повтор\n");
        if (!port_comreset(pidx))
            serial_puts("[ahci] предупреждение: линия не поднялась после COMRESET\n");
        port_stop(pidx);
    }
    if (!port_start(pidx, ap))
        serial_puts("[ahci] порт не запустился (CR не поднялся)\n");
    return 1;
}

/* Попытка идентификации с одной повторной попыткой через COMRESET
 * (диски в standby/раскрутке на первой команде могут ошибиться). */
static int port_identify(ahci_port_t *ap)
{
    if (port_cmd(ap, 0xEC /* IDENTIFY */, 0, NULL, 0, 0, 0, NULL, 512))
        return 1;
    serial_puts("[ahci] IDENTIFY не прошёл — COMRESET и повтор\n");
    if (!port_comreset(ap->pidx)) return 0;
    if (!port_stop(ap->pidx)) return 0;
    if (!port_start(ap->pidx, ap)) return 0;
    return port_cmd(ap, 0xEC, 0, NULL, 0, 0, 0, NULL, 512);
}

int ahci_init(void)
{
    /* --- PCI-скан: класс 01 (Mass Storage), подкласс 06 (SATA/AHCI) --- */
    int found = 0, fbus = 0, fdev = 0, ffunc = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            for (int func = 0; func < 8; func++) {
                u16 v = pci_read16(bus, dev, func, 0);
                if (v == 0xFFFF) continue;
                u8 cls  = (u8)(pci_read32(bus, dev, func, 0x08) >> 24);
                u8 sub  = (u8)(pci_read32(bus, dev, func, 0x08) >> 16);
                u8 prog = (u8)(pci_read32(bus, dev, func, 0x08) >> 8);
                if (cls == 0x01 && sub == 0x06 && prog == 0x01) {
                    fbus = bus; fdev = dev; ffunc = func;
                    found = 1;
                    break;
                }
            }
        }
    }
    if (!found) return 0;

    {
        char b[96];
        u16 vid = pci_read16(fbus, fdev, ffunc, 0);
        u16 did = pci_read16(fbus, fdev, ffunc, 2);
        snprintf(b, sizeof(b), "[ahci] контроллер %04x:%04x bus=%d dev=%d\n",
                 vid, did, fbus, fdev);
        serial_puts(b);
    }

    /* BAR5 -> ABAR; включаем MMIO + bus master */
    u32 bar5 = pci_read32(fbus, fdev, ffunc, 0x24);
    if (!bar5) {
        serial_puts("[ahci] BAR5 пуст\n");
        return 0;
    }
    u16 cmd = pci_read16(fbus, fdev, ffunc, 0x04);
    pci_write16(fbus, fdev, ffunc, 0x04, cmd | 0x06 /* MSE+BME */);
    g_abar = (volatile u32 *)(unsigned long)(bar5 & 0xFFFFFFF0u);

    u32 ghc = rd32(HBA_GHC);
    if (!(ghc & (1u << 31))) {
        wr32(HBA_GHC, ghc | (1u << 31));    /* AE = 1 */
    }
    u32 vs = rd32(HBA_VS);
    {
        char b[64];
        snprintf(b, sizeof(b), "[ahci] ABAR=%x GHC=%x VS=%x.%02x\n",
                 (unsigned)(bar5 & 0xFFFFFFF0u), rd32(HBA_GHC),
                 (unsigned)(vs >> 16), (unsigned)(vs & 0xFF));
        serial_puts(b);
    }

    u32 pi = rd32(HBA_PI);
    u32 cap = rd32(HBA_CAP);
    u32 nports = (cap & 0x1F) + 1;
    int staggered = (cap & AHCI_CAP_SSS) != 0;

    /* калибровка задержек — ДО первого ожидания */
    a_delay_calibrate();

    /* --- перебор портов --- */
    for (int p = 0; p < 32 && p < (int)nports; p++) {
        if (!(pi & (1u << p))) continue;

        u32 ssts = prd32(p, PxSSTS);
        u32 det = ssts & 0xF;
        u32 sig = prd32(p, PxSIG);

        /* Если устройства нет на линии — spin-up (если контроллер умеет)
         * и честное ожидание 1 секунду, не миллионы итераций. */
        if (det != 3) {
            if (staggered) {
                u32 cmd = prd32(p, PxCMD);
                pwr32(p, PxCMD, cmd | PxCMD_SUD);
            }
            int ok = pwait_reg(p, PxSSTS, 0xF, 3, 1000);
            if (!ok) {
                char b[64];
                snprintf(b, sizeof(b), "[ahci] порт %d: пусто (DET=%x)\n",
                         p, prd32(p, PxSSTS) & 0xF);
                serial_puts(b);
                continue;
            }
            det = 3;
        }
        (void)det;

        if (sig == 0xEB140101u) {
            /* ATAPI */
            if (g_cd.used) continue;
            char b[64];
            snprintf(b, sizeof(b), "[ahci] порт %d: SATA ATAPI CD (SIG=%x)\n",
                     p, (unsigned)sig);
            serial_puts(b);
            if (!port_setup(p, &g_cd)) continue;
            /* TEST UNIT READY не обязателен: пробуем INQUIRY для проверки */
            u8 cdb[12];
            memset(cdb, 0, 12);
            cdb[0] = 0x12; cdb[4] = 36;      /* INQUIRY */
            if (port_cmd(&g_cd, 0xA0, 1, cdb, 0, 0, 0, NULL, 36)) {
                g_cd.used = 1;
                g_cd.is_atapi = 1;
                strcpy(g_cd.model, "SATA CD/DVD (AHCI)");
                serial_puts("[ahci] ATAPI готов\n");
            } else {
                serial_puts("[ahci] ATAPI INQUIRY не прошёл\n");
            }
        } else {
            /* SATA-диск */
            if (g_disk.used) continue;
            /* СЕССИЯ 73 [CONSOLE]: 64 -> 128 — строка диска с моделью
             * («[ahci] диск: VMware Virtual SATA Hard Drive, …») занимала
             * 86 байт и обрезалась посреди UTF-8 с потерей '\n' */
            char b[128];
            snprintf(b, sizeof(b), "[ahci] порт %d: SATA диск (SIG=%x)\n",
                     p, (unsigned)sig);
            serial_puts(b);
            if (!port_setup(p, &g_disk)) continue;
            if (port_identify(&g_disk)) {
                parse_identify(&g_disk, (const u16 *)g_disk.buf);
                g_disk.used = 1;
                g_disk.is_atapi = 0;
                snprintf(b, sizeof(b), "[ahci] диск: %s, %u секторов (%u МиБ)\n",
                         g_disk.model, (unsigned)g_disk.sectors,
                         (unsigned)(g_disk.sectors / 2048u));
                serial_puts(b);
                /* Самопроверка чтения: сектор 0 (MBR, сигнатура 55AA) */
                if (port_cmd(&g_disk, 0x25 /* READ DMA EXT */, 0, NULL, 0, 1, 0, NULL, 512) &&
                    g_disk.buf[510] == 0x55 && g_disk.buf[511] == 0xAA) {
                    serial_puts("[ahci] чтение LBA0: OK (55AA)\n");
                } else {
                    serial_puts("[ahci] чтение LBA0: НЕИСПРАВНО\n");
                }
            } else {
                serial_puts("[ahci] IDENTIFY не прошёл\n");
            }
        }
    }

    g_ahci_present = 1;
    return 1;
}

int ahci_present(void)   { return g_ahci_present; }
int ahci_hdd_present(void) { return g_disk.used; }
int ahci_cd_present(void)  { return g_cd.used; }

u32 ahci_hdd_sectors(void) { return g_disk.sectors; }
const char *ahci_hdd_model(void) { return g_disk.model; }

/* Чтение секторов SATA-диска (READ DMA EXT, 48-бит LBA) */
int ahci_read_hdd(u32 lba, u8 count, void *buf)
{
    if (!g_disk.used) return 0;
    if (count == 0 || count > 128) return 0;   /* один PRDT до 4 МиБ (сессия 13: пакеты записи формата) */
    if (!port_cmd(&g_disk, 0x25, 0, NULL, lba, count, 0, buf, (u32)count * 512))
        return 0;
    return 1;
}

/* Запись секторов SATA-диска (WRITE DMA EXT 0x35, 48-бит LBA) — сессия 12.
 * Нужна для форматирования диска в FAT32 из «Настроек». */
int ahci_write_hdd(u32 lba, u8 count, const void *buf)
{
    if (!g_disk.used) return 0;
    if (count == 0 || count > 128) return 0;   /* один PRDT до 4 МиБ (сессия 13: пакеты записи формата) */
    if (!port_cmd(&g_disk, 0x35, 0, NULL, lba, count, 0,
                  (void *)buf, (u32)count * 512))
        return 0;
    return 1;
}

/* Чтение сектора ATAPI CD (2048 байт) */
int ahci_read_cd(u32 lba, void *buf)
{
    if (!g_cd.used) return 0;
    u8 cdb[12];
    cdb_read12(cdb, lba, 1);
    if (!port_cmd(&g_cd, 0xA0, 1, cdb, 0, 0, 0, buf, 2048))
        return 0;
    return 1;
}
