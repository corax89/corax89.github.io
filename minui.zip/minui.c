#include <stdio.h>
#include <stdlib.h>
#include <msettings.h>
#include <sys/types.h>
#include <dirent.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <zlib.h>
#include <arpa/inet.h>

#include "minIni.h"
#include "defines.h"
#include "api.h"
#include "utils.h"
#include "animated_list.h"

#define _GNU_SOURCE
#define OPTION_PADDING 4
#define COLOR_BLACK_V (SDL_Color){color_triad_black_r, color_triad_black_g, color_triad_black_b}
#define SCREENSHOTS_PATH SDCARD_PATH "/Screenshots"
#define DELETION_ANIMATION_SPEED 6 // как у клавиатуры (6 шагов анимации)
// Ускоряем анимацию меню
#define MENU_ANIMATION_SPEED (animation_speed * 2 / 3)

static ListAnimation list_anim;
static int need_final_redraw = 0;
static int last_anim_frame = 0;
static int DEVICE_WIDTH = FIXED_WIDTH;
static int DEVICE_HEIGHT = FIXED_HEIGHT;
static SDL_Surface* surface_png = NULL;
static SDL_Surface* prev_surface_png = NULL;
static SDL_Surface* fade_snapshot = NULL;
static int mem_index = -1;

// Кэш превью для карусели
#define CAROUSEL_CACHE_SIZE 10
static int carousel_cache_idx[CAROUSEL_CACHE_SIZE];
static SDL_Surface* carousel_cache_surf[CAROUSEL_CACHE_SIZE];
static int carousel_cache_last_used[CAROUSEL_CACHE_SIZE]; // для LRU
static int carousel_cache_tick = 0;
static int carousel_cache_init = 0;

static void carousel_cache_init_func(void) {
    for (int i = 0; i < CAROUSEL_CACHE_SIZE; i++) {
        carousel_cache_idx[i] = -1;
        carousel_cache_surf[i] = NULL;
        carousel_cache_last_used[i] = 0;
    }
    carousel_cache_tick = 0;
    carousel_cache_init = 1;
}

static void carousel_cache_reset(void) {
    for (int i = 0; i < CAROUSEL_CACHE_SIZE; i++) {
        if (carousel_cache_surf[i]) { SDL_FreeSurface(carousel_cache_surf[i]); carousel_cache_surf[i] = NULL; }
        carousel_cache_idx[i] = -1;
        carousel_cache_last_used[i] = 0;
    }
    carousel_cache_tick = 0;
}

static SDL_Surface* carousel_cache_get(int entry_idx) {
    if (!carousel_cache_init) carousel_cache_init_func();
    for (int i = 0; i < CAROUSEL_CACHE_SIZE; i++) {
        if (carousel_cache_idx[i] == entry_idx) {
            carousel_cache_last_used[i] = ++carousel_cache_tick; // обновляем LRU
            return carousel_cache_surf[i];
        }
    }
    return NULL;
}

static void carousel_cache_put(int entry_idx, SDL_Surface* surf) {
    if (!carousel_cache_init) carousel_cache_init_func();
    for (int i = 0; i < CAROUSEL_CACHE_SIZE; i++) {
        if (carousel_cache_idx[i] == entry_idx) return; // уже в кеше
    }
    // Ищем пустой слот
    int slot = -1;
    for (int i = 0; i < CAROUSEL_CACHE_SIZE; i++) {
        if (carousel_cache_idx[i] == -1) { slot = i; break; }
    }
    // Если нет пустого — вытесняем самый старый (LRU)
    if (slot < 0) {
        int min_tick = carousel_cache_last_used[0];
        slot = 0;
        for (int i = 1; i < CAROUSEL_CACHE_SIZE; i++) {
            if (carousel_cache_last_used[i] < min_tick) {
                min_tick = carousel_cache_last_used[i];
                slot = i;
            }
        }
    }
    if (carousel_cache_surf[slot]) SDL_FreeSurface(carousel_cache_surf[slot]);
    carousel_cache_idx[slot] = entry_idx;
    carousel_cache_surf[slot] = surf;
    carousel_cache_last_used[slot] = ++carousel_cache_tick;
}
static int next_folder = 1;
static int dirty = 1;
static char info_path[512];
SDL_Surface* screen = NULL;


const char inifile[] = SYSTEM_PATH "/uisettings.ini";
char select_themes[256];

static int isImageFile(const char* path);
static void loadImagesForViewer(const char* start_image);
static void viewer_load_image(void);
static void viewer_apply_transformations(void);
static void viewer_cleanup(void);
static void viewer_draw_image(void);
static void viewer_draw_info(void);
static void cancelAllAnimations(void);
extern int FillRoundRect(SDL_Surface* dst, int xo, int yo, int w, int h, int r, Uint16 color);
int strcasestr_i(const char* str, const char* pattern);

static int color_triad_black_r = 0x01;
static int color_triad_black_g = 0x01;
static int color_triad_black_b = 0x01;

static int colors_b[6][3] = {
    {0x1, 0x1, 0x1},
    {0xfe, 0xc2, 0x60},
    {0x1e, 0x51, 0x28},
    {0x09, 0x26, 0x35},
    {0x75, 0x0e, 0x21},
    {0x43, 0x0a, 0x5d},
};

static int animation = 1;
static int preview_transition = 0; // 0=SLIDE, 1=HORIZONTAL, 2=FADE, 3=ZOOM, 4=CAROUSEL
static int one_name_on_screen = 1;
static int root_directory = 1;
static int animation_speed = 9;
static int scroll_bar_view = 0;
static float scrollbar_anim_y = -1.0f;
static float scrollbar_drop_from = -1.0f; // позиция старой точки при анимации капли
static float scrollbar_prev_target = -1.0f; // предыдущая целевая позиция (дискретная)
static float carousel_pos = 0.0f;
static float carousel_target = 0.0f;
static int carousel_initialized = 0;
static int isPSP = 0;
static int show_empty_folders = 1;
extern void PLAT_showPopup(const char* text);
extern int PLAT_isPopupActive(void);

// Улучшенная универсальная структура для меню с заголовком
typedef struct {
    int visible;
    int anim_frame;
    SDL_Surface* menu_surface;
    int selected_option;
    int item_count;
    char** menu_items;
    int animation;
    int border_color;
    int bg_color;
    int width;
    int height;
    int item_height;
    char* title; // Новое поле для заголовка
    int has_title; // Флаг наличия заголовка
} GenericMenuDialog;

// Структура для анимации меню (аналогично анимации списка файлов)
typedef struct {
    int anim_frame;
    int anim_direction; // 1 = вверх, -1 = вниз
    int old_selected;
    int new_selected;
} MenuAnimation;

static MenuAnimation menu_anim = {0};

// Улучшенная функция создания меню с более пропорциональными размерами
static GenericMenuDialog* createGenericMenuDialogWithTitle(char** items, int item_count, 
                                                          int border_color, int bg_color, 
                                                          int with_animation, const char* title) {
    GenericMenuDialog* menu = malloc(sizeof(GenericMenuDialog));
    if (!menu) return NULL;
    
    menu->item_count = item_count;
    menu->menu_items = malloc(sizeof(char*) * item_count);
    
    // Копируем строки
    for (int i = 0; i < item_count; i++) {
        menu->menu_items[i] = strdup(items[i]);
    }
    
    // Рассчитываем размеры для небольшого экрана
    menu->item_height = 32; // Оптимальная высота для маленького экрана
    
    // Базовые отступы (уменьшены для компактности)
    int top_padding = 12;
    int bottom_padding = 12;
    int item_spacing = 2; // Уменьшили расстояние между пунктами на треть (было 3)
    
    // Вычисляем высоту
    int items_height = (menu->item_height * item_count) + (item_spacing * (item_count - 1));
    menu->height = top_padding + items_height + bottom_padding;
    
    // Стандартная ширина, компактная для маленького экрана
    menu->width = 240;
    
    // Добавляем место для заголовка если есть
    menu->has_title = 0;
    menu->title = NULL;
    if (title && title[0] != '\0') {
        menu->has_title = 1;
        menu->title = strdup(title);
        // Добавляем место для заголовка (уменьшили для компактности)
        menu->height += 45;
        top_padding += 45;
    }
    
    // Находим максимальную ширину текста
    int max_text_width = 0;
    for (int i = 0; i < item_count; i++) {
        int text_w = 0;
        TTF_SizeUTF8(font.large, items[i], &text_w, NULL);
        if (text_w > max_text_width) {
            max_text_width = text_w;
        }
    }
    
    // Проверяем ширину заголовка если есть
    if (menu->has_title) {
        // Для многострочного заголовка находим максимальную ширину строк
        char title_copy[512];
        strcpy(title_copy, title);
        char* line = strtok(title_copy, "\n");
        while (line) {
            int line_width = 0;
            TTF_SizeUTF8(font.large, line, &line_width, NULL);
            if (line_width > max_text_width) {
                max_text_width = line_width;
            }
            line = strtok(NULL, "\n");
        }
    }
    
    // Вычисляем необходимую ширину с компактными отступами
    int required_width = max_text_width + 60; // Компактные отступы
    
    // Устанавливаем ширину, но с ограничениями
    if (required_width > menu->width) {
        menu->width = required_width;
    }
    
    // Ограничиваем минимальную и максимальную ширину для компактности
    if (menu->width < 210) menu->width = 210;
    if (menu->width > 380) menu->width = 380;
    
    menu->visible = 1;
    menu->anim_frame = with_animation ? DELETION_ANIMATION_SPEED : 0;
    menu->selected_option = 0;
    menu->animation = with_animation;
    menu->border_color = border_color;
    menu->bg_color = bg_color;
    
    // Создаем поверхность с запасом для бордюра
    menu->menu_surface = SDL_CreateRGBSurface(0, menu->width + 4, menu->height + 4, 16, 
                                             screen->format->Rmask, screen->format->Gmask, 
                                             screen->format->Bmask, screen->format->Amask);
    
    return menu;
}

// Упрощенная функция без заголовка для обратной совместимости
static GenericMenuDialog* createGenericMenuDialog(char** items, int item_count, 
                                                 int border_color, int bg_color, 
                                                 int with_animation) {
    return createGenericMenuDialogWithTitle(items, item_count, border_color, 
                                           bg_color, with_animation, NULL);
}

// Функция для запуска анимации меню (ускоренная)
static void startMenuAnimation(int old_selected, int new_selected, int direction) {
    menu_anim.anim_frame = MENU_ANIMATION_SPEED;
    menu_anim.anim_direction = direction;
    menu_anim.old_selected = old_selected;
    menu_anim.new_selected = new_selected;
}

// Функция для обновления анимации меню
static int updateMenuAnimation(void) {
    if (menu_anim.anim_frame > 0) {
        menu_anim.anim_frame--;
        if (menu_anim.anim_frame == 0) {
            // Когда анимация завершена, нужно принудительно перерисовать
            dirty = 1;
            return 1; // Анимация завершена
        }
        return 0; // Анимация еще идет
    }
    return 1; // Анимация завершена или не запущена
}

// Улучшенная функция отрисовки меню с поддержкой заголовка
static void drawGenericMenuDialog(GenericMenuDialog* menu, SDL_Surface* screen) {
    if (!menu || !menu->visible || !menu->menu_surface) return;
    
    int screen_center_x = screen->w / 2;
    int screen_center_y = screen->h / 2;
    
    // Начальные координаты (без анимации)
    int x = screen_center_x - (menu->width / 2);
    int y = screen_center_y - (menu->height / 2);
    int draw_width = menu->width;
    int draw_height = menu->height;
    
    // Анимация появления/исчезновения меню
    if (menu->animation && menu->anim_frame > 1) {
        float progress = 1.0f - ((float)menu->anim_frame / DELETION_ANIMATION_SPEED);
        
        draw_width = 1 + (menu->width * progress);
        draw_height = 1 + (menu->height * progress);
        x = screen_center_x - (draw_width / 2);
        y = screen_center_y - (draw_height / 2);
    }
    
    // Очищаем поверхность
    SDL_FillRect(menu->menu_surface, NULL, 0xDEDB); // цвет ключ
    
    if (draw_width > 2 && draw_height > 2) {
        // Рисуем бордюр (внешний прямоугольник)
        FillRoundRect(menu->menu_surface, 0, 0, draw_width, draw_height, 6, menu->border_color);
        
        // Рисуем фон (внутренний прямоугольник)
        FillRoundRect(menu->menu_surface, 2, 2, draw_width - 4, draw_height - 4, 4, menu->bg_color);
        
        // Если анимация появления завершена, рисуем содержимое
        if (!menu->animation || menu->anim_frame <= 1) {
            int content_start_y = 10;
            
            // Рисуем заголовок если есть
            if (menu->has_title && menu->title) {
                char title_copy[512];
                strcpy(title_copy, menu->title);
                
                int line_height = 18; // Уменьшили для компактности
                int current_y = content_start_y;
                
                // Разбиваем заголовок на строки
                char* line = strtok(title_copy, "\n");
                while (line) {
                    SDL_Surface* title_text = TTF_RenderUTF8_Blended(font.large, line, COLOR_WHITE);
                    if (title_text) {
                        // Центрируем текст
                        int text_x = (menu->width - title_text->w) / 2;
                        
                        // Рисуем тень
                        SDL_Surface* shadow = TTF_RenderUTF8_Blended(font.large, line, COLOR_BLACK_V);
                        SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                      &(SDL_Rect){text_x - 1, current_y - 1});
                        SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                      &(SDL_Rect){text_x - 1, current_y + 1});
                        SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                      &(SDL_Rect){text_x + 1, current_y - 1});
                        SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                      &(SDL_Rect){text_x + 1, current_y + 1});
                        SDL_FreeSurface(shadow);
                        
                        // Основной текст
                        SDL_BlitSurface(title_text, NULL, menu->menu_surface, 
                                      &(SDL_Rect){text_x, current_y});
                        SDL_FreeSurface(title_text);
                    }
                    
                    current_y += line_height;
                    line = strtok(NULL, "\n");
                }
                
                content_start_y = current_y + 8; // Компактный отступ после заголовка
            }
            
            // Вычисляем область для пунктов меню
            int item_area_height = menu->height - content_start_y - 10;
            int item_spacing = 2; // Минимальное расстояние между пунктами
            int items_total_height = (menu->item_count * menu->item_height) + 
                                     (item_spacing * (menu->item_count - 1));
            int items_start_y = content_start_y + (item_area_height - items_total_height) / 2;
            
            // СОЗДАЕМ ВРЕМЕННУЮ ПОВЕРХНОСТЬ для рисования подложки поверх всего
            SDL_Surface* overlay_surface = NULL;
            if (menu_anim.anim_frame > 0 || menu->selected_option >= 0) {
                overlay_surface = SDL_CreateRGBSurface(0, menu->width, menu->height, 16, 
                                                      screen->format->Rmask, screen->format->Gmask, 
                                                      screen->format->Bmask, screen->format->Amask);
                if (overlay_surface) {
                    SDL_FillRect(overlay_surface, NULL, 0xDEDB); // Прозрачный фон
                    SDL_SetColorKey(overlay_surface, SDL_TRUE, 0xDEDB);
                }
            }
            
            // 1. Сначала рисуем ВСЕ пункты меню (белый текст)
            for (int i = 0; i < menu->item_count; i++) {
                int item_y = items_start_y + (i * (menu->item_height + item_spacing));
                
                // Текст ВСЕГДА белый
                SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, menu->menu_items[i], COLOR_WHITE);
                
                if (text) {
                    // Центрируем текст
                    int text_x = (menu->width - text->w) / 2;
                    int text_y = item_y + (menu->item_height - text->h) / 2;
                    
                    // Рисуем тень для всех пунктов
                    SDL_Surface* shadow = TTF_RenderUTF8_Blended(font.large, menu->menu_items[i], COLOR_BLACK_V);
                    SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                  &(SDL_Rect){text_x - 1, text_y - 1});
                    SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                  &(SDL_Rect){text_x - 1, text_y + 1});
                    SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                  &(SDL_Rect){text_x + 1, text_y - 1});
                    SDL_BlitSurface(shadow, NULL, menu->menu_surface, 
                                  &(SDL_Rect){text_x + 1, text_y + 1});
                    SDL_FreeSurface(shadow);
                    
                    // Основной текст (всегда белый)
                    SDL_BlitSurface(text, NULL, menu->menu_surface, 
                                  &(SDL_Rect){text_x, text_y});
                    SDL_FreeSurface(text);
                }
            }
            
            // 2. Затем рисуем ПОДЛОЖКУ на отдельной поверхности (поверх всего)
            if (overlay_surface) {
                // Анимация перемещения подложки
                if (menu_anim.anim_frame > 0 && 
                    menu_anim.old_selected >= 0 && menu_anim.old_selected < menu->item_count &&
                    menu_anim.new_selected >= 0 && menu_anim.new_selected < menu->item_count) {
                    
                    // ИСПРАВЛЕННЫЙ РАСЧЕТ ПРОГРЕССА: учитываем все кадры включая последний
                    float anim_progress;
                    if (menu_anim.anim_frame == 0) {
                        // Последний кадр - анимация завершена
                        anim_progress = 1.0f;
                    } else {
                        // Плавное изменение прогресса
                        anim_progress = 1.0f - ((float)menu_anim.anim_frame / (float)MENU_ANIMATION_SPEED);
                    }
                    
                    // Рассчитываем позиции для анимации
                    int old_y = items_start_y + (menu_anim.old_selected * (menu->item_height + item_spacing));
                    int new_y = items_start_y + (menu_anim.new_selected * (menu->item_height + item_spacing));
                    
                    // Плавное движение подложки
                    float current_y = old_y + (new_y - old_y) * anim_progress;
                    
                    // Размеры подложки
                    int pill_padding = 10;
                    int pill_width = menu->width - (pill_padding * 2);
                    int pill_height = menu->item_height - 3;
                    int pill_x = (menu->width - pill_width) / 2;
                    
                    // Рисуем анимированную подложку
                    GFX_blitPill(ASSET_WHITE_PILL, overlay_surface, 
                               &(SDL_Rect){pill_x, (int)current_y + 2, pill_width, pill_height});
                    
                    // Определяем какой текст показывать во время анимации
                    int show_index;
                    if (anim_progress >= 1.0f) {
                        // Анимация завершена - показываем новый выбранный элемент
                        show_index = menu_anim.new_selected;
                    } else if (anim_progress <= 0.0f) {
                        // Начало анимации - показываем старый элемент
                        show_index = menu_anim.old_selected;
                    } else {
                        // Во время анимации - плавный переход между текстами
                        show_index = (anim_progress < 0.5f) ? menu_anim.old_selected : menu_anim.new_selected;
                    }
                    
                    // Рисуем текст для текущего состояния анимации
                    if (show_index >= 0 && show_index < menu->item_count) {
                        SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, menu->menu_items[show_index], COLOR_BLACK_V);
                        
                        if (text) {
                            int text_x = pill_padding + (pill_width - text->w) / 2;
                            int text_y = (int)current_y + (menu->item_height - text->h) / 2;
                            SDL_BlitSurface(text, NULL, overlay_surface, 
                                          &(SDL_Rect){text_x, text_y});
                            SDL_FreeSurface(text);
                        }
                    }
                } 
                // Статическая подложка (без анимации или после завершения анимации)
                else if (menu->selected_option >= 0 && menu->selected_option < menu->item_count) {
                    int item_y = items_start_y + (menu->selected_option * (menu->item_height + item_spacing));
                    
                    // Размеры подложки
                    int pill_padding = 10;
                    int pill_width = menu->width - (pill_padding * 2);
                    int pill_height = menu->item_height - 3;
                    
                    // Центрируем подложку
                    int pill_x = (menu->width - pill_width) / 2;
                    
                    GFX_blitPill(ASSET_WHITE_PILL, overlay_surface, 
                               &(SDL_Rect){pill_x, item_y + 2, pill_width, pill_height});
                    
                    // Текст черным на белой подложке
                    SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, menu->menu_items[menu->selected_option], COLOR_BLACK_V);
                    
                    if (text) {
                        int text_x = pill_padding + (pill_width - text->w) / 2;
                        int text_y = item_y + (menu->item_height - text->h) / 2;
                        SDL_BlitSurface(text, NULL, overlay_surface, 
                                      &(SDL_Rect){text_x, text_y});
                        SDL_FreeSurface(text);
                    }
                }
                
                // Накладываем поверхность с подложкой поверх всего меню
                SDL_BlitSurface(overlay_surface, NULL, menu->menu_surface, NULL);
                SDL_FreeSurface(overlay_surface);
            }
        }
    }
    
    if (menu->anim_frame > 0) {
        menu->anim_frame--;
    }
    
    // Устанавливаем цветовой ключ и рисуем на экран
    SDL_SetColorKey(menu->menu_surface, SDL_TRUE, 0xDEDB);
    SDL_BlitSurface(menu->menu_surface, NULL, screen, &(SDL_Rect){x, y});
}

// Обновленная функция очистки меню
static void freeGenericMenuDialog(GenericMenuDialog* menu) {
    if (!menu) return;
    
    if (menu->menu_surface) {
        SDL_FreeSurface(menu->menu_surface);
    }
    
    if (menu->menu_items) {
        for (int i = 0; i < menu->item_count; i++) {
            free(menu->menu_items[i]);
        }
        free(menu->menu_items);
    }
    
    // Освобождаем заголовок если есть
    if (menu->title) {
        free(menu->title);
    }
    
    free(menu);
}

// Обновленная функция отображения меню с поддержкой заголовка
static int showGenericMenuDialogWithTitle(char** items, int item_count, 
                                         int border_color, int bg_color, 
                                         SDL_Surface* screen, const char* title) {
    if (!items || item_count <= 0 || !screen) return -1;
    
    uint32_t now = SDL_GetTicks();
    GenericMenuDialog* menu = createGenericMenuDialogWithTitle(items, item_count, 
                                                              border_color, bg_color, 
                                                              animation, title);
    if (!menu) return -1;
    
    // Сбрасываем анимацию меню
    menu_anim.anim_frame = 0;
    
    // Сохраняем текущий экран как фон
    SDL_Surface* background = SDL_CreateRGBSurface(0, screen->w, screen->h, 
                                                  screen->format->BitsPerPixel,
                                                  screen->format->Rmask,
                                                  screen->format->Gmask,
                                                  screen->format->Bmask, 0);
    if (background) {
        SDL_BlitSurface(screen, NULL, background, NULL);
    }
    
    int result = -1;
    int quit = 0;
    int old_selected = 0;
    
    while (!quit && menu->visible) {
        PAD_poll();
        
        // Обновляем анимацию
        updateMenuAnimation();
        
        // Обработка ввода
        // Упрощенный вариант - просто убираем вызов startMenuAnimation для циклических переходов:

                if (PAD_justPressed(BTN_UP)) {
                if (menu->selected_option > 0) {
                        old_selected = menu->selected_option;
                        menu->selected_option--;
                        // Запускаем ускоренную анимацию перемещения вверх
                        if (animation) {
                        startMenuAnimation(old_selected, menu->selected_option, 1);
                        }
                        dirty = 1;
                } else {
                        // Циклический переход на последний элемент - БЕЗ АНИМАЦИИ
                        menu->selected_option = menu->item_count - 1;
                        // Просто обновляем без анимации
                        dirty = 1;
                }
                } else if (PAD_justPressed(BTN_DOWN)) {
                if (menu->selected_option < menu->item_count - 1) {
                        old_selected = menu->selected_option;
                        menu->selected_option++;
                        // Запускаем ускоренную анимацию перемещения вниз
                        if (animation) {
                        startMenuAnimation(old_selected, menu->selected_option, -1);
                        }
                        dirty = 1;
                } else {
                        // Циклический переход на первый элемент - БЕЗ АНИМАЦИИ
                        menu->selected_option = 0;
                        // Просто обновляем без анимации
                        dirty = 1;
                }
                } else if (PAD_justPressed(getButtonA())) {
            result = menu->selected_option;
            quit = 1;
        } else if (PAD_justPressed(getButtonB()) || PAD_tappedMenu(now)) {
            result = -1;
            quit = 1;
        }
        
        // Перерисовка
        if (dirty || menu->anim_frame > 0 || menu_anim.anim_frame > 0 || PLAT_isPopupActive()) {
            if (background) {
                SDL_BlitSurface(background, NULL, screen, NULL);
            }
            
            drawGenericMenuDialog(menu, screen);
            GFX_flip(screen);
            dirty = 0;
            SDL_Delay(16);
        } else {
            GFX_sync();
        }
    }
    
    // Восстанавливаем состояние кнопок
    PAD_poll();
    PAD_reset();
    SDL_Delay(50);
    PAD_poll();
    
    // Очистка
    if (background) {
        SDL_FreeSurface(background);
    }
    
    freeGenericMenuDialog(menu);
    
    return result;
}

// Функция без заголовка для обратной совместимости
static int showGenericMenuDialog(char** items, int item_count, 
                                int border_color, int bg_color, 
                                SDL_Surface* screen) {
    return showGenericMenuDialogWithTitle(items, item_count, border_color, 
                                         bg_color, screen, NULL);
}

void loadSettingsFromIni() {
    int color_select = 0;
    const char* colors_name_in_ini[] = {"yellow", "green", "blue", "red", "violet"};
    
    if (ini_haskey("sleep", "val", inifile)) {
        PWR_changeSleepDelay(ini_getl("sleep", "val", -1, inifile));
    }
    if (ini_haskey("animation", "val", inifile))
        animation = ini_getl("animation", "val", -1, inifile);
    if (ini_haskey("animation", "speed", inifile))
        animation_speed = (3 - ini_getl("animation", "speed", -1, inifile)) * 4;
    if (animation_speed > 12 || animation_speed < 0)
        animation_speed = 12;
    
    if (ini_haskey("color", "val", inifile)) {
        int r, g, b;
        char str[7];
        color_select = ini_getl("color", "val", -1, inifile);
        if (color_select > 5 || color_select < 0)
            color_select = 0;
        for (int i = 0; i < 5; i++) {
            if (ini_haskey("color", colors_name_in_ini[i], inifile)) {
                if (ini_gets("color", colors_name_in_ini[i], "dummy", str, 7, inifile)) {
                    sscanf(str, "%02x%02x%02x", &r, &g, &b);
                    colors_b[i + 1][0] = r;
                    colors_b[i + 1][1] = g;
                    colors_b[i + 1][2] = b;
                }
            }
        }
    }
    
    if (ini_haskey("themes", "val", inifile)) {
        ini_gets("themes", "val", "default", select_themes, 256, inifile);
    }
    if (ini_haskey("animation", "preview_type", inifile)) {
        preview_transition = ini_getl("animation", "preview_type", 0, inifile);
        if (preview_transition > 4 || preview_transition < 0)
            preview_transition = 0;
    }
    if (ini_haskey("screen", "list", inifile)) {
        one_name_on_screen = ini_getl("screen", "list", -1, inifile);
    }
    if (ini_haskey("screen", "scrollbar", inifile)) {
        scroll_bar_view = ini_getl("screen", "scrollbar", -1, inifile);
        if (scroll_bar_view > 2 || scroll_bar_view < 0)
            scroll_bar_view = 1;
    }
    
    if (ini_haskey("folders", "show_empty", inifile)) {
        show_empty_folders = ini_getl("folders", "show_empty", 1, inifile) ? 1 : 0;
    }
    
    color_triad_black_r = colors_b[color_select][0];
    color_triad_black_g = colors_b[color_select][1];
    color_triad_black_b = colors_b[color_select][2];
    language_init(-1);
}

char find_string[256] = {'\0'};
int isFind = 0;

typedef struct Array {
    int count;
    int capacity;
    void** items;
} Array;

static Array* Array_new(void) {
    Array* self = malloc(sizeof(Array));
    self->count = 0;
    self->capacity = 8;
    self->items = malloc(sizeof(void*) * self->capacity);
    return self;
}

static void Array_push(Array* self, void* item) {
    if (self->count >= self->capacity) {
        self->capacity *= 2;
        self->items = realloc(self->items, sizeof(void*) * self->capacity);
    }
    self->items[self->count++] = item;
}

static void Array_unshift(Array* self, void* item) {
    if (self->count == 0) return Array_push(self, item);
    Array_push(self, NULL);
    for (int i = self->count - 2; i >= 0; i--) {
        self->items[i + 1] = self->items[i];
    }
    self->items[0] = item;
}

static void* Array_pop(Array* self) {
    if (self->count == 0) return NULL;
    return self->items[--self->count];
}

static void Array_reverse(Array* self) {
    int end = self->count - 1;
    int mid = self->count / 2;
    for (int i = 0; i < mid; i++) {
        void* item = self->items[i];
        self->items[i] = self->items[end - i];
        self->items[end - i] = item;
    }
}

static void Array_free(Array* self) {
    free(self->items);
    free(self);
}

static int StringArray_indexOf(Array* self, char* str) {
    for (int i = 0; i < self->count; i++) {
        if (exactMatch(self->items[i], str)) return i;
    }
    return -1;
}

static void StringArray_free(Array* self) {
    for (int i = 0; i < self->count; i++) {
        free(self->items[i]);
    }
    Array_free(self);
}

static int viewer_mode = 0;
static Array* viewer_images = NULL;
static int viewer_index = 0;
static SDL_Surface* viewer_current = NULL;
static SDL_Surface* viewer_original = NULL;
static int viewer_zoom = 100; // процент масштабирования
static int viewer_rotation = 0; // 0, 90, 180, 270 градусов
static int viewer_filter = 0; // 0=нормальный, 1=черно-белый
static int viewer_pan_x = 0;
static int viewer_pan_y = 0;
static int viewer_info_visible = 1;
static int viewer_fullscreen = 0;

static SDL_Surface* convertAlphaToColorKey(SDL_Surface* src) {
    if (!src || !src->format->Amask) return src; // уже без альфы — возвращаем как есть

    // Создаём новую поверхность без альфа-канала
    SDL_Surface* dst = SDL_CreateRGBSurface(0, src->w, src->h, 32,
        screen->format->Rmask, screen->format->Gmask, screen->format->Bmask, 0);
    if (!dst) return src;

    // Магический цвет: пурпурный (0xFF00FF) — его не должно быть в реальных превью
    Uint32 color_key = SDL_MapRGB(dst->format, 0xFF, 0x00, 0xFF);
    SDL_FillRect(dst, NULL, color_key);

    // Копируем непрозрачные пиксели
    SDL_LockSurface(src);
    SDL_LockSurface(dst);

    int bpp = src->format->BytesPerPixel;
    Uint32 amask = src->format->Amask;
    Uint8 r, g, b, a;
    for (int y = 0; y < src->h; y++) {
        for (int x = 0; x < src->w; x++) {
            Uint32 pixel = *((Uint32*)((Uint8*)src->pixels + y * src->pitch + x * bpp));
            SDL_GetRGBA(pixel, src->format, &r, &g, &b, &a);
            if (a > 127) { // порог: >50% непрозрачности — рисуем
                Uint32 dst_pixel = SDL_MapRGB(dst->format, r, g, b);
                *((Uint32*)((Uint8*)dst->pixels + y * dst->pitch + x * 4)) = dst_pixel;
            }
            // иначе — оставляем color_key (прозрачный)
        }
    }

    SDL_UnlockSurface(dst);
    SDL_UnlockSurface(src);
    SDL_FreeSurface(src); // освобождаем оригинал

    // Устанавливаем цветовой ключ
    SDL_SetColorKey(dst, SDL_TRUE, color_key);

    return dst;
}

void get_name(char* pt, char* name, const char* path) {
    size_t n;
    const char* a, *b = path + strlen(path);
    if (b > path)
        --b;
    
    a = b;
    while ((a >= path) && (*a != '\\') && (*a != '/')) {
        --a;
    }
    
    if (a < path)
        return;
    ++a;
    
    n = (size_t)(b - a);
    strncpy(name, a, n + 1);
    name[n + 1] = '\0';
    strncpy(pt, path, strlen(path) - n);
    pt[strlen(path) - n - 1] = '\0';
}

typedef struct Hash {
    Array* keys;
    Array* values;
} Hash;

static Hash* Hash_new(void) {
    Hash* self = malloc(sizeof(Hash));
    self->keys = Array_new();
    self->values = Array_new();
    return self;
}

static void Hash_free(Hash* self) {
    StringArray_free(self->keys);
    StringArray_free(self->values);
    free(self);
}

static void Hash_set(Hash* self, char* key, char* value) {
    Array_push(self->keys, strdup(key));
    Array_push(self->values, strdup(value));
}

static char* Hash_get(Hash* self, char* key) {
    int i = StringArray_indexOf(self->keys, key);
    if (i == -1) return NULL;
    return self->values->items[i];
}

enum EntryType {
    ENTRY_DIR,
    ENTRY_PAK,
    ENTRY_ROM,
    ENTRY_IMAGE,
};

typedef struct Entry {
    char* path;
    char* name;
    char* unique;
    int type;
    int alpha;
} Entry;

static void getLocalizedDisplayName(const char* path, char* out) {
    // Шаг 1: Получаем стандартное отображаемое имя
    getDisplayName(path, out);

    // Шаг 2: Определяем базовое имя для сравнения
    const char* basename = strrchr(path, '/');
    if (basename == NULL) basename = path;
    else basename++;

    // Шаг 3: Заменяем на локализованные имена для виртуальных папок
    if (exactMatch((char*)path, FAUX_FAVORITE_PATH)) {
        strcpy(out, language_get_string("FAVORITES"));
        return;
    }
    if (exactMatch((char*)path, FAUX_RECENT_PATH)) {
        strcpy(out, language_get_string("RECENTLY_PLAYED"));
        return;
    }
    if (exactMatch((char*)path, SCREENSHOTS_PATH)) {
        strcpy(out, language_get_string("SCREENSHOTS")); // Нужно добавить строку в языковые файлы
        return;
    }
    if (exactMatch((char*)path, SDCARD_PATH "/Tools/" PLATFORM)) {
        strcpy(out, language_get_string("TOOLS"));
        return;
    }

    // Шаг 4: Локализация для .pak-папок
    if (suffixMatch(".pak", (char*)basename)) {
        static char key[256];
        snprintf(key, sizeof(key), "PAK_%s", basename);
        const char* localized = language_get_string(key);
        // language_get_string вернёт оригинал, если нет перевода
        // Но нам нужно **сохранить именно оригинальное имя из getDisplayName**,
        // если перевода нет. Однако getDisplayName уже удалил ".pak"!
        // → Поэтому лучше использовать basename напрямую при отсутствии перевода.

        // Проверим: если перевод совпадает с ключом — значит, перевода нет
        if (strcmp(localized, key) == 0) {
            // Нет перевода — оставляем то, что дал getDisplayName()
            // (оно уже без .pak)
            return;
        } else {
            strcpy(out, localized);
            return;
        }
    }
}

static Entry* Entry_new(char* path, int type) {
    char display_name[256];
        getLocalizedDisplayName(path, display_name);
    Entry* self = malloc(sizeof(Entry));
    self->path = strdup(path);
    self->name = strdup(display_name);
    self->unique = NULL;
    self->type = type;
    self->alpha = 0;
    return self;
}

static void Entry_free(Entry* self) {
    free(self->path);
    free(self->name);
    if (self->unique) free(self->unique);
    free(self);
}

static int EntryArray_indexOf(Array* self, char* path) {
    for (int i = 0; i < self->count; i++) {
        Entry* entry = self->items[i];
        if (exactMatch(entry->path, path)) return i;
    }
    return -1;
}

static int EntryArray_sortEntry(const void* a, const void* b) {
    Entry* item1 = *(Entry**)a;
    Entry* item2 = *(Entry**)b;
    return strcasecmp(item1->name, item2->name);
}

static void EntryArray_sort(Array* self) {
    qsort(self->items, self->count, sizeof(void*), EntryArray_sortEntry);
}

static void EntryArray_free(Array* self) {
    for (int i = 0; i < self->count; i++) {
        Entry_free(self->items[i]);
    }
    Array_free(self);
}

#define INT_ARRAY_MAX 27
typedef struct IntArray {
    int count;
    int items[INT_ARRAY_MAX];
} IntArray;

static IntArray* IntArray_new(void) {
    IntArray* self = malloc(sizeof(IntArray));
    self->count = 0;
    memset(self->items, 0, sizeof(int) * INT_ARRAY_MAX);
    return self;
}

static void IntArray_push(IntArray* self, int i) {
    self->items[self->count++] = i;
}

static void IntArray_free(IntArray* self) {
    free(self);
}

typedef struct Directory {
    char* path;
    char* name;
    Array* entries;
    IntArray* alphas;
    int selected;
    int start;
    int end;
} Directory;

static int getIndexChar(char* str) {
    char i = 0;
    char c = tolower(str[0]);
    if (c >= 'a' && c <= 'z') i = (c - 'a') + 1;
    return i;
}

static void getUniqueName(Entry* entry, char* out_name) {
    char* filename = strrchr(entry->path, '/') + 1;
    char emu_tag[256];
    getEmuName(entry->path, emu_tag);
    
    strcpy(out_name, entry->name);
    char* tmp = out_name + strlen(out_name);
    strcpy(tmp, " (");
    tmp = out_name + strlen(out_name);
    strcpy(tmp, emu_tag);
    tmp = out_name + strlen(out_name);
    strcpy(tmp, ")");
}

static void Directory_index(Directory* self) {
    int skip_index = exactMatch(FAUX_RECENT_PATH, self->path) || 
                     exactMatch(FAUX_FAVORITE_PATH, self->path) || 
                     prefixMatch(COLLECTIONS_PATH, self->path);
    
    Hash* map = NULL;
    char map_path[256];
    sprintf(map_path, "%s/map.txt", self->path);
    if (exists(map_path)) {
        FILE* file = fopen(map_path, "r");
        if (file) {
            map = Hash_new();
            char line[256];
            int resort = 0;
            while (fgets(line, 256, file) != NULL) {
                normalizeNewline(line);
                trimTrailingNewlines(line);
                if (strlen(line) == 0) continue;
                
                char* tmp = strchr(line, '\t');
                if (tmp) {
                    tmp[0] = '\0';
                    char* key = line;
                    char* value = tmp + 1;
                    Hash_set(map, key, value);
                }
            }
            fclose(file);
            
            for (int i = 0; i < self->entries->count; i++) {
                Entry* entry = self->entries->items[i];
                char* filename = strrchr(entry->path, '/') + 1;
                char* alias = Hash_get(map, filename);
                if (alias) {
                    free(entry->name);
                    entry->name = strdup(alias);
                    resort = 1;
                }
            }
            
            if (resort) EntryArray_sort(self->entries);
        }
    }
    
    Entry* prior = NULL;
    int alpha = -1;
    int index = 0;
    for (int i = 0; i < self->entries->count; i++) {
        Entry* entry = self->entries->items[i];
        if (map) {
            char* filename = strrchr(entry->path, '/') + 1;
            char* alias = Hash_get(map, filename);
            if (alias) {
                free(entry->name);
                entry->name = strdup(alias);
            }
        }
        
        if (prior != NULL && exactMatch(prior->name, entry->name)) {
            if (prior->unique) free(prior->unique);
            if (entry->unique) free(entry->unique);
            
            char* prior_filename = strrchr(prior->path, '/') + 1;
            char* entry_filename = strrchr(entry->path, '/') + 1;
            if (exactMatch(prior_filename, entry_filename)) {
                char prior_unique[256];
                char entry_unique[256];
                getUniqueName(prior, prior_unique);
                getUniqueName(entry, entry_unique);
                
                prior->unique = strdup(prior_unique);
                entry->unique = strdup(entry_unique);
            } else {
                prior->unique = strdup(prior_filename);
                entry->unique = strdup(entry_filename);
            }
        }
        
        if (!skip_index) {
            int a = getIndexChar(entry->name);
            if (a != alpha) {
                index = self->alphas->count;
                IntArray_push(self->alphas, i);
                alpha = a;
            }
            entry->alpha = index;
        }
        
        prior = entry;
    }
    
    if (map) Hash_free(map);
}

static Array* getRoot(void);
static Array* getRecents(void);
static Array* getFavorites(void);
static Array* getCollection(char* path);
static Array* getDiscs(char* path);
static Array* getEntries(char* path);

static Directory* Directory_new(char* path, int selected) {
    char display_name[256];
    getLocalizedDisplayName(path, display_name);
    
    Directory* self = malloc(sizeof(Directory));
    self->path = strdup(path);
    self->name = strdup(display_name);
    root_directory = 0;
    
    if (exactMatch(path, SDCARD_PATH)) {
        self->entries = getRoot();  // УЖЕ в правильном порядке
        root_directory = 1;
    } else if (exactMatch(path, FAUX_RECENT_PATH)) {
        self->entries = getRecents();  // УЖЕ в правильном порядке
    } else if (exactMatch(path, FAUX_FAVORITE_PATH)) {
        self->entries = getFavorites();  // УЖЕ в правильном порядке
    } else if (!exactMatch(path, COLLECTIONS_PATH) && prefixMatch(COLLECTIONS_PATH, path) && suffixMatch(".txt", path)) {
        self->entries = getCollection(path);
        // Коллекции сортируем
        EntryArray_sort(self->entries);
    } else if (suffixMatch(".m3u", path)) {
        self->entries = getDiscs(path);
        // Диски не сортируем (уже в порядке)
    } else {
        self->entries = getEntries(path);
        // ВСЕ остальные папки сортируем
        EntryArray_sort(self->entries);
    }
    
    self->alphas = IntArray_new();
    self->selected = selected;
    
    // Индексируем ТОЛЬКО если не Recent/Favorites/Collections
    int skip_index = exactMatch(FAUX_RECENT_PATH, self->path) || 
                     exactMatch(FAUX_FAVORITE_PATH, self->path) || 
                     prefixMatch(COLLECTIONS_PATH, self->path);
    
    if (!skip_index) {
        Directory_index(self);
    }
    
    return self;
}

static void Directory_free(Directory* self) {
    free(self->path);
    free(self->name);
    EntryArray_free(self->entries);
    IntArray_free(self->alphas);
    free(self);
}

static void DirectoryArray_pop(Array* self) {
    Directory_free(Array_pop(self));
}

static void DirectoryArray_free(Array* self) {
    for (int i = 0; i < self->count; i++) {
        Directory_free(self->items[i]);
    }
    Array_free(self);
}

typedef struct Recent {
    char* path;
    char* alias;
    int available;
} Recent;

static char* recent_alias = NULL;

static int hasEmu(char* emu_name);
static Recent* Recent_new(char* path, char* alias) {
    Recent* self = malloc(sizeof(Recent));
    char sd_path[256];
    sprintf(sd_path, "%s%s", SDCARD_PATH, path);
    char emu_name[256];
    getEmuName(sd_path, emu_name);
    
    self->path = strdup(path);
    self->alias = alias ? strdup(alias) : NULL;
    self->available = hasEmu(emu_name);
    return self;
}

static void Recent_free(Recent* self) {
    free(self->path);
    if (self->alias) free(self->alias);
    free(self);
}

static int RecentArray_indexOf(Array* self, char* str) {
    for (int i = 0; i < self->count; i++) {
        Recent* item = self->items[i];
        if (exactMatch(item->path, str)) return i;
    }
    return -1;
}

static void RecentArray_free(Array* self) {
    for (int i = 0; i < self->count; i++) {
        Recent_free(self->items[i]);
    }
    Array_free(self);
}

typedef struct Favorite {
    char* path;
    int available;
} Favorite;

static Favorite* Favorite_new(char* path) {
    Favorite* self = malloc(sizeof(Favorite));
    char sd_path[256];
    sprintf(sd_path, "%s%s", SDCARD_PATH, path);
    char emu_name[256];
    getEmuName(sd_path, emu_name);
    
    self->path = strdup(path);
    self->available = hasEmu(emu_name);
    return self;
}

static void Favorite_free(Favorite* self) {
    free(self->path);
    free(self);
}

static int FavoriteArray_indexOf(Array* self, char* str) {
    for (int i = 0; i < self->count; i++) {
        Favorite* item = self->items[i];
        if (exactMatch(item->path, str)) return i;
    }
    return -1;
}

static void FavoriteArray_free(Array* self) {
    for (int i = 0; i < self->count; i++) {
        Favorite_free(self->items[i]);
    }
    Array_free(self);
}

static int FavoriteArray_splice(Array* self, int index) {
    if (index != -1) {
        for (int i = index; i < self->count - 1; i++) {
            self->items[i] = self->items[i + 1];
        }
        --self->count;
    }
    return index;
}

static Directory* top;
static Array* stack;
static Array* recents;
static Array* favorites;

static int quit = 0;
static int can_resume = 0;
static int should_resume = 0;
static int simple_mode = 0;
static char slot_path[256];
static char bmp_slot_path[256];

static int restore_depth = -1;
static int restore_relative = -1;
static int restore_selected = 0;
static int restore_start = 0;
static int restore_end = 0;

#define MAX_RECENTS 24
static void saveRecents(void) {
    FILE* file = fopen(RECENT_PATH, "w");
    if (file) {
        for (int i = 0; i < recents->count; i++) {
            Recent* recent = recents->items[i];
            fputs(recent->path, file);
            if (recent->alias) {
                fputs("\t", file);
                fputs(recent->alias, file);
            }
            putc('\n', file);
        }
        fclose(file);
    }
}

static void addRecent(char* path, char* alias) {
    path += strlen(SDCARD_PATH);
    int id = RecentArray_indexOf(recents, path);
    if (id == -1) {
        while (recents->count >= MAX_RECENTS) {
            Recent_free(Array_pop(recents));
        }
        Array_unshift(recents, Recent_new(path, alias));
    } else if (id > 0) {
        for (int i = id; i > 0; i--) {
            void* tmp = recents->items[i - 1];
            recents->items[i - 1] = recents->items[i];
            recents->items[i] = tmp;
        }
    }
    saveRecents();
}

static void saveFavorites(void) {
    FILE* file = fopen(FAVORITE_PATH, "w");
    if (file) {
        for (int i = 0; i < favorites->count; i++) {
            Favorite* favorite = favorites->items[i];
            fputs(favorite->path, file);
            putc('\n', file);
        }
        fclose(file);
    }
}

static void toggleFavorite(char* path) {
    path += strlen(SDCARD_PATH);
    int id = FavoriteArray_indexOf(favorites, path);
    if (id == -1) {
        Array_unshift(favorites, Favorite_new(path));
    } else {
        FavoriteArray_splice(favorites, id);
    }
    saveFavorites();
}

static int isImageFile(const char* path) {
    if (!path) return 0;
    
    const char* ext = strrchr(path, '.');
    if (!ext) return 0;
    
    ext++; // Пропускаем точку
    
    // Проверяем расширения изображений
    if (strcasecmp(ext, "bmp") == 0 ||
        strcasecmp(ext, "png") == 0 || //является ромом для pico8
        strcasecmp(ext, "jpg") == 0 ||
        strcasecmp(ext, "jpeg") == 0 ||
        strcasecmp(ext, "gif") == 0 ||
        strcasecmp(ext, "tga") == 0) {
        return 1;
    }
    
    return 0;
}

static int isFavorite(char* path) {
    path += strlen(SDCARD_PATH);
    int id = FavoriteArray_indexOf(favorites, path);
    return ++id;
}

static int hasEmu(char* emu_name) {
    char pak_path[256];
    sprintf(pak_path, "%s/Emus/%s.pak/launch.sh", PAKS_PATH, emu_name);
    if (exists(pak_path)) return 1;
    
    sprintf(pak_path, "%s/Emus/%s/%s.pak/launch.sh", SDCARD_PATH, PLATFORM, emu_name);
    return exists(pak_path);
}

static int hasCue(char* dir_path, char* cue_path) {
    char* tmp = strrchr(dir_path, '/') + 1;
    sprintf(cue_path, "%s/%s.cue", dir_path, tmp);
    return exists(cue_path);
}

static int hasM3u(char* rom_path, char* m3u_path) {
    strcpy(m3u_path, rom_path);
    char* tmp = strrchr(m3u_path, '/') + 1;
    tmp[0] = '\0';
    
    char base_path[256];
    strcpy(base_path, m3u_path);
    
    tmp = strrchr(m3u_path, '/');
    tmp[0] = '\0';
    
    char dir_name[256];
    tmp = strrchr(m3u_path, '/');
    strcpy(dir_name, tmp);
    
    tmp = m3u_path + strlen(m3u_path);
    strcpy(tmp, dir_name);
    tmp = m3u_path + strlen(m3u_path);
    strcpy(tmp, ".m3u");
    
    return exists(m3u_path);
}

static int hasRecents(void) {
    int has = 0;
    Array* parent_paths = Array_new();
    
    if (exists(CHANGE_DISC_PATH)) {
        char sd_path[256];
        getFile(CHANGE_DISC_PATH, sd_path, 256);
        if (exists(sd_path)) {
            char* disc_path = sd_path + strlen(SDCARD_PATH);
            Recent* recent = Recent_new(disc_path, NULL);
            if (recent->available) has += 1;
            Array_push(recents, recent);
            
            char parent_path[256];
            strcpy(parent_path, disc_path);
            char* tmp = strrchr(parent_path, '/') + 1;
            tmp[0] = '\0';
            Array_push(parent_paths, strdup(parent_path));
        }
        unlink(CHANGE_DISC_PATH);
    }
    
    FILE* file = fopen(RECENT_PATH, "r");
    if (file) {
        char line[256];
        while (fgets(line, 256, file) != NULL) {
            normalizeNewline(line);
            trimTrailingNewlines(line);
            if (strlen(line) == 0) continue;
            
            char* path = line;
            char* alias = NULL;
            char* tmp = strchr(line, '\t');
            if (tmp) {
                tmp[0] = '\0';
                alias = tmp + 1;
            }
            
            char sd_path[256];
            sprintf(sd_path, "%s%s", SDCARD_PATH, path);
            if (exists(sd_path)) {
                if (recents->count < MAX_RECENTS) {
                    char m3u_path[256];
                    if (hasM3u(sd_path, m3u_path)) {
                        char parent_path[256];
                        strcpy(parent_path, path);
                        char* tmp = strrchr(parent_path, '/') + 1;
                        tmp[0] = '\0';
                        
                        int found = 0;
                        for (int i = 0; i < parent_paths->count; i++) {
                            char* path = parent_paths->items[i];
                            if (prefixMatch(path, parent_path)) {
                                found = 1;
                                break;
                            }
                        }
                        if (found) continue;
                        
                        Array_push(parent_paths, strdup(parent_path));
                    }
                    
                    Recent* recent = Recent_new(path, alias);
                    if (recent->available) has += 1;
                    Array_push(recents, recent);
                }
            }
        }
        fclose(file);
    }
    
    saveRecents();
    StringArray_free(parent_paths);
    return 1;
}

static int hasFavorites(void) {
    int has = 0;
    FILE* file = fopen(FAVORITE_PATH, "r");
    if (file) {
        char line[256];
        while (fgets(line, 256, file) != NULL) {
            normalizeNewline(line);
            trimTrailingNewlines(line);
            if (strlen(line) == 0) continue;
            
            char sd_path[256];
            sprintf(sd_path, "%s%s", SDCARD_PATH, line);
            if (exists(sd_path)) {
                Favorite* favorite = Favorite_new(line);
                if (favorite->available) has += 1;
                Array_push(favorites, favorite);
            }
        }
        fclose(file);
    }
    
    saveFavorites();
    return 1;
}

static int hasCollections(void) {
    int has = 0;
    if (!exists(COLLECTIONS_PATH)) return has;
    
    DIR* dh = opendir(COLLECTIONS_PATH);
    struct dirent* dp;
    while ((dp = readdir(dh)) != NULL) {
        if (hide(dp->d_name)) continue;
        has = 1;
        break;
    }
    closedir(dh);
    return has;
}

// Функция для проверки, является ли папка пустой (не считая .res)
static int isFolderEmpty(const char* path) {
    DIR* dh = opendir(path);
    if (!dh) return 1;
    
    struct dirent* dp;
    int has_content = 0;
    
    while ((dp = readdir(dh)) != NULL) {
        // Пропускаем служебные директории
        if (strcmp(dp->d_name, ".") == 0 || strcmp(dp->d_name, "..") == 0)
            continue;
        
        // Пропускаем папку .res
        if (strcmp(dp->d_name, ".res") == 0)
            continue;
        
        // Если нашли любой другой файл или папку
        has_content = 1;
        break;
    }
    
    closedir(dh);
    return !has_content;
}


static int hasRoms(char* dir_name) {
    char emu_name[256];
    char rom_path[256];
    getEmuName(dir_name, emu_name);
    if (!hasEmu(emu_name)) return 0;

    // Если разрешено показывать пустые папки — показываем ВСЕГДА
    if (show_empty_folders) {
        return 1;
    }

    // Иначе — проверяем наличие ЛЮБОГО видимого содержимого
    sprintf(rom_path, "%s/%s/", ROMS_PATH, dir_name);
    DIR* dh = opendir(rom_path);
    if (!dh) return 0;

    struct dirent* dp;
    while ((dp = readdir(dh)) != NULL) {
        if (strcmp(dp->d_name, ".") == 0 || strcmp(dp->d_name, "..") == 0)
            continue;
        if (strcmp(dp->d_name, ".res") == 0)
            continue;
        if (hide(dp->d_name))
            continue;
        // Найден хотя бы один видимый файл/папка
        closedir(dh);
        return 1;
    }
    closedir(dh);
    return 0; // Ничего видимого нет → папка считается пустой
}

static int hasScreenshots(void) {
    if (!exists(SCREENSHOTS_PATH)) return 0;
    
    DIR* dh = opendir(SCREENSHOTS_PATH);
    if (!dh) return 0;
    
    struct dirent* dp;
    int has_images = 0;
    
    while ((dp = readdir(dh)) != NULL) {
        if (hide(dp->d_name)) continue;
        
        char full_path[512];
        sprintf(full_path, "%s/%s", SCREENSHOTS_PATH, dp->d_name);
        
        if (isImageFile(full_path)) {
            has_images = 1;
            break;
        }
    }
    
    closedir(dh);
    return has_images;
}

static Array* getRoot(void) {
    Array* root = Array_new();
    
    // 1. Recent и Favorite - СНАЧАЛА (как в старом коде)
    if (hasRecents()) Array_push(root, Entry_new(FAUX_RECENT_PATH, ENTRY_DIR));
    if (hasFavorites()) Array_push(root, Entry_new(FAUX_FAVORITE_PATH, ENTRY_DIR));
    
    // 2. Эмуляторы - в отдельный массив для сортировки
    Array* entries = Array_new();
    DIR* dh = opendir(ROMS_PATH);
    if (dh != NULL) {
        struct dirent* dp;
        char* tmp;
        char full_path[256];
        sprintf(full_path, "%s/", ROMS_PATH);
        tmp = full_path + strlen(full_path);
        Array* emus = Array_new();
        while ((dp = readdir(dh)) != NULL) {
            if (hide(dp->d_name)) continue;
            if (hasRoms(dp->d_name)) {
                strcpy(tmp, dp->d_name);
                Array_push(emus, Entry_new(full_path, ENTRY_DIR));
            }
        }
        // СОРТИРУЕМ только эмуляторы
        EntryArray_sort(emus);
        Entry* prev_entry = NULL;
        for (int i = 0; i < emus->count; i++) {
            Entry* entry = emus->items[i];
            if (prev_entry != NULL) {
                if (exactMatch(prev_entry->name, entry->name)) {
                    Entry_free(entry);
                    continue;
                }
            }
            Array_push(entries, entry);
            prev_entry = entry;
        }
        Array_free(emus);
        closedir(dh);
    }
    
    char map_path[256];
    sprintf(map_path, "%s/map.txt", ROMS_PATH);
    if (entries->count > 0 && exists(map_path)) {
        FILE* file = fopen(map_path, "r");
        if (file) {
            Hash* map = Hash_new();
            char line[256];
            int resort = 0;
            while (fgets(line, 256, file) != NULL) {
                normalizeNewline(line);
                trimTrailingNewlines(line);
                if (strlen(line) == 0) continue;
                
                char* tmp = strchr(line, '\t');
                if (tmp) {
                    tmp[0] = '\0';
                    char* key = line;
                    char* value = tmp + 1;
                    Hash_set(map, key, value);
                }
            }
            fclose(file);
            
            for (int i = 0; i < entries->count; i++) {
                Entry* entry = entries->items[i];
                char* filename = strrchr(entry->path, '/') + 1;
                char* alias = Hash_get(map, filename);
                if (alias) {
                    free(entry->name);
                    entry->name = strdup(alias);
                    resort = 1;
                }
            }
            if (resort) EntryArray_sort(entries);
            Hash_free(map);
        }
    }
    
    // 3. Collections (как в старом коде)
    if (hasCollections()) {
        if (entries->count) {
            // Есть эмуляторы - Collections отдельным пунктом
            Array_push(root, Entry_new(COLLECTIONS_PATH, ENTRY_DIR));
        } else {
            // Нет эмуляторов - коллекции как эмуляторы
            dh = opendir(COLLECTIONS_PATH);
            if (dh != NULL) {
                struct dirent* dp;
                char* tmp;
                char full_path[256];
                sprintf(full_path, "%s/", COLLECTIONS_PATH);
                tmp = full_path + strlen(full_path);
                Array* collections = Array_new();
                while ((dp = readdir(dh)) != NULL) {
                    if (hide(dp->d_name)) continue;
                    strcpy(tmp, dp->d_name);
                    Array_push(collections, Entry_new(full_path, ENTRY_DIR));
                }
                EntryArray_sort(collections);
                for (int i = 0; i < collections->count; i++) {
                    Array_push(entries, collections->items[i]);
                }
                Array_free(collections);
                closedir(dh);
            }
        }
    }
    
    // 4. Добавить отсортированные эмуляторы в root (ПОСЛЕ Recent/Favorites)
    for (int i = 0; i < entries->count; i++) {
        Array_push(root, entries->items[i]);
    }
    Array_free(entries);
    
    // 5. Screenshots - ПОСЛЕ эмуляторов, перед Tools (НОВОЕ)
    if (hasScreenshots()) {
        Array_push(root, Entry_new(SCREENSHOTS_PATH, ENTRY_DIR));
    }
    
    // 6. Tools - ВСЕГДА последний (как в старом коде)
    char* tools_path = SDCARD_PATH "/Tools/" PLATFORM;
    if (exists(tools_path) && !simple_mode) Array_push(root, Entry_new(tools_path, ENTRY_DIR));
    
    return root;
}

static Array* getRecents(void) {
    Array* entries = Array_new();
    for (int i = 0; i < recents->count; i++) {
        Recent* recent = recents->items[i];
        if (!recent->available) continue;
        
        char sd_path[256];
        sprintf(sd_path, "%s%s", SDCARD_PATH, recent->path);
        int type = suffixMatch(".pak", sd_path) ? ENTRY_PAK : ENTRY_ROM;
        Entry* entry = Entry_new(sd_path, type);
        if (recent->alias) {
            free(entry->name);
            entry->name = strdup(recent->alias);
        }
        Array_push(entries, entry);
    }
    return entries;
}

static Array* getFavorites(void) {
    Array* entries = Array_new();
    for (int i = 0; i < favorites->count; i++) {
        Favorite* favorite = favorites->items[i];
        if (!favorite->available) continue;
        
        char sd_path[256];
        sprintf(sd_path, "%s%s", SDCARD_PATH, favorite->path);
        int type = suffixMatch(".pak", sd_path) ? ENTRY_PAK : ENTRY_ROM;
        Array_push(entries, Entry_new(sd_path, type));
    }
    EntryArray_sort(entries);
    return entries;
}

static Array* getCollection(char* path) {
    Array* entries = Array_new();
    FILE* file = fopen(path, "r");
    if (file) {
        char line[256];
        while (fgets(line, 256, file) != NULL) {
            normalizeNewline(line);
            trimTrailingNewlines(line);
            if (strlen(line) == 0) continue;
            
            char sd_path[256];
            sprintf(sd_path, "%s%s", SDCARD_PATH, line);
            if (exists(sd_path)) {
                int type = suffixMatch(".pak", sd_path) ? ENTRY_PAK : ENTRY_ROM;
                Array_push(entries, Entry_new(sd_path, type));
            }
        }
        fclose(file);
    }
    return entries;
}

static Array* getDiscs(char* path) {
    Array* entries = Array_new();
    char base_path[256];
    strcpy(base_path, path);
    char* tmp = strrchr(base_path, '/') + 1;
    tmp[0] = '\0';
    
    FILE* file = fopen(path, "r");
    if (file) {
        char line[256];
        int disc = 0;
        while (fgets(line, 256, file) != NULL) {
            normalizeNewline(line);
            trimTrailingNewlines(line);
            if (strlen(line) == 0) continue;
            
            char disc_path[256];
            sprintf(disc_path, "%s%s", base_path, line);
            
            if (exists(disc_path)) {
                disc += 1;
                Entry* entry = Entry_new(disc_path, ENTRY_ROM);
                free(entry->name);
                char name[16];
                sprintf(name, "Disc %i", disc);
                entry->name = strdup(name);
                Array_push(entries, entry);
            }
        }
        fclose(file);
    }
    return entries;
}

static int getFirstDisc(char* m3u_path, char* disc_path) {
    int found = 0;
    char base_path[256];
    strcpy(base_path, m3u_path);
    char* tmp = strrchr(base_path, '/') + 1;
    tmp[0] = '\0';
    
    FILE* file = fopen(m3u_path, "r");
    if (file) {
        char line[256];
        while (fgets(line, 256, file) != NULL) {
            normalizeNewline(line);
            trimTrailingNewlines(line);
            if (strlen(line) == 0) continue;
            
            sprintf(disc_path, "%s%s", base_path, line);
            if (exists(disc_path)) found = 1;
            break;
        }
        fclose(file);
    }
    return found;
}

static void addEntries(Array* entries, char* path) {
    DIR* dh = opendir(path);
    if (dh != NULL) {
        struct dirent* dp;
        char* tmp;
        char full_path[256];
        char folder_path[256];
        sprintf(full_path, "%s/", path);
        tmp = full_path + strlen(full_path);
        
        // Определяем, мы в папке скриншотов или нет
        int is_screenshots_folder = prefixMatch(SCREENSHOTS_PATH, path);
        
        while ((dp = readdir(dh)) != NULL) {
            if (hide(dp->d_name)) continue;
            // Пропускаем папку .res
            if (strcmp(dp->d_name, ".res") == 0) {
                continue;
            }
            if (isFind) {
                if (dp->d_type == DT_DIR) {
                    sprintf(folder_path, "%s/%s/", full_path, dp->d_name);
                    addEntries(entries, folder_path);
                    continue;
                }
                if (!strcasestr_i(dp->d_name, find_string))
                    continue;
            }
            strcpy(tmp, dp->d_name);
            // Проверяем пустые папки если настройка отключена
            if (dp->d_type == DT_DIR && !show_empty_folders) {
                if (isFolderEmpty(full_path)) {
                    continue; // Пропускаем пустую папку
                }
            }
            int is_dir = dp->d_type == DT_DIR;
            int type;
            if (is_dir) {
                if (suffixMatch(".pak", dp->d_name)) {
                    type = ENTRY_PAK;
                } else {
                    type = ENTRY_DIR;
                }
            } else {
                // КЛЮЧЕВОЕ: В папке скриншотов - изображения как ENTRY_IMAGE
                if (is_screenshots_folder && isImageFile(full_path)) {
                    type = ENTRY_IMAGE;  // Только для скриншотов!
                } else {
                    // Всё остальное - старая логика
                    if (prefixMatch(COLLECTIONS_PATH, full_path)) {
                        type = ENTRY_DIR;
                    } else {
                        type = ENTRY_ROM;
                    }
                }
            }
            Array_push(entries, Entry_new(full_path, type));
        }
        closedir(dh);
    }
}

static void loadImagesForViewer(const char* start_image) {
    if (viewer_images) {
        StringArray_free(viewer_images);
    }
    
    viewer_images = Array_new();
    viewer_index = 0;
    
    // Получаем директорию из пути
    char directory[512];
    strcpy(directory, start_image);
    char* last_slash = strrchr(directory, '/');
    if (last_slash) {
        *last_slash = '\0';
    } else {
        // Если нет слешей, используем текущую директорию
        directory[0] = '.';
        directory[1] = '\0';
    }
    
    // Сканируем директорию на изображения
    DIR* dh = opendir(directory);
    if (dh != NULL) {
        struct dirent* dp;
        char full_path[512];
        
        // Сначала собираем все изображения
        while ((dp = readdir(dh)) != NULL) {
            if (dp->d_type != DT_REG) continue; // Только файлы
            
            sprintf(full_path, "%s/%s", directory, dp->d_name);
            if (isImageFile(full_path)) {
                Array_push(viewer_images, strdup(full_path));
            }
        }
        closedir(dh);
        
        // Сортируем по имени
        if (viewer_images->count > 0) {
            qsort(viewer_images->items, viewer_images->count, sizeof(void*), 
                  (int(*)(const void*, const void*))strcasecmp);
            
            // Находим индекс стартового изображения
            for (int i = 0; i < viewer_images->count; i++) {
                if (strcmp(viewer_images->items[i], start_image) == 0) {
                    viewer_index = i;
                    break;
                }
            }
        }
    }
}

static void viewer_load_image(void) {
    if (!viewer_images || viewer_images->count == 0) return;
    
    if (viewer_current) {
        SDL_FreeSurface(viewer_current);
        viewer_current = NULL;
    }
    
    if (viewer_original) {
        SDL_FreeSurface(viewer_original);
        viewer_original = NULL;
    }
    
    const char* image_path = viewer_images->items[viewer_index];
    
    // Загружаем изображение
    viewer_original = IMG_Load(image_path);
    if (!viewer_original) {
        // Если не удалось загрузить, пробуем SDL_LoadBMP для BMP файлов
        if (strstr(image_path, ".bmp") || strstr(image_path, ".BMP")) {
            viewer_original = SDL_LoadBMP(image_path);
        }
    }
    
    if (viewer_original) {
        // Применяем начальные трансформации
        viewer_apply_transformations();
    }
}

static void viewer_apply_transformations(void) {
    if (!viewer_original) return;
    
    if (viewer_current) {
        SDL_FreeSurface(viewer_current);
        viewer_current = NULL;
    }
    
    // Конвертируем поверхность к формату экрана
    SDL_Surface* filtered = SDL_ConvertSurface(viewer_original, screen->format, 0);
    if (!filtered) return;
    
    // Применяем масштабирование
    int new_width = (filtered->w * viewer_zoom) / 100;
    int new_height = (filtered->h * viewer_zoom) / 100;
    
    viewer_current = SDL_CreateRGBSurface(0, new_width, new_height,
                                          screen->format->BitsPerPixel,
                                          screen->format->Rmask,
                                          screen->format->Gmask,
                                          screen->format->Bmask, 0);
    
    if (viewer_current && filtered) {
        // Масштабирование
        SDL_Rect src_rect = {0, 0, filtered->w, filtered->h};
        SDL_Rect dst_rect = {0, 0, new_width, new_height};
        SDL_BlitScaled(filtered, &src_rect, viewer_current, &dst_rect);
    }
    
    if (filtered) SDL_FreeSurface(filtered);
}

static void viewer_cleanup(void) {
    if (viewer_current) {
        SDL_FreeSurface(viewer_current);
        viewer_current = NULL;
    }
    if (viewer_original) {
        SDL_FreeSurface(viewer_original);
        viewer_original = NULL;
    }
    if (viewer_images) {
        StringArray_free(viewer_images);
        viewer_images = NULL;
    }
    
    viewer_mode = 0;
    viewer_zoom = 100;
    viewer_rotation = 0;
    viewer_filter = 0;
    viewer_pan_x = 0;
    viewer_pan_y = 0;
    viewer_info_visible = 1;
    viewer_fullscreen = 0;
}

static void viewer_draw_image(void) {
    if (!viewer_current) return;
    
    // Очищаем экран
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    
    // Вычисляем позицию для отображения
    int draw_x = 0;
    int draw_y = 0;
    
    if (!viewer_fullscreen) {
        // Центрируем изображение
        draw_x = (screen->w - viewer_current->w) / 2 + viewer_pan_x;
        draw_y = (screen->h - viewer_current->h) / 2 + viewer_pan_y;
        
        // Ограничиваем панорамирование
        int max_pan_x = (viewer_current->w - screen->w) / 2;
        int max_pan_y = (viewer_current->h - screen->h) / 2;
        
        if (viewer_current->w <= screen->w) {
            viewer_pan_x = 0;
            draw_x = (screen->w - viewer_current->w) / 2;
        } else {
            if (viewer_pan_x > max_pan_x) viewer_pan_x = max_pan_x;
            if (viewer_pan_x < -max_pan_x) viewer_pan_x = -max_pan_x;
        }
        
        if (viewer_current->h <= screen->h) {
            viewer_pan_y = 0;
            draw_y = (screen->h - viewer_current->h) / 2;
        } else {
            if (viewer_pan_y > max_pan_y) viewer_pan_y = max_pan_y;
            if (viewer_pan_y < -max_pan_y) viewer_pan_y = -max_pan_y;
        }
    }
    
    // Рисуем изображение
    SDL_Rect src_rect = {0, 0, viewer_current->w, viewer_current->h};
    SDL_Rect dst_rect = {draw_x, draw_y, viewer_current->w, viewer_current->h};
    
    // Обрезаем, если изображение выходит за границы
    if (draw_x < 0) {
        src_rect.x = -draw_x;
        src_rect.w += draw_x;
        dst_rect.x = 0;
    }
    if (draw_y < 0) {
        src_rect.y = -draw_y;
        src_rect.h += draw_y;
        dst_rect.y = 0;
    }
    if (draw_x + viewer_current->w > screen->w) {
        src_rect.w = screen->w - draw_x;
    }
    if (draw_y + viewer_current->h > screen->h) {
        src_rect.h = screen->h - draw_y;
    }
    
    if (src_rect.w > 0 && src_rect.h > 0) {
        SDL_BlitSurface(viewer_current, &src_rect, screen, &dst_rect);
    }
}

static void viewer_draw_info(void) {
    if (!viewer_info_visible) return;
    
    // Отображаем информацию об изображении
    if (viewer_images && viewer_images->count > 0) {
        const char* path = viewer_images->items[viewer_index];
        const char* filename = strrchr(path, '/');
        if (filename) filename++;
        else filename = path;
        
        // Статусная строка сверху
        SDL_Rect status_rect = {0, 0, screen->w, 20};
        SDL_FillRect(screen, &status_rect, SDL_MapRGB(screen->format, 0, 0, 0));
        
        char status[256];
        snprintf(status, sizeof(status), "%s (%d/%d) %d%%", 
                filename, viewer_index + 1, viewer_images->count, viewer_zoom);
        
        SDL_Surface* status_text = TTF_RenderUTF8_Blended(font.small, status, COLOR_WHITE);
        if (status_text) {
            SDL_BlitSurface(status_text, NULL, screen, &(SDL_Rect){5, 2});
            SDL_FreeSurface(status_text);
        }
        
        // Информация о размере изображения
        if (viewer_original) {
            char size_info[128];
            snprintf(size_info, sizeof(size_info), "%dx%d", 
                    viewer_original->w, viewer_original->h);
            
            SDL_Surface* size_text = TTF_RenderUTF8_Blended(font.small, size_info, COLOR_WHITE);
            if (size_text) {
                SDL_BlitSurface(size_text, NULL, screen, 
                               &(SDL_Rect){screen->w - size_text->w - 5, 2});
                SDL_FreeSurface(size_text);
            }
        }
        
        // Подсказки внизу
        if (!viewer_fullscreen) {
            if(getSwapButtonAB() == 1)
                                GFX_blitButtonGroup((char*[]){ "L1/L2", "<-->", "A", language_get_string("BACK"), NULL }, 1, screen, 1);
                        else
                                GFX_blitButtonGroup((char*[]){ "L1/L2", "<-->", "B", language_get_string("BACK"), NULL }, 1, screen, 1);
        } else {
            // В полноэкранном режиме показываем только минимальные подсказки
            SDL_Rect hint_rect = {0, screen->h - 20, screen->w, 20};
            SDL_FillRect(screen, &hint_rect, SDL_MapRGB(screen->format, 0, 0, 0));
            
            char hints[256];
            snprintf(hints, sizeof(hints), "B: Назад | A: Выйти из полноэкранного");
            
            SDL_Surface* hints_text = TTF_RenderUTF8_Blended(font.small, hints, COLOR_WHITE);
            if (hints_text) {
                int x = (screen->w - hints_text->w) / 2;
                SDL_BlitSurface(hints_text, NULL, screen, &(SDL_Rect){x, screen->h - 18});
                SDL_FreeSurface(hints_text);
            }
        }
    }
}

static int isConsoleDir(char* path) {
    char* tmp;
    char parent_dir[256];
    strcpy(parent_dir, path);
    tmp = strrchr(parent_dir, '/');
    tmp[0] = '\0';
    return exactMatch(parent_dir, ROMS_PATH);
}

static Array* getEntries(char* path) {
    Array* entries = Array_new();
    
    if (isConsoleDir(path)) {
        char collated_path[256];
        strcpy(collated_path, path);
        char* tmp = strrchr(collated_path, '(');
        if (tmp) tmp[1] = '\0';
        
        DIR* dh = opendir(ROMS_PATH);
        if (dh != NULL) {
            struct dirent* dp;
            char full_path[256];
            sprintf(full_path, "%s/", ROMS_PATH);
            tmp = full_path + strlen(full_path);
            while ((dp = readdir(dh)) != NULL) {
                if (hide(dp->d_name)) continue;
                if (dp->d_type != DT_DIR) continue;
                strcpy(tmp, dp->d_name);
                
                if (!prefixMatch(collated_path, full_path)) continue;
                addEntries(entries, full_path);
            }
            closedir(dh);
        }
    } else if (exactMatch(path, SCREENSHOTS_PATH)) {
        // Специальная обработка для папки скриншотов
        DIR* dh = opendir(path);
        if (dh != NULL) {
            struct dirent* dp;
            char full_path[512];
            sprintf(full_path, "%s/", path);
            char* tmp = full_path + strlen(full_path);
            
            while ((dp = readdir(dh)) != NULL) {
                if (hide(dp->d_name)) continue;
                
                strcpy(tmp, dp->d_name);
                
                // Проверяем, является ли файл изображением
                if (isImageFile(full_path)) {
                    Array_push(entries, Entry_new(full_path, ENTRY_IMAGE));
                }
            }
            closedir(dh);
        }
        // Скриншоты сортируем
        EntryArray_sort(entries);
    } else {
        // Все остальные папки
        addEntries(entries, path);
        // СОРТИРУЕМ всегда
        EntryArray_sort(entries);
    }
    
    return entries;
}

static void queueNext(char* cmd) {
    putFile("/tmp/next", cmd);
    quit = 1;
}

static int replaceString(char* line, const char* search, const char* replace) {
    char* sp;
    if ((sp = strstr(line, search)) == NULL) {
        return 0;
    }
    int count = 1;
    int sLen = strlen(search);
    int rLen = strlen(replace);
    if (sLen > rLen) {
        char* src = sp + sLen;
        char* dst = sp + rLen;
        while ((*dst = *src) != '\0') {
            dst++;
            src++;
        }
    } else if (sLen < rLen) {
        int tLen = strlen(sp) - sLen;
        char* stop = sp + rLen;
        char* src = sp + sLen + tLen;
        char* dst = sp + rLen + tLen;
        while (dst >= stop) {
            *dst = *src;
            dst--;
            src--;
        }
    }
    memcpy(sp, replace, rLen);
    count += replaceString(sp + rLen, search, replace);
    return count;
}

static char* escapeSingleQuotes(char* str) {
    replaceString(str, "'", "'\\''");
    return str;
}

static void readyResumePath(char* rom_path, int type) {
    char* tmp;
    can_resume = 0;
    char path[256];
    strcpy(path, rom_path);
    
    if (!prefixMatch(ROMS_PATH, path)) return;
    
    char auto_path[256];
    if (type == ENTRY_DIR) {
        if (!hasCue(path, auto_path)) {
            tmp = strrchr(auto_path, '.') + 1;
            strcpy(tmp, "m3u");
            if (!exists(auto_path)) return;
        }
        strcpy(path, auto_path);
    }
    
    if (!suffixMatch(".m3u", path)) {
        char m3u_path[256];
        if (hasM3u(path, m3u_path)) {
            strcpy(path, m3u_path);
        }
    }
    
    char emu_name[256];
    getEmuName(path, emu_name);
    
    if (strcmp(emu_name, "PSP") == 0)
        isPSP = 1;
    else
        isPSP = 0;
    
    char rom_file[256];
    tmp = strrchr(path, '/') + 1;
    strcpy(rom_file, tmp);
    
    sprintf(bmp_slot_path, "%s/.minui/%s/%s.0.bmp", SHARED_USERDATA_PATH, emu_name, rom_file);
    sprintf(slot_path, "%s/.minui/%s/%s.txt", SHARED_USERDATA_PATH, emu_name, rom_file);
    
    can_resume = exists(slot_path);
}

static void readyResume(Entry* entry) {
    // PNG файлы не поддерживают сохранения
    if (entry->type == ENTRY_IMAGE || 
        (entry->type == ENTRY_ROM && suffixMatch(".png", entry->path))) {
        can_resume = 0;
        bmp_slot_path[0] = '\0'; // Очищаем путь
        return;
    }
    
    // Очищаем пути перед вычислением
    bmp_slot_path[0] = '\0';
    slot_path[0] = '\0';
    
    readyResumePath(entry->path, entry->type);
    
    // Если нет сохранения, явно очищаем путь
    if (!can_resume) {
        bmp_slot_path[0] = '\0';
    }
}

static void saveLast(char* path);
static void loadLast(void);

static int autoResume(void) {
    if (!exists(AUTO_RESUME_PATH)) return 0;
    
    char path[256];
    getFile(AUTO_RESUME_PATH, path, 256);
    unlink(AUTO_RESUME_PATH);
    sync();
    
    char sd_path[256];
    sprintf(sd_path, "%s%s", SDCARD_PATH, path);
    if (!exists(sd_path)) return 0;
    
    char emu_name[256];
    getEmuName(sd_path, emu_name);
    char emu_path[256];
    getEmuPath(emu_name, emu_path);
    if (!exists(emu_path)) return 0;
    
    char cmd[256];
    sprintf(cmd, "'%s' '%s'", escapeSingleQuotes(emu_path), escapeSingleQuotes(sd_path));
    putInt(RESUME_SLOT_PATH, AUTO_RESUME_SLOT);
    queueNext(cmd);
    return 1;
}

// Функция для загрузки изображений с приоритетом

// ==================== JAR ICON EXTRACTION ====================
// Минимальный ZIP reader для извлечения PNG-иконок из JAR-файлов
// JAR = ZIP, поэтому читаем Central Directory и локальные заголовки

#pragma pack(push, 1)
typedef struct {
    uint32_t signature;      // 0x02014B50
    uint16_t version_made;
    uint16_t version_needed;
    uint16_t flags;
    uint16_t compression;    // 0=stored, 8=deflate
    uint16_t mod_time;
    uint16_t mod_date;
    uint32_t crc32;
    uint32_t comp_size;
    uint32_t uncomp_size;
    uint16_t fname_len;
    uint16_t extra_len;
    uint16_t comment_len;
    uint16_t disk_start;
    uint16_t internal_attr;
    uint32_t external_attr;
    uint32_t local_header_offset;
} ZipCentralDirEntry;

typedef struct {
    uint32_t signature;      // 0x04034B50
    uint16_t version_needed;
    uint16_t flags;
    uint16_t compression;
    uint16_t mod_time;
    uint16_t mod_date;
    uint32_t crc32;
    uint32_t comp_size;
    uint32_t uncomp_size;
    uint16_t fname_len;
    uint16_t extra_len;
} ZipLocalHeader;
#pragma pack(pop)

// Сравнение путей case-insensitive, '/' и '\' считаются одинаковыми
static int path_match(const char* a, const char* b, size_t len) {
    for (size_t i = 0; i < len; i++) {
        char ca = a[i], cb = b[i];
        if (ca == '/') ca = '\\';
        if (cb == '/') cb = '\\';
        if (tolower((unsigned char)ca) != tolower((unsigned char)cb)) return 1;
    }
    return 0;
}

// Поиск EOCD (End of Central Directory) с конца файла, с учётом archive comment
// Возвращает смещение EOCD или -1
static off_t find_eocd(int fd, off_t file_size) {
    // Максимальный размер comment — 65535 байт
    // Ищем сигнатуру 0x06054B50 назад от конца файла
    off_t search_start = file_size - 22;
    if (search_start > file_size - 22 - 65535) search_start = file_size - 22 - 65535;
    if (search_start < 0) search_start = 0;

    uint8_t buf[4096];
    off_t pos = file_size - 22;

    while (pos >= search_start) {
        off_t chunk_start = pos - (pos % 4096);
        if (chunk_start < search_start) chunk_start = search_start;
        lseek(fd, chunk_start, SEEK_SET);
        ssize_t rd = read(fd, buf, pos - chunk_start + 22);
        if (rd <= 0) break;

        for (ssize_t j = rd - 4; j >= 0; j--) {
            if (buf[j] == 0x50 && buf[j+1] == 0x4B && buf[j+2] == 0x05 && buf[j+3] == 0x06) {
                off_t found = chunk_start + j;
                // Проверяем что после сигнатуры есть минимум 18 байт и вмещается в файл
                if (found + 22 <= file_size) {
                    return found;
                }
            }
        }
        pos = chunk_start - 1;
    }
    return -1;
}

static int jar_extract_file_by_name(const char* jar_path, const char* target_name,
                                     uint8_t** out_data, uint32_t* out_size) {
    // Извлекает файл из JAR по точному имени (case-insensitive)
    int fd = open(jar_path, O_RDONLY);
    if (fd < 0) return -1;

    off_t file_size = lseek(fd, 0, SEEK_END);
    if (file_size < 22) { close(fd); return -1; }

    off_t eocd_pos = find_eocd(fd, file_size);
    if (eocd_pos < 0) {
        close(fd); return -1;
    }

    uint8_t eocd[22];
    lseek(fd, eocd_pos, SEEK_SET);
    if (read(fd, eocd, 22) != 22) { close(fd); return -1; }

    uint16_t entry_count = le16toh(*(uint16_t*)(eocd + 10));
    uint32_t cd_offset = le32toh(*(uint32_t*)(eocd + 16));
    if (cd_offset >= (uint32_t)file_size) { close(fd); return -1; }

    uint8_t* cd = malloc(file_size - cd_offset);
    if (!cd) { close(fd); return -1; }
    lseek(fd, cd_offset, SEEK_SET);
    ssize_t cd_read = read(fd, cd, file_size - cd_offset);
    if (cd_read <= 0) { free(cd); close(fd); return -1; }

    int result = -1;
    uint8_t* ptr = cd;
    uint8_t* cd_end = cd + cd_read;
    size_t target_len = strlen(target_name);

    for (int i = 0; i < entry_count && ptr + sizeof(ZipCentralDirEntry) <= cd_end; i++) {
        ZipCentralDirEntry* entry = (ZipCentralDirEntry*)ptr;
        if (le32toh(entry->signature) != 0x02014B50) break;

        uint16_t fname_len = le16toh(entry->fname_len);
        uint16_t extra_len = le16toh(entry->extra_len);
        uint16_t comment_len = le16toh(entry->comment_len);
        uint16_t compression = le16toh(entry->compression);
        uint32_t comp_size = le32toh(entry->comp_size);
        uint32_t uncomp_size = le32toh(entry->uncomp_size);
        uint32_t local_offset = le32toh(entry->local_header_offset);

        if (fname_len == target_len &&
            path_match((char*)(ptr + sizeof(ZipCentralDirEntry)), target_name, fname_len) == 0) {

            ZipLocalHeader local;
            lseek(fd, local_offset, SEEK_SET);
            if (read(fd, &local, sizeof(local)) != sizeof(local)) break;

            uint32_t data_offset = local_offset + sizeof(local) +
                                   le16toh(local.fname_len) + le16toh(local.extra_len);

            if (compression == 0) {
                *out_data = malloc(comp_size);
                if (*out_data) {
                    lseek(fd, data_offset, SEEK_SET);
                    if (read(fd, *out_data, comp_size) == (ssize_t)comp_size) {
                        *out_size = comp_size;
                        result = 0;
                    } else { free(*out_data); *out_data = NULL; }
                }
            } else if (compression == 8) {
                // ZIP/JAR использует raw deflate (без zlib-заголовка)
                uint8_t* comp_data = malloc(comp_size);
                if (comp_data) {
                    lseek(fd, data_offset, SEEK_SET);
                    if (read(fd, comp_data, comp_size) == (ssize_t)comp_size) {
                        *out_data = malloc(uncomp_size > 0 ? uncomp_size + 1 : 65536);
                        if (*out_data) {
                            z_stream strm;
                            memset(&strm, 0, sizeof(strm));
                            strm.next_in = comp_data;
                            strm.avail_in = comp_size;
                            strm.next_out = *out_data;
                            strm.avail_out = uncomp_size > 0 ? uncomp_size : 65535;
                            if (inflateInit2(&strm, -MAX_WBITS) == Z_OK) {
                                int zret = inflate(&strm, Z_FINISH);
                                inflateEnd(&strm);
                                if (zret == Z_STREAM_END || zret == Z_OK) {
                                    *out_size = (uint32_t)strm.total_out;
                                    result = 0;
                                } else { free(*out_data); *out_data = NULL; }
                            } else { free(*out_data); *out_data = NULL; }
                        }
                    }
                    free(comp_data);
                }
            }
            break;
        }

        ptr += sizeof(ZipCentralDirEntry) + fname_len + extra_len + comment_len;
    }

    free(cd);
    close(fd);
    return result;
}

// Извлекает путь иконки из манифеста J2ME (META-INF/MANIFEST.MF)
// Принимает уже извлечённые данные манифеста
// Возвращает указатель на malloc-строку или NULL
// Приоритет: MIDlet-Icon: > MIDlet-n: (иконка после запятой) > первый .png в тексте
static char* jar_parse_manifest_icon(const uint8_t* mf_data, uint32_t mf_size) {
    if (!mf_data || mf_size == 0) return NULL;
    uint8_t* text = malloc(mf_size + 1);
    if (!text) return NULL;
    memcpy(text, mf_data, mf_size);
    text[mf_size] = '\0';

    char* icon_path = NULL;
    char* line = (char*)text;

    while (*line) {
        char* eol = line;
        while (*eol && *eol != '\n' && *eol != '\r') eol++;
        char saved = *eol;
        *eol = '\0';

        if (line[0] == '\0') { *eol = saved; line = eol + 1; if (saved) line++; continue; }

        // ПРИОРИТЕТ 1: MIDlet-Icon: <path>
        if (!icon_path && strncasecmp(line, "MIDlet-Icon:", 12) == 0) {
            char* val = line + 12;
            while (*val == ' ' || *val == '\t') val++;
            if (*val) {
                int len = strlen(val);
                icon_path = malloc(len + 1);
                if (icon_path) {
                    strcpy(icon_path, val);
                    if (icon_path[0] == '/' || icon_path[0] == '\\')
                        memmove(icon_path, icon_path + 1, len);
                }
                *eol = saved;
                break;
            }
        }

        // ПРИОРИТЕТ 2: MIDlet-n: <name>, <icon>, <class>
        if (!icon_path && strncasecmp(line, "MIDlet-", 7) == 0) {
            char* p = line + 7;
            while (*p && *p != ':') p++;
            if (*p == ':') {
                p++;
                while (*p && *p != ',') p++;
                if (*p == ',') {
                    p++;
                    while (*p == ' ' || *p == '\t') p++;
                    char* start = p;
                    while (*p && *p != ',') p++;
                    int len = p - start;
                    while (len > 0 && (start[len-1] == ' ' || start[len-1] == '\t')) len--;
                    if (len > 0) {
                        icon_path = malloc(len + 1);
                        if (icon_path) {
                            memcpy(icon_path, start, len);
                            icon_path[len] = '\0';
                            if (icon_path[0] == '/' || icon_path[0] == '\\')
                                memmove(icon_path, icon_path + 1, len);
                        }
                        *eol = saved;
                        break;
                    }
                }
            }
        }

        *eol = saved;
        line = eol;
        if (saved == '\r' && line[1] == '\n') line += 2;
        else if (saved) line++;
    }

    // ПРИОРИТЕТ 3: fallback — первое упоминание .png в тексте
    if (!icon_path) {
        char* p = (char*)text;
        while (*p) {
            if (strncasecmp(p, ".png", 4) == 0) {
                char* start = p;
                while (start > (char*)text) {
                    char c = *(start - 1);
                    if (c == ' ' || c == ',' || c == ':' || c == '\t' ||
                        c == '\r' || c == '\n') break;
                    start--;
                }
                int path_len = (p + 4) - start;
                if (path_len > 0 && path_len < 256) {
                    icon_path = malloc(path_len + 1);
                    if (icon_path) {
                        memcpy(icon_path, start, path_len);
                        icon_path[path_len] = '\0';
                        if (icon_path[0] == '/' || icon_path[0] == '\\')
                            memmove(icon_path, icon_path + 1, path_len);
                    }
                }
                break;
            }
            p++;
        }
    }

    // manifest icon path: icon_path or NULL
    free(text);
    return icon_path;
}

static int jar_extract_png_from_zip(const char* jar_path, uint8_t** out_data, uint32_t* out_size) {
    // searching icon in jar

    // === ПРИОРИТЕТ 1: парсим манифест J2ME (двухпроходный подход) ===
    uint8_t* mf_data = NULL;
    uint32_t mf_size = 0;
    char* manifest_icon = NULL;

    if (jar_extract_file_by_name(jar_path, "META-INF/MANIFEST.MF", &mf_data, &mf_size) != 0) {
        // META-INF/MANIFEST.MF not found, trying MANIFEST.MF
        jar_extract_file_by_name(jar_path, "MANIFEST.MF", &mf_data, &mf_size);
    }
    if (mf_data && mf_size > 0) {
        // manifest found
        manifest_icon = jar_parse_manifest_icon(mf_data, mf_size);
        free(mf_data);
    }

    if (manifest_icon) {
        // trying manifest icon
        int ret = jar_extract_file_by_name(jar_path, manifest_icon, out_data, out_size);
        free(manifest_icon);
        if (ret == 0) return 0;
    }

    // === ПРИОРИТЕТ 2: паттерны имён ===
    static const char* icon_patterns[] = {
        "icon.png", "app.png", "logo.png", "splash.png",
        "preview.png", "thumbnail.png", "banner.png",
        "META-INF/icon.png",
        "res/drawable/icon.png", "res/icon.png",
        "assets/icon.png", "assets/app.png", "assets/logo.png",
        NULL
    };
    for (int i = 0; icon_patterns[i] != NULL; i++) {
        if (jar_extract_file_by_name(jar_path, icon_patterns[i], out_data, out_size) == 0) {
            // icon found by pattern
            return 0;
        }
    }
    // no icon matched by name patterns

    // === ПРИОРИТЕТ 3: самый большой PNG или первый PNG ===
    int fd = open(jar_path, O_RDONLY);
    if (fd < 0) return -1;

    off_t file_size = lseek(fd, 0, SEEK_END);
    if (file_size < 22) { close(fd); return -1; }

    off_t eocd_pos = find_eocd(fd, file_size);
    if (eocd_pos < 0) {
        // EOCD not found
        close(fd); return -1;
    }

    uint8_t eocd[22];
    lseek(fd, eocd_pos, SEEK_SET);
    if (read(fd, eocd, 22) != 22) { close(fd); return -1; }

    uint16_t entry_count = le16toh(*(uint16_t*)(eocd + 10));
    uint32_t cd_offset = le32toh(*(uint32_t*)(eocd + 16));

    if (cd_offset >= (uint32_t)file_size) { close(fd); return -1; }

    // Читаем Central Directory
    uint8_t* cd = malloc(file_size - cd_offset);
    if (!cd) { close(fd); return -1; }
    lseek(fd, cd_offset, SEEK_SET);
    ssize_t cd_read = read(fd, cd, file_size - cd_offset);
    if (cd_read <= 0) { free(cd); close(fd); return -1; }

    // === ФАЗА 1: сканируем все записи, сохраняем нужные данные ===
    int found_pattern_idx = -1;   // индекс записи в CD, а НЕ в icon_patterns!
    int found_smallest = -1;      // индекс самого маленького PNG (иконки обычно маленькие)
    uint32_t smallest_size = 0xFFFFFFFF;
    int found_any_png = -1;       // индекс первого PNG

    uint8_t* ptr = cd;
    uint8_t* cd_end = cd + cd_read;

    for (int i = 0; i < entry_count && ptr + sizeof(ZipCentralDirEntry) <= cd_end; i++) {
        ZipCentralDirEntry* entry = (ZipCentralDirEntry*)ptr;
        if (le32toh(entry->signature) != 0x02014B50) break;

        uint16_t fname_len = le16toh(entry->fname_len);
        uint16_t extra_len = le16toh(entry->extra_len);
        uint16_t comment_len = le16toh(entry->comment_len);

        if (fname_len == 0 || fname_len > 512) {
            ptr += sizeof(ZipCentralDirEntry) + fname_len + extra_len + comment_len;
            continue;
        }

        char fname[513];
        memcpy(fname, ptr + sizeof(ZipCentralDirEntry), fname_len);
        fname[fname_len] = '\0';

        // Пропускаем директории (заканчиваются на '/')
        if (fname[fname_len - 1] == '/') {
            ptr += sizeof(ZipCentralDirEntry) + fname_len + extra_len + comment_len;
            continue;
        }

        // Проверяем — это PNG?
        int is_png = (fname_len > 4 && strncasecmp(fname + fname_len - 4, ".png", 4) == 0);
        if (!is_png) {
            ptr += sizeof(ZipCentralDirEntry) + fname_len + extra_len + comment_len;
            continue;
        }

        // Запоминаем первый PNG
        if (found_any_png < 0) found_any_png = i;
        // PNG in archive

        // Проверяем паттерны — сохраняем CD INDEX (i), а не индекс паттерна!
        if (found_pattern_idx < 0) {
            for (int p = 0; icon_patterns[p] != NULL; p++) {
                size_t pat_len = strlen(icon_patterns[p]);
                if (fname_len == (uint16_t)pat_len &&
                    path_match(fname, icon_patterns[p], pat_len) == 0) {
                    found_pattern_idx = i; // CD entry index!
                    break;
                }
            }
        }

        // Отслеживаем самый маленький PNG (иконки обычно маленькие)
        uint32_t uncomp = le32toh(entry->uncomp_size);
        if (uncomp < smallest_size) {
            smallest_size = uncomp;
            found_smallest = i;
        }

        ptr += sizeof(ZipCentralDirEntry) + fname_len + extra_len + comment_len;
    }

    // === ФАЗА 2: выбираем, что извлекать ===
    int target = -1;
    if (found_pattern_idx >= 0) { target = found_pattern_idx; }
    else if (found_smallest >= 0) { target = found_smallest; }
    else if (found_any_png >= 0) { target = found_any_png; }

    if (target < 0) {
        free(cd);
        close(fd);
        return -1;
    }

    // === ФАЗА 3: извлекаем выбранный файл ===
    int result = -1;
    ptr = cd;
    for (int i = 0; i <= target && ptr + sizeof(ZipCentralDirEntry) <= cd_end; i++) {
        ZipCentralDirEntry* entry = (ZipCentralDirEntry*)ptr;
        if (le32toh(entry->signature) != 0x02014B50) break;

        uint16_t fname_len = le16toh(entry->fname_len);
        uint16_t extra_len = le16toh(entry->extra_len);
        uint16_t comment_len = le16toh(entry->comment_len);
        uint16_t compression = le16toh(entry->compression);
        uint32_t comp_size = le32toh(entry->comp_size);
        uint32_t uncomp_size = le32toh(entry->uncomp_size);
        uint32_t local_offset = le32toh(entry->local_header_offset);

        if (i == target) {
            // Читаем локальный заголовок
            ZipLocalHeader local;
            lseek(fd, local_offset, SEEK_SET);
            if (read(fd, &local, sizeof(local)) != sizeof(local)) break;

            uint32_t data_offset = local_offset + sizeof(local) +
                                   le16toh(local.fname_len) + le16toh(local.extra_len);

            if (compression == 0) {
                // Stored — без сжатия
                *out_data = malloc(comp_size);
                if (*out_data) {
                    lseek(fd, data_offset, SEEK_SET);
                    if (read(fd, *out_data, comp_size) == (ssize_t)comp_size) {
                        *out_size = comp_size;
                        result = 0;
                    } else { free(*out_data); *out_data = NULL; }
                }
            } else if (compression == 8) {
                // ZIP/JAR использует raw deflate (без zlib-заголовка)
                uint8_t* comp_data = malloc(comp_size);
                if (comp_data) {
                    lseek(fd, data_offset, SEEK_SET);
                    if (read(fd, comp_data, comp_size) == (ssize_t)comp_size) {
                        *out_data = malloc(uncomp_size > 0 ? uncomp_size + 1 : 65536);
                        if (*out_data) {
                            z_stream strm;
                            memset(&strm, 0, sizeof(strm));
                            strm.next_in = comp_data;
                            strm.avail_in = comp_size;
                            strm.next_out = *out_data;
                            strm.avail_out = uncomp_size > 0 ? uncomp_size : 65535;
                            if (inflateInit2(&strm, -MAX_WBITS) == Z_OK) {
                                int zret = inflate(&strm, Z_FINISH);
                                inflateEnd(&strm);
                                if (zret == Z_STREAM_END || zret == Z_OK) {
                                    *out_size = (uint32_t)strm.total_out;
                                    result = 0;
                                } else { free(*out_data); *out_data = NULL; }
                            } else { free(*out_data); *out_data = NULL; }
                        }
                    }
                    free(comp_data);
                }
            }
            break;
        }

        ptr += sizeof(ZipCentralDirEntry) + fname_len + extra_len + comment_len;
    }

    free(cd);
    close(fd);
    return result;
}

static SDL_Surface* loadJarIcon(const char* jar_path) {
    uint8_t* png_data = NULL;
    uint32_t png_size = 0;

    if (jar_extract_png_from_zip(jar_path, &png_data, &png_size) != 0 || !png_data) {
        return NULL;
    }

    // Проверяем PNG сигнатуру
    if (png_size < 8 || png_data[0] != 0x89 || png_data[1] != 'P' || png_data[2] != 'N' || png_data[3] != 'G') {
        free(png_data);
        return NULL;
    }

    // Загружаем PNG из памяти через SDL_RWops
    SDL_RWops* rw = SDL_RWFromMem(png_data, png_size);
    if (!rw) {
        free(png_data);
        return NULL;
    }

    SDL_Surface* surface = IMG_Load_RW(rw, 1); // 1 = auto-close rw
    free(png_data);

    if (!surface) return NULL;

    // Сразу конвертируем в 32-бит RGBA — гарантирует корректную обработку
    // альфа-канала и colorkey при дальнейшем масштабировании
    SDL_Surface* rgba32 = SDL_ConvertSurfaceFormat(surface, SDL_PIXELFORMAT_RGBA32, 0);
    SDL_FreeSurface(surface);
    if (!rgba32) return NULL;
    surface = rgba32;

    // Если иконка меньше 128x128 — масштабируем целочисленным кратным (nearest neighbor)
    if (surface->w < 128 && surface->h < 128) {
        int scale = 1;
        // Находим максимальный целый масштаб, чтобы результат не превышал 128
        while (surface->w * (scale + 1) <= 128 && surface->h * (scale + 1) <= 128) {
            scale++;
        }
        if (scale > 1) {
            int new_w = surface->w * scale;
            int new_h = surface->h * scale;
            SDL_Surface* scaled = SDL_CreateRGBSurface(0, new_w, new_h,
                surface->format->BitsPerPixel,
                surface->format->Rmask,
                surface->format->Gmask,
                surface->format->Bmask,
                surface->format->Amask);
            if (scaled) {
                SDL_LockSurface(surface);
                SDL_LockSurface(scaled);

                int bpp = surface->format->BitsPerPixel / 8;
                int src_pitch = surface->pitch;
                int dst_pitch = scaled->pitch;

                for (int y = 0; y < new_h; y++) {
                    int src_y = y / scale;
                    uint8_t* src_row = (uint8_t*)surface->pixels + src_y * src_pitch;
                    uint8_t* dst_row = (uint8_t*)scaled->pixels + y * dst_pitch;
                    for (int x = 0; x < new_w; x++) {
                        int src_x = x / scale;
                        int src_off = src_x * bpp;
                        int dst_off = x * bpp;
                        memcpy(dst_row + dst_off, src_row + src_off, bpp);
                    }
                }

                SDL_UnlockSurface(scaled);
                SDL_UnlockSurface(surface);

                SDL_FreeSurface(surface);
                surface = scaled;
            }
        }
    }

    return surface;
}

// ==================== END JAR ICON EXTRACTION ====================

// Быстрый программный blit с масштабированием для RGB565 + colorkey
// Значительно быстрее SDL_BlitSurface при масштабировании
static void blitScaled565(SDL_Surface* src, SDL_Surface* dst,
                           int dst_x, int dst_y, int dst_w, int dst_h,
                           int clip_x, int clip_y, int clip_w, int clip_h) {
    if (!src || !dst || dst_w <= 0 || dst_h <= 0) return;
    int sw = src->w, sh = src->h;
    if (sw <= 0 || sh <= 0) return;

    Uint16 ck16 = 0;
    int has_ck = (SDL_GetColorKey(src, (Uint32*)&ck16) == 0) ? 1 : 0;

    // Вычисляем видимую область (пересечение с clip)
    int x0 = dst_x, y0 = dst_y;
    int x1 = dst_x + dst_w, y1 = dst_y + dst_h;
    if (x0 < clip_x) x0 = clip_x;
    if (y0 < clip_y) y0 = clip_y;
    int cx1 = clip_x + clip_w;
    int cy1 = clip_y + clip_h;
    if (x1 > cx1) x1 = cx1;
    if (y1 > cy1) y1 = cy1;
    if (x0 >= x1 || y0 >= y1) return;

    int draw_w = x1 - x0;
    int draw_h = y1 - y0;

    SDL_LockSurface(src);
    SDL_LockSurface(dst);

    Uint16* src_px = (Uint16*)src->pixels;
    Uint16* dst_px = (Uint16*)dst->pixels;
    int src_pitch = src->pitch / 2;
    int dst_pitch = dst->pitch / 2;

    // Обратное отображение: начальные координаты источника
    int src_x0 = (x0 - dst_x) * sw / dst_w;
    int src_y0 = (y0 - dst_y) * sh / dst_h;
    int src_x_range = (draw_w * sw) / dst_w;
    int src_y_range = (draw_h * sh) / dst_h;

    // Bresenham: замена mul/div на сложение/сравнение во внутреннем цикле
    int sy = src_y0, sy_err = 0, sy_step = src_y_range, sy_den = draw_h;

    if (has_ck) {
        for (int dy = 0; dy < draw_h; dy++) {
            if (sy >= sh) sy = sh - 1;
            Uint16* s_row = src_px + sy * src_pitch;
            Uint16* d_row = dst_px + (y0 + dy) * dst_pitch + x0;
            int sx = src_x0, sx_err = 0, sx_step = src_x_range, sx_den = draw_w;
            for (int dx = 0; dx < draw_w; dx++) {
                if (sx >= sw) sx = sw - 1;
                Uint16 pixel = s_row[sx];
                if (pixel != ck16) d_row[dx] = pixel;
                sx_err += sx_step;
                if (sx_err >= sx_den) { sx++; sx_err -= sx_den; }
            }
            sy_err += sy_step;
            if (sy_err >= sy_den) { sy++; sy_err -= sy_den; }
        }
    } else {
        for (int dy = 0; dy < draw_h; dy++) {
            if (sy >= sh) sy = sh - 1;
            Uint16* s_row = src_px + sy * src_pitch;
            Uint16* d_row = dst_px + (y0 + dy) * dst_pitch + x0;
            int sx = src_x0, sx_err = 0, sx_step = src_x_range, sx_den = draw_w;
            for (int dx = 0; dx < draw_w; dx++) {
                if (sx >= sw) sx = sw - 1;
                d_row[dx] = s_row[sx];
                sx_err += sx_step;
                if (sx_err >= sx_den) { sx++; sx_err -= sx_den; }
            }
            sy_err += sy_step;
            if (sy_err >= sy_den) { sy++; sy_err -= sy_den; }
        }
    }

    SDL_UnlockSurface(dst);
    SDL_UnlockSurface(src);
}

// Рисование заполненного круга для RGB565
static void drawFilledCircle565(SDL_Surface* surf, int cx, int cy, int r, Uint16 color) {
    if (!surf || r <= 0) return;
    SDL_LockSurface(surf);
    Uint16* pixels = (Uint16*)surf->pixels;
    int pitch = surf->pitch / 2;
    int sw = surf->w, sh = surf->h;
    int r2 = r * r;
    for (int dy = -r; dy <= r; dy++) {
        int y = cy + dy;
        if (y < 0 || y >= sh) continue;
        int dx2 = r2 - dy * dy;
        if (dx2 < 0) continue;
        int dx_max = (int)sqrtf((float)dx2);
        int x0 = cx - dx_max;
        int x1 = cx + dx_max;
        if (x0 < 0) x0 = 0;
        if (x1 >= sw) x1 = sw - 1;
        Uint16* row = pixels + y * pitch;
        for (int x = x0; x <= x1; x++) row[x] = color;
    }
    SDL_UnlockSurface(surf);
}

// Быстрый blit без масштабирования (1:1) для RGB565 + colorkey
static void blitDirect565(SDL_Surface* src, SDL_Surface* dst,
                           int dst_x, int dst_y,
                           int clip_x, int clip_y, int clip_w, int clip_h) {
    if (!src || !dst) return;
    int sw = src->w, sh = src->h;
    if (sw <= 0 || sh <= 0) return;

    Uint16 ck16 = 0;
    int has_ck = (SDL_GetColorKey(src, (Uint32*)&ck16) == 0) ? 1 : 0;

    int x0 = dst_x, y0 = dst_y;
    int x1 = dst_x + sw, y1 = dst_y + sh;
    if (x0 < clip_x) x0 = clip_x;
    if (y0 < clip_y) y0 = clip_y;
    int cx1 = clip_x + clip_w;
    int cy1 = clip_y + clip_h;
    if (x1 > cx1) x1 = cx1;
    if (y1 > cy1) y1 = cy1;
    if (x0 >= x1 || y0 >= y1) return;

    int draw_w = x1 - x0;
    int draw_h = y1 - y0;
    int src_x_off = x0 - dst_x;
    int src_y_off = y0 - dst_y;

    SDL_LockSurface(src);
    SDL_LockSurface(dst);

    Uint16* src_px = (Uint16*)src->pixels;
    Uint16* dst_px = (Uint16*)dst->pixels;
    int src_pitch = src->pitch / 2;
    int dst_pitch = dst->pitch / 2;

    if (has_ck) {
        for (int dy = 0; dy < draw_h; dy++) {
            Uint16* s_row = src_px + (src_y_off + dy) * src_pitch + src_x_off;
            Uint16* d_row = dst_px + (y0 + dy) * dst_pitch + x0;
            for (int dx = 0; dx < draw_w; dx++) {
                Uint16 pixel = s_row[dx];
                if (pixel != ck16) d_row[dx] = pixel;
            }
        }
    } else {
        for (int dy = 0; dy < draw_h; dy++) {
            memcpy(dst_px + (y0 + dy) * dst_pitch + x0,
                   src_px + (src_y_off + dy) * src_pitch + src_x_off,
                   draw_w * 2);
        }
    }

    SDL_UnlockSurface(dst);
    SDL_UnlockSurface(src);
}

// Масштабирование поверхности с сохранением пропорций (nearest neighbor, RGB565 + colorkey)
// Копирует colorkey с исходной поверхности, выход всегда RGB565 с colorkey
static SDL_Surface* scaleToFit(SDL_Surface* surface, int max_w, int max_h) {
    if (!surface || surface->w <= 0 || surface->h <= 0) return NULL;

    // Сохраняем colorkey исходной поверхности
    Uint32 colorkey = 0;
    int has_colorkey = SDL_GetColorKey(surface, &colorkey);

    // Конвертируем colorkey в RGB565
    Uint16 ck16 = 0;
    int use_colorkey = 0;
    if (has_colorkey == 0) {
        Uint8 r, g, b;
        SDL_GetRGB(colorkey, surface->format, &r, &g, &b);
        ck16 = (Uint16)SDL_MapRGB(screen->format, r, g, b);
        use_colorkey = 1;
    }

    int src_pitch = surface->pitch;
    int src_bpp = surface->format->BitsPerPixel / 8;

    // Вычисляем размер с сохранением пропорций
    int new_w, new_h;
    if (surface->w <= max_w && surface->h <= max_h) {
        new_w = surface->w;
        new_h = surface->h;
    } else {
        float scale_x = (float)max_w / (float)surface->w;
        float scale_y = (float)max_h / (float)surface->h;
        float scale = (scale_x < scale_y) ? scale_x : scale_y;
        new_w = (int)((float)surface->w * scale);
        new_h = (int)((float)surface->h * scale);
    }
    if (new_w < 1) new_w = 1;
    if (new_h < 1) new_h = 1;

    // Выходная поверхность всегда RGB565
    SDL_Surface* dst = SDL_CreateRGBSurface(0, new_w, new_h,
        screen->format->BitsPerPixel,
        screen->format->Rmask, screen->format->Gmask,
        screen->format->Bmask, 0);
    if (!dst) return NULL;

    int dst_pitch = dst->pitch;

    if (src_bpp == 2 && use_colorkey) {
        // Быстрый путь: RGB565 → RGB565, Bresenham (без float, без mul/div во внутреннем цикле)
        SDL_LockSurface(surface);
        SDL_LockSurface(dst);
        Uint16* src_pixels = (Uint16*)surface->pixels;
        Uint16* dst_pixels = (Uint16*)dst->pixels;
        int src_w_pitch = src_pitch / 2;
        int dst_w_pitch = dst_pitch / 2;
        int sw = surface->h, sdw = surface->w;

        int sy = 0, sy_step = sw, sy_den = new_h, sy_err = 0;
        for (int y = 0; y < new_h; y++) {
            Uint16* src_row = src_pixels + sy * src_w_pitch;
            Uint16* dst_row = dst_pixels + y * dst_w_pitch;
            int sx = 0, sx_step = sdw, sx_den = new_w, sx_err = 0;
            for (int x = 0; x < new_w; x++) {
                dst_row[x] = src_row[sx];
                sx_err += sx_step;
                if (sx_err >= sx_den) { sx++; sx_err -= sx_den; }
            }
            sy_err += sy_step;
            if (sy_err >= sy_den) { sy++; sy_err -= sy_den; }
        }
        SDL_UnlockSurface(dst);
        SDL_UnlockSurface(surface);
        // Устанавливаем тот же colorkey на выходе
        SDL_SetColorKey(dst, SDL_TRUE, ck16);
    } else {
        // Общий путь: прямые битовые операции вместо SDL_GetRGBA/SDL_MapRGB
        SDL_LockSurface(surface);
        SDL_LockSurface(dst);
        Uint16* dst_pixels = (Uint16*)dst->pixels;
        int dst_pitch16 = dst_pitch / 2;

        // Предвычисляем сдвиги и потери
        int sr = surface->format->Rshift, sg = surface->format->Gshift;
        int sb = surface->format->Bshift, sa = surface->format->Ashift;
        int drl = screen->format->Rloss, dgl = screen->format->Gloss, dbl = screen->format->Bloss;
        int drs = screen->format->Rshift,  dgs = screen->format->Gshift,  dbs = screen->format->Bshift;

        int sy = 0, sy_step = surface->h, sy_den = new_h, sy_err = 0;
        for (int y = 0; y < new_h; y++) {
            uint8_t* src_row = (uint8_t*)surface->pixels + sy * src_pitch;
            Uint16* dst_row = dst_pixels + y * dst_pitch16;
            int sx = 0, sx_step = surface->w, sx_den = new_w, sx_err = 0;
            for (int x = 0; x < new_w; x++) {
                int a = 255;
                Uint8 r, g, b;
                if (src_bpp == 4) {
                    Uint32 pixel = *((Uint32*)(src_row + sx * 4));
                    a = (pixel >> sa) & 0xFF;
                    r = (pixel >> sr) & 0xFF;
                    g = (pixel >> sg) & 0xFF;
                    b = (pixel >> sb) & 0xFF;
                } else if (src_bpp == 2) {
                    Uint16 pixel = *((Uint16*)(src_row + sx * 2));
                    r = (pixel >> sr) & 0xFF;
                    g = (pixel >> sg) & 0xFF;
                    b = (pixel >> sb) & 0xFF;
                } else {
                    sx_err += sx_step;
                    if (sx_err >= sx_den) { sx++; sx_err -= sx_den; }
                    continue;
                }
                dst_row[x] = (a > 127) ? (Uint16)(
                    ((r >> drl) << drs) | ((g >> dgl) << dgs) | ((b >> dbl) << dbs)) : ck16;
                sx_err += sx_step;
                if (sx_err >= sx_den) { sx++; sx_err -= sx_den; }
            }
            sy_err += sy_step;
            if (sy_err >= sy_den) { sy++; sy_err -= sy_den; }
        }
        SDL_UnlockSurface(dst);
        SDL_UnlockSurface(surface);
        SDL_SetColorKey(dst, SDL_TRUE, ck16);
    }

    return dst;
}

static SDL_Surface* loadImageWithPriority(Entry* entry, char* select_themes, char* bmp_slot_path) {
    if (!entry || !screen || !entry->path) return NULL;

    char file_path[256];
    char file_name[256];
    char theme_png_path[512];
    char png_path[512];

    get_name(file_path, file_name, entry->path);
    if (strlen(file_name) >= sizeof(file_name) || strlen(file_path) >= sizeof(file_path))
        return NULL;

    snprintf(theme_png_path, sizeof(theme_png_path), "/sdcard/Themes/%s/%s.png",
             select_themes ? select_themes : "default", file_name);
    snprintf(png_path, sizeof(png_path), "%s.res/%s.png", file_path, file_name);

    // === 1. ОПРЕДЕЛЕНИЕ ПУТИ И ЗАГРУЗКА ===
    const char* load_path = NULL;
    if (isImageFile(entry->path)) {
        load_path = entry->path;
    } else if (exists(theme_png_path)) {
        load_path = theme_png_path;
    } else if (exists(png_path)) {
        load_path = png_path;
    } else if (bmp_slot_path && exists(bmp_slot_path)) {
        load_path = bmp_slot_path;
    }

    SDL_Surface* src = NULL;
    if (load_path) {
        src = IMG_Load(load_path);
    }

    // === 1b. FALLBACK: извлечение иконки из JAR-файла ===
    if (!src && entry->type == ENTRY_ROM) {
        const char* ext = strrchr(entry->path, '.');
        if (ext && (strcasecmp(ext, ".jar") == 0 || strcasecmp(ext, ".jad") == 0)) {
            src = loadJarIcon(entry->path);
        }
    }

    if (!src) return NULL;

    // === 2. МАЛЕНЬКИЕ ИЗОБРАЖЕНИЯ: композитим альфу на фон, конвертируем в 16-бит с colorkey ===
    if (src->w <= 128 && src->h <= 128) {
        // Конвертируем в 32-бит RGBA (платформо-зависимый формат)
        SDL_Surface* rgba = SDL_ConvertSurfaceFormat(src, SDL_PIXELFORMAT_RGBA32, 0);
        SDL_FreeSurface(src);
        if (!rgba) return NULL;

        int sw = rgba->w;
        int sh = rgba->h;

        // Создаём 16-битную поверхность
        SDL_Surface* final = SDL_CreateRGBSurface(0, sw, sh,
                                                  screen->format->BitsPerPixel,
                                                  screen->format->Rmask,
                                                  screen->format->Gmask,
                                                  screen->format->Bmask,
                                                  0);
        if (!final) { SDL_FreeSurface(rgba); return NULL; }

        // Цвет для colorkey — пурпурный (обычно отсутствует в иконках)
        Uint32 colorkey = SDL_MapRGB(final->format, 0xFF, 0x00, 0xFF);
        SDL_FillRect(final, NULL, colorkey);

        // Берем цвет фона из настроек темы
        Uint8 bg_r = color_triad_black_r;
        Uint8 bg_g = color_triad_black_g;
        Uint8 bg_b = color_triad_black_b;

        SDL_LockSurface(rgba);
        SDL_LockSurface(final);

        Uint32* src_pixels = (Uint32*)rgba->pixels;
        Uint16* dst_pixels = (Uint16*)final->pixels;
        int src_pitch = rgba->pitch / 4;
        int dst_pitch = final->pitch / 2;

        // Предвычисляем сдвиги и потери для прямого преобразования
        int sr = rgba->format->Rshift, sg = rgba->format->Gshift;
        int sb = rgba->format->Bshift, sa = rgba->format->Ashift;
        int drl = final->format->Rloss, dgl = final->format->Gloss, dbl = final->format->Bloss;
        int drs = final->format->Rshift,  dgs = final->format->Gshift,  dbs = final->format->Bshift;

        for (int y = 0; y < sh; y++) {
            Uint32* s_row = src_pixels + y * src_pitch;
            Uint16* d_row = dst_pixels + y * dst_pitch;
            for (int x = 0; x < sw; x++) {
                Uint32 pixel = s_row[x];
                Uint8 a = (pixel >> sa) & 0xFF;
                if (a > 0) {
                    if (a >= 255) {
                        d_row[x] = (Uint16)(
                            (((pixel >> sr) & 0xFF) >> drl) << drs |
                            (((pixel >> sg) & 0xFF) >> dgl) << dgs |
                            (((pixel >> sb) & 0xFF) >> dbl) << dbs);
                    } else {
                        Uint8 r = (pixel >> sr) & 0xFF;
                        Uint8 g = (pixel >> sg) & 0xFF;
                        Uint8 b = (pixel >> sb) & 0xFF;
                        Uint8 or = (r * a + bg_r * (255 - a)) / 255;
                        Uint8 og = (g * a + bg_g * (255 - a)) / 255;
                        Uint8 ob = (b * a + bg_b * (255 - a)) / 255;
                        d_row[x] = (Uint16)(
                            ((or >> drl) << drs) | ((og >> dgl) << dgs) | ((ob >> dbl) << dbs));
                    }
                }
                // Полностью прозрачные пиксели остаются colorkey
            }
        }

        SDL_UnlockSurface(final);
        SDL_UnlockSurface(rgba);
        SDL_FreeSurface(rgba);

        SDL_SetColorKey(final, SDL_TRUE, colorkey);
        return final;
    }

    // === 3. БОЛЬШИЕ ИЗОБРАЖЕНИЯ: обрезка + 16-бит + colorkey ===
    const int MAX_W = 480;
    const int MAX_H = 273;
    int crop_w = (src->w > MAX_W) ? MAX_W : src->w;
    int crop_h = (src->h > MAX_H) ? MAX_H : src->h;

    // Временная 32-битная поверхность для точной обрезки с альфой
    SDL_Surface* temp_rgba = SDL_ConvertSurfaceFormat(src, SDL_PIXELFORMAT_RGBA32, 0);
    SDL_FreeSurface(src);
    if (!temp_rgba) return NULL;

    // Целевая 16-битная поверхность
    SDL_Surface* final = SDL_CreateRGBSurface(0, crop_w, crop_h,
                                              screen->format->BitsPerPixel,
                                              screen->format->Rmask,
                                              screen->format->Gmask,
                                              screen->format->Bmask,
                                              0);
    if (!final) {
        SDL_FreeSurface(temp_rgba);
        return NULL;
    }

    // Цвет для colorkey — пурпурный (обычно отсутствует в превью)
    Uint32 colorkey = SDL_MapRGB(final->format, 0xFF, 0x00, 0xFF);
    SDL_FillRect(final, NULL, colorkey);

    // Перенос непрозрачных пикселей — БЫСТРЫЙ ПУТЬ: прямые битовые операции вместо SDL_GetRGBA/SDL_MapRGB
    SDL_LockSurface(temp_rgba);
    SDL_LockSurface(final);

    Uint32* src_pixels = (Uint32*)temp_rgba->pixels;
    Uint16* dst_pixels = (Uint16*)final->pixels;
    int src_pitch = temp_rgba->pitch / 4;
    int dst_pitch = final->pitch / 2;

    // Предвычисляем сдвиги и потери для прямого преобразования RGBA→RGB565
    int sr = temp_rgba->format->Rshift, sg = temp_rgba->format->Gshift;
    int sb = temp_rgba->format->Bshift, sa = temp_rgba->format->Ashift;
    int drl = final->format->Rloss, dgl = final->format->Gloss, dbl = final->format->Bloss;
    int drs = final->format->Rshift,  dgs = final->format->Gshift,  dbs = final->format->Bshift;

    for (int y = 0; y < crop_h; y++) {
        Uint32* s_row = src_pixels + y * src_pitch;
        Uint16* d_row = dst_pixels + y * dst_pitch;
        for (int x = 0; x < crop_w; x++) {
            Uint32 pixel = s_row[x];
            if (((pixel >> sa) & 0xFF) > 127) {
                d_row[x] = (Uint16)(
                    (((pixel >> sr) & 0xFF) >> drl) << drs |
                    (((pixel >> sg) & 0xFF) >> dgl) << dgs |
                    (((pixel >> sb) & 0xFF) >> dbl) << dbs);
            }
        }
    }

    SDL_UnlockSurface(final);
    SDL_UnlockSurface(temp_rgba);
    SDL_FreeSurface(temp_rgba);

    SDL_SetColorKey(final, SDL_TRUE, colorkey);
    return final;
}

static void setPreviewImage(Entry* entry, int anim_direction) {
    if (!entry) {
        // Очищаем текущие изображения
        if (surface_png) {
            SDL_FreeSurface(surface_png);
            surface_png = NULL;
        }
        if (prev_surface_png) {
            SDL_FreeSurface(prev_surface_png);
            prev_surface_png = NULL;
        }
        mem_index = -1;
        dirty = 1;
        return;
    }
    
    // ВАЖНО: Сбрасываем путь к сохранению перед обновлением
    bmp_slot_path[0] = '\0';
    
    // ОБНОВЛЯЕМ ПУТЬ ТОЛЬКО ДЛЯ ROM/DIR/PAK (НЕ для ENTRY_IMAGE из скриншотов)
    if (entry->type == ENTRY_ROM || entry->type == ENTRY_DIR || entry->type == ENTRY_PAK) {
        readyResume(entry);
    } else if (entry->type == ENTRY_IMAGE) {
        // Для изображений из скриншотов явно сбрасываем путь к сохранению
        bmp_slot_path[0] = '\0';
        can_resume = 0;
    }
    
    // Пытаемся загрузить изображение
    SDL_Surface* new_image = NULL;
    
    // Для ENTRY_IMAGE из скриншотов - пытаемся загрузить как изображение
    if (entry->type == ENTRY_IMAGE && prefixMatch(SCREENSHOTS_PATH, entry->path)) {
        new_image = IMG_Load(entry->path);
        if (!new_image) {
            // Если не удалось загрузить, пробуем BMP
            const char* ext = strrchr(entry->path, '.');
            if (ext && (strcasecmp(ext, ".bmp") == 0)) {
                new_image = SDL_LoadBMP(entry->path);
            }
        }
    } else {
        // Для остальных типов - стандартная логика загрузки
        char* bmp_path_to_use = NULL;
        if (bmp_slot_path[0] != '\0' && exists(bmp_slot_path)) {
            bmp_path_to_use = bmp_slot_path;
        }
        new_image = loadImageWithPriority(entry, select_themes, bmp_path_to_use);
    }
    
    // Обработка анимаций
    if (anim_direction == 0) {
        // Быстрый переход - без анимации
        if (surface_png) {
            SDL_FreeSurface(surface_png);
            surface_png = NULL;
        }
        if (prev_surface_png) {
            SDL_FreeSurface(prev_surface_png);
            prev_surface_png = NULL;
        }
        
        if (new_image) {
            surface_png = new_image;
            mem_index = top->selected;
        } else {
            surface_png = NULL;
            mem_index = -1;
        }
        dirty = 1;
        return;
    }
    
    // Анимированный переход
    if (animation == 1) {
        if (surface_png != NULL) {
            if (new_image != NULL) {
                // Сохраняем старое изображение для анимации
                if (prev_surface_png) {
                    SDL_FreeSurface(prev_surface_png);
                }
                prev_surface_png = surface_png;
                surface_png = new_image;
            } else {
                // Нет нового изображения - сбрасываем оба
                SDL_FreeSurface(surface_png);
                surface_png = NULL;
                if (prev_surface_png) {
                    SDL_FreeSurface(prev_surface_png);
                    prev_surface_png = NULL;
                }
                mem_index = -1;
                dirty = 1;
                return;
            }
        } else {
            // Нет текущего изображения
            if (prev_surface_png) {
                SDL_FreeSurface(prev_surface_png);
                prev_surface_png = NULL;
            }
            surface_png = new_image; // Может быть NULL
        }
    } else {
        // Без анимации
        if (surface_png) {
            SDL_FreeSurface(surface_png);
        }
        if (prev_surface_png) {
            SDL_FreeSurface(prev_surface_png);
            prev_surface_png = NULL;
        }
        surface_png = new_image; // Может быть NULL
    }
    
    if (new_image != NULL) {
        mem_index = top->selected;
    } else {
        mem_index = -1;
    }
    dirty = 1;
}

static void openPak(char* path) {
    saveLast(path);
    char cmd[256];
    sprintf(cmd, "'%s/launch.sh'", escapeSingleQuotes(path));
    queueNext(cmd);
}

static void openRom(char* path, char* last) {
    char sd_path[256];
    strcpy(sd_path, path);
    
    char m3u_path[256];
    int has_m3u = hasM3u(sd_path, m3u_path);
    
    char recent_path[256];
    strcpy(recent_path, has_m3u ? m3u_path : sd_path);
    
    if (has_m3u && suffixMatch(".m3u", sd_path)) {
        getFirstDisc(m3u_path, sd_path);
    }
    
    char emu_name[256];
    getEmuName(sd_path, emu_name);
    
    if (should_resume) {
        char slot[16];
        getFile(slot_path, slot, 16);
        putFile(RESUME_SLOT_PATH, slot);
        should_resume = 0;
        
        if (has_m3u) {
            char rom_file[256];
            strcpy(rom_file, strrchr(m3u_path, '/') + 1);
            char disc_path_path[256];
            sprintf(disc_path_path, "%s/.minui/%s/%s.%s.txt", SHARED_USERDATA_PATH, emu_name, rom_file, slot);
            
            if (exists(disc_path_path)) {
                char disc_path[256];
                getFile(disc_path_path, disc_path, 256);
                if (disc_path[0] == '/')
                    strcpy(sd_path, disc_path);
                else {
                    strcpy(sd_path, m3u_path);
                    char* tmp = strrchr(sd_path, '/') + 1;
                    strcpy(tmp, disc_path);
                }
            }
        }
    } else {
        putInt(RESUME_SLOT_PATH, 8);
    }
    
    char emu_path[256];
    getEmuPath(emu_name, emu_path);
    
    addRecent(recent_path, recent_alias);
    saveLast(last == NULL ? sd_path : last);
    
    char cmd[256];
    if (isPSP == 2)
        sprintf(cmd, "'%s' '%s' 2", escapeSingleQuotes(emu_path), escapeSingleQuotes(sd_path));
    else
        sprintf(cmd, "'%s' '%s'", escapeSingleQuotes(emu_path), escapeSingleQuotes(sd_path));
    queueNext(cmd);
}

static void openDirectory(char* path, int auto_launch) {
    char auto_path[256];
    if (hasCue(path, auto_path) && auto_launch) {
        openRom(auto_path, path);
        return;
    }
    
    char m3u_path[256];
    strcpy(m3u_path, auto_path);
    char* tmp = strrchr(m3u_path, '.') + 1;
    strcpy(tmp, "m3u");
    if (exists(m3u_path) && auto_launch) {
        auto_path[0] = '\0';
        if (getFirstDisc(m3u_path, auto_path)) {
            openRom(auto_path, path);
            return;
        }
    }
    
    // ОСВОБОЖДАЕМ ИЗОБРАЖЕНИЯ ПЕРЕД ОТКРЫТИЕМ НОВОЙ ПАПКИ
    memset(bmp_slot_path, 0, sizeof(bmp_slot_path));
    if (surface_png) {
        SDL_FreeSurface(surface_png);
        surface_png = NULL;
    }
    if (prev_surface_png) {
        SDL_FreeSurface(prev_surface_png);
        prev_surface_png = NULL;
    }
    mem_index = -1;
    
    int selected = 0;
    int start = selected;
    int end = 0;
    if (top && top->entries->count > 0) {
        if (restore_depth == stack->count && top->selected == restore_relative) {
            selected = restore_selected;
            start = restore_start;
            end = restore_end;
        }
    }
    
    top = Directory_new(path, selected);
    top->start = start;
    top->end = end ? end : ((top->entries->count < MAIN_ROW_COUNT) ? top->entries->count : MAIN_ROW_COUNT);
    
    Array_push(stack, top);
    
    // Сбрасываем кеш и анимации карусели при входе в папку
    carousel_initialized = 0;
    carousel_cache_reset();
    list_anim.anim_frame = 0;
    scrollbar_anim_y = -1.0f;
    scrollbar_drop_from = -1.0f;
    scrollbar_prev_target = -1.0f;
    
    // Освобождаем снимок fade при смене папки
    if (fade_snapshot != NULL) {
        SDL_FreeSurface(fade_snapshot);
        fade_snapshot = NULL;
    }
    
    // ЗАГРУЖАЕМ ИЗОБРАЖЕНИЕ ТОЛЬКО ЕСЛИ ЕСТЬ ЭЛЕМЕНТЫ
    if (top->entries && top->entries->count > 0 && top->selected >= 0 && top->selected < top->entries->count) {
        Entry* entry = top->entries->items[top->selected];
        setPreviewImage(entry, 0);
    }
    
    dirty = 1;
}

static void closeDirectory(void) {
    // Сохраняем состояние для восстановления
    if (top && stack->count > 0) {
        restore_depth = stack->count - 1;
        restore_relative = 0;
        restore_selected = top->selected;
        restore_start = top->start;
        restore_end = top->end;
    }
    
    // ВАЖНО: освобождаем изображения ПЕРЕД удалением директории
    if (surface_png) {
        SDL_FreeSurface(surface_png);
        surface_png = NULL;
    }
    if (prev_surface_png) {
        SDL_FreeSurface(prev_surface_png);
        prev_surface_png = NULL;
    }
    
    // ВАЖНО: сбрасываем путь к сохранению при закрытии папки
    bmp_slot_path[0] = '\0';
    slot_path[0] = '\0';
    mem_index = -1;
    next_folder = 1;
    can_resume = 0; // Явно сбрасываем флаг
    scrollbar_anim_y = -1.0f;
    scrollbar_drop_from = -1.0f;
    scrollbar_prev_target = -1.0f;
    carousel_initialized = 0;
    carousel_cache_reset();
    
    // Освобождаем снимок fade при выходе из папки
    if (fade_snapshot != NULL) {
        SDL_FreeSurface(fade_snapshot);
        fade_snapshot = NULL;
    }
    // Закрываем директорию
    if (stack->count > 0) {
        DirectoryArray_pop(stack);
    }
    
    // Восстанавливаем верхнюю директорию
    if (stack->count > 0) {
        top = stack->items[stack->count - 1];
    } else {
        top = NULL;
    }
    
    isPSP = 0;
    
    // ЗАГРУЖАЕМ ИЗОБРАЖЕНИЕ ДЛЯ НОВОГО ВЫДЕЛЕННОГО ЭЛЕМЕНТА
    if (top && top->entries && top->entries->count > 0 && 
        top->selected >= 0 && top->selected < top->entries->count) {
        Entry* entry = top->entries->items[top->selected];
        
        // Явно сбрасываем пути перед загрузкой
        bmp_slot_path[0] = '\0';
        slot_path[0] = '\0';
        
        // Обновляем сохранение для нового элемента
        readyResume(entry);
        
        surface_png = loadImageWithPriority(entry, select_themes, 
                                           (bmp_slot_path[0] != '\0') ? bmp_slot_path : NULL);
        if (surface_png && surface_png->w > 0 && surface_png->h > 0) {
            mem_index = top->selected;
        }
    }
    
    dirty = 1;
}

static int drawViewer(void);

static void Entry_open(Entry* self) {
    recent_alias = self->name;
    
    // КЛЮЧЕВОЕ ИЗМЕНЕНИЕ:
    // Открываем в просмотрщике ТОЛЬКО изображения из папки скриншотов
    if (self->type == ENTRY_IMAGE && prefixMatch(SCREENSHOTS_PATH, self->path)) {
        // Только для скриншотов - открываем просмотрщик
        loadImagesForViewer(self->path);
        viewer_mode = 1;
        viewer_load_image();
        dirty = 1;
        while(!drawViewer()){};
    } 
    else if (self->type == ENTRY_ROM) {
        // ВСЕ остальные PNG/изображения - как обычные ROM
        char* last = NULL;
        if (prefixMatch(COLLECTIONS_PATH, top->path)) {
            char* tmp;
            char filename[256];
            tmp = strrchr(self->path, '/');
            if (tmp) strcpy(filename, tmp + 1);
            char last_path[256];
            sprintf(last_path, "%s/%s", top->path, filename);
            last = last_path;
        }
        openRom(self->path, last);
    } 
    else if (self->type == ENTRY_PAK) {
        openPak(self->path);
    } 
    else if (self->type == ENTRY_DIR) {
        openDirectory(self->path, 1);
    }
}

static void saveLast(char* path) {
    if (exactMatch(top->path, FAUX_RECENT_PATH)) {
        path = FAUX_RECENT_PATH;
    } else if (exactMatch(top->path, FAUX_FAVORITE_PATH)) {
        path = FAUX_FAVORITE_PATH;
    }
    putFile(LAST_PATH, path);
}

static void loadLast(void) {
    if (!exists(LAST_PATH)) return;
    char last_path[256];
    getFile(LAST_PATH, last_path, 256);
    char full_path[256];
    strcpy(full_path, last_path);
    char* tmp;
    char filename[256];
    tmp = strrchr(last_path, '/');
    if (tmp) strcpy(filename, tmp);
    Array* last = Array_new();
    while (!exactMatch(last_path, SDCARD_PATH)) {
        Array_push(last, strdup(last_path));
        char* slash = strrchr(last_path, '/');
        if (!slash) break; // защита от пустого пути
        last_path[(slash - last_path)] = '\0';
    }
    while (last->count > 0) {
        char* path = Array_pop(last);
        if (!exactMatch(path, ROMS_PATH)) {
            char collated_path[256];
            collated_path[0] = '\0';
            if (suffixMatch(")", path) && isConsoleDir(path)) {
                strcpy(collated_path, path);
                tmp = strrchr(collated_path, '(');
                if (tmp) tmp[1] = '\0';
            }
            for (int i = 0; i < top->entries->count; i++) {
                Entry* entry = top->entries->items[i];
                if (exactMatch(entry->path, path) ||
                    (strlen(collated_path) && prefixMatch(collated_path, entry->path)) ||
                    (prefixMatch(COLLECTIONS_PATH, full_path) && suffixMatch(filename, entry->path))) {

                    top->selected = i;
                    if (i >= top->end) {
                        top->start = i;
                        top->end = top->start + MAIN_ROW_COUNT;
                        if (top->end > top->entries->count) {
                            top->end = top->entries->count;
                            top->start = top->end - MAIN_ROW_COUNT;
                        }
                    }

                    if (last->count == 0 &&
                        !exactMatch(entry->path, FAUX_RECENT_PATH) &&
                        !(prefixMatch(COLLECTIONS_PATH, entry->path) && !exactMatch(entry->path, COLLECTIONS_PATH))) {

                        // ✅ Безопасная загрузка изображения
                        setPreviewImage(entry, 0);
                        break;
                    }

                    if (entry->type == ENTRY_DIR) {
                        openDirectory(entry->path, 0);
                        break;
                    }
                }
            }
        }
        free(path);
    }
    StringArray_free(last);
}

static void Menu_init(void) {
    stack = Array_new();
    recents = Array_new();
    favorites = Array_new();
    openDirectory(SDCARD_PATH, 0);
    loadLast();

    // ✅ Устанавливаем изображение только если всё валидно
    if (top &&
        top->entries &&
        top->entries->count > 0 &&
        top->selected >= 0 &&
        top->selected < top->entries->count) {
        setPreviewImage(top->entries->items[top->selected], 0);
    } else {
        // На всякий случай сбрасываем
        surface_png = NULL;
        prev_surface_png = NULL;
        mem_index = -1;
    }

    dirty = 1;
}

static void Menu_quit(void) {
    // Освобождаем все изображения
    if (surface_png) {
        SDL_FreeSurface(surface_png);
        surface_png = NULL;
    }
    if (prev_surface_png) {
        SDL_FreeSurface(prev_surface_png);
        prev_surface_png = NULL;
    }
    
    RecentArray_free(recents);
    FavoriteArray_free(favorites);
    DirectoryArray_free(stack);
}

// Упрощенная функция для получения информации о ядре
static int getCoreInfo(Entry* entry, char* emu_name_out, char* core_name_out, size_t out_size) {
    if (!entry || !emu_name_out || !core_name_out || out_size == 0) {
        return 0;
    }
    
    LOG_info("getCoreInfo for: %s\n", entry->path);
    
    // 1. Получаем имя эмулятора (тег) из пути к ROM
    getEmuName(entry->path, emu_name_out);
    LOG_info("Emulator tag: '%s'\n", emu_name_out);
    
    // 2. Ищем .pak файл для этого эмулятора в нескольких местах
    char launch_path[512];
    int found_launch = 0;
    
    // Вариант 1: /sdcard/Emus/<platform>/<emu_tag>.pak
    snprintf(launch_path, sizeof(launch_path), "%s/Emus/%s/%s.pak/launch.sh", 
             SDCARD_PATH, PLATFORM, emu_name_out);
    LOG_info("Trying path 1: %s\n", launch_path);
    
    if (exists(launch_path)) {
        found_launch = 1;
    }
    
    // Вариант 2: /sdcard/.system/<platform>/paks/Emus/<emu_tag>.pak
    if (!found_launch) {
        snprintf(launch_path, sizeof(launch_path), "%s/paks/Emus/%s.pak/launch.sh", 
                 SYSTEM_PATH, emu_name_out);
        LOG_info("Trying path 2: %s\n", launch_path);
        
        if (exists(launch_path)) {
            found_launch = 1;
        }
    }
    
    // Вариант 3: /sdcard/Emus/<emu_tag>.pak (без платформы)
    if (!found_launch) {
        snprintf(launch_path, sizeof(launch_path), "%s/Emus/%s.pak/launch.sh", 
                 SDCARD_PATH, emu_name_out);
        LOG_info("Trying path 3: %s\n", launch_path);
        
        if (exists(launch_path)) {
            found_launch = 1;
        }
    }
    
    // Вариант 4: /sdcard/.system/<platform>/paks/<emu_tag>.pak
    if (!found_launch) {
        snprintf(launch_path, sizeof(launch_path), "%s/paks/%s.pak/launch.sh", 
                 SYSTEM_PATH, emu_name_out);
        LOG_info("Trying path 4: %s\n", launch_path);
        
        if (exists(launch_path)) {
            found_launch = 1;
        }
    }
    
    if (!found_launch) {
        LOG_error("launch.sh not found for emulator: %s\n", emu_name_out);
        return 0;
    }
    
    LOG_info("Found launch.sh at: %s\n", launch_path);
    
    // 3. Читаем launch.sh чтобы найти имя ядра
    FILE* file = fopen(launch_path, "r");
    if (!file) {
        LOG_error("Cannot open launch.sh: %s\n", launch_path);
        return 0;
    }
    
    char line[256];
    int found_core = 0;
    
    while (fgets(line, sizeof(line), file)) {
        // Обрезаем перевод строки
        char* newline = strchr(line, '\n');
        if (newline) *newline = '\0';
        
        // Ищем строку с EMU_EXE=
        if (strstr(line, "EMU_EXE=")) {
            // Формат: EMU_EXE=desmume
            char* equals = strchr(line, '=');
            if (equals) {
                equals++; // Пропускаем '='
                
                // Копируем имя ядра
                char* end = equals;
                while (*end && *end != ' ' && *end != '\t' && *end != '\r' && *end != '\n' && *end != '#') {
                    end++;
                }
                
                int len = end - equals;
                if (len > 0 && len < (int)out_size) {
                    strncpy(core_name_out, equals, len);
                    core_name_out[len] = '\0';
                    found_core = 1;
                    LOG_info("Found core in EMU_EXE: %s\n", core_name_out);
                    break;
                }
            }
        }
    }
    
    fclose(file);
    
    // Если не нашли EMU_EXE, ищем по-другому
    if (!found_core) {
        file = fopen(launch_path, "r");
        if (file) {
            while (fgets(line, sizeof(line), file)) {
                char* newline = strchr(line, '\n');
                if (newline) *newline = '\0';
                
                // Ищем строку с _libretro.so
                char* libretro = strstr(line, "_libretro.so");
                if (libretro) {
                    // Ищем начало имени ядра
                    char* start = libretro;
                    while (start > line && *start != '/' && *start != '"' && 
                           *start != '\'' && *start != '$' && *start != '{') {
                        start--;
                    }
                    
                    // Пропускаем разделитель
                    if (*start == '/' || *start == '"' || *start == '\'' || 
                        *start == '$' || *start == '{') {
                        start++;
                    }
                    
                    int len = libretro - start;
                    if (len > 0 && len < (int)out_size) {
                        strncpy(core_name_out, start, len);
                        core_name_out[len] = '\0';
                        found_core = 1;
                        LOG_info("Found core in libretro line: %s\n", core_name_out);
                        break;
                    }
                }
            }
            fclose(file);
        }
    }
    
    if (!found_core) {
        LOG_error("Cannot extract core name from launch.sh\n");
        return 0;
    }
    
    LOG_info("Success: emu='%s', core='%s'\n", emu_name_out, core_name_out);
    return 1;
}

// Функция для поиска конфигурационной директории
static int findConfigDir(const char* emu_name, const char* core_name, char* config_dir_out, size_t out_size) {
    if (!emu_name || !core_name || !config_dir_out || out_size == 0) {
        return 0;
    }
    
    char test_path[512];
    
    // Вариант 1: стандартный формат <emu>-<core>
    snprintf(test_path, sizeof(test_path), "%s/%s-%s", USERDATA_PATH, emu_name, core_name);
    LOG_info("Checking config dir: %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(config_dir_out, test_path, out_size - 1);
        config_dir_out[out_size - 1] = '\0';
        return 1;
    }
    
    // Вариант 2: только имя эмулятора
    snprintf(test_path, sizeof(test_path), "%s/%s", USERDATA_PATH, emu_name);
    LOG_info("Checking config dir (emu only): %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(config_dir_out, test_path, out_size - 1);
        config_dir_out[out_size - 1] = '\0';
        return 1;
    }
    
    // Вариант 3: с libretro префиксом
    snprintf(test_path, sizeof(test_path), "%s/%s-libretro_%s", USERDATA_PATH, emu_name, core_name);
    LOG_info("Checking config dir (libretro): %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(config_dir_out, test_path, out_size - 1);
        config_dir_out[out_size - 1] = '\0';
        return 1;
    }
    
    // Для Virtual Boy пробуем специальные варианты
    if (strcasecmp(core_name, "vb") == 0 || strstr(core_name, "mednafen") != NULL) {
        // Вариант для Virtual Boy: BVB-mednafen_vb
        snprintf(test_path, sizeof(test_path), "%s/%s-mednafen_vb", USERDATA_PATH, emu_name);
        LOG_info("Checking config dir (Virtual Boy): %s\n", test_path);
        
        if (exists(test_path)) {
            strncpy(config_dir_out, test_path, out_size - 1);
            config_dir_out[out_size - 1] = '\0';
            return 1;
        }
        
        // Вариант: BVB-vb
        snprintf(test_path, sizeof(test_path), "%s/%s-vb", USERDATA_PATH, emu_name);
        LOG_info("Checking config dir (vb): %s\n", test_path);
        
        if (exists(test_path)) {
            strncpy(config_dir_out, test_path, out_size - 1);
            config_dir_out[out_size - 1] = '\0';
            return 1;
        }
    }
    
    LOG_error("Config directory not found for %s-%s\n", emu_name, core_name);
    return 0;
}

// Функция для получения имени конфига игры (полное имя файла с .cfg расширением)
static void getGameConfigName(Entry* entry, char* config_name_out, size_t out_size) {
    if (!entry || !config_name_out || out_size == 0) return;
    
    // Получаем имя файла без пути
    const char* filename = strrchr(entry->path, '/');
    if (filename) filename++;
    else filename = entry->path;
    
    LOG_info("Original ROM filename: %s\n", filename);
    
    // Создаем имя конфига: <имя_файла_рома>.cfg
    // Например: "Mario's Tennis (JU) _a1_.vb.cfg"
    snprintf(config_name_out, out_size, "%s.cfg", filename);
    
    LOG_info("Config filename: %s\n", config_name_out);
}

// Функция для поиска всех возможных имен конфигов
static int findGameConfig(const char* config_dir, const char* rom_filename, char* found_config_out, size_t out_size) {
    if (!config_dir || !rom_filename || !found_config_out || out_size == 0) {
        return 0;
    }
    
    LOG_info("Looking for config for ROM: %s\n", rom_filename);
    
    char base_name[256];
    char test_name[256];
    char test_path[512];
    
    // 1. Пробуем точное имя файла с .cfg
    snprintf(test_path, sizeof(test_path), "%s/%s.cfg", config_dir, rom_filename);
    LOG_info("Trying exact match: %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(found_config_out, test_path, out_size - 1);
        found_config_out[out_size - 1] = '\0';
        LOG_info("Found exact match!\n");
        return 1;
    }
    
    // 2. Если в имени есть пробелы или специальные символы, пробуем варианты
    strncpy(base_name, rom_filename, sizeof(base_name) - 1);
    base_name[sizeof(base_name) - 1] = '\0';
    
    // Убираем расширение .vb
    char* dot = strrchr(base_name, '.');
    if (dot) *dot = '\0';
    
    LOG_info("Base name without extension: %s\n", base_name);
    
    // Вариант 2a: с заменой пробелов на подчеркивания
    strcpy(test_name, base_name);
    for (int i = 0; test_name[i]; i++) {
        if (test_name[i] == ' ') test_name[i] = '_';
        if (test_name[i] == '\'') test_name[i] = '_'; // Апострофы тоже заменяем
    }
    
    snprintf(test_path, sizeof(test_path), "%s/%s.cfg", config_dir, test_name);
    LOG_info("Trying with underscores: %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(found_config_out, test_path, out_size - 1);
        found_config_out[out_size - 1] = '\0';
        LOG_info("Found with underscores!\n");
        return 1;
    }
    
    // Вариант 2b: убираем квадратные скобки
    strcpy(test_name, base_name);
    char* bracket = strchr(test_name, '[');
    while (bracket) {
        char* close_bracket = strchr(bracket, ']');
        if (close_bracket) {
            memmove(bracket, close_bracket + 1, strlen(close_bracket));
        } else {
            *bracket = '\0';
            break;
        }
        bracket = strchr(test_name, '[');
    }
    
    // Обрезаем пробелы
    int len = strlen(test_name);
    while (len > 0 && test_name[len-1] == ' ') {
        test_name[len-1] = '\0';
        len--;
    }
    
    snprintf(test_path, sizeof(test_path), "%s/%s.cfg", config_dir, test_name);
    LOG_info("Trying without brackets: %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(found_config_out, test_path, out_size - 1);
        found_config_out[out_size - 1] = '\0';
        LOG_info("Found without brackets!\n");
        return 1;
    }
    
    // Вариант 2c: убираем круглые скобки с региональными кодами
    strcpy(test_name, base_name);
    char* paren = strchr(test_name, '(');
    while (paren) {
        char* close_paren = strchr(paren, ')');
        if (close_paren) {
            int code_len = close_paren - paren - 1;
            if (code_len >= 1 && code_len <= 4) {
                // Это короткий региональный код, убираем
                memmove(paren, close_paren + 1, strlen(close_paren));
            } else {
                // Длинное содержимое, оставляем
                paren = strchr(close_paren + 1, '(');
            }
        } else {
            *paren = '\0';
            break;
        }
        paren = strchr(test_name, '(');
    }
    
    // Обрезаем пробелы
    len = strlen(test_name);
    while (len > 0 && test_name[len-1] == ' ') {
        test_name[len-1] = '\0';
        len--;
    }
    
    snprintf(test_path, sizeof(test_path), "%s/%s.cfg", config_dir, test_name);
    LOG_info("Trying without regional codes: %s\n", test_path);
    
    if (exists(test_path)) {
        strncpy(found_config_out, test_path, out_size - 1);
        found_config_out[out_size - 1] = '\0';
        LOG_info("Found without regional codes!\n");
        return 1;
    }
    
    // 3. Пробуем перебрать все файлы .cfg в директории
    DIR* dir = opendir(config_dir);
    if (dir) {
        struct dirent* dp;
        LOG_info("Scanning directory for configs...\n");
        
        while ((dp = readdir(dir)) != NULL) {
            if (suffixMatch(".cfg", dp->d_name)) {
                LOG_info("Found config file: %s\n", dp->d_name);
                
                // Проверяем, содержит ли имя конфига основное имя игры
                if (strstr(dp->d_name, "Mario") && strstr(dp->d_name, "Tennis")) {
                    snprintf(test_path, sizeof(test_path), "%s/%s", config_dir, dp->d_name);
                    strncpy(found_config_out, test_path, out_size - 1);
                    found_config_out[out_size - 1] = '\0';
                    closedir(dir);
                    LOG_info("Found by partial match: %s\n", dp->d_name);
                    return 1;
                }
            }
        }
        closedir(dir);
    }
    
    LOG_warn("No config file found for: %s\n", rom_filename);
    return 0;
}

// Упрощенная функция сброса настроек ядра
static void resetCoreSettings(Entry* entry) {
    if (!entry) return;
    
    LOG_info("=== resetCoreSettings ===\n");
    LOG_info("Entry: %s\n", entry->path);
    
    char emu_name[256] = {0};
    char core_name[256] = {0};
    
    // Получаем информацию о ядре
    if (!getCoreInfo(entry, emu_name, core_name, sizeof(core_name))) {
        LOG_error("Cannot get core info\n");
        PLAT_showPopup(language_get_string("CORE_NOT_FOUND"));
        return;
    }
    
    // Ищем конфигурационную директорию
    char config_dir[512];
    if (!findConfigDir(emu_name, core_name, config_dir, sizeof(config_dir))) {
        LOG_warn("Config directory not found\n");
        PLAT_showPopup(language_get_string("NO_CORE_SETTINGS_FOUND"));
        return;
    }
    
    LOG_info("Using config directory: %s\n", config_dir);
    
    // Удаляем конфигурационные файлы
    int deleted_count = 0;
    
    // 1. Удаляем minarch.cfg (конфиг ядра)
    char minarch_cfg[512];
    snprintf(minarch_cfg, sizeof(minarch_cfg), "%s/minarch.cfg", config_dir);
    LOG_info("Checking for core config: %s\n", minarch_cfg);
    
    if (exists(minarch_cfg)) {
        if (remove(minarch_cfg) == 0) {
            LOG_info("Deleted core config: %s\n", minarch_cfg);
            deleted_count++;
        } else {
            LOG_error("Failed to delete: %s\n", minarch_cfg);
        }
    } else {
        LOG_info("Core config not found: %s\n", minarch_cfg);
    }
    
    // 2. Удаляем все .cfg файлы игр
    DIR* dir = opendir(config_dir);
    if (dir) {
        struct dirent* dp;
        LOG_info("Looking for game configs...\n");
        
        while ((dp = readdir(dir)) != NULL) {
            // Ищем файлы .cfg (кроме minarch.cfg)
            const char* ext = strrchr(dp->d_name, '.');
            if (ext && strcasecmp(ext, ".cfg") == 0 && 
                strcmp(dp->d_name, "minarch.cfg") != 0) {
                
                char game_cfg[512];
                snprintf(game_cfg, sizeof(game_cfg), "%s/%s", config_dir, dp->d_name);
                
                LOG_info("Found game config: %s\n", dp->d_name);
                
                if (remove(game_cfg) == 0) {
                    LOG_info("Deleted game config: %s\n", dp->d_name);
                    deleted_count++;
                } else {
                    LOG_error("Failed to delete: %s\n", dp->d_name);
                }
            }
        }
        closedir(dir);
    } else {
        LOG_error("Could not open config directory: %s\n", config_dir);
    }
    
    // Результат
    if (deleted_count > 0) {
        char msg[256];
        snprintf(msg, sizeof(msg), "%s: %d %s", 
                language_get_string("CORE_SETTINGS_RESET"),
                deleted_count,
                language_get_string("FILES_DELETED"));
        PLAT_showPopup(msg);
    } else {
        PLAT_showPopup(language_get_string("NO_CORE_SETTINGS_FOUND"));
    }
    
    LOG_info("Deleted %d files\n", deleted_count);
}

// Упрощенная функция сброса настроек игры
static void resetGameSettings(Entry* entry) {
    if (!entry) return;
    
    LOG_info("=== resetGameSettings ===\n");
    LOG_info("Entry: %s\n", entry->path);
    
    char emu_name[256] = {0};
    char core_name[256] = {0};
    
    // Получаем информацию о ядре
    if (!getCoreInfo(entry, emu_name, core_name, sizeof(core_name))) {
        LOG_error("Cannot get core info\n");
        PLAT_showPopup(language_get_string("CORE_NOT_FOUND"));
        return;
    }
    
    // Ищем конфигурационную директорию
    char config_dir[512];
    if (!findConfigDir(emu_name, core_name, config_dir, sizeof(config_dir))) {
        LOG_warn("Config directory not found\n");
        PLAT_showPopup(language_get_string("NO_GAME_SETTINGS_FOUND"));
        return;
    }
    
    LOG_info("Config directory: %s\n", config_dir);
    
    // Получаем имя файла ROM
    const char* rom_filename = strrchr(entry->path, '/');
    if (rom_filename) rom_filename++;
    else rom_filename = entry->path;
    
    // Ищем конфиг игры
    char game_cfg[512];
    if (!findGameConfig(config_dir, rom_filename, game_cfg, sizeof(game_cfg))) {
        LOG_warn("Game config not found\n");
        PLAT_showPopup(language_get_string("NO_GAME_SETTINGS_FOUND"));
        return;
    }
    
    LOG_info("Found config file: %s\n", game_cfg);
    
    // Получаем короткое имя файла для сообщения
    const char* cfg_filename = strrchr(game_cfg, '/');
    if (cfg_filename) cfg_filename++;
    else cfg_filename = game_cfg;
    
    char display_name[256];
    strncpy(display_name, cfg_filename, sizeof(display_name) - 1);
    display_name[sizeof(display_name) - 1] = '\0';
    
    // Убираем .cfg расширение для отображения
    char* dot = strrchr(display_name, '.');
    if (dot && strcmp(dot, ".cfg") == 0) {
        *dot = '\0';
    }
    
    // Удаляем конфигурационный файл игры
    LOG_info("Deleting: %s\n", game_cfg);
    
    if (remove(game_cfg) == 0) {
        char msg[256];
        snprintf(msg, sizeof(msg), "%s\n%s", 
                language_get_string("GAME_SETTINGS_RESET"),
                display_name);
        PLAT_showPopup(msg);
    } else {
        LOG_error("Failed to delete: %s\n", game_cfg);
        PLAT_showPopup(language_get_string("ERROR_DELETING_FILE"));
    }
}

// Добавляем новую функцию для режима просмотрщика
static int drawViewer(void) {
    uint32_t now = SDL_GetTicks();
    PAD_poll();
    
    int viewer_dirty = 1;
    int quit_viewer = 0;
    
    // Обработка ввода для просмотрщика
    if (PAD_justPressed(BTN_LEFT) || PAD_justPressed(BTN_L1)) {
        // Предыдущее изображение
        if (viewer_index > 0) {
            viewer_index--;
            viewer_load_image();
            viewer_pan_x = 0;
            viewer_pan_y = 0;
            viewer_dirty = 1;
        }
    }
    else if (PAD_justPressed(BTN_RIGHT) || PAD_justPressed(BTN_R1)) {
        // Следующее изображение
        if (viewer_images && viewer_index < viewer_images->count - 1) {
            viewer_index++;
            viewer_load_image();
            viewer_pan_x = 0;
            viewer_pan_y = 0;
            viewer_dirty = 1;
        }
    }
    else if (PAD_justPressed(BTN_UP)) {
        // Увеличение
        if (viewer_zoom < 400) {
            viewer_zoom += 25;
            viewer_apply_transformations();
            viewer_dirty = 1;
        }
    }
    else if (PAD_justPressed(BTN_DOWN)) {
        // Уменьшение
        if (viewer_zoom > 25) {
            viewer_zoom -= 25;
            viewer_apply_transformations();
            viewer_dirty = 1;
        }
    }
    else if (PAD_justPressed(BTN_X)) {
        // Переключение информации
        viewer_info_visible = !viewer_info_visible;
        viewer_dirty = 1;
    }
    else if (PAD_justPressed(BTN_Y)) {
        // Переключение фильтра
        viewer_filter = (viewer_filter + 1) % 2;
        viewer_apply_transformations();
        viewer_dirty = 1;
    }
    else if (PAD_justPressed(getButtonA())) {
        // Полноэкранный режим
        viewer_fullscreen = !viewer_fullscreen;
        viewer_info_visible = !viewer_fullscreen;
        viewer_dirty = 1;
    }
    else if (PAD_justPressed(BTN_L2)) {
        // Поворот против часовой
        viewer_rotation = (viewer_rotation + 270) % 360;
        viewer_apply_transformations();
        viewer_dirty = 1;
    }
    else if (PAD_justPressed(BTN_R2)) {
        // Поворот по часовой
        viewer_rotation = (viewer_rotation + 90) % 360;
        viewer_apply_transformations();
        viewer_dirty = 1;
    }
    else if (PAD_justPressed(getButtonB())) {
        // Выход из просмотрщика
        quit_viewer = 1;
    }
    else if (PAD_tappedMenu(now)) {
        // Сброс настроек просмотрщика
        viewer_zoom = 100;
        viewer_rotation = 0;
        viewer_filter = 0;
        viewer_pan_x = 0;
        viewer_pan_y = 0;
        viewer_fullscreen = 0;
        viewer_info_visible = 1;
        viewer_apply_transformations();
        viewer_dirty = 1;
    }
    
    // Панорамирование при удержании кнопок
    if (PAD_isPressed(BTN_L2) && PAD_isPressed(BTN_UP)) {
        viewer_pan_y += 5;
        viewer_dirty = 1;
    }
    if (PAD_isPressed(BTN_L2) && PAD_isPressed(BTN_DOWN)) {
        viewer_pan_y -= 5;
        viewer_dirty = 1;
    }
    if (PAD_isPressed(BTN_L2) && PAD_isPressed(BTN_LEFT)) {
        viewer_pan_x += 5;
        viewer_dirty = 1;
    }
    if (PAD_isPressed(BTN_L2) && PAD_isPressed(BTN_RIGHT)) {
        viewer_pan_x -= 5;
        viewer_dirty = 1;
    }
    
    // Если выходим из просмотрщика
    if (quit_viewer) {
        viewer_cleanup();
        return 1; // Выйти из просмотрщика
    }
    
    // Перерисовка если нужно
    if (viewer_dirty) {
        GFX_clear(screen);
        viewer_draw_image();
        viewer_draw_info();
        GFX_flip(screen);
    } else {
        GFX_sync();
    }
    
    return 0; // Остаемся в просмотрщике
}

void drawIcon(SDL_Surface* dst, char* src_ptr, int x, int y, int reverse) {
    SDL_Surface* icon = SDL_CreateRGBSurfaceWithFormatFrom(src_ptr, 16, 16, 1, 2, SDL_PIXELFORMAT_INDEX1MSB);
    SDL_Color bwpalette[] = {{.r = 217, .g = 217, .b = 210}, {.r = 0, .g = 0, .b = 0}};
    SDL_Color rbwpalette[] = {{.r = 0, .g = 0, .b = 0}, {.r = 217, .g = 217, .b = 210}};
    if (reverse)
        SDL_SetPaletteColors(icon->format->palette, rbwpalette, 0, 2);
    else
        SDL_SetPaletteColors(icon->format->palette, bwpalette, 0, 2);
    SDL_BlitSurface(icon, NULL, dst, &(SDL_Rect){x, y});
    SDL_FreeSurface(icon);
}

char icon_key_left[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x08, 0x00, 0x10, 0x00, 0x3F, 0xFC, 0x10, 0x00, 0x08, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
char icon_key_right[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x10, 0x00, 0x08, 0x3F, 0xFC, 0x00, 0x08, 0x00, 0x10, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
char icon_key_delite[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0xFC, 0x08, 0x04, 0x11, 0x14, 0x20, 0xA4, 0x40, 0x44, 0x20, 0xA4, 0x11, 0x14, 0x08, 0x04, 0x07, 0xFC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
char icon_key_find[] = {0x00, 0x00, 0x00, 0x00, 0x07, 0x00, 0x08, 0x80, 0x10, 0x40, 0x10, 0x40, 0x10, 0x40, 0x08, 0x80, 0x07, 0x40, 0x00, 0x20, 0x00, 0x10, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
char icon_key_cursor[] = {0x38, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x10, 0x0, 0x38, 0x0, 0x0, 0x0, 0x0, 0x0};

int drawKeyboard(SDL_Surface* s, char* input, int animation, int x, int y) {
    const char v_keys[] = "0123456789qwertyuiopasdfghjkl zxcvbnm  ";
    SDL_Surface* one_char = NULL;
    SDL_Surface* keyboard_surface = SDL_CreateRGBSurface(0, 213, 146, 16, 0, 0, 0, 0);
    int cursor_x = 0;
    int cursor_y = 0;
    int charWidth;
    int stringWidth;
    int quit = 0;
    int txt_size = 0;
    int start_print_text;
    int position;
    
    one_char = TTF_RenderGlyph_Blended(font.small, 'W', (SDL_Color){220, 220, 220});
    charWidth = one_char->w;
    stringWidth = 180 / charWidth;
    SDL_FreeSurface(one_char);
    txt_size = 0;
    while (input[txt_size++]) {
    }
    start_print_text = (txt_size > stringWidth) ? txt_size - stringWidth : 0;
    position = txt_size - 1;
    
    if (animation)
        for (int i = 6; i > 0; i--) {
            SDL_FillRect(keyboard_surface, &(SDL_Rect){0, 0, 213, 146}, 0xDEDB);
            FillRoundRect(keyboard_surface, 1 + i * 10, 1 + i * 10, 211 - i * 20, 142 - i * 20, 4, 0xDEDA);
            FillRoundRect(keyboard_surface, 4 + i * 10, 4 + i * 10, 204 - i * 20, 24 - i * 2, 4, 0x0000);
            SDL_SetColorKey(keyboard_surface, SDL_TRUE, 0xDEDB);
            SDL_BlitSurface(keyboard_surface, NULL, s, &(SDL_Rect){x, y});
            GFX_flip(s);
            SDL_Delay(16);
        }
        
    dirty = 1;
    
    while (!quit) {
        uint32_t frame_start = SDL_GetTicks();
        if (!animation) {
                list_anim.list_anim_frame = 0;
                list_anim.bg_anim_frame = 0;
                list_anim.bg_anim_frame = 0;
                }
                
        PAD_poll();
        
        if (PAD_justPressed(BTN_UP)) {
            if (cursor_y > 0)
                cursor_y--;
            else
                cursor_y = 3;
            dirty = 1;
        } else if (PAD_justPressed(BTN_DOWN)) {
            if (cursor_y < 3)
                cursor_y++;
            else
                cursor_y = 0;
            dirty = 1;
        } else if (PAD_justPressed(BTN_LEFT)) {
            if (cursor_x > 0)
                cursor_x--;
            else
                cursor_x = 9;
            dirty = 1;
        } else if (PAD_justPressed(BTN_L1)) {
            if (position > 0) {
                position--;
                if (position < start_print_text)
                    start_print_text--;
            }
            dirty = 1;
        } else if (PAD_justPressed(BTN_R1)) {
            if (position < txt_size - 1) {
                position++;
                if (position > start_print_text + stringWidth - 1)
                    start_print_text++;
            }
            dirty = 1;
        } else if (PAD_justPressed(BTN_RIGHT)) {
            if (cursor_x < 9)
                cursor_x++;
            else
                cursor_x = 0;
            dirty = 1;
        }
        if (PAD_justPressed(getButtonB())) {
            quit = 1;
            txt_size = 0;
        }
        if (PAD_justPressed(getButtonA())) {
            if (cursor_x == 7 && cursor_y == 3) {
                if (position > 0) {
                    position--;
                    if (position < start_print_text)
                        start_print_text--;
                }
            } else if (cursor_x == 8 && cursor_y == 3) {
                if (position < txt_size - 1) {
                    position++;
                    if (position > start_print_text + stringWidth - 1)
                        start_print_text++;
                }
            } else if (cursor_x == 9 && cursor_y == 3) {
                quit = 1;
            } else if (cursor_x == 9 && cursor_y == 2) {
                if (position > 0 && txt_size > 0) {
                    position--;
                    for (int i = position; i < txt_size; i++)
                        input[i] = input[i + 1];
                    input[txt_size - 1] = '\0';
                    txt_size--;
                    if (start_print_text > 0)
                        start_print_text--;
                }
            } else if (txt_size < 254) {
                for (int i = txt_size; i > position; i--)
                    input[i] = input[i - 1];
                input[position++] = v_keys[cursor_y * 10 + cursor_x];
                input[txt_size + 1] = '\0';
                txt_size++;
                if (position - start_print_text + 1 > stringWidth)
                    start_print_text++;
            }
            dirty = 1;
        }
        
        if (dirty) {
            dirty = 0;
            SDL_FillRect(keyboard_surface, &(SDL_Rect){0, 0, 213, 146}, 0xDEDB);
            FillRoundRect(keyboard_surface, 1, 1, 211, 142, 4, 0xDEDA);
            FillRoundRect(keyboard_surface, 4, 4, 204, 24, 4, 0x0000);
            txt_size = 0;
            while (input[txt_size++]) {
            }
            drawIcon(keyboard_surface, icon_key_cursor, 7 + (position - start_print_text) * charWidth, 10, 1);
            int i = 0, xi = 0;
            for (i = start_print_text; i < start_print_text + stringWidth; i++) {
                if (!input[i])
                    break;
                one_char = TTF_RenderGlyph_Blended(font.small, input[i], COLOR_WHITE);
                SDL_BlitSurface(one_char, NULL, keyboard_surface, &(SDL_Rect){12 + xi * charWidth, 11});
                SDL_FreeSurface(one_char);
                xi++;
            }
            
            for (int yi = 0; yi < 4; yi++)
                for (int xi = 0; xi < 10; xi++) {
                    one_char = TTF_RenderGlyph_Blended(font.small, v_keys[yi * 10 + xi], (SDL_Color){10, 10, 10});
                    SDL_BlitSurface(one_char, NULL, keyboard_surface, &(SDL_Rect){xi * 20 + 12, yi * 28 + 40});
                    SDL_FreeSurface(one_char);
                }
            
            drawIcon(keyboard_surface, icon_key_left, 148, 122, 0);
            drawIcon(keyboard_surface, icon_key_right, 168, 122, 0);
            drawIcon(keyboard_surface, icon_key_find, 188, 122, 0);
            drawIcon(keyboard_surface, icon_key_delite, 188, 94, 0);
            
            FillRoundRect(keyboard_surface, 4 + cursor_x * 20, 32 + cursor_y * 28, 24, 24, 4, 0x0000);
            one_char = TTF_RenderGlyph_Blended(font.small, v_keys[cursor_y * 10 + cursor_x], (SDL_Color){220, 220, 220});
            SDL_BlitSurface(one_char, NULL, keyboard_surface, &(SDL_Rect){cursor_x * 20 + 12, cursor_y * 28 + 40});
            SDL_FreeSurface(one_char);
            if (cursor_x == 7 && cursor_y == 3)
                drawIcon(keyboard_surface, icon_key_left, 148, 122, 1);
            else if (cursor_x == 8 && cursor_y == 3)
                drawIcon(keyboard_surface, icon_key_right, 168, 122, 1);
            else if (cursor_x == 9 && cursor_y == 3)
                drawIcon(keyboard_surface, icon_key_find, 188, 122, 1);
            else if (cursor_x == 9 && cursor_y == 2)
                drawIcon(keyboard_surface, icon_key_delite, 188, 94, 1);
            
            SDL_SetColorKey(keyboard_surface, SDL_TRUE, 0xDEDB);
            SDL_BlitSurface(keyboard_surface, NULL, s, &(SDL_Rect){x, y});
            GFX_flip(s);
        } else
            GFX_sync();
    }
    
    SDL_FreeSurface(keyboard_surface);
    return txt_size;
}

// Функция проверки, можно ли удалить выбранный элемент
static int canDeleteSelectedEntry(void) {
    if (!top || !top->entries || top->selected < 0 || 
        top->selected >= top->entries->count) {
        return 0;
    }
    
    Entry* entry = top->entries->items[top->selected];
    
    // Нельзя удалять папки и .pak файлы
    if (entry->type == ENTRY_DIR || entry->type == ENTRY_PAK) {
        return 0;
    }
    
    // Нельзя удалять системные папки и виртуальные
    if (exactMatch(entry->path, FAUX_RECENT_PATH) ||
        exactMatch(entry->path, FAUX_FAVORITE_PATH) ||
        exactMatch(entry->path, SDCARD_PATH "/Tools/" PLATFORM) ||
        exactMatch(entry->path, SCREENSHOTS_PATH) ||
        exactMatch(entry->path, COLLECTIONS_PATH)) {
        return 0;
    }
    
    // Проверяем, что файл существует (только для обычных файлов)
    return exists(entry->path);
}

// Функция удаления файла
static void deleteSelectedEntry(void) {
    if (!top || !top->entries || top->selected < 0 || 
        top->selected >= top->entries->count) {
        return;
    }
    
    Entry* entry = top->entries->items[top->selected];
    
    // Дополнительная проверка на тип файла
    if (entry->type == ENTRY_DIR || entry->type == ENTRY_PAK) {
        PLAT_showPopup(language_get_string("DELETE_ERROR"));
        return;
    }
    
    // Получаем имя файла для сообщения
    char* filename = strrchr(entry->path, '/');
    if (filename) filename++;
    else filename = entry->path;
    
    // Удаляем файл
    if (remove(entry->path) == 0) {
        char success_msg[256];
        snprintf(success_msg, sizeof(success_msg), "%s\n%s", 
                language_get_string("DELETE_SUCCESS"), filename);
        PLAT_showPopup(success_msg);
        
        // Удаляем запись из списка
        Entry_free(entry);
        for (int i = top->selected; i < top->entries->count - 1; i++) {
            top->entries->items[i] = top->entries->items[i + 1];
        }
        top->entries->count--;
        
        // Обновляем индексы
        if (top->selected >= top->entries->count) {
            top->selected = top->entries->count - 1;
        }
        
        if (top->end > top->entries->count) {
            top->end = top->entries->count;
        }
        
        // Обновляем анимацию и изображение
        cancelAllAnimations();
        if (top->entries->count > 0) {
            Entry* new_selected = top->entries->items[top->selected];
            readyResume(new_selected);
            setPreviewImage(new_selected, 0);
        } else {
            // Папка пуста
            if (surface_png) {
                SDL_FreeSurface(surface_png);
                surface_png = NULL;
            }
            mem_index = -1;
        }
        
        dirty = 1;
    } else {
        PLAT_showPopup(language_get_string("DELETE_ERROR"));
    }
}

static void splitIntoTwoLines(char* text, int max_width, TTF_Font* font) {
    if (!text || max_width <= 0) {
        return;
    }
    
    int src_len = strlen(text);
    if (src_len == 0) {
        return;
    }
    
    // Убираем завершающий пробел (маскировку)
    if (text[src_len - 1] == ' ') {
        text[src_len - 1] = '\0';
        src_len--;
    }
    
    // Проверяем, помещается ли исходный текст в одну строку
    int text_width = 0;
    TTF_SizeUTF8(font, text, &text_width, NULL);
    
    if (text_width <= max_width) {
        // Восстанавливаем пробел в конце и возвращаем
        text[src_len] = ' ';
        text[src_len + 1] = '\0';
        return;
    }
    
    // Ищем точку разрыва - где текст перестает помещаться в max_width
    int split_pos = -1;
    char test_str[256] = {0};
    
    // Начинаем с начала и проверяем посимвольно, пока текст помещается
    for (int i = 1; i <= src_len; i++) {
        strncpy(test_str, text, i);
        test_str[i] = '\0';
        
        TTF_SizeUTF8(font, test_str, &text_width, NULL);
        
        if (text_width > max_width) {
            // Текст перестал помещаться - ищем пробел для разрыва строки
            // Ищем пробел слева от этой позиции (чтобы разорвать по слову)
            for (int j = i - 1; j >= 0; j--) {
                if (text[j] == ' ') {
                    split_pos = j;
                    break;
                }
            }
            
            // Если не нашли пробел, ищем справа
            if (split_pos == -1) {
                for (int j = i; j < src_len; j++) {
                    if (text[j] == ' ') {
                        split_pos = j;
                        break;
                    }
                }
            }
            
            // Если пробел вообще не нашел (одно длинное слово), делим по позиции i-1
            if (split_pos == -1) {
                // Найдем оптимальное место для разрыва длинного слова
                // Разобьем примерно на середине, но с учетом max_width
                split_pos = i - 1;
                
                // Если разделение почти в самом конце, лучше разделить ближе к середине слова
                if (split_pos > src_len - 3) {
                    split_pos = src_len / 2;
                }
                
                // Проверим, что не делим слишком близко к началу
                if (split_pos < 2) {
                    split_pos = src_len / 2;
                }
            }
            break;
        }
    }
    
    // Если не нашли точку разрыва (странный случай), делим пополам
    if (split_pos == -1) {
        split_pos = src_len / 2;
    }
    
    // Проверяем, что split_pos в допустимых пределах
    if (split_pos <= 0) {
        split_pos = 1;
    }
    if (split_pos >= src_len) {
        split_pos = src_len - 1;
    }
    
    // Создаем две строки для проверки
    char first_line[256];
    char second_line[256];
    
    strncpy(first_line, text, split_pos);
    first_line[split_pos] = '\0';
    
    // Копируем вторую часть
    // Если разрываем по пробелу, пропускаем его
    if (split_pos < src_len && text[split_pos] == ' ') {
        strcpy(second_line, &text[split_pos + 1]);
    } else {
        strcpy(second_line, &text[split_pos]);
    }
    
    // Проверяем ширину получившихся строк
    int first_width = 0, second_width = 0;
    TTF_SizeUTF8(font, first_line, &first_width, NULL);
    TTF_SizeUTF8(font, second_line, &second_width, NULL);
    
    // Если обе строки влазят, формируем результат
    if (first_width <= max_width && second_width <= max_width) {
        if (split_pos < src_len && text[split_pos] == ' ') {
            text[split_pos] = '\n';
        } else {
            // Вставляем \n в найденную позицию (разрыв длинного слова)
            if (split_pos < src_len) {
                memmove(&text[split_pos + 1], &text[split_pos], src_len - split_pos + 1);
                text[split_pos] = '\n';
            }
        }
    } else {
        // Если не влазят, ищем лучшую позицию для разрыва
        int best_split = -1;
        int best_score = 1000000000;  // Большое число вместо INT_MAX
        
        // Попробуем найти лучшую позицию для разрыва
        for (int try_pos = 1; try_pos < src_len; try_pos++) {
            // Создаем первую строку
            strncpy(first_line, text, try_pos);
            first_line[try_pos] = '\0';
            
            // Создаем вторую строку
            if (try_pos < src_len && text[try_pos] == ' ') {
                strcpy(second_line, &text[try_pos + 1]);
            } else {
                strcpy(second_line, &text[try_pos]);
            }
            
            // Проверяем ширину
            TTF_SizeUTF8(font, first_line, &first_width, NULL);
            TTF_SizeUTF8(font, second_line, &second_width, NULL);
            
            // Вычисляем "штраф" - насколько строки выходят за пределы
            int score = 0;
            if (first_width > max_width) score += (first_width - max_width) * 2;  // Больший штраф за первую строку
            if (second_width > max_width) score += (second_width - max_width);
            
            // Предпочитаем разрывы по пробелам
            if (try_pos < src_len && text[try_pos] == ' ') {
                score -= 50;  // Бонус за разрыв по пробелу
            }
            
            if (score < best_score) {
                best_score = score;
                best_split = try_pos;
            }
        }
        
        if (best_split > 0 && best_split < src_len) {
            // Используем лучшую найденную позицию
            if (best_split < src_len && text[best_split] == ' ') {
                text[best_split] = '\n';
            } else {
                memmove(&text[best_split + 1], &text[best_split], src_len - best_split + 1);
                text[best_split] = '\n';
            }
        } else {
            // Не нашли подходящую позицию - обрезаем с троеточием
            for (int len = src_len; len > 3; len--) {
                strncpy(first_line, text, len - 3);
                first_line[len - 3] = '\0';
                strcat(first_line, "...");
                
                TTF_SizeUTF8(font, first_line, &first_width, NULL);
                if (first_width <= max_width || len <= 4) {
                    strcpy(text, first_line);
                    break;
                }
            }
        }
    }
    
    // Восстанавливаем завершающий пробел
    int final_len = strlen(text);
    text[final_len] = ' ';
    text[final_len + 1] = '\0';
}

static void cancelAllAnimations(void) {
    // Немедленно завершаем все анимации
    list_anim.anim_frame = 0;
    list_anim.list_anim_frame = 0;
    list_anim.bg_anim_frame = 0;
    need_final_redraw = 0;
    
    // Освобождаем старое изображение если есть
    if (prev_surface_png) {
        SDL_FreeSurface(prev_surface_png);
        prev_surface_png = NULL;
    }
    
    // ВАЖНО: очищаем путь к сохранению при отмене анимаций
    bmp_slot_path[0] = '\0';
}

int strcasestr_i(const char* str, const char* pattern) {
    size_t i, j = 0;
    unsigned char c0 = *pattern, c1, c2;
    
    if (c0 == '\0')
        return -1;
    
    c0 = toupper(c0);
    for (; (c1 = *str) != '\0'; str++) {
        if (toupper(c1) == c0) {
            for (i = 1;; i++) {
                c2 = pattern[i];
                if (c2 != '\0')
                    return j;
                c1 = str[i];
                if (toupper(c1) != toupper(c2))
                    break;
            }
        }
        j++;
    }
    return -1;
}


int main(int argc, char* argv[]) {
    if (autoResume()) return 0;
    
    simple_mode = exists(SIMPLE_MODE_PATH);
    
    LOG_info("MinUI\n");
    InitSettings();
    
    screen = GFX_init(MODE_MAIN);
    SDL_Surface* background = NULL;
    PAD_init();
    PWR_init();
    if (!HAS_POWER_BUTTON && !simple_mode) PWR_disableSleep();
    
    SDL_Surface* version = NULL;
    
    loadSettingsFromIni();
    
    Menu_init();
    
    PWR_setCPUSpeed(CPU_SPEED_MENU);
    GFX_setVsync(VSYNC_STRICT);
    
    PAD_reset();
    
    next_folder = 1;
    int anim_frame = 0;
    int anim_direction = 1;
    int old_im = 0;
    int show_version = 0;
    int show_setting = 0;
    int was_online = PLAT_isOnline();
    mem_index = -1;
    char file_name[256];
    char file_path[256];
    char png_path[512];
    char background_path[512];
    char theme_png_path[512];
    
    dirty = 1;
    if (top && top->entries && top->entries->count > 0) {
        Entry* entry = top->entries->items[top->selected];
        readyResume(entry);  // Инициализировать bmp_slot_path
        setPreviewImage(entry, 0);
        }
    
    // Инициализация анимации списка
    initListAnimation(&list_anim);
    
    snprintf(background_path, sizeof background_path, "/sdcard/Themes/%s/background.png", select_themes);
    if (exists(background_path)) {
        background = convertAlphaToColorKey(IMG_Load(background_path));
        }
    
    while (!quit) {
        GFX_startFrame();
        unsigned long now = SDL_GetTicks();
                // Используем существующие переменные из структуры list_anim
        int bg_old_selected = list_anim.bg_old_selected;
        int bg_new_selected = list_anim.bg_new_selected;
        int bg_anim_frame = list_anim.bg_anim_frame;
        float bg_anim_progress = 0.0f;
        
        // ВЫЧИСЛЯЕМ ПРАВИЛЬНЫЙ ПРОГРЕСС
        if (bg_anim_frame == 0) {
            bg_anim_progress = 1.0f;
        } else if (need_final_redraw) {
            // При финальной перерисовке гарантируем прогресс = 1.0
            bg_anim_progress = 1.0f;
        } else {
            // Вычисляем прогресс на основе текущего кадра и скорости анимации
            bg_anim_progress = 1.0f - ((float)bg_anim_frame / (animation_speed * 2));
        }
        PAD_poll();
        
        int selected = top->selected;
        int total = top->entries->count;
        
        PWR_update(&dirty, &show_setting, NULL, NULL);
        
        int is_online = PLAT_isOnline();
        if (was_online != is_online) dirty = 1;
        was_online = is_online;
        
        if (show_version) {
            if (PAD_justPressed(getButtonB()) || PAD_tappedMenu(now)) {
                show_version = 0;
                dirty = 1;
                mem_index = -1;
                if (!HAS_POWER_BUTTON && !simple_mode) PWR_disableSleep();
            }
        } else {
            if (PAD_tappedMenu(now)) {
                        // Создаем массив пунктов меню
                        char* menu_items[5];
                        
                        // Определяем текст для пункта "Избранное"
                        char favorite_text_buffer[256];
                        if (top && top->entries && top->entries->count > 0 && top->selected >= 0 && 
                                top->selected < top->entries->count) {
                                Entry* entry = top->entries->items[top->selected];
                                if (entry->type == ENTRY_ROM && isFavorite(entry->path)) {
                                strcpy(favorite_text_buffer, language_get_string("REMOVE_FROM_FAVORITES"));
                                } else {
                                strcpy(favorite_text_buffer, language_get_string("ADD_TO_FAVORITES"));
                                }
                        } else {
                                strcpy(favorite_text_buffer, language_get_string("ADD_TO_FAVORITES"));
                        }
                        
                        // Определяем, это ром или нет
                        int is_rom_selected = 0;
                        if (top && top->entries && top->entries->count > 0 && 
                                top->selected >= 0 && top->selected < top->entries->count) {
                                Entry* entry = top->entries->items[top->selected];
                                is_rom_selected = (entry->type == ENTRY_ROM);
                        }
                        
                        // Заполняем массив пунктов меню динамически
                        int menu_item_count = 5;
                        menu_items[0] = language_get_string("MINUI_INFORMATION");
                        
                        // Если выбран ром - показываем "Сбросить настройки", иначе - "Настройки"
                        if (is_rom_selected) {
                                menu_items[1] = language_get_string("RESET_SETTINGS");
                        } else {
                                menu_items[1] = language_get_string("SETTINGS");
                        }
                        
                        menu_items[2] = favorite_text_buffer; // Динамический текст
                        menu_items[3] = language_get_string("DELETE");
                        menu_items[4] = language_get_string("CLOSE");
                        
                        int menu_result = showGenericMenuDialog(menu_items, menu_item_count, 0xDEDA, 0x0000, screen);
                        
                        // Обработка выбранного пункта меню
                        switch (menu_result) {
                                case 0: // Информация
                                show_version = 1;
                                dirty = 1;
                                if (!HAS_POWER_BUTTON && !simple_mode) PWR_enableSleep();
                                break;
                                
                                case 1: // Сбросить настройки ИЛИ Настройки (зависит от контекста)
                                if (is_rom_selected) {
                                        // Подменю сброса настроек для рома
                                        char* reset_items[] = {
                                        language_get_string("RESET_CORE"),
                                        language_get_string("RESET_GAME"),
                                        language_get_string("CANCEL")
                                        };
                                        
                                        int reset_result = showGenericMenuDialog(reset_items, 3, 0xDEDA, 0x0000, screen);
                                        
                                        switch (reset_result) {
                                        case 0: // Сбросить настройки ядра
                                                if (top && top->entries && top->entries->count > 0 && 
                                                top->selected >= 0 && top->selected < top->entries->count) {
                                                Entry* entry = top->entries->items[top->selected];
                                                resetCoreSettings(entry);
                                                }
                                                break;
                                                
                                        case 1: // Сбросить настройки игры
                                                if (top && top->entries && top->entries->count > 0 && 
                                                top->selected >= 0 && top->selected < top->entries->count) {
                                                Entry* entry = top->entries->items[top->selected];
                                                resetGameSettings(entry);
                                                }
                                                break;
                                                
                                        case 2: // Отмена
                                        case -1:
                                                // Ничего не делаем, просто закрываем подменю
                                                break;
                                        }
                                } else {
                                        // Запуск программы настроек для не-ROM элементов
                                        char settings_path[256];
                                        snprintf(settings_path, sizeof(settings_path), 
                                                "/sdcard/Tools/%s/Settings.pak/launch.sh", PLATFORM);
                                        
                                        if (exists(settings_path)) {
                                        char cmd[256];
                                        sprintf(cmd, "'%s'", escapeSingleQuotes(settings_path));
                                        queueNext(cmd);
                                        } else {
                                        // Пробуем альтернативный путь
                                        snprintf(settings_path, sizeof(settings_path), 
                                                "%s/Tools/%s/Settings.pak/launch.sh", SDCARD_PATH, PLATFORM);
                                        
                                        if (exists(settings_path)) {
                                                char cmd[256];
                                                sprintf(cmd, "'%s'", escapeSingleQuotes(settings_path));
                                                queueNext(cmd);
                                        } else {
                                                PLAT_showPopup(language_get_string("SETTINGS_NOT_FOUND"));
                                        }
                                        }
                                }
                                break;
                                
                                case 2: // Добавить/убрать из избранного
                                if (top && top->entries && top->entries->count > 0 && 
                                        top->selected >= 0 && top->selected < top->entries->count) {
                                        Entry* entry = top->entries->items[top->selected];
                                        if (entry->type == ENTRY_ROM) {
                                        toggleFavorite(entry->path);
                                        dirty = 1;
                                        PLAT_showPopup(isFavorite(entry->path) ? 
                                                        language_get_string("ADDED_TO_FAVORITES") : 
                                                        language_get_string("REMOVED_FROM_FAVORITES"));
                                        }
                                }
                                break;
                                
                                case 3: // Удалить
                                if (canDeleteSelectedEntry()) {
                                        Entry* entry = top->entries->items[top->selected];
                                        char* filename = strrchr(entry->path, '/');
                                        if (filename) filename++;
                                        else filename = entry->path;
                                        
                                        // Получаем размер файла
                                        struct stat file_stat;
                                        char file_size_str[32] = "";
                                        if (stat(entry->path, &file_stat) == 0) {
                                        off_t file_size = file_stat.st_size;
                                        
                                        // Форматируем размер файла в читаемом виде
                                        if (file_size < 1024) {
                                                snprintf(file_size_str, sizeof(file_size_str), " (%lld B)", (long long)file_size);
                                        } else if (file_size < 1024 * 1024) {
                                                snprintf(file_size_str, sizeof(file_size_str), " (%.1f KB)", file_size / 1024.0);
                                        } else if (file_size < 1024 * 1024 * 1024) {
                                                snprintf(file_size_str, sizeof(file_size_str), " (%.1f MB)", file_size / (1024.0 * 1024.0));
                                        } else {
                                                snprintf(file_size_str, sizeof(file_size_str), " (%.1f GB)", file_size / (1024.0 * 1024.0 * 1024.0));
                                        }
                                        }
                                        
                                        // Создаем заголовок для диалога
                                        char dialog_title[512];
                                        snprintf(dialog_title, sizeof(dialog_title), "%s%s?\n", 
                                                language_get_string("DELETE"), file_size_str);
                                        
                                        // Добавляем имя файла
                                        int title_len = strlen(dialog_title);
                                        char* filename_part = dialog_title + title_len;
                                        snprintf(filename_part, sizeof(dialog_title) - title_len, "%s ", filename);
                                        
                                        // Разделяем имя файла на две строки если нужно
                                        splitIntoTwoLines(filename_part, 210, font.large);
                                        
                                        // Убираем завершающий пробел
                                        int total_len = strlen(dialog_title);
                                        if (total_len > 0 && dialog_title[total_len - 1] == ' ') {
                                        dialog_title[total_len - 1] = '\0';
                                        }
                                        
                                        // Создаем пункты меню для подтверждения
                                        char* confirm_items[] = {
                                        language_get_string("OK"),
                                        language_get_string("CANCEL")
                                        };
                                        
                                        // Используем новую функцию с заголовком
                                        int confirm_result = showGenericMenuDialogWithTitle(confirm_items, 2, 0xDEDA, 0x0000, screen, dialog_title);
                                        
                                        if (confirm_result == 0) {
                                        deleteSelectedEntry();
                                        }
                                } else {
                                        PLAT_showPopup(language_get_string("ERROR_DELETING_FILE"));
                                }
                                break;
                                
                                case 4: // Закрыть
                                // Просто закрываем меню, ничего не делаем
                                break;
                                
                                default: // -1 или другие значения
                                // Просто закрываем меню
                                break;
                        }
                        
                        dirty = 1;
                        
                        // ВАЖНО: Сбрасываем состояние кнопок после закрытия меню
                        PAD_poll();
                        PAD_reset(); // Сброс состояния кнопок
                        SDL_Delay(100); // Короткая задержка
                        PAD_poll(); // Еще раз обновим состояние
                        } else if (total > 0) {
                // ИСПОЛЬЗОВАНИЕ НОВОЙ ФУНКЦИИ: Обработка навигации
                // Циклическая навигация — только при одиночном нажатии
                                if (PAD_justPressed(BTN_UP)) {
                                if (selected == 0) {
                                        // Переход на последний элемент
                                        int old_selected = top->selected;
                                        selected = total - 1;
                                        if (total > MAIN_ROW_COUNT) {
                                        top->start = selected - MAIN_ROW_COUNT + 1;
                                        top->end = selected + 1;
                                        }
                                        top->selected = selected;
                                        cancelAllAnimations();
                                        carousel_pos = (float)selected; // мгновенный snap при переходе 0→last
                                        scrollbar_anim_y = -1.0f; // snap скроллбара
                                        scrollbar_drop_from = -1.0f;
                                        scrollbar_prev_target = -1.0f;
                                        setPreviewImage(top->entries->items[selected], 0); // без анимации
                                        dirty = 1;
                                } else {
                                        // Обычный переход вверх — как раньше
                                        int old_selected = top->selected;
                                        handleListNavigation(&selected, total, &top->start, &top->end, 1, 0, MAIN_ROW_COUNT);
                                        if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                        } else {
                                        cancelAllAnimations();
                                        top->selected = selected;
                                        setPreviewImage(top->entries->items[selected], 1);
                                        dirty = 1;
                                        if (animation) {
                                                startListAnimation(&list_anim, old_selected, selected, animation_speed, 1);
                                                startAnimation(&list_anim, animation_speed * 2, 1);
                                        }
                                        }
                                }
                                } else if (PAD_justRepeated(BTN_UP) && selected > 0) {
                                // Продолжение удержания — только если не вверху
                                int old_selected = top->selected;
                                handleListNavigation(&selected, total, &top->start, &top->end, 1, 0, MAIN_ROW_COUNT);
                                if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                } else {
                                        cancelAllAnimations();
                                        top->selected = selected;
                                        setPreviewImage(top->entries->items[selected], 1);
                                        dirty = 1;
                                        if (animation) {
                                        startListAnimation(&list_anim, old_selected, selected, animation_speed, 1);
                                        startAnimation(&list_anim, animation_speed * 2, 1);
                                        }
                                }
                                } else if (PAD_justPressed(BTN_DOWN)) {
                                if (selected == total - 1) {
                                        // Переход на первый элемент
                                        int old_selected = top->selected;
                                        selected = 0;
                                        top->start = 0;
                                        top->end = (total < MAIN_ROW_COUNT) ? total : MAIN_ROW_COUNT;
                                        top->selected = selected;
                                        cancelAllAnimations();
                                        carousel_pos = (float)selected; // мгновенный snap при переходе last→0
                                        scrollbar_anim_y = -1.0f; // snap скроллбара
                                        scrollbar_drop_from = -1.0f;
                                        scrollbar_prev_target = -1.0f;
                                        setPreviewImage(top->entries->items[selected], 0); // без анимации
                                        dirty = 1;
                                } else {
                                        // Обычный переход вниз
                                        if (list_anim.list_anim_frame > 0 || list_anim.anim_frame > 0) {
                                        list_anim.list_anim_frame = 2;
                                        list_anim.anim_frame = 2;
                                        }
                                        int old_selected = top->selected;
                                        handleListNavigation(&selected, total, &top->start, &top->end, -1, 0, MAIN_ROW_COUNT);
                                        if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                        } else {
                                        cancelAllAnimations();
                                        top->selected = selected;
                                        setPreviewImage(top->entries->items[selected], -1);
                                        dirty = 1;
                                        if (animation) {
                                                startListAnimation(&list_anim, old_selected, selected, animation_speed, -1);
                                                startAnimation(&list_anim, animation_speed * 2, -1);
                                        }
                                        }
                                }
                                } else if (PAD_justRepeated(BTN_DOWN) && selected < total - 1) {
                                // Продолжение удержания — только если не внизу
                                if (list_anim.list_anim_frame > 0 || list_anim.anim_frame > 0) {
                                        list_anim.list_anim_frame = 2;
                                        list_anim.anim_frame = 2;
                                }
                                int old_selected = top->selected;
                                handleListNavigation(&selected, total, &top->start, &top->end, -1, 0, MAIN_ROW_COUNT);
                                if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                } else {
                                        cancelAllAnimations();
                                        top->selected = selected;
                                        setPreviewImage(top->entries->items[selected], -1);
                                        dirty = 1;
                                        if (animation) {
                                        startListAnimation(&list_anim, old_selected, selected, animation_speed, -1);
                                        startAnimation(&list_anim, animation_speed * 2, -1);
                                        }
                                }
                                }
                if (PAD_justRepeated(BTN_LEFT)) {
                                if (selected == 0) {
                                        // nothing
                                } else {
                                        int old_selected = top->selected;
                                        handleListNavigation(&selected, total, &top->start, &top->end, 1, 1, MAIN_ROW_COUNT);
                                        if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                        continue;
                                        }
                                        top->selected = selected;
                                        
                                        // ОТМЕНА АНИМАЦИЙ ПЕРЕД БЫСТРЫМ ПЕРЕХОДОМ
                                        cancelAllAnimations();
                                        setPreviewImage(top->entries->items[selected], 0); // 0 = без анимации
                                        dirty = 1;
                                        
                                        // Без анимации списка для быстрых переходов
                                        // startListAnimation(&list_anim, old_selected, selected, animation_speed * 2, 1); // ЗАКОММЕНТИРОВАТЬ
                                }
                                } else if (PAD_justRepeated(BTN_RIGHT)) {
                                if (selected == total - 1) {
                                        // nothing
                                } else {
                                        int old_selected = top->selected;
                                        handleListNavigation(&selected, total, &top->start, &top->end, -1, 1, MAIN_ROW_COUNT);
                                        if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                        continue;
                                        }
                                        top->selected = selected;
                                        
                                        // ОТМЕНА АНИМАЦИЙ ПЕРЕД БЫСТРЫМ ПЕРЕХОДОМ
                                        cancelAllAnimations();
                                        setPreviewImage(top->entries->items[selected], 0); // 0 = без анимации
                                        dirty = 1;
                                        
                                        // Без анимации списка для быстрых переходов
                                        // startListAnimation(&list_anim, old_selected, selected, animation_speed * 2, -1); // ЗАКОММЕНТИРОВАТЬ
                                }
                                }
                                        
                if (PAD_justRepeated(BTN_L1) && !PAD_isPressed(BTN_R1) && !PWR_ignoreSettingInput(BTN_L1, show_setting)) {
                                Entry* entry = top->entries->items[selected];
                                int i = entry->alpha - 1;
                                if (i >= 0) {
                                        int old_selected = top->selected;
                                        selected = top->alphas->items[i];
                                        if (total > MAIN_ROW_COUNT) {
                                        top->start = selected;
                                        top->end = top->start + MAIN_ROW_COUNT;
                                        if (top->end > total) top->end = total;
                                        top->start = top->end - MAIN_ROW_COUNT;
                                        }
                                        if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                        continue;
                                        }
                                        top->selected = selected;
                                        
                                        // ОТМЕНА АНИМАЦИЙ ПЕРЕД БЫСТРЫМ ПЕРЕХОДОМ
                                        cancelAllAnimations();
                                        setPreviewImage(top->entries->items[selected], 0); // 0 = без анимации
                                        dirty = 1;
                                        
                                        // Без анимации списка для быстрых переходов
                                        // startListAnimation(&list_anim, old_selected, selected, animation_speed * 2, 1); // ЗАКОММЕНТИРОВАТЬ
                                }
                                } else if (PAD_justRepeated(BTN_R1) && !PAD_isPressed(BTN_L1) && !PWR_ignoreSettingInput(BTN_R1, show_setting)) {
                                Entry* entry = top->entries->items[selected];
                                int i = entry->alpha + 1;
                                if (i < top->alphas->count) {
                                        int old_selected = top->selected;
                                        selected = top->alphas->items[i];
                                        if (total > MAIN_ROW_COUNT) {
                                        top->start = selected;
                                        top->end = top->start + MAIN_ROW_COUNT;
                                        if (top->end > total) top->end = total;
                                        top->start = top->end - MAIN_ROW_COUNT;
                                        }
                                        top->selected = selected;
                                        if (selected < 0 || selected >= total) {
                                        selected = old_selected;
                                        continue;
                                        }
                                        
                                        // ОТМЕНА АНИМАЦИЙ ПЕРЕД БЫСТРЫМ ПЕРЕХОДОМ
                                        cancelAllAnimations();
                                        setPreviewImage(top->entries->items[selected], 0); // 0 = без анимации
                                        dirty = 1;
                                        
                                        // Без анимации списка для быстрых переходов
                                        // startListAnimation(&list_anim, old_selected, selected, animation_speed * 2, -1); // ЗАКОММЕНТИРОВАТЬ
                                }
                                }
                        }
            
            if (selected != top->selected) {
                top->selected = selected;
                dirty = 1;
            }
            
            if (dirty && total > 0) readyResume(top->entries->items[top->selected]);
            
            if (total > 0 && can_resume && PAD_justReleased(BTN_RESUME)) {
                should_resume = 1;
                Entry_open(top->entries->items[top->selected]);
                dirty = 1;
            } else if (total > 0 && (isPSP != 0) && PAD_justReleased(BTN_RESUME)) {
                isPSP = 2;
                Entry_open(top->entries->items[top->selected]);
                dirty = 1;
            } else if (total > 0 && PAD_justPressed(getButtonA())) {
                        isFind = 0;
                        Entry* selected_entry = top->entries->items[top->selected];
                        
                        // УПРОЩЁННАЯ ЛОГИКА:
                        // ТОЛЬКО ENTRY_IMAGE из папки скриншотов открываем в просмотрщике
                        if (selected_entry->type == ENTRY_IMAGE && 
                                prefixMatch(SCREENSHOTS_PATH, selected_entry->path)) {
                                // Только скриншоты - в просмотрщик
                                loadImagesForViewer(selected_entry->path);
                                viewer_mode = 1;
                                viewer_load_image();
                                dirty = 1;
                                while(!drawViewer()){};
                        } else {
                                // ВСЁ остальное - старая логика
                                Entry_open(selected_entry);
                                selected = top->selected;
                                total = top->entries->count;
                                anim_frame = 0;
                                list_anim.list_anim_frame = 0;
                                list_anim.bg_anim_frame = 0;
                                mem_index = -1;
                                next_folder = 1;
                                dirty = 1;
                                
                                if (total > 0) readyResume(top->entries->items[top->selected]);
                        }
                        } else if (PAD_justPressed(BTN_Y)) {
                if (drawKeyboard(screen, find_string, 1, 133, 63) > 0) {
                    isFind = 1;
                    Entry* entry = top->entries->items[top->selected];
                    if (entry->type == ENTRY_DIR)
                        Entry_open(top->entries->items[top->selected]);
                    else {
                        closeDirectory();
                        Entry_open(top->entries->items[top->selected]);
                    }
                    selected = top->selected;
                    total = top->entries->count;
                    anim_frame = 0;
                    list_anim.list_anim_frame = 0;
                    list_anim.bg_anim_frame = 0;
                    bg_anim_frame = 0;
                    mem_index = -1;
                    next_folder = 1;
                    
                    if (total > 0) readyResume(top->entries->items[top->selected]);
                }
                selected = 0;
                dirty = 1;
            } else if (PAD_justPressed(getButtonB()) && stack->count > 1) {
                isFind = 0;
                closeDirectory();
                selected = top->selected;
                total = top->entries->count;
                anim_frame = 0;
                list_anim.list_anim_frame = 0;
                list_anim.bg_anim_frame = 0;
                bg_anim_frame = 0;
                mem_index = -1;
                next_folder = 1;
                dirty = 1;
                if (exactMatch(top->path, SDCARD_PATH))
                    root_directory = 1;
                if (total > 0) readyResume(top->entries->items[top->selected]);
            } else if (total > 0 && PAD_justPressed(BTN_X)) {
                Entry* entry = top->entries->items[top->selected];
                if (entry->type == ENTRY_ROM) {
                    toggleFavorite(entry->path);
                    dirty = 1;
                }
                        } else if (total > 0 && PAD_justPressed(BTN_L2)) {
                        if (canDeleteSelectedEntry()) {
                                Entry* entry = top->entries->items[top->selected];
                                if (!entry) {
                                dirty = 1;
                                continue;
                                }
                                
                                char* filename = strrchr(entry->path, '/');
                                if (filename) filename++;
                                else filename = entry->path;
                                
                                // Получаем размер файла
                                struct stat file_stat;
                                char file_size_str[32] = "";
                                if (stat(entry->path, &file_stat) == 0) {
                                off_t file_size = file_stat.st_size;
                                
                                // Форматируем размер файла в читаемом виде
                                if (file_size < 1024) {
                                        snprintf(file_size_str, sizeof(file_size_str), " (%lld B)", (long long)file_size);
                                } else if (file_size < 1024 * 1024) {
                                        snprintf(file_size_str, sizeof(file_size_str), " (%.1f KB)", file_size / 1024.0);
                                } else if (file_size < 1024 * 1024 * 1024) {
                                        snprintf(file_size_str, sizeof(file_size_str), " (%.1f MB)", file_size / (1024.0 * 1024.0));
                                } else {
                                        snprintf(file_size_str, sizeof(file_size_str), " (%.1f GB)", file_size / (1024.0 * 1024.0 * 1024.0));
                                }
                                }
                                
                                // Создаем заголовок для диалога
                                char dialog_title[512];
                                snprintf(dialog_title, sizeof(dialog_title), "%s%s?\n", 
                                        language_get_string("DELETE"), file_size_str);
                                
                                // Добавляем имя файла
                                int title_len = strlen(dialog_title);
                                char* filename_part = dialog_title + title_len;
                                snprintf(filename_part, sizeof(dialog_title) - title_len, "%s ", filename);
                                
                                // Разделяем имя файла на две строки если нужно
                                splitIntoTwoLines(filename_part, 210, font.large);
                                
                                // Убираем завершающий пробел
                                int total_len = strlen(dialog_title);
                                if (total_len > 0 && dialog_title[total_len - 1] == ' ') {
                                dialog_title[total_len - 1] = '\0';
                                }
                                
                                // Создаем пункты меню для подтверждения
                                char* confirm_items[] = {
                                language_get_string("OK"),
                                language_get_string("CANCEL")
                                };
                                
                                // Используем новую функцию с заголовком
                                int confirm_result = showGenericMenuDialogWithTitle(confirm_items, 2, 0xDEDA, 0x0000, screen, dialog_title);
                                
                                if (confirm_result == 0) {
                                // Удаляем файл
                                if (remove(entry->path) == 0) {
                                        char success_msg[256];
                                        snprintf(success_msg, sizeof(success_msg), "%s\n%s", 
                                                language_get_string("DELETE_SUCCESS"), filename);
                                        PLAT_showPopup(success_msg);
                                        
                                        // Удаляем запись из списка
                                        Entry_free(entry);
                                        for (int i = top->selected; i < top->entries->count - 1; i++) {
                                        top->entries->items[i] = top->entries->items[i + 1];
                                        }
                                        top->entries->count--;
                                        
                                        // Обновляем индексы
                                        if (top->selected >= top->entries->count) {
                                        top->selected = top->entries->count - 1;
                                        }
                                        
                                        if (top->end > top->entries->count) {
                                        top->end = top->entries->count;
                                        }
                                        
                                        // Обновляем анимацию и изображение
                                        cancelAllAnimations();
                                        if (top->entries->count > 0) {
                                        Entry* new_selected = top->entries->items[top->selected];
                                        readyResume(new_selected);
                                        setPreviewImage(new_selected, 0);
                                        } else {
                                        // Папка пуста
                                        if (surface_png) {
                                                SDL_FreeSurface(surface_png);
                                                surface_png = NULL;
                                        }
                                        mem_index = -1;
                                        }
                                        
                                        dirty = 1;
                                        selected = top->selected;
                                        total = top->entries->count;
                                } else {
                                        PLAT_showPopup(language_get_string("ERROR_DELETING_FILE"));
                                }
                                }
                                
                                dirty = 1;
                                
                                // Обновляем состояние после выхода из диалога
                                if (top && top->entries && top->entries->count > 0 && 
                                top->selected >= 0 && top->selected < top->entries->count) {
                                readyResume(top->entries->items[top->selected]);
                                }
                        }
                        }
        }

                // Используем существующую функцию: Обновление анимации списка
                int animation_finished = updateAnimationProgress(&list_anim, animation_speed);
                
                // Если анимация только что завершилась, устанавливаем флаг для финальной перерисовки
                if (animation_finished) {
                need_final_redraw = 1;
                dirty = 1; // Принудительно устанавливаем dirty
                }
        
        if (anim_frame || list_anim.anim_frame || list_anim.list_anim_frame || bg_anim_frame || dirty || need_final_redraw || PLAT_isPopupActive()
            || (preview_transition == 4 && carousel_initialized && fabsf(carousel_pos - carousel_target) > 0.01f)
            || (scrollbar_drop_from >= 0.0f)) {
            // Для fade (type 2): сохраняем полный экран перед очисткой (снимок "старого" кадра)
            if (animation == 1 && list_anim.anim_frame > 0 && preview_transition == 2 && fade_snapshot == NULL) {
                fade_snapshot = SDL_ConvertSurface(screen, screen->format, 0);
            }
            
            GFX_clear(screen);
            
            SDL_FillRect(screen, &(SDL_Rect){0, 0, DEVICE_WIDTH, DEVICE_HEIGHT - 1},
                         SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
            if (background != NULL) {
                SDL_BlitSurface(background, &(SDL_Rect){0, 0, background->w, background->h}, screen,
                                &(SDL_Rect){0, 0, 272, 273});
            }
            
            int ox,oy,ow = 0;
            
            if (show_version) {
                if (exists(info_path)) {
                    SDL_Surface* surfaceInfo = SDL_CreateRGBSurface(0, 400, 196, 16, 0, 0, 0, 0);
                    SDL_Surface* surfaceMessage;
                    char info_txt[1024];
                    char string_text_buffer[256];
                    getFile(info_path, info_txt, 1024);
                    int i = 0, j = 0;
                    int charw;
                    int charh;
                    int y_pos = 0;
                    while (info_txt[i] && i < 1024) {
                        if ((info_txt[i] & 0xF0) == 0xF0) {
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j] = '\0';
                        } else if ((info_txt[i] & 0xE0) == 0xE0) {
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j++] = info_txt[i++]; 
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j] = '\0';
                        } else if ((info_txt[i] & 0xC0) == 0xC0) {
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j++] = info_txt[i++];
                            string_text_buffer[j] = '\0';
                        } else {
                            if (info_txt[i] >= 0x20)
                                string_text_buffer[j++] = info_txt[i];
                            string_text_buffer[j] = '\0';
                            i++;
                        } 
                        
                        TTF_SizeUTF8(font.small, string_text_buffer, &charw, &charh);
                        if (charw >= 390 || info_txt[i - 1] == '\n') {
                            j = 0;
                            surfaceMessage = TTF_RenderUTF8_Blended(font.small, string_text_buffer, COLOR_WHITE);
                            SDL_BlitSurface(surfaceMessage, NULL, surfaceInfo, &(SDL_Rect){0, y_pos * 14});
                            SDL_FreeSurface(surfaceMessage);
                            y_pos++;
                        }
                    }
                    surfaceMessage = TTF_RenderUTF8_Blended(font.small, string_text_buffer, COLOR_WHITE);
                    SDL_BlitSurface(surfaceMessage, NULL, surfaceInfo, &(SDL_Rect){0, y_pos * 14});
                    SDL_FreeSurface(surfaceMessage);
                    FillRoundRect(screen, (screen->w - surfaceInfo->w) / 2 - 4, (screen->h - surfaceInfo->h) / 2 - 4,
                                  surfaceInfo->w + 8, surfaceInfo->h + 8, 4, 0x0);
                    SDL_BlitSurface(surfaceInfo, NULL, screen,
                                    &(SDL_Rect){(screen->w - surfaceInfo->w) / 2, (screen->h - surfaceInfo->h) / 2});
                    SDL_FreeSurface(surfaceInfo);
                } else {
                    if (!version) {
                        char release[256];
                        getFile(ROOT_SYSTEM_PATH "/version.txt", release, 256);
                        
                        char *tmp, *commit;
                        commit = strrchr(release, '\n');
                        commit[0] = '\0';
                        commit = strrchr(release, '\n') + 1;
                        tmp = strchr(release, '\n');
                        tmp[0] = '\0';
                        
                        char* extra_key = language_get_string("MODEL");
                        char* extra_val = PLAT_getModel();
                        
                        SDL_Surface* release_txt =
                            TTF_RenderUTF8_Blended(font.large, language_get_string("RELEASE"), COLOR_DARK_TEXT);
                        SDL_Surface* version_txt = TTF_RenderUTF8_Blended(font.large, release, COLOR_WHITE);
                        SDL_Surface* commit_txt =
                            TTF_RenderUTF8_Blended(font.large, language_get_string("COMMIT"), COLOR_DARK_TEXT);
                        SDL_Surface* hash_txt = TTF_RenderUTF8_Blended(font.large, commit, COLOR_WHITE);
                        
                        SDL_Surface* key_txt = TTF_RenderUTF8_Blended(font.large, extra_key, COLOR_DARK_TEXT);
                        SDL_Surface* val_txt = TTF_RenderUTF8_Blended(font.large, extra_val, COLOR_WHITE);
                        
                        int l_width = 0;
                        int r_width = 0;
                        
                        if (release_txt->w > l_width) l_width = release_txt->w;
                        if (commit_txt->w > l_width) l_width = commit_txt->w;
                        if (key_txt->w > l_width) l_width = commit_txt->w;
                        
                        if (version_txt->w > r_width) r_width = version_txt->w;
                        if (hash_txt->w > r_width) r_width = hash_txt->w;
                        if (val_txt->w > r_width) r_width = val_txt->w;
                        
#define VERSION_LINE_HEIGHT 24
                        int x = l_width + SCALE1(8) + 16;
                        int w = x + r_width;
                        int h = SCALE1(VERSION_LINE_HEIGHT * 4);
                        version = SDL_CreateRGBSurface(0, w, h, 16, 0, 0, 0, 0);
                        
                        SDL_BlitSurface(release_txt, NULL, version, &(SDL_Rect){0, 0});
                        SDL_BlitSurface(version_txt, NULL, version, &(SDL_Rect){x, 0});
                        SDL_BlitSurface(commit_txt, NULL, version, &(SDL_Rect){0, SCALE1(VERSION_LINE_HEIGHT)});
                        SDL_BlitSurface(hash_txt, NULL, version, &(SDL_Rect){x, SCALE1(VERSION_LINE_HEIGHT)});
                        
                        SDL_BlitSurface(key_txt, NULL, version, &(SDL_Rect){0, SCALE1(VERSION_LINE_HEIGHT * 3)});
                        SDL_BlitSurface(val_txt, NULL, version, &(SDL_Rect){x, SCALE1(VERSION_LINE_HEIGHT * 3)});
                        
                        SDL_FreeSurface(release_txt);
                        SDL_FreeSurface(version_txt);
                        SDL_FreeSurface(commit_txt);
                        SDL_FreeSurface(hash_txt);
                        SDL_FreeSurface(key_txt);
                        SDL_FreeSurface(val_txt);
                    }
                    FillRoundRect(screen, (screen->w - version->w) / 2 - 4, (screen->h - version->h) / 2 - 4,
                                  version->w + 8, version->h + 8, 4, 0x0);
                    SDL_BlitSurface(version, NULL, screen,
                                    &(SDL_Rect){(screen->w - version->w) / 2, (screen->h - version->h) / 2});
                }
                ow = GFX_blitHardwareGroup(screen, show_setting);
                if (show_setting)
                    GFX_blitHardwareHints(screen, show_setting);
                else
                    GFX_blitButtonGroup((char*[]){BTN_SLEEP == BTN_POWER ? language_get_string("POWER")
                                                                         : language_get_string("MENU"),
                                                 language_get_string("SLEEP"), NULL},
                                        0, screen, 0);
                
                if (getSwapButtonAB() == 1)
                    GFX_blitButtonGroup((char*[]){"A", language_get_string("BACK"), NULL}, 0, screen, 1);
                else
                    GFX_blitButtonGroup((char*[]){"B", language_get_string("BACK"), NULL}, 0, screen, 1);
            } else {
                if (total > 0) {
                    // ОБНОВЛЕННЫЙ КОД ДЛЯ АНИМАЦИИ ИЗОБРАЖЕНИЙ С ПОДДЕРЖКОЙ НЕСКОЛЬКИХ ТИПОВ ПЕРЕХОДОВ:
                    // Обновляем анимацию изображений (используем переменную из структуры list_anim)
                    if (list_anim.anim_frame > 0) {
                        list_anim.anim_frame--;
                    }
                    
                    // Анимация скроллбара — плавное перемещение (lerp по пиксельной позиции)
                    {
                        float target_y;
                        if (total > 1) {
                            if (total < 34) {
                                // Маленький список: точки расположены вокруг центра (шаг 8px)
                                target_y = (float)(135 - ((total - 1) * 8) / 2 + selected * 8);
                            } else {
                                // Большой список: точка движется по линии 4..268
                                target_y = 4.0f + (264.0f * selected / (total - 1));
                            }
                        } else {
                            target_y = 135.0f;
                        }
                        if (scrollbar_anim_y < 0.0f) {
                            scrollbar_anim_y = target_y; // первый кадр — мгновенно
                            scrollbar_drop_from = -1.0f;
                            scrollbar_prev_target = target_y;
                        } else if (selected == 0 || selected == total - 1 ||
                                   fabsf(scrollbar_anim_y - target_y) > 30.0f) {
                            scrollbar_anim_y = target_y; // snap на границах и при прыжках
                            scrollbar_drop_from = -1.0f;
                            scrollbar_prev_target = target_y;
                        } else {
                            float diff = target_y - scrollbar_anim_y;
                            if (fabsf(diff) > 0.3f && fabsf(target_y - scrollbar_prev_target) > 0.5f) {
                                // Цель изменилась — запускаем анимацию капли от предыдущей дискретной позиции
                                scrollbar_drop_from = scrollbar_prev_target;
                            }
                            scrollbar_anim_y += diff * 0.35f;
                            if (fabsf(scrollbar_anim_y - target_y) < 0.5f) {
                                scrollbar_anim_y = target_y;
                                scrollbar_drop_from = -1.0f;
                                scrollbar_prev_target = target_y;
                            }
                        }
                    }

                    // === КАРУСЕЛЬ ВЕРТИКАЛЬНАЯ (type 4) ===
                    if (preview_transition == 4 && total > 0) {
                        carousel_target = (float)selected;
                        if (!carousel_initialized) {
                            carousel_pos = carousel_target;
                            carousel_initialized = 1;
                        } else {
                            // Мгновенный snap на границах и при быстром листании
                            if (selected == 0 || selected == total - 1 ||
                                fabsf(carousel_pos - carousel_target) > 1.5f) {
                                carousel_pos = carousel_target;
                            } else {
                                carousel_pos += (carousel_target - carousel_pos) * 0.25f;
                                if (fabsf(carousel_pos - carousel_target) < 0.01f)
                                    carousel_pos = carousel_target;
                            }
                        }

                        int preview_w = 272;
                        int preview_h = 272;
                        int max_img_w = 272;
                        int max_img_h = 200;
                        float step = 120.0f; // вертикальное расстояние между элементами

                        int vis_above = 3, vis_below = 3;
                        int center_idx = (int)roundf(carousel_pos);
                        if (center_idx - vis_above < 0) vis_above = center_idx;
                        if (center_idx + vis_below >= total) vis_below = total - 1 - center_idx;
                        if (vis_above < 0) vis_above = 0;
                        if (vis_below < 0) vis_below = 0;

                        // Область превью: правая половина экрана
                        int area_x = 480 - preview_w;

                        // Заливаем фон только если нет фонового изображения
                        if (background == NULL) {
                            SDL_FillRect(screen, &(SDL_Rect){area_x, 0, preview_w, preview_h},
                                         SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
                        }

                        // Рисуем все элементы (от дальних к ближним), включая центральный
                        for (int offset = -vis_above; offset <= vis_below; offset++) {
                            int idx = center_idx + offset;
                            if (idx < 0 || idx >= total) continue;

                            SDL_Surface* s = carousel_cache_get(idx);
                            if (!s) {
                                // Для текущего выбранного — берём surface_png чтобы не грузить с диска
                                SDL_Surface* raw = NULL;
                                if (idx == top->selected && surface_png != NULL && surface_png->w > 0 && surface_png->h > 0) {
                                    raw = surface_png;
                                } else {
                                    Entry* e = top->entries->items[idx];
                                    if (!e) continue;
                                    raw = loadImageWithPriority(e, select_themes, NULL);
                                }
                                if (!raw || raw->w <= 0 || raw->h <= 0) {
                                    if (raw && raw != surface_png) SDL_FreeSurface(raw);
                                    continue;
                                }
                                s = scaleToFit(raw, max_img_w, max_img_h);
                                if (raw != surface_png) SDL_FreeSurface(raw);
                                if (!s) continue;
                                carousel_cache_put(idx, s);
                            }
                            if (s->w <= 0 || s->h <= 0) continue;

                            float fi = (float)idx;
                            // Вертикальная позиция центра элемента
                            float cy = (float)preview_h / 2.0f + (fi - carousel_pos) * step;
                            float dist = fabsf(fi - carousel_pos);
                            float scale = 1.0f / (1.0f + dist * 0.5f);
                            if (scale < 0.2f) scale = 0.2f;

                            int sw = (int)((float)s->w * scale);
                            int sh = (int)((float)s->h * scale);
                            if (sw < 4) sw = 4;
                            if (sh < 4) sh = 4;

                            // Центрируем по горизонтали в области превью
                            int sx = area_x + (preview_w - sw) / 2;
                            int sy = (int)(cy - (float)sh / 2.0f);

                            // Быстрый blit: 1:1 или с масштабированием
                            if (sw == s->w && sh == s->h) {
                                blitDirect565(s, screen, sx, sy,
                                              area_x, 0, preview_w, preview_h);
                            } else {
                                blitScaled565(s, screen, sx, sy, sw, sh,
                                              area_x, 0, preview_w, preview_h);
                            }
                        }

                        dirty = 1; dirty = 0;
                        goto carousel_done;
                    }

                    if (animation == 1 && list_anim.anim_frame > 0) {
                        // ВЫЧИСЛЕНИЕ ПРОГРЕССА АНИМАЦИИ
                        float progress;
                        if (list_anim.anim_frame == 0) {
                            progress = 1.0f;
                        } else {
                            progress = 1.0f - ((float)list_anim.anim_frame / (animation_speed * 2));
                        }
                        
                        int direction = list_anim.anim_direction; // 1 = вверх, -1 = вниз
                        int preview_w = 272;
                        int preview_h = 272;
                        
                        switch (preview_transition) {
                            case 0: // SLIDE — вертикальный слайд (оригинальная анимация)
                            {
                                if (prev_surface_png != NULL && prev_surface_png->w > 0 && prev_surface_png->h > 0) {
                                    int prev_png_offset_x;
                                    if (prev_surface_png->w > preview_w)
                                        prev_png_offset_x = (480 - prev_surface_png->w) / 2;
                                    else
                                        prev_png_offset_x = 480 - preview_w + (preview_w - prev_surface_png->w) / 2;
                                    
                                    int prev_offset_y = 0;
                                    if (direction == 1)
                                        prev_offset_y = -preview_h * progress;
                                    else
                                        prev_offset_y = preview_h * progress;
                                    
                                    SDL_BlitSurface(prev_surface_png,
                                        &(SDL_Rect){0, 0, prev_surface_png->w, prev_surface_png->h}, screen,
                                        &(SDL_Rect){prev_png_offset_x, (preview_h - prev_surface_png->h) / 2 + prev_offset_y, preview_w, preview_h + 1});
                                }
                                
                                if (surface_png != NULL && surface_png->w > 0 && surface_png->h > 0) {
                                    int png_offset_x;
                                    if (surface_png->w > preview_w)
                                        png_offset_x = (480 - surface_png->w) / 2;
                                    else
                                        png_offset_x = 480 - preview_w + (preview_w - surface_png->w) / 2;
                                    
                                    int new_offset_y = 0;
                                    if (direction == 1)
                                        new_offset_y = preview_h * (1 - progress);
                                    else
                                        new_offset_y = -preview_h * (1 - progress);
                                    
                                    SDL_BlitSurface(surface_png, &(SDL_Rect){0, 0, surface_png->w, surface_png->h}, screen,
                                        &(SDL_Rect){png_offset_x, (preview_h - surface_png->h) / 2 + new_offset_y, preview_w, preview_h + 1});
                                }
                                break;
                            }
                            
                            case 1: // HORIZONTAL — горизонтальный слайд
                            {
                                if (prev_surface_png != NULL && prev_surface_png->w > 0 && prev_surface_png->h > 0) {
                                    int prev_offset_x;
                                    int base_x;
                                    if (prev_surface_png->w > preview_w)
                                        base_x = (480 - prev_surface_png->w) / 2;
                                    else
                                        base_x = 480 - preview_w + (preview_w - prev_surface_png->w) / 2;
                                    
                                    // Старое изображение уходит влево или вправо
                                    if (direction == 1)
                                        prev_offset_x = base_x - (int)(preview_w * progress);
                                    else
                                        prev_offset_x = base_x + (int)(preview_w * progress);
                                    
                                    SDL_BlitSurface(prev_surface_png,
                                        &(SDL_Rect){0, 0, prev_surface_png->w, prev_surface_png->h}, screen,
                                        &(SDL_Rect){prev_offset_x, (preview_h - prev_surface_png->h) / 2, preview_w, preview_h});
                                }
                                
                                if (surface_png != NULL && surface_png->w > 0 && surface_png->h > 0) {
                                    int new_offset_x;
                                    int base_x;
                                    if (surface_png->w > preview_w)
                                        base_x = (480 - surface_png->w) / 2;
                                    else
                                        base_x = 480 - preview_w + (preview_w - surface_png->w) / 2;
                                    
                                    // Новое изображение появляется справа или слева
                                    if (direction == 1)
                                        new_offset_x = base_x + (int)(preview_w * (1 - progress));
                                    else
                                        new_offset_x = base_x - (int)(preview_w * (1 - progress));
                                    
                                    SDL_BlitSurface(surface_png, &(SDL_Rect){0, 0, surface_png->w, surface_png->h}, screen,
                                        &(SDL_Rect){new_offset_x, (preview_h - surface_png->h) / 2, preview_w, preview_h});
                                }
                                break;
                            }
                            
                            case 2: // FADE — полный экран, dissolve через дизеринг (применяется после отрисовки всего кадра)
                            {
                                // Рисуем новое изображение как обычно (статично)
                                // Дизеринг будет применён к всему экрану после отрисовки всех элементов
                                if (surface_png != NULL && surface_png->w > 0 && surface_png->h > 0) {
                                    int png_offset_x;
                                    if (surface_png->w > 272)
                                        png_offset_x = (480 - surface_png->w) / 2;
                                    else
                                        png_offset_x = 480 - 272 + (272 - surface_png->w) / 2;
                                    
                                    SDL_BlitSurface(surface_png, &(SDL_Rect){0, 0, surface_png->w, surface_png->h}, screen,
                                        &(SDL_Rect){png_offset_x, (272 - surface_png->h) / 2, 272, 272});
                                }
                                dirty = 1; dirty = 0;
                                break;
                            }
                            
                            case 3: // ZOOM — старое статично как фон, новое масштабируется поверх
                            {
                                // ease-out для естественного замедления
                                float t = progress;
                                t = 1.0f - (1.0f - t) * (1.0f - t);
                                
                                // Старое изображение: рисуем статично на весь экран как фон
                                if (prev_surface_png != NULL && prev_surface_png->w > 0 && prev_surface_png->h > 0) {
                                    int prev_png_offset_x;
                                    if (prev_surface_png->w > preview_w)
                                        prev_png_offset_x = (480 - prev_surface_png->w) / 2;
                                    else
                                        prev_png_offset_x = 480 - preview_w + (preview_w - prev_surface_png->w) / 2;
                                    
                                    SDL_BlitSurface(prev_surface_png,
                                        &(SDL_Rect){0, 0, prev_surface_png->w, prev_surface_png->h}, screen,
                                        &(SDL_Rect){prev_png_offset_x, (preview_h - prev_surface_png->h) / 2, preview_w, preview_h});
                                }
                                
                                // Новое изображение: масштабируется из центра поверх старого
                                if (surface_png != NULL && surface_png->w > 0 && surface_png->h > 0 && t > 0.0f) {
                                    int new_disp_w = (surface_png->w > preview_w) ? 480 : preview_w;
                                    int new_disp_x = (surface_png->w > preview_w) ? 0 : 480 - preview_w;
                                    int new_center_x = new_disp_x + new_disp_w / 2;
                                    int new_center_y = preview_h / 2;
                                    
                                    float new_scale = t;
                                    int new_w = (int)(new_disp_w * new_scale);
                                    int new_h = (int)(preview_h * new_scale);
                                    
                                    if (new_w > 2 && new_h > 2) {
                                        int new_x = new_center_x - new_w / 2;
                                        int new_y = new_center_y - new_h / 2;
                                        
                                        // Заливаем область под новым изображением фоновым цветом
                                        SDL_FillRect(screen, &(SDL_Rect){new_x, new_y, new_w, new_h},
                                                     SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
                                        
                                        SDL_BlitSurface(surface_png,
                                            &(SDL_Rect){0, 0, surface_png->w, surface_png->h}, screen,
                                            &(SDL_Rect){new_x, new_y, new_w, new_h});
                                    }
                                }
                                break;
                            }
                            
                            default: // fallback — SLIDE
                            {
                                if (surface_png != NULL && surface_png->w > 0 && surface_png->h > 0) {
                                    int png_offset_x;
                                    if (surface_png->w > preview_w)
                                        png_offset_x = (480 - surface_png->w) / 2;
                                    else
                                        png_offset_x = 480 - preview_w + (preview_w - surface_png->w) / 2;
                                    
                                    SDL_BlitSurface(surface_png, &(SDL_Rect){0, 0, surface_png->w, surface_png->h}, screen,
                                        &(SDL_Rect){png_offset_x, (preview_h - surface_png->h) / 2, preview_w, preview_h});
                                }
                                break;
                            }
                        }
                        
                        dirty = 1;
                        dirty = 0;
                    } else if (surface_png != NULL && surface_png->w > 0 && surface_png->h > 0) {
                        // Статическое отображение, если анимация не идет
                        int png_offset_x;
                        if (surface_png->w > 272)
                            png_offset_x = (480 - surface_png->w) / 2;
                        else
                            png_offset_x = 480 - 272 + (272 - surface_png->w) / 2;
                        
                        SDL_BlitSurface(surface_png, &(SDL_Rect){0, 0, surface_png->w, surface_png->h}, screen,
                            &(SDL_Rect){png_offset_x, (272 - surface_png->h) / 2, 272, 272});
                        dirty = 1;
                        dirty = 0;
                    }
                    
                    carousel_done:;
                    
                    // === СКРОЛЛБАР С АНИМАЦИЕЙ КАПЛИ ===
                    if (scroll_bar_view == 1 || scroll_bar_view == 2) {
                        int bar_cx = (scroll_bar_view == 1) ? 4 : 476;
                        int head_r = 4;
                        Uint16 bar_color = SDL_MapRGB(screen->format, 0xff, 0xff, 0xff);
                        
                        // Пассивные точки / линия фона
                        if (total < 34) {
                            for (int k = 0; k < total; k++) {
                                int dot_cy = 135 - ((total - 1) * 8) / 2 + k * 8;
                                drawFilledCircle565(screen, bar_cx, dot_cy, 1, bar_color);
                            }
                        } else {
                            SDL_FillRect(screen, &(SDL_Rect){bar_cx - 1, 4, 3, 264}, bar_color);
                        }
                        
                        if (scrollbar_drop_from >= 0.0f) {
                            // Анимация капли: старая точка уменьшается, новая увеличивается, между ними — линия воды
                            float draw_target;
                            if (total > 1) {
                                if (total < 34)
                                    draw_target = (float)(135 - ((total - 1) * 8) / 2 + selected * 8);
                                else
                                    draw_target = 4.0f + (264.0f * selected / (total - 1));
                            } else {
                                draw_target = 135.0f;
                            }
                            
                            float total_dist = draw_target - scrollbar_drop_from;
                            float progress;
                            if (fabsf(total_dist) > 0.5f)
                                progress = (scrollbar_anim_y - scrollbar_drop_from) / total_dist;
                            else
                                progress = 1.0f;
                            if (progress < 0.0f) progress = 0.0f;
                            if (progress > 1.0f) progress = 1.0f;
                            
                            int old_r = (int)((float)head_r * (1.0f - progress) + 0.5f);
                            int new_r = (int)((float)head_r * progress + 0.5f);
                            
                            int from_y = (int)scrollbar_drop_from;
                            int to_y = (int)draw_target;
                            int line_top = from_y < to_y ? from_y : to_y;
                            int line_bot = from_y < to_y ? to_y : from_y;
                            
                            // Линия воды между точками
                            if (line_bot > line_top) {
                                SDL_FillRect(screen, &(SDL_Rect){bar_cx - 1, line_top, 3, line_bot - line_top}, bar_color);
                            }
                            
                            // Старая точка (уменьшается)
                            if (old_r > 0) drawFilledCircle565(screen, bar_cx, from_y, old_r, bar_color);
                            
                            // Новая точка (увеличивается)
                            if (new_r > 0) drawFilledCircle565(screen, bar_cx, to_y, new_r, bar_color);
                        } else {
                            // Статичный индикатор
                            drawFilledCircle565(screen, bar_cx, (int)scrollbar_anim_y, head_r, bar_color);
                        }
                    }
                    
                    if (root_directory && (one_name_on_screen <= 1)) {
                        Entry* entry = top->entries->items[top->selected];
                        char* entry_name = entry->name;
                        char* entry_unique = entry->unique;
                        int available_width = screen->w - SCALE1(PADDING * 2);
                        char display_name[256];
                        int text_width = GFX_truncateText(font.large, entry_unique ? entry_unique : entry_name,
                                                          display_name, available_width, SCALE1(BUTTON_PADDING * 2));
                        int max_width = MIN(available_width, text_width);
                        if (one_name_on_screen)
                            GFX_blitPill(ASSET_WHITE_PILL, screen,
                                         &(SDL_Rect){SCALE1(PADDING), SCALE1(PADDING), max_width, SCALE1(PILL_SIZE)});
                        SDL_Color text_color = COLOR_BLACK_V;
                        
                        if (one_name_on_screen) {
                            SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, display_name, text_color);
                            SDL_BlitSurface(text,
                                            &(SDL_Rect){0, 0, max_width - SCALE1(BUTTON_PADDING * 2), text->h}, screen,
                                            &(SDL_Rect){SCALE1(PADDING + BUTTON_PADDING), SCALE1(PADDING + 4)});
                            SDL_FreeSurface(text);
                        }
                    } else {
                                                // Обновляем логику отрисовки подложки в функции main() (часть с отрисовкой списка):
                                                int total_rows = top->end - top->start;
                                                int max_width = screen->w - SCALE1(PADDING * 2);
                                                int ox = SCALE1(PADDING);
                                                int oy = SCALE1(PADDING);
                                                
                                                // 1. Рисуем ВСЕ элементы — белым
                                                for (int i = top->start, j = 0; i < top->end; i++, j++) {                                               
                                                Entry* entry = top->entries->items[i];
                                                char* name = entry->unique ? entry->unique : entry->name;
                                                int is_favorite = isFavorite(entry->path);
                                                int available_width = max_width;
                                                if (i == top->start) available_width -= ow;
                                                
                                                char display_name[256];
                                                GFX_truncateText(font.large, name, display_name, available_width, SCALE1(BUTTON_PADDING * 2));
                                                SDL_Color color = is_favorite ? COLOR_GOLD : COLOR_WHITE;
                                                
                                                SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, display_name, color);
                                                if (text) {
                                                        int w = MIN(text->w, available_width - SCALE1(BUTTON_PADDING * 2));
                                                        // Для невыбранных элементов рисуем тень (если не в анимации)
                                        SDL_Surface* text_s = TTF_RenderUTF8_Blended(font.large, display_name, COLOR_BLACK_V);
                                        SDL_BlitSurface(text_s, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                        &(SDL_Rect){ox + SCALE1(BUTTON_PADDING) - 1, oy + SCALE1(j * PILL_SIZE + 3)});
                                        SDL_BlitSurface(text_s, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                        &(SDL_Rect){ox + SCALE1(BUTTON_PADDING) - 1, oy + SCALE1(j * PILL_SIZE + 5)});
                                        SDL_BlitSurface(text_s, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                        &(SDL_Rect){ox + SCALE1(BUTTON_PADDING) + 1, oy + SCALE1(j * PILL_SIZE + 3)});
                                        SDL_BlitSurface(text_s, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                        &(SDL_Rect){ox + SCALE1(BUTTON_PADDING) + 1, oy + SCALE1(j * PILL_SIZE + 5)});
                                        SDL_FreeSurface(text_s);
                                                        SDL_BlitSurface(text, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                        &(SDL_Rect){ox + SCALE1(BUTTON_PADDING), oy + SCALE1(j * PILL_SIZE + 4)});
                                                        SDL_FreeSurface(text);
                                                }
                                                }
                                                
                                                // 2. Рисуем анимированную или статическую подложку
                                                if (list_anim.list_anim_frame > 0) {
                                                float anim_progress = 1.0f - ((float)list_anim.list_anim_frame / (float)animation_speed);
                                                int old_in_view = (list_anim.list_anim_old_selected >= top->start && 
                                                                list_anim.list_anim_old_selected < top->end);
                                                int new_in_view = (list_anim.list_anim_selected >= top->start && 
                                                                list_anim.list_anim_selected < top->end);
                                                
                                                // Оба элемента видны - анимируем перемещение
                                                if (old_in_view && new_in_view) {
                                                        int old_y = oy + SCALE1((list_anim.list_anim_old_selected - top->start) * PILL_SIZE);
                                                        int new_y = oy + SCALE1((list_anim.list_anim_selected - top->start) * PILL_SIZE);
                                                        
                                                        // Плавное движение по Y
                                                        float current_y = old_y + (new_y - old_y) * anim_progress;
                                                        
                                                        // Определяем текущий элемент для вычисления ширины
                                                        int current_index;
                                                        int old_text_width = 0, new_text_width = 0;
                                                        
                                                        // Вычисляем ширину текста для старого элемента
                                                        if (list_anim.list_anim_old_selected >= 0 && list_anim.list_anim_old_selected < top->entries->count) {
                                                        Entry* old_entry = top->entries->items[list_anim.list_anim_old_selected];
                                                        char* old_name = old_entry->unique ? old_entry->unique : old_entry->name;
                                                        TTF_SizeUTF8(font.large, old_name, &old_text_width, NULL);
                                                        }
                                                        
                                                        // Вычисляем ширину текста для нового элемента
                                                        if (list_anim.list_anim_selected >= 0 && list_anim.list_anim_selected < top->entries->count) {
                                                        Entry* new_entry = top->entries->items[list_anim.list_anim_selected];
                                                        char* new_name = new_entry->unique ? new_entry->unique : new_entry->name;
                                                        TTF_SizeUTF8(font.large, new_name, &new_text_width, NULL);
                                                        }
                                                        
                                                        // Плавная анимация ширины подложки
                                                        float current_text_width = old_text_width + (new_text_width - old_text_width) * anim_progress;
                                                        
                                                        // Вычисляем ширину подложки (текст + отступы)
                                                        int pill_width = current_text_width + SCALE1(OPTION_PADDING * 4);
                                                        
                                                        // Максимальная ширина (с учетом доступного места)
                                                        int available_width = max_width;
                                                        if (list_anim.list_anim_selected == top->start) available_width -= ow;
                                                        if (pill_width > available_width) pill_width = available_width;
                                                        
                                                        // Добавляем дополнительный отступ, чтобы текст не обрезался
                                                        pill_width += SCALE1(16); // Увеличиваем отступ
                                                        
                                                        // Определяем текущий текст для отображения
                                                        if (anim_progress < 0.5f) {
                                                        current_index = list_anim.list_anim_old_selected;
                                                        } else {
                                                        current_index = list_anim.list_anim_selected;
                                                        }
                                                        
                                                        // Рисуем подложку
                                                        GFX_blitPill(ASSET_WHITE_PILL, screen, &(SDL_Rect){ox, (int)current_y, pill_width, SCALE1(PILL_SIZE)});
                                                        
                                                        // Рисуем текст
                                                        if (current_index >= 0 && current_index < top->entries->count) {
                                                        Entry* current_entry = top->entries->items[current_index];
                                                        char* current_name = current_entry->unique ? current_entry->unique : current_entry->name;
                                                        int is_favorite = isFavorite(current_entry->path);
                                                        
                                                        SDL_Color text_color = is_favorite ? COLOR_GOLD_DARK : COLOR_BLACK_V;
                                                        SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, current_name, text_color);
                                                        if (text) {
                                                                // Вычисляем доступную ширину для текста
                                                                int max_text_width = pill_width - SCALE1(BUTTON_PADDING * 2);
                                                                if (max_text_width < 0) max_text_width = 0;
                                                                
                                                                // Обрезаем текст если нужно
                                                                int w = MIN(text->w, max_text_width);
                                                                SDL_BlitSurface(text, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                                &(SDL_Rect){ox + SCALE1(BUTTON_PADDING), (int)current_y + SCALE1(4)});
                                                                SDL_FreeSurface(text);
                                                        }
                                                        }
                                                } 
                                                // Только один элемент виден
                                                else if (new_in_view) {
                                                        int draw_pos = list_anim.list_anim_selected - top->start;
                                                        int item_oy = oy + SCALE1(draw_pos * PILL_SIZE);
                                                        Entry* entry = top->entries->items[list_anim.list_anim_selected];
                                                        char* name = entry->unique ? entry->unique : entry->name;
                                                        int is_favorite = isFavorite(entry->path);
                                                        int available_width = max_width;
                                                        if (list_anim.list_anim_selected == top->start) available_width -= ow;
                                                        
                                                        char display_name[256];
                                                        GFX_truncateText(font.large, name, display_name, available_width, SCALE1(BUTTON_PADDING * 2));
                                                        
                                                        int text_width = 0;
                                                        TTF_SizeUTF8(font.large, display_name, &text_width, NULL);
                                                        
                                                        // Ширина подложки (с дополнительным отступом)
                                                        int pill_width = text_width + SCALE1(OPTION_PADDING * 2) + SCALE1(16);
                                                        if (pill_width < SCALE1(PILL_SIZE)) pill_width = SCALE1(PILL_SIZE);
                                                        if (pill_width > available_width) pill_width = available_width;
                                                        
                                                        // Подложка
                                                        GFX_blitPill(ASSET_WHITE_PILL, screen, &(SDL_Rect){ox, item_oy, pill_width, SCALE1(PILL_SIZE)});
                                                        
                                                        // Текст
                                                        SDL_Color text_color = is_favorite ? COLOR_GOLD_DARK : COLOR_BLACK_V;
                                                        SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, display_name, text_color);
                                                        if (text) {
                                                        int max_text_width = pill_width - SCALE1(BUTTON_PADDING * 2);
                                                        if (max_text_width < 0) max_text_width = 0;
                                                        
                                                        int w = MIN(text->w, max_text_width);
                                                        SDL_BlitSurface(text, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                                &(SDL_Rect){ox + SCALE1(BUTTON_PADDING), item_oy + SCALE1(4)});
                                                        SDL_FreeSurface(text);
                                                        }
                                                }
                                                } else {
                                                // Без анимации — статическая подложка
                                                if (top->selected >= top->start && top->selected < top->end) {
                                                        int draw_pos = top->selected - top->start;
                                                        int item_oy = oy + SCALE1(draw_pos * PILL_SIZE);
                                                        Entry* entry = top->entries->items[top->selected];
                                                        char* name = entry->unique ? entry->unique : entry->name;
                                                        int is_favorite = isFavorite(entry->path);
                                                        int available_width = max_width;
                                                        if (top->selected == top->start) available_width -= ow;
                                                
                                                        char display_name[256];
                                                        GFX_truncateText(font.large, name, display_name, available_width, SCALE1(BUTTON_PADDING * 2));
                                                
                                                        int text_width = 0;
                                                        TTF_SizeUTF8(font.large, display_name, &text_width, NULL);
                                                        
                                                        // Ширина подложки с дополнительным отступом
                                                        int pill_width = text_width + SCALE1(OPTION_PADDING * 2) + SCALE1(16);
                                                        if (pill_width < SCALE1(PILL_SIZE)) pill_width = SCALE1(PILL_SIZE);
                                                        if (pill_width > available_width) pill_width = available_width;
                                                
                                                        GFX_blitPill(ASSET_WHITE_PILL, screen, &(SDL_Rect){ox, item_oy, pill_width, SCALE1(PILL_SIZE)});
                                                
                                                        SDL_Color text_color = is_favorite ? COLOR_GOLD_DARK : COLOR_BLACK_V;
                                                        SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, display_name, text_color);
                                                        if (text) {
                                                        int max_text_width = pill_width - SCALE1(BUTTON_PADDING * 2);
                                                        if (max_text_width < 0) max_text_width = 0;
                                                        
                                                        int w = MIN(text->w, max_text_width);
                                                        SDL_BlitSurface(text, &(SDL_Rect){0, 0, w, text->h}, screen,
                                                                &(SDL_Rect){ox + SCALE1(BUTTON_PADDING), item_oy + SCALE1(4)});
                                                        SDL_FreeSurface(text);
                                                        }
                                                }
                                                }
                                        }
                } else {
                    GFX_blitMessage(font.large, language_get_string("EMPTY_FOLDER"), screen,
                                    &(SDL_Rect){0, 0, screen->w, screen->h});
                }
                
                if (show_setting) {
                                GFX_blitHardwareHints(screen, show_setting);
                                } else if (canDeleteSelectedEntry() && total > 0) {
                                GFX_blitButtonGroup((char*[]){"L2", language_get_string("DELETE"), 
                                                                isPSP != 0 ? "R2" : (can_resume ? "R2" : NULL),
                                                                isPSP != 0 ? "PPSSPP 1.12" : (can_resume ? language_get_string("RESUME") : NULL),
                                                                BTN_SLEEP == BTN_POWER ? language_get_string("POWER") : language_get_string("MENU"),
                                                                BTN_SLEEP == BTN_POWER || simple_mode ? language_get_string("SLEEP") : language_get_string("MENU"),
                                                                NULL},
                                                        0, screen, 0);
                                } else {
                                GFX_blitButtonGroup(
                                        (char*[]){isPSP != 0 ? "R2" : (can_resume ? "R2" : (BTN_SLEEP == BTN_POWER ? language_get_string("POWER") : language_get_string("MENU"))),
                                                isPSP != 0 ? "PPSSPP 1.12" : (can_resume ? language_get_string("RESUME") : (BTN_SLEEP == BTN_POWER || simple_mode ? language_get_string("SLEEP") : language_get_string("MENU"))),
                                                NULL},
                                        0, screen, 0);
                                }
                
                if (total == 0) {
                    if (stack->count > 1) {
                        if (getSwapButtonAB() == 1)
                            GFX_blitButtonGroup((char*[]){"A", language_get_string("BACK"), NULL}, 0,
                                                screen, 1);
                        else
                            GFX_blitButtonGroup((char*[]){"B", language_get_string("BACK"), NULL}, 0,
                                                screen, 1);
                    }
                } else {
                    if (stack->count > 1) {
                        if (getSwapButtonAB() == 1)
                            GFX_blitButtonGroup(
                                (char*[]){"B", language_get_string("OPEN"), "A",
                                          language_get_string("BACK"), NULL},
                                1, screen, 1);
                        else
                            GFX_blitButtonGroup(
                                (char*[]){"A", language_get_string("OPEN"), "B",
                                          language_get_string("BACK"), NULL},
                                1, screen, 1);
                    } else {
                        if (getSwapButtonAB() == 1)
                            GFX_blitButtonGroup((char*[]){"B", language_get_string("OPEN"), NULL}, 0,
                                                screen, 1);
                        else
                            GFX_blitButtonGroup((char*[]){"A", language_get_string("OPEN"), NULL}, 0,
                                                screen, 1);
                    }
                }
            }
            
            if (need_final_redraw) {
                        need_final_redraw = 0;
                        
                        // Очищаем старое изображение после завершения анимации
                        if (prev_surface_png != NULL) {
                                SDL_FreeSurface(prev_surface_png);
                                prev_surface_png = NULL;
                        }
                        
                        // Освобождаем снимок fade
                        if (fade_snapshot != NULL) {
                            SDL_FreeSurface(fade_snapshot);
                            fade_snapshot = NULL;
                        }
                        
                        // Явно устанавливаем завершенное состояние для следующего кадра
                        list_anim.anim_frame = 0;
                        list_anim.list_anim_frame = 0;
                        list_anim.bg_anim_frame = 0;
                        }
            
            // Полноэкранный dissolve для fade (type 2)
            if (animation == 1 && list_anim.anim_frame > 0 && preview_transition == 2 && fade_snapshot != NULL) {
                float progress = 1.0f - ((float)list_anim.anim_frame / (animation_speed * 2));
                int level = (int)(progress * 64.0f); // 64 уровня из Bayer 8x8
                if (level > 63) level = 63;
                
                if (level < 64) {
                    // Bayer 8x8 матрица (пороги 0-63)
                    static const int bayer8x8[8][8] = {
                        { 0, 32,  8, 40,  2, 34, 10, 42},
                        {48, 16, 56, 24, 50, 18, 58, 26},
                        {12, 44,  4, 36, 14, 46,  6, 38},
                        {60, 28, 52, 20, 62, 30, 54, 22},
                        { 3, 35, 11, 43,  1, 33,  9, 41},
                        {51, 19, 59, 27, 49, 17, 57, 25},
                        {15, 47,  7, 39, 13, 45,  5, 37},
                        {63, 31, 55, 23, 61, 29, 53, 21}
                    };
                    
                    int blk = 2; // размер блока 2x2 пикселя
                    int screen_w = screen->w;
                    int screen_h = screen->h;
                    
                    SDL_LockSurface(screen);
                    SDL_LockSurface(fade_snapshot);
                    
                    Uint16* dst = (Uint16*)screen->pixels;
                    Uint16* src = (Uint16*)fade_snapshot->pixels;
                    int dst_pitch = screen->pitch / 2;
                    int src_pitch = fade_snapshot->pitch / 2;
                    
                    int grid_cols = (screen_w + blk - 1) / blk;
                    int grid_rows = (screen_h + blk - 1) / blk;
                    
                    for (int gy = 0; gy < grid_rows; gy++) {
                        int by_idx = gy & 7;
                        for (int gx = 0; gx < grid_cols; gx++) {
                            if (bayer8x8[by_idx][gx & 7] >= level) {
                                // Копируем блок из снимка (старый кадр)
                                int bx = gx * blk;
                                int by = gy * blk;
                                int bw = (bx + blk <= screen_w) ? blk : (screen_w - bx);
                                int bh = (by + blk <= screen_h) ? blk : (screen_h - by);
                                for (int py = 0; py < bh; py++) {
                                    int dy = (by + py) * dst_pitch + bx;
                                    int sy = (by + py) * src_pitch + bx;
                                    for (int px = 0; px < bw; px++) {
                                        dst[dy + px] = src[sy + px];
                                    }
                                }
                            }
                        }
                    }
                    
                    SDL_UnlockSurface(fade_snapshot);
                    SDL_UnlockSurface(screen);
                }
            }
            
            ow = GFX_blitHardwareGroup(screen, show_setting);
            GFX_flip(screen);
            dirty = 0;
            
            // Пре-загрузка карусели: после отображения кадра загружаем 1 элемент заранее
            if (preview_transition == 4 && total > 0 && top && top->entries) {
                int ci = (int)roundf(carousel_pos);
                if (ci < 0) ci = 0;
                if (ci >= total) ci = total - 1;
                float scroll_dir = carousel_target - carousel_pos;
                int preload_idx = -1;
                
                if (scroll_dir > 0.3f) {
                    for (int d = 1; d <= 6; d++) {
                        int try_idx = ci + d;
                        if (try_idx < total && !carousel_cache_get(try_idx)) {
                            preload_idx = try_idx; break;
                        }
                    }
                } else if (scroll_dir < -0.3f) {
                    for (int d = 1; d <= 6; d++) {
                        int try_idx = ci - d;
                        if (try_idx >= 0 && !carousel_cache_get(try_idx)) {
                            preload_idx = try_idx; break;
                        }
                    }
                } else {
                    for (int d = 1; d <= 6 && preload_idx < 0; d++) {
                        int below = ci + d;
                        if (below < total && !carousel_cache_get(below)) { preload_idx = below; break; }
                        int above = ci - d;
                        if (above >= 0 && !carousel_cache_get(above)) { preload_idx = above; break; }
                    }
                }
                
                if (preload_idx >= 0) {
                    Entry* e = top->entries->items[preload_idx];
                    if (e) {
                        SDL_Surface* raw = loadImageWithPriority(e, select_themes, NULL);
                        if (raw && raw->w > 0 && raw->h > 0) {
                            SDL_Surface* s = scaleToFit(raw, 272, 200);
                            if (s) carousel_cache_put(preload_idx, s);
                            if (raw != surface_png) SDL_FreeSurface(raw);
                        } else {
                            if (raw && raw != surface_png) SDL_FreeSurface(raw);
                        }
                    }
                }
            }
        } else
            GFX_sync();
    }
    
    if (version) SDL_FreeSurface(version);
    if (surface_png != NULL) SDL_FreeSurface(surface_png);
    if (prev_surface_png != NULL) SDL_FreeSurface(prev_surface_png);
    if (fade_snapshot != NULL) SDL_FreeSurface(fade_snapshot);
    if (background != NULL) SDL_FreeSurface(background);
    carousel_cache_reset();
    
    Menu_quit();
    PWR_quit();
    PAD_quit();
    GFX_quit(COLOR_BLACK_V);
    QuitSettings();
}
