import java.io.InputStream;
import java.io.IOException;
import javax.microedition.midlet.MIDlet;

/* v36.08 STM-SPIN guard repro.
 *
 * Reproduces the Doom RPG [Rus] field hang EXACTLY: the game's readFully
 * helper is
 *     for (int i = n; i > 0; i -= in.read(buf, n - i, i)) {}
 * — read() returns -1 at EOF, so i -= (-1) INCREMENTS i and the loop spins on
 * an exhausted stream forever (no exception, no allocation, thread keeps
 * re-entering the read native: invisible to T-STALL/MIDLET-STUCK, r= climbs).
 *
 * Test 1 (spin): /short.bin holds 16 bytes but the loop asks for 4096 —
 *   without the guard this NEVER returns; with the v36.08 guard the VM
 *   injects a catchable IOException after NOJME_STM_SPIN_EOF_LIMIT
 *   consecutive EOF reads and the catch prints SPIN-OK.
 * Test 2 (control): a full read of exactly 16 bytes must complete WITHOUT
 *   any exception (false-positive guard).
 * Test 3 (control): the d.a()-style DataInputStream path still throws a real
 *   EOFException on a short stream (semantics unchanged).
 */
public class TestSpin extends MIDlet {

    /* byte-identical copy of the game's r.a(InputStream, byte[], int) */
    static void readFullyGameStyle(InputStream in, byte[] buf, int n) throws IOException {
        for (int i = n; i > 0; i -= in.read(buf, n - i, i)) {
        }
    }

    public void startApp() {
        System.out.println("TEST: start");

        /* Test 1: the EOF spin — must end with the guard's IOException */
        long t0 = System.currentTimeMillis();
        try {
            InputStream is = getClass().getResourceAsStream("/short.bin");
            byte[] b = new byte[16];
            readFullyGameStyle(is, b, 4096);   /* needs 4096, stream has 16 */
            System.out.println("SPIN-FAIL: loop returned without exception");
        } catch (IOException e) {
            long ms = System.currentTimeMillis() - t0;
            String msg = e.getMessage();
            if (msg != null && msg.indexOf("read-spin guard") >= 0) {
                System.out.println("SPIN-OK: guard IOException after " + ms + " ms");
            } else {
                System.out.println("SPIN-FAIL: wrong IOException: " + msg);
            }
        } catch (Throwable t) {
            System.out.println("SPIN-FAIL: unexpected " + t);
        }

        /* Test 2: exact-size read — no guard involvement */
        try {
            InputStream is = getClass().getResourceAsStream("/short.bin");
            byte[] b = new byte[16];
            readFullyGameStyle(is, b, 16);     /* exactly the stream size */
            System.out.println("CTRL-OK: exact read completed, b0=" + b[0] + " b15=" + b[15]);
        } catch (Throwable t) {
            System.out.println("CTRL-FAIL: " + t);
        }

        /* Test 3: DIS read past EOF still throws EOFException (not the guard) */
        try {
            InputStream is = getClass().getResourceAsStream("/short.bin");
            java.io.DataInputStream dis = new java.io.DataInputStream(is);
            for (int i = 0; i < 100; i++) dis.readByte();   /* 100 > 16 */
            System.out.println("DIS-FAIL: no exception");
        } catch (IOException e) {
            System.out.println("DIS-OK: " + e);
        } catch (Throwable t) {
            System.out.println("DIS-FAIL: unexpected " + t);
        }

        System.out.println("TEST: done");
        notifyDestroyed();
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) { }
}
