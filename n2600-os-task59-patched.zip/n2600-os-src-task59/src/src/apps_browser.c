/* apps_browser.c — веб-браузер N2600-OS.
 *
 * Возможности:
 *   - АДРЕСНАЯ СТРОКА: клик по ней или Ctrl+L — редактирование;
 *     Enter / кнопка «Go» — переход. Поддерживаются:
 *       http://host/path        — HTTP GET (в потоке ЭТОГО окна);
 *       имя файла               — открытие файла из RAM disk
 *                                 (readme.txt, help.md, demo.js...);
 *       www.host/path           — автоматически как http://.
 *   - HTTP GET запрос (net_http_get), выполняется в потоке окна:
 *     зависший запрос больше не блокирует систему и другие окна.
 *   - HTML -> Markdown конвертер (htmlconv.c) + рендеринг Markdown.
 *   - Прокрутка (PgUp/PgDn/стрелки/колёсико).
 *   - Сессия 67: кнопка Save (или Ctrl+S) — сохранить открытую страницу
 *     (Markdown/текст) в RAM disk под именем из адреса; существующие
 *     файлы не перезаписываются (подбирается свободное имя).
 *
 * Исправления аудита (реализованы в htmlconv.c и здесь):
 *   [H1] бесконечный цикл in_tag — см. htmlconv.c;
 *   [H2] static char md[8192] — общий на все окна: теперь буфер
 *        выделяется на каждый вызов browser_load_content() и
 *        принадлежит вызвавшему окну (два окна не конфликтуют);
 *   [H3] entities в конце файла — см. htmlconv.c.
 *
 * Буферы этого окна (browser_t) — собственность ОДНОГО окна;
 * fetch-буфер выделяется только на время запроса.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "clipboard.h" /* Ctrl+C/V — общий буфер с редактором */
#include "task.h"
#include "htmlconv.h"
#include "utf8.h"
#include "brlines.h"
#include "imgsvc.h"   /* сессия 55: декодирование PNG/JPEG/BMP/GIF */
#include "brpage.h"   /* сессия 55: картинки/ссылки страницы */
#include "brform.h"   /* Task 47: модель форм/скриптов страницы */
#include "brjs.h"     /* Task 47: JavaScript страницы (MicroQuickJS) */
#include "mqjs_os.h"  /* Task 47: mqjs_stdlib_def/mqjs_br_cfunc_base */

#define BR_HDR 22          /* высота адресной строки */
#define BR_STATUS_H 14
#define BR_MD_MAX 8192     /* МИНИМАЛЬНЫЙ буфер конвертера на вызов (FIX [H2]);
                            * FIX [BR-LONGPAGE]: для HTML ёмкость растёт от
                            * размера страницы (см. browser_load_content) —
                            * раньше 8 КиБ жёстко обрезали длинные страницы */
#define BR_FETCH_MAX 262144 /* HTTP-ответ на время запроса (256 КиБ; было
                             * 16 КиБ — страницы длиннее обрезались молча;
                             * imgsvc и так грузит картинки по 512 КиБ) */
#define BR_FILE_MAX 262144 /* лимит файла из RAM disk / не-HTML текста
                            * (было 64 КиБ) */
#define BR_ADDR_MAX 118
#define BR_HIST_MAX 16     /* история для Back (сессия 55) */

/* FIX (аудит UTF-8): прежде строки хранились в фикс-массиве 100x96 БАЙТ:
 *  - длинные строки ОБРЕЗАЛИСЬ (переноса не было вовсе),
 *  - кириллица резалась посередине символа (2 байта UTF-8).
 * Теперь текст хранится как есть (b->md), а строки отображения —
 * динамический массив, который перестраивается с ПЕРЕНОСОМ по СИМВОЛАМ
 * под текущую ширину окна (любая длинная строка переносится корректно). */
typedef struct {
    char *md;              /* исходный текст (Markdown/простой текст) */
    int  md_len;
    brl_list_t L;          /* строки отображения после переноса (brlines.h) */
    int  wrap_maxc;        /* ширина (в символах), по которой строились L; -1 = не строили */
    int  scroll;
    int  fetching;         /* 1 = идёт сетевой запрос (в этом потоке) */
    char url[128];         /* адрес текущей страницы */
    char status[80];
    char hover[96];        /* сессия 55: ссылка под курсором (для статуса) */
    /* адресная строка */
    char addr[BR_ADDR_MAX + 1];
    int  addr_len;
    int  addr_focus;       /* 1 = редактируем адрес */
    /* выделение текста (запрос: «копирование между приложениями,
     * в том числе браузером»). Координаты — строки ОТОБРАЖЕНИЯ (b->L)
     * и колонки в СИМВОЛАХ: sel_ar/ac — якорь (нажатие ЛКМ),
     * sel_br/bc — второй конец (drag). Нормализация — в br_sel_norm. */
    int sel_active;        /* 1 = есть непустое выделение */
    int sel_drag;          /* 1 = ЛКМ зажата в контенте (drag) */
    int sel_ar, sel_ac;    /* якорь: строка/колонка отображения */
    int sel_br, sel_bc;    /* второй конец (следует за курсором) */
    /* полоса прокрутки (общий виджет, сессия 17) */
    wm_scrollbar_t sb;
    /* сессия 55: картинки/ссылки страницы + история Back */
    brp_page_t page;
    int  imgs_pending;     /* 1 = картинки ждут загрузки (окно уже есть) */
    char hist[BR_HIST_MAX][128];
    int  hist_n;
    /* Task 47: формы и JavaScript страницы */
    brf_forms_t forms;     /* поля форм + скрипты (brform.h) */
    brjs_env_t  js;        /* JS-контекст страницы (живёт до закрытия/перехода) */
    int         focus;     /* фокус ввода: индекс поля или -1 */
    /* Task 51 [BR-SAVE]: исходник страницы (HTML ДО конвертации) —
     * «Save» сохраняет его как есть: с комментариями, <script> и
     * кнопками (Markdown-конверсия всё это вырезает) */
    char *src;
    int   src_len;
    /* служебное */
    window_t *win;
} browser_t;

/* ---------- утилиты ---------- */

static int ci_eq(char a, char b)
{
    if (a >= 'A' && a <= 'Z') a += 32;
    if (b >= 'A' && b <= 'Z') b += 32;
    return a == b;
}

static int ci_same(const char *a, const char *b)
{
    while (*a && *b) {
        if (!ci_eq(*a, *b)) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* Поиск файла в RAM disk без учёта регистра.
 * Возвращает 1 и размер, если найден. */
static int ramfs_lookup(const char *name, u32 *out_size)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        if (ci_same(ents[i].name, name)) {
            if (out_size) *out_size = ents[i].size;
            return 1;
        }
    }
    return 0;
}

/* ---------- загрузка контента и конвертация ---------- */

/* forward (сессия 55): циклы картинок/разметки */
static void br_layout_images(browser_t *b);
static void br_render_now(browser_t *b);
static void br_ensure_lines(browser_t *b, int cw);
/* forward (Task 47): формы/JS/навигация */
static int  br_parse_host(char *host, u16 *port);
static void br_navigate_ex(browser_t *b, const char *addr, int redirs);
static void br_navigate(browser_t *b, const char *addr);
static void br_navigate_post(browser_t *b, const char *addr, const char *body);
static void br_form_layout(browser_t *b);
static void br_js_ensure(browser_t *b);
static void br_form_submit(browser_t *b, int form_idx);
static void br_page_refresh(browser_t *b);
/* [BR-MP3]/Save: имена RAM disk (определения — в разделе сохранения) */
static void br_save_derive_stem(const char *url, char *out, int out_max);
static int  br_save_free_name_ext(const char *stem, const char *ext,
                                  char *out, int out_max);

/* Строки отображения под текущую ширину окна (перестройка только
 * при изменении ширины или нового контента). (cw - 16) / 8: текст
 * рисуется с x=4, полоса прокрутки занимает правый край cw-7..cw-2 —
 * резерв 16px держит текст ВНЕ полосы (раньше последний символ
 * наезжал на жёлоб на 2px). */
static void br_ensure_lines(browser_t *b, int cw)
{
    int maxc = (cw - 16) / 8;
    if (maxc < 8) maxc = 8;
    if (b->L.lines && b->wrap_maxc == maxc) return;
    brl_wrap(b->md, b->md_len, maxc, &b->L);
    b->wrap_maxc = maxc;
    br_layout_images(b);
    br_form_layout(b);        /* Task 47: якоря полей -> строки отображения */
}

/* ---------- формы и JavaScript (Task 47) ---------- */

/* Поле по строке отображения (якорь \x03) или NULL. */
static brf_field_t *br_field_by_row(browser_t *b, int row)
{
    for (int i = 0; i < b->forms.nfields; i++)
        if (b->forms.fields[i].row == row)
            return &b->forms.fields[i];
    return NULL;
}

/* Якоря \x03 в md -> строки отображения: поле.row + класс строки. */
static void br_form_layout(browser_t *b)
{
    for (int k = 0; k < b->forms.nfields; k++)
        b->forms.fields[k].row = -1;
    for (int i = 0; i < b->L.nlines; i++) {
        const char *s = b->L.lines[i];
        if (s[0] != BRF_MARK || s[1] != 0) continue;
        b->L.cls[i] = BRL_CLS_FORM;
        int src = b->L.srcidx[i];
        for (int k = 0; k < b->forms.nfields; k++) {
            if (b->forms.fields[k].src_line == src) {
                b->forms.fields[k].row = i;
                break;
            }
        }
    }
}

/* Отрезать HTTP-заголовки от сырого ответа (возвращает тело и длину).
 * Task 47: вынесено для fetch()-колбэка JS. */
static void br_strip_headers(const char *content, int len,
                             const char **out_body, int *out_len)
{
    if (len > 5 && !strncmp(content, "HTTP/", 5)) {
        int i = 0;
        while (i < len && i < 2048) {
            if (content[i] == '\n') {
                if (i + 2 < len && content[i + 1] == '\r' && content[i + 2] == '\n') {
                    content += i + 3;
                    len -= i + 3;
                    break;
                }
                if (i + 1 < len && content[i + 1] == '\n') {
                    content += i + 2;
                    len -= i + 2;
                    break;
                }
            }
            i++;
        }
    }
    *out_body = content;
    *out_len = len;
}

/* Колбэк fetch()/httpGet() из JS и загрузка <script src>.
 * Возвращает длину ТЕЛА или -1 (ошибка — в js.fetch_err). */
static int br_fetch_cb(void *ud, const char *url, char *out, int out_max)
{
    browser_t *b = (browser_t *)ud;
    char host[128];
    char path[256];
    char abs[300];
    img_url_resolve(b->url, url, abs, (int)sizeof(abs));

    const char *p = abs;
    int use_tls = 0;
    if (!strncmp(p, "https://", 8)) { p += 8; use_tls = 1; }
    else if (!strncmp(p, "http://", 7)) p += 7;
    else {
        /* не http — попробуем как файл RAM disk */
        u32 fsize = 0;
        if (ramfs_lookup(p, &fsize) && fsize > 0 && fsize < BR_FILE_MAX) {
            char *buf = (char *)malloc(fsize);
            if (!buf) return -1;
            u32 got = ramfs_read(p, buf, fsize);
            int n = got < (u32)out_max ? (int)got : out_max;
            memcpy(out, buf, (u32)n);
            free(buf);
            return n;
        }
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "схема не http(s)");
        return -1;
    }
    int hi = 0;
    while (*p && *p != '/' && hi < 127) host[hi++] = *p++;
    host[hi] = 0;
    u16 port = use_tls ? 443 : 80;
    if (!br_parse_host(host, &port)) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "неверный порт");
        return -1;
    }
    if (!*p) p = "/";
    strncpy(path, p, 255);
    path[255] = 0;
    if (!host[0]) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "пустой хост");
        return -1;
    }

    char *resp = (char *)malloc(BR_FETCH_MAX);
    if (!resp) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "нет памяти");
        return -1;
    }
    int n = net_http_get(host, port, path, resp, BR_FETCH_MAX, 10000);
    if (n <= 0) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "%.40s",
                 net_http_errstr());
        free(resp);
        return -1;
    }
    const char *body;
    int blen;
    br_strip_headers(resp, n, &body, &blen);
    if (blen > out_max) blen = out_max;
    memcpy(out, body, (u32)blen);
    free(resp);
    return blen;
}

/* FIX [JS-NAV]/[META-REFRESH]: защита от бесконечных цепочек
 * редиректов из скриптов/meta-refresh (страница редиректит на саму
 * себя или по кругу): не более 8 вложенных переходов. HTTP-редиректы
 * (301/302) имеют отдельный лимит (redirs < 4) — не пересекаются. */
static int s_br_nav_chain = 0;

/* JS-контекст страницы (создаётся лениво). */
static void br_js_ensure(browser_t *b)
{
    if (b->js.alive) return;
    if (brjs_start(&b->js, (const JSSTDLibraryDef *)mqjs_stdlib_def(),
                   mqjs_br_cfunc_base()) != 0) {
        snprintf(b->status, sizeof(b->status), "JS: нет памяти под контекст");
        return;
    }
    /* FIX [JS-NAV]: page_url и location.href — ПОСЛЕ brjs_start
     * (он делает memset окружения). Иначе href="" и ЛЮБОЙ скрипт
     * получал ложный «переход» на текущую страницу. */
    b->js.forms = &b->forms;
    brjs_set_page_url(&b->js, b->url);
    b->js.fetch_fn = br_fetch_cb;
    b->js.fetch_ud = b;
}

/* Вставить текст в md НА СТРОКУ src_line (замена этой строки).
 * Новая md — свежий malloc (рост), старая освобождается. */
static void br_splice_at_line(browser_t *b, int src_line,
                              const char *ins, int ins_len)
{
    /* найти байтовое начало строки src_line */
    int pos = 0, line = 0;
    while (line < src_line && pos < b->md_len) {
        while (pos < b->md_len && b->md[pos] != '\n') pos++;
        if (pos >= b->md_len) break;
        pos++;
        line++;
    }
    int le = pos;
    while (le < b->md_len && b->md[le] != '\n') le++;
    int tail_len = b->md_len - le;              /* \n и всё после строки */
    int head_len = pos;

    /* вставка НЕ после перевода строки — добавим '\n' сами (document.write
     * в конец страницы/скрипта не должен клеиться к последней строке) */
    char pre_nl = 0;
    if (head_len > 0 && b->md[head_len - 1] != '\n')
        pre_nl = 1;

    int new_len = head_len + (int)pre_nl + ins_len + tail_len;
    char *nb = (char *)malloc((u32)new_len + 1);
    if (!nb) return;
    memcpy(nb, b->md, (u32)head_len);
    int o = head_len;
    if (pre_nl) nb[o++] = '\n';
    if (ins_len > 0) memcpy(nb + o, ins, (u32)ins_len);
    o += ins_len;
    if (tail_len > 0) memcpy(nb + o, b->md + le, (u32)tail_len);
    nb[new_len] = 0;
    if (b->md) free(b->md);
    b->md = nb;
    b->md_len = new_len;
}

/* Вырезать все якоря скриптов \x04 (после исполнения). */
static void br_remove_script_anchors(browser_t *b)
{
    int r = 0, w = 0;
    while (r < b->md_len) {
        int ls = r;
        while (r < b->md_len && b->md[r] != '\n') r++;
        int le = r;
        int had_nl = (r < b->md_len);
        if (had_nl) r++;
        if (le > ls && b->md[ls] == BRJ_MARK && le - ls == 1)
            continue;                            /* строка-якорь — долой */
        for (int q = ls; q < le; q++) b->md[w++] = b->md[q];
        if (had_nl) b->md[w++] = '\n';
    }
    b->md_len = w;
    if (b->md) b->md[w] = 0;
}

/* Исполнить сниппет (onclick / javascript:). document.write дописывается
 * В КОНЕЦ страницы (отличие от DOM: позиция скрипта известна только при
 * загрузке). 0 = ок. */
static int br_js_run_snippet(browser_t *b, const char *code)
{
    br_js_ensure(b);
    if (!b->js.alive) return -1;
    b->js.wlen = 0;
    b->js.wovf = 0;
    b->js.wbuf_static[0] = 0;
    int rc = brjs_eval(&b->js, code, "snippet");
    if (b->js.alert_n > 0) {
        snprintf(b->status, sizeof(b->status), "JS alert: %s", b->js.alert);
    } else if (rc != 0) {
        snprintf(b->status, sizeof(b->status), "%.78s", b->js.last_err);
    } else {
        snprintf(b->status, sizeof(b->status), "JS выполнен");
    }
    /* document.write -> в конец страницы (Markdown, как обычный HTML) */
    if (b->js.wlen > 0) {
        char *wmd = (char *)malloc(BR_MD_MAX);
        if (wmd) {
            int wl = html_to_md(b->js.wbuf_static, b->js.wlen, wmd, BR_MD_MAX);
            if (wl > 0)
                br_splice_at_line(b, b->L.nlines ? 0x7FFFFFF : 0, wmd, wl);
            free(wmd);
        }
    }
    /* FIX [JS-NAV]: onclick/javascript:-ссылки тоже умеют навигацию
     * (location.href=..., location.replace(...), document.location=...) */
    if (b->js.nav_pending) {
        char nu[BR_ADDR_MAX + 1];
        char abs[300];
        strncpy(nu, b->js.nav_url, sizeof(nu) - 1);
        nu[sizeof(nu) - 1] = 0;
        b->js.nav_pending = 0;
        img_url_resolve(b->url, nu, abs, (int)sizeof(abs));
        if (s_br_nav_chain < 8) {
            s_br_nav_chain++;
            br_navigate(b, abs);
            s_br_nav_chain--;
        } else {
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений");
        }
        /* страница УЖЕ заменена навигацией: вызывающий (javascript:-ветка
         * br_navigate_full) не должен делать br_page_refresh над НОВОЙ
         * страницей (wlen здесь устаревший, а md новой страницы уже
         * разобран). rc != 0 гасит ветку document.write. */
        if (rc == 0)
            rc = 2;
    }
    return rc;
}

/* Исполнить скрипты страницы (по порядку); document.write вставляется
 * НА МЕСТЕ скрипта. Внешние <script src> скачиваются br_fetch_cb.
 * FIX [JS-NAV]: возвращает 1, если скрипт запросил переход
 * (браузер уже ушёл на новый адрес — вызывающий код должен выйти). */
static int br_page_scripts_run(browser_t *b)
{
    int nav = 0;
    if (b->forms.nscripts == 0) return 0;
    br_js_ensure(b);
    if (!b->js.alive) return 0;

    for (int i = 0; i < b->forms.nscripts; i++) {
        brf_script_t *sc = &b->forms.scripts[i];
        char *fetched = NULL;
        const char *code = sc->code;
        const char *nm = "inline";

        if (sc->src[0]) {
            nm = "external";
            fetched = (char *)malloc(BRJS_FETCH_MAX + 1);
            if (fetched) {
                int n = br_fetch_cb(b, sc->src, fetched, BRJS_FETCH_MAX);
                if (n < 0) {
                    snprintf(b->status, sizeof(b->status),
                             "script src: %.46s", b->js.fetch_err);
                    free(fetched);
                    fetched = NULL;
                } else {
                    fetched[n] = 0;
                }
            }
            code = fetched;
        }
        if (code && code[0]) {
            b->js.wlen = 0;
            b->js.wovf = 0;
            b->js.wbuf_static[0] = 0;
            int rc = brjs_eval(&b->js, code, nm);
            if (b->js.alert_n > 0) {
                snprintf(b->status, sizeof(b->status),
                         "JS alert: %s", b->js.alert);
            } else if (rc != 0) {
                snprintf(b->status, sizeof(b->status), "%.78s", b->js.last_err);
            }
            /* document.write — на МЕСТЕ скрипта (якорь \x04) */
            if (b->js.wlen > 0) {
                char *wmd = (char *)malloc(BR_MD_MAX);
                if (wmd) {
                    int wl = html_to_md(b->js.wbuf_static, b->js.wlen,
                                        wmd, BR_MD_MAX);
                    if (wl > 0)
                        br_splice_at_line(b, sc->src_line, wmd, wl);
                    free(wmd);
                }
                brf_reindex(&b->forms, b->md, b->md_len);
            }
        }
        if (fetched) free(fetched);
        sc->done = 1;
        /* FIX [JS-NAV]: скрипт запросил переход — оставшиеся скрипты
         * не исполняем (в браузерах навигация отменяет их) и уходим. */
        if (b->js.nav_pending) {
            nav = 1;
            break;
        }
    }

    if (nav) {
        char nu[BR_ADDR_MAX + 1];
        char abs[300];
        strncpy(nu, b->js.nav_url, sizeof(nu) - 1);
        nu[sizeof(nu) - 1] = 0;
        b->js.nav_pending = 0;
        img_url_resolve(b->url, nu, abs, (int)sizeof(abs));
        snprintf(b->status, sizeof(b->status), "JS redirect -> %.46s", abs);
        if (s_br_nav_chain < 8) {
            s_br_nav_chain++;
            br_navigate(b, abs);
            s_br_nav_chain--;
        } else {
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений");
        }
        return 1;
    }

    br_remove_script_anchors(b);
    brf_reindex(&b->forms, b->md, b->md_len);
    return 0;
}

/* Активировать поле кликом/Enter/Space. */
static void br_field_activate(browser_t *b, brf_field_t *fl)
{
    if (!strcmp(fl->type, "checkbox") || !strcmp(fl->type, "radio")) {
        fl->checked = !fl->checked;
    } else if (!strcmp(fl->type, "select")) {
        if (fl->nopts > 0)
            fl->opt_sel = (fl->opt_sel + 1) % fl->nopts;
    } else if (!strcmp(fl->type, "submit") || !strcmp(fl->type, "reset")) {
        br_form_submit(b, fl->form);        /* reset ведёт себя как submit
                                             * (значения по умолчанию не
                                             * хранятся) */
        return;
    } else if (!strcmp(fl->type, "button")) {
        if (fl->js[0])
            br_js_run_snippet(b, fl->js);
        return;
    }
    win_invalidate(b->win);
}

/* Перестроить страницу после изменения md (document.write и пр.). */
static void br_page_refresh(browser_t *b)
{
    brl_free(&b->L);
    b->wrap_maxc = -1;
    b->md_len = brp_analyze(&b->page, b->md, b->md_len);
    br_ensure_lines(b, win_content_w(b->win));
}

/* Отправить форму form_idx (-1 = поля вне форм: GET на текущий адрес). */
static void br_form_submit(browser_t *b, int form_idx)
{
    char body[1024];
    char action[300];
    char abs[300];

    if (!brf_serialize(&b->forms, form_idx, body, (int)sizeof(body))) {
        snprintf(b->status, sizeof(b->status), "Форма: слишком длинное тело");
        win_invalidate(b->win);
        return;
    }

    const brf_form_t *fo = NULL;
    if (form_idx >= 0 && form_idx < b->forms.nforms &&
        b->forms.forms[form_idx].used)
        fo = &b->forms.forms[form_idx];

    if (fo && fo->action[0])
        strncpy(action, fo->action, sizeof(action) - 1);
    else
        strncpy(action, b->url, sizeof(action) - 1);
    action[sizeof(action) - 1] = 0;

    int is_post = (fo && !strcmp(fo->method, "post"));
    img_url_resolve(b->url, action, abs, (int)sizeof(abs));

    if (!is_post) {
        char target[BR_ADDR_MAX + 1];
        if (body[0]) {
            char sep = strchr(abs, '?') ? '&' : '?';
            snprintf(target, sizeof(target), "%s%c%s", abs, sep, body);
        } else {
            snprintf(target, sizeof(target), "%s", abs);
        }
        snprintf(b->status, sizeof(b->status), "Отправка формы (GET)...");
        br_navigate(b, target);
    } else {
        snprintf(b->status, sizeof(b->status), "Отправка формы (POST)...");
        br_navigate_post(b, abs, body);
    }
}

/* ---------- картинки страницы (сессия 55) ---------- */

static brp_img_t *br_img_by_src(browser_t *b, int src_idx)
{
    for (int i = 0; i < b->page.nimgs; i++)
        if (b->page.imgs[i].src_idx == src_idx)
            return &b->page.imgs[i];
    return NULL;
}

/* Резерв строк под картинки в списке отображения: якорные строки
 * (BRP_IMG_MARK) получают высоту готовой картинки (в строках по 16px);
 * после якоря вставляются пустые строки BRL_CLS_IMG. */
static void br_layout_images(browser_t *b)
{
    for (int i = 0; i < b->L.nlines; i++) {
        const char *s = b->L.lines[i];
        if (s[0] != BRP_IMG_MARK || s[1] != 0) continue;
        brp_img_t *im = br_img_by_src(b, b->L.srcidx[i]);
        b->L.cls[i] = BRL_CLS_IMG;
        if (im) {
            int rows = (im->dh + 15) / 16;
            if (rows < 1) rows = 1;
            if (im->state != 1) rows = 1;   /* не готова: строка-заглушка */
            im->row = i;
            im->rows = rows;
            if (rows > 1)
                brl_insert_blanks(&b->L, i + 1, rows - 1, b->L.srcidx[i]);
        }
    }
}

/* Загрузить все картинки страницы (ВЫЗЫВАТЬ ИЗ ПОТОКА ОКНА — сеть
 * блокирующая, как и загрузка самой страницы). Картинка масштабируется
 * билинейно под ширину окна (и по высоте до 60% окна). */
static void br_load_images(browser_t *b)
{
    int total = b->page.nimgs;
    int maxw, maxh;
    int ok = 0, fail = 0;

    if (!b->win || total == 0) return;
    maxw = win_content_w(b->win) - 16;
    if (maxw < 64) maxw = 64;
    maxh = (win_content_h(b->win) * 6) / 10;
    if (maxh < 120) maxh = 120;

    b->imgs_pending = 0;
    for (int i = 0; i < total; i++) {
        brp_img_t *im = &b->page.imgs[i];
        img_t t, s;

        snprintf(b->status, sizeof(b->status), "Картинка %d/%d: %.48s...",
                 i + 1, total, im->url);
        br_render_now(b);

        if (img_decode_url(im->url, b->url, &t) != 0) {
            im->state = -1;
            fail++;
            win_invalidate(b->win);
            continue;
        }
        im->w = t.w;
        im->h = t.h;

        int dw = t.w, dh = t.h;
        if (dw > maxw) {
            dh = t.h * maxw / t.w;
            dw = maxw;
            if (dh < 1) dh = 1;
        }
        if (dh > maxh) {
            dw = dw * maxh / dh;
            dh = maxh;
            if (dw < 1) dw = 1;
        }

        if (img_scale(&t, dw, dh, &s) == 0) {
            im->rgba = s.rgba;
            im->dw = s.w;
            im->dh = s.h;
            im->state = 1;
            ok++;
        } else {
            im->state = -1;
            fail++;
        }
        img_dispose(&t);          /* оригинал больше не нужен */
        win_invalidate(b->win);
    }

    if (total)
        snprintf(b->status, sizeof(b->status),
                 "Картинки: %d готово, %d недоступно", ok, fail);

    /* Пересобрать строки-отображение ПОСЛЕ загрузки: br_ensure_lines
     * выходит по раннему return (ширина не менялась), а высоты
     * картинок (dh) уже изменились — сбрасываем кэш принудительно. */
    brl_free(&b->L);
    b->wrap_maxc = -1;
    br_ensure_lines(b, win_content_w(b->win));
    b->scroll = 0;
    win_invalidate(b->win);
}

static void browser_load_content(browser_t *b, const char *url,
                                  const char *content, int len)
{
    strncpy(b->url, url ? url : "", sizeof(b->url) - 1);
    b->url[sizeof(b->url) - 1] = 0;
    b->fetching = 0;
    b->sel_active = 0;     /* новая страница — старое выделение не имеет смысла */
    b->sel_drag = 0;

    /* сессия 55: пиксельные буферы прошлой страницы больше не нужны */
    brp_reset(&b->page);
    b->hover[0] = 0;

    /* FIX [N5]: сырой ответ HTTP-клиента содержит ЗАГОЛОВКИ
     * ("HTTP/1.0 200 OK\r\nServer:...\r\n\r\n<body>"). Раньше они
     * попадали в конвертер и на экран как текст. Отрезаем всё до
     * пустой строки — показываем только тело. */
    if (len > 5 && !strncmp(content, "HTTP/", 5)) {
        int i = 0;
        while (i < len && i < 2048) {
            if (content[i] == '\n') {
                if (i + 2 < len && content[i + 1] == '\r' && content[i + 2] == '\n') {
                    content += i + 3;
                    len -= i + 3;
                    break;
                }
                if (i + 1 < len && content[i + 1] == '\n') {
                    content += i + 2;
                    len -= i + 2;
                    break;
                }
            }
            i++;
        }
    }

    /* Это HTML или уже Markdown? */
    int is_html = 0;
    for (int i = 0; i < len && i < 200; i++) {
        if (content[i] == '<') { is_html = 1; break; }
    }

    /* Task 51 [BR-SAVE]: храним ИСХОДНИК HTML-страницы (тело после
     * отрезки заголовков, до конвертации). «Save» пишет его как есть:
     * комментарии, <script>-код, кнопки форм — всё на месте (сама
     * конвертация в Markdown теряет их безвозвратно). Не-HTML страницы
     * исходника не имеют — сохраняется их Markdown (он и есть текст). */
    if (b->src) { free(b->src); b->src = NULL; }
    b->src_len = 0;
    if (is_html && len > 0 && len <= BR_FILE_MAX) {
        char *sc = (char *)malloc((u32)len + 1);
        if (sc) {
            memcpy(sc, content, (u32)len);
            sc[len] = 0;
            b->src = sc;
            b->src_len = len;
        }
        /* нет памяти под копию — Save вернётся к Markdown (не фатально) */
    }

    /* FIX [BR-LONGPAGE]: длинные страницы обрезались ДВАЖДЫ:
     *  1) HTTP-ответ целиком был ограничен BR_FETCH_MAX (16 КиБ) —
     *     поднят до 256 КиБ (net_http_get сам уважает буфер вызывающего);
     *  2) ёмкость под Markdown была ВСЕГДА BR_MD_MAX (8 КиБ), а
     *     html_to_md честно останавливается на md_max — даже полностью
     *     загруженная страница > 8 КиБ Markdown теряла хвост.
     * Теперь для HTML ёмкость масштабируется от размера входа с запасом
     * x2 + 8 КиБ (худший случай: расширение разметки [T](url) — URL
     * переносится в Markdown целиком, сущности сжимаются).
     * FIX [BR-MD-OVF] (порча кучи «0 блоков» после некоторых сайтов):
     * не-HTML ветка копирует не более BR_FILE_MAX — ёмкость под полный
     * текст выделяется честно (см. исходный FIX ниже). */
    int md_cap = BR_MD_MAX;
    if (is_html) {
        int est = len * 2 + 8192;
        if (est > md_cap) md_cap = est;
    } else {
        int raw = len < BR_FILE_MAX ? len : BR_FILE_MAX;
        if (raw + 1 > md_cap) md_cap = raw + 1;
    }
    char *md = (char *)malloc((u32)md_cap);
    if (!md) {
        snprintf(b->status, sizeof(b->status), "Нет памяти для конвертации");
        brl_free(&b->L);
        b->wrap_maxc = -1;
        return;
    }

    int md_len;
    if (is_html) {
        snprintf(b->status, sizeof(b->status),
                 "Конвертация HTML->Markdown (%d байт)...", len);
        md_len = html_to_md(content, len, md, md_cap);
        snprintf(b->status, sizeof(b->status),
                 "HTML %d байт -> Markdown %d байт", len, md_len);
    } else {
        /* FIX (аудит): простой текст больше не режется до 8 КиБ —
        * храним столько, сколько пришло (в пределах лимита файла). */
        md_len = len < BR_FILE_MAX ? len : BR_FILE_MAX;
        memcpy(md, content, (u32)md_len);
        md[md_len] = 0;
        snprintf(b->status, sizeof(b->status),
                 "Markdown/текст (%d байт)", len);
    }

    /* Храним исходник (для переноса строк при отрисовке/resize) */
    {
        char *store = (char *)malloc((u32)md_len + 1);
        if (!store) {
            free(md);
            snprintf(b->status, sizeof(b->status), "Нет памяти под текст");
            brl_free(&b->L);
            b->wrap_maxc = -1;
            return;
        }
        memcpy(store, md, (u32)md_len);
        store[md_len] = 0;
        if (b->md) free(b->md);
        b->md = store;
        b->md_len = md_len;
    }
    free(md);

    /* Task 47: новая страница — старый JS-контекст не имеет смысла */
    brjs_stop(&b->js);
    b->focus = -1;

    /* Task 47: формы -> модель, маркеры -> якоря (md только сжимается);
     * затем скрипты по порядку (document.write вставляется на месте),
     * и только потом разбор ссылок/картинок (brp_analyze) — чтобы
     * вывод скриптов тоже стал кликабельным. */
    b->md_len = brf_parse(&b->forms, b->md, b->md_len);
    /* FIX [META-REFRESH]: страницы-редиректы <meta http-equiv=refresh
     * content="N;url=U">. Раньше молча игнорировались. Переход сразу
     * (браузер не ждёт N секунд — деталь, не критичная для UX). */
    if (b->forms.refresh_url[0]) {
        char rabs[300];
        img_url_resolve(b->url, b->forms.refresh_url, rabs, (int)sizeof(rabs));
        snprintf(b->status, sizeof(b->status),
                 "Meta refresh (%d с) -> %.40s", b->forms.refresh_delay, rabs);
        if (s_br_nav_chain < 8) {
            s_br_nav_chain++;
            br_navigate(b, rabs);
            s_br_nav_chain--;
        } else {
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений");
        }
        return;
    }
    if (br_page_scripts_run(b))
        return;          /* JS-редирект: страница уже заменена */

    /* сессия 55: разбор страницы — маркеры картинок -> якоря, сбор
     * ссылок с абсолютными смещениями (md может быть сжат). */
    b->md_len = brp_analyze(&b->page, b->md, b->md_len);
    b->imgs_pending = (b->page.nimgs > 0);

    brl_free(&b->L);        /* строки построятся при первой отрисовке */
    b->wrap_maxc = -1;
    b->scroll = 0;
    b->hover[0] = 0;
    {
        /* дописать " | строк: N" без strncat (его нет в kernel string.c).
        * N — строк ИСХОДНОГО текста (перенос может дать больше видимых). */
        int src_lines = 1;
        for (int i = 0; i < b->md_len; i++)
            if (b->md[i] == '\n') src_lines++;
        char tail[48];
        snprintf(tail, sizeof(tail), " | строк: %d", src_lines);
        int pos = (int)strlen(b->status);
        int rem = (int)sizeof(b->status) - 1 - pos;
        if (rem > 0) {
            strncpy(b->status + pos, tail, (u32)rem);
            b->status[pos + ((int)strlen(tail) < rem ? (int)strlen(tail) : rem)] = 0;
        }
    }
}

/* ---------- навигация ---------- */

/* Разобрать "host" или "host:port" → хост и порт.
 * ЗАДАЧА 53 (ФИКС «https открывает порт 80»): порт ПО УМОЛЧАНИЮ
 * ставит ВЫЗЫВАЮЩИЙ (80 для http, 443 для https) ДО вызова; функция
 * перезаписывает его ТОЛЬКО когда порт указан явно ("host:port").
 * Раньше здесь безусловно было *port = 80 — порт 443 затирался, и
 * net_http_get (TLS = порт 443) шёл plain-текстом на 80. */
static int br_parse_host(char *host, u16 *port)
{
    char *colon = strchr(host, ':');
    if (!colon) return 1;
    *colon = 0;
    u32 p = 0;   /* u32: u16 переполнялся бы ДО проверки > 65535 (-Wtype-limits) */
    for (const char *q = colon + 1; *q; q++) {
        if (*q < '0' || *q > '9') return 0;
        p = p * 10 + (u32)(*q - '0');
        if (p > 65535) return 0;
    }
    if (p == 0) return 0;
    *port = (u16)p;
    return 1;
}

static void br_render_now(browser_t *b)
{
    /* Немедленная отрисовка в canvas своего окна (мы в потоке окна):
     * под rlock — чтобы статус «Запрос...» был виден ДО блокирующего
     * сетевого запроса. Прямой вызов w->draw без rlock гонялся бы
     * с realloc canvas при resize. */
    if (b->win) win_draw_now(b->win);
}

static void br_navigate_ex(browser_t *b, const char *addr, int redirs);

static void br_navigate(browser_t *b, const char *addr)
{
    br_navigate_ex(b, addr, 0);
}

/* Сессия 56: распознать редирект в сыром HTTP-ответе. Заполняет loc
 * (буфер вызывающего) значением заголовка Location и возвращает код
 * статуса (301/302/303/307/308) или 0 (нет редиректа/нет Location).
 * loc может быть относительным — разрешает вызывающий. */
static int br_ci_ncmp(const char *a, const char *b, int n)
{
    for (int i = 0; i < n; i++) {
        char ca = a[i], cb = b[i];
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 1;
    }
    return 0;
}

/* [BR-TLSUP] (сессия 79): код статуса HTTP-ответа (100..599) или 0.
 * Общий парсер для br_parse_redirect и авто-перехода http->https. */
static int br_http_status(const char *resp, int len)
{
    if (!resp || len < 12 || strncmp(resp, "HTTP/", 5) != 0) return 0;
    int i = 5;
    while (i < len && resp[i] == ' ') i++;
    if (i + 3 > len) return 0;
    int code = 0;
    for (int k = 0; k < 3; k++) {
        char c = resp[i + k];
        if (c < '0' || c > '9') return 0;
        code = code * 10 + (c - '0');
    }
    return code;
}

static int br_parse_redirect(const char *resp, int len, int *out_code,
                             char *loc, int loc_max)
{
    if (!resp || !loc || loc_max < 8) return 0;
    int code = br_http_status(resp, len);
    if (code != 301 && code != 302 && code != 303 &&
        code != 307 && code != 308) return 0;

    /* конец заголовков: \r\n\r\n или \n\n (не дальше 2 КиБ) */
    int hdr_end = len;
    for (int p = 0; p < len && p < 2048; p++) {
        if (p + 3 < len && resp[p] == '\r' && resp[p + 1] == '\n' &&
            resp[p + 2] == '\r' && resp[p + 3] == '\n') {
            hdr_end = p; break;
        }
        if (p + 1 < len && resp[p] == '\n' && resp[p + 1] == '\n') {
            hdr_end = p; break;
        }
    }

    /* строка "location: ..." (без учёта регистра) до конца заголовков */
    for (int p = 0; p < hdr_end; ) {
        int eol = p;
        while (eol < hdr_end && resp[eol] != '\n') eol++;
        if (eol - p > 9 && br_ci_ncmp(resp + p, "location:", 9) == 0) {
            const char *v = resp + p + 9;
            const char *ve = resp + eol;
            while (v < ve && (*v == ' ' || *v == '\t')) v++;
            int vl = (int)(ve - v);
            while (vl > 0 && (v[vl - 1] == '\r' || v[vl - 1] == ' '))
                vl--;
            if (vl > 0 && vl < loc_max) {
                memcpy(loc, v, (u32)vl);
                loc[vl] = 0;
                *out_code = code;
                return code;
            }
            return 0;
        }
        p = eol + 1;
    }
    return 0;
}

/* [BR-MP3]: похоже ли это на MP3: расширение .mp3 в пути URL
 * (без регистра, до ?/#), либо контент ID3v2, либо frame sync
 * 0xFFEx (MPEG audio). Достаточно консервативно для ветки плеера. */
static int br_looks_like_mp3(const char *url, const char *body, int len)
{
    if (url) {
        const char *seg = strrchr(url, '/');
        seg = seg ? seg + 1 : url;
        const char *dot = strrchr(seg, '.');
        if (dot) {
            char e[8];
            int n = 0;
            for (const char *t = dot + 1;
                 *t && *t != '?' && *t != '#' && n < 7; t++) {
                char c = *t;
                if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
                e[n++] = c;
            }
            e[n] = 0;
            if (!strcmp(e, "mp3")) return 1;
        }
    }
    if (len >= 3 && body[0] == 'I' && body[1] == 'D' && body[2] == '3')
        return 1;
    if (len >= 2 && (unsigned char)body[0] == 0xFF &&
        ((unsigned char)body[1] & 0xE0) == 0xE0)
        return 1;
    return 0;
}

/* [BR-MP3]: отдать MP3 аудиоплееру (mp3svc/dr_mp3) вместо рендера
 * бинарника в Markdown. Копия сохраняется в RAM disk (Файлы/повтор).
 * payload переходит во владение плеера (app_mp3_open_with сам free).
 * 1 = отдали плееру (страницу не рендерить). */
static int br_hand_mp3_to_player(browser_t *b, const char *url_for_stem,
                                 const char *path, const char *resp, int n)
{
    const char *mbody;
    int mlen;
    br_strip_headers(resp, n, &mbody, &mlen);
    if (mlen < 4096 || !br_looks_like_mp3(path, mbody, mlen))
        return 0;

    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];
    int  have_name = 0;

    br_save_derive_stem(url_for_stem, stem, (int)sizeof(stem));
    if (br_save_free_name_ext(stem, "mp3", name, (int)sizeof(name))) {
        ramfs_delete(name);              /* свободное имя — delete страховка */
        if (ramfs_create(name, (u32)mlen + 1) &&
            ramfs_write(name, mbody, (u32)mlen))
            have_name = 1;
    }

    char *payload = (char *)malloc((u32)mlen);
    if (!payload) {
        snprintf(b->status, sizeof(b->status), "Нет памяти под MP3 (%d КБ)",
                 mlen / 1024);
        return 0;
    }
    memcpy(payload, mbody, (u32)mlen);
    snprintf(b->status, sizeof(b->status), "MP3: %s (%d КБ) — в плеер",
             have_name ? name : "поток", mlen / 1024);
    win_invalidate(b->win);
    app_mp3_open_with(have_name ? name : "", payload, (u32)mlen);
    return 1;
}

/* Полная навигация: GET/POST (Task 47) + javascript:-ссылки.
 * redirs — глубина цепочки редиректов. */
static void br_navigate_full(browser_t *b, const char *addr, int redirs,
                             int is_post, const char *post_body)
{
    char host[128];
    char path[256];
    /* сессия 55: локальная копия без фрагментов (на УРОВНЕ функции:
     * p остаётся валидным до конца функции) */
    char cut[BR_ADDR_MAX + 1];
    /* сессия 67: нормализованное имя файла RAM disk (тоже на уровне
     * функции: p = nm живёт до конца функции) */
    char nm[BR_ADDR_MAX + 1];
    const char *p = addr;

    b->addr_focus = 0;

    /* Пустой ввод — ничего не делать */
    while (*p == ' ') p++;
    if (!*p) {
        win_invalidate(b->win);
        return;
    }

    /* Task 47: javascript:-ссылки исполняются движком страницы
     * (раньше проваливались в ramfs-поиск и получали «Файл не найден»). */
    if (!strncmp(p, "javascript:", 11)) {
        char jsbuf[192];
        strncpy(jsbuf, p + 11, sizeof(jsbuf) - 1);
        jsbuf[sizeof(jsbuf) - 1] = 0;
        int rc = br_js_run_snippet(b, jsbuf);
        if (rc == 0 && b->js.wlen > 0) {
            /* document.write из javascript:-ссылки: страница изменилась */
            br_page_refresh(b);
        }
        win_invalidate(b->win);
        return;
    }

    /* сессия 55: фрагменты #... отбрасываем (якоря не поддержаны) */
    {
        int ci = 0;
        for (const char *q = p; *q && ci < BR_ADDR_MAX; q++) {
            if (*q == '#') break;
            cut[ci++] = *q;
        }
        cut[ci] = 0;
        while (ci > 0 && cut[ci - 1] == ' ') cut[--ci] = 0;
        if (ci == 0) {
            snprintf(b->status, sizeof(b->status), "Внутренний якорь — пропущен");
            win_invalidate(b->win);
            return;
        }
        /* работаем дальше с ЛОКАЛЬНОЙ обрезанной строкой (без алиасинга
         * с b->addr — ниже ветки сами обновляют адресную строку) */
        addr = cut;
        p = cut;
    }

    /* --- ramfs-файл? (нет схемы и не похоже на URL) --- */
    int has_scheme = 0;
    for (const char *q = p; *q; q++) {
        if (q - p > 12) break;
        if (*q == ':' && q[1] == '/' && q[2] == '/') { has_scheme = 1; break; }
    }

    if (!has_scheme) {
        u32 fsize = 0;
        int is_url = 0;
        /* www.foo.bar или foo.ru — похоже на хост без схемы */
        int dots = 0, spaces = 0;
        for (const char *q = p; *q; q++) {
            if (*q == '.') dots++;
            if (*q == ' ') spaces++;
        }
        if (!strncmp(p, "www.", 4) || (dots >= 1 && spaces == 0 &&
             !strchr(p, '/')))
            is_url = 1;

        /* СЕССИЯ 63: голый "localhost" (и "localhost:8080") — тоже URL:
         * без точек раньше шёл в ramfs-поиск и получал «Файл 'localhost'
         * не найден в RAM disk» вместо локального сервера. */
        if (!is_url && !strncmp(p, "localhost", 9) &&
            (p[9] == 0 || p[9] == ':' || p[9] == '/'))
            is_url = 1;

        if (!is_url) {
            /* СЕССИЯ 67: локальные адреса вида "/help.md", "./help.md",
             * "../help.md" (ссылка с абсолютным путём на локальной
             * странице, ручной ввод) — RAM disk хранит имена БЕЗ
             * ведущего '/': нормализуем к имени от корня. */
            const char *q = p;
            int k = 0;
            for (;;) {
                if (*q == '/') q++;
                else if (q[0] == '.' && q[1] == '/') q += 2;
                else if (q[0] == '.' && q[1] == '.' && q[2] == '/') q += 3;
                else break;
            }
            while (*q && k < BR_ADDR_MAX) nm[k++] = *q++;
            nm[k] = 0;
            if (!nm[0]) {
                snprintf(b->status, sizeof(b->status),
                         "Пустое имя файла");
                win_invalidate(b->win);
                return;
            }
            p = nm;
        }

        if (!is_url && ramfs_lookup(p, &fsize)) {
            /* Открываем файл из RAM disk */
            if (fsize == 0 || fsize > BR_FILE_MAX) {
                snprintf(b->status, sizeof(b->status),
                         "Файл %s: %u байт — вне лимита", p, (unsigned)fsize);
                win_invalidate(b->win);
                return;
            }
            char *buf = (char *)malloc(fsize);
            if (!buf) {
                snprintf(b->status, sizeof(b->status), "Нет памяти");
                win_invalidate(b->win);
                return;
            }
            u32 got = ramfs_read(p, buf, fsize);
            if (got == 0) {
                free(buf);
                snprintf(b->status, sizeof(b->status), "Ошибка чтения %s", p);
                win_invalidate(b->win);
                return;
            }
            strncpy(b->addr, p, BR_ADDR_MAX);
            b->addr[BR_ADDR_MAX] = 0;
            b->addr_len = (int)strlen(b->addr);
            browser_load_content(b, p, buf, (int)got);
            free(buf);
            win_invalidate(b->win);
            return;
        }
        if (!is_url) {
            snprintf(b->status, sizeof(b->status),
                     "Файл '%s' не найден в RAM disk", p);
            win_invalidate(b->win);
            return;
        }
        /* is_url: продолжаем как http(s):// */
    }
    else if (strncmp(p, "http://", 7) != 0 && strncmp(p, "https://", 8) != 0) {
        snprintf(b->status, sizeof(b->status),
                 "Схема не поддерживается (http:// или https://)");
        win_invalidate(b->win);
        return;
    }

    /* --- HTTP/HTTPS --- */
    int use_tls = 0;
    if (!strncmp(p, "https://", 8)) { p += 8; use_tls = 1; }
    else if (!strncmp(p, "http://", 7)) p += 7;
    int hi = 0;
    /* [BR-SLASH] (сессия 79): хост обрезаем и на '?': "http://ya.ru?x=1"
     * раньше склеивал query с хостом ("ya.ru?x=1" -> DNS не резолвил). */
    while (*p && *p != '/' && *p != '?' && hi < 127) {
        host[hi++] = *p++;
    }
    host[hi] = 0;
    /* host:port (порт по умолчанию: 443 для https, 80 для http) */
    u16 port = use_tls ? 443 : 80;
    if (!br_parse_host(host, &port)) {
        snprintf(b->status, sizeof(b->status), "Неверный порт в адресе");
        win_invalidate(b->win);
        return;
    }
    /* [BR-SLASH]: путь всегда начинается с '/'. "?query" прямо после
     * хоста -> "/?query"; голый хост -> "/" ("GET  HTTP/1.0" с пустым
     * путём nginx/httpd отвечают 400 — прежняя ветка p="/" это уже
     * закрывала, теперь же и query-вариант не теряется). */
    if (*p == '?') {
        int pl = 0;
        path[pl++] = '/';
        while (*p && pl < 255) path[pl++] = *p++;
        path[pl] = 0;
    } else {
        if (!*p) p = "/";
        strncpy(path, p, 255);
        path[255] = 0;
    }

    if (!host[0]) {
        snprintf(b->status, sizeof(b->status), "Пустой хост");
        win_invalidate(b->win);
        return;
    }

    /* СЕССИЯ 63: loopback ("localhost", 127.x.x.x) работает БЕЗ NIC и
     * без настроенного IP — соединение замыкается внутри стека
     * (net_is_loopback), поэтому проверку сети для него пропускаем:
     * раньше без сети браузер отвечал «Сеть не настроена» даже на
     * 127.0.0.1, хотя локальный httpd доступен. */
    if (!net_host_is_loopback(host) &&
        (!net_nic_present() || net_get_ip() == 0)) {
        snprintf(b->status, sizeof(b->status), "Сеть не настроена");
        win_invalidate(b->win);
        return;
    }

    /* Показываем статус ДО блокирующего запроса (запрос выполняется
     * в потоке ЭТОГО окна — система и остальные окна продолжают жить). */
    b->fetching = 1;
    snprintf(b->status, sizeof(b->status),
             "Запрос %s://%s:%u%s ...", use_tls ? "https" : "http",
             host, (unsigned)port, path);
    br_render_now(b);

    /* сессия 55: история Back — текущая страница уходит в стек
     * (сессия 56: только для переходов С НАЧАЛА цепочки —
     * промежуточные редиректы историю не дублируют) */
    if (redirs == 0 && b->url[0] && strcmp(b->url, addr) != 0 &&
        b->hist_n < BR_HIST_MAX) {
        strncpy(b->hist[b->hist_n], b->url, sizeof(b->hist[0]) - 1);
        b->hist[b->hist_n][sizeof(b->hist[0]) - 1] = 0;
        b->hist_n++;
    }

    char *resp = (char *)malloc(BR_FETCH_MAX);
    if (!resp) {
        b->fetching = 0;
        snprintf(b->status, sizeof(b->status), "Нет памяти под ответ");
        win_invalidate(b->win);
        return;
    }

    int n;
    if (is_post)
        n = net_http_post(host, port, path,
                          post_body ? post_body : "", NULL,
                          resp, BR_FETCH_MAX, 10000);
    else
        n = net_http_get(host, port, path, resp, BR_FETCH_MAX, 10000);
    b->fetching = 0;
    /* [BR-TLSUP] (сессия 79): АВТО-ПЕРЕХОД http -> https. Один повтор
     * на переход (как сессия 58), условия расширены:
     *  (a) сетевой отказ на :80 — "connection refused/reset",
     *      "connect timeout", "response timeout" (сервер молчит),
     *      "пустой ответ" (закрыл соединение, не ответив): типичная
     *      реакция https-only хостов и фильтров plain-HTTP;
     *  (b) сервер ОТВЕТИЛ на plain http кодом 400/403/426 — сайт
     *      жив, но работает только по TLS (nginx: "The plain HTTP
     *      request was sent to HTTPS port" = 400; Cloudflare-заглушки
     *      часто 403; RFC 2817: 426 Upgrade Required);
     *  (c) 301/302/303/307/308 с Location: https://... следуются и
     *     так (сессия 56, br_parse_redirect) — отдельного кода не нужно.
     * Обратное понижение https -> http НЕ делается. Loopback не
     * переключаем (локальный httpd говорит только plain HTTP). */
    if (!use_tls && redirs < 4 && !net_host_is_loopback(host)) {
        int try_https = 0;
        char why[56] = "";
        if (n <= 0) {
            const char *why0 = net_http_errstr();
            if (strncmp(why0, "connection", 10) == 0 ||      /* refused/reset */
                strncmp(why0, "connect timeout", 15) == 0 ||
                strncmp(why0, "response timeout", 16) == 0 ||
                strncmp(why0, "пустой ответ", strlen("пустой ответ")) == 0) {
                try_https = 1;
                strncpy(why, why0, sizeof(why) - 1);
                why[sizeof(why) - 1] = 0;
            }
        } else {
            int code = br_http_status(resp, n);
            if (code == 400 || code == 403 || code == 426) {
                try_https = 1;
                snprintf(why, sizeof(why), "HTTP %d — plain отвергнут", code);
            }
        }
        if (try_https) {
            snprintf(b->status, sizeof(b->status),
                     "HTTP: %s — пробую HTTPS...", why);
            b->fetching = 1;
            br_render_now(b);
            use_tls = 1;
            port = 443;
            if (is_post)
                n = net_http_post(host, port, path,
                                  post_body ? post_body : "", NULL,
                                  resp, BR_FETCH_MAX, 10000);
            else
                n = net_http_get(host, port, path, resp, BR_FETCH_MAX, 10000);
            b->fetching = 0;
        }
    }
    if (n > 0) {
        /* сессия 56: редиректы 301/302/303/307/308. ya.ru и большинство
         * крупных сайтов отвечают 302 (часто на https:// или
         * canonical-хост) — раньше пользователь видел сырые заголовки
         * вместо страницы. Следуем до 4 раз, Location абсолютный и
         * относительный. */
        if (redirs < 4) {
            int code = 0;
            char loc[300];
            if (br_parse_redirect(resp, n, &code, loc, (int)sizeof(loc))) {
                char base[168], abs[300];
                snprintf(base, sizeof(base), "%s://%s:%u%s",
                         use_tls ? "https" : "http", host, (unsigned)port,
                         path);
                img_url_resolve(base, loc, abs, (int)sizeof(abs));
                snprintf(b->status, sizeof(b->status),
                         "Редирект %d -> %.46s", code, abs);
                free(resp);
                br_navigate_ex(b, abs, redirs + 1);
                return;
            }
        }
        const char *scheme = use_tls ? "https" : "http";
        snprintf(b->addr, sizeof(b->addr), "%s://%s:%u%s", scheme,
                 host, (unsigned)port, path);
        b->addr[sizeof(b->addr) - 1] = 0;
        b->addr_len = (int)strlen(b->addr);
        char full[168];
        snprintf(full, sizeof(full), "%s://%s:%u%s", scheme,
                 host, (unsigned)port, path);
        /* [BR-MP3]: MP3-ссылка — сразу в аудиоплеер (не рендерим) */
        if (!is_post && br_hand_mp3_to_player(b, full, path, resp, n)) {
            free(resp);
            win_invalidate(b->win);
            return;
        }
        browser_load_content(b, full, resp, n);
    } else {
        /* FIX [N1d]: показываем причину сбоя (connect timeout /
         * connection refused / no ARP / resolve) вместо безликого кода */
        snprintf(b->status, sizeof(b->status),
                 "Ошибка: %s (HTTP Trace покажет детали)", net_http_errstr());
    }
    free(resp);

    /* сессия 55: картинки страницы (тот же поток, что и страница) */
    if (b->imgs_pending)
        br_load_images(b);

    win_invalidate(b->win);
}

static void br_navigate_ex(browser_t *b, const char *addr, int redirs)
{
    br_navigate_full(b, addr, redirs, 0, NULL);
}

/* Task 47: POST-навигация (отправка форм). */
static void br_navigate_post(browser_t *b, const char *addr, const char *body)
{
    br_navigate_full(b, addr, 0, 1, body);
}

/* Назад (сессия 55): возврат по истории. Backspace/кнопка Back. */
static void br_go_back(browser_t *b)
{
    char prev[128];
    if (b->hist_n == 0) {
        snprintf(b->status, sizeof(b->status), "История пуста");
        win_invalidate(b->win);
        return;
    }
    b->hist_n--;
    strncpy(prev, b->hist[b->hist_n], sizeof(prev) - 1);
    prev[sizeof(prev) - 1] = 0;
    br_navigate(b, prev);
}

/* ---------- сохранение страницы на RAM disk (сессия 67) ---------- */

/* Имя файла для сохранения из адреса страницы:
 *   "http://host:80/dir/page.html" -> "page"  (расширение добавит
 * br_save_free_name: ".md" — страница уже конвертирована в Markdown);
 *   "https://ya.ru/"               -> "page";
 *   "docs/page.md"                 -> "page.md";
 *   "notes.txt"                    -> "notes.txt" (текст сохраняется
 *                                     как есть, расширение честное).
 * Схема/host:port отрезаются (берётся последний сегмент пути),
 * не-[A-Za-z0-9._-] -> '_'. Стеб ограничен RAMFS_NAME_MAX-8 — запас
 * под суффикс "_NN.md". */
static void br_save_derive_stem(const char *url, char *out, int out_max)
{
    char stem[RAMFS_NAME_MAX + 1];
    int n = 0;
    const char *p = url ? url : "";

    const char *sch = strstr(p, "://");
    if (sch) p = sch + 3;
    const char *last = strrchr(p, '/');
    if (last) p = last + 1;

    for (; *p; p++) {
        char c = *p;
        if (c == '?' || c == '#' || c == '/') break;
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
              (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-'))
            c = '_';
        if (n < (int)sizeof(stem) - 1) stem[n++] = c;
    }
    stem[n] = 0;

    /* адрес без имени ("http://host:80/", "dir/") — базовое имя */
    if (!stem[0] || !strcmp(stem, ".") || !strcmp(stem, ".."))
        strcpy(stem, "page");

    /* расширение: .html/.htm убираем (контент уже Markdown), .md и
     * прочие честные расширения сохраняем, без расширения — добавит
     * br_save_free_name */
    {
        char *dot = strrchr(stem, '.');
        if (dot && dot != stem) {
            char e[8];
            int el = 0;
            for (const char *q = dot + 1; *q && el < 7; q++) {
                char lc = *q;
                if (lc >= 'A' && lc <= 'Z') lc += 32;
                e[el++] = lc;
            }
            e[el] = 0;
            if (!strcmp(e, "htm") || !strcmp(e, "html"))
                *dot = 0;                     /* .html/.htm -> стеб */
            /* .md/.txt/... — оставляем как есть */
        }
    }

    /* запас под суффикс "_NN.md" */
    if ((int)strlen(stem) > RAMFS_NAME_MAX - 8)
        stem[RAMFS_NAME_MAX - 8] = 0;
    strncpy(out, stem, (u32)out_max - 1);
    out[out_max - 1] = 0;
}

/* Свободное имя: "stem.md" (или стем с его расширением), затем
 * "stem_2.md"... "stem_99.md". Возвращает 1 при успехе. */
static int br_save_free_name(const char *stem, char *out, int out_max)
{
    char cand[RAMFS_NAME_MAX + 8];

    /* у стема может быть своё расширение (.md/.txt) — тогда "stem.md"
     * не добавляем второе: расширение уже есть */
    const char *dot = strrchr(stem, '.');
    if (dot && dot != stem) {
        snprintf(cand, sizeof(cand), "%s", stem);
    } else {
        snprintf(cand, sizeof(cand), "%s.md", stem);
    }
    if (!ramfs_lookup(cand, NULL)) {
        strncpy(out, cand, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return 1;
    }
    for (int k = 2; k < 100; k++) {
        snprintf(cand, sizeof(cand), "%s_%d.md", stem, k);
        if (!ramfs_lookup(cand, NULL)) {
            strncpy(out, cand, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return 1;
        }
    }
    return 0;
}

/* Свободное имя с ЗАДАННЫМ расширением: "stem.ext" (или стем с его
 * собственным расширением), затем "stem_2.ext"... Возвращает 1. */
static int br_save_free_name_ext(const char *stem, const char *ext,
                                 char *out, int out_max)
{
    char cand[RAMFS_NAME_MAX + 8];

    /* у стема может быть своё расширение — второе не добавляем */
    const char *dot = strrchr(stem, '.');
    if (dot && dot != stem) {
        snprintf(cand, sizeof(cand), "%s", stem);
    } else {
        snprintf(cand, sizeof(cand), "%s.%s", stem, ext);
    }
    if (!ramfs_lookup(cand, NULL)) {
        strncpy(out, cand, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return 1;
    }
    for (int k = 2; k < 100; k++) {
        snprintf(cand, sizeof(cand), "%s_%d.%s", stem, k, ext);
        if (!ramfs_lookup(cand, NULL)) {
            strncpy(out, cand, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return 1;
        }
    }
    return 0;
}

/* Сохранить текущую страницу в RAM disk.
 * Task 51 [BR-SAVE]: для HTML-страниц сохраняется ИСХОДНИК (b->src —
 * он же потом честно открывается браузером снова: комментарии, скрипты
 * и кнопки на месте). Раньше писался только Markdown после конвертации,
 * и пользователь не находил в сохранённом файле ни скриптов, ни
 * комментариев, ни кнопок. Для текстовых/Markdown страниц исходника
 * нет — сохраняется текст страницы (как прежде).
 * Существующие файлы НЕ перезаписываются (подбирается свободное имя). */
static void br_save_page(browser_t *b)
{
    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];

    if ((!b->md || b->md_len <= 0) &&
        (!(b->src && b->src_len > 0))) {
        snprintf(b->status, sizeof(b->status), "Нечего сохранять");
        win_invalidate(b->win);
        return;
    }
    br_save_derive_stem(b->url, stem, (int)sizeof(stem));

    if (b->src && b->src_len > 0) {
        /* --- исходник HTML --- */
        if (!br_save_free_name_ext(stem, "html", name, (int)sizeof(name))) {
            snprintf(b->status, sizeof(b->status), "Нет свободного имени");
            win_invalidate(b->win);
            return;
        }
        ramfs_delete(name);
        if (!ramfs_create(name, (u32)b->src_len + 1) ||
            !ramfs_write(name, b->src, (u32)b->src_len + 1)) {
            snprintf(b->status, sizeof(b->status),
                     "Ошибка записи RAM disk");
            win_invalidate(b->win);
            return;
        }
        snprintf(b->status, sizeof(b->status),
                 "Сохранён исходник: %s (%d байт)", name, b->src_len + 1);
        win_invalidate(b->win);
        return;
    }

    /* --- Markdown/текст (как раньше) --- */
    if (!br_save_free_name(stem, name, (int)sizeof(name))) {
        snprintf(b->status, sizeof(b->status), "Нет свободного имени");
        win_invalidate(b->win);
        return;
    }
    ramfs_delete(name);              /* свободное имя — delete страховка */
    if (!ramfs_create(name, (u32)b->md_len + 1) ||
        !ramfs_write(name, b->md, (u32)b->md_len + 1)) {
        snprintf(b->status, sizeof(b->status),
                 "Ошибка записи RAM disk");
        win_invalidate(b->win);
        return;
    }
    snprintf(b->status, sizeof(b->status), "Сохранено: %s (%d байт)",
             name, b->md_len + 1);
    win_invalidate(b->win);
}

/* ---------- рендеринг ---------- */

/* Сессия 56: строка отображения с ПОДСВЕТКОЙ ССЫЛОК. Ссылка — интервал
 * видимого текста [b_abs, t_end_abs) исходной строки (brpage.h: разметка
 * [T](U) вырезана из md). Кусок отображения покрывает байты
 * [line_base+srcoff, ...+plen) — пересечения рисуем синим с
 * подчёркиванием, остальное — цветом класса строки.
 * Раньше вся строка рисовалась одной fb_text с разметкой на экране:
 * пользователь видел [example.com](http://example.com/). */
#define BR_SEGS_MAX 12
#define BR_SEG_BUF  512
/* (форвард: определение — в разделе ввода, ниже) */
static void br_sel_norm(browser_t *b, int *r0, int *c0, int *r1, int *c1);

static void br_draw_text_line(browser_t *b, int i, int y, u32 color)
{
    const char *piece = b->L.lines[i];
    int plen = (int)strlen(piece);
    if (plen == 0) return;

    if (b->page.nlinks == 0 || b->page.line_off == NULL ||
        !b->L.srcidx || !b->L.srcoff ||
        b->L.srcidx[i] < 0 || b->L.srcidx[i] >= b->page.nlines) {
        fb_text(4, y, piece, color, -1);
        return;
    }
    int srcidx = b->L.srcidx[i];
    int piece_abs0 = b->page.line_off[srcidx] + b->L.srcoff[i];

    brp_seg_t segs[BR_SEGS_MAX];
    int ns = brp_link_segs(&b->page, srcidx, piece_abs0, piece, plen,
                           segs, BR_SEGS_MAX);
    if (ns == 0) {
        fb_text(4, y, piece, color, -1);
        return;
    }

    u32 link_col = wm_theme_accent();
    int total = utf8_count_chars(piece, -1);
    int col_prev = 0;
    int x = 4;
    char buf[BR_SEG_BUF];
    for (int s = 0; s <= ns && col_prev < total; s++) {
        int col_a = (s < ns) ? segs[s].col0 : total;
        int col_b = (s < ns) ? segs[s].col1 : col_a;
        if (col_a > total) col_a = total;
        if (col_b > total) col_b = total;
        /* обычный кусок [col_prev, col_a) */
        if (col_a > col_prev) {
            int b0 = brp_byte_of_col(piece, plen, col_prev);
            int b1 = brp_byte_of_col(piece, plen, col_a);
            int nb = b1 - b0;
            if (nb > (int)sizeof(buf) - 1) nb = (int)sizeof(buf) - 1;
            if (nb > 0) {
                memcpy(buf, piece + b0, (u32)nb);
                buf[nb] = 0;
                fb_text(x, y, buf, color, -1);
            }
            x += (col_a - col_prev) * 8;
            col_prev = col_a;
        }
        /* текст ссылки [col_a, col_b) — синий + подчёркивание */
        if (s < ns && col_b > col_prev) {
            int b0 = brp_byte_of_col(piece, plen, col_prev);
            int b1 = brp_byte_of_col(piece, plen, col_b);
            int nb = b1 - b0;
            if (nb > (int)sizeof(buf) - 1) nb = (int)sizeof(buf) - 1;
            if (nb > 0) {
                memcpy(buf, piece + b0, (u32)nb);
                buf[nb] = 0;
                fb_text(x, y, buf, link_col, -1);
            }
            fb_hline(x, x + (col_b - col_prev) * 8 - 1, y + 14, link_col);
            x += (col_b - col_prev) * 8;
            col_prev = col_b;
        }
    }
}

/* ---------- Task 47: отрисовка контролов форм ---------- */

static int br_field_box_w(int avail_px)
{
    int w = avail_px - 4;
    if (w > 26 * 8) w = 26 * 8;
    if (w < 10 * 8) w = 10 * 8;
    return w;
}

static void br_draw_field(browser_t *b, brf_field_t *fl, int y, int cw)
{
    u32 txt = wm_theme_text();
    u32 dim = wm_theme_text_dim();
    int focused = (b->focus >= 0 && &b->forms.fields[b->focus] == fl);
    char shown[132];

    if (!strcmp(fl->type, "text") || !strcmp(fl->type, "password") ||
        !strcmp(fl->type, "search") || !strcmp(fl->type, "textarea")) {
        char lab[24];
        snprintf(lab, sizeof(lab), "%s:",
                 fl->name[0] ? fl->name : "поле");
        fb_text(4, y + 1, lab, dim, -1);
        int lx = 4 + (int)strlen(lab) * 8 + 4;
        int bw2 = br_field_box_w(cw - lx);
        fb_fill_rect(lx, y + 1, bw2, 14,
                     focused ? wm_theme_win_bg_alt()
                             : fb_rgb(0x1E, 0x24, 0x2C));
        fb_rect(lx, y + 1, bw2, 14,
                focused ? wm_theme_accent() : fb_rgb(0x34, 0x3A, 0x42));
        /* содержимое: пароль звёздами; пустое — placeholder */
        const char *val = fl->value;
        if (!strcmp(fl->type, "password") && val[0]) {
            int vl = (int)strlen(val);
            if (vl > 22) vl = 22;
            for (int i = 0; i < vl; i++) shown[i] = '*';
            shown[vl] = 0;
            val = shown;
        } else if (!val[0] && fl->ph[0]) {
            val = fl->ph;
            txt = dim;
        }
        /* показываем ХВОСТ значения (курсор всегда в конце) */
        int maxc = (bw2 - 10) / 8;
        int total = utf8_count_chars(val, -1);
        int keep = focused ? (maxc - 1) : maxc;
        int from = 0;
        if (total > keep)
            from = utf8_take_bytes(val, -1, total - keep);
        strncpy(shown, val + from, sizeof(shown) - 2);
        shown[sizeof(shown) - 2] = 0;
        if (focused && wm_blink()) {
            /* strcat во freestanding нет (string.h без strcat); запас 1
             * байт гарантирован ограничением sizeof-2 выше */
            size_t sl = strlen(shown);
            shown[sl] = '_';
            shown[sl + 1] = 0;
        }
        fb_text(lx + 4, y + 1, shown, txt, -1);
    } else if (!strcmp(fl->type, "checkbox") ||
               !strcmp(fl->type, "radio")) {
        snprintf(shown, sizeof(shown), "%s%c %s",
                 fl->type[0] == 'c' ? "[" : "(",
                 fl->checked ? 'x' : ' ',
                 fl->label[0] ? fl->label
                              : (fl->name[0] ? fl->name : "выбор"));
        if (focused)
            fb_rect(2, y, utf8_count_chars(shown, -1) * 8 + 8, 15,
                    wm_theme_accent());
        fb_text(6, y + 1, shown,
                fl->checked ? wm_theme_accent() : txt, -1);
    } else if (!strcmp(fl->type, "select")) {
        char lab[24];
        snprintf(lab, sizeof(lab), "%s:",
                 fl->name[0] ? fl->name : "список");
        fb_text(4, y + 1, lab, dim, -1);
        int lx = 4 + (int)strlen(lab) * 8 + 4;
        int bw2 = br_field_box_w(cw - lx);
        fb_fill_rect(lx, y + 1, bw2, 14, fb_rgb(0x1E, 0x24, 0x2C));
        fb_rect(lx, y + 1, bw2, 14,
                focused ? wm_theme_accent() : fb_rgb(0x34, 0x3A, 0x42));
        const char *cur = (fl->opt_sel >= 0 && fl->opt_sel < fl->nopts)
                              ? fl->opts[fl->opt_sel] : "(не выбран)";
        int maxc = (bw2 - 20) / 8;
        int total = utf8_count_chars(cur, -1);
        int from = 0;
        if (total > maxc)
            from = utf8_take_bytes(cur, -1, total - maxc);
        strncpy(shown, cur + from, sizeof(shown) - 3);
        shown[sizeof(shown) - 3] = 0;
        /* strcat во freestanding нет; запас 2 байта гарантирован
         * ограничением sizeof-3 выше */
        {
            size_t sl = strlen(shown);
            shown[sl] = ' ';
            shown[sl + 1] = 'v';
            shown[sl + 2] = 0;
        }
        fb_text(lx + 4, y + 1, shown, txt, -1);
    } else if (!strcmp(fl->type, "submit") || !strcmp(fl->type, "button") ||
               !strcmp(fl->type, "reset")) {
        const char *lab2 =
            fl->label[0] ? fl->label
                         : (fl->value[0] ? fl->value
                         : (!strcmp(fl->type, "submit") ? "Отправить"
                                                        : fl->name));
        int bw2 = utf8_count_chars(lab2, -1) * 8 + 16;
        if (bw2 < 64) bw2 = 64;
        if (bw2 > cw - 16) bw2 = cw - 16;
        fb_fill_rect(4, y + 1, bw2, 14, wm_theme_sel_bg());
        fb_rect(4, y + 1, bw2, 14,
                focused ? wm_theme_accent() : fb_rgb(0x2C, 0x31, 0x38));
        fb_text(4 + (bw2 - utf8_count_chars(lab2, -1) * 8) / 2, y + 1,
                lab2, focused ? wm_theme_accent() : txt, -1);
    }
}

static void br_draw(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* --- адресная строка (BR_HDR пикселей сверху) --- */
    fb_fill_rect(0, 0, cw, BR_HDR, fb_rgb(0x16, 0x1C, 0x24));
    fb_hline(0, cw - 1, BR_HDR - 1, fb_rgb(0x2C, 0x31, 0x38));

    /* поле ввода (сессия 67: правее три кнопки — Back/Save/Go по 44px) */
    int box_x = 4, box_y = 3, box_w = cw - 152, box_h = 16;
    if (box_w < 40) box_w = 40;
    fb_fill_rect(box_x, box_y, box_w, box_h,
                 b->addr_focus ? wm_theme_win_bg() : fb_rgb(0x1E, 0x24, 0x2C));
    fb_rect(box_x, box_y, box_w, box_h,
            b->addr_focus ? wm_theme_accent() : fb_rgb(0x34, 0x3A, 0x42));

    char shown[BR_ADDR_MAX * 2 + 2];   /* x2 — UTF-8: до 2 байт на символ */
    int max_chars = (box_w - 12) / 8;
    if (max_chars < 4) max_chars = 4;
    if (max_chars > BR_ADDR_MAX) max_chars = BR_ADDR_MAX;

    const char *src = b->addr_focus ? b->addr : (b->addr[0] ? b->addr : b->url);
    int sl = (int)strlen(src);
    int total = utf8_count_chars(src, -1);
    /* показываем ХВОСТ адреса (FIX: отрезаем по СИМВОЛАМ, не по байтам —
    * раньше кириллица могла разрезаться посередине) */
    int from = 0;
    if (total > max_chars) from = utf8_take_bytes(src, -1, total - max_chars);
    int tl = sl - from;
    if (tl < 0) tl = 0;
    memcpy(shown, src + from, (u32)tl);
    shown[tl] = 0;
    if (b->addr_focus && wm_blink()) {
        shown[tl] = '_';
        shown[tl + 1] = 0;
    }
    fb_text(box_x + 6, box_y + 1, shown,
            b->addr_focus ? wm_theme_text() : wm_theme_text_dim(), -1);

    if (!b->addr_focus && !b->addr[0] && !b->url[0])
        fb_text(box_x + 6, box_y + 1, "http://... или имя файла RAM disk",
                fb_rgb(0x50, 0x58, 0x62), -1);

    /* кнопки Go, Save (сессия 67) и Back (сессия 55) */
    int go_x = cw - 48, go_y = 3, go_w = 44, go_h = 16;
    int sv_x = cw - 96, sv_w = 44;
    int bk_x = cw - 144, bk_w = 44;
    fb_fill_rect(go_x, go_y, go_w, go_h, wm_theme_sel_bg());
    fb_rect(go_x, go_y, go_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(go_x + (go_w - 2 * 8) / 2, go_y + 1, "Go",
            wm_theme_text(), -1);
    fb_fill_rect(sv_x, go_y, sv_w, go_h, wm_theme_sel_bg());
    fb_rect(sv_x, go_y, sv_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(sv_x + (sv_w - 4 * 8) / 2, go_y + 1, "Save",
            wm_theme_text(), -1);
    fb_fill_rect(bk_x, go_y, bk_w, go_h,
                 b->hist_n > 0 ? wm_theme_sel_bg() : fb_rgb(0x24, 0x2A, 0x32));
    fb_rect(bk_x, go_y, bk_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(bk_x + (bk_w - 4 * 8) / 2, go_y + 1, "Back",
            b->hist_n > 0 ? wm_theme_text() : wm_theme_text_dim(), -1);

    /* --- контент --- */
    int area_y = BR_HDR;
    int area_h = ch - BR_HDR - BR_STATUS_H;
    int vis = area_h / 16;
    if (vis < 1) vis = 1;

    fb_fill_rect(0, area_y, cw, area_h, wm_theme_win_bg());

    /* FIX (аудит): перенос строк по СИМВОЛАМ под текущую ширину окна
     * (при изменении размеров окно перестраивается автоматически) */
    br_ensure_lines(b, cw);

    int max_scroll = b->L.nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (b->scroll > max_scroll) b->scroll = max_scroll;
    if (b->scroll < 0) b->scroll = 0;

    int start = b->scroll;
    int end = start + vis;
    if (end > b->L.nlines) end = b->L.nlines;

    /* --- сессия 55: картинки рисуем ДО текста (они занимают свои
     * строки; текст на них не пишется, т.к. класс BRL_CLS_IMG
     * пропускается ниже) --- */
    int area_y2 = area_y + 2;
    int area_bot = area_y + area_h;
    for (int i = 0; i < b->page.nimgs; i++) {
        brp_img_t *im = &b->page.imgs[i];
        if (im->state != 1 || !im->rgba || im->dw <= 0 || im->dh <= 0)
            continue;
        int y_top = area_y2 + (im->row - start) * 16;
        int y_bot = y_top + im->dh;
        if (y_bot <= area_y2 || y_top >= area_bot) continue;  /* вне экрана */
        int dy = y_top > area_y2 ? y_top : area_y2;
        int src_y = dy - y_top;
        int h_vis = y_bot - dy;
        if (h_vis > area_bot - dy) h_vis = area_bot - dy;
        if (h_vis <= 0) continue;
        int x = (cw - im->dw) / 2;
        if (x < 2) x = 2;
        /* 1:1 blit видимой части (сдвиг источника при прокрутке) */
        fb_blit_rgba(im->rgba + (u32)src_y * (u32)im->dw * 4,
                     im->dw, h_vis, x, dy, im->dw, h_vis);
    }

    /* нормализованное выделение (один раз на кадр) для подсветки */
    int sr0 = 0, sc0 = 0, sr1 = -1, sc1 = 0;
    if (b->sel_active) br_sel_norm(b, &sr0, &sc0, &sr1, &sc1);

    int y = area_y + 2;
    for (int i = start; i < end; i++, y += 16) {
        u32 color = wm_theme_text();
        /* FIX (сессия 19): цвет по КЛАССУ строки отображения (brlines.h):
         * куски-продолжения переносной строки наследуют класс исходной,
         * поэтому длинный заголовок/пункт списка цветной ЦЕЛИКОМ —
         * раньше по первому символу куска цвет имели только первая
         * часть строки и следующий пункт, середина оставалась белой. */
        unsigned char cls = b->L.cls ? b->L.cls[i]
                                     : (b->L.lines[i][0] == '#' ? BRL_CLS_HEAD :
                                        b->L.lines[i][0] == '[' ? BRL_CLS_LINK :
                                        b->L.lines[i][0] == '-' ? BRL_CLS_LIST :
                                        BRL_CLS_TEXT);
        if (cls == BRL_CLS_HEAD)      color = fb_rgb(0xFF, 0xE0, 0x60); /* заголовки */
        else if (cls == BRL_CLS_LINK) color = wm_theme_accent();        /* ссылки */
        else if (cls == BRL_CLS_LIST) color = wm_theme_text_dim();      /* списки */

        /* сессия 55: строки картинок — не текст; якорная строка
         * (BRP_IMG_MARK) неутверждённой картинки показывает заглушку */
        if (cls == BRL_CLS_IMG) {
            const char *ls = b->L.lines[i];
            if (ls[0] == BRP_IMG_MARK && ls[1] == 0) {
                brp_img_t *im = br_img_by_src(b, b->L.srcidx[i]);
                if (im && im->state == 1) {
                    /* картинка нарисована выше — текст не пишем */
                } else if (im && im->state == 0) {
                    fb_text(4, y, "(картинка: загрузка...)",
                            wm_theme_text_dim(), -1);
                } else {
                    fb_text(4, y, "[картинка недоступна]",
                            fb_rgb(0x88, 0x70, 0x70), -1);
                }
            }
            continue;
        }

        /* строки уже перенесены по ширине окна (br_ensure_lines);
         * UTF-8 внутри строки не разрезан. Ссылочные интервалы —
         * синим с подчёркиванием (сессия 56). */
        /* Task 47: строка-якорь поля формы — рисуем контрол */
        if (b->L.lines[i][0] == BRF_MARK && b->L.lines[i][1] == 0) {
            brf_field_t *fl = br_field_by_row(b, i);
            if (fl)
                br_draw_field(b, fl, y, cw);
            continue;
        }

        /* подсветка выделенной части строки (ПОД текстом): колонки в
         * СИМВОЛАХ, x = 4 + col*8 — та же арифметика, что в hit-тесте */
        if (i >= sr0 && i <= sr1) {
            const char *ls = b->L.lines[i];
            int nc = utf8_count_chars(ls, -1);
            int a = (i == sr0) ? sc0 : 0;
            int z = (i == sr1) ? sc1 : nc;
            if (a < 0) a = 0;
            if (z > nc) z = nc;
            if (z > a)
                fb_fill_rect(4 + a * 8, y, (z - a) * 8, 16,
                             wm_theme_sel_bg());
        }
        br_draw_text_line(b, i, y, color);
    }

    /* полоса прокрутки — общий виджет wm_scrollbar (цвет из темы).
     * ПОРЯДОК ПОНЯТЕН: pos=0 — начало текста (ползунок сверху) */
    wm_scrollbar_draw(&b->sb, cw - 7, area_y + 2, 5, area_h - 4,
                      b->scroll, max_scroll, vis);

    /* --- статус-бар --- */
    fb_fill_rect(0, ch - BR_STATUS_H, cw, BR_STATUS_H, wm_theme_win_bg_alt());
    char st[112];
    if (b->hover[0])
        snprintf(st, sizeof(st), "ссылка: %s", b->hover);
    else
        snprintf(st, sizeof(st), "%s%s | прокрутка: %d/%d",
                 b->fetching ? "* " : "", b->status, b->scroll, max_scroll);
    fb_text(4, ch - BR_STATUS_H + 2, st, wm_theme_text_info(), -1);
}

/* ---------- ввод ---------- */

/* ---------- выделение и копирование (общий буфер, clipboard.h) ---------- */

/* Нормализованный диапазон выделения (r0<=r1; при равенстве c0<=c1),
 * границы clamp'ятся к числу строк/символов (строки могли перестроиться
 * при переносе под новую ширину окна). */
static void br_sel_norm(browser_t *b, int *r0, int *c0, int *r1, int *c1)
{
    int ar = b->sel_ar, ac = b->sel_ac, zr = b->sel_br, zc = b->sel_bc;
    if (b->L.nlines <= 0) { *r0 = *r1 = *c0 = *c1 = 0; return; }
    if (ar < 0) ar = 0;
    if (ar >= b->L.nlines) ar = b->L.nlines - 1;
    if (zr < 0) zr = 0;
    if (zr >= b->L.nlines) zr = b->L.nlines - 1;
    int na = utf8_count_chars(b->L.lines[ar], -1);
    int nz = utf8_count_chars(b->L.lines[zr], -1);
    if (ac < 0) ac = 0;
    if (ac > na) ac = na;
    if (zc < 0) zc = 0;
    if (zc > nz) zc = nz;
    if (ar < zr || (ar == zr && ac <= zc)) {
        *r0 = ar; *c0 = ac; *r1 = zr; *c1 = zc;
    } else {
        *r0 = zr; *c0 = zc; *r1 = ar; *c1 = ac;
    }
}

/* Скопировать выделенный текст в общий буфер обмена (строки — через
 * '\n'; пустое выделение — ничего). Статус — сколько скопировано. */
static void br_sel_copy(browser_t *b)
{
    if (!b->sel_active || !b->L.lines) return;
    int r0, c0, r1, c1;
    br_sel_norm(b, &r0, &c0, &r1, &c1);

    int total = 0;
    for (int r = r0; r <= r1; r++) {
        const char *ls = b->L.lines[r];
        int nc = utf8_count_chars(ls, -1);
        int a = (r == r0) ? c0 : 0;
        int z = (r == r1) ? c1 : nc;
        if (a < 0) a = 0;
        if (z > nc) z = nc;
        if (z > a)
            total += utf8_take_bytes(ls, -1, z) - utf8_take_bytes(ls, -1, a);
        if (r < r1) total++;
    }
    if (total <= 0) return;

    char *buf = (char *)malloc((u32)total + 1);
    if (!buf) return;
    char *p = buf;
    for (int r = r0; r <= r1; r++) {
        const char *ls = b->L.lines[r];
        int nc = utf8_count_chars(ls, -1);
        int a = (r == r0) ? c0 : 0;
        int z = (r == r1) ? c1 : nc;
        if (a < 0) a = 0;
        if (z > nc) z = nc;
        if (z > a) {
            int b0 = utf8_take_bytes(ls, -1, a);
            int b1 = utf8_take_bytes(ls, -1, z);
            memcpy(p, ls + b0, (u32)(b1 - b0));
            p += b1 - b0;
        }
        if (r < r1) *p++ = '\n';
    }
    *p = 0;
    clip_text_set(buf, total);
    free(buf);
    snprintf(b->status, sizeof(b->status),
             "Скопировано %d симв. (Ctrl+V — в редактор)", total);
}

static void br_key(window_t *w, const key_event_t *ev)
{
    browser_t *b = (browser_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* Ctrl+S — сохранить страницу в RAM disk (сессия 67) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 's' || ev->ch == 'S' || ev->ch == 0x13)) {
        br_save_page(b);
        return;
    }

    /* Ctrl+L — фокус на адресную строку (как в больших браузерах) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'l' || ev->ch == 'L' || ev->ch == 0x0C)) {
        b->addr_focus = 1;
        win_invalidate(w);
        return;
    }

    /* Ctrl+C — скопировать выделенный текст (буфер общий с редактором;
    * вставка — Ctrl+V в редакторе). Только вне режима адреса. */
    if ((ev->flags & KF_CTRL) && !b->addr_focus &&
        (ev->ch == 'c' || ev->ch == 'C' || ev->code == 0x2E)) {
        br_sel_copy(b);
        win_invalidate(w);
        return;
    }

    /* ---- Task 47: редактирование поля формы ---- */
    if (b->focus >= 0 && b->focus < b->forms.nfields) {
        brf_field_t *fl = &b->forms.fields[b->focus];
        if (ev->code == 0x0F) {                       /* Tab — следующее поле */
            int k = b->focus;
            for (int step = 0; step < b->forms.nfields; step++) {
                k = (k + 1) % b->forms.nfields;
                if (strcmp(b->forms.fields[k].type, "hidden") != 0)
                    break;
            }
            b->focus = k;
            win_invalidate(w);
            return;
        }
        if (ev->ch == 0x1B || ev->code == 0x01) {     /* Esc — снять фокус */
            b->focus = -1;
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x0E) {                       /* Backspace */
            int vl = (int)strlen(fl->value);
            if (vl > 0) {
                int cut = 1;
                while (cut < vl &&
                       (unsigned char)fl->value[vl - cut] >= 0x80 &&
                       (unsigned char)fl->value[vl - cut] < 0xC0)
                    cut++;                            /* целый символ UTF-8 */
                fl->value[vl - cut] = 0;
                win_invalidate(w);
            }
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n') {     /* Enter */
            if (!strcmp(fl->type, "textarea")) {
                int vl = (int)strlen(fl->value);
                if (vl < BRF_VAL_MAX - 1) {
                    fl->value[vl++] = '\n';
                    fl->value[vl] = 0;
                    win_invalidate(w);
                }
            } else if (!strcmp(fl->type, "text") ||
                       !strcmp(fl->type, "password") ||
                       !strcmp(fl->type, "search")) {
                br_form_submit(b, fl->form);          /* как в больших браузерах */
            } else {
                br_field_activate(b, fl);
            }
            return;
        }
        if (ev->code == 0x39 && !(ev->flags & KF_CTRL)) {   /* Space */
            if (strcmp(fl->type, "text") != 0 &&
                strcmp(fl->type, "password") != 0 &&
                strcmp(fl->type, "search") != 0 &&
                strcmp(fl->type, "textarea") != 0) {
                br_field_activate(b, fl);
                win_invalidate(w);
                return;
            }
        }
        if (ev->ch >= 0x20 && ev->ch < 0x7F && !(ev->flags & KF_CTRL)) {
            if (!strcmp(fl->type, "text") || !strcmp(fl->type, "password") ||
                !strcmp(fl->type, "search") || !strcmp(fl->type, "textarea")) {
                int vl = (int)strlen(fl->value);
                if (vl < BRF_VAL_MAX - 1) {
                    fl->value[vl++] = ev->ch;
                    fl->value[vl] = 0;
                    win_invalidate(w);
                }
            }
            return;
        }
        return;   /* прочие клавиши в поле — игнор */
    }

    /* Tab — фокус на первое поле формы */
    if (ev->code == 0x0F) {
        for (int k = 0; k < b->forms.nfields; k++) {
            if (strcmp(b->forms.fields[k].type, "hidden") != 0) {
                b->focus = k;
                win_invalidate(w);
                return;
            }
        }
    }

    /* --- режим редактирования адреса --- */
    if (b->addr_focus) {
        if (ev->ch == 0x1B || ev->code == 0x01) {          /* Esc */
            b->addr_focus = 0;
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n') {          /* Enter */
            br_navigate(b, b->addr);
            return;
        }
        if (ev->code == 0x0E) {                            /* Backspace */
            if (b->addr_len > 0) {
                b->addr[--b->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        /* Ctrl+V — вставить текст из буфера в адрес (адрес — ASCII:
         * кириллица из буфера пропускается) */
        if ((ev->flags & KF_CTRL) &&
            (ev->ch == 'v' || ev->ch == 'V' || ev->code == 0x2F)) {
            const char *t = clip_text_get();
            for (int i = 0; t && t[i]; i++) {
                char cv = t[i];
                if (cv < 0x20 || cv >= 0x7F) continue;
                if (b->addr_len < BR_ADDR_MAX)
                    b->addr[b->addr_len++] = cv;
            }
            b->addr[b->addr_len] = 0;
            win_invalidate(w);
            return;
        }
        if (ev->ch >= 0x20 && ev->ch < 0x7F && !(ev->flags & KF_CTRL)) {
            if (b->addr_len < BR_ADDR_MAX) {
                b->addr[b->addr_len++] = ev->ch;
                b->addr[b->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        return;   /* прочие клавиши в режиме ввода игнорируем */
    }

    /* --- обычный режим: прокрутка ---
     * СЕССИЯ 17 (ФИКС): раньше было ЗАДОМ НАПЕРЁД — PgUp увеличивал
     * scroll (первую видимую строку), Home прыгал в конец. Теперь:
     * scroll — первая видимая строка; PgUp/вверх — к началу.
     * ЗАДАЧА 53: PgUp/PgDn — страница; СТРЕЛКИ — WM_KEY_SCROLL_LINES
     * строк (несколько), а не страница: полной страницей легко
     * перескочить нужное место. */
    int ch = win_content_h(w);
    int vis = (ch - BR_HDR - BR_STATUS_H) / 16;
    if (vis < 1) vis = 1;
    int max_scroll = b->L.nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    int kstep = vis < WM_KEY_SCROLL_LINES ? vis : WM_KEY_SCROLL_LINES;

    if (ev->code == 0x49) {                                 /* PgUp */
        b->scroll -= vis;
        if (b->scroll < 0) b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == KBD_UP) {                        /* вверх */
        b->scroll -= kstep;
        if (b->scroll < 0) b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x51) {                          /* PgDn */
        b->scroll += vis;
        if (b->scroll > max_scroll) b->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == KBD_DOWN) {                      /* вниз */
        b->scroll += kstep;
        if (b->scroll > max_scroll) b->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == 0x47) {                          /* Home */
        b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x0E) {                          /* Backspace */
        br_go_back(b);                       /* сессия 55: назад */
    } else if (ev->ch == 0x1B || ev->code == 0x01) {
        win_close(w);
    }
}

/* Ссылка под точкой контента или NULL. r — строка отображения,
 * col — колонка в символах. */
static const char *br_link_at(browser_t *b, int r, int col)
{
    if (r < 0 || r >= b->L.nlines) return NULL;
    const char *piece = b->L.lines[r];
    int plen = (int)strlen(piece);
    return brp_click_link(&b->page, b->md, b->L.srcidx[r], b->L.srcoff[r],
                          piece, plen, col,
                          b->L.cls[r] == BRL_CLS_LINK ? 1 : 0);
}

static void br_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), chh = win_content_h(w);

    /* ОТпускание ЛКМ после drag выделения — принимается В ЛЮБОМ месте
     * (включая отрицательные координаты за пределами окна: сессия 20
     * доставляет их при неявном захвате мыши — иначе drag «залипал»). */
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT) && b->sel_drag) {
        b->sel_drag = 0;
        if (b->sel_active) {               /* было перетаскивание — это НЕ клик */
            win_invalidate(w);
            return;
        }
        /* клик без перемещения: ссылка под точкой отпускания? */
        int area_y = BR_HDR;
        int area_h = chh - BR_HDR - BR_STATUS_H;
        if (my >= area_y && my < area_y + area_h) {
            int r = b->scroll + (my - area_y - 2) / 16;
            int col = (mx - 4) / 8;
            const char *u = (col >= 0) ? br_link_at(b, r, col) : NULL;
            if (u) {
                /* клик по ссылке: относительные адреса — против страницы */
                char abs[300];
                img_url_resolve(b->url, u, abs, (int)sizeof(abs));
                br_navigate(b, abs);
                return;
            }
        }
        if (b->addr_focus) b->addr_focus = 0;
        win_invalidate(w);
        return;
    }

    if (my < 0 || mx < 0) return;

    if (my < BR_HDR) {
        if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT))
            return;                   /* интересует только нажатие ЛКМ */
        b->sel_drag = 0;              /* нажатие в шапке — не drag текста */
        /* полоса адреса: Go / Save (сессия 67) / Back / поле */
        if (mx >= cw - 48 && mx < cw - 4) {
            br_navigate(b, b->addr);   /* кнопка Go */
        } else if (mx >= cw - 96 && mx < cw - 52) {
            br_save_page(b);           /* кнопка Save (сессия 67) */
        } else if (mx >= cw - 144 && mx < cw - 100) {
            br_go_back(b);             /* кнопка Back (сессия 55) */
        } else if (mx < cw - 152) {
            if (!b->addr_focus) {
                b->addr_focus = 1;
                win_invalidate(w);
            }
        }
        return;
    }

    /* полоса прокрутки (сессия 17); сессия 20: при drag полосу не
     * отпускаем — события с любыми координатами (захват мыши) */
    if ((mx >= cw - 9 && my < chh - BR_STATUS_H) || b->sb.dragging) {
        int np = wm_scrollbar_mouse(&b->sb, mx, my, btn, changed);
        if (np >= 0) { b->scroll = np; win_invalidate(w); }
        return;
    }

    /* --- контент (сессия 55): ховер, выделение, клики по ссылкам --- */
    int area_y = BR_HDR;
    int area_h = chh - BR_HDR - BR_STATUS_H;
    if (my >= area_y && my < area_y + area_h) {
        int r = b->scroll + (my - area_y - 2) / 16;
        int col = (mx - 4) / 8;

        /* ховер: показ адреса в статусе (перерисовка только при смене;
         * во время drag выделения ховер не трогаем — статус оставим) */
        if (!b->sel_drag) {
            const char *url = (col >= 0) ? br_link_at(b, r, col) : NULL;
            const char *h = url ? url : "";
            if (strncmp(b->hover, h, sizeof(b->hover) - 1) != 0) {
                strncpy(b->hover, h, sizeof(b->hover) - 1);
                b->hover[sizeof(b->hover) - 1] = 0;
                win_invalidate(w);
            }
        }

        /* Task 51 [BR-INPUT]: КЛИК ПО КОНТРОЛУ ФОРМЫ. Раньше контролы
         * реагировали только на клавиатуру (Tab — фокус, Enter/Space —
         * активация), а клик мышью по кнопке/полю обрабатывался как
         * клик по обычному тексту (начинал выделение, снимал фокус
         * адреса) — «не могу нажать кнопки и ввести что-либо в поле
         * ввода». Теперь: клик по строке-якорю \x03 ставит фокус поля;
         * кнопки/чекбоксы/select активируются сразу, текстовые поля
         * ждут ввод с клавиатуры. */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) &&
            r >= 0 && r < b->L.nlines &&
            b->L.lines[r][0] == BRF_MARK && b->L.lines[r][1] == 0) {
            brf_field_t *fl = br_field_by_row(b, r);
            if (fl && strcmp(fl->type, "hidden") != 0) {
                b->focus = (int)(fl - b->forms.fields);
                b->sel_drag = 0;          /* клик по контролу — не выделение */
                b->sel_active = 0;
                int text_like = !strcmp(fl->type, "text") ||
                                !strcmp(fl->type, "password") ||
                                !strcmp(fl->type, "search") ||
                                !strcmp(fl->type, "textarea");
                if (!text_like)
                    br_field_activate(b, fl);   /* submit/button/checkbox/
                                                 * radio/select — сразу */
                win_invalidate(w);
                return;
            }
        }

        /* ВЫДЕЛЕНИЕ: нажатие ставит ЯКОРЬ, drag тянет второй конец;
         * клик БЕЗ перемещения обрабатывается в блоке отпускания выше
         * (ссылка/фокус адреса — как раньше, но на mouse-up). */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            b->sel_drag = 1;
            b->sel_active = 0;
            b->sel_ar = b->sel_br = r;
            b->sel_ac = b->sel_bc = col;
            /* клик по контенту снимает фокус с адресной строки */
            if (b->addr_focus) b->addr_focus = 0;
            win_invalidate(w);
        } else if (b->sel_drag && (btn & MSB_LEFT)) {
            /* drag: второй конец следует за курсором */
            if (r != b->sel_br || col != b->sel_bc) {
                b->sel_br = r;
                b->sel_bc = col;
                b->sel_active = (r != b->sel_ar || col != b->sel_ac);
                win_invalidate(w);
            }
        }
    } else if (b->hover[0]) {
        b->hover[0] = 0;
        win_invalidate(w);
    }
}

static void br_close(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    if (b) {
        /* Task 51 [JS-FREE]: ГЛАВНАЯ утечка памяти браузера. JS-контекст
         * страницы (brjs_start: пул 256 КиБ + сегменты роста до 512 КиБ)
         * освобождался только при переходе на новую страницу — при
         * ЗАКРЫТИИ окна brjs_stop не звался вовсе, и вся память JS
         * (скрипт отработал, упал по OOM или ещё жил) оставалась занятой
         * НАВСЕГДА: «скрипты забирают всю память и не отдают даже после
         * закрытия браузера». Теперь контекст и пул возвращаются системе
         * здесь (JS_FreeContext освобождает и сегменты роста). */
        brjs_stop(&b->js);
        /* [JS-FREE]: malloc-буферы инлайн-скриптов последней страницы
         * (brf_script_t.code) — навигация чистила их через brf_parse
         * (brf_reset), закрытие окна — нет. */
        brf_reset(&b->forms);
        brl_free(&b->L);
        if (b->md) free(b->md);
        if (b->src) free(b->src);            /* [BR-SAVE]: исходник */
        brp_reset(&b->page);                 /* сессия 55: пиксели картинок */
        if (b->page.line_off) free(b->page.line_off);
        b->page.line_off = NULL;
        free(b);
    }
}

/* ---------- стартовая страница ---------- */

static const char *br_help_md =
    "# Браузер N2600-OS\n\n"
    "## Ссылки\n"
    "- Ссылки — СИНИЕ с подчёркиванием: [пример.com](http://example.com/)\n"
    "- Клик — переход; адрес под курсором — в статус-строке\n"
    "- Редиректы (301/302) проходятся автоматически — до 4 раз\n"
    "- Кнопка **Back** или **Backspace** — назад; `<a href>` из HTML\n"
    "  и `[текст](url)` из Markdown работают одинаково\n\n"
    "## Картинки\n"
    "![логотип N2600](LOGO.PNG)\n"
    "- Форматы: PNG, JPEG, BMP, GIF (stb_image)\n"
    "- `<img src=...>` из HTML и `![alt](url)` из Markdown; относительные\n"
    "  пути разрешаются от адреса страницы; локальные файлы — RAM disk\n\n"
    "## Выделение и копирование\n"
    "- Проведите мышью с зажатой ЛКМ — текст выделится\n"
    "- **Ctrl+C** — скопировать выделенное в общий буфер обмена\n"
    "- Вставка — **Ctrl+V** в редакторе (буфер один на всю систему)\n"
    "- **Ctrl+V** в адресной строке — вставить скопированный адрес\n\n"
    "## Адресная строка\n"
    "- Клик по ней или **Ctrl+L** — редактирование\n"
    "- **Enter** или кнопка **Go** — переход\n"
    "- `http://host/path` или `https://` — запрос (в потоке этого окна:\n"
    "  зависший запрос не вешает систему)\n"
    "- Имя файла (`help.md`, `demo.js`) — открыть файл из RAM disk\n"
    "- Кнопка **Save** или **Ctrl+S** — сохранить страницу в RAM disk\n"
    "  (имя — из адреса, существующие файлы не перезаписываются)\n\n"
    "## Если «connection refused (RST ... ttl=...)»\n"
    "- Соединение сбросил не сайт: ttl=64 — фильтр вашей же сети\n"
    "  (роутер/AP/DNS-синкхол); меньше — хост интернета\n"
    "- Попробуйте https:// или info.cern.ch, neverssl.com, example.com\n\n"
    "## Поддержка Markdown\n"
    "- Заголовки `#`, `##`, `###`; **жирный**, *курсив*, `код`\n"
    "- Списки и ссылки [текст](http://example.com/)\n\n"
    "## Команды терминала\n"
    "- `curl http://example.com/` — загрузить страницу в новое окно\n"
    "- `spawn browser` — ещё одно окно браузера\n"
    "- `js img.js` — картинки из JS-скрипта (QuickJS)\n\n"
    "---\n"
    "Прокрутка: PgUp/PgDn, стрелки, колёсико мыши; назад — Backspace\n";

/* ---------- создание окна ---------- */

static browser_t *br_new_state(void)
{
    browser_t *b = (browser_t *)malloc(sizeof(browser_t));
    if (!b) return NULL;
    memset(b, 0, sizeof(*b));
    strncpy(b->url, "help", sizeof(b->url) - 1);
    strcpy(b->status, "Готово");
    return b;
}

static void br_open_common(browser_t *b, int load_help)
{
    if (load_help) {
        browser_load_content(b, "help", br_help_md, (int)strlen(br_help_md));
        strcpy(b->addr, "help");
        b->addr_len = (int)strlen(b->addr);
    }

    u32 W = fb_width(), H = fb_height();
    int ww = 700;
    int wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    window_t *w = win_create("Браузер", (int)W / 2 - ww / 2, 16, ww, wh,
                              br_draw, br_key, br_mouse, NULL, br_close, b);
    if (!w) {
        /* FIX [BR-OPEN-LEAK] (ревью, баг 6): провал win_create терял
         * ВСЕ буферы состояния (md/src/L/page.imgs/формы/JS-пул).
         * Освобождаем ровно как в br_close. */
        brjs_stop(&b->js);
        brf_reset(&b->forms);
        brl_free(&b->L);
        if (b->md) free(b->md);
        if (b->src) free(b->src);
        brp_reset(&b->page);
        if (b->page.line_off) free(b->page.line_off);
        free(b);
        return;
    }
    b->win = w;

    /* сессия 55: если контент уже загружен (curl/help) — картинки грузим
     * здесь, когда окно и его размеры уже известны */
    if (b->imgs_pending)
        br_load_images(b);
}

void app_browser_open(void)
{
    browser_t *b = br_new_state();
    if (!b) return;
    br_open_common(b, 1);
}

void app_browser_open_with(const char *url, const char *content, int len)
{
    browser_t *b = br_new_state();
    if (!b) return;
    browser_load_content(b, url ? url : "(curl)", content, len);
    if (url) {
        strncpy(b->addr, url, BR_ADDR_MAX);
        b->addr[BR_ADDR_MAX] = 0;
        b->addr_len = (int)strlen(b->addr);
    }
    br_open_common(b, 0);
}
