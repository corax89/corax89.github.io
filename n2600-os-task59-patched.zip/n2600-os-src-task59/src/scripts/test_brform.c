/* Host smoke-test: FIX [BRJ-OVF] (протечка кода скриптов) +
 * FIX [META-REFRESH] (парсер маркера REFRESH) в brform.h */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#define HOST_TEST 1
typedef unsigned int  u32;
typedef unsigned char u8;

#include "../task58/n2600-os-src-task53/src/src/brform.h"

static char mdbuf[256 * 1024];

static void put_line(const char *s)
{
    strcat(mdbuf, s);
    strcat(mdbuf, "\n");
}

int main(void)
{
    brf_forms_t f;

    /* --- Тест 1: 12 скриптов при BRJ_MAX=10 — код НЕ протекает --- */
    mdbuf[0] = 0;
    put_line("HEADER TEXT LINE");
    for (int i = 0; i < 12; i++) {
        put_line("\x01SCRIPT");
        char ln[128];
        snprintf(ln, sizeof(ln), "var leaky_code_%d = 12345678;", i);
        put_line(ln);
        snprintf(ln, sizeof(ln), "document.write('x%d');", i);
        put_line(ln);
        put_line("\x01/SCRIPT");
    }
    put_line("FOOTER TEXT LINE");

    memset(&f, 0xAA, sizeof(f));
    int out = brf_parse(&f, mdbuf, (int)strlen(mdbuf));
    mdbuf[out] = 0;

    if (f.nscripts != 10) {
        printf("FAIL1: nscripts=%d (ожидалось 10)\n", f.nscripts);
        return 1;
    }
    if (strstr(mdbuf, "leaky_code_10") || strstr(mdbuf, "leaky_code_11")) {
        printf("FAIL1: код скриптов 10/11 ПРОТЕК в текст\n");
        return 1;
    }
    if (strstr(mdbuf, "leaky_code_0")) {
        printf("FAIL1: код первых скриптов протек (не должен вообще)\n");
        return 1;
    }
    if (!strstr(mdbuf, "HEADER TEXT LINE") || !strstr(mdbuf, "FOOTER TEXT LINE")) {
        printf("FAIL1: обычный текст потерян\n");
        return 1;
    }
    printf("OK1: 12 скриптов -> код сверх лимита проглочен, текст цел\n");

    /* --- Тест 1b: вложенный сценарий — SCRIPT сразу после исчерпания
     * бюджета кода (cap <= 128): 3 больших скрипта по 10К --- */
    memset(&f, 0, sizeof(f));
    mdbuf[0] = 0;
    for (int i = 0; i < 4; i++) {
        put_line("\x01SCRIPT");
        char big[4096];
        for (int j = 0; j < 3; j++) {
            memset(big, 'a' + i, sizeof(big) - 1);
            big[sizeof(big) - 1] = 0;
            put_line(big);
        }
        put_line("\x01/SCRIPT");
    }
    put_line("AFTER SCRIPTS");
    out = brf_parse(&f, mdbuf, (int)strlen(mdbuf));
    mdbuf[out] = 0;
    if (strstr(mdbuf, "aaaaaaaa") || strstr(mdbuf, "bbbbbbbb") ||
        strstr(mdbuf, "cccccccc") || strstr(mdbuf, "dddddddd")) {
        printf("FAIL1b: переполнение бюджета кода протекло\n");
        return 1;
    }
    if (!strstr(mdbuf, "AFTER SCRIPTS")) {
        printf("FAIL1b: текст после скриптов потерян\n");
        return 1;
    }
    printf("OK1b: исчерпание бюджета кода не протекает\n");

    /* --- Тест 2: маркер REFRESH --- */
    memset(&f, 0, sizeof(f));
    mdbuf[0] = 0;
    put_line("PAGE");
    put_line("\x01REFRESH content=\"0; url=https://ya.ru/target.html\"");
    put_line("TAIL");
    out = brf_parse(&f, mdbuf, (int)strlen(mdbuf));
    mdbuf[out] = 0;
    if (strcmp(f.refresh_url, "https://ya.ru/target.html") != 0) {
        printf("FAIL2: refresh_url='%s'\n", f.refresh_url);
        return 1;
    }
    if (f.refresh_delay != 0) {
        printf("FAIL2: delay=%d\n", f.refresh_delay);
        return 1;
    }
    if (strstr(mdbuf, "REFRESH") || strstr(mdbuf, "ya.ru")) {
        printf("FAIL2: маркер REFRESH виден в тексте\n");
        return 1;
    }
    printf("OK2: meta-refresh разобран (delay=%d url=%s)\n",
           f.refresh_delay, f.refresh_url);

    /* --- Тест 2b: content без url; url в верхнем регистре; &amp; --- */
    memset(&f, 0, sizeof(f));
    mdbuf[0] = 0;
    put_line("\x01REFRESH content=\"5; URL=/go?a=1&amp;b=2\"");
    out = brf_parse(&f, mdbuf, (int)strlen(mdbuf));
    if (strcmp(f.refresh_url, "/go?a=1&b=2") != 0 || f.refresh_delay != 5) {
        printf("FAIL2b: url='%s' delay=%d\n", f.refresh_url, f.refresh_delay);
        return 1;
    }
    memset(&f, 0, sizeof(f));
    mdbuf[0] = 0;
    put_line("\x01REFRESH content=\"3\"");
    out = brf_parse(&f, mdbuf, (int)strlen(mdbuf));
    if (f.refresh_url[0] != 0 || f.refresh_delay != 3) {
        printf("FAIL2c: url='%s' delay=%d (ожидался пустой url, delay 3)\n",
               f.refresh_url, f.refresh_delay);
        return 1;
    }
    printf("OK2b/2c: URL= верхним регистром + &amp;; content без url\n");

    /* --- Тест 3: обычные скрипты по-прежнему собираются --- */
    memset(&f, 0, sizeof(f));
    mdbuf[0] = 0;
    put_line("\x01SCRIPT");
    put_line("var a = 1;");
    put_line("\x01/SCRIPT");
    put_line("TEXT");
    out = brf_parse(&f, mdbuf, (int)strlen(mdbuf));
    mdbuf[out] = 0;
    if (f.nscripts != 1 || !f.scripts[0].code ||
        strcmp(f.scripts[0].code, "var a = 1;\n") != 0) {
        printf("FAIL3: code='%s'\n", f.scripts[0].code ? f.scripts[0].code : "(null)");
        return 1;
    }
    if (strstr(mdbuf, "var a")) {
        printf("FAIL3: код виден в тексте\n");
        return 1;
    }
    printf("OK3: обычные инлайн-скрипты не сломаны\n");

    printf("ALL brform TESTS PASSED\n");
    return 0;
}
