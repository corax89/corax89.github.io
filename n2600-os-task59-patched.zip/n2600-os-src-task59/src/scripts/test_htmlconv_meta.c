/* Host smoke-test: htmlconv meta-refresh + инлайн-скрипты -> маркеры */
#define HOST_TEST 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef unsigned int  u32;
typedef unsigned char u8;

#include "../task58/n2600-os-src-task53/src/src/htmlconv.h"

static char md[65536];

static int run(const char *html)
{
    int n = html_to_md(html, (int)strlen(html), md, (int)sizeof(md));
    md[n < 0 ? 0 : n] = 0;
    return n;
}

static int fails = 0;

static void expect(int cond, const char *what)
{
    printf("%s: %s\n", cond ? "OK" : "FAIL", what);
    if (!cond) fails++;
}

int main(void)
{
    /* --- Тест 1: meta refresh -> маркер REFRESH --- */
    run("<html><head><meta http-equiv=\"Refresh\" "
        "content=\"0; url=https://ya.ru/target.html\"></head>"
        "<body>Hello</body></html>");
    puts(md);
    expect(strstr(md, "\x01REFRESH content=\"0; url=https://ya.ru/target.html\"") != NULL,
           "T1: маркер \\x01REFRESH присутствует");
    expect(strstr(md, "Hello") != NULL, "T1: текст тела на месте");
    expect(strstr(md, "http-equiv") == NULL, "T1: атрибуты meta не протекли");

    /* --- Тест 2: meta с нижним регистром и одинарными кавычками --- */
    run("<meta http-equiv='refresh' content='5;URL=/next?a=1&amp;b=2'>X");
    expect(strstr(md, "\x01REFRESH content=\"5;URL=/next?a=1&b=2\"") != NULL,
           "T2: lowercase/одинарные кавычки/&amp;");
    expect(strstr(md, "X") != NULL, "T2: текст после meta цел");

    /* --- Тест 3: обычный meta без refresh НЕ даёт маркер --- */
    run("<head><meta charset=\"utf-8\"><meta name=\"viewport\" "
        "content=\"width=1024\"></head>");
    expect(strstr(md, "\x01") == NULL, "T3: прочие meta без маркеров");

    /* --- Тест 4: инлайн-скрипт -> SCRIPT/SCRIPT-маркеры, код не в тексте --- */
    run("<body>BEFORE<script>var q=123;\nalert(q);</script>AFTER</body>");
    expect(strstr(md, "\x01SCRIPT\n") != NULL, "T4: открывающий маркер SCRIPT");
    expect(strstr(md, "\n\x01/SCRIPT") != NULL, "T4: закрывающий маркер /SCRIPT");
    expect(strstr(md, "var q=123;") != NULL, "T4: код собран в маркерном блоке");
    {
        /* код должен лежать МЕЖДУ маркерами, не как видимый текст:
         * вырежем блок и проверим, что вне блока кода нет */
        const char *s = strstr(md, "\x01SCRIPT");
        const char *e = strstr(md, "\x01/SCRIPT");
        expect(s && e && e > s, "T4: оба маркера в правильном порядке");
        if (s && e && e > s) {
            /* скопируем md без блока */
            char clean[65536];
            int head = (int)(s - md);
            int tail = (int)strlen(e + 1) + 1;
            memcpy(clean, md, (size_t)head);
            memcpy(clean + head, e + 1, (size_t)tail);
            clean[head + tail] = 0;
            expect(strstr(clean, "var q=123;") == NULL &&
                   strstr(clean, "alert(q)") == NULL,
                   "T4: вне маркерного блока кода нет");
            expect(strstr(clean, "BEFORE") && strstr(clean, "AFTER"),
                   "T4: текст вокруг скрипта цел");
        }
    }

    /* --- Тест 5: несколько meta refresh — берётся первый --- */
    run("<meta http-equiv=refresh content=\"0;url=/a\">"
        "<meta http-equiv=refresh content=\"0;url=/b\">");
    {
        const char *r1 = strstr(md, "url=/a");
        const char *r2 = strstr(md, "url=/b");
        expect(r1 != NULL && r2 != NULL,
               "T5: оба маркера REFRESH выданы (браузер возьмёт первый)");
    }

    printf(fails ? "\n%d FAILURES\n" : "\nALL htmlconv TESTS PASSED\n", fails);
    return fails != 0;
}
