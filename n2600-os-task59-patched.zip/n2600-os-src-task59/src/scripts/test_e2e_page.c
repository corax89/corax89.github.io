/* E2E: сложная страница (12 скриптов + meta refresh + текст) ->
 * htmlconv -> brf_parse. Проверяем: код НЕ виден, refresh распознан. */
#define HOST_TEST 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef unsigned int  u32;
typedef unsigned char u8;

#include "../task58/n2600-os-src-task53/src/src/htmlconv.h"
#include "../task58/n2600-os-src-task53/src/src/brform.h"

static char md[256 * 1024];

int main(void)
{
    /* эмуляция «сложной страницы»: шапка, meta refresh, 12 скриптов
     * (последние два — за лимитом BRJ_MAX=10), текст, ещё скрипты */
    char html[128 * 1024];
    int o = 0;
    o += snprintf(html + o, sizeof(html) - (size_t)o,
        "<html><head><meta http-equiv=\"content-type\" content=\"text/html\">"
        "<meta http-equiv=\"refresh\" content=\"0;url=https://example.com/go\">"
        "<title>Complex page</title></head><body>");
    o += snprintf(html + o, sizeof(html) - (size_t)o, "<h1>Заголовок</h1>");
    for (int i = 0; i < 12; i++) {
        o += snprintf(html + o, sizeof(html) - (size_t)o,
            "<script>var cfg_%d = {id:%d, data:'x'};\n"
            "init(%d);</script>", i, i, i);
        o += snprintf(html + o, sizeof(html) - (size_t)o, "<p>Параграф %d</p>", i);
    }
    o += snprintf(html + o, sizeof(html) - (size_t)o,
        "<script>var tail='КОНЕЦ';</script><p>Финал</p></body></html>");

    int md_len = html_to_md(html, o, md, (int)sizeof(md));
    md[md_len] = 0;

    brf_forms_t f;
    memset(&f, 0, sizeof(f));
    md_len = brf_parse(&f, md, md_len);
    md[md_len] = 0;

    int fails = 0;
    /* 1) refresh распознан */
    if (strcmp(f.refresh_url, "https://example.com/go") != 0) {
        printf("FAIL: refresh_url='%s'\n", f.refresh_url); fails++;
    } else printf("OK: refresh_url = %s (delay %d)\n", f.refresh_url, f.refresh_delay);

    /* 2) НИ ОДНОГО фрагмента JS-кода в видимом тексте */
    const char *leaks[] = { "var cfg_", "init(", "var tail", "КОНЕЦ" };
    for (unsigned k = 0; k < sizeof(leaks)/sizeof(leaks[0]); k++) {
        if (strstr(md, leaks[k])) {
            printf("FAIL: протёк '%s'\n", leaks[k]); fails++;
        }
    }
    if (!fails) printf("OK: ни один скрипт не протёк в текст\n");

    /* 3) полезный текст цел */
    if (!strstr(md, "Заголовок") || !strstr(md, "Финал") ||
        !strstr(md, "Параграф 9")) {
        printf("FAIL: потерян видимый текст\n"); fails++;
    } else printf("OK: видимый текст цел\n");

    /* 4) собрано скриптов: 10 (лимит) */
    printf("info: nscripts=%d, code_used=%d\n", f.nscripts, f.code_used);
    if (f.nscripts != 10) { printf("FAIL: nscripts!=10\n"); fails++; }

    printf(fails ? "\n%d FAILURES\n" : "\nE2E PASSED\n", fails);
    return fails != 0;
}
