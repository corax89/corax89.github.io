/* c4.c — C in four functions (Robert Swierczek, https://github.com/rswier/c4).
 *
 * ПОРТ ДЛЯ N2600-OS (freestanding):
 *   - убран #define int long long (мы 32-битные, int и так вмещает указатель);
 *   - убраны stdio/stdlib/unistd/fcntl, используются наши string.h/mem.h;
 *   - printf() переадресован во внешний буфер (c4_out/c4_out_pos);
 *   - exit() делает __builtin_longjmp обратно в c4_run();
 *   - open/read/close не нужны: исходник передаётся в память;
 *   - точка входа: c4_run(src, out, out_max) вместо main(argc, argv).
 *
 * Поддержано подмножество C: char/int/unsigned/указатели, if/while/for/do/
 * switch-case-default/break/continue, оператор «запятая», составные
 * присваивания (+= -= *= /= %= &= |= ^= <<= >>=), escape-последовательности
 * C89 (\n \t \r \xHH \NNN ...), прототипы функций (вызовы до определения);
 * выражения, функции; VM-сисколы OPEN/READ/CLOS/PRTF/MALC/FREE/MSET/MCMP/EXIT.
 * Для PRTF поддержаны %d %s %c (по нашему snprintf).
 *
 * РАСШИРЕНИЯ СОВМЕСТИМОСТИ (сессия «c4 improvements»):
 *   1. const/static/volatile/extern — разбираются и игнорируются
 *      (квалификаторы перед типом в глобальных/локальных объявлениях);
 *   2. goto Label / Label: — переходы внутри одной функции;
 *   3. sizeof(выражение) — например sizeof(*p), sizeof(p[0]), sizeof(x+y);
 *   4. конкатенация смежных строковых литералов "abc" "def" + корректный
 *      NUL-терминатор (раньше строки длиной, кратной 4, склеивались
 *      с соседними без терминатора!);
 *   5. базовый #include "file" / <file> — текстовый препроцессор до
 *      компиляции (хост-хук c4_include_hook); #define NAME VALUE уже был.
 *
 * CMScript GUI API (parity с cmscript_api ОС): win_open/win_close/win_alive/
 * win_clear/win_rect/win_text/win_update/btn_add/btn_clicked/btn_set_label —
 * сисколы WOPEN..BSETLB (добавлены В КОНЕЦ списка опкодов; в native-пути
 * вызываются через kapi_t, в VM-пути — через таблицу c4_gui_api).
 */

#include "c4.h"
#include "sync.h"
#include "types.h"
#include "string.h"
#include "mem.h"
/* N2600-OS: заголовки для SDL2-подобных сисколов */
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"
#include "ramfs.h"
#include "c4gfx.h"   /* окно графики для kfill/ktext VM-пути */

char *p, *lp, // текущая позиция в исходнике
     *data;   // указатель области data/bss

int *e, *le,  // текущая позиция в эмитируемом коде
    *id,      // разбираемый идентификатор
    *sym,     // таблица символов (простой список идентификаторов)
    tk,       // текущий токен
    ival,     // значение текущего токена
    ty,       // тип текущего выражения
    loc,      // смещение локальной переменной
    line,     // номер строки
    src,      // флаг печати исходника (не используется в нашей сборке)
    debug;    // флаг печати выполняемых инструкций

// токены и классы (операторы — последние, в порядке приоритета)
enum {
  Num = 128, Fun, Sys, Glo, Loc, Id,
  Char, Else, Enum, If, Int, Return, Sizeof, While,
  For, Do, Break, Continue, Switch, Case, Default, Unsigned,
  /* Квалификаторы (игнорируются) и goto — регистрируются как ключевые
   * слова; диапазон Char..Auto обязан быть непрерывным (см. цикл
   * регистрации). Держать ВЫШЕ Comma/Assign (это НЕ операторы). */
  Goto, Const, Static, Volatile, Extern,
  /* C89: typedef и «мягкие» типы: signed (игнорируется), long/short
   * (алиас int), register/auto (игнорируются). */
  Typedef, Signed, Long, Short, Register, Auto,
  /* Псевдо-токен ИМЕНИ typedef (u32, string, ...); ключевое слово
   * typedef — отдельный токен Typedef. Не регистрируется лексером. */
  TdefName,
  /* Comma — НИЖЕ Assign: в c4 чем больше значение enum, тем выше
   * приоритет; у оператора «запятая» приоритет минимальный. */
  Comma,
  /* Составные присваивания — тот же уровень приоритета, что Assign */
  Assign, AddAssign, SubAssign, MulAssign, DivAssign, ModAssign,
  AndAssign, OrAssign, XorAssign, ShlAssign, ShrAssign,
  Cond, Lor, Lan, Or, Xor, And, Eq, Ne, Lt, Gt, Le, Ge, Shl, Shr, Add, Sub, Mul, Div, Mod, Inc, Dec, Brak,
  /* Диапазон метки case (расширение GCC): case 'a' ... 'z': — тройная
   * точка отдельным токеном, чтобы парсер case отличал её от одиночной
   * точки (структуры не поддерживаются, одиночная '.' всё равно ошибка). */
  DotDotDot
};

// опкоды
enum { LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,
       OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,
       OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,
       /* N2600-OS: SDL2-подобные сисколы для c4-программ.
        * Имена: kinit, kquit, kdelay, kfill, ktext, kflip, krgb, kevent,
        *        kclear, kwidth, kheight, kmtime
        * Позволяют писать простые интерактивные программы. */
       KINIT,KQUIT,KDELAY,KFILL,KTEXT,KFLIP,KRGB,KEVENT,KCLEAR,KW,KH,KMTIME,
       /* Строковые операции */
       STRLEN,STRCPY,STRCMP,
       /* Логический (беззнаковый) сдвиг вправо: unsigned >> n.
       * ДОБАВЛЯТЬ ТОЛЬКО В КОНЕЦ: нумерация опкодов должна совпадать
       * с c4_x86.c и влияет на формат сохранённых бинарей. */
       USHR,
       /* CMScript GUI API (окна/кнопки) — WOPEN..BSETLB, ТОЛЬКО В КОНЦЕ.
       * Имена: win_open win_close win_alive win_clear win_rect win_text
       *        win_update btn_add btn_clicked btn_set_label
       * В native-коде эмитятся как call [edi+KAPI_WIN_*] (c4_x86.c),
       * в VM — через таблицу указателей c4_gui_api (ниже). */
       WOPEN,WCLOSE,WALIVE,WCLEAR,WRECT,WTEXT,WUPD,BADD,BCLICK,BSETLB };

/* Таблица GUI-функций для VM-пути (native-путь вызывает через kapi_t).
 * Тип c4_gui_api_t объявлен в c4.h. Хост (IDE/тесты) регистрирует
 * реализации; NULL = безопасные заглушки: win_open -> -1, win_alive -> 0
 * (окно «закрыто»), btn_clicked -> -1. */
c4_gui_api_t *c4_gui_api = 0;

/* Хост-хук для #include (см. c4_preprocess ниже). Регистрируется хостом
 * ДО компиляции; NULL = директивы #include пропускаются (старое поведение).
 *   name     — имя файла без кавычек/уголков;
 *   kind     — 0 для #include "name", 1 для #include <name>;
 *   includer — путь файла, из которого включают (для относительных путей);
 *   buf/max  — куда прочитать содержимое.
 * Возвращает длину содержимого (0 = файл не найден). */
u32 (*c4_include_hook)(const char *name, int kind, const char *includer,
                       char *buf, u32 max) = 0;

// типы
enum { CHAR, INT, PTR };
#define ARR 0x80        /* флаг массива: OR с базовым типом (ARR|INT, ARR|CHAR) */
/* «Это указатель?» — БЕЗ флага UNSIGNED (0x100 иначе делает тип
 * «> INT/PTR» и включает масштабирование указателей у обычных
 * unsigned-переменных: s += v умножал на 4, u32++ прибавлял 4). */
#define IS_PTR_T(t)   (((t) & ~UNSIGNED) > INT)
#define IS_CPTR_T(t)  (((t) & ~UNSIGNED) == PTR)   /* char* (шаг 1 байт) */
#define IS_IPTR_T(t)  (((t) & ~UNSIGNED) > PTR)    /* указатель на 4-байтные (шаг 4) */
#define UNSIGNED 0x100  /* флаг беззнаковости: OR с базовым типом (INT|UNSIGNED).
                         * Влияет на выбор сдвига >> (логический вместо
                         * арифметического). Деление, сравнения и прочие
                         * операции остаются знаковыми (документированное
                         * ограничение). */

// смещения в записи идентификатора
enum { Tk, Hash, Name, Class, Type, Val, HClass, HType, HVal, Idsz };

/* ---------- выходной буфер и escape через __builtin_longjmp ---------- */

/* FIX [C1]: пулы для освобождения на ВСЕХ путях выхода. Раньше каждый
 * запуск c4_run (успешный или с ошибкой) протекал 4 x 256К = 1 МиБ:
 * EXIT, longjmp (exit()), все `return -1` парсера и лимит циклов
 * не освобождали пулы. */
static int  *c4_pool_sym   = NULL;
static int  *c4_pool_text  = NULL;
static char *c4_pool_data  = NULL;
static int  *c4_pool_stack = NULL;

static void c4_free_pools(void)
{
    if (c4_pool_sym)   { free(c4_pool_sym);   c4_pool_sym = NULL; }
    if (c4_pool_text)  { free(c4_pool_text);  c4_pool_text = NULL; }
    if (c4_pool_data)  { free(c4_pool_data);  c4_pool_data = NULL; }
    if (c4_pool_stack) { free(c4_pool_stack); c4_pool_stack = NULL; }
}

static char *c4_out = 0;
static u32   c4_out_pos = 0;
static u32   c4_out_max = 0;
static void *c4_jmp[12];
static int   c4_exit_code = 0;

/* Когда не NULL — c4_run сохранит байт-код в RAMFS под этим именем
 * и сразу вернётся (не запуская VM). Формат файла:
 *   char magic[4] = "C4B1"
 *   u32  entry_offset_cells   (смещение main от начала text в int-ячейках)
 *   u32  text_len_cells       (длина text в int-ячейках)
 *   u32  data_len_bytes       (длина data в байтах)
 *   u8   text[text_len_cells * 4]
 *   u8   data[data_len_bytes]
 */
static const char *c4_save_bin_name = NULL;
/* Сохранённое начало data pool (для расчёта data_len при dump в файл) */
static char *data_pool_start = NULL;

/* Compile-only mode: c4_run после парсинга сохраняет байт-код в
 * caller-предоставленные буферы и возвращает без запуска VM. */
static int c4_compile_only = 0;
static u8 *c4_compile_bc_buf = NULL;
static u32  c4_compile_bc_max = 0;
static u32  c4_compile_bc_len_cells = 0;
static u8 *c4_compile_data_buf = NULL;
static u32  c4_compile_data_max = 0;
static u32  c4_compile_data_len = 0;
static u32  c4_compile_entry_cells = 0;
static int *c4_idmain_val_saved = NULL;

/* Метки IMM-операндов, ссылающихся на СЕГМЕНТ ДАННЫХ (строки и глобалы).
 * c4_x86 использует их, чтобы отличить адрес данных от обычной числовой
 * константы и сгенерировать релокацию (сегмент данных у каждого
 * скомпилированного бинарника — СВОЙ, выделяется loader'ом).
 * Индекс ячейки — в int-ячейках от начала пула text (le). */
#define C4_MAX_IMM_MARKS 8192
u32 c4_imm_data_cells[C4_MAX_IMM_MARKS];
int c4_n_imm_data_cells = 0;
/* Адрес data pool на момент компиляции (нужен c4_x86 для пересчёта
 * абсолютных адресов в смещения сегмента данных). */
u32 c4_compile_data_base = 0;
/* База текст-пула (le) на момент компиляции: операнды переходов в
 * байт-коде — абсолютные указатели le+cell; c4_x86 пересчитывает их
 * в индексы ячеек для карты {cell → x86 offset}. */
u32 c4_compile_text_base = 0;

/* --- Прототипы: вызовы функций до их определения ---
 * JSR с операндом 0 записывается сюда; после разбора всего файла
 * операнд патчится на id[Val] (либо ошибка «function not defined»). */
#define C4_MAX_JSR_FIXUPS 256
static struct { int *cell; int *fid; } c4_jsr_fixups[C4_MAX_JSR_FIXUPS];
static int c4_n_jsr_fixups = 0;

/* --- Текущая функция (для switch: скрытые слоты локалов) ---
 * i / loc / указатель на ENT — локали c4_run_impl, из stmt() они не
 * видны; синхронизируем в эти глобалы перед разбором тела функции. */
static int *c4_fn_ent = 0;   /* ячейка ENT текущей функции ([1] = операнд) */
static int  c4_fn_i = 0;     /* счётчик слотов локалов (синхронизирован с i) */
static int  c4_fn_loc = 0;   /* loc текущей функции */

static void c4_putc(char c)
{
    if (c4_out_pos + 1 < c4_out_max) c4_out[c4_out_pos++] = c;
}

/* Перенаправить вывод c4 (printf нативных программ и VM) во внешний
 * буфер БЕЗ запуска c4_run. Нужно loader'у: он захватывает вывод
 * нативного .bin (запуск через `run` / файловый менеджер) и показывает
 * его в окне. c4_capture_end() возвращает прежнее перенаправление. */
void c4_capture_begin(char *buf, u32 max)
{
    c4_out = buf;
    c4_out_pos = 0;
    c4_out_max = max;
    if (buf && max) buf[0] = 0;
}

u32 c4_capture_len(void)
{
    return c4_out_pos;
}

void c4_capture_end(void)
{
    if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0;
    c4_out = 0;
    c4_out_pos = 0;
    c4_out_max = 0;
}

static void c4_puts(const char *s)
{
    while (*s) c4_putc(*s++);
}

static void c4_putint(int v)
{
    char b[12]; int i = 0;
    int neg = 0;
    unsigned u;
    if (v < 0) { c4_putc('-'); u = (unsigned)(-v); } else u = (unsigned)v;
    if (u == 0) { c4_putc('0'); return; }
    while (u) { b[i++] = (char)('0' + u % 10); u /= 10; }
    while (i--) c4_putc(b[i]);
    (void)neg;
}

static void c4_putudec(unsigned u)
{
    char b[12]; int i = 0;
    if (u == 0) { c4_putc('0'); return; }
    while (u) { b[i++] = (char)('0' + u % 10u); u /= 10u; }
    while (i--) c4_putc(b[i]);
}

static void c4_puthex(unsigned v)
{
    const char *d = "0123456789abcdef";
    for (int i = 28; i >= 0; i -= 4) c4_putc(d[(v >> i) & 0xF]);
}

/* Минимальный printf для исходников c4: %d %s %c %x, без ширины/флагов. */
static int c4_vm_printf(const char *fmt, int a0, int a1, int a2, int a3, int a4, int a5)
{
    int argidx = 0;
    int args[6]; args[0]=a0; args[1]=a1; args[2]=a2; args[3]=a3; args[4]=a4; args[5]=a5;
    while (*fmt) {
        if (*fmt != '%') { c4_putc(*fmt++); continue; }
        fmt++;
        /* ширина: %[0]<N>d/s/x/c — %5d, %05d, %7x */
        int wflag = 0, wzero = 0;
        if (*fmt == '0') { wzero = 1; fmt++; }
        while (*fmt >= '0' && *fmt <= '9') { wflag = wflag * 10 + (*fmt - '0'); fmt++; }
        if (*fmt == 'l') fmt++;   /* %ld/%lu/%lx — модификатор длины игнорируем */
        if (*fmt == 'd') {
            char b[16]; int i = 0; unsigned uv;
            int v = args[argidx++];
            if (v < 0) { c4_putc('-'); uv = (unsigned)(-(long long)v); } else uv = (unsigned)v;
            if (uv == 0) b[i++] = '0';
            while (uv) { b[i++] = (char)('0' + uv % 10u); uv /= 10u; }
            if (wflag) { int pad = wflag - i - (v < 0 ? 1 : 0); while (pad-- > 0) c4_putc(wzero ? '0' : ' '); }
            while (i--) c4_putc(b[i]);
            fmt++;
        }
        else if (*fmt == 'u') {
            /* %u — беззнаковое десятичное (C89) */
            char b[16]; int i = 0;
            unsigned uv = (unsigned)args[argidx++];
            if (uv == 0) b[i++] = '0';
            while (uv) { b[i++] = (char)('0' + uv % 10u); uv /= 10u; }
            if (wflag) { int pad = wflag - i; while (pad-- > 0) c4_putc(wzero ? '0' : ' '); }
            while (i--) c4_putc(b[i]);
            fmt++;
        }
        else if (*fmt == 's') {
            const char *s = (const char *)(unsigned)args[argidx++];
            int sl = 0; if (s) while (s[sl]) sl++;
            if (wflag) { int pad = wflag - sl; while (pad-- > 0) c4_putc(' '); }
            c4_puts(s ? s : "");
            fmt++;
        }
        else if (*fmt == 'c') { c4_putc((char)args[argidx++]); fmt++; }
        else if (*fmt == 'x') { c4_puthex((unsigned)args[argidx++]); fmt++; }
        else if (*fmt == '%') { c4_putc('%'); fmt++; }
        else { c4_putc('%'); c4_putc(*fmt++); }
    }
    return 0;
}

/* printf для самого компилятора (диагностика): полностью перекладываем на snprintf. */
static void c4_printf(const char *fmt, ...)
{
    if (c4_out_pos + 1 >= c4_out_max) return;
    int n;
    /* вычисляем через наш snprintf в свой микро-буфер, потом копируем */
    char buf[160];
    /* snprintf из string.h принимает (out, n, fmt, ...) — cdecl, va_list не нужен */
    extern int snprintf(char *out, u32 n, const char *fmt, ...);
    /* Здесь мы не знаем число аргументов заранее — поэтому обрабатываем %d и %s вручную,
       копируя va_list через __builtin_va_arg. Чтобы не усложнять, передаём в snprintf
       только тривиальные случаи. */
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    n = vsnprintf(buf, sizeof(buf), fmt, ap);
    __builtin_va_end(ap);
    if (n < 0) return;
    for (int i = 0; i < n && c4_out_pos + 1 < c4_out_max; i++)
        c4_out[c4_out_pos++] = buf[i];
}

#define exit(x) do { c4_exit_code = (x); __builtin_longjmp(c4_jmp, 1); } while (0)
#define printf(...) c4_printf(__VA_ARGS__)

/* --- goto / метки (расширение 2) ---
 * goto эмитит JMP с нулевым операндом + запись в c4_goto_fixups;
 * определение метки (Name:) патчит все ждущие goto на (e+1).
 * Ключ — запись идентификатора в symtab (как у c4_jsr_fixups).
 * Таблицы сбрасываются при входе в каждую функцию; незакрытые
 * goto в конце функции = «undefined label». */
#define C4_MAX_GOTO_FIXUPS 128
static struct { int *cell; int *fsym; } c4_goto_fixups[C4_MAX_GOTO_FIXUPS];
static int c4_n_goto_fixups = 0;

/* --- глобальные инициализаторы: чанки-функции + boot-код до main --- */
#define C4_MAX_BOOT 256
static int *c4_boot_chunks[C4_MAX_BOOT];
static int  c4_n_boot = 0;
static u32  c4_boot_cell = 0;   /* индекс ячейки boot-кода (0 = нет) */
#define C4_MAX_LABELS 128
static struct { int *fsym; int *addr; } c4_labels[C4_MAX_LABELS];
static int c4_n_labels = 0;

static int *c4_label_find(int *fsym)
{
    for (int i = 0; i < c4_n_labels; i++)
        if (c4_labels[i].fsym == fsym) return c4_labels[i].addr;
    return 0;
}

static void c4_label_define(int *fsym)
{
    int *addr = (int *)(e + 1);   /* следующая эмитируемая ячейка */
    for (int i = 0; i < c4_n_labels; i++) {
        if (c4_labels[i].fsym == fsym) {
            printf("%d: duplicate label '%s'\n", line, (char *)(unsigned long)fsym[Name]);
            exit(-1);
        }
    }
    if (c4_n_labels < C4_MAX_LABELS) {
        c4_labels[c4_n_labels].fsym = fsym;
        c4_labels[c4_n_labels].addr = addr;
        c4_n_labels++;
    }
    /* патчим все ждущие goto на эту метку и УБИРАЕМ их из списка
     * (иначе патченые фиксапы давали ложное «undefined label») */
    int w = 0;
    for (int i = 0; i < c4_n_goto_fixups; i++) {
        if (c4_goto_fixups[i].fsym == fsym)
            *c4_goto_fixups[i].cell = (int)(unsigned long)addr;
        else
            c4_goto_fixups[w++] = c4_goto_fixups[i];
    }
    c4_n_goto_fixups = w;
}

/* Метка ли это? tk == Id; p указывает на символ сразу после
 * идентификатора — пропускаем пробелы и ищем ':'. */
static int c4_at_label(void);

/* --- Разворачивание #include (расширение 5) ---
 * Однопроходный лексер не умеет подгружать файлы посреди потока,
 * поэтому ДО компиляции строится развёрнутый исходник: каждая строка
 * #include "file" / <file> заменяется содержимым файла (рекурсивно,
 * глубина <= 8, результат <= 1 МиБ, защита от циклических включений).
 * Возвращает malloc'нутый буфер (освобождает вызывающий) или NULL,
 * если включений не было (компилируем исходный текст как есть). */
#define C4_INCL_MAX_DEPTH 8
#define C4_INCL_MAX_OUT   (1024 * 1024)
#define C4_INCL_MAX_FILE  (256 * 1024)

static int c4_incl_depth = 0;
static const char *c4_incl_chain[C4_INCL_MAX_DEPTH];   /* имена активных включений */

static char *c4_incl_out;
static u32   c4_incl_len, c4_incl_cap;

static int c4_incl_reserve(u32 extra)
{
    if (c4_incl_len + extra + 1 <= c4_incl_cap) return 1;
    u32 ncap = c4_incl_cap ? c4_incl_cap * 2 : 65536;
    while (ncap < c4_incl_len + extra + 1) ncap *= 2;
    if (ncap > C4_INCL_MAX_OUT + 4096) return 0;
    char *nb = (char *)malloc(ncap);
    if (!nb) return 0;
    if (c4_incl_out) { memcpy(nb, c4_incl_out, c4_incl_len); free(c4_incl_out); }
    c4_incl_out = nb;
    c4_incl_cap = ncap;
    return 1;
}

static void c4_incl_emit(const char *s, u32 n)
{
    if (!c4_incl_reserve(n)) return;
    memcpy(c4_incl_out + c4_incl_len, s, n);
    c4_incl_len += n;
    c4_incl_out[c4_incl_len] = 0;
}

/* --- C89: условная компиляция (#ifdef/#ifndef/#if/#else/#elif/#endif) ---
 * Текстовый препроцессор ведёт список имён #define (с числовым значением,
 * если указано) и вырезает неактивные ветки ДО компиляции. Include-гuards
 * (#ifndef X_H / #define X_H / ... / #endif) работают естественно. */
#define C4_MAX_DEFS 128
#define C4_DEF_NAME 64
static char c4_def_names[C4_MAX_DEFS][C4_DEF_NAME];
static int  c4_def_has_val[C4_MAX_DEFS];
static int  c4_def_vals[C4_MAX_DEFS];
static int  c4_n_defs = 0;

static int c4_def_find(const char *name, u32 len)
{
    for (int i = 0; i < c4_n_defs; i++)
        if ((int)len == (int)strlen(c4_def_names[i]) &&
            !memcmp(c4_def_names[i], name, len)) return i;
    return -1;
}

static void c4_def_add(const char *name, u32 len, int has_val, int val)
{
    if (len == 0 || len >= C4_DEF_NAME) return;
    int di = c4_def_find(name, len);
    if (di < 0) {
        if (c4_n_defs >= C4_MAX_DEFS) return;
        di = c4_n_defs++;
        memcpy(c4_def_names[di], name, len);
        c4_def_names[di][len] = 0;
        c4_def_has_val[di] = 0;
    }
    c4_def_has_val[di] = has_val;
    c4_def_vals[di] = val;
}

static void c4_def_del(const char *name, u32 len)
{
    int di = c4_def_find(name, len);
    if (di < 0) return;
    for (int i = di; i < c4_n_defs - 1; i++) {
        memcpy(c4_def_names[i], c4_def_names[i + 1], C4_DEF_NAME);
        c4_def_has_val[i] = c4_def_has_val[i + 1];
        c4_def_vals[i] = c4_def_vals[i + 1];
    }
    c4_n_defs--;
}

/* слово директивы: возвращает длину или 0; *body — после слова (пробелы
 * пропущены), *bend — конец строки. */
static int c4_dir_word(const char *q, const char *le,
                       const char **body, const char **bend)
{
    const char *w = q + 1;                       /* после '#' */
    while (w < le && (*w == ' ' || *w == '\t')) w++;
    const char *ws = w;
    while (w < le && ((*w >= 'a' && *w <= 'z') || (*w >= 'A' && *w <= 'Z') || *w == '_')) w++;
    if (w == ws) return 0;
    *body = w;
    while (*body < le && (**body == ' ' || **body == '\t')) (*body)++;
    *bend = le;
    return (int)(w - ws);
}

/* вычислитель #if: числа (dec/hex/oct), defined(NAME)/defined NAME,
 * имена макросов (их числовое значение), скобки, унарные ! - + ~,
 * бинарные по приоритетам: || && | ^ & == != < > <= >= << >> + - * / %.
 * Деление/остаток на ноль дают 0 (не падаем). Всё остальное = 0. */
static int c4_if_expr(const char **pp, const char *le);

static int c4_if_prim(const char **pp, const char *le)
{
    const char *p = *pp;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    int v;
    if (*p == '(') {
        p++;
        v = c4_if_expr(&p, le);
        while (p < le && (*p == ' ' || *p == '\t')) p++;
        if (*p == ')') p++;
    } else if (p + 7 <= le && !memcmp(p, "defined", 7) &&
               (p[7] == '(' || p[7] == ' ' || p[7] == '\t')) {
        p += 7;
        while (p < le && (*p == ' ' || *p == '\t')) p++;
        if (*p == '(') p++;
        const char *ns = p;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        v = (c4_def_find(ns, (u32)(p - ns)) >= 0) ? 1 : 0;
        while (p < le && (*p == ' ' || *p == '\t')) p++;
        if (*p == ')') p++;
    } else if (*p >= '0' && *p <= '9') {
        if (*p == '0' && (p[1] == 'x' || p[1] == 'X')) {
            p += 2; v = 0;
            while (p < le && (((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') ||
                               (*p >= 'A' && *p <= 'F'))))
                v = v * 16 + (*p & 15) + (*p >= 'A' ? 9 : 0), p++;
        } else if (*p == '0') {
            v = 0;
            while (p < le && *p >= '0' && *p <= '7') v = v * 8 + (*p++ - '0');
        } else {
            v = 0;
            while (p < le && *p >= '0' && *p <= '9') v = v * 10 + (*p++ - '0');
        }
    } else {
        const char *ns = p;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        int di = (p > ns) ? c4_def_find(ns, (u32)(p - ns)) : -1;
        v = (di >= 0 && c4_def_has_val[di]) ? c4_def_vals[di] : 0;
    }
    *pp = p;
    return v;
}

/* унарные префиксы #if: ! - + ~ (рекурсивно, перед prim) */
static int c4_if_unary(const char **pp, const char *le)
{
    const char *p = *pp;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    if (p < le && (*p == '!' || *p == '-' || *p == '+' || *p == '~')) {
        int op = *p++;
        *pp = p;
        int v = c4_if_unary(pp, le);
        if (op == '!') return !v;
        if (op == '-') return -v;      /* #define X -5 в #if теперь верен */
        if (op == '~') return ~v;
        return v;
    }
    *pp = p;
    return c4_if_prim(pp, le);
}

/* бинарный оператор #if: id (0 = нет) и приоритет *pr (больше = сильнее).
 * 1|| 2&& 3== 4!= 5<= 6>= 7<< 8>> 9| 10^ 11& 12< 13> 14+ 15- 16* 17/ 18%
 * (двухсимвольные проверяются первыми) */
static int c4_if_op(const char **pp, const char *le, int *pr)
{
    const char *p = *pp;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    int op = 0, q = 0;
    #define C4_OP2(a, b) (p + 1 < le && p[0] == (a) && p[1] == (b))
    if      (C4_OP2('|','|')) { op = 1;  q = 1;  p += 2; }
    else if (C4_OP2('&','&')) { op = 2;  q = 2;  p += 2; }
    else if (C4_OP2('=','=')) { op = 3;  q = 6;  p += 2; }
    else if (C4_OP2('!','=')) { op = 4;  q = 6;  p += 2; }
    else if (C4_OP2('<','=')) { op = 5;  q = 7;  p += 2; }
    else if (C4_OP2('>','=')) { op = 6;  q = 7;  p += 2; }
    else if (C4_OP2('<','<')) { op = 7;  q = 8;  p += 2; }
    else if (C4_OP2('>','>')) { op = 8;  q = 8;  p += 2; }
    else if (p < le) {
        switch (*p) {
        case '|': op = 9;  q = 3;  break;
        case '^': op = 10; q = 4;  break;
        case '&': op = 11; q = 5;  break;
        case '<': op = 12; q = 7;  break;
        case '>': op = 13; q = 7;  break;
        case '+': op = 14; q = 9;  break;
        case '-': op = 15; q = 9;  break;
        case '*': op = 16; q = 10; break;
        case '/': op = 17; q = 10; break;
        case '%': op = 18; q = 10; break;
        }
        if (op) p++;
    }
    #undef C4_OP2
    *pp = p;
    *pr = q;
    return op;
}

/* приоритетное восхождение (precedence climbing) для #if */
static int c4_if_bin(const char **pp, const char *le, int minq)
{
    int l = c4_if_unary(pp, le);
    for (;;) {
        const char *save = *pp;        /* откат, если оператор не взят */
        int q;
        int op = c4_if_op(pp, le, &q);
        if (!op || q < minq) { *pp = save; break; }
        int r = c4_if_bin(pp, le, q + 1);
        switch (op) {
        case 1:  l = (l || r); break;
        case 2:  l = (l && r); break;
        case 3:  l = (l == r); break;
        case 4:  l = (l != r); break;
        case 5:  l = (l <= r); break;
        case 6:  l = (l >= r); break;
        case 7:  l = (l << r); break;
        case 8:  l = (l >> r); break;
        case 9:  l = (l |  r); break;
        case 10: l = (l ^  r); break;
        case 11: l = (l &  r); break;
        case 12: l = (l <  r); break;
        case 13: l = (l >  r); break;
        case 14: l = (l +  r); break;
        case 15: l = (l -  r); break;
        case 16: l = (l *  r); break;
        case 17: l = r ? (l / r) : 0; break;
        case 18: l = r ? (l % r) : 0; break;
        }
    }
    return l;
}

static int c4_if_expr(const char **pp, const char *le)
{
    return c4_if_bin(pp, le, 1);
}

/* запомнить имя #define (и числовое значение, если это число/скобки с числом) */
static void c4_def_record(const char *body, const char *le)
{
    const char *p = body;
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    const char *ns = p;
    while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                      (*p >= '0' && *p <= '9') || *p == '_')) p++;
    if (p == ns) return;
    u32 len = (u32)(p - ns);
    while (p < le && (*p == ' ' || *p == '\t')) p++;
    int has_val = 0, val = 0;
    if (p < le && (*p == '-' || (*p >= '0' && *p <= '9'))) {
        const char *np = p;
        int v = c4_if_unary(&np, le);   /* унарный '-': #define X -5 */
        has_val = 1; val = v;
    }
    c4_def_add(ns, len, has_val, val);
}

/* обработать условную директиву. Возвращает:
 *   0 — не условная директива (строку emits вызывающий);
 *   1 — условная директива (строка вырезана, лексер её не увидит);
 *   2 — #define/#undef в активной области: строку надо ВЫВЕСТИ
 *       (лексер регистрирует значение), имя уже запомнено;
 *   3 — #define/#undef/#include в НЕактивной области: строка вырезана. */
static int c4_incl_directive(const char *q, const char *le, int *cd,
                             int *cact, int *ctaken, int *cpar)
{
    const char *body, *bend;
    int wl = c4_dir_word(q, le, &body, &bend);
    if (!wl) return 0;
    int parent = (*cd == 0) ? 1 : cact[*cd - 1];
    if (wl == 5 && !memcmp(q + 1, "ifdef", 5)) {
        const char *ns = body;
        const char *p = body;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        int def = (c4_def_find(ns, (u32)(p - ns)) >= 0);
        if (*cd < 32) { cpar[*cd] = parent; cact[*cd] = parent && def; ctaken[*cd] = def; (*cd)++; }
        return 1;
    }
    if (wl == 6 && !memcmp(q + 1, "ifndef", 6)) {
        const char *ns = body;
        const char *p = body;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        int def = (c4_def_find(ns, (u32)(p - ns)) >= 0);
        if (*cd < 32) { cpar[*cd] = parent; cact[*cd] = parent && !def; ctaken[*cd] = !def; (*cd)++; }
        return 1;
    }
    if (wl == 2 && !memcmp(q + 1, "if", 2) &&
        !(q + 1 + 2 <= le && (q[3] == 'd'))) {   /* не ifdef/ifndef (уже отсечено длиной) */
        const char *bp = body;
        int v = c4_if_expr(&bp, le);
        if (*cd < 32) { cpar[*cd] = parent; cact[*cd] = parent && v; ctaken[*cd] = v; (*cd)++; }
        return 1;
    }
    if (wl == 4 && !memcmp(q + 1, "else", 4)) {
        if (*cd > 0) {
            cact[*cd - 1] = cpar[*cd - 1] && !ctaken[*cd - 1];
            ctaken[*cd - 1] = 1;
        }
        return 1;
    }
    if (wl == 4 && !memcmp(q + 1, "elif", 4)) {
        if (*cd > 0) {
            if (!ctaken[*cd - 1]) {
                const char *bp = body;
                int v = c4_if_expr(&bp, le);
                cact[*cd - 1] = cpar[*cd - 1] && v;
                ctaken[*cd - 1] = v;
            } else {
                cact[*cd - 1] = 0;
            }
        }
        return 1;
    }
    if (wl == 5 && !memcmp(q + 1, "endif", 5)) {
        if (*cd > 0) (*cd)--;
        return 1;
    }
    if (wl == 6 && !memcmp(q + 1, "define", 6)) {
        if (!parent) return 3;
        c4_def_record(body, le);
        return 2;                     /* строку выводим — лексер зарегистрирует */
    }
    if (wl == 5 && !memcmp(q + 1, "undef", 5)) {
        if (!parent) return 3;
        const char *ns = body;
        const char *p = body;
        while (p < le && ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
                          (*p >= '0' && *p <= '9') || *p == '_')) p++;
        c4_def_del(ns, (u32)(p - ns));
        return 2;                     /* лексер строку пропустит сам */
    }
    return parent ? 0 : 3;   /* прочие директивы (#include, #pragma...) */
}

static void c4_incl_expand(const char *src, const char *includer)
{
    int my_depth = c4_incl_depth;
    if (my_depth >= C4_INCL_MAX_DEPTH) return;
    c4_incl_depth = my_depth + 1;
    /* стек условной компиляции — локальный на файл (незакрытый #if
     * в одном заголовке не ломает остальные) */
    int cd = 0;
    int cact[32], ctaken[32], cpar[32];
    const char *p = src;
    while (*p) {
        const char *le = p;
        while (*le && *le != '\n') le++;          /* конец строки (не включая \n) */
        u32 line_len = (u32)(le - p);
        /* начало строки после пропуска пробелов */
        const char *q = p;
        while (q < le && (*q == ' ' || *q == '\t')) q++;
        if (*q != '#' && cd > 0 && !cact[cd - 1]) {
            /* НЕактивная область: обычные строки вырезаются (директивы
             * обработаны выше по стеку; #include/#define в неактивных
             * ветках дают dr == 3 и тоже вырезаются). */
            if (*le == '\n') c4_incl_emit("\n", 1);
            p = *le ? le + 1 : le;
            continue;
        }
        if (*q == '#') {
            int dr = c4_incl_directive(q, le, &cd, cact, ctaken, cpar);
            if (dr == 1 || dr == 3) {
                /* условная директива / неактивная строка: вырезаем,
                 * перевод строки оставляем (нумерация строк) */
                if (*le == '\n') c4_incl_emit("\n", 1);
                p = *le ? le + 1 : le;
                continue;
            }
            if (dr == 2) {
                /* активный #define/#undef: строка выводится как есть */
                c4_incl_emit(p, line_len);
                c4_incl_emit("\n", 1);
                p = *le ? le + 1 : le;
                continue;
            }
            if (q + 8 <= le && !memcmp(q + 1, "include", 7) &&
                (q[8] == ' ' || q[8] == '\t')) {
                /* #include "name" / <name> */
                const char *fn = q + 9;
                while (fn < le && (*fn == ' ' || *fn == '\t')) fn++;
                int kind = -1;
                char name[256]; u32 nl = 0;
                if (fn < le && *fn == '"') {
                    kind = 0; fn++;
                    while (fn < le && *fn != '"' && nl < sizeof(name) - 1) name[nl++] = *fn++;
                } else if (fn < le && *fn == '<') {
                    kind = 1; fn++;
                    while (fn < le && *fn != '>' && nl < sizeof(name) - 1) name[nl++] = *fn++;
                }
                if (kind >= 0) {
                    name[nl] = 0;
                    int cyclic = 0;
                    for (int i = 0; i < c4_incl_depth - 1; i++)
                        if (c4_incl_chain[i] && !strcmp(c4_incl_chain[i], name)) cyclic = 1;
                    static char buf[C4_INCL_MAX_FILE];
                    u32 got = 0;
                    if (!cyclic && c4_include_hook)
                        got = c4_include_hook(name, kind, includer, buf, sizeof(buf) - 1);
                    if (got) {
                        buf[got] = 0;
                        c4_incl_chain[c4_incl_depth - 1] = name;
                        c4_incl_expand(buf, name);
                        /* включённый файл обязан кончаться переводом строки */
                        if (c4_incl_len && c4_incl_out[c4_incl_len - 1] != '\n')
                            c4_incl_emit("\n", 1);
                        c4_incl_chain[c4_incl_depth - 1] = 0;
                    }
                    /* не найден/цикл — строка просто пропадает (не ломаем лексер).
                     * c4_incl_depth НЕ трогаем: рекурсивный вызов уже сбалансирован. */
                    if (*le == '\n') c4_incl_emit("\n", 1);  /* сохранить нумерацию строк */
                    p = *le ? le + 1 : le;
                    continue;
                }
                /* нераспознанный #include — копируем как есть (лексер пропустит) */
            }
        }
        c4_incl_emit(p, line_len);
        c4_incl_emit("\n", 1);
        p = *le ? le + 1 : le;
    }
    (void)includer;
    c4_incl_depth = my_depth;
}

/* Публичная точка: вернуть развёрнутый исходник или NULL (включений нет). */
static char *c4_preprocess(const char *src)
{
    if (!c4_include_hook) return 0;
    /* быстрый скан: нет ни одного "#include"/"#if" (покрывает и
     * #ifdef/#ifndef/#elif) — не тратим память */
    if (!strstr(src, "#include") && !strstr(src, "#if")) return 0;
    c4_incl_out = 0; c4_incl_len = 0; c4_incl_cap = 0;
    c4_incl_depth = 0;
    c4_incl_chain[0] = 0;
    c4_n_defs = 0;                 /* список #define — на одну компиляцию */
    c4_incl_expand(src, "");
    if (!c4_incl_out) return 0;
    c4_incl_reserve(1);
    c4_incl_out[c4_incl_len] = 0;
    return c4_incl_out;
}

/* Метка ли это? tk == Id; p указывает на символ сразу после
 * идентификатора — пропускаем пробелы и ищем ':'. */
static int c4_at_label(void)
{
    const char *q = p;
    while (*q == ' ' || *q == '\t' || *q == '\r' || *q == '\n') q++;
    return *q == ':';
}

/* Подглядеть символ ch сразу после текущего токена (через пробелы/
 * переводы строк). Нужно для различения f(void) и f(char c). */
static int c4_raw_peek(char ch)
{
    const char *q = p;
    while (*q == ' ' || *q == '\t' || *q == '\r' || *q == '\n') q++;
    return *q == ch;
}

/* Пропуск пробелов/табуляций ВНУТРИ директив с учётом переноса строки
 * «\\» в конце (#define BIG \<LF> 100). line++ — счётчик строк. */
static char *c4_dir_skip_ws(char *q)
{
    for (;;) {
        if (*q == ' ' || *q == '\t') { q++; continue; }
        if (*q == '\\' && (q[1] == '\n' || (q[1] == '\r' && q[2] == '\n'))) {
            q += (q[1] == '\r') ? 3 : 2;
            line++;
            continue;
        }
        break;
    }
    return q;
}

/* Квалификаторы/классы памяти, разбираемые и игнорируемые (C89). */
#define IS_QUAL(t) ((t) == Const || (t) == Static || (t) == Volatile || \
                    (t) == Extern || (t) == Register || (t) == Auto)

static int c4_base_type(void);              /* единый разбор базового типа */
static void c4_parse_typedef(void);
static void c4_parse_decls(int bt, int scope_push);
void expr(int lev);

/* --- Стек областей видимости (объявления во вложенных блоках, C89) ---
 * При объявлении в блоке запись символа сохраняется ЦЕЛИКОМ; при '}'
 * блока восстанавливается (LIFO). Перекрытие параметров, глобалов и
 * #define-констант работает корректно на любую глубину. */
#define C4_MAX_SCOPE 512
static int c4_scope_save[C4_MAX_SCOPE * Idsz];
static int *c4_scope_id[C4_MAX_SCOPE];
static int  c4_n_scope = 0;

static void c4_scope_push(int *sid)
{
    if (c4_n_scope >= C4_MAX_SCOPE) return;
    c4_scope_id[c4_n_scope] = sid;
    for (int k = 0; k < Idsz; k++)
        c4_scope_save[c4_n_scope * Idsz + k] = sid[k];
    c4_n_scope++;
}

static void c4_scope_pop_to(int base)
{
    while (c4_n_scope > base) {
        int *sid;
        c4_n_scope--;
        sid = c4_scope_id[c4_n_scope];
        for (int k = 0; k < Idsz; k++)
            sid[k] = c4_scope_save[c4_n_scope * Idsz + k];
    }
}

/* --- Сырые сканеры инициализаторов (размер int a[] = {...} / = "строка") ---
 * Однопроходный парсер не умеет «сначала посчитать, потом парсить»,
 * поэтому размер выводится сканом сырого текста. Учитывают строки,
 * символы и комментарии (чтобы запятые/кавычки внутри них не считались). */

/* Количество элементов в "{ e0, e1, ... }"; sv указывает на '{'. */
static int c4_count_init_list(const char *sv)
{
    int depth = 0, cnt = 1, in_str = 0, in_chr = 0;
    while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
    if (*sv != '{') return 1;
    sv++;
    while (*sv) {
        if (in_str) {
            if (*sv == '\\') sv++;
            else if (*sv == '"') in_str = 0;
        } else if (in_chr) {
            if (*sv == '\\') sv++;
            else if (*sv == '\'') in_chr = 0;
        } else if (*sv == '"') in_str = 1;
        else if (*sv == '\'') in_chr = 1;
        else if (*sv == '/' && sv[1] == '*') {
            sv += 2;
            while (*sv && !(sv[0] == '*' && sv[1] == '/')) sv++;
            if (*sv) sv++;
        } else if (*sv == '/' && sv[1] == '/') {
            while (*sv && *sv != '\n') sv++;
        } else if (*sv == '{') depth++;
        else if (*sv == '}') { if (depth == 0) break; depth--; }
        else if (*sv == ',' && depth == 0) cnt++;
        sv++;
    }
    return cnt;
}

/* Длина строкового инициализатора в БАЙТАХ (включая NUL); sv указывает
 * на открывающую кавычку. Смежные литералы "a" "b" склеиваются,
 * escape-последовательности считаются одним символом. */
static int c4_count_str_lit(const char *sv)
{
    int n = 0;
    for (;;) {
        while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
        if (*sv != '"') break;
        sv++;
        while (*sv && *sv != '"') {
            if (*sv == '\\') {
                sv++;
                if (*sv == 'x' || *sv == 'X') {
                    sv++;
                    while ((*sv >= '0' && *sv <= '9') || (*sv >= 'a' && *sv <= 'f') ||
                           (*sv >= 'A' && *sv <= 'F')) sv++;
                } else {
                    if (*sv) sv++;
                    while (*sv >= '0' && *sv <= '7') sv++;   /* \NNN — до 3 цифр */
                }
            } else sv++;
            n++;
        }
        if (*sv == '"') sv++; else break;   /* незакрытая строка — что успели */
    }
    return n + 1;   /* NUL-терминатор */
}


void next()
{
  char *pp;

  while (tk = *p) {
    ++p;
    if (tk == '\n') {
      if (src) {
        printf("%d: %.*s", line, p - lp, lp);
        lp = p;
        while (le < e) {
          printf("%8.4s", &"LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,"
                           "OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,"
                           "OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,"[*++le * 5]);
          if (*le <= ADJ) printf(" %d\n", *++le); else printf("\n");
        }
      }
      ++line;
    }
    else if (tk == '#') {
      /* Поддержка #define NAME VALUE — регистрируем NAME как Num в sym table.
       * Остальные #-директивы (#include, #if и т.д.) пропускаем. */
      if (p[0]=='d' && p[1]=='e' && p[2]=='f' && p[3]=='i' && p[4]=='n' && p[5]=='e' && (p[6]==' '||p[6]=='\t')) {
        p = c4_dir_skip_ws(p + 7);
        /* Хэшируем имя */
        char *dp = p;
        int dh = 0;
        while ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p == '_') || (*p >= '0' && *p <= '9'))
          dh = dh * 147 + *p++;
        dh = (dh << 6) + (p - dp);
        int dlen = p - dp;
        p = c4_dir_skip_ws(p);
        /* Парсим значение (число): десятичное/шестнадцатеричное/
         * восьмеричное, с необязательными '-' и скобками */
        int dv = 0;
        int dsign = 1;
        int dparen = 0;
        p = c4_dir_skip_ws(p);
        if (*p == '(') { dparen = 1; p++; while (*p==' '||*p=='\t') p++; }
        if (*p == '-') { dsign = -1; p++; }
        else if (*p == '+') p++;
        if (*p == '0' && (p[1] == 'x' || p[1] == 'X')) {
          p += 2;
          while ((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') || (*p >= 'A' && *p <= 'F'))
            dv = dv * 16 + (*p & 15) + (*p >= 'A' ? 9 : 0), p++;
        } else if (*p == '0') {
          while (*p >= '0' && *p <= '7') dv = dv * 8 + (*p++ - '0');
        } else {
          while (*p >= '0' && *p <= '9') { dv = dv * 10 + (*p - '0'); p++; }
        }
        dv *= dsign;
        if (dparen) { while (*p==' '||*p=='\t') p++; if (*p == ')') p++; }
        /* Регистрируем в sym table */
        id = sym;
        while (id[Tk]) {
          if (dh == id[Hash] && !memcmp((char *)id[Name], dp, dlen)) {
            id[Class] = Num; id[Type] = INT; id[Val] = dv; id[Tk] = Num;
            break;
          }
          id = id + Idsz;
        }
        if (!id[Tk]) {
          /* Новая запись */
          id[Name] = (int)(unsigned long)dp;
          id[Hash] = dh;
          id[Class] = Num; id[Type] = INT; id[Val] = dv;
          id[Tk] = Num;
        }
      }
      else if (p[0]=='e' && p[1]=='r' && p[2]=='r' && p[3]=='o' && p[4]=='r' &&
               (p[5]==' '||p[5]=='\t'||p[5]=='\r'||p[5]=='\n'||!p[5])) {
        /* #error message — диагностическая остановка компиляции (C89).
         * Неактивные ветки #if вырезаны препроцессором и сюда не дойдут. */
        char *m = p + 5;
        while (*m == ' ' || *m == '\t') m++;
        char *me = m;
        while (*me && *me != '\n' && *me != '\r') me++;
        printf("%d: #error: %.*s\n", line, (int)(me - m), m);
        exit(-1);
      }
      /* Пропускаем остаток строки (с учётом переноса \ в конце строки) */
      while (*p != 0 && *p != '\n') {
        if (*p == '\\' && (p[1] == '\n' || (p[1] == '\r' && p[2] == '\n'))) {
          p += (p[1] == '\r') ? 3 : 2;
          ++line;
          continue;
        }
        ++p;
      }
    }
    else if ((tk >= 'a' && tk <= 'z') || (tk >= 'A' && tk <= 'Z') || tk == '_') {
      pp = p - 1;
      while ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') || *p == '_')
        tk = tk * 147 + *p++;
      tk = (tk << 6) + (p - pp);
      id = sym;
      while (id[Tk]) {
        if (tk == id[Hash] && !memcmp((char *)id[Name], pp, p - pp)) {
          tk = id[Tk];
          if (tk == Num) ival = id[Val];  /* #define'd constant → set ival */
          return;
        }
        id = id + Idsz;
      }
      id[Name] = (int)(unsigned long)pp;
      id[Hash] = tk;
      tk = id[Tk] = Id;
      return;
    }
    else if (tk >= '0' && tk <= '9') {
      if (ival = tk - '0') { while (*p >= '0' && *p <= '9') ival = ival * 10 + *p++ - '0'; }
      else if (*p == 'x' || *p == 'X') {
        while ((tk = *++p) && ((tk >= '0' && tk <= '9') || (tk >= 'a' && tk <= 'f') || (tk >= 'A' && tk <= 'F')))
          ival = ival * 16 + (tk & 15) + (tk >= 'A' ? 9 : 0);
      }
      else { while (*p >= '0' && *p <= '7') ival = ival * 8 + *p++ - '0'; }
      tk = Num;
      return;
    }
    else if (tk == '/') {
      if (*p == '/') {
        ++p;
        while (*p != 0 && *p != '\n') ++p;
      }
      else if (*p == '*') {
        /* Block comment: skip until matching */
        ++p; /* skip '*' */
        while (*p != 0) {
          if (*p == '*' && p[1] == '/') { p += 2; break; }
          ++p;
        }
      }
      else {
        if (*p == '=') { ++p; tk = DivAssign; } else tk = Div;
        return;
      }
    }
    else if (tk == '\'' || tk == '"') {
      pp = data;
      while (*p != 0 && *p != tk) {
        if ((ival = *p++) == '\\') {
          ival = *p++;
          /* Полный набор escape-последовательностей C89 */
          if      (ival == 'n') ival = '\n';
          else if (ival == 't') ival = '\t';
          else if (ival == 'r') ival = '\r';
          else if (ival == 'a') ival = 7;    /* bell */
          else if (ival == 'b') ival = 8;    /* backspace */
          else if (ival == 'f') ival = 12;   /* form feed */
          else if (ival == 'v') ival = 11;   /* vtab */
          else if (ival == '\\') ival = '\\';
          else if (ival == '\'') ival = '\'';
          else if (ival == '"') ival = '"';
          else if (ival == '?') ival = '?';
          else if (ival == 'x' || ival == 'X') {
            /* \xHH — шестнадцатеричный код */
            ival = 0;
            while ((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') || (*p >= 'A' && *p <= 'F'))
              ival = ival * 16 + (*p & 15) + (*p >= 'A' ? 9 : 0), p++;
          }
          else if (ival >= '0' && ival <= '7') {
            /* \NNN — восьмеричный код (включая \0) */
            ival -= '0';
            while (*p >= '0' && *p <= '7') ival = ival * 8 + (*p++ - '0');
          }
        }
        if (tk == '"') *data++ = (char)ival;
      }
      ++p;
      if (tk == '"') ival = (int)(unsigned long)pp; else tk = Num;
      return;
    }
    else if (tk == '=') { if (*p == '=') { ++p; tk = Eq; } else tk = Assign; return; }
    else if (tk == '+') { if (*p == '+') { ++p; tk = Inc; } else if (*p == '=') { ++p; tk = AddAssign; } else tk = Add; return; }
    else if (tk == '-') { if (*p == '-') { ++p; tk = Dec; } else if (*p == '=') { ++p; tk = SubAssign; } else tk = Sub; return; }
    else if (tk == '!') { if (*p == '=') { ++p; tk = Ne; } return; }
    else if (tk == '<') {
      if (*p == '=') { ++p; tk = Le; }
      else if (*p == '<') { ++p; if (*p == '=') { ++p; tk = ShlAssign; } else tk = Shl; }
      else tk = Lt;
      return;
    }
    else if (tk == '>') {
      if (*p == '=') { ++p; tk = Ge; }
      else if (*p == '>') { ++p; if (*p == '=') { ++p; tk = ShrAssign; } else tk = Shr; }
      else tk = Gt;
      return;
    }
    else if (tk == '|') { if (*p == '|') { ++p; tk = Lor; } else if (*p == '=') { ++p; tk = OrAssign; } else tk = Or; return; }
    else if (tk == '&') { if (*p == '&') { ++p; tk = Lan; } else if (*p == '=') { ++p; tk = AndAssign; } else tk = And; return; }
    else if (tk == '^') { if (*p == '=') { ++p; tk = XorAssign; } else tk = Xor; return; }
    else if (tk == '%') { if (*p == '=') { ++p; tk = ModAssign; } else tk = Mod; return; }
    else if (tk == '*') { if (*p == '=') { ++p; tk = MulAssign; } else tk = Mul; return; }
    else if (tk == '[') { tk = Brak; return; }
    else if (tk == '?') { tk = Cond; return; }
    else if (tk == ',') { tk = Comma; return; }
    else if (tk == '.' && p[0] == '.' && p[1] == '.') {
      /* "..." — диапазон case (case 2 ... 6:); p стоит на 2-й точке */
      p += 2; tk = DotDotDot; return;
    }
    else if (tk == '~' || tk == ';' || tk == '{' || tk == '}' || tk == '(' || tk == ')' || tk == ']' || tk == ':') return;
  }
}

void expr(int lev)
{
  int t, *d;

  if (!tk) { printf("%d: unexpected eof in expression\n", line); exit(-1); }
  else if (tk == Inc || tk == Dec) {
    /* ПРЕФИКСНЫЕ ++x / --x (новое): загрузить lvalue, +/- 1, сохранить,
     * результат — НОВОЕ значение (как в C). Для указателей шаг — размер
     * элемента (та же формула, что у постфиксной формы). */
    int op = tk;
    next(); expr(Inc);
    if (*e == LC) { *e = PSH; *++e = LC; }
    else if (*e == LI) { *e = PSH; *++e = LI; }
    else { printf("%d: bad lvalue in prefix %s\n", line, op == Inc ? "++" : "--"); exit(-1); }
    *++e = PSH; *++e = IMM; *++e = IS_IPTR_T(ty) ? sizeof(int) : sizeof(char);
    *++e = (op == Inc) ? ADD : SUB;
    *++e = (ty == CHAR) ? SC : SI;
    ty = (ty == CHAR) ? CHAR : INT;
  }
  else if (tk == Num) { *++e = IMM; *++e = ival; next(); ty = INT; }
  else if (tk == '"') {
    *++e = IMM; *++e = ival;
    /* метка: этот IMM-операнд — адрес строки в сегменте данных */
    if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS)
        c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le);
    next();
    while (tk == '"') next();   /* смежные литералы: символы дописываются в data подряд (конкатенация) */
    /* FIX (расширение 4): NUL-терминатор обязателен! Раньше строка
     * terminating'ась ТОЛЬКО выравниванием пула: при длине, кратной 4,
     * терминатора не было вовсе, а следующая строка писалась вплотную —
     * printf("%s", "abcd") печатал мусор до конца пула. Теперь:
     * один терминатор на ВСЮ последовательность смежных литералов. */
    *data++ = 0;
    data = (char *)((int)((unsigned long)data + sizeof(int)) & -sizeof(int)); ty = PTR;
  }
  else if (tk == Sizeof) {
    next();
    if (tk != '(') {
      /* C89: sizeof выражение — без скобок: sizeof x, sizeof *p */
      int *save_e = e;
      int save_n_imm = c4_n_imm_data_cells;
      int save_n_jsr = c4_n_jsr_fixups;
      expr(Inc);
      int is_char = (ty == CHAR);
      e = save_e;                       /* отбросить эмитированный код */
      c4_n_imm_data_cells = save_n_imm; /* отбросить метки data-адресов */
      c4_n_jsr_fixups = save_n_jsr;     /* отбросить фиксапы вызовов */
      *++e = IMM; *++e = is_char ? 1 : 4;
      ty = INT;
    }
    else {
      next();
      /* базовый тип через единый разбор: int/char/unsigned/enum/typedef */
      int b = c4_base_type();
      if (b >= 0) {
        ty = b;
        while (tk == Mul) { next(); ty = ty + PTR; }
        while (IS_QUAL(tk)) next();
        if (tk == ')') next(); else { printf("%d: close paren expected in sizeof\n", line); exit(-1); }
        *++e = IMM; *++e = (ty == CHAR) ? sizeof(char) : sizeof(int);
        ty = INT;
      } else {
        /* sizeof(выражение) — sizeof(*p), sizeof(p[0]), sizeof(x + y),
         * sizeof(arr[i]) ... Код выражения эмитится во временный хвост
         * пула и ОТБРАСЫВАЕТСЯ, размер берётся из типа результата (ty):
         * CHAR -> 1, всё остальное -> 4 (int/указатель).
         * Ограничения (документированы): sizeof(массив) даёт размер
         * указателя, sizeof("строка") — размер указателя (не длину). */
        int *save_e = e;
        int save_n_imm = c4_n_imm_data_cells;
        int save_n_jsr = c4_n_jsr_fixups;
        expr(Comma);
        int is_char2 = (ty == CHAR);
        e = save_e;                       /* отбросить эмитированный код */
        c4_n_imm_data_cells = save_n_imm; /* отбросить метки data-адресов */
        c4_n_jsr_fixups = save_n_jsr;     /* отбросить фиксапы вызовов */
        if (tk == ')') next(); else { printf("%d: close paren expected in sizeof\n", line); exit(-1); }
        *++e = IMM; *++e = is_char2 ? 1 : 4;
        ty = INT;
      }
    }
  }
  else if (tk == Id) {
    d = id; next();
    if (tk == '(') {
      next();
      t = 0;
      while (tk != ')') { expr(Assign); *++e = PSH; ++t; if (tk == Comma) next(); }
      next();
      if (d[Class] == Sys) *++e = d[Val];
      else if (d[Class] == Fun) {
        *++e = JSR; *++e = d[Val];
        /* Вызов по прототипу (Val==0): операнд допатчим после разбора
         * всех определений функций (см. c4_jsr_fixups). */
        if (d[Val] == 0 && c4_n_jsr_fixups < C4_MAX_JSR_FIXUPS) {
          c4_jsr_fixups[c4_n_jsr_fixups].cell = e;
          c4_jsr_fixups[c4_n_jsr_fixups].fid = d;
          c4_n_jsr_fixups++;
        }
      }
      else { printf("%d: bad function call\n", line); exit(-1); }
      if (t) { *++e = ADJ; *++e = t; }
      ty = d[Type];
    }
    else if (d[Class] == Num) { *++e = IMM; *++e = d[Val]; ty = INT; }
    else {
      if (d[Class] == Loc) { *++e = LEA; *++e = loc - d[Val]; }
      else if (d[Class] == Glo) {
          *++e = IMM; *++e = d[Val];
          /* метка: IMM-операнд глобала — адрес в сегменте данных */
          if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS)
              c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le);
      }
      else { printf("%d: undefined variable\n", line); exit(-1); }
      if (d[Type] & ARR) {
        /* Массив: IMM/LEA уже даёт адрес. Не разыменовываем (нет LI/LC).
         * Преобразуем тип: ARR|INT → PTR+INT, ARR|CHAR → PTR. */
        ty = (d[Type] & ~ARR) + PTR;
      } else {
        *++e = ((ty = d[Type]) == CHAR) ? LC : LI;
      }
    }
  }
  else if (tk == '(') {
    next();
    while (IS_QUAL(tk)) next();       /* (const char *)p */
    {
      int b = c4_base_type();
      if (b >= 0) {
        t = b;
        while (tk == Mul) { next(); t = t + PTR; }
        while (IS_QUAL(tk)) next();   /* char * const */
        if (tk == ')') next(); else { printf("%d: bad cast\n", line); exit(-1); }
        expr(Inc);
        ty = t;
      }
      else {
        expr(Comma);   /* (a, b) — оператор «запятая» допустим и в скобках */
        if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
      }
    }
  }
  else if (tk == Mul) {
    next(); expr(Inc);
    if (IS_PTR_T(ty)) ty = (ty & ~UNSIGNED) - PTR; else { printf("%d: bad dereference\n", line); exit(-1); }
    *++e = (ty == CHAR) ? LC : LI;
  }
  else if (tk == And) {
    next(); expr(Inc);
    if (*e == LC || *e == LI) --e; else { printf("%d: bad address-of\n", line); exit(-1); }
    ty = ty + PTR;
  }
  else if (tk == '!') { next(); expr(Inc); *++e = PSH; *++e = IMM; *++e = 0; *++e = EQ; ty = INT; }
  else if (tk == '~') { next(); expr(Inc); *++e = PSH; *++e = IMM; *++e = -1; *++e = XOR; ty = INT; }
  else if (tk == Add) { next(); expr(Inc); ty = INT; }
  else if (tk == Sub) {
    next(); *++e = IMM;
    if (tk == Num) { *++e = -ival; next(); } else { *++e = -1; *++e = PSH; expr(Inc); *++e = MUL; }
    ty = INT;
  }
  else if (tk == Inc || tk == Dec) {
    t = tk; next(); expr(Inc);
    if (*e == LC) { *e = PSH; *++e = LC; }
    else if (*e == LI) { *e = PSH; *++e = LI; }
    else { printf("%d: bad lvalue in pre-increment\n", line); exit(-1); }
    *++e = PSH;
    *++e = IMM; *++e = IS_IPTR_T(ty) ? sizeof(int) : sizeof(char);
    *++e = (t == Inc) ? ADD : SUB;
    *++e = (ty == CHAR) ? SC : SI;
  }
  else { printf("%d: bad expression near: [%.40s]\n", line, p); exit(-1); }

  while (tk >= lev) { // "precedence climbing" or "Top Down Operator Precedence" method
    t = ty;
    if (tk == Comma) {
      /* Оператор «запятая»: левый операнд уже вычислен (в a), вычисляем
       * правый — его значение/тип и есть результат. Побочные эффекты
       * левого сохранены. На стек ничего не кладётся. */
      next();
      expr(Assign);
    }
    else if (tk == Assign) {
      next();
      if (*e == LC || *e == LI) *e = PSH; else { printf("%d: bad lvalue in assignment\n", line); exit(-1); }
      expr(Assign); *++e = ((ty = t) == CHAR) ? SC : SI;
    }
    else if (tk >= AddAssign && tk <= ShrAssign) {
      /* Составные присваивания: x += y; p -= 2; x <<= 3; u >>= 1; ...
       * Левый операнд уже спарсен: [..., LEA/IMM (адрес), LC/LI (значение)].
       * Перестраиваем хвост в [LEA/IMM][PSH (адрес)][LC/LI][PSH (старое
       * значение)]: адрес и старое значение — на стеке; правая часть
       * даёт правый операнд в a; операция снимает старое значение как
       * левый операнд; SC/SI сохраняет результат по адресу. */
      int op;
      switch (tk) {
        case AddAssign: op = ADD; break;
        case SubAssign: op = SUB; break;
        case MulAssign: op = MUL; break;
        case DivAssign: op = DIV; break;
        case ModAssign: op = MOD; break;
        case AndAssign: op = AND; break;
        case OrAssign:  op = OR;  break;
        case XorAssign: op = XOR; break;
        case ShlAssign: op = SHL; break;
        default:        op = (t & UNSIGNED) ? USHR : SHR; break;
      }
      if (*e != LC && *e != LI) { printf("%d: bad lvalue in compound assignment\n", line); exit(-1); }
      int ischar = (*e == LC);
      next();
      *e = PSH;                        /* адрес переменной — на стек */
      *++e = ischar ? LC : LI;         /* старое значение -> a */
      *++e = PSH;                      /* ... и на стек (левый операнд) */
      expr(Assign);
      /* ptr += n / ptr -= n: правый операнд масштабируется
       * размером элемента (как в обычном + / -) */
      if ((op == ADD || op == SUB) && IS_PTR_T(t) && !(t & ARR)) {
        *++e = PSH; *++e = IMM;
        *++e = IS_CPTR_T(t) ? sizeof(char) : sizeof(int);
        *++e = MUL;
      }
      *++e = op;
      *++e = ischar ? SC : SI;
      ty = t;
    }
    else if (tk == Cond) {
      next();
      *++e = BZ; d = ++e;
      expr(Assign);
      if (tk == ':') next(); else { printf("%d: conditional missing colon\n", line); exit(-1); }
      *d = (int)(e + 3); *++e = JMP; d = ++e;
      expr(Cond);
      *d = (int)(e + 1);
    }
    else if (tk == Lor) { next(); *++e = BNZ; d = ++e; expr(Lan); *d = (int)(e + 1); ty = INT; }
    else if (tk == Lan) { next(); *++e = BZ;  d = ++e; expr(Or);  *d = (int)(e + 1); ty = INT; }
    else if (tk == Or)  { next(); *++e = PSH; expr(Xor); *++e = OR;  ty = INT; }
    else if (tk == Xor) { next(); *++e = PSH; expr(And); *++e = XOR; ty = INT; }
    else if (tk == And) { next(); *++e = PSH; expr(Eq);  *++e = AND; ty = INT; }
    else if (tk == Eq)  { next(); *++e = PSH; expr(Lt);  *++e = EQ;  ty = INT; }
    else if (tk == Ne)  { next(); *++e = PSH; expr(Lt);  *++e = NE;  ty = INT; }
    else if (tk == Lt)  { next(); *++e = PSH; expr(Shl); *++e = LT;  ty = INT; }
    else if (tk == Gt)  { next(); *++e = PSH; expr(Shl); *++e = GT;  ty = INT; }
    else if (tk == Le)  { next(); *++e = PSH; expr(Shl); *++e = LE;  ty = INT; }
    else if (tk == Ge)  { next(); *++e = PSH; expr(Shl); *++e = GE;  ty = INT; }
    else if (tk == Shl) { next(); *++e = PSH; expr(Add); *++e = SHL; ty = INT; }
    else if (tk == Shr) { next(); *++e = PSH; expr(Add); *++e = (t & UNSIGNED) ? USHR : SHR; ty = INT; }
    else if (tk == Add) {
      next(); *++e = PSH; expr(Mul);
      /* FIX [C41]: при портировании из rswier/c4 потерялся сам `*++e = ADD`
       * — сложение вообще не эмитилось! `i = i + 1` присваивал ПРАВЫЙ
       * операнд как адрес (SI брал value вместо адреса) → i не менялся
       * → вечный цикл (VM ловила по лимиту 10M, native писал по диким
       * адресам). То же с SUB для int-int и ptr-int.
       * Тип результата ptr+int = ptr; масштаб правого — размер элемента. */
      if (IS_PTR_T(t) && !(t & ARR)) {
          *++e = PSH; *++e = IMM;
          *++e = IS_CPTR_T(t) ? sizeof(char) : sizeof(int);   /* char* vs int*+ */
          *++e = MUL;
      }
      *++e = ADD;
      ty = t;
    }
    else if (tk == Sub) {
      next(); *++e = PSH; expr(Mul);
      if ((t & ~UNSIGNED) == (ty & ~UNSIGNED) && IS_PTR_T(t) && !(t & ARR)) {
          /* ptr - ptr: разность в элементах */
          *++e = SUB; *++e = PSH; *++e = IMM;
          *++e = (t == PTR) ? sizeof(char) : sizeof(int);
          *++e = DIV; ty = INT;
      }
      else {
          if (IS_PTR_T(t) && !(t & ARR)) {
              /* ptr - int: масштабируем правый */
              *++e = PSH; *++e = IMM;
              *++e = IS_CPTR_T(t) ? sizeof(char) : sizeof(int);
              *++e = MUL;
          }
          *++e = SUB;   /* FIX [C41]: эмит потерялся при портировании */
          ty = t;
      }
    }
    else if (tk == Mul) { next(); *++e = PSH; expr(Inc); *++e = MUL; ty = INT; }
    /* FIX [C40]: ветки Div/Mod были потеряны при портировании (в оригинале
     * c4.c rswier — строки 259-260). Без них любая программа с '/' или '%'
     * не компилировалась («bad expression»). */
    else if (tk == Div) { next(); *++e = PSH; expr(Inc); *++e = DIV; ty = INT; }
    else if (tk == Mod) { next(); *++e = PSH; expr(Inc); *++e = MOD; ty = INT; }
    else if (tk == Inc || tk == Dec) {
      /* FIX: постфиксный x-- не поддерживался (в оригинальном c4 в этом
       * цикле есть только ветка Inc — Dec проваливался в `else return`,
       * токен не съедался и парсер требовал ';' на месте '--').
       * Постфиксные ++/-- возвращают НОВОЕ значение в a (семантика c4). */
      int op = tk;
      if (*e == LC) { *e = PSH; *++e = LC; }
      else if (*e == LI) { *e = PSH; *++e = LI; }
      else { printf("%d: bad lvalue in post-increment\n", line); exit(-1); }
      *++e = PSH; *++e = IMM; *++e = IS_IPTR_T(ty) ? sizeof(int) : sizeof(char);
      *++e = (op == Inc) ? ADD : SUB;
      *++e = (ty == CHAR) ? SC : SI;
      next();
    }
    else if (tk == Brak) {
      next(); *++e = PSH; expr(Assign);
      if (tk == ']') next(); else { printf("%d: close bracket expected\n", line); exit(-1); }
      if (IS_IPTR_T(t)) { *++e = PSH; *++e = IMM; *++e = sizeof(int); *++e = MUL; *++e = ADD; *++e = (ty = (t & ~UNSIGNED) - PTR) == CHAR ? LC : LI; }
      /* FIX [C43]: было `(ty = CHAR) ? LC : LI` — присваивание вместо
       * сравнения: CHAR=0 → всегда ложь → LI (4-байтовая загрузка)
       * вместо LC. char* p; p[i] читал 4 байта (мусор соседних). */
      else if (IS_CPTR_T(t)) { *++e = ADD; *++e = LC; ty = CHAR; }
      else { printf("%d: can't index subptr\n", line); exit(-1); }
    }
    else return;
  }
}

/* Break/continue fixup stack: каждый break/continue генерирует JMP с placeholder.
 * После завершения цикла все pending break'и патчатся на адрес выхода,
 * все continue — на адрес следующей итерации. Поддерживает вложенные циклы. */
#define MAX_FIXUPS 64
#define MAX_LOOP_DEPTH 32
static int *break_fixups[MAX_FIXUPS];
static int n_break_fixups;
static int *cont_fixups[MAX_FIXUPS];
static int n_cont_fixups;

static int break_save[MAX_LOOP_DEPTH];
static int cont_save[MAX_LOOP_DEPTH];
static int loop_depth = 0;

static void push_loop(void) {
    if (loop_depth >= MAX_LOOP_DEPTH) return;
    break_save[loop_depth] = n_break_fixups;
    cont_save[loop_depth] = n_cont_fixups;
    loop_depth++;
}
static void patch_continue(int *loop_top) {
    if (loop_depth == 0) return;
    for (int i = cont_save[loop_depth - 1]; i < n_cont_fixups; i++)
        *cont_fixups[i] = (int)loop_top;
    n_cont_fixups = cont_save[loop_depth - 1];
}
static void pop_loop(int *loop_end) {
    if (loop_depth == 0) return;
    loop_depth--;
    for (int i = break_save[loop_depth]; i < n_break_fixups; i++)
        *break_fixups[i] = (int)loop_end;
    n_break_fixups = break_save[loop_depth];
    n_cont_fixups = cont_save[loop_depth];
}

/* Выход из switch: патчим ТОЛЬКО break'и. continue внутри switch
 * относится к объёмлющему циклу — их фикспейсы остаются висеть
 * до patch_continue внешнего while/for/do (pop_loop их бы обрезал). */
static void pop_switch(int *sw_end) {
    if (loop_depth == 0) return;
    loop_depth--;
    for (int i = break_save[loop_depth]; i < n_break_fixups; i++)
        *break_fixups[i] = (int)sw_end;
    n_break_fixups = break_save[loop_depth];
}

/* ---------- CONST-FOLD: константные выражения без отдельного парсера ----------
 * c4_fold_const: интерпретирует эмитированный хвост байт-кода [from..to]
 * как стек-машину (IMM кладёт в аккумулятор, PSH дублирует на стек,
 * бинарные операции снимают левый операнд со стека). Если весь хвост —
 * чистые вычисления, возвращается 1 и значение. Любая нагрузка
 * (LEA/LI/LC/SI/JSR/JMP/сисколы...) — «не константа», 0.
 * Работает на уровне байт-кода, поэтому одинаков для VM и native (x86). */
static int c4_fold_const(int *from, int *to, int *out)
{
    int st[32];                        /* стек операндов (выражения мелкие) */
    int sp = 0;
    int ax = 0;                        /* аккумулятор (как в VM c4) */
    for (int *c = from; c <= to; c++) {
        switch (*c) {
        case IMM: ax = *++c; break;
        case PSH: if (sp >= 32) return 0; st[sp++] = ax; break;
        case ADD: if (sp < 1) return 0; ax = st[--sp] + ax; break;
        case SUB: if (sp < 1) return 0; ax = st[--sp] - ax; break;
        case MUL: if (sp < 1) return 0; ax = st[--sp] * ax; break;
        case DIV: if (sp < 1 || !ax) return 0; ax = st[--sp] / ax; break;
        case MOD: if (sp < 1 || !ax) return 0; ax = st[--sp] % ax; break;
        case AND: if (sp < 1) return 0; ax = st[--sp] & ax; break;
        case OR:  if (sp < 1) return 0; ax = st[--sp] | ax; break;
        case XOR: if (sp < 1) return 0; ax = st[--sp] ^ ax; break;
        case SHL: if (sp < 1) return 0; ax = st[--sp] << ax; break;
        case SHR: if (sp < 1) return 0; ax = st[--sp] >> ax; break;
        case USHR: if (sp < 1) return 0; ax = (int)((unsigned)st[--sp] >> ax); break;
        case EQ: if (sp < 1) return 0; ax = (st[--sp] == ax); break;
        case NE: if (sp < 1) return 0; ax = (st[--sp] != ax); break;
        case LT: if (sp < 1) return 0; ax = (st[--sp] <  ax); break;
        case GT: if (sp < 1) return 0; ax = (st[--sp] >  ax); break;
        case LE: if (sp < 1) return 0; ax = (st[--sp] <= ax); break;
        case GE: if (sp < 1) return 0; ax = (st[--sp] >= ax); break;
        default: return 0;           /* обращение к памяти/вызов — не константа */
        }
    }
    if (sp) return 0;                /* висячие операнды — не свернулось */
    *out = ax;
    return 1;
}

/* c4_parse_const: разобрать текущее ПОЗИЦИЮ выражение как константу.
 * Выражение парсится обычным expr(Assign) во временный хвост текст-пула,
 * затем сворачивается (c4_fold_const) и ВЕСЬ код откатывается — тот же
 * приём, что в sizeof. Строковые литералы/глобалы дают IMM-метки в
 * сегменте данных — такие «константы» отвергаются проверкой счётчика
 * меток. Возвращает 0 и *out = значение, либо -1 (не константа). */
static int c4_parse_const(int *out)
{
    int *save_e = e;
    int save_imm = c4_n_imm_data_cells;
    int save_jsr = c4_n_jsr_fixups;
    char *save_data = data;
    expr(Assign);
    int v = 0;
    int ok = c4_fold_const(save_e + 1, e, &v) &&
             c4_n_imm_data_cells == save_imm;   /* без строк/адресов данных */
    e = save_e;                                 /* откат кода, меток, пула */
    c4_n_imm_data_cells = save_imm;
    c4_n_jsr_fixups = save_jsr;
    data = save_data;
    if (!ok) return -1;
    *out = v;
    return 0;
}

void stmt()
{
  int *a, *b;
  int *c, *d;

  if (tk == If) {
    next();
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    expr(Assign);
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    *++e = BZ; b = ++e;
    stmt();
    if (tk == Else) { next(); *++e = JMP; a = ++e; *b = (int)(e + 1); stmt(); *a = (int)(e + 1); }
    else *b = (int)(e + 1);
  }
  else if (tk == While) {
    next();
    a = e + 1;
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    expr(Assign);
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    *++e = BZ; b = ++e;
    push_loop();
    stmt();
    patch_continue(a);
    *++e = JMP; *++e = (int)a;
    *b = (int)(e + 1);
    pop_loop(e + 1);
  }
  else if (tk == For) {
    next();
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    if (tk == ';') next();   /* for (;;) */
    else {
      /* C99: for (int i = 0; ...) — объявление счётчика в заголовке
       * (переменная видна до конца функции — упрощение; c4_parse_decls
       * сам съедает ';') */
      int b = c4_base_type();
      if (b >= 0) c4_parse_decls(b, 1);
      else {
        expr(Comma);             /* for (i = 0, j = 10; ...) */
        if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
      }
    }
    a = e + 1;
    b = 0;
    if (tk != ';') {
      expr(Assign);
      *++e = BZ; b = ++e;
    }
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
    if (tk != ')') {
      *++e = JMP; d = ++e;
      c = e + 1;
      expr(Comma);   /* for (...; ...; i++, j--) */
      *++e = JMP; *++e = (int)a;
      *d = (int)(e + 1);
    } else { c = 0; d = 0; }
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    push_loop();
    stmt();
    if (c) { *++e = JMP; *++e = (int)c; }
    else { *++e = JMP; *++e = (int)a; }
    if (b) *b = (int)(e + 1);
    if (c) patch_continue(c); else patch_continue(a);
    pop_loop(e + 1);
  }
  else if (tk == Do) {
    next();
    a = e + 1;
    push_loop();
    stmt();
    patch_continue(a);
    if (tk == While) next(); else { printf("%d: while expected\n", line); exit(-1); }
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    expr(Assign);
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    *++e = BNZ; *++e = (int)a;
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
    pop_loop(e + 1);
  }
  else if (tk == Break) {
    next();
    /* FIX (найден при тестировании switch): фиксап обязан указывать на
     * ОПЕРАНД JMP, а не на ячейку опкода — раньше патч затирал сам JMP
     * адресом цели, и исполнение уходило в мусор («unknown
     * instruction»). break/continue были сломаны с самого порта —
     * тесты t1-t8 их не покрывали. */
    *++e = JMP;
    *++e = 0;
    break_fixups[n_break_fixups++] = e;  /* ячейка операнда — сюда цель */
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
  else if (tk == Continue) {
    next();
    *++e = JMP;
    *++e = 0;
    cont_fixups[n_cont_fixups++] = e;    /* операнд JMP (см. Break) */
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
  else if (tk == Switch) {
    /* switch/case/default — десугаринг в цепочку сравнений со скрытыми
     * локальными слотами (однопроходный парсер без AST не может
     * «сначала все сравнения, потом все тела» — тела эмитятся в
     * исходном порядке, поэтому используется флаговая схема):
     *
     *   __sw = выражение;      __m = 0;        __df = 0;
     *   case K:  if (!__m && __sw == K) __m = 1;   if (__m) тело;
     *   default: if (__df) тело;   вход только «с конца»
     *   хвост-стаб: if (__df) конец; __df = 1; goto default-guard;
     *
     * Флаг __m даёт: grouped labels (case 1: case 2:), fallthrough
     * между телами (тело выполняется, если совпал любой случай выше),
     * пропуск уже проверенных case. Хвост-стаб маршрутизирует путь
     * «ничего не совпало» в default (в любой позиции — первой,
     * средней, последней) и защищает от повторного захода (цикл).
     * break патчится на конец switch (как у циклов); continue
     * внутри switch относится к внешнему циклу.
     *
     * Скрытые слоты выделяются из счётчика локалов с мгновенным
     * перпатчиванием операнда ENT (кадр функции растёт). */
    int sw_slot, m_slot, df_slot;
    int *pending = 0;      /* BZ «тело пропущено» → патчим на след. проверку */
    int *pd_pending = 0;    /* ссылка «пропущено» ПЕРЕД default — патчим позже */
    int *dguard = 0;        /* BZ-ячейка guard'а default (!(df||m) → мимо тела) */
    int has_default = 0;
    next();
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    c4_fn_i += 3;
    sw_slot = c4_fn_i - 2; m_slot = c4_fn_i - 1; df_slot = c4_fn_i;
    if (c4_fn_ent) c4_fn_ent[1] = c4_fn_i - c4_fn_loc;  /* кадр растёт */
    /* __sw = выражение (шаблон FIX [C16b]: LEA; PSH; expr; SI) */
    *++e = LEA; *++e = c4_fn_loc - sw_slot; *++e = PSH;
    expr(Assign);
    *++e = SI;
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    if (tk == '{') next(); else { printf("%d: open brace expected in switch\n", line); exit(-1); }
    /* __m = 0; __df = 0 (ВАЖНО: оба флага обязаны обнуляться при КАЖДОМ
     * входе в switch — слоты кадра переживают итерации циклов (m) и
     * содержат мусор на первом входе (df); без сброса default-ветка
     * ломается со второй итерации / на грязном стеке). */
    *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = PSH; *++e = IMM; *++e = 0; *++e = SI;
    *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = PSH; *++e = IMM; *++e = 0; *++e = SI;
    push_loop();
    while (tk != '}') {
      if (tk == Case) {
        next();
        /* CONST-FOLD: метка case — произвольное константное выражение:
         *   case 1+2:  case (1<<3):  case 'A'+1:  case FLAG|MASK:  case -7:
         * Выражение парсится обычным expr() во временный хвост пула и
         * сворачивается в константу (c4_parse_const; код откатывается).
         * Переменные/вызовы/строки — ошибка компиляции.
         *
         * ДИАПАЗОН (расширение GCC): case 2 ... 6: / case 'a' ... 'z':
         * — после нижней границы ожидаем токен DotDotDot и верхнюю
         * границу (тоже константное выражение). Сравнение __sw == K
         * заменяется на (__sw >= K) && (__sw <= K2) на тех же опкодах
         * (GE/LE/AND), так что VM- и x86-пути работают без изменений
         * бэкенда. Допустима запись и без пробелов (case 2...6:), т.к.
         * лексер узнаёт "..." непосредственно за числом. */
        int K, K2 = 0, is_range = 0;
        if (c4_parse_const(&K)) {
          printf("%d: bad case label (integer constant expression expected)\n", line);
          exit(-1);
        }
        if (tk == DotDotDot) {
          next();
          if (c4_parse_const(&K2)) {
            printf("%d: bad case range upper bound (integer constant expected)\n", line);
            exit(-1);
          }
          if (K2 < K)
            printf("%d: warning: case range %d ... %d is empty (lower bound greater)\n",
                   line, K, K2);
          is_range = 1;
        }
        if (tk == ':') next(); else { printf("%d: colon expected after case\n", line); exit(-1); }
        /* сюда прыгает «тело предыдущего case пропущено» (или отложенная
         * ссылка перед default — она патчится тут же на новую проверку) */
        if (pending) *pending = (int)(e + 1);
        else if (pd_pending) { *pd_pending = (int)(e + 1); pd_pending = 0; }
        /* if (!__m && __sw == K) __m = 1;
         * для диапазона: if (!__m && __sw >= K && __sw <= K2) __m = 1; */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = LI;
        *++e = BNZ; int *bz = ++e;          /* __m != 0 → пропустить сравнение (сохранив флаг) */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = PSH;
        *++e = LEA; *++e = c4_fn_loc - sw_slot; *++e = LI;
        if (!is_range) {
          *++e = PSH; *++e = IMM; *++e = K; *++e = EQ;
        } else {
          /* (__sw >= K): __sw на стеке, IMM K в a, GE берёт левый со стека */
          *++e = PSH; *++e = IMM; *++e = K; *++e = GE;
          *++e = PSH;                        /* сохранить промежуточный итог */
          /* (__sw <= K2): __sw ещё раз из слота, LE — левый со стека */
          *++e = LEA; *++e = c4_fn_loc - sw_slot; *++e = LI;
          *++e = PSH; *++e = IMM; *++e = K2; *++e = LE;
          *++e = AND;                        /* итог: (ge) & (le), оба 0/1 */
        }
        *++e = SI;                          /* __m = результат сравнения */
        *bz = (int)(e + 1);
        /* if (__m) тело — иначе прыжок к следующей проверке */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = LI;
        *++e = BZ; pending = ++e;
      }
      else if (tk == Default) {
        next();
        if (tk == ':') next(); else { printf("%d: colon expected after default\n", line); exit(-1); }
        if (has_default) { printf("%d: duplicate default label\n", line); exit(-1); }
        /* Входящая ссылка «тело предыдущего case пропущено» патчим НЕ
         * сразу: если default окажется последней секцией, она должна
         * вести на хвост-стаб (путь «ничего не совпало»), а не мимо
         * тела. Откладываем до следующей секции / хвоста. */
        pd_pending = pending; pending = 0;
        /* guard: if (__df || __m) { __m = 1; тело default }
         * — fallthrough с совпавшим case выше (m=1) проваливается в
         * тело (строгая семантика C), поток «ещё проверяем» (0|0)
         * тело пропускает, вход с хвост-стаба (df=1) исполняет тело.
         * Установленный __m=1 даёт fallthrough ИЗ default в тела
         * нижележащих case (строгая семантика C). */
        *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = LI;
        *++e = PSH;
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = LI;
        *++e = OR;                             /* a = __df || __m */
        *++e = BZ; pending = ++e; dguard = e;  /* 0 → пропустить тело */
        /* df-вход (BZ не взят): __m = 1 — тела ниже идут по fallthrough */
        *++e = LEA; *++e = c4_fn_loc - m_slot; *++e = PSH;
        *++e = IMM; *++e = 1; *++e = SI;
        has_default = 1;
      }
      else stmt();
    }
    next();  /* '}' */
    if (has_default) {
      /* нормальный выход (fallthrough из последнего тела) — прыжок
       * за хвост-стаб, чтобы не провалиться в него */
      *++e = JMP; int *jend = ++e;
      /* сюда попадает «ни один case не совпал»: последний pending и
       * отложенная ссылка перед default (если default — последняя
       * секция). Первый заход ставит __df=1 и уходит на guard default
       * (тело исполнится; a=1 от SI — BZ guard'а будет пройден),
       * повторный (df уже 1) — сразу в конец (защита от цикла). */
      if (pending) *pending = (int)(e + 1);
      if (pd_pending) *pd_pending = (int)(e + 1);
      *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = LI;
      *++e = BNZ; int *again = ++e;      /* __df == 1 → конец */
      *++e = LEA; *++e = c4_fn_loc - df_slot; *++e = PSH;
      *++e = IMM; *++e = 1; *++e = SI;   /* __df = 1 */
      *++e = JMP; *++e = (int)(dguard - 1);  /* на BZ-инструкцию guard'а */
      *again = (int)(e + 1);
      *jend = (int)(e + 1);
    } else {
      /* default нет: «ничего не совпало» → конец switch */
      if (pending) *pending = (int)(e + 1);
    }
    pop_switch(e + 1);
  }
  else if (tk == Return) {
    next();
    if (tk != ';') expr(Comma);   /* return a, b; — легальный C */
    *++e = LEV;
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
  else if (tk == Goto) {
    /* РАСШИРЕНИЕ 2: goto Label; — переход внутри текущей функции.
     * JMP с нулевым операндом патчится при определении метки
     * (c4_label_define) или сразу, если метка уже определена выше. */
    next();
    if (tk != Id) { printf("%d: label name expected after goto\n", line); exit(-1); }
    int *lsym = id;
    next();
    *++e = JMP;
    *++e = 0;
    int *tgt = c4_label_find(lsym);
    if (tgt) *e = (int)(unsigned long)tgt;      /* метка уже выше */
    else if (c4_n_goto_fixups < C4_MAX_GOTO_FIXUPS) {
      c4_goto_fixups[c4_n_goto_fixups].cell = e;
      c4_goto_fixups[c4_n_goto_fixups].fsym = lsym;
      c4_n_goto_fixups++;
    } else { printf("%d: too many gotos\n", line); exit(-1); }
    if (tk == ';') next(); else { printf("%d: semicolon expected after goto\n", line); exit(-1); }
  }
  else if (IS_QUAL(tk) || tk == Typedef) {
    /* Объявление в глубине блока (расширение C99; в C89 допустимы
     * только в начале блока — их разбирает ветка '{'). Переменная
     * видна до конца функции (упрощённая семантика C99). */
    while (IS_QUAL(tk)) next();
    if (tk == Typedef) { c4_parse_typedef(); }
    else {
      int b = c4_base_type();
      if (b < 0) { printf("%d: type expected after qualifier\n", line); exit(-1); }
      c4_parse_decls(b, 1);
    }
  }
  else if (tk == Id && c4_at_label()) {
    /* РАСШИРЕНИЕ 2: метка Label: — патчит ждущие goto на (e+1).
     * Различение с выражением «x ? a : b»: peek делаем по сырому
     * тексту сразу после идентификатора. */
    int *lsym = id;
    next();   /* идентификатор */
    next();   /* ':' */
    c4_label_define(lsym);
  }
  else if (tk == '{') {
    next();
    /* C89: объявления в начале блока с собственной областью видимости
     * ({ int t = a; ... }) — при '}' записи символов восстанавливаются */
    int sbase = c4_n_scope;
    for (;;) {
      while (IS_QUAL(tk)) next();
      if (tk == Typedef) { c4_parse_typedef(); continue; }
      {
        int b = c4_base_type();
        if (b < 0) break;
        c4_parse_decls(b, 1);
      }
    }
    while (tk != '}') stmt();
    next();
    c4_scope_pop_to(sbase);
  }
  else if (tk == ';') {
    next();
  }
  else {
    /* Объявление в глубине блока (C99-расширение: int x = ...;
     * u32 v = ...;) или оператор-выражение. Токены типов (int/char/
     * unsigned/enum/typedef-имя) не могут начинать выражение, так что
     * различение однозначно. */
    int b = c4_base_type();
    if (b >= 0) {
      c4_parse_decls(b, 1);
    } else {
      expr(Comma);   /* оператор-выражение: допустим оператор «запятая» */
      if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
    }
  }
}

/* ---------- C89: единый разбор базового типа ---------- */

/* Понятная ошибка вместо тихого объявления «double» как int:
 * double/float не поддерживаются (int-only компилятор). */
static void c4_check_not_float(void)
{
    if (tk == Id) {
        const char *nm = (const char *)(unsigned long)id[Name];
        if (!memcmp(nm, "double", 7) || !memcmp(nm, "float", 6)) {
            printf("%d: 'double'/'float' are not supported (int only)\n", line);
            exit(-1);
        }
    }
}

/* enum [Tag] { A, B = 5, C } — тело; тег пропускается, константы
 * регистрируются как Num (работают в case, размерах массивов и т.д.).
 * Допустимы отрицательные значения и значения-константы. */
static void c4_parse_enum(void)
{
    next();                          /* enum */
    if (tk != '{') next();           /* необязательный тег */
    if (tk != '{') return;           /* enum Tag x; — тип уже INT */
    next();
    int i_ev = 0;
    while (tk != '}') {
        if (tk != Id) { printf("%d: bad enum identifier\n", line); exit(-1); }
        int *eid = id;               /* id затирается разбором значения */
        next();
        if (tk == Assign) {
            next();
            /* CONST-FOLD: значение — константное выражение
             * (enum { A = 1<<2, B = A*3 };) через c4_parse_const */
            if (c4_parse_const(&i_ev)) {
                printf("%d: bad enum initializer (integer constant expected)\n", line);
                exit(-1);
            }
        }
        /* id[Tk] = Num: лексер вернёт константу как число (case RED:,
         * int arr[SIZE]; ...) — как у #define-констант. */
        eid[Class] = Num; eid[Type] = INT; eid[Val] = i_ev++; eid[Tk] = Num;
        if (tk == Comma) next();
    }
    next();
}

/* Базовый тип начиная с текущего токена. Возвращает тип (CHAR/INT/
 * INT|UNSIGNED) или -1, если токен — не тип (в этом случае НИ ОДИН
 * токен не потребляется). void обрабатывается как char (историческая
 * семантика c4). typedef-имя возвращает записанный в нём тип.
 * «Мягкие» типы C89: signed игнорируется, long/short = int,
 * unsigned long/long unsigned = unsigned int, unsigned char = char. */
static int c4_base_type(void)
{
    int ty_ = -1, un = 0, seen = 0;
    for (;;) {
        if (tk == Char) { ty_ = CHAR; next(); }              /* и void */
        else if (tk == Int || tk == Long || tk == Short) { if (ty_ < 0) ty_ = INT; next(); }
        else if (tk == Unsigned) { un = 1; next(); }
        else if (tk == Signed) { next(); }
        else if (tk == Enum) { c4_parse_enum(); ty_ = INT; }
        else if (tk == TdefName) { ty_ = id[Type]; next(); }  /* typedef-имя */
        else break;
        seen = 1;
    }
    if (!seen) return -1;
    if (ty_ < 0) ty_ = INT;
    if (un && ty_ == INT) ty_ |= UNSIGNED;
    return ty_;
}

/* typedef int u32, *stringp; — регистрирует имена как ТИПЫ (id[Tk] =
 * Typedef, тип в id[Type]). Указатели поддерживаются; массивы и
 * функции — нет. Допустим и внутри функций. */
static void c4_parse_typedef(void)
{
    next();                          /* typedef */
    while (IS_QUAL(tk)) next();
    int bt = c4_base_type();
    if (bt < 0) { printf("%d: type expected after typedef\n", line); exit(-1); }
    for (;;) {
        int ty_ = bt;
        while (tk == Mul) { next(); ty_ = ty_ + PTR; }
        if (tk != Id) { printf("%d: bad typedef name\n", line); exit(-1); }
        id[Class] = 0; id[Type] = ty_; id[Tk] = TdefName; id[Val] = 0;
        next();
        if (tk == Comma) { next(); continue; }
        break;
    }
    if (tk == ';') next(); else { printf("%d: ';' expected after typedef\n", line); exit(-1); }
}

/* ---------- C89: объявления локальных переменных ----------
 * Общий код для начала функции И начала вложенного блока (и C99-
 * объявлений в глубине блока). Разбирает деклараторы до ';':
 *   int x = 5, *p, a[10], b[] = {1,2}, c[8] = "hi", d[] = "abc";
 * bt    — базовый тип (уже разобран c4_base_type);
 * scope_push — 1: вложенный блок (записи в стек областей видимости);
 *              0: начало функции (дубликаты — ошибка, откат через H*).
 * Слоты выделяются через c4_fn_i (кадр функции растёт, ENT патчится). */
static void c4_parse_decls(int bt, int scope_push)
{
    for (;;) {
        int ty_ = bt;
        while (tk == Mul) { next(); ty_ = ty_ + PTR; }
        while (IS_QUAL(tk)) next();          /* char * const p */
        if (tk != Id) { printf("%d: bad local declaration (tk=%d)\n", line, tk); exit(-1); }
        c4_check_not_float();
        if (!scope_push && id[Class] == Loc) { printf("%d: duplicate local definition\n", line); exit(-1); }
        if (scope_push) c4_scope_push(id);   /* откат при '}' блока */
        id[HClass] = id[Class]; id[Class] = Loc;
        id[HType]  = id[Type];  id[Type] = ty_;
        id[HVal]   = id[Val];   id[Val] = ++c4_fn_i;
        /* ВАЖНО: сохраняем указатель на запись, т.к. next() ниже (при
         * разборе [N]) может найти N как #define'Id-константу и
         * переключить id на запись N. */
        int *arr_id = id;
        next();
        int arr_elems = 0;                   /* 0 = не массив */
        if (tk == Brak) {
            next();
            if (tk == ']') {
                /* «[]»: размер выводится из инициализатора = {...} / = "стр" */
                const char *sv = p;
                while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
                if (*sv == '=') {
                    sv++;
                    while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
                    if (*sv == '{') arr_elems = c4_count_init_list(sv);
                    else if (*sv == '"') arr_elems = c4_count_str_lit(sv);
                }
                if (arr_elems < 1) {
                    printf("%d: local array size cannot be inferred\n", line);
                    exit(-1);
                }
                next();   /* ']' */
            }
            else if (c4_parse_const(&arr_elems) || arr_elems < 0) {
                /* размер — константное выражение (int a[SIZE*2];) через
                 * c4_parse_const; переменные/отрицательные — ошибка */
                printf("%d: bad array size (integer constant expected)\n", line);
                exit(-1);
            }
            if (tk == ']') next();   /* закрывающая скобка */
            if (arr_elems < 1) arr_elems = 1;
            c4_fn_i += arr_elems - 1;
            arr_id[Val] = c4_fn_i;           /* база = НИЖНИЙ слот резервации */
            arr_id[Type] = ty_ | ARR;
        }
        if (tk == Assign) {
            int offset = c4_fn_loc - arr_id[Val];   /* сохранить до смены id */
            next();
            if (arr_elems) {
                /* Инициализатор массива: C89 требует нулевые остатки —
                 * заливаем весь массив через memset-сискол, затем
                 * поэлементные записи. */
                *++e = LEA; *++e = offset; *++e = PSH;
                *++e = IMM; *++e = 0; *++e = PSH;
                *++e = IMM; *++e = arr_elems * (int)sizeof(int); *++e = PSH;
                *++e = MSET; *++e = ADJ; *++e = 3;
                /* АДРЕС ЭЛЕМЕНТА k: локальные char-массивы индексируются
                 * ПОБАЙТОВО (Brak при t==PTR не масштабирует), int-массивы —
                 * по слотам (4 байта). Поэтому:
                 *   int:  LEA (offset + k) — ячейки;
                 *   char: LEA offset; PSH; IMM k; ADD — байты. */
                #define C4_LELEM(k_, ch_) do { \
                    if (ch_) { *++e = LEA; *++e = offset; *++e = PSH; *++e = IMM; *++e = (k_); *++e = ADD; } \
                    else     { *++e = LEA; *++e = offset + (k_); } \
                    *++e = PSH; \
                } while (0)

                if (tk == '{') {
                    next();
                    int i_el = 0;
                    int is_ch_arr = ((ty_ & ~ARR) == CHAR);
                    while (tk && tk != '}') {
                        if (i_el >= arr_elems) {
                            printf("%d: too many initializers for array\n", line);
                            exit(-1);
                        }
                        C4_LELEM(i_el, is_ch_arr);
                        expr(Assign);
                        *++e = is_ch_arr ? SC : SI;
                        i_el++;
                        if (tk == Comma) next();
                    }
                    if (tk == '}') next();
                    else { printf("%d: '}' expected in initializer\n", line); exit(-1); }
                }
                else if (tk == '"' && (ty_ & ~ARR) == CHAR) {
                    /* char b[8] = "строка"; — строка УЖЕ лексирована
                     * (tk == '"' означает: ival = её адрес в данных) */
                    int saddr = ival;
                    while (tk == '"') next();      /* смежные литералы */
                    int slen = 0;
                    while (((char *)(unsigned long)saddr)[slen]) slen++;
                    int n = slen;                  /* NUL уже даст MSET */
                    if (n > arr_elems) n = arr_elems;
                    for (int ci = 0; ci < n; ci++) {
                        *++e = LEA; *++e = offset; *++e = PSH;
                        *++e = IMM; *++e = ci; *++e = ADD; *++e = PSH;
                        *++e = IMM; *++e = saddr + ci;
                        if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS)
                            c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le);
                        *++e = LC; *++e = SC;
                    }
                }
                else {
                    printf("%d: bad array initializer\n", line);
                    exit(-1);
                }
                #undef C4_LELEM
            } else {
                /* Скаляр: LEA offset; PSH; expr; SI/SC (FIX [C16b]) */
                *++e = LEA; *++e = offset; *++e = PSH;
                expr(Assign);
                *++e = (ty_ == CHAR) ? SC : SI;
            }
        }
        if (tk == Comma) { next(); continue; }
        break;
    }
    if (c4_fn_ent) c4_fn_ent[1] = c4_fn_i - c4_fn_loc;   /* кадр вырос */
    if (tk == ';') next(); else { printf("%d: ';' expected after declaration\n", line); exit(-1); }
}

/* FIX (многозадачность): интерпретатор c4 — на глобалах. Раньше вызывался
 * только из kmain, теперь компиляция идёт в задачах (два редактора F9
 * одновременно). Обёртка сериализует выполнение. */
static volatile int c4_run_lock = 0;

int c4_run(const char *src_text, char *out, u32 out_max);
static int c4_run_impl(const char *src_text, char *out, u32 out_max);

int c4_run(const char *src_text, char *out, u32 out_max)
{
    int rc;
    /* РАСШИРЕНИЕ 5: #include разворачивается ДО компиляции.
     * Развёрнутый буфер живёт до конца c4_run_impl (все пути выхода
     * проходят через возврат сюда — включая longjmp из exit()). */
    char *expanded = c4_preprocess(src_text);
    s_lock(&c4_run_lock);
    rc = c4_run_impl(expanded ? expanded : src_text, out, out_max);
    s_unlock(&c4_run_lock);
    if (expanded) free(expanded);
    return rc;
}

static int c4_run_impl(const char *src_text, char *out, u32 out_max)
{
  int bt, poolsz, *idmain;
  int *pc, *sp, *bp, a, cycle;
  int i, *t;

  /* Сбрасываем ВСЕ глобальное состояние.
   * Важно: e, le, sym, data, sp могут быть dangling указателями
   * после предыдущего compile_only вызова (который их free()'нул). */
  c4_out = out; c4_out_pos = 0; c4_out_max = out_max;
  if (c4_out && c4_out_max) c4_out[0] = 0;
  c4_exit_code = 0;
  src = 0; debug = 0;
  n_break_fixups = 0;
  n_cont_fixups = 0;
  loop_depth = 0;
  c4_n_goto_fixups = 0;       /* сброс goto/меток (расширение 2) */
  c4_n_labels = 0;
  c4_n_scope = 0;             /* стек областей видимости (C89 блоки) */
  c4_n_boot = 0;              /* сброс глобальных инициализаторов */
  c4_boot_cell = 0;
  c4_n_imm_data_cells = 0;   /* сброс меток data-ссылок */
  c4_compile_data_base = 0;
  c4_compile_text_base = 0;
  c4_n_jsr_fixups = 0;        /* сброс ссылок на неопределённые функции */
  c4_fn_ent = 0; c4_fn_i = 0; c4_fn_loc = 0;
  /* Сброс dangling указателей */
  e = le = NULL;
  sym = NULL;
  data = NULL;
  id = NULL;
  tk = 0;
  ival = 0;
  ty = 0;
  loc = 0;
  line = 0;
  loop_depth = 0;

  if (__builtin_setjmp(c4_jmp) != 0) {
    /* сюда попадаем после exit() — возвращаем код.
     * FIX [C1]: освобождаем пулы (раньше — утечка 1 МиБ на каждый exit()). */
    c4_free_pools();
    if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0;
    return c4_exit_code;
  }

  poolsz = 256*1024;
  c4_free_pools();   /* FIX [C1]: страховка от прошлых утечек */
  if (!(c4_pool_sym = sym = malloc(poolsz))) { printf("could not malloc(%d) symbol area\n", poolsz); return -1; }
  if (!(c4_pool_text = le = e = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) text area\n", poolsz); return -1; }
  if (!(c4_pool_data = data = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) data area\n", poolsz); return -1; }
  if (!(c4_pool_stack = sp = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) stack area\n", poolsz); return -1; }
  /* Сохраняем исходное начало data pool — нужно для расчёта data_len
   * при dump байт-кода в файл. */
  data_pool_start = data;

  memset(sym,  0, poolsz);
  memset(e,    0, poolsz);
  memset(data, 0, poolsz);

  p = "char else enum if int return sizeof while "
      "for do break continue switch case default unsigned "
      "goto const static volatile extern "
      "typedef signed long short register auto "
      "open read close printf malloc free memset memcmp exit "
      "kinit kquit kdelay kfill ktext kflip krgb kevent kclear kw kh kmtime "
      "strlen strcpy strcmp "
      "win_open win_close win_alive win_clear win_rect win_text win_update "
      "btn_add btn_clicked btn_set_label "
      "delay "
      "void main";
  i = Char; while (i <= Auto) { next(); id[Tk] = i++; }
  i = OPEN; while (i <= STRCMP) { next(); id[Class] = Sys; id[Type] = INT; id[Val] = i++; }
  /* CMScript GUI API — сисколы WOPEN..BSETLB (окна/кнопки) */
  i = WOPEN; while (i <= BSETLB) { next(); id[Class] = Sys; id[Type] = INT; id[Val] = i++; }
  /* delay — дружелюбный алиас kdelay (последнее имя перед void/main) */
  next(); id[Class] = Sys; id[Type] = INT; id[Val] = KDELAY;
  /* void и main — ПОСЛЕ Sys-цикла, чтобы не получить Class=Sys */
  next(); id[Tk] = Char;    /* void → обрабатываем как char */
  next(); idmain = id;       /* main → запоминаем для проверки */

  /* Источник передан в память — не нужен open/read/close */
  lp = p = (char *)(unsigned long)src_text;
  line = 1;
  next();
  while (tk) {
    bt = INT;
    /* Квалификаторы/классы памяти C89 перед типом игнорируются:
     * const int T[] = ...; static int counter; extern void f(int); */
    while (IS_QUAL(tk)) next();
    /* typedef int u32; — имя регистрируется как тип */
    if (tk == Typedef) { c4_parse_typedef(); continue; }
    c4_check_not_float();
    {
      int b = c4_base_type();
      if (b >= 0) bt = b;          /* не тип — прежнее поведение (int) */
    }
    while (tk != ';' && tk != '}') {
      ty = bt;
      while (tk == Mul) { next(); ty = ty + PTR; }
      while (IS_QUAL(tk)) next();   /* char * const p; */
      if (tk != Id) { printf("%d: bad global declaration (tk=%d)\n", line, tk); goto fail; }
      /* Уже зарегистрированный сискол (Class==Sys — printf/win_open/...)
       * прототипом из #include <cmscript.h> НЕ перекрывается: объявление
       * пропускается целиком (имя + параметры + ';', без эмиссии кода). */
      if (id[Class] == Sys) {
        /* встроенная функция: пропустить объявление до ';'. ';' НЕ едим —
         * им завершится цикл деклараторов (как у прототипов). */
        next();
        if (tk == '(') {
          next();                    /* съесть '(' — иначе nest удвоится */
          int nest = 1;
          while (tk && nest > 0) {
            if (tk == '(') nest++;
            else if (tk == ')') nest--;
            next();
          }
        }
        goto fn_decl_done;
      }
      /* Повторное объявление допустимо ТОЛЬКО как «прототип, затем
       * определение» (Fun с Val==0 — см. разбор ниже). */
      if (id[Class] && !(id[Class] == Fun && id[Val] == 0)) { printf("%d: duplicate global definition\n", line); goto fail; }
      next();
      id[Type] = ty;
      if (tk == '(') {
        int *fn_id = id;   /* ЗАПИСАЛИ: id затирается парсингом параметров */
        id[Class] = Fun;
        id[Val] = (int)(e + 1);
        next(); i = 0;
        while (tk != ')') {
          /* f(void): «void» с последующей ')' — пустой список параметров
           * (C89), без фантомного слота. void и char — один токен, поэтому
           * проверяем сырое слово: «void» (4 байта) ровно перед p. */
          if (tk == Char && c4_raw_peek(')') && !memcmp(p - 4, "void", 4)) { next(); break; }
          ty = INT;
          /* квалификаторы в параметрах: const void *a, unsigned long... */
          while (IS_QUAL(tk)) next();
          {
            int pbt = c4_base_type();
            if (pbt >= 0) ty = pbt;   /* K&R-стиль без типа: считаем int */
          }
          while (tk == Mul) { next(); ty = ty + PTR; }
          while (IS_QUAL(tk)) next();   /* char * const p */
          if (tk == Comma || tk == ')') {
            /* анонимный параметр (прототип): слот резервируем, имя не объявляем */
            i++;
            if (tk == Comma) next();
            continue;
          }
          if (tk != Id) { printf("%d: bad parameter declaration (tk=%d)\n", line, tk); goto fail; }
          if (id[Class] == Loc) { printf("%d: duplicate parameter definition\n", line); goto fail; }
          id[HClass] = id[Class]; id[Class] = Loc;
          id[HType]  = id[Type];  id[Type] = ty;
          id[HVal]   = id[Val];   id[Val] = i++;
          next();
          if (tk == Comma) next();
        }
        next();
        if (tk == ';') {
          /* Прототип функции: объявление без тела. ';' НЕ потребляем —
           * им завершится цикл деклараторов (как у int g;). Val=0
           * помечает «ещё не определена»: вызовы до определения дают
           * JSR 0 + запись в c4_jsr_fixups (патчится в конце файла).
           * Параметры уже записаны как Loc — возвращаем их прежние
           * атрибуты (как это делает конец разбора определения).
           * ВАЖНО: id указывает на ПОСЛЕДНИЙ параметр, а не на функцию —
           * поэтому патчим через сохранённый fn_id. */
          fn_id[Val] = 0;
          id = sym;
          while (id[Tk]) {
            if (id[Class] == Loc) {
              id[Class] = id[HClass]; id[Type] = id[HType]; id[Val] = id[HVal];
            }
            id = id + Idsz;
          }
          goto fn_decl_done;   /* пропустить разбор тела */
        }
        if (tk != '{') { printf("%d: bad function definition\n", line); goto fail; }
        loc = ++i;
        c4_fn_loc = loc;   /* синхронизация для switch (stmt() их не видит) */
        /* РАСШИРЕНИЕ 2: таблицы goto/меток — свои на каждую функцию */
        c4_n_goto_fixups = 0;
        c4_n_labels = 0;
        /* FIX [C16]: эмитим ENT (пролог) ПЕРВЫМ, с операндом-заглушкой.
         * Раньше код инициализаторов `int x = expr;` попадал ВЫШЕ ENT и
         * исполнялся с bp ВЫЗЫВАЮЩЕГО: порча кадра вызываемого, локалы
         * оставались мусором, VM сходила с рельсов. Теперь операнд
         * (число слотов) патчится после разбора объявлений. */
        int *fn_ent = e + 1;
        c4_fn_ent = fn_ent;   /* для switch: перпатч операнда ENT */
        *++e = ENT; *++e = 0;
        /* Таблицы областей видимости/слоты — свои на каждую функцию */
        c4_n_scope = 0;
        c4_fn_i = i;          /* слоты теперь выделяет c4_parse_decls */
        next();
        /* C89: объявления в начале функции (int x = 5, *p, a[10] = {...};
         * typedef ...;) — общий код с вложенными блоками */
        for (;;) {
          while (IS_QUAL(tk)) next();
          if (tk == Typedef) { c4_parse_typedef(); continue; }
          {
            int b = c4_base_type();
            if (b < 0) break;
            c4_parse_decls(b, 0);
          }
        }
        i = c4_fn_i;
        fn_ent[1] = i - loc;   /* FIX [C16]: патчим операнд ENT */
        c4_fn_i = i;           /* синхронизация счётчика слотов для switch */
        while (tk != '}') stmt();
        *++e = LEV;
        /* РАСШИРЕНИЕ 2: незакрытые goto — ошибка компиляции */
        if (c4_n_goto_fixups > 0) {
          int *fid = c4_goto_fixups[0].fsym;
          printf("%d: undefined label '%s'\n", line, (char *)(unsigned long)fid[Name]);
          goto fail;
        }
        c4_n_goto_fixups = 0;
        c4_n_labels = 0;
        id = sym;
        while (id[Tk]) {
          if (id[Class] == Loc) {
            id[Class] = id[HClass];
            id[Type] = id[HType];
            id[Val] = id[HVal];
          }
          id = id + Idsz;
        }
      }
      else {
        id[Class] = Glo;
        id[Val] = (int)(unsigned long)data;
        /* Сохраняем указатель на запись массива, т.к. next() ниже
         * может переключить id на другую запись (если размер —
         * #define'Id-константа). Без этого флаг ARR запишется не туда. */
        int *glo_id = id;
        int is_arr = 0, arr_elems = 1, base_ty = ty & ~ARR;

        /* Поддержка массивов: int a[10]; const char *MON[] = {...}; */
        if (tk == Brak) {
          is_arr = 1;
          next();
          if (tk == ']') {
            /* «[]»: размер выводится из инициализатора "= { ... }"
             * или "= \"строка\"" — сырой скан (однопроходный парсер
             * не умеет «сначала посчитать, потом парсить»). */
            const char *sv = p;
            while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
            if (*sv == '=') {
              sv++;
              while (*sv == ' ' || *sv == '\t' || *sv == '\r' || *sv == '\n') sv++;
              if (*sv == '{') arr_elems = c4_count_init_list(sv);
              else if (*sv == '"') arr_elems = c4_count_str_lit(sv);
            }
            if (tk == ']') next();
          }
          /* размер — константное выражение (char buf[SIZE/2 + 1];) через
           * c4_parse_const; переменные — ошибка (C89) */
          else if (c4_parse_const(&arr_elems) || arr_elems < 0) {
            printf("%d: bad array size (integer constant expected)\n", line);
            exit(-1);
          }
          if (tk == ']') next();   /* закрывающая скобка */
          if (arr_elems < 1) arr_elems = 1;
          data = data + (base_ty == CHAR ? 1 : (int)sizeof(int)) * arr_elems;
          /* base_ty, а НЕ ty: c4_parse_const внутри (expr) затирает
           * глобальный ty — иначе char G2[8] получает тип int[8]. */
          glo_id[Type] = base_ty | ARR;
        } else {
          data = data + sizeof(int);
        }

        /* ГЛОБАЛЬНЫЕ ИНИЦИАЛИЗАТОРЫ: int K = 5; const char *MSG = "...";
         * int A[3] = {1, 2, 3}; char S[] = "строка"; — код записи
         * собирается в отдельный «чанк»-функцию; при запуске boot-код
         * вызывает чанки до main. Строковая инициализация char-массива
         * копируется прямо в сегмент данных (без чанка). */
        if (tk == Assign) {
          next();
          if (is_arr && base_ty == CHAR && tk == '"') {
            /* char S[] = "abc"; / char S[10] = "hi"; — статическая
             * инициализация: строка уже лежит в сегменте данных (её
             * только что лексировали), копируем байты прямо в слот
             * массива. Остаток массива остаётся нулевым (C89). */
            int saddr = ival;
            while (tk == '"') next();      /* смежные литералы */
            int slen = 0;
            while (((char *)(unsigned long)saddr)[slen]) slen++;
            int n = slen + 1;              /* вместе с NUL */
            if (n > arr_elems) n = arr_elems;
            memcpy((char *)(unsigned long)glo_id[Val],
                   (char *)(unsigned long)saddr, n);
          } else {
            /* адрес элемента i на стек: IMM addr; PSH */
            #define C4_GSTORE(gid, bty, idx) do { \
                unsigned long a_ = (unsigned long)(gid)[Val] + \
                    ((bty) == CHAR ? (unsigned long)(idx) : (unsigned long)(idx) * sizeof(int)); \
                *++e = IMM; *++e = (int)a_; \
                if (c4_n_imm_data_cells < C4_MAX_IMM_MARKS) \
                    c4_imm_data_cells[c4_n_imm_data_cells++] = (u32)(e - le); \
                *++e = PSH; \
            } while (0)

            int *chunk = e + 1;              /* начало чанка (ENT) */
            *++e = ENT; *++e = 0;            /* пролог чанка-функции */
            if (tk == '{') {
              /* список: { e0, e1, ... } */
              next();
              int i_el = 0;
              while (tk && tk != '}') {
                if (is_arr && i_el >= arr_elems) {
                  printf("%d: too many initializers for array\n", line);
                  exit(-1);
                }
                C4_GSTORE(glo_id, base_ty, i_el);
                expr(Assign);
                *++e = (base_ty == CHAR) ? SC : SI;
                i_el++;
                if (tk == Comma) next();
              }
              if (tk == '}') next(); else { printf("%d: '}' expected in initializer\n", line); exit(-1); }
            } else {
              if (is_arr) {
                printf("%d: brace list expected in array initializer\n", line);
                exit(-1);
              }
              C4_GSTORE(glo_id, base_ty, 0);
              expr(Assign);
              *++e = (base_ty == CHAR) ? SC : SI;
            }
            *++e = LEV;                      /* эпилог чанка */
            if (c4_n_boot < C4_MAX_BOOT) {
              c4_boot_chunks[c4_n_boot++] = chunk;
            } else {
              printf("%d: too many global initializers\n", line);
              exit(-1);
            }
            #undef C4_GSTORE
          }
        }
      }
fn_decl_done: ;   /* сюда попадает разбор прототипа (без тела) */
      if (tk == Comma) next();
    }
    next();
  }

  /* Патчим вызовы функций, встреченные ДО их определения (прототипы).
   * К этому моменту разобраны все определения; незакрытые ссылки —
   * ошибка компиляции. Операнд JSR — абсолютный адрес байт-кода. */
  for (i = 0; i < c4_n_jsr_fixups; i++) {
    int *fid = c4_jsr_fixups[i].fid;
    if (fid[Val] == 0) {
      printf("%d: function '%s' used but not defined\n", line,
             (char *)(unsigned long)fid[Name]);
      goto fail;
    }
    *c4_jsr_fixups[i].cell = fid[Val];
  }

  if (!(pc = (int *)idmain[Val])) { printf("main() not defined\n"); goto fail; }

  /* Boot-код глобальных инициализаторов: JSR по чанкам, затем JMP main.
   * Точка входа смещается на boot, если инициализаторы были. */
  if (c4_n_boot > 0) {
    /* boot начнётся с ячейки e+1 (индекс от начала пула le) */
    c4_boot_cell = (u32)(((int)(unsigned long)(e + 1) - (int)(unsigned long)le) / (int)sizeof(int));
    for (int bi = 0; bi < c4_n_boot; bi++) {
      *++e = JSR;
      *++e = (int)(unsigned long)c4_boot_chunks[bi];
    }
    *++e = JMP;
    *++e = (int)(unsigned long)idmain[Val];
  }

  if (src) { if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0; c4_free_pools(); return 0; }


  /* ---------- N2600-OS: compile-only mode (для c4_x86.c) ----------
   * Если выставлен флаг c4_compile_only, мы сохраняем байт-код и сегмент
   * данных в caller-предоставленные буферы и возвращаемся БЕЗ запуска VM.
   * Это позволяет c4_compile() получить IR для дальнейшей обработки. */
  if (c4_compile_only) {
    u32 text_cells = (u32)((int)(unsigned long)e - (int)(unsigned long)le) / sizeof(int) + 1;
    u32 entry_cells = c4_boot_cell
        ? c4_boot_cell
        : (((u32)(unsigned long)idmain[Val] - (u32)(unsigned long)le) / sizeof(int));
    u32 data_len = 0;
    if (data_pool_start) {
      data_len = (u32)((unsigned long)data - (unsigned long)data_pool_start);
    }
    if (c4_compile_bc_buf && c4_compile_bc_max >= text_cells * 4) {
      memcpy(c4_compile_bc_buf, le, text_cells * 4);
      c4_compile_bc_len_cells = text_cells;
    }
    if (c4_compile_data_buf && c4_compile_data_max >= data_len) {
      memcpy(c4_compile_data_buf, data_pool_start, data_len);
      c4_compile_data_len = data_len;
    }
    c4_compile_entry_cells = entry_cells;
    c4_idmain_val_saved = (int *)idmain[Val];
    /* база сегмента данных для c4_x86 (пересчёт адресов в смещения) */
    if (data_pool_start)
        c4_compile_data_base = (u32)(unsigned long)data_pool_start;
    /* база текст-пула: цели переходов в байт-коде — указатели le+cell */
    c4_compile_text_base = (u32)(unsigned long)le;
    data_pool_start = NULL;
    c4_free_pools();   /* FIX [C1]: единая точка освобождения */
    return 0;
  }

  /* ---------- N2600-OS: сохранение байт-кода в .bin рядом с .c ---------- */
  if (c4_save_bin_name) {
    /* Точка входа main — абсолютный адрес idmain[Val]. Байт-код начинается
     * с le (pool start). Длина text в int-ячейках: (e - le) + 1.
     * Длина data = текущий data - data_pool_start (исходное начало). */
    u32 text_cells = (u32)((int)(unsigned long)e - (int)(unsigned long)le) / sizeof(int) + 1;
    u32 entry_cells = c4_boot_cell
        ? c4_boot_cell
        : (((u32)(unsigned long)idmain[Val] - (u32)(unsigned long)le) / sizeof(int));
    u32 data_len = 0;
    if (data_pool_start) {
      data_len = (u32)((unsigned long)data - (unsigned long)data_pool_start);
    }

    u32 total_size = 16 + text_cells * 4 + data_len;
    int saved = 0;
    if (ramfs_ready()) {
      ramfs_delete(c4_save_bin_name);
      if (ramfs_create(c4_save_bin_name, total_size)) {
        u8 *buf = (u8 *)malloc(total_size);
        if (buf) {
          buf[0]='C'; buf[1]='4'; buf[2]='B'; buf[3]='1';
          buf[4] = (u8)(entry_cells & 0xFF);
          buf[5] = (u8)((entry_cells >> 8) & 0xFF);
          buf[6] = (u8)((entry_cells >> 16) & 0xFF);
          buf[7] = (u8)((entry_cells >> 24) & 0xFF);
          buf[8]  = (u8)(text_cells & 0xFF);
          buf[9]  = (u8)((text_cells >> 8) & 0xFF);
          buf[10] = (u8)((text_cells >> 16) & 0xFF);
          buf[11] = (u8)((text_cells >> 24) & 0xFF);
          buf[12] = (u8)(data_len & 0xFF);
          buf[13] = (u8)((data_len >> 8) & 0xFF);
          buf[14] = (u8)((data_len >> 16) & 0xFF);
          buf[15] = (u8)((data_len >> 24) & 0xFF);
          memcpy(buf + 16, le, text_cells * sizeof(int));
          if (data_len > 0 && data_pool_start) {
            memcpy(buf + 16 + text_cells * 4, data_pool_start, data_len);
          }
          ramfs_write(c4_save_bin_name, buf, total_size);
          free(buf);
          saved = 1;
        }
      }
    }
    if (c4_out && c4_out_pos < c4_out_max) {
      if (saved) {
        char msg[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(msg, sizeof(msg),
                 "[c4] compiled OK: %u text cells, %u data bytes, saved as %s",
                 (unsigned)text_cells, (unsigned)data_len, c4_save_bin_name);
        c4_puts(msg);
        c4_putc('\n');
      } else {
        c4_puts("[c4] failed to save binary (RAMFS error)\n");
      }
    }
    c4_save_bin_name = NULL;
    data_pool_start = NULL;
    c4_free_pools();   /* FIX [C1]: единая точка освобождения */
    return 0;
  }

  // setup stack
  bp = sp = (int *)((int)(unsigned long)sp + poolsz);
  *--sp = EXIT;
  *--sp = PSH; t = sp;
  *--sp = 0;
  *--sp = (int)(unsigned long)"";
  *--sp = (int)(unsigned long)t;
  /* boot глобальных инициализаторов: стартуем с boot-кода, не с main */
  if (c4_boot_cell) pc = le + c4_boot_cell;

  /* run
   * ВАЖНО: после возврата из main() (LEV), pc указывает на СТЕК,
   * где лежат PSH+EXIT (см. setup ниже). Это НЕ байт-код!
   * Поэтому bounds check на pc НЕЛЬЗЯ делать — он даёт ложное срабатывание. */
  cycle = 0;
  while (1) {
    /* Лимит циклов: предотвращаем бесконечный цикл (10 млн) */
    if (cycle > 10000000) {
      printf("cycle limit exceeded (10M)! possible infinite loop\n");
      c4_free_pools();   /* FIX [C1] */
      return -1;
    }
    i = *pc++; ++cycle;
    if (debug) {
      printf("%d> %.4s", cycle,
        &"LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,"
         "OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,"
         "OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,"[i * 5]);
      if (i <= ADJ) printf(" %d\n", *pc); else printf("\n");
    }
    if      (i == LEA) a = (int)(unsigned long)(bp + *pc++);
    else if (i == IMM) a = *pc++;
    else if (i == JMP) pc = (int *)*pc;
    else if (i == JSR) { *--sp = (int)(unsigned long)(pc + 1); pc = (int *)*pc; }
    else if (i == BZ)  pc = a ? pc + 1 : (int *)*pc;
    else if (i == BNZ) pc = a ? (int *)*pc : pc + 1;
    else if (i == ENT) { *--sp = (int)(unsigned long)bp; bp = sp; sp = sp - *pc++; }
    else if (i == ADJ) sp = sp + *pc++;
    else if (i == LEV) { sp = bp; bp = (int *)*sp++; pc = (int *)*sp++; }
    else if (i == LI)  a = *(int *)a;
    else if (i == LC)  a = *(char *)a;
    else if (i == SI)  *(int *)*sp++ = a;
    else if (i == SC)  a = *(char *)*sp++ = a;
    else if (i == PSH) *--sp = a;

    else if (i == OR)  a = *sp++ |  a;
    else if (i == XOR) a = *sp++ ^  a;
    else if (i == AND) a = *sp++ &  a;
    else if (i == EQ)  a = *sp++ == a;
    else if (i == NE)  a = *sp++ != a;
    else if (i == LT)  a = *sp++ <  a;
    else if (i == GT)  a = *sp++ >  a;
    else if (i == LE)  a = *sp++ <= a;
    else if (i == GE)  a = *sp++ >= a;
    else if (i == SHL) a = *sp++ << a;
    else if (i == SHR) a = *sp++ >> a;
    else if (i == USHR) a = (int)((u32)*sp++ >> ((u32)a & 31u));  /* логический сдвиг: unsigned >> */
    else if (i == ADD) a = *sp++ +  a;
    else if (i == SUB) a = *sp++ -  a;
    else if (i == MUL) a = *sp++ *  a;
    else if (i == DIV) {
        /* FIX [C35]: деление на ноль в c4-программе вызывало исключение #0
         * CPU -> exc_panic -> ПАНИКА ВСЕЙ СИСТЕМЫ (VM не защищена setjmp).
         * Внимание: делитель — аккумулятор a (правый операнд), делимое в стеке. */
        if (a == 0) { printf("divide by zero\n"); exit(-1); }
        a = *sp++ /  a;
    }
    else if (i == MOD) {
        /* FIX [C35]: аналогично для остатка. */
        if (a == 0) { printf("modulo by zero\n"); exit(-1); }
        a = *sp++ %  a;
    }

    else if (i == OPEN) a = -1; /* не поддерживается */
    else if (i == READ) a = -1;
    else if (i == CLOS) a = 0;
    else if (i == PRTF) { t = sp + pc[1]; a = c4_vm_printf((const char *)(unsigned long)t[-1],
                                t[-2], t[-3], t[-4], t[-5], t[-6], t[-7]); }
    else if (i == MALC) a = (int)(unsigned long)malloc((u32)*sp);
    else if (i == FREE) free((void *)(unsigned long)*sp);
    else if (i == MSET) a = (int)(unsigned long)memset((void *)(unsigned long)sp[2], sp[1], (u32)*sp);
    else if (i == MCMP) a = memcmp((const void *)(unsigned long)sp[2], (const void *)(unsigned long)sp[1], (u32)*sp);
    else if (i == EXIT) { int code = *sp; /* FIX: код выхода читаем ДО free — sp указывает в пул стека! */ if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0; c4_free_pools(); return code; } /* FIX [C1] */
    /* ============== N2600-OS: SDL2-подобные сисколы ============== */
    /* Стек c4 после всех PSH: sp[0]=последний аргумент, sp[1]=предыд., ...
     * ADJ потом всё уберет (sp += argcount). */
    else if (i == KINIT)   a = 0;                              /* no-op: контекст уже есть */
    else if (i == KQUIT)   a = 0;                              /* no-op */
    else if (i == KDELAY) {
        /* kdelay(ms): уступить CPU на ms миллисекунд
         * (сессия 33: 1 тик = 1 мс при PIT 1000 Гц) */
        u32 start = timer_ticks();
        u32 need = (u32)*sp;
        if (need == 0) need = 1;
        while ((timer_ticks() - start) < need) task_yield();
        a = 0;
    }
    else if (i == KFILL) {
        /* kfill(x, y, w, h, color) — заливка прямоугольника.
         * Через c4gfx: ленивое окно с canvas (прямой вывод на экран
         * стирается композитором многопоточного WM). */
        c4_gfx_fill_rect(sp[4], sp[3], sp[2], sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == KTEXT) {
        /* ktext(x, y, s, fg, bg) — вывести строку */
        c4_gfx_text(sp[4], sp[3], (const char *)(unsigned long)sp[2],
                    (u32)sp[1], (int)sp[0]);
        a = 0;
    }
    else if (i == KFLIP) {
        /* kflip() — показать нарисованное (область окна на экране) */
        c4_gfx_flip(NULL);
        a = 0;
    }
    else if (i == KRGB) {
        /* krgb(r, g, b) — получить цвет; возвращает 32-битное ARGB */
        a = (int)fb_rgb((u8)sp[2], (u8)sp[1], (u8)sp[0]);
    }
    else if (i == KEVENT) {
        /* kevent(out_buf) — получить следующее событие ввода.
         * Возвращает 0=нет события, 1=клавиша, 2=мышь, 3=выход (Esc).
         * Формат буфера для клавиши: buf[0]=ch, buf[1]=code, buf[2]=flags
         * Формат для мыши: buf[0..3]=dx_lo, dx_hi, dy_lo, dy_hi, buf[4]=buttons */
        char *out = (char *)(unsigned long)sp[0];
        if (out) {
            /* FIX: события читаем из очереди ОКНА программы (c4gfx):
             * глобальную kbd-очередь вытягивает kmain (wm_key) —
             * раньше события до c4-программ не доходили ВООБЩЕ. */
            a = c4_gfx_event_poll(out);
        } else a = 0;
    }
    else if (i == KCLEAR) {
        /* kclear(color) — залить canvas цветом */
        c4_gfx_fill_screen((u32)*sp);
        a = 0;
    }
    else if (i == KW) {
        /* kwidth() — ширина области рисования (canvas окна) */
        a = (int)c4_gfx_width();
    }
    else if (i == KH) {
        /* kheight() — высота области рисования (canvas окна) */
        a = (int)c4_gfx_height();
    }
    else if (i == KMTIME) {
        /* kmtime() — текущее время в миллисекундах (1 тик = 1 мс) */
        a = (int)timer_ticks();
    }
    /* ===== Строковые операции ===== */
    else if (i == STRLEN) {
        /* strlen(s) — длина NUL-terminated строки */
        char *s = (char *)(unsigned long)sp[0];
        int len = 0;
        while (s && s[len]) len++;
        a = len;
    }
    else if (i == STRCPY) {
        /* strcpy(dst, src) — копирование строки */
        char *dst = (char *)(unsigned long)sp[1];
        char *src = (char *)(unsigned long)sp[0];
        if (dst && src) {
            int j = 0;
            while (src[j]) { dst[j] = src[j]; j++; }
            dst[j] = 0;
        }
        a = (int)(unsigned long)dst;
    }
    else if (i == STRCMP) {
        /* strcmp(a, b) — сравнение строк: 0=равны, <0=a<b, >0=a>b */
        char *a_s = (char *)(unsigned long)sp[1];
        char *b_s = (char *)(unsigned long)sp[0];
        a = 0;
        if (a_s && b_s) {
            int j = 0;
            while (a_s[j] && b_s[j] && a_s[j] == b_s[j]) j++;
            a = (int)(unsigned char)a_s[j] - (int)(unsigned char)b_s[j];
        }
    }
    /* ===== CMScript GUI API (VM-путь, через c4_gui_api; native — через kapi) ===== */
    else if (i == WOPEN) {
        const char *title = (const char *)(unsigned long)sp[4];
        a = (c4_gui_api && c4_gui_api->win_open)
            ? c4_gui_api->win_open(title, sp[3], sp[2], sp[1], (int)sp[0]) : -1;
    }
    else if (i == WCLOSE) {
        int id_w = (int)sp[0];
        if (c4_gui_api && c4_gui_api->win_close) c4_gui_api->win_close(id_w);
        a = 0;
    }
    else if (i == WALIVE) {
        int id_w = (int)sp[0];
        a = (c4_gui_api && c4_gui_api->win_alive) ? c4_gui_api->win_alive(id_w) : 0;
    }
    else if (i == WCLEAR) {
        if (c4_gui_api && c4_gui_api->win_clear) c4_gui_api->win_clear((int)sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == WRECT) {
        if (c4_gui_api && c4_gui_api->win_rect)
            c4_gui_api->win_rect((int)sp[5], sp[4], sp[3], sp[2], sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == WTEXT) {
        if (c4_gui_api && c4_gui_api->win_text)
            c4_gui_api->win_text((int)sp[4], sp[3], sp[2],
                                 (const char *)(unsigned long)sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == WUPD) {
        if (c4_gui_api && c4_gui_api->win_update) c4_gui_api->win_update((int)sp[0]);
        a = 0;
    }
    else if (i == BADD) {
        a = (c4_gui_api && c4_gui_api->btn_add)
            ? c4_gui_api->btn_add((int)sp[5], sp[4], sp[3], sp[2], sp[1],
                                  (const char *)(unsigned long)sp[0]) : -1;
    }
    else if (i == BCLICK) {
        a = (c4_gui_api && c4_gui_api->btn_clicked) ? c4_gui_api->btn_clicked((int)sp[0]) : -1;
    }
    else if (i == BSETLB) {
        if (c4_gui_api && c4_gui_api->btn_set_label)
            c4_gui_api->btn_set_label((int)sp[2], (int)sp[1],
                                      (const char *)(unsigned long)sp[0]);
        a = 0;
    }
    else { printf("unknown instruction = %d! cycle = %d\n", i, cycle); c4_free_pools(); return -1; } /* FIX [C1] */
  }

fail:
  /* FIX [C1]: все ошибки компиляции освобождают пулы (раньше — утечка 1 МиБ).
   * ВАЖНО: метка обязана стоять ПОСЛЕДНЕЙ в c4_run — иначе нормальный путь
   * проваливается в неё. */
  c4_free_pools();
  return -1;
}


/* ---------- N2600-OS: c4_compile — вынести фазу компиляции отдельно ---------- */

/* c4_compile: скомпилировать исходник в байт-код (без запуска VM).
 *   src              — C-исходник (NUL-terminated)
 *   out              — буфер для диагностики ошибок
 *   out_max          — размер out
 *   bytecode         — куда записать пул байт-кода (int-ячейки)
 *   bytecode_max     — ёмкость в байтах
 *   bytecode_len_cells — записанная длина в int-ячейках (вых. параметр)
 *   data_seg         — куда записать сегмент данных
 *   data_seg_max     — ёмкость в байтах
 *   data_seg_len     — записанная длина в байтах (вых. параметр)
 *   entry_offset     — смещение main в int-ячейках от начала bytecode
 * Возвращает: 1 при успехе, 0 при ошибке компиляции. */
int c4_compile(const char *src, char *out, u32 out_max,
               void *bytecode, u32 bytecode_max, u32 *bytecode_len_cells,
               void *data_seg, u32 data_seg_max, u32 *data_seg_len,
               u32 *entry_offset)
{
    /* Настраиваем caller-буферы для c4_run (compile-only mode) */
    c4_compile_only = 1;
    c4_compile_bc_buf = (u8 *)bytecode;
    c4_compile_bc_max = bytecode_max;
    c4_compile_bc_len_cells = 0;
    c4_compile_data_buf = (u8 *)data_seg;
    c4_compile_data_max = data_seg_max;
    c4_compile_data_len = 0;
    c4_compile_entry_cells = 0;

    int r = c4_run(src, out, out_max);

    /* Сбрасываем флаги */
    c4_compile_only = 0;
    c4_compile_bc_buf = NULL;
    c4_compile_bc_max = 0;
    c4_compile_data_buf = NULL;
    c4_compile_data_max = 0;

    if (r != 0) {
        /* ошибка компиляции — c4_run вернул -1, диагностика в out */
        return 0;
    }

    /* Успешная компиляция — возвращаем результаты */
    if (bytecode_len_cells) *bytecode_len_cells = c4_compile_bc_len_cells;
    if (data_seg_len) *data_seg_len = c4_compile_data_len;
    if (entry_offset) *entry_offset = c4_compile_entry_cells;
    return 1;
}

/* c4_print_str: вывод строки в текущий выходной буфер c4 (если есть). */
void c4_print_str(const char *s, u32 len)
{
    if (!s) return;
    for (u32 i = 0; i < len; i++) c4_putc(s[i]);
}

/* c4_event_poll: опрос события ввода для c4-программ (нативных).
 * Паритет с VM-версией kevent: Esc → код 3 (выход). */
int c4_event_poll(void *out_buf)
{
    if (!out_buf) return 0;
    u8 *out = (u8 *)out_buf;
    key_event_t ev;
    if (kbd_pop(&ev)) {
        out[0] = ev.ch;
        out[1] = (u8)ev.code;
        out[2] = (u8)ev.flags;
        if (ev.ch == 0x1B || ev.code == 0x01) return 3;
        return 1;
    }
    return 0;
}

/* c4_printf_va: formatted print для native c4-программ.
 *   fmt           — форматная строка (с %d/%s/%c/%x)
 *   nargs         — число аргументов ВКЛЮЧАЯ fmt (как в c4 PRTF)
 *   args_reversed — массив аргументов (без fmt) в ОБРАТНОМ порядке
 *                  args_reversed[0] = последний аргумент в source
 *                  args_reversed[actual_args-1] = первый аргумент в source
 * Возвращает число записанных символов (в VM PRTF кладёт его в "a").
 * Запись идёт в текущий буфер c4_out. */
int c4_printf_va(const char *fmt, int nargs, int *args_reversed)
{
    if (!fmt) return 0;
    int nprinted = 0;
    int actual = nargs - 1;   /* args excluding fmt */
    if (actual < 0) actual = 0;
    int argidx = 0;   /* индекс следующего аргумента в source order */

    while (*fmt) {
        if (*fmt != '%') { c4_putc(*fmt++); nprinted++; continue; }
        fmt++;   /* skip '%' */
        if (*fmt == 'l') fmt++;   /* %ld/%lu/%lx — модификатор длины игнорируем */
        if (*fmt == 'd') {
            if (argidx < actual) {
                /* i-th arg in source = args_reversed[actual-1-argidx] */
                int val = args_reversed[actual - 1 - argidx];
                c4_putint(val);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 'u') {
            /* %u — беззнаковое десятичное (C89) */
            if (argidx < actual) {
                unsigned v = (unsigned)args_reversed[actual - 1 - argidx];
                c4_putudec(v);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 's') {
            if (argidx < actual) {
                const char *s = (const char *)(unsigned long)args_reversed[actual - 1 - argidx];
                if (s) { while (*s) { c4_putc(*s++); nprinted++; } }
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 'c') {
            if (argidx < actual) {
                char c = (char)args_reversed[actual - 1 - argidx];
                c4_putc(c);
                nprinted++;
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 'x') {
            if (argidx < actual) {
                unsigned v = (unsigned)args_reversed[actual - 1 - argidx];
                c4_puthex(v);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == '%') {
            c4_putc('%');
            nprinted++;
            fmt++;
        }
        else {
            /* Unknown format spec — output as-is */
            c4_putc('%');
            nprinted++;
            if (*fmt) { c4_putc(*fmt); nprinted++; fmt++; }
        }
    }
    return nprinted;
}

