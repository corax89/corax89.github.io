/* Minimal libretro frontend to reproduce the user's RetroArch environment.
 * Usage: lr_run <core.so> <game.jar> <max_frames> <out_dir> [press_every]
 * Saves PPM snapshots every 500 frames + the last frame; logs video size.
 * Auto-presses joypad A (Fire/5) every `press_every` frames for 60 frames.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <dlfcn.h>
#include <signal.h>
#include <execinfo.h>
#include <unistd.h>
#include <time.h>
#include <ucontext.h>

/* SIGFPE/SIGSEGV handler: symbolized backtrace and exit.
 * v34.49: ucontext mcontext access made libc-portable (glibc uses
 * uc_mcontext.gregs[REG_RIP]; musl/bionic variants expose __gregs or
 * nothing at all) — the RIP value is now read through a guarded macro
 * and defaults to si_addr when unavailable. */
#if defined(__x86_64__) && defined(REG_RIP) && defined(__GLIBC__)
#  define LR_CRASH_PC(uc) ((void*)((ucontext_t*)(uc))->uc_mcontext.gregs[REG_RIP])
#elif defined(__x86_64__) && defined(__REG_RIP)
#  define LR_CRASH_PC(uc) ((void*)((ucontext_t*)(uc))->uc_mcontext.__gregs[__REG_RIP])
#elif defined(__aarch64__) && defined(__GLIBC__)
#  define LR_CRASH_PC(uc) ((void*)((ucontext_t*)(uc))->uc_mcontext.pc)
#else
#  define LR_CRASH_PC(uc) ((void*)0)
#endif

static void crash_handler(int sig, siginfo_t* si, void* uc) {
    void* bt[64];
    int n = backtrace(bt, 64);
    void* pc = LR_CRASH_PC(uc);
    if (!pc) pc = si->si_addr;  /* fallback: faulting address */
    fprintf(stderr, "\n[FRONT] === CAUGHT SIGNAL %d at PC=%p (code=%d addr=%p) ===\n",
            sig, pc, si->si_code, si->si_addr);
    backtrace_symbols_fd(bt, n, 2);
    _exit(99);
}

#define RETRO_ENVIRONMENT_SET_PIXEL_FORMAT   10
#define RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS 11
#define RETRO_ENVIRONMENT_GET_VARIABLE       15
#define RETRO_ENVIRONMENT_SET_VARIABLES      16
#define RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE 17
#define RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME 18
#define RETRO_ENVIRONMENT_SET_CONTROLLER_INFO 19
#define RETRO_ENVIRONMENT_GET_LOG_INTERFACE  27
#define RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY 31

typedef void (*retro_video_refresh_t)(const void*, unsigned, unsigned, size_t);
typedef void (*retro_audio_sample_t)(int16_t, int16_t);
typedef size_t (*retro_audio_sample_batch_t)(const int16_t*, size_t);
typedef void (*retro_input_poll_t)(void);
typedef int16_t (*retro_input_state_t)(unsigned, unsigned, unsigned, unsigned);
typedef bool (*retro_environment_t)(unsigned, void*);

struct retro_game_info { const char* path; const void* data; size_t size; const char* meta; };
struct retro_variable { const char* key; const char* value; };

static unsigned g_frame = 0;
static unsigned g_last_w = 0, g_last_h = 0;
static uint32_t g_pixels[2048*2048];
static char g_out_dir[512];
static unsigned g_press_every = 200;
static unsigned g_press_len = 60;

/* KEYSEQ: comma-separated joypad ids (17='5' key, 8=Fire, 9/10=soft keys);
 * one entry is held for KEYSEQ_LEN frames every KEYSEQ_EVERY frames. */
static int g_keyseq[16];
static int g_keyseq_n = 0;
static int g_keyseq_idx = 0;

/* KEYSEQ_HOLD: comma-separated joypad ids held CONTINUOUSLY (e.g. "13"
 * for the '5' accelerate key in Asphalt races) while KEYSEQ entries are
 * additionally pressed on schedule. */
static int g_keyseq_hold[8];
static int g_keyseq_hold_n = 0;

/* v34.48 test knobs:
 *   LR_FORCE_XRGB=1    — reject RGB565 so the core falls back to XRGB8888
 *   LR_ROT_SWITCH=N    — report GET_VARIABLE_UPDATE once at frame N;
 *                        j2me_rotation then answers LRVAR_j2me_rotation2 */
static int g_force_xrgb = 0;
static int g_rot_switch_frame = 0;
static int g_rot_switched = 0;

/* v34.53: NOJME_AUDIO_DUMP=<path> — write all core audio to <path> as a
 * 16-bit stereo WAV (rate = j2me_audio_rate option). NOJME_AUDIO_DUMP_START
 * =<frame> opens the file only at that frame (skip menus). */
static FILE* g_audio_dump = NULL;
static unsigned g_audio_rate = 22050;
static unsigned g_audio_dump_start = 0;
static unsigned g_audio_dumped_frames = 0;

static void audio_dump_wav_header(FILE* f) {
    uint32_t hz = g_audio_rate;
    /* byte layout: RIFF/size/WAVE/fmt /16/ PCM+ch / rate / byterate /
     * align+bits / data / size — all little-endian on every target we care
     * about (x86/ARM LE), so a plain uint32 array works. */
    uint32_t hdr[11] = { 0x46464952, 0, 0x45564157, 0x20746d66, 16,
                        0x00020001, hz, hz * 4, 0x00100004, 0x61746164, 0 };
    fwrite(hdr, 4, 11, f);
}

static void parse_keyseq(const char* s) {
    if (!s) return;
    const char* p = s;
    while (*p && g_keyseq_n < 16) {
        g_keyseq[g_keyseq_n++] = (int)strtol(p, (char**)&p, 10);
        if (*p == ',') p++;
        else break;
    }
}

static void parse_keyseq_hold(const char* s) {
    if (!s) return;
    const char* p = s;
    while (*p && g_keyseq_hold_n < 8) {
        g_keyseq_hold[g_keyseq_hold_n++] = (int)strtol(p, (char**)&p, 10);
        if (*p == ',') p++;
        else break;
    }
}

static bool env_cb(unsigned cmd, void* data) {
    switch (cmd) {
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        /* accept whatever the core asks (0=1555? 1=XRGB8888, 2=RGB565) */
        if (g_force_xrgb && *(int*)data == 2) {
            /* v34.48 test knob: reject RGB565 like a weak frontend —
             * the core must fall back to XRGB8888 (rotation bpp=4 path). */
            fprintf(stderr, "[FRONT] pixel format 2 (RGB565) rejected\n");
            return false;
        }
        fprintf(stderr, "[FRONT] pixel format req = %d\n", *(int*)data);
        return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        struct retro_variable* var = (struct retro_variable*)data;
        /* Default: no value (frontend has no per-core config yet). Override
         * with LRVAR_<key>=<value> to emulate a saved core option, e.g.
         * LRVAR_j2me_resolution=240x320 (RetroArch-style explicit choice).
         * After LR_ROT_SWITCH fired, j2me_rotation answers LRVAR_j2me_rotation2. */
        if (var && var->key) {
            char envname[128];
            if (g_rot_switched && strcmp(var->key, "j2me_rotation") == 0)
                snprintf(envname, sizeof(envname), "LRVAR_%s2", var->key);
            else
                snprintf(envname, sizeof(envname), "LRVAR_%s", var->key);
            const char* v = getenv(envname);
            if (v) {
                var->value = v;
                return true;
            }
        }
        return false;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        /* v34.48 test knob LR_ROT_SWITCH=<frame>: report an option update
         * once after the given frame — emulates the user flipping the
         * core option in RetroArch's Quick Menu mid-run. The new value
         * comes from LRVAR_j2me_rotation2. */
        if (g_rot_switch_frame && g_frame >= (unsigned)g_rot_switch_frame && !g_rot_switched) {
            g_rot_switched = 1;
            *(bool*)data = true;
            fprintf(stderr, "[FRONT] simulating option update at frame %u\n", g_frame);
            return true;
        }
        *(bool*)data = false;
        return true;
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_VARIABLES:
        return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
        /* struct { retro_log_printf_t log; } — provide fprintf */
        ((void**)data)[0] = (void*)(void(*)(int, const char*, ...))0; /* avoid */
        return false;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: {
        /* S48: enable RMS persistence like real RetroArch — the game's
         * continue-from-save path (state 0) could never be tested before. */
        const char* sd = getenv("LR_SAVE_DIR");
        if (sd && sd[0]) {
            *(const char**)data = sd;
            return true;
        }
        return false;
    }
    default:
        return false;
    }
}

static void video_cb(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data) return;
    g_last_w = w; g_last_h = h;
    if (w*h <= 2048*2048) {
        if (pitch == w*2) { /* RGB565 */
            const uint16_t* src = (const uint16_t*)data;
            for (unsigned i = 0; i < w*h; i++) {
                uint16_t p = src[i];
                uint8_t r = (uint8_t)(((p >> 11) & 0x1F) * 255 / 31);
                uint8_t g = (uint8_t)(((p >> 5) & 0x3F) * 255 / 63);
                uint8_t b = (uint8_t)((p & 0x1F) * 255 / 31);
                g_pixels[i] = 0xFF000000u | (r << 16) | (g << 8) | b;
            }
        } else { /* XRGB8888 */
            const uint32_t* src = (const uint32_t*)data;
            for (unsigned i = 0; i < w*h; i++) g_pixels[i] = src[i] | 0xFF000000u;
        }
    }
}

static void save_frame(const char* tag) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/lr_%s.ppm", g_out_dir, tag);
    FILE* f = fopen(path, "wb");
    if (!f) return;
    fprintf(f, "P6\n%u %u\n255\n", g_last_w, g_last_h);
    for (unsigned i = 0; i < g_last_w * g_last_h; i++) {
        uint8_t rgb[3] = { (uint8_t)(g_pixels[i] >> 16), (uint8_t)(g_pixels[i] >> 8), (uint8_t)g_pixels[i] };
        fwrite(rgb, 1, 3, f);
    }
    fclose(f);
}

static void audio_cb(int16_t l, int16_t r) {
    if (g_audio_dump) {
        fwrite(&l, 2, 1, g_audio_dump);
        fwrite(&r, 2, 1, g_audio_dump);
        g_audio_dumped_frames++;
    }
}
static size_t audio_batch_cb(const int16_t* d, size_t n) {
    if (g_audio_dump && d && n) {
        fwrite(d, sizeof(int16_t), n * 2, g_audio_dump);
        g_audio_dumped_frames += (unsigned)n;
    }
    return n;
}
static void poll_cb(void) {}
static int16_t input_cb(unsigned port, unsigned device, unsigned index, unsigned id) {
    (void)port; (void)device; (void)index;
    /* continuous HOLD keys first (accelerate etc.) */
    for (int i = 0; i < g_keyseq_hold_n; i++) {
        if ((int)id == g_keyseq_hold[i]) return 1;
    }
    /* RETRO_DEVICE_ID_JOYPAD_A = 8 -> Fire (key -5) in this core.
     * START/SELECT tap REMOVED — it pauses the race (v37 repro). */
    if (device == 1 && g_press_every > 0) {
        unsigned phase = g_frame % g_press_every;
        if (phase < g_press_len) {
            if (g_keyseq_n > 0) {
                if (id == g_keyseq[g_keyseq_idx]) return 1;
            } else if (id == 8) {
                return 1;
            }
        }
    }
    return 0;
}

int main(int argc, char** argv) {
    if (argc < 5) {
        fprintf(stderr, "usage: %s core.so game.jar max_frames out_dir [press_every|0=none]\n", argv[0]);
        return 1;
    }
    const char* core_path = argv[1];
    const char* game_path = argv[2];
    unsigned max_frames = (unsigned)atoi(argv[3]);
    snprintf(g_out_dir, sizeof(g_out_dir), "%s", argv[4]);
    if (argc >= 6) g_press_every = (unsigned)atoi(argv[5]);
    /* SNAP_EVERY: save a frame every N iterations (default 0 = only 500s) */
    unsigned snap_every = 0;
    const char* se = getenv("SNAP_EVERY");
    if (se) snap_every = (unsigned)atoi(se);
    parse_keyseq(getenv("KEYSEQ"));
    parse_keyseq_hold(getenv("KEYSEQ_HOLD"));
    /* v34.48 test knobs (see declaration block) */
    if (getenv("LR_FORCE_XRGB") && atoi(getenv("LR_FORCE_XRGB")) == 1) g_force_xrgb = 1;
    if (getenv("LR_ROT_SWITCH")) g_rot_switch_frame = atoi(getenv("LR_ROT_SWITCH"));
    /* PACED=1: call retro_run at a real ~60fps cadence like RetroArch
     * (default: free-run as fast as the core returns) */
    int paced = getenv("PACED") && atoi(getenv("PACED")) == 1;

    /* v34.53 audio dump setup */
    {
        const char* ad = getenv("NOJME_AUDIO_DUMP");
        const char* ads = getenv("NOJME_AUDIO_DUMP_START");
        const char* ar = getenv("LRVAR_j2me_audio_rate");
        if (ar) g_audio_rate = (unsigned)atoi(ar);
        if (ads) g_audio_dump_start = (unsigned)atoi(ads);
        if (ad && ad[0] && g_audio_dump_start == 0) {
            g_audio_dump = fopen(ad, "wb");
            if (!g_audio_dump) fprintf(stderr, "[FRONT] audio dump open failed: %s\n", ad);
        }
        if (g_audio_dump) audio_dump_wav_header(g_audio_dump);
    }

    void* handle = dlopen(core_path, RTLD_NOW);
    if (!handle) { fprintf(stderr, "dlopen failed: %s\n", dlerror()); return 1; }

    #define LOADSYM(sym) dlsym(handle, #sym)

    void (*retro_set_environment)(retro_environment_t) = (void (*)(retro_environment_t))LOADSYM(retro_set_environment);
    void (*retro_set_video_refresh)(retro_video_refresh_t) = (void (*)(retro_video_refresh_t))LOADSYM(retro_set_video_refresh);
    void (*retro_set_audio_sample)(retro_audio_sample_t) = (void (*)(retro_audio_sample_t))LOADSYM(retro_set_audio_sample);
    void (*retro_set_audio_sample_batch)(retro_audio_sample_batch_t) = (void (*)(retro_audio_sample_batch_t))LOADSYM(retro_set_audio_sample_batch);
    void (*retro_set_input_poll)(retro_input_poll_t) = (void (*)(retro_input_poll_t))LOADSYM(retro_set_input_poll);
    void (*retro_set_input_state)(retro_input_state_t) = (void (*)(retro_input_state_t))LOADSYM(retro_set_input_state);
    void (*retro_init)(void) = (void (*)(void))LOADSYM(retro_init);
    bool (*retro_load_game)(const struct retro_game_info*) = (bool (*)(const struct retro_game_info*))LOADSYM(retro_load_game);
    void (*retro_run)(void) = (void (*)(void))LOADSYM(retro_run);
    void (*retro_deinit)(void) = (void (*)(void))LOADSYM(retro_deinit);
    #define CHECK(fn) if (!(fn)) { fprintf(stderr, "missing %s\n", #fn); return 1; }
    CHECK(retro_set_environment); CHECK(retro_set_video_refresh); CHECK(retro_set_audio_sample);
    CHECK(retro_set_audio_sample_batch); CHECK(retro_set_input_poll); CHECK(retro_set_input_state);
    CHECK(retro_init); CHECK(retro_load_game); CHECK(retro_run); CHECK(retro_deinit);

    retro_set_environment(env_cb);
    retro_set_video_refresh(video_cb);
    retro_set_audio_sample(audio_cb);
    retro_set_audio_sample_batch(audio_batch_cb);
    retro_set_input_poll(poll_cb);
    retro_set_input_state(input_cb);

    /* Install crash handlers FIRST — a SIGFPE during retro_init/load_game
     * must still produce a symbolized backtrace. SA_SIGINFO gives RIP. */
    {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = crash_handler;
        sa.sa_flags = SA_SIGINFO;
        sigaction(SIGFPE, &sa, NULL);
        sigaction(SIGSEGV, &sa, NULL);
        sigaction(SIGBUS, &sa, NULL);
    }

    retro_init();

    struct retro_game_info info;
    memset(&info, 0, sizeof(info));
    info.path = game_path;
    if (!retro_load_game(&info)) {
        fprintf(stderr, "[FRONT] retro_load_game FAILED\n");
        return 1;
    }

    for (g_frame = 1; g_frame <= max_frames; g_frame++) {
        struct timespec ts0, ts1;
        clock_gettime(CLOCK_MONOTONIC, &ts0);
        retro_run();
        if (g_audio_dump_start && g_frame == g_audio_dump_start && !g_audio_dump) {
            const char* ad = getenv("NOJME_AUDIO_DUMP");
            if (ad && ad[0]) {
                g_audio_dump = fopen(ad, "wb");
                if (g_audio_dump) audio_dump_wav_header(g_audio_dump);
            }
        }
        clock_gettime(CLOCK_MONOTONIC, &ts1);
        double dt_ms = (ts1.tv_sec - ts0.tv_sec) * 1000.0 + (ts1.tv_nsec - ts0.tv_nsec) / 1e6;
        if (dt_ms > 30.0)
            fprintf(stderr, "[FRONT] SLOW frame %u: %.1f ms\n", g_frame, dt_ms);
        /* paced mode: hold the real 60fps cadence (like RetroArch vsync) */
        if (paced) {
            double budget_ms = 16.666;
            if (dt_ms < budget_ms) {
                struct timespec req;
                double sleep_ms = budget_ms - dt_ms;
                req.tv_sec = (time_t)(sleep_ms / 1000.0);
                req.tv_nsec = (long)((sleep_ms - req.tv_sec * 1000.0) * 1e6);
                nanosleep(&req, NULL);
            }
        }
        /* advance the KEYSEQ entry at each round boundary */
        if (g_keyseq_n > 0 && g_frame % g_press_every == 0)
            g_keyseq_idx = (g_keyseq_idx + 1) % g_keyseq_n;
        if (g_last_w && ((g_frame % 500 == 0) ||
                         (snap_every && g_frame % snap_every == 0))) {
            char tag[32];
            snprintf(tag, sizeof(tag), "%06u", g_frame);
            save_frame(tag);
            fprintf(stderr, "[FRONT] frame %u saved (%ux%u)\n", g_frame, g_last_w, g_last_h);
        }
    }
    save_frame("last");
    fprintf(stderr, "[FRONT] done: %u frames, video %ux%u, audio %u frames dumped\n",
            max_frames, g_last_w, g_last_h, g_audio_dumped_frames);
    if (g_audio_dump) {
        uint32_t data_bytes = g_audio_dumped_frames * 4;
        uint32_t riff = 36 + data_bytes;
        fseek(g_audio_dump, 4, SEEK_SET);  fwrite(&riff, 4, 1, g_audio_dump);
        fseek(g_audio_dump, 40, SEEK_SET); fwrite(&data_bytes, 4, 1, g_audio_dump);
        fclose(g_audio_dump);
    }
    retro_deinit();
    dlclose(handle);
    return 0;
}
