#!/bin/bash
# Build lr_run for the host (x86-64) — links against system libc.
set -e
D=/home/z/my-project/j2me-analysis
gcc -O1 -g -std=c11 $D/scripts/lr_run.c -o $D/bin/lr_run -ldl -lm -pthread
file $D/bin/lr_run | cut -c1-90
