export SWITCHUI_SDL_CFLAGS="-I/home/z/my-project/work/sdl2-headers"
export SWITCHUI_SDL_LIBS="-L/home/z/my-project/work -lSDL2 -lm -pthread"
