/**
 * DirectRenderTest — v35.06 selftest midlet for the phone-faithful
 * direct-render delivery (settle-if-stale).
 *
 * Models the two rendering disciplines J2ME games actually use:
 *
 *   Phase A ("pump-paced", Asphalt-results-screen-like): the game thread
 *       yields ~71 ms between ticks, then repaint() + serviceRepaints().
 *       ALL drawing happens inside paint() on the pump thread. Expected:
 *       settles at the game's own pace (~14/s), dset=0 (nothing draws
 *       outside the pump), lvc == fl — "nothing dropped".
 *
 *   Phase B ("direct-render", Nokia DirectGraphics-era style): the game
 *       thread draws via the Graphics object cached from paint() every
 *       ~16 ms and NEVER calls repaint(). Pre-v35.06 that content never
 *       settled (the screen froze until the next pump paint — the exact
 *       "frames dropped at the final render stage" field report). With
 *       v35.06 settle-if-stale the frontend delivers it every present.
 *       Expected: fl ~60/s with dset ~60/s in the diag line.
 *
 * PASS (from the sandbox log):
 *   "DRT:PASS A paints=N"   (N >= 15 — the pump-paced loop ran)
 *   "DRT:PASS B direct=N"   (N >= 80 — the direct-render loop ran)
 *   a diag window inside phase B with fl >= 100 and dset >= 50
 *   a diag window inside phase A with lvc == fl (nothing dropped)
 *   no [NO-FRAME] watchdog alarm, no crash.
 */
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;

public class DirectRenderTest extends MIDlet {
    static int paints = 0;
    static int directs = 0;
    static Graphics cached = null;
    static Canvas cv = null;
    static int pos = 0;
    static int color = 0;

    public DirectRenderTest() {
    }

    static void drawScene(Graphics g) {
        color++;
        pos += 3;
        g.setColor((color & 1) == 0 ? 0x00B040 : 0x1030A0);
        g.fillRect(0, 0, 240, 320);
        g.setColor(0xFFFFFF);
        g.fillRect((pos % 200) + 20, (pos % 260) + 30, 12, 12);
    }

    protected void startApp() {
        Canvas c = new Canvas() {
            protected void paint(Graphics g) {
                paints++;
                cached = g;          /* the direct-render handle */
                drawScene(g);
            }
        };
        cv = c;
        Display.getDisplay(this).setCurrent(c);

        Thread t = new Thread() {
            public void run() {
                /* Phase A: pump-paced like the Asphalt results screen. */
                long bg = System.currentTimeMillis();
                long tEnd = System.currentTimeMillis() + 6500;
                while (System.currentTimeMillis() < tEnd) {
                    while (System.currentTimeMillis() - bg < 71L) {
                        Thread.yield();
                    }
                    pos += 5;                       /* logic tick */
                    cv.repaint();
                    cv.serviceRepaints();
                    bg = System.currentTimeMillis();
                }
                System.out.println("DRT:PASS A paints=" + paints);

                /* Phase B: direct render via the cached screen Graphics. */
                long dBg = System.currentTimeMillis();
                tEnd = System.currentTimeMillis() + 6500;
                while (System.currentTimeMillis() < tEnd) {
                    while (System.currentTimeMillis() - dBg < 16L) {
                        Thread.yield();
                    }
                    Graphics g = cached;
                    if (g != null) {
                        drawScene(g);
                        directs++;
                    }
                    dBg = System.currentTimeMillis();
                }
                System.out.println("DRT:PASS B direct=" + directs
                        + " paints=" + paints);

                try { Thread.sleep(400); } catch (Exception e) {}
                notifyDestroyed();
            }
        };
        t.start();
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean unconditional) {
    }
}
