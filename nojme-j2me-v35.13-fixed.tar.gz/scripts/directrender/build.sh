#!/bin/bash
# Build DirectRenderTest.jar — the v35.06 settle-if-stale selftest midlet.
# Requires: JRE (java) + ECJ (ecj.jar).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ=/tmp/my-project/src/nojme-j2me/scripts/ecj.jar
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/DirectRenderTest.java" \
    "$D"/stubs/javax/microedition/midlet/*.java \
    "$D"/stubs/javax/microedition/lcdui/*.java
printf 'Manifest-Version: 1.0\r\nMIDlet-1: DRT, , DirectRenderTest\r\nMIDlet-Name: DRT\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT"/DirectRenderTest*.class "$OUT/pkg/"
rm -f "$D/DirectRenderTest.jar"
( cd "$OUT/pkg" && zip -q -r "$D/DirectRenderTest.jar" . )
echo "built: $D/DirectRenderTest.jar"
