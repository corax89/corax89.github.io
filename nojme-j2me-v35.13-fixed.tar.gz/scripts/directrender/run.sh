#!/bin/bash
# Run the v35.06 settle-if-stale selftest against bin/switchui-verify
# (host SDL2 sandbox, dummy video).
#
# Verifies the two delivery disciplines end to end:
#   Phase A (pump-paced): settles at the game's own pace, dset=0,
#                         lvc == fl — nothing dropped.
#   Phase B (direct-render through a Graphics cached from paint()):
#                         pre-v35.06 the screen would freeze; v35.06
#                         delivers every present — fl >= 100, dset >= 50.
#
# PASS criteria (all must hold):
#   1. "DRT:PASS A paints=" present (phase A ran, paints >= 15)
#   2. "DRT:PASS B direct=" present (phase B ran, direct >= 80)
#   3. at least one diag window with lvc == fl > 0   (phase A: nothing dropped)
#   4. at least one diag window with fl >= 100 and dset >= 50 (phase B delivered)
#   5. no [NO-FRAME] watchdog alarm, no crash
set -e
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/drt
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/directrender/DirectRenderTest.jar "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1  # v35.08: diag lines follow the logging gate
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:600,A:600"

timeout 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
# rc 124 is tolerated (known host teardown hang with logging ON, v34.95
# EXITTRACE note). The checks below decide the verdict.

ok=1
grep -q "DRT:PASS A paints=" "$D/err.log" \
    || { echo "FAIL: phase A (pump-paced) did not complete"; ok=0; }
grep -q "DRT:PASS B direct=" "$D/err.log" \
    || { echo "FAIL: phase B (direct-render) did not complete"; ok=0; }
grep -q "\[NO-FRAME\]" "$D/err.log" \
    && { echo "FAIL: [NO-FRAME] watchdog fired (frames did not settle)"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" \
    && { echo "FAIL: crash"; ok=0; }

# Phase completion counts.
pa=$(grep -o "DRT:PASS A paints=[0-9]*" "$D/err.log" | head -1 | grep -o "[0-9]*$")
pb=$(grep -o "DRT:PASS B direct=[0-9]*" "$D/err.log" | head -1 | grep -o "[0-9]*$")
[ -n "$pa" ] && [ "$pa" -ge 15 ] 2>/dev/null \
    || { echo "FAIL: phase A too few paints ($pa)"; ok=0; }
[ -n "$pb" ] && [ "$pb" -ge 80 ] 2>/dev/null \
    || { echo "FAIL: phase B too few direct draws ($pb)"; ok=0; }

# Diag windows: extract fl/lvc/dset triples and check both phases.
# NOTE: phase A occupies the first ~2 diag windows, phase B the later ones.
python3 - "$D/err.log" <<'EOF' || ok=0
import re, sys
log = open(sys.argv[1], errors="replace").read()
rows = []
for m in re.finditer(r"diag:.*? fl=(\d+).*? cs=(\d+) lvc=(\d+) dset=(\d+)", log):
    fl, cs, lvc, dset = map(int, m.groups())
    rows.append((fl, lvc, dset))
if len(rows) < 2:
    print("FAIL: fewer than 2 diag windows captured:", len(rows)); sys.exit(1)
# Phase A window: the FIRST window with fl>0 must show lvc == fl within a
# small tolerance (window-edge races), dset == 0 (pump-paced: everything
# the game drew reached the screen; nothing dropped).
a = next((r for r in rows if r[0] > 0), None)
if a is None:
    print("FAIL: no diag window with fl>0"); sys.exit(1)
if abs(a[1] - a[0]) > 2:
    print("FAIL: phase A lvc(%d) != fl(%d) — frames dropped at scanout?" % (a[1], a[0]))
    sys.exit(1)
# Phase B window: any window with fl >= 100 and dset >= 50 proves the
# direct-render delivery works (dummy video: the sandbox loop runs ~570/s,
# so phase-B windows collect several seconds of both phases).
b = [r for r in rows if r[0] >= 100 and r[2] >= 50]
if not b:
    print("FAIL: no diag window with fl>=100 and dset>=50 (direct-render delivery dead):",
          rows); sys.exit(1)
# Phase A window must NOT use divergence settles (game is pump-paced).
if a[2] != 0:
    print("FAIL: phase A dset=%d — settle-if-stale fired on a pump-paced game" % a[2])
    sys.exit(1)
print("DIAG CHECK: phase A fl=%d lvc=%d dset=0 (nothing dropped); "
      "phase B fl=%d lvc=%d dset=%d (direct render delivered)"
      % (a[0], a[1], b[0][0], b[0][1], b[0][2]))
EOF

if [ $ok -eq 1 ]; then
    echo "DIRECTRENDER SELFTEST: ALL CHECKS PASSED"
else
    echo "DIRECTRENDER SELFTEST: FAILED — log tail:"
    tail -40 "$D/err.log"
fi
exit $((1 - ok))
