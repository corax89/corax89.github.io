#!/bin/bash
# v35.10 exit-deadlock repro driver (sandbox)
# Drives the exact user flow: game running -> MINUS (pause menu) ->
# B ("exit to frontend menu") -> destroyApp must run to completion.
#
# usage: run_pausexit.sh [jar] [minus_at_ms] [b_after_ms] [seconds]
cd "$(dirname "$0")/.." || exit 1
JAR="${1:-games/AsiaRally3D.jar}"
MINUS_AT="${2:-12000}"
B_AFTER="${3:-800}"
SECS="${4:-40}"
D=/tmp/pausexit
rm -rf "$D"; mkdir -p "$D/roms"
cp "$JAR" "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800"          # frontend menu: launch the jar
export NOJME_FRONT_KEYS="MINUS:${MINUS_AT},B:${B_AFTER}"  # pause menu -> exit
timeout -k 5 "$SECS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
echo "rc=$?"
echo "--- pause/exit markers (log.txt, ms timestamps):"
grep -aE "pause: open|pause: close|STUCK:|FE-PAUSE|FRONTKEYS|session end|session complete" "$D/log.txt" 2>/dev/null | head -30
echo "--- destroyApp markers (err.log):"
grep -aE "destroyApp|MIDLET" "$D/err.log" 2>/dev/null | head -10
echo "--- STUCK count: $(grep -ac 'STUCK:' "$D/log.txt" 2>/dev/null)"
