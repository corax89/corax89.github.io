/**
 * NoFrameTest — v35.04 selftest midlet for the [NO-FRAME] watchdog.
 *
 * Models the Bobby Carrot 4 field signature: the game paints its first
 * frame, then a live VM thread BUSY-SPINS forever — no sleep (thread stays
 * runnable), no repaint (settled-frame seq freezes), no allocation. The
 * beat watchdog must fire [NO-FRAME] ~10 s in and dump the threads.
 *
 * Expected log (switchui-verify, NOJME_LOG=1):
 *   [NO-FRAME] no settled frame for 10 s; live>=1 ... disp=Canvas-ish
 *   followed by td lines naming the spin thread (nat=...Thread.yield).
 */
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;

public class NoFrameTest extends MIDlet {
    public NoFrameTest() {
    }

    protected void startApp() {
        Canvas c = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0x205090);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        Display.getDisplay(this).setCurrent(c);
        c.repaint();

        Thread t = new Thread() {
            public void run() {
                long x = 0;
                while (true) {
                    /* native dispatch every few ms, zero sleep, zero paint */
                    x += System.currentTimeMillis();
                    Thread.yield();
                    if (x < 0) x = 1;
                }
            }
        };
        t.start();
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean unconditional) {
    }
}
