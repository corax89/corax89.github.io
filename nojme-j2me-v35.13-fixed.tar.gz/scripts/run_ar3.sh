#!/bin/bash
# AsiaRally3D sandbox repro driver (v35.09)
# usage: run_ar3.sh "<NOJME_GAME_KEYS script>" [seconds] [vm_speed]
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ar3run
rm -rf "$D"; mkdir -p "$D/roms"
if [ -n "$3" ]; then printf "audio_enabled=1\nvm_speed=%s\n" "$3" > "$D/switchui_settings.ini"; fi
cp games/AsiaRally3D.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_GAME_KEYS="${1:-}"
SECS="${2:-90}"
timeout -k 5 "$SECS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
echo "rc=$?"
echo "--- diag tail:"
grep -a "diag:" "$D/log.txt" 2>/dev/null | tail -6
