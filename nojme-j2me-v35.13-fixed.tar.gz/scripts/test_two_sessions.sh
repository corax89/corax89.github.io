#!/bin/bash
# v35.08 repro: midlet switch from the frontend menu.
# Session 1 (MonLeakTest) runs -> menu -> Session 2 (same jar, fresh JVM)
# runs -> B exits the app.
# PASS = 2x "game selected" + 2x full game run (MONLEAK:DONE PASSED) +
#        2x "session complete" + clean exit + no FATAL/OPCODE FAIL.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_2s
rm -rf "$D"; mkdir -p "$D/roms/sub"
cp scripts/monleak/MonLeakTest.jar "$D/roms/sub/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# main: A=Open; browser: A=enter sub; A=select jar1; (session 1 self-ends)
# main: A=Open; browser: A=enter sub; A=select jar2; (session 2 self-ends)
# B: exit app
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,A:400,A:400,A:400,EXIT:6000"

timeout 110 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
sel=$(grep -c "game selected:" "$D/err.log" || true)
[ "$sel" -ge 2 ] || { echo "FAIL: game launches = $sel (want 2)"; ok=0; }
comp=$(grep -c "session complete" "$D/err.log" || true)
[ "$comp" -ge 2 ] || { echo "FAIL: completed sessions = $comp (want 2)"; ok=0; }
done_n=$(grep -c "MONLEAK:DONE.*PASSED" "$D/err.log" || true)
[ "$done_n" -ge 2 ] || { echo "FAIL: full game runs = $done_n (want 2)"; ok=0; }
started=$(grep -c "MIDLET STARTED" "$D/err.log" || true)
[ "$started" -ge 2 ] || { echo "FAIL: MIDLET STARTED count = $started (want 2)"; ok=0; }
grep -q "FATAL\|OPCODE FAIL\|startApp failed" "$D/err.log" && { echo "FAIL: VM error in a session"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: crash"; ok=0; }
grep -q "menu exit — shutting down" "$D/err.log" || { echo "FAIL: app did not exit cleanly"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "TWO-SESSION E2E: ALL CHECKS PASSED"
else
    echo "TWO-SESSION E2E: FAILED — tail of err.log:"
    tail -40 "$D/err.log"
fi
exit $((1 - ok))
