#!/bin/bash
# Run the v35.05 showNotify-pump selftest against bin/switchui-verify
# (host SDL2 sandbox, dummy video). Verifies that the Switch frontend
# delivers the deferred Canvas.showNotify() and that a Bobby-Carrot-style
# showNotify-gated paint loop then produces frames.
#
# PASS criteria:
#   1. "[DISPLAY] Calling showNotify() on ShowNotifyTest$1" in the log
#   2. "SNT:PASS shown=true paints=>=10" from the game thread
#   3. no [NO-FRAME] watchdog alarm, no crash
set -e
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/snt
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/shownotify/ShowNotifyTest.jar "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:600,A:600"

timeout 45 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
# rc 124 is tolerated: the host verification build has a KNOWN teardown
# hang after main-return when logging is ON (v34.95 EXITTRACE note —
# exit()/stdio teardown, host-only, not a VM/frontend issue). The checks
# below decide the verdict.

ok=1
grep -q "Calling showNotify() on ShowNotifyTest\$1" "$D/err.log" \
    || { echo "FAIL: showNotify() was not delivered by the frontend pump"; ok=0; }
grep -q "SNT:PASS shown=true paints=" "$D/err.log" \
    || { echo "FAIL: showNotify-gated paint loop did not run"; ok=0; }
grep -q "SNT:FAIL" "$D/err.log" \
    && { echo "FAIL: midlet reported SNT:FAIL"; ok=0; }
grep -q "\[NO-FRAME\]" "$D/err.log" \
    && { echo "FAIL: [NO-FRAME] watchdog fired (frames did not settle)"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" \
    && { echo "FAIL: crash"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "SHOWNOTIFY SELFTEST: ALL CHECKS PASSED"
else
    echo "SHOWNOTIFY SELFTEST: FAILED — log tail:"
    tail -30 "$D/err.log"
fi
exit $((1 - ok))
