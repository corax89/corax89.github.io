/**
 * ShowNotifyTest — v35.05 selftest midlet for the Switch showNotify pump.
 *
 * Models the Bobby Carrot 4 field signature: the canvas overrides
 * showNotify() to set a flag, and a game thread repaints ONLY while the
 * flag is true (`if (this.d && ...) repaint()`). Before v35.05 the
 * Switch/SDL2 frame loop never delivered the deferred showNotify, so the
 * flag stayed false forever: one initial frame, then a frozen screen with
 * a live game thread ([NO-FRAME], fl=0, skip=loop).
 *
 * Expected log (switchui-verify, NOJME_LOG=1):
 *   [DISPLAY] Calling showNotify() on ShowNotifyTest$1   (frontend pump)
 *   SNT:PASS shown=true paints=N (N >= 10)               (game thread)
 * and no [NO-FRAME] alarm during the run.
 */
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;

public class ShowNotifyTest extends MIDlet {
    static boolean shown = false;
    static int paints = 0;
    static Canvas cv;

    public ShowNotifyTest() {
    }

    protected void startApp() {
        Canvas c = new Canvas() {
            protected void paint(Graphics g) {
                paints++;
                g.setColor((paints & 1) == 0 ? 0x00B040 : 0x1030A0);
                g.fillRect(0, 0, getWidth(), getHeight());
            }

            protected void showNotify() {
                shown = true;
            }
        };
        Display.getDisplay(this).setCurrent(c);
        cv = c;

        Thread t = new Thread() {
            public void run() {
                /* 1.5 s grace: prove that WITHOUT showNotify nothing paints
                 * (pre-v35.05 the run ended here with paints stuck at 1). */
                try { Thread.sleep(1500); } catch (Exception e) {}
                long deadline = System.currentTimeMillis() + 8000;
                while (System.currentTimeMillis() < deadline && paints < 10) {
                    if (shown) {
                        cv.repaint();
                        cv.serviceRepaints();
                    }
                    try { Thread.sleep(100); } catch (Exception e) {}
                }
                if (shown && paints >= 10) {
                    System.out.println("SNT:PASS shown=true paints=" + paints);
                } else {
                    System.out.println("SNT:FAIL shown=" + shown + " paints=" + paints);
                }
                try { Thread.sleep(300); } catch (Exception e) {}
                notifyDestroyed();
            }
        };
        t.start();
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean unconditional) {
    }
}
