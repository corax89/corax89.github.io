#!/bin/bash
# E2E автотест Switch-фронтенда (bin/switchui-verify, SDL dummy video).
# Сценарий: главное меню -> браузер -> вход в каталог -> выбор jar ->
# игра (TestDosWrite, мгновенно завершается) -> возврат в меню -> выход.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_e2e
rm -rf "$D"; mkdir -p "$D/roms/sub"
cp scripts/testdosw/TestDosWrite.jar "$D/roms/sub/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1  # v35.08: diag lines follow the logging gate
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,EXIT:6000"

timeout 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
grep -q "TDW:DONE ALL DOS CHECKS PASSED" "$D/err.log" || { echo "FAIL: игра не выполнилась"; ok=0; }
grep -q "game selected: .*TestDosWrite.jar" "$D/err.log" || { echo "FAIL: jar не выбран"; ok=0; }
grep -q "session complete — back to menu" "$D/err.log" || { echo "FAIL: нет возврата в меню"; ok=0; }
grep -q "menu session end (result=0)" "$D/err.log" || { echo "FAIL: приложение не вышло из меню"; ok=0; }
grep -q "\[SWITCH\] platform init OK" "$D/err.log" || { echo "FAIL: платформа не инициализировалась"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "SWITCH-UI E2E: ALL CHECKS PASSED"
else
    echo "SWITCH-UI E2E: FAILED — последние строки err.log:"; tail -25 "$D/err.log"
fi
exit $((1 - ok))
