/* v35.12 unit test: jar_detect_screen_size_from_name() */
#include <stdio.h>
#include <string.h>
#include "jar_reader.h"

static int fails = 0;

static void check(const char* name, int want_w, int want_h) {
    int w = -1, h = -1;
    int got = jar_detect_screen_size_from_name(name, &w, &h);
    if (want_w == 0) {
        if (got) { printf("FAIL %-46s -> %dx%d (want none)\n", name, w, h); fails++; }
        else printf("ok   %-46s -> none\n", name);
    } else {
        if (!got || w != want_w || h != want_h) {
            printf("FAIL %-46s -> %s%dx%d (want %dx%d)\n", name, got ? "" : "none ",
                   w, h, want_w, want_h);
            fails++;
        } else printf("ok   %-46s -> %dx%d\n", name, w, h);
    }
}

int main(void) {
    check("Asphalt 3 3D (1.1.5).jar", 0, 0);        /* no size in name */
    check("GloftA33D.jar", 0, 0);
    check("somegame v1.2.3.jar", 0, 0);             /* version tail must not match */
    check("Game 2x2.jar", 0, 0);                    /* junk range rejected */
    check("Game 240x320.jar", 240, 320);
    check("Game240x320.jar", 240, 320);             /* glued */
    check("Rayman 3_320X240.jar", 320, 240);        /* uppercase X */
    check("Game 176x208 240x320.jar", 240, 320);    /* LAST pair wins */
    check("/path/to/Game 640x360.jar", 640, 360);   /* path prefix ignored */
    check("C:\\dir\\Game 128x128.jar", 128, 128);   /* windows path */
    check("сапёр 128x128.jar", 128, 128);           /* non-ascii prefix */
    check("game 352x416 (mod).jar", 352, 416);
    check("history 1024x9999.jar", 0, 0);           /* out of range */
    check("resolver max 480x800.jar", 480, 800);    /* 'max ' boundary ok */
    check("гдр 240x320", 240, 320);                 /* no .jar suffix, fine */
    printf(fails ? "\nNAME-RES: %d FAILURES\n" : "\nNAME-RES: ALL PASSED\n", fails);
    return fails ? 1 : 0;
}
