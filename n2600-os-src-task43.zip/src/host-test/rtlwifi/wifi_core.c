/* wifi_core.c — чипо-НЕЗАВИСИМЫЙ WiFi-стек N2600-OS (сессия 28).
 *
 * Переехал из ath9k_wifi.c без изменения логики: журнал, профиль
 * WIFI.CFG, сканирование (пошагово, каналы 1-14), парсинг beacon
 * (RSN/WPA IE), машина подключения (SCAN→AUTH→ASSOC→4WAY→CONNECTED),
 * WPA2-PSK (PBKDF2/PTK/EAPOL M1-M4 + group rekey), мост
 * 802.11<->Ethernet для net.c.
 *
 * Драйверы (ath9k_wifi.c, rtl8192eu.c) регистрируют wifi_hw_ops_t и
 * доставляют принятые кадры через wc_rx_frame(). ИЗМЕНЕНИЕ ПОВЕДЕНИЯ:
 * wifi_scan_start() больше НЕ очищает список найденных точек — он
 * обновляется маяками. Раньше очистка при подключении выглядела как
 * «поиск начался заново» сразу после ввода пароля (жалоба сессии 28).
 */
#include "wifi_core.h"
#include "wpa2.h"
#include "string.h"
#include "mem.h"
#include "timer.h"
#include "sync.h"
#include "kernel.h"
#include "ramfs.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);
extern int  vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* ================= конфигурация (бывший ath9k_wifi.c) ================= */

/* СЕССИЯ 33: 1 тик = 1 мс (PIT 1000 Гц; было 10 мс при 100 Гц).
 * Все тайминги ниже — в тиках, численно равны миллисекундам. */
#define WIFI_SCAN_DWELL   150       /* мс на канал: окно должно ПОКРЫВАТЬ
 * интервал маяков (~102.4 мс) с запасом на послеперестроечную стабилизацию
 * AGC/NF — при 110 мс маяк «съезжал» за край окна (см. [W-DWELLFIX],
 * [ATH-SCAN2]; полевой лог: маяк точки ловился только на соседнем канале) */
#define WIFI_TXBUF_SZ     2360      /* 24 hdr + LLC/SNAP 8 + 1500 + запас */
#define WIFI_NET_RXQ      16        /* кадров Ethernet в кольце к net.c
 * [RXQ-WIDE] (Task 41): было 8 — при всплеске бродкастов (ARP/NetBIOS/
 * ретрансляции OFFER на занятом канале) кольцо переполнялось между
 * опросами net_poll, и новые кадры (OFFER/ACK) терялись */
#define WIFI_NET_RXSZ     1600
/* тайминги ассоциации (тики = мс при 1000 Гц) */
#define CONN_4WAY_TO     5000  /* 5 с на шаг рукопожатия */
#define CONN_MAX_4WAY    3     /* попыток рукопожатия */
#define CONN_AUTH_TO       600         /* 600 мс на попытку AUTH/ASSOC */
#define CONN_MAX_ATTEMPTS  5   /* [W-RATELADDER]: 1M/11M/2M/5.5M/6M */
/* [W-AUTHDWELL]: окно прослушивания канала точки ПЕРЕД AUTH. Маяк
 * идёт ~102 мс — 340 мс = 3 маяка; если точка жива и слышима, за окно
 * придёт 2-3 маяка. Полевой лог AR9285 показал: AUTH уходит на канал
 * точки (DS), а ACK нет — нужно понять, слышим ли мы точку на ЕЁ
 * канале вообще (dwell ch 1 был глух, маяк ловился только на ch 2). */
#define PREAUTH_DWELL_MS   340
#define CONN_SCAN_TRIES    3          /* проходов скана при поиске сети */
#define CONN_BEACON_LOST   6000       /* 6 с без маяков = связь потеряна */
/* СЕССИЯ 32 (анти-шторм): точка, которая стабильно отшивает DEAUTH'ом,
 * раньше ЗАЦИКЛИВАЛА машину подключения: полный скан (3 с) → AUTH →
 * DEAUTH → снова полный скан… до бесконечности, с сожжённым CPU.
 * Теперь: сначала 2 быстрых переподключения к ТОЙ ЖЕ точке без скана,
 * после 4 DEAUTH — FAILED (переподключение — по клику пользователя). */
#define CONN_MAX_DEAUTH    4          /* DEAUTH за сессию подключения */
#define CONN_FAST_RETRIES  2          /* из них — без пересканирования */

#define WIFI_LOG_LINES    28
/* СЕССИЯ 73 [CONSOLE]: 96 -> 160 — строки со счётчиками (скан PCI с
 * «пробую RTL8192EU (USB attach=N)») упирались в 96 байт и обрезались
 * без перевода строки — «исчезает часть текста» в логе */
#define WIFI_LOG_LINE     160

const u16 wc_channel_freq[14] = {
    2412, 2417, 2422, 2427, 2432, 2437, 2442,
    2447, 2452, 2457, 2462, 2467, 2472, 2484
};

typedef struct {
    int present, ready;
    char chip_name[40];

    /* сканирование */
    int      scanning;
    int      scan_channel;   /* индекс 0..13 */
    u32      dwell_start;
    int      pass;           /* 1 = основной, 2 = повтор драйвера */
    wifi_ap_t aps[WIFI_MAX_APS];
    int      ap_count;
    wifi_stats_t stats;

    /* ---- подключение ---- */
    wifi_conn_state_t conn;
    char     conn_ssid[33];
    u8       conn_bssid[6];
    int      conn_channel;   /* индекс 0..13 */
    u16      conn_aid;
    int      conn_attempts;
    int      conn_scans;
    u32      conn_timer;
    u32      beacon_last;
    int      conn_rssi;
    /* [W-AUTHDWELL]: окно PREAUTH (слушаем канал точки перед AUTH) */
    u32      preauth_beacons;   /* маяков от ЦЕЛЕВОЙ точки за окно */
    u32      preauth_frames0;   /* кадров всего на входе в окно */
    u8       preauth_stage;     /* 0 = после fastcc, 1 = после bring-up */
    u8       preauth_tries;    /* 1 = полный bring-up уже пробовали */
    /* [W-AUTHWINDIAG]: снапшот статистики на входе в попытку AUTH/ASSOC —
     * на таймауте печатаем дельты: отличаем «эфир пуст/шумит» от «mgmt
     * шли, но не от точки» (полевой лог итерации 11: ответ ACK-нутой
     * точки не дошёл — надо видеть, что вообще приходило в окне) */
    u32      aw_f0, aw_crc0, aw_oth0, aw_mgmt0;
    u32      aw_bcn0;           /* [W-AUTHWINDIAG2] маяки на входе в окно */
    u32      dbg_bss, dbg_tome; /* [W-ASOCDBG] mgmt от нашей BSSID / DA=мы за окно */
    u32      dbg_asp;           /* [W-ASOCDBG] assoc-resp (subtype 1) от BSSID за окно */
    u32      probe_ok;          /* [W-AUTH2] ответов НА ПРЯМОЙ probe запрос */
    u8       probe_sent;        /* [W-AUTH2] направленный probe отправлен */
    u8       probe_stage;       /* [W-AUTH2] 0 = ещё не слали, 1 = уже слали */
    char     conn_fail_reason[48];
    u8       prot_dump_left;   /* [W-PROTDUMP] лимит печати защищённых кадров
                               * (обнуляется при установке ключей — окно DHCP) */
    /* СЕССИЯ 32: параметры выбранной точки для ASSOC REQ (рейты —
     * ровно как в маяке; capability — для короткой преамбулы) */
    u16      conn_capab;
    u8       conn_rates[12];
    u8       conn_rates_len;
    /* [W-TXRATE] TX-рейт mgmt/EAPOL/данных — низший БАЗОВЫЙ рейт точки
     * (см. ap_lowest_basic_rate). По умолчанию (0) = WCRATE_1M. */
    wc_rate_t tx_rate;
    u8       assoc_rate_alt; /* 1 = после отказа status=18 слать полный набор b/g */
    /* Сессия 43: профиль точки — HT/WPA IE/PMF (в ASSOC REQ как у
     * настоящего клиента) */
    u8       conn_ht;
    u8       conn_wpa;
    u8       conn_pmf;
    int      conn_retries;   /* DEAUTH-переподключения за сессию */
    u32      last_scan_end;  /* тик завершения последнего полного скана */
    /* ротация BSSID: одноимённые SSID бывают на нескольких точках;
 * если одна стабильно отказывает — следующая попытка берёт другую */
    u8       tried_bssid[4][6];
    int      tried_n;
    char     tried_ssid[33];

    /* ---- WPA2-PSK ---- */
    u8       sec;            /* WIFI_SEC_* целевой сети */
    char     psk[65];        /* "" = открытая сеть */
    int      fw_phase;       /* 0 = ждём M1, 1 = ждём M3,
                              * 2 = ждём групповой ключ (WPA, после M4) */
    u8       fw_desc;        /* СЕССИЯ 45: дескриптор рукопожатия (2 RSN / 254 WPA) */
    u8       fw_ver;         /* версия дескриптора M1 (1 = MD5/TKIP, 2 = AES) */
    u32      fw_timer;
    int      fw_attempts;
    u32      fourway_data;   /* СЕССИЯ 44: data-кадров от точки за окно 4WAY
                              * (0 = эфир глухой — искать проблему в RX) */
    u8       anonce[32];
    u8       snonce[32];
    u8       replay[8];
    u8       replay_m1[8];   /* replay M1 — для повторного M2 после M3 */
    u8       ap_wpa_ie[40];  /* WPA IE точки (из key data M3) для эха в M2 */
    u8       ap_wpa_ie_len;
    u8       ap_rsn_ie[40];  /* СЕССИЯ 51: RSN IE точки (из assoc-resp) —
                              * Ralink сверяет IE в M2 с СОБСТВЕННЫМ IE
                              * побайтно; наш (1 пара) != её (2 пары) */
    u8       ap_rsn_ie_len;
    int      m2_rsn_tries;   /* сколько M2 уже ушло в этом рукопожатии:
                              * 0 = первый (свой IE), 1+ = эхо IE точки */
    u8       m2_apie_sent;   /* повторный M2 с IE точки уже отправлен */
    u8       pmk[32];
    char     pmk_ssid[33];
    char     pmk_psk[65];
    int      pmk_valid;
    u8       ptk[64];        /* KCK16+KEK16+TK16 (+MIC RX@48/TX@56 у
                              * TKIP-пары) после M1 */
    int      ptk_is_tkip;    /* пара TKIP (PTK-64) или CCMP (PTK-48) */
    int      pairwise_tkip;  /* СЕССИЯ 48: какой pairwise предлагаем в
                              * IE этой попытки (0=CCMP, 1=TKIP) */
    u8       assoc_variant;  /* СЕССИЯ 50: состав IE ассоциации по попыткам:
                              * 0-1 = ТОЛЬКО RSN IE (точка обязана взять
                              * RSN/WPA2-протокол; Ralink с двумя IE берёт
                              * свой сырой WPA-режим), 2-3 = оба IE;
                              * бит 0 = пара TKIP */
    int      assoc_rsn_only; /* СЕССИЯ 50: 1 = в assoc ТОЛЬКО RSN IE */
    int      assoc_fallback_tried; /* уже пробовали оба IE после отказа */
    u8       gtk[32];
    int      gtk_is_tkip;
    int      gtk_keyid;
    int      keys_installed;
    u8       ap_group_tkip;
    u32      rng_state;
    /* СЕССИЯ 51: TX-счётчик пакетных номеров (IV-заголовок строим САМИ:
     * железо 8192EU только шифрует, IV кладёт драйвер — как mac80211
     * с IEEE80211_KEY_FLAG_GENERATE_IV). Один 48-битный PN на ключ:
     * CCMP берёт его целиком, TKIP — iv16=pn&0xffff, iv32=pn>>16.
     * СЕССИЯ 52: TX только парным ключом (802.11i: станция шифрует
     * ВСЁ в сторону точки PTK, включая broadcast) — gtk_pn не нужен. */
    u64      ptk_pn;
    /* СЕССИЯ 51: диагностика data-пути (DHCP/ARP не отвечают — видно
     * уходят ли наши кадры и приходит ли хоть что-то).
     * СЕССИЯ 52: data_rx_uc — юникаст-кадры ОТ точки: бродкасты точка
     * шлёт и без нашего участия (соседи), а юникаст идёт только если
     * точка приняла наш M4/наши данные и порт открыт. */
    u32      data_tx, data_rx, data_rx_uc;
    /* Сессия 53: сколько из data_tx — ЮНИКАСТ (не бродкаст). Только
     * отправив юникаст (TCP SYN, ARP-ответ), мы вправе ждать юникаст
     * назад; во время DHCP весь наш трафик бродкастный — критерий
     * «RXuc==0 = проблема» там давал ложную тревогу. */
    u32      data_tx_uc;
    u32      data_stat_timer;

    u8       mac[6];
    u8       mac_rotated;    /* [W-MACROT]: MAC уже меняли в этом подключении */
    u16      tx_seq;
    volatile int tx_lock;
    /* [W-ASOCTRACE]: окно покадровой трассы RX после TX ASSOC REQ
     * (только mgmt-пути): trace_until — дедлайн (timer_ticks),
     * trace_burst — номер запроса (растёт на каждом TX; драйвер по
     * нему сбрасывает лимит строк трассы на новый бурст) */
    u32      trace_until, trace_burst;

    /* ---- мост 802.11 -> Ethernet (к net.c) ---- */
    u8           netrx[WIFI_NET_RXQ][WIFI_NET_RXSZ];
    u16          netrx_len[WIFI_NET_RXQ];
    int          netrx_head, netrx_tail;
    volatile int rx_lock;

    const wifi_hw_ops_t *ops;
} wifi_core_t;

static wifi_core_t wc;

/* СЕССИЯ 51: условная компиляция частых логов. По умолчанию молчат:
 * ретрансмиссии M1/M3, пофреймовые строки EAPOL — на фоне живой сети
 * их десятки, а milestone-логи (M1/M2/M3/ключи) остаются всегда.
 * [WIFI-DBG-GATE] (Task 43): WIFI_DEBUG включает и VERBOSE-уровень —
 * единый рубильник полевой отладки. */
#ifndef WIFI_VERBOSE
#define WIFI_VERBOSE 0
#endif
#if WIFI_VERBOSE || WIFI_DEBUG
#define WLOGV(...) wifi_log(__VA_ARGS__)
#else
#define WLOGV(...) do {} while (0)
#endif

/* ================= журнал (виден в приложении WiFi и dmesg) ================= */

static char    g_wlog[WIFI_LOG_LINES][WIFI_LOG_LINE];
static volatile int g_wlog_head = 0;
static volatile int g_wlog_count = 0;

void wifi_log(const char *fmt, ...) {
    char line[WIFI_LOG_LINE];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    __builtin_va_end(ap);

    int idx = g_wlog_head;
    u32 L = (u32)strlen(line);
    if (L >= WIFI_LOG_LINE) L = WIFI_LOG_LINE - 1;
    memcpy(g_wlog[idx], line, L);
    g_wlog[idx][L] = 0;
    g_wlog_head = (idx + 1) % WIFI_LOG_LINES;
    if (g_wlog_count < WIFI_LOG_LINES) g_wlog_count++;

    /* СЕССИЯ 73 [CONSOLE]: печать ОДНИМ serial_puts. serial_puts атомарен
     * на СТРОКУ (cli/sti), а три отдельных вызова («[wifi] » / текст /
 * «\n») вклинивались [boot]-логом фоновых задач между префиксом и
 * текстом — «…RTL8192EU USB)...[boot] » в журнале. */
    char sfull[WIFI_LOG_LINE + 8];
    snprintf(sfull, sizeof(sfull), "[wifi] %s\n",
             g_wlog[(g_wlog_head + WIFI_LOG_LINES - 1) % WIFI_LOG_LINES]);
    serial_puts(sfull);
    {   /* в klog — без хвостового '\n': klog_puts добавляет перевод сам,
         * иначе в dmesg после каждой wifi-строки появляется пустая */
        u32 fl = (u32)strlen(sfull);
        if (fl && sfull[fl - 1] == '\n') sfull[fl - 1] = 0;
        klog_puts(sfull);
    }
}

int wifi_log_tail(char *buf, int buf_sz, int n_lines) {
    if (!buf || buf_sz <= 0) return 0;
    int pos = 0;
    int total = g_wlog_count;
    if (n_lines <= 0 || n_lines > total) n_lines = total;
    for (int i = total - n_lines; i < total; i++) {
        int idx = (g_wlog_head + WIFI_LOG_LINES - total + i) % WIFI_LOG_LINES;
        const char *s = g_wlog[idx];
        while (*s && pos < buf_sz - 2) buf[pos++] = *s++;
        if (pos < buf_sz - 1) buf[pos++] = '\n';
    }
    if (pos < buf_sz) buf[pos] = 0; else buf[buf_sz - 1] = 0;
    return pos;
}

int wifi_log_count(void) { return g_wlog_count; }

/* ================= MAC (драйвер <- efuse/EEPROM) ================= */

void wc_set_mac(const u8 mac[6]) { memcpy(wc.mac, mac, 6); }
void wc_get_mac(u8 out[6])       { memcpy(out, wc.mac, 6); }

void wc_set_chip_name(const char *name) {
    strncpy(wc.chip_name, name ? name : "?", sizeof(wc.chip_name) - 1);
    wc.chip_name[sizeof(wc.chip_name) - 1] = 0;
}

void wc_set_state(int present, int ready) {
    wc.present = present;
    wc.ready = ready;
}

/* ================= профиль автоподключения (RAM disk WIFI.CFG) ================= */

#define WIFI_CFG_FILE "WIFI.CFG"

static int wifi_cfg_get(const char *buf, const char *key, char *out, int max)
{
    u32 klen = (u32)strlen(key);
    const char *p = buf;
    while (*p) {
        if (memcmp(p, key, klen) == 0) {
            p += klen;
            int L = 0;
            while (*p && *p != '\n' && *p != '\r' && L < max - 1)
                out[L++] = *p++;
            out[L] = 0;
            return L > 0;
        }
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    return 0;
}

int wifi_profile_load(char *out_ssid, int max) {
    out_ssid[0] = 0;
    if (!ramfs_ready()) return 0;
    char buf[192];
    u32 n = ramfs_read(WIFI_CFG_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    return wifi_cfg_get(buf, "ssid=", out_ssid, max > 33 ? 33 : max);
}

int wifi_profile_load_psk(char *out_psk, int max) {
    out_psk[0] = 0;
    if (!ramfs_ready()) return 0;
    char buf[192];
    u32 n = ramfs_read(WIFI_CFG_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    return wifi_cfg_get(buf, "psk=", out_psk, max > 65 ? 65 : max);
}

void wifi_profile_save(const char *ssid) {
    if (!ramfs_ready()) return;
    if (!ssid || !ssid[0]) {
        ramfs_delete(WIFI_CFG_FILE);
        return;
    }
    char buf[128];
    int L;
    if (wc.psk[0] && wc.sec == WIFI_SEC_WPA2_PSK)
        L = snprintf(buf, sizeof(buf), "ssid=%s\npsk=%s\n", ssid, wc.psk);
    else
        L = snprintf(buf, sizeof(buf), "ssid=%s\n", ssid);
    ramfs_delete(WIFI_CFG_FILE);
    if (ramfs_create(WIFI_CFG_FILE, (u32)L + 1))
        ramfs_write(WIFI_CFG_FILE, buf, (u32)L + 1);
}

/* ================= парсинг beacon ================= */

/* [W-RXLIVE] (полевой лог AR9285: dwell ch 1 — 0 кадров, маяк той же
 * точки ловится на dwell ch 2 с -55 dBm): бюджет журналирования
 * маяков на проход скана — сбрасывается в wifi_scan_start(). */
static u32 g_beacon_log_budget = 0;
/* [W-RXLIVE]: кадров, пойманных в ОКНЕ ПЕРЕСТРОЙКИ на канал N
 * (счёт уже N, радио ещё на N-1) — если кадры есть ТОЛЬКО в
 * переходах, приёмник глух на всём dwell: видно в пер-канальном
 * логе «(в переходе X)». */
static u32 g_chan_trans[WC_NUM_CHANNELS];

/* 802.11 beacon: FC(2) Dur(2) DA(6) SA(6) BSSID(6) Seq(2) |
 * TS(8) Interval(2) Cap(2) | tags. RSSI — от драйвера. */
static void parse_beacon(const u8 *data, int len, i8 rssi) {
    if (len < 38) return;                       /* заголовок + хоть один тег */
    if ((data[0] & 0xFC) != 0x80) return;       /* не beacon */
    const u8 *bssid = data + 16;

    u16 interval = (u16)(data[32] | (data[33] << 8));
    u16 capability = (u16)(data[34] | (data[35] << 8));

    char ssid[33];
    memset(ssid, 0, sizeof(ssid));
    u8 channel = 0;
    u8 ch_from_ds = 0;      /* [W-CHTRUST]: канал из DS IE (авторитет)
                             * или из позиции скана (догадка) */
    u8 sec = WIFI_SEC_OTHER;   /* tmp: не встретили RSN/WPA — по capability */
    u8 group_tkip = 0;         /* групповой шифр точки = TKIP */
    u8 rates[12];              /* Supported + Ext Supported из маяка */
    u8 rates_len = 0;
    /* Сессия 43: HT/смешанный WPA/PMF — из маяка */
    u8 ap_ht = 0, ap_wpa = 0, ap_pmf = 0;
    const char *rsn_reject = NULL;
    int pos = 36;
    int guard = 0;
    while (pos + 2 <= len && guard++ < 64) {
        u8 tag = data[pos], tlen = data[pos + 1];
        pos += 2;
        if (pos + tlen > len) break;
        if (tag == 0) {
            int sl = tlen;
            if (sl > 32) sl = 32;
            memcpy(ssid, data + pos, sl);
            ssid[sl] = 0;
        } else if (tag == 1 && tlen >= 1) {
            /* СЕССИЯ 32: IE Supported Rates — запоминаем РОВНО как
             * рекламирует точка (старший бит = её basic-рейт).
             * СЕССИЯ 43: 0x7E/0x7F — BSS Membership Selectors (VHT/HT),
             * это НЕ рейты — в список не кладём, но помечаем точку HT */
            for (u8 k = 0; k < tlen && rates_len < 12; k++) {
                u8 r = data[pos + k];
                if (r == 0x7E || r == 0x7F) { ap_ht = 1; continue; }
                rates[rates_len++] = r;
            }
        } else if (tag == 50 && tlen >= 1) {
            /* IE Extended Supported Rates — дописываем в хвост */
            for (u8 k = 0; k < tlen && rates_len < 12; k++) {
                u8 r = data[pos + k];
                if (r == 0x7E || r == 0x7F) { ap_ht = 1; continue; }
                rates[rates_len++] = r;
            }
        } else if (tag == 45 && tlen >= 26) {
            ap_ht = 1;                 /* HT Capabilities — точка 11n */
        } else if (tag == 3 && tlen >= 1) {
            channel = data[pos];
            ch_from_ds = 1;    /* [W-CHTRUST]: точка САМА объявила канал */
        } else if (tag == 48 && tlen >= 2) {
            /* RSN IE — WPA2. Поддерживаем: pairwise CCMP, AKM PSK.
             * ГРУППОВОЙ шифр ЛЮБОЙ (смешанный режим TKIP+AES). */
            const u8 *p = data + pos;
            u32 L = tlen, off = 2;
            int ok_ver = (p[0] == 1 && p[1] == 0);
            int pairwise_ccmp = 0, akm_psk = 0;
            int any_akm = 0, any_pair = 0;
            if (off + 4 <= L) {
                group_tkip = (memcmp(p + off, "\x00\x0F\xAC\x02", 4) == 0);
                off += 4;
            }
            if (off + 2 <= L) {
                u32 pcnt = (u32)p[off] | ((u32)p[off + 1] << 8);
                off += 2;
                for (u32 k = 0; k < pcnt && off + 4 <= L; k++, off += 4) {
                    any_pair = 1;
                    if (memcmp(p + off, "\x00\x0F\xAC\x04", 4) == 0)
                        pairwise_ccmp = 1;
                }
            }
            if (off + 2 <= L) {
                u32 acnt = (u32)p[off] | ((u32)p[off + 1] << 8);
                off += 2;
                for (u32 k = 0; k < acnt && off + 4 <= L; k++, off += 4) {
                    any_akm = 1;
                    if (memcmp(p + off, "\x00\x0F\xAC\x02", 4) == 0)
                        akm_psk = 1;
                }
            }
            /* RSN capabilities: бит 6 (0x40) = Management Frame
             * Protection Required — такие точки не принимают клиентов
             * без PMF; мы его не умеем — честно покажем в диагностике */
            if (off + 2 <= L && ((u16)(p[off] | (p[off + 1] << 8)) & 0x0040))
                ap_pmf = 1;
            if (ok_ver && pairwise_ccmp && akm_psk)
                sec = WIFI_SEC_WPA2_PSK;
            else if (ok_ver) {
                sec = WIFI_SEC_OTHER;         /* Enterprise/SAE/TKIP-only */
                if (!pairwise_ccmp && any_pair)
                    rsn_reject = "pairwise без CCMP";
                else if (!akm_psk && any_akm)
                    rsn_reject = "AKM без PSK (Enterprise/SAE?)";
                else if (!any_pair || !any_akm)
                    rsn_reject = "короткий RSN IE";
                else
                    rsn_reject = "версия RSN != 1";
            }
        } else if (tag == 221 && tlen >= 8 &&
                   memcmp(data + pos, "\x00\x50\xF2\x01\x01\x00", 6) == 0) {
            /* WPA IE (Microsoft OUI 00:50:F2, тип 01, версия 01:00).
             * СЕССИЯ 43: маяк с WPA IE = смешанная точка — в ассоциации
             * реальный клиент шлёт ОБА IE (RSN + WPA) */
            ap_wpa = 1;
            const u8 *p = data + pos + 6;
            u32 left = tlen - 6;
            int pairwise_ccmp = 0, akm_psk = 0;
            if (left >= 4) {
                group_tkip = (memcmp(p, "\x00\x50\xF2\x02", 4) == 0);
                p += 4; left -= 4;
            }
            if (left >= 2) {
                u32 pcnt = (u32)p[0] | ((u32)p[1] << 8);
                p += 2;
                for (u32 k = 0; k < pcnt && left >= 6; k++, p += 4, left -= 4)
                    if (memcmp(p, "\x00\x50\xF2\x04", 4) == 0)
                        pairwise_ccmp = 1;
            }
            if (left >= 2) {
                u32 acnt = (u32)p[0] | ((u32)p[1] << 8);
                p += 2;
                for (u32 k = 0; k < acnt && left >= 6; k++, p += 4, left -= 4)
                    if (memcmp(p, "\x00\x50\xF2\x02", 4) == 0)
                        akm_psk = 1;
            }
            if (pairwise_ccmp && akm_psk)
                sec = WIFI_SEC_WPA2_PSK;      /* WPA с CCMP — как WPA2 */
            else if (sec == WIFI_SEC_OTHER)
                sec = WIFI_SEC_WPA_PSK;       /* TKIP-only — не поддержано */
        }
        pos += tlen;
    }
    if (ssid[0] == 0) return;                   /* hidden SSID */

    if (channel == 0) channel = (u8)(wc.scan_channel + 1);
    if (channel < 1 || channel > 14) channel = 1;

#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): покадровый маяк-трасс скана */
    /* [W-RXLIVE]: каждый маяк прохода скана — ГДЕ СЛУШАЛИ (позиция
     * скана), что заявила ТОЧКА (DS IE) и с каким RSSI поймали.
     * Расхождение «dwell vs DS» сразу выдаёт расстройку радиотракта
     * или приём соседнего канала. Бюджет обнуляется на старте скана. */
    if (wc.scanning && g_beacon_log_budget > 0) {
        g_beacon_log_budget--;
        wifi_log("маяк: dwell ch %d, DS=%s%d, RSSI %d, \"%s\"",
                 wc.scan_channel + 1,
                 ch_from_ds ? "ch " : "нет(", (int)channel,
                 (int)rssi, ssid);
    }
#endif

    /* уже видели эту точку? — обновляем RSSI/канал/защиту */
    for (int i = 0; i < wc.ap_count; i++) {
        if (memcmp(wc.aps[i].bssid, bssid, 6) == 0) {
            /* [W-HEARDON]: зафиксировать, на каком dwell-канале скана
             * услышан маяк ЭТОЙ точки (гистограмма печатается по концу
             * скана — расхождение с DS-каналом точки = симптом) */
            if (wc.scanning && wc.scan_channel >= 0 &&
                wc.scan_channel < WC_NUM_CHANNELS)
                wc.aps[i].heard[wc.scan_channel]++;
            /* [W-AUTHDWELL]: маяк от целевой точки в окне PREAUTH —
             * на её канале после настройки на неё */
            if (wc.conn == WIFI_CONN_PREAUTH &&
                0 == memcmp(wc.conn_bssid, bssid, 6))
                wc.preauth_beacons++;
            if (rssi > wc.aps[i].rssi) wc.aps[i].rssi = rssi;
            /* [W-CHTRUST] (полевой лог AR9285: точка найдена «ch 1 (94)»
             * при сильном сигнале -59 на ch 4): канал записи перекрывался
             * СЛАБЫМ маяком, пойманным на краю соседнего канала — без DS
             * IE (или до его разбора) парсер подставлял канал СКАНА, и
             * запись «уходила» на чужой канал: подключение перестраивало
             * радио мимо точки (RSSI -94, AUTH без ACK). Теперь:
             *  - DS IE точки (её собственное объявление) — авторитет всегда;
             *  - канал по позиции скана — только от маяка НЕ СЛАБЕЕ
             *    уже сохранённого замера (пролезший через фильтр соседний
             *    канал всегда на десятки dB слабее прямого). */
            if (ch_from_ds)
                wc.aps[i].channel = channel;
            else if (rssi >= wc.aps[i].rssi && channel)
                wc.aps[i].channel = channel;
            u8 encrypted = (capability & 0x0010) ? 1 : 0;
            wc.aps[i].sec = encrypted ? (u8)sec : (u8)WIFI_SEC_OPEN;
            wc.aps[i].group_tkip = group_tkip;
            wc.aps[i].ht = ap_ht;
            wc.aps[i].wpa = ap_wpa;
            wc.aps[i].pmf = ap_pmf;
            if (wc.aps[i].rates_len == 0 && rates_len > 0) {
                memcpy(wc.aps[i].rates, rates, rates_len);
                wc.aps[i].rates_len = rates_len;
            }
            return;
        }
    }
    if (wc.ap_count < WIFI_MAX_APS) {
        wifi_ap_t *ap = &wc.aps[wc.ap_count++];
        memset(ap, 0, sizeof(*ap));
        strncpy(ap->ssid, ssid, 32);
        memcpy(ap->bssid, bssid, 6);
        ap->rssi = rssi;
        ap->channel = channel;
        ap->beacon_interval = (u8)(interval / 10);
        ap->capability = capability;
        ap->encrypted = (capability & 0x0010) ? 1 : 0;
        if (!ap->encrypted)
            sec = WIFI_SEC_OPEN;
        ap->sec = (u8)sec;
        ap->group_tkip = group_tkip;
        ap->ht = ap_ht;
        ap->wpa = ap_wpa;
        ap->pmf = ap_pmf;
        if (rates_len > 0) {
            memcpy(ap->rates, rates, rates_len);
            ap->rates_len = rates_len;
        }
        wc.stats.aps = (u32)wc.ap_count;
        static const char *secname[4] = { "открытая", "WPA2", "WPA", "WEP/др" };
        wifi_log("ch %d: новая сеть \"%s\" RSSI %d dBm [%s%s]",
                 channel, ssid, (int)rssi, secname[sec],
                 (sec == WIFI_SEC_WPA2_PSK && group_tkip)
                     ? ", группа TKIP" : "");
        if (rsn_reject && ap->encrypted)
            wifi_log("  RSN сети \"%s\" не поддержан: %s", ssid, rsn_reject);
        if (ap_pmf)
            wifi_log("  сеть \"%s\" требует PMF (802.11w) — подключение не гарантируется", ssid);
    }
}

/* ==== ТЕСТОВЫЙ ДОСТУП (харнесс rtlwifi компилирует этот файл) ==== */
#ifdef WIFI_CORE_TEST
wifi_stats_t *wc_test_stats(void) { return &wc.stats; }
int wc_test_ap_count(void) { return wc.ap_count; }
const wifi_ap_t *wc_test_ap(int i) { return &wc.aps[i]; }
wifi_conn_state_t wc_test_conn(void) { return wc.conn; }
const char *wc_test_conn_fail(void) { return wc.conn_fail_reason; }
const char *wc_test_ssid(void) { return wc.conn_ssid; }
int wc_test_keys_installed(void) { return wc.keys_installed; }
void wc_test_set_ready(void) { wc.present = 1; wc.ready = 1; wc.scan_channel = -1; }
#endif

/* ================= RX: приём кадров от драйвера ================= */

static void conn_handle_mgmt(const u8 *frame, u32 len);
static void bridge_rx_to_net(const u8 *frame, u32 len);
static void wpa2_rx_eapol(const u8 *eth_payload, u32 len);
static void conn_hw_bssid(u16 aid);   /* [W-M1ASSOC] вызывается из wc_rx_frame */

/* [W-RXLAT] (итерация 14): окно глухоты RX сразу после НАШЕГО TX?
 * Гипотеза полевого лога 12: маяки идут (RX жив), но ответ точки на
 * AUTH/PROBE (первая попытка - через ~50-100 мкс, ретраи ~5 мс) не
 * приходит ВООБЩЕ. Меряем зазор «TxDone -> первый принятый кадр»:
 * на занятом канале он должен быть 0-10 мс; стабильно >5 мс сразу
 * после TX = RX слепнет после передачи (AGC/NF не восстанавливаются). */
static u32 g_tx_done_tick = 0;       /* тик последнего TxDone (mgmt TX) */
static int  g_tx_gap_logged = 0;
void wc_tx_done_note(void)  { g_tx_done_tick = timer_ticks(); }
/* [W9-RXLAT2]: сброс лимитера зазоров на каждую попытку AUTH/ASSOC —
 * раньше логировались только ПЕРВЫЕ 4 зазора за загрузку (все уходили
 * на probe/auth первого цикла), и слепое пятно накрывало именно фазу
 * ASSOC — где гипотеза «глухоты после TX» не проверена вовсе. */
void wc_tx_gap_reset(void) { g_tx_gap_logged = 0; }
void wc_rx_gap_check(void) {
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): PHY-диагностика глухоты после TX */
    if (g_tx_gap_logged >= 8 || !g_tx_done_tick) return;
    u32 now = timer_ticks();
    u32 gap = now - g_tx_done_tick;
    if (gap > 0 && gap <= 2000u) {       /* первый кадр в течение 2 с */
        g_tx_gap_logged++;
        wifi_log("RX-зазор после TX: %u мс%s",
                 (unsigned)gap,
                 gap > 5 ? " — ГЛУХОТА после TX?" : "");
        g_tx_done_tick = 0;
    }
#endif
}

void wc_rx_err(int crc) {
    if (crc) {
        wc.stats.crc_err++;
        if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
            wc.stats.chan_crc[wc.scan_channel]++;
    } else {
        wc.stats.other++;
    }
}

/* [W-SNAPSCAN] (полевой лог HomeWifi 26.10: «TRACE: data fc=0288 to-me
 * len=139 ... body[113]=10 aa aa aa 03 00 00 00 88 8e 01 03 00 5f 02 00» —
 * AP (TP-Link) вставляет 2 байта (10 aa) между QoS-заголовком (26) и
 * LLC/SNAP; арифметика кадра сходится: 139 = 28 hdr + 8 LLC + 99 EAPOL
 * + 4 FCS). Прежний код требовал LLC СТРОГО на 24/26 — и [W-M1ASSOC],
 * и bridge_rx_to_net_ex выбрасывали кадр: EAPOL M1 БЫЛ ПРИНЯТ железом
 * (r=0b = 6M OFDM, -73 дБм) и молча выброшен парсером → 4-way не
 * начался → DEAUTH reason=15. Ищем сигнатуру SNAP (AA AA 03 000000)
 * в диапазоне hdr..hdr+4 (QoS +2, Order/HTC +4, паддинг AP +2).
 * Возвращает смещение LLC или 0. hdr передаёт вызывающий (в _ex он
 * уже включает срез IV расшифрованных кадров). */
static u32 wc_snap_off(const u8 *frame, u32 len, u32 hdr) {
    if (hdr + 6 > len) return 0;
    for (u32 off = hdr; off <= hdr + 4 && off + 6 <= len; off++) {
        if (frame[off]     == 0xAA && frame[off + 1] == 0xAA &&
            frame[off + 2] == 0x03 && frame[off + 3] == 0x00 &&
            frame[off + 4] == 0x00 && frame[off + 5] == 0x00)
            return off;
    }
    return 0;
}

void wc_rx_frame(const u8 *frame, int len, i8 rssi) {
    wc_rx_gap_check();                   /* [W-RXLAT] */
    wc.stats.frames++;
    if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
        wc.stats.chan_frames[wc.scan_channel]++;
    if (len < 2) return;
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if ((fc & 0xFC) == 0x80) {            /* beacon */
        wc.stats.beacons++;
        if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
            wc.stats.chan_beacons[wc.scan_channel]++;
        parse_beacon(frame, len, rssi);
        /* маяк нашей точки: живём (контроль потери связи) */
        if (wc.conn == WIFI_CONN_CONNECTED && len >= 22 &&
            memcmp(frame + 16, wc.conn_bssid, 6) == 0) {
            wc.beacon_last = timer_ticks();
            wc.conn_rssi = rssi;
        }
        return;
    }
    /* [W-AUTHWINDIAG] mgmt-кадры (не маяки) — считаем ВСЕГДА, даже вне
     * подключения: дельта за окно AUTH показывает, шли ли чужие маяки/
     * пробы и был ли в эфире вообще хоть один management-кадр */
    if (((fc >> 2) & 0x3) == 0)
        wc.stats.mgmt++;
    /* кадры ассоциации и данные нашей точки */
    if (wc.conn == WIFI_CONN_OFF || wc.conn == WIFI_CONN_FAILED)
        return;
    u8 type = (u8)((fc >> 2) & 0x3);
    if (type == 0)
        conn_handle_mgmt(frame, (u32)len);        /* mgmt: AUTH/ASSOC/DEAUTH */
    else if (type == 2) {
        /* [W-M1ASSOC] (полевой лог esp32test: сразу после ASSOC REQ пришёл
         * DATA-кадр fc=0208 (FromDS) с A1=наш MAC — вероятный EAPOL M1;
         * DEAUTH reason=15 HomeWifi = «4-way timeout»: AP засчитала
         * ассоциацию и начала рукопожатие, а мы дропали её data-кадры,
         * потому что ASSOC-RSP к нам не дошёл. Если в состоянии ASSOC от
         * нашей точки пришёл EAPOL (LLC AA AA 03 000000 888E) — считаем
         * ассоциацию состоявшейся и входим в рукопожатие. */
        if (wc.conn == WIFI_CONN_ASSOC && len >= 34 &&
            memcmp(frame + 4, wc.mac, 6) == 0 &&
            memcmp(frame + 10, wc.conn_bssid, 6) == 0) {
            u32 h = ((fc & 0x0090u) == 0x0080u) ? 26u : 24u;   /* QoS-data: +2 */
            /* [W-SNAPSCAN]: LLC ищем в h..h+4 — HomeWifi вставляет 2 байта
             * паддинга после QoS-заголовка (M1 доходит, но прежде выбрасы-
             * вался здесь: LLC была на h+2, а не на h). */
            u32 off = wc_snap_off(frame, (u32)len, h);
            if (off && off + 8 <= (u32)len &&
                frame[off + 6] == 0x88 && frame[off + 7] == 0x8E) {
                if (wc.conn_aid == 0) wc.conn_aid = 1;   /* AID неизвестен */
                wc.beacon_last = timer_ticks();
                conn_hw_bssid(wc.conn_aid);              /* AID в железо */
                wc.ops->rx_filter_bss();
                if (wc.sec == WIFI_SEC_WPA2_PSK) {
                    wc.conn = WIFI_CONN_4WAY;
                    wc.fw_phase = 0;
                    wc.fw_attempts = 0;
                    wc.fourway_data = 0;
                    wc.fw_timer = timer_ticks();
                } else {
                    wc.conn = WIFI_CONN_CONNECTED;
                }
                wifi_log("M1 без ASSOC-RSP (fc=%04x len=%u LLC@%u%s) — считаю "
                         "ассоциацию состоявшейся (AID=%u), вхожу в рукопожатие",
                         (unsigned)fc, (unsigned)len, (unsigned)off,
                         off != h ? " паддинг AP" : "", (unsigned)wc.conn_aid);
            }
        }
        if (wc.conn == WIFI_CONN_CONNECTED ||
            wc.conn == WIFI_CONN_4WAY) {
            /* data: в стек (после подключения) и EAPOL рукопожатию (в 4WAY) */
            if (wc.conn == WIFI_CONN_4WAY) {
                wc.fourway_data++;
                /* СЕССИЯ 44: первые data-кадры в окне рукопожатия — раньше
                 * по логу нельзя было понять, доходит ли эфир вообще (если
                 * счётчик = 0 при таймауте, M1 теряется в RX, а не в парсере) */
                if (wc.fourway_data <= 3)
                    WLOGV("4WAY: data-кадр #%u (len=%d fc=%04x)",
                             (unsigned)wc.fourway_data, len, fc);
            }
            bridge_rx_to_net(frame, (u32)len);
        }
    }
}

/* ================= TX: построители кадров 802.11 =================
 * Драйвер получает готовый кадр через ops->tx_frame (рейт логический). */

/* [W-SEQ3] записать Sequence Control (байты 22/23 кадра). ПОЛЕВОЙ ЛОГ 15
 * ПОКАЗАЛ, ЧТО [W-SEQ2] САМА БЫЛА ОШИБКОЙ: 802.11 (9.2.4.4.2) — SC это
 * 16-битное LE-поле, биты [3:0] = НОМЕР ФРАГМЕНТА, [15:4] = НОМЕР
 * ПОСЛЕДОВАТЕЛЬНОСТИ. На проводе: байт22 = (seq[3:0]<<4) | frag[3:0],
 * байт23 = seq[11:4]. [W-SEQ2] писала seq в младший байт ЦЕЛИКОМ
 * (байт22 = seq&0xFF, байт23 = seq>>8&0xF): при seq=3 на провод уходил
 * SC = 0x0003 = «фрагмент 3, последовательность 0» (видно в дампе
 * AUTH REQ лога 15: «... 03 00 00 00 01 00 ...»). Точка честно ACK-ит
 * (ACK не разбирает SC), но кадр с «фрагментом 3 без первого фрагмента»
 * отбрасывает — ЭТО и была вся история «AUTH ACK-ится — ответа нет»
 * (итерации 12-15). А «баг» который чинила [W-SEQ2] был другим: прежний
 * код писал только младший байт (f[22] = (seq<<4)&0xFF, f[23] всегда 0),
 * т.е. seq оборачивался каждые 16 кадров — дубликаты, тоже «ответа нет»
 * (итерации 5-11). Теперь ЧЕСТНО 12-битная последовательность + frag=0. */
static void put_seq_ctrl(u8 *f)
{
    u16 sc = (u16)((wc.tx_seq & 0xFFFu) << 4);   /* frag = 0 */
    f[22] = (u8)(sc & 0xFFu);
    f[23] = (u8)(sc >> 8);
    wc.tx_seq = (u16)((wc.tx_seq + 1u) & 0xFFFu);
}

/* Общий заголовок mgmt: FC(2) Dur(2) addr1=DA addr2=SA addr3=BSSID Seq(2) */
static void put_mgmt_hdr(u8 *f, u16 fc, const u8 *da, u32 *pos) {
    f[0] = (u8)(fc & 0xFF);
    f[1] = (u8)(fc >> 8);
    f[2] = 0x3A; f[3] = 0x00;                 /* duration 58 мкс */
    memcpy(f + 4, da, 6);
    memcpy(f + 10, wc.mac, 6);
    memcpy(f + 16, wc.conn_bssid, 6);
    put_seq_ctrl(f);                          /* [W-SEQ2] */
    *pos = 24;
}

static int tx_mgmt_frame(u16 fc, const u8 *body, u32 body_len, wc_rate_t rate) {
    u8 f[128];
    u32 pos = 0;
    u8 da[6];
    memcpy(da, wc.conn_bssid, 6);
    put_mgmt_hdr(f, fc, da, &pos);
    if (pos + body_len > sizeof(f)) return 0;
    memcpy(f + pos, body, body_len);
    pos += body_len;
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): байтовый дамп AUTH REQ */
    /* [W-AUTHDUMP] (итерация 12): ОДИН раз за загрузку дампим AUTH REQ
     * целиком — сверка байт-в-байт с захватом настоящего клиента. Кадр
     * ACK-ится точкой (st1=1), но ответа нет: исключаем «не то тело» на
     * проводе (порядок полей, длительность, SC). */
    if (fc == 0x00B0) {
        static int s_dumped = 0;
        if (!s_dumped) {
            s_dumped = 1;
            char line[176];   /* [W-AUTHDUMP2] 96 \u043c\u0430\u043b\u043e: 30 \u0431\u0430\u0439\u0442 = 90+ \u0441\u0438\u043c\u0432. \u2014 \u0434\u0430\u043c\u043f \u043e\u0431\u0440\u0435\u0437\u0430\u043b\u0441\u044f \u043d\u0430 16-\u043c \u0431\u0430\u0439\u0442\u0435 */
            u32 o = 0;
            o += (u32)snprintf(line + o, sizeof(line) - o,
                               "AUTH REQ байты (%u):", (unsigned)pos);
            for (u32 k = 0; k < pos && o + 3 < sizeof(line); k++)
                o += (u32)snprintf(line + o, sizeof(line) - o, " %02x", f[k]);
            wifi_log("%s", line);
        }
    }
#endif /* WIFI_DEBUG */
    return wc.ops->tx_frame(f, pos, rate, 7, 0, -1);
}

/* Authentication Request (открытая система): algo=0, seq=1, status=0.
 * [W-TXRATE] рейт — параметр: попытки AUTH чередуют базовый рейты
 * (см. conn_step, WIFI_CONN_AUTH). */
static int tx_auth_req(wc_rate_t rate) {
    u8 body[6] = { 0, 0, 1, 0, 0, 0 };
    return tx_mgmt_frame(0x00B0, body, 6, rate);
}

/* [W-AUTH2] Directed PROBE REQUEST (SSID точки): решающий тест
 * «слышит/отвечает ли точка НАМ» — ответ приходит КАСТОМНО нам
 * (addr1 = наш MAC, SA = точка). wpa_supplicant шлёт directed probe
 * перед каждым подключением; мы прежде сканировали только ПАССИВНО и
 * сразу AUTH — точка могла игнорировать «неопрошенного» клиента. */
static int tx_probe_req(const char *ssid, wc_rate_t rate) {
    u8 f[96];
    u32 pos = 0;
    put_mgmt_hdr(f, 0x0040, wc.conn_bssid, &pos);   /* DA = точка */
    u32 sl = (u32)strlen(ssid);
    if (sl > 32) sl = 32;
    f[pos++] = 0;                                   /* IE 0: SSID */
    f[pos++] = (u8)sl;
    memcpy(f + pos, ssid, sl); pos += sl;
    u8 rates[8] = { 0x82, 0x84, 0x8B, 0x96 };       /* basic 1/2/5.5/11 */
    f[pos++] = 1;                                   /* IE 1: Supported Rates */
    f[pos++] = 4;
    memcpy(f + pos, rates, 4); pos += 4;
    return wc.ops->tx_frame(f, pos, rate, 4, 1, -1);/* noack — ответа-ACK не ждём */
}

/* [W-TXRATE] имя рейта для лога */
static const char *wc_rate_name(wc_rate_t r) {
    static const char *nm[5] = { "1M", "2M", "5.5M", "11M", "6M" };
    return ((unsigned)r <= WCRATE_6M) ? nm[(int)r] : "1M";
}

/* [W-TXRATE] низший БАЗОВЫЙ рейт точки из маяка (Supported+Ext Rates с
 * basic-битом 0x80) — ЭТИМ рейтом шлём mgmt/EAPOL/данные, как это делает
 * wpa_supplicant. Раньше всё уходило на жёстком CCK 1 Мбит/с: точка с
 * выключенными b-рейтами (beacon на OFDM) CCK-кадры НЕ СЛЫШИТ и не ACK-ит
 * — ровно тот «TX отказ: ретраи исчерпаны», что виден в полевом логе
 * AR9285 при слышимых маяках. */
static wc_rate_t ap_lowest_basic_rate(const wifi_ap_t *ap) {
    u8 best = 0xFF;
    for (u32 k = 0; ap && k < ap->rates_len; k++) {
        u8 r = ap->rates[k];
        if (!(r & 0x80)) continue;              /* не basic */
        u8 v = r & 0x7F;
        if (v >= 0x7E) continue;                /* HT/VHT селектор */
        if (v < best) best = v;
    }
    switch (best) {
    case 0x02: return WCRATE_1M;
    case 0x04: return WCRATE_2M;
    case 0x0B: return WCRATE_5_5M;
    case 0x16: return WCRATE_11M;
    default:   return (best != 0xFF) ? WCRATE_6M   /* OFDM-базовые -> 6 Мбит/с */
                                     : WCRATE_1M;  /* базовые не объявлены */
    }
}

/* Association Request: listen=3, IE: SSID + rates (+RSN/WPA/HT/WMM).
 * СЕССИЯ 32: capability зеркалим по точке (ESS всегда, Short Preamble —
 * если точка сама его рекламирует: строгие точки отказывают в ассоциации
 * без него).
 * СЕССИЯ 38 (status=18): рейты — ОБЪЕДИНЕНИЕ набора точки из маяка
 * (с её basic-битами) и полного стандарта b/g.
 * СЕССИЯ 43 (status=18 на WPA2-точке с полным набором b/g): по
 * 802.11-2016 status 18 = REFUSED_BASIC_RATES_MISMATCH покрывает и
 * Basic HT-MCS Set — точка 11n отвечает 18 клиенту без HT Capabilities
 * IE. Запрос приведён к виду настоящего клиента (wpa_supplicant):
 *  - рейты отсортированы по возрастанию (basic-биты точки сохранены);
 *  - Short Slot Time (0x0400) зеркалим из capability точки;
 *  - HT Capabilities IE (45), если точка HT (IE 45 или селектор 0x7E/0x7F);
 *  - RSN IE + WPA IE для смешанных точек (оба, как у реального клиента);
 *  - WMM IE — заявляем QoS-клиента (RX-мост умеет QoS и A-MSDU). */
static const u8 wc_std_rates[12] = {   /* 1,2,5.5,11,6,9,12,18,24,36,48,54 Мбит */
    0x02, 0x04, 0x0B, 0x16, 0x0C, 0x12, 0x18, 0x24, 0x30, 0x48, 0x60, 0x6C
};

/* HT Capabilities IE (26 байт): 20 МГц, SM Power Save static (0x0000),
 * A-MPDU до 64К. Хватает, чтобы точка видела нас HT-клиентом.
 * [W-HTHONEST] (HomeWifi/byfly: ASSOC REQ ACK-ится, ответа нет):
 * прежние 0x0300 врали о возможностях — LDPC-декода у AR9285 НЕТ,
 * 40 МГц мы не включаем. Честный профиль 1x1/20 МГц-клиента (как у
 * настоящего ноутбука на 9285): RX MCS 0-7 (один поток).
 * [W-HTZERO] (поле): HT caps info = 0x0000 — SM PS static, без Green
 * Field/SMPS-disabled-комбинации 0x000C, к которой были вопросы у
 * прошивок точек (Reserved/Supported-Channel-Width трактовки). */
static u32 wc_build_ht_caps(u8 *out) {
    static const u8 body[26] = {
        0x00, 0x00,                   /* [W-HTZERO] HT caps info = 0: SM PS static,
                                         без Green Field/Reserved-комбинаций 0x0C —
                                         вопрос прошивок точек к 0x0C снят */
        0x0F,                         /* A-MPDU: exp 3, spacing 7 */
        0xFF, 0x00,                   /* RX MCS 0-7 (1 пространственный поток) */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00,                   /* HT extended caps */
        0x00, 0x00, 0x00, 0x00,       /* TX beamforming */
        0x00                          /* ASEL */
    };
    out[0] = 45;
    out[1] = sizeof(body);
    memcpy(out + 2, body, sizeof(body));
    return (u32)sizeof(body) + 2;
}

/* WMM Information IE станции (221, тело 7 байт): заявка QoS-клиента */
static const u8 wc_wmm_ie[9] = {
    221, 7, 0x00, 0x50, 0xF2, 0x02, 0x00, 0x01, 0x00
};

/* Объединённый набор рейтов + сортировка по возрастанию (вставками,
 * стабильная — basic-биты точки остаются на своих значениях). */
static u32 wc_build_rates(u8 *out) {
    u8 rates[24];
    u32 rn = 0;
    if (!wc.assoc_rate_alt) {
        for (u32 k = 0; k < wc.conn_rates_len && rn < 24; k++)
            rates[rn++] = wc.conn_rates[k];
    } else {
        rates[rn++] = 0x82; rates[rn++] = 0x84;   /* 1, 2 — basic */
        rates[rn++] = 0x8B; rates[rn++] = 0x96;   /* 5.5, 11 — basic */
    }
    for (u32 k = 0; k < 12 && rn < 24; k++) {
        u8 r = wc_std_rates[k];
        int have = 0;
        for (u32 j = 0; j < rn; j++)
            if ((rates[j] & 0x7F) == (r & 0x7F)) { have = 1; break; }
        if (!have) rates[rn++] = r;               /* добавляем без basic-бита */
    }
    for (u32 i = 1; i < rn; i++) {                /* сортировка по рейту */
        u8 v = rates[i];
        u32 j = i;
        while (j > 0 && (rates[j - 1] & 0x7F) > (v & 0x7F)) {
            rates[j] = rates[j - 1];
            j--;
        }
        rates[j] = v;
    }
    memcpy(out, rates, rn);
    return rn;
}

static int tx_assoc_req(const char *ssid) {
    u8 f[256];
    u32 pos = 0;
    /* [W-ASSOCBARE] (HomeWifi/byfly: ACK на КАЖДЫЙ ASSOC REQ — ответа нет;
    * esp32test тот же кадр принимал): попытки 4-5 уходят в «bare»-виде —
    * без HT и WMM IE. Если строгая точка молчит из-за своего IE-парсера
    * (A-MPDU/ASEL-байты, QoS-заявка) — bare-попытка ДОЛЖНА получить
    * ответ; если и она молчит — дело НЕ в содержимом IE.
    * [W9-LEGACY1M] (полевая пара esp32test: Windows на ТОМ ЖЕ железе
    * ассоциируется сразу; наша точка логирует «station join, AID=1» на
    * КАЖДЫЙ наш запрос = AP assoc ПРИНЯЛА и RSP построила, но до парсера
    * она не доходит ни разу — 0/17; при этом AUTH-RSP (1M) и PROBE-RSP
    * доходит, а за ВСЁ время наблюдений не принят ни один HT/MCS-кадр —
    * весь HT-трафик соседей лежит в «прочих» как PHY-err). Гипотеза:
    * AP шлёт ASSOC-RSP на HT-рейте (MCS) станции, заявившей HT caps,
    * а наш RX HT не демодулирует. LEGACY-вариант: SupportedRates =
    * ТОЛЬКО 1 Мбит/с basic, БЕЗ HT/WMM — тогда любой sane rate-control
    * обязан слать нам всё ≤1M. Порядок: попытка 2 (обычный цикл) и
    * попытки 1-2 после ротации MAC (в точке свежая запись — HT ни разу
    * не заявлен). Если точка ответит status=18 — есть штатный fallback
    * на полный набор. */
    u32 bare = (wc.conn_attempts >= 4);
    u32 legacy1m = (wc.conn_attempts == 2) ||
                   (wc.mac_rotated && wc.conn_attempts <= 2);
    put_mgmt_hdr(f, 0x0000, wc.conn_bssid, &pos);
    u16 cap = 0x0001;                          /* ESS */
    if (wc.conn_capab & 0x0020) cap |= 0x0020; /* Short Preamble как у точки */
    if (wc.conn_capab & 0x0010) cap |= 0x0010; /* Privacy как у точки (WEP/WPA) */
    if (wc.conn_capab & 0x0400) cap |= 0x0400; /* Short Slot Time как у точки */
    f[pos++] = (u8)(cap & 0xFF);
    f[pos++] = (u8)(cap >> 8);
    f[pos++] = 3;   f[pos++] = 0x00;           /* listen interval (как у реальных клиентов) */
    /* IE 0: SSID */
    u32 sl = (u32)strlen(ssid);
    if (sl > 32) sl = 32;
    f[pos++] = 0;
    f[pos++] = (u8)sl;
    memcpy(f + pos, ssid, sl); pos += sl;
    /* IE 1 + IE 50: рейты — отсортированное объединение набора точки
     * и стандарта b/g (как у wpa_supplicant) */
    u8 rates[24];
    u32 rn = wc_build_rates(rates);
    if (legacy1m) {                        /* [W9-LEGACY1M] */
        rates[0] = 0x82;                   /* 1 Мбит/с basic — единственный */
        rn = 1;
    }
    u32 n1 = rn > 8 ? 8 : rn;
    f[pos++] = 1; f[pos++] = (u8)n1;
    memcpy(f + pos, rates, n1); pos += n1;
    if (rn > n1) {
        u32 n2 = rn - n1;
        f[pos++] = 50; f[pos++] = (u8)n2;
        memcpy(f + pos, rates + n1, n2); pos += n2;
    }
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): IE-состав ASSOC REQ */
    /* диагностика (СЕССИЯ 38/43): что реально уходит в ASSOC REQ */
    {
        char dbg[96];
        u32 o = 0;
        o += (u32)snprintf(dbg + o, sizeof(dbg) - o, "ASSOC REQ: rates %u:",
                           (unsigned)rn);
        for (u32 k = 0; k < rn && k < 12 && o + 4 < sizeof(dbg); k++)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " %02x", rates[k]);
        if (rn > 12)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " +%u",
                               (unsigned)(rn - 12));
        if (legacy1m)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " LEGACY-1M");
        else if (wc.conn_ht)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, bare ? " bare" : " HT");
        else if (bare)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " bare");
        if (wc.conn_wpa)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " WPA");
        wifi_log("%s (cap=%04x)", dbg, (unsigned)cap);
    }
#endif
    /* HT Capabilities — точка 11n считает клиента без него несовместимым
     * (status 18 «Basic HT-MCS»/27 «нет HT»); [W-ASSOCBARE] попытки 4-5 —
     * без него */
    if (wc.conn_ht && !bare && !legacy1m)      /* [W9-LEGACY1M]: без HT */
        pos += wc_build_ht_caps(f + pos);
    /* RSN IE для WPA2-сетей (CCMP + PSK) — без него точка отклонит
     * ассоциацию или не начнёт рукопожатие */
    if (wc.sec == WIFI_SEC_WPA2_PSK) {
        pos += wpa2_build_rsn_ie(f + pos, wc.ap_group_tkip,
                                 wc.pairwise_tkip);
        /* СЕССИЯ 50: WPA IE добавляем ТОЛЬКО если точка отказала ассоциа-
         * ции без него (fallback). С двумя IE Ralink-точки выбирают свой
         * WPA-режим (дескриптор 254) вместо стандартного RSN — из-за этого
         * рукопожатие и буксовало. RSN-only = как WPA2-only клиент. */
        if (wc.conn_wpa && !wc.assoc_rsn_only)
            pos += wpa2_build_wpa_ie(f + pos, wc.ap_group_tkip,
                                     wc.pairwise_tkip);
    }
    /* WMM IE — заявка QoS-клиента (строгие точки с WMM-only отказывают
     * ассоциацию без него); [W-ASSOCBARE] — на bare-попытках не шлём */
    if (!bare && !legacy1m) {                  /* [W9-LEGACY1M]: без WMM */
        memcpy(f + pos, wc_wmm_ie, sizeof(wc_wmm_ie));
        pos += sizeof(wc_wmm_ie);
    }
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): байтовый дамп ASSOC REQ */
    /* [W-ASOCDUMP] (HomeWifi/byfly: ACK на КАЖДЫЙ запрос — ответа нет;
     * esp32test тот же самый кадр принимал): один раз за загрузку дампим
     * ASSOC REQ целиком — байт-в-байт сверка со сниффером настоящего
     * клиента. Наш кадр отличается от AUTH/PROBE (на которые точки
     * ОТВЕЧАЮТ) только телом IE — на проводе должно быть видно, чем. */
    {
        static int s_dumped = 0;
        if (!s_dumped) {
            s_dumped = 1;
            for (u32 k = 0; k < pos; k += 40) {
                char line[160];
                u32 o = 0;
                u32 e = (k + 40 < pos) ? k + 40 : pos;
                o += (u32)snprintf(line + o, sizeof(line) - o,
                                   "ASSOC REQ[%u..%u]:",
                                   (unsigned)k, (unsigned)(e - 1));
                for (u32 b = k; b < e && o + 4 < sizeof(line); b++)
                    o += (u32)snprintf(line + o, sizeof(line) - o, " %02x", f[b]);
                wifi_log("%s", line);
            }
        }
    }
#endif /* WIFI_DEBUG */
    return wc.ops->tx_frame(f, pos, wc.tx_rate, 7, 0, -1);
}

/* Deauthentication (reason 3 = STATION LEAVING) */
static int tx_deauth(void) {
    u8 body[2] = { 3, 0 };
    return tx_mgmt_frame(0x00C0, body, 2, wc.tx_rate);
}

#define ASSOC_TRACE_MS 300   /* [W-ASOCTRACE] глубина трассы после TX */

/* [W-ASOCTRACE] активна ли покадровая трасса RX (драйвер читает в
 * owl_rx_poll): 300 мс после каждого TX ASSOC REQ пишем ВСЁ пришедшее
 * (годное/CRC/прочее) — вопрос «точка отвечает, но ответ роняется на
 * PHY» или «точка не отвечает вовсе» решается на уровне кадров, а не
 * оконной статистики (кадры ответа по времени совпадают с TX). */
int wc_assoc_trace_active(u32 *burst)
{
    if (!wc.trace_until) return 0;
    if ((int)(timer_ticks() - wc.trace_until) >= 0) return 0;
    if (burst) *burst = wc.trace_burst;
    return 1;
}

/* [W-ASOCACK] явный статус последнего TX ASSOC REQ. Поле: ACK = точка
 * кадр СЛЫШИТ (FCS честный — MAC-уровень точки подтвердил), и если
 * ответа нет — её MLME молча отбросил СОДЕРЖИМОЕ (IE/капабилити).
 * Без ACK — кадр не долетает (рейт/мощность/канал). Отличать нужно:
 * HomeWifi дал 6 ACK и ноль ответов, esp32 — ACK и ответ с ретраем. */
static int tx_assoc_req_ack(const char *ssid) {
    int r = tx_assoc_req(ssid);
    wc_tx_gap_reset();                 /* [W9-RXLAT2] */
    wifi_log("  TX ASSOC REQ: %s",
             r ? "ACK получен — точка кадр слышит"
               : "БЕЗ ACK — кадр не долетает (рейт/канал/мощность)");
    if (r) {                               /* [W-ASOCTRACE] */
        wc.trace_burst++;
        wc.trace_until = timer_ticks() + ASSOC_TRACE_MS;
    }
    return r;
}

/* ---- IV-заголовки шифрхвостов (СЕССИЯ 51) ----
 * Железо 8192EU ШИФРУЕТ тело (sec_type в дескрипторе), но IV-заголовок
 * в кадр обязан положить драйвер — эталон rtl8xxxu берёт его из mac80211
 * (IEEE80211_KEY_FLAG_GENERATE_IV), сам чип IV не строит. Без IV-хвоста
 * точка видит «Protected»-кадр без CCMP/TKIP-заголовка и молча роняет
 * ЕЩЁ ДО расшифровки — это и убивало DHCP/ARP после рукопожатия.
 * Раскладка байт — дословно из net/mac80211 (wpa.c:ccmp_pn2hdr,
 * tkip.c:ieee80211_tkip_add_iv), PN растёт с 1 (increment-before-use). */

/* CCMP: 8 байт [PN5][PN4][00][0x20|keyid<<6][PN3][PN2][PN1][PN0].
 * СЕССИЯ 52: прежняя раскладка клала PN в LE-порядке ([PN0][PN1]...,
 * [PN2..PN5] в хвосте) — а 802.11/802.11i требует PN СТАРШИМ байтом
 * вперёд (mac80211 ccmp_pn2hdr: hdr[0]=pn[5]... hdr[7]=pn[0], hostapd
 * то же). Для pn<256 точка видела PN=pn*2^40 (монотонно — маскировалось),
 * после 256 кадров PN «прыгал» назад — точка роняла всё как replay. */
static void wpa2_tx_iv_ccmp(u8 *out, u64 pn, int keyid) {
    out[0] = (u8)(pn >> 40);
    out[1] = (u8)(pn >> 32);
    out[2] = 0;
    out[3] = (u8)(0x20 | ((keyid & 3) << 6));
    out[4] = (u8)(pn >> 24);
    out[5] = (u8)(pn >> 16);
    out[6] = (u8)(pn >> 8);
    out[7] = (u8)(pn);
}

/* TKIP: [TSC1][TSC1|0x20 (&0x7f)][TSC0][keyid<<6|EXT][IV32 LE32],
 * iv16 = pn & 0xffff, iv32 = pn >> 16 */
static void wpa2_tx_iv_tkip(u8 *out, u64 pn, int keyid) {
    u16 iv16 = (u16)(pn & 0xFFFFu);
    u32 iv32 = (u32)(pn >> 16);
    out[0] = (u8)(iv16 >> 8);
    out[1] = (u8)(((iv16 >> 8) | 0x20) & 0x7F);
    out[2] = (u8)(iv16 & 0xFF);
    out[3] = (u8)(((keyid & 3) << 6) | 0x20);   /* Ext IV */
    out[4] = (u8)(iv32);
    out[5] = (u8)(iv32 >> 8);
    out[6] = (u8)(iv32 >> 16);
    out[7] = (u8)(iv32 >> 24);
}

/* ---- Ethernet -> 802.11 (TX данных) ----
 * Кадр: data+ToDS, addr1=BSSID addr2=наш MAC addr3=eth.dst, LLC/SNAP. */
int wifi_net_send(const void *eth_frame, u32 len) {
    if (!wc.ops || wc.conn != WIFI_CONN_CONNECTED || !wc.ready)
        return -1;
    if (len < 14 || len > 1518) return -1;
    const u8 *eth = (const u8 *)eth_frame;

    s_lock(&wc.tx_lock);
    static u8 f[WIFI_TXBUF_SZ];
    u32 pos = 0, iv_pos = 0;
    f[0] = 0x08; f[1] = 0x01;                 /* data, ToDS */
    /* WPA2: бит Protected (FC.14) — данные уходят шифрованными;
     * железо строит CCMP/TKIP-заголовок и шифрует по ключу. */
    int fc_protected = (wc.keys_installed != 0);
    if (fc_protected)
        f[1] = 0x01 | 0x40;                   /* ToDS + Protected */
    f[2] = 0x3A; f[3] = 0x00;                 /* duration */
    memcpy(f + 4, wc.conn_bssid, 6);          /* addr1 = BSSID */
    memcpy(f + 10, wc.mac, 6);                /* addr2 = мы */
    memcpy(f + 16, eth, 6);                   /* addr3 = dst MAC */
    put_seq_ctrl(f);                          /* [W-SEQ2] */
    pos = 24;
    /* СЕССИЯ 51→52: IV-заголовок строим САМИ (см. коммент над билдерами).
     * СЕССИЯ 52: ШИФРУЕМ ТОЛЬКО ПАРНЫМ КЛЮЧОМ — по 802.11i (12.5.x)
     * станция в BSS защищает группо-адресованные MSDU к своей точке
     * ПАРНЫМ шифром (точка расшифрует PTK и перезашифрует GTK соседям);
     * mac80211 так и делает (ieee80211_tx_h_select_key берёт sta->ptk
     * для ВСЕХ данных). Прежний broadcast→GTK-TKIP точка не могла даже
     * расшифровать (ждёт CCMP-PTK) — DHCP DISCOVER/ARP молча падали.
     * keyid парного ключа всегда 0 → CAM-ячейка 0. */
    if (fc_protected) {
        u64 pn = ++wc.ptk_pn;
        iv_pos = pos;
        if (wc.ptk_is_tkip) wpa2_tx_iv_tkip(f + pos, pn, 0);
        else                wpa2_tx_iv_ccmp(f + pos, pn, 0);
        pos += 8;
    }
    f[pos++] = 0xAA; f[pos++] = 0xAA; f[pos++] = 0x03;   /* LLC/SNAP */
    f[pos++] = 0x00; f[pos++] = 0x00; f[pos++] = 0x00;
    memcpy(f + pos, eth + 12, len - 12);      /* ethertype + payload */
    pos += len - 12;
    if (fc_protected && wc.ptk_is_tkip && wc.ops->tkip_sw_mic) {
        /* СЕССИЯ 51: Michael MIC — В СОФТЕ (железо 8192EU делает
         * только RC4; эталон rtl8xxxu — GENERATE_MMIC в mac80211).
         * Вход MIC = MSDU (LLC/SNAP+payload, ПОСЛЕ IV), ключ — наш
         * TX-MIC парного ключа (ptk+56; KDE несёт [TK][RX][TX]).
         * В кадре: [IV 8][MSDU][MIC 8], ICV 4 добавит железо.
         * СЕССИЯ 52: TKIP-пара и для broadcast (PTK, см. выше).
         * [W-TKIPSW]: ТОЛЬКО для чипов без железного Michael
         * (tkip_sw_mic=1). У Atheros Michael в keycache (TX-MIC
         * MIC-ячейки) и дописывается PCU — софтовый MIC давал бы
         * ДВОЙНОЙ хвост, а хвост FrameLen уже учёл 12 (см. драйвер). */
        u8 mic8[8];
        wpa2_tkip_michael(wc.ptk + 56, eth, eth + 6, f + iv_pos + 8,
                          pos - iv_pos - 8, mic8);
        memcpy(f + pos, mic8, 8);
        pos += 8;
    }

    /* [W-TXRATE] broadcast/multicast — без ACK; юникаст и бродкаст —
     * низшим базовым рейтом точки (CCK-рейты у точек с b off не слышны) */
    int noack = (eth[0] & 1) != 0;
    wc_rate_t rate = wc.tx_rate;
    int tries = noack ? 3 : 4;
    /* EAPOL сюда не попадает — у него свой путь (wpa2_tx_eapol_eth).
     * СЕССИЯ 52: шифруем всегда парным ключом (см. коммент выше):
     * у Atheros keyidx — номер ячейки keycache (PTK = KC_PTK_ENTRY=4),
     * у Realtek — только признак «шифровать» (алгоритм берётся из
     * ptk_is_tkip, сама ячейка = CAM[0] по keyid из IV). */
    int keyidx = -1;
    if (wc.keys_installed && fc_protected)
        keyidx = 4;
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): замер data-TX; о вырезании
                 * зависшего ожидания сигнализирует [TXWAIT2] в драйвере */
    /* [TXSTALL1] (Task 41): замер длительности data-TX. Поле 27.10: между
     * принятием OFFER и выходом REQUEST в эфир проходило ~500 мс (ESP32
     * видел DISCOVER в 32.422, REQUEST в 32.925) — если узкое место в
     * tx_frame (очередь/PCU), замер покажет в следующем логе. */
    u32 tx_t0 = timer_ticks();
    int r = wc.ops->tx_frame(f, pos, rate, tries, noack, keyidx) ? (int)len : 0;
    u32 tx_dt = timer_ticks() - tx_t0;
    static int g_tx_stall_logged = 0;
    if (tx_dt > 300 && g_tx_stall_logged < 8) {
        g_tx_stall_logged++;
        wifi_log("data-TX занял %u тиков (len=%u) — очередь/PCU?",
                 (unsigned)tx_dt, (unsigned)len);
    }
#else
    int r = wc.ops->tx_frame(f, pos, rate, tries, noack, keyidx) ? (int)len : 0;
#endif
    if (r > 0) {
        wc.data_tx++;
        if (!noack) wc.data_tx_uc++;   /* сессия 53: юникаст-TX */
    }
    s_unlock(&wc.tx_lock);
    return r;
}

/* ---- 802.11 -> Ethernet (RX данных) ----
 * От точки (FromDS): addr1=DA, addr2=BSSID, addr3=SA; после заголовка
 * LLC/SNAP. Складывается в кольцо к net.c (забирает wifi_net_recv).
 * tail_cut — байт шифрхвоста (MIC/ICV), hdr_iv_skip — пропустить
 * CCMP/TKIP-заголовок после 802.11-заголовка.
 * СЕССИЯ 43: разбор A-MSDU (QoS-кадр с битом A-MSDU) — HT-точки
 * агрегируют несколько MSDU в один кадр, без разбора сетевой стек
 * получал бы мусор. */

/* Положить ethernet-кадр в кольцо к net.c (или EAPOL — в рукопожатие).
 * da/sa — MAC адреса, payload — LLC/SNAP (8) + данные. */
static void bridge_push_eth(const u8 da[6], const u8 sa[6],
                            const u8 *payload, u32 payload_len) {
    if (payload_len < 8) return;
    u16 ethertype = (u16)((payload[6] << 8) | payload[7]);
    if (ethertype == 0x888E) {
        /* EAPOL — в обработчик рукопожатия WPA2, не в сетевой стек */
        wpa2_rx_eapol(payload + 6, payload_len - 6);
        return;
    }
    if (wc.conn != WIFI_CONN_CONNECTED) return;   /* мост только после 4-way */
    wc.data_rx++;
    if ((da[0] & 1) == 0) wc.data_rx_uc++;        /* юникаст от точки */
    u32 eth_len = 14 + (payload_len - 8);
    if (eth_len > WIFI_NET_RXSZ) return;
    s_lock(&wc.rx_lock);
    int nxt = (wc.netrx_head + 1) % WIFI_NET_RXQ;
    if (nxt == wc.netrx_tail) {
        /* [RXQ1] (Task 41): кольцо полно — выкидываем САМЫЙ СТАРЫЙ кадр.
         * Раньше терялся именно НОВЫЙ кадр (OFFER/ACK DHCP), а лежалый
         * мусор продолжал занимать кольцо до опроса. */
        wc.netrx_tail = (wc.netrx_tail + 1) % WIFI_NET_RXQ;
    }
    u8 *dst = wc.netrx[wc.netrx_head];
    memcpy(dst, da, 6);
    memcpy(dst + 6, sa, 6);
    memcpy(dst + 12, payload + 6, payload_len - 6);
    wc.netrx_len[wc.netrx_head] = (u16)eth_len;
    wc.netrx_head = nxt;
    s_unlock(&wc.rx_lock);
}

static void bridge_rx_to_net_ex(const u8 *frame, u32 len,
                                u32 hdr_iv_skip, u32 tail_cut) {
    if (len < 30) return;                     /* 24 hdr + LLC 6 + ethertype 2 */
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if ((fc & 0x0C) != 0x08) return;          /* не data */
    if (!(fc & 0x0200)) return;               /* не FromDS */
    u8 subtype = (u8)((fc >> 4) & 0xF);
    u32 hdr = (subtype & 0x8) ? 26 : 24;      /* QoS-data: +2 байта */
    if (fc & 0x8000) hdr += 4;                /* Order: +HTC (11n, редко) */
    if (len < hdr + 8) return;
    if (memcmp(frame + 4, wc.mac, 6) != 0 &&
        (frame[4] & 1) == 0)
        return;                               /* не нам и не mcast */
    u32 plen = len;
    if (hdr_iv_skip) hdr += hdr_iv_skip;      /* CCMP/TKIP-заголовок */
    if (tail_cut && plen > tail_cut) plen -= tail_cut;  /* MIC/ICV в хвосте */
    if (plen < hdr + 8) return;

    /* A-MSDU: у QoS-кадра бит 7 второго байта QoS Control (frame[25]).
     * Поддкадры: DA(6) SA(6) len(2, LE) + MSDU, паддинг до 4 байт. */
    if ((subtype & 0x8) && (frame[25] & 0x80)) {
        u32 p = hdr;
        u32 pushed = 0;
        while (p + 14 <= plen) {
            u32 sl = (u32)frame[p + 12] | ((u32)frame[p + 13] << 8);
            if (sl < 8 || p + 14 + sl > plen) break;   /* мусор/конец */
            bridge_push_eth(frame + p, frame + p + 6, frame + p + 14, sl);
            pushed++;
            p += 14 + sl;
            u32 pad = (4 - (sl & 3)) & 3;    /* паддинг не после последнего */
            if (p + pad < plen) p += pad;
            if (pushed > 32) break;          /* защита от кривого кадра */
        }
        return;
    }

    /* [W-SNAPSCAN]: LLC может лежать не на hdr (паддинг AP после QoS-
     * заголовка — HomeWifi вставляет 2 байта, см. коммент у wc_snap_off);
     * ищем в hdr..hdr+4. Не нашли — кадров без LLC/SNAP касаемся как
     * раньше (отбрасываем в bridge_push_eth по ethertype). */
    u32 snap = wc_snap_off(frame, plen, hdr);
    if (snap == 0)
        return;                               /* не LLC/SNAP */
    bridge_push_eth(frame + 4, frame + 16, frame + snap, plen - snap);
}

/* защищённый кадр: железо расшифровало (после [W9-TKIPTYPE] — в поле
 * подтверждено), но что именно осталось в буфере — РАЗБИРАЕМ ПО
 * СОДЕРЖИМОМУ.
 * [W-TAILOPT] (поле 27.10 №2: assoc/4-way/ключи ок, OFFER виден в
 * «RX prot» с op=2 и НАШИМ xid — но «DHCP не ответил»). Дамп показал
 * decr=0 при ЧИТАЕМОМ plaintext (et/sp/dp/op/xid): LLC на hl+8. Это
 * значит, что PCU Atheros при RX-декрипте TKIP ВЫРЕЗАЛ хвост
 * (MIC+ICV), а 8-байтовый IV ОСТАВИЛ в буфере. Прежняя ветка «IV в
 * буфере» резала 8 спереди (верно) и ФИКСИРОВАННЫЕ 12 с хвоста — с
 * конца IP-датаграммы срезалось 8 байт, и net_handle_packet молча
 * выкидывал кадр (net.c: ip_len > payload_len -> return): OFFER
 * доходил до дампа, но НЕ до netcfg -> «DHCP не ответил» -> стек
 * молчал -> точка отшивала по неактивности (DISASSOC reason=4) ->
 * цикл переподключений («соединение отваливается через время»).
 * Теперь адаптивно всё:
 *  - позиция LLC: hl (декрипт + вырезка всего), hl+2 (паддинг AP —
 *    HomeWifi), hl+8 (IV остался — наш случай), hl+10 (паддинг+IV);
 *  - хвост: по длине ПН-пакета — IPv4 tot_len / EAPOL body_len /
 *    ARP 28 б; всё после конца датаграммы (MIC/ICV/FCS/паддинг)
 *    срезается ТОЧНО. Не определилось (неизвестный ethertype) —
 *    прежний fallback: 12 TKIP / 8 CCMP по направлению кадра
 *    (СЕССИЯ 51: broadcast — GTK, unicast — пара).
 * Если декрипта не было вовсе, LLC не найдётся ни на одной позиции —
 * кадр уходит в _ex со срезом 8 и отбрасывается snap-проверкой
 * (шифртекст не начинается на AA AA). [W-PROTDUMP] теперь печатает
 * llc= и tail= — в поле видно оба среза одним взглядом. */
static void bridge_rx_to_net(const u8 *frame, u32 len) {
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if (fc & 0x4000) {                        /* Protected */
        int mcast = (frame[4] & 1) != 0;
        u32 tail = mcast ? (wc.gtk_is_tkip ? 12 : 8)
                         : (wc.ptk_is_tkip ? 12 : 8);   /* fallback */
        u8  st = (u8)((fc >> 4) & 0xF);
        u32 hl = ((st & 0x8) ? 26u : 24u) + ((fc & 0x8000) ? 4u : 0u);
        if (len >= hl + 8) {
            /* адаптивный поиск LLC в буфере расшифрованного кадра */
            u32 llc = 0;
            if (memcmp(frame + hl, "\xAA\xAA\x03", 3) == 0)
                llc = hl;                           /* декрипт+вырезка */
            else if (hl + 10 <= len &&
                     memcmp(frame + hl + 2, "\xAA\xAA\x03", 3) == 0)
                llc = hl + 2;                       /* паддинг AP */
            else if (memcmp(frame + hl + 8, "\xAA\xAA\x03", 3) == 0)
                llc = hl + 8;                       /* IV остался */
            else if (hl + 18 <= len &&
                     memcmp(frame + hl + 10, "\xAA\xAA\x03", 3) == 0)
                llc = hl + 10;                      /* паддинг + IV */
            if (llc == 0) {
                /* LLC не найдена: декрипта не было (шифртекст) или
                 * нестандартный кадр — прежняя ветка: срез IV спереди,
                 * fallback-хвост; snap-проверка в _ex отбросит. */
                bridge_rx_to_net_ex(frame, len, 8, tail);
                return;
            }
            /* хвост по длине ПН-пакета: конец датаграммы в буфере */
            u16 et = (u16)(((u16)frame[llc + 6] << 8) | frame[llc + 7]);
            u32 end = 0;
            if (et == 0x0800 && llc + 12 <= len) {
                u32 tot = (u32)((frame[llc + 10] << 8) |
                                frame[llc + 11]);
                if (tot >= 20 && llc + 8 + tot <= len)
                    end = llc + 8 + tot;            /* IPv4 tot_len */
            } else if (et == 0x888E && llc + 12 <= len) {
                u32 bl = (u32)((frame[llc + 10] << 8) |
                               frame[llc + 11]);
                if (llc + 12 + bl <= len)
                    end = llc + 12 + bl;            /* EAPOL body */
            } else if (et == 0x0806 && llc + 36 <= len) {
                end = llc + 36;                     /* ARP PDU 28 б */
            }
            if (end > 0 && end <= len) {
                u32 t = len - end;  /* MIC/ICV/FCS/паддинг — остаток */
                if (t <= 60)
                    tail = t;       /* больше — недоверие, fallback */
            }
            /* [W-PROTDUMP] (поле 27.10): первые 24 защищённых кадра
             * после установки ключей — DA, decr (LLC сразу на hl =
             * железо вырезало и IV), llc/tail (срезы), ethertype,
             * UDP-порты и BOOTP op/xid: различит эхо нашего DISCOVER
             * (op=1) от OFFER точки (op=2) одним взглядом. После 24
             * кадров — тишина до переустановки ключей. */
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): дамп защищённых кадров */
            if (wc.prot_dump_left > 0) {
                wc.prot_dump_left--;
                int decr = (llc == hl);
                u16 sp = 0, dp = 0;
                u8  op = 0;
                u32 xid = 0;
                if (et == 0x0800 && llc + 8 + 20 <= len) {
                    const u8 *ip = frame + llc + 8;
                    u32 ihl = (u32)(ip[0] & 0xF) * 4;
                    if (ip[9] == 17 && llc + 8 + ihl + 8 <= len) {
                        const u8 *udp = ip + ihl;
                        sp = (u16)(((u16)udp[0] << 8) | udp[1]);
                        dp = (u16)(((u16)udp[2] << 8) | udp[3]);
                        if (udp + 8 + 8 <= frame + len &&
                            (dp == 67 || dp == 68 ||
                             sp == 67 || sp == 68)) {
                            const u8 *bp = udp + 8;
                            op = bp[0];
                            xid = ((u32)bp[4] << 24) |
                                  ((u32)bp[5] << 16) |
                                  ((u32)bp[6] << 8) | bp[7];
                        }
                    }
                }
                wifi_log("RX prot: DA=%02x:%02x:%02x:%02x:%02x:%02x "
                         "decr=%u llc=%u tail=%u len=%u et=%04x "
                         "sp=%u dp=%u op=%u xid=%08x",
                         frame[4], frame[5], frame[6],
                         frame[7], frame[8], frame[9],
                         (unsigned)decr, (unsigned)llc, (unsigned)tail,
                         (unsigned)len, (unsigned)et,
                         (unsigned)sp, (unsigned)dp, (unsigned)op,
                         (unsigned)xid);
            }
#endif /* WIFI_DEBUG */
            bridge_rx_to_net_ex(frame, len, llc - hl, tail);
        }
    } else {
        bridge_rx_to_net_ex(frame, len, 0, 0);
    }
}

u32 wifi_net_recv(void *buf, u32 max) {
    if (wc.netrx_tail == wc.netrx_head) return 0;
    s_lock(&wc.rx_lock);
    u32 n = wc.netrx_len[wc.netrx_tail];
    if (n > max) n = max;
    memcpy(buf, wc.netrx[wc.netrx_tail], n);
    wc.netrx_tail = (wc.netrx_tail + 1) % WIFI_NET_RXQ;
    s_unlock(&wc.rx_lock);
    return n;
}

void wifi_net_get_mac(u8 out_mac[6]) { memcpy(out_mac, wc.mac, 6); }
int  wifi_net_link(void) { return wc.ops && wc.conn == WIFI_CONN_CONNECTED; }

/* ================= публичный API скана/статуса ================= */

void wifi_scan_start(void) {
    if (!wc.present || !wc.ready || !wc.ops) return;
    if (wc.scanning) return;
    memset(&wc.stats, 0, sizeof(wc.stats));
    /* [SCAN-PASS] (отчёт, баг 9): новый скан — новый счётчик проходов
     * (раньше после первого «прохода 2» wc.pass навсегда оставался 2
     * и повторные сканы теряли право на второй проход при <10 маяках) */
    wc.pass = 1;
    /* [W-HEARDON]: новая гистограмма на новый скан */
    for (int i = 0; i < wc.ap_count; i++)
        memset(wc.aps[i].heard, 0, sizeof(wc.aps[i].heard));
    /* [W-RXLIVE]: бюджет журнала маяков + счётчики переходов */
    g_beacon_log_budget = 12;
    memset(g_chan_trans, 0, sizeof(g_chan_trans));
    /* СЕССИЯ 28: список точек СОХРАНЯЕТСЯ между сканами — он
     * обновляется маяками. Очистка при подключении выглядела как
     * «поиск начался заново» сразу после Enter в поле пароля. */
    wc.scanning = 1;
    wc.scan_channel = 0;
    wifi_log("скан: старт (каналы 1-14, %d мс/канал)", WIFI_SCAN_DWELL);
    if (!wc.ops->set_channel(0))
        wifi_log("скан: смена канала не удалась");
    /* [W-DWELLFIX]: окно прослушивания начинается ПОСЛЕ перестройки —
     * смена канала (fastcc + NF-загрузка) занимает единицы-десятки мс,
     * раньше они вычитались из dwell-окна 110 мс и канал «слушали»
     * лишь остаток: маяки (интервал ~102 мс) терялись на большинстве
     * каналов при полностью исправном радио */
    wc.dwell_start = timer_ticks();
}

int  wifi_present(void)    { return wc.present; }
int  wifi_ready(void)      { return wc.ready; }
const char *wifi_chip_name(void) { return wc.chip_name; }
int  wifi_scan_active(void) { return wc.scanning; }

int wifi_scan_results(wifi_ap_t *out, int max) {
    s_lock(&wc.rx_lock);
    int n = wc.ap_count;
    if (n > max) n = max;
    memcpy(out, wc.aps, (u32)n * sizeof(wifi_ap_t));
    s_unlock(&wc.rx_lock);
    return n;
}

void wifi_get_stats(wifi_stats_t *out) {
    if (!out) return;
    s_lock(&wc.rx_lock);
    wc.stats.channel = wc.scanning ? wc.scan_channel + 1 : 0;
    wc.stats.pass = wc.pass;
    *out = wc.stats;
    s_unlock(&wc.rx_lock);
}

/* ================= WPA2-PSK: рукопожатие и ключи ================= */

/* Генератор для SNonce: xorshift32, засеянный таймером + MAC. */
static void wpa2_rng_seed(void)
{
    wc.rng_state ^= timer_ticks() * 2654435761u;
    for (int i = 0; i < 6; i++)
        wc.rng_state = (wc.rng_state << 8) | wc.mac[i];
    wc.rng_state ^= ((u32)wc.conn_aid << 16) ^ (u32)wc.tx_seq;
    if (!wc.rng_state) wc.rng_state = 0x9E3779B9u;
}

static u32 wpa2_rng_next(void)
{
    u32 x = wc.rng_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    wc.rng_state = x;
    return x;
}

/* PMK для текущего ssid+psk (с кэшем — PBKDF2 4096 итераций). */
static int wpa2_ensure_pmk(void)
{
    if (wc.pmk_valid &&
        strcmp(wc.pmk_ssid, wc.conn_ssid) == 0 &&
        strcmp(wc.pmk_psk, wc.psk) == 0)
        return 1;
    u32 t0 = timer_ticks();
    wpa2_pbkdf2_sha1((const u8 *)wc.psk, (u32)strlen(wc.psk),
                     (const u8 *)wc.conn_ssid, (u32)strlen(wc.conn_ssid),
                     4096, wc.pmk, 32);
    strncpy(wc.pmk_ssid, wc.conn_ssid, sizeof(wc.pmk_ssid) - 1);
    wc.pmk_ssid[sizeof(wc.pmk_ssid) - 1] = 0;
    strncpy(wc.pmk_psk, wc.psk, sizeof(wc.pmk_psk) - 1);
    wc.pmk_psk[sizeof(wc.pmk_psk) - 1] = 0;
    wc.pmk_valid = 1;
    wifi_log("PMK посчитан (%u мс)", (unsigned)(timer_ticks() - t0));
    return 1;
}

static void wpa2_install_keys(void)
{
    if (!wc.ops->keys_install) return;
    /* СЕССИЯ 51: свежие ключи = свежие PN-счётчики (повтор PN после
     * переустановки точка считает replay и роняет кадры). */
    wc.ptk_pn = 0;
    if (wc.ops->keys_install(wc.conn_bssid, wc.ptk, wc.ptk_is_tkip,
                             wc.gtk, wc.gtk_is_tkip, wc.gtk_keyid)) {
        wc.keys_installed = 1;
        wc.prot_dump_left = 64;   /* [W-PROTDUMP]: окно DHCP — печатать
         * ([PROTDUMP3] Task 41: было 24 — бюджет кончался до ACK DHCP,
         * и успех/неуспех доставки ACK было не видно в логе) */
        wifi_log("ключи установлены: PTK(%s) + GTK(keyid=%d%s)",
                 wc.ptk_is_tkip ? "TKIP-64" : "CCMP",
                 wc.gtk_keyid, wc.gtk_is_tkip ? ", TKIP" : "");
    } else {
        wifi_log("ключи НЕ установлены (ошибка железа)");
    }
}

static void wpa2_clear_keys(void)
{
    if (wc.ops && wc.ops->keys_clear) wc.ops->keys_clear();
    wc.keys_installed = 0;
}

/* Отправка EAPOL-кадра точке (ВСЕГДА без шифрования — Protected=0:
 * даже после установки ключей рукопожатие идёт открыто, шифруется
 * только key data). eth = [dst=AP][src=мы][888E]. */
static int wpa2_tx_eapol_eth(const u8 *eth, u32 eth_len)
{
    if (eth_len > 1518) return 0;
    static u8 f[WIFI_TXBUF_SZ];
    u32 pos = 0;
    f[0] = 0x08; f[1] = 0x01;                 /* data, ToDS, НЕ Protected */
    f[2] = 0x3A; f[3] = 0x00;
    memcpy(f + 4, wc.conn_bssid, 6);          /* addr1 = BSSID */
    memcpy(f + 10, wc.mac, 6);                /* addr2 = мы */
    memcpy(f + 16, eth, 6);                   /* addr3 = DA (точка) */
    put_seq_ctrl(f);                          /* [W-SEQ2] */
    pos = 24;
    f[pos++] = 0xAA; f[pos++] = 0xAA; f[pos++] = 0x03;
    f[pos++] = 0x00; f[pos++] = 0x00; f[pos++] = 0x00;
    memcpy(f + pos, eth + 12, eth_len - 12);  /* ethertype + тело */
    pos += eth_len - 12;
    /* [W-TXRATE] EAPOL — критичный путь рукопожатия: шлём низшим базовым
     * рейтом точки (прежде — жёсткий CCK 11M: на точках без b-рейтов
     * M2/M4 не доходили бы вовсе) */
    return wc.ops->tx_frame(f, pos, wc.tx_rate, 4, 0, -1);
}

/* Обработать входящий EAPOL-Key (вызывается из bridge_rx_to_net).
 * eth указывает на LLC-payload: [ethertype 888E][EAPOL...].
 * Робастность (сессия 15): версия 2/3, ретрансмиссия M1, групповой
 * rekey в CONNECTED. */
static void wpa2_rx_eapol(const u8 *eth_payload, u32 len)
{
    if (wc.conn != WIFI_CONN_4WAY && wc.conn != WIFI_CONN_CONNECTED) return;
    /* len = [ethertype 888E 2 б][EAPOL hdr 4 б][Key-дескриптор >= 95 б];
     * раньше сравнивали с 14+4+95+2 (как ПОЛНЫЙ eth-кадр) — минимальный
     * M1 (99 б EAPOL-Key без key data) отбрасывался как «короткий» */
    if (len < 2 + 4 + 95) return;             /* короткий EAPOL-Key */

    /* СЕССИЯ 44: диагностика рукопожатия. eth_payload =
     * [888E 2б][EAPOL hdr 4б][дескриптор]: ver @+2, type @+3,
     * body len @+4, desc type @+6, key info @+7..8. Раньше ВСЕ отказы
     * ниже были тихими — по логу нельзя было понять, где теряется M1. */
    WLOGV("[wpa2] EAPOL: len=%u v%u d%u ki=0x%04x klen=%u kd=%u",
             (unsigned)len, eth_payload[2], eth_payload[6],
             (u16)(((u32)eth_payload[7] << 8) | eth_payload[8]),
             (u16)(((u32)eth_payload[9] << 8) | eth_payload[10]),
             (u16)(((u32)eth_payload[99] << 8) | eth_payload[100]));

    static u8 eb[WIFI_NET_RXSZ];
    if (len + 14 > sizeof(eb)) return;
    memset(eb, 0, 14);
    memcpy(eb + 12, eth_payload, len);        /* 888E + тело */

    eapol_key_t k;
    if (!wpa2_parse_eapol_key(eb, len + 14, &k)) {
        wifi_log("[wpa2] разбор EAPOL-Key не прошёл (body=%u)",
                 (u32)(((u32)eth_payload[4] << 8) | eth_payload[5]));
        return;
    }

    u16 ki = k.key_info;
    u8  kv = (u8)(ki & WPA2_KI_VER_MASK);    /* версия дескриптора */
    /* СЕССИЯ 45: is_wpa = дескриптор 254 — смешанные точки согласуют
     * WPA-протокол; прежняя ветка «только RSN» отбрасывала такое
     * рукопожатие (лог: desc=254, «разбор не прошёл (body=95)») */
    int is_wpa  = (k.desc_type == 254);
    /* ver 2 = AES (CCMP), ver 3 = AES-128-CMAC (PMF-capable точки;
     * AKM тот же PSK-SHA1 — обрабатываем как ver 2), ver 1 = HMAC-MD5
     * (WPA/TKIP) — только для дескриптора 254 */
    int ver_ok = ((ki & WPA2_KI_VER_MASK) == WPA2_KI_VER_AES) ||
                 ((ki & WPA2_KI_VER_MASK) == 3) || (is_wpa && kv == 1);
    int pairwise = (ki & WPA2_KI_KEY_TYPE) != 0;
    int has_mic  = (ki & WPA2_KI_MIC) != 0;
    int has_ack  = (ki & WPA2_KI_ACK) != 0;

    /* ---- ГРУППОВОЙ КЛЮЧ: WPA — после M4 (fw_phase 2); RSN — rekey GTK
     *      в CONNECTED. Сверяно с wpa_supplicant_process_1_of_2_wpa():
     *      GTK = расшифрованный key data целиком, длина в поле
     *      Key Length (WPA); ver1 = RC4(KeyIV||KEK, skip 256),
     *      ver2 = AES-KW. */
    if (!pairwise && has_mic && ver_ok &&
        (wc.fw_phase == 2 ||
         (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed))) {
        static u8 micbuf[WIFI_NET_RXSZ];
        u32 flen = k.frame_len;
        if (flen > sizeof(micbuf)) return;
        memcpy(micbuf, eb, flen);
        memset(micbuf + 95, 0, 16);
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, micbuf, flen, mic);
        if (!wpa2_ct_equal(mic, k.mic, 16)) {
            wifi_log("WPA2: group-M1 MIC неверный — игнор");
            return;
        }
        int rekey = (wc.conn == WIFI_CONN_CONNECTED);
        u8 gtkk[32];
        memset(gtkk, 0, sizeof(gtkk));
        int have_gtk = 0;
        if (is_wpa) {
            u16 gtk_len = k.key_len;
            if (gtk_len != 16 && gtk_len != 32) {
                wifi_log("WPA: групповой ключ длины %u — игнор",
                         (unsigned)gtk_len);
                return;
            }
            static u8 kd[WIFI_NET_RXSZ];
            if (kv == 1) {
                if (k.key_data_len < gtk_len || k.key_data_len > sizeof(kd)) {
                    wifi_log("WPA: group-M1 kd короткий (%u < %u)",
                             (unsigned)k.key_data_len, (unsigned)gtk_len);
                    return;
                }
                memcpy(kd, k.key_data, k.key_data_len);
                u8 ek[32];
                memcpy(ek, k.iv, 16);
                memcpy(ek + 16, wc.ptk + 16, 16);
                wpa2_rc4_skip(ek, 32, 256, kd, k.key_data_len);
                memset(ek, 0, sizeof(ek));
            } else {
                if (k.key_data_len < 16 || (k.key_data_len & 7) ||
                    k.key_data_len > sizeof(kd)) {
                    wifi_log("WPA: group-M1 kd повреждён (len=%u)",
                             (unsigned)k.key_data_len);
                    return;
                }
                if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data,
                                     k.key_data_len, kd)) {
                    wifi_log("WPA: group-M1 unwrap не прошёл");
                    return;
                }
            }
            memcpy(gtkk, kd, gtk_len);
            if (gtk_len > 16) memset(gtkk + gtk_len, 0, 32 - gtk_len);
            wc.gtk_is_tkip = (gtk_len == 32);
            wc.gtk_keyid = (ki & WPA2_KI_KEY_INDEX) >> 4;
            have_gtk = 1;
        } else {
            static u8 kd[WIFI_NET_RXSZ];
            if (k.key_data_len < 16 || (k.key_data_len & 7) ||
                k.key_data_len > sizeof(kd)) {
                wifi_log("WPA2: group-M1 kd повреждён (len=%u)",
                         (unsigned)k.key_data_len);
                return;
            }
            if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data,
                                 k.key_data_len, kd)) {
                wifi_log("WPA2: group-M1 unwrap не прошёл");
                return;
            }
            u32 kdn = k.key_data_len - 8;
            u32 off = 0;
            while (off + 2 <= kdn) {
                u8 t = kd[off], l = kd[off + 1];
                if (t == 0xDD && l >= 8 && off + 2 + 8 <= kdn &&
                    memcmp(kd + off + 2, "\x00\x0F\xAC\x01", 4) == 0) {
                    u8 flags = kd[off + 6];
                    u32 klen = (u32)l - 6;
                    /* СЕССИЯ 51: GTK с off+8 (OUI4+keyid+reserved —
                     * канонический GTK KDE; было off+7 — сдвиг на байт) */
                    if (klen > 32) klen = 32;
                    if (klen < 16) klen = 16;
                    if (off + 2 + 6 + klen <= kdn) {
                        memcpy(gtkk, kd + off + 8, klen);
                        if (klen > 16) memset(gtkk + klen, 0, 32 - klen);
                        wc.gtk_is_tkip = (klen == 32);
                        wc.gtk_keyid = flags & 3;
                        have_gtk = 1;
                    }
                }
                if (t == 0xDD && l == 0) { off += 2; continue; }
                if (l == 0 && t == 0) break;
                off += 2u + l;
            }
            if (!have_gtk) {
                wifi_log("WPA2: GTK KDE не найден в group-M1");
                return;
            }
        }
        memcpy(wc.gtk, gtkk, sizeof(wc.gtk));
        memcpy(wc.replay, k.replay, 8);       /* M2 отвечает счётчиком M1 */
        wpa2_install_keys();
        /* групповой M2: keyidx эхом (биты 4..5), ver, SECURE, MIC */
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        k.desc_type,
                                        (u16)(kv | (ki & WPA2_KI_KEY_INDEX) |
                                              WPA2_KI_MIC | WPA2_KI_SECURE),
                                        k.key_len, NULL, wc.replay, NULL, 0);
        if (k.ver) eb[14] = k.ver;           /* эхо EAPOL-версии точки */
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        wpa2_tx_eapol_eth(eb, n);
        if (!rekey) {
            wc.fw_phase = 0;
            wc.conn = WIFI_CONN_CONNECTED;
            wc.beacon_last = timer_ticks();
            wifi_log("WPA: рукопожатие завершено — \"%s\" доступна (%s)",
                     wc.conn_ssid, is_wpa ? "WPA/PSK" : "WPA2/PSK");
            wifi_profile_save(wc.conn_ssid);
        } else {
            wifi_log("WPA2: групповой ключ обновлён (GTK keyid=%d)",
                     wc.gtk_keyid);
        }
        return;
    }

    /* ---- Сообщение 1: ANonce, без MIC, с ACK ---- */
    if (wc.fw_phase == 0 && pairwise && has_ack && !has_mic && !ver_ok) {
        /* СЕССИЯ 44: ver 1 = TKIP-pairwise (HMAC-MD5/RC4), ver 2/3 = AES.
         * Раньше такой M1 отбрасывался МОЛЧА и выглядел как «нет EAPOL». */
        wifi_log("[wpa2] M1 с версией ключа %u не поддержан "
                 "(1 = пара TKIP, ждали AES)", ki & WPA2_KI_VER_MASK);
        return;
    }
    if ((wc.fw_phase == 0 || wc.conn == WIFI_CONN_CONNECTED) &&
        pairwise && has_ack && !has_mic && ver_ok) {
        wc.fw_desc = (u8)k.desc_type;         /* 2 RSN / 254 WPA */
        wc.fw_ver  = kv;
        wc.m2_apie_sent = 0;
        wc.m2_rsn_tries = 0;
        memcpy(wc.replay_m1, k.replay, 8);
        /* СЕССИЯ 48: ver 1 = TKIP-пара — теперь ПОЛНАЯ поддержка:
         * PTK-64 (KCK+KEK+TK+2 MIC), MIC M2 = HMAC-MD5, железо —
         * 32-байтная CAM-запись. Родной режим старых WPA-точек. */
        wc.ptk_is_tkip = (kv == 1);
        if (wc.ptk_is_tkip)
            wifi_log("WPA: точка выбрала TKIP-пару (ver 1) — PTK-64/HMAC-MD5");
        memcpy(wc.anonce, k.nonce, 32);
        memcpy(wc.replay, k.replay, 8);

        wpa2_rng_seed();
        for (int i = 0; i < 8; i++) {
            u32 r = wpa2_rng_next();
            wc.snonce[i*4+0] = (u8)r; wc.snonce[i*4+1] = (u8)(r >> 8);
            wc.snonce[i*4+2] = (u8)(r >> 16); wc.snonce[i*4+3] = (u8)(r >> 24);
        }
        wpa2_ensure_pmk();
        wpa2_derive_ptk_ex(wc.pmk, wc.conn_bssid, wc.mac,
                           wc.anonce, wc.snonce, wc.ptk,
                           wc.ptk_is_tkip ? 64 : 48);

        /* СЕССИЯ 45 (send_2_of_4): M2 несёт ТОТ IE, по которому
         * согласовано рукопожатие — WPA IE для дескриптора 254,
         * RSN IE для 2. Прежний M2 всегда нёс RSN IE + дескриптор 2:
         * точка WPA отвергала его как чужой (или мы молчали).
         * Key Length: WPA — эхо точки, RSN — 0. MIC по версии. */
        u8 kd[32];
        u16 keylen = (u16)(is_wpa ? k.key_len : 0);
        u32 kdl = is_wpa ? wpa2_build_wpa_ie(kd, wc.ap_group_tkip,
                                             wc.pairwise_tkip)
                         : wpa2_build_rsn_ie(kd, wc.ap_group_tkip,
                                             wc.pairwise_tkip);
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        k.desc_type,
                                        (u16)(kv | WPA2_KI_KEY_TYPE |
                                              WPA2_KI_MIC),
                                        keylen,
                                        wc.snonce, wc.replay, kd, (u16)kdl);
        /* СЕССИЯ 47: эхо EAPOL-версии точки (она шлёт v1, мы v2 —
         * часть точек-Broadcom/Realtek rejects чужую версию) */
        if (k.ver) eb[14] = k.ver;
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);  /* KCK = ptk[0..15] */
        wpa2_eapol_set_mic(eb, mic);
        if (!wpa2_tx_eapol_eth(eb, n)) {
            wifi_log("M2 не отправлен (TX отказ)");
            return;
        }
        wifi_log("TX M2: desc=%u ki=0x%04x klen=%u kd=%u",
                 k.desc_type, (u16)(kv | WPA2_KI_KEY_TYPE | WPA2_KI_MIC),
                 keylen, (unsigned)kdl);
        wc.m2_rsn_tries = 1;
        wc.fw_phase = 1;                     /* ждём M3 */
        wc.fw_timer = timer_ticks();
        wifi_log("WPA2: M1 получен, M2 отправлен (PTK выведен%s)",
                 is_wpa ? ", WPA-протокол" : "");
        return;
    }

    /* ---- РЕТРАНСМИССИЯ M1 (ждём M3, пришёл снова M1) ----
     * СЕССИЯ 51: с 1-й ретрансмиссии RSN-M2 несёт RSN IE ТОЧКИ
     * (захвачен из assoc-resp). Ralink сверяет IE в M2 с СОБСТВЕННЫМ
     * побайтно: наш (1 пара CCMP) != её (2 пары) — все M2 молча
     * ронялись, точка по таймауту уходила в «оптимистичный» M3 и
     * игнорировала M4 (луп M3 → DEAUTH). hostapd такой второй M2
     * роняет по replay — безопасно. */
    if (wc.fw_phase == 1 && wc.conn == WIFI_CONN_4WAY &&
        pairwise && has_ack && !has_mic && ver_ok &&
        memcmp(k.nonce, wc.anonce, 32) == 0) {
        u8 kd[40];
        u16 keylen = (u16)(is_wpa ? k.key_len : 0);
        u32 kdl;
        int apie = 0;
        if (!is_wpa && wc.m2_rsn_tries >= 1 && wc.ap_rsn_ie_len >= 20) {
            memcpy(kd, wc.ap_rsn_ie, wc.ap_rsn_ie_len);
            kdl = wc.ap_rsn_ie_len;
            apie = 1;
        } else if (is_wpa) {
            kdl = wpa2_build_wpa_ie(kd, wc.ap_group_tkip,
                                    wc.pairwise_tkip);
        } else {
            kdl = wpa2_build_rsn_ie(kd, wc.ap_group_tkip,
                                    wc.pairwise_tkip);
        }
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        k.desc_type,
                                        (u16)(kv | WPA2_KI_KEY_TYPE |
                                              WPA2_KI_MIC),
                                        keylen,
                                        wc.snonce, wc.replay, kd, (u16)kdl);
        if (k.ver) eb[14] = k.ver;           /* эхо EAPOL-версии точки */
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        wpa2_tx_eapol_eth(eb, n);
        if (apie && !wc.m2_apie_sent) {
            wc.m2_apie_sent = 1;             /* однократный milestone-лог */
            wifi_log("повтор M2 с RSN IE точки (%u б) — ждём её M3",
                     (unsigned)kdl);
        } else {
            WLOGV("WPA2: повторный M1 — M2 перепослан");
        }
        return;
    }

    /* ---- Сообщение 3: ACK + MIC + pairwise. RSN: key data зашифрован
     *      (ENCR_DATA+SECURE), GTK KDE внутри — ключи сразу; WPA (254):
     *      СЕССИЯ 46 — M3 у WPA-точек БЕЗ бита Secure (лог:
     *      ki=0x01ca = ver|pairwise|install|ack|mic), hostap принимает
     *      M3 по ACK|MIC|pairwise; GTK в M3 НЕ передаётся — M4 и
     *      групповое рукопожатие (как wpa_supplicant_process_3_of_4_wpa). */
    if (wc.fw_phase >= 1 && wc.fw_phase <= 2 && pairwise &&
        (ki & WPA2_KI_ACK) && (ki & WPA2_KI_MIC) && ver_ok &&
        (is_wpa || ((ki & WPA2_KI_SECURE) && (ki & WPA2_KI_ENCR_DATA)))) {
        /* СЕССИЯ 51: БЫСТРЫЙ ПУТЬ — ретранслированный M3 после
         * завершённого рукопожатия (тот же replay + тот же ANonce):
         * тихо отвечаем кэшированным M4, НЕ переустанавливая ключи.
         * Прежний путь на каждый повтор M3 переписывал CAM и сыпал
         * логами; переустановка ещё и сбросила бы PN-счётчики —
         * точка считала бы наши data-кадры replay. Новый 4-way rekey
         * (другой ANonce) сюда не попадает — уйдёт в обычный путь. */
        if (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed &&
            memcmp(k.replay, wc.replay, 8) == 0 &&
            memcmp(k.nonce, wc.anonce, 32) == 0) {
            u32 n4 = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                             k.desc_type,
                                             (u16)(kv | WPA2_KI_KEY_TYPE |
                                                   WPA2_KI_MIC |
                                                   (ki & WPA2_KI_SECURE)),
                                             0, NULL, wc.replay, NULL, 0);
            if (k.ver) eb[14] = k.ver;
            u8 mic4[16];
            wpa2_eapol_mic2(kv, wc.ptk, eb, n4, mic4);
            wpa2_eapol_set_mic(eb, mic4);
            wpa2_tx_eapol_eth(eb, n4);
            WLOGV("M3 повтор после завершения — M4 перепослан");
            return;
        }
        /* СЕССИЯ 44: точка ИНКРЕМЕНТИРУЕТ replay counter между M1 и M3
         * (M1 = R, M3 = R+1). Прежнее точное равенство с M1 отбрасывало
         * КАЖДЫЙ M3 от настоящей точки. Правило: принимаем M3 с счётчиком
         * НЕ СТАРШЕ последнего увиденного, и отвечаем M4 счётчиком M3. */
        if (memcmp(k.replay, wc.replay, 8) < 0) {
            wifi_log("WPA2: M3 со старым replay counter — игнор");
            return;
        }
        memcpy(wc.replay, k.replay, 8);       /* M4 отвечает счётчиком M3 */
        if (memcmp(k.nonce, wc.anonce, 32) != 0) {
            wifi_log("WPA2: ANonce в M3 != M1 — игнор");
            return;
        }
        static u8 micbuf[WIFI_NET_RXSZ];
        u32 flen = k.frame_len;
        if (flen > sizeof(micbuf)) return;
        memcpy(micbuf, eb, flen);
        memset(micbuf + 95, 0, 16);           /* MIC := 0 (смещ. в кадре) */
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, micbuf, flen, mic);
        if (!wpa2_ct_equal(mic, k.mic, 16)) {
            wifi_log("WPA2: MIC M3 неверный — пароль не подходит?");
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "WPA2: неверный MIC (пароль?)");
            wc.conn = WIFI_CONN_FAILED;
            tx_deauth();
            return;
        }

        /* СЕССИЯ 47: некоторые точки доставляют GTK прямо в M3 (KDE
         * 00:50:F2:01 / 00:0F:AC:01) — тогда группового рукопожатия НЕ
         * будет вовсе. Сканируем key data (с расшифровкой при ENCR_DATA);
         * hex-дамп первых 20 байт — чтобы увидеть содержимое (у этой
         * точки kd=28 б: WPA IE или GTK?). */
        int m3_gtk = 0;
        if (is_wpa && k.key_data_len) {
            const u8 *kdp = k.key_data;
            u32 kdn = k.key_data_len;
            static u8 kdd[WIFI_NET_RXSZ];
            if ((ki & WPA2_KI_ENCR_DATA) && k.key_data_len >= 16 &&
                !(k.key_data_len & 7) && k.key_data_len <= sizeof(kdd) &&
                wpa2_aes_unwrap(wc.ptk + 16, k.key_data,
                                k.key_data_len, kdd)) {
                kdp = kdd; kdn = k.key_data_len - 8;
            }
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): hex-дамп key data M3 */
            {   char hx[64]; u32 p = 0;
                for (u32 i = 0; i < kdn && i < 20 && p + 4 < sizeof(hx); i++)
                    p += (u32)snprintf(hx + p, sizeof(hx) - p,
                                       "%02x ", kdp[i]);
                hx[p] = 0;
                wifi_log("[wpa2] M3 kd(%u): %s", (unsigned)kdn, hx);
            }
#endif
            /* СЕССИЯ 49: захват WPA IE ТОЧКИ (element DD, OUI 00:50:F2:01,
             * version=1 после OUI — отличаем от GTK KDE, у него там
             * keyid=0..3). Некоторые точки сверяют IE в M2 с СОБСТВЕННЫМ
             * (а не с assoc-IE как hostapd) — наш IE с одной парой не
             * совпадает с её {TKIP,CCMP} → M2 молча отброшен, M3 шлётся
             * всё равно (PTK из нашего SNonce), а M4 игнорируется — точка
             * всё ещё ждёт валидный M2. */
            u32 apie_off = (u32)-1;
            if (!wc.m2_apie_sent && !wc.ap_wpa_ie_len) {
                u32 off = 0;
                while (off + 2 <= kdn) {
                    u8 t = kdp[off], l = kdp[off + 1];
                    if (t == 0xDD && l >= 24 &&
                        off + 2 + (u32)l <= kdn &&
                        memcmp(kdp + off + 2, "\x00\x50\xF2\x01", 4) == 0 &&
                        kdp[off + 6] == 0x01 && kdp[off + 7] == 0x00 &&
                        kdp[off + 8] == 0x00 &&
                        l + 2u <= (u32)sizeof(wc.ap_wpa_ie)) {
                        wc.ap_wpa_ie[0] = 0xDD;
                        wc.ap_wpa_ie[1] = l;
                        memcpy(wc.ap_wpa_ie + 2, kdp + off + 2, l);
                        wc.ap_wpa_ie_len = (u8)(l + 2);
                        apie_off = off;
                        break;
                    }
                    if (t == 0xDD && l == 0) { off += 2; continue; }
                    if (l == 0 && t == 0) break;
                    off += 2u + l;
                }
            }
            u32 off = 0;
            while (off + 6 <= kdn) {
                if (off == apie_off) {           /* это WPA IE, не GTK KDE */
                    off += 2u + kdp[off + 1];
                    continue;
                }
                u8 t = kdp[off], l = kdp[off + 1];
                if (t == 0xDD && l >= 6 && off + 2 + (u32)l <= kdn &&
                    (memcmp(kdp + off + 2, "\x00\x50\xF2\x01", 4) == 0 ||
                     memcmp(kdp + off + 2, "\x00\x0F\xAC\x01", 4) == 0)) {
                    /* GTK: 2-байтный заголовок (keyid+reserved, как в
                     * hostap); запасной 1-байтный (старый WPA-стиль) */
                    u32 k2 = (u32)l - 6, k1 = (u32)l - 5;
                    u32 klen = 0, hdr = 0;
                    if (k2 == 16 || k2 == 32) { klen = k2; hdr = 2; }
                    else if (k1 == 16 || k1 == 32) { klen = k1; hdr = 1; }
                    if (klen) {
                        memcpy(wc.gtk, kdp + off + 6 + hdr, klen);
                        if (klen > 16) memset(wc.gtk + klen, 0, 32 - klen);
                        wc.gtk_is_tkip = (klen == 32);
                        wc.gtk_keyid = kdp[off + 6] & 3;
                        m3_gtk = 1;
                    }
                }
                if (t == 0xDD && l == 0) { off += 2; continue; }
                if (l == 0 && t == 0) break;
                off += 2u + l;
            }
        }

        if (is_wpa && wc.ap_wpa_ie_len && !wc.m2_apie_sent) {
            /* повторный M2: эхо WPA IE ТОЧКИ (hostapd такой M2 безболезненно
             * роняет по состоянию; точка-одиночка — принимает) */
            u8 kd2[40];
            memcpy(kd2, wc.ap_wpa_ie, wc.ap_wpa_ie_len);
            u32 n2 = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                             k.desc_type,
                                             (u16)(kv | WPA2_KI_KEY_TYPE |
                                                   WPA2_KI_MIC),
                                             k.key_len, wc.snonce,
                                             wc.replay_m1, kd2,
                                             (u16)wc.ap_wpa_ie_len);
            if (k.ver) eb[14] = k.ver;
            u8 mic2b[16];
            wpa2_eapol_mic2(kv, wc.ptk, eb, n2, mic2b);
            wpa2_eapol_set_mic(eb, mic2b);
            wpa2_tx_eapol_eth(eb, n2);
            wc.m2_apie_sent = 1;
            wifi_log("повтор M2 с WPA IE точки (%u б) — ждём её M3",
                     (unsigned)wc.ap_wpa_ie_len);
        }
        if (is_wpa) {
            /* WPA: GTK обычно в групповом M1 — сейчас только M4:
             * Secure-бит эхом из M3, replay = M3 (wc.replay — НЕ k.replay:
             * сборщик очищает eb, куда указывает k.replay!), Key Length
             * = эхо. Ключи ставим после группового M1 (или сразу, если
             * GTK был в M3). */
            u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                            k.desc_type,
                                            (u16)(kv | WPA2_KI_KEY_TYPE |
                                                  WPA2_KI_MIC |
                                                  (ki & WPA2_KI_SECURE)),
                                            k.key_len, NULL, wc.replay,
                                            NULL, 0);
            if (k.ver) eb[14] = k.ver;   /* эхо EAPOL-версии точки */
            wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
            wpa2_eapol_set_mic(eb, mic);
            if (!wpa2_tx_eapol_eth(eb, n)) {
                wifi_log("M4 не отправлен — переповтор");
                return;
            }
            wifi_log("TX M4: desc=%u ki=0x%04x klen=%u",
                     k.desc_type,
                     (u16)(kv | WPA2_KI_KEY_TYPE | WPA2_KI_MIC |
                           (ki & WPA2_KI_SECURE)),
                     k.key_len);
            if (m3_gtk) {
                /* СЕССИЯ 47: GTK пришёл прямо в M3 — группового M1 не
                 * будет: ставим ключи и завершаем */
                wc.fw_phase = 0;
                wpa2_install_keys();
                wc.conn = WIFI_CONN_CONNECTED;
                wc.beacon_last = timer_ticks();
                wifi_log("WPA: рукопожатие завершено (GTK из M3) — \"%s\" доступна",
                         wc.conn_ssid);
                wifi_profile_save(wc.conn_ssid);
            } else {
                wc.fw_phase = 2;             /* ждём групповой M1 */
                wc.fw_timer = timer_ticks();
                wifi_log("WPA: M3 ok, M4 отправлен — ждём групповой ключ (GTK)");
            }
            return;
        }

        u8 kd[WIFI_NET_RXSZ];
        if (k.key_data_len > sizeof(kd) || (k.key_data_len & 7) ||
            k.key_data_len < 16) {
            wifi_log("WPA2: key data повреждён (len=%u)", k.key_data_len);
            return;
        }
        if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data, k.key_data_len, kd)) {
            wifi_log("WPA2: unwrap key data не прошёл");
            return;
        }
        u32 kdn = k.key_data_len - 8;
        int have_gtk = 0;
        u32 off = 0;
        while (off + 2 <= kdn) {
            u8 t = kd[off], l = kd[off + 1];
            if (t == 0xDD && l >= 8 && off + 2 + 8 <= kdn &&
                memcmp(kd + off + 2, "\x00\x0F\xAC\x01", 4) == 0) {
                /* СЕССИЯ 51 (исправление off-by-one): GTK KDE по hostap:
                 * [OUI 4][keyid/tx 1][reserved 1][GTK]. Раньше GTK
                 * копировался с off+7 — на байт СДВИНУТ: ключи
                 * получались мусорные, бродкаст-путь (DHCP!) не работал. */
                u8 flags = kd[off + 6];
                u32 klen = (u32)l - 6;
                if (klen > 32) klen = 32;
                if (klen < 16) klen = 16;
                if (off + 2 + 6 + klen <= kdn) {
                    memcpy(wc.gtk, kd + off + 8, klen);
                    if (klen > 16) memset(wc.gtk + klen, 0, 32 - klen);
                    wc.gtk_is_tkip = (klen == 32);
                    wc.gtk_keyid = flags & 3;
                    have_gtk = 1;
                }
            }
            if (t == 0xDD && l == 0) { off += 2; continue; }   /* паддинг */
            if (l == 0 && t == 0) break;
            off += 2u + l;
        }
        if (!have_gtk) {
            wifi_log("WPA2: GTK KDE не найден в key data");
            return;
        }

        wpa2_install_keys();
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        2,
                                        (u16)(kv | WPA2_KI_KEY_TYPE |
                                              WPA2_KI_MIC | WPA2_KI_SECURE),
                                        0, NULL, wc.replay, NULL, 0);
        if (k.ver) eb[14] = k.ver;           /* эхо EAPOL-версии точки */
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        if (!wpa2_tx_eapol_eth(eb, n)) {
            wifi_log("M4 не отправлен — переповтор");
            return;
        }
        wifi_log("TX M4: desc=2 ki=0x%04x klen=0 kd=0 — ждём data-канал",
                 (u16)(kv | WPA2_KI_KEY_TYPE | WPA2_KI_MIC | WPA2_KI_SECURE));
        wc.conn = WIFI_CONN_CONNECTED;
        /* fw_phase оставляем 1: ретранслированные M3 попадут в
         * быстрый путь (тихий ресенд M4) выше, а новый 4-way rekey
         * примет ветка M1 ниже (она допускает CONNECTED). */
        wc.beacon_last = timer_ticks();
        wc.data_stat_timer = timer_ticks();
        wc.data_tx = 0; wc.data_rx = 0; wc.data_rx_uc = 0;   /* сессия 52 */
        wc.data_tx_uc = 0;                                   /* сессия 53 */
        wifi_log("WPA2: рукопожатие завершено — \"%s\" доступна (CCMP)",
                 wc.conn_ssid);
        wifi_profile_save(wc.conn_ssid);
        return;
    }
}

/* ================= машина подключения ================= */

/* СЕССИЯ 32: ротация BSSID — одноимённый SSID бывает на нескольких
 * точках («byfly WiFi» в логе пользователя — на 6!), и если одна
 * стабильно отказывает — следующая попытка подключения берёт другую. */
static int conn_bssid_tried(const wifi_ap_t *ap) {
    if (wc.tried_n <= 0) return 0;
    if (strcmp(wc.tried_ssid, wc.conn_ssid) != 0) return 0;
    for (int k = 0; k < wc.tried_n && k < 4; k++)
        if (memcmp(wc.tried_bssid[k], ap->bssid, 6) == 0) return 1;
    return 0;
}

static void conn_remember_tried(const wifi_ap_t *ap) {
    if (strcmp(wc.tried_ssid, wc.conn_ssid) != 0) {
        strncpy(wc.tried_ssid, wc.conn_ssid, sizeof(wc.tried_ssid) - 1);
        wc.tried_ssid[sizeof(wc.tried_ssid) - 1] = 0;
        wc.tried_n = 0;
    }
    if (conn_bssid_tried(ap)) return;
    int slot = wc.tried_n < 4 ? wc.tried_n : (wc.tried_n % 4);  /* кольцо */
    memcpy(wc.tried_bssid[slot], ap->bssid, 6);
    wc.tried_n++;
}

/* [W-HEARDCONN] (полевой лог 14: маяки "HomeWifi" (DS ch 1) ловились
 * ТОЛЬКО на dwell ch 2 с -61 dBm; PREAUTH на заявленном ch 1 — 0 маяков
 * в двух окнах по 340 мс; TX с ch 1 не получает ACK. Приёмник чут на
 * других каналах честен (TP-Link_697B сильнее всего именно на своём
 * ch 2) — значит маяки показывают, ГДЕ точка реально передаёт; DS IE
 * у неё врёт (бывает у mesh/репитеров). Подключаемся по ФАКТУ ПРИЁМА:
 * канал с максимумом маяков в гистограмме скана; DS-канал — только
 * фолбэк при равенстве.) Возвращает индекс (0-based) или -1. */
static int ap_best_heard_channel(const wifi_ap_t *a, int exclude) {
    int best = -1;
    u32 best_n = 0;
    for (int ch = 0; ch < WC_NUM_CHANNELS; ch++) {
        if (ch == exclude) continue;
        if (a->heard[ch] > best_n) { best_n = a->heard[ch]; best = ch; }
    }
    return best;
}

/* [W-MACROT] (полевой лог 15: точка ACK-ит наши AUTH и отвечает на probe,
 * но AUTH-ответ не приходит; при этом соседа 68:c4:4d:... она обслуживает;
 * RTL с локальным MAC 02:1a:2b:... прошёл ВЕСЬ путь) — после исчерпания
 * лесенки рейтов меняем НАШ MAC на свежий локально-администрируемый
 * (02:...) и повторяем подключение: у точки мог остаться застрявший
 * сеанс/запись по старому MAC после 15 итераций неудачных рукопожатий. */
static void conn_rotate_mac(void) {
    u8 m[6];
    m[0] = 0x02;                       /* locally administered + unicast */
    u32 s = wc.rng_state ^ (timer_ticks() * 2654435761u);
    for (int i = 1; i < 6; i++) {
        s = s * 1664525u + 1013904223u;
        m[i] = (u8)(s >> 16);
    }
    m[1] |= 0x02; m[1] &= ~0x01u;      /* страховка: unicast */
    memcpy(wc.mac, m, 6);
    wc.rng_state = s;
    if (wc.ops->set_mac) wc.ops->set_mac(wc.mac);
    wifi_log("MAC заменён на %02x:%02x:%02x:%02x:%02x:%02x "
             "— попытка с чистой записью в точке",
             m[0], m[1], m[2], m[3], m[4], m[5]);
}

/* [W-BSSID] BSSID+AID в регистры PCU (AR_BSS_ID0/1 + маска BSSMSK) через
 * ops->set_bssid. Без этого BSS_ID вечно FF:FF:FF:FF:FF:FF (дефолт
 * ath_mac_dma_config) или 0 (ini): PCU не с чем сверять BSSID-матч —
 * юникаст-ответы точки не ACK-ятся (сниффер: ASSOC-RSP только с
 * retry=1; строгий AP после серии неподтверждённых ответов откатывает
 * станцию — «0 из 6 → DEAUTH»), а keycache-поиск ключа RX (KSRCH_MODE)
 * матчит ячейки по BSSID. Хук объявлен в итерации 14, реализован в
 * rtl8192eu, но в ops ath9k отсутствовал и НИ РАЗУ не вызывался. */
static void conn_hw_bssid(u16 aid) {
    if (!wc.ops || !wc.ops->set_bssid) return;
    wc.ops->set_bssid(wc.conn_bssid, aid);
    wifi_log("BSSID в железо: %02x:%02x:%02x:%02x:%02x:%02x aid=%u",
             wc.conn_bssid[0], wc.conn_bssid[1], wc.conn_bssid[2],
             wc.conn_bssid[3], wc.conn_bssid[4], wc.conn_bssid[5],
             (unsigned)aid);
}

static void conn_handle_mgmt(const u8 *frame, u32 len) {
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    u8 type = (u8)((fc >> 2) & 0x3);
    u8 subtype = (u8)((fc >> 4) & 0xF);
    if (type != 0) return;                    /* только management */
    if (len < 26) return;
    /* [W-ASOCDBG] (полевой лог esp32test: точка ассоциировала нас
     * (stations=1; 6× «event id=63» — mesh-событие обработки станции,
     * esp-idf#2916, безвредно), а в парсер не пришло НИ ОДНОГО
     * assoc-resp: в счётчике окон «mgmt» тонули пробы соседей — они
     * считаются, но не печатаются. Считаем ОТДЕЛЬНО: mgmt от нашей
     * BSSID, адресованные НАМ и подтип assoc-resp; последний печатаем
     * ВСЕГДА (без троттлинга) с hex-дампом — следующий полевой лог
     * однозначно скажет, доходят ли ответы точки до драйвера. */
    if (memcmp(frame + 16, wc.conn_bssid, 6) == 0 ||
        memcmp(frame + 10, wc.conn_bssid, 6) == 0) {
        wc.dbg_bss++;
        if (memcmp(frame + 4, wc.mac, 6) == 0) wc.dbg_tome++;
        if (subtype == 1) {                   /* Association Response */
            wc.dbg_asp++;
            u16 st  = (len >= 28) ? (u16)(frame[26] | (frame[27] << 8)) : 0;
            u16 aid = (len >= 30) ? (u16)(frame[28] | (frame[29] << 8)) : 0;
            wifi_log("ASSOC-RSP от точки: len=%u "
                     "DA=%02x:%02x:%02x:%02x:%02x:%02x status=%u aid=%u retry=%u",
                     (unsigned)len, frame[4], frame[5], frame[6],
                     frame[7], frame[8], frame[9],
                     (unsigned)st, (unsigned)(aid & 0x3FFF),
                     (unsigned)((frame[1] >> 3) & 1));
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): hex-дамп ASSOC-RSP */
            char hx[120];                     /* hex-дамп первых 36 байт */
            u32 off = 0, n = (len < 36) ? len : 36;
            for (u32 i = 0; i < n && off + 3 < sizeof(hx); i++) {
                snprintf(hx + off, sizeof(hx) - off, "%s%02x",
                         i ? " " : "", frame[i]);
                off += i ? 3 : 2;
            }
            hx[off] = 0;
            wifi_log("  hex[0..%u]: %s", (unsigned)(n - 1), hx);
#endif
        }
    } else {
        return;
    }

    /* [W-AUTH2] ПРЯМОЙ ответ на НАШ probe запрос: SA = точка, DA = НАШ
     * MAC. Именно этот счётчик отличает «точка нас игнорирует целиком»
     * от «точка отвечает, но AUTH-ответ теряется». */
    if (wc.conn == WIFI_CONN_PROBE && subtype == 5 && len >= 24 &&
        memcmp(frame + 4, wc.mac, 6) == 0) {
        wc.probe_ok++;
        wifi_log("PROBE: ответ точки (len=%u, rssi-кадр принят) — мы слышим друг друга",
                 (unsigned)len);
    }

    if (subtype == 11 && len >= 30) {         /* Authentication */
        if (wc.conn != WIFI_CONN_AUTH) return;
        /* [W-DACHK] (полевой лог 15: в окнах AUTH шли чужие AUTH/ASSOC
         * соседа 68:c4:4d:... с тем же BSSID) — ответ обязан адресоваться
         * НАМ: DA = наш MAC, иначе примем чужой сеанс за свой */
        if (memcmp(frame + 4, wc.mac, 6) != 0) return;
        u16 algo = (u16)(frame[24] | (frame[25] << 8));
        u16 seq  = (u16)(frame[26] | (frame[27] << 8));
        u16 st   = (u16)(frame[28] | (frame[29] << 8));
        if (algo == 0 && seq == 2 && st == 0) {
            /* СЕССИЯ 38: скан обязан молчать с этого момента — радио
             * закреплено на канале точки до конца ассоциации */
            wc.scanning = 0;
            wc.assoc_rate_alt = 0;
            wifi_log("AUTH ok — посылаем ASSOC REQ");
            wc.conn = WIFI_CONN_ASSOC;
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            wc.dbg_bss = wc.dbg_tome = wc.dbg_asp = 0;   /* [W-ASOCDBG] */
            tx_assoc_req_ack(wc.conn_ssid);   /* [W-ASOCACK] */
        } else {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "AUTH отклонён (status=%u)", (unsigned)st);
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
        }
    } else if (subtype == 1 && len >= 30) {   /* Association Response */
        if (wc.conn != WIFI_CONN_ASSOC) return;
        /* [W-DACHK]: DA = наш MAC (см. AUTH выше) */
        if (memcmp(frame + 4, wc.mac, 6) != 0) return;
        u16 st  = (u16)(frame[26] | (frame[27] << 8));
        u16 aid = (u16)(frame[28] | (frame[29] << 8));
        if (st == 0) {
            wc.conn_aid = aid & 0x3FFF;
            wc.beacon_last = timer_ticks();
            /* СЕССИЯ 51: RSN IE точки из assoc-resp — эталон для эха в M2
             * (Ralink сверяет IE в M2 с собственным побайтно). Assoc resp:
                 * cap@24 status@26 AID@28, IEs с 30. */
            {
                u32 ie_off = 30, ie_len = len - 30;
                u32 io = 0;
                wc.ap_rsn_ie_len = 0;
                while (io + 2 <= ie_len) {
                    u8 t = frame[ie_off + io], l = frame[ie_off + io + 1];
                    /* СЕССИЯ 51: копируем ЦЕЛЫЙ элемент (30 18 + тело) —
                     * в key data M2 IE идёт как полный элемент */
                    if (t == 48 && l >= 20 && l <= 38 &&
                        io + 2 + l <= ie_len && 2u + l <= sizeof(wc.ap_rsn_ie)) {
                        memcpy(wc.ap_rsn_ie, frame + ie_off + io, 2u + l);
                        wc.ap_rsn_ie_len = (u8)(2u + l);
                        wifi_log("точка: RSN IE в assoc-resp (%u б) — эхо в M2 готово",
                                 (unsigned)(2u + l));
                        break;
                    }
                    if (l == 0 && t == 0) break;
                    io += 2u + l;
                }
            }
            if (wc.conn_retries > 0) wc.conn_retries--;  /* точка нас приняла — смягчаем счётчик */
            conn_hw_bssid(wc.conn_aid);   /* [W-BSSID] AID в железо */
            /* RX-фильтр: только наша BSS + bcast/mcast + маяки */
            wc.ops->rx_filter_bss();
            if (wc.sec == WIFI_SEC_WPA2_PSK) {
                wc.conn = WIFI_CONN_4WAY;
                wc.fw_phase = 0;
                wc.fw_attempts = 0;
                wc.fourway_data = 0;
                wc.fw_timer = timer_ticks();
                wifi_log("ASSOC ok: \"%s\" AID=%u (ch %d) — WPA2: ждём ключи",
                         wc.conn_ssid, (unsigned)wc.conn_aid,
                         wc.conn_channel + 1);
            } else {
                wc.conn = WIFI_CONN_CONNECTED;
                wifi_log("ASSOC ok: \"%s\" AID=%u (ch %d) — сеть доступна",
                         wc.conn_ssid, (unsigned)wc.conn_aid,
                         wc.conn_channel + 1);
                wifi_profile_save(wc.conn_ssid);
            }
        } else if (st == 18 && !wc.assoc_rate_alt) {
            /* СЕССИЯ 38: status 18 = «STA не поддерживает все
             * BSSBasicRateSet». Объединённый набор уже покрывал рейты
             * точки — вторая попытка с классическим набором b/g
             * (basic 1/2/5.5/11), как у самого обычного клиента. */
            wc.assoc_rate_alt = 1;
            wifi_log("ASSOC отклонён (status=18, рейты) — повтор с полным набором b/g");
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            tx_assoc_req(wc.conn_ssid);
        } else if (st == 18) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "ASSOC отклонён (status=18, рейты/BSS)");
            wifi_log("%s", wc.conn_fail_reason);
            wifi_log("  если точка не принимает: фильтр MAC у точки / 11n-only / PMF");
            wifi_log("  MAC адаптера: %02x:%02x:%02x:%02x:%02x:%02x",
                     wc.mac[0], wc.mac[1], wc.mac[2],
                     wc.mac[3], wc.mac[4], wc.mac[5]);
            wc.conn = WIFI_CONN_FAILED;
        } else if (wc.conn_wpa && wc.assoc_rsn_only &&
                   !wc.assoc_fallback_tried) {
            /* СЕССИЯ 50: точка не взяла RSN-only ассоциацию — повторяем
             * с обоими IE (как раньше) */
            wc.assoc_fallback_tried = 1;
            wc.assoc_variant = 2;
            wc.assoc_rsn_only = 0;
            wc.pairwise_tkip = 0;
            wifi_log("ASSOC отклонён (status=%u) без WPA IE — повтор с обоими IE",
                     (unsigned)st);
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            tx_assoc_req(wc.conn_ssid);
        } else {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "ASSOC отклонён (status=%u)", (unsigned)st);
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
        }
    } else if (subtype == 12 && len >= 26) {  /* Deauthentication */
        if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_ASSOC ||
            wc.conn == WIFI_CONN_AUTH || wc.conn == WIFI_CONN_4WAY ||
            wc.conn == WIFI_CONN_PREAUTH) {   /* [W-AUTHDWELL]: шторм DEAUTH
             * и в окне PREAUTH должен считаться — иначе петля не
             * останавливается по CONN_MAX_DEAUTH */
            u16 reason = (u16)(frame[24] | (frame[25] << 8));
            wc.conn_retries++;
            if (wc.conn_retries > CONN_MAX_DEAUTH) {
                /* СЕССИЯ 32 (анти-шторм): точка стабильно отшивает —
                 * СТОП. Раньше цикл скан→AUTH→DEAUTH крутился вечно,
                 * выжигая CPU на полных сканах и EHCI-поллинге. */
                snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                         "точка отшивает (DEAUTH reason=%u)", (unsigned)reason);
                wifi_log("%s", wc.conn_fail_reason);
                wc.conn = WIFI_CONN_FAILED;
                wc.ops->rx_filter_promisc();
            } else if (wc.conn_retries <= CONN_FAST_RETRIES) {
                /* быстрая переподключалка к ТОЙ ЖЕ точке: канал уже
                 * настроен, полный скан (3 с) не нужен */
                wifi_log("точка послала DEAUTH (reason=%u) — переподключение",
                         (unsigned)reason);
                wc.conn = WIFI_CONN_AUTH;
                wc.conn_attempts = 1;
                wc.conn_timer = timer_ticks();
                tx_auth_req(wc.tx_rate);
            } else {
                /* быстрые попытки кончились — рескан (другая BSSID
                 * того же SSID может принять) */
                wifi_log("точка послала DEAUTH (reason=%u) — рескан",
                         (unsigned)reason);
                wc.ops->rx_filter_promisc();
                wifi_scan_start();
                /* СЕССИЯ 38: conn=SCAN ПОСЛЕ старта скана — иначе в окне
                 * между ними conn_step(SCAN) успеет начать AUTH, и скан
                 * начнёт прыгать по каналам поверх ассоциации */
                wc.conn = WIFI_CONN_SCAN;
                wc.conn_scans = 0;
                wc.conn_attempts = 0;
            }
        }
    } else if (subtype == 10 && len >= 26) {  /* Disassociation */
        if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_ASSOC) {
            wc.conn_retries++;
            if (wc.conn_retries > CONN_MAX_DEAUTH) {
                snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                         "точка отвязывает (DISASSOC)");
                wifi_log("%s", wc.conn_fail_reason);
                wc.conn = WIFI_CONN_FAILED;
                wc.ops->rx_filter_promisc();
            } else {
                wifi_log("DISASSOC от точки — переподключение к той же");
                wc.conn = WIFI_CONN_AUTH;
                wc.conn_attempts = 1;
                wc.conn_timer = timer_ticks();
                tx_auth_req(wc.tx_rate);
            }
        }
    }
}

/* ---- шаг машины подключения (вызывается из wifi_poll) ---- */
static void conn_step(void) {
    switch (wc.conn) {
    case WIFI_CONN_SCAN:
        /* скан завершён? — ищем сеть */
        if (wc.scanning) return;
        {
            /* сильнейшая точка с нужным SSID. Открытая — без пароля;
             * ЗАЩИЩЕННАЯ ЛЮБОГО ТИПА — с паролем (пробуем как WPA2-PSK).
             * СЕССИЯ 32: непробованные BSSID приоритетнее (ротация). */
            int best = -1, best_fresh = -1;
            for (int i = 0; i < wc.ap_count; i++) {
                if (strcmp(wc.aps[i].ssid, wc.conn_ssid) != 0) continue;
                u8 sec = wc.aps[i].sec;
                if (sec == WIFI_SEC_OPEN && wc.psk[0]) continue;
                if (sec != WIFI_SEC_OPEN && !wc.psk[0]) continue;
                if (best < 0 || wc.aps[i].rssi > wc.aps[best].rssi)
                    best = i;
                if (!conn_bssid_tried(&wc.aps[i]) &&
                    (best_fresh < 0 || wc.aps[i].rssi > wc.aps[best_fresh].rssi))
                    best_fresh = i;
            }
            if (best_fresh >= 0) best = best_fresh;
            if (best < 0) {
                int enc = -1;
                for (int i = 0; i < wc.ap_count; i++)
                    if (strcmp(wc.aps[i].ssid, wc.conn_ssid) == 0) { enc = i; break; }
                if (enc >= 0) {
                    const char *why = wc.psk[0]
                        ? "открытая сеть — пароль не нужен"
                        : "нужен пароль (WPA2/WPA)";
                    snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                             "\"%s\": %s", wc.conn_ssid, why);
                    wifi_log("%s", wc.conn_fail_reason);
                    wc.conn = WIFI_CONN_FAILED;
                    return;
                }
                wc.conn_scans++;
                if (wc.conn_scans >= CONN_SCAN_TRIES) {
                    snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                             "сеть \"%s\" не найдена", wc.conn_ssid);
                    wifi_log("%s", wc.conn_fail_reason);
                    wc.conn = WIFI_CONN_FAILED;
                    return;
                }
                wifi_log("скан %d: сети нет — повтор", wc.conn_scans);
                wifi_scan_start();
                return;
            }
            /* нашли: тип защиты точки + настройка канала и BSSID */
            wc.sec = wc.psk[0] ? WIFI_SEC_WPA2_PSK : wc.aps[best].sec;
            wc.ap_group_tkip = wc.aps[best].group_tkip;
            /* СЕССИЯ 43: HT/WPA/PMF профиля точки */
            wc.conn_ht  = wc.aps[best].ht;
            wc.conn_wpa = wc.aps[best].wpa;
            wc.conn_pmf = wc.aps[best].pmf;
            memcpy(wc.conn_bssid, wc.aps[best].bssid, 6);
            wc.conn_channel = wc.aps[best].channel - 1;
            if (wc.conn_channel < 0 || wc.conn_channel >= WC_NUM_CHANNELS)
                wc.conn_channel = 0;
            /* [W-HEARDCONN-2] (полевые логи 15+16: СИММЕТРИЯ КАНАЛОВ
             * У ТОЧКИ НАРУШЕНА — мы СЛЫШИМ её маяки лучше на ch 2, но
             * ОНА слышит наши кадры только на своём DS-канале: лог 15 —
             * на DS ch 1 probe-ответ получен, лог 16 — на ch 2 (маяки
             * в 4 раза громче!) ни один наш кадр не дошёл (probe без
             * ACK). Приём и передача точки сидят на DS-канале; «слышимость
             * маяков» отражает её TX-мощность/фильтры, а не канал её RX.
             * Поэтому подключаемся СТРОГО на DS-канале (это где точка
             * слушает клиентов по стандарту), а heard-канал остаётся
             * ФОЛБЭКОМ PREAUTH — только если на DS полный ноль кадров. */
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): гистограмма маяков точки */
            {
                int alt = ap_best_heard_channel(&wc.aps[best], wc.conn_channel);
                if (alt >= 0 && alt != wc.conn_channel)
                    wifi_log("маяки точки: DS ch %d — %u, ch %d — %u "
                             "(подключаемся на DS: там точка СЛЫШИТ нас)",
                             wc.conn_channel + 1,
                             (unsigned)wc.aps[best].heard[wc.conn_channel],
                             alt + 1, (unsigned)wc.aps[best].heard[alt]);
            }
#endif
            wc.conn_rssi = wc.aps[best].rssi;
            /* СЕССИЯ 32: рейты/capability точки — для ASSOC REQ */
            wc.conn_capab = wc.aps[best].capability;
            wc.conn_rates_len = wc.aps[best].rates_len;
            memcpy(wc.conn_rates, wc.aps[best].rates, wc.conn_rates_len);
            /* СЕССИЯ 38: скан остановлен до AUTH — каналы не перекидываются,
             * радио остаётся на канале точки до конца ассоциации */
            wc.scanning = 0;
            wc.assoc_rate_alt = 0;
            conn_remember_tried(&wc.aps[best]);
            wifi_log("точка найдена: %02x:%02x:%02x:%02x:%02x:%02x ch %d (%d dBm)"
                     " — проверка канала",
                     wc.conn_bssid[0], wc.conn_bssid[1], wc.conn_bssid[2],
                     wc.conn_bssid[3], wc.conn_bssid[4], wc.conn_bssid[5],
                     wc.conn_channel + 1, wc.conn_rssi);
            /* [W-TXRATE]: TX-рейт сессии — низший базовый точки */
            wc.tx_rate = ap_lowest_basic_rate(&wc.aps[best]);
            if (wc.sec == WIFI_SEC_WPA2_PSK)
                wifi_log("точка: группа %s%s%s%s, рейтов %u, TX %s",
                         wc.ap_group_tkip ? "TKIP" : "CCMP",
                         wc.conn_ht  ? ", HT(11n)" : "",
                         wc.conn_wpa ? ", +WPA(смешанный)" : "",
                         wc.conn_pmf ? ", PMF обязателен!" : "",
                         (unsigned)wc.conn_rates_len, wc_rate_name(wc.tx_rate));
            else
                wifi_log("точка: TX-рейт mgmt/данных %s (низший базовый)",
                         wc_rate_name(wc.tx_rate));
            if (!wc.ops->set_channel(wc.conn_channel)) {
                wifi_log("смена канала не удалась — полный init");
                wc.ops->full_reset();
            }
            wc.ops->rx_filter_bss();          /* фильтр на время ассоциации */
            /* [W-AUTHDWELL]: НЕ шлём AUTH сразу. Полевой лог сессии 6:
             * AUTH уходил на канал точки (DS, всё по коду верно), а
             * ACK не было — при этом в сканах dwell на канале точки
             * давал 0 кадров, маяки ловились только на +5 МГц. Пока не
             * понятно, ГЛУХ ЛИ ПРИЁМНИК на настроенной частоте или не
             * слышит точку наш TX — сначала окно прослушивания на канале
             * точки, затем (если глухо) полный bring-up и сравнение. */
            wc.conn = WIFI_CONN_PREAUTH;
            wc.preauth_stage = 0;
            wc.preauth_tries = 0;
            wc.preauth_beacons = 0;
            wc.preauth_frames0 = wc.stats.frames;
            wc.probe_stage = 0;              /* [W-AUTH2] новая сессия подключения */
            wc.conn_timer = timer_ticks();
        }
        break;

    case WIFI_CONN_PREAUTH: {
        /* [W-AUTHDWELL]: слушали канал точки PREAUTH_DWELL_MS — сколько
         * маяков ЦЕЛЕВОЙ точки пришло на её собственном канале.
         * [W-HEARDCONN]: если на выбранном канале глухо, СНАЧАЛА пробуем
         * другой канал из гистограммы маяков (DS у точки может врать,
         * см. полевой лог 14), и лишь потом полный bring-up. */
        if ((int)(timer_ticks() - wc.conn_timer) < PREAUTH_DWELL_MS) return;
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): fr — только для печатей окон */
        u32 fr = wc.stats.frames - wc.preauth_frames0;
#endif
        if (wc.preauth_stage == 0) {
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): окно прослушивания PREAUTH */
            wifi_log("PREAUTH: ch %d, %d мс: маяков точки %u, всего кадров %u — %s",
                     wc.conn_channel + 1, PREAUTH_DWELL_MS,
                     (unsigned)wc.preauth_beacons, (unsigned)fr,
                     wc.preauth_beacons
                        ? "точка слышима на своём канале"
                        : "ГЛУХО на канале точки (маяк ~102 мс)");
#endif
            if (wc.preauth_beacons == 0) {
                /* найдём точку в списке скана по BSSID — гистограмма маяков */
                const wifi_ap_t *ap = (const wifi_ap_t *)0;
                for (int i = 0; i < wc.ap_count; i++)
                    if (memcmp(wc.aps[i].bssid, wc.conn_bssid, 6) == 0) {
                        ap = &wc.aps[i];
                        break;
                    }
                int alt = ap ? ap_best_heard_channel(ap, wc.conn_channel) : -1;
                if (alt >= 0 && ap->heard[alt] > 0) {
                    wifi_log("PREAUTH: пробую ch %d — там маяки ловились в скане (%u раз)",
                             alt + 1, (unsigned)ap->heard[alt]);
                    wc.conn_channel = alt;
                    if (!wc.ops->set_channel(wc.conn_channel)) {
                        wifi_log("смена канала не удалась — полный init");
                        if (wc.ops->full_reset) wc.ops->full_reset();
                    }
                    wc.ops->rx_filter_bss();
                    wc.preauth_stage = 1;
                    wc.preauth_beacons = 0;
                    wc.preauth_frames0 = wc.stats.frames;
                    wc.conn_timer = timer_ticks();
                    return;      /* ещё одно окно — на другом канале */
                }
                if (!wc.preauth_tries) {
                    wc.preauth_tries = 1;
                    wifi_log("PREAUTH: полный bring-up на том же канале — "
                             "сравнение с fastcc");
                    if (wc.ops->full_reset) wc.ops->full_reset();
                    wc.preauth_stage = 2;
                    wc.preauth_beacons = 0;
                    wc.preauth_frames0 = wc.stats.frames;
                    wc.conn_timer = timer_ticks();
                    return;      /* ещё одно окно — уже после bring-up */
                }
            }
        } else {
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): окно PREAUTH альт-канала */
            wifi_log("PREAUTH (этап %d): маяков точки %u, кадров %u — %s",
                     wc.preauth_stage,
                     (unsigned)wc.preauth_beacons, (unsigned)fr,
                     wc.preauth_beacons
                        ? (wc.preauth_stage == 1
                           ? "точка слышна на канале из гистограммы маяков"
                           : "bring-up вернул слух на канале точки")
                        : (wc.preauth_stage == 1
                           ? "и там глухо — остаётся bring-up/тракт RX"
                           : "канал точки по-прежнему глух (тракт RX)"));
#endif
        }
        wc.conn = WIFI_CONN_PROBE;            /* [W-AUTH2] сброс+probe перед AUTH */
        wc.conn_timer = timer_ticks();
        /* [W-BSSID] после всех bring-up/full_reset PREAUTH (они сносят
         * BSS_ID в дефолт) — точка назначена, PCU обязан ACK-ить её
         * юникаст-ответы начиная с PROBE-RSP/AUTH-RSP */
        conn_hw_bssid(0);
        break;
    }

    case WIFI_CONN_PROBE: {
        /* [W-AUTH2]: (1) DEAUTH — сброс возможного зависшего сеанса/бана
         * от прежних итераций (шторм DEAUTH в сессии 5-9 мог оставить
         * точку в состоянии «клиент уже есть»); (2) ПРЯМОЙ probe request
         * — как у wpa_supplicant. Ответ (кастомный, addr1 = НАШ MAC)
         * считаем в conn_handle_mgmt. Через 250 мс — вердикт и AUTH.
         * Раньше: пассивный скан -> сразу AUTH; точка, отвечающая на
         * пробы чужим станциям (probe resp в логе идут), наш AUTH
         * молча игнорировала при честном ACK. */
        if (wc.probe_stage == 0) {
            wc.probe_stage = 1;
            wc.probe_ok = 0;
            wc.probe_sent = 0;
            wifi_log("PROBE: DEAUTH-сброс сеанса + направленный запрос к точке");
            tx_deauth();                       /* сброс stale-состояния точки */
            wc.probe_sent = tx_probe_req(wc.conn_ssid, wc.tx_rate) ? 1 : 0;
            wc.conn_timer = timer_ticks();
            break;
        }
        /* [W-AUTH2B] +120 мс: ВТОРОЙ probe — ШИРОКОВЕЩАТЕЛЬНЫЙ (без SSID):
         * часть точек молчит на directed probe от «неизвестного» MAC,
         * но отвечает на wildcard. Ответ считаем тот же счётчик. */
        if (wc.probe_stage == 1 &&
            (int)(timer_ticks() - wc.conn_timer) >= 120) {
            wc.probe_stage = 2;
            tx_probe_req("", wc.tx_rate);
        }
        if ((int)(timer_ticks() - wc.conn_timer) < 250) break;
        wifi_log("PROBE: %s (ответов %u) — %s",
                 wc.probe_sent ? "запрос отправлен" : "запрос НЕ отправлен (TX отказ)",
                 (unsigned)wc.probe_ok,
                 wc.probe_ok ? "точка ОТВЕЧАЕТ нам — AUTH обязан пройти"
                             : "точка НЕ отвечает и на probe: фильтр MAC / бан / глухота к нашим кадрам");
        wc.conn = WIFI_CONN_AUTH;
        wc.conn_attempts = 1;
        wc.conn_timer = timer_ticks();
        wc.aw_f0    = wc.stats.frames;       /* [W-AUTHWINDIAG] */
        wc.aw_crc0  = wc.stats.crc_err;
        wc.aw_oth0  = wc.stats.other;
        wc.aw_mgmt0 = wc.stats.mgmt;
        wc.aw_bcn0  = wc.stats.beacons;
        wc.dbg_bss = wc.dbg_tome = wc.dbg_asp = 0;   /* [W-ASOCDBG] */
        if (!tx_auth_req(wc.tx_rate)) {
            wifi_log("AUTH не отправлен (TX отказ)");
            wc.conn = WIFI_CONN_FAILED;
        }
        break;
    }

    case WIFI_CONN_AUTH:
    case WIFI_CONN_ASSOC:
        if ((int)(timer_ticks() - wc.conn_timer) < CONN_AUTH_TO) return;
        /* [W-AUTHWINDIAG]: что пришло за окно попытки — кадров всего,
         * mgmt, CRC-ошибок. Если mgmt=0 и CRC>0 — эфир шумит/PHY роняет
         * кадры (возможно, сразу после нашего TX); mgmt=0 и кадров=0 —
         * точка молчит; mgmt>0 — ответ шёл, но не распознан (см.
         * «RX mgmt: ...» драйвера с DA/SA/BSSID). */
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): оконная статистика попыток */
        wifi_log("%s: окно %u мс: кадров %u (маяков %u, mgmt %u, CRC %u, прочих %u, "
                 "от BSSID %u, нам %u, assoc-rsp %u) — %s",
                 wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC",
                 (unsigned)CONN_AUTH_TO,
                 (unsigned)(wc.stats.frames - wc.aw_f0),
                 (unsigned)(wc.stats.beacons - wc.aw_bcn0),
                 (unsigned)(wc.stats.mgmt - wc.aw_mgmt0),
                 (unsigned)(wc.stats.crc_err - wc.aw_crc0),
                 (unsigned)(wc.stats.other - wc.aw_oth0),
                 (unsigned)wc.dbg_bss,                /* [W-ASOCDBG] */
                 (unsigned)wc.dbg_tome,
                 (unsigned)wc.dbg_asp,
                 wc.dbg_asp ? "assoc-rsp ДОХОДИЛ — разбор выше"
                 : (wc.dbg_bss ? "mgmt от точки были, assoc-rsp НЕТ"
                 : ((wc.stats.mgmt != wc.aw_mgmt0)
                    ? "mgmt только чужие (пробы соседей)"
                    : ((wc.stats.beacons != wc.aw_bcn0)
                       ? "маяки шли, НЕ-маяков mgmt НЕТ — ответа не было"
                       : ((wc.stats.frames != wc.aw_f0 ||
                           wc.stats.crc_err != wc.aw_crc0)
                          ? "mgmt НЕТ: эфир шумит / кадр роняется"
                          : "эфир пуст")))));
#endif /* WIFI_DEBUG */
        if (wc.conn_attempts >= CONN_MAX_ATTEMPTS) {
            /* [W-MACROT]/[W-MACROT2]: одна ротация MAC за подключение —
             * точка могла застрять на старом MAC (ACK есть — ответа нет;
             * esp32test: AP держала нас за станцию прошлой Windows-сессии
             * с тем же MAC — ассоц-реквесты дропались молча) — теперь и
             * при AUTH-, и при ASSOC-таймаутах */
            if ((wc.conn == WIFI_CONN_AUTH || wc.conn == WIFI_CONN_ASSOC) &&
                !wc.mac_rotated) {
                wc.mac_rotated = 1;
                wifi_log("%s: нет ответа за %d попыток — меняю MAC и повторяю",
                         wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC",
                         CONN_MAX_ATTEMPTS);
                conn_rotate_mac();
                wc.conn = WIFI_CONN_PREAUTH;
                wc.preauth_stage = 0;
                wc.preauth_tries = 0;
                wc.preauth_beacons = 0;
                wc.preauth_frames0 = wc.stats.frames;
                wc.probe_stage = 0;
                wc.conn_attempts = 0;
                wc.conn_timer = timer_ticks();
                return;
            }
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "%s: нет ответа точки",
                     wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC");
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
            return;
        }
        wc.conn_attempts++;
        wc.conn_timer = timer_ticks();
        if (wc.conn == WIFI_CONN_AUTH) {
            /* [W-TXRATE] чередуем рейт по попыткам: 2-я — OFDM 6 Мбит/с
             * (точки с b-рейтами off CCK не слышат), 3-я — CCK 1 Мбит/с
             * (страховка от глухоты к 6M). Попытка 1 уже ушла на базовом
             * рейте точки. */
            /* [W-RATELADDER] (полевой лог 13: RTL подключается, TX у
             * него mgmt на 11M; наш AR9285: 1M «ACK», 6M - ретраи).
             * Лесенка базовых CCK/OFDM: 1M -> 11M -> 2M -> 5.5M -> 6M. */
            static const wc_rate_t ladder[5] = {
                WCRATE_1M, WCRATE_11M, WCRATE_2M, WCRATE_5_5M, WCRATE_6M
            };
            int li = wc.conn_attempts - 1;
            if (li < 0) li = 0;
            if (li > 4) li = 4;
            wc_rate_t r = ladder[li];
            wifi_log("таймаут — повтор %d (AUTH, рейт %s)",
                     wc.conn_attempts, wc_rate_name(r));
            wc.aw_f0    = wc.stats.frames;   /* [W-AUTHWINDIAG] */
            wc.aw_crc0  = wc.stats.crc_err;
            wc.aw_oth0  = wc.stats.other;
            wc.aw_mgmt0 = wc.stats.mgmt;
            wc.dbg_bss = wc.dbg_tome = wc.dbg_asp = 0;   /* [W-ASOCDBG] */
            tx_auth_req(r);
        } else {
            wifi_log("таймаут — повтор %d (ASSOC)", wc.conn_attempts);
            wc.aw_f0    = wc.stats.frames;
            wc.aw_crc0  = wc.stats.crc_err;
            wc.aw_oth0  = wc.stats.other;
            wc.aw_mgmt0 = wc.stats.mgmt;
            wc.dbg_bss = wc.dbg_tome = wc.dbg_asp = 0;   /* [W-ASOCDBG] */
            tx_assoc_req_ack(wc.conn_ssid);   /* [W-ASOCACK] */
        }
        break;

    case WIFI_CONN_4WAY:
        if ((int)(timer_ticks() - wc.fw_timer) < CONN_4WAY_TO) return;
        wc.fw_attempts++;
        if (wc.fw_attempts >= CONN_MAX_4WAY) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "WPA2: рукопожатие не завершено");
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
            return;
        }
        int was_phase = wc.fw_phase;
        wc.fw_phase = 0;
        wc.fw_timer = timer_ticks();
        /* СЕССИЯ 48: чередуем pairwise в WPA IE — у старых WPA-точек
         * путь «WPA+CCMP-пара» бывает непроверен, TKIP-пара — родной */
        wc.assoc_variant = (u8)((wc.assoc_variant + 1) & 3);
        wc.pairwise_tkip   = (int)(wc.assoc_variant & 1);
        wc.assoc_rsn_only  = (int)(wc.assoc_variant < 2);
        wifi_log("следующая попытка: assoc %s, пара %s",
                 wc.assoc_rsn_only ? "RSN-only" : "RSN+WPA",
                 wc.pairwise_tkip ? "TKIP" : "CCMP");
#if WIFI_DEBUG /* [WIFI-DBG-GATE] (Task 43): сводка счётчиков RX */
        wifi_log("RX-статистика: кадров=%u crc=%u прочих=%u",
                 (unsigned)wc.stats.frames, (unsigned)wc.stats.crc_err,
                 (unsigned)wc.stats.other);
#endif
        /* СЕССИЯ 44: счётчик data-кадров за окно 4WAY отличает «эфир глухой,
         * M1 не доходил» (0) от «кадры идут, но EAPOL нет/отвергнут» (>0) */
        if (was_phase == 2)
            wifi_log("WPA: групповой ключ не пришёл (data от точки: %u) — "
                     "повтор ассоциации (%d)",
                     (unsigned)wc.fourway_data, wc.fw_attempts);
        else
            wifi_log("WPA2: нет сообщений EAPOL (data от точки: %u) — "
                     "повтор ассоциации (%d)",
                     (unsigned)wc.fourway_data, wc.fw_attempts);
        wc.conn = WIFI_CONN_ASSOC;
        wc.conn_attempts = 1;
        wc.conn_timer = timer_ticks();
        tx_assoc_req_ack(wc.conn_ssid);       /* [W-ASOCACK] */
        break;

    case WIFI_CONN_CONNECTED:
        /* Сессия 53: диагностика data-канала раз в 10 с, только при
         * РЕАЛЬНОЙ проблеме. Старый критерий (RXuc==0 при RX>0 или
         * data_tx==0) срабатывал ложно: во время DHCP весь трафик
         * бродкастный — юникаста легитимно нет; в простой сети точка
         * тоже не обязана слать data-кадры. Проблема — только когда
         * мы сами отправляли ЮНИКАСТ (TCP SYN и т.п.), а назад не
         * пришло ни одного юникаста: точка не приняла наш кадр
         * (ключ/порт) — классика «M4 не принят». */
        if (wc.data_stat_timer &&
            (u32)(timer_ticks() - wc.data_stat_timer) > 10000) {
            wc.data_stat_timer = timer_ticks();
            if (wc.data_tx_uc > 0 && wc.data_rx_uc == 0)
                wifi_log("data-канал: TX=%u (unicast %u) RX=%u RXuc=%u — "
                         "наши юникасты не возвращаются",
                         (unsigned)wc.data_tx, (unsigned)wc.data_tx_uc,
                         (unsigned)wc.data_rx, (unsigned)wc.data_rx_uc);
        }
        /* контроль потери связи: нет маяков давно → рескан */
        if ((int)(timer_ticks() - wc.beacon_last) < CONN_BEACON_LOST) return;
        wifi_log("маяки пропали >6 с — переподключение к \"%s\"", wc.conn_ssid);
        wc.ops->rx_filter_promisc();
        wifi_scan_start();
        /* СЕССИЯ 38: conn=SCAN ПОСЛЕ старта скана (гонка скан↔AUTH) */
        wc.conn = WIFI_CONN_SCAN;
        wc.conn_scans = 0;
        wc.conn_attempts = 0;
        break;

    default:
        break;
    }
}

/* ================= публичный API подключения ================= */

int wifi_connect_psk(const char *ssid, const char *psk) {
    if (!wc.present || !wc.ready || !wc.ops) return 0;
    if (!ssid || !ssid[0]) return 0;
    u32 L = (u32)strlen(ssid);
    if (L > 32) return 0;

    if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_AUTH ||
        wc.conn == WIFI_CONN_ASSOC || wc.conn == WIFI_CONN_4WAY)
        wifi_disconnect();

    strncpy(wc.conn_ssid, ssid, 32);
    wc.conn_ssid[32] = 0;
    wc.mac_rotated = 0;         /* [W-MACROT]: новая попытка — новая ротация */
    wc.sec = 0;                 /* уточним по маяку при скане */
    wc.psk[0] = 0;
    if (psk && psk[0]) {
        if (strlen(psk) < 8) {
            wifi_log("WPA2: пароль короче 8 символов");
            return 0;
        }
        strncpy(wc.psk, psk, sizeof(wc.psk) - 1);
        wc.psk[sizeof(wc.psk) - 1] = 0;
        wc.sec = WIFI_SEC_WPA2_PSK;   /* попытаемся как WPA2 */
    }
    wc.conn_scans = 0;
    wc.conn_attempts = 0;
    wc.conn_fail_reason[0] = 0;
    wc.conn_retries = 0;      /* сессия подключения новая — счётчик DEAUTH с нуля */
    wc.pairwise_tkip = 0;     /* новая сессия — начинаем с CCMP-пары */
    wc.assoc_variant = 0;     /* и с RSN-only ассоциации (СЕССИЯ 50) */
    wc.assoc_rsn_only = 1;
    wc.assoc_rate_alt = 0;
    wc.netrx_head = wc.netrx_tail = 0;
    /* СЕССИЯ 32: свежий скан (< 15 с) уже видел эту сеть — НЕ гоняем
     * полный скан (~1.5 с при dwell 110 мс) на каждую попытку подключения:
     * клик по сети из списка должен сразу AUTH-ить по готовым данным. */
    int have_cached = 0;
    if (!wc.scanning && wc.ap_count > 0 && wc.last_scan_end != 0 &&
        (u32)(timer_ticks() - wc.last_scan_end) < 15000) {
        for (int i = 0; i < wc.ap_count; i++) {
            if (strcmp(wc.aps[i].ssid, wc.conn_ssid) != 0) continue;
            u8 s = wc.aps[i].sec;
            if (s == WIFI_SEC_OPEN && wc.psk[0]) continue;
            if (s != WIFI_SEC_OPEN && !wc.psk[0]) continue;
            have_cached = 1;
            break;
        }
    }
    /* СЕССИЯ 38 (гонка скан↔подключение): conn=SCAN ставится ПОСЛЕДНИМ.
     * Раньше между «conn=SCAN» и «wifi_scan_start()» планировщик мог
     * переключиться на wifi_poll: conn_step(SCAN) при scanning==0
     * немедленно выбирал точку и посылал AUTH — а затем стартовал скан,
     * который ПЕРЕСКАКИВАЛ каналы 1-14 поверх ассоциации. Радио оказывалось
     * на чужом канале: ответы точки не слышны («AUTH ok» наудачу →
     * «ASSOC: нет ответа точки»). */
    if (have_cached) {
        wifi_log("подключение к \"%s\"%s: сеть в свежем скане — AUTH сразу",
                 wc.conn_ssid, wc.psk[0] ? " (WPA2)" : "");
        /* scanning=0 — conn_step(SCAN) сам выберет точку и отправит AUTH */
        wc.conn = WIFI_CONN_SCAN;
        return 1;
    }
    wifi_log("подключение к \"%s\"%s: скан...", wc.conn_ssid,
             wc.psk[0] ? " (WPA2)" : "");
    if (!wc.scanning)
        wifi_scan_start();
    else
        wc.conn_scans = 1;      /* скан уже идёт — учтём текущий проход */
    wc.conn = WIFI_CONN_SCAN;
    return 1;
}

int wifi_connect(const char *ssid) {
    /* если в профиле есть пароль — подключаемся с ним */
    char psk[65];
    if (wifi_profile_load_psk(psk, sizeof(psk)))
        return wifi_connect_psk(ssid, psk);
    return wifi_connect_psk(ssid, NULL);
}

int wifi_conn_secured(void)
{
    return (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed) ? 1 : 0;
}

void wifi_disconnect(void) {
    if (!wc.ops) return;
    if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_4WAY)
        tx_deauth();
    if (wc.conn != WIFI_CONN_OFF) {
        wc.conn = WIFI_CONN_OFF;
        wc.conn_ssid[0] = 0;
        wpa2_clear_keys();          /* ключи железа больше не валидны */
        {   /* [W-BSSID] железо забывает точку (скан-дефолт FF:FF.., aid=0):
             * иначе PCU продолжит ACK/BSS-матч по старому BSSID */
            const u8 none[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
            if (wc.ops->set_bssid) wc.ops->set_bssid(none, 0);
        }
        wc.ops->rx_filter_promisc();
        wifi_log("отключено");
    }
}

wifi_conn_state_t wifi_conn_state(void) { return wc.conn; }
const char *wifi_conn_ssid(void) { return wc.conn_ssid; }
int  wifi_conn_rssi(void)   { return wc.conn_rssi; }
int  wifi_conn_channel(void) { return wc.conn_channel + 1; }

const char *wifi_conn_state_name(void) {
    switch (wc.conn) {
        case WIFI_CONN_OFF:       return "не подключаемся";
        case WIFI_CONN_SCAN:      return "поиск сети";
        case WIFI_CONN_PREAUTH:   return "проверка канала";
        case WIFI_CONN_PROBE:     return "probe-тест точки";
        case WIFI_CONN_AUTH:      return "аутентификация";
        case WIFI_CONN_ASSOC:     return "ассоциация";
        case WIFI_CONN_4WAY:      return "WPA2-рукопожатие";
        case WIFI_CONN_CONNECTED: return "подключено";
        case WIFI_CONN_FAILED:    return "не удалось";
    }
    return "?";
}

/* ================= опрос из главного цикла ================= */

void wifi_poll(void) {
    if (!wc.present || !wc.ready || !wc.ops) return;

    wc.ops->poll_rx();

    /* машина подключения (после опроса RX — ответы уже разобраны) */
    conn_step();

    if (!wc.scanning) return;
    /* СЕССИЯ 38: во время ассоциации каналы не перекидывать — AUTH/
     * ASSOC/4WAY идут на ЗАКРЕПЛЁННОМ канале точки; прыжок канала
     * делает нас глухими и немыми для неё. PREAUTH — тот же случай */
    if (wc.conn == WIFI_CONN_PREAUTH || wc.conn == WIFI_CONN_AUTH ||
        wc.conn == WIFI_CONN_ASSOC || wc.conn == WIFI_CONN_4WAY) {
        wc.scanning = 0;
        return;
    }

    u32 now = timer_ticks();
    if ((int)(now - wc.dwell_start) < WIFI_SCAN_DWELL) return;   /* ещё слушаем */

    int idx = wc.scan_channel;
    wifi_log("ch %d (%u МГц): кадров %u (в переходе %u), маяков %u, CRC %u, сетей %d",
             idx + 1, (unsigned)wc_channel_freq[idx],
             (unsigned)wc.stats.chan_frames[idx],
             (unsigned)g_chan_trans[idx],
             (unsigned)wc.stats.chan_beacons[idx],
             (unsigned)wc.stats.chan_crc[idx], wc.ap_count);

    if (idx + 1 >= WC_NUM_CHANNELS) {
        /* скан завершён */
        wc.scanning = 0;
        wc.last_scan_end = timer_ticks();   /* для кэша при подключении */
        /* [ATH-SCAN2] повторный проход при МАЛОМ числе маяков (<10):
         * на загруженном эфире маяк периодически сдвигается за край
         * окна 110 мс — сеть пропускается. Прежде pass-2 запускался
         * только при НУЛЕ кадров (AR9485, опорник 25 МГц). */
        if (wc.pass == 1 && wc.stats.beacons < 10 && wc.ops->scan_retry &&
            wc.ops->scan_retry(wc.stats.frames)) {
            wc.pass = 2;
            wifi_log("маяков %u (<10) — второй проход скана",
                     (unsigned)wc.stats.beacons);
            memset(&wc.stats, 0, sizeof(wc.stats));
            memset(g_chan_trans, 0, sizeof(g_chan_trans));
            wc.scanning = 1;
            wc.scan_channel = 0;
            if (!wc.ops->set_channel(0)) {
                wc.scanning = 0;
                wc.pass = 1;
            }
            /* [W-RXLIVE]: кадры в окне этой перестройки — уже в
             * chan_frames[0] (stats только что обнулены) */
            g_chan_trans[0] = wc.stats.chan_frames[0];
            wc.dwell_start = timer_ticks();   /* [W-DWELLFIX] */
            return;
        }
        /* [SCAN-PASS] (отчёт, баг 9): проход завершён — вернуть право
         * на повторный проход следующему скану */
        wc.pass = 1;
        wifi_log("скан завершён: %d сетей, %u кадров, %u CRC, %u прочих",
                 wc.ap_count, (unsigned)wc.stats.frames,
                 (unsigned)wc.stats.crc_err, (unsigned)wc.stats.other);
        /* [W-HEARDON]: на каких dwell-каналах слышны маяки каждой точки.
         * Здоровый приёмник: маяки только на dwell = DS-каналу точки.
         * «Только на соседнем» или «ноль на своём» — симптом для лога. */
        for (int i = 0; i < wc.ap_count; i++) {
            wifi_ap_t *a = &wc.aps[i];
            int any = 0, own = 0;
            for (int ch = 0; ch < WC_NUM_CHANNELS; ch++)
                if (a->heard[ch]) { any = 1; if (ch + 1 == a->channel) own = 1; }
            if (!any) continue;
            char b[160];
            int n = snprintf(b, sizeof(b),
                             "маяки \"%s\" (DS ch %d): dwell",
                             a->ssid, a->channel);
            for (int ch = 0; ch < WC_NUM_CHANNELS && n < (int)sizeof(b) - 16; ch++)
                if (a->heard[ch])
                    n += snprintf(b + n, (u32)sizeof(b) - (u32)n,
                                  " %d:%u", ch + 1, (unsigned)a->heard[ch]);
            if (!own)
                n += snprintf(b + n, (u32)sizeof(b) - (u32)n,
                              " — НА СВОЁМ КАНАЛЕ НОЛЬ");
            wifi_log("%s", b);
        }
        return;
    }

    wc.scan_channel = idx + 1;
    {
        /* [W-RXLIVE]: сколько кадров пришло, ПОКА шла перестройка на
         * этот канал (счёт уже на нём, радио ещё на прошлом) */
        u32 snap = wc.stats.chan_frames[idx + 1];
        if (!wc.ops->set_channel(wc.scan_channel)) {
            wc.scanning = 0;
            wifi_log("скан прерван: смена канала не удалась");
            return;
        }
        g_chan_trans[idx + 1] = wc.stats.chan_frames[idx + 1] - snap;
    }
    wc.dwell_start = timer_ticks();   /* [W-DWELLFIX]: слушаем после */
}

/* ================= bind + init (диспетчер драйверов) ================= */

void wifi_core_bind(const wifi_hw_ops_t *ops) {
    wc.ops = ops;
}

void wifi_init(void) {
    memset(&wc, 0, sizeof(wc));
    wc.scan_channel = -1;
    wc.pass = 1;
    /* запасной MAC до чтения EEPROM/efuse: локально-администрируемый */
    wc.mac[0] = 0x02; wc.mac[1] = 0x1A; wc.mac[2] = 0x2B;

    wifi_log("wifi: поиск адаптеров (Atheros PCI, Realtek RTL8192EU USB)...");

    /* СЕССИЯ 37: диагностика фазы probe — раньше после «поиск Atheros»
     * в serial-логе могла быть тишина на минуты (BG-крошки), и по логу
     * было не понять: задача жива? скан идёт? донгл зааттачен? */
    {
        u32 t0 = timer_ticks();
        if (ath9k_wifi_probe())
            goto found;
        wifi_log("wifi: скан PCI занял %u мс, Atheros не найден — пробую RTL8192EU (USB attach=%d)",
                 (unsigned)(timer_ticks() - t0), rtl8192eu_attached() ? 1 : 0);
    }
    if (rtl8192eu_probe())
        goto found;

    wifi_log("адаптер не найден (нужен AR9285/9287/9485 или RTL8192EU)");
    return;

found:
    wifi_log("%s готов к работе (RX+TX)", wc.chip_name);
    /* автоподключение к сохранённой сети (WIFI.CFG) */
    char ssid[33];
    if (wifi_profile_load(ssid, sizeof(ssid))) {
        wifi_log("профиль: \"%s\" — автоподключение", ssid);
        wifi_connect(ssid);
    } else {
        wifi_log("профиль не задан — подключение из WiFi/Настроек");
    }
}
