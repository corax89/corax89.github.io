/* httpd60_test.c — хост-репро httpd N2600-OS (сессия 60).
 *
 * Проверяет исправления по отчёту аудита на РЕАЛЬНОМ net.c +
 * новом net_httpd.c через loopback-пару стека (127.0.0.1):
 *   1. /hello            — 200, Content-Length == фактической длине тела;
 *   2. /                 — файл www/index.html из RAM (ramfs-заглушка);
 *   3. /INDEX.HTML       — поиск без учёта регистра (ramfs_stat_ci);
 *   4. HEAD /hello       — только заголовки, CL тот же, тела нет;
 *   5. GETTER /hello     — 501 (метод с p[3] != ' ' больше не GET);
 *   6. /../x             — 404 (path-safe);
 *   7. /big.bin 16 КиБ   — FSM отправки: ровно CL байт, содержимое целое;
 *   8. /sysinfo          — статусная страница собирается без выхода за
 *                          границы (ASan), CL честный;
 *   9. idle-таймаут      — «молчаливый» клиент выкидывается через 30 с
 *                          (Slowloris), слот освобождается;
 *  10. переполнение слотов — 5-е соединение при 4 занятых отклоняется;
 *  11. SETTINGS.CFG      — "httpd=1" читается целиком (load_cfg).
 *
 * RAM disk — заглушка в этом файле (плоские имена, без учёта регистра);
 * остальное — канонические исходники ОС (симлинки в build_host). */
#include <stdio.h>
#include <string.h>
#include "net.h"
#include "net_httpd.h"
#include "ramfs.h"
#include "timer.h"
#include "task.h"
#include "mem.h"
#include "fake_nic.h"

/* fake_nic.c: обвязка NIC (заголовок не объявляет — объявления тут) */
extern void fake_nic_up(void);
extern u32 g_vticks;   /* модельное время (определено в fake_nic.c) */
extern void fake_tx_clear(void);
/* TLS/DHCP-заглушки — общие: stubs_net/tls_stubs.c */

/* без <stdlib.h> (конфликт с mem.h): свои минимумы */
static int t_atoi(const char *s)
{
    int v = 0, neg = 0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return neg ? -v : v;
}

/* ---- модель сети: кадры никуда не уходят (loopback-тесты) ---- */
void fake_server_on_tx(const u8 *frame, u32 len) { (void)frame; (void)len; }

static int g_fail = 0;
#define CHECK(cond, ...) do { \
        if (cond) { printf("  OK  " __VA_ARGS__); printf("\n"); } \
        else { printf("  FAIL " __VA_ARGS__); printf("\n"); g_fail++; } \
    } while (0)

/* ---------------- RAM disk-заглушка ---------------- */

#define SF_MAX 16
typedef struct { char name[80]; u32 size; u8 *data; int is_dir; } sfile_t;
static sfile_t g_sf[SF_MAX];
static int g_sf_n = 0;

static void sf_reset(void)
{
    for (int i = 0; i < g_sf_n; i++) free(g_sf[i].data);
    g_sf_n = 0;
}

static int sf_find_ci(const char *name)
{
    for (int i = 0; i < g_sf_n; i++) {
        const char *a = g_sf[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) return i;
    }
    return -1;
}

int ramfs_ready(void) { return 1; }

int ramfs_mkdir(const char *path)
{
    if (sf_find_ci(path) >= 0) return 0;
    if (g_sf_n >= SF_MAX) return 0;
    sfile_t *f = &g_sf[g_sf_n++];
    memset(f, 0, sizeof(*f));
    snprintf(f->name, sizeof(f->name), "%s", path);
    f->is_dir = 1;
    return 1;
}

int ramfs_create(const char *name, u32 size)
{
    if (sf_find_ci(name) >= 0) return 0;
    if (g_sf_n >= SF_MAX) return 0;
    sfile_t *f = &g_sf[g_sf_n++];
    memset(f, 0, sizeof(*f));
    snprintf(f->name, sizeof(f->name), "%s", name);
    f->data = (u8 *)malloc(size ? size : 1);
    if (f->data) memset(f->data, 0, size ? size : 1);
    f->size = size;
    return 1;
}

int ramfs_write(const char *name, const void *buf, u32 size)
{
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    u32 n = size < g_sf[i].size ? size : g_sf[i].size;
    memcpy(g_sf[i].data, buf, n);
    g_sf[i].size = n;
    return 1;
}

u32 ramfs_read(const char *name, void *buf, u32 max)
{
    int i = sf_find_ci(name);
    if (i < 0 || g_sf[i].is_dir) return 0;
    u32 n = g_sf[i].size < max ? g_sf[i].size : max;
    memcpy(buf, g_sf[i].data, n);
    return n;
}

int ramfs_stat_ci(const char *name, ramfs_dirent_t *out)
{
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    memset(out, 0, sizeof(*out));
    snprintf(out->name, sizeof(out->name), "%s", g_sf[i].name);
    out->size = g_sf[i].size;
    out->is_dir = (u8)g_sf[i].is_dir;
    return 1;
}

/* [UP] Task 43: недостающие операции — delete (перезапись upload) и
 * free_space (проверка места перед созданием) */
int ramfs_delete(const char *name)
{
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    free(g_sf[i].data);
    for (int j = i; j + 1 < g_sf_n; j++) g_sf[j] = g_sf[j + 1];
    g_sf_n--;
    return 1;
}

u32 ramfs_free_space(void) { return 8u * 1024u * 1024u; }

int ramfs_file_count(void) { return g_sf_n; }

/* ---------------- приём ответа клиентом ---------------- */

static char g_rx[262144];
static u32  g_rx_len = 0;
static int  g_cli_sock = -1;
static int  g_cli_port = 40000;

static void cli_recv(int sock, u32 ip, u16 port, const void *data, u32 len)
{
    (void)ip; (void)port;
    if (sock != g_cli_sock) return;
    if (g_rx_len + len <= sizeof(g_rx)) {
        memcpy(g_rx + g_rx_len, data, len);
        g_rx_len += len;
    }
}

/* Выполнить запрос; возвращает статус-код или -1. */
static int http_fetch(const char *req, const char **body, u32 *body_len,
                      const char **hdrs, u32 *hdr_len)
{
    g_rx_len = 0;
    g_cli_sock = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    if (g_cli_sock < 0) return -1;

    net_tcp_send(g_cli_sock, req, (u32)strlen(req));

    /* крутим стек: loopback доставляет всё инлайн, но даём FIN доехать */
    for (int i = 0; i < 500 && net_tcp_state(g_cli_sock) == TCP_ESTABLISHED;
         i++) {
        net_poll();
        net_httpd_poll();
        g_vticks += 10;
    }
    net_tcp_close(g_cli_sock);
    net_poll();

    /* разбор ответа */
    char *sep = NULL;
    for (u32 i = 0; i + 3 < g_rx_len; i++) {
        if (g_rx[i] == '\r' && g_rx[i+1] == '\n' &&
            g_rx[i+2] == '\r' && g_rx[i+3] == '\n') { sep = g_rx + i; break; }
    }
    if (!sep) {
        printf("  [dbg] нет заголовков: rx_len=%u sock=%d state=%d\n",
               g_rx_len, g_cli_sock,
               g_cli_sock >= 0 ? (int)net_tcp_state(g_cli_sock) : -1);
        return -2;
    }
    *hdr_len = (u32)(sep - g_rx) + 4;
    *hdrs = g_rx;
    *body = sep + 4;
    *body_len = g_rx_len - *hdr_len;

    int code = 0;
    if (g_rx_len >= 12 && strncmp(g_rx, "HTTP/1.0 ", 9) == 0)
        code = t_atoi(g_rx + 9);
    return code;
}

/* CL из заголовков (u32, 0 если нет) */
static u32 cl_of(const char *hdrs, u32 hdr_len)
{
    char tmp[256];
    u32 n = hdr_len < sizeof(tmp) - 1 ? hdr_len : (u32)sizeof(tmp) - 1;
    memcpy(tmp, hdrs, n);
    tmp[n] = 0;
    char *p = strstr(tmp, "Content-Length:");
    if (!p) {
        printf("  [dbg] CL не найден в [%.140s]\n", tmp);
        return 0;
    }
    return (u32)t_atoi(p + 15);
}

/* [UP] Task 43: то же, что http_fetch, но тело БИНАРНОЕ (multipart
 * содержит нули) — req/req_len отправляются как есть. */
static int http_fetch_bin(const char *req, u32 req_len,
                          const char **body, u32 *body_len,
                          const char **hdrs, u32 *hdr_len)
{
    g_rx_len = 0;
    g_cli_sock = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    if (g_cli_sock < 0) return -1;

    net_tcp_send(g_cli_sock, req, req_len);

    for (int i = 0; i < 500 && net_tcp_state(g_cli_sock) == TCP_ESTABLISHED;
         i++) {
        net_poll();
        net_httpd_poll();
        g_vticks += 10;
    }
    net_tcp_close(g_cli_sock);
    net_poll();

    char *sep = NULL;
    for (u32 i = 0; i + 3 < g_rx_len; i++) {
        if (g_rx[i] == '\r' && g_rx[i+1] == '\n' &&
            g_rx[i+2] == '\r' && g_rx[i+3] == '\n') { sep = g_rx + i; break; }
    }
    if (!sep) return -2;
    *hdr_len = (u32)(sep - g_rx) + 4;
    *hdrs = g_rx;
    *body = sep + 4;
    *body_len = g_rx_len - *hdr_len;

    int code = 0;
    if (g_rx_len >= 12 && strncmp(g_rx, "HTTP/1.0 ", 9) == 0)
        code = t_atoi(g_rx + 9);
    return code;
}

/* ---------------- сценарии ---------------- */

static void t1_hello(void)
{
    printf("[t1] GET /hello: 200, честный Content-Length\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(bl == 33 && memcmp(b, "Hello from N2600-OS local httpd!\n", 33) == 0,
          "тело %u байт", bl);
    CHECK(cl_of(h, hl) == bl, "CL == телу (%u)", cl_of(h, hl));
}

static void t2_index(void)
{
    printf("[t2] GET /: файл www/index.html из RAM\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET / HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    int i = sf_find_ci("www/index.html");
    CHECK(i >= 0, "демо-страница создана");
    if (i >= 0) {
        CHECK(bl == g_sf[i].size && memcmp(b, g_sf[i].data, bl) == 0,
              "тело == файлу (%u)", bl);
        CHECK(cl_of(h, hl) == bl, "CL == телу");
        /* NUL не должен уйти в файл (FIX LOW: sizeof-1) */
        CHECK(g_sf[i].data[g_sf[i].size] == 0 && bl > 0 &&
              g_sf[i].data[bl - 1] != 0,
              "файл без хвостового NUL");
    }
}

static void t3_caseins(void)
{
    printf("[t3] GET /INDEX.HTML: без учёта регистра\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /INDEX.HTML HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    (void)b; (void)h; (void)hl;
}

static void t4_head(void)
{
    printf("[t4] HEAD /hello: заголовки без тела\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("HEAD /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(cl_of(h, hl) == 33, "CL = 33 (как у GET)");
    CHECK(bl == 0, "тела нет (%u)", bl);
}

static void t5_getter(void)
{
    printf("[t5] GETTER /hello: 501 (метод не GET)\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GETTER /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 501, "код %d", code);
    CHECK(cl_of(h, hl) == bl, "CL == телу");
}

static void t6_traversal(void)
{
    printf("[t6] GET /../x: 404 (выход из www запрещён)\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /../x HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 404, "код %d", code);
    (void)b; (void)h; (void)hl;
}

static void t7_bigfile(void)
{
    printf("[t7] GET /big.bin (16 КиБ): FSM отправки, байт ровно CL\n");
    if (sf_find_ci("www/big.bin") < 0) {
        ramfs_create("www/big.bin", 16384);
        u8 *pat = (u8 *)malloc(16384);
        for (u32 i = 0; i < 16384; i++) pat[i] = (u8)(i * 7 + i / 251);
        ramfs_write("www/big.bin", pat, 16384);
        free(pat);
    }
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /big.bin HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(cl_of(h, hl) == 16384, "CL = 16384 (%u)", cl_of(h, hl));
    CHECK(bl == 16384, "получено %u байт", bl);
    if (bl == 16384) {
        int bad = 0;
        for (u32 i = 0; i < 16384; i++)
            if ((u8)b[i] != (u8)(i * 7 + i / 251)) { bad = 1; break; }
        CHECK(!bad, "содержимое целое");
    }
}

static void t8_sysinfo(void)
{
    printf("[t8] GET /sysinfo: статусная страница без порчи памяти\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /sysinfo HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(bl > 200 && bl < 1400, "разумный размер тела: %u", bl);
    CHECK(cl_of(h, hl) == bl, "CL == телу (%u == %u)", cl_of(h, hl), bl);
}

static void t9_idle(void)
{
    printf("[t9] idle-таймаут: молчаливый клиент выкидывается\n");
    int s = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    CHECK(s >= 0 && net_tcp_state(s) == TCP_ESTABLISHED, "соединение открыто");
    if (s < 0) return;
    g_cli_sock = s;

    /* 30 с тишины (1 тик = 1 мс) — по шагам, чтобы poll шёл */
    for (int i = 0; i < 3200; i++) {
        g_vticks += 10;
        net_poll();
        net_httpd_poll();
    }
    CHECK(net_tcp_state(s) != TCP_ESTABLISHED,
          "сокет закрыт сервером по таймауту");

    /* слот освободился — новое соединение работает */
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "после таймаута сервер жив (код %d)", code);
}

static void t10_slots(void)
{
    printf("[t10] 4 молчаливых клиента: 5-й отклоняется\n");
    int socks[4];
    int ok = 1;
    for (int i = 0; i < 4; i++) {
        socks[i] = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
        if (socks[i] < 0 || net_tcp_state(socks[i]) != TCP_ESTABLISHED) ok = 0;
    }
    CHECK(ok, "4 соединения принято");

    int s5 = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    CHECK(s5 < 0 || net_tcp_state(s5) != TCP_ESTABLISHED,
          "5-е соединение отклонено");

    for (int i = 0; i < 4; i++)
        if (socks[i] >= 0) net_tcp_close(socks[i]);
    if (s5 >= 0) net_tcp_close(s5);
    net_poll();
}

static void t11_cfg(void)
{
    printf("[t11] SETTINGS.CFG читается целиком (httpd=1)\n");
    /* сервер уже работает; настройка "httpd=1" в конце файла не должна
     * ломать автостарт (раньше читались только первые 255 байт) */
    if (sf_find_ci("SETTINGS.CFG") < 0) {
        const char *cfg =
            "adapter=auto\n"
            "wifi=1\n"
            ";\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "httpd=1\n";
        ramfs_create("SETTINGS.CFG", (u32)strlen(cfg));
        ramfs_write("SETTINGS.CFG", cfg, (u32)strlen(cfg));
    }
    /* сам запуск проверяется в main() сразу после net_httpd_start() */
}

/* ---------------- [UP] Task 43: POST /upload ---------------- */

/* Собрать multipart-запрос с одной file-частью и одной текстовой. */
static u32 build_multipart(char *out, u32 cap,
                           const char *bnd,
                           const char *fname,
                           const u8 *file, u32 flen)
{
    u32 o = 0;
    int n;
    n = snprintf(out + o, cap - o,
                 "POST /upload HTTP/1.1\r\n"
                 "Host: n2600\r\n"
                 "User-Agent: test-agent\r\n"
                 "Accept: */*\r\n"
                 "Content-Type: multipart/form-data; boundary=%s\r\n"
                 "Content-Length: ", bnd);
    if (n > 0) o += (u32)n;
    /* длину считаем после сборки тела — сначала прикинем */
    /* тело (без финального \r\n после --bnd--, как шлют браузеры) */
    char body[70000];
    u32 bo = 0;
    n = snprintf(body, sizeof(body) - flen - 64,
                 "--%s\r\n"
                 "Content-Disposition: form-data; name=\"file\"; "
                 "filename=\"%s\"\r\n"
                 "Content-Type: application/octet-stream\r\n"
                 "\r\n",
                 bnd, fname);
    if (n > 0) bo += (u32)n;
    memcpy(body + bo, file, flen); bo += flen;
    n = snprintf(body + bo, sizeof(body) - bo,
                 "\r\n--%s\r\n"
                 "Content-Disposition: form-data; name=\"submit\"\r\n"
                 "\r\n"
                 "ok\r\n"
                 "--%s--\r\n",
                 bnd, bnd);
    if (n > 0) bo += (u32)n;
    n = snprintf(out + o, cap - o, "%u\r\n\r\n", bo);
    if (n > 0) o += (u32)n;
    if (o + bo < cap) { memcpy(out + o, body, bo); o += bo; }
    return o;
}

static void t12_upload(void)
{
    printf("[t12] POST /upload multipart: файл с нулями + текстовое поле\n");
    /* дать стеку доиграть закрытия t10 (LAST_ACK/TIME_WAIT — модельное
     * время): иначе свежие соединения попадают в занятый слот-загадку */
    for (int i = 0; i < 200; i++) { net_poll(); net_httpd_poll(); g_vticks += 50; }
    /* бинарное содержимое с нулями и CRLF — часто ломает строчные парсеры */
    u8 bin[300];
    for (int i = 0; i < (int)sizeof(bin); i++) bin[i] = (u8)(i * 7);
    bin[10] = 0; bin[11] = '\r'; bin[12] = '\n'; bin[13] = 0;
    const char *bnd = "----N2600TestBoundary42";
    static char req[71000];
    u32 rl = build_multipart(req, sizeof(req), bnd, "up test.bin", bin, sizeof(bin));
    CHECK(rl > 400, "запрос собран (%u б)", rl);

    const char *body, *hdrs; u32 bl, hl;
    int code = http_fetch_bin(req, rl, &body, &bl, &hdrs, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(bl > 0 && strstr(body, "Загружено: up test.bin") != NULL,
          "ответ содержит «Загружено»");
    int i = sf_find_ci("www/up test.bin");
    CHECK(i >= 0, "файл в www (без пути и кавычек)");
    if (i >= 0) {
        CHECK(g_sf[i].size == sizeof(bin), "размер %u == %u",
              (unsigned)g_sf[i].size, (unsigned)sizeof(bin));
        CHECK(g_sf[i].data && memcmp(g_sf[i].data, bin, sizeof(bin)) == 0,
              "содержимое побайтно целое (нули/CRLF не тронуты)");
    }
    /* перезапись тем же именем: дублей быть не должно */
    rl = build_multipart(req, sizeof(req), bnd, "up test.bin", bin, 100);
    code = http_fetch_bin(req, rl, &body, &bl, &hdrs, &hl);
    CHECK(code == 200, "повторный upload: код %d", code);
    i = sf_find_ci("www/up test.bin");
    CHECK(i >= 0 && g_sf[i].size == 100, "перезапись: размер 100 (%u)",
          i >= 0 ? (unsigned)g_sf[i].size : 0u);
}

static void t13_upload_errors(void)
{
    printf("[t13] POST /upload: без CL / слишком большой / без filename\n");
    const char *body, *hdrs; u32 bl, hl;

    /* без Content-Length */
    {
        static const char q[] =
            "POST /upload HTTP/1.1\r\n"
            "Content-Type: multipart/form-data; boundary=xx\r\n\r\n"
            "--xx\r\n";
        int code = http_fetch_bin(q, (u32)sizeof(q) - 1, &body, &bl, &hdrs, &hl);
        CHECK(code == 400, "без CL: код %d", code);
    }
    /* слишком большой */
    {
        char *q = (char *)malloc(70000);
        int n = snprintf(q, 70000,
                         "POST /upload HTTP/1.1\r\n"
                         "Content-Type: multipart/form-data; boundary=yy\r\n"
                         "Content-Length: 100000\r\n\r\n");
        memset(q + n, 'A', 60000);
        int code = http_fetch_bin(q, (u32)(n + 60000), &body, &bl, &hdrs, &hl);
        CHECK(code == 400, "CL > 64К: код %d", code);
        free(q);
    }
    /* multipart без filename (только текстовое поле) */
    {
        static const char bodytxt[] =
            "--zz\r\n"
            "Content-Disposition: form-data; name=\"note\"\r\n"
            "\r\n"
            "привет\r\n"
            "--zz--\r\n";
        static char q[512];
        int n = snprintf(q, sizeof(q),
                         "POST /upload HTTP/1.1\r\n"
                         "Content-Type: multipart/form-data; boundary=zz\r\n"
                         "Content-Length: %u\r\n\r\n",
                         (unsigned)(sizeof(bodytxt) - 1));
        memcpy(q + n, bodytxt, sizeof(bodytxt) - 1);
        int code = http_fetch_bin(q, (u32)(n + (int)sizeof(bodytxt) - 1),
                                  &body, &bl, &hdrs, &hl);
        CHECK(code == 400, "без filename: код %d", code);
    }
    /* GET /upload — страница с формой */
    {
        int code = http_fetch("GET /upload HTTP/1.1\r\nHost: x\r\n\r\n",
                              &body, &bl, &hdrs, &hl);
        CHECK(code == 200, "GET /upload: код %d", code);
        CHECK(bl > 0 && strstr(body, "multipart/form-data") != NULL &&
              strstr(body, "type=\"file\"") != NULL,
              "страница содержит форму загрузки");
    }
    /* демо-страница (создаётся при старте сервера) содержит форму */
    {
        int code = http_fetch("GET / HTTP/1.1\r\nHost: x\r\n\r\n",
                              &body, &bl, &hdrs, &hl);
        CHECK(code == 200, "GET /: код %d", code);
        CHECK(bl > 0 && strstr(body, "action=\"/upload\"") != NULL,
              "демо-страница содержит форму /upload");
    }
}

int main(void)
{
    net_tcp_set_callback(cli_recv);

    sf_reset();
    fake_nic_up();
    net_init();
    net_set_ip(0x0A5C3CC7u);
    net_set_netmask(0xFFFFFF00u);
    net_set_gateway(0x0A050001u);

    t11_cfg();          /* SETTINGS.CFG кладём ДО старта сервера */
    net_httpd_start();
    CHECK(net_httpd_running(), "httpd слушает :80");

    t1_hello();
    t2_index();
    t3_caseins();
    t4_head();
    t5_getter();
    t6_traversal();
    t7_bigfile();
    t8_sysinfo();
    t9_idle();
    t10_slots();
    t12_upload();
    t13_upload_errors();

    printf("\n========================================\n");
    if (g_fail == 0) printf("HTTPD60: ВСЕ ПРОВЕРКИ ЗЕЛЁНЫЕ\n");
    else             printf("HTTPD60: ПРОВАЛОВ: %d\n", g_fail);
    return g_fail ? 1 : 0;
}
