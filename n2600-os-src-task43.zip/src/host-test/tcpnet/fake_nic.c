/* fake_nic.c — реализации заглушек для хост-тестов TCP-стека N2600-OS.
 *
 * Фейковый e1000: кадры ОС уходят в журнал (fake_tx_frame) и в хук
 * модели сервера fake_server_on_tx (определён в tcpnet_test.c);
 * кадры «из провода» кладутся в очередь fake_inject и выдаются
 * через e1000_recv по одному за вызов.
 *
 * Попутно ПРОВЕРЯЮТСЯ чексуммы (TCP и IP) каждого исходящего кадра:
 * счётчики g_tx_tcp_cs_bad / g_tx_ip_cs_bad. */
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#define E1000_NO_STUBS
#include "e1000.h"
#include "fake_nic.h"

/* --- хостовые куча/время/задачи (реализации заглушек) --- */
#include "mem.h"
#include "timer.h"
#include "task.h"

u32 g_vticks = 0;
u32 g_yield_per_call = 1;

/* хостовая куча (имя malloc/free занято заглушкой с сигнатурой ОС) */
extern void *__libc_malloc(size_t n);
extern void  __libc_free(void *p);
void *malloc(size_t n) { return __libc_malloc(n); }
void  free(void *p) { __libc_free(p); }
u32   mem_used(void) { return 0; }
u32   mem_heap_size(void) { return 0; }

u32 timer_ticks(void) { return g_vticks; }

void task_yield(void) { g_vticks += g_yield_per_call; }
int  task_spawn(const char *name, void (*fn)(void *), void *arg)
{ (void)name; (void)fn; (void)arg; return -1; }
void task_exit(void) {}
int  task_current(void) { return 1; }
int  task_finished(int idx) { (void)idx; return 0; }
void task_wake(int idx) { (void)idx; }
void task_set_lockwait_me(int on) { (void)on; }

/* --- serial --- */
static char g_serial[65536];
static int  g_serial_n = 0;
void serial_puts(const char *s)
{
    while (*s && g_serial_n < (int)sizeof(g_serial) - 1)
        g_serial[g_serial_n++] = *s++;
    fputs(s, stdout);
}
const char *fake_serial_get(void) { g_serial[g_serial_n] = 0; return g_serial; }
void fake_serial_clear(void) { g_serial_n = 0; g_serial[0] = 0; }

/* [UP] Task 43: net.c с [IP-CHG2] пишет и в klog — в хост-тесте klog
 * это тот же журнал (fake_serial_* показывает оба) */
void klog_puts(const char *s)
{
    serial_puts(s);
}

/* --- фейковый NIC --- */
#define QMAX 128
static u8  qf[QMAX][1600];
static u32 ql[QMAX];
static int qh, qt;

static u8  g_mac[6] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 };
static int g_present = 0;

static u8  txf[512][1600];
static u32 txl[512];
static u32 txt[512];   /* виртуальное время каждого кадра */
static int txn;
int g_tx_tcp_cs_bad = 0;
int g_tx_ip_cs_bad  = 0;

void fake_nic_up(void) { g_present = 1; }
void fake_tx_clear(void) { txn = 0; g_tx_tcp_cs_bad = 0; g_tx_ip_cs_bad = 0; }
int  fake_tx_count(void) { return txn; }
const u8 *fake_tx_frame(int i, u32 *len)
{
    if (len) *len = txl[i];
    return txf[i];
}

void fake_inject(const void *frame, u32 len)
{
    if (!frame || len == 0 || len > 1600) return;
    if (((qt + 1) % QMAX) == qh) return;   /* переполнение — молча */
    memcpy(qf[qt], frame, len);
    ql[qt] = len;
    qt = (qt + 1) % QMAX;
}

int e1000_present(void) { return g_present; }
int e1000_link_up(void) { return 1; }
const char *e1000_chip_name(void) { return "fake-e1000"; }
int e1000_get_mac(u8 m[6]) { memcpy(m, g_mac, 6); return 1; }
void e1000_set_dest_mac(const u8 mac[6]) { (void)mac; }
int e1000_init(void) { return g_present; }
void e1000_poll(void) {}
void e1000_debug_dump(void) {}

int e1000_send(const void *buf, u32 len)
{
    if (!buf || len == 0 || len > 1600) return -1;
    if (txn < 512) {
        memcpy(txf[txn], buf, len);
        txl[txn] = len;
        txt[txn] = g_vticks;
        txn++;
    }
    fake_server_on_tx((const u8 *)buf, len);   /* модель сервера */
    return (int)len;
}

u32 e1000_recv(void *out, u32 max)
{
    if (qh == qt) return 0;
    u32 n = ql[qh];
    if (n > max) n = max;
    memcpy(out, qf[qh], n);
    qh = (qh + 1) % QMAX;
    return n;
}

/* --- прочие драйверы: отсутствуют --- */
int  ne2000_present(void) { return 0; }
int  ne2000_get_mac(u8 m[6]) { (void)m; return 0; }
int  ne2000_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
u32  ne2000_recv(void *o, u32 m) { (void)o; (void)m; return 0; }

int  virtio_net_present(void) { return 0; }
int  virtio_net_get_mac(u8 m[6]) { (void)m; return 0; }
int  virtio_net_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
u32  virtio_net_recv(void *o, u32 m) { (void)o; (void)m; return 0; }
const char *virtio_net_chip_name(void) { return "none"; }

int  atl1c_present(void) { return 0; }
int  atl1c_link_up(void) { return 0; }
int  atl1c_get_mac(u8 m[6]) { (void)m; return 0; }
int  atl1c_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
u32  atl1c_recv(void *o, u32 m) { (void)o; (void)m; return 0; }

int  wifi_present(void) { return 0; }
int  wifi_ready(void) { return 0; }
int  wifi_net_link(void) { return 0; }
int  wifi_net_get_mac(u8 m[6]) { (void)m; return 0; }
int  wifi_net_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
u32  wifi_net_recv(void *o, u32 m) { (void)o; (void)m; return 0; }

/* --- проверка чексумм исходящих кадров ОС --- */
u32 fake_tx_time(int i) { return txt[i]; }

static u16 cksum(const u8 *p, u32 n)
{
    u32 sum = 0;
    for (u32 i = 0; i + 1 < n; i += 2) sum += ((u32)p[i] << 8) | p[i + 1];
    if (n & 1) sum += (u32)p[n - 1] << 8;
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)(~sum & 0xFFFF);
}

void fake_check_tx_checksums(const u8 *f, u32 len)
{
    if (len < 34) return;
    if (f[12] != 0x08 || f[13] != 0x00) return;      /* не IPv4 */
    const u8 *ip = f + 14;
    u32 ihl = (u32)(ip[0] & 0x0F) * 4;
    u32 tot = ((u32)ip[2] << 8) | ip[3];
    if (ihl < 20 || tot < ihl || 14 + tot > len) return;
    u8 proto = ip[9];

    /* IP: сумма по заголовку ВМЕСТЕ с полем чексуммы должна дать 0xFFFF */
    if (cksum(ip, ihl) != 0x0000) { g_tx_ip_cs_bad++; return; }

    /* TCP: псевдозаголовок + TCP-сегмент (с полем) == 0xFFFF */
    if (proto == 6 && tot >= ihl + 20) {
        const u8 *tcp = ip + ihl;
        u32 tlen = tot - ihl;
        u32 sum = 0;
        sum += ((u32)ip[12] << 8) | ip[13];
        sum += ((u32)ip[14] << 8) | ip[15];
        sum += ((u32)ip[16] << 8) | ip[17];
        sum += ((u32)ip[18] << 8) | ip[19];
        sum += (u32)proto + tlen;
        /* возвращает ~sum; нужно сверить как «сумма == 0xFFFF»:
         * cksum вернёт 0xFFFF при корректном сегменте */
        u32 s2 = sum;
        for (u32 i = 0; i + 1 < tlen; i += 2)
            s2 += ((u32)tcp[i] << 8) | tcp[i + 1];
        if (tlen & 1) s2 += (u32)tcp[tlen - 1] << 8;
        while (s2 >> 16) s2 = (s2 & 0xFFFF) + (s2 >> 16);
        /* корректный сегмент: полная сумма (псевдо+TCP с полем) == 0xFFFF */
        if ((s2 & 0xFFFF) != 0xFFFF) g_tx_tcp_cs_bad++;
    }
}
