/* kernel.h — глобальные службы ядра */
#ifndef KERNEL_H
#define KERNEL_H

#include "types.h"
#include "boot.h"

const mb_info_t *mb_info(void);
void sys_reboot(void);
void sys_poweroff(void);

/* Журнал загрузки (klog): кольцевой буфер строк. Каждая строка dbg()/
 * dbg_err() + ключевые вехи kmain попадают сюда; команда dmesg в
 * терминале выводит журнал целиком («процесс загрузки»). */
void        klog_puts(const char *s);       /* добавить строку (без \n) */
const char *klog_get(void);                 /* весь журнал, '\n'-разделённый */
int         klog_line_count(void);

/* Сессия 11: 0/1 = фоновая инициализация SATA идёт/не идёт (fileman
 * показывает «инициализация...» вместо пустого списка до готовности). */
int sata_pending(void);

/* Сессия 11: перезапросить DHCP на активном адаптере (netmon). */
void net_request_dhcp(void);

#endif
