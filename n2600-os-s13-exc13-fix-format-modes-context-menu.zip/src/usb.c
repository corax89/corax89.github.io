/* usb.c — компактный стек USB (UHCI + HID boot-protocol) для N2600-OS.
 *
 * Реализовано:
 *   1. PCI-сканирование: UHCI = class 0x0C, subclass 0x03, prog-if 0x00.
 *   2. Полноценный UHCI QH-stack: TD (32 байта), QH (8 байт), frame list
 *      (4 КиБ = 1024 элементов), вставка TD/QH в кадры.
 *   3. Control-трансферы: SETUP + DATA + STATUS — для дескрипторов
 *      и установки адреса/конфигурации.
 *   4. Перечисление: GetDescriptor(Device,8) @ addr=0 → SetAddress →
 *      GetDescriptor(Device,18) @ addr → GetDescriptor(Config) →
 *      SetConfiguration → для HID: SetIdle + SetProtocol(Boot).
 *   5. Interrupt-трансферы на EP1: вставляем TD в кадр каждые 8 позиций
 *      (каждые 8 мс). Из usb_poll() проверяем завершение, читаем отчёты
 *      (8 байт клавиатура, 4 байта мышь) и инжектим события в PS/2 ring
 *      (kbd.c и mouse.c) — WM «видит» USB-устройства как PS/2.
 *
 * НЕ реализовано (ограничение):
 *   - EHCI/XHCI (USB 2.0/3.0 hi-speed). Для hi-speed флешек нужен EHCI +
 *     bulk-трансферы + SCSI/BBB — в разы больше кода. См. usb_ehci.c.
 *   - Хабы (Hub class) — только порты рут-хаба UHCI (2 шт.).
 *   - USB прерывания — polling из главного цикла.
 *
 * Источники вдохновения: SanOS (Michael Ringgaard), HelenOS,
 * UHCI spec 1.0d (ftp://ftp.netbsd.org/pub/NetBSD/...).
 */
#include "usb.h"
#include "usb_ehci.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"

extern void serial_puts(const char *s);
extern void serial_putc(char c);

/* ---------- PCI конфигурация ---------- */

#define PCI_ADDR  0xCF8
#define PCI_DATA  0xCFC

u32 pci_read32(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return inl(PCI_DATA);
}

u16 pci_read16(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return (u16)((inl(PCI_DATA) >> ((reg & 2) * 8)) & 0xFFFF);
}

u8 pci_read8(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return (u8)((inl(PCI_DATA) >> ((reg & 3) * 8)) & 0xFF);
}

void pci_write32(int bus, int dev, int func, int reg, u32 val)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    outl(PCI_DATA, val);
}

void pci_write16(int bus, int dev, int func, int reg, u16 val)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    u32 old = inl(PCI_DATA);
    u32 shift = (reg & 2) * 8;
    u32 mask = 0xFFFFu << shift;
    u32 new = (old & ~mask) | (((u32)val) << shift);
    outl(PCI_DATA, new);
}

/* ---------- UHCI регистры ---------- */

#define UHCI_USBCMD     0x00
#define UHCI_USBSTS     0x02
#define UHCI_USBINTR    0x04
#define UHCI_FRNUM      0x06
#define UHCI_FRBASEADD  0x08
#define UHCI_SOFMOD     0x0C
#define UHCI_PORTSC1    0x10
#define UHCI_PORTSC2    0x12

#define USBCMD_GRESET   0x04
#define USBCMD_HCRESET  0x02
#define USBCMD_RS       0x01
#define USBCMD_FGBL     0x40
#define USBCMD_MAXP     0x80

#define USBSTS_HC_HALTED 0x20
#define USBSTS_USB_INT   0x01

#define PORTSC_CONNECT    0x0001
#define PORTSC_CONNECT_C  0x0002
#define PORTSC_ENABLE     0x0004
#define PORTSC_RESET      0x0200
#define PORTSC_LOWSPEED   0x0100
#define PORTSC_SUSPEND    0x1000

/* Transfer Descriptor — 32 байта, выравнивание 16 байт.
 * Layout соответствует UHCI spec (4 dword'а аппаратной части + 4 dword'а soft). */
typedef struct __attribute__((packed, aligned(16))) uhci_td {
    u32 link;        /* link pointer (бит 0 = term, бит 1 = QH, бит 2 = depth-first) */
    u32 ctrl_status;
    u32 token;
    u32 buffer;
    /* soft-поля (не hardware) */
    u32 done;         /* 1 = TD выполнен (для polling-логики) */
    u32 buf_phys;     /* физический адрес data-буфера */
    u32 next_td;      /* для программной цепочки */
    u32 reserved;
} uhci_td_t;

/* Queue Head — 16 байт (8 hardware + 8 padding), выравнивание 16. */
typedef struct __attribute__((packed, aligned(16))) uhci_qh {
    u32 head;         /* link to next QH/TD */
    u32 element;       /* link to first TD in queue */
    u32 pad1, pad2;
} uhci_qh_t;

/* Флаги ctrl_status UHCI TD:
 *   bits 31..24:  reserved (0)
 *   bit 23:       Active
 *   bit 22:       Stalled
 *   bit 21:       Data Buffer Error
 *   bit 20:       Bitstuff Error (SPD bit in some docs)
 *   bit 19:       IOC (Interrupt On Complete)
 *   bit 18:       Babble Detected
 *   bit 17:       NAK Received
 *   bit 16:       CRC/Timeout Error
 *   bits 15..11:  ACTUAL_LENGTH (получено байт, биты 0..10)
 *   bit 10:       Bitstuff Error
 *   bit 9:        Timeout / CRC Error
 *   bit 8:        Babble
 *   bit 7:        NAK
 *   bit 6:        Data Buffer Error
 *   bit 5:        Stalled
 *   bit 4:        Active (mirror?)
 *   bits 3..0:    PID
 * Реально в поле ctrl_status:
 *   bits 0..10:   actual_length (max len - 1 written here by host on completion)
 *   bit 20:       SPD (short packet detect)
 *   bit 23:       Active (1 = TD is active)
 *   bit 24:       IOC (Interrupt On Completion)
 *   bit 26:       LS (Low-speed device bit) —moved to token field actually
 */

#define TD_CTRL_ACTIVE   (1u << 23)    /* bit 23: Active (1 = TD pending) */
#define TD_CTRL_IOC      (1u << 24)    /* bit 24: Interrupt On Complete */
#define TD_CTRL_SPD      (1u << 20)    /* bit 20: Short Packet Detect (NOT used here) */
#define TD_CTRL_LS        (1u << 26)   /* bit 26: Low-Speed device */
/* length is NOT in ctrl_status; it's in token field (bits 30..21).
 * UHCI ctrl_status bits 10..0 = actual_length (read-only, set by HC). */

/* For SETUP we WANT SPD and IOC. For DATA, IOC + SPD. For STATUS, IOC + zero len. */
#define TD_CTRL_SETUP (TD_CTRL_ACTIVE | TD_CTRL_IOC | TD_CTRL_SPD)
#define TD_CTRL_DATA  (TD_CTRL_ACTIVE | TD_CTRL_IOC | TD_CTRL_SPD)
#define TD_CTRL_STATUS (TD_CTRL_ACTIVE | TD_CTRL_IOC)

/* PID'ы: UHCI использует значения как в спецификации — LS-first, инвертированные. */
#define PID_SETUP 0x2D
#define PID_IN    0x69
#define PID_OUT   0xE1

static inline u32 uhci_make_token(u8 pid, u8 addr, u8 endp, int toggle, int len)
{
    return ((u32)pid) |
           ((u32)addr << 8) |
           ((u32)(endp & 0xF) << 15) |
           ((u32)(toggle ? 1 : 0) << 19) |
           ((u32)((len - 1) & 0x7FF) << 21);
}

/* ---------- дескрипторы USB ---------- */

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 bcdUSB;
    u8 bDeviceClass, bDeviceSubClass, bDeviceProtocol;
    u8 bMaxPacketSize0;
    u16 idVendor, idProduct, bcdDevice;
    u8 iManufacturer, iProduct, iSerial;
    u8 bNumConfigurations;
} usb_device_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 wTotalLength;
    u8 bNumInterfaces, bConfigValue, iConfiguration, bmAttributes;
    u8 bMaxPower;
} usb_config_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bInterfaceNumber, bAlternateSetting;
    u8 bNumEndpoints, bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol;
    u8 iInterface;
} usb_iface_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bEndpointAddress, bmAttributes;
    u16 wMaxPacketSize;
    u8 bInterval;
} usb_ep_desc_t;

/* ---------- найденные устройства ---------- */

#define USB_MAX_DEVICES 4

typedef enum {
    DEV_NONE = 0,
    DEV_KEYBOARD,
    DEV_MOUSE,
} dev_kind_t;

typedef struct {
    int      valid;
    int      addr;           /* USB-адрес (после SET_ADDRESS) */
    int      low_speed;
    int      ep_in;          /* номер interrupt-IN endpoint (обычно 1) */
    int      ep_size;        /* max packet size для ep_in */
    int      ep_toggle;
    dev_kind_t kind;
    u8       last_report[8]; /* последний прочитанный отчёт (для дедупликации) */
    int      has_report;
    uhci_td_t *intr_td;      /* periodic TD для опроса (если есть) */
    u8       *intr_buf;      /* буфер под interrupt-данные */
} usb_dev_t;

static usb_dev_t usb_devices[USB_MAX_DEVICES];
static int usb_dev_count = 0;

/* ---------- контроллер ---------- */

typedef struct {
    int  valid;
    u16  iobase;
    u32 *frame_list;          /* 1024 физических указателя (4 КиБ) */
    u8  *frame_list_storage;  /* сохранённое выделение для free (если было выравнивание) */
} uhci_ctrl_t;

static uhci_ctrl_t uhci_ctrl;

/* Удержание: список TD, которые надо освободить после завершения. */
#define USB_TD_POOL 64
static uhci_td_t td_pool[USB_TD_POOL];
static u8 td_used[USB_TD_POOL];

static uhci_td_t *td_alloc(void)
{
    for (int i = 0; i < USB_TD_POOL; i++) {
        if (!td_used[i]) {
            td_used[i] = 1;
            memset(&td_pool[i], 0, sizeof(uhci_td_t));
            return &td_pool[i];
        }
    }
    return NULL;
}

static void td_free(uhci_td_t *td)
{
    if (!td) return;
    for (int i = 0; i < USB_TD_POOL; i++) {
        if (&td_pool[i] == td) { td_used[i] = 0; return; }
    }
}

static inline u32 td_phys(uhci_td_t *td)
{
    return (u32)(unsigned long)td;
}

static inline u16 uhci_in(u16 base, int reg) { return inw(base + reg); }
static inline void uhci_out(u16 base, int reg, u16 val) { outw(base + reg, val); }

/* Ждать, пока TD не выполнится. Возвращает кол-во переданных байт или -1.
 * timeout_iters — число итераций ожидания (каждая итерация ~100ns в QEMU).
 * Учитывает NAK — устройство может быть занято, HC повторяет передачу. */
static int uhci_wait_td(uhci_td_t *td, int timeout_iters)
{
    for (int i = 0; i < timeout_iters; i++) {
        u32 cs = td->ctrl_status;
        if (!(cs & TD_CTRL_ACTIVE)) {
            /* Готово. Проверим ошибки. */
            u32 err_mask = (1u << 22) | (1u << 21) | (1u << 18) | (1u << 17) | (1u << 16);
            if (cs & err_mask) {
                return -1;
            }
            /* actual_length: биты 0..10 содержат длину - 1 */
            int actual = (int)((cs >> 0) & 0x7FFu) + 1;
            return actual;
        }
        /* Уступим немного времени HC */
        (void)inb(0x80);
    }
    return -1;
}

/* ---------- инициализация контроллера ---------- */

static int uhci_init_one(int bus, int dev, int func)
{
    u32 bar4 = pci_read32(bus, dev, func, 0x20);
    if (bar4 == 0xFFFFFFFF || bar4 == 0) return 0;
    u16 iobase = (u16)(bar4 & 0xFFFC);

    /* Включаем Bus Master + I/O Space + Memory (для подстраховки) */
    u16 cmd = pci_read16(bus, dev, func, 0x04);
    cmd |= 0x07;     /* IOSE | MSE | BME */
    pci_write16(bus, dev, func, 0x04, cmd);

    uhci_ctrl.iobase = iobase;

    /* Сброс контроллера */
    uhci_out(iobase, UHCI_USBCMD, USBCMD_HCRESET);
    for (volatile int i = 0; i < 100000; i++) { }   /* ~10ms */
    uhci_out(iobase, UHCI_USBCMD, 0);
    for (volatile int i = 0; i < 100000; i++) { }

    uhci_out(iobase, UHCI_USBSTS, 0xFFFF);

    /* Выделяем 8 КиБ под frame list + выравнивание до 4K */
    u8 *storage = (u8 *)malloc(8192 + 16);
    if (!storage) {
        serial_puts("[usb] no memory for frame list\n");
        return 0;
    }
    u32 aligned = ((u32)(unsigned long)storage + 0xFFF) & ~0xFFFu;
    u32 *flist = (u32 *)(unsigned long)aligned;

    uhci_ctrl.frame_list = flist;
    uhci_ctrl.frame_list_storage = storage;

    /* Терминируем все 1024 элементов как пустые (бит 0 = 1 = no link) */
    for (int i = 0; i < 1024; i++) flist[i] = 0x00000001u;

    /* Программируем FRBASEAD (32-битный физический адрес) */
    outl(iobase + UHCI_FRBASEADD, (u32)(unsigned long)flist);
    uhci_out(iobase, UHCI_FRNUM, 0);
    uhci_out(iobase, UHCI_SOFMOD, 64);    /* ~1ms SOF */
    uhci_out(iobase, UHCI_USBINTR, 0);

    /* Включаем контроллер: Run (bit 0) + Configure Flag (bit 7).
     * ВАЖНО: НЕ устанавливать бит 6 (Forced Global Resume) — он затягивает HC
     * в режим resume, и TD'шки не исполняются. */
    uhci_out(iobase, UHCI_USBCMD, USBCMD_RS | USBCMD_MAXP);
    for (volatile int i = 0; i < 50000; i++) { }

    /* Проверим, что HC действительно запустился (USBSTS.HCHALTED = 0). */
    {
        u16 sts = uhci_in(iobase, UHCI_USBSTS);
        if (sts & USBSTS_HC_HALTED) {
            char buf[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf),
                     "[usb] WARN: HC still halted after enable, sts=0x%x\n",
                     (unsigned)sts);
            serial_puts(buf);
        }
    }

    uhci_ctrl.valid = 1;

    char buf[80];
    extern int snprintf(char *out, u32 n, const char *fmt, ...);
    snprintf(buf, sizeof(buf), "[usb] UHCI at 0x%x, frame_list=%p, sts=0x%x\n",
             (unsigned)iobase, (void *)(unsigned long)flist,
             (unsigned)uhci_in(iobase, UHCI_USBSTS));
    serial_puts(buf);

    return 1;
}

static void uhci_scan_pci(void)
{
    uhci_ctrl.valid = 0;

    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                if ((id & 0xFFFF) == 0 || (id & 0xFFFF) == 0xFFFF) {
                    if (func == 0) break;
                    continue;
                }
                u32 class_code = pci_read32(bus, dev, func, 0x08);
                u8 base_class = (u8)((class_code >> 24) & 0xFF);
                u8 sub_class  = (u8)((class_code >> 16) & 0xFF);
                u8 prog_if    = (u8)((class_code >> 8)  & 0xFF);
                if (base_class == 0x0C && sub_class == 0x03 && prog_if == 0x00) {
                    char buf[80];
                    snprintf(buf, sizeof(buf),
                             "[usb] UHCI: bus=%d dev=%d func=%d\n",
                             bus, dev, func);
                    serial_puts(buf);
                    if (uhci_init_one(bus, dev, func)) {
                        return;
                    }
                }
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    serial_puts("[usb] no UHCI controller found\n");
}

/* ---------- порт-менеджмент ---------- */

static int port_reset(u16 iobase, int port)
{
    int reg = UHCI_PORTSC1 + port * 2;
    u16 ps = uhci_in(iobase, reg);
    if (!(ps & PORTSC_CONNECT)) return 0;
    uhci_out(iobase, reg, PORTSC_RESET);
    for (volatile int i = 0; i < 100000; i++) { }   /* ~10ms */
    uhci_out(iobase, reg, 0);
    for (volatile int i = 0; i < 50000; i++) { }
    u16 ps2 = uhci_in(iobase, reg);
    uhci_out(iobase, reg, (u16)(ps2 | PORTSC_CONNECT_C));
    u16 ps3 = uhci_in(iobase, reg);
    uhci_out(iobase, reg, (u16)(ps3 | PORTSC_ENABLE));
    for (volatile int i = 0; i < 20000; i++) { }
    return 1;
}

/* ---------- control-трансфер ---------- */

/* Стандартные запросы USB. */
typedef struct __attribute__((packed)) {
    u8 bmRequestType;
    u8 bRequest;
    u16 wValue;
    u16 wIndex;
    u16 wLength;
} usb_request_t;

/* Запланировать QH+TDs в текущий кадр frame list. После завершения — снять. */
static int uhci_run_transfer(int addr, int low_speed, u8 *setup_buf,
                              void *data_buf, int data_len, int data_in,
                              u8 *out_status)
{
    if (!uhci_ctrl.valid) return -1;
    (void)out_status;

    /* TD1: SETUP (8 байт, toggle=0) */
    uhci_td_t *td_setup = td_alloc();
    /* TD2..n: DATA (toggle = 1, 2, 3, ... — чередуется после setup) */
    uhci_td_t *td_data_first = NULL, *td_data_last = NULL;
    /* TD_last: STATUS (zero-length, toggle=1) */
    uhci_td_t *td_status = td_alloc();

    if (!td_setup || !td_status) {
        td_free(td_setup); td_free(td_status); return -1;
    }

    /* Setup TD */
    td_setup->ctrl_status = TD_CTRL_SETUP;
    if (low_speed) td_setup->ctrl_status |= TD_CTRL_LS;
    td_setup->token = uhci_make_token(PID_SETUP, addr, 0, 0, 8);
    td_setup->buffer = (u32)(unsigned long)setup_buf;

    /* Цепочка: setup -> data_first -> ... -> data_last -> status -> terminate */
    int toggle = 1;     /* после SETUP data-toggle=1 */
    u8 *p = (u8 *)data_buf;
    int left = data_len;
    while (left > 0) {
        int chunk = left > 64 ? 64 : left;
        uhci_td_t *td = td_alloc();
        if (!td) { td_free(td_setup); td_free(td_status); return -1; }
        td->ctrl_status = TD_CTRL_DATA;
        if (low_speed) td->ctrl_status |= TD_CTRL_LS;
        td->token = uhci_make_token(data_in ? PID_IN : PID_OUT, addr, 0, toggle, chunk);
        td->buffer = (u32)(unsigned long)p;
        /* link to next */
        if (!td_data_first) td_data_first = td;
        else td_data_last->link = td_phys(td) & ~0xFu;
        td_data_last = td;
        toggle ^= 1;
        p += chunk;
        left -= chunk;
    }

    /* Status TD (zero-length, opposite direction).
     * В UHCI zero-length = 0x7FF в поле length (bits 30..21). */
    td_status->ctrl_status = TD_CTRL_STATUS;
    if (low_speed) td_status->ctrl_status |= TD_CTRL_LS;
    {
        u32 pid = data_in ? PID_OUT : PID_IN;
        td_status->token = ((u32)pid) |
                          ((u32)addr << 8) |
                          ((u32)1 << 19) |     /* toggle = 1 (after SETUP+DATA) */
                          (0x7FFu << 21);       /* zero-length */
    }
    td_status->buffer = 0;

    /* Цепочка TD: setup -> data... -> status -> terminate */
    if (td_data_first) {
        td_setup->link = td_phys(td_data_first) & ~0xFu;
        td_data_last->link = td_phys(td_status) & ~0xFu;
    } else {
        td_setup->link = td_phys(td_status) & ~0xFu;
    }
    td_status->link = 0x00000001u;     /* terminate */

    /* Записываем setup_td в frame list на следующие 16 кадров (16ms).
     * ВАЖНО: после записи нужна задержка (минимум 1ms), чтобы HC гарантированно
     * прочитал нашу запись. Без задержки иногда HC не подхватывает TD. */
    u32 frame = (u32)uhci_in(uhci_ctrl.iobase, UHCI_FRNUM) & 0x3FFu;
    u32 saved_entries[16];
    for (int i = 0; i < 16; i++) {
        u32 fr = (frame + i) & 0x3FFu;
        saved_entries[i] = uhci_ctrl.frame_list[fr];
        uhci_ctrl.frame_list[fr] = (td_phys(td_setup) & ~0xFu);
    }
    /* Дать HC время обработать хотя бы один кадр (1ms). */
    for (volatile int i = 0; i < 50000; i++) { }

    /* Ждём завершения SETUP (timeout ~50ms) */
    int r = uhci_wait_td(td_setup, 50000);
    if (r < 0) {
        for (int i = 0; i < 16; i++) {
            u32 fr = (frame + i) & 0x3FFu;
            uhci_ctrl.frame_list[fr] = saved_entries[i];
        }
        td_free(td_setup); td_free(td_status);
        for (uhci_td_t *t = td_data_first; t; ) {
            uhci_td_t *next = (uhci_td_t *)(unsigned long)t->next_td;
            td_free(t); t = next;
        }
        return -1;
    }

    /* Ждём data TD'и */
    for (uhci_td_t *t = td_data_first; t; t = (uhci_td_t *)(unsigned long)t->next_td) {
        int rr = uhci_wait_td(t, 50000);
        if (rr < 0) {
            for (int i = 0; i < 16; i++) {
                u32 fr = (frame + i) & 0x3FFu;
                uhci_ctrl.frame_list[fr] = saved_entries[i];
            }
            td_free(td_setup); td_free(td_status);
            for (uhci_td_t *t2 = td_data_first; t2; ) {
                uhci_td_t *next = (uhci_td_t *)(unsigned long)t2->next_td;
                td_free(t2); t2 = next;
            }
            return -1;
        }
    }

    /* Ждём STATUS */
    int rs = uhci_wait_td(td_status, 50000);
    (void)rs;

    /* Восстановим старые записи frame list */
    for (int i = 0; i < 16; i++) {
        u32 fr = (frame + i) & 0x3FFu;
        uhci_ctrl.frame_list[fr] = saved_entries[i];
    }

    int result = data_len;
    td_free(td_setup); td_free(td_status);
    for (uhci_td_t *t = td_data_first; t; ) {
        uhci_td_t *next = (uhci_td_t *)(unsigned long)t->next_td;
        td_free(t); t = next;
    }
    return result;
}

/* ---------- стандартные запросы USB ---------- */

static int usb_get_descriptor(int addr, int low_speed, u8 type, u8 idx,
                               void *buf, int len)
{
    usb_request_t req;
    req.bmRequestType = 0x80;     /* IN, Standard, Device */
    req.bRequest = 6;             /* GET_DESCRIPTOR */
    req.wValue = (u16)((type << 8) | idx);
    req.wIndex = 0;
    req.wLength = (u16)len;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, buf, len, 1, 0);
}

static int usb_set_address(int low_speed, u8 new_addr)
{
    usb_request_t req;
    req.bmRequestType = 0x00;     /* OUT, Standard, Device */
    req.bRequest = 5;             /* SET_ADDRESS */
    req.wValue = new_addr;
    req.wIndex = 0;
    req.wLength = 0;
    return uhci_run_transfer(0, low_speed, (u8 *)&req, 0, 0, 0, 0);
}

static int usb_set_configuration(int addr, int low_speed, u8 config)
{
    usb_request_t req;
    req.bmRequestType = 0x00;     /* OUT, Standard, Device */
    req.bRequest = 9;             /* SET_CONFIGURATION */
    req.wValue = config;
    req.wIndex = 0;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 0);
}

static int usb_set_idle(int addr, int low_speed, int ifc)
{
    usb_request_t req;
    req.bmRequestType = 0x21;     /* OUT, Class, Interface */
    req.bRequest = 0x0A;          /* SET_IDLE (HID class) */
    req.wValue = 0;
    req.wIndex = (u16)ifc;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 0);
}

static int usb_set_protocol_boot(int addr, int low_speed, int ifc)
{
    usb_request_t req;
    req.bmRequestType = 0x21;
    req.bRequest = 0x0B;          /* SET_PROTOCOL (HID class) */
    req.wValue = 0;               /* 0 = Boot Protocol */
    req.wIndex = (u16)ifc;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 0);
}

/* ---------- поддержка USB-хабов ---------- */

/* Forward declaration — parse_config_descriptor определена ниже. */
static void parse_config_descriptor(u8 *buf, int len, usb_dev_t *d);

/* Hub class requests (USB 2.0 spec section 11.24). */
#define HUB_GET_DESCRIPTOR  0x06   /* bRequest for GetDescriptor */
#define HUB_SET_FEATURE     0x03
#define HUB_CLEAR_FEATURE   0x01
#define HUB_GET_STATUS      0x00

#define HUB_FEATURE_PORT_RESET         4
#define HUB_FEATURE_PORT_POWER         8
#define HUB_FEATURE_C_PORT_CONNECT    16
#define HUB_FEATURE_C_PORT_RESET      20
#define HUB_FEATURE_C_PORT_ENABLE     17

static int usb_hub_get_descriptor(int addr, int low_speed, u8 *buf, int len)
{
    usb_request_t req;
    req.bmRequestType = 0xA0;     /* IN, Class, Device */
    req.bRequest = HUB_GET_DESCRIPTOR;
    req.wValue = 0x2900;          /* descriptor type 0x29 = hub */
    req.wIndex = 0;
    req.wLength = (u16)len;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, buf, len, 1, 0);
}

static int usb_hub_set_port_feature(int addr, int low_speed, int port, int feature)
{
    usb_request_t req;
    req.bmRequestType = 0x23;     /* OUT, Class, Other (port) */
    req.bRequest = HUB_SET_FEATURE;
    req.wValue = (u16)feature;
    req.wIndex = (u16)port;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 0);
}

static int usb_hub_clear_port_feature(int addr, int low_speed, int port, int feature)
{
    usb_request_t req;
    req.bmRequestType = 0x23;     /* OUT, Class, Other (port) */
    req.bRequest = HUB_CLEAR_FEATURE;
    req.wValue = (u16)feature;
    req.wIndex = (u16)port;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 0);
}

static int usb_hub_get_port_status(int addr, int low_speed, int port, u32 *status)
{
    usb_request_t req;
    u8 buf[4];
    req.bmRequestType = 0xA3;     /* IN, Class, Other (port) */
    req.bRequest = HUB_GET_STATUS;
    req.wValue = 0;
    req.wIndex = (u16)port;
    req.wLength = 4;
    int r = uhci_run_transfer(addr, low_speed, (u8 *)&req, buf, 4, 1, 0);
    if (r >= 4) {
        *status = (u32)buf[0] | ((u32)buf[1] << 8) |
                  ((u32)buf[2] << 16) | ((u32)buf[3] << 24);
        return 1;
    }
    return 0;
}

/* Перечислить устройства на портах USB-хаба.
 * hub_addr — USB-адрес хаба (уже присвоен после SetAddress).
 * hub_low_speed — 1 если хаб low-speed (обычно full-speed). */
static void enumerate_hub(int hub_addr, int hub_low_speed)
{
    if (!uhci_ctrl.valid) return;

    /* Читаем hub descriptor */
    u8 hdbuf[16];
    memset(hdbuf, 0, sizeof(hdbuf));
    int r = usb_hub_get_descriptor(hub_addr, hub_low_speed, hdbuf, sizeof(hdbuf));
    if (r < 7) {
        serial_puts("[usb-hub] get_descriptor failed\n");
        return;
    }
    int nbr_ports = hdbuf[2];     /* bNbrPorts */
    char buf[80];
    snprintf(buf, sizeof(buf), "[usb-hub] hub @ addr %d: %d ports\n",
             hub_addr, nbr_ports);
    serial_puts(buf);

    /* Включаем питание на всех портах хаба */
    for (int p = 1; p <= nbr_ports; p++) {
        usb_hub_set_port_feature(hub_addr, hub_low_speed, p, HUB_FEATURE_PORT_POWER);
    }
    /* Ждём стабилизации питания */
    for (volatile int i = 0; i < 100000; i++) { }

    /* Перечисляем каждый порт */
    for (int p = 1; p <= nbr_ports; p++) {
        /* Проверим статус порта */
        u32 port_status = 0;
        if (!usb_hub_get_port_status(hub_addr, hub_low_speed, p, &port_status)) {
            continue;
        }
        /* bit 0 = Current Connect Status (1 = device connected) */
        if (!(port_status & 0x01)) continue;

        /* Устройство подключено — сброс порта */
        usb_hub_set_port_feature(hub_addr, hub_low_speed, p, HUB_FEATURE_PORT_RESET);
        for (volatile int i = 0; i < 500000; i++) { }    /* ~50ms */
        usb_hub_clear_port_feature(hub_addr, hub_low_speed, p, HUB_FEATURE_C_PORT_RESET);
        for (volatile int i = 0; i < 50000; i++) { }    /* ~5ms */

        /* Проверим скорость: bit 10 = low-speed (0=full, 1=low) */
        int dev_low_speed = (port_status & (1 << 9)) ? 1 : 0;

        snprintf(buf, sizeof(buf),
                 "[usb-hub] port %d: device present (%s-speed)\n",
                 p, dev_low_speed ? "low" : "full");
        serial_puts(buf);

        /* Стандартное перечисление устройства (по тому же шаблону,
         * что и в enumerate_ports(), но устройство — за хабом).
         * Устройство сейчас на addr 0 (после сброса порта). */
        u8 devbuf[64];
        memset(devbuf, 0, sizeof(devbuf));
        r = usb_get_descriptor(0, dev_low_speed, 1, 0, devbuf, 8);
        if (r < 8) {
            serial_puts("[usb-hub] get_descriptor(8) failed\n");
            continue;
        }
        int max_pkt0 = devbuf[7];

        /* Назначаем новый адрес */
        static int hub_next_addr = 20;     /* начинаем с 20 для hub-устройств */
        if (usb_set_address(dev_low_speed, (u8)hub_next_addr) < 0) {
            serial_puts("[usb-hub] set_address failed\n");
            continue;
        }
        int addr = hub_next_addr++;
        for (volatile int i = 0; i < 50000; i++) { }

        r = usb_get_descriptor(addr, dev_low_speed, 1, 0, devbuf, 18);
        if (r < 18) continue;

        u8 cfgbuf[256];
        r = usb_get_descriptor(addr, dev_low_speed, 2, 0, cfgbuf, 9);
        if (r < 9) continue;
        int cfg_total = cfgbuf[2] | (cfgbuf[3] << 8);
        if (cfg_total > 200) cfg_total = 200;
        usb_get_descriptor(addr, dev_low_speed, 2, 0, cfgbuf, cfg_total);
        usb_set_configuration(addr, dev_low_speed, 1);

        if (usb_dev_count < USB_MAX_DEVICES) {
            usb_dev_t *d = &usb_devices[usb_dev_count];
            memset(d, 0, sizeof(*d));
            d->valid = 1;
            d->addr = addr;
            d->low_speed = dev_low_speed;
            d->ep_in = 1;
            d->ep_size = max_pkt0;
            d->ep_toggle = 0;
            d->kind = DEV_NONE;
            d->has_report = 0;
            d->intr_buf = NULL;

            parse_config_descriptor(cfgbuf, cfg_total, d);

            if (d->kind != DEV_NONE) {
                usb_set_idle(addr, dev_low_speed, 0);
                usb_set_protocol_boot(addr, dev_low_speed, 0);
                d->intr_buf = (u8 *)malloc(d->ep_size + 8);
                if (d->intr_buf) memset(d->intr_buf, 0, d->ep_size + 8);
                char kbuf[80];
                snprintf(kbuf, sizeof(kbuf),
                         "[usb-hub] HID device @ addr %d: %s, EP%d(%d bytes)\n",
                         addr, d->kind == DEV_KEYBOARD ? "keyboard" : "mouse",
                         d->ep_in, d->ep_size);
                serial_puts(kbuf);
            } else {
                char kbuf[80];
                snprintf(kbuf, sizeof(kbuf),
                         "[usb-hub] device @ addr %d (class=%d)\n",
                         addr, devbuf[4]);
                serial_puts(kbuf);
            }
            usb_dev_count++;
        }
    }
}

/* ---------- перечисление ---------- */

/* Перебираем конфигурацию и находим HID interface (class 3) + interrupt EP. */
static void parse_config_descriptor(u8 *buf, int len, usb_dev_t *d)
{
    int i = 0;
    int cur_iface = -1;
    u8 ep_addr = 0; u8 ep_attr = 0; u16 ep_size = 0; u8 ep_int = 0;
    u8 iface_class = 0, iface_subclass = 0, iface_proto = 0;
    while (i + 2 <= len) {
        u8 dlen = buf[i];
        u8 dtyp = buf[i + 1];
        if (dlen == 0) break;
        if (dtyp == 4 && i + 9 <= len) {     /* INTERFACE */
            cur_iface = buf[i + 2];
            iface_class = buf[i + 5];
            iface_subclass = buf[i + 6];
            iface_proto = buf[i + 7];
        }
        else if (dtyp == 5 && i + 7 <= len) {  /* ENDPOINT */
            ep_addr = buf[i + 2];
            ep_attr = buf[i + 3];
            ep_size = (u16)(buf[i + 4] | (buf[i + 5] << 8));
            ep_int  = buf[i + 6];
            /* Если interrupt IN endpoint на текущем HID-интерфейсе — запомним */
            if ((ep_attr & 0x03) == 0x03 && (ep_addr & 0x80) && cur_iface >= 0 &&
                iface_class == 3 && iface_subclass == 1) {
                d->ep_in = ep_addr & 0x0F;
                d->ep_size = ep_size;
                /* Определяем тип по протоколу */
                if (iface_proto == 1) d->kind = DEV_KEYBOARD;
                else if (iface_proto == 2) d->kind = DEV_MOUSE;
            }
        }
        i += dlen;
    }
}

static void enumerate_ports(void)
{
    if (!uhci_ctrl.valid) return;
    u16 iobase = uhci_ctrl.iobase;

    int next_addr = 1;
    for (int port = 0; port < 2; port++) {
        u16 ps = uhci_in(iobase, UHCI_PORTSC1 + port * 2);
        if (!(ps & PORTSC_CONNECT)) continue;

        if (!port_reset(iobase, port)) continue;

        ps = uhci_in(iobase, UHCI_PORTSC1 + port * 2);
        int low_speed = (ps & PORTSC_LOWSPEED) ? 1 : 0;

        char buf2[80];
        snprintf(buf2, sizeof(buf2),
                 "[usb] port %d: device present (%s-speed)\n",
                 port + 1, low_speed ? "low" : "full");
        serial_puts(buf2);

        /* Шаг 1: GetDescriptor(Device, 8 байт) @ addr 0 */
        u8 devbuf[64];
        memset(devbuf, 0, sizeof(devbuf));
        int r = usb_get_descriptor(0, low_speed, 1, 0, devbuf, 8);
        if (r < 8) {
            serial_puts("[usb] get_descriptor(8) failed\n");
            continue;
        }
        int max_pkt0 = devbuf[7];   /* bMaxPacketSize0 */

        /* Шаг 2: SetAddress (assign new_addr) */
        if (usb_set_address(low_speed, (u8)next_addr) < 0) {
            serial_puts("[usb] set_address failed\n");
            continue;
        }
        int addr = next_addr++;
        for (volatile int i = 0; i < 20000; i++) { }   /* 2ms settling */

        /* Шаг 3: GetDescriptor(Device, 18 байт) @ addr */
        r = usb_get_descriptor(addr, low_speed, 1, 0, devbuf, 18);
        if (r < 18) {
            serial_puts("[usb] get_descriptor(18) failed\n");
            continue;
        }

        /* Шаг 4: GetDescriptor(Config, 9 байт сначала) */
        u8 cfgbuf[256];
        r = usb_get_descriptor(addr, low_speed, 2, 0, cfgbuf, 9);
        if (r < 9) {
            serial_puts("[usb] get_descriptor(cfg) failed\n");
            continue;
        }
        int cfg_total = cfgbuf[2] | (cfgbuf[3] << 8);
        if (cfg_total > 200) cfg_total = 200;

        /* Шаг 5: GetDescriptor(Config, full length) */
        r = usb_get_descriptor(addr, low_speed, 2, 0, cfgbuf, cfg_total);
        if (r < cfg_total) {
            /* Продолжим даже если мало — что есть */
        }

        /* Шаг 6: SetConfiguration(1) */
        usb_set_configuration(addr, low_speed, 1);

        /* Заполняем устройство и пытаемся найти HID */
        if (usb_dev_count < USB_MAX_DEVICES) {
            usb_dev_t *d = &usb_devices[usb_dev_count];
            memset(d, 0, sizeof(*d));
            d->valid = 1;
            d->addr = addr;
            d->low_speed = low_speed;
            d->ep_in = 1;
            d->ep_size = max_pkt0;
            d->ep_toggle = 0;
            d->kind = DEV_NONE;
            d->has_report = 0;
            d->intr_td = NULL;
            d->intr_buf = NULL;

            parse_config_descriptor(cfgbuf, cfg_total, d);

            /* Если это HID — установим idle + boot protocol */
            if (d->kind != DEV_NONE) {
                usb_set_idle(addr, low_speed, 0);
                usb_set_protocol_boot(addr, low_speed, 0);
                /* Выделим буфер под interrupt-данные */
                d->intr_buf = (u8 *)malloc(d->ep_size + 8);
                if (d->intr_buf) {
                    memset(d->intr_buf, 0, d->ep_size + 8);
                }
                char kbuf[80];
                snprintf(kbuf, sizeof(kbuf), "[usb] HID device @ addr %d: %s, EP%d(%d bytes)\n",
                         addr, d->kind == DEV_KEYBOARD ? "keyboard" : "mouse",
                         d->ep_in, d->ep_size);
                serial_puts(kbuf);
            } else {
                char kbuf[80];
                snprintf(kbuf, sizeof(kbuf), "[usb] device @ addr %d (class=%d)\n",
                         addr, devbuf[4]);
                serial_puts(kbuf);

                /* Если это хаб (class=9) — перечислим его порты */
                if (devbuf[4] == 9) {
                    serial_puts("[usb] hub detected, enumerating ports...\n");
                    enumerate_hub(addr, low_speed);
                }
            }
            usb_dev_count++;
        }
    }
}

/* ---------- опрос HID ---------- */

/* Прочитать interrupt-отчёт через простой TD. */
static int usb_poll_interrupt(usb_dev_t *d)
{
    if (!d->intr_buf) return 0;

    uhci_td_t *td = td_alloc();
    if (!td) return 0;

    td->ctrl_status = TD_CTRL_DATA;
    if (d->low_speed) td->ctrl_status |= TD_CTRL_LS;
    td->token = uhci_make_token(PID_IN, d->addr, d->ep_in, d->ep_toggle, d->ep_size);
    td->buffer = (u32)(unsigned long)d->intr_buf;
    td->link = 0x00000001u;     /* terminate */

    /* Записываем в 8 последовательных кадров (8ms) — даём HC достаточно
     * времени, чтобы опросить устройство. */
    u32 frame = (u32)uhci_in(uhci_ctrl.iobase, UHCI_FRNUM) & 0x3FFu;
    u32 saved[8];
    for (int i = 0; i < 8; i++) {
        u32 fr = (frame + i) & 0x3FFu;
        saved[i] = uhci_ctrl.frame_list[fr];
        uhci_ctrl.frame_list[fr] = (td_phys(td) & ~0xFu);
    }
    /* Задержка — дать HC время обработать хотя бы один кадр (~1ms). */
    for (volatile int i = 0; i < 50000; i++) { }

    int r = uhci_wait_td(td, 10000);   /* ~10ms timeout */
    for (int i = 0; i < 8; i++) {
        u32 fr = (frame + i) & 0x3FFu;
        uhci_ctrl.frame_list[fr] = saved[i];
    }

    int result = -1;
    if (r >= 0) {
        /* Успешно получили данные */
        d->ep_toggle ^= 1;
        result = r;
    }

    td_free(td);
    return result;
}

/* Распарсить 8-байтный отчёт USB-клавиатуры (boot-протокол):
 *   byte 0: modifiers (Ctrl/Shift/Alt/etc.)
 *   byte 1: reserved
 *   bytes 2..7: pressed key codes (HID usage table)
 * Преобразуем HID usage в ASCII/PS2 scan-code и складываем в kbd ring. */
static void dispatch_keyboard(usb_dev_t *d, u8 *report)
{
    /* Дедупликация: если отчёт идентичен предыдущему — пропускаем */
    if (d->has_report && memcmp(d->last_report, report, 8) == 0) return;
    /* Найдём новые нажатые клавиши (есть в новом, нет в старом) */
    for (int i = 2; i < 8; i++) {
        u8 code = report[i];
        if (code == 0) continue;
        /* Пропускаем, если уже была нажата */
        int already = 0;
        if (d->has_report) {
            for (int j = 2; j < 8; j++) {
                if (d->last_report[j] == code) { already = 1; break; }
            }
        }
        if (already) continue;
        /* HID usage → простейший ASCII (US раскладка) */
        /* 0x04..0x1D = a..z; 0x1E..0x27 = 1..0 */
        u8 ch = 0, scancode = 0;
        if (code >= 0x04 && code <= 0x1D) {
            ch = (u8)('a' + (code - 0x04));
            scancode = (u8)(code - 0x04 + 0x1E);
        } else if (code >= 0x1E && code <= 0x27) {
            ch = (u8)('1' + (code - 0x1E));
            if (code == 0x27) ch = '0';
            scancode = (u8)(code - 0x1E + 0x02);
        } else if (code == 0x28) { ch = '\n'; scancode = 0x1C; }
        else if (code == 0x29) { ch = 0; scancode = 0x01; }     /* Esc */
        else if (code == 0x2A) { ch = '\b'; scancode = 0x0E; }
        else if (code == 0x2B) { ch = '\t'; scancode = 0x0F; }
        else if (code == 0x2C) { ch = ' '; scancode = 0x39; }
        /* Модификаторы (byte 0): Shift=0x22, Ctrl=0x11, Alt=0x44 */
        u8 mod = report[0];
        u8 flags = 0;
        if (mod & 0x22) flags |= 0x02;     /* Shift */
        if (mod & 0x11) flags |= 0x04;     /* Ctrl */
        if (mod & 0x44) flags |= 0x08;     /* Alt */
        if (ch >= 'a' && ch <= 'z' && (flags & 0x02)) ch = (u8)(ch - 'a' + 'A');
        (void)scancode;

        /* Пушим в kbd ring через публичный API */
        kbd_push_event(scancode, (char)ch, flags);
    }
    memcpy(d->last_report, report, 8);
    d->has_report = 1;
}

/* Распарсить 4-байтный отчёт USB-мыши (boot-протокол):
 *   byte 0: buttons (bit 0=left, 1=right, 2=middle)
 *   bytes 1, 2: dx, dy (signed 8-bit)
 *   byte 3: wheel */
static void dispatch_mouse(usb_dev_t *d, u8 *report)
{
    extern volatile int ms_x, ms_y, ms_event;
    extern volatile u8  ms_buttons;
    int dx = (int)(i8)report[1];
    int dy = (int)(i8)report[2];
    int nx = ms_x + dx;
    int ny = ms_y - dy;     /* PS/2: плюс по Y = вверх */
    if (nx < 0) nx = 0;
    if (ny < 0) ny = 0;
    if (nx > (int)fb_width() - 1) nx = (int)fb_width() - 1;
    if (ny > (int)fb_height() - 1) ny = (int)fb_height() - 1;
    ms_x = nx;
    ms_y = ny;
    ms_buttons = (u8)(report[0] & 0x07);
    ms_event = 1;
    (void)d;
}

void usb_poll(void)
{
    if (!uhci_ctrl.valid) return;
    for (int i = 0; i < usb_dev_count; i++) {
        usb_dev_t *d = &usb_devices[i];
        if (!d->valid || d->kind == DEV_NONE) continue;
        if (!d->intr_buf) continue;
        /* Делаем один interrupt-запрос; при успехе — диспатачим */
        int n = usb_poll_interrupt(d);
        if (n > 0) {
            if (d->kind == DEV_KEYBOARD) dispatch_keyboard(d, d->intr_buf);
            else if (d->kind == DEV_MOUSE) dispatch_mouse(d, d->intr_buf);
        }
    }
}

/* ---------- API ---------- */

int usb_keyboard_present(void)
{
    for (int i = 0; i < usb_dev_count; i++) {
        if (usb_devices[i].valid && usb_devices[i].kind == DEV_KEYBOARD) return 1;
    }
    return 0;
}

int usb_mouse_present(void)
{
    for (int i = 0; i < usb_dev_count; i++) {
        if (usb_devices[i].valid && usb_devices[i].kind == DEV_MOUSE) return 1;
    }
    return 0;
}

int usb_controllers_found(void)
{
    return uhci_ctrl.valid ? 1 : 0;
}

int usb_devices_found(void)
{
    return usb_dev_count;
}

/* ---------- EHCI-детекция перенесена в usb_ehci.c ---------- */

void usb_init(void)
{
    usb_dev_count = 0;
    memset(usb_devices, 0, sizeof(usb_devices));
    memset(td_used, 0, sizeof(td_used));
    memset(&uhci_ctrl, 0, sizeof(uhci_ctrl));

    serial_puts("[usb] init...\n");
    uhci_scan_pci();
    if (uhci_ctrl.valid) {
        enumerate_ports();
        if (usb_dev_count > 0) {
            char buf[80];
            snprintf(buf, sizeof(buf), "[usb] %d device(s) found\n", usb_dev_count);
            serial_puts(buf);
        }
    }
    /* Инициализируем EHCI (полноценный драйвер с bulk-трансферами). */
    usb_ehci_init();
}
