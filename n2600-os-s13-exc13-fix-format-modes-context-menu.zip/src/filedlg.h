/* filedlg.h — стандартные диалоги открытия и сохранения файлов N2600-OS.
 *
 * Общие диалоги в стиле «классического» файлового диалога: панель источников
 * (RAM disk / HDD / USB), навигация по каталогам FAT32, список файлов с
 * фильтром расширений, поле ввода имени, кнопки. Диалог открытия умеет
 * читать со всех смонтированных источников; диалог сохранения работает
 * с RAM disk — единственной перезаписываемой ФС (FAT32/ISO доступны
 * только для чтения), с подтверждением перезаписи.
 *
 * Диалоги асинхронны (event-driven, как весь WM): результат доставляется
 * колбэком. Пока диалог открыт, вызывающему окну следует игнорировать
 * ввод — проверяйте свой флаг «диалог открыт» (см. apps_editor.c).
 *
 * Буфер content в on_open_ok передаётся во владение вызывающему —
 * он обязан free() его после использования.
 *
 * Пример:
 *   static void my_open_ok(void *ctx, const fd_pick_t *pick,
 *                          char *content, int len) {
 *       my_app_t *a = (my_app_t *)ctx;
 *       ... скопировать content в буфер приложения ...
 *       free(content);
 *       a->dlg = 0;              \* диалог закрылся, ввод снова активен *\
 *   }
 *   static void my_cancel(void *ctx) {
 *       my_app_t *a = (my_app_t *)ctx;
 *       a->dlg = 0;
 *   }
 *   ...
 *   a->dlg = 1;
 *   filedlg_open("Открыть файл", ".c,.cs,.txt", NULL,
 *                my_open_ok, my_cancel, a);
 */
#ifndef FILEDLG_H
#define FILEDLG_H

#include "types.h"

/* Источники файлов для диалога открытия. */
typedef enum {
    FD_SRC_RAMFS = 0,   /* RAM disk (перезаписываемый)   */
    FD_SRC_ATA    = 1,  /* HDD: FAT32 через ATA (чтение) */
    FD_SRC_USB    = 2   /* USB-флешка: FAT32 (чтение)    */
} fd_source_t;

#define FD_NAME_MAX 64        /* как RAMFS_NAME_MAX */

/* Результат выбора файла в диалоге открытия. */
typedef struct {
    fd_source_t source;          /* источник, из которого прочитан файл */
    char        name[FD_NAME_MAX + 1];   /* имя файла (без пути) */
    char        path[200];       /* полный путь (FAT32) или имя (RAMFS) */
} fd_pick_t;

/* Диалог открытия файла.
 *   title       — заголовок окна;
 *   filter      — список расширений через запятую, напр. ".c,.cs,.txt";
 *                 каталоги показываются всегда; "*" или NULL — все файлы;
 *   default_name— имя, подставляемое в поле ввода (NULL = пустое);
 *   on_open_ok  — вызывается, когда файл прочитан: pick — откуда и что,
 *                 content — содержимое (malloc, до FD_READ_MAX байт),
 *                 владение буфером переходит к вызывающему (он free()ит);
 *   on_cancel   — вызывается при Esc/«Отмена»/закрытии окна диалога
 *                 (может быть NULL);
 *   ctx         — указатель, транслируемый в колбэки (обычно состояние app).
 * Диалог закрывается сам; повторный вызов из on_* допустим. */
void filedlg_open(const char *title, const char *filter, const char *default_name,
                  void (*on_open_ok)(void *ctx, const fd_pick_t *pick,
                                     char *content, int len),
                  void (*on_cancel)(void *ctx),
                  void *ctx);

/* Диалог сохранения файла (в RAM disk — единственная перезаписываемая ФС).
 *   title        — заголовок окна;
 *   default_name — имя, подставляемое в поле ввода (NULL = пустое);
 *   on_save_ok   — вызывается после подтверждения (в т.ч. перезаписи):
 *                  name — выбранное имя файла в RAMFS;
 *   on_cancel    — Esc/«Отмена»/закрытие (может быть NULL);
 *   ctx          — контекст для колбэков.
 * Подтверждение перезаписи встроено: первое нажатие «Сохранить» по
 * существующему файлу запрашивает подтверждение, второе — выполняет. */
void filedlg_save(const char *title, const char *default_name,
                  void (*on_save_ok)(void *ctx, const char *name),
                  void (*on_cancel)(void *ctx),
                  void *ctx);

/* Лимит чтения файла в диалоге открытия. */
#define FD_READ_MAX 65536

#endif /* FILEDLG_H */

/* ================= диалог ввода имени (сессия 13) =================
 * Переиспользуемый модальный ввод одной строки (имя папки/файла).
 * Как и все диалоги — асинхронный: результат приходит в колбэк окну-
 * вызывающему; окну-владельцу следует игнорировать ввод, пока открыт
 * (флаг dlg у приложения). Enter — OK, Esc — отмена, клик по кнопкам. */
typedef void (*fd_input_ok_fn)(void *ctx, const char *name);
typedef void (*fd_input_cancel_fn)(void *ctx);

/* title — заголовок окна; prompt — подсказка (над полем); defname —
 * значение по умолчанию (может быть NULL); maxlen — лимит ввода. */
void filedlg_input_open(const char *title, const char *prompt,
                         const char *defname, int maxlen,
                         fd_input_ok_fn ok, fd_input_cancel_fn cancel,
                         void *ctx);
