/* htmlconv.c — HTML -> Markdown конвертер (упрощённый) для N2600-OS.
 *
 * Поддерживаемые теги:
 *   <h1>-<h6>      -> # ## ### #### ##### (+ пробел)
 *   <p>            -> пустая строка
 *   <br>           -> \n
 *   <hr>           -> ---
 *   <b>/<strong>   -> **      </b>/<strong> -> **
 *   <i>/<em>       -> *       </i>/<em>     -> *
 *   <code>         -> `       </code>       -> `
 *   <pre>          -> ``` \n  </pre>        -> ``` \n
 *   <ul>/<ol>      -> \n      </ul>/</ol>   -> \n (выход из списка)
 *   <li>           -> - (с новой строки)
 *   <a ...>        -> [       </a>          -> ]()
 *   <script>/<style> и их содержимое — пропускаются целиком
 *   прочие теги — удаляются, содержимое сохраняется
 *
 * Entities: &amp; &lt; &gt; &quot; &nbsp; &#39; — включая случаи,
 * когда entity стоит в самом конце файла (см. FIX [H3]).
 *
 * История исправлений (аудит браузера):
 *   FIX [H1] БЕСКОНЕЧНЫЙ ЦИКЛ: переменная in_tag устанавливалась в 1
 *     при встрече '<', но никогда не сбрасывалась в 0. После обработки
 *     тега (i корректно сдвигался за '>') следующий символ текста
 *     попадал в «if (in_tag) continue;» — continue выполнялся БЕЗ
 *     инкремента i -> бесконечный цикл. Тег теперь потребляется целиком
 *     внутри одной ветки, отдельный флаг не нужен вовсе.
 *   FIX [H2] (в apps_browser.c) static буфер md[8192] заменён на
 *     буфер, принадлежащий вызову. Конвертер принимает md извне.
 *   FIX [H3] ГРАНИЦЫ ENTITIES: для &lt; (4 символа) проверялось
 *     «i+5 < html_len» — требовалось 6+ символов подряд, из-за чего
 *     entity в конце файла не распознавались и попадали в вывод как
 *     литеральный текст. Теперь условие — «осталось >= длины entity»
 *     (i + N <= html_len), что верно и в конце файла.
 *   FIX [H4] ЧТЕНИЕ ИМЕНИ ТЕГА: '/' в начале закрывающего тега (</a>)
 *     молча съедался, и закрывающий тег обрабатывался как открывающий
 *     (</a> давал '[', </pre> не закрывал ```-блок, </ul> не выходил из
 *     списка). Теперь '/' попадает в имя тега: «/a», «/pre», «/ul»
 *     приходят в свои ветки. Добавлены ветки /pre, /ul, /ol.
 */
#ifdef HOST_TEST
#include <string.h>   /* хостовой тест: стандартная библиотека */
#else
#include "string.h"   /* ядро: freestanding-версия (src/string.c) */
#include "types.h"
#endif

#include "htmlconv.h"

int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    int mi = 0;
    int i = 0;
    int pre_mode = 0;
    char tag[32];
    int tag_i;

    if (!html || !md || html_len <= 0 || md_max < 4) {
        if (md && md_max > 0) md[0] = 0;
        return 0;
    }

    while (i < html_len && mi < md_max - 2) {
        char c = html[i];

        if (c == '<') {
            tag_i = 0;
            i++;
            /* Читаем имя тега. FIX [H4]: '/' в начале — часть имени
             * закрывающего тега; '/' после имени и пробел — конец имени
             * (начало атрибутов, напр. <a href=...> или <br/>). */
            while (i < html_len && html[i] != '>' && tag_i < 31) {
                if (html[i] == ' ') break;
                if (html[i] == '/' && tag_i > 0) break;
                tag[tag_i++] = html[i++];
            }
            tag[tag_i] = 0;
            /* Пропускаем атрибуты до '>' */
            while (i < html_len && html[i] != '>') i++;
            if (i < html_len) i++;

            /* Обрабатываем тег */
            if (!strcmp(tag, "h1") || !strcmp(tag, "H1")) {
                md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "h2") || !strcmp(tag, "H2")) {
                md[mi++] = '#'; md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "h3") || !strcmp(tag, "H3")) {
                md[mi++] = '#'; md[mi++] = '#'; md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "h4") || !strcmp(tag, "H4")) {
                md[mi++] = '#'; md[mi++] = '#'; md[mi++] = '#';
                md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "p") || !strcmp(tag, "P")) {
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '\n';
            } else if (!strcmp(tag, "br") || !strcmp(tag, "BR") ||
                       !strcmp(tag, "br/") || !strcmp(tag, "br /")) {
                md[mi++] = '\n';
            } else if (!strcmp(tag, "hr") || !strcmp(tag, "HR")) {
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '-'; md[mi++] = '-'; md[mi++] = '-';
                md[mi++] = '\n';
            } else if (!strcmp(tag, "b") || !strcmp(tag, "B") ||
                       !strcmp(tag, "strong") || !strcmp(tag, "STRONG")) {
                md[mi++] = '*'; md[mi++] = '*';
            } else if (!strcmp(tag, "i") || !strcmp(tag, "I") ||
                       !strcmp(tag, "em") || !strcmp(tag, "EM")) {
                md[mi++] = '*';
            } else if (!strcmp(tag, "code") || !strcmp(tag, "CODE")) {
                md[mi++] = '`';
            } else if (!strcmp(tag, "pre") || !strcmp(tag, "PRE")) {
                pre_mode = 1;
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '`'; md[mi++] = '`'; md[mi++] = '`';
                md[mi++] = '\n';
            } else if (!strcmp(tag, "/pre") || !strcmp(tag, "/PRE")) {
                /* FIX [H4]: закрывающий </pre> раньше читался как «pre»
                 * и ПОВТОРНО открывал ```-блок. Теперь закрывает. */
                pre_mode = 0;
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '`'; md[mi++] = '`'; md[mi++] = '`';
                md[mi++] = '\n';
            } else if (!strcmp(tag, "ul") || !strcmp(tag, "UL") ||
                       !strcmp(tag, "ol") || !strcmp(tag, "OL")) {
                /* вход в список — с новой строки */
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
            } else if (!strcmp(tag, "/ul") || !strcmp(tag, "/UL") ||
                       !strcmp(tag, "/ol") || !strcmp(tag, "/OL")) {
                /* FIX [H4]: </ul> раньше читался как «ul» и не мог
                 * выключить список. Теперь закрывает. */
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
            } else if (!strcmp(tag, "li") || !strcmp(tag, "LI")) {
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '-'; md[mi++] = ' ';
            } else if (!strcmp(tag, "a") || !strcmp(tag, "A")) {
                md[mi++] = '[';
            } else if (!strcmp(tag, "/a") || !strcmp(tag, "/A")) {
                /* FIX [H4]: </a> раньше читался как «a» и выдавал '['
                 * вместо ']()'. */
                md[mi++] = ']';
                md[mi++] = '(';
                md[mi++] = ')'; /* URL из href не извлекаем — упрощение */
            }
            /* Закрывающие теги форматирования */
            else if (!strcmp(tag, "/b") || !strcmp(tag, "/B") ||
                     !strcmp(tag, "/strong") || !strcmp(tag, "/STRONG")) {
                md[mi++] = '*'; md[mi++] = '*';
            } else if (!strcmp(tag, "/i") || !strcmp(tag, "/I") ||
                       !strcmp(tag, "/em") || !strcmp(tag, "/EM")) {
                md[mi++] = '*';
            } else if (!strcmp(tag, "/code") || !strcmp(tag, "/CODE")) {
                md[mi++] = '`';
            }
            /* script/style — пропускаем содержимое до закрывающего тега */
            else if (!strcmp(tag, "script") || !strcmp(tag, "SCRIPT") ||
                     !strcmp(tag, "style") || !strcmp(tag, "STYLE")) {
                while (i < html_len) {
                    if (html[i] == '<' && i+1 < html_len &&
                        (html[i+1] == '/' || html[i+1] == 'S' || html[i+1] == 's')) {
                        /* Проверяем закрывающий тег */
                        int save_i = i;
                        int j = i + 1;
                        int t2 = 0;
                        while (j < html_len && html[j] != '>' && t2 < 31)
                            tag[t2++] = html[j++];
                        tag[t2] = 0;
                        if (j < html_len) j++;
                        if (tag[0] == '/') { i = j; break; }
                        i = save_i + 1;
                    } else i++;
                }
            }
            /* FIX [H1]: тег потреблён целиком, i стоит на первом символе
             * ПОСЛЕ '>'. Никакого флага in_tag не нужно: ветка '<'
             * всегда доводит i как минимум до позиции после '>'.
             * Прежний «if (in_tag) continue;» здесь выполнялся без
             * инкремента i и давал бесконечный цикл. */
            continue;
        }

        /* Преобразуем HTML entities.
         * FIX [H3]: условие — «остаток >= длина entity», т.е.
         * i + N <= html_len. Раньше стояло i+5 < html_len (нужно 6
         * символов подряд), из-за чего &lt;/&gt; в конце файла не
         * распознавались. */
        if (c == '&') {
            int rem = html_len - i;   /* сколько байт доступно */
            if (rem >= 5 && !strncmp(html+i, "&amp;", 5)) {
                md[mi++] = '&'; i += 5; continue;
            }
            if (rem >= 4 && !strncmp(html+i, "&lt;", 4)) {
                md[mi++] = '<'; i += 4; continue;
            }
            if (rem >= 4 && !strncmp(html+i, "&gt;", 4)) {
                md[mi++] = '>'; i += 4; continue;
            }
            if (rem >= 6 && !strncmp(html+i, "&quot;", 6)) {
                md[mi++] = '"'; i += 6; continue;
            }
            if (rem >= 6 && !strncmp(html+i, "&nbsp;", 6)) {
                md[mi++] = ' '; i += 6; continue;
            }
            if (rem >= 5 && !strncmp(html+i, "&#39;", 5)) {
                md[mi++] = '\''; i += 5; continue;
            }
        }

        /* В pre mode сохраняем всё как есть */
        if (pre_mode) {
            md[mi++] = c;
            i++;
            continue;
        }

        /* Сжимаем пробелы и переводы строк вне pre */
        if (c == '\n' || c == '\r') {
            if (mi > 0 && md[mi-1] != '\n' && md[mi-1] != ' ')
                md[mi++] = ' ';
            i++;
            continue;
        }
        if (c == '\t') {
            if (mi > 0 && md[mi-1] != ' ')
                md[mi++] = ' ';
            i++;
            continue;
        }
        if (c == ' ' && mi > 0 && md[mi-1] == ' ') {
            i++;
            continue;
        }

        md[mi++] = c;
        i++;
    }
    md[mi] = 0;
    return mi;
}
