/* apps_editor.c — текстовый редактор со встроенной компиляцией c4.
 *
 * Возможности:
 *   - редактирование многострочного текста (до EDIT_BUF_SIZE байт);
 *   - курсор и скроллинг по стрелкам/PgUp/PgDn/Home/End;
 *   - верхняя панель с НАЖИМАЕМЫМИ кнопками:
 *       [Save F2] [Load F4] [Run F9] [Close Esc]
 *     кликабельны мышью или горячими клавишами;
 *   - F2 — записать текст в RAMFS под именем из e->filename;
 *   - F4 — загрузить текст из RAMFS;
 *   - F9 — скомпилировать и запустить через c4.c; вывод открывается
 *           в отдельном окне «Вывод программы»;
 *   - Esc — закрыть редактор.
 *
 * Ключевая фишка — F9: текст из буфера передаётся в c4_run(), который
 * компилирует подмножество C в собственный байт-код и сразу исполняет
 * его виртуальной машиной c4. Вывод printf() программы попадает в окно.
 *
 * Файловый менеджер открывает .c-файлы в этом редакторе через
 * app_editor_open_with(name, buf, len) — функция ниже.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "c4.h"
#include "c4gfx.h"
#include "task.h"
#include "mouse.h"
#include "filedlg.h"

#define EDIT_BUF_SIZE   8192
#define EDIT_COLS       72
#define EDIT_ROWS       24
#define EDIT_HEADER_H   22      /* высота панели с кнопками (увеличили под кнопки) */

/* Геометрия кнопок верхней панели. */
#define BTN_COUNT 4
#define BTN_W     70
#define BTN_H     18
#define BTN_GAP   4
#define BTN_X0    4
#define BTN_Y0    2

typedef struct {
    char buf[EDIT_BUF_SIZE];
    int  len;
    int  cursor;          /* смещение курсора в буфере */
    int  top;             /* номер первой видимой строки */
    char filename[FD_NAME_MAX + 1];
    int  dirty;
    int  compiling;
    int  dlg;             /* 1 = открыт диалог открытия/сохранения (игнорировать ввод) */
    int  btn_hot;          /* индекс кнопки под курсором или -1 */
    int  btn_pressed;      /* индекс зажатой кнопки или -1 */
    char status[80];
} editor_t;

/* ---------- кнопки верхней панели ---------- */

typedef struct {
    const char *label;
    int  key_code;          /* скан-код (для F-клавиш) */
    char hot_key;           /* ASCII-клавиша (Esc = 0x1B) */
} editor_button_t;

static const editor_button_t editor_buttons[BTN_COUNT] = {
    { "Save F2",  0x3C, 0    },
    { "Load F4",  0x3E, 0    },
    { "Run F9",   0x43, 0    },
    { "Close Esc", 0,   0x1B },
};

static void ed_button_rect(int idx, int *bx, int *by, int *bw, int *bh)
{
    *bx = BTN_X0 + idx * (BTN_W + BTN_GAP);
    *by = BTN_Y0;
    *bw = BTN_W;
    *bh = BTN_H;
}

static int ed_button_at(editor_t *e, int mx, int my)
{
    (void)e;
    if (my < BTN_Y0 || my >= BTN_Y0 + BTN_H) return -1;
    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh;
        ed_button_rect(i, &bx, &by, &bw, &bh);
        if (mx >= bx && mx < bx + bw) return i;
    }
    return -1;
}

/* ---------- расчёт строк ---------- */

static int line_of(editor_t *e, int pos)
{
    int line = 0;
    for (int i = 0; i < pos && i < e->len; i++)
        if (e->buf[i] == '\n') line++;
    return line;
}

static int line_start(editor_t *e, int pos)
{
    int i = pos;
    while (i > 0 && e->buf[i - 1] != '\n') i--;
    return i;
}

static int line_end(editor_t *e, int pos)
{
    int i = pos;
    while (i < e->len && e->buf[i] != '\n') i++;
    return i;
}

/* ---------- окно вывода программы ---------- */

typedef struct {
    char *buf;
    u32   len;
    int   top;
} outwin_t;

static void outwin_draw(window_t *w)
{
    outwin_t *o = (outwin_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x0B, 0x0E, 0x11));

    int cols = cw / 8;
    int vis  = (ch - 4) / 16;
    if (cols < 1) cols = 1;

    int line = 0, i = 0;
    while (i < (int)o->len && line < o->top) {
        if (o->buf[i] == '\n') line++;
        i++;
    }
    int y = 2;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)o->len; r++) {
        int start = i, end = i;
        while (end < (int)o->len && o->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols)  len = cols;
        if (len > 254)   len = 254;
        memcpy(tmp, o->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xC6, 0xCD, 0xD5), -1);
        i = end + (end < (int)o->len ? 1 : 0);
        y += 16;
    }
    char st[64];
    snprintf(st, sizeof(st), "PgUp/PgDn, Esc — закрыть, %u байт", (unsigned)o->len);
    fb_text(4, ch - 14, st, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

static void outwin_key(window_t *w, const key_event_t *ev)
{
    outwin_t *o = (outwin_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == 0x49)   { o->top -= 8; if (o->top < 0) o->top = 0; win_invalidate(w); }
    else if (ev->code == 0x51) { o->top += 8; win_invalidate(w); }
    else if (ev->code == KBD_UP)   { if (o->top > 0) o->top--; win_invalidate(w); }
    else if (ev->code == KBD_DOWN) { o->top++; win_invalidate(w); }
    else if (ev->ch == 0x1B || ev->code == 0x01) win_close(w);
}

static void outwin_close(window_t *w)
{
    outwin_t *o = (outwin_t *)w->data;
    if (o) { if (o->buf) free(o->buf); free(o); }
}

/* Экспортируется (apps.h): окно вывода текста — используется и
 * редактором (F9), и loader'ом (нативные .bin через `run`). */
void app_outwin_open(const char *title, const char *text, u32 len)
{
    outwin_t *o = (outwin_t *)malloc(sizeof(outwin_t));
    if (!o) return;
    o->buf = (char *)malloc(len + 1);
    if (!o->buf) { free(o); return; }
    memcpy(o->buf, text, len);
    o->buf[len] = 0;
    o->len = len;
    o->top = 0;

    u32 W = fb_width(), H = fb_height();
    int ww = 600, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 90, 70, ww, wh, outwin_draw, outwin_key, NULL, NULL, outwin_close, o);
}

/* ---------- задача компиляции ---------- */

typedef struct {
    editor_t *ed;
    char     *out;
    u32       out_max;
    int       result;
} compile_ctx_t;

static void compile_task_fn(void *arg)
{
    compile_ctx_t *c = (compile_ctx_t *)arg;
    /* Сначала компилируем и сохраняем байт-код в .bin рядом с .c. */
    if (c->ed->filename[0]) {
        /* Если имя файла задано — компилируем в <basename>.bin */
        char bin_out[256];
        bin_out[0] = 0;
        int bin_r = c4_compile_to_file(c->ed->filename, c->ed->buf,
                                       bin_out, sizeof(bin_out));
        if (bin_r != 0 && bin_out[0]) {
            /* Сохраним ошибку компиляции как префикс вывода */
            char err[400];
            snprintf(err, sizeof(err), "[c4 compile-to-file error]\n%s\n",
                     bin_out);
            /* Дописываем в начало c->out (если есть место) */
            u32 el = (u32)strlen(err);
            if (el + 1 < c->out_max) {
                memmove(c->out + el, c->out, strlen(c->out) + 1);
                memcpy(c->out, err, el);
            }
        }
    }
    /* Затем компилируем и запускаем (как раньше). Окно графики (если
     * программа рисует) создаётся лениво в ЭТОЙ задаче; после
     * завершения canvas остаётся у окна — последний кадр виден. */
    c4_gfx_set_name(c->ed->filename[0] ? c->ed->filename : "prog.c");
    c->result = c4_run(c->ed->buf, c->out, c->out_max);
    c4_gfx_detach();
    /* Обновим статус в редакторе */
    if (c->result == 0) {
        snprintf(c->ed->status, sizeof(c->ed->status),
                 "OK: программа завершилась с кодом 0");
    } else {
        snprintf(c->ed->status, sizeof(c->ed->status),
                 "Ошибка: код %d (см. вывод)", c->result);
    }
    c->ed->compiling = 0;
    /* Откроем окно вывода */
    u32 out_len = (u32)strlen(c->out);
    app_outwin_open("Вывод программы", c->out, out_len);
    /* Освобождаем контекст (буфер out не освобождаем — он теперь в outwin) */
    free(c);
    task_exit();
}

/* ---------- редактор ---------- */

static void ed_status(editor_t *e, const char *msg)
{
    strncpy(e->status, msg, sizeof(e->status) - 1);
    e->status[sizeof(e->status) - 1] = 0;
}

/* ---------- сохранение (сейчас: в RAM disk) ---------- */

static void ed_save_to(editor_t *e, const char *name)
{
    if (!ramfs_ready()) {
        ed_status(e, "RAM disk недоступен");
        return;
    }
    if (!name || !name[0]) name = "prog.c";
    ramfs_delete(name);
    if (!ramfs_create(name, (u32)(e->len + 1))) {
        ed_status(e, "Не удалось создать файл (нет места?)");
        return;
    }
    if (!ramfs_write(name, e->buf, (u32)(e->len + 1))) {
        ed_status(e, "Ошибка записи");
        return;
    }
    strncpy(e->filename, name, sizeof(e->filename) - 1);
    e->filename[sizeof(e->filename) - 1] = 0;
    e->dirty = 0;
    char msg[96];
    snprintf(msg, sizeof(msg), "Сохранено: %s (%d байт)", e->filename, e->len);
    ed_status(e, msg);
}

/* Колбэки диалога сохранения. */
static void ed_dlg_save_ok(void *ctx, const char *name)
{
    editor_t *e = (editor_t *)ctx;
    e->dlg = 0;
    ed_save_to(e, name);
}

static void ed_dlg_cancel(void *ctx)
{
    editor_t *e = (editor_t *)ctx;
    e->dlg = 0;
    ed_status(e, "Отменено");
}

/* «Сохранить как...»: стандартный диалог. */
static void ed_save_as(editor_t *e)
{
    if (e->dlg) return;
    e->dlg = 1;
    ed_status(e, "Сохранение: выберите имя файла...");
    filedlg_save("Сохранить как", e->filename[0] ? e->filename : "prog.c",
                 ed_dlg_save_ok, ed_dlg_cancel, e);
}

/* Колбэк диалога открытия: подменить буфер содержимым файла. */
static void ed_dlg_open_ok(void *ctx, const fd_pick_t *pick,
                           char *content, int len)
{
    editor_t *e = (editor_t *)ctx;
    e->dlg = 0;
    if (!content || len <= 0) { ed_status(e, "Пустой файл"); return; }
    if (len > EDIT_BUF_SIZE - 1) {
        len = EDIT_BUF_SIZE - 1;
        ed_status(e, "Файл усечён до 8192 байт");
    }
    memcpy(e->buf, content, len);
    e->buf[len] = 0;
    e->len = len;
    e->cursor = 0;
    e->top = 0;
    e->dirty = 0;
    strncpy(e->filename, pick->name, sizeof(e->filename) - 1);
    e->filename[sizeof(e->filename) - 1] = 0;
    free(content);
    char msg[96];
    const char *src = pick->source == FD_SRC_RAMFS ? "RAM disk"
                   : pick->source == FD_SRC_ATA ? "HDD" : "USB";
    snprintf(msg, sizeof(msg), "Загружено: %s (%d байт, %s) — правка сохранится в RAM disk",
             e->filename, len, src);
    ed_status(e, msg);
}

/* «Открыть...»: стандартный диалог с тремя источниками. */
static void ed_open_file(editor_t *e)
{
    if (e->dlg) return;
    e->dlg = 1;
    ed_status(e, "Открытие: выберите файл...");
    filedlg_open("Открыть файл", ".c,.cs,.txt",
                 e->filename[0] ? e->filename : NULL,
                 ed_dlg_open_ok, ed_dlg_cancel, e);
}

static void ed_compile_run(editor_t *e)
{
    if (e->compiling) {
        ed_status(e, "Уже компилируется...");
        return;
    }
    if (e->len == 0) {
        ed_status(e, "Буфер пуст — нечего компилировать");
        return;
    }
    e->buf[e->len] = 0;

    /* Автосохранение под текущим именем (без диалога), чтобы исходник
     * был доступен для перезагрузки и компиляции в .bin. */
    ed_save_to(e, e->filename[0] ? e->filename : "prog.c");

    compile_ctx_t *c = (compile_ctx_t *)malloc(sizeof(compile_ctx_t));
    if (!c) { ed_status(e, "Нет памяти под контекст"); return; }
    c->ed = e;
    c->out_max = 16384;
    c->out = (char *)malloc(c->out_max);
    if (!c->out) { free(c); ed_status(e, "Нет памяти под вывод"); return; }
    c->out[0] = 0;
    c->result = -1;

    e->compiling = 1;
    ed_status(e, "Компиляция и запуск...");

    int tid = task_spawn("c4", compile_task_fn, c);
    if (tid < 0) {
        e->compiling = 0;
        free(c->out);
        free(c);
        ed_status(e, "Не удалось породить задачу");
    } else {
        char msg[80];
        snprintf(msg, sizeof(msg), "Запущена задача #%d: c4", tid);
        ed_status(e, msg);
    }
}

/* Запустить действие по индексу кнопки */
static void ed_run_button(editor_t *e, int btn_idx)
{
    switch (btn_idx) {
    case 0: ed_save_as(e);   break;   /* Save F2 — диалог «Сохранить как» */
    case 1: ed_open_file(e); break;   /* Load F4 — диалог «Открыть» */
    case 2: ed_compile_run(e); break;
    case 3: /* Close — обрабатывается в ed_mouse */
        break;
    }
}

static void ed_draw(window_t *w)
{
    editor_t *e = (editor_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Шапка с кнопками */
    fb_fill_rect(0, 0, cw, EDIT_HEADER_H, fb_rgb(0x1E, 0x4A, 0x73));

    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh;
        ed_button_rect(i, &bx, &by, &bw, &bh);
        u32 bg = (e->btn_pressed == i) ? fb_rgb(0x4A, 0x7F, 0xB0)
              : (e->btn_hot == i) ? fb_rgb(0x32, 0x60, 0x8E)
              : fb_rgb(0x25, 0x4A, 0x70);
        fb_fill_rect(bx, by, bw, bh, bg);
        fb_rect(bx, by, bw, bh, fb_rgb(0x6F, 0xB3, 0xF2));
        /* Центрируем текст кнопки */
        int tw = (int)strlen(editor_buttons[i].label) * 8;
        int tx = bx + (bw - tw) / 2;
        int ty = by + (bh - 16) / 2 + 1;
        fb_text(tx, ty, editor_buttons[i].label, fb_rgb(0xE6, 0xEA, 0xEE), -1);
    }

    /* Информация о файле справа от кнопок */
    {
        int ix = BTN_X0 + BTN_COUNT * (BTN_W + BTN_GAP);
        if (ix < cw - 200) {
            char info[80];
            snprintf(info, sizeof(info), "%s  %d/%d  %s",
                     e->filename[0] ? e->filename : "(без имени)",
                     e->cursor, e->len,
                     e->dirty ? "*)" : "");
            fb_text(ix, BTN_Y0 + 3, info, fb_rgb(0xC6, 0xCD, 0xD5), -1);
        }
    }

    /* Текстовая область */
    int area_y0 = EDIT_HEADER_H;
    int area_h  = ch - EDIT_HEADER_H - 14;
    int cols = (cw - 4) / 8;
    if (cols < 1) cols = 1;
    int vis  = area_h / 16;
    if (vis < 1) vis = 1;

    fb_fill_rect(0, area_y0, cw, area_h, fb_rgb(0x0B, 0x0E, 0x11));

    int line = 0, i = 0;
    while (i < e->len && line < e->top) {
        if (e->buf[i] == '\n') line++;
        i++;
    }
    int y = area_y0 + 2;
    char tmp[256];
    for (int r = 0; r < vis && i < e->len; r++) {
        int start = i, end = i;
        while (end < e->len && e->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols)  len = cols;
        if (len > 254)   len = 254;
        memcpy(tmp, e->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xE6, 0xEA, 0xEE), -1);
        i = end + (end < e->len ? 1 : 0);
        y += 16;
    }

    /* Курсор (мигающий блок) */
    if (wm_blink() && !e->compiling) {
        int cl = line_of(e, e->cursor);
        int row = cl - e->top;
        if (row >= 0 && row < vis) {
            int ls = line_start(e, e->cursor);
            int col = e->cursor - ls;
            if (col > cols) col = cols;
            int cx = 4 + col * 8;
            int cy = area_y0 + 2 + row * 16;
            fb_fill_rect(cx, cy, 8, 16, fb_rgb(0x6F, 0xB3, 0xF2));
        }
    }

    /* Статус-строка внизу */
    fb_fill_rect(0, ch - 14, cw, 14, fb_rgb(0x12, 0x16, 0x1B));
    fb_text(4, ch - 12, e->status, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

static void ed_insert(editor_t *e, char c)
{
    if (e->len >= EDIT_BUF_SIZE - 1) {
        ed_status(e, "Буфер полон");
        return;
    }
    for (int i = e->len; i > e->cursor; i--) e->buf[i] = e->buf[i - 1];
    e->buf[e->cursor] = c;
    e->cursor++;
    e->len++;
    e->buf[e->len] = 0;
    e->dirty = 1;
}

static void ed_backspace(editor_t *e)
{
    if (e->cursor == 0) return;
    e->cursor--;
    for (int i = e->cursor; i < e->len; i++) e->buf[i] = e->buf[i + 1];
    e->len--;
    e->buf[e->len] = 0;
    e->dirty = 1;
}

static void ed_key(window_t *w, const key_event_t *ev)
{
    editor_t *e = (editor_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (e->dlg) return;    /* открыт диалог — редактор игнорирует ввод */

    /* F2 (0x3C), F4 (0x3E), F9 (0x43), Esc (0x01) — дублируют кнопки */
    if (ev->code == 0x3C)   { ed_save_as(e); win_invalidate(w); return; }
    if (ev->code == 0x3E)   { ed_open_file(e); win_invalidate(w); return; }
    if (ev->code == 0x43)   { ed_compile_run(e); win_invalidate(w); return; }
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }

    if (ev->code == KBD_UP) {
        int ls = line_start(e, e->cursor);
        if (ls > 0) {
            int prev_end = ls - 1;
            int prev_start = line_start(e, prev_end);
            int col = e->cursor - ls;
            int new_pos = prev_start + col;
            if (new_pos > prev_end) new_pos = prev_end;
            e->cursor = new_pos;
            int l = line_of(e, e->cursor);
            if (l < e->top) e->top = l;
            win_invalidate(w);
        }
        return;
    }
    if (ev->code == KBD_DOWN) {
        int ls = line_start(e, e->cursor);
        int le = line_end(e, e->cursor);
        int col = e->cursor - ls;
        if (le < e->len) {
            int next_start = le + 1;
            int next_end = line_end(e, next_start);
            int new_pos = next_start + col;
            if (new_pos > next_end) new_pos = next_end;
            e->cursor = new_pos;
            int l = line_of(e, e->cursor);
            int vis = (win_content_h(w) - EDIT_HEADER_H - 14) / 16;
            if (l >= e->top + vis) e->top = l - vis + 1;
            win_invalidate(w);
        }
        return;
    }
    if (ev->code == KBD_LEFT)  { if (e->cursor > 0) e->cursor--; win_invalidate(w); return; }
    if (ev->code == KBD_RIGHT) { if (e->cursor < e->len) e->cursor++; win_invalidate(w); return; }
    if (ev->code == 0x49) { e->top -= 8; if (e->top < 0) e->top = 0; win_invalidate(w); return; }
    if (ev->code == 0x51) { e->top += 8; win_invalidate(w); return; }
    if (ev->code == 0x47) { e->cursor = line_start(e, e->cursor); win_invalidate(w); return; }
    if (ev->code == 0x4F) { e->cursor = line_end(e, e->cursor);   win_invalidate(w); return; }

    if (ev->ch == '\b') { ed_backspace(e); win_invalidate(w); return; }
    if (ev->ch == '\n') { ed_insert(e, '\n'); win_invalidate(w); return; }
    if (ev->ch == '\t') { ed_insert(e, ' '); ed_insert(e, ' '); win_invalidate(w); return; }

    if (ev->ch >= 32 && ev->ch < 127) {
        ed_insert(e, (char)ev->ch);
        win_invalidate(w);
        return;
    }
}

/* Обработчик мыши: клики по верхней панели активируют кнопки. */
static void ed_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed)
{
    editor_t *e = (editor_t *)w->data;
    if (e->dlg) return;    /* открыт диалог — редактор игнорирует ввод */
    int inside = (my < EDIT_HEADER_H);

    if (inside) {
        int btn = ed_button_at(e, mx, my);
        if (btn != e->btn_hot) {
            e->btn_hot = btn;
            win_invalidate(w);
        }
        /* Нажатие ЛКМ */
        if ((changed & MSB_LEFT) && (buttons & MSB_LEFT)) {
            if (btn >= 0) {
                e->btn_pressed = btn;
                win_invalidate(w);
            }
        }
        /* Отпускание ЛКМ */
        if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT)) {
            int was_pressed = e->btn_pressed;
            e->btn_pressed = -1;
            if (was_pressed >= 0 && btn == was_pressed) {
                /* Срабатывание кнопки */
                if (was_pressed == 3) {
                    /* Close */
                    win_close(w);
                    return;
                }
                ed_run_button(e, was_pressed);
            }
            win_invalidate(w);
        }
        return;
    }

    /* Клик в текстовой области — снимаем подсветку кнопок */
    if (e->btn_hot != -1 || e->btn_pressed != -1) {
        e->btn_hot = -1;
        e->btn_pressed = -1;
        win_invalidate(w);
    }
}

static void ed_close(window_t *w)
{
    editor_t *e = (editor_t *)w->data;
    if (e) free(e);
}

/* Шаблон по умолчанию — демонстрирует улучшенный c4 (for, #define, массивы,
 * блочные комментарии, инициализация переменных). */
static const char *default_template =
    "/* Пример для c4: for, #define, массивы, блочные комментарии */\n"
    "#define MAX 10\n"
    "\n"
    "int fib(int n) {\n"
    "    if (n < 2) return n;\n"
    "    return fib(n - 1) + fib(n - 2);\n"
    "}\n"
    "\n"
    "int main() {\n"
    "    int i;\n"
    "    int sum = 0;\n"
    "    int arr[MAX];\n"
    "\n"
    "    for (i = 0; i < MAX; i = i + 1) {\n"
    "        arr[i] = fib(i + 1);\n"
    "        sum = sum + arr[i];\n"
    "    }\n"
    "    for (i = 0; i < MAX; i = i + 1) {\n"
    "        printf(\"fib(%d) = %d\\n\", i + 1, arr[i]);\n"
    "    }\n"
    "    printf(\"sum = %d\\n\", sum);\n"
    "    return 0;\n"
    "}\n";

/* Внутренняя функция для инициализации редактора с заданным содержимым.
 * Используется app_editor_open() (пустой шаблон) и fileman (загрузка .c). */
static editor_t *ed_new_with(const char *filename, const char *content, int len)
{
    editor_t *e = (editor_t *)malloc(sizeof(editor_t));
    if (!e) return NULL;
    memset(e, 0, sizeof(editor_t));

    if (content && len > 0) {
        if (len >= EDIT_BUF_SIZE) len = EDIT_BUF_SIZE - 1;
        memcpy(e->buf, content, len);
        e->buf[len] = 0;
        e->len = len;
    } else {
        /* Шаблон по умолчанию */
        int L = (int)strlen(default_template);
        if (L >= EDIT_BUF_SIZE) L = EDIT_BUF_SIZE - 1;
        memcpy(e->buf, default_template, L);
        e->buf[L] = 0;
        e->len = L;
    }
    e->cursor = 0;
    e->top = 0;
    e->btn_hot = -1;
    e->btn_pressed = -1;
    if (filename && filename[0]) {
        strncpy(e->filename, filename, sizeof(e->filename) - 1);
        e->filename[sizeof(e->filename) - 1] = 0;
    } else {
        strcpy(e->filename, "prog.c");
    }
    ed_status(e, "F2 — сохранить в диалоге, F4 — открыть, F9 — скомпилировать");
    return e;
}

void app_editor_open(void)
{
    editor_t *e = ed_new_with(NULL, NULL, 0);
    if (!e) return;

    u32 W = fb_width(), H = fb_height();
    int ww = EDIT_COLS * 8 + 12;
    int wh = EDIT_ROWS * 16 + EDIT_HEADER_H + 16 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    win_create("Редактор C", 60, 30, ww, wh,
               ed_draw, ed_key, ed_mouse, NULL, ed_close, e);
}

/* Открыть редактор с уже загруженным содержимым.
 * Используется файловым менеджером для .c-файлов. */
void app_editor_open_with(const char *filename, const char *content, int len)
{
    editor_t *e = ed_new_with(filename, content, len);
    if (!e) return;

    u32 W = fb_width(), H = fb_height();
    int ww = EDIT_COLS * 8 + 12;
    int wh = EDIT_ROWS * 16 + EDIT_HEADER_H + 16 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    char title[64];
    snprintf(title, sizeof(title), "Редактор C: %s",
             filename ? filename : "(без имени)");
    win_create(title, 60, 30, ww, wh,
               ed_draw, ed_key, ed_mouse, NULL, ed_close, e);
}
