/* apps_settings.c — приложение «Настройки» (сессия 11, переработано 12).
 *
 * Сессия 12: ДВЕ ВКЛАДКИ — «Сеть» и «Диски»:
 *   - Сеть: как раньше (адаптеры/линк/приоритет/DHCP/WiFi);
 *   - Диски: подключённые накопители (НЖМД, разделы, CD, USB, RAM),
 *     форматирование НЖМД в FAT32 — с двухшаговым предупреждением
 *     о потере данных и прогрессом.
 *
 * Настройки сети сохраняются в RAM disk (SETTINGS.CFG).
 *
 * Клавиши: Tab / 1 / 2 — вкладки; Сеть: Up/Dn — выбор адаптера,
 * Enter — приоритет, A — авто, R — DHCP, W/D — WiFi; Диски: F —
 * формат, Enter — подтвердить, Esc — отмена/выход. Мышь: клики по
 * вкладкам и строкам-кнопкам.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "net.h"
#include "ath9k_wifi.h"
#include "disk.h"
#include "fat32.h"
#include "fat32_format.h"
#include "ntfs.h"
#include "kernel.h"
#include "ramfs.h"
#include "timer.h"
#include "task.h"
#include "iso9660.h"

extern void serial_puts(const char *s);
#include "usb_ehci.h"

#define SET_COLS     66
#define SET_ROW_H    18
#define SET_HDR_H    24
#define SET_TABS_H   26

typedef struct {
    int  tab;              /* 0 = Сеть, 1 = Диски */
    int  sel;              /* выбранная строка-адаптер */
    int  hover;            /* подсветка мыши */
    u32  dhcp_ticks;       /* мигание статуса DHCP */

    /* ---- Диски / форматирование ---- */
    int  confirm;          /* 1 = ждём подтверждение формата */
    int  deny;             /* 1 = формат запрещён (NTFS) — сообщение */
    int  fmt_full;         /* 0 = быстрое (оглавление), 1 = полное (очистка) */
    int  formatting;       /* 1 = формат идёт (рисуем прогресс) */
    int  fmt_done, fmt_total;
    int  fmt_last_result;  /* 0 = ок, <0 = ошибка, -100 = не было */
    char fmt_err[96];

    /* кликабельные зоны (заполняются при отрисовке; тот же поток) */
    struct { int x, y, w, h, action; } hot[20];
    int  hot_n;
} set_t;

/* действия кликов */
#define ACT_TAB_NET   0
#define ACT_TAB_DISK  1
#define ACT_AUTO      2
#define ACT_DHCP      3
#define ACT_WIFI_W    4
#define ACT_WIFI_D    5
#define ACT_ADAPTER   8    /* + индекс */
#define ACT_FMT       20
#define ACT_FMT_YES   21
#define ACT_FMT_NO    22

/* ============ сохранение настроек (RAM disk SETTINGS.CFG) ============ */

#define SETTINGS_FILE "SETTINGS.CFG"

static void settings_save_adapter(int mode /* 0=auto, 1..N=manual */)
{
    if (!ramfs_ready()) return;
    char buf[64];
    int L;
    if (mode == 0)
        L = snprintf(buf, sizeof(buf), "adapter=auto\n");
    else {
        const char *nm = net_adapter_name(mode - 1);
        L = snprintf(buf, sizeof(buf), "adapter=%s\n", nm);
    }
    ramfs_delete(SETTINGS_FILE);
    if (ramfs_create(SETTINGS_FILE, (u32)L + 1))
        ramfs_write(SETTINGS_FILE, buf, (u32)L + 1);
}

/* ============ вспомогательная отрисовка ============ */

static void set_hot(set_t *d, int x, int y, int w, int h, int action)
{
    if (d->hot_n < 20) {
        d->hot[d->hot_n].x = x; d->hot[d->hot_n].y = y;
        d->hot[d->hot_n].w = w; d->hot[d->hot_n].h = h;
        d->hot[d->hot_n].action = action;
        d->hot_n++;
    }
}

static void set_row(set_t *d, int y, int hot_action, const char *left,
                    const char *right, u32 lcol, u32 rcol)
{
    if (hot_action >= 0) {
        int w = 62 * 8 + 8;
        int hover = 0;
        for (int i = 0; i < d->hot_n; i++)
            if (d->hot[i].action == hot_action) { (void)d->hot[i]; break; }
        (void)hover;
        set_hot(d, 2, y - 2, w, SET_ROW_H - 2, hot_action);
        /* подсветка: рисуется по d->hover в вызывающем (упрощённо) */
    }
    fb_text(8, y, left, lcol, -1);
    int rw = (int)strlen(right) * 8;
    if (right[0])
        fb_text(8 + 62 * 8 - rw, y, right, rcol, -1);
}

/* строка с подсветкой, если она под hover/selected */
static void set_row_hl(set_t *d, int y, int hl, const char *left,
                       const char *right, u32 lcol, u32 rcol)
{
    if (hl) {
        int w = 62 * 8 + 8;
        for (int i = 0; i < d->hot_n; i++)
            if (d->hot[i].y == y - 2) {
                fb_fill_rect(2, y - 2, w, SET_ROW_H - 2, fb_rgb(0x24, 0x43, 0x5F));
                break;
            }
    }
    fb_text(8, y, left, lcol, -1);
    int rw = (int)strlen(right) * 8;
    if (right[0])
        fb_text(8 + 62 * 8 - rw, y, right, rcol, -1);
}

static void fmt_human_size(u64 sectors, char *out, int max)
{
    u64 mib = sectors / 2048u;
    if (mib >= 1024u * 100u)
        snprintf(out, (u32)max, "%u ГиБ", (unsigned)(mib / 1024u));
    else
        snprintf(out, (u32)max, "%u МиБ", (unsigned)mib);
}

/* ============ вкладка «Диски» ============ */

/* Высота красного прямоугольника формата: предупреждение + режим + кнопки */
#define FMT_BOX_H 96

/* Y-координата верха красного бокса. ЕДИНАЯ функция и для confirm-бокса,
 * и для прогресса (сессия 13, FIX: раньше полоса рисовалась по ЖЁСТКО
 * заданному Y и «слегка выходила за границы красного прямоугольника» —
 * теперь бокс и полоса живут в одной системе координат, всё строго
 * внутри). Высота зависит от числа строк разделов MBR. */
static int set_fmt_box_y(void)
{
    int y = SET_TABS_H + 4;          /* начало таба */
    y += 15;                        /* строка НЖМД */
    y += 15;                        /* строка ФС */
    int np = disk_part_count();
    int plines = (np > 0) ? (np < 4 ? np : 4) : 1;
    y += plines * 15;               /* строки разделов */
    return y + 8 - 4;               /* +8 отступ, -4 рамка от текста */
}

/* Сессия 13 (запрос пользователя): ЗАПРЕТ форматирования NTFS.
 * Формат делает из диска superfloppy и уничтожает ВСЕ разделы —
 * если на диске есть NTFS (Windows), запрещаем: ntfs-разделы защищены.
 * Признак: смонтированная NTFS, раздел MBR типа 0x07, NTFS-загрузочный
 * сектор в любом разделе. */
static int set_disk_has_ntfs(void)
{
    if (ntfs_ready()) return 1;
    int np = disk_part_count();
    for (int i = 0; i < np; i++) {
        if (disk_part(i)->type == 0x07) return 1;
        if (strcmp(disk_part_fstype(i), "NTFS") == 0) return 1;
    }
    return 0;
}

static void draw_disk_tab(window_t *w, set_t *d)
{
    int cw = win_content_w(w);
    char line[160];
    int y = SET_TABS_H + 4;

    /* --- НЖМД --- */
    if (disk_hdd_present()) {
        char sz[24];
        fmt_human_size(disk_hdd_sectors(), sz, sizeof(sz));
        const char *fs = fat32_ready() ? "FAT32" : (ntfs_ready() ? "NTFS" : NULL);
        snprintf(line, sizeof(line), "НЖМД [%s]: %s (%s)",
                 disk_hdd_bus(), disk_hdd_model(), sz);
        fb_text(8, y, line, fb_rgb(0xDD, 0xE2, 0xE6), -1);
        y += 15;
        snprintf(line, sizeof(line), "ФС: %s%s",
                 fs ? fs : "не распознана",
                 sata_pending() ? "  (инициализация...)" :
                 (fs ? "  [доступна]" : "  [нет поддерживаемой]"));
        fb_text(8, y, line,
                fs ? fb_rgb(0x90, 0xEE, 0x90) : fb_rgb(0xE0, 0x9A, 0x9A), -1);
        y += 15;

        /* разделы MBR */
        int np = disk_part_count();
        if (np > 0) {
            for (int i = 0; i < np && i < 4; i++) {
                char psz[24];
                fmt_human_size(disk_part(i)->nsectors, psz, sizeof(psz));
                snprintf(line, sizeof(line), "  раздел %d: %s %s  LBA %u",
                         i + 1, disk_part_fstype(i)[0] ? disk_part_fstype(i) : "?",
                         psz, (unsigned)disk_part(i)->start_lba);
                fb_text(8, y, line, fb_rgb(0x9E, 0xB8, 0xC8), -1);
                y += 15;
            }
        } else {
            fb_text(8, y, "  разделов MBR нет (весь диск — одна ФС)",
                    fb_rgb(0x9E, 0xB8, 0xC8), -1);
            y += 15;
        }

        /* кнопка форматирования */
        y += 8;
        if (d->formatting) {
            /* прогресс рисуется отдельно (fmt_progress_cb) — здесь
             * только заголовок; бокс с полосой рисуется тем же колбэком
             * в тех же координатах (FIX сессии 13) */
            fb_text(8, y, "Форматирование...", fb_rgb(0xFF, 0xC0, 0x40), -1);
            y += SET_ROW_H;
        } else if (d->deny) {
            /* Сессия 13: запрет (NTFS) */
            int bw = cw - 16;
            int by = set_fmt_box_y();
            fb_fill_rect(6, by, bw, FMT_BOX_H, fb_rgb(0x40, 0x14, 0x14));
            fb_rect(6, by, bw, FMT_BOX_H, fb_rgb(0xE0, 0x50, 0x50));
            fb_text(14, by + 8, "Форматирование ЗАПРЕЩЕНО:",
                    fb_rgb(0xFF, 0x90, 0x90), -1);
            fb_text(14, by + 24, "на этом диске есть NTFS (Windows).",
                    fb_rgb(0xE0, 0xA0, 0xA0), -1);
            fb_text(14, by + 40, "NTFS-разделы защищены от удаления;",
                    fb_rgb(0xE0, 0xA0, 0xA0), -1);
            fb_text(14, by + 56, "Esc — закрыть",
                    fb_rgb(0xDD, 0xE2, 0xE6), -1);
            y = by + FMT_BOX_H + 4;
        } else if (d->confirm) {
            int bw = cw - 16;
            int by = set_fmt_box_y();
            fb_fill_rect(6, by, bw, FMT_BOX_H, fb_rgb(0x40, 0x14, 0x14));
            fb_rect(6, by, bw, FMT_BOX_H, fb_rgb(0xE0, 0x50, 0x50));
            fb_text(14, by + 8, "ВНИМАНИЕ! Форматирование УДАЛИТ ВСЕ ДАННЫЕ",
                    fb_rgb(0xFF, 0x90, 0x90), -1);
            fb_text(14, by + 24, "на диске (разделы, файлы, Windows — всё).",
                    fb_rgb(0xE0, 0xA0, 0xA0), -1);
            /* Сессия 13: выбор режима [Q]/[P] */
            snprintf(line, sizeof(line), "[Q] Быстрое (оглавление)%s   [P] Полное (очистка)%s",
                     d->fmt_full ? "" : " *", d->fmt_full ? " *" : "");
            fb_text(14, by + 40, line, fb_rgb(0xDD, 0xE2, 0xE6), -1);
            snprintf(line, sizeof(line), "Режим: %s", d->fmt_full
                     ? "ПОЛНОЕ — структуры + очистка всех данных нулями"
                     : "БЫСТРОЕ — только структуры ФС (оглавление)");
            fb_text(14, by + 56, line, fb_rgb(0x8A, 0xC8, 0xE8), -1);
            fb_text(14, by + 72, "Enter — ДА, форматировать    Esc — отмена",
                    fb_rgb(0xDD, 0xE2, 0xE6), -1);
            set_hot(d, 6, by + 76, bw / 2 - 10, 18, ACT_FMT_YES);
            set_hot(d, 6 + bw / 2, by + 76, bw / 2 - 10, 18, ACT_FMT_NO);
            y = by + FMT_BOX_H + 4;
        } else {
            set_row(d, y, ACT_FMT, "[F] Форматировать диск в FAT32", "",
                    fb_rgb(0xE0, 0x9A, 0x9A), 0);
            y += SET_ROW_H;
            if (d->fmt_last_result == 0) {
                fb_text(8, y, "Форматирование завершено — FAT32 готова.",
                        fb_rgb(0x90, 0xEE, 0x90), -1);
                y += 15;
            } else if (d->fmt_last_result < 0 && d->fmt_last_result != -100) {
                snprintf(line, sizeof(line), "Ошибка формата: %s",
                         d->fmt_err[0] ? d->fmt_err : "запись не удалась");
                fb_text(8, y, line, fb_rgb(0xE0, 0x9A, 0x9A), -1);
                y += 15;
            }
        }
    } else {
        const char *st = sata_pending() ? "инициализация в фоне..." : "не найден";
        snprintf(line, sizeof(line), "НЖМД: %s", st);
        fb_text(8, y, line, fb_rgb(0x8A, 0x93, 0x9C), -1);
        y += SET_ROW_H;
    }

    /* --- прочие накопители --- */
    y += 8;
    fb_text(8, y, "Прочие накопители:", fb_rgb(0x6F, 0xB3, 0xF2), -1);
    y += 15;
    snprintf(line, sizeof(line), "  CD: %s", disk_cd_present() ? "есть (ISO9660)" : "нет");
    fb_text(8, y, line, fb_rgb(0xDD, 0xE2, 0xE6), -1);
    y += 15;
    {
        const char *ust = !usb_ehci_storage_ready() ? "нет"
            : (fat32_ready() && fat32_is_usb() ? "есть, FAT32" : "есть (ФС?)");
        snprintf(line, sizeof(line), "  USB: %s", ust);
        fb_text(8, y, line, fb_rgb(0xDD, 0xE2, 0xE6), -1);
        y += 15;
    }
    snprintf(line, sizeof(line), "  RAM disk: %s",
             ramfs_ready() ? "готов" : "нет");
    fb_text(8, y, line, fb_rgb(0xDD, 0xE2, 0xE6), -1);
}

/* ============ вкладка «Сеть» ============ */

static void draw_net_tab(window_t *w, set_t *d)
{
    int cw = win_content_w(w);
    char line[160];
    int y = SET_TABS_H + 4;

    fb_text(8, y, "Адреса:", fb_rgb(0x6F, 0xB3, 0xF2), -1);
    y += 15;
    {
        char ipbuf[16];
        u32 ip = net_get_ip();
        if (ip)
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
        else
            strcpy(ipbuf, "нет");
        snprintf(line, sizeof(line), "IP: %s   DHCP: %s   TX %u / RX %u",
                 ipbuf,
                 net_dhcp_state() == DHCP_BOUND ? "BOUND" : "wait",
                 (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
        fb_text(16, y, line, fb_rgb(0x8A, 0xC8, 0xE8), -1);
        y += SET_ROW_H;
    }

    fb_text(8, y, "Приоритетный адаптер:", fb_rgb(0x6F, 0xB3, 0xF2), -1);
    y += SET_ROW_H;

    /* строка «Авто (по линку)» */
    {
        int manual = net_adapter_mode();
        char right[48];
        int any_link = 0;
        for (int i = 0; i < 5; i++)
            if (net_adapter_present(i) && net_adapter_link(i)) any_link = 1;
        snprintf(right, sizeof(right), "%s",
                 manual == 0 ? "<включён>" : (any_link ? "" : ""));
        set_row(d, y, ACT_AUTO, "[A] Авто (кабель > WiFi по линку)", right,
                fb_rgb(0xDD, 0xE2, 0xE6), fb_rgb(0x90, 0xEE, 0x90));
        set_row_hl(d, y, manual == 0, "", "", 0, 0);
        y += SET_ROW_H;
    }

    /* адаптеры */
    int shown = 0;
    for (int i = 0; i < 5 && shown < 4; i++) {
        if (!net_adapter_present(i)) continue;
        const char *nm = net_adapter_name(i);
        int act = (net_adapter_active() == i);
        int link = net_adapter_link(i);
        char right[48];
        if (i == 4 && wifi_present()) {
            const char *st = wifi_conn_state_name();
            snprintf(right, sizeof(right), "%s%s", st,
                     act ? "  [АКТИВЕН]" : "");
        } else {
            snprintf(right, sizeof(right), "link: %s%s",
                     link ? "up" : "down", act ? "  [АКТИВЕН]" : "");
        }
        char left[48];
        snprintf(left, sizeof(left), "     %s", nm);
        set_row(d, y, ACT_ADAPTER + i, left, right,
                act ? fb_rgb(0x90, 0xEE, 0x90) : fb_rgb(0xDD, 0xE2, 0xE6),
                act ? fb_rgb(0x90, 0xEE, 0x90) :
                      (link ? fb_rgb(0x8A, 0xC8, 0xE8) : fb_rgb(0xE0, 0x9A, 0x9A)));
        set_row_hl(d, y, d->sel == i, "", "", 0, 0);
        y += SET_ROW_H;
        shown++;
    }

    /* DHCP-кнопка */
    y += 6;
    set_row(d, y, ACT_DHCP, "[R] Обновить DHCP", "", fb_rgb(0xDD, 0xE2, 0xE6), 0);
    y += SET_ROW_H;

    /* ===== WiFi ===== */
    y += 10;
    fb_fill_rect(0, y - 4, cw, SET_HDR_H, fb_rgb(0x1E, 0x4A, 0x73));
    fb_text(8, y, "WIFI", fb_rgb(0xE6, 0xEA, 0xEE), -1);
    y += SET_HDR_H;

    if (wifi_present()) {
        char prof[33];
        int has_prof = wifi_profile_load(prof, sizeof(prof));
        snprintf(line, sizeof(line), "%s: %s%s",
                 wifi_chip_name(),
                 wifi_conn_state_name(),
                 wifi_conn_ssid()[0] ? ": \"" : "");
        fb_text(8, y, line, fb_rgb(0xDD, 0xE2, 0xE6), -1);
        if (wifi_conn_ssid()[0]) {
            snprintf(line, sizeof(line), "\"%s\"  ch %d  RSSI %d dBm%s",
                     wifi_conn_ssid(), wifi_conn_channel(), wifi_conn_rssi(),
                     wifi_conn_state() == WIFI_CONN_CONNECTED ? "" : " ...");
            fb_text(8, y += 15, line, fb_rgb(0x8A, 0xC8, 0xE8), -1);
        }
        snprintf(line, sizeof(line), "Профиль: %s%s",
                 has_prof ? prof : "(не задан)",
                 wifi_conn_secured() ? "  [WPA2]" : "");
        fb_text(8, y += 15, line, fb_rgb(0x9E, 0xB8, 0xC8), -1);
        y += SET_ROW_H - 15 + 6;
        if (has_prof) {
            set_row(d, y, ACT_WIFI_W, "[W] Переподключиться", "",
                    fb_rgb(0xDD, 0xE2, 0xE6), 0);
            y += SET_ROW_H;
        }
        set_row(d, y, ACT_WIFI_D, "[D] Отключиться", "",
                fb_rgb(0xDD, 0xE2, 0xE6), 0);
        y += SET_ROW_H;
    } else {
        fb_text(8, y, "Адаптер не найден (AR9285/9287/9485)",
                fb_rgb(0x8A, 0x93, 0x9C), -1);
        y += SET_ROW_H;
    }
}

/* ============ общий draw ============ */

static void set_draw(window_t *w)
{
    set_t *d = (set_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    d->hot_n = 0;   /* заново собираем кликабельные зоны */

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x10, 0x13, 0x18));

    /* ===== вкладки ===== */
    {
        static const char *names[2] = { "[1] Сеть", "[2] Диски" };
        int tw = (cw - 12) / 2;
        for (int i = 0; i < 2; i++) {
            int bx = 4 + i * (tw + 4);
            int on = (d->tab == i);
            fb_fill_rect(bx, 2, tw, SET_TABS_H - 6,
                         on ? fb_rgb(0x1E, 0x4A, 0x73) : fb_rgb(0x17, 0x1C, 0x22));
            fb_rect(bx, 2, tw, SET_TABS_H - 6,
                    on ? fb_rgb(0x6F, 0xB3, 0xF2) : fb_rgb(0x2C, 0x31, 0x38));
            fb_text(bx + 10, 6, names[i],
                    on ? fb_rgb(0xE6, 0xEA, 0xEE) : fb_rgb(0x9A, 0xA3, 0xAC), -1);
            set_hot(d, bx, 2, tw, SET_TABS_H - 6, i ? ACT_TAB_DISK : ACT_TAB_NET);
        }
        fb_hline(0, cw - 1, SET_TABS_H - 1, fb_rgb(0x2C, 0x31, 0x38));
    }

    if (d->tab == 0)
        draw_net_tab(w, d);
    else
        draw_disk_tab(w, d);

    /* подсказка */
    fb_fill_rect(0, ch - 16, cw, 16, fb_rgb(0x12, 0x16, 0x1B));
    fb_text(6, ch - 13,
            d->tab == 0
            ? "Tab: вкладки   Enter: приоритет   A: авто   R: DHCP   Esc: выход"
            : "Tab: вкладки   F: формат FAT32   Enter: да   Esc: нет/выход",
            fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

/* ============ форматирование (поток окна Настроек) ============ */

static window_t *g_fmt_win;

static void fmt_progress_cb(u32 done, u32 total, void *ctx)
{
    set_t *d = (set_t *)ctx;
    window_t *w = g_fmt_win;
    if (!w || !w->canvas) return;
    d->fmt_done = (int)done;
    d->fmt_total = (int)total;

    /* Сессия 13, FIX «полоса с надписью выходит за границы красного
     * прямоугольника»: весь блок формата (рамка + полоса + подпись)
     * рисуется ЗДЕСЬ в одних координатах set_fmt_box_y(). Во время
     * формата окно не перерисовывается целиком (поток занят записью),
     * поэтому колбэк закрашивает бокс целиком — никакой «полосы
     * поверх чужой рамки». */
    int cw = win_content_w(w);
    int ch = win_content_h(w);
    fb_set_clip(0, 0, cw - 1, ch - 1);
    fb_set_origin(0, 0);
    int by = set_fmt_box_y();
    int bw = cw - 16;
    if (by + FMT_BOX_H > ch) by = ch - FMT_BOX_H - 2;
    if (by < 0) by = 0;

    fb_fill_rect(6, by, bw, FMT_BOX_H, fb_rgb(0x40, 0x14, 0x14));
    fb_rect(6, by, bw, FMT_BOX_H, fb_rgb(0xE0, 0x50, 0x50));
    fb_text(14, by + 8, d->fmt_full
            ? "ПОЛНОЕ форматирование (с очисткой данных)..."
            : "БЫСТРОЕ форматирование (создание оглавления)...",
            fb_rgb(0xFF, 0xC0, 0x40), -1);

    /* полоса: строго внутри бокса */
    int bar_y = by + 30;
    int bar_x = 14, bar_w = cw - 28;      /* отступ 8 от рамки с обеих сторон */
    fb_fill_rect(bar_x, bar_y, bar_w, 14, fb_rgb(0x1B, 0x21, 0x27));
    fb_rect(bar_x, bar_y, bar_w, 14, fb_rgb(0x2C, 0x31, 0x38));
    if (total > 0) {
        int fill = (int)(((u64)done * (u64)(bar_w - 4)) / total);
        if (fill > bar_w - 4) fill = bar_w - 4;
        if (fill > 0)
            fb_fill_rect(bar_x + 2, bar_y + 2, fill, 10, fb_rgb(0x3E, 0x7D, 0xBF));
    }

    /* подпись ПОД полосой — тоже внутри бокса */
    char b[80];
    snprintf(b, sizeof(b), "%s: %u / %u секторов",
             d->fmt_full ? "Полное" : "Быстрое",
             (unsigned)done, (unsigned)total);
    fb_text(14, by + 52, b, fb_rgb(0xFF, 0xC0, 0x40), -1);

    fb_touch(w->x, w->y, w->w, w->h);
}

static void set_run_format(window_t *w, set_t *d)
{
    d->formatting = 1;
    d->fmt_last_result = -100;
    g_fmt_win = w;
    /* первичная отрисовка бокса с полосой */
    fmt_progress_cb(0, 1, d);

    int rc = fat32_format_hdd(fmt_progress_cb, d, d->fmt_full);

    d->formatting = 0;
    if (rc == FAT32_FMT_OK) {
        d->fmt_last_result = 0;
        /* перемонтирование: MBR больше нет, FAT32 — на весь диск */
        fat32_deinit();
        ntfs_invalidate();
        disk_part_rescan();
        if (fat32_init())
            serial_puts("[fmt] FAT32 смонтирована после форматирования\n");
        else
            serial_puts("[fmt] ВНИМАНИЕ: FAT32 не смонтировалась после формата\n");
    } else {
        d->fmt_last_result = rc;
        const char *why =
            rc == FAT32_FMT_NO_DISK  ? "диск не найден" :
            rc == FAT32_FMT_TOO_SMALL ? "диск слишком мал для FAT32" :
                                        "ошибка записи";
        strncpy(d->fmt_err, why, sizeof(d->fmt_err) - 1);
        d->fmt_err[sizeof(d->fmt_err) - 1] = 0;
    }
    win_invalidate(w);
}

/* ============ события ============ */

static void set_apply_mode(set_t *d, int mode)
{
    /* net_adapter_set_mode сам переключит адаптер и дёрнет netmon */
    if (net_adapter_set_mode(mode)) {
        /* адаптер сменился: DHCP перезапустится через callback */
    }
    settings_save_adapter(mode);
    d->dhcp_ticks = timer_ticks();
}

static void set_action(window_t *w, set_t *d, int action)
{
    switch (action) {
    case ACT_TAB_NET:  d->tab = 0; break;
    case ACT_TAB_DISK: d->tab = 1; break;
    case ACT_AUTO:     set_apply_mode(d, 0); break;
    case ACT_DHCP:
        net_request_dhcp();
        d->dhcp_ticks = timer_ticks();
        break;
    case ACT_WIFI_W: {
        char ssid[33];
        if (wifi_profile_load(ssid, sizeof(ssid)))
            wifi_connect(ssid);
        break;
    }
    case ACT_WIFI_D:
        wifi_disconnect();
        break;
    case ACT_FMT:
        if (disk_hdd_present() && !d->formatting) {
            /* Сессия 13: запрет форматирования NTFS-разделов */
            if (set_disk_has_ntfs()) {
                d->deny = 1;
                d->confirm = 0;
            } else {
                d->confirm = 1;
                d->deny = 0;
            }
        }
        break;
    case ACT_FMT_YES:
        if (d->confirm) {
            d->confirm = 0;
            set_run_format(w, d);
        }
        break;
    case ACT_FMT_NO:
        d->confirm = 0;
        break;
    default:
        if (action >= ACT_ADAPTER && action < ACT_ADAPTER + 5) {
            d->sel = action - ACT_ADAPTER;
            if (net_adapter_present(d->sel))
                set_apply_mode(d, d->sel + 1);
        }
        break;
    }
}

static void set_key(window_t *w, const key_event_t *ev)
{
    set_t *d = (set_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* Esc: отмена подтверждения/запрета, иначе — закрыть */
    if (ev->ch == 0x1B || ev->code == 0x01) {
        if (d->confirm) { d->confirm = 0; win_invalidate(w); return; }
        if (d->deny)    { d->deny = 0;    win_invalidate(w); return; }
        win_close(w);
        return;
    }

    /* вкладки */
    if (ev->code == 0x0F /* Tab */ || ev->ch == '1' || ev->ch == '2') {
        if (ev->code == 0x0F)
            d->tab = d->tab ? 0 : 1;
        else
            d->tab = (ev->ch == '2') ? 1 : 0;
        win_invalidate(w);
        return;
    }

    /* подтверждение формата: Q/P — режим, Enter — да */
    if (d->confirm) {
        if (ev->ch == 'q' || ev->ch == 'Q') { d->fmt_full = 0; win_invalidate(w); return; }
        if (ev->ch == 'p' || ev->ch == 'P') { d->fmt_full = 1; win_invalidate(w); return; }
        if (ev->code == 0x1C || ev->ch == '\n') {
            d->confirm = 0;
            set_run_format(w, d);
            return;
        }
    }
    if (d->deny && (ev->code == 0x1C || ev->ch == '\n')) {
        d->deny = 0;
        win_invalidate(w);
        return;
    }

    if (d->tab == 0) {
        /* ===== Сеть ===== */
        if (ev->ch == 'a' || ev->ch == 'A') {
            set_apply_mode(d, 0);
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'r' || ev->ch == 'R') {
            net_request_dhcp();
            d->dhcp_ticks = timer_ticks();
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'w' || ev->ch == 'W') {
            char ssid[33];
            if (wifi_profile_load(ssid, sizeof(ssid)))
                wifi_connect(ssid);
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'd' || ev->ch == 'D') {
            wifi_disconnect();
            win_invalidate(w);
            return;
        }
        if (ev->code == KBD_UP) {
            int cur = d->sel;
            for (int step = 0; step < 5; step++) {
                cur--;
                if (cur < 0) cur = 4;
                if (net_adapter_present(cur)) { d->sel = cur; break; }
            }
            win_invalidate(w);
        }
        if (ev->code == KBD_DOWN) {
            int cur = d->sel;
            for (int step = 0; step < 5; step++) {
                cur++;
                if (cur > 4) cur = 0;
                if (net_adapter_present(cur)) { d->sel = cur; break; }
            }
            win_invalidate(w);
        }
        if (ev->code == 0x1C || ev->ch == '\n') {
            if (net_adapter_present(d->sel))
                set_apply_mode(d, d->sel + 1);
            win_invalidate(w);
        }
    } else {
        /* ===== Диски ===== */
        if ((ev->ch == 'f' || ev->ch == 'F') && disk_hdd_present() &&
            !d->formatting) {
            if (set_disk_has_ntfs()) d->deny = 1;
            else d->confirm = 1;
            win_invalidate(w);
        }
    }
}

static void set_tick(window_t *w)
{
    set_t *d = (set_t *)w->data;
    wifi_conn_state_t cs = wifi_conn_state();
    int need = 0;
    if (d->tab == 0) {
        if (net_dhcp_state() != DHCP_BOUND ||
            cs == WIFI_CONN_SCAN || cs == WIFI_CONN_AUTH ||
            cs == WIFI_CONN_ASSOC)
            need = 1;
    } else {
        /* диски: состояние меняется по мере фоновой инициализации SATA
         * и после форматирования — сверяем контрольную сумму признаков */
        static int snap = -1;
        int cur = (disk_hdd_present() ? 1 : 0) |
                  (fat32_ready() ? 2 : 0) | (ntfs_ready() ? 4 : 0) |
                  (sata_pending() ? 8 : 0);
        if (cur != snap) { snap = cur; need = 1; }
    }
    if (need)
        win_invalidate(w);
}

static void set_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    set_t *d = (set_t *)w->data;

    /* клик по зоне */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        for (int i = 0; i < d->hot_n; i++) {
            if (mx >= d->hot[i].x && mx < d->hot[i].x + d->hot[i].w &&
                my >= d->hot[i].y && my < d->hot[i].y + d->hot[i].h) {
                set_action(w, d, d->hot[i].action);
                win_invalidate(w);
                return;
            }
        }
    }
    /* hover-подсветка строк (упрощённо: не перерисовываем, чтобы
     * не грузить композитор; курсор и так даёт обратную связь) */
    (void)d;
}

static void set_close(window_t *w) { free(w->data); }

void app_settings_open(void)
{
    set_t *d = (set_t *)malloc(sizeof(set_t));
    if (!d) return;
    memset(d, 0, sizeof(set_t));
    d->sel = net_adapter_active() >= 0 ? net_adapter_active() : 0;
    d->hover = -1;
    d->tab = 0;
    d->fmt_last_result = -100;

    u32 W = fb_width(), H = fb_height();
    int ww = SET_COLS * 8 + 16;
    int wh = 440;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    win_create("Настройки", 60, 40, ww, wh,
               set_draw, set_key, set_mouse, set_tick, set_close, d);
}
