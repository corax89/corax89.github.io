/* disk.c — диспетчер блочных устройств: AHCI (SATA) -> ATA (IDE).
 *
 * Контекст: в VMware НЖМД по умолчанию — SATA/AHCI, CD — IDE. Легаси-ATA
 * драйвер SATA не видит, и «кроме ramfs нет дисков». Слой пробует AHCI
 * первым; если SATA-диска нет — откат на ATA (QEMU IDE, старое железо).
 *
 * Сессия 11: + слой разделов MBR (общий для fat32/ntfs). Таблица
 * сканируется один раз; разделы отдаются драйверам ФС по индексу.
 */
#include "disk.h"
#include "ahci.h"
#include "ata.h"
#include "string.h"
#include "sync.h"

static int g_backend = 0;   /* 1 = AHCI, 2 = ATA */

int disk_hdd_init(void)
{
    if (ahci_hdd_present()) { g_backend = 1; return 1; }
    if (ata_hdd_present())  { g_backend = 2; return 1; }
    return 0;
}

int disk_hdd_present(void)
{
    if (g_backend == 1 && ahci_hdd_present()) return 1;
    if (g_backend == 2 && ata_hdd_present()) return 1;
    if (ahci_hdd_present()) { g_backend = 1; return 1; }
    if (ata_hdd_present())  { g_backend = 2; return 1; }
    return 0;
}

u32 disk_hdd_sectors(void)
{
    if (disk_hdd_present())
        return (g_backend == 1) ? ahci_hdd_sectors() : ata_hdd_sectors();
    return 0;
}

const char *disk_hdd_model(void)
{
    if (disk_hdd_present())
        return (g_backend == 1) ? ahci_hdd_model() : ata_hdd_model();
    return "";
}

const char *disk_hdd_bus(void)
{
    return (g_backend == 1) ? "AHCI" : "ATA";
}

int disk_hdd_read(u32 lba, u8 count, void *buf)
{
    if (ahci_hdd_present())
        return ahci_read_hdd(lba, count, buf);
    if (ata_hdd_present())
        return ata_read_hdd(lba, count, buf);
    return 0;
}

/* Запись секторов НЖМД (сессия 12) — используется форматированием
 * в FAT32 (Настройки → Диски). Маршрутизация та же, что у чтения. */
int disk_hdd_write(u32 lba, u8 count, const void *buf)
{
    if (ahci_hdd_present())
        return ahci_write_hdd(lba, count, buf);
    if (ata_hdd_present())
        return ata_write_hdd(lba, count, buf);
    return 0;
}

int disk_cd_read(u32 lba, void *buf)
{
    /* AHCI ATAPI (SATA-привод) приоритетнее */
    if (ahci_cd_present())
        return ahci_read_cd(lba, buf);
    if (ata_present() && !ata_is_hdd_active())
        return ata_read(lba, 1, buf);
    return 0;
}

int disk_cd_present(void)
{
    if (ahci_cd_present()) return 1;
    if (ata_present() && !ata_is_hdd_active()) return 1;
    return 0;
}

/* ================= разделы MBR (сессия 11) ================= */

#define DISK_MAX_PARTS 8
static disk_part_t g_parts[DISK_MAX_PARTS];
static int g_part_count = 0;
static int g_part_scanned = 0;
static volatile int g_part_lock = 0;

static int part_rd_sector(u32 lba, void *buf)
{
    return disk_hdd_read(lba, 1, buf);
}

static u32 part_rd32(const u8 *p)
{
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

/* Разбор MBR: 4 первичные записи + цепочка EBR (один уровень). */
static int part_scan_impl(void)
{
    u8 mbr[512];
    g_part_count = 0;
    if (!disk_hdd_present()) return 0;
    if (!part_rd_sector(0, mbr)) return 0;
    if (mbr[510] != 0x55 || mbr[511] != 0xAA) return 0;

    u32 ebr_base = 0;
    for (int i = 0; i < 4 && g_part_count < DISK_MAX_PARTS; i++) {
        const u8 *e = mbr + 0x1BE + i * 16;
        u8 type = e[4];
        if (type == 0) continue;
        u32 start = part_rd32(e + 8);
        u32 nsec = part_rd32(e + 12);
        if (type == 0x05 || type == 0x0F) {
            ebr_base = start;               /* extended — после первичных */
            continue;
        }
        if (start == 0 || nsec == 0) continue;
        g_parts[g_part_count].type = type;
        g_parts[g_part_count].start_lba = start;
        g_parts[g_part_count].nsectors = nsec;
        g_part_count++;
    }
    /* extended: цепочка EBR (до 4 логических разделов) */
    if (ebr_base) {
        u32 next = ebr_base;
        for (int k = 0; k < 4 && next; k++) {
            u8 ebr[512];
            if (!part_rd_sector(next, ebr)) break;
            if (ebr[510] != 0x55 || ebr[511] != 0xAA) break;
            const u8 *e0 = ebr + 0x1BE;     /* первая запись = сам раздел */
            if (e0[4] != 0 && g_part_count < DISK_MAX_PARTS) {
                u32 start = next + part_rd32(e0 + 8);
                u32 nsec = part_rd32(e0 + 12);
                if (start && nsec) {
                    g_parts[g_part_count].type = e0[4];
                    g_parts[g_part_count].start_lba = start;
                    g_parts[g_part_count].nsectors = nsec;
                    g_part_count++;
                }
            }
            const u8 *e1 = ebr + 0x1CE;     /* вторая = следующий EBR */
            if (e1[4] == 0x05 || e1[4] == 0x0F)
                next = ebr_base + part_rd32(e1 + 8);
            else
                next = 0;
        }
    }
    return g_part_count > 0;
}

int disk_part_count(void)
{
    if (!g_part_scanned) {
        s_lock(&g_part_lock);
        if (!g_part_scanned) {
            part_scan_impl();
            g_part_scanned = 1;
        }
        s_unlock(&g_part_lock);
    }
    return g_part_count;
}

/* Сессия 12: перечитать таблицу разделов (после форматирования диска —
 * superfloppy не имеет MBR, старый список недействителен). */
void disk_part_rescan(void)
{
    s_lock(&g_part_lock);
    part_scan_impl();
    g_part_scanned = 1;
    s_unlock(&g_part_lock);
}

const disk_part_t *disk_part(int i)
{
    if (i < 0 || i >= disk_part_count()) return NULL;
    return &g_parts[i];
}

const char *disk_part_fstype(int i)
{
    if (i < 0 || i >= disk_part_count()) return "";
    u8 bs[512];
    if (!part_rd_sector(g_parts[i].start_lba, bs)) return "";
    if (memcmp(bs + 3, "NTFS    ", 8) == 0) return "NTFS";
    if (memcmp(bs + 0x52, "FAT32", 5) == 0 ||
        memcmp(bs + 0x36, "FAT32", 5) == 0) return "FAT32";
    return "";
}
