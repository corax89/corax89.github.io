/* apps.h — реестр приложений N2600-OS.
 *
 * КАК ДОБАВИТЬ СВОЁ ПРИЛОЖЕНИЕ:
 *   1) создайте src/my_app.c по образцу src/apps_example.c;
 *   2) добавьте строку в app_table[] ниже (src/apps.c);
 *   3) соберите проект build.bat — всё, приложение появится в меню.
 */
#ifndef APPS_H
#define APPS_H

#include "types.h"   /* u32 для app_outwin_open */

typedef struct {
    const char *name;   /* название в меню «Пуск» */
    void (*open_fn)(void);
} app_def_t;

extern const app_def_t app_table[];
extern const int app_table_count;

void apps_open(int idx);

/* встроенные приложения */
void app_about_open(void);
void app_term_open(void);
void app_sysinfo_open(void);
void app_files_open(void);   /* файловый менеджер FAT32 */
void app_example_open(void);   /* шаблон нового приложения */
void app_editor_open(void);    /* текстовый редактор + компиляция c4 */
void app_editor_open_with(const char *filename, const char *content, int len);
void app_cmscript_open(void);  /* CMScript-редактор + запуск .cs */
void app_cmscript_open_with(const char *filename, const char *content, int len);
void app_taskmgr_open(void);    /* диспетчер задач */
void app_wifi_open(void);      /* WiFi сканер */
void app_browser_open(void);   /* веб-браузер (HTML→Markdown→рендер) */
void app_browser_open_with(const char *url, const char *content, int len);
void app_nettrace_open(void);  /* HTTP Trace: трассировка запроса/ответа */
void app_settings_open(void); /* Настройки: сеть/WiFi/система (сессия 11) */

/* Окно текстового вывода (используется редактором F9 и loader'ом
 * для вывода нативных c4-программ, запущенных через `run`). */
void app_outwin_open(const char *title, const char *text, u32 len);

/* Запустить приложение по имени (для вызова из других приложений).
 * Возвращает 1 при успехе, 0 если не найдено. */
int app_spawn_by_name(const char *name);

/* Открыть приложение по индексу в app_table */
void apps_open(int idx);

/* информация о CPU для приложений (заполняется лениво) */
void cpu_get_brand(char out[52]);
void cpu_get_vendor(char out[16]);
int  cpu_get_cores(void);

#endif /* APPS_H */
