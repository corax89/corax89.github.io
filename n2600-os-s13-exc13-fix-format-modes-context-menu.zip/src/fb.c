/* fb.c — вывод в VESA-фреймбуфер: backbuffer -> LFB, dirty-область, шрифт.
 * Размер и адрес фреймбуфера берутся из Multiboot (GRUB сам выставляет
 * видеорежим VESA согласно grub.cfg, включая 1280x600x32). */
#include "fb.h"
#include "font.h"
#include "mem.h"
#include "string.h"
#include "task.h"

static u32 fbw = 0, fbh = 0, fbpitch = 0, fbbpp = 0;
static u32 *lfb = NULL;       /* реальный фреймбуфер */
static u32 *back = NULL;      /* Backbuffer экрана (рисуем сюда) */
static u32 *bg = NULL;        /* фон рабочего стола */

/* ---------------- по-задачные цели рендера (многопоточный WM) ----------------
 *
 * Активный контекст рендера (цель) — «жivoй» набор глобальных переменных
 * rt_*: примитивы fb_* работают с ним. При переключении задач
 * (task_schedule -> fb_task_switch) текущий контекст сохраняется в запись
 * прежней задачи и загружается запись новой. Задача без canvas (напр.
 * kmain/task0 и внешние loader-приложения без окна) использует экранную
 * запись [0] — разделяемую, как в старой однопоточной модели.
 *
 * Canvas-контексты: marking=0 — примитивы, рисующие в canvas, НЕ трогают
 * dirty-область ЭКРАНА (координаты canvas ≠ координаты экрана); окно само
 * вызывает win_invalidate() -> fb_touch(прямоугольник окна на экране).
 * Экранная запись: marking=1/0 — управление fb_mark_enable/disable теперь
 * касается только текущей цели: touch'и из ДРУГИХ потоков не теряются. */
#define FB_MAX_CANVAS 64   /* сессия 12: было 40 — при множестве окон и c4-
 * програм слоты кончались, attach молча проваливался и окно рисовало
 * ПОВЕРХ экрана (canvas-контекст не подключился) */
typedef struct {
    u32 *base;
    int  w, h;
    int  marking;
    int  cx0, cy0, cx1, cy1;
    int  ox, oy;
} fb_ctx_t;

static fb_ctx_t fb_recs[1 + FB_MAX_CANVAS];  /* [0] = экран, [1..] = canvas */
static u8       fb_tmap[MAX_TASKS];          /* задача -> запись (0 = экран) */

/* активный (живой) контекст */
static u32 *rt_base = NULL;
static int  rt_w = 0, rt_h = 0;
static int  rt_marking = 1;
static int  rt_cx0 = 0, rt_cy0 = 0, rt_cx1 = 0, rt_cy1 = 0;
static int  rt_ox = 0, rt_oy = 0;

static void rec_save(int idx)
{
    fb_recs[idx].base    = rt_base;
    fb_recs[idx].w       = rt_w;
    fb_recs[idx].h       = rt_h;
    fb_recs[idx].marking = rt_marking;
    fb_recs[idx].cx0 = rt_cx0; fb_recs[idx].cy0 = rt_cy0;
    fb_recs[idx].cx1 = rt_cx1; fb_recs[idx].cy1 = rt_cy1;
    fb_recs[idx].ox  = rt_ox;  fb_recs[idx].oy  = rt_oy;
}

static void rec_load(int idx)
{
    rt_base    = fb_recs[idx].base;
    rt_w       = fb_recs[idx].w;
    rt_h       = fb_recs[idx].h;
    rt_marking = fb_recs[idx].marking;
    rt_cx0 = fb_recs[idx].cx0; rt_cy0 = fb_recs[idx].cy0;
    rt_cx1 = fb_recs[idx].cx1; rt_cy1 = fb_recs[idx].cy1;
    rt_ox  = fb_recs[idx].ox;  rt_oy  = fb_recs[idx].oy;
}

/* Вызывается из task_schedule (контекст IRQ0, прерывания уже запрещены). */
void fb_task_switch(int from_task, int to_task)
{
    if (from_task == to_task) return;
    if (from_task < 0 || from_task >= MAX_TASKS) return;
    if (to_task < 0 || to_task >= MAX_TASKS) return;
    rec_save(fb_tmap[from_task] ? fb_tmap[from_task] : 0);
    rec_load(fb_tmap[to_task] ? fb_tmap[to_task] : 0);
}

int fb_task_canvas_attach(int task, u32 *mem, int w, int h)
{
    if (task <= 0 || task >= MAX_TASKS || !mem || w <= 0 || h <= 0)
        return 0;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");

    /* слот уже занят чужим canvas (задачу убили, она не успела
     * отсоединиться) — освобождаем старую запись */
    if (fb_tmap[task]) {
        fb_recs[fb_tmap[task]].base = NULL;
        fb_tmap[task] = 0;
    }

    int idx = -1;
    for (int i = 1; i <= FB_MAX_CANVAS; i++) {
        if (!fb_recs[i].base) { idx = i; break; }
    }
    if (idx > 0) {
        fb_recs[idx].base    = mem;
        fb_recs[idx].w       = w;
        fb_recs[idx].h       = h;
        fb_recs[idx].marking = 0;
        fb_recs[idx].cx0 = 0; fb_recs[idx].cy0 = 0;
        fb_recs[idx].cx1 = w - 1; fb_recs[idx].cy1 = h - 1;
        fb_recs[idx].ox  = 0; fb_recs[idx].oy  = 0;
        fb_tmap[task] = (u8)idx;
        /* FIX (c4gfx): attach ИЗ КОНТЕКСТА САМОЙ задачи (ленивое окно
         * графики c4-программы) — canvas должен стать активной целью
         * НЕМЕДЛЕННО: следующий fb_task_switch в эту задачу случится
         * только после вытеснения, а программа рисует ПРЯМО СЕЙЧАС.
         * Раньше rt_base оставался экраном и рисунок уходил мимо
         * canvas (композитор его стирал). */
        if (task_current() == task) rec_load(idx);
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return idx > 0;
}

void fb_task_canvas_detach(int task)
{
    if (task <= 0 || task >= MAX_TASKS) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (fb_tmap[task]) {
        fb_recs[fb_tmap[task]].base = NULL;
        fb_tmap[task] = 0;
        /* если отсоединяемся сами (текущая задача) — сразу вернуть
         * экранную запись, чтобы дальнейший вывод шёл на экран */
        if (task_current() == task) rec_load(0);
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* Сессия 12: есть ли у задачи подключённый canvas? Поток окна ждёт
 * этого ПЕРЕД первым рисованием: между task_spawn() и attach() в
 * win_create() нас может вытеснить, и рисование без canvas ушло бы
 * в ЭКРАННЫЙ контекст — прямо поверх чужих окон (это и было
 * «окна прорисовываются сквозь друг друга»). */
int fb_task_has_canvas(int task)
{
    if (task <= 0 || task >= MAX_TASKS) return 0;
    return fb_tmap[task] != 0;
}

/* dirty-область кадра (только для ЭКРАНА) */
static int d_x0 = 0x7FFFFFFF, d_y0 = 0x7FFFFFFF, d_x1 = -0x7FFFFFFF, d_y1 = -0x7FFFFFFF;

static int glyph_index(unsigned cp)
{
    if (cp >= 0x20 && cp <= 0x7E)  return (int)cp - 0x20;
    if (cp >= 0x410 && cp <= 0x44F) return 95 + (int)cp - 0x410;
    switch (cp) {
    case 0x401: return 159; /* Ё */
    case 0x451: return 160; /* ё */
    case 0x0AB: return 161; /* « */
    case 0x0BB: return 162; /* » */
    case 0x0B0: return 163; /* ° */
    }
    return -1;
}

int fb_init(const mb_info_t *mb)
{
    int have_mb = (mb->flags & MBIF_FRAMEBUFFER) &&
                  mb->framebuffer_type == MB_FT_RGB &&
                  mb->framebuffer_bpp >= 16 &&
                  mb->framebuffer_addr && mb->framebuffer_width;

    if (!have_mb) {
        /* Headless-фолбэк (сессия 13): эмулятор не выставил VESA (Bochs в
         * некоторых конфигурациях, текстовые VGA). Поднимаем RAM-backed
         * фреймбуфер 1024x768x32: ОС и приложения работают «вслепую», но
         * serial/klog/WM живы — пригодно для автотестов (AUTORUN) и для
         * машин, где GRUB не смог переключить видеорежим. На реальном
         * железе GRUB+VESA даёт настоящий LFB — сюда не попадаем. */
        extern void serial_puts(const char *s);
        serial_puts("[fb] no VESA LFB: headless RAM-фреймбуфер 1024x768\n");
        fbw = 1024;
        fbh = 768;
        fbbpp = 32;
        fbpitch = fbw * 4;
        lfb = (u32 *)malloc(fbw * fbh * 4);
        if (!lfb) return 0;
    } else {
        fbw = mb->framebuffer_width;
        fbh = mb->framebuffer_height;
        fbpitch = mb->framebuffer_pitch;
        fbbpp = mb->framebuffer_bpp;
        lfb = (u32 *)(u32)mb->framebuffer_addr;
    }

    /* Backbuffer всегда 32-битный (внутренний формат), конвертируем при flush. */
    back = (u32 *)malloc(fbw * fbh * 4);
    bg = (u32 *)malloc(fbw * fbh * 4);
    if (!back || !bg) return 0;

    /* экранная запись контекста [0] */
    fb_recs[0].base    = back;
    fb_recs[0].w       = (int)fbw;
    fb_recs[0].h       = (int)fbh;
    fb_recs[0].marking = 1;
    fb_recs[0].cx0 = 0; fb_recs[0].cy0 = 0;
    fb_recs[0].cx1 = (int)fbw - 1; fb_recs[0].cy1 = (int)fbh - 1;
    fb_recs[0].ox  = 0; fb_recs[0].oy  = 0;
    for (int i = 0; i < MAX_TASKS; i++) fb_tmap[i] = 0;
    rec_load(0);

    fb_set_clip(0, 0, (int)fbw - 1, (int)fbh - 1);
    fb_touch_all();
    return 1;
}

int fb_ready(void) { return back != NULL; }
u32 fb_rgb(u8 r, u8 g, u8 b) { return 0xFF000000u | ((u32)r << 16) | ((u32)g << 8) | b; }
u32 fb_width(void)  { return fbw; }
u32 fb_height(void) { return fbh; }
u32 fb_bpp(void)    { return fbbpp; }
u32 fb_pitch(void)  { return fbpitch; }

/* Прокрутка экрана вверх на px пикселей (консоль загрузки).
 * Сдвигаем backbuffer, нижнюю полосу очищаем. Вызывающий код затем
 * рисует новую строку лога внизу и делает fb_flush(). Без этого
 * загрузочный лог при >45 строках (1024x768) уходил за нижний край
 * экрана и его было не прочитать. */
void fb_scroll_up(int px)
{
    if (!back || px <= 0) return;
    if ((u32)px > fbh) px = (int)fbh;
    u32 rows = fbh - (u32)px;
    if (rows)
        memmove(back, back + (u32)px * fbw, rows * fbw * 4);
    fb_fill_rect(0, (int)fbh - px, (int)fbw, px, fb_rgb(0x00, 0x00, 0x00));
    fb_touch_all();
}

/* ------------------------------ фон стола ------------------------------ */

void fb_make_bg(void)
{
    u32 top = fb_rgb(0x21, 0x26, 0x2D);
    u32 bot = fb_rgb(0x0B, 0x0D, 0x10);
    for (u32 y = 0; y < fbh; y++) {
        u32 t = (y * 256u) / (fbh ? fbh : 1);
        u32 r = ((top >> 16) & 0xFF) + ((((bot >> 16) & 0xFF) - ((top >> 16) & 0xFF)) * t) / 256;
        u32 g = ((top >> 8) & 0xFF) + ((((bot >> 8) & 0xFF) - ((top >> 8) & 0xFF)) * t) / 256;
        u32 b = (top & 0xFF) + (((bot & 0xFF) - (top & 0xFF)) * t) / 256;
        u32 c = fb_rgb((u8)r, (u8)g, (u8)b);
        u32 *row = bg + (u32)y * fbw;
        for (u32 x = 0; x < fbw; x++) row[x] = c;
    }
    /* едва заметный водяной знак */
    const char *wm = "N2600-OS";
    u32 wc = fb_rgb(0x19, 0x1E, 0x25);
    u32 tw = fb_text_w(wm);
    fb_text((int)fbw - tw - 24, (int)fbh - 28 - 16 - 24, wm, wc, -1);
}

/* ---------------------------- dirty-область ---------------------------- */

/* FIX (многопоточность): dirty-область ЭКРАНА общая для всех задач.
 * touch из разных потоков теперь атомарен (запрет прерываний на время
 * обновления границ), иначе пропущенные обновления экрана. */
void fb_mark_enable(void)  { rt_marking = 1; }
void fb_mark_disable(void) { rt_marking = 0; }

void fb_touch(int x, int y, int w, int h)
{
    /* ЯВНАЯ отметка ЭКРАННОЙ области (в отличие от авто-touch примитивов):
     * работает из ЛЮБОГО контекста (поток окна помечает свой прямоугольник
     * после отрисовки canvas). Была ошибка: раньше touch гейтился rt_marking
     * текущей цели — для canvas-контекста (marking=0) ЯВНЫЕ отметки
     * поглощались, и экран не обновлялся. */
    if (!back) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > (int)fbw) w = (int)fbw - x;
    if (y + h > (int)fbh) h = (int)fbh - y;
    if (w > 0 && h > 0) {
        if (x < d_x0) d_x0 = x;
        if (y < d_y0) d_y0 = y;
        if (x + w - 1 > d_x1) d_x1 = x + w - 1;
        if (y + h - 1 > d_y1) d_y1 = y + h - 1;
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

void fb_touch_all(void)
{
    if (!rt_marking || !back) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    d_x0 = 0; d_y0 = 0; d_x1 = (int)fbw - 1; d_y1 = (int)fbh - 1;
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

int fb_dirty(int *x0, int *y0, int *x1, int *y1)
{
    if (d_x0 > d_x1 || d_y0 > d_y1 || !back) return 0;
    if (x0) *x0 = d_x0;
    if (y0) *y0 = d_y0;
    if (x1) *x1 = d_x1;
    if (y1) *y1 = d_y1;
    return 1;
}

void fb_flush(void)
{
    if (!lfb || !back || d_x0 > d_x1 || d_y0 > d_y1) {
        d_x0 = d_y0 = 0x7FFFFFFF; d_x1 = d_y1 = -0x7FFFFFFF;
        return;
    }
    u8 *dst = (u8 *)lfb;
    const u32 *src32 = back;
    int w = d_x1 - d_x0 + 1;

    if (fbbpp == 32) {
        /* Fast path: прямой memcpy по 4 байта на пиксель */
        for (int y = d_y0; y <= d_y1; y++) {
            memcpy(dst + (u32)y * fbpitch + (u32)d_x0 * 4,
                   (const u8 *)(src32 + (u32)y * fbw + (u32)d_x0),
                   (u32)w * 4);
        }
    }
    else if (fbbpp == 24) {
        /* 24bpp: конвертация 0x00RRGGBB → 3 байта (B, G, R) */
        for (int y = d_y0; y <= d_y1; y++) {
            u8 *row = dst + (u32)y * fbpitch + (u32)d_x0 * 3;
            const u32 *s = src32 + (u32)y * fbw + (u32)d_x0;
            for (int x = 0; x < w; x++) {
                u32 c = s[x];
                row[x * 3]     = (u8)(c);          /* B */
                row[x * 3 + 1] = (u8)(c >> 8);     /* G */
                row[x * 3 + 2] = (u8)(c >> 16);     /* R */
            }
        }
    }
    else if (fbbpp == 16) {
        /* 16bpp RGB565: конвертация 0x00RRGGBB → 0xRRRRRGGG GGGBBBBB */
        for (int y = d_y0; y <= d_y1; y++) {
            u8 *row = dst + (u32)y * fbpitch + (u32)d_x0 * 2;
            const u32 *s = src32 + (u32)y * fbw + (u32)d_x0;
            for (int x = 0; x < w; x++) {
                u32 c = s[x];
                u8 r = (u8)((c >> 16) & 0xFF);
                u8 g = (u8)((c >> 8) & 0xFF);
                u8 b = (u8)(c & 0xFF);
                u16 rgb565 = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
                row[x * 2]     = (u8)(rgb565 & 0xFF);
                row[x * 2 + 1] = (u8)((rgb565 >> 8) & 0xFF);
            }
        }
    }
    /* Other bpp: не поддерживается, просто не выводим */
    {
        int if_had;
        __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
        d_x0 = d_y0 = 0x7FFFFFFF; d_x1 = d_y1 = -0x7FFFFFFF;
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    }
}

/* ------------------------------ примитивы ------------------------------ */

/* Авто-отметка примитивов: только если текущая цель — экран с включённым
 * маркированием (не canvas и не composite под mark_disable). */
static void prim_touch(int x, int y, int w, int h)
{
    if (!rt_marking) return;
    fb_touch(x, y, w, h);
}

void fb_set_clip(int x0, int y0, int x1, int y1)
{
    /* Жёстко зажимаем область отсечения в границах ТЕКУЩЕЙ цели рендера
     * (экран или canvas окна). Иначе при выходе за границы пиксели
     * пишутся со «сдвигом на следующую строку» — содержимое появляется
     * с противоположной стороны. */
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > rt_w - 1) x1 = rt_w - 1;
    if (y1 > rt_h - 1) y1 = rt_h - 1;

    rt_cx0 = x0; rt_cy0 = y0; rt_cx1 = x1; rt_cy1 = y1;
}

void fb_set_origin(int ox, int oy)
{
    rt_ox = ox; rt_oy = oy;
}

static inline void raw_pixel(int x, int y, u32 c)
{
    rt_base[(u32)y * (u32)rt_w + (u32)x] = c;
}

void fb_fill_screen(u32 c) { fb_fill_rect(0, 0, (int)fbw, (int)fbh, c); }

void fb_fill_rect(int x, int y, int w, int h, u32 c)
{
    x += rt_ox; y += rt_oy;
    if (x < rt_cx0) { w -= rt_cx0 - x; x = rt_cx0; }
    if (y < rt_cy0) { h -= rt_cy0 - y; y = rt_cy0; }
    if (x + w - 1 > rt_cx1) w = rt_cx1 - x + 1;
    if (y + h - 1 > rt_cy1) h = rt_cy1 - y + 1;
    if (w <= 0 || h <= 0 || !rt_base) return;
    for (int yy = y; yy < y + h; yy++) {
        u32 *row = rt_base + (u32)yy * (u32)rt_w + (u32)x;
        for (int xx = 0; xx < w; xx++) row[xx] = c;
    }
    prim_touch(x, y, w, h);
}

void fb_rect(int x, int y, int w, int h, u32 c)
{
    fb_hline(x, x + w - 1, y, c);
    fb_hline(x, x + w - 1, y + h - 1, c);
    fb_vline(x, y, y + h - 1, c);
    fb_vline(x + w - 1, y, y + h - 1, c);
}

void fb_hline(int x0, int x1, int y, u32 c)
{
    x0 += rt_ox; x1 += rt_ox; y += rt_oy;
    if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
    if (x0 < rt_cx0) x0 = rt_cx0;
    if (x1 > rt_cx1) x1 = rt_cx1;
    if (y < rt_cy0 || y > rt_cy1 || x0 > x1 || !rt_base) return;
    u32 *row = rt_base + (u32)y * (u32)rt_w;
    for (int x = x0; x <= x1; x++) row[x] = c;
    prim_touch(x0, y, x1 - x0 + 1, 1);
}

void fb_vline(int x, int y0, int y1, u32 c)
{
    x += rt_ox; y0 += rt_oy; y1 += rt_oy;
    if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
    if (y0 < rt_cy0) y0 = rt_cy0;
    if (y1 > rt_cy1) y1 = rt_cy1;
    if (x < rt_cx0 || x > rt_cx1 || y0 > y1 || !rt_base) return;
    for (int y = y0; y <= y1; y++) rt_base[(u32)y * (u32)rt_w + (u32)x] = c;
    prim_touch(x, y0, 1, y1 - y0 + 1);
}

void fb_char(int x, int y, unsigned cp, u32 fg, int bg)
{
    x += rt_ox; y += rt_oy;
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];
    for (int ry = 0; ry < 16; ry++) {
        u8 bits = g[ry];
        if (!bits) continue;
        for (int rx = 0; rx < 8; rx++) {
            if (bits & (0x80 >> rx)) {
                if (x + rx >= rt_cx0 && x + rx <= rt_cx1 &&
                    y + ry >= rt_cy0 && y + ry <= rt_cy1)
                    raw_pixel(x + rx, y + ry, fg);
            } else if (bg >= 0) {
                if (x + rx >= rt_cx0 && x + rx <= rt_cx1 &&
                    y + ry >= rt_cy0 && y + ry <= rt_cy1)
                    raw_pixel(x + rx, y + ry, (u32)bg);
            }
        }
    }
    prim_touch(x, y, 8, 16);
}

void fb_char2x(int x, int y, unsigned cp, u32 fg)
{
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];
    for (int ry = 0; ry < 16; ry++) {
        u8 bits = g[ry];
        if (!bits) continue;
        for (int rx = 0; rx < 8; rx++) {
            if (bits & (0x80 >> rx)) {
                fb_fill_rect(x + rx * 2, y + ry * 2, 2, 2, fg);
            }
        }
    }
}

void fb_text(int x, int y, const char *s, u32 fg, int bg)
{
    int cx = x;
    while (*s) {
        unsigned cp = utf8_next(&s);
        if (cp == '\n') break;
        fb_char(cx, y, cp, fg, bg);
        cx += 8;
    }
}

void fb_text_screen_centered(int clip_y0, int y, const char *s, u32 fg)
{
    int x = (int)(fbw - fb_text_w(s)) / 2;
    fb_set_clip(0, clip_y0, (int)fbw - 1, (int)fbh - 1);
    fb_text(x, y, s, fg, -1);
}

u32 fb_text_w(const char *s)
{
    return (u32)strlen(s) * 8;
}

void fb_blit_bg(int x0, int y0, int x1, int y1)
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 >= (int)fbw) x1 = (int)fbw - 1;
    if (y1 >= (int)fbh) y1 = (int)fbh - 1;
    if (x0 > x1 || y0 > y1 || !bg || !back) return;
    for (int y = y0; y <= y1; y++) {
        memcpy(back + (u32)y * fbw + (u32)x0,
               bg + (u32)y * fbw + (u32)x0,
               (u32)(x1 - x0 + 1) * 4);
    }
}

/* Blit прямоугольника из произвольного буфера в ЭКРАННЫЙ backbuffer.
 * Используется композитингом wm.c для вывода canvas'а окна на экран.
 * Клип берётся ТЕКУЩИЙ (экранный контекст kmain-задачи). */
void fb_blit_to_screen(const u32 *src, int src_w, int src_h,
                        int dx, int dy, int w, int h)
{
    if (!src || !back || w <= 0 || h <= 0 || src_w <= 0 || src_h <= 0)
        return;

    for (int row = 0; row < h; row++) {
        int sy = row;                 /* строка источника */
        int syy = dy + row;           /* строка экрана */
        if (syy < rt_cy0 || syy > rt_cy1) continue;    /* вне клипа */
        if (sy < 0 || sy >= src_h) continue;           /* вне источника */

        /* столбцы: пересечение [0,w) источника с клипом экрана */
        int sx0 = 0;
        int sx1 = w - 1;
        if (sx1 >= src_w) sx1 = src_w - 1;
        int scr_x0 = dx + sx0;
        int scr_x1 = dx + sx1;
        if (scr_x0 < rt_cx0) { sx0 += rt_cx0 - scr_x0; scr_x0 = rt_cx0; }
        if (scr_x1 > rt_cx1) { sx1 -= scr_x1 - rt_cx1; scr_x1 = rt_cx1; }
        if (scr_x0 > scr_x1 || sx0 > sx1) continue;

        memcpy(back + (u32)syy * fbw + (u32)scr_x0,
               src + (u32)sy * (u32)src_w + (u32)sx0,
               (u32)(sx1 - sx0 + 1) * 4);
    }
}
