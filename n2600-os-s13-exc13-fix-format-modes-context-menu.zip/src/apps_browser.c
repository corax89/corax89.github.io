/* apps_browser.c — веб-браузер N2600-OS.
 *
 * Возможности:
 *   - АДРЕСНАЯ СТРОКА: клик по ней или Ctrl+L — редактирование;
 *     Enter / кнопка «Go» — переход. Поддерживаются:
 *       http://host/path        — HTTP GET (в потоке ЭТОГО окна);
 *       имя файла               — открытие файла из RAM disk
 *                                 (readme.txt, help.md, demo.cs...);
 *       www.host/path           — автоматически как http://.
 *   - HTTP GET запрос (net_http_get), выполняется в потоке окна:
 *     зависший запрос больше не блокирует систему и другие окна.
 *   - HTML -> Markdown конвертер (htmlconv.c) + рендеринг Markdown.
 *   - Прокрутка (PgUp/PgDn/стрелки/колёсико).
 *
 * Исправления аудита (реализованы в htmlconv.c и здесь):
 *   [H1] бесконечный цикл in_tag — см. htmlconv.c;
 *   [H2] static char md[8192] — общий на все окна: теперь буфер
 *        выделяется на каждый вызов browser_load_content() и
 *        принадлежит вызвавшему окну (два окна не конфликтуют);
 *   [H3] entities в конце файла — см. htmlconv.c.
 *
 * Буферы этого окна (browser_t) — собственность ОДНОГО окна;
 * fetch-буфер выделяется только на время запроса.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "task.h"
#include "htmlconv.h"

#define BR_COLS 96
#define BR_ROWS 100
#define BR_HDR 22          /* высота адресной строки */
#define BR_STATUS_H 14
#define BR_MD_MAX 8192     /* буфер конвертера на вызов (FIX [H2]) */
#define BR_FETCH_MAX 16384 /* HTTP-ответ на время запроса */
#define BR_FILE_MAX 65536  /* лимит файла из RAM disk */
#define BR_ADDR_MAX 118

typedef struct {
    char lines[BR_ROWS][BR_COLS + 1];
    int  nlines;
    int  scroll;
    int  fetching;         /* 1 = идёт сетевой запрос (в этом потоке) */
    char url[128];         /* адрес текущей страницы */
    char status[80];
    /* адресная строка */
    char addr[BR_ADDR_MAX + 1];
    int  addr_len;
    int  addr_focus;       /* 1 = редактируем адрес */
    /* служебное */
    window_t *win;
    int   pad_;
} browser_t;

/* ---------- утилиты ---------- */

static int ci_eq(char a, char b)
{
    if (a >= 'A' && a <= 'Z') a += 32;
    if (b >= 'A' && b <= 'Z') b += 32;
    return a == b;
}

static int ci_same(const char *a, const char *b)
{
    while (*a && *b) {
        if (!ci_eq(*a, *b)) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* Поиск файла в RAM disk без учёта регистра.
 * Возвращает 1 и размер, если найден. */
static int ramfs_lookup(const char *name, u32 *out_size)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        if (ci_same(ents[i].name, name)) {
            if (out_size) *out_size = ents[i].size;
            return 1;
        }
    }
    return 0;
}

/* ---------- загрузка контента и конвертация ---------- */

/* Разбивка Markdown на строки (без изменений по смыслу).
 * Определена ДО browser_load_content (порядок объявления). */
static void md_to_lines(const char *md, int md_len, browser_t *b)
{
    b->nlines = 0;
    int i = 0;
    while (i < md_len && b->nlines < BR_ROWS) {
        int start = i;
        while (i < md_len && md[i] != '\n' && (i - start) < BR_COLS) i++;
        int len = i - start;
        if (len > BR_COLS) len = BR_COLS;
        memcpy(b->lines[b->nlines], md + start, len);
        b->lines[b->nlines][len] = 0;
        b->nlines++;
        if (i < md_len && md[i] == '\n') i++;
    }
}

static void browser_load_content(browser_t *b, const char *url,
                                  const char *content, int len)
{
    strncpy(b->url, url ? url : "", sizeof(b->url) - 1);
    b->url[sizeof(b->url) - 1] = 0;
    b->fetching = 0;

    /* FIX [N5]: сырой ответ HTTP-клиента содержит ЗАГОЛОВКИ
     * ("HTTP/1.0 200 OK\r\nServer:...\r\n\r\n<body>"). Раньше они
     * попадали в конвертер и на экран как текст. Отрезаем всё до
     * пустой строки — показываем только тело. */
    if (len > 5 && !strncmp(content, "HTTP/", 5)) {
        int i = 0;
        while (i < len && i < 2048) {
            if (content[i] == '\n') {
                if (i + 2 < len && content[i + 1] == '\r' && content[i + 2] == '\n') {
                    content += i + 3;
                    len -= i + 3;
                    break;
                }
                if (i + 1 < len && content[i + 1] == '\n') {
                    content += i + 2;
                    len -= i + 2;
                    break;
                }
            }
            i++;
        }
    }

    /* Это HTML или уже Markdown? */
    int is_html = 0;
    for (int i = 0; i < len && i < 200; i++) {
        if (content[i] == '<') { is_html = 1; break; }
    }

    /* FIX [H2]: буфер конвертера — локальный на вызов, не static.
     * Два окна браузера конвертируют в РАЗНЫЕ буферы. */
    char *md = (char *)malloc(BR_MD_MAX);
    if (!md) {
        snprintf(b->status, sizeof(b->status), "Нет памяти для конвертации");
        b->nlines = 0;
        return;
    }

    int md_len;
    if (is_html) {
        snprintf(b->status, sizeof(b->status),
                 "Конвертация HTML->Markdown (%d байт)...", len);
        md_len = html_to_md(content, len, md, BR_MD_MAX);
        snprintf(b->status, sizeof(b->status),
                 "HTML %d байт -> Markdown %d байт", len, md_len);
    } else {
        md_len = len < BR_MD_MAX - 1 ? len : BR_MD_MAX - 1;
        memcpy(md, content, md_len);
        md[md_len] = 0;
        snprintf(b->status, sizeof(b->status),
                 "Markdown/текст (%d байт)", len);
    }

    md_to_lines(md, md_len, b);
    free(md);

    b->scroll = 0;
    {
        /* дописать " | строк: N" без strncat (его нет в kernel string.c) */
        char tail[48];
        snprintf(tail, sizeof(tail), " | строк: %d", b->nlines);
        int pos = (int)strlen(b->status);
        int rem = (int)sizeof(b->status) - 1 - pos;
        if (rem > 0) {
            strncpy(b->status + pos, tail, rem);
            b->status[pos + ((int)strlen(tail) < rem ? (int)strlen(tail) : rem)] = 0;
        }
    }
}

/* ---------- навигация ---------- */

/* Разобрать "host" или "host:port" → хост и порт (80 по умолчанию).
 * Нужно и для http://10.0.2.2:8080/ (веб-серверы на нестандартном порту),
 * и для тестов QEMU. Возвращает 1 при успехе. */
static int br_parse_host(char *host, u16 *port)
{
    *port = 80;
    char *colon = strchr(host, ':');
    if (!colon) return 1;
    *colon = 0;
    u16 p = 0;
    for (const char *q = colon + 1; *q; q++) {
        if (*q < '0' || *q > '9') return 0;
        p = (u16)(p * 10 + (u16)(*q - '0'));
        if (p > 65535) return 0;
    }
    if (p == 0) return 0;
    *port = p;
    return 1;
}

static void br_render_now(browser_t *b)
{
    /* Немедленная отрисовка в canvas своего окна (мы в потоке окна):
     * под rlock — чтобы статус «Запрос...» был виден ДО блокирующего
     * сетевого запроса. Прямой вызов w->draw без rlock гонялся бы
     * с realloc canvas при resize. */
    if (b->win) win_draw_now(b->win);
}

static void br_navigate(browser_t *b, const char *addr)
{
    char host[128];
    char path[256];
    const char *p = addr;

    b->addr_focus = 0;

    /* Пустой ввод — ничего не делать */
    while (*p == ' ') p++;
    if (!*p) {
        win_invalidate(b->win);
        return;
    }

    /* --- ramfs-файл? (нет схемы и не похоже на URL) --- */
    int has_scheme = 0;
    for (const char *q = p; *q; q++) {
        if (q - p > 12) break;
        if (*q == ':' && q[1] == '/' && q[2] == '/') { has_scheme = 1; break; }
    }

    if (!has_scheme) {
        u32 fsize = 0;
        int is_url = 0;
        /* www.foo.bar или foo.ru — похоже на хост без схемы */
        int dots = 0, spaces = 0;
        for (const char *q = p; *q; q++) {
            if (*q == '.') dots++;
            if (*q == ' ') spaces++;
        }
        if (!strncmp(p, "www.", 4) || (dots >= 1 && spaces == 0 &&
             !strchr(p, '/')))
            is_url = 1;

        if (!is_url && ramfs_lookup(p, &fsize)) {
            /* Открываем файл из RAM disk */
            if (fsize == 0 || fsize > BR_FILE_MAX) {
                snprintf(b->status, sizeof(b->status),
                         "Файл %s: %u байт — вне лимита", p, (unsigned)fsize);
                win_invalidate(b->win);
                return;
            }
            char *buf = (char *)malloc(fsize);
            if (!buf) {
                snprintf(b->status, sizeof(b->status), "Нет памяти");
                win_invalidate(b->win);
                return;
            }
            u32 got = ramfs_read(p, buf, fsize);
            if (got == 0) {
                free(buf);
                snprintf(b->status, sizeof(b->status), "Ошибка чтения %s", p);
                win_invalidate(b->win);
                return;
            }
            strncpy(b->addr, p, BR_ADDR_MAX);
            b->addr[BR_ADDR_MAX] = 0;
            b->addr_len = (int)strlen(b->addr);
            browser_load_content(b, p, buf, (int)got);
            free(buf);
            win_invalidate(b->win);
            return;
        }
        if (!is_url) {
            snprintf(b->status, sizeof(b->status),
                     "Файл '%s' не найден в RAM disk", p);
            win_invalidate(b->win);
            return;
        }
        /* is_url: продолжаем как http:// */
    }
    else if (strncmp(p, "http://", 7) != 0) {
        snprintf(b->status, sizeof(b->status),
                 "Схема не поддерживается (только http://)");
        win_invalidate(b->win);
        return;
    }

    /* --- HTTP --- */
    if (!strncmp(p, "http://", 7)) p += 7;
    int hi = 0;
    while (*p && *p != '/' && hi < 127) {
        host[hi++] = *p++;
    }
    host[hi] = 0;
    /* host:port (порт по умолчанию 80) */
    u16 port = 80;
    if (!br_parse_host(host, &port)) {
        snprintf(b->status, sizeof(b->status), "Неверный порт в адресе");
        win_invalidate(b->win);
        return;
    }
    if (!*p) p = "/";
    strncpy(path, p, 255);
    path[255] = 0;

    if (!host[0]) {
        snprintf(b->status, sizeof(b->status), "Пустой хост");
        win_invalidate(b->win);
        return;
    }

    if (!net_nic_present() || net_get_ip() == 0) {
        snprintf(b->status, sizeof(b->status), "Сеть не настроена");
        win_invalidate(b->win);
        return;
    }

    /* Показываем статус ДО блокирующего запроса (запрос выполняется
     * в потоке ЭТОГО окна — система и остальные окна продолжают жить). */
    b->fetching = 1;
    snprintf(b->status, sizeof(b->status),
             "Запрос http://%s:%u%s ...", host, (unsigned)port, path);
    br_render_now(b);

    char *resp = (char *)malloc(BR_FETCH_MAX);
    if (!resp) {
        b->fetching = 0;
        snprintf(b->status, sizeof(b->status), "Нет памяти под ответ");
        win_invalidate(b->win);
        return;
    }

    int n = net_http_get(host, port, path, resp, BR_FETCH_MAX, 10000);
    b->fetching = 0;
    if (n > 0) {
        snprintf(b->addr, sizeof(b->addr), "http://%s:%u%s", host, (unsigned)port, path);
        b->addr[sizeof(b->addr) - 1] = 0;
        b->addr_len = (int)strlen(b->addr);
        char full[168];
        snprintf(full, sizeof(full), "http://%s:%u%s", host, (unsigned)port, path);
        browser_load_content(b, full, resp, n);
    } else {
        /* FIX [N1d]: показываем причину сбоя (connect timeout /
         * connection refused / no ARP / resolve) вместо безликого кода */
        snprintf(b->status, sizeof(b->status),
                 "Ошибка: %s (HTTP Trace покажет детали)", net_http_errstr());
    }
    free(resp);
    win_invalidate(b->win);
}

/* ---------- рендеринг ---------- */

static void br_draw(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* --- адресная строка (BR_HDR пикселей сверху) --- */
    fb_fill_rect(0, 0, cw, BR_HDR, fb_rgb(0x16, 0x1C, 0x24));
    fb_hline(0, cw - 1, BR_HDR - 1, fb_rgb(0x2C, 0x31, 0x38));

    /* поле ввода */
    int box_x = 4, box_y = 3, box_w = cw - 68, box_h = 16;
    fb_fill_rect(box_x, box_y, box_w, box_h,
                 b->addr_focus ? fb_rgb(0x0B, 0x0E, 0x11) : fb_rgb(0x1E, 0x24, 0x2C));
    fb_rect(box_x, box_y, box_w, box_h,
            b->addr_focus ? fb_rgb(0x6F, 0xB3, 0xF2) : fb_rgb(0x34, 0x3A, 0x42));

    char shown[BR_ADDR_MAX + 2];
    int max_chars = (box_w - 12) / 8;
    if (max_chars < 4) max_chars = 4;
    if (max_chars > BR_ADDR_MAX) max_chars = BR_ADDR_MAX;

    const char *src = b->addr_focus ? b->addr : (b->addr[0] ? b->addr : b->url);
    int sl = (int)strlen(src);
    int from = 0;
    if (sl > max_chars) from = sl - max_chars;   /* хвост: видно окончание */
    int tl = sl - from;
    memcpy(shown, src + from, tl);
    shown[tl] = 0;
    if (b->addr_focus && wm_blink()) {
        shown[tl] = '_';
        shown[tl + 1] = 0;
    }
    fb_text(box_x + 6, box_y + 1, shown,
            b->addr_focus ? fb_rgb(0xE6, 0xEA, 0xEE) : fb_rgb(0x9A, 0xA3, 0xAC), -1);

    if (!b->addr_focus && !b->addr[0] && !b->url[0])
        fb_text(box_x + 6, box_y + 1, "http://... или имя файла RAM disk",
                fb_rgb(0x50, 0x58, 0x62), -1);

    /* кнопка Go */
    int go_x = cw - 60, go_y = 3, go_w = 56, go_h = 16;
    fb_fill_rect(go_x, go_y, go_w, go_h, fb_rgb(0x24, 0x43, 0x5F));
    fb_rect(go_x, go_y, go_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(go_x + (go_w - 2 * 8) / 2, go_y + 1, "Go",
            fb_rgb(0xE6, 0xEA, 0xEE), -1);

    /* --- контент --- */
    int area_y = BR_HDR;
    int area_h = ch - BR_HDR - BR_STATUS_H;
    int vis = area_h / 16;
    if (vis < 1) vis = 1;

    fb_fill_rect(0, area_y, cw, area_h, fb_rgb(0x0B, 0x0E, 0x11));

    int max_scroll = b->nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (b->scroll > max_scroll) b->scroll = max_scroll;
    if (b->scroll < 0) b->scroll = 0;

    int start = b->scroll;
    int end = start + vis;
    if (end > b->nlines) end = b->nlines;

    int y = area_y + 2;
    for (int i = start; i < end; i++, y += 16) {
        u32 color = fb_rgb(0xE6, 0xEA, 0xEE);
        if (b->lines[i][0] == '#') color = fb_rgb(0xFF, 0xE0, 0x60);      /* заголовки */
        else if (b->lines[i][0] == '[') color = fb_rgb(0x6F, 0xB3, 0xF2); /* ссылки */
        else if (b->lines[i][0] == '-') color = fb_rgb(0x9A, 0xA3, 0xAC); /* списки */

        int max_chars2 = (cw - 8) / 8;
        char tmp[BR_COLS + 1];
        int sl = (int)strlen(b->lines[i]);
        if (sl > max_chars2) sl = max_chars2;
        memcpy(tmp, b->lines[i], sl);
        tmp[sl] = 0;
        fb_text(4, y, tmp, color, -1);
    }

    /* полоса прокрутки */
    if (max_scroll > 0) {
        int sb_x = cw - 6;
        int sb_h = area_h - 4;
        fb_fill_rect(sb_x, area_y + 2, 4, sb_h, fb_rgb(0x1E, 0x22, 0x28));
        int thumb_h = sb_h * vis / b->nlines;
        if (thumb_h < 8) thumb_h = 8;
        int thumb_y = area_y + 2 + (sb_h - thumb_h) * (max_scroll - b->scroll) / max_scroll;
        fb_fill_rect(sb_x, thumb_y, 4, thumb_h, fb_rgb(0x6F, 0xB3, 0xF2));
    }

    /* --- статус-бар --- */
    fb_fill_rect(0, ch - BR_STATUS_H, cw, BR_STATUS_H, fb_rgb(0x12, 0x16, 0x1B));
    char st[112];
    snprintf(st, sizeof(st), "%s%s | прокрутка: %d/%d",
             b->fetching ? "* " : "", b->status, b->scroll, max_scroll);
    fb_text(4, ch - BR_STATUS_H + 2, st, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

/* ---------- ввод ---------- */

static void br_key(window_t *w, const key_event_t *ev)
{
    browser_t *b = (browser_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* Ctrl+L — фокус на адресную строку (как в больших браузерах) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'l' || ev->ch == 'L' || ev->ch == 0x0C)) {
        b->addr_focus = 1;
        win_invalidate(w);
        return;
    }

    /* --- режим редактирования адреса --- */
    if (b->addr_focus) {
        if (ev->ch == 0x1B || ev->code == 0x01) {          /* Esc */
            b->addr_focus = 0;
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n') {          /* Enter */
            br_navigate(b, b->addr);
            return;
        }
        if (ev->code == 0x0E) {                            /* Backspace */
            if (b->addr_len > 0) {
                b->addr[--b->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        if (ev->ch >= 0x20 && ev->ch < 0x7F && !(ev->flags & KF_CTRL)) {
            if (b->addr_len < BR_ADDR_MAX) {
                b->addr[b->addr_len++] = ev->ch;
                b->addr[b->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        return;   /* прочие клавиши в режиме ввода игнорируем */
    }

    /* --- обычный режим: прокрутка --- */
    int ch = win_content_h(w);
    int vis = (ch - BR_HDR - BR_STATUS_H) / 16;
    int max_scroll = b->nlines - vis;
    if (max_scroll < 0) max_scroll = 0;

    if (ev->code == 0x49 || ev->code == KBD_UP) {          /* PgUp/вверх */
        if (b->scroll < max_scroll) b->scroll++;
        win_invalidate(w);
    } else if (ev->code == 0x51 || ev->code == KBD_DOWN) { /* PgDn/вниз */
        if (b->scroll > 0) b->scroll--;
        win_invalidate(w);
    } else if (ev->code == 0x47) {                          /* Home */
        b->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == 0x4F) {                          /* End */
        b->scroll = 0;
        win_invalidate(w);
    } else if (ev->ch == 0x1B || ev->code == 0x01) {
        win_close(w);
    }
}

static void br_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    browser_t *b = (browser_t *)w->data;
    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT))
        return;                       /* интересует только нажатие ЛКМ */

    if (my < 0 || mx < 0) return;
    int cw = win_content_w(w);

    if (my < BR_HDR) {
        /* полоса адреса */
        if (mx >= cw - 60 && mx < cw - 4) {
            br_navigate(b, b->addr);   /* кнопка Go */
        } else if (mx < cw - 64) {
            if (!b->addr_focus) {
                b->addr_focus = 1;
                win_invalidate(w);
            }
        }
        return;
    }
    /* клик по контенту снимает фокус с адресной строки */
    if (b->addr_focus) {
        b->addr_focus = 0;
        win_invalidate(w);
    }
}

static void br_close(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    if (b) free(b);
}

/* ---------- стартовая страница ---------- */

static const char *br_help_md =
    "# Браузер N2600-OS\n\n"
    "## Адресная строка\n"
    "- Клик по ней или **Ctrl+L** — редактирование\n"
    "- **Enter** или кнопка **Go** — переход\n"
    "- `http://host/path` — HTTP-запрос (выполняется в потоке этого окна: "
    "зависший запрос не вешает систему)\n"
    "- Имя файла (`help.md`, `readme.txt`, `demo.cs`) — открыть файл "
    "из RAM disk\n\n"
    "## Поддержка Markdown\n"
    "- Заголовки `#`, `##`, `###`\n"
    "- **Жирный**, *курсив*, `код`\n"
    "- Списки и ссылки [текст]()\n\n"
    "## Команды терминала\n"
    "- `curl http://example.com/` — загрузить страницу в новое окно\n"
    "- `spawn browser` — ещё одно окно браузера\n\n"
    "---\n"
    "Прокрутка: PgUp/PgDn, стрелки, колёсико мыши\n";

/* ---------- создание окна ---------- */

static browser_t *br_new_state(void)
{
    browser_t *b = (browser_t *)malloc(sizeof(browser_t));
    if (!b) return NULL;
    memset(b, 0, sizeof(*b));
    strncpy(b->url, "help", sizeof(b->url) - 1);
    strcpy(b->status, "Готово");
    return b;
}

static void br_open_common(browser_t *b, int load_help)
{
    if (load_help) {
        browser_load_content(b, "help", br_help_md, (int)strlen(br_help_md));
        strcpy(b->addr, "help");
        b->addr_len = (int)strlen(b->addr);
    }

    u32 W = fb_width(), H = fb_height();
    int ww = 700;
    int wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    window_t *w = win_create("Браузер", (int)W / 2 - ww / 2, 16, ww, wh,
                              br_draw, br_key, br_mouse, NULL, br_close, b);
    if (!w) {
        free(b);
        return;
    }
    b->win = w;
}

void app_browser_open(void)
{
    browser_t *b = br_new_state();
    if (!b) return;
    br_open_common(b, 1);
}

void app_browser_open_with(const char *url, const char *content, int len)
{
    browser_t *b = br_new_state();
    if (!b) return;
    browser_load_content(b, url ? url : "(curl)", content, len);
    if (url) {
        strncpy(b->addr, url, BR_ADDR_MAX);
        b->addr[BR_ADDR_MAX] = 0;
        b->addr_len = (int)strlen(b->addr);
    }
    br_open_common(b, 0);
}
