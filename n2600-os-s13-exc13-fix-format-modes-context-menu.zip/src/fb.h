/* fb.h — фреймбуфер VESA LFB (из Multiboot), двойная буферизация, примитивы */
#ifndef FB_H
#define FB_H

#include "types.h"
#include "boot.h"

int   fb_init(const mb_info_t *mb);
int   fb_ready(void);
u32   fb_rgb(u8 r, u8 g, u8 b);
u32   fb_width(void);
u32   fb_height(void);
u32   fb_bpp(void);
u32   fb_pitch(void);

void  fb_make_bg(void);                     /* построить фон рабочего стола */
void  fb_scroll_up(int px);                 /* прокрутка экрана вверх (консоль загрузки) */

void  fb_mark_enable(void);                 /* вкл/выкл накопление dirty-области */
void  fb_mark_disable(void);
void  fb_touch(int x, int y, int w, int h); /* пометить область на вывод */
void  fb_touch_all(void);
void  fb_flush(void);                       /* копировать помеченное в LFB */
int   fb_dirty(int *x0, int *y0, int *x1, int *y1);                       /* копировать помеченное в реальный LFB */

void  fb_set_clip(int x0, int y0, int x1, int y1);
void  fb_set_origin(int ox, int oy);  /* приложения рисуют от левого-верхнего угла содержимого */

void  fb_fill_screen(u32 c);
void  fb_fill_rect(int x, int y, int w, int h, u32 c);
void  fb_rect(int x, int y, int w, int h, u32 c);
void  fb_hline(int x0, int x1, int y, u32 c);
void  fb_vline(int x, int y0, int y1, u32 c);

void  fb_char(int x, int y, unsigned cp, u32 fg, int bg); /* bg=-1: прозрачный фон */
void  fb_char2x(int x, int y, unsigned cp, u32 fg);
void  fb_text(int x, int y, const char *s, u32 fg, int bg);
void  fb_text_screen_centered(int clip_y0, int y, const char *s, u32 fg);
u32   fb_text_w(const char *s);
void  fb_blit_bg(int x0, int y0, int x1, int y1);

/* Копировать прямоугольник w x h из src (строка src_w пикселей) в
 * ЭКРАННЫЙ backbuffer с позиции (dx,dy), honouring текущий клип экрана.
 * Выходы за границы src и экрана обрезаются. Для композитинга canvas'ов
 * окон (wm.c). */
void  fb_blit_to_screen(const u32 *src, int src_w, int src_h,
                         int dx, int dy, int w, int h);

/* ---------------- по-задачные цели рендера (многопоточный WM) ----------------
 *
 * Каждое окно WM рисует в СОБСТВЕННЫЙ canvas (пиксельный буфер размера
 * содержимого окна) из СВОЕГО потока. fb.c подкачивает активный контекст
 * (base/ширина/клип/origin/marking) при переключении задач:
 * task_schedule() вызывает fb_task_switch(из, в).
 *
 * fb_width()/fb_height() — всегда РАЗМЕР ЭКРАНА (для раскладки окон);
 * размеры цели рендера видны только внутри примитивов fb_*.
 *
 * fb_task_canvas_attach() вызывается wm.c при создании окна;
 * поток окна сам вызывает fb_task_canvas_detach() перед завершением. */
int   fb_task_canvas_attach(int task, u32 *mem, int w, int h); /* 1=ок */
void  fb_task_canvas_detach(int task);
int   fb_task_has_canvas(int task);   /* 1 = canvas подключён (сессия 12) */
void  fb_task_switch(int from_task, int to_task);  /* из task_schedule */

#endif /* FB_H */
