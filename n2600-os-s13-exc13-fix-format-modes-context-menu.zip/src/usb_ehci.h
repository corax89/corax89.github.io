/* usb_ehci.h — драйвер EHCI (USB 2.0) для N2600-OS.
 *
 * Реализовано:
 *   - PCI-сканирование на EHCI (class 0x0C0320).
 *   - Захват контроллера у BIOS (USBLEGSUP).
 *   - Сброс HC (USBCMD.HCRESET).
 *   - Инициализация periodic list и async list.
 *   - Структуры QH (Queue Head) и qTD (queue element TD) с 32-байтным выравниванием.
 *   - Control-трансферы: SETUP + DATA + STATUS через async schedule.
 *   - Bulk-трансферы (для mass-storage).
 *
 * Что НЕ реализовано:
 *   - Periodic schedule (interrupt transfers для HID). UHCI покрывает HID на low/full-speed.
 *   - Split transactions (TT) для low/full-speed устройств на EHCI-портах.
 *     Драйвер EHCI работает только с hi-speed устройствами (флешки).
 *
 * Взаимодействие с другими модулями:
 *   usb_ehci_init() — вызывается из usb_init() после UHCI.
 *   usb_ehci_read_sector(lba, buf) — чтение сектора 512 байт с USB-флешки.
 */
#ifndef USB_EHCI_H
#define USB_EHCI_H

#include "types.h"

void usb_ehci_init(void);
int  usb_ehci_present(void);
int  usb_ehci_storage_ready(void);

/* Чтение сектора 512 байт с USB-флешки.
 * Возвращает 1 при успехе, 0 при ошибке. */
int  usb_ehci_read_sector(u32 lba, void *buf);

/* Запись сектора 512 байт на USB-флешку (WRITE 10 + CBW с OUT data).
 * Возвращает 1 при успехе, 0 при ошибке. */
int  usb_ehci_write_sector(u32 lba, const void *buf);

#endif /* USB_EHCI_H */
