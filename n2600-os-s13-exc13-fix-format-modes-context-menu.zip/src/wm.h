/* wm.h — оконный менеджер: окна, таскбар, меню, курсор, композитинг.
 * Это публичный API для приложений N2600-OS (см. apps_example.c и README). */
#ifndef WM_H
#define WM_H

#include "types.h"
#include "kbd.h"

#define WM_MAX_WINDOWS 32

#define TBAR_H   28   /* высота таскбара */
#define TITLE_H  24   /* высота заголовка окна */

struct window;

typedef void (*win_draw_fn)(struct window *);
typedef void (*win_key_fn)(struct window *, const key_event_t *);
typedef void (*win_mouse_fn)(struct window *, int mx, int my, u8 buttons, u8 changed);
typedef void (*win_tick_fn)(struct window *);
typedef void (*win_close_fn)(struct window *);

typedef struct window {
    int x, y, w, h;        /* геометрия вместе с рамкой */
    int minimized;          /* 1 = свёрнуто (не отрисовывается) */
    int maximized;          /* 1 = развёрнуто на весь экран (кроме таскбара) */
    int prev_x, prev_y, prev_w, prev_h;  /* геометрия до сворачивания/разворота */
    u32 serial;             /* порядковый номер создания (стабильный порядок
                             * кнопок на таскбаре — FIX [W1]) */
    char title[40];
    void *data;            /* состояние приложения (malloc/free) */
    win_draw_fn   draw;     /* отрисовка содержимого (клип уже установлен) */
    win_key_fn    on_key;   /* клавиатура (только у окна в фокусе) */
    win_mouse_fn  on_mouse; /* мышь: координаты относительно содержимого */
    win_tick_fn   on_tick;  /* вызывается 2 раза в секунду */
    win_close_fn  on_close; /* освободить data перед закрытием */

    /* ---- многопоточный WM (внутреннее, приложения не используют) ----
     * КАЖДОЕ окно работает в собственном потоке: все колбэки (draw/
     * on_key/on_mouse/on_tick/on_close) выполняются в нём и рисуют в
     * собственный canvas. Зависание одного приложения больше не
     * останавливает систему и остальные окна. */
    int   task;            /* индекс задачи потока окна, -1 = нет */
    u32  *canvas;          /* пиксельный буфер содержимого (cvs_w x cvs_h) */
    int   cvs_w, cvs_h;
    int   fixed_size;      /* 1 = resize/maximize запрещены (canvas рисует
                            * ВНЕШНЯЯ задача — realloc canvas отвалил бы её
                            * указатель; см. c4gfx.c) */
    void  *thr;            /* wm-внутренность: очередь событий, блокировки */
} window_t;

/* создать окно (добавляется поверх остальных, окно в фокусе) */
window_t *win_create(const char *title, int x, int y, int w, int h,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data);

/* пометить окно к закрытию (безопасно вызывать из любого колбэка) */
void win_close(window_t *w);
void win_set_no_canvas(window_t *w);   /* сессия 12: canvas вне потока (c4gfx) */

/* запросить перерисовку содержимого окна */
void win_invalidate(window_t *w);

/* НЕМЕДЛЕННАЯ отрисовка canvas окна. Должна вызываться ПОТОКОМ САМОГО
 * окна (из колбэка): под rlock (vs realloc при resize). Нужна, когда
 * приложение хочет показать статус ДО долгой блокирующей работы
 * (напр. сетевой запрос в браузере). */
void win_draw_now(window_t *w);

/* свернуть/восстановить окно */
void win_minimize(window_t *w);
void win_restore(window_t *w);
int  win_is_minimized(window_t *w);

/* развернуть на весь экран (заголовок и таскбар сохраняются) /
 * вернуть прежний размер. Двойной клик по заголовку — тоже переключает. */
void win_maximize(window_t *w);
void win_unmaximize(window_t *w);
void win_toggle_maximize(window_t *w);
int  win_is_maximized(window_t *w);

int  win_content_w(window_t *w);
int  win_content_h(window_t *w);

void wm_init(void);
void wm_key(const key_event_t *ev);
void wm_mouse_poll(void);   /* обработать накопившиеся события мыши */
void wm_halfsec(void);      /* тик 2 Гц (мигание курсора, on_tick, часы) */
void wm_frame(void);        /* композитинг и вывод помеченных областей */

int  wm_blink(void);        /* 0/1 для мигающего курсора */
int  wm_window_count(void);          /* общее число (включая свёрнутые) */
int  wm_window_visible_count(void);  /* видимые (не свёрнутые) */
const char *wm_window_title(int i);
int  wm_window_minimized(int i);
int  wm_window_focused(int i);
window_t *wm_window_at(int i);

/* ---- многопоточный WM: служебное (для диспетчера задач и ядра) ---- */
int  wm_task_of(window_t *w);          /* индекс задачи потока окна или -1 */
window_t *wm_find_by_task(int task_idx); /* окно по задаче или NULL */
void wm_request_kill(int task_idx);   /* убить поток окна и окно (мягко:
                                         просим kmain — обработается в
                                         ближайшем wm_frame) */
void wm_pump_kills(void);             /* обработать отложенные kill (из
                                         главного цикла/kmain) */
int  wm_test_glock_spin(void);        /* ТЕСТ живучести (команда spinlock):
                                         задача берёт wm_glock и зависает;
                                         система должна ожить через ~20 с */

/* ===================== контекстное меню (сессия 13) =====================
 * ПЕРЕИСПОЛЬЗУЕМЫЙ компонент для ЛЮБЫХ приложений. Открытие — из on_mouse
 * потока окна (обычно по правой кнопке):
 *     wm_menu_open(w, mx, my, items, n, cb, uctx);
 * mx,my — координаты ОТНОСИТЕЛЬНО содержимого окна w. Выбор пункта
 * доставляется потоку окна-владельца (WEV_MENU): колбэк cb(id, uctx)
 * исполняется в ЕГО потоке — данные приложения защищены от гонок.
 * Закрытие: выбор пункта, Esc, клик мимо меню. item.label == NULL —
 * разделитель. disabled=1 — пункт серый и не выбирается. */
typedef struct {
    const char *label;        /* NULL = разделитель */
    int  id;                  /* идентификатор в колбэке */
    u8   disabled;            /* 1 = недоступен */
} wm_menu_item_t;
typedef void (*wm_menu_fn)(int id, void *uctx);
void wm_menu_open(window_t *owner, int content_x, int content_y,
                  const wm_menu_item_t *items, int n,
                  wm_menu_fn cb, void *uctx);
void wm_menu_close(void);
int  wm_menu_active(void);        /* ТЕСТ живучести (команда spinlock):
                                         задача берёт wm_glock и зависает;
                                         система должна ожить через ~20 с */

#endif /* WM_H */
