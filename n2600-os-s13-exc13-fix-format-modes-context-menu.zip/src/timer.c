/* timer.c — PIT (канал 0) на 100 Гц.
 *
 * Сами тики и uptime_sec() теперь живут в task.c (см. task_schedule),
 * потому что обработчик IRQ0 передан планировщику задач для переключения
 * контекста. Здесь остаётся только инициализация PIT.
 */
#include "timer.h"
#include "io.h"
#include "idt.h"

void timer_init(int hz)
{
    if (hz < 20) hz = 20;
    if (hz > 1000) hz = 1000;
    u32 div = 1193182u / (u32)hz;
    outb(0x43, 0x36);                 /* канал 0, режим 3, binary */
    outb(0x40, (u8)(div & 0xFF));
    outb(0x40, (u8)(div >> 8));
    /* Обработчик IRQ0 не устанавливаем: им занимается irq_stub_0 из task.c */
}
