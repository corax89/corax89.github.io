/* apps_wifi.c — графическая утилита сканирования WiFi точек доступа.
 * Сессия 11: + кнопка [Connect] (открытые сети: AUTH/ASSOC + мост
 * в сетевой стек), состояние подключения в шапке, автосохранение
 * профиля (WIFI.CFG) для автоподключения при загрузке.
 * Сессия 12: + WPA2-PSK — для защищённой сети вводится пароль
 * (поле внизу списка), тип защиты из RSN/WPA IE (Open/WPA2/WPA/WEP).
 *
 * Показывает список найденных точек доступа (SSID, BSSID, RSSI, канал,
 * безопасность) и ПОДРОБНУЮ информацию о процессе поиска:
 *   - текущий канал и прогресс (1-14)
 *   - статистику приёма: кадры / маяки / CRC-ошибки
 *   - журнал драйвера (этапы init, находки, итог скана)
 *   - причину сбоя инициализации, если адаптер не поднялся
 *
 * Данные: ath9k_wifi.c (драйвер Atheros AR9285/AR9287/AR9485).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ath9k_wifi.h"
#include "timer.h"
#include "task.h"

#define WIFI_ROWS   10
#define WIFI_COLS   76
#define WIFI_HDR    22
#define WIFI_BTN_W  80
#define WIFI_BTN_H  18
#define WIFI_LOG_H  8      /* строк журнала на панели */

typedef struct {
    wifi_ap_t aps[WIFI_MAX_APS];
    int  ap_count;
    int  sel;
    int  scroll;
    int  scanning;
    int  scan_progress;    /* индекс канала 0..13 */
    int  btn_hot;
    int  btn_pressed;
    wifi_stats_t stats;
    char logbuf[2048];
    /* сессия 12: ввод пароля WPA2 для выбранной сети */
    int  pw_mode;          /* 1 = ждём пароль */
    char pw_ssid[33];      /* к какой сети подключаемся */
    char psw[65];          /* введённый пароль */
} wifi_mgr_t;

static void wifi_start_scan(wifi_mgr_t *m) {
    if (m->scanning) return;
    if (!wifi_present()) return;
    if (!wifi_ready()) return;
    m->scanning = 1;
    m->scan_progress = 0;
    m->ap_count = 0;
    wifi_scan_start();
}

static void wifi_draw_btn(int idx, const char *label, int hot, int pressed) {
    int bx = 4 + idx * (WIFI_BTN_W + 4);
    int by = 2;
    u32 bg = pressed ? fb_rgb(0x4A, 0x7F, 0xB0) :
             hot ? fb_rgb(0x32, 0x60, 0x8E) :
             fb_rgb(0x25, 0x4A, 0x70);
    fb_fill_rect(bx, by, WIFI_BTN_W, WIFI_BTN_H, bg);
    fb_rect(bx, by, WIFI_BTN_W, WIFI_BTN_H, fb_rgb(0x6F, 0xB3, 0xF2));
    int tw = (int)strlen(label) * 8;
    fb_text(bx + (WIFI_BTN_W - tw) / 2, by + 1, label, fb_rgb(0xE6, 0xEA, 0xEE), -1);
}

static const char *security_str(u8 sec) {
    switch (sec) {
    case WIFI_SEC_OPEN:     return "Open";
    case WIFI_SEC_WPA2_PSK: return "WPA2";
    case WIFI_SEC_WPA_PSK:  return "WPA";
    default:                return "WEP/other";
    }
}

static void wifi_draw_bars(int x, int y, i8 rssi) {
    int bars = 0;
    if (rssi > -50) bars = 5;
    else if (rssi > -60) bars = 4;
    else if (rssi > -70) bars = 3;
    else if (rssi > -80) bars = 2;
    else bars = 1;
    u32 colors[] = { fb_rgb(0xFF, 0x60, 0x60), fb_rgb(0xFF, 0xA0, 0x60),
                    fb_rgb(0xFF, 0xE0, 0x60), fb_rgb(0x90, 0xEE, 0x90),
                    fb_rgb(0x60, 0xE0, 0x60) };
    for (int i = 0; i < 5; i++) {
        int h = 4 + i * 3;
        u32 c = (i < bars) ? colors[i] : fb_rgb(0x30, 0x30, 0x30);
        fb_fill_rect(x + i * 5, y + (15 - h), 4, h, c);
    }
}

static void wifi_draw(window_t *w) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Шапка */
    fb_fill_rect(0, 0, cw, WIFI_HDR, fb_rgb(0x1E, 0x4A, 0x73));
    wifi_draw_btn(0, "Scan", m->btn_hot == 0, m->btn_pressed == 0);
    wifi_draw_btn(1, "Connect", m->btn_hot == 1, m->btn_pressed == 1);

    const char *chip = wifi_present() ? wifi_chip_name() : "No WiFi adapter";
    fb_text(100, 2, chip, fb_rgb(0xC6, 0xCD, 0xD5), -1);

    /* Состояние подключения (сессия 11) */
    if (wifi_present()) {
        char cs[80];
        if (wifi_conn_ssid()[0])
            snprintf(cs, sizeof(cs), "%s: \"%s\" ch %d  %d dBm",
                     wifi_conn_state_name(), wifi_conn_ssid(),
                     wifi_conn_channel(), wifi_conn_rssi());
        else
            snprintf(cs, sizeof(cs), "%s", wifi_conn_state_name());
        fb_text(100, 12, cs,
                wifi_conn_state() == WIFI_CONN_CONNECTED
                    ? fb_rgb(0x90, 0xEE, 0x90) : fb_rgb(0x8A, 0xC8, 0xE8), -1);
    }

    if (m->scanning) {
        char pbar[80];
        snprintf(pbar, sizeof(pbar), "Scanning channel %d/14 (%u MHz)",
                 m->stats.channel ? m->stats.channel : 1,
                 (unsigned)(2407 + (m->stats.channel ? m->stats.channel : 1) * 5));
        fb_text(cw - 8 - (int)strlen(pbar) * 8, 5, pbar,
                fb_rgb(0xFF, 0xE0, 0x60), -1);
        int pw = (cw - 8) * (m->stats.channel ? m->stats.channel : 1) / 14;
        fb_fill_rect(4, WIFI_HDR - 4, pw, 2, fb_rgb(0x90, 0xEE, 0x90));
    }

    /* Заголовки колонок */
    int y0 = WIFI_HDR;
    fb_fill_rect(0, y0, cw, 18, fb_rgb(0x14, 0x18, 0x1E));
    fb_text(4, y0 + 1, "SSID                  BSSID               RSSI  Ch  Security",
            fb_rgb(0xC6, 0xCD, 0xD5), -1);

    /* Список AP */
    int area_y0 = y0 + 18;
    int log_h = WIFI_LOG_H * 11 + 16;
    int area_h = ch - area_y0 - log_h - 14;
    if (area_h < 36) area_h = 36;
    int vis = area_h / 18;
    if (vis < 1) vis = 1;
    fb_fill_rect(0, area_y0, cw, area_h, fb_rgb(0x0B, 0x0E, 0x11));

    if (!wifi_present()) {
        fb_text(12, area_y0 + 6, "WiFi adapter not found", fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, area_y0 + 22, "Atheros AR9285/AR9287/AR9485 required", fb_rgb(0x8A, 0x93, 0x9C), -1);
    } else if (!wifi_ready()) {
        fb_text(12, area_y0 + 6, "Adapter init FAILED (see log below)", fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, area_y0 + 22, "Serial log has details (dmesg)", fb_rgb(0x8A, 0x93, 0x9C), -1);
    } else if (m->ap_count == 0 && !m->scanning) {
        fb_text(12, area_y0 + 6, "No access points found", fb_rgb(0x8A, 0x93, 0x9C), -1);
        fb_text(12, area_y0 + 22, "Click [Scan] to start scanning", fb_rgb(0x6F, 0xB3, 0xF2), -1);
    } else {
        int vis_max = (vis < m->ap_count) ? vis : m->ap_count;
        int y = area_y0 + 2;
        for (int i = 0; i < vis_max; i++) {
            int idx = m->scroll + i;
            if (idx >= m->ap_count) break;
            wifi_ap_t *ap = &m->aps[idx];
            char line[200];
            char ssid[21];
            int sl = (int)strlen(ap->ssid);
            if (sl > 20) sl = 20;
            memcpy(ssid, ap->ssid, sl);
            ssid[sl] = 0;
            char mac[20];
            snprintf(mac, sizeof(mac), "%02x:%02x:%02x:%02x:%02x:%02x",
                     ap->bssid[0], ap->bssid[1], ap->bssid[2],
                     ap->bssid[3], ap->bssid[4], ap->bssid[5]);
            snprintf(line, sizeof(line), "%-20s  %-17s  %4d  %2d  %-10s",
                     ssid, mac, (int)ap->rssi, (int)ap->channel,
                     security_str(ap->sec));
            u32 fg = (ap->sec == WIFI_SEC_OPEN) ? fb_rgb(0x90, 0xEE, 0x90)
                  : (ap->sec == WIFI_SEC_WPA2_PSK ? fb_rgb(0x8A, 0xC8, 0xE8)
                                                  : fb_rgb(0xC6, 0xCD, 0xD5));
            int is_sel = (i == (m->sel - m->scroll));
            if (is_sel) fb_fill_rect(0, y, cw, 18, fb_rgb(0x24, 0x43, 0x5F));
            fb_text(4, y, line, fg, -1);
            wifi_draw_bars(cw - 40, y + 1, ap->rssi);
            y += 18;
        }
    }

    /* Панель журнала драйвера — подробности поиска */
    int log_y = area_y0 + area_h;
    fb_fill_rect(0, log_y, cw, log_h, fb_rgb(0x10, 0x14, 0x18));
    fb_rect(0, log_y, cw, log_h, fb_rgb(0x2A, 0x33, 0x3D));
    fb_text(4, log_y + 2, "Driver log:", fb_rgb(0x6F, 0xB3, 0xF2), -1);
    {
        int got = wifi_log_tail(m->logbuf, sizeof(m->logbuf) - 1, WIFI_LOG_H);
        if (got > 0) {
            m->logbuf[got] = 0;
            int ly = log_y + 14;
            const char *p = m->logbuf;
            while (*p && ly < log_y + log_h - 4) {
                char line[110];
                int ll = 0;
                while (*p && *p != '\n' && ll < (int)sizeof(line) - 1)
                    line[ll++] = *p++;
                line[ll] = 0;
                if (*p == '\n') p++;
                if (ll) {
                    fb_text(8, ly, line, fb_rgb(0x9E, 0xB8, 0xC8), -1);
                }
                ly += 11;
            }
        } else {
            fb_text(8, log_y + 14, "(empty)", fb_rgb(0x5A, 0x63, 0x6C), -1);
        }
    }

    /* Сессия 12: поле ввода пароля WPA2 */
    if (m->pw_mode) {
        int pw_h = 56;
        int pw_y = ch - 14 - pw_h;
        fb_fill_rect(0, pw_y, cw, pw_h, fb_rgb(0x1A, 0x14, 0x10));
        fb_rect(0, pw_y, cw, pw_h, fb_rgb(0xE0, 0x50, 0x50));
        char lt[128];
        snprintf(lt, sizeof(lt), "Пароль WPA2 для \"%s\"", m->pw_ssid);
        fb_text(8, pw_y + 4, lt, fb_rgb(0xFF, 0xC0, 0x40), -1);
        fb_fill_rect(8, pw_y + 22, cw - 16, 18, fb_rgb(0x0B, 0x0E, 0x11));
        fb_rect(8, pw_y + 22, cw - 16, 18, fb_rgb(0x2C, 0x31, 0x38));
        {
            int n = (int)strlen(m->psw);
            if (n > (cw - 40) / 8) n = (cw - 40) / 8;
            char stars[80];
            if (n > (int)sizeof(stars) - 1) n = (int)sizeof(stars) - 1;
            for (int i = 0; i < n; i++) stars[i] = '*';
            stars[n] = 0;
            if (stars[0]) fb_text(12, pw_y + 26, stars, fb_rgb(0xE6, 0xEA, 0xEE), -1);
        }
        fb_text(8, pw_y + 44,
                "Enter: подключиться    Esc: отмена    Backspace: стереть",
                fb_rgb(0x9E, 0xB8, 0xC8), -1);
    }

    /* Статус-строка */
    fb_fill_rect(0, ch - 14, cw, 14, fb_rgb(0x12, 0x16, 0x1B));
    char s2[120];
    if (m->pw_mode)
        snprintf(s2, sizeof(s2), "Ввод пароля WPA2 (%d симв.)",
                 (int)strlen(m->psw));
    else if (m->scanning)
        snprintf(s2, sizeof(s2), "Scanning ch %d/14 | %d AP | pass %d",
                 m->stats.channel ? m->stats.channel : 1, m->ap_count,
                 m->stats.pass);
    else
        snprintf(s2, sizeof(s2), "%d AP | F1=Scan, F2=Connect, Up/Dn, Esc",
                 m->ap_count);
    fb_text(4, ch - 12, s2, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

static void wifi_tick(window_t *w) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    wifi_get_stats(&m->stats);
    if (m->scanning) {
        m->scan_progress = m->stats.channel ? m->stats.channel - 1 : 0;
        m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
        if (!wifi_scan_active()) m->scanning = 0;
    }
    win_invalidate(w);
}

/* Сессия 12: подключение к выбранной сети (с учётом защиты) */
static void wifi_connect_selected(wifi_mgr_t *m) {
    if (m->sel < 0 || m->sel >= m->ap_count) return;
    wifi_ap_t *ap = &m->aps[m->sel];
    if (ap->sec == WIFI_SEC_WPA2_PSK) {
        char ssid[33], psk[65];
        if (wifi_profile_load(ssid, sizeof(ssid)) &&
            strcmp(ssid, ap->ssid) == 0 &&
            wifi_profile_load_psk(psk, sizeof(psk))) {
            if (wifi_connect_psk(ap->ssid, psk))
                m->scanning = wifi_scan_active();
        } else {
            m->pw_mode = 1;               /* просим пароль */
            m->psw[0] = 0;
            strncpy(m->pw_ssid, ap->ssid, sizeof(m->pw_ssid) - 1);
            m->pw_ssid[sizeof(m->pw_ssid) - 1] = 0;
            wifi_log("Connect: введите пароль WPA2 для \"%s\"", ap->ssid);
        }
    } else if (ap->sec == WIFI_SEC_OPEN) {
        if (wifi_connect(ap->ssid))
            m->scanning = wifi_scan_active();
    } else {
        wifi_log("Connect: \"%s\" — %s не поддерживается", ap->ssid,
                 ap->sec == WIFI_SEC_WPA_PSK ? "WPA/TKIP" : "этот тип защиты");
    }
}

static void wifi_key(window_t *w, const key_event_t *ev) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* --- режим ввода пароля WPA2 (сессия 12) --- */
    if (m->pw_mode) {
        if (ev->ch == 0x1B || ev->code == 0x01) {
            m->pw_mode = 0;
            wifi_log("ввод пароля отменён");
        } else if (ev->code == 0x1C || ev->ch == '\n') {
            m->pw_mode = 0;
            if (strlen(m->psw) >= 8) {
                if (wifi_connect_psk(m->pw_ssid, m->psw))
                    m->scanning = wifi_scan_active();
            } else {
                wifi_log("пароль короче 8 символов — отмена");
            }
        } else if (ev->code == 0x0E) {          /* Backspace */
            int nn = (int)strlen(m->psw);
            if (nn > 0) m->psw[nn - 1] = 0;
        } else if (ev->ch >= 0x20 && ev->ch < 0x7F) {
            int nn = (int)strlen(m->psw);
            if (nn < (int)sizeof(m->psw) - 1) {
                m->psw[nn] = (char)ev->ch;
                m->psw[nn + 1] = 0;
            }
        }
        win_invalidate(w);
        return;
    }

    if (ev->code == 0x3B || ev->ch == 's' || ev->ch == 'S') {  /* F1 or S */
        wifi_start_scan(m);
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x3C || ev->ch == 'c' || ev->ch == 'C') {  /* F2 or C */
        wifi_connect_selected(m);
        win_invalidate(w);
        return;
    }
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == KBD_UP) {
        if (m->sel > 0) m->sel--;
        win_invalidate(w);
    }
    if (ev->code == KBD_DOWN) {
        if (m->sel + 1 < m->ap_count) m->sel++;
        win_invalidate(w);
    }
}

static void wifi_mouse(window_t *w, int mx, int my, u8 btn, u8 changed) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;

    if (my < WIFI_HDR) {
        if (my >= 2 && my < 2 + WIFI_BTN_H) {
            for (int b = 0; b < 2; b++) {
                int bx = 4 + b * (WIFI_BTN_W + 4);
                if (mx >= bx && mx < bx + WIFI_BTN_W) {
                    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
                        m->btn_pressed = b;
                    }
                    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT) &&
                        m->btn_pressed == b) {
                        m->btn_pressed = -1;
                        if (b == 0) {
                            wifi_start_scan(m);
                        } else if (!m->pw_mode) {
                            wifi_connect_selected(m);
                        }
                    }
                    if (m->btn_hot != b) {
                        m->btn_hot = b;
                        win_invalidate(w);
                    }
                    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT))
                        win_invalidate(w);
                    return;
                }
            }
        }
        if (m->btn_hot != -1 || m->btn_pressed != -1) {
            m->btn_hot = -1;
            m->btn_pressed = -1;
            win_invalidate(w);
        }
        return;
    }
}

static void wifi_close(window_t *w) {
    if (w->data) free(w->data);
}

void app_wifi_open(void) {
    wifi_mgr_t *m = (wifi_mgr_t *)malloc(sizeof(wifi_mgr_t));
    if (!m) return;
    memset(m, 0, sizeof(wifi_mgr_t));
    m->btn_hot = -1;
    m->btn_pressed = -1;

    m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
    wifi_get_stats(&m->stats);

    u32 W = fb_width(), H = fb_height();
    int ww = WIFI_COLS * 8 + 12;
    int wh = WIFI_ROWS * 18 + WIFI_HDR + 18 + (WIFI_LOG_H * 11 + 16) + 14 + 24 + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    win_create("WiFi Scanner", 120, 30, ww, wh,
               wifi_draw, wifi_key, wifi_mouse, wifi_tick, wifi_close, m);
}
