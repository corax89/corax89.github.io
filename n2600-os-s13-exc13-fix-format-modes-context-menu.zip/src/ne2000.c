/* ne2000.c — драйвер NE2000 (8390) PCI Ethernet для N2600-OS.
 *
 * ПЕРЕПИСАН (сессия 7). Прежняя версия НЕ РАБОТАЛА ВООБЩЕ (из-за неё
 * «DHCP не ответил» и «ARP 7040 мс, сокет -1» из HTTP Trace):
 *
 *   БАГ-1 [DCR=word vs byte-доступ]: DCR программировался как 0x01
 *        (word-wide DMA), а данные гонялись ПОБАЙТНО (inb/outb).
 *        В remote-write каждый байт попадал в буфер через 16-битную
 *        запись: mem[rsar]=байт, mem[rsar+1]=0, rsar+=2 → КАДР
 *        ПЕРЕМЕЖАЛСЯ НУЛЯМИ и обрезался пополам (RBCR сгорал вдвое
 *        быстрее). На приёме — каждый второй байта пропускался.
 *        Ни один кадр не уходил в сеть корректным → slirp молчал на
 *        DISCOVER и ARP. Теперь DCR=0x00 (byte DMA) и весь обмен
 *        побайтовый — режим и доступ согласованы.
 *
 *   БАГ-2 [кольцо приёма off-by-one]: пакет лежит на странице
 *        BNRY+1, а после чтения граница ставится на next_page-1
 *        (с wrap на PSTOP-1). Прежний код читал пакет со страницы
 *        BNRY (первый — мимо), ставил BNRY=next_page и определял
 *        «пусто» как bnry==curr — рассинхрон с первого же пакета.
 *
 *   БАГ-3 [пустой check]: корректное условие пустого кольца —
 *        (BNRY+1)==CURR (с wrap), а не BNRY==CURR.
 *
 * Реализация выверена по исходникам эмуляции QEMU hw/net/ne2000.c
 * (та же версия, что у пользователя) и по Linux drivers/net/ethernet/
 * 8390 (ne.c/8390.c):
 *   - регистры: CR стр.0/1 = 0x00/0x40, NODMA=0x20, RREAD=0x08,
 *     RWRITE=0x10, TRANS=0x04 (Linux 8390.h, QEMU ne2000.c);
 *   - remote DMA у QEMU НЕ зависит от битов CR (порт 0x10 читает/
 *     пишет mem[RSAR] с шириной по DCR; rcnt уменьшается сам);
 *   - заголовок пакета в кольце: {rsr, next_page, len_lo, len_hi},
 *     len ВКЛЮЧАЕТ 4 байта заголовка (QEMU: total_len = size + 4);
 *   - адресный фильтр unicast в QEMU сравнивает с ПЗУ-копией MAC в
 *     mem[0..10] (не с PAR) — наш MAC проходит всегда; broadcast
 *     требует RCR.AB (бит 2); PAR всё равно программируем (железо).
 *
 * Раскладка буферов (страницы по 256 байт):
 *   TX: страница 0x40 (адрес 0x4000, 1536 байт — кадр до 1514)
 *   RX: кольцо 0x46..0x80 (адреса 0x4600..0x8000 = 16К..32К) —
 *       влезает и в QEMU (PMEM 0x4000..0xC000), и в реальные
 *       16КБ-карты NE2000.
 */
#include "ne2000.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* ---------- Регистры 8390 (страница 0) ---------- */
#define NE_CR     0x00
#define NE_PSTART 0x01
#define NE_PSTOP  0x02
#define NE_BNRY   0x03
#define NE_TPDR   0x04   /* TPSR: transmit page start */
#define NE_TBCR0  0x05
#define NE_TBCR1  0x06
#define NE_ISR    0x07
#define NE_RSAR0  0x08
#define NE_RSAR1  0x09
#define NE_RBCR0  0x0A
#define NE_RBCR1  0x0B
#define NE_RCR    0x0C
#define NE_TCR    0x0D
#define NE_DCR    0x0E
#define NE_IMR    0x0F
#define NE_DATA   0x10   /* порт данных remote DMA */
#define NE_RESET  0x1F

/* CR: STP=0x01 STA=0x02 TXP=0x04 RD0(RREAD)=0x08 RD1(RWRITE)=0x10
 *     RD2(NODMA)=0x20, страницы: PG0=0x00 PG1=0x40 PG2=0x80 */
#define CR_STOP   0x01
#define CR_START  0x02
#define CR_TXP    0x04
#define CR_RREAD  0x08
#define CR_RWRITE 0x10
#define CR_NODMA  0x20
#define CR_PAGE0  0x00
#define CR_PAGE1  0x40

#define ISR_RX    0x01
#define ISR_TX    0x02
#define ISR_OVER  0x10
#define ISR_RDC   0x40

#define RSR_RXOK  0x01

/* Кольцо: TX на странице 0x40, RX 0x46..0x80 */
#define NE_TX_PAGE  0x40
#define NE_RX_START 0x46
#define NE_RX_STOP  0x80

typedef struct {
    int  present;
    u32  io_base;
    u8   mac[6];
    char chip_name[40];
    /* Сессия 12: диагностика «сеть по ne2000 рвётся / RX всегда 0» —
     * счётчики и последнее состояние кольца, доступные из терминала
     * (команда ne2000). Если у пользователя в эмуляторе кадры не
     * приходят, эти числа покажут, видит ли драйвер прерывание RX и
     * что происходит с указателями кольца (BNRY/CURR). */
    u32  diag_recv_calls;
    u32  diag_pkts;
    u32  diag_over;
    u32  diag_resync;
    u8   diag_bnry, diag_curr, diag_isr;
} ne2000_t;

static ne2000_t g_ne;

static inline u8  ne_r(u8 reg) { return inb(g_ne.io_base + reg); }
static inline void ne_w(u8 reg, u8 val) { outb(g_ne.io_base + reg, val); }

static void ne_delay(void)
{
    for (volatile int i = 0; i < 200; i++) (void)inb(0x80);
}

/* Выбрать страницу + режим (значение CR целиком) */
static inline void ne_cmd(u8 val) { ne_w(NE_CR, val); }

/* Сброс: запись в 0x1F. В QEMU чтение 0x1F — тоже сброс (лишний, но
 * безвредный: регистры не трогает, только isr=RESET и копию ПЗУ);
 * на реальном железе чтение снимает reset-latch. Делаем оба. */
static void ne_reset(void)
{
    outb(g_ne.io_base + NE_RESET, 0xFF);
    ne_delay();
    (void)inb(g_ne.io_base + NE_RESET);
    ne_delay();
}

/* ---------- Remote DMA (byte-wide, DCR=0x00) ----------
 * QEMU: порт 0x10 читает/пишет mem[RSAR], ширина по DCR; rcnt
 * уменьшается на 1 за байт, при 0 на записи данные игнорируются,
 * на чтении — читается всё равно (но мы ставим rcnt точно). */
static void ne_remote_read(u16 addr, void *out, u16 n)
{
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_RSAR0, (u8)(addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(addr >> 8));
    ne_w(NE_RBCR0, (u8)(n & 0xFF));
    ne_w(NE_RBCR1, (u8)(n >> 8));
    ne_cmd(CR_START | CR_RREAD | CR_PAGE0);
    u8 *p = (u8 *)out;
    for (u16 i = 0; i < n; i++)
        p[i] = inb(g_ne.io_base + NE_DATA);
    /* завершение DMA: сбросить RDC (QEMU ставит его на последнем байте) */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_ISR, ISR_RDC);
}

static void ne_remote_write(u16 addr, const void *src, u16 n)
{
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_RSAR0, (u8)(addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(addr >> 8));
    ne_w(NE_RBCR0, (u8)(n & 0xFF));
    ne_w(NE_RBCR1, (u8)(n >> 8));
    ne_cmd(CR_START | CR_RWRITE | CR_PAGE0);
    const u8 *p = (const u8 *)src;
    for (u16 i = 0; i < n; i++)
        outb(g_ne.io_base + NE_DATA, p[i]);
    /* дождаться RDC (на QEMU мгновенно, на железе — до ~мс) */
    for (int i = 0; i < 20000; i++) {
        if (ne_r(NE_ISR) & ISR_RDC) break;
        ne_delay();
    }
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_ISR, ISR_RDC);
}

/* ---------- Инициализация ---------- */
int ne2000_init(void)
{
    g_ne.present = 0;
    g_ne.io_base = 0;

    serial_puts("[ne2000] init...\n");

    /* PCI: Realtek RTL8029 или любой Ethernet-контроллер (класс 0x0200),
     * до которого не добрались e1000/virtio (порядок в kernel.c). */
    int found = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            u8 hdr = pci_read8(bus, dev, 0, 0x0E);
            int max_func = (hdr & 0x80) ? 8 : 1;
            for (int func = 0; func < max_func && !found; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor == 0xFFFF) continue;

                u32 classcc = pci_read32(bus, dev, func, 0x08);
                u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                u8 cc_sub  = (u8)((classcc >> 16) & 0xFF);

                if (cc_base == 0x02 && cc_sub == 0x00) {
                    /* Сессия 11 (КРИТИЧЕСКИЙ ФИКС): раньше probe захватывал
                     * ЛЮБОЙ ethernet-контроллер с I/O-BAR — включая virtio-net
                     * (transitional I/O-BAR) и Atheros atl1c! Далее ne_reset()
                     * писал в ЧУЖЫЕ legacy-регистры: очереди virtio
                     * обнулялись, TX умирал («DHCP не ответил» при живом
                     * драйвере). Пропускаем устройства со своими драйверами. */
                    if (vendor == 0x8086 ||   /* e1000 (Intel) */
                        vendor == 0x1AF4 ||   /* virtio */
                        vendor == 0x1969 ||   /* Atheros L1c/L2c (atl1c) */
                        vendor == 0x168C)     /* Atheros WiFi (ath9k) */
                        continue;
                    u32 bar0 = pci_read32(bus, dev, func, 0x10);
                    if (!(bar0 & 1)) continue;      /* ждём I/O-пространство */
                    g_ne.io_base = bar0 & 0xFFFC;

                    u16 cmd = pci_read16(bus, dev, func, 0x04);
                    cmd |= 0x05;  /* I/O Space + Bus Master */
                    pci_write16(bus, dev, func, 0x04, cmd);

                    if (vendor == 0x10EC && device == 0x8029)
                        strcpy(g_ne.chip_name, "Realtek RTL8029");
                    else
                        strcpy(g_ne.chip_name, "NE2000-compatible");
                    found = 1;
                }

                if (func == 0 && !(hdr & 0x80)) break;
            }
        }
        if (bus > 2) break;
    }

    if (!found) {
        serial_puts("[ne2000] no NE2000-compatible card found\n");
        return 0;
    }

    serial_puts("[ne2000] found: ");
    serial_puts(g_ne.chip_name);
    serial_puts("\n");

    /* --- Сброс и базовая настройка (по Linux NS8390_init) --- */
    ne_reset();

    ne_cmd(CR_STOP | CR_NODMA | CR_PAGE0);   /* стоп, страница 0 */
    ne_delay();

    /* FIX БАГ-1: DCR = 0x00 — BYTE-wide DMA (было 0x01=word при
     * побайтовом доступе: кадры перемежались нулями/теряли байты) */
    ne_w(NE_DCR, 0x00);

    ne_w(NE_RBCR0, 0);
    ne_w(NE_RBCR1, 0);

    /* RCR: AB (бит 2) — принимать broadcast (ARP/DHCP) + unicast себе */
    ne_w(NE_RCR, 0x04);
    /* TCR: loopback на время инициализации (железо), QEMU игнорирует */
    ne_w(NE_TCR, 0x02);

    /* Кольцо приёма */
    ne_w(NE_PSTART, NE_RX_START);
    ne_w(NE_PSTOP,  NE_RX_STOP);
    /* FIX БАГ-2: BNRY = PSTART-1 — первый пакет лежит на PSTART,
     * читаем со страницы BNRY+1 */
    ne_w(NE_BNRY, NE_RX_START - 1);

    /* MAC из ПЗУ. QEMU (и настоящий NE2000 в 16-битном режиме) хранит
     * ПЗУ УДВОЕННЫМ: mem[2i] = mem[2i+1] = mac[i] — берём каждый второй
     * байт (prom[0],prom[2],...). Но НЕ все эмуляторы так делают: часть
     * (VirtualBox, Bochs, реальные карты в 8-битном режиме) кладёт MAC
     * ПОДРЯД в prom[0..5]. Сессия 12: определяем раскладку автоматически —
     * если байты НЕ удвоены (prom[2i] != prom[2i+1]), читаем подряд.
     * Раньше на «несудвоенном» ПЗУ MAC читался как мусор (52:00:34:...)
     * и юникаст-кадры молча отбрасывались фильтром NIC. */
    {
        u8 prom[32];
        ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
        ne_remote_read(0, prom, 32);
        int doubled = 1;
        for (int i = 0; i < 6; i++)
            if (prom[2 * i] != prom[2 * i + 1]) { doubled = 0; break; }
        for (int i = 0; i < 6; i++)
            g_ne.mac[i] = doubled ? prom[2 * i] : prom[i];
        {
            char b[48];
            snprintf(b, sizeof(b), "[ne2000] PROM: %s раскладка\n",
                     doubled ? "удвоенная" : "последовательная");
            serial_puts(b);
        }
        /* Сессия 11: мусорный MAC (все FF / групповой / нулевой) — карта
         * не отвечает, детект ложный. Не регистрируем. */
        {
            int bad = (g_ne.mac[0] & 1) != 0;
            u8 or_all = 0, and_all = 0xFF;
            for (int i = 0; i < 6; i++) {
                or_all |= g_ne.mac[i];
                and_all &= g_ne.mac[i];
            }
            if (or_all == 0 || and_all == 0xFF) bad = 1;
            if (bad) {
                serial_puts("[ne2000] MAC невалиден — ложный детект, пропуск\n");
                g_ne.io_base = 0;
                return 0;
            }
        }
    }
    serial_puts("[ne2000] MAC: ");
    {
        const char *h = "0123456789abcdef";
        char buf[4];
        for (int i = 0; i < 6; i++) {
            buf[0] = h[(g_ne.mac[i] >> 4) & 0xF];
            buf[1] = h[g_ne.mac[i] & 0xF];
            buf[2] = (i < 5) ? ':' : 0;
            buf[3] = 0;
            serial_puts(buf);
        }
    }
    serial_puts("\n");

    /* Страница 1: физический адрес (PAR0-5), multicast-хэш (MAR0-7),
     * CURR = PSTART (первый пакет будет записан на PSTART) */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE1);
    for (int i = 0; i < 6; i++)
        ne_w(0x01 + i, g_ne.mac[i]);
    for (int i = 0; i < 8; i++)
        ne_w(0x08 + i, 0x00);
    ne_w(0x07, NE_RX_START);   /* CURR */

    /* Пуск: страница 0, режим START */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_delay();

    ne_w(NE_ISR, 0xFF);        /* сброс всех флагов */
    ne_w(NE_IMR, 0x00);        /* прерываний нет — поллинг из net_poll */
    ne_w(NE_TCR, 0x00);        /* нормальная передача (без loopback) */

    g_ne.present = 1;

    serial_puts("[ne2000] ready (byte DMA, ring 0x46-0x80)\n");
    return 1;
}

int ne2000_present(void) { return g_ne.present; }
const char *ne2000_chip_name(void) { return g_ne.chip_name; }

/* Сессия 12: диагностика для терминала (команда ne2000) — состояние
 * кольца приёма и счётчики. Возвращает число записанных символов. */
int ne2000_diag(char *out, int max)
{
    if (!g_ne.present) {
        if (max > 0) out[0] = 0;
        return 0;
    }
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    u8 bnry = ne_r(NE_BNRY);
    u8 isr  = ne_r(NE_ISR);
    ne_cmd(CR_START | CR_NODMA | CR_PAGE1);
    u8 curr = ne_r(0x07);
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    g_ne.diag_bnry = bnry;
    g_ne.diag_curr = curr;
    g_ne.diag_isr = isr;
    return snprintf(out, (u32)max,
                    "ne2000: BNRY=%02x CURR=%02x ISR=%02x RXisr=%d "
                    "pkts=%u recv=%u over=%u resync=%u",
                    bnry, curr, isr, (isr & ISR_RX) ? 1 : 0,
                    (unsigned)g_ne.diag_pkts, (unsigned)g_ne.diag_recv_calls,
                    (unsigned)g_ne.diag_over, (unsigned)g_ne.diag_resync);
}

/* Кольцо живо? (для авто-диагностики: RX-бит в ISR при «пустом» кольце
 * означает, что кадры ПРИХОДЯТ, но указатели рассинхронизированы) */
u32 ne2000_diag_pkts(void) { return g_ne.diag_pkts; }

int ne2000_get_mac(u8 out_mac[6])
{
    if (!g_ne.present) return 0;
    memcpy(out_mac, g_ne.mac, 6);
    return 1;
}

/* ---------- Передача ---------- */
int ne2000_send(const void *buf, u32 len)
{
    if (!g_ne.present) return -1;
    if (len > 1514) len = 1514;

    /* Минимальный Ethernet-кадр — 60 байт (без CRC): добиваем нулями.
     * QEMU шлёт ровно TBCR байт; реальное железо тоже допускает,
     * а короткие ARP (42 байта) на живых сетях часто отбрасываются. */
    static u8 tmp[60];
    if (len < 60) {
        memcpy(tmp, buf, len);
        memset(tmp + len, 0, 60 - len);
        buf = tmp;
        len = 60;
    }

    /* Кадр → буфер NIC (страница 0x40, адрес 0x4000) */
    ne_remote_write(NE_TX_PAGE * 256, buf, (u16)len);

    /* Пуск передачи */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_TPDR, NE_TX_PAGE);
    ne_w(NE_TBCR0, (u8)(len & 0xFF));
    ne_w(NE_TBCR1, (u8)(len >> 8));
    ne_cmd(CR_START | CR_TXP | CR_PAGE0);

    return (int)len;
}

/* ---------- Приём (один пакет за вызов; net_poll зовёт до 8 раз) ---------- */
u32 ne2000_recv(void *out_buf, u32 out_max)
{
    if (!g_ne.present) return 0;
    g_ne.diag_recv_calls++;

    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    u8 bnry = ne_r(NE_BNRY);
    ne_cmd(CR_START | CR_NODMA | CR_PAGE1);
    u8 curr = ne_r(0x07);              /* CURR */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);

    /* переполнение кольца (реальное железо) — ресинхронизация */
    if (ne_r(NE_ISR) & ISR_OVER) {
        g_ne.diag_over++;
        ne_w(NE_ISR, 0xFF);
        u8 b = (u8)(curr - 1);
        if (b < NE_RX_START) b = NE_RX_STOP - 1;
        ne_w(NE_BNRY, b);
        return 0;
    }

    /* FIX БАГ-2/3: непрочитанный пакет — на странице BNRY+1 (с wrap);
     * кольцо пусто, когда BNRY+1 == CURR */
    u8 pkt_page = (u8)(bnry + 1);
    if (pkt_page >= NE_RX_STOP) pkt_page = NE_RX_START;
    if (pkt_page == curr) {
        /* Сессия 12: диагностика «RX всегда 0» — кадры реально приходят
         * (бит RX в ISR), но кольцо «пусто»? Значит указатели синхронны,
         * а карта кадры НЕ записывает — например, фильтр RCR или чужой
         * MAC. Пишем состояние в serial РАЗ (не спамим). */
        if ((ne_r(NE_ISR) & ISR_RX) && (g_ne.diag_pkts == 0) &&
            (g_ne.diag_recv_calls & 0x3FF) == 0) {
            char b[96];
            snprintf(b, sizeof(b),
                     "[ne2000] ВНИМАНИЕ: ISR.RX=1, но кольцо пусто "
                     "(BNRY=%02x CURR=%02x) — кадры фильтруются?\n",
                     bnry, curr);
            serial_puts(b);
        }
        return 0;
    }

    /* Заголовок пакета: {rsr, next_page, len_lo, len_hi}; len включает
     * сам заголовок (QEMU: total_len = size + 4) */
    u8 hdr[4];
    ne_remote_read((u16)pkt_page << 8, hdr, 4);
    u8 status = hdr[0];
    u8 next   = hdr[1];
    u16 len   = (u16)hdr[2] | ((u16)hdr[3] << 8);

    if (!(status & RSR_RXOK) || len < 4 || len > 1522 ||
        next < NE_RX_START || next >= NE_RX_STOP) {
        /* битый заголовок = рассинхрон; догоняем CURR */
        g_ne.diag_resync++;
        u8 b = (u8)(curr - 1);
        if (b < NE_RX_START) b = NE_RX_STOP - 1;
        ne_w(NE_BNRY, b);
        return 0;
    }

    u16 frame_len = (u16)(len - 4);
    if ((u32)frame_len > out_max) frame_len = (u16)out_max;
    if (frame_len == 0) {
        u8 b = (u8)(next - 1);
        if (b < NE_RX_START) b = NE_RX_STOP - 1;
        ne_w(NE_BNRY, b);
        return 0;
    }

    /* Данные (remote read сам заворачивает RSAR на границе кольца) */
    ne_remote_read(((u16)pkt_page << 8) + 4, out_buf, frame_len);

    /* Продвинуть границу: BNRY = next-1 (wrap → PSTOP-1) */
    u8 b = (u8)(next - 1);
    if (b < NE_RX_START) b = NE_RX_STOP - 1;
    ne_w(NE_BNRY, b);

    g_ne.diag_pkts++;
    return frame_len;
}
