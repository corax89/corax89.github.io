/* usb_ehci.c — EHCI (USB 2.0) драйвер + USB Mass Storage (SCSI/CBC).
 *
 * Реализовано:
 *   1. PCI-сканирование EHCI (class 0x0C, subclass 0x03, prog-if 0x20).
 *   2. Захват контроллера у BIOS (USBLEGSUP register, OS Owned bit).
 *   3. Сброс HC (USBCMD.HCRESET).
 *   4. Инициализация periodic и async списков (4K-aligned, 1024 entries).
 *   5. QH (Queue Head, 32-байта, 32-byte aligned) и qTD (32-байта, 32-byte aligned)
 *      с overlay-структурой.
 *   6. Control transfers (SETUP + DATA + STATUS) через async schedule.
 *   7. Bulk transfers (для mass storage).
 *   8. USB Mass Storage class driver (BBB protocol):
 *      CBW (31 байт) → DATA → CSW (13 байт).
 *      Поддержаны SCSI-команды: INQUIRY, READ CAPACITY, READ 10, TEST UNIT READY.
 *
 * Что НЕ реализовано:
 *   - Interrupt transfers (periodic schedule для HID). UHCI покрывает HID.
 *   - Split transactions (Transaction Translator) для low/full-speed
 *     устройств на hi-speed порт EHCI. EHCI здесь работает только с hi-speed.
 *   - Multiline support (TT — Transaction Translator через hub).
 *
 * Источники: EHCI spec 1.0, Linux ehci-hcd.c, USB Mass Storage Class spec.
 */
#include "usb_ehci.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "timer.h"
#include "task.h"
#include "ata.h"  /* для ata.h совместимости, не используется */

extern void serial_puts(const char *s);
extern void serial_putc(char c);
extern void *memset(void *dst, int c, u32 n);

/* ---------- EHCI регистры (capability + operational) ---------- */

#define EHCI_CAP_CAPLENGTH   0x00     /* 8-bit R */
#define EHCI_CAP_HCIVERSION  0x02     /* 16-bit R */
#define EHCI_CAP_HCSPARAMS   0x04     /* 32-bit R */
#define EHCI_CAP_HCCPARAMS   0x08     /* 32-bit R */

/* HCCPARAMS bits */
#define EHCI_HCC_EXT_CAP_OFF  0xFF     /* bits 7..0: extended capabilities offset (pointer in PCI config) */
#define EHCI_HCC_64BIT        (1 << 0)

/* Operational registers (offset from base + CAPLENGTH) */
#define EHCI_OP_USBCMD        0x00
#define EHCI_OP_USBSTS        0x04
#define EHCI_OP_USBINTR       0x08
#define EHCI_OP_FRINDEX       0x0C
#define EHCI_OP_CTRLDSSEGMENT 0x10
#define EHCI_OP_PERIODICLISTBASE 0x14
#define EHCI_OP_ASYNCLISTADDR 0x18
#define EHCI_OP_CONFIGFLAG    0x1C
#define EHCI_OP_PORTSC        0x40     /* + 4*port_offset — каждый порт 4 байта */

/* USBCMD bits — layout из EHCI spec 2.2.
 *   bit 0:     RS (Run/Stop)
 *   bit 1:     HCRESET (Host Controller Reset)
 *   bits 4..3: FLS (Frame List Size)
 *   bit 4:     PSE (Periodic Schedule Enable)
 *   bit 5:     ASE (Async Schedule Enable)  ← было (1<<4), правильно (1<<5)
 *   bit 6:     DbC (Debug)
 *   bit 7:     ASP (Async Schedule Park Mode)
 *   bit 24:    IAAD (Interrupt on Async Advance Doorbell)
 *   bits 23..16: IAA Threshold */
#define EHCI_USBCMD_RS        (1u << 0)       /* Run/Stop */
#define EHCI_USBCMD_HCRESET   (1u << 1)       /* Host Controller Reset */
#define EHCI_USBCMD_PSE       (1u << 4)       /* Periodic Schedule Enable */
#define EHCI_USBCMD_ASE       (1u << 5)       /* Async Schedule Enable */
#define EHCI_USBCMD_IAAD      (1u << 6)       /* Interrupt on Async Advance Doorbell (часто для очистки) */
#define EHCI_USBCMD_ASP       (1u << 11)      /* Async Schedule Park Mode */

/* USBSTS bits */
#define EHCI_USBSTS_UI        (1 << 0)       /* USB Interrupt */
#define EHCI_USBSTS_PCI       (1 << 2)       /* Port Change Detect */
#define EHCI_USBSTS_FRI       (1 << 3)       /* Frame List Rollover */
#define EHCI_USBSTS_HSE       (1 << 4)       /* Host System Error */
#define EHCI_USBSTS_IAA       (1 << 5)       /* Interrupt on Async Advance */
#define EHCI_USBSTS_HCH       (1 << 12)      /* HC Halted */
#define EHCI_USBSTS_PSS       (1 << 14)      /* Periodic Schedule Status */
#define EHCI_USBSTS_ASS       (1 << 15)      /* Async Schedule Status */

/* PORTSC bits */
#define EHCI_PORTSC_CCS       (1 << 0)       /* Current Connect Status */
#define EHCI_PORTSC_CSC       (1 << 1)       /* Connect Status Change */
#define EHCI_PORTSC_PE        (1 << 2)       /* Port Enable */
#define EHCI_PORTSC_PEC       (1 << 3)       /* Port Enable/Disable Change */
#define EHCI_PORTSC_OCA       (1 << 4)       /* Over-current Active */
#define EHCI_PORTSC_OCC       (1 << 5)       /* Over-current Change */
#define EHCI_PORTSC_FPR       (1 << 6)       /* Force Port Resume */
#define EHCI_PORTSC_SUSPEND   (1 << 7)       /* Suspend */
#define EHCI_PORTSC_PR        (1 << 8)       /* Port Reset */
#define EHCI_PORTSC_PLS_MASK  0x0F00         /* Port Link State */
#define EHCI_PORTSC_PLS_SHFT  8
#define EHCI_PORTSC_PP        (1 << 12)      /* Port Power */
#define EHCI_PORTSC_LS_SHFT   10            /* Line Status */
#define EHCI_PORTSC_LS_MASK   (3 << 10)
#define EHCI_PORTSC_LS_SE0    (0 << 10)
#define EHCI_PORTSC_LS_J      (2 << 10)      /* hi-speed: D+ high */
#define EHCI_PORTSC_LS_K      (1 << 10)
#define EHCI_PORTSC_LS_SE1    (3 << 10)      /* both lines high */
#define EHCI_PORTSC_OWNER     (1 << 13)      /* Port Owner (1 = companion) */
#define EHCI_PORTSC_FPO       (1 << 13)      /* ... alternate */
#define EHCI_PORTSC_WKOC_E    (1 << 24)      /* Wake on Over-current */
#define EHCI_PORTSC_WKD_CONN  (1 << 25)     /* Wake on Disconnect */
#define EHCI_PORTSC_WKCONN_E  (1 << 26)      /* Wake on Connect */
#define EHCI_PORTSC_PTC_SHFT  16            /* Port Test Control */
#define EHCI_PORTSC_PTC_MASK  (0xF << 16)

/* ---------- qTD (queue element TD) ---------- */

/* EHCI qTD (32 bytes, 32-byte aligned). */
typedef struct __attribute__((packed, aligned(32))) ehci_qtd {
    u32 next_qtd;       /* link to next qTD (bit 0 = T terminate, bits 4..1 = type, bit 1 reserved) */
    u32 alt_next_qtd;   /* alternate next (for short packet) */
    u32 token;          /* status, PID, length, etc. */
    u32 buffer[5];      /* 5 buffer pointers, each pointing to a 4K page */
    /* software fields (not hardware, padding to 32 bytes) */
    u32 soft_active;
    u32 soft_result;
} ehci_qtd_t;

/* Token bits — layout из EHCI spec 3.5.3 + Linux ehci.h.
 * После отладки с QEMU ("cpage out of range (6)") правильный layout:
 *   bits 0..7:    status (bit 7 = Active, 6 = Halt, 5 = DBE, 4 = Babble, 3 = XactErr, 2 = MissedMicro, 1 = SplitXState, 0 = PING)
 *   bits 10..8:   PID code (3 bits, 0=OUT, 1=IN, 2=SETUP)
 *   bits 11..10:  CERR (2 bits, 11 = 3 retries)
 *   bits 14..12:  Current Page (3 bits, range 0..7) ← QEMU использует 3 бита!
 *   bit 15:       IOC (Interrupt On Complete)
 *   bits 30..16:  Total Bytes to Transfer (15 bits, value = bytes left)
 *   bit 31:       Data Toggle (DT) */
#define EHCI_TD_ACTIVE       (1u << 7)
#define EHCI_TD_HALT         (1u << 6)
#define EHCI_TD_DBE          (1u << 5)
#define EHCI_TD_BABBLE       (1u << 4)
#define EHCI_TD_XACT_ERR     (1u << 3)
#define EHCI_TD_PID_OUT     (0u << 8)
#define EHCI_TD_PID_IN       (1u << 8)
#define EHCI_TD_PID_SETUP    (2u << 8)
#define EHCI_TD_CERR_SHFT    10
#define EHCI_TD_CERR_DEF     (3u << 10)        /* CERR=3 retries, bits 11..10 */
#define EHCI_TD_IOC          (1u << 15)        /* Interrupt On Complete, bit 15 */
#define EHCI_TD_BYTES_SHFT   16
#define EHCI_TD_BYTES_MASK   0x7FFF           /* 15 bits */
#define EHCI_TD_DT           (1u << 31)        /* Data Toggle: 0=DATA0, 1=DATA1 */

#define EHCI_QTD_TERMINATE   0x00000001u
/* qTD next_qtd field format:
 *   bit 0: T (Terminate), bits 4..1: Reserved (must be 0),
 *   bits 31..5: 32-byte aligned qTD pointer.
 * Для QH horiz_link тип указывается в битах 4..2, но для qTD next_qtd
 * биты 4..1 должны быть 0. */
#define EHCI_QTD_NEXT(n)     ((u32)(unsigned long)(n) & ~0x1Fu)

/* ---------- QH (Queue Head) ---------- */

/* EHCI QH (48 bytes hardware + padding to 64 for cache line, 32-byte aligned). */
typedef struct __attribute__((packed, aligned(32))) ehci_qh {
    u32 horiz_link;        /* next QH/QH pointer (bit 0 = T terminate, bits 2..1 = type) */
    u32 characteristics;   /* EP, dev addr, max packet, etc. */
    u32 split_completion;  /* split transaction (for low/full via TT) */
    u32 cur_qtd;          /* current qTD pointer (filled by HC) */
    /* Overlay (qTD copy): HC writes here when it advances. */
    u32 next_qtd;          /* overlay: next qTD */
    u32 alt_next_qtd;       /* overlay: alt next */
    u32 token;             /* overlay: token */
    u32 buffer[5];          /* overlay: 5 buffer pointers */
} ehci_qh_t;

/* Horiz link types */
#define EHCI_QH_TYPE_ITD     0x00
#define EHCI_QH_TYPE_QH      0x02      /* bits 2..1 = 01 means QH */
#define EHCI_QH_TYPE_SITD    0x04
#define EHCI_QH_TYPE_FSTN    0x06
#define EHCI_QH_TERMINATE    0x00000001u

/* Characteristics bits — layout из EHCI spec table 3-16 / Linux ehci.h.
 *   bits 6..0:    Device Address (7 bits, 0..127)
 *   bits 11..8:   Endpoint Number (4 bits)
 *   bit 12:       I bit (Inactive on Next Transaction — для split)
 *   bits 14..13:  Endpoint Speed (00=Full, 01=Low, 10=High, 11=Reserved)
 *   bit 15:       Head of Reclamation List Flag
 *   bits 26..16:  Maximum Packet Length (11 bits)
 *   bit 23:       DTC (Data Toggle Control: 1=from qTD, 0=from overlay)
 *   bit 27..30:   Control/Bulk Service Ratio (CBR)
 *   bit 31:       NAK Count Reload (RL) */
#define EHCI_QH_DEVADDR_SHFT  0
#define EHCI_QH_EP_SHFT       8
#define EHCI_QH_EPSPEED_SHFT  13      /* 0=full, 1=low, 2=hi */
#define EHCI_QH_MAXPKT_SHFT   16
#define EHCI_QH_DTC            (1 << 23)  /* Data Toggle Control: 1 = toggle from qTD */
#define EHCI_QH_C_MASK         (1 << 15)  /* Control endpoint flag */
#define EHCI_QH_NAK_CNT_RL_SHFT 28

/* ---------- пулы статических QH и qTD ---------- */

#define EHCI_QH_POOL 16
#define EHCI_QTD_POOL 64

static ehci_qh_t  ehci_qh_pool  [EHCI_QH_POOL];
static ehci_qtd_t ehci_qtd_pool [EHCI_QTD_POOL];
static u8 ehci_qh_used [EHCI_QH_POOL];
static u8 ehci_qtd_used[EHCI_QTD_POOL];

static ehci_qh_t *ehci_qh_alloc(void)
{
    for (int i = 0; i < EHCI_QH_POOL; i++) {
        if (!ehci_qh_used[i]) {
            ehci_qh_used[i] = 1;
            memset(&ehci_qh_pool[i], 0, sizeof(ehci_qh_t));
            return &ehci_qh_pool[i];
        }
    }
    return NULL;
}

static void ehci_qh_free(ehci_qh_t *qh)
{
    if (!qh) return;
    for (int i = 0; i < EHCI_QH_POOL; i++) {
        if (&ehci_qh_pool[i] == qh) { ehci_qh_used[i] = 0; return; }
    }
}

static ehci_qtd_t *ehci_qtd_alloc(void)
{
    for (int i = 0; i < EHCI_QTD_POOL; i++) {
        if (!ehci_qtd_used[i]) {
            ehci_qtd_used[i] = 1;
            memset(&ehci_qtd_pool[i], 0, sizeof(ehci_qtd_t));
            return &ehci_qtd_pool[i];
        }
    }
    return NULL;
}

static void ehci_qtd_free(ehci_qtd_t *qtd)
{
    if (!qtd) return;
    for (int i = 0; i < EHCI_QTD_POOL; i++) {
        if (&ehci_qtd_pool[i] == qtd) { ehci_qtd_used[i] = 0; return; }
    }
}

/* ---------- контроллер ---------- */

typedef struct {
    int  valid;
    u8   cap_length;       /* offset to operational registers */
    u16  hciversion;
    u8   n_ports;          /* number of ports (from HCSPARAMS) */
    u32  mmio_base;        /* base of MMIO region (BAR0) */
    int  bus, dev, func;   /* PCI coordinates */
    u32 *periodic_list;    /* 4K-aligned, 1024 entries */
    ehci_qh_t *async_qh;   /* head of async list (self-link for empty) */
    /* Mass storage device info */
    int  storage_dev_addr;
    int  storage_ep_in;
    int  storage_ep_out;
    u32  storage_max_lba;
    u32  storage_block_size;
} ehci_ctrl_t;

static ehci_ctrl_t ehci_ctrl;

/* MMIO helpers */
static inline u8  mmio_r8 (u32 base, u32 off) { return *(volatile u8 *)(unsigned long)(base + off); }
static inline u16 mmio_r16(u32 base, u32 off) { return *(volatile u16 *)(unsigned long)(base + off); }
static inline u32 mmio_r32(u32 base, u32 off) { return *(volatile u32 *)(unsigned long)(base + off); }
static inline void mmio_w8 (u32 base, u32 off, u8 v)  { *(volatile u8 *)(unsigned long)(base + off) = v; }
static inline void mmio_w16(u32 base, u32 off, u16 v) { *(volatile u16 *)(unsigned long)(base + off) = v; }
static inline void mmio_w32(u32 base, u32 off, u32 v) { *(volatile u32 *)(unsigned long)(base + off) = v; }

/* ---------- взятие у BIOS ---------- */

static void ehci_take_ownership(int bus, int dev, int func)
{
    /* USBLEGSUP register offset is in HCCPARAMS bits 7..0 (extended capability pointer) */
    u32 hccparams = pci_read32(bus, dev, func, 0x08 + EHCI_CAP_HCCPARAMS);
    /* Actually HCCPARAMS is at offset 0x08 from BAR0 (MMIO) — but in PCI config, it's at offset 0x08 + 4 = 0x0C? No, HCCPARAMS is in the CAPABILITY registers (MMIO), not in PCI config. */

    /* Read HCCPARAMS from MMIO if we have a base; else skip. */
    if (!ehci_ctrl.mmio_base) return;
    u32 hccp = mmio_r32(ehci_ctrl.mmio_base, EHCI_CAP_HCCPARAMS);
    u8 ecp = (u8)(hccp & 0xFF);
    if (ecp == 0) {
        serial_puts("[ehci] no USBLEGSUP cap\n");
        return;
    }

    /* USBLEGSUP register: at offset ecp in PCI config space of this device. */
    u32 legsup = pci_read32(bus, dev, func, ecp);
    if (legsup & (1 << 16)) {
        /* BIOS owns HC — request ownership by setting OS Owned bit (bit 24) */
        serial_puts("[ehci] requesting ownership from BIOS...\n");
        pci_write32(bus, dev, func, ecp, legsup | (1 << 24));
        /* Wait for BIOS to release (up to 1 sec) */
        for (int i = 0; i < 100; i++) {
            u32 v = pci_read32(bus, dev, func, ecp);
            if ((v & (1 << 16)) == 0) {
                serial_puts("[ehci] ownership acquired\n");
                return;
            }
            for (volatile int j = 0; j < 100000; j++) { }   /* ~10ms */
        }
        serial_puts("[ehci] WARN: BIOS didn't release ownership\n");
    } else {
        serial_puts("[ehci] ownership: OS already owns (or no BIOS owner)\n");
    }
}

/* ---------- инициализация HC ---------- */

static int ehci_init_one(int bus, int dev, int func)
{
    u32 bar0 = pci_read32(bus, dev, func, 0x10);
    if (bar0 == 0xFFFFFFFF) return 0;
    /* BAR0 — это MMIO адрес (бит 0..3 типа = 0 для MMIO) */
    u32 mmio = bar0 & 0xFFFFFFF0u;
    if (mmio == 0) return 0;

    /* Включаем Bus Master + MMIO */
    u16 cmd = pci_read16(bus, dev, func, 0x04);
    cmd |= 0x06;     /* MSE | BME */
    pci_write16(bus, dev, func, 0x04, cmd);

    ehci_ctrl.mmio_base = mmio;
    ehci_ctrl.bus = bus; ehci_ctrl.dev = dev; ehci_ctrl.func = func;

    /* Читаем capability registers */
    ehci_ctrl.cap_length  = mmio_r8(mmio, EHCI_CAP_CAPLENGTH);
    ehci_ctrl.hciversion  = mmio_r16(mmio, EHCI_CAP_HCIVERSION);
    u32 hcsparams = mmio_r32(mmio, EHCI_CAP_HCSPARAMS);
    ehci_ctrl.n_ports = (u8)(hcsparams & 0xF);

    {
        char buf[120];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(buf, sizeof(buf),
                 "[ehci] mmio=0x%x caplen=%u hciver=0x%x nports=%u\n",
                 (unsigned)mmio, (unsigned)ehci_ctrl.cap_length,
                 (unsigned)ehci_ctrl.hciversion, (unsigned)ehci_ctrl.n_ports);
        serial_puts(buf);
    }

    /* Взять владение у BIOS */
    ehci_take_ownership(bus, dev, func);

    /* Шаг 1: Остановить HC */
    u32 op = mmio + ehci_ctrl.cap_length;
    mmio_w32(op, EHCI_OP_USBCMD, 0);
    /* Ждём HCHalted */
    for (int i = 0; i < 1000; i++) {
        if (mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_HCH) break;
        for (volatile int j = 0; j < 1000; j++) { }
    }

    /* Шаг 2: Сброс HC */
    mmio_w32(op, EHCI_OP_USBCMD, EHCI_USBCMD_HCRESET);
    for (int i = 0; i < 1000; i++) {
        if (!(mmio_r32(op, EHCI_OP_USBCMD) & EHCI_USBCMD_HCRESET)) break;
        for (volatile int j = 0; j < 1000; j++) { }
    }
    /* Очищаем статусы */
    mmio_w32(op, EHCI_OP_USBSTS, 0xFFFFFFFF);

    /* Шаг 3: Выделяем periodic list (4K-aligned, 1024 entries = 4K) */
    u8 *storage = (u8 *)malloc(8192 + 32);
    if (!storage) {
        serial_puts("[ehci] no memory for periodic list\n");
        return 0;
    }
    u32 aligned = ((u32)(unsigned long)storage + 0xFFF) & ~0xFFFu;
    u32 *plist = (u32 *)(unsigned long)aligned;
    ehci_ctrl.periodic_list = plist;
    /* Все 1024 элементов терминированы (T=1, type QH=01 → 0x3 = T|QH-type) */
    for (int i = 0; i < 1024; i++) plist[i] = EHCI_QH_TERMINATE | EHCI_QH_TYPE_QH;

    /* Шаг 4: Создаём async QH (пустой, self-link с Head флагом) */
    ehci_qh_t *aqh = ehci_qh_alloc();
    if (!aqh) {
        serial_puts("[ehci] no memory for async QH\n");
        return 0;
    }
    /* Head of reclamation list flag (bit 15), EPSPEED=hi (10<<13), maxpkt=64.
     * Это особый "head" QH, который HC обходит циклически. */
    aqh->characteristics = (1 << 15) | (2 << 13) | (64 << 16);
    aqh->split_completion = (1 << 16) | (1 << 8);   /* Default split C-mask и hub-addr */
    aqh->horiz_link = (u32)(unsigned long)aqh | EHCI_QH_TYPE_QH | EHCI_QH_TERMINATE;
    aqh->cur_qtd = EHCI_QTD_TERMINATE;
    aqh->next_qtd = EHCI_QTD_TERMINATE;
    aqh->alt_next_qtd = EHCI_QTD_TERMINATE;
    aqh->token = 0;
    ehci_ctrl.async_qh = aqh;

    /* Шаг 5: Программируем регистры */
    mmio_w32(op, EHCI_OP_CTRLDSSEGMENT, 0);     /* 32-bit, без сегментации */
    mmio_w32(op, EHCI_OP_PERIODICLISTBASE, (u32)(unsigned long)plist);
    mmio_w32(op, EHCI_OP_FRINDEX, 0);
    mmio_w32(op, EHCI_OP_ASYNCLISTADDR, (u32)(unsigned long)aqh);
    mmio_w32(op, EHCI_OP_USBINTR, 0);
    /* Установить Configflag = 1 (claim all ports from companion) */
    mmio_w32(op, EHCI_OP_CONFIGFLAG, 1);

    /* Шаг 6: Включить HC */
    mmio_w32(op, EHCI_OP_USBCMD, EHCI_USBCMD_RS | (1 << 4) /* ASE */ | EHCI_USBCMD_ASP);
    /* Подождать запуска */
    for (int i = 0; i < 1000; i++) {
        if (!(mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_HCH)) break;
        for (volatile int j = 0; j < 1000; j++) { }
    }

    /* Шаг 7: Power on all ports */
    for (int p = 0; p < ehci_ctrl.n_ports; p++) {
        u32 psc = mmio_r32(op, EHCI_OP_PORTSC + p * 4);
        mmio_w32(op, EHCI_OP_PORTSC + p * 4, psc | EHCI_PORTSC_PP);
    }
    for (volatile int i = 0; i < 50000; i++) { }

    ehci_ctrl.valid = 1;
    serial_puts("[ehci] initialized\n");
    return 1;
}

/* ---------- сброс порта ---------- */

static int ehci_reset_port(int port)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    u32 psc_addr = op + EHCI_OP_PORTSC + port * 4;
    u32 ps = mmio_r32(psc_addr, 0);
    if (!(ps & EHCI_PORTSC_CCS)) return 0;

    /* Сброс порта: установить PR бит на 50ms */
    ps |= EHCI_PORTSC_PR;
    mmio_w32(psc_addr, 0, ps);
    for (volatile int i = 0; i < 500000; i++) { }    /* ~50ms */
    ps = mmio_r32(psc_addr, 0);
    ps &= ~EHCI_PORTSC_PR;
    mmio_w32(psc_addr, 0, ps);
    for (volatile int i = 0; i < 100000; i++) { }    /* ~10ms */

    /* Проверим, что порт включился (PE=1) */
    ps = mmio_r32(psc_addr, 0);
    if (!(ps & EHCI_PORTSC_PE)) {
        /* Порт мог перейти к companion-контроллеру (owner bit = 1) — это не наша зона */
        if (ps & EHCI_PORTSC_CCS) {
            char buf[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf),
                     "[ehci] port %d: device present but not enabled (ps=0x%x)\n",
                     port, (unsigned)ps);
            serial_puts(buf);
        }
        return 0;
    }
    /* Очистим change-биты */
    mmio_w32(psc_addr, 0, ps | EHCI_PORTSC_CSC | EHCI_PORTSC_PEC);
    return 1;
}

/* ---------- ожидание завершения qTD ---------- */

static int ehci_wait_qtd(ehci_qtd_t *qtd, int timeout_iters)
{
    for (int i = 0; i < timeout_iters; i++) {
        u32 t = qtd->token;
        if (!(t & EHCI_TD_ACTIVE)) {
            /* Готово. Проверим ошибки. */
            if (t & (EHCI_TD_HALT | EHCI_TD_DBE | EHCI_TD_BABBLE | EHCI_TD_XACT_ERR)) {
                return -1;
            }
            return 1;
        }
        (void)inb(0x80);
    }
    return -1;
}

/* ---------- управление async schedule ---------- */

static int ehci_run_async_qh(ehci_qh_t *qh)
{
    /* Поместить qh в async schedule (circular list), дождаться, снять. */
    if (!ehci_ctrl.valid) return -1;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;

    /* Циклический список: async_qh -> qh -> async_qh (без terminate!).
     * T=0 в horiz_link — HC продолжает обходить по цепочке.
     * Если T=1, HC останавливается после этого QH и больше не обрабатывает. */
    ehci_ctrl.async_qh->horiz_link = (u32)(unsigned long)qh | EHCI_QH_TYPE_QH;
    qh->horiz_link = (u32)(unsigned long)ehci_ctrl.async_qh | EHCI_QH_TYPE_QH;

    /* Подготовим ASYNCLISTADDR на наш async_qh (если ещё не). */
    mmio_w32(op, EHCI_OP_ASYNCLISTADDR, (u32)(unsigned long)ehci_ctrl.async_qh);

    /* Включим async schedule. */
    u32 cmd = mmio_r32(op, EHCI_OP_USBCMD);
    mmio_w32(op, EHCI_OP_USBCMD, cmd | EHCI_USBCMD_ASE);

    /* Подождать включения async (ASS bit в USBSTS). */
    for (int i = 0; i < 1000; i++) {
        if (mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_ASS) break;
        (void)inb(0x80);
    }

    /* Ждём завершения всей цепочки qTD. После всех qTD'ишек HC
     * обновляет overlay: qh->next_qtd=TERMINATE и Active бит очищается. */
    int result = -1;
    for (int i = 0; i < 500000; i++) {
        u32 next = qh->next_qtd;
        if (next == EHCI_QTD_TERMINATE) {
            if (!(qh->token & EHCI_TD_ACTIVE)) {
                result = 1;
                break;
            }
        }
        (void)inb(0x80);
    }

    /* Снимем async schedule и восстановим async_qh как self-link. */
    cmd = mmio_r32(op, EHCI_OP_USBCMD);
    mmio_w32(op, EHCI_OP_USBCMD, cmd & ~EHCI_USBCMD_ASE);
    /* Подождать выключения async. */
    for (int i = 0; i < 1000; i++) {
        if (!(mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_ASS)) break;
        (void)inb(0x80);
    }
    ehci_ctrl.async_qh->horiz_link = (u32)(unsigned long)ehci_ctrl.async_qh | EHCI_QH_TYPE_QH | EHCI_QH_TERMINATE;

    return (result > 0) ? 0 : -1;
}

/* ---------- control transfer ---------- */

static int ehci_control_transfer(int addr, u8 *setup_buf,
                                  void *data_buf, int data_len, int data_in)
{
    if (!ehci_ctrl.valid) return -1;

    ehci_qh_t *qh = ehci_qh_alloc();
    ehci_qtd_t *q_setup = ehci_qtd_alloc();
    ehci_qtd_t *q_status = ehci_qtd_alloc();
    ehci_qtd_t *q_data = NULL;
    if (!qh || !q_setup || !q_status) {
        ehci_qh_free(qh); ehci_qtd_free(q_setup); ehci_qtd_free(q_status);
        return -1;
    }

    /* Setup QH */
    qh->characteristics = (addr << EHCI_QH_DEVADDR_SHFT) |
                          (0 << EHCI_QH_EP_SHFT) |
                          (2 << EHCI_QH_EPSPEED_SHFT) |   /* hi-speed */
                          (64 << EHCI_QH_MAXPKT_SHFT) |
                          EHCI_QH_DTC;                    /* data toggle from qTD */
    qh->split_completion = 0;
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    qh->next_qtd = EHCI_QTD_TERMINATE;
    qh->alt_next_qtd = EHCI_QTD_TERMINATE;
    /* Overlay token: установить Active=1, чтобы HC начал обрабатывать qTD'и. */
    qh->token = EHCI_TD_ACTIVE;

    /* Setup qTD (8 bytes SETUP, DATA0) */
    q_setup->next_qtd = EHCI_QTD_TERMINATE;
    q_setup->alt_next_qtd = EHCI_QTD_TERMINATE;
    q_setup->token = (8 << EHCI_TD_BYTES_SHFT) |
                     EHCI_TD_PID_SETUP |
                     EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC;
    q_setup->buffer[0] = (u32)(unsigned long)setup_buf;

    /* Data qTD (если есть) */
    if (data_len > 0) {
        q_data = ehci_qtd_alloc();
        if (!q_data) {
            ehci_qh_free(qh); ehci_qtd_free(q_setup); ehci_qtd_free(q_status);
            return -1;
        }
        q_data->next_qtd = EHCI_QTD_TERMINATE;
        q_data->alt_next_qtd = EHCI_QTD_TERMINATE;
        q_data->token = ((u32)data_len << EHCI_TD_BYTES_SHFT) |
                        (data_in ? EHCI_TD_PID_IN : EHCI_TD_PID_OUT) |
                        EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC |
                        EHCI_TD_DT;       /* DATA1 */
        q_data->buffer[0] = (u32)(unsigned long)data_buf;
        q_setup->next_qtd = EHCI_QTD_NEXT(q_data);
        q_status->token = (0 << EHCI_TD_BYTES_SHFT) |
                          (data_in ? EHCI_TD_PID_OUT : EHCI_TD_PID_IN) |
                          EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC |
                          EHCI_TD_DT;       /* DATA1 */
    } else {
        q_status->token = (0 << EHCI_TD_BYTES_SHFT) |
                          EHCI_TD_PID_IN |
                          EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC |
                          EHCI_TD_DT;       /* DATA1 */
    }

    /* Status qTD (zero-length, opposite direction, DATA1) */
    q_status->next_qtd = EHCI_QTD_TERMINATE;
    q_status->alt_next_qtd = EHCI_QTD_TERMINATE;
    q_status->buffer[0] = 0;

    /* Chain: setup -> data? -> status */
    if (q_data) {
        q_setup->next_qtd = EHCI_QTD_NEXT(q_data);
        q_data->next_qtd = EHCI_QTD_NEXT(q_status);
    } else {
        q_setup->next_qtd = EHCI_QTD_NEXT(q_status);
    }

    /* Point QH to first qTD.
     * cur_qtd MUST be EHCI_QTD_TERMINATE (not 0!) — иначе HC интерпретирует
     * это как указатель на qTD по адресу 0 (недопустимо).
     * HC использует next_qtd overlay, когда cur_qtd = TERMINATE. */
    qh->next_qtd = EHCI_QTD_NEXT(q_setup);
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    /* token установлен в EHCI_TD_ACTIVE при инициализации QH. Не обнуляем! */

    /* Run async */
    int r = ehci_run_async_qh(qh);
    int result = (r == 0) ? data_len : -1;

    /* Cleanup */
    ehci_qtd_free(q_setup);
    ehci_qtd_free(q_status);
    if (q_data) ehci_qtd_free(q_data);
    ehci_qh_free(qh);
    return result;
}

/* ---------- bulk transfer ---------- */

static int ehci_bulk_transfer(int addr, int ep, int ep_size, int data_in,
                               void *buf, int len)
{
    if (!ehci_ctrl.valid) return -1;

    ehci_qh_t *qh = ehci_qh_alloc();
    ehci_qtd_t *q = ehci_qtd_alloc();
    if (!qh || !q) {
        ehci_qh_free(qh); ehci_qtd_free(q);
        return -1;
    }

    /* Bulk QH */
    qh->characteristics = (addr << EHCI_QH_DEVADDR_SHFT) |
                          ((ep & 0xF) << EHCI_QH_EP_SHFT) |
                          (2 << EHCI_QH_EPSPEED_SHFT) |   /* hi-speed */
                          (((u32)ep_size) << EHCI_QH_MAXPKT_SHFT) |
                          EHCI_QH_DTC;
    qh->split_completion = 0;
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    qh->next_qtd = EHCI_QTD_TERMINATE;
    qh->alt_next_qtd = EHCI_QTD_TERMINATE;
    /* Overlay token: Active=1, чтобы HC начал обработку. */
    qh->token = EHCI_TD_ACTIVE;

    /* qTD */
    q->next_qtd = EHCI_QTD_TERMINATE;
    q->alt_next_qtd = EHCI_QTD_TERMINATE;
    q->token = ((u32)len << EHCI_TD_BYTES_SHFT) |
               (data_in ? EHCI_TD_PID_IN : EHCI_TD_PID_OUT) |
               (3 << EHCI_TD_CERR_SHFT) | EHCI_TD_ACTIVE | EHCI_TD_IOC;
    q->buffer[0] = (u32)(unsigned long)buf;
    /* Если длина больше 4K, нужно несколько buffer[]; упрощение — до 4K */

    qh->next_qtd = EHCI_QTD_NEXT(q);
    qh->cur_qtd = 0;

    int r = ehci_run_async_qh(qh);
    int result = (r == 0) ? len : -1;

    ehci_qtd_free(q);
    ehci_qh_free(qh);
    return result;
}

/* ---------- standard USB requests ---------- */

typedef struct __attribute__((packed)) {
    u8 bmRequestType;
    u8 bRequest;
    u16 wValue;
    u16 wIndex;
    u16 wLength;
} usb_request_t;

static int ehci_get_descriptor(int addr, u8 type, u8 idx, void *buf, int len)
{
    usb_request_t req;
    req.bmRequestType = 0x80;     /* IN, Standard, Device */
    req.bRequest = 6;
    req.wValue = (u16)((type << 8) | idx);
    req.wIndex = 0;
    req.wLength = (u16)len;
    return ehci_control_transfer(addr, (u8 *)&req, buf, len, 1);
}

static int ehci_set_address(int addr)
{
    usb_request_t req;
    req.bmRequestType = 0x00;
    req.bRequest = 5;
    req.wValue = (u16)addr;
    req.wIndex = 0;
    req.wLength = 0;
    return ehci_control_transfer(0, (u8 *)&req, 0, 0, 0);
}

static int ehci_set_configuration(int addr, u8 cfg)
{
    usb_request_t req;
    req.bmRequestType = 0x00;
    req.bRequest = 9;
    req.wValue = cfg;
    req.wIndex = 0;
    req.wLength = 0;
    return ehci_control_transfer(addr, (u8 *)&req, 0, 0, 0);
}

/* ---------- USB Mass Storage (BBB protocol + SCSI) ---------- */

typedef struct __attribute__((packed)) {
    u32 dCBWSignature;       /* 0x43425355 = 'USBC' */
    u32 dCBWTag;
    u32 dCBWDataTransferLength;
    u8  bmCBWFlags;            /* bit 7 = direction (1 = IN, 0 = OUT) */
    u8  bCBWLUN;
    u8  bCBWCBLength;
    u8  CBWCB[16];
} msd_cbw_t;     /* total 31 bytes */

typedef struct __attribute__((packed)) {
    u32 dCSWSignature;        /* 0x53425355 = 'USBS' */
    u32 dCSWTag;
    u32 dCSWDataResidue;
    u8  bCSWStatus;           /* 0 = OK, 1 = failed, 2 = phase error */
} msd_csw_t;     /* total 13 bytes */

static u8 msd_inquiry_cmd[6] = { 0x12, 0x00, 0x00, 0x00, 0x24, 0x00 };   /* INQUIRY, 36 bytes */
static u8 msd_test_unit_ready[6] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static u8 msd_read_capacity[10] = { 0x25, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static u8 msd_request_sense[6] = { 0x03, 0x00, 0x00, 0x00, 0x12, 0x00 };

static int ehci_msd_send_cbw(msd_cbw_t *cbw, int ep_out, int addr, int ep_size)
{
    return ehci_bulk_transfer(addr, ep_out, ep_size, 0, cbw, 31);
}

static int ehci_msd_recv_csw(msd_csw_t *csw, int ep_in, int addr, int ep_size)
{
    return ehci_bulk_transfer(addr, ep_in, ep_size, 1, csw, 13);
}

static int ehci_msd_init_device(int addr, int ep_in, int ep_out, int ep_size)
{
    /* Шлём TEST UNIT READY, пока не ответит OK (или limit) */
    msd_cbw_t cbw;
    msd_csw_t csw;
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    for (int attempt = 0; attempt < 5; attempt++) {
        cbw.dCBWSignature = 0x43425355u;
        cbw.dCBWTag = 0x100 + attempt;
        cbw.dCBWDataTransferLength = 0;
        cbw.bmCBWFlags = 0;            /* OUT */
        cbw.bCBWLUN = 0;
        cbw.bCBWCBLength = 6;
        memcpy(cbw.CBWCB, msd_test_unit_ready, 6);

        ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
        ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);
        if (csw.dCSWSignature == 0x53425355u && csw.bCSWStatus == 0) {
            return 1;
        }
        /* Если статус 1, шлём REQUEST SENSE */
        memset(&csw, 0, sizeof(csw));
        cbw.dCBWTag = 0x200 + attempt;
        cbw.dCBWDataTransferLength = 0x12;
        cbw.bmCBWFlags = 0x80;     /* IN */
        cbw.bCBWCBLength = 6;
        memcpy(cbw.CBWCB, msd_request_sense, 6);
        u8 sense[18];
        ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
        ehci_bulk_transfer(addr, ep_in, ep_size, 1, sense, 0x12);
        ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);
    }
    return 0;
}

static int ehci_msd_read_capacity(int addr, int ep_in, int ep_out, int ep_size,
                                   u32 *out_max_lba, u32 *out_block_size)
{
    msd_cbw_t cbw;
    msd_csw_t csw;
    u8 resp[8];
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));
    memset(resp, 0, sizeof(resp));

    cbw.dCBWSignature = 0x43425355u;
    cbw.dCBWTag = 0x300;
    cbw.dCBWDataTransferLength = 8;
    cbw.bmCBWFlags = 0x80;     /* IN */
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = 10;
    memcpy(cbw.CBWCB, msd_read_capacity, 10);

    ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
    ehci_bulk_transfer(addr, ep_in, ep_size, 1, resp, 8);
    ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);

    if (csw.dCSWSignature != 0x53425355u || csw.bCSWStatus != 0) return 0;

    /* resp: last LBA (big-endian 4 bytes) + block size (big-endian 4 bytes) */
    *out_max_lba = ((u32)resp[0] << 24) | ((u32)resp[1] << 16) |
                   ((u32)resp[2] << 8) | (u32)resp[3];
    *out_block_size = ((u32)resp[4] << 24) | ((u32)resp[5] << 16) |
                     ((u32)resp[6] << 8) | (u32)resp[7];
    return 1;
}

static int ehci_msd_read10(int addr, int ep_in, int ep_out, int ep_size,
                            u32 lba, void *buf, u32 n_blocks, u32 block_size)
{
    msd_cbw_t cbw;
    msd_csw_t csw;
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    cbw.dCBWSignature = 0x43425355u;
    cbw.dCBWTag = 0x400 + lba;
    cbw.dCBWDataTransferLength = n_blocks * block_size;
    cbw.bmCBWFlags = 0x80;     /* IN (read from device) */
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = 10;
    /* READ 10 command */
    cbw.CBWCB[0] = 0x28;     /* READ 10 */
    cbw.CBWCB[2] = (u8)((lba >> 24) & 0xFF);
    cbw.CBWCB[3] = (u8)((lba >> 16) & 0xFF);
    cbw.CBWCB[4] = (u8)((lba >> 8) & 0xFF);
    cbw.CBWCB[5] = (u8)(lba & 0xFF);
    cbw.CBWCB[7] = (u8)((n_blocks >> 8) & 0xFF);
    cbw.CBWCB[8] = (u8)(n_blocks & 0xFF);

    ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
    /* Receive data */
    ehci_bulk_transfer(addr, ep_in, ep_size, 1, buf, n_blocks * block_size);
    /* Receive CSW */
    ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);

    return (csw.dCSWSignature == 0x53425355u && csw.bCSWStatus == 0) ? 1 : 0;
}

/* WRITE 10: запись блоков на USB-флешку через BBB-протокол.
 * CBW (OUT) → DATA (OUT) → CSW (IN). */
static int ehci_msd_write10(int addr, int ep_in, int ep_out, int ep_size,
                             u32 lba, const void *buf, u32 n_blocks, u32 block_size)
{
    msd_cbw_t cbw;
    msd_csw_t csw;
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    cbw.dCBWSignature = 0x43425355u;
    cbw.dCBWTag = 0x600 + lba;
    cbw.dCBWDataTransferLength = n_blocks * block_size;
    cbw.bmCBWFlags = 0x00;     /* OUT (write to device) */
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = 10;
    /* WRITE 10 command (opcode 0x2A) */
    cbw.CBWCB[0] = 0x2A;     /* WRITE 10 */
    cbw.CBWCB[2] = (u8)((lba >> 24) & 0xFF);
    cbw.CBWCB[3] = (u8)((lba >> 16) & 0xFF);
    cbw.CBWCB[4] = (u8)((lba >> 8) & 0xFF);
    cbw.CBWCB[5] = (u8)(lba & 0xFF);
    cbw.CBWCB[7] = (u8)((n_blocks >> 8) & 0xFF);
    cbw.CBWCB[8] = (u8)(n_blocks & 0xFF);

    /* Send CBW (OUT direction) */
    ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
    /* Send data (OUT direction — host to device) */
    ehci_bulk_transfer(addr, ep_out, ep_size, 0, (void *)buf, n_blocks * block_size);
    /* Receive CSW (IN direction — device to host) */
    ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);

    return (csw.dCSWSignature == 0x53425355u && csw.bCSWStatus == 0) ? 1 : 0;
}

/* ---------- enumeration + storage discovery ---------- */

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 bcdUSB;
    u8 bDeviceClass, bDeviceSubClass, bDeviceProtocol;
    u8 bMaxPacketSize0;
    u16 idVendor, idProduct, bcdDevice;
    u8 iManufacturer, iProduct, iSerial;
    u8 bNumConfigurations;
} ehci_dev_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 wTotalLength;
    u8 bNumInterfaces, bConfigValue, iConfig, bmAttributes, bMaxPower;
} ehci_cfg_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bInterfaceNumber, bAlternateSetting;
    u8 bNumEndpoints, bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol;
    u8 iInterface;
} ehci_iface_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bEndpointAddress, bmAttributes;
    u16 wMaxPacketSize;
    u8 bInterval;
} ehci_ep_desc_t;

/* Найти в конфигурации mass-storage interface (class 8). */
static void ehci_parse_config_for_msd(u8 *buf, int len, int *ep_in, int *ep_out, int *ep_size)
{
    int i = 0;
    int cur_iface = -1;
    u8 iface_class = 0, iface_sub = 0, iface_proto = 0;
    while (i + 2 <= len) {
        u8 dlen = buf[i];
        u8 dtyp = buf[i + 1];
        if (dlen == 0) break;
        if (dtyp == 4 && i + 9 <= len) {
            cur_iface = buf[i + 2];
            iface_class = buf[i + 5];
            iface_sub = buf[i + 6];
            iface_proto = buf[i + 7];
        }
        else if (dtyp == 5 && i + 7 <= len) {
            u8 ep_addr = buf[i + 2];
            u8 ep_attr = buf[i + 3];
            u16 ep_sz = (u16)(buf[i + 4] | (buf[i + 5] << 8));
            /* Mass storage: bulk endpoints (attr=2). */
            if ((ep_attr & 0x03) == 0x02 && iface_class == 8) {
                if (ep_addr & 0x80) {
                    *ep_in = ep_addr & 0x0F;
                    *ep_size = ep_sz;
                } else {
                    *ep_out = ep_addr & 0x0F;
                    *ep_size = ep_sz;
                }
            }
        }
        i += dlen;
    }
    (void)iface_sub; (void)iface_proto; (void)cur_iface;
}

static void ehci_enumerate(void)
{
    if (!ehci_ctrl.valid) return;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;

    /* Дебаг: показать состояние всех портов до enumerate */
    for (int p = 0; p < ehci_ctrl.n_ports; p++) {
        u32 ps = mmio_r32(op, EHCI_OP_PORTSC + p * 4);
        if (ps & EHCI_PORTSC_CCS) {
            char buf[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            int ls = (ps & EHCI_PORTSC_LS_MASK) >> EHCI_PORTSC_LS_SHFT;
            const char *speed = (ls == EHCI_PORTSC_LS_J) ? "hi-speed" :
                                (ls == EHCI_PORTSC_LS_K) ? "low-speed" : "full-speed";
            snprintf(buf, sizeof(buf),
                     "[ehci] port %d: device present (ps=0x%x, %s)\n",
                     p, (unsigned)ps, speed);
            serial_puts(buf);
        }
    }

    int next_addr = 10;     /* EHCI-адреса начинаем с 10, чтобы не конфликтовать с UHCI */
    for (int port = 0; port < ehci_ctrl.n_ports; port++) {
        if (!ehci_reset_port(port)) continue;

        u8 devbuf[64];
        memset(devbuf, 0, sizeof(devbuf));
        if (ehci_get_descriptor(0, 1, 0, devbuf, 8) < 8) continue;

        if (ehci_set_address(next_addr) < 0) continue;
        int addr = next_addr++;
        for (volatile int i = 0; i < 50000; i++) { }

        if (ehci_get_descriptor(addr, 1, 0, devbuf, 18) < 18) continue;

        u8 cfgbuf[256];
        if (ehci_get_descriptor(addr, 2, 0, cfgbuf, 9) < 9) continue;
        int cfg_total = cfgbuf[2] | (cfgbuf[3] << 8);
        if (cfg_total > 200) cfg_total = 200;
        ehci_get_descriptor(addr, 2, 0, cfgbuf, cfg_total);
        ehci_set_configuration(addr, 1);

        int ep_in = 0, ep_out = 0, ep_size = 0;
        ehci_parse_config_for_msd(cfgbuf, cfg_total, &ep_in, &ep_out, &ep_size);

        if (ep_in && ep_out && ep_size) {
            char buf[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf),
                     "[ehci] mass storage @ addr %d, EPin=%d EPout=%d size=%d\n",
                     addr, ep_in, ep_out, ep_size);
            serial_puts(buf);

            if (ehci_msd_init_device(addr, ep_in, ep_out, ep_size)) {
                u32 max_lba = 0, bsz = 0;
                if (ehci_msd_read_capacity(addr, ep_in, ep_out, ep_size, &max_lba, &bsz)) {
                    snprintf(buf, sizeof(buf),
                             "[ehci] storage: %u blocks x %u bytes = %u MiB\n",
                             (unsigned)max_lba, (unsigned)bsz,
                             (unsigned)((u64)max_lba * bsz / (1024 * 1024)));
                    serial_puts(buf);
                    ehci_ctrl.storage_dev_addr = addr;
                    ehci_ctrl.storage_ep_in = ep_in;
                    ehci_ctrl.storage_ep_out = ep_out;
                    ehci_ctrl.storage_max_lba = max_lba;
                    ehci_ctrl.storage_block_size = bsz;
                }
            }
        }
    }
}

/* ---------- public API ---------- */

int usb_ehci_present(void) { return ehci_ctrl.valid ? 1 : 0; }

int usb_ehci_storage_ready(void) { return ehci_ctrl.storage_dev_addr ? 1 : 0; }

int usb_ehci_read_sector(u32 lba, void *buf)
{
    if (!ehci_ctrl.storage_dev_addr) return 0;
    return ehci_msd_read10(ehci_ctrl.storage_dev_addr,
                            ehci_ctrl.storage_ep_in,
                            ehci_ctrl.storage_ep_out,
                            ehci_ctrl.storage_block_size,
                            lba, buf, 1, 512);
}

int usb_ehci_write_sector(u32 lba, const void *buf)
{
    if (!ehci_ctrl.storage_dev_addr) return 0;
    return ehci_msd_write10(ehci_ctrl.storage_dev_addr,
                             ehci_ctrl.storage_ep_in,
                             ehci_ctrl.storage_ep_out,
                             ehci_ctrl.storage_block_size,
                             lba, buf, 1, 512);
}

void usb_ehci_init(void)
{
    ehci_ctrl.valid = 0;
    ehci_ctrl.storage_dev_addr = 0;
    memset(ehci_qh_used, 0, sizeof(ehci_qh_used));
    memset(ehci_qtd_used, 0, sizeof(ehci_qtd_used));

    serial_puts("[ehci] init...\n");
    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                if ((id & 0xFFFF) == 0 || (id & 0xFFFF) == 0xFFFF) {
                    if (func == 0) break;
                    continue;
                }
                u32 class_code = pci_read32(bus, dev, func, 0x08);
                u8 base_class = (u8)((class_code >> 24) & 0xFF);
                u8 sub_class  = (u8)((class_code >> 16) & 0xFF);
                u8 prog_if    = (u8)((class_code >> 8)  & 0xFF);
                if (base_class == 0x0C && sub_class == 0x03 && prog_if == 0x20) {
                    if (ehci_init_one(bus, dev, func)) {
                        ehci_enumerate();
                        return;
                    }
                }
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    serial_puts("[ehci] no EHCI controller found\n");
}
