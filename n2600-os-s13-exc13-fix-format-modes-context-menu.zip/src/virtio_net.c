/* virtio_net.c — драйвер VirtIO-net (legacy I/O + modern virtio-1.0 MMIO)
 * для N2600-OS.
 *
 * СЕССИЯ 9: добавлен транспорт MODERN (virtio 1.0, MMIO через PCI
 * capabilities). Прежний код работал ТОЛЬКО с legacy I/O BAR0, но при этом
 * «находил» и modern-устройства (ID 0x1040+) — читал мусорный MAC и
 * строил очередь по неработающему протоколу: кадры не покидали гостя
 * (DHCP DISCOVER уходил в никуда, DNS timeout). Так ведёт себя
 * virtio-net-pci-non-transitional в QEMU и virtio 1.0 в VirtualBox 7.1+
 * (у VBox legacy-режод сломан при включённом MMIO BAR — их issue #569).
 *
 * Теперь транспорт выбирается по PCI-возможностям:
 *   - есть caps COMMON_CFG+NOTIFY_CFG → modern (virtio 1.0):
 *       фичи через driver_feature_select/select, FEATURES_OK, адреса
 *       колец 64-битные в common cfg, queue_enable, notify через
 *       notify BAR + notify_off*multiplier, заголовок кадра 12 байт
 *       (virtio_net_hdr_v1 с num_buffers).
 *   - иначе ID 0x1000..0x103F + I/O BAR0 → legacy (как раньше, 10-байтный
 *       заголовок, PFN-регистры). Проверен в QEMU transitional: DHCP BOUND.
 *
 * Переписан ранее (сессия 7): кольца по фактическому qsize устройства
 * (до 1024), 10/12-байтный virtio_net_hdr снимается/добавляется,
 * used-кольцо поллится (без прерываний), TX — ротация 16 слотов.
 */
#include "virtio_net.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

#define VIRTIO_VENDOR_ID  0x1AF4

/* Legacy I/O-регистры (BAR0) */
#define VIO_DEV_FEAT    0x00
#define VIO_GUEST_FEAT  0x04
#define VIO_QUEUE_PFN   0x08
#define VIO_QUEUE_SIZE  0x0C  /* R: 16 бит */
#define VIO_QUEUE_SEL   0x0E  /* W: 16 бит */
#define VIO_QUEUE_NOTIFY 0x10 /* W: 16 бит */
#define VIO_STATUS      0x12  /* R/W: 8 бит */
#define VIO_ISR         0x13  /* R: 8 бит */
#define VIO_NET_CFG     0x14  /* MAC и статус ссылки */

#define VIO_S_ACK         0x01
#define VIO_S_DRIVER      0x02
#define VIO_S_DRIVER_OK   0x04
#define VIO_S_FEATURES_OK 0x08
#define VIO_S_FAILED      0x80

/* PCI capabilities virtio (vendor-specific, cap ID 0x09) */
#define VIO_CAP_COMMON 1
#define VIO_CAP_NOTIFY 2
#define VIO_CAP_ISR    3
#define VIO_CAP_DEVICE 4
#define VIO_CAP_PCICFG 5

/* virtio-фичи */
#define VIRTIO_F_VERSION_1_BIT 32
#define VNET_F_MAC_BIT         5

/* Common config (virtio 1.0, little-endian) */
typedef struct __attribute__((packed)) {
    u32 device_feature_select;   /* +0x00 W */
    u32 device_feature;          /* +0x04 R */
    u32 driver_feature_select;   /* +0x08 W */
    u32 driver_feature;          /* +0x0C W */
    u16 config_msix_vector;      /* +0x10 */
    u16 num_queues;              /* +0x12 R */
    u8  device_status;           /* +0x14 R/W */
    u8  config_generation;       /* +0x15 R */
    u16 queue_select;            /* +0x16 W */
    u16 queue_size;              /* +0x18 R/W */
    u16 queue_msix_vector;       /* +0x1A */
    u16 queue_enable;            /* +0x1C R/W */
    u16 queue_notify_off;        /* +0x1E R */
    u64 queue_desc;              /* +0x20 R/W */
    u64 queue_avail;             /* +0x28 R/W */
    u64 queue_used;              /* +0x30 R/W */
} vio_common_cfg_t;

#define VQ_MAX_QSIZE   1024
#define VQ_POOL_SIZE   (32 * 1024)   /* покрывает qsize 1024:
                                        used заканчивается на 28676 */

#define VRING_DESC_F_NEXT  1
#define VRING_DESC_F_WRITE 2

/* Заголовок кадра: legacy = 10 байт, virtio-1.0 = 12 (num_buffers) */
#define VIO_HDR_LEGACY 10
#define VIO_HDR_MODERN 12
#define VIO_HDR_MAX    12

typedef struct __attribute__((packed)) {
    u64 addr;
    u32 len;
    u16 flags;
    u16 next;
} vq_desc_t;

typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    u16 ring[];      /* qsize элементов */
} vq_avail_t;

typedef struct __attribute__((packed)) {
    u32 id;
    u32 len;
} vq_used_elem_t;

typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    vq_used_elem_t ring[];  /* qsize элементов */
} vq_used_t;

/* Кольца RX (queue 0) и TX (queue 1) — выровненные пулы */
static u8 g_rx_pool[VQ_POOL_SIZE] __attribute__((aligned(4096)));
static u8 g_tx_pool[VQ_POOL_SIZE] __attribute__((aligned(4096)));

#define RX_BUF_COUNT 16
#define TX_BUF_COUNT 16
#define RX_FRAME_MAX 1536   /* hdr 12 + кадр 1514 + запас */

static u8 g_rx_bufs[RX_BUF_COUNT][RX_FRAME_MAX];
static u8 g_tx_bufs[TX_BUF_COUNT][VIO_HDR_MAX + 1514];

typedef struct {
    int  present;
    int  modern;              /* 1 = virtio 1.0 MMIO, 0 = legacy I/O */
    u32  io_base;             /* legacy */
    u8   mac[6];
    char chip_name[40];
    u16  rx_qsize;
    u16  tx_qsize;
    u16  rx_last_used;
    u16  tx_last_used;
    u16  tx_next;      /* следующий слот tx-буфера (ротация) */
    u16  tx_base;      /* первый desc-индекс TX-области */
    u32  tx_posted;    /* сколько отправлено; освобождается по used */
    u32  tx_done;      /* сколько подтверждено устройством */
    u16  hdr_size;     /* 10 или 12 */
    /* modern: отображённые области */
    volatile vio_common_cfg_t *common;
    volatile u8 *dev_cfg;      /* MAC здесь */
    u32  notify_addr;          /* базовый адрес notify-области */
    u32  notify_mult;          /* notify_off_multiplier */
    int  notify_is_io;
    u32  rx_notify_addr;
    u32  tx_notify_addr;
} virtio_t;

static virtio_t g_vio;

static inline u8  vio_r8(u32 off) { return inb(g_vio.io_base + off); }
static inline u16 vio_r16(u32 off) { return inw(g_vio.io_base + off); }
static inline u32 vio_r32(u32 off) { return inl(g_vio.io_base + off); }
static inline void vio_w8(u32 off, u8 v) { outb(g_vio.io_base + off, v); }
static inline void vio_w16(u32 off, u16 v) { outw(g_vio.io_base + off, v); }
static inline void vio_w32(u32 off, u32 v) { outl(g_vio.io_base + off, v); }

#define vio_mb() __asm__ __volatile__("" ::: "memory")

/* Адреса областей кольца внутри пула */
static vq_desc_t *q_desc(u8 *pool) { return (vq_desc_t *)pool; }
static vq_avail_t *q_avail(u8 *pool, u16 qsize)
{ return (vq_avail_t *)(pool + 16u * qsize); }
static u32 used_off(u16 qsize)
{
    u32 off = 16u * qsize + 4u + 2u * qsize;   /* desc + avail */
    return (off + 4095u) & ~4095u;             /* выравнивание used */
}
static vq_used_t *q_used(u8 *pool, u16 qsize)
{ return (vq_used_t *)(pool + used_off(qsize)); }

/* ---------- уведомление устройства ---------- */
static void vio_kick(int queue_idx)
{
    if (!g_vio.modern) {
        vio_w16(VIO_QUEUE_NOTIFY, (u16)queue_idx);
        return;
    }
    u32 addr = (queue_idx == 0) ? g_vio.rx_notify_addr : g_vio.tx_notify_addr;
    if (g_vio.notify_is_io) {
        outw(addr, (u16)queue_idx);
    } else {
        *(volatile u16 *)(unsigned long)addr = (u16)queue_idx;
    }
}

/* ---------- настройка очередей ---------- */

/* Legacy: select → size → очистить кольцо → PFN */
static int vio_setup_queue_legacy(int queue_idx, u8 *pool, u16 *out_qsize)
{
    vio_w16(VIO_QUEUE_SEL, (u16)queue_idx);
    u16 qsize = vio_r16(VIO_QUEUE_SIZE);
    if (qsize == 0) return 0;
    if (qsize > VQ_MAX_QSIZE) qsize = VQ_MAX_QSIZE;
    if (used_off(qsize) + 4u + 8u * qsize > VQ_POOL_SIZE) return 0;

    memset(pool, 0, used_off(qsize) + 4u + 8u * qsize);

    /* Барьер: кольцо очищено до записи PFN */
    vio_mb();
    vio_w32(VIO_QUEUE_PFN, (u32)(unsigned long)pool / 4096u);
    *out_qsize = qsize;
    return 1;
}

/* Modern: select → size (можно уменьшить) → адреса → enable */
static int vio_setup_queue_modern(int queue_idx, u8 *pool, u16 *out_qsize,
                                  u32 *out_notify_addr)
{
    volatile vio_common_cfg_t *c = g_vio.common;
    c->queue_select = (u16)queue_idx;
    u16 qsize = c->queue_size;
    if (qsize == 0) return 0;
    if (qsize > VQ_MAX_QSIZE) {
        /* virtio 1.0 разрешает уменьшить размер (степень двойки) */
        c->queue_size = VQ_MAX_QSIZE;
        qsize = c->queue_size;
        if (qsize > VQ_MAX_QSIZE) return 0;
    }
    if (used_off(qsize) + 4u + 8u * qsize > VQ_POOL_SIZE) return 0;

    memset(pool, 0, used_off(qsize) + 4u + 8u * qsize);

    u32 n_off = c->queue_notify_off;   /* читать до enable */
    vio_mb();
    c->queue_desc  = (u64)(unsigned long)pool;
    c->queue_avail = (u64)(unsigned long)(pool + 16u * qsize);
    c->queue_used  = (u64)(unsigned long)(pool + used_off(qsize));
    c->queue_enable = 1;

    *out_qsize = qsize;
    *out_notify_addr = g_vio.notify_addr + (u32)n_off * g_vio.notify_mult;
    return 1;
}

/* ---------- PCI capability-парсер (modern) ---------- */

typedef struct {
    int ok;                    /* есть COMMON+NOTIFY */
    volatile vio_common_cfg_t *common;
    volatile u8 *dev_cfg;      /* DEVICE_CFG или NULL */
    u32  notify_addr;
    int  notify_is_io;
    u32  notify_mult;
    u8   bar_is_io[6];
    u32  bar_base[6];
} vio_caps_t;

static vio_caps_t g_caps;

/* Прочитать базу BAR (поддержка 64-бит) и тип */
static void vio_read_bar(int bus, int dev, int func, int bar_idx)
{
    u32 reg = 0x10 + 4 * bar_idx;
    u32 v = pci_read32(bus, dev, func, reg);
    if (v & 1) {
        g_caps.bar_is_io[bar_idx] = 1;
        g_caps.bar_base[bar_idx] = v & 0xFFFCu;
    } else {
        g_caps.bar_is_io[bar_idx] = 0;
        u32 base = v & 0xFFFFFFF0u;
        u32 type = (v >> 1) & 3;
        if (type == 2 && bar_idx < 5) {          /* 64-битный BAR */
            u32 hi = pci_read32(bus, dev, func, reg + 4);
            if (hi) {                             /* память >4ГБ — не мапим */
                g_caps.bar_base[bar_idx] = 0;
                return;
            }
        }
        g_caps.bar_base[bar_idx] = base;
    }
}

static void vio_scan_caps(int bus, int dev, int func)
{
    g_caps.ok = 0;
    g_caps.common = NULL;
    g_caps.dev_cfg = NULL;
    g_caps.notify_mult = 0;

    u32 common_addr = 0; int common_is_io = 0;
    u32 notify_bar_base = 0; int notify_is_io = 0; u32 notify_off = 0;
    u32 dev_addr = 0; int dev_is_io = 0; int have_dev = 0;
    int have_common = 0, have_notify = 0;

    u8 cap = pci_read8(bus, dev, func, 0x34);
    int guard = 0;
    while (cap && guard++ < 48) {
        u8 vndr = pci_read8(bus, dev, func, cap);
        u8 next = pci_read8(bus, dev, func, cap + 1);
        if (vndr != 0x09) {                 /* vendor-specific */
            cap = next;
            continue;
        }
        u8 cfg_type = pci_read8(bus, dev, func, cap + 3);
        u8 bar      = pci_read8(bus, dev, func, cap + 4);
        u32 offset  = pci_read32(bus, dev, func, cap + 8);
        u32 length  = pci_read32(bus, dev, func, cap + 12);
        (void)length;

        if (bar < 6 && g_caps.bar_base[bar] == 0 && !g_caps.bar_is_io[bar])
            vio_read_bar(bus, dev, func, bar);

        switch (cfg_type) {
        case VIO_CAP_COMMON:
            if (bar < 6 && g_caps.bar_base[bar]) {
                common_addr = g_caps.bar_base[bar] + offset;
                common_is_io = g_caps.bar_is_io[bar];
                have_common = 1;
            }
            break;
        case VIO_CAP_NOTIFY:
            if (bar < 6 && g_caps.bar_base[bar]) {
                notify_bar_base = g_caps.bar_base[bar];
                notify_is_io = g_caps.bar_is_io[bar];
                notify_off = offset;
                g_caps.notify_mult =
                    pci_read32(bus, dev, func, cap + 16);
                have_notify = 1;
            }
            break;
        case VIO_CAP_DEVICE:
            if (bar < 6 && g_caps.bar_base[bar]) {
                dev_addr = g_caps.bar_base[bar] + offset;
                dev_is_io = g_caps.bar_is_io[bar];
                have_dev = 1;
            }
            break;
        default:
            break;
        }
        cap = next;
    }

    /* common cfg обязан быть MMIO (virtio 1.0); notify может быть I/O */
    if (have_common && !common_is_io && have_notify) {
        g_caps.common = (volatile vio_common_cfg_t *)
                        (unsigned long)common_addr;
        g_caps.notify_addr = notify_bar_base + notify_off;
        g_caps.notify_is_io = notify_is_io;
        if (have_dev && !dev_is_io)
            g_caps.dev_cfg = (volatile u8 *)(unsigned long)dev_addr;
        g_caps.ok = 1;
    }
}

/* ---------- init ---------- */

int virtio_net_init(void)
{
    g_vio.present = 0;

    serial_puts("[virtio] init...\n");

    /* PCI-скан */
    int found = 0;
    int f_bus = 0, f_dev = 0, f_func = 0;
    u16 f_device = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            u8 hdr = pci_read8(bus, dev, 0, 0x0E);
            int max_func = (hdr & 0x80) ? 8 : 1;
            for (int func = 0; func < max_func && !found; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor != VIRTIO_VENDOR_ID) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                u32 classcc = pci_read32(bus, dev, func, 0x08);
                u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                u8 cc_sub  = (u8)((classcc >> 16) & 0xFF);

                int is_net = 0;
                if (cc_base == 0x02 && cc_sub == 0x00) is_net = 1;
                if (device >= 0x1000 && device <= 0x103F) is_net = 1;
                if (device >= 0x1040 && device <= 0x107F) {
                    u32 ss = pci_read32(bus, dev, func, 0x2C);
                    u16 subsys = (u16)((ss >> 16) & 0xFFFF);
                    if (subsys == 1) is_net = 1;   /* virtio-net */
                }
                if (!is_net) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                found = 1;
                f_bus = bus; f_dev = dev; f_func = func; f_device = device;
                break;
            }
        }
        if (bus > 2) break;
    }

    if (!found) {
        serial_puts("[virtio] no VirtIO-net device found\n");
        return 0;
    }

    /* Кэшировать BARы и просканировать capabilities */
    for (int b = 0; b < 6; b++) {
        g_caps.bar_base[b] = 0;
        g_caps.bar_is_io[b] = 0;
        vio_read_bar(f_bus, f_dev, f_func, b);
    }
    vio_scan_caps(f_bus, f_dev, f_func);

    u32 bar0 = g_caps.bar_base[0];
    int bar0_is_io = g_caps.bar_is_io[0];

    /* Выбор транспорта: modern caps имеют приоритет — надёжнее
     * (у VirtualBox 7.1+ legacy I/O сломан при включённом MMIO BAR) */
    if (g_caps.ok) {
        g_vio.modern = 1;
        g_vio.common = g_caps.common;
        g_vio.dev_cfg = g_caps.dev_cfg;
        g_vio.notify_addr = g_caps.notify_addr;
        g_vio.notify_is_io = g_caps.notify_is_io;
        g_vio.notify_mult = g_caps.notify_mult;
        strcpy(g_vio.chip_name, "VirtIO-net 1.0 (modern)");
    } else if (f_device >= 0x1000 && f_device <= 0x103F && bar0_is_io) {
        g_vio.modern = 0;
        g_vio.io_base = bar0;
        strcpy(g_vio.chip_name, "VirtIO-net (legacy)");
    } else {
        serial_puts("[virtio] device 0x");
        {
            char b[8];
            for (int i = 3; i >= 0; i--) {
                b[3 - i] = "0123456789abcdef"[((unsigned)f_device >> (i * 4)) & 0xF];
            }
            b[4] = 0;
            serial_puts(b);
        }
        serial_puts(": no modern caps, no legacy I/O — skipped\n");
        return 0;
    }

    /* Включить I/O + Memory + Bus Master */
    {
        u16 cmd = pci_read16(f_bus, f_dev, f_func, 0x04);
        cmd |= 0x07;
        pci_write16(f_bus, f_dev, f_func, 0x04, cmd);
    }

    serial_puts("[virtio] found: ");
    serial_puts(g_vio.chip_name);
    serial_puts("\n");

    if (g_vio.modern) {
        char b[96];
        snprintf(b, sizeof(b),
                 "[virtio] caps: common=%x notify=%x(io=%d) mult=%u devcfg=%x\n",
                 (unsigned)(unsigned long)g_vio.common,
                 g_vio.notify_addr, g_vio.notify_is_io,
                 (unsigned)g_vio.notify_mult,
                 (unsigned)(unsigned long)g_vio.dev_cfg);
        serial_puts(b);
    }

    if (!g_vio.modern) {
        /* ---- legacy init (как в сессии 7, проверен в QEMU) ---- */
        vio_w8(VIO_STATUS, 0);
        vio_w8(VIO_STATUS, VIO_S_ACK);
        vio_w8(VIO_STATUS, VIO_S_ACK | VIO_S_DRIVER);
        (void)vio_r32(VIO_DEV_FEAT);
        vio_w32(VIO_GUEST_FEAT, 0);
        g_vio.hdr_size = VIO_HDR_LEGACY;

        for (int i = 0; i < 6; i++)
            g_vio.mac[i] = inb(g_vio.io_base + VIO_NET_CFG + i);

        if (!vio_setup_queue_legacy(0, g_rx_pool, &g_vio.rx_qsize)) {
            serial_puts("[virtio] RX queue setup failed\n");
            vio_w8(VIO_STATUS, VIO_S_ACK | VIO_S_DRIVER | VIO_S_FAILED);
            return 0;
        }
        if (!vio_setup_queue_legacy(1, g_tx_pool, &g_vio.tx_qsize)) {
            serial_puts("[virtio] TX queue setup failed\n");
            vio_w8(VIO_STATUS, VIO_S_ACK | VIO_S_DRIVER | VIO_S_FAILED);
            return 0;
        }
    } else {
        /* ---- modern init (virtio 1.0) ---- */
        volatile vio_common_cfg_t *c = g_vio.common;

        c->device_status = 0;                        /* reset */
        c->device_status = VIO_S_ACK | VIO_S_DRIVER;

        /* Фичи: MAC + VIRTIO_F_VERSION_1, больше ничего
         * (без EVENT_IDX / MRG_RXBUF / offload — заголовок 12 байт) */
        c->driver_feature_select = 0;
        c->driver_feature = (1u << VNET_F_MAC_BIT);
        c->driver_feature_select = 1;
        c->driver_feature = 1u;                      /* бит 32 */
        c->device_status = VIO_S_ACK | VIO_S_DRIVER | VIO_S_FEATURES_OK;
        if (!(c->device_status & VIO_S_FEATURES_OK)) {
            serial_puts("[virtio] FEATURES_OK not accepted by device\n");
            c->device_status |= VIO_S_FAILED;
            return 0;
        }
        g_vio.hdr_size = VIO_HDR_MODERN;

        /* MAC из device config */
        if (g_vio.dev_cfg) {
            for (int i = 0; i < 6; i++)
                g_vio.mac[i] = g_vio.dev_cfg[i];
        } else {
            /* нет DEVICE_CFG — неизвестный MAC */
            memset(g_vio.mac, 0, 6);
        }

        if (!vio_setup_queue_modern(0, g_rx_pool, &g_vio.rx_qsize,
                                    &g_vio.rx_notify_addr)) {
            serial_puts("[virtio] RX queue setup failed\n");
            c->device_status = VIO_S_ACK | VIO_S_DRIVER |
                               VIO_S_FEATURES_OK | VIO_S_FAILED;
            return 0;
        }
        if (!vio_setup_queue_modern(1, g_tx_pool, &g_vio.tx_qsize,
                                    &g_vio.tx_notify_addr)) {
            serial_puts("[virtio] TX queue setup failed\n");
            c->device_status = VIO_S_ACK | VIO_S_DRIVER |
                               VIO_S_FEATURES_OK | VIO_S_FAILED;
            return 0;
        }

        /* DRIVER_OK до первого kick (требование virtio 1.0) */
        c->device_status = VIO_S_ACK | VIO_S_DRIVER |
                           VIO_S_FEATURES_OK | VIO_S_DRIVER_OK;
    }

    /* MAC в журнал */
    serial_puts("[virtio] MAC: ");
    {
        const char *h = "0123456789abcdef";
        char buf[4];
        for (int i = 0; i < 6; i++) {
            buf[0] = h[(g_vio.mac[i] >> 4) & 0xF];
            buf[1] = h[g_vio.mac[i] & 0xF];
            buf[2] = (i < 5) ? ':' : 0;
            buf[3] = 0;
            serial_puts(buf);
        }
    }
    serial_puts("\n");

    {
        char b[64];
        snprintf(b, sizeof(b), "[virtio] queues: rx=%u tx=%u\n",
                 (unsigned)g_vio.rx_qsize, (unsigned)g_vio.tx_qsize);
        serial_puts(b);
    }

    /* TX-область дескрипторов — последние TX_BUF_COUNT индексов */
    g_vio.tx_base = (u16)(g_vio.tx_qsize - TX_BUF_COUNT);
    g_vio.tx_next = 0;
    g_vio.tx_posted = 0;
    g_vio.tx_done = 0;
    g_vio.tx_last_used = 0;

    /* Выдать устройству RX-буферы: desc[0..15] → writable, в avail */
    {
        vq_desc_t *d = q_desc(g_rx_pool);
        vq_avail_t *av = q_avail(g_rx_pool, g_vio.rx_qsize);
        for (int i = 0; i < RX_BUF_COUNT; i++) {
            d[i].addr = (u64)(unsigned long)g_rx_bufs[i];
            d[i].len = RX_FRAME_MAX;
            d[i].flags = VRING_DESC_F_WRITE;
            d[i].next = 0;
            av->ring[av->idx % g_vio.rx_qsize] = (u16)i;
            vio_mb();
            av->idx++;
        }
        g_vio.rx_last_used = 0;
        if (!g_vio.modern)
            /* legacy: порядок как в сессии 7 (проверен в QEMU) */
            vio_w8(VIO_STATUS, VIO_S_ACK | VIO_S_DRIVER | VIO_S_DRIVER_OK);
        vio_kick(0);   /* kick RX */
    }

    g_vio.present = 1;
    serial_puts("[virtio] ready\n");
    return 1;
}

int virtio_net_present(void) { return g_vio.present; }
const char *virtio_net_chip_name(void) { return g_vio.chip_name; }

int virtio_net_get_mac(u8 out_mac[6])
{
    if (!g_vio.present) return 0;
    memcpy(out_mac, g_vio.mac, 6);
    return 1;
}

int virtio_net_send(const void *buf, u32 len)
{
    if (!g_vio.present) return -1;
    if (len > 1514) len = 1514;

    /* Освободить завершённые TX по used-кольцу (ротация слотов) */
    {
        vq_used_t *u = q_used(g_tx_pool, g_vio.tx_qsize);
        vio_mb();
        while (g_vio.tx_last_used != u->idx) {
            vq_used_elem_t *e = &u->ring[g_vio.tx_last_used % g_vio.tx_qsize];
            if (e->id >= g_vio.tx_base) {
                if (g_vio.tx_done < g_vio.tx_posted) g_vio.tx_done++;
            }
            g_vio.tx_last_used++;
        }
    }

    /* Слот свободен? (ротация: занято = posted - done) */
    if (g_vio.tx_posted - g_vio.tx_done >= TX_BUF_COUNT)
        return -1;   /* все слоты в полёте — редкая ситуация */

    u16 slot = (u16)(g_vio.tx_next++ % TX_BUF_COUNT);
    u16 di = (u16)(g_vio.tx_base + slot);

    /* Заголовок (нули: без offload/GSO) + кадр */
    memset(g_tx_bufs[slot], 0, g_vio.hdr_size);
    memcpy(g_tx_bufs[slot] + g_vio.hdr_size, buf, len);

    vq_desc_t *d = q_desc(g_tx_pool);
    vq_avail_t *av = q_avail(g_tx_pool, g_vio.tx_qsize);

    d[di].addr = (u64)(unsigned long)g_tx_bufs[slot];
    d[di].len = g_vio.hdr_size + len;
    d[di].flags = 0;
    d[di].next = 0;

    av->ring[av->idx % g_vio.tx_qsize] = di;
    vio_mb();
    av->idx++;
    vio_mb();

    g_vio.tx_posted++;
    vio_kick(1);   /* kick TX */
    return (int)len;
}

u32 virtio_net_recv(void *out_buf, u32 out_max)
{
    if (!g_vio.present) return 0;

    vq_used_t *u = q_used(g_rx_pool, g_vio.rx_qsize);
    vio_mb();
    if (g_vio.rx_last_used == u->idx) return 0;

    vq_used_elem_t *e = &u->ring[g_vio.rx_last_used % g_vio.rx_qsize];
    u32 id = e->id;
    u32 blen = e->len;
    g_vio.rx_last_used++;

    u32 frame_len = 0;
    if (id < RX_BUF_COUNT && blen > g_vio.hdr_size) {
        frame_len = blen - g_vio.hdr_size;         /* снять virtio-заголовок */
        if (frame_len > 1514) frame_len = 1514;
        if (frame_len > out_max) frame_len = out_max;
        memcpy(out_buf, g_rx_bufs[id] + g_vio.hdr_size, frame_len);
    }

    /* Вернуть буфер устройству */
    vq_avail_t *av = q_avail(g_rx_pool, g_vio.rx_qsize);
    av->ring[av->idx % g_vio.rx_qsize] = (u16)id;
    vio_mb();
    av->idx++;
    vio_mb();
    vio_kick(0);

    return frame_len;
}
