/* ath9k_wifi.h — драйвер Atheros WiFi (порт Linux ath9k, GPLv2).
 *
 * Поддерживаемые чипы (PCI vendor 0x168c):
 *   AR9285 (002b), AR9287 (002e) — семейство Owl
 *   AR9485 (0032)                — семейство Sowl (AR9003)
 *
 * Реализовано: полный bring-up (reset/PLL/ini/калибровки), DMA RX,
 * пассивное сканирование 2.4 ГГц (каналы 1-14), парсинг beacon,
 * TX (QCU/DCU, дескрипторы AR5416 — семейство Owl), ассоциация с
 * открытыми сетями (AUTH/ASSOC), мост 802.11<->Ethernet для стека,
 * автоподключение к сохранённой сети (RAM disk WIFI.CFG).
 * Не реализовано: шифрование (WEP/WPA — сети пропускаются).
 *
 * Диагностика: подробный журнал этапов (wifi_log_tail) — виден
 * в приложении WiFi, dmesg и serial.
 *
 * Графическая утилита: apps_wifi.c — список точек доступа + журнал.
 */
#ifndef ATH9K_WIFI_H
#define ATH9K_WIFI_H

#include "types.h"

#define WIFI_MAX_APS 32

typedef struct {
    char     ssid[33];       /* SSID (NUL-terminated) */
    u8       bssid[6];       /* BSSID (MAC адрес точки) */
    i8       rssi;           /* Signal strength (dBm, отрицательное) */
    u8       channel;        /* Номер канала (1-14) */
    u8       beacon_interval; /* Интервал beacon (в 1024 us единицах) */
    u16      capability;     /* Capability info */
    u8       encrypted;      /* 1 = сеть зашифрована */
    u8       sec;            /* WIFI_SEC_* (сессия 12: тип защиты) */
} wifi_ap_t;

/* Статистика приёма/сканирования — «подробная информация при поиске» */
typedef struct {
    u32 frames;              /* всего кадров принято */
    u32 beacons;             /* из них beacon-кадров */
    u32 crc_err;             /* кадров с CRC/PHY-ошибкой */
    u32 other;               /* прочие ошибки */
    u32 aps;                 /* найдено сетей */
    int  channel;            /* текущий канал сканирования (1-14; 0 = нет) */
    int  pass;               /* 1 = основной проход, 2 = повтор (AR9485, 25 МГц) */
    u32 chan_beacons[14];    /* маяков на каждом канале */
    u32 chan_frames[14];     /* кадров (FrameOK) на каждом канале */
    u32 chan_crc[14];        /* CRC/PHY-ошибок на каждом канале */
    int  nf_chain0;          /* NF (dBm) цепи 0 по CCA — жив ли приёмник */
} wifi_stats_t;

void wifi_init(void);
void wifi_scan_start(void);
int  wifi_scan_active(void);
int  wifi_scan_results(wifi_ap_t *out, int max);
int  wifi_present(void);
int  wifi_ready(void);
const char *wifi_chip_name(void);
void wifi_poll(void);

/* Диагностика */
void wifi_get_stats(wifi_stats_t *out);
void wifi_log(const char *fmt, ...);
int  wifi_log_count(void);
int  wifi_log_tail(char *buf, int buf_sz, int n_lines);  /* последние строки */

/* ===================== подключение (сессия 11) ===================== */

typedef enum {
    WIFI_CONN_OFF = 0,     /* не подключаемся */
    WIFI_CONN_SCAN,        /* ищем сеть из профиля */
    WIFI_CONN_AUTH,        /* отправлен AUTH, ждём ответ */
    WIFI_CONN_ASSOC,       /* отправлен ASSOC REQ, ждём ответ */
    WIFI_CONN_4WAY,        /* WPA2: 4-стороннее рукопожатие (сессия 12) */
    WIFI_CONN_CONNECTED,   /* ассоциированы — IP-трафик разрешён */
    WIFI_CONN_FAILED       /* не удалось (таймаут/отказ/шифрование) */
} wifi_conn_state_t;

/* Тип защиты сети (сессия 12): разбор RSN/WPA IE из маяка */
#define WIFI_SEC_OPEN      0   /* без шифрования */
#define WIFI_SEC_WPA2_PSK  1   /* WPA2/WPA-PSK + CCMP — поддержано */
#define WIFI_SEC_WPA_PSK   2   /* только WPA/TKIP — не поддержано */
#define WIFI_SEC_OTHER     3   /* WEP / Enterprise / TKIP-only — нет */

/* Подключиться к сети по SSID (асинхронно: состояние машины —
 * в wifi_poll, прогресс — wifi_conn_state()). Открытые сети — сразу,
 * WPA2-PSK (CCMP) — беря пароль из профиля WIFI.CFG (psk=...),
 * если он там есть (сессия 12). Шифрованные сети без пароля в
 * профиле — вернёт 0 (нужен wifi_connect_psk).
 * При успехе SSID (и пароль, если есть) сохраняется в WIFI.CFG
 * для автоподключения при следующей загрузке.
 * Возвращает 1 если процесс запущен. */
int  wifi_connect(const char *ssid);

/* Сессия 12: подключение к WPA2-PSK с явной парольной фразой
 * (ввод пароля в приложении WiFi Scanner). psk = NULL/"" — из профиля. */
int  wifi_connect_psk(const char *ssid, const char *psk);

/* Сессия 12: текущее подключение защищено WPA2 (установлены ключи)? */
int  wifi_conn_secured(void);

void wifi_disconnect(void);
wifi_conn_state_t wifi_conn_state(void);
const char *wifi_conn_state_name(void);
const char *wifi_conn_ssid(void);     /* текущий/целевой SSID ("" = нет) */
int  wifi_conn_rssi(void);            /* RSSI последнего маяка, dBm */
int  wifi_conn_channel(void);         /* канал точки (0 = нет) */

/* Сохранённый SSID из RAM disk (WIFI.CFG, первая строка "ssid=...").
 * Возвращает 1 если профиль найден. */
int  wifi_profile_load(char *out_ssid, int max);
int  wifi_profile_load_psk(char *out_psk, int max);   /* сессия 12: psk= */
void wifi_profile_save(const char *ssid);   /* "" — удалить профиль */

/* ---- NIC-интерфейс для net.c (мост 802.11 <-> Ethernet) ---- */
void wifi_net_get_mac(u8 out_mac[6]);
int  wifi_net_link(void);              /* 1 = ассоциированы */
int  wifi_net_send(const void *eth_frame, u32 len);   /* -1/0/1 */
u32  wifi_net_recv(void *buf, u32 max);               /* байт (0 = пусто) */

#endif /* ATH9K_WIFI_H */
