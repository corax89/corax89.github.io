/* fileman.c — файловый менеджер: CD/ISO9660, FAT32 (ATA/USB), RAMFS.
 * FIX (не видно дисков): загрузочный CD с ISO9660 раньше вообще не
 * был доступен в «Файлах» (кнопки были только HDD/RAM/USB) — на машине
 * с одним CD-приводом приложение показывало «нет диска», хотя ОС
 * загрузилась с читаемого ISO. Теперь панель устройств — [CD][HDD][RAM][USB].
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "kbd.h"
#include "mouse.h"
#include "fat32.h"
#include "ntfs.h"
#include "kernel.h"   /* sata_pending */
#include "ramfs.h"
#include "iso9660.h"
#include "usb_ehci.h"
#include "ata.h"
#include "disk.h"   /* единый слой НЖМД (AHCI/ATA) */
#include "loader.h"
#include "filedlg.h"   /* сессия 13: диалог ввода имени */

/* ============================ файловый менеджер ============================ */

#define FM_MAX 256
#define FM_ROW 18
#define FM_HDR 22
#define FM_DEVBAR 22    /* высота панели выбора устройства */

/* режимы источника: 0=HDD (FAT32 или NTFS), 1=RAMFS, 2=FAT32(USB), 3=CD/ISO9660 */
#define FM_MODE_ATA 0
#define FM_MODE_RAM 1
#define FM_MODE_USB 2
#define FM_MODE_ISO 3
#define FM_MODE_COUNT 4

/* порядок кнопок на панели: CD, HDD, RAM, USB */
static const int fm_btn_mode[4] = { FM_MODE_ISO, FM_MODE_ATA, FM_MODE_RAM, FM_MODE_USB };
static const char *const fm_btn_name[4] = { "[CD]", "[HDD]", "[RAM]", "[USB]" };

/* Сессия 12 (запрос пользователя): панель показывает ТОЛЬКО существующие
 * диски с ПОНЯТНОЙ файловой системой — с которой можно работать:
 *   CD   — смонтирован ISO9660;
 *   HDD  — НЖМД найден и на нём FAT32 (ATA-бэкенд) или NTFS;
 *   RAM  — RAM disk;
 *   USB  — флешка смонтирована как FAT32 (USB-бэкенд).
 * Диск без поддерживаемой ФС (например, NTFS до инициализации или
 * ext4) НЕ показывается — раньше кнопка висела серой и вела в тупик
 * «ФС не найдена». USB монтируется автоматически при первом
 * обнаружении флешки; если ФС не FAT32 — кнопка не появляется. */
static int fm_usb_bad = 0;      /* монтирование USB пробовали — ФС не FAT32 */

static int fm_src_avail(int mode)
{
    switch (mode) {
    case FM_MODE_ISO: return iso9660_ready() ? 1 : 0;
    case FM_MODE_ATA:
        return (disk_hdd_present() &&
                ((fat32_ready() && !fat32_is_usb()) || ntfs_ready())) ? 1 : 0;
    case FM_MODE_RAM: return ramfs_ready() ? 1 : 0;
    case FM_MODE_USB:
        return (fat32_ready() && fat32_is_usb()) ? 1 : 0;
    }
    return 0;
}

/* Первая доступная источник-режим (для авто-переключения). */
static int fm_first_avail_mode(void)
{
    for (int i = 0; i < 4; i++)
        if (fm_src_avail(fm_btn_mode[i]))
            return fm_btn_mode[i];
    return FM_MODE_RAM;   /* что-то должно быть (RAM disk живёт всегда) */
}

/* К какому режиму принадлежит FAT-набор записей (режимы 0 и 2 делят fat_ents) */
#define FM_IS_FAT(m) ((m) == FM_MODE_ATA || (m) == FM_MODE_USB)
/* Сессия 11: [HDD] теперь умеет и NTFS — выбор ФС внутри режима ATA */
#define FM_HDD_IS_NTFS(m) ((m) == FM_MODE_ATA && fm_hdd_fs == 1)

static int fm_hdd_fs = 0;     /* [HDD]: 0 = FAT32, 1 = NTFS (сессия 11) */

typedef struct {
    fat32_dirent_t fat_ents[FM_MAX];
    ramfs_dirent_t ram_ents[FM_MAX];
    iso9660_dirent_t iso_ents[FM_MAX];
    ntfs_dirent_t ntfs_ents[FM_MAX];
    int  fat_n, ram_n, iso_n, ntfs_n;
    int  sel, scroll, depth;
    int  mode; /* FM_MODE_* */
    int  usb_inited;          /* 1 = fat32_init_usb() уже вызвана */
    int  dev_hover;           /* -1 = none, 0..3 = device button hover */
    int  hdd_avail_snap;      /* тик: состояние [HDD] для автообновления */
    struct { u32 cluster;     /* FAT: кластер / ISO: LBA каталога */
             u32 iso_size;    /* ISO: размер каталога в байтах */
             char path[200]; } stk[16];
} fm_t;

/* --- форвард-объявления (сессия 13: меню/действия используют их выше) --- */
static void fm_open_selected(window_t *w);
static void fm_mouse_rmb(window_t *w, fm_t *m, int mx, int my, u8 btn, u8 changed);

/* Полный путь RAM-ребёнка name в текущем каталоге (сессия 13). */
static void fm_ram_full(char *dst, int dstsz, fm_t *m, const char *name)
{
    const char *base = m->stk[m->depth].path;
    if (base[0] == '/' && !base[1])
        snprintf(dst, dstsz, "%s", name);
    else
        snprintf(dst, dstsz, "%s/%s", base, name);
}

static void fm_path_join(char *dst, const char *name)
{
    int l = (int)strlen(dst);
    if (l && dst[l-1] != '/') dst[l++] = '/';
    int i = 0;
    while (name[i] && l < 190) dst[l++] = name[i++];
    dst[l] = 0;
}

static void fm_reload(fm_t *m)
{
    m->ntfs_n = 0;
    if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
        /* NTFS (сессия 11): листинг по полному пути */
        m->ntfs_n = ntfs_ready()
            ? ntfs_list(m->stk[m->depth].path, m->ntfs_ents, FM_MAX) : 0;
        if (m->ntfs_n < 0) m->ntfs_n = 0;
        m->fat_n = 0;
        m->ram_n = 0;
        m->iso_n = 0;
    } else if (FM_IS_FAT(m->mode)) {
        /* FAT32 ATA/USB режим */
        m->fat_n = fat32_ready() ? fat32_list(m->stk[m->depth].cluster, m->fat_ents, FM_MAX) : 0;
        m->ram_n = 0;
        m->iso_n = 0;
    } else if (m->mode == FM_MODE_ISO) {
        /* CD / ISO9660: корень или каталог по LBA+размеру из стека */
        if (!iso9660_ready()) {
            m->iso_n = 0;
        } else if (m->depth == 0) {
            m->iso_n = iso9660_list_root(m->iso_ents, FM_MAX);
        } else {
            m->iso_n = iso9660_list_dir(m->stk[m->depth].cluster,
                                        m->stk[m->depth].iso_size, 1,
                                        m->iso_ents, FM_MAX);
        }
        m->fat_n = 0;
        m->ram_n = 0;
    } else {
        /* RAMFS режим (сессия 13: иерархия — листинг ТЕКУЩЕГО каталога) */
        m->ram_n = ramfs_ready()
            ? ramfs_list_dir(m->stk[m->depth].path, m->ram_ents, FM_MAX) : 0;
        m->fat_n = 0;
        m->iso_n = 0;
    }
    m->sel = 0;
    m->scroll = 0;
}

/* ============ контекстное меню и создание/удаление (сессия 13) ============
 * Запрос пользователя: «стандартное контекстное меню (которое смогут
 * переиспользовать другие приложения)» + «создание папок и файлов».
 * Меню — переиспользуемый wm-компонент (wm_menu_open); пункты зависят
 * от режима и выделения. Создание/удаление — только в RAM disk
 * (единственная перезаписываемая ФС). */

enum { FMC_OPEN = 1, FMC_MKDIR, FMC_TOUCH, FMC_DELETE, FMC_RELOAD };

static const char *fm_menu_hint;   /* строка статуса после действия */

static void fm_reload_and_draw(fm_t *m, window_t *w)
{
    fm_reload(m);
    win_invalidate(w);
}

/* ---- колбэки диалога ввода имени (поток диалога — как во всём ОС) ---- */
static window_t *fm_input_owner;
static int fm_pending_kind;     /* FMC_MKDIR / FMC_TOUCH */

static void fm_input_ok(void *ctx, const char *name)
{
    window_t *w = (window_t *)ctx;
    fm_t *m = (fm_t *)w->data;
    if (!m || m->mode != FM_MODE_RAM) return;
    char full[232];
    /* чистим имя от '/' (один уровень за раз) */
    char clean[FD_NAME_MAX + 1];
    int ci = 0;
    for (const char *p = name; *p && ci < FD_NAME_MAX; p++)
        if (*p != '/') clean[ci++] = *p;
    clean[ci] = 0;
    if (!clean[0]) return;

    fm_ram_full(full, sizeof(full), m, clean);
    if (fm_pending_kind == FMC_MKDIR) {
        if (ramfs_mkdir(full)) fm_menu_hint = "Папка создана";
        else fm_menu_hint = "Не удалось создать папку (имя занято?)";
    } else {
        ramfs_delete(full);
        if (ramfs_create(full, 1) && ramfs_write(full, "", 1))
            fm_menu_hint = "Файл создан";
        else fm_menu_hint = "Не удалось создать файл";
    }
    fm_reload_and_draw(m, w);
}

static void fm_input_cancel(void *ctx)
{
    (void)ctx;
    fm_menu_hint = "Отменено";
}

/* колбэк меню: исполняется в потоке окна Файлов (WEV_MENU) */
static void fm_menu_cb(int id, void *ctx)
{
    window_t *w = (window_t *)ctx;
    fm_t *m = (fm_t *)w->data;
    if (!m) return;
    char full[232];

    switch (id) {
    case FMC_OPEN:
        fm_open_selected(w);
        break;
    case FMC_RELOAD:
        fm_reload_and_draw(m, w);
        break;
    case FMC_MKDIR:
    case FMC_TOUCH:
        /* ввод имени — через переиспользуемый диалог (filedlg) */
        {
            extern void serial_puts(const char *s);
            serial_puts(id == FMC_MKDIR ? "[fm] диалог: папка\n"
                                        : "[fm] диалог: файл\n");
        }
        fm_menu_hint = (id == FMC_MKDIR) ? "Новая папка" : "Новый файл";
        fm_pending_kind = id;
        fm_input_owner = w;
        filedlg_input_open(fm_menu_hint,
                           id == FMC_MKDIR ? "Имя папки:" : "Имя файла:",
                           "", FD_NAME_MAX,
                           fm_input_ok, fm_input_cancel, w);
        break;
    case FMC_DELETE: {
        if (m->mode != FM_MODE_RAM) break;
        int total = m->ram_n;
        if (m->sel < 0 || m->sel >= total) break;
        ramfs_dirent_t *e = &m->ram_ents[m->sel];
        fm_ram_full(full, sizeof(full), m, e->name);
        if (!ramfs_delete(full)) {
            /* каталог не пуст (или файл занят) */
            fm_menu_hint = e->is_dir ? "Каталог не пуст" : "Не удалось удалить";
        } else {
            fm_menu_hint = "Удалено";
        }
        fm_reload_and_draw(m, w);
        break;
    }
    }
}


static void fm_draw(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x17, 0x1C));

    /* === Панель выбора устройства === */
    fb_fill_rect(0, 0, cw, FM_DEVBAR, fb_rgb(0x0C, 0x0F, 0x14));
    fb_hline(0, cw - 1, FM_DEVBAR - 1, fb_rgb(0x2C, 0x31, 0x38));
    {
        /* Сессия 12: рисуем только ДОСТУПНЫЕ источники (см. fm_src_avail) */
        int bx = 6;
        for (int i = 0; i < 4; i++) {
            if (!fm_src_avail(fm_btn_mode[i])) continue;
            int bw = 50;
            int hot = (m->mode == fm_btn_mode[i]);
            int hov = (m->dev_hover == i);
            u32 bg = hot ? fb_rgb(0x24, 0x43, 0x5F) :
                    (hov ? fb_rgb(0x1E, 0x33, 0x4A) : fb_rgb(0x14, 0x18, 0x1E));
            u32 fg = hot ? fb_rgb(0xE6, 0xEA, 0xEE) : fb_rgb(0x9A, 0xA3, 0xAC);
            fb_fill_rect(bx, 2, bw, FM_DEVBAR - 4, bg);
            fb_rect(bx, 2, bw, FM_DEVBAR - 4, fb_rgb(0x2C, 0x31, 0x38));
            fb_text(bx + 6, 4, fm_btn_name[i], fg, -1);
            bx += bw + 4;
        }
        /* Информация о выбранном устройстве справа */
        const char *info = "";
        if (m->mode == FM_MODE_ISO)
            info = iso9660_ready() ? "CD/ISO9660" : "нет CD";
        else if (m->mode == FM_MODE_ATA) {
            if (fm_hdd_fs == 1)
                info = ntfs_ready() ? ntfs_label() : "нет NTFS";
            else
                info = fat32_ready() ? fat32_label() : "нет FAT32";
        }
        else if (m->mode == FM_MODE_RAM)
            info = ramfs_ready() ? "RAM disk" : "не инициализирован";
        else
            info = fat32_ready() ? fat32_label() : "нет флешки";
        fb_text(bx + 8, 4, info, fb_rgb(0x6F, 0xB3, 0xF2), -1);
    }

    /* === Заголовок с путём === */
    {
        int hy = FM_DEVBAR;
        fb_fill_rect(0, hy, cw, FM_HDR, fb_rgb(0x1E, 0x4A, 0x73));
        char title[120];
        const char *mode_name = m->mode == FM_MODE_ISO ? "CD/ISO9660" :
                                (m->mode == FM_MODE_ATA
                                 ? (fm_hdd_fs == 1 ? "NTFS" : "FAT32") :
                                m->mode == FM_MODE_RAM ? "RAMFS" : "USB");
        snprintf(title, sizeof(title), "%s: %s",
                 mode_name, m->stk[m->depth].path);
        fb_text(6, hy + (FM_HDR - 16) / 2, title, fb_rgb(0xE6, 0xEA, 0xEE), -1);
    }

    /* Проверка готовности устройства */
    int list_y0 = FM_DEVBAR + FM_HDR;
    {
        const char *msg = NULL;
        if (m->mode == FM_MODE_ISO && !iso9660_ready())
            msg = "CD/ISO9660: диск не читается";
        else if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1 && !ntfs_ready())
            msg = sata_pending() ? "SATA: инициализация в фоне (AHCI)..."
                                 : "NTFS-раздел не найден.";
        else if (((m->mode == FM_MODE_ATA && fm_hdd_fs == 0) ||
                  m->mode == FM_MODE_USB) && !fat32_ready())
            msg = m->mode == FM_MODE_USB ? "USB FAT32: флешка не готова"
                                         : (sata_pending()
                                            ? "SATA: инициализация в фоне (AHCI)..."
                                            : "FAT32-раздел не найден.");
        else if (m->mode == FM_MODE_RAM && !ramfs_ready())
            msg = "RAMFS не инициализирован.";
        if (msg) {
            fb_text(12, list_y0 + 8, msg, fb_rgb(0xE0, 0x9A, 0x9A), -1);
            fb_text(12, list_y0 + 28, sata_pending() ? "Кнопка [HDD] оживёт сама"
                       : "Кликните на устройство выше", fb_rgb(0x8A, 0x93, 0x9C), -1);
            return;
        }
    }

    int area_h  = ch - list_y0 - 20;
    int vis = area_h / FM_ROW;
    if (vis < 1) vis = 1;
    if (m->sel < m->scroll) m->scroll = m->sel;
    if (m->sel >= m->scroll + vis) m->scroll = m->sel - vis + 1;

    int y0 = list_y0 + 2;
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    
    for (int i = 0; i < vis; i++) {
        int idx = m->scroll + i;
        if (idx >= total) break;
        
        const char *name;
        u32 size;
        int is_dir;
        
        if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
            ntfs_dirent_t *e = &m->ntfs_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        } else if (m->mode == FM_MODE_ISO) {
            iso9660_dirent_t *e = &m->iso_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        } else if (FM_IS_FAT(m->mode)) {
            fat32_dirent_t *e = &m->fat_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = (e->attr & 0x10) ? 1 : 0;
        } else {
            ramfs_dirent_t *e = &m->ram_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        }
        
        int yy = y0 + i * FM_ROW;
        if (idx == m->sel)
            fb_fill_rect(0, yy, cw, FM_ROW, fb_rgb(0x24, 0x43, 0x5F));

        u32 col = is_dir ? fb_rgb(0x8F, 0xC8, 0xFF) : fb_rgb(0xDD, 0xE2, 0xE6);
        fb_text(6, yy + 1, is_dir ? "[D]" : "   ", col, -1);
        fb_text(6 + 4*8, yy + 1, name, col, -1);

        if (!is_dir) {
            char buf[24];
            if (size < 1024)                 snprintf(buf, sizeof(buf), "%u B",   (unsigned)size);
            else if (size < 1024u*1024)      snprintf(buf, sizeof(buf), "%u KiB", (unsigned)(size/1024));
            else                             snprintf(buf, sizeof(buf), "%u MiB", (unsigned)(size/(1024u*1024)));
            int tw = (int)strlen(buf) * 8;
            fb_text(cw - tw - 8, yy + 1, buf, fb_rgb(0x8A, 0x93, 0x9C), -1);
        }
    }

    char st[96];
    snprintf(st, sizeof(st), "%d / %d | Tab: режим%s%s",
             total ? m->sel + 1 : 0, total,
             (m->mode == FM_MODE_ATA && fat32_ready() && ntfs_ready())
                 ? ", F5: FAT32/NTFS" : "",
             m->mode == FM_MODE_RAM ? ", ПКМ: меню" : "");
    fb_text(6, ch - 16, st, fb_rgb(0x8A, 0x93, 0x9C), -1);
    if (fm_menu_hint && fm_menu_hint[0]) {
        fb_text(6, ch - 32, fm_menu_hint, fb_rgb(0x90, 0xEE, 0x90), -1);
        fm_menu_hint = NULL;              /* показываем один раз */
    }
}

/* --------- просмотрщик --------- */

typedef struct {
    char *buf;
    u32   len;
    int   top;
    int   source; /* 0 = FAT32, 1 = RAMFS, 2 = CD/ISO9660 */
} viewer_t;

static void viewer_draw(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int cols = cw / 8;
    int vis  = ch / 16;

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x0B, 0x0E, 0x11));

    /* Заголовок с источником */
    const char *src = v->source == 0 ? "FAT32" :
                      v->source == 2 ? "CD/ISO9660" : "RAMFS";
    u32 src_col = v->source == 0 ? fb_rgb(0x8F, 0xC8, 0xFF) :
                  v->source == 2 ? fb_rgb(0xFF, 0xE0, 0x60) : fb_rgb(0x90, 0xEE, 0x90);
    fb_text(4, 2, src, src_col, -1);

    int line = 0, i = 0;
    while (i < (int)v->len && line < v->top) {
        if (v->buf[i] == '\n') line++;
        i++;
    }
    int y = 18;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)v->len; r++) {
        int start = i, end = i;
        while (end < (int)v->len && v->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols) len = cols;
        if (len > 255)  len = 255;
        memcpy(tmp, v->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xC6, 0xCD, 0xD5), -1);
        i = end + (end < (int)v->len ? 1 : 0);
        y += 16;
    }
}

static void viewer_key(window_t *w, const key_event_t *ev)
{
    viewer_t *v = (viewer_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == KBD_UP)   { if (v->top > 0) v->top--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { v->top++; win_invalidate(w); }
    if (ev->code == 0x49)     { v->top -= 16; if (v->top < 0) v->top = 0; win_invalidate(w); }
    if (ev->code == 0x51)     { v->top += 16; win_invalidate(w); }
}

static void viewer_close(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    if (v) { if (v->buf) free(v->buf); free(v); }
}

static void viewer_open_fat(const fat32_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 0;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = fat32_read_file(e->first_cluster, e->size, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [FAT32]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

/* Сессия 13: чтение RAM-файла по ПОЛНОМУ пути (иерархия каталогов);
 * e->name используется только для заголовка окна. */
static void viewer_open_ram_path(const char *full, const ramfs_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 1;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = ramfs_read(full, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [RAMFS]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

/* Просмотр файла с NTFS-раздела (сессия 11) */
static void viewer_open_ntfs(const char *dir_path, const ntfs_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 0;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }

    char full[224];
    snprintf(full, sizeof(full), "%s/%s", dir_path, e->name);
    v->len = ntfs_read_file(full, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [NTFS]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

/* Просмотр файла с загрузочного CD (ISO9660, только чтение) */
static void viewer_open_iso(const iso9660_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(v));
    v->source = 2;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = iso9660_read_file(e->first_lba, e->size, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [CD]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

/* --------- события файлового менеджера --------- */

static int name_is_cs_script(const char *name)
{
    int L = (int)strlen(name);
    if (L < 3) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 3) return 0;
    return (name[dot+1]=='c'||name[dot+1]=='C') && (name[dot+2]=='s'||name[dot+2]=='S');
}

static int name_is_c4_source(const char *name)
{
    int L = (int)strlen(name);
    if (L < 2) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 2) return 0;
    char ext = name[dot + 1];
    return (ext == 'c' || ext == 'C');
}

/* Проверить, заканчивается ли имя на .bin (исполняемое приложение). */
static int name_is_bin_app(const char *name)
{
    int L = (int)strlen(name);
    if (L < 5) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 4) return 0;
    return (name[dot+1]=='b'||name[dot+1]=='B')
        && (name[dot+2]=='i'||name[dot+2]=='I')
        && (name[dot+3]=='n'||name[dot+3]=='N');
}

static void fm_open_selected(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    if (m->sel < 0 || m->sel >= total) return;

    if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
        /* NTFS: каталогы по пути, файлы — редактор/просмотрщик */
        ntfs_dirent_t *e = &m->ntfs_ents[m->sel];
        if (e->is_dir) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            m->sel = 0;
            m->scroll = 0;
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name) || name_is_c4_source(e->name)) {
            /* .cs/.c с NTFS → копия в RAM disk → редактор */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                char full[224];
                snprintf(full, sizeof(full), "%s/%s",
                         m->stk[m->depth].path, e->name);
                u32 got = ntfs_read_file(full, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                if (name_is_cs_script(e->name))
                    app_cmscript_open_with(e->name, buf, (int)got);
                else
                    app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else {
            viewer_open_ntfs(m->stk[m->depth].path, e);
        }
    } else if (m->mode == FM_MODE_ISO) {
        /* CD/ISO9660: каталогы по LBA+размеру, файлы — просмотр/копирование */
        iso9660_dirent_t *e = &m->iso_ents[m->sel];
        if (e->is_dir) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            m->stk[m->depth].cluster = e->first_lba;   /* LBA каталога */
            m->stk[m->depth].iso_size = e->size;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            m->sel = 0;
            m->scroll = 0;
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name) || name_is_c4_source(e->name)) {
            /* .cs/.c с CD → скопировать в RAM disk и открыть в редакторе */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = iso9660_read_file(e->first_lba, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                if (name_is_cs_script(e->name))
                    app_cmscript_open_with(e->name, buf, (int)got);
                else
                    app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else {
            viewer_open_iso(e);
        }
    } else if (FM_IS_FAT(m->mode)) {
        /* FAT32 режим (ATA или USB) */
        fat32_dirent_t *e = &m->fat_ents[m->sel];
        if (e->attr & 0x10) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            m->stk[m->depth].cluster = e->first_cluster;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name)) {
            /* .cs-файл → открыть в CMScript-редакторе */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                app_cmscript_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_c4_source(e->name)) {
            /* .c-файл → открыть в редакторе C (как .cs: копия в RAM disk) */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else {
            /* прочие файлы → простой просмотрщик */
            viewer_open_fat(e);
        }
    } else {
        /* RAMFS режим (сессия 13: каталоги — иерархия, файлы — по полному
         * пути: e->name из list_dir — БАЗОВОЕ имя, читаем cur_path+name) */
        ramfs_dirent_t *e = &m->ram_ents[m->sel];
        char full[232];
        fm_ram_full(full, sizeof(full), m, e->name);
        if (e->is_dir) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            m->sel = 0;
            m->scroll = 0;
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_c4_source(e->name)) {
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                buf[got] = 0;
                app_editor_open_with(full, buf, (int)got);
                free(buf);
            }
        } else if (name_is_cs_script(e->name)) {
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                buf[got] = 0;
                app_cmscript_open_with(full, buf, (int)got);
                free(buf);
            }
        } else if (name_is_bin_app(e->name)) {
            int tid = loader_spawn(full, NULL);
            (void)tid;
        } else {
            viewer_open_ram_path(full, e);
        }
    }
}

static void fm_up(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    if (m->depth == 0) return;
    m->depth--;
    fm_reload(m);
    win_invalidate(w);
}

static void fm_switch_mode(fm_t *m, int new_mode)
{
    if (new_mode < 0 || new_mode >= FM_MODE_COUNT) return;
    m->mode = new_mode;
    m->depth = 0;
    m->sel = 0;
    m->scroll = 0;
    if (m->mode == FM_MODE_ATA) {
        fat32_init();
        /* сессия 11: ФС по умолчанию — FAT32, иначе NTFS */
        if (!fat32_ready() && ntfs_ready()) fm_hdd_fs = 1;
        else if (!ntfs_ready()) fm_hdd_fs = 0;
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else if (m->mode == FM_MODE_USB) {
        if (!fat32_init_usb())
            fm_usb_bad = 1;     /* Сессия 12: ФС не FAT32 — кнопку прячем */
        else
            fm_usb_bad = 0;
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else {
        /* CD/ISO9660 и RAMFS — инициализация уже выполнена при загрузке */
        m->stk[0].cluster = 0;
    }
    strcpy(m->stk[0].path, "/");
    fm_reload(m);
}

static void fm_key(window_t *w, const key_event_t *ev)
{
    fm_t *m = (fm_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    
    if (ev->code == 0x3F) { /* F5 — FAT32 <-> NTFS на [HDD] (если обе смонтированы) */
        if (m->mode == FM_MODE_ATA && fat32_ready() && ntfs_ready()) {
            fm_hdd_fs = fm_hdd_fs ? 0 : 1;
            m->depth = 0;
            m->sel = 0;
            m->scroll = 0;
            m->stk[0].cluster = fat32_root_cluster();
            strcpy(m->stk[0].path, "/");
            fm_reload(m);
            win_invalidate(w);
        }
        return;
    }

    if (ev->code == 0x0F) { /* Tab - переключение режима (CD → HDD → RAM → USB → CD) */
        int cur_btn = 0;
        for (int i = 0; i < 4; i++)
            if (fm_btn_mode[i] == m->mode) { cur_btn = i; break; }
        fm_switch_mode(m, fm_btn_mode[(cur_btn + 1) % 4]);
        win_invalidate(w);
        return;
    }
    
    if (ev->code == KBD_UP)   { if (m->sel > 0)     m->sel--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { 
        int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                    FM_IS_FAT(m->mode) ? m->fat_n :
                    (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
        if (m->sel+1 < total) m->sel++; 
        win_invalidate(w); 
    }
    if (ev->code == 0x1C || ev->ch == '\n') fm_open_selected(w);
    if (ev->code == 0x0E || ev->ch == '\b') fm_up(w);
    if (ev->ch == 'r' || ev->ch == 'R') { fm_reload(m); win_invalidate(w); }
    /* Esc — закрыть файловый менеджер (как браузер и HTTP Trace) */
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
}

static void fm_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    fm_t *m = (fm_t *)w->data;

    /* Обработка кликов по кнопкам устройств (только ДОСТУПНЫЕ — сессия 12) */
    if (my < FM_DEVBAR) {
        /* Подсветка наведения: та же последовательность кнопок, что в draw */
        int bx = 6;
        int new_hover = -1;
        for (int i = 0; i < 4; i++) {
            if (!fm_src_avail(fm_btn_mode[i])) continue;
            if (mx >= bx && mx < bx + 50) { new_hover = i; break; }
            bx += 50 + 4;
        }
        if (new_hover != m->dev_hover) {
            m->dev_hover = new_hover;
            win_invalidate(w);
        }
        /* Клик по кнопке: индекс кнопки → режим через fm_btn_mode */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && new_hover >= 0) {
            fm_switch_mode(m, fm_btn_mode[new_hover]);
            win_invalidate(w);
        }
        return;
    }
    m->dev_hover = -1;

    fm_mouse_rmb(w, m, mx, my, btn, changed);

    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT)) return;
    if (my < FM_DEVBAR + FM_HDR + 2) return;
    int row = (my - FM_DEVBAR - FM_HDR - 2) / FM_ROW;
    int idx = m->scroll + row;
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    if (idx < 0 || idx >= total) return;
    if (idx == m->sel) fm_open_selected(w);
    else { m->sel = idx; win_invalidate(w); }
}

/* ---- ПКМ: контекстное меню (сессия 13) ---- */
static wm_menu_item_t fm_menu_items[8];
static int fm_menu_n;

static void fm_mouse_rmb(window_t *w, fm_t *m, int mx, int my, u8 btn, u8 changed)
{
    if (!((changed & MSB_RIGHT) && (btn & MSB_RIGHT))) return;
    if (wm_menu_active()) return;

    /* где клик: список (строка) или пустое место */
    int on_item = 0, idx = -1;
    if (my >= FM_DEVBAR + FM_HDR + 2) {
        int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                    FM_IS_FAT(m->mode) ? m->fat_n :
                    (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
        int row = (my - FM_DEVBAR - FM_HDR - 2) / FM_ROW;
        idx = m->scroll + row;
        if (idx >= 0 && idx < total) {
            on_item = 1;
            if (idx != m->sel) { m->sel = idx; win_invalidate(w); }
        }
    }

    fm_menu_n = 0;
    if (on_item) {
        fm_menu_items[fm_menu_n].label = "Открыть";
        fm_menu_items[fm_menu_n].id = FMC_OPEN;
        fm_menu_items[fm_menu_n].disabled = 0;
        fm_menu_n++;
    }
    /* Создание/удаление — только в RAM disk */
    if (m->mode == FM_MODE_RAM) {
        if (fm_menu_n) {
            fm_menu_items[fm_menu_n].label = NULL;  /* разделитель */
            fm_menu_items[fm_menu_n].id = 0;
            fm_menu_items[fm_menu_n].disabled = 0;
            fm_menu_n++;
        }
        fm_menu_items[fm_menu_n].label = "Создать папку";
        fm_menu_items[fm_menu_n].id = FMC_MKDIR;
        fm_menu_items[fm_menu_n].disabled = 0;
        fm_menu_n++;
        fm_menu_items[fm_menu_n].label = "Создать файл";
        fm_menu_items[fm_menu_n].id = FMC_TOUCH;
        fm_menu_items[fm_menu_n].disabled = 0;
        fm_menu_n++;
        if (on_item) {
            fm_menu_items[fm_menu_n].label = "Удалить";
            fm_menu_items[fm_menu_n].id = FMC_DELETE;
            fm_menu_items[fm_menu_n].disabled = 0;
            fm_menu_n++;
        }
    }
    if (fm_menu_n) {
        fm_menu_items[fm_menu_n].label = NULL;      /* разделитель */
        fm_menu_items[fm_menu_n].id = 0;
        fm_menu_items[fm_menu_n].disabled = 0;
        fm_menu_n++;
    }
    fm_menu_items[fm_menu_n].label = "Обновить";
    fm_menu_items[fm_menu_n].id = FMC_RELOAD;
    fm_menu_items[fm_menu_n].disabled = 0;
    fm_menu_n++;

    {
        extern void serial_puts(const char *s);
        extern int snprintf(char *o, u32 n, const char *f, ...);
        char mb[96];
        snprintf(mb, sizeof(mb), "[fm] ПКМ: mode=%d idx=%d total=%d on_item=%d\n",
                 m->mode, idx, (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                 FM_IS_FAT(m->mode) ? m->fat_n :
                 (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n), on_item);
        serial_puts(mb);
    }
    wm_menu_open(w, mx, my, fm_menu_items, fm_menu_n, fm_menu_cb, (void *)w);
}

static void fm_close(window_t *w) { free(w->data); }

/* Тик 2 Гц (сессия 11): пока фоновая задача sata инициализирует AHCI,
 * состояние кнопки [HDD] меняется сама — обновляем окно при изменении. */
static void fm_tick(window_t *w)
{
    fm_t *m = (fm_t *)w->data;

    /* Сессия 12: панель живёт состоянием ФС — следим за всеми
     * источниками, а не только за «диск найден»:
     *  - SATA доезжает в фоне → FAT32/NTFS готовы → кнопка [HDD] появляется;
     *  - флешка обнаружена → пробуем смонтировать FAT32 один раз
     *    (удача — кнопка [USB]; неудача — не показываем);
     *  - текущий источник стал недоступен → переключаемся на первый живой. */
    static int usb_seen = 0;
    if (usb_ehci_storage_ready() && !usb_seen &&
        !(fat32_ready() && fat32_is_usb()) && !m->usb_inited) {
        m->usb_inited = 1;
        if (!fat32_init_usb())
            fm_usb_bad = 1;
    }
    usb_seen = usb_ehci_storage_ready() ? 1 : 0;

    int avail = fm_src_avail(FM_MODE_ATA);
    int changed = 0;
    if (avail != m->hdd_avail_snap) {
        m->hdd_avail_snap = avail;
        changed = 1;
        if (m->mode == FM_MODE_ATA)
            fm_reload(m);
    }
    if (!fm_src_avail(m->mode)) {
        int first = fm_first_avail_mode();
        if (first != m->mode) {
            fm_switch_mode(m, first);
            changed = 1;
        }
    }
    if (changed)
        win_invalidate(w);
}

void app_files_open(void)
{
    fm_t *m = (fm_t *)malloc(sizeof(fm_t));
    if (!m) return;
    memset(m, 0, sizeof(fm_t));

    m->depth = 0;
    m->hdd_avail_snap = disk_hdd_present() ? 1 : 0;
    /* Режим по умолчанию: загрузочный CD, затем HDD (FAT32/NTFS), RAM */
    if (iso9660_ready())          m->mode = FM_MODE_ISO;
    else if (fat32_ready())       { m->mode = FM_MODE_ATA; fm_hdd_fs = 0; }
    else if (ntfs_ready())        { m->mode = FM_MODE_ATA; fm_hdd_fs = 1; }
    else if (ramfs_ready())       m->mode = FM_MODE_RAM;
    else                          m->mode = FM_MODE_ATA;
    m->stk[0].cluster = (m->mode == FM_MODE_ATA && fat32_ready())
                        ? fat32_root_cluster() : 0;
    strcpy(m->stk[0].path, "/");
    fm_reload(m);

    u32 W = fb_width(), H = fb_height();
    int ww = 520, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("Файлы", 30, 30, ww, wh, fm_draw, fm_key, fm_mouse, fm_tick, fm_close, m);
}