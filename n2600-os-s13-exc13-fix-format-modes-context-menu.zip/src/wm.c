/* wm.c — оконный менеджер N2600-OS.
 * Композитинг: backbuffer -> LFB. Перерисовываются только «грязные» области:
 * полный кадр нужен при перетаскивании/изменении z-порядка, в остальных
 * случаях обновляются только прямоугольники (курсор, текст, часы). */
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "mouse.h"
#include "rtc.h"
#include "string.h"
#include "task.h"
#include "timer.h"
#include "sync.h"
#include "apps.h"
#include "e1000.h"
#include "net.h"

/* --------------------------- палитра интерфейса --------------------------- */
#define COL_ACCENT      fb_rgb(0x3E, 0x7D, 0xBF)
#define COL_BORDER      fb_rgb(0x34, 0x38, 0x3E)
#define COL_TITLE_FOC   fb_rgb(0x1E, 0x4A, 0x73)
#define COL_TITLE       fb_rgb(0x25, 0x2A, 0x30)
#define COL_CLOSE       fb_rgb(0x8C, 0x2E, 0x2E)
#define COL_CLOSE_HOT   fb_rgb(0xB0, 0x38, 0x38)
#define COL_TBAR        fb_rgb(0x12, 0x16, 0x1B)
#define COL_TBAR_LINE   fb_rgb(0x2C, 0x31, 0x38)
#define COL_BTN         fb_rgb(0x1B, 0x21, 0x27)
#define COL_BTN_ACT     fb_rgb(0x24, 0x43, 0x5F)
#define COL_MENU        fb_rgb(0x17, 0x1C, 0x22)
#define COL_MENU_LINE   fb_rgb(0x30, 0x36, 0x3E)
#define COL_MENU_HOT    fb_rgb(0x24, 0x43, 0x5F)
#define COL_TEXT        fb_rgb(0xE6, 0xEA, 0xEE)
#define COL_TEXT_DIM    fb_rgb(0x9A, 0xA3, 0xAC)

static window_t *wins[WM_MAX_WINDOWS];
static int nwin = 0;
static u32  win_serial_next = 1;   /* FIX [W1]: стабильный порядок таскбара */

static window_t *drag_win = NULL;
static int drag_dx = 0, drag_dy = 0;
static window_t *resize_win = NULL;   /* окно, размер которого меняем */
static int resize_start_w = 0, resize_start_h = 0;
static int resize_start_x = 0, resize_start_y = 0;
static window_t *pending_close = NULL;
static int menu_open = 0, menu_hover = -1;

static int cur_x = 0, cur_y = 0;        /* позиция курсора (последняя отрисованная) */

/* ---- мини-блокировки (см. комментарий в секции многопоточного WM) ---- */
static volatile int wm_glock = 0;

/* ---- мини-блокировки ----
 * ЕДИНАЯ реализация — sync.h (s_lock/s_unlock/s_trylock):
 *   * значение = владелец+1 → ждущий видит, КТО держит;
 *   * если владелец убит, держа блокировку (task_kill/ватчдог) —
 *     блокировка освобождается силой: раньше это НАМЕРТВО фризило
 *     kmain (composite ждёт wm_glock, wm_key ждёт qlock окна —
 *     а kmain делает мышь/клавиатуру/композитинг для всей системы);
 *   * если владелец завис внутри секции > 20 с — блокировка
 *     отбирается (busy-loop ватчдог не видит).
 * Обёртки оставлены, чтобы не менять ~40 мест вызова. */

static void wl_lock(volatile int *l)
{
    s_lock(l);
}

static void wl_unlock(volatile int *l)
{
    s_unlock(l);
}

/* Попытка захвата с ограниченным числом повторов (для kmain):
 * никогда не блокируется надолго; мёртвого владельца чинит s_trylock. */
static int wl_trylock(volatile int *l, int spins)
{
    for (int i = 0; i < spins; i++) {
        if (s_trylock(l)) return 1;
    }
    return 0;
}


static int cursor_visible = 0;
static int blink_state = 0;
static int tooltip_win_idx = -1;         /* индекс окна для tooltip (-1 = нет) */
static int tooltip_timer = 0;            /* таймер показа tooltip (тики) */

/* служебные действия (реализованы в kernel.c) */
extern void sys_reboot(void);
extern void sys_poweroff(void);

/* ------------------------------- курсор ------------------------------- */
static const char *cursor_map[19] = {
    "X           ",
    "XX          ",
    "X*X         ",
    "X**X        ",
    "X***X       ",
    "X****X      ",
    "X*****X     ",
    "X******X    ",
    "X*******X   ",
    "X********X  ",
    "X*****XXXXX ",
    "X**X**X     ",
    "X*X X**X    ",
    "XX  X**X    ",
    "X    X**X   ",
    "     X**X   ",
    "      XX    ",
    "            ",
    "            "
};

static void draw_cursor(void)
{
    u32 black = fb_rgb(0, 0, 0), white = fb_rgb(0xFF, 0xFF, 0xFF);
    for (int r = 0; r < 19; r++) {
        for (int c = 0; c < 12; c++) {
            char ch = cursor_map[r][c];
            if (ch == ' ') continue;
            fb_fill_rect(cur_x + c, cur_y + r, 1, 1,
                         (ch == 'X') ? black : white);
        }
    }
}

/* ------------------------------ служебное ------------------------------ */

static int rect_intersect(int ax, int ay, int aw, int ah,
                          int bx, int by, int bw, int bh)
{
    return ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah;
}

static void win_content_rect(window_t *w, int *cx, int *cy, int *cw, int *ch)
{
    *cx = w->x + 1;
    *cy = w->y + TITLE_H + 1;
    *cw = w->w - 2;
    *ch = w->h - TITLE_H - 2;
}

int win_content_w(window_t *w) { return w->w - 2; }
int win_content_h(window_t *w) { return w->h - TITLE_H - 2; }

static int window_at(int x, int y)
{
    for (int i = nwin - 1; i >= 0; i--) {
        if (wins[i]->minimized) continue;     /* свёрнутые окна не ловят клики */
        if (x >= wins[i]->x && x < wins[i]->x + wins[i]->w &&
            y >= wins[i]->y && y < wins[i]->y + wins[i]->h)
            return i;
    }
    return -1;
}

static void raise_window(int idx)
{
    if (idx < 0 || idx == nwin - 1) return;
    /* под glock: исключение с win_create/удалениями из других потоков */
    wl_lock(&wm_glock);
    window_t *w = wins[idx];
    for (int i = idx; i < nwin - 1; i++) wins[i] = wins[i + 1];
    wins[nwin - 1] = w;
    wl_unlock(&wm_glock);
    fb_touch_all(); /* изменился z-порядок — полная перерисовка */
}

/* Найти верхнее НЕ свёрнутое окно (для фокуса). */
static int top_visible_window(void)
{
    for (int i = nwin - 1; i >= 0; i--)
        if (!wins[i]->minimized) return i;
    return -1;
}

/* ========================================================================
 * Многопоточный WM: поток на каждое окно ( FIX всего семейства
 * «зависло одно приложение — встала вся система» ).
 *
 * Модель:
 *   win_create()      — создаёт окно + canvas (пиксельный буфер содержимого)
 *                       + ПОТОК (task_spawn) и подключает canvas как цель
 *                       рендера задачи (fb_task_canvas_attach).
 *   wm_key/mouse/halfsec — БОЛЬШЕ не вызывают колбэки приложений напрямую:
 *                       они кладут событие в очередь окна (win_post) и
 *                       будят поток (task_wake). kmain никогда не выполняет
 *                       код приложений — только композитит canvas'ы.
 *   Поток окна         — вынимает события, вызывает колбэки, рисует в
 *                       СВОЙ canvas; закончив работу — помечает need_draw;
 *                       если работы нет — спит (task_set_waiting_me + hlt).
 *   wm_frame (kmain)   — закрывает окна, пересоздаёт canvas при resize,
 *                       убирает мёртвые окна (reaper), композитит:
 *                       хром окна + blit canvas на экран.
 *
 * Блокировки (одного уровня, без вложенного ожидания):
 *   wm_glock — защищает wins[]/nwin (win_create из любого потока против
 *              kmain-итераций);
 *   qlock    — очередь событий окна (kmain кладёт / поток вынимает);
 *   rlock    — секция рендера canvas в потоке против пересоздания canvas
 *              в kmain (resize) и против blit'а в composite.
 *              kmain всегда берёт её try-ом и НИКОГДА не ждёт.
 * ======================================================================== */

extern void serial_puts(const char *s);

typedef enum { WEV_KEY = 1, WEV_MOUSE, WEV_TICK, WEV_CLOSE,
               WEV_MENU } wev_kind_t;   /* сессия 13: контекстное меню */

typedef struct {
    u8           kind;
    key_event_t  key;          /* WEV_KEY */
    int          mx, my;       /* WEV_MOUSE (координаты от содержимого) */
    u8           btn, changed;
    int          menu_id;      /* WEV_MENU */
    void        *menu_cb;      /* WEV_MENU: колбэк (исполнить в ЭТОМ потоке) */
    void        *menu_ctx;     /* WEV_MENU: пользовательский контекст */
} wev_t;

typedef struct {
    wev_t        q[24];
    volatile int head;         /* сюда пишем */
    volatile int tail;         /* отсюда читаем */
    volatile int qlock;
    volatile int rlock;        /* рендер canvas / realloc / blit */
    volatile int need_draw;    /* поток должен перерисовать canvas */
    volatile int closing;      /* CLOSE отправлен */
    volatile int dead;         /* поток завершился, память можно освободить */
    volatile int no_canvas;    /* сессия 12: canvas сознательно отключён от
                                * потока (c4gfx: рисует задача программы) —
                                * ожидать attach в потоке НЕ нужно */
} win_thr_t;

/* ---- очередь событий окна ---- */

static void win_post(window_t *w, const wev_t *ev)
{
    if (!w || w->task < 0) return;
    win_thr_t *t = (win_thr_t *)w->thr;
    if (!t) return;

    int dropped = 0;
    wl_lock(&t->qlock);
    int cnt = (t->head - t->tail + 24) % 24;
    if (cnt >= 23) {
        dropped = 1;
    } else {
        t->q[t->head] = *ev;
        t->head = (t->head + 1) % 24;
    }
    wl_unlock(&t->qlock);
    if (dropped) {
        serial_puts("[wm] event queue full, drop (window hung?)\n");
        return;
    }
    task_wake(w->task);
}

/* Отправить CLOSE: даже если очередь забита — очищаем её (события
 * всё равно уже не нужны) и кладём CLOSE. */
static void win_post_close(window_t *w)
{
    if (!w || w->task < 0) return;
    win_thr_t *t = (win_thr_t *)w->thr;
    if (!t) return;

    wl_lock(&t->qlock);
    t->tail = 0;
    t->head = 0;
    memset(&t->q[0], 0, sizeof(t->q[0]));
    t->q[0].kind = WEV_CLOSE;
    t->head = 1;
    t->closing = 1;
    wl_unlock(&t->qlock);
    task_wake(w->task);
}

/* ---- отложенное освобождение canvas (сессия 12) ----
 * Blit canvas в composite больше не берёт rlock (см. draw_window):
 * пока поток окна рисует, композитор может одновременно читать canvas.
 * Убрать rlock нельзя было раньше ещё и из-за освобождения: поток,
 * закрываясь, делал free(canvas), и композитор мог читать освобождённую
 * память. Теперь все освобождения canvas идут через этот список:
 * kmain (wm_frame) реально освобождает буфер через 3 кадра — к этому
 * моменту ни один blit физически не может держать старый указатель. */
#define WM_TRASH_MAX 48
static u32 *wm_trash[WM_TRASH_MAX];
static int   wm_trash_age[WM_TRASH_MAX];
static int   wm_trash_n = 0;

static void wm_canvas_trash_add(u32 *p)
{
    if (!p) return;
    if (wm_trash_n >= WM_TRASH_MAX) {   /* переполнение — освобождаем старейший */
        free(wm_trash[0]);
        for (int i = 1; i < WM_TRASH_MAX; i++) {
            wm_trash[i - 1] = wm_trash[i];
            wm_trash_age[i - 1] = wm_trash_age[i];
        }
        wm_trash_n--;
    }
    wm_trash[wm_trash_n] = p;
    wm_trash_age[wm_trash_n] = 0;
    wm_trash_n++;
}

/* Вызывается ТОЛЬКО из kmain (wm_frame): стареем на кадр, освобождаем
 * повзрослевшие до 3 кадров. */
static void wm_canvas_trash_tick(void)
{
    for (int i = 0; i < wm_trash_n; ) {
        if (++wm_trash_age[i] >= 3) {
            free(wm_trash[i]);
            wm_trash[i] = wm_trash[--wm_trash_n];
            continue;
        }
        i++;
    }
}

/* ---- поток окна ---- */

static void win_thread_fn(void *arg)
{
    window_t *w = (window_t *)arg;
    win_thr_t *t = (win_thr_t *)w->thr;

    /* Сессия 12 (FIX «окна прорисовываются сквозь друг друга»):
     * ждём подключения canvas-контекста ПЕРВЫМ делом. Между task_spawn()
     * и fb_task_canvas_attach() в win_create() нас могут вытеснить — и
     * тогда НУЖНЫЙ окну canvas ещё не подключён: рисовать в этот момент
     * НЕЛЬЗЯ — вывод уйдёт в ЭКРАННЫЙ контекст (запись [0]) с координатами
     * canvas, т.е. поверх левого верхнего угла экрана и всех окон, а
     * заодно испортит clip экранной записи для kmain. Ждём attach
     * (win_create делает его микросекундами позже) с ограничением
     * по времени — если слоты кончились (не бывает с 64), поток
     * просто не рисует (окно останется тёмным). */
    {
        int guard = 0;
        while (!fb_task_has_canvas(w->task) && !t->no_canvas &&
               guard++ < 2000)
            task_yield();
        /* норма: attach происходит микросекундами позже spawn.
         * no_canvas: окно c4gfx (canvas у задачи программы).
         * guard: страховка от зависания (рисовать не будем). */
    }

    for (;;) {
        /* 1) события (сначала добираем всё) */
        wev_t ev;
        int have = 0;
        wl_lock(&t->qlock);
        if (t->head != t->tail) {
            ev = t->q[t->tail];
            t->tail = (t->tail + 1) % 24;
            have = 1;
        }
        wl_unlock(&t->qlock);

        if (have) {
            switch (ev.kind) {
            case WEV_CLOSE:
                /* колбэк освобождает данные приложения в его потоке;
                 * canvas тоже освобождаем здесь (владелец — поток), но
                 * НЕ напрямую, а через trash-список (сессия 12): композитор
                 * мог читать этот canvas в момент закрытия (blit теперь
                 * lock-free) — освобождаем через 3 кадра, когда ни один
                 * blit уже не может его держать */
                if (w->on_close) w->on_close(w);
                wl_lock(&t->rlock);
                fb_task_canvas_detach(w->task);
                if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
                wl_unlock(&t->rlock);
                t->dead = 1;
                task_exit();               /* не вернёмся */
                break;
            case WEV_KEY:
                if (w->on_key) w->on_key(w, &ev.key);
                break;
            case WEV_MOUSE:
                if (w->on_mouse) w->on_mouse(w, ev.mx, ev.my, ev.btn, ev.changed);
                break;
            case WEV_TICK:
                if (w->on_tick) w->on_tick(w);
                break;
            case WEV_MENU:
                /* контекстное меню (сессия 13): колбэк приложения
                 * исполняется в ПОТОКЕ ОКНА-ВЛАДЕЛЬЦА — без гонок */
                {
                    wm_menu_fn cb = (wm_menu_fn)ev.menu_cb;
                    if (cb) cb(ev.menu_id, ev.menu_ctx);
                }
                break;
            default:
                break;
            }
            continue;
        }

        /* 2) перерисовка canvas */
        if (t->need_draw) {
            t->need_draw = 0;
            if (!w->minimized && w->draw && w->canvas) {
                wl_lock(&t->rlock);     /* vs realloc в kmain (resize) */
                fb_set_clip(0, 0, w->cvs_w - 1, w->cvs_h - 1);
                fb_set_origin(0, 0);
                w->draw(w);
                wl_unlock(&t->rlock);
                /* НЕ win_invalidate (это зациклило бы need_draw), а прямой
                 * fb_touch — пометить область окна на экране */
                fb_touch(w->x, w->y, w->w, w->h);
            }
            continue;
        }

        /* 3) работы нет: спим до события (hlt; планировщик нас пропускает) */
        {
            int if_had;
            __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
            if (t->head != t->tail || t->need_draw || t->closing) {
                if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
                continue;
            }
            task_set_waiting_me();
            __asm__ __volatile__("sti\n\thlt" ::: "memory");
            /* пробуждение: task_wake снял waiting, IRQ0 вернул нас */
            if (!(if_had & 0x200)) __asm__ __volatile__("cli" ::: "memory");
        }
    }
}

/* ---- zombie: окна, чей поток ещё не умер (ждём dead) ---- */
#define WM_ZOMBIE_MAX 64
static window_t *zombies[WM_ZOMBIE_MAX];
static int nzombie = 0;

/* ---- kill mailbox: диспетчер задач/ватчдог просят убить окно ---- */
#define WM_KILL_MAIL 16
static volatile int kill_mail[WM_KILL_MAIL];
static volatile int kill_mail_n = 0;
static volatile int kill_lock = 0;

void wm_request_kill(int task_idx)
{
    if (task_idx <= 0) return;
    wl_lock(&kill_lock);
    if (kill_mail_n < WM_KILL_MAIL) kill_mail[kill_mail_n++] = task_idx;
    wl_unlock(&kill_lock);
}

/* ---- ТЕСТ ЖИВУЧЕСТИ (команда spinlock в терминале) ----
 * Задача берёт wm_glock (главная блокировка оконного менеджера — её
 * ждёт composite в kmain КАЖДЫЙ кадр) и зависает в вечном цикле.
 * До фикса sync.h это НАМЕРТВО замораживало весь UI: kmain вечно
 * ждал блокировку, а с ним — мышь, клавиатуру и часы. Теперь s_lock
 * видит живого, но не отпускающего владельца и через 20 секунд
 * (SLOCK_STALE_TICKS) отбирает блокировку — система оживает.
 * Убить саму задачу: kill <N> / Del в диспетчере задач. */
static void glock_spin_fn(void *arg)
{
    (void)arg;
    wl_lock(&wm_glock);
    volatile u32 x = 0;
    for (;;) { x++; }   /* «зависли», держа блокировку */
}

int wm_test_glock_spin(void)
{
    return task_spawn("spinlock", glock_spin_fn, NULL);
}

int wm_task_of(window_t *w) { return w ? w->task : -1; }

window_t *wm_find_by_task(int task_idx)
{
    if (task_idx <= 0) return NULL;
    for (int i = 0; i < nwin; i++)
        if (wins[i] && wins[i]->task == task_idx) return wins[i];
    return NULL;
}

/* Обработка kill-запросов и вычистка мёртвых окон. Вызывается ТОЛЬКО
 * из kmain (wm_frame). */
void wm_pump_kills(void)
{
    /* 1) запросы на убийство (диспетчер задач, ватчдог) */
    for (;;) {
        int idx;
        wl_lock(&kill_lock);
        if (kill_mail_n <= 0) { wl_unlock(&kill_lock); break; }
        idx = kill_mail[--kill_mail_n];
        wl_unlock(&kill_lock);
        if (idx <= 0) continue;

        window_t *w = wm_find_by_task(idx);
        if (!w) continue;

        wl_lock(&wm_glock);
        for (int i = 0; i < nwin; i++) {
            if (wins[i] == w) {
                for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
                nwin--;
                break;
            }
        }
        wl_unlock(&wm_glock);

        /* Данные приложения: поток мёртв, ничего не изменит.
         * ВАЖНО: rlock здесь НЕ берём — убитый поток мог умереть, держа
         * rlock, и никогда его не отпустит. Мёртвый поток никому больше
         * не конкурент: окно уже вне wins[], blit его не видит.
         * Сессия 12: canvas — через trash (мог читаться композитором). */
        if (w->on_close) w->on_close(w);
        fb_task_canvas_detach(idx);
        if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
        if (w->thr) { free(w->thr); w->thr = NULL; }
        free(w);
        fb_touch_all();
    }

    /* 2) окна с уже умершим потоком (закрыты нормально: dead) */
    for (int zi = 0; zi < nzombie; ) {
        window_t *w = zombies[zi];
        win_thr_t *t = (win_thr_t *)w->thr;
        if (t && t->dead) {
            free(t);
            w->thr = NULL;
            free(w);
            zombies[zi] = zombies[--nzombie];   /* swap-remove */
            continue;                           /* без zi++ */
        }
        zi++;
    }

    /* 3) окна в wins[], чей поток убит ватчдогом/task_kill напрямую */
    for (int i = 0; i < nwin; ) {
        window_t *w = wins[i];
        if (w->task > 0 && task_finished(w->task) && !task_is_waiting(w->task)) {
            wl_lock(&wm_glock);
            for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
            nwin--;
            wl_unlock(&wm_glock);
            if (w->on_close) w->on_close(w);
            /* rlock НЕ берём: поток мёртв (см. комментарий выше) */
            fb_task_canvas_detach(w->task);
            if (w->canvas) { wm_canvas_trash_add(w->canvas); w->canvas = NULL; }
            if (w->thr) { free(w->thr); w->thr = NULL; }
            free(w);
            fb_touch_all();
            continue;
        }
        i++;
    }
}

/* ------------------------------- меню ------------------------------- */

#define MENU_W 210
#define MENU_ITEM_H 26

static int menu_items(void)
{
    return app_table_count + 3; /* приложения + разделитель + Перезагрузка + Выключение */
}

static int menu_height(void)
{
    return menu_items() * MENU_ITEM_H + 8 + 9;
}

static void menu_rect(int *mx, int *my, int *mw, int *mh)
{
    *mx = 4;
    *mw = MENU_W;
    *mh = menu_height();
    *my = (int)fb_height() - TBAR_H - *mh;
}

/* индекс пункта по экранным координатам (с учётом разделителя) или -1 */
static int menu_hit(int x, int y)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    if (x < mx || x >= mx + mw || y < my || y >= my + mh) return -1;
    int yy = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == app_table_count) { yy += 9; continue; }
        if (y >= yy && y < yy + MENU_ITEM_H) return i;
        yy += MENU_ITEM_H;
    }
    return -1;
}

static void menu_action(int idx)
{
    if (idx < app_table_count) {
        apps_open(idx);
    } else if (idx == app_table_count + 1) {
        sys_reboot();
    } else if (idx == app_table_count + 2) {
        sys_poweroff();
    }
}

/* ------------------------------ заголовки ------------------------------ */

/* ---------------- кнопки заголовка ----------------
 * Справа налево: [×] закрыть (x+w-22), [□/❐] развернуть (x+w-42),
 * [—] свернуть (x+w-62). Каждая 18x16, как и раньше у закрытия. */
#define TB_BTN_W   18
#define TB_BTN_H   16
#define TB_BTN_GAP 2   /* зазор между кнопками: 22-18=4... фактически 20-шаг */

static void title_btn_rects(window_t *w, int *close, int *maxb, int *minb)
{
    /* каждая возвращает x (y везде w->y+4) */
    if (close) *close = w->x + w->w - 22;
    if (maxb)  *maxb  = w->x + w->w - 42;
    if (minb)  *minb  = w->x + w->w - 62;
}

static void draw_close_icon(int bx, int by, u32 col)
{
    for (int k = 0; k < 9; k++) {
        fb_fill_rect(bx + k, by + k, 1, 1, col);
        fb_fill_rect(bx + 8 - k, by + k, 1, 1, col);
    }
}

/* Иконка «развернуть»: квадрат; при уже развёрнутом окне — два
 * квадрата (восстановление). */
static void draw_max_icon(int bx, int by, u32 col, int maximized)
{
    if (!maximized) {
        fb_rect(bx + 4, by + 3, 10, 10, col);
        fb_fill_rect(bx + 4, by + 3, 2, 2, col);
    } else {
        /* задний квадрат */
        fb_rect(bx + 2, by + 7, 9, 9, col);
        /* передний (с заливкой фона кнопки поверх) */
        fb_rect(bx + 6, by + 2, 10, 9, col);
        fb_hline(bx + 7, bx + 15, by + 3, col);
    }
}

/* Иконка «свернуть»: полоска внизу */
static void draw_min_icon(int bx, int by, u32 col)
{
    fb_hline(bx + 4, bx + 13, by + 11, col);
    fb_hline(bx + 4, bx + 13, by + 12, col);
}

static void draw_window(window_t *w)
{
    int focused = (nwin > 0 && wins[nwin - 1] == w);
    u32 title_col = focused ? COL_TITLE_FOC : COL_TITLE;
    u32 border_col = focused ? COL_ACCENT : COL_BORDER;

    fb_rect(w->x, w->y, w->w, w->h, border_col);
    fb_fill_rect(w->x + 1, w->y + 1, w->w - 2, TITLE_H, title_col);
    fb_text(w->x + 8, w->y + (TITLE_H - 16) / 2, w->title, COL_TEXT, -1);

    /* Три кнопки: [—] свернуть, [□] развернуть, [×] закрыть */
    int bx_close, bx_max, bx_min;
    title_btn_rects(w, &bx_close, &bx_max, &bx_min);
    int by = w->y + 4;
    u32 btn_bg = focused ? COL_BTN : fb_rgb(0x20, 0x25, 0x2B);
    u32 btn_fg = fb_rgb(0xC6, 0xCD, 0xD5);

    /* свернуть */
    fb_fill_rect(bx_min, by, TB_BTN_W, TB_BTN_H, btn_bg);
    fb_rect(bx_min, by, TB_BTN_W, TB_BTN_H, COL_BORDER);
    draw_min_icon(bx_min, by, btn_fg);

    /* развернуть/восстановить */
    fb_fill_rect(bx_max, by, TB_BTN_W, TB_BTN_H, w->maximized ? COL_BTN_ACT : btn_bg);
    fb_rect(bx_max, by, TB_BTN_W, TB_BTN_H, COL_BORDER);
    draw_max_icon(bx_max, by, btn_fg, w->maximized);

    /* закрыть */
    fb_fill_rect(bx_close, by, TB_BTN_W, TB_BTN_H,
                 (pending_close == w) ? COL_CLOSE_HOT : COL_CLOSE);
    draw_close_icon(bx_close + 4, by + 3, fb_rgb(0xF0, 0xD0, 0xD0));

    /* Resize handle: правый нижний угол (диагональные полоски).
     * У развёрнутого окна скрыт — размер менять нельзя. */
    if (!w->maximized) {
        int rx = w->x + w->w - 9;
        int ry = w->y + w->h - 9;
        u32 hc = focused ? fb_rgb(0x6F, 0xB3, 0xF2) : fb_rgb(0x50, 0x58, 0x62);
        for (int k = 0; k < 6; k++) {
            fb_fill_rect(rx + k, ry + 7, 1, 1, hc);
            fb_fill_rect(rx + 7, ry + k, 1, 1, hc);
            fb_fill_rect(rx + k + 1, ry + 5 - k, 1, 1, hc);
        }
    }

    int cx, cy, cw, ch;
    win_content_rect(w, &cx, &cy, &cw, &ch);
    fb_set_clip(cx, cy, cx + cw - 1, cy + ch - 1);

    /* Содержимое — canvas окна: его рисует ПОТОК окна (не kmain!).
     * Сессия 12: blit БЕЗ rlock. Раньше композитор брал rlock try-ом,
     * и если поток окна в этот момент перерисовывал canvas (а при
     * движении курсора потоки перерисовываются ПОСТОЯННО — hover),
     * содержимое заливалось ТЁМНЫМ — «окна мигали/пропадали при
     * движении курсора». Теперь blit идёт параллельно с рисованием:
     * одновременно виден кадр наполовину старый/новый (tearing) —
     * это нормальная цена lock-free композитинга без двойной
     * буферизации canvas, артефакт длится один кадр и незаметен.
     * От use-after-free защищает trash-список (освобождение через
     * 3 кадра, см. wm_canvas_trash_add). */
    {
        win_thr_t *t = (win_thr_t *)w->thr;
        (void)t;
        if (w->canvas)
            fb_blit_to_screen(w->canvas, w->cvs_w, w->cvs_h, cx, cy, cw, ch);
        else
            fb_fill_rect(cx, cy, cw, ch, fb_rgb(0x0B, 0x0E, 0x11));
    }
}

/* FIX [W1]: стабильный порядок кнопок таскбара.
 * Раньше кнопки рисовались в порядке массива wins[], а raise_window()
 * ПЕРЕНОСИЛ окно в конец массива — клик по кнопке (или просто фокусировка
 * окна) «перескакивал» кнопку в самый правый угол. Теперь порядок кнопок —
 * по serial (времени создания окна): кнопка всегда на своём месте,
 * как в обычных ОС. */
static int taskbar_order(int *order, int max)
{
    int n = 0;
    for (int i = 0; i < nwin && n < max; i++) {
        if (!wins[i]) continue;
        int j = n - 1;
        while (j >= 0 && wins[order[j]]->serial > wins[i]->serial) {
            order[j + 1] = order[j];
            j--;
        }
        order[j + 1] = i;
        n++;
    }
    return n;
}

/* Обрезка UTF-8 строки до max_chars видимых СИМВОЛОВ; если обрезали —
 * в конец добавляется '.'. Символ никогда не рвётся посередине. */
static void utf8_clip(char *dst, const char *src, int max_chars)
{
    int cnt = 0, o = 0;
    const char *p = src;
    while (*p) {
        int adv = 1;
        if ((*p & 0xE0) == 0xC0 && p[1]) adv = 2;
        else if ((*p & 0xF0) == 0xE0 && p[1] && p[2]) adv = 3;
        if (cnt == max_chars - 1 && p[adv] != 0) {
            dst[o++] = '.';
            break;
        }
        if (cnt >= max_chars) break;
        for (int k = 0; k < adv; k++) dst[o++] = p[k];
        p += adv;
        cnt++;
    }
    dst[o] = 0;
}

static void draw_taskbar(void)
{
    u32 H = fb_height(), W = fb_width();
    fb_fill_rect(0, (int)H - TBAR_H, (int)W, TBAR_H, COL_TBAR);
    fb_hline(0, (int)W - 1, (int)H - TBAR_H, COL_TBAR_LINE);

    /* кнопка «Меню» */
    fb_fill_rect(4, (int)H - 24, 64, 20, menu_open ? COL_BTN_ACT : COL_BTN);
    fb_rect(4, (int)H - 24, 64, 20, COL_MENU_LINE);
    fb_text(4 + (64 - 4 * 8) / 2, (int)H - 24 + 2, "Меню", COL_TEXT, -1);

    /* Кнопки открытых окон — после кнопки Меню.
     * Порядок — по времени создания (taskbar_order), НЕ по z-порядку:
     * выделение не должно уезжать (FIX [W1]). */
    int bx_start = 4 + 64 + 6;     /* = 74 */
    int bx_end   = (int)W - 8 - 8 * 8;   /* место под часы */
    int btn_max_w = 140;
    int btn_min_w = 60;
    int btn_h = 20;
    int by = (int)H - 24;

    int order[WM_MAX_WINDOWS];
    int nt = taskbar_order(order, WM_MAX_WINDOWS);

    /* Сколько кнопок помещается? */
    int avail_w = bx_end - bx_start;
    int max_btns = avail_w / btn_min_w;
    if (max_btns < 1) max_btns = 1;
    /* Если окон больше, чем помещается — показываем последние созданные */
    int first_btn = 0;
    if (nt > max_btns) first_btn = nt - max_btns;
    int btn_w = (nt > max_btns) ? (avail_w / max_btns) : btn_max_w;
    if (btn_w > btn_max_w) btn_w = btn_max_w;
    if (btn_w < btn_min_w) btn_w = btn_min_w;

    /* верхнее видимое окно — для подсветки активной кнопки */
    window_t *top_w = NULL;
    {
        int top = top_visible_window();
        if (top >= 0) top_w = wins[top];
    }

    for (int k = first_btn; k < nt; k++) {
        window_t *w = wins[order[k]];
        int bx = bx_start + (k - first_btn) * btn_w;
        int w_eff = btn_w;
        if (bx + w_eff > bx_end) w_eff = bx_end - bx;
        if (w_eff < 1) break;
        int focused = (w == top_w) && !w->minimized;
        u32 bg = focused ? COL_BTN_ACT
                : (w->minimized ? fb_rgb(0x14, 0x18, 0x1E) : COL_BTN);
        fb_fill_rect(bx, by, w_eff, btn_h, bg);
        fb_rect(bx, by, w_eff, btn_h, COL_MENU_LINE);
        /* Текст с обрезкой под ширину (UTF-8-безопасно) */
        char t[36];
        int max_chars = (w_eff - 8) / 8;
        if (max_chars < 1) max_chars = 1;
        if (max_chars > 34) max_chars = 34;
        utf8_clip(t, w->title, max_chars);
        fb_text(bx + 4, by + 2, t, focused ? COL_TEXT : COL_TEXT_DIM, -1);
    }

    /* часы */
    int h = 0, m = 0, s = 0;
    rtc_get_time(&h, &m, &s);
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", h, m, s);
    fb_text((int)W - 8 - (int)strlen(buf) * 8, (int)H - 22, buf, COL_TEXT_DIM, -1);

    /* ---------- значок сети (левее часов) ----------
     * Показываем состояние:
     *   - нет NIC:             серый значок с крестиком
     *   - есть NIC, нет IP:    жёлтый значок (предупреждение)
     *   - IP есть, нет линка: оранжевый
     *   - всё ок (link up):   зелёный с делениями сигнала
     * Рисуем 4 «полоски» разной высоты, как WiFi-значок, либо провод. */
    {
        int icon_x = (int)W - 8 - (int)strlen(buf) * 8 - 28;
        int icon_y = (int)H - 22;
        int nic_present = net_nic_present();
        u32 ip = net_get_ip();
        u32 tx = net_tx_packets();
        u32 rx = net_rx_packets();

        if (!nic_present) {
            /* серая иконка с крестиком */
            u32 col = fb_rgb(0x60, 0x68, 0x70);
            /* Рамка */
            fb_rect(icon_x, icon_y, 20, 16, col);
            /* X внутри */
            fb_hline(icon_x + 4, icon_x + 14, icon_y + 4, col);
            fb_hline(icon_x + 4, icon_x + 14, icon_y + 11, col);
            /* диагонали */
            for (int i = 0; i < 8; i++) {
                fb_hline(icon_x + 4 + i, icon_x + 4 + i, icon_y + 4 + i, col);
            }
        } else if (ip == 0) {
            /* жёлтый треугольник-предупреждение */
            u32 col = fb_rgb(0xFF, 0xC0, 0x40);
            fb_fill_rect(icon_x, icon_y + 12, 20, 4, col);   /* подставка */
            for (int i = 0; i < 12; i++) {
                fb_hline(icon_x + 4 + i, icon_x + 4 + i*2, icon_y + 11 - i, col);
            }
            /* восклицательный знак */
            fb_fill_rect(icon_x + 9, icon_y + 3, 2, 7, fb_rgb(0x12, 0x16, 0x1B));
            fb_fill_rect(icon_x + 9, icon_y + 11, 2, 2, fb_rgb(0x12, 0x16, 0x1B));
        } else {
            /* Зелёный значок: 4 столбика разной высоты = eth-метр активности
             * Высоты: 4, 8, 12, 16 (как столбики сигнала) */
            u32 col = fb_rgb(0x60, 0xE0, 0x60);
            int heights[4] = { 4, 8, 12, 16 };
            int activity = (int)((tx + rx) & 0x3);   /* индикатор активности: 0..3 */
            for (int i = 0; i < 4; i++) {
                int h_b = heights[i];
                u32 c = (i <= activity) ? col : fb_rgb(0x30, 0x40, 0x30);
                fb_fill_rect(icon_x + i * 4, icon_y + 16 - h_b, 3, h_b, c);
            }
            /* Подпись IP (мини): два октета */
            char mini[12];
            snprintf(mini, sizeof(mini), "%d.%d",
                     (int)((ip >> 24) & 0xFF), (int)((ip >> 16) & 0xFF));
            fb_text(icon_x - 4 - (int)strlen(mini) * 8,
                    icon_y + 3, mini, fb_rgb(0x9A, 0xA3, 0xAC), -1);
        }
    }

    /* Подпись "N2600-OS" убрана — кнопки задач используют всю ширину */
}

/* Проверить попадание клика в кнопку окна на таскбаре.
 * Возвращает индекс окна в wins[] или -1. Использует ТОТ ЖЕ стабильный
 * порядок (taskbar_order), что и отрисовка — FIX [W1]. */
static int taskbar_hit(int x, int y)
{
    u32 H = fb_height(), W = fb_width();
    if (y < (int)H - 24 || y >= (int)H - 4) return -1;

    int bx_start = 4 + 64 + 6;
    int bx_end   = (int)W - 8 - 8 * 8;
    int btn_min_w = 60;
    int btn_max_w = 140;
    int avail_w = bx_end - bx_start;
    int max_btns = avail_w / btn_min_w;
    if (max_btns < 1) max_btns = 1;

    int order[WM_MAX_WINDOWS];
    int nt = taskbar_order(order, WM_MAX_WINDOWS);

    int first_btn = 0;
    if (nt > max_btns) first_btn = nt - max_btns;
    int btn_w = (nt > max_btns) ? (avail_w / max_btns) : btn_max_w;
    if (btn_w > btn_max_w) btn_w = btn_max_w;
    if (btn_w < btn_min_w) btn_w = btn_min_w;

    for (int k = first_btn; k < nt; k++) {
        int bx = bx_start + (k - first_btn) * btn_w;
        int w_eff = btn_w;
        if (bx + w_eff > bx_end) w_eff = bx_end - bx;
        if (w_eff < 1) break;
        if (x >= bx && x < bx + w_eff) return order[k];
    }
    return -1;
}

static void draw_menu(void)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    fb_fill_rect(mx, my, mw, mh, COL_MENU);
    fb_rect(mx, my, mw, mh, COL_MENU_LINE);

    int y = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == app_table_count) {           /* разделитель */
            fb_hline(mx + 1, mx + mw - 2, y + 4, COL_MENU_LINE);
            y += 9;
            continue;
        }
        int hot = (menu_open && menu_hover == i);
        if (hot) fb_fill_rect(mx + 2, y, mw - 4, MENU_ITEM_H, COL_MENU_HOT);
        const char *name = (i < app_table_count)
            ? app_table[i].name
            : (i == app_table_count ? "Перезагрузка" : "Выключение");
        fb_text(mx + 12, y + (MENU_ITEM_H - 16) / 2, name,
                hot ? COL_TEXT : COL_TEXT_DIM, -1);
        y += MENU_ITEM_H;
    }
}

/* ===================== контекстное меню (сессия 13) =====================
 * ПЕРЕИСПОЛЬЗУЕМЫЙ компонент для приложений (запрос пользователя).
 * Открытие — из on_mouse потока окна (обычно по правой кнопке):
 *     wm_menu_open(w, mx, my, items, n, cb, uctx)
 * координаты mx,my — ОТНОСИТЕЛЬНО содержимого окна w (WM сам переводит
 * в экранные). Выбор пункта доставляется потоку владельца как WEV_MENU:
 * колбэк cb(id, uctx) исполняется в ЕГО потоке — данные приложения
 * не требуют блокировок. Закрытие: клик по пункту, Esc, клик мимо.
 * Другие приложения могут строить свои меню на этом же API. */
#define CMENU_ITEM_H 20

typedef struct {
    int  open;
    int  x, y, w, h;          /* экранные координаты бокса */
    int  hover;               /* индекс пункта под курсором или -1 */
    window_t *owner;          /* окно-владелец (для доставки WEV_MENU) */
    const wm_menu_item_t *items;
    int  n;
    wm_menu_fn cb;            /* колбэк приложения (исполнить в его потоке) */
    void *uctx;               /* контекст колбэка */
} cmenu_t;
static cmenu_t g_cmenu;

static void cmenu_geom(void)
{
    int maxw = 120;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (g_cmenu.items[i].label)
            maxw = (maxw > (int)strlen(g_cmenu.items[i].label) * 8 + 34)
                   ? maxw : (int)strlen(g_cmenu.items[i].label) * 8 + 34;
    }
    int hh = 6;
    for (int i = 0; i < g_cmenu.n; i++)
        hh += g_cmenu.items[i].label ? CMENU_ITEM_H : 9;
    g_cmenu.w = maxw;
    g_cmenu.h = hh + 2;
}

static void draw_cmenu(void)
{
    fb_fill_rect(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h, COL_MENU);
    fb_rect(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h, COL_MENU_LINE);
    int y = g_cmenu.y + 3;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (!g_cmenu.items[i].label) {          /* разделитель */
            fb_hline(g_cmenu.x + 1, g_cmenu.x + g_cmenu.w - 2, y + 4, COL_MENU_LINE);
            y += 9;
            continue;
        }
        int hot = (g_cmenu.hover == i) && !g_cmenu.items[i].disabled;
        if (hot) fb_fill_rect(g_cmenu.x + 2, y, g_cmenu.w - 4, CMENU_ITEM_H, COL_MENU_HOT);
        fb_text(g_cmenu.x + 12, y + (CMENU_ITEM_H - 16) / 2, g_cmenu.items[i].label,
                g_cmenu.items[i].disabled ? COL_TEXT_DIM : (hot ? COL_TEXT : COL_TEXT_DIM),
                -1);
        y += CMENU_ITEM_H;
    }
}

/* Индекс пункта по экранной точке (разделители пропускаются) */
static int cmenu_hit(int x, int y)
{
    if (x < g_cmenu.x || x >= g_cmenu.x + g_cmenu.w ||
        y < g_cmenu.y || y >= g_cmenu.y + g_cmenu.h)
        return -1;
    int yy = g_cmenu.y + 3;
    for (int i = 0; i < g_cmenu.n; i++) {
        if (!g_cmenu.items[i].label) { yy += 9; continue; }
        if (y >= yy && y < yy + CMENU_ITEM_H) return i;
        yy += CMENU_ITEM_H;
    }
    return -1;
}

void wm_menu_open(window_t *owner, int content_x, int content_y,
                  const wm_menu_item_t *items, int n, wm_menu_fn cb, void *uctx)
{
    if (!items || n <= 0 || !owner) return;
    /* контентные координаты -> экранные */
    int cx = 0, cy = 0, cw = 0, ch = 0;
    win_content_rect(owner, &cx, &cy, &cw, &ch);
    int sx = cx + content_x, sy = cy + content_y;

    memset(&g_cmenu, 0, sizeof(g_cmenu));
    g_cmenu.open = 1;
    g_cmenu.items = items;
    g_cmenu.n = n;
    g_cmenu.owner = owner;
    g_cmenu.cb = cb;
    g_cmenu.uctx = uctx;
    g_cmenu.hover = -1;
    cmenu_geom();
    g_cmenu.x = sx;
    g_cmenu.y = sy;
    if (g_cmenu.x + g_cmenu.w > (int)fb_width())
        g_cmenu.x = (int)fb_width() - g_cmenu.w - 2;
    if (g_cmenu.y + g_cmenu.h > (int)fb_height() - TBAR_H)
        g_cmenu.y = (int)fb_height() - TBAR_H - g_cmenu.h - 2;
    if (g_cmenu.x < 0) g_cmenu.x = 0;
    if (g_cmenu.y < 0) g_cmenu.y = 0;
    fb_touch(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h);
}

void wm_menu_close(void)
{
    if (!g_cmenu.open) return;
    int x = g_cmenu.x, y = g_cmenu.y, w_ = g_cmenu.w, h_ = g_cmenu.h;
    memset(&g_cmenu, 0, sizeof(g_cmenu));
    fb_touch(x, y, w_, h_);
}

int wm_menu_active(void) { return g_cmenu.open; }

/* Прямоугольник tooltip при текущем положении курсора (сессия 12):
 * та же арифметика, что в composite — чтобы помечать на перерисовку
 * ровно то место, где tooltip рисуется. */
static void tooltip_rect(int *tx, int *ty, int *tw, int *th)
{
    const char *title = (tooltip_win_idx >= 0 && tooltip_win_idx < nwin)
                        ? wins[tooltip_win_idx]->title : "";
    *tw = (int)strlen(title) * 8 + 12;
    *tx = cur_x + 14;
    *ty = cur_y - 20;
    if (*tx + *tw > (int)fb_width()) *tx = (int)fb_width() - *tw - 2;
    if (*ty < 0) *ty = cur_y + 20;
    *th = 18;
}

/* ----------------------------- композитинг ----------------------------- */

static void composite(int rx0, int ry0, int rx1, int ry1)
{
    u32 W = fb_width(), H = fb_height();

    fb_blit_bg(rx0, ry0, rx1, ry1);

    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (w->minimized) continue;     /* свёрнутые окна не отрисовываются */
        if (!rect_intersect(w->x, w->y, w->w, w->h, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1))
            continue;
        int cx0 = (w->x < rx0) ? rx0 : w->x;
        int cy0 = (w->y < ry0) ? ry0 : w->y;
        int cx1 = (w->x + w->w - 1 > rx1) ? rx1 : w->x + w->w - 1;
        int cy1 = (w->y + w->h - 1 > ry1) ? ry1 : w->y + w->h - 1;
        fb_set_clip(cx0, cy0, cx1, cy1);
        draw_window(w);
        fb_set_clip(rx0, ry0, rx1, ry1);
    }

    if (ry1 >= (int)H - TBAR_H) {
        fb_set_clip(rx0, (int)H - TBAR_H, rx1, (int)H - 1);
        draw_taskbar();
    }

    if (menu_open) {
        int mx, my, mw, mh;
        menu_rect(&mx, &my, &mw, &mh);
        if (rect_intersect(mx, my, mw, mh, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_menu();
        }
    }

    if (g_cmenu.open) {                       /* сессия 13: контекстное меню */
        if (rect_intersect(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h,
                           rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_cmenu();
        }
    }

    if (cursor_visible) {
        if (rect_intersect(cur_x, cur_y, 12, 19, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_cursor();
        }
    }

    /* Tooltip: показываем полный заголовок окна при наведении на таскбар */
    if (tooltip_win_idx >= 0 && tooltip_win_idx < nwin && tooltip_timer > 3) {
        int tx, ty, tw, th;
        tooltip_rect(&tx, &ty, &tw, &th);
        fb_set_clip(0, 0, (int)fb_width() - 1, (int)fb_height() - 1);
        fb_fill_rect(tx, ty, tw, th, fb_rgb(0x33, 0x33, 0x33));
        fb_rect(tx, ty, tw, th, fb_rgb(0x6F, 0xB3, 0xF2));
        fb_text(tx + 6, ty + 1, wins[tooltip_win_idx]->title,
                fb_rgb(0xFF, 0xFF, 0xFF), -1);
    }

    fb_set_clip(0, 0, (int)W - 1, (int)H - 1);
}

void wm_frame(void)
{
    /* 0) kill-запросы (диспетчер задач/ватчдог) + вычистка мёртвых окон
     *    + старение trash-списка canvas'ов (сессия 12) */
    wm_pump_kills();
    wm_canvas_trash_tick();

    /* 1) отложенные закрытия — до отрисовки */
    if (pending_close) {
        window_t *w = pending_close;
        pending_close = NULL;

        wl_lock(&wm_glock);
        for (int i = 0; i < nwin; i++) {
            if (wins[i] == w) {
                for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
                nwin--;
                break;
            }
        }
        wl_unlock(&wm_glock);

        if (w->task > 0) {
            /* ПОТОК окна сам вызовет on_close (в своём контексте),
             * отсоединит canvas, освободит их и умрёт (dead=1).
             * Здесь лишь отправляем CLOSE и ждём смерти в zombies. */
            win_post_close(w);
            if (nzombie < WM_ZOMBIE_MAX) {
                zombies[nzombie++] = w;
            } else {
                serial_puts("[wm] zombie list overflow, leaking window\n");
            }
        } else {
            /* окно без потока (страховка) — старый путь */
            if (w->on_close) w->on_close(w);
            if (w->thr) free(w->thr);
            if (w->canvas) free(w->canvas);
            free(w);
        }
        fb_touch_all();
    }

    /* 2) resize: пересоздать canvas окон с изменившейся геометрией.
     * rlock-try: если поток сейчас рисует — отложим до следующего кадра. */
    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (!w) continue;
        int ncw = w->w - 2;
        int nch = w->h - TITLE_H - 2;
        if (ncw < 1) ncw = 1;
        if (nch < 1) nch = 1;
        if (w->canvas && w->task > 0 && !w->fixed_size &&
            (w->cvs_w != ncw || w->cvs_h != nch)) {
            win_thr_t *t = (win_thr_t *)w->thr;
            if (t && wl_trylock(&t->rlock, 200)) {
                u32 *nc = (u32 *)malloc((u32)ncw * (u32)nch * 4);
                if (nc) {
                    u32 dark = fb_rgb(0x0B, 0x0E, 0x11);
                    u32 words = (u32)ncw * (u32)nch;
                    for (u32 k = 0; k < words; k++) nc[k] = dark;
                    wm_canvas_trash_add(w->canvas);   /* старый — через trash (сессия 12) */
                    w->canvas = nc;
                    w->cvs_w = ncw;
                    w->cvs_h = nch;
                    fb_task_canvas_attach(w->task, nc, ncw, nch);
                    t->need_draw = 1;
                    task_wake(w->task);
                    fb_touch(w->x, w->y, w->w, w->h);
                }
                wl_unlock(&t->rlock);
            }
        }
    }

    if (!fb_ready()) return;

    int rx0, ry0, rx1, ry1;
    if (!fb_dirty(&rx0, &ry0, &rx1, &ry1)) return;

    fb_mark_disable();
    wl_lock(&wm_glock);          /* стабильный список окон на время кадра */
    composite(rx0, ry0, rx1, ry1);
    wl_unlock(&wm_glock);
    fb_mark_enable();
    fb_flush();
}

/* ------------------------------- события ------------------------------- */

void wm_key(const key_event_t *ev)
{
    /* Находим верхнее не свёрнутое окно для фокуса */
    int top = top_visible_window();
    if (top < 0) return;
    window_t *w = wins[top];
    if (!w) return;

    /* Событие — в очередь ПОТОКА окна (колбэк выполнится в нём).
     * kmain больше не выполняет код приложений. */
    if (w->task > 0) {
        wev_t e;
        memset(&e, 0, sizeof(e));
        e.kind = WEV_KEY;
        e.key = *ev;
        win_post(w, &e);
    } else if (w->on_key) {
        w->on_key(w, ev);   /* страховка (окна без потока не бывает) */
    }
}

static void start_button_rect(int *bx, int *by, int *bw, int *bh)
{
    *bx = 4; *by = (int)fb_height() - 24; *bw = 64; *bh = 20;
}

/* Экранные координаты -> событие MOUSE в очередь потока окна
 * (координаты относительно содержимого). */
static void post_mouse(window_t *w, int x, int y, u8 btn, u8 changed)
{
    if (!w) return;
    int cx, cy, cw, ch;
    win_content_rect(w, &cx, &cy, &cw, &ch);
    if (x < cx || x >= cx + cw || y < cy || y >= cy + ch) return;
    if (w->task > 0) {
        wev_t e;
        memset(&e, 0, sizeof(e));
        e.kind = WEV_MOUSE;
        e.mx = x - cx;
        e.my = y - cy;
        e.btn = btn;
        e.changed = changed;
        win_post(w, &e);
    } else if (w->on_mouse) {
        w->on_mouse(w, x - cx, y - cy, btn, changed);
    }
}

void wm_mouse_poll(void)
{
    /* Обработка колёсика мыши: прокрутка фокусного окна */
    if (ms_wheel_event) {
        ms_wheel_event = 0;
        int wheel = ms_wheel;
        ms_wheel = 0;
        /* Находим фокусное окно и эмулируем PgUp/PgDn */
        int top = top_visible_window();
        if (top >= 0 && wins[top]) {
            window_t *w = wins[top];
            if (w->task > 0) {
                wev_t e;
                memset(&e, 0, sizeof(e));
                e.kind = WEV_KEY;
                e.key.code = (wheel > 0) ? 0x49 : 0x51;  /* PgUp / PgDn */
                e.key.flags = 0;
                e.key.ch = 0;
                win_post(w, &e);
            } else if (w->on_key) {
                key_event_t ev;
                memset(&ev, 0, sizeof(ev));
                ev.code = (wheel > 0) ? 0x49 : 0x51;
                w->on_key(w, &ev);
            }
        }
    }

    if (!ms_event) return;
    ms_event = 0;

    int x = ms_x, y = ms_y;
    static u8 prev_btn = 0;
    u8 btn = ms_buttons;
    u8 changed = (u8)(btn ^ prev_btn);
    prev_btn = btn;

    /* области курсора: старая и новая */
    if (cursor_visible) fb_touch(cur_x, cur_y, 12, 19);
    cur_x = x; cur_y = y;
    if (cursor_visible) fb_touch(x, y, 12, 19);

    /* Сессия 12 (FIX tooltip): состояние tooltip обновляется ЗДЕСЬ, до
     * всех ранних return (перетаскивание/resize/меню/клики). Раньше
     * открытие меню «замораживало» активный tooltip — он продолжал
     * рисоваться ПОВЕРХ окон и меню, следуя за курсором, пока тот не
     * возвращался на таскбар. Плюс: вместо fb_touch_all() на каждое
     * движение (тяжёлый полный кадр при множестве окон) помечаем только
     * сам прямоугольник tooltip — старый и новый. */
    {
        static int tt_x = -1, tt_y = -1, tt_w = 0;   /* прошлый rect */
        int ti = (btn == 0 && !menu_open && !drag_win && !resize_win)
                 ? taskbar_hit(x, y) : -1;
        if (ti >= 0) {
            if (ti != tooltip_win_idx) {
                tooltip_win_idx = ti;
                tooltip_timer = 0;
            }
            if (tooltip_timer < 1000) tooltip_timer++;
        } else if (tooltip_win_idx >= 0) {
            tooltip_win_idx = -1;
            tooltip_timer = 0;
        }
        int show = (tooltip_win_idx >= 0 && tooltip_win_idx < nwin &&
                    tooltip_timer > 3);
        if (show) {
            int nx, ny, nw, nh;
            tooltip_rect(&nx, &ny, &nw, &nh);
            if (nx != tt_x || ny != tt_y) {
                if (tt_w > 0) fb_touch(tt_x, tt_y, tt_w, 18);   /* стереть старый */
                fb_touch(nx, ny, nw, nh);                       /* новый */
            }
            tt_x = nx; tt_y = ny; tt_w = nw;
        } else if (tt_w > 0) {
            fb_touch(tt_x, tt_y, tt_w, 18);   /* tooltip исчез — перерисовать */
            tt_x = -1; tt_y = -1; tt_w = 0;
        }
    }

    /* --- контекстное меню (сессия 13): меню забирает весь ввод --- */
    if (g_cmenu.open) {
        int hov = cmenu_hit(x, y);
        if (hov != g_cmenu.hover) {
            g_cmenu.hover = hov;
            fb_touch(g_cmenu.x, g_cmenu.y, g_cmenu.w, g_cmenu.h);
        }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            /* активация пункта — доставка в поток владельца */
            if (hov >= 0 && !g_cmenu.items[hov].disabled &&
                g_cmenu.owner && g_cmenu.owner->task > 0) {
                wev_t e;
                memset(&e, 0, sizeof(e));
                e.kind = WEV_MENU;
                e.menu_id = g_cmenu.items[hov].id;
                e.menu_cb = (void *)g_cmenu.cb;    /* снять ДО close */
                e.menu_ctx = g_cmenu.uctx;
                win_post(g_cmenu.owner, &e);
            }
            wm_menu_close();
            return;                       /* клик проглатывается */
        }
        return;                            /* движение/прочее — меню живёт */
    }

    /* --- нажатие ПКМ: доставить окну (приложения открывают меню) --- */
    if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
        int wi = window_at(x, y);
        if (wi >= 0) {
            window_t *w = wins[wi];
            int cx, cy, cw, ch;
            win_content_rect(w, &cx, &cy, &cw, &ch);
            if (x >= cx && x < cx + cw && y >= cy && y < cy + ch)
                post_mouse(w, x, y, btn, changed);
        }
        return;
    }

    /* --- перетаскивание окна --- */
    if (drag_win && (btn & MSB_LEFT)) {
        int nx = x - drag_dx;
        int ny = y - drag_dy;
        int maxx = (int)fb_width() - 60;
        int maxy = (int)fb_height() - TBAR_H - TITLE_H;
        if (nx > maxx) nx = maxx;
        if (ny > maxy) ny = maxy;
        if (nx < -(drag_win->w - 60)) nx = -(drag_win->w - 60);
        if (ny < 0) ny = 0;
        if (nx != drag_win->x || ny != drag_win->y) {
            fb_touch(drag_win->x, drag_win->y, drag_win->w, drag_win->h);
            fb_touch(nx, ny, drag_win->w, drag_win->h);
            drag_win->x = nx;
            drag_win->y = ny;
        }
        if (changed & MSB_LEFT) { /* отпущено и нажато одновременно — не бывает */ }
        return;
    }
    if (drag_win && !(btn & MSB_LEFT)) {
        drag_win = NULL;
    }

    /* --- изменение размера окна (перетаскивание правого нижнего угла) --- */
    if (resize_win && (btn & MSB_LEFT)) {
        int nw = resize_start_w + (x - resize_start_x);
        int nh = resize_start_h + (y - resize_start_y);
        if (nw < 80) nw = 80;
        if (nh < 60) nh = 60;
        if (nw > (int)fb_width()) nw = (int)fb_width();
        if (nh > (int)fb_height() - TBAR_H) nh = (int)fb_height() - TBAR_H;
        if (nw != resize_win->w || nh != resize_win->h) {
            fb_touch(resize_win->x, resize_win->y, resize_win->w, resize_win->h);
            resize_win->w = nw;
            resize_win->h = nh;
            fb_touch(resize_win->x, resize_win->y, nw, nh);
            /* обновим prev геометрию (для сворачивания/восстановления) */
            resize_win->prev_w = nw;
            resize_win->prev_h = nh;
        }
        return;
    }
    if (resize_win && !(btn & MSB_LEFT)) {
        resize_win = NULL;
    }

    /* --- нажатие ЛКМ --- */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        /* Двойной клик по заголовку — развернуть/восстановить окно.
         * Отслеживаем время и позицию предыдущего клика. */
        {
            static int last_click_x = -1000, last_click_y = -1000;
            static u32 last_click_tick = 0;
            u32 now = timer_ticks();
            if (now - last_click_tick < 30 &&          /* < 300 мс */
                x > last_click_x - 5 && x < last_click_x + 5 &&
                y > last_click_y - 5 && y < last_click_y + 5) {
                /* возможен double-click: проверим ниже, что это заголовок */
                int wi2 = window_at(x, y);
                if (wi2 >= 0 && y >= wins[wi2]->y &&
                    y < wins[wi2]->y + TITLE_H) {
                    int bx_c, bx_m, bx_n;
                    title_btn_rects(wins[wi2], &bx_c, &bx_m, &bx_n);
                    /* но не по кнопкам */
                    if (x < bx_n) {
                        win_toggle_maximize(wins[wi2]);
                        last_click_tick = 0;
                        return;
                    }
                }
            }
            last_click_x = x; last_click_y = y;
            last_click_tick = now;
        }

        /* меню открыто? */
        if (menu_open) {
            int mx, my, mw, mh;
            menu_rect(&mx, &my, &mw, &mh);
            int idx = menu_hit(x, y);
            menu_open = 0;
            menu_hover = -1;
            fb_touch(mx, my, mw, mh);
            if (idx >= 0) {
                menu_action(idx);
                return;
            }
            /* клик вне меню — обрабатывается дальше */
        }

        int bx, by, bw, bh;
        start_button_rect(&bx, &by, &bw, &bh);
        if (x >= bx && x < bx + bw && y >= by && y < by + bh) {
            menu_open = !menu_open;
            menu_hover = -1;
            if (menu_open) {
                int mx, my, mw, mh;
                menu_rect(&mx, &my, &mw, &mh);
                fb_touch(mx, my, mw, mh);
            }
            fb_touch(bx, by, bw, bh);
            return;
        }

        /* Клик по кнопке окна на таскбаре — переключение свернуть/развернуть */
        {
            int ti = taskbar_hit(x, y);
            if (ti >= 0) {
                window_t *w = wins[ti];
                int top = top_visible_window();
                if (w->minimized) {
                    /* Восстанавливаем и поднимаем наверх */
                    win_restore(w);
                    raise_window(ti);
                } else if (ti == top) {
                    /* Уже активное окно — сворачиваем */
                    win_minimize(w);
                } else {
                    /* Не в фокусе — поднимаем */
                    raise_window(ti);
                }
                fb_touch_all();
                return;
            }
        }

        int wi = window_at(x, y);
        if (wi >= 0) {
            window_t *w = wins[wi];
            raise_window(wi);
            /* Проверка: клик в правом нижнем углу (resize handle, 10x10)?
             * Развёрнутое окно ресайзить нельзя. */
            if (!w->maximized && !w->fixed_size &&
                x >= w->x + w->w - 10 && x < w->x + w->w &&
                y >= w->y + w->h - 10 && y < w->y + w->h) {
                resize_win = w;
                resize_start_x = x;
                resize_start_y = y;
                resize_start_w = w->w;
                resize_start_h = w->h;
                return;
            }
            if (y < w->y + TITLE_H) {
                /* три кнопки заголовка: [—] [□] [×] */
                int bx_close, bx_max, bx_min;
                title_btn_rects(w, &bx_close, &bx_max, &bx_min);
                int cby = w->y + 4;
                if (x >= bx_close && x < bx_close + TB_BTN_W &&
                    y >= cby && y < cby + TB_BTN_H) {
                    pending_close = w;
                    fb_touch(bx_close, cby, TB_BTN_W, TB_BTN_H);
                } else if (x >= bx_max && x < bx_max + TB_BTN_W &&
                           y >= cby && y < cby + TB_BTN_H) {
                    /* развернуть/восстановить */
                    win_toggle_maximize(w);
                } else if (x >= bx_min && x < bx_min + TB_BTN_W &&
                           y >= cby && y < cby + TB_BTN_H) {
                    /* свернуть */
                    win_minimize(w);
                } else if (!w->maximized) {
                    /* перетаскивание за заголовок (кроме развёрнутого) */
                    drag_win = w;
                    drag_dx = x - w->x;
                    drag_dy = y - w->y;
                }
                return;
            }
            int cx, cy, cw, ch;
            win_content_rect(w, &cx, &cy, &cw, &ch);
            if (x >= cx && x < cx + cw && y >= cy && y < cy + ch)
                post_mouse(w, x, y, btn, changed);
            return;
        }
        return;
    }

    /* --- отпускание ЛКМ --- */
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
        if (pending_close) {
            window_t *w = pending_close;
            int bx_close, bx_max, bx_min;
            title_btn_rects(w, &bx_close, &bx_max, &bx_min);
            int cby = w->y + 4;
            if (x >= bx_close && x < bx_close + TB_BTN_W &&
                y >= cby && y < cby + TB_BTN_H &&
                window_at(x, y) >= 0) {
                win_close(w);
            } else {
                pending_close = NULL;
                fb_touch(bx_close, cby, TB_BTN_W, TB_BTN_H);
            }
        }
        /* отдаём отпускание приложению */
        int wi = window_at(x, y);
        if (wi >= 0) {
            post_mouse(wins[wi], x, y, btn, changed);
        }
        return;
    }

    /* --- просто движение / hover меню --- */
    if (menu_open) {
        int mx, my, mw, mh;
        menu_rect(&mx, &my, &mw, &mh);
        int hov = menu_hit(x, y);
        if (hov != menu_hover) {
            menu_hover = hov;
            fb_touch(mx, my, mw, mh);
        }
        return;
    }

    /* движение над окном — отдаём приложению (для рисования мышью) */
    int wi = window_at(x, y);
    if (wi >= 0) {
        post_mouse(wins[wi], x, y, btn, changed);
    }
}

void wm_halfsec(void)
{
    blink_state ^= 1;

    /* on_tick — в очередь каждого окна (колбэк вызовет поток окна) */
    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (!w || !w->on_tick) continue;
        if (w->task > 0) {
            wev_t e;
            memset(&e, 0, sizeof(e));
            e.kind = WEV_TICK;
            win_post(w, &e);
        } else {
            w->on_tick(w);
        }
    }

    /* часы в таскбаре */
    static int last_sec = -1;
    int h, m, s;
    rtc_get_time(&h, &m, &s);
    if (s != last_sec) {
        last_sec = s;
        fb_touch(0, (int)fb_height() - TBAR_H, (int)fb_width(), TBAR_H);
    }
}

/* -------------------------------- API -------------------------------- */

window_t *win_create(const char *title, int x, int y, int ww, int wh,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data)
{
    /* Всё создание окна — под wm_glock: атомарная проверка свободного слота
     * wins[] и вставка (без TOCTOU между потоками, открывающими окна).
     * Время удержания ~1-2 мс (malloc canvas + memset) — приемлемо. */
    window_t *w = NULL;
    u32 *canvas = NULL;
    win_thr_t *thr = NULL;

    wl_lock(&wm_glock);
    if (nwin >= WM_MAX_WINDOWS) { wl_unlock(&wm_glock); return NULL; }

    w = (window_t *)malloc(sizeof(window_t));
    if (w) memset(w, 0, sizeof(window_t));
    if (w) {
        strncpy(w->title, title, sizeof(w->title) - 1);
        w->draw = draw;
        w->on_key = on_key;
        w->on_mouse = on_mouse;
        w->on_tick = on_tick;
        w->on_close = on_close;
        w->data = data;
        w->task = -1;
        w->serial = win_serial_next++;   /* FIX [W1]: стабильный таскбар */
    }

    /* геометрия: не даём окну выйти за экран */
    if (w) {
        u32 W = fb_width(), H = fb_height();
        if (ww > (int)W) ww = (int)W;
        if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x + ww > (int)W) x = (int)W - ww;
        if (y + wh > (int)H - TBAR_H) y = (int)H - TBAR_H - wh;
        w->x = x; w->y = y;
        w->w = ww; w->h = wh;
        w->minimized = 0;
        w->prev_x = x; w->prev_y = y; w->prev_w = ww; w->prev_h = wh;
    }

    /* ---- canvas + поток ---- */
    if (w) {
        int ncw = ww - 2;
        int nch = wh - TITLE_H - 2;
        if (ncw < 1) ncw = 1;
        if (nch < 1) nch = 1;
        canvas = (u32 *)malloc((u32)ncw * (u32)nch * 4);
        thr = (win_thr_t *)malloc(sizeof(win_thr_t));
        if (canvas && thr) {
            memset(thr, 0, sizeof(*thr));
            u32 dark = fb_rgb(0x0B, 0x0E, 0x11);
            u32 words = (u32)ncw * (u32)nch;
            for (u32 k = 0; k < words; k++) canvas[k] = dark;
            w->canvas = canvas;
            w->cvs_w = ncw;
            w->cvs_h = nch;
            w->thr = thr;
            thr->need_draw = 1;    /* первичная отрисовка */
        }
    }

    if (w && w->thr) {
        /* Имя задачи — заголовок окна, обрезанный по ГРАНИЦЕ UTF-8
         * символа (кириллица = 2 байта: обрезать посередине нельзя —
         * в диспетчере задач появится битый символ). */
        char tname[16];
        {
            const char *s = title;
            int o = 0;
            while (*s && o < 15) {
                int adv = 1;
                if ((*s & 0xE0) == 0xC0 && s[1]) adv = 2;
                else if ((*s & 0xF0) == 0xE0 && s[1] && s[2]) adv = 3;
                if (o + adv > 15) break;
                for (int k = 0; k < adv; k++) tname[o++] = s[k];
                s += adv;
            }
            tname[o] = 0;
        }
        int tid = task_spawn(tname, win_thread_fn, w);
        if (tid > 0) {
            w->task = tid;
            if (!fb_task_canvas_attach(tid, w->canvas, w->cvs_w, w->cvs_h)) {
                /* слоты кончились (64): окно без canvas — поток не ждёт */
                win_set_no_canvas(w);
            }
            wins[nwin++] = w;          /* наверх стека */
            wl_unlock(&wm_glock);
            fb_touch_all();           /* изменился список окон — полный кадр */
            return w;
        }
        /* spawn не удался — вернуть всё */
        free(w->thr);
        free(w->canvas);
    }
    if (thr) free(thr);
    if (canvas) free(canvas);
    if (w) free(w);
    wl_unlock(&wm_glock);
    return NULL;
}

void win_close(window_t *w)
{
    if (w) pending_close = w;
}

/* Сессия 12: пометить окно как «без canvas у потока» — вызывается
 * c4gfx ПОСЛЕ win_create и ДО fb_task_canvas_detach(w->task):
 * поток окна не должен ждать attach, который сознательно отменён. */
void win_set_no_canvas(window_t *w)
{
    if (w && w->thr)
        ((win_thr_t *)w->thr)->no_canvas = 1;
}

void win_draw_now(window_t *w)
{
    if (!w || !w->thr) return;
    if (w->task <= 0 || w->task != task_current()) return;  /* только свой поток */
    if (w->minimized || !w->draw || !w->canvas) return;
    win_thr_t *t = (win_thr_t *)w->thr;
    t->need_draw = 0;
    wl_lock(&t->rlock);            /* vs realloc при resize (kmain) */
    fb_set_clip(0, 0, w->cvs_w - 1, w->cvs_h - 1);
    fb_set_origin(0, 0);
    w->draw(w);
    wl_unlock(&t->rlock);
    fb_touch(w->x, w->y, w->w, w->h);
}

void win_invalidate(window_t *w)
{
    if (!w) return;
    /* Новая семантика (многопоточный WM): помечаем canvas к перерисовке
     * и будим ПОТОК окна — он отрисует и сам пометит экранную область
     * (fb_touch) по завершении. Прямой fb_touch здесь убран: иначе экран
     * обновился бы со СТАРЫМ canvas. */
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
        return;
    }
    if (!w->minimized)
        fb_touch(w->x, w->y, w->w, w->h);   /* окно без потока (страховка) */
}

/* Свернуть окно: запоминаем геометрию, помечаем minimized=1.
 * Окно больше не отрисовывается, не ловит клики, не получает фокуса. */
void win_minimize(window_t *w)
{
    if (!w || w->minimized) return;
    w->prev_x = w->x; w->prev_y = w->y;
    w->prev_w = w->w; w->prev_h = w->h;
    w->minimized = 1;
    fb_touch_all();    /* таскбар изменился, экран перерисовать */
}

/* Восстановить окно: вернули прежнюю геометрию, поднять наверх. */
void win_restore(window_t *w)
{
    if (!w || !w->minimized) return;
    w->x = w->prev_x; w->y = w->prev_y;
    w->w = w->prev_w; w->h = w->prev_h;
    w->minimized = 0;
    /* пока окно было свёрнуто, canvas не обновлялся — перерисуем */
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
    }
    fb_touch_all();
}

/* Развернуть окно на весь экран: заголовок и таскбар СОХРАНЯЮТСЯ,
 * содержимое занимает всю область над таскбаром. Прежняя геометрия
 * запоминается в prev_*. Canvas пересоздаётся в wm_frame (контроль
 * размера), окно получает need_draw. */
void win_maximize(window_t *w)
{
    if (!w || w->maximized || w->fixed_size) return;
    w->prev_x = w->x; w->prev_y = w->y;
    w->prev_w = w->w; w->prev_h = w->h;
    w->x = 0;
    w->y = 0;
    w->w = (int)fb_width();
    w->h = (int)fb_height() - TBAR_H;
    w->maximized = 1;
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
    }
    fb_touch_all();
}

/* Вернуть окну прежний размер/позицию. */
void win_unmaximize(window_t *w)
{
    if (!w || !w->maximized) return;
    w->x = w->prev_x; w->y = w->prev_y;
    w->w = w->prev_w; w->h = w->prev_h;
    w->maximized = 0;
    if (w->thr) {
        ((win_thr_t *)w->thr)->need_draw = 1;
        if (w->task > 0) task_wake(w->task);
    }
    fb_touch_all();
}

void win_toggle_maximize(window_t *w)
{
    if (!w) return;
    if (w->maximized) win_unmaximize(w);
    else win_maximize(w);
}

int win_is_maximized(window_t *w)
{
    return w ? w->maximized : 0;
}

int win_is_minimized(window_t *w)
{
    return w ? w->minimized : 0;
}

void wm_init(void)
{
    nwin = 0;
    nzombie = 0;
    kill_mail_n = 0;
    drag_win = NULL;
    resize_win = NULL;
    pending_close = NULL;
    menu_open = 0;
    menu_hover = -1;
    cursor_visible = mouse_present();
    cur_x = (int)fb_width() / 2;
    cur_y = (int)fb_height() / 2;
    ms_x = cur_x;
    ms_y = cur_y;
}

int wm_blink(void) { return blink_state; }

int wm_window_count(void) { return nwin; }

int wm_window_visible_count(void)
{
    int n = 0;
    for (int i = 0; i < nwin; i++)
        if (!wins[i]->minimized) n++;
    return n;
}

const char *wm_window_title(int i)
{
    return (i >= 0 && i < nwin) ? wins[i]->title : "";
}

int wm_window_minimized(int i)
{
    return (i >= 0 && i < nwin) ? wins[i]->minimized : 0;
}

int wm_window_focused(int i)
{
    if (i < 0 || i >= nwin) return 0;
    int top = top_visible_window();
    return (i == top);
}

window_t *wm_window_at(int i)
{
    return (i >= 0 && i < nwin) ? wins[i] : NULL;
}
