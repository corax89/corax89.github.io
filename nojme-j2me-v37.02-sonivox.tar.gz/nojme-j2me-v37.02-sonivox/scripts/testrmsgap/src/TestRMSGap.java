import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.InvalidRecordIDException;

/* v37.02 [RMS-GAP-HEAL] — репродуктор полевого бага Zombie Infection
 * (лог 2026-10-10: «загрузилось не то, что сохранялось») для
 * scripts/test_rmsgap.sh (bin/switchui-verify, E2E).
 *
 * Мидлет использует РОВНО идиому сохранений Gameloft (декомпиляция
 * класса g, методы B/c/a/ci/ad):
 *   B(n)  — бутстрап: open; если getNumRecords()==0 — добавить n
 *           записей по 1 байту; close. При живой записи 1 НЕ ВЫПОЛНЯЕТСЯ
 *           НИКОГДА — «частичный» стор (запись 1 есть, 2..n потеряны)
 *           игра сама не лечит.
 *   c(id) — чтение: open; getRecord(id); close; ЛЮБОЕ исключение
 *           глотается -> null («нет сохранения»).
 *   a(id) — запись: open; setRecord(id,...); close; исключение
 *           глотается -> false (прогресс ТИХО не сохраняется).
 *   ci()  — настройки: D=c(1); если null -> B(2)+a(1,умолчания).
 *   ad()  — прогресс: E=c(2); если null -> return (новая игра).
 * Полевой стор 'a': запись id=1 (настройки, 219 Б) жива, запись id=2
 * (прогресс) потеряна историческими багами -> c(2)=null вечно,
 * a(2,...) вечно InvalidRecordIDException.
 *
 * Сторы (готовит scripts/make_gap_rms.py ДО запуска):
 *   GZ1 — полевой кейс: запись 1 (219 Б), next_id=2, запись 2 потеряна;
 *   GZ3 — записи 1,2,3 (next_id=4) — тест удалённого id (спека);
 *   GZ4 — запись 1, next_id=2 — тест дикого id (граница хила);
 *   GZ5 — запись 1, next_id=2 — тест скан-цикла чтения (без роста);
 *   GZH — здоровый: записи 1,2 (next_id=3) — хил не вмешивается;
 *   GZ6 — копия GZ1 для A/B с рубильником NOJME_RMS_GAP_HEAL=0.
 */
public class TestRMSGap extends MIDlet {
    static int pass = 0, fail = 0;

    static void chk(String id, boolean cond, String detail) {
        if (cond) { pass++; System.out.println("RG:" + id + " PASS " + detail); }
        else      { fail++; System.out.println("RG:" + id + " FAIL " + detail); }
    }

    static byte[] one = new byte[1]; /* g.d — бутстрап-байт */

    /* g.B(n): бутстрап ТОЛЬКО при пустом сторе. */
    static void ziBootstrap(String store, int n) throws Exception {
        RecordStore rs = RecordStore.openRecordStore(store, true);
        try {
            if (rs.getNumRecords() == 0) {
                for (int i = 0; i < n; i++) rs.addRecord(one, 0, 1);
            }
        } finally {
            rs.closeRecordStore();
        }
    }

    /* g.c(id): чтение; исключение глотается -> null. */
    static byte[] ziRead(String store, int id) {
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(store, true);
        } catch (Throwable t) {
            return null;
        }
        try {
            return rs.getRecord(id);
        } catch (Throwable t) {
            return null;
        } finally {
            try { rs.closeRecordStore(); } catch (Throwable t) { }
        }
    }

    /* g.a(id, data): запись; исключение глотается -> false. */
    static boolean ziWrite(String store, int id, byte[] data) {
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(store, true);
        } catch (Throwable t) {
            return false;
        }
        try {
            rs.setRecord(id, data, 0, data.length);
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            try { rs.closeRecordStore(); } catch (Throwable t) { }
        }
    }

    /* g.ci(): настройки. D=c(1); null -> B(2)+a(1,умолчания). */
    static byte[] ziCi(String store) {
        byte[] d = ziRead(store, 1);
        if (d == null) {
            try { ziBootstrap(store, 2); } catch (Throwable t) { }
            ziWrite(store, 1, "defaults".getBytes());
            d = ziRead(store, 1);
        }
        return d;
    }

    static int numRecords(String store) {
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(store, true);
            return rs.getNumRecords();
        } catch (Throwable t) {
            return -1;
        } finally {
            try { rs.closeRecordStore(); } catch (Throwable t) { }
        }
    }

    void session1() {
        /* --- GZ1: ПОЛЕВОЙ КЕЙС Zombie Infection --- */
        byte[] d = ziCi("GZ1");
        chk("G1-CI", d != null && d.length > 0,
            "ci(): settings record 1 alive, len=" + (d == null ? -1 : d.length));
        chk("G1-NOBOOT", numRecords("GZ1") == 1,
            "bootstrap B(2) skipped (record 1 alive) — n=" + numRecords("GZ1"));
        byte[] e = ziRead("GZ1", 2);
        chk("G1-AD", e == null,
            "ad(): c(2) -> null (InvalidRecordIDException swallowed) — field behavior");
        boolean ok = ziWrite("GZ1", 2, "LEVEL-3".getBytes());
        chk("G1-SAVE", ok, "progress a(2,E) healed: setRecord(2) succeeded");
        byte[] back = ziRead("GZ1", 2);
        chk("G1-RELOAD", back != null && "LEVEL-3".equals(new String(back)),
            "reload c(2)=" + (back == null ? "null" : new String(back)));
        byte[] d2 = ziRead("GZ1", 1);
        chk("G1-SETTINGS", d2 != null && new String(d2).startsWith("OLD"),
            "settings record 1 untouched by heal: " + (d2 == null ? "null" : new String(d2)));

        /* --- GZ3: УДАЛЁННЫЙ id — спека, хил не воскрешает --- */
        {
            RecordStore rs = null;
            boolean del = false;
            try {
                rs = RecordStore.openRecordStore("GZ3", true);
                rs.deleteRecord(2); /* next_id остаётся 4 */
                del = true;
            } catch (Throwable t) {
            } finally {
                try { if (rs != null) rs.closeRecordStore(); } catch (Throwable t) { }
            }
            chk("G3-DEL", del, "deleteRecord(2) on healthy store");
        }
        chk("G3-SPEC", !ziWrite("GZ3", 2, "zombie".getBytes()),
            "setRecord(2) after delete still throws (spec: id < next_id)");

        /* --- GZ4: ДИКИЙ id — за границей хила --- */
        chk("G4-WILD", !ziWrite("GZ4", 202, "wild".getBytes()),
            "setRecord(next_id+200) throws (gap bound 64)");

        /* --- GZ5: скан-цикл чтения — стор не растёт --- */
        boolean allNull = true;
        for (int i = 2; i <= 4; i++) {
            if (ziRead("GZ5", i) != null) allNull = false;
        }
        chk("G5-SCAN", allNull && numRecords("GZ5") == 1,
            "getRecord on missing tail ids: all null, records=" + numRecords("GZ5")
            + " (no auto-create on READ — scan loops safe)");

        /* --- GZH: здоровый стор — хил не вмешивается --- */
        chk("GH-SAVE", ziWrite("GZH", 2, "upd2".getBytes()),
            "healthy setRecord(2) on existing id works");
        byte[] h = ziRead("GZH", 2);
        chk("GH-RELOAD", h != null && "upd2".equals(new String(h)),
            "healthy reload=" + (h == null ? "null" : new String(h)));

        /* --- GZ6: A/B-маркер (рубильник NOJME_RMS_GAP_HEAL=0) --- */
        boolean ok6 = ziWrite("GZ6", 2, "ab".getBytes());
        chk("G6-AB", true, "GZ6 setRecord(2) ok=" + ok6
            + " (expect false with NOJME_RMS_GAP_HEAL=0, true otherwise)");
    }

    void session2() {
        /* Персистентность через перезапуск ПРОЦЕССА — сценарий
         * пользователя: прошёл уровень, вышел, открыл — «Продолжить». */
        byte[] e = ziRead("GZ1", 2);
        chk("P1-LOAD", e != null && "LEVEL-3".equals(new String(e)),
            "healed progress survived restart: " + (e == null ? "null" : new String(e)));
        boolean ok = ziWrite("GZ1", 2, "LEVEL-4".getBytes());
        chk("P1-SAVE", ok, "second-session save works (normal path now)");
        byte[] e2 = ziRead("GZ1", 2);
        chk("P2-LOAD", e2 != null && "LEVEL-4".equals(new String(e2)),
            "reload after second save=" + (e2 == null ? "null" : new String(e2)));
    }

    public void startApp() {
        System.out.println("RMSGAP-TEST-START");
        byte[] probe = ziRead("GZ1", 2);
        if (probe != null) {
            System.out.println("RMSGAP: session 2 (persistence)");
            session2();
        } else {
            System.out.println("RMSGAP: session 1 (gap heal)");
            session1();
        }
        System.out.println("RG:DONE " + pass + "/" + fail);
        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
