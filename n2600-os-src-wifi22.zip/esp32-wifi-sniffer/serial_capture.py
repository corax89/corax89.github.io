#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
serial_capture.py — приёмник данных сниффера esp32_wifi_sniffer (N2600-OS).

Текстовый режим (по умолчанию) — читаемый дамп в файл + на консоль:
    python3 serial_capture.py --port COM5
    python3 serial_capture.py --port /dev/ttyUSB0 --out log.txt

Режим pcap — бинарный поток с ESP32 в dump.pcap для Wireshark:
    1) в мониторе порта послать ESP32 команду:  pcap 1
       (ответит "[pcap] ВКЛ", после этого текст в UART пропадёт)
    2) python3 serial_capture.py --port COM5 pcap --out dump.pcap
    3) Ctrl-C — файл закроется; открыть dump.pcap в Wireshark.
       Полезные фильтры:  eapol || auth || assoc-req || deauth

Список портов:  python3 serial_capture.py --list
Зависимости:    pip install pyserial
"""
import argparse
import struct
import sys
import time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    print("Нужен pyserial:  pip install pyserial")
    sys.exit(1)

# ESP32 sig_len включает FCS; если Wireshark на КАЖДОМ кадре пишет "bad FCS"
# — значит у этого ядра sig_len БЕЗ FCS: поставь False и перезапусти захват.
RADIOTAP_FCS = True

CAP_MAX = 384  # должен совпадать с CAP_MAX в esp32_wifi_sniffer.ino


def crc8(data: bytes) -> int:
    c = 0
    for b in data:
        c ^= b
        for _ in range(8):
            c = ((c >> 1) ^ 0x8C) if (c & 1) else (c >> 1)
    return c


def list_serial_ports() -> None:
    ports = list(list_ports.comports())
    if not ports:
        print("Последовательные порты не найдены")
        return
    for p in ports:
        print(f"{p.device:20s} {p.description}")


def run_text(port: str, baud: int, out: str) -> None:
    f = open(out, "w", encoding="utf-8", errors="replace")
    print(f"[log] порт {port} @ {baud}, пишу в {out} (Ctrl-C — завершить)")
    n = 0
    try:
        with serial.Serial(port, baud, timeout=0.5) as ser:
            while True:
                line = ser.readline()
                if not line:
                    continue
                s = line.decode("utf-8", errors="replace").rstrip("\r\n")
                f.write(s + "\n")
                f.flush()
                print(s)
                n += 1
    except KeyboardInterrupt:
        print(f"\n[log] завершено, строк принято: {n}")
    except serial.SerialException as e:
        print(f"[log] ошибка порта: {e}")
    finally:
        f.close()
        print(f"[log] лог сохранён: {out}")


def run_pcap(port: str, baud: int, out: str) -> None:
    f = open(out, "wb")
    # глобальный заголовок pcap: LINKTYPE_IEEE802_11_RADIO = 127
    f.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 262144, 127))
    print(f"[pcap] порт {port} @ {baud}, пишу {out}")
    print("[pcap] Ctrl-C — завершить; затем открой файл в Wireshark")
    buf = bytearray()
    frames = bad_crc = resyncs = seq_gaps = 0
    last_seq = None
    last_report = time.time()
    try:
        with serial.Serial(port, baud, timeout=0.5) as ser:
            while True:
                chunk = ser.read(4096)
                if chunk:
                    buf.extend(chunk)
                while True:
                    # 1) ищем синхрослово AA 55
                    i = buf.find(b"\xAA\x55")
                    if i < 0:
                        buf = buf[-1:]
                        break
                    if i > 0:
                        del buf[:i]
                        resyncs += 1
                    if len(buf) < 4:
                        break
                    # 2) длина тела: sanity-фильтр отсекает текст в UART
                    plen = buf[2] | (buf[3] << 8)
                    if not (20 <= plen <= 18 + CAP_MAX):
                        del buf[:2]
                        resyncs += 1
                        continue
                    total = 4 + plen + 1
                    if len(buf) < total:
                        break
                    # 3) CRC по seq+meta+payload
                    body = bytes(buf[4:4 + plen])
                    crc = buf[4 + plen]
                    if crc8(body) != crc:
                        del buf[:2]
                        bad_crc += 1
                        resyncs += 1
                        continue
                    del buf[:total]
                    # 4) разбор
                    seq = body[0] | (body[1] << 8)
                    ts_us = int.from_bytes(body[2:10], "little")
                    rssi = body[10] - 256 if body[10] >= 128 else body[10]
                    orig_len = body[14] | (body[15] << 8)
                    caplen = body[16] | (body[17] << 8)
                    frame = body[18:18 + caplen]
                    if last_seq is not None and ((last_seq + 1) & 0xFFFF) != seq:
                        seq_gaps += 1
                    last_seq = seq
                    # 5) запись в pcap: radiotap(flags FCS + rssi) + кадр
                    present = 0x02 | 0x20          # FLAGS | DBM_ANTSIGNAL
                    rflags = 0x10 if RADIOTAP_FCS else 0x00
                    radiotap = struct.pack("<BBHIBB", 0, 0, 10, present,
                                           rflags, rssi & 0xFF)
                    ts_sec = (ts_us // 1_000_000) & 0xFFFFFFFF
                    ts_usec = ts_us % 1_000_000
                    incl = len(radiotap) + len(frame)
                    orig = len(radiotap) + orig_len
                    f.write(struct.pack("<IIII", ts_sec, ts_usec, incl, orig))
                    f.write(radiotap)
                    f.write(frame)
                    f.flush()
                    frames += 1
                    if time.time() - last_report > 5:
                        last_report = time.time()
                        print(f"[pcap] кадров={frames} crc-ошибок={bad_crc} "
                              f"потерь(seq)={seq_gaps} ресинхр={resyncs}")
    except KeyboardInterrupt:
        pass
    finally:
        f.close()
        print(f"\n[pcap] готово: кадров={frames} crc-ошибок={bad_crc} "
              f"потерь(seq)={seq_gaps} ресинхр={resyncs}")
        print(f"[pcap] файл: {out}  (Wireshark: eapol || auth || assoc || deauth)")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Приёмник дампа сниффера esp32_wifi_sniffer (N2600-OS)")
    ap.add_argument("--list", action="store_true", help="показать COM-порты")
    ap.add_argument("--port", help="COM5 / /dev/ttyUSB0 / ...")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--out", help="имя выходного файла")
    ap.add_argument("mode", nargs="?", choices=["text", "pcap"],
                    default="text", help="режим (по умолчанию text)")
    args = ap.parse_args()

    if args.list:
        list_serial_ports()
        return
    if not args.port:
        ap.error("укажи --port COMx (или --list)")

    if args.mode == "pcap":
        out = args.out or "dump.pcap"
        run_pcap(args.port, args.baud, out)
    else:
        out = args.out or time.strftime("sniff_%Y%m%d_%H%M%S.log")
        run_text(args.port, args.baud, out)


if __name__ == "__main__":
    main()
