/*
 * ====================================================================
 *  ESP32 WiFi DIAGNOSTICS v2  (N2600-OS): SoftAP "esp32test" + SNIFFER
 * ====================================================================
 * Совместимость: Arduino-ESP32 core 1.0.x (ВАШ случай) И 2.x/3.x.
 * НИКАКИХ esp_netif.h / esp_event.h не нужно: в ядре 1.0.x esp_netif
 * вообще не существует (его роль играет tcpip_adapter.h, но и он нам
 * не нужен) - подключаются только WiFi.h и esp_wifi.h, которые уже
 * входят в ядро.
 *
 * Что делает:
 *  - поднимает открытую точку доступа "esp32test" на канале 6;
 *  - одновременно сниффит эфир (promiscuous) НА ТОМ ЖЕ канале;
 *  - SMART-фильтр: показывает только кадры, относящиеся к нашему AP
 *    или к клиентам, которые его ищут/подключаются. Чужие сети,
 *    их биконы и данные отсеиваются (MAC-фильтр с автообучением).
 *  - разбирает PROBE/AUTH/ASSOC/DEAUTH и проверяет поле Sequence
 *    Control: ловит баг [W-SEQ2] (номер последовательности попал в
 *    поле fragment) прямо в эфире;
 *  - всё печатает в Serial (115200).
 *
 * ВАЖНО: ESP32 НЕ ВИДИТ собственные переданные кадры (probe-resp/
 * auth-resp/assoc-resp от AP невидимы). Зато мы видим: все запросы
 * нетбука + его ACK-и в ответ на наши кадры (CTRL ACK c A1=наш MAC).
 * Этого достаточно, чтобы понять, на каком этапе рвётся ассоциация.
 * Для полного захвата ОБЕИХ сторон залейте второй ESP32 этим же
 * скетчем с SNIFF_ONLY 1 (чистый сниффер рядом с нетбуком).
 *
 * Команды в мониторе порта (можно без перевода строки):
 *   h / ?  - справка
 *   f      - фильтр: SMART <-> ALL (сырой эфир)
 *   c      - конфиг AP и список выученных MAC
 *   r      - очистить список выученных MAC
 * ====================================================================
 */

#include <Arduino.h>
#include <WiFi.h>
#include <esp_wifi.h>

// ---------------------- НАСТРОЙКИ ----------------------
#define AP_SSID       "esp32test"
#define AP_PASS       ""        // ""  = открытая сеть (рекомендую для первой диагностики)
                                // >=8 символов = WPA2-PSK (ближе к реальному HomeWifi)
#define AP_CHANNEL    6         // канал AP и сниффера 1..13
#define AP_MAX_STA    4
#define SERIAL_BAUD   115200    // для режима ALL можно поднять до 921600
#define SNIFF_ONLY    0         // 1 = сниффер БЕЗ AP (для второго ESP32)
// -------------------------------------------------------

#define RB_SLOTS 32             // очередь пакетов (степень двойки!)
#define RB_CAP   512            // сколько байт пакета сохраняем

struct PktRec {
  uint16_t len;                 // сохранено байт
  uint16_t olen;                // исходная длина в эфире
  int8_t   rssi;
  uint8_t  ptype;               // 0=MGMT 1=CTRL 2=DATA
  uint32_t tms;                 // millis()
  uint32_t tus;                 // esp timestamp, us
  uint8_t  data[RB_CAP];
};

static PktRec            rb[RB_SLOTS];
static volatile uint16_t rbHead = 0, rbTail = 0;
static uint32_t          rbDrops = 0;

static uint8_t  apMac[6]  = {0,0,0,0,0,0};
static uint8_t  staMacs[4][6];          // выученные MAC клиентов
static int      staCnt    = 0;
static bool     filterAll = false;
static bool     apOpen    = true;

static const uint8_t WPA_OUI[3] = {0x00, 0x50, 0xF2};

// ---------------------- helpers ----------------------
static inline uint16_t le16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static inline bool isMcast(const uint8_t *m)  { return (m[0] & 0x01) != 0; }

static void mac2str(const uint8_t *m, char *out) {
  sprintf(out, "%02X:%02X:%02X:%02X:%02X:%02X", m[0], m[1], m[2], m[3], m[4], m[5]);
}

static bool isKnown(const uint8_t *m) {
  if (memcmp(m, apMac, 6) == 0) return true;
  for (int i = 0; i < staCnt; i++)
    if (memcmp(m, staMacs[i], 6) == 0) return true;
  return false;
}

// первый IE SSID (id=0) совпадает с нашим?
static bool ssidIsOurs(const uint8_t *p, uint16_t len, uint16_t ieOff) {
  uint16_t off = ieOff;
  while (off + 2 <= len) {
    uint8_t id = p[off], l = p[off + 1];
    if (off + 2 + (uint16_t)l > len) break;
    if (id == 0) {
      size_t want = strlen(AP_SSID);
      return (l == want) && (memcmp(p + off + 2, AP_SSID, l) == 0);
    }
    off += 2 + l;
  }
  return false;
}

struct IEs { char ssid[33]; bool rsn; bool wpa1; int dsChan; };

static void getIEs(const uint8_t *p, uint16_t ieOff, uint16_t len, IEs &o) {
  memset(&o, 0, sizeof(o));
  o.dsChan = -1;
  uint16_t off = ieOff;
  while (off + 2 <= len) {
    uint8_t id = p[off], l = p[off + 1];
    if (off + 2 + (uint16_t)l > len) break;
    const uint8_t *body = p + off + 2;
    if      (id == 0) { int n = (l > 32) ? 32 : l; memcpy(o.ssid, body, n); o.ssid[n] = 0; }
    else if (id == 3 && l >= 1) o.dsChan = body[0];
    else if (id == 48)          o.rsn  = true;
    else if (id == 221 && l >= 4 && memcmp(body, WPA_OUI, 3) == 0) o.wpa1 = true;
    off += 2 + l;
  }
}

static const char *statusName(uint16_t c) {
  switch (c) {
    case 0:  return "SUCCESS";
    case 1:  return "UNSPEC-FAILURE";
    case 10: return "CANNOT-SUPPORT-CAPS";
    case 13: return "AUTH-ALG-NOT-SUPPORTED";
    case 14: return "AUTH-UNEXPECTED-SEQ";
    case 15: return "AUTH-CHALLENGE-FAIL";
    case 16: return "AUTH-TIMEOUT";
    case 17: return "AP-CANNOT-HANDLE-MORE";
    case 18: return "BASIC-RATES-NOT-SUPPORTED";
    default: return "code?";
  }
}

static const char *reasonName(uint16_t c) {
  switch (c) {
    case 1:  return "UNSPEC";
    case 2:  return "PREV-AUTH-NO-LONGER-VALID";
    case 3:  return "STA-LEAVING";
    case 4:  return "INACTIVITY";
    case 5:  return "AP-TOO-MANY-STAS";
    case 6:  return "CLASS2-FROM-NONAUTH";
    case 7:  return "CLASS3-FROM-NONASSOC";
    case 8:  return "DISASSOC-LEAVING";
    case 15: return "4WAY-HANDSHAKE-TIMEOUT";
    default: return "code?";
  }
}

static const char *mgmtSubName(uint8_t s) {
  switch (s) {
    case 0:  return "ASSOC-REQ";
    case 1:  return "ASSOC-RESP";
    case 2:  return "REASSOC-REQ";
    case 3:  return "REASSOC-RESP";
    case 4:  return "PROBE-REQ";
    case 5:  return "PROBE-RESP";
    case 8:  return "BEACON";
    case 10: return "DISASSOC";
    case 11: return "AUTH";
    case 12: return "DEAUTH";
    case 13: return "ACTION";
    default: return "MGMT?";
  }
}

static const char *ctrlSubName(uint8_t s) {
  switch (s) {
    case 8:  return "BLOCKACK-REQ";
    case 9:  return "BLOCKACK";
    case 10: return "PS-POLL";
    case 11: return "RTS";
    case 12: return "CTS";
    case 13: return "ACK";
    case 14: return "CF-END";
    default: return "CTRL?";
  }
}

// ---------------------- колбэк сниффера ----------------------
static void IRAM_ATTR snifferCb(void *buf, wifi_promiscuous_pkt_type_t type) {
  if (type == WIFI_PROMIS_PKT_TYPE_MISC) return;          // битый кадр
  const wifi_promiscuous_pkt_t *pkt = (const wifi_promiscuous_pkt_t *)buf;
  const uint8_t *p    = pkt->payload;
  uint16_t       olen = pkt->rx_ctrl.sig_len;
  if (olen < 10) return;                                  // ACK = 10 байт, не отбрасывать!

  uint8_t t = (p[0] >> 2) & 3;
  uint8_t s = (p[0] >> 4) & 0xF;
  const uint8_t *a1 = p + 4;
  const uint8_t *a2 = (t == 1 && (s == 12 || s == 13)) ? a1 : p + 10; // CTS/ACK без A2
  const uint8_t *a3 = p + 16;

  if (!filterAll) {
    bool keep = false;
    if (t == 0) {                                         // MGMT
      if (s == 4) keep = true;                            // все probe-req (поиск сети)
      else keep = isKnown(a1) || isKnown(a2) || (olen >= 24 && isKnown(a3));
      // автообучение: MAC клиента, который обращается к нашему AP
      if (!isMcast(a2) && memcmp(a2, apMac, 6) != 0 && staCnt < 4) {
        bool related;
        if (s == 4) related = (memcmp(a1, apMac, 6) == 0) || ssidIsOurs(p, olen, 24);
        else        related = (memcmp(a1, apMac, 6) == 0) || (memcmp(a3, apMac, 6) == 0);
        if (related && !isKnown(a2)) memcpy(staMacs[staCnt++], a2, 6);
      }
    } else if (t == 1) {                                  // CTRL
      keep = isKnown(a1) || isKnown(a2);
    } else {                                              // DATA
      keep = isKnown(a1) || (olen >= 24 && isKnown(a2)) || (olen >= 24 && isKnown(a3));
    }
    if (!keep) return;
  }

  uint16_t nh = (rbHead + 1) & (RB_SLOTS - 1);
  if (nh == rbTail) { rbDrops++; return; }                // очередь полна -> дроп
  PktRec &r = rb[rbHead];
  r.len   = (olen > RB_CAP) ? RB_CAP : olen;
  r.olen  = olen;
  r.rssi  = pkt->rx_ctrl.rssi;
  r.ptype = (uint8_t)type;
  r.tms   = millis();
  r.tus   = pkt->rx_ctrl.timestamp;
  memcpy(r.data, p, r.len);
  rbHead = nh;
}

// ---------------------- печать кадра ----------------------
static void dumpPacket(const PktRec &r) {
  const uint8_t *p   = r.data;
  uint16_t len = r.len;
  uint8_t  t   = (p[0] >> 2) & 3;
  uint8_t  s   = (p[0] >> 4) & 0xF;
  uint8_t  f1  = p[1];
  bool toDS = f1 & 0x01, fromDS = f1 & 0x02;
  bool retry = (f1 >> 3) & 1, wep = (f1 >> 6) & 1;
  bool four  = toDS && fromDS;                            // 4-адресные (WDS) - SC не по смещению 22

  const uint8_t *a1 = p + 4;
  const uint8_t *a2 = (t == 1 && (s == 12 || s == 13)) ? a1 : p + 10;
  const uint8_t *a3 = p + 16;

  char a1s[18], a2s[18], a3s[18];
  mac2str(a1, a1s); mac2str(a2, a2s); mac2str(a3, a3s);

  const char *tn = (r.ptype == 0) ? "MGMT" : (r.ptype == 1) ? "CTRL" :
                   (r.ptype == 2) ? "DATA" : "MISC";
  char subn[16];
  if      (r.ptype == 0) strncpy(subn, mgmtSubName(s), sizeof(subn) - 1);
  else if (r.ptype == 1) strncpy(subn, ctrlSubName(s), sizeof(subn) - 1);
  else                   snprintf(subn, sizeof(subn), "DATA-0x%02X", s);
  subn[sizeof(subn) - 1] = 0;

  const char *dir = "ext";
  if (t == 0) {
    if      (memcmp(a2, apMac, 6) == 0)                              dir = "AP->STA";
    else if (memcmp(a1, apMac, 6) == 0 || memcmp(a3, apMac, 6) == 0) dir = "STA->AP";
  } else if (t == 1) {
    dir = (memcmp(a1, apMac, 6) == 0) ? "ACK->AP-frame" : "ACK->other";
  } else {
    if      (toDS && !fromDS)  dir = (memcmp(a1, apMac, 6) == 0) ? "STA->AP"  : "STA->ext";
    else if (fromDS && !toDS)  dir = (memcmp(a2, apMac, 6) == 0) ? "AP->STA"  : "ext->STA";
  }

  bool fromSta = (r.ptype == 0) && (memcmp(a2, apMac, 6) != 0);
  bool isReq   = fromSta && (s == 0 || s == 4 || s == 11 || s == 10 || s == 12);
  if (isReq) Serial.println("------------------------------------------------");

  Serial.printf("[P %6lu.%03lu] ch=%d rssi=%d %s/%s len=%u retry=%d wep=%d dir=%s\r\n",
                (unsigned long)(r.tms / 1000UL), (unsigned long)(r.tms % 1000UL),
                (int)AP_CHANNEL, (int)r.rssi, tn, subn,
                (unsigned)r.olen, (int)retry, (int)wep, dir);

  if (len >= 24 && !four) {
    uint16_t sc = le16(p + 22);
    Serial.printf("  A1=%s A2=%s A3=%s | SC: seq=%u frag=%u\r\n",
                  a1s, a2s, a3s, (unsigned)(sc >> 4), (unsigned)(sc & 0xF));
  } else {
    Serial.printf("  A1=%s A2=%s A3=%s | SC: n/a\r\n", a1s, a2s, a3s);
  }

  // проверка [W-SEQ2]: запрос клиента с frag != 0 подозрителен
  if (fromSta && (s == 0 || s == 4 || s == 11) && len >= 24 && !four) {
    uint8_t frag = le16(p + 22) & 0xF;
    if (frag != 0) {
      Serial.printf("  !! frag=%u != 0 в запросе %s! Похоже на баг [W-SEQ2]: номер"
                    " последовательности попал в поле fragment (байты SC выглядят как 0N 00).\r\n"
                    "     Правильно: byte22=(seq<<4)|frag, byte23=seq>>4\r\n",
                    (unsigned)frag, subn);
    }
  }

  if (r.ptype == 0 && len >= 24) {
    const uint8_t *b  = p + 24;
    uint16_t       bl = len - 24;
    if (s == 11 && bl >= 6) {                             // AUTH
      uint16_t alg = le16(b), txn = le16(b + 2), st = le16(b + 4);
      const char *algN = (alg == 0) ? "open-system" : (alg == 1) ? "shared-key(WEP)" :
                         (alg == 2) ? "FT" : (alg == 3) ? "SAE" : "unknown";
      Serial.printf("  AUTH: alg=%u(%s) txn=%u status=%u(%s)\r\n",
                    alg, algN, txn, st, statusName(st));
      if (fromSta && alg == 1)
        Serial.println("  !! shared-key (WEP) аутентификация - проверьте конфиг нетбука");
    } else if (s == 0 && bl >= 4) {                       // ASSOC-REQ
      IEs ie; getIEs(p, 28, len, ie);
      Serial.printf("  ASSOC-REQ: caps=0x%04X listen-int=%u ssid=\"%s\" rsn=%d wpa1=%d\r\n",
                    le16(b), le16(b + 2), ie.ssid, (int)ie.rsn, (int)ie.wpa1);
    } else if (s == 1 && bl >= 6) {                       // ASSOC-RESP
      Serial.printf("  ASSOC-RESP: status=%u(%s) aid=0x%04X caps=0x%04X\r\n",
                    le16(b + 2), statusName(le16(b + 2)), le16(b + 4), le16(b));
    } else if (s == 2 && bl >= 10) {                      // REASSOC-REQ
      IEs ie; getIEs(p, 34, len, ie);
      Serial.printf("  REASSOC-REQ: ssid=\"%s\" curAP=%02X:%02X:%02X:%02X:%02X:%02X\r\n",
                    ie.ssid, b[4], b[5], b[6], b[7], b[8], b[9]);
    } else if ((s == 10 || s == 12) && bl >= 2) {         // DISASSOC / DEAUTH
      Serial.printf("  %s: reason=%u(%s)\r\n",
                    (s == 10) ? "DISASSOC" : "DEAUTH", le16(b), reasonName(le16(b)));
    } else if (s == 4 || s == 5 || s == 8) {              // PROBE-REQ / PROBE-RESP / BEACON
      IEs ie; getIEs(p, (s == 4) ? 24 : 36, len, ie);
      Serial.printf("  %s: ssid=\"%s\" chan-ie=%d rsn(WPA2)=%d wpa1=%d\r\n",
                    (s == 4) ? "PROBE-REQ" : (s == 5) ? "PROBE-RESP" : "BEACON",
                    ie.ssid, ie.dsChan, (int)ie.rsn, (int)ie.wpa1);
    }
  }

  if (wep && apOpen && r.ptype == 2 &&
      (memcmp(a1, apMac, 6) == 0 || memcmp(a2, apMac, 6) == 0)) {
    Serial.println("  !! зашифрованный DATA на ОТКРЫТОМ AP - проверьте, что шлёт нетбук");
  }

  uint16_t cap = (r.ptype == 0) ? 192 : 96;
  if (r.ptype == 0 && s == 8) cap = 0;                    // бикон: без hex (повтор каждые 100 мс)
  if (cap > len) cap = len;
  Serial.print("  HEX:");
  for (uint16_t i = 0; i < cap; i++) Serial.printf(" %02X", p[i]);
  if (len > cap) Serial.printf(" ...(+%u)", len - cap);
  Serial.println();
}

// ---------------------- служебное ----------------------
static void printHelp() {
  Serial.println("h/? - справка | f - фильтр SMART<->ALL | c - конфиг | r - сброс списка STA");
}

static void printConfig() {
  char m[18]; mac2str(apMac, m);
  Serial.printf("AP: ssid=\"%s\" ch=%d auth=%s\r\n",
                AP_SSID, (int)AP_CHANNEL, apOpen ? "OPEN" : "WPA2-PSK");
  Serial.printf("BSSID(AP)=%s ip=%s sta=%u\r\n", m,
                WiFi.softAPIP().toString().c_str(), (unsigned)WiFi.softAPgetStationNum());
  Serial.printf("выученные STA: %d\r\n", staCnt);
  for (int i = 0; i < staCnt; i++) {
    mac2str(staMacs[i], m);
    Serial.printf("  [%d] %s\r\n", i, m);
  }
  Serial.printf("фильтр: %s | дропов из очереди: %u\r\n",
                filterAll ? "ALL (сырой эфир)" : "SMART", (unsigned)rbDrops);
}

// ---------------------- setup / loop ----------------------
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(400);
  Serial.println();
  Serial.println("==================================================");
  Serial.println("  N2600-OS WiFi diagnostics v2: AP \"esp32test\" + sniffer");
  Serial.println("==================================================");

#if SNIFF_ONLY
  filterAll = true;
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true);
  delay(100);
  esp_wifi_set_promiscuous_filter(NULL);
  esp_wifi_set_promiscuous_rx_cb(&snifferCb);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(AP_CHANNEL, WIFI_SECOND_CHAN_NONE);
  Serial.printf("Режим SNIFF_ONLY: без AP, канал %d, фильтр ALL\r\n", (int)AP_CHANNEL);
#else
  apOpen = (AP_PASS[0] == 0);

  WiFi.mode(WIFI_AP);
  bool ok = WiFi.softAP(AP_SSID, apOpen ? NULL : AP_PASS, AP_CHANNEL, 0, AP_MAX_STA);
  delay(100);
  WiFi.softAPmacAddress(apMac);
  if (!ok) Serial.println("!! softAP не поднялся (пароль WPA2 должен быть >= 8 символов)");

  wifi_promiscuous_filter_t filt;
  filt.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT |
                     WIFI_PROMIS_FILTER_MASK_CTRL |
                     WIFI_PROMIS_FILTER_MASK_DATA;
  esp_wifi_set_promiscuous_filter(&filt);
  esp_wifi_set_promiscuous_rx_cb(&snifferCb);
  esp_wifi_set_promiscuous(true);

  printConfig();
  Serial.println();
  Serial.println("Подключите нетбук к сети \"esp32test\". Здоровый обмен выглядит так:");
  Serial.println(" 1) PROBE-REQ (STA->AP) - может быть broadcast при сканировании");
  Serial.println(" 2) [AP шлёт PROBE-RESP - сам себя не видит] -> далее CTRL 'ACK->AP-frame' от STA");
  Serial.println(" 3) AUTH alg=0 txn=1 (STA->AP)");
  Serial.println(" 4) [AP шлёт AUTH txn=2 status=0] -> ACK от STA");
  Serial.println(" 5) ASSOC-REQ (STA->AP)");
  Serial.println(" 6) [AP шлёт ASSOC-RESP status=0] -> ACK от STA");
  Serial.println(" 7) DATA от STA (ARP/DHCP...)");
  Serial.println();
  Serial.println("ВАЖНО: ESP32 не видит собственные кадры (resp от AP невидимы), но видит");
  Serial.println("все запросы STA и его ACK-и на наши кадры. Пропал ACK после resp =");
  Serial.println("STA не услышал/не разобрал ответ. RETRY=1 на повторе запроса = ответа не было.");
  Serial.println("Для полного захвата ОБЕИХ сторон: второй ESP32 с SNIFF_ONLY 1.");
  Serial.println();
#endif
  printHelp();
}

void loop() {
  while (rbTail != rbHead) {
    dumpPacket(rb[rbTail]);
    rbTail = (rbTail + 1) & (RB_SLOTS - 1);
  }

  while (Serial.available() > 0) {
    int c = Serial.read();
    if      (c == 'f') { filterAll = !filterAll; Serial.printf("фильтр -> %s\r\n", filterAll ? "ALL" : "SMART"); }
    else if (c == 'c') printConfig();
    else if (c == 'r') { staCnt = 0; Serial.println("список STA очищен"); }
    else if (c == 'h' || c == '?') printHelp();
  }

  static uint32_t lastMs = 0, lastSta = 0;
  uint32_t now = millis();
  if (now - lastMs >= 1000) {
    lastMs = now;
#if !SNIFF_ONLY
    uint32_t n = WiFi.softAPgetStationNum();
    if (n != lastSta) { lastSta = n; Serial.printf("AP: stations=%u\r\n", (unsigned)n); }
#endif
    if (rbDrops) {
      Serial.printf("!! переполнение очереди, потеряно %u кадр. (перейдите на 921600 или включите SMART)\r\n",
                    (unsigned)rbDrops);
      rbDrops = 0;
    }
  }
}
