/*
  ============================================================================
  esp32_wifi_sniffer.ino  v1.0  —  WiFi debugger for N2600-OS (ASUS X101CH)
  ============================================================================
  ESP32 поднимает SoftAP (по умолчанию имитирует точку "HomeWifi", ОТКРЫТУЮ)
  и ОДНОВРЕМЕННО работает в promiscuous-режиме, вываливая в UART ПОЛНУЮ
  информацию о каждом 802.11 кадре: рdf-заголовки, SC (seq/frag!),
  AUTH alg/txn/status, ASSOC capabilities/IEs, RSN, EAPOL M1-M4,
  DEAUTH/DISASSOC reason, hex-дампы и скорость/точку приёма каждого кадра.

  ДВА РЕЖИМА:
    mode ap      - ESP32 = точка доступа + сниффер на её канале.
                   Смотрим ТОЛЬКО кадры нетбука (AUTH REQ, ASSOC REQ, EAPOL,
                   а также retry-повторы = "нетбук не слышит ответ").
    mode sniff N - пассивный монитор на канале N. Слушаем РЕАЛЬНЫЙ диалог
                   "нетбук <-> домашний роутер": видим ОБЕ стороны, включая
                   статус-коды AUTH RSP / ASSOC RESP роутера и его EAPOL M1/M3.

  ВАЖНОЕ ОГРАНИЧЕНИЕ: ESP32 НЕ слышит собственные передачи (аппаратное).
  Всё, что шлёт нетбук, ловится promiscuous'ом; ответы нашего AP видны
  косвенно: события [EVT] (STA CONNECTED/DISCONNECTED + reason) и реакция
  нетбука (продвинулся ли он к следующему шагу, ставит ли retry).

  СЕРИЙНЫЙ ПОРТ 115200 8N1:
    - текстовый режим (по умолчанию): читаемый дамп;
    - `pcap 1`: бинарный поток кадров -> serial_capture.py pcap -> dump.pcap
      -> открыть в Wireshark.

  СБОРКА: Arduino IDE (плата "ESP32 Dev Module") или PlatformIO
  (platformio.ini лежит рядом). Схема не нужна — питание только по USB.
  ============================================================================
*/

#include <Arduino.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_event.h>
#include <esp_netif.h>
#include <esp_timer.h>
#include <esp_log.h>
#include <string.h>
#include <ctype.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>

/* ----------------------------- настройка ------------------------------- */
#define FW_VERSION      "1.0"
#define SNIFF_BAUD      115200   /* не менять: лог ESP-IDF тоже идёт на 115200 */
#define AP_SSID_DEF     "HomeWifi" /* SSID, который увидит нетбук            */
#define AP_PASS_DEF     ""         /* "" = открытая сеть; >=8 симв. = WPA2-PSK */
#define AP_CH_DEF       6          /* канал AP (1..13)                        */
#define CAP_MAX         384        /* сколько байт кадра сохраняем            */
#define QUEUE_LEN       24         /* глубина очереди кадров RX               */
#define RING_LEN        32         /* строк истории для команды dump          */
#define RING_LINE       150
#define MAX_TRACKED     8          /* MAC-адресов в фильтре                   */
#define LEARN_MS        30000      /* окно команды `learn`                    */
#define DATA_PRINT_MAX  30         /* подробный print data-кадров, кадр/сек   */
#define STAT_PERIOD_MS  5000
#define AP_FIX_RATE     0          /* 1 = форсировать unicast AP->STA в 1 Мбит/с
                                        (эксперимент, если нетбук не слышит
                                        ответы AP; включать только при
                                        необходимости, см. README)             */

#if AP_FIX_RATE
  #if defined(__has_include)
    #if __has_include(<esp_wifi_internal.h>)
      #include <esp_wifi_internal.h>
      #define HAVE_FIX_RATE 1
    #endif
  #endif
#endif

/* ------------------------------- типы ---------------------------------- */
enum RunMode : uint8_t { MODE_AP, MODE_SNIFF };

struct CapFrame {
  int64_t  ts_us;      /* esp_timer_get_time() на момент RX            */
  uint16_t len;        /* сколько байт записано (<= CAP_MAX)           */
  uint16_t orig_len;   /* длина кадра на проводе (rx_ctrl.sig_len)     */
  uint8_t  ptype;      /* wifi_promiscuous_pkt_type_t                  */
  int8_t   rssi;
  uint8_t  rate;       /* wifi_phy_rate_t (индекс)                     */
  uint8_t  sig_mode;   /* 0=legacy(b/g), 1=HT(11n), 2=VHT              */
  uint8_t  mcs;
  uint8_t  channel;
  uint8_t  data[CAP_MAX];
};

struct Counters {
  uint32_t mgmt, ctrl, data, misc;
  uint32_t foreign, beacon_drop, rssi_drop, qdrop, shown, suppressed;
};

/* ------------------------------ глобальные ----------------------------- */
static QueueHandle_t capQueue = nullptr;
static RunMode  runMode   = MODE_AP;
static volatile bool pcapOn  = false;
static volatile bool paused  = false;
static bool foreignOn   = false;  /* печатать кадры "чужих" станций        */
static bool beaconsOn   = false;  /* печатать beacon'и                     */
static uint8_t hexMode  = 1;      /* 0=нет, 1=только mgmt, 2=все           */
static int    rssiMin   = -128;   /* фильтр по RSSI (-128 = выключен)      */
static uint32_t learnUntil = 0;   /* до этого millis() печатать ВСЁ        */
static char   curSsid[33] = AP_SSID_DEF;
static char   curPass[65] = AP_PASS_DEF;
static int    curCh       = AP_CH_DEF;
static uint8_t apMac[6]     = {0};
static uint8_t tracked[MAX_TRACKED][6];      /* фильтр MAC (пустые = FF)   */
static Counters cnt;
static uint32_t frameNo  = 0;
static uint16_t pcapSeq  = 0;
static char   ring[RING_LEN][RING_LINE];
static int    ringPos    = 0, ringCount = 0;
static uint32_t dataSecMark = 0, dataSecCount = 0, statMark = 0;

/* ---------------------------- прототипы -------------------------------- */
void setup();
void loop();
void snifferCb(void* buf, wifi_promiscuous_pkt_type_t type);
void wifiEventHandler(void* arg, esp_event_base_t base, int32_t id, void* data);
void registerPromisc();
void startApMode(const char* ssid, const char* pass, int ch);
void startSniffMode(int ch);
void processFrame(const CapFrame& f);
void emitPcap(const CapFrame& f);
bool frameRelevant(const uint8_t* a1, const uint8_t* a2, const uint8_t* a3,
                   int fcType, int sub, int8_t rssi);
void learnMac(const uint8_t* m);
bool macTracked(const uint8_t* m);
bool macEq(const uint8_t* a, const uint8_t* b);
bool parseMacStr(const char* s, uint8_t* m);
void macToStr(char* out, const uint8_t* m);
void fmtTs(char* b, size_t n, int64_t us);
void hexDump(const uint8_t* p, int n, const char* ind);
void walkIEs(const uint8_t* p, int len, const char* ind);
void printRSN(const uint8_t* v, int l, const char* ind);
void parseMgmt(const uint8_t* pl, int len, int sub);
void parseData(const uint8_t* pl, int len, uint16_t fc);
void parseEapol(const uint8_t* p, int n, bool toDS);
int  dataHeaderLen(uint16_t fc);
void capBitsStr(uint16_t cap, char* out, size_t n);
void ringPush(const char* line);
void printHelp();
void printInfo();
void printStat();
void printStas();
void cmdScan();
void handleSerial();
void runCommand(char* line);
const char* rateName(uint8_t r);
const char* pktTypeName(uint8_t t);
const char* mgmtSubName(int sub);
const char* ctrlSubName(int sub);
const char* dataSubName(int sub);
const char* reasonName(uint16_t r);
const char* statusName(uint16_t s);
const char* authAlgName(uint16_t a);
const char* cipherName(uint8_t t);
const char* akmName(uint8_t t);

/* ------------------------------ утилиты -------------------------------- */
static inline uint16_t le16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }

uint8_t crc8(const uint8_t* d, int n) {
  uint8_t c = 0;
  while (n--) {
    c ^= *d++;
    for (int i = 0; i < 8; i++) c = (c & 1) ? (uint8_t)((c >> 1) ^ 0x8C) : (uint8_t)(c >> 1);
  }
  return c;
}

void fmtTs(char* b, size_t n, int64_t us) {
  uint32_t tot = (uint32_t)(us / 1000ULL);      /* мс с загрузки           */
  uint32_t hh = tot / 3600000U; tot %= 3600000U;
  uint32_t mm = tot / 60000U;   tot %= 60000U;
  uint32_t ss = tot / 1000U;
  uint32_t frac = (uint32_t)(us % 1000000ULL);
  snprintf(b, n, "T+%02u:%02u:%02u.%06u",
           (unsigned)hh, (unsigned)mm, (unsigned)ss, (unsigned)frac);
}

bool macEq(const uint8_t* a, const uint8_t* b) {
  return a[0]==b[0] && a[1]==b[1] && a[2]==b[2] && a[3]==b[3] && a[4]==b[4] && a[5]==b[5];
}

bool macIsMcast(const uint8_t* m) { return (m[0] & 1) != 0; }

void macToStr(char* out, const uint8_t* m) {
  snprintf(out, 18, "%02x:%02x:%02x:%02x:%02x:%02x",
           m[0], m[1], m[2], m[3], m[4], m[5]);
}

bool parseMacStr(const char* s, uint8_t* m) {
  unsigned v[6];
  if (sscanf(s, "%x:%x:%x:%x:%x:%x", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5]) != 6)
    return false;
  for (int i = 0; i < 6; i++) {
    if (v[i] > 0xFF) return false;
    m[i] = (uint8_t)v[i];
  }
  return true;
}

const char* rateName(uint8_t r) {
  static const char* tbl[32] = {
    "1M", "2M", "5.5M", "11M", "1M(S)", "2M(S)", "5.5M(S)", "11M(S)",
    "48M", "24M", "12M", "6M", "54M", "36M", "18M", "9M",
    "MCS0", "MCS1", "MCS2", "MCS3", "MCS4", "MCS5", "MCS6", "MCS7",
    "MCS8", "MCS9", "MCS10", "MCS11", "MCS12", "MCS13", "MCS14", "MCS15"
  };
  return (r < 32) ? tbl[r] : "rate?";
}

const char* pktTypeName(uint8_t t) {
  switch (t) {                       /* wifi_promiscuous_pkt_type_t */
    case 0:  return "MGMT";
    case 1:  return "CTRL";
    case 2:  return "DATA";
    default: return "MISC";
  }
}

const char* mgmtSubName(int sub) {   /* sub = (fc>>4)&0xF, type=0 */
  switch (sub) {
    case 0x0: return "ASSOC_REQ";
    case 0x1: return "ASSOC_RESP";
    case 0x2: return "REASSOC_REQ";
    case 0x3: return "REASSOC_RESP";
    case 0x4: return "PROBE_REQ";
    case 0x5: return "PROBE_RESP";
    case 0x8: return "BEACON";
    case 0x9: return "ATIM";
    case 0xA: return "DISASSOC";
    case 0xB: return "AUTH";
    case 0xC: return "DEAUTH";
    case 0xD: return "ACTION";
    case 0xE: return "ACTION_NOACK";
    default:  return "MGMT?";
  }
}

const char* ctrlSubName(int sub) {   /* sub = (fc>>4)&0xF, type=1 */
  switch (sub) {
    case 0x8: return "BLOCK_ACK_REQ";
    case 0x9: return "BLOCK_ACK";
    case 0xA: return "PS_POLL";
    case 0xB: return "RTS";
    case 0xC: return "CTS";
    case 0xD: return "ACK";
    case 0xE: return "CF_END";
    case 0xF: return "CF_END_ACK";
    default:  return "CTRL?";
  }
}

const char* dataSubName(int sub) {   /* sub = (fc>>4)&0xF, type=2 */
  switch (sub) {
    case 0x0: return "DATA";
    case 0x4: return "NULL";
    case 0x8: return "QOS_DATA";
    case 0xC: return "QOS_NULL";
    default:  return "DATA?";
  }
}

const char* reasonName(uint16_t r) {
  switch (r) {
    case 1:  return "UNSPECIFIED";
    case 2:  return "AUTH_EXPIRE";
    case 3:  return "AUTH_LEAVE";
    case 4:  return "ASSOC_EXPIRE";
    case 5:  return "ASSOC_TOOMANY";
    case 6:  return "NOT_AUTHED";
    case 7:  return "NOT_ASSOCED";
    case 8:  return "ASSOC_LEAVE";
    case 9:  return "ASSOC_NOT_AUTHED";
    case 10: return "DISASSOC_PWRCAP_BAD";
    case 11: return "DISASSOC_SUPCHAN_BAD";
    case 13: return "IE_INVALID";
    case 14: return "MIC_FAILURE";
    case 15: return "4WAY_HANDSHAKE_TIMEOUT";  /* ключи не сошлись */
    case 16: return "GROUP_KEY_UPDATE_TIMEOUT";
    case 17: return "IE_IN_4WAY_DIFFERS";
    case 18: return "GROUP_CIPHER_INVALID";
    case 19: return "PAIRWISE_CIPHER_INVALID";
    case 20: return "AKMP_INVALID";
    case 21: return "UNSUPPORTED_RSN_IE_VERSION";
    case 22: return "INVALID_RSN_IE_CAP";
    case 23: return "802_1X_AUTH_FAILED";
    case 24: return "CIPHER_SUITE_REJECTED";
    case 34: return "DISASSOC_LOW_AP_FRAMEWORK"; /* в пути... 2007 set */
    case 200: return "BEACON_TIMEOUT(ESP)";
    case 201: return "NO_AP_FOUND(ESP)";
    case 202: return "AUTH_FAIL(ESP)";
    case 203: return "ASSOC_FAIL(ESP)";
    case 204: return "HANDSHAKE_TIMEOUT(ESP)";
    default: return "REASON?";
  }
}

const char* statusName(uint16_t s) {
  switch (s) {
    case 0:  return "SUCCESS";
    case 1:  return "UNSPEC_FAILURE";
    case 10: return "CAPS_UNSUPPORTED";
    case 11: return "REASSOC_DENIED";
    case 12: return "ASSOC_DENIED_UNSPEC";
    case 13: return "ASSOC_DENIED_AP_OVERLOAD";
    case 14: return "ASSOC_DENIED_BAD_RATES";
    case 15: return "ASSOC_DENIED_TEMPORARY";
    case 16: return "ASSOC_DENIED_NO_SHORT_PREAMBLE";
    case 17: return "ASSOC_DENIED_NO_PBCC";
    case 18: return "ASSOC_DENIED_NO_CH_AGILITY";
    case 19: return "ASSOC_DENIED_SPECTRUM_MGMT";
    case 25: return "ASSOC_DENIED_CANNOT_START_CF";
    case 28: return "ASSOC_DENIED_INVALID_IE";
    default: return "STATUS?";
  }
}

const char* authAlgName(uint16_t a) {
  switch (a) {
    case 0: return "OPEN";
    case 1: return "SHARED_KEY";
    case 2: return "FT";
    case 3: return "SAE";
    default: return "ALG?";
  }
}

const char* cipherName(uint8_t t) {  /* младший байт suite 00-0F-AC:x */
  switch (t) {
    case 0: return "NONE/GROUP";
    case 1: return "WEP-40";
    case 2: return "TKIP";
    case 4: return "CCMP-128";
    case 5: return "WEP-104";
    case 6: return "BIP-CMAC-128";
    case 8: return "GCMP-128";
    default: return "CIPH?";
  }
}

const char* akmName(uint8_t t) {
  switch (t) {
    case 1: return "802.1X";
    case 2: return "PSK";
    case 3: return "FT-802.1X";
    case 4: return "FT-PSK";
    case 5: return "802.1X-SHA256";
    case 6: return "PSK-SHA256";
    case 8: return "SAE";
    default: return "AKM?";
  }
}

void capBitsStr(uint16_t cap, char* out, size_t n) {
  out[0] = 0;
  if (cap & 0x0001) strlcat(out, "ESS ", n);
  if (cap & 0x0002) strlcat(out, "IBSS ", n);
  if (cap & 0x0010) strlcat(out, "PRIVACY ", n);
  if (cap & 0x0020) strlcat(out, "SHORT_PREAMBLE ", n);
  if (cap & 0x0040) strlcat(out, "PBCC ", n);
  if (cap & 0x0080) strlcat(out, "CH_AGILITY ", n);
  if (cap & 0x0400) strlcat(out, "SHORT_SLOT ", n);
  if (cap & 0x2000) strlcat(out, "DSSS_OFDM ", n);
  size_t l = strlen(out);
  if (l) out[l-1] = 0;
}

/* ------------------- фильтр релевантности + MAC-трекинг ----------------- */
bool macTracked(const uint8_t* m) {
  for (int i = 0; i < MAX_TRACKED; i++)
    if (macEq(tracked[i], m)) return true;
  return false;
}

void learnMac(const uint8_t* m) {
  if (macIsMcast(m) || !(m[0]|m[1]|m[2]|m[3]|m[4]|m[5])) return;
  if (macTracked(m)) return;
  for (int i = 0; i < MAX_TRACKED; i++) {
    if (!(tracked[i][0]|tracked[i][1]|tracked[i][2]|tracked[i][3]|tracked[i][4]|tracked[i][5])) {
      memcpy(tracked[i], m, 6);
      char s[18]; macToStr(s, m);
      Serial.printf("[learn] слежу за MAC %s\n", s);
      return;
    }
  }
}

bool frameRelevant(const uint8_t* a1, const uint8_t* a2, const uint8_t* a3,
                   int fcType, int sub, int8_t rssi) {
  if (rssiMin > -128 && rssi < rssiMin) { cnt.rssi_drop++; return false; }
  if (learnUntil && millis() < learnUntil) return true;   /* окно "показать всё" */
  if (macTracked(a1) || macTracked(a2) || macTracked(a3)) return true;
  if (macEq(a1, apMac) || macEq(a2, apMac) || macEq(a3, apMac)) return true;
  bool bcast = macIsMcast(a1);
  if (fcType == 0) {
    if (sub == 8 && !beaconsOn) { cnt.beacon_drop++; return false; }
    if (bcast) return true;          /* probe req, deauth и пр. — показываем */
  }
  cnt.foreign++;
  return foreignOn;
}

/* --------------------------- разбор кадров ------------------------------ */
void hexDump(const uint8_t* p, int n, const char* ind) {
  for (int i = 0; i < n; i += 16) {
    Serial.printf("%s%04x: ", ind, i);
    for (int j = 0; j < 16; j++) {
      if (i + j < n) Serial.printf("%02x ", p[i + j]);
      else           Serial.print("   ");
      if (j == 7) Serial.print(" ");
    }
    Serial.print(" |");
    for (int j = 0; j < 16 && i + j < n; j++) {
      char c = (char)p[i + j];
      Serial.print((c >= 32 && c < 127) ? c : '.');
    }
    Serial.println("|");
  }
}

void printRSN(const uint8_t* v, int l, const char* ind) {
  if (l < 2) return;
  Serial.printf("%sIE 48 RSN: v=%u", ind, le16(v));
  int off = 2;
  if (l >= off + 4) {
    Serial.printf(" grp=%s", cipherName(v[off + 3]));
    off += 4;
  }
  if (l >= off + 2) {
    int n = le16(v + off); off += 2;
    Serial.printf(" prw[");
    for (int i = 0; i < n && off + 4 <= l && i < 4; i++, off += 4)
      Serial.printf("%s%s", i ? "," : "", cipherName(v[off + 3]));
    Serial.printf("](%d)", n);
  }
  if (l >= off + 2) {
    int n = le16(v + off); off += 2;
    Serial.printf(" akm[");
    for (int i = 0; i < n && off + 4 <= l && i < 4; i++, off += 4)
      Serial.printf("%s%s", i ? "," : "", akmName(v[off + 3]));
    Serial.printf("](%d)", n);
  }
  if (l >= off + 2) Serial.printf(" caps=0x%04x", le16(v + off));
  Serial.printf(" raw[%d]:", l);
  for (int i = 0; i < l && i < 40; i++) Serial.printf("%02x", v[i]);
  Serial.println();
}

void walkIEs(const uint8_t* p, int len, const char* ind) {
  int off = 0;
  while (off + 2 <= len) {
    uint8_t id = p[off], l = p[off + 1];
    if (off + 2 + l > len) {
      Serial.printf("%sIE %u len=%u ОБОРВАН (мусор в конце кадра!)\n", ind, id, l);
      return;
    }
    const uint8_t* v = p + off + 2;
    switch (id) {
      case 0: { /* SSID */
        if (l == 0) { Serial.printf("%sIE 0 SSID: <wildcard>\n", ind); break; }
        bool printable = true;
        for (int i = 0; i < l; i++) if (v[i] < 32 || v[i] > 126) printable = false;
        char ss[33]; int n = (l < 32) ? l : 32;
        memcpy(ss, v, n); ss[n] = 0;
        if (printable) Serial.printf("%sIE 0 SSID: \"%s\" (len=%u)\n", ind, ss, l);
        else           Serial.printf("%sIE 0 SSID: len=%u (непечатаемый)\n", ind, l);
        break;
      }
      case 1: case 50: {
        Serial.printf("%sIE %u %s:", ind, id, id == 1 ? "RATES" : "EXT_RATES");
        for (int i = 0; i < l; i++)
          Serial.printf(" %s%.1f", (v[i] & 0x80) ? "*" : "", (v[i] & 0x7F) * 0.5f);
        Serial.println();
        break;
      }
      case 3: Serial.printf("%sIE 3 DS_PARAM: ch=%u\n", ind, l >= 1 ? v[0] : 0); break;
      case 5: Serial.printf("%sIE 5 TIM: dtim_cnt=%u dtim_per=%u\n", ind,
                            l >= 1 ? v[0] : 0, l >= 2 ? v[1] : 0); break;
      case 7: if (l >= 5) Serial.printf("%sIE 7 COUNTRY: %.3s first_ch=%u n=%u\n",
                                        ind, (const char*)v, v[3], v[4]); break;
      case 16: Serial.printf("%sIE 16 CHALLENGE: len=%u\n", ind, l); break;
      case 45: Serial.printf("%sIE 45 HT_CAP: 0x%02x%02x ampdu_exp=%u\n", ind,
                             l >= 2 ? v[1] : 0, l >= 1 ? v[0] : 0,
                             l >= 3 ? (v[2] & 3) : 0); break;
      case 48: printRSN(v, l, ind); break;
      case 61: Serial.printf("%sIE 61 HT_OP: primary_ch=%u\n", ind,
                             l >= 1 ? v[0] : 0); break;
      case 127: Serial.printf("%sIE 127 EXT_CAP: len=%u\n", ind, l); break;
      case 191: Serial.printf("%sIE 191 VHT_CAP: len=%u\n", ind, l); break;
      case 192: Serial.printf("%sIE 192 VHT_OP: len=%u\n", ind, l); break;
      case 221: if (l >= 4) Serial.printf("%sIE 221 VENDOR: oui=%02x:%02x:%02x type=0x%02x len=%u\n",
                                          ind, v[0], v[1], v[2], v[3], l); break;
      default: Serial.printf("%sIE %u len=%u\n", ind, id, l);
    }
    off += 2 + l;
  }
}

int dataHeaderLen(uint16_t fc) {
  int h = 24;
  if ((fc >> 4) & 0x08) h += 2;   /* QoS-подтип: 2 байта QoS Control       */
  if (fc & 0x8000)      h += 4;   /* порядок: 4 байта HT Control           */
  return h;
}

/* EAPOL-KEY: классификация сообщений 4-way handshake (RSN/WPA2-PSK) */
void parseEapol(const uint8_t* p, int n, bool toDS) {
  if (n < 4) return;
  uint8_t ver = p[0], type = p[1];
  uint16_t elen = le16(p + 2);
  const char* dir = toDS ? "STA->AP" : "AP->STA";
  if (type == 1) { Serial.printf("    EAPOL: ver=%u EAPOL-START (%s) — станция просит 4-way\n", ver, dir); return; }
  if (type == 2) { Serial.printf("    EAPOL: ver=%u EAPOL-LOGOFF (%s)\n", ver, dir); return; }
  if (type != 3 || n < 8) {
    Serial.printf("    EAPOL: ver=%u type=%u len=%u (%s)\n", ver, type, elen, dir);
    return;
  }
  uint8_t  desc    = p[4];
  uint16_t keyInfo = le16(p + 5);
  uint16_t keyLen  = le16(p + 7);
  bool ktype = keyInfo & 0x0008;
  bool ack   = keyInfo & 0x0080;
  bool mic   = keyInfo & 0x0100;
  bool sec   = keyInfo & 0x0200;
  bool err   = keyInfo & 0x0400;
  bool req   = keyInfo & 0x0800;
  bool encr  = keyInfo & 0x1000;
  const char* msg = "?";
  if (ack && !mic && !sec)            msg = "M1 (AP->STA, ANonce)";
  else if (!ack && mic && !sec)       msg = "M2 (STA->AP, SNonce+MIC)";
  else if (ack && mic && sec)         msg = "M3 (AP->STA, GTK)";
  else if (!ack && mic)               msg = "M4 (STA->AP, MIC)";
  Serial.printf("    EAPOL-KEY %s: desc=%s(%u) info=0x%04x [ver=%u %s ACK=%d MIC=%d SEC=%d ERR=%d REQ=%d ENC=%d] keylen=%u => %s\n",
                dir, desc == 2 ? "RSN" : desc == 1 ? "WPA" : "?", desc, keyInfo,
                keyInfo & 7, ktype ? "PTK" : "GTK", ack, mic, sec, err, req, encr,
                keyLen, msg);
  if (n >= 25) { /* replay counter (9..16) + nonce (17..48) */
    Serial.printf("      replay="); for (int i = 9; i < 17; i++) Serial.printf("%02x", p[i]);
    Serial.printf(" nonce[0..7]="); for (int i = 17; i < 25; i++) Serial.printf("%02x", p[i]);
    Serial.printf("...\n");
  }
}

void parseData(const uint8_t* pl, int len, uint16_t fc) {
  int sub = (fc >> 4) & 0xF;
  bool toDS = fc & 0x0100, fromDS = fc & 0x0200;
  bool qos = (sub & 0x08) != 0;
  bool prot = (fc & 0x4000) != 0;
  if (sub == 4 || sub == 5 || sub == 6 || sub == 0xC || sub == 0xD || sub == 0xE) {
    Serial.printf("    NULL/CF-кадр (тела нет)\n");
    return;
  }
  int h = dataHeaderLen(fc);
  if (qos && len >= h - 2 + 2) {
    uint16_t qc = le16(pl + h - 2);
    Serial.printf("    DATA: toDS=%d fromDS=%d qos_tid=%u%s len=%d\n",
                  toDS, fromDS, qc & 0xF, prot ? " PROTECTED" : "", len - h);
  } else {
    Serial.printf("    DATA: toDS=%d fromDS=%d%s len=%d\n",
                  toDS, fromDS, prot ? " PROTECTED" : "", len - h);
  }
  if (len <= h) return;
  const uint8_t* d = pl + h;
  int dl = len - h;
  if (dl >= 8 && d[0] == 0xAA && d[1] == 0xAA && d[2] == 0x03) {
    uint16_t et = (uint16_t)((d[6] << 8) | d[7]);
    if (et == 0x888E)      { Serial.printf("    LLC/SNAP: ethertype=0x888E EAPOL\n"); parseEapol(d + 8, dl - 8, toDS); }
    else if (et == 0x0800) Serial.printf("    LLC/SNAP: ethertype=0x0800 IPv4\n");
    else if (et == 0x0806) Serial.printf("    LLC/SNAP: ethertype=0x0806 ARP\n");
    else if (et == 0x86DD) Serial.printf("    LLC/SNAP: ethertype=0x86DD IPv6\n");
    else                   Serial.printf("    LLC/SNAP: ethertype=0x%04x\n", et);
  } else if (prot) {
    Serial.printf("    payload ЗАШИФРОВАН (%d байт) — норма после 4-way\n", dl);
  } else {
    Serial.printf("    payload без LLC/SNAP (%d байт)\n", dl);
  }
}

void parseMgmt(const uint8_t* pl, int len, int sub) {
  /* тело mgmt начинается с offset 24 */
  switch (sub) {
    case 0xB: { /* AUTH */
      if (len < 30) { Serial.printf("    AUTH: короткий (%d б)!\n", len); return; }
      uint16_t alg = le16(pl + 24), txn = le16(pl + 26), st = le16(pl + 28);
      Serial.printf("    AUTH: alg=%s(%u) txn=%u status=%s(%u)%s\n",
                    authAlgName(alg), alg, txn, statusName(st), st,
                    (txn == 1) ? " <- ЗАПРОС станции" : (txn == 2) ? " <- ОТВЕТ AP" : "");
      if (len > 30 && txn == 2) walkIEs(pl + 30, len - 30, "    ");
      break;
    }
    case 0x0: case 0x2: { /* ASSOC_REQ / REASSOC_REQ */
      if (len < 28) { Serial.printf("    ASSOC_REQ: короткий (%d б)!\n", len); return; }
      uint16_t cap = le16(pl + 24), li = le16(pl + 26);
      char cb[96]; capBitsStr(cap, cb, sizeof(cb));
      Serial.printf("    ASSOC_REQ: cap=0x%04x [%s] listen_int=%u\n", cap, cb, li);
      int ieOff = (sub == 0x0) ? 28 : 34;
      if (len > ieOff) walkIEs(pl + ieOff, len - ieOff, "    ");
      break;
    }
    case 0x1: case 0x3: { /* ASSOC_RESP / REASSOC_RESP */
      if (len < 30) { Serial.printf("    ASSOC_RESP: короткий (%d б)!\n", len); return; }
      uint16_t cap = le16(pl + 24), st = le16(pl + 26), aid = le16(pl + 28) & 0x3FFF;
      Serial.printf("    ASSOC_RESP: status=%s(%u) aid=%u cap=0x%04x\n",
                    statusName(st), st, aid, cap);
      if (len > 30) walkIEs(pl + 30, len - 30, "    ");
      break;
    }
    case 0xA: { /* DISASSOC */
      if (len >= 26) Serial.printf("    DISASSOC: reason=%u (%s)\n",
                                   le16(pl + 24), reasonName(le16(pl + 24)));
      break;
    }
    case 0xC: { /* DEAUTH */
      if (len >= 26) Serial.printf("    DEAUTH: reason=%u (%s)\n",
                                   le16(pl + 24), reasonName(le16(pl + 24)));
      break;
    }
    case 0x4: { /* PROBE_REQ */
      if (len > 24) walkIEs(pl + 24, len - 24, "    ");
      break;
    }
    case 0x8: case 0x5: { /* BEACON / PROBE_RESP */
      if (len < 36) { Serial.printf("    BEACON: короткий (%d б)!\n", len); return; }
      uint16_t bi = le16(pl + 32), cap = le16(pl + 34);
      char cb[96]; capBitsStr(cap, cb, sizeof(cb));
      Serial.printf("    %s: interval=%u TU cap=0x%04x [%s]\n",
                    sub == 8 ? "BEACON" : "PROBE_RESP", bi, cap, cb);
      if (len > 36) walkIEs(pl + 36, len - 36, "    ");
      break;
    }
    case 0xD: { /* ACTION */
      if (len >= 25) {
        Serial.printf("    ACTION: category=%u\n", pl[24]);
        if (len > 25) { Serial.printf("      body:"); for (int i = 25; i < len && i < 25 + 16; i++) Serial.printf(" %02x", pl[i]); Serial.println(); }
      }
      break;
    }
    default: break;
  }
}

/* ------------------------------- RX-путь -------------------------------- */
void snifferCb(void* buf, wifi_promiscuous_pkt_type_t type) {
  wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
  const wifi_pkt_rx_ctrl_t& rx = pkt->rx_ctrl;
  uint16_t orig = rx.sig_len;
  uint16_t len = orig;
  if (len > CAP_MAX) len = CAP_MAX;
  if (len < 2) return;
  CapFrame f;
  f.ts_us    = esp_timer_get_time();
  f.len      = len;
  f.orig_len = orig;
  f.ptype    = (uint8_t)type;
  f.rssi     = (int8_t)rx.rssi;
  f.rate     = rx.rate;
  f.sig_mode = rx.signal_mode;
  f.mcs      = rx.mcs;
  f.channel  = rx.channel;
  memcpy(f.data, pkt->payload, len);
  if (xQueueSend(capQueue, &f, 0) != pdTRUE) cnt.qdrop++;
}

void processFrame(const CapFrame& f) {
  if (f.len < 2) return;
  const uint8_t* pl = f.data;
  uint16_t fc = (uint16_t)(pl[0] | (pl[1] << 8));
  int fcType = (fc >> 2) & 3;
  int sub    = (fc >> 4) & 0xF;
  const uint8_t *a1 = pl + 4, *a2 = pl + 10, *a3 = pl + 16;
  bool toDS = fc & 0x0100, fromDS = fc & 0x0200;
  bool retry = fc & 0x0800, prot = fc & 0x4000;
  uint16_t sc = (f.len >= 24) ? (uint16_t)(pl[22] | (pl[23] << 8)) : 0;
  uint16_t seq  = (sc >> 4) & 0x0FFF;
  uint16_t frag = sc & 0xF;
  uint16_t dur  = (f.len >= 4) ? le16(pl + 2) : 0;

  /* счётчики по типу кадра (по фильтру promiscuous, до релевантности) */
  if (f.ptype == 0) cnt.mgmt++;
  else if (f.ptype == 1) cnt.ctrl++;
  else if (f.ptype == 2) cnt.data++;
  else cnt.misc++;

  if (paused) return;

  if (!frameRelevant(a1, a2, a3, fcType, sub, f.rssi)) return;

  /* бинарный pcap-поток: без текста */
  if (pcapOn) { emitPcap(f); cnt.shown++; return; }

  /* data-шторм не должен завалить UART; EAPOL печатаем всегда */
  if (fcType == 2) {
    uint32_t now = millis();
    if (now - dataSecMark >= 1000) { dataSecMark = now; dataSecCount = 0; }
    dataSecCount++;
    int h = dataHeaderLen(fc);
    bool isEapol = (f.len > h + 8 && pl[h] == 0xAA && pl[h+1] == 0xAA &&
                    pl[h+2] == 0x03 && pl[h+6] == 0x88 && pl[h+7] == 0x8E);
    if (!isEapol && dataSecCount > DATA_PRINT_MAX) { cnt.suppressed++; return; }
  }

  /* авто-трекинг: mgmt станции, адресованной нашему AP */
  if (fcType == 0 && !macIsMcast(a2) &&
      (macEq(a3, apMac) || macEq(a1, apMac)))
    learnMac(a2);

  cnt.shown++;
  char ts[32]; fmtTs(ts, sizeof(ts), f.ts_us);
  const char* tname = pktTypeName(f.ptype);
  const char* sname = (fcType == 0) ? mgmtSubName(sub) :
                      (fcType == 1) ? ctrlSubName(sub) : dataSubName(sub);

  Serial.printf("[%s] #%u %s %s len=%u rssi=%d rate=%s%s ch=%u\n",
                ts, (unsigned)frameNo, tname, sname, f.orig_len,
                (int)f.rssi, rateName(f.rate),
                (f.sig_mode == 1) ? "(HT)" : "", f.channel);

  char s1[18], s2[18], s3[18];
  macToStr(s1, a1); macToStr(s2, a2); macToStr(s3, a3);
  const char* r13 = (fcType == 0) ? "DA " : (fcType == 2 && toDS) ? "BSS" : "DA ";
  const char* r23 = (fcType == 0) ? "SA " : (fcType == 2 && toDS) ? "SA " : "BSS";
  const char* r33 = (fcType == 0) ? "BSS" : (fcType == 2 && toDS) ? "DA " : "SA ";
  Serial.printf("    A1(%s)=%s A2(%s)=%s A3(%s)=%s\n", r13, s1, r23, s2, r33, s3);

  char fl[80]; fl[0] = 0;
  if (toDS)   strlcat(fl, "toDS ", sizeof(fl));
  if (fromDS) strlcat(fl, "fromDS ", sizeof(fl));
  if (fc & 0x0400) strlcat(fl, "MORE_FRAG ", sizeof(fl));
  if (retry)  strlcat(fl, "RETRY ", sizeof(fl));
  if (fc & 0x1000) strlcat(fl, "PWR_MGMT ", sizeof(fl));
  if (prot)   strlcat(fl, "PROTECTED ", sizeof(fl));
  if (fc & 0x8000) strlcat(fl, "ORDER ", sizeof(fl));
  size_t l = strlen(fl); if (l) fl[l-1] = 0;

  Serial.printf("    FC=0x%04x %s%s dur=%u SC=0x%04x seq=%u frag=%u%s\n",
                fc, fl[0] ? "[" : "", fl, dur, sc, seq, frag,
                retry ? "  <<== ПОВТОР: ответ не получен/не ACK-нут!" : "");

  /* ГЛАВНАЯ ПРОВЕРКА W-SEQ3: frag должен быть всегда 0, seq +1 с каждым
     новым кадром. frag!=0 или seq=0 при активной передаче => раскладка SC
     в передатчике нетбука по-прежнему неверна (байт22/байт23).           */
  if (fcType == 0 && frag != 0)
    Serial.printf("    !!! frag=%u при mgmt-кадре — БАГ РАСКЛАДКИ SC (W-SEQ2/3) !!!\n", frag);

  switch (fcType) {
    case 0: parseMgmt(pl, f.len, sub); break;
    case 2: parseData(pl, f.len, fc);  break;
    case 1: if (sub == 0xB || sub == 0xC) {  /* RTS/CTS: длительность */
              if (f.len >= 6) Serial.printf("    %s: dur=%u RA=%02x:%02x:%02x:%02x:%02x:%02x\n",
                                            sub == 0xB ? "RTS" : "CTS", le16(pl + 2),
                                            pl[4], pl[5], pl[6], pl[7], pl[8], pl[9]);
            } break;
    default: break;
  }

  if (hexMode == 2 || (hexMode == 1 && fcType == 0)) {
    Serial.printf("    HEX[%u%s]:\n", f.len,
                  f.orig_len > f.len ? ", кадр обрезан" : " байт");
    hexDump(pl, f.len, "      ");
  }

  /* строка в кольцо истории */
  char line[RING_LINE];
  snprintf(line, sizeof(line), "[%s] #%u %s %s A2=%s seq=%u frag=%u rssi=%d%s",
           ts, (unsigned)frameNo, tname, sname, s2, seq, frag, (int)f.rssi,
           retry ? " RETRY" : "");
  ringPush(line);
}

/* ---------------------- бинарный pcap-поток ----------------------------
   Формат посылки: AA 55 | len:u16le | seq:u16le | meta:16B | payload | crc8
   len  = 18 + caplen  (seq + meta + payload, БЕЗ заголовка и CRC)
   meta: ts_us:u64le, rssi:i8, rate:u8, sig_mode:u8, ch:u8,
         orig_len:u16le, caplen:u16le
   crc8 — по seq+meta+payload (poly 0x07, отражённый 0x8C, init 0).
   serial_capture.py (режим pcap) разбирает это в dump.pcap для Wireshark. */
void emitPcap(const CapFrame& f) {
  static uint8_t out[8 + 2 + 16 + CAP_MAX];
  uint16_t caplen = f.len;
  uint16_t plen = (uint16_t)(18 + caplen);
  out[0] = 0xAA; out[1] = 0x55;
  out[2] = (uint8_t)(plen & 0xFF); out[3] = (uint8_t)(plen >> 8);
  out[4] = (uint8_t)(pcapSeq & 0xFF); out[5] = (uint8_t)((pcapSeq >> 8) & 0xFF);
  pcapSeq++;
  uint8_t* m = out + 6;
  for (int i = 0; i < 8; i++) m[i] = (uint8_t)(((uint64_t)f.ts_us) >> (8 * i));
  m[8]  = (uint8_t)f.rssi;
  m[9]  = f.rate;
  m[10] = f.sig_mode;
  m[11] = f.channel;
  m[12] = (uint8_t)(f.orig_len & 0xFF); m[13] = (uint8_t)(f.orig_len >> 8);
  m[14] = (uint8_t)(caplen & 0xFF);     m[15] = (uint8_t)(caplen >> 8);
  memcpy(out + 22, f.data, caplen);
  out[22 + caplen] = crc8(out + 4, plen);
  Serial.write(out, 23 + caplen);
}

/* --------------------------- фикс скорости TX --------------------------- */
void applyFixRateFor(const uint8_t* mac) {
#if defined(HAVE_FIX_RATE)
  esp_err_t err = esp_wifi_internal_set_fix_rate(WIFI_IF_AP, (uint8_t*)mac, WIFI_PHY_RATE_1M_L);
  char s[18]; macToStr(s, mac);
  Serial.printf("[EVT] fix-rate AP->%s = 1M: %s\n", s, err == ESP_OK ? "OK" : "ошибка");
#else
  (void)mac;
#endif
}

/* ------------------------------ события --------------------------------- */
void wifiEventHandler(void* arg, esp_event_base_t base, int32_t id, void* data) {
  (void)arg;
  if (base == IP_EVENT) {
    if (id == IP_EVENT_AP_STAIPASSIGNED) {
      ip_event_ap_staipassigned_t* e = (ip_event_ap_staipassigned_t*)data;
      char buf[16];
      esp_ip4addr_ntoa(&e->ip, buf, sizeof(buf));
      Serial.printf("[EVT] DHCP: станции назначен IP %s\n", buf);
    }
    return;
  }
  if (base != WIFI_EVENT) return;
  switch (id) {
    case WIFI_EVENT_AP_START:
      Serial.printf("[EVT] *** AP ЗАПУЩЕН: ssid=\"%s\" ch=%d ***\n", curSsid, curCh);
      break;
    case WIFI_EVENT_AP_STOP:
      Serial.println("[EVT] AP остановлен");
      break;
    case WIFI_EVENT_AP_STACONNECTED: {
      wifi_event_ap_staconnected_t* e = (wifi_event_ap_staconnected_t*)data;
      char s[18]; macToStr(s, e->mac);
      Serial.printf("[EVT] *** СТАНЦИЯ ПОДКЛЮЧИЛАСЬ: %s aid=%u (AUTH+ASSOC пройдены) ***\n", s, e->aid);
      learnMac(e->mac);
      applyFixRateFor(e->mac);
      break;
    }
    case WIFI_EVENT_AP_STADISCONNECTED: {
      wifi_event_ap_stadisconnected_t* e = (wifi_event_ap_stadisconnected_t*)data;
      char s[18]; macToStr(s, e->mac);
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
      uint16_t reason = e->reason;
      Serial.printf("[EVT] *** СТАНЦИЯ ОТВАЛИЛАСЬ: %s aid=%u reason=%u (%s) ***\n",
                    s, e->aid, reason, reasonName(reason));
#else
      Serial.printf("[EVT] *** СТАНЦИЯ ОТВАЛИЛАСЬ: %s aid=%u (reason недоступен в этом ядре — смотри DEAUTH в сниффере) ***\n", s, e->aid);
#endif
      break;
    }
    case WIFI_EVENT_AP_PROBEREQRECVED: {
      wifi_event_ap_probe_req_rx_t* e = (wifi_event_ap_probe_req_rx_t*)data;
      char s[18]; macToStr(s, e->mac);
      Serial.printf("[EVT] probe req от %s rssi=%d\n", s, (int)e->rssi);
      learnMac(e->mac);
      break;
    }
    default: break;
  }
}

/* --------------------------- запуск режимов ----------------------------- */
void registerPromisc() {
  esp_wifi_set_promiscuous(false);
  wifi_promiscuous_filter_t flt;
  flt.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT |
                    WIFI_PROMIS_FILTER_MASK_DATA |
                    WIFI_PROMIS_FILTER_MASK_CTRL;
  esp_wifi_set_promiscuous_filter(&flt);
  esp_wifi_set_promiscuous_rx_cb(&snifferCb);
  esp_wifi_set_promiscuous(true);
}

void startApMode(const char* ssid, const char* pass, int ch) {
  esp_wifi_set_promiscuous(false);
  WiFi.persistent(false);
  WiFi.setAutoReconnect(false);
  runMode = MODE_AP;
  curCh = ch;
  strncpy(curSsid, ssid, sizeof(curSsid) - 1); curSsid[sizeof(curSsid) - 1] = 0;
  strncpy(curPass, pass, sizeof(curPass) - 1); curPass[sizeof(curPass) - 1] = 0;
  WiFi.mode(WIFI_AP);
  WiFi.softAP(curSsid, curPass[0] ? curPass : NULL, curCh, 0, 4);
  delay(120);
  parseMacStr(WiFi.softAPmacAddress().c_str(), apMac);
  esp_wifi_set_event_mask(WIFI_EVENT_MASK_NONE);
  registerPromisc();
  char s[18]; macToStr(s, apMac);
  Serial.printf("\n=== РЕЖИМ AP: ssid=\"%s\" %s ch=%d BSSID=%s ===\n",
                curSsid, curPass[0] ? "WPA2-PSK" : "OPEN", curCh, s);
  Serial.println("=== Жду кадры нетбука: probe req -> AUTH REQ -> ASSOC REQ -> EAPOL ===");
  Serial.println("=== Подключи ещё телефон: его диалог будет эталоном для сравнения ===");
}

void startSniffMode(int ch) {
  esp_wifi_set_promiscuous(false);
  WiFi.persistent(false);
  WiFi.setAutoReconnect(false);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, true);
  delay(100);
  curCh = ch;
  runMode = MODE_SNIFF;
  registerPromisc();
  esp_wifi_set_channel(curCh, WIFI_SECOND_CHAN_NONE);
  foreignOn = true; beaconsOn = true;
  Serial.printf("\n=== РЕЖИМ SNIFF: канал %d, promiscuous, показываю ВСЁ (foreign=1 beacons=1) ===\n", curCh);
  Serial.println("=== Отсечь соседей: `mac <BSSID роутера>` затем `f 0` ===");
  Serial.println("=== Здесь видно ОБЕ стороны: статусы AUTH RSP/ASSOC RESP роутера, его EAPOL M1/M3 ===");
}

/* ---------------------- история + справка/статус ------------------------ */
void ringPush(const char* line) {
  strncpy(ring[ringPos], line, RING_LINE - 1);
  ring[ringPos][RING_LINE - 1] = 0;
  ringPos = (ringPos + 1) % RING_LEN;
  if (ringCount < RING_LEN) ringCount++;
}

void printHelp() {
  Serial.println("---------- команды (Enter в конце) ----------");
  Serial.println("  help | info | stat | stas");
  Serial.println("  mode ap | mode sniff <ch>   - режимы");
  Serial.println("  ch <1..13>                  - канал");
  Serial.println("  ssid <имя> | sec open | sec wpa <пароль>");
  Serial.println("  f 0|1 (чужие)  b 0|1 (beacons)  hex 0|1|2  rssi <n|off>");
  Serial.println("  learn (30 c показывать всё)");
  Serial.println("  mac <aa:bb:..> | macs | mac clear");
  Serial.println("  pcap 0|1   - бинарный поток -> dump.pcap (Wireshark)");
  Serial.println("  scan | dump <n> | pause | resume | rst");
  Serial.println("---------------------------------------------");
}

void printInfo() {
  Serial.printf("=== esp32_wifi_sniffer v%s ===\n", FW_VERSION);
  Serial.printf("чип: %s rev%d ядер:%d %dМГц\n", ESP.getChipModel(),
                ESP.getChipRevision(), ESP.getChipCores(), ESP.getCpuFreqMHz());
  Serial.printf("MAC STA: %s\n", WiFi.macAddress().c_str());
  char s[18]; macToStr(s, apMac);
  Serial.printf("MAC AP:  %s\n", s);
  Serial.printf("режим: %s канал=%d ssid=\"%s\" %s\n",
                runMode == MODE_AP ? "AP" : "SNIFF", curCh, curSsid,
                curPass[0] ? "WPA2-PSK" : "OPEN");
  Serial.printf("фильтры: foreign=%d beacons=%d hex=%u rssi_min=%d pcap=%d paused=%d\n",
                foreignOn, beaconsOn, hexMode, rssiMin, (int)pcapOn, (int)paused);
}

void printStat() {
  Serial.printf("[stat] RX: mgmt=%u ctrl=%u data=%u misc=%u | показано=%u\n",
                cnt.mgmt, cnt.ctrl, cnt.data, cnt.misc, cnt.shown);
  Serial.printf("[stat] отсев: чужие=%u beacons=%u rssi=%u очередь=%u data-подавлено=%u\n",
                cnt.foreign, cnt.beacon_drop, cnt.rssi_drop, cnt.qdrop, cnt.suppressed);
}

void printStas() {
  if (runMode != MODE_AP) { Serial.println("[cmd] список станций — только в режиме AP"); return; }
  wifi_sta_list_t lst;
  if (esp_wifi_ap_get_sta_list(&lst) != ESP_OK) { Serial.println("[cmd] ошибка esp_wifi_ap_get_sta_list"); return; }
  Serial.printf("[cmd] ассоциировано станций: %d\n", lst.num);
  for (int i = 0; i < lst.num; i++) {
    char s[18]; macToStr(s, lst.sta[i].mac);
    Serial.printf("  %s rssi=%d\n", s, (int)lst.sta[i].rssi);
  }
}

void cmdScan() {
  Serial.println("[scan] сканирую ~2 c (сниффер временно приостановлен)...");
  esp_wifi_set_promiscuous(false);
  WiFi.enableSTA(true);
  delay(50);
  int n = WiFi.scanNetworks(false, true);
  if (n <= 0) {
    Serial.println("[scan] сетей не найдено");
  } else {
    Serial.printf("[scan] найдено %d сетей (0 = открытая):\n", n);
    for (int i = 0; i < n; i++) {
      String ssid = WiFi.SSID(i);
      Serial.printf("  %2d) ch=%2d rssi=%3d auth=%u \"%s\"\n",
                    i + 1, WiFi.channel(i), (int)WiFi.RSSI(i),
                    WiFi.encryptionType(i), ssid.c_str());
    }
  }
  WiFi.scanDelete();
  registerPromisc();
  if (runMode == MODE_SNIFF) esp_wifi_set_channel(curCh, WIFI_SECOND_CHAN_NONE);
  Serial.println("[scan] готово, сниффер снова активен");
}

/* ------------------------------ команды --------------------------------- */
bool ciEq(const char* a, const char* b) {
  while (*a && *b) {
    if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return false;
    a++; b++;
  }
  return *a == *b;
}

void runCommand(char* line) {
  char* cmd = strtok(line, " ");
  if (!cmd) return;
  char* a1 = strtok(NULL, " ");
  char* rest = strtok(NULL, "");

  if (ciEq(cmd, "help"))   { printHelp(); return; }
  if (ciEq(cmd, "info"))   { printInfo(); return; }
  if (ciEq(cmd, "stat"))   { printStat(); return; }
  if (ciEq(cmd, "stas"))   { printStas(); return; }
  if (ciEq(cmd, "scan"))   { cmdScan();   return; }
  if (ciEq(cmd, "pause"))  { paused = true;  Serial.println("[cmd] вывод на паузу (приём продолжается)"); return; }
  if (ciEq(cmd, "resume")) { paused = false; Serial.println("[cmd] вывод продолжен"); return; }
  if (ciEq(cmd, "learn"))  { learnUntil = millis() + LEARN_MS; Serial.println("[cmd] 30 c показываю ВСЕ кадры"); return; }
  if (ciEq(cmd, "rst"))    { Serial.println("[cmd] перезагрузка..."); delay(100); ESP.restart(); return; }

  if (ciEq(cmd, "mode")) {
    if (a1 && ciEq(a1, "ap")) { startApMode(curSsid, curPass, curCh); return; }
    if (a1 && ciEq(a1, "sniff")) {
      int ch = rest ? atoi(rest) : curCh;
      if (ch < 1 || ch > 13) { Serial.println("[cmd] канал 1..13"); return; }
      startSniffMode(ch);
      return;
    }
    Serial.println("[cmd] mode ap | mode sniff <ch>");
    return;
  }

  if (ciEq(cmd, "ch")) {
    if (!a1) { Serial.println("[cmd] ch <1..13>"); return; }
    int ch = atoi(a1);
    if (ch < 1 || ch > 13) { Serial.println("[cmd] канал 1..13"); return; }
    if (runMode == MODE_AP) startApMode(curSsid, curPass, ch);
    else { curCh = ch; esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE); Serial.printf("[cmd] канал=%d\n", ch); }
    return;
  }

  if (ciEq(cmd, "ssid")) {
    if (!a1) { Serial.println("[cmd] ssid <имя>"); return; }
    strncpy(curSsid, a1, sizeof(curSsid) - 1); curSsid[sizeof(curSsid) - 1] = 0;
    if (runMode == MODE_AP) startApMode(curSsid, curPass, curCh);
    else Serial.printf("[cmd] ssid=\"%s\" (вступит при mode ap)\n", curSsid);
    return;
  }

  if (ciEq(cmd, "sec")) {
    if (!a1) { Serial.println("[cmd] sec open | sec wpa <пароль 8..63>"); return; }
    if (ciEq(a1, "open")) {
      curPass[0] = 0;
      if (runMode == MODE_AP) startApMode(curSsid, curPass, curCh);
      else Serial.println("[cmd] sec=open (вступит при mode ap)");
      return;
    }
    if (ciEq(a1, "wpa")) {
      if (!rest) { Serial.println("[cmd] sec wpa <пароль 8..63>"); return; }
      int n = strlen(rest);
      if (n < 8 || n > 63) { Serial.println("[cmd] пароль должен быть 8..63 символов"); return; }
      strncpy(curPass, rest, sizeof(curPass) - 1); curPass[sizeof(curPass) - 1] = 0;
      if (runMode == MODE_AP) startApMode(curSsid, curPass, curCh);
      else Serial.println("[cmd] sec=wpa2 (вступит при mode ap)");
      return;
    }
    Serial.println("[cmd] sec open | sec wpa <пароль>");
    return;
  }

  if (ciEq(cmd, "f"))   { if (a1) foreignOn = atoi(a1) != 0;  Serial.printf("[cmd] чужие кадры=%d\n", foreignOn);  return; }
  if (ciEq(cmd, "b"))   { if (a1) beaconsOn = atoi(a1) != 0;  Serial.printf("[cmd] beacon'и=%d\n", beaconsOn);     return; }
  if (ciEq(cmd, "hex")) {
    if (!a1) { Serial.println("[cmd] hex 0|1|2"); return; }
    hexMode = (uint8_t)atoi(a1);
    Serial.printf("[cmd] hex=%u (0=нет 1=mgmt 2=все)\n", hexMode);
    return;
  }
  if (ciEq(cmd, "rssi")) {
    if (!a1) { Serial.println("[cmd] rssi <dBm | off>"); return; }
    rssiMin = ciEq(a1, "off") ? -128 : atoi(a1);
    Serial.printf("[cmd] rssi_min=%d\n", rssiMin);
    return;
  }

  if (ciEq(cmd, "mac")) {
    if (!a1) { Serial.println("[cmd] mac <aa:bb:cc:dd:ee:ff> | mac clear"); return; }
    if (ciEq(a1, "clear")) { memset(tracked, 0, sizeof(tracked)); Serial.println("[cmd] список MAC очищен"); return; }
    uint8_t m[6];
    if (!parseMacStr(a1, m)) { Serial.println("[cmd] формат aa:bb:cc:dd:ee:ff"); return; }
    learnMac(m);
    return;
  }
  if (ciEq(cmd, "macs")) {
    Serial.printf("[cmd] отслеживаемые MAC (%d):\n", MAX_TRACKED);
    for (int i = 0; i < MAX_TRACKED; i++) {
      if (tracked[i][0] | tracked[i][1] | tracked[i][2] | tracked[i][3] | tracked[i][4] | tracked[i][5]) {
        char s[18]; macToStr(s, tracked[i]);
        Serial.printf("  %s\n", s);
      }
    }
    return;
  }

  if (ciEq(cmd, "pcap")) {
    if (!a1) { Serial.printf("[cmd] pcap=%d\n", (int)pcapOn); return; }
    pcapOn = atoi(a1) != 0;
    if (pcapOn) Serial.println("[pcap] ВКЛ: дальше идёт бинарный поток. На ПК: python3 serial_capture.py --port <COMx> pcap --out dump.pcap");
    else        Serial.println("[pcap] выключен, текстовый режим");
    return;
  }

  if (ciEq(cmd, "dump")) {
    int n = a1 ? atoi(a1) : 10;
    if (n > ringCount) n = ringCount;
    Serial.printf("[cmd] последние %d кадров:\n", n);
    int start = (ringPos - n + RING_LEN) % RING_LEN;
    for (int i = 0; i < n; i++) Serial.println(ring[(start + i) % RING_LEN]);
    return;
  }

  Serial.printf("[cmd] неизвестная команда \"%s\" (help)\n", cmd);
}

/* --------------------------- ввод с UART -------------------------------- */
void handleSerial() {
  static char buf[160];
  static int n = 0;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (n > 0) { buf[n] = 0; runCommand(buf); n = 0; }
    } else if (n < (int)sizeof(buf) - 1) {
      buf[n++] = c;
    }
  }
}

/* ---------------------------- setup / loop ------------------------------ */
void setup() {
  Serial.begin(SNIFF_BAUD);
  delay(300);
  esp_log_level_set("*", ESP_LOG_WARN);
  memset(tracked, 0, sizeof(tracked));
  memset(&cnt, 0, sizeof(cnt));
  capQueue = xQueueCreate(QUEUE_LEN, sizeof(CapFrame));
  esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifiEventHandler, NULL);
  esp_event_handler_register(IP_EVENT, IP_EVENT_AP_STAIPASSIGNED, &wifiEventHandler, NULL);
  Serial.printf("\n\n=== esp32_wifi_sniffer v%s — отладчик WiFi N2600-OS (ASUS X101CH) ===\n", FW_VERSION);
  Serial.printf("=== ESP32 = точка \"%s\" (ch %d, %s) + promiscuous-сниффер, UART %d ===\n",
                AP_SSID_DEF, AP_CH_DEF, AP_PASS_DEF[0] ? "WPA2" : "OPEN", SNIFF_BAUD);
  Serial.println("=== ESP32 НЕ слышит собственные передачи: ответы AP видны по [EVT] и реакции нетбука ===");
  startApMode(AP_SSID_DEF, AP_PASS_DEF, AP_CH_DEF);
  printHelp();
}

void loop() {
  handleSerial();
  CapFrame f;
  while (xQueueReceive(capQueue, &f, 0) == pdTRUE) {
    frameNo++;
    processFrame(f);
  }
  uint32_t now = millis();
  if (now - statMark >= STAT_PERIOD_MS) {
    statMark = now;
    if (!pcapOn && !paused) {
      Serial.printf("[stat] %s ch=%d | mgmt=%u data=%u ctrl=%u показано=%u чужие=%u bcnскип=%u qdrop=%u подавлено=%u\n",
                    runMode == MODE_AP ? "AP" : "SNIFF", curCh,
                    cnt.mgmt, cnt.data, cnt.ctrl, cnt.shown,
                    cnt.foreign, cnt.beacon_drop, cnt.qdrop, cnt.suppressed);
    }
  }
  delay(2);
}
