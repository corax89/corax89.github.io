---
Task ID: 1
Agent: main (Z.ai)
Task: Проверить и применить патчи HDA (snd_hda.c) и WiFi (ath9k_wifi.c/wifi_core.c) к N2600-OS по документу пользователя

Work Log:
- Скачан n2600-os.7z (GitHub corax89), распакован py7zr в /home/z/my-project/work/src
- Прочитаны полностью: snd_hda.c (829 стр), ath9k_wifi.c (2032), wifi_core.c (2492)
- Скачаны эталоны Linux v6.6: ar9002_mac.c, mac.h, reg.h, eeprom.h, eeprom_4k.c,
  ar5008_phy.c, hw.c, hda_controller.c, hdac_controller.c, hda_intel.c; QEMU intel-hda.c,
  intel-hda-defs.h
- Проверены утверждения HDA: 1.1 CORBCTL бит0 vs бит1 — ПОДТВЕРЖДЕНО (QEMU defs);
  1.2 ICB не писался — ПОДТВЕРЖДЕНО (QEMU intel_hda_set_ics требует BUSY);
  1.3 rcad=(ex>>20)&0xF неверно, нужно ex&0xF + g_cad в discovery — ПОДТВЕРЖДЕНО;
  1.4 amp_caps/gain на CAD0 — ПОДТВЕРЖДЕНО; 1.5.2 барьер — ПРИМЕНЁН;
  1.5.3 явные CORBSZ/RIRBSZ=0x02 — ПОДТВЕРЖДЕНО Linux; 1.5.1 (инвертированные
  ожидания CORBRP) — ОПРОВЕРГНУТО: это точный azx_clear_corbrp() для ICH7
  (CORBRP_SELF_CLEAR в Linux только у Nvidia/C-Media) — НЕ применено
- Проверены утверждения WiFi: 2.0 частоты/синтезатор верны; 2.1 skip same-channel +
  dwell 110->220 — ПРИМЕНЕНО (wifi_core.c + ath9k_wifi.c); 2.3 DestIdxValid в ctl0 —
  ПОДТВЕРЖДЕНО (Linux mac.h: бит30 ctl1 = AR_IsAggr; ar9002_mac.c ds_ctl0) — ПРИМЕНЕНО;
  2.2 шаг1 масштаб мощности 30->40 (2*дБм+10, PWR_TABLE_OFFSET=-5, eeprom_4k.c:615) —
  ПРИМЕНЕНО (включая XmitPower0 в owl ctl0); этапы 2-4 (PDADC/board values/high_power)
  отложены до полевого теста шага 1; 2.4 MAC слова 6-8 + LE + автопроба map@0/@64
  (base_eep_header_4k, eep_start_loc=64) — ПРИМЕНЕНО + лог сырых слов и txGainType;
  synth_delay «в 10 раз длиннее» — ОПРОВЕРГНУТО (совпадает с ath9k_hw_synth_delay)
- Патчи внесены в work/src/src/{snd_hda,ath9k_wifi,wifi_core}.c
- Компиляция: gcc -m32 -Wall -Wextra — чисто; полная сборка build.sh — kernel.bin OK
- Дифф: work/n2600-snd-wifi.patch (494 строки, 22 хунка), прогнан patch -p1 на чистом
  дереве — файлы совпадают байт-в-байт

Stage Summary:
- Деливераблы: /home/z/my-project/download/n2600-snd-wifi-fix/ (README-FIX.txt,
  n2600-snd-wifi.patch, src/{snd_hda,ath9k_wifi,wifi_core}.c, kernel.bin) + .zip
- Ключевые решения: 1.5.1 и synth_delay НЕ применять (расхождения с документом,
  подтверждены эталонами); этапы 2-4 EEPROM-калибровки TX — после полевого теста
  шага 1 (быстрая проверка мощности); добавлена диагностика MAC/txGainType в лог
- Следующий шаг: загрузка на X101CH, проверка [hda] vendor=0x10EC0269, скан ch1,
  AUTH; при неудаче TX — прислать лог, портовать board values + PDADC + tx-gain

---
Task ID: 2
Agent: main (Z.ai)
Task: Проверить новый полевой лог (HDA жив, сеть падает на fastcc/TX AUTH) и применить исправления: адреса TX-мощности по ar9002_phy.h, fastcc->bring-up, EEPROM magic/checksum, путь звука DAC->mixer->pin

Work Log:
- Проверены утверждения пользователя по эталонам Linux v5.6: адреса
  POWER_TX_RATE1..6/MAX — ПОДТВЕРЖДЕНЫ (0x9934/0x9938/0xa234/0xa238/
  0xa38c/0xa390/0x993c); 0xa3a8 драйвера = AR_PHY_MASK2_M_16_30 — драйвер
  затирал маску интерливера; INI регистры мощности не трогает (grep);
  TxDone owl = status9 бит0 (ar9002_mac.c:322) — код драйвера ВЕРЕН,
  st1=0x702 = реальный отказ (8 передач, 0 ACK) — виновата мощность;
  txGainType=87 невалиден (допустимы 0/1) — MAC/карта читались не из
  карты (эвристика «валидный unicast» ловила слова вне карты);
  do_fastcc Linux ДЕЛАЕТ МЕНЬШЕ нашего fastcc — чинить нечем, выключаем
- Патчи ath9k_wifi.c: [W-TXPOW-v2] ath_txpow_program по настоящим
  адресам + контроль записи в лог; [W-FASTCC-OFF] ATH_USE_FASTCC=0,
  полный bring-up на каждый канал + [W-QUIET] тихий режим bring-up
  (одна сводная строка на канал, загрузочный/PREAUTH — подробные);
  [W-EEP4K-v2] eeprom_map_probe: magic 0x5aa5/0xa55a + XOR-checksum
  карты @64 (затем @0), macAddr=base+6..8, txGainType=base+15hi,
  старая эвристика — fallback; g_txgain_type сохранён
- Патчи snd_hda.c: [HDA-PATH] hda_conn_list (0xF0E/0xF02) +
  hda_route_output (пин 0x14/0x21: прямой DAC или миксер с размьючиванием
  входного ампа по индексу DAC — кодировка hda_verbs.h: Input=бит14,
  индекс=[11:8]); [HDA-PINCFG] лог pin config 0xF1C; [HDA-DMA] play():
  лог CTL/CBL/LVI/LPIB (двойное чтение) — «DMA НЕ ИДЁТ!» если стоит;
  [HDA-CIV] ФИКС stream(): CIV из байта СТАТУСА (+0x03), не из CTL
- Сборка: gcc -m32 -Wall -Wextra чисто; build.sh -> kernel.bin OK
  (1210228 байт); os.iso не собран (нет root для grub-pc-bin) — makeiso.sh
  у пользователя
- Поставка: download/n2600-net-txpow-fix/ (README-FIX.txt,
  n2600-net-txpow.patch 579 строк, src/{ath9k_wifi,snd_hda}.c,
  kernel.bin) + .zip; патч прогнан patch -p1 на дереве прошлой
  поставки — совпадение байт-в-байт

Stage Summary:
- Корень «TX отказ» = нулевая мощность: регистры 0x9934+ никогда не
  программировались, драйвер писал в несуществующие 0xa368+
- Корень «глухоты» скана = fastcc на этом железе (полный bring-up —
  единственный проверенный путь), теперь по умолчанию выключен
- Звук: путь ALC269 DAC->0x0C->пин размьючивается полностью; play
  теперь диагносцируется в логе; CIV-фикс для потокового плеера
- Следующий шаг: полевой тест — ждать ACK на AUTH (мощность), маяки
  на ch 1 (bring-up), magic/txGainType в логе EEPROM; при успехе —
  port board values + PDADC (этапы 2-4), затем WPA2

---
Task ID: 3
Agent: main (Z.ai)
Task: Разбор полевого лога (HDA: play запускается, DMA стоит; WiFi: AUTH без ACK, EEPROM magic не найден) и итерация 3 исправлений

Work Log:
- HDA [HDA-SDFIX]: сверка с QEMU intel-hda-defs.h/ST_REG и Linux — офсеты
  дескриптора в коде были сдвинуты на 4 (LPIB 0x08/0x04, CBL 0x0c/0x08,
  LVI 0x0e/0x0c), база потока 0x120 = SDO1 при INTCTL бит4 = SDO0; hd_wr32
  на невыровненные 0x0e/0x12 молча округлялся вниз (mmio[off>>2]) — из лога
  CBL=262145=0x40001 = LVI(1)|FIFOW(4)<<16, FMT получал нули, настоящий CBL
  оставался 0 => контроллер не запускал DMA. Исправлено: HDA_SD0=0x100,
  LVI/FMT через hd_wr16, SRST-последовательность (Linux azx_stream_reset),
  ack STS 0x1C, бит DIR убран, CIV -> позиция LPIB в stream(), лог play()
  читает настоящий LPIB (+0x04) и печатает CTL/CBL/LVI/FMT/BDL
- WiFi [W-EEP4K-v3]: протокол чтения слова сверён с Linux ath9k/pci.c
  ath_pci_eeprom_read (триггер 0x2000+(w<<2), статус 0x407c, VAL 15:0) —
  верен; проблема была в поиске карты. Новый пробоотбор: дамп слов 0..31 и
  64..79 + статус (BUSY/PROT/ABSENT), скан magic 0x5aa5/0xa55a по 0..127
  (сдвиг окна => база K+64), checksum по эталону (XOR слов 0..el-1 ОТ
  НАЧАЛА EEPROM, el=min(length/2,188); v2 считал от базы — расхождение),
  карта целиком в структуру 1:1 eeprom.h v6.6 (Static assert 32/68/376;
  ловушки транскрипции: length/checksum = u16, spurChan = u16, байт
  db1_0/db1_1 в modal)
- WiFi [W-BOARD4K]: порт ath9k_hw_4k_set_board_values/set_gain (eeprom_4k.c
  v6.6) — SWITCH_COM/CHAIN_0, IQCORR, XATTEN, RXGAIN atten/margin (+0x1000),
  антдиверсити (0x99ac/0xA208), OB/DB bias в AR9285_AN_RF2G3/4 (0x7828/2C),
  SETTLING/DESIRED_SZ/RF_CTL2/3/4, CCA/EXT_CCA0 thresh62, bb_scale; вызов в
  ath_bringup после delta_slope, до init_bb
- WiFi [W-PDADC4K]: порт ath9k_hw_set_4k_power_cal_table +
  get_gain_boundaries_pdadcs + fill_vpd_table/interpolate (4K-ветка) —
  TPCRG1 PD_GAIN'ы, TPCRG5 (0xA26C) overlap/границы, таблица PDADC 32 dword
  @0xA280; вызов в bring-up перед ath_txpow_program (порядок set_txpower)
- Сборка: bash build.sh -> kernel.bin OK (1188 КиБ, floppy.img собран);
  gcc -m32 -Wall -Wextra — в правленых файлах предупреждений нет
- Дифф n2600-fix3.patch (1111 строк) прогнан patch -p1 на поставке 2 —
  файлы совпадают байт-в-байт

Stage Summary:
- Деливерабл: download/n2600-hda-dma-eep-fix/ (README-FIX.txt,
  n2600-fix3.patch, src/{snd_hda,ath9k_wifi}.c, kernel.bin) + .zip
- Звук: три независимых дефекта (офсеты, невыровненные 32-бит записи,
  отсутствие SRST/reset-программирования) устранены; критерий успеха в
  логе — рост LPIB в строке play
- WiFi: если карта найдётся (ожидаем "карта @ слово 64 ВАЛИДНА"), впервые
  применяются board values + PDADC из EEPROM — главный подозреваемый
  «8 передач 0 ACK»; если magic не найден даже в 0..127 — дамп покажет
  (OTP/нестандартное окно), MAC сверить с наклейкой
- Следующий шаг: полевой лог -> при валидной карте и сохранении
  ExcessiveRetries проверить RX ACK-путь и TX-статусы; при слухе ACK —
  WPA2 4-way

---
Task ID: 4
Agent: main (Z.ai)
Task: Разбор полевого лога итерации 3 (HDA DMA пошёл; WiFi EEPROM «magic НЕ найден», AUTH без ACK) и итерация 4 исправлений

Work Log:
- Звук: LPIB растёт (48/24/60/264) — [HDA-SDFIX] итерации 3 РАБОТАЕТ;
  8086:27d8 = NM10/ICH7 HD Audio — совпадает с «Intel 82801GB ICH7 - HD
  Audio [B0]» из диспетчера устройств Windows, кодек ALC269
- HDA проверен без правок: STRM tag в битах 23:20 SDnCTL подтверждён
  QEMU (intel_hda: stnr = (ctl >> 20) & 0x0f) и совпадает с verb 0x706
  payload 0x10 (stream 1 ch 0) на DAC 0x02; FMT=0011 = 48k/16/стерео;
  биты 18/20/26/29 в CTL расшифрованы (DEIE/IOCE/BCIS/FIFORDY — безвредны)
- WiFi: корень найден — swap-полярность пробы ИЗНАНКУ. Эталон eeprom.c
  ath9k_hw_nvram_swap_data: raw 0xa55a -> LE (свопа НЕТ), 0x5aa5 -> BE.
  Карта X101CH отдаёт a55a (LE), v3 считал её BE и свопил length
  0x0178 -> 0x7801 -> «вне диапазона» -> валидная карта отбрасывалась
- Сверено с refs/ath9k_eeprom_4k.c: eep_start_loc=64, checksum XOR по
  массиву карты (от базы), SIZE_EEPROM_4K=188, el=min(length/2,188);
  base_eep_header_4k 32 байта (macAddr слова 6..8 карты = EEPROM 70..72,
  txGainType байт 31)
- Прогноз по дампу: карта @64 подлинная — length=376, version 0xe00e
  (14.14), opCapFlags=0x02 (11G-only Kite), MAC = 94:db:c9:a2:58:c1
  (OUI ASUS) — слова 70-72; фолбэк 08:50:01:00:80:02 читал PCI
  VID/DID/подсистему (слова 4-6)
- Патч [W-EEP4K-v4] (ath9k_wifi.c, единственный изменённый файл):
  1) полярность 0xa55a->swap=0 / 0x5aa5->swap=1;
  2) checksum от базы карты (эталон), абсолютная — фолбэк, печать
     сумм sum=/abs= при отказе;
  3) при отказе checksum карта принимается с предупреждением, если
     length/version-major/MAC подлинные (eep4k_looks_genuine) —
     не блокировать board values/PDADC;
  4) диагностика: custData (ASCII), opCap/maxPower, modal[0..3]
     (antCtrlChain/antCtrlCommon), сообщение «magic найден, но карта
     не прошла» вместо вводящего в заблуждение «magic НЕ найден»
- ath_txpow_program проверен: RATE4 (0xa238, CCK 1L) пишется (в лог
  не выводился) — тут дефекта нет
- Сборка: build.sh -> kernel.bin 1217524 байт OK; ath9k_wifi.c без
  предупреждений; n2600-eep-swap.patch (204 строки) прогнан patch -p1
  на дереве итерации 3 — совпадение байт-в-байт

Stage Summary:
- Деливерабл: download/n2600-eep-swap-fix/ (README-FIX.txt,
  n2600-eep-swap.patch, src/ath9k_wifi.c, kernel.bin) + .zip
- Звук: драйверная часть готова; осталось подтвердить слышимость
  (если тихо — pin config 0x71C=0 задать явно, каскад ALC269)
- WiFi: после фикса пробы впервые выполнятся board values + PDADC
  (порт итерации 3 ждал g_eep4k_ok=1) — главный подозреваемый «8
  передач 0 ACK» (PA работал на ini-умолчаниях)
- Следующий шаг: полевой лог -> сверить MAC 94:db:c9:a2:58:c1 с
  наклейкой; если TX ACK есть — WPA2 4-way; если «tries=7» остался
  при валидной карте — RX ACK-путь и TX-статусы подробно

---
Task ID: 5
Agent: main (Z.ai)
Task: Разбор полевого лога итерации 4 (WiFi-карта валидна, но bring-up завис после «калибровка ok»; звук: DMA идёт, тишина) и итерация 5

Work Log:
- Подтверждено: карта EEPROM читается (MAC 94:db:c9:a2:58:c1 — прогноз
  сошёлся, слова 70-72), но bring-up ОБРЫВАЕТСЯ после «калибровка ok»:
  PDADC/TX-мощность/скан не печатаются, система жива (usb/sata/бипер)
  -> зациклившаяся wifi-задача
- НАЙДЕНО: в порте ath9k_get_gain_boundaries_pdadcs хвостовой цикл
  дозаполнения pdadcValues БЕЗ k++ (Linux: pdadcValues[k]=k-1, k++).
  Циклы выше ограничены k<127 -> хвост всегда выполняется -> вечный
  цикл. Регресс порта итерации 3, проявился как только карта стала
  валидной (g_eep4k_ok=1). [W-PDADC-FIX]: k++ + границы-хвост копией
  последней (эталон eeprom.c, не 58) + страховки (clamp vpd 64,
  guard sizeCurrVpdTable-2)
- ЗВУК — ГЛАВНАЯ ПРИЧИНА ТИШИНЫ: 4-битные глаголы (SetConverterFormat
  0x2, SetAmpGainMute 0x3 — 16-бит payload) кодировались макросом
  VERB (verb<<8): SetAmp(0x3,0xA000|val) собирался в 0xA3xx — кодек
  видел GET Converter Format (0xA), ВСЕ unmute/gain-записи были
  чтениями (миксер 0x0C оставался замученным после сброса);
  SetConverterFormat собирался в 0x211 — no-op, формат DAC = сброс
  (44.1к/8бит/моно) при линке 48к/16/стерео. В VMware незаметно
  (эмулятор не гейтится mute'ами). [HDA-VERB16]: макрос VERB16
  (verb4<<16|payload16); unmute по alc269_init_verbs (AMP_OUT_UNMUTE
  0xB000, миксер 0x7000|idx<<8); чтение-подтверждение формата (0xA) и
  потока (0xF06) DAC в лог с «НЕ СОВПАЛО!»; декод Amp Cap NumSteps
  [23:16] (прежде читался StepSize)
- [HDA-1B] (гипотеза пользователя принята): пин 0x1b — pin caps
  (0xF00/0x09 бит4) + pin config печатаются; при заявленном выходе —
  маршрут DAC->0x0c->0x1b + unmute + EAPD + Out Enable + D0
- TX: [W-TXDONE-STRICT] (пункт пользователя принят): завершение ТОЛЬКО
  по status9.0 TxDone (ar9002_mac.c proc_txdesc); эвристика «TXE погас
  + st1!=0» (via=3) удалена; при TXE-без-TxDone — дамп сырых
  статусных слов дескриптора st[0..9] (первые 2 раза) — следующий
  лог покажет, куда железо пишет статус (st1=0702 = RTSFailCnt=7 +
  ExcessiveRetries по ar5416.h)
- Замечено: у пользователя дублирование макроса VERB16 из-за атомарного
  отказа MultiEdit — устранено; сборка чистая (0 предупреждений в
  правленых файлах)
- Сборка: build.sh -> kernel.bin 1219316 байт; патчи
  n2600-pdadc-verb-ath9k.patch (135 строк) + n2600-pdadc-verb-hda.patch
  (153) верифицированы patch -p1 на дереве итерации 4 — байт-в-байт

Stage Summary:
- Деливерабл: download/n2600-pdadc-verb-fix/ (README-FIX.txt, 2 патча,
  src/{ath9k_wifi,snd_hda}.c, kernel.bin) + .zip
- Звук: две реальные причины тишины (unmute-записи не были записями +
  формат конвертера не задавался) устранены; контроль в логе
  («формат=0011, stream=10») — если «НЕ СОВПАЛО!», кодек не принимает
  глаголы, следующий шаг — RIRB-детали
- WiFi: PDADC-цикл исправлен — board values + PDADC наконец выполнятся
  до конца; TX ждёт только TxDone с дампом дескриптора при аномалии
- Следующий шаг: полевой лог -> сверить MAC с наклейкой; звук —
  подтверждение слышимости; WiFi — «PDADC: таблица записана», скан,
  AUTH: TxDone или дамп дескриптора

---
Task ID: 6
Agent: main (Z.ai)
Task: Разбор полевого лога итерации 5 (звук пошёл, но «на грани
слышимости»; WiFi сканирует, RSSI врёт, AUTH без ACK: «TXE погасла,
TxDone(status9.0) НЕ установлен (st1=702 st9=0)») и итерация 6:
громкость + регулятор на панели задач, мощность точек, причина «нет ACK»

Work Log:
- ЗВУК — корень тишины найден: [HDA-GAINMAX] все записи усиления
  писали индекс 0 с комментарием «0 дБ»; по спецификации HDA
  (7.3.4.7; Linux snd_hda_codec: max index = 0 dB) индексы ампа
  0..NumSteps и ТОЛЬКО NumSteps — точка 0 дБ, индекс 0 — максимум
  ослабления. Главный тракт ALC269 — входной амп миксера 0x0c
  (~74 шага = до -74 дБ) стоял на полу. Теперь все ампы (DAC 0x02,
  миксер 0x0c in+out, пины 0x14/0x21/0x1b/0x0F/0x10) — в NumSteps,
  unmute; лог «SetAmp=%04x» для контроля
- [HDA-SWVOL] софтверная мастер-громкость: масштабирование отсчётов
  при копии в DMA-кольцо (g_buf) — единая точка hda_vol_copy в
  snd_hda_play/snd_hda_stream; API snd_hda_set/get_volume ->
  sound_set/get_volume (sound.h/.c, для ES137x — no-op)
- [UI] wm.c: значок динамика левее значка сети (TB_VOL_W=26,
  taskbar_btn_end резерв narrowed — кнопки задач физически не
  достают до трея, отрисовка и hit-тест из одной раскладки); щелчок —
  панель «Громкость: N%» (204x58 над таскбаром, как панель boot-
  прогресса), ползунок тянется ЛКМ (vol_drag), клик мимо — закрыть;
  волны/крестик по состоянию, акцентный цвет при открытой панели
- WiFi TX — ГЛАВНАЯ ПРИЧИНА «нет ACK» найдена: [W-IFSTIME] INI
  AR9285 (ath9k_ar9285_ini.h:118) программирует 0x8014 (AR_TIME_OUT)
  = 0 и НЕ программирует SIFS/SLOT — окно ожидания ACK у DCU = 0 мкс:
  кадр уходит (SendTimestamp пишется), ACK не засчитывается НИКОГДА
  (DataFailCnt=7, ExcessiveRetries). В Linux обязательно поверх ini
  пишет ath9k_hw_init_global_settings — порт ath_global_ifs_setup
  (SIFS 10 мкс/440 такта, SLOT 20/880, ACK 64 мкс/2816, CTS 48/2112,
  AR_USEC USEC=43 | RX_LAT=37 | TX_LAT=54), вызов в bring-up после
  ini+queue_setup, лог «было/стало» — в поле «было 00000000»
  подтвердит диагноз
- [W-RXCTRL] RX-фильтр без бита CONTROL (0x08): ACK — control-кадр;
  добавлен в оба режима (скан/BSS) — как FreeBSD/madwifi
  (безусловно); ACK в очереди RX парсер пропускает
- [W-TXWAIT] окно TxDone 150 -> 300 мс (полевой лог: 7 ретраев 1M на
  занятом эфире ~152 мс — статус приходил сразу после отпускания)
- [W-TXDUMP2] полный дамп дескриптора при аномалии (ctl0-13 + st0-9 +
  2 слова): полевой дамп итерации 5 декодируется идеально при статусе
  со слова 16 (st1=702 = ExcessiveRetries+DataFailCnt=7, st9=142b =
  TxDone+SeqNum), тогда как mac.h эталона кладёт статус со слова 14 —
  слова 14/15 в прежний дамп не попадали; контрольные слова (FrameLen/
  BufLen/rate/tries) в обеих раскладках на одних местах, поэтому
  структуру НЕ менял — следующий дамп закроет вопрос
- [W-RSSI-NF] RSSI: байт дескриптора ОТНОСИТЕЛЕН шумового пола
  (эталон ath9k_cmn_process_rssi: signal = noise + rs_rssi); прежнее
  «-raw» совпадало с эталоном только при raw=59 — точка показывала
  то -35, то -59, слабые всегда -100. Теперь dBm = g_nf_dbm (NF канала
  из bring-up) + raw; raw 0/0x80 -> -100; клэмп -110..-20
- Сборка: bash build.sh -> kernel.bin 1222776 байт; правленые файлы
  (ath9k_wifi.c, snd_hda.c, wm.c, sound.c, sound.h) — 0 предупреждений
- Патч n2600-vol-wifi-ack.patch (655 строк, 5 файлов) верифицирован
  patch -p1 на синтетическом дереве (поставка 5 + оригиналы wm/sound
  из n2600-os.7z) — совпадение байт-в-байт

Stage Summary:
- Деливерабл: download/n2600-vol-wifi-ack-fix/ (README-FIX.txt,
  n2600-vol-wifi-ack.patch, src/{ath9k_wifi,snd_hda,wm,sound.c,
  sound.h}, kernel.bin) + .zip
- Звук: «на грани слышимости» = тракт на полу усиления (индекс 0);
  теперь 0 дБ + софт-громкость + регулятор на панели задач
- WiFi: «нет ACK» = AR_TIME_OUT=0 из INI (+бит CONTROL в фильтре);
  после фикса AUTH должен подтверждаться — дальше машина подключения
  (ASSOC -> 4-way WPA2, код готов); RSSI = NF + raw (эталон)
- Следующий шаг: полевой лог -> «Тайминги MAC (было 00000000)»,
  AUTH с ACK, 4-way; при повторе «TxDone не встал» — дамп 7 строк
  «TX ctl…/st…/+2слова» даст фактическую раскладку статуса

---
Task ID: 7
Agent: main (Z.ai)
Task: Итерация 7 — ползунок громкости не реагирует в VMware (Sound Blaster
ES1371); эмуляция терминальных последовательностей в терминале (как libtmt);
telnet-клиент; telnet-сервер + галочка в настройках (включён по умолчанию)

Work Log:
- ЗВУК — причина «замороженного» ползунка: громкость применялась ТОЛЬКО
  на HDA (sound_set_volume: g_driver==3; sound_get_volume для ES137x
  всегда 100) — в VMware карта ES1371 «Sound Blaster AudioPCI», set —
  no-op, UI перерисовывал 100%. [SND-VOL] sound.c: громкость для всех
  драйверов; ES137x — масштабирование s16 перед отдачей (beep — на месте,
  stream — ПАРА чередующихся staging-буферов 64 КиБ: DMA ES137x читает
  буфер вызывающего напрямую, контракт «живёт до следующего вызова»
  сохранён; отказ malloc — без громкости). Отрисовка панели не менялась.
- [VOL-KEYS] wm.c wm_key: открытая панель громкости — ←/→ (↑/↓) ±5%,
  Esc закрывает; перехват до доставки верхнему окну (по образцу
  menu_key_nav). Раньше стрелки в панель не обрабатывались вовсе.
- [TERM-VT] apps.c: VT/xterm-эмулятор в духе libtmt (машина состояний
  GROUND→ESC→CSI/OSC+C0) поверх сетки 96x48 (по размеру окна), атрибут
  на байт (0xFF=умолчания темы), таблица 16 комбинаций fg/bg/bold/rev
  с вытеснением по кругу, палитра xterm 16 + приведение 256/24-бит
  цветов к 16. CSI: CUP/HVP/CUU/CUD/CUF/CUB/CNL/CPL/CHA/VPA, ED 0/1/2/3,
  EL 0/1/2, IL/DL/ICH/DCH/ECH, SU/SD, CBT; ESC D/M/E/7/8/c; SGR
  (bold/reverse/30-37/90-97/40-47/100-107/38;5/38;2/48;…), ?25, alt-screen
  ?1049/?1047/?47 (сохранение основного экрана), RIS; UTF-8 на приёме;
  OSC глотается; ответы DSR-6/DSR-5/DA (VT102). DECSTBM/?7/?1000 — молча.
  Отрисовка прогонами по атрибуту; фон ячеек — fb_fill_rect (fb_text
  заливает фон не полностью); курсор-блок с wm_blink; resize → clear+home.
  Ввод — ASCII (ограничение key_event_t.ch, как и в локальном вводе).
- [TCLIENT] telnet-клиент: команда «telnet <хост> [порт]», DNS
  (net_dns_resolve), net_tcp_connect:40001, pin+gen; НОВОЕ net.c/net.h
  net_tcp_set_sock_callback — per-socket приём для активных соединений
  (раньше клиентские сокеты падали в единственный глобальный callback);
  приём → кольцевой буфер 16 КиБ (cli/sti) → дренаж в term_draw+term_tick
  → VT-парсер; клавиатура → хост (Enter=CR, BS=DEL, стрелки/F-клавиши/
  PgUp/PgDn → последовательности, Ctrl+буква → байт), IAC-экранирование
  исходящих 0xFF, входящие IAC: DO/WILL → WONT/DONT, SB..SE пропуск;
  выход Ctrl+]/Ctrl+Q; RST/FIN распознаются; одна сессия на систему;
  ping/js/telnet через sink-режим («headless») запрещены с объяснением.
- [TERM-SINK] headless-терминал (apps.c/apps.h): term_headless_create/
  free/sink + term_shell_exec — term_t без окна, term_print уводит вывод
  в колбэк; term_exec(NULL-safe term_touch) — та же таблица команд.
- telnetd.c/h (новый): TCP :23, до 3 клиентов, slug «telnetd»
  (TASK_PRIO_BG, system); accept/recv-колбэки только копируют (баннер и
  исполнение — в задаче: отправка с ожиданием ACK из accept дала бы
  реентерабельный net_poll — исправлено на need_hello); IAC WILL ECHO +
  WILL/DO SGA; строка с эхом/Backspace/Ctrl+U/Ctrl+C/Ctrl+D; исполнение
  через headless-term, вывод \n→\r\n + IAC-экранирование; idle 10 мин;
  reboot/poweroff по telnet запрещены. ПО УМОЛЧАНИЮ ВКЛЮЧЁН.
- kernel.c: telnetd_autostart() после фоновых задач (читает SETTINGS.CFG
  «telnet=0», слушает :23, спавнит задачу).
- apps_settings.c: галочка «Telnet-сервер (:23, shell терминала)» на
  вкладке Сеть по образцу веб-сервера (ACT_TELNETD=41, wm_checkbox_draw/
  hit, telnetd_y=-1000 до отрисовки, telnet= в settings_net_save).
- Сборка: bash build.sh → kernel.bin 1245216 байт; во всех правленых
  файлах 0 предупреждений/ошибок (ahci/mquickjs/wifi_core warnings —
  существовавшие ранее).
- Патч n2600-term-telnet.patch (88 КиБ, 11 файлов, 37 хунков) верифицирован
  patch -p1 на синтетическом дереве (оригиналы + поставка 6) — все 11
  файлов совпали байт-в-байт; wifi_core.c/.h, rtl8192eu.c в патч НЕ
  входят (локальные правки пользователя [W-TXRATE] не затрагиваются).
- QEMU в среде нет (нет root) — верификация статическая; полевой тест
  за пользователем (VMware/QEMU/железо).

Stage Summary:
- Деливерабл: download/n2600-term-telnet/ (README-FIX.txt,
  n2600-term-telnet.patch, src/{apps,apps_settings,net,apps.h,kernel,
  sound.c,sound.h,wm,telnetd.c,telnetd.h}, kernel.bin) + .zip
- Громкость: работает на всех драйверах (ES1371/ES1370 — софт-масштаб
  в staging), панель — мышь + стрелки + Esc
- Терминал: VT100/xterm-подмножество (курсор/очистки/цвета 16/256/
  alt-screen/DSR/DA) — готов к BBS/роутерам; telnet-клиент Ctrl+]
- telnetd: :23, shell терминала, вкл по умолчанию, галочка в настройках,
  telnet=0|1 в SETTINGS.CFG, 3 клиента, idle 10 мин
- Следующий шаг: полевой тест (громкость в VMware; telnet 127.0.0.1;
  telnet на роутер/BBS); WiFi-тесты итерации 6 — как только появится
  доступ к железу

---
Task ID: 8
Agent: main (Z.ai)
Task: Итерация 8 — разбор полевого лога VMware (serial.txt): зависание
с лавиной «[task_lock] STUCK >1c … освобождена» (12k+ строк) и паникой
[klock] FATAL на 18-й секунде; на одноядерном CPU проблемы нет. Найти
корневую причину и исправить.

Work Log:
- Скачан serial.txt (12693 строки, 1.4 МиБ). Статистика: 12149x
  «STUCK >1c (owner task -1, site 001d1b0d) — секция брошена,
  освобождена»; 252x «owner task 0, site 001d3625 … освобождена»;
  149x «держатель жив, ждём»; строка 2024: «[klock] FATAL: klock stuck
  >2s — kernel panic», ticks=17921 (вся катастрофа за 18 с аптайма);
  ПОСЛЕ паники — ~10600 строк флуда. В дампе паники держатель klock —
  задача 5 «Термина», но holds_klock=0 — расхождение = след параллельных
  секций.
- Сайты разрешены по kernel.bin итерации 7 (пересборка synth7 -> ELF с
  символами; сверка байт-кода с плоским бинарником): 001d1b0d =
  task_ap_schedule+0x28 (первый task_lock_acq AP-планировщика),
  001d3625 = task_schedule+0x25 (BSP-планировщик из IRQ0). Лавина
  начинается сразу после «[smp] планирование задач на AP включено».
- ПРИЧИНА 1 (корень): ватчдог [TL-STUCK2] в task_lock_acq рвал живые
  секции: (а) own<0 — ЛЕГИТИМНО ([TASKC-AP-IDLE]: AP-idle планировщик
  пишет task_current()==-1 — самая частая секция в системе, 3 AP);
  (б) escaped (own==0 + пульс kmain) — ложные срабатывания для секций
  из IRQ0-контекста + stale-владение после release ([TL-OWNER]).
  task_lock=0 по живой секции -> параллельные планировщики -> порча
  tasks[]/holds_klock -> осиротевший klock -> честный [klock] FATAL.
- ПРИЧИНА 2 (ускоритель): скорость лавины ~130 строк/с (при честном
  1 с — максимум ~4/с на 4 ядра) => timer_poll_expired истекал рано.
  Калибровки ahci/ath9k/rtl8192eu/atl1c перепрограммируют PIT-канал 2
  ВНЕ cmpxchg timer.c -> детектор «now > s_wrap_last» даёт фантомные
  +65536 тиков (~55 мс) на перепрограммку; GATE2 мог замораживаться
  восстановлением 0x61.
- ФИКС [TL-STUCK3] (task.c/task.h): владение per-cpu
  (s_tl_owner[]/s_tl_site[]/s_tl_hold_cpu, пишется после owner, сброс в
  rel ДО unlock); отбор ТОЛЬКО доказуемо мёртвого держателя при
  достоверном владении (own<0/escaped-ветки удалены); диагностика не
  чаще 1 строки/с (task_lock_msg_gate); task_lock_panic_release и два
  panic-пути (task_panic_kill_current, task_ap_panic_orphan) переведены
  на per-cpu проверку.
- ФИКС [TL-QUIET]: оба FATAL-пути klock зовут task_lock_quiet_set()
  перед остановкой — AP-спины после паники молчат и паркуется (cli;hlt).
- ФИКС klock-таймаута: pit2-истечение (2 с) кросс-проверяется тиками
  IRQ0 (wait_ticks, >1.5 с) — ложные FATAL от фантомного PIT2 исключены.
- ФИКС [PIT2-RESYNC] (timer.c/timer.h): timer_pit2_resync() переозначает
  базу оборотов под замком; вызван из калибровок ahci/atl1c/ath9k/rtl;
  GATE2 в калибровках оставляем открытым ((p61|0x01)&~0x02).
- Сборка: bash build.sh -> kernel.bin 1246272 байт; в правленых файлах
  0 предупреждений (ahci lba48/mquickjs/chk_game/rtl bcast_mac — старые).
- Патч n2600-vm-stuck.patch (24.8 КиБ, 8 файлов, 17 хунков) верифицирован
  patch -p1 на чистом дереве итерации 7 — все 8 файлов байт-в-байт.
  (Замечание: канал вывода терминала «ест» последовательность «[h» в
  тексте — проверки делать hexdump'ом/cmp, не глазами.)

Stage Summary:
- Деливерабл: download/n2600-vm-stuck-fix/ (README-FIX.txt,
  n2600-vm-stuck.patch, src/{task,task.h,timer,timer.h,ahci,atl1c,
  ath9k_wifi,rtl8192eu}, kernel.bin) + .zip
- Корневая причина зависания в VMware: SMP-гонка ватчдога task_lock
  (срыв живых секций по owner=-1/escaped), ускоренная фантомными
  оборотами PIT2 от калибровок драйверов; после паники AP-спины
  заваливали serial. На одноядерной машине спин-ветка не выполняется —
  потому проблемы нет.
- Ожидание после фикса: STUCK-строки максимум 1/с и только при реальной
  занятости замка >1 с; отбор — только у мёртвого держателя; [klock]
  FATAL — один раз, чисто, AP паркуется.
- Следующий шаг: полевой тест VMware (4 vCPU, длительный аптайм) и
  реальное железо; WiFi-тесты итерации 6 — при доступе к AR9285.

---
Task ID: 9
Agent: main (Z.ai)
Task: Итерация 9 — разбор полевого лога реального железа (AR9285, X101CH):
WiFi «TXE погасла, TxDone(status9.0) НЕ установлен (st1=702 st9=0)»,
«AUTH не отправлен»; звук «очень тихий даже на 100% и работает только в
колонках»; «mp3 вообще не слышно»

Work Log:
- WIFI, расшифровка статуса по ref_mac.h: st1=0x702 = FrmXmitOK=0 +
  ExcessiveRetries=1 + DataFailCnt=7 — MAC 7 раз ждал ACK, RSSI-поля 0x80
  («не измерялись»): кадр фактически не передавался/ACK невозможен.
  КОРЕНЬ: в owl_txdesc не заполнялся ctl7 — биты ChainSel (выбор TX-цепи
  PHY для рейта серии; эталон ar9002_set_txdesc -> set11nChainSel,
  кодировка — битовая маска: 1 = цепь A). ctl7=0 = «ни одной цепочки».
  ФИКС [W-CHAINSEL]: d->ctl7 = (1<<2) | (RATE_CCK_1M<<20) (RTSCTSRate —
  как ath9k, младший базовый рейт).
- WIFI [W-TXISR]: полевые логи итераций 5/9 — TxDone(status9.0)
  запаздывает относительно завершения (st1 финален, st9 приходил через
  десятки мс после печати отказа). Добавлен фолбэк по эталону
  ar9002_mac.c get_isr (не-RAC): опрос AR_ISR_S0 (QCU_TXOK/TXDESC) /
  AR_ISR_S1 (QCU_TXERR/TXEOL) с очисткой записью прочитанного; биты
  очищаются ДО постановки кадра; если через 10 мс после бита ISR TxDone
  не встал — done=2 (статус финален), лог «TX: завершено по ISR».
- WIFI [W-PCUTXBUF]: AR_PCU_TXBUF_CTRL=0x380 для AR9285 (0x700 осталь-
  ным) после сброса — эталон hw.c ath9k_hw_reset («wrap around issues»).
- Проверено и НЕ тронуто: ACK/CTS-таймауты ОС = 64/48 мкс — совпадают с
  ath9k_hw_init_global_settings (2 ГГц workaround 64/48); FrameType=0 —
  n_TYPE_NORMAL=0 по ref_mac.h; AMPLITUDE-полярность амп [HDA-GAINMAX]
  подтверждена эталоном snd_hda_codec (raw NumSteps = 0 дБ, ALSA max).
- ЗВУК «только в колонках»: ALC269VB — наушники 0x21 <- 0x0d <- DAC 0x03
  (второй DAC!), ОС настраивала только DAC 0x02: у 0x03 не было
  формат/поток/D0, входной амп 0x0d не размьючен. ФИКС [HDA-DUALDAC]:
  hda_widget_type() (Get Param 0x09 биты 23:20); hda_route_output
  спускается по conn list глубже — если миксер питается другим DAC
  (тип 1), hda_dac_setup подключает его к потоку 1 (формат 48k/16/st,
  тег 0x10, D0, амп-макс) и размьючивает вход миксера на его индексе.
  Работает и для 0x1b/нестандартных разводок; в логе «da] путь: DAC 03
  [второй DAC] -> 0d …».
- ЗВУК «тихий даже на 100%»: тракт на максимуме; генератор бипа выдавал
  43% шкалы (-7.4 дБ) — поднято до 28000/32768 (~85%, -1.4 дБ).
- MP3 «вообще не слышно»: цикл плеера декодировал фикс. 4608 фреймов на
  кусок 8192 выходных: 39-56% куска = «залипший» последний сэмпл (DC),
  на 44.1 кГц темп 0.56x, стыки с треском. ФИКС [MP3-CHUNK]: на кусок
  декодируется ровно need_in = ceil(OUT_CHUNK*srate/orate)+2 фреймов
  (добор по 1 фрейму), stage расширен до MP3_IN_MAX, страховка
  p->chans==0 (иначе весь кусок — константа = полная тишина).
  IN_CHUNK удалён.
- Сборка: bash build.sh -> kernel.bin 1246752 байт; в 4 правленых файлах
  0 предупреждений (проверено точечной компиляцией с -Wall -Wextra).
- Патч n2600-fix9.patch (23.3 КиБ, 4 файла, 23 хунка) верифицирован
  patch -p1 на синтетическом дереве (vm-stuck-fix ath9k, pdadc-verb
  snd_hda, term-telnet sound.c, 7z apps_mp3.c) — все 4 файла байт-в-байт.

Stage Summary:
- Деливерабл: download/n2600-tx-dac-mp3-fix/ (README-FIX.txt,
  n2600-fix9.patch, src/{ath9k_wifi,snd_hda,sound,apps_mp3}.c,
  kernel.bin) + .zip
- WiFi: корень — пустой ChainSel в TX-дескрипторе (PHY без цепи);
  запасной путь завершения по ISR на случай запаздывания status9.
- Звук: наушники — второй DAC 0x03 ALС269VB; бип громче на ~6 дБ.
- MP3: темп/стыки/DC-дыры устранены; полная тишина доп. объяснялась
  chans==0 — застрахованы; при повторе — просить serial старта MP3.
- Следующий шаг: полевой тест (WiFi-подключение, наушники, MP3); при
  «ушёл, но ACK нет» — эфирная отладка мощности/канала.

---
Task ID: 10
Agent: main (Z.ai)
Task: Итерация 10 — разбор полевого лога реального железа: WiFi «TxDone
(st1=1 st9=1)» + «AUTH: нет ответа точки»; звук «только в наушниках,
тихий, в динамиках нет»; «mp3 вообще не проигрывается (ползунок не
двигается)»

Work Log:
- WIFI: расшифровка st1=1 по ref_mac.h:468 — AR_FrmXmitOK=1: точка ACK-ит
  КАЖДЫЙ кадр (обе попытки, CCK 1M и OFDM 6M) — фикс [W-CHAINSEL]
  итерации 9 РАБОТАЕТ; проблема ушла на приём: юникаст-ответ (AUTH
  response) не доходит до парсера. Юникаст-RX никогда не был проверен
  (скан видит только маяки/бродкаст). Проверены и НЕ виноваты:
  ath_set_sta_id (STA_ID0/1 пишутся в bring-up), биты RX_FILTER
  (UCAST=0x1/PROM=0x20 подтверждены ath9k_rx_filter), KSRCH_MODE
  (Linux ставит так же), STA_ID1-маска, парсер AUTH-ответа wifi_core,
  buid кадра (30 б, alg=0/seq=1/status=0). Патч ath9k_wifi.c:
  [W-RXPROM-BSS] PROM в bss-фильтре (промискуитет мимо DA-фильтра,
  парсер фильтрует по BSSID); [W-RXDESC32] RX-кольцо 16->32 (спин TX
  до 30 мс + занятый канал = риск затирания ответа в кольце);
  [W-RXUCDIAG] лог первых не-маяков (fc/len/DA/rssi; 8 шт + 1/5 с) —
  решающая диагностика: fc=00b0 len=30 DA=<наш MAC> = ответ доходит
- ЗВУК: корень «только в наушниках» — итерация 6 ошибочно объявила бит 1
  глагола 0x70C резервным и писала 0x8000. Эталон snd_hda_codec.c
  (eapd_power_filter: eapd & 0x02) и HDA spec 7.3.4.11: EAPD = бит 1 =
  0x02. С итерации 6 внешний усилитель динамика ОБЕСТОЧЕН (наушникам
  EAPD не нужен). [HDA-EAPD2]: 0x70C=0x0002 на 0x14/0x21/0x1b/0x0F/0x10
  + чтение-контроль («EAPD чтение: 0x14=0002 ...»/«НЕ ВСТАЛ!»).
  [HDA-HPEN]: пин 0x21 = 0xC0 (OUT_EN|HP_EN, как Linux PIN_HP) — громче
  в наушниках. Оба DAC остаются на потоке 1 (динамики + наушники сразу)
- MP3: «ползунок не двигается» — latch task_spawned не сбрасывался при
  выходе задачи (после Stop/остановки ensure_task навсегда отказывался
  спавнить). [MP3-SPAWN]: сброс в конце mp3p_task, проверка результата
  task_spawn (telnetd итерации 7 добавил слоты-конкуренты), самолечение
  с логом. [MP3-DIAG]: serial-лог плеера (старт/EOF/первый кусок
  got=N/M ампл.=X stream_chunk=Y; отказ malloc). Дешифрованы строки
  лога «play: CBL=400/320/240/200» = sound_test_melody (480/600/800/960
  Гц @48к = 100/80/60/50 фреймов x 4 б) — тракт HDA/DMA жив
- Сборка: точечная (3 файла, -Wall -Wextra — 0 предупреждений) +
  bash build.sh -> kernel.bin 1249216 байт; загрузчик пересобран
- Патч n2600-fix10.patch (262 строки, 3 файла, 12 хунков) верифицирован
  patch -p1 на дереве поставки 9 — файлы совпали байт-в-байт

Stage Summary:
- Деливерабл: download/n2600-ucast-eapd-mp3-fix/ (README-FIX.txt,
  n2600-fix10.patch, src/{ath9k_wifi,snd_hda,apps_mp3}.c, kernel.bin) + .zip
- WiFi: TX+ACK подтверждены точкой; юникаст-RX — исправление через
  PROM + кольцо 32 + решающий лог «RX не-маяк»; если ответа нет даже
  в PROM — потери PHY/DMA, копать по CRC-счётчику окна
- Звук: возвращён EAPD=0x02 (усилитель динамика), HP_EN для громкости
  наушников; контроль чтением в логе init
- MP3: починен мёртвый UI после Stop (task_spawned latch) + полная
  диагностика пути декодер->DMA в serial
- Следующий шаг: полевой лог -> WiFi: наличие «RX не-маяк fc=00b0» и
  «AUTH ok» -> ASSOC/4-way; звук: «EAPD чтение: 0x14=0002» и динамики;
  MP3: строки [mp3] при Play/Stop/Play

---
Task ID: 11
Agent: main (Z.ai)
Task: Итерация 11 — полевой лог итерации 10: WiFi «точка ACK-ит, AUTH-ответ
не доходит»; звук «на всех выходах, но очень тихий» (диагноз пользователя:
NumSteps из caps[23:16], входные капсы параметром 0x0A); «mp3 не играется»
(в дампе нет строк [mp3]); «dmesg копируется только 16 КБ»

Work Log:
- WIFI [W-SEQ2] КОРЕНЬ всей истории «AUTH: нет ответа точки» найден:
  все 3 билдера кадров (mgmt/данные/EAPOL) писали Sequence Control как
  SC = tx_seq<<4 — по 802.11-2016 9.2.4.4.2 биты [15:12] это НОМЕР
  ФРАГМЕНТА, seq живёт в [11:0]. При tx_seq >= 0x100 (~256 mgmt-кадров:
  probe на каждый dwell, попытки подключения) старшие биты seq
  становились номером фрагмента: точка видела фрагмент без начала,
  буферизировала кадр, НЕ ОТВЕЧАЛА, но ACK-ила (ACK не разбирает SC) —
  точно то, что видно в логах итераций 5-11 (st1=1, ответа нет).
  Исправлено put_seq_ctrl(): frag=0, seq=tx_seq — в put_mgmt_hdr,
  wifi_net_send (данные) и wpa2_tx_eapol_eth (EAPOL).
- WIFI [W-AUTHWINDIAG]: снапшот stats на входе в каждую попытку
  AUTH/ASSOC, на таймауте дельта: «AUTH: окно 600 мс: кадров N (mgmt M,
  CRC K, прочих O) — mgmt шли / эфир шумит / эфир пуст» (wifi_stats_t
  + поле mgmt в wc_rx_frame для type-0 не-маяков).
- WIFI [W-RXUCDIAG2]: лимитер итерации 10 (8+1/5с) съедался чужими
  ACK/CTS ещё в скане. mgmt-кадры теперь отдельная категория: первые 16
  всегда, дальше 1/с, с DA/SA/BSSID («RX mgmt: fc=00b0 len=30 …»);
  данные/управление: 4 + 1/10 с.
- ЗВУК [HDA-GAIN2]: диагноз пользователя подтверждён эталоном
  ref_hda_verbs.h:282-294: Amp Cap = Offset[6:0]/NumSteps[14:8]/
  StepSize[22:16]/Mute[31], шаг=(поле+1)*0.25 дБ, gain(i)=(i-Ofs)*шаг.
  Прежде NumSteps брали из caps[23:16] (=StepSize): для NID 0x02
  (0x00025757: ofs=87, шагов=87, шаг=0.75 дБ) писался индекс 2 =
  -63.75 дБ. Теперь пишется NumSteps (макс усиления), mute-only ампы —
  unmute на 0. Входные капсы: параметр 0x0A (PCM!) -> 0x0D
  (AC_PAR_AMP_IN_CAP, ref_hda_verbs.h:136/141). hda_amp_decode() +
  подробный лог «амп-капсы=… (ofs, шагов, шаг дБ, mute) SetAmp=…».
- MP3 [MP3-KLOG]: строки [mp3] в дампе отсутствовали ПОТОМУ ЧТО
  mp3p_logf писал только в serial, мимо klog. Теперь klog + serial
  одной строкой; логи на мёртвых путях: rate=0 в старте задачи,
  Play без звукового потока.
- ЛОГИ: [KLOG64] KLOG_SIZE 16384->65536 (кольцо — корень «копируется
  только 16 КБ»); [W-LOGCHG] одинаковые per-channel строки bring-up
  (EEPROM board values / PDADC / Тайминги MAC) печатаются только при
  изменении (~5 КБ экономии на скан+подключение); [HDA-LOG2] «da]
  play:» — первые 2 за загрузку + всегда при stall LPIB.
- Сборка: точечная (5 файлов, -Wall -Wextra — 0 новых предупреждений)
  + bash build.sh -> kernel.bin 1251136 байт, загрузчики пересобраны.
- Патч n2600-fix11.patch (6 файлов, 24 хунка) верифицирован patch -p1
  на дереве поставки 10 — все файлы совпали байт-в-байт (cmp).

Stage Summary:
- Деливерабл: download/n2600-seq-amp-log-fix/ (README-FIX.txt,
  n2600-fix11.patch, src/{snd_hda,wifi_core.c,wifi_core.h,ath9k_wifi,
  apps_mp3,kernel}.c, kernel.bin) + .zip
- WiFi:_seq-bug объясняет «TX ok, ACK есть, ответа нет» через всю
  историю; диагностика окна AUTH покажет, если причина не только в нём
- Звук: ампы DAC на максимум (0 дБ) вместо -63.75 дБ; входные капсы —
  правильным параметром
- MP3: диагностика теперь попадает в dmesg; dmesg стал 64 КБ и
  компактнее
- Следующий шаг: полевой лог — WiFi до ASSOC/4WAY; громкость; строки
  [mp3] при Play/Stop/Play

---
Task ID: 12
Agent: main (Z.ai)
Task: Итерация 12 — полевой лог итерации 11: звук «громкость максимальная,
регуляция не работает, ползунок ни на что не влияет»; «mp3 играет лишь
фрагмент — затем пауза, play проигрывает ещё фрагмент»; WiFi «AUTH нет
ответа точки» (точка ACK-ит, окна AUTH: «кадров 13 (mgmt 0)»)

Work Log:
- ЗВУК [HDA-RING2] КОРЕНЬ ОБОИХ симптомов найден: snd_hda_stream
  «двух половин по LPIB» был гоночной — первый доводку куска надо было
  уложить в окно ~17 мс, декод на Atom занимает десятки мс; при промахе
  кусок писался в чужую половину, часть кольца оставалась тишиной,
  кольцо крутило СТАРЫЕ байты (новые куски и новая громкость в DMA не
  попадали) = «фрагмент-пауза-фрагмент» + «ползунок не влияет».
  Переписано на продюсер-потребитель: BDL 2x32КиБ, CBL=65536, DMA
  крутит сам; курсор записи g_wr_total / воспроизведения g_play_total
  (LPIB с учётом заворотов); огибание конца кольца; flow control
  (кольцо полно — ждём, до 500 мс); отстали — подтяжка к play+21 мс.
- ЗВУК [HDA-SWOWNER]: две «задача стартовала» = два потока плеера над
  одним HDA-потоком (писали одно кольцо, сбивали DMA паузами). Поток
  закреплён за задачей: чужой stream_chunk получает -2 + строка в
  dmesg; apps_mp3 гасит Play и печатает причину.
- ЗВУК [MP3-DIAG3]: выход mp3p_task ВООБЩЕ не логировался (смерть
  задачи невидима) — теперь «задача #N стартовала» / «задача #N
  завершена (quit=..)»; в «первый кусок» — время декода (декод=мс).
- ЗВУК [EXC-KLOG]: дампы исключений уходили только в serial, а
  пользователь копирует dmesg — смерти задач были невидимы. idt.c
  [PANIC-TASK] дублирует дамп в klog через НОВЫЙ klog_try_puts
  (kernel.c: одна попытка smp_trylock, без спина — из исключения
  спинить нельзя).
- WiFi [W-AUTH2] расшифровка окон AUTH: frames считает и маяки, mgmt —
  только не-маяки: в окнах «кадров 13 (mgmt 0)» = 8-13 МАЯКОВ, RX жив,
  точка маячит, AUTH ACK-ит — ответа нет; кадр корректен (FCS
  проходит, ACK есть). Остаются (а) игнор нашего MAC целиком (фильтр/
  бан после DEAUTH-штормов прежних сессий), (б) «AUTH только после
  probe». Новая стадия WIFI_CONN_PROBE перед AUTH: DEAUTH (reason 3) +
  НАПРАВЛЕННЫЙ probe request с SSID + окно 250 мс с счётом кастомных
  ответов (addr1=наш MAC) + вердикт в лог («точка ОТВЕЧАЕТ нам» /
  «НЕ отвечает и на probe: фильтр MAC / бан»). Решающая развилка.
- WiFi [W-AUTHDUMP]: раз за загрузку дамп всех 30 байтов AUTH REQ для
  сверки с захватом настоящего клиента. [W-AUTHWINDIAG2]: в окнах
  печатается дельта маяков, вердикт «маяки шли, НЕ-маяков mgmt НЕТ».
- ЛОГИ [W-LOGCHG2]: probe-кадры (fc=0040/0050) не печатаются никогда
  (~90% строк полевого лога), данные/управление 4+1/30 с; решающие
  mgmt (AUTH/DEAUTH/ASSOC/ACTION) — всегда.
- Сборка: точечная (7 файлов, -Wall -Wextra — 0 новых предупреждений)
  + bash build.sh -> kernel.bin 1254592 байт, загрузчики пересобраны.
- Патч n2600-fix12.patch (7 файлов, 24 хунка) верифицирован patch -p1
  на дереве поставки 11; пересборка из запатченного дерева дала
  kernel.bin, ПОБАЙТНО совпадающий с поставляемым (cmp).

Stage Summary:
- Деливерабл: download/n2600-ring2-auth2-fix/ (README-FIX.txt,
  n2600-fix12.patch, src/{snd_hda,apps_mp3,wifi_core.c,wifi_core.h,
  ath9k_wifi,kernel,idt}.*, kernel.bin) + .zip
- Звук: кольцо переписано (гарантия «не перезаписываем неигранное,
  не тишина при опоздании»), громкость применяется к каждому куску,
  второй плеер честно получает отказ; смерти задач видны в dmesg
- WiFi: следующее подключение даст РАЗВИЛКУ: «ответ на прямой probe
  есть» (копать AUTH-поля по дампу) или «ответа нет» (точка банит MAC:
  перезагрузить точку / проверить список клиентов)
- Логи: dmesg сжат в разы (пробы молчат), смерти задач видны
- Следующий шаг: полевой лог — MP3 без пауз + ползунок; WiFi строка
  «PROBE: ... ответов N» и вердикт; при «ответ есть» — сравнить дамп
  AUTH REQ с захватом настоящего клиента (Wireshark на другой машине)

---
Task ID: 13
Agent: main (Z.ai)
Task: Итерация 13 — полевой лог итерации 12: «все проблемы на месте» —
громкость не влияет даже на тест звука; mp3 «только треск»; WiFi не
подключается (лог: задача #1 len=2738608 и #2 len=1032192 = ДВА окна
плеера; «поток занят задачей #8 (вызов от #10)»; PROBE ответов 0; дамп
AUTH обрезан на 16 б)

Work Log:
- ЗВУК [MP3-SINGLE] ГЛАВНАЯ НАХОДКА: два окна плеера (второй двойной
  клик по MP3 открывал второе окно) = две задачи над одним HDA-потоком;
  задача #2, получив -2, гасила DMA задачи #1 через НЕЧЕЙНЫЙ
  pause(1)/stop() -> цикл «пауза чужака-рестарт» = «треск». Плеер стал
  СИНГЛТОНОМ: g_player + g_player_lock (s_lock); открытие MP3 поднимает
  существующее окно (НОВЫЙ wm_raise в wm.c — safe из чужого потока,
  trylock wm_glock 50 мс) и переставляет трек через mp3p_swap_track
  (тот же путь, что диалог); утечка data на отказе swap устранена.
- ЗВУК [HDA-SWOWNER2]: pause/stop HDA-потока из чужой задачи
  ИГНОРИРУЮТСЯ драйвером (гасить DMA может только владелец).
- ЗВУК [HDA-HWVOL]: «ползунок ни на что не влияет даже на тест звука» —
  слайдер крутил только софт-множитель при копии. Теперь мастер-громкость
  = АППАРАТНЫЙ выходной амп DAC 0x02 (87 шагов x 0.75 дБ, 100%=0 дБ /
  0%=−65 дБ) — ТОТ ЖЕ механизм, что поднял громкость в итерации 11
  (SetAmp=b057 доказанно работает на этом железе). g_hwvol_nid/nsteps
  заполняются в init из амп-капсов; софт-множитель держится на 100%;
  лог «[hda] громкость: N% (амп 02 индекс M из 87)». get_volume
  возвращает запрошенные проценты (g_volume_pct).
- WIFI: PROBE ответов 0 при ACK — точка игнорирует ВСЁ от нашего MAC
  (фильтр/бан/зависшая запись) — на стороне ТОЧКИ. Дамп AUTH REQ
  подтвердил корректность кадра. [W-AUTHDUMP2] буфер дампа 96->176
  (было 30 байтов -> видно 16). [W-AUTH2B] второй, ШИРОКОВЕЩАТЕЛЬНЫЙ
  probe через 120 мс (часть точек молчит на directed от чужого MAC).
  Рекомендации пользователю: перезагрузить точку / проверить фильтр
  MAC / РЕШАЮЩИЙ ТЕСТ — hotspot телефона (отделяет «ОС сломана» от
  «точка банит MAC 94:db:c9:a2:58:c1»).
- Сборка: точечная (5 файлов, -Wall -Wextra — 0 новых предупреждений)
  + bash build.sh -> kernel.bin 1256644 байт, загрузчики пересобраны.
- Патч n2600-fix13.patch (5 файлов, 14 хунков) верифицирован patch -p1
  на дереве поставки 12; пересборка из запатченного дерева ПОБАЙТНО
  совпала с поставляемым kernel.bin (cmp).

Stage Summary:
- Деливерабл: download/n2600-hwvol-single-fix/ (README-FIX.txt,
  n2600-fix13.patch, src/{snd_hda,apps_mp3,wm,wifi_core}.*, kernel.bin) + .zip
- Звук: плеер один, чужой pause/stop игнорируется, громкость —
  аппаратный амп DAC (действует на всё, доказанно рабочий путь)
- WiFi: код исчерпал софт-гипотезы; развязка через hotspot телефона
- Следующий шаг: полевой лог — громкость 30% на тесте звука + строка
  «[hda] громкость»; MP3 при переключении треков; WiFi после
  перезагрузки точки / hotspot телефона («PROBE: ... ответов N»)

---
Task ID: 14
Agent: main (Z.ai)
Task: Итерация 14 — полевой лог 13: USB-адаптер (RTL8192EU) подключается
ЦЕЛИКОМ (PREAUTH/PROBE/AUTH/ASSOC/WPA2-M1-M4/CAM/ключи) — стек доказан;
AR9285 по-прежнему «ACK есть, ответа нет»; пользователь исключил точку
(тот же MAC под Windows/Linux работает); присланный разбор MP3 (90% темп,
кольцо=1 кусок) относится к коду до итерации 12

Work Log:
- WIFI: факт сессии — на RTL8192EU ОС прошла AUTH->ASSOC->WPA2->ключи:
  билдеры кадров/SC/EAPOL-шифрование/машина состояний корректны; баг
  локализован в TX-пути AR9285. Проверены и сняты гипотезы: FCS (ath9k
  не считает FCS в SW — hw append, оба драйвера симметричны), ini-затирание
  STA_ID (ar9285_2_2_base — мёртвые данные; ath_set_sta_id вызывается
  в bring-up), RX-фильтр (rx_filter_bss с итерации 9/10 уже держит PROM).
- WIFI [W-BSSID]: новый op set_bssid(bssid, aid); AR9285 пишет
  AR_BSS_ID0/1 (прежде ff:ff ВЕЧНО — матчинг «unicast mgmt из моей
  BSS» был невыполним), RTL — заглушка. Контрольный дамп STA_ID0/1 +
  FILT в той же строке лога (ловит затирание регистров).
- WIFI [W-RATELADDER]: AUTH 2 -> 5 попыток: 1M/11M/2M/5.5M/6M (у
  подключающегося RTL mgmt на 11M).
- WIFI [W-RXLAT]: зазор «TxDone -> первый принятый кадр» (wc_tx_done_note
  из owl_tx_frame + wc_rx_gap_check; первые 4 замера) — последняя
  софт-гипотеза: окно глухоты RX после TX (ответ точки приходит через
  ~50-100 мкс, ретраи ~5 мс).
- WIFI: решающий эксперимент в README — снифф эфира со второй машины
  (монитор + Wireshark) во время попытки AR9285: уходят ли кадры, FCS,
  отвечает ли точка.
- MP3 [MP3-SPAWN2]: окно двойного спавна в ensure_task закрыто
  (task_spawn_tick, 500 мс); [MP3-DIAG4]: diag-флаги перенесены из
  static в mp3p_t (per-instance), -1 от stream_chunk логируется.
- Отмечено: DHCP на RTL — следующий рубеж (bcast GTK-TKIP DISCOVER без
  OFFER при рабочем юникасте); [task_lock] STUCK и фантомный вектор #0 —
  отдельная тема.
- Сборка: точечная (5 файлов, -Wall -Wextra — 0 новых предупреждений)
  + bash build.sh -> kernel.bin 1257188 байт.
- Патч n2600-fix14.patch (5 файлов, 12 хунков) верифицирован на дереве
  13; пересборка ПОБАЙТНО совпала (cmp).

Stage Summary:
- Деливерабл: download/n2600-bssid-mp3diag-fix/ (README-FIX.txt,
  n2600-fix14.patch, src/{wifi_core.h,wifi_core.c,ath9k_wifi,rtl8192eu,
  apps_mp3}.*, kernel.bin) + .zip
- WiFi: стек доказан подключением RTL; AR9285 — BSS_ID в железо,
  лесенка 5 рейтов, зазор TX->RX; решающий шаг — снифф эфира
- MP3: разбор пользователя верен для кода до итерации 12; новое кольцо
  (flow control) уже реализует его рекомендацию; добавлена его
  диагностика (per-instance, -1, окно спавна)
- Следующий шаг: полевой лог 14 (BSS_ID/PROBE/зазор/окна AUTH); при
  «ответа нет» — снифф; DHCP на RTL после подключения

---
Task ID: 15
Agent: main (Z.ai)
Task: Итерация 15 — полевой лог 14: WiFi «подключения всё еще нет, даже к
открытой точке»; MP3 «играет, громкость меняется, но сильно трещит и
кажется быстрее — поднять приоритет плеера?»

Work Log:
- ОБНАРУЖЕНО И ИСПРАВЛЕНО: рабочее дерево work/src ОТКАТИЛОСЬ (snd_hda,
  sound, task, timer, wm, idt, ath9k_wifi, rtl8192eu, wifi_core.h — версии
  до итераций 8-14; wifi_core.c/apps_mp3/kernel совпадали с старыми).
  Восстановлено копированием поставок в хронологическом порядке
  (snd-wifi -> bssid-mp3diag); контроль: пересборка из восстановленного
  дерева дала kernel.bin, ПОБАЙТНО равный kernel.bin поставки 14 (cmp) —
  полевой лог 14 собран именно из этого кода.
- ЗВУК [HDA-RATE]: поток HDA был всегда 48к (файл 44.1 через
  программный ресэмплер). Теперь нативный формат по частоте файла:
  hda_fmt_for_rate (44.1к=0x4011; кодирование base/mult/div — по
  Linux hda_codec.h AC_FMT_*), формат в SDxFMT + verb 0x2 в конвертер
  DAC; beep возвращает конвертер в 48к; snd_hda_stream_set_rate()/
  sound_stream_set_rate(); плеер запрашивает p->rate в старте задачи;
  не выражаемые (8к) — откат 48к + ресэмпл. Лог «da] stream: fmt=4011
  (44100 Гц)».
- ЗВУК [HDA-CURSOR2] ГЛАВНАЯ причина треска: play-курсор = сумма
  LPIB-дельт, LPIB — mod кольцо: сон производителя дольше круга терял
  k*65536 байт, play занижался, «подтяжка» wr к play+запас выбрасывала
  НЕИГРАННЫЕ куски (повторы/скачки = треск и «быстрее»). Число кругов
  восстанавливается по стенному времени (elapsed*байт/мс при RUN=1,
  пауза не считается, k<=16). Таймаут flow-control 500 мс теперь НЕ
  пишет поверх неигранного: пропуск куска (-3) + лог «кольцо полно
  >500 мс» раз в секунду.
- ЗВУК [MP3-PRIO]: предложение пользователя — задача плеера в
  TASK_PRIO_UI (task_spawn_prio); безопасно при декоде ~7% CPU.
- WIFI [W-HEARDCONN]: из лога 14 — маяки HomeWifi (DS ch 1, -61..-73)
  ловились ТОЛЬКО на dwell ch 2 во всех сканах; PREAUTH ch 1 — 0 маяков
  в двух окнах; TX с ch 1 — без ACK; при этом TP-Link_697B (DS ch 2)
  сильнее всего именно на своём канале, ch4/10/12/13 честные =
  приёмник/настройка каналов корректны. Вывод: точка передаёт не там,
  где заявляет DS IE (mesh/репитеры). Канал подключения выбирается по
  гистограмме маяков (heard[1..14]), DS — только при маяках на нём;
  в PREAUTH при 0 маяков — одно окно на альтернативном канале из
  гистограммы, потом полный bring-up. Логи: «точка DS ch N, но маяки
  ловились на ch M», «PREAUTH: пробую ch M».
- Отмечено в README: открытые сети в логе все -104..-110 дБм (порог
  чувствительности) — к ним подключение не обязано получаться.
- Сборка: точечная проверка 4 файлов + bash build.sh -> kernel.bin
  1 259 112 байт; -Wall -Wextra — 0 новых предупреждений.
- Патч n2600-fix15.patch (5 файлов, 20 хунков) верифицирован
  patch -p1 --fuzz=0 на базе (snd_hda/sound из 13/8, wifi_core/apps_mp3
  из 14): все файлы совпали байт-в-байт (cmp).

Stage Summary:
- Деливерабл: download/n2600-hdarc-heardconn-fix/ (README-FIX.txt,
  n2600-fix15.patch, src/{snd_hda,sound.c,sound.h,apps_mp3,wifi_core}.*,
  kernel.bin) + .zip
- Звук: нативный 44.1 кГц (ровный ход), курсоры кольца с восстановлением
  кругов по времени (без порчи неигранного), плеер в UI-приоритете
- WiFi: подключение по факту приёма маяков — обход вранья DS IE у
  mesh-точек; честные точки не затронуты
- Следующий шаг: полевой лог 15 — строки «da] stream: fmt=4011»,
  треск/громкость MP3, «точка DS ch N, но маяки ловились на ch M»,
  вердикт PROBE и окна AUTH на канале маяков

---
Task ID: 16
Agent: main (Z.ai)
Task: Итерация 16 — полевой лог 15: WiFi ДОШЁЛ ДО PROBE (точка ответила!)
но AUTH ACK-ится без ответа (5 рейтов); MP3 44.1 стартовал (fmt=4011),
но «часть файлов с треском, часть сразу на паузу»; прислана полная
IE-раскладка точки (Ralink RT2860, WPS, VHT-IE = анализатор смешал)

Work Log:
- WIFI [W-SEQ3] КОРЕНЬ НАЙДЕН В ДАМПЕ ПОЛЬЗОВАТЕЛЯ: AUTH REQ байты
  22/23 = «03 00» = SC 0x0003 = ФРАГМЕНТ 3, последовательность 0.
  «Правка» [W-SEQ2] (итер. 12) сама перепутала порядок полей SC
  (802.11 9.2.4.4.2: [3:0]=frag, [15:4]=seq; на проводе byte22 =
  (seq&0xF)<<4|frag, byte23 = seq>>4). Кадр с «фрагментом 3 без первого
  фрагмента» точка честно ACK-ит (ACK не разбирает SC) и отбрасывает —
  вся история «AUTH ACK-ится — ответа нет» с итерации 5. До [W-SEQ2]
  код писал только младший байт (seq mod 16 = дубликаты) — тот же
  симптом. Исправлено: sc = (seq&0xFFF)<<4; f[22]=sc&0xFF; f[23]=sc>>8;
  юнит-тест seq=3 -> «30 00», seq=0x123 -> «30 12».
- WIFI [W-DACHK]: AUTH/ASSOC-ответы принимались без проверки DA — в
  окнах лога 15 шли AUTH/ASSOC соседа 68:c4:4d:... с тем же BSSID.
  Добавлена проверка DA == наш MAC в оба матчера.
- WIFI [W-MACROT]: после исчерпания лесенки 5 рейтов AUTH без ответа —
  наш MAC ОДИН раз меняется на локальный 02:xx (LCG от таймера),
  ops->set_mac пишет STA_ID0/1 AR9285, цикл PREAUTH->PROBE->AUTH
  повторяется. RTL в 14 прошёл весь путь именно с локальным MAC.
  mac_rotated сбрасывается на новое подключение; у RTL — заглушка.
- ЗВУК [HDA-IOCOFF]: IOC=0 в BDL + SIE не включаем (линия IRQ держалась
  BCIS и не гасилась в игре — риск шторма/джиттера; позиция и так
  polled по LPIB).
- ЗВУК [HDA-441CHK]: Set Converter Format + чтение обратно (verb 0xA);
  кодек не принял формат -> откат 48к + лог. Различает «кодек не умеет
  44.1» и «треск по другой причине».
- ЗВУК [HDA-HEALTH]: раз в 5 с «da] поток: lead=N мс, ждём-полно=N,
  пропусков=N, кругов восстановлено=N» — следующий лог однозначно
  покажет, кольцо или что-то ещё.
- ЗВУК [MP3-DIAG5]: «сразу на паузу» = EOF на первом куске — лог до 3
  раз с магией первых 4 байт файла (ID3x/FF Fx).
- Пользователю разъяснено: файл уже целиком в ОЗУ (буфер плеера), вход
  не узкое место.
- Сборка: точечная + bash build.sh -> kernel.bin 1 260 264 байт;
  -Wall -Wextra — 0 новых предупреждений (2 предупреждения — старые).
- Патч n2600-fix16.patch (6 файлов, 24 хунка) верифицирован
  patch -p1 --fuzz=0 на базе (15: snd_hda/sound/apps_mp3/wifi_core;
  14: wifi_core.h/ath9k_wifi/rtl8192eu): все файлы байт-в-байт (cmp).

Stage Summary:
- Деливерабл: download/n2600-seq3-macrot-fix/ (README-FIX.txt,
  n2600-fix16.patch, src/{snd_hda,sound.c,sound.h,apps_mp3,wifi_core.*,
  ath9k_wifi,rtl8192eu}.*, kernel.bin) + .zip
- WiFi: SC исправлен по стандарту (frag=0 всегда) — ожидаем «AUTH ok»;
  страховка — ротация MAC; чужие ответы больше не принимаются
- Звук: IRQ потока выключены, 44.1 подтверждается конвертером,
  health-строка потока, диагностика EOF-файлов
- Следующий шаг: полевой лог 16 — «AUTH ok — посылаем ASSOC REQ»,
  WPA2/4WAY, строки «da] поток: lead=...», вердикт по треску,
  магия EOF-файлов; при подключении — DHCP и браузер

---
Task ID: 17
Agent: main (Z.ai)
Task: Итерация 17 — полевой лог 16: health-строка «lead=360 мс стабильно,
ждём-полно +27/5с (=1/кусок), пропусков 0, кругов 0» — кольцо ИДЕАЛЬНО,
а хрип остаётся; WiFi: HEARDCONN увёл на ch2 (маяки громче) — и там ни
один наш кадр не дошёл (probe без ACK); SC исправен («30 00» в дампе)

Work Log:
- WIFI [W-HEARDCONN-2] РАЗВИЛКА ЛОГОВ 15/16 РАЗРЕШЕНА: лог 15 (DS ch1) —
  probe-ответ ПОЛУЧЕН; лог 16 (ch2, маяки x4 громче) — probe вообще без
  ACK. Приём и передача точки живут на DS-канале; громкость маяков на
  соседнем канале — свойство её излучения, не канал её RX. Подключение
  СТРОГО на DS; гистограмма маяков — в лог; heard-канал — только
  фолбэк PREAUTH при полном нуле на DS (этап 1 из итерации 15).
- ЗВУК [SND-STREAMTEST] РЕШАЮЩИЙ ЭКСПЕРИМЕНТ: кольцо доказанно здорово,
  beep чист — осталась развилка «HW-тракт потока vs содержимое MP3».
  Кнопка «Тест звука»: мелодия + ~6с синуса через ИМЕННО потоковый путь
  (кольцо+DMA+SD_FMT), фазы 44.1к и 48к, сигнал — целочисленный NCO
  (Q15, без FPU/декода). Чисто = содержимое MP3 (файл/декод); хрип =
  HW-тракт, с указанием частоты. Контрольные суммы кусков в dmesg
  ([sndtest] cs=...). sound_stream_test() в sound.c, кнопка в apps.c.
- ЗВУК [MP3-FILECHK] целостность ФАЙЛА при старте трека: проход по
  MPEG-заголовкам (ID3v2 skip; таблицы битрейтов MPEG1/2/2.5; длины
  кадров 144/72*br/sr+pad): «файл цел: кадров N, десинков 0» или
  «ФАЙЛ ПОРЧЕН?: десинков M из T, первый @ X (%512, %4096)» —
  порча на границах секторов/кластеров видна по регулярности смещений.
  Подозрительные размеры из логов: 524288 (ровно 512К!), 811008
  (кратно 512) — файлы идут с NTFS-тома SSD.
- ЗВУК [MP3-CHUNKCHK] контрольные суммы первых 3 кусков декода
  (mp3p_t.chunk_n): повторное воспроизведение того же файла даёт те же
  суммы = декод детерминирован; разные = FPU топчется (сделаем
  fxsave/fnsave).
- Сборка: точечная + bash build.sh -> kernel.bin 1 262 728 байт;
  -Wall -Wextra — 0 новых предупреждений.
- Патч n2600-fix17.patch (5 файлов, 9 хунков) верифицирован
  patch -p1 --fuzz=0 на базе 16 (+apps.c term-telnet): все файлы
  байт-в-байт (cmp).

Stage Summary:
- Деливерабл: download/n2600-heardconn2-sndtest/ (README-FIX.txt,
  n2600-fix17.patch, src/{apps,apps_mp3,snd_hda,sound.c,sound.h,
  wifi_core}.*, kernel.bin) + .zip
- WiFi: DS-канал снова основной (точка слышит нас только там);
  SC/DA/MACROT из 16 остаются
- Звук: развилка HW-vs-содержимое в одном нажатии («Тест звука»);
  целостность файла и детерминизм декода — в логе
- Следующий шаг: полевой лог 17 — [sndtest] вердикт по фазам,
  «файл цел/ПОРЧЕН», cs кусков, «AUTH ok» на DS; при подключении — DHCP

---
Task ID: 18
Agent: main (Z.ai)
Task: Итерация 18 — разбор лога 17: звук (кольцо 64К мало, старт без запаса,
хрупкий счёт кругов LPIB), MP3 «сразу на паузу» (NTFS читает только VCN=0),
WiFi SC «03 00» (сверка — исправлено в 16)

Work Log:
- ЗВУК [HDA-RING256]: кольцо 65536 -> 262144 байт (8 BDL-записей по 32 КиБ,
  CBL=262144, LVI=7) — запас ~1.4 с против прежних ~340 мс: WiFi-скан
  (bring-up'ы 60-114 мс x 14 каналов)/декод/планировщик больше не выедают
  lead, DMA не убегает за курсор записи
- ЗВУК [HDA-PREFILL]: RUN больше не ставится первым куском (186 мс):
  первый вызов stream() конфигурирует BDL/FMT и СТОИТ; RUN — при
  >= 96 КиБ или через 250 мс (какой раньше); armed-состояние + защита
  pause(0)/stop(); в логе «RUN после предзаполнения N КиБ (M мс)»
- ЗВУК [HDA-LPIB64]: wall-оценка числа кругов — точная 64-битная формула
  elapsed*rate*4/1000 (прежде bpm=(rate/1000)*4 обрезал 44.1к до 176
  байт/мс — дрейф 0.9% портил оценку k: завышение = запись поверх
  играемого, занижение = «кольцо полно» навсегда); инвариант play<=wr
- ЗВУК [HDA-UNDERRUN]: при подтяжке wr к play+запас пропускаемый участок
  гасится в тишину (hda_mute_range, огибание стыка) — недобор = чистая
  пауза вместо треск-повтора; health-строка + «гашений=N», lead в точных мс
- NTFS [NTFS-EXT]: причина «некоторые MP3 сразу на паузу» — у
  фрагментированных файлов $DATA разнесён по MFT-записям через
  $ATTRIBUTE_LIST, драйвер читал только базовый экстент (VCN=0), файл
  обрывался (524288/811008 байт в логах) -> EOF -> пауза. Добавлено:
  ntfs_ext_t/g_exts/g_ext_runs, load_data_extents() (базовый + расширения,
  проверка стыка lowest=highest+1, громкий лог обрыва), runs_open_multi,
  runs_next с переходом между экстентами (lcn с 0 в каждой записи),
  буфер 16x1 КиБ в ntfs_init_ex. РАСКЛАДКА СВЕРЕНА С ЭТАЛОНАМИ: ntfs-3g
  (ntfs_mapping_pairs_decompress_i: lcn=0 на каждой записи) и ntfs3
  (run.c: prev_lcn=0 на каждый буфер) — цепочка офсетов ПЕРЕЗАПУСКАЕТСЯ,
  первый офсет экстента — абсолютный LCN; экстенты независимы
- WIFI: проверен весь тракт SC: [W-SEQ3] put_seq_ctrl верна
  (байт22=(seq&0xF)<<4, байт23=seq>>4), все 3 построителя кадров через
  неё, других записей в f[22]/f[23] нет; RTL txdw3 переносит 12-битный
  seq согласованно; AR9285 STA = AR_STA_ID1_PRES_SEQNUM (SC кадра
  сохраняется). «03 00» из лога 15 — сборка до [W-SEQ3]; лог 16 показал
  «30 00». В README зафиксировано: если AUTH опять ACK-ится молча —
  дамп AUTH REQ + окна AUTH
- Сборка: точечная + bash build.sh -> kernel.bin 1 266 696 байт;
  -Wall -Wextra — 0 новых предупреждений (2 старых в нетронутых местах)
- Патч n2600-fix18.patch (2 файла, 18 хунков) сгенерирован против
  реконструированной базы 17 (scripts/make_base17.py: ntfs.c — обратные
  замены, snd_hda.c — из поставки 17); верифицирован patch -p1 --fuzz=0:
  оба файла байт-в-байт (cmp), обратное применение чисто

Stage Summary:
- Деливерабл: download/n2600-ring256-ntfsext/ (README-FIX.txt,
  n2600-fix18.patch, src/{snd_hda.c,ntfs.c}, kernel.bin) + .zip
- Звук: запас 1.4 с, старт с предзаполнением, точный LPIB-64, недобор =
  пауза; ждать «RUN после предзаполнения» и health с гашениями
- MP3: фрагментированные файлы читаются целиком (до 16 экстентов)
- WiFi: SC исправен с ядра 16; следующий шаг — AUTH ok -> ASSOC -> 4WAY
- Следующий полевой лог: вердикт по треску (lead/гашения), играли ли
  «встававшие» файлы, окна AUTH

---
Task ID: 19
Agent: main (Z.ai)
Task: Итерация 19 — ESP32-инструмент по запросу пользователя: сниффер с точкой
доступа для полной диагностики WiFi-диалога нетбука, вывод в UART на ПК

Work Log:
- Написана прошивка download/esp32-wifi-sniffer/esp32_wifi_sniffer/
  esp32_wifi_sniffer.ino (~1170 строк, Arduino/PlatformIO, любой ESP32):
  * Режим `mode ap`: SoftAP (SSID HomeWifi, OPEN/WPA2 командой sec, канал
    командой ch) + promiscuous-сниффер на том же канале — изолированный
    стенд «нетбук <-> ESP32», телефон подключается как эталон
  * Режим `mode sniff <ch>`: пассивный монитор канала реального HomeWifi —
    видны ОБЕ стороны (статусы AUTH RSP/ASSOC RESP роутера, его EAPOL M1/M3)
  * Парсер 802.11: FC/флаги (RETRY подсвечен), SC с правильной раскладкой
    seq/frag (проверка W-SEQ3: frag!=0 в mgmt -> громкий маркер бага),
    AUTH alg/txn/status, ASSOC cap/listen_int/IEs (SSID, rates, RSN с
    расшифровкой cipher/AKM, HT, vendor), BEACON/PROBE, DEAUTH/DISASSOC
    reason-имена, ACTION; DATA: QoS, LLC/SNAP, ethertype, EAPOL с
    классификацией M1-M4 по keyinfo-битам + replay/nonce; hex-дампы
  * События esp_event: AP STACONNECTED/STADISCONNECTED (+reason на IDF5),
    PROBEREQ (маска WIFI_EVENT_MASK_NONE снята), DHCP IP
  * Скорость приёма каждого кадра из rx_ctrl (rate/sig_mode/mcs/rssi/канал)
  * Авто-трекинг MAC нетбука; фильтры foreign/beacons/hex/rssi; команда
    learn (30 c показывать всё); RAM-кольцо 32 строк (dump); stat-хартбиты
  * Бинарный режим `pcap 1`: посылки AA55+len(u16)+seq(u16)+meta(16B)+
    payload+crc8 -> serial_capture.py собирает dump.pcap (radiotap
    FLAGS+FCS-present и DBM_ANTSIGNAL, LINKTYPE 127) для Wireshark
  * Опция AP_FIX_RATE (выкл по умолч.): форс unicast AP->STA 1 Мбит/с через
    esp_wifi_internal_set_fix_rate (под guarded __has_include)
- Написан download/esp32-wifi-sniffer/serial_capture.py (pyserial): режим
  text (лог+консоль) и pcap (ресинк по AA55, sanity по длине, crc8-контроль,
  счётчики потерь по seq, pcap-записи)
- README.md: сборка (Arduino IDE/PlatformIO/esptool), команды, сценарий A
  (нетбук<->ESP32) и B (пассивно нетбук<->реальный роутер), чек-лист
  «на что смотреть» (SC/frag, RETRY, скорости, RSN-сравнение, цепочка
  EAPOL, deauth-причины 2/7/15/23), справочная последовательность здорового
  подключения; platformio.ini
- Верификация scripts/check_sniffer.py: py_compile serial_capture.py OK;
  round-trip «emitPcap(.ino) -> парсер serial_capture.py» на AUTH REQ
  (SC=30 00) — поля совпали, ресинк после текста в UART работает, crc-контроль
  чистый; radiotap 10 байт (present 0x22); баланс скобок .ino OK;
  в emitPcap исправлена раскладка len (18+caplen, crc поверх seq+meta+payload)

Stage Summary:
- Деливерабл: download/esp32-wifi-sniffer/ (README.md, platformio.ini,
  serial_capture.py, esp32_wifi_sniffer/esp32_wifi_sniffer.ino) + .zip
- План полевых работ: (A) прошить ESP32, подключить нетбук к его «HomeWifi»
  и телефоном сделать эталон; (B) mode sniff <канал HomeWifi> и снять
  диалог с реальным роутером; первое расхождение = место бага
- Ключевые маркеры в дампе: frag!=0/seq=0 -> снова байты SC; RETRY на
  AUTH REQ -> нетбук не слышит ответ; EAPOL M1 без M2 -> wpa2.c;
  DEAUTH reason 15 -> ключи не установились; [EVT] STADISCONNECTED reason

---
Task ID: 20
Agent: main (Z.ai)
Task: Исправить ошибку компиляции сниффера на ESP32 у пользователя (esp_netif.h: No such file or directory); сделать AP "esp32test" + сниффер с отсевом чужих кадров

Work Log:
- Причина ошибки: у пользователя Arduino-ESP32 core 1.0.x (toolchain
  xtensa-esp32-elf-gcc 1.22.0-80-g6c4433a-5.2.0 = IDF 3.2, ARDUINO=10819);
  esp_netif.h появился только в core 2.x/IDF4. Аналог в 1.0.x -
  tcpip_adapter.h, но скетчу он не нужен вовсе
- Написан download/esp32-wifi-sniffer/esp32_ap_sniffer_v2.ino:
  только #include <Arduino.h>, <WiFi.h>, <esp_wifi.h> (совместимо с
  core 1.0.x и 2.x), без esp_netif/esp_event; события опрашиваются
  через WiFi.softAPgetStationNum()
- AP "esp32test" (открытый по умолчанию, канал 6, опция WPA2 через
  AP_PASS) + promiscuous-сниффер на том же канале
- SMART-фильтр чужих кадров: ведёт apMac + автообучение до 4 STA MAC
  (по probe-req с нашим SSID и по mgmt к нашему BSSID); MGMT чужих
  сетей, их биконы и DATA отсеиваются; режим 'f' - ALL (сырой эфир)
- Проверка [W-SEQ2] в эфире: frag!=0 в PROBE/AUTH/ASSOC REQ от STA ->
  громкий маркер с правильной раскладкой SC (byte22=(seq<<4)|frag)
- Разбор кадров: AUTH alg/txn/status, ASSOC REQ/RESP, REASSOC,
  DEAUTH/DISASSOC reason-имена, PROBE/BEACON (SSID, chan, RSN/WPA),
  wep-флаг на открытом AP; hex-дампы (бикон без hex); CTRL ACK
  распознаётся по A1==apMac ("ACK->AP-frame")
- Команды: h/? f c r; baud 115200 (опция 921600); SNIFF_ONLY 1 -
  второй ESP32 чистым сниффером (полный захват обеих сторон)
- Ограничение задокументировано: ESP32 не видит собственные TX-кадры
  (resp от AP невидимы); диагностика через запросы STA + его ACK-и
- Верификация: баланс скобок/кавычек кода OK; в коде 0 вхождений
  esp_netif/esp_event/tcpip_adapter

Stage Summary:
- Деливерабл: download/esp32-wifi-sniffer/esp32_ap_sniffer_v2.ino
  (заменить содержимое esp32sniffer.ino у пользователя)
- Интерпретация лога: ACK после req есть -> AP ответил; RETRY=1 на
  повторе req без ACK -> ответ не дошёл/не разобран; seq=0 frag=N ->
  [W-SEQ2] не применён во всех местах TX; AUTH alg=1/wep=1 ->
  неверный режим в конфиге нетбука; DEAUTH reason 15 -> 4-way таймаут
- Следующий шаг: снять лог ассоциации нетбук<->ESP32 и сравнить SC
  всех исходящих кадров N2600-OS с эталонной раскладкой

---
Task ID: 21
Agent: main (Z.ai)
Task: Разобрать полевой лог ESP32-сниффера (assoc с esp32test), найти и исправить причину молчания точки на AUTH

Work Log:
- Лог сниффера (7 кадров: 2 PROBE REQ + 5 AUTH): фикс [W-SEQ2]
  ПОДТВЕРЖДЁН В ПОЛЕ — SC чистый (байты 00/10/20/30/40/50/60 00,
  seq=0..6, frag=0)
- НО: тело AUTH на проводе = 00 00 00 00 XX XX, т.е. alg=0, txn=0,
  status=мусор (2A 00 / C0 87 / B4 FF / 2A 00 / B3 7D), хотя билдер
  tx_auth_req() шлёт alg=0, txn=1, status=0 (сверено с исходником и
  [W-AUTHDUMP]) → точка ACK-ит, но молча отбрасывает = вся история
  «AUTH ACK-ится — ответа нет»
- Во ВСЕХ кадрах (AUTH 30Б, PROBE 32Б/41Б) порчен ровно ПОСЛЕДНИЕ
  4 байта (у PROBE — IE Supported Rates: 82 84 8B 96 -> мусор)
- FCS-гипотезы опровергнуты численно (crc32 по префиксу/интендед
  кадру не совпадает с хвостом; хвост AUTH#1 == AUTH#4 при разных
  префиксах — хвост не функция кадра) → хвост = мусор окна FCS PCU
- Скачан эталон ath9k v6.6 (xmit.c, ar9002_mac.c, mac.h):
  xmit.c:2293/2938 «framelen = skb->len + FCS_LEN» при
  buf_len = skb->len → AR_FrameLen (ctl0) включает авто-FCS
- БАГ [W-FCSLEN]: owl_tx_frame писал ctl0 = ctl1 = len (без FCS) →
  PCU передавал (FrameLen-4) байт данных, хвост 4 байта замещался
  мусором. Для AR9485 то же в sowl_tx_frame ctl11 (все прежние
  полевые итерации)
- ПАТЧ в work/src/src/ath9k_wifi.c: #define WIFI_FCS_LEN 4;
  owl ctl0 = ((len+4) & TXD_FrameLen) | ...; sowl ctl11 =
  ((len+4) & 0x0FFF) | ...; BufLen не тронут. checksum sowl (ctl10)
  не затронут (ctl11 не входит в сумму), ctl3/buf_len корректен
- Отмечено в комментарии: для keyidx>=0 (шифрованные data) возможно
  нужен учёт хвоста криптодвижка (MIC/ICV) — сверить длину на эфире
  сниффером после завершения 4-way (CCMP: IV уже в кадре от SW,
  сессия 51-52)

Stage Summary:
- Причина НЕРАБОТАЮЩЕГО WiFi найдена окончательно: FrameLen без FCS
  портил последние 4 байта КАЖДОГО исходящего кадра → точки видели
  alg=0/txn=0/status=мусор и молча отбрасывали AUTH
- Патч [W-FCSLEN] применён (owl + sowl); следующий шаг: пересборка
  build.bat, тест с esp32test (открытая) — ожидание: AUTH txn=1 на
  эфире, ответ точки, ASSOC, CONNECTED; затем WPA2 + проверка
  шифрованного data-пути сниффером
- Доставка исходников по запросу пользователя: download/n2600-os-src-wfcslen.zip
  (13 МБ, дерево без .git/объектов, src/ath9k_wifi.c с [W-FCSLEN]);
  залито на tmpfiles.org (60 мин):
  https://tmpfiles.org/dl/wqAjV6kWH9LW/n2600-os-src-wfcslen.zip
  (зеркала litterbox/catbox недоступны: 500 / Invalid uploader)

---
Task ID: 22
Agent: main (Z.ai)
Task: Разбор полевых логов (ESP32-сниффер + нетбук) после [W-FCSLEN]: AUTH прошёл, ASSOC-RESP теряется; патчи [W-HWACK], [W-ASOCDBG]

Work Log:
- Сниффер: AUTH STA->AP теперь ЧИСТЫЙ на эфире (txn=1 status=0, FCS валиден) — [W-FCSLEN] подтверждён полем; PROBE-REQ тоже целы (SSID+rates); [W-SEQ2] держится (seq=0..3, frag=0). Точка ACK-ит, AUTH-RESP принят нетбуком («AUTH ok»)
- ESP32 «mismatch or invalid event, id=63» исследован (esp-idf#2916): mesh-событие, утекает в IDF 3.x при обработке станции softAP, официально безвредно («just ignore it»); 6 событий = 6 обработанных ASSOC-REQ
- «AP: stations=1» печатается периодической (1 с) проверкой при изменении — тайминговая загадка снята: точка АССОЦИИРОВАЛА нас (станция в списке => ASSOC-RESP уходил)
- Нетбук: матчер ASSOC-RESP в conn_handle_mgmt корректен; «mgmt 2/6/4/3» в окнах = пробы соседей (считаются stats.mgmt, но не печатаются — is_probe исключён в [W-LOGCHG2]); кольцо RX 32 дескриптора; юникаст-RX доказан (AUTH-RESP — DA=мы — принят)
- Причина найдена [W-HWACK]: RXF_PROM в BSS-фильтре запрещает PCU аппаратные ACK — ответы точки уходили в ретраи без подтверждений; ath_set_mac уже программирует STA_ID0/1
- Патчи: [W-HWACK] ath9k_wifi.c ath_rx_filter_bss — убран RXF_PROM; [W-ASOCDBG] wifi_core.c — dbg_bss/dbg_tome/dbg_asp, безтроттлинговая печать любого assoc-resp от BSSID (status/aid/retry + hex), дельты в строке окна, сбросы на входе в окна (4 точки)
- Проверено grep-ом: PROM остался только в сканере (ath_rx_start, ath_rx_filter_promisc)

Stage Summary:
- Цепочка: PROBE ok -> AUTH ok -> НОВЫЙ фронт: ASSOC-RESP не доходит до парсера, хотя точка ассоциирует
- Ожидание следующего лога: «ASSOC-RSP от точки: ... status=0 aid=...» + «ASSOC ok: AID=...», в сниффере — ACK->AP-фреймы от 94:db:c9:a2:58:c1 (признак работы [W-HWACK])
- Открыто: [NTFS-EXT]; [W-TXBLK] (TX busy-wait блокирует опрос RX до 30/300 мс при сбоях) — отложено
