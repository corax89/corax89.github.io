/* apps_browser.c — веб-браузер N2600-OS.
 *
 * Возможности:
 *   - АДРЕСНАЯ СТРОКА: клик по ней или Ctrl+L — редактирование;
 *     Enter / кнопка «Go» — переход. Поддерживаются:
 *       http://host/path        — HTTP GET (в потоке ЭТОГО окна);
 *       имя файла               — открытие файла из RAM disk
 *                                 (readme.txt, help.md, demo.js...);
 *       www.host/path           — автоматически как http://.
 *   - HTTP GET запрос (net_http_get), выполняется в потоке окна:
 *     зависший запрос больше не блокирует систему и другие окна.
 *   - HTML -> Markdown конвертер (htmlconv.c) + рендеринг Markdown.
 *   - Прокрутка (PgUp/PgDn/стрелки/колёсико).
 *   - Сессия 67: кнопка Save (или Ctrl+S) — сохранить открытую страницу
 *     (Markdown/текст) в RAM disk под именем из адреса; существующие
 *     файлы не перезаписываются (подбирается свободное имя).
 *
 * Исправления аудита (реализованы в htmlconv.c и здесь):
 *   [H1] бесконечный цикл in_tag — см. htmlconv.c;
 *   [H2] static char md[8192] — общий на все окна: теперь буфер
 *        выделяется на каждый вызов browser_load_content() и
 *        принадлежит вызвавшему окну (два окна не конфликтуют);
 *   [H3] entities в конце файла — см. htmlconv.c.
 *
 * Буферы этого окна (browser_t) — собственность ОДНОГО окна;
 * fetch-буфер выделяется только на время запроса.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "clipboard.h" /* Ctrl+C/V — общий буфер с редактором */
#include "task.h"
#include "htmlconv.h"
#include "utf8.h"
#include "brlines.h"
#include "imgsvc.h"   /* сессия 55: декодирование PNG/JPEG/BMP/GIF */
#include "brpage.h"   /* сессия 55: картинки/ссылки страницы */

#define BR_HDR 22          /* высота адресной строки */
#define BR_STATUS_H 14
#define BR_MD_MAX 8192     /* буфер конвертера на вызов (FIX [H2]) */
#define BR_FETCH_MAX 16384 /* HTTP-ответ на время запроса */
#define BR_FILE_MAX 65536  /* лимит файла из RAM disk */
#define BR_ADDR_MAX 118
#define BR_HIST_MAX 16     /* история для Back (сессия 55) */

/* FIX (аудит UTF-8): прежде строки хранились в фикс-массиве 100x96 БАЙТ:
 *  - длинные строки ОБРЕЗАЛИСЬ (переноса не было вовсе),
 *  - кириллица резалась посередине символа (2 байта UTF-8).
 * Теперь текст хранится как есть (b->md), а строки отображения —
 * динамический массив, который перестраивается с ПЕРЕНОСОМ по СИМВОЛАМ
 * под текущую ширину окна (любая длинная строка переносится корректно). */
typedef struct {
    char *md;              /* исходный текст (Markdown/простой текст) */
    int  md_len;
    brl_list_t L;          /* строки отображения после переноса (brlines.h) */
    int  wrap_maxc;        /* ширина (в символах), по которой строились L; -1 = не строили */
    int  scroll;
    int  fetching;         /* 1 = идёт сетевой запрос (в этом потоке) */
    char url[128];         /* адрес текущей страницы */
    char status[80];
    char hover[96];        /* сессия 55: ссылка под курсором (для статуса) */
    /* адресная строка */
    char addr[BR_ADDR_MAX + 1];
    int  addr_len;
    int  addr_focus;       /* 1 = редактируем адрес */
    /* выделение текста (запрос: «копирование между приложениями,
     * в том числе браузером»). Координаты — строки ОТОБРАЖЕНИЯ (b->L)
     * и колонки в СИМВОЛАХ: sel_ar/ac — якорь (нажатие ЛКМ),
     * sel_br/bc — второй конец (drag). Нормализация — в br_sel_norm. */
    int sel_active;        /* 1 = есть непустое выделение */
    int sel_drag;          /* 1 = ЛКМ зажата в контенте (drag) */
    int sel_ar, sel_ac;    /* якорь: строка/колонка отображения */
    int sel_br, sel_bc;    /* второй конец (следует за курсором) */
    /* полоса прокрутки (общий виджет, сессия 17) */
    wm_scrollbar_t sb;
    /* сессия 55: картинки/ссылки страницы + история Back */
    brp_page_t page;
    int  imgs_pending;     /* 1 = картинки ждут загрузки (окно уже есть) */
    char hist[BR_HIST_MAX][128];
    int  hist_n;
    /* служебное */
    window_t *win;
} browser_t;

/* ---------- утилиты ---------- */

static int ci_eq(char a, char b)
{
    if (a >= 'A' && a <= 'Z') a += 32;
    if (b >= 'A' && b <= 'Z') b += 32;
    return a == b;
}

static int ci_same(const char *a, const char *b)
{
    while (*a && *b) {
        if (!ci_eq(*a, *b)) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* Поиск файла в RAM disk без учёта регистра.
 * Возвращает 1 и размер, если найден. */
static int ramfs_lookup(const char *name, u32 *out_size)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        if (ci_same(ents[i].name, name)) {
            if (out_size) *out_size = ents[i].size;
            return 1;
        }
    }
    return 0;
}

/* ---------- загрузка контента и конвертация ---------- */

/* forward (сессия 55): циклы картинок/разметки */
static void br_layout_images(browser_t *b);
static void br_render_now(browser_t *b);
static void br_ensure_lines(browser_t *b, int cw);

/* Строки отображения под текущую ширину окна (перестройка только
 * при изменении ширины или нового контента). (cw - 16) / 8: текст
 * рисуется с x=4, полоса прокрутки занимает правый край cw-7..cw-2 —
 * резерв 16px держит текст ВНЕ полосы (раньше последний символ
 * наезжал на жёлоб на 2px). */
static void br_ensure_lines(browser_t *b, int cw)
{
    int maxc = (cw - 16) / 8;
    if (maxc < 8) maxc = 8;
    if (b->L.lines && b->wrap_maxc == maxc) return;
    brl_wrap(b->md, b->md_len, maxc, &b->L);
    b->wrap_maxc = maxc;
    br_layout_images(b);
}

/* ---------- картинки страницы (сессия 55) ---------- */

static brp_img_t *br_img_by_src(browser_t *b, int src_idx)
{
    for (int i = 0; i < b->page.nimgs; i++)
        if (b->page.imgs[i].src_idx == src_idx)
            return &b->page.imgs[i];
    return NULL;
}

/* Резерв строк под картинки в списке отображения: якорные строки
 * (BRP_IMG_MARK) получают высоту готовой картинки (в строках по 16px);
 * после якоря вставляются пустые строки BRL_CLS_IMG. */
static void br_layout_images(browser_t *b)
{
    for (int i = 0; i < b->L.nlines; i++) {
        const char *s = b->L.lines[i];
        if (s[0] != BRP_IMG_MARK || s[1] != 0) continue;
        brp_img_t *im = br_img_by_src(b, b->L.srcidx[i]);
        b->L.cls[i] = BRL_CLS_IMG;
        if (im) {
            int rows = (im->dh + 15) / 16;
            if (rows < 1) rows = 1;
            if (im->state != 1) rows = 1;   /* не готова: строка-заглушка */
            im->row = i;
            im->rows = rows;
            if (rows > 1)
                brl_insert_blanks(&b->L, i + 1, rows - 1, b->L.srcidx[i]);
        }
    }
}

/* Загрузить все картинки страницы (ВЫЗЫВАТЬ ИЗ ПОТОКА ОКНА — сеть
 * блокирующая, как и загрузка самой страницы). Картинка масштабируется
 * билинейно под ширину окна (и по высоте до 60% окна). */
static void br_load_images(browser_t *b)
{
    int total = b->page.nimgs;
    int maxw, maxh;
    int ok = 0, fail = 0;

    if (!b->win || total == 0) return;
    maxw = win_content_w(b->win) - 16;
    if (maxw < 64) maxw = 64;
    maxh = (win_content_h(b->win) * 6) / 10;
    if (maxh < 120) maxh = 120;

    b->imgs_pending = 0;
    for (int i = 0; i < total; i++) {
        brp_img_t *im = &b->page.imgs[i];
        img_t t, s;

        snprintf(b->status, sizeof(b->status), "Картинка %d/%d: %.48s...",
                 i + 1, total, im->url);
        br_render_now(b);

        if (img_decode_url(im->url, b->url, &t) != 0) {
            im->state = -1;
            fail++;
            win_invalidate(b->win);
            continue;
        }
        im->w = t.w;
        im->h = t.h;

        int dw = t.w, dh = t.h;
        if (dw > maxw) {
            dh = t.h * maxw / t.w;
            dw = maxw;
            if (dh < 1) dh = 1;
        }
        if (dh > maxh) {
            dw = dw * maxh / dh;
            dh = maxh;
            if (dw < 1) dw = 1;
        }

        if (img_scale(&t, dw, dh, &s) == 0) {
            im->rgba = s.rgba;
            im->dw = s.w;
            im->dh = s.h;
            im->state = 1;
            ok++;
        } else {
            im->state = -1;
            fail++;
        }
        img_dispose(&t);          /* оригинал больше не нужен */
        win_invalidate(b->win);
    }

    if (total)
        snprintf(b->status, sizeof(b->status),
                 "Картинки: %d готово, %d недоступно", ok, fail);

    /* Пересобрать строки-отображение ПОСЛЕ загрузки: br_ensure_lines
     * выходит по раннему return (ширина не менялась), а высоты
     * картинок (dh) уже изменились — сбрасываем кэш принудительно. */
    brl_free(&b->L);
    b->wrap_maxc = -1;
    br_ensure_lines(b, win_content_w(b->win));
    b->scroll = 0;
    win_invalidate(b->win);
}

static void browser_load_content(browser_t *b, const char *url,
                                  const char *content, int len)
{
    strncpy(b->url, url ? url : "", sizeof(b->url) - 1);
    b->url[sizeof(b->url) - 1] = 0;
    b->fetching = 0;
    b->sel_active = 0;     /* новая страница — старое выделение не имеет смысла */
    b->sel_drag = 0;

    /* сессия 55: пиксельные буферы прошлой страницы больше не нужны */
    brp_reset(&b->page);
    b->hover[0] = 0;

    /* FIX [N5]: сырой ответ HTTP-клиента содержит ЗАГОЛОВКИ
     * ("HTTP/1.0 200 OK\r\nServer:...\r\n\r\n<body>"). Раньше они
     * попадали в конвертер и на экран как текст. Отрезаем всё до
     * пустой строки — показываем только тело. */
    if (len > 5 && !strncmp(content, "HTTP/", 5)) {
        int i = 0;
        while (i < len && i < 2048) {
            if (content[i] == '\n') {
                if (i + 2 < len && content[i + 1] == '\r' && content[i + 2] == '\n') {
                    content += i + 3;
                    len -= i + 3;
                    break;
                }
                if (i + 1 < len && content[i + 1] == '\n') {
                    content += i + 2;
                    len -= i + 2;
                    break;
                }
            }
            i++;
        }
    }

    /* Это HTML или уже Markdown? */
    int is_html = 0;
    for (int i = 0; i < len && i < 200; i++) {
        if (content[i] == '<') { is_html = 1; break; }
    }

    /* FIX [H2]: буфер конвертера — локальный на вызов, не static.
     * Два окна браузера конвертируют в РАЗНЫЕ буферы. */
    char *md = (char *)malloc(BR_MD_MAX);
    if (!md) {
        snprintf(b->status, sizeof(b->status), "Нет памяти для конвертации");
        brl_free(&b->L);
        b->wrap_maxc = -1;
        return;
    }

    int md_len;
    if (is_html) {
        snprintf(b->status, sizeof(b->status),
                 "Конвертация HTML->Markdown (%d байт)...", len);
        md_len = html_to_md(content, len, md, BR_MD_MAX);
        snprintf(b->status, sizeof(b->status),
                 "HTML %d байт -> Markdown %d байт", len, md_len);
    } else {
        /* FIX (аудит): простой текст больше не режется до 8 КиБ —
        * храним столько, сколько пришло (в пределах лимита файла). */
        md_len = len < BR_FILE_MAX ? len : BR_FILE_MAX;
        memcpy(md, content, (u32)md_len);
        md[md_len] = 0;
        snprintf(b->status, sizeof(b->status),
                 "Markdown/текст (%d байт)", len);
    }

    /* Храним исходник (для переноса строк при отрисовке/resize) */
    {
        char *store = (char *)malloc((u32)md_len + 1);
        if (!store) {
            free(md);
            snprintf(b->status, sizeof(b->status), "Нет памяти под текст");
            brl_free(&b->L);
            b->wrap_maxc = -1;
            return;
        }
        memcpy(store, md, (u32)md_len);
        store[md_len] = 0;
        if (b->md) free(b->md);
        b->md = store;
        b->md_len = md_len;
    }
    free(md);

    /* сессия 55: разбор страницы — маркеры картинок -> якоря, сбор
     * ссылок с абсолютными смещениями (md может быть сжат). */
    b->md_len = brp_analyze(&b->page, b->md, b->md_len);
    b->imgs_pending = (b->page.nimgs > 0);

    brl_free(&b->L);        /* строки построятся при первой отрисовке */
    b->wrap_maxc = -1;
    b->scroll = 0;
    b->hover[0] = 0;
    {
        /* дописать " | строк: N" без strncat (его нет в kernel string.c).
        * N — строк ИСХОДНОГО текста (перенос может дать больше видимых). */
        int src_lines = 1;
        for (int i = 0; i < b->md_len; i++)
            if (b->md[i] == '\n') src_lines++;
        char tail[48];
        snprintf(tail, sizeof(tail), " | строк: %d", src_lines);
        int pos = (int)strlen(b->status);
        int rem = (int)sizeof(b->status) - 1 - pos;
        if (rem > 0) {
            strncpy(b->status + pos, tail, (u32)rem);
            b->status[pos + ((int)strlen(tail) < rem ? (int)strlen(tail) : rem)] = 0;
        }
    }
}

/* ---------- навигация ---------- */

/* Разобрать "host" или "host:port" → хост и порт (80 по умолчанию).
 * Нужно и для http://10.0.2.2:8080/ (веб-серверы на нестандартном порту),
 * и для тестов QEMU. Возвращает 1 при успехе. */
static int br_parse_host(char *host, u16 *port)
{
    *port = 80;
    char *colon = strchr(host, ':');
    if (!colon) return 1;
    *colon = 0;
    u32 p = 0;   /* u32: u16 переполнялся бы ДО проверки > 65535 (-Wtype-limits) */
    for (const char *q = colon + 1; *q; q++) {
        if (*q < '0' || *q > '9') return 0;
        p = p * 10 + (u32)(*q - '0');
        if (p > 65535) return 0;
    }
    if (p == 0) return 0;
    *port = (u16)p;
    return 1;
}

static void br_render_now(browser_t *b)
{
    /* Немедленная отрисовка в canvas своего окна (мы в потоке окна):
     * под rlock — чтобы статус «Запрос...» был виден ДО блокирующего
     * сетевого запроса. Прямой вызов w->draw без rlock гонялся бы
     * с realloc canvas при resize. */
    if (b->win) win_draw_now(b->win);
}

static void br_navigate_ex(browser_t *b, const char *addr, int redirs);

static void br_navigate(browser_t *b, const char *addr)
{
    br_navigate_ex(b, addr, 0);
}

/* Сессия 56: распознать редирект в сыром HTTP-ответе. Заполняет loc
 * (буфер вызывающего) значением заголовка Location и возвращает код
 * статуса (301/302/303/307/308) или 0 (нет редиректа/нет Location).
 * loc может быть относительным — разрешает вызывающий. */
static int br_ci_ncmp(const char *a, const char *b, int n)
{
    for (int i = 0; i < n; i++) {
        char ca = a[i], cb = b[i];
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 1;
    }
    return 0;
}

static int br_parse_redirect(const char *resp, int len, int *out_code,
                             char *loc, int loc_max)
{
    if (!resp || len < 12 || strncmp(resp, "HTTP/", 5) != 0 || !loc ||
        loc_max < 8)
        return 0;
    int i = 5;
    while (i < len && resp[i] == ' ') i++;
    if (i + 3 > len) return 0;
    int code = 0;
    for (int k = 0; k < 3; k++) {
        char c = resp[i + k];
        if (c < '0' || c > '9') return 0;
        code = code * 10 + (c - '0');
    }
    if (code != 301 && code != 302 && code != 303 &&
        code != 307 && code != 308) return 0;

    /* конец заголовков: \r\n\r\n или \n\n (не дальше 2 КиБ) */
    int hdr_end = len;
    for (int p = 0; p < len && p < 2048; p++) {
        if (p + 3 < len && resp[p] == '\r' && resp[p + 1] == '\n' &&
            resp[p + 2] == '\r' && resp[p + 3] == '\n') {
            hdr_end = p; break;
        }
        if (p + 1 < len && resp[p] == '\n' && resp[p + 1] == '\n') {
            hdr_end = p; break;
        }
    }

    /* строка "location: ..." (без учёта регистра) до конца заголовков */
    for (int p = 0; p < hdr_end; ) {
        int eol = p;
        while (eol < hdr_end && resp[eol] != '\n') eol++;
        if (eol - p > 9 && br_ci_ncmp(resp + p, "location:", 9) == 0) {
            const char *v = resp + p + 9;
            const char *ve = resp + eol;
            while (v < ve && (*v == ' ' || *v == '\t')) v++;
            int vl = (int)(ve - v);
            while (vl > 0 && (v[vl - 1] == '\r' || v[vl - 1] == ' '))
                vl--;
            if (vl > 0 && vl < loc_max) {
                memcpy(loc, v, (u32)vl);
                loc[vl] = 0;
                *out_code = code;
                return code;
            }
            return 0;
        }
        p = eol + 1;
    }
    return 0;
}

static void br_navigate_ex(browser_t *b, const char *addr, int redirs)
{
    char host[128];
    char path[256];
    /* сессия 55: локальная копия без фрагментов (на УРОВНЕ функции:
     * p остаётся валидным до конца функции) */
    char cut[BR_ADDR_MAX + 1];
    /* сессия 67: нормализованное имя файла RAM disk (тоже на уровне
     * функции: p = nm живёт до конца функции) */
    char nm[BR_ADDR_MAX + 1];
    const char *p = addr;

    b->addr_focus = 0;

    /* Пустой ввод — ничего не делать */
    while (*p == ' ') p++;
    if (!*p) {
        win_invalidate(b->win);
        return;
    }

    /* сессия 55: фрагменты #... отбрасываем (якоря не поддержаны) */
    {
        int ci = 0;
        for (const char *q = p; *q && ci < BR_ADDR_MAX; q++) {
            if (*q == '#') break;
            cut[ci++] = *q;
        }
        cut[ci] = 0;
        while (ci > 0 && cut[ci - 1] == ' ') cut[--ci] = 0;
        if (ci == 0) {
            snprintf(b->status, sizeof(b->status), "Внутренний якорь — пропущен");
            win_invalidate(b->win);
            return;
        }
        /* работаем дальше с ЛОКАЛЬНОЙ обрезанной строкой (без алиасинга
         * с b->addr — ниже ветки сами обновляют адресную строку) */
        addr = cut;
        p = cut;
    }

    /* --- ramfs-файл? (нет схемы и не похоже на URL) --- */
    int has_scheme = 0;
    for (const char *q = p; *q; q++) {
        if (q - p > 12) break;
        if (*q == ':' && q[1] == '/' && q[2] == '/') { has_scheme = 1; break; }
    }

    if (!has_scheme) {
        u32 fsize = 0;
        int is_url = 0;
        /* www.foo.bar или foo.ru — похоже на хост без схемы */
        int dots = 0, spaces = 0;
        for (const char *q = p; *q; q++) {
            if (*q == '.') dots++;
            if (*q == ' ') spaces++;
        }
        if (!strncmp(p, "www.", 4) || (dots >= 1 && spaces == 0 &&
             !strchr(p, '/')))
            is_url = 1;

        /* СЕССИЯ 63: голый "localhost" (и "localhost:8080") — тоже URL:
         * без точек раньше шёл в ramfs-поиск и получал «Файл 'localhost'
         * не найден в RAM disk» вместо локального сервера. */
        if (!is_url && !strncmp(p, "localhost", 9) &&
            (p[9] == 0 || p[9] == ':' || p[9] == '/'))
            is_url = 1;

        if (!is_url) {
            /* СЕССИЯ 67: локальные адреса вида "/help.md", "./help.md",
             * "../help.md" (ссылка с абсолютным путём на локальной
             * странице, ручной ввод) — RAM disk хранит имена БЕЗ
             * ведущего '/': нормализуем к имени от корня. */
            const char *q = p;
            int k = 0;
            for (;;) {
                if (*q == '/') q++;
                else if (q[0] == '.' && q[1] == '/') q += 2;
                else if (q[0] == '.' && q[1] == '.' && q[2] == '/') q += 3;
                else break;
            }
            while (*q && k < BR_ADDR_MAX) nm[k++] = *q++;
            nm[k] = 0;
            if (!nm[0]) {
                snprintf(b->status, sizeof(b->status),
                         "Пустое имя файла");
                win_invalidate(b->win);
                return;
            }
            p = nm;
        }

        if (!is_url && ramfs_lookup(p, &fsize)) {
            /* Открываем файл из RAM disk */
            if (fsize == 0 || fsize > BR_FILE_MAX) {
                snprintf(b->status, sizeof(b->status),
                         "Файл %s: %u байт — вне лимита", p, (unsigned)fsize);
                win_invalidate(b->win);
                return;
            }
            char *buf = (char *)malloc(fsize);
            if (!buf) {
                snprintf(b->status, sizeof(b->status), "Нет памяти");
                win_invalidate(b->win);
                return;
            }
            u32 got = ramfs_read(p, buf, fsize);
            if (got == 0) {
                free(buf);
                snprintf(b->status, sizeof(b->status), "Ошибка чтения %s", p);
                win_invalidate(b->win);
                return;
            }
            strncpy(b->addr, p, BR_ADDR_MAX);
            b->addr[BR_ADDR_MAX] = 0;
            b->addr_len = (int)strlen(b->addr);
            browser_load_content(b, p, buf, (int)got);
            free(buf);
            win_invalidate(b->win);
            return;
        }
        if (!is_url) {
            snprintf(b->status, sizeof(b->status),
                     "Файл '%s' не найден в RAM disk", p);
            win_invalidate(b->win);
            return;
        }
        /* is_url: продолжаем как http(s):// */
    }
    else if (strncmp(p, "http://", 7) != 0 && strncmp(p, "https://", 8) != 0) {
        snprintf(b->status, sizeof(b->status),
                 "Схема не поддерживается (http:// или https://)");
        win_invalidate(b->win);
        return;
    }

    /* --- HTTP/HTTPS --- */
    int use_tls = 0;
    if (!strncmp(p, "https://", 8)) { p += 8; use_tls = 1; }
    else if (!strncmp(p, "http://", 7)) p += 7;
    int hi = 0;
    while (*p && *p != '/' && hi < 127) {
        host[hi++] = *p++;
    }
    host[hi] = 0;
    /* host:port (порт по умолчанию: 443 для https, 80 для http) */
    u16 port = use_tls ? 443 : 80;
    if (!br_parse_host(host, &port)) {
        snprintf(b->status, sizeof(b->status), "Неверный порт в адресе");
        win_invalidate(b->win);
        return;
    }
    if (!*p) p = "/";
    strncpy(path, p, 255);
    path[255] = 0;

    if (!host[0]) {
        snprintf(b->status, sizeof(b->status), "Пустой хост");
        win_invalidate(b->win);
        return;
    }

    /* СЕССИЯ 63: loopback ("localhost", 127.x.x.x) работает БЕЗ NIC и
     * без настроенного IP — соединение замыкается внутри стека
     * (net_is_loopback), поэтому проверку сети для него пропускаем:
     * раньше без сети браузер отвечал «Сеть не настроена» даже на
     * 127.0.0.1, хотя локальный httpd доступен. */
    if (!net_host_is_loopback(host) &&
        (!net_nic_present() || net_get_ip() == 0)) {
        snprintf(b->status, sizeof(b->status), "Сеть не настроена");
        win_invalidate(b->win);
        return;
    }

    /* Показываем статус ДО блокирующего запроса (запрос выполняется
     * в потоке ЭТОГО окна — система и остальные окна продолжают жить). */
    b->fetching = 1;
    snprintf(b->status, sizeof(b->status),
             "Запрос %s://%s:%u%s ...", use_tls ? "https" : "http",
             host, (unsigned)port, path);
    br_render_now(b);

    /* сессия 55: история Back — текущая страница уходит в стек
     * (сессия 56: только для переходов С НАЧАЛА цепочки —
     * промежуточные редиректы историю не дублируют) */
    if (redirs == 0 && b->url[0] && strcmp(b->url, addr) != 0 &&
        b->hist_n < BR_HIST_MAX) {
        strncpy(b->hist[b->hist_n], b->url, sizeof(b->hist[0]) - 1);
        b->hist[b->hist_n][sizeof(b->hist[0]) - 1] = 0;
        b->hist_n++;
    }

    char *resp = (char *)malloc(BR_FETCH_MAX);
    if (!resp) {
        b->fetching = 0;
        snprintf(b->status, sizeof(b->status), "Нет памяти под ответ");
        win_invalidate(b->win);
        return;
    }

    int n = net_http_get(host, port, path, resp, BR_FETCH_MAX, 10000);
    b->fetching = 0;
    /* Сессия 58: АВТО-FALLBACK НА HTTPS. Большинство сайтов сегодня
     * отвечают только по TLS, а plain http:80 часто режется на пути
     * (провайдер/фаервол: «connection refused»/таймаут — собственный
     * стек при этом полностью исправен, host-тест tcpnet зелёный).
     * Если запрос по http не удался — повторяем тот же адрес через
     * TLS (порт 443). Один повтор на переход; статус показывает причину
     * первой неудачи. */
    if (n <= 0 && !use_tls && redirs < 4 && !net_host_is_loopback(host)) {
        const char *why0 = net_http_errstr();
        /* повторяем только при сетевом отказе соединения: DNS/ARP-ошибки
         * при повторе https бессмысленны (удвоили бы ожидание).
         * Сессия 63: для loopback повтор на 443 тоже бессмыслен —
         * локальный httpd говорит только по plain HTTP. */
        if (strncmp(why0, "connection", 10) == 0 ||      /* refused/reset */
            strncmp(why0, "connect timeout", 15) == 0) {
            char why[56];
            strncpy(why, why0, sizeof(why) - 1);
            why[sizeof(why) - 1] = 0;
            snprintf(b->status, sizeof(b->status),
                     "HTTP: %s — пробую HTTPS...", why);
            b->fetching = 1;
            br_render_now(b);
            use_tls = 1;
            port = 443;
            n = net_http_get(host, port, path, resp, BR_FETCH_MAX, 10000);
            b->fetching = 0;
        }
    }
    if (n > 0) {
        /* сессия 56: редиректы 301/302/303/307/308. ya.ru и большинство
         * крупных сайтов отвечают 302 (часто на https:// или
         * canonical-хост) — раньше пользователь видел сырые заголовки
         * вместо страницы. Следуем до 4 раз, Location абсолютный и
         * относительный. */
        if (redirs < 4) {
            int code = 0;
            char loc[300];
            if (br_parse_redirect(resp, n, &code, loc, (int)sizeof(loc))) {
                char base[168], abs[300];
                snprintf(base, sizeof(base), "%s://%s:%u%s",
                         use_tls ? "https" : "http", host, (unsigned)port,
                         path);
                img_url_resolve(base, loc, abs, (int)sizeof(abs));
                snprintf(b->status, sizeof(b->status),
                         "Редирект %d -> %.46s", code, abs);
                free(resp);
                br_navigate_ex(b, abs, redirs + 1);
                return;
            }
        }
        const char *scheme = use_tls ? "https" : "http";
        snprintf(b->addr, sizeof(b->addr), "%s://%s:%u%s", scheme,
                 host, (unsigned)port, path);
        b->addr[sizeof(b->addr) - 1] = 0;
        b->addr_len = (int)strlen(b->addr);
        char full[168];
        snprintf(full, sizeof(full), "%s://%s:%u%s", scheme,
                 host, (unsigned)port, path);
        browser_load_content(b, full, resp, n);
    } else {
        /* FIX [N1d]: показываем причину сбоя (connect timeout /
         * connection refused / no ARP / resolve) вместо безликого кода */
        snprintf(b->status, sizeof(b->status),
                 "Ошибка: %s (HTTP Trace покажет детали)", net_http_errstr());
    }
    free(resp);

    /* сессия 55: картинки страницы (тот же поток, что и страница) */
    if (b->imgs_pending)
        br_load_images(b);

    win_invalidate(b->win);
}

/* Назад (сессия 55): возврат по истории. Backspace/кнопка Back. */
static void br_go_back(browser_t *b)
{
    char prev[128];
    if (b->hist_n == 0) {
        snprintf(b->status, sizeof(b->status), "История пуста");
        win_invalidate(b->win);
        return;
    }
    b->hist_n--;
    strncpy(prev, b->hist[b->hist_n], sizeof(prev) - 1);
    prev[sizeof(prev) - 1] = 0;
    br_navigate(b, prev);
}

/* ---------- сохранение страницы на RAM disk (сессия 67) ---------- */

/* Имя файла для сохранения из адреса страницы:
 *   "http://host:80/dir/page.html" -> "page"  (расширение добавит
 * br_save_free_name: ".md" — страница уже конвертирована в Markdown);
 *   "https://ya.ru/"               -> "page";
 *   "docs/page.md"                 -> "page.md";
 *   "notes.txt"                    -> "notes.txt" (текст сохраняется
 *                                     как есть, расширение честное).
 * Схема/host:port отрезаются (берётся последний сегмент пути),
 * не-[A-Za-z0-9._-] -> '_'. Стеб ограничен RAMFS_NAME_MAX-8 — запас
 * под суффикс "_NN.md". */
static void br_save_derive_stem(const char *url, char *out, int out_max)
{
    char stem[RAMFS_NAME_MAX + 1];
    int n = 0;
    const char *p = url ? url : "";

    const char *sch = strstr(p, "://");
    if (sch) p = sch + 3;
    const char *last = strrchr(p, '/');
    if (last) p = last + 1;

    for (; *p; p++) {
        char c = *p;
        if (c == '?' || c == '#' || c == '/') break;
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
              (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-'))
            c = '_';
        if (n < (int)sizeof(stem) - 1) stem[n++] = c;
    }
    stem[n] = 0;

    /* адрес без имени ("http://host:80/", "dir/") — базовое имя */
    if (!stem[0] || !strcmp(stem, ".") || !strcmp(stem, ".."))
        strcpy(stem, "page");

    /* расширение: .html/.htm убираем (контент уже Markdown), .md и
     * прочие честные расширения сохраняем, без расширения — добавит
     * br_save_free_name */
    {
        char *dot = strrchr(stem, '.');
        if (dot && dot != stem) {
            char e[8];
            int el = 0;
            for (const char *q = dot + 1; *q && el < 7; q++) {
                char lc = *q;
                if (lc >= 'A' && lc <= 'Z') lc += 32;
                e[el++] = lc;
            }
            e[el] = 0;
            if (!strcmp(e, "htm") || !strcmp(e, "html"))
                *dot = 0;                     /* .html/.htm -> стеб */
            /* .md/.txt/... — оставляем как есть */
        }
    }

    /* запас под суффикс "_NN.md" */
    if ((int)strlen(stem) > RAMFS_NAME_MAX - 8)
        stem[RAMFS_NAME_MAX - 8] = 0;
    strncpy(out, stem, (u32)out_max - 1);
    out[out_max - 1] = 0;
}

/* Свободное имя: "stem.md" (или стем с его расширением), затем
 * "stem_2.md"... "stem_99.md". Возвращает 1 при успехе. */
static int br_save_free_name(const char *stem, char *out, int out_max)
{
    char cand[RAMFS_NAME_MAX + 8];

    /* у стема может быть своё расширение (.md/.txt) — тогда "stem.md"
     * не добавляем второе: расширение уже есть */
    const char *dot = strrchr(stem, '.');
    if (dot && dot != stem) {
        snprintf(cand, sizeof(cand), "%s", stem);
    } else {
        snprintf(cand, sizeof(cand), "%s.md", stem);
    }
    if (!ramfs_lookup(cand, NULL)) {
        strncpy(out, cand, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return 1;
    }
    for (int k = 2; k < 100; k++) {
        snprintf(cand, sizeof(cand), "%s_%d.md", stem, k);
        if (!ramfs_lookup(cand, NULL)) {
            strncpy(out, cand, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return 1;
        }
    }
    return 0;
}

/* Сохранить текущую страницу (b->md — Markdown/текст) в RAM disk.
 * Существующие файлы НЕ перезаписываются (подбирается свободное имя) —
 * сохранение не может уничтожить HELP.MD и прочие файлы. */
static void br_save_page(browser_t *b)
{
    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];

    if (!b->md || b->md_len <= 0) {
        snprintf(b->status, sizeof(b->status), "Нечего сохранять");
        win_invalidate(b->win);
        return;
    }
    br_save_derive_stem(b->url, stem, (int)sizeof(stem));
    if (!br_save_free_name(stem, name, (int)sizeof(name))) {
        snprintf(b->status, sizeof(b->status), "Нет свободного имени");
        win_invalidate(b->win);
        return;
    }
    ramfs_delete(name);              /* свободное имя — delete страховка */
    if (!ramfs_create(name, (u32)b->md_len + 1) ||
        !ramfs_write(name, b->md, (u32)b->md_len + 1)) {
        snprintf(b->status, sizeof(b->status),
                 "Ошибка записи RAM disk");
        win_invalidate(b->win);
        return;
    }
    snprintf(b->status, sizeof(b->status), "Сохранено: %s (%d байт)",
             name, b->md_len + 1);
    win_invalidate(b->win);
}

/* ---------- рендеринг ---------- */

/* Сессия 56: строка отображения с ПОДСВЕТКОЙ ССЫЛОК. Ссылка — интервал
 * видимого текста [b_abs, t_end_abs) исходной строки (brpage.h: разметка
 * [T](U) вырезана из md). Кусок отображения покрывает байты
 * [line_base+srcoff, ...+plen) — пересечения рисуем синим с
 * подчёркиванием, остальное — цветом класса строки.
 * Раньше вся строка рисовалась одной fb_text с разметкой на экране:
 * пользователь видел [example.com](http://example.com/). */
#define BR_SEGS_MAX 12
#define BR_SEG_BUF  512
/* (форвард: определение — в разделе ввода, ниже) */
static void br_sel_norm(browser_t *b, int *r0, int *c0, int *r1, int *c1);

static void br_draw_text_line(browser_t *b, int i, int y, u32 color)
{
    const char *piece = b->L.lines[i];
    int plen = (int)strlen(piece);
    if (plen == 0) return;

    if (b->page.nlinks == 0 || b->page.line_off == NULL ||
        !b->L.srcidx || !b->L.srcoff ||
        b->L.srcidx[i] < 0 || b->L.srcidx[i] >= b->page.nlines) {
        fb_text(4, y, piece, color, -1);
        return;
    }
    int srcidx = b->L.srcidx[i];
    int piece_abs0 = b->page.line_off[srcidx] + b->L.srcoff[i];

    brp_seg_t segs[BR_SEGS_MAX];
    int ns = brp_link_segs(&b->page, srcidx, piece_abs0, piece, plen,
                           segs, BR_SEGS_MAX);
    if (ns == 0) {
        fb_text(4, y, piece, color, -1);
        return;
    }

    u32 link_col = wm_theme_accent();
    int total = utf8_count_chars(piece, -1);
    int col_prev = 0;
    int x = 4;
    char buf[BR_SEG_BUF];
    for (int s = 0; s <= ns && col_prev < total; s++) {
        int col_a = (s < ns) ? segs[s].col0 : total;
        int col_b = (s < ns) ? segs[s].col1 : col_a;
        if (col_a > total) col_a = total;
        if (col_b > total) col_b = total;
        /* обычный кусок [col_prev, col_a) */
        if (col_a > col_prev) {
            int b0 = brp_byte_of_col(piece, plen, col_prev);
            int b1 = brp_byte_of_col(piece, plen, col_a);
            int nb = b1 - b0;
            if (nb > (int)sizeof(buf) - 1) nb = (int)sizeof(buf) - 1;
            if (nb > 0) {
                memcpy(buf, piece + b0, (u32)nb);
                buf[nb] = 0;
                fb_text(x, y, buf, color, -1);
            }
            x += (col_a - col_prev) * 8;
            col_prev = col_a;
        }
        /* текст ссылки [col_a, col_b) — синий + подчёркивание */
        if (s < ns && col_b > col_prev) {
            int b0 = brp_byte_of_col(piece, plen, col_prev);
            int b1 = brp_byte_of_col(piece, plen, col_b);
            int nb = b1 - b0;
            if (nb > (int)sizeof(buf) - 1) nb = (int)sizeof(buf) - 1;
            if (nb > 0) {
                memcpy(buf, piece + b0, (u32)nb);
                buf[nb] = 0;
                fb_text(x, y, buf, link_col, -1);
            }
            fb_hline(x, x + (col_b - col_prev) * 8 - 1, y + 14, link_col);
            x += (col_b - col_prev) * 8;
            col_prev = col_b;
        }
    }
}

static void br_draw(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* --- адресная строка (BR_HDR пикселей сверху) --- */
    fb_fill_rect(0, 0, cw, BR_HDR, fb_rgb(0x16, 0x1C, 0x24));
    fb_hline(0, cw - 1, BR_HDR - 1, fb_rgb(0x2C, 0x31, 0x38));

    /* поле ввода (сессия 67: правее три кнопки — Back/Save/Go по 44px) */
    int box_x = 4, box_y = 3, box_w = cw - 152, box_h = 16;
    if (box_w < 40) box_w = 40;
    fb_fill_rect(box_x, box_y, box_w, box_h,
                 b->addr_focus ? wm_theme_win_bg() : fb_rgb(0x1E, 0x24, 0x2C));
    fb_rect(box_x, box_y, box_w, box_h,
            b->addr_focus ? wm_theme_accent() : fb_rgb(0x34, 0x3A, 0x42));

    char shown[BR_ADDR_MAX * 2 + 2];   /* x2 — UTF-8: до 2 байт на символ */
    int max_chars = (box_w - 12) / 8;
    if (max_chars < 4) max_chars = 4;
    if (max_chars > BR_ADDR_MAX) max_chars = BR_ADDR_MAX;

    const char *src = b->addr_focus ? b->addr : (b->addr[0] ? b->addr : b->url);
    int sl = (int)strlen(src);
    int total = utf8_count_chars(src, -1);
    /* показываем ХВОСТ адреса (FIX: отрезаем по СИМВОЛАМ, не по байтам —
    * раньше кириллица могла разрезаться посередине) */
    int from = 0;
    if (total > max_chars) from = utf8_take_bytes(src, -1, total - max_chars);
    int tl = sl - from;
    if (tl < 0) tl = 0;
    memcpy(shown, src + from, (u32)tl);
    shown[tl] = 0;
    if (b->addr_focus && wm_blink()) {
        shown[tl] = '_';
        shown[tl + 1] = 0;
    }
    fb_text(box_x + 6, box_y + 1, shown,
            b->addr_focus ? wm_theme_text() : wm_theme_text_dim(), -1);

    if (!b->addr_focus && !b->addr[0] && !b->url[0])
        fb_text(box_x + 6, box_y + 1, "http://... или имя файла RAM disk",
                fb_rgb(0x50, 0x58, 0x62), -1);

    /* кнопки Go, Save (сессия 67) и Back (сессия 55) */
    int go_x = cw - 48, go_y = 3, go_w = 44, go_h = 16;
    int sv_x = cw - 96, sv_w = 44;
    int bk_x = cw - 144, bk_w = 44;
    fb_fill_rect(go_x, go_y, go_w, go_h, wm_theme_sel_bg());
    fb_rect(go_x, go_y, go_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(go_x + (go_w - 2 * 8) / 2, go_y + 1, "Go",
            wm_theme_text(), -1);
    fb_fill_rect(sv_x, go_y, sv_w, go_h, wm_theme_sel_bg());
    fb_rect(sv_x, go_y, sv_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(sv_x + (sv_w - 4 * 8) / 2, go_y + 1, "Save",
            wm_theme_text(), -1);
    fb_fill_rect(bk_x, go_y, bk_w, go_h,
                 b->hist_n > 0 ? wm_theme_sel_bg() : fb_rgb(0x24, 0x2A, 0x32));
    fb_rect(bk_x, go_y, bk_w, go_h, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(bk_x + (bk_w - 4 * 8) / 2, go_y + 1, "Back",
            b->hist_n > 0 ? wm_theme_text() : wm_theme_text_dim(), -1);

    /* --- контент --- */
    int area_y = BR_HDR;
    int area_h = ch - BR_HDR - BR_STATUS_H;
    int vis = area_h / 16;
    if (vis < 1) vis = 1;

    fb_fill_rect(0, area_y, cw, area_h, wm_theme_win_bg());

    /* FIX (аудит): перенос строк по СИМВОЛАМ под текущую ширину окна
     * (при изменении размеров окно перестраивается автоматически) */
    br_ensure_lines(b, cw);

    int max_scroll = b->L.nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (b->scroll > max_scroll) b->scroll = max_scroll;
    if (b->scroll < 0) b->scroll = 0;

    int start = b->scroll;
    int end = start + vis;
    if (end > b->L.nlines) end = b->L.nlines;

    /* --- сессия 55: картинки рисуем ДО текста (они занимают свои
     * строки; текст на них не пишется, т.к. класс BRL_CLS_IMG
     * пропускается ниже) --- */
    int area_y2 = area_y + 2;
    int area_bot = area_y + area_h;
    for (int i = 0; i < b->page.nimgs; i++) {
        brp_img_t *im = &b->page.imgs[i];
        if (im->state != 1 || !im->rgba || im->dw <= 0 || im->dh <= 0)
            continue;
        int y_top = area_y2 + (im->row - start) * 16;
        int y_bot = y_top + im->dh;
        if (y_bot <= area_y2 || y_top >= area_bot) continue;  /* вне экрана */
        int dy = y_top > area_y2 ? y_top : area_y2;
        int src_y = dy - y_top;
        int h_vis = y_bot - dy;
        if (h_vis > area_bot - dy) h_vis = area_bot - dy;
        if (h_vis <= 0) continue;
        int x = (cw - im->dw) / 2;
        if (x < 2) x = 2;
        /* 1:1 blit видимой части (сдвиг источника при прокрутке) */
        fb_blit_rgba(im->rgba + (u32)src_y * (u32)im->dw * 4,
                     im->dw, h_vis, x, dy, im->dw, h_vis);
    }

    /* нормализованное выделение (один раз на кадр) для подсветки */
    int sr0 = 0, sc0 = 0, sr1 = -1, sc1 = 0;
    if (b->sel_active) br_sel_norm(b, &sr0, &sc0, &sr1, &sc1);

    int y = area_y + 2;
    for (int i = start; i < end; i++, y += 16) {
        u32 color = wm_theme_text();
        /* FIX (сессия 19): цвет по КЛАССУ строки отображения (brlines.h):
         * куски-продолжения переносной строки наследуют класс исходной,
         * поэтому длинный заголовок/пункт списка цветной ЦЕЛИКОМ —
         * раньше по первому символу куска цвет имели только первая
         * часть строки и следующий пункт, середина оставалась белой. */
        unsigned char cls = b->L.cls ? b->L.cls[i]
                                     : (b->L.lines[i][0] == '#' ? BRL_CLS_HEAD :
                                        b->L.lines[i][0] == '[' ? BRL_CLS_LINK :
                                        b->L.lines[i][0] == '-' ? BRL_CLS_LIST :
                                        BRL_CLS_TEXT);
        if (cls == BRL_CLS_HEAD)      color = fb_rgb(0xFF, 0xE0, 0x60); /* заголовки */
        else if (cls == BRL_CLS_LINK) color = wm_theme_accent();        /* ссылки */
        else if (cls == BRL_CLS_LIST) color = wm_theme_text_dim();      /* списки */

        /* сессия 55: строки картинок — не текст; якорная строка
         * (BRP_IMG_MARK) неутверждённой картинки показывает заглушку */
        if (cls == BRL_CLS_IMG) {
            const char *ls = b->L.lines[i];
            if (ls[0] == BRP_IMG_MARK && ls[1] == 0) {
                brp_img_t *im = br_img_by_src(b, b->L.srcidx[i]);
                if (im && im->state == 1) {
                    /* картинка нарисована выше — текст не пишем */
                } else if (im && im->state == 0) {
                    fb_text(4, y, "(картинка: загрузка...)",
                            wm_theme_text_dim(), -1);
                } else {
                    fb_text(4, y, "[картинка недоступна]",
                            fb_rgb(0x88, 0x70, 0x70), -1);
                }
            }
            continue;
        }

        /* строки уже перенесены по ширине окна (br_ensure_lines);
         * UTF-8 внутри строки не разрезан. Ссылочные интервалы —
         * синим с подчёркиванием (сессия 56). */
        /* подсветка выделенной части строки (ПОД текстом): колонки в
         * СИМВОЛАХ, x = 4 + col*8 — та же арифметика, что в hit-тесте */
        if (i >= sr0 && i <= sr1) {
            const char *ls = b->L.lines[i];
            int nc = utf8_count_chars(ls, -1);
            int a = (i == sr0) ? sc0 : 0;
            int z = (i == sr1) ? sc1 : nc;
            if (a < 0) a = 0;
            if (z > nc) z = nc;
            if (z > a)
                fb_fill_rect(4 + a * 8, y, (z - a) * 8, 16,
                             wm_theme_sel_bg());
        }
        br_draw_text_line(b, i, y, color);
    }

    /* полоса прокрутки — общий виджет wm_scrollbar (цвет из темы).
     * ПОРЯДОК ПОНЯТЕН: pos=0 — начало текста (ползунок сверху) */
    wm_scrollbar_draw(&b->sb, cw - 7, area_y + 2, 5, area_h - 4,
                      b->scroll, max_scroll, vis);

    /* --- статус-бар --- */
    fb_fill_rect(0, ch - BR_STATUS_H, cw, BR_STATUS_H, wm_theme_win_bg_alt());
    char st[112];
    if (b->hover[0])
        snprintf(st, sizeof(st), "ссылка: %s", b->hover);
    else
        snprintf(st, sizeof(st), "%s%s | прокрутка: %d/%d",
                 b->fetching ? "* " : "", b->status, b->scroll, max_scroll);
    fb_text(4, ch - BR_STATUS_H + 2, st, wm_theme_text_info(), -1);
}

/* ---------- ввод ---------- */

/* ---------- выделение и копирование (общий буфер, clipboard.h) ---------- */

/* Нормализованный диапазон выделения (r0<=r1; при равенстве c0<=c1),
 * границы clamp'ятся к числу строк/символов (строки могли перестроиться
 * при переносе под новую ширину окна). */
static void br_sel_norm(browser_t *b, int *r0, int *c0, int *r1, int *c1)
{
    int ar = b->sel_ar, ac = b->sel_ac, zr = b->sel_br, zc = b->sel_bc;
    if (b->L.nlines <= 0) { *r0 = *r1 = *c0 = *c1 = 0; return; }
    if (ar < 0) ar = 0;
    if (ar >= b->L.nlines) ar = b->L.nlines - 1;
    if (zr < 0) zr = 0;
    if (zr >= b->L.nlines) zr = b->L.nlines - 1;
    int na = utf8_count_chars(b->L.lines[ar], -1);
    int nz = utf8_count_chars(b->L.lines[zr], -1);
    if (ac < 0) ac = 0;
    if (ac > na) ac = na;
    if (zc < 0) zc = 0;
    if (zc > nz) zc = nz;
    if (ar < zr || (ar == zr && ac <= zc)) {
        *r0 = ar; *c0 = ac; *r1 = zr; *c1 = zc;
    } else {
        *r0 = zr; *c0 = zc; *r1 = ar; *c1 = ac;
    }
}

/* Скопировать выделенный текст в общий буфер обмена (строки — через
 * '\n'; пустое выделение — ничего). Статус — сколько скопировано. */
static void br_sel_copy(browser_t *b)
{
    if (!b->sel_active || !b->L.lines) return;
    int r0, c0, r1, c1;
    br_sel_norm(b, &r0, &c0, &r1, &c1);

    int total = 0;
    for (int r = r0; r <= r1; r++) {
        const char *ls = b->L.lines[r];
        int nc = utf8_count_chars(ls, -1);
        int a = (r == r0) ? c0 : 0;
        int z = (r == r1) ? c1 : nc;
        if (a < 0) a = 0;
        if (z > nc) z = nc;
        if (z > a)
            total += utf8_take_bytes(ls, -1, z) - utf8_take_bytes(ls, -1, a);
        if (r < r1) total++;
    }
    if (total <= 0) return;

    char *buf = (char *)malloc((u32)total + 1);
    if (!buf) return;
    char *p = buf;
    for (int r = r0; r <= r1; r++) {
        const char *ls = b->L.lines[r];
        int nc = utf8_count_chars(ls, -1);
        int a = (r == r0) ? c0 : 0;
        int z = (r == r1) ? c1 : nc;
        if (a < 0) a = 0;
        if (z > nc) z = nc;
        if (z > a) {
            int b0 = utf8_take_bytes(ls, -1, a);
            int b1 = utf8_take_bytes(ls, -1, z);
            memcpy(p, ls + b0, (u32)(b1 - b0));
            p += b1 - b0;
        }
        if (r < r1) *p++ = '\n';
    }
    *p = 0;
    clip_text_set(buf, total);
    free(buf);
    snprintf(b->status, sizeof(b->status),
             "Скопировано %d симв. (Ctrl+V — в редактор)", total);
}

static void br_key(window_t *w, const key_event_t *ev)
{
    browser_t *b = (browser_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* Ctrl+S — сохранить страницу в RAM disk (сессия 67) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 's' || ev->ch == 'S' || ev->ch == 0x13)) {
        br_save_page(b);
        return;
    }

    /* Ctrl+L — фокус на адресную строку (как в больших браузерах) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'l' || ev->ch == 'L' || ev->ch == 0x0C)) {
        b->addr_focus = 1;
        win_invalidate(w);
        return;
    }

    /* Ctrl+C — скопировать выделенный текст (буфер общий с редактором;
    * вставка — Ctrl+V в редакторе). Только вне режима адреса. */
    if ((ev->flags & KF_CTRL) && !b->addr_focus &&
        (ev->ch == 'c' || ev->ch == 'C' || ev->code == 0x2E)) {
        br_sel_copy(b);
        win_invalidate(w);
        return;
    }

    /* --- режим редактирования адреса --- */
    if (b->addr_focus) {
        if (ev->ch == 0x1B || ev->code == 0x01) {          /* Esc */
            b->addr_focus = 0;
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n') {          /* Enter */
            br_navigate(b, b->addr);
            return;
        }
        if (ev->code == 0x0E) {                            /* Backspace */
            if (b->addr_len > 0) {
                b->addr[--b->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        /* Ctrl+V — вставить текст из буфера в адрес (адрес — ASCII:
         * кириллица из буфера пропускается) */
        if ((ev->flags & KF_CTRL) &&
            (ev->ch == 'v' || ev->ch == 'V' || ev->code == 0x2F)) {
            const char *t = clip_text_get();
            for (int i = 0; t && t[i]; i++) {
                char cv = t[i];
                if (cv < 0x20 || cv >= 0x7F) continue;
                if (b->addr_len < BR_ADDR_MAX)
                    b->addr[b->addr_len++] = cv;
            }
            b->addr[b->addr_len] = 0;
            win_invalidate(w);
            return;
        }
        if (ev->ch >= 0x20 && ev->ch < 0x7F && !(ev->flags & KF_CTRL)) {
            if (b->addr_len < BR_ADDR_MAX) {
                b->addr[b->addr_len++] = ev->ch;
                b->addr[b->addr_len] = 0;
                win_invalidate(w);
            }
            return;
        }
        return;   /* прочие клавиши в режиме ввода игнорируем */
    }

    /* --- обычный режим: прокрутка ---
     * СЕССИЯ 17 (ФИКС): раньше было ЗАДОМ НАПЕРЁД — PgUp увеличивал
     * scroll (первую видимую строку), Home прыгал в конец. Теперь:
     * scroll — первая видимая строка; PgUp/вверх — к началу. */
    int ch = win_content_h(w);
    int vis = (ch - BR_HDR - BR_STATUS_H) / 16;
    if (vis < 1) vis = 1;
    int max_scroll = b->L.nlines - vis;
    if (max_scroll < 0) max_scroll = 0;

    if (ev->code == 0x49 || ev->code == KBD_UP) {          /* PgUp/вверх */
        b->scroll -= vis;
        if (b->scroll < 0) b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x51 || ev->code == KBD_DOWN) { /* PgDn/вниз */
        b->scroll += vis;
        if (b->scroll > max_scroll) b->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == 0x47) {                          /* Home */
        b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x0E) {                          /* Backspace */
        br_go_back(b);                       /* сессия 55: назад */
    } else if (ev->ch == 0x1B || ev->code == 0x01) {
        win_close(w);
    }
}

/* Ссылка под точкой контента или NULL. r — строка отображения,
 * col — колонка в символах. */
static const char *br_link_at(browser_t *b, int r, int col)
{
    if (r < 0 || r >= b->L.nlines) return NULL;
    const char *piece = b->L.lines[r];
    int plen = (int)strlen(piece);
    return brp_click_link(&b->page, b->md, b->L.srcidx[r], b->L.srcoff[r],
                          piece, plen, col,
                          b->L.cls[r] == BRL_CLS_LINK ? 1 : 0);
}

static void br_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), chh = win_content_h(w);

    /* ОТпускание ЛКМ после drag выделения — принимается В ЛЮБОМ месте
     * (включая отрицательные координаты за пределами окна: сессия 20
     * доставляет их при неявном захвате мыши — иначе drag «залипал»). */
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT) && b->sel_drag) {
        b->sel_drag = 0;
        if (b->sel_active) {               /* было перетаскивание — это НЕ клик */
            win_invalidate(w);
            return;
        }
        /* клик без перемещения: ссылка под точкой отпускания? */
        int area_y = BR_HDR;
        int area_h = chh - BR_HDR - BR_STATUS_H;
        if (my >= area_y && my < area_y + area_h) {
            int r = b->scroll + (my - area_y - 2) / 16;
            int col = (mx - 4) / 8;
            const char *u = (col >= 0) ? br_link_at(b, r, col) : NULL;
            if (u) {
                /* клик по ссылке: относительные адреса — против страницы */
                char abs[300];
                img_url_resolve(b->url, u, abs, (int)sizeof(abs));
                br_navigate(b, abs);
                return;
            }
        }
        if (b->addr_focus) b->addr_focus = 0;
        win_invalidate(w);
        return;
    }

    if (my < 0 || mx < 0) return;

    if (my < BR_HDR) {
        if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT))
            return;                   /* интересует только нажатие ЛКМ */
        b->sel_drag = 0;              /* нажатие в шапке — не drag текста */
        /* полоса адреса: Go / Save (сессия 67) / Back / поле */
        if (mx >= cw - 48 && mx < cw - 4) {
            br_navigate(b, b->addr);   /* кнопка Go */
        } else if (mx >= cw - 96 && mx < cw - 52) {
            br_save_page(b);           /* кнопка Save (сессия 67) */
        } else if (mx >= cw - 144 && mx < cw - 100) {
            br_go_back(b);             /* кнопка Back (сессия 55) */
        } else if (mx < cw - 152) {
            if (!b->addr_focus) {
                b->addr_focus = 1;
                win_invalidate(w);
            }
        }
        return;
    }

    /* полоса прокрутки (сессия 17); сессия 20: при drag полосу не
     * отпускаем — события с любыми координатами (захват мыши) */
    if ((mx >= cw - 9 && my < chh - BR_STATUS_H) || b->sb.dragging) {
        int np = wm_scrollbar_mouse(&b->sb, mx, my, btn, changed);
        if (np >= 0) { b->scroll = np; win_invalidate(w); }
        return;
    }

    /* --- контент (сессия 55): ховер, выделение, клики по ссылкам --- */
    int area_y = BR_HDR;
    int area_h = chh - BR_HDR - BR_STATUS_H;
    if (my >= area_y && my < area_y + area_h) {
        int r = b->scroll + (my - area_y - 2) / 16;
        int col = (mx - 4) / 8;

        /* ховер: показ адреса в статусе (перерисовка только при смене;
         * во время drag выделения ховер не трогаем — статус оставим) */
        if (!b->sel_drag) {
            const char *url = (col >= 0) ? br_link_at(b, r, col) : NULL;
            const char *h = url ? url : "";
            if (strncmp(b->hover, h, sizeof(b->hover) - 1) != 0) {
                strncpy(b->hover, h, sizeof(b->hover) - 1);
                b->hover[sizeof(b->hover) - 1] = 0;
                win_invalidate(w);
            }
        }

        /* ВЫДЕЛЕНИЕ: нажатие ставит ЯКОРЬ, drag тянет второй конец;
         * клик БЕЗ перемещения обрабатывается в блоке отпускания выше
         * (ссылка/фокус адреса — как раньше, но на mouse-up). */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            b->sel_drag = 1;
            b->sel_active = 0;
            b->sel_ar = b->sel_br = r;
            b->sel_ac = b->sel_bc = col;
            /* клик по контенту снимает фокус с адресной строки */
            if (b->addr_focus) b->addr_focus = 0;
            win_invalidate(w);
        } else if (b->sel_drag && (btn & MSB_LEFT)) {
            /* drag: второй конец следует за курсором */
            if (r != b->sel_br || col != b->sel_bc) {
                b->sel_br = r;
                b->sel_bc = col;
                b->sel_active = (r != b->sel_ar || col != b->sel_ac);
                win_invalidate(w);
            }
        }
    } else if (b->hover[0]) {
        b->hover[0] = 0;
        win_invalidate(w);
    }
}

static void br_close(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    if (b) {
        brl_free(&b->L);
        if (b->md) free(b->md);
        brp_reset(&b->page);                 /* сессия 55: пиксели картинок */
        if (b->page.line_off) free(b->page.line_off);
        b->page.line_off = NULL;
        free(b);
    }
}

/* ---------- стартовая страница ---------- */

static const char *br_help_md =
    "# Браузер N2600-OS\n\n"
    "## Ссылки\n"
    "- Ссылки — СИНИЕ с подчёркиванием: [пример.com](http://example.com/)\n"
    "- Клик — переход; адрес под курсором — в статус-строке\n"
    "- Редиректы (301/302) проходятся автоматически — до 4 раз\n"
    "- Кнопка **Back** или **Backspace** — назад; `<a href>` из HTML\n"
    "  и `[текст](url)` из Markdown работают одинаково\n\n"
    "## Картинки\n"
    "![логотип N2600](LOGO.PNG)\n"
    "- Форматы: PNG, JPEG, BMP, GIF (stb_image)\n"
    "- `<img src=...>` из HTML и `![alt](url)` из Markdown; относительные\n"
    "  пути разрешаются от адреса страницы; локальные файлы — RAM disk\n\n"
    "## Выделение и копирование\n"
    "- Проведите мышью с зажатой ЛКМ — текст выделится\n"
    "- **Ctrl+C** — скопировать выделенное в общий буфер обмена\n"
    "- Вставка — **Ctrl+V** в редакторе (буфер один на всю систему)\n"
    "- **Ctrl+V** в адресной строке — вставить скопированный адрес\n\n"
    "## Адресная строка\n"
    "- Клик по ней или **Ctrl+L** — редактирование\n"
    "- **Enter** или кнопка **Go** — переход\n"
    "- `http://host/path` или `https://` — запрос (в потоке этого окна:\n"
    "  зависший запрос не вешает систему)\n"
    "- Имя файла (`help.md`, `demo.js`) — открыть файл из RAM disk\n"
    "- Кнопка **Save** или **Ctrl+S** — сохранить страницу в RAM disk\n"
    "  (имя — из адреса, существующие файлы не перезаписываются)\n\n"
    "## Если «connection refused (RST ... ttl=...)»\n"
    "- Соединение сбросил не сайт: ttl=64 — фильтр вашей же сети\n"
    "  (роутер/AP/DNS-синкхол); меньше — хост интернета\n"
    "- Попробуйте https:// или info.cern.ch, neverssl.com, example.com\n\n"
    "## Поддержка Markdown\n"
    "- Заголовки `#`, `##`, `###`; **жирный**, *курсив*, `код`\n"
    "- Списки и ссылки [текст](http://example.com/)\n\n"
    "## Команды терминала\n"
    "- `curl http://example.com/` — загрузить страницу в новое окно\n"
    "- `spawn browser` — ещё одно окно браузера\n"
    "- `js img.js` — картинки из JS-скрипта (QuickJS)\n\n"
    "---\n"
    "Прокрутка: PgUp/PgDn, стрелки, колёсико мыши; назад — Backspace\n";

/* ---------- создание окна ---------- */

static browser_t *br_new_state(void)
{
    browser_t *b = (browser_t *)malloc(sizeof(browser_t));
    if (!b) return NULL;
    memset(b, 0, sizeof(*b));
    strncpy(b->url, "help", sizeof(b->url) - 1);
    strcpy(b->status, "Готово");
    return b;
}

static void br_open_common(browser_t *b, int load_help)
{
    if (load_help) {
        browser_load_content(b, "help", br_help_md, (int)strlen(br_help_md));
        strcpy(b->addr, "help");
        b->addr_len = (int)strlen(b->addr);
    }

    u32 W = fb_width(), H = fb_height();
    int ww = 700;
    int wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    window_t *w = win_create("Браузер", (int)W / 2 - ww / 2, 16, ww, wh,
                              br_draw, br_key, br_mouse, NULL, br_close, b);
    if (!w) {
        free(b);
        return;
    }
    b->win = w;

    /* сессия 55: если контент уже загружен (curl/help) — картинки грузим
     * здесь, когда окно и его размеры уже известны */
    if (b->imgs_pending)
        br_load_images(b);
}

void app_browser_open(void)
{
    browser_t *b = br_new_state();
    if (!b) return;
    br_open_common(b, 1);
}

void app_browser_open_with(const char *url, const char *content, int len)
{
    browser_t *b = br_new_state();
    if (!b) return;
    browser_load_content(b, url ? url : "(curl)", content, len);
    if (url) {
        strncpy(b->addr, url, BR_ADDR_MAX);
        b->addr[BR_ADDR_MAX] = 0;
        b->addr_len = (int)strlen(b->addr);
    }
    br_open_common(b, 0);
}
