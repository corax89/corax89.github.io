/* fileman.c — файловый менеджер: CD/ISO9660, FAT32 (ATA/USB), RAMFS.
 * FIX (не видно дисков): загрузочный CD с ISO9660 раньше вообще не
 * был доступен в «Файлах» (кнопки были только HDD/RAM/USB) — на машине
 * с одним CD-приводом приложение показывало «нет диска», хотя ОС
 * загрузилась с читаемого ISO. Теперь панель устройств — [CD][HDD][RAM][USB].
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "kbd.h"
#include "mouse.h"
#include "fat32.h"
#include "ntfs.h"
#include "kernel.h"   /* sata_pending */
#include "ramfs.h"
#include "iso9660.h"
#include "usb_ehci.h"
#include "timer.h"   /* сессия 73: тики для кулдауна ретраев монтирования */
#include "ata.h"
#include "disk.h"   /* единый слой НЖМД (AHCI/ATA) */
#include "loader.h"
#include "filedlg.h"   /* сессия 13: диалог ввода имени */

/* ============================ файловый менеджер ============================ */

#define FM_MAX 256
#define FM_ROW 18
#define FM_HDR 22
#define FM_DEVBAR 22    /* высота панели выбора устройства */
#define FM_BACK_W 64    /* кнопка «Назад» в строке пути (сессия 62) */
#define FM_CRUMB_X (4 + FM_BACK_W + 8)  /* «крошки» адреса — правее кнопки */

/* режимы источника: 0=HDD (FAT32 или NTFS), 1=RAMFS, 2=FAT32(USB), 3=CD/ISO9660 */
#define FM_MODE_ATA 0
#define FM_MODE_RAM 1
#define FM_MODE_USB 2
#define FM_MODE_ISO 3
#define FM_MODE_COUNT 4

/* порядок кнопок на панели: CD, HDD, RAM, USB */
static const int fm_btn_mode[4] = { FM_MODE_ISO, FM_MODE_ATA, FM_MODE_RAM, FM_MODE_USB };
static const char *const fm_btn_name[4] = { "[CD]", "[HDD]", "[RAM]", "[USB]" };

/* Сессия 12 (запрос пользователя): панель показывает ТОЛЬКО существующие
 * диски с ПОНЯТНОЙ файловой системой — с которой можно работать:
 *   CD   — смонтирован ISO9660;
 *   HDD  — НЖМД найден и на нём FAT32 (ATA-бэкенд) или NTFS;
 *   RAM  — RAM disk;
 *   USB  — флешка смонтирована как FAT32 (USB-бэкенд).
 * Диск без поддерживаемой ФС (например, NTFS до инициализации или
 * ext4) НЕ показывается — раньше кнопка висела серой и вела в тупик
 * «ФС не найдена». USB монтируется автоматически при первом
 * обнаружении флешки; если ФС не FAT32 — кнопка не появляется. */
static int fm_usb_bad = 0;      /* монтирование USB пробовали — ФС не FAT32 */

static int fm_hdd_fs = 0;     /* [HDD]: 0 = FAT32, 1 = NTFS (сессия 11);
                               * сессия 25: 1 = активный том — NTFS */

/* ---- Сессия 25: тома НЖМД — по кнопке на каждый раздел с ФС ----
 * Раньше на диске с несколькими разделами был виден только ПЕРВЫЙ
 * FAT32/NTFS (fat32_init/ntfs_init монтировали первый подходящий).
 * Теперь сканируется вся таблица (включая GPT и логические) и каждый
 * раздел с поддерживаемой ФС получает свою кнопку в панели устройств. */
#define FM_MAX_VOLS 8
typedef struct {
    int  part;      /* индекс в disk_part(); -1 = ВЕСЬ ДИСК (superfloppy) */
    int  is_ntfs;   /* 1 = NTFS, 0 = FAT32 */
    char letter;    /* 'C', 'D', ... — порядок по возрастанию LBA */
} fm_vol_t;
static fm_vol_t fm_vols[FM_MAX_VOLS];
static int fm_vol_count = 0;
static int fm_vol_cur   = -1;   /* активный том (-1 = ещё не выбран) */

static void fm_scan_vols(void)
{
    /* активный том сохраняем по индексу раздела (скан идёт при каждой
     * отрисовке/тике — сбрасывать выбор было бы нельзя) */
    int old_part = (fm_vol_cur >= 0 && fm_vol_cur < fm_vol_count)
                   ? fm_vols[fm_vol_cur].part : -2;
    fm_vol_count = 0;
    if (!disk_hdd_present()) { fm_vol_cur = -1; return; }
    int np = disk_part_count();
    for (int i = 0; i < np && fm_vol_count < FM_MAX_VOLS; i++) {
        const char *fs = disk_part_fstype(i);
        int ntfs = strcmp(fs, "NTFS") == 0;
        /* СЕССИЯ 75: exFAT-тома идут через fat32_*-пути (personality) */
        if (!ntfs && strcmp(fs, "FAT32") != 0 && strcmp(fs, "exFAT") != 0)
            continue;
        fm_vols[fm_vol_count].part    = i;
        fm_vols[fm_vol_count].is_ntfs = ntfs;
        fm_vols[fm_vol_count].letter  = (char)('C' + fm_vol_count);
        fm_vol_count++;
    }
    /* FIX (сессия 57): SUPERFLOPPY — FAT32 БЕЗ таблицы разделов. fat32_init
     * монтирует весь диск (g_base_lba=0), Настройки показывают «ФС: FAT32»,
     * а файловый менеджер строил кнопки ТОЛЬКО из disk_part(): при нуле
     * разделов кнопки [HDD] не было вовсе — «диск виден в настройках, но
     * не в менеджере». Теперь весь смонтированный диск — псевдо-том
     * (part = -1). */
    if (fm_vol_count == 0 && !fat32_is_usb() && fat32_ready()) {
        fm_vols[fm_vol_count].part = -1;
        fm_vols[fm_vol_count].is_ntfs = 0;
        fm_vols[fm_vol_count].letter = 'C';
        fm_vol_count++;
    }
    fm_vol_cur = -1;
    if (old_part >= -1)
        for (int i = 0; i < fm_vol_count; i++)
            if (fm_vols[i].part == old_part) { fm_vol_cur = i; break; }
}

static int fm_src_avail(int mode)
{
    switch (mode) {
    case FM_MODE_ISO: return iso9660_ready() ? 1 : 0;
    case FM_MODE_ATA:
        /* сессия 25: том считается доступным, если на диске есть хоть
         * один раздел с поддерживаемой ФС (список — fm_scan_vols) */
        if (!disk_hdd_present()) return 0;
        fm_scan_vols();
        return fm_vol_count > 0;
    case FM_MODE_RAM: return ramfs_ready() ? 1 : 0;
    case FM_MODE_USB:
        return (fat32_ready() && fat32_is_usb()) ? 1 : 0;
    }
    return 0;
}

/* Смонтировать том по индексу fm_vols[] (смена смонтированной ФС). */
static void fm_mount_vol(int vi)
{
    if (vi < 0 || vi >= fm_vol_count) return;
    fm_vol_cur = vi;
    fm_hdd_fs = fm_vols[vi].is_ntfs ? 1 : 0;
    if (fm_vols[vi].part < 0) {
        /* superfloppy: весь диск, монтирование целиком */
        if (fm_vols[vi].is_ntfs)
            ntfs_init();
        else
            fat32_init();
        return;
    }
    if (fm_vols[vi].is_ntfs)
        ntfs_init_part(fm_vols[vi].part);
    else
        fat32_init_part(fm_vols[vi].part);
}

/* Буква текущего тома для шапки ('\0' — не HDD-режим). */
static char fm_vol_letter(void)
{
    if (fm_vol_cur < 0 || fm_vol_cur >= fm_vol_count) return 0;
    return fm_vols[fm_vol_cur].letter;
}

/* ---- Раскладка панели устройств (сессия 25) ----
 * Кнопки: [CD] | тома C:, D:, ... | [RAM] [USB]. Возвращает число
 * кнопок; kind: 0 = режим (idx = FM_MODE_*), 1 = том (idx = fm_vols). */
typedef struct { int x, w; int kind; int idx; } fm_devbtn_t;

static int fm_devbar_layout(fm_devbtn_t *out, int maxn)
{
    int n = 0, x = 6;
    if (fm_src_avail(FM_MODE_ISO) && n < maxn) {
        out[n].x = x; out[n].w = 50; out[n].kind = 0; out[n].idx = FM_MODE_ISO;
        x += 54; n++;
    }
    if (fm_src_avail(FM_MODE_ATA) && n < maxn) {
        for (int i = 0; i < fm_vol_count && n < maxn; i++) {
            out[n].x = x; out[n].w = 34; out[n].kind = 1; out[n].idx = i;
            x += 38; n++;
        }
    }
    if (fm_src_avail(FM_MODE_RAM) && n < maxn) {
        out[n].x = x; out[n].w = 50; out[n].kind = 0; out[n].idx = FM_MODE_RAM;
        x += 54; n++;
    }
    if (fm_src_avail(FM_MODE_USB) && n < maxn) {
        out[n].x = x; out[n].w = 50; out[n].kind = 0; out[n].idx = FM_MODE_USB;
        x += 54; n++;
    }
    return n;
}

/* Первая доступная источник-режим (для авто-переключения). */
static int fm_first_avail_mode(void)
{
    for (int i = 0; i < 4; i++)
        if (fm_src_avail(fm_btn_mode[i]))
            return fm_btn_mode[i];
    return FM_MODE_RAM;   /* что-то должно быть (RAM disk живёт всегда) */
}

/* К какому режиму принадлежит FAT-набор записей (режимы 0 и 2 делят fat_ents) */
#define FM_IS_FAT(m) ((m) == FM_MODE_ATA || (m) == FM_MODE_USB)
/* Сессия 11: [HDD] теперь умеет и NTFS — выбор ФС внутри режима ATA */
#define FM_HDD_IS_NTFS(m) ((m) == FM_MODE_ATA && fm_hdd_fs == 1)

typedef struct {
    fat32_dirent_t fat_ents[FM_MAX];
    ramfs_dirent_t ram_ents[FM_MAX];
    iso9660_dirent_t iso_ents[FM_MAX];
    ntfs_dirent_t ntfs_ents[FM_MAX];
    int  fat_n, ram_n, iso_n, ntfs_n;
    int  sel, scroll, depth;
    int  mode; /* FM_MODE_* */
    int  usb_inited;          /* 1 = fat32_init_usb() уже вызвана */
    int  dev_hover;           /* -1 = none, 0..3 = device button hover */
    int  crumb_hover;         /* сессия 62: сегмент «крошек» под курсором, -1 */
    int  back_hover;          /* сессия 62: курсор на кнопке «Назад» */
    int  hdd_avail_snap;      /* тик: состояние [HDD] для автообновления */
    struct { u32 cluster;     /* FAT: кластер / ISO: LBA каталога */
             u32 iso_size;    /* ISO: размер каталога в байтах */
             char path[200]; } stk[16];
} fm_t;

/* --- форвард-объявления (сессия 13: меню/действия используют их выше) --- */
static void fm_open_selected(window_t *w);
static void fm_edit_selected(window_t *w);   /* «Редактировать» (запрос) */
static void fm_mouse_rmb(window_t *w, fm_t *m, int mx, int my, u8 btn, u8 changed);

/* Полный путь RAM-ребёнка name в текущем каталоге (сессия 13). */
static void fm_ram_full(char *dst, int dstsz, fm_t *m, const char *name)
{
    const char *base = m->stk[m->depth].path;
    if (base[0] == '/' && !base[1])
        snprintf(dst, dstsz, "%s", name);
    else
        snprintf(dst, dstsz, "%s/%s", base, name);
}

static void fm_path_join(char *dst, const char *name)
{
    int l = (int)strlen(dst);
    if (l && dst[l-1] != '/') dst[l++] = '/';
    int i = 0;
    while (name[i] && l < 190) dst[l++] = name[i++];
    dst[l] = 0;
}

static void fm_reload(fm_t *m)
{
    m->ntfs_n = 0;
    if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
        /* NTFS (сессия 11): листинг по полному пути */
        m->ntfs_n = ntfs_ready()
            ? ntfs_list(m->stk[m->depth].path, m->ntfs_ents, FM_MAX) : 0;
        if (m->ntfs_n < 0) m->ntfs_n = 0;
        m->fat_n = 0;
        m->ram_n = 0;
        m->iso_n = 0;
    } else if (FM_IS_FAT(m->mode)) {
        /* FAT32 ATA/USB режим */
        m->fat_n = fat32_ready() ? fat32_list(m->stk[m->depth].cluster, m->fat_ents, FM_MAX) : 0;
        m->ram_n = 0;
        m->iso_n = 0;
    } else if (m->mode == FM_MODE_ISO) {
        /* CD / ISO9660: корень или каталог по LBA+размеру из стека */
        if (!iso9660_ready()) {
            m->iso_n = 0;
        } else if (m->depth == 0) {
            m->iso_n = iso9660_list_root(m->iso_ents, FM_MAX);
        } else {
            m->iso_n = iso9660_list_dir(m->stk[m->depth].cluster,
                                        m->stk[m->depth].iso_size, 1,
                                        m->iso_ents, FM_MAX);
        }
        m->fat_n = 0;
        m->ram_n = 0;
    } else {
        /* RAMFS режим (сессия 13: иерархия — листинг ТЕКУЩЕГО каталога) */
        m->ram_n = ramfs_ready()
            ? ramfs_list_dir(m->stk[m->depth].path, m->ram_ents, FM_MAX) : 0;
        m->fat_n = 0;
        m->iso_n = 0;
    }
    m->sel = 0;
    m->scroll = 0;
}

/* ============ контекстное меню и создание/удаление (сессия 13) ============
 * Запрос пользователя: «стандартное контекстное меню (которое смогут
 * переиспользовать другие приложения)» + «создание папок и файлов».
 * Меню — переиспользуемый wm-компонент (wm_menu_open); пункты зависят
 * от режима и выделения. Создание/удаление — только в RAM disk
 * (единственная перезаписываемая ФС). */

enum { FMC_OPEN = 1, FMC_MKDIR, FMC_TOUCH, FMC_DELETE, FMC_RELOAD,
       FMC_COPY, FMC_PASTE, FMC_EDIT };   /* СЕССИЯ 61: копировать/вставить;
 * FMC_EDIT (запрос): «Редактировать» — web-файлы (.md/.html/.htm)
 * по «Открыть» уходят в браузер, этим пунктом — в редактор */

static const char *fm_menu_hint;   /* строка статуса после действия */

static void fm_reload_and_draw(fm_t *m, window_t *w)
{
    fm_reload(m);
    win_invalidate(w);
}

/* ---- колбэки диалога ввода имени (поток диалога — как во всём ОС) ---- */
static window_t *fm_input_owner;
static int fm_pending_kind;     /* FMC_MKDIR / FMC_TOUCH */

/* Запрос имени (диалог) выполнен: создаём в ТЕКУЩЕМ каталоге на ТЕКУЩЕМ
 * источнике — сессия 14: FAT32 (HDD/USB) в дополнение к RAM.
 * «Файлы создаются только в корне, но не в папках» — теперь путь берётся
 * из стека навигации (RAM: путь, FAT: кластер). */
static void fm_input_ok(void *ctx, const char *name)
{
    window_t *w = (window_t *)ctx;
    fm_t *m = (fm_t *)w->data;
    if (!m) return;

    /* чистим имя от '/' (один уровень за раз) */
    char clean[FD_NAME_MAX + 1];
    int ci = 0;
    for (const char *p = name; *p && ci < FD_NAME_MAX; p++)
        if (*p != '/') clean[ci++] = *p;
    clean[ci] = 0;
    if (!clean[0]) return;

    if (m->mode == FM_MODE_RAM) {
        char full[232];
        fm_ram_full(full, sizeof(full), m, clean);
        if (fm_pending_kind == FMC_MKDIR) {
            if (ramfs_mkdir(full)) fm_menu_hint = "Папка создана";
            else fm_menu_hint = "Не удалось создать папку (имя занято?)";
        } else {
            ramfs_delete(full);
            if (ramfs_create(full, 1) && ramfs_write(full, "", 1))
                fm_menu_hint = "Файл создан";
            else fm_menu_hint = "Не удалось создать файл";
        }
    } else if (FM_IS_FAT(m->mode) && !(m->mode == FM_MODE_ATA && fm_hdd_fs == 1)
               && fat32_ready()) {
        u32 dir = m->stk[m->depth].cluster;
        if (fm_pending_kind == FMC_MKDIR) {
            if (fat32_mkdir(dir, clean)) fm_menu_hint = "Папка создана (FAT32)";
            else fm_menu_hint = "Не удалось создать папку (имя занято?)";
        } else {
            if (fat32_create_file(dir, clean)) fm_menu_hint = "Файл создан (FAT32)";
            else fm_menu_hint = "Не удалось создать файл (имя занято?)";
        }
    } else {
        fm_menu_hint = "Этот источник только для чтения";
        return;
    }
    fm_reload_and_draw(m, w);
}

static void fm_input_cancel(void *ctx)
{
    (void)ctx;
    fm_menu_hint = "Отменено";
}

/* колбэк меню: исполняется в потоке окна Файлов (WEV_MENU) */

/* ---- СЕССИЯ 61: буфер обмена «Копировать/Вставить» ----
 * Снимок содержимого берётся В МОМЕНТ копирования (источник может
 * исчезнуть до вставки; файлы до 8 МиБ). Вставка — в текущий каталог
 * текущего источника: RAM disk или FAT32 (НЖМД/флешка). Имя при
 * вставке сохраняется (существующий файл заменяется). */
#define FM_CLIP_MAX  (8u * 1024u * 1024u)   /* лимит снимка: 8 МиБ */
enum { FM_CLIP_NONE = 0, FM_CLIP_RAM, FM_CLIP_FAT, FM_CLIP_NTFS };
static int   fm_clip_src = FM_CLIP_NONE;
static u32   fm_clip_dir;                    /* FAT32: кластер каталога */
static char  fm_clip_path[232];              /* RAM/NTFS: полный путь */
static char  fm_clip_name[FAT32_NAME_MAX + 1];
static char *fm_clip_data = NULL;
static u32   fm_clip_size = 0;

static void fm_clip_free(void)
{
    if (fm_clip_data) { free(fm_clip_data); fm_clip_data = NULL; }
    fm_clip_size = 0;
    fm_clip_src = FM_CLIP_NONE;
}

/* ---- [FM-PROG] (запрос пользователя): полоса прогресса копирования ----
 * Медленная часть копирования — ЧТЕНИЕ файла с НЖМД/флешки (до 8 МиБ
 * через AHCI): раньше окно просто замолкало на секунды. Теперь ФС-чтение
 * идёт с колбэком (fat32/ntfs_read_file_prog — один проход по цепочке),
 * колбэк двигает полосу и зовёт win_draw_now — легальный НЕМЕДЛЕННЫЙ
 * repaint ИЗ ПОТОКА СВОЕГО ОКНА (wm.c). Два окна Файлов копируют
 * по очереди: буфер обмена и полоса — глобальные (как и раньше). */
static struct {
    int         active;
    const char *op;        /* «Копирование» / «Вставка» */
    const char *name;
    u32         done, total;
    u32         last_pct;
} fm_prog;

static void fm_prog_begin(window_t *w, const char *op, const char *name, u32 total)
{
    fm_prog.active = 1;
    fm_prog.op = op;
    fm_prog.name = name ? name : "?";
    fm_prog.done = 0;
    fm_prog.total = total ? total : 1;
    fm_prog.last_pct = 0xFFFFFFFFu;
    win_draw_now(w);          /* показать полосу ДО первого кластера */
}

static void fm_prog_end(window_t *w)
{
    fm_prog.active = 0;
    win_invalidate(w);
}

static int fm_prog_cb(void *ctx, u32 done, u32 total)
{
    fm_prog.done = done;
    fm_prog.total = total ? total : 1;
    /* перерисовка не чаще ~1% полосы: полный fm_draw на каждый кластер
     * (4-32 КиБ) — сотни перерисовок листинга на один большой файл */
    u32 pct = fm_prog.total ? fm_prog.done * 100 / fm_prog.total : 100;
    if (pct == fm_prog.last_pct && done != fm_prog.total) return 0;
    fm_prog.last_pct = pct;
    win_draw_now((window_t *)ctx);
    return 0;
}

static void fm_menu_cb(int id, void *ctx);   /* ниже */

static void fm_clip_copy(fm_t *m, window_t *w)
{
    fm_clip_free();
    if (m->mode == FM_MODE_RAM) {
        if (m->sel < 0 || m->sel >= m->ram_n) return;
        ramfs_dirent_t *e = &m->ram_ents[m->sel];
        if (e->is_dir) { fm_menu_hint = "Каталог скопировать нельзя"; return; }
        if (e->size == 0 || e->size > FM_CLIP_MAX) {
            fm_menu_hint = "Файл пуст или больше 8 МиБ"; return;
        }
        char *buf = (char *)malloc(e->size);
        if (!buf) { fm_menu_hint = "Нет памяти под копию"; return; }
        fm_ram_full(fm_clip_path, sizeof(fm_clip_path), m, e->name);
        fm_prog_begin(w, "Копирование", e->name, e->size);
        u32 got = ramfs_read(fm_clip_path, buf, e->size);
        fm_prog_end(w);
        if (got != e->size) {
            free(buf); fm_menu_hint = "Не удалось прочитать файл"; return;
        }
        fm_clip_src = FM_CLIP_RAM;
        fm_clip_data = buf; fm_clip_size = e->size;
        strncpy(fm_clip_name, e->name, sizeof(fm_clip_name) - 1);
        fm_clip_name[sizeof(fm_clip_name) - 1] = 0;
    } else if (FM_IS_FAT(m->mode) && !(m->mode == FM_MODE_ATA && fm_hdd_fs == 1)
               && fat32_ready()) {
        if (m->sel < 0 || m->sel >= m->fat_n) return;
        fat32_dirent_t *e = &m->fat_ents[m->sel];
        if (e->attr & 0x10) { fm_menu_hint = "Каталог скопировать нельзя"; return; }
        if (e->size == 0 || e->size > FM_CLIP_MAX) {
            fm_menu_hint = "Файл пуст или больше 8 МиБ"; return;
        }
        char *buf = (char *)malloc(e->size);
        if (!buf) { fm_menu_hint = "Нет памяти под копию"; return; }
        fm_prog_begin(w, "Копирование", e->name, e->size);
        u32 got = fat32_read_file_prog(e->first_cluster, e->size, buf, e->size,
                                       fm_prog_cb, w);
        fm_prog_end(w);
        if (got != e->size) {
            free(buf); fm_menu_hint = "Не удалось прочитать файл"; return;
        }
        fm_clip_src = FM_CLIP_FAT;
        fm_clip_dir = m->stk[m->depth].cluster;
        fm_clip_data = buf; fm_clip_size = e->size;
        strncpy(fm_clip_name, e->name, sizeof(fm_clip_name) - 1);
        fm_clip_name[sizeof(fm_clip_name) - 1] = 0;
    } else if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1 && ntfs_ready()) {
        if (m->sel < 0 || m->sel >= m->ntfs_n) return;
        ntfs_dirent_t *e = &m->ntfs_ents[m->sel];
        if (e->is_dir) { fm_menu_hint = "Каталог скопировать нельзя"; return; }
        if (e->size == 0 || e->size > FM_CLIP_MAX) {
            fm_menu_hint = "Файл пуст или больше 8 МиБ"; return;
        }
        char *buf = (char *)malloc(e->size);
        if (!buf) { fm_menu_hint = "Нет памяти под копию"; return; }
        char full[224];
        snprintf(full, sizeof(full), "%s/%s", m->stk[m->depth].path, e->name);
        fm_prog_begin(w, "Копирование", e->name, e->size);
        u32 got = ntfs_read_file_prog(full, buf, e->size, fm_prog_cb, w);
        fm_prog_end(w);
        if (got != e->size) {
            free(buf); fm_menu_hint = "Не удалось прочитать файл"; return;
        }
        fm_clip_src = FM_CLIP_NTFS;
        strncpy(fm_clip_path, full, sizeof(fm_clip_path) - 1);
        fm_clip_path[sizeof(fm_clip_path) - 1] = 0;
        fm_clip_data = buf; fm_clip_size = e->size;
        strncpy(fm_clip_name, e->name, sizeof(fm_clip_name) - 1);
        fm_clip_name[sizeof(fm_clip_name) - 1] = 0;
    } else {
        fm_menu_hint = "Этот источник не читается";
        return;
    }
    /* fm_menu_hint — указатель на строку: текст держим в static-буфере */
    static char clip_msg[96];
    snprintf(clip_msg, sizeof(clip_msg), "Скопировано: %.50s (%u байт)",
             fm_clip_name, (unsigned)fm_clip_size);
    fm_menu_hint = clip_msg;
}

static void fm_clip_paste(fm_t *m, window_t *w)
{
    if (fm_clip_src == FM_CLIP_NONE || !fm_clip_data) {
        fm_menu_hint = "Буфер обмена пуст";
        return;
    }
    if (fm_clip_size == 0) { fm_menu_hint = "Пустой файл в буфере"; return; }

    /* [FM-PROG]: вставка тоже с полосой (RAM — мгновенно, FAT32 —
     * короткая запись ≤128 КиБ, полоса покажет факт операции) */
    fm_prog_begin(w, "Вставка", fm_clip_name, fm_clip_size);

    if (m->mode == FM_MODE_RAM) {
        char full[232];
        fm_ram_full(full, sizeof(full), m, fm_clip_name);
        ramfs_delete(full);
        if (!ramfs_create(full, fm_clip_size) ||
            !ramfs_write(full, fm_clip_data, fm_clip_size)) {
            fm_prog_end(w);
            fm_menu_hint = "Не удалось записать (место?)";
            return;
        }
    } else if (FM_IS_FAT(m->mode) && !(m->mode == FM_MODE_ATA && fm_hdd_fs == 1)
               && fat32_ready()) {
        if (fm_clip_size > 128u * 1024u) {
            fm_prog_end(w);
            fm_menu_hint = "На FAT32 — максимум 128 КиБ";
            return;
        }
        u32 dir = m->stk[m->depth].cluster;
        if (fat32_write_file(dir, fm_clip_name, fm_clip_data, fm_clip_size)
                != fm_clip_size) {
            fm_prog_end(w);
            fm_menu_hint = "Не удалось записать (место?)";
            return;
        }
    } else {
        fm_prog_end(w);
        fm_menu_hint = "Этот источник только для чтения";
        return;
    }
    fm_prog_end(w);
    fm_menu_hint = "Вставлено";
    fm_reload_and_draw(m, w);
}

static void fm_menu_cb(int id, void *ctx)
{
    window_t *w = (window_t *)ctx;
    fm_t *m = (fm_t *)w->data;
    if (!m) return;
    char full[232];

    switch (id) {
    case FMC_OPEN:
        fm_open_selected(w);
        break;
    case FMC_EDIT:
        fm_edit_selected(w);
        break;
    case FMC_RELOAD:
        fm_reload_and_draw(m, w);
        break;
    case FMC_COPY:
        fm_clip_copy(m, w);
        break;
    case FMC_PASTE:
        fm_clip_paste(m, w);
        break;
    case FMC_MKDIR:
    case FMC_TOUCH:
        /* ввод имени — через переиспользуемый диалог (filedlg) */
        {
            extern void serial_puts(const char *s);
            serial_puts(id == FMC_MKDIR ? "[fm] диалог: папка\n"
                                        : "[fm] диалог: файл\n");
        }
        fm_menu_hint = (id == FMC_MKDIR) ? "Новая папка" : "Новый файл";
        fm_pending_kind = id;
        fm_input_owner = w;
        filedlg_input_open(fm_menu_hint,
                           id == FMC_MKDIR ? "Имя папки:" : "Имя файла:",
                           "", FD_NAME_MAX,
                           fm_input_ok, fm_input_cancel, w);
        break;
    case FMC_DELETE: {
        if (m->mode == FM_MODE_RAM) {
            int total = m->ram_n;
            if (m->sel < 0 || m->sel >= total) break;
            ramfs_dirent_t *e = &m->ram_ents[m->sel];
            fm_ram_full(full, sizeof(full), m, e->name);
            if (!ramfs_delete(full)) {
                /* каталог не пуст (или файл занят) */
                fm_menu_hint = e->is_dir ? "Каталог не пуст" : "Не удалось удалить";
            } else {
                fm_menu_hint = "Удалено";
            }
            fm_reload_and_draw(m, w);
        } else if (FM_IS_FAT(m->mode) && !(m->mode == FM_MODE_ATA && fm_hdd_fs == 1)
                   && fat32_ready()) {
            /* сессия 14: удаление на FAT32 (файл — с освобождением цепочки,
             * каталог — только пустой) */
            int total = m->fat_n;
            if (m->sel < 0 || m->sel >= total) break;
            fat32_dirent_t *e = &m->fat_ents[m->sel];
            u32 dir = m->stk[m->depth].cluster;
            if (!fat32_delete(dir, e->name))
                fm_menu_hint = (e->attr & 0x10) ? "Каталог не пуст" : "Не удалось удалить";
            else
                fm_menu_hint = "Удалено";
            fm_reload_and_draw(m, w);
        }
        break;
    }
    }
}


/* ---- Сессия 62: адресная строка с «крошками» ----
 * Путь рисуется по частям: корень (том/источник) и каждая папка —
 * отдельная «кнопка»; клик по части адреса — переход на ту глубину
 * стека каталогов (stk обрезается, reload читает уровень заново).
 * Сегменты, не влезающие в max_w, не рисуются и не кликаются.
 * draw=1 — рисование (подсветка сегмента из crumb_hover);
 * draw=0 — hit-тест: возврат глубины сегмента под курсором (-1). */
static int fm_path_comp(const char *path, int seg, char *out, int outsz)
{
    int idx = 0, i = 0;
    while (path[i]) {
        while (path[i] == '/') i++;
        if (!path[i]) break;
        int start = i;
        while (path[i] && path[i] != '/') i++;
        if (++idx == seg) {
            int len = i - start;
            if (len > outsz - 1) len = outsz - 1;
            memcpy(out, path + start, len);
            out[len] = 0;
            return 1;
        }
    }
    out[0] = 0;
    return 0;
}

static int fm_crumbs(fm_t *m, int x, int hy, int max_w, int draw, int hit_x)
{
    char root[12];
    char L = (m->mode == FM_MODE_ATA) ? fm_vol_letter() : 0;
    if (L) snprintf(root, sizeof(root), "%c:", L);
    else {
        const char *mn = m->mode == FM_MODE_ISO ? "CD" :
                         m->mode == FM_MODE_ATA ? "HDD" :
                         m->mode == FM_MODE_RAM ? "RAM" : "USB";
        snprintf(root, sizeof(root), "%s", mn);
    }
    const char *path = m->stk[m->depth].path;
    int lim = x + max_w;
    int cx  = x;
    int ty  = hy + 3;
    int hit = -1;

    for (int seg = 0; seg <= m->depth; seg++) {
        char comp[64];
        const char *name;
        if (seg == 0) name = root;
        else {
            if (!fm_path_comp(path, seg, comp, sizeof(comp))) break;
            name = comp;
        }
        int bw = (int)fb_text_w(name) + 8;
        if (cx + bw > lim) break;
        int cur = (seg == m->depth);   /* текущий каталог — не кнопка */
        if (draw) {
            if (!cur && m->crumb_hover == seg)
                fb_fill_rect(cx, hy + 2, bw, FM_HDR - 4, wm_theme_sel_bg());
            fb_text(cx + 4, ty, name,
                    cur ? wm_theme_text() : fb_rgb(0x8F, 0xC8, 0xFF), -1);
        } else if (hit_x >= cx && hit_x < cx + bw) {
            hit = seg;
        }
        cx += bw;
        if (seg < m->depth) {
            if (draw) fb_text(cx + 2, ty, "/", wm_theme_text_dim(), -1);
            cx += 12;
        }
    }
    return hit;
}

static void fm_draw(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x17, 0x1C));

    /* === Панель выбора устройства === */
    fb_fill_rect(0, 0, cw, FM_DEVBAR, fb_rgb(0x0C, 0x0F, 0x14));
    fb_hline(0, cw - 1, FM_DEVBAR - 1, fb_rgb(0x2C, 0x31, 0x38));
    {
        /* Сессия 25: [CD] | тома C:, D:, ... | [RAM] [USB] */
        fm_devbtn_t btns[FM_MAX_VOLS + 3];
        int nb = fm_devbar_layout(btns, (int)(sizeof(btns) / sizeof(btns[0])));
        for (int i = 0; i < nb; i++) {
            char lbl[8];
            const char *name;
            int hot;
            if (btns[i].kind == 1) {
                snprintf(lbl, sizeof(lbl), "%c:", fm_vols[btns[i].idx].letter);
                name = lbl;
                hot = (m->mode == FM_MODE_ATA && fm_vol_cur == btns[i].idx);
            } else {
                name = fm_btn_name[btns[i].idx == FM_MODE_ISO ? 0 :
                                  btns[i].idx == FM_MODE_RAM ? 2 :
                                  btns[i].idx == FM_MODE_USB ? 3 : 1];
                hot = (m->mode == btns[i].idx);
            }
            int hov = (m->dev_hover == i);
            u32 bg = hot ? wm_theme_sel_bg() :
                    (hov ? fb_rgb(0x1E, 0x33, 0x4A) : wm_theme_win_bg_alt());
            u32 fg = hot ? wm_theme_text() : wm_theme_text_dim();
            fb_fill_rect(btns[i].x, 2, btns[i].w, FM_DEVBAR - 4, bg);
            fb_rect(btns[i].x, 2, btns[i].w, FM_DEVBAR - 4, fb_rgb(0x2C, 0x31, 0x38));
            fb_text(btns[i].x + 6, 4, name, fg, -1);
        }
        /* Информация о выбранном устройстве справа */
        char infobuf[72];
        char lpref[4];
        const char *info = infobuf;
        if (m->mode == FM_MODE_ISO)
            info = iso9660_ready() ? "CD/ISO9660" : "нет CD";
        else if (m->mode == FM_MODE_ATA) {
            char L = fm_vol_letter();
            const char *lab = (fm_hdd_fs == 1)
                ? (ntfs_ready() ? ntfs_label() : "нет NTFS")
                : (fat32_ready() && !fat32_is_usb()
                    ? fat32_label() : "нет FAT32/exFAT");
            if (L) { lpref[0] = L; lpref[1] = ':'; lpref[2] = ' '; lpref[3] = 0; }
            else   lpref[0] = 0;
            snprintf(infobuf, sizeof(infobuf), "%s%s", lpref, lab);
        }
        else if (m->mode == FM_MODE_RAM)
            info = ramfs_ready() ? "RAM disk" : "не инициализирован";
        else
            info = fat32_ready() ? fat32_label() : "нет флешки";
        {
            /* справа; не рисуем, если не влезает после кнопок */
            int tw = (int)fb_text_w(info);
            int lx = cw - 8 - tw;
            int lastx = 0;
            for (int i = 0; i < nb; i++)
                lastx = btns[i].x + btns[i].w;
            if (lx >= lastx + 8)
                fb_text(lx, 4, info, wm_theme_text_info(), -1);
        }
    }

    /* === Строка пути: [Назад] + «крошки» (сессия 62) ===
     * Кнопка «Назад» — уровень выше (дублирует Backspace); каждая
     * часть адреса — кнопка: клик — переход на эту глубину стека. */
    {
        int hy = FM_DEVBAR;
        int by = hy + 3, bh = FM_HDR - 6;
        int en = m->depth > 0;
        fb_fill_rect(0, hy, cw, FM_HDR, wm_theme_title());
        wm_button_draw(4, by, FM_BACK_W, bh, "Назад",
                       !en ? wm_theme_win_bg_alt()
                           : (m->back_hover ? fb_rgb(0x32, 0x60, 0x8E)
                                            : fb_rgb(0x1B, 0x21, 0x27)),
                       en ? wm_theme_text() : wm_theme_text_dim(),
                       en ? wm_theme_accent() : fb_rgb(0x2C, 0x31, 0x38));
        fm_crumbs(m, FM_CRUMB_X, hy, cw - FM_CRUMB_X - 6, 1, 0);
    }

    /* Проверка готовности устройства */
    int list_y0 = FM_DEVBAR + FM_HDR;
    {
        const char *msg = NULL;
        if (m->mode == FM_MODE_ISO && !iso9660_ready())
            msg = "CD/ISO9660: диск не читается";
        else if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1 && !ntfs_ready())
            msg = sata_pending() ? "SATA: инициализация в фоне (AHCI)..."
                                 : "NTFS-раздел не найден.";
        else if (((m->mode == FM_MODE_ATA && fm_hdd_fs == 0) ||
                  m->mode == FM_MODE_USB) && !fat32_ready())
            msg = m->mode == FM_MODE_USB ? "USB FAT32: флешка не готова"
                                         : (sata_pending()
                                            ? "SATA: инициализация в фоне (AHCI)..."
                                            : "FAT32-раздел не найден.");
        else if (m->mode == FM_MODE_RAM && !ramfs_ready())
            msg = "RAMFS не инициализирован.";
        if (msg) {
            fb_text(12, list_y0 + 8, msg, fb_rgb(0xE0, 0x9A, 0x9A), -1);
            fb_text(12, list_y0 + 28, sata_pending() ? "Кнопка [HDD] оживёт сама"
                       : "Кликните на устройство выше", wm_theme_text_dim(), -1);
            return;
        }
    }

    int area_h  = ch - list_y0 - 20;
    int vis = area_h / FM_ROW;
    if (vis < 1) vis = 1;
    if (m->sel < m->scroll) m->scroll = m->sel;
    if (m->sel >= m->scroll + vis) m->scroll = m->sel - vis + 1;

    int y0 = list_y0 + 2;
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    
    for (int i = 0; i < vis; i++) {
        int idx = m->scroll + i;
        if (idx >= total) break;
        
        const char *name;
        u32 size;
        int is_dir;
        
        if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
            ntfs_dirent_t *e = &m->ntfs_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        } else if (m->mode == FM_MODE_ISO) {
            iso9660_dirent_t *e = &m->iso_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        } else if (FM_IS_FAT(m->mode)) {
            fat32_dirent_t *e = &m->fat_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = (e->attr & 0x10) ? 1 : 0;
        } else {
            ramfs_dirent_t *e = &m->ram_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        }
        
        int yy = y0 + i * FM_ROW;
        if (idx == m->sel)
            fb_fill_rect(0, yy, cw, FM_ROW, wm_theme_sel_bg());

        u32 col = is_dir ? fb_rgb(0x8F, 0xC8, 0xFF) : wm_theme_text();
        fb_text(6, yy + 1, is_dir ? "[D]" : "   ", col, -1);
        fb_text(6 + 4*8, yy + 1, name, col, -1);

        if (!is_dir) {
            char buf[24];
            if (size < 1024)                 snprintf(buf, sizeof(buf), "%u B",   (unsigned)size);
            else if (size < 1024u*1024)      snprintf(buf, sizeof(buf), "%u KiB", (unsigned)(size/1024));
            else                             snprintf(buf, sizeof(buf), "%u MiB", (unsigned)(size/(1024u*1024)));
            int tw = (int)fb_text_w(buf);
            fb_text(cw - tw - 8, yy + 1, buf, wm_theme_text_dim(), -1);
        }
    }

    /* [FM-PROG]: полоса прогресса копирования/вставки — рисуется и при
     * штатной перерисовке, и из fm_prog_cb через win_draw_now */
    if (fm_prog.active) {
        int by = ch - 54;
        if (by < FM_DEVBAR + FM_HDR + 4) by = FM_DEVBAR + FM_HDR + 4;
        fb_fill_rect(4, by - 15, cw - 8, 15 + 17, fb_rgb(0x0C, 0x0F, 0x14));
        char pt[96];
        snprintf(pt, sizeof(pt), "%s: %.36s — %u%% (%u/%u КиБ)",
                 fm_prog.op, fm_prog.name,
                 fm_prog.total ? (unsigned)(fm_prog.done * 100 / fm_prog.total) : 100,
                 (unsigned)(fm_prog.done >> 10),
                 (unsigned)(fm_prog.total >> 10));
        fb_text(6, by - 13, pt, wm_theme_text(), -1);
        fb_rect(4, by, cw - 8, 12, fb_rgb(0x3E, 0x7D, 0xBF));
        if (fm_prog.total) {
            u32 fw = (u32)(cw - 10) * fm_prog.done / fm_prog.total;
            if (fw) fb_fill_rect(5, by + 1, (int)fw, 10, fb_rgb(0x3E, 0x7D, 0xBF));
        }
    }

    char st[96];
    snprintf(st, sizeof(st), "%d / %d | Tab: режим%s%s",
             total ? m->sel + 1 : 0, total,
             (m->mode == FM_MODE_ATA && fm_vol_count > 1)
                 ? ", F5: сменить том" : "",
             m->mode == FM_MODE_RAM ? ", ПКМ: меню" : "");
    fb_text(6, ch - 16, st, wm_theme_text_dim(), -1);
    if (fm_menu_hint && fm_menu_hint[0]) {
        fb_text(6, ch - 32, fm_menu_hint, fb_rgb(0x90, 0xEE, 0x90), -1);
        fm_menu_hint = NULL;              /* показываем один раз */
    }
}

/* --------- просмотрщик --------- */

typedef struct {
    char *buf;
    u32   len;
    int   top;
    int   source; /* 0 = FAT32, 1 = RAMFS, 2 = CD/ISO9660 */
    wm_scrollbar_t sb;   /* общий виджет полосы прокрутки (сессия 17) */
} viewer_t;

/* число строк в буфере просмотрщика (для полосы прокрутки) */
static int viewer_count_lines(const viewer_t *v)
{
    int n = 1;
    for (u32 i = 0; i < v->len; i++)
        if (v->buf[i] == '\n') n++;
    return n;
}

static void viewer_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    viewer_t *v = (viewer_t *)w->data;
    int cw = win_content_w(w);
    if (mx < 0 || my < 0) {
        /* сессия 20 (неявный захват мыши): отпускание за пределами окна
         * обязано дойти до полосы — иначе drag «залипал» бы до первого
         * события внутри окна */
        if (v->sb.dragging)
            wm_scrollbar_mouse(&v->sb, mx, my, btn, changed);
        return;
    }
    if (mx >= cw - 9 || v->sb.dragging) {
        int np = wm_scrollbar_mouse(&v->sb, mx, my, btn, changed);
        if (np >= 0) { v->top = np; win_invalidate(w); }
    }
}

static void viewer_draw(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int cols = cw / 8;
    int vis  = ch / 16;

    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    /* Заголовок с источником */
    const char *src = v->source == 0 ? fat32_fsname() :
                      v->source == 2 ? "CD/ISO9660" : "RAMFS";
    u32 src_col = v->source == 0 ? fb_rgb(0x8F, 0xC8, 0xFF) :
                  v->source == 2 ? fb_rgb(0xFF, 0xE0, 0x60) : fb_rgb(0x90, 0xEE, 0x90);
    fb_text(4, 2, src, src_col, -1);

    int line = 0, i = 0;
    while (i < (int)v->len && line < v->top) {
        if (v->buf[i] == '\n') line++;
        i++;
    }
    int y = 18;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)v->len; r++) {
        int start = i, end = i;
        while (end < (int)v->len && v->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols) len = cols;
        if (len > 255)  len = 255;
        memcpy(tmp, v->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, wm_theme_text(), -1);
        i = end + (end < (int)v->len ? 1 : 0);
        y += 16;
    }

    /* полоса прокрутки (общий виджет, цвет из темы) */
    int nlines = viewer_count_lines(v);
    int max_scroll = nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (v->top > max_scroll) v->top = max_scroll;
    if (v->top < 0) v->top = 0;
    wm_scrollbar_draw(&v->sb, cw - 7, 2, 5, ch - 4, v->top, max_scroll, vis);
}

static void viewer_key(window_t *w, const key_event_t *ev)
{
    viewer_t *v = (viewer_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == KBD_UP)   { if (v->top > 0) v->top--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { v->top++; win_invalidate(w); }
    if (ev->code == 0x49)     { v->top -= 16; if (v->top < 0) v->top = 0; win_invalidate(w); }
    if (ev->code == 0x51)     { v->top += 16; win_invalidate(w); }
    /* границы top приводятся в норму в viewer_draw при отрисовке */
}

static void viewer_close(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    if (v) { if (v->buf) free(v->buf); free(v); }
}

static void viewer_open_fat(const fat32_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 0;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = fat32_read_file(e->first_cluster, e->size, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [FAT32]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, viewer_mouse, NULL, viewer_close, v);
}

/* Сессия 13: чтение RAM-файла по ПОЛНОМУ пути (иерархия каталогов);
 * e->name используется только для заголовка окна. */
static void viewer_open_ram_path(const char *full, const ramfs_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 1;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = ramfs_read(full, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [RAMFS]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, viewer_mouse, NULL, viewer_close, v);
}

/* Просмотр файла с NTFS-раздела (сессия 11) */
static void viewer_open_ntfs(const char *dir_path, const ntfs_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 0;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }

    char full[224];
    snprintf(full, sizeof(full), "%s/%s", dir_path, e->name);
    v->len = ntfs_read_file(full, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [NTFS]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, viewer_mouse, NULL, viewer_close, v);
}

/* Просмотр файла с загрузочного CD (ISO9660, только чтение) */
static void viewer_open_iso(const iso9660_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(v));
    v->source = 2;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = iso9660_read_file(e->first_lba, e->size, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [CD]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, viewer_mouse, NULL, viewer_close, v);
}

/* --------- события файлового менеджера --------- */

/* QuickJS-скрипты: .js (legacy: старые .cs от CMScript открывались так же) */
static int name_is_cs_script(const char *name)
{
    int L = (int)strlen(name);
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 3) return 0;
    char a = name[dot+1], b = name[dot+2];
    int is_js = (a=='j'||a=='J') && (b=='s'||b=='S');
    int is_cs = (a=='c'||a=='C') && (b=='s'||b=='S');
    return is_js || is_cs;
}

static int name_is_c4_source(const char *name)
{
    int L = (int)strlen(name);
    if (L < 2) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 2) return 0;
    char ext = name[dot + 1];
    return (ext == 'c' || ext == 'C');
}

/* Проверить, заканчивается ли имя на .bin (исполняемое приложение). */
static int name_is_bin_app(const char *name)
{
    int L = (int)strlen(name);
    if (L < 5) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 4) return 0;
    return (name[dot+1]=='b'||name[dot+1]=='B')
        && (name[dot+2]=='i'||name[dot+2]=='I')
        && (name[dot+3]=='n'||name[dot+3]=='N');
}

/* СЕССИЯ 14 «универсальный текстовый редактор»: какие файлы считать
 * ТЕКСТОМ и открывать в редакторе (прочие — в просмотрщике). */
static int name_is_text(const char *name)
{
    static const char *exts[] = { "txt", "log", "ini", "cfg", "bat", 0 };
    int L = (int)strlen(name);
    if (L < 4) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--)
        if (name[i] == '.') { dot = i; break; }
    if (dot < 0 || dot + 1 >= L) return 0;
    for (int k = 0; exts[k]; k++) {
        const char *e = exts[k];
        int el = (int)strlen(e);
        if (L - dot - 1 == el) {
            int ok = 1;
            for (int i = 0; i < el; i++) {
                char a = name[dot + 1 + i];
                if (a >= 'A' && a <= 'Z') a += 32;
                if (a != e[i]) { ok = 0; break; }
            }
            if (ok) return 1;
        }
    }
    return 0;
}

/* Сессия 60: сравнить расширение имени без учёта регистра. */
static int name_ext_is(const char *name, const char *ext)
{
    int L = (int)strlen(name), el = (int)strlen(ext);
    if (L <= el) return 0;
    const char *dot = name + L - el - 1;
    if (*dot != '.') return 0;
    for (int i = 0; i < el; i++) {
        char a = dot[1 + i], b = ext[i];
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a != b) return 0;
    }
    return 1;
}

/* Сессия 60: ассоциации файлов с новыми приложениями —
 * .mp3 → MP3-плеер (dr_mp3), картинки → просмотрщик (imgsvc). */
static int name_is_mp3(const char *name)
{
    return name_ext_is(name, "mp3");
}

static int name_is_image(const char *name)
{
    return name_ext_is(name, "png") || name_ext_is(name, "jpg") ||
           name_ext_is(name, "jpeg") || name_ext_is(name, "bmp") ||
           name_ext_is(name, "gif");
}

/* Запрос: «файлы md и html/htm нужно открывать через браузер».
 * .md рендерится браузером как Markdown, .html/.htm — конвертером
 * HTML→Markdown (browser_load_content сам различает формат по '<').
 * «Редактировать» в контекстном меню открывает их же в редакторе. */
static int name_is_web_doc(const char *name)
{
    return name_ext_is(name, "md") || name_ext_is(name, "html") ||
           name_ext_is(name, "htm");
}

/* Лимит чтения файла под новое приложение (байты). */
#define FM_MP3_READ_MAX   (24u * 1024u * 1024u)   /* ~25 минут CBR 128k */
#define FM_IMG_READ_MAX   (8u  * 1024u * 1024u)

static void fm_open_selected(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    if (m->sel < 0 || m->sel >= total) return;

    if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
        /* NTFS: каталогы по пути, файлы — редактор/просмотрщик */
        ntfs_dirent_t *e = &m->ntfs_ents[m->sel];
        if (e->is_dir) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            m->sel = 0;
            m->scroll = 0;
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name) || name_is_c4_source(e->name)) {
            /* .cs/.c с NTFS → копия в RAM disk → редактор */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                char full[224];
                snprintf(full, sizeof(full), "%s/%s",
                         m->stk[m->depth].path, e->name);
                u32 got = ntfs_read_file(full, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                if (name_is_cs_script(e->name))
                    app_quickjs_open_with(e->name, buf, (int)got);
                else
                    app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_web_doc(e->name)) {
            /* Запрос: .md/.html/.htm — в БРАУЗЕРЕ (Markdown/HTML-рендер).
             * Лимит — как у браузера для файлов RAM disk (BR_FILE_MAX). */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                char full[224];
                snprintf(full, sizeof(full), "%s/%s",
                         m->stk[m->depth].path, e->name);
                u32 got = ntfs_read_file(full, buf, cap);
                buf[got] = 0;
                app_browser_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_text(e->name)) {
            /* СЕССИЯ 14: .txt/... с NTFS → копия в RAM → редактор */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                char full[224];
                snprintf(full, sizeof(full), "%s/%s",
                         m->stk[m->depth].path, e->name);
                u32 got = ntfs_read_file(full, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_mp3(e->name) || name_is_image(e->name)) {
            /* Сессия 60: .mp3 → плеер, картинки → просмотрщик.
             * Владение буфером переходит приложению (не free). */
            u32 cap = name_is_mp3(e->name) ? FM_MP3_READ_MAX : FM_IMG_READ_MAX;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap);
            if (buf) {
                char full[224];
                snprintf(full, sizeof(full), "%s/%s",
                         m->stk[m->depth].path, e->name);
                u32 got = ntfs_read_file(full, buf, cap);
                if (got == 0) free(buf);
                else if (name_is_mp3(e->name))
                    app_mp3_open_with(e->name, buf, got);
                else
                    app_imgview_open_with(e->name, buf, got);
            }
        } else {
            viewer_open_ntfs(m->stk[m->depth].path, e);
        }
    } else if (m->mode == FM_MODE_ISO) {
        /* CD/ISO9660: каталогы по LBA+размеру, файлы — просмотр/копирование */
        iso9660_dirent_t *e = &m->iso_ents[m->sel];
        if (e->is_dir) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            m->stk[m->depth].cluster = e->first_lba;   /* LBA каталога */
            m->stk[m->depth].iso_size = e->size;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            m->sel = 0;
            m->scroll = 0;
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name) || name_is_c4_source(e->name)) {
            /* .cs/.c с CD → скопировать в RAM disk и открыть в редакторе */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = iso9660_read_file(e->first_lba, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                if (name_is_cs_script(e->name))
                    app_quickjs_open_with(e->name, buf, (int)got);
                else
                    app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_web_doc(e->name)) {
            /* Запрос: .md/.html/.htm — в браузере (CD). */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = iso9660_read_file(e->first_lba, e->size, buf, cap);
                buf[got] = 0;
                app_browser_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_text(e->name)) {
            /* СЕССИЯ 14: .txt/... с CD → копия в RAM → редактор */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = iso9660_read_file(e->first_lba, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_mp3(e->name) || name_is_image(e->name)) {
            /* Сессия 60: .mp3 → плеер, картинки → просмотрщик (CD).
             * Владение буфером переходит приложению (не free). */
            u32 cap = name_is_mp3(e->name) ? FM_MP3_READ_MAX : FM_IMG_READ_MAX;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap);
            if (buf) {
                u32 got = iso9660_read_file(e->first_lba, e->size, buf, cap);
                if (got == 0) free(buf);
                else if (name_is_mp3(e->name))
                    app_mp3_open_with(e->name, buf, got);
                else
                    app_imgview_open_with(e->name, buf, got);
            }
        } else {
            viewer_open_iso(e);
        }
    } else if (FM_IS_FAT(m->mode)) {
        /* FAT32 режим (ATA или USB) */
        fat32_dirent_t *e = &m->fat_ents[m->sel];
        if (e->attr & 0x10) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            m->stk[m->depth].cluster = e->first_cluster;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name)) {
            /* .cs-файл → открыть в CMScript-редакторе */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                app_quickjs_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_web_doc(e->name)) {
            /* Запрос: .md/.html/.htm — в браузере (FAT32). */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                app_browser_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_text(e->name)) {
            /* СЕССИЯ 14 «универсальный текстовый редактор»: .txt/... —
             * прямо в его каталоге на диске; F2/F9 сохранят туда же */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                app_editor_open_at(m->mode == FM_MODE_USB ? FD_SRC_USB : FD_SRC_ATA,
                                   m->stk[m->depth].path,
                                   m->stk[m->depth].cluster,
                                   e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_bin_app(e->name)) {
            /* .bin с FAT32 (сессия 14): копия в RAM + запуск (как в RAM-режиме) */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                (void)loader_spawn(e->name, NULL);
                free(buf);
            }
        } else if (name_is_c4_source(e->name)) {
            /* .c-файл (сессия 14): редактор с целью — этот же каталог на диске */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                app_editor_open_at(m->mode == FM_MODE_USB ? FD_SRC_USB : FD_SRC_ATA,
                                   m->stk[m->depth].path,
                                   m->stk[m->depth].cluster,
                                   e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_mp3(e->name) || name_is_image(e->name)) {
            /* Сессия 60: .mp3 → плеер, картинки → просмотрщик (FAT32).
             * Владение буфером переходит приложению (не free). */
            u32 cap = name_is_mp3(e->name) ? FM_MP3_READ_MAX : FM_IMG_READ_MAX;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                if (got == 0) free(buf);
                else if (name_is_mp3(e->name))
                    app_mp3_open_with(e->name, buf, got);
                else
                    app_imgview_open_with(e->name, buf, got);
            }
        } else {
            /* прочие файлы → простой просмотрщик */
            viewer_open_fat(e);
        }
    } else {
        /* RAMFS режим (сессия 13: каталоги — иерархия, файлы — по полному
         * пути: e->name из list_dir — БАЗОВОЕ имя, читаем cur_path+name) */
        ramfs_dirent_t *e = &m->ram_ents[m->sel];
        char full[232];
        fm_ram_full(full, sizeof(full), m, e->name);
        if (e->is_dir) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            m->sel = 0;
            m->scroll = 0;
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_c4_source(e->name)) {
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                buf[got] = 0;
                app_editor_open_with(full, buf, (int)got);
                free(buf);
            }
        } else if (name_is_cs_script(e->name)) {
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                buf[got] = 0;
                app_quickjs_open_with(full, buf, (int)got);
                free(buf);
            }
        } else if (name_is_bin_app(e->name)) {
            int tid = loader_spawn(full, NULL);
            (void)tid;
        } else if (name_is_web_doc(e->name)) {
            /* Запрос: .md/.html/.htm — в браузере (RAM disk).
             * URL — ПОЛНЫЙ путь страницы: картинки «./LOGO.PNG» и
             * «LOGO.PNG» разрешаются относительно её каталога
             * (см. img_url_resolve в imgsvc). */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                buf[got] = 0;
                app_browser_open_with(full, buf, (int)got);
                free(buf);
            }
        } else if (name_is_text(e->name)) {
            /* СЕССИЯ 14 «универсальный текстовый редактор»: .txt/...
             * с RAM disk — в редакторе, цель — этот же каталог */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                buf[got] = 0;
                app_editor_open_at(FD_SRC_RAMFS, m->stk[m->depth].path, 0,
                                   e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_mp3(e->name) || name_is_image(e->name)) {
            /* Сессия 60: .mp3 → плеер, картинки → просмотрщик (RAM disk).
             * Владение буфером переходит приложению (не free). */
            u32 cap = name_is_mp3(e->name) ? FM_MP3_READ_MAX : FM_IMG_READ_MAX;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap);
            if (buf) {
                u32 got = ramfs_read(full, buf, cap);
                if (got == 0) free(buf);
                else if (name_is_mp3(e->name))
                    app_mp3_open_with(e->name, buf, got);
                else
                    app_imgview_open_with(e->name, buf, got);
            }
        } else {
            viewer_open_ram_path(full, e);
        }
    }
}

/* «Редактировать» из контекстного меню (запрос): открыть выделенный
 * файл в РЕДАКТОРЕ независимо от того, куда он открыт по умолчанию
 * (web-файлы .md/.html/.htm по «Открыть» идут в браузер). Цель
 * сохранения — как у обычных текстовых файлов:
 *   FAT32/RAM — прямо в своём каталоге (app_editor_open_at),
 *   NTFS/ISO  — копия в RAM disk (app_editor_open_with). */
static void fm_edit_selected(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int d = m->depth;            /* текущий уровень стека каталогов */
    int si = m->sel;             /* выделенная строка списка */
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    if (si < 0 || si >= total) return;

    if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
        ntfs_dirent_t *e = &m->ntfs_ents[si];
        if (e->is_dir) return;
        u32 cap = 65536;
        if (e->size < cap) cap = e->size;
        char *buf = (char *)malloc(cap + 1);
        if (!buf) return;
        char full[224];
        snprintf(full, sizeof(full), "%s/%s", m->stk[d].path, e->name);
        u32 got = ntfs_read_file(full, buf, cap);
        buf[got] = 0;
        if (ramfs_ready()) {
            ramfs_delete(e->name);
            if (ramfs_create(e->name, got + 1))
                ramfs_write(e->name, buf, got + 1);
        }
        app_editor_open_with(e->name, buf, (int)got);
        free(buf);
    } else if (m->mode == FM_MODE_ISO) {
        iso9660_dirent_t *e = &m->iso_ents[si];
        if (e->is_dir) return;
        u32 cap = 65536;
        if (e->size < cap) cap = e->size;
        char *buf = (char *)malloc(cap + 1);
        if (!buf) return;
        u32 got = iso9660_read_file(e->first_lba, e->size, buf, cap);
        buf[got] = 0;
        if (ramfs_ready()) {
            ramfs_delete(e->name);
            if (ramfs_create(e->name, got + 1))
                ramfs_write(e->name, buf, got + 1);
        }
        app_editor_open_with(e->name, buf, (int)got);
        free(buf);
    } else if (FM_IS_FAT(m->mode)) {
        fat32_dirent_t *e = &m->fat_ents[si];
        if (e->attr & 0x10) return;
        u32 cap = 65536;
        if (e->size < cap) cap = e->size;
        char *buf = (char *)malloc(cap + 1);
        if (!buf) return;
        u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
        buf[got] = 0;
        app_editor_open_at(m->mode == FM_MODE_USB ? FD_SRC_USB : FD_SRC_ATA,
                           m->stk[d].path,
                           m->stk[d].cluster,
                           e->name, buf, (int)got);
        free(buf);
    } else {
        /* RAMFS */
        ramfs_dirent_t *e = &m->ram_ents[si];
        if (e->is_dir) return;
        u32 cap = 65536;
        if (e->size < cap) cap = e->size;
        char *buf = (char *)malloc(cap + 1);
        if (!buf) return;
        char full[232];
        fm_ram_full(full, sizeof(full), m, e->name);
        u32 got = ramfs_read(full, buf, cap);
        buf[got] = 0;
        app_editor_open_at(FD_SRC_RAMFS, m->stk[d].path, 0,
                           e->name, buf, (int)got);
        free(buf);
    }
}

static void fm_up(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    if (m->depth == 0) return;
    m->depth--;
    m->crumb_hover = -1;    /* сегменты сместились — подсветка устарела */
    m->back_hover  = 0;
    fm_reload(m);
    win_invalidate(w);
}

static void fm_switch_mode(fm_t *m, int new_mode)
{
    if (new_mode < 0 || new_mode >= FM_MODE_COUNT) return;
    m->mode = new_mode;
    m->depth = 0;
    m->sel = 0;
    m->scroll = 0;
    if (m->mode == FM_MODE_ATA) {
        /* сессия 25: монтируем АКТИВНЫЙ том (а не «первый подходящий»);
         * если активный ещё не выбран — первый найденный */
        fm_scan_vols();
        if (fm_vol_cur < 0 && fm_vol_count > 0) {
            /* при старте ОС ядро уже могло смонтировать FAT32 — подхватим
             * этот том, чтобы не перемонтировать зря */
            if (fat32_ready() && !fat32_is_usb()) {
                for (int i = 0; i < fm_vol_count; i++)
                    if (!fm_vols[i].is_ntfs) { fm_vol_cur = i; break; }
            }
            if (fm_vol_cur < 0) fm_vol_cur = 0;
        }
        if (fm_vol_cur >= 0)
            fm_mount_vol(fm_vol_cur);
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else if (m->mode == FM_MODE_USB) {
        if (!fat32_init_usb())
            fm_usb_bad = 1;     /* Сессия 12: ФС не FAT32 — кнопку прячем */
        else
            fm_usb_bad = 0;
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else {
        /* CD/ISO9660 и RAMFS — инициализация уже выполнена при загрузке */
        m->stk[0].cluster = 0;
    }
    strcpy(m->stk[0].path, "/");
    fm_reload(m);
}

static void fm_key(window_t *w, const key_event_t *ev)
{
    fm_t *m = (fm_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    
    if (ev->code == 0x3F) { /* F5 — цикл по томам НЖМД (сессия 25) */
        if (m->mode == FM_MODE_ATA) {
            fm_scan_vols();
            if (fm_vol_count > 1) {
                int nv = (fm_vol_cur + 1) % fm_vol_count;
                fm_mount_vol(nv);
                m->depth = 0;
                m->sel = 0;
                m->scroll = 0;
                m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
                strcpy(m->stk[0].path, "/");
                fm_reload(m);
                win_invalidate(w);
            }
        }
        return;
    }

    if (ev->code == 0x0F) { /* Tab - переключение режима (CD → HDD → RAM → USB → CD) */
        int cur_btn = 0;
        for (int i = 0; i < 4; i++)
            if (fm_btn_mode[i] == m->mode) { cur_btn = i; break; }
        fm_switch_mode(m, fm_btn_mode[(cur_btn + 1) % 4]);
        win_invalidate(w);
        return;
    }
    
    if (ev->code == KBD_UP)   { if (m->sel > 0)     m->sel--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { 
        int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                    FM_IS_FAT(m->mode) ? m->fat_n :
                    (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
        if (m->sel+1 < total) m->sel++; 
        win_invalidate(w); 
    }
    if (ev->code == 0x1C || ev->ch == '\n') fm_open_selected(w);
    if (ev->code == 0x0E || ev->ch == '\b') fm_up(w);
    if (ev->ch == 'r' || ev->ch == 'R') { fm_reload(m); win_invalidate(w); }
    /* Esc — закрыть файловый менеджер (как браузер и HTTP Trace) */
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
}

static void fm_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    fm_t *m = (fm_t *)w->data;

    /* Обработка кликов по кнопкам устройств (только ДОСТУПНЫЕ — сессия 12) */
    if (my < FM_DEVBAR) {
        /* Подсветка наведения: раскладка та же, что в fm_draw (сессия 25) */
        fm_devbtn_t btns[FM_MAX_VOLS + 3];
        int nb = fm_devbar_layout(btns, (int)(sizeof(btns) / sizeof(btns[0])));
        int new_hover = -1;
        for (int i = 0; i < nb; i++)
            if (mx >= btns[i].x && mx < btns[i].x + btns[i].w) { new_hover = i; break; }
        if (new_hover != m->dev_hover) {
            m->dev_hover = new_hover;
            win_invalidate(w);
        }
        /* Клик: том — смонтировать; режим — fm_switch_mode */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && new_hover >= 0) {
            if (btns[new_hover].kind == 1) {
                if (m->mode != FM_MODE_ATA ||
                    fm_vol_cur != btns[new_hover].idx) {
                    fm_mount_vol(btns[new_hover].idx);
                    if (m->mode != FM_MODE_ATA) {
                        m->mode = FM_MODE_ATA;
                        m->depth = 0;
                        m->sel = 0;
                        m->scroll = 0;
                        strcpy(m->stk[0].path, "/");
                    }
                    m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
                    fm_reload(m);
                }
            } else {
                fm_switch_mode(m, btns[new_hover].idx);
            }
            win_invalidate(w);
        }
        return;
    }
    m->dev_hover = -1;

    fm_mouse_rmb(w, m, mx, my, btn, changed);

    /* === Сессия 62: строка пути — кнопка «Назад» + «крошки» === */
    if (my < FM_DEVBAR + FM_HDR) {
        int cw = win_content_w(w);
        int bhov = wm_button_hit(mx, my, 4, FM_DEVBAR + 3,
                                 FM_BACK_W, FM_HDR - 6);
        int hov = fm_crumbs(m, FM_CRUMB_X, FM_DEVBAR,
                            cw - FM_CRUMB_X - 6, 0, mx);
        if (hov == m->depth) hov = -1;  /* текущий каталог не подсвечиваем */
        if (bhov != m->back_hover || hov != m->crumb_hover) {
            m->back_hover  = bhov;
            m->crumb_hover = hov;
            win_invalidate(w);
        }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            if (bhov) {
                fm_up(w);               /* сам делает invalidate */
            } else if (hov >= 0 && hov < m->depth) {
                m->depth = hov;
                fm_reload(m);
                m->crumb_hover = -1;
                m->back_hover  = 0;
                win_invalidate(w);
            }
        }
        return;
    }
    if (m->back_hover || m->crumb_hover != -1) {
        m->back_hover  = 0;
        m->crumb_hover = -1;
        win_invalidate(w);
    }

    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT)) return;
    if (my < FM_DEVBAR + FM_HDR + 2) return;
    int row = (my - FM_DEVBAR - FM_HDR - 2) / FM_ROW;
    int idx = m->scroll + row;
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    if (idx < 0 || idx >= total) return;
    if (idx == m->sel) fm_open_selected(w);
    else { m->sel = idx; win_invalidate(w); }
}

/* ---- ПКМ: контекстное меню (сессия 13) ---- */
/* Выделенный файл редактируем ли (пункт «Редактировать»):
 * web-файлы (.md/.html/.htm — «Открыть» уводит их в браузер),
 * текстовые, .c-исходники и .js/.cs-скрипты. Каталоги — нет. */
static int fm_sel_editable(fm_t *m)
{
    int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                FM_IS_FAT(m->mode) ? m->fat_n :
                (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
    int si = m->sel;
    if (si < 0 || si >= total) return 0;
    const char *nm = NULL;
    int is_dir = 0;
    if (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) {
        ntfs_dirent_t *e = &m->ntfs_ents[si];
        nm = e->name; is_dir = e->is_dir;
    } else if (m->mode == FM_MODE_ISO) {
        iso9660_dirent_t *e = &m->iso_ents[si];
        nm = e->name; is_dir = e->is_dir;
    } else if (FM_IS_FAT(m->mode)) {
        fat32_dirent_t *e = &m->fat_ents[si];
        nm = e->name; is_dir = (e->attr & 0x10) != 0;
    } else {
        ramfs_dirent_t *e = &m->ram_ents[si];
        nm = e->name; is_dir = e->is_dir;
    }
    if (!nm || is_dir) return 0;
    return name_is_web_doc(nm) || name_is_text(nm) ||
           name_is_c4_source(nm) || name_is_cs_script(nm);
}

static wm_menu_item_t fm_menu_items[12];   /* СЕССИЯ 61: + Копировать/Вставить;
                                            * + «Редактировать» (запрос) */
static int fm_menu_n;

static void fm_mouse_rmb(window_t *w, fm_t *m, int mx, int my, u8 btn, u8 changed)
{
    if (!((changed & MSB_RIGHT) && (btn & MSB_RIGHT))) return;
    if (wm_menu_active()) return;

    /* где клик: список (строка) или пустое место */
    int on_item = 0, idx = -1;
    if (my >= FM_DEVBAR + FM_HDR + 2) {
        int total = (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                    FM_IS_FAT(m->mode) ? m->fat_n :
                    (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n);
        int row = (my - FM_DEVBAR - FM_HDR - 2) / FM_ROW;
        idx = m->scroll + row;
        if (idx >= 0 && idx < total) {
            on_item = 1;
            if (idx != m->sel) { m->sel = idx; win_invalidate(w); }
        }
    }

    fm_menu_n = 0;
    if (on_item) {
        fm_menu_items[fm_menu_n].label = "Открыть";
        fm_menu_items[fm_menu_n].id = FMC_OPEN;
        fm_menu_items[fm_menu_n].disabled = 0;
        fm_menu_n++;
        /* Запрос: «добавь во всплывающее меню кнопку "редактировать"».
         * Для .md/.html/.htm это ЕДИНСТВЕННЫЙ путь в редактор —
         * «Открыть» теперь уводит их в браузер. */
        fm_menu_items[fm_menu_n].label = "Редактировать";
        fm_menu_items[fm_menu_n].id = FMC_EDIT;
        fm_menu_items[fm_menu_n].disabled = !fm_sel_editable(m);
        fm_menu_n++;
        /* СЕССИЯ 61: копировать можно из читаемых источников
         * (RAM, FAT32 НЖМД/флешка, NTFS); каталоги — нельзя (в колбэке) */
        fm_menu_items[fm_menu_n].label = "Копировать";
        fm_menu_items[fm_menu_n].id = FMC_COPY;
        fm_menu_items[fm_menu_n].disabled = (m->mode == FM_MODE_ISO);
        fm_menu_n++;
    }
    /* Создание/удаление — сессия 14: RAM И перезаписываемая FAT32
     * (запрос: «в пустом диске FAT32 нет пунктов создания — только
     * обновить»). Прежде пункты существовали ТОЛЬКО в RAM disk. */
    {
        int writable = 0;
        if (m->mode == FM_MODE_RAM)
            writable = 1;
        else if (FM_IS_FAT(m->mode) && !(m->mode == FM_MODE_ATA && fm_hdd_fs == 1)
                 && fat32_ready())
            writable = 1;   /* [HDD] в режиме FAT32 или [USB] */
        if (writable) {
            if (fm_menu_n) {
                fm_menu_items[fm_menu_n].label = NULL;  /* разделитель */
                fm_menu_items[fm_menu_n].id = 0;
                fm_menu_items[fm_menu_n].disabled = 0;
                fm_menu_n++;
            }
            /* СЕССИЯ 61: вставка из буфера обмена (снимок в памяти) */
            fm_menu_items[fm_menu_n].label = "Вставить";
            fm_menu_items[fm_menu_n].id = FMC_PASTE;
            fm_menu_items[fm_menu_n].disabled = (fm_clip_src == FM_CLIP_NONE);
            fm_menu_n++;
            fm_menu_items[fm_menu_n].label = "Создать папку";
            fm_menu_items[fm_menu_n].id = FMC_MKDIR;
            fm_menu_items[fm_menu_n].disabled = 0;
            fm_menu_n++;
            fm_menu_items[fm_menu_n].label = "Создать файл";
            fm_menu_items[fm_menu_n].id = FMC_TOUCH;
            fm_menu_items[fm_menu_n].disabled = 0;
            fm_menu_n++;
            if (on_item) {
                fm_menu_items[fm_menu_n].label = "Удалить";
                fm_menu_items[fm_menu_n].id = FMC_DELETE;
                fm_menu_items[fm_menu_n].disabled = 0;
                fm_menu_n++;
            }
        }
    }
    if (fm_menu_n) {
        fm_menu_items[fm_menu_n].label = NULL;      /* разделитель */
        fm_menu_items[fm_menu_n].id = 0;
        fm_menu_items[fm_menu_n].disabled = 0;
        fm_menu_n++;
    }
    fm_menu_items[fm_menu_n].label = "Обновить";
    fm_menu_items[fm_menu_n].id = FMC_RELOAD;
    fm_menu_items[fm_menu_n].disabled = 0;
    fm_menu_n++;

    {
        extern void serial_puts(const char *s);
        extern int snprintf(char *o, u32 n, const char *f, ...);
        char mb[96];
        snprintf(mb, sizeof(mb), "[fm] ПКМ: mode=%d idx=%d total=%d on_item=%d\n",
                 m->mode, idx, (m->mode == FM_MODE_ATA && fm_hdd_fs == 1) ? m->ntfs_n :
                 FM_IS_FAT(m->mode) ? m->fat_n :
                 (m->mode == FM_MODE_ISO ? m->iso_n : m->ram_n), on_item);
        serial_puts(mb);
    }
    wm_menu_open(w, mx, my, fm_menu_items, fm_menu_n, fm_menu_cb, (void *)w);
}

static void fm_close(window_t *w) { free(w->data); }

/* Тик 2 Гц (сессия 11): пока фоновая задача sata инициализирует AHCI,
 * состояние кнопки [HDD] меняется сама — обновляем окно при изменении. */
static void fm_tick(window_t *w)
{
    fm_t *m = (fm_t *)w->data;

    /* Сессия 12: панель живёт состоянием ФС — следим за всеми
     * источниками, а не только за «диск найден»:
     *  - SATA доезжает в фоне → FAT32/NTFS готовы → кнопка [HDD] появляется;
     *  - флешка обнаружена → пробуем смонтировать FAT32
     *    (удача — кнопка [USB]; неудача — не показываем);
     *  - текущий источник стал недоступен → переключаемся на первый живой. */
    /* СЕССИЯ 73: ретраи ПО ТАЙМЕРУ вместо «одной попытки на первое окно».
     * Прежде: если первая попытка приходилась на момент, когда EHCI ещё
     * дорабатывал hot-plug скан, она проваливалась — а usb_seen/usb_inited
     * запирали повтор навсегда: флешка детектилась, но [USB] не появлялся
     * до переоткрытия ФМ. Теперь попытки раз в 2 с, не более 5 за загрузку. */
    {
        static u32 usb_last_try = 0;
        static int usb_tries = 0;
        if (usb_ehci_storage_ready() &&
            !(fat32_ready() && fat32_is_usb()) &&
            usb_tries < 5 &&
            (u32)(timer_ticks() - usb_last_try) >= 2000u) {
            usb_last_try = timer_ticks();
            usb_tries++;
            {
                extern void serial_puts(const char *s);
                char tb[80];
                extern int snprintf(char *o, u32 n, const char *f, ...);
                snprintf(tb, sizeof(tb),
                         "[fm] флешка готова — смонтировать FAT32 (попытка %d)\n",
                         usb_tries);
                serial_puts(tb);
            }
            if (!fat32_init_usb())
                fm_usb_bad = 1;
            else
                fm_usb_bad = 0;
            win_invalidate(w);
        }
    }

    /* СЕССИЯ 61: флешку выдернули, а FAT32 ещё смотрит на USB-backend —
     * перемонтировать НЖМД, иначе все операции ФС упираются в мёртвые
     * usb-чтения (прежде система оставалась без ФС до перезагрузки). */
    if (fat32_ready() && fat32_is_usb() && !usb_ehci_storage_ready()) {
        fat32_init();           /* вернуть backend на НЖМД */
        if (m->mode == FM_MODE_ATA) fm_reload(m);
        win_invalidate(w);
    }

    int avail = fm_src_avail(FM_MODE_ATA);
    int changed = 0;
    if (avail != m->hdd_avail_snap) {
        m->hdd_avail_snap = avail;
        changed = 1;
        if (m->mode == FM_MODE_ATA)
            fm_reload(m);
    }
    if (!fm_src_avail(m->mode)) {
        int first = fm_first_avail_mode();
        if (first != m->mode) {
            fm_switch_mode(m, first);
            changed = 1;
        }
    }
    if (changed)
        win_invalidate(w);
}

void app_files_open(void)
{
    fm_t *m = (fm_t *)malloc(sizeof(fm_t));
    if (!m) return;
    memset(m, 0, sizeof(fm_t));
    m->crumb_hover = -1;

    m->depth = 0;
    m->hdd_avail_snap = disk_hdd_present() ? 1 : 0;
    /* Режим по умолчанию: загрузочный CD, затем HDD (FAT32/NTFS), RAM */
    if (iso9660_ready())          m->mode = FM_MODE_ISO;
    else if (fat32_ready())       { m->mode = FM_MODE_ATA; fm_hdd_fs = 0; }
    else if (ntfs_ready())        { m->mode = FM_MODE_ATA; fm_hdd_fs = 1; }
    else if (ramfs_ready())       m->mode = FM_MODE_RAM;
    else                          m->mode = FM_MODE_ATA;
    /* сессия 25: синхронизировать список томов с ФС, смонтированной при
     * загрузке (чтобы активная кнопка тома была помечена сразу) */
    fm_scan_vols();
    if (m->mode == FM_MODE_ATA) {
        if (fat32_ready() && !fat32_is_usb()) {
            for (int i = 0; i < fm_vol_count; i++)
                if (!fm_vols[i].is_ntfs) { fm_vol_cur = i; break; }
        } else if (ntfs_ready()) {
            for (int i = 0; i < fm_vol_count; i++)
                if (fm_vols[i].is_ntfs) { fm_vol_cur = i; break; }
        }
    }
    m->stk[0].cluster = (m->mode == FM_MODE_ATA && fat32_ready())
                        ? fat32_root_cluster() : 0;
    strcpy(m->stk[0].path, "/");
    fm_reload(m);

    u32 W = fb_width(), H = fb_height();
    int ww = 520, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("Файлы", 30, 30, ww, wh, fm_draw, fm_key, fm_mouse, fm_tick, fm_close, m);
}