/* apps_editor.c — текстовый редактор со встроенной компиляцией c4.
 *
 * СЕССИЯ 17: редактирование перенесено в переиспользуемую библиотеку
 * src/editor.c (порт kilo): построчное хранилище, скроллинг по обеим
 * осям, Delete, поиск Ctrl+F, подсветка синтаксиса C, номера строк,
 * клик мышью и ПОЛОСА ПРОКРУТКИ (общий виджет wm_scrollbar, цвет из
 * темы). Приложению остаются панель кнопок, диалоги, сохранение и c4.
 *
 * Возможности:
 *   - редактирование (библиотека editor.c, см. её шапку);
 *   - верхняя панель с НАЖИМАЕМЫМИ кнопками:
 *       [Save F2] [Load F4] [Run F9] [Close Esc]
 *     кликабельны мышью или горячими клавишами;
 *   - F2 — сохранить (диалог «Сохранить как», цель как в файловом
 *     менеджере: RAM / HDD / USB FAT32);
 *   - F4 — загрузить (диалог «Открыть»);
 *   - F9 — скомпилировать и запустить через c4.c; вывод открывается
 *           в отдельном окне «Вывод программы»;
 *   - Esc — закрыть редактор.
 *
 * Файловый менеджер открывает файлы здесь через app_editor_open_with()
 * и app_editor_open_at(). */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "editor.h"
#include "kbd.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "c4.h"
#include "c4gfx.h"
#include "task.h"
#include "mouse.h"
#include "filedlg.h"
#include "fat32.h"

#define EDIT_HEADER_H   22      /* высота панели с кнопками */

/* Геометрия кнопок верхней панели. */
#define BTN_COUNT 4
#define BTN_W     70
#define BTN_H     18
#define BTN_GAP   4
#define BTN_X0    4
#define BTN_Y0    2

/* окно редактора: 80 колонок, 24 строки (шрифт 8x16) */
#define EDIT_COLS 80
#define EDIT_ROWS 24

typedef struct {
    ed_t   *ed;                /* редактор-библиотека (kilo) */
    char    filename[FD_NAME_MAX + 1];
    int     dirty;             /* снимок dirty для заголовка окна */
    int     compiling;
    int     orphan;            /* окно закрыто во время компиляции:
                                * editor_t освободит задача компиляции */
    int     dlg;               /* 1 = открыт диалог (игнорировать ввод) */
    int     btn_hot;
    int     btn_pressed;
    char    status[80];
    /* цель сохранения — как в файловом менеджере: файл, открытый с
     * HDD/USB(FAT32), по F2/F9 сохраняется обратно туда же. */
    fd_source_t save_src;      /* FD_SRC_RAMFS по умолчанию */
    char    save_dir[200];     /* каталог назначения (RAM: полный путь) */
    u32     save_cluster;      /* FAT32: кластер каталога назначения */
} editor_t;

/* ---------- кнопки верхней панели ---------- */

typedef struct {
    const char *label;
    int  key_code;          /* скан-код (для F-клавиш) */
    char hot_key;           /* ASCII-клавиша (Esc = 0x1B) */
} editor_button_t;

static const editor_button_t editor_buttons[BTN_COUNT] = {
    { "Save F2",  0x3C, 0    },
    { "Load F4",  0x3E, 0    },
    { "Run F9",   0x43, 0    },
    { "Close Esc", 0,   0x1B },
};

static void ed_button_rect(int idx, int *bx, int *by, int *bw, int *bh)
{
    *bx = BTN_X0 + idx * (BTN_W + BTN_GAP);
    *by = BTN_Y0;
    *bw = BTN_W;
    *bh = BTN_H;
}

static int ed_button_at(editor_t *e, int mx, int my)
{
    (void)e;
    if (my < BTN_Y0 || my >= BTN_Y0 + BTN_H) return -1;
    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh;
        ed_button_rect(i, &bx, &by, &bw, &bh);
        if (mx >= bx && mx < bx + bw) return i;
    }
    return -1;
}

static void ed_status(editor_t *e, const char *msg)
{
    strncpy(e->status, msg, sizeof(e->status) - 1);
    e->status[sizeof(e->status) - 1] = 0;
}

/* ---------- окно вывода программы (со скроллбаром темы) ---------- */

typedef struct {
    char *buf;
    u32   len;
    int   top;
    wm_scrollbar_t sb;
} outwin_t;

static int outwin_count_lines(const char *buf, u32 len)
{
    int n = 1;
    for (u32 i = 0; i < len; i++)
        if (buf[i] == '\n') n++;
    return n;
}

static void outwin_draw(window_t *w)
{
    outwin_t *o = (outwin_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    int cols = (cw - 14) / 8;
    int vis  = (ch - 4) / 16;
    if (cols < 1) cols = 1;
    if (vis < 1) vis = 1;

    int nlines = outwin_count_lines(o->buf, o->len);
    int max_scroll = nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (o->top > max_scroll) o->top = max_scroll;
    if (o->top < 0) o->top = 0;

    int line = 0, i = 0;
    while (i < (int)o->len && line < o->top) {
        if (o->buf[i] == '\n') line++;
        i++;
    }
    int y = 2;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)o->len; r++) {
        int start = i, end = i;
        while (end < (int)o->len && o->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols)  len = cols;
        if (len > 254)   len = 254;
        memcpy(tmp, o->buf + start, (u32)len);
        tmp[len] = 0;
        fb_text(4, y, tmp, wm_theme_text(), -1);
        i = end + (end < (int)o->len ? 1 : 0);
        y += 16;
    }

    /* полоса прокрутки (общий виджет, цвет из темы) */
    wm_scrollbar_draw(&o->sb, cw - 7, 2, 5, ch - 4, o->top, max_scroll, vis);

    char st[64];
    snprintf(st, sizeof(st), "PgUp/PgDn, Esc — закрыть, %u байт",
             (unsigned)o->len);
    fb_text(4, ch - 14, st, wm_theme_text_info(), -1);
}

static void outwin_key(window_t *w, const key_event_t *ev)
{
    outwin_t *o = (outwin_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == 0x49)   { o->top -= 8; win_invalidate(w); }
    else if (ev->code == 0x51) { o->top += 8; win_invalidate(w); }
    else if (ev->code == KBD_UP)   { o->top--; win_invalidate(w); }
    else if (ev->code == KBD_DOWN) { o->top++; win_invalidate(w); }
    else if (ev->ch == 0x1B || ev->code == 0x01) win_close(w);
    /* границы top приводятся в норму в outwin_draw при каждой отрисовке */
}

static void outwin_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed)
{
    outwin_t *o = (outwin_t *)w->data;
    int cw = win_content_w(w);
    (void)my;
    if (mx >= cw - 9) {
        int np = wm_scrollbar_mouse(&o->sb, mx, my, buttons, changed);
        if (np >= 0) { o->top = np; win_invalidate(w); }
        return;
    }
    /* скроллбар растянут на всю высоту: drag продолжается везде по X */
    if (o->sb.dragging) {
        int np = wm_scrollbar_mouse(&o->sb, mx, my, buttons, changed);
        if (np >= 0) { o->top = np; win_invalidate(w); }
    }
}

static void outwin_close(window_t *w)
{
    outwin_t *o = (outwin_t *)w->data;
    if (o) { if (o->buf) free(o->buf); free(o); }
}

/* Экспортируется (apps.h): окно вывода текста — используется и
 * редактором (F9), и loader'ом (нативные .bin через `run`). */
void app_outwin_open(const char *title, const char *text, u32 len)
{
    outwin_t *o = (outwin_t *)malloc(sizeof(outwin_t));
    if (!o) return;
    memset(o, 0, sizeof(*o));
    o->buf = (char *)malloc(len + 1);
    if (!o->buf) { free(o); return; }
    memcpy(o->buf, text, len);
    o->buf[len] = 0;
    o->len = len;
    o->top = 0;

    u32 W = fb_width(), H = fb_height();
    int ww = 600, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 90, 70, ww, wh, outwin_draw, outwin_key,
               outwin_mouse, NULL, outwin_close, o);
}

/* ---------- задача компиляции ---------- */

typedef struct {
    editor_t *ed;              /* редактор-владелец (см. orphan) */
    char     *src;             /* СНИМОК текста на момент F9 */
    char      fname[FD_NAME_MAX + 1];
    char     *out;
    u32       out_max;
    int       result;
} compile_ctx_t;

static void compile_task_fn(void *arg)
{
    compile_ctx_t *c = (compile_ctx_t *)arg;
    /* Сначала компилируем и сохраняем байт-код в .bin рядом с .c. */
    if (c->fname[0]) {
        char bin_out[256];
        bin_out[0] = 0;
        int bin_r = c4_compile_to_file(c->fname, c->src, bin_out,
                                       sizeof(bin_out));
        if (bin_r != 0 && bin_out[0]) {
            char err[400];
            snprintf(err, sizeof(err), "[c4 compile-to-file error]\n%s\n",
                     bin_out);
            u32 el = (u32)strlen(err);
            if (el + 1 < c->out_max) {
                memmove(c->out + el, c->out, strlen(c->out) + 1);
                memcpy(c->out, err, el);
            }
        }
    }
    /* Затем компилируем и запускаем. Работаем со СНИМКОМ: правки
     * пользователя во время компиляции не ломают процесс (раньше
     * компилировали живой буфер редактора). */
    c4_gfx_set_name(c->fname[0] ? c->fname : "prog.c");
    c->result = c4_run(c->src, c->out, c->out_max);
    c4_gfx_detach();

    /* Обновим статус в редакторе (если окно ещё живо) */
    if (c->ed) {
        if (!c->ed->orphan) {
            if (c->result == 0)
                snprintf(c->ed->status, sizeof(c->ed->status),
                         "OK: программа завершилась с кодом 0");
            else
                snprintf(c->ed->status, sizeof(c->ed->status),
                         "Ошибка: код %d (см. вывод)", c->result);
            c->ed->compiling = 0;
        } else {
            ed_free(c->ed->ed);   /* окно закрыто при активной задачи:
                                   * память editor_t освобождаем здесь */
            free(c->ed);
            c->ed = NULL;
        }
    }

    u32 out_len = (u32)strlen(c->out);
    app_outwin_open("Вывод программы", c->out, out_len);
    free(c->src);
    free(c->out);
    free(c);
    task_exit();
}

/* ---------- сохранение (цель как в файловом менеджере) ----------
 * Пишем в e->save_src: RAM (иерархия) или FAT32 на HDD/USB.
 * Возвращает 1 при успехе. */
static int ed_save_current(editor_t *e)
{
    int len = 0;
    char *text = ed_get_text_alloc(e->ed, &len);
    if (!text) {
        ed_status(e, "Нет памяти для выгрузки текста");
        return 0;
    }

    if (!e->filename[0]) strcpy(e->filename, "prog.c");

    int ok = 0;
    if (e->save_src == FD_SRC_ATA || e->save_src == FD_SRC_USB) {
        if (fat32_ready()) {
            u32 wrote = fat32_write_file(e->save_cluster, e->filename,
                                         text, (u32)(len + 1));
            if (wrote != 0) {
                e->dirty = 0;
                {
                    char msg[96];
                    const char *d = e->save_src == FD_SRC_ATA ? "HDD" : "USB";
                    snprintf(msg, sizeof(msg), "Сохранено: %s:%s/%s (%d байт)",
                             d, e->save_dir, e->filename, len);
                    ed_status(e, msg);
                }
                ok = 1;
            } else {
                ed_status(e, "Ошибка записи на диск");
            }
        } else {
            ed_status(e, "FAT32 не смонтирована — сохраните на другой диск (F2)");
        }
    } else {
        /* RAM disk (иерархия: полный путь) */
        if (ramfs_ready()) {
            char full[232];
            const char *base = e->save_dir[0] ? e->save_dir : "/";
            if (base[0] == '/' && !base[1])
                snprintf(full, sizeof(full), "%s", e->filename);
            else
                snprintf(full, sizeof(full), "%s/%s", base, e->filename);
            ramfs_delete(full);
            if (ramfs_create(full, (u32)(len + 1)) &&
                ramfs_write(full, text, (u32)(len + 1))) {
                e->dirty = 0;
                {
                    char msg[96];
                    snprintf(msg, sizeof(msg), "Сохранено: RAM%s/%s (%d байт)",
                             e->save_dir, e->filename, len);
                    ed_status(e, msg);
                }
                ok = 1;
            } else {
                ed_status(e, "Ошибка записи (нет места?)");
            }
        } else {
            ed_status(e, "RAM disk недоступен");
        }
    }
    free(text);
    if (ok) ed_mark_clean(e->ed);
    return ok;
}

/* Колбэки диалога сохранения. */
static void ed_dlg_save_ok(void *ctx, const fd_save_t *save)
{
    editor_t *e = (editor_t *)ctx;
    e->dlg = 0;
    e->save_src = save->source;
    snprintf(e->save_dir, sizeof(e->save_dir), "%s", save->path);
    e->save_cluster = save->cluster;
    if (save->name[0]) {
        strncpy(e->filename, save->name, sizeof(e->filename) - 1);
        e->filename[sizeof(e->filename) - 1] = 0;
    }
    ed_save_current(e);
}

static void ed_dlg_cancel(void *ctx)
{
    editor_t *e = (editor_t *)ctx;
    e->dlg = 0;
    ed_status(e, "Отменено");
}

/* «Сохранить как...»: стандартный диалог. */
static void ed_save_as(editor_t *e)
{
    if (e->dlg) return;
    e->dlg = 1;
    ed_status(e, "Сохранение: выберите диск и имя (Tab — диск)");
    filedlg_save("Сохранить как",
                 e->filename[0] ? e->filename : "prog.c",
                 e->save_src,
                 ed_dlg_save_ok, ed_dlg_cancel, e);
}

/* Колбэк диалога открытия: подменить текст содержимым файла.
 * Запоминаем, ОТКУДА файл открыт — F2/F9 сохранят его туда же. */
static void ed_dlg_open_ok(void *ctx, const fd_pick_t *pick,
                           char *content, int len)
{
    editor_t *e = (editor_t *)ctx;
    e->dlg = 0;
    if (!content || len <= 0) { ed_status(e, "Пустой файл"); return; }
    ed_set_text(e->ed, content, len);
    free(content);
    ed_mark_clean(e->ed);
    strncpy(e->filename, pick->name, sizeof(e->filename) - 1);
    e->filename[sizeof(e->filename) - 1] = 0;
    e->save_src = pick->source;
    snprintf(e->save_dir, sizeof(e->save_dir), "%s", pick->dir);
    e->save_cluster = pick->cluster;
    {
        char msg[96];
        const char *src = pick->source == FD_SRC_RAMFS ? "RAM disk"
                       : pick->source == FD_SRC_ATA ? "HDD" : "USB";
        snprintf(msg, sizeof(msg), "Загружено: %s (%d байт, %s) — F2 сохранит туда же",
                 e->filename, len, src);
        ed_status(e, msg);
    }
}

/* «Открыть...»: стандартный диалог с тремя источниками. */
static void ed_open_file(editor_t *e)
{
    if (e->dlg) return;
    e->dlg = 1;
    ed_status(e, "Открытие: выберите файл (Tab — источник)");
    filedlg_open("Открыть файл", ".c,.js,.txt,.md,.log,.ini,.cfg",
                 e->filename[0] ? e->filename : NULL,
                 ed_dlg_open_ok, ed_dlg_cancel, e);
}

static void ed_compile_run(editor_t *e)
{
    if (e->compiling) {
        ed_status(e, "Уже компилируется...");
        return;
    }
    if (ed_len_bytes(e->ed) == 0) {
        ed_status(e, "Буфер пуст — нечего компилировать");
        return;
    }

    /* Автосохранение под текущим именем в текущую цель.
     * Для компиляции/cc/run исходник дополнительно зеркалится в RAM disk. */
    if (ed_save_current(e) && e->save_src != FD_SRC_RAMFS && ramfs_ready()) {
        /* зеркало в RAM: терминальные cc/run и FM видят свежую копию */
        int len = 0;
        char *mirror = ed_get_text_alloc(e->ed, &len);
        if (mirror) {
            ramfs_delete(e->filename);
            if (ramfs_create(e->filename, (u32)(len + 1)))
                ramfs_write(e->filename, mirror, (u32)(len + 1));
            free(mirror);
        }
    }

    compile_ctx_t *c = (compile_ctx_t *)malloc(sizeof(compile_ctx_t));
    if (!c) { ed_status(e, "Нет памяти под контекст"); return; }
    memset(c, 0, sizeof(*c));
    c->ed = e;
    snprintf(c->fname, sizeof(c->fname), "%s", e->filename);
    c->out_max = 16384;
    c->out = (char *)malloc(c->out_max);
    c->src = ed_get_text_alloc(e->ed, NULL);   /* снимок текста */
    if (!c->out || !c->src) {
        if (c->out) free(c->out);
        if (c->src) free(c->src);
        free(c);
        ed_status(e, "Нет памяти под вывод");
        return;
    }
    c->out[0] = 0;
    c->result = -1;

    e->compiling = 1;
    ed_status(e, "Компиляция и запуск...");

    int tid = task_spawn("c4", compile_task_fn, c);
    if (tid < 0) {
        e->compiling = 0;
        free(c->src);
        free(c->out);
        free(c);
        ed_status(e, "Не удалось породить задачу");
    } else {
        char msg[80];
        snprintf(msg, sizeof(msg), "Запущена задача #%d: c4", tid);
        ed_status(e, msg);
    }
}

/* Запустить действие по индексу кнопки */
static void ed_run_button(editor_t *e, int btn_idx)
{
    switch (btn_idx) {
    case 0: ed_save_as(e);   break;   /* Save F2 — диалог «Сохранить как» */
    case 1: ed_open_file(e); break;   /* Load F4 — диалог «Открыть» */
    case 2: ed_compile_run(e); break;
    case 3: /* Close — обрабатывается в ed_mouse */
        break;
    }
}

static void ed_win_draw(window_t *w)
{
    editor_t *e = (editor_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Шапка с кнопками */
    fb_fill_rect(0, 0, cw, EDIT_HEADER_H, wm_theme_title());

    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh;
        ed_button_rect(i, &bx, &by, &bw, &bh);
        u32 bg = (e->btn_pressed == i) ? fb_rgb(0x4A, 0x7F, 0xB0)
              : (e->btn_hot == i) ? fb_rgb(0x32, 0x60, 0x8E)
              : fb_rgb(0x25, 0x4A, 0x70);
        /* сессия 20: подпись гарантированно внутри кнопки */
        wm_button_draw(bx, by, bw, bh, editor_buttons[i].label,
                       bg, wm_theme_text(), wm_theme_accent());
    }

    /* Информация о файле и позиции курсора справа от кнопок */
    {
        int ix = BTN_X0 + BTN_COUNT * (BTN_W + BTN_GAP);
        if (ix < cw - 260) {
            int ln1 = 0, col1 = 0, nrows = 0;
            ed_cursor_pos(e->ed, &ln1, &col1, &nrows);
            char info[112];
            snprintf(info, sizeof(info), "%s%s  Стр %d, Кол %d из %d",
                     e->filename[0] ? e->filename : "(без имени)",
                     ed_dirty(e->ed) ? " *" : "",
                     ln1, col1, nrows);
            fb_text(ix, BTN_Y0 + 3, info, wm_theme_text(), -1);
        }
    }

    /* Текстовая область — вся правка рисует библиотека editor.c
     * (подсветка C, номера строк, курсор, скроллбар темы, поиск). */
    ed_draw(e->ed, 0, EDIT_HEADER_H, cw, ch - EDIT_HEADER_H - 14);

    /* Статус-строка внизу */
    fb_fill_rect(0, ch - 14, cw, 14, wm_theme_win_bg_alt());
    fb_text(4, ch - 12, e->status, wm_theme_text_info(), -1);
}

static void ed_win_key(window_t *w, const key_event_t *ev)
{
    editor_t *e = (editor_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (e->dlg) return;    /* открыт диалог — редактор игнорирует ввод */

    /* F2 (0x3C), F4 (0x3E), F9 (0x43), Esc (0x01) — дублируют кнопки.
     * Esc работает и из режима поиска библиотеки (сначала она). */
    if (ev->code == 0x3C)   { ed_save_as(e); win_invalidate(w); return; }
    if (ev->code == 0x3E)   { ed_open_file(e); win_invalidate(w); return; }
    if (ev->code == 0x43)   { ed_compile_run(e); win_invalidate(w); return; }
    if ((ev->ch == 0x1B || ev->code == 0x01) && !ed_in_find(e->ed)) {
        win_close(w);
        return;
    }

    /* всё остальное — библиотеке (ввод, стрелки, Ctrl+F, ...) */
    ed_key(e->ed, ev, win_content_w(w), win_content_h(w) - EDIT_HEADER_H - 14);
    win_invalidate(w);
}

/* Обработчик мыши: клики по верхней панели активируют кнопки,
 * остальное — библиотеке (курсор, полоса прокрутки). */
static void ed_win_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed)
{
    editor_t *e = (editor_t *)w->data;
    if (e->dlg) return;
    int inside = (my < EDIT_HEADER_H);

    if (inside) {
        int btn = ed_button_at(e, mx, my);
        if (btn != e->btn_hot) {
            e->btn_hot = btn;
            win_invalidate(w);
        }
        if ((changed & MSB_LEFT) && (buttons & MSB_LEFT)) {
            if (btn >= 0) {
                e->btn_pressed = btn;
                win_invalidate(w);
            }
        }
        if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT)) {
            int was_pressed = e->btn_pressed;
            e->btn_pressed = -1;
            if (was_pressed >= 0 && btn == was_pressed) {
                if (was_pressed == 3) {
                    win_close(w);
                    return;
                }
                ed_run_button(e, was_pressed);
            }
            win_invalidate(w);
        }
        return;
    }

    /* текстовая область/скроллбар — библиотеке */
    int area_h = win_content_h(w) - EDIT_HEADER_H - 14;
    int eaten = ed_mouse(e->ed, mx, my - EDIT_HEADER_H,
                         buttons, changed, win_content_w(w), area_h);
    if (eaten) {
        win_invalidate(w);
        return;
    }
    if (e->btn_hot != -1 || e->btn_pressed != -1) {
        e->btn_hot = -1;
        e->btn_pressed = -1;
        win_invalidate(w);
    }
}

static void ed_win_close(window_t *w)
{
    editor_t *e = (editor_t *)w->data;
    if (!e) return;
    if (e->compiling) {
        /* задача компиляции держит указатель на editor_t — пометим и
         * пусть память освободит она (см. compile_task_fn) */
        e->orphan = 1;
    } else {
        ed_free(e->ed);
        free(e);
    }
}

/* Внутренняя функция для инициализации редактора с заданным содержимым. */
static editor_t *ed_new_with(const char *filename, const char *content, int len)
{
    editor_t *e = (editor_t *)malloc(sizeof(editor_t));
    if (!e) return NULL;
    memset(e, 0, sizeof(editor_t));

    e->ed = ed_create(1);          /* подсветка синтаксиса C */
    if (!e->ed) { free(e); return NULL; }

    if (content && len > 0) {
        ed_set_text(e->ed, content, len);
    } else {
        /* пустой буфер с подсказкой в статусе */
        ed_set_text(e->ed, NULL, 0);
    }
    e->btn_hot = -1;
    e->btn_pressed = -1;
    e->save_src = FD_SRC_RAMFS;    /* цель по умолчанию */
    strcpy(e->save_dir, "/");
    e->save_cluster = 0;
    if (filename && filename[0]) {
        strncpy(e->filename, filename, sizeof(e->filename) - 1);
        e->filename[sizeof(e->filename) - 1] = 0;
    } else {
        strcpy(e->filename, "prog.c");
    }
    ed_status(e, "Выделение мышью; Ctrl+C/V/X/A — буфер; F2/F4/F9 — файлы");
    return e;
}

/* единая геометрия окна для всех вариантов открытия */
static void ed_create_window(editor_t *e, const char *title)
{
    u32 W = fb_width(), H = fb_height();
    int ww = EDIT_COLS * 8 + 20;
    int wh = EDIT_ROWS * 16 + EDIT_HEADER_H + 14 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 60, 30, ww, wh, ed_win_draw, ed_win_key, ed_win_mouse,
               NULL, ed_win_close, e);
}

void app_editor_open(void)
{
    editor_t *e = ed_new_with(NULL, NULL, 0);
    if (!e) return;
    ed_create_window(e, "Редактор C");
}

/* Открыть редактор с уже загруженным содержимым.
 * Используется файловым менеджером. */
void app_editor_open_with(const char *filename, const char *content, int len)
{
    editor_t *e = ed_new_with(filename, content, len);
    if (!e) return;
    char title[64];
    snprintf(title, sizeof(title), "Редактор C: %s",
             filename ? filename : "(без имени)");
    ed_create_window(e, title);
}

/* Универсальный текстовый редактор: открыть ТЕКСТОВЫЙ файл с любого
 * диска прямо в его каталоге — F2/F9 сохранят файл туда же. */
void app_editor_open_at(fd_source_t src, const char *dir, u32 dir_cluster,
                        const char *name, const char *content, int len)
{
    editor_t *e = ed_new_with(name, content, len);
    if (!e) return;
    e->save_src = src;
    snprintf(e->save_dir, sizeof(e->save_dir), "%s", dir ? dir : "/");
    e->save_cluster = dir_cluster;

    char title[80];
    const char *d = src == FD_SRC_ATA ? "HDD" : src == FD_SRC_USB ? "USB" : "RAM";
    snprintf(title, sizeof(title), "Редактор: %s:%s%s%s",
             d, e->save_dir,
             (e->save_dir[0] == '/' && !e->save_dir[1]) ? "" : "/",
             name ? name : "(без имени)");
    ed_create_window(e, title);
}
