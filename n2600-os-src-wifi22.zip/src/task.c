/* task.c — вытесняющая многозадачность N2600-OS.
 *
 * Архитектура переключения контекста:
 *   1. PIT генерирует IRQ0 каждые 1 мс (СЕССИЯ 33: 1000 Гц — было 100 Гц).
 *      Зачем: точные короткие паузы (task_msleep(1) раньше длил 10 мс —
 *      все тайминги USB/WiFi/скана раздувались кратно), плавнее UI,
 *      быстрее реакция горячей замены задач.
 *   2. CPU входит в irq_stub_0 (naked-функция), который:
 *        pusha                  — сохраняет 8 general regs в стеке текущей задачи;
 *        cld; pushl %esp; call _task_schedule
 *                               — передаёт C-функции указатель на pusha-кадр;
 *        movl %eax, %esp        — переключает стек на сохранённый кадр новой задачи;
 *        popa; iret             — восстанавливает regs и EIP/CS/EFLAGS новой задачи.
 *
 *   3. task_schedule():
 *        - инкрементирует системные тики (ticks);
 *        - шлёт EOI master PIC;
 *        - сохраняет tasks[cur].esp = saved_esp;
 *        - инкрементирует uptime задачи, которая только что работала;
 *        - round-robin выбирает следующую активную задачу;
 *        - возвращает tasks[next].esp.
 *
 * Для новой задачи fabricate-стек: на вершине выделенного стека
 * кладётся фейковый кадр iret (EIP=task_trampoline, CS=0x08, EFLAGS=IF=1)
 * и под ним — pusha-кадр из нулей. Первое переключение на новую задачу
 * popa-нет нули и iret-ом прыгает в task_trampoline, который зовёт fn(arg).
 *
 * Главная задача (kmain) — task[0]; её стек не fabricate-ится, так как
 * она уже работает на системном стеке _stack_top.
 *
 * Лимит задач: 256 (увеличен с 8). Каждый слот задаёт имя, статус,
 * стек (16 КиБ), uptime (число тиков, в которых задача исполнялась).
 */
#include "task.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "gdt.h"   /* песочница: gdt_clear_task_region при переиспользовании слота */
#include "timer.h" /* сессия 78: pit2-дедлайны для KLOCK-STALE (работают под cli) */
#include "smp.h"   /* SMP_MAX_CPUS, smp_current_cpu (task_lock [TL-IFSAFE]); ядровый замок */

extern void serial_puts(const char *s);   /* сессия 78: diag-логи klock/spawn */

#define TASK_STACK_SIZE (32 * 1024)
/* Сессия 13: 16 -> 32 КиБ. КОРНЕВАЯ ПРИЧИНА порчи кучи (см. apps.c):
 * кадр term_exec (ramtree: ents[128]=9.7КБ + cc: src_buf[8КБ]) плюс
 * loader_load (ents[64]=4.8КБ) переваливали за 16КБ — поток писал ниже
 * своего стекового блока в кучу, затирая заголовок соседнего блока
 * (size=0 -> malloc зависал под cli). 32КБ даёт запас; большие массивы
 * к тому же уведены со стека (apps.c: static). */

/* СЕССИЯ 59: КАНАРЕЙКИ СТЕКОВ. Порча кучи вернулась (лог fixed58:
 * «ПОРЧА КУЧИ: блок size=0» — заголовок блока, ИДУЩЕГО СРАЗУ ЗА
 * чьим-то стеком, побит значениями {4,0}). Стек растёт ВНИЗ, поэтому
 * переполнение пишёт сначала в СВОИ нижние байты, потом в заголовок
 * соседнего блока. Канарейка в нижних 8 байтах ЛОВИТ переполнение
 * ДО порчи кучи и называет задачу по имени. */
#define TASK_STACK_CANARY0 0xC7194A5Bu
#define TASK_STACK_CANARY1 0x5BA419C7u

/* Селектор данных ядра (flat 4 ГБ) — синхронизирован с gdt.c */
#define KERNEL_DS 0x10

/* Таймаут по умолчанию для IRQ-ватчдога: 5 секунд (5000 тиков по 1 мс).
 * Должен быть определён ДО task_schedule() (используется там). */
#define TASK_WATCHDOG_TICKS 5000

typedef struct {
    /* [H5-HARD] (разбор гипотез): поля ниже читаются/пишутся с ДВУХ ядер
     * без общих замков (BSP-IRQ0 против AP-LAPIC) — раньше были plain
     * int: компилятор вправе кэшировать чтения между memory-барьерами.
     * Гонку миграции закрывает гейтинг on_cpu (оба планировщика
     * пропускают on_cpu-задачи), volatile гарантирует свежесть чтений. */
    volatile int  used;
    volatile int  finished;
    u32 *esp;
    u8  *stack;
    u32  stack_size;
    char name[16];
    void (*fn)(void *);
    void *arg;
    u32  uptime;
    u32  last_active_tick;  /* последний тик, когда задача работала */
    u32  watchdog_timeout;  /* 0 = нет ватчдога, иначе макс тиков без активности */
    u32  last_uptime;       /* предыдущее значение uptime (для детекции зависания) */
    volatile int  waiting;           /* 1 = задача спит, ждёт события (не «зависла») */
    int  system;            /* 1 = системная задача (ramfs-сервер и т.п.):
                              * kill запрещён — иначе умрёт подсистема ОС */
    int  lock_wait;         /* 1 = задача ждёт блокировку в s_lock (sync.h):
                              * ватчдог такие НЕ убивает — ими управляет
                              * таймаут отбора зависшей блокировки (20 с) */
    int  prio;              /* СЕССИЯ 34: приоритет (0=UI, 1=NORMAL, 2=BG) */
    int  canary;            /* СЕССИЯ 59: 1 = в НИЖНИЕ 8 байт стека записана
                              * канарейка (только собственные стеки; у
                              * песочницы stack = регион — там kapi-копия) */
    /* СЕССИЯ 75 (многоядерность):
     * cpu         — ядро, на которое назначена задача (0 = BSP);
     * on_cpu      — 1 = задача исполняется/переключается на AP
     *               (планировщик BSP такие пропускает — защита от
     *               двойного исполнения);
     * migrating   — 1 = задача «в перелёте» AP->BSP: BSP НЕ планирует
     *               её, пока AP не сохранит контекст и не снимет флаг;
     * holds_klock — 1 = задача держит ядровый замок (smp.h): замок
     *               ПЕРЕДАЁТСЯ при переключении контекста (без
     *               unlock/lock), флаг — координация с post-hlt
     *               захватом и источник правды «кто держит». */
    volatile int  cpu;
    volatile int  on_cpu;
    volatile int  migrating;
    volatile int  holds_klock;
    /* [CORE-BALANCE] (полевой лог VMware: «все процессы кроме js —
     * на ядре 0»): песочница (внешний стек-регион) — такие задачи
     * НЕ переносятся между ядрами: сегментная механика irq_stub_0
     * (cur_task) рассчитана на BSP. Дублирует параметр task_pick_core
     * на случай ребаланса, когда параметра уже нет. */
    int  sandbox;
} task_t;

static task_t tasks[MAX_TASKS];

/* ШАГ 3 (SMP-rework): task_lock — спинлок таблицы задач.
 *
 * Закрывает корневую гонку разбора (п.3/п.4): task_watchdog_irq (IRQ0,
 * BSP) и task_ap_schedule (LAPIC, AP) пишут finished/on_cpu/holds_klock/
 * g_ap_cur_task одних и тех же слотов БЕЗ общей синхронизации — volatile
 * даёт атомарность отдельного write, но НЕ последовательности. Теперь
 * все мутации tasks[]/cur_task/n_tasks идут под task_lock; секции —
 * микросекунды; замок НИКОГДА не держится через hlt/msleep и НЕ берётся
 * внутри spin'а klock (иначе ждущий klock намертво блокировал бы
 * AP-планировщик — а он единственный, кто мог бы освободить klock).
 *
 * Иерархия замков (зафиксирована; проверять в debug-сборке):
 *   task_lock → heap_lock → { fb_sched_lock, ser_xcore, klog_lock }
 *   klock — ВНЕ иерархии: его секции не берут task_lock и наоборот. */
static volatile int task_lock = 0;

/* [TL-IFSAFE] (QEMU-сессия): IF-состояние на время секции task_lock.
 * Раньше task_exit/task_set_priority/... брали task_lock в контексте
 * задачи с IF=1: таймер (IRQ0/LAPIC) мог прервать СЕКЦИЮ, и планировщик
 * ТОГО ЖЕ ядра закручивался в task_lock_acq на замке, который держит
 * его собственный прерванный кадр — self-deadlock без паники (в -d int
 * оба ядра видны в спине xchg по task_lock, serial замолкает). Теперь
 * секция ВСЕГДА под cli; IF честно сохраняется/восстанавливается
 * по ядрам. Держатель завершает секцию при любых раскладах. */
static volatile int s_tl_if_saved[SMP_MAX_CPUS];
/* [TL-STUCK3] (полевой лог VMware 4 ядра, «зависание с огромным логом»):
 * владение замком теперь PER-CPU. Прежние ОДНИ глобальные s_tl_owner/
 * s_tl_site писались каждым новым держателем и читались ватчдогом любого
 * ядра — в окна «xchg взят, владение ещё не записано» и после release
 * ватчдог видел чужой/stale owner и решал по нему сорвать замок. Итог
 * поля: 12149 «STUCK owner -1 … освобождена» (owner -1 — ЛЕГАЛЬНОЕ
 * значение [TASKC-AP-IDLE]: AP-планировщик в idle пишет
 * task_current()==-1), 252 ложных escaped-срыва, порча tasks[]/holds_klock
 * (в дампе [klock] FATAL: «держатель: задача 5» при holds_klock=0 — след
 * параллельных секций) и паника на 18-й секунде аптайма. */
static volatile int s_tl_owner[SMP_MAX_CPUS]; /* task_current() при acq, по ядрам */
static volatile u32 s_tl_site [SMP_MAX_CPUS]; /* адрес возврата acq, по ядрам */
static volatile int s_tl_hold_cpu = -1; /* ядро-держатель; -1 = не подтверждено.
                                 * Пишется ПОСЛЕ owner/site, сбрасывается в rel
                                 * ДО unlock: окно «xchg взят, владение ещё не
                                 * записано» ватчдог обязан читать как «не трогать» */
static volatile int s_tl_quiet = 0;     /* 1 = после [klock] FATAL: диагностика
                                 * task_lock молчит, спящие ядра паркуются
                                 * (иначе AP-спины после паники BSP заваливали
                                 * serial: 10600 строк после паники в полевом логе) */
static volatile u32 s_tl_last_msg = 0;  /* штамп pit2 для лимита 1 строка/с */

/* [TL-QUIET] вызывается из FATAL-путей ([klock] FATAL: ждущий
 * task_klock_acquire_me и ватчдог [KLOCK-HANG-DETECT]) перед остановкой
 * BSP: система уже остановлена честной паникой — AP-спины в task_lock_acq
 * замолкают и паркуются вместо бесконечного флуда serial. */
void task_lock_quiet_set(void) { s_tl_quiet = 1; }

/* Лимит диагностики: не чаще 1 строки/с НА ВСЮ систему (pit2-штамп).
 * Без защиты от гонки: два ядра могут уложиться в одно окно — худший
 * случай 2-3 строки/с вместо прежних ~130 строк/с, гасивших лог. */
static int task_lock_msg_gate(void)
{
    if (!timer_poll_expired(s_tl_last_msg, 1000000u)) return 0;
    s_tl_last_msg = timer_poll_deadline();
    return 1;
}

/* SMP-rework (диагностика QEMU): пульс kmain (определён в kernel.c).
 * Читается посмертным дампом [klock] FATAL, сообщением миграции и
 * детектором [TL-STUCK2] (пульс жив = кадр ушёл через longjmp). */
extern volatile unsigned g_kmain_loops;
extern volatile unsigned g_kmain_phase;

static void task_lock_acq(void)
{
    int cpu = smp_current_cpu();
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    s_tl_if_saved[cpu] = (if_had & 0x200) ? 1 : 0;
    {
        /* [TL-STUCK3] страховка от УТЕЧКИ — только ДОКАЗУЕМО мёртвый
         * держатель при ДОСТОВЕРНОМ владении:
         *   - s_tl_hold_cpu указывает на ядро-держатель (не -1);
         *   - владелец tasks[s_tl_owner[hold_cpu]] мёртв (finished/слот
         *     свободен) — в секцию не вернётся НИКОГДА (kill/exit не
         *     дойдут до rel), замок иначе нечитаем навсегда.
         * Всё остальное — «держатель жив или владение не подтверждено»:
         * ЖДЁМ. Отбор у живого держателя запрещён как и прежде (ШАГ 1:
         * отбор у исполняющегося держателя = параллельный kernel-код =
         * порча). owner<0 (AP-idle планировщик) и owner==0 (kmain/IRQ0) —
         * легитимные состояния, а НЕ «брошенные секции»: прежние ветки
         * «own<0 → освободить» и «escaped → освободить» срывали живые
         * секции планировщиков — корень полевой катастрофы. Путь kmain
         * (KMAIN-RECOVER) закрыт task_lock_panic_release из idt.c. */
        u32 dl = timer_poll_deadline();
        while (__sync_lock_test_and_set(&task_lock, 1)) {   /* lock xchg */
            __asm__ __volatile__("pause" ::: "memory");
            if (timer_poll_expired(dl, 1000000u)) {
                int hc  = s_tl_hold_cpu;
                int own = (hc >= 0 && hc < SMP_MAX_CPUS) ? s_tl_owner[hc] : -1;
                int dead = (own > 0 && own < MAX_TASKS &&
                            (tasks[own].finished || !tasks[own].used));
                if (dead) {
                    if (!s_tl_quiet && task_lock_msg_gate()) {
                        char b[160];
                        snprintf(b, sizeof(b),
                                 "[task_lock] STUCK >1c (owner task %d, site %08x)"
                                 " — держатель мёртв, секция освобождена\n",
                                 own, (unsigned)s_tl_site[hc]);
                        serial_puts(b);
                    }
                    task_lock = 0;          /* мёртвый не отпустит сам */
                } else if (s_tl_quiet) {
                    /* [TL-QUIET] паника уже напечатала дамп: замолкаем и
                     * паркуем это ядро — система остановлена. */
                    for (;;) __asm__ __volatile__("cli; hlt");
                } else if (task_lock_msg_gate()) {
                    char b[160];
                    snprintf(b, sizeof(b),
                             "[task_lock] STUCK >1c (owner task %d, site %08x)"
                             " — держатель жив/не подтверждён, ждём\n",
                             own, (unsigned)s_tl_site[hc]);
                    serial_puts(b);
                }
                dl = timer_poll_deadline();
            }
        }
    }
    s_tl_owner[cpu] = task_current();
    s_tl_site[cpu]  = (u32)(unsigned long)__builtin_return_address(0);
    s_tl_hold_cpu   = cpu;                      /* ПОСЛЕ owner/site (x86 TSO) */
}
static void task_lock_rel(void)
{
    /* [TL-STUCK3]: владение снимаем ДО unlock. Прежний [TL-OWNER]
     * сознательно оставлял stale-владение после release — ватчдог
     * консультировал им при занятом замке и в наносекундном окне
     * «xchg взят новым держателем, владение ещё не записано» видел
     * ПРЕДЫДУЩЕГО держателя; если тот успел завершиться — живой замок
     * срывался по «мёртвому» owner. Теперь окно читается честно:
     * hold_cpu == -1 = «владение не подтверждено» = не трогать. */
    s_tl_hold_cpu = -1;
    __sync_lock_release(&task_lock);                  /* store-release */
    if (s_tl_if_saved[smp_current_cpu()])
        __asm__ __volatile__("sti" ::: "memory");
}

/* [TL-RECOVER] (VMware-сессия): исключение в kmain могло застать его
 * ВНУТРИ секции task_lock (лог: site task_schedule+0x25). KMAIN-RECOVER
 * (idt.c) делает longjmp в главный цикл — кадр брошен, но замок
 * оставался захваченным: AP-планировщик ждал по 1 с (12x «STUCK >1c
 * owner task 0») и срывал его принудительно — тот самый запрещённый
 * «отбор». Отпускаем ТОЛЬКО владение kmain (task 0): его кадр
 * гарантированно покинут (longjmp уже произошёл). Чужой замок
 * (владелец — задача или AP-контекст) НЕ трогаем — это был бы отбор. */
void task_lock_panic_release(void)
{
    /* [TL-STUCK3]: владение kmain подтверждаем по паре (hold_cpu==0,
     * owner[0]==0) — прежняя проверка читала ГЛОБАЛЬНЫЙ stale owner,
     * который после release мог указывать на задачу 0, пока замок уже
     * держал кто-то другой. */
    int hc = s_tl_hold_cpu;
    if (task_lock && hc == 0 && s_tl_owner[0] == 0) {
        s_tl_hold_cpu = -1;
        task_lock = 0;
    }
}

/* [KLOCK-NOSTEAL] (полевой лог VMware, сессия 2; вызывается из exc_panic
 * KMAIN-RECOVER, BSP, IF=0): отпустить ядровый замок ТОЛЬКО если его
 * держит kmain (task 0). Возврат 1 = отпустили (вызывающий заодно
 * восстанавливает PIC-маску — её ставит только держатель-исполнитель).
 * После [KMAIN-NO-KLOCK] kmain замка не держит — вызов почти всегда
 * no-op; прежний БЕЗУСЛОВНЫЙ unlock снимал замок у РАБОТАЮЩЕЙ AP-задачи
 * (в поле после 5 recover-ов молча погиб mquickjs: параллельный
 * kernel-код на двух ядрах = порча кучи — тот самый «отбор» из п.1
 * разбора, только в Recovery-маске). Читается без task_lock: holds_klock
 * задачи 0 мутирует только планировщик ЭТОГО ядра (мы в его исключении)
 * и task_kill(0) — kmain не убивается. */
int task_klock_release_kmain(void)
{
    if (tasks[0].used && tasks[0].holds_klock) {
        tasks[0].holds_klock = 0;
        smp_klock_unlock();
        return 1;
    }
    return 0;
}

static inline int task_prio_of(int i, u32 now)
{
    /* Эффективный приоритет: задача, не получавшая CPU дольше
     * TASK_STARVE_TICKS, временно планируется как UI (анти-голодание
     * фона при постоянной готовности UI-задач). */
    int p = tasks[i].prio;
    if (p < 0) p = 0;
    if (p >= TASK_PRIO_LEVELS) p = TASK_PRIO_LEVELS - 1;
    if (p > 0 && (u32)(now - tasks[i].last_active_tick) > TASK_STARVE_TICKS)
        p = 0;
    return p;
}
/* Защита памяти (песочница нативных c4-программ): линейная база региона
 * задачи; 0 = обычная задача ядра (сегменты flat). Массив НЕ static — на
 * него ссылается irq_stub_0 (пересчёт ESP при смене базы SS), поэтому
 * менять тип/порядок нельзя. */
u32 task_region_base[MAX_TASKS];
int cur_task = 0;   /* глобальный: читается из irq_stub_0 (asm) — ТОЛЬКО BSP */
static int   n_tasks  = 0;

/* ---- многоядерность (сессия 75; ШАГ 5 — per-core) ----
 * g_ap_cur_task[c] — задача, исполняющаяся на ядре c (-1 = ни одной;
 * индекс 0 = BSP не используется — там своя cur_task). Пишется ТОЛЬКО
 * из task_ap_schedule ядра c (контекст LAPIC-таймера, IF=0, task_lock)
 * и orphan-путём паники этого ядра (task_ap_panic_orphan).
 * task_current()/task_exec_core() читают СВОЙ элемент — «кто исполняется».
 * g_ap_slice[c] — непрерывный стаж исполнения задач ядра c (fair-share).
 * s_rr_cursor — round-robin среди одинаково нагруженных AP.
 *
 * Снимает ограничение [AP-CAP-1] прошлой сессии (полевое зависание
 * 2C4T): тогда состояние планировщика было ОДИНОЧНЫМ (один g_ap_cur_task
 * на все AP — взаимная порча контекстов), поэтому поднимался ровно 1 AP,
 * а остальные ядра парковались. Теперь состояние PER-CORE: AP из MADT
 * поднимается столько, сколько найдено (<= SMP_MAX_CPUS); взаимного
 * влияния нет — каждое ядро ведёт только свой элемент массива. */
static volatile int g_ap_cur_task[SMP_MAX_CPUS];
static volatile u32 g_ap_slice[SMP_MAX_CPUS];
static u32          s_rr_cursor   = 0;

/* Слот исполняется сейчас на каком-либо AP? ([SPAWN-GATE], [CORE-COL]) */
static int ap_slot_running(int slot)
{
    for (int c = 1; c < SMP_MAX_CPUS; c++)
        if (g_ap_cur_task[c] == slot) return 1;
    return 0;
}

#include "smp.h"   /* (дубль не нужен: перенесён к остальным include выше) */

/* Захват замка от лица AP-исполнителя (+ маска PIC: драйверные IRQ
 * приходят только на BSP и не должны пересекаться с кодом задачи). */
static int klock_acq_ap(void)
{
    if (!smp_klock_try()) return 0;
    smp_pic_mask();
    return 1;
}

/* Освобождение замка AP-исполнителем (+ восстановление PIC). */
static void klock_rel_ap(void)
{
    smp_pic_restore();
    smp_klock_unlock();
}

/* Хук очистки слота: вызывается при переиспользовании слота задачи,
 * у которой был регион песочницы (kill/ватчдог — loader_task_fn не
 * дошёл до своего free). Loader устанавливает. */
static void (*task_slot_cleanup_cb)(int tid);

void task_set_slot_cleanup_hook(void (*cb)(int tid)) { task_slot_cleanup_cb = cb; }

u32 task_get_region_base(int tid)
{
    return (tid >= 0 && tid < MAX_TASKS) ? task_region_base[tid] : 0;
}

void task_set_region_base(int tid, u32 base)
{
    if (tid >= 0 && tid < MAX_TASKS) task_region_base[tid] = base;
}
static u32   last_sched_tick = 0;   /* тик, когда последний раз вызывался scheduler */

/* Системные тики — теперь инкрементируются из task_schedule (раньше timer_irq). */
static volatile u32 ticks = 0;

u32 timer_ticks(void) { return ticks; }
u32 uptime_sec(void)  { return ticks / 1000; }   /* СЕССИЯ 33: 1 тик = 1 мс */

extern void task_trampoline(void);

/* ---------- IRQ0 stub: переключение контекста ----------
 *
 * Защита памяти: кадр задачи теперь включает DS/ES/SS — задача,
 * работающая в песочнице (сегментный лимит, см. loader.c/gdt.c),
 * после вытеснения продолжает с СВОИМИ сегментами. Планировщик
 * работает с сегментами ядра (flat): задачи с лимитами не могут
 * покалечить таблицу tasks[] через чужое прерывание. */
__attribute__((naked, used)) void irq_stub_0(void)
{
    __asm__ __volatile__(
        "pusha\n\t"                  /* сохранить EAX,ECX,EDX,EBX,ESP_orig,EBP,ESI,EDI */
        "pushl %ss\n\t"             /* сегменты прерванной задачи (в её стеке) */
        "pushl %ds\n\t"
        "pushl %es\n\t"
        /* ЗАЩИТА ПАМЯТИ: сначала сегменты ДАННЫХ на ядро (читать
         * cur_task под песочницей нельзя — #GP), и лишь потом
         * пересчёт ESP. ECX после pusha мёртв. */
        "movl $0x10, %ecx\n\t"
        "movw %cx, %ds\n\t"
        "movw %cx, %es\n\t"
        /* Если прервана задача в песочнице: её SS имеет базу = регион,
         * ESP — смещение. Переводим ESP в абсолютный (регистр), чтобы
         * после смены SS планировщик работал на том же линейном стеке. */
        "movl cur_task, %eax\n\t"
        "movl task_region_base(,%eax,4), %eax\n\t"
        "addl %eax, %esp\n\t"
        "movw %cx, %ss\n\t"
        "cld\n\t"
        "pushl %esp\n\t"             /* arg: указатель на кадр (es,ds,ss,pusha) */
        "call _task_schedule\n\t"   /* планировщик: вернуть новый ESP в %eax */
        "movl %eax, %esp\n\t"        /* переключение стека (абсолютный адрес кадра) */
        /* DS здесь ещё ядро: читаем регион НОВОЙ задачи до восстановления
         * её сегментов (после popl %ds чтение ядра станет невозможным). */
        "movl cur_task, %eax\n\t"   /* scheduler уже обновил cur_task */
        "movl task_region_base(,%eax,4), %ecx\n\t"
        "popl %es\n\t"               /* сегменты НОВОЙ задачи */
        "popl %ds\n\t"
        "popl %eax\n\t"              /* слот SS новой задачи */
        "movw %ax, %ss\n\t"          /* SS = сегмент новой задачи (база региона) */
        "subl %ecx, %esp\n\t"       /* ESP = смещение в регионе (ядро: -0) */
        "popa\n\t"                   /* восстановить regs новой задачи */
        "iret\n\t"                   /* EIP/CS/EFLAGS новой задачи */
    );
}

/* ---------- планировщик ---------- */

/* FIX [T3]: вызывается из task_schedule (IRQ0-контекст) — см. ниже */
int task_watchdog_irq(u32 timeout_ticks);

u32 *task_schedule(u32 *saved_esp)
{
    u32 now = ticks + 1;
    ticks = now;
    outb(0x20, 0x20);                /* EOI master PIC (IRQ0 — на master) */

    /* ШАГ 3: вся мутация tasks[]/выбор — под task_lock (гонка с
     * AP-планировщиком и ватчдогом закрыта). */
    task_lock_acq();

    if (n_tasks == 0) {              /* задач нет — остаёмся */
        task_lock_rel();
        return saved_esp;
    }

    /* Сохранить контекст текущей задачи */
    tasks[cur_task].esp = saved_esp;

    /* Инкремент uptime и обновление last_active_tick */
    u32 delta = now - last_sched_tick;
    tasks[cur_task].uptime += delta;
    tasks[cur_task].last_active_tick = now;
    last_sched_tick = now;

    /* [T3] (перестроено на правильной базе): ВАТЧДОГ В КОНТЕКСТЕ
     * ПРЕРЫВАНИЯ. Раньше task_watchdog() вызывался только из главного
     * цикла kmain — если kmain зависал (все приложения выполняются в
     * task[0]!), ватчдог вообще не запускался и зависала ВСЯ система.
     * Здесь мы в IRQ0; ШАГ 3: гонка «ватчдог против AP-планировщика»
     * (п.4 разбора) закрыта — оба исполняются под task_lock, секция
     * атомарна по определению. Проверяем каждые 512 тиков (~0.5 с). */
    if ((now & 511u) == 0) {         /* ~ каждые 512 тиков (~0.5 с при 1000 Гц) */
        task_watchdog_irq(TASK_WATCHDOG_TICKS);
    }

    /* СЕССИЯ 75 + SMP-rework [KMAIN-NO-KLOCK]: ядровый замок.
     * Правила:
     * (а) держатель -> задача: передача БЕЗ unlock/lock (замок «едет»
     *     вместе с исполняемой задачей; прерванная kernel-секция
     *     возобновится под замком при повторном входе — та же
     *     семантика подвешивания, что у force-idle AP-планировщика);
     * (б) вход в kmain (task 0) — ВСЕГДА БЕЗ замка: цикл kmain защищён
     *     fine-grained замками (ШАГИ 2/3/6: heap_lock/task_lock/wm),
     *     а сам он klock не захватывает. Прежний код «дарил» замок
     *     каждому проснувшемуся kmain — и получал монополию: цикл
     *     kmain длиннее тика IRQ0 (~1.3 мс), замок физически
     *     освобождался только на микросекунды hlt; AP-задачи
     *     голодали вечно (спин 708 мс у fresh-задач, FATAL >2 с у
     *     ждущих acquire_me). Отбор (klock_steal) лишь маскировал
     *     это — ценой параллельного kernel-кода и порчи кучи. */
    int held = tasks[cur_task].holds_klock;

    /* Поиск следующей активной задачи. СЕССИЯ 34: приоритетное
     * планирование — среди готовых выбираем минимальный эффективный
     * приоритет (с учётом анти-голодания), внутри уровня — round-robin
     * (пропуская завершённые и СПЯЩИЕ). СЕССИЯ 75: только задачи с
     * cpu==0, не исполняющиеся на AP (on_cpu) и не «в перелёте»
     * (migrating — их контекст ещё не сохранён AP-ядром). */
    int next = cur_task;
    int found = 0;
    {
        int best = TASK_PRIO_LEVELS;
        for (int i = 0; i < MAX_TASKS; i++) {
            if (!tasks[i].used || tasks[i].finished || tasks[i].waiting)
                continue;
            if (tasks[i].cpu != 0 || tasks[i].on_cpu || tasks[i].migrating)
                continue;
            int p = task_prio_of(i, now);
            if (p < best) best = p;
            if (best == 0) break;
        }
        if (best < TASK_PRIO_LEVELS) {
            for (int t = 0; t < MAX_TASKS; t++) {
                int j = (cur_task + 1 + t) % MAX_TASKS;
                if (!tasks[j].used || tasks[j].finished || tasks[j].waiting)
                    continue;
                if (tasks[j].cpu != 0 || tasks[j].on_cpu || tasks[j].migrating)
                    continue;
                if (task_prio_of(j, now) == best) {
                    next = j;
                    found = 1;
                    break;
                }
            }
        }
    }

    if (!found) {
        /* Никого на BSP: остаёмся в текущем кадре. Замок НЕ берём:
         * был ours (held=1) — он и так при нас; не был — кадр жил без
         * замка и продолжит (kmain; либо задача в окне post-hlt —
         * её собственный acquire дождётся своего). */
        task_lock_rel();
        return saved_esp;
    }

    if (next == cur_task) {
        /* выбор пал на себя же: продолжаем, владение не меняется */
        task_lock_rel();
        return saved_esp;
    }

    if (next == 0 && (tasks[0].cpu != 0 || tasks[0].on_cpu ||
                      tasks[0].migrating || tasks[0].finished ||
                      !tasks[0].used)) {
        /* kmain недоступен (защитный случай): остаёмся в текущем кадре */
        task_lock_rel();
        return saved_esp;
    }

    if (next != 0 && !held) {
        /* вход в задачу требует замка: пробуем взять; неудача (замок
         * у AP) — не переключаемся, текущий кадр продолжает жить */
        if (!smp_klock_try()) {
            task_lock_rel();
            return saved_esp;
        }
    }

    /* Смена задачи. kmain (next==0) входит БЕЗ замка: если замок был
     * у cur — физически освобождаем (AP получает окно; kernel-секция
     * cur «подвешена» и возобновится под замком при следующем входе).
     * Задача (next!=0) входит ВЛАДЕЛЬЦЕМ: передача либо fresh-захват. */
    if (held) {
        tasks[cur_task].holds_klock = 0;
        if (next != 0) tasks[next].holds_klock = 1;
        else           smp_klock_unlock();
    } else if (next != 0) {
        tasks[next].holds_klock = 1;   /* замок взят trylock выше */
    }

    /* FIX (многопоточный WM): подкачать контекст рендера fb новой задачи
     * (canvas окна или экран). fb_sched_lock — вложен в task_lock
     * (иерархия выше), обратного ребра нет. */
    fb_task_switch(cur_task, next);
    cur_task = next;
    task_lock_rel();
    return tasks[cur_task].esp;
}

/* ================= МНОГОЯДЕРНОСТЬ (сессия 75) ================= */

/* Готовая задача для ядра cpu: round-robin от start_after (-1 = с начала).
 * Пропускаем finished/waiting/migrating (у «перелётных» ещё не сохранён
 * контекст — их подхватит BSP после снятия флага AP-ядром). */
static int ap_pick(int cpu, int start_after)
{
    for (int t = 0; t < MAX_TASKS; t++) {
        int j = (start_after + 1 + t) % MAX_TASKS;
        if (j == 0) continue;                       /* kmain — только BSP */
        task_t *tk = &tasks[j];
        if (!tk->used || tk->finished || tk->waiting) continue;
        if (tk->cpu != cpu || tk->migrating) continue;
        return j;
    }
    return -1;
}

/* Планировщик AP-ядра (зовётся из ap_timer_irq_c, IF=0, по LAPIC-таймеру
 * 1000 Гц). Логика зеркальна task_schedule:
 *   - прервана задача этого ядра: сохранить контекст; выбрать следующую
 *     задачу ядра (замок ПЕРЕДАЁТСЯ) либо уйти в idle (замок ОТПУСТИТЬ —
 *     его подхватит BSP или другое ядро);
 *   - прерван idle: запомнить кадр; есть задача и замок свободен —
 *     захватить (+ маска PIC) и войти в задачу;
 *   - fair-share: после SMP_FAIR_TICKS непрерывных тиков — принудительный
 *     уход в idle на один тик (BSP разбирает прерывания/таймеры). */
u32 task_ap_schedule(u32 saved_esp, int core, volatile u32 *idle_esp)
{
    /* СЕССИЯ 77 [SMP-BOOT-GATE]: до smp_tasks_enable() (конец загрузки)
     * AP не получает задач — BSP грузит систему в одиночку, как в
     * до-SMP ядре. Иначе фоновые задачи стартуют на AP посреди boot-лога
     * и вешают BSP в s_lock (sti;hlt при замаскированном IRQ0). */
    if (!smp_tasks_enabled()) return saved_esp;

    /* ШАГ 3: вся последовательность «сохранение кадра + смена
     * g_ap_cur_task/on_cpu/holds_klock» атомарна относительно BSP
     * (ватчдог/kill/spawn) — то самое «неатомарно друг с другом»
     * из п.3 разбора. */
    task_lock_acq();

    int cur = g_ap_cur_task[core];

    /* [UPTIME-DELTA-AP] (разбор кода пользователем, баг №5): дельту
     * тиков считаем ДЛЯ КАЖДОГО вызова планировщика (и в idle — иначе
     * после долгого простоя первая тика задачи получала бы фантомные
     * +100 мс), а начисляем ТОЛЬКО прерванной задаче — как BSP
     * (task_schedule: delta = now - last_sched_tick). При длинной
     * cli-секции в прерванной задаче LAPIC-тик не вытесняет (IF=0) —
     * прежнее «+1» теряло весь интервал, диспетчер задач занижал
     * загрузку AP-задач. Клампы: тот же тик глобального счётчика
     * (дрейф LAPIC против PIT) и первый вызов — минимум 1; зажатость
     * >100 мс за один тик не копим. */
    static volatile u32 s_ap_last_tick[SMP_MAX_CPUS];
    u32 ap_d = ticks - s_ap_last_tick[core];
    if (ap_d == 0 || ap_d > 1000u) ap_d = 1;   /* тот же тик / первый вызов */
    if (ap_d > 100u) ap_d = 100u;              /* не копим «долги» разом */
    s_ap_last_tick[core] = ticks;

    if (cur < 0) {
        /* Ядро было в idle: сохранить кадр idle-цикла */
        *idle_esp = saved_esp;
        int next = ap_pick(core, (int)s_rr_cursor);
        if (next < 0 || !klock_acq_ap()) {
            g_ap_slice[core] = 0;
            task_lock_rel();
            return saved_esp;                   /* остаёмся в idle */
        }
        tasks[next].on_cpu = 1;
        tasks[next].holds_klock = 1;
        tasks[next].last_active_tick = ticks;
        fb_task_switch_ap(-1, next, core);
        g_ap_cur_task[core] = next;
        task_lock_rel();
        return (u32)(unsigned long)tasks[next].esp;
    }

    /* Прервана задача этого ядра: сохранить контекст и учёт.
     * ШАГ 7: [MIG-FIX] удалён — AP-планировщик больше НЕ трогает
     * migrating: единственный владелец флага — task_spawn_impl (клейм
     * слота ДО гейта, публикация migrating=0 в конце заполнения).
     * Прежний сброс здесь создавал гонку с параллельным spawn'ом
     * (снимал чужой клейм посреди заполнения) и держал логику
     * «миграции», которой больше нет (ватчдог мигрирует через cpu=0
     * только для on_cpu==0 — кадр уже сохранён). */
    tasks[cur].esp = (u32 *)saved_esp;
    tasks[cur].uptime += ap_d;               /* [UPTIME-DELTA-AP] */
    tasks[cur].last_active_tick = ticks;
    tasks[cur].on_cpu = 0;

    /* ШАГ 7 ([KLOCK-PASS-FIX] переписан): отбора замка больше нет;
     * holds_klock==0 здесь означает ровно одно — задачу УБИЛИ, пока
     * она исполнялась (task_kill/[KLOCK-REL] снял флаг). Передать
     * «по наследству» нельзя — физического владения нет: передаём
     * только если флаг ещё наш, иначе захватываем для next заново
     * (неудача — idle). */
    int klocked = tasks[cur].holds_klock;

    int force_idle = (g_ap_slice[core] >= SMP_FAIR_TICKS);
    g_ap_slice[core]++;

    int next = force_idle ? -1 : ap_pick(core, cur);
    if (next < 0) {
        /* Уход в idle: отпустить замок (только если он у нас) */
        if (klocked) {
            klock_rel_ap();
            tasks[cur].holds_klock = 0;
        }
        fb_task_switch_ap(cur, -1, core);
        g_ap_cur_task[core] = -1;
        g_ap_slice[core] = 0;
        task_lock_rel();
        return *idle_esp;
    }

    if (klocked) {
        /* Задача -> задача того же ядра: передача замка без unlock/lock */
        tasks[cur].holds_klock = 0;
        tasks[next].holds_klock = 1;
    } else {
        /* Держатель убит (holds снят task_kill): физически владения
         * нет — захват для next. Конкурент (BSP/другое ядро) успел
         * раньше — уходим в idle на тик (без unlock — не наш замок). */
        if (!klock_acq_ap()) {
            fb_task_switch_ap(cur, -1, core);
            g_ap_cur_task[core] = -1;
            g_ap_slice[core] = 0;
            task_lock_rel();
            return *idle_esp;
        }
        tasks[next].holds_klock = 1;
    }
    tasks[next].on_cpu = 1;
    tasks[next].last_active_tick = ticks;
    if (next != cur) {
        fb_task_switch_ap(cur, next, core);
        g_ap_cur_task[core] = next;
    }
    task_lock_rel();
    return (u32)(unsigned long)tasks[next].esp;
}

/* Размещение новой задачи: наименее нагруженное онлайн-ядро.
 * score(ядро) = число НАЗНАЧЕННЫХ (не finished) задач на нём —
 * включая спящие: спящая задача занимает своё ядро после пробуждения,
 * а диспетчер показывает именно НАЗНАЧЕНИЕ (колонка «Ядро»);
 * прежний подсчёт «только готовых» занижал загрузку BSP — все
 * событийные приложения спят, и новые задачи сваливались туда же
 * (полевой лог: «все процессы кроме js работают на ядре 0»).
 * При равенстве предпочтение AP (реальный параллелизм) с round-robin
 * среди них.
 * [CORE-BALANCE] (сессия 2): UI-приоритет БОЛЬШЕ не прикрепляет задачу
 * к BSP — потоки окон ходят на AP наравне с остальными: события
 * доставляются через очереди (qlock), рендер — через per-core
 * fb-контексты (fb_task_switch_ap, сессия 78), краш на AP изолируется
 * orphan-путём так же, как на BSP. Прибиты к BSP остаются ПЕСОЧНИЦЫ
 * (сегментная механика irq_stub_0/cur_task) и kmain (ap_pick: j==0). */
static int task_pick_core(int prio, int is_sandbox)
{
    (void)prio;                     /* [CORE-BALANCE]: приоритет не пинит */
    /* СЕССИЯ 77 [SMP-BOOT-GATE]: во время загрузки всё — на BSP.
     * После smp_tasks_enable() новые задачи размещаются как обычно. */
    if (!smp_tasks_enabled()) return 0;
    if (is_sandbox) return 0;
    int online = smp_online_count();
    if (online <= 1) return 0;
    if (online > SMP_MAX_CPUS) online = SMP_MAX_CPUS;

    int score[SMP_MAX_CPUS];
    for (int c = 0; c < online; c++) {
        int n = 0;
        for (int i = 1; i < MAX_TASKS; i++) {
            if (!tasks[i].used || tasks[i].finished) continue;
            if (tasks[i].cpu == c) n++;      /* спящие тоже считаем */
        }
        score[c] = n;
    }
    int best = score[0];
    for (int c = 1; c < online; c++)
        if (score[c] < best) best = score[c];

    int cands[SMP_MAX_CPUS];
    int nc = 0;
    for (int c = 1; c < online; c++)                 /* AP при равенстве */
        if (score[c] == best) cands[nc++] = c;
    if (nc == 0) return 0;                           /* BSP строго свободнее */
    s_rr_cursor++;
    return cands[s_rr_cursor % (u32)nc];
}

/* ---- операции с ядровым замком от лица задачи ----
 * cli-окна в release/acquire обязательны: между «снять флаг» и
 * «unlock» (и наоборот) не должен вклиниться AP-планировщик — иначе
 * замок «потеряется» (останется захваченным без держателя) или
 * снимется дважды. */

void task_klock_release_me(void)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && tasks[me].holds_klock) {
        /* ШАГ 7: [H4-DIAG] (датирование удержания + «ЗАМЕДЛИТЕЛЬ»)
         * удалён вместе с klock_steal: зависший держатель теперь честно
         * приводит к FATAL-панике ждущего (task_klock_acquire_me),
         * а не маскируется диагностики ради. task_lock здесь НЕ берём:
         * путь не должен ждать другое ядро (кли-секция держателя). */
        tasks[me].holds_klock = 0;
        /* [ШАГ 5] ядро-исполнитель — per-core: PIC распаковывать только
         * задаче, исполняющейся НА ЭТОМ AP (замок захвачен с маской
         * только здесь — klock_acq_ap/acquire_me на AP). BSP-задаче —
         * чистый unlock (PIC на BSP никогда не маскировался нами). */
        int c = smp_this_cpu_is_ap() ? smp_current_cpu() : 0;
        if (c > 0 && g_ap_cur_task[c] == me) klock_rel_ap();  /* AP: + PIC */
        else                                 smp_klock_unlock();
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* ================== ШАГ 1 (SMP-rework): БЕЗ ОТБОРА ==================
 * Смертельный сценарий из лога пользователя (JS-запуск повесил ВСЮ
 * систему): AP-задача зависает, владея ядровым замком (cli-секция,
 * тихое зависание — не exc_panic), а BSP навсегда крутится в спине
 * task_klock_acquire_me под cli. Прерываний нет ни у кого: LAPIC-таймер
 * AP не вытесняет (IF=0 у зависшего), IRQ0 BSP блокирован тем же cli —
 * ватчдог стоит, справиться некому.
 *
 * Новая политика (п.1 разбора): отбор ЗАПРЕЩЁН. Замок, не
 * освобождаемый дольше KLOCK_STALE_US — «система уже сломана»:
 * честная FATAL-паника («порча памяти хуже зависания — по крайней
 * мере понятна причина»). Отбор у ИСПОЛНЯЮЩЕЙСЯ задачи открывал окно
 * параллельного kernel-кода на двух ядрах: порча кучи, #UD,
 * зомби-воскресение — это хуже зависания.
 *
 * Сохранено из прежнего спина (правильная база, не костыль):
 *   - пауза-спин батчами с коротким окном sti: ждущий НЕ вырубает
 *     прерывания на секунды — IRQ0/ввод/ватчдог живут до самой паники;
 *   - мёртвый держатель (finished) ВНЕ исполнения (on_cpu=0)
 *     освобождается немедленно — безопасно (путь [KLOCK-REL]). */
#define KLOCK_SPIN_BATCH 2000u          /* pause-итераций между проверками */
/* [H2] (сохранено на правильной базе): батчи спина перемежаются окном
 * sti — ждущее ядро не «замораживается» на время ожидания. Порог 2 с —
 * заведомо дольше любой легитимной cli-секции (миллисекунды); теперь
 * это не «отбор», а FATAL-паника ждущего. */
#define KLOCK_STALE_US   2000000u       /* 2 с — FATAL-паника ждущего */

/* Кто держит замок сейчас (для диагностики/паники): приоритет — задача,
 * исполняющаяся на AP (on_cpu). Консистентность не атомарна, но истина
 * нужна только на медленном пути ожидания (>KLOCK_SPIN_BATCH пауз). */
static int klock_owner_scan(void)
{
    int cand = -1;
    for (int i = 0; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished || !tasks[i].holds_klock)
            continue;
        if (tasks[i].on_cpu) return i;
        if (cand < 0) cand = i;
    }
    return cand;
}

/* ШАГ 1 (SMP-rework): klock_steal() УДАЛЁН вместе с [ZOMBIE-FIX] и
 * [STEAL-SYS] (заплатки поверх заплатки). Мёртвый держатель ВНЕ
 * исполнения (finished && !on_cpu) освобождается прямо здесь — это
 * безопасно: задача не исполняется, параллельного kernel-кода не
 * возникает (тот же путь, что [KLOCK-REL] в task_kill). Живой/висящий
 * держатель — FATAL-паника: система уже сломана, а порча кучи двумя
 * ядрами в kernel-коде хуже честной остановки. */
void task_klock_acquire_me(void)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && !tasks[me].holds_klock) {
        u32 wait_start = 0;
        u32 wait_ticks = 0;   /* [TL-STUCK3]: кросс-проверка по тикам IRQ0 */
        int  timed     = 0;
        u32  spins     = 0;
        while (!smp_klock_try()) {
            if (++spins < KLOCK_SPIN_BATCH) {
                __asm__ __volatile__("pause");
                continue;
            }
            spins = 0;
            /* [H2]: окно sti между батчами — ждущее ядро живёт до самой
             * паники (IRQ0/ввод/ватчдог продолжают обслуживаться). pit2
             * ниже меряет честное время и под cli. */
            __asm__ __volatile__("sti\n\tpause\n\tcli" ::: "memory");
            /* [GRANT-RACE-FIX] (QEMU-сессия, найдено по -d int): в окне
             * sti нас могли вытеснить и ПОВТОРНО ввести в задачу —
             * планировщик (task_schedule/task_ap_schedule) берёт klock
             * TRYLOCK'ом ЗА НАС и ставит holds_klock=1. Без проверки
             * ждущий вечно крутился бы в этом цикле, ожидая замок,
             * которым САМ ВЛАДЕЕТ (self-deadlock: в логе — 2 с спина
             * в task_klock_acquire_me, затем FATAL с держателем =
             * сам ждущий). Гонка существовала и в старом планировщике
             * (handoff всегда «дарил» замок следующей задаче), но
             * маскировалась отбором klock_steal. */
            if (tasks[me].holds_klock)
                break;              /* замок уже наш — выходим из спина */
            int owner = klock_owner_scan();
            if (owner >= 0 && tasks[owner].finished && !tasks[owner].on_cpu) {
                /* Держатель УБИТ и НЕ исполняется: немедленное
                 * освобождение (НЕ отбор — параллельного kernel-кода
                 * не возникает). */
                char b[96];
                snprintf(b, sizeof(b),
                         "[klock] замок мёртвой задачи %d '%s' освобождён\n",
                         owner, tasks[owner].name);
                serial_puts(b);
                tasks[owner].holds_klock = 0;
                smp_pic_restore();
                smp_klock_unlock();
                timed = 0;
                continue;               /* физически перезахватываем */
            }
            if (!timed) {
                wait_start = timer_poll_deadline();   /* pit2: живёт под cli */
                wait_ticks = ticks;   /* [TL-STUCK3]: второй, независимый источник */
                timed = 1;
            } else if (timer_poll_expired(wait_start, KLOCK_STALE_US) &&
                       (u32)(ticks - wait_ticks) > 1500) {
                /* Держатель не отдаёт замок >2 с (живой завис в cli-
                 * секции; либо «потерянный» замок, owner<0). Система
                 * уже сломана: НЕ отбирать — честная паника с причиной. */
                if (owner >= 0) {
                    char b[128];
                    snprintf(b, sizeof(b),
                             "[klock] держатель: задача %d '%s' (on_cpu=%d)\n",
                             owner, tasks[owner].name,
                             (int)tasks[owner].on_cpu);
                    serial_puts(b);
                }
                task_lock_quiet_set();   /* [TL-QUIET]: AP-спины замолчат */
                serial_puts("[klock] FATAL: klock stuck >2s — kernel panic\n");
                /* SMP-rework (QEMU-сессия): посмертный дамп всего
                 * контекста планирования. Печатаем без замков (система
                 * уже останавливается): рассинхрон на одну итерацию не
                 * искажает картину «кто что держал в момент смерти». */
                {
                    char b[160];
                    serial_puts("[klock] --- контекст паники ---\n");
                    snprintf(b, sizeof(b),
                             "  ticks=%u klock=%d rr=%u ap_cur:",
                             (unsigned)ticks, smp_klock,
                             (unsigned)s_rr_cursor);
                    serial_puts(b);
                    for (int c = 1; c < SMP_MAX_CPUS; c++) {
                        snprintf(b, sizeof(b), " [%d]=%d/%u", c,
                                 (int)g_ap_cur_task[c],
                                 (unsigned)g_ap_slice[c]);
                        serial_puts(b);
                    }
                    serial_puts("\n");
                    snprintf(b, sizeof(b),
                             "  kmain: loops=%u phase=%u "
                             "(1=события 2=wifi 3=halfsec 4=guard 5=кадр 6=hlt)\n",
                             g_kmain_loops, g_kmain_phase);
                    serial_puts(b);
                    serial_puts("  слот имя        cpu on wt mg fn hold idle_ms\n");
                    for (int i = 0; i < MAX_TASKS; i++) {
                        if (!tasks[i].used && !tasks[i].finished &&
                            !tasks[i].migrating)
                            continue;      /* пустой слот */
                        u32 idle_ms = (u32)(ticks - tasks[i].last_active_tick);
                        snprintf(b, sizeof(b),
                                 "  [%2d] %-10.10s %3d %2d %2d %2d %2d %4d %u\n",
                                 i, tasks[i].name, (int)tasks[i].cpu,
                                 (int)tasks[i].on_cpu, (int)tasks[i].waiting,
                                 (int)tasks[i].migrating,
                                 (int)tasks[i].finished,
                                 (int)tasks[i].holds_klock, idle_ms);
                        serial_puts(b);
                    }
                    serial_puts("[klock] --- конец контекста ---\n");
                }
                for (;;) __asm__ __volatile__("cli; hlt");
            }
        }
        /* [ШАГ 5] исполняемся на AP — маска PIC у ЗАДАЧИ ЭТОГО ядра */
        int me_core = smp_this_cpu_is_ap() ? smp_current_cpu() : 0;
        if (me_core > 0 && g_ap_cur_task[me_core] == me) smp_pic_mask();
        tasks[me].holds_klock = 1;
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}



/* Сон задачи с отпуском замка: БЕЗ этого AP-задачи никогда не получили
 * бы CPU (BSP-задача висела бы держателем), а сон AP-задачи не
 * освобождал бы её ядро для остальных. Вызывается ВМЕСТО голого hlt
 * во ВСЕХ точках сна задач (task_yield/msleep, sync.h, wm, ramfs,
 * драйверные ожидания, главный цикл kmain). */
void task_hlt_idle(void)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0" : "=r"(if_had) :: "memory");
    /* СЕССИЯ 77 [SMP-HLT]: сон = sti+hlt. Под cli (IF=0 — фаза загрузки,
     * когда IRQ0 на BSP ещё замаскирован, или драйверная критическая
     * секция) hlt — это ВЕЧНЫЙ сон без источника прерываний. Раньше
     * «спящий» навсегда держал и ядровый замок. Теперь под cli сон
     * невозможен — выходим, вызывающий продолжит крутить свой цикл
     * (ожидание с опросом). Замок при этом НЕ трогаем: cli-секция
     * обязана сохранить владение. */
    if (!(if_had & 0x200)) return;
    task_klock_release_me();
    __asm__ __volatile__("sti\n\thlt" ::: "memory");
    __asm__ __volatile__("cli" ::: "memory");
    /* SMP-rework [KMAIN-NO-KLOCK]: task 0 (kmain) после сна продолжает
     * цикл БЕЗ замка — все пути главного цикла защищены fine-grained
     * замками (ШАГИ 2/3/6), klock принадлежит задачам обоих ядер.
     * Прежний безусловный re-acquire возвращал монополию: kmain брал
     * замок после КАЖДОГО пробуждения (раз в ~1 мс) и держал его весь
     * цикл (~1.3 мс) — AP видел свободный замок микросекундами.
     * Задачи (task != 0) пере-захватывают как раньше: их сон —
     * посреди kernel-кода, остаток кванта обязан идти под замком.
     * (kmain зовёт hlt_idle только на верхнем уровне цикла, вне
     * каких-либо acquire-секций — пропускать захват безопасно.) */
    if (task_current() != 0)
        task_klock_acquire_me();
    __asm__ __volatile__("sti" ::: "memory");
}

/* Терминальный сон (task_exit / kill себя): отпустить замок навсегда. */
void task_idle_release(void)
{
    task_klock_release_me();
}

/* ---------- API ---------- */

void task_init(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        tasks[i].used = 0;
        tasks[i].finished = 0;
        tasks[i].esp = NULL;
        tasks[i].stack = NULL;
        tasks[i].stack_size = 0;
        tasks[i].name[0] = 0;
        tasks[i].fn = NULL;
        tasks[i].arg = NULL;
        tasks[i].uptime = 0;
        tasks[i].system = 0;
        tasks[i].lock_wait = 0;
        tasks[i].cpu = 0;
        tasks[i].on_cpu = 0;
        tasks[i].migrating = 0;
        tasks[i].holds_klock = 0;
    }
    /* task[0] — главная задача (контекст kmain), стек — системный */
    tasks[0].used = 1;
    tasks[0].finished = 0;
    tasks[0].stack = NULL;
    tasks[0].esp = NULL;
    tasks[0].fn = NULL;
    tasks[0].arg = NULL;
    tasks[0].uptime = 0;
    tasks[0].prio = TASK_PRIO_UI;   /* kmain — отзывчивость интерфейса */
    strncpy(tasks[0].name, "main", sizeof(tasks[0].name) - 1);
    tasks[0].name[sizeof(tasks[0].name) - 1] = 0;

    cur_task = 0;
    n_tasks = 1;
    last_sched_tick = 0;
    /* [ШАГ 5]: per-core состояние AP-планировщика — честный -1/idle.
     * task_init идёт ДО smp_tasks_enable — ни одно ядро ещё не заходило
     * в task_ap_schedule, массивы инициализируем безопасно (нулевая
     * инициализация означала бы «на всех AP исполняется kmain»). */
    for (int c = 0; c < SMP_MAX_CPUS; c++) {
        g_ap_cur_task[c] = -1;
        g_ap_slice[c]    = 0;
    }
}

static int task_spawn_impl(const char *name, void (*fn)(void *), void *arg,
                           u8 *stack_mem, u32 stack_size, int spawn_prio)
{
    /* Сохраняем IF: task_spawn теперь вызывается и ДО sti() в kmain
     * (создание окон на этапе загрузки) — не должен включать прерывания
     * раньше времени. */
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");

    /* ШАГ 3: поиск+клейм слота под task_lock. migrating=1 ставится
     * СРАЗУ как клейм: (а) оба планировщика пропускают слот, (б)
     * параллельный spawn на другом ядре не возьмёт тот же слот
     * (прежде двойной spawn с двух ядер мог заполнить один слот
     * дважды — порча tasks[]). */
    int slot = -1;
    task_lock_acq();
    for (int i = 1; i < MAX_TASKS; i++) {
        if ((!tasks[i].used || tasks[i].finished) && !tasks[i].migrating) {
            slot = i;
            tasks[i].migrating = 1;          /* клейм — до всякого ожидания */
            break;
        }
    }
    task_lock_rel();
    if (slot < 0) {
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return -1;
    }

    /* [SPAWN-GATE] (1/2, перестроено): если завершённая задача ЕЩЁ НА
     * AP (finished уже выставлен, но кадр AP сохранит только своим
     * следующим тиком, <=1 мс) — ждём её снятия.
     * ШАГ 7: [SPAWN-GATE-TMO] удалён. Принудительный сброс
     * g_ap_cur_task=-1, пока AP ЕЩЁ ИСПОЛНЯЕТ слот, — это «зомби-
     * воскресение» (п.5 разбора): следующий тик сохранял кадр зависшей
     * задачи как idle-кадр, AP «оживал» в мёртвом коде (#6/#13).
     * Теперь: ждём честно; если AP завис и не сохраняет кадр — одно
     * предупреждение в serial, дальше ждём (зависание честнее порчи;
     * «AP завис держателем klock» накроет FATAL-паника ждущего).
     * Ожидание прерываемо (sti): замков мы не держим, слот заклеймен. */
    if (if_had & 0x200)
        __asm__ __volatile__("sti" ::: "memory");
    {
        u32 gate_spins = 0;
        int  warned = 0;
        while (ap_slot_running(slot)) {   /* [ШАГ 5]: слот на ЛЮБОМ AP */
            if (!warned && ++gate_spins > 4000000u) {  /* ~0.2-0.4 с */
                warned = 1;
                char b[96];
                snprintf(b, sizeof(b),
                         "[smp] spawn: слот %d ещё на AP — ждём снятия "
                         "(AP не сохраняет кадр — завис?)\n", slot);
                serial_puts(b);
            }
            /* нас могли убить, пока мы ждём: снять клейм и сдаться */
            if (task_finished(task_current())) {
                task_lock_acq();
                tasks[slot].migrating = 0;
                task_lock_rel();
                if (if_had & 0x200)
                    __asm__ __volatile__("sti" ::: "memory");
                return -1;
            }
            __asm__ __volatile__("pause" ::: "memory");
        }
    }
    __asm__ __volatile__("cli" ::: "memory");

    /* [SPAWN-GATE] (2/2): заполнение слота. ШАГ 3: кросс-ядерная
     * атомарность — task_lock; локальная (своё ядро) — cli. Гейт
     * публикации: migrating держим ВСЁ заполнение — оба планировщика
     * (BSP task_schedule и AP ap_pick) пропускают migrating-задачи;
     * снимаем флаг ОДНОЙ строкой в самом конце, когда used/esp/cpu/имя
     * уже согласованы. */
    task_lock_acq();

    /* Освобождаем память, если слот уже использовался (завершённая задача).
     * Для внешних стеков (песочница) это ВЕСЬ регион задачи — освобождение
     * отложено до переиспользования слота, потому что задача ещё может
     * стоять на этом стеке в hlt-цикле task_exit().
     * Песочница (kill/ватчдог): loader_task_fn не дошёл до своего free —
     * регион чистим хуком, GDT-запись гасим здесь же. */
    if (tasks[slot].stack) {
        free(tasks[slot].stack);
        tasks[slot].stack = NULL;
    }
    if (task_region_base[slot]) {
        gdt_clear_task_region(slot);
        task_region_base[slot] = 0;
        if (task_slot_cleanup_cb) task_slot_cleanup_cb(slot);
    }

    u8 *stack = stack_mem;
    if (!stack) {
        stack = (u8 *)malloc(TASK_STACK_SIZE);
        if (!stack) {
            tasks[slot].migrating = 0;      /* вернуть клейм — слот не наш */
            task_lock_rel();
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
            return -1;
        }
        stack_size = TASK_STACK_SIZE;
    }
    if (stack_size == 0) stack_size = TASK_STACK_SIZE;

    /* СЕССИЯ 59: канарейки в НИЖНИЕ 8 байт собственного стека
     * (только для malloc-стеков: у песочницы stack = регион,
     * там по смещению 0 лежит kapi-копия). */
    if (!stack_mem && stack_size >= 16) {
        ((u32 *)stack)[0] = TASK_STACK_CANARY0;
        ((u32 *)stack)[1] = TASK_STACK_CANARY1;
        tasks[slot].canary = 1;
    } else {
        tasks[slot].canary = 0;
    }

    /* Строим кадр: iret (EFLAGS, CS, EIP) + pusha (8 regs) + ss/ds/es.
     * Стек растёт вниз, поэтому кладём с вершины.
     * Сегменты новой задачи — ЯДРА (flat): песочницу (если нужно)
     * loader включает только вокруг вызова entry() — см. sandbox_call. */
    u32 *sp = (u32 *)(stack + stack_size);
    sp -= 1; *sp = 0x00000202;                       /* EFLAGS: reserved bit + IF=1 */
    sp -= 1; *sp = 0x08;                             /* CS */
    sp -= 1; *sp = (u32)(unsigned long)task_trampoline;  /* EIP */
    /* pusha order: EAX, ECX, EDX, EBX, ESP_orig, EBP, ESI, EDI */
    sp -= 1; *sp = 0;                                /* EAX */
    sp -= 1; *sp = 0;                                /* ECX */
    sp -= 1; *sp = 0;                                /* EDX */
    sp -= 1; *sp = 0;                                /* EBX */
    sp -= 1; *sp = (u32)(unsigned long)sp;            /* ESP_orig (игнорируется popa) */
    sp -= 1; *sp = 0;                                /* EBP */
    sp -= 1; *sp = 0;                                /* ESI */
    sp -= 1; *sp = 0;                                /* EDI */
    sp -= 1; *sp = KERNEL_DS;                        /* SS (восстановит stub) */
    sp -= 1; *sp = KERNEL_DS;                        /* DS */
    sp -= 1; *sp = KERNEL_DS;                        /* ES — после fabricate ESP указывает сюда */

    tasks[slot].used = 1;
    tasks[slot].finished = 0;
    tasks[slot].esp = sp;
    tasks[slot].stack = stack;
    tasks[slot].stack_size = stack_size;
    tasks[slot].fn = fn;
    tasks[slot].arg = arg;
    tasks[slot].uptime = 0;
    tasks[slot].last_active_tick = ticks;
    tasks[slot].watchdog_timeout = 0;
    tasks[slot].last_uptime = 0;
    tasks[slot].waiting = 0;
    tasks[slot].system = 0;
    tasks[slot].lock_wait = 0;
    tasks[slot].prio = spawn_prio;
    tasks[slot].sandbox = (stack_mem != NULL);
    /* СЕССИЯ 75: размещение по наименее нагруженному ядру.
     * UI-задачи и песочницы (внешний стек) — всегда BSP. */
    tasks[slot].cpu = task_pick_core(spawn_prio, stack_mem != NULL);
    tasks[slot].on_cpu = 0;
    /* migrating остаётся 1 — гейт публикации, снимается ОДНОЙ строкой
     * ниже, когда всё заполнено. */
    tasks[slot].holds_klock = 0;
    strncpy(tasks[slot].name, name ? name : "?", sizeof(tasks[slot].name) - 1);
    tasks[slot].name[sizeof(tasks[slot].name) - 1] = 0;
    /* Учёт памяти: стек выделен в контексте ПОРОЖДАЮЩЕЙ задачи —
     * переносим владение на новую (диспетчер задач покажет честные цифры) */
    mem_reassign(stack, slot);
    n_tasks++;

    /* ПУБЛИКАЦИЯ — последняя операция. До этой строки оба планировщика
     * видят слот как migrating (пропускают): гонки «used=1 при ещё
     * старом esp/cpu» больше нет. */
    __asm__ __volatile__("" ::: "memory");
    tasks[slot].migrating = 0;
    task_lock_rel();

    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return slot;
}

void task_yield(void)
{
    /* Простая уступка: спим до следующего IRQ0, отпустив ядровый замок
     * (иначе AP-задачи не получили бы CPU, пока мы «уступаем»). */
    task_hlt_idle();
}

/* Сон на ms миллисекунд с уступкой CPU (СЕССИЯ 33: 1 тик = 1 мс при
 * 1000 Гц — точность ±1 мс вместо ±10 мс).
 * Экспортируется в приложения через kapi->msleep — это честная
 * семантика kdelay(ms) из c4 VM (раньше native-кодогенератор
 * эмитил один task_yield и анимации превращались в один кадр). */
void task_msleep(u32 ms)
{
    u32 need = ms;                   /* 1 тик = 1 мс (PIT 1000 Гц) */
    if (need == 0) need = 1;
    /* [H7b] (сохранено на правильной базе) (разбор гипотез «msleep под cli — бесконечный busy-
     * цикл»): под IF=0 timer_ticks() стоит (IRQ0 не приходит), а
     * task_hlt_idle молча возвращается — цикл ниже превращался бы в
     * вечный спин. Замок при этом НЕ отпускаем (cli-секция обязана
     * сохранить владение) и sti НЕ включаем (вытеснение посреди
     * cli-секции ломает инвариант большого замка) — меряем честное
     * время pit2 (работает под cli) и ждём плотным опросом. */
    {
        int if_had;
        __asm__ __volatile__("pushfl\n\tpopl %0" : "=r"(if_had) :: "memory");
        if (!(if_had & 0x200)) {
            u32 dl = timer_poll_deadline();
            while (!timer_poll_expired(dl, need * 1000u))
                __asm__ __volatile__("pause" ::: "memory");
            return;
        }
    }
    u32 start = timer_ticks();
    while ((timer_ticks() - start) < need) {
        task_hlt_idle();             /* сон с отпуском ядрового замка */
    }
}

int task_spawn_ext(const char *name, void (*fn)(void *), void *arg,
                   u8 *stack_mem, u32 stack_size)
{
    return task_spawn_impl(name, fn, arg, stack_mem, stack_size,
                           TASK_PRIO_NORMAL);
}

int task_spawn(const char *name, void (*fn)(void *), void *arg)
{
    return task_spawn_impl(name, fn, arg, NULL, 0, TASK_PRIO_NORMAL);
}

/* СЕССИЯ 34: spawn с приоритетом (wifi/usb/sata/netmon = BG,
 * потоки окон WM = UI). Приложениям и ramfs — обычный task_spawn. */
int task_spawn_prio(const char *name, void (*fn)(void *), void *arg, int prio)
{
    if (prio < 0 || prio >= TASK_PRIO_LEVELS) prio = TASK_PRIO_NORMAL;
    return task_spawn_impl(name, fn, arg, NULL, 0, prio);
}

void task_set_priority(int idx, int prio)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    if (prio < 0 || prio >= TASK_PRIO_LEVELS) return;
    task_lock_acq();          /* ШАГ 3: мутация tasks[] — под task_lock */
    tasks[idx].prio = prio;
    task_lock_rel();
}

int task_priority(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return TASK_PRIO_NORMAL;
    if (!tasks[idx].used) return TASK_PRIO_NORMAL;
    return tasks[idx].prio;
}

void task_exit(void)
{
    /* СЕССИЯ 75: «я» — ИСПОЛНЯЮЩАЯСЯ задача (на AP cur_task — чужой).
     * СЕССИЯ 79 [T0-GUARD]: НИКОГДА не помечаем задачу 0 (kmain)
     * завершённой. Раньше при инвертированном task_current (см.
     * [ROOT-FIX] в smp.c) trampoline на AP считал себя kmain и одним
     * task_exit() УБИВАЛ весь рабочий стол (мышь/клавиатура/композитинг
     * — всё исполняется в kmain). Даже при ошибке идентификации ядра
     * гибель kmain недопустима: молча остаёмся живыми. */
    int me = task_current();
    /* ШАГ 3: мутация tasks[] — под task_lock; cli не защищает от
     * AP-планировщика (п.2 разбора). */
    task_lock_acq();
    if (me > 0 && me < MAX_TASKS && tasks[me].used && !tasks[me].finished) {
        tasks[me].finished = 1;
        if (n_tasks > 0) n_tasks--;
    }
    task_lock_rel();
    /* Отпустить ядровый замок — иначе он останется у мёртвой задачи
     * и вся ОС встанет (никто не сможет войти в kernel-код).
     * [T0-GUARD]: если «мы» по ошибке kmain — замок НЕ отпускаем
     * THIRD-PARTY: task_klock_release_me снимет флаг ТОЛЬКО если он наш. */
    task_idle_release();
    /* Больше не вернёмся — ждём переключения на другую задачу. */
    for (;;) __asm__ __volatile__("hlt");
}

/* Завершить задачу по индексу. Если задача уже не используется или это
 * текущая задача — для текущей работает как task_exit().
 * Параметр idx может быть любым (проверяется валидность слота).
 * Возвращает 1 при успехе, 0 если слот не используется или задача уже завершена.
 * Стек задачи будет освобождён при следующем task_spawn() в этот слот.
 * СИСТЕМНЫЕ задачи (ramfs-сервер) убивать НЕЛЬЗЯ — их смерть намертво
 * блокирует файловые операции всей ОС; task_kill возвращает 0. */
int task_kill(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (idx == 0) return 0;             /* главную задачу (kmain) убивать нельзя */
    if (!tasks[idx].used) return 0;
    if (tasks[idx].finished) return 0;
    if (tasks[idx].system) return 0;    /* системная задача — под защитой */

    /* ШАГ 3: вся мутация — под task_lock (кросс-ядерно). */
    task_lock_acq();
    tasks[idx].finished = 1;
    if (n_tasks > 0) n_tasks--;
    /* СЕССИЯ 78 [KLOCK-REL]: убитая задача могла владеть ядровым замком
     * (например, спала внутри cli-секции после захвата). Раньше замок
     * оставался «висеть» на мёртвом флаге holds_klock до отбора по 5-с
     * таймауту [KLOCK-STALE] — теперь освобождаем сразу, если задача
     * НЕ исполняется на AP прямо сейчас (там замок корректно передаст
     * AP-планировщик при сохранении кадра). */
    if (tasks[idx].holds_klock && !tasks[idx].on_cpu) {
        tasks[idx].holds_klock = 0;
        char b[80];
        snprintf(b, sizeof(b),
                 "[klock] замок убитой задачи %d '%s' освобождён\n",
                 idx, tasks[idx].name);
        serial_puts(b);
        smp_pic_restore();
        smp_klock_unlock();
    }
    /* Если убили текущую — уступить CPU. СЕССИЯ 75: замок у убитой
     * задачи подхватит планировщик при следующем переключении
     * (передача holds-флага). */
    if (idx == cur_task) {
        task_lock_rel();
        sti();
        task_idle_release();
        for (;;) __asm__ __volatile__("hlt");
    }
    task_lock_rel();
    return 1;
}

int task_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++)
        if (tasks[i].used && !tasks[i].finished) n++;
    return n;
}

/* СЕССИЯ 75: «текущая» задача = ИСПОЛНЯЮЩАЯСЯ.
 *
 * СЕССИЯ 78 [TASKC-CPU]: СЕМЕЙСТВО ЗАВИСАНИЙ ИЗ ЛОГА ПОЛЬЗОВАТЕЛЯ
 * («ПОВТОРНЫЙ вход задачи 10 в блокировку», пустые окна, зависание
 * после JS) имело корень ЗДЕСЬ. Раньше: g_ap_cur_task >= 0 заставлял
 * ЛЮБОЙ код считать себя AP-задачей:
 *   - BSP (kmain) при task_klock_acquire_me видел «себя» AP-задачу с
 *     holds_klock=1 и ПРОПУСКАЛ захват замка — главный цикл шёл
 *     ПАРАЛЛЕЛЬНО AP-задаче (две задачи в критических секциях: порча
 *     wins[], очередей, кучи);
 *   - s_lock записывал владельцем ЧУЖУЮ AP-задачу, а её собственный
 *     следующий вход определялся как «реентерабельность»;
 *   - task_klock_release_me на BSP мог «отпустить» ЧУЖОЙ замок
 *     (klock_rel_ap → PIC распакован, AP продолжает без замка).
 * Теперь ядро-исполнитель определяется честно: на AP (LAPIC включён —
 * MSR 0x1B бит 8; у BSP он выключен с smp_init) возвращается
 * g_ap_cur_task, на BSP — cur_task. До smp_init / до запуска AP
 * g_ap_cur_task == -1, на BSP ветка не срабатывает вовсе; на AP-idle
 * честно возвращается -1 ([TASKC-AP-IDLE] ниже).
 *
 * ШАГ 3: остаточная гонка «пишутся неатомарно друг с другом» (п.3
 * разбора) закрыта task_lock: пишущие последовательности в
 * task_ap_schedule/watchdog/kill/spawn атомарны целиком. */
int task_current(void)
{
    /* [TASKC-AP-IDLE] (разбор кода пользователем, баг №3): на AP в idle
     * (g_ap_cur_task[я] == -1) ЧЕСТНО возвращаем -1. Прежний фолбэк на
     * cur_task подсовывал ЧУЖУЮ (BSP) задачу:
     *  - s_tl_owner в task_lock_acq записывал владельцем AP-секции
     *    задачу BSP; если это была задача 0 (kmain), исключение в kmain
     *    (KMAIN-RECOVER -> task_lock_panic_release: owner==0) отпускало
     *    ЖИВОЙ замок AP-планировщика посреди секции — параллельный вход
     *    двух планировщиков в tasks[];
     *  - exc_diag_line печатала имя задачи BSP для сбоя на AP-idle;
     *  - s_lock (sync.h) записывал владельцем чужую задачу — её
     *    легитимный вход выглядел «повторным» (реентерабельность).
     * Вызывающие готовы к -1: task_name/task_finished/task_exit/
     * task_stack_range/task_set_waiting_me/... проверяют индекс;
     * кодировки владельцев (sync.h slock_me_code, mem.c b->used)
     * различают «вне задачи» отдельным значением, не 0.
     *
     * [ШАГ 5]: теперь AP НЕСКОЛЬКО — читаем СВОЙ элемент массива
     * (ядро-исполнитель по LAPIC ID; smp_current_cpu даёт 0 только на
     * BSP/не опознанном ядре — тогда честный -1 безопаснее чужой задачи). */
    if (smp_this_cpu_is_ap()) {
        int c = smp_current_cpu();
        return (c > 0) ? g_ap_cur_task[c] : -1;   /* может быть -1 */
    }
    return cur_task;
}

/* Ядро-исполнитель ТЕКУЩЕГО кода (0 = BSP, 1..N = AP). Вызывается из
 * задач и из fb-примитивов (выбор per-core набора fb-контекстов).
 * СЕССИЯ 78 [TASKC-CPU]: та же логика, что task_current — раньше BSP
 * при активной AP-задаче рисовал в НАБОР КОНТЕКСТОВ AP (fb_task_switch
 * уводил canvas BSP-задачи на чужой набор — артефакты/пустые окна). */
int task_exec_core(void)
{
    /* [ШАГ 5]: на AP возвращаем СВОЁ ядро, если на нём исполняется
     * задача (idle-код AP работает с контекстом BSP, как раньше —
     * fb-примитивы из idle не рисуют). */
    if (smp_this_cpu_is_ap()) {
        int c = smp_current_cpu();
        if (c > 0 && g_ap_cur_task[c] >= 0) return c;
    }
    return 0;
}

int task_cpu(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return -1;
    if (!tasks[idx].used) return -1;
    return tasks[idx].cpu;
}

/* VMware-сессия [CORE-COL] (запрос пользователя: колонка «Ядро» в
 * диспетчере задач). Живой адрес задачи: на каком ядре она НАХОДИТСЯ.
 *  - работает на AP сейчас (on_cpu/g_ap_cur_task) -> ядро AP;
 *  - является текущей на BSP (cur_task) -> ядро 0;
 *  - иначе -> назначенное ядро (tasks[].cpu; миграции меняют его).
 * Чтение без task_lock допустимо: отображение, рассинхрон на один
 * тик для диспетчера не критичен. */
int task_core_live(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS || !tasks[idx].used) return -1;
    /* [ШАГ 5]: ядер несколько — просматриваем СВОЙ массив; ядро с этой
     * задачей (если есть) приоритетнее назначения/BSP. */
    for (int c = 1; c < SMP_MAX_CPUS; c++)
        if (g_ap_cur_task[c] == idx) return c;
    if (idx == cur_task) return 0;
    return tasks[idx].cpu;
}

int task_on_cpu(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].on_cpu;
}

int task_ap_is_idle(int core)
{
    /* [ШАГ 5] per-core: idle-статус ИМЕННО этого ядра (учёт загрузки
     * LAPIC-таймера в ap_timer_irq_c). Индекс 0 (BSP) — не бывает AP. */
    if (core <= 0 || core >= SMP_MAX_CPUS) return 1;
    return g_ap_cur_task[core] < 0;
}

/* СЕССИЯ 79 [PANIC-TASK]: CPU-исключение в ЗАДАЧЕ (не в kmain) —
 * задача снимается, ядро продолжает работать. Вызывается exc_panic
 * (idt.c) на BSP: помечаем ИСПОЛНЯЮЩУЮСЯ задачу погибшей, снимаем
 * её флаги, отпускаем ядровый замок (если числится за ней) и снимаем
 * PIC-маску. Блокировки s_lock, оставшиеся за задачей, восстановит
 * sync.h (мёртвый владелец освобождается ждущим). Возвращает 1, если
 * исключение изолировано (можно продолжать), 0 — виновник kmain/
 * загрузка (нужна полная паника). */
int task_panic_kill_current(void)
{
    int me = task_current();
    if (me <= 0 || me >= MAX_TASKS) return 0;
    if (!tasks[me].used) return 0;
    /* [TL-RECOVER]: гибнущая задача могла быть прервана ВНУТРИ своей
     * секции task_lock — освобождаем ДО acq, иначе self-deadlock
     * (acq ниже ждал бы собственный замок 1 с). Секция брошена:
     * задачу снимаем, в неё не вернёмся. */
    /* [TL-STUCK3]: владение per-cpu — секция наша, только если замок
     * держит ЭТО ядро и владелец в его ячейке = гибнущая задача. */
    {
        int _c = smp_current_cpu();
        if (task_lock && s_tl_hold_cpu == _c && s_tl_owner[_c] == me) {
            s_tl_hold_cpu = -1;
            task_lock = 0;
        }
    }
    task_lock_acq();      /* ШАГ 3: мутация — под task_lock */
    if (!tasks[me].finished) {
        tasks[me].finished = 1;
        tasks[me].on_cpu = 0;
        tasks[me].waiting = 0;
        tasks[me].lock_wait = 0;
        if (n_tasks > 0) n_tasks--;
    }
    task_lock_rel();
    if (tasks[me].holds_klock) {
        tasks[me].holds_klock = 0;
        smp_pic_restore();
        smp_klock_unlock();
    }
    return 1;
}

/* СЕССИЯ 76: паника на AP (зовётся из exc_panic, idt.c, в контексте
 * исключения AP, IF=0). Лог пользователя: #13 на AP при первом
 * переключении idle->задача — замок уже был у погибшего ядра и PIC
 * замаскирован, поэтому BSP замерзал намертво (нет IRQ0, нет тиков).
 * Здесь: задача, исполнявшаяся на AP, помечается погибшей (её код не
 * был запущен / контекст уже не вернуть), замок и PIC-маска
 * отпускаются — BSP продолжает работать, потеряв только это ядро и
 * одну задачу. Сам AP после этого уходит в hlt навсегда (cli). */
void task_ap_panic_orphan(void)
{
    int held_klock = 0;
    /* [ШАГ 5]: панирует КОНКРЕТНОЕ ядро — его элемент и чистим
     * (раньше состояние было одиночным — теперь каждое ядро ведёт
     * своё; чужие AP-задачи не трогаем). */
    int c = smp_current_cpu();
    if (c < 1) {
        /* невозможно (вызываем только на онлайн-AP), но подстраховка:
        * без индекса ядра нельзя выборочно чистить — ядро всё равно
        * уйдёт в вечный hlt, ограничиваемся 1-м валидным AP + лог */
        serial_puts("[smp] orphan: ядро не опознано — беру AP1 (критично!)\n");
        c = 1;
    }
    int t = g_ap_cur_task[c];
    /* [TL-RECOVER]: AP-задача могла быть прервана ВНУТРИ своей секции
     * task_lock — освобождаем ДО acq (self-deadlock иначе). */
    /* [TL-STUCK3]: владение per-cpu (см. task_panic_kill_current) */
    {
        int _c = smp_current_cpu();
        if (task_lock && t >= 0 && s_tl_hold_cpu == _c &&
            s_tl_owner[_c] == t) {
            s_tl_hold_cpu = -1;
            task_lock = 0;
        }
    }
        task_lock = 0;
    task_lock_acq();      /* ШАГ 3: мутация — под task_lock */
    /* [KLOCK-FINISHED-FIX] (разбор кода пользователем, баг №2):
     * klock/on_cpu/holds снимаем ВНЕ зависимости от finished. Сценарий
     * гонки: задачу УБИЛИ (task_kill/watchdog: finished=1, но holds_klock
     * НЕ тронут — kill рассчитывает, что AP-планировщик передаст замок
     * при сохранении кадра), а она падает с исключением РАНЬШЕ
     * ближайшего тика. Старое условие !finished пропускало блок —
     * физический klock оставался заперт навсегда (holds=1, on_cpu=1),
     * AP уходил в idle, ватчдог через 2 с давал [klock] FATAL =>
     * паника всей системы. BSP-близнец (task_panic_kill_current) всегда
     * отпускал holds безусловно — выравниваем семантику. */
    if (t >= 0 && t < MAX_TASKS && tasks[t].used) {
        if (!tasks[t].finished) {
            tasks[t].finished = 1;
            if (n_tasks > 0) n_tasks--;
            /* стек не освобождаем (esp задачи мог указывать в него) —
             * блок отдаст task_spawn при переиспользовании слота */
        }
        tasks[t].waiting  = 0;
        tasks[t].lock_wait = 0;
        tasks[t].on_cpu   = 0;   /* иначе ватчдог считал бы её «исполняемой» */
        held_klock = tasks[t].holds_klock;
        tasks[t].holds_klock = 0;
    }
    g_ap_cur_task[c] = -1;
    g_ap_slice[c]    = 0;
    task_lock_rel();      /* ФИКС УТЕЧКИ (QEMU-сессия): rel отсутствовал —
                           * любое исключение на AP оставляло task_lock=1
                           * НАВСЕГДА: оба планировщика (IRQ0 BSP и LAPIC
                           * AP) умирали в спине xchg, система замолкала
                           * без паники (диагноз по -d int: оба ядра в
                           * task_lock_acq). */
    /* Отпускать klock/PIC — ТОЛЬКО если погибшая задача реально владела
     * замком (упала в кли-секции). Безусловный unlock снимал ЧУЖОЙ
     * замок (задача могла упасть уже отпустив — в sleep-ожидании) и
     * открывал параллельный kernel-код на двух ядрах. */
    if (held_klock) {
        smp_pic_restore();
        smp_klock_unlock();
    }
}

/* Границы стека ТЕКУЩЕЙ задачи — для C-stack guard'а JS-движка
 * (mquickjs_api.c ставит JS_SetStackGuard на lo + запас).
 * Возвращает 1 для задач с собственным стеком (malloc-стек или песочница);
 * 0 для task[0] (kmain на системном стеке — движок там не исполняется,
 * guard остаётся выключенным). */
int task_stack_range(u32 *lo, u32 *hi)
{
    /* СЕССИЯ 75: границы стека ИСПОЛНЯЮЩЕЙСЯ задачи (JS на AP — свой стек) */
    int t = task_current();
    if (t < 0 || t >= MAX_TASKS) return 0;
    if (!tasks[t].used || !tasks[t].stack || tasks[t].stack_size < 256) return 0;
    if (lo) *lo = (u32)(unsigned long)tasks[t].stack;
    if (hi) *hi = (u32)(unsigned long)tasks[t].stack + tasks[t].stack_size;
    return 1;
}

/* Пометить задачу как системную (kill запрещён, ватчдог не трогает).
 * Используется для ramfs-сервера и других подсистем ядра. */
void task_set_system(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].system = 1;
}

int task_is_system(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].system;
}

const char *task_name(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return "";
    if (!tasks[idx].used) return "";
    return tasks[idx].name;
}

int task_used(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].used;
}

int task_finished(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 1;
    return tasks[idx].finished;
}

u32 task_uptime(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].uptime;
}

/* ---------- trampoline для новых задач ---------- */

void task_trampoline(void)
{
    /* СЕССИЯ 75: fn/arg своей задачи — через исполняющуюся (на AP
     * cur_task чужой — задача могла стартовать на другом ядре).
     * СЕССИЯ 79 [ROOT-FIX]: task_current() теперь честен на обоих
     * ядрах (см. smp_this_cpu_is_ap) — trampoline видит СВОЮ задачу. */
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && tasks[me].fn)
        tasks[me].fn(tasks[me].arg);
    task_exit();
    for (;;) __asm__ __volatile__("hlt");
}

/* ---------------- сон и пробуждение (многопоточный WM) ---------------- */

/* Пометить задачу как спящую (вызывается ПОД cli из task_wait_event). */
void task_set_waiting_me(void)
{
    /* СЕССИЯ 75: «я» — исполняющаяся задача (на AP это не cur_task) */
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS)
        tasks[me].waiting = 1;
}

/* Разбудить задачу по индексу: снять waiting — следующий тик IRQ0
 * вернёт её в планирование. Безопасно из любого контекста.
 * FIX (ватчдог убивал разбуженные задачи): одновременно ОБНУЛЯЕМ
 * last_active_tick. Сценарий бага: задача спала 20 с (например, пока
 * держатель блокировки завис) — kmain будит её (waiting=0), но до
 * первого слота планировщика ватчдог видел «не планировалась 20 с»
 * и УБИВАЛ её. Теперь будение = отсчёт простоя заново (5 с форы,
 * а полный цикл планировщика ≤ 256×10 мс = 2.6 с). */
void task_wake(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used || tasks[idx].finished) return;
    task_lock_acq();          /* ШАГ 3: мутация tasks[] — под task_lock */
    if (tasks[idx].used && !tasks[idx].finished) {
        tasks[idx].waiting = 0;
        tasks[idx].last_active_tick = ticks;   /* сброс счётчика простоя */
    }
    task_lock_rel();
}

int task_is_waiting(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].waiting;
}

/* Пометить/снять признак «жду блокировку» для ТЕКУЩЕЙ задачи.
 * Вызывается из s_lock (sync.h) ПОД cli — атомарно. Задача в ожидании
 * блокировки — НЕ «зависла»: ватчдог её не трогает, её судьбу решает
 * таймаут отбора блокировки (SLOCK_STALE_TICKS). Иначе ватчдог убивал
 * ждущие задачи через 5 с — и при зависании держателя выкашивал все
 * окна ДО срабатывания отбора блокировки. */
void task_set_lockwait_me(int on)
{
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS)
        tasks[me].lock_wait = on ? 1 : 0;
}

int task_is_lockwait(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].lock_wait;
}

/* ---------- Ватчдог ---------- */

void task_set_watchdog(int idx, u32 timeout_ticks)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].watchdog_timeout = timeout_ticks;
    tasks[idx].last_uptime = tasks[idx].uptime;
}

u32 task_get_watchdog(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].watchdog_timeout;
}

/* [T3b] (перестроено): версия для вызова ИЗ ПРЕРЫВАНИЯ (уже с IF=0 — без cli/sti).
 * Критерий: задача не получала CPU дольше limit тиков. Заметим честно:
 * задача, зависшая в плотном цикле while(1){} БЕЗ hlt, всё равно
 * получает CPU по round-robin и этим критерием не ловится — для этого
 * нужны счётчики команд/привилегии (нет в x86 без MMU/PIT-профилирования).
 * Но главный сценарий пользователя (зависает kmain с приложениями,
 * либо задача навсегда теряет CPU) теперь отрабатывается: если task[0]
 * (kmain с браузером/терминалом) не планировался дольше таймаута —
 * зависшие вложенные задачи убиваются, система продолжает жить.
 * Стек НЕ освобождаем немедленно (esp задачи может указывать в него,
 * а free() из IRQ-контекста опасен) — отложено до task_spawn в этот слот. */
/* [CORE-BALANCE] (полевой лог VMware: «все процессы кроме js —
 * на ядре 0»): мягкий ребаланс ядер из ватчдога (раз в проход,
 * ~0.5 с). Причины перекоса: (а) все boot-задачи создаются ДО
 * smp_tasks_enable() и навсегда получают cpu=0; (б) миграция AP->BSP
 * при голоде — односторонняя. Переносим ОДНУ СПЯЩУЮ (waiting) подвижную
 * задачу с перегруженного ядра на недогруженное — перегруз >= 2
 * (меньше — не стоит гонять задачи туда-сюда).
 * Переносятся ТОЛЬКО спящие: их кадр уже сохранён, ни одно ядро их
 * не исполняет, а голодная (готовая, но не получающая CPU) задача на
 * AP уже обслуживается односторонней миграцией выше — классы не
 * пересекаются, пинг-понга нет. Подвижные: не kmain, не песочница
 * (сегментная механика), не системная, без замков; UI-приоритет
 * БОЛЬШЕ не пинит к BSP ([CORE-BALANCE]: потоки окон ходят на AP).
 * Вызывается под task_lock (из task_watchdog_irq). */
static void task_rebalance(void)
{
    int online = smp_online_count();
    if (online <= 1) return;
    if (online > SMP_MAX_CPUS) online = SMP_MAX_CPUS;

    /* счёт НАЗНАЧЕННЫХ задач (спящие включены) + поиск кандидата
     * (самая давно спящая подвижная задача) на каждом ядре */
    int  cnt[SMP_MAX_CPUS];
    int  cand[SMP_MAX_CPUS];          /* индекс задачи-кандидата */
    u32  cand_idle[SMP_MAX_CPUS];     /* её «возраст сна» */
    for (int c = 0; c < online; c++) { cnt[c] = 0; cand[c] = -1; cand_idle[c] = 0; }
    for (int i = 1; i < MAX_TASKS; i++) {
        task_t *tk = &tasks[i];
        if (!tk->used || tk->finished || tk->migrating) continue;
        int c = tk->cpu;
        if (c < 0 || c >= online) continue;
        cnt[c]++;
        if (tk->waiting && !tk->on_cpu && !tk->holds_klock &&
            !tk->sandbox && !tk->system) {
            u32 idle = ticks - tk->last_active_tick;
            if (cand[c] < 0 || idle > cand_idle[c]) {
                cand[c] = i;
                cand_idle[c] = idle;
            }
        }
    }

    int heavy = 0, light = 0;
    for (int c = 1; c < online; c++) {
        if (cnt[c] > cnt[heavy]) heavy = c;
        if (cnt[c] < cnt[light]) light = c;
    }
    if (heavy == light || cnt[heavy] - cnt[light] < 2) return;
    if (cand[heavy] < 0) return;      /* нечего переносить */

    int t = cand[heavy];
    int old = tasks[t].cpu;
    tasks[t].cpu = light;
    {
        extern void serial_puts(const char *s);
        /* Буфер 160: кириллица UTF-8 — при меньшем хвост резался. */
        char b[160];
        snprintf(b, sizeof(b),
                 "[smp] балансировка: задача #%d '%s' ядро %d -> %d "
                 "(спала %u мс; на ядре %d было %d задач, на %d — %d)\n",
                 t, tasks[t].name, old, light, cand_idle[heavy],
                 heavy, cnt[heavy], light, cnt[light]);
        serial_puts(b);
    }
}

int task_watchdog_irq(u32 timeout_ticks)
{
    int killed = 0;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) continue;
        /* Системные задачи (ramfs-сервер) ватчдог НЕ убивает: их гибель
         * блокирует файловые операции навсегда. Они почти всегда спят
         * (waiting), а активными бывают microseconds при копировании. */
        if (tasks[i].system) continue;
        /* FIX (многопоточный WM): спящая задача (waiting) — это НЕ
         * зависание: она ждёт события. Иначе ватчдог убивал бы каждое
         * простаивающее окно через 5 секунд. */
        if (tasks[i].waiting) continue;
        /* Задача в ожидании блокировки (s_lock) — тоже НЕ зависание:
         * пока держатель жив, ждущий честно спит в hlt. Раньше ватчдог
         * убивал такие задачи через 5 с — и при 20-секундном зависании
         * держателя выкашивал ВСЕ окна до отбора блокировки. */
        if (tasks[i].lock_wait) continue;

        u32 idle = ticks - tasks[i].last_active_tick;
        u32 limit = tasks[i].watchdog_timeout ? tasks[i].watchdog_timeout
                                              : timeout_ticks;
        if (limit == 0) continue;

        /* СЕССИЯ 75: МИГРАЦИЯ голодающей AP-задачи на BSP. Задача на
         * AP, не получавшая CPU > 300 мс (замок прочно у BSP либо AP
         * перегружен), переезжает на BSP — fair-play и защита от
         * ватчдога.
         * СЕССИЯ 78 [MIG-FIX]: флаг migrating здесь НЕ ставится. Он
         * означает «контекст ещё не сохранён AP-ядром», но мигрируем мы
         * ТОЛЬКО задачи с on_cpu==0 — их кадр уже сохранён (esp валиден),
         * и ни одно ядро их не исполняет. С migrating=1 такую задачу
         * пропускали ОБА планировщика и никто не снимал флаг (его чистит
         * только ветка сохранения кадра cur в task_ap_schedule) — задача
         * НАВСЕГДА выпадала из планирования (лог: «запуски JS висят»).
         * Гонка «BSP ставит cpu=0 / AP подхватывает задачу в этот же
         * тик» самозалечивается: AP исполняет её один тик, при следующем
         * сохранении кадра on_cpu сбрасывается, BSP подхватывает. */
        if (tasks[i].cpu > 0 && !tasks[i].on_cpu && !tasks[i].migrating &&
            idle > 300) {
            int old_core = tasks[i].cpu;
            tasks[i].cpu = 0;
            {
                extern void serial_puts(const char *s);
                /* ФИКС буфера: b[80] МАЛО (кириллица UTF-8 ×2 байта —
                 * хвост «мс)\n» резался, две миграции подряд выглядели
                 * как обрыв посреди строки). + контекст: состояние klock
                 * и пульс kmain на момент миграции — видно, жил ли kmain. */
                char b[160];
                snprintf(b, sizeof(b),
                         "[smp] миграция: задача #%d '%s' AP%d -> BSP "
                         "(голода %u мс; klock=%d kmain_loops=%u)\n",
                         i, tasks[i].name, old_core, idle,
                         smp_klock, g_kmain_loops);
                serial_puts(b);
            }
            continue;
        }

        /* [KLOCK-HANG-DETECT] (требование SMP-rework: «klock застрял
         * >2 c => panic+halt»): держатель замка на AP (on_cpu=1), чьё
         * ядро не планировалось >2 c, — ядро зависло в cli-секции ПОД
         * ЗАМКОМ (LAPIC-таймер не вытесняет при IF=0). Замок не вернётся
         * никогда: система сломана — честная паника с диагнозом, а НЕ
         * отбор (отбор открывал бы окно параллельного kernel-кода —
         * п.1 разбора). Ждущий мог и не наступить (цикл kmain ходит
         * БЕЗ klock — [KMAIN-NO-KLOCK]), поэтому детектирует ватчдог.
         * Ложных срабатываний нет: легитимные cli-секции — миллисекунды
         * (KLOCK_STALE_US), а BSP-держатель обновляет last_active каждым
         * тиком (on_cpu=1 — только замороженное AP-ядро). */
        if (tasks[i].holds_klock && tasks[i].on_cpu && idle > 2000) {
            char b[144];
            snprintf(b, sizeof(b),
                     "[klock] FATAL: держатель %d '%s' завис на AP "
                     "с замком >%u мс — kernel panic\n",
                     i, tasks[i].name, idle);
            serial_puts(b);
            snprintf(b, sizeof(b),
                     "  kmain: loops=%u phase=%u ticks=%u klock=%d\n",
                     g_kmain_loops, g_kmain_phase, (unsigned)ticks,
                     smp_klock);
            serial_puts(b);
            task_lock_quiet_set();    /* [TL-QUIET]: AP-спины замолчат */
            serial_puts("[klock] FATAL: klock stuck >2s — kernel panic\n");
            for (;;) __asm__ __volatile__("cli; hlt");
        }

        if (idle > limit) {
            /* диагностика в serial: КТО убит (имя + возраст) */
            {
                extern void serial_puts(const char *s);
                char b[64];
                snprintf(b, sizeof(b), "[watchdog] kill #%d '%s' idle=%u\n",
                         i, tasks[i].name, idle);
                serial_puts(b);
            }
            tasks[i].finished = 1;
            if (n_tasks > 0) n_tasks--;
            /* СЕССИЯ 78 [KLOCK-REL]: убитая задача могла владеть ядровым
             * замком. Если она НЕ исполняется на AP прямо сейчас — замок
             * ничей навсегда (флаг передачи снять некому): освобождаем
             * немедленно, иначе ждущие вянут до отбора [KLOCK-STALE]. */
            if (tasks[i].holds_klock && !tasks[i].on_cpu) {
                tasks[i].holds_klock = 0;
                serial_puts("[watchdog] замок убитой задачи освобождён\n");
                smp_pic_restore();
                smp_klock_unlock();
            }
            killed++;
            /* Стек НЕ трогаем: tasks[i].stack освобождается в task_spawn() */
        }
    }

    /* [CORE-BALANCE]: один перенос за проход ватчдога (~0.5 с) —
     * перекос сглаживается за секунды, без шторма миграций. */
    if (smp_tasks_enabled())
        task_rebalance();

    return killed;
}

/* Публичная версия — с защитой cli/sti (FIX [T3c]: раньше меняла
 * таблицу задач и звала free() без запрета прерываний — гонка с IRQ0
 * и порча кучи). */
int task_watchdog(u32 timeout_ticks)
{
    /* [T3c] (перестроено): вместо cli — task_lock: IRQ0-версия
     * (task_watchdog_irq) теперь предполагает, что вызывающий уже
     * держит его (иначе гонка с AP-планировщиком, п.4 разбора). */
    task_lock_acq();
    int killed = task_watchdog_irq(timeout_ticks);
    task_lock_rel();
    return killed;
}

/* СЕССИЯ 59: проверка канареек стеков (зовётся раз в секунду из
 * главного цикла). Переполнение стека задачи — единственный известный
 * механизм порчи кучи «заголовок соседнего блока» (сессии 13 и 59);
 * канарейка бьётся РАНЬШЕ заголовка и называет виновника. */
void task_check_stack_canaries(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].canary != 1 || !tasks[i].stack) continue;
        u32 c0 = ((u32 *)tasks[i].stack)[0];
        u32 c1 = ((u32 *)tasks[i].stack)[1];
        if (c0 == TASK_STACK_CANARY0 && c1 == TASK_STACK_CANARY1) continue;
        tasks[i].canary = 2;              /* доложить ОДИН раз */
        extern void serial_puts(const char *s);
        char b[96];
        snprintf(b, sizeof(b),
                 "[task] СТЕК ПЕРЕПОЛНЕН: #%d '%s' — кадр ушёл ниже блока "
                 "(портит кучу)\n", i, tasks[i].name);
        serial_puts(b);
    }
}
