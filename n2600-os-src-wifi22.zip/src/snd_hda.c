/* snd_hda.c — драйвер Intel High Definition Audio (сессия 57).
 *
 * Покрывает:
 *   - VMware sound.virtualDev="hdaudio" (режим по умолчанию для новых
 *     гостей; PCI 8086:2668 ICH6-class);
 *   - настоящие контроллеры Intel HDA, включая ноутбучный ALC269VB
 *     (Realtek codec на Intel NM10, PCI 8086:27D8 на N2600).
 *
 * Устройство ищется по классу 0x0403xx (Multimedia/Audio/HD-Audio) или
 * по известным PCI-ID. Кодек управляется через IMMEDIATE-интерфейс
 * (ICW/IRR/ICIS — без CORB/RIRB-колец, надёжнее в bring-up).
 *
 * ALC269VB: DAC NID 0x02 -> пин 0x14 (выход/динамик, EAPD обязателен).
 * Формат: 16-bit stereo 48 kHz (поток 1). Воспроизведение — кольцевой
 * BDL из 2 буферов, без прерываний (длительность — по PIT).
 *
 * Сессия 86 [HDA-RW]: карта регистров СМЕШАННОЙ разрядности — WAKEEN
 * (16 бит @0x0C) и STATESTS (16 бит @0x0E) — соседи в одном dword.
 * Прежнее 32-битное «чтение STATESTS» с маской 0x7FFF возвращало
 * WAKEEN (=0): на реальном NM10 кодек считался неответившим, звук был
 * «не инициализирован». Все 16/8-битные регистры читаются/пишутся
 * доступом точной разрядности (hd_rd16/hd_wr16/hd_wr8).
 *
 * Сессия 89 [HDA-CAD] «кодек мёртв» на реальном NM10 (STATESTS=3, а ответа
 * на vendor-запрос нет) — ТРИ причины, все устранены:
 *
 *   1) НЕ ТЕ node: vendor-запрос шёл на NID 1 (AFG). По спецификации HDA
 *      Vendor ID (глагол 0xF00) — параметр КОРНЕВОГО узла NID 0; реальный
 *      кодек (ALC269VB) на NID 1 молчит (эмуляторы VMware/86Box отвечали
 *      на любой NID — потому в них работало). Теперь probe идёт на NID 0,
 *      NID 1 — только как запас (для эмуляторов).
 *
 *   2) НЕ ТЕ адреса: STATESTS=3 — биты кодеков 0 И 1; прежде выбирался
 *      всегда CAD 0. Теперь — матрица по всем CAD из маски STATESTS.
 *
 *   3) ОДИН канал команды: прежде только IMMEDIATE-интерфейс (ICW/IRR).
 *      Теперь, еслиImmediate молчит, тот же глагол посылается через
 *      CORB/RIRB (основной механизм Linux/FreeBSD: кольцо команд + кольцо
 *      ответов в RAM). Живым считается первый CAD, ответивший по любому
 *      пути; дальше вся конфигурация идёт тем же путём и адресом.
 *
 *   Дополнительно: ICS (0x68) — 16-битный регистр, доступ точной
 *   разрядности; в лог добавлена длительность инициализации.
 *
 * Сессия 88 [HDA-LOG] «инициализация звука была очень долгой, но похоже
 * звука нет (или громкость на нуле)» — две причины, обе устранены:
 *
 *   1) ГРОМКОСТЬ НА НУЛЕ — ПРЯМАЯ: «unmute»-глаголы 0x3 с payload
 *      0x2000/0x4000 писали байт усиления 0x00 — а это МИНИМАЛЬНОЕ
 *      усиление выходного усилителя (громкость буквально на нуле),
 *      причём без бита Output (0x8000) и для «правого» — с битом Input
 *      (0x4000) вместо Right (0x1000). Теперь: читаются Amp Cap
 *      (глагол 0xF00/0x12), усиление ставится ~75% шкалы, оба канала
 *      с правильными битами Output|Left/Right; виджеты (DAC/пины)
 *      явно переводятся в D0.
 *
 *   2) «ОЧЕНЬ ДОЛГАЯ» ИНИЦИАЛИЗАЦИЯ: таймаут ожидания ответа на глагол
 *      был ~100 000 итераций (~0.15-0.2 с) — мёртвый/молчащий кодек
 *      давал ~25 глаголов × 0.2 с = 4-5 с, после чего snd_hda_init
 *      ВСЁ РАВНО возвращал успех. Теперь таймаут ~8 мс, глаголы
 *      прекращаются при подряд идущих провалах, vendor-запрос обязателен
 *      (нет ответа -> init=0, честное «кодек не ответил»), холодный
 *      повтор CRST сокращён с 1 с до 0.3 с. Худший случай < 1 с.
 *
 *   3) [HDA-LOG] строки драйвера печатались ТОЛЬКО в serial (serial_puts)
 *      и не попадали в klog/dmesg — в загрузочном логе блок звука выглядел
 *      пустым («sound: probe...» и сразу «task_init...»). Все строки
 *      идут в klog тоже (snd_log), как у wifi/sgx545.
 *
 * Сессия 90 [HDA-REAL] «кодек мёртв» на реальном NM10 (STATESTS=3, оба
 * пути глаголов молчат) — найдено сверкой с Linux (hda_intel.c,
 * hdac_controller.c) и QEMU (intel-hda.c / intel-hda-defs.h), ЧЕТЫРЕ
 * причины, все устранены:
 *
 *   1) ФАТАЛЬНО: CORB DMA не запускался — НЕ ТОТ БИТ. Запуск DMA кольца
 *      команд — CORBCTL бит 1 (CORBRUN); бит 0 — CMEIE (разрешение IRQ
 *      ошибки памяти). Прежде ставили бит 0: DMA не работал ни на одном
 *      глаголе, а проверка «CORBCTL & 1» ложно проходила (читали свой же
 *      CMEIE). Эталон: QEMU intel-hda-defs.h ICH6_CORBCTL_RUN=(1<<1),
 *      ICH6_CORBCTL_CMEIE=(1<<0); Linux пишет CORBCTL=RUN. RIRBCTL=0x02
 *      у нас был верный (бит 1 = RIRB DMA enable).
 *
 *   2) ФАТАЛЬНО: IMMEDIATE-команда физически не отправлялась. По
 *      спецификации HDA после записи глагола в ICW софт ОБЯЗАН записать
 *      1 в бит 0 ICIS (ICB, Immediate Command Busy) — «курок» команды:
 *      контроллер выдаёт глагол в линк, сам снимает ICB и выставляет IRV
 *      (ответ в IRR). Прежде ICB не писался — на реальном ICH7 команда
 *      не уходила никогда (QEMU: intel_hda_set_ics -> intel_hda_corb_run
 *      шлёт ICW только при ICS_BUSY; VMware/86Box выполняют команду
 *      прямо по записи в ICW — потому «в эмуляторах работало»).
 *      IICI (бит 2) по спецификации — разрешение прерывания, не статус:
 *      реальный индикатор «кодек не ответил» — таймаут без IRV.
 *      ICIS переводится на 8-битный доступ (биты 0-2 в байте 0; байт
 *      0x69 не задевается; QEMU intel-hda mmio min_access_size=1).
 *
 *   3) ЛАТЕНТНО: CAD ответившего кодека в RIRB resp_ex — БИТЫ 3:0
 *      (QEMU: ex = unsol(1<<4) | cad; Linux unsol = бит 0x10). Прежде
 *      читались биты 23:20 (зарезервированы, всегда 0): при CAD=0
 *      «совпадало», ответ реального кодека CAD1 был бы отвергнут.
 *      Вдобавок g_cad в discovery теперь выставляется ДО пробы каждого
 *      CAD (CORB-фильтр знает, чей ответ ждём).
 *
 *   4) ЛАТЕНТНО: amp_caps/amp_gain_out шлют на захардкоженный CAD 0 —
 *      заменено на g_cad (иначе при кодеке на CAD1 настройка усиления
 *      ушла бы не тому кодеку).
 *
 *   Дополнительно: размеры колец пишутся ЯВНО (CORBSZ/RIRBSZ = 0x02 =
 *   256 записей, как Linux snd_hdac_bus_init_cmd_io); барьер памяти
 *   между записью глагола в CORB и обновлением CORBWP. Последовательность
 *   сброса CORBRP (0x8000 -> ждать бита 15 -> 0 -> ждать очистки)
 *   СОХРАНЕНА как была: для ICH7/NM10 (БЕЗ флага CORBRP_SELF_CLEAR —
 *   в Linux тот есть только у Nvidia/C-Media) это в точности
 *   azx_clear_corbrp() эталона.
 */
#include "types.h"
#include "pci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sound.h"

extern void serial_puts(const char *s);
extern void klog_puts(const char *s);

/* [HDA-HWVOL] forward: определяются ниже (блок мастер-громкости),
 * используются уже в snd_hda_init (заполнение из амп-капсов DAC 0x02) */
static u32 g_hwvol_nid;
static u32 g_hwvol_nsteps;

/* [HDA-LOG] строка и в serial, и в klog (dmesg) — как у wifi/sgx545 */
static void snd_log(const char *s)
{
    serial_puts(s);
    serial_puts("\n");
    klog_puts(s);
}

static void snd_logf(const char *fmt, ...)
{
    char b[128];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(b, sizeof(b), fmt, ap);
    __builtin_va_end(ap);
    snd_log(b);
}

/* ---------- регистры контроллера (MMIO BAR0) ---------- */
#define HDA_GCTL    0x08
#define HDA_WAKEEN  0x0c
#define HDA_STATESTS 0x0e
#define HDA_INTCTL  0x20
#define HDA_CORBCTL 0x4c
#define HDA_ICW     0x60
#define HDA_IRR     0x64
#define HDA_ICIS    0x68     /* bit0 ICB busy, bit1 IRV valid */

/* выходной поток 0 (SDO0): база 0x100, шаг 0x20.
 * [HDA-SDFIX] Прежняя база 0x120 — это SDO1 (SDI0=0x80 + n*0x20:
 * SDO0=0x100, SDO1=0x120, ... SDO3=0x160; QEMU intel-hda.c ST_REG),
 * а INTCTL бит 4 включает SDO0 — тег и поток не совпадали.
 *
 * [HDA-SDFIX] ОФСЕТЫ внутри дескриптора (HDA spec 1.0a / QEMU
 * intel-hda-defs.h): LPIB=0x04, CBL=0x08, LVI=0x0c, FIFOW=0x0e(RO),
 * FIFOS=0x10(RO), FMT=0x12, BDLPL=0x18, BDLPU=0x1c. Прежде LPIB=0x08,
 * CBL=0x0c, LVI=0x0e — ВСЁ СОДВИНУТО НА 4: настоящий CBL не
 * программировался вовсе (остался 0 -> контроллер не запускал DMA,
 * LPIB стоял), «CBL» в логе был чтением LVI|FIFOW, а hd_wr32 на
 * невыровненные 0x0e/0x12 молча округлялся ВНИЗ (mmio[off>>2]):
 * LVI-запись (1) уезжала в настоящий LVI (потому в логе
 * CBL=262145=0x40001 = LVI(1) | FIFOW(4)<<16), FMT-запись 0x11
 * округлялась на +0x10 и в FMT попадали НУЛИ (48кГц, 8 бит, моно!). */
#define HDA_SD0     0x100
#define SD_CTL      0x00     /* bit0 SRST, bit1 RUN, bits 23:20 STRM */
#define SD_STS      0x03     /* байт: bit2 BCIS, bit3 FIFOE, bit4 DESE (W1C), bit5 FIFORDY */
#define SD_LPIB     0x04
#define SD_CBL      0x08
#define SD_LVI      0x0c     /* 16 бит! */
#define SD_FMT      0x12     /* 16 бит! */
#define SD_BDLP     0x18
#define SD_BDLU     0x1c

#define HDA_FMT_48K_16_ST 0x0011u   /* 48kHz base, mult1/div1, 16bit, 2ch */

/* [HDA-RATE] (полевой лог 14: файл 44100 играл в 48-кГц поток —
 * ресэмплер 44.1→48 был, но скорость/высота на слух «чуть быстрее»;
 * нативный 44.1-формат потока снимает вопрос целиком). Формат SDxFMT
 * из частоты: биты [2:0]=001 (16 бит), [6:4]=001 (2 канала), bit14 =
 * база (0 = 48к семейство, 1 = 44.1к), [10:8] = mult-1, [13:11] = div-1
 * [Linux hda_codec.h: AC_FMT_BASE_SHIFT 14, AC_FMT_MULT_SHIFT 8,
 * AC_FMT_DIV_SHIFT 11; 44100 16-бит стерео = 0x4011]. 0 = не
 * выражается (div ≤ 4, mult ≤ 4) — вызывающий откатывается на 48к
 * с программным ресэмплом. */
static u16 hda_fmt_for_rate(u32 rate)
{
    switch (rate) {
        case 44100:  return 0x4011u;
        case 48000:  return 0x0011u;
        case 88200:  return 0x4511u;
        case 96000:  return 0x0411u;
        case 176400: return 0x4311u;
        case 192000: return 0x0311u;
        case 32000:  return 0x1111u;   /* 48к * 2/3 */
        case 24000:  return 0x0811u;   /* 48к / 2   */
        case 22050:  return 0x4811u;   /* 44.1к / 2 */
        case 16000:  return 0x1011u;   /* 48к / 3   */
        case 12000:  return 0x1811u;   /* 48к / 4   */
        case 11025:  return 0x5811u;   /* 44.1к / 4 */
        default:     return 0;
    }
}

/* [HDA-SDFIX] Сброс выходного дескриптора по Linux azx_stream_reset /
 * QEMU (SRST=1 -> QEMU и железо держат бит взведённым, RUN и все
 * регистры потока сброшены; SRST=0 -> рабочий режим). ПОСЛЕ сброса
 * CBL/LVI/FMT/BDL обязаны быть перепрограммированы заново.
 * Байтовые доступы к +0x00 — точные, обходим невыровненный hd_wr. */
static void hd_delay(u32 us);   /* [HDA-SDFIX] fwd: определён ниже */
static void hd_wr8(u32 off, u8 v);   /* [HDA-SDFIX] fwd: точные байтовые */
static u8   hd_rd8(u32 off);         /* доступы к CTL/STS до их опред. */

static void hda_sd_reset(u32 sd)
{
    int t;
    hd_wr8(sd + SD_CTL, hd_rd8(sd + SD_CTL) & ~2u);      /* RUN=0 */
    for (t = 0; t < 1000 && (hd_rd8(sd + SD_CTL) & 2u); t++) hd_delay(1);
    hd_wr8(sd + SD_CTL, hd_rd8(sd + SD_CTL) | 1u);       /* SRST=1 */
    for (t = 0; t < 1000 && !(hd_rd8(sd + SD_CTL) & 1u); t++) hd_delay(1);
    hd_wr8(sd + SD_CTL, hd_rd8(sd + SD_CTL) & ~1u);      /* SRST=0 */
    for (t = 0; t < 1000 && (hd_rd8(sd + SD_CTL) & 1u); t++) hd_delay(1);
    hd_wr8(sd + SD_STS, 0x1Cu);                          /* BCIS|FIFOE|DESE (W1C) */
}

static struct {
    volatile u32 *mmio;
    int ok;
    int bus, dev, fn;      /* [HDA-PM]: расположение контроллера на PCI —
                            * нужно для перевода D3hot -> D0 в init */
    char name[40];
} g_hda;

/* [HDA-ID] резервный критерий поиска: часть плат прошивка выставляет
 * класс НЕ 0x0403 (или вообще не мультимедиа) — тогда ищем по
 * известным PCI-ID Intel HDA-контроллеров. Список покрывает ICH6..Alder
 * Lake; на N2600 целевой контроллер — 8086:27D8 (ALC269VB). */
static int hda_is_known_intel(u16 did)
{
    switch (did) {
    case 0x2668:   /* ICH6 */
    case 0x27D8:   /* ICH7 — Intel NM10 / N2600 */
    case 0x27DD:   /* ICH7 */
    case 0x284B:   /* ICH8 */
    case 0x293E:   /* ICH9 */
    case 0x293F:   /* ICH9 */
    case 0x3A3E:   /* ICH10 */
    case 0x3A6E:   /* ICH10 */
    case 0x1C20:   /* 6 Series PCH (Cougar Point) */
    case 0x1D20:   /* C600/X79 */
    case 0x1E20:   /* 7 Series PCH (Panther Point) */
    case 0x8C20:   /* Lynx Point */
    case 0x9C20:   /* Lynx Point LP */
    case 0x9D70:   /* Sunrise Point-LP */
    case 0xA170:   /* Sunrise Point-H */
    case 0xA348:   /* Cannon Lake */
    case 0x9DC8:   /* Comet Lake */
    case 0xA0C8:   /* Comet Lake LP */
    case 0x43C8:   /* Tiger Lake */
    case 0x51C8:   /* Alder Lake-P */
        return 1;
    }
    return 0;
}

/* [HDA-ID] единая точка «приёма» контроллера: BAR0/MMIO/командный
 * регистр/лог. Общая для обоих критериев (класс и известный ID). */
static int hda_adopt(int bus, int dev, int fn, u16 vid, u16 did)
{
    u32 bar0 = pci_read32(bus, dev, fn, 0x10);
    if (bar0 & 1) return 0;               /* нужен MMIO */
    u32 mmio = bar0 & 0xFFFFFFF0u;
    if (!mmio || mmio < 0x10000) return 0;
    u16 cmd = pci_read16(bus, dev, fn, 0x04);
    pci_write16(bus, dev, fn, 0x04, (u16)(cmd | 0x6)); /* MEM+BME */
    g_hda.mmio = (volatile u32 *)(unsigned long)mmio;
    g_hda.ok = 1;
    g_hda.bus = bus; g_hda.dev = dev; g_hda.fn = fn;
    snprintf(g_hda.name, sizeof(g_hda.name),
             "Intel HDA (%04x:%04x)", vid, did);
    snd_logf("[hda] %04x:%04x mmio=%x @ %02x:%02x.%d",
             vid, did, mmio, bus, dev, fn);
    return 1;
}

/* [HDA-DIAG] дамп конфигурационного пространства 00:1b.* — куда прошивка
 * штатно ставит HDA-контроллер на реальном железе. По дампу видно:
 * аудио отключено в BIOS (функции пусты), класс нестандартный,
 * BAR0 не назначен, память/мастер выключены (cmd) и т.п. */
static void hda_diag_dump_001b(void)
{
    char b[112];
    snd_log("[hda] DIAG: HDA не найден — дамп 00:1b.* :");
    for (int fn = 0; fn < 8; fn++) {
        u32 id = pci_read32(0, 0x1B, fn, 0);
        u16 vid = (u16)(id & 0xFFFF);
        if (vid == 0x0000 || vid == 0xFFFF) continue;   /* функция пуста */
        u32 cc  = pci_read32(0, 0x1B, fn, 0x08);
        u16 cmd = pci_read16(0, 0x1B, fn, 0x04);
        u32 bar0 = pci_read32(0, 0x1B, fn, 0x10);
        snprintf(b, sizeof(b),
                 "[hda] DIAG 00:1b.%d: %04x:%04x класс=%08x cmd=%04x BAR0=%08x",
                 fn, vid, (u16)(id >> 16), cc, cmd, bar0);
        snd_log(b);
    }
}

static inline u32 hd_rd(u32 off) { return g_hda.mmio[off >> 2]; }
static inline void hd_wr(u32 off, u32 v) { g_hda.mmio[off >> 2] = v; }

/* [HDA-RW] 16- и 8-битные доступы: карта регистров HDA — СМЕШАННОЙ
 * разрядности (WAKEEN/STATESTS — 16-битные соседи @0x0C/0x0E; SD_STS —
 * 8-битный байт @+0x03 внутри 32-битного SDnCTL). 32-битное чтение
 * dword'а @0x0C содержит WAKEEN в МЛАДШИХ битах и STATESTS в СТАРШИХ —
 * прежнее «hd_rd(STATESTS) & 0x7FFF» читало WAKEEN (всегда 0) и НИКОГДА
 * не видело биты обнаруженных кодеков -> на реальном железе (NM10 /
 * ALC269VB) init всегда падал с «кодеки не ответили». */
static inline u16 hd_rd16(u32 off) { return ((volatile u16 *)g_hda.mmio)[off >> 1]; }
static inline void hd_wr16(u32 off, u16 v) { ((volatile u16 *)g_hda.mmio)[off >> 1] = v; }
static inline void hd_wr8(u32 off, u8 v) { ((volatile u8 *)g_hda.mmio)[off] = v; }
static inline u8  hd_rd8(u32 off)  { return ((volatile u8 *)g_hda.mmio)[off]; }

static void hd_delay(u32 us)
{
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, us)) { }
}

/* ---------- команды кодеку: IMMEDIATE + CORB/RIRB (сессия 89) ---------- */
#define VERB(cad, nid, verb, pay) \
    ((((u32)(cad)) << 28) | (((u32)(nid)) << 20) | \
     (((u32)(verb)) << 8) | ((u32)(pay)))

/* [HDA-VERB16] 4-БИТНЫЕ глаголы с 16-битным payload: Set Converter
 * Format (0x2), Set/Get Amp Gain/Mute (0x3/0xB). Прежде они посылались
 * через VERB() (verb<<8): SetAmp 0x3 с payload 0xA000|.. собирался в
 * 0xA3xx — кодек декодировал биты [19:16]=0xA как GET Converter
 * Format, т.е. ВСЕ записи усиления/unmute были на деле чтениями;
 * SetConverterFormat 0x2|fmt собирался в 0x211 — неопределённый
 * глагол (no-op), формат DAC оставался сбросовым (44.1к/8бит/моно).
 * В VMware это было незаметно (кодек эмулятора не гейтится mute'ами). */
#define VERB16(cad, nid, verb4, pay16) \
    ((((u32)(cad)) << 28) | (((u32)(nid)) << 20) | \
     (((u32)(verb4) & 0xFu) << 16) | ((u32)(pay16) & 0xFFFFu))

/* [HDA-FAST] ответ на глагол по спецификации приходит за кадры линка
 * (~20-60 мкс); пауза на переходы питания покрывается флагом ICB.
 * Таймаут 8 мс: живой кодек успевает всегда, мёртвый не съедает
 * секунды (прежде — ~0.2 с на глагол). */
#define HDA_VERB_TIMEOUT_ITER 5000

/* выбранный адрес кодека и путь команды (заполняет probe) */
static u32  g_cad      = 0;
static int  g_use_corb = 0;

/* --- путь 1: IMMEDIATE (ICW/IRR/ICS) --- */
/* [HDA-REAL] сессия 90: ICB (бит 0 ICIS) — «курок» команды. По
 * спецификации HDA софт обязан записать 1 в ICB ПОСЛЕ записи глагола в
 * ICW — без этого реальный контроллер не выдаёт команду в линк (QEMU
 * шлёт ICW только при ICS_BUSY, VMware — прямо по записи в ICW, потому
 * в эмуляторах прежний код «работал»). IICI (бит 2) — разрешение
 * прерывания, а не статус: индикатор молчания кодека — таймаут без IRV.
 * ICIS — 8-битный доступ (все нужные биты в байте 0; 0x69 не задеваем). */
static int hda_verb_imm(u32 v, u32 *resp)
{
    /* ждать ICB=0 */
    for (int t = 0; t < 10000; t++)
        if (!(hd_rd8(HDA_ICIS) & 1u)) break;
    hd_wr8(HDA_ICIS, 2u | 4u);    /* W1C: сброс IRV и IICI */
    hd_wr(HDA_ICW, v);
    hd_wr8(HDA_ICIS, 1u);         /* ГЛАВНОЕ: ICB=1 — команда уходит в линк */

    for (int t = 0; t < HDA_VERB_TIMEOUT_ITER; t++) {
        u32 st = hd_rd8(HDA_ICIS);
        if (st & 2u) {                        /* IRV: ответ готов */
            if (resp) *resp = hd_rd(HDA_IRR);
            hd_wr8(HDA_ICIS, 2u);             /* съесть ответ (W1C) */
            return 1;
        }
        if (st & 4u) {                        /* страховка: IICI (не статус,
                                               * но читаем — вдруг включён) */
            hd_wr8(HDA_ICIS, 4u);
            return 0;
        }
        hd_delay(1);
    }
    return 0;                                 /* кодек не ответил */
}

/* --- путь 2: CORB/RIRB (кольца в RAM, как у Linux/FreeBSD) --- */
#define HDA_CORB_LBASE 0x40
#define HDA_CORB_UBASE 0x44
#define HDA_CORBWP     0x48
#define HDA_CORBRP     0x4A
/* HDA_CORBCTL уже определён выше (0x4C) */
#define HDA_CORBSTS    0x4D
#define HDA_CORBSZ     0x4E
#define HDA_RIRB_LBASE 0x50
#define HDA_RIRB_UBASE 0x54
#define HDA_RIRBWP     0x58
#define HDA_RINTCNT    0x5A
#define HDA_RIRBCTL    0x5C
#define HDA_RIRBSTS    0x5D
#define HDA_RIRBSZ     0x5E
#define HDA_CORB_VERB_TIMEOUT_US 8000

static struct {
    u32 *corb;            /* CORB: 256 x u32 (выравн. 1 КиБ) */
    u32 *rirb;            /* RIRB: 256 x [resp,ex] (выравн. 2 КиБ) */
    u32  size;            /* число записей CORB (2/15/16/256)      */
    u32  wp;              /* теневой CORBWP                        */
    u32  rp;              /* теневой RIRBWP                        */
    int  ready;
} g_corb;

static int hda_corb_init(void)
{
    if (g_corb.ready) return 1;

    /* остановить DMA команд.
     * [HDA-REAL] сессия 90: CORBRUN — БИТ 1 CORBCTL (бит 0 — CMEIE, IRQ
     * ошибки памяти). Прежде останавливали/проверяли бит 0. */
    hd_wr8(HDA_CORBCTL, hd_rd8(HDA_CORBCTL) & ~0x02u);
    for (int t = 0; t < 2000 && (hd_rd8(HDA_CORBCTL) & 0x02u); t++) hd_delay(1);

    /* память: CORB 1 КиБ (align 1 КиБ), RIRB 2 КиБ (align 2 КиБ) */
    u32 *corb = (u32 *)malloc(1024 + 1023);
    u32 *rirb = (u32 *)malloc(2048 + 2047);
    if (!corb || !rirb) { snd_log("[hda] CORB: нет памяти под кольца"); return 0; }
    corb = (u32 *)(((u32)(unsigned long)corb + 1023) & ~1023u);
    rirb = (u32 *)(((u32)(unsigned long)rirb + 2047) & ~2047u);
    memset(corb, 0, 1024);
    memset(rirb, 0, 2048);
    g_corb.corb = corb;
    g_corb.rirb = rirb;

    /* базы (физика == виртуал у ОС) */
    hd_wr(HDA_CORB_LBASE, (u32)(unsigned long)corb);
    hd_wr(HDA_CORB_UBASE, 0);
    hd_wr(HDA_RIRB_LBASE, (u32)(unsigned long)rirb);
    hd_wr(HDA_RIRB_UBASE, 0);

    /* [HDA-REAL] размеры пишем ЯВНО: 0x02 = 256 записей (Linux
     * snd_hdac_bus_init_cmd_io: «set the corb size to 256 entries»).
     * Прежде значение только читалось (0x42 = SizeCap(256)|Size(256)
     * дефолта ICH7) — работало на дефолте, но зависело от него. */
    hd_wr8(HDA_CORBSZ, 0x02u);
    hd_wr8(HDA_RIRBSZ, 0x02u);
    g_corb.size = 256;

    /* сброс указателей CORB.
     * [HDA-REAL] сессия 90: последовательность 0x8000 -> ждать бита 15 ->
     * 0 -> ждать очистки — это В ТОЧНОСТИ azx_clear_corbrp() эталона для
     * контроллеров БЕЗ self-clear (ICH7/NM10; флаг CORBRP_SELF_CLEAR в
     * Linux — только Nvidia/C-Media). НЕ менять на «ждать очистки»: у
     * ICH7 бит сброса сам не очищается. */
    hd_wr16(HDA_CORBRP, 0x8000u);
    for (int t = 0; t < 2000 && !(hd_rd16(HDA_CORBRP) & 0x8000u); t++) hd_delay(1);
    hd_wr16(HDA_CORBRP, 0x0000u);
    for (int t = 0; t < 2000 && (hd_rd16(HDA_CORBRP) & 0x8000u); t++) hd_delay(1);
    hd_wr16(HDA_CORBWP, 0);
    g_corb.wp = 0;

    /* сброс указателя RIRB, счётчик, DMA ответов (без IRQ) */
    hd_wr16(HDA_RIRBWP, 0x8000u);
    hd_wr16(HDA_RIRBWP, 0x0000u);   /* RIRBWP-сброс без ожиданий, как Linux */
    g_corb.rp = 0;
    hd_wr16(HDA_RINTCNT, 1);
    hd_wr8(HDA_RIRBCTL, 0x02u);          /* RIRB DMA enable, INTCTL=0 */
    hd_wr8(HDA_RIRBSTS, 0x05u);          /* сброс статусов (W1C) */
    hd_wr8(HDA_CORBSTS, 0x01u);          /* сброс CORB status (W1C) */

    /* запуск.
     * [HDA-REAL] сессия 90: CORBRUN — БИТ 1 (0x02). Прежде ставили бит 0
     * (CMEIE): DMA не стартовал, а проверка «читаем свой же бит» ложно
     * проходила. Эталон: QEMU ICH6_CORBCTL_RUN=(1<<1), Linux пишет RUN. */
    hd_wr8(HDA_CORBCTL, hd_rd8(HDA_CORBCTL) | 0x02u);
    int run = 0;
    for (int t = 0; t < 2000; t++) {
        if (hd_rd8(HDA_CORBCTL) & 0x02u) { run = 1; break; }
        hd_delay(1);
    }
    if (!run) { snd_log("[hda] CORB: CORBRUN не поднялся"); return 0; }
    g_corb.ready = 1;
    snd_logf("[hda] CORB готов: %u записей, CORB=%08x RIRB=%08x",
             (unsigned)g_corb.size, (unsigned)(unsigned long)corb,
             (unsigned)(unsigned long)rirb);
    return 1;
}

static int hda_verb_corb(u32 v, u32 *resp)
{
    if (!hda_corb_init()) return 0;
    u32 size = g_corb.size;
    u32 next = (g_corb.wp + 1u) % size;

    /* место в кольце: next не должен настигнуть CORBRP */
    u32 dl = timer_poll_deadline();
    while (next == (hd_rd16(HDA_CORBRP) & 0xFFu)) {
        if (timer_poll_expired(dl, HDA_CORB_VERB_TIMEOUT_US)) return 0;
    }
    g_corb.corb[next] = v;               /* глагол в кольцо */
    __sync_synchronize();   /* [HDA-REAL] глагол обязан дойти до RAM до обновления WP */
    hd_wr16(HDA_CORBWP, (u16)(next & 0xFFu));   /* и WP — команда уходит */
    g_corb.wp = next;

    /* ждать новый ответ в RIRB */
    dl = timer_poll_deadline();
    for (;;) {
        u32 nrp = hd_rd16(HDA_RIRBWP) & 0xFFu;
        if (nrp != g_corb.rp) {
            g_corb.rp = nrp;
            u32 ex = g_corb.rirb[nrp * 2u + 1u];
            u32 rs = g_corb.rirb[nrp * 2u + 0u];
            /* [HDA-REAL] сессия 90: CAD ответившего кодека — БИТЫ 3:0
             * resp_ex (QEMU: ex = unsol(1<<4) | cad; Linux unsol = 0x10).
             * Прежде читались биты 23:20 (резерв, всегда 0): ответ кодека
             * CAD1 отвергался бы. */
            u32 rcad = ex & 0xFu;
            if (rcad == g_cad && !(ex & 0x10u)) {   /* наш CAD, не unsolicited */
                if (resp) *resp = rs;
                return 1;
            }
            /* чужой/unsolicited ответ — пропустить, ждать дальше */
        }
        if (timer_poll_expired(dl, HDA_CORB_VERB_TIMEOUT_US)) return 0;
    }
}

/* диспетчер: путь выбирается probe'ом (IMM первым — он дешевле) */
static int hda_verb(u32 v, u32 *resp)
{
    if (g_use_corb) return hda_verb_corb(v, resp);
    return hda_verb_imm(v, resp);
}

/* [HDA-CAD] поиск живого кодека: матрица {CAD из STATESTS} x {IMM, CORB}
 * x {NID 0 (корень — vendor ID по спецификации), NID 1 (запас для
 * эмуляторов)}. Живой ответ: не 0 и не -1.
 * [HDA-REAL] сессия 90: g_cad выставляется ДО пробы каждого CAD —
 * иначе (с исправленной маской resp_ex) CORB-фильтр отвергал бы ответ
 * самого пробуемого кодека при CAD != 0. */
static int hda_codec_discover(u32 mask, u32 *out_cad, u32 *out_resp,
                              const char **out_path)
{
    static const u32 nids[2] = { 0, 1 };
    for (u32 cad = 0; cad < 15; cad++) {
        if (!(mask & (1u << cad))) continue;
        for (int path = 0; path < 2; path++) {
            for (int ni = 0; ni < 2; ni++) {
                u32 r = 0;
                int ok;
                g_cad = cad;    /* фильтр CORB-ответов: ждём ЭТОТ адрес */
                if (path == 0) { g_use_corb = 0; ok = hda_verb_imm(VERB(cad, nids[ni], 0xF00, 0), &r); }
                else           { g_use_corb = 1; ok = hda_verb_corb(VERB(cad, nids[ni], 0xF00, 0), &r); }
                if (ok && r != 0u && r != 0xFFFFFFFFu) {
                    *out_cad  = cad;
                    *out_resp = r;
                    *out_path = path ? "CORB" : "IMM";
                    return 1;
                }
            }
        }
    }
    return 0;
}

/* [HDA-GAIN2] чтение Amp Cap виджета: OUT — Get parameter 0x12,
 * IN — 0x0D (AC_PAR_AMP_IN_CAP; эталон ref_hda_verbs.h:136/141).
 * Прежде IN читался параметром 0x0A = AC_PAR_PCM (частоты!) —
 * капсы входов миксеров были мусором/нулём.
 * РАСКЛАДКА Amp Cap 32-бит (эталон ref_hda_verbs.h:282-294, Linux):
 *   [6:0]  Offset — число шагов ОТ максимума ДО точки 0 дБ;
 *   [14:8] NumSteps — число шагов усиления (всего NumSteps+1 позиц.);
 *   [22:16] StepSize — шаг = (поле+1) * 0.25 дБ;
 *   [31] Mute capable, [30] MIN_MUTE (мин. громкость = mute).
 * Усиление при индексе i: gain = (i - Offset) * шаг (Linux
 * get_ctl_amp_tlv: min_dB = -Offset*шаг; максимум при i = NumSteps).
 * [HDA-REAL] сессия 90: адрес — g_cad, а не захардкоженный 0 (при
 * кодеке на CAD1 весь разбор усиления уходил бы не тому кодеку). */
static u32 hda_amp_caps(u32 nid, int is_output)
{
    u32 r = 0;
    hda_verb(VERB(g_cad, nid, 0xF00, is_output ? 0x12u : 0x0Du), &r);
    return r;
}

/* [HDA-GAIN2] разбор Amp Cap на поля: ofs = 0 дБ точка, nsteps =
 * максимум индекса, шаг в сотых дБ. caps=0x00025757 (ALC269VB, DAC
 * 0x02, полевой лог итерации 10) = ofs 87, шагов 87, шаг 0.75 дБ,
 * mute=0: максимум 0 дБ, пол -65.25 дБ. */
static void hda_amp_decode(u32 caps, u32 *ofs, u32 *nsteps, u32 *step_cdB,
                           u32 *mute)
{
    *ofs       = caps & 0x7Fu;
    *nsteps    = (caps >> 8) & 0x7Fu;
    *step_cdB  = (((caps >> 16) & 0x7Fu) + 1u) * 25u;  /* в 0.01 дБ */
    *mute      = (caps >> 31) & 1u;
}

/* [HDA-GAIN2] unmute выходного усилителя виджета НА МАКСИМУМЕ усиления.
 * Глагол 0x3 — 4-БИТНЫЙ с 16-битным payload (VERB16!). Payload:
 * bit15 Output, bit14 Input, bit13 Left, bit12 Right, [11:8] индекс
 * входа (для input-ампов), bit7 mute, [6:0] индекс усиления.
 *
 * [HDA-GAIN2] ПРИЧИНА «очень тихого» звука (полевой лог итерации 10,
 * диагноз пользователя — точный): NumSteps читался из caps[23:16] —
 * а там StepSize. Для NID 0x02 (капсы 0x00025757) «шагов» = 2, писался
 * индекс 2 из 87: gain(2) = (2 - 87) * 0.75 = -63.75 дБ — тракт
 * придавлен к полу. Правильно: NumSteps = caps[14:8] = 87 → индекс 87
 * = точка 0 дБ (у DAC-ампа ALC269 ofs == NumSteps, максимум = 0 дБ).
 * Для mute-only ампов (NumSteps=0) — просто unmute на индексе 0.
 * Возвращает payload (для лога). */
static u32 hda_amp_gain_out(u32 nid, u32 caps)
{
    u32 ofs, nsteps, step_cdB, mute;
    u32 val;
    hda_amp_decode(caps, &ofs, &nsteps, &step_cdB, &mute);
    val = (nsteps > 0x7Fu) ? 0x7Fu : nsteps;  /* максимум усиления */
    hda_verb(VERB16(g_cad, nid, 0x3, 0xB000u | val), NULL); /* Out|L|R */
    return 0xB000u | val;
}

/* [HDA-DUALDAC] тип виджета (Get Parameter 0x09, биты 23:20):
 * 1 = Audio Output (DAC), 6 = Pin Complex, 7 = Mixer. */
static u32 hda_widget_type(u32 nid)
{
    u32 r = 0;
    if (!hda_verb(VERB(g_cad, nid, 0xF00, 0x09u), &r)) return 0xFFFFFFFFu;
    return (r >> 20) & 0xFu;
}

/* [HDA-DUALDAC] подключить второй DAC к потоку 1 (формат + тег + D0).
 * ALC269VB: наушники 0x21 <- миксер 0x0d <- DAC 0x03 (а не 0x02!). Без
 * настройки 0x03 конвертер не слушает поток SDO0 и даже размьюченный
 * пин 0x21 молчит — «звук только в колонках» (полевой лог итерации 9). */
static void hda_dac_setup(u32 dac)
{
    hda_verb(VERB16(g_cad, dac, 0x2, HDA_FMT_48K_16_ST), NULL);
    hda_verb(VERB(g_cad, dac, 0x706, 0x10), NULL);   /* stream 1, ch 0 */
    hda_verb(VERB(g_cad, dac, 0x705, 0x00), NULL);   /* D0 */
    (void)hda_amp_gain_out(dac, hda_amp_caps(dac, 1));
    snd_logf("da] DAC %02x подключён к потоку 1 (формат %04x)",
             (unsigned)dac, (unsigned)HDA_FMT_48K_16_ST);
}

/* [HDA-PATH] чтение connection list виджета (Get Connection List Entry
 * 0xF02; длина — Get parameter 0x0E: [6:0] число записей, бит7 —
 * длинный формат). Короткий формат: 4 записи по 8 бит на ответ;
 * длинный: 2 записи по 16 бит. Возвращает число записей (<= maxn). */
static int hda_conn_list(u32 nid, u32 *ents, int maxn)
{
    u32 r = 0;
    if (!hda_verb(VERB(g_cad, nid, 0xF00, 0x0Eu), &r)) return 0;
    int n  = (int)(r & 0x7Fu);
    int lf = (int)((r >> 7) & 1u);
    if (n <= 0) return 0;
    if (n > maxn) n = maxn;
    for (int i = 0; i < n; ) {
        u32 v = 0;
        if (!hda_verb(VERB(g_cad, nid, 0xF02, (u32)i), &v)) break;
        if (lf) {
            ents[i] = v & 0xFFFFu; i++;
            if (i < n) { ents[i] = (v >> 16) & 0xFFFFu; i++; }
        } else {
            for (int k = 0; k < 4 && i < n; k++, i++)
                ents[i] = (v >> (8 * k)) & 0xFFu;
        }
    }
    return n;
}

/* [HDA-PATH] маршрутизация выхода: пин <- DAC напрямую или через
 * миксер. Разбираем connection list пина; выбираем запись с самим DAC,
 * иначе первую запись-виджет, чей собственный список содержит DAC
 * (миксер). Ставим conn select пина (0x701). Для миксера размьючиваем
 * ВХОДНОЙ амп с индексом DAC и выходной амп. Кодировка Set_Amp
 * [hda_verbs.h эталона]: Output=бит15, Input=бит14, Left=13, Right=12,
 * индекс = биты [11:8], mute = бит7, усиление = [6:0]. Именно
 * размьючивание входного ампа миксера (у ALC269 это 0x0C
 * IN_UNMUTE(0) из alc269_init_verbs) прежде ОТСУТСТВОВАЛО: путь
 * DAC 0x02 -> 0x0C -> пин 0x14 оставался замьюченным на входе
 * миксера — на реальном кодеке тишина, в VMware миксер по умолчанию
 * размьючен, поэтому там звук был и без этого. */
static void hda_route_output(u32 dac, u32 pin)
{
    u32 ents[15];
    int n = hda_conn_list(pin, ents, 15);
    if (n <= 0) {
        snd_logf("da] пин %02x: connection list не читается — вход 0",
                 (unsigned)pin);
        hda_verb(VERB(g_cad, pin, 0x701, 0x00), NULL);
        return;
    }
    for (int i = 0; i < n; i++)
        snd_logf("da] пин %02x: conn[%d] = %02x", (unsigned)pin, i,
                 (unsigned)ents[i]);

    int sel = -1, mixer = -1;
    u32 src_dac = dac;   /* [HDA-DUALDAC] чей поток реально питает миксер */
    for (int i = 0; i < n; i++)
        if (ents[i] == dac) { sel = i; mixer = -1; break; }  /* прямой DAC */
    if (sel < 0) {
        for (int i = 0; i < n; i++) {
            u32 m = ents[i];
            if (m == 0 || m == dac) continue;
            u32 ments[15];
            int mn = hda_conn_list(m, ments, 15);
            for (int k = 0; k < mn; k++)
                if (ments[k] == dac) { sel = i; mixer = (int)m; break; }
            if (sel >= 0) break;
            /* [HDA-DUALDAC] миксер питается ДРУГИМ DAC (ALC269VB:
             * 0x21 <- 0x0d <- 0x03) — настраиваем его на тот же поток */
            for (int k = 0; k < mn; k++) {
                u32 alt = ments[k];
                if (alt == 0 || alt == dac) continue;
                if (hda_widget_type(alt) == 1u) {
                    sel = i; mixer = (int)m; src_dac = alt; break;
                }
            }
            if (sel >= 0) break;
        }
    }
    if (sel < 0) sel = 0;                    /* по умолчанию — вход 0 */
    hda_verb(VERB(g_cad, pin, 0x701, (u32)sel), NULL);

    if (mixer >= 0) {
        u32 ments[15];
        int mn = hda_conn_list((u32)mixer, ments, 15);
        int midx = 0;
        for (int k = 0; k < mn; k++)
            if (ments[k] == src_dac) { midx = k; break; }
        if (src_dac != dac) hda_dac_setup(src_dac);
        u32 icaps = hda_amp_caps((u32)mixer, 0);
        /* [HDA-VERB16] Input|Left|Right, вход midx, unmute, усиление —
         * максимум (индекс = NumSteps из caps[14:8]). [HDA-GAIN2] прежде
         * «NumSteps» брали из caps[22:16] (там StepSize), а сами капсы
         * входов читались параметром 0x0A (PCM) — мусор. У Realtek
         * входные ампы миксеров mute-only (NumSteps=0) — пишем индекс 0
         * и бит mute=0; индекс ВХОДА миксера живёт в битах [11:8]. */
        u32 mofs, misteps, mstep, mmute;
        hda_amp_decode(icaps, &mofs, &misteps, &mstep, &mmute);
        hda_verb(VERB16(g_cad, (u32)mixer, 0x3,
                        0x7000u | ((u32)midx << 8) | misteps), NULL);
        u32 ocaps = hda_amp_caps((u32)mixer, 1);
        hda_amp_gain_out((u32)mixer, ocaps);
        snd_logf("da] путь: DAC %02x%s -> %02x (вход %d) -> пин %02x "
                 "(вх-капсы=%08x: ofs %u, шагов %u, шаг %u.%02u дБ, "
                 "гейн=%u)",
                 (unsigned)src_dac, (src_dac != dac) ? " [второй DAC]" : "",
                 (unsigned)mixer, midx, (unsigned)pin,
                 (unsigned)icaps, (unsigned)mofs, (unsigned)misteps,
                 (unsigned)(mstep / 100u), (unsigned)(mstep % 100u),
                 (unsigned)misteps);
    } else {
        snd_logf("da] путь: DAC %02x -> пин %02x напрямую (вход %d)",
                 (unsigned)dac, (unsigned)pin, sel);
    }
}

int snd_hda_probe(void)
{
    g_hda.ok = 0;
    g_hda.bus = g_hda.dev = g_hda.fn = -1;
    /* [HDA-LOG] вход в пробу виден в dmesg — раньше блок звука в логе
     * выглядел пустым (строки шли только в serial) */
    snd_log("[hda] probe: поиск контроллера (класс 0x0403 / PCI-ID Intel)");
    /* проход 1: штатный критерий — класс 0x0403xx */
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid == 0xFFFF) continue;
                u32 cc = pci_read32(bus, dev, fn, 0x08);
                u8 base = (u8)((cc >> 24) & 0xFF);
                u8 sub  = (u8)((cc >> 16) & 0xFF);
                u8 prif = (u8)((cc >> 8) & 0xFF);
                if (base != 0x04 || sub != 0x03 || prif != 0x00) continue;
                if (hda_adopt(bus, dev, fn, vid, did)) return 1;
            }
        }
    }
    /* проход 2 [HDA-ID]: класс от прошивки нестандартный — ищем по
     * известным PCI-ID Intel */
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid != 0x8086 || !hda_is_known_intel(did)) continue;
                if (hda_adopt(bus, dev, fn, vid, did)) {
                    serial_puts("[hda] найден по PCI-ID (класс нестандартный)\n");
                    return 1;
                }
            }
        }
    }
    hda_diag_dump_001b();      /* [HDA-DIAG] */
    return 0;
}

const char *snd_hda_name(void) { return g_hda.name; }

/* Инициализация контроллера и кодека ALC269VB */
int snd_hda_init(void)
{
    if (!g_hda.ok) return 0;
    u32 t0 = timer_poll_deadline();          /* [HDA-CAD] длительность в лог */

    /* [HDA-PM] ГЛАВНАЯ правка для реального железа: на ноутбуках
     * контроллер часто остаётся в D3hot после прошивки — кодеки молчат
     * (STATESTS=0) до перевода в D0. Идём по списку capabilities
     * (CAP_PTR @ 0x34), ищем Power Management (ID 0x01), PMCSR <- D0,
     * ждём 20 мс, восстанавливаем биты MEM+BME командного регистра. */
    if (g_hda.bus >= 0) {
        u8 cap = pci_read8(g_hda.bus, g_hda.dev, g_hda.fn, 0x34);
        int guard = 0;
        while (cap >= 0x40 && guard++ < 16) {
            u32 ch = pci_read32(g_hda.bus, g_hda.dev, g_hda.fn, cap & ~3u);
            u8  cap_id  = (u8)(ch & 0xFF);
            u8  cap_nxt = (u8)((ch >> 8) & 0xFF);
            if (cap_id == 0x01) {                 /* PCI Power Management */
                u16 pmcsr = pci_read16(g_hda.bus, g_hda.dev, g_hda.fn,
                                       cap + 4);
                if ((pmcsr & 3u) != 0) {
                    char b[80];
                    snprintf(b, sizeof(b), "[hda] PM: D%d -> D0",
                             (int)(pmcsr & 3u));
                    snd_log(b);
                }
                pmcsr &= (u16)~3u;                /* power state = D0 */
                pci_write16(g_hda.bus, g_hda.dev, g_hda.fn, cap + 4, pmcsr);
                hd_delay(20000);                  /* 20 мс на выход из D3 */
                u16 cmd = pci_read16(g_hda.bus, g_hda.dev, g_hda.fn, 0x04);
                pci_write16(g_hda.bus, g_hda.dev, g_hda.fn, 0x04,
                            (u16)(cmd | 0x6));    /* MEM+BME */
                break;
            }
            cap = cap_nxt;
        }
    }

    /* CRST: 0 -> 1, пауза, ждать STATESTS */
    hd_wr(HDA_GCTL, 0);
    hd_delay(100);
    hd_wr(HDA_GCTL, hd_rd(HDA_GCTL) | 1u);
    int up = 0;
    for (int t = 0; t < 200; t++) {          /* до ~20 мс */
        if (hd_rd(HDA_GCTL) & 1u) { up = 1; break; }
        hd_delay(100);
    }
    if (!up) {
        snd_log("[hda] CRST не поднялся");
        return 0;
    }
    hd_delay(500);                            /* спецификация: 521 мкс */

    /* [HDA-COLD] ожидание кодека по спецификации — ДВА раунда: на
     * «холодном» железе кодек может проснуться позже первого окна.
     * Раунд 1: до 30 мс; если пусто — ПОЛНЫЙ повторный цикл CRST (0->1)
     * и ожидание до 1 с. Маска STATESTS: 0x0F -> 0x7FFF (15 бит — часть
     * контроллеров держит биты выше 4-го). */
    u32 mask = 0;
    for (int round = 0; round < 2 && !mask; round++) {
        if (round) {
            snd_log("[hda] кодек не ответил — холодный повтор CRST");
            hd_wr(HDA_GCTL, 0);
            hd_delay(100);
            hd_wr(HDA_GCTL, hd_rd(HDA_GCTL) | 1u);
            int up2 = 0;
            for (int t = 0; t < 200; t++) {
                if (hd_rd(HDA_GCTL) & 1u) { up2 = 1; break; }
                hd_delay(100);
            }
            if (!up2) {
                snd_log("[hda] CRST не поднялся (повтор)");
                return 0;
            }
            hd_delay(500);
        }
        for (int t = 0; t < (round ? 3000 : 300); t++) {
            /* [HDA-RW] STATESTS — 16-битный регистр @0x0E: читать СТРОГО
             * словом. dword @0x0C = WAKEEN(младшие)|STATESTS(старшие). */
            mask = (u32)hd_rd16(HDA_STATESTS) & 0x7FFFu;
            if (mask) break;
            hd_delay(100);                       /* 30 мс / 0.3 с [HDA-FAST] */
        }
    }
    if (!mask) {
        snd_logf("[hda] кодеки не ответили (STATESTS=0, WAKEEN=%04x, GCTL=%08x)",
                 (unsigned)hd_rd16(0x0C), hd_rd(HDA_GCTL));
        return 0;
    }
    hd_wr16(HDA_STATESTS, 0x7FFFu);          /* сброс битов wake (W1C, 16 бит) */
    snd_logf("[hda] кодеки: маска %x", (unsigned)mask);

    /* --- поиск живого кодека (сессия 89 [HDA-CAD]) ---
     * [HDA-FAST] vendor-запрос ОБЯЗАТЕЛЕН: живой кодек отвечает всегда;
     * молчание = битый линк/кодек — честный провал вместо 25 глаголов
     * по таймауту и ложного «готов». Матрица: CAD из маски STATESTS ×
     * путь (IMMEDIATE, затем CORB/RIRB) × NID (0 = корень — по
     * спецификации HDA vendor ID живёт ТОЛЬКО в NID 0; NID 1 — запас
     * для эмуляторов VMware/86Box, отвечавших на любой узел). */
    u32 resp = 0, vcad = 0;
    const char *vpath = "";
    if (!hda_codec_discover(mask, &vcad, &resp, &vpath)) {
        snd_log("[hda] кодек не ответил (IMM+CORB, NID0/NID1, все CAD) — кодек мёртв");
        return 0;
    }
    g_cad = vcad;
    g_use_corb = (vpath[0] == 'C');
    snd_logf("[hda] кодек @ CAD%u жив (%s): vendor=0x%08x",
             (unsigned)vcad, vpath, resp);
    hda_verb(VERB(g_cad, 1, 0x705, 0x00), NULL); /* кодек (AFG) в D0 */

    /* [HDA-GAIN] конфигурация выхода: виджеты в D0, усиление по капсам.
    * Путь ALC269VB: DAC 0x02 -> пин 0x14 (динамик); 0x21 — наушники;
    * 0x0F/0x10 — подстраховка нестандартных разводок. */
    static const u16 out_nids[] = { 0x02, 0x14, 0x21, 0x0F, 0x10 };
    for (unsigned i = 0; i < sizeof(out_nids) / sizeof(out_nids[0]); i++) {
        u32 nid = out_nids[i];
        u32 caps = hda_amp_caps(nid, 1);
        u32 wr   = hda_amp_gain_out(nid, caps); /* [HDA-GAIN2] макс усиления */
        u32 aofs, asteps, astep, amute;
        hda_amp_decode(caps, &aofs, &asteps, &astep, &amute);
        /* [HDA-HWVOL]: DAC s shagovym ampom = apparatnyj master-volume */
        if (nid == 0x02 && asteps > 0) {
            g_hwvol_nid    = nid;
            g_hwvol_nsteps = asteps;
        }
        snd_logf("[hda] NID %02x: амп-капсы=%08x (ofs %u, шагов %u, "
                 "шаг %u.%02u дБ, mute %u) SetAmp=%04x",
                 (unsigned)nid, (unsigned)caps,
                 (unsigned)aofs, (unsigned)asteps,
                 (unsigned)(astep / 100u), (unsigned)(astep % 100u),
                 (unsigned)amute, (unsigned)(wr & 0xFFFFu));
    }

    /* DAC 0x02: формат + поток 1 канал 0. [HDA-VERB16] Set Converter
     * Format — глагол 0x2 с 16-битным payload (прежде VERB() собирал
     * 0x211 — неопределённый глагол: формат оставался 0 = 44.1 кГц /
     * 8 бит / моно при линке 48к/16/стерео). Проверяем чтением. */
    {
        u32 fmt_rb = 0, conv_rb = 0;
        hda_verb(VERB16(g_cad, 2, 0x2, HDA_FMT_48K_16_ST), NULL);
        hda_verb(VERB16(g_cad, 2, 0xA, 0), &fmt_rb);      /* Get Conv Format */
        hda_verb(VERB(g_cad, 2, 0x706, 0x10), NULL);      /* stream 1, ch 0 */
        hda_verb(VERB(g_cad, 2, 0xF06, 0), &conv_rb);     /* Get Conv Stream */
        snd_logf("da] DAC 0x02: формат=%04x (ожидал %04x), stream=%02x "
                 "(ожидал 10)%s", (unsigned)(fmt_rb & 0xFFFFu),
                 (unsigned)HDA_FMT_48K_16_ST, (unsigned)(conv_rb & 0xFFu),
                 ((fmt_rb & 0xFFFFu) == HDA_FMT_48K_16_ST &&
                  (conv_rb & 0xFFu) == 0x10u) ? "" : " — НЕ СОВПАЛО!");
    }

    /* [HDA-PINCFG] диагностика: конфигурация пинов (Get Config Default
     * 0xF1C) — по ней видно, какой пин динамик/наушники на этой плате */
    {
        static const u16 pcnids[] = { 0x14, 0x21, 0x0F, 0x10 };
        for (unsigned i = 0; i < sizeof(pcnids) / sizeof(pcnids[0]); i++) {
            u32 pc = 0;
            hda_verb(VERB(g_cad, pcnids[i], 0xF00, 0xF1Cu), &pc);
            snd_logf("da] NID %02x: pin config = %08x",
                     (unsigned)pcnids[i], (unsigned)pc);
        }
    }

    /* [HDA-PATH] маршрутизация по connection list: DAC 0x02 -> пин
     * 0x14 (динамик) / 0x21 (наушники). Прежде conn select жёстко
     * ставил вход 0, а входной амп миксера 0x0C не размьючивался —
     * на реальном кодеке путь был глух. Теперь путь разбирается по
     * списку соединений и размьючивается целиком. */
    hda_route_output(0x02, 0x14);
    hda_route_output(0x02, 0x21);
    hda_verb(VERB(g_cad, 0x14, 0x707, 0x40), NULL);  /* pin: out enable */
    /* [HDA-EAPD2] ПРИЧИНА «звука нет во встроенных динамиках» (полевой
     * лог итерации 10: звук только в наушниках). Итерация 6 «исправила»
     * EAPD 0x02 -> 0x8000, объявив бит 1 резервным — ЭТО ОШИБКА:
     * EAPD/BTL Enable (глагол 0x70C): бит 0 = BTL, бит 1 = EAPD, бит 2 =
     * LR Swap (HDA spec 7.3.4.11; эталон snd_hda_codec.c:
     * snd_hda_codec_eapd_power_filter проверяет `eapd & 0x02`). С
     * итерации 6 EAPD стоял на зарезервированном бите 15 — ВНЕШНИЙ
     * УСИЛИТЕЛЬ ДИНАМИКА ОБЕСТОЧЕН (наушники не требуют EAPD — потому
     * звук в них был). Возвращаем 0x02; в VMware бит игнорируется.
     * Запись ПОСЛЕ всей остальной настройки (рекомендация Realtek). */
    hda_verb(VERB(g_cad, 0x14, 0x70C, 0x0002), NULL); /* EAPD: динамик */

    /* [HDA-HPEN] наушники ALC269VB — пин 0x21: PIN_HP = OUT_EN|HP_EN
     * (0xC0) — включаем ступень драйвера наушников (Linux для HP-пинов
     * пишет PIN_HP); с одним OUT_EN (0x40) выход слабее — «тихий» звук. */
    hda_verb(VERB(g_cad, 0x21, 0x707, 0xC0), NULL);  /* pin: out + HP enable */
    hda_verb(VERB(g_cad, 0x21, 0x70C, 0x0002), NULL); /* EAPD: наушники */

    /* [HDA-1B] (полевая гипотеза: у части плат ALC269VB динамик выведен
     * на 0x1b, а не 0x14) — настраиваем 0x1b ТОЛЬКО если он существует
     * и умеет выход (Pin Caps, Get Parameter 0x09, бит4 Output Capable) */
    {
        u32 pcaps = 0, pcfg = 0;
        hda_verb(VERB(g_cad, 0x1b, 0xF00, 0x09u), &pcaps);
        hda_verb(VERB(g_cad, 0x1b, 0xF00, 0xF1Cu), &pcfg);
        snd_logf("da] NID 1b: pin caps=%08x pin config=%08x%s",
                 (unsigned)pcaps, (unsigned)pcfg,
                 (pcaps & 0x10u) ? " — выход" : " — выход не заявлен");
        if (pcaps & 0x10u) {
            hda_route_output(0x02, 0x1b);
            hda_verb(VERB(g_cad, 0x1b, 0x707, 0x40), NULL);
            hda_verb(VERB(g_cad, 0x1b, 0x70C, 0x0002), NULL); /* [HDA-EAPD2] */
            hda_verb(VERB(g_cad, 0x1b, 0x705, 0x00), NULL);
            (void)hda_amp_gain_out(0x1b, hda_amp_caps(0x1b, 1));
        }
    }

    /* подстраховка: некоторые платы разводят динамик на 0x0F/0x10 */
    hda_verb(VERB(g_cad, 0x0F, 0x707, 0x40), NULL);
    hda_verb(VERB(g_cad, 0x0F, 0x70C, 0x0002), NULL);  /* [HDA-EAPD2] */
    hda_verb(VERB(g_cad, 0x10, 0x707, 0x40), NULL);
    hda_verb(VERB(g_cad, 0x10, 0x70C, 0x0002), NULL);  /* [HDA-EAPD2] */

    /* [HDA-EAPD2] контроль: чтение EAPD/BTL назад (0xF0C) — в логе
     * должно быть 0002; иначе кодек не принял запись (глаголы/CAD) */
    {
        u32 e14 = 0, e21 = 0;
        hda_verb(VERB(g_cad, 0x14, 0xF0C, 0), &e14);
        hda_verb(VERB(g_cad, 0x21, 0xF0C, 0), &e21);
        snd_logf("da] EAPD чтение: 0x14=%04x 0x21=%04x%s",
                 (unsigned)(e14 & 0xFFFFu), (unsigned)(e21 & 0xFFFFu),
                 ((e14 & 0x2u) && (e21 & 0x2u)) ? "" : " — EAPD НЕ ВСТАЛ!");
    }

    /* [HDA-FAST] виджеты явно в D0 (дешёвая страховка: после CRST кодек
     * в D0 целиком, но отдельные узлы на некоторых платах спят) */
    hda_verb(VERB(g_cad, 0x02, 0x705, 0x00), NULL);
    hda_verb(VERB(g_cad, 0x14, 0x705, 0x00), NULL);
    hda_verb(VERB(g_cad, 0x21, 0x705, 0x00), NULL);

    snd_log("[hda] ALC269-конфигурация применена (unmute 0 дБ, EAPD, D0)");
    {
        u32 t1 = timer_poll_deadline();
        u32 us = (t1 - t0) * 10u / 12u;      /* тики PIT2 (0.838 мкс) -> мкс */
        snd_logf("[hda] init занял ~%u мс", (unsigned)(us / 1000u));
    }
    return 1;
}

/* BDL + кольцевой буфер (выделяются один раз).
 * Сессия 60: буфер увеличен 16384 → 65536 байт.
 * [HDA-RING256] (полевой лог 17): 64 КиБ ≈ 340-370 мс — ЛЮБОЙ сон задачи
 * дольше запаса (WiFi-скан с bring-up'ами по 60-114 мс × 14 каналов,
 * декод, планировщик) — и DMA убегает за курсор записи и крутит старые
 * данные прошлого круга (повтор = треск). Кольцо 256 КиБ:
 * 8 BDL-записей по 32 КиБ, ~1.4 с запаса @ 44.1к/стерео. Мелодии
 * sound_beep (до 16384 фреймов = 64 КиБ) по-прежнему не усекаются. */
#define HDA_BUF_BYTES 262144u
#define HDA_BDL_ENTRIES 8u                        /* 8 записей BDL */
#define HDA_BDL_ENTRY_BYTES (HDA_BUF_BYTES / HDA_BDL_ENTRIES)  /* 32 КиБ */
/* [HDA-PREFILL]: DMA стартует не раньше запаса */
#define HDA_PREFILL_BYTES (96u * 1024u)           /* ~0.5 с @ 44.1к */
#define HDA_PREFILL_MS 250u                       /* ...или максимум 250 мс */

/* [HDA-IOCOFF] прерывания потока НЕ используем (позиция — polling LPIB):
 * с IOC=1 контроллер выставляет BCIS и держит линию IRQ — мы её никогда
 * не гасим в процессе игры (STS чистится только в reset). Неисправленная
 * уровневая линия = риск IRQ-шторма/джиттера. Поэтому IOC=0 и SIE не
 * включаем. */
#define HDA_BDL_IOC  0x0000u   /* было 0x01 */

static i16  *g_buf = NULL;
static u32  *g_bdl = NULL;
static u32   hda_half_frames = 0;   /* фреймов в половине кольца; 0 = не настроен */

/* [HDA-SWVOL] Мастер-громкость (софтверная): масштабирование отсчётов
 * при копировании в DMA-кольцо. Аппаратные ампы выставлены в точку 0 дБ
 * ([HDA-GAINMAX]), громкость UI (панель на таскбаре) крутит именно
 * этот множитель — 0..100%. Реализуется ЕДИНОЙ точкой — копией в
 * g_buf (DMA читает только g_buf, буфер вызывающего не трогается). */
static int g_volume = 100;           /* процентов, 0..100 */

/* [HDA-HWVOL] (итерация 12) АППАРАТНАЯ мастер-громкость: выходной амп
 * DAC (ALC269: NID 0x02, капсы 0x00025757 = 87 шагов по 0.75 дБ,
 * ofs 87 = точка 0 дБ). Полевой лог 12: слайдер крутил только софт-
 * множитель при копии, а пользователь видел «ни на что не влияет»
 * (в т.ч. на мелодии теста). Аппаратный амп действует на ВСЁ и не
 * зависит от пути копирования: 100% = индекс 87 (0 дБ), 0% = индекс 0
 * (−65 дБ). Заполняется в init (см. цикл out_nids); 0 = софт-фолбэк. */
static u32 g_hwvol_nid = 0;          /* NID DAC-а с шаговым ампом */
static u32 g_hwvol_nsteps = 0;       /* NumSteps амп-капсов (0 = нет) */
static int g_volume_pct = 100;       /* проценты, запрошенные слайдером (UI) */

void snd_hda_set_volume(int percent)
{
    if (percent < 0)   percent = 0;
    if (percent > 100) percent = 100;
    g_volume_pct = percent;              /* UI показывает запрошенное */
    if (g_hwvol_nsteps) {
        /* аппаратный амп — единственный регулятор: софт-множитель держим
         * на 100%, иначе ослабления сложатся (двойное приглушение) */
        u32 idx = (u32)(((u64)percent * g_hwvol_nsteps) / 100u);
        hda_verb(VERB16(g_cad, g_hwvol_nid, 0x3, 0xB000u | idx), NULL);
        g_volume = 100;
        {
            static int s_vol_logged = 0;
            s_vol_logged++;
            if (s_vol_logged <= 4 || (s_vol_logged % 25u) == 0)
                snd_logf("[hda] громкость: %d%% (амп %02x индекс %u из %u)",
                         percent, (unsigned)g_hwvol_nid,
                         (unsigned)idx, (unsigned)g_hwvol_nsteps);
        }
    } else {
        g_volume = percent;              /* софт-фолбэк (амп без шагов) */
    }
}

/* проценты, ЗАПРОШЕННЫЕ слайдером — объявлены выше (g_volume_pct) */

int snd_hda_get_volume(void) { return g_volume_pct; }

/* копия stereo s16 c мастер-громкостью */
static void hda_vol_copy(i16 *dst, const i16 *src, u32 frames)
{
    if (g_volume >= 100) {
        memcpy(dst, src, frames * 4u);
        return;
    }
    if (g_volume <= 0) {
        memset(dst, 0, frames * 4u);
        return;
    }
    for (u32 i = 0; i < frames * 2u; i++)
        dst[i] = (i16)(((i32)src[i] * (i32)g_volume) / 100);
}

int snd_hda_play(const i16 *samples, u32 frames, u32 rate, u32 ms)
{
    (void)rate;   /* кодек и SD уже в 48k; мелодия синтезируется под 44100,
                     но луп целых периодов — сдвиг высоты неслышен */
    if (!g_hda.ok) return -1;

    if (!g_bdl) {
        g_bdl = (u32 *)malloc(256 + 128);       /* 2 записи по 16 байт */
        if (!g_bdl) return -1;
        memset((void *)(((unsigned long)g_bdl + 127) & ~127ul), 0, 32);
    }
    if (!g_buf) {
        g_buf = (i16 *)malloc(HDA_BUF_BYTES + 128);
        if (!g_buf) return -1;
    }
    u32 bdlp = ((u32)(unsigned long)g_bdl + 127) & ~127u;
    u32 bufp = ((u32)(unsigned long)g_buf + 127) & ~127u;

    u32 bytes = frames * 4;                     /* 16-bit stereo */
    if (bytes > HDA_BUF_BYTES) bytes = HDA_BUF_BYTES;
    u32 half = bytes / 2;                       /* 2 BDL-записи */
    /* [HDA-SWVOL] копия с громкостью */
    hda_vol_copy((i16 *)(unsigned long)bufp, samples, bytes / 4u);

    /* BDL: две половины одного кольца [HDA-IOCOFF]: IOC=0 — прерывания
     * не используем, позиция опрашивается по LPIB */
    u32 *bd = (u32 *)(unsigned long)bdlp;
    bd[0] = bufp;          bd[1] = 0; bd[2] = half; bd[3] = HDA_BDL_IOC;
    bd[4] = bufp + half;   bd[5] = 0; bd[6] = half; bd[7] = HDA_BDL_IOC;

    u32 sd = HDA_SD0;
    /* стоп + сброс дескриптора ([HDA-SDFIX]: SRST чистит CBL/LVI/FMT/BDL,
     * поэтому программирование — строго ПОСЛЕ reset) */
    hda_sd_reset(sd);
    /* [HDA-RATE] конвертер DAC — обратно в 48к (после 44.1-потока
     * MP3-плеера мелодия без этого играла бы с чужой тактовой) */
    hda_verb(VERB16(g_cad, 2, 0x2, HDA_FMT_48K_16_ST), NULL);
    /* настройки: CBL — 32 бита @0x08 (выровнено), LVI/FMT — СТРОГО 16 бит
     * (32-битная запись на невыровненный офсет молча округлялась вниз) */
    hd_wr(sd + SD_CBL, half * 2);
    hd_wr16(sd + SD_LVI, 1);                    /* 2 записи - 1 */
    hd_wr16(sd + SD_FMT, HDA_FMT_48K_16_ST);
    hd_wr(sd + SD_BDLP, bdlp);
    hd_wr(sd + SD_BDLU, 0);
    /* STRM tag=1 (совпадает с verb 0x706 на DAC: payload 0x10) + RUN.
     * Бит DIR (19) не ставим — на выделенном выходном дескрипторе он
     * зарезервирован (Linux не ставит). */
    u32 ctl = (1u << 20) | 2u;
    hd_wr(sd + SD_CTL, ctl);
    /* [HDA-IOCOFF]: SIE потока не включаем (прерывания не используем) */

    /* [HDA-DMA] диагностика DMA: LPIB (+0x04, НАСТОЯЩИЙ офсет) должен
     * расти. [HDA-LOG2] (полевой лог итерации 11: мелодия UI зовёт play()
     * 4 раза на ноту и выталкивала полезные строки из кольца klog) —
     * печатаем первые 2 запуска за загрузку и ВСЕГДА при остановке LPIB. */
    {
        static int s_play_logged = 0;
        u32 lpib0 = hd_rd(sd + SD_LPIB);
        hd_delay(20000);                     /* ~20 мс */
        u32 lpib1 = hd_rd(sd + SD_LPIB);
        int stalled = (lpib1 == lpib0);
        if (stalled || s_play_logged < 2) {
            s_play_logged++;
            snd_logf("da] play: CTL=%08x CBL=%u LVI=%u FMT=%04x BDL=%08x LPIB %u -> %u%s",
                     (unsigned)hd_rd(sd + SD_CTL), (unsigned)hd_rd(sd + SD_CBL),
                     (unsigned)hd_rd16(sd + SD_LVI), (unsigned)hd_rd16(sd + SD_FMT),
                     (unsigned)bdlp, (unsigned)lpib0,
                     (unsigned)lpib1, stalled ? " — DMA НЕ ИДЁТ!" : "");
        }
    }

    /* ждём */
    u32 t0 = timer_ticks();
    while ((timer_ticks() - t0) < ms) task_msleep(5);

    /* стоп */
    hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
    hd_delay(200);
    hda_half_frames = 0;
    return 0;
}

/* ================= потоковое воспроизведение (сессия 60) =================
 * [HDA-RING2] (итерация 12) МОДЕЛЬ: курсорная кольцевая запись.
 * [HDA-RING256/PREFILL/LPIB64] (полевой лог 17) — три доводки:
 *
 *   - BDL: 8 записей по 32 КиБ, CBL=256 КиБ (~1.4 с), LVI=7 — DMA крутит
 *     кольцо сам (IOC-прерываний нет, позиция — polling LPIB);
 *   - [HDA-PREFILL]: RUN ставится не сразу, а когда в кольце >= 96 КиБ
 *     (~0.5 с) или через 250 мс — раньше DMA запускался первым же куском
 *     (186 мс) и малейшая задержка декода выедала весь запас;
 *   - [HDA-LPIB64]: число полных кругов LPIB — по ТОЧНОЙ 64-битной
 *     оценке wall-clock (раньше bpm = rate/1000*4 обрезал 44.1к до 176
 *     байт/мс вместо 176.4 — дрейф 0.9% накапливался и портил оценку k);
 *   - [HDA-UNDERRUN]: при отставании производителя курсор записи
 *     подтягивается к play+запас, а ПРОПУСКАЕМЫЙ УЧАСТОК гасится в
 *     тишину — недобор теперь короткая пауза, а не треск-повтор старого
 *     круга; инвариант play <= wr контролируется явно.
 *
 * Гарантии: не перезаписываем неигранное, при опоздании — пауза (буфер
 * ~1.4 с), громкость применяется к КАЖДОМУ куску. */

#define HDA_MARGIN_BYTES (HDA_BUF_BYTES / 16u)   /* 16 КиБ ≈ 93 мс @ 44.1к */
#define HDA_FULL_SLACK   (HDA_BUF_BYTES / 32u)   /* порог «кольцо полно» */

static u64 g_wr_total   = 0;        /* байт записано с момента старта */
static u64 g_play_total = 0;        /* байт воспроизведено (по LPIB) */
static u32 g_last_lpib  = 0;
static int g_stream_task = 0;       /* [HDA-SWOWNER] владелец потока */
static int g_owner_logged = 0;
static u32 g_stream_rate_want = 48000u;   /* [HDA-RATE] запрошенный рейт */
static u32 g_last_play_tick = 0;    /* [HDA-CURSOR2] для оценки по времени */
static int g_paused = 0;            /* [HDA-CURSOR2] RUN снят паузой */
static int g_stream_armed = 0;      /* [HDA-PREFILL] сконфигурирован, ждёт запаса */
static u32 g_start_tick = 0;        /* [HDA-PREFILL] момент первого куска */
/* [HDA-HEALTH] счётчики самочувствия потока (строка раз в 5 с) */
static u32 g_hl_waits = 0;          /* входов в ожидание «кольцо полно» */
static u32 g_hl_drops = 0;          /* пропущенных кусков (-3) */
static u32 g_hl_bigk = 0;           /* восстановлений пропущенных кругов */
static u32 g_hl_muted = 0;          /* [HDA-UNDERRUN] гашений недобора */
static u64 g_hl_play0 = 0;          /* play-курсор прошлой строки здоровья */

/* байты -> мс по текущему формату потока (64 бита, без обрезки bpm) */
static u64 hda_bytes_to_ms(u64 bytes)
{
    u64 bps = (u64)g_stream_rate_want * 4u;      /* байт/с: 16бит стерео */
    return bps ? (bytes * 1000u) / bps : 0;
}

/* [HDA-UNDERRUN] погасить участок кольца [from, to) в тишину (офсеты —
 * монотонные байты с момента старта; участок может пересекать стык). */
static void hda_mute_range(u32 bufp, u64 from, u64 to)
{
    if (to <= from) return;
    if (to - from > (u64)HDA_BUF_BYTES) from = to - HDA_BUF_BYTES;
    u32 off = (u32)(from % HDA_BUF_BYTES);
    u64 len = to - from;
    u32 first = (u32)len;
    if ((u64)off + len > (u64)HDA_BUF_BYTES) first = HDA_BUF_BYTES - off;
    memset((void *)(unsigned long)(bufp + off), 0, first);
    if (len > (u64)first)
        memset((void *)(unsigned long)bufp, 0, (u32)(len - (u64)first));
}

/* [HDA-RATE] запрос частоты потока под файл. Возвращает ФАКТИЧЕСКИЙ
 * рейт: поддержанный — как есть, неподдержанный (напр. 8 кГц) — 48000
 * (ресэмпл на вызывающем). Формат применяется при следующем старте
 * потока; текучий поток добивается в прежнем формате. */
u32 snd_hda_stream_set_rate(u32 want)
{
    if (!g_hda.ok) return 0;
    u32 r = hda_fmt_for_rate(want) ? want : 48000u;
    u16 fmt = hda_fmt_for_rate(r);
    if (fmt) {
        /* [HDA-441CHK] DAC обязан ПОДТВЕРДИТЬ формат: пишем в конвертер
         * и читаем обратно (Get Converter Format, verb 0xA). Если кодек
         * частоту не умеет — вернётся другое значение: откат на 48к,
         * вызывающий включит свой ресэмплер. Вызывается между треками,
         * когда поток остановлен — verb безопасен. */
        u32 rb = 0;
        hda_verb(VERB16(g_cad, 2, 0x2, (u32)fmt), NULL);
        hda_verb(VERB16(g_cad, 2, 0xA, 0), &rb);
        if ((rb & 0xFFFFu) != (u32)fmt) {
            snd_logf("da] конвертер не принял fmt=%04x (читается %04x) — откат на 48к",
                     (unsigned)fmt, (unsigned)(rb & 0xFFFFu));
            r = 48000u;
        }
    }
    g_stream_rate_want = r;
    return g_stream_rate_want;
}

u32 snd_hda_stream_rate(void) { return g_stream_rate_want; }

/* продвинуть курсор воспроизведения по текущему LPIB (с учётом заворота)
 * [HDA-CURSOR2] (полевой лог 14: «треск + быстрее»): LPIB считает
 * позицию mod кольцо — пока производитель спал дольше круга (WiFi-скан,
 * планировщик), DMA прошёл k полных кругов, и сумма LPIB-дельт занижала
 * play на k*кольцо. Число кругов восстанавливаем по стенному времени:
 * DMA при RUN=1 потребляет ровно elapsed * байт/мс.
 * [HDA-LPIB64] (полевой лог 17): оценка — ТОЧНАЯ 64-БИТНАЯ формула
 * wall = elapsed_мс * rate * 4 / 1000. Прежде bpm = (rate/1000)*4
 * обрезал 44100/1000 до 44 → 176 байт/мс вместо 176.4: дрейф 0.9%
 * накапливался (~0.7 с за 80 с), и оценка k уползала — при завышении
 * play разрешал писать поверх играемого (треск), при занижении —
 * «кольцо полно» навсегда (пропуски). Разрешения таймера 1 мс
 * (PIT 1000 Гц) достаточно: ошибка <= ~176 байт на вызов против
 * половины круга 128 КиБ. */
static void hda_track_play(u32 sd)
{
    u32 now = timer_ticks();
    u32 lpib = hd_rd(sd + SD_LPIB) % HDA_BUF_BYTES;
    u32 delta = (lpib >= g_last_lpib) ? (lpib - g_last_lpib)
                                      : (lpib + HDA_BUF_BYTES - g_last_lpib);
    if (g_paused || !(hd_rd8(sd + SD_CTL) & 2u)) {
        /* пауза/стоп: LPIB заморожен — время в play НЕ засчитываем */
        g_last_lpib = lpib;
        g_last_play_tick = now;
        return;
    }
    u32 elapsed = (u32)(now - g_last_play_tick);
    u64 wall = (u64)elapsed * (u64)g_stream_rate_want * 4u / 1000u;  /* [HDA-LPIB64] */
    if (wall >= (u64)delta) {
        u64 k = (wall - (u64)delta + (u64)(HDA_BUF_BYTES / 2)) /
                (u64)HDA_BUF_BYTES;
        if (k > 16u) k = 16u;      /* страховка от скакнувшего таймера */
        if (k >= 1u) g_hl_bigk++;  /* [HDA-HEALTH] */
        g_play_total += (u64)delta + k * (u64)HDA_BUF_BYTES;
    } else {
        g_play_total += delta;     /* LPIB дальше времени — верим LPIB */
    }
    g_last_lpib = lpib;
    g_last_play_tick = now;
}

int snd_hda_stream(const i16 *samples, u32 frames, u32 rate)
{
    (void)rate;   /* фактический рейт — g_stream_rate_want [HDA-RATE] */
    if (!g_hda.ok || !samples || frames < 8) return -1;
    u16 want_fmt = hda_fmt_for_rate(g_stream_rate_want);
    if (!want_fmt) want_fmt = HDA_FMT_48K_16_ST;

    if (!g_bdl) {
        g_bdl = (u32 *)malloc(256 + 128);
        if (!g_bdl) return -1;
        memset((void *)(((unsigned long)g_bdl + 127) & ~127ul), 0, 32);
    }
    if (!g_buf) {
        g_buf = (i16 *)malloc(HDA_BUF_BYTES + 128);
        if (!g_buf) return -1;
    }
    u32 bdlp = ((u32)(unsigned long)g_bdl + 127) & ~127u;
    u32 bufp = ((u32)(unsigned long)g_buf + 127) & ~127u;
    u32 sd = HDA_SD0;

    u32 chunk_bytes = frames * 4;
    if (chunk_bytes > HDA_BUF_BYTES / 2) chunk_bytes = HDA_BUF_BYTES / 2;

    /* [HDA-RATE]: смена формата под другим файлом — только через полный
     * перезапуск (SRST чистит FMT/CBL/BDL); несовпадающий FMT принудительно
     * уводит в ветку первого запуска */
    int running = (hd_rd(sd + SD_CTL) & 2u) && hda_half_frames != 0 &&
                  (u32)hd_rd16(sd + SD_FMT) == (u32)want_fmt;
    /* [HDA-PREFILL]: «armed» = BDL/формат настроены, DMA ещё СТОИТ —
     * кольцо копит запас; fmt-проверка — на случай set_rate между кусками */
    int armed = !running && g_stream_armed && hda_half_frames != 0 &&
                (u32)hd_rd16(sd + SD_FMT) == (u32)want_fmt;

    if (!running && !armed) {
        /* первый запуск: кольцо — тишина, кусок — с нулевой позиции.
         * [HDA-PREFILL]: DMA НЕ запускаем — RUN поставит armed-ветка,
         * когда в кольце будет запас (96 КиБ / 250 мс) */
        /* [HDA-SWOWNER] поток закрепляем за вызвавшей задачей */
        g_stream_task  = task_current();
        g_owner_logged = 0;
        memset((void *)(unsigned long)bufp, 0, HDA_BUF_BYTES);
        hda_vol_copy((i16 *)(unsigned long)bufp, samples, chunk_bytes / 4u);
        g_wr_total    = chunk_bytes;
        g_play_total  = 0;
        g_last_lpib   = 0;
        g_paused      = 0;
        g_last_play_tick = timer_ticks();
        g_stream_armed   = 1;                 /* ждём предзаполнения */
        g_start_tick     = timer_ticks();

        hda_sd_reset(sd);                     /* [HDA-SDFIX] */
        /* BDL: 8 записей по 32 КиБ [HDA-RING256] */
        u32 *bd = (u32 *)(unsigned long)bdlp;
        for (u32 i = 0; i < HDA_BDL_ENTRIES; i++) {
            bd[i * 4 + 0] = bufp + i * HDA_BDL_ENTRY_BYTES;
            bd[i * 4 + 1] = 0;
            bd[i * 4 + 2] = HDA_BDL_ENTRY_BYTES;
            bd[i * 4 + 3] = HDA_BDL_IOC;
        }
        hd_wr(sd + SD_CBL, HDA_BUF_BYTES);
        hd_wr16(sd + SD_LVI, (u16)(HDA_BDL_ENTRIES - 1u));  /* 8 записей */
        hd_wr16(sd + SD_FMT, want_fmt);       /* [HDA-RATE] формат потока */
        /* конвертер DAC — тот же формат (verb 0x2), иначе 44.1-поток
         * играет с чужой тактовой [HDA-VERB16] */
        hda_verb(VERB16(g_cad, 2, 0x2, (u32)want_fmt), NULL);
        hd_wr(sd + SD_BDLP, bdlp);
        hd_wr(sd + SD_BDLU, 0);
        /* [HDA-IOCOFF]: SIE не включаем — прерывания не используем;
         * [HDA-PREFILL]: RUN не ставим — старт после предзаполнения */
        hda_half_frames = HDA_BDL_ENTRY_BYTES >> 2;   /* фреймов на запись */
        g_hl_waits = g_hl_drops = g_hl_bigk = g_hl_muted = 0;  /* [HDA-HEALTH] */
        g_hl_play0 = 0;
        {
            /* [HDA-LOG2]: формат потока — максимум 4 строки за загрузку */
            static int s_str_logged = 0;
            if (s_str_logged < 4) {
                s_str_logged++;
                snd_logf("da] stream: fmt=%04x (%u Гц), кольцо %u КиБ, "
                         "предзаполнение %u КиБ/макс %u мс",
                         (unsigned)want_fmt, (unsigned)g_stream_rate_want,
                         (unsigned)(HDA_BUF_BYTES >> 10),
                         (unsigned)(HDA_PREFILL_BYTES >> 10),
                         (unsigned)HDA_PREFILL_MS);
            }
        }
        return 0;
    }

    /* [HDA-SWOWNER] (полевой лог итерации 11: ДВЕ строки «задача
     * стартовала» подряд — два потока плеера; прежний кольц они
     * писали одновременно, попеременно ставя/снимая паузу DMA).
     * Чужой вызов — отказ: у ОС один HDA-поток, второй плеер должен
     * подождать. Код -2: apps_mp3 печатает причину и гасит Play. */
    if (g_stream_task != task_current()) {
        if (!g_owner_logged) {
            g_owner_logged = 1;
            snd_logf("da] stream: поток занят задачей #%d (вызов от #%d) — отказ",
                     g_stream_task, task_current());
        }
        return -2;
    }

    if (armed) {
        /* [HDA-PREFILL] (полевой лог 17): RUN ставится, когда в кольце
         * >= 96 КиБ (~0.5 с) или через 250 мс — какой порог раньше.
         * Прежде DMA стартовал с первым же куском (186 мс) — малейшая
         * задержка декода/планировщика и DMA выедал весь запас. */
        {
            u32 off = (u32)(g_wr_total % HDA_BUF_BYTES);
            u32 tail_bytes = HDA_BUF_BYTES - off;
            u32 f1 = (tail_bytes < chunk_bytes) ? tail_bytes : chunk_bytes;
            u32 f2 = chunk_bytes - f1;
            if (f1) hda_vol_copy((i16 *)(unsigned long)(bufp + off),
                                 samples, f1 / 4u);
            if (f2) hda_vol_copy((i16 *)(unsigned long)bufp,
                                 samples + f1 / 4u, f2 / 4u);
            g_wr_total += chunk_bytes;
        }
        u32 elapsed = (u32)(timer_ticks() - g_start_tick);
        if (g_wr_total >= (u64)HDA_PREFILL_BYTES || elapsed >= HDA_PREFILL_MS) {
            /* запас набран (или время вышло) — запуск DMA */
            hd_wr(sd + SD_CTL, (1u << 20) | 2u);
            g_stream_armed = 0;
            g_last_play_tick = timer_ticks();
            {
                static int s_run_logged = 0;
                if (s_run_logged < 4) {
                    s_run_logged++;
                    snd_logf("da] поток: RUN после предзаполнения %u КиБ "
                             "(%u мс) — запас ~%u мс",
                             (unsigned)(g_wr_total >> 10), elapsed,
                             (unsigned)hda_bytes_to_ms(g_wr_total));
                }
            }
        }
        return 0;
    }

    hda_track_play(sd);

    /* [HDA-UNDERRUN] (полевой лог 17): отставший производитель (декод,
     * WiFi-скан, планировщик) — курсор записи подтягиваем к play+запас,
     * а ПРОПУСКАЕМЫЙ УЧАСТОК гасим в тишину: прежде там оставались
     * старые данные прошлого круга (DMA их докручивал — треск-повтор).
     * Недобор теперь — короткая чистая пауза. */
    {
        u64 min_wr = g_play_total + HDA_MARGIN_BYTES;
        if (g_wr_total < min_wr) {
            u64 skip = min_wr - g_wr_total;
            if (skip > (u64)HDA_BUF_BYTES / 8u) {
                static u32 s_mute_last = 0;
                u32 nw = timer_ticks();
                if ((u32)(nw - s_mute_last) >= 1000u) {
                    s_mute_last = nw;
                    snd_logf("da] поток: недобор %u мс — гасим в тишину",
                             (unsigned)hda_bytes_to_ms(skip));
                }
            }
            hda_mute_range(bufp, g_wr_total, min_wr);
            g_hl_muted++;                     /* [HDA-HEALTH] */
            g_wr_total = min_wr;
        }
        /* [HDA-INV] play не может обгонять wr: после подтяжки гарантировано,
         * clamp — страховка от скакнувшей wall-оценки (иначе flow-control
         * видел бы фантомно свободное место и писал поверх играемого) */
        if (g_play_total > g_wr_total) g_play_total = g_wr_total;
    }

    /* flow control: не догонять play-курсор (кольцо полно) — ждём.
     * [HDA-CURSOR2]: таймаут 500 мс больше НЕ разрешает писать поверх
     * неигранного (это был треск) — кусок пропускается с кодом -3. */
    {
        u64 limit = HDA_BUF_BYTES - HDA_FULL_SLACK;
        if (g_wr_total + (u64)chunk_bytes - g_play_total > limit) {
            u32 t0 = timer_ticks();
            int full = 1;
            g_hl_waits++;                     /* [HDA-HEALTH] */
            while ((u32)(timer_ticks() - t0) <= 500u) {
                hda_track_play(sd);
                if (g_wr_total + (u64)chunk_bytes - g_play_total <= limit) {
                    full = 0;
                    break;
                }
                task_msleep(1);
            }
            hda_track_play(sd);
            /* после ожидания play мог обогнать наш курсор (мы спали) */
            {
                u64 min_wr = g_play_total + HDA_MARGIN_BYTES;
                if (g_wr_total < min_wr) g_wr_total = min_wr;
            }
            if (full) {
                static u32 s_full_last = 0;
                u32 now = timer_ticks();
                g_hl_drops++;                 /* [HDA-HEALTH] */
                if ((u32)(now - s_full_last) >= 1000u) {
                    s_full_last = now;
                    snd_logf("da] stream: кольцо полно >500 мс — кусок пропущен "
                             "(запись отстала на %u байт)",
                             (unsigned)(g_wr_total - g_play_total));
                }
                return -3;   /* пропуск куска вместо порчи неигранного */
            }
        }
    }

    /* пишем кусок по кольцу с огибанием конца (кусочки i16-фреймов) */
    {
        u32 off = (u32)(g_wr_total % HDA_BUF_BYTES);
        u32 tail_bytes = HDA_BUF_BYTES - off;
        u32 f1 = (tail_bytes < chunk_bytes) ? tail_bytes : chunk_bytes;
        u32 f2 = chunk_bytes - f1;
        if (f1) hda_vol_copy((i16 *)(unsigned long)(bufp + off),
                             samples, f1 / 4u);
        if (f2) hda_vol_copy((i16 *)(unsigned long)bufp,
                             samples + f1 / 4u, f2 / 4u);
    }
    g_wr_total += chunk_bytes;

    /* [HDA-HEALTH] раз в 5 с воспроизведения — одна строка самочувствия:
     * запас (lead, точные мс по 64-битной формуле) и счётчики проблем.
     * Если треск остался, а lead и счётчики чистые — причина вне кольца
     * (кодек/декод/IRQ). */
    {
        u64 lead = g_wr_total - g_play_total;
        u64 b5s = (u64)g_stream_rate_want * 4u / 1000u * 5000u;   /* байт за 5 с */
        if (g_play_total - g_hl_play0 >= b5s) {
            snd_logf("da] поток: lead=%u мс, ждём-полно=%u, пропусков=%u, "
                     "кругов восстановлено=%u, гашений=%u",
                     (unsigned)hda_bytes_to_ms(lead),
                     (unsigned)g_hl_waits, (unsigned)g_hl_drops,
                     (unsigned)g_hl_bigk, (unsigned)g_hl_muted);
            g_hl_play0 = g_play_total;
        }
    }
    return 0;
}

/* Пауза с сохранением позиции DMA (RUN снимается/ставится). */
void snd_hda_stream_pause(int on)
{
    if (!g_hda.ok) return;
    /* [HDA-SWOWNER2] (field log 12: crackling): task of SECOND
     * player, having got -2, called pause(1)/stop() and STOPPED the DMA
     * of the first one. Foreign call is IGNORED. */
    if (hda_half_frames != 0 && g_stream_task != task_current()) return;
    u32 sd = HDA_SD0;
    if (on) {
        hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
        g_paused = 1;                     /* [HDA-CURSOR2] время не считать */
    } else {
        if (g_stream_armed) {
            /* [HDA-PREFILL]: поток ещё копит запас, RUN=0 — это норма;
             * снятие паузы просто разрешает продолжение предзаполнения */
            g_paused = 0;
            return;
        }
        hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) | 2u);
        g_paused = 0;
        g_last_play_tick = timer_ticks(); /* elapsed — с момента снятия */
    }
}

/* Полный стоп (конец файла / закрытие плеера). */
void snd_hda_stream_stop(void)
{
    if (!g_hda.ok) return;
    /* [HDA-SWOWNER2]: foreign stop does not kill the stream */
    if (hda_half_frames != 0 && g_stream_task != task_current()) return;
    u32 sd = HDA_SD0;
    hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
    hd_delay(200);
    hda_half_frames = 0;
    g_wr_total = g_play_total = 0;
    g_last_lpib = 0;
    g_last_play_tick = timer_ticks();     /* [HDA-CURSOR2] */
    g_paused = 0;
    g_stream_armed = 0;                   /* [HDA-PREFILL] */
    g_start_tick = 0;
    g_stream_task = 0;                    /* поток свободен */
}
