/* brjs.h — интерактивные Markdown-страницы браузера N2600-OS
 * (поля ввода + скрипты QuickJS). Header-only, как brlines.h/brpage.h.
 *
 * Схема (сессия 65) — три слоя в исходнике страницы:
 *   1. Fenced-блоки (АВТОРИНГ, читается человеком):
 *        ```reader-input id=step widget=number label="Шаг" default=1
 *        ```
 *        ```reader-script id=inc trigger=click:#go
 *        let n = 0;
 *        go.onclick = () => ...   — НЕТ: тело — просто JS, см. reader API
 *        ```
 *   2. Base64-payload'ы (ДИСТРИБУЦИЯ, невидимы в любом рендерере):
 *        <!--@r:eyJ2IjoxLCJ0IjoiaW5wdXQiLi4ufQ==-->
 *        payload — JSON: {"v":1,"t":"input"|"script"|"page",...}
 *   3. Reference-style метаданные (выбрасываются):
 *        [//]: # (что угодно)
 *   YAML front matter (---...---) скрывается целиком.
 *
 * Конвейер страницы:
 *   brjs_extract()   — вырезать payload'ы/блоки из md ДО рендеринга;
 *                      каждый УСТОЙЧИВЫЙ (строкой) элемент заменить
 *                      односимвольным якорем \003 (паттерн brpage.h
 *                      для картинок \002): смещения строк остаются
 *                      честными, сжатие «на месте»;
 *   brp_analyze()    — картинки/ссылки (без изменений);
 *   brjs_scan()      — ОДИН раз при первой отрисовке (в потоке окна):
 *                      привязать якоря к элементам ПО ПОРЯДКУ,
 *                      разобрать base64-payload'ы движком страницы
 *                      (JS_EVAL_JSON — C-парсер JSON не нужен),
 *                      создать JS-сессию страницы (лениво — только
 *                      если странице есть чем её оправдать);
 *   brjs_layout()    — резерв строк под виджеты (совместно с картинками);
 *   отрисовка/мышь/клавиатура — brjs_draw_widget/brjs_hit/brjs_key;
 *   brjs_fire()      — исполнение скриптов по триггеру
 *                      (load | click:<id> | input:<id> | manual).
 *
 * Безопасность — см. mqjs_page.h (ограничение API, канарейки, CPU-guard,
 * stack guard, reaper). Скрипты всегда исполняются в потоке СВОЕГО окна.
 *
 * Зависимости: mem.h/string.h, utf8.h, brlines.h, fb.h, wm.h,
 * mqjs_page.h (движок). Хост-тест: scripts/test_brjs.c (без движка —
 * условная компиляция BRJS_NO_ENGINE).
 */
#ifndef BRJS_H
#define BRJS_H

#include "utf8.h"
#include "brlines.h"

#ifndef BRJS_NO_ENGINE
#include "mqjs_page.h"
#include "fb.h"
#include "wm.h"
#endif

/* односимвольный якорь виджета в md (у картинок brpage.h — '\002') */
#ifndef BRJS_MARK
#define BRJS_MARK '\003'
#endif

#define BRJS_MAX_WIDGETS 12
#define BRJS_MAX_SCRIPTS 8
#define BRJS_MAX_OPTIONS 6
#define BRJS_ID_MAX      24
#define BRJS_LABEL_MAX   48
#define BRJS_VALUE_MAX   96
#define BRJS_OPTION_MAX  24
#define BRJS_CODE_MAX    4096
#define BRJS_RAW_MAX     4096     /* предел base64-payload'а после декода */
#define BRJS_OUT_MAX     1024     /* текст виджета output */
#define BRJS_CONSOLE_MAX 4096     /* консоль страницы (Ctrl+J) */
#define BRJS_OUT_ROWS    6        /* предел строк виджета output */
#define BRJS_TRG_MAX     32

/* виды виджетов */
enum {
    BRJS_W_TEXT = 0,
    BRJS_W_NUMBER,
    BRJS_W_SELECT,
    BRJS_W_CHECK,
    BRJS_W_BUTTON,
    BRJS_W_OUTPUT,     /* место вывода reader.out()/reader.print-поля */
    BRJS_W_NKINDS
};

typedef struct {
    int  used;
    int  kind;                       /* BRJS_W_* */
    int  src_line;                   /* строка md с якорем (brjs_scan) */
    int  row;                        /* строка отображения (лейаут) */
    int  rows;                       /* занято строк отображения (>=1) */
    /* геометрия ПОСЛЕДНЕЙ отрисовки (коорд. содержимого окна) — hit-test */
    int  gx, gy, gw, gh;
    char id[BRJS_ID_MAX];
    char label[BRJS_LABEL_MAX];
    char bind[BRJS_ID_MAX];          /* имя глобала для значений (по умолч. id) */
    char value[BRJS_VALUE_MAX];      /* text/number/select; чекбокс — "0"/"1" */
    char options[BRJS_MAX_OPTIONS][BRJS_OPTION_MAX];
    int  noptions;
    int  sel;                        /* выбранный индекс options */
    /* сессия 66: ФОРМЫ. form — имя группы; action/method — только на
     * кнопке-отправителе (submit). Поля формы — виджеты с тем же form. */
    char form[BRJS_ID_MAX];
    char action[96];
    char method[8];                  /* "get" (по умолчанию) | "post" */
    /* текст виджета output (может быть многострочным) */
    char out[BRJS_OUT_MAX];
    int  out_len;
    int  focus;                      /* 1 = в поле идёт набор текста */
} brjs_widget_t;

typedef struct {
    int  used;
    char id[BRJS_ID_MAX];
    char trigger[BRJS_TRG_MAX];      /* "load"|"click:<id>"|"input:<id>"|"manual" */
    char *code;                      /* malloc, освобождает brjs_free */
    int  code_len;
} brjs_script_t;

/* необработанный base64-payload (JSON); разбирается движком в brjs_scan */
typedef struct {
    char *json;
    int   len;
} brjs_raw_t;

typedef struct {
    brjs_widget_t w[BRJS_MAX_WIDGETS];
    brjs_script_t s[BRJS_MAX_SCRIPTS];
    int nw, ns;
    /* очередь привязки якорей: k-я строка-якорь md -> элемент порядка k.
     * >=0 — индекс виджета (fenced-блок), <0 — индекс raw-payload
     * (-1-idx). Заполняется brjs_extract, разбирается brjs_scan. */
    signed char order[BRJS_MAX_WIDGETS + BRJS_MAX_SCRIPTS + 4];
    int norder;
    /* JS-сессия страницы (создаётся лениво в brjs_scan) */
    brjs_raw_t raw[BRJS_MAX_WIDGETS + BRJS_MAX_SCRIPTS];
    int nraw;
#ifndef BRJS_NO_ENGINE
    JSContext *ctx;
    int unsafe;                      /* 1 = полный API (только RAM disk) */
    int sess_dead;                   /* движок умер — скрипты не трогаем */
#endif
    int scanned;                     /* brjs_scan выполнен */
    int fire_load;                   /* 1 = скрипты load ждут после draw */
    int focus;                       /* индекс виджета в фокусе или -1 */
    char nav_pending[128];           /* reader.go: переход после скрипта */
    char status_msg[80];             /* reader.status */
    int  layout_dirty;               /* 1 = пересобрать строки (output менялся) */
} brjs_page_t;

/* ==================== утилиты ==================== */

static void brjs_copy(char *dst, int cap, const char *src, int len)
{
    if (len < 0) { const char *e = src; while (*e) e++; len = (int)(e - src); }
    if (len > cap - 1) len = cap - 1;
    if (len > 0) memcpy(dst, src, (u32)len);
    dst[len] = 0;
}

/* Вставка: удалить [d_from,d_to), вписать repl[0..rlen) (сдвиг хвоста).
 * Как brp_splice в brpage.h, но с memmove (не дублируем тонкости). */
static int brjs_splice(char *md, int len, int d_from, int d_to,
                       const char *repl, int rlen)
{
    if (d_from < 0 || d_to > len || d_from > d_to) return len;
    if (rlen > d_to - d_from) {
        int extra = rlen - (d_to - d_from);
        for (int i = len; i >= d_to; i--) md[i + extra] = md[i];
    } else if (rlen < d_to - d_from) {
        int shift = (d_to - d_from) - rlen;
        memmove(md + d_to - shift, md + d_to, (u32)(len - d_to + 1));
    }
    if (rlen > 0 && repl) memcpy(md + d_from, repl, (u32)rlen);
    return len - (d_to - d_from) + rlen;
}

/* base64 (стандартный алфавит; '-'/'_' принимаются как '+','/').
 * Возвращает число записанных байт или -1 (мусор/переполнение). */
static int brjs_b64dec(const char *in, int in_len, char *out, int out_max)
{
    static signed char T[256];               /* ленивая таблица декода */
    static int inited = 0;
    if (!inited) {
        const char *A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                        "abcdefghijklmnopqrstuvwxyz0123456789+/";
        memset(T, -1, sizeof(T));
        for (int i = 0; i < 64; i++) T[(u8)A[i]] = (signed char)i;
        T[(u8)'-'] = 62;
        T[(u8)'_'] = 63;
        inited = 1;
    }
    int o = 0;
    u32 acc = 0;
    int bits = 0;
    for (int i = 0; i < in_len; i++) {
        u8 c = (u8)in[i];
        if (c == '=') break;
        if (c == '\n' || c == '\r' || c == ' ') continue;
        int v = T[c];
        if (v < 0) return -1;
        acc = (acc << 6) | (u32)v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            if (o >= out_max) return -1;
            out[o++] = (char)((acc >> bits) & 0xFF);
        }
    }
    return o;
}

/* ==================== извлечение (brjs_extract) ====================
 * md МОДИФИЦИРУЕТСЯ. Квоты: BRJS_MAX_WIDGETS/SCRIPTS — лишнее молча
 * игнорируется. Возвращает новую длину md. */

/* fenced-атрибуты: key=value (value в кавычках или до пробела).
 * s указывает ВНУТРЬ строки md (NUL нет): конца строки достигли по
 * '\n'/'\r' — дальше атрибутов нет (FIX: раньше скан уходил за
 * пределы строки и втягивал мусор из следующих строк md). */
static int brjs_attr(const char *s, const char *key,
                     char *out, int out_max)
{
    int kl = (int)strlen(key);
    for (const char *p = s; *p && *p != '\n' && *p != '\r'; ) {
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\n' || *p == '\r') break;
        if (strncmp(p, key, (u32)kl) == 0 && p[kl] == '=') {
            p += kl + 1;
            if (*p == '"') {
                p++;
                int i = 0;
                while (*p && *p != '"' && *p != '\n' && *p != '\r' &&
                       i < out_max - 1) out[i++] = *p++;
                out[i] = 0;
                return 1;
            }
            int i = 0;
            while (*p && *p != ' ' && *p != '\t' &&
                   *p != '\n' && *p != '\r' && i < out_max - 1)
                out[i++] = *p++;
            out[i] = 0;
            return 1;
        }
        while (*p && *p != ' ' && *p != '\t' &&
               *p != '\n' && *p != '\r') p++;
    }
    return 0;
}

static int brjs_widget_alloc(brjs_page_t *js)
{
    if (js->nw >= BRJS_MAX_WIDGETS) return -1;
    brjs_widget_t *w = &js->w[js->nw];
    memset(w, 0, sizeof(*w));
    w->used = 1;
    w->kind = BRJS_W_TEXT;
    return js->nw++;
}

static int brjs_script_alloc(brjs_page_t *js)
{
    if (js->ns >= BRJS_MAX_SCRIPTS) return -1;
    brjs_script_t *sc = &js->s[js->ns];
    memset(sc, 0, sizeof(*sc));
    sc->used = 1;
    return js->ns++;
}

/* очередь привязки якорей (см. brjs_page_t.order) */
static void brjs_order_push(brjs_page_t *js, int widget_idx, int raw_idx)
{
    if (js->norder >= (int)(sizeof(js->order) / sizeof(js->order[0]))) return;
    js->order[js->norder++] = (signed char)(widget_idx >= 0 ? widget_idx
                                             : -1 - raw_idx);
}

/* создать виджет input из атрибутов fenced-блока. Возвращает индекс
 * или -1 (квоты/неизвестный вид). */
static int brjs_fenced_input(brjs_page_t *js, const char *attrs)
{
    char tmp[BRJS_VALUE_MAX];
    int wi = brjs_widget_alloc(js);
    if (wi < 0) return -1;
    brjs_widget_t *w = &js->w[wi];
    if (brjs_attr(attrs, "id", tmp, sizeof(tmp)))  brjs_copy(w->id, BRJS_ID_MAX, tmp, -1);
    if (brjs_attr(attrs, "label", tmp, sizeof(tmp))) brjs_copy(w->label, BRJS_LABEL_MAX, tmp, -1);
    if (brjs_attr(attrs, "bind", tmp, sizeof(tmp)))  brjs_copy(w->bind, BRJS_ID_MAX, tmp, -1);
    else brjs_copy(w->bind, BRJS_ID_MAX, w->id, -1);
    /* сессия 66: форма (имя группы) и кнопка-отправитель */
    if (brjs_attr(attrs, "form", tmp, sizeof(tmp)))
        brjs_copy(w->form, BRJS_ID_MAX, tmp, -1);
    if (brjs_attr(attrs, "action", tmp, sizeof(tmp)))
        brjs_copy(w->action, (int)sizeof(w->action), tmp, -1);
    if (brjs_attr(attrs, "method", tmp, sizeof(tmp)))
        brjs_copy(w->method, (int)sizeof(w->method), tmp, -1);
    if (brjs_attr(attrs, "widget", tmp, sizeof(tmp))) {
        if (!strcmp(tmp, "number"))       w->kind = BRJS_W_NUMBER;
        else if (!strcmp(tmp, "select"))  w->kind = BRJS_W_SELECT;
        else if (!strcmp(tmp, "checkbox"))w->kind = BRJS_W_CHECK;
        else if (!strcmp(tmp, "button"))  w->kind = BRJS_W_BUTTON;
        else if (!strcmp(tmp, "output"))  w->kind = BRJS_W_OUTPUT;
        else                               w->kind = BRJS_W_TEXT;
    }
    if (brjs_attr(attrs, "default", tmp, sizeof(tmp)))
        brjs_copy(w->value, BRJS_VALUE_MAX, tmp, -1);
    if (brjs_attr(attrs, "options", tmp, sizeof(tmp))) {
        /* options="a,b,c" — запятая-разделитель */
        const char *p = tmp;
        while (*p && w->noptions < BRJS_MAX_OPTIONS) {
            const char *e = p;
            while (*e && *e != ',') e++;
            int n = (int)(e - p);
            if (n > 0)
                brjs_copy(w->options[w->noptions++], BRJS_OPTION_MAX, p, n);
            p = (*e == ',') ? e + 1 : e;
        }
        if (w->noptions > 0) {
            w->sel = 0;
            for (int k = 0; k < w->noptions; k++)
                if (!strcmp(w->options[k], w->value)) { w->sel = k; break; }
            brjs_copy(w->value, BRJS_VALUE_MAX, w->options[w->sel], -1);
        }
    }
    if (w->kind == BRJS_W_CHECK) {
        w->value[0] = (!strcmp(w->value, "1") || !strcmp(w->value, "true")
                       || !strcmp(w->value, "on")) ? '1' : '0';
        w->value[1] = 0;
    }
    if (!w->id[0]) snprintf(w->id, sizeof(w->id), "in%d", wi);
    if (!w->bind[0]) brjs_copy(w->bind, BRJS_ID_MAX, w->id, -1);
    return wi;
}

/* создать скрипт из fenced-блока. Возвращает индекс или -1. */
static int brjs_fenced_script(brjs_page_t *js, const char *attrs,
                              const char *code, int code_len)
{
    char tmp[BRJS_TRG_MAX];
    int si = brjs_script_alloc(js);
    if (si < 0) return -1;
    brjs_script_t *sc = &js->s[si];
    if (brjs_attr(attrs, "id", tmp, sizeof(tmp)))
        brjs_copy(sc->id, BRJS_ID_MAX, tmp, -1);
    if (brjs_attr(attrs, "trigger", tmp, sizeof(tmp)))
        brjs_copy(sc->trigger, BRJS_TRG_MAX, tmp, -1);
    if (code_len > BRJS_CODE_MAX) code_len = BRJS_CODE_MAX;
    sc->code = (char *)malloc((u32)code_len + 1);
    if (!sc->code) { sc->used = 0; return -1; }
    memcpy(sc->code, code, (u32)code_len);
    sc->code[code_len] = 0;
    sc->code_len = code_len;
    if (!sc->trigger[0]) strcpy(sc->trigger, "load");
    return si;
}

/* Удалить front matter "---\n ... \n---\n" в начале файла. */
static int brjs_cut_front_matter(char *md, int len)
{
    if (len < 4 || strncmp(md, "---", 3) != 0) return len;
    if (md[3] != '\n' && md[3] != '\r') return len;
    int pos = 3;
    while (pos < len && (md[pos] == '\r' || md[pos] == '\n')) { pos++; if (md[pos-1] == '\n') break; }
    for (; pos < len; ) {
        int eol = pos;
        while (eol < len && md[eol] != '\n') eol++;
        int ls = pos, le = eol;
        if (le > ls && md[le - 1] == '\r') le--;
        if (le - ls >= 3 && strncmp(md + ls, "---", 3) == 0) {
            /* закрывающая черта: отрезать [0, eol+1) */
            int cut = (eol < len) ? eol + 1 : eol;
            memmove(md, md + cut, (u32)(len - cut));
            return len - cut;
        }
        if (eol >= len) break;
        pos = eol + 1;
    }
    return len;                          /* закрывающей черты нет — не трогаем */
}

/* Сдвинуть элементы очереди привязки при удалении ещё НЕ
 * привязанных позиций не нужно: привязка идёт ПО ПОРЯДКУ очереди,
 * а не по смещениям md. Удалённые строки (front matter, reference-
 * style) никогда не содержат якорей. */

/* ГЛАВНАЯ функция извлечения. */
static int brjs_extract(brjs_page_t *js, char *md, int md_len,
                        int *n_raw_out)
{
    if (n_raw_out) *n_raw_out = 0;
    md_len = brjs_cut_front_matter(md, md_len);
    md[md_len] = 0;

    int pos = 0;
    int in_fence = 0;
    while (pos < md_len) {
        int eol = pos;
        while (eol < md_len && md[eol] != '\n') eol++;
        int ls = pos, le = eol;
        if (le > ls && md[le - 1] == '\r') le--;
        int llen = le - ls;
        const char *line = md + ls;

        /* --- fenced-блоки --- */
        int ind = 0;
        while (ind < llen && (line[ind] == ' ' || line[ind] == '\t')) ind++;
        if (ind + 3 <= llen && line[ind] == '`' && line[ind+1] == '`' &&
            line[ind+2] == '`') {
            if (!in_fence) {
                /* открывающий: reader-input / reader-script? */
                const char *lang = line + ind + 3;
                int lang_len = llen - (ind + 3);
                int is_input = (lang_len >= 12 &&
                                !strncmp(lang, "reader-input", 12) &&
                                (lang_len == 12 || lang[12] == ' ' ||
                                 lang[12] == '\t'));
                int is_script = (lang_len >= 13 &&
                                 !strncmp(lang, "reader-script", 13) &&
                                 (lang_len == 13 || lang[13] == ' ' ||
                                  lang[13] == '\t'));
                if (is_input || is_script) {
                    /* найти закрывающий ``` и тело */
                    int q = pos;
                    int close = -1, close_eol = -1;
                    while (q < md_len) {
                        int e2 = q;
                        while (e2 < md_len && md[e2] != '\n') e2++;
                        int l2s = q, l2e = e2;
                        if (l2e > l2s && md[l2e - 1] == '\r') l2e--;
                        int l2 = l2e - l2s;
                        int i2 = 0;
                        while (i2 < l2 && (md[l2s + i2] == ' ' || md[l2s + i2] == '\t')) i2++;
                        if (q > pos && i2 + 3 <= l2 && md[l2s + i2] == '`' &&
                            md[l2s + i2 + 1] == '`' && md[l2s + i2 + 2] == '`') {
                            close = l2s; close_eol = e2; break;
                        }
                        if (e2 >= md_len) break;
                        q = e2 + 1;
                    }
                    if (close >= 0) {
                        const char *attrs = lang + (is_input ? 12 : 13);
                        int wi = -1, si = -1;
                        if (is_input) {
                            wi = brjs_fenced_input(js, attrs);
                            if (wi >= 0) brjs_order_push(js, wi, -1);
                        } else {
                            /* тело: [конец открывающей строки+1, close) */
                            int body_s = eol + 1;
                            int body_e = (close > body_s) ? close : body_s;
                            int blen = body_e - body_s;
                            if (blen > 0 && md[body_e - 1] == '\n') {
                                blen--;
                                if (blen > 0 && md[body_e - 2] == '\r') blen--;
                            }
                            si = brjs_fenced_script(js, attrs,
                                                    md + body_s, blen);
                            /* скрипты в очередь якорей НЕ попадают:
                             * они безпозиционные (FIX: иначе сбивается
                             * соответствие «k-й якорь — k-й элемент») */
                            (void)si;
                        }
                        /* заменить весь блок якорем (input/виджет) или
                         * пустой строкой (скрипт не рисуется). Граница —
                         * close_eol, НЕ включая '\n' закрывающей черты:
                         * он остаётся терминатором строки якоря
                         * (FIX: с +1 якорь склеивался со следующей
                         * строкой и та переставала быть fenced). */
                        if (wi >= 0) {
                            md_len = brjs_splice(md, md_len, pos, close_eol,
                                                 "\003", 1);
                            eol = pos + 1;
                        } else {
                            md_len = brjs_splice(md, md_len, pos, close_eol,
                                                 "", 0);
                            eol = pos;
                        }
                        md[md_len] = 0;
                        pos = (eol < md_len) ? eol + 1 : eol;
                        continue;
                    }
                    /* незакрытый блок — дальше как обычный текст */
                }
                in_fence = 1;
            } else {
                in_fence = 0;            /* закрывающий ``` — сам текст */
            }
            if (eol >= md_len) break;
            pos = eol + 1;
            continue;
        }

        if (!in_fence) {
            /* --- reference-style метаданные: "[//]: ..." — строка целиком --- */
            if (llen >= 5 && !strncmp(line, "[//]:", 5)) {
                int cut_to = (eol < md_len) ? eol + 1 : eol;
                md_len = brjs_splice(md, md_len, pos, cut_to, "", 0);
                md[md_len] = 0;
                pos = (pos < md_len) ? pos : md_len;
                continue;
            }

            /* --- <!--@r:BASE64--> --- */
            const char *cm = strstr(line, "<!--@r:");
            if (cm && cm - line < llen) {
                int cs = (int)(cm - line) + 7;       /* 7 = len("<!--@r:") */
                int ce = cs;
                while (ce < llen && strncmp(md + ls + ce, "-->", 3) != 0) ce++;
                if (ce < llen) {
                    int b64_len = ce - cs;
                    /* standalone (вся строка — только комментарий)? */
                    int standalone = 1;
                    for (int k = 0; k < (int)(cm - line); k++)
                        if (line[k] != ' ' && line[k] != '\t') { standalone = 0; break; }
                    for (int k = ce + 3; k < llen; k++)
                        if (line[k] != ' ' && line[k] != '\t') { standalone = 0; break; }
                    if (standalone && js->nraw < (int)(sizeof(js->raw) / sizeof(js->raw[0]))) {
                        char dec[BRJS_RAW_MAX];
                        int dl = brjs_b64dec(md + ls + cs, b64_len,
                                             dec, (int)sizeof(dec) - 1);
                        if (dl > 0) {
                            brjs_raw_t *r = &js->raw[js->nraw];
                            r->json = (char *)malloc((u32)dl + 1);
                            if (r->json) {
                                memcpy(r->json, dec, (u32)dl);
                                r->json[dl] = 0;
                                r->len = dl;
                                brjs_order_push(js, -1, js->nraw);
                                js->nraw++;
                                if (n_raw_out) (*n_raw_out)++;
                                /* якорь вместо комментария */
                                md_len = brjs_splice(md, md_len, pos, eol,
                                                     "\003", 1);
                                md[md_len] = 0;
                                eol = pos + 1;
                            }
                        }
                    }
                    /* НЕ standalone: payload игнорируется (документация:
                     * виджеты только отдельным абзацем), комментарий
                     * вырезаем, чтобы base64 не мусорил на экране */
                    if (!standalone) {
                        int c_abs0 = ls + (int)(cm - line);
                        int c_abs1 = ls + ce + 3;
                        md_len = brjs_splice(md, md_len, c_abs0, c_abs1, "", 0);
                        md[md_len] = 0;
                        eol = c_abs0;
                    }
                }
            }
        }

        if (eol >= md_len) break;
        pos = eol + 1;
    }
    return md_len;
}

/* сброс страницы: освободить коды/payload'ы/сессию (md свободает
 * вызывающий — браузер). Вызывается и из brjs_free. */
#ifndef BRJS_NO_ENGINE
static void brjs_page_reset(brjs_page_t *js)
{
    if (js->ctx) {
        mqjs_page_stop(js->ctx);
        js->ctx = NULL;
    }
    js->sess_dead = 0;
    js->unsafe = 0;
    js->scanned = 0;
    js->fire_load = 0;
    js->focus = -1;
    js->nav_pending[0] = 0;
    js->status_msg[0] = 0;
    js->layout_dirty = 0;
    for (int i = 0; i < js->ns; i++) {
        if (js->s[i].code) { free(js->s[i].code); js->s[i].code = NULL; }
    }
    for (int i = 0; i < js->nraw; i++) {
        if (js->raw[i].json) { free(js->raw[i].json); js->raw[i].json = NULL; }
    }
    js->nraw = 0;
    js->ns = 0;
    js->nw = 0;
    js->norder = 0;
}
#else
static void brjs_page_reset(brjs_page_t *js)
{
    js->scanned = 0;
    js->fire_load = 0;
    js->focus = -1;
    js->nav_pending[0] = 0;
    js->layout_dirty = 0;
    for (int i = 0; i < js->ns; i++)
        if (js->s[i].code) { free(js->s[i].code); js->s[i].code = NULL; }
    for (int i = 0; i < js->nraw; i++)
        if (js->raw[i].json) { free(js->raw[i].json); js->raw[i].json = NULL; }
    js->nraw = 0;
    js->ns = 0;
    js->nw = 0;
    js->norder = 0;
}
#endif


/* ==================== чистая логика (работает и без движка: хост-тест) ==================== */

/* виджет по id */
static brjs_widget_t *brjs_wfind(brjs_page_t *js, const char *id)
{
    if (!id || !id[0]) return NULL;
    for (int i = 0; i < js->nw; i++) {
        brjs_widget_t *w = &js->w[i];
        if (w->used && !strcmp(w->id, id)) return w;
    }
    return NULL;
}

static brjs_widget_t *brjs_outfind(brjs_page_t *js, const char *id)
{
    brjs_widget_t *hit = NULL;
    for (int i = 0; i < js->nw; i++) {
        brjs_widget_t *w = &js->w[i];
        if (!w->used || w->kind != BRJS_W_OUTPUT) continue;
        if (id && id[0] && !strcmp(w->id, id)) return w;
        if (!hit) hit = w;               /* первый output — по умолчанию */
    }
    return hit;
}

/* --- доступ значений (мост reader.* -> браузер -> сюда) --- */

/* тип значения: 0=string 1=number 2=bool. 1 = виджет найден. */
static int brjs_get_value(brjs_page_t *js, const char *id, char *buf,
                          int buf_max, int *type)
{
    brjs_widget_t *w = brjs_wfind(js, id);
    if (!w || w->kind == BRJS_W_OUTPUT || w->kind == BRJS_W_BUTTON)
        return 0;
    brjs_copy(buf, buf_max, w->value, -1);
    if (type) *type = (w->kind == BRJS_W_NUMBER) ? 1
                    : (w->kind == BRJS_W_CHECK)  ? 2 : 0;
    return 1;
}

static int brjs_set_value(brjs_page_t *js, const char *id, const char *val)
{
    brjs_widget_t *w = brjs_wfind(js, id);
    if (!w || w->kind == BRJS_W_OUTPUT) return 0;
    if (w->kind == BRJS_W_BUTTON) return 1;
    if (w->kind == BRJS_W_CHECK) {
        w->value[0] = (val && (!strcmp(val, "1") || !strcmp(val, "true") ||
                               !strcmp(val, "on"))) ? '1' : '0';
        w->value[1] = 0;
        return 1;
    }
    if (w->kind == BRJS_W_SELECT && w->noptions > 0) {
        w->sel = 0;
        for (int k = 0; k < w->noptions; k++)
            if (!strcmp(w->options[k], val)) { w->sel = k; break; }
        brjs_copy(w->value, BRJS_VALUE_MAX, w->options[w->sel], -1);
        return 1;
    }
    brjs_copy(w->value, BRJS_VALUE_MAX, val ? val : "", -1);
    return 1;
}

static int brjs_set_output(brjs_page_t *js, const char *id,
                           const char *text, int len)
{
    brjs_widget_t *w = brjs_outfind(js, id);
    if (!w) return 0;
    if (len < 0) len = (int)strlen(text);
    if (len > BRJS_OUT_MAX - 1) len = BRJS_OUT_MAX - 1;
    memcpy(w->out, text, (u32)len);
    w->out[len] = 0;
    w->out_len = len;
    js->layout_dirty = 1;                /* число строк могло измениться */
    return 1;
}

/* Хвост консоли: последние rows непустых строк буфера (панель Ctrl+J).
 * Возвращает число строк (в out[0] — самая СТАРАЯ из выбранных). */
__attribute__((unused))
static int brjs_console_tail(const char *buf, int len, int rows,
                             char out[][BRJS_VALUE_MAX])
{
    int n = 0;
    int pos = len;
    while (pos > 0 && n < rows) {
        int e = pos;                     /* строка — buf[e_prev..e) */
        while (e > 0 && buf[e - 1] != '\n') e--;
        int s = e;
        int sl = pos - s;
        if (sl > 0 && buf[s + sl - 1] == '\n') sl--;
        if (sl > 0 && buf[s + sl - 1] == '\r') sl--;
        if (sl > 0) {
            brjs_copy(out[n], BRJS_VALUE_MAX, buf + s, sl);
            n++;
        }
        pos = e - 1;                     /* за '\n' перед строкой */
        if (pos < 0) break;
    }
    for (int i = 0; i < n / 2; i++) {    /* старые сверху */
        char tmp[BRJS_VALUE_MAX];
        memcpy(tmp, out[i], BRJS_VALUE_MAX);
        memcpy(out[i], out[n - 1 - i], BRJS_VALUE_MAX);
        memcpy(out[n - 1 - i], tmp, BRJS_VALUE_MAX);
    }
    return n;
}

/* Сколько строк отображения займёт виджет (якорная строка входит). */
static int brjs_widget_rows(const brjs_widget_t *w)
{
    if (w->kind != BRJS_W_OUTPUT) return 1;
    int rows = 1;
    for (int k = 0; k < w->out_len; k++)
        if (w->out[k] == '\n') rows++;
    if (rows > BRJS_OUT_ROWS) rows = BRJS_OUT_ROWS;
    return rows;
}

/* Резерв строк отображения под виджеты (СТОЯЩИЙ ОТДЕЛЬНО вариант для
 * хост-тестов; браузер использует общий проход br_layout_media —
 * картинки и виджеты обязаны размечаться в одном проходе). */
__attribute__((unused))
static void brjs_layout(brjs_page_t *js, brl_list_t *L)
{
    if (!L || !L->lines) return;
    for (int i = 0; i < L->nlines; i++) {
        const char *s = L->lines[i];
        if (s[0] != BRJS_MARK || s[1] != 0) continue;
        brjs_widget_t *w = NULL;
        for (int k = 0; k < js->nw; k++) {
            brjs_widget_t *q = &js->w[k];
            if (q->used && q->src_line >= 0 && q->src_line == L->srcidx[i]) {
                w = q;
                break;
            }
        }
        L->cls[i] = BRL_CLS_WID;
        if (!w) continue;
        w->row = i;
        int rows = brjs_widget_rows(w);
        w->rows = rows;
        if (rows > 1) {
            brl_insert_blanks(L, i + 1, rows - 1, L->srcidx[i]);
            for (int k = i + 1; k < i + rows && k < L->nlines; k++)
                L->cls[k] = BRL_CLS_WID;
            i += rows - 1;               /* вставленные строки — пропустить */
        }
    }
}

/* действия мыши по виджетам */
#define BRJS_ACT_NONE   0
#define BRJS_ACT_FOCUS  1    /* клик в поле: фокус ввода */
#define BRJS_ACT_TOGGLE 2    /* чекбокс: инвертировать -> input:<id> */
#define BRJS_ACT_CYCLE  3    /* select: следующий вариант -> input:<id> */
#define BRJS_ACT_PRESS  4    /* кнопка -> click:<id> */

/* Виджет под точкой содержимого (mx,my) — по геометрии последней
 * отрисовки. Возвращает действие; *w_out — виджет (может быть NULL). */
__attribute__((unused))
static int brjs_hit(brjs_page_t *js, int mx, int my, brjs_widget_t **w_out)
{
    if (w_out) *w_out = NULL;
    for (int i = 0; i < js->nw; i++) {
        brjs_widget_t *w = &js->w[i];
        if (!w->used || w->gw <= 0) continue;
        if (mx >= w->gx && mx < w->gx + w->gw &&
            my >= w->gy && my < w->gy + w->gh) {
            if (w_out) *w_out = w;
            switch (w->kind) {
            case BRJS_W_TEXT:
            case BRJS_W_NUMBER: return BRJS_ACT_FOCUS;
            case BRJS_W_CHECK:  return BRJS_ACT_TOGGLE;
            case BRJS_W_SELECT: return BRJS_ACT_CYCLE;
            case BRJS_W_BUTTON: return BRJS_ACT_PRESS;
            default:            return BRJS_ACT_NONE;
            }
        }
    }
    return BRJS_ACT_NONE;
}

/* инвертировать чекбокс / перещёлкнуть select (после hit) */
static void brjs_apply_action(brjs_page_t *js, brjs_widget_t *w, int act)
{
    (void)js;
    if (!w) return;
    if (act == BRJS_ACT_TOGGLE)
        w->value[0] = (w->value[0] == '1') ? '0' : '1';
    else if (act == BRJS_ACT_CYCLE && w->noptions > 0)
        w->sel = (w->sel + 1) % w->noptions,
        brjs_copy(w->value, BRJS_VALUE_MAX, w->options[w->sel], -1);
}

/* ==================== формы (сессия 66) ==================== */

/* URL-encode значения поля: безопасны [A-Za-z0-9-._~], прочие байты
 * — %XX. Возвращает число записанных байт (без NUL). */
__attribute__((unused))
static int brjs_urlenc(const char *s, char *out, int out_max)
{
    static const char hex[] = "0123456789ABCDEF";
    int o = 0;
    if (out_max <= 0) return 0;
    out[0] = 0;
    for (; *s; s++) {
        char c = *s;
        int plain = ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                     (c >= '0' && c <= '9') || c == '-' || c == '.' ||
                     c == '_' || c == '~');
        int need = plain ? 1 : 3;
        if (o + need > out_max - 1) break;
        if (plain) {
            out[o++] = c;
        } else {
            u8 b = (u8)c;
            out[o++] = '%';
            out[o++] = hex[b >> 4];
            out[o++] = hex[b & 15];
        }
    }
    out[o] = 0;
    return o;
}

/* Собрать тело формы (query string "k=v&k2=v2") из виджетов с той же
 * формой, в порядке документа. Кнопки/output не участвуют; чекбокс
 * даёт 1/0. Возвращает длину out. */
__attribute__((unused))
static int brjs_form_query(brjs_page_t *js, const char *form_name,
                           char *out, int out_max)
{
    int o = 0;
    if (!form_name || !form_name[0] || out_max <= 0) return 0;
    out[0] = 0;
    for (int i = 0; i < js->nw; i++) {
        brjs_widget_t *w = &js->w[i];
        if (!w->used || !w->form[0] || strcmp(w->form, form_name) != 0)
            continue;
        if (w->kind == BRJS_W_BUTTON || w->kind == BRJS_W_OUTPUT)
            continue;
        if (o > 0 && o < out_max - 1) out[o++] = '&';
        o += brjs_urlenc(w->bind[0] ? w->bind : w->id, out + o, out_max - o);
        if (o < out_max - 1) out[o++] = '=';
        const char *val = w->value;
        if (w->kind == BRJS_W_CHECK)
            val = (w->value[0] == '1') ? "1" : "0";
        o += brjs_urlenc(val, out + o, out_max - o);
        if (o > out_max - 1) o = out_max - 1;
        out[o] = 0;
    }
    return o;
}

/* ==================== движок страницы (сессия 65) ==================== */

#ifndef BRJS_NO_ENGINE

/* строковое свойство payload'а (или def, если нет/не строка) */
static void brjs_jstr(JSContext *ctx, JSValue obj, const char *name,
                      char *dst, int cap, const char *def)
{
    JSValue v = JS_GetPropertyStr(ctx, obj, name);
    if (!JS_IsException(v) && JS_IsString(ctx, v)) {
        JSCStringBuf sb;
        size_t len = 0;
        const char *s = JS_ToCStringLen(ctx, &len, v, &sb);
        if (s) {
            brjs_copy(dst, cap, s, (int)(len > (size_t)(cap - 1) ?
                                         (size_t)(cap - 1) : len));
            return;
        }
    }
    if (JS_HasException(ctx)) JS_GetException(ctx);
    if (def) brjs_copy(dst, cap, def, -1);
    else dst[0] = 0;
}

/* Разобрать raw-payload (JSON) движком и создать input/script/page.
 * Вызывается из brjs_scan, когда контекст уже есть. */
static void brjs_parse_payload(brjs_page_t *js, const brjs_raw_t *r)
{
    JSValue obj = mqjs_page_json(js->ctx, r->json, (size_t)r->len);
    if (JS_IsException(obj)) {
        JS_GetException(js->ctx);
        return;
    }
    char t[16], id[BRJS_ID_MAX], tmp[BRJS_VALUE_MAX];
    brjs_jstr(js->ctx, obj, "t", t, (int)sizeof(t), "");
    brjs_jstr(js->ctx, obj, "id", id, (int)sizeof(id), "");

    if (!strcmp(t, "page")) {
        JSValue uv = JS_GetPropertyStr(js->ctx, obj, "unsafe");
        if (!JS_IsException(uv) && JS_IsBool(uv) && uv == JS_TRUE)
            js->unsafe = 1;
        if (JS_HasException(js->ctx)) JS_GetException(js->ctx);
    } else if (!strcmp(t, "input") && js->nw < BRJS_MAX_WIDGETS) {
        int wi = brjs_widget_alloc(js);
        if (wi >= 0) {
            brjs_widget_t *w = &js->w[wi];
            brjs_jstr(js->ctx, obj, "widget", tmp, (int)sizeof(tmp), "text");
            if (!strcmp(tmp, "number"))        w->kind = BRJS_W_NUMBER;
            else if (!strcmp(tmp, "select"))   w->kind = BRJS_W_SELECT;
            else if (!strcmp(tmp, "checkbox")) w->kind = BRJS_W_CHECK;
            else if (!strcmp(tmp, "button"))   w->kind = BRJS_W_BUTTON;
            else if (!strcmp(tmp, "output"))   w->kind = BRJS_W_OUTPUT;
            else                               w->kind = BRJS_W_TEXT;
            brjs_jstr(js->ctx, obj, "label", w->label, BRJS_LABEL_MAX,
                      id[0] ? id : NULL);
            brjs_jstr(js->ctx, obj, "bind", w->bind, BRJS_ID_MAX, id);
            /* сессия 66: форма/кнопка-отправитель из payload'а */
            brjs_jstr(js->ctx, obj, "form", tmp, (int)sizeof(tmp), "");
            if (tmp[0]) brjs_copy(w->form, BRJS_ID_MAX, tmp, -1);
            brjs_jstr(js->ctx, obj, "action", tmp, (int)sizeof(tmp), "");
            if (tmp[0]) brjs_copy(w->action, (int)sizeof(w->action), tmp, -1);
            brjs_jstr(js->ctx, obj, "method", tmp, (int)sizeof(tmp), "");
            if (tmp[0]) brjs_copy(w->method, (int)sizeof(w->method), tmp, -1);
            /* default: любым скаляром — через JS_ToString */
            JSValue dv = JS_GetPropertyStr(js->ctx, obj, "default");
            if (!JS_IsException(dv) && !JS_IsUndefined(dv) && !JS_IsNull(dv)) {
                JSValue sv = JS_ToString(js->ctx, dv);
                if (JS_HasException(js->ctx)) JS_GetException(js->ctx);
                if (!JS_IsException(sv) && JS_IsString(js->ctx, sv)) {
                    JSCStringBuf sb;
                    size_t sl = 0;
                    const char *ss = JS_ToCStringLen(js->ctx, &sl, sv, &sb);
                    if (ss) brjs_copy(w->value, BRJS_VALUE_MAX, ss,
                                      (int)(sl > BRJS_VALUE_MAX - 1 ?
                                            BRJS_VALUE_MAX - 1 : (int)sl));
                }
                if (JS_HasException(js->ctx)) JS_GetException(js->ctx);
            }
            if (w->kind == BRJS_W_CHECK) {
                w->value[0] = (!strcmp(w->value, "true") ||
                               !strcmp(w->value, "1")) ? '1' : '0';
                w->value[1] = 0;
            }
            if (w->kind == BRJS_W_SELECT) {
                JSValue ov = JS_GetPropertyStr(js->ctx, obj, "options");
                if (!JS_IsException(ov) && JS_IsArray(js->ctx, ov)) {
                    JSValue lv = JS_GetPropertyStr(js->ctx, ov, "length");
                    int ln = 0;
                    if (!JS_IsException(lv) && JS_IsInt(lv))
                        ln = JS_VALUE_GET_INT(lv);
                    if (ln > BRJS_MAX_OPTIONS) ln = BRJS_MAX_OPTIONS;
                    for (int k = 0; k < ln; k++) {
                        JSValue e = JS_GetPropertyUint32(js->ctx, ov, (u32)k);
                        if (!JS_IsException(e) && JS_IsString(js->ctx, e)) {
                            JSCStringBuf sb2;
                            size_t el = 0;
                            const char *ee = JS_ToCStringLen(js->ctx, &el,
                                                             e, &sb2);
                            if (ee && w->noptions < BRJS_MAX_OPTIONS) {
                                brjs_copy(w->options[w->noptions++],
                                          BRJS_OPTION_MAX, ee,
                                          (int)(el > BRJS_OPTION_MAX - 1 ?
                                                BRJS_OPTION_MAX - 1 : (int)el));
                            }
                        }
                        if (JS_HasException(js->ctx)) JS_GetException(js->ctx);
                    }
                }
                if (JS_HasException(js->ctx)) JS_GetException(js->ctx);
                w->sel = 0;
                for (int k = 0; k < w->noptions; k++)
                    if (!strcmp(w->options[k], w->value)) { w->sel = k; break; }
                if (w->noptions > 0)
                    brjs_copy(w->value, BRJS_VALUE_MAX, w->options[w->sel], -1);
            }
            if (id[0]) brjs_copy(w->id, BRJS_ID_MAX, id, -1);
            if (!w->id[0]) snprintf(w->id, sizeof(w->id), "in%d", wi);
            if (!w->bind[0]) brjs_copy(w->bind, BRJS_ID_MAX, w->id, -1);
        }
    } else if (!strcmp(t, "script") && js->ns < BRJS_MAX_SCRIPTS) {
        int si = brjs_script_alloc(js);
        if (si >= 0) {
            brjs_script_t *sc = &js->s[si];
            brjs_jstr(js->ctx, obj, "id", sc->id, BRJS_ID_MAX, "");
            brjs_jstr(js->ctx, obj, "trigger", sc->trigger, BRJS_TRG_MAX,
                      "load");
            if (!sc->trigger[0]) strcpy(sc->trigger, "load");
            JSValue cv = JS_GetPropertyStr(js->ctx, obj, "code");
            if (!JS_IsException(cv) && JS_IsString(js->ctx, cv)) {
                JSCStringBuf sb;
                size_t cl = 0;
                const char *cc = JS_ToCStringLen(js->ctx, &cl, cv, &sb);
                if (cc) {
                    int n = (int)cl;
                    if (n > BRJS_CODE_MAX) n = BRJS_CODE_MAX;
                    sc->code = (char *)malloc((u32)n + 1);
                    if (sc->code) {
                        memcpy(sc->code, cc, (u32)n);
                        sc->code[n] = 0;
                        sc->code_len = n;
                    }
                }
            }
            if (JS_HasException(js->ctx)) JS_GetException(js->ctx);
            if (!sc->code) sc->used = 0;
        }
    }
}

/* Значение виджета как JS-значение (для bind'ов и reader.get):
 * number -> число, check -> bool, остальное -> строка. */
static JSValue brjs_jsval_of(JSContext *ctx, const brjs_widget_t *w)
{
    if (w->kind == BRJS_W_CHECK)
        return JS_NewBool(w->value[0] == '1');
    if (w->kind == BRJS_W_NUMBER) {
        long long iv = 0;
        int neg = 0, digits = 0;
        const char *p = w->value;
        while (*p == ' ') p++;
        const char *q = (*p == '-') ? (neg = 1, p + 1)
                      : (*p == '+') ? p + 1 : p;
        for (; *q >= '0' && *q <= '9'; q++) {
            if (iv < ((long long)1 << 40)) iv = iv * 10 + (*q - '0');
            digits++;
        }
        if (digits > 0 && *q == 0)
            return JS_NewInt64(ctx, neg ? -iv : iv);
        /* нецелые — как строка (скрипт сам зовёт Number(), если надо) */
    }
    return JS_NewString(ctx, w->value);
}

/* Предать значения виджетов глобалам (bind) перед исполнением скрипта:
 * скрипту доступны ОБЕ формы — глобалы по bind и reader.get(). */
static void brjs_push_binds(JSContext *ctx, brjs_page_t *js)
{
    JSValue g = JS_GetGlobalObject(ctx);
    for (int i = 0; i < js->nw; i++) {
        brjs_widget_t *w = &js->w[i];
        if (!w->used || !w->bind[0] || w->kind == BRJS_W_OUTPUT ||
            w->kind == BRJS_W_BUTTON)
            continue;
        JS_SetPropertyStr(ctx, g, w->bind, brjs_jsval_of(ctx, w));
    }
}


/* ==================== привязка якорей и исполнение ==================== */







/* --- ПРИВЯЗКА ЯКОРЕЙ + ленивый запуск сессии ---
 * Вызывается ОДИН раз на страницу при первой отрисовке (поток окна).
 * md здесь — финальный (после brp_analyze). allow_unsafe даёт только
 * браузер для локальных страниц RAM disk. */
static void brjs_scan(brjs_page_t *js, const char *md, int md_len,
                      int allow_unsafe, char *console, u32 console_max,
                      const mqjs_reader_vt_t *vt, void *ui)
{
    if (js->scanned) return;
    js->scanned = 1;

    /* сессия нужна только при base64-payload'ах (парсер JSON) или
     * скриптах. Страница из одних fenced-input'ов движка НЕ получает
     * вообще — нулевая цена. */
    int need_ctx = (js->nraw > 0);
    if (!need_ctx)
        for (int i = 0; i < js->ns && !need_ctx; i++)
            if (js->s[i].used) need_ctx = 1;
    if (!need_ctx) return;

    js->ctx = mqjs_page_start(console, console_max, 0, vt, ui);
    if (!js->ctx) { js->sess_dead = 1; return; }

    /* привязка якорей по порядку очереди; попутно — разбор raw */
    int li = 0, pos = 0, oi = 0;
    while (pos < md_len && oi < js->norder) {
        const char *nl = md + pos;
        while (nl < md + md_len && *nl != '\n') nl++;
        int llen = (int)(nl - (md + pos));
        if (llen == 1 && md[pos] == BRJS_MARK) {
            int it = js->order[oi++];
            if (it >= 0) {
                if (it < js->nw) js->w[it].src_line = li;
            } else {
                int ri = -1 - it;
                if (ri < js->nraw) {
                    int nw_before = js->nw;
                    brjs_parse_payload(js, &js->raw[ri]);
                    /* payload создал ВИДЖЕТ -> он занимает ЭТУ строку
                     * (t=script/page виджет не создают — строка
                     * остаётся пустой) */
                    if (js->nw > nw_before)
                        js->w[js->nw - 1].src_line = li;
                }
            }
        }
        li++;
        if (nl >= md + md_len) break;
        pos = (int)(nl - md) + 1;
    }

    /* unsafe-страница (только локальные): пересоздать контекст с
     * полным API ОС. Разбор payload'ов уже прошёл в ограниченном —
     * JSON.parse его не требует. */
    if (js->unsafe && allow_unsafe) {
        mqjs_page_stop(js->ctx);
        js->ctx = mqjs_page_start(console, console_max, 1, vt, ui);
        if (!js->ctx) { js->sess_dead = 1; return; }
    }
    js->fire_load = 1;                   /* скрипты load — после отрисовки */
}

/* Триггер скрипта совпал? "load"|"manual" — точное совпадение,
 * "click:<id>"/"input:<id>" — совпадение всей строки триггера.
 * НЕСКОЛЬКО скриптов могут висеть на одном триггере. */
static int brjs_trigger_match(const brjs_script_t *sc, const char *trg)
{
    if (!sc->used || !sc->code) return 0;
    return !strcmp(sc->trigger, trg);
}

/* Исполнить все скрипты с триггером trg. Возвращает 1, если скрипт
 * запросил переход (js->nav_pending). Сессия может умереть (-2):
 * дальнейшие скрипты пропускаются, движок больше не трогаем. */
static int brjs_fire(brjs_page_t *js, const char *trg, char *console,
                     u32 console_max, const mqjs_reader_vt_t *vt, void *ui)
{
    if (js->sess_dead) return 0;
    if (!js->ctx) {
        js->ctx = mqjs_page_start(console, console_max, js->unsafe, vt, ui);
        if (!js->ctx) { js->sess_dead = 1; return 0; }
    }
    for (int i = 0; i < js->ns; i++) {
        brjs_script_t *sc = &js->s[i];
        if (!brjs_trigger_match(sc, trg)) continue;
        brjs_push_binds(js->ctx, js);
        int rc = mqjs_page_eval(js->ctx, sc->code, (size_t)sc->code_len,
                                sc->id[0] ? sc->id : "page");
        if (rc == -2) {                  /* движок мёртв */
            js->ctx = NULL;
            js->sess_dead = 1;
            return 1;                    /* nav_pending мог уже быть */
        }
    }
    /* сессия 66: DOM-мост. Обработчики, назначенные скриптом как
     * document.getElementById('id').onclick = fn, вызываются при клике
     * по виджету-кнопке с тем же id (после скриптов с триггером
     * click:<id>). Идентификатор проверяется на безопасные символы —
     * он встраивается в JS-сниппет. */
    if (js->ctx && !js->sess_dead && !strncmp(trg, "click:", 6)) {
        const char *id = trg + 6;
        int safe = id[0] != 0;
        for (const char *q = id; safe && *q; q++)
            if (!((*q >= 'A' && *q <= 'Z') || (*q >= 'a' && *q <= 'z') ||
                  (*q >= '0' && *q <= '9') || *q == '_' || *q == '-'))
                safe = 0;
        if (safe) {
            char disp[BRJS_ID_MAX * 2 + 48];
            snprintf(disp, sizeof(disp),
                     "if(typeof __dispatchClick==='function')"
                     "__dispatchClick('%s');", id);
            int rc = mqjs_page_eval(js->ctx, disp, strlen(disp), "domclick");
            if (rc == -2) { js->ctx = NULL; js->sess_dead = 1; }
        }
    }
    return js->nav_pending[0] ? 1 : 0;
}


/* ==================== лейаут / отрисовка / ввод ==================== */



/* геометрия виджета по умолчанию (в символах; 1 символ = 8 px) */
#define BRJS_LABEL_C   14               /* предел символов подписи */
#define BRJS_BOX_C     22               /* ширина поля ввода в символах */

/* отрисовать виджет. y — верх строки-якоря (уже с прокруткой).
 * Запоминает геометрию для hit-test. cw — ширина содержимого окна. */
static void brjs_draw_widget(brjs_page_t *js, brjs_widget_t *w, int y, int cw)
{
    (void)js;
    if (!w || !w->used) return;
    int x = 4;
    u32 col_text = wm_theme_text();
    u32 col_dim  = wm_theme_text_dim();
    u32 col_box  = fb_rgb(0x1E, 0x24, 0x2C);
    u32 col_bord = w->focus ? wm_theme_accent() : fb_rgb(0x34, 0x3A, 0x42);
    char buf[BRJS_LABEL_MAX + 2];

    switch (w->kind) {
    case BRJS_W_TEXT:
    case BRJS_W_NUMBER: {
        /* подпись */
        brjs_copy(buf, (int)sizeof(buf) - 1, w->label, BRJS_LABEL_C);
        int lw = (int)utf8_count_chars(buf, -1);
        if (buf[0]) fb_text(x, y + 1, buf, col_dim, -1);
        x += (lw + 1) * 8;
        /* поле */
        int bw = (cw - x - 4);
        int box_c = bw / 8;
        if (box_c > BRJS_BOX_C) box_c = BRJS_BOX_C;
        if (box_c < 4) box_c = 4;
        bw = box_c * 8 + 6;
        fb_fill_rect(x, y, bw, 15, col_box);
        fb_rect(x, y, bw, 15, col_bord);
        /* значение (хвост) + курсор */
        brjs_copy(buf, box_c + 1, w->value, -1);
        int vl = (int)utf8_count_chars(buf, -1);
        int max_v = box_c - (w->focus ? 1 : 0);
        int from = 0;
        if (vl > max_v) from = utf8_take_bytes(buf, -1, vl - max_v);
        fb_text(x + 3, y + 1, buf + from, col_text, -1);
        if (w->focus) {
            int vx = x + 3 + (vl - from) * 8;
            fb_text(vx, y + 1, "_", col_text, -1);
        }
        w->gx = x; w->gy = y; w->gw = bw; w->gh = 15;
        break;
    }
    case BRJS_W_SELECT: {
        brjs_copy(buf, (int)sizeof(buf) - 1, w->label, BRJS_LABEL_C);
        int lw = (int)utf8_count_chars(buf, -1);
        if (buf[0]) fb_text(x, y + 1, buf, col_dim, -1);
        x += (lw + 1) * 8;
        int box_c = BRJS_BOX_C;
        if ((cw - x - 4) / 8 < box_c) box_c = (cw - x - 4) / 8;
        if (box_c < 6) box_c = 6;
        int bw = box_c * 8 + 6;
        fb_fill_rect(x, y, bw, 15, col_box);
        fb_rect(x, y, bw, 15, col_bord);
        /* "< значение (i+1)/n >" */
        brjs_copy(buf, box_c - 6, w->value, -1);
        char line[BRJS_OPTION_MAX + 16];
        snprintf(line, sizeof(line), "< %s %d/%d >", buf,
                 w->sel + 1, w->noptions > 0 ? w->noptions : 1);
        fb_text(x + 3, y + 1, line, col_text, -1);
        w->gx = x; w->gy = y; w->gw = bw; w->gh = 15;
        break;
    }
    case BRJS_W_CHECK: {
        brjs_copy(buf, (int)sizeof(buf) - 1, w->label, 32);
        wm_checkbox_draw(x, y + 1, buf, w->value[0] == '1', col_text);
        int lw = (int)utf8_count_chars(buf, -1);
        w->gx = x; w->gy = y; w->gw = 16 + (lw + 1) * 8; w->gh = 15;
        break;
    }
    case BRJS_W_BUTTON: {
        brjs_copy(buf, (int)sizeof(buf) - 1, w->label, 24);
        int bw = ((int)utf8_count_chars(buf, -1) + 2) * 8;
        if (bw < 48) bw = 48;
        wm_button_draw(x, y + 1, bw, 14, buf,
                       wm_theme_sel_bg(), col_text, wm_theme_accent());
        w->gx = x; w->gy = y + 1; w->gw = bw; w->gh = 14;
        break;
    }
    case BRJS_W_OUTPUT: {
        /* блок вывода: строки текста (уже учтены в лейауте) */
        fb_fill_rect(0, y, cw - 8, w->rows * 16, fb_rgb(0x18, 0x1D, 0x24));
        int yy = y;
        int drawn = 0;
        const char *p = w->out;
        while (*p && drawn < w->rows) {
            const char *e = p;
            while (*e && *e != '\n') e++;
            int n = (int)(e - p);
            if (n > cw / 8 - 2) n = cw / 8 - 2;
            if (n > 0) {
                brjs_copy(buf, (int)sizeof(buf) - 1, p, n);
                fb_text(x, yy + 1, buf, col_dim, -1);
            }
            yy += 16;
            drawn++;
            p = (*e == '\n') ? e + 1 : e;
        }
        w->gx = 0; w->gy = y; w->gw = cw - 8; w->gh = w->rows * 16;
        break;
    }
    default:
        break;
    }
}



/* клавиатура в фокусе. Возвращает: 0 = не съедено, 1 = съедено
 * (перерисовать), 2 = съедено + событие input:<id> (Enter). */
static int brjs_key(brjs_page_t *js, const key_event_t *ev)
{
    if (js->focus < 0 || js->focus >= js->nw) return 0;
    brjs_widget_t *w = &js->w[js->focus];
    if (!w->used || (w->kind != BRJS_W_TEXT && w->kind != BRJS_W_NUMBER))
        return 0;

    if (ev->flags & KF_RELEASED) return 1;           /* отпускания съедаем */

    if (ev->code == 0x1C || ev->ch == '\n') {        /* Enter: событие */
        js->focus = -1;
        return 2;
    }
    if (ev->ch == 0x1B || ev->code == 0x01) {        /* Esc: без события */
        js->focus = -1;
        return 1;
    }
    if (ev->code == 0x0F) {                          /* Tab: следующий input */
        int n = js->nw;
        for (int k = 1; k <= n; k++) {
            int cand = (js->focus + k) % n;
            brjs_widget_t *q = &js->w[cand];
            if (q->used && (q->kind == BRJS_W_TEXT ||
                            q->kind == BRJS_W_NUMBER)) {
                js->focus = cand;
                return 1;
            }
        }
        js->focus = -1;
        return 1;
    }
    if (ev->code == 0x0E) {                          /* Backspace */
        int vl = (int)strlen(w->value);
        if (vl > 0) w->value[vl - 1] = 0;
        return 1;
    }
    if (ev->ch >= 0x20 && ev->ch < 0x7F && !(ev->flags & KF_CTRL)) {
        if (w->kind == BRJS_W_NUMBER &&
            !((ev->ch >= '0' && ev->ch <= '9') || ev->ch == '-' ||
              ev->ch == '+' || ev->ch == '.'))
            return 1;                                /* не цифра — мимо */
        int vl = (int)strlen(w->value);
        if (vl < BRJS_VALUE_MAX - 1) {
            w->value[vl] = (char)ev->ch;
            w->value[vl + 1] = 0;
        }
        return 1;
    }
    return 1;                                        /* прочие клавиши съедаем */
}

#endif /* BRJS_NO_ENGINE */

#endif /* BRJS_H */