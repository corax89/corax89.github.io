/* usb.c — компактный стек USB (UHCI + HID boot-protocol) для N2600-OS.
 *
 * Реализовано:
 *   1. PCI-сканирование: UHCI = class 0x0C, subclass 0x03, prog-if 0x00.
 *   2. Полноценный UHCI QH-stack: TD (32 байта), QH (8 байт), frame list
 *      (4 КиБ = 1024 элементов), вставка TD/QH в кадры.
 *   3. Control-трансферы: SETUP + DATA + STATUS — для дескрипторов
 *      и установки адреса/конфигурации.
 *   4. Перечисление: GetDescriptor(Device,8) @ addr=0 → SetAddress →
 *      GetDescriptor(Device,18) @ addr → GetDescriptor(Config) →
 *      SetConfiguration → для HID: SetIdle + SetProtocol(Boot).
 *   5. Interrupt-трансферы на EP1: вставляем TD в кадр каждые 8 позиций
 *      (каждые 8 мс). Из usb_poll() проверяем завершение, читаем отчёты
 *      (8 байт клавиатура, 4 байта мышь) и инжектим события в PS/2 ring
 *      (kbd.c и mouse.c) — WM «видит» USB-устройства как PS/2.
 *
 * НЕ реализовано (ограничение):
 *   - EHCI/XHCI (USB 2.0/3.0 hi-speed). Для hi-speed флешек нужен EHCI +
 *     bulk-трансферы + SCSI/BBB — в разы больше кода. См. usb_ehci.c.
 *   - Хабы (Hub class) — только порты рут-хаба UHCI (2 шт.).
 *   - USB прерывания — polling из главного цикла.
 *
 * Источники вдохновения: SanOS (Michael Ringgaard), HelenOS,
 * UHCI spec 1.0d (ftp://ftp.netbsd.org/pub/NetBSD/...).
 */
#include "usb.h"
#include "usb_ehci.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"

extern void serial_puts(const char *s);
extern void serial_putc(char c);

/* ---------- PCI конфигурация ---------- */

#define PCI_ADDR  0xCF8
#define PCI_DATA  0xCFC

u32 pci_read32(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return inl(PCI_DATA);
}

u16 pci_read16(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return (u16)((inl(PCI_DATA) >> ((reg & 2) * 8)) & 0xFFFF);
}

u8 pci_read8(int bus, int dev, int func, int reg)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    return (u8)((inl(PCI_DATA) >> ((reg & 3) * 8)) & 0xFF);
}

void pci_write32(int bus, int dev, int func, int reg, u32 val)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    outl(PCI_DATA, val);
}

void pci_write16(int bus, int dev, int func, int reg, u16 val)
{
    u32 addr = 0x80000000u | (bus << 16) | (dev << 11) | (func << 8) | (reg & 0xFC);
    outl(PCI_ADDR, addr);
    u32 old = inl(PCI_DATA);
    u32 shift = (reg & 2) * 8;
    u32 mask = 0xFFFFu << shift;
    u32 new = (old & ~mask) | (((u32)val) << shift);
    outl(PCI_DATA, new);
}

/* ---------- UHCI регистры ---------- */

#define UHCI_USBCMD     0x00
#define UHCI_USBSTS     0x02
#define UHCI_USBINTR    0x04
#define UHCI_FRNUM      0x06
#define UHCI_FRBASEADD  0x08
#define UHCI_SOFMOD     0x0C
#define UHCI_PORTSC1    0x10
#define UHCI_PORTSC2    0x12

#define USBCMD_GRESET   0x04
#define USBCMD_HCRESET  0x02
#define USBCMD_RS       0x01
#define USBCMD_FGBL     0x40
#define USBCMD_MAXP     0x80

#define USBSTS_HC_HALTED 0x20
#define USBSTS_USB_ERR   0x08
#define USBSTS_HOST_ERR  0x10
#define USBSTS_USB_INT   0x01

/* USBLEGSUP (PCI config offset 0xC0): биты 15:8 — SMI-enable (W1C),
 * бит 0 — "USB PIRQ Enable" (SMM/BIOS владеет HC). По порядку запуска
 * из Linux uhci_reset_hc(): сначала гасим SMI-биты, затем отбираем
 * владение у SMM. В VMware обычно 0, но проверка обязательна —
 * владелец-SMM молча душит расписание (TD не исполняются). */
#define UHCI_PCI_USBLEGSUP   0xC0
#define USBLEGSUP_RWC        0x8F00u   /* SMI-биты: W1C для очистки */
#define USBLEGSUP_HC_OWNED   0x0001u   /* HC в режиме PIRQ/BIOS */

#define PORTSC_CONNECT    0x0001
#define PORTSC_CONNECT_C  0x0002
#define PORTSC_ENABLE     0x0004
#define PORTSC_RESET      0x0200
#define PORTSC_LOWSPEED   0x0100
#define PORTSC_SUSPEND    0x1000

/* Transfer Descriptor — 32 байта, выравнивание 16 байт.
 * Layout соответствует UHCI spec (4 dword'а аппаратной части + 4 dword'а soft). */
typedef struct __attribute__((packed, aligned(16))) uhci_td {
    u32 link;        /* link pointer (бит 0 = term, бит 1 = QH, бит 2 = depth-first) */
    u32 ctrl_status;
    u32 token;
    u32 buffer;
    /* soft-поля (не hardware) */
    u32 done;         /* 1 = TD выполнен (для polling-логики) */
    u32 buf_phys;     /* физический адрес data-буфера */
    u32 next_td;      /* для программной цепочки */
    u32 reserved;
} uhci_td_t;

/* Queue Head — 16 байт (8 hardware + 8 padding), выравнивание 16.
 *
 * СЕССИЯ 31, ПРИЧИНА ПЕРЕРАБОТКИ: раньше control-трансфер писал
 * ГОЛЫЙ TD прямо в элементы frame list (bit1 = QH/TD = 0). По
 * спецификации это допустимо, НО по фактам лога VMware HC ни разу
 * не коснулся такого TD (cs остался ровно тем, что записал софт:
 * ACTIVE|IOC|CERR, ни одной ошибки). Все рабочие драйверы (Linux,
 * sanos) ведут расписание через QH: frame list → QH → цепочка TD.
 * Теперь так же здесь: каждый трансфер обёрнут в QH, элемент frame
 * list — указатель на QH (bit1 = 1). */
typedef struct __attribute__((packed, aligned(16))) uhci_qh {
    u32 head;         /* link to next QH/TD */
    u32 element;       /* link to first TD in queue */
    u32 pad1, pad2;
} uhci_qh_t;

/* Бит 2 link-указателя TD: Depth-first (VF). Как в Linux (UHCI_PTR_DEPTH):
 * HC может заранее выбрать следующий TD цепочки, пока исполняется
 * текущий; порядок транзакций не меняется, а “короткий пакет” в
 * DATA-стадии мы и так гасим обнулением ctrl_status хвоста. */
#define UHCI_LINK_VF   (1u << 2)
#define UHCI_LINK_QH   (1u << 1)
#define UHCI_LINK_TERM (1u << 0)

/* Флаги ctrl_status UHCI TD — сверено со спецификацией UHCI 1.1 и
 * эталонным Linux 6.6 (drivers/usb/host/uhci-hcd.h):
 *
 *   bit 29:     SPD  (Short Packet Detect) — программно НЕ ставим.
 *   bits 28:27: CERR (Error Counter) — 3 = до трёх повторов при
 *               CRC/таймауте (устройство имеет право молчать кадр).
 *   bit 26:     LS   (Low-Speed Device)
 *   bit 25:     IOS  (Isochronous Select)
 *   bit 24:     IOC  (Interrupt On Complete)
 *   bit 23:     Active
 *   --- далее статусы, которые пишет ТОЛЬКО контроллер (HC) ---
 *   bit 22:     Stalled
 *   bit 21:     Data Buffer Error
 *   bit 20:     Babble Detected
 *   bit 19:     NAK Received
 *   bit 18:     CRC/Time Out
 *   bit 17:     Bitstuff Error
 *   bits 10..0: Actual Length: (передано байт - 1), читается ((cs+1)&0x7FF)
 *
 * ИСТОРИЯ БАГА: раньше TD_CTRL_SPD был определён как (1u<<20) — это
 * БИТ BABBLE, статус, который HC пишет сам. Софт выставлял его в
 * КАЖДОМ SETUP/DATA TD, контроллер (VMware) видит «взведённую»
 * ошибку и не выполняет/бракует TD — отсюда get_descriptor failed.
 * SPD нужен только для interrupt-IN с ожиданием коротких пакетов
 * (как в Linux uhci-hcd.h: TD_CTRL_SPD = 1 << 29), на control-стадиях
 * он не нужен вовсе. */
#define TD_CTRL_SPD      (1u << 29)   /* Short Packet Detect (не используем) */
#define TD_CTRL_CERR     (3u << 27)   /* Error Counter = 3 повтора */
#define TD_CTRL_LS       (1u << 26)   /* Low-Speed Device */
#define TD_CTRL_IOC      (1u << 24)   /* Interrupt On Complete */
#define TD_CTRL_ACTIVE   (1u << 23)   /* TD Active */

/* Статусы HC — только для ЧТЕНИЯ софтом (ошибочный TD они бракуют) */
#define TD_CTRL_STALLED  (1u << 22)
#define TD_CTRL_DBUFERR  (1u << 21)
#define TD_CTRL_BABBLE   (1u << 20)
#define TD_CTRL_NAK      (1u << 19)
#define TD_CTRL_CRCTIMEO (1u << 18)
#define TD_CTRL_BITSTUFF (1u << 17)
#define TD_CTRL_ERRS     (TD_CTRL_STALLED | TD_CTRL_DBUFERR | TD_CTRL_BABBLE | \
                          TD_CTRL_CRCTIMEO | TD_CTRL_BITSTUFF)

#define TD_CTRL_SETUP  (TD_CTRL_ACTIVE | TD_CTRL_IOC | TD_CTRL_CERR)
#define TD_CTRL_DATA   (TD_CTRL_ACTIVE | TD_CTRL_IOC | TD_CTRL_CERR)
#define TD_CTRL_STATUS (TD_CTRL_ACTIVE | TD_CTRL_IOC | TD_CTRL_CERR)

/* PID'ы: UHCI использует значения как в спецификации — LS-first, инвертированные. */
#define PID_SETUP 0x2D
#define PID_IN    0x69
#define PID_OUT   0xE1

/* Token dword: PID[7:0], Addr[14:8], EP[15], Toggle D[19], MaxLen[31:21].
 * MaxLen = (len - 1) — сдвиг РОВНО 21, значение снаружи<<20 — ОШИБКА
 * (биты 20..16 — это toggle/reserved; в Linux: TD_TOKEN_EXPLEN_SHIFT 21,
 * uhci_explen(len) = ((len-1) & 0x7FF) << 21). */
static inline u32 uhci_make_token(u8 pid, u8 addr, u8 endp, int toggle, int len)
{
    return ((u32)pid) |
           ((u32)addr << 8) |
           ((u32)(endp & 0xF) << 15) |
           ((u32)(toggle ? 1 : 0) << 19) |
           ((u32)((len - 1) & 0x7FF) << 21);
}

/* ---------- дескрипторы USB ---------- */

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 bcdUSB;
    u8 bDeviceClass, bDeviceSubClass, bDeviceProtocol;
    u8 bMaxPacketSize0;
    u16 idVendor, idProduct, bcdDevice;
    u8 iManufacturer, iProduct, iSerial;
    u8 bNumConfigurations;
} usb_device_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 wTotalLength;
    u8 bNumInterfaces, bConfigValue, iConfiguration, bmAttributes;
    u8 bMaxPower;
} usb_config_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bInterfaceNumber, bAlternateSetting;
    u8 bNumEndpoints, bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol;
    u8 iInterface;
} usb_iface_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bEndpointAddress, bmAttributes;
    u16 wMaxPacketSize;
    u8 bInterval;
} usb_ep_desc_t;

/* ---------- найденные устройства ---------- */

#define USB_MAX_DEVICES 4

typedef enum {
    DEV_NONE = 0,
    DEV_KEYBOARD,
    DEV_MOUSE,
} dev_kind_t;

typedef struct {
    int      valid;
    int      port;           /* порт рут-хаба UHCI, на котором устройство (-1 = за хабом) */
    int      addr;           /* USB-адрес (после SET_ADDRESS) */
    int      low_speed;
    int      ep_in;          /* номер interrupt-IN endpoint (обычно 1) */
    int      ep_size;        /* max packet size для ep_in */
    int      ep_toggle;
    dev_kind_t kind;
    u8       last_report[8]; /* последний прочитанный отчёт (для дедупликации) */
    int      has_report;
    uhci_td_t *intr_td;      /* ПОСТОЯННЫЙ periodic TD (не-blocking poll) */
    uhci_qh_t *intr_qh;      /* обёртка-очередь: frame slots → QH → TD (сессия 31) */
    u8       *intr_buf;      /* буфер под interrupt-данные */
    int      intr_armed;     /* TD вставлен в frame list и ждёт */
    int      intr_base;      /* базовый кадр (slots каждые 16 кадров) */
    u32      intr_saved[64]; /* прежние значения элементов frame list */
} usb_dev_t;

static usb_dev_t usb_devices[USB_MAX_DEVICES];
static int usb_dev_count = 0;

/* ---------- контроллер ---------- */

typedef struct {
    int  valid;
    u16  iobase;
    int  bus, dev, func;      /* для диагностики PCI cmd (Bus Master) */
    u32 *frame_list;          /* 1024 физических указателя (4 КиБ) */
    u8  *frame_list_storage;  /* сохранённое выделение для free (если было выравнивание) */
} uhci_ctrl_t;

static uhci_ctrl_t uhci_ctrl;

/* Пул QH для control-трансферов и постоянных interrupt-очередей HID. */
#define USB_QH_POOL 8
static uhci_qh_t qh_pool[USB_QH_POOL];
static u8        qh_used[USB_QH_POOL];

static uhci_qh_t *qh_alloc(void)
{
    for (int i = 0; i < USB_QH_POOL; i++) {
        if (!qh_used[i]) {
            qh_used[i] = 1;
            memset(&qh_pool[i], 0, sizeof(uhci_qh_t));
            return &qh_pool[i];
        }
    }
    return NULL;
}

static void qh_free(uhci_qh_t *qh)
{
    if (!qh) return;
    for (int i = 0; i < USB_QH_POOL; i++) {
        if (&qh_pool[i] == qh) { qh_used[i] = 0; return; }
    }
}

static inline u32 qh_phys(uhci_qh_t *qh)
{
    return (u32)(unsigned long)qh;
}

/* Удержание: список TD, которые надо освободить после завершения. */
#define USB_TD_POOL 64
static uhci_td_t td_pool[USB_TD_POOL];
static u8 td_used[USB_TD_POOL];

static uhci_td_t *td_alloc(void)
{
    for (int i = 0; i < USB_TD_POOL; i++) {
        if (!td_used[i]) {
            td_used[i] = 1;
            memset(&td_pool[i], 0, sizeof(uhci_td_t));
            return &td_pool[i];
        }
    }
    return NULL;
}

static void td_free(uhci_td_t *td)
{
    if (!td) return;
    for (int i = 0; i < USB_TD_POOL; i++) {
        if (&td_pool[i] == td) { td_used[i] = 0; return; }
    }
}

static inline u32 td_phys(uhci_td_t *td)
{
    return (u32)(unsigned long)td;
}

static inline u16 uhci_in(u16 base, int reg) { return inw(base + reg); }
static inline void uhci_out(u16 base, int reg, u16 val) { outw(base + reg, val); }

/* Точная задержка по PIT-каналу 2 (работает и ДО sti — см. timer.h).
 * Старые volatile-циклы давали 0.2-0.5 мс там, где предполагалось 10 мс:
 * в VMware итерации летят на полной скорости хоста, на реальном Atom
 * цикл 100000 итераций ~0.3 мс. Слишком короткий сброс порта оставляет
 * устройство вне Default state — транзакции молчат (CRC/Time Out). */
static void uhci_udelay(u32 us)
{
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, us)) { }
}

/* Диагностика контроллера (одна строка на неудачную попытку перечисления):
 * cmd/sts/FRNUM (дважды, 10 мс apart — двигается ли счётчик кадров),
 * FRBASEADD (совпадает ли с нашим frame list), PCI command (включён ли
 * Bus Master), flist[0] (дошла ли запись в память расписания).
 * Классы отказов различаются однозначно:
 *   FRNUM заморожен            → HC не работает (RS/сброс/владение SMM);
 *   FRBASEADD != наш           → регистр не принят;
 *   PCI cmd без бита 2 (BME)   → DMA запрещён на шине;
 *   всё в порядке, TD не тронут → расписание не доходит/не исполняется. */
static void uhci_diag(const char *what)
{
    u16 iobase = uhci_ctrl.iobase;
    u16 cmd = uhci_in(iobase, UHCI_USBCMD);
    u16 sts = uhci_in(iobase, UHCI_USBSTS);
    u16 fn1 = uhci_in(iobase, UHCI_FRNUM) & 0x3FFu;
    uhci_udelay(10000);
    u16 fn2 = uhci_in(iobase, UHCI_FRNUM) & 0x3FFu;
    u32 frbase = inl(iobase + UHCI_FRBASEADD);
    u32 fl0 = uhci_ctrl.frame_list[0];
    u16 pcicmd = 0;
    if (uhci_ctrl.bus >= 0)
        pcicmd = pci_read16(uhci_ctrl.bus, uhci_ctrl.dev, uhci_ctrl.func, 0x04);

    char buf[160];
    snprintf(buf, sizeof(buf),
             "[usb] DIAG(%s): cmd=0x%04x sts=0x%04x%s%s frnum %u->%u frbase=0x%08x%s flist0=0x%08x pci_cmd=0x%04x%s\n",
             what, (unsigned)cmd, (unsigned)sts,
             (sts & USBSTS_HC_HALTED) ? " HC-HALTED" : "",
             (sts & USBSTS_HOST_ERR)  ? " HOST-SYS-ERR" : "",
             fn1, fn2,
             (unsigned)frbase,
             (frbase == (u32)(unsigned long)uhci_ctrl.frame_list) ? "" : " (!=flist)",
             (unsigned)fl0, (unsigned)pcicmd,
             (pcicmd & 0x04) ? "" : " NO-BUS-MASTER");
    serial_puts(buf);
}

/* Диагностика TD при ошибке/таймауте (только при перечислении —
 * чтобы не спамить serial в рабочем режиме). */
static void uhci_td_dump(const char *what, uhci_td_t *td, u32 cs)
{
    char buf[120];
    snprintf(buf, sizeof(buf),
             "[usb] %s: cs=0x%08x token=0x%08x%s%s%s%s%s\n",
             what, (unsigned)cs, (unsigned)td->token,
             (cs & TD_CTRL_STALLED)  ? " STALLED"  : "",
             (cs & TD_CTRL_DBUFERR)  ? " DBUFERR"  : "",
             (cs & TD_CTRL_BABBLE)   ? " BABBLE"   : "",
             (cs & TD_CTRL_CRCTIMEO) ? " CRC/TO"   : "",
             (cs & TD_CTRL_BITSTUFF) ? " BITSTUFF" : "");
    serial_puts(buf);
}

/* Ждать выполнения TD (до 100 мс). Возвращает число ПРИНЯТЫХ байт
 * (0..maxlen) или -1 (ошибка HC / таймаут).
 * Поллим ПАМЯТЬ TD (HC пишет статус по DMA; на x86 PCI-мастера
 * когерентны с кэшем CPU). Никаких inb в цикле: в VMware каждый
 * порт I/O — VM-exit, старый цикл из 50000 итераций выжигал до
 * сотен мс на каждый TD. */
static int uhci_wait_td(uhci_td_t *td)
{
    u32 dl = timer_poll_deadline();
    for (;;) {
        u32 cs = td->ctrl_status;
        if (!(cs & TD_CTRL_ACTIVE)) {
            if (cs & TD_CTRL_ERRS) {
                uhci_td_dump("TD error", td, cs);
                return -1;
            }
            if (cs & TD_CTRL_NAK)
                uhci_td_dump("TD done+NAK", td, cs);
            /* actual length: bits 10..0 = (n-1); 0x7FF = 0 байт.
             * Формула как в Linux: uhci_actual_length = (cs+1) & 0x7FF. */
            return (int)((cs + 1) & 0x7FFu);
        }
        if (timer_poll_expired(dl, 100000)) {   /* 100 мс */
            uhci_td_dump("TD timeout", td, cs);
            return -1;
        }
    }
}

/* ---------- инициализация контроллера ---------- */

static int uhci_init_one(int bus, int dev, int func)
{
    u32 bar4 = pci_read32(bus, dev, func, 0x20);
    if (bar4 == 0xFFFFFFFF || bar4 == 0) return 0;
    u16 iobase = (u16)(bar4 & 0xFFFC);

    uhci_ctrl.iobase = iobase;
    uhci_ctrl.bus = bus; uhci_ctrl.dev = dev; uhci_ctrl.func = func;

    /* Включаем Bus Master + I/O Space + Memory (для подстраховки) */
    u16 cmd = pci_read16(bus, dev, func, 0x04);
    cmd |= 0x07;     /* IOSE | MSE | BME */
    pci_write16(bus, dev, func, 0x04, cmd);

    /* Отбор владения у SMM/BIOS (Linux uhci_check_and_reset_hc):
     * 1) гасим SMI-enable биты (W1C); 2) сбрасываем "USB PIRQ Enable" —
     * иначе SMM-обработчик может перехватывать HC. */
    {
        u32 legsup = pci_read32(bus, dev, func, UHCI_PCI_USBLEGSUP);
        if (legsup != 0xFFFFFFFFu) {
            if (legsup & USBLEGSUP_RWC)
                pci_write32(bus, dev, func, UHCI_PCI_USBLEGSUP, legsup & USBLEGSUP_RWC);
            legsup = pci_read32(bus, dev, func, UHCI_PCI_USBLEGSUP);
            if (legsup & USBLEGSUP_HC_OWNED)
                pci_write32(bus, dev, func, UHCI_PCI_USBLEGSUP,
                            legsup & ~(u32)USBLEGSUP_HC_OWNED);
        }
    }

    /* Сброс контроллера: HCRESET самосбрасывающийся — ждём сброса бита
     * (до 5 мс), затем отпускаем HC. */
    uhci_out(iobase, UHCI_USBCMD, USBCMD_HCRESET);
    {
        u32 dl = timer_poll_deadline();
        while (uhci_in(iobase, UHCI_USBCMD) & USBCMD_HCRESET) {
            if (timer_poll_expired(dl, 5000)) break;    /* 5 мс */
        }
    }
    uhci_out(iobase, UHCI_USBCMD, 0);
    uhci_udelay(10000);                                  /* 10 мс после сброса */

    uhci_out(iobase, UHCI_USBSTS, 0xFFFF);

    /* Выделяем 8 КиБ под frame list + выравнивание до 4K */
    u8 *storage = (u8 *)malloc(8192 + 16);
    if (!storage) {
        serial_puts("[usb] no memory for frame list\n");
        return 0;
    }
    u32 aligned = ((u32)(unsigned long)storage + 0xFFF) & ~0xFFFu;
    u32 *flist = (u32 *)(unsigned long)aligned;

    uhci_ctrl.frame_list = flist;
    uhci_ctrl.frame_list_storage = storage;

    /* Терминируем все 1024 элементов как пустые (бит 0 = 1 = no link) */
    for (int i = 0; i < 1024; i++) flist[i] = 0x00000001u;

    /* Программируем FRBASEAD (32-битный физический адрес) */
    outl(iobase + UHCI_FRBASEADD, (u32)(unsigned long)flist);
    uhci_out(iobase, UHCI_FRNUM, 0);
    uhci_out(iobase, UHCI_SOFMOD, 64);    /* ~1ms SOF (7-битный регистр) */
    uhci_out(iobase, UHCI_USBINTR, 0);

    /* Включаем контроллер: Run (bit 0) + Configure Flag (bit 7).
     * ВАЖНО: НЕ устанавливать бит 6 (Forced Global Resume) — он затягивает HC
     * в режим resume, и TD'шки не исполняются. */
    uhci_out(iobase, UHCI_USBCMD, USBCMD_RS | USBCMD_MAXP);
    uhci_udelay(2000);

    /* Проверки запуска: HCHALTED=0 И счётчик кадров реально идёт
     * (RS без тикающего FRNUM = HC формально «работает», а расписание
     * не исполняется — именно такой режим давал «TD не тронут»). */
    {
        u16 sts = uhci_in(iobase, UHCI_USBSTS);
        u16 f1 = uhci_in(iobase, UHCI_FRNUM) & 0x3FFu;
        uhci_udelay(10000);
        u16 f2 = uhci_in(iobase, UHCI_FRNUM) & 0x3FFu;
        u32 frback = inl(iobase + UHCI_FRBASEADD);
        char buf[120];
        if (sts & USBSTS_HC_HALTED) {
            snprintf(buf, sizeof(buf), "[usb] WARN: HC halted after enable, sts=0x%x\n",
                     (unsigned)sts);
            serial_puts(buf);
        }
        if (f1 == f2) {
            snprintf(buf, sizeof(buf),
                     "[usb] WARN: FRNUM заморожен (%u), HC не исполняет кадры!\n",
                     (unsigned)f1);
            serial_puts(buf);
        }
        if (frback != (u32)(unsigned long)flist) {
            snprintf(buf, sizeof(buf),
                     "[usb] WARN: FRBASEADD readback 0x%x != 0x%x\n",
                     (unsigned)frback, (unsigned)(unsigned long)flist);
            serial_puts(buf);
        }
    }

    uhci_ctrl.valid = 1;

    char buf[80];
    snprintf(buf, sizeof(buf), "[usb] UHCI at 0x%x, frame_list=%p\n",
             (unsigned)iobase, (void *)(unsigned long)flist);
    serial_puts(buf);

    return 1;
}

static void uhci_scan_pci(void)
{
    uhci_ctrl.valid = 0;

    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                if ((id & 0xFFFF) == 0 || (id & 0xFFFF) == 0xFFFF) {
                    if (func == 0) break;
                    continue;
                }
                u32 class_code = pci_read32(bus, dev, func, 0x08);
                u8 base_class = (u8)((class_code >> 24) & 0xFF);
                u8 sub_class  = (u8)((class_code >> 16) & 0xFF);
                u8 prog_if    = (u8)((class_code >> 8)  & 0xFF);
                if (base_class == 0x0C && sub_class == 0x03 && prog_if == 0x00) {
                    char buf[80];
                    snprintf(buf, sizeof(buf),
                             "[usb] UHCI: bus=%d dev=%d func=%d\n",
                             bus, dev, func);
                    serial_puts(buf);
                    if (uhci_init_one(bus, dev, func)) {
                        return;
                    }
                }
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    serial_puts("[usb] no UHCI controller found\n");
}

/* ---------- порт-менеджмент ---------- */

/* Сброс порта рут-хаба UHCI по USB-спецификации:
 * RESET >= 10 мс (практика: 20 мс надёжнее), пауза стабилизации,
 * очистка CSC, PORTSC_ENABLE с проверкой. Возвращает 1, если после
 * сброса устройство всё ещё на порту. */
static int port_reset(u16 iobase, int port)
{
    int reg = UHCI_PORTSC1 + port * 2;
    u16 ps = uhci_in(iobase, reg);
    if (!(ps & PORTSC_CONNECT)) return 0;

    uhci_out(iobase, reg, (u16)(ps | PORTSC_RESET));
    uhci_udelay(20000);                              /* 20 мс сброс */
    uhci_out(iobase, reg, (u16)(uhci_in(iobase, reg) & ~PORTSC_RESET));
    uhci_udelay(20000);                              /* 20 мс стабилизации */

    ps = uhci_in(iobase, reg);
    if (!(ps & PORTSC_CONNECT)) return 0;            /* отвалился при сбросе */
    uhci_out(iobase, reg, (u16)(ps | PORTSC_CONNECT_C));  /* W1C: сбросить CSC */
    ps = uhci_in(iobase, reg);
    uhci_out(iobase, reg, (u16)(ps | PORTSC_ENABLE));
    uhci_udelay(5000);
    ps = uhci_in(iobase, reg);
    if (!(ps & PORTSC_ENABLE)) {                     /* повторная попытка enable */
        uhci_out(iobase, reg, (u16)(ps | PORTSC_ENABLE));
        uhci_udelay(5000);
        ps = uhci_in(iobase, reg);
    }
    return (ps & PORTSC_CONNECT) ? 1 : 0;
}

/* ---------- control-трансфер ---------- */

/* Стандартные запросы USB. */
typedef struct __attribute__((packed)) {
    u8 bmRequestType;
    u8 bRequest;
    u16 wValue;
    u16 wIndex;
    u16 wLength;
} usb_request_t;

/* Запланировать control-трансфер (SETUP + DATA + STATUS) в кадры.
 * max_pkt — max packet size EP0 УСТРОЙСТВА (bMaxPacketSize0): TD
 * нарезается ровно по нему. Для первого чтения дескриптора (8 байт)
 * передаётся 8, дальше — прочитанное bMaxPacketSize0.
 * Раньше чанки резались по 64: устройство с maxpkt0=8 на 18-байтный
 * запрос отвечает STALL/Babble (пакет больше его EP0), а короткий
 * пакет внутри длинного DATA-стейджа терял остаток данных.
 * Возвращает число ПРИНЯТЫХ байт (для data_in) или data_len (OUT), -1 = ошибка. */
/* Сессия 31: расписание control-трансфера ЧЕРЕЗ QH.
 *
 * QH кладётся в КАЖДЫЙ из 1024 элементов frame list (с сохранением и
 * восстановлением). Это дороже, чем 16 кадров, но устраняет целый класс
 * отказов: HC обязан наткнуться на очередь независимо от текущего номера
 * кадра, а пустой QH после завершения цепочки безвреден. Цепочка TD
 * (SETUP → DATA… → STATUS) вешается на element-указатель QH; ссылки
 * между TD — depth-first (VF=1), как в Linux. */
static u32 fl_saved[1024];          /* копия frame list на время трансфера */
static int  fl_busy = 0;

static int uhci_run_transfer(int addr, int low_speed, u8 *setup_buf,
                              void *data_buf, int data_len, int data_in,
                              int max_pkt)
{
    if (!uhci_ctrl.valid) return -1;
    if (fl_busy) return -1;         /* кооперативная модель: реентрантности нет */
    if (max_pkt < 8) max_pkt = 8;
    if (max_pkt > 64) max_pkt = 64;

    /* TD1: SETUP (8 байт, DATA0) */
    uhci_td_t *td_setup = td_alloc();
    /* TD2..n: DATA (toggle = 1, 0, 1, ... — чередуется после setup) */
    uhci_td_t *td_data_first = NULL, *td_data_last = NULL;
    /* TD_last: STATUS (zero-length, DATA1) */
    uhci_td_t *td_status = td_alloc();
    uhci_qh_t *qh = qh_alloc();

    if (!td_setup || !td_status || !qh) {
        td_free(td_setup); td_free(td_status); qh_free(qh);
        return -1;
    }

    /* Setup TD */
    td_setup->ctrl_status = TD_CTRL_SETUP;
    if (low_speed) td_setup->ctrl_status |= TD_CTRL_LS;
    td_setup->token = uhci_make_token(PID_SETUP, addr, 0, 0, 8);
    td_setup->buffer = (u32)(unsigned long)setup_buf;

    /* DATA-стейдж: чанки по max_pkt, тогглы чередуются с DATA1 */
    int toggle = 1;
    u8 *p = (u8 *)data_buf;
    int left = data_len;
    while (left > 0) {
        int chunk = left > max_pkt ? max_pkt : left;
        uhci_td_t *td = td_alloc();
        if (!td) {
            td_free(td_setup); td_free(td_status); qh_free(qh);
            for (uhci_td_t *t = td_data_first; t; ) {
                uhci_td_t *nx = (uhci_td_t *)(unsigned long)t->next_td;
                td_free(t); t = nx;
            }
            return -1;
        }
        td->ctrl_status = TD_CTRL_DATA;
        if (low_speed) td->ctrl_status |= TD_CTRL_LS;
        td->token = uhci_make_token(data_in ? PID_IN : PID_OUT, addr, 0, toggle, chunk);
        td->buffer = (u32)(unsigned long)p;
        td->next_td = 0;
        if (!td_data_first) td_data_first = td;
        else td_data_last->link = td_phys(td) | UHCI_LINK_VF;
        if (td_data_last) td_data_last->next_td = td_phys(td);
        td_data_last = td;
        toggle ^= 1;
        p += chunk;
        left -= chunk;
    }

    /* STATUS-стейдж: zero-length, противоположное направление, ВСЕГДА DATA1
     * (USB 2.0 spec 8.5.3). Zero-length в UHCI = MaxLen 0x7FF (2048):
     * при чтении (0x7FF+1)&0x7FF = 0 — нулевая длина. */
    td_status->ctrl_status = TD_CTRL_STATUS;
    if (low_speed) td_status->ctrl_status |= TD_CTRL_LS;
    {
        u32 pid = data_in ? PID_OUT : PID_IN;
        td_status->token = ((u32)pid) |
                           ((u32)addr << 8) |
                           ((u32)1 << 19) |     /* DATA1 */
                           (0x7FFu << 21);       /* zero-length */
    }
    td_status->buffer = 0;

    /* Цепочка TD: setup -> data... -> status -> terminate (ссылки VF=1) */
    if (td_data_first) {
        td_setup->link = td_phys(td_data_first) | UHCI_LINK_VF;
        td_data_last->link = td_phys(td_status) | UHCI_LINK_VF;
    } else {
        td_setup->link = td_phys(td_status) | UHCI_LINK_VF;
    }
    td_status->link = UHCI_LINK_TERM;

    /* QH: горизонтальная ссылка — terminate; element — первый TD */
    qh->head = UHCI_LINK_TERM;
    qh->element = td_phys(td_setup);            /* T=0, QH-bit=0 → TD */

    /* Подмена расписания: во ВСЕ кадры — наш QH (bit1 = QH) */
    fl_busy = 1;
    for (int i = 0; i < 1024; i++) {
        fl_saved[i] = uhci_ctrl.frame_list[i];
        uhci_ctrl.frame_list[i] = qh_phys(qh) | UHCI_LINK_QH;
    }
    uhci_udelay(2000);                 /* HC успел зайти в новый кадр */

    int received = 0;                  /* сколько байт реально принято */
    int failed = 0;
    int short_packet = 0;              /* устройство отдало меньше, чем просили */

    /* SETUP */
    if (uhci_wait_td(td_setup) < 0) {
        failed = 1;
    } else if (td_data_first) {
        /* DATA: ждём каждый TD; короткий пакет завершает стейдж досрочно */
        for (uhci_td_t *t = td_data_first; t && !failed; ) {
            int rr = uhci_wait_td(t);
            if (rr < 0) { failed = 1; break; }
            received += rr;
            if (data_in && rr < (int)(((t->token >> 21) & 0x7FFu) + 1))
                short_packet = 1;
            uhci_td_t *nx = (uhci_td_t *)(unsigned long)t->next_td;
            if (short_packet && nx) {
                /* отцепляем хвост: последний исполненный TD -> сразу STATUS */
                t->link = td_phys(td_status) | UHCI_LINK_VF;
                /* гасим оставшиеся DATA TD, если HC их уже где-то fetched */
                for (uhci_td_t *q = nx; q; q = (uhci_td_t *)(unsigned long)q->next_td)
                    q->ctrl_status = 0;
                nx = NULL;
            }
            t = nx;
        }
    }

    /* STATUS (даже при failed — попытка, устройство может ответить STALL) */
    if (!failed) (void)uhci_wait_td(td_status);

    /* Восстанавливаем frame list ЦЕЛИКОМ */
    for (int i = 0; i < 1024; i++)
        uhci_ctrl.frame_list[i] = fl_saved[i];
    fl_busy = 0;

    if (failed) {
        uhci_diag(data_in ? "ctrl-IN" : "ctrl-OUT");
    }

    int result;
    if (failed) result = -1;
    else if (data_in) result = received;
    else result = data_len;

    td_free(td_setup); td_free(td_status); qh_free(qh);
    for (uhci_td_t *t = td_data_first; t; ) {
        uhci_td_t *nx = (uhci_td_t *)(unsigned long)t->next_td;
        td_free(t); t = nx;
    }
    return result;
}

/* ---------- стандартные запросы USB ---------- */

static int usb_get_descriptor(int addr, int low_speed, u8 type, u8 idx,
                               void *buf, int len, int max_pkt)
{
    usb_request_t req;
    req.bmRequestType = 0x80;     /* IN, Standard, Device */
    req.bRequest = 6;             /* GET_DESCRIPTOR */
    req.wValue = (u16)((type << 8) | idx);
    req.wIndex = 0;
    req.wLength = (u16)len;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, buf, len, 1, max_pkt);
}

static int usb_set_address(int low_speed, u8 new_addr)
{
    usb_request_t req;
    req.bmRequestType = 0x00;     /* OUT, Standard, Device */
    req.bRequest = 5;             /* SET_ADDRESS */
    req.wValue = new_addr;
    req.wIndex = 0;
    req.wLength = 0;
    return uhci_run_transfer(0, low_speed, (u8 *)&req, 0, 0, 0, 8);
}

static int usb_set_configuration(int addr, int low_speed, u8 config)
{
    usb_request_t req;
    req.bmRequestType = 0x00;     /* OUT, Standard, Device */
    req.bRequest = 9;             /* SET_CONFIGURATION */
    req.wValue = config;
    req.wIndex = 0;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 8);
}

static int usb_set_idle(int addr, int low_speed, int ifc)
{
    usb_request_t req;
    req.bmRequestType = 0x21;     /* OUT, Class, Interface */
    req.bRequest = 0x0A;          /* SET_IDLE (HID class) */
    req.wValue = 0;
    req.wIndex = (u16)ifc;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 8);
}

static int usb_set_protocol_boot(int addr, int low_speed, int ifc)
{
    usb_request_t req;
    req.bmRequestType = 0x21;
    req.bRequest = 0x0B;          /* SET_PROTOCOL (HID class) */
    req.wValue = 0;               /* 0 = Boot Protocol */
    req.wIndex = (u16)ifc;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, 8);
}

/* ---------- поддержка USB-хабов ---------- */

/* forward declarations (определены ниже по файлу) */
static int  usb_fix_maxpkt0(int raw);
static void dispatch_keyboard(usb_dev_t *d, u8 *report);
static void dispatch_mouse(usb_dev_t *d, u8 *report);
static int g_next_addr = 1;   /* сквозная нумерация адресов (hot-plug без конфликтов) */

/* Forward declaration — parse_config_descriptor определена ниже. */
static void parse_config_descriptor(u8 *buf, int len, usb_dev_t *d);

/* Hub class requests (USB 2.0 spec section 11.24). */
#define HUB_GET_DESCRIPTOR  0x06   /* bRequest for GetDescriptor */
#define HUB_SET_FEATURE     0x03
#define HUB_CLEAR_FEATURE   0x01
#define HUB_GET_STATUS      0x00

#define HUB_FEATURE_PORT_RESET         4
#define HUB_FEATURE_PORT_POWER         8
#define HUB_FEATURE_C_PORT_CONNECT    16
#define HUB_FEATURE_C_PORT_RESET      20
#define HUB_FEATURE_C_PORT_ENABLE     17

static int usb_hub_get_descriptor(int addr, int low_speed, u8 *buf, int len, int max_pkt)
{
    usb_request_t req;
    req.bmRequestType = 0xA0;     /* IN, Class, Device */
    req.bRequest = HUB_GET_DESCRIPTOR;
    req.wValue = 0x2900;          /* descriptor type 0x29 = hub */
    req.wIndex = 0;
    req.wLength = (u16)len;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, buf, len, 1, max_pkt);
}

static int usb_hub_set_port_feature(int addr, int low_speed, int port, int feature, int max_pkt)
{
    usb_request_t req;
    req.bmRequestType = 0x23;     /* OUT, Class, Other (port) */
    req.bRequest = HUB_SET_FEATURE;
    req.wValue = (u16)feature;
    req.wIndex = (u16)port;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, max_pkt);
}

static int usb_hub_clear_port_feature(int addr, int low_speed, int port, int feature, int max_pkt)
{
    usb_request_t req;
    req.bmRequestType = 0x23;     /* OUT, Class, Other (port) */
    req.bRequest = HUB_CLEAR_FEATURE;
    req.wValue = (u16)feature;
    req.wIndex = (u16)port;
    req.wLength = 0;
    return uhci_run_transfer(addr, low_speed, (u8 *)&req, 0, 0, 0, max_pkt);
}

static int usb_hub_get_port_status(int addr, int low_speed, int port, u32 *status, int max_pkt)
{
    usb_request_t req;
    u8 buf[4];
    req.bmRequestType = 0xA3;     /* IN, Class, Other (port) */
    req.bRequest = HUB_GET_STATUS;
    req.wValue = 0;
    req.wIndex = (u16)port;
    req.wLength = 4;
    int r = uhci_run_transfer(addr, low_speed, (u8 *)&req, buf, 4, 1, max_pkt);
    if (r >= 4) {
        *status = (u32)buf[0] | ((u32)buf[1] << 8) |
                  ((u32)buf[2] << 16) | ((u32)buf[3] << 24);
        return 1;
    }
    return 0;
}

/* Перечислить устройства на портах USB-хаба.
 * hub_addr — USB-адрес хаба (уже присвоен после SetAddress);
 * hub_max_pkt — bMaxPacketSize0 самого хаба. */
static void enumerate_hub(int hub_addr, int hub_low_speed, int hub_max_pkt)
{
    if (!uhci_ctrl.valid) return;

    /* Читаем hub descriptor */
    u8 hdbuf[16];
    memset(hdbuf, 0, sizeof(hdbuf));
    int r = usb_hub_get_descriptor(hub_addr, hub_low_speed, hdbuf, sizeof(hdbuf), hub_max_pkt);
    if (r < 7) {
        serial_puts("[usb-hub] get_descriptor failed\n");
        return;
    }
    int nbr_ports = hdbuf[2];     /* bNbrPorts */
    char buf[80];
    snprintf(buf, sizeof(buf), "[usb-hub] hub @ addr %d: %d ports\n",
             hub_addr, nbr_ports);
    serial_puts(buf);

    /* Включаем питание на всех портах хаба */
    for (int p = 1; p <= nbr_ports; p++) {
        usb_hub_set_port_feature(hub_addr, hub_low_speed, p, HUB_FEATURE_PORT_POWER, hub_max_pkt);
    }
    uhci_udelay(100000);   /* 100 мс на стабилизацию питания */

    /* Перечисляем каждый порт */
    for (int p = 1; p <= nbr_ports; p++) {
        /* Проверим статус порта */
        u32 port_status = 0;
        if (!usb_hub_get_port_status(hub_addr, hub_low_speed, p, &port_status, hub_max_pkt)) {
            continue;
        }
        /* bit 0 = Current Connect Status (1 = device connected) */
        if (!(port_status & 0x01)) continue;

        /* Устройство подключено — сброс порта (10 мс минимум) */
        usb_hub_set_port_feature(hub_addr, hub_low_speed, p, HUB_FEATURE_PORT_RESET, hub_max_pkt);
        uhci_udelay(20000);                            /* 20 мс */
        usb_hub_clear_port_feature(hub_addr, hub_low_speed, p, HUB_FEATURE_C_PORT_RESET, hub_max_pkt);
        uhci_udelay(20000);                            /* 20 мс на reset-recovery */

        /* Проверим скорость: bit 9 = low-speed (0=full, 1=low) */
        usb_hub_get_port_status(hub_addr, hub_low_speed, p, &port_status, hub_max_pkt);
        int dev_low_speed = (port_status & (1 << 9)) ? 1 : 0;

        snprintf(buf, sizeof(buf),
                 "[usb-hub] port %d: device present (%s-speed)\n",
                 p, dev_low_speed ? "low" : "full");
        serial_puts(buf);

        /* Шаг 1: GetDescriptor(Device, 8 байт) @ addr 0 — ровно maxpkt 8 */
        u8 devbuf[64];
        memset(devbuf, 0, sizeof(devbuf));
        r = usb_get_descriptor(0, dev_low_speed, 1, 0, devbuf, 8, 8);
        if (r < 8) {
            serial_puts("[usb-hub] get_descriptor(8) failed\n");
            continue;
        }
        int max_pkt0 = usb_fix_maxpkt0(devbuf[7]);

        /* Назначаем новый адрес */
        if (usb_set_address(dev_low_speed, (u8)g_next_addr) < 0) {
            serial_puts("[usb-hub] set_address failed\n");
            continue;
        }
        int addr = g_next_addr++;
        uhci_udelay(5000);

        r = usb_get_descriptor(addr, dev_low_speed, 1, 0, devbuf, 18, max_pkt0);
        if (r < 18) continue;

        u8 cfgbuf[256];
        r = usb_get_descriptor(addr, dev_low_speed, 2, 0, cfgbuf, 9, max_pkt0);
        if (r < 9) continue;
        int cfg_total = cfgbuf[2] | (cfgbuf[3] << 8);
        if (cfg_total > 200) cfg_total = 200;
        usb_get_descriptor(addr, dev_low_speed, 2, 0, cfgbuf, cfg_total, max_pkt0);
        usb_set_configuration(addr, dev_low_speed, 1);

        if (usb_dev_count < USB_MAX_DEVICES) {
            usb_dev_t *d = &usb_devices[usb_dev_count];
            memset(d, 0, sizeof(*d));
            d->valid = 1;
            d->port = -1;                 /* за хабом — hot-plug не отслеживаем */
            d->addr = addr;
            d->low_speed = dev_low_speed;
            d->ep_in = 1;
            d->ep_size = max_pkt0;
            d->ep_toggle = 0;
            d->kind = DEV_NONE;
            d->has_report = 0;
            d->intr_buf = NULL;

            parse_config_descriptor(cfgbuf, cfg_total, d);

            if (d->kind != DEV_NONE) {
                usb_set_idle(addr, dev_low_speed, 0);
                usb_set_protocol_boot(addr, dev_low_speed, 0);
                d->intr_td = td_alloc();
                d->intr_buf = (u8 *)malloc(d->ep_size + 8);
                if (d->intr_buf) memset(d->intr_buf, 0, d->ep_size + 8);
                char kbuf[80];
                snprintf(kbuf, sizeof(kbuf),
                         "[usb-hub] HID device @ addr %d: %s, EP%d(%d bytes)\n",
                         addr, d->kind == DEV_KEYBOARD ? "keyboard" : "mouse",
                         d->ep_in, d->ep_size);
                serial_puts(kbuf);
            } else {
                char kbuf[80];
                snprintf(kbuf, sizeof(kbuf),
                         "[usb-hub] device @ addr %d (class=%d)\n",
                         addr, devbuf[4]);
                serial_puts(kbuf);
            }
            usb_dev_count++;
        }
    }
}

/* ---------- перечисление ---------- */

/* Перебираем конфигурацию и находим HID interface (class 3) + interrupt EP. */
static void parse_config_descriptor(u8 *buf, int len, usb_dev_t *d)
{
    int i = 0;
    int cur_iface = -1;
    u8 ep_addr = 0; u8 ep_attr = 0; u16 ep_size = 0; u8 ep_int = 0;
    (void)ep_int;   /* bInterval не используется (boot-интервал по умолчанию) */
    u8 iface_class = 0, iface_subclass = 0, iface_proto = 0;
    while (i + 2 <= len) {
        u8 dlen = buf[i];
        u8 dtyp = buf[i + 1];
        if (dlen == 0) break;
        if (dtyp == 4 && i + 9 <= len) {     /* INTERFACE */
            cur_iface = buf[i + 2];
            iface_class = buf[i + 5];
            iface_subclass = buf[i + 6];
            iface_proto = buf[i + 7];
        }
        else if (dtyp == 5 && i + 7 <= len) {  /* ENDPOINT */
            ep_addr = buf[i + 2];
            ep_attr = buf[i + 3];
            ep_size = (u16)(buf[i + 4] | (buf[i + 5] << 8));
            ep_int  = buf[i + 6];
            /* Если interrupt IN endpoint на текущем HID-интерфейсе — запомним */
            if ((ep_attr & 0x03) == 0x03 && (ep_addr & 0x80) && cur_iface >= 0 &&
                iface_class == 3 && iface_subclass == 1) {
                d->ep_in = ep_addr & 0x0F;
                d->ep_size = ep_size;
                /* Определяем тип по протоколу */
                if (iface_proto == 1) d->kind = DEV_KEYBOARD;
                else if (iface_proto == 2) d->kind = DEV_MOUSE;
            }
        }
        i += dlen;
    }
}

/* ---------- перечисление и горячее подключение ---------- */

/* bMaxPacketSize0 по спецификации = 8/16/32/64; некоторые устройства
 * кодируют 16/32/64 как 9/10/11 — приведём к реальному размеру. */
static int usb_fix_maxpkt0(int raw)
{
    if (raw == 9)  return 16;
    if (raw == 10) return 32;
    if (raw == 11) return 64;
    if (raw >= 8 && raw <= 64) return raw;
    return 8;   /* консервативный минимум */
}

/* Состояние каждого порта рут-хаба — конечный автомат hot-plug. */
typedef struct {
    u8  enumerated;   /* устройство перечислено и живо */
    u8  pending;      /* требуется (пере)перечисление */
    u8  fails;        /* подряд идущих неудач (>=5 — ждём переподключения) */
    u32 fail_stamp;   /* PIT-снимок последней неудачи (для паузы 1.5 с) */
} uhci_port_t;
static uhci_port_t uhci_ports[2];

/* Отключение устройства(й) на порту: гасим HID-опрос, освобождаем TD. */
static void usb_handle_disconnect(int port)
{
    for (int i = 0; i < usb_dev_count && i < USB_MAX_DEVICES; i++) {
        usb_dev_t *d = &usb_devices[i];
        if (!d->valid || d->port != port) continue;
        if (d->intr_armed && d->intr_td) {
            u32 slotval = qh_phys(d->intr_qh) | UHCI_LINK_QH;
            for (int k = 0, f = d->intr_base; k < 64; k++, f += 16) {
                f &= 0x3FF;
                if (uhci_ctrl.frame_list[f] == slotval)
                    uhci_ctrl.frame_list[f] = 0x00000001u;
            }
            d->intr_td->ctrl_status = 0;
            td_free(d->intr_td);
            qh_free(d->intr_qh);
            d->intr_td = NULL;
            d->intr_qh = NULL;
            d->intr_armed = 0;
        }
        d->valid = 0;
        d->intr_td = NULL;
        char buf[64];
        snprintf(buf, sizeof(buf),
                 "[usb] port %d: %s отключён\n",
                 port + 1,
                 d->kind == DEV_KEYBOARD ? "клавиатура" :
                 d->kind == DEV_MOUSE    ? "мышь" : "устройство");
        serial_puts(buf);
    }
    uhci_ports[port].enumerated = 0;
    uhci_ports[port].pending = 0;
    uhci_ports[port].fails = 0;
}

/* Одна попытка перечисления порта. Возвращает 1 при успехе. */
static int enumerate_port_once(u16 iobase, int port)
{
    if (!port_reset(iobase, port)) return 0;

    u16 ps = uhci_in(iobase, UHCI_PORTSC1 + port * 2);
    int low_speed = (ps & PORTSC_LOWSPEED) ? 1 : 0;

    char buf2[96];
    snprintf(buf2, sizeof(buf2),
             "[usb] port %d: device present (%s-speed)\n",
             port + 1, low_speed ? "low" : "full");
    serial_puts(buf2);

    /* Шаг 1: GetDescriptor(Device, 8 байт) @ addr 0, ровно maxpkt 8 */
    u8 devbuf[64];
    memset(devbuf, 0, sizeof(devbuf));
    int r = usb_get_descriptor(0, low_speed, 1, 0, devbuf, 8, 8);
    if (r < 8) {
        serial_puts("[usb] get_descriptor(8) failed\n");
        uhci_diag("get_desc8");
        return 0;
    }
    int max_pkt0 = usb_fix_maxpkt0(devbuf[7]);

    /* Шаг 2: SetAddress */
    if (usb_set_address(low_speed, (u8)g_next_addr) < 0) {
        serial_puts("[usb] set_address failed\n");
        return 0;
    }
    int addr = g_next_addr++;
    uhci_udelay(10000);   /* spec: 2 мс на восстановление, даём 10 */

    /* Шаг 3: GetDescriptor(Device, 18 байт) с РЕАЛЬНЫМ maxpkt0 */
    memset(devbuf, 0, sizeof(devbuf));
    r = usb_get_descriptor(addr, low_speed, 1, 0, devbuf, 18, max_pkt0);
    if (r < 18) {
        serial_puts("[usb] get_descriptor(18) failed\n");
        return 0;
    }

    {
        char ib[96];
        snprintf(ib, sizeof(ib),
                 "[usb] dev %04x:%04x class=%02x maxpkt0=%d addr=%d\n",
                 (unsigned)(devbuf[8] | (devbuf[9] << 8)),
                 (unsigned)(devbuf[10] | (devbuf[11] << 8)),
                 (unsigned)devbuf[4], max_pkt0, addr);
        serial_puts(ib);
    }

    /* Шаги 4-5: конфигурация */
    u8 cfgbuf[256];
    r = usb_get_descriptor(addr, low_speed, 2, 0, cfgbuf, 9, max_pkt0);
    if (r < 9) {
        serial_puts("[usb] get_descriptor(cfg) failed\n");
        return 0;
    }
    int cfg_total = cfgbuf[2] | (cfgbuf[3] << 8);
    if (cfg_total > 200) cfg_total = 200;
    if (cfg_total < 1) cfg_total = 9;
    usb_get_descriptor(addr, low_speed, 2, 0, cfgbuf, cfg_total, max_pkt0);

    /* Шаг 6: SetConfiguration(1) */
    usb_set_configuration(addr, low_speed, 1);

    if (usb_dev_count >= USB_MAX_DEVICES) return 1;

    /* Ищем свободный слот (после disconnect старые invalid) */
    usb_dev_t *d = NULL;
    for (int i = 0; i < USB_MAX_DEVICES; i++) {
        if (!usb_devices[i].valid) { d = &usb_devices[i]; break; }
    }
    if (!d) return 1;
    if (d == &usb_devices[usb_dev_count]) usb_dev_count++;

    memset(d, 0, sizeof(*d));
    d->valid = 1;
    d->port = port;
    d->addr = addr;
    d->low_speed = low_speed;
    d->ep_in = 1;
    d->ep_size = max_pkt0;
    d->ep_toggle = 0;
    d->kind = DEV_NONE;
    d->has_report = 0;
    d->intr_td = NULL;
    d->intr_buf = NULL;

    parse_config_descriptor(cfgbuf, cfg_total, d);

    if (d->kind != DEV_NONE) {
        usb_set_idle(addr, low_speed, 0);
        usb_set_protocol_boot(addr, low_speed, 0);
        d->intr_td = td_alloc();
        d->intr_buf = (u8 *)malloc(d->ep_size + 8);
        if (d->intr_buf) memset(d->intr_buf, 0, d->ep_size + 8);
        char kbuf[80];
        snprintf(kbuf, sizeof(kbuf), "[usb] HID device @ addr %d: %s, EP%d(%d bytes)\n",
                 addr, d->kind == DEV_KEYBOARD ? "keyboard" : "mouse",
                 d->ep_in, d->ep_size);
        serial_puts(kbuf);
    } else {
        char kbuf[80];
        snprintf(kbuf, sizeof(kbuf), "[usb] device @ addr %d (class=%d)\n",
                 addr, devbuf[4]);
        serial_puts(kbuf);

        /* Хаб (class 9) — перечисляем его порты */
        if (devbuf[4] == 9) {
            serial_puts("[usb] hub detected, enumerating ports...\n");
            enumerate_hub(addr, low_speed, max_pkt0);
        }
    }
    return 1;
}

/* Обслуживание портов: CSC-события, подключения/отключения, retry.
 * Вызывается из usb_poll (главный цикл) каждые ~16 итераций и
 * один раз из usb_init. Пауза между попытками — 1.5 с по PIT
 * (PIT-канал 2 работает и ДО sti — тики IRQ0 при загрузке ещё
 * не идут, поэтому timer_ticks() для паузы непригоден).
 * Максимум 5 подряд неудач — затем ждать переподключения (CSC). */
static void usb_service_ports(void)
{
    if (!uhci_ctrl.valid) return;
    u16 iobase = uhci_ctrl.iobase;

    for (int port = 0; port < 2; port++) {
        u16 ps = uhci_in(iobase, UHCI_PORTSC1 + port * 2);

        if (ps & PORTSC_CONNECT_C) {
            /* Событие изменения подключения */
            uhci_out(iobase, UHCI_PORTSC1 + port * 2,
                     (u16)(ps | PORTSC_CONNECT_C));     /* W1C */
            if (ps & PORTSC_CONNECT) {
                if (!uhci_ports[port].pending && !uhci_ports[port].enumerated)
                    serial_puts("[usb] hot-plug: устройство подключено\n");
                uhci_ports[port].pending = 1;
                uhci_ports[port].fails = 0;
            } else {
                usb_handle_disconnect(port);
                continue;
            }
            ps = uhci_in(iobase, UHCI_PORTSC1 + port * 2);
        }

        if (uhci_ports[port].enumerated && !(ps & PORTSC_CONNECT)) {
            /* устройство исчезло без CSC (бывают такие HC) */
            usb_handle_disconnect(port);
            continue;
        }

        if (!uhci_ports[port].pending) continue;
        if (uhci_ports[port].fails >= 5) continue;      /* до переподключения */
        /* пауза 1.5 с после неудачи */
        if (uhci_ports[port].fails > 0 &&
            !timer_poll_expired(uhci_ports[port].fail_stamp, 1500000))
            continue;

        int ok = enumerate_port_once(iobase, port);
        if (ok) {
            uhci_ports[port].pending = 0;
            uhci_ports[port].fails = 0;
            uhci_ports[port].enumerated = 1;
        } else {
            uhci_ports[port].fails++;
            uhci_ports[port].fail_stamp = timer_poll_deadline();
            if (uhci_ports[port].fails >= 5) {
                char b2[80];
                snprintf(b2, sizeof(b2),
                         "[usb] port %d: 5 неудач — жду переподключения\n",
                         port + 1);
                serial_puts(b2);
            }
        }
    }
}

/* Первоначальное перечисление (вызывается из usb_init до sti()). */
static void enumerate_ports(void)
{
    if (!uhci_ctrl.valid) return;
    u16 iobase = uhci_ctrl.iobase;

    for (int port = 0; port < 2; port++) {
        u16 ps = uhci_in(iobase, UHCI_PORTSC1 + port * 2);
        if (ps & PORTSC_CONNECT) {
            uhci_ports[port].pending = 1;
            /* погасить CSC, оставшийся с включения питания */
            uhci_out(iobase, UHCI_PORTSC1 + port * 2,
                     (u16)(ps | PORTSC_CONNECT_C));
        }
    }
    usb_service_ports();
}

/* ---------- опрос HID (НЕБЛОКИРУЮЩИЙ) ---------- */

/* Раньше usb_poll() на КАЖДУЮ итерацию главного цикла вставлял TD
 * в 8 кадров и ЖДАЛ завершения (>= 1 мс + циклы inb(0x80) — в VMware
 * до сотен мс): рабочий стол бы умер от одного найденного устройства.
 * Теперь у каждого HID-устройства есть ПОСТОЯННЫЙ TD, вставленный в
 * каждый 16-й кадр (62 Гц); usb_poll лишь заглядывает в его статус
 * (чтение памяти, без VM-exit). Пока устройство молчит, HC честно
 * NAK-ит при каждом проходе расписания — отчёт приходит максимум
 * через 16 мс после движения устройства. */

static void usb_intr_disarm(usb_dev_t *d)
{
    if (!d->intr_armed || !d->intr_td) return;
    u32 slotval = qh_phys(d->intr_qh) | UHCI_LINK_QH;
    for (int k = 0, f = d->intr_base; k < 64; k++, f += 16) {
        f &= 0x3FF;
        if (uhci_ctrl.frame_list[f] == slotval)
            uhci_ctrl.frame_list[f] = d->intr_saved[k];
    }
    d->intr_td->ctrl_status = 0;
    d->intr_armed = 0;
}

static void usb_intr_arm(usb_dev_t *d)
{
    if (!d->intr_td || !d->intr_buf) return;
    if (!d->intr_qh) {
        d->intr_qh = qh_alloc();
        if (!d->intr_qh) return;
    }
    d->intr_qh->head = UHCI_LINK_TERM;
    d->intr_qh->element = td_phys(d->intr_td);
    d->intr_td->link = UHCI_LINK_TERM;                  /* terminate */
    d->intr_td->ctrl_status = TD_CTRL_DATA;             /* ACTIVE|IOC|CERR */
    if (d->low_speed) d->intr_td->ctrl_status |= TD_CTRL_LS;
    d->intr_td->token = uhci_make_token(PID_IN, (u8)d->addr, (u8)d->ep_in,
                                        d->ep_toggle, d->ep_size);
    d->intr_td->buffer = (u32)(unsigned long)d->intr_buf;
    d->intr_td->next_td = 0;

    /* Периодический опрос: ОЧЕРЕДЬ (QH) в КАЖДОМ 16-м кадре (раз в 16 мс,
     * 62 Гц). Один слот не годится: после NAK HC вернётся к TD только когда
     * снова прочитает ЭТОТ элемент расписания — через 1024 кадра (1 с).
     * Устройство i живёт на кадрах (3 + 16*i) mod 1024 — до 4 устройств
     * без взаимных наложений. Контрольные трансферы временно подменяют
     * ВСЁ расписание (с восстановлением) — это безопасно. */
    int idx = (int)(d - usb_devices);
    if (idx < 0 || idx >= USB_MAX_DEVICES) idx = 0;
    d->intr_base = 3 + 16 * idx;
    u32 slotval = qh_phys(d->intr_qh) | UHCI_LINK_QH;
    for (int k = 0, f = d->intr_base; k < 64; k++, f += 16) {
        f &= 0x3FF;
        d->intr_saved[k] = uhci_ctrl.frame_list[f];
        uhci_ctrl.frame_list[f] = slotval;
    }
    d->intr_armed = 1;
}

static void usb_intr_poll(usb_dev_t *d)
{
    if (!d->intr_td) return;

    if (!d->intr_armed) {
        usb_intr_arm(d);        /* новая попытка (следующий тоггл после успеха) */
        return;
    }

    u32 cs = d->intr_td->ctrl_status;
    if (cs & TD_CTRL_ACTIVE)
        return;                 /* ещё ждёт/NAK — устройство молчит, норма */

    int n = (int)((cs + 1) & 0x7FFu);
    if (cs & TD_CTRL_ERRS || n <= 0 || n > d->ep_size) {
        /* ошибка (напр. STALL) или пусто: снять, перевооружить тем же тогглом */
        usb_intr_disarm(d);
        return;
    }

    /* Успешный отчёт */
    if (d->kind == DEV_KEYBOARD)      dispatch_keyboard(d, d->intr_buf);
    else if (d->kind == DEV_MOUSE)    dispatch_mouse(d, d->intr_buf);
    d->ep_toggle ^= 1;            /* устройство чередует DATA0/DATA1 */

    usb_intr_disarm(d);           /* следующий usb_poll перевооружит */
}

/* Распарсить 8-байтный отчёт USB-клавиатуры (boot-протокол):
 *   byte 0: modifiers (Ctrl/Shift/Alt/etc.)
 *   byte 1: reserved
 *   bytes 2..7: pressed key codes (HID usage table)
 * Преобразуем HID usage в ASCII/PS2 scan-code и складываем в kbd ring. */
static void dispatch_keyboard(usb_dev_t *d, u8 *report)
{
    /* Дедупликация: если отчёт идентичен предыдущему — пропускаем */
    if (d->has_report && memcmp(d->last_report, report, 8) == 0) return;
    /* Найдём новые нажатые клавиши (есть в новом, нет в старом) */
    for (int i = 2; i < 8; i++) {
        u8 code = report[i];
        if (code == 0) continue;
        /* Пропускаем, если уже была нажата */
        int already = 0;
        if (d->has_report) {
            for (int j = 2; j < 8; j++) {
                if (d->last_report[j] == code) { already = 1; break; }
            }
        }
        if (already) continue;
        /* HID usage → простейший ASCII (US раскладка) */
        /* 0x04..0x1D = a..z; 0x1E..0x27 = 1..0 */
        u8 ch = 0, scancode = 0;
        if (code >= 0x04 && code <= 0x1D) {
            ch = (u8)('a' + (code - 0x04));
            scancode = (u8)(code - 0x04 + 0x1E);
        } else if (code >= 0x1E && code <= 0x27) {
            ch = (u8)('1' + (code - 0x1E));
            if (code == 0x27) ch = '0';
            scancode = (u8)(code - 0x1E + 0x02);
        } else if (code == 0x28) { ch = '\n'; scancode = 0x1C; }
        else if (code == 0x29) { ch = 0; scancode = 0x01; }     /* Esc */
        else if (code == 0x2A) { ch = '\b'; scancode = 0x0E; }
        else if (code == 0x2B) { ch = '\t'; scancode = 0x0F; }
        else if (code == 0x2C) { ch = ' '; scancode = 0x39; }
        else if (code == 0x65 || code == 0x66) {
            /* Win-клавиши (LeftGUI/RightGUI) -> виртуальные коды:
             * открывают/закрывают меню Пуск (release USB не шлёт) */
            ch = 0;
            scancode = (code == 0x65) ? KBD_LWIN : KBD_RWIN;
        }
        /* Модификаторы (byte 0): Shift=0x22, Ctrl=0x11, Alt=0x44 */
        u8 mod = report[0];
        u8 flags = 0;
        if (mod & 0x22) flags |= 0x02;     /* Shift */
        if (mod & 0x11) flags |= 0x04;     /* Ctrl */
        if (mod & 0x44) flags |= 0x08;     /* Alt */
        if (ch >= 'a' && ch <= 'z' && (flags & 0x02)) ch = (u8)(ch - 'a' + 'A');
        (void)scancode;

        /* Пушим в kbd ring через публичный API */
        kbd_push_event(scancode, (char)ch, flags);
    }
    memcpy(d->last_report, report, 8);
    d->has_report = 1;
}

/* Распарсить 4-байтный отчёт USB-мыши (boot-протокол):
 *   byte 0: buttons (bit 0=left, 1=right, 2=middle)
 *   bytes 1, 2: dx, dy (signed 8-bit)
 *   byte 3: wheel */
static void dispatch_mouse(usb_dev_t *d, u8 *report)
{
    extern volatile int ms_x, ms_y, ms_event;
    extern volatile u8  ms_buttons;
    extern volatile u8  ms_click_latch;   /* latch нажатий (сессия 31, см. mouse.c) */
    static u8 prev = 0;
    int dx = (int)(i8)report[1];
    int dy = (int)(i8)report[2];
    int nx = ms_x + dx;
    int ny = ms_y - dy;     /* PS/2: плюс по Y = вверх */
    if (nx < 0) nx = 0;
    if (ny < 0) ny = 0;
    if (nx > (int)fb_width() - 1) nx = (int)fb_width() - 1;
    if (ny > (int)fb_height() - 1) ny = (int)fb_height() - 1;
    ms_x = nx;
    ms_y = ny;
    u8 nb = (u8)(report[0] & 0x07);
    ms_click_latch |= (u8)(nb & (u8)~prev);   /* 0->1 — гарантированный клик */
    prev = nb;
    ms_buttons = nb;
    ms_event = 1;
    (void)d;
}

void usb_poll(void)
{
    if (!uhci_ctrl.valid) return;

    /* Горячее подключение: два inw раз в ~16 итераций главного цикла
     * (~0.15 с при 100 Гц главного цикла). Дёшево и без блокировок. */
    {
        static u16 hp_div = 0;
        if ((++hp_div & 0x0Fu) == 0)
            usb_service_ports();
    }

    for (int i = 0; i < usb_dev_count && i < USB_MAX_DEVICES; i++) {
        usb_dev_t *d = &usb_devices[i];
        if (!d->valid || d->kind == DEV_NONE) continue;
        if (!d->intr_buf) continue;
        usb_intr_poll(d);   /* неблокирующе: статус/приём/перевооружение */
    }
}

/* ---------- API ---------- */

int usb_keyboard_present(void)
{
    for (int i = 0; i < usb_dev_count; i++) {
        if (usb_devices[i].valid && usb_devices[i].kind == DEV_KEYBOARD) return 1;
    }
    return 0;
}

int usb_mouse_present(void)
{
    for (int i = 0; i < usb_dev_count; i++) {
        if (usb_devices[i].valid && usb_devices[i].kind == DEV_MOUSE) return 1;
    }
    return 0;
}

int usb_controllers_found(void)
{
    return uhci_ctrl.valid ? 1 : 0;
}

int usb_devices_found(void)
{
    int n = 0;
    for (int i = 0; i < usb_dev_count && i < USB_MAX_DEVICES; i++)
        if (usb_devices[i].valid) n++;
    return n;
}

/* ---------- EHCI-детекция перенесена в usb_ehci.c ---------- */

void usb_init(void)
{
    usb_dev_count = 0;
    memset(usb_devices, 0, sizeof(usb_devices));
    memset(td_used, 0, sizeof(td_used));
    memset(qh_used, 0, sizeof(qh_used));
    memset(&uhci_ctrl, 0, sizeof(uhci_ctrl));
    memset(uhci_ports, 0, sizeof(uhci_ports));
    fl_busy = 0;
    g_next_addr = 1;

    serial_puts("[usb] init...\n");
    uhci_scan_pci();
    if (uhci_ctrl.valid) {
        enumerate_ports();
        int found = usb_devices_found();
        if (found > 0) {
            char buf[80];
            snprintf(buf, sizeof(buf), "[usb] %d device(s) found\n", found);
            serial_puts(buf);
        }
    }
    /* Инициализируем EHCI (полноценный драйвер с bulk-трансферами). */
    usb_ehci_init();
}
