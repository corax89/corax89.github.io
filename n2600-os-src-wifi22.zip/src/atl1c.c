/* atl1c.c — Atheros/Qualcomm L1c/L2c PCI-E Ethernet — порт Linux atl1c (GPLv2).
 *
 * ИСТОЧНИК: Linux drivers/net/ethernet/atheros/atl1c/ (v6.1):
 *   atl1c_main.c  — reset_pcie/pcie_patch, reset_mac, configure(_mac/_des_ring/
 *                   _tx/_rx/_dma), start_mac, кадры TX/RX
 *   atl1c_hw.c    — phy_reset/phy_init, MDIO, чтение MAC (TWSI/OTP)
 *   atl1c_hw.h    — регистры и биты
 *
 * Устройство: сетевая карта ASUS Eee PC X101CH — Atheros AR8152 v2.0
 * (PCI 1969:2062, семейство L2CB; AROS HCL: «Flare X101CH ... Atheros l1c 2.0»).
 * Поддержаны и остальные чипы семейства (1062/1063/2062/1073/1083).
 *
 * Отличия от эталона (упрощения для polling-ОС без прерываний):
 *   - IMR=0: приём/передача опрашиваются дескрипторами (RRS.UPDATED,
 *     TPD CIDX), как остальные NIC-драйверы этой ОС;
 *   - без NAPI/skb: пакеты копируются в статические буферы;
 *   - без checksum offload / TSO / VLAN / WoL / EEE (кроме отключения
 *     EEE для L2CB2 — это влияет на стабильность линии);
 *   - задержки калибруются по PIT каналу 2 (init идёт ДО sti()).
 *
 * Схема колец (как в эталоне):
 *   TPD (tx)  16 байт/дескриптор: buffer_len, vlan, word1(EOP), addr64
 *   RFD (rx free) 8 байт: addr64 — адрес буфера приёма
 *   RRD (rx return) 16 байт: word0(rfd_num/rfd_index), rss, vlan,
 *             flag, word3(PKT_SIZE|RX_ERR|UPDATED)
 *   HW берёт RFD по producer-индексу (MB_RFD0_PROD_IDX), отдаёт кадр
 *   в буфер и пишет RRD; мы чистим RRD (снимаем UPDATED), пере-
 *   вооружаем RFD и двигаем producer.
 */
#include "atl1c.h"
#include "io.h"
#include "pci.h"
#include "string.h"
#include "mem.h"
#include "timer.h"  /* [PIT2-RESYNC] после калибровки канала 2 */

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);

/* ============================ регистры (atl1c_hw.h) ==================== */

#define REG_TWSI_CTRL            0x218
#define REG_PCIE_PHYMISC         0x1000
#define REG_PCIE_PHYMISC2        0x1004
#define REG_OTP_CTRL             0x12F0
#define REG_PM_CTRL              0x12F8
#define REG_LTSSM_ID_CTRL        0x12FC
#define REG_MASTER_CTRL          0x1400
#define REG_IRQ_MODRT_TIMER_INIT 0x1408
#define REG_GPHY_CTRL            0x140C
#define REG_IDLE_STATUS          0x1410
#define REG_MDIO_CTRL            0x1414
#define REG_SERDES               0x1424
#define REG_LPI_CTRL             0x1440
#define REG_MDIO_EXTN            0x1448
#define REG_MAC_CTRL             0x1480
#define REG_MAC_STA_ADDR         0x1488
#define REG_RX_HASH_TABLE        0x1490
#define REG_MTU                  0x149c
#define REG_WOL_CTRL             0x14a0
#define REG_LOAD_PTR             0x1534
#define REG_RX_BASE_ADDR_HI      0x1540
#define REG_TX_BASE_ADDR_HI      0x1544
#define REG_RFD0_HEAD_ADDR_LO    0x1550
#define REG_RFD_RING_SIZE        0x1560
#define REG_RX_BUF_SIZE          0x1564
#define REG_RRD0_HEAD_ADDR_LO    0x1568
#define REG_RRD_RING_SIZE        0x1578
#define REG_TPD_PRI0_ADDR_LO     0x1580
#define REG_TPD_RING_SIZE        0x1584
#define REG_TXQ_CTRL             0x1590
#define REG_TX_TSO_OFFLOAD_THRESH 0x1594
#define REG_RXQ_CTRL             0x15A0
#define REG_DMA_CTRL             0x15C0
#define REG_SMB_STAT_TIMER       0x15C4
#define REG_MB_RFD0_PROD_IDX     0x15E0
#define REG_TPD_PRI0_PIDX        0x15F2   /* 16 бит: TX producer */
#define REG_TPD_PRI0_CIDX        0x15F6   /* 16 бит: TX consumer (читает HW) */
#define REG_ISR                  0x1600
#define REG_IMR                  0x1604
#define REG_INT_RETRIG_TIMER     0x1608
#define REG_CLK_GATING_CTRL      0x1814

/* MASTER_CTRL */
#define MASTER_CTRL_INT_RDCLR    (1u << 14)
#define MASTER_CTRL_CLK_SEL_DIS  (1u << 12)
#define MASTER_CTRL_SA_TIMER_EN  (1u << 7)
#define MASTER_CTRL_OOB_DIS      (1u << 6)
#define MASTER_CTRL_WAKEN_25M    (1u << 5)
#define MASTER_CTRL_TX_ITIMER_EN (1u << 15)
#define MASTER_CTRL_RX_ITIMER_EN (1u << 16)
#define MASTER_CTRL_SOFT_RST     (1u << 0)

/* GPHY_CTRL */
#define GPHY_CTRL_PWDOWN_HW      (1u << 14)
#define GPHY_CTRL_SEL_ANA_RST    (1u << 12)
#define GPHY_CTRL_HIB_PULSE      (1u << 11)
#define GPHY_CTRL_HIB_EN         (1u << 10)
#define GPHY_CTRL_PHY_IDDQ       (1u << 7)
#define GPHY_CTRL_GATE_25M_EN    (1u << 5)
#define GPHY_CTRL_EXT_RESET      (1u << 0)
#define GPHY_CTRL_EXT_RST_TO     80       /* 800 мкс */

/* IDLE_STATUS */
#define IDLE_STATUS_RXQ_BUSY     (1u << 2)
#define IDLE_STATUS_TXQ_BUSY     (1u << 3)
#define IDLE_STATUS_RXMAC_BUSY   (1u << 0)
#define IDLE_STATUS_TXMAC_BUSY   (1u << 1)
#define IDLE_STATUS_MASK         0x0000000Fu

/* MDIO_CTRL */
#define MDIO_CTRL_MODE_EXT       (1u << 30)
#define MDIO_CTRL_BUSY           (1u << 27)
#define MDIO_CTRL_CLK_SEL_M      0x7u
#define MDIO_CTRL_CLK_SEL_S      24
#define MDIO_CTRL_CLK_25_4       0
#define MDIO_CTRL_CLK_25_128     7
#define MDIO_CTRL_START          (1u << 23)
#define MDIO_CTRL_SPRES_PRMBL    (1u << 22)
#define MDIO_CTRL_OP_READ        (1u << 21)
#define MDIO_CTRL_REG_M          0x1Fu
#define MDIO_CTRL_REG_S          16
#define MDIO_CTRL_DATA_S         0
#define MDIO_EXTN_DEVAD_M        0x1Fu
#define MDIO_EXTN_DEVAD_S        16
#define MDIO_MAX_AC_TO           120

/* SERDES (только l2c_b/l2c_b2/l1d_2) */
#define SERDES_PHY_CLK_SLOWDOWN  (1u << 19)
#define SERDES_MAC_CLK_SLOWDOWN  (1u << 18)

/* MAC_CTRL */
#define MAC_CTRL_PROMIS_EN       (1u << 31)
#define MAC_CTRL_SPEED_MODE_SW   (1u << 30)
#define MAC_CTRL_HASH_ALG_CRC32  (1u << 29)
#define MAC_CTRL_SINGLE_PAUSE_EN (1u << 28)
#define MAC_CTRL_MC_ALL_EN       (1u << 27)
#define MAC_CTRL_BC_EN           (1u << 26)
#define MAC_CTRL_SPEED_S         20
#define MAC_CTRL_SPEED_10_100    1
#define MAC_CTRL_SPEED_1000      2
#define MAC_CTRL_PRMLEN_M        0xFu
#define MAC_CTRL_PRMLEN_S        10
#define MAC_CTRL_PAD             (1u << 7)
#define MAC_CTRL_ADD_CRC         (1u << 6)
#define MAC_CTRL_DUPLX           (1u << 5)
#define MAC_CTRL_RX_FLOW         (1u << 3)
#define MAC_CTRL_TX_FLOW         (1u << 2)
#define MAC_CTRL_RX_EN           (1u << 1)
#define MAC_CTRL_TX_EN           (1u << 0)

/* TXQ_CTRL */
#define TXQ_TXF_BURST_NUM_M      0xFFFFu
#define TXQ_TXF_BURST_NUM_S      16
#define L1C_TXQ_TXF_BURST_PREF   0x200
#define L2CB_TXQ_TXF_BURST_PREF  0x40
#define TXQ_CTRL_LS_8023_EN      (1u << 7)
#define TXQ_CTRL_ENH_MODE        (1u << 6)
#define TXQ_CTRL_IP_OPTION_EN    (1u << 4)
#define TXQ_CTRL_EN              (1u << 5)
#define TXQ_NUM_TPD_BURST_M      0xFu
#define TXQ_NUM_TPD_BURST_S      0
#define TXQ_NUM_TPD_BURST_DEF    5

/* RXQ_CTRL */
#define RXQ_RFD_BURST_NUM_M      0x3F
#define RXQ_RFD_BURST_NUM_S      20
#define RXQ_CTRL_EN              (1u << 31)

/* DMA_CTRL */
#define DMA_CTRL_RORDER_MODE_M   7u
#define DMA_CTRL_RORDER_MODE_S   0
#define DMA_CTRL_RORDER_MODE_OUT 4
#define DMA_CTRL_RREQ_PRI_DATA   (1u << 10)
#define DMA_CTRL_RREQ_BLEN_M     7u
#define DMA_CTRL_RREQ_BLEN_S     4
#define DMA_CTRL_WDLY_CNT_M      0xFu
#define DMA_CTRL_WDLY_CNT_S      16
#define DMA_CTRL_WDLY_CNT_DEF    4
#define DMA_CTRL_RDLY_CNT_M      0x1Fu
#define DMA_CTRL_RDLY_CNT_S      11
#define DMA_CTRL_RDLY_CNT_DEF    15

#define RFD_RING_SIZE_M          0x0FFF
#define RX_BUF_SIZE_M            0xFFFF
#define RRD_RING_SIZE_M          0x0FFF
#define TPD_RING_SIZE_M          0xFFFF
#define MB_RFDX_PROD_IDX_M       0xFFFF
#define TX_TSO_OFFLOAD_THRESH_M  0x07FF

/* RRS (RRD word0/word3) */
#define RRS_RX_RFD_CNT_M         0x000F
#define RRS_RX_RFD_CNT_S         16
#define RRS_RX_RFD_INDEX_M       0x0FFF
#define RRS_RX_RFD_INDEX_S       20
#define RRS_PKT_SIZE_M           0x3FFF
#define RRS_RX_ERR_SUM           0x00100000
#define RRS_802_3_LEN_ERR        0x40000000
#define RRS_RXD_UPDATED          0x80000000

/* TPD word1 */
#define TPD_EOP_S                31
#define TPD_ETH_TYPE_S           17       /* 1 = Ethernet II */

/* MII (linux/mii.h, стандартные) */
#define MII_BMCR                 0x00
#define MII_BMSR                 0x01
#define MII_PHYSID1              0x02
#define MII_PHYSID2              0x03
#define MII_ADVERTISE            0x04
#define MII_CTRL1000             0x09
#define MII_GIGA_PSSR            0x11
#define MII_IER                  0x12
#define MII_DBG_ADDR             0x1D
#define MII_DBG_DATA             0x1E
#define BMCR_RESET               0x8000
#define BMCR_ANENABLE            0x1000
#define BMCR_ANRESTART           0x0200
#define BMSR_LSTATUS             0x0004
#define BMSR_ANEGCOMPLETE        0x0020
#define ADVERTISE_10HALF         0x0020
#define ADVERTISE_10FULL         0x0040
#define ADVERTISE_100HALF        0x0080
#define ADVERTISE_100FULL        0x0100
#define GIGA_ADVERTISE_1000HALF  0x0100
#define GIGA_ADVERTISE_1000FULL  0x0200
#define GIGA_PSSR_SPD_DPLX_RESOLVED 0x0800
#define GIGA_PSSR_DPLX           0x2000
#define GIGA_PSSR_SPEED          0xC000
#define GIGA_PSSR_100MBS         0x4000
#define GIGA_PSSR_1000MBS        0x8000
#define IER_LINK_UP              0x0400
#define IER_LINK_DOWN            0x0800

/* PHY debug registers (через MII_DBG_ADDR/DATA) */
#define MIIDBG_CFGLPSPD          0x0A
#define MIIDBG_HIBNEG            0x0B
#define MIIDBG_TST10BTCFG        0x12
#define MIIDBG_LEGCYPS           0x29
#define MIIDBG_TST100BTCFG       0x36
#define MIIDBG_VOLT_CTRL         0x3B
#define MIIDBG_CABLE1TH_DET      0x3E
#define MIIDBG_SYSMODCTRL        0x04
#define MIIDBG_ANACTRL           0x00
#define MIIDBG_SRDSYSMOD         0x05

/* MII extension (EEE off для l2cb2/l1d_2) */
#define MIIEXT_ANEG              7
#define MIIEXT_LOCAL_EEEADV      0x3C
#define MIIEXT_PCS               3
#define MIIEXT_CLDCTRL3          0x8003
#define L2CB_CLDCTRL3            0x4D19

/* PHY dbg значения (atl1c_hw.h) */
#define ANACTRL_DEF              0x02EF
#define SRDSYSMOD_DEF            0x2C46
#define TST10BTCFG_DEF           0x4C04
#define TST100BTCFG_DEF          0xE12C
#define TST100BTCFG_LITCH_EN     0x80
#define L1C_LEGCYPS_DEF          0x36DD
#define SYSMODCTRL_IECHOADJ_DEF  0x88BB
#define CFGLPSPD_RSTCNT_CLK125SW 0x1000
#define CABLE1TH_DET_EN          0x8000
#define VOLT_CTRL_SWLOWEST       0x0003
#define LEGCYPS_EN               0x0080
#define HIBNEG_PSHIB_EN          0x8000
#define LPI_CTRL_EN              (1u << 0)

/* TWSI / OTP (чтение MAC) */
#define TWSI_CTRL_SW_LDSTART     (1u << 18)
#define AT_TWSI_EEPROM_TIMEOUT   100
#define OTP_CTRL_CLK_EN          (1u << 0)
#define L2CB_V10                 0xC0
#define L2CB_V21                 0xC1

/* ============================ размеры ================================== */

#define ATL1C_TX_COUNT    32
#define ATL1C_RX_COUNT    64
#define ATL1C_RX_BUF_SZ   1600          /* ≥ 1522 (ETH+VLAN+FCS) */
#define ATL1C_TX_BUF_SZ   1600
#define AT_RX_BUF_SIZE    1522

typedef struct __attribute__((packed)) {
    u16 buffer_len;
    u16 vlan_tag;
    u32 word1;
    u64 buffer_addr;
} atl1c_tpd_t;                          /* 16 байт */

typedef struct __attribute__((packed)) {
    u64 buffer_addr;
} atl1c_rfd_t;                          /* 8 байт */

typedef struct __attribute__((packed)) {
    u32 word0;
    u32 rss_hash;
    u16 vlan_tag;
    u16 flag;
    u32 word3;
} atl1c_rrd_t;                          /* 16 байт */

/* ============================ состояние ================================ */

enum { NIC_L2C = 0, NIC_L1C, NIC_L2CB, NIC_L2CB2, NIC_L1D, NIC_L1D_2 };

static struct {
    int      present;
    u32      mmio;
    int      bus, dev, func;
    u16      devid;
    u8       rev;
    int      nic_type;
    int      is_l2c_b;                  /* L2CB v1.0: особые патчи */
    int      is_l2c_b2;                 /* L2CB v2.x (AR8152 v2) */
    int      link_1g;                  /* гигабитная линия */
    u8       mac[6];
    char     chip_name[44];

    /* кольца */
    void        *tpd_raw;
    atl1c_tpd_t *tpd;
    void        *rfd_raw;
    atl1c_rfd_t *rfd;
    void        *rrd_raw;
    atl1c_rrd_t *rrd;
    u8          *rxbuf[ATL1C_RX_COUNT];    /* выровненные буферы приёма */
    u8          *txbuf[ATL1C_TX_COUNT];
    u16          rx_next2use;              /* producer для RFD */
    u16          rx_next2clean;            /* RRD */
    u16          tx_next2use;
} g;

/* ============================ MMIO / задержки ========================== */

static inline u32 rd(u32 off) { return *(volatile u32 *)(unsigned long)(g.mmio + off); }
static inline void wr(u32 off, u32 v) { *(volatile u32 *)(unsigned long)(g.mmio + off) = v; }
static inline u16 rd16(u32 off) { return *(volatile u16 *)(unsigned long)(g.mmio + off); }
static inline void wr16(u32 off, u16 v) { *(volatile u16 *)(unsigned long)(g.mmio + off) = v; }

/* Задержки: init выполняется ДО sti() — PIT-канал-2 калибровка
 * (как в ahci.c/ath9k_wifi.c).
 *
 * Сессия 25 (репро пользователя: «[boot] atl1c_init... на ноутбуке
 * длится почти минуту, эмуляторы проходят мгновенно»): старая
 * калибровка считала ЦЕЛОЕ число io-операций на микросекунду
 * (g_io_per_us). На реальном железе, где port 0x80 медленный
 * (> 1 мкс — некоторые чипсеты/ACPI траппят POST-порт), частное
 * получалось 0 → фолбэк 9 → все задержки умножались в 9+ раз, а на
 * траппящем порту и в десятки. Теперь задержка хранится ДРОБНО:
 * наносекунды на одну io-операцию, что корректно при ЛЮБОЙ скорости
 * порта; при неудаче калибровки фолбэк — классические ~1 мкс. */
static u16 pit2_read(void) {
    outb(0x43, 0x80);
    return (u16)(inb(0x42) | (inb(0x42) << 8));
}

static volatile u32 g_ns_per_io = 1000;   /* нс на inb(0x80) */

/* один проход: n операций io, dt — тиков PIT (838 нс/тик) */
static u32 a_cal_pass(u32 n)
{
    u16 t0 = pit2_read();
    for (u32 i = 0; i < n; i++) (void)inb(0x80);
    u16 t1 = pit2_read();
    u32 dt = (u32)((t0 - t1) & 0xFFFF);
    if (dt < 8 || dt > 30000) return 0;    /* слишком быстро/медленно или перенос */
    u32 ns = (u32)(((u64)dt * 838ull) / n);
    return ns ? ns : 1;
}

static void a_calibrate(void)
{
    u8 p61 = inb(0x61);
    outb(0x61, (p61 | 0x01) & ~0x02);
    outb(0x43, 0xB4);
    outb(0x42, 0xFF); outb(0x42, 0xFF);
    /* убывающие n: длинный проход точнее, короткий замеряет и
     * очень медленный порт (без переноса PIT-канала) */
    static const u32 ns_tab[] = { 2000, 500, 125, 32 };
    u32 best = 0;
    for (int s = 0; s < 4 && !best; s++)
        best = a_cal_pass(ns_tab[s]);
    /* [PIT2-RESYNC]: GATE2 оставляем открытым (конвенция timer.c), базу
     * оборотов переозначаем — наша перепрограммка канала 2 иначе дарит
     * фантомные +65536 тиков дедлайнам timer.c. */
    outb(0x61, (u8)((p61 | 0x01) & ~0x02));
    timer_pit2_resync();
    if (best == 0) best = 1000;              /* классика: ~1 мкс на inb(0x80) */
    if (best < 50) best = 50;                /* заведомо быстрее невозможно */
    if (best > 50000) best = 50000;          /* заведомо медленнее — ошибка */
    g_ns_per_io = best;
    {
        char b[64];
        snprintf(b, sizeof(b), "[atl1c] калибровка io: %u нс/операцию\n",
                 (unsigned)best);
        serial_puts(b);
    }
}

static void a_udelay(int us)
{
    if (us <= 0) return;
    volatile u32 n = ((u32)us * 1000u) / g_ns_per_io;
    if (n == 0) n = 1;
    while (n-- > 0) (void)inb(0x80);
}

static void a_msleep(int ms) { while (ms-- > 0) a_udelay(1000); }

/* ============================ MDIO (atl1c_hw.c) ======================== */

void atl1c_rx_rearm(void);

static int mdio_wait_idle(void)
{
    for (int i = 0; i < MDIO_MAX_AC_TO; i++) {
        if (!(rd(REG_MDIO_CTRL) & (MDIO_CTRL_BUSY | MDIO_CTRL_START)))
            return 1;
        a_udelay(10);
    }
    return 0;
}

static int phy_read_core(int ext, u8 dev, u16 reg, u16 *out)
{
    u32 val;
    /* только l2c_b2/l1d_2 — медленный клок (как эталон при hibernate) */
    u32 clk = (g.is_l2c_b2 || g.nic_type == NIC_L1D_2) ?
              MDIO_CTRL_CLK_25_128 : MDIO_CTRL_CLK_25_4;

    if (ext) {
        val = ((u32)dev << MDIO_EXTN_DEVAD_S) | reg;
        wr(REG_MDIO_EXTN, val);
        val = MDIO_CTRL_SPRES_PRMBL | (clk << MDIO_CTRL_CLK_SEL_S) |
              MDIO_CTRL_START | MDIO_CTRL_MODE_EXT | MDIO_CTRL_OP_READ;
    } else {
        val = MDIO_CTRL_SPRES_PRMBL | (clk << MDIO_CTRL_CLK_SEL_S) |
              ((u32)reg << MDIO_CTRL_REG_S) |
              MDIO_CTRL_START | MDIO_CTRL_OP_READ;
    }
    wr(REG_MDIO_CTRL, val);
    if (!mdio_wait_idle()) return 0;
    val = rd(REG_MDIO_CTRL);
    *out = (u16)(val & 0xFFFF);       /* MDIO_CTRL_DATA_GET = младшие 16 бит */
    return 1;
}

static int phy_write_core(int ext, u8 dev, u16 reg, u16 data)
{
    u32 val;
    u32 clk = (g.is_l2c_b2 || g.nic_type == NIC_L1D_2) ?
              MDIO_CTRL_CLK_25_128 : MDIO_CTRL_CLK_25_4;

    if (ext) {
        val = ((u32)dev << MDIO_EXTN_DEVAD_S) | reg;
        wr(REG_MDIO_EXTN, val);
        val = MDIO_CTRL_SPRES_PRMBL | (clk << MDIO_CTRL_CLK_SEL_S) |
              ((u32)data << MDIO_CTRL_DATA_S) |
              MDIO_CTRL_START | MDIO_CTRL_MODE_EXT;   /* OP_WRITE = 0 */
    } else {
        val = MDIO_CTRL_SPRES_PRMBL | (clk << MDIO_CTRL_CLK_SEL_S) |
              ((u32)reg << MDIO_CTRL_REG_S) |
              ((u32)data << MDIO_CTRL_DATA_S) |
              MDIO_CTRL_START;
    }
    wr(REG_MDIO_CTRL, val);
    return mdio_wait_idle();
}

static int phy_read(u16 reg, u16 *out)  { return phy_read_core(0, 0, reg, out); }
static int phy_write(u16 reg, u16 data) { return phy_write_core(0, 0, reg, data); }

static int phy_dbg_read(u16 dbg_reg, u16 *out)
{
    if (!phy_write(MII_DBG_ADDR, dbg_reg)) return 0;
    return phy_read(MII_DBG_DATA, out);
}

static int phy_dbg_write(u16 dbg_reg, u16 data)
{
    if (!phy_write(MII_DBG_ADDR, dbg_reg)) return 0;
    return phy_write(MII_DBG_DATA, data);
}

static int phy_ext_write(u8 dev, u16 reg, u16 data)
{
    return phy_write_core(1, dev, reg, data);
}

/* ============================ сбросы (atl1c_main.c) ==================== */

/* wait_until_idle: до 10 мс */
static int wait_until_idle(u32 modu_ctrl)
{
    for (int i = 0; i < 10; i++) {
        if ((rd(REG_IDLE_STATUS) & modu_ctrl) == 0) return 1;
        a_msleep(1);
    }
    return 0;
}

static int stop_mac(void)
{
    u32 v = rd(REG_RXQ_CTRL) & ~RXQ_CTRL_EN;
    wr(REG_RXQ_CTRL, v);
    v = rd(REG_TXQ_CTRL) & ~TXQ_CTRL_EN;
    wr(REG_TXQ_CTRL, v);
    wait_until_idle(IDLE_STATUS_RXQ_BUSY | IDLE_STATUS_TXQ_BUSY);
    v = rd(REG_MAC_CTRL) & ~(MAC_CTRL_TX_EN | MAC_CTRL_RX_EN);
    wr(REG_MAC_CTRL, v);
    return wait_until_idle(IDLE_STATUS_TXMAC_BUSY | IDLE_STATUS_RXMAC_BUSY);
}

static void pcie_patch(void)
{
    u32 mst = rd(REG_MASTER_CTRL) & ~MASTER_CTRL_CLK_SEL_DIS;
    wr(REG_MASTER_CTRL, mst);
    if (g.nic_type == NIC_L1C || g.nic_type == NIC_L2C) {
        wr(REG_PCIE_PHYMISC, rd(REG_PCIE_PHYMISC) | (1u << 1));  /* FORCE_RCV_DET */
    } else if (!(mst & MASTER_CTRL_WAKEN_25M)) {
        wr(REG_MASTER_CTRL, mst | MASTER_CTRL_WAKEN_25M);
    }
    /* l2cb 1.x & l1d 1.x */
    if (g.is_l2c_b || g.nic_type == NIC_L1D) {
        wr(REG_PM_CTRL, rd(REG_PM_CTRL) | (1u << 23));   /* PM_CTRL_L0S_BUFSRX_EN */
    }
}

static void reset_pcie(void)
{
    /* PCI command: Memory|Master (INTx не трогаем — прерываний нет) */
    u16 cmd = pci_read16(g.bus, g.dev, g.func, 0x04);
    pci_write16(g.bus, g.dev, g.func, 0x04, (u16)(cmd | 0x0006));
    /* очистка WoL-статуса */
    (void)rd(REG_WOL_CTRL);
    wr(REG_WOL_CTRL, 0);
    pcie_patch();
    a_msleep(5);
}

static int reset_mac(void)
{
    if (!stop_mac())
        serial_puts("[atl1c] предупреждение: MAC не остановился\n");

    u32 ctrl = rd(REG_MASTER_CTRL) | MASTER_CTRL_OOB_DIS;
    wr(REG_MASTER_CTRL, ctrl | MASTER_CTRL_SOFT_RST);
    a_msleep(10);
    if (!wait_until_idle(IDLE_STATUS_MASK)) {
        serial_puts("[atl1c] MAC не выходит из reset\n");
        return 0;
    }
    wr(REG_MASTER_CTRL, ctrl);

    /* скорость/дуплекс под управлением ПО */
    wr(REG_MAC_CTRL, rd(REG_MAC_CTRL) | MAC_CTRL_SPEED_MODE_SW);

    /* clk switch: l2c_b2/l1d_2 — замедление, l2c_b — убрать замедление */
    if (g.nic_type == NIC_L2CB) {
        wr(REG_SERDES, rd(REG_SERDES) & ~(SERDES_PHY_CLK_SLOWDOWN |
                                          SERDES_MAC_CLK_SLOWDOWN));
    } else if (g.is_l2c_b2 || g.nic_type == NIC_L1D_2) {
        wr(REG_SERDES, rd(REG_SERDES) | SERDES_PHY_CLK_SLOWDOWN |
                                        SERDES_MAC_CLK_SLOWDOWN);
    }
    return 1;
}

/* atl1c_phy_reset [atl1c_hw.c] */
static int phy_reset(void)
{
    u16 d;
    u32 pc = rd(REG_GPHY_CTRL) & ~(GPHY_CTRL_EXT_RESET | GPHY_CTRL_PHY_IDDQ |
                                   GPHY_CTRL_GATE_25M_EN | GPHY_CTRL_PWDOWN_HW |
                                   (1u << 2) /* LED_MODE */  |
                                   (1u << 17) /* 100AB_EN */ |
                                   (1u << 13) /* PHY_PLL_ON */);
    pc |= GPHY_CTRL_SEL_ANA_RST;
    /* ATL1C_HIB_DISABLE не ставим → hibernate включён, как в эталоне */
    pc |= GPHY_CTRL_HIB_EN | GPHY_CTRL_HIB_PULSE;
    wr(REG_GPHY_CTRL, pc);
    a_udelay(10);
    wr(REG_GPHY_CTRL, pc | GPHY_CTRL_EXT_RESET);
    a_udelay(10 * GPHY_CTRL_EXT_RST_TO);          /* 800 мкс */

    if (g.nic_type == NIC_L2CB) {
        if (phy_dbg_read(MIIDBG_CFGLPSPD, &d))
            phy_dbg_write(MIIDBG_CFGLPSPD, (u16)(d & ~CFGLPSPD_RSTCNT_CLK125SW));
    }
    if (g.is_l2c_b || g.is_l2c_b2) {
        if (phy_dbg_read(MIIDBG_CABLE1TH_DET, &d))
            phy_dbg_write(MIIDBG_CABLE1TH_DET, (u16)(d | CABLE1TH_DET_EN));
    }
    /* питание/hibernate-конфиг эталона */
    if (g.is_l2c_b || g.is_l2c_b2) {
        if (phy_dbg_read(MIIDBG_VOLT_CTRL, &d))
            phy_dbg_write(MIIDBG_VOLT_CTRL, (u16)(d & ~VOLT_CTRL_SWLOWEST));
    }
    phy_dbg_write(MIIDBG_LEGCYPS, L1C_LEGCYPS_DEF);
    phy_dbg_write(MIIDBG_SYSMODCTRL, SYSMODCTRL_IECHOADJ_DEF);

    /* EEE (AZ) отключить для l1d/l1d_2/l2c_b2 — стабилизация линии */
    if (g.nic_type == NIC_L1D || g.nic_type == NIC_L1D_2 || g.is_l2c_b2) {
        wr(REG_LPI_CTRL, rd(REG_LPI_CTRL) & ~LPI_CTRL_EN);
        phy_ext_write(MIIEXT_ANEG, MIIEXT_LOCAL_EEEADV, 0);
        phy_ext_write(MIIEXT_PCS, MIIEXT_CLDCTRL3, L2CB_CLDCTRL3);
    }

    /* отладочные порты */
    phy_dbg_write(MIIDBG_ANACTRL, ANACTRL_DEF);
    phy_dbg_write(MIIDBG_SRDSYSMOD, SRDSYSMOD_DEF);
    phy_dbg_write(MIIDBG_TST10BTCFG, TST10BTCFG_DEF);
    phy_dbg_write(MIIDBG_TST100BTCFG, (u16)(TST100BTCFG_DEF | TST100BTCFG_LITCH_EN));

    /* маска прерываний PHY: link up/down (не используются, но как эталон) */
    if (!phy_write(MII_IER, IER_LINK_UP | IER_LINK_DOWN)) {
        serial_puts("[atl1c] PHY не отвечает (MDIO)\n");
        return 0;
    }
    return 1;
}

/* atl1c_phy_init: автонег */
static int phy_init(void)
{
    u16 id1 = 0, id2 = 0;
    if (!phy_read(MII_PHYSID1, &id1) || !phy_read(MII_PHYSID2, &id2)) {
        serial_puts("[atl1c] не читается PHY ID\n");
        return 0;
    }
    {
        char b[48];
        snprintf(b, sizeof(b), "[atl1c] PHY id %04x:%04x", id1, id2);
        serial_puts(b);
    }

    /* advertise: 10/100 half+full; гигабит только для l1c/l1d семейства */
    int gig_cap = (g.nic_type == NIC_L1C || g.nic_type == NIC_L1D ||
                   g.nic_type == NIC_L1D_2);
    phy_write(MII_ADVERTISE, (u16)(ADVERTISE_10HALF | ADVERTISE_10FULL |
                                   ADVERTISE_100HALF | ADVERTISE_100FULL));
    phy_write(MII_CTRL1000, (u16)(gig_cap ?
                     (GIGA_ADVERTISE_1000HALF | GIGA_ADVERTISE_1000FULL) : 0));

    return phy_write(MII_BMCR, (u16)(BMCR_RESET | BMCR_ANENABLE | BMCR_ANRESTART));
}

/* ============================ MAC-адрес ================================ */

static int read_current_addr(void)
{
    u32 a0 = rd(REG_MAC_STA_ADDR);
    u32 a1 = rd(REG_MAC_STA_ADDR + 4);
    g.mac[2] = (u8)(a0 >> 24); g.mac[3] = (u8)(a0 >> 16);
    g.mac[4] = (u8)(a0 >> 8);  g.mac[5] = (u8)a0;
    g.mac[0] = (u8)(a1 >> 8);  g.mac[1] = (u8)a1;
    /* валиден, если не 0 и не multicast */
    return !(g.mac[0] == 0 && g.mac[1] == 0 && g.mac[2] == 0 &&
             g.mac[3] == 0 && g.mac[4] == 0 && g.mac[5] == 0) &&
           !(g.mac[0] & 1);
}

static void hw_set_mac_addr(void)
{
    u32 lo = ((u32)g.mac[2] << 24) | ((u32)g.mac[3] << 16) |
             ((u32)g.mac[4] << 8)  |  (u32)g.mac[5];
    u32 hi = ((u32)g.mac[0] << 8) | (u32)g.mac[1];
    wr(REG_MAC_STA_ADDR, lo);
    wr(REG_MAC_STA_ADDR + 4, hi);
}

/* get_permanent_address: регистр → TWSI/SPI-загрузка → fallback */
static void get_permanent_address(void)
{
    if (read_current_addr()) return;

    /* eeprom существует? (бит EEPROM_EXIST в TWSI_CTRL) */
    if (rd(REG_TWSI_CTRL) & (1u << 31)) {
        /* поднять OTP clock для l1c/l2c (не наш случай, но по эталону) */
        u32 otp = rd(REG_OTP_CTRL);
        int old_clk = (g.nic_type == NIC_L1C || g.nic_type == NIC_L2C);
        if (old_clk && !(otp & OTP_CTRL_CLK_EN)) {
            wr(REG_OTP_CTRL, otp | OTP_CTRL_CLK_EN);
            a_msleep(1);
        }
        /* команда «загрузить из EEPROM в регистры» */
        u32 t = rd(REG_TWSI_CTRL) | TWSI_CTRL_SW_LDSTART;
        wr(REG_TWSI_CTRL, t);
        for (int i = 0; i < AT_TWSI_EEPROM_TIMEOUT; i++) {
            a_msleep(10);
            /* сессия 25: адрес мог уже появиться — не ждём весь таймаут */
            if (read_current_addr()) break;
            if (!(rd(REG_TWSI_CTRL) & TWSI_CTRL_SW_LDSTART)) break;
        }
        if (old_clk) {
            otp = rd(REG_OTP_CTRL) & ~OTP_CTRL_CLK_EN;
            wr(REG_OTP_CTRL, otp);
            a_msleep(1);
        }
        if (read_current_addr()) return;
    }
    /* fallback: локально администрируемый адрес */
    g.mac[0] = 0x02; g.mac[1] = 0x12;
    g.mac[2] = 0x34; g.mac[3] = 0x56;
    g.mac[4] = (u8)(g.devid & 0xFF);
    g.mac[5] = 0x78;
    serial_puts("[atl1c] MAC не найден — временный адрес\n");
}

/* ============================ кольца / настройка ======================= */

static void *amem(u32 size, u32 align, void **raw)
{
    u8 *p = (u8 *)malloc(size + align);
    if (!p) return NULL;
    *raw = p;
    return (void *)(((u32)(unsigned long)p + align - 1) & ~(align - 1));
}

static int alloc_rings(void)
{
    g.tpd = (atl1c_tpd_t *)amem(ATL1C_TX_COUNT * 16, 16, &g.tpd_raw);
    g.rfd = (atl1c_rfd_t *)amem(ATL1C_RX_COUNT * 8, 16, &g.rfd_raw);
    g.rrd = (atl1c_rrd_t *)amem(ATL1C_RX_COUNT * 16, 16, &g.rrd_raw);
    if (!g.tpd || !g.rfd || !g.rrd) return 0;
    memset((void *)g.tpd, 0, ATL1C_TX_COUNT * 16);
    memset((void *)g.rfd, 0, ATL1C_RX_COUNT * 8);
    memset((void *)g.rrd, 0, ATL1C_RX_COUNT * 16);

    static void *rxraw[ATL1C_RX_COUNT];
    static void *txraw[ATL1C_TX_COUNT];
    for (int i = 0; i < ATL1C_RX_COUNT; i++) {
        g.rxbuf[i] = (u8 *)amem(ATL1C_RX_BUF_SZ, 16, &rxraw[i]);
        if (!g.rxbuf[i]) return 0;
    }
    for (int i = 0; i < ATL1C_TX_COUNT; i++) {
        g.txbuf[i] = (u8 *)amem(ATL1C_TX_BUF_SZ, 16, &txraw[i]);
        if (!g.txbuf[i]) return 0;
    }
    return 1;
}

/* configure_des_ring + configure_tx/rx/dma + configure_mac */
static void configure_hw(void)
{
    /* TSO-порог */
    wr(REG_TX_TSO_OFFLOAD_THRESH, ((7u * 1024u) >> 3) & TX_TSO_OFFLOAD_THRESH_M);

    /* базовые адреса колец (32-бит физика == виртуальным) */
    wr(REG_TX_BASE_ADDR_HI, 0);
    wr(REG_RX_BASE_ADDR_HI, 0);
    wr(REG_TPD_PRI0_ADDR_LO, (u32)(unsigned long)g.tpd);
    wr(REG_TPD_RING_SIZE, ATL1C_TX_COUNT & TPD_RING_SIZE_M);
    wr(REG_RFD0_HEAD_ADDR_LO, (u32)(unsigned long)g.rfd);
    wr(REG_RFD_RING_SIZE, ATL1C_RX_COUNT & RFD_RING_SIZE_M);
    wr(REG_RX_BUF_SIZE, AT_RX_BUF_SIZE & RX_BUF_SIZE_M);
    wr(REG_RRD0_HEAD_ADDR_LO, (u32)(unsigned long)g.rrd);
    wr(REG_RRD_RING_SIZE, ATL1C_RX_COUNT & RRD_RING_SIZE_M);
    wr(REG_LOAD_PTR, 1);                    /* загрузить адреса */

    /* TXQ: 5 TPD/burst, enhance, 802.3 ls, ip-option; burst pref по чипу */
    u32 burst_pref = (g.is_l2c_b || g.is_l2c_b2) ?
                     L2CB_TXQ_TXF_BURST_PREF : L1C_TXQ_TXF_BURST_PREF;
    u32 txq = (TXQ_NUM_TPD_BURST_DEF << TXQ_NUM_TPD_BURST_S) |
              TXQ_CTRL_ENH_MODE | TXQ_CTRL_LS_8023_EN |
              TXQ_CTRL_IP_OPTION_EN |
              (burst_pref << TXQ_TXF_BURST_NUM_S);
    wr(REG_TXQ_CTRL, txq);

    /* RXQ: burst 8 RFD */
    wr(REG_RXQ_CTRL, (8u << RXQ_RFD_BURST_NUM_S));

    /* DMA: out-order, pri-data, read 512B (консервативно), задержки по умолчанию */
    wr(REG_DMA_CTRL, (DMA_CTRL_RORDER_MODE_OUT << DMA_CTRL_RORDER_MODE_S) |
                     DMA_CTRL_RREQ_PRI_DATA |
                     (2u << DMA_CTRL_RREQ_BLEN_S) |               /* 512B */
                     (DMA_CTRL_WDLY_CNT_DEF << DMA_CTRL_WDLY_CNT_S) |
                     (DMA_CTRL_RDLY_CNT_DEF << DMA_CTRL_RDLY_CNT_S));

    /* MTU */
    wr(REG_MTU, 1500 + 14 + 4 + 4);

    /* прерывания: прочистить и замаскировать (polling) */
    wr(REG_ISR, 0xFFFFFFFFu);
    wr(REG_IMR, 0);

    wr(REG_INT_RETRIG_TIMER, 50000 & 0xFFFF);
    wr(REG_CLK_GATING_CTRL, 0);
    wr(REG_SMB_STAT_TIMER, 200000 & 0xFFFFFF);

    u32 mst = rd(REG_MASTER_CTRL) & ~(MASTER_CTRL_TX_ITIMER_EN |
                                      MASTER_CTRL_RX_ITIMER_EN |
                                      MASTER_CTRL_INT_RDCLR);
    mst |= MASTER_CTRL_SA_TIMER_EN;
    wr(REG_MASTER_CTRL, mst);
}

/* заполнить RFD буферами и объявить producer (как alloc_rx_buffer:
 * один слот всегда остаётся свободным — producer указывает на НЕзанятый) */
static void rx_refill_all(void)
{
    /* адреса статичны; producer = COUNT-1 (заняты 0..COUNT-2) */
    for (int i = 0; i < ATL1C_RX_COUNT; i++)
        g.rfd[i].buffer_addr = (u64)(unsigned long)g.rxbuf[i];
    g.rx_next2use = ATL1C_RX_COUNT - 1;
    wr(REG_MB_RFD0_PROD_IDX, g.rx_next2use & MB_RFDX_PROD_IDX_M);
}

/* start_mac: включить TXQ/RXQ/MAC с параметрами линии */
static void start_mac(void)
{
    wr(REG_TXQ_CTRL, rd(REG_TXQ_CTRL) | TXQ_CTRL_EN);
    wr(REG_RXQ_CTRL, rd(REG_RXQ_CTRL) | RXQ_CTRL_EN);

    u32 mac = rd(REG_MAC_CTRL);
    mac |= MAC_CTRL_TX_EN | MAC_CTRL_TX_FLOW | MAC_CTRL_RX_EN | MAC_CTRL_RX_FLOW |
           MAC_CTRL_ADD_CRC | MAC_CTRL_PAD | MAC_CTRL_BC_EN |
           MAC_CTRL_SINGLE_PAUSE_EN | MAC_CTRL_HASH_ALG_CRC32;
    mac |= MAC_CTRL_DUPLX;                        /* полнодуплексная линия */
    mac = (mac & ~(0xFu << MAC_CTRL_SPEED_S)) |
          ((g.link_1g ? MAC_CTRL_SPEED_1000 : MAC_CTRL_SPEED_10_100)
           << MAC_CTRL_SPEED_S);
    mac = (mac & ~(MAC_CTRL_PRMLEN_M << MAC_CTRL_PRMLEN_S)) |
          (7u << MAC_CTRL_PRMLEN_S);
    wr(REG_MAC_CTRL, mac);
}

/* ============================ приём/передача =========================== */

int atl1c_send(const void *buf, u32 len)
{
    if (!g.present || len < 14 || len > 1518) return 0;

    u16 use = g.tx_next2use;
    /* дождаться свободного слота: consumer (HW) продвинулся.
     * Не дольше 100 мс (линия может быть не поднята) — иначе кадр
     * теряется, как в e1000-драйвере. */
    int waited = 0;
    for (;;) {
        u16 cons = rd16(REG_TPD_PRI0_CIDX);
        u16 used = (u16)(((use + ATL1C_TX_COUNT - (cons % ATL1C_TX_COUNT)) %
                          ATL1C_TX_COUNT));
        if (used < ATL1C_TX_COUNT - 1) break;
        if (++waited > 100) return 0;
        a_udelay(1000);
    }

    /* копия в буфер слота; короткие кадры — до 60 байт (CSMA/CD) */
    u8 *dst = g.txbuf[use];
    memcpy(dst, buf, len);
    if (len < 60) {
        for (u32 i = len; i < 60; i++) dst[i] = 0;
        len = 60;
    }

    atl1c_tpd_t *tpd = &g.tpd[use];
    tpd->buffer_len = (u16)len;
    tpd->vlan_tag = 0;
    tpd->word1 = (1u << TPD_EOP_S);               /* EOP, Ethernet II */
    tpd->buffer_addr = (u64)(unsigned long)dst;

    g.tx_next2use = (u16)((use + 1) % ATL1C_TX_COUNT);
    wr16(REG_TPD_PRI0_PIDX, g.tx_next2use);
    return 1;
}

u32 atl1c_recv(void *out_buf, u32 out_max)
{
    if (!g.present) return 0;
    wr(REG_ISR, 0xFFFFFFFFu);

    for (;;) {
        atl1c_rrd_t *rrs = &g.rrd[g.rx_next2clean];
        if (!(rrs->word3 & RRS_RXD_UPDATED)) return 0;   /* пусто */

        u16 rfd_num  = (u16)((rrs->word0 >> RRS_RX_RFD_CNT_S) & RRS_RX_RFD_CNT_M);
        u16 rfd_idx  = (u16)((rrs->word0 >> RRS_RX_RFD_INDEX_S) & RRS_RX_RFD_INDEX_M);

        /* снять UPDATED, продвинуть RRD */
        rrs->word3 &= ~RRS_RXD_UPDATED;
        g.rx_next2clean = (u16)((g.rx_next2clean + 1) % ATL1C_RX_COUNT);

        if (rrs->word3 & (RRS_RX_ERR_SUM | RRS_802_3_LEN_ERR)) {
            atl1c_rx_rearm();
            continue;
        }
        if (rfd_num != 1 || rfd_idx >= ATL1C_RX_COUNT) {
            atl1c_rx_rearm();
            continue;
        }

        u32 length = rrs->word3 & RRS_PKT_SIZE_M;
        if (length >= 4) length -= 4;             /* минус FCS */
        u32 copy = (length < out_max) ? length : out_max;
        if (out_buf) memcpy(out_buf, g.rxbuf[rfd_idx], copy);

        /* вернуть буфер в пул (RFD по producer-индексу, как эталон) */
        atl1c_rx_rearm();
        return length;
    }
}

/* пере-вооружить один RFD (адрес статичен — двигаем producer) */
void atl1c_rx_rearm(void)
{
    g.rx_next2use = (u16)((g.rx_next2use + 1) % ATL1C_RX_COUNT);
    g.rfd[g.rx_next2use].buffer_addr = (u64)(unsigned long)g.rxbuf[g.rx_next2use];
    wr(REG_MB_RFD0_PROD_IDX, g.rx_next2use & MB_RFDX_PROD_IDX_M);
}

/* ============================ публичный API ============================ */

int  atl1c_present(void)      { return g.present; }
void atl1c_get_mac(u8 *out6)  { memcpy(out6, g.mac, 6); }
const char *atl1c_chip_name(void) { return g.chip_name; }

/* Состояние линка (PHY BMSR.LSTATUS) — для приоритета адаптеров:
 * если кабель не вставлен, WiFi (ассоциирован) должен обгонять LAN.
 * BMSR читается дважды: бит latched-low обновляется при втором чтении
 * [типовая практика mii-инструментов]. */
int atl1c_link_up(void)
{
    u16 bmsr = 0;
    if (!g.present) return 0;
    if (!phy_read(MII_BMSR, &bmsr)) return 0;
    if (!phy_read(MII_BMSR, &bmsr)) return 0;
    return (bmsr & BMSR_LSTATUS) ? 1 : 0;
}

/* ============================ init ===================================== */

int atl1c_init(void)
{
    memset(&g, 0, sizeof(g));

    /* --- PCI: Atheros/Attansic L1c/L2c family --- */
    static const u16 ids[] = { 0x1062, 0x1063, 0x2062, 0x1073, 0x1083 };
    int found = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 v = pci_read32(bus, dev, func, 0);
                if ((v & 0xFFFF) != 0x1969) {
                    if (func == 0) {
                        u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                        if (!(hdr & 0x80)) break;
                    }
                    continue;
                }
                u16 did = (u16)(v >> 16);
                for (int k = 0; k < 5; k++) {
                    if (ids[k] == did) {
                        g.bus = bus; g.dev = dev; g.func = func;
                        g.devid = did; found = 1; break;
                    }
                }
                if (found) break;
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    if (!found) return 0;

    g.rev = pci_read8(g.bus, g.dev, g.func, 8);
    switch (g.devid) {
    case 0x1062: g.nic_type = NIC_L2C;    break;   /* AR8132 */
    case 0x1063: g.nic_type = NIC_L1C;    break;   /* AR8131 */
    case 0x2062:                                /* AR8152 v1/v2 */
        g.nic_type = NIC_L2CB2;
        g.is_l2c_b2 = 1;
        break;
    case 0x1073: g.nic_type = NIC_L1D;    break;   /* AR8151 v1 */
    case 0x1083: g.nic_type = NIC_L1D_2;  break;   /* AR8151 v2 */
    }

    u32 bar0 = pci_read32(g.bus, g.dev, g.func, 0x10);
    g.mmio = bar0 & 0xFFFFFFF0u;
    if (!g.mmio) {
        serial_puts("[atl1c] BAR0 пуст\n");
        return 0;
    }
    {
        u16 cmd = pci_read16(g.bus, g.dev, g.func, 0x04);
        pci_write16(g.bus, g.dev, g.func, 0x04, (u16)(cmd | 0x0006));
    }

    const char *fam = g.nic_type == NIC_L2C   ? "AR8132 (L2C)"  :
                      g.nic_type == NIC_L1C   ? "AR8131 (L1C)"  :
                      g.is_l2c_b2             ? "AR8152 (L2CB v2)" :
                      g.nic_type == NIC_L1D   ? "AR8151 (L1D)"  : "AR8151 v2 (L1D_2)";
    snprintf(g.chip_name, sizeof(g.chip_name), "Atheros %s", fam);
    serial_puts("[atl1c] найден ");
    serial_puts(g.chip_name);
    {
        char b[24];
        snprintf(b, sizeof(b), " rev %02x, MMIO=%x\n", g.rev, g.mmio);
        serial_puts(b);
    }

    a_calibrate();

    /* --- bring-up (порядок как в atl1c_probe) --- */
    reset_pcie();
    if (!phy_reset()) return 0;
    if (!reset_mac()) return 0;
    if (!phy_init()) return 0;
    get_permanent_address();
    hw_set_mac_addr();

    if (!alloc_rings()) {
        serial_puts("[atl1c] нет памяти под кольца\n");
        return 0;
    }
    configure_hw();
    rx_refill_all();

    /* --- ждём автонег (до 4 с) и узнаём скорость ---
     * сессия 25: прогресс в serial раз в секунду — раньше «atl1c_init...»
     * висел молча, невозможно было отличить работу от зависания */
    int link = 0;
    u16 bmsr = 0;
    for (int i = 0; i < 400; i++) {
        phy_read(MII_BMSR, &bmsr);        /* BMSR читается дважды */
        phy_read(MII_BMSR, &bmsr);
        if ((bmsr & (BMSR_LSTATUS | BMSR_ANEGCOMPLETE)) ==
            (BMSR_LSTATUS | BMSR_ANEGCOMPLETE)) { link = 1; break; }
        if (i > 0 && i % 100 == 0) {
            serial_puts("[atl1c] автонег: ");
            char nb[16];
            int p10 = i / 10;
            int k = 0;
            if (p10 >= 10) nb[k++] = (char)('0' + p10 / 10);
            nb[k++] = (char)('0' + p10 % 10);
            nb[k++] = '%'; nb[k++] = '\n'; nb[k] = 0;
            serial_puts(nb);
        }
        a_msleep(10);
    }
    if (link) {
        u16 pssr = 0;
        if (phy_read(MII_GIGA_PSSR, &pssr) &&
            (pssr & GIGA_PSSR_SPD_DPLX_RESOLVED)) {
            g.link_1g = (pssr & GIGA_PSSR_SPEED) == GIGA_PSSR_1000MBS;
        }
    } else {
        serial_puts("[atl1c] линия не поднялась — старт с 100 Мбит/с\n");
    }

    start_mac();

    {
        char b[64];
        const char *h = "0123456789abcdef";
        char mac[18];
        for (int i = 0; i < 6; i++) {
            mac[i * 2]     = h[(g.mac[i] >> 4) & 0xF];
            mac[i * 2 + 1] = h[g.mac[i] & 0xF];
        }
        mac[17] = 0;
        snprintf(b, sizeof(b), "[atl1c] готов: MAC=%s, %s, %s\n",
                 mac, link ? (g.link_1g ? "1 Гбит/с" : "100 Мбит/с") : "нет линии",
                 "polling");
        serial_puts(b);
    }

    g.present = 1;
    return 1;
}
