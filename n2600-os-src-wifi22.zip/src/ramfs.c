/* ramfs.c — виртуальная файловая система в оперативной памяти.
 *
 * ramfs КАК ОТДЕЛЬНЫЙ ПРОЦЕСС (задача «ramfs» в диспетчере задач):
 *   - после task_init() ядро зовёт ramfs_server_start() — порождается
 *     системная задача-сервер (task_spawn + task_set_system);
 *   - сервер ЗАБИРАЕТ ВЛАДЕНИЕ блоком ramdisk (mem_reassign), поэтому
 *     диспетчер задач честно показывает, сколько памяти занимает ramfs
 *     (десятки МиБ), плюс её CPU/uptime;
 *   - все файловые операции (create/write/read/delete/list) идут через
 *     очередь запросов: клиент кладёт запрос, будит сервер (task_wake),
 *     сам засыпает (task_set_waiting_me + hlt); сервер выполняет
 *     операцию и будит клиента. Файловая система теперь — СЛУЖБА,
 *     видимая в диспетчере как отдельная строка.
 *
 * Фаза загрузки: до запуска сервера (и из kmain) вызовы идут напрямую
 * (ramfs_lock внутри) — сидинг из ISO выполняется однопоточно до sti().
 *
 * Защита: задача «ramfs» — системная: task_kill отказывается её убивать
 * (иначе все файловые операции ОС зависли бы навсегда), ватчдог её
 * пропускает (она почти всё время спит в ожидании запросов).
 */
#include "ramfs.h"
#include "sync.h"
#include "mem.h"
#include "string.h"
#include "task.h"

/* Структура суперблока */
typedef struct {
    u32 magic;           /* 0x52414D46 = "RAMF" */
    u32 total_size;      /* общий размер в байтах */
    u32 data_offset;     /* смещение начала области данных */
    u32 file_count;      /* количество файлов */
    u32 free_offset;     /* смещение первого свободного байта в данных */
} ramfs_super_t;

#define RAMFS_MAGIC 0x52414D46u

static int ready = 0;
static u8 *ramdisk = NULL;
static u32 ramdisk_size = 0;
static ramfs_super_t *super = NULL;

/* Получить указатель на таблицу файлов (сразу после суперблока) */
static ramfs_dirent_t *file_table(void) {
    return (ramfs_dirent_t *)(ramdisk + sizeof(ramfs_super_t));
}

/* Получить указатель на область данных */
static u8 *data_area(void) {
    return ramdisk + super->data_offset;
}

/* Сравнение имён БЕЗ УЧЁТА РЕГИСТРА (FIX: img.js/img_load).
 * Имена в таблице — в нижнем регистре (сидинг из ISO/FAT приводит
 * их rs_lower), а скрипты/браузер/терминал передают «LOGO.PNG»,
 * «IMG.JS», «HELP.MD» как набрано. Прежний strcmp находил файл
 * только при точном регистре: img_ramfs_lookup (imgsvc) и
 * ramfs_lookup (браузер) проверяли существование без регистра,
 * после чего ramfs_read с тем же именем молча возвращал 0 —
 * «рисунок лежит тут же, но не открывается». FAT32/ISO9660 в этой
 * ОС тоже регистронезависимы — ramfs теперь ведёт себя так же:
 * чтение/запись/удаление находят файл при любом регистре имени. */
static int ramfs_name_eq(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* Найти файл по имени (возвращает индекс или -1; регистр не важен) */
static int find_file(const char *name) {
    ramfs_dirent_t *ft = file_table();
    for (u32 i = 0; i < super->file_count; i++) {
        if (ramfs_name_eq(ft[i].name, name)) {
            return (int)i;
        }
    }
    return -1;
}

int ramfs_init(void) {
    ready = 0;

    /* Выделяем 10% от доступной RAM (но не меньше 1 МиБ и не больше 64 МиБ) */
    u32 ram_mib = mem_ram_mib();
    u32 size_mib = ram_mib / 10;
    if (size_mib < 1) size_mib = 1;
    if (size_mib > 64) size_mib = 64;

    ramdisk_size = size_mib * 1024 * 1024;

    /* Выделяем память через наш аллокатор */
    ramdisk = (u8 *)malloc(ramdisk_size);
    if (!ramdisk) return 0;

    /* Очищаем всю область */
    memset(ramdisk, 0, ramdisk_size);

    /* Инициализируем суперблок */
    super = (ramfs_super_t *)ramdisk;
    super->magic = RAMFS_MAGIC;
    super->total_size = ramdisk_size;
    super->data_offset = sizeof(ramfs_super_t) + RAMFS_MAX_FILES * sizeof(ramfs_dirent_t);
    super->file_count = 0;
    super->free_offset = 0;

    ready = 1;
    return 1;
}

int ramfs_ready(void) {
    return ready;
}

static volatile int ramfs_lock = 0;

/* ======================= прямые операции (impl) ======================= */
/* Выполняются под ramfs_lock. До запуска сервера их зовёт kmain
 * (сидинг из ISO/FAT32), после — задача-сервер ramfs. */

static int ramfs_create_impl(const char *name, u32 size) {
    if (!ready || !name || !ramdisk) return 0;
    s_lock(&ramfs_lock);
    /* FIX: раньше при слишком длинном имени возвращали БЕЗ unlock —
     * блокировка оставалась захваченной навсегда (deadlock системы) */
    if (strlen(name) > RAMFS_NAME_MAX) { s_unlock(&ramfs_lock); return 0; }

    /* Проверяем, нет ли уже такого файла */
    if (find_file(name) >= 0) { s_unlock(&ramfs_lock); return 0; }

    /* Проверяем, есть ли место */
    u32 needed = super->free_offset + size;
    if (needed > (ramdisk_size - super->data_offset)) { s_unlock(&ramfs_lock); return 0; }

    /* Проверяем, есть ли место в таблице файлов */
    if (super->file_count >= RAMFS_MAX_FILES) { s_unlock(&ramfs_lock); return 0; }

    /* Добавляем запись в таблицу */
    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *entry = &ft[super->file_count];

    strncpy(entry->name, name, RAMFS_NAME_MAX);
    entry->name[RAMFS_NAME_MAX] = 0;
    entry->size = size;
    entry->offset = super->free_offset;
    entry->is_dir = 0;

    /* Обновляем суперблок */
    super->file_count++;
    super->free_offset += size;

    s_unlock(&ramfs_lock);
    return 1;
}

static int ramfs_write_impl(const char *name, const void *buf, u32 size) {
    if (!ready || !name || !buf) return 0;
    s_lock(&ramfs_lock);
    int idx = find_file(name);
    if (idx < 0) { s_unlock(&ramfs_lock); return 0; }

    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *entry = &ft[idx];

    /* Проверяем размер */
    if (size > entry->size) size = entry->size;

    /* Копируем данные */
    u8 *data = data_area() + entry->offset;
    memcpy(data, buf, size);

    /* Обновляем размер (если записали меньше, чем выделено) */
    entry->size = size;

    s_unlock(&ramfs_lock);
    return 1;
}

static u32 ramfs_read_impl(const char *name, void *buf, u32 max) {
    if (!ready || !name || !buf) return 0;
    u32 rc;
    s_lock(&ramfs_lock);
    int idx = find_file(name);
    if (idx < 0) { s_unlock(&ramfs_lock); return 0; }

    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *entry = &ft[idx];

    /* Ограничиваем чтение размером файла и буфера */
    u32 to_read = entry->size;
    if (to_read > max) to_read = max;

    /* Копируем данные */
    u8 *data = data_area() + entry->offset;
    memcpy(buf, data, to_read);
    rc = to_read;

    s_unlock(&ramfs_lock);
    return rc;
}

static int ramfs_delete_impl(const char *name) {
    if (!ready || !name) return 0;
    s_lock(&ramfs_lock);
    int idx = find_file(name);
    if (idx < 0) { s_unlock(&ramfs_lock); return 0; }

    ramfs_dirent_t *ft = file_table();

    /* Сессия 13: каталог можно удалить только ПУСТОЙ (иначе потеряем
     * детей: плоская таблица хранит их отдельными записями). */
    if (ft[idx].is_dir) {
        u32 plen = (u32)strlen(name);
        for (u32 i = 0; i < super->file_count; i++) {
            if (i == (u32)idx) continue;
            if (strncmp(ft[i].name, name, plen) == 0 &&
                ft[i].name[plen] == '/') {
                s_unlock(&ramfs_lock);
                return 0;          /* есть дети */
            }
        }
    }

    /* Сдвигаем все последующие записи влево */
    for (u32 i = (u32)idx; i < super->file_count - 1; i++) {
        ft[i] = ft[i + 1];
    }

    /* Очищаем последнюю запись */
    memset(&ft[super->file_count - 1], 0, sizeof(ramfs_dirent_t));
    super->file_count--;

    /* Примечание: память данных не освобождается (упрощение) */

    s_unlock(&ramfs_lock);
    return 1;
}

static int ramfs_list_impl(ramfs_dirent_t *out, int max) {
    if (!ready || !out) return 0;
    s_lock(&ramfs_lock);

    ramfs_dirent_t *ft = file_table();
    int count = 0;

    for (u32 i = 0; i < super->file_count && count < max; i++) {
        out[count++] = ft[i];
    }

    s_unlock(&ramfs_lock);
    return count;
}

/* ===================== каталоги (сессия 13) ===================== */

static int ramfs_mkdir_impl(const char *path) {
    if (!ready || !path || !path[0]) return 0;
    s_lock(&ramfs_lock);
    if (strlen(path) > RAMFS_NAME_MAX) { s_unlock(&ramfs_lock); return 0; }
    if (find_file(path) >= 0) { s_unlock(&ramfs_lock); return 0; }
    if (super->file_count >= RAMFS_MAX_FILES) { s_unlock(&ramfs_lock); return 0; }

    /* родитель должен существовать (кроме корня) */
    const char *slash = strrchr(path, '/');
    if (slash) {
        int plen = (int)(slash - path);
        char parent[RAMFS_NAME_MAX + 1];
        if (plen <= 0 || plen > RAMFS_NAME_MAX) { s_unlock(&ramfs_lock); return 0; }
        memcpy(parent, path, plen);
        parent[plen] = 0;
        int pi = find_file(parent);
        if (pi < 0 || !file_table()[pi].is_dir) { s_unlock(&ramfs_lock); return 0; }
    }

    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *e = &ft[super->file_count];
    strncpy(e->name, path, RAMFS_NAME_MAX);
    e->name[RAMFS_NAME_MAX] = 0;
    e->size = 0;
    e->offset = 0;
    e->is_dir = 1;
    super->file_count++;
    s_unlock(&ramfs_lock);
    return 1;
}

static int ramfs_list_dir_impl(const char *dir, ramfs_dirent_t *out, int max) {
    if (!ready || !out || !dir) return 0;
    s_lock(&ramfs_lock);
    /* префикс: "/" -> "", "dir1" -> "dir1/", "dir1/" -> "dir1/" */
    char pre[RAMFS_NAME_MAX + 2];
    {
        u32 n = (u32)strlen(dir);
        if (n == 0 || (n == 1 && dir[0] == '/')) { pre[0] = 0; }
        else {
            if (dir[0] == '/') { dir++; n--; }
            if (n > RAMFS_NAME_MAX) { s_unlock(&ramfs_lock); return 0; }
            memcpy(pre, dir, n);
            if (n && pre[n-1] != '/') { pre[n] = '/'; pre[n+1] = 0; }
            else { pre[n] = 0; }
        }
    }
    u32 plen = (u32)strlen(pre);
    ramfs_dirent_t *ft = file_table();
    int count = 0;
    for (u32 i = 0; i < super->file_count && count < max; i++) {
        if (plen && strncmp(ft[i].name, pre, plen) != 0) continue;
        const char *rest = ft[i].name + plen;
        const char *sl = strchr(rest, '/');
        if (sl) continue;                     /* это внук — не наш ребёнок */
        if (!rest[0]) continue;               /* сама запись dir */
        out[count] = ft[i];                   /* имя = БАЗОВОЕ (rest) */
        strcpy(out[count].name, rest);
        count++;
    }
    s_unlock(&ramfs_lock);
    return count;
}

/* Сессия 60: stat файла по имени БЕЗ УЧЁТА РЕГИСТРА (httpd отдаёт файлы
 * с URL "/WWW/Index.HTML" как в любом веб-сервере). Раньше httpd держал
 * СТАТИЧЕСКИЙ массив ents[RAMFS_MAX_FILES] (~20 КиБ) и перелопачивал
 * ВЕСЬ список на каждый запрос; теперь — прямой поиск по таблице.
 * out получает КОПИЮ записи (имя/размер/каталог). 1 = найден. */
static int ramfs_stat_ci_impl(const char *name, ramfs_dirent_t *out) {
    if (!ready || !name || !out || !ramdisk) return 0;
    s_lock(&ramfs_lock);
    ramfs_dirent_t *ft = file_table();
    int found = 0;
    for (u32 i = 0; i < super->file_count && !found; i++) {
        const char *a = ft[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) {
            *out = ft[i];
            found = 1;
        }
    }
    s_unlock(&ramfs_lock);
    return found;
}

/* ===================== сервер ramfs (отдельная задача) ===================== */

/* Типы запросов */
enum {
    RQ_CREATE = 1,
    RQ_WRITE,
    RQ_READ,
    RQ_DELETE,
    RQ_LIST,
    RQ_MKDIR,       /* сессия 13 */
    RQ_LISTDIR,
    RQ_STAT_CI      /* сессия 60: stat по имени без учёта регистра (httpd) */
};

typedef struct ramfs_req {
    int  kind;
    char name[RAMFS_NAME_MAX + 1];
    const void *wbuf;      /* write: источник данных (адресное пространство общее) */
    void *rbuf;            /* read/list: приёмник */
    u32  size;             /* create/write: размер */
    u32  max;              /* read/list: ёмкость буфера */
    int  iresult;          /* результат int-операций */
    u32  uresult;          /* результат u32-операций */
    volatile int done;     /* 1 = сервер обработал */
    /* СЕССИЯ 68 (фикс порчи кучи): клиент отказался ждать (таймаут/мёртвый
     * сервер) и БОЛЬШЕ НЕ ВЛАДЕЕТ кадром стека, на котором раньше жил
     * запрос. Сервер увидит abandoned=1 и ОСВОБОДИТ запрос, не обслуживая
     * его (иначе memcpy с мусорными rbuf/size = дикие записи в кучу). */
    volatile int abandoned;
    int  heap;             /* 1 = запрос в куче (IPC-путь): владелец — клиент,
                            * сервер освобождает ТОЛЬКО abandoned/мёртвые */
    int  client;           /* индекс задачи клиента (для task_wake) */
    struct ramfs_req *next;
} ramfs_req_t;

/* Очередь запросов: односвязный список + спинлока на enqueue/dequeue */
static ramfs_req_t *volatile rq_head = NULL;
static ramfs_req_t *volatile rq_tail = NULL;
static volatile int rq_lock = 0;

/* Индекс задачи-сервера; -1 = сервер ещё не запущен (фаза загрузки:
 * вызовы идут напрямую). Устанавливается в ramfs_server_start(). */
static volatile int server_tid = -1;

int ramfs_server_task(void) { return server_tid; }

static void rq_enqueue(ramfs_req_t *r)
{
    r->next = NULL;
    s_lock(&rq_lock);
    if (rq_tail) rq_tail->next = r;
    else         rq_head = r;
    rq_tail = r;
    s_unlock(&rq_lock);
}

static ramfs_req_t *rq_dequeue(void)
{
    ramfs_req_t *r = NULL;
    s_lock(&rq_lock);
    if (rq_head) {
        r = rq_head;
        rq_head = r->next;
        if (!rq_head) rq_tail = NULL;
    }
    s_unlock(&rq_lock);
    if (r) r->next = NULL;
    return r;
}

/* Заснуть до r->done — С ОГРАНИЧЕНИЕМ (сессия 68). Вызывается ТОЛЬКО
 * потоком приложения (после sti()). kmain в фазе загрузки сюда не
 * попадает (прямой путь).
 *
 * СЕССИЯ 68 (фикс порчи кучи на localhost): раньше ожидание было БЕЗ
 * таймаута и без проверки состояния сервера — задача-клиент (браузер
 * внутри loopback-обработчика httpd с удержанием http_busy_lock)
 * могла уснуть НАВСЕГДА; ждуны отбирали блокировку через 20 с и
 * входили в чужую критическую секцию → порча кучи. Теперь: если
 * сервер умер (finished) или не ответил за RAMFS_IPC_TIMEOUT_TICKS —
 * запрос помечается abandoned (сервер его освободит, не обслуживая) и
 * клиент уходит с отказом, отпуская свои блокировки. Спим без флага
 * waiting (крутой цикл с hlt): просыпаемся на каждом тике и проверяем
 * done/таймаут; CPU-цена — единицы циклов на тик (1 мс). */
#define RAMFS_IPC_TIMEOUT_TICKS 10000u   /* 10 с (1 тик = 1 мс) */

static void rq_wait(ramfs_req_t *r)
{
    u32 t0 = timer_ticks();
    for (;;) {
        if (r->done) return;
        if (r->abandoned) return;
        if (server_tid >= 0 && task_finished(server_tid)) {
            serial_puts("[ramfs] сервер мёг — запрос отклонён (клиент не ждёт вечно)\n");
            r->abandoned = 1;       /* сервер освободит, не обслуживая */
            return;
        }
        if (timer_ticks() - t0 > RAMFS_IPC_TIMEOUT_TICKS) {
            serial_puts("[ramfs] таймаут IPC — сервер не отвечает 10 с, запрос брошен\n");
            r->abandoned = 1;
            return;
        }
        /* СЕССИЯ 75: сон с отпуском ядрового замка (иначе AP-задачи
         * не получают CPU, пока клиент ждёт сервер) */
        task_klock_release_me();
        __asm__ __volatile__("sti\n\thlt" ::: "memory");
        task_klock_acquire_me();
    }
}

/* Выполнить запрос сервером (вызывается из задачи ramfs) */
static void rq_serve(ramfs_req_t *r)
{
    switch (r->kind) {
    case RQ_CREATE:
        r->iresult = ramfs_create_impl(r->name, r->size);
        break;
    case RQ_WRITE:
        r->iresult = ramfs_write_impl(r->name, r->wbuf, r->size);
        break;
    case RQ_READ:
        r->uresult = ramfs_read_impl(r->name, r->rbuf, r->max);
        break;
    case RQ_DELETE:
        r->iresult = ramfs_delete_impl(r->name);
        break;
    case RQ_LIST:
        r->uresult = (u32)ramfs_list_impl((ramfs_dirent_t *)r->rbuf, (int)r->max);
        break;
    case RQ_MKDIR:
        r->iresult = ramfs_mkdir_impl(r->name);
        break;
    case RQ_LISTDIR:
        r->uresult = (u32)ramfs_list_dir_impl(r->name,
                                              (ramfs_dirent_t *)r->rbuf,
                                              (int)r->max);
        break;
    case RQ_STAT_CI:
        r->iresult = ramfs_stat_ci_impl(r->name, (ramfs_dirent_t *)r->rbuf);
        break;
    default:
        r->iresult = 0;
        break;
    }
    r->done = 1;
    if (r->client > 0) task_wake(r->client);
}

/* Тело задачи-сервера: забрать владение ramdisk, затем вечно служить. */
static void ramfs_server_fn(void *arg)
{
    (void)arg;
    /* Теперь весь ramdisk числится за ЭТОЙ задачей: диспетчер задач
     * показывает память ramfs отдельной строкой (mem_task_used). */
    if (ramdisk && ready) mem_reassign(ramdisk, task_current());

    for (;;) {
        /* спим, пока очередь пуста (waiting: ватчдог и планировщик
         * нас пропускают — CPU не тратим) */
        int if_had;
        __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
        while (!rq_head) {
            task_set_waiting_me();
            /* СЕССИЯ 75: сон с отпуском ядрового замка */
            task_klock_release_me();
            if (if_had & 0x200)
                __asm__ __volatile__("sti\n\thlt" ::: "memory");
            else
                __asm__ __volatile__("hlt" ::: "memory");
            __asm__ __volatile__("cli" ::: "memory");
            task_klock_acquire_me();
        }
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");

        ramfs_req_t *r = rq_dequeue();
        if (!r) continue;
        /* СЕССИЯ 68: запрос может указывать на КАДР СТЕКА клиента,
         * которого больше нет (клиент убит ватчдогом/kill, пока ждал;
         * стек освободится при переиспользовании слота) — или клиент
         * сам отказался ждать (abandoned, таймаут). Обслуживать такой
         * запрос НЕЛЬЗЯ: impl скопирует данные по мусорным rbuf/wbuf —
         * дикие записи в кучу (наблюдалось как «ПОРЧА КУЧИ» с чужими
         * указателями в заголовках блоков). Освобождаем молча. */
        if (r->abandoned ||
            (r->client > 0 && task_finished(r->client))) {
            free(r);
            continue;
        }
        rq_serve(r);
        /* СЕССИЯ 68: heap-запрос освобождает КЛИЕНТ после копирования
         * результатов (он — владелец). Сервер freed бы его до чтения
         * результатов (гонка) — а повторный free у нас нет. Утечка
         * возможна только если клиент умер ПОСЛЕ обслуживания — это
         * безопасная утечка ~100 байт вместо порчи кучи. */
    }
}

/* Запустить задачу-сервер ramfs. Вызывается из kmain ПОСЛЕ task_init()
 * (до sti()): задача начнёт исполняться с первым IRQ0 после sti(). */
int ramfs_server_start(void)
{
    if (!ready) return 0;
    if (server_tid >= 0) return 1;      /* уже запущен */
    int tid = task_spawn("ramfs", ramfs_server_fn, NULL);
    if (tid < 0) return 0;
    task_set_system(tid);               /* kill запрещён, ватчдог не трогает */
    server_tid = tid;
    return 1;
}

/* Клиентский вызов: напрямую (загрузка/kmain) или через очередь к серверу.
 *
 * СЕССИЯ 68 (фикс порчи кучи на localhost): раньше r (ramfs_req_t со
 * СТЕКА клиента) клался в общую очередь УКАЗАТЕЛЕМ: смерть клиента
 * (kill/ватчдог — finished ставится в произвольной точке) или вечный
 * rq_wait делали указатель висящим — сервер обслуживал мусор из
 * переиспользованного стека (memcpy по чужим rbuf/wbuf = дикие записи
 * с указателями/размерами — точь-в-точь дамп «ПОРЧА КУЧИ»).
 * Теперь: IPC-запрос живёт В КУЧЕ; при таймауте/смерти сервера клиент
 * помечает abandoned и уходит; сервер освободит abandoned/мёртвых,
 * не обслуживая; живой клиент копирует результаты и сам делает free. */
static int ramfs_call(ramfs_req_t *r)
{
    if (!ready) return 0;
    /* Прямой путь: сервер не запущен (фаза загрузки — сидинг) или
     * вызывающий — kmain (task 0, выполняется до sti() и в главном цикле).
     * ramfs_lock внутри impl защищает данные от гонок с сервером. */
    if (server_tid < 0 || task_current() == 0) {
        rq_serve(r);
        return 1;
    }
    ramfs_req_t *h = (ramfs_req_t *)malloc(sizeof(ramfs_req_t));
    if (!h) return 0;
    *h = *r;                    /* kind/name/wbuf/rbuf/size/max */
    h->done = 0;
    h->abandoned = 0;
    h->heap = 1;
    h->client = task_current();
    h->next = NULL;
    rq_enqueue(h);
    task_wake(server_tid);
    rq_wait(h);
    if (!h->done) return 0;     /* abandoned: результат недействителен,
                                 * сам h освободит сервер */
    r->iresult = h->iresult;
    r->uresult = h->uresult;
    free(h);
    return 1;
}

/* ======================= публичный API (обёртки) ======================= */

int ramfs_create(const char *name, u32 size) {
    ramfs_req_t r;
    if (!ready || !name) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_CREATE;
    r.size = size;
    strncpy(r.name, name, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return r.iresult;
}

int ramfs_write(const char *name, const void *buf, u32 size) {
    ramfs_req_t r;
    if (!ready || !name || !buf) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_WRITE;
    r.wbuf = buf;
    r.size = size;
    strncpy(r.name, name, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return r.iresult;
}

u32 ramfs_read(const char *name, void *buf, u32 max) {
    ramfs_req_t r;
    if (!ready || !name || !buf) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_READ;
    r.rbuf = buf;
    r.max = max;
    strncpy(r.name, name, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return r.uresult;
}

int ramfs_delete(const char *name) {
    ramfs_req_t r;
    if (!ready || !name) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_DELETE;
    strncpy(r.name, name, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return r.iresult;
}

int ramfs_list(ramfs_dirent_t *out, int max) {
    ramfs_req_t r;
    if (!ready || !out) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_LIST;
    r.rbuf = out;
    r.max = (u32)max;
    ramfs_call(&r);
    return (int)r.uresult;
}

int ramfs_mkdir(const char *path) {
    ramfs_req_t r;
    if (!ready || !path) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_MKDIR;
    strncpy(r.name, path, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return r.iresult;
}

int ramfs_list_dir(const char *dir, ramfs_dirent_t *out, int max) {
    ramfs_req_t r;
    if (!ready || !dir || !out) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_LISTDIR;
    r.rbuf = out;
    r.max = (u32)max;
    strncpy(r.name, dir, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return (int)r.uresult;
}

/* Сессия 60: stat файла по имени без учёта регистра (для httpd).
 * Вызывается из kmain (httpd-коллбеки) — прямой путь, без IPC. */
int ramfs_stat_ci(const char *name, ramfs_dirent_t *out) {
    ramfs_req_t r;
    if (!ready || !name || !out) return 0;
    memset(&r, 0, sizeof(r));
    r.kind = RQ_STAT_CI;
    r.rbuf = out;
    strncpy(r.name, name, RAMFS_NAME_MAX);
    r.name[RAMFS_NAME_MAX] = 0;
    ramfs_call(&r);
    return r.iresult;
}

u32 ramfs_free_space(void) {
    if (!ready) return 0;
    return ramdisk_size - super->data_offset - super->free_offset;
}

u32 ramfs_total_space(void) {
    if (!ready) return 0;
    return ramdisk_size - super->data_offset;
}

/* Число файлов (для команды disks и статистики). */
int ramfs_file_count(void) {
    if (!ready || !super) return 0;
    return (int)super->file_count;
}
