/* Cross-compile verification TU for v36.102 [GFXP-TICK-FIX].
 * Compiled twice with the aarch64 cross gcc:
 *   1. plain            -> must emit mrs cntvct_el0 (0xd53be04x)
 *   2. -D__SWITCH__     -> must emit mrs cntpct_el0 (0xd53be01x)  [libnx parity]
 * Both must emit mrs cntfrq_el0 (0xd53be00x) in the cold freq path.
 * v36.106 [PERF-GATE]: compile with -DNOJME_PERF_DEBUG=1 — the timing
 * wrappers are compiled out of the default (battle) configuration, this
 * TU exists to verify their CODEGEN:
 *   aarch64-linux-gnu-gcc -O2 -c scripts/gfxp_cross_test.c -Iinclude \
 *     -o /tmp/g1.o && aarch64-linux-gnu-gcc -O2 -D__SWITCH__ \
 *     -DNOJME_PERF_DEBUG=1 -c scripts/gfxp_cross_test.c -Iinclude -o /tmp/g2.o
 */
#define NOJME_PERF_DEBUG 1
#include "gfxperf.h"
#include <stdint.h>
#include <stdio.h>

volatile uint32_t g_gfxp_n[GFXP_COUNT];
volatile uint32_t g_gfxp_us[GFXP_COUNT];

uint64_t probe_begin(void)  { return gfxp_begin(); }
void     probe_end(int id, uint64_t t0) { gfxp_end(id, t0); }
uint64_t probe_freq(void)   { return gfxp_tick_freq(); }

int main(void) {
    uint64_t t0 = gfxp_begin();
    gfxp_end(GFXP_NAT, t0);
    printf("%llu %llu\n", (unsigned long long)t0,
           (unsigned long long)gfxp_tick_freq());
    return 0;
}
