#!/bin/bash
# v36.106 [RMS-SAVEGUARD]: E2E-тест защиты сохранений (bin/switchui-verify,
# SDL dummy). Мидлет scripts/testrmsg/TestRMSG.jar каждой сессией читает
# последнюю запись стора "TSG" (печать "TSG:PERSIST n=<итог> prev=<маркер>")
# и добавляет свою ("r<номер сессии-1>"), данные НЕ удаляет — teardown
# сессии флашит стор на диск.
# Сценарии (каталог сохранений НЕ чистится между запусками):
#   S1: первая сессия  -> TSG.rms существует, формат v3, .old ещё нет;
#       TSG:PERSIST n=1 prev=none.
#   S2: вторая сессия  -> ротация: появился .rms.old; TSG:PERSIST n=2 prev=r0
#       (данные пережили процесс).
#   S3: порча .rms (flip байта в данных записи — ломает CRC v3) ->
#       [RMS-RECOVER] из .old + карантин .bad; prev=r1 = ДАННЫЕ
#       восстановленного состояния (минус последняя сессия — ровно
#       семантика «прошлый прогресс важнее последнего сохранения»);
#       после сессии .rms пересоздан.
#   S4: симуляция HOS-семантики rename (NOJME_PG_RENAME_EEXIST=1 —
#       rename не заменяет получатель, v36.52) -> сохранение поверх
#       существующего .rms проходит, prev=r2, .rms/.old живы.
#   S5: обрезка .rms до 12 байт -> RECOVER из .old, prev=r3.
#   S6: порча .rms + удаление .old -> чистый старт: QUARANTINE без
#       RECOVER, prev=none, свежий .rms записан.
# Успех = все проверки пройдены, ни одного SIGSEGV/зависания.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_rmsguard
rm -rf "$D"; mkdir -p "$D/roms/sub" "$D/rms"
cp scripts/testrmsg/TestRMSG.jar "$D/roms/sub/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# Каталог сохранений задаётся через ini настроек фронтенда: на verify-сборке
# (-D__SWITCH__ на хосте) дефолт saves_dir = "sdmc:/switch/j2me/saves", и
# main.c setenv-ит им NOJME_RMS_DIR поверх окружения процесса.
printf 'saves_dir=%s\n' "$D/rms" > "$D/switchui_settings.ini"
KEYS="A:400,A:400,A:400,EXIT:8000"

run_session() {  # $1 = метка, $2 = доп. env (KEY=VAL) или "-"
    local tag="$1"; shift
    local extra="$1"; shift
    if [ "$extra" = "-" ]; then
        env NOJME_SWITCH_KEYS="$KEYS" \
            timeout -k 5 40 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log"
    else
        env "$extra" NOJME_SWITCH_KEYS="$KEYS" \
            timeout -k 5 40 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log"
    fi
    echo $?
}

fail() { echo "RMSGUARD: FAIL — $*"; echo "RMSGUARD: FAILED"; exit 1; }

persist_line() { grep -a "TSG:PERSIST" "$D/err_$1.log" | tail -1; }

# ---------- S1: первая сессия ----------
rc=$(run_session s1 -)
[ "$rc" = "0" ] || fail "S1 rc=$rc"
RMSF=$(find "$D/rms" -name 'TSG.rms' | head -1)
[ -n "$RMSF" ] || { echo "--- err_s1 tail:"; tail -15 "$D/err_s1.log"; fail "S1: TSG.rms не создан"; }
[ -f "$RMSF.old" ] && fail "S1: .old не должен существовать после первой записи"
V3=$(od -An -tu1 -j4 -N4 "$RMSF" | tr -d ' \n')
[ "$V3" = "3000" ] || fail "S1: файл не v3 (байты 4-7: '$V3')"
persist_line s1 | grep -q "n=1 prev=none" || fail "S1: $(persist_line s1)"
echo "S1 OK: TSG.rms (v3, $(stat -c%s "$RMSF") байт), n=1 prev=none"

# ---------- S2: вторая сессия -> ротация .old ----------
rc=$(run_session s2 -)
[ "$rc" = "0" ] || fail "S2 rc=$rc"
[ -f "$RMSF.old" ] || fail "S2: .rms.old не появился после повторного сохранения"
[ -f "$RMSF" ] || fail "S2: .rms исчез"
persist_line s2 | grep -q "n=2 prev=r0" || fail "S2: $(persist_line s2)"
echo "S2 OK: ротация .old; персистентность n=2 prev=r0"

# ---------- S3: порча .rms -> RECOVER из .old ----------
printf '\xA5' | dd of="$RMSF" bs=1 seek=44 conv=notrunc status=none
rc=$(run_session s3 -)
[ "$rc" = "0" ] || fail "S3 rc=$rc"
grep -a "RMS-SAVEGUARD.*RECOVER from .old" "$D/err_s3.log" >/dev/null || fail "S3: нет [RMS-RECOVER] из .old"
grep -a "RMS-SAVEGUARD.*QUARANTINED" "$D/err_s3.log" >/dev/null || fail "S3: нет QUARANTINED (.bad)"
[ -f "$RMSF.bad" ] || fail "S3: .rms.bad не создан"
[ -f "$RMSF" ] || fail "S3: .rms не пересоздан после восстановления"
[ -f "$RMSF.old" ] || fail "S3: .old потерян"
persist_line s3 | grep -q "prev=r0" || fail "S3: ожидался prev=r0 (восстановлено из .old = состояние S1): $(persist_line s3)"
echo "S3 OK: RECOVER из .old (prev=r0 — на поколение назад) + карантин .bad + пересохранение"

# ---------- S4: HOS-семантика rename (replace не работает) ----------
rc=$(run_session s4 NOJME_PG_RENAME_EEXIST=1)
[ "$rc" = "0" ] || fail "S4 rc=$rc"
[ -f "$RMSF" ] || fail "S4: .rms потерян при HOS-семантике rename"
[ -f "$RMSF.old" ] || fail "S4: .old потерян при HOS-семантике rename"
V3=$(od -An -tu1 -j4 -N4 "$RMSF" | tr -d ' \n')
[ "$V3" = "3000" ] || fail "S4: .rms не v3 после HOS-симуляции"
persist_line s4 | grep -q "prev=r1" || fail "S4: $(persist_line s4)"
echo "S4 OK: сохранение при NOJME_PG_RENAME_EEXIST=1, prev=r1"

# ---------- S5: обрезка .rms ----------
head -c 12 "$RMSF" > "$RMSF.trunc" && mv "$RMSF.trunc" "$RMSF"
rc=$(run_session s5 -)
[ "$rc" = "0" ] || fail "S5 rc=$rc"
grep -a "RMS-SAVEGUARD.*RECOVER from .old" "$D/err_s5.log" >/dev/null || fail "S5: нет RECOVER из .old после обрезки"
[ -f "$RMSF" ] || fail "S5: .rms не пересоздан"
persist_line s5 | grep -q "prev=r1" || fail "S5: ожидался prev=r1 (откат на поколение): $(persist_line s5)"
echo "S5 OK: обрезка -> RECOVER (prev=r1)"

# ---------- S6: порча .rms + нет .old -> чистый старт ----------
printf '\x5A\x5A\x5A\x5A' | dd of="$RMSF" bs=1 seek=8 conv=notrunc status=none
rm -f "$RMSF.old"
rc=$(run_session s6 -)
[ "$rc" = "0" ] || fail "S6 rc=$rc"
grep -a "RMS-SAVEGUARD.*QUARANTINED" "$D/err_s6.log" >/dev/null || fail "S6: нет QUARANTINED"
if grep -a "RMS-SAVEGUARD.*RECOVER" "$D/err_s6.log" >/dev/null; then
    fail "S6: неожиданный RECOVER без .old"
fi
[ -f "$RMSF" ] || fail "S6: свежий .rms не записан"
persist_line s6 | grep -q "prev=none" || fail "S6: ожидался чистый старт prev=none: $(persist_line s6)"
echo "S6 OK: оба файла битые -> чистый старт + карантин"

# крашей нигде:
for f in "$D"/err_s*.log; do
    grep -aqi "segfault\|SIGSEGV" "$f" && fail "краш в $f"
done

echo ""
echo "RMSGUARD: ALL CHECKS PASSED (6/6 сценариев)"
