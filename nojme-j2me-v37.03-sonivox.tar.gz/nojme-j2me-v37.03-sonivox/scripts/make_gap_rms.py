#!/usr/bin/env python3
# v37.02 [RMS-GAP-HEAL]: подготовка .rms-сторов для scripts/test_rmsgap.sh.
# Формат v3 [RMS-SAVEGUARD] v36.106 (идентичен make_zombie_rms.py):
#   magic("RMS\0") ver(3) next_id count store_version last_modified(u64)
#   authmode writable records{id,size,data}... crc32(всё выше, zlib)
# Все файлы проходят СТРОГУЮ валидацию загрузчика — как в поле.
import struct, sys, zlib, os

def u32(v): return struct.pack('<I', v)
def u64(v): return struct.pack('<Q', v)

def make_rms(path, next_id, records):
    body = (u32(0x524D5300) + u32(3) + u32(next_id) + u32(len(records))
            + u32(7) + u64(0x1122334455667788) + u32(0) + u32(1))
    for rid, data in records:
        body += u32(rid) + u32(len(data)) + bytes(data)
    crc = zlib.crc32(body) & 0xFFFFFFFF
    with open(path, 'wb') as f:
        f.write(body + u32(crc))
    return len(body) + 4

def main():
    if len(sys.argv) < 2:
        print("usage: make_gap_rms.py <rms-game-dir> [only]", file=sys.stderr)
        return 1
    d = sys.argv[1]
    only = sys.argv[2] if len(sys.argv) > 2 else None
    os.makedirs(d, exist_ok=True)

    # GZ1 — ПОЛЕВОЙ КЕЙС Zombie Infection (лог 2026-10-10):
    # запись id=1 (настройки, 219 Б), next_id=2, запись id=2 (прогресс)
    # ПОТЕРЯНА историческими багами. CRC валиден.
    if only in (None, 'GZ1'):
        prof = b'OLD' + bytes((i * 7 + 3) & 0xFF for i in range(216))
        n = make_rms(os.path.join(d, 'GZ1.rms'), 2, [(1, prof)])
        print(f"GZ1.rms: damaged tail (record 1 x{len(prof)}B, record 2 LOST, next_id=2) — {n} bytes")
    # GZ3 — записи 1,2,3 при next_id=4: тест удалённого id (спека).
    if only in (None, 'GZ3'):
        n = make_rms(os.path.join(d, 'GZ3.rms'), 4,
                     [(1, b'prof'), (2, b'old2'), (3, b'old3')])
        print(f"GZ3.rms: three records next_id=4 — {n} bytes")
    # GZ4 — запись 1, next_id=2: тест дикого id (за границей хила).
    if only in (None, 'GZ4'):
        n = make_rms(os.path.join(d, 'GZ4.rms'), 2, [(1, b'prof')])
        print(f"GZ4.rms: record 1 next_id=2 — {n} bytes")
    # GZ5 — запись 1, next_id=2: тест скан-цикла чтения (стор не растёт).
    if only in (None, 'GZ5'):
        n = make_rms(os.path.join(d, 'GZ5.rms'), 2, [(1, b'prof')])
        print(f"GZ5.rms: record 1 next_id=2 — {n} bytes")
    # GZH — здоровый стор: записи 1,2 при next_id=3 (хил не нужен).
    if only in (None, 'GZH'):
        n = make_rms(os.path.join(d, 'GZH.rms'), 3,
                     [(1, b'v1'), (2, b'v2')])
        print(f"GZH.rms: healthy (records 1,2, next_id=3) — {n} bytes")
    # GZ6 — копия GZ1 для A/B с NOJME_RMS_GAP_HEAL=0.
    if only in (None, 'GZ6'):
        prof = b'OLD' + bytes((i * 7 + 3) & 0xFF for i in range(216))
        n = make_rms(os.path.join(d, 'GZ6.rms'), 2, [(1, prof)])
        print(f"GZ6.rms: damaged tail copy for A/B — {n} bytes")
    return 0

if __name__ == '__main__':
    sys.exit(main())
