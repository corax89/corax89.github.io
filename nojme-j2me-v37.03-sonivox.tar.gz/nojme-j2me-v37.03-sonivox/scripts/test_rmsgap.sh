#!/bin/bash
# v37.02 [RMS-GAP-HEAL]: E2E-тест восстановления потерянных «хвостовых»
# записей RMS (bin/switchui-verify, SDL dummy). Полевой кейс: Zombie
# Infection (240x320) — «загрузилось не то, что сохранялось»: стор 'a'
# валиден по CRC v3, запись id=1 (настройки) жива, запись id=2 (прогресс)
# потеряна историческими багами. Идиома Gameloft: бутстрап B(n) только
# при getNumRecords()==0 — при живой записи 1 никогда не выполняется;
# getRecord(2) вечно кидает InvalidRecordIDException (g.c PC=14),
# setRecord(2,...) гибнет молча в catch (g.a PC=16).
# Сценарии (scripts/make_gap_rms.py готовит сторы ДО запуска):
#   G1 сессия 1: GZ1 (полевой кейс) -> [RMS-HEAL] gap heal в логе;
#      идиома Zombie (ci->c(1) ok, ad->c(2)=null, a(2,E) УСПЕШНО).
#   G3 GZ3: deleteRecord(2) -> setRecord(2) ПО-ПРЕЖНЕМУ кидает (спека:
#      удалённый id < next_id не воскрешается).
#   G4 GZ4: setRecord(next_id+200) кидает (граница хила 64).
#   G5 GZ5: getRecord по несуществующим хвостовым id — все кидают,
#      стор НЕ растёт (скан-циклы безопасны — автосоздания чтения нет).
#   GH GZH: здоровый стор — setRecord(2) по живому id работает,
#      ложного [RMS-HEAL] нет.
#   G5P сессия 2 (тот же каталог): вылеченный прогресс GZ1 пережил
#      перезапуск процесса — сценарий «прошёл-вышел-открыл».
#   G6 A/B: NOJME_RMS_GAP_HEAL=0 + свежий GZ6 -> setRecord(2) падает
#      (старое навсегда-сломанное поведение) — рубильник работает.
# Успех = все проверки пройдены, ни одного SIGSEGV/зависания.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_rmsgap
rm -rf "$D"; mkdir -p "$D/roms/sub" "$D/rms"
cp scripts/testrmsgap/TestRMSGap.jar "$D/roms/sub/" || { echo "RMSGAP: FAIL — TestRMSGap.jar не собран (scripts/testrmsgap/build.sh)"; exit 1; }

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
printf 'saves_dir=%s\n' "$D/rms" > "$D/switchui_settings.ini"
KEYS="A:400,A:400,A:400,EXIT:8000"

run_session() {  # $1 = метка, $2 = доп. env (KEY=VAL) или "-"
    local tag="$1"; shift
    local extra="$1"; shift
    if [ "$extra" = "-" ]; then
        env NOJME_SWITCH_KEYS="$KEYS" \
            timeout -k 5 40 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log"
    else
        env "$extra" NOJME_SWITCH_KEYS="$KEYS" \
            timeout -k 5 40 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log"
    fi
    echo $?
}

fail() { echo "RMSGAP: FAIL — $*"; echo "RMSGAP: FAILED"; exit 1; }
rg_()   { grep -a "RG:$1 " "$D/err_$2.log" | tail -1; }

# ---------- подготовка сторов (формат v3+CRC, как пишет эмулятор) ----------
python3 scripts/make_gap_rms.py "$D/rms/TestRMSGap" >/dev/null || fail "подготовка сторов"
[ -f "$D/rms/TestRMSGap/GZ1.rms" ] || fail "GZ1.rms не создан"

# ---------- G1/G3/G4/G5/GH: сессия 1 (хил хвоста + идиома Zombie) ----------
rc=$(run_session s1 -)
[ "$rc" = "0" ] || { echo "--- err_s1 tail:"; tail -15 "$D/err_s1.log"; fail "G1 rc=$rc"; }
grep -a "RMSGAP: session 1" "$D/err_s1.log" >/dev/null || fail "G1: мидлет не запустился (нет session 1)"
grep -a "\[RMS-HEAL\].*GZ1" "$D/err_s1.log" >/dev/null || fail "G1: нет [RMS-HEAL] для GZ1"
if grep -a "\[RMS-HEAL\].*GZH" "$D/err_s1.log" >/dev/null; then
    fail "GH: ложный [RMS-HEAL] здорового GZH"
fi
rg_ G1-CI s1       | grep -q "PASS" || fail "G1: $(rg_ G1-CI s1)"
rg_ G1-NOBOOT s1   | grep -q "PASS" || fail "G1: $(rg_ G1-NOBOOT s1)"
rg_ G1-AD s1       | grep -q "PASS" || fail "G1: $(rg_ G1-AD s1)"
rg_ G1-SAVE s1     | grep -q "PASS" || fail "G1: $(rg_ G1-SAVE s1)"
rg_ G1-RELOAD s1   | grep -q "PASS" || fail "G1: $(rg_ G1-RELOAD s1)"
rg_ G1-SETTINGS s1 | grep -q "PASS" || fail "G1: $(rg_ G1-SETTINGS s1)"
rg_ G3-DEL s1  | grep -q "PASS" || fail "G3: $(rg_ G3-DEL s1)"
rg_ G3-SPEC s1 | grep -q "PASS" || fail "G3: $(rg_ G3-SPEC s1)"
rg_ G4-WILD s1 | grep -q "PASS" || fail "G4: $(rg_ G4-WILD s1)"
rg_ G5-SCAN s1  | grep -q "PASS" || fail "G5: $(rg_ G5-SCAN s1)"
rg_ GH-SAVE s1  | grep -q "PASS" || fail "GH: $(rg_ GH-SAVE s1)"
rg_ GH-RELOAD s1 | grep -q "PASS" || fail "GH: $(rg_ GH-RELOAD s1)"
grep -a "RG:DONE" "$D/err_s1.log" | grep -qv "/0$" && fail "G1: есть FAIL-строки: $(grep -a 'RG:.*FAIL' "$D/err_s1.log" | head -3)"
echo "G1 OK: полевой кейс GZ1 вылечен — a(2,E) записал прогресс: $(rg_ G1-SAVE s1 | sed 's/^RG:[^ ]* //')"
echo "G3 OK: удалённый id не воскрешается (спека)"
echo "G4 OK: дикий id за границей хила кидает"
echo "G5 OK: чтение хвоста не растит стор (скан-циклы безопасны)"
echo "GH OK: здоровый стор не тронут хилом"

# файл GZ1 после сессии: записи id=1 (OLD...) и id=2 (LEVEL-3), next_id=3
python3 - "$D/rms/TestRMSGap/GZ1.rms" <<'EOF' || fail "G1: GZ1.rms без записи id=2 'LEVEL-3'"
import struct, sys
d = open(sys.argv[1], 'rb').read()
magic, ver, nxt, cnt = struct.unpack_from('<IIII', d, 0)
assert magic == 0x524D5300 and ver == 3, "не v3"
assert nxt == 3, f"next_id={nxt}, ожидался 3 (за id=2)"
off = 36
recs = {}
for _ in range(cnt):
    rid, sz = struct.unpack_from('<II', d, off); off += 8
    recs[rid] = d[off:off+sz]; off += sz
assert recs.get(2) == b'LEVEL-3', f"запись 2 = {recs.get(2)!r}"
assert recs.get(1, b'').startswith(b'OLD'), "запись 1 (настройки) испорчена"
EOF
echo "G1b OK: GZ1.rms на диске: id=1 настройки целы + id=2 'LEVEL-3', next_id=3"

# ---------- G5P: сессия 2 — персистентность через перезапуск ----------
rc=$(run_session s2 -)
[ "$rc" = "0" ] || { echo "--- err_s2 tail:"; tail -15 "$D/err_s2.log"; fail "G5P rc=$rc"; }
grep -a "RMSGAP: session 2" "$D/err_s2.log" >/dev/null || fail "G5P: нет session 2"
rg_ P1-LOAD s2 | grep -q "PASS" || fail "G5P: $(rg_ P1-LOAD s2)"
rg_ P1-SAVE s2 | grep -q "PASS" || fail "G5P: $(rg_ P1-SAVE s2)"
rg_ P2-LOAD s2 | grep -q "PASS" || fail "G5P: $(rg_ P2-LOAD s2)"
grep -a "RG:DONE" "$D/err_s2.log" | grep -qv "/0$" && fail "G5P: есть FAIL-строки"
echo "G5P OK: вылеченный прогресс пережил перезапуск: LEVEL-3 -> LEVEL-4 (сценарий «прошёл-вышел-открыл»)"

# ---------- G6: A/B без хила — старое поведение воспроизводимо ----------
D2=/tmp/sw_rmsgap_ab
rm -rf "$D2"; mkdir -p "$D2/roms/sub" "$D2/rms"
cp scripts/testrmsgap/TestRMSGap.jar "$D2/roms/sub/"
printf 'saves_dir=%s\n' "$D2/rms" > "$D2/switchui_settings.ini"
python3 scripts/make_gap_rms.py "$D2/rms/TestRMSGap" GZ6 >/dev/null || fail "G6: подготовка GZ6"
env NOJME_RMS_GAP_HEAL=0 NOJME_SWITCH_KEYS="$KEYS" \
    NOJME_SWITCH_BROWSE_ROOT="$D2/roms" NOJME_SWITCH_UI_DIR="$D2" \
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy NOJME_LOG=1 NOJME_LOGGING=1 \
    timeout -k 5 40 ./bin/switchui-verify > "$D2/out.log" 2> "$D2/err.log"
rc=$?
[ "$rc" = "0" ] || { echo "--- err tail:"; tail -15 "$D2/err.log"; fail "G6 rc=$rc"; }
if grep -a "\[RMS-HEAL\].*GZ6" "$D2/err.log" >/dev/null; then
    fail "G6: [RMS-HEAL] сработал при NOJME_RMS_GAP_HEAL=0"
fi
ab=$(grep -a "RG:G6-AB " "$D2/err.log" | tail -1)
echo "$ab" | grep -q "ok=false" || fail "G6: с выключенным хилом setRecord(2) не упал: $ab"
echo "G6 OK: NOJME_RMS_GAP_HEAL=0 — баг воспроизводится (setRecord(2) ok=false), рубильник работает"

echo "RMSGAP: ALL PASSED"
