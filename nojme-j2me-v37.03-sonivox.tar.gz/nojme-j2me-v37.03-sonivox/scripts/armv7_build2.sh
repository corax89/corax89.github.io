#!/bin/bash
# v37.02: кросс-сборка headless для ARMv7 через Makefile-таргет headless
# с переопределённым компилятором (ys/armhf-cross, gcc-14.2 из deb без
# sudo). Заменяет scripts/armv7_build.sh с путями старой машины (armtc/):
# полный список источников (sax/threadpool/sonivox/amr) знает Makefile.
# Статическая линковка: libc.so-скрипт cross-пакета содержит абсолютные
# пути /usr/arm-linux-gnueabihf (нет прав на симлинк) — -static обходит.
# Usage: armv7_build2.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
XT=/home/z/my-project/ys/armhf-cross/root

cd "$ROOT"
make headless -j"$(nproc)" \
  HEADLESS_CC=$XT/usr/bin/arm-linux-gnueabihf-gcc \
  OBJDIR=obj/armv7-build \
  HEADLESS_TARGET=bin/j2me-headless-armv7 \
  HEADLESS_LDFLAGS="--sysroot=$XT/usr/arm-linux-gnueabihf -static -lm -pthread" \
  LD_LIBRARY_PATH=$XT/usr/lib/x86_64-linux-gnu

file bin/j2me-headless-armv7 | head -1
echo "BUILD OK: bin/j2me-headless-armv7"
