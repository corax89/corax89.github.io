#!/bin/bash
# test_libnx_api.sh — СТАТИЧЕСКАЯ проверка libnx-веток против стаба с
# РЕАЛЬНЫМИ сигнатурами libnx (scripts/libnx_stub/switch.h, сверен с
# doxygen-документацией devkitPro/libnx).
#
# Зачем: код под гвардом __has_include(<switch.h>) не парсится НИ ОДНОЙ
# хостовой сборкой (headless / switchui-verify / app) — его единственный
# компилятор это devkitPro на машине пользователя. В v36.41 из-за этого
# уехали на устройство ошибка 'PsmChargerType_None undeclared' и
# предупреждение о s32*/u32* в psmGetBatteryChargePercentage. Этот тест
# закрывает класс: любая правка libnx-веток прогоняется здесь со строгими
# -Wall -Wextra, причём предупреждение = FAIL (сборка devkitPro у
# пользователя должна быть чистой).
#
# Покрытие: [1] battery.c целиком (гвард отрабатывает сам: -D__SWITCH__ +
# стаб на -I пути делают __has_include(<switch.h>) истинным);
# [2] switch_joy_pad_type_str из sdl_graphics.c ([PAD-INFO], hid-ветка);
# [3]svcExitProcess в main.c всегда вызывается без аргументов
#    (реальный прототип — void svcExitProcess(void); аргумент = ошибка
#    v36.09, уже чиненная).
#
# Запуск: scripts/test_libnx_api.sh  (из любого каталога). Выход 0 = OK.
set -u
cd "$(dirname "$0")/.."
STUB=scripts/libnx_stub
CC=${CC:-gcc}
STRICT="-fsyntax-only -Wall -Wextra -D__SWITCH__ -I $STUB -I src"
fails=0

check() { # $1=проверка, $2=файл
    local out rc
    out=$($CC $STRICT "$2" 2>&1); rc=$?
    if [ $rc -eq 0 ] && [ -z "$out" ]; then
        echo "  OK   : $1"
    else
        echo "  FAIL : $1"
        echo "$out" | sed 's/^/        /'
        fails=1
    fi
}

echo "== [1/3] battery.c: PSM-ветка (v36.41 писалась по памяти; теперь против реального psm.h) =="
check "src/utils/battery.c с -D__SWITCH__ + стаб libnx" src/utils/battery.c

echo "== [2/3] sdl_graphics.c: hid-ветка [PAD-INFO] (извлечение функции) =="
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
awk '/^static const char\* switch_joy_pad_type_str/{flag=1}
     flag{print}
     flag && /^}/{exit}' src/sdl/sdl_graphics.c > "$TMP/padinfo_fn.c"
if [ ! -s "$TMP/padinfo_fn.c" ] || ! grep -q 'hidGetNpadStyleSet' "$TMP/padinfo_fn.c"; then
    echo "  FAIL : функция switch_joy_pad_type_str не извлеклась из src/sdl/sdl_graphics.c"
    fails=1
else
    {
        echo '#include <switch.h>'
        echo '#define NOJME_PADINFO_LIBNX 1'
        cat "$TMP/padinfo_fn.c"
    } > "$TMP/padinfo_test.c"
    check "switch_joy_pad_type_str (hidGetNpadStyleSet/DeviceType, HidNpadStyleTag_* / HidDeviceTypeBits_*)" "$TMP/padinfo_test.c"
fi

echo "== [3/3] main.c: svcExitProcess() без аргументов =="
bad=$(grep -nE 'svcExitProcess\s*\(\s*[^)]' src/main.c | grep -v '"' | grep -vE '^[0-9]+:\s*(\*|/\*)' | grep -v 'extern void' || true)
calls=$(grep -cE '^\s*svcExitProcess\(\);' src/main.c)
if [ -z "$bad" ] && [ "$calls" -ge 2 ]; then
    echo "  OK   : все вызовы svcExitProcess() без аргументов ($calls шт.)"
else
    echo "  FAIL : подозрительные вызовы: ${bad:-нет безаргументных вызовов (найдено $calls)}"
    fails=1
fi

echo "== [4/4] threadpool.c: MMAN-GUARD-ветка (v36.74) — svcSetMemoryPermission против реального svc.h =="
cat > "$TMP/guard_test.c" <<'EOF'
#include <stddef.h>
#include <switch.h>
static int switch_mprotect(void* addr, size_t len, int prot) {
    u32 perm = (u32)prot;
    return (int)svcSetMemoryPermission(addr, (u64)len, perm);
}
#define mprotect(addr, len, prot) switch_mprotect((addr), (len), (prot))
void vm_guard_probe(void* page) {
    mprotect(page, 4096, 0);
    mprotect(page, 4096, 3);
}
EOF
check "switch_mprotect/svcSetMemoryPermission (threadpool.c [MMAN-GUARD])" "$TMP/guard_test.c"

if [ $fails -eq 0 ]; then
    echo "ALL PASSED"
else
    echo "FAILED"
fi
exit $fails
