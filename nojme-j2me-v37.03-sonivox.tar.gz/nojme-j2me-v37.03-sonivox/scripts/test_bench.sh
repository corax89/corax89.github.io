#!/bin/bash
# v36.99 [ZPERF2]基准: интерпретаторный throughput (Bench.jar) на switchui-verify.
# Печатает медиану approx_instr/s по фазам 3..9 (первые фазы прогрев).
# Использование: test_bench.sh [метка]
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/zbench
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/benchjar/Bench.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:800,EXIT:26000"
timeout -k 5 40 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

vals=$(grep -ao "approx_instr/s=[0-9]*" "$D/err.log" | cut -d= -f2 | awk 'NF')
n=$(echo "$vals" | awk 'NF' | wc -l)
if [ "$n" -lt 3 ]; then
    echo "BENCH[$1]: FAILED — строк BENCH: $n"
    grep -a "BENCH\|start" "$D/err.log" | head -5
    exit 1
fi
med=$(echo "$vals" | sort -n | awk '{a[NR]=$1} END{print (a[int((NR+1)/2)]+a[int(NR/2)+1])/2}')
mx=$(echo "$vals" | sort -n | tail -1)
echo "BENCH[$1]: n=$n median=${med} max=${mx}"
echo "$vals" | head -8
