#!/bin/bash
# Репро Rally 3D Continue с [RACE]-прибором v36.59.
# Аргументы: $1 = суффикс прогона; RUN_SECONDS, EXTRA_ENV, KEYS — снаружи.
set -u
cd /home/z/my-project/nojme/nojme-j2me || exit 1
D=/tmp/race_${1:-base}
rm -rf "$D"; mkdir -p "$D/roms" "$D/snaps" "$D/sdmc:/switch/j2me/saves/rally3d" "$D/sdmc:/switch/j2me/games"
cp /home/z/my-project/rally3d/rally3d.jar "$D/roms/"
cp /tmp/rally3d101.rms.bak "$D/sdmc:/switch/j2me/saves/rally3d/rally3d101.rms"

cd "$D" || exit 1
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
# Браузер: A — открыть roms, A — запустить jar; дальше ИГРОВЫЕ клавиши
# (MIDP-коды): ждём меню (~6с от старта игры), '5'=Continue, '5'=Yes
# (Do you wish to continue?), Loading ~2с, газ UP.
export NOJME_SWITCH_KEYS="A:400,A:600"
GK=${KEYS:-"W:6000,53:400,W:1500,53:400,W:4000,-1:2000,-1:2000,-3:500,-4:500,-1:2000"}
export NOJME_GAME_KEYS="$GK"
unset NOJME_FRONT_KEYS
export NOJME_RACE_PROBE=1
export NOJME_TEXTLOG=1
export NOJME_SNAP_DIR="$D/snaps,ALL"
eval "${EXTRA_ENV:-true}"

RUN_SECONDS=${RUN_SECONDS:-45}
taskset -c 0 timeout -k 5 "$RUN_SECONDS" /home/z/my-project/nojme/nojme-j2me/bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit=$rc"
echo "=== RACE-зонд: ключевые события ==="
grep -a "RACE\]" "$D/err.log" | head -20
echo "..."
grep -a "RACE\] flush" "$D/err.log" | tail -8
echo "=== RACE-строк всего:"; grep -ac "RACE\]" "$D/err.log"
echo "=== Km/h (гонка жива?):"; grep -ac "Km/h" "$D/err.log"
echo "=== снапы:"; ls "$D/snaps" | wc -l
