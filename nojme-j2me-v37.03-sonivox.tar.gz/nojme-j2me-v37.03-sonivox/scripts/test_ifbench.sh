#!/bin/bash
# v36.101 [IFACE-IC]: IfaceBench A/B — interface-dense calls, default vs
# NOJME_IFACE_IC=0 on the SAME binary. Prints both medians + delta.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/zifbench
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/ifbench/IfaceBench.jar "$D/roms/"

run_one() {  # $1 = label, $2 = extra env ("" = default)
    rm -rf "$D/roms/.state" 2>/dev/null
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-} \
    NOJME_LOG=1 NOJME_LOGGING=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 NOJME_SWITCH_KEYS="A:400,A:800,EXIT:25000" \
    $2 timeout -k 5 35 ./bin/switchui-verify > "$D/out_$1.log" 2> "$D/err_$1.log" || true
    grep -a "calls_per_s=" "$D/err_$1.log" | tail -8 | cut -d= -f3 | awk 'NF' | sort -n | awk '{a[NR]=$1} END{print (a[int((NR+1)/2)]+a[int(NR/2)+1])/2}'
}

med_on=$(run_one on "")
med_off=$(run_one off "env NOJME_IFACE_IC=0")
if [ -z "$med_on" ] || [ -z "$med_off" ] || [ "$med_on" = "0" ] || [ "$med_off" = "0" ]; then
    echo "IFBENCH: FAILED (on='${med_on}' off='${med_off}')"
    exit 1
fi
pct=$(python3 -c "print('%.1f' % ((float('$med_on')/float('$med_off')-1)*100))")
echo "IFBENCH: IC-ON=${med_on} calls/s  IC-OFF=${med_off} calls/s  delta=+${pct}%"
