/*
 * Smoke test for the Sonivox integration in NOJME.
 *
 * 1. Calls midi_init(44100)
 * 2. Loads a tiny in-memory SMF (a 4-note C-major arpeggio)
 * 3. Calls midi_play + renders ~1 second of audio
 * 4. Verifies non-zero output (i.e. synth actually produced sound)
 * 5. Loads midi_load_empty() and feeds a NoteOn / NoteOff sequence,
 *    renders 0.5 second, verifies non-zero output.
 * 6. Frees everything, exits 0 on success.
 *
 * Build: gcc -o test_sonivox test_sonivox.c -Iinclude -Isrc -Isrc/midi/sonivox/include \
 *           obj/headless/midi/midi.o obj/headless/midi/sonivox/.../*.o -lm -lpthread
 *
 * Or just link against the libretro .so for ease.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "midi.h"

/* Minimal SMF (Standard MIDI File) type 0:
 *   MThd: format=0, tracks=1, division=480
 *   MTrk: track events:
 *     - Program Change ch=0 prog=0 (Piano)
 *     - Note On  ch=0 note=60 vel=100, delta=0
 *     - Note Off ch=0 note=60, delta=480 (quarter note)
 *     - Note On  ch=0 note=64 vel=100, delta=0
 *     - Note Off ch=0 note=64, delta=480
 *     - Note On  ch=0 note=67 vel=100, delta=0
 *     - Note Off ch=0 note=67, delta=480
 *     - Note On  ch=0 note=72 vel=100, delta=0
 *     - Note Off ch=0 note=72, delta=480
 *     - End of Track meta event (FF 2F 00), delta=0
 */
static const uint8_t SMF[] = {
    /* MThd - 6 bytes header */
    'M','T','h','d', 0x00,0x00,0x00,0x06,
    0x00,0x00,             /* format 0 */
    0x00,0x01,             /* 1 track */
    0x01,0xE0,             /* 480 ticks per quarter */
    /* MTrk */
    'M','T','r','k', 0x00,0x00,0x00,0x1E,
    /* Program Change ch=0 prog=0 */
    0x00, 0xC0, 0x00,
    /* Note On C4 (60) vel 100, delta 0 */
    0x00, 0x90, 60, 100,
    /* Note Off C4, delta 480 (quarter) — 0x83 0x60 = (1<<7)|0x60 = 0xE0... wait, var-len 480 = 0x83 0xE0 */
    0x83, 0xE0, 0x90, 60, 0,
    /* Note On E4 (64), delta 0 */
    0x00, 0x90, 64, 100,
    /* Note Off E4, delta 480 */
    0x83, 0xE0, 0x90, 64, 0,
    /* Note On G4 (67), delta 0 */
    0x00, 0x90, 67, 100,
    /* Note Off G4, delta 480 */
    0x83, 0xE0, 0x90, 67, 0,
    /* Note On C5 (72), delta 0 */
    0x00, 0x90, 72, 100,
    /* Note Off C5, delta 480 */
    0x83, 0xE0, 0x90, 72, 0,
    /* End of Track meta, delta 0 */
    0x00, 0xFF, 0x2F, 0x00,
};

int main(void)
{
    printf("== Sonivox integration smoke test ==\n");

    if (midi_init(44100) != 0) {
        fprintf(stderr, "midi_init failed\n");
        return 1;
    }
    printf("[1] midi_init(44100) OK\n");

    MidiFile* m = midi_load(SMF, sizeof(SMF));
    if (!m) {
        fprintf(stderr, "midi_load failed\n");
        return 1;
    }
    printf("[2] midi_load OK, duration=%u ms\n",
           (unsigned) midi_get_duration_ms(m));

    midi_set_loop(m, false);
    midi_set_volume(m, 0.8f);
    midi_play(m);
    printf("[3] midi_play called\n");

    /* Render 1 second = 44100 stereo frames */
    int16_t* buf = malloc(44100 * 2 * sizeof(int16_t));
    if (!buf) { midi_free(m); return 1; }

    /* midi_advance_time + midi_generate_samples, mimicking media.c */
    int rendered = 0;
    int chunk = 220;
    while (rendered < 44100) {
        int n = (44100 - rendered < chunk) ? (44100 - rendered) : chunk;
        midi_advance_time(m, (uint64_t)n * 1000000ULL / 44100);
        midi_generate_samples(m, buf + rendered * 2, n);
        rendered += n;
    }

    /* Compute peak */
    int32_t peak = 0;
    for (int i = 0; i < 44100 * 2; i++) {
        int32_t a = buf[i] < 0 ? -buf[i] : buf[i];
        if (a > peak) peak = a;
    }
    printf("[4] rendered 1s of audio, peak=%d (silent if 0)\n", peak);

    if (peak < 1000) {
        fprintf(stderr, "FAIL: synth produced near-silence (peak < 1000)\n");
        midi_free(m); free(buf);
        return 1;
    }

    /* Test midi_load_empty + midi_note_on (tone player path) */
    MidiFile* em = midi_load_empty();
    if (!em) {
        fprintf(stderr, "midi_load_empty failed\n");
        midi_free(m); free(buf);
        return 1;
    }
    printf("[5] midi_load_empty OK\n");

    midi_play(em);
    midi_note_on_file(em, 0, 60, 100);   /* C4 */
    midi_note_on_file(em, 0, 64, 100);   /* E4 */
    midi_note_on_file(em, 0, 67, 100);   /* G4 */

    /* Render 0.5 second */
    int16_t* buf2 = malloc(22050 * 2 * sizeof(int16_t));
    if (!buf2) { midi_free(m); midi_free(em); free(buf); return 1; }

    midi_advance_time(em, 1000000);  /* 1 sec worth of ticks (will exceed our 0.5 sec render but fine) */
    midi_generate_samples(em, buf2, 22050);

    int32_t peak2 = 0;
    for (int i = 0; i < 22050 * 2; i++) {
        int32_t a = buf2[i] < 0 ? -buf2[i] : buf2[i];
        if (a > peak2) peak2 = a;
    }
    printf("[6] rendered 0.5s of tone-player audio, peak=%d\n", peak2);

    if (peak2 < 1000) {
        fprintf(stderr, "FAIL: tone player produced near-silence\n");
        midi_free(m); midi_free(em); free(buf); free(buf2);
        return 1;
    }

    midi_note_off_file(em, 0, 60);
    midi_note_off_file(em, 0, 64);
    midi_note_off_file(em, 0, 67);

    midi_free(m);
    midi_free(em);
    free(buf);
    free(buf2);

    midi_shutdown();

    printf("== All checks passed ==\n");
    return 0;
}
