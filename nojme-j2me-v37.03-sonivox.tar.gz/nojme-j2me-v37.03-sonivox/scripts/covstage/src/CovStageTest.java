import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;
import javax.microedition.m3g.Graphics3D;

/* v36.55 [M3G-COV-OPAQUE] selftest (восстановлен в v36.62 из потерянной
 * сессии): три фазы на одной канве 240x320 = 76800 px, bind-окно каждого
 * кадра — bindTarget(3arg) -> releaseTarget из paint.
 *
 *   ФАЗА 1 (кадры 1..59): непрозрачный fillRect-фон 0x203040 каждый кадр
 *     -> bind -> release. Ожидание в логе: «0 px fresh-black, 76800 kept»
 *     (coverage 76800/76800) — класс v25 байт-в-байт: фон детерминирован,
 *     всё сеется и переживает bind.
 *   ФАЗА 2 (кадры 60..179): bind -> release -> ПОСТ-release HUD:
 *     drawRGB КРАСНЫЙ 64x64 alpha=128 (processAlpha=true) @ (40,40) и
 *     БЕЛЫЙ 64x64 alpha=255 @ (140,40). Ожидание: «72704 px fresh-black,
 *     4096 kept» — сеется ТОЛЬКО непрозрачный белый блок; красный НЕ
 *     отмечен (полупрозрачный оверлей базу не детерминирует), его регион
 *     каждый кадр свежий чёрный -> красный в кадрах КОНСТАНТЕН (128,0,0)
 *     без ползучести яркости. Дамп releaseTarget (M3G_CAPTURE) поздних
 *     кадров: красный регион ЧЁРНЫЙ (красный не попал в буфер), белый
 *     блок (255,255,255), остальное чёрное.
 *   ФАЗА 3 (кадры 180..239): только bind -> release. Ожидание: «76800 px
 *     fresh-black, 0 kept» — полная свежая очистка; финальный дамп
 *     целиком чёрный (0/76800).
 *
 * A/B-рубильники (раннер scripts/test_m3g_covstage.sh):
 *   NOJME_M3G_COV_OPAQUE=0 -> фаза 2 даёт «68608 fresh, 8192 kept» и
 *     красный регион в дампах НЕ чёрный (сеется вчерашним красным —
 *     ползучесть яркости, сигнатура ореолов v36.54);
 *   NOJME_M3G_BIND_FRESH=0 -> строк [M3G-VIEWPORT-FRESH] нет вовсе.
 *
 * SYSOUT-хвост: «COVSTAGE:DONE n=240 PASSED». */
public class CovStageTest extends MIDlet {

    static class C extends Canvas {
        int frames;
        Graphics3D g3d;
        int[] red, white;

        C() {
            g3d = Graphics3D.getInstance();
            red = new int[64 * 64];
            white = new int[64 * 64];
            for (int i = 0; i < 64 * 64; i++) {
                red[i] = 0x80FF0000;    /* (255,0,0) alpha=128 */
                white[i] = (int) 0xFFFFFFFF; /* (255,255,255) alpha=255 */
            }
        }

        protected void paint(Graphics g) {
            frames++;
            try {
                if (frames == 1) System.out.println("COVSTAGE:PHASE1 start");
                if (frames == 60) System.out.println("COVSTAGE:PHASE2 start");
                if (frames == 180) System.out.println("COVSTAGE:PHASE3 start");
                if (frames <= 59) {
                    /* ФАЗА 1: непрозрачный фон + bind/release */
                    g.setColor(0x203040);
                    g.fillRect(0, 0, getWidth(), getHeight());
                    g3d.bindTarget(g, true, 0);
                    g3d.releaseTarget();
                } else if (frames <= 179) {
                    /* ФАЗА 2: bind/release, затем пост-release HUD */
                    g3d.bindTarget(g, true, 0);
                    g3d.releaseTarget();
                    g.drawRGB(red, 0, 64, 40, 40, 64, 64, true);
                    g.drawRGB(white, 0, 64, 140, 40, 64, 64, true);
                } else {
                    /* ФАЗА 3: только bind/release — всё свежее */
                    g3d.bindTarget(g, true, 0);
                    g3d.releaseTarget();
                }
            } catch (Throwable th) {
                System.out.println("COVSTAGE: EXC at " + frames + ": " + th);
            }
            if (frames == 239) {
                System.out.println("COVSTAGE:DONE n=" + frames + " PASSED");
            }
        }
    }

    C c;

    public void startApp() {
        System.out.println("COVSTAGE: startApp");
        c = new C();
        c.setFullScreenMode(true);
        Display.getDisplay(this).setCurrent(c);
        Thread t = new Thread() {
            public void run() {
                System.out.println("COVSTAGE: loop start");
                try {
                    for (int i = 0; i < 300; i++) {
                        c.repaint();
                        c.serviceRepaints();
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                        }
                    }
                } catch (Throwable th) {
                    System.out.println("COVSTAGE: LOOP EXC: " + th);
                }
                System.out.println("COVSTAGE:LOOP-EXIT");
            }
        };
        t.start();
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }
}
