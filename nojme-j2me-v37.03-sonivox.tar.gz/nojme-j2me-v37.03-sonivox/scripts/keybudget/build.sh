#!/bin/bash
# Build MonKeyBudgetTest.jar — v36.94 [KEY-BUDGET] selftest.
# Run: NOJME_HEADLESS_MAX_MS=60000 timeout 60 ./bin/j2me-headless \
#        scripts/keybudget/MonKeyBudgetTest.jar \
#        with NOJME_HEADLESS_KEYSCRIPT="30:-4"
# Expect: [KEY-BUDGET] requeued lines during the 4 s holds (abort ~1 s),
#         NO [MON-WAIT] waited=2000 for the delivery, then
#         KEYBUDGET:DELIVERED (in a ~300 ms release window),
#         KEYBUDGET:DESTROYED, clean exit.
# Pre-v36.94: [MON-WAIT] waited=2000/7003 lines, key delivered only after
# the full 4 s hold, frontend frozen for the whole hold.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/MonKeyBudgetTest.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: M, , MonKeyBudgetTest\r\nMIDlet-Name: M\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/MonKeyBudgetTest"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/MonKeyBudgetTest.jar" META-INF && zip -q "$D/MonKeyBudgetTest.jar" *.class )
echo "built: $D/MonKeyBudgetTest.jar"
