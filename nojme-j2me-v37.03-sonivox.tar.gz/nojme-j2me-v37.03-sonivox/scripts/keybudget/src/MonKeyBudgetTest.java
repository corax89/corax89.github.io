import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;

/**
 * v36.94 [KEY-BUDGET] e2e selftest — Metal Slug 6 "second input lock" race.
 *
 * Field evidence (log v36.93-ms6fix3, t=122.6-148.85 s):
 *   at.run() holds synchronized(at.a) — the game's INPUT-STATE lock — around
 *   a System.arraycopy key-state merge; at.h(II) (keyReleased dispatch path)
 *   does monitorenter on the SAME at.a object at PC 196. The v36.93
 *   [KEY-TRYLOCK-PUMP] guards trylock the CANVAS object — a different lock —
 *   so when the canvas was momentarily free (game thread between bl() calls)
 *   the frontend entered keyReleased and then blocked on at.a for 22.5 s:
 *   [MON-WAIT] site=block at.h@197 waited=22010 ms owner_tid=2, td m
 *   monenter=21s. The whole frontend froze (PUMP-GAP 22565 ms).
 *
 * v36.94 [KEY-BUDGET]: frontend key delivery carries a monitor budget
 * (NOJME_KEY_BUDGET_MS, default 1000). On expiry monitor_enter aborts with
 * JNI_ERR, op_monitorenter throws RuntimeException, the delivery unwinds
 * (MONITOR-UNWIND releases owned monitors), the key is RE-QUEUED and retried
 * on a later frame. Frontend stalls at most ~1 s per attempt instead of
 * hanging for the whole game-side critical section.
 *
 * This test reproduces the shape deterministically:
 *   - game thread: holds LOCK 4 s (arraycopy + sleep inside synchronized),
 *     releases it for ~300 ms, repeats (canvas monitor NEVER held);
 *   - KEYSCRIPT injects a key: frontend pump -> keyReleased ->
 *     synchronized(LOCK) — the exact at.h@196 shape.
 *
 * Expect (with v36.94):
 *   [KEY-BUDGET] key delivery exceeded ... — requeued      (during holds)
 *   NO [MON-WAIT] waited=2000 for the frontend delivery    (abort at 1 s)
 *   KEYBUDGET:DELIVERED ...                                 (in a release window)
 *   KEYBUDGET:DESTROYED, clean exit.
 *
 * Pre-v36.94 behavior: [MON-WAIT] waited=2000/7003/... lines and the key is
 * delivered only after a full 4 s hold (frontend frozen the whole time).
 */
public class MonKeyBudgetTest extends MIDlet implements Runnable {

    static final Object LOCK = new Object();   // аналог at.a (замок ввода)
    static volatile boolean stop = false;
    static int delivered = 0;
    static long firstDeliveredMs = -1;
    static long startMs;

    public MonKeyBudgetTest() { startMs = System.currentTimeMillis(); }

    public void startApp() {
        System.out.println("KEYBUDGET:STARTAPP-BEGIN t=" + (System.currentTimeMillis() - startMs));
        Display.getDisplay(this).setCurrent(new KbCanvas());
        System.out.println("KEYBUDGET:STARTAPP-CANVAS-SET");
        Thread t = new Thread(this);
        t.start();
        System.out.println("KEYBUDGET:STARTAPP-THREAD-STARTED");
    }

    public void run() {
        System.out.println("KEYBUDGET:GAME-LOOP-BEGIN");
        // «Игровой цикл»: держит замок ввода 4 c, отпускает на ~300 мс.
        // Канву (canvas-монитор) НЕ держим — как at.run() вне bl().
        while (!stop && System.currentTimeMillis() - startMs < 40000) {
            synchronized (LOCK) {
                byte[] b = new byte[23];
                byte[] c = new byte[23];
                System.arraycopy(b, 0, c, 0, 23);   // «key-sync» MS6
                try { Thread.sleep(4000); } catch (InterruptedException ie) { }
            }
            try { Thread.sleep(300); } catch (InterruptedException ie) { }
        }
        stop = true;
        System.out.println("KEYBUDGET:GAME-DONE delivered=" + delivered);
    }

    static class KbCanvas extends Canvas {
        protected void paint(Graphics g) {
            g.drawString("KB " + delivered, 5, 20, Graphics.TOP | Graphics.LEFT);
        }

        protected void keyReleased(int keyCode) {
            // аналог at.h(II)@196: monenter на замок СОСТОЯНИЯ ВВОДА
            synchronized (LOCK) {
                delivered++;
                long now = System.currentTimeMillis();
                if (firstDeliveredMs < 0) firstDeliveredMs = now;
                System.out.println("KEYBUDGET:DELIVERED k=" + keyCode
                        + " t=" + (now - startMs));
            }
        }
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) {
        stop = true;
        System.out.println("KEYBUDGET:DESTROYED delivered=" + delivered);
    }
}
