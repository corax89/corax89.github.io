#!/bin/bash
# Cross-build the headless emulator for ARMv7+NEON (m17-equivalent flags)
# and run a JAR under qemu-arm-static. Usage:
#   armv7_build.sh build          — compile to bin/j2me-headless-armv7 (static)
#   armv7_build.sh run <jar> [env...] — run under qemu
set -e
R=/home/z/my-project/work/armtc/sysroot
D=/home/z/my-project/j2me-analysis
CC=$R/usr/bin/arm-linux-gnueabihf-gcc
CXX=/home/z/my-project/work/armtc/cxx-armv7
OUT=$D/bin/j2me-headless-armv7

SRCS="$D/src/jvm/classfile.c $D/src/jvm/debug_var.c $D/src/jvm/execute.c \
$D/src/jvm/heap.c $D/src/jvm/jvm.c $D/src/jvm/method_cache.c $D/src/jvm/native.c \
$D/src/jvm/nokia_m3d.c $D/src/jvm/opcodes.c $D/src/jvm/stubs.c $D/src/jvm/threads.c \
$D/src/jvm/charset.c \
$D/src/midp/display.c $D/src/midp/form.c $D/src/midp/graphics.c $D/src/midp/media.c \
$D/src/midp/mobile3d.c $D/src/midp/mascot3d.c $D/src/midp/rms.c \
$D/src/render/render.c \
$D/src/utils/miniz.c $D/src/utils/jar_reader.c $D/src/utils/stb_image_impl.c \
$D/src/utils/utils.c $D/src/jvm/drm_bypass.c \
$D/src/midi/midi.c \
$D/src/sdl/sdl_headless.c $D/src/main.c"

# v34.53: AMR-NB decoder (opencore-amrnb) — C-style C++, no libstdc++
AMR_CPP="$D/src/amr/amr_nb_dec.cpp $(find $D/src/amr/opencore -name '*.cpp' | sort)"
AMR_INCS="-I$D/src/amr -I$D/src/amr/oscl \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/common/include \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/include \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/common/dec/include"

# m17 target flags (Makefile v41): -O3 (NO fast-math — bit-exact contract)
# -marm -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=hard
FLAGS="-Wall -Wextra -std=c11 \
-I$D/include -I$D/src -I$D/src/include -I$D/src/jvm -I$D/src/midp \
-I$D/src/utils -I$D/src/libretro \
-D_GNU_SOURCE -DJ2ME_DEBUG=0 -DJ2ME_HEADLESS -DOPT_NO_BOUNDS_CHECK \
-O3 -fno-stack-protector -fomit-frame-pointer \
-fmerge-all-constants -fno-math-errno \
-marm -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=hard"

# AMR C++ mirrors the C flags minus the C dialect plus freestanding C++
AMR_FLAGS="-Wall -std=gnu++98 -I$D/include -I$D/src -I$D/src/include \
-O3 -fno-stack-protector -fomit-frame-pointer -fmerge-all-constants -fno-math-errno \
-marm -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=hard \
$AMR_INCS"

export LD_LIBRARY_PATH=$R/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH

AMROBJ=$D/obj/arm_amr_headless

case "$1" in
build)
    mkdir -p $D/bin $AMROBJ
    # compile the AMR objects once (per-file, cached by mtime)
    for f in $AMR_CPP; do
        o=$AMROBJ/$(echo "${f#$D/src/amr/}" | tr / _).o
        if [ ! -f "$o" ] || [ "$f" -nt "$o" ]; then
            echo "  CXX(arm) ${f##*/}"
            $CXX $AMR_FLAGS -c "$f" -o "$o"
        fi
    done
    time $CC $FLAGS $SRCS $AMROBJ/*.o -o $OUT -static -lm
    file $OUT
    echo "BUILD OK: $OUT"
    ;;
run)
    shift
    JAR="$1"; shift
    env "$@" /tmp/qemu-arm-static $OUT "$JAR"
    ;;
esac
