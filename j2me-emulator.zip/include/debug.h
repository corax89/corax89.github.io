/*
 * J2ME Emulator - Debug Logging System
 * Conditional compilation for debug output
 * 
 * Usage:
 *   - Set J2ME_DEBUG=1 for verbose debug output (default)
 *   - Set J2ME_DEBUG=0 for release mode (errors only)
 *   - Can be defined in Makefile: CFLAGS += -DJ2ME_DEBUG=0
 */

#ifndef DEBUG_H
#define DEBUG_H

#include <stdio.h>
#include <stdint.h>

/* Debug level - can be overridden via compiler flag */
#ifndef J2ME_DEBUG
#define J2ME_DEBUG 1
#endif

/* Error prefix for all log messages */
#define LOG_PREFIX "[J2ME]"

/* Main debug log macro - compiles to nothing when J2ME_DEBUG=0 */
#if J2ME_DEBUG
    #define DEBUG_LOG(fmt, ...) fprintf(stderr, LOG_PREFIX " " fmt "\n", ##__VA_ARGS__)
    #define DEBUG_LOG_RAW(fmt, ...) fprintf(stderr, fmt, ##__VA_ARGS__)
#else
    #define DEBUG_LOG(fmt, ...) ((void)0)
    #define DEBUG_LOG_RAW(fmt, ...) ((void)0)
#endif

/* Error log - ALWAYS enabled, even in release mode */
#define ERROR_LOG(fmt, ...) fprintf(stderr, LOG_PREFIX " [ERROR] " fmt "\n", ##__VA_ARGS__)

/* Warning log - ALWAYS enabled */
#define WARN_LOG(fmt, ...) fprintf(stderr, LOG_PREFIX " [WARN] " fmt "\n", ##__VA_ARGS__)

/* Info log - only in debug mode */
#if J2ME_DEBUG
    #define INFO_LOG(fmt, ...) do { \
        printf("[INFO] " fmt "\n", ##__VA_ARGS__); \
        fflush(stdout); \
    } while(0)
#else
    #define INFO_LOG(fmt, ...) ((void)0)
#endif

/* Module-specific debug macros for finer control */
#if J2ME_DEBUG
    /* JVM Core */
    #define JVM_DEBUG(fmt, ...) fprintf(stderr, "[JVM] " fmt "\n", ##__VA_ARGS__)
    
    /* Execution/Interpreter */
    #define EXEC_DEBUG(fmt, ...) fprintf(stderr, "[EXEC] " fmt "\n", ##__VA_ARGS__)
    
    /* Class loading */
    #define CLASS_DEBUG(fmt, ...) fprintf(stderr, "[CLASS] " fmt "\n", ##__VA_ARGS__)
    
    /* Heap/GC */
    #define GC_DEBUG(fmt, ...) fprintf(stderr, "[GC] " fmt "\n", ##__VA_ARGS__)
    
    /* Native methods */
    #define NATIVE_DEBUG(fmt, ...) fprintf(stderr, "[NATIVE] " fmt "\n", ##__VA_ARGS__)
    
    /* MIDP */
    #define MIDP_DEBUG(fmt, ...) fprintf(stderr, "[MIDP] " fmt "\n", ##__VA_ARGS__)
    
    /* Graphics */
    #define GFX_DEBUG(fmt, ...) fprintf(stderr, "[GFX] " fmt "\n", ##__VA_ARGS__)
    
    /* Display */
    #define DISP_DEBUG(fmt, ...) fprintf(stderr, "[DISP] " fmt "\n", ##__VA_ARGS__)
    
    /* Form/UI */
    #define FORM_DEBUG(fmt, ...) fprintf(stderr, "[FORM] " fmt "\n", ##__VA_ARGS__)
    
    /* Media */
    #define MEDIA_DEBUG(fmt, ...) fprintf(stderr, "[MEDIA] " fmt "\n", ##__VA_ARGS__)
    
    /* RMS (Record Management System) */
    #define RMS_DEBUG(fmt, ...) fprintf(stderr, "[RMS] " fmt "\n", ##__VA_ARGS__)
    
    /* Threading */
    #define THREAD_DEBUG(fmt, ...) fprintf(stderr, "[THREAD] " fmt "\n", ##__VA_ARGS__)
    
    /* Opcode tracing (very verbose - use DEBUG_EXECUTION flag) */
    #define OPCODE_DEBUG(fmt, ...) fprintf(stderr, "[OP] " fmt "\n", ##__VA_ARGS__)
    
    /* Additional module macros */
    #define DEBUG_LOG(fmt, ...) fprintf(stderr, "[DEBUG] " fmt "\n", ##__VA_ARGS__)
    #define DEBUG_LOG_RAW(fmt, ...) fprintf(stderr, fmt, ##__VA_ARGS__)
#else
    #define JVM_DEBUG(fmt, ...) ((void)0)
    #define EXEC_DEBUG(fmt, ...) ((void)0)
    #define CLASS_DEBUG(fmt, ...) ((void)0)
    #define GC_DEBUG(fmt, ...) ((void)0)
    #define NATIVE_DEBUG(fmt, ...) ((void)0)
    #define MIDP_DEBUG(fmt, ...) ((void)0)
    #define GFX_DEBUG(fmt, ...) ((void)0)
    #define DISP_DEBUG(fmt, ...) ((void)0)
    #define FORM_DEBUG(fmt, ...) ((void)0)
    #define MEDIA_DEBUG(fmt, ...) ((void)0)
    #define RMS_DEBUG(fmt, ...) ((void)0)
    #define THREAD_DEBUG(fmt, ...) ((void)0)
    #define OPCODE_DEBUG(fmt, ...) ((void)0)
    #define DEBUG_LOG(fmt, ...) ((void)0)
    #define DEBUG_LOG_RAW(fmt, ...) ((void)0)
#endif

/* Hex dump utility - only in debug mode */
#if J2ME_DEBUG
static inline void debug_hexdump(const char* label, const void* data, size_t len) {
    const uint8_t* bytes = (const uint8_t*)data;
    fprintf(stderr, "[HEX] %s (%zu bytes): ", label, len);
    for (size_t i = 0; i < len && i < 64; i++) {
        fprintf(stderr, "%02X ", bytes[i]);
    }
    if (len > 64) fprintf(stderr, "...");
    fprintf(stderr, "\n");
}
#define HEXDUMP(label, data, len) debug_hexdump(label, data, len)
#else
#define HEXDUMP(label, data, len) ((void)0)
#endif

/* Memory tracking in debug mode */
/* ИСПРАВЛЕНО: Переименовано для избежания конфликта с Windows MEM_FREE */
#if J2ME_DEBUG
    #define J2ME_MEM_ALLOC(ptr, size) DEBUG_LOG("ALLOC: %p (%zu bytes)", ptr, size)
    #define J2ME_MEM_FREE(ptr) DEBUG_LOG("FREE: %p", ptr)
#else
    #define J2ME_MEM_ALLOC(ptr, size) ((void)0)
    #define J2ME_MEM_FREE(ptr) ((void)0)
#endif

/* Performance timing in debug mode */
#if J2ME_DEBUG
    #include <time.h>
    #define PERF_START() clock_t _perf_start = clock()
    #define PERF_END(label) do { \
        clock_t _perf_end = clock(); \
        double _perf_ms = ((double)(_perf_end - _perf_start) / CLOCKS_PER_SEC) * 1000.0; \
        DEBUG_LOG("[PERF] %s: %.2f ms", label, _perf_ms); \
    } while(0)
#else
    #define PERF_START() ((void)0)
    #define PERF_END(label) ((void)0)
#endif

#endif /* DEBUG_H */
