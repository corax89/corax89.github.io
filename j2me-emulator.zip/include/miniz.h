/* Mini deflate decompressor - based on zlib-compatible interface */
#ifndef MINIZ_H
#define MINIZ_H

#include <stddef.h>
#include <stdint.h>

/* Simple inflate implementation for deflate compressed data */
int miniz_inflate(const uint8_t* source, size_t source_len,
                  uint8_t* dest, size_t dest_len, size_t* out_len);

#endif
