import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.*;

public class GCTestMidlet extends MIDlet implements CommandListener {
    private Display display;
    private TestCanvas canvas;
    private Command exitCmd = new Command("Exit", Command.EXIT, 0);
    
    private String[] testNames = {
        "1. Runtime.getRuntime()",
        "2. freeMemory() > 0",
        "3. totalMemory() > 0",
        "4. System.gc() call",
        "5. Runtime.gc() call",
        "6. Create 1000 Objects",
        "7. Create 1000 Strings",
        "8. Create 1000 int[100]",
        "9. Create 1000 Vector",
        "10. Create 1000 Hashtable",
        "11. Null references + GC",
        "12. Memory freed after GC",
        "13. Large array alloc/free",
        "14. Repeated alloc cycles",
        "15. Allocate until OOM",
        "16. Recover after OOM",
        "17. GC during OOM",
        "18. Fragmentation test",
        "19. Defragmentation by GC",
        "20. Finalizer called",
        "21. Finalizer order",
        "22. 100 alloc/GC cycles",
        "23. Memory stability",
        "24. GC in multiple threads",
        "25. Concurrent allocation",
        "26. Null handling",
        "27. Zero-size array",
        "28. Large single object"
    };
    
    private String[] results;
    private int passCount = 0;
    private int failCount = 0;
    private boolean done = false;
    private String currentTest = "";
    private String errorDetail = "";
    
    private Runtime runtime;
    private long initialFreeMem;
    private long initialTotalMem;
    
    public GCTestMidlet() {
        results = new String[testNames.length];
        for (int i = 0; i < results.length; i++) results[i] = "?";
    }
    
    public void startApp() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
        canvas.addCommand(exitCmd);
        canvas.setCommandListener(this);
        display.setCurrent(canvas);
        
        new Thread(new Runnable() {
            public void run() { runTests(); }
        }).start();
    }
    
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
    
    public void commandAction(Command c, Displayable d) {
        if (c == exitCmd) { destroyApp(true); notifyDestroyed(); }
    }
    
    private void pass(int i) { 
        results[i] = "PASS"; 
        passCount++; 
        canvas.repaint(); 
        sleep(50); 
    }
    
    private void pass(int i, String info) { 
        results[i] = "PASS:" + info; 
        passCount++; 
        canvas.repaint(); 
        sleep(50); 
    }
    
    private void fail(int i, String e) { 
        results[i] = "FAIL:" + e; 
        failCount++; 
        errorDetail = e;
        canvas.repaint(); 
        sleep(50); 
    }
    
    private void sleep(int ms) { 
        try { Thread.sleep(ms); } catch (Exception e) {} 
    }
    
    private void runTests() {
        int i = 0;
        
        // Test 1: Runtime.getRuntime()
        currentTest = "Runtime";
        try {
            runtime = Runtime.getRuntime();
            if (runtime != null) pass(i); else fail(i, "null");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 2: freeMemory()
        currentTest = "freeMemory";
        try {
            initialFreeMem = runtime.freeMemory();
            if (initialFreeMem > 0) pass(i, initialFreeMem + "b"); 
            else fail(i, "freeMemory=" + initialFreeMem);
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 3: totalMemory()
        currentTest = "totalMemory";
        try {
            initialTotalMem = runtime.totalMemory();
            if (initialTotalMem > 0) pass(i, initialTotalMem + "b");
            else fail(i, "totalMemory=" + initialTotalMem);
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 4: System.gc()
        currentTest = "System.gc";
        try {
            System.gc();
            sleep(100);
            pass(i);
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 5: Runtime.gc()
        currentTest = "Runtime.gc";
        try {
            runtime.gc();
            sleep(100);
            pass(i);
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 6: Create 1000 Objects
        currentTest = "Create Objects";
        try {
            Object[] objs = new Object[1000];
            for (int j = 0; j < 1000; j++) objs[j] = new Object();
            long memAfter = runtime.freeMemory();
            pass(i, "used=" + (initialFreeMem - memAfter));
            objs = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 7: Create 1000 Strings
        currentTest = "Create Strings";
        try {
            String[] strs = new String[1000];
            for (int j = 0; j < 1000; j++) strs[j] = "TestString" + j + "Data";
            long memAfter = runtime.freeMemory();
            pass(i, "used=" + (initialFreeMem - memAfter));
            strs = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 8: Create 1000 int[100]
        currentTest = "Create int arrays";
        try {
            int[][] arrs = new int[1000][];
            for (int j = 0; j < 1000; j++) arrs[j] = new int[100];
            long memAfter = runtime.freeMemory();
            pass(i, "used=" + (initialFreeMem - memAfter));
            arrs = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 9: Create 1000 Vector
        currentTest = "Create Vectors";
        try {
            Vector[] vecs = new Vector[1000];
            for (int j = 0; j < 1000; j++) {
                vecs[j] = new Vector();
                vecs[j].addElement("item" + j);
            }
            long memAfter = runtime.freeMemory();
            pass(i, "used=" + (initialFreeMem - memAfter));
            vecs = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 10: Create 1000 Hashtable
        currentTest = "Create Hashtables";
        try {
            Hashtable[] tables = new Hashtable[1000];
            for (int j = 0; j < 1000; j++) {
                tables[j] = new Hashtable();
                tables[j].put("key" + j, "value" + j);
            }
            long memAfter = runtime.freeMemory();
            pass(i, "used=" + (initialFreeMem - memAfter));
            tables = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 11: Null references + GC
        currentTest = "Null + GC";
        try {
            long beforeGC = runtime.freeMemory();
            Object[] temp = new Object[5000];
            for (int j = 0; j < 5000; j++) temp[j] = new int[50];
            long afterAlloc = runtime.freeMemory();
            temp = null;
            System.gc();
            sleep(200);
            long afterGC = runtime.freeMemory();
            if (afterGC > afterAlloc) pass(i, "freed=" + (afterGC - afterAlloc));
            else pass(i, "no change");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 12: Memory freed after GC
        currentTest = "Memory freed";
        try {
            long before = runtime.freeMemory();
            for (int cycle = 0; cycle < 3; cycle++) {
                int[][] data = new int[100][100];
                data = null;
                System.gc();
                sleep(100);
            }
            long after = runtime.freeMemory();
            if (after - before >= -1000) pass(i, "stable");
            else fail(i, "leak? diff=" + (before - after));
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 13: Large array alloc/free
        currentTest = "Large array";
        try {
            int[] big = new int[10000];
            for (int j = 0; j < big.length; j++) big[j] = j;
            long mid = runtime.freeMemory();
            big = null;
            System.gc();
            sleep(200);
            long after = runtime.freeMemory();
            if (after >= mid - 1000) pass(i, "freed");
            else fail(i, "not freed");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 14: Repeated alloc cycles
        currentTest = "Repeat cycles";
        try {
            long startMem = runtime.freeMemory();
            for (int cycle = 0; cycle < 10; cycle++) {
                Object[] arr = new Object[100];
                for (int j = 0; j < 100; j++) arr[j] = new byte[100];
                arr = null;
                System.gc();
                sleep(50);
            }
            long endMem = runtime.freeMemory();
            if (startMem - endMem < 5000) pass(i, "diff=" + (startMem - endMem));
            else fail(i, "leak? diff=" + (startMem - endMem));
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 15: Allocate until OOM
        currentTest = "Alloc until OOM";
        try {
            Vector storage = new Vector();
            int count = 0;
            boolean oomTriggered = false;
            try {
                while (count < 10000) {
                    storage.addElement(new byte[1024]);
                    count++;
                }
            } catch (OutOfMemoryError e) { oomTriggered = true; }
            storage = null;
            System.gc();
            sleep(200);
            if (oomTriggered) pass(i, "OOM at " + count + "KB");
            else pass(i, "limit reached");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 16: Recover after OOM
        currentTest = "Recover OOM";
        try {
            Vector v = new Vector();
            try {
                while (true) v.addElement(new byte[1024]);
            } catch (OutOfMemoryError e) {}
            v = null;
            System.gc();
            sleep(300);
            byte[] test = new byte[1024];
            test[0] = 1;
            if (test[0] == 1) pass(i, "recovered");
            else fail(i, "not recovered");
            test = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 17: GC during OOM
        currentTest = "GC during OOM";
        try {
            Vector v = new Vector();
            int gcCalled = 0;
            try {
                while (v.size() < 5000) {
                    v.addElement(new byte[512]);
                    if (v.size() % 50 == 0) { System.gc(); gcCalled++; }
                }
            } catch (OutOfMemoryError e) {}
            v = null;
            System.gc();
            sleep(200);
            pass(i, "GC " + gcCalled + " times");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 18: Fragmentation test
        currentTest = "Fragmentation";
        try {
            Object[] mix = new Object[100];
            for (int j = 0; j < 100; j++) {
                if (j % 3 == 0) mix[j] = new byte[10];
                else if (j % 3 == 1) mix[j] = new byte[100];
                else mix[j] = new byte[1000];
            }
            for (int j = 0; j < 100; j += 2) mix[j] = null;
            System.gc();
            sleep(100);
            byte[] medium = new byte[5000];
            medium[0] = 1;
            pass(i, "allocated 5K");
            medium = null;
            mix = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 19: Defragmentation by GC
        currentTest = "Defragment";
        try {
            Object[] frag = new Object[50];
            for (int j = 0; j < 50; j++) frag[j] = new byte[(j + 1) * 100];
            for (int j = 1; j < 50; j += 2) frag[j] = null;
            System.gc();
            sleep(100);
            byte[] large = new byte[10000];
            System.gc();
            sleep(100);
            pass(i, "OK");
            large = null;
            frag = null;
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 20: Finalizer called
        currentTest = "Finalizer";
        try {
            FinalizerTest.finalizedCount = 0;
            for (int j = 0; j < 100; j++) new FinalizerTest();
            System.gc();
            sleep(500);
            System.gc();
            sleep(500);
            if (FinalizerTest.finalizedCount > 0) pass(i, "fin=" + FinalizerTest.finalizedCount);
            else pass(i, "no finalizers");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 21: Finalizer order
        currentTest = "Finalizer order";
        try {
            FinalizerOrder.lastFinalized = -1;
            FinalizerOrder[] objs = new FinalizerOrder[10];
            for (int j = 0; j < 10; j++) objs[j] = new FinalizerOrder(j);
            objs = null;
            System.gc();
            sleep(500);
            pass(i, "tested");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 22: 100 alloc/GC cycles
        currentTest = "100 cycles";
        try {
            long startMem = runtime.freeMemory();
            for (int cycle = 0; cycle < 100; cycle++) {
                Object[] temp = new Object[50];
                for (int j = 0; j < 50; j++) temp[j] = new byte[100];
                temp = null;
                System.gc();
            }
            long endMem = runtime.freeMemory();
            if (startMem - endMem < 5000) pass(i, "stable");
            else fail(i, "unstable diff=" + (startMem - endMem));
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 23: Memory stability
        currentTest = "Mem stability";
        try {
            long[] samples = new long[10];
            for (int s = 0; s < 10; s++) {
                for (int j = 0; j < 100; j++) { String x = "test" + j; x = null; }
                System.gc();
                sleep(50);
                samples[s] = runtime.freeMemory();
            }
            long min = samples[0], max = samples[0];
            for (int j = 1; j < 10; j++) {
                if (samples[j] < min) min = samples[j];
                if (samples[j] > max) max = samples[j];
            }
            if (max - min < 10000) pass(i, "var=" + (max - min));
            else fail(i, "high var=" + (max - min));
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 24: GC in multiple threads
        currentTest = "Multi-thread GC";
        try {
            GCMultiThread r1 = new GCMultiThread();
            GCMultiThread r2 = new GCMultiThread();
            GCMultiThread r3 = new GCMultiThread();
            Thread t1 = new Thread(r1);
            Thread t2 = new Thread(r2);
            Thread t3 = new Thread(r3);
            t1.start(); t2.start(); t3.start();
            t1.join(); t2.join(); t3.join();
            if (r1.error == null && r2.error == null && r3.error == null) pass(i, "3 threads OK");
            else fail(i, "thread error");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 25: Concurrent allocation
        currentTest = "Concurrent alloc";
        try {
            ConcurrentAlloc ca1 = new ConcurrentAlloc();
            ConcurrentAlloc ca2 = new ConcurrentAlloc();
            Thread t1 = new Thread(ca1);
            Thread t2 = new Thread(ca2);
            t1.start(); t2.start();
            for (int j = 0; j < 100; j++) { byte[] b = new byte[100]; b = null; }
            System.gc();
            t1.join(); t2.join();
            if (ca1.error == null && ca2.error == null) pass(i, "concurrent OK");
            else fail(i, "alloc error");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 26: Null handling
        currentTest = "Null handling";
        try {
            Object obj = null;
            obj = null;
            System.gc();
            Object[] arr = null;
            arr = null;
            System.gc();
            pass(i, "OK");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 27: Zero-size array
        currentTest = "Zero-size array";
        try {
            int[] zero = new int[0];
            byte[] zeroByte = new byte[0];
            Object[] zeroObj = new Object[0];
            zero = null; zeroByte = null; zeroObj = null;
            System.gc();
            pass(i, "OK");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        // Test 28: Large single object
        currentTest = "Large object";
        try {
            int size = 10000;
            byte[] large = null;
            while (size <= 100000) {
                try {
                    large = new byte[size];
                    large[0] = 1;
                    large[size - 1] = 1;
                    break;
                } catch (OutOfMemoryError e) {
                    size -= 5000;
                    if (size < 1000) break;
                }
            }
            long mid = runtime.freeMemory();
            large = null;
            System.gc();
            sleep(200);
            long after = runtime.freeMemory();
            if (after >= mid - 1000) pass(i, "max=" + size);
            else fail(i, "not freed");
        } catch (Throwable e) { fail(i, e.toString()); }
        i++;
        
        done = true;
        canvas.repaint();
    }
    
    static class FinalizerTest {
        static int finalizedCount = 0;
        protected void finalize() { finalizedCount++; }
    }
    
    static class FinalizerOrder {
        static int lastFinalized = -1;
        private int id;
        FinalizerOrder(int id) { this.id = id; }
        protected void finalize() { lastFinalized = id; }
    }
    
    static class GCMultiThread implements Runnable {
        String error = null;
        public void run() {
            try {
                for (int j = 0; j < 100; j++) {
                    byte[] b = new byte[1000];
                    b[0] = 1;
                    System.gc();
                    b = null;
                }
            } catch (Throwable e) { error = e.toString(); }
        }
    }
    
    static class ConcurrentAlloc implements Runnable {
        String error = null;
        public void run() {
            try {
                for (int j = 0; j < 500; j++) {
                    Object o = new byte[100];
                    System.gc();
                    Thread.sleep(1);
                }
            } catch (Throwable e) { error = e.toString(); }
        }
    }
    
    private class TestCanvas extends Canvas {
        private GCTestMidlet midlet;
        TestCanvas(GCTestMidlet m) { midlet = m; }
        
        protected void paint(Graphics g) {
            int w = getWidth();
            int h = getHeight();
            g.setColor(0x000000);
            g.fillRect(0, 0, w, h);
            
            g.setColor(0xFFFFFF);
            g.setFont(Font.getFont(0, Font.STYLE_BOLD, Font.SIZE_MEDIUM));
            g.drawString("GC Test", w/2, 3, Graphics.HCENTER|Graphics.TOP);
            
            g.setFont(Font.getFont(0, 0, Font.SIZE_SMALL));
            g.setColor(0xAAAAAA);
            g.drawString("PASS:" + passCount + " FAIL:" + failCount, w/2, 18, Graphics.HCENTER|Graphics.TOP);
            
            if (currentTest.length() > 0 && !done) {
                g.setColor(0xFFFF00);
                g.drawString("Running: " + currentTest, w/2, 30, Graphics.HCENTER|Graphics.TOP);
            }
            
            int y = 44;
            for (int i = 0; i < testNames.length && y < h - 15; i++) {
                if (results[i] == null) continue;
                if (results[i].startsWith("PASS")) g.setColor(0x00FF00);
                else if (results[i].startsWith("FAIL")) g.setColor(0xFF0000);
                else g.setColor(0x666666);
                String txt = testNames[i] + ":" + results[i];
                if (txt.length() > 35) txt = txt.substring(0, 35);
                g.drawString(txt, 2, y, 0);
                y += 11;
            }
            
            if (done) {
                g.setColor(passCount == testNames.length ? 0x00FF00 : 0xFFFF00);
                g.setFont(Font.getFont(0, Font.STYLE_BOLD, Font.SIZE_LARGE));
                g.drawString("DONE: " + passCount + "/" + testNames.length, w/2, h - 15, Graphics.HCENTER|Graphics.TOP);
            }
        }
    }
}
