import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.*;

public class VectorHashtableTestMidlet extends MIDlet {
    private Display display;
    private TestCanvas canvas;
    
    public VectorHashtableTestMidlet() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
    }
    
    public void startApp() {
        display.setCurrent(canvas);
        canvas.startTests();
    }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
}

class TestCanvas extends Canvas {
    private MIDlet midlet;
    private Vector results;
    private Vector testNames;
    private Vector testCategories;
    private boolean testsRunning = true;
    private int currentTest = 0;
    private Vector log = new Vector();
    private int passCount = 0;
    private int failCount = 0;
    
    public TestCanvas(MIDlet m) {
        this.midlet = m;
        
        results = new Vector();
        testNames = new Vector();
        testCategories = new Vector();
        
        // ========== VECTOR TESTS ==========
        // Basic operations
        addTest("Vector", "Create empty Vector");
        addTest("Vector", "Vector.size() on empty");
        addTest("Vector", "Vector.isEmpty() on empty");
        addTest("Vector", "Add single element");
        addTest("Vector", "Add multiple elements");
        addTest("Vector", "Get element by index");
        addTest("Vector", "Size after additions");
        addTest("Vector", "isEmpty after additions");
        addTest("Vector", "Set element at index");
        addTest("Vector", "Insert element at index");
        addTest("Vector", "Remove element at index");
        addTest("Vector", "Remove by Object reference");
        addTest("Vector", "Contains element");
        addTest("Vector", "IndexOf element");
        addTest("Vector", "IndexOf from index");
        addTest("Vector", "LastIndexOf element");
        addTest("Vector", "FirstElement");
        addTest("Vector", "LastElement");
        addTest("Vector", "Clear all elements");
        addTest("Vector", "Size after clear");
        addTest("Vector", "Clone Vector");
        addTest("Vector", "CopyInto array");
        addTest("Vector", "TrimToSize");
        addTest("Vector", "EnsureCapacity");
        addTest("Vector", "SetSize grow");
        addTest("Vector", "SetSize shrink");
        addTest("Vector", "Add null element");
        addTest("Vector", "Contains null");
        addTest("Vector", "Remove null");
        addTest("Vector", "Enumeration traversal");
        addTest("Vector", "ElementAt bounds check");
        addTest("Vector", "RemoveAllElements");
        addTest("Vector", "Add at beginning");
        addTest("Vector", "Add at end");
        addTest("Vector", "Multiple insert operations");
        addTest("Vector", "IndexOf not found");
        addTest("Vector", "Remove element not found returns false");
        
        // ========== HASHTABLE TESTS ==========
        addTest("Hashtable", "Create empty Hashtable");
        addTest("Hashtable", "Size on empty");
        addTest("Hashtable", "isEmpty on empty");
        addTest("Hashtable", "Put single entry");
        addTest("Hashtable", "Put multiple entries");
        addTest("Hashtable", "Get by key");
        addTest("Hashtable", "Get non-existent key");
        addTest("Hashtable", "ContainsKey exists");
        addTest("Hashtable", "ContainsKey not exists");
        addTest("Hashtable", "Contains value exists");
        addTest("Hashtable", "Contains value not exists");
        addTest("Hashtable", "Remove by key");
        addTest("Hashtable", "Remove non-existent key");
        addTest("Hashtable", "Size after operations");
        addTest("Hashtable", "Clear Hashtable");
        addTest("Hashtable", "Size after clear");
        addTest("Hashtable", "Keys enumeration");
        addTest("Hashtable", "Elements enumeration");
        addTest("Hashtable", "Overwrite value");
        addTest("Hashtable", "Get overwritten value");
        addTest("Hashtable", "Put null key throws NPE");
        addTest("Hashtable", "Put null value throws NPE");
        addTest("Hashtable", "Get null key throws NPE");
        addTest("Hashtable", "Contains null value");
        addTest("Hashtable", "Clone Hashtable");
        addTest("Hashtable", "String key test");
        addTest("Hashtable", "Integer key test");
        addTest("Hashtable", "Mixed key types");
        addTest("Hashtable", "Large number of entries");
        addTest("Hashtable", "Remove all entries one by one");
        addTest("Hashtable", "Put same key twice");
        addTest("Hashtable", "Keys hasMoreElements");
        addTest("Hashtable", "Elements hasMoreElements");
        addTest("Hashtable", "ContainsKey after remove");
        addTest("Hashtable", "Get after overwrite");
        addTest("Hashtable", "Remove returns old value");
        addTest("Hashtable", "Put returns old value");
        
        // ========== COMBINED TESTS ==========
        addTest("Combined", "Vector of Hashtables");
        addTest("Combined", "Hashtable with Vector values");
        addTest("Combined", "Nested structures");
        addTest("Combined", "Vector as Hashtable key");
        addTest("Combined", "Complex data structure");
        
        // Initialize all results to "?"
        for (int i = 0; i < testNames.size(); i++) {
            results.addElement("?");
        }
    }
    
    private void addTest(String category, String name) {
        testCategories.addElement(category);
        testNames.addElement(name);
    }
    
    private void setTestResult(int index, boolean passed) {
        if (passed) {
            results.setElementAt("PASS", index);
            passCount++;
        } else {
            results.setElementAt("FAIL", index);
            failCount++;
        }
    }
    
    private void addLog(String msg) {
        log.addElement(msg);
        if (log.size() > 15) {
            log.removeElementAt(0);
        }
        repaint();
    }
    
    public void startTests() {
        new Thread() {
            public void run() {
                runTests();
                testsRunning = false;
                repaint();
            }
        }.start();
    }
    
    private void runTests() {
        int testIndex = 0;
        
        // ========== VECTOR TESTS ==========
        
        // Test: Create empty Vector
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            boolean passed = (v != null);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": new Vector() - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Vector.size() on empty
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            boolean passed = (v.size() == 0);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": empty.size()=" + v.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Vector.isEmpty() on empty
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            boolean passed = v.isEmpty();
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": empty.isEmpty()=" + v.isEmpty() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Add single element
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("test");
            boolean passed = (v.size() == 1);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": addElement - size=" + v.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Add multiple elements
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("one");
            v.addElement("two");
            v.addElement("three");
            boolean passed = (v.size() == 3);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": add 3 elements - size=" + v.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Get element by index
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("first");
            v.addElement("second");
            Object elem = v.elementAt(1);
            boolean passed = "second".equals(elem);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": elementAt(1)=\"" + elem + "\" - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Size after additions
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            for (int i = 0; i < 10; i++) {
                v.addElement(new Integer(i));
            }
            boolean passed = (v.size() == 10);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": add 10 elements - size=" + v.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: isEmpty after additions
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("item");
            boolean passed = !v.isEmpty();
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": isEmpty after add=" + v.isEmpty() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Set element at index
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("old");
            v.addElement("value");
            v.setElementAt("new", 0);
            boolean passed = "new".equals(v.elementAt(0)) && "value".equals(v.elementAt(1));
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": setElementAt - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Insert element at index
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("one");
            v.addElement("three");
            v.insertElementAt("two", 1);
            boolean passed = "two".equals(v.elementAt(1)) && v.size() == 3;
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": insertElementAt - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove element at index
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement("b");
            v.addElement("c");
            v.removeElementAt(1);
            boolean passed = (v.size() == 2) && "a".equals(v.elementAt(0)) && "c".equals(v.elementAt(1));
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": removeElementAt(1) - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove by Object reference
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("x");
            v.addElement("y");
            v.addElement("z");
            boolean removed = v.removeElement("y");
            boolean passed = removed && v.size() == 2 && !v.contains("y");
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": removeElement(\"y\")=" + removed + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Contains element
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("apple");
            v.addElement("banana");
            boolean passed = v.contains("apple") && v.contains("banana") && !v.contains("orange");
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": contains - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: IndexOf element
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("first");
            v.addElement("second");
            v.addElement("third");
            int idx = v.indexOf("second");
            boolean passed = (idx == 1);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": indexOf(\"second\")=" + idx + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: IndexOf from index
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement("b");
            v.addElement("a");
            v.addElement("b");
            int idx = v.indexOf("b", 2);
            boolean passed = (idx == 3);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": indexOf(\"b\",2)=" + idx + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: LastIndexOf element
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("x");
            v.addElement("y");
            v.addElement("x");
            int idx = v.lastIndexOf("x");
            boolean passed = (idx == 2);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": lastIndexOf(\"x\")=" + idx + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: FirstElement
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("head");
            v.addElement("tail");
            Object first = v.firstElement();
            boolean passed = "head".equals(first);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": firstElement()=\"" + first + "\" - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: LastElement
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("head");
            v.addElement("tail");
            Object last = v.lastElement();
            boolean passed = "tail".equals(last);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": lastElement()=\"" + last + "\" - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Clear all elements
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement("b");
            v.addElement("c");
            v.removeAllElements();
            boolean passed = v.isEmpty();
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": removeAllElements - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Size after clear
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("x");
            v.addElement("y");
            v.removeAllElements();
            boolean passed = (v.size() == 0);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": size after clear=" + v.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Copy Vector manually (clone not public in J2ME)
        currentTest = testIndex;
        try {
            Vector v1 = new Vector();
            v1.addElement("copy");
            v1.addElement("test");
            Vector v2 = new Vector();
            for (int i = 0; i < v1.size(); i++) {
                v2.addElement(v1.elementAt(i));
            }
            boolean passed = (v1 != v2) && v1.size() == v2.size() && 
                            v1.elementAt(0).equals(v2.elementAt(0));
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": copy vector - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: CopyInto array
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("one");
            v.addElement("two");
            Object[] arr = new Object[2];
            v.copyInto(arr);
            boolean passed = "one".equals(arr[0]) && "two".equals(arr[1]);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": copyInto - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: TrimToSize
        currentTest = testIndex;
        try {
            Vector v = new Vector(10);
            v.addElement("a");
            v.trimToSize();
            boolean passed = (v.size() == 1); // capacity info not directly accessible
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": trimToSize - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: EnsureCapacity
        currentTest = testIndex;
        try {
            Vector v = new Vector(2);
            v.ensureCapacity(100);
            for (int i = 0; i < 50; i++) {
                v.addElement(new Integer(i));
            }
            boolean passed = (v.size() == 50);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": ensureCapacity - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: SetSize grow
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.setSize(5);
            boolean passed = (v.size() == 5) && "a".equals(v.elementAt(0));
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": setSize grow - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: SetSize shrink
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement("b");
            v.addElement("c");
            v.setSize(1);
            boolean passed = (v.size() == 1) && "a".equals(v.elementAt(0));
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": setSize shrink - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Add null element
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement(null);
            boolean passed = (v.size() == 1) && (v.elementAt(0) == null);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": addElement(null) - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Contains null
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement(null);
            v.addElement("b");
            boolean passed = v.contains(null);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": contains(null) - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove null
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement(null);
            v.addElement("b");
            boolean removed = v.removeElement(null);
            boolean passed = removed && v.size() == 2 && !v.contains(null);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": removeElement(null) - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Enumeration traversal
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("1");
            v.addElement("2");
            v.addElement("3");
            int count = 0;
            String result = "";
            for (Enumeration e = v.elements(); e.hasMoreElements(); ) {
                result += (String) e.nextElement();
                count++;
            }
            boolean passed = (count == 3) && "123".equals(result);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": enumeration - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: ElementAt bounds check
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            boolean caught = false;
            try {
                v.elementAt(5);
            } catch (ArrayIndexOutOfBoundsException ex) {
                caught = true;
            }
            setTestResult(testIndex, caught);
            addLog("V" + (testIndex+1) + ": elementAt bounds check - " + (caught ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: RemoveAllElements
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("x");
            v.addElement("y");
            v.addElement("z");
            v.removeAllElements();
            boolean passed = v.isEmpty() && v.size() == 0;
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": removeAllElements - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Add at beginning (insertElementAt 0)
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("middle");
            v.insertElementAt("start", 0);
            boolean passed = "start".equals(v.firstElement()) && v.size() == 2;
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": insertElementAt(0) - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Add at end
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("first");
            v.addElement("last");
            boolean passed = "last".equals(v.lastElement()) && v.size() == 2;
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": add at end - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Multiple insert operations
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.insertElementAt("b", 0);
            v.insertElementAt("a", 0);
            v.insertElementAt("c", 2);
            boolean passed = "a".equals(v.elementAt(0)) && "b".equals(v.elementAt(1)) && "c".equals(v.elementAt(2));
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": multiple inserts - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: IndexOf not found
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            v.addElement("b");
            int idx = v.indexOf("c");
            boolean passed = (idx == -1);
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": indexOf not found=" + idx + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove element not found returns false
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            v.addElement("a");
            boolean removed = v.removeElement("notexist");
            boolean passed = !removed && v.size() == 1;
            setTestResult(testIndex, passed);
            addLog("V" + (testIndex+1) + ": remove not found=" + removed + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("V" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        addLog("=== VECTOR TESTS COMPLETED ===");
        
        // ========== HASHTABLE TESTS ==========
        
        // Test: Create empty Hashtable
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            boolean passed = (h != null);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": new Hashtable() - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Size on empty
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            boolean passed = (h.size() == 0);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": empty size=" + h.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: isEmpty on empty
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            boolean passed = h.isEmpty();
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": empty.isEmpty()=" + h.isEmpty() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Put single entry
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("key", "value");
            boolean passed = (h.size() == 1);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": put single - size=" + h.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Put multiple entries
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("k1", "v1");
            h.put("k2", "v2");
            h.put("k3", "v3");
            boolean passed = (h.size() == 3);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": put 3 entries - size=" + h.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Get by key
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("name", "John");
            Object val = h.get("name");
            boolean passed = "John".equals(val);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": get(\"name\")=\"" + val + "\" - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Get non-existent key
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            Object val = h.get("nonexistent");
            boolean passed = (val == null);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": get non-existent=" + val + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: ContainsKey exists
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("testkey", "testvalue");
            boolean passed = h.containsKey("testkey");
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": containsKey(\"testkey\") - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: ContainsKey not exists
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "b");
            boolean passed = !h.containsKey("notexist");
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": containsKey not exist - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Contains value exists
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("key1", "value1");
            h.put("key2", "value2");
            boolean passed = h.contains("value1") && h.contains("value2");
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": contains value - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Contains value not exists
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "b");
            boolean passed = !h.contains("notexist");
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": contains not exist - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove by key
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("del", "value");
            Object removed = h.remove("del");
            boolean passed = "value".equals(removed) && h.size() == 0;
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": remove - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove non-existent key
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            Object removed = h.remove("nonexistent");
            boolean passed = (removed == null) && h.size() == 1;
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": remove non-existent - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Size after operations
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            h.put("b", "2");
            h.put("c", "3");
            h.remove("b");
            boolean passed = (h.size() == 2);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": size after ops=" + h.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Clear Hashtable
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            h.put("b", "2");
            h.clear();
            boolean passed = h.isEmpty();
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": clear - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Size after clear
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("x", "y");
            h.clear();
            boolean passed = (h.size() == 0);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": size after clear=" + h.size() + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Keys enumeration
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("k1", "v1");
            h.put("k2", "v2");
            int count = 0;
            for (Enumeration e = h.keys(); e.hasMoreElements(); ) {
                e.nextElement();
                count++;
            }
            boolean passed = (count == 2);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": keys enum count=" + count + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Elements enumeration
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("k1", "v1");
            h.put("k2", "v2");
            int count = 0;
            for (Enumeration e = h.elements(); e.hasMoreElements(); ) {
                e.nextElement();
                count++;
            }
            boolean passed = (count == 2);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": elements enum count=" + count + " - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Overwrite value
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("key", "old");
            h.put("key", "new");
            Object val = h.get("key");
            boolean passed = "new".equals(val) && h.size() == 1;
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": overwrite - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Get overwritten value
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("key", "original");
            Object old = h.put("key", "replacement");
            boolean passed = "original".equals(old);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": put returns old - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Put null key throws NPE
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            boolean caught = false;
            try {
                h.put(null, "value");
            } catch (NullPointerException ex) {
                caught = true;
            }
            setTestResult(testIndex, caught);
            addLog("H" + (testIndex+1) + ": put null key NPE - " + (caught ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Put null value throws NPE
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            boolean caught = false;
            try {
                h.put("key", null);
            } catch (NullPointerException ex) {
                caught = true;
            }
            setTestResult(testIndex, caught);
            addLog("H" + (testIndex+1) + ": put null value NPE - " + (caught ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Get null key throws NPE
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "b");
            boolean caught = false;
            try {
                h.get(null);
            } catch (NullPointerException ex) {
                caught = true;
            }
            setTestResult(testIndex, caught);
            addLog("H" + (testIndex+1) + ": get null key NPE - " + (caught ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Contains null value
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "b");
            boolean passed = !h.contains(null);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": contains(null) - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Copy Hashtable manually (clone not public in J2ME)
        currentTest = testIndex;
        try {
            Hashtable h1 = new Hashtable();
            h1.put("a", "1");
            h1.put("b", "2");
            Hashtable h2 = new Hashtable();
            for (Enumeration e = h1.keys(); e.hasMoreElements(); ) {
                Object key = e.nextElement();
                h2.put(key, h1.get(key));
            }
            boolean passed = (h1 != h2) && h1.size() == h2.size() && "1".equals(h2.get("a"));
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": copy hashtable - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: String key test
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            String key1 = new String("key");
            String key2 = new String("key");
            h.put(key1, "value1");
            h.put(key2, "value2");
            boolean passed = h.size() == 1 && "value2".equals(h.get("key"));
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": string key equality - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Integer key test
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put(new Integer(1), "one");
            h.put(new Integer(2), "two");
            boolean passed = "one".equals(h.get(new Integer(1)));
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": Integer key - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Mixed key types
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("string", "sval");
            h.put(new Integer(42), "ival");
            h.put(new Long(100L), "lval");
            boolean passed = h.size() == 3 && "sval".equals(h.get("string")) && "ival".equals(h.get(new Integer(42)));
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": mixed keys - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Large number of entries
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            for (int i = 0; i < 100; i++) {
                h.put("key" + i, "value" + i);
            }
            boolean passed = (h.size() == 100) && "value50".equals(h.get("key50"));
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": 100 entries - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove all entries one by one
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            h.put("b", "2");
            h.put("c", "3");
            h.remove("a");
            h.remove("b");
            h.remove("c");
            boolean passed = h.isEmpty();
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": remove all one by one - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Put same key twice
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            Object old1 = h.put("key", "first");
            Object old2 = h.put("key", "second");
            boolean passed = (old1 == null) && "first".equals(old2) && h.size() == 1;
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": put same key twice - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Keys hasMoreElements
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            Enumeration e = h.keys();
            boolean passed = e.hasMoreElements();
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": keys hasMoreElements - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Elements hasMoreElements
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("a", "1");
            Enumeration e = h.elements();
            boolean passed = e.hasMoreElements();
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": elements hasMoreElements - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: ContainsKey after remove
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("del", "value");
            h.remove("del");
            boolean passed = !h.containsKey("del");
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": containsKey after remove - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Get after overwrite
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("key", "old");
            h.put("key", "new");
            boolean passed = "new".equals(h.get("key"));
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": get after overwrite - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Remove returns old value
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("key", "toremove");
            Object removed = h.remove("key");
            boolean passed = "toremove".equals(removed);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": remove returns value - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Put returns old value
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            h.put("k", "v1");
            Object old = h.put("k", "v2");
            boolean passed = "v1".equals(old);
            setTestResult(testIndex, passed);
            addLog("H" + (testIndex+1) + ": put returns old - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("H" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        addLog("=== HASHTABLE TESTS COMPLETED ===");
        
        // ========== COMBINED TESTS ==========
        
        // Test: Vector of Hashtables
        currentTest = testIndex;
        try {
            Vector v = new Vector();
            Hashtable h1 = new Hashtable();
            h1.put("a", "1");
            Hashtable h2 = new Hashtable();
            h2.put("b", "2");
            v.addElement(h1);
            v.addElement(h2);
            boolean passed = v.size() == 2 && "1".equals(((Hashtable)v.elementAt(0)).get("a"));
            setTestResult(testIndex, passed);
            addLog("C" + (testIndex+1) + ": Vector of Hashtable - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("C" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Hashtable with Vector values
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            Vector v1 = new Vector();
            v1.addElement("item1");
            v1.addElement("item2");
            h.put("list", v1);
            Vector retrieved = (Vector) h.get("list");
            boolean passed = retrieved.size() == 2 && "item1".equals(retrieved.elementAt(0));
            setTestResult(testIndex, passed);
            addLog("C" + (testIndex+1) + ": Hashtable with Vector - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("C" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Nested structures
        currentTest = testIndex;
        try {
            Hashtable outer = new Hashtable();
            Vector inner = new Vector();
            Hashtable nested = new Hashtable();
            nested.put("deep", "value");
            inner.addElement(nested);
            outer.put("vector", inner);
            Vector v = (Vector) outer.get("vector");
            Hashtable n = (Hashtable) v.elementAt(0);
            boolean passed = "value".equals(n.get("deep"));
            setTestResult(testIndex, passed);
            addLog("C" + (testIndex+1) + ": nested structures - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("C" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Vector as Hashtable key
        currentTest = testIndex;
        try {
            Hashtable h = new Hashtable();
            Vector key1 = new Vector();
            key1.addElement("keypart");
            h.put(key1, "value");
            boolean passed = "value".equals(h.get(key1));
            setTestResult(testIndex, passed);
            addLog("C" + (testIndex+1) + ": Vector as key - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("C" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        // Test: Complex data structure
        currentTest = testIndex;
        try {
            Hashtable db = new Hashtable();
            for (int i = 0; i < 5; i++) {
                Vector record = new Vector();
                record.addElement("name" + i);
                record.addElement(new Integer(i * 10));
                Hashtable details = new Hashtable();
                details.put("active", i % 2 == 0 ? "yes" : "no");
                record.addElement(details);
                db.put(new Integer(i), record);
            }
            Vector rec = (Vector) db.get(new Integer(2));
            Hashtable det = (Hashtable) rec.elementAt(2);
            boolean passed = db.size() == 5 && "name2".equals(rec.elementAt(0)) && "yes".equals(det.get("active"));
            setTestResult(testIndex, passed);
            addLog("C" + (testIndex+1) + ": complex structure - " + (passed ? "PASS" : "FAIL"));
        } catch (Exception e) {
            results.setElementAt("ERROR", testIndex);
            failCount++;
            addLog("C" + (testIndex+1) + ": ERROR - " + e.getClass().getName());
        }
        testIndex++; sleep(100);
        
        addLog("=== ALL TESTS COMPLETED ===");
        addLog("Passed: " + passCount + " Failed: " + failCount);
    }
    
    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }
    
    protected void paint(Graphics g) {
        g.setColor(255, 255, 255);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        int y = 15;
        int width = getWidth();
        
        // Header
        g.setColor(0, 0, 0);
        g.drawString("Vector & Hashtable Tests", width/2, y, Graphics.TOP | Graphics.HCENTER);
        y += 25;
        
        if (testsRunning) {
            // Current test info
            g.setColor(0, 0, 150);
            g.drawString("Running: " + (currentTest + 1) + "/" + testNames.size(), 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            String category = (String) testCategories.elementAt(currentTest);
            String name = (String) testNames.elementAt(currentTest);
            
            g.setColor(100, 100, 100);
            g.drawString("[" + category + "]", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;
            
            g.setColor(0, 0, 0);
            g.drawString(name, 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            String result = (String) results.elementAt(currentTest);
            if ("PASS".equals(result)) {
                g.setColor(0, 150, 0);
            } else if ("FAIL".equals(result) || "ERROR".equals(result)) {
                g.setColor(200, 0, 0);
            } else {
                g.setColor(150, 150, 0);
            }
            g.drawString("Result: " + result, 5, y, Graphics.TOP | Graphics.LEFT);
            y += 25;
            
            // Progress bar
            y = getHeight() - 60;
            g.setColor(100, 100, 100);
            g.drawString("Progress: " + passCount + " pass, " + failCount + " fail", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;
            
            int progressWidth = (width - 40) * (currentTest + 1) / testNames.size();
            g.setColor(0, 150, 0);
            g.fillRect(20, y, progressWidth, 10);
            g.setColor(200, 200, 200);
            g.fillRect(20 + progressWidth, y, (width - 40) - progressWidth, 10);
            y += 20;
            
            // Log
            g.setColor(100, 100, 100);
            g.drawString("--- Log ---", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;
            
            g.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_PLAIN, Font.SIZE_SMALL));
            int startIdx = Math.max(0, log.size() - 8);
            for (int i = startIdx; i < log.size(); i++) {
                String msg = (String) log.elementAt(i);
                g.drawString(msg, 5, y, Graphics.TOP | Graphics.LEFT);
                y += 12;
            }
            
        } else {
            // Show summary
            g.setColor(0, 0, 0);
            g.drawString("RESULTS SUMMARY", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 25;
            
            g.setColor(0, 150, 0);
            g.drawString("Passed: " + passCount, 10, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            g.setColor(200, 0, 0);
            g.drawString("Failed: " + failCount, 10, y, Graphics.TOP | Graphics.LEFT);
            y += 25;
            
            g.setColor(0, 0, 0);
            g.drawString("Total: " + testNames.size() + " tests", 10, y, Graphics.TOP | Graphics.LEFT);
            y += 30;
            
            // Show last few results
            g.drawString("Recent results:", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            int start = Math.max(0, testNames.size() - 6);
            for (int i = start; i < testNames.size(); i++) {
                String res = (String) results.elementAt(i);
                String cat = (String) testCategories.elementAt(i);
                String nm = (String) testNames.elementAt(i);
                
                if ("PASS".equals(res)) {
                    g.setColor(0, 150, 0);
                } else {
                    g.setColor(200, 0, 0);
                }
                
                String display = res + " [" + cat + "] " + nm;
                if (display.length() > 30) {
                    display = display.substring(0, 30) + "...";
                }
                g.drawString(display, 5, y, Graphics.TOP | Graphics.LEFT);
                y += 15;
            }
            
            g.setColor(0, 0, 150);
            g.drawString("Press any key to exit", width/2, getHeight() - 15, 
                        Graphics.BOTTOM | Graphics.HCENTER);
        }
    }
    
    protected void keyPressed(int keyCode) {
        if (!testsRunning) {
            midlet.notifyDestroyed();
        }
    }
}
