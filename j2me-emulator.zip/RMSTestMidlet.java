import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class RMSTestMidlet extends MIDlet {
    private Display display;
    private TestCanvas canvas;

    public RMSTestMidlet() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
    }

    public void startApp() {
        display.setCurrent(canvas);
        canvas.startTests();
    }

    public void pauseApp() {}

    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
}

class TestCanvas extends Canvas {
    private MIDlet midlet;
    private String[] results;
    private String[] testNames;
    private boolean testsRunning = true;
    private int currentTest = 0;
    private String[] log = new String[20];
    private int logIndex = 0;
    private int passCount = 0;
    private int failCount = 0;
    private int skipCount = 0;

    public TestCanvas(MIDlet m) {
        this.midlet = m;

        testNames = new String[] {
            // Basic RMS operations
            "Create RecordStore",
            "Add Record",
            "Get Record",
            "Update Record",
            "Enumerate Records",
            "Get Record Size",
            "Get NumRecords",
            "Delete Record",
            "Close RecordStore",
            "Delete RecordStore",
            // Data type tests
            "Write/Read Boolean",
            "Write/Read Byte",
            "Write/Read Short",
            "Write/Read Int",
            "Write/Read Long",
            "Write/Read Char",
            "Write/Read UTF String",
            "Write/Read UTF8 Cyrillic",
            "Write/Read UTF8 Chinese",
            "Write/Read Float (fixed)",
            "Mixed Data Types",
            "Large Data Block",
            "Multiple RecordStores",
            "RecordStore Info"
        };
        results = new String[testNames.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = "?";
        }

        for (int i = 0; i < log.length; i++) {
            log[i] = "";
        }
    }

    private void addLog(String msg) {
        log[logIndex % log.length] = msg;
        logIndex++;
        repaint();
    }

    public void startTests() {
        new Thread() {
            public void run() {
                runTests();
                testsRunning = false;
                repaint();
            }
        }.start();
    }

    private void runTests() {
        RecordStore rs = null;
        String storeName = "TestRMS";

        // ==================== BASIC RMS TESTS ====================

        // Test 0: Create RecordStore
        currentTest = 0;
        try {
            try {
                RecordStore.deleteRecordStore(storeName);
            } catch (Exception e) { }

            rs = RecordStore.openRecordStore(storeName, true);
            results[0] = (rs != null) ? "PASS" : "FAIL";
            addLog("Test 0: Open store '" + storeName + "' - " + results[0]);
        } catch (Exception e) {
            results[0] = "FAIL";
            addLog("Test 0: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 1: Add Record
        currentTest = 1;
        int recordId1 = -1;
        try {
            String data = "Hello RMS!";
            byte[] dataBytes = data.getBytes();
            recordId1 = rs.addRecord(dataBytes, 0, dataBytes.length);
            results[1] = (recordId1 > 0) ? "PASS" : "FAIL";
            addLog("Test 1: Add record ID=" + recordId1 + " - " + results[1]);
        } catch (Exception e) {
            results[1] = "FAIL";
            addLog("Test 1: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 2: Get Record
        currentTest = 2;
        try {
            byte[] retrieved = rs.getRecord(recordId1);
            String retrievedStr = new String(retrieved);
            boolean match = "Hello RMS!".equals(retrievedStr);
            results[2] = match ? "PASS" : "FAIL";
            addLog("Test 2: Get '" + retrievedStr + "' - " + results[2]);
        } catch (Exception e) {
            results[2] = "FAIL";
            addLog("Test 2: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 3: Update Record
        currentTest = 3;
        try {
            String newData = "Updated Data";
            byte[] newBytes = newData.getBytes();
            rs.setRecord(recordId1, newBytes, 0, newBytes.length);

            byte[] check = rs.getRecord(recordId1);
            String checkStr = new String(check);
            boolean match = newData.equals(checkStr);
            results[3] = match ? "PASS" : "FAIL";
            addLog("Test 3: Update to '" + checkStr + "' - " + results[3]);
        } catch (Exception e) {
            results[3] = "FAIL";
            addLog("Test 3: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 4: Enumerate Records
        currentTest = 4;
        try {
            RecordEnumeration re = rs.enumerateRecords(null, null, false);
            int count = 0;
            while (re.hasNextElement()) {
                int id = re.nextRecordId();
                count++;
            }
            results[4] = (count >= 1) ? "PASS" : "FAIL";
            addLog("Test 4: Enumerate found " + count + " records - " + results[4]);
        } catch (Exception e) {
            results[4] = "FAIL";
            addLog("Test 4: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 5: Get Record Size
        currentTest = 5;
        try {
            int size = rs.getRecordSize(recordId1);
            results[5] = (size > 0) ? "PASS" : "FAIL";
            addLog("Test 5: Record size = " + size + " bytes - " + results[5]);
        } catch (Exception e) {
            results[5] = "FAIL";
            addLog("Test 5: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 6: Get NumRecords
        currentTest = 6;
        try {
            int numRecords = rs.getNumRecords();
            results[6] = (numRecords >= 1) ? "PASS" : "FAIL";
            addLog("Test 6: NumRecords = " + numRecords + " - " + results[6]);
        } catch (Exception e) {
            results[6] = "FAIL";
            addLog("Test 6: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 7: Delete Record
        currentTest = 7;
        try {
            rs.deleteRecord(recordId1);

            boolean deleted = false;
            try {
                rs.getRecord(recordId1);
            } catch (InvalidRecordIDException ire) {
                deleted = true;
            }
            results[7] = deleted ? "PASS" : "FAIL";
            addLog("Test 7: Delete record - " + results[7]);
        } catch (Exception e) {
            results[7] = "FAIL";
            addLog("Test 7: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 8: Close RecordStore
        currentTest = 8;
        try {
            rs.closeRecordStore();
            results[8] = "PASS";
            addLog("Test 8: Close store - " + results[8]);
        } catch (Exception e) {
            results[8] = "FAIL";
            addLog("Test 8: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 9: Delete RecordStore
        currentTest = 9;
        try {
            RecordStore.deleteRecordStore(storeName);
            results[9] = "PASS";
            addLog("Test 9: Delete store '" + storeName + "' - " + results[9]);
        } catch (Exception e) {
            results[9] = "FAIL";
            addLog("Test 9: ERROR - " + e.getMessage());
        }
        sleep(300);

        // ==================== DATA TYPE TESTS ====================

        // Open new store for data type tests
        String dataStoreName = "DataTypesTest";
        RecordStore dataRs = null;
        try {
            try { RecordStore.deleteRecordStore(dataStoreName); } catch (Exception e) { }
            dataRs = RecordStore.openRecordStore(dataStoreName, true);
        } catch (Exception e) {
            addLog("Failed to open data store: " + e.getMessage());
        }

        // Test 10: Write/Read Boolean
        currentTest = 10;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeBoolean(true);
            dos.writeBoolean(false);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            boolean b1 = dis.readBoolean();
            boolean b2 = dis.readBoolean();

            results[10] = (b1 == true && b2 == false) ? "PASS" : "FAIL";
            addLog("Test 10: Boolean true=" + b1 + ", false=" + b2 + " - " + results[10]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[10] = "FAIL";
            addLog("Test 10: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 11: Write/Read Byte
        currentTest = 11;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeByte(127);
            dos.writeByte(-128);
            dos.writeByte(0);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            int v1 = dis.readByte();
            int v2 = dis.readByte();
            int v3 = dis.readByte();

            boolean ok = (v1 == 127 && v2 == -128 && v3 == 0);
            results[11] = ok ? "PASS" : "FAIL";
            addLog("Test 11: Byte 127,-128,0 = " + v1 + "," + v2 + "," + v3 + " - " + results[11]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[11] = "FAIL";
            addLog("Test 11: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 12: Write/Read Short
        currentTest = 12;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeShort(32767);
            dos.writeShort(-32768);
            dos.writeShort(1000);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            short s1 = dis.readShort();
            short s2 = dis.readShort();
            short s3 = dis.readShort();

            boolean ok = (s1 == 32767 && s2 == -32768 && s3 == 1000);
            results[12] = ok ? "PASS" : "FAIL";
            addLog("Test 12: Short max,min,1000 = " + s1 + "," + s2 + "," + s3 + " - " + results[12]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[12] = "FAIL";
            addLog("Test 12: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 13: Write/Read Int
        currentTest = 13;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeInt(2147483647);  // Integer.MAX_VALUE
            dos.writeInt(-2147483648); // Integer.MIN_VALUE
            dos.writeInt(12345678);
            dos.writeInt(-999999);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            int i1 = dis.readInt();
            int i2 = dis.readInt();
            int i3 = dis.readInt();
            int i4 = dis.readInt();

            boolean ok = (i1 == 2147483647 && i2 == -2147483648 && i3 == 12345678 && i4 == -999999);
            results[13] = ok ? "PASS" : "FAIL";
            addLog("Test 13: Int max,min,12345678,-999999 - " + results[13]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[13] = "FAIL";
            addLog("Test 13: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 14: Write/Read Long
        currentTest = 14;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeLong(9223372036854775807L);  // Long.MAX_VALUE
            dos.writeLong(-9223372036854775808L); // Long.MIN_VALUE
            dos.writeLong(1234567890123L);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            long l1 = dis.readLong();
            long l2 = dis.readLong();
            long l3 = dis.readLong();

            boolean ok = (l1 == 9223372036854775807L && l2 == -9223372036854775808L && l3 == 1234567890123L);
            results[14] = ok ? "PASS" : "FAIL";
            addLog("Test 14: Long max,min,1234567890123 - " + results[14]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[14] = "FAIL";
            addLog("Test 14: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 15: Write/Read Char
        currentTest = 15;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeChar('A');
            dos.writeChar('Z');
            dos.writeChar('0');
            dos.writeChar(0x410);  // Cyrillic 'А'
            dos.writeChar(0x4E2D); // Chinese '中'
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            char c1 = dis.readChar();
            char c2 = dis.readChar();
            char c3 = dis.readChar();
            char c4 = dis.readChar();
            char c5 = dis.readChar();

            boolean ok = (c1 == 'A' && c2 == 'Z' && c3 == '0' && c4 == 0x410 && c5 == 0x4E2D);
            results[15] = ok ? "PASS" : "FAIL";
            addLog("Test 15: Char A,Z,0,Cyr,Chi - " + results[15]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[15] = "FAIL";
            addLog("Test 15: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 16: Write/Read UTF String
        currentTest = 16;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeUTF("Hello World!");
            dos.writeUTF("");
            dos.writeUTF("Test123");
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            String s1 = dis.readUTF();
            String s2 = dis.readUTF();
            String s3 = dis.readUTF();

            boolean ok = "Hello World!".equals(s1) && "".equals(s2) && "Test123".equals(s3);
            results[16] = ok ? "PASS" : "FAIL";
            addLog("Test 16: UTF 'Hello World!','','Test123' - " + results[16]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[16] = "FAIL";
            addLog("Test 16: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 17: Write/Read UTF8 Cyrillic
        currentTest = 17;
        try {
            String cyrillic = "Привет мир! Тест русского текста.";
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeUTF(cyrillic);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            String read = dis.readUTF();

            boolean ok = cyrillic.equals(read);
            results[17] = ok ? "PASS" : "FAIL";
            addLog("Test 17: Cyrillic '" + cyrillic + "' - " + results[17]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[17] = "FAIL";
            addLog("Test 17: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 18: Write/Read UTF8 Chinese
        currentTest = 18;
        try {
            // Use Unicode escapes to avoid encoding issues
            // "中文测试 你好世界 数据存储"
            String chinese = "\u4e2d\u6587\u6d4b\u8bd5 \u4f60\u597d\u4e16\u754c \u6570\u636e\u5b58\u50a8";
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeUTF(chinese);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            String read = dis.readUTF();

            boolean ok = chinese.equals(read);
            results[18] = ok ? "PASS" : "FAIL";
            addLog("Test 18: Chinese - " + results[18]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[18] = "FAIL";
            addLog("Test 18: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 19: Write/Read Float (CLDC 1.1)
        currentTest = 19;
        try {
            // CLDC 1.1 supports float/double
            // writeFloat uses IEEE 754 single-precision format (4 bytes)
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeFloat(3.14159f);
            dos.writeFloat(-273.15f);
            dos.writeFloat(0.001f);
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            float f1 = dis.readFloat();
            float f2 = dis.readFloat();
            float f3 = dis.readFloat();

            // Check with tolerance for floating point comparison
            boolean ok = (f1 > 3.141f && f1 < 3.142f) &&
                        (f2 < -273.0f && f2 > -274.0f) &&
                        (f3 > 0.0009f && f3 < 0.0011f);
            results[19] = ok ? "PASS" : "FAIL";
            addLog("Test 19: Float " + f1 + "," + f2 + "," + f3 + " - " + results[19]);
            dataRs.deleteRecord(id);
        } catch (Throwable e) {
            // CLDC 1.0 doesn't support float - catches Error or Exception
            results[19] = "SKIP";
            addLog("Test 19: Float not supported - " + e.getClass().getName());
        }
        sleep(300);

        // Test 20: Mixed Data Types
        currentTest = 20;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.writeBoolean(true);
            dos.writeByte(100);
            dos.writeShort(5000);
            dos.writeInt(123456);
            dos.writeLong(9876543210L);
            dos.writeChar('X');
            dos.writeUTF("Mixed");
            dos.flush();
            byte[] data = baos.toByteArray();
            int id = dataRs.addRecord(data, 0, data.length);

            byte[] readData = dataRs.getRecord(id);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(readData));
            boolean b = dis.readBoolean();
            byte by = dis.readByte();
            short sh = dis.readShort();
            int in = dis.readInt();
            long lo = dis.readLong();
            char ch = dis.readChar();
            String st = dis.readUTF();

            boolean ok = (b == true && by == 100 && sh == 5000 && 
                         in == 123456 && lo == 9876543210L && 
                         ch == 'X' && "Mixed".equals(st));
            results[20] = ok ? "PASS" : "FAIL";
            addLog("Test 20: Mixed types bool,byte,short,int,long,char,utf - " + results[20]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[20] = "FAIL";
            addLog("Test 20: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 21: Large Data Block
        currentTest = 21;
        try {
            // Create a large data block (several KB)
            int size = 4096;
            byte[] largeData = new byte[size];
            for (int i = 0; i < size; i++) {
                largeData[i] = (byte)(i % 256);
            }
            
            int id = dataRs.addRecord(largeData, 0, largeData.length);
            byte[] readData = dataRs.getRecord(id);

            // Verify data
            boolean ok = (readData.length == size);
            if (ok) {
                for (int i = 0; i < size; i++) {
                    if (readData[i] != (byte)(i % 256)) {
                        ok = false;
                        addLog("Test 21: Mismatch at byte " + i);
                        break;
                    }
                }
            }
            results[21] = ok ? "PASS" : "FAIL";
            addLog("Test 21: Large " + size + " bytes - " + results[21]);
            dataRs.deleteRecord(id);
        } catch (Exception e) {
            results[21] = "FAIL";
            addLog("Test 21: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 22: Multiple RecordStores
        currentTest = 22;
        try {
            String[] storeNames = {"Store1", "Store2", "Store3"};
            RecordStore[] stores = new RecordStore[3];
            
            // Open multiple stores
            for (int i = 0; i < 3; i++) {
                try { RecordStore.deleteRecordStore(storeNames[i]); } catch (Exception e) { }
                stores[i] = RecordStore.openRecordStore(storeNames[i], true);
            }
            
            // Add records to each
            for (int i = 0; i < 3; i++) {
                String data = "Data for store " + i;
                stores[i].addRecord(data.getBytes(), 0, data.length());
            }
            
            // Verify
            boolean ok = true;
            for (int i = 0; i < 3; i++) {
                if (stores[i].getNumRecords() != 1) ok = false;
                stores[i].closeRecordStore();
                RecordStore.deleteRecordStore(storeNames[i]);
            }
            
            results[22] = ok ? "PASS" : "FAIL";
            addLog("Test 22: 3 RecordStores created/deleted - " + results[22]);
        } catch (Exception e) {
            results[22] = "FAIL";
            addLog("Test 22: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Test 23: RecordStore Info
        currentTest = 23;
        try {
            String infoStore = "InfoTest";
            try { RecordStore.deleteRecordStore(infoStore); } catch (Exception e) { }
            RecordStore infoRs = RecordStore.openRecordStore(infoStore, true);
            
            String name = infoRs.getName();
            int version = infoRs.getVersion();
            long lastModified = infoRs.getLastModified();
            int sizeAvailable = infoRs.getSizeAvailable();
            int size = infoRs.getSize();
            
            infoRs.closeRecordStore();
            RecordStore.deleteRecordStore(infoStore);
            
            boolean ok = (name != null && name.equals(infoStore) && version >= 0);
            results[23] = ok ? "PASS" : "FAIL";
            addLog("Test 23: Info name=" + name + " ver=" + version + " - " + results[23]);
        } catch (Exception e) {
            results[23] = "FAIL";
            addLog("Test 23: ERROR - " + e.getMessage());
        }
        sleep(300);

        // Close data store
        try {
            dataRs.closeRecordStore();
            RecordStore.deleteRecordStore(dataStoreName);
        } catch (Exception e) { }

        // Count results
        passCount = 0;
        failCount = 0;
        skipCount = 0;
        for (int i = 0; i < results.length; i++) {
            if (results[i].equals("PASS")) passCount++;
            else if (results[i].equals("FAIL")) failCount++;
            else if (results[i].equals("SKIP")) skipCount++;
        }

        addLog("=== RMS TESTS COMPLETED ===");
        addLog("PASSED: " + passCount + "/" + testNames.length);
        if (skipCount > 0) addLog("SKIPPED: " + skipCount);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }

    protected void paint(Graphics g) {
        g.setColor(255, 255, 255);
        g.fillRect(0, 0, getWidth(), getHeight());

        int y = 12;
        int width = getWidth();

        // Title
        g.setColor(0, 0, 128);
        g.drawString("RMS (RecordStore) Tests", width/2, y, Graphics.TOP | Graphics.HCENTER);
        y += 18;

        // Progress
        g.setColor(80, 80, 80);
        g.drawString("Test " + (currentTest + 1) + "/" + testNames.length, 5, y, Graphics.TOP | Graphics.LEFT);
        y += 15;

        if (testsRunning) {
            // Current test
            g.setColor(0, 0, 100);
            g.drawString(testNames[currentTest], 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;

            String res = results[currentTest];
            if ("PASS".equals(res)) {
                g.setColor(0, 130, 0);
            } else if ("FAIL".equals(res)) {
                g.setColor(180, 0, 0);
            } else {
                g.setColor(100, 100, 100);
            }
            g.drawString("Status: " + res, 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;

            // Log
            g.setColor(100, 100, 100);
            g.drawString("--- Log ---", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 12;

            for (int i = 0; i < log.length; i++) {
                int idx = (logIndex - log.length + i + log.length) % log.length;
                if (log[idx].length() > 0) {
                    g.setColor(60, 60, 60);
                    // Truncate long log lines
                    String logLine = log[idx];
                    if (logLine.length() > 35) {
                        logLine = logLine.substring(0, 32) + "...";
                    }
                    g.drawString(logLine, 5, y, Graphics.TOP | Graphics.LEFT);
                    y += 12;
                    if (y > getHeight() - 40) break;
                }
            }

            // Progress bar
            int barY = getHeight() - 25;
            int progressWidth = (width - 20) * (currentTest + 1) / testNames.length;
            g.setColor(0, 130, 0);
            g.fillRect(10, barY, progressWidth, 12);
            g.setColor(180, 180, 180);
            g.fillRect(10 + progressWidth, barY, (width - 20) - progressWidth, 12);

        } else {
            // Show all results - FAILED tests first, then SKIPPED, then PASSED
            // Build sorted index array: FAIL first, then SKIP, then PASS
            int[] sortedIdx = new int[testNames.length];
            int idx = 0;
            // First add all FAIL tests
            for (int i = 0; i < testNames.length; i++) {
                if (results[i].equals("FAIL")) {
                    sortedIdx[idx++] = i;
                }
            }
            // Then add all SKIP tests
            for (int i = 0; i < testNames.length; i++) {
                if (results[i].equals("SKIP")) {
                    sortedIdx[idx++] = i;
                }
            }
            // Then add all PASS tests
            for (int i = 0; i < testNames.length; i++) {
                if (results[i].equals("PASS")) {
                    sortedIdx[idx++] = i;
                }
            }
            // Then add any remaining (unknown status)
            for (int i = 0; i < testNames.length; i++) {
                if (!results[i].equals("PASS") && !results[i].equals("FAIL") && !results[i].equals("SKIP")) {
                    sortedIdx[idx++] = i;
                }
            }
            
            g.setColor(0, 0, 0);
            g.drawString("RESULTS:", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;

            for (int i = 0; i < sortedIdx.length && y < getHeight() - 35; i++) {
                int testIdx = sortedIdx[i];
                String result = results[testIdx];
                if (result.equals("PASS")) {
                    g.setColor(0, 130, 0);      // Green
                } else if (result.equals("SKIP")) {
                    g.setColor(200, 150, 0);    // Orange/Yellow
                } else {
                    g.setColor(180, 0, 0);      // Red for FAIL
                }
                String line = results[testIdx] + " " + testNames[testIdx];
                if (line.length() > 28) {
                    line = line.substring(0, 25) + "...";
                }
                g.drawString(line, 5, y, Graphics.TOP | Graphics.LEFT);
                y += 13;
            }

            // Summary
            g.setColor(0, 0, 128);
            String summary = passCount + "/" + testNames.length + " passed";
            if (skipCount > 0) summary += ", " + skipCount + " skipped";
            g.drawString(summary, 5, getHeight() - 30,
                        Graphics.TOP | Graphics.LEFT);

            if (failCount == 0 && skipCount == 0) {
                g.setColor(0, 150, 0);
                g.drawString("ALL PASSED!", width/2, getHeight() - 30,
                            Graphics.TOP | Graphics.HCENTER);
            } else {
                g.setColor(180, 0, 0);
                g.drawString(failCount + " FAILED", width/2, getHeight() - 30,
                            Graphics.TOP | Graphics.HCENTER);
            }

            g.setColor(100, 100, 100);
            g.drawString("Press key to exit", width/2, getHeight() - 12,
                        Graphics.BOTTOM | Graphics.HCENTER);
        }
    }

    protected void keyPressed(int keyCode) {
        if (!testsRunning) {
            midlet.notifyDestroyed();
        }
    }
}
