# J2ME Emulator

Кроссплатформенный эмулятор J2ME (Java 2 Micro Edition) с поддержкой MIDP2, написанный на чистом C.

## Особенности

- **Полная поддержка MIDP2**: Graphics, Display, Image, Font, GameCanvas, Sprite, TiledLayer
- **Все опкоды Java байт-кода**: ~200 инструкций JVM
- **Нативные методы на C**: java.lang.*, javax.microedition.*
- **SDL2 графика**: Аппаратное ускорение, кроссплатформенность
- **RMS (Record Management System)**: Персистентное хранение данных
- **Многопоточность**: Поддержка Java потоков с синхронизацией
- **Сборщик мусора**: Простой mark-and-sweep GC

## Сборка

### Требования

- C компилятор (GCC, Clang, MSVC)
- SDL2 development libraries
- CMake 3.10+ (опционально)

### Linux/macOS

```bash
# Установка SDL2
# Ubuntu/Debian:
sudo apt-get install libsdl2-dev

# macOS (Homebrew):
brew install sdl2

# Сборка с Make
cd j2me-emulator
make

# Или с CMake
mkdir build && cd build
cmake ..
make
```

### Windows

```bash
# Установите SDL2 development libraries для MinGW или Visual Studio
# Скачайте с https://www.libsdl.org/download-2.0.php

# CMake с MinGW:
mkdir build && cd build
cmake -G "MinGW Makefiles" ..
mingw32-make

# Или используйте Visual Studio:
cmake -G "Visual Studio 17 2022" ..
```

## Использование

```bash
# Базовый запуск
./j2me-emulator game.jar

# С указанием класса MIDlet
./j2me-emulator -m com.example.Game game.jar

# С кастомным разрешением
./j2me-emulator -w 320 -h 480 game.jar

# Полноэкранный режим
./j2me-emulator -f game.jar

# С масштабированием
./j2me-emulator -s 3 game.jar

# Полный список опций
./j2me-emulator --help
```

## Архитектура

```
j2me-emulator/
├── include/           # Заголовочные файлы
│   ├── jvm.h         # JVM core
│   ├── opcodes.h     # Опкоды байт-кода
│   ├── classfile.h   # Загрузчик классов
│   ├── heap.h        # Куча и GC
│   ├── threads.h     # Потоки
│   ├── native.h      # Нативные методы
│   ├── midp.h        # MIDP2 API
│   └── sdl_backend.h # SDL2 бэкенд
├── src/
│   ├── jvm/          # Реализация JVM
│   │   ├── jvm.c
│   │   ├── classfile.c
│   │   ├── opcodes.c
│   │   ├── heap.c
│   │   ├── threads.c
│   │   └── native.c
│   ├── midp/         # MIDP2 API
│   │   ├── graphics.c
│   │   ├── display.c
│   │   └── rms.c
│   ├── sdl/          # SDL2 бэкенд
│   │   └── sdl_graphics.c
│   ├── utils/        # Утилиты
│   │   └── utils.c
│   └── main.c        # Точка входа
├── Makefile          # GNU Make
├── CMakeLists.txt    # CMake
└── README.md
```

## Поддерживаемые API

### java.lang
- Object (getClass, hashCode, clone, notify, notifyAll, wait)
- Class (forName, getName, isInstance)
- String (hashCode, intern)
- System (arraycopy, currentTimeMillis, gc)
- Runtime (freeMemory, totalMemory, gc)
- Math (sqrt, sin, cos, tan, abs, max, min)
- Thread (currentThread, sleep, yield)
- Throwable (fillInStackTrace)

### javax.microedition.lcdui
- Display (getWidth, getHeight, isColor, numColors, vibrate)
- Graphics (setColor, drawLine, fillRect, drawRect, drawImage, setClip)
- Image (createImage, createRGBImage, getRGB, getWidth, getHeight)
- Font (getDefaultFont, stringWidth, getHeight)

### javax.microedition.lcdui.game
- GameCanvas (getKeyStates, suppressKeyEvents)
- Sprite (transform, collision detection)
- TiledLayer (tile-based rendering)
- LayerManager (layer management)

### javax.microedition.rms
- RecordStore (openRecordStore, closeRecordStore, addRecord, getRecord, setRecord, deleteRecord)

## Поддерживаемые опкоды

Все стандартные опкоды JVM (Java 1.3 compatible):

- **Constants**: nop, aconst_null, iconst_*, lconst_*, fconst_*, dconst_*, bipush, sipush, ldc, ldc_w, ldc2_w
- **Loads**: iload, lload, fload, dload, aload, iload_*, lload_*, fload_*, dload_*, aload_*, iaload, laload, faload, daload, aaload, baload, caload, saload
- **Stores**: istore, lstore, fstore, dstore, astore, istore_*, lstore_*, fstore_*, dstore_*, astore_*, iastore, lastore, fastore, dastore, aastore, bastore, castore, sastore
- **Stack**: pop, pop2, dup, dup_x1, dup_x2, dup2, dup2_x1, dup2_x2, swap
- **Math**: iadd, ladd, fadd, dadd, isub, lsub, fsub, dsub, imul, lmul, fmul, dmul, idiv, ldiv, fdiv, ddiv, irem, lrem, frem, drem, ineg, lneg, fneg, dneg
- **Bitwise**: ishl, lshl, ishr, lshr, iushr, lushr, iand, land, ior, lor, ixor, lxor, iinc
- **Conversion**: i2l, i2f, i2d, l2i, l2f, l2d, f2i, f2l, f2d, d2i, d2l, d2f, i2b, i2c, i2s
- **Comparison**: lcmp, fcmpl, fcmpg, dcmpl, dcmpg
- **Control**: ifeq, ifne, iflt, ifge, ifgt, ifle, if_icmpeq, if_icmpne, if_icmplt, if_icmpge, if_icmpgt, if_icmple, if_acmpeq, if_acmpne, goto, jsr, ret, tableswitch, lookupswitch
- **Return**: ireturn, lreturn, freturn, dreturn, areturn, return
- **Fields**: getstatic, putstatic, getfield, putfield
- **Invocation**: invokevirtual, invokespecial, invokestatic, invokeinterface
- **Objects**: new, newarray, anewarray, arraylength, athrow, checkcast, instanceof, monitorenter, monitorexit
- **Extended**: wide, multianewarray, ifnull, ifnonnull, goto_w, jsr_w

## Расширение

### Добавление нативных методов

```c
static JavaValue native_myMethod(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    // Реализация
    jint result = args[0].i * 2;
    return NATIVE_RETURN_INT(result);
}

void init_my_package(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"my/package/MyClass", "myMethod", "(I)I", native_myMethod},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}
```

### Добавление новых опкодов

Опкоды определены в `include/opcodes.h` и реализованы в `src/jvm/opcodes.c`.

## Лицензия

MIT License

## Благодарности

- JVM Specification (JVMS)
- MIDP2 Specification (JSR-118)
- SDL2 Library
