/*
 * J2ME Emulator - Native Methods
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup, clock_gettime - only on POSIX */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#endif

#include "native.h"
#include "jvm.h"
#include "heap.h"
#include "threads.h"
#include "opcodes.h"
#include "classfile.h"
#include "midp.h"  /* For load_jar_resource */

/* Forward declarations */
void init_java_util_random(JVM* jvm);
void init_java_util_timer(JVM* jvm);
void init_java_lang_stringbuffer(JVM* jvm);
void init_java_io_bytearrayinputstream(JVM* jvm);
void init_java_io_bytearrayoutputstream(JVM* jvm);
void init_java_io_dataoutputstream(JVM* jvm);
void init_java_io_datainputstream(JVM* jvm);
void init_nokia_sound(JVM* jvm);

/* Native method registry */
#define MAX_NATIVE_METHODS 1024

static struct {
    NativeMethodEntry entries[MAX_NATIVE_METHODS];
    int count;
} native_registry;

/* Initialize native methods */
int native_init(JVM* jvm) {
    native_registry.count = 0;
    
    /* Initialize standard Java native methods */
    init_java_lang_object(jvm);
    init_java_lang_class(jvm);
    init_java_lang_string(jvm);
    init_java_lang_system(jvm);
    init_java_lang_runtime(jvm);
    init_java_lang_math(jvm);
    init_java_lang_thread(jvm);
    init_java_lang_throwable(jvm);
    
    /* Initialize StringBuffer */
    init_java_lang_stringbuffer(jvm);
    
    /* Initialize java.util.Random */
    init_java_util_random(jvm);
    
    /* Initialize java.util.Timer */
    init_java_util_timer(jvm);
    
    /* Initialize ByteArrayInputStream */
    init_java_io_bytearrayinputstream(jvm);
    
    /* Initialize ByteArrayOutputStream */
    init_java_io_bytearrayoutputstream(jvm);
    
    /* Initialize DataOutputStream */
    init_java_io_dataoutputstream(jvm);
    
    /* Initialize DataInputStream */
    init_java_io_datainputstream(jvm);
    
    /* Initialize Nokia Sound */
    init_nokia_sound(jvm);
    
    return JNI_OK;
}

/* Register a native method */
int native_register(JVM* jvm, const char* class_name, const char* method_name,
                    const char* descriptor, NativeMethod handler) {
    (void)jvm;
    
    if (native_registry.count >= MAX_NATIVE_METHODS) {
        return JNI_ERR;
    }
    
    NativeMethodEntry* entry = &native_registry.entries[native_registry.count++];
    entry->class_name = class_name;
    entry->method_name = method_name;
    entry->descriptor = descriptor;
    entry->handler = handler;
    
    return JNI_OK;
}

/* Register multiple native methods */
int native_register_methods(JVM* jvm, const NativeMethodEntry* methods, int count) {
    for (int i = 0; i < count; i++) {
        if (native_register(jvm, methods[i].class_name, methods[i].method_name,
                           methods[i].descriptor, methods[i].handler) != JNI_OK) {
            return JNI_ERR;
        }
    }
    return JNI_OK;
}

/* Find native method */
NativeMethod native_find(JVM* jvm, const char* class_name, const char* method_name,
                         const char* descriptor) {
    (void)jvm;
    
    for (int i = 0; i < native_registry.count; i++) {
        NativeMethodEntry* entry = &native_registry.entries[i];
        if (strcmp(entry->class_name, class_name) == 0 &&
            strcmp(entry->method_name, method_name) == 0 &&
            strcmp(entry->descriptor, descriptor) == 0) {
            return entry->handler;
        }
    }
    
    return NULL;
}

/* Utility functions */
const char* native_get_string_utf8(JVM* jvm, JavaValue* args, int index) {
    JavaString* str = (JavaString*)args[index].ref;
    if (!str) return NULL;
    return string_utf8(jvm, str);
}

/* Exception helpers */
void native_throw_npe(JVM* jvm, JavaThread* thread) {
    jvm_throw_by_name(jvm, "java/lang/NullPointerException", NULL);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_aioobe(JVM* jvm, JavaThread* thread, jint index) {
    char msg[64];
    snprintf(msg, sizeof(msg), "Array index out of range: %d", index);
    jvm_throw_by_name(jvm, "java/lang/ArrayIndexOutOfBoundsException", msg);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_cnfe(JVM* jvm, JavaThread* thread, const char* name) {
    jvm_throw_by_name(jvm, "java/lang/ClassNotFoundException", name);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_oome(JVM* jvm, JavaThread* thread) {
    jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_iae(JVM* jvm, JavaThread* thread, const char* message) {
    jvm_throw_by_name(jvm, "java/lang/IllegalArgumentException", message);
    thread->pending_exception = jvm_exception_pending(jvm);
}

/*
 * java.lang.Object native methods
 */

static JavaValue native_object_getClass(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    return NATIVE_RETURN_OBJECT(obj ? obj->header.clazz : NULL);
}

static JavaValue native_object_hashCode(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    return NATIVE_RETURN_INT(obj ? obj->header.hashcode : 0);
}

static JavaValue native_object_clone(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* TODO: Implement clone */
    return NATIVE_RETURN_NULL();
}

static JavaValue native_object_notify(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    monitor_notify(jvm, obj);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_object_notifyAll(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    monitor_notify_all(jvm, obj);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_object_wait(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    jlong timeout = 0;
    bool timed = false;
    
    if (arg_count >= 2) {
        timeout = args[1].j;
        timed = true;
    }
    
    monitor_wait(jvm, obj, timeout, timed);
    return NATIVE_RETURN_VOID();
}

void init_java_lang_object(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Object", "getClass", "()Ljava/lang/Class;", native_object_getClass},
        {"java/lang/Object", "hashCode", "()I", native_object_hashCode},
        {"java/lang/Object", "clone", "()Ljava/lang/Object;", native_object_clone},
        {"java/lang/Object", "notify", "()V", native_object_notify},
        {"java/lang/Object", "notifyAll", "()V", native_object_notifyAll},
        {"java/lang/Object", "wait", "(J)V", native_object_wait},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Class native methods
 */

static JavaValue native_class_forName(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    const char* name = native_get_string_utf8(jvm, args, 1);
    if (!name) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Convert dots to slashes */
    char* internal_name = strdup(name);
    for (char* p = internal_name; *p; p++) {
        if (*p == '.') *p = '/';
    }
    
    JavaClass* clazz = jvm_load_class(jvm, internal_name);
    free(internal_name);
    
    if (!clazz) {
        native_throw_cnfe(jvm, thread, name);
        return NATIVE_RETURN_NULL();
    }
    
    return NATIVE_RETURN_OBJECT(clazz);
}

static JavaValue native_class_getName(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaClass* clazz = (JavaClass*)args[0].ref;
    if (!clazz || !clazz->class_name) return NATIVE_RETURN_NULL();
    
    char* name = class_name_to_java(clazz->class_name);
    JavaString* str = jvm_new_string(jvm, name);
    free(name);
    
    return NATIVE_RETURN_OBJECT(str);
}

static JavaValue native_class_isInstance(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaClass* clazz = (JavaClass*)args[0].ref;
    JavaObject* obj = (JavaObject*)args[1].ref;
    
    return NATIVE_RETURN_INT(object_instance_of(obj, clazz) ? 1 : 0);
}

/* Class.getResourceAsStream(String) - load resource from JAR */
static JavaValue native_class_getResourceAsStream(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    
    /* args[0] is the Class object (which is a JavaClass* in our implementation) */
    JavaClass* clazz = (JavaClass*)args[0].ref;
    JavaString* name_str = (JavaString*)args[1].ref;
    
    fprintf(stderr, "[Class] getResourceAsStream: clazz=%p, name_str=%p\n",
            (void*)clazz, (void*)name_str);
    fflush(stderr);
    
    if (!name_str) {
        fprintf(stderr, "[Class] getResourceAsStream: name_str is NULL\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Get the resource name */
    const char* name = string_utf8(jvm, name_str);
    if (!name) {
        fprintf(stderr, "[Class] getResourceAsStream: string_utf8 returned NULL\n");
        return NATIVE_RETURN_NULL();
    }
    
    fprintf(stderr, "[Class] getResourceAsStream: name='%s' (from class %s)\n", 
            name, (clazz && clazz->class_name) ? clazz->class_name : "?");
    fflush(stderr);
    
    /* Skip leading slash if present */
    const char* resource_name = name;
    if (resource_name[0] == '/') {
        resource_name++;
    }
    
    /* Load the resource from JAR */
    size_t data_size;
    uint8_t* data = load_jar_resource(resource_name, &data_size);
    
    if (!data) {
        fprintf(stderr, "[Class] Resource not found: %s\n", name);
        return NATIVE_RETURN_NULL();
    }
    
    fprintf(stderr, "[Class] Loaded %zu bytes from %s\n", data_size, name);
    
    /* Create a byte array to hold the data */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, (jsize)data_size);
    if (!byte_array) {
        free(data);
        return NATIVE_RETURN_NULL();
    }
    
    /* Copy data into byte array */
    memcpy(array_data(byte_array), data, data_size);
    free(data);
    
    /* Create ByteArrayInputStream object */
    JavaClass* bais_class = jvm_load_class(jvm, "java/io/ByteArrayInputStream");
    if (!bais_class) {
        fprintf(stderr, "[Class] Failed to load ByteArrayInputStream class\n");
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* bais_obj = jvm_new_object(jvm, bais_class);
    if (!bais_obj) {
        fprintf(stderr, "[Class] Failed to create ByteArrayInputStream object\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Set fields: buf = byte_array, pos = 0, count = data_size */
    /* Find field indices */
    int buf_idx = -1, pos_idx = -1, count_idx = -1;
    for (int i = 0; i < bais_class->fields_count; i++) {
        if (bais_class->fields[i].name) {
            if (strcmp(bais_class->fields[i].name, "buf") == 0) buf_idx = i;
            else if (strcmp(bais_class->fields[i].name, "pos") == 0) pos_idx = i;
            else if (strcmp(bais_class->fields[i].name, "count") == 0) count_idx = i;
        }
    }
    
    if (buf_idx >= 0) {
        bais_obj->fields[buf_idx].ref = byte_array;
    }
    if (pos_idx >= 0) {
        bais_obj->fields[pos_idx].i = 0;
    }
    if (count_idx >= 0) {
        bais_obj->fields[count_idx].i = (jint)data_size;
    }
    
    fprintf(stderr, "[Class] Created ByteArrayInputStream: buf=%p, pos=0, count=%zu\n",
            (void*)byte_array, data_size);
    
    return NATIVE_RETURN_OBJECT(bais_obj);
}

/* ByteArrayInputStream.read() - read single byte */
static JavaValue native_bytearrayinputstream_read(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    JavaClass* clazz = obj->header.clazz;
    if (!clazz || !clazz->fields) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Find field indices */
    int buf_idx = -1, pos_idx = -1, count_idx = -1;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name) {
            if (strcmp(clazz->fields[i].name, "buf") == 0) buf_idx = i;
            else if (strcmp(clazz->fields[i].name, "pos") == 0) pos_idx = i;
            else if (strcmp(clazz->fields[i].name, "count") == 0) count_idx = i;
        }
    }
    
    if (buf_idx < 0 || pos_idx < 0 || count_idx < 0) {
        return NATIVE_RETURN_INT(-1);
    }
    
    JavaArray* buf = (JavaArray*)obj->fields[buf_idx].ref;
    jint pos = obj->fields[pos_idx].i;
    jint count = obj->fields[count_idx].i;
    
    if (!buf || pos >= count) {
        return NATIVE_RETURN_INT(-1);  /* EOF */
    }
    
    /* Read byte from buffer */
    uint8_t* data = (uint8_t*)array_data(buf);
    jbyte val = (jbyte)data[pos];
    
    /* Update position */
    obj->fields[pos_idx].i = pos + 1;
    
    return NATIVE_RETURN_INT(val & 0xFF);  /* Return as unsigned */
}

/* ByteArrayInputStream.read(byte[], int, int) - read into buffer */
static JavaValue native_bytearrayinputstream_read_array(JVM* jvm, JavaThread* thread,
                                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* dest = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint len = args[3].i;
    
    if (!obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    JavaClass* clazz = obj->header.clazz;
    if (!clazz || !clazz->fields) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Find field indices */
    int buf_idx = -1, pos_idx = -1, count_idx = -1;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name) {
            if (strcmp(clazz->fields[i].name, "buf") == 0) buf_idx = i;
            else if (strcmp(clazz->fields[i].name, "pos") == 0) pos_idx = i;
            else if (strcmp(clazz->fields[i].name, "count") == 0) count_idx = i;
        }
    }
    
    if (buf_idx < 0 || pos_idx < 0 || count_idx < 0) {
        return NATIVE_RETURN_INT(-1);
    }
    
    JavaArray* buf = (JavaArray*)obj->fields[buf_idx].ref;
    jint pos = obj->fields[pos_idx].i;
    jint count = obj->fields[count_idx].i;
    
    if (!buf || !dest) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (pos >= count) {
        return NATIVE_RETURN_INT(-1);  /* EOF */
    }
    
    /* Calculate bytes to read */
    jint available = count - pos;
    jint to_read = (len < available) ? len : available;
    
    /* Check bounds */
    if (offset < 0 || len < 0 || offset + len > (jint)dest->length) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Copy data */
    uint8_t* src_data = (uint8_t*)array_data(buf);
    uint8_t* dest_data = (uint8_t*)array_data(dest);
    memcpy(dest_data + offset, src_data + pos, to_read);
    
    /* Update position */
    obj->fields[pos_idx].i = pos + to_read;
    
    return NATIVE_RETURN_INT(to_read);
}

/* ByteArrayInputStream.available() - bytes available to read */
static JavaValue native_bytearrayinputstream_available(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    JavaClass* clazz = obj->header.clazz;
    if (!clazz || !clazz->fields) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Find field indices */
    int pos_idx = -1, count_idx = -1;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name) {
            if (strcmp(clazz->fields[i].name, "pos") == 0) pos_idx = i;
            else if (strcmp(clazz->fields[i].name, "count") == 0) count_idx = i;
        }
    }
    
    if (pos_idx < 0 || count_idx < 0) {
        return NATIVE_RETURN_INT(0);
    }
    
    jint pos = obj->fields[pos_idx].i;
    jint count = obj->fields[count_idx].i;
    
    return NATIVE_RETURN_INT(count - pos);
}

void init_java_lang_class(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;", native_class_forName},
        {"java/lang/Class", "getName", "()Ljava/lang/String;", native_class_getName},
        {"java/lang/Class", "isInstance", "(Ljava/lang/Object;)Z", native_class_isInstance},
        {"java/lang/Class", "getResourceAsStream", "(Ljava/lang/String;)Ljava/io/InputStream;", native_class_getResourceAsStream},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/* ByteArrayInputStream native methods */
void init_java_io_bytearrayinputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/ByteArrayInputStream", "read", "()I", native_bytearrayinputstream_read},
        {"java/io/ByteArrayInputStream", "read", "([BII)I", native_bytearrayinputstream_read_array},
        {"java/io/ByteArrayInputStream", "available", "()I", native_bytearrayinputstream_available},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.io.ByteArrayOutputStream native methods
 */

/* ByteArrayOutputStream buffer is stored in a native peer pointer */

static JavaValue native_bytearrayoutputstream_init(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Allocate a dynamic buffer - start with 32 bytes */
    int capacity = 32;
    uint8_t* buffer = (uint8_t*)malloc(capacity);
    if (!buffer) return NATIVE_RETURN_VOID();
    
    memset(buffer, 0, capacity);
    
    /* Store buffer pointer and size info in obj's fields */
    /* We use the buf/count fields from the stub class */
    JavaClass* clazz = obj->header.clazz;
    
    /* Find buf field (byte[]) and count field (int) */
    /* For now, store the native buffer pointer in a hidden location */
    /* We'll use the nativePeer approach similar to Graphics */
    
    /* Ensure instance has space for native peer */
    /* Look for "buf" field */
    int buf_field_idx = -1;
    int count_field_idx = -1;
    
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name) {
                if (strcmp(clazz->fields[i].name, "buf") == 0) {
                    buf_field_idx = i;
                } else if (strcmp(clazz->fields[i].name, "count") == 0) {
                    count_field_idx = i;
                }
            }
        }
    }
    
    /* Store buffer info as a simple structure */
    /* We'll create a small Java byte array to hold our data */
    JavaArray* buf_array = jvm_new_array(jvm, T_BYTE, capacity);
    if (buf_array) {
        /* Store in object's first field if buf not found */
        if (buf_field_idx >= 0) {
            JavaValue buf_val = { .ref = buf_array };
            obj->fields[buf_field_idx] = buf_val;
        } else {
            /* Store in nativePeer-like field */
            JavaValue buf_val = { .ref = buf_array };
            obj->fields[0] = buf_val;
        }
    }
    
    fprintf(stderr, "[BAOS] <init>: obj=%p, buffer capacity=%d\n", (void*)obj, capacity);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_bytearrayoutputstream_tobytearray(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    JavaClass* clazz = obj->header.clazz;
    JavaArray* buf_array = NULL;
    jint count = 0;
    
    /* Find buf and count fields */
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name) {
                if (strcmp(clazz->fields[i].name, "buf") == 0) {
                    JavaValue val = obj->fields[i];
                    buf_array = (JavaArray*)val.ref;
                } else if (strcmp(clazz->fields[i].name, "count") == 0) {
                    JavaValue val = obj->fields[i];
                    count = val.i;
                }
            }
        }
    }
    
    /* If no fields found, try first field */
    if (!buf_array && clazz->fields_count > 0) {
        JavaValue val = obj->fields[0];
        buf_array = (JavaArray*)val.ref;
        count = buf_array ? buf_array->length : 0;
    }
    
    if (!buf_array || count <= 0) {
        /* Return empty array */
        JavaArray* empty = jvm_new_array(jvm, T_BYTE, 0);
        return NATIVE_RETURN_OBJECT(empty);
    }
    
    /* Create result array with actual size */
    JavaArray* result = jvm_new_array(jvm, T_BYTE, count);
    if (result && buf_array) {
        void* src_data = array_data(buf_array);
        void* dst_data = array_data(result);
        if (src_data && dst_data) {
            memcpy(dst_data, src_data, count);
        }
    }
    
    fprintf(stderr, "[BAOS] toByteArray: obj=%p, count=%d\n", (void*)obj, count);
    return NATIVE_RETURN_OBJECT(result);
}

static JavaValue native_bytearrayoutputstream_write(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint b = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = obj->header.clazz;
    JavaArray* buf_array = NULL;
    jint count = 0;
    int buf_field_idx = -1;
    int count_field_idx = -1;
    
    /* Find buf and count fields */
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name) {
                if (strcmp(clazz->fields[i].name, "buf") == 0) {
                    buf_field_idx = i;
                    JavaValue val = obj->fields[i];
                    buf_array = (JavaArray*)val.ref;
                } else if (strcmp(clazz->fields[i].name, "count") == 0) {
                    count_field_idx = i;
                    JavaValue val = obj->fields[i];
                    count = val.i;
                }
            }
        }
    }
    
    /* If no buf field, use first field */
    if (!buf_array && clazz->fields_count > 0) {
        buf_field_idx = 0;
        JavaValue val = obj->fields[0];
        buf_array = (JavaArray*)val.ref;
    }
    
    /* Need to expand buffer? */
    if (!buf_array || count >= (jint)buf_array->length) {
        int new_capacity = buf_array ? buf_array->length * 2 : 32;
        if (new_capacity < count + 1) new_capacity = count + 32;
        
        JavaArray* new_array = jvm_new_array(jvm, T_BYTE, new_capacity);
        if (new_array) {
            void* src = array_data(buf_array);
            void* dst = array_data(new_array);
            if (buf_array && src && dst && count > 0) {
                memcpy(dst, src, count);
            }
            buf_array = new_array;
            if (buf_field_idx >= 0) {
                JavaValue buf_val = { .ref = buf_array };
                obj->fields[buf_field_idx] = buf_val;
            }
        }
    }
    
    /* Write byte */
    if (buf_array) {
        uint8_t* data = (uint8_t*)array_data(buf_array);
        if (data) {
            data[count] = (uint8_t)b;
            count++;
        
            /* Update count field */
            if (count_field_idx >= 0) {
                JavaValue count_val = { .i = count };
                obj->fields[count_field_idx] = count_val;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_bytearrayoutputstream_write_array(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint off = args[2].i;
    jint len = args[3].i;
    
    if (!obj || !data) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = obj->header.clazz;
    JavaArray* buf_array = NULL;
    jint count = 0;
    int buf_field_idx = -1;
    int count_field_idx = -1;
    
    /* Find buf and count fields */
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name) {
                if (strcmp(clazz->fields[i].name, "buf") == 0) {
                    buf_field_idx = i;
                    JavaValue val = obj->fields[i];
                    buf_array = (JavaArray*)val.ref;
                } else if (strcmp(clazz->fields[i].name, "count") == 0) {
                    count_field_idx = i;
                    JavaValue val = obj->fields[i];
                    count = val.i;
                }
            }
        }
    }
    
    if (!buf_array && clazz->fields_count > 0) {
        buf_field_idx = 0;
        JavaValue val = obj->fields[0];
        buf_array = (JavaArray*)val.ref;
    }
    
    /* Need to expand buffer? */
    int needed = count + len;
    if (!buf_array || needed > (jint)buf_array->length) {
        int new_capacity = buf_array ? buf_array->length * 2 : 32;
        while (new_capacity < needed) new_capacity *= 2;
        
        JavaArray* new_array = jvm_new_array(jvm, T_BYTE, new_capacity);
        if (new_array) {
            void* src = array_data(buf_array);
            void* dst = array_data(new_array);
            if (buf_array && src && dst && count > 0) {
                memcpy(dst, src, count);
            }
            buf_array = new_array;
            if (buf_field_idx >= 0) {
                JavaValue buf_val = { .ref = buf_array };
                obj->fields[buf_field_idx] = buf_val;
            }
        }
    }
    
    /* Write bytes */
    if (buf_array && data) {
        uint8_t* dst = (uint8_t*)array_data(buf_array);
        uint8_t* src = (uint8_t*)array_data(data);
        if (dst && src) {
            memcpy(dst + count, src + off, len);
            count += len;
        
            if (count_field_idx >= 0) {
                JavaValue count_val = { .i = count };
                obj->fields[count_field_idx] = count_val;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

void init_java_io_bytearrayoutputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/ByteArrayOutputStream", "<init>", "()V", native_bytearrayoutputstream_init},
        {"java/io/ByteArrayOutputStream", "toByteArray", "()[B", native_bytearrayoutputstream_tobytearray},
        {"java/io/ByteArrayOutputStream", "write", "(I)V", native_bytearrayoutputstream_write},
        {"java/io/ByteArrayOutputStream", "write", "([BII)V", native_bytearrayoutputstream_write_array},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.io.DataOutputStream native methods
 * DataOutputStream wraps an OutputStream and writes data to it
 */

/* Forward declaration */
static void dos_write_byte(JVM* jvm, JavaObject* dos_obj, uint8_t b);
static void dos_write_bytes(JVM* jvm, JavaObject* dos_obj, uint8_t* data, int len);

static JavaValue native_dataoutputstream_init(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* out = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store the wrapped OutputStream in the "out" field */
    JavaClass* clazz = obj->header.clazz;
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "out") == 0) {
                JavaValue out_val = { .ref = out };
                obj->fields[i] = out_val;
                break;
            }
        }
    }
    
    fprintf(stderr, "[DOS] <init>: obj=%p, out=%p\n", (void*)obj, (void*)out);
    return NATIVE_RETURN_VOID();
}

/* Write a single byte to the underlying output stream */
static void dos_write_byte(JVM* jvm, JavaObject* dos_obj, uint8_t b) {
    if (!dos_obj) return;
    
    JavaClass* clazz = dos_obj->header.clazz;
    JavaObject* out = NULL;
    
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "out") == 0) {
                JavaValue val = dos_obj->fields[i];
                out = (JavaObject*)val.ref;
                break;
            }
        }
    }
    
    if (!out) return;
    
    /* Call out.write(b) */
    JavaClass* out_class = out->header.clazz;
    JavaMethod* write_method = jvm_resolve_method(jvm, out_class, "write", "(I)V");
    
    if (write_method) {
        /* This would require calling back into the interpreter, for now we just 
         * directly manipulate ByteArrayOutputStream's buffer if that's what it is */
    }
    
    /* Check if out is a ByteArrayOutputStream */
    if (out_class && out_class->class_name && 
        strcmp(out_class->class_name, "java/io/ByteArrayOutputStream") == 0) {
        /* Directly write to BAOS buffer */
        JavaArray* buf_array = NULL;
        jint count = 0;
        int buf_field_idx = -1;
        int count_field_idx = -1;
        
        if (out_class->fields) {
            for (int i = 0; i < out_class->fields_count; i++) {
                if (out_class->fields[i].name) {
                    if (strcmp(out_class->fields[i].name, "buf") == 0) {
                        buf_field_idx = i;
                        JavaValue val = out->fields[i];
                        buf_array = (JavaArray*)val.ref;
                    } else if (strcmp(out_class->fields[i].name, "count") == 0) {
                        count_field_idx = i;
                        JavaValue val = out->fields[i];
                        count = val.i;
                    }
                }
            }
        }
        
        if (!buf_array && out_class->fields_count > 0) {
            buf_field_idx = 0;
            JavaValue val = out->fields[0];
            buf_array = (JavaArray*)val.ref;
        }
        
        /* Expand buffer if needed */
        if (!buf_array || count >= (jint)buf_array->length) {
            int new_capacity = buf_array ? buf_array->length * 2 : 32;
            JavaArray* new_array = jvm_new_array(jvm, T_BYTE, new_capacity);
            if (new_array) {
                void* src = array_data(buf_array);
                void* dst = array_data(new_array);
                if (buf_array && src && dst && count > 0) {
                    memcpy(dst, src, count);
                }
                buf_array = new_array;
                if (buf_field_idx >= 0) {
                    JavaValue buf_val = { .ref = buf_array };
                    out->fields[buf_field_idx] = buf_val;
                }
            }
        }
        
        /* Write byte */
        if (buf_array) {
            uint8_t* data = (uint8_t*)array_data(buf_array);
            if (data) {
                data[count] = b;
                count++;
                if (count_field_idx >= 0) {
                    JavaValue count_val = { .i = count };
                    out->fields[count_field_idx] = count_val;
                }
            }
        }
    }
}

static void dos_write_bytes(JVM* jvm, JavaObject* dos_obj, uint8_t* data, int len) {
    for (int i = 0; i < len; i++) {
        dos_write_byte(jvm, dos_obj, data[i]);
    }
}

static JavaValue native_dataoutputstream_write(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint b = args[1].i;
    
    dos_write_byte(jvm, obj, (uint8_t)b);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writeint(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint v = args[1].i;
    
    uint8_t bytes[4];
    bytes[0] = (v >> 24) & 0xFF;
    bytes[1] = (v >> 16) & 0xFF;
    bytes[2] = (v >> 8) & 0xFF;
    bytes[3] = v & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 4);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writelong(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong v = args[1].j;
    
    uint8_t bytes[8];
    bytes[0] = (v >> 56) & 0xFF;
    bytes[1] = (v >> 48) & 0xFF;
    bytes[2] = (v >> 40) & 0xFF;
    bytes[3] = (v >> 32) & 0xFF;
    bytes[4] = (v >> 24) & 0xFF;
    bytes[5] = (v >> 16) & 0xFF;
    bytes[6] = (v >> 8) & 0xFF;
    bytes[7] = v & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 8);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writebyte(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint v = args[1].i;
    
    dos_write_byte(jvm, obj, (uint8_t)v);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writeshort(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint v = args[1].i;
    
    uint8_t bytes[2];
    bytes[0] = (v >> 8) & 0xFF;
    bytes[1] = v & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 2);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writefloat(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jfloat v = args[1].f;
    
    /* Convert float to int bits, then write as 4 bytes */
    jint bits = *(jint*)&v;
    
    uint8_t bytes[4];
    bytes[0] = (bits >> 24) & 0xFF;
    bytes[1] = (bits >> 16) & 0xFF;
    bytes[2] = (bits >> 8) & 0xFF;
    bytes[3] = bits & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 4);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writedouble(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jdouble v = args[1].d;
    
    /* Convert double to long bits, then write as 8 bytes */
    jlong bits = *(jlong*)&v;
    
    uint8_t bytes[8];
    bytes[0] = (bits >> 56) & 0xFF;
    bytes[1] = (bits >> 48) & 0xFF;
    bytes[2] = (bits >> 40) & 0xFF;
    bytes[3] = (bits >> 32) & 0xFF;
    bytes[4] = (bits >> 24) & 0xFF;
    bytes[5] = (bits >> 16) & 0xFF;
    bytes[6] = (bits >> 8) & 0xFF;
    bytes[7] = bits & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 8);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writebytes(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaString* str = (JavaString*)args[1].ref;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    /* Write string as bytes (high byte discarded) */
    const jchar* chars = string_chars(str);
    if (chars) {
        for (int i = 0; i < str->length; i++) {
            uint16_t ch = chars[i];
            dos_write_byte(jvm, obj, ch & 0xFF);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_flush(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op for now */
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_close(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op for now */
    return NATIVE_RETURN_VOID();
}

void init_java_io_dataoutputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/DataOutputStream", "<init>", "(Ljava/io/OutputStream;)V", native_dataoutputstream_init},
        {"java/io/DataOutputStream", "write", "(I)V", native_dataoutputstream_write},
        {"java/io/DataOutputStream", "writeInt", "(I)V", native_dataoutputstream_writeint},
        {"java/io/DataOutputStream", "writeLong", "(J)V", native_dataoutputstream_writelong},
        {"java/io/DataOutputStream", "writeByte", "(I)V", native_dataoutputstream_writebyte},
        {"java/io/DataOutputStream", "writeShort", "(I)V", native_dataoutputstream_writeshort},
        {"java/io/DataOutputStream", "writeFloat", "(F)V", native_dataoutputstream_writefloat},
        {"java/io/DataOutputStream", "writeDouble", "(D)V", native_dataoutputstream_writedouble},
        {"java/io/DataOutputStream", "writeBytes", "(Ljava/lang/String;)V", native_dataoutputstream_writebytes},
        {"java/io/DataOutputStream", "flush", "()V", native_dataoutputstream_flush},
        {"java/io/DataOutputStream", "close", "()V", native_dataoutputstream_close},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * DataInputStream native methods
 */

static JavaValue native_datainputstream_read_byte_array(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    
    if (!obj || !buffer) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Get the underlying InputStream - look for "in" field */
    JavaClass* clazz = obj->header.clazz;
    JavaObject* in_stream = NULL;
    
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "in") == 0) {
                in_stream = (JavaObject*)obj->fields[i].ref;
                break;
            }
        }
    }
    
    if (!in_stream) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Check if it's a ByteArrayInputStream */
    JavaClass* in_class = in_stream->header.clazz;
    if (in_class && in_class->class_name && 
        strcmp(in_class->class_name, "java/io/ByteArrayInputStream") == 0) {
        
        /* Get buf, pos, count fields */
        JavaArray* buf = NULL;
        jint pos = 0, count = 0;
        
        if (in_class->fields) {
            for (int i = 0; i < in_class->fields_count; i++) {
                if (in_class->fields[i].name) {
                    if (strcmp(in_class->fields[i].name, "buf") == 0) {
                        buf = (JavaArray*)in_stream->fields[i].ref;
                    } else if (strcmp(in_class->fields[i].name, "pos") == 0) {
                        pos = in_stream->fields[i].i;
                    } else if (strcmp(in_class->fields[i].name, "count") == 0) {
                        count = in_stream->fields[i].i;
                    }
                }
            }
        }
        
        if (!buf || pos >= count) {
            return NATIVE_RETURN_INT(-1);
        }
        
        /* Read available bytes into buffer */
        int available = count - pos;
        int to_read = buffer->length < available ? buffer->length : available;
        
        uint8_t* src = (uint8_t*)array_data(buf);
        uint8_t* dst = (uint8_t*)array_data(buffer);
        
        if (src && dst) {
            memcpy(dst, src + pos, to_read);
            
            /* Update pos field */
            for (int i = 0; i < in_class->fields_count; i++) {
                if (in_class->fields[i].name && strcmp(in_class->fields[i].name, "pos") == 0) {
                    in_stream->fields[i].i = pos + to_read;
                    break;
                }
            }
        }
        
        return NATIVE_RETURN_INT(to_read);
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* Helper to find field index by name in class hierarchy */
static int find_field_index(JavaClass* clazz, const char* name) {
    if (!clazz || !name) return -1;
    
    /* Check this class */
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, name) == 0) {
                return i;
            }
        }
    }
    
    /* Check superclass */
    if (clazz->super_class) {
        return find_field_index(clazz->super_class, name);
    }
    
    return -1;
}

/* DataInputStream.<init>(InputStream) - constructor */
static JavaValue native_datainputstream_init(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* in_stream = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store the wrapped InputStream in the "in" field */
    JavaClass* clazz = obj->header.clazz;
    int in_field_idx = find_field_index(clazz, "in");
    
    if (in_field_idx >= 0) {
        obj->fields[in_field_idx].ref = in_stream;
        fprintf(stderr, "[DataInputStream] <init>: obj=%p, in=%p (field_idx=%d)\n", 
                (void*)obj, (void*)in_stream, in_field_idx);
    } else {
        /* If no 'in' field found, try first field */
        if (clazz->fields_count > 0) {
            obj->fields[0].ref = in_stream;
            fprintf(stderr, "[DataInputStream] <init>: obj=%p, in=%p (using field 0)\n", 
                    (void*)obj, (void*)in_stream);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Helper to read a single byte from underlying InputStream with proper position tracking */
static jint dis_read_byte(JVM* jvm, JavaObject* dis_obj) {
    if (!dis_obj) {
        fprintf(stderr, "[DIS] dis_read_byte: dis_obj is NULL\n");
        return -1;
    }
    
    /* Get the underlying InputStream - look for "in" field */
    JavaClass* clazz = dis_obj->header.clazz;
    JavaObject* in_stream = NULL;
    
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "in") == 0) {
                in_stream = (JavaObject*)dis_obj->fields[i].ref;
                break;
            }
        }
    }
    
    if (!in_stream) {
        /* Try superclass (FilterInputStream) */
        if (clazz->super_class && clazz->super_class->fields) {
            for (int i = 0; i < clazz->super_class->fields_count; i++) {
                if (clazz->super_class->fields[i].name && 
                    strcmp(clazz->super_class->fields[i].name, "in") == 0) {
                    in_stream = (JavaObject*)dis_obj->fields[i].ref;
                    break;
                }
            }
        }
    }
    
    if (!in_stream) {
        return -1;
    }
    
    /* Check if it's a ByteArrayInputStream */
    JavaClass* in_class = in_stream->header.clazz;
    if (in_class && in_class->class_name && 
        strcmp(in_class->class_name, "java/io/ByteArrayInputStream") == 0) {
        
        /* Find field indices once and cache them */
        static struct {
            int buf_idx;
            int pos_idx;
            int count_idx;
            int initialized;
        } field_cache = { -1, -1, -1, 0 };
        
        if (!field_cache.initialized && in_class->fields) {
            for (int i = 0; i < in_class->fields_count; i++) {
                if (in_class->fields[i].name) {
                    if (strcmp(in_class->fields[i].name, "buf") == 0)
                        field_cache.buf_idx = i;
                    else if (strcmp(in_class->fields[i].name, "pos") == 0)
                        field_cache.pos_idx = i;
                    else if (strcmp(in_class->fields[i].name, "count") == 0)
                        field_cache.count_idx = i;
                }
            }
            field_cache.initialized = 1;
        }
        
        if (field_cache.buf_idx < 0 || field_cache.pos_idx < 0 || field_cache.count_idx < 0) {
            return -1;
        }
        
        JavaArray* buf = (JavaArray*)in_stream->fields[field_cache.buf_idx].ref;
        jint pos = in_stream->fields[field_cache.pos_idx].i;
        jint count = in_stream->fields[field_cache.count_idx].i;
        
        if (!buf) {
            return -1;
        }
        
        if (pos >= count) {
            return -1;  /* EOF */
        }
        
        /* Read single byte and ADVANCE position */
        uint8_t* data = (uint8_t*)array_data(buf);
        jbyte val = (jbyte)data[pos];
        
        /* CRITICAL: Update position in the underlying stream */
        in_stream->fields[field_cache.pos_idx].i = pos + 1;
        
        return val & 0xFF;
    }
    
    return -1;
}

/* DataInputStream.readByte() - reads a single byte */
static JavaValue native_datainputstream_readbyte(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jint val = dis_read_byte(jvm, obj);
    if (val < 0) {
        /* Throw EOFException instead of returning 0 */
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT((jbyte)val);
}

/* DataInputStream.readUnsignedByte() - reads an unsigned byte */
static JavaValue native_datainputstream_readunsignedbyte(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jint val = dis_read_byte(jvm, obj);
    if (val < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT(val);
}

/* DataInputStream.readShort() - reads 2 bytes as short */
static JavaValue native_datainputstream_readshort(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    jint b1 = dis_read_byte(jvm, obj);
    jint b2 = dis_read_byte(jvm, obj);
    
    if (b1 < 0 || b2 < 0) {
        fprintf(stderr, "[DataInputStream] readShort: EOF reached\n");
        return NATIVE_RETURN_INT(0);
    }
    
    jshort val = (jshort)((b1 << 8) | b2);
    return NATIVE_RETURN_INT(val);
}

/* DataInputStream.readInt() - reads 4 bytes as int */
static JavaValue native_datainputstream_readint(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    /* Read 4 bytes sequentially, each call advances position */
    jint b1 = dis_read_byte(jvm, obj);
    if (b1 < 0) {
        /* Throw EOFException */
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jint b2 = dis_read_byte(jvm, obj);
    if (b2 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jint b3 = dis_read_byte(jvm, obj);
    if (b3 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jint b4 = dis_read_byte(jvm, obj);
    if (b4 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jint val = (b1 << 24) | (b2 << 16) | (b3 << 8) | b4;
    return NATIVE_RETURN_INT(val);
}

/* DataInputStream.readLong() - reads 8 bytes as long */
static JavaValue native_datainputstream_readlong(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    jlong val = 0;
    for (int i = 0; i < 8; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            fprintf(stderr, "[DataInputStream] readLong: EOF reached at byte %d\n", i);
            return NATIVE_RETURN_LONG(0);
        }
        val = (val << 8) | b;
    }
    
    return NATIVE_RETURN_LONG(val);
}

/* DataInputStream.readFully([B)V - reads bytes to fill array */
static JavaValue native_datainputstream_readfully(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    
    if (!obj || !buffer) {
        return NATIVE_RETURN_VOID();
    }
    
    uint8_t* data = (uint8_t*)array_data(buffer);
    if (!data) {
        return NATIVE_RETURN_VOID();
    }
    
    for (int i = 0; i < (int)buffer->length; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            fprintf(stderr, "[DataInputStream] readFully: EOF reached at %d\n", i);
            break;
        }
        data[i] = (uint8_t)b;
    }
    
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.readFully([BII)V - with bounds checking */
static JavaValue native_datainputstream_readfully_offset(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint len = args[3].i;
    
    if (!obj || !buffer) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Bounds checking */
    if (offset < 0 || len < 0 || offset + len > (jint)buffer->length) {
        native_throw_aioobe(jvm, thread, offset);
        return NATIVE_RETURN_VOID();
    }
    
    uint8_t* data = (uint8_t*)array_data(buffer);
    if (!data) {
        return NATIVE_RETURN_VOID();
    }
    
    for (int i = 0; i < len; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            /* Throw EOFException if we couldn't read all bytes */
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_VOID();
        }
        data[offset + i] = (uint8_t)b;
    }
    
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.skipBytes(int) - skips n bytes */
static JavaValue native_datainputstream_skipbytes(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint n = args[1].i;
    
    if (!obj || n <= 0) {
        return NATIVE_RETURN_INT(0);
    }
    
    int skipped = 0;
    for (int i = 0; i < n; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) break;
        skipped++;
    }
    
    return NATIVE_RETURN_INT(skipped);
}

void init_java_io_datainputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/DataInputStream", "<init>", "(Ljava/io/InputStream;)V", native_datainputstream_init},
        {"java/io/DataInputStream", "read", "([B)I", native_datainputstream_read_byte_array},
        {"java/io/DataInputStream", "readByte", "()B", native_datainputstream_readbyte},
        {"java/io/DataInputStream", "readUnsignedByte", "()I", native_datainputstream_readunsignedbyte},
        {"java/io/DataInputStream", "readShort", "()S", native_datainputstream_readshort},
        {"java/io/DataInputStream", "readInt", "()I", native_datainputstream_readint},
        {"java/io/DataInputStream", "readLong", "()J", native_datainputstream_readlong},
        {"java/io/DataInputStream", "readFully", "([B)V", native_datainputstream_readfully},
        {"java/io/DataInputStream", "readFully", "([BII)V", native_datainputstream_readfully_offset},
        {"java/io/DataInputStream", "skipBytes", "(I)I", native_datainputstream_skipbytes},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    fprintf(stderr, "[NATIVE] Registered java/io/DataInputStream native methods\n");
}

/*
 * com.nokia.mid.sound.Sound native methods
 * Nokia's sound API for playing audio
 */

/* Sound stores audio data and native handle */
static JavaValue native_sound_init(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint type = args[2].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store the audio data reference in a field */
    JavaClass* clazz = obj->header.clazz;
    if (clazz->fields_count > 0) {
        /* Store data in first field if available */
        obj->fields[0].ref = data;
        if (clazz->fields_count > 1) {
            obj->fields[1].i = type;
        }
    }
    
    fprintf(stderr, "[Sound] <init>: obj=%p, data=%p, type=%d\n", (void*)obj, (void*)data, type);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_play(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Get audio data from field */
    JavaClass* clazz = obj->header.clazz;
    JavaArray* data = NULL;
    
    if (clazz->fields_count > 0) {
        data = (JavaArray*)obj->fields[0].ref;
    }
    
    if (data && data->length > 0) {
        /* For now, just log - actual audio playback would require audio library */
        fprintf(stderr, "[Sound] play: %d bytes of audio data\n", data->length);
        
        /* TODO: Implement actual audio playback using SDL audio or similar */
        /* The data is likely AMR format which needs decoding */
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_stop(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Sound] stop: obj=%p\n", (void*)obj);
    /* TODO: Stop audio playback */
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_getstate(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* Return SOUND_PLAYING = 1, SOUND_STOPPED = 0 */
    return NATIVE_RETURN_INT(0);  /* Always return stopped for now */
}

static JavaValue native_sound_setgain(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint gain = args[1].i;
    
    fprintf(stderr, "[Sound] setGain: obj=%p, gain=%d\n", (void*)obj, gain);
    /* TODO: Set volume */
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_release(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Sound] release: obj=%p\n", (void*)obj);
    /* TODO: Release audio resources */
    
    return NATIVE_RETURN_VOID();
}

void init_nokia_sound(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"com/nokia/mid/sound/Sound", "<init>", "([BI)V", native_sound_init},
        {"com/nokia/mid/sound/Sound", "play", "(I)V", native_sound_play},
        {"com/nokia/mid/sound/Sound", "stop", "()V", native_sound_stop},
        {"com/nokia/mid/sound/Sound", "getState", "()I", native_sound_getstate},
        {"com/nokia/mid/sound/Sound", "setGain", "(I)V", native_sound_setgain},
        {"com/nokia/mid/sound/Sound", "release", "()V", native_sound_release},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.String native methods
 */

static JavaValue native_string_hashCode(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    return NATIVE_RETURN_INT(str ? string_hash(str) : 0);
}

static JavaValue native_string_intern(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) return NATIVE_RETURN_NULL();
    
    /* TODO: Implement string interning */
    return NATIVE_RETURN_OBJECT(str);
}

/* String.length() - returns the length of the string */
static JavaValue native_string_length(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT(str->length);
}

/* String.charAt(int) - returns character at index */
static JavaValue native_string_charAt(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jint index = args[1].i;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    if (index < 0 || index >= str->length) {
        native_throw_aioobe(jvm, thread, index);
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* chars = string_chars(str);
    return NATIVE_RETURN_INT((jint)chars[index]);
}

/* String.isEmpty() - returns true if length is 0 */
static JavaValue native_string_isEmpty(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    return NATIVE_RETURN_INT(str ? (str->length == 0 ? 1 : 0) : 1);
}

/* String.startsWith(String) - check if string starts with prefix */
static JavaValue native_string_startsWith(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* prefix = (JavaString*)args[1].ref;
    
    if (!str || !prefix) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (prefix->length > str->length) {
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* prefix_chars = string_chars(prefix);
    
    for (jsize i = 0; i < prefix->length; i++) {
        if (str_chars[i] != prefix_chars[i]) {
            return NATIVE_RETURN_INT(0);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* String.endsWith(String) - check if string ends with suffix */
static JavaValue native_string_endsWith(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* suffix = (JavaString*)args[1].ref;
    
    if (!str || !suffix) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (suffix->length > str->length) {
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* suffix_chars = string_chars(suffix);
    
    jsize start = str->length - suffix->length;
    for (jsize i = 0; i < suffix->length; i++) {
        if (str_chars[start + i] != suffix_chars[i]) {
            return NATIVE_RETURN_INT(0);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* String.indexOf(int) - find first occurrence of character */
static JavaValue native_string_indexOf(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jchar ch = (jchar)args[1].i;
    
    if (!str) {
        return NATIVE_RETURN_INT(-1);
    }
    
    const jchar* chars = string_chars(str);
    
    for (jsize i = 0; i < str->length; i++) {
        if (chars[i] == ch) {
            return NATIVE_RETURN_INT((jint)i);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* String.substring(int) - extract substring from start index */
static JavaValue native_string_substring(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jint start = args[1].i;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    if (start < 0 || start > str->length) {
        native_throw_aioobe(jvm, thread, start);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    jsize len = str->length - start;
    JavaString* result = jvm_new_string_utf16(jvm, chars + start, len);
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.equals(Object) - compare strings */
static JavaValue native_string_equals(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* other = (JavaString*)args[1].ref;
    
    if (str == other) {
        return NATIVE_RETURN_INT(1);
    }
    
    if (!str || !other) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (str->length != other->length) {
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* other_chars = string_chars(other);
    
    for (jsize i = 0; i < str->length; i++) {
        if (str_chars[i] != other_chars[i]) {
            return NATIVE_RETURN_INT(0);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* String.valueOf(C) - convert char to String */
static JavaValue native_string_valueOf_char(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jchar c = (jchar)args[0].i;
    
    /* Create a new String with one character */
    char utf8[8];
    int len = 0;
    
    /* Convert jchar (UTF-16) to UTF-8 */
    if (c < 0x80) {
        utf8[len++] = (char)c;
    } else if (c < 0x800) {
        utf8[len++] = (char)(0xC0 | (c >> 6));
        utf8[len++] = (char)(0x80 | (c & 0x3F));
    } else {
        utf8[len++] = (char)(0xE0 | (c >> 12));
        utf8[len++] = (char)(0x80 | ((c >> 6) & 0x3F));
        utf8[len++] = (char)(0x80 | (c & 0x3F));
    }
    utf8[len] = '\0';
    
    JavaString* str = jvm_new_string(jvm, utf8);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(I) - convert int to String */
static JavaValue native_string_valueOf_int(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    char buffer[16];
    snprintf(buffer, sizeof(buffer), "%d", value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(J) - convert long to String */
static JavaValue native_string_valueOf_long(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jlong value = args[0].j;
    
    char buffer[24];
    snprintf(buffer, sizeof(buffer), "%lld", (long long)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(Z) - convert boolean to String */
static JavaValue native_string_valueOf_boolean(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jboolean value = args[0].i;
    
    JavaString* str = jvm_new_string(jvm, value ? "true" : "false");
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(F) - convert float to String */
static JavaValue native_string_valueOf_float(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jfloat value = args[0].f;
    
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%g", (double)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(D) - convert double to String */
static JavaValue native_string_valueOf_double(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%g", value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(Object) - convert object to String */
static JavaValue native_string_valueOf_object(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = args[0].ref;
    
    if (!obj) {
        JavaString* str = jvm_new_string(jvm, "null");
        return NATIVE_RETURN_OBJECT(str);
    }
    
    /* TODO: Call obj.toString() */
    JavaString* str = jvm_new_string(jvm, "Object");
    return NATIVE_RETURN_OBJECT(str);
}

void init_java_lang_string(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/String", "length", "()I", native_string_length},
        {"java/lang/String", "charAt", "(I)C", native_string_charAt},
        {"java/lang/String", "isEmpty", "()Z", native_string_isEmpty},
        {"java/lang/String", "startsWith", "(Ljava/lang/String;)Z", native_string_startsWith},
        {"java/lang/String", "endsWith", "(Ljava/lang/String;)Z", native_string_endsWith},
        {"java/lang/String", "indexOf", "(I)I", native_string_indexOf},
        {"java/lang/String", "substring", "(I)Ljava/lang/String;", native_string_substring},
        {"java/lang/String", "equals", "(Ljava/lang/Object;)Z", native_string_equals},
        {"java/lang/String", "hashCode", "()I", native_string_hashCode},
        {"java/lang/String", "intern", "()Ljava/lang/String;", native_string_intern},
        /* String.valueOf static methods */
        {"java/lang/String", "valueOf", "(C)Ljava/lang/String;", native_string_valueOf_char},
        {"java/lang/String", "valueOf", "(I)Ljava/lang/String;", native_string_valueOf_int},
        {"java/lang/String", "valueOf", "(J)Ljava/lang/String;", native_string_valueOf_long},
        {"java/lang/String", "valueOf", "(Z)Ljava/lang/String;", native_string_valueOf_boolean},
        {"java/lang/String", "valueOf", "(F)Ljava/lang/String;", native_string_valueOf_float},
        {"java/lang/String", "valueOf", "(D)Ljava/lang/String;", native_string_valueOf_double},
        {"java/lang/String", "valueOf", "(Ljava/lang/Object;)Ljava/lang/String;", native_string_valueOf_object},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.System native methods
 */

static JavaValue native_system_arraycopy(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaArray* src = (JavaArray*)args[1].ref;
    jint src_pos = args[2].i;
    JavaArray* dest = (JavaArray*)args[3].ref;
    jint dest_pos = args[4].i;
    jint length = args[5].i;
    
    if (!src || !dest) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    if (src_pos < 0 || dest_pos < 0 || length < 0 ||
        src_pos + length > src->length ||
        dest_pos + length > dest->length) {
        native_throw_aioobe(jvm, thread, -1);
        return NATIVE_RETURN_VOID();
    }
    
    /* Copy elements */
    size_t elem_size = 4;  /* Default to int */
    switch (src->element_type) {
        case T_BOOLEAN:
        case T_BYTE:    elem_size = 1; break;
        case T_CHAR:
        case T_SHORT:   elem_size = 2; break;
        case T_INT:
        case T_FLOAT:   elem_size = 4; break;
        case T_LONG:
        case T_DOUBLE:  elem_size = 8; break;
        case DESC_OBJECT:
        case DESC_ARRAY: elem_size = sizeof(void*); break;
    }
    
    uint8_t* dest_data = (uint8_t*)array_data(dest);
    uint8_t* src_data = (uint8_t*)array_data(src);
    
    memmove(dest_data + dest_pos * elem_size,
            src_data + src_pos * elem_size,
            length * elem_size);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_system_currentTimeMillis(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    jlong ms;
    
#ifdef _WIN32
    /* Windows implementation */
    LARGE_INTEGER freq, counter;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&counter);
    ms = (counter.QuadPart * 1000) / freq.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ms = (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
    
    return NATIVE_RETURN_LONG(ms);
}

static JavaValue native_system_gc(JVM* jvm, JavaThread* thread,
                                  JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    gc_collect(jvm);
    return NATIVE_RETURN_VOID();
}

void init_java_lang_system(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/System", "arraycopy", "(Ljava/lang/Object;ILjava/lang/Object;II)V", native_system_arraycopy},
        {"java/lang/System", "currentTimeMillis", "()J", native_system_currentTimeMillis},
        {"java/lang/System", "gc", "()V", native_system_gc},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Runtime native methods
 */

static JavaValue native_runtime_freeMemory(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    HeapStats stats = heap_get_stats(jvm);
    return NATIVE_RETURN_LONG((jlong)stats.free_size);
}

static JavaValue native_runtime_totalMemory(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    HeapStats stats = heap_get_stats(jvm);
    return NATIVE_RETURN_LONG((jlong)stats.total_size);
}

static JavaValue native_runtime_gc(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    jvm_gc(jvm);
    return NATIVE_RETURN_VOID();
}

void init_java_lang_runtime(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Runtime", "freeMemory", "()J", native_runtime_freeMemory},
        {"java/lang/Runtime", "totalMemory", "()J", native_runtime_totalMemory},
        {"java/lang/Runtime", "gc", "()V", native_runtime_gc},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Math native methods
 */

static JavaValue native_math_sqrt(JVM* jvm, JavaThread* thread,
                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(sqrt(value));
}

static JavaValue native_math_sin(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(sin(value));
}

static JavaValue native_math_cos(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(cos(value));
}

static JavaValue native_math_tan(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(tan(value));
}

static JavaValue native_math_abs_int(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint value = args[0].i;
    return NATIVE_RETURN_INT(value < 0 ? -value : value);
}

static JavaValue native_math_abs_long(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jlong value = args[0].j;
    return NATIVE_RETURN_LONG(value < 0 ? -value : value);
}

static JavaValue native_math_abs_float(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jfloat value = args[0].f;
    return NATIVE_RETURN_FLOAT(value < 0 ? -value : value);
}

static JavaValue native_math_abs_double(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(value < 0 ? -value : value);
}

static JavaValue native_math_max_int(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint a = args[0].i;
    jint b = args[1].i;
    return NATIVE_RETURN_INT(a > b ? a : b);
}

static JavaValue native_math_min_int(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint a = args[0].i;
    jint b = args[1].i;
    return NATIVE_RETURN_INT(a < b ? a : b);
}

void init_java_lang_math(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Math", "sqrt", "(D)D", native_math_sqrt},
        {"java/lang/Math", "sin", "(D)D", native_math_sin},
        {"java/lang/Math", "cos", "(D)D", native_math_cos},
        {"java/lang/Math", "tan", "(D)D", native_math_tan},
        {"java/lang/Math", "abs", "(I)I", native_math_abs_int},
        {"java/lang/Math", "abs", "(J)J", native_math_abs_long},
        {"java/lang/Math", "abs", "(F)F", native_math_abs_float},
        {"java/lang/Math", "abs", "(D)D", native_math_abs_double},
        {"java/lang/Math", "max", "(II)I", native_math_max_int},
        {"java/lang/Math", "min", "(II)I", native_math_min_int},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Thread native methods
 */

static JavaValue native_thread_currentThread(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)args; (void)arg_count;
    return NATIVE_RETURN_OBJECT(thread ? thread->thread_object : NULL);
}

static JavaValue native_thread_sleep(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)arg_count;
    jlong millis = args[0].j;
    thread_sleep(jvm, millis);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_thread_yield(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    thread_yield(jvm);
    return NATIVE_RETURN_VOID();
}

/* External functions for method resolution and execution */
extern JavaMethod* jvm_resolve_method(JVM* jvm, JavaClass* clazz, const char* name, const char* descriptor);
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                          JavaValue* args, JavaValue* result);

/* Thread.start() - starts the thread by calling run() synchronously */
static JavaValue native_thread_start(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* First, check if there's a target Runnable stored in the Thread object */
    JavaClass* thread_class = thread_obj->header.clazz;
    JavaObject* run_target = NULL;
    
    /* Find the 'target' field index in the Thread class */
    if (thread_class && thread_class->fields) {
        for (int i = 0; i < thread_class->fields_count; i++) {
            if (thread_class->fields[i].name && 
                strcmp(thread_class->fields[i].name, "target") == 0) {
                /* Found target field, get its value */
                run_target = (JavaObject*)thread_obj->fields[i].ref;
                fprintf(stderr, "[Thread] start(): target field found at index %d, value = %p\n", 
                        i, (void*)run_target);
                break;
            }
        }
    }
    
    /* If target is set, call run() on the target, otherwise call run() on Thread itself */
    JavaObject* run_obj = run_target ? run_target : thread_obj;
    JavaClass* run_class = run_obj->header.clazz;
    
    fprintf(stderr, "[Thread] start(): looking for run() in %s\n", run_class->class_name);
    
    JavaMethod* run_method = jvm_resolve_method(jvm, run_class, "run", "()V");
    
    if (!run_method) {
        fprintf(stderr, "[Thread] start(): run() method not found in %s\n", run_class->class_name);
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Thread] start(): calling run() on %s\n", run_class->class_name);
    
    /* Call run() synchronously (simplified - no actual threading) */
    JavaValue this_arg = { .ref = run_obj };
    JavaValue result;
    execute_method(jvm, thread, run_method, &this_arg, &result);
    
    fprintf(stderr, "[Thread] start(): run() completed\n");
    
    return NATIVE_RETURN_VOID();
}

/* Thread.<init>() - default constructor */
static JavaValue native_thread_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize target to NULL - no runnable target */
    JavaClass* thread_class = thread_obj->header.clazz;
    if (thread_class && thread_class->fields) {
        for (int i = 0; i < thread_class->fields_count; i++) {
            if (thread_class->fields[i].name && 
                strcmp(thread_class->fields[i].name, "target") == 0) {
                thread_obj->fields[i].ref = NULL;
                fprintf(stderr, "[Thread] <init>(): target field initialized to NULL\n");
                break;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Thread.<init>(Runnable) - constructor with Runnable target */
static JavaValue native_thread_init_runnable(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    JavaObject* runnable = (JavaObject*)args[1].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Set target to the provided Runnable */
    JavaClass* thread_class = thread_obj->header.clazz;
    if (thread_class && thread_class->fields) {
        for (int i = 0; i < thread_class->fields_count; i++) {
            if (thread_class->fields[i].name && 
                strcmp(thread_class->fields[i].name, "target") == 0) {
                thread_obj->fields[i].ref = runnable;
                fprintf(stderr, "[Thread] <init>(Runnable): target field set to %p\n", (void*)runnable);
                break;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

void init_java_lang_thread(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Thread", "currentThread", "()Ljava/lang/Thread;", native_thread_currentThread},
        {"java/lang/Thread", "sleep", "(J)V", native_thread_sleep},
        {"java/lang/Thread", "yield", "()V", native_thread_yield},
        {"java/lang/Thread", "start", "()V", native_thread_start},
        {"java/lang/Thread", "<init>", "()V", native_thread_init},
        {"java/lang/Thread", "<init>", "(Ljava/lang/Runnable;)V", native_thread_init_runnable},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Throwable native methods
 */

static JavaValue native_throwable_fillInStackTrace(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* throwable = NATIVE_ARG_OBJECT(args, 0);
    
    /* TODO: Implement stack trace capture */
    (void)throwable;
    
    return NATIVE_RETURN_OBJECT(throwable);
}

void init_java_lang_throwable(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Throwable", "fillInStackTrace", "()Ljava/lang/Throwable;", native_throwable_fillInStackTrace},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.util.Random native methods
 * 
 * Random uses a simple linear congruential generator:
 * seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1)
 * 
 * We store the seed in the first field of the Random object.
 */

/* Helper to get seed from Random object */
static jlong* random_get_seed_ptr(JavaObject* obj) {
    if (!obj) return NULL;
    /* The seed is stored as a long in the first field (fields[0]) */
    return (jlong*)&obj->fields[0];
}

/* Helper to set seed in Random object */
static void random_set_seed(JavaObject* obj, jlong seed) {
    if (!obj) return;
    obj->fields[0].j = seed;
}

/* Random() - constructor with time-based seed */
static JavaValue native_random_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize seed with current time */
    jlong seed;
#ifdef _WIN32
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    seed = counter.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    seed = (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
    
    /* Apply the initial scramble: seed ^ 0x5DEECE66DL */
    seed ^= 0x5DEECE66DLL;
    
    random_set_seed(obj, seed);
    
    fprintf(stderr, "[Random] <init>: obj=%p, seed=%lld\n", (void*)obj, (long long)seed);
    
    return NATIVE_RETURN_VOID();
}

/* Random(long seed) - constructor with explicit seed */
static JavaValue native_random_init_seed(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong seed = args[1].j;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Apply the initial scramble: seed ^ 0x5DEECE66DL */
    seed ^= 0x5DEECE66DLL;
    
    random_set_seed(obj, seed);
    
    fprintf(stderr, "[Random] <init>(seed): obj=%p, seed=%lld\n", (void*)obj, (long long)seed);
    
    return NATIVE_RETURN_VOID();
}

/* Random.next(int bits) - generate next random value */
static JavaValue native_random_next(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint bits = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jlong* seed_ptr = random_get_seed_ptr(obj);
    if (!seed_ptr) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1) */
    jlong seed = *seed_ptr;
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    *seed_ptr = seed;
    
    /* return (int)(seed >>> (48 - bits)) */
    jint result = (jint)(seed >> (48 - bits));
    
    return NATIVE_RETURN_INT(result);
}

/* Random.nextInt() - random integer */
static JavaValue native_random_nextInt(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jlong* seed_ptr = random_get_seed_ptr(obj);
    if (!seed_ptr) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Generate next random value (32 bits) */
    jlong seed = *seed_ptr;
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    *seed_ptr = seed;
    
    jint result = (jint)(seed >> 16);
    
    fprintf(stderr, "[Random] nextInt(): result=%d, seed=%lld\n", result, (long long)seed);
    
    return NATIVE_RETURN_INT(result);
}

/* Random.nextInt(int bound) - random integer in [0, bound) */
static JavaValue native_random_nextIntBound(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint bound = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    if (bound <= 0) {
        native_throw_iae(jvm, thread, "bound must be positive");
        return NATIVE_RETURN_INT(0);
    }
    
    jlong* seed_ptr = random_get_seed_ptr(obj);
    if (!seed_ptr) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Generate next random value */
    jlong seed = *seed_ptr;
    
    jint result;
    if ((bound & -bound) == bound) {
        /* bound is a power of 2 */
        seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
        *seed_ptr = seed;
        result = (jint)((bound * (seed >> 17)) >> 31);
    } else {
        /* Reject samples that would produce bias */
        jint val;
        do {
            seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
            val = (jint)(seed >> 17);
            jint r = val % bound;
            /* Check for bias */
            while (val - r + (bound - 1) < 0) {
                seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
                val = (jint)(seed >> 17);
                r = val % bound;
            }
            result = r;
            break;  /* Simplified - just take the first value */
        } while (0);
    }
    
    *seed_ptr = seed;
    
    fprintf(stderr, "[Random] nextInt(%d): result=%d, seed=%lld\n", bound, result, (long long)seed);
    
    return NATIVE_RETURN_INT(result);
}

/* Random.nextLong() - random long */
static JavaValue native_random_nextLong(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_LONG(0);
    }
    
    jlong* seed_ptr = random_get_seed_ptr(obj);
    if (!seed_ptr) {
        return NATIVE_RETURN_LONG(0);
    }
    
    /* Generate two 32-bit values and combine */
    jlong seed = *seed_ptr;
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint high = (jint)(seed >> 16);
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint low = (jint)(seed >> 16);
    *seed_ptr = seed;
    
    jlong result = ((jlong)high << 32) | (low & 0xFFFFFFFFLL);
    
    return NATIVE_RETURN_LONG(result);
}

/* Random.nextFloat() - random float in [0, 1) */
static JavaValue native_random_nextFloat(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_FLOAT(0.0f);
    }
    
    jlong* seed_ptr = random_get_seed_ptr(obj);
    if (!seed_ptr) {
        return NATIVE_RETURN_FLOAT(0.0f);
    }
    
    jlong seed = *seed_ptr;
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    *seed_ptr = seed;
    
    jfloat result = (jfloat)(seed >> 24) / (jfloat)(1LL << 24);
    
    return NATIVE_RETURN_FLOAT(result);
}

/* Random.nextDouble() - random double in [0, 1) */
static JavaValue native_random_nextDouble(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_DOUBLE(0.0);
    }
    
    jlong* seed_ptr = random_get_seed_ptr(obj);
    if (!seed_ptr) {
        return NATIVE_RETURN_DOUBLE(0.0);
    }
    
    jlong seed = *seed_ptr;
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint high = (jint)(seed >> 16);
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint low = (jint)(seed >> 16);
    *seed_ptr = seed;
    
    jlong combined = ((jlong)high << 27) | (low >> 5);
    jdouble result = (jdouble)combined / (jdouble)(1LL << 53);
    
    return NATIVE_RETURN_DOUBLE(result);
}

/* Random.setSeed(long) - set the seed */
static JavaValue native_random_setSeed(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong seed = args[1].j;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Apply the initial scramble: seed ^ 0x5DEECE66DL */
    seed ^= 0x5DEECE66DLL;
    
    random_set_seed(obj, seed);
    
    return NATIVE_RETURN_VOID();
}

/*
 * java.lang.StringBuffer native methods
 * 
 * StringBuffer is used for building strings. We need to implement append() 
 * which returns 'this' for method chaining, and toString().
 */

/* StringBuffer buffer field access */
#define STRINGBUFFER_INITIAL_CAPACITY 16

static char* stringbuffer_get_buffer(JavaObject* obj) {
    if (!obj) return NULL;
    /* The buffer is stored in a char[] field. We'll use a simple approach:
     * Store the string data in the first field as a pointer to a malloc'd buffer */
    if (obj->fields[0].raw == 0) {
        /* Initialize buffer */
        obj->fields[0].ref = calloc(1, 1024);  /* Start with 1KB buffer */
    }
    return (char*)obj->fields[0].ref;
}

static int* stringbuffer_get_length_ptr(JavaObject* obj) {
    if (!obj) return NULL;
    /* Use second field for length */
    return &obj->fields[1].i;
}

/* StringBuffer.append(String) */
static JavaValue native_stringbuffer_append_string(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaString* str = (JavaString*)args[1].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (str && buffer && len_ptr) {
        const char* utf8 = str->utf8 ? str->utf8 : "";
        int str_len = strlen(utf8);
        memcpy(buffer + *len_ptr, utf8, str_len);
        *len_ptr += str_len;
        buffer[*len_ptr] = '\0';
    }
    
    /* Return this for method chaining */
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(int) */
static JavaValue native_stringbuffer_append_int(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint value = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    /* Debug: verify object's class pointer */
    if (obj->header.clazz && obj->header.clazz->class_name) {
        fprintf(stderr, "[NATIVE] StringBuffer.append(%d): obj=%p, class=%s\n", 
                value, (void*)obj, obj->header.clazz->class_name);
    } else {
        fprintf(stderr, "[NATIVE] StringBuffer.append(%d): obj=%p, INVALID CLASS POINTER!\n",
                value, (void*)obj);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%d", value);
        if (written > 0 && *len_ptr + written < 1024) {  /* Bounds check */
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(long) */
static JavaValue native_stringbuffer_append_long(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong value = args[1].j;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%lld", (long long)value);
        if (written > 0) {
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(float) */
static JavaValue native_stringbuffer_append_float(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jfloat value = args[1].f;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%g", (double)value);
        if (written > 0) {
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(double) */
static JavaValue native_stringbuffer_append_double(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jdouble value = args[1].d;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%g", value);
        if (written > 0) {
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(boolean) */
static JavaValue native_stringbuffer_append_boolean(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jboolean value = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        const char* str = value ? "true" : "false";
        int str_len = strlen(str);
        memcpy(buffer + *len_ptr, str, str_len);
        *len_ptr += str_len;
        buffer[*len_ptr] = '\0';
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(char) */
static JavaValue native_stringbuffer_append_char(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jchar value = (jchar)args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        /* Simple: just add the char as a byte if it's ASCII */
        if (value < 128) {
            buffer[*len_ptr] = (char)value;
            (*len_ptr)++;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(Object) */
static JavaValue native_stringbuffer_append_object(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* value = (JavaObject*)args[1].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        if (value) {
            /* Call toString() on the object - simplified, just append class name */
            const char* str = "Object";
            int str_len = strlen(str);
            memcpy(buffer + *len_ptr, str, str_len);
            *len_ptr += str_len;
        } else {
            const char* str = "null";
            int str_len = strlen(str);
            memcpy(buffer + *len_ptr, str, str_len);
            *len_ptr += str_len;
        }
        buffer[*len_ptr] = '\0';
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.toString() */
static JavaValue native_stringbuffer_toString(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        JavaString* str = jvm_new_string(jvm, buffer);
        return NATIVE_RETURN_OBJECT(str);
    }
    
    return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, ""));
}

/* StringBuffer.length() */
static JavaValue native_stringbuffer_length(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    return NATIVE_RETURN_INT(len_ptr ? *len_ptr : 0);
}

void init_java_lang_stringbuffer(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/StringBuffer", "append", "(Ljava/lang/String;)Ljava/lang/StringBuffer;", native_stringbuffer_append_string},
        {"java/lang/StringBuffer", "append", "(I)Ljava/lang/StringBuffer;", native_stringbuffer_append_int},
        {"java/lang/StringBuffer", "append", "(J)Ljava/lang/StringBuffer;", native_stringbuffer_append_long},
        {"java/lang/StringBuffer", "append", "(F)Ljava/lang/StringBuffer;", native_stringbuffer_append_float},
        {"java/lang/StringBuffer", "append", "(D)Ljava/lang/StringBuffer;", native_stringbuffer_append_double},
        {"java/lang/StringBuffer", "append", "(Z)Ljava/lang/StringBuffer;", native_stringbuffer_append_boolean},
        {"java/lang/StringBuffer", "append", "(C)Ljava/lang/StringBuffer;", native_stringbuffer_append_char},
        {"java/lang/StringBuffer", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuffer;", native_stringbuffer_append_object},
        {"java/lang/StringBuffer", "toString", "()Ljava/lang/String;", native_stringbuffer_toString},
        {"java/lang/StringBuffer", "length", "()I", native_stringbuffer_length},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    fprintf(stderr, "[NATIVE] Registered java/lang/StringBuffer native methods\n");
}

void init_java_util_random(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Random", "<init>", "()V", native_random_init},
        {"java/util/Random", "<init>", "(J)V", native_random_init_seed},
        {"java/util/Random", "next", "(I)I", native_random_next},
        {"java/util/Random", "nextInt", "()I", native_random_nextInt},
        {"java/util/Random", "nextInt", "(I)I", native_random_nextIntBound},
        {"java/util/Random", "nextLong", "()J", native_random_nextLong},
        {"java/util/Random", "nextFloat", "()F", native_random_nextFloat},
        {"java/util/Random", "nextDouble", "()D", native_random_nextDouble},
        {"java/util/Random", "setSeed", "(J)V", native_random_setSeed},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    fprintf(stderr, "[NATIVE] Registered java/util/Random native methods\n");
}

/*
 * java.util.Timer native methods
 * Simple implementation that runs TimerTask.run() synchronously
 */

static JavaValue native_timer_schedule_task_delay(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)arg_count;
    /* args[0] = this (Timer), args[1] = TimerTask, args[2-3] = delay (long) */
    JavaObject* timer_task = (JavaObject*)args[1].ref;
    jlong delay = args[2].j;  /* First long value */
    
    (void)delay;  /* For now, ignore delay and run immediately */
    
    if (!timer_task) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Find and call run() method on the TimerTask */
    JavaClass* task_class = timer_task->header.clazz;
    JavaMethod* run_method = jvm_resolve_method(jvm, task_class, "run", "()V");
    
    if (run_method) {
        JavaValue task_arg = { .ref = timer_task };
        JavaValue result;
        execute_method(jvm, thread, run_method, &task_arg, &result);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_timer_schedule_task_delay_period(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)arg_count;
    /* args[0] = this (Timer), args[1] = TimerTask, args[2-3] = delay (long), args[4-5] = period (long) */
    JavaObject* timer_task = (JavaObject*)args[1].ref;
    /* jlong delay = args[2].j; */
    /* jlong period = args[4].j; */
    
    if (!timer_task) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* For simplicity, just run once */
    JavaClass* task_class = timer_task->header.clazz;
    JavaMethod* run_method = jvm_resolve_method(jvm, task_class, "run", "()V");
    
    if (run_method) {
        JavaValue task_arg = { .ref = timer_task };
        JavaValue result;
        execute_method(jvm, thread, run_method, &task_arg, &result);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_timer_cancel(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Timer.cancel() - nothing to do in our simple implementation */
    return NATIVE_RETURN_VOID();
}

void init_java_util_timer(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Timer", "schedule", "(Ljava/util/TimerTask;J)V", native_timer_schedule_task_delay},
        {"java/util/Timer", "schedule", "(Ljava/util/TimerTask;JJ)V", native_timer_schedule_task_delay_period},
        {"java/util/Timer", "scheduleAtFixedRate", "(Ljava/util/TimerTask;JJ)V", native_timer_schedule_task_delay_period},
        {"java/util/Timer", "cancel", "()V", native_timer_cancel},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    fprintf(stderr, "[NATIVE] Registered java/util/Timer native methods\n");
}

/*
 * Call a native method
 */
int native_call(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                JavaValue* args, JavaValue* result) {
    if (!method || !method->clazz) {
        fprintf(stderr, "[NATIVE] native_call: NULL method or class\n");
        return -1;
    }
    
    /* Find native method handler */
    NativeMethod handler = native_find(jvm, 
        method->clazz->class_name, method->name, method->descriptor);
    
    if (!handler) {
        fprintf(stderr, "[NATIVE] Unimplemented native method: %s.%s%s\n",
                method->clazz->class_name, method->name, method->descriptor);
        
        /* Return default value instead of crashing */
        if (result) {
            memset(result, 0, sizeof(JavaValue));
        }
        return 0;  /* Don't fail, just return default */
    }
    
    /* Count arguments */
    int arg_count = count_args(method->descriptor);
    
    /* For non-static methods, args[0] is 'this' reference */
    int is_static = (method->access_flags & ACC_STATIC) != 0;
    int total_args = is_static ? arg_count : arg_count + 1;
    
    /* Call the native method */
    JavaValue ret = handler(jvm, thread, args, total_args);
    
    if (result) {
        *result = ret;
    }
    
    /* Check for exception */
    if (thread->pending_exception) {
        return -1;
    }
    
    return 0;
}

/* Count arguments in method descriptor */
int count_args(const char* descriptor) {
    if (!descriptor) return 0;
    
    int count = 0;
    const char* p = descriptor;
    
    /* Skip return type, find args */
    if (*p != '(') return 0;
    p++;
    
    while (*p && *p != ')') {
        switch (*p) {
            case 'B': case 'C': case 'D': case 'F':
            case 'I': case 'J': case 'S': case 'Z':
                count++;
                if (*p == 'J' || *p == 'D') count++;  /* Long/double take 2 slots */
                p++;
                break;
            case 'L':
                count++;
                while (*p && *p != ';') p++;
                if (*p == ';') p++;
                break;
            case '[':
                count++;
                while (*p == '[') p++;
                if (*p == 'L') {
                    while (*p && *p != ';') p++;
                    if (*p == ';') p++;
                } else {
                    p++;
                }
                break;
            default:
                p++;
                break;
        }
    }
    
    return count;
}
