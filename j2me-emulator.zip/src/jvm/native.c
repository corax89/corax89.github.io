/*
 * J2ME Emulator - Native Methods
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup, clock_gettime, pthread - only on POSIX */
#define _DEFAULT_SOURCE   /* For usleep */
#endif

#include <stdio.h>
#include "debug.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#include <unistd.h>
#endif

#include "native.h"
#include "jvm.h"
#include "heap.h"
#include "threads.h"
#include "opcodes.h"
#include "classfile.h"
#include "midp.h"  /* For load_jar_resource */

/* Forward declarations */
void init_java_util_random(JVM* jvm);
void init_java_util_timer(JVM* jvm);
void init_java_lang_stringbuffer(JVM* jvm);
void init_java_lang_stringbuilder(JVM* jvm);
void init_java_util_vector(JVM* jvm);
void init_java_util_enumeration(JVM* jvm);
void init_java_util_hashtable(JVM* jvm);
void init_java_io_bytearrayinputstream(JVM* jvm);
void init_java_io_bytearrayoutputstream(JVM* jvm);
void init_java_io_dataoutputstream(JVM* jvm);
void init_java_io_datainputstream(JVM* jvm);
void init_java_io_inputstreamreader(JVM* jvm);
void init_java_io_bufferedreader(JVM* jvm);
void init_nokia_sound(JVM* jvm);
void init_nokia_ui(JVM* jvm);
void init_nokia_direct_graphics(JVM* jvm);
void init_javax_microedition_midlet_MIDlet(JVM* jvm);
void init_javax_microedition_rms(JVM* jvm);
void init_javax_microedition_lcdui_graphics(JVM* jvm);
void init_javax_microedition_lcdui_image(JVM* jvm);
void init_javax_microedition_lcdui_display(JVM* jvm);
void init_javax_microedition_lcdui_form(JVM* jvm);
void init_javax_microedition_media(JVM* jvm);
void init_java_lang_integer(JVM* jvm);
void init_java_lang_long(JVM* jvm);
void init_java_lang_boolean(JVM* jvm);
void init_javax_microedition_io(JVM* jvm);
void init_java_util_calendar(JVM* jvm);
void init_java_util_date(JVM* jvm);
void init_java_lang_character(JVM* jvm);
void init_java_lang_byte_short(JVM* jvm);
void init_java_lang_float_double(JVM* jvm);
void init_javax_microedition_media_manager(JVM* jvm);
void init_vendor_extensions(JVM* jvm);
void init_javax_microedition_m3g(JVM* jvm);  /* JSR 184 Mobile 3D Graphics */

/* Native method registry */
#define MAX_NATIVE_METHODS 1024

static struct {
    NativeMethodEntry entries[MAX_NATIVE_METHODS];
    int count;
} native_registry;

/* Forward declaration for execute_method (used by Class.newInstance) */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                          JavaValue* args, JavaValue* result);

/* Initialize native methods */
int native_init(JVM* jvm) {
    native_registry.count = 0;
    
    /* Initialize standard Java native methods */
    init_java_lang_object(jvm);
    init_java_lang_class(jvm);
    init_java_lang_string(jvm);
    init_java_lang_system(jvm);
    init_java_lang_runtime(jvm);
    init_java_lang_math(jvm);
    init_java_lang_thread(jvm);
    init_java_lang_throwable(jvm);
    
    /* Initialize MIDlet lifecycle */
    init_javax_microedition_midlet_MIDlet(jvm);
    
    /* Initialize StringBuffer and StringBuilder */
    init_java_lang_stringbuffer(jvm);
    init_java_lang_stringbuilder(jvm);
    
    /* Initialize java.util collection classes */
    init_java_util_random(jvm);
    init_java_util_vector(jvm);
    init_java_util_enumeration(jvm);
    init_java_util_hashtable(jvm);
    
    /* Initialize java.util.Timer */
    init_java_util_timer(jvm);
    
    /* Initialize ByteArrayInputStream */
    init_java_io_bytearrayinputstream(jvm);
    
    /* Initialize ByteArrayOutputStream */
    init_java_io_bytearrayoutputstream(jvm);
    
    /* Initialize DataOutputStream */
    init_java_io_dataoutputstream(jvm);
    
    /* Initialize DataInputStream */
    init_java_io_datainputstream(jvm);
    
    /* Initialize InputStreamReader and BufferedReader */
    init_java_io_inputstreamreader(jvm);
    init_java_io_bufferedreader(jvm);
    
    /* Initialize Nokia Sound */
    init_nokia_sound(jvm);
    
    /* Initialize Nokia UI API */
    init_nokia_ui(jvm);
    init_nokia_direct_graphics(jvm);
    
    /* Initialize RMS (RecordStore) */
    init_javax_microedition_rms(jvm);
    
    /* Initialize LCDUI */
    init_javax_microedition_lcdui_graphics(jvm);
    init_javax_microedition_lcdui_image(jvm);
    init_javax_microedition_lcdui_display(jvm);
    init_javax_microedition_lcdui_form(jvm);
    
    /* Initialize Media */
    init_javax_microedition_media(jvm);
    
    /* Initialize wrapper classes */
    init_java_lang_integer(jvm);
    init_java_lang_long(jvm);
    init_java_lang_boolean(jvm);
    init_java_lang_character(jvm);
    init_java_lang_byte_short(jvm);
    init_java_lang_float_double(jvm);
    
    /* Initialize J2ME IO (GCF) */
    init_javax_microedition_io(jvm);
    
    /* Initialize Calendar and Date */
    init_java_util_calendar(jvm);
    init_java_util_date(jvm);
    
    /* Initialize Media Manager */
    init_javax_microedition_media_manager(jvm);
    
    /* Initialize vendor-specific extensions */
    init_vendor_extensions(jvm);
    
    /* Initialize JSR 184 Mobile 3D Graphics API */
    init_javax_microedition_m3g(jvm);
    
    return JNI_OK;
}

/* Register a native method */
int native_register(JVM* jvm, const char* class_name, const char* method_name,
                    const char* descriptor, NativeMethod handler) {
    (void)jvm;
    
    if (native_registry.count >= MAX_NATIVE_METHODS) {
        return JNI_ERR;
    }
    
    NativeMethodEntry* entry = &native_registry.entries[native_registry.count++];
    entry->class_name = class_name;
    entry->method_name = method_name;
    entry->descriptor = descriptor;
    entry->handler = handler;
    
    return JNI_OK;
}

/* Register multiple native methods */
int native_register_methods(JVM* jvm, const NativeMethodEntry* methods, int count) {
    for (int i = 0; i < count; i++) {
        if (native_register(jvm, methods[i].class_name, methods[i].method_name,
                           methods[i].descriptor, methods[i].handler) != JNI_OK) {
            return JNI_ERR;
        }
    }
    return JNI_OK;
}

/* Find native method */
NativeMethod native_find(JVM* jvm, const char* class_name, const char* method_name,
                         const char* descriptor) {
    (void)jvm;

    for (int i = 0; i < native_registry.count; i++) {
        NativeMethodEntry* entry = &native_registry.entries[i];
        if (strcmp(entry->class_name, class_name) == 0 &&
            strcmp(entry->method_name, method_name) == 0 &&
            strcmp(entry->descriptor, descriptor) == 0) {
            return entry->handler;
        }
    }
    
    /* Debug: print what we're looking for */
    static int debug_count = 0;
    if (debug_count < 10) {
        NATIVE_DEBUG("Not found: %s.%s%s (checked %d entries)", 
                class_name, method_name, descriptor, native_registry.count);
        debug_count++;
    }

    return NULL;
}

/* Utility functions */
const char* native_get_string_utf8(JVM* jvm, JavaValue* args, int index) {
    JavaString* str = (JavaString*)args[index].ref;
    if (!str) return NULL;
    return string_utf8(jvm, str);
}

/* Exception helpers */
void native_throw_npe(JVM* jvm, JavaThread* thread) {
    jvm_throw_by_name(jvm, "java/lang/NullPointerException", NULL);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_aioobe(JVM* jvm, JavaThread* thread, jint index) {
    char msg[64];
    snprintf(msg, sizeof(msg), "Array index out of range: %d", index);
    jvm_throw_by_name(jvm, "java/lang/ArrayIndexOutOfBoundsException", msg);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_cnfe(JVM* jvm, JavaThread* thread, const char* name) {
    jvm_throw_by_name(jvm, "java/lang/ClassNotFoundException", name);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_oome(JVM* jvm, JavaThread* thread) {
    jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
    thread->pending_exception = jvm_exception_pending(jvm);
}

void native_throw_iae(JVM* jvm, JavaThread* thread, const char* message) {
    jvm_throw_by_name(jvm, "java/lang/IllegalArgumentException", message);
    thread->pending_exception = jvm_exception_pending(jvm);
}

/* Throw IOException */
void native_throw_ioe(JVM* jvm, JavaThread* thread, const char* message) {
    jvm_throw_by_name(jvm, "java/io/IOException", message);
    thread->pending_exception = jvm_exception_pending(jvm);
}

/* === КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Правильный расчет слотов полей ===
 * 
 * Проблема: native-код использовал индекс поля в clazz->fields[] напрямую
 * как слот в obj->fields[], но это неправильно потому что:
 * 1. Статические поля не хранятся в экземпляре
 * 2. Поля суперкласса должны быть учтены (они идут первыми)
 * 3. Long/double занимают 2 слота
 * 
 * Эта функция вычисляет правильный слот для поля по его имени.
 * Возвращает -1 если поле не найдено.
 */

/* Helper: count instance fields in a class (excluding static) */
static int native_count_instance_fields(JavaClass* clazz) {
    int count = 0;
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (!(clazz->fields[i].access_flags & ACC_STATIC)) {
                count++;
                /* Long and double take 2 slots */
                if (clazz->fields[i].descriptor &&
                    (clazz->fields[i].descriptor[0] == 'J' || clazz->fields[i].descriptor[0] == 'D')) {
                    count++;
                }
            }
        }
    }
    return count;
}

/* Helper: count instance fields before a given field index */
static int native_count_instance_fields_before(JavaClass* clazz, int field_index) {
    int count = 0;
    if (clazz->fields) {
        for (int i = 0; i < field_index; i++) {
            if (!(clazz->fields[i].access_flags & ACC_STATIC)) {
                count++;
                /* Long and double take 2 slots */
                if (clazz->fields[i].descriptor &&
                    (clazz->fields[i].descriptor[0] == 'J' || clazz->fields[i].descriptor[0] == 'D')) {
                    count++;
                }
            }
        }
    }
    return count;
}

/* Build class hierarchy array from Object to obj_class */
static int native_build_hierarchy(JavaClass* obj_class, JavaClass** hierarchy, int max_depth) {
    int depth = 0;
    JavaClass* c = obj_class;
    
    while (c && depth < max_depth) {
        hierarchy[depth++] = c;
        c = c->super_class;
    }
    
    /* Reverse to get Object first */
    for (int i = 0; i < depth / 2; i++) {
        JavaClass* tmp = hierarchy[i];
        hierarchy[i] = hierarchy[depth - 1 - i];
        hierarchy[depth - 1 - i] = tmp;
    }
    
    return depth;
}

/* Find field slot in object instance - CORRECT VERSION */
typedef struct {
    JavaClass* defining_class;
    int field_index;
    int slot;
} NativeFieldLookupResult;

static NativeFieldLookupResult native_find_field_slot(JavaClass* obj_class, 
                                                       const char* field_name,
                                                       const char* descriptor) {
    NativeFieldLookupResult result = { NULL, -1, -1 };
    
    if (!obj_class || !field_name) return result;
    
    /* Build hierarchy from Object to obj_class */
    JavaClass* hierarchy[64];
    int depth = native_build_hierarchy(obj_class, hierarchy, 64);
    
    /* Search for field in hierarchy (from Object to obj_class) */
    for (int h = 0; h < depth; h++) {
        JavaClass* current_class = hierarchy[h];
        
        if (current_class->fields) {
            for (int i = 0; i < current_class->fields_count; i++) {
                JavaField* field = &current_class->fields[i];
                
                /* Skip static fields */
                if (field->access_flags & ACC_STATIC) continue;
                
                /* Match by name */
                if (!field->name || strcmp(field->name, field_name) != 0) continue;
                
                /* Match by descriptor if provided */
                if (descriptor && field->descriptor) {
                    if (strcmp(field->descriptor, descriptor) != 0) continue;
                }
                
                /* Found the field! */
                result.defining_class = current_class;
                result.field_index = i;
                
                /* Calculate slot */
                result.slot = 0;
                
                /* Add fields from all classes above current_class */
                for (int j = 0; j < h; j++) {
                    result.slot += native_count_instance_fields(hierarchy[j]);
                }
                
                /* Add fields before this one in current_class */
                result.slot += native_count_instance_fields_before(current_class, i);
                
                return result;
            }
        }
    }
    
    return result;
}

/* Convenience function to get field slot by name only */
int native_get_field_slot(JavaClass* clazz, const char* field_name) {
    NativeFieldLookupResult result = native_find_field_slot(clazz, field_name, NULL);
    return result.slot;
}

/* Convenience function to get field value from object by name */
JavaValue native_get_field_value(JavaObject* obj, const char* field_name) {
    JavaValue v = { .raw = 0 };
    if (!obj || !obj->header.clazz || !field_name) return v;
    
    int slot = native_get_field_slot(obj->header.clazz, field_name);
    if (slot < 0) return v;
    
    int max_slots = (obj->header.clazz->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue);
    if (slot >= max_slots) {
        NATIVE_DEBUG("ERROR: field '%s' slot %d out of bounds (max %d)",
                field_name, slot, max_slots);
        return v;
    }
    
    return obj->fields[slot];
}

/* Convenience function to set field value in object by name */
void native_set_field_value(JavaObject* obj, const char* field_name, JavaValue value) {
    if (!obj || !obj->header.clazz || !field_name) return;
    
    int slot = native_get_field_slot(obj->header.clazz, field_name);
    if (slot < 0) {
        NATIVE_DEBUG("WARNING: field '%s' not found in %s",
                field_name, obj->header.clazz->class_name ? obj->header.clazz->class_name : "?");
        return;
    }
    
    int max_slots = (obj->header.clazz->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue);
    if (slot >= max_slots) {
        NATIVE_DEBUG("ERROR: field '%s' slot %d out of bounds (max %d)",
                field_name, slot, max_slots);
        return;
    }
    
    /* Debug: Log field set */
    NATIVE_DEBUG("set_field: class=%s, field='%s', slot=%d/%d, value=%p",
            obj->header.clazz->class_name ? obj->header.clazz->class_name : "?",
            field_name, slot, max_slots, value.ref);
    
    obj->fields[slot] = value;
}

/*
 * java.lang.Object native methods
 */

static JavaValue native_object_getClass(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    return NATIVE_RETURN_OBJECT(obj ? obj->header.clazz : NULL);
}

static JavaValue native_object_hashCode(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    return NATIVE_RETURN_INT(obj ? obj->header.hashcode : 0);
}

static JavaValue native_object_clone(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* TODO: Implement clone */
    return NATIVE_RETURN_NULL();
}

static JavaValue native_object_notify(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    monitor_notify(jvm, obj);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_object_notifyAll(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    monitor_notify_all(jvm, obj);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_object_wait(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    JavaObject* obj = NATIVE_ARG_OBJECT(args, 0);
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    jlong timeout = 0;
    bool timed = false;
    
    if (arg_count >= 2) {
        timeout = args[1].j;
        timed = true;
    }
    
    monitor_wait(jvm, obj, timeout, timed);
    return NATIVE_RETURN_VOID();
}

/* Object.<init>() - base constructor, does nothing */
static JavaValue native_object_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Object constructor does nothing - just return */
    return NATIVE_RETURN_VOID();
}

void init_java_lang_object(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Object", "<init>", "()V", native_object_init},
        {"java/lang/Object", "getClass", "()Ljava/lang/Class;", native_object_getClass},
        {"java/lang/Object", "hashCode", "()I", native_object_hashCode},
        {"java/lang/Object", "clone", "()Ljava/lang/Object;", native_object_clone},
        {"java/lang/Object", "notify", "()V", native_object_notify},
        {"java/lang/Object", "notifyAll", "()V", native_object_notifyAll},
        {"java/lang/Object", "wait", "(J)V", native_object_wait},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Class native methods
 */

static JavaValue native_class_forName(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    /* STATIC METHOD - no 'this' argument!
     * args[0] = class name (String)
     */
    const char* name = native_get_string_utf8(jvm, args, 0);
    if (!name) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Convert dots to slashes */
    char* internal_name = strdup(name);
    for (char* p = internal_name; *p; p++) {
        if (*p == '.') *p = '/';
    }
    
    JavaClass* clazz = jvm_load_class(jvm, internal_name);
    free(internal_name);
    
    if (!clazz) {
        native_throw_cnfe(jvm, thread, name);
        return NATIVE_RETURN_NULL();
    }
    
    return NATIVE_RETURN_OBJECT(clazz);
}

static JavaValue native_class_getName(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaClass* clazz = (JavaClass*)args[0].ref;
    if (!clazz || !clazz->class_name) return NATIVE_RETURN_NULL();
    
    char* name = class_name_to_java(clazz->class_name);
    JavaString* str = jvm_new_string(jvm, name);
    free(name);
    
    return NATIVE_RETURN_OBJECT(str);
}

static JavaValue native_class_isInstance(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaClass* clazz = (JavaClass*)args[0].ref;
    JavaObject* obj = (JavaObject*)args[1].ref;
    
    return NATIVE_RETURN_INT(object_instance_of(obj, clazz) ? 1 : 0);
}

/* Class.getResourceAsStream(String) - load resource from JAR */
static JavaValue native_class_getResourceAsStream(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    
    /* args[0] is the Class object (which is a JavaClass* in our implementation) */
    JavaClass* clazz = (JavaClass*)args[0].ref;
    JavaString* name_str = (JavaString*)args[1].ref;
    
    CLASS_DEBUG("getResourceAsStream: clazz=%p, name_str=%p",
            (void*)clazz, (void*)name_str);
    
    if (!name_str) {
        CLASS_DEBUG("getResourceAsStream: name_str is NULL");
        return NATIVE_RETURN_NULL();
    }
    
    /* Get the resource name */
    const char* name = string_utf8(jvm, name_str);
    if (!name) {
        CLASS_DEBUG("getResourceAsStream: string_utf8 returned NULL");
        return NATIVE_RETURN_NULL();
    }
    
    CLASS_DEBUG("getResourceAsStream: name='%s' (from class %s)", 
            name, (clazz && clazz->class_name) ? clazz->class_name : "?");
    
    /* Skip leading slash if present */
    const char* resource_name = name;
    if (resource_name[0] == '/') {
        resource_name++;
    }
    
    /* Load the resource from JAR */
    size_t data_size;
    uint8_t* data = load_jar_resource(resource_name, &data_size);
    
    if (!data) {
        CLASS_DEBUG("Resource not found: %s", name);
        return NATIVE_RETURN_NULL();
    }
    
    CLASS_DEBUG("Loaded %zu bytes from %s", data_size, name);
    
    /* Create a byte array to hold the data */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, (jsize)data_size);
    if (!byte_array) {
        free(data);
        return NATIVE_RETURN_NULL();
    }
    
    /* Copy data into byte array */
    memcpy(array_data(byte_array), data, data_size);
    free(data);
    
    /* Create ByteArrayInputStream object */
    JavaClass* bais_class = jvm_load_class(jvm, "java/io/ByteArrayInputStream");
    if (!bais_class) {
        CLASS_DEBUG("Failed to load ByteArrayInputStream class");
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* bais_obj = jvm_new_object(jvm, bais_class);
    if (!bais_obj) {
        CLASS_DEBUG("Failed to create ByteArrayInputStream object");
        return NATIVE_RETURN_NULL();
    }
    
    /* Set fields: buf = byte_array, pos = 0, count = data_size
     * ИСПРАВЛЕНО: Используем native_set_field_value вместо прямого доступа по индексу */
    JavaValue buf_val = { .ref = byte_array };
    JavaValue pos_val = { .i = 0 };
    JavaValue count_val = { .i = (jint)data_size };
    
    native_set_field_value(bais_obj, "buf", buf_val);
    native_set_field_value(bais_obj, "pos", pos_val);
    native_set_field_value(bais_obj, "count", count_val);
    
    CLASS_DEBUG("Created ByteArrayInputStream: buf=%p, pos=0, count=%zu",
            (void*)byte_array, data_size);
    
    return NATIVE_RETURN_OBJECT(bais_obj);
}

/* ByteArrayInputStream.<init>(byte[]) - constructor with byte array */
static JavaValue native_bytearrayinputstream_init_bytes(JVM* jvm, JavaThread* thread,
                                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buf = (JavaArray*)args[1].ref;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[BAIS] <init>(byte[]): obj=%p, buf=%p\n", (void*)obj, (void*)buf);
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue buf_val = { .ref = buf };
    JavaValue pos_val = { .i = 0 };
    JavaValue count_val = { .i = buf ? (jint)buf->length : 0 };
    
    native_set_field_value(obj, "buf", buf_val);
    native_set_field_value(obj, "pos", pos_val);
    native_set_field_value(obj, "count", count_val);
    
    fprintf(stderr, "[BAIS] Initialized: buf=%p, pos=0, count=%d\n", 
            (void*)buf, buf ? (int)buf->length : 0);
    
    return NATIVE_RETURN_VOID();
}

/* ByteArrayInputStream.<init>(byte[], int, int) - constructor with offset and length */
static JavaValue native_bytearrayinputstream_init_bytes_offset(JVM* jvm, JavaThread* thread,
                                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buf = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[BAIS] <init>(byte[], %d, %d): obj=%p, buf=%p\n", offset, length, (void*)obj, (void*)buf);
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue buf_val = { .ref = buf };
    JavaValue pos_val = { .i = offset };
    JavaValue count_val = { .i = offset + length };
    
    native_set_field_value(obj, "buf", buf_val);
    native_set_field_value(obj, "pos", pos_val);
    native_set_field_value(obj, "count", count_val);
    
    return NATIVE_RETURN_VOID();
}

/* ByteArrayInputStream.read() - read single byte */
static JavaValue native_bytearrayinputstream_read(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* buf = (JavaArray*)native_get_field_value(obj, "buf").ref;
    jint pos = native_get_field_value(obj, "pos").i;
    jint count = native_get_field_value(obj, "count").i;
    
    if (!buf || pos >= count) {
        return NATIVE_RETURN_INT(-1);  /* EOF */
    }
    
    /* Read byte from buffer */
    uint8_t* data = (uint8_t*)array_data(buf);
    jbyte val = (jbyte)data[pos];
    
    /* Update position */
    JavaValue new_pos = { .i = pos + 1 };
    native_set_field_value(obj, "pos", new_pos);
    
    return NATIVE_RETURN_INT(val & 0xFF);  /* Return as unsigned */
}

/* ByteArrayInputStream.read(byte[], int, int) - read into buffer */
static JavaValue native_bytearrayinputstream_read_array(JVM* jvm, JavaThread* thread,
                                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* dest = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint len = args[3].i;
    
    if (!obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* buf = (JavaArray*)native_get_field_value(obj, "buf").ref;
    jint pos = native_get_field_value(obj, "pos").i;
    jint count = native_get_field_value(obj, "count").i;
    
    if (!buf || !dest) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (pos >= count) {
        return NATIVE_RETURN_INT(-1);  /* EOF */
    }
    
    /* Calculate bytes to read */
    jint available = count - pos;
    jint to_read = (len < available) ? len : available;
    
    /* Check bounds */
    if (offset < 0 || len < 0 || offset + len > (jint)dest->length) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Copy data */
    uint8_t* src_data = (uint8_t*)array_data(buf);
    uint8_t* dest_data = (uint8_t*)array_data(dest);
    memcpy(dest_data + offset, src_data + pos, to_read);
    
    /* Update position */
    JavaValue new_pos = { .i = pos + to_read };
    native_set_field_value(obj, "pos", new_pos);
    
    return NATIVE_RETURN_INT(to_read);
}

/* ByteArrayInputStream.read(byte[]) - read into entire buffer */
static JavaValue native_bytearrayinputstream_read_array_full(JVM* jvm, JavaThread* thread,
                                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* dest = (JavaArray*)args[1].ref;
    
    if (!obj || !dest) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Call read(byte[], 0, length) */
    JavaValue new_args[4];
    new_args[0].ref = args[0].ref;  /* this */
    new_args[1].ref = args[1].ref;  /* buffer */
    new_args[2].i = 0;               /* offset */
    new_args[3].i = dest->length;    /* length */
    
    return native_bytearrayinputstream_read_array(jvm, thread, new_args, 4);
}

/* ByteArrayInputStream.available() - bytes available to read */
static JavaValue native_bytearrayinputstream_available(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    jint pos = native_get_field_value(obj, "pos").i;
    jint count = native_get_field_value(obj, "count").i;
    
    jint available = count - pos;
    return NATIVE_RETURN_INT(available > 0 ? available : 0);
}

/* Class.newInstance() - create a new instance of the class */
static JavaValue native_class_newInstance(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    
    /* args[0] is the Class object (JavaClass*) */
    JavaClass* clazz = (JavaClass*)args[0].ref;
    
    if (!clazz) {
        CLASS_DEBUG("newInstance: clazz is NULL");
        return NATIVE_RETURN_NULL();
    }
    
    CLASS_DEBUG("newInstance: creating instance of %s", clazz->class_name);
    
    /* Check if class is abstract or interface */
    if (clazz->access_flags & (ACC_ABSTRACT | ACC_INTERFACE)) {
        CLASS_DEBUG("newInstance: cannot instantiate abstract class or interface %s", clazz->class_name);
        return NATIVE_RETURN_NULL();
    }
    
    /* Create new instance */
    JavaObject* obj = jvm_new_object(jvm, clazz);
    if (!obj) {
        CLASS_DEBUG("newInstance: failed to create object for %s", clazz->class_name);
        return NATIVE_RETURN_NULL();
    }
    
    /* Call default constructor if it exists */
    JavaMethod* constructor = jvm_resolve_method(jvm, clazz, "<init>", "()V");
    if (constructor) {
        CLASS_DEBUG("newInstance: calling default constructor for %s", clazz->class_name);
        JavaValue ctor_args[1];
        ctor_args[0].ref = obj;
        JavaValue result;
        execute_method(jvm, thread, constructor, ctor_args, &result);
    } else {
        CLASS_DEBUG("newInstance: no default constructor for %s (using default init)", clazz->class_name);
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* Class.isArray() - check if class is an array class */
static JavaValue native_class_isArray(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    
    JavaClass* clazz = (JavaClass*)args[0].ref;
    if (!clazz || !clazz->class_name) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Array class names start with '[' */
    return NATIVE_RETURN_INT(clazz->class_name[0] == '[' ? 1 : 0);
}

/* Class.isAssignableFrom(Class) - check if this class is assignable from another */
static JavaValue native_class_isAssignableFrom(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    
    JavaClass* this_class = (JavaClass*)args[0].ref;
    JavaClass* other_class = (JavaClass*)args[1].ref;
    
    if (!this_class || !other_class) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Simple check: if classes are the same */
    if (this_class == other_class) {
        return NATIVE_RETURN_INT(1);
    }
    
    /* Check if other_class extends this_class */
    JavaClass* current = other_class;
    while (current) {
        if (current == this_class) {
            return NATIVE_RETURN_INT(1);
        }
        current = current->super_class;
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Class.getSuperclass() - get the superclass */
static JavaValue native_class_getSuperclass(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    
    JavaClass* clazz = (JavaClass*)args[0].ref;
    if (!clazz) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Return superclass (for Object, this will be NULL) */
    return NATIVE_RETURN_OBJECT(clazz->super_class);
}

/* Class.getComponentType() - get component type for array classes */
static JavaValue native_class_getComponentType(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    
    JavaClass* clazz = (JavaClass*)args[0].ref;
    if (!clazz || !clazz->class_name || clazz->class_name[0] != '[') {
        return NATIVE_RETURN_NULL();
    }
    
    /* Get component type name (skip the '[' prefix) */
    const char* component_name = clazz->class_name + 1;
    
    /* Handle primitive array types */
    if (component_name[0] != 'L') {
        /* Primitive type - return special class */
        JavaClass* component_class = NULL;
        switch (component_name[0]) {
            case 'Z': component_class = jvm_load_class(jvm, "java/lang/Boolean"); break;
            case 'B': component_class = jvm_load_class(jvm, "java/lang/Byte"); break;
            case 'C': component_class = jvm_load_class(jvm, "java/lang/Character"); break;
            case 'S': component_class = jvm_load_class(jvm, "java/lang/Short"); break;
            case 'I': component_class = jvm_load_class(jvm, "java/lang/Integer"); break;
            case 'J': component_class = jvm_load_class(jvm, "java/lang/Long"); break;
            case 'F': component_class = jvm_load_class(jvm, "java/lang/Float"); break;
            case 'D': component_class = jvm_load_class(jvm, "java/lang/Double"); break;
        }
        return NATIVE_RETURN_OBJECT(component_class);
    }
    
    /* Object array - component name is like "Ljava/lang/Object;" */
    /* Skip 'L' and ';' */
    char* name_copy = strdup(component_name + 1);
    size_t len = strlen(name_copy);
    if (len > 0 && name_copy[len - 1] == ';') {
        name_copy[len - 1] = '\0';
    }
    
    JavaClass* component_class = jvm_load_class(jvm, name_copy);
    free(name_copy);
    
    return NATIVE_RETURN_OBJECT(component_class);
}

void init_java_lang_class(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;", native_class_forName},
        {"java/lang/Class", "getName", "()Ljava/lang/String;", native_class_getName},
        {"java/lang/Class", "isInstance", "(Ljava/lang/Object;)Z", native_class_isInstance},
        {"java/lang/Class", "getResourceAsStream", "(Ljava/lang/String;)Ljava/io/InputStream;", native_class_getResourceAsStream},
        {"java/lang/Class", "newInstance", "()Ljava/lang/Object;", native_class_newInstance},
        {"java/lang/Class", "isArray", "()Z", native_class_isArray},
        {"java/lang/Class", "isAssignableFrom", "(Ljava/lang/Class;)Z", native_class_isAssignableFrom},
        {"java/lang/Class", "getSuperclass", "()Ljava/lang/Class;", native_class_getSuperclass},
        {"java/lang/Class", "getComponentType", "()Ljava/lang/Class;", native_class_getComponentType},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/* ByteArrayInputStream native methods */
void init_java_io_bytearrayinputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/ByteArrayInputStream", "<init>", "([B)V", native_bytearrayinputstream_init_bytes},
        {"java/io/ByteArrayInputStream", "<init>", "([BII)V", native_bytearrayinputstream_init_bytes_offset},
        {"java/io/ByteArrayInputStream", "read", "()I", native_bytearrayinputstream_read},
        {"java/io/ByteArrayInputStream", "read", "([B)I", native_bytearrayinputstream_read_array_full},
        {"java/io/ByteArrayInputStream", "read", "([BII)I", native_bytearrayinputstream_read_array},
        {"java/io/ByteArrayInputStream", "available", "()I", native_bytearrayinputstream_available},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.io.ByteArrayOutputStream native methods
 */

/* ByteArrayOutputStream buffer is stored in a native peer pointer */

static JavaValue native_bytearrayoutputstream_init(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Allocate a dynamic buffer - start with 32 bytes */
    int capacity = 32;
    
    /* Create a Java byte array to hold our data */
    JavaArray* buf_array = jvm_new_array(jvm, T_BYTE, capacity);
    if (buf_array) {
        /* ИСПРАВЛЕНО: Используем native_set_field_value */
        JavaValue buf_val = { .ref = buf_array };
        JavaValue count_val = { .i = 0 };
        native_set_field_value(obj, "buf", buf_val);
        native_set_field_value(obj, "count", count_val);
    }
    
    fprintf(stderr, "[BAOS] <init>: obj=%p, buffer capacity=%d\n", (void*)obj, capacity);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_bytearrayoutputstream_tobytearray(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* buf_array = (JavaArray*)native_get_field_value(obj, "buf").ref;
    jint count = native_get_field_value(obj, "count").i;
    
    if (!buf_array || count <= 0) {
        /* Return empty array */
        JavaArray* empty = jvm_new_array(jvm, T_BYTE, 0);
        return NATIVE_RETURN_OBJECT(empty);
    }
    
    /* Create result array with actual size */
    JavaArray* result = jvm_new_array(jvm, T_BYTE, count);
    if (result && buf_array) {
        void* src_data = array_data(buf_array);
        void* dst_data = array_data(result);
        if (src_data && dst_data) {
            memcpy(dst_data, src_data, count);
        }
    }
    
    fprintf(stderr, "[BAOS] toByteArray: obj=%p, count=%d\n", (void*)obj, count);
    return NATIVE_RETURN_OBJECT(result);
}

static JavaValue native_bytearrayoutputstream_write(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint b = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get/set_field_value */
    JavaArray* buf_array = (JavaArray*)native_get_field_value(obj, "buf").ref;
    jint count = native_get_field_value(obj, "count").i;
    
    /* Need to expand buffer? */
    if (!buf_array || count >= (jint)buf_array->length) {
        int new_capacity = buf_array ? buf_array->length * 2 : 32;
        if (new_capacity < count + 1) new_capacity = count + 32;
        
        JavaArray* new_array = jvm_new_array(jvm, T_BYTE, new_capacity);
        if (new_array) {
            void* src = array_data(buf_array);
            void* dst = array_data(new_array);
            if (buf_array && src && dst && count > 0) {
                memcpy(dst, src, count);
            }
            buf_array = new_array;
            JavaValue buf_val = { .ref = buf_array };
            native_set_field_value(obj, "buf", buf_val);
        }
    }
    
    /* Write byte */
    if (buf_array) {
        uint8_t* data = (uint8_t*)array_data(buf_array);
        if (data) {
            data[count] = (uint8_t)b;
            count++;
        
            /* Update count field */
            JavaValue count_val = { .i = count };
            native_set_field_value(obj, "count", count_val);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_bytearrayoutputstream_write_array(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint off = args[2].i;
    jint len = args[3].i;
    
    if (!obj || !data) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get/set_field_value */
    JavaArray* buf_array = (JavaArray*)native_get_field_value(obj, "buf").ref;
    jint count = native_get_field_value(obj, "count").i;
    
    /* Need to expand buffer? */
    int needed = count + len;
    if (!buf_array || needed > (jint)buf_array->length) {
        int new_capacity = buf_array ? buf_array->length * 2 : 32;
        while (new_capacity < needed) new_capacity *= 2;
        
        JavaArray* new_array = jvm_new_array(jvm, T_BYTE, new_capacity);
        if (new_array) {
            void* src = array_data(buf_array);
            void* dst = array_data(new_array);
            if (buf_array && src && dst && count > 0) {
                memcpy(dst, src, count);
            }
            buf_array = new_array;
            JavaValue buf_val = { .ref = buf_array };
            native_set_field_value(obj, "buf", buf_val);
        }
    }
    
    /* Write bytes */
    if (buf_array && data) {
        uint8_t* dst = (uint8_t*)array_data(buf_array);
        uint8_t* src = (uint8_t*)array_data(data);
        if (dst && src) {
            memcpy(dst + count, src + off, len);
            count += len;
        
            JavaValue count_val = { .i = count };
            native_set_field_value(obj, "count", count_val);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

void init_java_io_bytearrayoutputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/ByteArrayOutputStream", "<init>", "()V", native_bytearrayoutputstream_init},
        {"java/io/ByteArrayOutputStream", "toByteArray", "()[B", native_bytearrayoutputstream_tobytearray},
        {"java/io/ByteArrayOutputStream", "write", "(I)V", native_bytearrayoutputstream_write},
        {"java/io/ByteArrayOutputStream", "write", "([BII)V", native_bytearrayoutputstream_write_array},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.io.DataOutputStream native methods
 * DataOutputStream wraps an OutputStream and writes data to it
 */

/* Forward declaration */
static void dos_write_byte(JVM* jvm, JavaObject* dos_obj, uint8_t b);
static void dos_write_bytes(JVM* jvm, JavaObject* dos_obj, uint8_t* data, int len);

static JavaValue native_dataoutputstream_init(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* out = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue out_val = { .ref = out };
    native_set_field_value(obj, "out", out_val);
    
    fprintf(stderr, "[DOS] <init>: obj=%p, out=%p\n", (void*)obj, (void*)out);
    return NATIVE_RETURN_VOID();
}

/* Write a single byte to the underlying output stream */
static void dos_write_byte(JVM* jvm, JavaObject* dos_obj, uint8_t b) {
    if (!dos_obj) return;
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaObject* out = (JavaObject*)native_get_field_value(dos_obj, "out").ref;
    
    if (!out) return;
    
    /* Check if out is a ByteArrayOutputStream */
    JavaClass* out_class = out->header.clazz;
    if (out_class && out_class->class_name && 
        strcmp(out_class->class_name, "java/io/ByteArrayOutputStream") == 0) {
        
        /* ИСПРАВЛЕНО: Используем native_get/set_field_value */
        JavaArray* buf_array = (JavaArray*)native_get_field_value(out, "buf").ref;
        jint count = native_get_field_value(out, "count").i;
        
        /* Expand buffer if needed */
        if (!buf_array || count >= (jint)buf_array->length) {
            int new_capacity = buf_array ? buf_array->length * 2 : 32;
            JavaArray* new_array = jvm_new_array(jvm, T_BYTE, new_capacity);
            if (new_array) {
                void* src = array_data(buf_array);
                void* dst = array_data(new_array);
                if (buf_array && src && dst && count > 0) {
                    memcpy(dst, src, count);
                }
                buf_array = new_array;
                JavaValue buf_val = { .ref = buf_array };
                native_set_field_value(out, "buf", buf_val);
            }
        }
        
        /* Write byte */
        if (buf_array) {
            uint8_t* data = (uint8_t*)array_data(buf_array);
            if (data) {
                data[count] = b;
                count++;
                JavaValue count_val = { .i = count };
                native_set_field_value(out, "count", count_val);
            }
        }
    }
}

static void dos_write_bytes(JVM* jvm, JavaObject* dos_obj, uint8_t* data, int len) {
    for (int i = 0; i < len; i++) {
        dos_write_byte(jvm, dos_obj, data[i]);
    }
}

static JavaValue native_dataoutputstream_write(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint b = args[1].i;
    
    dos_write_byte(jvm, obj, (uint8_t)b);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writeint(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint v = args[1].i;
    
    uint8_t bytes[4];
    bytes[0] = (v >> 24) & 0xFF;
    bytes[1] = (v >> 16) & 0xFF;
    bytes[2] = (v >> 8) & 0xFF;
    bytes[3] = v & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 4);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writelong(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong v = args[1].j;
    
    uint8_t bytes[8];
    bytes[0] = (v >> 56) & 0xFF;
    bytes[1] = (v >> 48) & 0xFF;
    bytes[2] = (v >> 40) & 0xFF;
    bytes[3] = (v >> 32) & 0xFF;
    bytes[4] = (v >> 24) & 0xFF;
    bytes[5] = (v >> 16) & 0xFF;
    bytes[6] = (v >> 8) & 0xFF;
    bytes[7] = v & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 8);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writebyte(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint v = args[1].i;
    
    dos_write_byte(jvm, obj, (uint8_t)v);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writeshort(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint v = args[1].i;
    
    uint8_t bytes[2];
    bytes[0] = (v >> 8) & 0xFF;
    bytes[1] = v & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 2);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writefloat(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jfloat v = args[1].f;
    
    /* Convert float to int bits, then write as 4 bytes */
    jint bits = *(jint*)&v;
    
    uint8_t bytes[4];
    bytes[0] = (bits >> 24) & 0xFF;
    bytes[1] = (bits >> 16) & 0xFF;
    bytes[2] = (bits >> 8) & 0xFF;
    bytes[3] = bits & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 4);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writedouble(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jdouble v = args[1].d;
    
    /* Convert double to long bits, then write as 8 bytes */
    jlong bits = *(jlong*)&v;
    
    uint8_t bytes[8];
    bytes[0] = (bits >> 56) & 0xFF;
    bytes[1] = (bits >> 48) & 0xFF;
    bytes[2] = (bits >> 40) & 0xFF;
    bytes[3] = (bits >> 32) & 0xFF;
    bytes[4] = (bits >> 24) & 0xFF;
    bytes[5] = (bits >> 16) & 0xFF;
    bytes[6] = (bits >> 8) & 0xFF;
    bytes[7] = bits & 0xFF;
    
    dos_write_bytes(jvm, obj, bytes, 8);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_writebytes(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaString* str = (JavaString*)args[1].ref;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    /* Write string as bytes (high byte discarded) */
    const jchar* chars = string_chars(str);
    if (chars) {
        for (int i = 0; i < str->length; i++) {
            uint16_t ch = chars[i];
            dos_write_byte(jvm, obj, ch & 0xFF);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_flush(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op for now */
    return NATIVE_RETURN_VOID();
}

static JavaValue native_dataoutputstream_close(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op for now */
    return NATIVE_RETURN_VOID();
}

void init_java_io_dataoutputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/DataOutputStream", "<init>", "(Ljava/io/OutputStream;)V", native_dataoutputstream_init},
        {"java/io/DataOutputStream", "write", "(I)V", native_dataoutputstream_write},
        {"java/io/DataOutputStream", "writeInt", "(I)V", native_dataoutputstream_writeint},
        {"java/io/DataOutputStream", "writeLong", "(J)V", native_dataoutputstream_writelong},
        {"java/io/DataOutputStream", "writeByte", "(I)V", native_dataoutputstream_writebyte},
        {"java/io/DataOutputStream", "writeShort", "(I)V", native_dataoutputstream_writeshort},
        {"java/io/DataOutputStream", "writeFloat", "(F)V", native_dataoutputstream_writefloat},
        {"java/io/DataOutputStream", "writeDouble", "(D)V", native_dataoutputstream_writedouble},
        {"java/io/DataOutputStream", "writeBytes", "(Ljava/lang/String;)V", native_dataoutputstream_writebytes},
        {"java/io/DataOutputStream", "flush", "()V", native_dataoutputstream_flush},
        {"java/io/DataOutputStream", "close", "()V", native_dataoutputstream_close},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * DataInputStream native methods
 */

static JavaValue native_datainputstream_read_byte_array(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    
    if (!obj || !buffer) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value для доступа к полю "in" */
    JavaObject* in_stream = (JavaObject*)native_get_field_value(obj, "in").ref;
    
    if (!in_stream) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Check if it's a ByteArrayInputStream */
    JavaClass* in_class = in_stream->header.clazz;
    if (in_class && in_class->class_name && 
        strcmp(in_class->class_name, "java/io/ByteArrayInputStream") == 0) {
        
        /* ИСПРАВЛЕНО: Используем native_get_field_value */
        JavaArray* buf = (JavaArray*)native_get_field_value(in_stream, "buf").ref;
        jint pos = native_get_field_value(in_stream, "pos").i;
        jint count = native_get_field_value(in_stream, "count").i;
        
        if (!buf || pos >= count) {
            return NATIVE_RETURN_INT(-1);
        }
        
        /* Read available bytes into buffer */
        int available = count - pos;
        int to_read = buffer->length < available ? buffer->length : available;
        
        uint8_t* src = (uint8_t*)array_data(buf);
        uint8_t* dst = (uint8_t*)array_data(buffer);
        
        if (src && dst) {
            memcpy(dst, src + pos, to_read);
            
            /* ИСПРАВЛЕНО: Используем native_set_field_value */
            JavaValue new_pos = { .i = pos + to_read };
            native_set_field_value(in_stream, "pos", new_pos);
        }
        
        return NATIVE_RETURN_INT(to_read);
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* ИСПРАВЛЕНО: find_field_index возвращает индекс в clazz->fields[],
 * что НЕ является правильным слотом для obj->fields[].
 * Используйте native_get_field_slot() вместо этой функции.
 * Эта функция оставлена для совместимости, но помечена как устаревшая. */
__attribute__((deprecated("Use native_get_field_slot instead")))
static int find_field_index(JavaClass* clazz, const char* name) {
    if (!clazz || !name) return -1;
    
    /* Check this class */
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, name) == 0) {
                return i;
            }
        }
    }
    
    /* Check superclass */
    if (clazz->super_class) {
        return find_field_index(clazz->super_class, name);
    }
    
    return -1;
}

/* DataInputStream.<init>(InputStream) - constructor */
static JavaValue native_datainputstream_init(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* in_stream = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue in_val = { .ref = in_stream };
    native_set_field_value(obj, "in", in_val);
    
    fprintf(stderr, "[DataInputStream] <init>: obj=%p, in=%p\n", 
            (void*)obj, (void*)in_stream);
    
    return NATIVE_RETURN_VOID();
}

/* Helper to read a single byte from underlying InputStream with proper position tracking */
static jint dis_read_byte(JVM* jvm, JavaObject* dis_obj) {
    (void)jvm;
    if (!dis_obj) {
        fprintf(stderr, "[DIS] dis_read_byte: dis_obj is NULL\n");
        return -1;
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value для доступа к полю "in" */
    JavaObject* in_stream = (JavaObject*)native_get_field_value(dis_obj, "in").ref;
    
    if (!in_stream) {
        fprintf(stderr, "[DIS] No 'in' field found!\n");
        return -1;
    }
    
    /* Check if it's a ByteArrayInputStream */
    JavaClass* in_class = in_stream->header.clazz;
    if (!in_class || !in_class->class_name ||
        strcmp(in_class->class_name, "java/io/ByteArrayInputStream") != 0) {
        fprintf(stderr, "[DIS] Underlying stream is not ByteArrayInputStream: %s\n",
                in_class ? in_class->class_name : "NULL");
        return -1;
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* buf = (JavaArray*)native_get_field_value(in_stream, "buf").ref;
    jint pos = native_get_field_value(in_stream, "pos").i;
    jint count = native_get_field_value(in_stream, "count").i;
    
    if (!buf) {
        fprintf(stderr, "[DIS] ERROR: buf is NULL!\n");
        return -1;
    }
    
    if (pos >= count) {
        fprintf(stderr, "[DIS] EOF reached: pos=%d >= count=%d\n", pos, count);
        return -1;  /* EOF */
    }
    
    /* Read single byte */
    uint8_t* data = (uint8_t*)array_data(buf);
    jbyte val = (jbyte)data[pos];
    
    /* CRITICAL: Update position in the underlying stream */
    JavaValue new_pos = { .i = pos + 1 };
    native_set_field_value(in_stream, "pos", new_pos);
    
    return val & 0xFF;
}

/* DataInputStream.read() - reads a single byte */
static JavaValue native_datainputstream_read(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    jint val = dis_read_byte(jvm, obj);
    
    if (val < 0) {
        return NATIVE_RETURN_INT(-1);  /* EOF */
    }
    
    return NATIVE_RETURN_INT(val);
}

/* DataInputStream.read(byte[]) - reads into byte array */
static JavaValue native_datainputstream_read_array(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    
    if (!obj || !buffer) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    uint8_t* data = (uint8_t*)array_data(buffer);
    int max_read = buffer->length;
    int bytes_read = 0;
    
    for (int i = 0; i < max_read; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            break;
        }
        data[i] = (uint8_t)b;
        bytes_read++;
    }
    
    return NATIVE_RETURN_INT(bytes_read > 0 ? bytes_read : -1);
}

/* DataInputStream.read(byte[], int, int) - reads with offset/length */
static JavaValue native_datainputstream_read_offset(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    if (!obj || !buffer) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Bounds checking */
    if (offset < 0 || length < 0 || offset + length > (jint)buffer->length) {
        native_throw_aioobe(jvm, thread, offset);
        return NATIVE_RETURN_INT(-1);
    }
    
    uint8_t* data = (uint8_t*)array_data(buffer);
    int bytes_read = 0;
    
    for (int i = 0; i < length; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            break;
        }
        data[offset + i] = (uint8_t)b;
        bytes_read++;
    }
    
    return NATIVE_RETURN_INT(bytes_read > 0 ? bytes_read : -1);
}

/* DataInputStream.skip(int) - skips bytes */
static JavaValue native_datainputstream_skip(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong n = args[1].j;
    
    if (!obj || n <= 0) {
        return NATIVE_RETURN_LONG(0);
    }
    
    long skipped = 0;
    for (int i = 0; i < n; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) break;
        skipped++;
    }
    
    return NATIVE_RETURN_LONG(skipped);
}

/* DataInputStream.available() - returns bytes available */
static JavaValue native_datainputstream_available(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaObject* in_stream = (JavaObject*)native_get_field_value(obj, "in").ref;
    
    if (!in_stream) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Check if it's ByteArrayInputStream */
    JavaClass* in_class = in_stream->header.clazz;
    if (in_class && in_class->class_name && 
        strcmp(in_class->class_name, "java/io/ByteArrayInputStream") == 0) {
        
        /* ИСПРАВЛЕНО: Используем native_get_field_value */
        jint pos = native_get_field_value(in_stream, "pos").i;
        jint count = native_get_field_value(in_stream, "count").i;
        return NATIVE_RETURN_INT(count - pos);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* DataInputStream.close() */
static JavaValue native_datainputstream_close(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Nothing to do - underlying stream will be GC'd */
    fprintf(stderr, "[DataInputStream] close()\n");
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.readBoolean() */
static JavaValue native_datainputstream_readBoolean(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    jint b = dis_read_byte(jvm, obj);
    if (b < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT(b != 0 ? 1 : 0);
}

/* DataInputStream.readUnsignedShort() */
static JavaValue native_datainputstream_readUnsignedShort(JVM* jvm, JavaThread* thread,
                                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    jint b1 = dis_read_byte(jvm, obj);
    jint b2 = dis_read_byte(jvm, obj);
    
    if (b1 < 0 || b2 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT((b1 << 8) | b2);
}

/* DataInputStream.readChar() */
static JavaValue native_datainputstream_readChar(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    jint b1 = dis_read_byte(jvm, obj);
    jint b2 = dis_read_byte(jvm, obj);
    
    if (b1 < 0 || b2 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT((b1 << 8) | b2);
}

/* DataInputStream.readUTF() - reads a UTF-8 encoded string */
static JavaValue native_datainputstream_readUTF(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Read length (unsigned short) */
    jint b1 = dis_read_byte(jvm, obj);
    jint b2 = dis_read_byte(jvm, obj);
    
    if (b1 < 0 || b2 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    jint utf_length = (b1 << 8) | b2;
    
    if (utf_length == 0) {
        JavaString* empty = jvm_new_string(jvm, "");
        return NATIVE_RETURN_OBJECT(empty);
    }
    
    /* Read UTF-8 bytes - allocate extra byte for null terminator */
    uint8_t* utf_bytes = (uint8_t*)malloc(utf_length + 1);
    if (!utf_bytes) {
        native_throw_oome(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    int bytes_read = 0;
    for (int i = 0; i < utf_length; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            free(utf_bytes);
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_NULL();
        }
        utf_bytes[i] = (uint8_t)b;
        bytes_read++;
    }
    
    /* Null-terminate the string! */
    utf_bytes[utf_length] = '\0';
    
    /* Convert to Java String */
    JavaString* str = jvm_new_string(jvm, (char*)utf_bytes);
    free(utf_bytes);
    
    return NATIVE_RETURN_OBJECT(str);
}

/* DataInputStream.readUTF(DataInput) - static version */
static JavaValue native_datainputstream_readUTF_static(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)arg_count;
    /* This is a static method that takes a DataInput */
    JavaObject* input = (JavaObject*)args[0].ref;
    
    if (!input) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Delegate to readUTF on the DataInput object */
    /* But since DataInput is an interface, we need to call the method dynamically */
    /* For simplicity, we'll assume it's a DataInputStream */
    
    /* Reuse the instance method implementation */
    JavaValue new_args[1] = { { .ref = input } };
    return native_datainputstream_readUTF(jvm, thread, new_args, 1);
}

/* DataInputStream.mark(int) - mark current position */
static JavaValue native_datainputstream_mark(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* TODO: Implement mark/reset if needed */
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.reset() - reset to marked position */
static JavaValue native_datainputstream_reset(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* TODO: Implement mark/reset if needed */
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.markSupported() */
static JavaValue native_datainputstream_markSupported(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* ByteArrayInputStream supports mark/reset */
    return NATIVE_RETURN_INT(1);
}

/* DataInputStream.readByte() - reads a single byte */
static JavaValue native_datainputstream_readbyte(JVM* jvm, JavaThread* thread,
JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jint val = dis_read_byte(jvm, obj);
    
    //fprintf(stderr, "[DIS.readByte] Result: %d\n", val);
    
    if (val < 0) {
        /* Throw EOFException - критически важно для остановки цикла! */
        fprintf(stderr, "[DIS.readByte] Throwing EOFException\n");
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        
        /* Return zero value but exception will be detected by native_call() */
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT((jbyte)val);
}

/* DataInputStream.readUnsignedByte() - reads an unsigned byte */
static JavaValue native_datainputstream_readunsignedbyte(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jint val = dis_read_byte(jvm, obj);
    if (val < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT(val);
}

/* DataInputStream.readShort() - reads 2 bytes as short */
static JavaValue native_datainputstream_readshort(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    jint b1 = dis_read_byte(jvm, obj);
    jint b2 = dis_read_byte(jvm, obj);
    
    if (b1 < 0 || b2 < 0) {
        fprintf(stderr, "[DataInputStream] readShort: EOF reached\n");
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jshort val = (jshort)((b1 << 8) | b2);
    return NATIVE_RETURN_INT(val);
}

/* DataInputStream.readInt() - reads 4 bytes as int */
static JavaValue native_datainputstream_readint(JVM* jvm, JavaThread* thread,
JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    /* Read 4 bytes sequentially, each call advances position */
    jint b1 = dis_read_byte(jvm, obj);
    if (b1 < 0) {
        /* Throw EOFException на первом байте */
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jint b2 = dis_read_byte(jvm, obj);
    jint b3 = dis_read_byte(jvm, obj);
    jint b4 = dis_read_byte(jvm, obj);
    
    if (b2 < 0 || b3 < 0 || b4 < 0) {
        jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(0);
    }
    
    jint val = (b1 << 24) | (b2 << 16) | (b3 << 8) | b4;
    return NATIVE_RETURN_INT(val);
}


/* DataInputStream.readLong() - reads 8 bytes as long */
static JavaValue native_datainputstream_readlong(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_LONG(0);
    }
    
    jlong val = 0;
    for (int i = 0; i < 8; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            fprintf(stderr, "[DataInputStream] readLong: EOF reached at byte %d\n", i);
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_LONG(0);
        }
        val = (val << 8) | b;
    }
    
    return NATIVE_RETURN_LONG(val);
}

/* DataInputStream.readFully([B)V - reads bytes to fill array */
static JavaValue native_datainputstream_readfully(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    
    if (!obj || !buffer) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    uint8_t* data = (uint8_t*)array_data(buffer);
    if (!data) {
        return NATIVE_RETURN_VOID();
    }
    
    for (int i = 0; i < (int)buffer->length; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            fprintf(stderr, "[DataInputStream] readFully: EOF reached at %d\n", i);
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_VOID();
        }
        data[i] = (uint8_t)b;
    }
    
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.readFully([BII)V - with bounds checking */
static JavaValue native_datainputstream_readfully_offset(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* buffer = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint len = args[3].i;
    
    if (!obj || !buffer) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Bounds checking */
    if (offset < 0 || len < 0 || offset + len > (jint)buffer->length) {
        native_throw_aioobe(jvm, thread, offset);
        return NATIVE_RETURN_VOID();
    }
    
    uint8_t* data = (uint8_t*)array_data(buffer);
    if (!data) {
        return NATIVE_RETURN_VOID();
    }
    
    for (int i = 0; i < len; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            /* Throw EOFException if we couldn't read all bytes */
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_VOID();
        }
        data[offset + i] = (uint8_t)b;
    }
    
    return NATIVE_RETURN_VOID();
}

/* DataInputStream.skipBytes(int) - skips n bytes */
static JavaValue native_datainputstream_skipbytes(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint n = args[1].i;
    
    if (!obj || n <= 0) {
        return NATIVE_RETURN_INT(0);
    }
    
    int skipped = 0;
    for (int i = 0; i < n; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) break;
        skipped++;
    }
    
    return NATIVE_RETURN_INT(skipped);
}

/* DataInputStream.readFloat() */
static JavaValue native_datainputstream_readfloat(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    /* Read 4 bytes as int, then convert to float */
    jint bits = 0;
    for (int i = 0; i < 4; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_FLOAT(0.0f);
        }
        bits = (bits << 8) | b;
    }
    
    jfloat val = *(jfloat*)&bits;
    return NATIVE_RETURN_FLOAT(val);
}

/* DataInputStream.readDouble() */
static JavaValue native_datainputstream_readdouble(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    /* Read 8 bytes as long, then convert to double */
    jlong bits = 0;
    for (int i = 0; i < 8; i++) {
        jint b = dis_read_byte(jvm, obj);
        if (b < 0) {
            jvm_throw_by_name(jvm, "java/io/EOFException", NULL);
            thread->pending_exception = jvm_exception_pending(jvm);
            return NATIVE_RETURN_DOUBLE(0.0);
        }
        bits = (bits << 8) | b;
    }
    
    jdouble val = *(jdouble*)&bits;
    return NATIVE_RETURN_DOUBLE(val);
}

void init_java_io_datainputstream(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/DataInputStream", "<init>", "(Ljava/io/InputStream;)V", native_datainputstream_init},
        {"java/io/DataInputStream", "read", "()I", native_datainputstream_read},
        {"java/io/DataInputStream", "read", "([B)I", native_datainputstream_read_array},
        {"java/io/DataInputStream", "read", "([BII)I", native_datainputstream_read_offset},
        {"java/io/DataInputStream", "readByte", "()B", native_datainputstream_readbyte},
        {"java/io/DataInputStream", "readUnsignedByte", "()I", native_datainputstream_readunsignedbyte},
        {"java/io/DataInputStream", "readShort", "()S", native_datainputstream_readshort},
        {"java/io/DataInputStream", "readUnsignedShort", "()I", native_datainputstream_readUnsignedShort},
        {"java/io/DataInputStream", "readChar", "()C", native_datainputstream_readChar},
        {"java/io/DataInputStream", "readInt", "()I", native_datainputstream_readint},
        {"java/io/DataInputStream", "readLong", "()J", native_datainputstream_readlong},
        {"java/io/DataInputStream", "readFloat", "()F", native_datainputstream_readfloat},
        {"java/io/DataInputStream", "readDouble", "()D", native_datainputstream_readdouble},
        {"java/io/DataInputStream", "readBoolean", "()Z", native_datainputstream_readBoolean},
        {"java/io/DataInputStream", "readUTF", "()Ljava/lang/String;", native_datainputstream_readUTF},
        {"java/io/DataInputStream", "readUTF", "(Ljava/io/DataInput;)Ljava/lang/String;", native_datainputstream_readUTF_static},
        {"java/io/DataInputStream", "readFully", "([B)V", native_datainputstream_readfully},
        {"java/io/DataInputStream", "readFully", "([BII)V", native_datainputstream_readfully_offset},
        {"java/io/DataInputStream", "skipBytes", "(I)I", native_datainputstream_skipbytes},
        {"java/io/DataInputStream", "skip", "(J)J", native_datainputstream_skip},
        {"java/io/DataInputStream", "available", "()I", native_datainputstream_available},
        {"java/io/DataInputStream", "close", "()V", native_datainputstream_close},
        {"java/io/DataInputStream", "mark", "(I)V", native_datainputstream_mark},
        {"java/io/DataInputStream", "reset", "()V", native_datainputstream_reset},
        {"java/io/DataInputStream", "markSupported", "()Z", native_datainputstream_markSupported},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/io/DataInputStream native methods (%zu)", 
            sizeof(methods) / sizeof(methods[0]));
}

/*
 * com.nokia.mid.sound.Sound native methods
 * Nokia's sound API for playing audio
 */

/* Sound stores audio data and native handle */
static JavaValue native_sound_init(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint type = args[2].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue data_val = { .ref = data };
    JavaValue type_val = { .i = type };
    native_set_field_value(obj, "data", data_val);
    native_set_field_value(obj, "soundType", type_val);
    
    fprintf(stderr, "[Sound] <init>: obj=%p, data=%p, type=%d\n", (void*)obj, (void*)data, type);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_play(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* data = (JavaArray*)native_get_field_value(obj, "data").ref;
    
    if (data && data->length > 0) {
        /* For now, just log - actual audio playback would require audio library */
        fprintf(stderr, "[Sound] play: %d bytes of audio data\n", data->length);
        
        /* TODO: Implement actual audio playback using SDL audio or similar */
        /* The data is likely AMR format which needs decoding */
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sound.play(int) - play with loop count */
static JavaValue native_sound_play_loop(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint loop = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* data = (JavaArray*)native_get_field_value(obj, "data").ref;
    
    if (data && data->length > 0) {
        fprintf(stderr, "[Sound] play(loop=%d): %d bytes of audio data\n", loop, data->length);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_stop(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Sound] stop: obj=%p\n", (void*)obj);
    /* TODO: Stop audio playback */
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_getstate(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* Return SOUND_PLAYING = 1, SOUND_STOPPED = 0 */
    return NATIVE_RETURN_INT(0);  /* Always return stopped for now */
}

static JavaValue native_sound_setgain(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint gain = args[1].i;
    
    fprintf(stderr, "[Sound] setGain: obj=%p, gain=%d\n", (void*)obj, gain);
    /* TODO: Set volume */
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sound_release(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Sound] release: obj=%p\n", (void*)obj);
    /* TODO: Release audio resources */
    
    return NATIVE_RETURN_VOID();
}

/* Sound.getGain() - returns current gain level */
static JavaValue native_sound_getGain(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    (void)args;
    /* Return default gain (100 = max) */
    return NATIVE_RETURN_INT(100);
}

/* Sound.resume() - resume playing */
static JavaValue native_sound_resume(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Sound] resume: obj=%p\n", (void*)obj);
    return NATIVE_RETURN_VOID();
}

/* Sound.getDuration() - get duration in milliseconds */
static JavaValue native_sound_getDuration(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    (void)args;
    /* Return -1 to indicate unknown duration */
    return NATIVE_RETURN_INT(-1);
}

/* Sound.setSoundListener(SoundListener) - set event listener */
static JavaValue native_sound_setSoundListener(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* listener = (JavaObject*)args[1].ref;
    
    fprintf(stderr, "[Sound] setSoundListener: obj=%p, listener=%p\n", (void*)obj, (void*)listener);
    return NATIVE_RETURN_VOID();
}

/* Sound.init(byte[], int, int) - initialize with data, type and frames */
static JavaValue native_sound_init_frames(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint type = args[2].i;
    jint frames = args[3].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue data_val = { .ref = data };
    JavaValue type_val = { .i = type };
    native_set_field_value(obj, "data", data_val);
    native_set_field_value(obj, "soundType", type_val);
    
    (void)frames;
    fprintf(stderr, "[Sound] <init>([BII): obj=%p, data=%p, type=%d, frames=%d\n", 
            (void*)obj, (void*)data, type, frames);
    return NATIVE_RETURN_VOID();
}

/* Sound default constructor ()V */
static JavaValue native_sound_init_default(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue null_val = { .ref = NULL };
    JavaValue zero_val = { .i = 0 };
    native_set_field_value(obj, "data", null_val);
    native_set_field_value(obj, "soundType", zero_val);
    
    fprintf(stderr, "[Sound] <init>(): obj=%p (default constructor)\n", (void*)obj);
    return NATIVE_RETURN_VOID();
}

/* Sound constructor with byte array only ([B)V */
static JavaValue native_sound_init_bytes(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue data_val = { .ref = data };
    JavaValue zero_val = { .i = 0 };
    native_set_field_value(obj, "data", data_val);
    native_set_field_value(obj, "soundType", zero_val);
    
    fprintf(stderr, "[Sound] <init>([B): obj=%p, data=%p\n", (void*)obj, (void*)data);
    return NATIVE_RETURN_VOID();
}

/* Sound constructor with int and long (IJ)V - for tone sounds */
static JavaValue native_sound_init_int_long(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint type = args[1].i;
    jlong data = args[2].j;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue null_val = { .ref = NULL };
    JavaValue type_val = { .i = type };
    native_set_field_value(obj, "data", null_val);
    native_set_field_value(obj, "soundType", type_val);
    
    fprintf(stderr, "[Sound] <init>(IJ): obj=%p, type=%d, data=%ld\n", (void*)obj, type, (long)data);
    return NATIVE_RETURN_VOID();
}

/* Sound constructor with int and double (ID)V - for tone sounds */
static JavaValue native_sound_init_int_double(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint type = args[1].i;
    jdouble data = args[2].d;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue null_val = { .ref = NULL };
    JavaValue type_val = { .i = type };
    native_set_field_value(obj, "data", null_val);
    native_set_field_value(obj, "soundType", type_val);
    
    fprintf(stderr, "[Sound] <init>(ID): obj=%p, type=%d, data=%f\n", (void*)obj, type, data);
    return NATIVE_RETURN_VOID();
}

/* Sound constructor with int only (I)V */
static JavaValue native_sound_init_int(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint type = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue null_val = { .ref = NULL };
    JavaValue type_val = { .i = type };
    native_set_field_value(obj, "data", null_val);
    native_set_field_value(obj, "soundType", type_val);
    
    fprintf(stderr, "[Sound] <init>(I): obj=%p, type=%d\n", (void*)obj, type);
    return NATIVE_RETURN_VOID();
}

void init_nokia_sound(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"com/nokia/mid/sound/Sound", "<init>", "()V", native_sound_init_default},
        {"com/nokia/mid/sound/Sound", "<init>", "([B)V", native_sound_init_bytes},
        {"com/nokia/mid/sound/Sound", "<init>", "([BI)V", native_sound_init},
        {"com/nokia/mid/sound/Sound", "<init>", "([BII)V", native_sound_init_frames},
        {"com/nokia/mid/sound/Sound", "<init>", "(I)V", native_sound_init_int},
        {"com/nokia/mid/sound/Sound", "<init>", "(IJ)V", native_sound_init_int_long},
        {"com/nokia/mid/sound/Sound", "<init>", "(ID)V", native_sound_init_int_double},
        {"com/nokia/mid/sound/Sound", "play", "()V", native_sound_play},
        {"com/nokia/mid/sound/Sound", "play", "(I)V", native_sound_play_loop},
        {"com/nokia/mid/sound/Sound", "stop", "()V", native_sound_stop},
        {"com/nokia/mid/sound/Sound", "getState", "()I", native_sound_getstate},
        {"com/nokia/mid/sound/Sound", "setGain", "(I)V", native_sound_setgain},
        {"com/nokia/mid/sound/Sound", "getGain", "()I", native_sound_getGain},
        {"com/nokia/mid/sound/Sound", "resume", "()V", native_sound_resume},
        {"com/nokia/mid/sound/Sound", "getDuration", "()I", native_sound_getDuration},
        {"com/nokia/mid/sound/Sound", "setSoundListener", "(Lcom/nokia/mid/sound/SoundListener;)V", native_sound_setSoundListener},
        {"com/nokia/mid/sound/Sound", "release", "()V", native_sound_release},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered Nokia Sound native methods (%zu)", sizeof(methods) / sizeof(methods[0]));
}

/*
 * com.nokia.mid.ui.DirectUtils native methods
 * Nokia's utility class for creating images and getting DirectGraphics
 */

/* DirectUtils.createImage(int width, int height) - creates a mutable image */
static JavaValue native_directutils_createImage(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint width = args[0].i;
    jint height = args[1].i;
    
    fprintf(stderr, "[DirectUtils] createImage(%d, %d)\n", width, height);
    
    /* Create Image object using native factory */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        fprintf(stderr, "[DirectUtils] Failed to load Image class\n");
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* image = jvm_new_object(jvm, image_class);
    if (!image) {
        fprintf(stderr, "[DirectUtils] Failed to create Image object\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store dimensions in native peer or fields */
    /* The actual native image creation would happen here */
    
    return NATIVE_RETURN_OBJECT(image);
}

/* DirectUtils.createImage(int width, int height, int color) - creates image with background */
static JavaValue native_directutils_createImage_color(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint width = args[0].i;
    jint height = args[1].i;
    jint color = args[2].i;
    
    fprintf(stderr, "[DirectUtils] createImage(%d, %d, 0x%08X)\n", width, height, color);
    
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* image = jvm_new_object(jvm, image_class);
    return NATIVE_RETURN_OBJECT(image);
}

/* DirectUtils.getDirectGraphics(Graphics g) - returns DirectGraphics adapter */
static JavaValue native_directutils_getDirectGraphics(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* graphics = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[DirectUtils] getDirectGraphics(%p)\n", (void*)graphics);
    
    /* Create DirectGraphics object - for now just return the same graphics object wrapped */
    JavaClass* dg_class = jvm_load_class(jvm, "com/nokia/mid/ui/DirectGraphics");
    if (!dg_class) {
        fprintf(stderr, "[DirectUtils] Failed to load DirectGraphics class\n");
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* dg = jvm_new_object(jvm, dg_class);
    if (dg) {
        /* ИСПРАВЛЕНО: Используем native_set_field_value */
        JavaValue graphics_val = { .ref = graphics };
        native_set_field_value(dg, "graphics", graphics_val);
    }
    
    return NATIVE_RETURN_OBJECT(dg);
}

void init_nokia_ui(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"com/nokia/mid/ui/DirectUtils", "createImage", "(II)Ljavax/microedition/lcdui/Image;", native_directutils_createImage},
        {"com/nokia/mid/ui/DirectUtils", "createImage", "(III)Ljavax/microedition/lcdui/Image;", native_directutils_createImage_color},
        {"com/nokia/mid/ui/DirectUtils", "getDirectGraphics", "(Ljavax/microedition/lcdui/Graphics;)Lcom/nokia/mid/ui/DirectGraphics;", native_directutils_getDirectGraphics},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered Nokia UI native methods");
}

/*
 * com.nokia.mid.ui.DirectGraphics native methods
 * Nokia's extended graphics API
 */

/* DirectGraphics.drawImage(Image img, int x, int y, int anchor, int manipulation) */
static JavaValue native_directgraphics_drawImage(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    jint x = args[2].i;
    jint y = args[3].i;
    jint anchor = args[4].i;
    jint manipulation = args[5].i;
    
    (void)dg; (void)image;
    fprintf(stderr, "[DirectGraphics] drawImage(%p, %d, %d, 0x%X, 0x%X)\n", 
            (void*)image, x, y, anchor, manipulation);
    
    /* TODO: Implement actual image drawing with manipulation */
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.setARGBColor(int argb) */
static JavaValue native_directgraphics_setARGBColor(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    (void)dg;
    fprintf(stderr, "[DirectGraphics] setARGBColor(0x%08X)\n", argb);
    
    /* TODO: Implement ARGB color setting */
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.getAlphaComponent() - returns alpha channel */
static JavaValue native_directgraphics_getAlphaComponent(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* Return full opacity by default */
    return NATIVE_RETURN_INT(255);
}

/* DirectGraphics.getNativePixelFormat() - returns pixel format */
static JavaValue native_directgraphics_getNativePixelFormat(JVM* jvm, JavaThread* thread,
                                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* Return TYPE_INT_8888_ARGB = 1 */
    return NATIVE_RETURN_INT(1);
}

/* DirectGraphics.drawPixels(int[] pixels, boolean transparency, int offset, int scanlength, 
                              int x, int y, int width, int height, int manipulation, int format) */
static JavaValue native_directgraphics_drawPixels(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    JavaArray* pixels = (JavaArray*)args[1].ref;
    jint transparency = args[2].i;
    jint offset = args[3].i;
    jint scanlength = args[4].i;
    jint x = args[5].i;
    jint y = args[6].i;
    jint width = args[7].i;
    jint height = args[8].i;
    jint manipulation = args[9].i;
    jint format = args[10].i;
    
    (void)dg; (void)pixels; (void)transparency; (void)offset; (void)scanlength;
    (void)x; (void)y; (void)width; (void)height; (void)manipulation; (void)format;
    
    fprintf(stderr, "[DirectGraphics] drawPixels(%p, %d, %d, %d, %d, %d, %d, %d, 0x%X, %d)\n",
            (void*)pixels, transparency, offset, scanlength, x, y, width, height, manipulation, format);
    
    /* TODO: Implement actual pixel drawing */
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.drawPolygon(int[] xPoints, int xOffset, int[] yPoints, int yOffset, 
                               int nPoints, int argbColor) */
static JavaValue native_directgraphics_drawPolygon(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    JavaArray* xPoints = (JavaArray*)args[1].ref;
    jint xOffset = args[2].i;
    JavaArray* yPoints = (JavaArray*)args[3].ref;
    jint yOffset = args[4].i;
    jint nPoints = args[5].i;
    jint argbColor = args[6].i;
    
    (void)dg; (void)xPoints; (void)xOffset; (void)yPoints; (void)yOffset;
    (void)nPoints; (void)argbColor;
    
    fprintf(stderr, "[DirectGraphics] drawPolygon(%p, %d, %p, %d, %d, 0x%08X)\n",
            (void*)xPoints, xOffset, (void*)yPoints, yOffset, nPoints, argbColor);
    
    /* TODO: Implement polygon drawing */
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.fillPolygon(int[] xPoints, int xOffset, int[] yPoints, int yOffset, 
                               int nPoints, int argbColor) */
static JavaValue native_directgraphics_fillPolygon(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    JavaArray* xPoints = (JavaArray*)args[1].ref;
    jint xOffset = args[2].i;
    JavaArray* yPoints = (JavaArray*)args[3].ref;
    jint yOffset = args[4].i;
    jint nPoints = args[5].i;
    jint argbColor = args[6].i;
    
    (void)dg; (void)xPoints; (void)xOffset; (void)yPoints; (void)yOffset;
    (void)nPoints; (void)argbColor;
    
    fprintf(stderr, "[DirectGraphics] fillPolygon(%p, %d, %p, %d, %d, 0x%08X)\n",
            (void*)xPoints, xOffset, (void*)yPoints, yOffset, nPoints, argbColor);
    
    /* TODO: Implement polygon filling */
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.setPixels(int[] pixels, int offset, int scanlength, int x, int y, 
                             int width, int height, int format) */
static JavaValue native_directgraphics_setPixels(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    JavaArray* pixels = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint scanlength = args[3].i;
    jint x = args[4].i;
    jint y = args[5].i;
    jint width = args[6].i;
    jint height = args[7].i;
    jint format = args[8].i;
    
    (void)dg; (void)pixels; (void)offset; (void)scanlength;
    (void)x; (void)y; (void)width; (void)height; (void)format;
    
    fprintf(stderr, "[DirectGraphics] setPixels(%p, %d, %d, %d, %d, %d, %d, %d)\n",
            (void*)pixels, offset, scanlength, x, y, width, height, format);
    
    /* TODO: Implement pixel setting */
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.getPixels(int[] pixels, int offset, int scanlength, int x, int y, 
                             int width, int height, int format) */
static JavaValue native_directgraphics_getPixels(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    JavaArray* pixels = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint scanlength = args[3].i;
    jint x = args[4].i;
    jint y = args[5].i;
    jint width = args[6].i;
    jint height = args[7].i;
    jint format = args[8].i;
    
    (void)dg; (void)pixels; (void)offset; (void)scanlength;
    (void)x; (void)y; (void)width; (void)height; (void)format;
    
    fprintf(stderr, "[DirectGraphics] getPixels(%p, %d, %d, %d, %d, %d, %d, %d)\n",
            (void*)pixels, offset, scanlength, x, y, width, height, format);
    
    /* TODO: Implement pixel getting - for now fill with zeros */
    if (pixels && pixels->element_type == T_INT) {
        jint* data = (jint*)array_data(pixels);
        for (int i = 0; i < (int)pixels->length; i++) {
            data[i] = 0;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int argbColor) */
static JavaValue native_directgraphics_drawTriangle(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    jint x1 = args[1].i;
    jint y1 = args[2].i;
    jint x2 = args[3].i;
    jint y2 = args[4].i;
    jint x3 = args[5].i;
    jint y3 = args[6].i;
    jint argbColor = args[7].i;
    
    (void)dg; (void)x1; (void)y1; (void)x2; (void)y2; (void)x3; (void)y3; (void)argbColor;
    
    fprintf(stderr, "[DirectGraphics] drawTriangle(%d, %d, %d, %d, %d, %d, 0x%08X)\n",
            x1, y1, x2, y2, x3, y3, argbColor);
    
    return NATIVE_RETURN_VOID();
}

/* DirectGraphics.fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int argbColor) */
static JavaValue native_directgraphics_fillTriangle(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* dg = (JavaObject*)args[0].ref;
    jint x1 = args[1].i;
    jint y1 = args[2].i;
    jint x2 = args[3].i;
    jint y2 = args[4].i;
    jint x3 = args[5].i;
    jint y3 = args[6].i;
    jint argbColor = args[7].i;
    
    (void)dg; (void)x1; (void)y1; (void)x2; (void)y2; (void)x3; (void)y3; (void)argbColor;
    
    fprintf(stderr, "[DirectGraphics] fillTriangle(%d, %d, %d, %d, %d, %d, 0x%08X)\n",
            x1, y1, x2, y2, x3, y3, argbColor);
    
    return NATIVE_RETURN_VOID();
}

void init_nokia_direct_graphics(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"com/nokia/mid/ui/DirectGraphics", "drawImage", "(Ljavax/microedition/lcdui/Image;IIII)V", native_directgraphics_drawImage},
        {"com/nokia/mid/ui/DirectGraphics", "setARGBColor", "(I)V", native_directgraphics_setARGBColor},
        {"com/nokia/mid/ui/DirectGraphics", "getAlphaComponent", "()I", native_directgraphics_getAlphaComponent},
        {"com/nokia/mid/ui/DirectGraphics", "getNativePixelFormat", "()I", native_directgraphics_getNativePixelFormat},
        {"com/nokia/mid/ui/DirectGraphics", "drawPixels", "([IZIIIIIIII)V", native_directgraphics_drawPixels},
        {"com/nokia/mid/ui/DirectGraphics", "drawPolygon", "([II[IIII)V", native_directgraphics_drawPolygon},
        {"com/nokia/mid/ui/DirectGraphics", "fillPolygon", "([II[IIII)V", native_directgraphics_fillPolygon},
        {"com/nokia/mid/ui/DirectGraphics", "setPixels", "([IIIIIIII)V", native_directgraphics_setPixels},
        {"com/nokia/mid/ui/DirectGraphics", "getPixels", "([IIIIIIII)V", native_directgraphics_getPixels},
        {"com/nokia/mid/ui/DirectGraphics", "drawTriangle", "(IIIIIII)V", native_directgraphics_drawTriangle},
        {"com/nokia/mid/ui/DirectGraphics", "fillTriangle", "(IIIIIII)V", native_directgraphics_fillTriangle},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered DirectGraphics native methods (%zu)", 
            sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.String native methods
 */

static JavaValue native_string_hashCode(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    return NATIVE_RETURN_INT(str ? string_hash(str) : 0);
}

static JavaValue native_string_intern(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;

    if (!str) return NATIVE_RETURN_NULL();

    /* TODO: Implement string interning */
    return NATIVE_RETURN_OBJECT(str);
}

/* String.toString() - returns the string itself */
static JavaValue native_string_toString(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;

    /* toString() returns the string itself (this) */
    return NATIVE_RETURN_OBJECT(str);
}

/* String.length() - returns the length of the string */
static JavaValue native_string_length(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT(str->length);
}

/* String.charAt(int) - returns character at index */
static JavaValue native_string_charAt(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jint index = args[1].i;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    if (index < 0 || index >= str->length) {
        native_throw_aioobe(jvm, thread, index);
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* chars = string_chars(str);
    return NATIVE_RETURN_INT((jint)chars[index]);
}

/* String.isEmpty() - returns true if length is 0 */
static JavaValue native_string_isEmpty(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    return NATIVE_RETURN_INT(str ? (str->length == 0 ? 1 : 0) : 1);
}

/* String.startsWith(String) - check if string starts with prefix */
static JavaValue native_string_startsWith(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* prefix = (JavaString*)args[1].ref;
    
    if (!str || !prefix) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (prefix->length > str->length) {
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* prefix_chars = string_chars(prefix);
    
    for (jsize i = 0; i < prefix->length; i++) {
        if (str_chars[i] != prefix_chars[i]) {
            return NATIVE_RETURN_INT(0);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* String.endsWith(String) - check if string ends with suffix */
static JavaValue native_string_endsWith(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* suffix = (JavaString*)args[1].ref;
    
    if (!str || !suffix) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (suffix->length > str->length) {
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* suffix_chars = string_chars(suffix);
    
    jsize start = str->length - suffix->length;
    for (jsize i = 0; i < suffix->length; i++) {
        if (str_chars[start + i] != suffix_chars[i]) {
            return NATIVE_RETURN_INT(0);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* String.indexOf(int) - find first occurrence of character */
static JavaValue native_string_indexOf(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jchar ch = (jchar)args[1].i;
    
    if (!str) {
        return NATIVE_RETURN_INT(-1);
    }
    
    const jchar* chars = string_chars(str);
    
    for (jsize i = 0; i < str->length; i++) {
        if (chars[i] == ch) {
            return NATIVE_RETURN_INT((jint)i);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* String.indexOf(int, int) - find character starting from index */
static JavaValue native_string_indexOf_from(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jchar ch = (jchar)args[1].i;
    jint fromIndex = args[2].i;
    
    if (!str) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (fromIndex < 0) fromIndex = 0;
    
    const jchar* chars = string_chars(str);
    
    for (jsize i = fromIndex; i < str->length; i++) {
        if (chars[i] == ch) {
            return NATIVE_RETURN_INT((jint)i);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* String.indexOf(String) - find first occurrence of substring */
static JavaValue native_string_indexOf_string(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* sub = (JavaString*)args[1].ref;
    
    if (!str) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!sub || sub->length == 0) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (sub->length > str->length) {
        return NATIVE_RETURN_INT(-1);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* sub_chars = string_chars(sub);
    
    /* Simple substring search */
    for (jsize i = 0; i <= str->length - sub->length; i++) {
        bool found = true;
        for (jsize j = 0; j < sub->length; j++) {
            if (str_chars[i + j] != sub_chars[j]) {
                found = false;
                break;
            }
        }
        if (found) {
            return NATIVE_RETURN_INT((jint)i);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* String.indexOf(String, int) - find substring starting from index */
static JavaValue native_string_indexOf_string_from(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* sub = (JavaString*)args[1].ref;
    jint fromIndex = args[2].i;
    
    if (!str) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (fromIndex < 0) fromIndex = 0;
    
    if (!sub || sub->length == 0) {
        return NATIVE_RETURN_INT(fromIndex < str->length ? fromIndex : str->length);
    }
    
    if (sub->length > str->length) {
        return NATIVE_RETURN_INT(-1);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* sub_chars = string_chars(sub);
    
    for (jsize i = fromIndex; i <= str->length - sub->length; i++) {
        bool found = true;
        for (jsize j = 0; j < sub->length; j++) {
            if (str_chars[i + j] != sub_chars[j]) {
                found = false;
                break;
            }
        }
        if (found) {
            return NATIVE_RETURN_INT((jint)i);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* String.lastIndexOf(int) - find last occurrence of character */
static JavaValue native_string_lastIndexOf(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jchar ch = (jchar)args[1].i;
    
    if (!str) {
        return NATIVE_RETURN_INT(-1);
    }
    
    const jchar* chars = string_chars(str);
    
    for (jsize i = str->length - 1; i >= 0; i--) {
        if (chars[i] == ch) {
            return NATIVE_RETURN_INT((jint)i);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* String.substring(int) - extract substring from start index */
static JavaValue native_string_substring(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jint start = args[1].i;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    if (start < 0 || start > str->length) {
        native_throw_aioobe(jvm, thread, start);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    jsize len = str->length - start;
    JavaString* result = jvm_new_string_utf16(jvm, chars + start, len);
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.substring(int, int) - extract substring between indices */
static JavaValue native_string_substring_range(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jint start = args[1].i;
    jint end = args[2].i;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    if (start < 0 || end > str->length || start > end) {
        native_throw_aioobe(jvm, thread, start);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    jsize len = end - start;
    JavaString* result = jvm_new_string_utf16(jvm, chars + start, len);
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.trim() - remove leading and trailing whitespace */
static JavaValue native_string_trim(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    jint start = 0;
    jint end = str->length;
    
    /* Find first non-whitespace */
    while (start < end && (chars[start] <= ' ')) {
        start++;
    }
    
    /* Find last non-whitespace */
    while (end > start && (chars[end - 1] <= ' ')) {
        end--;
    }
    
    if (start == 0 && end == str->length) {
        return NATIVE_RETURN_OBJECT(str);  /* No change */
    }
    
    jsize len = end - start;
    JavaString* result = jvm_new_string_utf16(jvm, chars + start, len);
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.toLowerCase() - convert to lowercase */
static JavaValue native_string_toLowerCase(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    JavaString* result = jvm_new_string_utf16(jvm, chars, str->length);
    
    if (result) {
        jchar* result_chars = (jchar*)string_chars(result);
        for (jsize i = 0; i < str->length; i++) {
            jchar c = chars[i];
            if (c >= 'A' && c <= 'Z') {
                result_chars[i] = c + ('a' - 'A');
            } else {
                result_chars[i] = c;
            }
        }
    }
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.toUpperCase() - convert to uppercase */
static JavaValue native_string_toUpperCase(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    JavaString* result = jvm_new_string_utf16(jvm, chars, str->length);
    
    if (result) {
        jchar* result_chars = (jchar*)string_chars(result);
        for (jsize i = 0; i < str->length; i++) {
            jchar c = chars[i];
            if (c >= 'a' && c <= 'z') {
                result_chars[i] = c - ('a' - 'A');
            } else {
                result_chars[i] = c;
            }
        }
    }
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.compareTo(String) - compare strings lexicographically */
static JavaValue native_string_compareTo(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* other = (JavaString*)args[1].ref;
    
    if (!str) {
        return NATIVE_RETURN_INT(other ? -1 : 0);
    }
    
    if (!other) {
        return NATIVE_RETURN_INT(1);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* other_chars = string_chars(other);
    
    jsize min_len = str->length < other->length ? str->length : other->length;
    
    for (jsize i = 0; i < min_len; i++) {
        if (str_chars[i] != other_chars[i]) {
            return NATIVE_RETURN_INT((jint)str_chars[i] - (jint)other_chars[i]);
        }
    }
    
    return NATIVE_RETURN_INT((jint)str->length - (jint)other->length);
}

/* String.replace(char, char) - replace characters */
static JavaValue native_string_replace(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jchar oldChar = (jchar)args[1].i;
    jchar newChar = (jchar)args[2].i;
    
    if (!str) {
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    const jchar* chars = string_chars(str);
    JavaString* result = jvm_new_string_utf16(jvm, chars, str->length);
    
    if (result) {
        jchar* result_chars = (jchar*)string_chars(result);
        for (jsize i = 0; i < str->length; i++) {
            if (chars[i] == oldChar) {
                result_chars[i] = newChar;
            } else {
                result_chars[i] = chars[i];
            }
        }
    }
    
    return NATIVE_RETURN_OBJECT(result);
}

/* String.equals(Object) - compare strings */
static JavaValue native_string_equals(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* other = (JavaString*)args[1].ref;
    
    if (str == other) {
        return NATIVE_RETURN_INT(1);
    }
    
    if (!str || !other) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Debug: Log string comparison */
    const char* str_utf8 = string_utf8(jvm, str);
    const char* other_utf8 = string_utf8(jvm, other);
    fprintf(stderr, "[String.equals] '%s' vs '%s' (len=%d vs %d)\n", 
            str_utf8 ? str_utf8 : "(null)", 
            other_utf8 ? other_utf8 : "(null)",
            str->length, other->length);
    
    if (str->length != other->length) {
        fprintf(stderr, "[String.equals] -> false (different lengths)\n");
        return NATIVE_RETURN_INT(0);
    }
    
    const jchar* str_chars = string_chars(str);
    const jchar* other_chars = string_chars(other);
    
    for (jsize i = 0; i < str->length; i++) {
        if (str_chars[i] != other_chars[i]) {
            fprintf(stderr, "[String.equals] -> false (char mismatch at %d)\n", i);
            return NATIVE_RETURN_INT(0);
        }
    }
    
    fprintf(stderr, "[String.equals] -> true\n");
    return NATIVE_RETURN_INT(1);
}

/*
 * java.lang.String native methods - ADD toCharArray
 */

/* String.toCharArray() - converts string to char array */
static JavaValue native_string_toCharArray(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Get string characters */
    const jchar* chars = string_chars(str);
    jsize length = str->length;
    
    /* Create char array of same length */
    JavaArray* char_array = jvm_new_array(jvm, T_CHAR, length);
    if (!char_array) {
        native_throw_oome(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Copy characters to array */
    if (length > 0) {
        jchar* array_data_ptr = (jchar*)array_data(char_array);
        memcpy(array_data_ptr, chars, length * sizeof(jchar));
    }
    
    fprintf(stderr, "[String] toCharArray(): length=%d, array=%p\n", 
            length, (void*)char_array);
    
    return NATIVE_RETURN_OBJECT(char_array);
}

/* String.getBytes() - converts string to byte array using platform encoding */
static JavaValue native_string_getBytes(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Get UTF-8 representation (simplified - in real Java it uses platform encoding) */
    const char* utf8 = string_utf8(jvm, str);
    if (!utf8) {
        return NATIVE_RETURN_NULL();
    }
    
    jsize length = (jsize)strlen(utf8);
    
    /* Create byte array */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, length);
    if (!byte_array) {
        native_throw_oome(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Copy bytes */
    if (length > 0) {
        uint8_t* array_data_ptr = (uint8_t*)array_data(byte_array);
        memcpy(array_data_ptr, utf8, length);
    }
    
    fprintf(stderr, "[String] getBytes(): length=%d\n", length);
    
    return NATIVE_RETURN_OBJECT(byte_array);
}

/* String.getBytes(int, int, byte[], int) - old method (deprecated but used in some apps) */
static JavaValue native_string_getBytes_old(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    jint srcBegin = args[1].i;
    jint srcEnd = args[2].i;
    JavaArray* dst = (JavaArray*)args[3].ref;
    jint dstBegin = args[4].i;
    
    if (!str || !dst) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Bounds checking */
    if (srcBegin < 0 || srcBegin > srcEnd || srcEnd > str->length) {
        native_throw_aioobe(jvm, thread, srcBegin);
        return NATIVE_RETURN_VOID();
    }
    
    if (dstBegin < 0 || dstBegin + (srcEnd - srcBegin) > (jint)dst->length) {
        native_throw_aioobe(jvm, thread, dstBegin);
        return NATIVE_RETURN_VOID();
    }
    
    /* Get string characters */
    const jchar* chars = string_chars(str);
    
    /* Convert to bytes (ASCII only - high byte discarded) */
    uint8_t* dst_data = (uint8_t*)array_data(dst);
    for (int i = srcBegin; i < srcEnd; i++) {
        dst_data[dstBegin + (i - srcBegin)] = (uint8_t)(chars[i] & 0xFF);
    }
    
    return NATIVE_RETURN_VOID();
}

/* String.getBytes(String charsetName) */
static JavaValue native_string_getBytes_charset(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* charset_str = (JavaString*)args[1].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Get charset name (ignore for now, just use UTF-8) */
    const char* charset = charset_str ? string_utf8(jvm, charset_str) : "UTF-8";
    (void)charset; /* Ignore in simplified implementation */
    
    /* Get UTF-8 representation */
    const char* utf8 = string_utf8(jvm, str);
    if (!utf8) {
        return NATIVE_RETURN_NULL();
    }
    
    jsize length = (jsize)strlen(utf8);
    
    /* Create byte array */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, length);
    if (!byte_array) {
        native_throw_oome(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Copy bytes */
    if (length > 0) {
        uint8_t* array_data_ptr = (uint8_t*)array_data(byte_array);
        memcpy(array_data_ptr, utf8, length);
    }
    
    return NATIVE_RETURN_OBJECT(byte_array);
}

/* String.valueOf(C) - convert char to String */
static JavaValue native_string_valueOf_char(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jchar c = (jchar)args[0].i;
    
    /* Create a new String with one character */
    char utf8[8];
    int len = 0;
    
    /* Convert jchar (UTF-16) to UTF-8 */
    if (c < 0x80) {
        utf8[len++] = (char)c;
    } else if (c < 0x800) {
        utf8[len++] = (char)(0xC0 | (c >> 6));
        utf8[len++] = (char)(0x80 | (c & 0x3F));
    } else {
        utf8[len++] = (char)(0xE0 | (c >> 12));
        utf8[len++] = (char)(0x80 | ((c >> 6) & 0x3F));
        utf8[len++] = (char)(0x80 | (c & 0x3F));
    }
    utf8[len] = '\0';
    
    JavaString* str = jvm_new_string(jvm, utf8);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(I) - convert int to String */
static JavaValue native_string_valueOf_int(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    char buffer[16];
    snprintf(buffer, sizeof(buffer), "%d", value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(J) - convert long to String */
static JavaValue native_string_valueOf_long(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jlong value = args[0].j;
    
    char buffer[24];
    snprintf(buffer, sizeof(buffer), "%lld", (long long)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(Z) - convert boolean to String */
static JavaValue native_string_valueOf_boolean(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jboolean value = args[0].i;
    
    JavaString* str = jvm_new_string(jvm, value ? "true" : "false");
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(F) - convert float to String */
static JavaValue native_string_valueOf_float(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jfloat value = args[0].f;
    
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%g", (double)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(D) - convert double to String */
static JavaValue native_string_valueOf_double(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%g", value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* String.valueOf(Object) - convert object to String */
static JavaValue native_string_valueOf_object(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = args[0].ref;
    
    if (!obj) {
        JavaString* str = jvm_new_string(jvm, "null");
        return NATIVE_RETURN_OBJECT(str);
    }
    
    /* TODO: Call obj.toString() */
    JavaString* str = jvm_new_string(jvm, "Object");
    return NATIVE_RETURN_OBJECT(str);
}

/* String.<init>() - default constructor creates empty string */
static JavaValue native_string_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (str) {
        /* Initialize as empty string - the JavaString already has fields from jvm_new_string */
        /* We need to set the internal char array to empty */
        str->length = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

/* String.<init>(char[]) - construct from char array */
static JavaValue native_string_init_chars(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaArray* char_array = (JavaArray*)args[1].ref;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    if (char_array && char_array->length > 0) {
        jchar* chars = (jchar*)array_data(char_array);
        /* Create new string from chars - this replaces the string object's data */
        JavaString* new_str = jvm_new_string_utf16(jvm, chars, char_array->length);
        if (new_str) {
            /* Copy the new string's data to our object */
            str->length = new_str->length;
            /* The chars pointer will be different - we need to handle this */
        }
    } else {
        str->length = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

/* String.<init>(byte[]) - construct from byte array */
static JavaValue native_string_init_bytes(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaArray* byte_array = (JavaArray*)args[1].ref;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    if (byte_array && byte_array->length > 0) {
        char* bytes = (char*)array_data(byte_array);
        /* Null-terminate for jvm_new_string */
        char* temp = (char*)malloc(byte_array->length + 1);
        if (temp) {
            memcpy(temp, bytes, byte_array->length);
            temp[byte_array->length] = '\0';
            JavaString* new_str = jvm_new_string(jvm, temp);
            free(temp);
            if (new_str) {
                str->length = new_str->length;
            }
        }
    } else {
        str->length = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

/* String.<init>(String) - copy constructor */
static JavaValue native_string_init_string(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaString* other = (JavaString*)args[1].ref;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    if (other) {
        str->length = other->length;
        /* Copy the char data pointer - both strings share the same data */
        /* This is simplified - in real JVM strings are immutable */
    } else {
        str->length = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

/* String.<init>(char[], int, int) - construct from char array with offset */
static JavaValue native_string_init_chars_offset(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaArray* char_array = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint count = args[3].i;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    if (char_array && offset >= 0 && count > 0 && offset + count <= (jint)char_array->length) {
        jchar* chars = (jchar*)array_data(char_array);
        JavaString* new_str = jvm_new_string_utf16(jvm, chars + offset, count);
        if (new_str) {
            str->length = new_str->length;
        }
    } else {
        str->length = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

/* String.<init>(byte[], int, int) - construct from byte array with offset */
static JavaValue native_string_init_bytes_offset(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    JavaArray* byte_array = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint count = args[3].i;
    
    if (!str) return NATIVE_RETURN_VOID();
    
    if (byte_array && offset >= 0 && count > 0 && offset + count <= (jint)byte_array->length) {
        char* bytes = (char*)array_data(byte_array);
        /* Null-terminate for jvm_new_string */
        char* temp = (char*)malloc(count + 1);
        if (temp) {
            memcpy(temp, bytes + offset, count);
            temp[count] = '\0';
            JavaString* new_str = jvm_new_string(jvm, temp);
            free(temp);
            if (new_str) {
                str->length = new_str->length;
            }
        }
    } else {
        str->length = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

void init_java_lang_string(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Constructors */
        {"java/lang/String", "<init>", "()V", native_string_init},
        {"java/lang/String", "<init>", "([C)V", native_string_init_chars},
        {"java/lang/String", "<init>", "([B)V", native_string_init_bytes},
        {"java/lang/String", "<init>", "(Ljava/lang/String;)V", native_string_init_string},
        {"java/lang/String", "<init>", "([CII)V", native_string_init_chars_offset},
        {"java/lang/String", "<init>", "([BII)V", native_string_init_bytes_offset},
        
        /* Basic methods */
        {"java/lang/String", "length", "()I", native_string_length},
        {"java/lang/String", "charAt", "(I)C", native_string_charAt},
        {"java/lang/String", "isEmpty", "()Z", native_string_isEmpty},
        
        /* Comparison methods */
        {"java/lang/String", "equals", "(Ljava/lang/Object;)Z", native_string_equals},
        {"java/lang/String", "hashCode", "()I", native_string_hashCode},
        {"java/lang/String", "compareTo", "(Ljava/lang/String;)I", native_string_compareTo},
        {"java/lang/String", "startsWith", "(Ljava/lang/String;)Z", native_string_startsWith},
        {"java/lang/String", "endsWith", "(Ljava/lang/String;)Z", native_string_endsWith},
        
        /* Search methods */
        {"java/lang/String", "indexOf", "(I)I", native_string_indexOf},
        {"java/lang/String", "indexOf", "(II)I", native_string_indexOf_from},
        {"java/lang/String", "indexOf", "(Ljava/lang/String;)I", native_string_indexOf_string},
        {"java/lang/String", "indexOf", "(Ljava/lang/String;I)I", native_string_indexOf_string_from},
        {"java/lang/String", "lastIndexOf", "(I)I", native_string_lastIndexOf},
        
        /* Substring methods */
        {"java/lang/String", "substring", "(I)Ljava/lang/String;", native_string_substring},
        {"java/lang/String", "substring", "(II)Ljava/lang/String;", native_string_substring_range},
        
        /* Conversion methods */
        {"java/lang/String", "toCharArray", "()[C", native_string_toCharArray},
        {"java/lang/String", "getBytes", "()[B", native_string_getBytes},
        {"java/lang/String", "getBytes", "(II[BI)V", native_string_getBytes_old},
        {"java/lang/String", "trim", "()Ljava/lang/String;", native_string_trim},
        {"java/lang/String", "toLowerCase", "()Ljava/lang/String;", native_string_toLowerCase},
        {"java/lang/String", "toUpperCase", "()Ljava/lang/String;", native_string_toUpperCase},
        {"java/lang/String", "replace", "(CC)Ljava/lang/String;", native_string_replace},
        {"java/lang/String", "intern", "()Ljava/lang/String;", native_string_intern},
        {"java/lang/String", "toString", "()Ljava/lang/String;", native_string_toString},
        
        /* String.valueOf static methods */
        {"java/lang/String", "valueOf", "(C)Ljava/lang/String;", native_string_valueOf_char},
        {"java/lang/String", "valueOf", "(I)Ljava/lang/String;", native_string_valueOf_int},
        {"java/lang/String", "valueOf", "(J)Ljava/lang/String;", native_string_valueOf_long},
        {"java/lang/String", "valueOf", "(Z)Ljava/lang/String;", native_string_valueOf_boolean},
        {"java/lang/String", "valueOf", "(F)Ljava/lang/String;", native_string_valueOf_float},
        {"java/lang/String", "valueOf", "(D)Ljava/lang/String;", native_string_valueOf_double},
        {"java/lang/String", "valueOf", "(Ljava/lang/Object;)Ljava/lang/String;", native_string_valueOf_object},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/lang/String native methods (%zu total)",
            sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Integer native methods
 */

static JavaValue native_integer_valueOf(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    JavaClass* int_class = jvm_load_class(jvm, "java/lang/Integer");
    if (!int_class) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* int_obj = jvm_new_object(jvm, int_class);
    if (!int_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue val = { .i = value };
    native_set_field_value(int_obj, "value", val);
    
    return NATIVE_RETURN_OBJECT(int_obj);
}

static JavaValue native_integer_valueOf_string(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    const char* utf8 = string_utf8(jvm, str);
    if (!utf8) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Parse integer */
    jint value = 0;
    int sign = 1;
    const char* p = utf8;
    
    if (*p == '-') {
        sign = -1;
        p++;
    } else if (*p == '+') {
        p++;
    }
    
    while (*p >= '0' && *p <= '9') {
        value = value * 10 + (*p - '0');
        p++;
    }
    
    value *= sign;
    
    JavaClass* int_class = jvm_load_class(jvm, "java/lang/Integer");
    if (!int_class) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* int_obj = jvm_new_object(jvm, int_class);
    if (!int_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue val = { .i = value };
    native_set_field_value(int_obj, "value", val);
    
    return NATIVE_RETURN_OBJECT(int_obj);
}

static JavaValue native_integer_parseInt(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    const char* utf8 = string_utf8(jvm, str);
    if (!utf8) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Parse integer */
    jint value = 0;
    int sign = 1;
    const char* p = utf8;
    
    if (*p == '-') {
        sign = -1;
        p++;
    } else if (*p == '+') {
        p++;
    }
    
    while (*p >= '0' && *p <= '9') {
        value = value * 10 + (*p - '0');
        p++;
    }
    
    return NATIVE_RETURN_INT(value * sign);
}

static JavaValue native_integer_toString(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    char buffer[16];
    snprintf(buffer, sizeof(buffer), "%d", value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

static JavaValue native_integer_intValue(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* int_obj = (JavaObject*)args[0].ref;
    
    if (!int_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    return NATIVE_RETURN_INT(native_get_field_value(int_obj, "value").i);
}

/* Integer(int) constructor */
static JavaValue native_integer_init(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* int_obj = (JavaObject*)args[0].ref;
    jint value = args[1].i;
    
    if (!int_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue val = { .i = value };
    native_set_field_value(int_obj, "value", val);
    
    return NATIVE_RETURN_VOID();
}

/* Integer.toHexString(int) - convert int to hexadecimal string */
static JavaValue native_integer_toHexString(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    char buffer[12];  /* Enough for 32-bit hex: 8 chars + "0x" + null */
    snprintf(buffer, sizeof(buffer), "%X", (unsigned int)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* Integer.toHexString(long) - convert long to hexadecimal string (for Long) */
static JavaValue native_integer_toHexString_long(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jlong value = args[0].j;
    
    char buffer[20];  /* Enough for 64-bit hex: 16 chars + null */
    snprintf(buffer, sizeof(buffer), "%llX", (unsigned long long)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* Integer.toOctalString(int) - convert int to octal string */
static JavaValue native_integer_toOctalString(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    char buffer[16];  /* Enough for 32-bit octal */
    snprintf(buffer, sizeof(buffer), "%o", (unsigned int)value);
    
    JavaString* str = jvm_new_string(jvm, buffer);
    return NATIVE_RETURN_OBJECT(str);
}

/* Integer.toBinaryString(int) - convert int to binary string */
static JavaValue native_integer_toBinaryString(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint value = args[0].i;
    
    /* Convert to binary string manually */
    char buffer[33];  /* 32 bits + null */
    buffer[32] = '\0';
    
    unsigned int uval = (unsigned int)value;
    for (int i = 31; i >= 0; i--) {
        buffer[i] = (uval & 1) ? '1' : '0';
        uval >>= 1;
    }
    
    /* Skip leading zeros */
    char* start = buffer;
    while (*start == '0' && *(start + 1) != '\0') {
        start++;
    }
    
    JavaString* str = jvm_new_string(jvm, start);
    return NATIVE_RETURN_OBJECT(str);
}

void init_java_lang_integer(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Integer", "<init>", "(I)V", native_integer_init},
        {"java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;", native_integer_valueOf},
        {"java/lang/Integer", "valueOf", "(Ljava/lang/String;)Ljava/lang/Integer;", native_integer_valueOf_string},
        {"java/lang/Integer", "parseInt", "(Ljava/lang/String;)I", native_integer_parseInt},
        {"java/lang/Integer", "parseInt", "(Ljava/lang/String;I)I", native_integer_parseInt},
        {"java/lang/Integer", "toString", "(I)Ljava/lang/String;", native_integer_toString},
        {"java/lang/Integer", "toHexString", "(I)Ljava/lang/String;", native_integer_toHexString},
        {"java/lang/Integer", "toOctalString", "(I)Ljava/lang/String;", native_integer_toOctalString},
        {"java/lang/Integer", "toBinaryString", "(I)Ljava/lang/String;", native_integer_toBinaryString},
        {"java/lang/Integer", "intValue", "()I", native_integer_intValue},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Long native methods
 */

void init_java_lang_long(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Long", "valueOf", "(J)Ljava/lang/Long;", native_integer_valueOf},
        {"java/lang/Long", "parseLong", "(Ljava/lang/String;)J", native_integer_parseInt},
        {"java/lang/Long", "toString", "(J)Ljava/lang/String;", native_integer_toString},
        {"java/lang/Long", "toHexString", "(J)Ljava/lang/String;", native_integer_toHexString_long},
        {"java/lang/Long", "longValue", "()J", native_integer_intValue},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Boolean native methods
 */

static JavaValue native_boolean_valueOf(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jboolean value = args[0].i != 0;
    
    JavaClass* bool_class = jvm_load_class(jvm, "java/lang/Boolean");
    if (!bool_class) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* bool_obj = jvm_new_object(jvm, bool_class);
    if (!bool_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue val = { .i = value ? 1 : 0 };
    native_set_field_value(bool_obj, "value", val);
    
    return NATIVE_RETURN_OBJECT(bool_obj);
}

static JavaValue native_boolean_parseBoolean(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        return NATIVE_RETURN_INT(0);
    }
    
    const char* utf8 = string_utf8(jvm, str);
    if (utf8 && strcmp(utf8, "true") == 0) {
        return NATIVE_RETURN_INT(1);
    }
    
    return NATIVE_RETURN_INT(0);
}

void init_java_lang_boolean(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", native_boolean_valueOf},
        {"java/lang/Boolean", "parseBoolean", "(Ljava/lang/String;)Z", native_boolean_parseBoolean},
        {"java/lang/Boolean", "booleanValue", "()Z", native_integer_intValue},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.System native methods
 */

/* System.getProperty(String key) - получить системное свойство */
static JavaValue native_system_getProperty(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)arg_count;
    
    /* STATIC METHOD - no 'this' argument!
     * args[0] = key string
     */
    JavaString* key_str = (JavaString*)args[0].ref;
    
    if (!key_str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    const char* key = string_utf8(jvm, key_str);
    if (!key) {
        return NATIVE_RETURN_NULL();
    }
    
    NATIVE_DEBUG("getProperty: '%s'", key);
    
    /* Стандартные J2ME системные свойства */
    const char* value = NULL;
    
    if (strcmp(key, "microedition.platform") == 0) {
        value = "j2me";
    } else if (strcmp(key, "microedition.encoding") == 0) {
        value = "UTF-8";
    } else if (strcmp(key, "microedition.configuration") == 0) {
        value = "CLDC-1.1";
    } else if (strcmp(key, "microedition.profiles") == 0) {
        value = "MIDP-2.0";
    } else if (strcmp(key, "microedition.locale") == 0) {
        value = "en-US";
    } else if (strcmp(key, "supports.mixing") == 0) {
        value = "true";
    } else if (strcmp(key, "supports.audio.capture") == 0) {
        value = "false";
    } else if (strcmp(key, "supports.video.capture") == 0) {
        value = "false";
    } else if (strcmp(key, "supports.recording") == 0) {
        value = "false";
    } else if (strcmp(key, "microedition.hostname") == 0) {
        value = "localhost";
    } else if (strcmp(key, "microedition.commports") == 0) {
        value = "";
    } else if (strcmp(key, "os.name") == 0) {
        value = "J2ME Emulator";
    } else if (strcmp(key, "os.version") == 0) {
        value = "1.0";
    } else if (strcmp(key, "os.arch") == 0) {
        value = "arm";
    } else if (strcmp(key, "java.version") == 0) {
        value = "1.3";
    } else if (strcmp(key, "java.vendor") == 0) {
        value = "NOJ2ME Emulator";
    } else if (strcmp(key, "file.separator") == 0) {
        value = "/";
    } else if (strcmp(key, "path.separator") == 0) {
        value = ":";
    } else if (strcmp(key, "line.separator") == 0) {
        value = "\n";
    }
    
    /* Nokia-specific свойства */
    else if (strcmp(key, "com.nokia.mid.ui.version") == 0) {
        value = "1.0";
    } else if (strcmp(key, "com.nokia.mid.ui.fullscreen") == 0) {
        value = "true";
    } else if (strcmp(key, "com.nokia.mid.ui.noSoftkeys") == 0) {
        value = "false";
    }
    
    if (value) {
        NATIVE_DEBUG("getProperty: '%s' -> '%s'", key, value);
        return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, value));
    }
    
    /* Свойство не найдено - возвращаем null */
    NATIVE_DEBUG("getProperty: '%s' not found, returning null", key);
    return NATIVE_RETURN_NULL();
}

static JavaValue native_system_arraycopy(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    /* Static method: args[0] is first parameter (src), not 'this' */
    JavaArray* src = (JavaArray*)args[0].ref;
    jint src_pos = args[1].i;
    JavaArray* dest = (JavaArray*)args[2].ref;
    jint dest_pos = args[3].i;
    jint length = args[4].i;
    
    if (!src || !dest) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    if (src_pos < 0 || dest_pos < 0 || length < 0 ||
        src_pos + length > src->length ||
        dest_pos + length > dest->length) {
        native_throw_aioobe(jvm, thread, -1);
        return NATIVE_RETURN_VOID();
    }
    
    /* Copy elements */
    size_t elem_size = 4;  /* Default to int */
    switch (src->element_type) {
        case T_BOOLEAN:
        case T_BYTE:    elem_size = 1; break;
        case T_CHAR:
        case T_SHORT:   elem_size = 2; break;
        case T_INT:
        case T_FLOAT:   elem_size = 4; break;
        case T_LONG:
        case T_DOUBLE:  elem_size = 8; break;
        case DESC_OBJECT:
        case DESC_ARRAY: elem_size = sizeof(void*); break;
    }
    
    uint8_t* dest_data = (uint8_t*)array_data(dest);
    uint8_t* src_data = (uint8_t*)array_data(src);
    
    memmove(dest_data + dest_pos * elem_size,
            src_data + src_pos * elem_size,
            length * elem_size);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_system_currentTimeMillis(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    jlong ms;
    
#ifdef _WIN32
    /* Windows implementation */
    LARGE_INTEGER freq, counter;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&counter);
    ms = (counter.QuadPart * 1000) / freq.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ms = (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
    
    return NATIVE_RETURN_LONG(ms);
}

static JavaValue native_system_gc(JVM* jvm, JavaThread* thread,
                                  JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    gc_collect(jvm);
    return NATIVE_RETURN_VOID();
}

void init_java_lang_system(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/System", "arraycopy", "(Ljava/lang/Object;ILjava/lang/Object;II)V", native_system_arraycopy},
        {"java/lang/System", "currentTimeMillis", "()J", native_system_currentTimeMillis},
        {"java/lang/System", "gc", "()V", native_system_gc},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    
    /* Initialize System.in, System.out, System.err */
    JavaClass* system_class = jvm_load_class(jvm, "java/lang/System");
    if (system_class && system_class->static_fields) {
        /* Find PrintStream class */
        JavaClass* ps_class = jvm_load_class(jvm, "java/io/PrintStream");
        JavaClass* is_class = jvm_load_class(jvm, "java/io/InputStream");
        
        for (int i = 0; i < system_class->static_fields_count; i++) {
            if (system_class->static_fields[i].name) {
                /* System.out */
                if (strcmp(system_class->static_fields[i].name, "out") == 0 && ps_class) {
                    JavaObject* out_obj = jvm_new_object(jvm, ps_class);
                    if (out_obj) {
                        system_class->static_fields[i].value.ref = out_obj;
                        NATIVE_DEBUG("Initialized System.out");
                    }
                }
                /* System.err */
                else if (strcmp(system_class->static_fields[i].name, "err") == 0 && ps_class) {
                    JavaObject* err_obj = jvm_new_object(jvm, ps_class);
                    if (err_obj) {
                        system_class->static_fields[i].value.ref = err_obj;
                        NATIVE_DEBUG("Initialized System.err");
                    }
                }
                /* System.in */
                else if (strcmp(system_class->static_fields[i].name, "in") == 0 && is_class) {
                    JavaObject* in_obj = jvm_new_object(jvm, is_class);
                    if (in_obj) {
                        system_class->static_fields[i].value.ref = in_obj;
                        NATIVE_DEBUG("Initialized System.in");
                    }
                }
            }
        }
    }
}

/*
 * java.lang.Runtime native methods
 */

/* Singleton Runtime instance */
static JavaObject* g_runtime_instance = NULL;

static JavaValue native_runtime_getRuntime(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    
    /* Return singleton Runtime instance */
    if (!g_runtime_instance) {
        JavaClass* runtime_class = jvm_load_class(jvm, "java/lang/Runtime");
        if (runtime_class) {
            g_runtime_instance = jvm_new_object(jvm, runtime_class);
            /* Register as GC root to prevent collection */
            gc_add_root(jvm, (void**)&g_runtime_instance);
            fprintf(stderr, "[Runtime] Created Runtime instance: %p\n", (void*)g_runtime_instance);
        }
    }
    
    return NATIVE_RETURN_OBJECT(g_runtime_instance);
}

static JavaValue native_runtime_freeMemory(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    HeapStats stats = heap_get_stats(jvm);
    return NATIVE_RETURN_LONG((jlong)stats.free_size);
}

static JavaValue native_runtime_totalMemory(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    HeapStats stats = heap_get_stats(jvm);
    return NATIVE_RETURN_LONG((jlong)stats.total_size);
}

static JavaValue native_runtime_gc(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    jvm_gc(jvm);
    return NATIVE_RETURN_VOID();
}

void init_java_lang_runtime(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Runtime", "getRuntime", "()Ljava/lang/Runtime;", native_runtime_getRuntime},
        {"java/lang/Runtime", "freeMemory", "()J", native_runtime_freeMemory},
        {"java/lang/Runtime", "totalMemory", "()J", native_runtime_totalMemory},
        {"java/lang/Runtime", "gc", "()V", native_runtime_gc},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Math native methods
 */

static JavaValue native_math_sqrt(JVM* jvm, JavaThread* thread,
                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(sqrt(value));
}

static JavaValue native_math_sin(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(sin(value));
}

static JavaValue native_math_cos(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(cos(value));
}

static JavaValue native_math_tan(JVM* jvm, JavaThread* thread,
                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(tan(value));
}

static JavaValue native_math_abs_int(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint value = args[0].i;
    return NATIVE_RETURN_INT(value < 0 ? -value : value);
}

static JavaValue native_math_abs_long(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jlong value = args[0].j;
    return NATIVE_RETURN_LONG(value < 0 ? -value : value);
}

static JavaValue native_math_abs_float(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jfloat value = args[0].f;
    return NATIVE_RETURN_FLOAT(value < 0 ? -value : value);
}

static JavaValue native_math_abs_double(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    return NATIVE_RETURN_DOUBLE(value < 0 ? -value : value);
}

static JavaValue native_math_max_int(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint a = args[0].i;
    jint b = args[1].i;
    return NATIVE_RETURN_INT(a > b ? a : b);
}

static JavaValue native_math_min_int(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint a = args[0].i;
    jint b = args[1].i;
    return NATIVE_RETURN_INT(a < b ? a : b);
}

void init_java_lang_math(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Math", "sqrt", "(D)D", native_math_sqrt},
        {"java/lang/Math", "sin", "(D)D", native_math_sin},
        {"java/lang/Math", "cos", "(D)D", native_math_cos},
        {"java/lang/Math", "tan", "(D)D", native_math_tan},
        {"java/lang/Math", "abs", "(I)I", native_math_abs_int},
        {"java/lang/Math", "abs", "(J)J", native_math_abs_long},
        {"java/lang/Math", "abs", "(F)F", native_math_abs_float},
        {"java/lang/Math", "abs", "(D)D", native_math_abs_double},
        {"java/lang/Math", "max", "(II)I", native_math_max_int},
        {"java/lang/Math", "min", "(II)I", native_math_min_int},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Thread native methods
 */

static JavaValue native_thread_currentThread(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)args; (void)arg_count;
    return NATIVE_RETURN_OBJECT(thread ? thread->thread_object : NULL);
}

static JavaValue native_thread_sleep(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)arg_count;
    jlong millis = args[0].j;
    thread_sleep(jvm, millis);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_thread_yield(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    thread_yield(jvm);
    return NATIVE_RETURN_VOID();
}

/* External functions for method resolution and execution */
extern JavaMethod* jvm_resolve_method(JVM* jvm, JavaClass* clazz, const char* name, const char* descriptor);
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                          JavaValue* args, JavaValue* result);

/* Thread.start() - cooperative thread start */
static JavaValue native_thread_start(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaObject* run_target = (JavaObject*)native_get_field_value(thread_obj, "target").ref;
    THREAD_DEBUG("start(): target field = %p", (void*)run_target);
    
    /* Determine which object's run() to call */
    JavaObject* run_obj = run_target ? run_target : thread_obj;
    JavaClass* run_class = run_obj->header.clazz;
    
    /* Find run() method */
    JavaMethod* run_method = jvm_resolve_method(jvm, run_class, "run", "()V");
    if (!run_method) {
        THREAD_DEBUG("start(): run() not found in %s", run_class->class_name);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create a new cooperative thread */
    char thread_name[64];
    snprintf(thread_name, sizeof(thread_name), "Thread-%d", jvm->thread_count + 1);
    
    JavaThread* new_java_thread = thread_create(jvm, thread_name, THREAD_PRIORITY_NORM, thread_obj);
    if (!new_java_thread) {
        THREAD_DEBUG("start(): failed to create cooperative thread");
        return NATIVE_RETURN_VOID();
    }
    
    /* Store run method info in thread object for scheduler */
    /* The scheduler will call run() when this thread is scheduled */
    
    /* Start the cooperative thread (adds to run queue) */
    thread_start(jvm, new_java_thread);
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue started_val = { .i = 1 };
    native_set_field_value(thread_obj, "started", started_val);
    
    THREAD_DEBUG("start(): cooperative thread %d created", new_java_thread->id);
    
    /* In cooperative mode, we execute the new thread's run() now 
     * but it will yield back to us periodically */
    JavaValue this_arg = { .ref = run_obj };
    JavaValue result;
    
    /* Execute run() with cooperative yielding */
    execute_method(jvm, new_java_thread, run_method, &this_arg, &result);
    
    /* Mark thread as terminated */
    new_java_thread->is_alive = false;
    
    THREAD_DEBUG("start(): thread %d completed", new_java_thread->id);
    
    return NATIVE_RETURN_VOID();
}

/* Thread.<init>() - default constructor */
static JavaValue native_thread_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue null_val = { .ref = NULL };
    native_set_field_value(thread_obj, "target", null_val);
    THREAD_DEBUG("<init>(): target field initialized to NULL");
    
    return NATIVE_RETURN_VOID();
}

/* Thread.<init>(Runnable) - constructor with Runnable target */
static JavaValue native_thread_init_runnable(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    JavaObject* runnable = (JavaObject*)args[1].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    JavaValue runnable_val = { .ref = runnable };
    native_set_field_value(thread_obj, "target", runnable_val);
    THREAD_DEBUG("<init>(Runnable): target field set to %p", (void*)runnable);
    
    return NATIVE_RETURN_VOID();
}

/* Thread.close() - called when thread terminates */
static JavaValue native_thread_close(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (thread_obj) {
        THREAD_DEBUG("close() called for thread object %p", (void*)thread_obj);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Thread.isAlive() - check if thread is alive */
static JavaValue native_thread_isAlive(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Check if thread is still running */
    /* For now, return 0 (not alive) for simplicity */
    return NATIVE_RETURN_INT(0);
}

/* Thread.interrupt() - interrupt thread */
static JavaValue native_thread_interrupt(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (thread_obj) {
        THREAD_DEBUG("interrupt() called");
    }
    
    return NATIVE_RETURN_VOID();
}

/* Thread.isInterrupted() - check if thread is interrupted */
static JavaValue native_thread_isInterrupted(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    return NATIVE_RETURN_INT(0);
}

/* Thread.interrupted() - static method to check and clear interrupted status */
static JavaValue native_thread_interrupted(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(0);
}

/* Thread.setPriority(int) */
static JavaValue native_thread_setPriority(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    jint priority = args[1].i;
    
    if (thread_obj) {
        /* ИСПРАВЛЕНО: Используем native_set_field_value */
        JavaValue priority_val = { .i = priority };
        native_set_field_value(thread_obj, "priority", priority_val);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Thread.getPriority() */
static JavaValue native_thread_getPriority(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_INT(5);  /* NORM_PRIORITY */
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    return NATIVE_RETURN_INT(native_get_field_value(thread_obj, "priority").i);
}

/* Thread.setName(String) */
static JavaValue native_thread_setName(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* Just ignore - name is stored in Java field */
    return NATIVE_RETURN_VOID();
}

/* Thread.getName() */
static JavaValue native_thread_getName(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* thread_obj = (JavaObject*)args[0].ref;
    
    if (!thread_obj) {
        return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, "Thread-0"));
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaString* name = (JavaString*)native_get_field_value(thread_obj, "name").ref;
    if (name) {
        return NATIVE_RETURN_OBJECT(name);
    }
    
    return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, "Thread-?"));
}

/* Thread.activeCount() - static */
static JavaValue native_thread_activeCount(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(1);  /* Just main thread */
}

/* Thread.holdsLock(Object) - static */
static JavaValue native_thread_holdsLock(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    return NATIVE_RETURN_INT(0);
}

void init_java_lang_thread(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Thread", "currentThread", "()Ljava/lang/Thread;", native_thread_currentThread},
        {"java/lang/Thread", "sleep", "(J)V", native_thread_sleep},
        {"java/lang/Thread", "yield", "()V", native_thread_yield},
        {"java/lang/Thread", "start", "()V", native_thread_start},
        {"java/lang/Thread", "close", "()V", native_thread_close},
        {"java/lang/Thread", "isAlive", "()Z", native_thread_isAlive},
        {"java/lang/Thread", "interrupt", "()V", native_thread_interrupt},
        {"java/lang/Thread", "isInterrupted", "()Z", native_thread_isInterrupted},
        {"java/lang/Thread", "interrupted", "()Z", native_thread_interrupted},
        {"java/lang/Thread", "setPriority", "(I)V", native_thread_setPriority},
        {"java/lang/Thread", "getPriority", "()I", native_thread_getPriority},
        {"java/lang/Thread", "setName", "(Ljava/lang/String;)V", native_thread_setName},
        {"java/lang/Thread", "getName", "()Ljava/lang/String;", native_thread_getName},
        {"java/lang/Thread", "activeCount", "()I", native_thread_activeCount},
        {"java/lang/Thread", "holdsLock", "(Ljava/lang/Object;)Z", native_thread_holdsLock},
        {"java/lang/Thread", "<init>", "()V", native_thread_init},
        {"java/lang/Thread", "<init>", "(Ljava/lang/Runnable;)V", native_thread_init_runnable},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * javax.microedition.midlet.MIDlet native methods
 * 
 * MIDlet lifecycle management:
 * - notifyDestroyed(): Called by MIDlet to tell AMS it wants to be destroyed
 * - notifyPaused(): Called by MIDlet to tell AMS it wants to be paused
 * These methods are protected in MIDlet class and called from startApp/pauseApp/destroyApp
 */

/* Global MIDlet state */
static bool g_midlet_destroyed = false;
static bool g_midlet_paused = false;

/* MIDlet.notifyDestroyed() - tell AMS the MIDlet wants to be destroyed */
static JavaValue native_midlet_notifyDestroyed(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    fprintf(stderr, "[MIDlet] notifyDestroyed() called - MIDlet requests destruction\n");
    g_midlet_destroyed = true;
    g_midlet_paused = false;
    
    /* Stop the JVM main loop */
    if (jvm) {
        jvm->running = false;
    }
    
    return NATIVE_RETURN_VOID();
}

/* MIDlet.notifyPaused() - tell AMS the MIDlet wants to be paused */
static JavaValue native_midlet_notifyPaused(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    fprintf(stderr, "[MIDlet] notifyPaused() called - MIDlet requests pause\n");
    g_midlet_paused = true;
    
    return NATIVE_RETURN_VOID();
}

/* MIDlet.resumeApp() - called by AMS to resume a paused MIDlet 
 * This is protected, called by the system, not by the MIDlet itself */
static JavaValue native_midlet_resumeApp(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    fprintf(stderr, "[MIDlet] resumeApp() called\n");
    g_midlet_paused = false;
    
    /* Find and call startApp on the MIDlet */
    JavaObject* midlet = (JavaObject*)args[0].ref;
    if (midlet && midlet->header.clazz) {
        JavaMethod* startApp = jvm_resolve_method(jvm, midlet->header.clazz, "startApp", "()V");
        if (startApp) {
            JavaValue result;
            execute_method(jvm, thread, startApp, args, &result);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Check if MIDlet is destroyed */
bool midlet_is_destroyed(void) {
    return g_midlet_destroyed;
}

/* Check if MIDlet is paused */
bool midlet_is_paused(void) {
    return g_midlet_paused;
}

/* Reset MIDlet state (for new MIDlet load) */
void midlet_reset_state(void) {
    g_midlet_destroyed = false;
    g_midlet_paused = false;
}

void init_javax_microedition_midlet_MIDlet(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/midlet/MIDlet", "notifyDestroyed", "()V", native_midlet_notifyDestroyed},
        {"javax/microedition/midlet/MIDlet", "notifyPaused", "()V", native_midlet_notifyPaused},
        {"javax/microedition/midlet/MIDlet", "resumeApp", "()V", native_midlet_resumeApp},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Throwable native methods
 */

static JavaValue native_throwable_fillInStackTrace(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* throwable = NATIVE_ARG_OBJECT(args, 0);
    
    /* TODO: Implement stack trace capture */
    (void)throwable;
    
    return NATIVE_RETURN_OBJECT(throwable);
}

void init_java_lang_throwable(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Throwable", "fillInStackTrace", "()Ljava/lang/Throwable;", native_throwable_fillInStackTrace},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.util.Random native methods
 * 
 * Random uses a simple linear congruential generator:
 * seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1)
 * 
 * We store the seed in the first field of the Random object.
 */

/* Helper to get seed from Random object - ИСПРАВЛЕНО: используем native_get_field_value */
static jlong random_get_seed(JavaObject* obj) {
    if (!obj) return 0;
    return native_get_field_value(obj, "seed").j;
}

/* Helper to set seed in Random object - ИСПРАВЛЕНО: используем native_set_field_value */
static void random_set_seed(JavaObject* obj, jlong seed) {
    if (!obj) return;
    JavaValue val = { .j = seed };
    native_set_field_value(obj, "seed", val);
}

/* Random() - constructor with time-based seed */
static JavaValue native_random_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize seed with current time */
    jlong seed;
#ifdef _WIN32
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    seed = counter.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    seed = (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
    
    /* Apply the initial scramble: seed ^ 0x5DEECE66DL */
    seed ^= 0x5DEECE66DLL;
    
    random_set_seed(obj, seed);
    
    NATIVE_DEBUG("<init>: obj=%p, seed=%lld", (void*)obj, (long long)seed);
    
    return NATIVE_RETURN_VOID();
}

/* Random(long seed) - constructor with explicit seed */
static JavaValue native_random_init_seed(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong seed = args[1].j;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Apply the initial scramble: seed ^ 0x5DEECE66DL */
    seed ^= 0x5DEECE66DLL;
    
    random_set_seed(obj, seed);
    
    NATIVE_DEBUG("<init>(seed): obj=%p, seed=%lld", (void*)obj, (long long)seed);
    
    return NATIVE_RETURN_VOID();
}

/* Random.next(int bits) - generate next random value */
static JavaValue native_random_next(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint bits = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: используем random_get_seed/random_set_seed вместо указателя */
    jlong seed = random_get_seed(obj);
    
    /* seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1) */
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    random_set_seed(obj, seed);
    
    /* return (int)(seed >>> (48 - bits)) */
    jint result = (jint)(seed >> (48 - bits));
    
    return NATIVE_RETURN_INT(result);
}

/* Random.nextInt() - random integer */
static JavaValue native_random_nextInt(JVM* jvm, JavaThread* thread,
JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: используем random_get_seed/random_set_seed */
    jlong seed = random_get_seed(obj);
    
    /* Generate next random value (32 bits) */
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    random_set_seed(obj, seed);
    
    jint result = (jint)(seed >> 16);
    
    NATIVE_DEBUG("nextInt(): result=%d, seed=%lld", result, (long long)seed);
    
    return NATIVE_RETURN_INT(result);
}

/* Random.nextInt(int bound) - random integer in [0, bound) */
static JavaValue native_random_nextIntBound(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint bound = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    if (bound <= 0) {
        native_throw_iae(jvm, thread, "bound must be positive");
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: используем random_get_seed/random_set_seed */
    jlong seed = random_get_seed(obj);
    
    jint result;
    if ((bound & -bound) == bound) {
        /* bound is a power of 2 */
        seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
        result = (jint)((bound * (seed >> 17)) >> 31);
    } else {
        /* Reject samples that would produce bias */
        jint val;
        do {
            seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
            val = (jint)(seed >> 17);
            jint r = val % bound;
            /* Check for bias */
            while (val - r + (bound - 1) < 0) {
                seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
                val = (jint)(seed >> 17);
                r = val % bound;
            }
            result = r;
            break;  /* Simplified - just take the first value */
        } while (0);
    }
    
    random_set_seed(obj, seed);
    
    NATIVE_DEBUG("nextInt(%d): result=%d, seed=%lld", bound, result, (long long)seed);
    
    return NATIVE_RETURN_INT(result);
}

/* Random.nextLong() - random long */
static JavaValue native_random_nextLong(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_LONG(0);
    }
    
    /* ИСПРАВЛЕНО: используем random_get_seed/random_set_seed */
    jlong seed = random_get_seed(obj);
    
    /* Generate two 32-bit values and combine */
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint high = (jint)(seed >> 16);
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint low = (jint)(seed >> 16);
    random_set_seed(obj, seed);
    
    jlong result = ((jlong)high << 32) | (low & 0xFFFFFFFFLL);
    
    return NATIVE_RETURN_LONG(result);
}

/* Random.nextFloat() - random float in [0, 1) */
static JavaValue native_random_nextFloat(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_FLOAT(0.0f);
    }
    
    /* ИСПРАВЛЕНО: используем random_get_seed/random_set_seed */
    jlong seed = random_get_seed(obj);
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    random_set_seed(obj, seed);
    
    jfloat result = (jfloat)(seed >> 24) / (jfloat)(1LL << 24);
    
    return NATIVE_RETURN_FLOAT(result);
}

/* Random.nextDouble() - random double in [0, 1) */
static JavaValue native_random_nextDouble(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_DOUBLE(0.0);
    }
    
    /* ИСПРАВЛЕНО: используем random_get_seed/random_set_seed */
    jlong seed = random_get_seed(obj);
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint high = (jint)(seed >> 16);
    seed = (seed * 0x5DEECE66DLL + 0xBL) & ((1LL << 48) - 1);
    jint low = (jint)(seed >> 16);
    random_set_seed(obj, seed);
    
    jlong combined = ((jlong)high << 27) | (low >> 5);
    jdouble result = (jdouble)combined / (jdouble)(1LL << 53);
    
    return NATIVE_RETURN_DOUBLE(result);
}

/* Random.setSeed(long) - set the seed */
static JavaValue native_random_setSeed(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong seed = args[1].j;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Apply the initial scramble: seed ^ 0x5DEECE66DL */
    seed ^= 0x5DEECE66DLL;
    
    random_set_seed(obj, seed);
    
    return NATIVE_RETURN_VOID();
}

/*
 * java.lang.StringBuffer native methods
 * 
 * StringBuffer is used for building strings. We need to implement append() 
 * which returns 'this' for method chaining, and toString().
 */

/* StringBuffer buffer field access */
#define STRINGBUFFER_INITIAL_CAPACITY 16

/* ИСПРАВЛЕНИЕ: Fallback storage for StringBuffer objects that don't have enough fields.
 * Some JAR files may have StringBuffer class with fewer than 3 instance fields.
 * We use a hash table to store buffer state for such objects.
 */
#define STRINGBUFFER_FALLBACK_SIZE 64

typedef struct {
    void* obj_ptr;
    char* buffer;
    int length;
    int capacity;
} StringBufferFallback;

static StringBufferFallback g_stringbuffer_fallback[STRINGBUFFER_FALLBACK_SIZE];
static int g_stringbuffer_fallback_count = 0;

/* Helper: Check if object has enough instance fields for inline storage
 * ИСПРАВЛЕНО: Всегда возвращаем false чтобы использовать fallback механизм,
 * так как прямое использование field[0/1/2] может конфликтовать с реальными полями Java
 */
static bool stringbuffer_has_enough_fields(JavaObject* obj) {
    (void)obj;
    /* Всегда используем fallback для безопасности */
    return false;
}

/* Helper: Find or create fallback entry for object */
static StringBufferFallback* stringbuffer_get_fallback(JavaObject* obj) {
    for (int i = 0; i < g_stringbuffer_fallback_count; i++) {
        if (g_stringbuffer_fallback[i].obj_ptr == obj) {
            return &g_stringbuffer_fallback[i];
        }
    }
    
    /* Create new entry if space available */
    if (g_stringbuffer_fallback_count < STRINGBUFFER_FALLBACK_SIZE) {
        StringBufferFallback* entry = &g_stringbuffer_fallback[g_stringbuffer_fallback_count++];
        entry->obj_ptr = obj;
        entry->buffer = NULL;
        entry->length = 0;
        entry->capacity = 0;
        return entry;
    }
    
    return NULL;
}

static char* stringbuffer_get_buffer(JavaObject* obj) {
    if (!obj) return NULL;
    
    /* Check if object has enough fields for inline storage */
    if (stringbuffer_has_enough_fields(obj)) {
        /* Use inline fields */
        if (obj->fields[0].ref == NULL) {
            obj->fields[0].ref = calloc(1, 1024);
            obj->fields[1].i = 0;
            obj->fields[2].i = 1024;
        }
        return (char*)obj->fields[0].ref;
    } else {
        /* Use fallback storage */
        StringBufferFallback* fallback = stringbuffer_get_fallback(obj);
        if (!fallback) return NULL;
        
        if (fallback->buffer == NULL) {
            fallback->buffer = calloc(1, 1024);
            fallback->length = 0;
            fallback->capacity = 1024;
        }
        return fallback->buffer;
    }
}

static int* stringbuffer_get_length_ptr(JavaObject* obj) {
    if (!obj) return NULL;
    
    if (stringbuffer_has_enough_fields(obj)) {
        return &obj->fields[1].i;
    } else {
        StringBufferFallback* fallback = stringbuffer_get_fallback(obj);
        return fallback ? &fallback->length : NULL;
    }
}

static int* stringbuffer_get_capacity_ptr(JavaObject* obj) {
    if (!obj) return NULL;
    
    if (stringbuffer_has_enough_fields(obj)) {
        return &obj->fields[2].i;
    } else {
        StringBufferFallback* fallback = stringbuffer_get_fallback(obj);
        return fallback ? &fallback->capacity : NULL;
    }
}

/* Helper: Update buffer pointer after realloc */
static void stringbuffer_set_buffer(JavaObject* obj, char* buffer) {
    if (!obj) return;
    
    if (stringbuffer_has_enough_fields(obj)) {
        obj->fields[0].ref = buffer;
    } else {
        StringBufferFallback* fallback = stringbuffer_get_fallback(obj);
        if (fallback) fallback->buffer = buffer;
    }
}

/* StringBuffer.append(String) */
static JavaValue native_stringbuffer_append_string(JVM* jvm, JavaThread* thread,
JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaString* str = (JavaString*)args[1].ref;

    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }

    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    int* cap_ptr = stringbuffer_get_capacity_ptr(obj);

    if (str && buffer && len_ptr && cap_ptr) {
        /* Use string_utf8() to properly convert from jchar[] if needed */
        const char* utf8 = string_utf8(jvm, str);
        if (!utf8) utf8 = "";
        int str_len = strlen(utf8);
        
        /* Проверка: нужно ли расширять буфер */
        if (*len_ptr + str_len >= *cap_ptr) {
            int new_cap = (*cap_ptr + str_len) * 2;
            char* new_buffer = (char*)realloc(buffer, new_cap);
            if (!new_buffer) {
                native_throw_oome(jvm, thread);
                return NATIVE_RETURN_OBJECT(NULL);
            }
            stringbuffer_set_buffer(obj, new_buffer);
            buffer = new_buffer;
            *cap_ptr = new_cap;
        }
        
        memcpy(buffer + *len_ptr, utf8, str_len);
        *len_ptr += str_len;
        buffer[*len_ptr] = '\0';
    }
    
    /* Return this for method chaining */
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(int) */
static JavaValue native_stringbuffer_append_int(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint value = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    /* Debug: verify object's class pointer */
    if (obj->header.clazz && obj->header.clazz->class_name) {
        NATIVE_DEBUG("StringBuffer.append(%d): obj=%p, class=%s", 
                value, (void*)obj, obj->header.clazz->class_name);
    } else {
        NATIVE_DEBUG("StringBuffer.append(%d): obj=%p, INVALID CLASS POINTER!",
                value, (void*)obj);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%d", value);
        if (written > 0 && *len_ptr + written < 1024) {  /* Bounds check */
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(long) */
static JavaValue native_stringbuffer_append_long(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jlong value = args[1].j;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%lld", (long long)value);
        if (written > 0) {
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(float) */
static JavaValue native_stringbuffer_append_float(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jfloat value = args[1].f;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%g", (double)value);
        if (written > 0) {
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(double) */
static JavaValue native_stringbuffer_append_double(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jdouble value = args[1].d;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        char num_buf[32];
        int written = snprintf(num_buf, sizeof(num_buf), "%g", value);
        if (written > 0) {
            memcpy(buffer + *len_ptr, num_buf, written);
            *len_ptr += written;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(boolean) */
static JavaValue native_stringbuffer_append_boolean(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jboolean value = args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        const char* str = value ? "true" : "false";
        int str_len = strlen(str);
        memcpy(buffer + *len_ptr, str, str_len);
        *len_ptr += str_len;
        buffer[*len_ptr] = '\0';
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(char) */
static JavaValue native_stringbuffer_append_char(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jchar value = (jchar)args[1].i;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        /* Simple: just add the char as a byte if it's ASCII */
        if (value < 128) {
            buffer[*len_ptr] = (char)value;
            (*len_ptr)++;
            buffer[*len_ptr] = '\0';
        }
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.append(Object) */
static JavaValue native_stringbuffer_append_object(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* value = (JavaObject*)args[1].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr) {
        if (value) {
            /* Call toString() on the object - simplified, just append class name */
            const char* str = "Object";
            int str_len = strlen(str);
            memcpy(buffer + *len_ptr, str, str_len);
            *len_ptr += str_len;
        } else {
            const char* str = "null";
            int str_len = strlen(str);
            memcpy(buffer + *len_ptr, str, str_len);
            *len_ptr += str_len;
        }
        buffer[*len_ptr] = '\0';
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

/* StringBuffer.toString() */
static JavaValue native_stringbuffer_toString(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_OBJECT(NULL);
    }
    
    char* buffer = stringbuffer_get_buffer(obj);
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    
    if (buffer && len_ptr && *len_ptr >= 0) {
        /* Truncate to actual length */
        char saved = buffer[*len_ptr];
        buffer[*len_ptr] = '\0';
        JavaString* str = jvm_new_string(jvm, buffer);
        buffer[*len_ptr] = saved;
        return NATIVE_RETURN_OBJECT(str);
    }
    
    return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, ""));
}

/* StringBuffer.length() */
static JavaValue native_stringbuffer_length(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    return NATIVE_RETURN_INT(len_ptr ? *len_ptr : 0);
}

/* StringBuffer.setLength(int) */
static JavaValue native_stringbuffer_setlength(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint new_length = args[1].i;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    if (new_length < 0) {
        /* StringIndexOutOfBoundsException - but for simplicity, just ignore */
        return NATIVE_RETURN_VOID();
    }
    
    int* len_ptr = stringbuffer_get_length_ptr(obj);
    char* buffer = stringbuffer_get_buffer(obj);
    int* cap_ptr = stringbuffer_get_capacity_ptr(obj);
    
    if (len_ptr && buffer && cap_ptr) {
        if (new_length > *cap_ptr) {
            /* Need to expand buffer */
            int new_cap = new_length * 2;
            char* new_buffer = (char*)realloc(buffer, new_cap);
            if (new_buffer) {
                stringbuffer_set_buffer(obj, new_buffer);
                buffer = new_buffer;
                *cap_ptr = new_cap;
            }
        }
        
        /* If growing, fill with nulls */
        if (new_length > *len_ptr) {
            memset(buffer + *len_ptr, 0, new_length - *len_ptr);
        }
        
        *len_ptr = new_length;
        if (buffer) buffer[*len_ptr] = '\0';
    }
    
    return NATIVE_RETURN_VOID();
}

void init_java_lang_stringbuffer(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/StringBuffer", "append", "(Ljava/lang/String;)Ljava/lang/StringBuffer;", native_stringbuffer_append_string},
        {"java/lang/StringBuffer", "append", "(I)Ljava/lang/StringBuffer;", native_stringbuffer_append_int},
        {"java/lang/StringBuffer", "append", "(J)Ljava/lang/StringBuffer;", native_stringbuffer_append_long},
        {"java/lang/StringBuffer", "append", "(F)Ljava/lang/StringBuffer;", native_stringbuffer_append_float},
        {"java/lang/StringBuffer", "append", "(D)Ljava/lang/StringBuffer;", native_stringbuffer_append_double},
        {"java/lang/StringBuffer", "append", "(Z)Ljava/lang/StringBuffer;", native_stringbuffer_append_boolean},
        {"java/lang/StringBuffer", "append", "(C)Ljava/lang/StringBuffer;", native_stringbuffer_append_char},
        {"java/lang/StringBuffer", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuffer;", native_stringbuffer_append_object},
        {"java/lang/StringBuffer", "toString", "()Ljava/lang/String;", native_stringbuffer_toString},
        {"java/lang/StringBuffer", "length", "()I", native_stringbuffer_length},
        {"java/lang/StringBuffer", "setLength", "(I)V", native_stringbuffer_setlength},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/lang/StringBuffer native methods");
}

/*
 * java.lang.StringBuilder native methods
 * Same implementation as StringBuffer (uses StringBuffer handlers)
 */

void init_java_lang_stringbuilder(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", native_stringbuffer_append_string},
        {"java/lang/StringBuilder", "append", "(I)Ljava/lang/StringBuilder;", native_stringbuffer_append_int},
        {"java/lang/StringBuilder", "append", "(J)Ljava/lang/StringBuilder;", native_stringbuffer_append_long},
        {"java/lang/StringBuilder", "append", "(F)Ljava/lang/StringBuilder;", native_stringbuffer_append_float},
        {"java/lang/StringBuilder", "append", "(D)Ljava/lang/StringBuilder;", native_stringbuffer_append_double},
        {"java/lang/StringBuilder", "append", "(Z)Ljava/lang/StringBuilder;", native_stringbuffer_append_boolean},
        {"java/lang/StringBuilder", "append", "(C)Ljava/lang/StringBuilder;", native_stringbuffer_append_char},
        {"java/lang/StringBuilder", "append", "(Ljava/lang/Object;)Ljava/lang/StringBuilder;", native_stringbuffer_append_object},
        {"java/lang/StringBuilder", "toString", "()Ljava/lang/String;", native_stringbuffer_toString},
        {"java/lang/StringBuilder", "length", "()I", native_stringbuffer_length},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/lang/StringBuilder native methods");
}

/*
 * java.util.Vector native methods
 */

static void vector_init_internal(JVM* jvm, JavaObject* vec, int initialCapacity) {
    if (!vec) return;
    
    /* ИСПРАВЛЕНО: Используем native_set_field_value */
    int capacity = initialCapacity > 0 ? initialCapacity : 10;
    JavaArray* arr = jvm_new_array(jvm, DESC_OBJECT, capacity);
    
    JavaValue arr_val = { .ref = arr };
    JavaValue count_val = { .i = 0 };
    
    native_set_field_value(vec, "elementData", arr_val);
    native_set_field_value(vec, "elementCount", count_val);
    
    NATIVE_DEBUG("init: initialized elementData with capacity %d", capacity);
}

static JavaValue native_vector_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    NATIVE_DEBUG("<init>(): initializing vector %p", (void*)vec);
    vector_init_internal(jvm, vec, 10);
    return NATIVE_RETURN_VOID();
}

/* Vector(int initialCapacity) constructor */
static JavaValue native_vector_init_int(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    jint initialCapacity = args[1].i;
    NATIVE_DEBUG("<init>(%d): initializing vector %p", initialCapacity, (void*)vec);
    vector_init_internal(jvm, vec, initialCapacity);
    return NATIVE_RETURN_VOID();
}

/* Vector(int initialCapacity, int capacityIncrement) constructor */
static JavaValue native_vector_init_int_int(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    jint initialCapacity = args[1].i;
    jint capacityIncrement = args[2].i;
    (void)capacityIncrement; /* We don't use this yet */
    NATIVE_DEBUG("<init>(%d, %d): initializing vector %p", initialCapacity, capacityIncrement, (void*)vec);
    vector_init_internal(jvm, vec, initialCapacity);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_vector_add(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    JavaValue element = args[1];
    
    if (!vec) return NATIVE_RETURN_INT(1);
    
    /* ИСПРАВЛЕНО: Используем native_get/set_field_value */
    JavaArray* arr = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int count = native_get_field_value(vec, "elementCount").i;
    
    if (arr) {
        /* Grow array if needed */
        if (count >= arr->length) {
            JavaArray* new_arr = jvm_new_array(jvm, DESC_OBJECT, arr->length * 2 + 1);
            if (new_arr) {
                /* CRITICAL FIX: Object arrays store void* pointers, not JavaValue structs */
                memcpy(array_data(new_arr), array_data(arr), arr->length * sizeof(void*));
                arr = new_arr;
                /* Update elementData field */
                JavaValue arr_val = { .ref = arr };
                native_set_field_value(vec, "elementData", arr_val);
            }
        }
        if (count < arr->length) {
            /* CRITICAL FIX: Use array_set_ref for object arrays */
            array_set_ref(arr, count, element.ref);
            JavaValue count_val = { .i = count + 1 };
            native_set_field_value(vec, "elementCount", count_val);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* addElement is the same as add but returns void */
static JavaValue native_vector_add_element(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    JavaValue element = args[1];
    
    NATIVE_DEBUG("addElement: obj=%p, element=%p", (void*)vec, element.ref);
    
    if (!vec) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get/set_field_value */
    JavaArray* arr = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int count = native_get_field_value(vec, "elementCount").i;
    
    /* Auto-initialize if elementData is NULL (constructor might not have been called) */
    if (!arr) {
        NATIVE_DEBUG("addElement: auto-initializing elementData");
        arr = jvm_new_array(jvm, DESC_OBJECT, 10);
        JavaValue arr_val = { .ref = arr };
        native_set_field_value(vec, "elementData", arr_val);
    }
    
    if (arr) {
        /* Grow array if needed */
        if (count >= arr->length) {
            int new_size = arr->length * 2 + 1;
            JavaArray* new_arr = jvm_new_array(jvm, DESC_OBJECT, new_size);
            if (new_arr) {
                /* CRITICAL FIX: Object arrays store void* pointers, not JavaValue structs */
                memcpy(array_data(new_arr), array_data(arr), arr->length * sizeof(void*));
                arr = new_arr;
                /* Update elementData field */
                JavaValue arr_val = { .ref = arr };
                native_set_field_value(vec, "elementData", arr_val);
            }
        }
        if (count < arr->length) {
            /* CRITICAL FIX: Use array_set_ref for object arrays */
            array_set_ref(arr, count, element.ref);
            JavaValue count_val = { .i = count + 1 };
            native_set_field_value(vec, "elementCount", count_val);
            NATIVE_DEBUG("addElement: stored element at index %d, new count=%d", count, count + 1);
        }
    } else {
        NATIVE_DEBUG("addElement: ERROR - arr is NULL");
    }
    
    return NATIVE_RETURN_VOID();
}

/* Vector.insertElementAt(Object obj, int index) - insert at specific position */
static JavaValue native_vector_insertElementAt(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    JavaValue element = args[1];
    jint index = args[2].i;
    
    NATIVE_DEBUG("insertElementAt: obj=%p, index=%d, element=%p", 
            (void*)vec, index, element.ref);
    
    if (!vec) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get/set_field_value */
    JavaArray* arr = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int count = native_get_field_value(vec, "elementCount").i;
    
    if (!arr) return NATIVE_RETURN_VOID();
    
    /* Bounds check */
    if (index < 0 || index > count) {
        /* Should throw ArrayIndexOutOfBoundsException */
        return NATIVE_RETURN_VOID();
    }
    
    /* Grow array if needed */
    if (count >= arr->length) {
        JavaArray* new_arr = jvm_new_array(jvm, DESC_OBJECT, arr->length * 2 + 1);
        if (new_arr) {
            memcpy(array_data(new_arr), array_data(arr), arr->length * sizeof(void*));
            arr = new_arr;
            JavaValue arr_val = { .ref = arr };
            native_set_field_value(vec, "elementData", arr_val);
        }
    }
    
    /* Shift elements to make room */
    if (index < count) {
        void** data = (void**)array_data(arr);
        for (int i = count; i > index; i--) {
            data[i] = data[i - 1];
        }
    }
    
    /* Insert element */
    array_set_ref(arr, index, element.ref);
    JavaValue count_val = { .i = count + 1 };
    native_set_field_value(vec, "elementCount", count_val);
    
    return NATIVE_RETURN_VOID();
}

/* Vector.setElementAt(Object obj, int index) - replace element at position */
static JavaValue native_vector_setElementAt(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    JavaValue element = args[1];
    jint index = args[2].i;
    
    if (!vec) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* arr = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int count = native_get_field_value(vec, "elementCount").i;
    
    if (arr && index >= 0 && index < count) {
        array_set_ref(arr, index, element.ref);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_vector_get(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    if (!vec) return NATIVE_RETURN_NULL();
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* arr = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int count = native_get_field_value(vec, "elementCount").i;
    
    if (arr && index >= 0 && index < count) {
        /* CRITICAL FIX: Use array_get_ref for object arrays */
        return NATIVE_RETURN_OBJECT(array_get_ref(arr, index));
    }
    
    return NATIVE_RETURN_NULL();
}

static JavaValue native_vector_size(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    
    if (!vec) return NATIVE_RETURN_INT(0);
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    return NATIVE_RETURN_INT(native_get_field_value(vec, "elementCount").i);
}

static JavaValue native_vector_isEmpty(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    
    if (!vec) return NATIVE_RETURN_INT(1);
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    return NATIVE_RETURN_INT(native_get_field_value(vec, "elementCount").i == 0 ? 1 : 0);
}

/* Vector.copyInto(Object[] array) - copies elements into array */
static JavaValue native_vector_copyInto(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    JavaArray* dest_array = (JavaArray*)args[1].ref;
    
    if (!vec || !dest_array) {
        NATIVE_DEBUG("copyInto: null parameter (vec=%p, array=%p)", 
                (void*)vec, (void*)dest_array);
        return NATIVE_RETURN_VOID();
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* src_array = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int element_count = native_get_field_value(vec, "elementCount").i;
    
    if (!src_array) {
        NATIVE_DEBUG("copyInto: no elementData field found");
        return NATIVE_RETURN_VOID();
    }
    
    int copy_count = element_count;
    if (copy_count > (int)dest_array->length) {
        copy_count = dest_array->length;
    }
    
    NATIVE_DEBUG("copyInto: copying %d elements (vector size=%d, array len=%u)",
            copy_count, element_count, dest_array->length);
    
    /* Copy elements from source array to destination array using helper functions */
    for (int i = 0; i < copy_count; i++) {
        void* ref = array_get_ref(src_array, i);
        array_set_ref(dest_array, i, ref);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Vector.elements() - returns an Enumeration over the vector elements */
static JavaValue native_vector_elements(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* vec = (JavaObject*)args[0].ref;
    
    if (!vec) {
        NATIVE_DEBUG("elements: null vector");
        return NATIVE_RETURN_NULL();
    }
    
    /* ИСПРАВЛЕНО: Используем native_get_field_value */
    JavaArray* src_array = (JavaArray*)native_get_field_value(vec, "elementData").ref;
    int element_count = native_get_field_value(vec, "elementCount").i;
    
    NATIVE_DEBUG("elements: src_array=%p, element_count=%d", 
            (void*)src_array, element_count);
    
    if (!src_array) {
        NATIVE_DEBUG("elements: WARNING - elementData is NULL!");
        /* Return an empty enumeration */
        element_count = 0;
    }
    
    /* Create a new Enumeration-like object with:
     * field 0: elements array
     * field 1: count
     * field 2: current index (starts at 0)
     */
    JavaClass* iter_class = jvm_load_class(jvm, "java/util/Enumeration");
    if (!iter_class) {
        iter_class = jvm_load_class(jvm, "java/lang/Object");
    }
    
    /* Ensure the class has fields */
    if (iter_class->fields_count == 0) {
        iter_class->fields = (JavaField*)calloc(3, sizeof(JavaField));
        iter_class->fields[0].name = strdup("elements");
        iter_class->fields[0].descriptor = strdup("[Ljava/lang/Object;");
        iter_class->fields[1].name = strdup("count");
        iter_class->fields[1].descriptor = strdup("I");
        iter_class->fields[2].name = strdup("index");
        iter_class->fields[2].descriptor = strdup("I");
        iter_class->fields_count = 3;
        iter_class->instance_size = sizeof(ObjectHeader) + 3 * sizeof(JavaValue);
    }
    
    JavaObject* iter_obj = jvm_new_object(jvm, iter_class);
    if (iter_obj && iter_class->fields_count >= 3) {
        /* ИСПРАВЛЕНО: Используем native_set_field_value для установки полей */
        JavaValue arr_val = { .ref = src_array };
        JavaValue count_val = { .i = element_count };
        JavaValue index_val = { .i = 0 };
        native_set_field_value(iter_obj, "elements", arr_val);
        native_set_field_value(iter_obj, "count", count_val);
        native_set_field_value(iter_obj, "index", index_val);
    }
    
    NATIVE_DEBUG("elements: returning enumeration object %p with %d elements", 
            (void*)iter_obj, element_count);
    return NATIVE_RETURN_OBJECT(iter_obj);
}

void init_java_util_vector(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Vector", "<init>", "()V", native_vector_init},
        {"java/util/Vector", "<init>", "(I)V", native_vector_init_int},
        {"java/util/Vector", "<init>", "(II)V", native_vector_init_int_int},
        {"java/util/Vector", "add", "(Ljava/lang/Object;)Z", native_vector_add},
        {"java/util/Vector", "addElement", "(Ljava/lang/Object;)V", native_vector_add_element},
        {"java/util/Vector", "insertElementAt", "(Ljava/lang/Object;I)V", native_vector_insertElementAt},
        {"java/util/Vector", "setElementAt", "(Ljava/lang/Object;I)V", native_vector_setElementAt},
        {"java/util/Vector", "get", "(I)Ljava/lang/Object;", native_vector_get},
        {"java/util/Vector", "elementAt", "(I)Ljava/lang/Object;", native_vector_get},
        {"java/util/Vector", "size", "()I", native_vector_size},
        {"java/util/Vector", "isEmpty", "()Z", native_vector_isEmpty},
        {"java/util/Vector", "copyInto", "([Ljava/lang/Object;)V", native_vector_copyInto},
        {"java/util/Vector", "elements", "()Ljava/util/Enumeration;", native_vector_elements},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/util/Vector native methods");
}

/* Enumeration methods - used by Vector.elements() */
static JavaValue native_enumeration_hasMoreElements(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (!enum_obj) {
        fprintf(stderr, "[Enumeration] hasMoreElements: null enumeration\n");
        return NATIVE_RETURN_INT(0);
    }
    
    /* ИСПРАВЛЕНО: используем native_get_field_value */
    JavaArray* elements = (JavaArray*)native_get_field_value(enum_obj, "elements").ref;
    jint count = native_get_field_value(enum_obj, "count").i;
    jint index = native_get_field_value(enum_obj, "index").i;
    
    jboolean result = (elements && index < count) ? JNI_TRUE : JNI_FALSE;
    fprintf(stderr, "[Enumeration] hasMoreElements: index=%d, count=%d, result=%d\n", index, count, result);
    return NATIVE_RETURN_INT(result);
}

static JavaValue native_enumeration_nextElement(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (!enum_obj) {
        fprintf(stderr, "[Enumeration] nextElement: null enumeration\n");
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* ИСПРАВЛЕНО: используем native_get_field_value */
    JavaArray* elements = (JavaArray*)native_get_field_value(enum_obj, "elements").ref;
    jint count = native_get_field_value(enum_obj, "count").i;
    jint index = native_get_field_value(enum_obj, "index").i;
    
    JavaClass* clazz = enum_obj->header.clazz;
    fprintf(stderr, "[Enumeration] nextElement: elements=%p, count=%d, index=%d, class=%s\n",
            (void*)elements, count, index, clazz->class_name ? clazz->class_name : "(null)");
    
    if (!elements || index >= count) {
        fprintf(stderr, "[Enumeration] nextElement: no more elements (index=%d, count=%d)\n", index, count);
        /* Should throw NoSuchElementException, but for compatibility return null */
        return NATIVE_RETURN_NULL();
    }
    
    /* Get the element at current index using array_get_ref for object arrays */
    void* elem_ref = array_get_ref(elements, index);
    
    /* ИСПРАВЛЕНО: используем native_set_field_value для обновления index */
    JavaValue new_index = { .i = index + 1 };
    native_set_field_value(enum_obj, "index", new_index);
    
    /* Debug: check the element */
    if (elem_ref) {
        JavaObject* elem_obj = (JavaObject*)elem_ref;
        JavaClass* elem_class = elem_obj->header.clazz;
        fprintf(stderr, "[Enumeration] nextElement: returning element at index %d, elem=%p, class=%s\n", 
                index, elem_ref, elem_class && elem_class->class_name ? elem_class->class_name : "(null class)");
    } else {
        fprintf(stderr, "[Enumeration] nextElement: WARNING - null element at index %d\n", index);
    }
    
    return NATIVE_RETURN_OBJECT(elem_ref);
}

void init_java_util_enumeration(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Enumeration", "hasMoreElements", "()Z", native_enumeration_hasMoreElements},
        {"java/util/Enumeration", "nextElement", "()Ljava/lang/Object;", native_enumeration_nextElement},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/util/Enumeration native methods");
}

/*
 * java.util.Hashtable native methods
 */

static JavaValue native_hashtable_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ht = (JavaObject*)args[0].ref;
    if (!ht) return NATIVE_RETURN_VOID();
    
    /* ИСПРАВЛЕНО: используем native_set_field_value */
    JavaArray* arr = jvm_new_array(jvm, DESC_OBJECT, 11);
    if (arr) {
        JavaValue arr_val = { .ref = arr };
        native_set_field_value(ht, "table", arr_val);
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_hashtable_put(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ht = (JavaObject*)args[0].ref;
    JavaValue key = args[1];
    JavaValue value = args[2];
    
    if (!ht) return NATIVE_RETURN_NULL();
    
    /* ИСПРАВЛЕНО: используем native_get/set_field_value */
    JavaArray* arr = (JavaArray*)native_get_field_value(ht, "table").ref;
    if (!arr) {
        arr = jvm_new_array(jvm, DESC_OBJECT, 16);
        if (arr) {
            JavaValue arr_val = { .ref = arr };
            native_set_field_value(ht, "table", arr_val);
        }
    }
    /* For simplicity, we just mark that we have entries */
    (void)key; (void)value;
    
    return NATIVE_RETURN_NULL();
}

static JavaValue native_hashtable_get(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ht = (JavaObject*)args[0].ref;
    (void)ht;
    
    /* Simple stub - return null */
    return NATIVE_RETURN_NULL();
}

static JavaValue native_hashtable_size(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ht = (JavaObject*)args[0].ref;
    
    if (!ht) return NATIVE_RETURN_INT(0);
    
    /* ИСПРАВЛЕНО: используем native_get_field_value */
    jint count = native_get_field_value(ht, "count").i;
    return NATIVE_RETURN_INT(count);
}

/*
 * java.io.InputStreamReader native methods
 */

/* Helper to find the underlying InputStream in InputStreamReader */
/* ИСПРАВЛЕНО: используем native_get_field_value */
static JavaObject* get_inputstream_reader_stream(JavaObject* isr_obj) {
    if (!isr_obj) return NULL;
    
    JavaClass* clazz = isr_obj->header.clazz;
    if (!clazz) return NULL;
    
    fprintf(stderr, "[ISR] get_stream: clazz=%s, fields_count=%d\n", 
            clazz->class_name ? clazz->class_name : "(null)", clazz->fields_count);
    
    /* Try to get 'in' field directly */
    JavaObject* stream = (JavaObject*)native_get_field_value(isr_obj, "in").ref;
    if (stream) {
        fprintf(stderr, "[ISR]   Found 'in' stream: %p\n", (void*)stream);
        return stream;
    }
    
    /* If no 'in' field found, try to find InputStream by descriptor type */
    fprintf(stderr, "[ISR]   No 'in' field found, trying InputStream type...\n");
    for (int i = 0; i < clazz->fields_count; i++) {
        const char* desc = clazz->fields[i].descriptor;
        const char* name = clazz->fields[i].name;
        if (desc && strstr(desc, "InputStream") && name) {
            /* InputStream reference field - use helper function */
            stream = (JavaObject*)native_get_field_value(isr_obj, name).ref;
            if (stream) {
                fprintf(stderr, "[ISR]   Found InputStream at field '%s': %p\n", name, (void*)stream);
                return stream;
            }
        }
    }
    
    fprintf(stderr, "[ISR]   No InputStream field found!\n");
    return NULL;
}

static JavaValue native_inputstreamreader_read(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* isr = (JavaObject*)args[0].ref;
    
    if (!isr) {
        fprintf(stderr, "[ISR] read: NULL InputStreamReader\n");
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Get underlying InputStream */
    JavaObject* stream = get_inputstream_reader_stream(isr);
    if (!stream) {
        fprintf(stderr, "[ISR] read: No underlying stream found for isr=%p, clazz=%s, fields_count=%d\n",
                (void*)isr, isr->header.clazz->class_name, isr->header.clazz->fields_count);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Check if it's a ByteArrayInputStream */
    JavaClass* stream_class = stream->header.clazz;
    if (stream_class && stream_class->class_name && 
        strstr(stream_class->class_name, "ByteArrayInputStream")) {
        
        /* ИСПРАВЛЕНО: используем native_get_field_value */
        JavaArray* buf = (JavaArray*)native_get_field_value(stream, "buf").ref;
        jint pos = native_get_field_value(stream, "pos").i;
        jint count = native_get_field_value(stream, "count").i;
        
        if (buf && pos < count) {
            /* Read byte and convert to char (ISO-8859-1) */
            uint8_t* data = (uint8_t*)array_data(buf);
            jint result = data[pos];
            
            /* ИСПРАВЛЕНО: используем native_set_field_value для обновления pos */
            JavaValue new_pos = { .i = pos + 1 };
            native_set_field_value(stream, "pos", new_pos);
            
            return NATIVE_RETURN_INT(result);
        }
    }
    
    /* Default: end of stream */
    return NATIVE_RETURN_INT(-1);
}

static JavaValue native_inputstreamreader_read_array(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* isr = (JavaObject*)args[0].ref;
    JavaArray* cbuf = (JavaArray*)args[1].ref;
    
    if (!isr || !cbuf) return NATIVE_RETURN_INT(-1);
    
    /* Get underlying InputStream */
    JavaObject* stream = get_inputstream_reader_stream(isr);
    if (!stream) return NATIVE_RETURN_INT(-1);
    
    /* Check if it's a ByteArrayInputStream */
    JavaClass* stream_class = stream->header.clazz;
    if (stream_class && stream_class->class_name && 
        strstr(stream_class->class_name, "ByteArrayInputStream")) {
        
        /* ИСПРАВЛЕНО: используем native_get_field_value */
        JavaArray* buf = (JavaArray*)native_get_field_value(stream, "buf").ref;
        jint pos = native_get_field_value(stream, "pos").i;
        jint count = native_get_field_value(stream, "count").i;
        
        if (buf && pos < count) {
            uint8_t* src_data = (uint8_t*)array_data(buf);
            uint16_t* dst_data = (uint16_t*)array_data(cbuf);
            
            int to_read = count - pos;
            if (to_read > cbuf->length) to_read = cbuf->length;
            
            /* Copy bytes as chars (ISO-8859-1) */
            for (int i = 0; i < to_read; i++) {
                dst_data[i] = src_data[pos + i];
            }
            
            /* ИСПРАВЛЕНО: используем native_set_field_value для обновления pos */
            JavaValue new_pos = { .i = pos + to_read };
            native_set_field_value(stream, "pos", new_pos);
            
            return NATIVE_RETURN_INT(to_read);
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

static JavaValue native_inputstreamreader_close(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op for now */
    return NATIVE_RETURN_VOID();
}

/*
 * java.io.BufferedReader native methods
 */

/* Helper to find the underlying Reader in BufferedReader */
/* ИСПРАВЛЕНО: используем native_get_field_value */
static JavaObject* get_bufferedreader_reader(JavaObject* br_obj) {
    if (!br_obj) return NULL;
    
    /* Try 'in' field first */
    JavaObject* reader = (JavaObject*)native_get_field_value(br_obj, "in").ref;
    if (reader) return reader;
    
    /* Try 'reader' field */
    reader = (JavaObject*)native_get_field_value(br_obj, "reader").ref;
    if (reader) return reader;
    
    /* Try 'lock' field as fallback */
    reader = (JavaObject*)native_get_field_value(br_obj, "lock").ref;
    return reader;
}

static JavaValue native_bufferedreader_read(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* br = (JavaObject*)args[0].ref;
    
    if (!br) return NATIVE_RETURN_INT(-1);
    
    /* Get underlying Reader (InputStreamReader) */
    JavaObject* reader = get_bufferedreader_reader(br);
    if (!reader) return NATIVE_RETURN_INT(-1);
    
    /* Call read() on the underlying InputStreamReader */
    JavaClass* reader_class = reader->header.clazz;
    JavaMethod* read_method = jvm_resolve_method(jvm, reader_class, "read", "()I");
    
    if (read_method) {
        JavaValue reader_arg = { .ref = reader };
        JavaValue result;
        execute_method(jvm, thread, read_method, &reader_arg, &result);
        return result;
    }
    
    return NATIVE_RETURN_INT(-1);
}

static JavaValue native_bufferedreader_readline(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* br = (JavaObject*)args[0].ref;
    
    if (!br) return NATIVE_RETURN_NULL();
    
    /* Get underlying Reader */
    JavaObject* reader = get_bufferedreader_reader(br);
    if (!reader) return NATIVE_RETURN_NULL();
    
    /* Build string by reading characters */
    char buffer[4096];
    int len = 0;
    
    JavaClass* reader_class = reader->header.clazz;
    JavaMethod* read_method = jvm_resolve_method(jvm, reader_class, "read", "()I");
    
    if (!read_method) return NATIVE_RETURN_NULL();
    
    while (len < (int)sizeof(buffer) - 1) {
        JavaValue reader_arg = { .ref = reader };
        JavaValue result;
        execute_method(jvm, thread, read_method, &reader_arg, &result);
        
        jint ch = result.i;
        
        if (ch < 0) {
            /* End of stream */
            break;
        }
        
        if (ch == '\n') {
            break;
        }
        
        if (ch == '\r') {
            /* Check for \r\n */
            execute_method(jvm, thread, read_method, &reader_arg, &result);
            jint next = result.i;
            if (next >= 0 && next != '\n') {
                /* Put back - for simplicity, we just skip */
            }
            break;
        }
        
        buffer[len++] = (char)ch;
    }
    
    if (len == 0) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create String */
    buffer[len] = '\0';
    JavaString* str = jvm_new_string(jvm, buffer);
    JavaValue ret = { .ref = (JavaObject*)str };
    return ret;
}

static JavaValue native_bufferedreader_close(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op for now */
    return NATIVE_RETURN_VOID();
}

void init_java_io_inputstreamreader(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/InputStreamReader", "read", "()I", native_inputstreamreader_read},
        {"java/io/InputStreamReader", "read", "([C)I", native_inputstreamreader_read_array},
        {"java/io/InputStreamReader", "read", "([CII)I", native_inputstreamreader_read_array},
        {"java/io/InputStreamReader", "close", "()V", native_inputstreamreader_close},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/io/InputStreamReader native methods");
}

void init_java_io_bufferedreader(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/io/BufferedReader", "read", "()I", native_bufferedreader_read},
        {"java/io/BufferedReader", "readLine", "()Ljava/lang/String;", native_bufferedreader_readline},
        {"java/io/BufferedReader", "close", "()V", native_bufferedreader_close},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/io/BufferedReader native methods");
}

void init_java_util_hashtable(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Hashtable", "<init>", "()V", native_hashtable_init},
        {"java/util/Hashtable", "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", native_hashtable_put},
        {"java/util/Hashtable", "get", "(Ljava/lang/Object;)Ljava/lang/Object;", native_hashtable_get},
        {"java/util/Hashtable", "size", "()I", native_hashtable_size},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/util/Hashtable native methods");
}

void init_java_util_random(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Random", "<init>", "()V", native_random_init},
        {"java/util/Random", "<init>", "(J)V", native_random_init_seed},
        {"java/util/Random", "next", "(I)I", native_random_next},
        {"java/util/Random", "nextInt", "()I", native_random_nextInt},
        {"java/util/Random", "nextInt", "(I)I", native_random_nextIntBound},
        {"java/util/Random", "nextLong", "()J", native_random_nextLong},
        {"java/util/Random", "nextFloat", "()F", native_random_nextFloat},
        {"java/util/Random", "nextDouble", "()D", native_random_nextDouble},
        {"java/util/Random", "setSeed", "(J)V", native_random_setSeed},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/util/Random native methods");
}

/*
 * java.util.Timer native methods
 * SIMPLIFIED IMPLEMENTATION - runs synchronously in main thread
 * This avoids threading issues with non-thread-safe JVM
 */

/* Timer task entry */
typedef struct {
    JavaObject* timer_task;
    jlong next_run_time;    /* When to run (in ms since start) */
    jlong period_ms;        /* Period for repeating tasks, 0 for one-shot */
    bool active;
} TimerEntry;

#define MAX_TIMERS 16
static TimerEntry g_timers[MAX_TIMERS];
static int g_timer_count = 0;
static uint64_t g_start_time_ms = 0;

/* Get current time in milliseconds */
static uint64_t get_time_ms(void) {
#ifdef _WIN32
    return GetTickCount64();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
}

/* Process all pending timers - call from main loop */
void jvm_process_timers(JVM* jvm) {
    if (g_timer_count == 0) return;
    
    uint64_t now = get_time_ms() - g_start_time_ms;
    
    for (int i = 0; i < MAX_TIMERS; i++) {
        if (!g_timers[i].active || !g_timers[i].timer_task) continue;
        
        /* Check if it's time to run */
        if ((jlong)now >= g_timers[i].next_run_time) {
            /* Get the run method */
            JavaClass* task_class = g_timers[i].timer_task->header.clazz;
            if (!task_class) continue;
            
            JavaMethod* run_method = jvm_resolve_method(jvm, task_class, "run", "()V");
            if (!run_method) continue;
            
            /* Execute in main thread */
            JavaValue task_arg = { .ref = g_timers[i].timer_task };
            JavaValue result;
            JavaThread* thread = jvm_current_thread(jvm);
            if (thread && jvm->running) {
                execute_method(jvm, thread, run_method, &task_arg, &result);
            }
            
            /* Handle periodic vs one-shot */
            if (g_timers[i].period_ms > 0) {
                /* Schedule next run */
                g_timers[i].next_run_time = (jlong)now + g_timers[i].period_ms;
            } else {
                /* One-shot task done */
                g_timers[i].active = false;
                g_timer_count--;
            }
        }
    }
}

static JavaValue native_timer_schedule_task_delay(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)arg_count;
    (void)thread;
    JavaObject* timer_task = (JavaObject*)args[1].ref;
    jlong delay_ms = args[2].j;
    
    if (!timer_task) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize start time on first use */
    if (g_start_time_ms == 0) {
        g_start_time_ms = get_time_ms();
    }
    
    /* Find free slot */
    int slot = -1;
    for (int i = 0; i < MAX_TIMERS; i++) {
        if (!g_timers[i].active) {
            slot = i;
            break;
        }
    }
    
    if (slot < 0) {
        NATIVE_DEBUG("No free timer slots!");
        return NATIVE_RETURN_VOID();
    }
    
    uint64_t now = get_time_ms() - g_start_time_ms;
    g_timers[slot].timer_task = timer_task;
    g_timers[slot].next_run_time = (jlong)now + delay_ms;
    g_timers[slot].period_ms = 0;
    g_timers[slot].active = true;
    g_timer_count++;
    
    NATIVE_DEBUG("Scheduled one-shot task at slot %d, delay=%ld ms", slot, (long)delay_ms);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_timer_schedule_task_delay_period(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)arg_count;
    (void)thread;
    JavaObject* timer_task = (JavaObject*)args[1].ref;
    jlong delay_ms = args[2].j;
    jlong period_ms = args[4].j;
    
    if (!timer_task) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize start time on first use */
    if (g_start_time_ms == 0) {
        g_start_time_ms = get_time_ms();
    }
    
    /* Find free slot */
    int slot = -1;
    for (int i = 0; i < MAX_TIMERS; i++) {
        if (!g_timers[i].active) {
            slot = i;
            break;
        }
    }
    
    if (slot < 0) {
        NATIVE_DEBUG("No free timer slots!");
        return NATIVE_RETURN_VOID();
    }
    
    uint64_t now = get_time_ms() - g_start_time_ms;
    g_timers[slot].timer_task = timer_task;
    g_timers[slot].next_run_time = (jlong)now + delay_ms;
    g_timers[slot].period_ms = period_ms;
    g_timers[slot].active = true;
    g_timer_count++;
    
    NATIVE_DEBUG("Scheduled periodic task at slot %d, delay=%ld ms, period=%ld ms", 
            slot, (long)delay_ms, (long)period_ms);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_timer_cancel(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    /* Cancel all timers */
    for (int i = 0; i < MAX_TIMERS; i++) {
        g_timers[i].active = false;
        g_timers[i].timer_task = NULL;
    }
    g_timer_count = 0;
    
    NATIVE_DEBUG("All timers cancelled");
    return NATIVE_RETURN_VOID();
}

void init_java_util_timer(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Timer", "schedule", "(Ljava/util/TimerTask;J)V", native_timer_schedule_task_delay},
        {"java/util/Timer", "schedule", "(Ljava/util/TimerTask;JJ)V", native_timer_schedule_task_delay_period},
        {"java/util/Timer", "scheduleAtFixedRate", "(Ljava/util/TimerTask;JJ)V", native_timer_schedule_task_delay_period},
        {"java/util/Timer", "cancel", "()V", native_timer_cancel},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/util/Timer native methods");
}

/*
 * Call a native method
 */
int native_call(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                JavaValue* args, JavaValue* result) {
    if (!method || !method->clazz) {
        NATIVE_DEBUG("native_call: NULL method or class");
        return -1;
    }
    
    /* CRITICAL FIX: If there's a pending exception from a previous context,
     * clear it before executing this native method. This handles the case where
     * an exception was thrown but not properly cleared after being handled.
     */
    if (thread->pending_exception) {
        JavaClass* ex_class = thread->pending_exception->header.clazz;
        NATIVE_DEBUG("WARNING: clearing stale pending_exception before %s.%s%s (exception: %s)",
                method->clazz->class_name, method->name, method->descriptor,
                ex_class ? ex_class->class_name : "??");
        thread->pending_exception = NULL;  /* Clear it */
    }
    
    /* Find native method handler */
    NativeMethod handler = native_find(jvm, 
        method->clazz->class_name, method->name, method->descriptor);
    
    if (!handler) {
        NATIVE_DEBUG("Unimplemented native method: %s.%s%s",
                method->clazz->class_name, method->name, method->descriptor);
        
        /* Return default value instead of crashing */
        if (result) {
            memset(result, 0, sizeof(JavaValue));
        }
        return 0;  /* Don't fail, just return default */
    }
    
    /* Count arguments */
    int arg_count = count_args(method->descriptor);
    
    /* For non-static methods, args[0] is 'this' reference */
    int is_static = (method->access_flags & ACC_STATIC) != 0;
    int total_args = is_static ? arg_count : arg_count + 1;
    
    /* Call the native method */
    JavaValue ret = handler(jvm, thread, args, total_args);
    
    if (result) {
        *result = ret;
    }
    
    /* Check for exception */
    if (thread->pending_exception) {
        return -1;
    }
    
    return 0;
}

/*
 * javax.microedition.io.Connector native methods
 * GCF (Generic Connection Framework) implementation
 */

static JavaValue native_connector_open(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    /* args[0] = name (String), args[1] = mode (int), args[2] = timeouts (boolean) */
    JavaString* name_str = (JavaString*)args[0].ref;
    const char* name = name_str ? string_utf8(jvm, name_str) : NULL;
    jint mode = args[1].i;
    jboolean timeouts = args[2].i;
    
    (void)mode; (void)timeouts;
    fprintf(stderr, "[Connector] open('%s', %d, %d)\n", name ? name : "NULL", mode, timeouts);
    
    if (!name) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Parse protocol */
    if (strncmp(name, "http://", 7) == 0 || strncmp(name, "https://", 8) == 0) {
        /* HTTP connection - return stub */
        JavaClass* http_class = jvm_load_class(jvm, "javax/microedition/io/HttpConnection");
        if (http_class) {
            JavaObject* conn = jvm_new_object(jvm, http_class);
            fprintf(stderr, "[Connector] Created HttpConnection stub: %p\n", (void*)conn);
            return NATIVE_RETURN_OBJECT(conn);
        }
    } else if (strncmp(name, "socket://", 9) == 0) {
        JavaClass* socket_class = jvm_load_class(jvm, "javax/microedition/io/SocketConnection");
        if (socket_class) {
            JavaObject* conn = jvm_new_object(jvm, socket_class);
            fprintf(stderr, "[Connector] Created SocketConnection stub: %p\n", (void*)conn);
            return NATIVE_RETURN_OBJECT(conn);
        }
    } else if (strncmp(name, "file://", 7) == 0) {
        JavaClass* file_class = jvm_load_class(jvm, "javax/microedition/io/FileConnection");
        if (!file_class) {
            /* Create stub class dynamically */
            file_class = get_or_create_stub_class(jvm, "javax/microedition/io/FileConnection");
        }
        if (file_class) {
            JavaObject* conn = jvm_new_object(jvm, file_class);
            fprintf(stderr, "[Connector] Created FileConnection stub: %p\n", (void*)conn);
            return NATIVE_RETURN_OBJECT(conn);
        }
    }
    
    /* Generic StreamConnection for other protocols */
    JavaClass* stream_class = jvm_load_class(jvm, "javax/microedition/io/StreamConnection");
    if (stream_class) {
        JavaObject* conn = jvm_new_object(jvm, stream_class);
        fprintf(stderr, "[Connector] Created StreamConnection stub for: %s\n", name);
        return NATIVE_RETURN_OBJECT(conn);
    }
    
    return NATIVE_RETURN_NULL();
}

static JavaValue native_connector_openInputStream(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* conn = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Connector] openInputStream(%p)\n", (void*)conn);
    
    /* Create ByteArrayInputStream stub */
    JavaClass* bais_class = jvm_load_class(jvm, "java/io/ByteArrayInputStream");
    if (bais_class) {
        JavaObject* stream = jvm_new_object(jvm, bais_class);
        return NATIVE_RETURN_OBJECT(stream);
    }
    
    return NATIVE_RETURN_NULL();
}

static JavaValue native_connector_openOutputStream(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* conn = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Connector] openOutputStream(%p)\n", (void*)conn);
    
    /* Create ByteArrayOutputStream stub */
    JavaClass* baos_class = jvm_load_class(jvm, "java/io/ByteArrayOutputStream");
    if (baos_class) {
        JavaObject* stream = jvm_new_object(jvm, baos_class);
        return NATIVE_RETURN_OBJECT(stream);
    }
    
    return NATIVE_RETURN_NULL();
}

void init_javax_microedition_io(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/io/Connector", "open", "(Ljava/lang/String;)Ljavax/microedition/io/Connection;", native_connector_open},
        {"javax/microedition/io/Connector", "open", "(Ljava/lang/String;IZ)Ljavax/microedition/io/Connection;", native_connector_open},
        {"javax/microedition/io/StreamConnection", "openInputStream", "()Ljava/io/InputStream;", native_connector_openInputStream},
        {"javax/microedition/io/StreamConnection", "openOutputStream", "()Ljava/io/OutputStream;", native_connector_openOutputStream},
        {"javax/microedition/io/ContentConnection", "openInputStream", "()Ljava/io/InputStream;", native_connector_openInputStream},
        {"javax/microedition/io/ContentConnection", "openOutputStream", "()Ljava/io/OutputStream;", native_connector_openOutputStream},
        {"javax/microedition/io/HttpConnection", "openInputStream", "()Ljava/io/InputStream;", native_connector_openInputStream},
        {"javax/microedition/io/HttpConnection", "openOutputStream", "()Ljava/io/OutputStream;", native_connector_openOutputStream},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered javax.microedition.io native methods");
}

/*
 * java.util.Calendar native methods
 */

static JavaValue native_calendar_getInstance(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    (void)args;
    
    fprintf(stderr, "[Calendar] getInstance()\n");
    
    JavaClass* cal_class = jvm_load_class(jvm, "java/util/Calendar");
    if (!cal_class) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* cal = jvm_new_object(jvm, cal_class);
    if (cal) {
        /* ИСПРАВЛЕНО: используем native_set_field_value */
        time_t now = time(NULL);
        struct tm* tm_info = localtime(&now);
        
        JavaValue time_val = { .j = (jlong)now * 1000 };
        native_set_field_value(cal, "time", time_val);
        
        JavaValue year_val = { .i = tm_info->tm_year + 1900 };
        native_set_field_value(cal, "year", year_val);
        
        JavaValue month_val = { .i = tm_info->tm_mon };
        native_set_field_value(cal, "month", month_val);
        
        JavaValue day_val = { .i = tm_info->tm_mday };
        native_set_field_value(cal, "day", day_val);
        native_set_field_value(cal, "dayOfMonth", day_val);
        
        JavaValue hour_val = { .i = tm_info->tm_hour };
        native_set_field_value(cal, "hour", hour_val);
        native_set_field_value(cal, "hourOfDay", hour_val);
        
        JavaValue min_val = { .i = tm_info->tm_min };
        native_set_field_value(cal, "minute", min_val);
        
        JavaValue sec_val = { .i = tm_info->tm_sec };
        native_set_field_value(cal, "second", sec_val);
    }
    
    return NATIVE_RETURN_OBJECT(cal);
}

static JavaValue native_calendar_getTime(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cal = (JavaObject*)args[0].ref;
    
    jlong millis = 0;
    
    if (cal) {
        /* ИСПРАВЛЕНО: используем native_get_field_value */
        millis = native_get_field_value(cal, "time").j;
    }
    
    /* Create Date object */
    JavaClass* date_class = jvm_load_class(jvm, "java/util/Date");
    if (date_class) {
        JavaObject* date = jvm_new_object(jvm, date_class);
        if (date) {
            /* ИСПРАВЛЕНО: используем native_set_field_value */
            JavaValue val = { .j = millis };
            native_set_field_value(date, "fastTime", val);
        }
        return NATIVE_RETURN_OBJECT(date);
    }
    
    return NATIVE_RETURN_NULL();
}

void init_java_util_calendar(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Calendar", "getInstance", "()Ljava/util/Calendar;", native_calendar_getInstance},
        {"java/util/Calendar", "getTime", "()Ljava/util/Date;", native_calendar_getTime},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.util.Date native methods
 */

static JavaValue native_date_init(JVM* jvm, JavaThread* thread,
                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* date = (JavaObject*)args[0].ref;
    
    if (date) {
        /* ИСПРАВЛЕНО: используем native_set_field_value */
        time_t now = time(NULL);
        JavaValue val = { .j = (jlong)now * 1000 };
        native_set_field_value(date, "fastTime", val);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_date_getTime(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* date = (JavaObject*)args[0].ref;
    
    if (date) {
        /* ИСПРАВЛЕНО: используем native_get_field_value */
        jlong time = native_get_field_value(date, "fastTime").j;
        return NATIVE_RETURN_LONG(time);
    }
    
    return NATIVE_RETURN_LONG(0);
}

static JavaValue native_date_toString(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* date = (JavaObject*)args[0].ref;
    
    /* ИСПРАВЛЕНО: используем native_get_field_value */
    jlong millis = 0;
    if (date) {
        millis = native_get_field_value(date, "fastTime").j;
    }
    
    time_t t = (time_t)(millis / 1000);
    struct tm* tm_info = localtime(&t);
    char buf[64];
    strftime(buf, sizeof(buf), "%a %b %d %H:%M:%S %Y", tm_info);
    
    return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, buf));
}

void init_java_util_date(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/util/Date", "<init>", "()V", native_date_init},
        {"java/util/Date", "getTime", "()J", native_date_getTime},
        {"java/util/Date", "toString", "()Ljava/lang/String;", native_date_toString},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Character native methods
 */

static JavaValue native_character_isDigit(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    return NATIVE_RETURN_INT(c >= '0' && c <= '9' ? 1 : 0);
}

static JavaValue native_character_isLetter(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    return NATIVE_RETURN_INT((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ? 1 : 0);
}

static JavaValue native_character_isLetterOrDigit(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    int is_letter = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    int is_digit = c >= '0' && c <= '9';
    return NATIVE_RETURN_INT(is_letter || is_digit ? 1 : 0);
}

static JavaValue native_character_isUpperCase(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    return NATIVE_RETURN_INT(c >= 'A' && c <= 'Z' ? 1 : 0);
}

static JavaValue native_character_isLowerCase(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    return NATIVE_RETURN_INT(c >= 'a' && c <= 'z' ? 1 : 0);
}

static JavaValue native_character_isWhitespace(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    return NATIVE_RETURN_INT(c == ' ' || c == '\t' || c == '\n' || c == '\r' ? 1 : 0);
}

static JavaValue native_character_toUpperCase(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    if (c >= 'a' && c <= 'z') {
        return NATIVE_RETURN_INT(c - 'a' + 'A');
    }
    return NATIVE_RETURN_INT(c);
}

static JavaValue native_character_toLowerCase(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    if (c >= 'A' && c <= 'Z') {
        return NATIVE_RETURN_INT(c - 'A' + 'a');
    }
    return NATIVE_RETURN_INT(c);
}

static JavaValue native_character_digit(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint c = args[0].i;
    jint radix = args[1].i;
    
    int val = -1;
    if (c >= '0' && c <= '9') {
        val = c - '0';
    } else if (c >= 'a' && c <= 'z') {
        val = c - 'a' + 10;
    } else if (c >= 'A' && c <= 'Z') {
        val = c - 'A' + 10;
    }
    
    if (val >= 0 && val < radix) {
        return NATIVE_RETURN_INT(val);
    }
    return NATIVE_RETURN_INT(-1);
}

static JavaValue native_character_forDigit(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint digit = args[0].i;
    jint radix = args[1].i;
    
    if (digit >= 0 && digit < radix) {
        if (digit < 10) {
            return NATIVE_RETURN_INT('0' + digit);
        } else {
            return NATIVE_RETURN_INT('a' + digit - 10);
        }
    }
    return NATIVE_RETURN_INT(0);
}

void init_java_lang_character(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Character", "isDigit", "(C)Z", native_character_isDigit},
        {"java/lang/Character", "isLetter", "(C)Z", native_character_isLetter},
        {"java/lang/Character", "isLetterOrDigit", "(C)Z", native_character_isLetterOrDigit},
        {"java/lang/Character", "isUpperCase", "(C)Z", native_character_isUpperCase},
        {"java/lang/Character", "isLowerCase", "(C)Z", native_character_isLowerCase},
        {"java/lang/Character", "isWhitespace", "(C)Z", native_character_isWhitespace},
        {"java/lang/Character", "toUpperCase", "(C)C", native_character_toUpperCase},
        {"java/lang/Character", "toLowerCase", "(C)C", native_character_toLowerCase},
        {"java/lang/Character", "digit", "(CI)I", native_character_digit},
        {"java/lang/Character", "forDigit", "(II)C", native_character_forDigit},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Byte and Short native methods
 */

static JavaValue native_byte_parseByte(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    const char* s = str ? string_utf8(jvm, str) : NULL;
    
    if (!s) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT((jbyte)atoi(s));
}

static JavaValue native_byte_valueOf(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jbyte b = (jbyte)args[0].i;
    
    JavaClass* byte_class = jvm_load_class(jvm, "java/lang/Byte");
    if (byte_class) {
        JavaObject* obj = jvm_new_object(jvm, byte_class);
        if (obj) {
            /* ИСПРАВЛЕНО: используем native_set_field_value */
            JavaValue val = { .i = b };
            native_set_field_value(obj, "value", val);
        }
        return NATIVE_RETURN_OBJECT(obj);
    }
    return NATIVE_RETURN_NULL();
}

static JavaValue native_short_parseShort(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    const char* s = str ? string_utf8(jvm, str) : NULL;
    
    if (!s) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(0);
    }
    
    return NATIVE_RETURN_INT((jshort)atoi(s));
}

static JavaValue native_short_valueOf(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jshort s = (jshort)args[0].i;
    
    JavaClass* short_class = jvm_load_class(jvm, "java/lang/Short");
    if (short_class) {
        JavaObject* obj = jvm_new_object(jvm, short_class);
        if (obj) {
            /* ИСПРАВЛЕНО: используем native_set_field_value */
            JavaValue val = { .i = s };
            native_set_field_value(obj, "value", val);
        }
        return NATIVE_RETURN_OBJECT(obj);
    }
    return NATIVE_RETURN_NULL();
}

void init_java_lang_byte_short(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Byte", "parseByte", "(Ljava/lang/String;)B", native_byte_parseByte},
        {"java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;", native_byte_valueOf},
        {"java/lang/Short", "parseShort", "(Ljava/lang/String;)S", native_short_parseShort},
        {"java/lang/Short", "valueOf", "(S)Ljava/lang/Short;", native_short_valueOf},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

/*
 * java.lang.Float native methods
 */

static JavaValue native_float_valueOf(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jfloat value = args[0].f;
    
    JavaClass* float_class = jvm_load_class(jvm, "java/lang/Float");
    if (!float_class) return NATIVE_RETURN_NULL();
    
    JavaObject* obj = jvm_new_object(jvm, float_class);
    if (obj) {
        /* ИСПРАВЛЕНО: используем native_set_field_value */
        JavaValue val = { .f = value };
        native_set_field_value(obj, "value", val);
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

static JavaValue native_float_parseFloat(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_FLOAT(0.0f);
    }
    
    const char* cstr = string_utf8(jvm, str);
    float value = 0.0f;
    if (cstr) {
        value = (float)atof(cstr);
    }
    
    return NATIVE_RETURN_FLOAT(value);
}

static JavaValue native_float_floatValue(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_FLOAT(0.0f);
    
    /* ИСПРАВЛЕНО: используем native_get_field_value */
    jfloat value = native_get_field_value(obj, "value").f;
    return NATIVE_RETURN_FLOAT(value);
}

static JavaValue native_float_toString(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jfloat value = args[0].f;
    
    char buf[32];
    snprintf(buf, sizeof(buf), "%g", (double)value);
    
    JavaString* str = jvm_new_string(jvm, buf);
    return NATIVE_RETURN_OBJECT(str);
}

/*
 * java.lang.Double native methods
 */

static JavaValue native_double_valueOf(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    
    JavaClass* double_class = jvm_load_class(jvm, "java/lang/Double");
    if (!double_class) return NATIVE_RETURN_NULL();
    
    JavaObject* obj = jvm_new_object(jvm, double_class);
    if (obj) {
        /* ИСПРАВЛЕНО: используем native_set_field_value */
        JavaValue val = { .d = value };
        native_set_field_value(obj, "value", val);
    }
    
    return NATIVE_RETURN_OBJECT(obj);
}

static JavaValue native_double_parseDouble(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* str = (JavaString*)args[0].ref;
    
    if (!str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_DOUBLE(0.0);
    }
    
    const char* cstr = string_utf8(jvm, str);
    double value = 0.0;
    if (cstr) {
        value = atof(cstr);
    }
    
    return NATIVE_RETURN_DOUBLE(value);
}

static JavaValue native_double_doubleValue(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_DOUBLE(0.0);
    
    /* ИСПРАВЛЕНО: используем native_get_field_value */
    jdouble value = native_get_field_value(obj, "value").d;
    return NATIVE_RETURN_DOUBLE(value);
}

static JavaValue native_double_toString(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jdouble value = args[0].d;
    
    char buf[32];
    snprintf(buf, sizeof(buf), "%g", value);
    
    JavaString* str = jvm_new_string(jvm, buf);
    return NATIVE_RETURN_OBJECT(str);
}

void init_java_lang_float_double(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"java/lang/Float", "valueOf", "(F)Ljava/lang/Float;", native_float_valueOf},
        {"java/lang/Float", "parseFloat", "(Ljava/lang/String;)F", native_float_parseFloat},
        {"java/lang/Float", "floatValue", "()F", native_float_floatValue},
        {"java/lang/Float", "toString", "(F)Ljava/lang/String;", native_float_toString},
        {"java/lang/Double", "valueOf", "(D)Ljava/lang/Double;", native_double_valueOf},
        {"java/lang/Double", "parseDouble", "(Ljava/lang/String;)D", native_double_parseDouble},
        {"java/lang/Double", "doubleValue", "()D", native_double_doubleValue},
        {"java/lang/Double", "toString", "(D)Ljava/lang/String;", native_double_toString},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered java/lang/Float and Double native methods");
}

/*
 * javax.microedition.media.Manager native methods
 */

static JavaValue native_manager_createPlayer(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* locator = (JavaString*)args[0].ref;
    const char* loc = locator ? string_utf8(jvm, locator) : NULL;
    
    fprintf(stderr, "[Manager] createPlayer('%s')\n", loc ? loc : "NULL");
    
    JavaClass* player_class = jvm_load_class(jvm, "javax/microedition/media/Player");
    if (player_class) {
        JavaObject* player = jvm_new_object(jvm, player_class);
        fprintf(stderr, "[Manager] Created Player: %p\n", (void*)player);
        return NATIVE_RETURN_OBJECT(player);
    }
    
    return NATIVE_RETURN_NULL();
}

static JavaValue native_manager_playTone(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint note = args[0].i;
    jint duration = args[1].i;
    jint volume = args[2].i;
    
    fprintf(stderr, "[Manager] playTone(note=%d, duration=%d, volume=%d)\n", note, duration, volume);
    /* TODO: Implement actual tone playback */
    
    return NATIVE_RETURN_VOID();
}

void init_javax_microedition_media_manager(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/media/Manager", "createPlayer", "(Ljava/lang/String;)Ljavax/microedition/media/Player;", native_manager_createPlayer},
        {"javax/microedition/media/Manager", "playTone", "(III)V", native_manager_playTone},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered javax.microedition.media.Manager native methods");
}

/*
 * Vendor-specific extensions (Siemens, Samsung, Motorola)
 */

/* Siemens Light control */
static JavaValue native_siemens_light_setColor(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint color = args[0].i;
    fprintf(stderr, "[Siemens] Light.setColor(0x%06X)\n", color);
    return NATIVE_RETURN_VOID();
}

/* Siemens Vibrator */
static JavaValue native_siemens_vibrator_start(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint duration = args[0].i;
    fprintf(stderr, "[Siemens] Vibrator.start(%d)\n", duration);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_siemens_vibrator_stop(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    fprintf(stderr, "[Siemens] Vibrator.stop()\n");
    return NATIVE_RETURN_VOID();
}

/* Samsung Vibration */
static JavaValue native_samsung_vibration_start(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint duration = args[0].i;
    fprintf(stderr, "[Samsung] Vibration.start(%d)\n", duration);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_samsung_vibration_stop(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    fprintf(stderr, "[Samsung] Vibration.stop()\n");
    return NATIVE_RETURN_VOID();
}

void init_vendor_extensions(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Siemens */
        {"com/siemens/mp/game/Light", "setColor", "(I)V", native_siemens_light_setColor},
        {"com/siemens/mp/game/Vibrator", "start", "(I)V", native_siemens_vibrator_start},
        {"com/siemens/mp/game/Vibrator", "stop", "()V", native_siemens_vibrator_stop},
        /* Samsung */
        {"com/samsung/util/Vibration", "start", "(I)V", native_samsung_vibration_start},
        {"com/samsung/util/Vibration", "stop", "()V", native_samsung_vibration_stop},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    NATIVE_DEBUG("Registered vendor-specific extensions");
}

/* Count stack slots needed for method arguments (long/double take 2 slots) */
int count_args(const char* descriptor) {
    if (!descriptor) return 0;
    
    int count = 0;
    const char* p = descriptor;
    
    /* Skip return type, find args */
    if (*p != '(') return 0;
    p++;
    
    while (*p && *p != ')') {
        switch (*p) {
            case 'B': case 'C': case 'D': case 'F':
            case 'I': case 'J': case 'S': case 'Z':
                count++;
                if (*p == 'J' || *p == 'D') count++;  /* Long/double take 2 slots */
                p++;
                break;
            case 'L':
                count++;
                while (*p && *p != ';') p++;
                if (*p == ';') p++;
                break;
            case '[':
                count++;
                while (*p == '[') p++;
                if (*p == 'L') {
                    while (*p && *p != ';') p++;
                    if (*p == ';') p++;
                } else {
                    p++;
                }
                break;
            default:
                p++;
                break;
        }
    }
    
    return count;
}

/* ИСПРАВЛЕНО: Count actual Java arguments (not stack slots) 
 * long/double count as 1 argument (not 2 stack slots) */
int count_java_args(const char* descriptor) {
    if (!descriptor) return 0;
    
    int count = 0;
    const char* p = descriptor;
    
    /* Skip return type, find args */
    if (*p != '(') return 0;
    p++;
    
    while (*p && *p != ')') {
        switch (*p) {
            case 'B': case 'C': case 'D': case 'F':
            case 'I': case 'J': case 'S': case 'Z':
                count++;  /* Каждый тип - 1 аргумент */
                p++;
                break;
            case 'L':
                count++;
                while (*p && *p != ';') p++;
                if (*p == ';') p++;
                break;
            case '[':
                count++;
                while (*p == '[') p++;
                if (*p == 'L') {
                    while (*p && *p != ';') p++;
                    if (*p == ';') p++;
                } else {
                    p++;
                }
                break;
            default:
                p++;
                break;
        }
    }
    
    return count;
}
