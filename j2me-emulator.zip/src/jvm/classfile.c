/*
 * J2ME Emulator - Class File Parser
 * Parses Java .class files according to JVM Specification
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "classfile.h"
#include "jvm.h"
#include "opcodes.h"  /* For ACC_NATIVE */

/* Create a class file reader */
ClassFileReader* classfile_reader_create(const uint8_t* data, size_t length) {
    ClassFileReader* reader = (ClassFileReader*)malloc(sizeof(ClassFileReader));
    if (!reader) return NULL;
    
    reader->data = data;
    reader->length = length;
    reader->position = 0;
    reader->error = NULL;
    reader->error_position = 0;
    
    return reader;
}

/* Destroy a class file reader */
void classfile_reader_destroy(ClassFileReader* reader) {
    free(reader);
}

/* Read a single byte */
int classfile_read_u1(ClassFileReader* reader, uint8_t* value) {
    if (reader->position >= reader->length) {
        reader->error = "Unexpected end of data";
        reader->error_position = reader->position;
        return -1;
    }
    *value = reader->data[reader->position++];
    return 0;
}

/* Read a 16-bit value */
int classfile_read_u2(ClassFileReader* reader, uint16_t* value) {
    if (reader->position + 2 > reader->length) {
        reader->error = "Unexpected end of data";
        reader->error_position = reader->position;
        return -1;
    }
    *value = jvm_read_u16(reader->data + reader->position);
    reader->position += 2;
    return 0;
}

/* Read a 32-bit value */
int classfile_read_u4(ClassFileReader* reader, uint32_t* value) {
    if (reader->position + 4 > reader->length) {
        reader->error = "Unexpected end of data";
        reader->error_position = reader->position;
        return -1;
    }
    *value = jvm_read_u32(reader->data + reader->position);
    reader->position += 4;
    return 0;
}

/* Read bytes into buffer */
int classfile_read_bytes(ClassFileReader* reader, void* buffer, size_t count) {
    if (reader->position + count > reader->length) {
        reader->error = "Unexpected end of data";
        reader->error_position = reader->position;
        return -1;
    }
    memcpy(buffer, reader->data + reader->position, count);
    reader->position += count;
    return 0;
}

/* Skip bytes */
int classfile_skip(ClassFileReader* reader, size_t count) {
    if (reader->position + count > reader->length) {
        reader->error = "Unexpected end of data";
        reader->error_position = reader->position;
        return -1;
    }
    reader->position += count;
    return 0;
}

/* Get current position */
size_t classfile_position(ClassFileReader* reader) {
    return reader->position;
}

/* Check remaining bytes */
size_t classfile_remaining(ClassFileReader* reader) {
    return reader->length - reader->position;
}

/* Parse constant pool */
int classfile_parse_constant_pool(ClassFileReader* reader, JavaClass* clazz) {
    if (classfile_read_u2(reader, &clazz->constant_pool_count) != 0) {
        return -1;
    }
    
    clazz->constant_pool_capacity = clazz->constant_pool_count;
    clazz->constant_pool = (ConstantPoolEntry*)calloc(
        clazz->constant_pool_count, sizeof(ConstantPoolEntry));
    if (!clazz->constant_pool) return -1;
    
    /* Index 0 is unused */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        ConstantPoolEntry* entry = &clazz->constant_pool[i];
        
        if (classfile_read_u1(reader, &entry->tag) != 0) {
            return -1;
        }
        
        switch (entry->tag) {
            case CONSTANT_Utf8: {
                uint16_t length;
                if (classfile_read_u2(reader, &length) != 0) return -1;
                entry->info.utf8.length = length;
                entry->info.utf8.bytes = (char*)malloc(length + 1);
                if (!entry->info.utf8.bytes) return -1;
                if (classfile_read_bytes(reader, entry->info.utf8.bytes, length) != 0) {
                    return -1;
                }
                entry->info.utf8.bytes[length] = '\0';
                break;
            }
            
            case CONSTANT_Integer: {
                uint32_t value;
                if (classfile_read_u4(reader, &value) != 0) return -1;
                entry->info.integer.value = (jint)value;
                break;
            }
            
            case CONSTANT_Float: {
                uint32_t value;
                if (classfile_read_u4(reader, &value) != 0) return -1;
                memcpy(&entry->info.float_val.value, &value, sizeof(jfloat));
                break;
            }
            
            case CONSTANT_Long: {
                uint32_t high, low;
                if (classfile_read_u4(reader, &high) != 0) return -1;
                if (classfile_read_u4(reader, &low) != 0) return -1;
                uint64_t val = ((uint64_t)high << 32) | low;
                memcpy(&entry->info.long_val.value, &val, sizeof(jlong));
                i++;  /* Long takes two entries */
                break;
            }
            
            case CONSTANT_Double: {
                uint32_t high, low;
                if (classfile_read_u4(reader, &high) != 0) return -1;
                if (classfile_read_u4(reader, &low) != 0) return -1;
                uint64_t val = ((uint64_t)high << 32) | low;
                memcpy(&entry->info.double_val.value, &val, sizeof(jdouble));
                i++;  /* Double takes two entries */
                break;
            }
            
            case CONSTANT_Class:
                if (classfile_read_u2(reader, &entry->info.class_info.name_index) != 0) return -1;
                break;
            
            case CONSTANT_String:
                if (classfile_read_u2(reader, &entry->info.string_info.string_index) != 0) return -1;
                break;
            
            case CONSTANT_Fieldref:
            case CONSTANT_Methodref:
            case CONSTANT_InterfaceMethodref:
                if (classfile_read_u2(reader, &entry->info.ref_info.class_index) != 0) return -1;
                if (classfile_read_u2(reader, &entry->info.ref_info.name_and_type_index) != 0) return -1;
                break;
            
            case CONSTANT_NameAndType:
                if (classfile_read_u2(reader, &entry->info.name_and_type.name_index) != 0) return -1;
                if (classfile_read_u2(reader, &entry->info.name_and_type.descriptor_index) != 0) return -1;
                break;
            
            default:
                fprintf(stderr, "Unknown constant pool tag: %d at index %d\n", 
                        entry->tag, i);
                return -1;
        }
    }
    
    return 0;
}

/* Get UTF8 string from constant pool */
const char* classfile_get_utf8(JavaClass* clazz, uint16_t index) {
    if (index == 0 || index >= clazz->constant_pool_count) return NULL;
    
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    if (entry->tag != CONSTANT_Utf8) return NULL;
    
    return entry->info.utf8.bytes;
}

/* Get class name from constant pool */
const char* classfile_get_class_name(JavaClass* clazz, uint16_t index) {
    if (index == 0 || index >= clazz->constant_pool_count) return NULL;
    
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    if (entry->tag != CONSTANT_Class) return NULL;
    
    return classfile_get_utf8(clazz, entry->info.class_info.name_index);
}

/* Get name and type */
int classfile_get_name_and_type(JavaClass* clazz, uint16_t index, 
                                const char** name, const char** descriptor) {
    if (index == 0 || index >= clazz->constant_pool_count) return -1;
    
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    if (entry->tag != CONSTANT_NameAndType) return -1;
    
    *name = classfile_get_utf8(clazz, entry->info.name_and_type.name_index);
    *descriptor = classfile_get_utf8(clazz, entry->info.name_and_type.descriptor_index);
    
    return 0;
}

/* Parse fields */
int classfile_parse_fields(ClassFileReader* reader, JavaClass* clazz) {
    if (classfile_read_u2(reader, &clazz->fields_count) != 0) return -1;
    
    if (clazz->fields_count == 0) {
        clazz->fields = NULL;
        return 0;
    }
    
    clazz->fields = (JavaField*)calloc(clazz->fields_count, sizeof(JavaField));
    if (!clazz->fields) return -1;
    
    for (uint16_t i = 0; i < clazz->fields_count; i++) {
        JavaField* field = &clazz->fields[i];
        
        if (classfile_read_u2(reader, &field->access_flags) != 0) return -1;
        if (classfile_read_u2(reader, &field->name_index) != 0) return -1;
        if (classfile_read_u2(reader, &field->descriptor_index) != 0) return -1;
        
        field->name = (char*)classfile_get_utf8(clazz, field->name_index);
        field->descriptor = (char*)classfile_get_utf8(clazz, field->descriptor_index);
        field->clazz = clazz;
        
        /* Read attributes count first, then parse attributes */
        if (classfile_read_u2(reader, &field->attributes_count) != 0) return -1;
        
        if (classfile_parse_attributes(reader, clazz, &field->attributes, 
                                        field->attributes_count) != 0) {
            return -1;
        }
    }
    
    return 0;
}

/* Parse methods */
int classfile_parse_methods(ClassFileReader* reader, JavaClass* clazz) {
    if (classfile_read_u2(reader, &clazz->methods_count) != 0) return -1;
    
    if (clazz->methods_count == 0) {
        clazz->methods = NULL;
        clazz->methods_capacity = 0;
        return 0;
    }
    
    clazz->methods = (JavaMethod*)calloc(clazz->methods_count, sizeof(JavaMethod));
    if (!clazz->methods) return -1;
    clazz->methods_capacity = clazz->methods_count;
    
    for (uint16_t i = 0; i < clazz->methods_count; i++) {
        JavaMethod* method = &clazz->methods[i];
        
        if (classfile_read_u2(reader, &method->access_flags) != 0) return -1;
        if (classfile_read_u2(reader, &method->name_index) != 0) return -1;
        if (classfile_read_u2(reader, &method->descriptor_index) != 0) return -1;
        
        method->name = (char*)classfile_get_utf8(clazz, method->name_index);
        method->descriptor = (char*)classfile_get_utf8(clazz, method->descriptor_index);
        method->clazz = clazz;
        method->is_native = (method->access_flags & ACC_NATIVE) != 0;
        
        uint16_t attr_count;
        if (classfile_read_u2(reader, &attr_count) != 0) return -1;
        
        /* Parse attributes */
        for (uint16_t j = 0; j < attr_count; j++) {
            uint16_t name_index;
            uint32_t length;
            
            if (classfile_read_u2(reader, &name_index) != 0) return -1;
            if (classfile_read_u4(reader, &length) != 0) return -1;
            
            const char* attr_name = classfile_get_utf8(clazz, name_index);
            
            if (attr_name && strcmp(attr_name, "Code") == 0) {
                /* Parse Code attribute */
                if (classfile_read_u2(reader, &method->code.max_stack) != 0) return -1;
                if (classfile_read_u2(reader, &method->code.max_locals) != 0) return -1;
                if (classfile_read_u4(reader, &method->code.code_length) != 0) return -1;
                
                method->code.code = (uint8_t*)malloc(method->code.code_length);
                if (!method->code.code) return -1;
                
                if (classfile_read_bytes(reader, method->code.code, 
                                         method->code.code_length) != 0) {
                    return -1;
                }
                
                /* Exception table */
                if (classfile_read_u2(reader, &method->code.exception_table_length) != 0) {
                    return -1;
                }
                
                if (method->code.exception_table_length > 0) {
                    method->code.exception_table = (ExceptionTableEntry*)calloc(
                        method->code.exception_table_length, sizeof(ExceptionTableEntry));
                    
                    for (uint16_t k = 0; k < method->code.exception_table_length; k++) {
                        classfile_read_u2(reader, &method->code.exception_table[k].start_pc);
                        classfile_read_u2(reader, &method->code.exception_table[k].end_pc);
                        classfile_read_u2(reader, &method->code.exception_table[k].handler_pc);
                        classfile_read_u2(reader, &method->code.exception_table[k].catch_type);
                    }
                }
                
                /* Skip code attributes */
                uint16_t code_attr_count;
                if (classfile_read_u2(reader, &code_attr_count) != 0) return -1;
                
                for (uint16_t k = 0; k < code_attr_count; k++) {
                    uint16_t skip_name;
                    uint32_t skip_len;
                    classfile_read_u2(reader, &skip_name);
                    classfile_read_u4(reader, &skip_len);
                    classfile_skip(reader, skip_len);
                }
            } else {
                /* Skip other attributes */
                classfile_skip(reader, length);
            }
        }
    }
    
    return 0;
}

/* Parse attributes */
int classfile_parse_attributes(ClassFileReader* reader, JavaClass* clazz,
                               AttributeInfo** attributes, uint16_t count) {
    if (count == 0) {
        *attributes = NULL;
        return 0;
    }
    
    *attributes = (AttributeInfo*)calloc(count, sizeof(AttributeInfo));
    if (!*attributes) return -1;
    
    for (uint16_t i = 0; i < count; i++) {
        AttributeInfo* attr = &(*attributes)[i];
        
        if (classfile_read_u2(reader, &attr->name_index) != 0) return -1;
        if (classfile_read_u4(reader, &attr->length) != 0) return -1;
        
        if (attr->length > 0) {
            attr->info = (uint8_t*)malloc(attr->length);
            if (!attr->info) return -1;
            if (classfile_read_bytes(reader, attr->info, attr->length) != 0) return -1;
        }
    }
    
    return 0;
}

/* Parse a class file */
JavaClass* classfile_parse(JVM* jvm, const uint8_t* data, size_t length) {
    ClassFileReader* reader = classfile_reader_create(data, length);
    if (!reader) return NULL;
    
    JavaClass* clazz = (JavaClass*)calloc(1, sizeof(JavaClass));
    if (!clazz) {
        classfile_reader_destroy(reader);
        return NULL;
    }
    
    /* Read magic number */
    if (classfile_read_u4(reader, &clazz->magic) != 0) {
        fprintf(stderr, "Failed to read magic number\n");
        goto error;
    }
    
    if (clazz->magic != CLASS_FILE_MAGIC) {
        fprintf(stderr, "Invalid class file magic: 0x%08X\n", clazz->magic);
        goto error;
    }
    
    /* Read version */
    if (classfile_read_u2(reader, &clazz->minor_version) != 0) goto error;
    if (classfile_read_u2(reader, &clazz->major_version) != 0) goto error;
    
    /* Parse constant pool */
    if (classfile_parse_constant_pool(reader, clazz) != 0) {
        fprintf(stderr, "Failed to parse constant pool\n");
        goto error;
    }
    
    /* Read access flags */
    if (classfile_read_u2(reader, &clazz->access_flags) != 0) goto error;
    
    /* Read this class */
    if (classfile_read_u2(reader, &clazz->this_class) != 0) goto error;
    
    /* Read super class */
    if (classfile_read_u2(reader, &clazz->super_class_index) != 0) goto error;
    
    /* Read interfaces */
    if (classfile_read_u2(reader, &clazz->interfaces_count) != 0) goto error;
    
    if (clazz->interfaces_count > 0) {
        clazz->interfaces = (uint16_t*)calloc(clazz->interfaces_count, sizeof(uint16_t));
        for (uint16_t i = 0; i < clazz->interfaces_count; i++) {
            if (classfile_read_u2(reader, &clazz->interfaces[i]) != 0) goto error;
        }
    }
    
    /* Parse fields */
    if (classfile_parse_fields(reader, clazz) != 0) {
        fprintf(stderr, "Failed to parse fields\n");
        goto error;
    }
    
    /* Parse methods */
    if (classfile_parse_methods(reader, clazz) != 0) {
        fprintf(stderr, "Failed to parse methods\n");
        goto error;
    }
    
    /* Read class attributes */
    if (classfile_read_u2(reader, &clazz->attributes_count) != 0) goto error;
    
    if (clazz->attributes_count > 0) {
        if (classfile_parse_attributes(reader, clazz, &clazz->attributes, 
                                        clazz->attributes_count) != 0) {
            goto error;
        }
    }
    
    /* Resolve class name */
    clazz->class_name = (char*)classfile_get_class_name(clazz, clazz->this_class);
    
    /* Resolve super class name */
    if (clazz->super_class_index > 0) {
        clazz->super_class_name = (char*)classfile_get_class_name(clazz, clazz->super_class_index);
    }

    /* === НАЧАЛО ИСПРАВЛЕНИЯ: Расчет instance_size === */
    
    /* 1. Наследуем размер от суперкласса */
    if (jvm && clazz->super_class_name) {
        /* Ищем суперкласс в списке уже загруженных классов */
        if (jvm->class_loader.classes != NULL) {
            for (size_t i = 0; i < jvm->class_loader.count; i++) {
                JavaClass* super = jvm->class_loader.classes[i];
                if (super->class_name && strcmp(super->class_name, clazz->super_class_name) == 0) {
                    clazz->super_class = super;
                    /* Наследуем размер экземпляра */
                    clazz->instance_size = super->instance_size;
                    break;
                }
            }
        }
    }

    /* 2. Добавляем размер собственных полей экземпляра */
    if (clazz->fields) {
        for (uint16_t i = 0; i < clazz->fields_count; i++) {
            JavaField* field = &clazz->fields[i];
            
            /* Пропускаем статические поля - они не хранятся в экземпляре */
            if (field->access_flags & ACC_STATIC) {
                continue;
            }
            
            /* Увеличиваем размер на один слот (JavaValue) */
            clazz->instance_size += sizeof(JavaValue);
            
            /* Long и Double занимают 2 слота */
            if (field->descriptor && 
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                clazz->instance_size += sizeof(JavaValue);
            }
        }
    }
    
    /* === КОНЕЦ ИСПРАВЛЕНИЯ === */
    
    classfile_reader_destroy(reader);
    return clazz;
    
error:
    classfile_reader_destroy(reader);
    classfile_free(clazz);
    return NULL;
}

/* Parse class from file */
JavaClass* classfile_parse_file(JVM* jvm, const char* filename) {
    FILE* f = fopen(filename, "rb");
    if (!f) return NULL;
    
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    
    if (size <= 0 || size > 10 * 1024 * 1024) {  /* Max 10 MB */
        fclose(f);
        return NULL;
    }
    
    uint8_t* data = (uint8_t*)malloc(size);
    if (!data) {
        fclose(f);
        return NULL;
    }
    
    if (fread(data, 1, size, f) != (size_t)size) {
        free(data);
        fclose(f);
        return NULL;
    }
    
    fclose(f);
    
    JavaClass* clazz = classfile_parse(jvm, data, size);
    free(data);
    
    return clazz;
}

/* Free a class */
void classfile_free(JavaClass* clazz) {
    if (!clazz) return;
    
    /* Free constant pool */
    if (clazz->constant_pool) {
        for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
            if (clazz->constant_pool[i].tag == CONSTANT_Utf8) {
                free(clazz->constant_pool[i].info.utf8.bytes);
            }
        }
        free(clazz->constant_pool);
    }
    
    /* Free interfaces */
    free(clazz->interfaces);
    
    /* Free fields */
    if (clazz->fields) {
        for (uint16_t i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].attributes) {
                for (uint16_t j = 0; j < clazz->fields[i].attributes_count; j++) {
                    free(clazz->fields[i].attributes[j].info);
                }
                free(clazz->fields[i].attributes);
            }
        }
        free(clazz->fields);
    }
    
    /* Free methods */
    if (clazz->methods) {
        for (uint16_t i = 0; i < clazz->methods_count; i++) {
            free(clazz->methods[i].code.code);
            free(clazz->methods[i].code.exception_table);
        }
        free(clazz->methods);
    }
    
    /* Free attributes */
    if (clazz->attributes) {
        for (uint16_t i = 0; i < clazz->attributes_count; i++) {
            free(clazz->attributes[i].info);
        }
        free(clazz->attributes);
    }
    
    /* Free static fields */
    free(clazz->static_fields);
    
    free(clazz);
}
