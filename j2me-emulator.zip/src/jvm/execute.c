/*
 * J2ME Emulator - Bytecode Execution Engine
 * Main interpreter loop and method invocation
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>

#include "jvm.h"
#include "classfile.h"
#include "opcodes.h"
#include "heap.h"
#include "threads.h"
#include "native.h"

/* Debug logging - always output for now */
#define EXEC_DEBUG(fmt, ...) fprintf(stderr, "[EXEC] " fmt "\n", ##__VA_ARGS__)

/* Enable detailed execution tracing */
#define DEBUG_EXECUTION 0

/* Execution context for exception handling */
static jmp_buf exec_jmp_buf;
static JavaObject* pending_exception = NULL;

/* Forward declarations */
int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args, JavaValue* result);
static int interpret(JVM* jvm, JavaThread* thread, JavaFrame* frame);

/* Create a new frame */
static JavaFrame* frame_create(JVM* jvm, JavaMethod* method, JavaClass* clazz) {
    if (!method || !clazz) {
        fprintf(stderr, "[EXEC] frame_create: NULL method or clazz\n");
        return NULL;
    }

    JavaFrame* frame = (JavaFrame*)calloc(1, sizeof(JavaFrame));
    if (!frame) {
        fprintf(stderr, "[EXEC] frame_create: Failed to allocate frame\n");
        return NULL;
    }

    frame->method = method;
    frame->clazz = clazz;
    frame->pc = 0;
    frame->code = method->code.code;
    frame->code_length = method->code.code_length;

    /* Allocate locals */
    frame->max_locals = method->code.max_locals;
    if (frame->max_locals > 0) {
        frame->locals = (JavaValue*)calloc(frame->max_locals, sizeof(JavaValue));
        if (!frame->locals) {
            fprintf(stderr, "[EXEC] frame_create: Failed to allocate locals\n");
            free(frame);
            return NULL;
        }
    }

    /* Allocate operand stack */
    frame->max_stack = method->code.max_stack;
    frame->stack_top = -1;
    if (frame->max_stack > 0) {
        frame->stack = (JavaValue*)calloc(frame->max_stack, sizeof(JavaValue));
        if (!frame->stack) {
            fprintf(stderr, "[EXEC] frame_create: Failed to allocate stack\n");
            free(frame->locals);
            free(frame);
            return NULL;
        }
    }

    /* Exception table */
    frame->exception_table = method->code.exception_table;
    frame->exception_table_length = method->code.exception_table_length;

    EXEC_DEBUG("Created frame for %s%s (locals: %d, stack: %d, code: %u bytes)",
               method->name, method->descriptor,
               frame->max_locals, frame->max_stack, frame->code_length);

    return frame;
}

/* Free a frame */
static void frame_destroy(JavaFrame* frame) {
    if (!frame) return;

    free(frame->locals);
    free(frame->stack);
    free(frame);
}

/* Push frame onto thread stack */
static int push_frame(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    if (!thread || !frame) return -1;

    frame->prev = thread->current_frame;
    thread->current_frame = frame;

    EXEC_DEBUG("Pushed frame, depth now: %d", 
               thread->current_frame ? 
               (thread->current_frame->prev ? 1 : 0) + 1 : 0);

    return 0;
}

/* Pop frame from thread stack */
static JavaFrame* pop_frame(JVM* jvm, JavaThread* thread) {
    if (!thread || !thread->current_frame) return NULL;

    JavaFrame* frame = thread->current_frame;
    thread->current_frame = frame->prev;

    EXEC_DEBUG("Popped frame, depth now: %d",
               thread->current_frame ? 1 : 0);

    return frame;
}

/* Count arguments in method descriptor - uses native.h version */
/* Forward declaration for readability */
extern int count_args(const char* descriptor);

/* Execute a method */
int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                   JavaValue* args, JavaValue* result) {
    if (!jvm || !thread || !method) {
        fprintf(stderr, "[EXEC] execute_method: NULL parameter\n");
        return -1;
    }

    EXEC_DEBUG("execute_method: %s%s", method->name, method->descriptor);

    /* Check if native */
    if (method->is_native) {
        EXEC_DEBUG("Calling native method: %s%s", method->name, method->descriptor);
        return native_call(jvm, thread, method, args, result);
    }

    /* Check if method has code */
    if (!method->code.code || method->code.code_length == 0) {
        fprintf(stderr, "[EXEC] Method %s has no code\n", method->name);
        return -1;
    }

    /* Create frame */
    JavaFrame* frame = frame_create(jvm, method, method->clazz);
    if (!frame) {
        fprintf(stderr, "[EXEC] Failed to create frame for %s\n", method->name);
        return -1;
    }

    /* Copy arguments to locals */
    int arg_count = count_args(method->descriptor);
    int is_static = (method->access_flags & ACC_STATIC) != 0;
    int local_idx = 0;

    if (!is_static && args) {
        /* this reference */
        frame->locals[local_idx++] = args[0];
    }

    /* Copy remaining arguments from descriptor 
     * For non-static: args[0]=this, args[1..]=method args
     * For static: args[0..]=method args
     */
    int args_start = is_static ? 0 : 1;
    for (int i = 0; i < arg_count; i++) {
        frame->locals[local_idx++] = args[args_start + i];
    }

    /* Push frame */
    push_frame(jvm, thread, frame);

    /* Execute */
    int exec_result = interpret(jvm, thread, frame);

    /* Pop frame */
    pop_frame(jvm, thread);

    /* Get result */
    if (result && exec_result == 0) {
        /* Result should already be in the right place for returns */
    }

    /* Cleanup */
    frame_destroy(frame);

    return exec_result;
}

/* Main bytecode interpreter */
static int interpret(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    if (!frame || !frame->code) {
        fprintf(stderr, "[EXEC] interpret: NULL frame or code\n");
        return -1;
    }

    EXEC_DEBUG("interpret: Starting at PC=0, code_length=%u", frame->code_length);

    /* Set up exception handling */
    int exception_occurred = setjmp(exec_jmp_buf);
    if (exception_occurred) {
        /* Handle exception */
        fprintf(stderr, "[EXEC] Exception occurred during execution\n");

        /* Look for exception handler */
        if (pending_exception && frame->exception_table) {
            for (uint16_t i = 0; i < frame->exception_table_length; i++) {
                ExceptionTableEntry* handler = &frame->exception_table[i];
                if (frame->pc >= handler->start_pc && frame->pc < handler->end_pc) {
                    /* Found handler */
                    EXEC_DEBUG("Found exception handler at PC=%d", handler->handler_pc);
                    frame->pc = handler->handler_pc;

                    /* Push exception onto stack */
                    JavaValue v = { .ref = pending_exception };
                    frame->stack_top++;
                    frame->stack[frame->stack_top] = v;
                    pending_exception = NULL;

                    /* Continue execution */
                    exception_occurred = 0;
                }
            }
        }

        if (exception_occurred) {
            thread->pending_exception = pending_exception;
            pending_exception = NULL;
            return -1;
        }
    }

    /* Main interpreter loop */
    while (frame->pc < frame->code_length && jvm->running) {
        uint8_t opcode = frame->code[frame->pc++];

#ifdef DEBUG_EXECUTION
        const char* op_name = opcode_table[opcode].name;
        EXEC_DEBUG("PC=%d: %s (0x%02X) [stack=%d, locals=%d]", 
                   frame->pc - 1, 
                   op_name ? op_name : "unknown", opcode,
                   frame->stack_top + 1,
                   frame->max_locals);
#endif

        /* Get opcode handler */
        OpcodeHandler handler = opcode_table[opcode].handler;
        if (!handler) {
            fprintf(stderr, "[EXEC] Unknown opcode: 0x%02X at PC=%d\n", 
                    opcode, frame->pc - 1);
            return -1;
        }

        /* Execute opcode */
        int result = handler(jvm, thread, frame);

        /* Check for return */
        if (result > 0) {
            EXEC_DEBUG("Method returned");
            return 0;  /* Normal return */
        }

        /* Check for exception */
        if (result < 0) {
            if (thread->pending_exception) {
                pending_exception = thread->pending_exception;
                thread->pending_exception = NULL;
                longjmp(exec_jmp_buf, 1);
            }
            return -1;
        }
    }

    EXEC_DEBUG("interpret: Reached end of code");
    return 0;  /* Reached end of code */
}

/* Invoke virtual method */
int jvm_invoke_virtual(JVM* jvm, JavaObject* obj, const char* name, 
                       const char* descriptor, JavaValue* args, JavaValue* result) {
    if (!obj || !name || !descriptor) {
        fprintf(stderr, "[EXEC] jvm_invoke_virtual: NULL parameter\n");
        return -1;
    }

    JavaClass* clazz = obj->header.clazz;
    if (!clazz) {
        fprintf(stderr, "[EXEC] jvm_invoke_virtual: Object has no class\n");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_virtual: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method in class hierarchy */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        fprintf(stderr, "[EXEC] Method not found: %s%s in %s\n", 
                name, descriptor, clazz->class_name);
        return -1;
    }

    /* Prepare args with 'this' reference */
    int arg_count = count_args(descriptor);
    JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!full_args) return -1;

    full_args[0].ref = obj;
    if (args) {
        memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
    }

    JavaThread* thread = jvm_current_thread(jvm);
    int ret = execute_method(jvm, thread, method, full_args, result);

    free(full_args);
    return ret;
}

/* Invoke static method */
int jvm_invoke_static(JVM* jvm, JavaClass* clazz, const char* name,
                      const char* descriptor, JavaValue* args, JavaValue* result) {
    if (!clazz || !name || !descriptor) {
        fprintf(stderr, "[EXEC] jvm_invoke_static: NULL parameter\n");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_static: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        fprintf(stderr, "[EXEC] Static method not found: %s%s in %s\n",
                name, descriptor, clazz->class_name);
        return -1;
    }

    JavaThread* thread = jvm_current_thread(jvm);
    return execute_method(jvm, thread, method, args, result);
}

/* Invoke special method (constructor, private, super) */
int jvm_invoke_special(JVM* jvm, JavaObject* obj, JavaClass* clazz,
                       const char* name, const char* descriptor,
                       JavaValue* args, JavaValue* result) {
    if (!clazz || !name || !descriptor) {
        fprintf(stderr, "[EXEC] jvm_invoke_special: NULL parameter\n");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_special: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        fprintf(stderr, "[EXEC] Special method not found: %s%s in %s\n",
                name, descriptor, clazz->class_name);
        return -1;
    }

    /* Prepare args with 'this' reference */
    int arg_count = count_args(descriptor);
    JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!full_args) return -1;

    full_args[0].ref = obj;
    if (args) {
        memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
    }

    JavaThread* thread = jvm_current_thread(jvm);
    int ret = execute_method(jvm, thread, method, full_args, result);

    free(full_args);
    return ret;
}

/* Create new object and call constructor */
JavaObject* jvm_new_object_with_constructor(JVM* jvm, JavaClass* clazz,
                                            const char* descriptor,
                                            JavaValue* args) {
    if (!clazz) {
        fprintf(stderr, "[EXEC] jvm_new_object_with_constructor: NULL class\n");
        return NULL;
    }

    EXEC_DEBUG("Creating object of class %s", clazz->class_name);

    /* Create object */
    JavaObject* obj = jvm_new_object(jvm, clazz);
    if (!obj) {
        fprintf(stderr, "[EXEC] Failed to allocate object\n");
        return NULL;
    }

    /* Find constructor if descriptor provided */
    if (descriptor) {
        JavaMethod* init = jvm_resolve_method(jvm, clazz, "<init>", descriptor);
        if (init) {
            int arg_count = count_args(descriptor);
            JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
            if (full_args) {
                full_args[0].ref = obj;
                if (args) {
                    memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
                }

                JavaThread* thread = jvm_current_thread(jvm);
                JavaValue result;
                execute_method(jvm, thread, init, full_args, &result);

                free(full_args);
            }
        }
    }

    return obj;
}

/* Execute a class initializer (clinit) */
int jvm_run_clinit(JVM* jvm, JavaClass* clazz) {
    if (!clazz || clazz->initialized) {
        return 0;
    }

    EXEC_DEBUG("Running <clinit> for %s", clazz->class_name);

    /* Find <clinit> method */
    JavaMethod* clinit = jvm_resolve_method(jvm, clazz, "<clinit>", "()V");
    if (!clinit) {
        /* No clinit is OK */
        clazz->initialized = true;
        return 0;
    }

    JavaThread* thread = jvm_current_thread(jvm);
    JavaValue result;
    int ret = execute_method(jvm, thread, clinit, NULL, &result);

    clazz->initialized = true;
    return ret;
}

/* Initialize a class and its superclass */
int jvm_init_class(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return -1;

    EXEC_DEBUG("Initializing class %s", clazz->class_name);

    /* Initialize superclass first */
    if (clazz->super_class && !clazz->super_class->initialized) {
        if (jvm_init_class(jvm, clazz->super_class) != 0) {
            return -1;
        }
    }

    /* Run clinit */
    return jvm_run_clinit(jvm, clazz);
}

/* Main entry point - execute a MIDlet */
int jvm_run_midlet(JVM* jvm, JavaClass* main_class) {
    if (!jvm || !main_class) {
        fprintf(stderr, "[EXEC] jvm_run_midlet: NULL parameter\n");
        return -1;
    }

    EXEC_DEBUG("Running MIDlet: %s", main_class->class_name);

    /* Initialize the class */
    if (jvm_init_class(jvm, main_class) != 0) {
        fprintf(stderr, "[EXEC] Failed to initialize class %s\n", main_class->class_name);
        return -1;
    }

    /* Find constructor */
    JavaMethod* constructor = jvm_resolve_method(jvm, main_class, "<init>", "()V");
    if (!constructor) {
        fprintf(stderr, "[EXEC] No default constructor in %s\n", main_class->class_name);
        return -1;
    }

    /* Create MIDlet instance */
    JavaObject* midlet = jvm_new_object(jvm, main_class);
    if (!midlet) {
        fprintf(stderr, "[EXEC] Failed to create MIDlet instance\n");
        return -1;
    }

    /* Call constructor */
    JavaValue this_arg = { .ref = midlet };
    JavaThread* thread = jvm_current_thread(jvm);
    JavaValue result;
    
    EXEC_DEBUG("Calling MIDlet constructor");
    if (execute_method(jvm, thread, constructor, &this_arg, &result) != 0) {
        fprintf(stderr, "[EXEC] Constructor failed\n");
        if (thread->pending_exception) {
            fprintf(stderr, "[EXEC] Exception pending\n");
        }
        return -1;
    }

    EXEC_DEBUG("MIDlet instance created successfully");

    /* Find startApp method */
    JavaMethod* startApp = jvm_resolve_method(jvm, main_class, "startApp", "()V");
    if (!startApp) {
        fprintf(stderr, "[EXEC] No startApp method in %s\n", main_class->class_name);
        /* This is not fatal - MIDlet might be abstract */
        return 0;
    }

    EXEC_DEBUG("Calling startApp()");
    if (execute_method(jvm, thread, startApp, &this_arg, &result) != 0) {
        fprintf(stderr, "[EXEC] startApp failed\n");
        return -1;
    }

    EXEC_DEBUG("MIDlet started successfully");
    return 0;
}
