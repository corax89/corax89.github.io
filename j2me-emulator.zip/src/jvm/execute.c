/*
 * J2ME Emulator - Bytecode Execution Engine
 * Main interpreter loop and method invocation
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <stdbool.h>

#include "jvm.h"
#include "classfile.h"
#include "opcodes.h"
#include "heap.h"
#include "threads.h"
#include "native.h"
#include "debug.h"

/* Forward declarations */
int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args, JavaValue* result);
static int interpret(JVM* jvm, JavaThread* thread, JavaFrame* frame);

/* === CRITICAL: Recalculate instance_size after superclass is loaded ===
 * This must be called after superclass is guaranteed to be loaded.
 * It properly calculates the total instance size including all inherited fields.
 * 
 * JVM Specification §4.5: Fields are laid out in the order they are declared,
 * with superclass fields appearing before subclass fields.
 */
void jvm_recalculate_instance_size(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return;
    
    /* Note: We used to skip stub classes, but they also need proper instance_size
     * calculation to include inherited fields. The stub class initialization only
     * sets instance_size for its own fields, not inherited ones. */
    
    /* Start with superclass size or ObjectHeader if no superclass */
    size_t size = sizeof(ObjectHeader);  /* Always start with header */
    
    /* CRITICAL: Ensure superclass is loaded and has correct size */
    if (clazz->super_class_name && !clazz->super_class) {
        /* Try to load superclass now */
        clazz->super_class = jvm_load_class(jvm, clazz->super_class_name);
    }
    
    if (clazz->super_class) {
        /* Recursively ensure superclass has correct size */
        jvm_recalculate_instance_size(jvm, clazz->super_class);
        
        /* Superclass should already have correct instance_size including header */
        /* Use >= because a superclass with no fields still has ObjectHeader */
        if (clazz->super_class->instance_size >= sizeof(ObjectHeader)) {
            size = clazz->super_class->instance_size;
        }
    }
    
    /* Add own instance fields */
    int own_field_count = 0;
    if (clazz->fields) {
        for (uint16_t i = 0; i < clazz->fields_count; i++) {
            JavaField* field = &clazz->fields[i];
            
            /* Skip static fields */
            if (field->access_flags & ACC_STATIC) continue;
            
            own_field_count++;
            
            /* Each field takes one JavaValue slot */
            size += sizeof(JavaValue);
            
            /* Long and double take 2 slots */
            if (field->descriptor && 
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                size += sizeof(JavaValue);
            }
        }
    }
    
    /* Update if different */
    if (clazz->instance_size != size) {
        EXEC_DEBUG("Recalculated instance_size for %s: %zu -> %zu bytes (super=%s, own_fields=%d)",
                   clazz->class_name ? clazz->class_name : "?",
                   clazz->instance_size, size,
                   clazz->super_class ? clazz->super_class->class_name : "none",
                   own_field_count);
        clazz->instance_size = size;
    }
}

/* Create a new frame */
static JavaFrame* frame_create(JVM* jvm, JavaMethod* method, JavaClass* clazz) {
    if (!method || !clazz) {
        ERROR_LOG("frame_create: NULL method or clazz");
        return NULL;
    }

    JavaFrame* frame = (JavaFrame*)calloc(1, sizeof(JavaFrame));
    if (!frame) {
        ERROR_LOG("frame_create: Failed to allocate frame");
        return NULL;
    }

    frame->method = method;
    frame->clazz = clazz;
    frame->pc = 0;
    frame->code = method->code.code;
    frame->code_length = method->code.code_length;

    /* Allocate locals */
    frame->max_locals = method->code.max_locals;
    if (frame->max_locals > 0) {
        frame->locals = (JavaValue*)calloc(frame->max_locals, sizeof(JavaValue));
        if (!frame->locals) {
            ERROR_LOG("frame_create: Failed to allocate locals");
            free(frame);
            return NULL;
        }
    }

    /* Allocate operand stack */
    frame->max_stack = method->code.max_stack;
    frame->stack_top = -1;
    if (frame->max_stack > 0) {
        frame->stack = (JavaValue*)calloc(frame->max_stack, sizeof(JavaValue));
        if (!frame->stack) {
            ERROR_LOG("frame_create: Failed to allocate stack");
            free(frame->locals);
            free(frame);
            return NULL;
        }
    }

    /* Exception table */
    frame->exception_table = method->code.exception_table;
    frame->exception_table_length = method->code.exception_table_length;

    EXEC_DEBUG("Created frame for %s%s (locals: %d, stack: %d, code: %u bytes)",
               method->name, method->descriptor,
               frame->max_locals, frame->max_stack, frame->code_length);

    return frame;
}

/* Free a frame */
static void frame_destroy(JavaFrame* frame) {
    if (!frame) return;

    free(frame->locals);
    free(frame->stack);
    free(frame);
}

/* Push frame onto thread stack */
static int push_frame(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    if (!thread || !frame) return -1;

    frame->prev = thread->current_frame;
    thread->current_frame = frame;

    EXEC_DEBUG("Pushed frame, depth now: %d", 
               thread->current_frame ? 
               (thread->current_frame->prev ? 1 : 0) + 1 : 0);

    return 0;
}

/* Pop frame from thread stack */
static JavaFrame* pop_frame(JVM* jvm, JavaThread* thread) {
    if (!thread || !thread->current_frame) return NULL;

    JavaFrame* frame = thread->current_frame;
    thread->current_frame = frame->prev;

    EXEC_DEBUG("Popped frame, depth now: %d",
               thread->current_frame ? 1 : 0);

    return frame;
}

/* Count arguments in method descriptor - uses native.h version */
/* Forward declaration for readability */
extern int count_args(const char* descriptor);

/* Execute a method */
int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                   JavaValue* args, JavaValue* result) {
    if (!jvm || !thread || !method) {
        ERROR_LOG("execute_method: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("execute_method: %s%s", method->name, method->descriptor);

    /* Check if native - first check the flag, then check registry for stub classes */
    if (method->is_native) {
        EXEC_DEBUG("Calling native method: %s%s", method->name, method->descriptor);
        return native_call(jvm, thread, method, args, result);
    }
    
    /* For stub classes, check if there's a registered native handler even if not marked native */
    extern NativeMethod native_find(JVM* jvm, const char* class_name, const char* method_name,
                                    const char* descriptor);
    if (method->clazz && method->clazz->class_name && 
        native_find(jvm, method->clazz->class_name, method->name, method->descriptor)) {
        EXEC_DEBUG("Calling native method (from registry): %s%s", method->name, method->descriptor);
        return native_call(jvm, thread, method, args, result);
    }

    /* Check if method has code */
    if (!method->code.code || method->code.code_length == 0) {
        ERROR_LOG("Method %s has no code", method->name);
        return -1;
    }

    /* Handle synchronized methods - acquire monitor before execution */
    bool is_synchronized = (method->access_flags & ACC_SYNCHRONIZED) != 0;
    bool is_static = (method->access_flags & ACC_STATIC) != 0;
    JavaObject* sync_obj = NULL;
    
    if (is_synchronized) {
        if (is_static) {
            /* For static methods, synchronize on the Class object */
            sync_obj = (JavaObject*)method->clazz;
        } else {
            /* For instance methods, synchronize on 'this' */
            if (args && args[0].ref) {
                sync_obj = (JavaObject*)args[0].ref;
            }
        }
        
        EXEC_DEBUG("[SYNC_METHOD] %s.%s is synchronized, sync_obj=%p",
                method->clazz ? method->clazz->class_name : "?", 
                method->name ? method->name : "?",
                (void*)sync_obj);
        
        if (sync_obj) {
            int mon_result = monitor_enter(jvm, sync_obj);
            if (mon_result != JNI_OK) {
                ERROR_LOG("Failed to enter monitor for synchronized method %s", method->name);
                return -1;
            }
            EXEC_DEBUG("[SYNC_METHOD] Entered monitor for %s.%s",
                    method->clazz ? method->clazz->class_name : "?",
                    method->name ? method->name : "?");
        } else {
            WARN_LOG("[SYNC_METHOD] sync_obj is NULL for %s.%s!",
                    method->clazz ? method->clazz->class_name : "?",
                    method->name ? method->name : "?");
        }
    }

    /* Create frame */
    JavaFrame* frame = frame_create(jvm, method, method->clazz);
    if (!frame) {
        ERROR_LOG("Failed to create frame for %s", method->name);
        if (is_synchronized && sync_obj) {
            monitor_exit(jvm, sync_obj);
        }
        return -1;
    }

    /* Copy arguments to locals */
    int arg_count = count_args(method->descriptor);
    int local_idx = 0;

    if (!is_static && args) {
        /* this reference */
        frame->locals[local_idx++] = args[0];
    }

    /* Copy remaining arguments from descriptor 
     * For non-static: args[0]=this, args[1..]=method args
     * For static: args[0..]=method args
     */
    int args_start = is_static ? 0 : 1;
    for (int i = 0; i < arg_count; i++) {
        frame->locals[local_idx++] = args[args_start + i];
    }

    /* Push frame */
    push_frame(jvm, thread, frame);

    /* DEBUG: Log frame relationship */
    EXEC_DEBUG("DEBUG: Pushed frame %p, prev=%p, thread->current_frame=%p",
            (void*)frame, (void*)frame->prev, (void*)thread->current_frame);
    if (frame->prev) {
        EXEC_DEBUG("DEBUG: Caller stack_top before: %d", frame->prev->stack_top);
    }

    /* Execute */
    int exec_result = interpret(jvm, thread, frame);

    /* DEBUG: Log stack state after interpret */
    EXEC_DEBUG("DEBUG: interpret returned %d, frame->prev=%p", exec_result, (void*)frame->prev);
    if (frame->prev) {
        EXEC_DEBUG("DEBUG: Caller stack_top after: %d", frame->prev->stack_top);
        if (frame->prev->stack_top >= 0) {
            EXEC_DEBUG("DEBUG: Caller stack[top] = %p", 
                    (void*)frame->prev->stack[frame->prev->stack_top].ref);
        }
    }

    /* Pop frame */
    pop_frame(jvm, thread);

    /* DEBUG: Verify current frame after pop */
    EXEC_DEBUG("DEBUG: After pop, thread->current_frame=%p", 
            (void*)thread->current_frame);
    if (thread->current_frame) {
        EXEC_DEBUG("DEBUG: Current stack_top: %d", thread->current_frame->stack_top);
        if (thread->current_frame->stack_top >= 0) {
            EXEC_DEBUG("DEBUG: Current stack[top] = %p",
                    (void*)thread->current_frame->stack[thread->current_frame->stack_top].ref);
        }
    }

    /* Get result */
    if (result && exec_result == 0) {
        /* Result should already be in the right place for returns */
    }

    /* Handle synchronized methods - release monitor after execution */
    if (is_synchronized && sync_obj) {
        monitor_exit(jvm, sync_obj);
    }

    /* Cleanup */
    frame_destroy(frame);

    return exec_result;
}

/* Main bytecode interpreter - NO setjmp/longjmp for thread safety
 * 
 * Each thread has its own call stack, so exceptions are propagated via return values.
 * This avoids the problem where Thread 2's jmp_buf would corrupt Thread 1's exception handling.
 */
static int interpret(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    if (!frame || !frame->code) {
        ERROR_LOG("interpret: NULL frame or code");
        return -1;
    }

    EXEC_DEBUG("interpret: Starting at PC=0, code_length=%u", frame->code_length);

continue_execution:
    /* Main interpreter loop */
    while (frame->pc < frame->code_length && jvm->running) {
        /* Save the PC of the instruction we are about to execute.
         * This is needed for correct exception table lookup. */
        frame->throwing_pc = frame->pc;

        uint8_t opcode = frame->code[frame->pc++];
        
        /* Cooperative thread scheduling */
        extern void thread_tick(JVM* jvm);
        thread_tick(jvm);

        /* Opcode tracing - uses runtime debug flag (toggle with F12) */
        if (g_j2me_runtime_debug) {
            const char* op_name = opcode_table[opcode].name;
            const char* method_name = frame->method ? frame->method->name : "?";
            const char* class_name = (frame->clazz && frame->clazz->class_name) ? frame->clazz->class_name : "?";
            
            /* For method invocations, show target method */
            if ((opcode == OPC_INVOKEVIRTUAL || opcode == OPC_INVOKESTATIC || 
                 opcode == OPC_INVOKESPECIAL || opcode == OPC_INVOKEINTERFACE) && 
                frame->pc + 1 < frame->code_length) {
                /* After reading opcode, PC points to first operand byte
                 * cp_index is at code[PC] and code[PC+1] */
                uint16_t cp_index = ((uint16_t)frame->code[frame->pc] << 8) | frame->code[frame->pc + 1];
                
                /* Get constant pool entry and extract method info */
                const char* target_class = "?";
                const char* target_method = "?";
                const char* target_desc = "?";
                
                if (cp_index > 0 && cp_index < frame->clazz->constant_pool_count) {
                    ConstantPoolEntry* entry = &frame->clazz->constant_pool[cp_index];
                    if (entry->tag == CONSTANT_Methodref || entry->tag == CONSTANT_InterfaceMethodref) {
                        target_class = classfile_get_class_name(frame->clazz, entry->info.ref_info.class_index);
                        classfile_get_name_and_type(frame->clazz, entry->info.ref_info.name_and_type_index,
                                                    &target_method, &target_desc);
                    }
                }
                
                fprintf(stderr, "[OPCODE] %s.%s PC=%d: %s -> %s.%s%s [cp=#%d, stack=%d/%d]\n",
                        class_name, method_name, frame->pc - 1, 
                        op_name ? op_name : "unknown",
                        target_class ? target_class : "?",
                        target_method ? target_method : "?",
                        target_desc ? target_desc : "?",
                        cp_index,
                        frame->stack_top + 1, frame->max_stack);
            } else if (opcode == OPC_GETFIELD && frame->pc + 1 < frame->code_length) {
                /* cp_index is at code[PC] and code[PC+1] */
                uint16_t cp_index = ((uint16_t)frame->code[frame->pc] << 8) | frame->code[frame->pc + 1];
                
                /* Get constant pool entry and extract field info */
                const char* field_class = "?";
                const char* field_name = "?";
                const char* field_desc = "?";
                
                if (cp_index > 0 && cp_index < frame->clazz->constant_pool_count) {
                    ConstantPoolEntry* entry = &frame->clazz->constant_pool[cp_index];
                    if (entry->tag == CONSTANT_Fieldref) {
                        field_class = classfile_get_class_name(frame->clazz, entry->info.ref_info.class_index);
                        classfile_get_name_and_type(frame->clazz, entry->info.ref_info.name_and_type_index,
                                                    &field_name, &field_desc);
                    }
                }
                
                fprintf(stderr, "[OPCODE] %s.%s PC=%d: getfield -> %s.%s [cp=#%d, stack=%d/%d]\n",
                        class_name, method_name, frame->pc - 1,
                        field_class ? field_class : "?",
                        field_name ? field_name : "?",
                        cp_index,
                        frame->stack_top + 1, frame->max_stack);
            } else if (opcode == OPC_IF_ICMPEQ || opcode == OPC_IF_ICMPNE || 
                       opcode == OPC_IF_ICMPLT || opcode == OPC_IF_ICMPGE ||
                       opcode == OPC_IF_ICMPGT || opcode == OPC_IF_ICMPLE) {
                /* Show comparison values for if_icmp*
                 * Stack: [... value1, value2]
                 * PEEK = stack[stack_top] = value2 (top)
                 * stack[stack_top - 1] = value1 (second from top)
                 * Compares: if value1 OP value2 then branch */
                if (frame->stack_top >= 1) {
                    jint value2 = frame->stack[frame->stack_top].i;      /* top of stack */
                    jint value1 = frame->stack[frame->stack_top - 1].i; /* second from top */
                    fprintf(stderr, "[OPCODE] %s.%s PC=%d: %s [value1=%d, value2=%d, result=%s, stack=%d/%d]\n",
                            class_name, method_name, frame->pc - 1,
                            op_name ? op_name : "unknown",
                            value1, value2,
                            (opcode == OPC_IF_ICMPEQ) ? (value1 == value2 ? "BRANCH" : "FALL") :
                            (opcode == OPC_IF_ICMPNE) ? (value1 != value2 ? "BRANCH" : "FALL") :
                            (opcode == OPC_IF_ICMPLT) ? (value1 < value2 ? "BRANCH" : "FALL") :
                            (opcode == OPC_IF_ICMPGE) ? (value1 >= value2 ? "BRANCH" : "FALL") :
                            (opcode == OPC_IF_ICMPGT) ? (value1 > value2 ? "BRANCH" : "FALL") :
                            (value1 <= value2 ? "BRANCH" : "FALL"),
                            frame->stack_top + 1, frame->max_stack);
                } else {
                    fprintf(stderr, "[OPCODE] %s.%s PC=%d: %s [stack=%d/%d, INSUFFICIENT VALUES!]\n",
                            class_name, method_name, frame->pc - 1,
                            op_name ? op_name : "unknown",
                            frame->stack_top + 1, frame->max_stack);
                }
            } else if (opcode == OPC_SIPUSH && frame->pc + 1 < frame->code_length) {
                /* Show the value being pushed - immediate is at code[PC] and code[PC+1] */
                int16_t value = (int16_t)(((uint16_t)frame->code[frame->pc] << 8) | frame->code[frame->pc + 1]);
                fprintf(stderr, "[OPCODE] %s.%s PC=%d: sipush %d [stack=%d/%d]\n",
                        class_name, method_name, frame->pc - 1, value,
                        frame->stack_top + 1, frame->max_stack);
            } else {
                fprintf(stderr, "[OPCODE] %s.%s PC=%d: %s (0x%02X) [stack=%d/%d, locals=%d]\n",
                        class_name, method_name,
                        frame->pc - 1, 
                        op_name ? op_name : "unknown", 
                        opcode,
                        frame->stack_top + 1,
                        frame->max_stack,
                        frame->max_locals);
            }
            fflush(stderr);
        }

        /* Get opcode handler */
        OpcodeHandler handler = opcode_table[opcode].handler;
        if (!handler) {
            ERROR_LOG("Unknown opcode: 0x%02X at PC=%d", opcode, frame->pc - 1);
            jvm_throw_by_name(jvm, "java/lang/VirtualMachineError", "Unknown opcode");
            return -1;
        }

        /* DEBUG: Log right before calling handler for checkcast */
        if (opcode == OPC_CHECKCAST) {
            EXEC_DEBUG("DEBUG: About to call checkcast handler=%p, frame=%p, stack_top=%d",
                    (void*)handler, (void*)frame, frame->stack_top);
            EXEC_DEBUG("DEBUG: frame->stack=%p, PEEK would be stack[%d]",
                    (void*)frame->stack, frame->stack_top);
        }

        /* Execute opcode */
        int result = handler(jvm, thread, frame);

        /* Check for return */
        if (result > 0) {
            EXEC_DEBUG("Method returned");
            return 0;  /* Normal return */
        }

        /* Check for exception */
        if (result < 0) {
            if (thread->pending_exception) {
                /* Handle exception - search for handler in this frame */
                JavaObject* exception = thread->pending_exception;
                JavaClass* exception_class = exception->header.clazz;

                EXEC_DEBUG("Exception %s occurred at PC=%d",
                           exception_class ? exception_class->class_name : "??",
                           frame->throwing_pc);

                /* Look for exception handler */
                bool handler_found = false;
                if (frame->exception_table) {
                    for (uint16_t i = 0; i < frame->exception_table_length; i++) {
                        ExceptionTableEntry* handler = &frame->exception_table[i];

                        if (frame->throwing_pc >= handler->start_pc &&
                            frame->throwing_pc < handler->end_pc) {

                            if (handler->catch_type == 0) {
                                /* catch_type 0 means "any" (finally block) */
                                handler_found = true;
                            } else {
                                const char* catch_name = classfile_get_class_name(frame->clazz, handler->catch_type);
                                if (catch_name) {
                                    JavaClass* catch_class = jvm_load_class(jvm, catch_name);
                                    if (catch_class && object_instance_of(exception, catch_class)) {
                                        handler_found = true;
                                    }
                                }
                            }

                            if (handler_found) {
                                EXEC_DEBUG("Exception matched handler at PC=%d", handler->handler_pc);

                                /* Clear operand stack and push exception */
                                frame->stack_top = 0;
                                JavaValue v = { .ref = exception };
                                frame->stack[0] = v;
                                thread->pending_exception = NULL;

                                /* Jump to handler */
                                frame->pc = handler->handler_pc;
                                goto continue_execution;
                            }
                        }
                    }
                }

                if (!handler_found) {
                    /* No handler found in this frame, propagate up */
                    EXEC_DEBUG("No handler found, propagating exception");
                    return -1;  /* Caller will handle */
                }
            }
            /* Error without exception object */
            return -1;
        }
    }

    EXEC_DEBUG("interpret: Reached end of code");
    return 0;  /* Reached end of code */
}

/* Invoke virtual method */
int jvm_invoke_virtual(JVM* jvm, JavaObject* obj, const char* name, 
                       const char* descriptor, JavaValue* args, JavaValue* result) {
    if (!obj || !name || !descriptor) {
        ERROR_LOG("jvm_invoke_virtual: NULL parameter");
        return -1;
    }

    JavaClass* clazz = obj->header.clazz;
    if (!clazz) {
        ERROR_LOG("jvm_invoke_virtual: Object has no class");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_virtual: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method in class hierarchy */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        ERROR_LOG("Method not found: %s%s in %s", name, descriptor, clazz->class_name);
        return -1;
    }

    /* Prepare args with 'this' reference */
    int arg_count = count_args(descriptor);
    JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!full_args) return -1;

    full_args[0].ref = obj;
    if (args) {
        memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
    }

    JavaThread* thread = jvm_current_thread(jvm);
    int ret = execute_method(jvm, thread, method, full_args, result);

    free(full_args);
    return ret;
}

/* Invoke static method */
int jvm_invoke_static(JVM* jvm, JavaClass* clazz, const char* name,
                      const char* descriptor, JavaValue* args, JavaValue* result) {
    if (!clazz || !name || !descriptor) {
        ERROR_LOG("jvm_invoke_static: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_static: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        ERROR_LOG("Static method not found: %s%s in %s", name, descriptor, clazz->class_name);
        return -1;
    }

    JavaThread* thread = jvm_current_thread(jvm);
    return execute_method(jvm, thread, method, args, result);
}

/* Invoke special method (constructor, private, super) */
int jvm_invoke_special(JVM* jvm, JavaObject* obj, JavaClass* clazz,
                       const char* name, const char* descriptor,
                       JavaValue* args, JavaValue* result) {
    if (!clazz || !name || !descriptor) {
        ERROR_LOG("jvm_invoke_special: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_special: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        ERROR_LOG("Special method not found: %s%s in %s", name, descriptor, clazz->class_name);
        return -1;
    }

    /* Prepare args with 'this' reference */
    int arg_count = count_args(descriptor);
    JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!full_args) return -1;

    full_args[0].ref = obj;
    if (args) {
        memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
    }

    JavaThread* thread = jvm_current_thread(jvm);
    int ret = execute_method(jvm, thread, method, full_args, result);

    free(full_args);
    return ret;
}

/* Create new object and call constructor */
JavaObject* jvm_new_object_with_constructor(JVM* jvm, JavaClass* clazz,
                                            const char* descriptor,
                                            JavaValue* args) {
    if (!clazz) {
        ERROR_LOG("jvm_new_object_with_constructor: NULL class");
        return NULL;
    }

    EXEC_DEBUG("Creating object of class %s", clazz->class_name);

    /* Create object */
    JavaObject* obj = jvm_new_object(jvm, clazz);
    if (!obj) {
        ERROR_LOG("Failed to allocate object");
        return NULL;
    }

    /* Find constructor if descriptor provided */
    if (descriptor) {
        JavaMethod* init = jvm_resolve_method(jvm, clazz, "<init>", descriptor);
        if (init) {
            int arg_count = count_args(descriptor);
            JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
            if (full_args) {
                full_args[0].ref = obj;
                if (args) {
                    memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
                }

                JavaThread* thread = jvm_current_thread(jvm);
                JavaValue result;
                execute_method(jvm, thread, init, full_args, &result);

                free(full_args);
            }
        }
    }

    return obj;
}

/* Initialize a class and its superclass */
int jvm_init_class(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return -1;

    /* 1. Если класс уже инициализирован */
    if (clazz->initialized) {
        return 0;
    }

    /* 2. Получаем текущий поток */
    JavaThread* current = jvm_current_thread(jvm);
    if (!current) return -1; /* Safety check */

    /* 3. Проверка на рекурсию (JVMS §5.5)
       Если класс уже инициализируется ЭТИМ потоком, разрешаем выполнение (return 0).
       Это происходит, когда <clinit> вызывает методы своего же класса. */
    if (clazz->initializing && clazz->initializing_thread == current) {
        return 0;
    }
    
    /* 4. Если класс инициализируется другим потоком (в однопоточном варианте не должно случаться) */
    if (clazz->initializing) {
        return 0; 
    }

    EXEC_DEBUG("Initializing class %s", clazz->class_name);
    EXEC_DEBUG("Class %s (is_stub=%d, instance_size=%zu)",
            clazz->class_name ? clazz->class_name : "?", clazz->is_stub ? 1 : 0, clazz->instance_size);

    /* 5. Инициализируем суперкласс */
    if (clazz->super_class && !clazz->super_class->initialized) {
        if (jvm_init_class(jvm, clazz->super_class) != 0) {
            return -1;
        }
    }
    
    /* === CRITICAL FIX: Recalculate instance_size after superclass is initialized ===
     * At class load time, superclass might not have been loaded yet.
     * Now that superclass is guaranteed to be loaded and initialized,
     * we can correctly calculate the total instance size.
     */
    jvm_recalculate_instance_size(jvm, clazz);

    /* === CRITICAL: Initialize static fields from class file ===
     * Static fields are parsed from the class file into clazz->fields[],
     * but need to be copied to clazz->static_fields[] for getstatic/putstatic.
     * This must be done BEFORE <clinit> runs.
     * 
     * IMPORTANT: Fields with same name but different descriptors are DIFFERENT fields!
     * This is valid in Java (obfuscated code often uses this).
     */
    if (clazz->fields && clazz->fields_count > 0) {
        /* Count static fields first */
        int static_count = 0;
        for (uint16_t i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].access_flags & ACC_STATIC) {
                static_count++;
            }
        }
        
        /* Allocate static fields storage if needed */
        if (static_count > 0) {
            if (!clazz->static_fields) {
                int capacity = static_count > 16 ? static_count : 16;
                clazz->static_fields = (JavaStaticField*)calloc(capacity, sizeof(JavaStaticField));
                clazz->static_fields_capacity = capacity;
                clazz->static_fields_count = 0;
            }
            
            /* Add each static field */
            for (uint16_t i = 0; i < clazz->fields_count; i++) {
                JavaField* field = &clazz->fields[i];
                if (!(field->access_flags & ACC_STATIC)) continue;
                
                /* Check if already exists */
                bool exists = false;
                for (int j = 0; j < clazz->static_fields_count; j++) {
                    if (clazz->static_fields[j].name && 
                        strcmp(clazz->static_fields[j].name, field->name) == 0 &&
                        clazz->static_fields[j].descriptor && field->descriptor &&
                        strcmp(clazz->static_fields[j].descriptor, field->descriptor) == 0) {
                        exists = true;
                        break;
                    }
                }
                
                if (!exists) {
                    /* Grow if needed */
                    if (clazz->static_fields_count >= clazz->static_fields_capacity) {
                        int new_cap = clazz->static_fields_capacity + 16;
                        JavaStaticField* new_fields = (JavaStaticField*)realloc(
                            clazz->static_fields, new_cap * sizeof(JavaStaticField));
                        if (!new_fields) continue;
                        memset(new_fields + clazz->static_fields_capacity, 0, 
                               16 * sizeof(JavaStaticField));
                        clazz->static_fields = new_fields;
                        clazz->static_fields_capacity = new_cap;
                    }
                    
                    int slot = clazz->static_fields_count++;
                    clazz->static_fields[slot].name = field->name ? strdup(field->name) : NULL;
                    clazz->static_fields[slot].descriptor = field->descriptor ? strdup(field->descriptor) : NULL;
                    clazz->static_fields[slot].value.raw = 0;  /* Default value */
                    
                    EXEC_DEBUG("Static field slot %d: %s %s", slot, 
                            field->name ? field->name : "?",
                            field->descriptor ? field->descriptor : "?");
                }
            }
            
            EXEC_DEBUG("Initialized %d static fields for %s", clazz->static_fields_count, 
                    clazz->class_name ? clazz->class_name : "?");
        }
    }

    /* 6. Устанавливаем флаг ПЕРЕД выполнением <clinit> */
    clazz->initializing = true;
    clazz->initializing_thread = current;

    /* 7. Запускаем <clinit> */
    JavaMethod* clinit = jvm_resolve_method(jvm, clazz, "<clinit>", "()V");
    if (clinit) {
        JavaValue result;
        /* execute_method вернет < 0 при исключении */
        int ret = execute_method(jvm, current, clinit, NULL, &result);
        
        if (ret != 0) {
            /* Ошибка при инициализации. Класс считается битым. */
            clazz->initializing = false;
            clazz->initializing_thread = NULL;
            /* initialized остается false */
            ERROR_LOG("ExceptionInInitializerError for %s", clazz->class_name);
            /* В строгом JVM тут нужно выбросить ExceptionInInitializerError, 
               но для простого эмулятора достаточно вернуть ошибку. */
            return -1;
        }
    }

    /* 8. Завершаем инициализацию */
    clazz->initializing = false;
    clazz->initializing_thread = NULL;
    clazz->initialized = true;

    return 0;
}

/* Main entry point - execute a MIDlet */
int jvm_run_midlet(JVM* jvm, JavaClass* main_class) {
    if (!jvm || !main_class) {
        ERROR_LOG("jvm_run_midlet: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("Running MIDlet: %s", main_class->class_name);

    /* Initialize the class */
    if (jvm_init_class(jvm, main_class) != 0) {
        ERROR_LOG("Failed to initialize class %s", main_class->class_name);
        return -1;
    }

    /* Find constructor */
    JavaMethod* constructor = jvm_resolve_method(jvm, main_class, "<init>", "()V");
    if (!constructor) {
        ERROR_LOG("No default constructor in %s", main_class->class_name);
        return -1;
    }

    /* Create MIDlet instance */
    JavaObject* midlet = jvm_new_object(jvm, main_class);
    if (!midlet) {
        ERROR_LOG("Failed to create MIDlet instance");
        return -1;
    }

    /* Call constructor */
    JavaValue this_arg = { .ref = midlet };
    JavaThread* thread = jvm_current_thread(jvm);
    JavaValue result;
    
    EXEC_DEBUG("Calling MIDlet constructor");
    if (execute_method(jvm, thread, constructor, &this_arg, &result) != 0) {
        ERROR_LOG("Constructor failed");
        if (thread->pending_exception) {
            ERROR_LOG("Exception pending");
        }
        return -1;
    }

    EXEC_DEBUG("MIDlet instance created successfully");

    /* Find startApp method */
    JavaMethod* startApp = jvm_resolve_method(jvm, main_class, "startApp", "()V");
    if (!startApp) {
        ERROR_LOG("No startApp method in %s", main_class->class_name);
        /* This is not fatal - MIDlet might be abstract */
        return 0;
    }

    EXEC_DEBUG("Calling startApp()");
    if (execute_method(jvm, thread, startApp, &this_arg, &result) != 0) {
        ERROR_LOG("startApp failed");
        return -1;
    }

    EXEC_DEBUG("MIDlet started successfully");
    return 0;
}

/* Execute one instruction from the current frame (for libretro step-by-step execution)
 * Returns: 0 = continue, >0 = method returned, <0 = error/exception
 * This is designed for step-by-step execution in libretro where we need to
 * periodically return control to the frontend.
 */
int execute_frame(JVM* jvm, JavaThread* thread) {
    if (!jvm || !thread) return -1;
    
    JavaFrame* frame = thread->current_frame;
    if (!frame || !frame->code) {
        return -1;  /* No frame to execute */
    }
    
    /* Check for pending exception */
    if (thread->pending_exception) {
        return -1;
    }
    
    /* Check if we've reached end of code */
    if (frame->pc >= frame->code_length) {
        return 1;  /* End of method */
    }
    
    /* Check if JVM is still running */
    if (!jvm->running) {
        return -1;
    }
    
    /* Save the PC for exception handling */
    frame->throwing_pc = frame->pc;
    
    /* Fetch and execute one instruction */
    uint8_t opcode = frame->code[frame->pc++];
    
    /* Opcode tracing - uses runtime debug flag (toggle with F12) */
    if (g_j2me_runtime_debug) {
        const char* op_name = opcode_table[opcode].name;
        const char* method_name = frame->method ? frame->method->name : "?";
        const char* class_name = (frame->clazz && frame->clazz->class_name) ? frame->clazz->class_name : "?";
        fprintf(stderr, "[OPCODE] %s.%s PC=%d: %s (0x%02X) [stack=%d/%d, locals=%d]\n",
                class_name, method_name,
                frame->pc - 1, 
                op_name ? op_name : "unknown", 
                opcode,
                frame->stack_top + 1,
                frame->max_stack,
                frame->max_locals);
        fflush(stderr);
    }
    
    /* Get opcode handler */
    OpcodeHandler handler = opcode_table[opcode].handler;
    if (!handler) {
        ERROR_LOG("Unknown opcode: 0x%02X at PC=%d", opcode, frame->pc - 1);
        return -1;
    }
    
    /* Execute opcode */
    int result = handler(jvm, thread, frame);
    
    /* result: 0 = continue, >0 = return, <0 = error/exception */
    return result;
}
