/*
 * J2ME Emulator - Bytecode Execution Engine
 * Main interpreter loop and method invocation
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>

#include "jvm.h"
#include "classfile.h"
#include "opcodes.h"
#include "heap.h"
#include "threads.h"
#include "native.h"
#include "debug.h"

/* Enable detailed execution tracing (separate from J2ME_DEBUG) */
#define DEBUG_EXECUTION 0

/* Execution context for exception handling */
static jmp_buf exec_jmp_buf;
static int exec_jmp_buf_valid = 0;

/* Forward declarations */
int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args, JavaValue* result);
static int interpret(JVM* jvm, JavaThread* thread, JavaFrame* frame);

/* === CRITICAL: Recalculate instance_size after superclass is loaded ===
 * This must be called after superclass is guaranteed to be loaded.
 * It properly calculates the total instance size including all inherited fields.
 * 
 * JVM Specification §4.5: Fields are laid out in the order they are declared,
 * with superclass fields appearing before subclass fields.
 */
void jvm_recalculate_instance_size(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return;
    
    /* Skip stub classes - they have manually set instance_size */
    if (clazz->is_stub) return;
    
    /* Start with superclass size or ObjectHeader if no superclass */
    size_t size = sizeof(ObjectHeader);  /* Always start with header */
    
    /* CRITICAL: Ensure superclass is loaded and has correct size */
    if (clazz->super_class_name && !clazz->super_class) {
        /* Try to load superclass now */
        clazz->super_class = jvm_load_class(jvm, clazz->super_class_name);
    }
    
    if (clazz->super_class) {
        /* Recursively ensure superclass has correct size */
        jvm_recalculate_instance_size(jvm, clazz->super_class);
        
        /* Superclass should already have correct instance_size including header */
        /* Use >= because a superclass with no fields still has ObjectHeader */
        if (clazz->super_class->instance_size >= sizeof(ObjectHeader)) {
            size = clazz->super_class->instance_size;
        }
    }
    
    /* Add own instance fields */
    int own_field_count = 0;
    if (clazz->fields) {
        for (uint16_t i = 0; i < clazz->fields_count; i++) {
            JavaField* field = &clazz->fields[i];
            
            /* Skip static fields */
            if (field->access_flags & ACC_STATIC) continue;
            
            own_field_count++;
            
            /* Each field takes one JavaValue slot */
            size += sizeof(JavaValue);
            
            /* Long and double take 2 slots */
            if (field->descriptor && 
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                size += sizeof(JavaValue);
            }
        }
    }
    
    /* Update if different */
    if (clazz->instance_size != size) {
        EXEC_DEBUG("Recalculated instance_size for %s: %zu -> %zu bytes (super=%s, own_fields=%d)",
                   clazz->class_name ? clazz->class_name : "?",
                   clazz->instance_size, size,
                   clazz->super_class ? clazz->super_class->class_name : "none",
                   own_field_count);
        clazz->instance_size = size;
    }
}

/* Create a new frame */
static JavaFrame* frame_create(JVM* jvm, JavaMethod* method, JavaClass* clazz) {
    if (!method || !clazz) {
        ERROR_LOG("frame_create: NULL method or clazz");
        return NULL;
    }

    JavaFrame* frame = (JavaFrame*)calloc(1, sizeof(JavaFrame));
    if (!frame) {
        ERROR_LOG("frame_create: Failed to allocate frame");
        return NULL;
    }

    frame->method = method;
    frame->clazz = clazz;
    frame->pc = 0;
    frame->code = method->code.code;
    frame->code_length = method->code.code_length;

    /* Allocate locals */
    frame->max_locals = method->code.max_locals;
    if (frame->max_locals > 0) {
        frame->locals = (JavaValue*)calloc(frame->max_locals, sizeof(JavaValue));
        if (!frame->locals) {
            ERROR_LOG("frame_create: Failed to allocate locals");
            free(frame);
            return NULL;
        }
    }

    /* Allocate operand stack */
    frame->max_stack = method->code.max_stack;
    frame->stack_top = -1;
    if (frame->max_stack > 0) {
        frame->stack = (JavaValue*)calloc(frame->max_stack, sizeof(JavaValue));
        if (!frame->stack) {
            ERROR_LOG("frame_create: Failed to allocate stack");
            free(frame->locals);
            free(frame);
            return NULL;
        }
    }

    /* Exception table */
    frame->exception_table = method->code.exception_table;
    frame->exception_table_length = method->code.exception_table_length;

    EXEC_DEBUG("Created frame for %s%s (locals: %d, stack: %d, code: %u bytes)",
               method->name, method->descriptor,
               frame->max_locals, frame->max_stack, frame->code_length);

    return frame;
}

/* Free a frame */
static void frame_destroy(JavaFrame* frame) {
    if (!frame) return;

    free(frame->locals);
    free(frame->stack);
    free(frame);
}

/* Push frame onto thread stack */
static int push_frame(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    if (!thread || !frame) return -1;

    frame->prev = thread->current_frame;
    thread->current_frame = frame;

    EXEC_DEBUG("Pushed frame, depth now: %d", 
               thread->current_frame ? 
               (thread->current_frame->prev ? 1 : 0) + 1 : 0);

    return 0;
}

/* Pop frame from thread stack */
static JavaFrame* pop_frame(JVM* jvm, JavaThread* thread) {
    if (!thread || !thread->current_frame) return NULL;

    JavaFrame* frame = thread->current_frame;
    thread->current_frame = frame->prev;

    EXEC_DEBUG("Popped frame, depth now: %d",
               thread->current_frame ? 1 : 0);

    return frame;
}

/* Count arguments in method descriptor - uses native.h version */
/* Forward declaration for readability */
extern int count_args(const char* descriptor);

/* Execute a method */
int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                   JavaValue* args, JavaValue* result) {
    if (!jvm || !thread || !method) {
        ERROR_LOG("execute_method: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("execute_method: %s%s", method->name, method->descriptor);

    /* Check if native - first check the flag, then check registry for stub classes */
    if (method->is_native) {
        EXEC_DEBUG("Calling native method: %s%s", method->name, method->descriptor);
        return native_call(jvm, thread, method, args, result);
    }
    
    /* For stub classes, check if there's a registered native handler even if not marked native */
    extern NativeMethod native_find(JVM* jvm, const char* class_name, const char* method_name,
                                    const char* descriptor);
    if (method->clazz && method->clazz->class_name && 
        native_find(jvm, method->clazz->class_name, method->name, method->descriptor)) {
        EXEC_DEBUG("Calling native method (from registry): %s%s", method->name, method->descriptor);
        return native_call(jvm, thread, method, args, result);
    }

    /* Check if method has code */
    if (!method->code.code || method->code.code_length == 0) {
        ERROR_LOG("Method %s has no code", method->name);
        return -1;
    }

    /* Create frame */
    JavaFrame* frame = frame_create(jvm, method, method->clazz);
    if (!frame) {
        ERROR_LOG("Failed to create frame for %s", method->name);
        return -1;
    }

    /* Copy arguments to locals */
    int arg_count = count_args(method->descriptor);
    int is_static = (method->access_flags & ACC_STATIC) != 0;
    int local_idx = 0;

    if (!is_static && args) {
        /* this reference */
        frame->locals[local_idx++] = args[0];
    }

    /* Copy remaining arguments from descriptor 
     * For non-static: args[0]=this, args[1..]=method args
     * For static: args[0..]=method args
     */
    int args_start = is_static ? 0 : 1;
    for (int i = 0; i < arg_count; i++) {
        frame->locals[local_idx++] = args[args_start + i];
    }

    /* Push frame */
    push_frame(jvm, thread, frame);

    /* Execute */
    int exec_result = interpret(jvm, thread, frame);

    /* Pop frame */
    pop_frame(jvm, thread);

    /* Get result */
    if (result && exec_result == 0) {
        /* Result should already be in the right place for returns */
    }

    /* Cleanup */
    frame_destroy(frame);

    return exec_result;
}

/* Main bytecode interpreter */
static int interpret(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    if (!frame || !frame->code) {
        ERROR_LOG("interpret: NULL frame or code");
        return -1;
    }

    EXEC_DEBUG("interpret: Starting at PC=0, code_length=%u", frame->code_length);

    /* Save previous jmp_buf for nested calls (critical for Windows!)
     * MUST be volatile because values after longjmp are undefined for non-volatile locals */
    volatile jmp_buf prev_jmp_buf;
    volatile int prev_jmp_valid = exec_jmp_buf_valid;
    if (exec_jmp_buf_valid) {
        memcpy((void*)prev_jmp_buf, exec_jmp_buf, sizeof(jmp_buf));
    }

    /* Set up exception handling */
    int exception_occurred = setjmp(exec_jmp_buf);
    exec_jmp_buf_valid = 1;

    if (exception_occurred) {
        /* Exception occurred - search for handler */
        JavaObject* exception = thread->pending_exception;
        thread->pending_exception = NULL; /* Clear while searching */

        if (!exception) {
            /* Restore previous jmp_buf */
            if (prev_jmp_valid) {
                memcpy(exec_jmp_buf, (void*)prev_jmp_buf, sizeof(jmp_buf));
            }
            exec_jmp_buf_valid = prev_jmp_valid;
            return -1;
        }

        JavaClass* exception_class = exception->header.clazz;

        EXEC_DEBUG("Exception %s occurred at PC=%d (instruction start)",
                   exception_class ? exception_class->class_name : "??",
                   frame->throwing_pc);

        /* Look for exception handler */
        bool handler_found = false;
        if (frame->exception_table) {
            EXEC_DEBUG("Searching %d exception handlers for PC=%d", 
                       frame->exception_table_length, frame->throwing_pc);
            for (uint16_t i = 0; i < frame->exception_table_length; i++) {
                ExceptionTableEntry* handler = &frame->exception_table[i];

                /* Use throwing_pc (instruction start) for range check */
                if (frame->throwing_pc >= handler->start_pc &&
                    frame->throwing_pc < handler->end_pc) {

                    /* Check catch type */
                    if (handler->catch_type == 0) {
                        /* catch_type 0 means "any" (finally block) */
                        EXEC_DEBUG("Handler %d: catch_type=0 (finally), range [%d,%d), handler_pc=%d",
                                   i, handler->start_pc, handler->end_pc, handler->handler_pc);
                        handler_found = true;
                    } else {
                        /* Check if exception is instance of catch_type */
                        const char* catch_name = classfile_get_class_name(frame->clazz, handler->catch_type);
                        EXEC_DEBUG("Handler %d: catch_type=%d (%s), range [%d,%d), handler_pc=%d",
                                   i, handler->catch_type, catch_name ? catch_name : "??",
                                   handler->start_pc, handler->end_pc, handler->handler_pc);
                        if (catch_name) {
                            JavaClass* catch_class = jvm_load_class(jvm, catch_name);
                            if (catch_class) {
                                bool is_instance = object_instance_of(exception, catch_class);
                                EXEC_DEBUG("  exception %s instanceof %s = %s",
                                           exception_class->class_name, catch_name,
                                           is_instance ? "true" : "false");
                                if (is_instance) {
                                    handler_found = true;
                                }
                            } else {
                                EXEC_DEBUG("  WARNING: catch_class not found: %s", catch_name);
                            }
                        }
                    }

                    if (handler_found) {
                        EXEC_DEBUG("Exception matched handler at PC=%d", handler->handler_pc);

                        /* CRITICAL: Clear operand stack before entering handler */
                        frame->stack_top = -1;

                        /* Push exception onto stack */
                        JavaValue v = { .ref = exception };
                        frame->stack_top++;
                        frame->stack[frame->stack_top] = v;

                        /* Jump to handler */
                        frame->pc = handler->handler_pc;

                        /* Verify pending_exception is cleared */
                        if (thread->pending_exception) {
                            EXEC_DEBUG("WARNING: pending_exception still set after handler match!");
                        }

                        /* Continue execution */
                        goto continue_execution;
                    }
                }
            }
        }

        if (!handler_found) {
            /* No handler found in this frame, propagate up */
            EXEC_DEBUG("No handler found, propagating exception");
            thread->pending_exception = exception; /* Restore for caller */
            /* Restore previous jmp_buf */
            if (prev_jmp_valid) {
                memcpy(exec_jmp_buf, (void*)prev_jmp_buf, sizeof(jmp_buf));
            }
            exec_jmp_buf_valid = prev_jmp_valid;
            return -1;
        }
    }

continue_execution:
    /* Main interpreter loop */
    while (frame->pc < frame->code_length && jvm->running) {
        /* Save the PC of the instruction we are about to execute.
         * This is needed for correct exception table lookup. */
        frame->throwing_pc = frame->pc;

        uint8_t opcode = frame->code[frame->pc++];

#ifdef DEBUG_EXECUTION
        const char* op_name = opcode_table[opcode].name;
        EXEC_DEBUG("PC=%d: %s (0x%02X) [stack=%d, locals=%d]", 
                   frame->pc - 1, 
                   op_name ? op_name : "unknown", opcode,
                   frame->stack_top + 1,
                   frame->max_locals);
#endif

        /* Get opcode handler */
        OpcodeHandler handler = opcode_table[opcode].handler;
        if (!handler) {
            ERROR_LOG("Unknown opcode: 0x%02X at PC=%d", opcode, frame->pc - 1);
            /* Treat as exception */
            jvm_throw_by_name(jvm, "java/lang/VirtualMachineError", "Unknown opcode");
            if (thread->pending_exception) {
                longjmp(exec_jmp_buf, 1);
            }
            return -1;
        }

        /* Execute opcode */
        int result = handler(jvm, thread, frame);

        /* Check for return */
        if (result > 0) {
            EXEC_DEBUG("Method returned");
            /* Restore previous jmp_buf before returning */
            if (prev_jmp_valid) {
                memcpy(exec_jmp_buf, (void*)prev_jmp_buf, sizeof(jmp_buf));
            }
            exec_jmp_buf_valid = prev_jmp_valid;
            return 0;  /* Normal return */
        }

        /* Check for exception */
        if (result < 0) {
            if (thread->pending_exception) {
                /* Jump to exception handling logic above */
                longjmp(exec_jmp_buf, 1);
            }
            /* Error without exception object */
            /* Restore previous jmp_buf before returning */
            if (prev_jmp_valid) {
                memcpy(exec_jmp_buf, (void*)prev_jmp_buf, sizeof(jmp_buf));
            }
            exec_jmp_buf_valid = prev_jmp_valid;
            return -1;
        }
    }

    EXEC_DEBUG("interpret: Reached end of code");
    /* Restore previous jmp_buf before returning */
    if (prev_jmp_valid) {
        memcpy(exec_jmp_buf, (void*)prev_jmp_buf, sizeof(jmp_buf));
    }
    exec_jmp_buf_valid = prev_jmp_valid;
    return 0;  /* Reached end of code */
}

/* Invoke virtual method */
int jvm_invoke_virtual(JVM* jvm, JavaObject* obj, const char* name, 
                       const char* descriptor, JavaValue* args, JavaValue* result) {
    if (!obj || !name || !descriptor) {
        ERROR_LOG("jvm_invoke_virtual: NULL parameter");
        return -1;
    }

    JavaClass* clazz = obj->header.clazz;
    if (!clazz) {
        ERROR_LOG("jvm_invoke_virtual: Object has no class");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_virtual: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method in class hierarchy */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        ERROR_LOG("Method not found: %s%s in %s", name, descriptor, clazz->class_name);
        return -1;
    }

    /* Prepare args with 'this' reference */
    int arg_count = count_args(descriptor);
    JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!full_args) return -1;

    full_args[0].ref = obj;
    if (args) {
        memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
    }

    JavaThread* thread = jvm_current_thread(jvm);
    int ret = execute_method(jvm, thread, method, full_args, result);

    free(full_args);
    return ret;
}

/* Invoke static method */
int jvm_invoke_static(JVM* jvm, JavaClass* clazz, const char* name,
                      const char* descriptor, JavaValue* args, JavaValue* result) {
    if (!clazz || !name || !descriptor) {
        ERROR_LOG("jvm_invoke_static: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_static: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        ERROR_LOG("Static method not found: %s%s in %s", name, descriptor, clazz->class_name);
        return -1;
    }

    JavaThread* thread = jvm_current_thread(jvm);
    return execute_method(jvm, thread, method, args, result);
}

/* Invoke special method (constructor, private, super) */
int jvm_invoke_special(JVM* jvm, JavaObject* obj, JavaClass* clazz,
                       const char* name, const char* descriptor,
                       JavaValue* args, JavaValue* result) {
    if (!clazz || !name || !descriptor) {
        ERROR_LOG("jvm_invoke_special: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("jvm_invoke_special: %s.%s%s", clazz->class_name, name, descriptor);

    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, name, descriptor);
    if (!method) {
        ERROR_LOG("Special method not found: %s%s in %s", name, descriptor, clazz->class_name);
        return -1;
    }

    /* Prepare args with 'this' reference */
    int arg_count = count_args(descriptor);
    JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!full_args) return -1;

    full_args[0].ref = obj;
    if (args) {
        memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
    }

    JavaThread* thread = jvm_current_thread(jvm);
    int ret = execute_method(jvm, thread, method, full_args, result);

    free(full_args);
    return ret;
}

/* Create new object and call constructor */
JavaObject* jvm_new_object_with_constructor(JVM* jvm, JavaClass* clazz,
                                            const char* descriptor,
                                            JavaValue* args) {
    if (!clazz) {
        ERROR_LOG("jvm_new_object_with_constructor: NULL class");
        return NULL;
    }

    EXEC_DEBUG("Creating object of class %s", clazz->class_name);

    /* Create object */
    JavaObject* obj = jvm_new_object(jvm, clazz);
    if (!obj) {
        ERROR_LOG("Failed to allocate object");
        return NULL;
    }

    /* Find constructor if descriptor provided */
    if (descriptor) {
        JavaMethod* init = jvm_resolve_method(jvm, clazz, "<init>", descriptor);
        if (init) {
            int arg_count = count_args(descriptor);
            JavaValue* full_args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
            if (full_args) {
                full_args[0].ref = obj;
                if (args) {
                    memcpy(full_args + 1, args, arg_count * sizeof(JavaValue));
                }

                JavaThread* thread = jvm_current_thread(jvm);
                JavaValue result;
                execute_method(jvm, thread, init, full_args, &result);

                free(full_args);
            }
        }
    }

    return obj;
}

/* Initialize a class and its superclass */
int jvm_init_class(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return -1;

    /* 1. Если класс уже инициализирован */
    if (clazz->initialized) {
        return 0;
    }

    /* 2. Получаем текущий поток */
    JavaThread* current = jvm_current_thread(jvm);
    if (!current) return -1; /* Safety check */

    /* 3. Проверка на рекурсию (JVMS §5.5)
       Если класс уже инициализируется ЭТИМ потоком, разрешаем выполнение (return 0).
       Это происходит, когда <clinit> вызывает методы своего же класса. */
    if (clazz->initializing && clazz->initializing_thread == current) {
        return 0;
    }
    
    /* 4. Если класс инициализируется другим потоком (в однопоточном варианте не должно случаться) */
    if (clazz->initializing) {
        return 0; 
    }

    EXEC_DEBUG("Initializing class %s", clazz->class_name);
    EXEC_DEBUG("Class %s (is_stub=%d, instance_size=%zu)",
            clazz->class_name ? clazz->class_name : "?", clazz->is_stub ? 1 : 0, clazz->instance_size);

    /* 5. Инициализируем суперкласс */
    if (clazz->super_class && !clazz->super_class->initialized) {
        if (jvm_init_class(jvm, clazz->super_class) != 0) {
            return -1;
        }
    }
    
    /* === CRITICAL FIX: Recalculate instance_size after superclass is initialized ===
     * At class load time, superclass might not have been loaded yet.
     * Now that superclass is guaranteed to be loaded and initialized,
     * we can correctly calculate the total instance size.
     */
    jvm_recalculate_instance_size(jvm, clazz);

    /* 6. Устанавливаем флаг ПЕРЕД выполнением <clinit> */
    clazz->initializing = true;
    clazz->initializing_thread = current;

    /* 7. Запускаем <clinit> */
    JavaMethod* clinit = jvm_resolve_method(jvm, clazz, "<clinit>", "()V");
    if (clinit) {
        JavaValue result;
        /* execute_method вернет < 0 при исключении */
        int ret = execute_method(jvm, current, clinit, NULL, &result);
        
        if (ret != 0) {
            /* Ошибка при инициализации. Класс считается битым. */
            clazz->initializing = false;
            clazz->initializing_thread = NULL;
            /* initialized остается false */
            ERROR_LOG("ExceptionInInitializerError for %s", clazz->class_name);
            /* В строгом JVM тут нужно выбросить ExceptionInInitializerError, 
               но для простого эмулятора достаточно вернуть ошибку. */
            return -1;
        }
    }

    /* 8. Завершаем инициализацию */
    clazz->initializing = false;
    clazz->initializing_thread = NULL;
    clazz->initialized = true;

    return 0;
}

/* Main entry point - execute a MIDlet */
int jvm_run_midlet(JVM* jvm, JavaClass* main_class) {
    if (!jvm || !main_class) {
        ERROR_LOG("jvm_run_midlet: NULL parameter");
        return -1;
    }

    EXEC_DEBUG("Running MIDlet: %s", main_class->class_name);

    /* Initialize the class */
    if (jvm_init_class(jvm, main_class) != 0) {
        ERROR_LOG("Failed to initialize class %s", main_class->class_name);
        return -1;
    }

    /* Find constructor */
    JavaMethod* constructor = jvm_resolve_method(jvm, main_class, "<init>", "()V");
    if (!constructor) {
        ERROR_LOG("No default constructor in %s", main_class->class_name);
        return -1;
    }

    /* Create MIDlet instance */
    JavaObject* midlet = jvm_new_object(jvm, main_class);
    if (!midlet) {
        ERROR_LOG("Failed to create MIDlet instance");
        return -1;
    }

    /* Call constructor */
    JavaValue this_arg = { .ref = midlet };
    JavaThread* thread = jvm_current_thread(jvm);
    JavaValue result;
    
    EXEC_DEBUG("Calling MIDlet constructor");
    if (execute_method(jvm, thread, constructor, &this_arg, &result) != 0) {
        ERROR_LOG("Constructor failed");
        if (thread->pending_exception) {
            ERROR_LOG("Exception pending");
        }
        return -1;
    }

    EXEC_DEBUG("MIDlet instance created successfully");

    /* Find startApp method */
    JavaMethod* startApp = jvm_resolve_method(jvm, main_class, "startApp", "()V");
    if (!startApp) {
        ERROR_LOG("No startApp method in %s", main_class->class_name);
        /* This is not fatal - MIDlet might be abstract */
        return 0;
    }

    EXEC_DEBUG("Calling startApp()");
    if (execute_method(jvm, thread, startApp, &this_arg, &result) != 0) {
        ERROR_LOG("startApp failed");
        return -1;
    }

    EXEC_DEBUG("MIDlet started successfully");
    return 0;
}

/* Execute one instruction from the current frame (for libretro step-by-step execution)
 * Returns: 0 = continue, >0 = method returned, <0 = error/exception
 * This is designed for step-by-step execution in libretro where we need to
 * periodically return control to the frontend.
 */
int execute_frame(JVM* jvm, JavaThread* thread) {
    if (!jvm || !thread) return -1;
    
    JavaFrame* frame = thread->current_frame;
    if (!frame || !frame->code) {
        return -1;  /* No frame to execute */
    }
    
    /* Check for pending exception */
    if (thread->pending_exception) {
        return -1;
    }
    
    /* Check if we've reached end of code */
    if (frame->pc >= frame->code_length) {
        return 1;  /* End of method */
    }
    
    /* Check if JVM is still running */
    if (!jvm->running) {
        return -1;
    }
    
    /* Save the PC for exception handling */
    frame->throwing_pc = frame->pc;
    
    /* Fetch and execute one instruction */
    uint8_t opcode = frame->code[frame->pc++];
    
    /* Get opcode handler */
    OpcodeHandler handler = opcode_table[opcode].handler;
    if (!handler) {
        ERROR_LOG("Unknown opcode: 0x%02X at PC=%d", opcode, frame->pc - 1);
        return -1;
    }
    
    /* Execute opcode */
    int result = handler(jvm, thread, frame);
    
    /* result: 0 = continue, >0 = return, <0 = error/exception */
    return result;
}
