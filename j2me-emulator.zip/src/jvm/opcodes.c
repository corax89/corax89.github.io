/*
 * J2ME Emulator - Bytecode Opcode Handlers
 * Implementation of all Java bytecode instructions
 */

/* For strdup on POSIX */
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* For Windows strdup compatibility */
#ifdef _WIN32
#ifndef strdup
#define strdup _strdup
#endif
#endif

#include "opcodes.h"
#include "jvm.h"
#include "classfile.h"
#include "heap.h"
#include "native.h"
#include "threads.h"  /* For monitor_enter/exit */

/* 
 * Logging control - define this macro to enable detailed opcode logging
 * By default, only errors are logged (via fprintf to stderr)
 */
// #define ENABLE_OPCODE_LOGGING 1

#ifdef ENABLE_OPCODE_LOGGING
#define LOG_OPCODE(...) fprintf(stderr, __VA_ARGS__)
#define LOG_DEBUG(...) fprintf(stderr, __VA_ARGS__)
#else
#define LOG_OPCODE(...) /* No-op */
#define LOG_DEBUG(...) /* No-op */
#endif

/* External function from native.c */
extern int count_args(const char* descriptor);

/* External function from execute.c */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                          JavaValue* args, JavaValue* result);

/* External functions from jvm.c */
extern JavaFrame* create_frame(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args);
extern void free_frame(JavaFrame* frame);

/* Forward declarations for long/double specific opcodes */
int op_lload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore(JVM* jvm, JavaThread* thread, JavaFrame* frame);

/* Opcode information table */
const OpcodeInfo opcode_table[256] = {
    [OPC_NOP]           = {"nop", 0, 0, op_nop},
    [OPC_ACONST_NULL]   = {"aconst_null", 0, 1, op_aconst_null},
    [OPC_ICONST_M1]     = {"iconst_m1", 0, 1, op_iconst},
    [OPC_ICONST_0]      = {"iconst_0", 0, 1, op_iconst},
    [OPC_ICONST_1]      = {"iconst_1", 0, 1, op_iconst},
    [OPC_ICONST_2]      = {"iconst_2", 0, 1, op_iconst},
    [OPC_ICONST_3]      = {"iconst_3", 0, 1, op_iconst},
    [OPC_ICONST_4]      = {"iconst_4", 0, 1, op_iconst},
    [OPC_ICONST_5]      = {"iconst_5", 0, 1, op_iconst},
    [OPC_LCONST_0]      = {"lconst_0", 0, 2, op_lconst},
    [OPC_LCONST_1]      = {"lconst_1", 0, 2, op_lconst},
    [OPC_FCONST_0]      = {"fconst_0", 0, 1, op_fconst},
    [OPC_FCONST_1]      = {"fconst_1", 0, 1, op_fconst},
    [OPC_FCONST_2]      = {"fconst_2", 0, 1, op_fconst},
    [OPC_DCONST_0]      = {"dconst_0", 0, 2, op_dconst},
    [OPC_DCONST_1]      = {"dconst_1", 0, 2, op_dconst},
    [OPC_BIPUSH]        = {"bipush", 1, 1, op_bipush},
    [OPC_SIPUSH]        = {"sipush", 2, 1, op_sipush},
    [OPC_LDC]           = {"ldc", 1, 1, op_ldc},
    [OPC_LDC_W]         = {"ldc_w", 2, 1, op_ldc_w},
    [OPC_LDC2_W]        = {"ldc2_w", 2, 2, op_ldc2_w},
    
    /* Load instructions */
    [OPC_ILOAD]         = {"iload", 1, 1, op_iload},
    [OPC_LLOAD]         = {"lload", 1, 2, op_lload},
    [OPC_FLOAD]         = {"fload", 1, 1, op_fload},
    [OPC_DLOAD]         = {"dload", 1, 2, op_dload},
    [OPC_ALOAD]         = {"aload", 1, 1, op_aload},
    [OPC_ILOAD_0]       = {"iload_0", 0, 1, op_load_0},
    [OPC_ILOAD_1]       = {"iload_1", 0, 1, op_load_1},
    [OPC_ILOAD_2]       = {"iload_2", 0, 1, op_load_2},
    [OPC_ILOAD_3]       = {"iload_3", 0, 1, op_load_3},
    [OPC_LLOAD_0]       = {"lload_0", 0, 2, op_lload_0},
    [OPC_LLOAD_1]       = {"lload_1", 0, 2, op_lload_1},
    [OPC_LLOAD_2]       = {"lload_2", 0, 2, op_lload_2},
    [OPC_LLOAD_3]       = {"lload_3", 0, 2, op_lload_3},
    [OPC_FLOAD_0]       = {"fload_0", 0, 1, op_load_0},
    [OPC_FLOAD_1]       = {"fload_1", 0, 1, op_load_1},
    [OPC_FLOAD_2]       = {"fload_2", 0, 1, op_load_2},
    [OPC_FLOAD_3]       = {"fload_3", 0, 1, op_load_3},
    [OPC_DLOAD_0]       = {"dload_0", 0, 2, op_dload_0},
    [OPC_DLOAD_1]       = {"dload_1", 0, 2, op_dload_1},
    [OPC_DLOAD_2]       = {"dload_2", 0, 2, op_dload_2},
    [OPC_DLOAD_3]       = {"dload_3", 0, 2, op_dload_3},
    [OPC_ALOAD_0]       = {"aload_0", 0, 1, op_load_0},
    [OPC_ALOAD_1]       = {"aload_1", 0, 1, op_load_1},
    [OPC_ALOAD_2]       = {"aload_2", 0, 1, op_load_2},
    [OPC_ALOAD_3]       = {"aload_3", 0, 1, op_load_3},
    
    /* Array load */
    [OPC_IALOAD]        = {"iaload", 0, -1, op_array_load},
    [OPC_LALOAD]        = {"laload", 0, 0, op_array_load},
    [OPC_FALOAD]        = {"faload", 0, -1, op_array_load},
    [OPC_DALOAD]        = {"daload", 0, 0, op_array_load},
    [OPC_AALOAD]        = {"aaload", 0, -1, op_array_load},
    [OPC_BALOAD]        = {"baload", 0, -1, op_array_load},
    [OPC_CALOAD]        = {"caload", 0, -1, op_array_load},
    [OPC_SALOAD]        = {"saload", 0, -1, op_array_load},
    
    /* Store instructions */
    [OPC_ISTORE]        = {"istore", 1, -1, op_store},
    [OPC_LSTORE]        = {"lstore", 1, -2, op_lstore},
    [OPC_FSTORE]        = {"fstore", 1, -1, op_store},
    [OPC_DSTORE]        = {"dstore", 1, -2, op_dstore},
    [OPC_ASTORE]        = {"astore", 1, -1, op_store},
    [OPC_ISTORE_0]      = {"istore_0", 0, -1, op_store_0},
    [OPC_ISTORE_1]      = {"istore_1", 0, -1, op_store_1},
    [OPC_ISTORE_2]      = {"istore_2", 0, -1, op_store_2},
    [OPC_ISTORE_3]      = {"istore_3", 0, -1, op_store_3},
    [OPC_LSTORE_0]      = {"lstore_0", 0, -2, op_lstore_0},
    [OPC_LSTORE_1]      = {"lstore_1", 0, -2, op_lstore_1},
    [OPC_LSTORE_2]      = {"lstore_2", 0, -2, op_lstore_2},
    [OPC_LSTORE_3]      = {"lstore_3", 0, -2, op_lstore_3},
    [OPC_FSTORE_0]      = {"fstore_0", 0, -1, op_store_0},
    [OPC_FSTORE_1]      = {"fstore_1", 0, -1, op_store_1},
    [OPC_FSTORE_2]      = {"fstore_2", 0, -1, op_store_2},
    [OPC_FSTORE_3]      = {"fstore_3", 0, -1, op_store_3},
    [OPC_DSTORE_0]      = {"dstore_0", 0, -2, op_dstore_0},
    [OPC_DSTORE_1]      = {"dstore_1", 0, -2, op_dstore_1},
    [OPC_DSTORE_2]      = {"dstore_2", 0, -2, op_dstore_2},
    [OPC_DSTORE_3]      = {"dstore_3", 0, -2, op_dstore_3},
    [OPC_ASTORE_0]      = {"astore_0", 0, -1, op_store_0},
    [OPC_ASTORE_1]      = {"astore_1", 0, -1, op_store_1},
    [OPC_ASTORE_2]      = {"astore_2", 0, -1, op_store_2},
    [OPC_ASTORE_3]      = {"astore_3", 0, -1, op_store_3},
    
    /* Array store */
    [OPC_IASTORE]       = {"iastore", 0, -3, op_array_store},
    [OPC_LASTORE]       = {"lastore", 0, -4, op_array_store},
    [OPC_FASTORE]       = {"fastore", 0, -3, op_array_store},
    [OPC_DASTORE]       = {"dastore", 0, -4, op_array_store},
    [OPC_AASTORE]       = {"aastore", 0, -3, op_array_store},
    [OPC_BASTORE]       = {"bastore", 0, -3, op_array_store},
    [OPC_CASTORE]       = {"castore", 0, -3, op_array_store},
    [OPC_SASTORE]       = {"sastore", 0, -3, op_array_store},
    
    /* Stack operations */
    [OPC_POP]           = {"pop", 0, -1, op_pop},
    [OPC_POP2]          = {"pop2", 0, -2, op_pop2},
    [OPC_DUP]           = {"dup", 0, 1, op_dup},
    [OPC_DUP_X1]        = {"dup_x1", 0, 1, op_dup_x1},
    [OPC_DUP_X2]        = {"dup_x2", 0, 1, op_dup_x2},
    [OPC_DUP2]          = {"dup2", 0, 2, op_dup2},
    [OPC_DUP2_X1]       = {"dup2_x1", 0, 2, op_dup2_x1},
    [OPC_DUP2_X2]       = {"dup2_x2", 0, 2, op_dup2_x2},
    [OPC_SWAP]          = {"swap", 0, 0, op_swap},
    
    /* Arithmetic */
    [OPC_IADD]          = {"iadd", 0, -1, op_add},
    [OPC_LADD]          = {"ladd", 0, -2, op_add},
    [OPC_FADD]          = {"fadd", 0, -1, op_add},
    [OPC_DADD]          = {"dadd", 0, -2, op_add},
    [OPC_ISUB]          = {"isub", 0, -1, op_sub},
    [OPC_LSUB]          = {"lsub", 0, -2, op_sub},
    [OPC_FSUB]          = {"fsub", 0, -1, op_sub},
    [OPC_DSUB]          = {"dsub", 0, -2, op_sub},
    [OPC_IMUL]          = {"imul", 0, -1, op_mul},
    [OPC_LMUL]          = {"lmul", 0, -2, op_mul},
    [OPC_FMUL]          = {"fmul", 0, -1, op_mul},
    [OPC_DMUL]          = {"dmul", 0, -2, op_mul},
    [OPC_IDIV]          = {"idiv", 0, -1, op_div},
    [OPC_LDIV]          = {"ldiv", 0, -2, op_div},
    [OPC_FDIV]          = {"fdiv", 0, -1, op_div},
    [OPC_DDIV]          = {"ddiv", 0, -2, op_div},
    [OPC_IREM]          = {"irem", 0, -1, op_rem},
    [OPC_LREM]          = {"lrem", 0, -2, op_rem},
    [OPC_FREM]          = {"frem", 0, -1, op_rem},
    [OPC_DREM]          = {"drem", 0, -2, op_rem},
    [OPC_INEG]          = {"ineg", 0, 0, op_neg},
    [OPC_LNEG]          = {"lneg", 0, 0, op_neg},
    [OPC_FNEG]          = {"fneg", 0, 0, op_neg},
    [OPC_DNEG]          = {"dneg", 0, 0, op_neg},
    
    /* Bit operations */
    [OPC_ISHL]          = {"ishl", 0, -1, op_shl},
    [OPC_LSHL]          = {"lshl", 0, -1, op_shl},
    [OPC_ISHR]          = {"ishr", 0, -1, op_shr},
    [OPC_LSHR]          = {"lshr", 0, -1, op_shr},
    [OPC_IUSHR]         = {"iushr", 0, -1, op_ushr},
    [OPC_LUSHR]         = {"lushr", 0, -1, op_ushr},
    [OPC_IAND]          = {"iand", 0, -1, op_and},
    [OPC_LAND]          = {"land", 0, -2, op_and},
    [OPC_IOR]           = {"ior", 0, -1, op_or},
    [OPC_LOR]           = {"lor", 0, -2, op_or},
    [OPC_IXOR]          = {"ixor", 0, -1, op_xor},
    [OPC_LXOR]          = {"lxor", 0, -2, op_xor},
    [OPC_IINC]          = {"iinc", 2, 0, op_iinc},
    
    /* Conversions */
    [OPC_I2L]           = {"i2l", 0, 1, op_convert},
    [OPC_I2F]           = {"i2f", 0, 0, op_convert},
    [OPC_I2D]           = {"i2d", 0, 1, op_convert},
    [OPC_L2I]           = {"l2i", 0, -1, op_convert},
    [OPC_L2F]           = {"l2f", 0, -1, op_convert},
    [OPC_L2D]           = {"l2d", 0, 0, op_convert},
    [OPC_F2I]           = {"f2i", 0, 0, op_convert},
    [OPC_F2L]           = {"f2l", 0, 1, op_convert},
    [OPC_F2D]           = {"f2d", 0, 1, op_convert},
    [OPC_D2I]           = {"d2i", 0, -1, op_convert},
    [OPC_D2L]           = {"d2l", 0, 0, op_convert},
    [OPC_D2F]           = {"d2f", 0, -1, op_convert},
    [OPC_I2B]           = {"i2b", 0, 0, op_convert},
    [OPC_I2C]           = {"i2c", 0, 0, op_convert},
    [OPC_I2S]           = {"i2s", 0, 0, op_convert},
    
    /* Comparisons */
    [OPC_LCMP]          = {"lcmp", 0, -3, op_lcmp},
    [OPC_FCMPL]         = {"fcmpl", 0, -1, op_fcmpl},
    [OPC_FCMPG]         = {"fcmpg", 0, -1, op_fcmpg},
    [OPC_DCMPL]         = {"dcmpl", 0, -3, op_dcmpl},
    [OPC_DCMPG]         = {"dcmpg", 0, -3, op_dcmpg},
    
    /* Branches */
    [OPC_IFEQ]          = {"ifeq", 2, -1, op_if},
    [OPC_IFNE]          = {"ifne", 2, -1, op_if},
    [OPC_IFLT]          = {"iflt", 2, -1, op_if},
    [OPC_IFGE]          = {"ifge", 2, -1, op_if},
    [OPC_IFGT]          = {"ifgt", 2, -1, op_if},
    [OPC_IFLE]          = {"ifle", 2, -1, op_if},
    [OPC_IF_ICMPEQ]     = {"if_icmpeq", 2, -2, op_if_icmp},
    [OPC_IF_ICMPNE]     = {"if_icmpne", 2, -2, op_if_icmp},
    [OPC_IF_ICMPLT]     = {"if_icmplt", 2, -2, op_if_icmp},
    [OPC_IF_ICMPGE]     = {"if_icmpge", 2, -2, op_if_icmp},
    [OPC_IF_ICMPGT]     = {"if_icmpgt", 2, -2, op_if_icmp},
    [OPC_IF_ICMPLE]     = {"if_icmple", 2, -2, op_if_icmp},
    [OPC_IF_ACMPEQ]     = {"if_acmpeq", 2, -2, op_if_acmp},
    [OPC_IF_ACMPNE]     = {"if_acmpne", 2, -2, op_if_acmp},
    [OPC_GOTO]          = {"goto", 2, 0, op_goto},
    [OPC_JSR]           = {"jsr", 2, 1, op_jsr},
    [OPC_RET]           = {"ret", 1, 0, op_ret},
    [OPC_TABLESWITCH]   = {"tableswitch", 0, -1, op_tableswitch},
    [OPC_LOOKUPSWITCH]  = {"lookupswitch", 0, -1, op_lookupswitch},
    
    /* Returns */
    [OPC_IRETURN]       = {"ireturn", 0, -1, op_ireturn},
    [OPC_LRETURN]       = {"lreturn", 0, -2, op_lreturn},
    [OPC_FRETURN]       = {"freturn", 0, -1, op_freturn},
    [OPC_DRETURN]       = {"dreturn", 0, -2, op_dreturn},
    [OPC_ARETURN]       = {"areturn", 0, -1, op_areturn},
    [OPC_RETURN]        = {"return", 0, 0, op_return},
    
    /* Field access */
    [OPC_GETSTATIC]     = {"getstatic", 2, 1, op_getstatic},
    [OPC_PUTSTATIC]     = {"putstatic", 2, -1, op_putstatic},
    [OPC_GETFIELD]      = {"getfield", 2, 0, op_getfield},
    [OPC_PUTFIELD]      = {"putfield", 2, -2, op_putfield},
    
    /* Method invocation */
    [OPC_INVOKEVIRTUAL]   = {"invokevirtual", 2, 0, op_invokevirtual},
    [OPC_INVOKESPECIAL]   = {"invokespecial", 2, 0, op_invokespecial},
    [OPC_INVOKESTATIC]    = {"invokestatic", 2, 0, op_invokestatic},
    [OPC_INVOKEINTERFACE] = {"invokeinterface", 4, 0, op_invokeinterface},
    
    /* Object creation */
    [OPC_NEW]             = {"new", 2, 1, op_new},
    [OPC_NEWARRAY]        = {"newarray", 1, 0, op_newarray},
    [OPC_ANEWARRAY]       = {"anewarray", 2, 0, op_anewarray},
    [OPC_ARRAYLENGTH]     = {"arraylength", 0, 1, op_arraylength},
    [OPC_ATHROW]          = {"athrow", 0, 0, op_athrow},
    [OPC_CHECKCAST]       = {"checkcast", 2, 0, op_checkcast},
    [OPC_INSTANCEOF]      = {"instanceof", 2, 0, op_instanceof},
    [OPC_MONITORENTER]    = {"monitorenter", 0, -1, op_monitorenter},
    [OPC_MONITOREXIT]     = {"monitorexit", 0, -1, op_monitorexit},
    
    /* Extended */
    [OPC_WIDE]            = {"wide", 0, 0, op_wide},
    [OPC_MULTIANEWARRAY]  = {"multianewarray", 3, 1, op_multianewarray},
    [OPC_IFNULL]          = {"ifnull", 2, -1, op_ifnull},
    [OPC_IFNONNULL]       = {"ifnonnull", 2, -1, op_ifnonnull},
    [OPC_GOTO_W]          = {"goto_w", 4, 0, op_goto_w},
    [OPC_JSR_W]           = {"jsr_w", 4, 1, op_jsr_w},
};

/* Initialize opcodes */
void opcodes_init(void) {
    /* Opcode table is statically initialized */
}

/* Macro helpers */
#define FETCH_U1(frame) ((frame)->code[(frame)->pc++])
#define FETCH_U2(frame) (frame->pc += 2, jvm_read_u16(frame->code + frame->pc - 2))
#define FETCH_S1(frame) ((int8_t)FETCH_U1(frame))
#define FETCH_S2(frame) ((int16_t)FETCH_U2(frame))

/* Stack operations with bounds checking */
/* PUSH checks if there's room for one more value */
#define PUSH(frame, val) do { \
    if ((frame)->stack_top + 1 >= (int)(frame)->max_stack) { \
        fprintf(stderr, "[EXEC] Stack overflow in %s: top=%d, max=%d\n", \
                (frame)->method->name, (frame)->stack_top + 1, (frame)->max_stack); \
        return -1; \
    } \
    (frame)->stack[++(frame)->stack_top] = (val); \
} while(0)

/* PUSH2 for long/double - checks if there's room for two values */
#define PUSH2(frame, val) do { \
    if ((frame)->stack_top + 2 >= (int)(frame)->max_stack) { \
        fprintf(stderr, "[EXEC] Stack overflow (2 slots) in %s: top=%d, max=%d\n", \
                (frame)->method->name, (frame)->stack_top + 2, (frame)->max_stack); \
        return -1; \
    } \
    (frame)->stack[++(frame)->stack_top] = (val); \
    (frame)->stack[++(frame)->stack_top] = (val); \
} while(0)

/* Safe pop that returns error on underflow */
static inline JavaValue safe_pop(JavaFrame* frame) {
    if (frame->stack_top < 0) {
        fprintf(stderr, "[EXEC] Stack underflow in %s\n", frame->method->name);
        JavaValue v = { .i = 0 };
        return v;
    }
    return frame->stack[frame->stack_top--];
}

#define POP(frame) safe_pop(frame)
#define PEEK(frame) ((frame)->stack[(frame)->stack_top])

/* Safe local variable access with bounds checking */
static inline JavaValue* safe_local_ptr(JavaFrame* frame, uint16_t idx) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return NULL;
    }
    return &frame->locals[idx];
}

/* For simple cases where we want to return error on out-of-bounds */
static inline int load_local(JavaFrame* frame, uint16_t idx, JavaValue* result) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return -1;
    }
    *result = frame->locals[idx];
    return 0;
}

static inline int store_local(JavaFrame* frame, uint16_t idx, JavaValue value) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return -1;
    }
    frame->locals[idx] = value;
    return 0;
}

/* Helper to calculate instance field slot index */
static int get_instance_field_slot(JavaClass* clazz, int field_index) {
    int slot = 0;
    
    /* Add superclass instance size offset */
    if (clazz->super_class) {
        /* Assuming instance_size is in bytes, divide by sizeof(JavaValue) to get slots */
        slot = clazz->super_class->instance_size / sizeof(JavaValue);
    }
    
    /* Count instance fields preceding the target field */
    for (int i = 0; i < field_index; i++) {
        if (!(clazz->fields[i].access_flags & ACC_STATIC)) {
            slot++;
            /* Long and double occupy 2 slots */
            if (clazz->fields[i].descriptor && 
                (clazz->fields[i].descriptor[0] == 'J' || clazz->fields[i].descriptor[0] == 'D')) {
                slot++;
            }
        }
    }
    return slot;
}

/* === CRITICAL FIX: Find field in class hierarchy ===
 * Searches for a field by name in the class and all superclasses.
 * Returns the class where the field was found and sets *out_field_index.
 * Returns NULL if field not found.
 */
typedef struct {
    JavaClass* defining_class;  /* Class where field is defined */
    int field_index;            /* Index in defining_class->fields[] */
    int slot;                   /* Calculated slot in object instance */
} FieldLookupResult;

/* Helper: count instance fields in a class (excluding static) */
static int count_instance_fields(JavaClass* clazz) {
    int count = 0;
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            if (!(clazz->fields[i].access_flags & ACC_STATIC)) {
                count++;
                /* Long and double take 2 slots */
                if (clazz->fields[i].descriptor &&
                    (clazz->fields[i].descriptor[0] == 'J' || clazz->fields[i].descriptor[0] == 'D')) {
                    count++;
                }
            }
        }
    }
    return count;
}

/* Helper: count instance fields up to (but not including) field_index */
static int count_instance_fields_before(JavaClass* clazz, int field_index) {
    int count = 0;
    if (clazz->fields) {
        for (int i = 0; i < field_index; i++) {
            if (!(clazz->fields[i].access_flags & ACC_STATIC)) {
                count++;
                /* Long and double take 2 slots */
                if (clazz->fields[i].descriptor &&
                    (clazz->fields[i].descriptor[0] == 'J' || clazz->fields[i].descriptor[0] == 'D')) {
                    count++;
                }
            }
        }
    }
    return count;
}

/* Build class hierarchy array from Object to obj_class */
static int build_hierarchy(JavaClass* obj_class, JavaClass** hierarchy, int max_depth) {
    int depth = 0;
    JavaClass* c = obj_class;
    
    /* Walk up to Object */
    while (c && depth < max_depth) {
        hierarchy[depth++] = c;
        c = c->super_class;
    }
    
    /* Reverse to get Object first */
    for (int i = 0; i < depth / 2; i++) {
        JavaClass* tmp = hierarchy[i];
        hierarchy[i] = hierarchy[depth - 1 - i];
        hierarchy[depth - 1 - i] = tmp;
    }
    
    return depth;
}

static FieldLookupResult find_field_in_hierarchy(JavaClass* obj_class, 
                                                   const char* field_name, 
                                                   const char* descriptor) {
    FieldLookupResult result = { NULL, -1, -1 };
    
    /* Build hierarchy from Object to obj_class */
    JavaClass* hierarchy[64];
    int depth = build_hierarchy(obj_class, hierarchy, 64);
    
    /* Search for field in hierarchy (from Object to obj_class) */
    for (int h = 0; h < depth; h++) {
        JavaClass* current_class = hierarchy[h];
        
        if (current_class->fields) {
            for (int i = 0; i < current_class->fields_count; i++) {
                JavaField* field = &current_class->fields[i];
                
                /* Skip static fields */
                if (field->access_flags & ACC_STATIC) continue;
                
                /* Match by name */
                if (!field->name || strcmp(field->name, field_name) != 0) continue;
                
                /* Match by descriptor if provided */
                if (descriptor && field->descriptor) {
                    if (strcmp(field->descriptor, descriptor) != 0) continue;
                }
                
                /* Found the field! */
                result.defining_class = current_class;
                result.field_index = i;
                
                /* Calculate slot: sum all instance fields in classes before this one,
                 * plus instance fields before this field in current class */
                result.slot = 0;
                
                /* Add fields from all classes above current_class in hierarchy */
                for (int j = 0; j < h; j++) {
                    result.slot += count_instance_fields(hierarchy[j]);
                }
                
                /* Add fields before this one in current_class */
                result.slot += count_instance_fields_before(current_class, i);
                
                return result;
            }
        }
    }
    
    return result;
}

/* Macros for backward compatibility with bounds checking */
#define LOCAL(frame, idx) (*safe_local_ptr(frame, idx))

/* Basic opcodes */
int op_nop(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    return 0;
}

int op_aconst_null(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = { .ref = NULL };
    PUSH(frame, v);
    return 0;
}

int op_iconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint value = opcode - OPC_ICONST_0;  /* -1 to 5 */
    JavaValue v = { .i = value };
    PUSH(frame, v);
    return 0;
}

int op_lconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jlong value = opcode - OPC_LCONST_0;  /* 0 or 1 */
    
    /* Long занимает 2 слота стека: low word и high word */
    JavaValue low = { .j = value };
    JavaValue high = { .raw = 0 };  /* High word для положительных чисел */
    
    PUSH(frame, low);
    PUSH(frame, high);
    return 0;
}

int op_fconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jfloat value = (jfloat)(opcode - OPC_FCONST_0);  /* 0.0, 1.0, or 2.0 */
    JavaValue v = { .f = value };
    PUSH(frame, v);
    return 0;
}

int op_dconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jdouble value = (jdouble)(opcode - OPC_DCONST_0);  /* 0.0 or 1.0 */
    
    /* Double занимает 2 слота стека */
    JavaValue low = { .d = value };
    JavaValue high = { .raw = 0 };
    
    PUSH(frame, low);
    PUSH(frame, high);
    return 0;
}

int op_bipush(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int8_t value = FETCH_S1(frame);
    JavaValue v = { .i = (jint)value };
    PUSH(frame, v);
    return 0;
}

int op_sipush(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t value = FETCH_S2(frame);
    JavaValue v = { .i = (jint)value };
    PUSH(frame, v);
    return 0;
}

int op_ldc(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaClass* clazz = frame->clazz;
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Integer:
            v.i = entry->info.integer.value;
            break;
        case CONSTANT_Float:
            v.f = entry->info.float_val.value;
            break;
        case CONSTANT_String: {
            const char* str = classfile_get_utf8(clazz, entry->info.string_info.string_index);
            v.ref = jvm_new_string(jvm, str);
            break;
        }
        case CONSTANT_Class: {
            const char* name = classfile_get_utf8(clazz, entry->info.class_info.name_index);
            v.ref = jvm_load_class(jvm, name);
            break;
        }
        default:
            return -1;
    }
    
    PUSH(frame, v);
    return 0;
}

int op_ldc_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaClass* clazz = frame->clazz;
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Integer:
            v.i = entry->info.integer.value;
            break;
        case CONSTANT_Float:
            v.f = entry->info.float_val.value;
            break;
        case CONSTANT_String: {
            const char* str = classfile_get_utf8(clazz, entry->info.string_info.string_index);
            v.ref = jvm_new_string(jvm, str);
            break;
        }
        default:
            return -1;
    }
    
    PUSH(frame, v);
    return 0;
}

int op_ldc2_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaClass* clazz = frame->clazz;
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Long:
            v.j = entry->info.long_val.value;
            break;
        case CONSTANT_Double:
            v.d = entry->info.double_val.value;
            break;
        default:
            return -1;
    }
    
    /* Long/double occupy 2 stack slots */
    PUSH(frame, v);
    /* Push a second slot (the value is already in v.j/v.d, this is just for stack accounting) */
    PUSH(frame, v);
    return 0;
}

/* Load opcodes */
int op_iload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        return -1;
    }
    PUSH(frame, v);
    return 0;
}

int op_lload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v1, v2;
    if (load_local(frame, index, &v1) != 0) return -1;
    if (load_local(frame, index + 1, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_fload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_dload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v1, v2;
    if (load_local(frame, index, &v1) != 0) return -1;
    if (load_local(frame, index + 1, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_aload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        return -1;
    }
    PUSH(frame, v);
    return 0;
}

int op_load_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 0, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 1, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 2, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 3, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

/* Long/Double load opcodes - these need 2 stack slots */
int op_lload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v0, v1;
    if (load_local(frame, 0, &v0) != 0) return -1;
    if (load_local(frame, 1, &v1) != 0) return -1;
    PUSH(frame, v0);
    PUSH(frame, v1);
    return 0;
}

int op_lload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (load_local(frame, 1, &v1) != 0) return -1;
    if (load_local(frame, 2, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_lload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v3;
    if (load_local(frame, 2, &v2) != 0) return -1;
    if (load_local(frame, 3, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v3);
    return 0;
}

int op_lload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v4;
    if (load_local(frame, 3, &v3) != 0) return -1;
    if (load_local(frame, 4, &v4) != 0) return -1;
    PUSH(frame, v3);
    PUSH(frame, v4);
    return 0;
}

/* dload_X same as lload_X */
int op_dload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v0, v1;
    if (load_local(frame, 0, &v0) != 0) return -1;
    if (load_local(frame, 1, &v1) != 0) return -1;
    PUSH(frame, v0);
    PUSH(frame, v1);
    return 0;
}

int op_dload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (load_local(frame, 1, &v1) != 0) return -1;
    if (load_local(frame, 2, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_dload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v3;
    if (load_local(frame, 2, &v2) != 0) return -1;
    if (load_local(frame, 3, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v3);
    return 0;
}

int op_dload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v4;
    if (load_local(frame, 3, &v3) != 0) return -1;
    if (load_local(frame, 4, &v4) != 0) return -1;
    PUSH(frame, v3);
    PUSH(frame, v4);
    return 0;
}

/* Array load */
int op_array_load(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint index = POP(frame).i;
    JavaArray* array = (JavaArray*)POP(frame).ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (index < 0 || index >= array->length) {
        native_throw_aioobe(jvm, thread, index);
        return -1;
    }
    
    JavaValue v = array_get(array, index);
    PUSH(frame, v);
    
    /* Long and double need 2 stack slots */
    if (opcode == OPC_LALOAD || opcode == OPC_DALOAD) {
        PUSH(frame, v);
    }
    
    return 0;
}

/* Store opcodes */
int op_store(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v = POP(frame);
    if (store_local(frame, index, v) != 0) {
        fprintf(stderr, "[EXEC] op_store: failed to store at index %d (max_locals=%d)\n", 
                index, frame->max_locals);
        return -1;
    }
    return 0;
}

/* Long/Double store - needs to pop 2 slots and store in 2 locals */
int op_lstore(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue high = POP(frame);  /* High word */
    JavaValue low = POP(frame);   /* Low word */
    if (store_local(frame, index, low) != 0) return -1;
    if (store_local(frame, index + 1, high) != 0) return -1;
    return 0;
}

int op_dstore(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    return op_lstore(jvm, thread, frame);  /* Same implementation */
}

int op_store_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 0, v) != 0) return -1;
    return 0;
}

int op_store_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 1, v) != 0) return -1;
    return 0;
}

int op_store_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 2, v) != 0) return -1;
    return 0;
}

int op_store_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 3, v) != 0) return -1;
    return 0;
}

/* Long/Double store opcodes - these need 2 stack slots */
int op_lstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);  /* Pop high word first */
    JavaValue v0 = POP(frame);  /* Pop low word second */
    if (store_local(frame, 1, v1) != 0) return -1;
    if (store_local(frame, 0, v0) != 0) return -1;
    return 0;
}

int op_lstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    if (store_local(frame, 2, v2) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    return 0;
}

int op_lstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3 = POP(frame);
    JavaValue v2 = POP(frame);
    if (store_local(frame, 3, v3) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    return 0;
}

int op_lstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v4 = POP(frame);
    JavaValue v3 = POP(frame);
    if (store_local(frame, 4, v4) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    return 0;
}

/* dstore_X same as lstore_X */
int op_dstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v0 = POP(frame);
    if (store_local(frame, 1, v1) != 0) return -1;
    if (store_local(frame, 0, v0) != 0) return -1;
    return 0;
}

int op_dstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    if (store_local(frame, 2, v2) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    return 0;
}

int op_dstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3 = POP(frame);
    JavaValue v2 = POP(frame);
    if (store_local(frame, 3, v3) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    return 0;
}

int op_dstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v4 = POP(frame);
    JavaValue v3 = POP(frame);
    if (store_local(frame, 4, v4) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    return 0;
}

/* Array store */
int op_array_store(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint8_t opcode = frame->code[frame->pc - 1];
    
    /* Long and double need to pop 2 stack slots for the value */
    JavaValue value;
    if (opcode == OPC_LASTORE || opcode == OPC_DASTORE) {
        POP(frame); /* discard high slot */
        value = POP(frame);
    } else {
        value = POP(frame);
    }
    
    jint index = POP(frame).i;
    JavaArray* array = (JavaArray*)POP(frame).ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (index < 0 || index >= array->length) {
        native_throw_aioobe(jvm, thread, index);
        return -1;
    }
    
    array_set(array, index, value);
    return 0;
}

/* Stack operations */
int op_pop(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    POP(frame);
    return 0;
}

int op_pop2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    POP(frame);
    POP(frame);
    return 0;
}

int op_dup(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = PEEK(frame);
    PUSH(frame, v);
    return 0;
}

int op_dup_x1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    PUSH(frame, v1);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup_x2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    JavaValue v3 = POP(frame);
    PUSH(frame, v1);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2_x1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    JavaValue v3 = POP(frame);
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2_x2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    JavaValue v3 = POP(frame);
    JavaValue v4 = POP(frame);
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v4);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_swap(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

/* Arithmetic operations */
int op_add(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_IADD: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i + v2.i; 
            PUSH(frame, result);
            break;
            
        case OPC_LADD: 
            /* ИСПРАВЛЕНО: Long хранится в одном JavaValue (union), но занимает 2 слота стека.
             * Сначала pop high slot (фиктивный), потом low slot с реальным значением */
            POP(frame);  /* v2 high slot (фиктивный) */
            JavaValue v2_l = POP(frame);  /* v2 low slot с реальным jlong */
            POP(frame);  /* v1 high slot (фиктивный) */
            JavaValue v1_l = POP(frame);  /* v1 low slot с реальным jlong */
            
            result.j = v1_l.j + v2_l.j;
            
            /* Push результат как 2 слота (low + high для совместимости) */
            PUSH(frame, result);
            PUSH(frame, result);  /* high slot = копия low slot */
            break;
            
        case OPC_FADD: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.f = v1.f + v2.f; 
            PUSH(frame, result);
            break;
            
        case OPC_DADD: 
            /* ИСПРАВЛЕНО: Double хранится в одном JavaValue (union), но занимает 2 слота стека */
            POP(frame);  /* d2 high slot (фиктивный) */
            JavaValue d2_d = POP(frame);  /* d2 low slot с реальным jdouble */
            POP(frame);  /* d1 high slot (фиктивный) */
            JavaValue d1_d = POP(frame);  /* d1 low slot с реальным jdouble */
            
            result.d = d1_d.d + d2_d.d;
            
            PUSH(frame, result);
            PUSH(frame, result);  /* high slot = копия low slot */
            break;
    }
    
    return 0;
}

int op_sub(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_ISUB: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i - v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LSUB: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j - v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_FSUB: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.f = v1.f - v2.f; 
            PUSH(frame, result);
            break;
        case OPC_DSUB: 
            /* Pop 2 slots for each double */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.d = v1.d - v2.d;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_mul(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_IMUL: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i * v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LMUL: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j * v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_FMUL: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.f = v1.f * v2.f; 
            PUSH(frame, result);
            break;
        case OPC_DMUL: 
            /* Pop 2 slots for each double */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.d = v1.d * v2.d;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_div(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    /* TODO: Check for division by zero */
    switch (opcode) {
        case OPC_IDIV: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i / v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LDIV: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j / v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_FDIV: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.f = v1.f / v2.f; 
            PUSH(frame, result);
            break;
        case OPC_DDIV: 
            /* Pop 2 slots for each double */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.d = v1.d / v2.d;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_rem(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_IREM: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i % v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LREM: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j % v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_FREM: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.f = fmodf(v1.f, v2.f); 
            PUSH(frame, result);
            break;
        case OPC_DREM: 
            /* Pop 2 slots for each double */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.d = fmod(v1.d, v2.d);
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_neg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v, result;
    
    switch (opcode) {
        case OPC_INEG: 
            v = POP(frame);
            result.i = -v.i; 
            PUSH(frame, result);
            break;
        case OPC_LNEG: 
            /* Pop 2 slots for long */
            POP(frame); /* high */
            v = POP(frame);
            result.j = -v.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_FNEG: 
            v = POP(frame);
            result.f = -v.f; 
            PUSH(frame, result);
            break;
        case OPC_DNEG: 
            /* Pop 2 slots for double */
            POP(frame); /* high */
            v = POP(frame);
            result.d = -v.d;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_shl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint shift = POP(frame).i & 0x3F;
    JavaValue v, result;
    
    switch (opcode) {
        case OPC_ISHL: 
            v = POP(frame);
            result.i = v.i << shift; 
            PUSH(frame, result);
            break;
        case OPC_LSHL: 
            /* Pop 2 slots for long */
            POP(frame); /* high */
            v = POP(frame);
            result.j = v.j << shift;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_shr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint shift = POP(frame).i & 0x3F;
    JavaValue v, result;
    
    switch (opcode) {
        case OPC_ISHR: 
            v = POP(frame);
            result.i = v.i >> shift; 
            PUSH(frame, result);
            break;
        case OPC_LSHR: 
            /* Pop 2 slots for long */
            POP(frame); /* high */
            v = POP(frame);
            result.j = v.j >> shift;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_ushr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint shift = POP(frame).i & 0x3F;
    JavaValue v, result;
    
    switch (opcode) {
        case OPC_IUSHR: 
            v = POP(frame);
            result.i = ((juint)v.i) >> shift; 
            PUSH(frame, result);
            break;
        case OPC_LUSHR: 
            /* Pop 2 slots for long */
            POP(frame); /* high */
            v = POP(frame);
            result.j = ((julong)v.j) >> shift;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_and(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_IAND: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i & v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LAND: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j & v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_or(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_IOR: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i | v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LOR: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j | v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_xor(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1, result;
    
    switch (opcode) {
        case OPC_IXOR: 
            v2 = POP(frame);
            v1 = POP(frame);
            result.i = v1.i ^ v2.i; 
            PUSH(frame, result);
            break;
        case OPC_LXOR: 
            /* Pop 2 slots for each long */
            POP(frame); /* v2 high */
            v2 = POP(frame);
            POP(frame); /* v1 high */
            v1 = POP(frame);
            result.j = v1.j ^ v2.j;
            PUSH(frame, result);
            PUSH(frame, result);
            break;
    }
    
    return 0;
}

int op_iinc(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    int8_t constant = FETCH_S1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        fprintf(stderr, "[EXEC] iinc: failed to load from index %d\n", index);
        return -1;
    }
    v.i += constant;
    if (store_local(frame, index, v) != 0) {
        fprintf(stderr, "[EXEC] iinc: failed to store to index %d\n", index);
        return -1;
    }
    return 0;
}

/* Conversion operations */
int op_convert(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v, result;
    
    switch (opcode) {
        /* int/float -> long/double: pop 1, push 2 */
        case OPC_I2L: 
            v = POP(frame);
            result.j = (jlong)v.i; 
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_I2D: 
            v = POP(frame);
            result.d = (jdouble)v.i; 
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_F2L: 
            v = POP(frame);
            result.j = (jlong)v.f; 
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_F2D: 
            v = POP(frame);
            result.d = (jdouble)v.f; 
            PUSH(frame, result);
            PUSH(frame, result);
            break;
            
        /* long/double -> int/float: pop 2, push 1 */
        case OPC_L2I: 
            POP(frame); /* discard high slot */
            v = POP(frame);
            result.i = (jint)v.j; 
            PUSH(frame, result);
            break;
        case OPC_L2F: 
            POP(frame); /* discard high slot */
            v = POP(frame);
            result.f = (jfloat)v.j; 
            PUSH(frame, result);
            break;
        case OPC_D2I: 
            POP(frame); /* discard high slot */
            v = POP(frame);
            result.i = (jint)v.d; 
            PUSH(frame, result);
            break;
        case OPC_D2F: 
            POP(frame); /* discard high slot */
            v = POP(frame);
            result.f = (jfloat)v.d; 
            PUSH(frame, result);
            break;
            
        /* long <-> double: pop 2, push 2 */
        case OPC_L2D: 
            v = POP(frame); /* high slot */
            result = POP(frame); /* low slot with the actual value */
            result.d = (jdouble)result.j; 
            PUSH(frame, result);
            PUSH(frame, result);
            break;
        case OPC_D2L: 
            v = POP(frame); /* high slot */
            result = POP(frame); /* low slot with the actual value */
            result.j = (jlong)result.d; 
            PUSH(frame, result);
            PUSH(frame, result);
            break;
            
        /* int -> int: pop 1, push 1 */
        case OPC_I2F: 
            v = POP(frame);
            result.f = (jfloat)v.i; 
            PUSH(frame, result);
            break;
        case OPC_I2B: 
            v = POP(frame);
            result.i = (jint)(int8_t)v.i; 
            PUSH(frame, result);
            break;
        case OPC_I2C: 
            v = POP(frame);
            result.i = (jint)(uint8_t)v.i; 
            PUSH(frame, result);
            break;
        case OPC_I2S: 
            v = POP(frame);
            result.i = (jint)(int16_t)v.i; 
            PUSH(frame, result);
            break;
        default: return -1;
    }
    
    return 0;
}

/* Comparison operations */
int op_lcmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    /* Pop 2 slots for each long value */
    POP(frame); /* v2 high slot */
    jlong v2 = POP(frame).j;
    POP(frame); /* v1 high slot */
    jlong v1 = POP(frame).j;
    JavaValue result;
    result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_fcmpl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jfloat v2 = POP(frame).f;
    jfloat v1 = POP(frame).f;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = -1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_fcmpg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jfloat v2 = POP(frame).f;
    jfloat v1 = POP(frame).f;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = 1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_dcmpl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    /* Pop 2 slots for each double value */
    POP(frame); /* v2 high slot */
    jdouble v2 = POP(frame).d;
    POP(frame); /* v1 high slot */
    jdouble v1 = POP(frame).d;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = -1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_dcmpg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    /* Pop 2 slots for each double value */
    POP(frame); /* v2 high slot */
    jdouble v2 = POP(frame).d;
    POP(frame); /* v1 high slot */
    jdouble v1 = POP(frame).d;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = 1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

/* Branch operations */
int op_if(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    int16_t offset = FETCH_S2(frame);
    JavaValue val = POP(frame);
    bool branch = false;
    
    /* Use jint for comparison - this is correct for both int and reference types
       For references: null = 0, non-null = non-zero address (lower 32 bits on 64-bit)
       For integers: the actual integer value */
    jint value = val.i;
    
    switch (opcode) {
        case OPC_IFEQ: branch = (value == 0); break;
        case OPC_IFNE: branch = (value != 0); break;
        case OPC_IFLT: branch = (value < 0); break;
        case OPC_IFGE: branch = (value >= 0); break;
        case OPC_IFGT: branch = (value > 0); break;
        case OPC_IFLE: branch = (value <= 0); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;  /* -3 for opcode + operand */
    }
    
    return 0;
}

int op_if_icmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    int16_t offset = FETCH_S2(frame);
    jint v2 = POP(frame).i;
    jint v1 = POP(frame).i;
    bool branch = false;
    
    switch (opcode) {
        case OPC_IF_ICMPEQ: branch = (v1 == v2); break;
        case OPC_IF_ICMPNE: branch = (v1 != v2); break;
        case OPC_IF_ICMPLT: branch = (v1 < v2); break;
        case OPC_IF_ICMPGE: branch = (v1 >= v2); break;
        case OPC_IF_ICMPGT: branch = (v1 > v2); break;
        case OPC_IF_ICMPLE: branch = (v1 <= v2); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_if_acmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    int16_t offset = FETCH_S2(frame);
    void* v2 = POP(frame).ref;
    void* v1 = POP(frame).ref;
    bool branch = false;
    
    switch (opcode) {
        case OPC_IF_ACMPEQ: branch = (v1 == v2); break;
        case OPC_IF_ACMPNE: branch = (v1 != v2); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_goto(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    frame->pc += offset - 3;
    return 0;
}

int op_jsr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue ret_addr = { .i = frame->pc };
    PUSH(frame, ret_addr);
    frame->pc += offset - 3;
    return 0;
}

int op_ret(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    frame->pc = LOCAL(frame, index).i;
    return 0;
}

int op_tableswitch(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* Save the start of tableswitch instruction (opcode is at pc-1) */
    /* Offsets in tableswitch are relative to the opcode's address */
    uint32_t start_pc = frame->pc - 1;
    
    /* Align to 4-byte boundary */
    while (frame->pc % 4 != 0) frame->pc++;
    
    int32_t default_offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    int32_t low = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    int32_t high = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    
    jint index = POP(frame).i;
    int32_t offset;
    
    if (index < low || index > high) {
        offset = default_offset;
    } else {
        offset = (int32_t)jvm_read_u32(frame->code + frame->pc + (index - low) * 4);
    }
    
    /* Jump to target - offset is relative to start of tableswitch instruction */
    frame->pc = start_pc + offset;
    
    return 0;
}

int op_lookupswitch(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* Save the start of lookupswitch instruction (opcode is at pc-1) */
    /* Offsets in lookupswitch are relative to the opcode's address */
    uint32_t start_pc = frame->pc - 1;
    
    /* Align to 4-byte boundary */
    while (frame->pc % 4 != 0) frame->pc++;
    
    int32_t default_offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    int32_t npairs = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    
    jint key = POP(frame).i;
    int32_t offset = default_offset;
    
    for (int32_t i = 0; i < npairs; i++) {
        int32_t match = (int32_t)jvm_read_u32(frame->code + frame->pc);
        frame->pc += 4;
        int32_t jump = (int32_t)jvm_read_u32(frame->code + frame->pc);
        frame->pc += 4;
        
        if (match == key) {
            offset = jump;
            break;
        }
    }
    
    /* Jump to target - offset is relative to start of lookupswitch instruction */
    frame->pc = start_pc + offset;
    return 0;
}

/* Return operations */
int op_return(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    return 1;  /* Signal return */
}

int op_ireturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* КРИТИЧЕСКАЯ ПРОВЕРКА: есть ли кадр вызова */
    if (!frame->prev) {
        fprintf(stderr, "[EXEC] ERROR: op_ireturn with no caller frame!\n");
        return -1;
    }
    
    JavaValue result = POP(frame);
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = result;
    return 1;
}

int op_lreturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* КРИТИЧЕСКАЯ ПРОВЕРКА: есть ли кадр вызова */
    if (!frame->prev) {
        fprintf(stderr, "[EXEC] ERROR: op_lreturn with no caller frame!\n");
        return -1;
    }
    
    /* Pop 2 slots для long */
    JavaValue high = POP(frame);
    JavaValue result = POP(frame);
    
    /* Push 2 slots в стек вызвавшего */
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = result;
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = high;
    return 1;
}

int op_freturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* КРИТИЧЕСКАЯ ПРОВЕРКА: есть ли кадр вызова */
    if (!frame->prev) {
        fprintf(stderr, "[EXEC] ERROR: op_freturn with no caller frame!\n");
        return -1;
    }
    
    JavaValue result = POP(frame);
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = result;
    return 1;
}

int op_dreturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* КРИТИЧЕСКАЯ ПРОВЕРКА: есть ли кадр вызова */
    if (!frame->prev) {
        fprintf(stderr, "[EXEC] ERROR: op_dreturn with no caller frame!\n");
        return -1;
    }
    
    /* Pop 2 slots для double */
    JavaValue high = POP(frame);
    JavaValue result = POP(frame);
    
    /* Push 2 slots в стек вызвавшего */
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = result;
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = high;
    return 1;
}

int op_areturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* КРИТИЧЕСКАЯ ПРОВЕРКА: есть ли кадр вызова */
    if (!frame->prev) {
        fprintf(stderr, "[EXEC] ERROR: op_areturn with no caller frame!\n");
        return -1;
    }
    
    JavaValue result = POP(frame);
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = result;
    return 1;
}

/* Field access - simplified stubs */
int op_getstatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }

    if (!class_name || !field_name || !descriptor) {
        fprintf(stderr, "[EXEC] getstatic: Invalid constant pool index %d\n", index);
        JavaValue v = { .i = 0 };
        PUSH(frame, v);
        if (descriptor && (descriptor[0] == 'J' || descriptor[0] == 'D')) PUSH(frame, v);
        return 0;
    }
    
    /* DEBUG: Always print getstatic */
    fprintf(stderr, "[GETSTATIC] %s.%s %s\n", class_name, field_name, descriptor);
    
    /* Load class */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    if (!target_class) {
        fprintf(stderr, "[EXEC] getstatic: Class %s not found\n", class_name);
        JavaValue v = { .i = 0 };
        PUSH(frame, v);
        if (descriptor && (descriptor[0] == 'J' || descriptor[0] == 'D')) PUSH(frame, v);
        return 0;
    }
    
    /* CRITICAL: Initialize class before access! */
    if (!target_class->initialized) {
        if (jvm_init_class(jvm, target_class) != 0) {
            return -1;
        }
    }
    
    /* Ensure static storage exists (for stubs) */
    if (!target_class->static_fields) {
        target_class->static_fields = (JavaStaticField*)calloc(16, sizeof(JavaStaticField));
        target_class->static_fields_count = 0;
        target_class->static_fields_capacity = 16;
    }
    
    /* Search for field */
    JavaValue v = { .raw = 0 };
    bool found = false;
    
    for (int i = 0; i < target_class->static_fields_count; i++) {
        if (target_class->static_fields[i].name && 
            strcmp(target_class->static_fields[i].name, field_name) == 0) {
            v = target_class->static_fields[i].value;
            found = true;
            break;
        }
    }
    
    if (!found) {
        fprintf(stderr, "[EXEC] getstatic: Field %s.%s not found (count=%d), returning default.\n", 
                class_name, field_name, target_class->static_fields_count);
    } else {
        fprintf(stderr, "[EXEC] getstatic: Found %s.%s = %p\n", 
                class_name, field_name, (void*)v.ref);
    }
    
    PUSH(frame, v);
    
    /* Long/double occupy 2 slots */
    if (descriptor[0] == 'J' || descriptor[0] == 'D') {
        PUSH(frame, v);
    }
    
    return 0;
}

int op_putstatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    /* Pop value */
    JavaValue v;
    if (descriptor && (descriptor[0] == 'J' || descriptor[0] == 'D')) {
        POP(frame); /* high slot */
        v = POP(frame);
    } else {
        v = POP(frame);
    }
    
    if (!class_name || !field_name) {
        fprintf(stderr, "[EXEC] putstatic: Invalid field ref\n");
        return 0;
    }

    LOG_OPCODE("[EXEC] putstatic: %s.%s = %p\n", class_name, field_name, (void*)v.ref);
    
    /* Load class */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    if (!target_class) {
        fprintf(stderr, "[EXEC] putstatic: Class %s not found\n", class_name);
        return 0;
    }
    
    /* CRITICAL: Initialize class before access! */
    if (!target_class->initialized) {
        if (jvm_init_class(jvm, target_class) != 0) {
            return -1;
        }
    }
    
    /* Ensure static storage */
    if (!target_class->static_fields) {
        target_class->static_fields = (JavaStaticField*)calloc(16, sizeof(JavaStaticField));
        target_class->static_fields_count = 0;
        target_class->static_fields_capacity = 16;
    }
    
    /* Find or create slot */
    int slot = -1;
    for (int i = 0; i < target_class->static_fields_count; i++) {
        if (target_class->static_fields[i].name && 
            strcmp(target_class->static_fields[i].name, field_name) == 0) {
            slot = i;
            break;
        }
    }
    
    if (slot == -1) {
        /* Create new slot */
        if (target_class->static_fields_count >= target_class->static_fields_capacity) {
            int new_cap = target_class->static_fields_capacity + 16;
            JavaStaticField* new_fields = (JavaStaticField*)realloc(
                target_class->static_fields, new_cap * sizeof(JavaStaticField));
            if (!new_fields) return -1;
            
            memset(new_fields + target_class->static_fields_capacity, 0, 
                   16 * sizeof(JavaStaticField));
            target_class->static_fields = new_fields;
            target_class->static_fields_capacity = new_cap;
        }
        
        slot = target_class->static_fields_count++;
        target_class->static_fields[slot].name = strdup(field_name);
        target_class->static_fields[slot].descriptor = descriptor ? strdup(descriptor) : NULL;
        fprintf(stderr, "[EXEC] putstatic: Created new slot %d for %s.%s\n", slot, class_name, field_name);
    }
    
    target_class->static_fields[slot].value = v;
    fprintf(stderr, "[EXEC] putstatic: Stored %s.%s = %p (slot %d, count=%d)\n", 
            class_name, field_name, (void*)v.ref, slot, target_class->static_fields_count);
    return 0;
}

int op_getfield(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    /* Get field reference from constant pool */
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    /* Pop object reference */
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    /* === Safety Checks === */
    if (!obj) {
        fprintf(stderr, "[EXEC] getfield: NULL object for field %s.%s\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (!obj->header.clazz) {
        fprintf(stderr, "[EXEC] getfield: FATAL: Object %p has NULL class pointer! Field: %s.%s\n", 
                (void*)obj, class_name ? class_name : "?", field_name ? field_name : "?");
        jvm_throw_by_name(jvm, "java/lang/InternalError", "Object has no class (getfield)");
        return -1;
    }
    
    if ((uintptr_t)obj->header.clazz < 0x10000) {
        fprintf(stderr, "[EXEC] getfield: FATAL: Object %p has invalid class pointer %p!\n", 
                (void*)obj, (void*)obj->header.clazz);
        jvm_throw_by_name(jvm, "java/lang/InternalError", "Object has invalid class pointer");
        return -1;
    }

    JavaClass* obj_class = obj->header.clazz;
    JavaValue v = { .i = 0 };
    
    /* === CRITICAL FIX: Use hierarchy-aware field lookup === */
    FieldLookupResult field_result = find_field_in_hierarchy(obj_class, field_name, descriptor);
    
    if (field_result.defining_class) {
        int slot = field_result.slot;
        
        /* Bounds check - max_slots is number of field slots (excluding ObjectHeader) */
        int max_slots = (obj_class->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue);
        if (slot < 0 || slot >= max_slots) {
            fprintf(stderr, "[EXEC] getfield: FATAL: Calculated slot %d out of bounds (max %d) for field %s.%s (defined in %s)\n",
                    slot, max_slots, class_name ? class_name : "?", field_name ? field_name : "?",
                    field_result.defining_class->class_name ? field_result.defining_class->class_name : "?");
            jvm_throw_by_name(jvm, "java/lang/InternalError", "Field slot out of bounds");
            return -1;
        }

        v = obj->fields[slot];
    } else {
        fprintf(stderr, "[EXEC] getfield: field %s.%s not found in hierarchy, returning 0\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
    }
    
    PUSH(frame, v);
    
    /* Long and double fields need 2 stack slots */
    if (descriptor && (descriptor[0] == 'J' || descriptor[0] == 'D')) {
        PUSH(frame, v);
    }
    
    return 0;
}

int op_putfield(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    /* Get field reference from constant pool */
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    /* Pop value - long and double need 2 stack slots */
    JavaValue value;
    if (descriptor && (descriptor[0] == 'J' || descriptor[0] == 'D')) {
        POP(frame); /* discard high slot */
        value = POP(frame);
    } else {
        value = POP(frame);
    }
    
    /* Pop object reference */
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    /* === Safety Checks === */
    if (!obj) {
        fprintf(stderr, "[EXEC] putfield: NULL object for field %s.%s\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (!obj->header.clazz) {
        fprintf(stderr, "[EXEC] putfield: FATAL: Object %p has NULL class pointer! Field: %s.%s\n", 
                (void*)obj, class_name ? class_name : "?", field_name ? field_name : "?");
        jvm_throw_by_name(jvm, "java/lang/InternalError", "Object has no class (putfield)");
        return -1;
    }
    
    if ((uintptr_t)obj->header.clazz < 0x10000) {
        fprintf(stderr, "[EXEC] putfield: FATAL: Object %p has invalid class pointer %p!\n", 
                (void*)obj, (void*)obj->header.clazz);
        jvm_throw_by_name(jvm, "java/lang/InternalError", "Object has invalid class pointer");
        return -1;
    }
    
    JavaClass* obj_class = obj->header.clazz;
    
    /* === CRITICAL FIX: Use hierarchy-aware field lookup === */
    FieldLookupResult field_result = find_field_in_hierarchy(obj_class, field_name, descriptor);
    
    if (field_result.defining_class) {
        int slot = field_result.slot;
        
        /* Bounds check - max_slots is number of field slots (excluding ObjectHeader) */
        int max_slots = (obj_class->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue);
        if (slot < 0 || slot >= max_slots) {
            fprintf(stderr, "[EXEC] putfield: FATAL: Calculated slot %d out of bounds (max %d) for field %s.%s (defined in %s)\n",
                    slot, max_slots, class_name ? class_name : "?", field_name ? field_name : "?",
                    field_result.defining_class->class_name ? field_result.defining_class->class_name : "?");
            return -1;
        }

        obj->fields[slot] = value;
        LOG_OPCODE("[EXEC] putfield: %s.%s (slot %d) = 0x%lX\n", 
                   class_name ? class_name : "?", field_name ? field_name : "?", slot, (unsigned long)value.raw);
    } else {
        fprintf(stderr, "[EXEC] putfield: field %s.%s not found in hierarchy!\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
    }
    
    return 0;
}

/* Method invocation - UPDATED with exception checking after native calls */
int op_invokevirtual(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Methodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }

    if (!descriptor) {
        fprintf(stderr, "[EXEC] FATAL: invokevirtual at index %d has NULL descriptor!\n", index);
        return -1;
    }
    
    int arg_count = count_args(descriptor);
    
    /* === FIX: CORRECT Stack check === */
    /* Need arg_count args + 1 object ref (this) = arg_count + 1 items.
       Available = stack_top + 1.
       Error if (stack_top + 1) < (arg_count + 1)  =>  stack_top < arg_count.
       This is what we had, so it was correct. But let's be explicit:
    */
    if (frame->stack_top < arg_count) {
        fprintf(stderr, "[EXEC] FATAL: Stack underflow in invokevirtual (need %d args + this, stack has %d)\n", 
                arg_count, frame->stack_top + 1);
        return -1;
    }

    JavaValue* args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!args) return -1;
    
    /* Pop arguments */
    for (int i = arg_count; i >= 1; i--) {
        args[i] = POP(frame);
    }
    
    /* Pop object reference (this) */
    args[0] = POP(frame);
    
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    LOG_OPCODE("[EXEC] invokevirtual: %s.%s%s (obj=%p, args=%d)\n", 
            class_name ? class_name : "?", 
            method_name ? method_name : "?", 
            descriptor, 
            (void*)obj, arg_count);
    fflush(stderr);
    
    /* Safety Checks */
    if (!obj) {
        fprintf(stderr, "[EXEC] invokevirtual: NULL object reference for %s.%s%s\n",
                class_name ? class_name : "?", method_name ? method_name : "?", descriptor);
        free(args);
        jvm_throw_by_name(jvm, "java/lang/NullPointerException", NULL);
        return -1;
    }
    
    /* Проверка что объект находится в куче ИЛИ это JavaClass* (Class object) */
    if (!is_heap_ptr_check(obj)) {
        /* Check if this is a JavaClass* acting as a Class object */
        /* JavaClass structs have header.clazz pointing to java/lang/Class */
        JavaClass* potential_class = (JavaClass*)obj;
        if (potential_class->header.clazz && 
            potential_class->header.clazz->class_name &&
            strcmp(potential_class->header.clazz->class_name, "java/lang/Class") == 0) {
            /* This is a valid JavaClass* acting as a Class object - allow it */
        } else {
            fprintf(stderr, "[EXEC] invokevirtual: FATAL: Object %p is NOT in heap! (heap: %p - %p)\n", 
                    (void*)obj, g_heap_start, g_heap_end);
            fprintf(stderr, "[EXEC]   Method: %s.%s%s\n", 
                    class_name ? class_name : "?", method_name ? method_name : "?", descriptor);
            free(args);
            return -1;
        }
    }
    
    /* Проверка на повреждённый или освобождённый объект */
    if (!obj->header.clazz || (uintptr_t)obj->header.clazz < 0x10000 || !obj->header.clazz->class_name) {
        fprintf(stderr, "[EXEC] invokevirtual: FATAL: Object %p has corrupted class pointer %p\n", 
                (void*)obj, (void*)obj->header.clazz);
        fprintf(stderr, "[EXEC]   Method: %s.%s%s\n", 
                class_name ? class_name : "?", method_name ? method_name : "?", descriptor);
        free(args);
        return -1;
    }
    
    /* Resolve and Execute */
    JavaClass* target_class = obj->header.clazz;
    JavaMethod* method = jvm_resolve_method(jvm, target_class, method_name, descriptor);
    
    if (!method) {
        /* Try native */
        NativeMethod native = NULL;
        JavaClass* search_class = target_class;
        while (search_class && !native) {
            native = native_find(jvm, search_class->class_name, method_name, descriptor);
            if (!native) search_class = search_class->super_class;
        }
        
        if (native) {
            JavaValue result = native(jvm, thread, args, arg_count + 1);
            free(args);
            
            if (thread->pending_exception) return -1;
            
            if (strlen(descriptor) > 0) {
                const char* ret = strchr(descriptor, ')');
                if (ret && ret[1] != 'V') {
                    PUSH(frame, result);
                    if (ret[1] == 'J' || ret[1] == 'D') PUSH(frame, result);
                }
            }
            return 0;
        }
        
        /* Stub fallback */
        fprintf(stderr, "[EXEC] invokevirtual: method %s.%s%s not found (stub?), using default\n", 
                target_class->class_name, method_name, descriptor);
        
        if (strlen(descriptor) > 0) {
            const char* ret = strchr(descriptor, ')');
            if (ret && ret[1] != 'V') {
                JavaValue default_val = { .raw = 0 };
                PUSH(frame, default_val);
                if (ret[1] == 'J' || ret[1] == 'D') PUSH(frame, default_val);
            }
        }
        free(args);
        return 0;
    }
    
    JavaValue result;
    int ret = execute_method(jvm, thread, method, args, &result);
    free(args);
    return ret;
}

int op_invokespecial(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread; (void)frame;
    uint16_t index = FETCH_U2(frame);
    
    /* Get method reference */
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Methodref || entry->tag == CONSTANT_InterfaceMethodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }
    
    /* Pop arguments based on descriptor */
    int arg_count = 0;
    JavaValue* args = NULL;
    
    if (descriptor) {
        /* Count actual Java arguments (not stack slots) */
        const char* p = descriptor;
        if (*p == '(') p++;
        int java_args = 0;
        while (*p && *p != ')') {
            switch (*p) {
                case 'J': case 'D':
                    java_args++;  /* Long/double - 1 argument, 2 slots */
                    p++;
                    break;
                case 'B': case 'C': case 'F': case 'I': case 'S': case 'Z':
                    java_args++;
                    p++;
                    break;
                case 'L':
                    java_args++;
                    while (*p && *p != ';') p++;
                    if (*p == ';') p++;
                    break;
                case '[':
                    java_args++;
                    while (*p == '[') p++;
                    if (*p == 'L') while (*p && *p != ';') p++;
                    if (*p) p++;
                    break;
                default:
                    p++;
                    break;
            }
        }
        
        /* Get stack slots needed (including 2 slots for long/double) */
        int stack_slots = count_args(descriptor);
        
        /* Allocate args array: this + java_args */
        args = (JavaValue*)malloc((java_args + 1) * sizeof(JavaValue));
        if (!args) return -1;
        
        /* Pop arguments from stack, handling long/double correctly */
        p = descriptor;
        if (*p == '(') p++;
        
        int arg_idx = java_args;
        
        /* First, collect all stack values into a temporary buffer */
        JavaValue* stack_vals = (JavaValue*)malloc((stack_slots + 1) * sizeof(JavaValue));
        if (!stack_vals) { free(args); return -1; }
        
        for (int i = stack_slots - 1; i >= 0; i--) {
            stack_vals[i] = POP(frame);
        }
        
        /* Pop object reference (this) */
        if (frame->stack_top < 0) {
            fprintf(stderr, "[EXEC] Stack underflow: no this reference\n");
            free(stack_vals);
            free(args);
            return -1;
        }
        args[0] = POP(frame);
        
        /* Now map stack values to args, combining long/double */
        int sv = 0;
        arg_idx = 1;
        p = descriptor;
        if (*p == '(') p++;
        
        while (*p && *p != ')') {
            if (*p == 'J' || *p == 'D') {
                /* Long or double - combine two slots */
                args[arg_idx].j = stack_vals[sv].j;  /* Already properly stored */
                sv += 2;
                arg_idx++;
                p++;
            } else if (*p == 'L') {
                args[arg_idx] = stack_vals[sv];
                sv++;
                arg_idx++;
                while (*p && *p != ';') p++;
                if (*p == ';') p++;
            } else if (*p == '[') {
                args[arg_idx] = stack_vals[sv];
                sv++;
                arg_idx++;
                while (*p == '[') p++;
                if (*p == 'L') while (*p && *p != ';') p++;
                if (*p) p++;
            } else {
                args[arg_idx] = stack_vals[sv];
                sv++;
                arg_idx++;
                p++;
            }
        }
        
        free(stack_vals);
        arg_count = java_args;
    }
    
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    LOG_OPCODE("[EXEC] invokespecial: %s.%s%s (obj=%p, args=%d)\n", 
            class_name ? class_name : "??", 
            method_name ? method_name : "??", 
            descriptor ? descriptor : "??",
            (void*)obj, arg_count);
    fflush(stderr);
    
    if (!obj) {
        fprintf(stderr, "[EXEC] invokespecial: NULL object!\n");
        free(args);
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    /* Get the class for the method */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    if (!target_class) {
        fprintf(stderr, "[EXEC] invokespecial: class %s not found\n", class_name);
        free(args);
        return -1;
    }
    
    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, target_class, method_name, descriptor);
    
    if (!method) {
        /* Try native method in class hierarchy */
        NativeMethod native = NULL;
        JavaClass* search_class = target_class;
        
        while (search_class && !native) {
            native = native_find(jvm, search_class->class_name, method_name, descriptor);
            if (!native) {
                search_class = search_class->super_class;
            }
        }
        
        if (native) {
            LOG_DEBUG("[EXEC] invokespecial: calling native %s.%s%s\n", 
                    search_class->class_name, method_name, descriptor);
            fflush(stderr);
            
            JavaValue result = native(jvm, thread, args, arg_count + 1);
            free(args);
            
            /* Check for exceptions */
            if (thread->pending_exception) {
                return -1;
            }
            
            /* Push result if not void */
            if (descriptor && strlen(descriptor) > 0) {
                const char* ret = strchr(descriptor, ')');
                if (ret && ret[1] != 'V') {
                    PUSH(frame, result);
                    if (ret[1] == 'J' || ret[1] == 'D') {
                        PUSH(frame, result);
                    }
                }
            }
            return 0;
        }
        
        /* 
         * CRITICAL FIX: If method is a constructor (<init>) and not found, 
         * throw NoSuchMethodError instead of silently ignoring it.
         * Silently ignoring allows "new Image()" to create uninitialized objects
         * which cause NullPointerExceptions later.
         */
        if (method_name && strcmp(method_name, "<init>") == 0) {
            fprintf(stderr, "[EXEC] invokespecial: Constructor %s.<init>%s not found. Throwing error.\n", 
                    target_class->class_name ? target_class->class_name : "?",
                    descriptor ? descriptor : "??");
            free(args);
            jvm_throw_by_name(jvm, "java/lang/NoSuchMethodError", "Constructor not found");
            thread->pending_exception = jvm_exception_pending(jvm);
            return -1;
        }
        
        /* For other methods on stub classes, provide default return */
        if (target_class->is_stub) {
            fprintf(stderr, "[EXEC] invokespecial: method %s.%s%s not found (stub class), using default\n", 
                    target_class->class_name, method_name, descriptor);
            
            /* Push default return value based on type */
            if (descriptor && strlen(descriptor) > 0) {
                const char* ret = strchr(descriptor, ')');
                if (ret && ret[1] != 'V') {
                    JavaValue default_val = { .raw = 0 };
                    PUSH(frame, default_val);
                    if (ret[1] == 'J' || ret[1] == 'D') {
                        PUSH(frame, default_val);
                    }
                }
            }
            free(args);
            return 0;
        }
        
        fprintf(stderr, "[EXEC] invokespecial: method %s.%s%s not found\n", 
                target_class->class_name, method_name, descriptor);
        free(args);
        return -1;
    }
    
    /* Execute Java method */
    JavaValue result;
    int ret = execute_method(jvm, thread, method, args, &result);
    
    free(args);
    return ret;
}

int op_invokestatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Methodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }

    /* === CRITICAL FIX: Validate descriptor === */
    if (!descriptor) {
        fprintf(stderr, "[EXEC] FATAL: op_invokestatic index %d has NULL descriptor!\n", index);
        jvm_throw_by_name(jvm, "java/lang/InternalError", "Null descriptor");
        return -1;
    }
    
    int arg_count = count_args(descriptor);
    
    /* === CRITICAL FIX: CORRECT Stack check === */
    /* stack_top is an index (0-based). arg_count is a count.
       We need (stack_top + 1) >= arg_count.
       Which simplifies to: stack_top >= arg_count - 1.
       Or error condition: stack_top < arg_count - 1.
       BUT arg_count can be 0. If arg_count=0, top >= -1 (always true).
       So condition for error: (stack_top + 1) < arg_count.
    */
    if (frame->stack_top + 1 < arg_count) {
         fprintf(stderr, "[EXEC] FATAL: Stack underflow in invokestatic (need %d args, stack has %d)\n", 
                 arg_count, frame->stack_top + 1);
         jvm_throw_by_name(jvm, "java/lang/InternalError", "Stack underflow");
         return -1;
    }

    /* Allocate args array */
    JavaValue* args = NULL;
    if (arg_count > 0) {
        args = (JavaValue*)malloc(arg_count * sizeof(JavaValue));
        if (!args) {
            jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", "Args alloc failed");
            return -1;
        }
        
        /* Pop arguments in reverse order */
        for (int i = arg_count - 1; i >= 0; i--) {
            args[i] = POP(frame);
        }
    }
    
    LOG_OPCODE("[EXEC] invokestatic: %s.%s%s (args=%d)\n", 
            class_name ? class_name : "??", 
            method_name ? method_name : "??", 
            descriptor, 
            arg_count);
    fflush(stderr);
    
    /* DEBUG: Always print invokestatic calls */
    fprintf(stderr, "[INVOKESTATIC] %s.%s%s (args=%d)\n", 
            class_name ? class_name : "??", 
            method_name ? method_name : "??", 
            descriptor ? descriptor : "??", 
            arg_count);
    
    /* Load class */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    JavaMethod* method = NULL;
    
    if (target_class) {
        /* Initialize class before static call */
        if (!target_class->initialized) {
            if (jvm_init_class(jvm, target_class) != 0) {
                free(args);  /* ИСПРАВЛЕНО: утечка памяти при ошибке */
                return -1;
            }
        }
        method = jvm_resolve_method(jvm, target_class, method_name, descriptor);
    }
    
    if (method) {
        LOG_DEBUG("[EXEC] invokestatic: calling Java method\n");
        fprintf(stderr, "[INVOKESTATIC] Found Java method %s.%s%s, executing...\n", 
                class_name, method_name, descriptor);
        JavaValue result;
        int ret = execute_method(jvm, thread, method, args, &result);
        free(args);
        return ret;
    }
    
    /* Try native method */
    NativeMethod native = native_find(jvm, class_name, method_name, descriptor);
    
    if (native) {
        LOG_DEBUG("[EXEC] invokestatic: calling native\n");
        fprintf(stderr, "[INVOKESTATIC] Found native %s.%s%s, calling...\n", 
                class_name, method_name, descriptor);
        JavaValue result = native(jvm, thread, args, arg_count);
        free(args);
        
        if (thread->pending_exception) {
            fprintf(stderr, "[INVOKESTATIC] Native threw exception!\n");
            return -1;
        }
        
        /* Push result if not void */
        if (strlen(descriptor) > 0) {
            const char* ret = strchr(descriptor, ')');
            if (ret && ret[1] != 'V') {
                PUSH(frame, result);
                if (ret[1] == 'J' || ret[1] == 'D') {
                    PUSH(frame, result);
                }
            }
        }
        return 0;
    }
    
    /* Method not found - stub fallback */
    fprintf(stderr, "[EXEC] invokestatic: %s.%s%s not found (stub?), returning default\n",
            class_name, method_name, descriptor);
    
    free(args);
    
    /* Push default return value if not void */
    if (strlen(descriptor) > 0) {
        const char* ret = strchr(descriptor, ')');
        if (ret && ret[1] != 'V') {
            JavaValue result = { .i = 0 };
            PUSH(frame, result);
            if (ret[1] == 'J' || ret[1] == 'D') {
                PUSH(frame, result);
            }
        }
    }
    
    return 0;
}

int op_invokeinterface(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    uint8_t count = FETCH_U1(frame);
    uint8_t zero = FETCH_U1(frame);
    (void)zero;
    
    /* Get method reference */
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_InterfaceMethodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }

    if (!descriptor) {
        fprintf(stderr, "[EXEC] FATAL: invokeinterface at index %d has NULL descriptor!\n", index);
        return -1;
    }
    
    int arg_count = count_args(descriptor);
    
    LOG_OPCODE("[EXEC] invokeinterface: %s.%s%s (count=%d, args=%d)\n", 
            class_name ? class_name : "?", 
            method_name ? method_name : "?", 
            descriptor, count, arg_count);
    
    /* Allocate args array: this + arguments */
    JavaValue* args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
    if (!args) return -1;
    
    /* Pop arguments in reverse order */
    for (int i = arg_count; i >= 1; i--) {
        args[i] = POP(frame);
    }
    
    /* Pop object reference (this) */
    args[0] = POP(frame);
    
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        fprintf(stderr, "[EXEC] invokeinterface: NULL object reference for %s.%s%s\n",
                class_name ? class_name : "?", method_name ? method_name : "?", descriptor);
        free(args);
        jvm_throw_by_name(jvm, "java/lang/NullPointerException", NULL);
        return -1;
    }
    
    /* For interface methods, we need to find the actual implementation in the object's class */
    JavaClass* target_class = obj->header.clazz;
    JavaMethod* method = NULL;
    NativeMethod native = NULL;
    
    /* Search in the object's class hierarchy for the method implementation */
    JavaClass* search_class = target_class;
    while (search_class && !method && !native) {
        method = jvm_resolve_method(jvm, search_class, method_name, descriptor);
        if (!method) {
            native = native_find(jvm, search_class->class_name, method_name, descriptor);
        }
        if (!method && !native) {
            search_class = search_class->super_class;
        }
    }
    
    /* If still not found, try the interface class name */
    if (!method && !native && class_name) {
        native = native_find(jvm, class_name, method_name, descriptor);
    }
    
    if (method) {
        /* Execute the method */
        JavaValue result;
        int ret = execute_method(jvm, thread, method, args, &result);
        free(args);
        
        if (ret < 0) return -1;
        if (thread->pending_exception) return -1;
        
        /* Push return value if not void */
        if (strlen(descriptor) > 0) {
            const char* ret_type = strchr(descriptor, ')');
            if (ret_type && ret_type[1] != 'V') {
                PUSH(frame, result);
                if (ret_type[1] == 'J' || ret_type[1] == 'D') {
                    PUSH(frame, result);  /* Long and double take 2 slots */
                }
            }
        }
    } else if (native) {
        /* Call native method */
        JavaValue result = native(jvm, thread, args, arg_count + 1);
        free(args);
        
        if (thread->pending_exception) return -1;
        
        /* Push return value if not void */
        if (strlen(descriptor) > 0) {
            const char* ret_type = strchr(descriptor, ')');
            if (ret_type && ret_type[1] != 'V') {
                PUSH(frame, result);
                if (ret_type[1] == 'J' || ret_type[1] == 'D') {
                    PUSH(frame, result);
                }
            }
        }
    } else {
        fprintf(stderr, "[EXEC] invokeinterface: method %s.%s%s not found!\n",
                class_name ? class_name : "?", method_name ? method_name : "?", descriptor);
        free(args);
        /* Don't throw - just return silently for now */
    }
    
    return 0;
}

/* Object creation */
int op_new(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    const char* class_name = classfile_get_class_name(frame->clazz, index);
    
    JavaClass* clazz = jvm_load_class(jvm, class_name);
    if (!clazz) {
        fprintf(stderr, "[EXEC] op_new: class %s not found!\n", class_name);
        native_throw_cnfe(jvm, thread, class_name);
        return -1;
    }
    
    /* Ensure super_class is resolved (may have been loaded from JAR) */
    if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
        LOG_DEBUG("[EXEC] op_new: resolving super_class %s for %s\n", 
                clazz->super_class_name, clazz->class_name);
        fflush(stderr);
        clazz->super_class = jvm_load_class(jvm, clazz->super_class_name);
    }
    
    /* IMPORTANT: Initialize the class before creating object!
     * This runs <clinit> which initializes static fields.
     * Per JVM spec, class initialization happens before new instance. */
    if (!clazz->initialized) {
        LOG_DEBUG("[EXEC] op_new: initializing class %s\n", clazz->class_name);
        fflush(stderr);
        
        /* Run <clinit> for the class */
        clazz->initialized = true;
        JavaMethod* clinit = jvm_resolve_method(jvm, clazz, "<clinit>", "()V");
        if (clinit) {
            LOG_DEBUG("[EXEC] op_new: running <clinit> for %s\n", clazz->class_name);
            fflush(stderr);
            JavaValue result;
            execute_method(jvm, thread, clinit, NULL, &result);
        }
    }
    
    LOG_DEBUG("[EXEC] op_new: creating %s (super_class=%p, super_class_name=%s)\n", 
            clazz->class_name, 
            (void*)clazz->super_class,
            clazz->super_class ? clazz->super_class->class_name : 
            (clazz->super_class_name ? clazz->super_class_name : "none"));
    fflush(stderr);
    
    JavaObject* obj = jvm_new_object(jvm, clazz);
    if (!obj) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = obj };
    PUSH(frame, v);
    return 0;
}

/* В op_newarray */
int op_newarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint8_t atype = FETCH_U1(frame);
    jint count = POP(frame).i;
    
    /* Критическая отладка для PC=250 */
    if (frame->pc - 2 == 250) {  /* PC начала инструкции */
        fprintf(stderr, "\n=== CRITICAL NEWARRAY AT PC=250 ===\n");
        fprintf(stderr, "Array type: %d, count: %d\n", atype, count);
        fprintf(stderr, "Stack after pop: top=%d\n", frame->stack_top);
        fprintf(stderr, "=== END CRITICAL NEWARRAY ===\n\n");
    }
    
    if (count < 0) {
        native_throw_iae(jvm, thread, "Negative array size");
        return -1;
    }
    
    /* Проверка на разумный размер */
    if (count > 1000000) {
        fprintf(stderr, "[NEWARRAY] WARNING: Suspiciously large array size: %d\n", count);
        /* Может быть, стоит бросить исключение вместо OutOfMemory */
        native_throw_iae(jvm, thread, "Array size too large");
        return -1;
    }
    
    JavaArray* array = jvm_new_array(jvm, atype, count);
    if (!array) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = array };
    PUSH(frame, v);
    return 0;
}

int op_anewarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    jint count = POP(frame).i;
    (void)index;
    
    if (count < 0) {
        native_throw_iae(jvm, thread, "Negative array size");
        return -1;
    }
    
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, count);
    if (!array) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = array };
    PUSH(frame, v);
    return 0;
}

int op_arraylength(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaArray* array = (JavaArray*)PEEK(frame).ref;
    
    if (!array) {
        /* COMPATIBILITY: Some games call arraylength on null without checking.
         * KEmulator apparently returns 0 in this case instead of throwing NPE.
         * We'll do the same for compatibility. */
        fprintf(stderr, "[EXEC] arraylength: WARNING - null array, returning 0 for compatibility\n");
        fflush(stderr);
        frame->stack[frame->stack_top].i = 0;
        return 0;
    }
    
    frame->stack[frame->stack_top].i = array->length;
    return 0;
}

int op_athrow(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaObject* exception = (JavaObject*)POP(frame).ref;
    
    if (!exception) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    jvm_throw(jvm, exception);
    return -1;  /* Signal exception */
}

int op_checkcast(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaObject* obj = (JavaObject*)PEEK(frame).ref;
    
    if (obj) {
        const char* class_name = classfile_get_class_name(frame->clazz, index);
        JavaClass* target = jvm_load_class(jvm, class_name);
        
        if (!object_instance_of(obj, target)) {
            jvm_throw_by_name(jvm, "java/lang/ClassCastException", NULL);
            return -1;
        }
    }
    
    return 0;
}

int op_instanceof(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    JavaValue result = { .i = 0 };
    
    if (obj) {
        const char* class_name = classfile_get_class_name(frame->clazz, index);
        JavaClass* target = jvm_load_class(jvm, class_name);
        result.i = object_instance_of(obj, target) ? 1 : 0;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_monitorenter(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    return monitor_enter(jvm, obj);
}

int op_monitorexit(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    return monitor_exit(jvm, obj);
}

/* Wide instructions */
int op_wide(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint8_t opcode = FETCH_U1(frame);
    uint16_t index = FETCH_U2(frame);
    JavaValue v1, v2;
    
    LOG_OPCODE("[EXEC] wide instruction: opcode=0x%02X, index=%d\n", opcode, index);
    
    switch (opcode) {
        case OPC_ILOAD:
        case OPC_FLOAD:
        case OPC_ALOAD:
            if (load_local(frame, index, &v1) != 0) return -1;
            PUSH(frame, v1);
            break;
            
        case OPC_LLOAD:
        case OPC_DLOAD:
            if (load_local(frame, index, &v1) != 0) return -1;
            if (load_local(frame, index + 1, &v2) != 0) return -1;
            PUSH(frame, v1);
            PUSH(frame, v2);
            break;
            
        case OPC_ISTORE:
        case OPC_FSTORE:
        case OPC_ASTORE:
            v1 = POP(frame);
            if (store_local(frame, index, v1) != 0) return -1;
            break;
            
        case OPC_LSTORE:
        case OPC_DSTORE:
            v2 = POP(frame);
            v1 = POP(frame);
            if (store_local(frame, index + 1, v2) != 0) return -1;
            if (store_local(frame, index, v1) != 0) return -1;
            break;
            
        case OPC_IINC: {
            int16_t constant = FETCH_S2(frame);
            if (load_local(frame, index, &v1) != 0) return -1;
            v1.i += constant;
            if (store_local(frame, index, v1) != 0) return -1;
            break;
        }
            
        case OPC_RET:
            if (load_local(frame, index, &v1) != 0) return -1;
            frame->pc = v1.i;
            break;
            
        default:
            fprintf(stderr, "[EXEC] Unknown wide opcode: 0x%02X\n", opcode);
            return -1;
    }
    
    return 0;
}

int op_multianewarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t class_index = FETCH_U2(frame);
    uint8_t dimensions = FETCH_U1(frame);
    
    /* Get array class name */
    const char* class_name = NULL;
    if (class_index > 0 && class_index < frame->clazz->constant_pool_count) {
        class_name = classfile_get_class_name(frame->clazz, class_index);
    }
    
    LOG_OPCODE("[EXEC] multianewarray: class=%s, dimensions=%d\n", 
            class_name ? class_name : "?", dimensions);
    
    /* Pop dimension sizes from stack (in reverse order) */
    jint* sizes = (jint*)malloc(dimensions * sizeof(jint));
    if (!sizes) return -1;
    
    for (int i = dimensions - 1; i >= 0; i--) {
        sizes[i] = POP(frame).i;
        if (sizes[i] < 0) {
            fprintf(stderr, "[EXEC] multianewarray: negative array size %d\n", sizes[i]);
            free(sizes);
            return -1;
        }
    }
    
    /* For now, only support 2D arrays ([[X) */
    if (dimensions == 2) {
        /* Create array of arrays */
        JavaArray* outer_array = (JavaArray*)jvm_new_array(jvm, DESC_ARRAY, sizes[0]);
        if (!outer_array) {
            fprintf(stderr, "[EXEC] multianewarray: failed to create outer array\n");
            free(sizes);
            JavaValue v = { .ref = NULL };
            PUSH(frame, v);
            return 0;
        }
        
        /* Determine element type from class name ([[X -> X) */
        int elem_type = DESC_INT;  /* Default to int */
        if (class_name && strlen(class_name) > 2) {
            char type_char = class_name[2];
            switch (type_char) {
                case 'Z': elem_type = T_BOOLEAN; break;
                case 'B': elem_type = T_BYTE; break;
                case 'C': elem_type = T_CHAR; break;
                case 'S': elem_type = T_SHORT; break;
                case 'I': elem_type = T_INT; break;
                case 'J': elem_type = T_LONG; break;
                case 'F': elem_type = T_FLOAT; break;
                case 'D': elem_type = T_DOUBLE; break;
                case 'L': case '[': elem_type = DESC_OBJECT; break;
            }
        }
        
        /* Create inner arrays */
        for (int i = 0; i < sizes[0]; i++) {
            JavaArray* inner_array = (JavaArray*)jvm_new_array(jvm, elem_type, sizes[1]);
            array_set_ref(outer_array, i, inner_array);
        }
        
        LOG_DEBUG("[EXEC] multianewarray: created %dx%d array of type %d\n", 
                sizes[0], sizes[1], elem_type);
        
        JavaValue v = { .ref = outer_array };
        PUSH(frame, v);
    } else if (dimensions == 1) {
        /* Single dimension - just create a regular array */
        int elem_type = DESC_INT;
        if (class_name && strlen(class_name) > 1) {
            char type_char = class_name[1];
            switch (type_char) {
                case 'Z': elem_type = T_BOOLEAN; break;
                case 'B': elem_type = T_BYTE; break;
                case 'C': elem_type = T_CHAR; break;
                case 'S': elem_type = T_SHORT; break;
                case 'I': elem_type = T_INT; break;
                case 'J': elem_type = T_LONG; break;
                case 'F': elem_type = T_FLOAT; break;
                case 'D': elem_type = T_DOUBLE; break;
                case 'L': case '[': elem_type = DESC_OBJECT; break;
            }
        }
        
        JavaArray* array = (JavaArray*)jvm_new_array(jvm, elem_type, sizes[0]);
        JavaValue v = { .ref = array };
        PUSH(frame, v);
    } else {
        /* More than 2 dimensions - not supported yet */
        fprintf(stderr, "[EXEC] multianewarray: %d dimensions not supported\n", dimensions);
        JavaValue v = { .ref = NULL };
        PUSH(frame, v);
    }
    
    free(sizes);
    return 0;
}

int op_ifnull(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    void* value = POP(frame).ref;
    
    if (value == NULL) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_ifnonnull(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    void* value = POP(frame).ref;
    
    if (value != NULL) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_goto_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int32_t offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4 + offset - 5;
    return 0;
}

int op_jsr_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int32_t offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    JavaValue ret_addr = { .i = frame->pc + 4 };
    PUSH(frame, ret_addr);
    frame->pc += offset;
    return 0;
}