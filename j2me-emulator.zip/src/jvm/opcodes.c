/*
 * J2ME Emulator - Bytecode Opcode Handlers
 * Implementation of all Java bytecode instructions
 */

/* For strdup on POSIX */
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* For Windows strdup compatibility */
#ifdef _WIN32
#ifndef strdup
#define strdup _strdup
#endif
#endif

#include "opcodes.h"
#include "jvm.h"
#include "classfile.h"
#include "heap.h"
#include "native.h"
#include "threads.h"  /* For monitor_enter/exit */

/* External function from native.c */
extern int count_args(const char* descriptor);

/* External function from execute.c */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                          JavaValue* args, JavaValue* result);

/* Forward declarations for long/double specific opcodes */
int op_lload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);

/* Opcode information table */
const OpcodeInfo opcode_table[256] = {
    [OPC_NOP]           = {"nop", 0, 0, op_nop},
    [OPC_ACONST_NULL]   = {"aconst_null", 0, 1, op_aconst_null},
    [OPC_ICONST_M1]     = {"iconst_m1", 0, 1, op_iconst},
    [OPC_ICONST_0]      = {"iconst_0", 0, 1, op_iconst},
    [OPC_ICONST_1]      = {"iconst_1", 0, 1, op_iconst},
    [OPC_ICONST_2]      = {"iconst_2", 0, 1, op_iconst},
    [OPC_ICONST_3]      = {"iconst_3", 0, 1, op_iconst},
    [OPC_ICONST_4]      = {"iconst_4", 0, 1, op_iconst},
    [OPC_ICONST_5]      = {"iconst_5", 0, 1, op_iconst},
    [OPC_LCONST_0]      = {"lconst_0", 0, 2, op_lconst},
    [OPC_LCONST_1]      = {"lconst_1", 0, 2, op_lconst},
    [OPC_FCONST_0]      = {"fconst_0", 0, 1, op_fconst},
    [OPC_FCONST_1]      = {"fconst_1", 0, 1, op_fconst},
    [OPC_FCONST_2]      = {"fconst_2", 0, 1, op_fconst},
    [OPC_DCONST_0]      = {"dconst_0", 0, 2, op_dconst},
    [OPC_DCONST_1]      = {"dconst_1", 0, 2, op_dconst},
    [OPC_BIPUSH]        = {"bipush", 1, 1, op_bipush},
    [OPC_SIPUSH]        = {"sipush", 2, 1, op_sipush},
    [OPC_LDC]           = {"ldc", 1, 1, op_ldc},
    [OPC_LDC_W]         = {"ldc_w", 2, 1, op_ldc_w},
    [OPC_LDC2_W]        = {"ldc2_w", 2, 2, op_ldc2_w},
    
    /* Load instructions */
    [OPC_ILOAD]         = {"iload", 1, 1, op_iload},
    [OPC_LLOAD]         = {"lload", 1, 2, op_lload},
    [OPC_FLOAD]         = {"fload", 1, 1, op_fload},
    [OPC_DLOAD]         = {"dload", 1, 2, op_dload},
    [OPC_ALOAD]         = {"aload", 1, 1, op_aload},
    [OPC_ILOAD_0]       = {"iload_0", 0, 1, op_load_0},
    [OPC_ILOAD_1]       = {"iload_1", 0, 1, op_load_1},
    [OPC_ILOAD_2]       = {"iload_2", 0, 1, op_load_2},
    [OPC_ILOAD_3]       = {"iload_3", 0, 1, op_load_3},
    [OPC_LLOAD_0]       = {"lload_0", 0, 2, op_lload_0},
    [OPC_LLOAD_1]       = {"lload_1", 0, 2, op_lload_1},
    [OPC_LLOAD_2]       = {"lload_2", 0, 2, op_lload_2},
    [OPC_LLOAD_3]       = {"lload_3", 0, 2, op_lload_3},
    [OPC_FLOAD_0]       = {"fload_0", 0, 1, op_load_0},
    [OPC_FLOAD_1]       = {"fload_1", 0, 1, op_load_1},
    [OPC_FLOAD_2]       = {"fload_2", 0, 1, op_load_2},
    [OPC_FLOAD_3]       = {"fload_3", 0, 1, op_load_3},
    [OPC_DLOAD_0]       = {"dload_0", 0, 2, op_dload_0},
    [OPC_DLOAD_1]       = {"dload_1", 0, 2, op_dload_1},
    [OPC_DLOAD_2]       = {"dload_2", 0, 2, op_dload_2},
    [OPC_DLOAD_3]       = {"dload_3", 0, 2, op_dload_3},
    [OPC_ALOAD_0]       = {"aload_0", 0, 1, op_load_0},
    [OPC_ALOAD_1]       = {"aload_1", 0, 1, op_load_1},
    [OPC_ALOAD_2]       = {"aload_2", 0, 1, op_load_2},
    [OPC_ALOAD_3]       = {"aload_3", 0, 1, op_load_3},
    
    /* Array load */
    [OPC_IALOAD]        = {"iaload", 0, -1, op_array_load},
    [OPC_LALOAD]        = {"laload", 0, 0, op_array_load},
    [OPC_FALOAD]        = {"faload", 0, -1, op_array_load},
    [OPC_DALOAD]        = {"daload", 0, 0, op_array_load},
    [OPC_AALOAD]        = {"aaload", 0, -1, op_array_load},
    [OPC_BALOAD]        = {"baload", 0, -1, op_array_load},
    [OPC_CALOAD]        = {"caload", 0, -1, op_array_load},
    [OPC_SALOAD]        = {"saload", 0, -1, op_array_load},
    
    /* Store instructions */
    [OPC_ISTORE]        = {"istore", 1, -1, op_store},
    [OPC_LSTORE]        = {"lstore", 1, -2, op_store},
    [OPC_FSTORE]        = {"fstore", 1, -1, op_store},
    [OPC_DSTORE]        = {"dstore", 1, -2, op_store},
    [OPC_ASTORE]        = {"astore", 1, -1, op_store},
    [OPC_ISTORE_0]      = {"istore_0", 0, -1, op_store_0},
    [OPC_ISTORE_1]      = {"istore_1", 0, -1, op_store_1},
    [OPC_ISTORE_2]      = {"istore_2", 0, -1, op_store_2},
    [OPC_ISTORE_3]      = {"istore_3", 0, -1, op_store_3},
    [OPC_LSTORE_0]      = {"lstore_0", 0, -2, op_lstore_0},
    [OPC_LSTORE_1]      = {"lstore_1", 0, -2, op_lstore_1},
    [OPC_LSTORE_2]      = {"lstore_2", 0, -2, op_lstore_2},
    [OPC_LSTORE_3]      = {"lstore_3", 0, -2, op_lstore_3},
    [OPC_FSTORE_0]      = {"fstore_0", 0, -1, op_store_0},
    [OPC_FSTORE_1]      = {"fstore_1", 0, -1, op_store_1},
    [OPC_FSTORE_2]      = {"fstore_2", 0, -1, op_store_2},
    [OPC_FSTORE_3]      = {"fstore_3", 0, -1, op_store_3},
    [OPC_DSTORE_0]      = {"dstore_0", 0, -2, op_dstore_0},
    [OPC_DSTORE_1]      = {"dstore_1", 0, -2, op_dstore_1},
    [OPC_DSTORE_2]      = {"dstore_2", 0, -2, op_dstore_2},
    [OPC_DSTORE_3]      = {"dstore_3", 0, -2, op_dstore_3},
    [OPC_ASTORE_0]      = {"astore_0", 0, -1, op_store_0},
    [OPC_ASTORE_1]      = {"astore_1", 0, -1, op_store_1},
    [OPC_ASTORE_2]      = {"astore_2", 0, -1, op_store_2},
    [OPC_ASTORE_3]      = {"astore_3", 0, -1, op_store_3},
    
    /* Array store */
    [OPC_IASTORE]       = {"iastore", 0, -3, op_array_store},
    [OPC_LASTORE]       = {"lastore", 0, -4, op_array_store},
    [OPC_FASTORE]       = {"fastore", 0, -3, op_array_store},
    [OPC_DASTORE]       = {"dastore", 0, -4, op_array_store},
    [OPC_AASTORE]       = {"aastore", 0, -3, op_array_store},
    [OPC_BASTORE]       = {"bastore", 0, -3, op_array_store},
    [OPC_CASTORE]       = {"castore", 0, -3, op_array_store},
    [OPC_SASTORE]       = {"sastore", 0, -3, op_array_store},
    
    /* Stack operations */
    [OPC_POP]           = {"pop", 0, -1, op_pop},
    [OPC_POP2]          = {"pop2", 0, -2, op_pop2},
    [OPC_DUP]           = {"dup", 0, 1, op_dup},
    [OPC_DUP_X1]        = {"dup_x1", 0, 1, op_dup_x1},
    [OPC_DUP_X2]        = {"dup_x2", 0, 1, op_dup_x2},
    [OPC_DUP2]          = {"dup2", 0, 2, op_dup2},
    [OPC_DUP2_X1]       = {"dup2_x1", 0, 2, op_dup2_x1},
    [OPC_DUP2_X2]       = {"dup2_x2", 0, 2, op_dup2_x2},
    [OPC_SWAP]          = {"swap", 0, 0, op_swap},
    
    /* Arithmetic */
    [OPC_IADD]          = {"iadd", 0, -1, op_add},
    [OPC_LADD]          = {"ladd", 0, -2, op_add},
    [OPC_FADD]          = {"fadd", 0, -1, op_add},
    [OPC_DADD]          = {"dadd", 0, -2, op_add},
    [OPC_ISUB]          = {"isub", 0, -1, op_sub},
    [OPC_LSUB]          = {"lsub", 0, -2, op_sub},
    [OPC_FSUB]          = {"fsub", 0, -1, op_sub},
    [OPC_DSUB]          = {"dsub", 0, -2, op_sub},
    [OPC_IMUL]          = {"imul", 0, -1, op_mul},
    [OPC_LMUL]          = {"lmul", 0, -2, op_mul},
    [OPC_FMUL]          = {"fmul", 0, -1, op_mul},
    [OPC_DMUL]          = {"dmul", 0, -2, op_mul},
    [OPC_IDIV]          = {"idiv", 0, -1, op_div},
    [OPC_LDIV]          = {"ldiv", 0, -2, op_div},
    [OPC_FDIV]          = {"fdiv", 0, -1, op_div},
    [OPC_DDIV]          = {"ddiv", 0, -2, op_div},
    [OPC_IREM]          = {"irem", 0, -1, op_rem},
    [OPC_LREM]          = {"lrem", 0, -2, op_rem},
    [OPC_FREM]          = {"frem", 0, -1, op_rem},
    [OPC_DREM]          = {"drem", 0, -2, op_rem},
    [OPC_INEG]          = {"ineg", 0, 0, op_neg},
    [OPC_LNEG]          = {"lneg", 0, 0, op_neg},
    [OPC_FNEG]          = {"fneg", 0, 0, op_neg},
    [OPC_DNEG]          = {"dneg", 0, 0, op_neg},
    
    /* Bit operations */
    [OPC_ISHL]          = {"ishl", 0, -1, op_shl},
    [OPC_LSHL]          = {"lshl", 0, -1, op_shl},
    [OPC_ISHR]          = {"ishr", 0, -1, op_shr},
    [OPC_LSHR]          = {"lshr", 0, -1, op_shr},
    [OPC_IUSHR]         = {"iushr", 0, -1, op_ushr},
    [OPC_LUSHR]         = {"lushr", 0, -1, op_ushr},
    [OPC_IAND]          = {"iand", 0, -1, op_and},
    [OPC_LAND]          = {"land", 0, -2, op_and},
    [OPC_IOR]           = {"ior", 0, -1, op_or},
    [OPC_LOR]           = {"lor", 0, -2, op_or},
    [OPC_IXOR]          = {"ixor", 0, -1, op_xor},
    [OPC_LXOR]          = {"lxor", 0, -2, op_xor},
    [OPC_IINC]          = {"iinc", 2, 0, op_iinc},
    
    /* Conversions */
    [OPC_I2L]           = {"i2l", 0, 1, op_convert},
    [OPC_I2F]           = {"i2f", 0, 0, op_convert},
    [OPC_I2D]           = {"i2d", 0, 1, op_convert},
    [OPC_L2I]           = {"l2i", 0, -1, op_convert},
    [OPC_L2F]           = {"l2f", 0, -1, op_convert},
    [OPC_L2D]           = {"l2d", 0, 0, op_convert},
    [OPC_F2I]           = {"f2i", 0, 0, op_convert},
    [OPC_F2L]           = {"f2l", 0, 1, op_convert},
    [OPC_F2D]           = {"f2d", 0, 1, op_convert},
    [OPC_D2I]           = {"d2i", 0, -1, op_convert},
    [OPC_D2L]           = {"d2l", 0, 0, op_convert},
    [OPC_D2F]           = {"d2f", 0, -1, op_convert},
    [OPC_I2B]           = {"i2b", 0, 0, op_convert},
    [OPC_I2C]           = {"i2c", 0, 0, op_convert},
    [OPC_I2S]           = {"i2s", 0, 0, op_convert},
    
    /* Comparisons */
    [OPC_LCMP]          = {"lcmp", 0, -3, op_lcmp},
    [OPC_FCMPL]         = {"fcmpl", 0, -1, op_fcmpl},
    [OPC_FCMPG]         = {"fcmpg", 0, -1, op_fcmpg},
    [OPC_DCMPL]         = {"dcmpl", 0, -3, op_dcmpl},
    [OPC_DCMPG]         = {"dcmpg", 0, -3, op_dcmpg},
    
    /* Branches */
    [OPC_IFEQ]          = {"ifeq", 2, -1, op_if},
    [OPC_IFNE]          = {"ifne", 2, -1, op_if},
    [OPC_IFLT]          = {"iflt", 2, -1, op_if},
    [OPC_IFGE]          = {"ifge", 2, -1, op_if},
    [OPC_IFGT]          = {"ifgt", 2, -1, op_if},
    [OPC_IFLE]          = {"ifle", 2, -1, op_if},
    [OPC_IF_ICMPEQ]     = {"if_icmpeq", 2, -2, op_if_icmp},
    [OPC_IF_ICMPNE]     = {"if_icmpne", 2, -2, op_if_icmp},
    [OPC_IF_ICMPLT]     = {"if_icmplt", 2, -2, op_if_icmp},
    [OPC_IF_ICMPGE]     = {"if_icmpge", 2, -2, op_if_icmp},
    [OPC_IF_ICMPGT]     = {"if_icmpgt", 2, -2, op_if_icmp},
    [OPC_IF_ICMPLE]     = {"if_icmple", 2, -2, op_if_icmp},
    [OPC_IF_ACMPEQ]     = {"if_acmpeq", 2, -2, op_if_acmp},
    [OPC_IF_ACMPNE]     = {"if_acmpne", 2, -2, op_if_acmp},
    [OPC_GOTO]          = {"goto", 2, 0, op_goto},
    [OPC_JSR]           = {"jsr", 2, 1, op_jsr},
    [OPC_RET]           = {"ret", 1, 0, op_ret},
    [OPC_TABLESWITCH]   = {"tableswitch", 0, -1, op_tableswitch},
    [OPC_LOOKUPSWITCH]  = {"lookupswitch", 0, -1, op_lookupswitch},
    
    /* Returns */
    [OPC_IRETURN]       = {"ireturn", 0, -1, op_ireturn},
    [OPC_LRETURN]       = {"lreturn", 0, -2, op_lreturn},
    [OPC_FRETURN]       = {"freturn", 0, -1, op_freturn},
    [OPC_DRETURN]       = {"dreturn", 0, -2, op_dreturn},
    [OPC_ARETURN]       = {"areturn", 0, -1, op_areturn},
    [OPC_RETURN]        = {"return", 0, 0, op_return},
    
    /* Field access */
    [OPC_GETSTATIC]     = {"getstatic", 2, 1, op_getstatic},
    [OPC_PUTSTATIC]     = {"putstatic", 2, -1, op_putstatic},
    [OPC_GETFIELD]      = {"getfield", 2, 0, op_getfield},
    [OPC_PUTFIELD]      = {"putfield", 2, -2, op_putfield},
    
    /* Method invocation */
    [OPC_INVOKEVIRTUAL]   = {"invokevirtual", 2, 0, op_invokevirtual},
    [OPC_INVOKESPECIAL]   = {"invokespecial", 2, 0, op_invokespecial},
    [OPC_INVOKESTATIC]    = {"invokestatic", 2, 0, op_invokestatic},
    [OPC_INVOKEINTERFACE] = {"invokeinterface", 4, 0, op_invokeinterface},
    
    /* Object creation */
    [OPC_NEW]             = {"new", 2, 1, op_new},
    [OPC_NEWARRAY]        = {"newarray", 1, 0, op_newarray},
    [OPC_ANEWARRAY]       = {"anewarray", 2, 0, op_anewarray},
    [OPC_ARRAYLENGTH]     = {"arraylength", 0, 1, op_arraylength},
    [OPC_ATHROW]          = {"athrow", 0, 0, op_athrow},
    [OPC_CHECKCAST]       = {"checkcast", 2, 0, op_checkcast},
    [OPC_INSTANCEOF]      = {"instanceof", 2, 0, op_instanceof},
    [OPC_MONITORENTER]    = {"monitorenter", 0, -1, op_monitorenter},
    [OPC_MONITOREXIT]     = {"monitorexit", 0, -1, op_monitorexit},
    
    /* Extended */
    [OPC_WIDE]            = {"wide", 0, 0, op_wide},
    [OPC_MULTIANEWARRAY]  = {"multianewarray", 3, 1, op_multianewarray},
    [OPC_IFNULL]          = {"ifnull", 2, -1, op_ifnull},
    [OPC_IFNONNULL]       = {"ifnonnull", 2, -1, op_ifnonnull},
    [OPC_GOTO_W]          = {"goto_w", 4, 0, op_goto_w},
    [OPC_JSR_W]           = {"jsr_w", 4, 1, op_jsr_w},
};

/* Initialize opcodes */
void opcodes_init(void) {
    /* Opcode table is statically initialized */
}

/* Macro helpers */
#define FETCH_U1(frame) ((frame)->code[(frame)->pc++])
#define FETCH_U2(frame) (frame->pc += 2, jvm_read_u16(frame->code + frame->pc - 2))
#define FETCH_S1(frame) ((int8_t)FETCH_U1(frame))
#define FETCH_S2(frame) ((int16_t)FETCH_U2(frame))

/* Stack operations with bounds checking */
#define PUSH(frame, val) do { \
    if ((frame)->stack_top >= (int)(frame)->max_stack - 1) { \
        fprintf(stderr, "[EXEC] Stack overflow in %s: top=%d, max=%d\n", \
                (frame)->method->name, (frame)->stack_top, (frame)->max_stack); \
        return -1; \
    } \
    (frame)->stack[++(frame)->stack_top] = (val); \
} while(0)

/* Safe pop that returns error on underflow */
static inline JavaValue safe_pop(JavaFrame* frame) {
    if (frame->stack_top < 0) {
        fprintf(stderr, "[EXEC] Stack underflow in %s\n", frame->method->name);
        JavaValue v = { .i = 0 };
        return v;
    }
    return frame->stack[frame->stack_top--];
}

#define POP(frame) safe_pop(frame)
#define PEEK(frame) ((frame)->stack[(frame)->stack_top])

/* Safe local variable access with bounds checking */
static inline JavaValue* safe_local_ptr(JavaFrame* frame, uint16_t idx) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return NULL;
    }
    return &frame->locals[idx];
}

/* For simple cases where we want to return error on out-of-bounds */
static inline int load_local(JavaFrame* frame, uint16_t idx, JavaValue* result) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return -1;
    }
    *result = frame->locals[idx];
    return 0;
}

static inline int store_local(JavaFrame* frame, uint16_t idx, JavaValue value) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return -1;
    }
    frame->locals[idx] = value;
    return 0;
}

/* Macros for backward compatibility with bounds checking */
#define LOCAL(frame, idx) (*safe_local_ptr(frame, idx))

/* Basic opcodes */
int op_nop(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    return 0;
}

int op_aconst_null(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = { .ref = NULL };
    PUSH(frame, v);
    return 0;
}

int op_iconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint value = opcode - OPC_ICONST_0;  /* -1 to 5 */
    JavaValue v = { .i = value };
    PUSH(frame, v);
    return 0;
}

int op_lconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jlong value = opcode - OPC_LCONST_0;  /* 0 or 1 */
    JavaValue v = { .j = value };
    PUSH(frame, v);
    return 0;
}

int op_fconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jfloat value = (jfloat)(opcode - OPC_FCONST_0);  /* 0.0, 1.0, or 2.0 */
    JavaValue v = { .f = value };
    PUSH(frame, v);
    return 0;
}

int op_dconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jdouble value = (jdouble)(opcode - OPC_DCONST_0);  /* 0.0 or 1.0 */
    JavaValue v = { .d = value };
    PUSH(frame, v);
    return 0;
}

int op_bipush(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int8_t value = FETCH_S1(frame);
    JavaValue v = { .i = (jint)value };
    PUSH(frame, v);
    return 0;
}

int op_sipush(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t value = FETCH_S2(frame);
    JavaValue v = { .i = (jint)value };
    PUSH(frame, v);
    return 0;
}

int op_ldc(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaClass* clazz = frame->clazz;
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Integer:
            v.i = entry->info.integer.value;
            break;
        case CONSTANT_Float:
            v.f = entry->info.float_val.value;
            break;
        case CONSTANT_String: {
            const char* str = classfile_get_utf8(clazz, entry->info.string_info.string_index);
            v.ref = jvm_new_string(jvm, str);
            break;
        }
        case CONSTANT_Class: {
            const char* name = classfile_get_utf8(clazz, entry->info.class_info.name_index);
            v.ref = jvm_load_class(jvm, name);
            break;
        }
        default:
            return -1;
    }
    
    PUSH(frame, v);
    return 0;
}

int op_ldc_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaClass* clazz = frame->clazz;
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Integer:
            v.i = entry->info.integer.value;
            break;
        case CONSTANT_Float:
            v.f = entry->info.float_val.value;
            break;
        case CONSTANT_String: {
            const char* str = classfile_get_utf8(clazz, entry->info.string_info.string_index);
            v.ref = jvm_new_string(jvm, str);
            break;
        }
        default:
            return -1;
    }
    
    PUSH(frame, v);
    return 0;
}

int op_ldc2_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaClass* clazz = frame->clazz;
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Long:
            v.j = entry->info.long_val.value;
            break;
        case CONSTANT_Double:
            v.d = entry->info.double_val.value;
            break;
        default:
            return -1;
    }
    
    /* Long/double occupy 2 stack slots */
    PUSH(frame, v);
    /* Push a second slot (the value is already in v.j/v.d, this is just for stack accounting) */
    PUSH(frame, v);
    return 0;
}

/* Load opcodes */
int op_iload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        return -1;
    }
    PUSH(frame, v);
    return 0;
}

int op_lload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v1, v2;
    if (load_local(frame, index, &v1) != 0) return -1;
    if (load_local(frame, index + 1, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_fload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_dload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v1, v2;
    if (load_local(frame, index, &v1) != 0) return -1;
    if (load_local(frame, index + 1, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_aload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        return -1;
    }
    PUSH(frame, v);
    return 0;
}

int op_load_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 0, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 1, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 2, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 3, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

/* Long/Double load opcodes - these need 2 stack slots */
int op_lload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v0, v1;
    if (load_local(frame, 0, &v0) != 0) return -1;
    if (load_local(frame, 1, &v1) != 0) return -1;
    PUSH(frame, v0);
    PUSH(frame, v1);
    return 0;
}

int op_lload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (load_local(frame, 1, &v1) != 0) return -1;
    if (load_local(frame, 2, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_lload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v3;
    if (load_local(frame, 2, &v2) != 0) return -1;
    if (load_local(frame, 3, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v3);
    return 0;
}

int op_lload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v4;
    if (load_local(frame, 3, &v3) != 0) return -1;
    if (load_local(frame, 4, &v4) != 0) return -1;
    PUSH(frame, v3);
    PUSH(frame, v4);
    return 0;
}

/* dload_X same as lload_X */
int op_dload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v0, v1;
    if (load_local(frame, 0, &v0) != 0) return -1;
    if (load_local(frame, 1, &v1) != 0) return -1;
    PUSH(frame, v0);
    PUSH(frame, v1);
    return 0;
}

int op_dload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (load_local(frame, 1, &v1) != 0) return -1;
    if (load_local(frame, 2, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_dload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v3;
    if (load_local(frame, 2, &v2) != 0) return -1;
    if (load_local(frame, 3, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v3);
    return 0;
}

int op_dload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v4;
    if (load_local(frame, 3, &v3) != 0) return -1;
    if (load_local(frame, 4, &v4) != 0) return -1;
    PUSH(frame, v3);
    PUSH(frame, v4);
    return 0;
}

/* Array load */
int op_array_load(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm;
    jint index = POP(frame).i;
    JavaArray* array = (JavaArray*)POP(frame).ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (index < 0 || index >= array->length) {
        native_throw_aioobe(jvm, thread, index);
        return -1;
    }
    
    JavaValue v = array_get(array, index);
    PUSH(frame, v);
    return 0;
}

/* Store opcodes */
int op_store(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v = POP(frame);
    if (store_local(frame, index, v) != 0) {
        fprintf(stderr, "[EXEC] op_store: failed to store at index %d (max_locals=%d)\n", 
                index, frame->max_locals);
        return -1;
    }
    return 0;
}

int op_store_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 0, v) != 0) return -1;
    return 0;
}

int op_store_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 1, v) != 0) return -1;
    return 0;
}

int op_store_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 2, v) != 0) return -1;
    return 0;
}

int op_store_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = POP(frame);
    if (store_local(frame, 3, v) != 0) return -1;
    return 0;
}

/* Long/Double store opcodes - these need 2 stack slots */
int op_lstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);  /* Pop high word first */
    JavaValue v0 = POP(frame);  /* Pop low word second */
    if (store_local(frame, 1, v1) != 0) return -1;
    if (store_local(frame, 0, v0) != 0) return -1;
    return 0;
}

int op_lstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    if (store_local(frame, 2, v2) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    return 0;
}

int op_lstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3 = POP(frame);
    JavaValue v2 = POP(frame);
    if (store_local(frame, 3, v3) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    return 0;
}

int op_lstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v4 = POP(frame);
    JavaValue v3 = POP(frame);
    if (store_local(frame, 4, v4) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    return 0;
}

/* dstore_X same as lstore_X */
int op_dstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v0 = POP(frame);
    if (store_local(frame, 1, v1) != 0) return -1;
    if (store_local(frame, 0, v0) != 0) return -1;
    return 0;
}

int op_dstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    if (store_local(frame, 2, v2) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    return 0;
}

int op_dstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3 = POP(frame);
    JavaValue v2 = POP(frame);
    if (store_local(frame, 3, v3) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    return 0;
}

int op_dstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v4 = POP(frame);
    JavaValue v3 = POP(frame);
    if (store_local(frame, 4, v4) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    return 0;
}

/* Array store */
int op_array_store(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaValue value = POP(frame);
    jint index = POP(frame).i;
    JavaArray* array = (JavaArray*)POP(frame).ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (index < 0 || index >= array->length) {
        native_throw_aioobe(jvm, thread, index);
        return -1;
    }
    
    array_set(array, index, value);
    return 0;
}

/* Stack operations */
int op_pop(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    POP(frame);
    return 0;
}

int op_pop2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    POP(frame);
    POP(frame);
    return 0;
}

int op_dup(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = PEEK(frame);
    PUSH(frame, v);
    return 0;
}

int op_dup_x1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    PUSH(frame, v1);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup_x2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    JavaValue v3 = POP(frame);
    PUSH(frame, v1);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2_x1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    JavaValue v3 = POP(frame);
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2_x2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    JavaValue v3 = POP(frame);
    JavaValue v4 = POP(frame);
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v4);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_swap(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1 = POP(frame);
    JavaValue v2 = POP(frame);
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

/* Arithmetic operations */
int op_add(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IADD: result.i = v1.i + v2.i; break;
        case OPC_LADD: result.j = v1.j + v2.j; break;
        case OPC_FADD: result.f = v1.f + v2.f; break;
        case OPC_DADD: result.d = v1.d + v2.d; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_sub(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_ISUB: result.i = v1.i - v2.i; break;
        case OPC_LSUB: result.j = v1.j - v2.j; break;
        case OPC_FSUB: result.f = v1.f - v2.f; break;
        case OPC_DSUB: result.d = v1.d - v2.d; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_mul(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IMUL: result.i = v1.i * v2.i; break;
        case OPC_LMUL: result.j = v1.j * v2.j; break;
        case OPC_FMUL: result.f = v1.f * v2.f; break;
        case OPC_DMUL: result.d = v1.d * v2.d; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_div(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    /* TODO: Check for division by zero */
    switch (opcode) {
        case OPC_IDIV: result.i = v1.i / v2.i; break;
        case OPC_LDIV: result.j = v1.j / v2.j; break;
        case OPC_FDIV: result.f = v1.f / v2.f; break;
        case OPC_DDIV: result.d = v1.d / v2.d; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_rem(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IREM: result.i = v1.i % v2.i; break;
        case OPC_LREM: result.j = v1.j % v2.j; break;
        case OPC_FREM: result.f = fmodf(v1.f, v2.f); break;
        case OPC_DREM: result.d = fmod(v1.d, v2.d); break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_neg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_INEG: result.i = -v.i; break;
        case OPC_LNEG: result.j = -v.j; break;
        case OPC_FNEG: result.f = -v.f; break;
        case OPC_DNEG: result.d = -v.d; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_shl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint shift = POP(frame).i & 0x3F;
    JavaValue v = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_ISHL: result.i = v.i << shift; break;
        case OPC_LSHL: result.j = v.j << shift; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_shr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint shift = POP(frame).i & 0x3F;
    JavaValue v = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_ISHR: result.i = v.i >> shift; break;
        case OPC_LSHR: result.j = v.j >> shift; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_ushr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint shift = POP(frame).i & 0x3F;
    JavaValue v = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IUSHR: result.i = ((juint)v.i) >> shift; break;
        case OPC_LUSHR: result.j = ((julong)v.j) >> shift; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_and(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IAND: result.i = v1.i & v2.i; break;
        case OPC_LAND: result.j = v1.j & v2.j; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_or(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IOR: result.i = v1.i | v2.i; break;
        case OPC_LOR: result.j = v1.j | v2.j; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_xor(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2 = POP(frame);
    JavaValue v1 = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_IXOR: result.i = v1.i ^ v2.i; break;
        case OPC_LXOR: result.j = v1.j ^ v2.j; break;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_iinc(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    int8_t constant = FETCH_S1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        fprintf(stderr, "[EXEC] iinc: failed to load from index %d\n", index);
        return -1;
    }
    v.i += constant;
    if (store_local(frame, index, v) != 0) {
        fprintf(stderr, "[EXEC] iinc: failed to store to index %d\n", index);
        return -1;
    }
    return 0;
}

/* Conversion operations */
int op_convert(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v = POP(frame);
    JavaValue result;
    
    switch (opcode) {
        case OPC_I2L: result.j = (jlong)v.i; break;
        case OPC_I2F: result.f = (jfloat)v.i; break;
        case OPC_I2D: result.d = (jdouble)v.i; break;
        case OPC_L2I: result.i = (jint)v.j; break;
        case OPC_L2F: result.f = (jfloat)v.j; break;
        case OPC_L2D: result.d = (jdouble)v.j; break;
        case OPC_F2I: result.i = (jint)v.f; break;
        case OPC_F2L: result.j = (jlong)v.f; break;
        case OPC_F2D: result.d = (jdouble)v.f; break;
        case OPC_D2I: result.i = (jint)v.d; break;
        case OPC_D2L: result.j = (jlong)v.d; break;
        case OPC_D2F: result.f = (jfloat)v.d; break;
        case OPC_I2B: result.i = (jint)(int8_t)v.i; break;
        case OPC_I2C: result.i = (jint)(uint8_t)v.i; break;
        case OPC_I2S: result.i = (jint)(int16_t)v.i; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

/* Comparison operations */
int op_lcmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jlong v2 = POP(frame).j;
    jlong v1 = POP(frame).j;
    JavaValue result;
    result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_fcmpl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jfloat v2 = POP(frame).f;
    jfloat v1 = POP(frame).f;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = -1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_fcmpg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jfloat v2 = POP(frame).f;
    jfloat v1 = POP(frame).f;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = 1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_dcmpl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jdouble v2 = POP(frame).d;
    jdouble v1 = POP(frame).d;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = -1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_dcmpg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    jdouble v2 = POP(frame).d;
    jdouble v1 = POP(frame).d;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = 1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

/* Branch operations */
int op_if(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    int16_t offset = FETCH_S2(frame);
    JavaValue val = POP(frame);
    bool branch = false;
    
    /* For reference types, null is treated as 0, non-null as non-zero
       For int types, the value itself is used */
    jlong value;
    /* Check if this might be a reference - check if ref is non-null */
    if (val.ref != NULL) {
        /* This is a non-null reference */
        value = 1;  /* Non-zero for branching purposes */
    } else {
        /* Could be null reference or integer */
        value = val.i;
    }
    
    switch (opcode) {
        case OPC_IFEQ: branch = (value == 0); break;
        case OPC_IFNE: branch = (value != 0); break;
        case OPC_IFLT: branch = (value < 0); break;
        case OPC_IFGE: branch = (value >= 0); break;
        case OPC_IFGT: branch = (value > 0); break;
        case OPC_IFLE: branch = (value <= 0); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;  /* -3 for opcode + operand */
    }
    
    return 0;
}

int op_if_icmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    int16_t offset = FETCH_S2(frame);
    jint v2 = POP(frame).i;
    jint v1 = POP(frame).i;
    bool branch = false;
    
    switch (opcode) {
        case OPC_IF_ICMPEQ: branch = (v1 == v2); break;
        case OPC_IF_ICMPNE: branch = (v1 != v2); break;
        case OPC_IF_ICMPLT: branch = (v1 < v2); break;
        case OPC_IF_ICMPGE: branch = (v1 >= v2); break;
        case OPC_IF_ICMPGT: branch = (v1 > v2); break;
        case OPC_IF_ICMPLE: branch = (v1 <= v2); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_if_acmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    int16_t offset = FETCH_S2(frame);
    void* v2 = POP(frame).ref;
    void* v1 = POP(frame).ref;
    bool branch = false;
    
    switch (opcode) {
        case OPC_IF_ACMPEQ: branch = (v1 == v2); break;
        case OPC_IF_ACMPNE: branch = (v1 != v2); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_goto(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    frame->pc += offset - 3;
    return 0;
}

int op_jsr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue ret_addr = { .i = frame->pc };
    PUSH(frame, ret_addr);
    frame->pc += offset - 3;
    return 0;
}

int op_ret(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    frame->pc = LOCAL(frame, index).i;
    return 0;
}

int op_tableswitch(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* Save the start of tableswitch instruction (opcode is at pc-1) */
    /* Offsets in tableswitch are relative to the opcode's address */
    uint32_t start_pc = frame->pc - 1;
    
    /* Align to 4-byte boundary */
    while (frame->pc % 4 != 0) frame->pc++;
    
    int32_t default_offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    int32_t low = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    int32_t high = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    
    jint index = POP(frame).i;
    int32_t offset;
    
    if (index < low || index > high) {
        offset = default_offset;
    } else {
        offset = (int32_t)jvm_read_u32(frame->code + frame->pc + (index - low) * 4);
    }
    
    /* Jump to target - offset is relative to start of tableswitch instruction */
    frame->pc = start_pc + offset;
    
    return 0;
}

int op_lookupswitch(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    
    /* Save the start of lookupswitch instruction (opcode is at pc-1) */
    /* Offsets in lookupswitch are relative to the opcode's address */
    uint32_t start_pc = frame->pc - 1;
    
    /* Align to 4-byte boundary */
    while (frame->pc % 4 != 0) frame->pc++;
    
    int32_t default_offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    int32_t npairs = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4;
    
    jint key = POP(frame).i;
    int32_t offset = default_offset;
    
    for (int32_t i = 0; i < npairs; i++) {
        int32_t match = (int32_t)jvm_read_u32(frame->code + frame->pc);
        frame->pc += 4;
        int32_t jump = (int32_t)jvm_read_u32(frame->code + frame->pc);
        frame->pc += 4;
        
        if (match == key) {
            offset = jump;
            break;
        }
    }
    
    /* Jump to target - offset is relative to start of lookupswitch instruction */
    frame->pc = start_pc + offset;
    return 0;
}

/* Return operations */
int op_return(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    return 1;  /* Signal return */
}

int op_ireturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue result = POP(frame);
    frame->prev->stack_top++;
    frame->prev->stack[frame->prev->stack_top] = result;
    return 1;
}

int op_lreturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    return op_ireturn(jvm, thread, frame);
}

int op_freturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    return op_ireturn(jvm, thread, frame);
}

int op_dreturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    return op_ireturn(jvm, thread, frame);
}

int op_areturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    return op_ireturn(jvm, thread, frame);
}

/* Field access - simplified stubs */
int op_getstatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    
    /* Get field reference from constant pool */
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    fprintf(stderr, "[EXEC] getstatic: %s.%s (%s)\n", 
            class_name ? class_name : "?", 
            field_name ? field_name : "?",
            descriptor ? descriptor : "?");
    fflush(stderr);
    
    /* Load the class */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    if (!target_class) {
        fprintf(stderr, "[EXEC] getstatic: class %s not found\n", class_name);
        JavaValue v = { .i = 0 };
        PUSH(frame, v);
        return 0;
    }
    
    /* Initialize the class if needed */
    if (!target_class->initialized) {
        target_class->initialized = true;
        /* Run <clinit> if exists */
        JavaMethod* clinit = jvm_resolve_method(jvm, target_class, "<clinit>", "()V");
        if (clinit) {
            JavaValue result;
            execute_method(jvm, thread, clinit, NULL, &result);
        }
    }
    
    /* Find static field in class */
    JavaValue v = { .i = 0 };
    
    if (target_class->static_fields) {
        for (int i = 0; i < target_class->static_fields_count; i++) {
            if (target_class->static_fields[i].name &&
                strcmp(target_class->static_fields[i].name, field_name) == 0) {
                v = target_class->static_fields[i].value;
                fprintf(stderr, "[EXEC] getstatic: found %s.%s = %p\n", 
                        class_name, field_name, (void*)v.ref);
                break;
            }
        }
    }
    
    PUSH(frame, v);
    return 0;
}

int op_putstatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    
    /* Get field reference from constant pool */
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    JavaValue v = POP(frame);
    
    fprintf(stderr, "[EXEC] putstatic: %s.%s = %p\n", 
            class_name ? class_name : "?", 
            field_name ? field_name : "?",
            (void*)v.ref);
    fflush(stderr);
    
    /* Load the class */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    if (!target_class) {
        fprintf(stderr, "[EXEC] putstatic: class %s not found\n", class_name);
        return 0;
    }
    
    /* Initialize static fields storage if needed */
    if (!target_class->static_fields) {
        /* Count static fields from class file or allocate default */
        target_class->static_fields_count = 16;  /* Default capacity */
        target_class->static_fields = (JavaStaticField*)calloc(16, sizeof(JavaStaticField));
    }
    
    /* Find or create static field slot */
    int slot = -1;
    for (int i = 0; i < target_class->static_fields_count; i++) {
        if (target_class->static_fields[i].name == NULL) {
            /* Empty slot - claim it */
            slot = i;
            target_class->static_fields[i].name = (char*)strdup(field_name);
            break;
        } else if (strcmp(target_class->static_fields[i].name, field_name) == 0) {
            slot = i;
            break;
        }
    }
    
    if (slot == -1) {
        /* No empty slot - expand */
        int new_count = target_class->static_fields_count + 16;
        JavaStaticField* new_fields = (JavaStaticField*)realloc(
            target_class->static_fields, new_count * sizeof(JavaStaticField));
        if (new_fields) {
            target_class->static_fields = new_fields;
            memset(&new_fields[target_class->static_fields_count], 0, 
                   16 * sizeof(JavaStaticField));
            slot = target_class->static_fields_count;
            target_class->static_fields[slot].name = (char*)strdup(field_name);
            target_class->static_fields_count = new_count;
        }
    }
    
    if (slot >= 0) {
        target_class->static_fields[slot].value = v;
    }
    
    return 0;
}

int op_getfield(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    /* Get field reference from constant pool */
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    /* Pop object reference */
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    /* === НАЧАЛО ЗАЩИТНЫХ ПРОВЕРОК === */
    
    /* Проверка 1: Объект не должен быть NULL */
    if (!obj) {
        fprintf(stderr, "[EXEC] getfield: NULL object for field %s.%s\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    /* Проверка 2: Указатель на класс не должен быть NULL */
    if (obj->header.clazz == NULL) {
        fprintf(stderr, "[EXEC] getfield: FATAL: Object %p has NULL class pointer! "
                "Field: %s.%s\n", 
                (void*)obj, 
                class_name ? class_name : "?", 
                field_name ? field_name : "?");
        fflush(stderr);
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Object has no class (getfield)");
        return -1;
    }
    
    /* Проверка 3: Указатель на класс должен быть в разумном диапазоне */
    if ((uintptr_t)obj->header.clazz < 0x10000) {
        fprintf(stderr, "[EXEC] getfield: FATAL: Object %p has suspiciously small "
                "class pointer %p! Field: %s.%s\n", 
                (void*)obj, (void*)obj->header.clazz,
                class_name ? class_name : "?", 
                field_name ? field_name : "?");
        fflush(stderr);
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Object has invalid class pointer (getfield)");
        return -1;
    }
    
    /* === КОНЕЦ ЗАЩИТНЫХ ПРОВЕРОК === */
    
    /* Find field in object's class - match both name AND descriptor */
    JavaClass* obj_class = obj->header.clazz;
    int field_index = -1;
    
    if (obj_class && obj_class->fields) {
        for (int i = 0; i < obj_class->fields_count; i++) {
            if (obj_class->fields[i].name && 
                strcmp(obj_class->fields[i].name, field_name) == 0) {
                /* Also check descriptor if available */
                if (descriptor && obj_class->fields[i].descriptor) {
                    if (strcmp(obj_class->fields[i].descriptor, descriptor) == 0) {
                        field_index = i;
                        break;
                    }
                    /* If descriptors don't match, keep searching */
                } else {
                    /* No descriptor to match, use first match */
                    field_index = i;
                    break;
                }
            }
        }
    }
    
    JavaValue v = { .i = 0 };
    
    if (field_index >= 0) {
        /* Get field value from object's fields array */
        v = obj->fields[field_index];
        fprintf(stderr, "[EXEC] getfield: %s.%s = 0x%08X (obj=%p, field_idx=%d)\n", 
                class_name ? class_name : "?", field_name ? field_name : "?", 
                v.i, (void*)obj, field_index);
        fflush(stderr);
    } else {
        /* Field not found - return default value */
        fprintf(stderr, "[EXEC] getfield: field %s.%s not found, returning 0\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
        fflush(stderr);
    }
    
    PUSH(frame, v);
    return 0;
}

int op_putfield(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    /* Get field reference from constant pool */
    const char* class_name = NULL;
    const char* field_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Fieldref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &field_name, &descriptor);
        }
    }
    
    /* Pop value */
    JavaValue value = POP(frame);
    
    /* Pop object reference */
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    /* === НАЧАЛО ЗАЩИТНЫХ ПРОВЕРОК === */
    
    /* Проверка 1: Объект не должен быть NULL */
    if (!obj) {
        fprintf(stderr, "[EXEC] putfield: NULL object for field %s.%s\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    /* Проверка 2: Указатель на класс не должен быть NULL */
    if (obj->header.clazz == NULL) {
        fprintf(stderr, "[EXEC] putfield: FATAL: Object %p has NULL class pointer! "
                "Field: %s.%s\n", 
                (void*)obj, 
                class_name ? class_name : "?", 
                field_name ? field_name : "?");
        fflush(stderr);
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Object has no class (putfield)");
        return -1;
    }
    
    /* Проверка 3: Указатель на класс должен быть в разумном диапазоне */
    if ((uintptr_t)obj->header.clazz < 0x10000) {
        fprintf(stderr, "[EXEC] putfield: FATAL: Object %p has suspiciously small "
                "class pointer %p! Field: %s.%s\n", 
                (void*)obj, (void*)obj->header.clazz,
                class_name ? class_name : "?", 
                field_name ? field_name : "?");
        fflush(stderr);
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Object has invalid class pointer (putfield)");
        return -1;
    }
    
    /* === КОНЕЦ ЗАЩИТНЫХ ПРОВЕРОК === */
    
    /* Find field in object's class - match both name AND descriptor */
    JavaClass* obj_class = obj->header.clazz;
    int field_index = -1;
    
    if (obj_class && obj_class->fields) {
        for (int i = 0; i < obj_class->fields_count; i++) {
            if (obj_class->fields[i].name && 
                strcmp(obj_class->fields[i].name, field_name) == 0) {
                /* Also check descriptor if available */
                if (descriptor && obj_class->fields[i].descriptor) {
                    if (strcmp(obj_class->fields[i].descriptor, descriptor) == 0) {
                        field_index = i;
                        break;
                    }
                    /* If descriptors don't match, keep searching */
                } else {
                    /* No descriptor to match, use first match */
                    field_index = i;
                    break;
                }
            }
        }
    }
    
    if (field_index >= 0) {
        /* Set field value */
        obj->fields[field_index] = value;
        fprintf(stderr, "[EXEC] putfield: %s.%s = %p (obj=%p, field_idx=%d)\n", 
                class_name ? class_name : "?", field_name ? field_name : "?",
                (void*)value.ref, (void*)obj, field_index);
    } else {
        fprintf(stderr, "[EXEC] putfield: field %s.%s not found!\n", 
                class_name ? class_name : "?", field_name ? field_name : "?");
        fflush(stderr);
    }
    
    return 0;
}

/* Method invocation */
int op_invokevirtual(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    /* Get method reference */
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Methodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }
    
    /* Count arguments */
    int arg_count = 0;
    JavaValue* args = NULL;
    
    if (descriptor) {
        arg_count = count_args(descriptor);
        
        /* Allocate args array: this + arguments */
        args = (JavaValue*)malloc((arg_count + 1) * sizeof(JavaValue));
        if (!args) {
            return -1;
        }
        
        /* IMPORTANT: Pop arguments in REVERSE order first, then object ref */
        /* Stack: [..., objref, arg1, arg2, ...] */
        /* Need to pop: arg_n, arg_n-1, ..., arg1, then objref */
        
        /* Pop arguments first (top of stack = last arg) */
        for (int i = arg_count; i >= 1; i--) {
            args[i] = POP(frame);
        }
        
        /* Then pop object reference (this) */
        args[0] = POP(frame);
    }
    
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[EXEC] invokevirtual: %s.%s%s (obj=%p, args=%d)\n", 
            class_name ? class_name : "?", 
            method_name ? method_name : "?", 
            descriptor ? descriptor : "?",
            (void*)obj, arg_count);
    fflush(stderr);
    
    /* === НАЧАЛО ЗАЩИТНЫХ ПРОВЕРОК === */
    
    /* Проверка 1: Объект не должен быть NULL */
    if (!obj) {
        fprintf(stderr, "[EXEC] invokevirtual: NULL object reference!\n");
        fflush(stderr);
        free(args);
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    /* Проверка 2: Указатель на класс не должен быть NULL */
    if (obj->header.clazz == NULL) {
        fprintf(stderr, "[EXEC] invokevirtual: FATAL: Object %p has NULL class pointer! "
                "This indicates heap corruption or uninitialized object.\n", (void*)obj);
        fflush(stderr);
        free(args);
        /* Бросаем исключение, так как это серьезная проблема */
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Object has no class (invokevirtual)");
        return -1;
    }
    
    /* Проверка 3: Указатель на класс должен быть в разумном диапазоне (не слишком маленький) */
    if ((uintptr_t)obj->header.clazz < 0x10000) {
        fprintf(stderr, "[EXEC] invokevirtual: FATAL: Object %p has suspiciously small "
                "class pointer %p! This is likely garbage.\n", 
                (void*)obj, (void*)obj->header.clazz);
        fflush(stderr);
        free(args);
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Object has invalid class pointer (invokevirtual)");
        return -1;
    }
    
    /* Проверка 4: Имя класса не должно быть NULL */
    if (obj->header.clazz->class_name == NULL) {
        fprintf(stderr, "[EXEC] invokevirtual: FATAL: Class %p for object %p has NULL "
                "class_name. Class is corrupted.\n", 
                (void*)obj->header.clazz, (void*)obj);
        fflush(stderr);
        free(args);
        jvm_throw_by_name(jvm, "java/lang/InternalError", 
                          "Class is corrupted (invokevirtual)");
        return -1;
    }
    
    /* === КОНЕЦ ЗАЩИТНЫХ ПРОВЕРОК === */
    
    /* Validate object has a proper class pointer */
    JavaClass* target_class = obj->header.clazz;
    if (!target_class) {
        fprintf(stderr, "[EXEC] invokevirtual: Object has NULL class pointer (invalid object reference)!\n");
        fprintf(stderr, "[EXEC] invokevirtual: obj=%p, this might be caused by reading garbage from local variables\n", (void*)obj);
        fflush(stderr);
        free(args);
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    /* Basic sanity check - class should have a valid class_name pointer */
    if (!target_class->class_name) {
        fprintf(stderr, "[EXEC] invokevirtual: Class has NULL class_name (invalid class pointer)!\n");
        fprintf(stderr, "[EXEC] invokevirtual: target_class=%p, this indicates memory corruption\n", (void*)target_class);
        fflush(stderr);
        free(args);
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    fprintf(stderr, "[EXEC] invokevirtual: target_class=%s (is_stub=%d)\n",
            target_class->class_name,
            target_class->is_stub);
    fflush(stderr);
    
    JavaMethod* method = jvm_resolve_method(jvm, target_class, method_name, descriptor);
    fprintf(stderr, "[EXEC] invokevirtual: method=%p\n", (void*)method);
    fflush(stderr);
    
    if (!method) {
        /* Try to find native method in class hierarchy */
        NativeMethod native = NULL;
        JavaClass* search_class = target_class;
        
        fprintf(stderr, "[EXEC] invokevirtual: searching for native %s%s in class hierarchy:\n", 
                method_name, descriptor);
        while (search_class && !native) {
            fprintf(stderr, "[EXEC]   checking class: %s\n", search_class->class_name);
            native = native_find(jvm, search_class->class_name, method_name, descriptor);
            if (!native) {
                search_class = search_class->super_class;
            }
        }
        
        if (native) {
            fprintf(stderr, "[EXEC] invokevirtual: calling native %s.%s%s\n", 
                    search_class->class_name, method_name, descriptor);
            fflush(stderr);
            JavaValue result = native(jvm, thread, args, arg_count + 1);
            free(args);
            
            /* Push result if not void */
            if (descriptor && strlen(descriptor) > 0) {
                const char* ret = strchr(descriptor, ')');
                if (ret && ret[1] != 'V') {
                    PUSH(frame, result);
                }
            }
            return 0;
        }
        
        /* Method not found - for stub classes, provide default return value */
        fprintf(stderr, "[EXEC] invokevirtual: method %s.%s%s not found (stub class?), using default\n", 
                target_class->class_name, method_name, descriptor);
        fflush(stderr);
        free(args);
        
        /* Push default return value based on return type */
        if (descriptor && strlen(descriptor) > 0) {
            const char* ret = strchr(descriptor, ')');
            if (ret && ret[1] != 'V') {
                JavaValue default_val = { .raw = 0 };
                /* Return appropriate default based on type */
                switch (ret[1]) {
                    case 'I': case 'S': case 'Z': case 'B': case 'C':
                        default_val.i = 0;
                        break;
                    case 'J':
                        default_val.j = 0;
                        break;
                    case 'F':
                        default_val.f = 0.0f;
                        break;
                    case 'D':
                        default_val.d = 0.0;
                        break;
                    case 'L': case '[':
                        default_val.ref = NULL;
                        break;
                }
                PUSH(frame, default_val);
            }
        }
        return 0;  /* Return success to continue execution */
    }
    
    /* Execute method */
    JavaValue result;
    int ret = execute_method(jvm, thread, method, args, &result);
    
    if (ret == 0 && descriptor) {
        /* Push return value if not void */
        const char* ret_type = strchr(descriptor, ')');
        if (ret_type && ret_type[1] != 'V') {
            PUSH(frame, result);
        }
    }
    
    free(args);
    return ret;
}

int op_invokespecial(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    
    /* Get method reference */
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Methodref || entry->tag == CONSTANT_InterfaceMethodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }
    
    /* Count arguments and pop them from stack */
    int arg_count = 0;
    JavaValue* args = NULL;
    
    if (descriptor) {
        /* Count actual Java arguments (not stack slots) */
        const char* p = descriptor;
        if (*p == '(') p++;
        int java_args = 0;
        while (*p && *p != ')') {
            switch (*p) {
                case 'J': case 'D':
                    java_args++;  /* Long/double - 1 argument, 2 slots */
                    p++;
                    break;
                case 'B': case 'C': case 'F': case 'I': case 'S': case 'Z':
                    java_args++;
                    p++;
                    break;
                case 'L':
                    java_args++;
                    while (*p && *p != ';') p++;
                    if (*p == ';') p++;
                    break;
                case '[':
                    java_args++;
                    while (*p == '[') p++;
                    if (*p == 'L') while (*p && *p != ';') p++;
                    if (*p) p++;
                    break;
                default:
                    p++;
                    break;
            }
        }
        
        /* Get stack slots needed (including 2 slots for long/double) */
        int stack_slots = count_args(descriptor);
        
        /* Allocate args array: this + java_args */
        args = (JavaValue*)malloc((java_args + 1) * sizeof(JavaValue));
        if (!args) return -1;
        
        /* Pop arguments from stack, handling long/double correctly */
        /* We need to map stack slots to Java arguments */
        p = descriptor;
        if (*p == '(') p++;
        
        int arg_idx = java_args;
        
        /* First, collect all stack values into a temporary buffer */
        JavaValue* stack_vals = (JavaValue*)malloc((stack_slots + 1) * sizeof(JavaValue));
        if (!stack_vals) { free(args); return -1; }
        
        for (int i = stack_slots - 1; i >= 0; i--) {
            stack_vals[i] = POP(frame);
        }
        
        /* Pop object reference (this) */
        if (frame->stack_top < 0) {
            fprintf(stderr, "[EXEC] Stack underflow: no this reference\n");
            free(stack_vals);
            free(args);
            return -1;
        }
        args[0] = POP(frame);
        
        /* Now map stack values to args, combining long/double */
        int sv = 0;
        arg_idx = 1;
        p = descriptor;
        if (*p == '(') p++;
        
        while (*p && *p != ')') {
            if (*p == 'J' || *p == 'D') {
                /* Long or double - combine two slots */
                args[arg_idx].j = stack_vals[sv].j;  /* Already properly stored */
                sv += 2;
                arg_idx++;
                p++;
            } else if (*p == 'L') {
                args[arg_idx] = stack_vals[sv];
                sv++;
                arg_idx++;
                while (*p && *p != ';') p++;
                if (*p == ';') p++;
            } else if (*p == '[') {
                args[arg_idx] = stack_vals[sv];
                sv++;
                arg_idx++;
                while (*p == '[') p++;
                if (*p == 'L') while (*p && *p != ';') p++;
                if (*p) p++;
            } else {
                args[arg_idx] = stack_vals[sv];
                sv++;
                arg_idx++;
                p++;
            }
        }
        
        free(stack_vals);
        arg_count = java_args;
    }
    
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[EXEC] invokespecial: %s.%s%s (obj=%p, args=%d)\n", 
            class_name ? class_name : "??", 
            method_name ? method_name : "??", 
            descriptor ? descriptor : "??",
            (void*)obj, arg_count);
    fflush(stderr);
    
    if (!obj) {
        fprintf(stderr, "[EXEC] invokespecial: NULL object!\n");
        free(args);
        return -1;
    }
    
    /* Get the class for the method */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    if (!target_class) {
        fprintf(stderr, "[EXEC] invokespecial: class %s not found\n", class_name);
        free(args);
        return -1;
    }
    
    /* Find method */
    JavaMethod* method = jvm_resolve_method(jvm, target_class, method_name, descriptor);
    
    if (!method) {
        /* Try native method in class hierarchy */
        NativeMethod native = NULL;
        JavaClass* search_class = target_class;
        
        while (search_class && !native) {
            native = native_find(jvm, search_class->class_name, method_name, descriptor);
            if (!native) {
                search_class = search_class->super_class;
            }
        }
        
        if (native) {
            fprintf(stderr, "[EXEC] invokespecial: calling native %s.%s%s\n", 
                    search_class->class_name, method_name, descriptor);
            fflush(stderr);
            JavaValue result = native(jvm, thread, args, arg_count + 1);
            free(args);
            
            /* Push result if not void */
            if (descriptor && strlen(descriptor) > 0) {
                const char* ret = strchr(descriptor, ')');
                if (ret && ret[1] != 'V') {
                    PUSH(frame, result);
                }
            }
            return 0;
        }
        
        /* For constructors on stub classes, just continue */
        if (method_name && strcmp(method_name, "<init>") == 0 && target_class->is_stub) {
            fprintf(stderr, "[EXEC] invokespecial: constructor %s.<init>() not found (stub class), ignoring\n", 
                    class_name);
            free(args);
            return 0;
        }
        
        /* For other methods on stub classes, provide default return */
        if (target_class->is_stub) {
            fprintf(stderr, "[EXEC] invokespecial: method %s.%s%s not found (stub class), using default\n", 
                    class_name, method_name, descriptor);
            
            /* Push default return value based on type */
            if (descriptor && strlen(descriptor) > 0) {
                const char* ret = strchr(descriptor, ')');
                if (ret && ret[1] != 'V') {
                    JavaValue default_val = { .raw = 0 };
                    PUSH(frame, default_val);
                }
            }
            free(args);
            return 0;
        }
        
        fprintf(stderr, "[EXEC] invokespecial: method %s.%s%s not found\n", 
                class_name, method_name, descriptor);
        free(args);
        return -1;
    }
    
    /* Execute method */
    JavaValue result;
    int ret = execute_method(jvm, thread, method, args, &result);
    
    if (ret == 0 && descriptor) {
        /* Push return value if not void */
        const char* ret_type = strchr(descriptor, ')');
        if (ret_type && ret_type[1] != 'V') {
            PUSH(frame, result);
        }
    }
    
    free(args);
    return ret;
}

int op_invokestatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    
    /* Get method reference */
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_Methodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }
    
    /* Count arguments */
    int arg_count = 0;
    JavaValue* args = NULL;
    
    if (descriptor) {
        arg_count = count_args(descriptor);
        
        /* Allocate args array */
        args = (JavaValue*)malloc(arg_count * sizeof(JavaValue));
        if (!args) return -1;
        
        /* Pop arguments in reverse order */
        for (int i = arg_count - 1; i >= 0; i--) {
            args[i] = POP(frame);
        }
    }
    
    fprintf(stderr, "[EXEC] invokestatic: %s.%s%s (args=%d)\n", 
            class_name ? class_name : "??", 
            method_name ? method_name : "??", 
            descriptor ? descriptor : "??",
            arg_count);
    fflush(stderr);
    
    /* Try to find the class and resolve the method */
    JavaClass* target_class = jvm_load_class(jvm, class_name);
    JavaMethod* method = NULL;
    
    if (target_class) {
        method = jvm_resolve_method(jvm, target_class, method_name, descriptor);
    }
    
    if (method) {
        /* Found Java method - execute it */
        fprintf(stderr, "[EXEC] invokestatic: calling Java method %s.%s%s\n",
                class_name, method_name, descriptor);
        fflush(stderr);
        
        JavaValue result;
        int ret = execute_method(jvm, thread, method, args, &result);
        
        if (ret == 0 && descriptor) {
            const char* ret_type = strchr(descriptor, ')');
            if (ret_type && ret_type[1] != 'V') {
                PUSH(frame, result);
            }
        }
        
        free(args);
        return ret;
    }
    
    /* Try to find native method */
    NativeMethod native = native_find(jvm, class_name, method_name, descriptor);
    
    if (native) {
        fprintf(stderr, "[EXEC] invokestatic: calling native %s.%s%s\n", 
                class_name, method_name, descriptor);
        fflush(stderr);
        JavaValue result = native(jvm, thread, args, arg_count);
        free(args);
        
        /* Push result if not void */
        if (descriptor) {
            const char* ret = strchr(descriptor, ')');
            if (ret && ret[1] != 'V') {
                PUSH(frame, result);
            }
        }
        return 0;
    }
    
    /* Method not found - for stub classes, just return default value */
    fprintf(stderr, "[EXEC] invokestatic: %s.%s%s not found (stub?), returning default\n",
            class_name, method_name, descriptor);
    fflush(stderr);
    
    free(args);
    
    /* Push default return value if not void */
    if (descriptor) {
        const char* ret = strchr(descriptor, ')');
        if (ret && ret[1] != 'V') {
            JavaValue result = { .i = 0 };
            PUSH(frame, result);
        }
    }
    
    return 0;
}

int op_invokeinterface(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    uint8_t count = FETCH_U1(frame);
    uint8_t zero = FETCH_U1(frame);
    (void)zero;
    
    /* Get method reference */
    const char* class_name = NULL;
    const char* method_name = NULL;
    const char* descriptor = NULL;
    
    if (index > 0 && index < frame->clazz->constant_pool_count) {
        ConstantPoolEntry* entry = &frame->clazz->constant_pool[index];
        if (entry->tag == CONSTANT_InterfaceMethodref) {
            uint16_t class_idx = entry->info.ref_info.class_index;
            uint16_t nat_idx = entry->info.ref_info.name_and_type_index;
            
            class_name = classfile_get_class_name(frame->clazz, class_idx);
            classfile_get_name_and_type(frame->clazz, nat_idx, &method_name, &descriptor);
        }
    }
    
    /* Pop arguments based on count or descriptor */
    if (count > 0) {
        for (int i = 0; i < count - 1; i++) {  /* count includes this */
            POP(frame);
        }
    }
    
    /* Pop object reference */
    JavaValue obj_ref = POP(frame);
    (void)obj_ref;
    
    (void)jvm; (void)class_name; (void)method_name;
    /* TODO: Actually invoke the interface method */
    return 0;
}

/* Object creation */
int op_new(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    const char* class_name = classfile_get_class_name(frame->clazz, index);
    
    JavaClass* clazz = jvm_load_class(jvm, class_name);
    if (!clazz) {
        fprintf(stderr, "[EXEC] op_new: class %s not found!\n", class_name);
        native_throw_cnfe(jvm, thread, class_name);
        return -1;
    }
    
    /* Ensure super_class is resolved (may have been loaded from JAR) */
    if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
        fprintf(stderr, "[EXEC] op_new: resolving super_class %s for %s\n", 
                clazz->super_class_name, clazz->class_name);
        fflush(stderr);
        clazz->super_class = jvm_load_class(jvm, clazz->super_class_name);
    }
    
    fprintf(stderr, "[EXEC] op_new: creating %s (super_class=%p, super_class_name=%s)\n", 
            clazz->class_name, 
            (void*)clazz->super_class,
            clazz->super_class ? clazz->super_class->class_name : 
            (clazz->super_class_name ? clazz->super_class_name : "none"));
    fflush(stderr);
    
    JavaObject* obj = jvm_new_object(jvm, clazz);
    if (!obj) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = obj };
    PUSH(frame, v);
    return 0;
}

int op_newarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint8_t atype = FETCH_U1(frame);
    jint count = POP(frame).i;
    
    if (count < 0) {
        native_throw_iae(jvm, thread, "Negative array size");
        return -1;
    }
    
    JavaArray* array = jvm_new_array(jvm, atype, count);
    if (!array) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = array };
    PUSH(frame, v);
    return 0;
}

int op_anewarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    jint count = POP(frame).i;
    (void)index;
    
    if (count < 0) {
        native_throw_iae(jvm, thread, "Negative array size");
        return -1;
    }
    
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, count);
    if (!array) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = array };
    PUSH(frame, v);
    return 0;
}

int op_arraylength(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaArray* array = (JavaArray*)PEEK(frame).ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    frame->stack[frame->stack_top].i = array->length;
    return 0;
}

int op_athrow(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaObject* exception = (JavaObject*)POP(frame).ref;
    
    if (!exception) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    jvm_throw(jvm, exception);
    return -1;  /* Signal exception */
}

int op_checkcast(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaObject* obj = (JavaObject*)PEEK(frame).ref;
    
    if (obj) {
        const char* class_name = classfile_get_class_name(frame->clazz, index);
        JavaClass* target = jvm_load_class(jvm, class_name);
        
        if (!object_instance_of(obj, target)) {
            jvm_throw_by_name(jvm, "java/lang/ClassCastException", NULL);
            return -1;
        }
    }
    
    return 0;
}

int op_instanceof(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    JavaValue result = { .i = 0 };
    
    if (obj) {
        const char* class_name = classfile_get_class_name(frame->clazz, index);
        JavaClass* target = jvm_load_class(jvm, class_name);
        result.i = object_instance_of(obj, target) ? 1 : 0;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_monitorenter(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    return monitor_enter(jvm, obj);
}

int op_monitorexit(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaObject* obj = (JavaObject*)POP(frame).ref;
    
    if (!obj) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    return monitor_exit(jvm, obj);
}

/* Wide instructions */
int op_wide(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint8_t opcode = FETCH_U1(frame);
    uint16_t index = FETCH_U2(frame);
    JavaValue v1, v2;
    
    fprintf(stderr, "[EXEC] wide instruction: opcode=0x%02X, index=%d\n", opcode, index);
    
    switch (opcode) {
        case OPC_ILOAD:
        case OPC_FLOAD:
        case OPC_ALOAD:
            if (load_local(frame, index, &v1) != 0) return -1;
            PUSH(frame, v1);
            break;
            
        case OPC_LLOAD:
        case OPC_DLOAD:
            if (load_local(frame, index, &v1) != 0) return -1;
            if (load_local(frame, index + 1, &v2) != 0) return -1;
            PUSH(frame, v1);
            PUSH(frame, v2);
            break;
            
        case OPC_ISTORE:
        case OPC_FSTORE:
        case OPC_ASTORE:
            v1 = POP(frame);
            if (store_local(frame, index, v1) != 0) return -1;
            break;
            
        case OPC_LSTORE:
        case OPC_DSTORE:
            v2 = POP(frame);
            v1 = POP(frame);
            if (store_local(frame, index + 1, v2) != 0) return -1;
            if (store_local(frame, index, v1) != 0) return -1;
            break;
            
        case OPC_IINC: {
            int16_t constant = FETCH_S2(frame);
            if (load_local(frame, index, &v1) != 0) return -1;
            v1.i += constant;
            if (store_local(frame, index, v1) != 0) return -1;
            break;
        }
            
        case OPC_RET:
            if (load_local(frame, index, &v1) != 0) return -1;
            frame->pc = v1.i;
            break;
            
        default:
            fprintf(stderr, "[EXEC] Unknown wide opcode: 0x%02X\n", opcode);
            return -1;
    }
    
    return 0;
}

int op_multianewarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t class_index = FETCH_U2(frame);
    uint8_t dimensions = FETCH_U1(frame);
    
    /* Get array class name */
    const char* class_name = NULL;
    if (class_index > 0 && class_index < frame->clazz->constant_pool_count) {
        class_name = classfile_get_class_name(frame->clazz, class_index);
    }
    
    fprintf(stderr, "[EXEC] multianewarray: class=%s, dimensions=%d\n", 
            class_name ? class_name : "?", dimensions);
    
    /* Pop dimension sizes from stack (in reverse order) */
    jint* sizes = (jint*)malloc(dimensions * sizeof(jint));
    if (!sizes) return -1;
    
    for (int i = dimensions - 1; i >= 0; i--) {
        sizes[i] = POP(frame).i;
        if (sizes[i] < 0) {
            fprintf(stderr, "[EXEC] multianewarray: negative array size %d\n", sizes[i]);
            free(sizes);
            return -1;
        }
    }
    
    /* For now, only support 2D arrays ([[X) */
    if (dimensions == 2) {
        /* Create array of arrays */
        JavaArray* outer_array = (JavaArray*)jvm_new_array(jvm, DESC_ARRAY, sizes[0]);
        if (!outer_array) {
            fprintf(stderr, "[EXEC] multianewarray: failed to create outer array\n");
            free(sizes);
            JavaValue v = { .ref = NULL };
            PUSH(frame, v);
            return 0;
        }
        
        /* Determine element type from class name ([[X -> X) */
        int elem_type = DESC_INT;  /* Default to int */
        if (class_name && strlen(class_name) > 2) {
            char type_char = class_name[2];
            switch (type_char) {
                case 'Z': elem_type = T_BOOLEAN; break;
                case 'B': elem_type = T_BYTE; break;
                case 'C': elem_type = T_CHAR; break;
                case 'S': elem_type = T_SHORT; break;
                case 'I': elem_type = T_INT; break;
                case 'J': elem_type = T_LONG; break;
                case 'F': elem_type = T_FLOAT; break;
                case 'D': elem_type = T_DOUBLE; break;
                case 'L': case '[': elem_type = DESC_OBJECT; break;
            }
        }
        
        /* Create inner arrays */
        for (int i = 0; i < sizes[0]; i++) {
            JavaArray* inner_array = (JavaArray*)jvm_new_array(jvm, elem_type, sizes[1]);
            array_set_ref(outer_array, i, inner_array);
        }
        
        fprintf(stderr, "[EXEC] multianewarray: created %dx%d array of type %d\n", 
                sizes[0], sizes[1], elem_type);
        
        JavaValue v = { .ref = outer_array };
        PUSH(frame, v);
    } else if (dimensions == 1) {
        /* Single dimension - just create a regular array */
        int elem_type = DESC_INT;
        if (class_name && strlen(class_name) > 1) {
            char type_char = class_name[1];
            switch (type_char) {
                case 'Z': elem_type = T_BOOLEAN; break;
                case 'B': elem_type = T_BYTE; break;
                case 'C': elem_type = T_CHAR; break;
                case 'S': elem_type = T_SHORT; break;
                case 'I': elem_type = T_INT; break;
                case 'J': elem_type = T_LONG; break;
                case 'F': elem_type = T_FLOAT; break;
                case 'D': elem_type = T_DOUBLE; break;
                case 'L': case '[': elem_type = DESC_OBJECT; break;
            }
        }
        
        JavaArray* array = (JavaArray*)jvm_new_array(jvm, elem_type, sizes[0]);
        JavaValue v = { .ref = array };
        PUSH(frame, v);
    } else {
        /* More than 2 dimensions - not supported yet */
        fprintf(stderr, "[EXEC] multianewarray: %d dimensions not supported\n", dimensions);
        JavaValue v = { .ref = NULL };
        PUSH(frame, v);
    }
    
    free(sizes);
    return 0;
}

int op_ifnull(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    void* value = POP(frame).ref;
    
    if (value == NULL) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_ifnonnull(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    void* value = POP(frame).ref;
    
    if (value != NULL) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_goto_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int32_t offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    frame->pc += 4 + offset - 5;
    return 0;
}

int op_jsr_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int32_t offset = (int32_t)jvm_read_u32(frame->code + frame->pc);
    JavaValue ret_addr = { .i = frame->pc + 4 };
    PUSH(frame, ret_addr);
    frame->pc += offset;
    return 0;
}
