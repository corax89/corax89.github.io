/*
 * J2ME Emulator - Heap and Garbage Collector (Fixed)
 * Mark-Sweep with free list, Coalescing, and 32-bit alignment support
 */
#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For posix_memalign */
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "heap.h"
#include "jvm.h"
#include "opcodes.h"
#include "classfile.h"
#include "debug.h"
#include "native.h"  /* For string field slot accessors */

/* Global JVM pointer for object_instance_of (set during JVM initialization) */
JVM* g_jvm_for_instanceof = NULL;

/* Выравнивание объектов. 
 * На 32-битных системах double/long требуют выравнивания по 8 байт. 
 * Поэтому используем 8 для совместимости. */
#ifndef OBJECT_ALIGNMENT
#define OBJECT_ALIGNMENT 8
#endif

/* Free list entry for recycled memory */
typedef struct FreeBlock {
    struct FreeBlock* next;
    size_t size;
} FreeBlock;

/* Heap state */
static struct {
    uint8_t* start;
    uint8_t* current;   /* Bump pointer for new allocations */
    uint8_t* end;
    size_t size;
    size_t allocated;   /* Total bytes currently occupied by live objects */
    size_t freed;       /* Total historical freed bytes */
    
    /* Мы не используем linked list heap.objects для обхода GC, 
       так как линейный проход по памяти надежнее. 
       Но можно оставить для статистики. */
    
    FreeBlock* free_list;  /* Free list for recycled memory (sorted by address for coalescing) */
    
    void*** roots;
    size_t root_count;
    size_t root_capacity;
    
    /* GC statistics */
    size_t gc_cycles;
    size_t gc_total_freed;
} heap;

/* Global heap bounds for validation */
void* g_heap_start = NULL;
void* g_heap_end = NULL;

/* Forward declarations */
static void gc_mark_object(void* ptr);
static void* try_alloc_from_free_list(size_t total_size);

/* Проверка, является ли указатель частью кучи */
static inline bool is_heap_ptr(void* ptr) {
    return ptr >= (void*)heap.start && ptr < (void*)heap.end;
}

/* Инициализация кучи */
int heap_init(JVM* jvm, size_t initial_size, size_t max_size) {
    (void)jvm; (void)max_size;
    
    /* Выравниваем начальный адрес кучи */
#if defined(_WIN32) || defined(_WIN64)
    /* Windows: использование _aligned_malloc */
    heap.start = (uint8_t*)_aligned_malloc(initial_size, OBJECT_ALIGNMENT);
    if (!heap.start) return JNI_ERR;
#elif defined(__APPLE__) || defined(__linux__) || defined(__unix__)
    /* Unix-like: использование posix_memalign */
    if (posix_memalign((void**)&heap.start, OBJECT_ALIGNMENT, initial_size) != 0) {
        /* Пробуем обычный malloc как запасной вариант */
        heap.start = (uint8_t*)malloc(initial_size);
        if (!heap.start) return JNI_ERR;
        
        /* Проверяем выравнивание */
        if (((uintptr_t)heap.start & (OBJECT_ALIGNMENT - 1)) != 0) {
            WARN_LOG("malloc returned unaligned address, performance may suffer");
        }
    }
#else
    /* Для других систем используем malloc и надеемся на лучшее */
    heap.start = (uint8_t*)malloc(initial_size);
    if (!heap.start) return JNI_ERR;
    
    /* Проверяем выравнивание */
    if (((uintptr_t)heap.start & (OBJECT_ALIGNMENT - 1)) != 0) {
        WARN_LOG("malloc returned unaligned address, performance may suffer");
    }
#endif
    
    heap.current = heap.start;
    heap.end = heap.start + initial_size;
    heap.size = initial_size;
    heap.allocated = 0;
    heap.freed = 0;
    heap.free_list = NULL;
    heap.gc_cycles = 0;
    heap.gc_total_freed = 0;
    
    /* Set global heap bounds for validation */
    g_heap_start = heap.start;
    g_heap_end = heap.end;
    
    heap.roots = (void***)malloc(1024 * sizeof(void**));
    if (!heap.roots) {
        free(heap.start);
        return JNI_ERR;
    }
    heap.root_capacity = 1024;
    heap.root_count = 0;
    
    return JNI_OK;
}

/* Уничтожение кучи */
void heap_destroy(JVM* jvm) {
    (void)jvm;
    free(heap.start);
    free(heap.roots);
    heap.start = NULL;
    heap.current = NULL;
    heap.end = NULL;
    heap.free_list = NULL;
}

/* Попытка выделить память из списка свободных блоков (First Fit) */
static void* try_alloc_from_free_list(size_t total_size) {
    FreeBlock** pp = &heap.free_list;
    FreeBlock* prev = NULL;
    
    while (*pp) {
        FreeBlock* block = *pp;
        
        if (block->size >= total_size) {
            /* Найден подходящий блок */
            
            /* Отсоединяем блок из списка */
            if (prev) {
                prev->next = block->next;
            } else {
                heap.free_list = block->next;
            }
            
            /* Если блок намного больше запроса, дробим его */
            if (block->size >= total_size + sizeof(GCObjectHeader) + OBJECT_ALIGNMENT) {
                /* ВАЖНО: remainder должен начинаться с GCObjectHeader для корректного
                   линейного прохода GC. FreeBlock использует те же поля что и 
                   GCObjectHeader (size + next), поэтому это безопасно. */
                GCObjectHeader* remainder = (GCObjectHeader*)((uint8_t*)block + total_size);
                remainder->size = (uint32_t)(block->size - total_size);
                remainder->type = OBJ_TYPE_FREE;  /* Маркируем как свободный блок */
                remainder->marked = 0;
                remainder->pinned = 0;
                remainder->clazz = NULL;
                remainder->next = NULL;
                
                /* Вставляем остаток обратно в список */
                FreeBlock* fb = (FreeBlock*)remainder;
                fb->next = heap.free_list;
                heap.free_list = fb;
            }
            
            return block;
        }
        
        prev = block;
        pp = &block->next;
    }
    
    return NULL;
}

/* Базовое выделение памяти */
void* heap_alloc(JVM* jvm, size_t size, JavaClass* clazz, ObjectType type) {
    (void)jvm;
    
    /* Выравниваем размер запроса */
    size = (size + OBJECT_ALIGNMENT - 1) & ~(OBJECT_ALIGNMENT - 1);
    
    /* Добавляем размер GC-заголовка */
    size_t total_size = sizeof(GCObjectHeader) + size;
    
    /* 1. Пытаемся найти в Free List */
    GCObjectHeader* header = (GCObjectHeader*)try_alloc_from_free_list(total_size);
    
    if (!header) {
        /* 2. Если нет в Free List, берем из топа кучи (Bump Pointer) */
        if (heap.current + total_size > heap.end) {
            /* Не хватает места в конце кучи. Запускаем GC. */
            gc_collect(jvm);
            
            /* Пробуем снова в Free List после GC */
            header = (GCObjectHeader*)try_alloc_from_free_list(total_size);
            
            if (!header) {
                /* Все еще нет места. Проверяем топ кучи (GC мог освободить место в середине, но не в конце) */
                if (heap.current + total_size > heap.end) {
                    ERROR_LOG("Out of memory! Requested: %zu, Available: %zu",
                            total_size, (size_t)(heap.end - heap.current));
                    return NULL;
                }
                
                /* Если GC освободил место в конце, используем bump pointer */
                header = (GCObjectHeader*)heap.current;
                heap.current += total_size;
            }
        } else {
            /* Место есть, выделяем */
            header = (GCObjectHeader*)heap.current;
            heap.current += total_size;
        }
    }
    
    heap.allocated += total_size;
    
    /* Вычисляем указатель на пользовательские данные (сразу после заголовка) */
    void* ptr = (void*)(header + 1);
    memset(ptr, 0, size);  /* Zero-initialize */
    
    /* Инициализация заголовка */
    /* Примечание: next здесь не используется для связывания объектов при GC, 
       так как мы используем линейный проход. Поле зарезервировано. */
    header->next = NULL; 
    header->clazz = clazz;
    header->size = (uint32_t)total_size;
    header->type = (uint8_t)type;
    header->marked = 0;
    header->pinned = 0;
    header->reserved = 0;
    
    /* DEBUG: Log heap allocation */
    GC_DEBUG("[HEAP_ALLOC] ptr=%p, gc_header=%p, clazz=%p (%s), type=%d, size=%u",
            ptr, (void*)header, (void*)clazz, 
            clazz ? (clazz->class_name ? clazz->class_name : "NO_NAME") : "NULL",
            type, header->size);
    
    return ptr;
}

/* Выделение объекта */
JavaObject* heap_alloc_object(JVM* jvm, JavaClass* clazz) {
    if (!clazz) {
        ERROR_LOG("heap_alloc_object called with NULL class");
        return NULL;
    }
    
    /* ИСПРАВЛЕНИЕ: clazz->instance_size уже должен включать sizeof(ObjectHeader) + поля.
       Мы не должны добавлять sizeof(ObjectHeader) здесь снова. */
    size_t size = clazz->instance_size;
    
    /* Минимальная защита */
    if (size < sizeof(JavaObject)) {
        size = sizeof(JavaObject);
    }

    /* Выравниваем размер объекта */
    size = (size + OBJECT_ALIGNMENT - 1) & ~(OBJECT_ALIGNMENT - 1);
    
    /* GC_DEBUG("Allocating object: class=%s, size=%zu", clazz->class_name, size); */
    
    JavaObject* obj = (JavaObject*)heap_alloc(jvm, size, clazz, OBJ_TYPE_OBJECT);
    if (obj) {
        /* Инициализируем Java-хедер объекта */
        obj->header.clazz = clazz;
        obj->header.hashcode = (jint)(intptr_t)obj;  /* Identity hash */
        obj->header.gc_mark = 0;
        obj->header.reserved = 0;
        
        /* ИСПРАВЛЕНИЕ: Обнуляем поля объекта для корректной инициализации
           (0 для числовых типов, null для ссылок, false для boolean) */
        size_t fields_size = size - sizeof(ObjectHeader);
        if (fields_size > 0 && obj->fields) {
            memset(obj->fields, 0, fields_size);
        }
    } else {
        ERROR_LOG("heap_alloc failed for class %s", 
                clazz->class_name ? clazz->class_name : "unknown");
    }
    
    return obj;
}

/* Выделение массива */
JavaArray* heap_alloc_array(JVM* jvm, uint8_t element_type, jsize length, JavaClass* element_class) {
    /* Verify JavaArray structure size at runtime */
    /* On 64-bit: should be 32 bytes (ObjectHeader 16 + length 4 + element_type 1 + reserved 3 + element_class 8) */
    /* On 32-bit: should be 20 bytes (ObjectHeader 8 + length 4 + element_type 1 + reserved 3 + element_class 4) */
    #ifdef __LP64__
    if (sizeof(JavaArray) != 32) {
        ERROR_LOG("JavaArray size mismatch: expected 32, got %zu", sizeof(JavaArray));
    }
    #endif
    
    /* Размер элемента */
    size_t elem_size;
    switch (element_type) {
        case T_BOOLEAN:
        case T_BYTE:    elem_size = 1; break;
        case T_CHAR:
        case T_SHORT:   elem_size = 2; break;
        case T_INT:
        case T_FLOAT:   elem_size = 4; break;
        case T_LONG:
        case T_DOUBLE:  elem_size = 8; break;
        case DESC_OBJECT:
        case DESC_ARRAY: elem_size = sizeof(void*); break;
        default: elem_size = 4; break;
    }
    
    size_t data_size = elem_size * length;
    size_t total_size = sizeof(JavaArray) + data_size;
    
    /* Поиск класса java/lang/Object для массива. */
    JavaClass* array_class = NULL;
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* c = jvm->class_loader.classes[i];
        if (c->class_name && strcmp(c->class_name, "java/lang/Object") == 0) {
            array_class = c;
            break;
        }
    }
    
    if (!array_class && jvm->class_loader.count > 0) {
        array_class = jvm->class_loader.classes[0]; /* Fallback */
    }
    
    /* DEBUG: Log what array_class we found */
    GC_DEBUG("[HEAP_ALLOC_ARRAY] array_class=%p (%s), element_class=%p (%s)",
            (void*)array_class, array_class ? (array_class->class_name ? array_class->class_name : "NO_NAME") : "NULL",
            (void*)element_class, element_class ? (element_class->class_name ? element_class->class_name : "NO_NAME") : "NULL");
    
    /* ИСПРАВЛЕНО: Передаём array_class в heap_alloc, чтобы GC header->clazz был установлен */
    JavaArray* array = (JavaArray*)heap_alloc(jvm, total_size, array_class, OBJ_TYPE_ARRAY);
    if (!array) return NULL;
    
    array->header.clazz = array_class;
    array->header.hashcode = (jint)(intptr_t)array;
    array->length = length;
    array->element_type = element_type;
    memset(array->_reserved, 0, sizeof(array->_reserved));
    array->element_class = element_class;  /* Store element class for object arrays */
    
    /* Debug: log array allocation details */
    DEBUG_LOG("heap_alloc_array: array=%p, elem_type=%d, length=%d, elem_class=%s, sizeof(JavaArray)=%zu",
              (void*)array, element_type, length, 
              element_class ? (element_class->class_name ? element_class->class_name : "?") : "NULL",
              sizeof(JavaArray));
    
    return array;
}

/* Выделение строки */
JavaString* heap_alloc_string(JVM* jvm, jsize length) {
    size_t data_size = length * sizeof(jchar);
    size_t total_size = sizeof(JavaString) + data_size;
    
    JavaString* str = (JavaString*)heap_alloc(jvm, total_size, NULL, OBJ_TYPE_STRING);
    if (!str) return NULL;
    
    JavaClass* str_class = NULL;
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* c = jvm->class_loader.classes[i];
        if (c->class_name && strcmp(c->class_name, "java/lang/String") == 0) {
            str_class = c;
            break;
        }
    }
    
    /* ИСПРАВЛЕНО: Предупреждение если класс String не найден, но не ошибка */
    if (!str_class) {
        WARN_LOG("java/lang/String class not found during string allocation");
    }
    
    /* CRITICAL FIX: Set both Java header and GC header class pointers */
    str->header.clazz = str_class;
    str->header.hashcode = (jint)(intptr_t)str;
    str->length = length;
    str->hash = 0;
    str->utf8 = NULL;
    
    /* Set GC header class pointer for object_get_class() */
    GCObjectHeader* gc_header = (GCObjectHeader*)str - 1;
    gc_header->clazz = str_class;
    
    return str;
}

/* --- Mark and Sweep Implementation --- */

/* ИСПРАВЛЕНО: Динамический размер стека маркировки GC */
#define GC_MARK_STACK_INITIAL_SIZE 4096
#define GC_MARK_STACK_MAX_SIZE (1024 * 1024)  /* Максимум 1M объектов */

typedef struct {
    void* ptr;
} MarkStackEntry;

static MarkStackEntry* gc_mark_stack = NULL;
static int gc_mark_stack_top = 0;
static int gc_mark_stack_capacity = 0;

/* ИСПРАВЛЕНО: Инициализация стека маркировки */
static bool gc_mark_stack_init(void) {
    gc_mark_stack = (MarkStackEntry*)malloc(GC_MARK_STACK_INITIAL_SIZE * sizeof(MarkStackEntry));
    if (!gc_mark_stack) return false;
    gc_mark_stack_capacity = GC_MARK_STACK_INITIAL_SIZE;
    gc_mark_stack_top = 0;
    return true;
}

/* ИСПРАВЛЕНО: Освобождение стека маркировки */
static void gc_mark_stack_destroy(void) {
    if (gc_mark_stack) {
        free(gc_mark_stack);
        gc_mark_stack = NULL;
    }
    gc_mark_stack_capacity = 0;
    gc_mark_stack_top = 0;
}

/* ИСПРАВЛЕНО: Push с проверкой и расширением стека */
static bool gc_push_mark(void* ptr) {
    if (!ptr) return true;
    
    /* Проверка на переполнение и расширение */
    if (gc_mark_stack_top >= gc_mark_stack_capacity) {
        if (gc_mark_stack_capacity >= GC_MARK_STACK_MAX_SIZE) {
            ERROR_LOG("Mark stack overflow (max %d entries)", GC_MARK_STACK_MAX_SIZE);
            return false;  /* Переполнение */
        }
        
        /* Расширяем стек */
        int new_capacity = gc_mark_stack_capacity * 2;
        if (new_capacity > GC_MARK_STACK_MAX_SIZE) {
            new_capacity = GC_MARK_STACK_MAX_SIZE;
        }
        
        MarkStackEntry* new_stack = (MarkStackEntry*)realloc(gc_mark_stack, 
                                                              new_capacity * sizeof(MarkStackEntry));
        if (!new_stack) {
            ERROR_LOG("Failed to expand mark stack");
            return false;
        }
        
        gc_mark_stack = new_stack;
        gc_mark_stack_capacity = new_capacity;
        GC_DEBUG("Expanded mark stack to %d entries", new_capacity);
    }
    
    gc_mark_stack[gc_mark_stack_top++].ptr = ptr;
    return true;
}

static void gc_mark_object(void* ptr) {
    if (!ptr) return;
    if (!is_heap_ptr(ptr)) return;
    
    /* Получаем GC заголовок (он находится перед пользовательскими данными) */
    GCObjectHeader* header = (GCObjectHeader*)ptr - 1;
    
    /* Проверка валидности */
    if (header->size == 0 || header->size > heap.size) {
        return; /* Коррумпированный указатель */
    }
    
    if (header->marked) return; /* Уже помечен */
    
    header->marked = 1;
    
    /* Рекурсивная пометка ссылок */
    switch (header->type) {
        case OBJ_TYPE_OBJECT: {
            JavaObject* obj = (JavaObject*)ptr;
            JavaClass* clazz = obj->header.clazz;
            
            if (!clazz) break;
            
            /* Build hierarchy and calculate field slots properly */
            JavaClass* hierarchy[64];
            int depth = 0;
            JavaClass* c = clazz;
            while (c && depth < 64) {
                hierarchy[depth++] = c;
                c = c->super_class;
            }
            
            /* Process fields from Object down to actual class */
            int slot = 0;
            for (int h = depth - 1; h >= 0; h--) {
                JavaClass* current = hierarchy[h];
                if (!current->fields) continue;
                
                for (int i = 0; i < current->fields_count; i++) {
                    JavaField* field = &current->fields[i];
                    
                    /* Skip static fields */
                    if (field->access_flags & ACC_STATIC) continue;
                    
                    /* Check if this is a reference field */
                    if (field->descriptor) {
                        char desc = field->descriptor[0];
                        if (desc == 'L' || desc == '[') {
                            void* ref = obj->fields[slot].ref;
                            if (ref) {
                                gc_push_mark(ref);
                            }
                        }
                    }
                    
                    /* Advance slot */
                    slot++;
                    /* Long and double take 2 slots */
                    if (field->descriptor && 
                        (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                        slot++;
                    }
                }
            }
            break;
        }
        
        case OBJ_TYPE_ARRAY: {
            JavaArray* array = (JavaArray*)ptr;
            if (array->element_type == DESC_OBJECT || array->element_type == DESC_ARRAY) {
                void** refs = (void**)((uint8_t*)array + sizeof(JavaArray));
                for (jsize i = 0; i < array->length; i++) {
                    if (refs[i]) gc_push_mark(refs[i]);
                }
            }
            break;
        }
        
        case OBJ_TYPE_CLASS: {
             /* Статические поля классов */
            if (header->clazz && header->clazz->static_fields) {
                JavaClass* clazz = header->clazz;
                for (int i = 0; i < clazz->static_fields_count; i++) {
                    JavaStaticField* sf = &clazz->static_fields[i];
                    if (sf->descriptor && (sf->descriptor[0] == 'L' || sf->descriptor[0] == '[')) {
                        if (sf->value.ref) gc_push_mark(sf->value.ref);
                    }
                }
            }
            break;
        }
            
        case OBJ_TYPE_STRING:
            /* Строковые данные встроены, utf8 кэш освобождается в Sweep */
            break;
    }
}

static void gc_process_mark_stack(void) {
    while (gc_mark_stack_top > 0) {
        void* ptr = gc_mark_stack[--gc_mark_stack_top].ptr;
        gc_mark_object(ptr);
    }
}

/* Запуск сборщика мусора с Линейным Sweep и Коалесцингом */
void gc_collect(JVM* jvm) {
    if (!jvm) return;
    
    /* ИСПРАВЛЕНО: Инициализация стека маркировки при первом вызове */
    if (!gc_mark_stack) {
        if (!gc_mark_stack_init()) {
            ERROR_LOG("Failed to initialize mark stack");
            return;
        }
    }
    
    size_t start_allocated = heap.allocated;
    gc_mark_stack_top = 0;
    
    /* 1. Mark Phase */
    /* Mark from Roots */
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] && *heap.roots[i]) {
            gc_push_mark(*heap.roots[i]);
        }
    }
    
    /* Mark from Stacks */
    for (int i = 0; i < jvm->thread_count; i++) {
        JavaThread* thread = jvm->threads[i];
        if (!thread) continue;
        
        if (thread->pending_exception) gc_push_mark(thread->pending_exception);
        if (thread->thread_object) gc_push_mark(thread->thread_object);
        
        JavaFrame* frame = thread->current_frame;
        while (frame) {
            /* ИСПРАВЛЕНО: Сканируем locals с учетом long/double (2 слота)
             * Long и double занимают 2 слота, но это ОДНО значение.
             * Второй слот (index+1) не является отдельной ссылкой.
             * Для locals это менее критично, т.к. .ref будет 0 для high-word,
             * но для корректности пропускаем второй слот long/double.
             */
            for (uint16_t j = 0; j < frame->max_locals; j++) {
                if (frame->locals[j].ref) {
                    gc_push_mark(frame->locals[j].ref);
                }
                /* Skip next slot for long/double - already handled by the fact
                   that high-word of long/double has .ref = 0 (it's data, not pointer) */
            }
            
            /* ИСПРАВЛЕНО: Сканируем стек с учетом long/double (2 слота)
             * JVM Spec: long и double занимают 2 слота стека.
             * Второй слот содержит continuation (high word), а не ссылку.
             * Когда long/double пушится на стек, оба слота содержат данные value,
             * поэтому .ref в high-word не будет валидным указателем.
             * Но для безопасности пропускаем второй слот явно.
             */
            for (int16_t j = 0; j <= frame->stack_top; j++) {
                if (frame->stack[j].ref) {
                    gc_push_mark(frame->stack[j].ref);
                }
                /* Note: Для long/double оба слота содержат одинаковое .j/.d значение.
                 * High-word не является ссылкой, .ref будет равен части данных.
                 * is_heap_ptr() в gc_mark_object() защитит от ложных срабатываний.
                 */
            }
            frame = frame->prev;
        }
    }
    
    /* Mark from Statics */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (!clazz || !clazz->static_fields) continue;
        for (int j = 0; j < clazz->static_fields_count; j++) {
            JavaStaticField* sf = &clazz->static_fields[j];
            if (sf->descriptor && (sf->descriptor[0] == 'L' || sf->descriptor[0] == '[')) {
                if (sf->value.ref) {
                    gc_push_mark(sf->value.ref);
                }
            }
        }
    }
    
    gc_process_mark_stack();
    
    /* 2. Sweep Phase (Linear Scan + Coalescing) */
    size_t freed_this_cycle = 0;
    size_t objects_freed = 0;
    
    /* Очищаем старый список свободных блоков, чтобы построить новый упорядоченный */
    heap.free_list = NULL; 
    
    uint8_t* scan_ptr = heap.start;
    
    /* Временный список свободных блоков для построения в порядке адреса
       (используем простой подход: добавляем в конец, но т.к. у нас нет tail, 
       будем вставлять так, чтобы список был отсортирован, или просто собираем 
       свободные куски в отдельный список и потом мержим) */
    
    /* Для простоты реализации на C без лишних аллокаций:
       Пройдемся линейно. Свободные блоки будем добавлять в free_list "в конец" 
       эмулируя это вставкой перед головой, если адрес меньше головы (сортировка по возрастанию).
       Это позволит легко слить соседние блоки. */
    
    FreeBlock* sorted_free_list = NULL;
    
    while (scan_ptr < heap.current) {
        GCObjectHeader* header = (GCObjectHeader*)scan_ptr;
        
        /* Защита от порчи памяти в куче */
        if (header->size == 0 || header->size > heap.size || scan_ptr + header->size > heap.end) {
            ERROR_LOG("Corruption detected at %p, aborting sweep", (void*)scan_ptr);
            ERROR_LOG("  header->size=%u, heap.size=%zu", header->size, heap.size);
            ERROR_LOG("  scan_ptr=%p, heap.end=%p", (void*)scan_ptr, (void*)heap.end);
            ERROR_LOG("  header->type=%d, header->marked=%d", header->type, header->marked);
            if (header->clazz) {
                ERROR_LOG("  header->clazz=%p, class_name=%s", 
                         (void*)header->clazz, 
                         header->clazz->class_name ? header->clazz->class_name : "(null)");
            }
            
            /* Попытка найти предыдущий объект для диагностики */
            uint8_t* prev_scan = heap.start;
            uint8_t* prev_obj_end = NULL;
            while (prev_scan < scan_ptr) {
                GCObjectHeader* prev_header = (GCObjectHeader*)prev_scan;
                if (prev_header->size == 0 || prev_header->size > heap.size) break;
                prev_obj_end = prev_scan + prev_header->size;
                prev_scan += prev_header->size;
            }
            if (prev_obj_end && prev_obj_end <= scan_ptr) {
                ERROR_LOG("  Previous object ended at %p, gap to corruption: %ld bytes",
                         (void*)prev_obj_end, (long)(scan_ptr - prev_obj_end));
            }
            
            /* Dump memory around corruption point */
            ERROR_LOG("  Memory dump at corruption point:");
            uint8_t* dump_start = scan_ptr;
            for (int i = 0; i < 64 && dump_start + i < heap.end; i += 16) {
                fprintf(stderr, "    %p: ", (void*)(dump_start + i));
                for (int j = 0; j < 16 && dump_start + i + j < heap.end; j++) {
                    fprintf(stderr, "%02X ", dump_start[i + j]);
                }
                fprintf(stderr, "\n");
            }
            fflush(stderr);
            break;
        }
        
        /* Пропускаем свободные блоки (они уже в free list) */
        if (header->type == OBJ_TYPE_FREE) {
            /* Этот блок уже свободен, пропускаем его при sweep */
            /* Он будет добавлен в sorted_free_list ниже как часть коалесцинга */
            scan_ptr += header->size;
            continue;
        }
        
        if (header->marked || header->pinned) {
            /* Объект жив */
            header->marked = 0; /* Сброс метки */
        } else {
            /* Объект мертв */
            freed_this_cycle += header->size;
            objects_freed++;
            
            /* Очистка строкового кэша */
            if (header->type == OBJ_TYPE_STRING) {
                JavaString* str = (JavaString*)(header + 1);
                if (str->utf8) {
                    free(str->utf8);
                    str->utf8 = NULL;
                }
            }
            
            /* Помечаем как свободный */
            header->type = OBJ_TYPE_FREE;
            
            /* Добавляем в сортированный список свободных блоков */
            FreeBlock* block = (FreeBlock*)header;
            block->size = header->size;
            
            /* Вставка в сортированный список (по возрастанию адреса) */
            FreeBlock** curr = &sorted_free_list;
            while (*curr && (uint8_t*)(*curr) < (uint8_t*)block) {
                curr = &((*curr)->next);
            }
            block->next = *curr;
            *curr = block;
        }
        
        scan_ptr += header->size;
    }
    
    /* 3. Coalescing (Слияние соседних блоков) */
    FreeBlock* fb = sorted_free_list;
    while (fb && fb->next) {
        /* Проверяем, лежит ли следующий блок сразу за текущим */
        if ((uint8_t*)fb + fb->size == (uint8_t*)fb->next) {
            /* Сливаем */
            fb->size += fb->next->size;
            fb->next = fb->next->next;
            /* Не продвигаем fb, так как новый блок может теперь merger'ся со следующим */
        } else {
            fb = fb->next;
        }
    }
    
    heap.free_list = sorted_free_list;
    
    /* Статистика */
    heap.allocated -= freed_this_cycle;
    heap.freed += freed_this_cycle;
    heap.gc_cycles++;
    heap.gc_total_freed += freed_this_cycle;
    
    /* Если мы освободили блок в конце кучи, можем подвинуть current назад (Defragmentation of top) */
    if (heap.free_list) {
        /* Найдем самый большой свободный блок. Если он в конце кучи, уменьшим current. */
        FreeBlock* last = heap.free_list;
        FreeBlock* last_prev = NULL;
        while (last->next) {
            last_prev = last;
            last = last->next;
        }
        
        if ((uint8_t*)last + last->size == heap.current) {
            /* Этот блок в самом конце кучи */
            heap.current = (uint8_t*)last;
            if (last_prev) {
                last_prev->next = NULL;
            } else {
                heap.free_list = NULL;
            }
            /* Память возвращена системе (bump pointer уменьшен) */
        }
    }

    if (freed_this_cycle > 0) {
        GC_DEBUG("Cycle %zu: freed %zu bytes (%zu objects), %zu bytes allocated",
                heap.gc_cycles, freed_this_cycle, objects_freed, heap.allocated);
    }
    
    /* Notify native code about GC completion.
     * This allows native fallback buffers (e.g., StringBuffer) to clean up
     * entries for objects that were garbage collected.
     */
    extern void native_gc_notify(void);
    native_gc_notify();
}

/* --- Roots and Utilities --- */

void gc_add_root(JVM* jvm, void** root) {
    (void)jvm;
    if (heap.root_count >= heap.root_capacity) {
        /* ИСПРАВЛЕНО: Проверка успешности realloc */
        size_t new_capacity = heap.root_capacity * 2;
        if (new_capacity == 0) new_capacity = 1024;  /* Защита от нуля */
        
        void*** new_roots = (void***)realloc(heap.roots, new_capacity * sizeof(void**));
        if (!new_roots) {
            ERROR_LOG("Failed to expand roots array");
            return;
        }
        heap.roots = new_roots;
        heap.root_capacity = new_capacity;
    }
    heap.roots[heap.root_count++] = root;
}

void gc_remove_root(JVM* jvm, void** root) {
    (void)jvm;
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] == root) {
            heap.roots[i] = heap.roots[--heap.root_count];
            return;
        }
    }
}

void gc_pin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object || !is_heap_ptr(object)) return;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 1;
}

void gc_unpin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object || !is_heap_ptr(object)) return;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 0;
}

HeapStats heap_get_stats(JVM* jvm) {
    HeapStats stats = {0};
    (void)jvm;
    stats.total_size = heap.size;
    stats.used_size = heap.allocated;
    stats.free_size = heap.size - heap.allocated;
    stats.object_count = 0; /* Сложно считать точно без счетчика при аллокации, можно добавить */
    stats.gc_cycles = heap.gc_cycles;
    stats.gc_time_ms = 0;
    return stats;
}

/* Объектные утилиты */

JavaClass* object_get_class(void* object) {
    if (!object) return NULL;
    
    /* Check if pointer is in heap */
    if (!is_heap_ptr(object)) return NULL;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    
    /* Validate header before accessing */
    if (header->size == 0 || header->size > 64 * 1024 * 1024) {
        return NULL;  /* Invalid object */
    }
    if (header->type > OBJ_TYPE_CLASS) {
        return NULL;  /* Invalid type */
    }
    
    return header->clazz;
}

size_t object_get_size(void* object) {
    if (!object || !is_heap_ptr(object)) return 0;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->size - sizeof(GCObjectHeader);
}

jint object_hash_code(void* object) {
    if (!object) return 0;
    JavaObject* obj = (JavaObject*)object;
    return obj->header.hashcode;
}

bool object_is_array(void* object) {
    if (!object || !is_heap_ptr(object)) return false;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_ARRAY;
}

bool object_is_string(void* object) {
    if (!object || !is_heap_ptr(object)) return false;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_STRING;
}

bool object_instance_of(void* object, JavaClass* clazz) {
    if (!object || !clazz) return false;
    
    /* CRITICAL: Check if pointer is in heap before accessing GC header */
    if (!is_heap_ptr(object)) {
        /* Not a heap object - could be a Class object or invalid pointer 
         * For safety, just return false for any non-heap pointer.
         * Class objects are handled separately in checkcast/instanceof. */
        return false;
    }
    
    /* Check GC header to determine object type */
    GCObjectHeader* gc_header = (GCObjectHeader*)object - 1;
    
    /* Validate GC header before using it */
    if (gc_header->size == 0 || gc_header->size > 64 * 1024 * 1024) {
        /* Invalid GC header - corrupted object */
        return false;
    }
    if (gc_header->type > OBJ_TYPE_CLASS) {
        /* Invalid object type */
        return false;
    }
    
    bool obj_is_array = (gc_header->type == OBJ_TYPE_ARRAY);
    
    /* Get the object's class */
    JavaClass* obj_class = object_get_class(object);
    
    /* Null check for class names */
    if (!clazz->class_name) return false;
    
    /* For arrays, check element type against expected array class name */
    if (obj_is_array) {
        /* All arrays are instanceof java/lang/Object */
        if (strcmp(clazz->class_name, "java/lang/Object") == 0) {
            return true;
        }
        
        /* Arrays implement Cloneable and Serializable interfaces */
        if (strcmp(clazz->class_name, "java/lang/Cloneable") == 0 ||
            strcmp(clazz->class_name, "java/io/Serializable") == 0) {
            return true;
        }
        
        /* Check if target class is an array type (starts with '[') */
        if (clazz->class_name[0] == '[') {
            JavaArray* array = (JavaArray*)object;
            
            /* For primitive arrays, do exact type matching */
            const char* expected_name = NULL;
            switch (array->element_type) {
                case T_BOOLEAN: expected_name = "[Z"; break;
                case T_BYTE:    expected_name = "[B"; break;
                case T_CHAR:    expected_name = "[C"; break;
                case T_SHORT:   expected_name = "[S"; break;
                case T_INT:     expected_name = "[I"; break;
                case T_LONG:    expected_name = "[J"; break;
                case T_FLOAT:   expected_name = "[F"; break;
                case T_DOUBLE:  expected_name = "[D"; break;
                case DESC_OBJECT:
                case DESC_ARRAY: {
                    /* For object arrays, we need to check covariance */
                    /* clazz->class_name is like "[Ljava/lang/String;" or "[[I" */
                    
                    /* Case 1: Exact match - check if element_class matches */
                    if (array->element_class && array->element_class->class_name) {
                        /* Build expected array class name from element class */
                        /* For element class "java/lang/String", expected name is "[Ljava/lang/String;" */
                        size_t elem_name_len = strlen(array->element_class->class_name);
                        /* Need: '[' + 'L' + class_name + ';' + '\0' = elem_name_len + 4 bytes */
                        char* computed_name = malloc(elem_name_len + 4);
                        if (computed_name) {
                            computed_name[0] = '[';
                            computed_name[1] = 'L';
                            strcpy(computed_name + 2, array->element_class->class_name);
                            computed_name[elem_name_len + 2] = ';';
                            computed_name[elem_name_len + 3] = '\0';
                            
                            if (strcmp(clazz->class_name, computed_name) == 0) {
                                free(computed_name);
                                return true;
                            }
                            free(computed_name);
                        }
                        
                        /* Case 2: Covariance - Object[] can hold any reference array */
                        /* Check if target is "[Ljava/lang/Object;" */
                        if (strcmp(clazz->class_name, "[Ljava/lang/Object;") == 0) {
                            /* Any object array is assignable to Object[] */
                            return true;
                        }
                        
                        /* Case 3: Check if element type is subtype of target element type */
                        /* Parse target element class from clazz->class_name */
                        const char* target_class_name = clazz->class_name;
                        if (target_class_name[0] == '[' && target_class_name[1] == 'L') {
                            /* Extract element class name: "[Ljava/lang/Object;" -> "java/lang/Object" */
                            char* elem_target_name = strdup(target_class_name + 2);
                            if (elem_target_name) {
                                char* semicolon = strchr(elem_target_name, ';');
                                if (semicolon) *semicolon = '\0';
                                
                                /* Load target element class and check assignability */
                                extern JVM* g_jvm_for_instanceof;
                                JavaClass* target_elem_class = g_jvm_for_instanceof ? 
                                    jvm_load_class(g_jvm_for_instanceof, elem_target_name) : NULL;
                                
                                if (target_elem_class && array->element_class) {
                                    /* Check if array's element class is assignable to target element class */
                                    /* We need to check if element_class is a subtype of target_elem_class */
                                    JavaClass* check = array->element_class;
                                    while (check) {
                                        if (check == target_elem_class ||
                                            (check->class_name && target_elem_class->class_name &&
                                             strcmp(check->class_name, target_elem_class->class_name) == 0)) {
                                            free(elem_target_name);
                                            return true;
                                        }
                                        check = check->super_class;
                                    }
                                }
                                free(elem_target_name);
                            }
                        }
                    } else {
                        /* No element_class stored - assume generic Object[] for DESC_OBJECT arrays */
                        if (strcmp(clazz->class_name, "[Ljava/lang/Object;") == 0) {
                            return true;
                        }
                    }
                    break;
                }
            }
            
            /* Exact match for primitive array types */
            if (expected_name && strcmp(clazz->class_name, expected_name) == 0) {
                return true;
            }
        }
        
        /* Array type doesn't match */
        return false;
    }
    
    if (!obj_class) return false;
    
    /* Walk up the class hierarchy and compare by name */
    JavaClass* current = obj_class;
    while (current) {
        /* Compare by class name instead of pointer */
        if (current->class_name && clazz->class_name) {
            if (strcmp(current->class_name, clazz->class_name) == 0) {
                return true;
            }
        }
        
        /* Also check pointer equality as fast path */
        if (current == clazz) return true;
        
        current = current->super_class;
    }
    
    /* Check if clazz is an interface and obj_class implements it */
    /* We need to check all interfaces in the hierarchy */
    current = obj_class;
    while (current) {
        /* Check interfaces implemented by this class */
        for (int i = 0; i < current->interfaces_count; i++) {
            const char* iface_name = classfile_get_class_name(current, current->interfaces[i]);
            if (iface_name && clazz->class_name && strcmp(iface_name, clazz->class_name) == 0) {
                return true;
            }
            /* Also check if the interface extends the target interface */
            if (iface_name) {
                /* Get JVM from global context - need to pass it or use a different approach */
                /* For now, use a helper function that takes JVM parameter */
                extern JVM* g_jvm_for_instanceof;
                JavaClass* iface_class = g_jvm_for_instanceof ? jvm_load_class(g_jvm_for_instanceof, iface_name) : NULL;
                if (iface_class && iface_class != clazz) {
                    /* Recursively check parent interfaces */
                    JavaClass* iface_check = iface_class;
                    while (iface_check) {
                        for (int j = 0; j < iface_check->interfaces_count; j++) {
                            const char* parent_iface = classfile_get_class_name(iface_check, iface_check->interfaces[j]);
                            if (parent_iface && clazz->class_name && strcmp(parent_iface, clazz->class_name) == 0) {
                                return true;
                            }
                        }
                        /* Interfaces can only extend other interfaces, not classes */
                        iface_check = iface_check->super_class;  /* This would be Object or another interface */
                    }
                }
            }
        }
        
        current = current->super_class;
    }
    
    return false;
}

/* Массивы */

jsize array_length(JavaArray* array) {
    return array ? array->length : 0;
}

uint8_t array_element_type(JavaArray* array) {
    return array ? array->element_type : 0;
}

static inline void* array_data_ptr(JavaArray* array) {
    return (void*)((uint8_t*)array + sizeof(JavaArray));
}

JavaValue array_get(JavaArray* array, jsize index) {
    JavaValue v = { .raw = 0 };
    if (!array || index < 0 || index >= array->length) return v;
    
    /* Memory barrier for thread visibility - ensure we see writes from other threads */
    __sync_synchronize();
    
    void* data = array_data_ptr(array);
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:    v.i = ((uint8_t*)data)[index]; break;
        case T_CHAR:    v.i = ((jchar*)data)[index]; break;
        case T_SHORT:   v.i = ((jshort*)data)[index]; break;
        case T_INT:     v.i = ((jint*)data)[index]; break;
        case T_LONG:    v.j = ((jlong*)data)[index]; break;
        case T_FLOAT:   v.f = ((jfloat*)data)[index]; break;
        case T_DOUBLE:  v.d = ((jdouble*)data)[index]; break;
        case DESC_OBJECT:
        case DESC_ARRAY: v.ref = ((void**)data)[index]; break;
    }
    return v;
}

void array_set(JavaArray* array, jsize index, JavaValue value) {
    if (!array || index < 0 || index >= array->length) return;
    
    void* data = array_data_ptr(array);
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:    ((uint8_t*)data)[index] = (uint8_t)value.i; break;
        case T_CHAR:    ((jchar*)data)[index] = (jchar)value.i; break;
        case T_SHORT:   ((jshort*)data)[index] = (jshort)value.i; break;
        case T_INT:     ((jint*)data)[index] = value.i; break;
        case T_LONG:    ((jlong*)data)[index] = value.j; break;
        case T_FLOAT:   ((jfloat*)data)[index] = value.f; break;
        case T_DOUBLE:  ((jdouble*)data)[index] = value.d; break;
        case DESC_OBJECT:
        case DESC_ARRAY: ((void**)data)[index] = value.ref; break;
    }
    
    /* Memory barrier for thread visibility - ensure other threads see our writes */
    __sync_synchronize();
}

void* array_get_ref(JavaArray* array, jsize index) {
    if (!array || index < 0 || index >= array->length) return NULL;
    return ((void**)array_data_ptr(array))[index];
}

void array_set_ref(JavaArray* array, jsize index, void* ref) {
    if (!array || index < 0 || index >= array->length) return;
    ((void**)array_data_ptr(array))[index] = ref;
}

/* Строки */

/* Helper to check if object is a native string (OBJ_TYPE_STRING) or bytecode-created String object (OBJ_TYPE_OBJECT) */
static inline bool is_native_string(void* ptr) {
    if (!ptr) return false;
    GCObjectHeader* header = (GCObjectHeader*)ptr - 1;
    ObjectType type = header->type;
    DEBUG_LOG("is_native_string: ptr=%p, header=%p, type=%d, is_string=%d",
              ptr, header, type, type == OBJ_TYPE_STRING);
    return type == OBJ_TYPE_STRING;
}

/* String field indices are now dynamically looked up via native.c */

jsize string_length(JavaString* str) {
    if (!str) return 0;
    
    /* Check if this is a native string (inline chars) or JavaObject with fields */
    if (is_native_string(str)) {
        return str->length;
    }
    
    /* It's a JavaObject - get count from field using proper slot lookup */
    JavaObject* obj = (JavaObject*)str;
    if (obj->header.clazz && g_jvm_for_instanceof) {
        int count_slot = native_get_string_count_slot(g_jvm_for_instanceof);
        if (count_slot >= 0) {
            jsize len = obj->fields[count_slot].i;
            DEBUG_LOG("string_length: JavaObject string, count_slot=%d, len=%d", count_slot, len);
            return len;
        }
    }
    
    /* Fallback - this should not happen for properly initialized strings */
    DEBUG_LOG("string_length: WARNING - fallback used for string at %p, clazz=%p",
              str, obj->header.clazz);
    return 0;  /* Return 0 instead of garbage */
}

const jchar* string_chars(JavaString* str) {
    if (!str) return NULL;
    
    /* Check if this is a native string (inline chars) */
    if (is_native_string(str)) {
        return (const jchar*)((uint8_t*)str + sizeof(JavaString));
    }
    
    /* It's a JavaObject - get char array from value field using proper slot lookup */
    JavaObject* obj = (JavaObject*)str;
    if (obj->header.clazz && g_jvm_for_instanceof) {
        int value_slot = native_get_string_value_slot(g_jvm_for_instanceof);
        if (value_slot >= 0) {
            JavaArray* char_array = (JavaArray*)obj->fields[value_slot].ref;
            if (char_array) {
                return (const jchar*)array_data(char_array);
            }
        }
    }
    
    /* Fallback - should not happen */
    return NULL;
}

const char* string_utf8(JVM* jvm, JavaString* str) {
    (void)jvm;
    if (!str) return NULL;
    
    /* For native strings, use cached utf8 if available */
    if (is_native_string(str) && str->utf8) return str->utf8;
    
    jsize len = string_length(str);
    const jchar* chars = string_chars(str);
    if (!chars && len > 0) return NULL;
    
    char* result = (char*)malloc(len * 3 + 1);
    if (!result) return NULL;
    
    char* p = result;
    for (jsize i = 0; i < len; i++) {
        jchar c = chars[i];
        if (c < 0x80) {
            *p++ = (char)c;
        } else if (c < 0x800) {
            *p++ = (char)(0xC0 | (c >> 6));
            *p++ = (char)(0x80 | (c & 0x3F));
        } else {
            *p++ = (char)(0xE0 | (c >> 12));
            *p++ = (char)(0x80 | ((c >> 6) & 0x3F));
            *p++ = (char)(0x80 | (c & 0x3F));
        }
    }
    *p = '\0';
    
    /* Cache utf8 only for native strings */
    if (is_native_string(str)) {
        str->utf8 = result;
    }
    return result;
}

bool string_equals(JavaString* a, JavaString* b) {
    if (a == b) return true;
    if (!a || !b) return false;
    
    jsize len_a = string_length(a);
    jsize len_b = string_length(b);
    if (len_a != len_b) return false;
    
    const jchar* chars_a = string_chars(a);
    const jchar* chars_b = string_chars(b);
    if (!chars_a || !chars_b) return false;
    
    return memcmp(chars_a, chars_b, len_a * sizeof(jchar)) == 0;
}

jint string_hash(JavaString* str) {
    if (!str) return 0;
    
    /* For native strings, use cached hash if available */
    if (is_native_string(str) && str->hash) return str->hash;
    
    /* For JavaObject strings, check hash field using proper slot lookup */
    if (!is_native_string(str)) {
        JavaObject* obj = (JavaObject*)str;
        if (obj->header.clazz && g_jvm_for_instanceof) {
            int hash_slot = native_get_string_hash_slot(g_jvm_for_instanceof);
            if (hash_slot >= 0) {
                jint cached_hash = obj->fields[hash_slot].i;
                if (cached_hash != 0) return cached_hash;
            }
        }
    }
    
    jsize len = string_length(str);
    const jchar* chars = string_chars(str);
    if (!chars) return 0;
    
    jint hash = 0;
    for (jsize i = 0; i < len; i++) {
        hash = 31 * hash + chars[i];
    }
    
    /* Cache hash for native strings */
    if (is_native_string(str)) {
        str->hash = hash;
    }
    
    return hash;
}

void heap_dump(JVM* jvm) {
    (void)jvm;
    printf("=== Heap Dump ===\n");
    printf("Total: %zu bytes\n", heap.size);
    printf("Used: %zu bytes\n", heap.allocated);
    printf("Free List Blocks: ");
    
    int count = 0;
    FreeBlock* fb = heap.free_list;
    while(fb && count < 10) {
        printf("[%p:%zu] ", (void*)fb, fb->size);
        fb = fb->next;
        count++;
    }
    printf("\n");
    
    printf("Live objects scan:\n");
    uint8_t* ptr = heap.start;
    int obj_count = 0;
    while (ptr < heap.current && obj_count < 20) {
        GCObjectHeader* h = (GCObjectHeader*)ptr;
        const char* type_name = "?";
        if (h->type == OBJ_TYPE_OBJECT && h->clazz) type_name = h->clazz->class_name;
        else if (h->type == OBJ_TYPE_ARRAY) type_name = "Array";
        else if (h->type == OBJ_TYPE_STRING) type_name = "String";
        
        printf("  [%p] %s sz=%u m=%d\n", (void*)(h+1), type_name, h->size, h->marked);
        ptr += h->size;
        obj_count++;
    }
    printf("==================\n");
}

void heap_validate(JVM* jvm) {
    (void)jvm;
    size_t computed_allocated = 0;
    size_t object_count = 0;
    uint8_t* ptr = heap.start;
    
    while (ptr < heap.current) {
        GCObjectHeader* h = (GCObjectHeader*)ptr;
        if (h->size == 0 || h->size > heap.size || ptr + h->size > heap.end) {
            ERROR_LOG("Corruption at %p", (void*)ptr);
            return;
        }
        
        /* ИСПРАВЛЕНО: Считаем все НЕ свободные объекты, а не только marked/pinned.
         * После GC marked сбрасывается в 0, поэтому проверка marked/pinned
         * давала бы всегда 0. Правильная проверка: type != OBJ_TYPE_FREE.
         */
        if (h->type != OBJ_TYPE_FREE) {
            computed_allocated += h->size;
            object_count++;
        }
        ptr += h->size;
    }
    
    if (computed_allocated != heap.allocated) {
        ERROR_LOG("Alloc mismatch: calc=%zu vs stats=%zu (objects=%zu)", 
                  computed_allocated, heap.allocated, object_count);
    }
}