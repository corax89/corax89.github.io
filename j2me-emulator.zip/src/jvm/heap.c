/*
 * J2ME Emulator - Heap and Garbage Collector (Fixed)
 * Mark-Sweep with free list, Coalescing, and 32-bit alignment support
 */
#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For posix_memalign */
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "heap.h"
#include "jvm.h"
#include "opcodes.h"
#include "classfile.h"

/* Выравнивание объектов. 
 * На 32-битных системах double/long требуют выравнивания по 8 байт. 
 * Поэтому используем 8 для совместимости. */
#ifndef OBJECT_ALIGNMENT
#define OBJECT_ALIGNMENT 8
#endif

/* Free list entry for recycled memory */
typedef struct FreeBlock {
    struct FreeBlock* next;
    size_t size;
} FreeBlock;

/* Heap state */
static struct {
    uint8_t* start;
    uint8_t* current;   /* Bump pointer for new allocations */
    uint8_t* end;
    size_t size;
    size_t allocated;   /* Total bytes currently occupied by live objects */
    size_t freed;       /* Total historical freed bytes */
    
    /* Мы не используем linked list heap.objects для обхода GC, 
       так как линейный проход по памяти надежнее. 
       Но можно оставить для статистики. */
    
    FreeBlock* free_list;  /* Free list for recycled memory (sorted by address for coalescing) */
    
    void*** roots;
    size_t root_count;
    size_t root_capacity;
    
    /* GC statistics */
    size_t gc_cycles;
    size_t gc_total_freed;
} heap;

/* Forward declarations */
static void gc_mark_object(void* ptr);
static void* try_alloc_from_free_list(size_t total_size);

/* Проверка, является ли указатель частью кучи */
static inline bool is_heap_ptr(void* ptr) {
    return ptr >= (void*)heap.start && ptr < (void*)heap.end;
}

/* Инициализация кучи */
int heap_init(JVM* jvm, size_t initial_size, size_t max_size) {
    (void)jvm; (void)max_size;
    
    /* Выравниваем начальный адрес кучи */
#if defined(_WIN32) || defined(_WIN64)
    /* Windows: использование _aligned_malloc */
    heap.start = (uint8_t*)_aligned_malloc(initial_size, OBJECT_ALIGNMENT);
    if (!heap.start) return JNI_ERR;
#elif defined(__APPLE__) || defined(__linux__) || defined(__unix__)
    /* Unix-like: использование posix_memalign */
    if (posix_memalign((void**)&heap.start, OBJECT_ALIGNMENT, initial_size) != 0) {
        /* Пробуем обычный malloc как запасной вариант */
        heap.start = (uint8_t*)malloc(initial_size);
        if (!heap.start) return JNI_ERR;
        
        /* Проверяем выравнивание */
        if (((uintptr_t)heap.start & (OBJECT_ALIGNMENT - 1)) != 0) {
            fprintf(stderr, "[WARN] malloc returned unaligned address, performance may suffer\n");
        }
    }
#else
    /* Для других систем используем malloc и надеемся на лучшее */
    heap.start = (uint8_t*)malloc(initial_size);
    if (!heap.start) return JNI_ERR;
    
    /* Проверяем выравнивание */
    if (((uintptr_t)heap.start & (OBJECT_ALIGNMENT - 1)) != 0) {
        fprintf(stderr, "[WARN] malloc returned unaligned address, performance may suffer\n");
    }
#endif
    
    heap.current = heap.start;
    heap.end = heap.start + initial_size;
    heap.size = initial_size;
    heap.allocated = 0;
    heap.freed = 0;
    heap.free_list = NULL;
    heap.gc_cycles = 0;
    heap.gc_total_freed = 0;
    
    heap.roots = (void***)malloc(1024 * sizeof(void**));
    if (!heap.roots) {
        free(heap.start);
        return JNI_ERR;
    }
    heap.root_capacity = 1024;
    heap.root_count = 0;
    
    return JNI_OK;
}

/* Уничтожение кучи */
void heap_destroy(JVM* jvm) {
    (void)jvm;
    free(heap.start);
    free(heap.roots);
    heap.start = NULL;
    heap.current = NULL;
    heap.end = NULL;
    heap.free_list = NULL;
}

/* Попытка выделить память из списка свободных блоков (First Fit) */
static void* try_alloc_from_free_list(size_t total_size) {
    FreeBlock** pp = &heap.free_list;
    FreeBlock* prev = NULL;
    
    while (*pp) {
        FreeBlock* block = *pp;
        
        if (block->size >= total_size) {
            /* Найден подходящий блок */
            
            /* Отсоединяем блок из списка */
            if (prev) {
                prev->next = block->next;
            } else {
                heap.free_list = block->next;
            }
            
            /* Если блок намного больше запроса, дробим его */
            if (block->size >= total_size + sizeof(FreeBlock) + OBJECT_ALIGNMENT) {
                FreeBlock* remainder = (FreeBlock*)((uint8_t*)block + total_size);
                remainder->size = block->size - total_size;
                
                /* Вставляем остаток обратно в список (простая вставка в начало для скорости, 
                   но для идеального коалесцинга нужно было бы по адресу) */
                remainder->next = heap.free_list;
                heap.free_list = remainder;
            }
            
            return block;
        }
        
        prev = block;
        pp = &block->next;
    }
    
    return NULL;
}

/* Базовое выделение памяти */
void* heap_alloc(JVM* jvm, size_t size, JavaClass* clazz, ObjectType type) {
    (void)jvm;
    
    /* Выравниваем размер запроса */
    size = (size + OBJECT_ALIGNMENT - 1) & ~(OBJECT_ALIGNMENT - 1);
    
    /* Добавляем размер GC-заголовка */
    size_t total_size = sizeof(GCObjectHeader) + size;
    
    /* 1. Пытаемся найти в Free List */
    GCObjectHeader* header = (GCObjectHeader*)try_alloc_from_free_list(total_size);
    
    if (!header) {
        /* 2. Если нет в Free List, берем из топа кучи (Bump Pointer) */
        if (heap.current + total_size > heap.end) {
            /* Не хватает места в конце кучи. Запускаем GC. */
            gc_collect(jvm);
            
            /* Пробуем снова в Free List после GC */
            header = (GCObjectHeader*)try_alloc_from_free_list(total_size);
            
            if (!header) {
                /* Все еще нет места. Проверяем топ кучи (GC мог освободить место в середине, но не в конце) */
                if (heap.current + total_size > heap.end) {
                    fprintf(stderr, "[GC] Out of memory! Requested: %zu, Available: %zu\n",
                            total_size, (size_t)(heap.end - heap.current));
                    return NULL;
                }
                
                /* Если GC освободил место в конце, используем bump pointer */
                header = (GCObjectHeader*)heap.current;
                heap.current += total_size;
            }
        } else {
            /* Место есть, выделяем */
            header = (GCObjectHeader*)heap.current;
            heap.current += total_size;
        }
    }
    
    heap.allocated += total_size;
    
    /* Инициализация заголовка */
    /* Примечание: next здесь не используется для связывания объектов при GC, 
       так как мы используем линейный проход. Поле зарезервировано. */
    header->next = NULL; 
    header->clazz = clazz;
    header->size = (uint32_t)total_size;
    header->type = (uint8_t)type;
    header->marked = 0;
    header->pinned = 0;
    header->reserved = 0;
    
    /* Возвращаем указатель на пользовательские данные (сразу после заголовка) */
    void* ptr = (void*)(header + 1);
    memset(ptr, 0, size);  /* Zero-initialize */
    
    return ptr;
}

/* Выделение объекта */
JavaObject* heap_alloc_object(JVM* jvm, JavaClass* clazz) {
    if (!clazz) {
        fprintf(stderr, "[HEAP] ERROR: heap_alloc_object called with NULL class\n");
        return NULL;
    }
    
    /* ИСПРАВЛЕНИЕ: clazz->instance_size уже должен включать sizeof(ObjectHeader) + поля.
       Мы не должны добавлять sizeof(ObjectHeader) здесь снова. */
    size_t size = clazz->instance_size;
    
    /* Минимальная защита */
    if (size < sizeof(JavaObject)) {
        size = sizeof(JavaObject);
    }

    /* Выравниваем размер объекта */
    size = (size + OBJECT_ALIGNMENT - 1) & ~(OBJECT_ALIGNMENT - 1);
    
    /* fprintf(stderr, "[HEAP] Allocating object: class=%s, size=%zu\n", clazz->class_name, size); */
    
    JavaObject* obj = (JavaObject*)heap_alloc(jvm, size, clazz, OBJ_TYPE_OBJECT);
    if (obj) {
        /* Инициализируем Java-хедер объекта */
        obj->header.clazz = clazz;
        obj->header.hashcode = (jint)(intptr_t)obj;  /* Identity hash */
        obj->header.gc_mark = 0;
        obj->header.reserved = 0;
    } else {
        fprintf(stderr, "[HEAP] ERROR: heap_alloc failed for class %s\n", 
                clazz->class_name ? clazz->class_name : "unknown");
    }
    
    return obj;
}

/* Выделение массива */
JavaArray* heap_alloc_array(JVM* jvm, uint8_t element_type, jsize length) {
    /* Размер элемента */
    size_t elem_size;
    switch (element_type) {
        case T_BOOLEAN:
        case T_BYTE:    elem_size = 1; break;
        case T_CHAR:
        case T_SHORT:   elem_size = 2; break;
        case T_INT:
        case T_FLOAT:   elem_size = 4; break;
        case T_LONG:
        case T_DOUBLE:  elem_size = 8; break;
        case DESC_OBJECT:
        case DESC_ARRAY: elem_size = sizeof(void*); break;
        default: elem_size = 4; break;
    }
    
    size_t data_size = elem_size * length;
    size_t total_size = sizeof(JavaArray) + data_size;
    
    JavaArray* array = (JavaArray*)heap_alloc(jvm, total_size, NULL, OBJ_TYPE_ARRAY);
    if (!array) return NULL;
    
    /* Поиск класса java/lang/Object или массива. 
       Для упрощения берем первый попавшийся класс, если Object не найден, 
       но корректнее искать по имени. */
    JavaClass* array_class = NULL;
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* c = jvm->class_loader.classes[i];
        if (c->class_name && strcmp(c->class_name, "java/lang/Object") == 0) {
            array_class = c;
            break;
        }
    }
    
    if (!array_class && jvm->class_loader.count > 0) {
        array_class = jvm->class_loader.classes[0]; /* Fallback */
    }
    
    array->header.clazz = array_class;
    array->header.hashcode = (jint)(intptr_t)array;
    array->length = length;
    array->element_type = element_type;
    memset(array->_padding, 0, sizeof(array->_padding));
    
    return array;
}

/* Выделение строки */
JavaString* heap_alloc_string(JVM* jvm, jsize length) {
    size_t data_size = length * sizeof(jchar);
    size_t total_size = sizeof(JavaString) + data_size;
    
    JavaString* str = (JavaString*)heap_alloc(jvm, total_size, NULL, OBJ_TYPE_STRING);
    if (!str) return NULL;
    
    JavaClass* str_class = NULL;
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* c = jvm->class_loader.classes[i];
        if (c->class_name && strcmp(c->class_name, "java/lang/String") == 0) {
            str_class = c;
            break;
        }
    }
    
    str->header.clazz = str_class;
    str->header.hashcode = (jint)(intptr_t)str;
    str->length = length;
    str->hash = 0;
    str->utf8 = NULL;
    
    return str;
}

/* --- Mark and Sweep Implementation --- */

#define GC_MARK_STACK_SIZE 4096

typedef struct {
    void* ptr;
} MarkStackEntry;

static MarkStackEntry gc_mark_stack[GC_MARK_STACK_SIZE];
static int gc_mark_stack_top = 0;

static inline void gc_push_mark(void* ptr) {
    if (ptr && gc_mark_stack_top < GC_MARK_STACK_SIZE) {
        gc_mark_stack[gc_mark_stack_top++].ptr = ptr;
    }
}

static void gc_mark_object(void* ptr) {
    if (!ptr) return;
    if (!is_heap_ptr(ptr)) return;
    
    /* Получаем GC заголовок (он находится перед пользовательскими данными) */
    GCObjectHeader* header = (GCObjectHeader*)ptr - 1;
    
    /* Проверка валидности */
    if (header->size == 0 || header->size > heap.size) {
        return; /* Коррумпированный указатель */
    }
    
    if (header->marked) return; /* Уже помечен */
    
    header->marked = 1;
    
    /* Рекурсивная пометка ссылок */
    switch (header->type) {
        case OBJ_TYPE_OBJECT: {
            JavaObject* obj = (JavaObject*)ptr;
            JavaClass* clazz = obj->header.clazz;
            
            while (clazz) {
                for (int i = 0; i < clazz->fields_count; i++) {
                    JavaField* field = &clazz->fields[i];
                    if (field->descriptor) {
                        char c = field->descriptor[0];
                        if (c == 'L' || c == '[') {
                            void* ref = obj->fields[field->offset].ref;
                            if (ref) gc_push_mark(ref);
                        }
                    }
                }
                clazz = clazz->super_class;
            }
            break;
        }
        
        case OBJ_TYPE_ARRAY: {
            JavaArray* array = (JavaArray*)ptr;
            if (array->element_type == DESC_OBJECT || array->element_type == DESC_ARRAY) {
                void** refs = (void**)((uint8_t*)array + sizeof(JavaArray));
                for (jsize i = 0; i < array->length; i++) {
                    if (refs[i]) gc_push_mark(refs[i]);
                }
            }
            break;
        }
        
        case OBJ_TYPE_CLASS: {
             /* Статические поля классов */
            if (header->clazz && header->clazz->static_fields) {
                JavaClass* clazz = header->clazz;
                for (int i = 0; i < clazz->static_fields_count; i++) {
                    JavaStaticField* sf = &clazz->static_fields[i];
                    if (sf->descriptor && (sf->descriptor[0] == 'L' || sf->descriptor[0] == '[')) {
                        if (sf->value.ref) gc_push_mark(sf->value.ref);
                    }
                }
            }
            break;
        }
            
        case OBJ_TYPE_STRING:
            /* Строковые данные встроены, utf8 кэш освобождается в Sweep */
            break;
    }
}

static void gc_process_mark_stack(void) {
    while (gc_mark_stack_top > 0) {
        void* ptr = gc_mark_stack[--gc_mark_stack_top].ptr;
        gc_mark_object(ptr);
    }
}

/* Запуск сборщика мусора с Линейным Sweep и Коалесцингом */
void gc_collect(JVM* jvm) {
    if (!jvm) return;
    
    size_t start_allocated = heap.allocated;
    gc_mark_stack_top = 0;
    
    /* 1. Mark Phase */
    /* Mark from Roots */
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] && *heap.roots[i]) {
            gc_push_mark(*heap.roots[i]);
        }
    }
    
    /* Mark from Stacks */
    for (int i = 0; i < jvm->thread_count; i++) {
        JavaThread* thread = jvm->threads[i];
        if (!thread) continue;
        
        if (thread->pending_exception) gc_push_mark(thread->pending_exception);
        if (thread->thread_object) gc_push_mark(thread->thread_object);
        
        JavaFrame* frame = thread->current_frame;
        while (frame) {
            for (uint16_t j = 0; j < frame->max_locals; j++) {
                if (frame->locals[j].ref) gc_push_mark(frame->locals[j].ref);
            }
            for (int16_t j = 0; j <= frame->stack_top; j++) {
                if (frame->stack[j].ref) gc_push_mark(frame->stack[j].ref);
            }
            frame = frame->prev;
        }
    }
    
    /* Mark from Statics */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (!clazz || !clazz->static_fields) continue;
        for (int j = 0; j < clazz->static_fields_count; j++) {
            JavaStaticField* sf = &clazz->static_fields[j];
            if (sf->descriptor && (sf->descriptor[0] == 'L' || sf->descriptor[0] == '[')) {
                if (sf->value.ref) gc_push_mark(sf->value.ref);
            }
        }
    }
    
    gc_process_mark_stack();
    
    /* 2. Sweep Phase (Linear Scan + Coalescing) */
    size_t freed_this_cycle = 0;
    size_t objects_freed = 0;
    
    /* Очищаем старый список свободных блоков, чтобы построить новый упорядоченный */
    heap.free_list = NULL; 
    
    uint8_t* scan_ptr = heap.start;
    
    /* Временный список свободных блоков для построения в порядке адреса
       (используем простой подход: добавляем в конец, но т.к. у нас нет tail, 
       будем вставлять так, чтобы список был отсортирован, или просто собираем 
       свободные куски в отдельный список и потом мержим) */
    
    /* Для простоты реализации на C без лишних аллокаций:
       Пройдемся линейно. Свободные блоки будем добавлять в free_list "в конец" 
       эмулируя это вставкой перед головой, если адрес меньше головы (сортировка по возрастанию).
       Это позволит легко слить соседние блоки. */
    
    FreeBlock* sorted_free_list = NULL;
    
    while (scan_ptr < heap.current) {
        GCObjectHeader* header = (GCObjectHeader*)scan_ptr;
        
        /* Защита от порчи памяти в куче */
        if (header->size == 0 || header->size > heap.size || scan_ptr + header->size > heap.end) {
            fprintf(stderr, "[GC] Corruption detected at %p, aborting sweep\n", (void*)scan_ptr);
            break;
        }
        
        if (header->marked || header->pinned) {
            /* Объект жив */
            header->marked = 0; /* Сброс метки */
        } else {
            /* Объект мертв */
            freed_this_cycle += header->size;
            objects_freed++;
            
            /* Очистка строкового кэша */
            if (header->type == OBJ_TYPE_STRING) {
                JavaString* str = (JavaString*)(header + 1);
                if (str->utf8) {
                    free(str->utf8);
                    str->utf8 = NULL;
                }
            }
            
            /* Добавляем в сортированный список свободных блоков */
            FreeBlock* block = (FreeBlock*)header;
            block->size = header->size;
            
            /* Вставка в сортированный список (по возрастанию адреса) */
            FreeBlock** curr = &sorted_free_list;
            while (*curr && (uint8_t*)(*curr) < (uint8_t*)block) {
                curr = &((*curr)->next);
            }
            block->next = *curr;
            *curr = block;
        }
        
        scan_ptr += header->size;
    }
    
    /* 3. Coalescing (Слияние соседних блоков) */
    FreeBlock* fb = sorted_free_list;
    while (fb && fb->next) {
        /* Проверяем, лежит ли следующий блок сразу за текущим */
        if ((uint8_t*)fb + fb->size == (uint8_t*)fb->next) {
            /* Сливаем */
            fb->size += fb->next->size;
            fb->next = fb->next->next;
            /* Не продвигаем fb, так как новый блок может теперь merger'ся со следующим */
        } else {
            fb = fb->next;
        }
    }
    
    heap.free_list = sorted_free_list;
    
    /* Статистика */
    heap.allocated -= freed_this_cycle;
    heap.freed += freed_this_cycle;
    heap.gc_cycles++;
    heap.gc_total_freed += freed_this_cycle;
    
    /* Если мы освободили блок в конце кучи, можем подвинуть current назад (Defragmentation of top) */
    if (heap.free_list) {
        /* Найдем самый большой свободный блок. Если он в конце кучи, уменьшим current. */
        FreeBlock* last = heap.free_list;
        FreeBlock* last_prev = NULL;
        while (last->next) {
            last_prev = last;
            last = last->next;
        }
        
        if ((uint8_t*)last + last->size == heap.current) {
            /* Этот блок в самом конце кучи */
            heap.current = (uint8_t*)last;
            if (last_prev) {
                last_prev->next = NULL;
            } else {
                heap.free_list = NULL;
            }
            /* Память возвращена системе (bump pointer уменьшен) */
        }
    }

    if (freed_this_cycle > 0) {
        fprintf(stderr, "[GC] Cycle %zu: freed %zu bytes (%zu objects), %zu bytes allocated\n",
                heap.gc_cycles, freed_this_cycle, objects_freed, heap.allocated);
    }
}

/* --- Roots and Utilities --- */

void gc_add_root(JVM* jvm, void** root) {
    (void)jvm;
    if (heap.root_count >= heap.root_capacity) {
        heap.root_capacity *= 2;
        heap.roots = (void***)realloc(heap.roots, heap.root_capacity * sizeof(void**));
    }
    heap.roots[heap.root_count++] = root;
}

void gc_remove_root(JVM* jvm, void** root) {
    (void)jvm;
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] == root) {
            heap.roots[i] = heap.roots[--heap.root_count];
            return;
        }
    }
}

void gc_pin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object || !is_heap_ptr(object)) return;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 1;
}

void gc_unpin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object || !is_heap_ptr(object)) return;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 0;
}

HeapStats heap_get_stats(JVM* jvm) {
    HeapStats stats = {0};
    (void)jvm;
    stats.total_size = heap.size;
    stats.used_size = heap.allocated;
    stats.free_size = heap.size - heap.allocated;
    stats.object_count = 0; /* Сложно считать точно без счетчика при аллокации, можно добавить */
    stats.gc_cycles = heap.gc_cycles;
    stats.gc_time_ms = 0;
    return stats;
}

/* Объектные утилиты */

JavaClass* object_get_class(void* object) {
    if (!object || !is_heap_ptr(object)) return NULL;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->clazz;
}

size_t object_get_size(void* object) {
    if (!object || !is_heap_ptr(object)) return 0;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->size - sizeof(GCObjectHeader);
}

jint object_hash_code(void* object) {
    if (!object) return 0;
    JavaObject* obj = (JavaObject*)object;
    return obj->header.hashcode;
}

bool object_is_array(void* object) {
    if (!object || !is_heap_ptr(object)) return false;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_ARRAY;
}

bool object_is_string(void* object) {
    if (!object || !is_heap_ptr(object)) return false;
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_STRING;
}

bool object_instance_of(void* object, JavaClass* clazz) {
    if (!object || !clazz) return false;
    JavaClass* obj_class = object_get_class(object);
    if (!obj_class) return false;
    
    while (obj_class) {
        if (obj_class == clazz) return true;
        /* Простой интерфейс-чек, можно улучшить */
        for (int i = 0; i < obj_class->interfaces_count; i++) {
            const char* iface_name = classfile_get_class_name(obj_class, obj_class->interfaces[i]);
            if (iface_name && clazz->class_name && strcmp(iface_name, clazz->class_name) == 0) {
                return true;
            }
        }
        obj_class = obj_class->super_class;
    }
    return false;
}

/* Массивы */

jsize array_length(JavaArray* array) {
    return array ? array->length : 0;
}

uint8_t array_element_type(JavaArray* array) {
    return array ? array->element_type : 0;
}

static inline void* array_data_ptr(JavaArray* array) {
    return (void*)((uint8_t*)array + sizeof(JavaArray));
}

JavaValue array_get(JavaArray* array, jsize index) {
    JavaValue v = { .raw = 0 };
    if (!array || index < 0 || index >= array->length) return v;
    
    void* data = array_data_ptr(array);
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:    v.i = ((uint8_t*)data)[index]; break;
        case T_CHAR:    v.i = ((jchar*)data)[index]; break;
        case T_SHORT:   v.i = ((jshort*)data)[index]; break;
        case T_INT:     v.i = ((jint*)data)[index]; break;
        case T_LONG:    v.j = ((jlong*)data)[index]; break;
        case T_FLOAT:   v.f = ((jfloat*)data)[index]; break;
        case T_DOUBLE:  v.d = ((jdouble*)data)[index]; break;
        case DESC_OBJECT:
        case DESC_ARRAY: v.ref = ((void**)data)[index]; break;
    }
    return v;
}

void array_set(JavaArray* array, jsize index, JavaValue value) {
    if (!array || index < 0 || index >= array->length) return;
    
    void* data = array_data_ptr(array);
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:    ((uint8_t*)data)[index] = (uint8_t)value.i; break;
        case T_CHAR:    ((jchar*)data)[index] = (jchar)value.i; break;
        case T_SHORT:   ((jshort*)data)[index] = (jshort)value.i; break;
        case T_INT:     ((jint*)data)[index] = value.i; break;
        case T_LONG:    ((jlong*)data)[index] = value.j; break;
        case T_FLOAT:   ((jfloat*)data)[index] = value.f; break;
        case T_DOUBLE:  ((jdouble*)data)[index] = value.d; break;
        case DESC_OBJECT:
        case DESC_ARRAY: ((void**)data)[index] = value.ref; break;
    }
}

void* array_get_ref(JavaArray* array, jsize index) {
    if (!array || index < 0 || index >= array->length) return NULL;
    return ((void**)array_data_ptr(array))[index];
}

void array_set_ref(JavaArray* array, jsize index, void* ref) {
    if (!array || index < 0 || index >= array->length) return;
    ((void**)array_data_ptr(array))[index] = ref;
}

/* Строки */

jsize string_length(JavaString* str) {
    return str ? str->length : 0;
}

const jchar* string_chars(JavaString* str) {
    if (!str) return NULL;
    return (const jchar*)((uint8_t*)str + sizeof(JavaString));
}

const char* string_utf8(JVM* jvm, JavaString* str) {
    (void)jvm;
    if (!str) return NULL;
    if (str->utf8) return str->utf8;
    
    const jchar* chars = string_chars(str);
    char* result = (char*)malloc(str->length * 3 + 1);
    if (!result) return NULL;
    
    char* p = result;
    for (jsize i = 0; i < str->length; i++) {
        jchar c = chars[i];
        if (c < 0x80) {
            *p++ = (char)c;
        } else if (c < 0x800) {
            *p++ = (char)(0xC0 | (c >> 6));
            *p++ = (char)(0x80 | (c & 0x3F));
        } else {
            *p++ = (char)(0xE0 | (c >> 12));
            *p++ = (char)(0x80 | ((c >> 6) & 0x3F));
            *p++ = (char)(0x80 | (c & 0x3F));
        }
    }
    *p = '\0';
    
    str->utf8 = result;
    return result;
}

bool string_equals(JavaString* a, JavaString* b) {
    if (a == b) return true;
    if (!a || !b) return false;
    if (a->length != b->length) return false;
    return memcmp(string_chars(a), string_chars(b), a->length * sizeof(jchar)) == 0;
}

jint string_hash(JavaString* str) {
    if (!str) return 0;
    if (str->hash) return str->hash;
    
    const jchar* chars = string_chars(str);
    jint hash = 0;
    for (jsize i = 0; i < str->length; i++) {
        hash = 31 * hash + chars[i];
    }
    str->hash = hash;
    return hash;
}

void heap_dump(JVM* jvm) {
    (void)jvm;
    printf("=== Heap Dump ===\n");
    printf("Total: %zu bytes\n", heap.size);
    printf("Used: %zu bytes\n", heap.allocated);
    printf("Free List Blocks: ");
    
    int count = 0;
    FreeBlock* fb = heap.free_list;
    while(fb && count < 10) {
        printf("[%p:%zu] ", (void*)fb, fb->size);
        fb = fb->next;
        count++;
    }
    printf("\n");
    
    printf("Live objects scan:\n");
    uint8_t* ptr = heap.start;
    int obj_count = 0;
    while (ptr < heap.current && obj_count < 20) {
        GCObjectHeader* h = (GCObjectHeader*)ptr;
        const char* type_name = "?";
        if (h->type == OBJ_TYPE_OBJECT && h->clazz) type_name = h->clazz->class_name;
        else if (h->type == OBJ_TYPE_ARRAY) type_name = "Array";
        else if (h->type == OBJ_TYPE_STRING) type_name = "String";
        
        printf("  [%p] %s sz=%u m=%d\n", (void*)(h+1), type_name, h->size, h->marked);
        ptr += h->size;
        obj_count++;
    }
    printf("==================\n");
}

void heap_validate(JVM* jvm) {
    (void)jvm;
    size_t computed_allocated = 0;
    uint8_t* ptr = heap.start;
    
    while (ptr < heap.current) {
        GCObjectHeader* h = (GCObjectHeader*)ptr;
        if (h->size == 0 || h->size > heap.size || ptr + h->size > heap.end) {
            fprintf(stderr, "[VALIDATE] Corruption at %p\n", (void*)ptr);
            return;
        }
        
        if (h->marked || h->pinned) {
            computed_allocated += h->size;
        }
        ptr += h->size;
    }
    
    if (computed_allocated != heap.allocated) {
        fprintf(stderr, "[VALIDATE] Alloc mismatch: calc=%zu vs stats=%zu\n", computed_allocated, heap.allocated);
    }
}