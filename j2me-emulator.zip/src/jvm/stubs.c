/*
 * J2ME Emulator - Built-in Stub Classes
 * Generates minimal stub classes for J2ME API
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup - only on POSIX systems */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jvm.h"
#include "classfile.h"
#include "native.h"
#include "opcodes.h"  /* For ACC_* constants */

/* Forward declarations */
static JavaClass* create_stub_class(JVM* jvm, const char* name, const char* super_name, uint16_t access_flags);

/* List of required J2ME stub classes */
static const struct {
    const char* name;
    const char* super;
    uint16_t flags;
} stub_classes[] = {
    /* Core Java classes */
    { "java/lang/Object", NULL, ACC_PUBLIC | ACC_ABSTRACT },
    { "java/lang/Class", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/String", "java/lang/Object", ACC_PUBLIC | ACC_FINAL },
    { "java/lang/StringBuilder", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/StringBuffer", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Exception", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/RuntimeException", "java/lang/Exception", ACC_PUBLIC },
    { "java/lang/Error", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Throwable", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/NullPointerException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/ClassCastException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/ArrayIndexOutOfBoundsException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IndexOutOfBoundsException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IllegalArgumentException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IllegalStateException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/NumberFormatException", "java/lang/IllegalArgumentException", ACC_PUBLIC },
    { "java/lang/ClassNotFoundException", "java/lang/Exception", ACC_PUBLIC },
    { "java/lang/OutOfMemoryError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/VirtualMachineError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/Integer", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Long", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Float", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Double", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Boolean", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Math", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/System", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Runtime", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Thread", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Runnable", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/Random", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Vector", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Hashtable", "java/lang/Object", ACC_PUBLIC },
    
    /* J2ME MIDlet API */
    { "javax/microedition/midlet/MIDlet", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/midlet/MIDletStateChangeException", "java/lang/Exception", ACC_PUBLIC },
    
    /* J2ME LCDUI API */
    { "javax/microedition/lcdui/Display", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Displayable", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Screen", "javax/microedition/lcdui/Displayable", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Canvas", "javax/microedition/lcdui/Displayable", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/GameCanvas", "javax/microedition/lcdui/Canvas", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Graphics", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Image", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Font", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Command", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/CommandListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/lcdui/Item", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Form", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/TextBox", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/List", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/Alert", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/Ticker", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Gauge", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/StringItem", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/TextField", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/ChoiceGroup", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/ImageItem", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/Spacer", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/DateField", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    
    /* J2ME RMS API */
    { "javax/microedition/rms/RecordStore", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreException", "java/lang/Exception", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreNotFoundException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreFullException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    
    /* J2ME Media API */
    { "javax/microedition/media/Manager", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/media/Player", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/Control", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/control/VolumeControl", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    { NULL, NULL, 0 }
};

/* Helper to ensure constant pool has space - only for stub classes during creation */
static void ensure_cp_capacity(JavaClass* clazz, size_t needed) {
    if (!clazz->constant_pool) {
        clazz->constant_pool_capacity = 64;
        clazz->constant_pool = (ConstantPoolEntry*)calloc(clazz->constant_pool_capacity, sizeof(ConstantPoolEntry));
        clazz->constant_pool_count = 1;  /* Index 0 unused */
    }
    
    if (clazz->constant_pool_count + needed >= clazz->constant_pool_capacity) {
        /* For stub classes, pre-allocate enough space */
        size_t new_cap = clazz->constant_pool_capacity + needed + 32;
        ConstantPoolEntry* new_pool = (ConstantPoolEntry*)calloc(new_cap, sizeof(ConstantPoolEntry));
        if (!new_pool) return;  /* Out of memory */
        
        /* Copy old entries */
        memcpy(new_pool, clazz->constant_pool, 
               clazz->constant_pool_count * sizeof(ConstantPoolEntry));
        
        free(clazz->constant_pool);
        clazz->constant_pool = new_pool;
        clazz->constant_pool_capacity = new_cap;
    }
}

/* Create a minimal constant pool entry for UTF8 */
static uint16_t add_utf8(JavaClass* clazz, const char* str) {
    if (!str) return 0;
    
    size_t len = strlen(str);
    
    /* Check if already exists */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        if (clazz->constant_pool[i].tag == CONSTANT_Utf8 &&
            clazz->constant_pool[i].info.utf8.length == len &&
            clazz->constant_pool[i].info.utf8.bytes &&
            memcmp(clazz->constant_pool[i].info.utf8.bytes, str, len) == 0) {
            return i;
        }
    }
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Utf8;
    clazz->constant_pool[index].info.utf8.length = (uint16_t)len;
    clazz->constant_pool[index].info.utf8.bytes = strdup(str);
    
    return index;
}

/* Create a minimal constant pool entry for Class */
static uint16_t add_class_ref(JavaClass* clazz, const char* name) {
    if (!name) return 0;
    
    uint16_t name_index = add_utf8(clazz, name);
    
    /* Check if already exists */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        if (clazz->constant_pool[i].tag == CONSTANT_Class &&
            clazz->constant_pool[i].info.class_info.name_index == name_index) {
            return i;
        }
    }
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Class;
    clazz->constant_pool[index].info.class_info.name_index = name_index;
    
    return index;
}

/* Create a NameAndType constant */
static uint16_t add_name_and_type(JavaClass* clazz, const char* name, const char* descriptor) {
    if (!name || !descriptor) return 0;
    
    uint16_t name_index = add_utf8(clazz, name);
    uint16_t descriptor_index = add_utf8(clazz, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_NameAndType;
    clazz->constant_pool[index].info.name_and_type.name_index = name_index;
    clazz->constant_pool[index].info.name_and_type.descriptor_index = descriptor_index;
    
    return index;
}

/* Create a Methodref constant */
static uint16_t add_method_ref(JavaClass* clazz, const char* class_name,
                               const char* name, const char* descriptor) {
    if (!class_name || !name || !descriptor) return 0;
    
    uint16_t class_index = add_class_ref(clazz, class_name);
    uint16_t name_and_type_index = add_name_and_type(clazz, name, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Methodref;
    clazz->constant_pool[index].info.ref_info.class_index = class_index;
    clazz->constant_pool[index].info.ref_info.name_and_type_index = name_and_type_index;
    
    return index;
}

/* Ensure methods array has space */
static void ensure_methods_capacity(JavaClass* clazz) {
    if (!clazz->methods) {
        clazz->methods_capacity = 8;
        clazz->methods = (JavaMethod*)calloc(clazz->methods_capacity, sizeof(JavaMethod));
        clazz->methods_count = 0;
    }
    
    if (clazz->methods_count >= clazz->methods_capacity) {
        int new_cap = clazz->methods_capacity * 2;
        JavaMethod* new_methods = (JavaMethod*)calloc(new_cap, sizeof(JavaMethod));
        if (!new_methods) return;  /* Out of memory */
        
        /* Copy old entries */
        memcpy(new_methods, clazz->methods, 
               clazz->methods_count * sizeof(JavaMethod));
        
        free(clazz->methods);
        clazz->methods = new_methods;
        clazz->methods_capacity = new_cap;
    }
}

/* Create a stub method - returns index in methods array */
static int create_stub_method(JavaClass* clazz, const char* name,
                              const char* descriptor, uint16_t access_flags,
                              const uint8_t* code, uint32_t code_len) {
    if (!name || !descriptor) return -1;
    
    ensure_methods_capacity(clazz);
    
    int idx = clazz->methods_count++;
    JavaMethod* method = &clazz->methods[idx];
    
    memset(method, 0, sizeof(JavaMethod));
    
    method->name = strdup(name);
    method->descriptor = strdup(descriptor);
    method->name_index = add_utf8(clazz, name);
    method->descriptor_index = add_utf8(clazz, descriptor);
    method->access_flags = access_flags;
    method->attributes_count = 0;
    method->clazz = clazz;
    
    /* Create Code attribute if not abstract/native and code provided */
    if (!(access_flags & (ACC_ABSTRACT | ACC_NATIVE))) {
        if (code && code_len > 0) {
            method->code.max_stack = 2;
            method->code.max_locals = 1;
            method->code.code_length = code_len;
            method->code.code = (uint8_t*)malloc(code_len);
            if (method->code.code) {
                memcpy(method->code.code, code, code_len);
            }
        } else {
            /* Minimal code: just return */
            method->code.max_stack = 1;
            method->code.max_locals = 1;
            method->code.code_length = 1;
            method->code.code = (uint8_t*)malloc(1);
            if (method->code.code) {
                method->code.code[0] = 0xB1; /* return */
            }
        }
    }
    
    return idx;
}

/* Create a stub class */
static JavaClass* create_stub_class(JVM* jvm, const char* name, const char* super_name, uint16_t access_flags) {
    if (!name) return NULL;
    
    JavaClass* clazz = (JavaClass*)calloc(1, sizeof(JavaClass));
    if (!clazz) return NULL;
    
    clazz->class_name = strdup(name);
    clazz->access_flags = access_flags;
    clazz->major_version = 47; /* JDK 1.3 */
    clazz->minor_version = 0;
    clazz->magic = 0xCAFEBABE;
    
    /* Initialize constant pool with space check */
    ensure_cp_capacity(clazz, 4);  /* Pre-allocate space for basic entries */
    
    /* Add this class */
    clazz->this_class = add_class_ref(clazz, name);
    
    /* Add super class */
    if (super_name) {
        clazz->super_class_index = add_class_ref(clazz, super_name);
        clazz->super_class_name = strdup(super_name);
    }
    
    /* Allocate methods array */
    ensure_methods_capacity(clazz);
    
    /* Add default constructor for non-abstract, non-interface classes */
    if (!(access_flags & (ACC_ABSTRACT | ACC_INTERFACE))) {
        /* Create default constructor: aload_0, invokespecial super.<init>, return */
        const char* super = super_name ? super_name : "java/lang/Object";
        uint16_t super_init_ref = add_method_ref(clazz, super, "<init>", "()V");
        
        uint8_t init_code[5];
        init_code[0] = 0x2A; /* aload_0 */
        init_code[1] = 0xB7; /* invokespecial */
        init_code[2] = (super_init_ref >> 8) & 0xFF;
        init_code[3] = super_init_ref & 0xFF;
        init_code[4] = 0xB1; /* return */
        
        create_stub_method(clazz, "<init>", "()V", ACC_PUBLIC, init_code, 5);
    }
    
    /* Mark as stub */
    clazz->is_stub = true;
    
    return clazz;
}

/* Initialize built-in stub classes */
int init_stub_classes(JVM* jvm) {
    if (!jvm) return 0;
    
    int count = 0;
    
    /* First pass: create all stub classes */
    for (int i = 0; stub_classes[i].name != NULL; i++) {
        /* Check if already loaded */
        bool found = false;
        for (size_t j = 0; j < jvm->class_loader.count; j++) {
            if (jvm->class_loader.classes[j]->class_name &&
                strcmp(jvm->class_loader.classes[j]->class_name, stub_classes[i].name) == 0) {
                found = true;
                break;
            }
        }
        
        if (found) continue;
        
        JavaClass* stub = create_stub_class(jvm, stub_classes[i].name,
                                           stub_classes[i].super, stub_classes[i].flags);
        if (!stub) {
            fprintf(stderr, "[STUB] Failed to create stub class: %s\n", stub_classes[i].name);
            continue;
        }
        
        /* Ensure class_loader has capacity */
        if (jvm->class_loader.count >= jvm->class_loader.capacity) {
            size_t new_cap = jvm->class_loader.capacity ? jvm->class_loader.capacity * 2 : 32;
            jvm->class_loader.classes = (JavaClass**)realloc(jvm->class_loader.classes,
                                   new_cap * sizeof(JavaClass*));
            if (jvm->class_loader.classes) {
                jvm->class_loader.capacity = new_cap;
            } else {
                free(stub);
                continue;
            }
        }
        
        jvm->class_loader.classes[jvm->class_loader.count++] = stub;
        count++;
        
        if (jvm->config.verbose_class) {
            printf("[STUB] Created stub class: %s\n", stub_classes[i].name);
        }
    }
    
    /* Second pass: resolve super_class references for all stub classes */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
            /* Find super class in loaded classes */
            for (size_t j = 0; j < jvm->class_loader.count; j++) {
                if (jvm->class_loader.classes[j]->class_name &&
                    strcmp(jvm->class_loader.classes[j]->class_name, clazz->super_class_name) == 0) {
                    clazz->super_class = jvm->class_loader.classes[j];
                    if (jvm->config.verbose_class) {
                        fprintf(stderr, "[STUB] Resolved %s -> super: %s\n", 
                                clazz->class_name, clazz->super_class->class_name);
                    }
                    break;
                }
            }
        }
    }
    
    /* Third pass: add fields to specific stub classes */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        
        /* java.util.Random needs a seed field (long = 64-bit = 2 slots) */
        if (clazz->class_name && strcmp(clazz->class_name, "java/util/Random") == 0) {
            /* Allocate fields array */
            clazz->fields_count = 1;  /* One field: seed (long) */
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("seed");
                clazz->fields[0].descriptor = strdup("J");  /* long */
                clazz->fields[0].name_index = add_utf8(clazz, "seed");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot for long */
            }
            fprintf(stderr, "[STUB] Added seed field to java/util/Random\n");
        }
        
        /* java.lang.StringBuffer needs buffer and length fields */
        if (clazz->class_name && strcmp(clazz->class_name, "java/lang/StringBuffer") == 0) {
            /* Allocate fields array: [0] = buffer pointer, [1] = length */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buffer pointer (stored as reference) */
                clazz->fields[0].name = strdup("buffer");
                clazz->fields[0].descriptor = strdup("Ljava/lang/Object;");
                clazz->fields[0].name_index = add_utf8(clazz, "buffer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/Object;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: length (int) */
                clazz->fields[1].name = strdup("count");
                clazz->fields[1].descriptor = strdup("I");  /* int */
                clazz->fields[1].name_index = add_utf8(clazz, "count");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two JavaValue slots */
            }
            fprintf(stderr, "[STUB] Added buffer/count fields to java/lang/StringBuffer\n");
        }
        
        /* javax.microedition.lcdui.Image needs native pointer field */
        if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Image") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added nativePeer field to javax/microedition/lcdui/Image\n");
        }
        
        /* javax.microedition.lcdui.Graphics needs native pointer field */
        if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Graphics") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added nativePeer field to javax/microedition/lcdui/Graphics\n");
        }
        
        /* javax.microedition.lcdui.Font needs native pointer field */
        if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Font") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added nativePeer field to javax/microedition/lcdui/Font\n");
        }
        
        /* java.lang.Thread needs target field for Runnable */
        if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Thread") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: target (Runnable) */
                clazz->fields[0].name = strdup("target");
                clazz->fields[0].descriptor = strdup("Ljava/lang/Runnable;");
                clazz->fields[0].name_index = add_utf8(clazz, "target");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/Runnable;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added target field to java/lang/Thread\n");
        }
    }
    
    return count;
}

/* Get or create a stub class by name */
JavaClass* get_or_create_stub_class(JVM* jvm, const char* class_name) {
    if (!class_name || !jvm) return NULL;
    
    /* Check if already loaded */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        if (jvm->class_loader.classes[i]->class_name &&
            strcmp(jvm->class_loader.classes[i]->class_name, class_name) == 0) {
            return jvm->class_loader.classes[i];
        }
    }
    
    /* Determine super class based on class name */
    const char* super_name = "java/lang/Object";  /* Default */
    
    /* MIDP LCDUI hierarchy */
    if (strcmp(class_name, "javax/microedition/lcdui/game/GameCanvas") == 0) {
        super_name = "javax/microedition/lcdui/Canvas";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Canvas") == 0) {
        super_name = "javax/microedition/lcdui/Displayable";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Displayable") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Screen") == 0) {
        super_name = "javax/microedition/lcdui/Displayable";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Form") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/TextBox") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/List") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Alert") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Item") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/StringItem") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/TextField") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/ImageItem") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/ChoiceGroup") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/Gauge") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/Spacer") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/DateField") == 0) {
        super_name = "javax/microedition/lcdui/Item";
    }
    /* MIDP Media */
    else if (strcmp(class_name, "javax/microedition/media/Player") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/media/Control") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/media/control/VolumeControl") == 0) {
        super_name = "javax/microedition/media/Control";
    }
    /* RMS */
    else if (strcmp(class_name, "javax/microedition/rms/RecordStoreException") == 0) {
        super_name = "java/lang/Exception";
    } else if (strcmp(class_name, "javax/microedition/rms/RecordStoreNotFoundException") == 0 ||
               strcmp(class_name, "javax/microedition/rms/RecordStoreFullException") == 0) {
        super_name = "javax/microedition/rms/RecordStoreException";
    }
    /* Exceptions */
    else if (strcmp(class_name, "javax/microedition/midlet/MIDletStateChangeException") == 0) {
        super_name = "java/lang/Exception";
    }
    
    /* Create stub class with proper super class */
    JavaClass* stub = create_stub_class(jvm, class_name, super_name, ACC_PUBLIC);
    if (!stub) return NULL;
    
    /* Ensure class_loader has capacity */
    if (jvm->class_loader.count >= jvm->class_loader.capacity) {
        size_t new_cap = jvm->class_loader.capacity ? jvm->class_loader.capacity * 2 : 32;
        jvm->class_loader.classes = (JavaClass**)realloc(jvm->class_loader.classes,
                               new_cap * sizeof(JavaClass*));
        if (!jvm->class_loader.classes) {
            free(stub);
            return NULL;
        }
        jvm->class_loader.capacity = new_cap;
    }
    
    jvm->class_loader.classes[jvm->class_loader.count++] = stub;
    
    /* Resolve super_class reference */
    if (stub->super_class == NULL && stub->super_class_name != NULL) {
        /* Try to find super class in loaded classes */
        for (size_t j = 0; j < jvm->class_loader.count; j++) {
            if (jvm->class_loader.classes[j]->class_name &&
                strcmp(jvm->class_loader.classes[j]->class_name, stub->super_class_name) == 0) {
                stub->super_class = jvm->class_loader.classes[j];
                break;
            }
        }
        /* If not found, create it recursively */
        if (stub->super_class == NULL && strcmp(stub->super_class_name, "java/lang/Object") != 0) {
            stub->super_class = get_or_create_stub_class(jvm, stub->super_class_name);
        }
    }
    
    if (jvm->config.verbose_class) {
        printf("[STUB] Auto-created stub class: %s (super: %s)\n", class_name, super_name);
    }
    
    return stub;
}
