/*
 * J2ME Emulator - Built-in Stub Classes
 * Generates minimal stub classes for J2ME API
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup - only on POSIX systems */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jvm.h"
#include "classfile.h"
#include "native.h"
#include "opcodes.h"  /* For ACC_* constants */

/* Forward declarations */
static JavaClass* create_stub_class(JVM* jvm, const char* name, const char* super_name, uint16_t access_flags);

/* List of required J2ME stub classes */
static const struct {
    const char* name;
    const char* super;
    uint16_t flags;
} stub_classes[] = {
    /* Core Java classes */
    /* FIX: Object must be concrete (not abstract) to have a constructor */
    { "java/lang/Object", NULL, ACC_PUBLIC },
    { "java/lang/Class", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/String", "java/lang/Object", ACC_PUBLIC | ACC_FINAL },
    { "java/lang/StringBuilder", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/StringBuffer", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Exception", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/RuntimeException", "java/lang/Exception", ACC_PUBLIC },
    { "java/lang/Error", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Throwable", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/NullPointerException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/ClassCastException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/ArrayIndexOutOfBoundsException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IndexOutOfBoundsException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IllegalArgumentException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/IllegalStateException", "java/lang/RuntimeException", ACC_PUBLIC },
    { "java/lang/NumberFormatException", "java/lang/IllegalArgumentException", ACC_PUBLIC },
    { "java/lang/ClassNotFoundException", "java/lang/Exception", ACC_PUBLIC },
    { "java/lang/OutOfMemoryError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/VirtualMachineError", "java/lang/Error", ACC_PUBLIC },
    { "java/lang/InternalError", "java/lang/VirtualMachineError", ACC_PUBLIC },
    { "java/lang/Integer", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Long", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Float", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Double", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Boolean", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Math", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/System", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Runtime", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Thread", "java/lang/Object", ACC_PUBLIC },
    { "java/lang/Runnable", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/lang/Cloneable", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/Random", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Vector", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Hashtable", "java/lang/Object", ACC_PUBLIC },
    { "java/util/Enumeration", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "java/util/Timer", "java/lang/Object", ACC_PUBLIC },
    { "java/util/TimerTask", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    
    /* I/O classes */
    { "java/io/InputStream", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/io/OutputStream", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "java/io/ByteArrayInputStream", "java/io/InputStream", ACC_PUBLIC },
    { "java/io/ByteArrayOutputStream", "java/io/OutputStream", ACC_PUBLIC },
    { "java/io/DataInputStream", "java/io/InputStream", ACC_PUBLIC },
    { "java/io/DataOutputStream", "java/io/OutputStream", ACC_PUBLIC },
    { "java/io/IOException", "java/lang/Exception", ACC_PUBLIC },
    { "java/io/PrintStream", "java/io/OutputStream", ACC_PUBLIC },
    
    /* J2ME MIDlet API */
    { "javax/microedition/midlet/MIDlet", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/midlet/MIDletStateChangeException", "java/lang/Exception", ACC_PUBLIC },
    
    /* J2ME LCDUI API */
    { "javax/microedition/lcdui/Display", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Displayable", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Screen", "javax/microedition/lcdui/Displayable", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Canvas", "javax/microedition/lcdui/Displayable", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/game/GameCanvas", "javax/microedition/lcdui/Canvas", ACC_PUBLIC },
    { "javax/microedition/lcdui/Graphics", "java/lang/Object", ACC_PUBLIC }, 
    { "javax/microedition/lcdui/Image", "java/lang/Object", ACC_PUBLIC | ACC_FINAL },
    { "javax/microedition/lcdui/Font", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Command", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/CommandListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/lcdui/Item", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "javax/microedition/lcdui/Form", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/TextBox", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/List", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/Alert", "javax/microedition/lcdui/Screen", ACC_PUBLIC },
    { "javax/microedition/lcdui/AlertType", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Ticker", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/lcdui/Gauge", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/StringItem", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/TextField", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/ChoiceGroup", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/ImageItem", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/Spacer", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    { "javax/microedition/lcdui/DateField", "javax/microedition/lcdui/Item", ACC_PUBLIC },
    
    /* J2ME RMS API */
    { "javax/microedition/rms/RecordStore", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreException", "java/lang/Exception", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreNotFoundException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/RecordStoreFullException", "javax/microedition/rms/RecordStoreException", ACC_PUBLIC },
    { "javax/microedition/rms/RecordListener", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* J2ME Media API */
    { "javax/microedition/media/Manager", "java/lang/Object", ACC_PUBLIC },
    { "javax/microedition/media/Player", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/Control", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    { "javax/microedition/media/control/VolumeControl", "java/lang/Object", ACC_PUBLIC | ACC_INTERFACE },
    
    /* Nokia UI/Sound API */
    { "com/nokia/mid/ui/FullCanvas", "java/lang/Object", ACC_PUBLIC | ACC_ABSTRACT },
    { "com/nokia/mid/sound/Sound", "java/lang/Object", ACC_PUBLIC },
    
    { NULL, NULL, 0 }
};

/* Helper to ensure constant pool has space - only for stub classes during creation */
static void ensure_cp_capacity(JavaClass* clazz, size_t needed) {
    if (!clazz->constant_pool) {
        clazz->constant_pool_capacity = 64;
        clazz->constant_pool = (ConstantPoolEntry*)calloc(clazz->constant_pool_capacity, sizeof(ConstantPoolEntry));
        clazz->constant_pool_count = 1;  /* Index 0 unused */
    }
    
    if (clazz->constant_pool_count + needed >= clazz->constant_pool_capacity) {
        /* For stub classes, pre-allocate enough space */
        size_t new_cap = clazz->constant_pool_capacity + needed + 32;
        ConstantPoolEntry* new_pool = (ConstantPoolEntry*)calloc(new_cap, sizeof(ConstantPoolEntry));
        if (!new_pool) return;  /* Out of memory */
        
        /* Copy old entries */
        memcpy(new_pool, clazz->constant_pool, 
               clazz->constant_pool_count * sizeof(ConstantPoolEntry));
        
        free(clazz->constant_pool);
        clazz->constant_pool = new_pool;
        clazz->constant_pool_capacity = new_cap;
    }
}

/* Create a minimal constant pool entry for UTF8 */
static uint16_t add_utf8(JavaClass* clazz, const char* str) {
    if (!str) return 0;
    
    size_t len = strlen(str);
    
    /* Check if already exists */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        if (clazz->constant_pool[i].tag == CONSTANT_Utf8 &&
            clazz->constant_pool[i].info.utf8.length == len &&
            clazz->constant_pool[i].info.utf8.bytes &&
            memcmp(clazz->constant_pool[i].info.utf8.bytes, str, len) == 0) {
            return i;
        }
    }
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Utf8;
    clazz->constant_pool[index].info.utf8.length = (uint16_t)len;
    clazz->constant_pool[index].info.utf8.bytes = strdup(str);
    
    return index;
}

/* Create a minimal constant pool entry for Class */
static uint16_t add_class_ref(JavaClass* clazz, const char* name) {
    if (!name) return 0;
    
    uint16_t name_index = add_utf8(clazz, name);
    
    /* Check if already exists */
    for (uint16_t i = 1; i < clazz->constant_pool_count; i++) {
        if (clazz->constant_pool[i].tag == CONSTANT_Class &&
            clazz->constant_pool[i].info.class_info.name_index == name_index) {
            return i;
        }
    }
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Class;
    clazz->constant_pool[index].info.class_info.name_index = name_index;
    
    return index;
}

/* Create a NameAndType constant */
static uint16_t add_name_and_type(JavaClass* clazz, const char* name, const char* descriptor) {
    if (!name || !descriptor) return 0;
    
    uint16_t name_index = add_utf8(clazz, name);
    uint16_t descriptor_index = add_utf8(clazz, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_NameAndType;
    clazz->constant_pool[index].info.name_and_type.name_index = name_index;
    clazz->constant_pool[index].info.name_and_type.descriptor_index = descriptor_index;
    
    return index;
}

/* Create a Methodref constant */
static uint16_t add_method_ref(JavaClass* clazz, const char* class_name,
                               const char* name, const char* descriptor) {
    if (!class_name || !name || !descriptor) return 0;
    
    uint16_t class_index = add_class_ref(clazz, class_name);
    uint16_t name_and_type_index = add_name_and_type(clazz, name, descriptor);
    
    ensure_cp_capacity(clazz, 1);
    
    uint16_t index = clazz->constant_pool_count++;
    clazz->constant_pool[index].tag = CONSTANT_Methodref;
    clazz->constant_pool[index].info.ref_info.class_index = class_index;
    clazz->constant_pool[index].info.ref_info.name_and_type_index = name_and_type_index;
    
    return index;
}

/* Ensure methods array has space */
static void ensure_methods_capacity(JavaClass* clazz) {
    if (!clazz->methods) {
        clazz->methods_capacity = 8;
        clazz->methods = (JavaMethod*)calloc(clazz->methods_capacity, sizeof(JavaMethod));
        clazz->methods_count = 0;
    }
    
    if (clazz->methods_count >= clazz->methods_capacity) {
        int new_cap = clazz->methods_capacity * 2;
        JavaMethod* new_methods = (JavaMethod*)calloc(new_cap, sizeof(JavaMethod));
        if (!new_methods) return;  /* Out of memory */
        
        /* Copy old entries */
        memcpy(new_methods, clazz->methods, 
               clazz->methods_count * sizeof(JavaMethod));
        
        free(clazz->methods);
        clazz->methods = new_methods;
        clazz->methods_capacity = new_cap;
    }
}

/* Create a stub method - returns index in methods array */
static int create_stub_method(JavaClass* clazz, const char* name,
                              const char* descriptor, uint16_t access_flags,
                              const uint8_t* code, uint32_t code_len) {
    if (!name || !descriptor) return -1;
    
    ensure_methods_capacity(clazz);
    
    int idx = clazz->methods_count++;
    JavaMethod* method = &clazz->methods[idx];
    
    memset(method, 0, sizeof(JavaMethod));
    
    method->name = strdup(name);
    method->descriptor = strdup(descriptor);
    method->name_index = add_utf8(clazz, name);
    method->descriptor_index = add_utf8(clazz, descriptor);
    method->access_flags = access_flags;
    method->attributes_count = 0;
    method->clazz = clazz;
    
    /* Create Code attribute if not abstract/native and code provided */
    if (!(access_flags & (ACC_ABSTRACT | ACC_NATIVE))) {
        /* === FIX: Calculate max_locals correctly === */
        int arg_slots = count_args(descriptor);
        int is_static = (access_flags & ACC_STATIC) != 0;
        
        /* Instance methods need 'this' + args. Static methods need just args. */
        method->code.max_locals = arg_slots + (is_static ? 0 : 1);
        
        method->code.max_stack = 2; /* Simple stub code usually doesn't need deep stack */
        method->code.code_length = code_len;
        method->code.code = (uint8_t*)malloc(code_len);
        if (method->code.code) {
            memcpy(method->code.code, code, code_len);
        }
    }
    
    return idx;
}

/* Create a stub class */
static JavaClass* create_stub_class(JVM* jvm, const char* name, const char* super_name, uint16_t access_flags) {
    if (!name) return NULL;
    
    JavaClass* clazz = (JavaClass*)calloc(1, sizeof(JavaClass));
    if (!clazz) return NULL;
    
    clazz->class_name = strdup(name);
    clazz->access_flags = access_flags;
    clazz->major_version = 47; /* JDK 1.3 */
    clazz->minor_version = 0;
    clazz->magic = 0xCAFEBABE;
    
    /* Initialize constant pool with space check */
    ensure_cp_capacity(clazz, 4);  /* Pre-allocate space for basic entries */
    
    /* Add this class */
    clazz->this_class = add_class_ref(clazz, name);
    
    /* Add super class */
    if (super_name) {
        clazz->super_class_index = add_class_ref(clazz, super_name);
        clazz->super_class_name = strdup(super_name);
    }
    
    /* Allocate methods array */
    ensure_methods_capacity(clazz);
    
    /* 
     * Add default constructor.
     * Constructors are needed for:
     * 1. Concrete classes (normal instantiation).
     * 2. Abstract classes (subclasses call super()).
     * Constructors are NOT needed for:
     * 1. Interfaces.
     * 2. System classes that should only be created via native factories (Image, etc).
     */
    bool add_constructor = !(access_flags & ACC_INTERFACE);
    
    /* List of classes that must NOT have a public constructor generated */
    if (strcmp(name, "javax/microedition/lcdui/Image") == 0 ||
        strcmp(name, "javax/microedition/lcdui/Graphics") == 0 ||
        strcmp(name, "javax/microedition/lcdui/Font") == 0 ||
        strcmp(name, "javax/microedition/lcdui/Display") == 0) {
        add_constructor = false;
    }
    
    if (add_constructor) {
        /* 
         * CRITICAL FIX: If this is java/lang/Object, the constructor must not call super.
         * It should just return.
         */
        if (super_name == NULL) {
            /* java/lang/Object constructor: just return */
            uint8_t init_code[1];
            init_code[0] = 0xB1; /* return */
            create_stub_method(clazz, "<init>", "()V", ACC_PUBLIC, init_code, 1);
        } else {
            /* Subclass constructor: aload_0, invokespecial super.<init>, return */
            const char* super = super_name;
            uint16_t super_init_ref = add_method_ref(clazz, super, "<init>", "()V");
            
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "()V", ACC_PUBLIC, init_code, 5);
        }
        
        /* Special case for GameCanvas: it needs a constructor (boolean) */
        if (strcmp(name, "javax/microedition/lcdui/game/GameCanvas") == 0) {
            /* public GameCanvas(boolean suppressKeyEvents) */
            /* Code: aload_0, invokespecial super.<init>(), return */
            /* The boolean argument is simply ignored in the stub. */
            
            uint16_t super_init_ref = add_method_ref(clazz, "javax/microedition/lcdui/Canvas", "<init>", "()V");
            
            uint8_t init_code[5];
            init_code[0] = 0x2A; /* aload_0 */
            init_code[1] = 0xB7; /* invokespecial */
            init_code[2] = (super_init_ref >> 8) & 0xFF;
            init_code[3] = super_init_ref & 0xFF;
            init_code[4] = 0xB1; /* return */
            
            /* Descriptor (Z)V means takes boolean, returns void */
            create_stub_method(clazz, "<init>", "(Z)V", ACC_PUBLIC, init_code, 5);
        }
        
        /* Для классов исключений добавляем конструктор с сообщением */
        if (strstr(name, "Exception") || strstr(name, "Error")) {
            /* Конструктор с сообщением: super(msg) */
            uint16_t super_init_msg_ref = add_method_ref(clazz, super_name, "<init>", "(Ljava/lang/String;)V");
            
            uint8_t init_msg_code[6];
            init_msg_code[0] = 0x2A; /* aload_0 */
            init_msg_code[1] = 0x2B; /* aload_1 (загружаем сообщение) */
            init_msg_code[2] = 0xB7; /* invokespecial */
            init_msg_code[3] = (super_init_msg_ref >> 8) & 0xFF;
            init_msg_code[4] = super_init_msg_ref & 0xFF;
            init_msg_code[5] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;)V", ACC_PUBLIC, init_msg_code, 6);
            
            /* Конструктор с сообщением и причиной (Throwable) */
            uint16_t super_init_msg_throw_ref = add_method_ref(clazz, super_name, "<init>", "(Ljava/lang/String;Ljava/lang/Throwable;)V");
            
            uint8_t init_msg_throw_code[8];
            init_msg_throw_code[0] = 0x2A; /* aload_0 */
            init_msg_throw_code[1] = 0x2B; /* aload_1 (сообщение) */
            init_msg_throw_code[2] = 0x2C; /* aload_2 (причина) */
            init_msg_throw_code[3] = 0xB7; /* invokespecial */
            init_msg_throw_code[4] = (super_init_msg_throw_ref >> 8) & 0xFF;
            init_msg_throw_code[5] = super_init_msg_throw_ref & 0xFF;
            init_msg_throw_code[6] = 0xB1; /* return */
            
            create_stub_method(clazz, "<init>", "(Ljava/lang/String;Ljava/lang/Throwable;)V", 
                              ACC_PUBLIC, init_msg_throw_code, 7);
        }
    }
    
    /* Mark as stub */
    clazz->is_stub = true;
    clazz->initialized = false;
    clazz->initializing = false;
    clazz->static_fields = NULL;
    clazz->static_fields_count = 0;
    clazz->static_fields_capacity = 0;
    
    return clazz;
}

/* Initialize built-in stub classes */
int init_stub_classes(JVM* jvm) {
    if (!jvm) return 0;
    
    int count = 0;
    
    /* ===== ПЕРВЫЙ ПРОХОД: Создаем все классы ===== */
    for (int i = 0; stub_classes[i].name != NULL; i++) {
        /* Check if already loaded */
        bool found = false;
        for (size_t j = 0; j < jvm->class_loader.count; j++) {
            if (jvm->class_loader.classes[j]->class_name &&
                strcmp(jvm->class_loader.classes[j]->class_name, stub_classes[i].name) == 0) {
                found = true;
                break;
            }
        }
        
        if (found) continue;
        
        JavaClass* stub = create_stub_class(jvm, stub_classes[i].name,
                                           stub_classes[i].super, stub_classes[i].flags);
        if (!stub) {
            fprintf(stderr, "[STUB] Failed to create stub class: %s\n", stub_classes[i].name);
            continue;
        }
        
        /* Ensure class_loader has capacity */
        if (jvm->class_loader.count >= jvm->class_loader.capacity) {
            size_t new_cap = jvm->class_loader.capacity ? jvm->class_loader.capacity * 2 : 32;
            jvm->class_loader.classes = (JavaClass**)realloc(jvm->class_loader.classes,
                                   new_cap * sizeof(JavaClass*));
            if (jvm->class_loader.classes) {
                jvm->class_loader.capacity = new_cap;
            } else {
                free(stub);
                continue;
            }
        }
        
        jvm->class_loader.classes[jvm->class_loader.count++] = stub;
        count++;
        
        if (jvm->config.verbose_class) {
            printf("[STUB] Created stub class: %s\n", stub_classes[i].name);
        }
    }
    
    /* ===== ВТОРОЙ ПРОХОД: Разрешаем ссылки на суперклассы ===== */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
            /* Find super class in loaded classes */
            for (size_t j = 0; j < jvm->class_loader.count; j++) {
                if (jvm->class_loader.classes[j]->class_name &&
                    strcmp(jvm->class_loader.classes[j]->class_name, clazz->super_class_name) == 0) {
                    clazz->super_class = jvm->class_loader.classes[j];
                    if (jvm->config.verbose_class) {
                        fprintf(stderr, "[STUB] Resolved %s -> super: %s\n", 
                                clazz->class_name, clazz->super_class->class_name);
                    }
                    break;
                }
            }
        }
    }
    
    /* ===== ТРЕТИЙ ПРОХОД: Добавляем поля к классам ===== */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (!clazz->class_name) continue;
        
        /* java.lang.System - статические поля */
        if (strcmp(clazz->class_name, "java/lang/System") == 0) {
            /* Создаем массив статических полей */
            static const char* sys_static_fields[][2] = {
                {"out", "Ljava/io/PrintStream;"},
                {"err", "Ljava/io/PrintStream;"},
                {"in", "Ljava/io/InputStream;"},
                {NULL, NULL}
            };
            
            int static_count = 0;
            while (sys_static_fields[static_count][0] != NULL) static_count++;
            
            clazz->static_fields = (JavaStaticField*)calloc(static_count, sizeof(JavaStaticField));
            clazz->static_fields_count = static_count;
            clazz->static_fields_capacity = static_count;
            
            for (int j = 0; j < static_count; j++) {
                clazz->static_fields[j].name = strdup(sys_static_fields[j][0]);
                clazz->static_fields[j].descriptor = strdup(sys_static_fields[j][1]);
                memset(&clazz->static_fields[j].value, 0, sizeof(JavaValue));
            }
            
            fprintf(stderr, "[STUB] System class: added %d static fields\n", static_count);
        }
        
        /* java.util.Random needs a seed field (long = 64-bit = 2 slots) */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/util/Random") == 0) {
            /* Allocate fields array */
            clazz->fields_count = 1;  /* One field: seed (long) */
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("seed");
                clazz->fields[0].descriptor = strdup("J");  /* long */
                clazz->fields[0].name_index = add_utf8(clazz, "seed");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            fprintf(stderr, "[STUB] Added seed field to java/util/Random\n");
        }
        
        /* java.lang.StringBuffer needs buffer and length fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/StringBuffer") == 0) {
            /* Allocate fields array: [0] = buffer pointer, [1] = length */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buffer pointer (stored as reference) */
                clazz->fields[0].name = strdup("buffer");
                clazz->fields[0].descriptor = strdup("Ljava/lang/Object;");
                clazz->fields[0].name_index = add_utf8(clazz, "buffer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/Object;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                /* Field 1: length (int) */
                clazz->fields[1].name = strdup("count");
                clazz->fields[1].descriptor = strdup("I");  /* int */
                clazz->fields[1].name_index = add_utf8(clazz, "count");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two JavaValue slots */
            }
            fprintf(stderr, "[STUB] Added buffer/count fields to java/lang/StringBuffer\n");
        }
        
        /* javax.microedition.lcdui.Image needs native pointer field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Image") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            fprintf(stderr, "[STUB] Added nativePeer field to javax/microedition/lcdui/Image\n");
        }
        
        /* javax.microedition.lcdui.Graphics needs native pointer field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Graphics") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            fprintf(stderr, "[STUB] Added nativePeer field to javax/microedition/lcdui/Graphics\n");
        }
        
        /* javax.microedition.lcdui.Font needs native pointer field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Font") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: native pointer (stored as reference/long) */
                clazz->fields[0].name = strdup("nativePeer");
                clazz->fields[0].descriptor = strdup("J");  /* long - stores native pointer */
                clazz->fields[0].name_index = add_utf8(clazz, "nativePeer");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two slots for long */
            }
            fprintf(stderr, "[STUB] Added nativePeer field to javax/microedition/lcdui/Font\n");
        }
        
        /* java.lang.Thread needs target field for Runnable */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Thread") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: target (Runnable) */
                clazz->fields[0].name = strdup("target");
                clazz->fields[0].descriptor = strdup("Ljava/lang/Runnable;");
                clazz->fields[0].name_index = add_utf8(clazz, "target");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/Runnable;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added target field to java/lang/Thread\n");
        }
        
        /* java.io.ByteArrayInputStream needs buffer and position fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/ByteArrayInputStream") == 0) {
            /* Fields: [0] = buf (byte[]), [1] = pos (int), [2] = count (int) */
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buf (byte[]) */
                clazz->fields[0].name = strdup("buf");
                clazz->fields[0].descriptor = strdup("[B");  /* byte array */
                clazz->fields[0].name_index = add_utf8(clazz, "buf");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[B");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                /* Field 1: pos (int) */
                clazz->fields[1].name = strdup("pos");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "pos");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PROTECTED;

                /* Field 2: count (int) */
                clazz->fields[2].name = strdup("count");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "count");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(JavaValue) * 3;  /* Three JavaValue slots */
            }
            fprintf(stderr, "[STUB] Added buf/pos/count fields to java/io/ByteArrayInputStream\n");
        }
        
        /* java.io.ByteArrayOutputStream needs buffer and count fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/ByteArrayOutputStream") == 0) {
            /* Fields: [0] = buf (byte[]), [1] = count (int) */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: buf (byte[]) */
                clazz->fields[0].name = strdup("buf");
                clazz->fields[0].descriptor = strdup("[B");  /* byte array */
                clazz->fields[0].name_index = add_utf8(clazz, "buf");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[B");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                /* Field 1: count (int) */
                clazz->fields[1].name = strdup("count");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "count");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(JavaValue) * 2;  /* Two JavaValue slots */
            }
            fprintf(stderr, "[STUB] Added buf/count fields to java/io/ByteArrayOutputStream\n");
        }
        
        /* java.io.DataOutputStream needs out field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/DataOutputStream") == 0) {
            /* Fields: [0] = out (OutputStream) */
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: out (OutputStream) */
                clazz->fields[0].name = strdup("out");
                clazz->fields[0].descriptor = strdup("Ljava/io/OutputStream;");
                clazz->fields[0].name_index = add_utf8(clazz, "out");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/io/OutputStream;");
                clazz->fields[0].access_flags = ACC_PROTECTED;

                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added out field to java/io/DataOutputStream\n");
        }

        /* javax.microedition.rms.RecordStore needs nativeHandle field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/rms/RecordStore") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                /* Field 0: nativeHandle (int) - stores native record store handle */
                clazz->fields[0].name = strdup("nativeHandle");
                clazz->fields[0].descriptor = strdup("I");  /* int */
                clazz->fields[0].name_index = add_utf8(clazz, "nativeHandle");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);  /* One JavaValue slot */
            }
            fprintf(stderr, "[STUB] Added nativeHandle field to javax/microedition/rms/RecordStore\n");
        }
        
        /* javax.microedition.lcdui.Form needs title and items fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Form") == 0) {
            /* Fields: [0] = title (String), [1] = items (Item[]) */
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("items");
                clazz->fields[1].descriptor = strdup("[Ljavax/microedition/lcdui/Item;");
                clazz->fields[1].name_index = add_utf8(clazz, "items");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "[Ljavax/microedition/lcdui/Item;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 2;
            }
            fprintf(stderr, "[STUB] Added title/items fields to javax/microedition/lcdui/Form\n");
        }
        
        /* javax.microedition.lcdui.List needs title, type, strings, selected fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/List") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("listType");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "listType");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("strings");
                clazz->fields[2].descriptor = strdup("[Ljava/lang/String;");
                clazz->fields[2].name_index = add_utf8(clazz, "strings");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "[Ljava/lang/String;");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("selected");
                clazz->fields[3].descriptor = strdup("[Z");
                clazz->fields[3].name_index = add_utf8(clazz, "selected");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "[Z");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 4;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/List\n");
        }
        
        /* javax.microedition.lcdui.Alert needs title, text, image, type, timeout fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Alert") == 0) {
            clazz->fields_count = 5;
            clazz->fields = (JavaField*)calloc(5, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("image");
                clazz->fields[2].descriptor = strdup("Ljavax/microedition/lcdui/Image;");
                clazz->fields[2].name_index = add_utf8(clazz, "image");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/Image;");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("alertType");
                clazz->fields[3].descriptor = strdup("Ljavax/microedition/lcdui/AlertType;");
                clazz->fields[3].name_index = add_utf8(clazz, "alertType");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/AlertType;");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->fields[4].name = strdup("timeout");
                clazz->fields[4].descriptor = strdup("I");
                clazz->fields[4].name_index = add_utf8(clazz, "timeout");
                clazz->fields[4].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[4].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 5;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/Alert\n");
        }
        
        /* javax.microedition.lcdui.TextBox needs title, text, maxSize, constraints fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/TextBox") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("title");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "title");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("maxSize");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "maxSize");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("constraints");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "constraints");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 4;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/TextBox\n");
        }
        
        /* javax.microedition.lcdui.Item needs label field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Item") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);
            }
            fprintf(stderr, "[STUB] Added label field to javax/microedition/lcdui/Item\n");
        }
        
        /* javax.microedition.lcdui.StringItem needs label, text fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/StringItem") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 2;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/StringItem\n");
        }
        
        /* javax.microedition.lcdui.TextField needs label, text, maxSize, constraints fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/TextField") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("text");
                clazz->fields[1].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[1].name_index = add_utf8(clazz, "text");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("maxSize");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "maxSize");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("constraints");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "constraints");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 4;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/TextField\n");
        }
        
        /* javax.microedition.lcdui.ChoiceGroup needs label, type, strings, selected fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/ChoiceGroup") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("choiceType");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "choiceType");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("strings");
                clazz->fields[2].descriptor = strdup("[Ljava/lang/String;");
                clazz->fields[2].name_index = add_utf8(clazz, "strings");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "[Ljava/lang/String;");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("selected");
                clazz->fields[3].descriptor = strdup("[Z");
                clazz->fields[3].name_index = add_utf8(clazz, "selected");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "[Z");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 4;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/ChoiceGroup\n");
        }
        
        /* javax.microedition.lcdui.Gauge needs label, interactive, max, value fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Gauge") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("interactive");
                clazz->fields[1].descriptor = strdup("Z");
                clazz->fields[1].name_index = add_utf8(clazz, "interactive");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Z");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("maxValue");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "maxValue");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("value");
                clazz->fields[3].descriptor = strdup("I");
                clazz->fields[3].name_index = add_utf8(clazz, "value");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 4;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/Gauge\n");
        }
        
        /* javax.microedition.lcdui.Spacer needs width, height fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Spacer") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("width");
                clazz->fields[0].descriptor = strdup("I");
                clazz->fields[0].name_index = add_utf8(clazz, "width");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("height");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "height");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 2;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/Spacer\n");
        }
        
        /* javax.microedition.lcdui.ImageItem needs label, image, layout, altText fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/ImageItem") == 0) {
            clazz->fields_count = 4;
            clazz->fields = (JavaField*)calloc(4, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("image");
                clazz->fields[1].descriptor = strdup("Ljavax/microedition/lcdui/Image;");
                clazz->fields[1].name_index = add_utf8(clazz, "image");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "Ljavax/microedition/lcdui/Image;");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("layout");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "layout");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->fields[3].name = strdup("altText");
                clazz->fields[3].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[3].name_index = add_utf8(clazz, "altText");
                clazz->fields[3].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[3].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 4;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/ImageItem\n");
        }
        
        /* javax.microedition.lcdui.DateField needs label, mode, date fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/DateField") == 0) {
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("mode");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "mode");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("date");
                clazz->fields[2].descriptor = strdup("J");  /* long */
                clazz->fields[2].name_index = add_utf8(clazz, "date");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "J");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 3;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/DateField\n");
        }
        
        /* javax.microedition.lcdui.Ticker needs text field */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Ticker") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("text");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "text");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                clazz->instance_size = sizeof(JavaValue);
            }
            fprintf(stderr, "[STUB] Added text field to javax/microedition/lcdui/Ticker\n");
        }
        
        /* javax.microedition.lcdui.Command needs label, type, priority fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/Command") == 0) {
            clazz->fields_count = 3;
            clazz->fields = (JavaField*)calloc(3, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("label");
                clazz->fields[0].descriptor = strdup("Ljava/lang/String;");
                clazz->fields[0].name_index = add_utf8(clazz, "label");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/lang/String;");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("type");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "type");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->fields[2].name = strdup("priority");
                clazz->fields[2].descriptor = strdup("I");
                clazz->fields[2].name_index = add_utf8(clazz, "priority");
                clazz->fields[2].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[2].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 3;
            }
            fprintf(stderr, "[STUB] Added fields to javax/microedition/lcdui/Command\n");
        }
        
        /* javax.microedition.lcdui.AlertType - just needs to exist */
        else if (clazz->class_name && strcmp(clazz->class_name, "javax/microedition/lcdui/AlertType") == 0) {
            clazz->fields_count = 0;
            clazz->instance_size = 0;
            fprintf(stderr, "[STUB] Created javax/microedition/lcdui/AlertType\n");
        }
        
        /* com.nokia.mid.sound.Sound needs data and type fields */
        else if (clazz->class_name && strcmp(clazz->class_name, "com/nokia/mid/sound/Sound") == 0) {
            clazz->fields_count = 2;
            clazz->fields = (JavaField*)calloc(2, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("data");
                clazz->fields[0].descriptor = strdup("[B");  /* byte array */
                clazz->fields[0].name_index = add_utf8(clazz, "data");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "[B");
                clazz->fields[0].access_flags = ACC_PRIVATE;
                
                clazz->fields[1].name = strdup("soundType");
                clazz->fields[1].descriptor = strdup("I");
                clazz->fields[1].name_index = add_utf8(clazz, "soundType");
                clazz->fields[1].descriptor_index = add_utf8(clazz, "I");
                clazz->fields[1].access_flags = ACC_PRIVATE;
                
                clazz->instance_size = sizeof(JavaValue) * 2;
            }
            fprintf(stderr, "[STUB] Added fields to com/nokia/mid/sound/Sound\n");
        }
        
        /* java.io.DataInputStream needs in field */
        else if (clazz->class_name && strcmp(clazz->class_name, "java/io/DataInputStream") == 0) {
            clazz->fields_count = 1;
            clazz->fields = (JavaField*)calloc(1, sizeof(JavaField));
            if (clazz->fields) {
                clazz->fields[0].name = strdup("in");
                clazz->fields[0].descriptor = strdup("Ljava/io/InputStream;");
                clazz->fields[0].name_index = add_utf8(clazz, "in");
                clazz->fields[0].descriptor_index = add_utf8(clazz, "Ljava/io/InputStream;");
                clazz->fields[0].access_flags = ACC_PROTECTED;
                
                clazz->instance_size = sizeof(JavaValue);
            }
            fprintf(stderr, "[STUB] Added in field to java/io/DataInputStream\n");
        }
    }

    /* ===== ЧЕТВЕРТЫЙ ПРОХОД: Устанавливаем ObjectHeader для всех классов ===== */
    JavaClass* class_class = NULL;  /* java/lang/Class */
    
    /* Находим java/lang/Class */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->class_name && strcmp(clazz->class_name, "java/lang/Class") == 0) {
            class_class = clazz;
            break;
        }
    }

    if (class_class) {
        for (size_t i = 0; i < jvm->class_loader.count; i++) {
            JavaClass* clazz = jvm->class_loader.classes[i];
            /* Set header.clazz to java/lang/Class so this JavaClass* can be used as a Class object */
            clazz->header.clazz = class_class;
            /* Set a hashcode based on the pointer */
            clazz->header.hashcode = (jint)(uintptr_t)clazz ^ 0x5A5A5A5A;
            clazz->header.gc_mark = 0;
            clazz->header.reserved = 0;
        }
        /* java/lang/Class's header.clazz should point to itself */
        class_class->header.clazz = class_class;
        fprintf(stderr, "[STUB] Initialized Class object headers for %zu classes\n", jvm->class_loader.count);
    }

    return count;
}

/* Get or create a stub class by name */
JavaClass* get_or_create_stub_class(JVM* jvm, const char* class_name) {
    if (!class_name || !jvm) return NULL;
    
    /* Check if already loaded */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        if (jvm->class_loader.classes[i]->class_name &&
            strcmp(jvm->class_loader.classes[i]->class_name, class_name) == 0) {
            return jvm->class_loader.classes[i];
        }
    }
    
    /* Determine super class based on class name */
    const char* super_name = "java/lang/Object";  /* Default */
    
    /* MIDP LCDUI hierarchy */
    if (strcmp(class_name, "javax/microedition/lcdui/game/GameCanvas") == 0) {
        super_name = "javax/microedition/lcdui/Canvas";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Canvas") == 0) {
        super_name = "javax/microedition/lcdui/Displayable";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Displayable") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Screen") == 0) {
        super_name = "javax/microedition/lcdui/Displayable";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Form") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/TextBox") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/List") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Alert") == 0) {
        super_name = "javax/microedition/lcdui/Screen";
    } else if (strcmp(class_name, "javax/microedition/lcdui/Item") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/lcdui/StringItem") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/TextField") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/ImageItem") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/ChoiceGroup") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/Gauge") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/Spacer") == 0 ||
               strcmp(class_name, "javax/microedition/lcdui/DateField") == 0) {
        super_name = "javax/microedition/lcdui/Item";
    }
    /* MIDP Media */
    else if (strcmp(class_name, "javax/microedition/media/Player") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/media/Control") == 0) {
        super_name = "java/lang/Object";
    } else if (strcmp(class_name, "javax/microedition/media/control/VolumeControl") == 0) {
        super_name = "javax/microedition/media/Control";
    }
    /* RMS */
    else if (strcmp(class_name, "javax/microedition/rms/RecordStoreException") == 0) {
        super_name = "java/lang/Exception";
    } else if (strcmp(class_name, "javax/microedition/rms/RecordStoreNotFoundException") == 0 ||
               strcmp(class_name, "javax/microedition/rms/RecordStoreFullException") == 0) {
        super_name = "javax/microedition/rms/RecordStoreException";
    }
    /* Exceptions */
    else if (strcmp(class_name, "javax/microedition/midlet/MIDletStateChangeException") == 0) {
        super_name = "java/lang/Exception";
    }
    
    /* Create stub class with proper super class */
    JavaClass* stub = create_stub_class(jvm, class_name, super_name, ACC_PUBLIC);
    if (!stub) return NULL;
    
    /* Ensure class_loader has capacity */
    if (jvm->class_loader.count >= jvm->class_loader.capacity) {
        size_t new_cap = jvm->class_loader.capacity ? jvm->class_loader.capacity * 2 : 32;
        jvm->class_loader.classes = (JavaClass**)realloc(jvm->class_loader.classes,
                               new_cap * sizeof(JavaClass*));
        if (!jvm->class_loader.classes) {
            free(stub);
            return NULL;
        }
        jvm->class_loader.capacity = new_cap;
    }
    
    jvm->class_loader.classes[jvm->class_loader.count++] = stub;
    
    /* Resolve super_class reference */
    if (stub->super_class == NULL && stub->super_class_name != NULL) {
        /* Try to find super class in loaded classes */
        for (size_t j = 0; j < jvm->class_loader.count; j++) {
            if (jvm->class_loader.classes[j]->class_name &&
                strcmp(jvm->class_loader.classes[j]->class_name, stub->super_class_name) == 0) {
                stub->super_class = jvm->class_loader.classes[j];
                break;
            }
        }
        /* If not found, create it recursively */
        if (stub->super_class == NULL && strcmp(stub->super_class_name, "java/lang/Object") != 0) {
            stub->super_class = get_or_create_stub_class(jvm, stub->super_class_name);
        }
    }

    /* Initialize header for Class object support */
    JavaClass* class_class = NULL;
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        if (jvm->class_loader.classes[i]->class_name &&
            strcmp(jvm->class_loader.classes[i]->class_name, "java/lang/Class") == 0) {
            class_class = jvm->class_loader.classes[i];
            break;
        }
    }
    if (class_class) {
        stub->header.clazz = class_class;
        stub->header.hashcode = (jint)(uintptr_t)stub ^ 0x5A5A5A5A;
    }

    if (jvm->config.verbose_class) {
        printf("[STUB] Auto-created stub class: %s (super: %s)\n", class_name, super_name);
    }

    return stub;
}