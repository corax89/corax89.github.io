/*
 * J2ME Emulator - Cooperative Multithreading Implementation
 * User-space thread scheduling without OS threads
 */

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "threads.h"
#include "jvm.h"
#include "debug.h"

/* Maximum number of cooperative threads */
#define MAX_COOP_THREADS 32

/* Thread control block for cooperative scheduling */
typedef struct CoopThread {
    JavaThread* java_thread;
    struct CoopThread* next;
    ThreadState state;
    jlong wake_time_ms;     /* For TIMED_WAITING */
    int priority;
} CoopThread;

/* Global scheduler state */
static struct {
    CoopThread* threads[MAX_COOP_THREADS];
    int thread_count;
    
    CoopThread* run_queue_head;   /* Runnable threads */
    CoopThread* run_queue_tail;
    
    CoopThread* sleep_list;       /* Sleeping threads, sorted by wake time */
    
    CoopThread* current;          /* Currently executing thread */
    JavaThread* main_thread;      /* Main thread reference */
    
    JVM* jvm;
    bool initialized;
} scheduler = {0};

/* Get current time in milliseconds */
static jlong get_time_ms(void) {
#ifdef _WIN32
    return (jlong)GetTickCount64();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
}

/* Initialize thread system */
int threads_init(JVM* jvm) {
    if (scheduler.initialized) return JNI_OK;
    
    scheduler.jvm = jvm;
    scheduler.thread_count = 0;
    scheduler.run_queue_head = NULL;
    scheduler.run_queue_tail = NULL;
    scheduler.sleep_list = NULL;
    scheduler.current = NULL;
    scheduler.main_thread = NULL;
    scheduler.initialized = true;
    
    return JNI_OK;
}

/* Create new Java thread */
JavaThread* thread_create(JVM* jvm, const char* name, jint priority, JavaObject* thread_obj) {
    (void)jvm;
    
    if (scheduler.thread_count >= MAX_COOP_THREADS) {
        THREAD_DEBUG("Maximum thread count reached");
        return NULL;
    }
    
    /* Allocate JavaThread */
    JavaThread* java_thread = (JavaThread*)calloc(1, sizeof(JavaThread));
    if (!java_thread) return NULL;
    
    java_thread->id = scheduler.thread_count + 1;
    java_thread->name = name ? strdup(name) : NULL;
    java_thread->priority = priority;
    java_thread->is_daemon = false;
    java_thread->is_alive = false;
    java_thread->thread_object = thread_obj;
    java_thread->current_frame = NULL;
    java_thread->pending_exception = NULL;
    java_thread->stack_size = JAVA_STACK_SIZE;
    
    /* Allocate stack for this thread */
    java_thread->stack_base = malloc(JAVA_STACK_SIZE);
    if (!java_thread->stack_base) {
        free(java_thread->name);
        free(java_thread);
        return NULL;
    }
    java_thread->stack_used = 0;
    
    /* Allocate thread-local allocator */
    java_thread->allocator.heap_size = 64 * 1024;  /* 64KB per thread */
    java_thread->allocator.heap = malloc(java_thread->allocator.heap_size);
    java_thread->allocator.heap_used = 0;
    
    /* Create CoopThread wrapper */
    CoopThread* coop = (CoopThread*)calloc(1, sizeof(CoopThread));
    if (!coop) {
        free(java_thread->stack_base);
        free(java_thread->name);
        free(java_thread);
        return NULL;
    }
    
    coop->java_thread = java_thread;
    coop->state = THREAD_STATE_NEW;
    coop->priority = priority;
    coop->wake_time_ms = 0;
    coop->next = NULL;
    
    /* Add to thread array */
    scheduler.threads[scheduler.thread_count++] = coop;
    
    /* Store main thread reference */
    if (name && strcmp(name, "main") == 0) {
        scheduler.main_thread = java_thread;
        scheduler.current = coop;  /* Main thread is initially current */
        coop->state = THREAD_STATE_RUNNABLE;
        java_thread->is_alive = true;
        
        /* Add main thread to run queue */
        scheduler.run_queue_head = coop;
        scheduler.run_queue_tail = coop;
    }
    
    THREAD_DEBUG("Created thread %d: %s (priority %d)", 
            java_thread->id, name ? name : "unnamed", priority);
    
    return java_thread;
}

/* Add thread to run queue */
static void add_to_run_queue(CoopThread* coop) {
    if (!coop) return;
    
    coop->state = THREAD_STATE_RUNNABLE;
    coop->next = NULL;
    
    if (!scheduler.run_queue_head) {
        scheduler.run_queue_head = coop;
        scheduler.run_queue_tail = coop;
    } else {
        /* Priority-based insertion: higher priority first */
        CoopThread** pp = &scheduler.run_queue_head;
        while (*pp && (*pp)->priority >= coop->priority) {
            pp = &(*pp)->next;
        }
        coop->next = *pp;
        *pp = coop;
        
        if (!coop->next) {
            scheduler.run_queue_tail = coop;
        }
    }
}

/* Remove thread from run queue */
static CoopThread* remove_from_run_queue(void) {
    if (!scheduler.run_queue_head) return NULL;
    
    CoopThread* coop = scheduler.run_queue_head;
    scheduler.run_queue_head = coop->next;
    
    if (!scheduler.run_queue_head) {
        scheduler.run_queue_tail = NULL;
    }
    
    coop->next = NULL;
    return coop;
}

/* Add to sleep list (sorted by wake time) */
static void add_to_sleep_list(CoopThread* coop, jlong wake_time) {
    coop->state = THREAD_STATE_TIMED_WAITING;
    coop->wake_time_ms = wake_time;
    coop->next = NULL;
    
    /* Insert sorted by wake time */
    CoopThread** pp = &scheduler.sleep_list;
    while (*pp && (*pp)->wake_time_ms <= wake_time) {
        pp = &(*pp)->next;
    }
    coop->next = *pp;
    *pp = coop;
    
    THREAD_DEBUG("Thread %d sleeping until %lld ms", 
            coop->java_thread->id, (long long)wake_time);
}

/* Wake up sleeping threads */
static void wakeup_sleeping_threads(void) {
    jlong now = get_time_ms();
    
    while (scheduler.sleep_list && scheduler.sleep_list->wake_time_ms <= now) {
        CoopThread* coop = scheduler.sleep_list;
        scheduler.sleep_list = coop->next;
        coop->next = NULL;
        
        THREAD_DEBUG("Thread %d woke up", coop->java_thread->id);
        add_to_run_queue(coop);
    }
}

/* Start a thread */
int thread_start(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return JNI_ERR;
    
    /* Find CoopThread for this JavaThread */
    CoopThread* coop = NULL;
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            coop = scheduler.threads[i];
            break;
        }
    }
    
    if (!coop) {
        THREAD_DEBUG("Thread not found for start");
        return JNI_ERR;
    }
    
    if (coop->state != THREAD_STATE_NEW) {
        THREAD_DEBUG("Thread already started");
        return JNI_ERR;
    }
    
    thread->is_alive = true;
    add_to_run_queue(coop);
    
    THREAD_DEBUG("Thread %d started and added to run queue", thread->id);
    return JNI_OK;
}

/* Join a thread - wait until it terminates */
int thread_join(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return JNI_ERR;
    
    /* Find CoopThread */
    CoopThread* coop = NULL;
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            coop = scheduler.threads[i];
            break;
        }
    }
    
    if (!coop) return JNI_ERR;
    
    /* Busy wait until thread terminates (cooperative) */
    while (coop->state != THREAD_STATE_TERMINATED) {
        thread_yield(jvm);
    }
    
    return JNI_OK;
}

/* Get current thread */
JavaThread* thread_current(JVM* jvm) {
    (void)jvm;
    return scheduler.current ? scheduler.current->java_thread : scheduler.main_thread;
}

/* Schedule next thread - cooperative context switch */
void thread_schedule(JVM* jvm) {
    (void)jvm;
    
    /* Wake up any sleeping threads */
    wakeup_sleeping_threads();
    
    /* If current thread is still runnable, put it back in queue */
    if (scheduler.current && 
        scheduler.current->state == THREAD_STATE_RUNNABLE &&
        scheduler.current->java_thread->is_alive) {
        add_to_run_queue(scheduler.current);
    }
    
    /* Get next thread from run queue */
    CoopThread* next = remove_from_run_queue();
    
    if (next) {
        scheduler.current = next;
        THREAD_DEBUG("Switched to thread %d (%s)",
                next->java_thread->id,
                next->java_thread->name ? next->java_thread->name : "?");
    } else if (scheduler.sleep_list) {
        /* All threads are sleeping, wait for the first to wake */
        jlong now = get_time_ms();
        jlong sleep_duration = scheduler.sleep_list->wake_time_ms - now;
        
        if (sleep_duration > 0) {
            THREAD_DEBUG("All threads sleeping, waiting %lld ms",
                    (long long)sleep_duration);
#ifdef _WIN32
            Sleep((DWORD)sleep_duration);
#else
            struct timespec ts = {
                .tv_sec = sleep_duration / 1000,
                .tv_nsec = (sleep_duration % 1000) * 1000000
            };
            nanosleep(&ts, NULL);
#endif
        }
        
        /* Try again after sleeping */
        wakeup_sleeping_threads();
        next = remove_from_run_queue();
        if (next) {
            scheduler.current = next;
        }
    }
}

/* Yield to other threads */
void thread_yield(JVM* jvm) {
    if (!scheduler.initialized) return;
    
    THREAD_DEBUG("Thread %d yields",
            scheduler.current ? scheduler.current->java_thread->id : 0);
    
    thread_schedule(jvm);
}

/* Sleep for milliseconds */
int thread_sleep(JVM* jvm, jlong millis) {
    (void)jvm;
    
    /* ИСПРАВЛЕНО: В текущей кооперативной модели без реального переключения контекста
     * (setjmp/longjmp или ucontext), мы не можем "усыпить" текущий поток и
     * переключиться на другой. Вместо этого:
     * 1. Если есть другие runnable потоки - пробуем их выполнить
     * 2. Реально блокируем на минимальное время
     * 3. Обрабатываем события SDL для отзывчивости UI
     */
    
    /* Cap sleep time to reasonable values */
    if (millis < 0) millis = 0;
    if (millis > 10000) millis = 10000;  /* Max 10 seconds */
    
    THREAD_DEBUG("Thread %d sleeping for %lld ms (cooperative mode)",
            scheduler.current ? scheduler.current->java_thread->id : 0, (long long)millis);
    
    /* Wake up any sleeping threads first */
    wakeup_sleeping_threads();
    
    /* Process SDL events to keep UI responsive during sleep */
    extern void sdl_process_events_minimal(void);
    sdl_process_events_minimal();
    
    /* For short sleeps, just do a real sleep */
    if (millis > 0) {
#ifdef _WIN32
        Sleep((DWORD)millis);
#else
        struct timespec ts = {
            .tv_sec = millis / 1000,
            .tv_nsec = (millis % 1000) * 1000000
        };
        nanosleep(&ts, NULL);
#endif
    }
    
    return JNI_OK;
}

/* Check if thread is alive */
bool thread_is_alive(JavaThread* thread) {
    if (!thread) return false;
    return thread->is_alive;
}

/* Get thread state */
ThreadState thread_get_state(JavaThread* thread) {
    if (!thread) return THREAD_STATE_NEW;
    
    /* Find CoopThread */
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            return scheduler.threads[i]->state;
        }
    }
    
    return THREAD_STATE_TERMINATED;
}

/* Set thread priority */
void thread_set_priority(JavaThread* thread, jint priority) {
    if (!thread) return;
    
    thread->priority = priority;
    
    /* Update CoopThread */
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            scheduler.threads[i]->priority = priority;
            break;
        }
    }
}

/* Interrupt a thread */
void thread_interrupt(JavaThread* thread) {
    if (!thread) return;
    
    thread->interrupted = true;
    
    /* If thread is sleeping/waiting, wake it up */
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            CoopThread* coop = scheduler.threads[i];
            
            if (coop->state == THREAD_STATE_TIMED_WAITING ||
                coop->state == THREAD_STATE_WAITING) {
                /* Remove from sleep list if there */
                CoopThread** pp = &scheduler.sleep_list;
                while (*pp) {
                    if (*pp == coop) {
                        *pp = coop->next;
                        coop->next = NULL;
                        add_to_run_queue(coop);
                        break;
                    }
                    pp = &(*pp)->next;
                }
            }
            break;
        }
    }
}

/* Check if thread is interrupted */
bool thread_is_interrupted(JavaThread* thread, bool clear_flag) {
    if (!thread) return false;
    bool interrupted = thread->interrupted;
    if (clear_flag) thread->interrupted = false;
    return interrupted;
}

/* Destroy a thread */
void thread_destroy(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return;
    
    /* Find and remove from scheduler */
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            CoopThread* coop = scheduler.threads[i];
            coop->state = THREAD_STATE_TERMINATED;
            
            /* Don't free yet - might still be in queue */
            thread->is_alive = false;
            break;
        }
    }
    
    free(thread->name);
    free(thread->stack_base);
    if (thread->allocator.heap) {
        free(thread->allocator.heap);
    }
    free(thread);
}

/* Execute one quantum for current thread, then schedule */
int thread_execute_quantum(JVM* jvm, int max_instructions) {
    (void)jvm;
    (void)max_instructions;
    
    /* This would be called from the interpreter to limit execution */
    /* and trigger cooperative scheduling */
    return 0;
}

/* Check if there are runnable threads */
bool threads_has_runnable(void) {
    wakeup_sleeping_threads();
    return scheduler.run_queue_head != NULL;
}

/* Get current CoopThread (internal) */
CoopThread* thread_current_coop(void) {
    return scheduler.current;
}

/*
 * Monitor functions (synchronization) - cooperative implementation
 */

/* Simple monitor structure */
typedef struct {
    JavaObject* owner;
    jint entry_count;
    CoopThread* wait_list;   /* Threads waiting on this monitor */
} CoopMonitor;

/* Get or create monitor for object */
static CoopMonitor* get_monitor(JavaObject* obj) {
    /* For simplicity, we use a hash of the object address as monitor storage */
    /* In a real implementation, this would be more sophisticated */
    static CoopMonitor monitors[256];
    
    size_t idx = ((size_t)obj >> 4) & 0xFF;
    return &monitors[idx];
}

/* Enter monitor (acquire lock) */
int monitor_enter(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    
    /* ИСПРАВЛЕНО: Правильная проверка владельца - это должен быть JavaThread */
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    if (mon->owner == NULL) {
        /* Lock is free, acquire it */
        mon->owner = (JavaObject*)current_thread;  /* Store thread as owner */
        mon->entry_count = 1;
        
        /* ИСПРАВЛЕНО: Memory barrier для volatile семантики */
        memory_barrier();
        return JNI_OK;
    }
    
    /* Check if current thread already owns it (reentrant) */
    if ((JavaObject*)current_thread == mon->owner) {
        mon->entry_count++;
        return JNI_OK;
    }
    
    /* Lock is held by another thread - yield and retry */
    THREAD_DEBUG("Monitor contention on %p - yielding", (void*)obj);
    thread_yield(jvm);
    
    /* Retry after yield */
    return monitor_enter(jvm, obj);
}

/* Exit monitor (release lock) */
int monitor_exit(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    /* ИСПРАВЛЕНО: Правильная проверка владельца */
    if (mon->owner != (JavaObject*)current_thread) {
        /* Not owner - IllegalMonitorStateException */
        THREAD_DEBUG("monitor_exit: thread %p is not owner (owner=%p)",
                (void*)current_thread, (void*)mon->owner);
        return JNI_ERR;
    }
    
    /* ИСПРАВЛЕНО: Memory barrier перед освобождением */
    memory_barrier();
    
    mon->entry_count--;
    if (mon->entry_count == 0) {
        mon->owner = NULL;
        
        /* Wake up one waiting thread */
        if (mon->wait_list) {
            CoopThread* waiter = mon->wait_list;
            mon->wait_list = waiter->next;
            waiter->next = NULL;
            add_to_run_queue(waiter);
        }
    }
    
    return JNI_OK;
}

/* Wait on monitor */
int monitor_wait(JVM* jvm, JavaObject* obj, jlong timeout, bool timed) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    /* ИСПРАВЛЕНО: Правильная проверка владельца */
    if (mon->owner != (JavaObject*)current_thread) {
        THREAD_DEBUG("monitor_wait: thread %p is not owner (owner=%p)",
                (void*)current_thread, (void*)mon->owner);
        return JNI_ERR;
    }
    
    /* Release monitor temporarily */
    jint saved_count = mon->entry_count;
    mon->owner = NULL;
    mon->entry_count = 0;
    
    /* ИСПРАВЛЕНО: Memory barrier */
    memory_barrier();
    
    /* Add current thread to wait list */
    if (scheduler.current) {
        scheduler.current->next = mon->wait_list;
        mon->wait_list = scheduler.current;
        scheduler.current->state = timed ? THREAD_STATE_TIMED_WAITING : THREAD_STATE_WAITING;
        
        if (timed && timeout > 0) {
            scheduler.current->wake_time_ms = get_time_ms() + timeout;
        }
    }
    
    /* Yield to other threads */
    thread_schedule(jvm);
    
    /* When we return, re-acquire the monitor */
    while (mon->owner != NULL) {
        thread_yield(jvm);
    }
    mon->owner = (JavaObject*)current_thread;
    mon->entry_count = saved_count;
    
    return JNI_OK;
}

/* Notify one thread waiting on monitor */
int monitor_notify(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    /* ИСПРАВЛЕНО: Правильная проверка владельца */
    if (mon->owner != (JavaObject*)current_thread) {
        THREAD_DEBUG("monitor_notify: thread %p is not owner", (void*)current_thread);
        return JNI_ERR;
    }
    
    /* Wake up one waiting thread */
    if (mon->wait_list) {
        CoopThread* waiter = mon->wait_list;
        mon->wait_list = waiter->next;
        waiter->next = NULL;
        add_to_run_queue(waiter);
    }
    
    return JNI_OK;
}

/* Notify all threads waiting on monitor */
int monitor_notify_all(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    /* ИСПРАВЛЕНО: Правильная проверка владельца */
    if (mon->owner != (JavaObject*)current_thread) {
        THREAD_DEBUG("monitor_notify_all: thread %p is not owner", (void*)current_thread);
        return JNI_ERR;
    }
    
    /* Wake up all waiting threads */
    while (mon->wait_list) {
        CoopThread* waiter = mon->wait_list;
        mon->wait_list = waiter->next;
        waiter->next = NULL;
        add_to_run_queue(waiter);
    }
    
    return JNI_OK;
}

/* Stub implementations for monitor queries */
JavaMonitor* monitor_get(JVM* jvm, JavaObject* obj) {
    (void)jvm; (void)obj;
    return NULL;
}

JavaThread* monitor_get_owner(JavaObject* obj) {
    if (!obj) return NULL;
    CoopMonitor* mon = get_monitor(obj);
    /* This is simplified - would need proper thread mapping */
    return mon->owner ? scheduler.current->java_thread : NULL;
}

jint monitor_get_entry_count(JavaObject* obj) {
    if (!obj) return 0;
    CoopMonitor* mon = get_monitor(obj);
    return mon->entry_count;
}

/*
 * Thread-local storage - simplified
 */

int thread_local_create(ThreadLocalKey* key) {
    *key = 0;
    return JNI_OK;
}

int thread_local_set(ThreadLocalKey key, void* value) {
    (void)key; (void)value;
    return JNI_OK;
}

void* thread_local_get(ThreadLocalKey key) {
    (void)key;
    return NULL;
}

void thread_local_delete(ThreadLocalKey key) {
    (void)key;
}

/*
 * Atomic operations - ИСПРАВЛЕНО с правильными барьерами памяти
 */

/* ИСПРАВЛЕНО: Реальные memory barriers для разных платформ */
void memory_barrier(void) {
#ifdef _WIN32
    MemoryBarrier();  /* Windows API */
#elif defined(__GNUC__)
    __sync_synchronize();  /* GCC/Clang full memory barrier */
#elif defined(__cplusplus) && __cplusplus >= 201103L
    std::atomic_thread_fence(std::memory_order_seq_cst);
#else
    /* Fallback - может не работать на всех архитектурах */
    volatile int dummy = 0;
    (void)dummy;
#endif
}

/* ИСПРАВЛЕНО: Acquire barrier - для чтения volatile */
void memory_barrier_acquire(void) {
#ifdef _WIN32
    MemoryBarrier();
#elif defined(__GNUC__)
    __sync_synchronize();
#else
    memory_barrier();
#endif
}

/* ИСПРАВЛЕНО: Release barrier - для записи volatile */
void memory_barrier_release(void) {
#ifdef _WIN32
    MemoryBarrier();
#elif defined(__GNUC__)
    __sync_synchronize();
#else
    memory_barrier();
#endif
}

bool atomic_cas_int(volatile jint* ptr, jint expected, jint newval) {
#ifdef _WIN32
    return InterlockedCompareExchange((LONG volatile*)ptr, newval, expected) == expected;
#elif defined(__GNUC__)
    return __sync_bool_compare_and_swap(ptr, expected, newval);
#else
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
#endif
}

bool atomic_cas_long(volatile jlong* ptr, jlong expected, jlong newval) {
#ifdef _WIN32
    return InterlockedCompareExchange64((LONG64 volatile*)ptr, newval, expected) == expected;
#elif defined(__GNUC__)
    return __sync_bool_compare_and_swap(ptr, expected, newval);
#else
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
#endif
}

bool atomic_cas_ptr(void* volatile* ptr, void* expected, void* newval) {
#ifdef _WIN32
    return InterlockedCompareExchangePointer(ptr, newval, expected) == expected;
#elif defined(__GNUC__)
    return __sync_bool_compare_and_swap(ptr, expected, newval);
#else
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
#endif
}

jint atomic_increment(volatile jint* ptr) {
#ifdef _WIN32
    return InterlockedIncrement((LONG volatile*)ptr);
#elif defined(__GNUC__)
    return __sync_add_and_fetch(ptr, 1);
#else
    return ++(*ptr);
#endif
}

jint atomic_decrement(volatile jint* ptr) {
#ifdef _WIN32
    return InterlockedDecrement((LONG volatile*)ptr);
#elif defined(__GNUC__)
    return __sync_sub_and_fetch(ptr, 1);
#else
    return --(*ptr);
#endif
}

jint atomic_add(volatile jint* ptr, jint value) {
#ifdef _WIN32
    return InterlockedAdd((LONG volatile*)ptr, value);
#elif defined(__GNUC__)
    return __sync_add_and_fetch(ptr, value);
#else
    *ptr += value;
    return *ptr;
#endif
}

/*
 * Lock-free queue - simplified
 */

void lfqueue_init(LFQueue* queue) {
    queue->head = NULL;
    queue->tail = NULL;
}

void lfqueue_push(LFQueue* queue, void* data) {
    LFQueueNode* node = (LFQueueNode*)malloc(sizeof(LFQueueNode));
    if (!node) return;
    
    node->data = data;
    node->next = NULL;
    
    if (queue->tail) {
        queue->tail->next = node;
    } else {
        queue->head = node;
    }
    queue->tail = node;
}

void* lfqueue_pop(LFQueue* queue) {
    if (!queue->head) return NULL;
    
    LFQueueNode* node = queue->head;
    void* data = node->data;
    queue->head = node->next;
    
    if (!queue->head) {
        queue->tail = NULL;
    }
    
    free(node);
    return data;
}

bool lfqueue_empty(LFQueue* queue) {
    return queue->head == NULL;
}
