/*
 * J2ME Emulator - Cooperative Multithreading Implementation
 * User-space thread scheduling with real context switching
 * 
 * Uses ucontext/makecontext/swapcontext for proper thread switching.
 * Each thread has its own stack, allowing true cooperative multitasking.
 */

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#ifdef MEM_FREE
#undef MEM_FREE
#endif
#else
#define _POSIX_C_SOURCE 200809L
/* Enable ucontext functions */
#define _XOPEN_SOURCE 700
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef _WIN32
#include <ucontext.h>
#endif

#include "threads.h"
#include "jvm.h"
#include "debug.h"

/* 
 * Global instruction counter for time-slicing 
 */
volatile uint64_t g_instruction_counter = 0;

/* Yield interval - switch threads after this many opcodes */
/* Increased to 100000 to allow loading to complete without interruption */
#define YIELD_INTERVAL 100000

/* Forward declarations */
static void memory_barrier_acquire(void);
static void memory_barrier_release(void);

/* Maximum number of cooperative threads */
#define MAX_COOP_THREADS 32

/* Stack size for each thread (64KB) */
#define THREAD_STACK_SIZE (64 * 1024)

/* Thread control block */
typedef struct CoopThread {
    JavaThread* java_thread;
    struct CoopThread* next;
    ThreadState state;
    jlong wake_time_ms;
    int priority;
    
#ifndef _WIN32
    ucontext_t context;       /* Thread context */
    void* stack;              /* Thread stack */
    int context_valid;        /* Whether context is initialized */
#endif
} CoopThread;

/* Forward declaration for thread wrapper */
static void thread_entry_wrapper(void);

/* Global scheduler state */
static struct {
    CoopThread* threads[MAX_COOP_THREADS];
    int thread_count;
    
    CoopThread* run_queue_head;
    CoopThread* run_queue_tail;
    
    CoopThread* sleep_list;
    
    CoopThread* current;
    JavaThread* main_thread;
    
    JVM* jvm;
    bool initialized;
    
#ifndef _WIN32
    ucontext_t main_context;    /* Main/scheduler context */
    ucontext_t* return_context; /* Context to return to after thread exits */
#endif
    
    /* Entry point for new threads */
    JavaMethod* entry_method;
    JavaObject* entry_obj;
    JavaThread* entry_java_thread;
} scheduler = {0};

/* Get current time in milliseconds */
static jlong get_time_ms(void) {
#ifdef _WIN32
    return (jlong)GetTickCount64();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
}

/* Initialize thread system */
int threads_init(JVM* jvm) {
    if (scheduler.initialized) return JNI_OK;
    
    scheduler.jvm = jvm;
    scheduler.thread_count = 0;
    scheduler.run_queue_head = NULL;
    scheduler.run_queue_tail = NULL;
    scheduler.sleep_list = NULL;
    scheduler.current = NULL;
    scheduler.main_thread = NULL;
    scheduler.initialized = true;
    
    return JNI_OK;
}

/* Check if thread is in run queue */
static bool is_in_run_queue(CoopThread* coop) {
    CoopThread* p = scheduler.run_queue_head;
    while (p) {
        if (p == coop) return true;
        p = p->next;
    }
    return false;
}

/* Add thread to run queue */
static void add_to_run_queue(CoopThread* coop) {
    if (!coop) return;
    
    if (is_in_run_queue(coop)) {
        THREAD_DEBUG("add_to_run_queue: thread %d already in queue", coop->java_thread->id);
        return;
    }
    
    coop->state = THREAD_STATE_RUNNABLE;
    coop->next = NULL;
    
    if (!scheduler.run_queue_head) {
        scheduler.run_queue_head = coop;
        scheduler.run_queue_tail = coop;
    } else {
        scheduler.run_queue_tail->next = coop;
        scheduler.run_queue_tail = coop;
    }
    
    THREAD_DEBUG("add_to_run_queue: added thread %d", coop->java_thread->id);
}

/* Remove thread from run queue head */
static CoopThread* remove_from_run_queue(void) {
    if (!scheduler.run_queue_head) return NULL;
    
    CoopThread* coop = scheduler.run_queue_head;
    scheduler.run_queue_head = coop->next;
    
    if (!scheduler.run_queue_head) {
        scheduler.run_queue_tail = NULL;
    }
    
    coop->next = NULL;
    return coop;
}

/* Remove specific thread from queue */
static bool remove_specific_from_queue(CoopThread* target) {
    if (!target || !scheduler.run_queue_head) return false;
    
    if (scheduler.run_queue_head == target) {
        scheduler.run_queue_head = target->next;
        if (!scheduler.run_queue_head) {
            scheduler.run_queue_tail = NULL;
        } else if (scheduler.run_queue_tail == target) {
            scheduler.run_queue_tail = NULL;
        }
        target->next = NULL;
        return true;
    }
    
    CoopThread* prev = scheduler.run_queue_head;
    CoopThread* curr = prev->next;
    
    while (curr) {
        if (curr == target) {
            prev->next = curr->next;
            if (scheduler.run_queue_tail == target) {
                scheduler.run_queue_tail = prev;
            }
            target->next = NULL;
            return true;
        }
        prev = curr;
        curr = curr->next;
    }
    
    return false;
}

/* Wake up sleeping threads */
static void wakeup_sleeping_threads(void) {
    jlong now = get_time_ms();
    
    while (scheduler.sleep_list && scheduler.sleep_list->wake_time_ms <= now) {
        CoopThread* coop = scheduler.sleep_list;
        scheduler.sleep_list = coop->next;
        coop->next = NULL;
        add_to_run_queue(coop);
    }
}

/* Create new Java thread */
JavaThread* thread_create(JVM* jvm, const char* name, jint priority, JavaObject* thread_obj) {
    (void)jvm;
    
    if (scheduler.thread_count >= MAX_COOP_THREADS) {
        THREAD_DEBUG("Maximum thread count reached");
        return NULL;
    }
    
    JavaThread* java_thread = (JavaThread*)calloc(1, sizeof(JavaThread));
    if (!java_thread) return NULL;
    
    java_thread->id = scheduler.thread_count + 1;
    java_thread->name = name ? strdup(name) : NULL;
    java_thread->priority = priority;
    java_thread->is_daemon = false;
    java_thread->is_alive = false;
    java_thread->thread_object = thread_obj;
    java_thread->current_frame = NULL;
    java_thread->pending_exception = NULL;
    java_thread->stack_size = JAVA_STACK_SIZE;
    java_thread->exec_jmp_buf = NULL;
    java_thread->exec_jmp_buf_valid = 0;
    
    /* Allocate stack for thread-local allocator */
    java_thread->stack_base = malloc(JAVA_STACK_SIZE);
    if (!java_thread->stack_base) {
        free(java_thread->name);
        free(java_thread);
        return NULL;
    }
    java_thread->stack_used = 0;
    
    java_thread->allocator.heap_size = 64 * 1024;
    java_thread->allocator.heap = malloc(java_thread->allocator.heap_size);
    java_thread->allocator.heap_used = 0;
    
    /* Create CoopThread wrapper */
    CoopThread* coop = (CoopThread*)calloc(1, sizeof(CoopThread));
    if (!coop) {
        free(java_thread->stack_base);
        free(java_thread->name);
        free(java_thread);
        return NULL;
    }
    
    coop->java_thread = java_thread;
    coop->state = THREAD_STATE_NEW;
    coop->priority = priority;
    coop->wake_time_ms = 0;
    coop->next = NULL;
    
#ifndef _WIN32
    /* Allocate stack for context switching */
    coop->stack = malloc(THREAD_STACK_SIZE);
    if (!coop->stack) {
        free(coop);
        free(java_thread->stack_base);
        free(java_thread->name);
        free(java_thread);
        return NULL;
    }
    coop->context_valid = 0;
#endif
    
    scheduler.threads[scheduler.thread_count++] = coop;
    
    /* Store main thread reference */
    if (name && strcmp(name, "main") == 0) {
        scheduler.main_thread = java_thread;
        scheduler.current = coop;
        coop->state = THREAD_STATE_RUNNABLE;
        java_thread->is_alive = true;
        
        scheduler.run_queue_head = coop;
        scheduler.run_queue_tail = coop;
    }
    
    THREAD_DEBUG("Created thread %d: %s (priority %d)", 
            java_thread->id, name ? name : "unnamed", priority);
    
    return java_thread;
}

/* Start a thread */
int thread_start(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return JNI_ERR;
    
    CoopThread* coop = NULL;
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            coop = scheduler.threads[i];
            break;
        }
    }
    
    if (!coop) {
        THREAD_DEBUG("Thread not found for start");
        return JNI_ERR;
    }
    
    if (coop->state != THREAD_STATE_NEW) {
        THREAD_DEBUG("Thread already started");
        return JNI_ERR;
    }
    
    thread->is_alive = true;
    add_to_run_queue(coop);
    
    THREAD_DEBUG("Thread %d started and added to run queue", thread->id);
    return JNI_OK;
}

/* Get current thread */
JavaThread* thread_current(JVM* jvm) {
    (void)jvm;
    return scheduler.current ? scheduler.current->java_thread : scheduler.main_thread;
}

/* Set current thread */
JavaThread* thread_set_current(JavaThread* thread) {
    JavaThread* prev = scheduler.current ? scheduler.current->java_thread : NULL;
    
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            scheduler.current = scheduler.threads[i];
            return prev;
        }
    }
    
    return prev;
}

/* Schedule next thread - cooperative context switch */
void thread_schedule(JVM* jvm) {
    (void)jvm;
    
    wakeup_sleeping_threads();
    
    /* If current thread is still runnable, put it back in queue */
    if (scheduler.current && 
        scheduler.current->state == THREAD_STATE_RUNNABLE &&
        scheduler.current->java_thread->is_alive) {
        add_to_run_queue(scheduler.current);
    }
    
    /* Get next thread from run queue */
    CoopThread* next = remove_from_run_queue();
    
    /* Skip if it's the same thread and there are others */
    if (next && next == scheduler.current && scheduler.run_queue_head) {
        add_to_run_queue(next);
        next = remove_from_run_queue();
    }
    
    if (next && next != scheduler.current) {
        THREAD_DEBUG("schedule: switching from thread %d to thread %d",
                scheduler.current ? scheduler.current->java_thread->id : 0,
                next->java_thread->id);
        
        CoopThread* prev = scheduler.current;
        scheduler.current = next;
        
#ifndef _WIN32
        if (prev && prev->context_valid) {
            /* Switch to next thread */
            swapcontext(&prev->context, &next->context);
        } else if (next->context_valid) {
            /* First time switching from main */
            setcontext(&next->context);
        }
#endif
    }
}

/* Thread entry wrapper - calls run() method */
static void thread_entry_wrapper(void) {
    if (!scheduler.current) return;
    
    JavaThread* java_thread = scheduler.current->java_thread;
    JavaMethod* method = scheduler.entry_method;
    JavaObject* obj = scheduler.entry_obj;
    
    THREAD_DEBUG("Thread entry: thread %d starting", java_thread->id);
    
    if (method && obj) {
        extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                                  JavaValue* args, JavaValue* result);
        JavaValue this_arg = { .ref = obj };
        JavaValue result;
        execute_method(scheduler.jvm, java_thread, method, &this_arg, &result);
    }
    
    THREAD_DEBUG("Thread entry: thread %d exiting", java_thread->id);
    
    /* Thread finished - mark as terminated */
    java_thread->is_alive = false;
    scheduler.current->state = THREAD_STATE_TERMINATED;
    
    /* Switch back to scheduler/main context */
#ifndef _WIN32
    if (scheduler.return_context) {
        setcontext(scheduler.return_context);
    }
#endif
}

/* Execute a thread's run method in its own context */
void thread_execute_run(JVM* jvm, JavaThread* java_thread, JavaMethod* run_method, JavaObject* run_obj) {
#ifndef _WIN32
    CoopThread* coop = NULL;
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == java_thread) {
            coop = scheduler.threads[i];
            break;
        }
    }
    
    if (!coop) return;
    
    /* Set up entry point */
    scheduler.entry_method = run_method;
    scheduler.entry_obj = run_obj;
    scheduler.entry_java_thread = java_thread;
    
    /* Initialize thread context */
    getcontext(&coop->context);
    
    coop->context.uc_stack.ss_sp = coop->stack;
    coop->context.uc_stack.ss_size = THREAD_STACK_SIZE;
    coop->context.uc_link = &scheduler.main_context;  /* Return to main when done */
    
    makecontext(&coop->context, thread_entry_wrapper, 0);
    coop->context_valid = 1;
    
    /* Save current context and switch to new thread */
    scheduler.return_context = &scheduler.main_context;
    
    /* CRITICAL: Set current to the new thread BEFORE swapcontext,
     * so thread_entry_wrapper sees the correct current thread */
    scheduler.current = coop;
    
    THREAD_DEBUG("thread_execute_run: switching to thread %d", java_thread->id);
    
    fprintf(stderr, "[EXEC_RUN_DEBUG] About to swapcontext to thread %d\n", java_thread->id);
    
    swapcontext(&scheduler.main_context, &coop->context);
    
    fprintf(stderr, "[EXEC_RUN_DEBUG] Returned from swapcontext, thread %d completed\n", java_thread->id);
    
    THREAD_DEBUG("thread_execute_run: returned from thread %d", java_thread->id);
    
    /* Restore current thread pointer */
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == scheduler.main_thread) {
            scheduler.current = scheduler.threads[i];
            break;
        }
    }
#else
    /* Windows: just execute synchronously */
    extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                              JavaValue* args, JavaValue* result);
    JavaValue this_arg = { .ref = run_obj };
    JavaValue result;
    execute_method(jvm, java_thread, run_method, &this_arg, &result);
    java_thread->is_alive = false;
#endif
}

/* Yield to other threads */
void thread_yield(JVM* jvm) {
    (void)jvm;
    if (!scheduler.initialized || !scheduler.current) return;
    
    wakeup_sleeping_threads();
    
    /* Process SDL events */
    extern void sdl_process_events_minimal(void);
    sdl_process_events_minimal();
    
    /* Check if there are other runnable threads */
    bool has_other = false;
    CoopThread* p = scheduler.run_queue_head;
    while (p) {
        if (p != scheduler.current && p->java_thread->is_alive) {
            has_other = true;
            break;
        }
        p = p->next;
    }
    
    /* Always print this for debugging thread issues */
    fprintf(stderr, "[YIELD_DEBUG] thread %d yielding, has_other=%d, queue_head=%p, current=%p\n",
            scheduler.current ? scheduler.current->java_thread->id : 0,
            has_other, (void*)scheduler.run_queue_head, (void*)scheduler.current);
    fflush(stderr);
    
    if (!has_other) {
        /* No other threads to run, just return */
        fprintf(stderr, "[YIELD_DEBUG] No other threads, returning\n");
        return;
    }
    
#ifndef _WIN32
    /* Save current context */
    if (scheduler.current->context_valid) {
        /* Put current thread back in queue */
        if (scheduler.current->java_thread->is_alive) {
            scheduler.current->state = THREAD_STATE_RUNNABLE;
            add_to_run_queue(scheduler.current);
        }
        
        /* Get next thread */
        CoopThread* next = remove_from_run_queue();
        if (next && next != scheduler.current) {
            THREAD_DEBUG("thread_yield: thread %d -> thread %d",
                    scheduler.current->java_thread->id, next->java_thread->id);
            
            /* CRITICAL: Save prev BEFORE updating current, so we save the correct context */
            CoopThread* prev = scheduler.current;
            scheduler.current = next;
            
            /* Main thread's context is in scheduler.main_context, not CoopThread.context */
            ucontext_t* next_ctx = (next->java_thread == scheduler.main_thread) 
                                   ? &scheduler.main_context 
                                   : &next->context;
            
            fprintf(stderr, "[YIELD_DEBUG] Switching from thread %d to thread %d (ctx=%p)\n",
                    prev->java_thread->id, next->java_thread->id, (void*)next_ctx);
            
            swapcontext(&prev->context, next_ctx);
            
            fprintf(stderr, "[YIELD_DEBUG] Returned from swapcontext in thread %d\n",
                    scheduler.current ? scheduler.current->java_thread->id : 0);
        }
    } else {
        /* First yield - save context and then switch */
        CoopThread* prev = scheduler.current;
        if (getcontext(&prev->context) == 0) {
            prev->context_valid = 1;
            
            /* Now do the actual context switch */
            /* Put current thread back in queue */
            if (prev->java_thread->is_alive) {
                prev->state = THREAD_STATE_RUNNABLE;
                add_to_run_queue(prev);
            }
            
            /* Get next thread */
            CoopThread* next = remove_from_run_queue();
            if (next && next != prev) {
                THREAD_DEBUG("thread_yield (first): thread %d -> thread %d",
                        prev->java_thread->id, next->java_thread->id);
                
                scheduler.current = next;
                
                /* Main thread's context is in scheduler.main_context */
                ucontext_t* next_ctx = (next->java_thread == scheduler.main_thread) 
                                       ? &scheduler.main_context 
                                       : &next->context;
                
                setcontext(next_ctx);
            }
        }
    }
#endif
}

/* Check if it's time to yield */
bool thread_should_yield(void) {
    return (g_instruction_counter % YIELD_INTERVAL) == 0;
}

/* Increment counter and yield if needed */
void thread_tick(JVM* jvm) {
    g_instruction_counter++;
    
    /* Debug: print every 1 million opcodes */
    if ((g_instruction_counter % 1000000) == 0) {
        fprintf(stderr, "[TICK_DEBUG] %llu opcodes executed, current thread: %d\n",
                (unsigned long long)g_instruction_counter,
                scheduler.current ? scheduler.current->java_thread->id : 0);
    }
    
    if ((g_instruction_counter % YIELD_INTERVAL) == 0) {
        thread_yield(jvm);
    }
}

/* Get instruction counter */
uint64_t thread_get_instruction_counter(void) {
    return g_instruction_counter;
}

/* Sleep for milliseconds */
int thread_sleep(JVM* jvm, jlong millis) {
    (void)jvm;
    
    if (millis < 0) millis = 0;
    if (millis > 10000) millis = 10000;
    
    THREAD_DEBUG("Thread %d sleeping for %lld ms",
            scheduler.current ? scheduler.current->java_thread->id : 0, (long long)millis);
    
    wakeup_sleeping_threads();
    
    extern void sdl_process_events_minimal(void);
    sdl_process_events_minimal();
    
    if (millis > 0) {
#ifdef _WIN32
        Sleep((DWORD)millis);
#else
        struct timespec ts = {
            .tv_sec = millis / 1000,
            .tv_nsec = (millis % 1000) * 1000000
        };
        nanosleep(&ts, NULL);
#endif
    }
    
    return JNI_OK;
}

/* Check if thread is alive */
bool thread_is_alive(JavaThread* thread) {
    if (!thread) return false;
    return thread->is_alive;
}

/* Get thread state */
ThreadState thread_get_state(JavaThread* thread) {
    if (!thread) return THREAD_STATE_NEW;
    
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            return scheduler.threads[i]->state;
        }
    }
    
    return THREAD_STATE_TERMINATED;
}

/* Set thread priority */
void thread_set_priority(JavaThread* thread, jint priority) {
    if (!thread) return;
    
    thread->priority = priority;
    
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            scheduler.threads[i]->priority = priority;
            break;
        }
    }
}

/* Interrupt a thread */
void thread_interrupt(JavaThread* thread) {
    if (!thread) return;
    
    thread->interrupted = true;
}

/* Check if thread is interrupted */
bool thread_is_interrupted(JavaThread* thread, bool clear_flag) {
    if (!thread) return false;
    bool interrupted = thread->interrupted;
    if (clear_flag) thread->interrupted = false;
    return interrupted;
}

/* Destroy a thread */
void thread_destroy(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return;
    
    for (int i = 0; i < scheduler.thread_count; i++) {
        if (scheduler.threads[i]->java_thread == thread) {
            CoopThread* coop = scheduler.threads[i];
            coop->state = THREAD_STATE_TERMINATED;
            thread->is_alive = false;
            
#ifndef _WIN32
            if (coop->stack) {
                free(coop->stack);
                coop->stack = NULL;
            }
#endif
            break;
        }
    }
    
    free(thread->name);
    free(thread->stack_base);
    if (thread->allocator.heap) {
        free(thread->allocator.heap);
    }
    free(thread);
}

/* Check if there are runnable threads */
bool threads_has_runnable(void) {
    wakeup_sleeping_threads();
    return scheduler.run_queue_head != NULL;
}

/* Get current CoopThread */
void* thread_current_coop(void) {
    return scheduler.current;
}

/*
 * Monitor functions
 */

typedef struct {
    JavaObject* owner;
    JavaThread* owner_thread;
    jint entry_count;
    CoopThread* wait_list;
    volatile jint spinlock;
} CoopMonitor;

static CoopMonitor g_monitors[256];
static volatile jint g_monitors_initialized = 0;

static void init_monitors(void) {
    if (atomic_cas_int(&g_monitors_initialized, 0, 1)) {
        memset(g_monitors, 0, sizeof(g_monitors));
    }
}

static void monitor_spinlock_acquire(CoopMonitor* mon) {
    while (atomic_cas_int(&mon->spinlock, 0, 1) == false) {
#ifdef _WIN32
        YieldProcessor();
#elif defined(__GNUC__)
        __builtin_ia32_pause();
#endif
    }
    memory_barrier_acquire();
}

static void monitor_spinlock_release(CoopMonitor* mon) {
    memory_barrier_release();
    mon->spinlock = 0;
}

static CoopMonitor* get_monitor(JavaObject* obj) {
    init_monitors();
    size_t idx = ((size_t)obj >> 4) & 0xFF;
    return &g_monitors[idx];
}

int monitor_enter(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    monitor_spinlock_acquire(mon);
    
    if (mon->owner_thread == NULL) {
        mon->owner = obj;
        mon->owner_thread = current_thread;
        mon->entry_count = 1;
        monitor_spinlock_release(mon);
        return JNI_OK;
    }
    
    if (current_thread == mon->owner_thread) {
        mon->entry_count++;
        monitor_spinlock_release(mon);
        return JNI_OK;
    }
    
    monitor_spinlock_release(mon);
    thread_yield(jvm);
    
    return monitor_enter(jvm, obj);
}

int monitor_exit(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    monitor_spinlock_acquire(mon);
    
    if (mon->owner_thread != current_thread) {
        monitor_spinlock_release(mon);
        return JNI_ERR;
    }
    
    mon->entry_count--;
    if (mon->entry_count == 0) {
        mon->owner = NULL;
        mon->owner_thread = NULL;
        
        if (mon->wait_list) {
            CoopThread* waiter = mon->wait_list;
            mon->wait_list = waiter->next;
            waiter->next = NULL;
            monitor_spinlock_release(mon);
            add_to_run_queue(waiter);
            return JNI_OK;
        }
    }
    
    monitor_spinlock_release(mon);
    return JNI_OK;
}

int monitor_wait(JVM* jvm, JavaObject* obj, jlong timeout, bool timed) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    monitor_spinlock_acquire(mon);
    
    if (mon->owner_thread != current_thread) {
        monitor_spinlock_release(mon);
        return JNI_ERR;
    }
    
    jint saved_count = mon->entry_count;
    mon->owner = NULL;
    mon->owner_thread = NULL;
    mon->entry_count = 0;
    
    if (scheduler.current) {
        scheduler.current->next = mon->wait_list;
        mon->wait_list = scheduler.current;
        scheduler.current->state = timed ? THREAD_STATE_TIMED_WAITING : THREAD_STATE_WAITING;
        
        if (timed && timeout > 0) {
            scheduler.current->wake_time_ms = get_time_ms() + timeout;
        }
    }
    
    monitor_spinlock_release(mon);
    
    thread_yield(jvm);
    
    /* Re-acquire monitor */
    monitor_spinlock_acquire(mon);
    while (mon->owner_thread != NULL) {
        monitor_spinlock_release(mon);
        thread_yield(jvm);
        monitor_spinlock_acquire(mon);
    }
    mon->owner = obj;
    mon->owner_thread = current_thread;
    mon->entry_count = saved_count;
    monitor_spinlock_release(mon);
    
    return JNI_OK;
}

int monitor_notify(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    monitor_spinlock_acquire(mon);
    
    if (mon->owner_thread != current_thread) {
        monitor_spinlock_release(mon);
        return JNI_ERR;
    }
    
    if (mon->wait_list) {
        CoopThread* waiter = mon->wait_list;
        mon->wait_list = waiter->next;
        waiter->next = NULL;
        monitor_spinlock_release(mon);
        add_to_run_queue(waiter);
        return JNI_OK;
    }
    
    monitor_spinlock_release(mon);
    return JNI_OK;
}

int monitor_notify_all(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    if (!obj) return JNI_ERR;
    
    CoopMonitor* mon = get_monitor(obj);
    JavaThread* current_thread = scheduler.current ? scheduler.current->java_thread : NULL;
    
    monitor_spinlock_acquire(mon);
    
    if (mon->owner_thread != current_thread) {
        monitor_spinlock_release(mon);
        return JNI_ERR;
    }
    
    while (mon->wait_list) {
        CoopThread* waiter = mon->wait_list;
        mon->wait_list = waiter->next;
        waiter->next = NULL;
        add_to_run_queue(waiter);
    }
    
    monitor_spinlock_release(mon);
    return JNI_OK;
}

JavaMonitor* monitor_get(JVM* jvm, JavaObject* obj) {
    (void)jvm; (void)obj;
    return NULL;
}

JavaThread* monitor_get_owner(JavaObject* obj) {
    if (!obj) return NULL;
    CoopMonitor* mon = get_monitor(obj);
    monitor_spinlock_acquire(mon);
    JavaThread* owner = mon->owner_thread;
    monitor_spinlock_release(mon);
    return owner;
}

jint monitor_get_entry_count(JavaObject* obj) {
    if (!obj) return 0;
    CoopMonitor* mon = get_monitor(obj);
    monitor_spinlock_acquire(mon);
    jint count = mon->entry_count;
    monitor_spinlock_release(mon);
    return count;
}

/*
 * Thread-local storage
 */
int thread_local_create(ThreadLocalKey* key) {
    *key = 0;
    return JNI_OK;
}

int thread_local_set(ThreadLocalKey key, void* value) {
    (void)key; (void)value;
    return JNI_OK;
}

void* thread_local_get(ThreadLocalKey key) {
    (void)key;
    return NULL;
}

void thread_local_delete(ThreadLocalKey key) {
    (void)key;
}

/*
 * Atomic operations
 */
void memory_barrier(void) {
#ifdef _WIN32
    MemoryBarrier();
#elif defined(__GNUC__)
    __sync_synchronize();
#endif
}

void memory_barrier_acquire(void) {
    memory_barrier();
}

void memory_barrier_release(void) {
    memory_barrier();
}

bool atomic_cas_int(volatile jint* ptr, jint expected, jint newval) {
#ifdef _WIN32
    return InterlockedCompareExchange((LONG volatile*)ptr, newval, expected) == expected;
#elif defined(__GNUC__)
    return __sync_bool_compare_and_swap(ptr, expected, newval);
#else
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
#endif
}

bool atomic_cas_long(volatile jlong* ptr, jlong expected, jlong newval) {
#ifdef _WIN32
    return InterlockedCompareExchange64((LONG64 volatile*)ptr, newval, expected) == expected;
#elif defined(__GNUC__)
    return __sync_bool_compare_and_swap(ptr, expected, newval);
#else
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
#endif
}

bool atomic_cas_ptr(void* volatile* ptr, void* expected, void* newval) {
#ifdef _WIN32
    return InterlockedCompareExchangePointer(ptr, newval, expected) == expected;
#elif defined(__GNUC__)
    return __sync_bool_compare_and_swap(ptr, expected, newval);
#else
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
#endif
}

jint atomic_increment(volatile jint* ptr) {
#ifdef _WIN32
    return InterlockedIncrement((LONG volatile*)ptr);
#elif defined(__GNUC__)
    return __sync_add_and_fetch(ptr, 1);
#else
    return ++(*ptr);
#endif
}

jint atomic_decrement(volatile jint* ptr) {
#ifdef _WIN32
    return InterlockedDecrement((LONG volatile*)ptr);
#elif defined(__GNUC__)
    return __sync_sub_and_fetch(ptr, 1);
#else
    return --(*ptr);
#endif
}

jint atomic_add(volatile jint* ptr, jint value) {
#ifdef _WIN32
    return InterlockedAdd((LONG volatile*)ptr, value);
#elif defined(__GNUC__)
    return __sync_add_and_fetch(ptr, value);
#else
    *ptr += value;
    return *ptr;
#endif
}

/*
 * Lock-free queue
 */
void lfqueue_init(LFQueue* queue) {
    if (queue) {
        queue->head = NULL;
        queue->tail = NULL;
    }
}

int lfqueue_push(LFQueue* queue, void* data) {
    if (!queue) return -1;
    
    LFQueueNode* node = (LFQueueNode*)malloc(sizeof(LFQueueNode));
    if (!node) return -1;
    
    node->data = data;
    node->next = NULL;
    
    if (queue->tail) {
        queue->tail->next = node;
    } else {
        queue->head = node;
    }
    queue->tail = node;
    
    return 0;
}

void* lfqueue_pop(LFQueue* queue) {
    if (!queue || !queue->head) return NULL;
    
    LFQueueNode* node = queue->head;
    void* data = node->data;
    queue->head = node->next;
    
    if (!queue->head) {
        queue->tail = NULL;
    }
    
    free(node);
    return data;
}

bool lfqueue_empty(LFQueue* queue) {
    return !queue || queue->head == NULL;
}

void lfqueue_destroy(LFQueue* queue) {
    if (!queue) return;
    
    while (queue->head) {
        LFQueueNode* node = queue->head;
        queue->head = node->next;
        free(node);
    }
    queue->tail = NULL;
}