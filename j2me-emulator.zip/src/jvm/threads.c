/*
 * J2ME Emulator - Thread Management (Simplified/Single-threaded)
 * All threading operations are stubs - no actual threads created
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "threads.h"
#include "jvm.h"

/* Single main thread - no threading */
static JavaThread* main_thread = NULL;

/* Initialize thread system */
int threads_init(JVM* jvm) {
    (void)jvm;
    /* Nothing to initialize in single-threaded mode */
    return JNI_OK;
}

/* Create new Java thread (just allocates structure, doesn't start) */
JavaThread* thread_create(JVM* jvm, const char* name, jint priority, JavaObject* thread_obj) {
    (void)jvm;
    
    JavaThread* thread = (JavaThread*)calloc(1, sizeof(JavaThread));
    if (!thread) return NULL;
    
    thread->id = 1;  /* Single thread ID */
    thread->name = name ? strdup(name) : NULL;
    thread->priority = priority;
    thread->is_daemon = false;
    thread->is_alive = (name && strcmp(name, "main") == 0);  /* Only main is "alive" */
    thread->thread_object = thread_obj;
    thread->current_frame = NULL;
    thread->pending_exception = NULL;
    
    /* No actual stack allocation - we use Java stack in frames */
    thread->stack_size = 0;
    thread->stack_base = NULL;
    
    /* Store main thread */
    if (name && strcmp(name, "main") == 0) {
        main_thread = thread;
    }
    
    return thread;
}

/* Start a thread - does nothing in single-threaded mode */
int thread_start(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return JNI_ERR;
    thread->is_alive = true;
    return JNI_OK;
}

/* Join a thread - does nothing */
int thread_join(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    (void)thread;
    return JNI_OK;
}

/* Get current thread - always returns main thread */
JavaThread* thread_current(JVM* jvm) {
    (void)jvm;
    return main_thread;
}

/* Yield to other threads - does nothing */
void thread_yield(JVM* jvm) {
    (void)jvm;
}

/* Sleep for milliseconds */
int thread_sleep(JVM* jvm, jlong millis) {
    (void)jvm;
    (void)millis;
    /* No actual sleep in headless mode */
    return JNI_OK;
}

/* Check if thread is alive */
bool thread_is_alive(JavaThread* thread) {
    return thread ? thread->is_alive : false;
}

/* Get thread state */
ThreadState thread_get_state(JavaThread* thread) {
    if (!thread) return THREAD_STATE_NEW;
    if (thread->is_alive) return THREAD_STATE_RUNNABLE;
    return THREAD_STATE_TERMINATED;
}

/* Set thread priority */
void thread_set_priority(JavaThread* thread, jint priority) {
    if (thread) thread->priority = priority;
}

/* Interrupt a thread */
void thread_interrupt(JavaThread* thread) {
    if (thread) thread->interrupted = true;
}

/* Check if thread is interrupted */
bool thread_is_interrupted(JavaThread* thread, bool clear_flag) {
    if (!thread) return false;
    bool interrupted = thread->interrupted;
    if (clear_flag) thread->interrupted = false;
    return interrupted;
}

/* Destroy a thread */
void thread_destroy(JVM* jvm, JavaThread* thread) {
    (void)jvm;
    if (!thread) return;
    
    free(thread->name);
    free(thread->stack_base);
    free(thread);
    
    if (thread == main_thread) {
        main_thread = NULL;
    }
}

/*
 * Monitor functions (synchronization) - all stubs
 */

/* Enter monitor (acquire lock) */
int monitor_enter(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    (void)obj;
    return JNI_OK;  /* Always succeeds in single-threaded mode */
}

/* Exit monitor (release lock) */
int monitor_exit(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    (void)obj;
    return JNI_OK;
}

/* Wait on monitor */
int monitor_wait(JVM* jvm, JavaObject* obj, jlong timeout, bool timed) {
    (void)jvm;
    (void)obj;
    (void)timeout;
    (void)timed;
    return JNI_OK;  /* Does nothing */
}

/* Notify one thread waiting on monitor */
int monitor_notify(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    (void)obj;
    return JNI_OK;
}

/* Notify all threads waiting on monitor */
int monitor_notify_all(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    (void)obj;
    return JNI_OK;
}

/* Get monitor for object */
JavaMonitor* monitor_get(JVM* jvm, JavaObject* obj) {
    (void)jvm;
    (void)obj;
    return NULL;  /* No monitors in single-threaded mode */
}

/* Get current monitor owner */
JavaThread* monitor_get_owner(JavaObject* obj) {
    (void)obj;
    return NULL;
}

/* Get monitor entry count */
jint monitor_get_entry_count(JavaObject* obj) {
    (void)obj;
    return 0;
}

/*
 * Thread-local storage - simplified
 */

/* Create thread-local key */
int thread_local_create(ThreadLocalKey* key) {
    *key = 0;
    return JNI_OK;
}

/* Set thread-local value */
int thread_local_set(ThreadLocalKey key, void* value) {
    (void)key;
    (void)value;
    return JNI_OK;
}

/* Get thread-local value */
void* thread_local_get(ThreadLocalKey key) {
    (void)key;
    return NULL;
}

/* Delete thread-local key */
void thread_local_delete(ThreadLocalKey key) {
    (void)key;
}

/*
 * Atomic operations - simplified without actual atomics
 */

/* Atomic compare and swap for int */
bool atomic_cas_int(volatile jint* ptr, jint expected, jint newval) {
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
}

/* Atomic compare and swap for long */
bool atomic_cas_long(volatile jlong* ptr, jlong expected, jlong newval) {
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
}

/* Atomic compare and swap for pointer */
bool atomic_cas_ptr(void* volatile* ptr, void* expected, void* newval) {
    if (*ptr == expected) {
        *ptr = newval;
        return true;
    }
    return false;
}

/* Atomic increment */
jint atomic_increment(volatile jint* ptr) {
    return ++(*ptr);
}

/* Atomic decrement */
jint atomic_decrement(volatile jint* ptr) {
    return --(*ptr);
}

/* Atomic add */
jint atomic_add(volatile jint* ptr, jint value) {
    *ptr += value;
    return *ptr;
}

/* Memory barrier */
void memory_barrier(void) {
    /* No-op in single-threaded mode */
}

/*
 * Lock-free data structures - simplified
 */

/* Initialize lock-free queue */
void lfqueue_init(LFQueue* queue) {
    queue->head = NULL;
    queue->tail = NULL;
}

/* Push to queue */
void lfqueue_push(LFQueue* queue, void* data) {
    LFQueueNode* node = (LFQueueNode*)malloc(sizeof(LFQueueNode));
    if (!node) return;
    node->data = data;
    node->next = NULL;
    
    if (queue->tail) {
        queue->tail->next = node;
    } else {
        queue->head = node;
    }
    queue->tail = node;
}

/* Pop from queue */
void* lfqueue_pop(LFQueue* queue) {
    if (!queue->head) return NULL;
    
    LFQueueNode* node = queue->head;
    void* data = node->data;
    queue->head = node->next;
    if (!queue->head) queue->tail = NULL;
    
    free(node);
    return data;
}

/* Check if queue is empty */
bool lfqueue_empty(LFQueue* queue) {
    return queue->head == NULL;
}
