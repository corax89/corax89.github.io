/*
 * J2ME Emulator - Libretro Core Implementation
 * Упрощенная версия
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>

#include "libretro.h"
#include "libretro_shared.h"
#include "jvm.h"
#include "midp.h"
#include "native.h"
#include "opcodes.h"
#include "sdl_backend.h"

/* Определяем недостающие константы если их нет */
#ifndef RETRO_REGION_NTSC
#define RETRO_REGION_NTSC 0
#endif

#ifndef RETRO_REGION_PAL
#define RETRO_REGION_PAL 1
#endif

/* ============================================
 * Глобальное состояние
 * ============================================ */

static JVM* g_jvm = NULL;
static uint8_t* g_jar_data = NULL;
static size_t g_jar_size = 0;
static char g_midlet_class[256] = {0};

/* Framebuffer - прямой массив */
static uint16_t g_framebuffer[240 * 320];  /* Максимальный размер */
static int g_screen_width = 240;
static int g_screen_height = 320;
static int g_screen_pitch = 240 * 2;  /* 240 * 2 bytes per pixel (RGB565) */

/* Клавиши */
static int g_key_states = 0;

/* Libretro callbacks - ИСПРАВЛЕНО: используем те же имена что и в shared.h */
retro_environment_t environ_cb = NULL;
retro_video_refresh_t video_cb = NULL;
retro_audio_sample_batch_t audio_batch_cb = NULL;
retro_input_poll_t input_poll_cb = NULL;
retro_input_state_t input_state_cb = NULL;
static retro_log_printf_t log_cb = NULL;  /* Это может быть static */

/* Время */
static uint64_t last_frame_time = 0;
static uint64_t frame_accumulator = 0;

/* ============================================
 * Функция получения времени
 * ============================================ */

static uint64_t millis(void) {
    struct timeval time;
    gettimeofday(&time, NULL);
    return time.tv_sec * 1000 + time.tv_usec / 1000;
}

/* ============================================
 * Логирование
 * ============================================ */

static void fallback_log(enum retro_log_level level, const char *fmt, ...) {
    (void)level;
    va_list va;
    va_start(va, fmt);
    vfprintf(stderr, fmt, va);
    va_end(va);
}

static void log_message(enum retro_log_level level, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    
    if (log_cb) {
        char buffer[1024];
        vsnprintf(buffer, sizeof(buffer), fmt, args);
        log_cb(level, "%s", buffer);
    } else {
        vfprintf(stderr, fmt, args);
    }
    
    va_end(args);
}

/* ============================================
 * Функции для доступа из stubs
 * ============================================ */

uint16_t* libretro_get_framebuffer(void) {
    return g_framebuffer;
}

int libretro_get_screen_width(void) {
    return g_screen_width;
}

int libretro_get_screen_height(void) {
    return g_screen_height;
}

void libretro_set_key_states(int states) {
    g_key_states = states;
}

int libretro_get_key_states(void) {
    return g_key_states;
}

/* ============================================
 * Инициализация JVM
 * ============================================ */

static bool init_emulator(void) {
    log_message(RETRO_LOG_INFO, "[J2ME] Initializing emulator...\n");
    
    /* Создаем JVM */
    g_jvm = jvm_create();
    if (!g_jvm) {
        log_message(RETRO_LOG_ERROR, "[J2ME] Failed to create JVM\n");
        return false;
    }
    
    /* Минимальная конфигурация */
    g_jvm->config.heap_size = 16 * 1024 * 1024;  /* 16 MB */
    g_jvm->config.stack_size = 64 * 1024;
    g_jvm->config.max_threads = 8;
    g_jvm->config.verbose_class = false;
    
    /* Инициализация */
    if (jvm_init(g_jvm) != JNI_OK) {
        log_message(RETRO_LOG_ERROR, "[J2ME] JVM init failed\n");
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    /* SDL контекст - минимальный */
    SdlContext* ctx = calloc(1, sizeof(SdlContext));
    if (!ctx) {
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    ctx->framebuffer = (uint32_t*)g_framebuffer;
    ctx->width = g_screen_width;
    ctx->height = g_screen_height;
    ctx->scale = 1;
    ctx->jvm = g_jvm;
    ctx->running = true;
    ctx->target_fps = 30;
    
    sdl_set_global_context(ctx);
    
    /* Инициализация native методов */
    if (native_init(g_jvm) != JNI_OK) {
        log_message(RETRO_LOG_ERROR, "[J2ME] native_init failed\n");
        free(ctx);
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    /* Инициализация MIDP */
    if (midp_init(g_jvm) != JNI_OK) {
        log_message(RETRO_LOG_ERROR, "[J2ME] midp_init failed\n");
        free(ctx);
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    /* Инициализация opcodes */
    opcodes_init();
    
    log_message(RETRO_LOG_INFO, "[J2ME] Emulator initialized\n");
    return true;
}

/* ============================================
 * Запуск MIDlet
 * ============================================ */

static bool run_midlet(void) {
    if (!g_jvm || !g_jar_data) return false;
    
    log_message(RETRO_LOG_INFO, "[J2ME] Starting MIDlet: %s\n", g_midlet_class);
    
    /* Set JAR data */
    jvm_set_jar_data(g_jvm, g_jar_data, g_jar_size, "game.jar");
    
    /* Convert class name */
    char class_name[256];
    strncpy(class_name, g_midlet_class, sizeof(class_name) - 1);
    class_name[sizeof(class_name) - 1] = '\0';
    
    for (char* p = class_name; *p; p++) {
        if (*p == '.') *p = '/';
    }
    
    /* Load class */
    JavaClass* main_class = jvm_load_class(g_jvm, class_name);
    if (!main_class) {
        log_message(RETRO_LOG_ERROR, "[J2ME] Failed to load class %s\n", class_name);
        return false;
    }
    
    /* Run */
    int result = jvm_run_midlet(g_jvm, main_class);
    if (result != 0) {
        log_message(RETRO_LOG_ERROR, "[J2ME] MIDlet execution failed: %d\n", result);
        return false;
    }
    
    log_message(RETRO_LOG_INFO, "[J2ME] MIDlet started\n");
    return true;
}

/* ============================================
 * Libretro API
 * ============================================ */

unsigned retro_api_version(void) {
    return RETRO_API_VERSION;
}

void retro_init(void) {
    fprintf(stderr, "[J2ME] retro_init\n");
    
    /* Просто инициализируем время */
    uint64_t current_time = millis();
    last_frame_time = current_time;
    frame_accumulator = 0;
    
    /* Очищаем фреймбуфер */
    memset(g_framebuffer, 0, sizeof(g_framebuffer));
}

void retro_deinit(void) {
    fprintf(stderr, "[J2ME] retro_deinit\n");
    
    if (g_jvm) {
        jvm_destroy(g_jvm);
        g_jvm = NULL;
    }
    
    if (g_jar_data) {
        free(g_jar_data);
        g_jar_data = NULL;
    }
}

void retro_set_controller_port_device(unsigned port, unsigned device) {
    (void)port;
    (void)device;
}

void retro_get_system_info(struct retro_system_info *info) {
    memset(info, 0, sizeof(*info));
    info->library_name = "J2ME";
    info->library_version = "1.0";
    info->need_fullpath = true;
    info->valid_extensions = "jar";
}

void retro_get_system_av_info(struct retro_system_av_info *info) {
    info->timing.fps = 30.0;
    info->timing.sample_rate = 22050;
    
    info->geometry.base_width = g_screen_width;
    info->geometry.base_height = g_screen_height;
    info->geometry.max_width = 640;
    info->geometry.max_height = 480;
    info->geometry.aspect_ratio = (float)g_screen_width / (float)g_screen_height;
}

void retro_set_environment(retro_environment_t cb) {
    environ_cb = cb;
    
    /* Get log interface */
    struct retro_log_callback logging;
    if (cb(RETRO_ENVIRONMENT_GET_LOG_INTERFACE, &logging)) {
        log_cb = logging.log;
    } else {
        log_cb = fallback_log;
    }
    
    log_message(RETRO_LOG_INFO, "[J2ME] retro_set_environment\n");
    
    /* No content mode */
    bool no_content = false;
    cb(RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME, &no_content);
}

void retro_set_audio_sample(retro_audio_sample_t cb) {
    (void)cb;  /* Not used */
}

void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) {
    audio_batch_cb = cb;
}

void retro_set_input_poll(retro_input_poll_t cb) {
    input_poll_cb = cb;
}

void retro_set_input_state(retro_input_state_t cb) {
    input_state_cb = cb;
}

void retro_set_video_refresh(retro_video_refresh_t cb) {
    video_cb = cb;
}

void retro_reset(void) {
    fprintf(stderr, "[J2ME] retro_reset\n");
    g_key_states = 0;
}

bool retro_load_game(const struct retro_game_info *info) {
    fprintf(stderr, "[J2ME] retro_load_game: %s\n", info ? info->path : "NULL");
    
    if (!info || !info->path) {
        fprintf(stderr, "[J2ME] No game path\n");
        return false;
    }
    
    /* Load JAR file */
    FILE* f = fopen(info->path, "rb");
    if (!f) {
        fprintf(stderr, "[J2ME] Cannot open file\n");
        return false;
    }
    
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    
    g_jar_data = malloc(size);
    if (!g_jar_data) {
        fclose(f);
        return false;
    }
    
    if (fread(g_jar_data, 1, size, f) != (size_t)size) {
        free(g_jar_data);
        fclose(f);
        return false;
    }
    fclose(f);
    g_jar_size = size;
    
    fprintf(stderr, "[J2ME] JAR loaded: %ld bytes\n", size);
    
    /* Hardcode MIDlet class for testing */
    strcpy(g_midlet_class, "ArrayTest");
    
    /* Set pixel format */
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_RGB565;
    if (!environ_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) {
        fprintf(stderr, "[J2ME] RGB565 not supported\n");
        return false;
    }
    
    /* Input descriptors */
    static const struct retro_input_descriptor desc[] = {
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP,    "Up" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN,  "Down" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT,  "Left" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT, "Right" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A,     "Fire" },
        { 0 },
    };
    environ_cb(RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS, (void*)desc);
    
    /* Initialize emulator */
    if (!init_emulator()) {
        fprintf(stderr, "[J2ME] Emulator init failed\n");
        return false;
    }
    
    /* Run MIDlet */
    run_midlet();
    
    fprintf(stderr, "[J2ME] Game loaded successfully\n");
    return true;
}

bool retro_load_game_special(unsigned type, const struct retro_game_info *info, size_t num) {
    (void)type;
    (void)info;
    (void)num;
    return false;
}

void retro_unload_game(void) {
    fprintf(stderr, "[J2ME] retro_unload_game\n");
}

void retro_run(void) {
    /* Get current time */
    uint64_t current_time = millis();
    uint64_t delta_time = current_time - last_frame_time;
    last_frame_time = current_time;
    
    frame_accumulator += delta_time;
    
    /* Target frame time for 30 FPS = 33.33 ms */
    uint32_t target_frame_time = 33;
    
    if (frame_accumulator >= target_frame_time) {
        /* Limit max frameskip */
        if (frame_accumulator > target_frame_time * 3) {
            frame_accumulator = target_frame_time * 2;
        }
        
        /* Poll input */
        if (input_poll_cb) input_poll_cb();
        
        /* Process input */
        int keys = 0;
        if (input_state_cb) {
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP)) keys |= (1 << 1);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN)) keys |= (1 << 6);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT)) keys |= (1 << 2);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT)) keys |= (1 << 5);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A)) keys |= (1 << 8);
        }
        g_key_states = keys;
        
        /* Run emulation for accumulated frames */
        while (frame_accumulator >= target_frame_time) {
            /* TODO: Run JVM for one frame */
            /* jvm_run_frame(g_jvm); */
            
            frame_accumulator -= target_frame_time;
        }
        
        /* Send frame to frontend */
        if (video_cb) {
            video_cb(g_framebuffer, g_screen_width, g_screen_height, g_screen_pitch);
        }
    }
}

/* Save states (minimal) */
size_t retro_serialize_size(void) {
    return 0;
}

bool retro_serialize(void *data, size_t size) {
    (void)data;
    (void)size;
    return false;
}

bool retro_unserialize(const void *data, size_t size) {
    (void)data;
    (void)size;
    return false;
}

void retro_cheat_reset(void) {}
void retro_cheat_set(unsigned index, bool enabled, const char *code) {
    (void)index;
    (void)enabled;
    (void)code;
}

unsigned retro_get_region(void) {
    return RETRO_REGION_NTSC;
}

void *retro_get_memory_data(unsigned id) {
    (void)id;
    return NULL;
}

size_t retro_get_memory_size(unsigned id) {
    (void)id;
    return 0;
}
