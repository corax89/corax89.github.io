/*
 * J2ME Emulator - Libretro Core Implementation
 * Упрощенная версия
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>

#include "libretro.h"
#include "libretro_shared.h"
#include "jvm.h"
#include "midp.h"
#include "native.h"
#include "opcodes.h"
#include "sdl_backend.h"
#include "miniz.h"  /* For JAR decompression */

/* Forward declaration for step-by-step execution */
extern int execute_frame(JVM* jvm, JavaThread* thread);

/* ============================================
 * JAR/ZIP reading functions
 * ============================================ */

static uint16_t jar_read_u16(const uint8_t* p) {
    return p[0] | (p[1] << 8);
}

static uint32_t jar_read_u32(const uint8_t* p) {
    return p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
}

static size_t jar_find_eocd(const uint8_t* data, size_t size) {
    if (size < 22) return 0;
    size_t max_comment = 65535 + 22;
    size_t search_start = size > max_comment ? size - max_comment : 0;
    
    for (size_t i = size - 22; i >= search_start && i > 0; i--) {
        if (data[i] == 0x50 && data[i+1] == 0x4B &&
            data[i+2] == 0x05 && data[i+3] == 0x06) {
            return i;
        }
    }
    return 0;
}

static uint8_t* jar_extract_file(const uint8_t* jar_data, size_t jar_size,
                                  const char* filename, size_t* out_size) {
    *out_size = 0;
    
    size_t eocd_offset = jar_find_eocd(jar_data, jar_size);
    if (eocd_offset == 0) return NULL;
    
    uint32_t cd_start = jar_read_u32(jar_data + eocd_offset + 16);
    uint16_t cd_entries = jar_read_u16(jar_data + eocd_offset + 10);
    
    size_t cde_offset = cd_start;
    for (int i = 0; i < cd_entries && cde_offset < eocd_offset; i++) {
        uint32_t cd_sig = jar_read_u32(jar_data + cde_offset);
        if (cd_sig != 0x02014B50) break;
        
        uint16_t compression = jar_read_u16(jar_data + cde_offset + 10);
        uint32_t comp_size = jar_read_u32(jar_data + cde_offset + 20);
        uint32_t uncomp_size = jar_read_u32(jar_data + cde_offset + 24);
        uint16_t filename_len = jar_read_u16(jar_data + cde_offset + 28);
        uint16_t extra_len = jar_read_u16(jar_data + cde_offset + 30);
        uint16_t comment_len = jar_read_u16(jar_data + cde_offset + 32);
        uint32_t local_header_offset = jar_read_u32(jar_data + cde_offset + 42);
        
        const char* entry_name = (const char*)(jar_data + cde_offset + 46);
        bool is_dir = (filename_len > 0 && entry_name[filename_len - 1] == '/');
        
        if (!is_dir && filename_len == strlen(filename) &&
            memcmp(entry_name, filename, filename_len) == 0) {
            
            uint16_t local_filename_len = jar_read_u16(jar_data + local_header_offset + 26);
            uint16_t local_extra_len = jar_read_u16(jar_data + local_header_offset + 28);
            size_t data_offset = local_header_offset + 30 + local_filename_len + local_extra_len;
            
            if (compression == 0) {
                *out_size = uncomp_size;
                uint8_t* data = (uint8_t*)malloc(*out_size + 1);
                if (data) {
                    memcpy(data, jar_data + data_offset, *out_size);
                    data[*out_size] = '\0';
                }
                return data;
            } else if (compression == 8) {
                uint8_t* data = (uint8_t*)malloc(uncomp_size + 1);
                if (!data) return NULL;
                
                z_stream stream;
                memset(&stream, 0, sizeof(stream));
                
                int ret = inflateInit2(&stream, -MAX_WBITS);
                if (ret != Z_OK) {
                    free(data);
                    return NULL;
                }
                
                stream.next_in = (Bytef*)(jar_data + data_offset);
                stream.avail_in = comp_size;
                stream.next_out = data;
                stream.avail_out = uncomp_size;
                
                ret = inflate(&stream, Z_FINISH);
                inflateEnd(&stream);
                
                if (ret != Z_STREAM_END) {
                    free(data);
                    return NULL;
                }
                
                data[uncomp_size] = '\0';
                *out_size = uncomp_size;
                return data;
            }
        }
        
        cde_offset += 46 + filename_len + extra_len + comment_len;
    }
    
    return NULL;
}

static char* find_midlet_class_in_jar(const uint8_t* jar_data, size_t jar_size) {
    size_t manifest_size;
    uint8_t* manifest = jar_extract_file(jar_data, jar_size, "META-INF/MANIFEST.MF", &manifest_size);
    
    if (!manifest) {
        manifest = jar_extract_file(jar_data, jar_size, "META-INF/manifest.mf", &manifest_size);
    }
    
    if (!manifest) return NULL;
    
    char* result = NULL;
    char* manifest_str = (char*)manifest;
    
    char* line = strtok(manifest_str, "\r\n");
    while (line) {
        if (strncmp(line, "MIDlet-1:", 9) == 0 || strncmp(line, "MIDlet-1 :", 10) == 0) {
            char* start = strchr(line, ':');
            if (start) {
                start++;
                char* comma1 = strchr(start, ',');
                if (comma1) {
                    char* comma2 = strchr(comma1 + 1, ',');
                    if (comma2) {
                        comma2++;
                        while (*comma2 == ' ') comma2++;
                        
                        char* end = comma2;
                        while (*end && *end != '\r' && *end != '\n' && *end != ',') end++;
                        
                        while (end > comma2 && (end[-1] == ' ' || end[-1] == '\t')) end--;
                        
                        size_t len = end - comma2;
                        result = (char*)malloc(len + 1);
                        if (result) {
                            memcpy(result, comma2, len);
                            result[len] = '\0';
                        }
                        break;
                    }
                }
            }
        }
        line = strtok(NULL, "\r\n");
    }
    
    free(manifest);
    return result;
}

/* Определяем недостающие константы если их нет */
#ifndef RETRO_REGION_NTSC
#define RETRO_REGION_NTSC 0
#endif

#ifndef RETRO_REGION_PAL
#define RETRO_REGION_PAL 1
#endif

/* ============================================
 * Глобальное состояние
 * ============================================ */

JVM* g_jvm = NULL;  /* Non-static for sdl_backend_stubs.c */
static uint8_t* g_jar_data = NULL;
static size_t g_jar_size = 0;
static char g_midlet_class[256] = {0};

/* Framebuffer - dynamic allocation for flexible screen sizes */
static uint32_t* g_framebuffer = NULL;  /* XRGB8888 format */
static int g_screen_width = 240;
static int g_screen_height = 320;
static int g_screen_pitch = 240 * 4;  /* 240 * 4 bytes per pixel (XRGB8888) */
static size_t g_framebuffer_size = 0;

/* Клавиши */
static int g_key_states = 0;

/* Libretro callbacks - ИСПРАВЛЕНО: используем те же имена что и в shared.h */
retro_environment_t environ_cb = NULL;
retro_video_refresh_t video_cb = NULL;
retro_audio_sample_batch_t audio_batch_cb = NULL;
retro_input_poll_t input_poll_cb = NULL;
retro_input_state_t input_state_cb = NULL;
static retro_log_printf_t log_cb = NULL;  /* Это может быть static */

/* Время */
static uint64_t last_frame_time = 0;
static uint64_t frame_accumulator = 0;

/* ============================================
 * Функция получения времени
 * ============================================ */

static uint64_t millis(void) {
    struct timeval time;
    gettimeofday(&time, NULL);
    return time.tv_sec * 1000 + time.tv_usec / 1000;
}

/* ============================================
 * Логирование
 * ============================================ */

static void fallback_log(enum retro_log_level level, const char *fmt, ...) {
    (void)level;
    va_list va;
    va_start(va, fmt);
    vfprintf(stderr, fmt, va);
    va_end(va);
}

static void log_message(enum retro_log_level level, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    
    if (log_cb) {
        char buffer[1024];
        vsnprintf(buffer, sizeof(buffer), fmt, args);
        log_cb(level, "%s", buffer);
    } else {
        vfprintf(stderr, fmt, args);
    }
    
    va_end(args);
}

/* ============================================
 * Функции для доступа из stubs
 * ============================================ */

/* Forward declaration */
static void update_variables(void);

uint32_t* libretro_get_framebuffer(void) {
    return g_framebuffer;
}

int libretro_get_screen_width(void) {
    return g_screen_width;
}

int libretro_get_screen_height(void) {
    return g_screen_height;
}

void libretro_set_key_states(int states) {
    g_key_states = states;
}

int libretro_get_key_states(void) {
    return g_key_states;
}

/* ============================================
 * Инициализация JVM
 * ============================================ */

static bool init_emulator(void) {
    log_message(RETRO_LOG_INFO, "[J2ME] Initializing emulator...\n");
    
    /* Создаем JVM */
    g_jvm = jvm_create();
    if (!g_jvm) {
        log_message(RETRO_LOG_ERROR, "[J2ME] Failed to create JVM\n");
        return false;
    }
    
    /* Минимальная конфигурация */
    g_jvm->config.heap_size = 16 * 1024 * 1024;  /* 16 MB */
    g_jvm->config.stack_size = 64 * 1024;
    g_jvm->config.max_threads = 8;
    g_jvm->config.verbose_class = false;
    
    /* Инициализация */
    if (jvm_init(g_jvm) != JNI_OK) {
        log_message(RETRO_LOG_ERROR, "[J2ME] JVM init failed\n");
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    /* SDL контекст - минимальный */
    SdlContext* ctx = calloc(1, sizeof(SdlContext));
    if (!ctx) {
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    ctx->framebuffer = (uint32_t*)g_framebuffer;
    ctx->width = g_screen_width;
    ctx->height = g_screen_height;
    ctx->scale = 1;
    ctx->jvm = g_jvm;
    ctx->running = true;
    ctx->target_fps = 30;
    
    sdl_set_global_context(ctx);
    
    /* Инициализация native методов */
    if (native_init(g_jvm) != JNI_OK) {
        log_message(RETRO_LOG_ERROR, "[J2ME] native_init failed\n");
        free(ctx);
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    /* Инициализация MIDP */
    if (midp_init(g_jvm) != JNI_OK) {
        log_message(RETRO_LOG_ERROR, "[J2ME] midp_init failed\n");
        free(ctx);
        jvm_destroy(g_jvm);
        g_jvm = NULL;
        return false;
    }
    
    /* Инициализация opcodes */
    opcodes_init();
    
    log_message(RETRO_LOG_INFO, "[J2ME] Emulator initialized\n");
    return true;
}

/* ============================================
 * Запуск MIDlet
 * ============================================ */

static bool run_midlet(void) {
    if (!g_jvm || !g_jar_data) return false;
    
    log_message(RETRO_LOG_INFO, "[J2ME] Starting MIDlet: %s\n", g_midlet_class);
    
    /* Set JAR data */
    jvm_set_jar_data(g_jvm, g_jar_data, g_jar_size, "game.jar");
    
    /* Convert class name */
    char class_name[256];
    strncpy(class_name, g_midlet_class, sizeof(class_name) - 1);
    class_name[sizeof(class_name) - 1] = '\0';
    
    for (char* p = class_name; *p; p++) {
        if (*p == '.') *p = '/';
    }
    
    /* Load class */
    JavaClass* main_class = jvm_load_class(g_jvm, class_name);
    if (!main_class) {
        log_message(RETRO_LOG_ERROR, "[J2ME] Failed to load class %s\n", class_name);
        return false;
    }
    
    /* Run */
    int result = jvm_run_midlet(g_jvm, main_class);
    if (result != 0) {
        log_message(RETRO_LOG_ERROR, "[J2ME] MIDlet execution failed: %d\n", result);
        return false;
    }
    
    log_message(RETRO_LOG_INFO, "[J2ME] MIDlet started\n");
    return true;
}

/* ============================================
 * Libretro API
 * ============================================ */

unsigned retro_api_version(void) {
    return RETRO_API_VERSION;
}

void retro_init(void) {
    fprintf(stderr, "[J2ME] retro_init\n");
    
    /* Update variables from frontend */
    update_variables();
    
    /* Allocate framebuffer */
    g_framebuffer_size = g_screen_width * g_screen_height * sizeof(uint32_t);
    g_framebuffer = (uint32_t*)malloc(g_framebuffer_size);
    if (!g_framebuffer) {
        fprintf(stderr, "[J2ME] Failed to allocate framebuffer\n");
        return;
    }
    memset(g_framebuffer, 0, g_framebuffer_size);
    g_screen_pitch = g_screen_width * 4;
    
    /* Initialize timing */
    uint64_t current_time = millis();
    last_frame_time = current_time;
    frame_accumulator = 0;
}

void retro_deinit(void) {
    fprintf(stderr, "[J2ME] retro_deinit\n");
    
    if (g_jvm) {
        jvm_destroy(g_jvm);
        g_jvm = NULL;
    }
    
    if (g_jar_data) {
        free(g_jar_data);
        g_jar_data = NULL;
    }
    
    if (g_framebuffer) {
        free(g_framebuffer);
        g_framebuffer = NULL;
    }
    g_framebuffer_size = 0;
}

void retro_set_controller_port_device(unsigned port, unsigned device) {
    (void)port;
    (void)device;
}

void retro_get_system_info(struct retro_system_info *info) {
    memset(info, 0, sizeof(*info));
    info->library_name = "J2ME";
    info->library_version = "1.0";
    info->need_fullpath = true;
    info->valid_extensions = "jar";
}

void retro_get_system_av_info(struct retro_system_av_info *info) {
    info->timing.fps = 30.0;
    info->timing.sample_rate = 22050;
    
    info->geometry.base_width = g_screen_width;
    info->geometry.base_height = g_screen_height;
    info->geometry.max_width = 640;
    info->geometry.max_height = 480;
    info->geometry.aspect_ratio = (float)g_screen_width / (float)g_screen_height;
}

/* Variables for core options */
static struct retro_variable g_variables[] = {
    { "j2me_screen_width", "Screen Width; 240|128|176|320|360|400|480" },
    { "j2me_screen_height", "Screen Height; 320|128|160|200|208|220|240|400|480|640|720|800" },
    { "j2me_heap_size", "Heap Size (MB); 16|8|32|64|128" },
    { "j2me_target_fps", "Target FPS; 30|15|20|25|60" },
    { "j2me_scale", "Display Scale; 2|1|3|4" },
    { NULL, NULL }
};

void retro_set_environment(retro_environment_t cb) {
    environ_cb = cb;
    
    /* Get log interface */
    struct retro_log_callback logging;
    if (cb(RETRO_ENVIRONMENT_GET_LOG_INTERFACE, &logging)) {
        log_cb = logging.log;
    } else {
        log_cb = fallback_log;
    }
    
    log_message(RETRO_LOG_INFO, "[J2ME] retro_set_environment\n");
    
    /* Set core options */
    cb(RETRO_ENVIRONMENT_SET_VARIABLES, (void*)g_variables);
    
    /* No content mode */
    bool no_content = false;
    cb(RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME, &no_content);
}

/* Update variables from frontend */
static void update_variables(void) {
    if (!environ_cb) return;
    
    struct retro_variable var = {0};
    
    var.key = "j2me_screen_width";
    if (environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) && var.value) {
        int width = atoi(var.value);
        if (width >= 128 && width <= 480) {
            g_screen_width = width;
            g_screen_pitch = width * 4;  /* XRGB8888 = 4 bytes per pixel */
        }
    }
    
    var.key = "j2me_screen_height";
    var.value = NULL;
    if (environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) && var.value) {
        int height = atoi(var.value);
        if (height >= 128 && height <= 800) {
            g_screen_height = height;
        }
    }
    
    log_message(RETRO_LOG_INFO, "[J2ME] Screen resolution: %dx%d\n", g_screen_width, g_screen_height);
}

void retro_set_audio_sample(retro_audio_sample_t cb) {
    (void)cb;  /* Not used */
}

void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) {
    audio_batch_cb = cb;
}

void retro_set_input_poll(retro_input_poll_t cb) {
    input_poll_cb = cb;
}

void retro_set_input_state(retro_input_state_t cb) {
    input_state_cb = cb;
}

void retro_set_video_refresh(retro_video_refresh_t cb) {
    video_cb = cb;
}

void retro_reset(void) {
    fprintf(stderr, "[J2ME] retro_reset\n");
    g_key_states = 0;
}

bool retro_load_game(const struct retro_game_info *info) {
    fprintf(stderr, "[J2ME] retro_load_game: %s\n", info ? info->path : "NULL");
    
    if (!info || !info->path) {
        fprintf(stderr, "[J2ME] No game path\n");
        return false;
    }
    
    /* Load JAR file */
    FILE* f = fopen(info->path, "rb");
    if (!f) {
        fprintf(stderr, "[J2ME] Cannot open file\n");
        return false;
    }
    
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    
    g_jar_data = malloc(size);
    if (!g_jar_data) {
        fclose(f);
        return false;
    }
    
    if (fread(g_jar_data, 1, size, f) != (size_t)size) {
        free(g_jar_data);
        fclose(f);
        return false;
    }
    fclose(f);
    g_jar_size = size;
    
    fprintf(stderr, "[J2ME] JAR loaded: %ld bytes\n", size);
    
    /* Find MIDlet class from JAR manifest (properly decompressed) */
    char* midlet_class = find_midlet_class_in_jar(g_jar_data, g_jar_size);
    if (midlet_class) {
        strncpy(g_midlet_class, midlet_class, sizeof(g_midlet_class) - 1);
        g_midlet_class[sizeof(g_midlet_class) - 1] = '\0';
        free(midlet_class);
        fprintf(stderr, "[J2ME] Found MIDlet class: %s\n", g_midlet_class);
    } else {
        /* Fallback: try common MIDlet class names */
        strcpy(g_midlet_class, "MIDlet");
        fprintf(stderr, "[J2ME] Warning: Could not find MIDlet class in manifest, using default\n");
    }
    
    /* Set pixel format - XRGB8888 matches our internal graphics format */
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_XRGB8888;
    if (!environ_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) {
        fprintf(stderr, "[J2ME] XRGB8888 not supported, trying RGB565\n");
        fmt = RETRO_PIXEL_FORMAT_RGB565;
        if (!environ_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) {
            fprintf(stderr, "[J2ME] Neither XRGB8888 nor RGB565 supported\n");
            return false;
        }
        fprintf(stderr, "[J2ME] Using RGB565 format (fallback)\n");
    } else {
        fprintf(stderr, "[J2ME] Using XRGB8888 format\n");
    }
    
    /* Input descriptors */
    static const struct retro_input_descriptor desc[] = {
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP,    "Up" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN,  "Down" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT,  "Left" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT, "Right" },
        { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A,     "Fire" },
        { 0 },
    };
    environ_cb(RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS, (void*)desc);
    
    /* Initialize emulator */
    if (!init_emulator()) {
        fprintf(stderr, "[J2ME] Emulator init failed\n");
        return false;
    }
    
    /* Run MIDlet */
    run_midlet();
    
    fprintf(stderr, "[J2ME] Game loaded successfully\n");
    return true;
}

bool retro_load_game_special(unsigned type, const struct retro_game_info *info, size_t num) {
    (void)type;
    (void)info;
    (void)num;
    return false;
}

void retro_unload_game(void) {
    fprintf(stderr, "[J2ME] retro_unload_game\n");
}

void retro_run(void) {
    /* Get current time */
    uint64_t current_time = millis();
    uint64_t delta_time = current_time - last_frame_time;
    last_frame_time = current_time;
    
    frame_accumulator += delta_time;
    
    /* Target frame time for 30 FPS = 33.33 ms */
    uint32_t target_frame_time = 33;
    
    if (frame_accumulator >= target_frame_time) {
        /* Limit max frameskip */
        if (frame_accumulator > target_frame_time * 3) {
            frame_accumulator = target_frame_time * 2;
        }
        
        /* Poll input */
        if (input_poll_cb) input_poll_cb();
        
        /* Process input */
        int keys = 0;
        if (input_state_cb) {
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP)) keys |= (1 << 1);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN)) keys |= (1 << 6);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT)) keys |= (1 << 2);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT)) keys |= (1 << 5);
            if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A)) keys |= (1 << 8);
        }
        g_key_states = keys;
        
        /* Run emulation for accumulated frames */
        while (frame_accumulator >= target_frame_time) {
            /* Execute JVM instructions - run until paused or frame done */
            if (g_jvm && g_jvm->running && g_jvm->main_thread) {
                JavaThread* thread = g_jvm->main_thread;
                if (thread->current_frame) {
                    /* Execute a batch of instructions */
                    for (int i = 0; i < 10000 && g_jvm->running; i++) {
                        if (execute_frame(g_jvm, thread) != 0) {
                            break;
                        }
                    }
                }
            }
            
            frame_accumulator -= target_frame_time;
        }
        
        /* Send frame to frontend */
        if (video_cb) {
            video_cb(g_framebuffer, g_screen_width, g_screen_height, g_screen_pitch);
        }
    }
}

/* Save states (minimal) */
size_t retro_serialize_size(void) {
    return 0;
}

bool retro_serialize(void *data, size_t size) {
    (void)data;
    (void)size;
    return false;
}

bool retro_unserialize(const void *data, size_t size) {
    (void)data;
    (void)size;
    return false;
}

void retro_cheat_reset(void) {}
void retro_cheat_set(unsigned index, bool enabled, const char *code) {
    (void)index;
    (void)enabled;
    (void)code;
}

unsigned retro_get_region(void) {
    return RETRO_REGION_NTSC;
}

void *retro_get_memory_data(unsigned id) {
    (void)id;
    return NULL;
}

size_t retro_get_memory_size(unsigned id) {
    (void)id;
    return 0;
}
