/*
 * SDL Backend Stubs for Libretro Build
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "libretro.h"
#include "sdl_backend.h"
#include "midp.h"
#include "miniz.h"  /* For JAR decompression */

/* ============================================
 * External variables from libretro.c
 * ============================================ */

/* Эти переменные определены в libretro.c как глобальные (не static) */
extern retro_video_refresh_t video_cb;
extern retro_input_poll_t input_poll_cb;
extern retro_input_state_t input_state_cb;
extern retro_environment_t environ_cb;

/* External functions from libretro.c */
extern uint32_t* libretro_get_framebuffer(void);
extern int libretro_get_screen_width(void);
extern int libretro_get_screen_height(void);

/* Global context */
static SdlContext g_libretro_context = {0};

/* Get global SDL context */
SdlContext* sdl_get_global_context(void) {
    return &g_libretro_context;
}

/* Set global context */
void sdl_set_global_context(SdlContext* ctx) {
    if (ctx) {
        g_libretro_context = *ctx;
    } else {
        memset(&g_libretro_context, 0, sizeof(SdlContext));
    }
}

/* Initialize SDL backend (stub for libretro) */
int sdl_init(JVM* jvm, int width, int height, int scale) {
    g_libretro_context.jvm = jvm;
    g_libretro_context.width = width;
    g_libretro_context.height = height;
    g_libretro_context.scale = scale;
    g_libretro_context.framebuffer = (uint32_t*)libretro_get_framebuffer();
    g_libretro_context.target_fps = 30;
    g_libretro_context.running = true;
    
    fprintf(stderr, "[J2ME Libretro] SDL stub initialized: %dx%d scale=%d\n", width, height, scale);
    return 0;
}

/* Destroy SDL backend */
void sdl_destroy(SdlContext* ctx) {
    (void)ctx;
    fprintf(stderr, "[J2ME Libretro] SDL stub destroyed\n");
}

/* Run main loop (not used) */
void sdl_run(SdlContext* ctx) {
    (void)ctx;
}

/* Set fullscreen (stub) */
void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) {
    (void)ctx;
    (void)fullscreen;
}

/* Get ticks (milliseconds) */
uint64_t sdl_get_ticks(SdlContext* ctx) {
    (void)ctx;
    return 0;
}

/* Delay (stub) */
void sdl_delay(uint32_t ms) {
    (void)ms;
}

/* Update screen */
void sdl_update_screen(SdlContext* ctx) {
    if (ctx && ctx->framebuffer && video_cb) {
        /* Use XRGB8888 format directly - pitch is width * 4 bytes */
        video_cb(ctx->framebuffer, ctx->width, ctx->height, ctx->width * 4);
    }
}

/* Handle events */
void sdl_handle_events(SdlContext* ctx) {
    (void)ctx;
}

/* Check if key is pressed */
/* ИСПРАВЛЕНО: Теперь использует g_key_states как единый источник истины */
bool sdl_key_pressed(SdlContext* ctx, int key) {
    (void)ctx;
    
    /* Use g_key_states as single source of truth */
    extern int libretro_get_key_states(void);
    int keys = libretro_get_key_states();
    
    /* Map game keys to bit positions */
    switch (key) {
        case 1:  /* GAME_UP */
            return (keys & (1 << 1)) != 0;
        case 6:  /* GAME_DOWN */
            return (keys & (1 << 6)) != 0;
        case 2:  /* GAME_LEFT */
            return (keys & (1 << 2)) != 0;
        case 5:  /* GAME_RIGHT */
            return (keys & (1 << 5)) != 0;
        case 8:  /* GAME_FIRE */
            return (keys & (1 << 8)) != 0;
        case 9:  /* GAME_A */
            return (keys & (1 << 9)) != 0;
        case 10: /* GAME_B */
            return (keys & (1 << 10)) != 0;
        case 11: /* GAME_C */
            return (keys & (1 << 11)) != 0;
        case 12: /* GAME_D */
            return false;  /* Not mapped yet */
        default:
            return false;
    }
}

/* Get graphics context */
MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

/* Audio initialization stub */
int sdl_audio_init_simple(uint32_t sample_rate) {
    (void)sample_rate;
    return 0;
}

/* Audio shutdown stub */
void sdl_audio_shutdown(void) {
}

/* Load resource from JAR - uses libretro's JAR data */
uint8_t* load_jar_resource(const char* path, size_t* size) {
    if (size) *size = 0;
    if (!path) return NULL;
    
    /* Get JAR data from JVM */
    extern JVM* g_jvm;  /* From libretro.c */
    if (!g_jvm || !g_jvm->class_loader.jar_data) return NULL;
    
    /* Use the jar_find_file_internal from jvm.c or implement here */
    /* For now, we'll implement a simple version */
    const uint8_t* jar_data = g_jvm->class_loader.jar_data;
    size_t jar_size = g_jvm->class_loader.jar_size;
    
    /* Find End of Central Directory */
    size_t eocd = 0;
    for (size_t i = jar_size - 22; i > 0; i--) {
        if (jar_data[i] == 0x50 && jar_data[i+1] == 0x4B &&
            jar_data[i+2] == 0x05 && jar_data[i+3] == 0x06) {
            eocd = i;
            break;
        }
    }
    if (eocd == 0) return NULL;
    
    uint32_t cd_start = jar_data[eocd + 16] | (jar_data[eocd + 17] << 8) |
                        (jar_data[eocd + 18] << 16) | (jar_data[eocd + 19] << 24);
    uint16_t cd_entries = jar_data[eocd + 10] | (jar_data[eocd + 11] << 8);
    
    /* Search for file */
    size_t cde = cd_start;
    for (int i = 0; i < cd_entries && cde < eocd; i++) {
        uint32_t sig = jar_data[cde] | (jar_data[cde+1] << 8) |
                       (jar_data[cde+2] << 16) | (jar_data[cde+3] << 24);
        if (sig != 0x02014B50) break;
        
        uint16_t compression = jar_data[cde + 10] | (jar_data[cde + 11] << 8);
        uint32_t comp_size = jar_data[cde + 20] | (jar_data[cde + 21] << 8) |
                             (jar_data[cde + 22] << 16) | (jar_data[cde + 23] << 24);
        uint32_t uncomp_size = jar_data[cde + 24] | (jar_data[cde + 25] << 8) |
                               (jar_data[cde + 26] << 16) | (jar_data[cde + 27] << 24);
        uint16_t name_len = jar_data[cde + 28] | (jar_data[cde + 29] << 8);
        uint16_t extra_len = jar_data[cde + 30] | (jar_data[cde + 31] << 8);
        uint16_t comment_len = jar_data[cde + 32] | (jar_data[cde + 33] << 8);
        uint32_t local_off = jar_data[cde + 42] | (jar_data[cde + 43] << 8) |
                             (jar_data[cde + 44] << 16) | (jar_data[cde + 45] << 24);
        
        const char* name = (const char*)(jar_data + cde + 46);
        if (name_len == strlen(path) && memcmp(name, path, name_len) == 0) {
            uint16_t local_name_len = jar_data[local_off + 26] | (jar_data[local_off + 27] << 8);
            uint16_t local_extra_len = jar_data[local_off + 28] | (jar_data[local_off + 29] << 8);
            size_t data_off = local_off + 30 + local_name_len + local_extra_len;
            
            if (compression == 0) {
                *size = uncomp_size;
                uint8_t* data = (uint8_t*)malloc(*size);
                if (data) memcpy(data, jar_data + data_off, *size);
                return data;
            } else if (compression == 8) {
                /* Decompress using miniz */
                uint8_t* data = (uint8_t*)malloc(uncomp_size);
                if (!data) return NULL;
                
                z_stream stream;
                memset(&stream, 0, sizeof(stream));
                if (inflateInit2(&stream, -MAX_WBITS) != Z_OK) {
                    free(data);
                    return NULL;
                }
                stream.next_in = (Bytef*)(jar_data + data_off);
                stream.avail_in = comp_size;
                stream.next_out = data;
                stream.avail_out = uncomp_size;
                if (inflate(&stream, Z_FINISH) != Z_STREAM_END) {
                    inflateEnd(&stream);
                    free(data);
                    return NULL;
                }
                inflateEnd(&stream);
                *size = uncomp_size;
                return data;
            }
        }
        
        cde += 46 + name_len + extra_len + comment_len;
    }
    
    return NULL;
}

/* Present framebuffer */
void sdl_present(SdlContext* ctx) {
    sdl_update_screen(ctx);
}

/* ============================================
 * ИСПРАВЛЕНО: Недостающие функции для libretro
 * Эти функции вызываются из display.c и graphics.c
 * В режиме libretro они либо no-op, либо устанавливают флаги
 * ============================================ */

/* Thread-safe запрос на перерисовку экрана */
void sdl_request_redraw(void) {
    /* В libretro режиме фронтенд управляет частотой кадров */
    /* Устанавливаем флаг для совместимости, но он не влияет на рендеринг */
    g_libretro_context.needs_redraw = true;
}

/* Check if redraw is needed */
bool sdl_needs_redraw(SdlContext* ctx) {
    return ctx ? ctx->needs_redraw : false;
}

/* Clear redraw flag */
void sdl_clear_redraw(SdlContext* ctx) {
    if (ctx) {
        ctx->needs_redraw = false;
    }
}

/* Process events minimal - stub for libretro */
void sdl_process_events_minimal(void) {
    /* В libretro события обрабатываются через input_poll_cb */
}

/* Update texture - stub for libretro */
void sdl_update_texture(SdlContext* ctx) {
    (void)ctx;
    /* В libretro текстуры управляются фронтендом */
}

/* Clear screen */
void sdl_clear(SdlContext* ctx, uint32_t color) {
    if (!ctx || !ctx->framebuffer) return;
    
    int size = ctx->width * ctx->height;
    for (int i = 0; i < size; i++) {
        ctx->framebuffer[i] = color;
    }
}

/* Resize framebuffer - stub for libretro */
int sdl_resize(SdlContext* ctx, int width, int height) {
    (void)ctx;
    (void)width;
    (void)height;
    /* В libretro размер управляется фронтендом */
    return 0;
}

/* Screenshot - stub for libretro */
int sdl_screenshot(SdlContext* ctx, const char* filename) {
    (void)ctx;
    (void)filename;
    return -1;
}

/* Frame end - stub for libretro */
void sdl_frame_end(SdlContext* ctx) {
    (void)ctx;
}

/* Sleep - stub for libretro */
void sdl_sleep(uint32_t ms) {
    (void)ms;
    /* В libretro тайминг управляется фронтендом */
}

/* Set window title - stub for libretro */
void sdl_set_title(SdlContext* ctx, const char* title) {
    (void)ctx;
    (void)title;
}

/* Toggle fullscreen - stub for libretro */
void sdl_toggle_fullscreen(SdlContext* ctx) {
    (void)ctx;
}

/* Get window size - returns framebuffer size for libretro */
void sdl_get_window_size(SdlContext* ctx, int* width, int* height) {
    if (width && ctx) *width = ctx->width;
    if (height && ctx) *height = ctx->height;
}

/* Stop main loop */
void sdl_stop(SdlContext* ctx) {
    if (ctx) ctx->running = false;
}

/* Get platform callbacks - stub for libretro */
MidpPlatformCallbacks* sdl_get_platform_callbacks(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

/* Check if screen graphics - stub for libretro */
bool sdl_is_screen_graphics(MidpGraphics* gfx) {
    (void)gfx;
    return true;
}

/* Audio init - stub for libretro */
int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
    (void)ctx;
    (void)frequency;
    (void)channels;
    (void)samples;
    return 0;
}

/* Audio queue - stub for libretro */
int sdl_audio_queue(SdlContext* ctx, const void* data, size_t length) {
    (void)ctx;
    (void)data;
    (void)length;
    return 0;
}

/* Audio queued size - stub for libretro */
uint32_t sdl_audio_queued_size(SdlContext* ctx) {
    (void)ctx;
    return 0;
}

/* Audio clear - stub for libretro */
void sdl_audio_clear(SdlContext* ctx) {
    (void)ctx;
}

/* Process events - stub for libretro */
void sdl_process_events(SdlContext* ctx) {
    (void)ctx;
    /* В libretro события обрабатываются через input_poll_cb в retro_run() */
}

/* Key mappings - stub for libretro */
int sdl_key_to_midp(int sdl_key) {
    (void)sdl_key;
    return 0;
}

int sdl_key_to_game_action(int sdl_key) {
    (void)sdl_key;
    return 0;
}

/* Pointer functions - stubs for libretro */
void sdl_get_pointer(SdlContext* ctx, int* x, int* y) {
    if (x) *x = 0;
    if (y) *y = 0;
    (void)ctx;
}

bool sdl_pointer_pressed(SdlContext* ctx) {
    (void)ctx;
    return false;
}

/* Dump info - stub for libretro */
void sdl_dump_info(SdlContext* ctx) {
    (void)ctx;
}
