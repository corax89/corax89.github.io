/*
 * SDL Backend Stubs for Libretro Build
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "libretro.h"
#include "sdl_backend.h"
#include "midp.h"
#include "miniz.h"  /* For JAR decompression */

/* ============================================
 * External variables from libretro.c
 * ============================================ */

/* Эти переменные определены в libretro.c как глобальные (не static) */
extern retro_video_refresh_t video_cb;
extern retro_input_poll_t input_poll_cb;
extern retro_input_state_t input_state_cb;
extern retro_environment_t environ_cb;

/* External functions from libretro.c */
extern uint32_t* libretro_get_framebuffer(void);
extern int libretro_get_screen_width(void);
extern int libretro_get_screen_height(void);

/* Global context */
static SdlContext g_libretro_context = {0};

/* Get global SDL context */
SdlContext* sdl_get_global_context(void) {
    return &g_libretro_context;
}

/* Set global context */
void sdl_set_global_context(SdlContext* ctx) {
    if (ctx) {
        g_libretro_context = *ctx;
    } else {
        memset(&g_libretro_context, 0, sizeof(SdlContext));
    }
}

/* Initialize SDL backend (stub for libretro) */
int sdl_init(JVM* jvm, int width, int height, int scale) {
    g_libretro_context.jvm = jvm;
    g_libretro_context.width = width;
    g_libretro_context.height = height;
    g_libretro_context.scale = scale;
    g_libretro_context.framebuffer = (uint32_t*)libretro_get_framebuffer();
    g_libretro_context.target_fps = 30;
    g_libretro_context.running = true;
    
    fprintf(stderr, "[J2ME Libretro] SDL stub initialized: %dx%d scale=%d\n", width, height, scale);
    return 0;
}

/* Destroy SDL backend */
void sdl_destroy(SdlContext* ctx) {
    (void)ctx;
    fprintf(stderr, "[J2ME Libretro] SDL stub destroyed\n");
}

/* Run main loop (not used) */
void sdl_run(SdlContext* ctx) {
    (void)ctx;
}

/* Set fullscreen (stub) */
void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) {
    (void)ctx;
    (void)fullscreen;
}

/* Get ticks (milliseconds) */
uint64_t sdl_get_ticks(SdlContext* ctx) {
    (void)ctx;
    return 0;
}

/* Delay (stub) */
void sdl_delay(uint32_t ms) {
    (void)ms;
}

/* Update screen */
void sdl_update_screen(SdlContext* ctx) {
    if (ctx && ctx->framebuffer && video_cb) {
        /* Use XRGB8888 format directly - pitch is width * 4 bytes */
        video_cb(ctx->framebuffer, ctx->width, ctx->height, ctx->width * 4);
    }
}

/* Handle events */
void sdl_handle_events(SdlContext* ctx) {
    (void)ctx;
}

/* Check if key is pressed */
bool sdl_key_pressed(SdlContext* ctx, int key) {
    if (!input_poll_cb || !input_state_cb) return false;
    
    (void)ctx;
    
    input_poll_cb();
    
    /* Map game keys to retro pad buttons */
    switch (key) {
        case 1: /* GAME_UP */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP) != 0;
        case 6: /* GAME_DOWN */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN) != 0;
        case 2: /* GAME_LEFT */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT) != 0;
        case 5: /* GAME_RIGHT */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT) != 0;
        case 8: /* GAME_FIRE */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A) != 0;
        case 9: /* GAME_A */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_Y) != 0;
        case 10: /* GAME_B */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L) != 0;
        case 11: /* GAME_C */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_R) != 0;
        case 12: /* GAME_D */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L2) != 0;
        default:
            return false;
    }
}

/* Get graphics context */
MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

/* Audio initialization stub */
int sdl_audio_init_simple(uint32_t sample_rate) {
    (void)sample_rate;
    return 0;
}

/* Audio shutdown stub */
void sdl_audio_shutdown(void) {
}

/* Load resource from JAR - uses libretro's JAR data */
uint8_t* load_jar_resource(const char* path, size_t* size) {
    if (size) *size = 0;
    if (!path) return NULL;
    
    /* Get JAR data from JVM */
    extern JVM* g_jvm;  /* From libretro.c */
    if (!g_jvm || !g_jvm->class_loader.jar_data) return NULL;
    
    /* Use the jar_find_file_internal from jvm.c or implement here */
    /* For now, we'll implement a simple version */
    const uint8_t* jar_data = g_jvm->class_loader.jar_data;
    size_t jar_size = g_jvm->class_loader.jar_size;
    
    /* Find End of Central Directory */
    size_t eocd = 0;
    for (size_t i = jar_size - 22; i > 0; i--) {
        if (jar_data[i] == 0x50 && jar_data[i+1] == 0x4B &&
            jar_data[i+2] == 0x05 && jar_data[i+3] == 0x06) {
            eocd = i;
            break;
        }
    }
    if (eocd == 0) return NULL;
    
    uint32_t cd_start = jar_data[eocd + 16] | (jar_data[eocd + 17] << 8) |
                        (jar_data[eocd + 18] << 16) | (jar_data[eocd + 19] << 24);
    uint16_t cd_entries = jar_data[eocd + 10] | (jar_data[eocd + 11] << 8);
    
    /* Search for file */
    size_t cde = cd_start;
    for (int i = 0; i < cd_entries && cde < eocd; i++) {
        uint32_t sig = jar_data[cde] | (jar_data[cde+1] << 8) |
                       (jar_data[cde+2] << 16) | (jar_data[cde+3] << 24);
        if (sig != 0x02014B50) break;
        
        uint16_t compression = jar_data[cde + 10] | (jar_data[cde + 11] << 8);
        uint32_t comp_size = jar_data[cde + 20] | (jar_data[cde + 21] << 8) |
                             (jar_data[cde + 22] << 16) | (jar_data[cde + 23] << 24);
        uint32_t uncomp_size = jar_data[cde + 24] | (jar_data[cde + 25] << 8) |
                               (jar_data[cde + 26] << 16) | (jar_data[cde + 27] << 24);
        uint16_t name_len = jar_data[cde + 28] | (jar_data[cde + 29] << 8);
        uint16_t extra_len = jar_data[cde + 30] | (jar_data[cde + 31] << 8);
        uint16_t comment_len = jar_data[cde + 32] | (jar_data[cde + 33] << 8);
        uint32_t local_off = jar_data[cde + 42] | (jar_data[cde + 43] << 8) |
                             (jar_data[cde + 44] << 16) | (jar_data[cde + 45] << 24);
        
        const char* name = (const char*)(jar_data + cde + 46);
        if (name_len == strlen(path) && memcmp(name, path, name_len) == 0) {
            uint16_t local_name_len = jar_data[local_off + 26] | (jar_data[local_off + 27] << 8);
            uint16_t local_extra_len = jar_data[local_off + 28] | (jar_data[local_off + 29] << 8);
            size_t data_off = local_off + 30 + local_name_len + local_extra_len;
            
            if (compression == 0) {
                *size = uncomp_size;
                uint8_t* data = (uint8_t*)malloc(*size);
                if (data) memcpy(data, jar_data + data_off, *size);
                return data;
            } else if (compression == 8) {
                /* Decompress using miniz */
                uint8_t* data = (uint8_t*)malloc(uncomp_size);
                if (!data) return NULL;
                
                z_stream stream;
                memset(&stream, 0, sizeof(stream));
                if (inflateInit2(&stream, -MAX_WBITS) != Z_OK) {
                    free(data);
                    return NULL;
                }
                stream.next_in = (Bytef*)(jar_data + data_off);
                stream.avail_in = comp_size;
                stream.next_out = data;
                stream.avail_out = uncomp_size;
                if (inflate(&stream, Z_FINISH) != Z_STREAM_END) {
                    inflateEnd(&stream);
                    free(data);
                    return NULL;
                }
                inflateEnd(&stream);
                *size = uncomp_size;
                return data;
            }
        }
        
        cde += 46 + name_len + extra_len + comment_len;
    }
    
    return NULL;
}

/* Present framebuffer */
void sdl_present(SdlContext* ctx) {
    sdl_update_screen(ctx);
}
