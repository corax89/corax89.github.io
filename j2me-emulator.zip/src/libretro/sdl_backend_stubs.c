/*
 * SDL Backend Stubs for Libretro Build
 * Provides minimal implementations of SDL functions needed by midp/
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "libretro.h"
#include "sdl_backend.h"
#include "midp.h"  /* For GAME_* constants */

/* External libretro callbacks - defined in libretro.c */
extern retro_video_refresh_t g_video_cb;
extern retro_audio_sample_batch_t g_audio_batch_cb;
extern retro_input_poll_t g_input_poll_cb;
extern retro_input_state_t g_input_state_cb;
extern retro_environment_t g_environ_cb;

/* External functions from libretro.c */
extern uint32_t* libretro_get_framebuffer(void);
extern int libretro_get_screen_width(void);
extern int libretro_get_screen_height(void);

/* Global context */
static SdlContext g_libretro_context = {0};

/* Get global SDL context (stub) */
SdlContext* sdl_get_global_context(void) {
    if (!g_libretro_context.framebuffer) {
        g_libretro_context.framebuffer = libretro_get_framebuffer();
        g_libretro_context.width = libretro_get_screen_width();
        g_libretro_context.height = libretro_get_screen_height();
        g_libretro_context.scale = 1;
    }
    return &g_libretro_context;
}

/* Set global context - no-op for libretro */
void sdl_set_global_context(SdlContext* ctx) {
    (void)ctx;
}

/* Present framebuffer to libretro */
void sdl_present(SdlContext* ctx) {
    if (ctx && ctx->framebuffer && g_video_cb) {
        g_video_cb(ctx->framebuffer, ctx->width, ctx->height, ctx->width * sizeof(uint32_t));
    }
}

/* Check if key is pressed */
bool sdl_key_pressed(SdlContext* ctx, int key) {
    if (!g_input_poll_cb || !g_input_state_cb) return false;
    
    /* Poll input */
    g_input_poll_cb();
    
    /* Map game keys to retro pad buttons - using midp.h constants */
    /* GAME_UP=1, GAME_DOWN=6, GAME_LEFT=2, GAME_RIGHT=5, GAME_FIRE=8, 
       GAME_A=9, GAME_B=10, GAME_C=11, GAME_D=12 */
    switch (key) {
        case GAME_UP:    return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP) != 0;
        case GAME_DOWN:  return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN) != 0;
        case GAME_LEFT:  return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT) != 0;
        case GAME_RIGHT: return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT) != 0;
        case GAME_FIRE:  return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A) != 0;
        case GAME_A:     return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_Y) != 0;
        case GAME_B:     return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L) != 0;
        case GAME_C:     return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_R) != 0;
        case GAME_D:     return g_input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L2) != 0;
        default:         return false;
    }
}

/* Get graphics context (just returns the context) */
MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    /* In libretro, we use the midp graphics directly */
    return NULL;  /* The display.c code has its own graphics init */
}

/* Audio initialization stub */
int sdl_audio_init_simple(uint32_t sample_rate) {
    /* Audio is handled by libretro frontend */
    (void)sample_rate;
    return 0;
}

/* Audio shutdown stub */
void sdl_audio_shutdown(void) {
    /* No-op for libretro */
}

/* Load resource from JAR - stub */
uint8_t* load_jar_resource(const char* path, size_t* size) {
    /* TODO: Implement using libretro VFS or memory loading */
    if (size) *size = 0;
    (void)path;
    return NULL;
}
