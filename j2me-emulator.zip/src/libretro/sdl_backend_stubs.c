/*
 * SDL Backend Stubs for Libretro Build
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "libretro.h"
#include "sdl_backend.h"
#include "midp.h"

/* ============================================
 * External variables from libretro.c
 * ============================================ */

/* Эти переменные определены в libretro.c как глобальные (не static) */
extern retro_video_refresh_t video_cb;
extern retro_input_poll_t input_poll_cb;
extern retro_input_state_t input_state_cb;
extern retro_environment_t environ_cb;

/* External functions from libretro.c */
extern uint16_t* libretro_get_framebuffer(void);
extern int libretro_get_screen_width(void);
extern int libretro_get_screen_height(void);

/* Global context */
static SdlContext g_libretro_context = {0};

/* Get global SDL context */
SdlContext* sdl_get_global_context(void) {
    return &g_libretro_context;
}

/* Set global context */
void sdl_set_global_context(SdlContext* ctx) {
    if (ctx) {
        g_libretro_context = *ctx;
    } else {
        memset(&g_libretro_context, 0, sizeof(SdlContext));
    }
}

/* Initialize SDL backend (stub for libretro) */
int sdl_init(JVM* jvm, int width, int height, int scale) {
    g_libretro_context.jvm = jvm;
    g_libretro_context.width = width;
    g_libretro_context.height = height;
    g_libretro_context.scale = scale;
    g_libretro_context.framebuffer = (uint32_t*)libretro_get_framebuffer();
    g_libretro_context.target_fps = 30;
    g_libretro_context.running = true;
    
    fprintf(stderr, "[J2ME Libretro] SDL stub initialized: %dx%d scale=%d\n", width, height, scale);
    return 0;
}

/* Destroy SDL backend */
void sdl_destroy(SdlContext* ctx) {
    (void)ctx;
    fprintf(stderr, "[J2ME Libretro] SDL stub destroyed\n");
}

/* Run main loop (not used) */
void sdl_run(SdlContext* ctx) {
    (void)ctx;
}

/* Set fullscreen (stub) */
void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) {
    (void)ctx;
    (void)fullscreen;
}

/* Get ticks (milliseconds) */
uint64_t sdl_get_ticks(SdlContext* ctx) {
    (void)ctx;
    return 0;
}

/* Delay (stub) */
void sdl_delay(uint32_t ms) {
    (void)ms;
}

/* Update screen */
void sdl_update_screen(SdlContext* ctx) {
    if (ctx && ctx->framebuffer && video_cb) {
        /* Convert from uint32_t* to uint16_t* for RGB565 */
        uint16_t* fb = (uint16_t*)ctx->framebuffer;
        video_cb(fb, ctx->width, ctx->height, ctx->width * sizeof(uint16_t));
    }
}

/* Handle events */
void sdl_handle_events(SdlContext* ctx) {
    (void)ctx;
}

/* Check if key is pressed */
bool sdl_key_pressed(SdlContext* ctx, int key) {
    if (!input_poll_cb || !input_state_cb) return false;
    
    (void)ctx;
    
    input_poll_cb();
    
    /* Map game keys to retro pad buttons */
    switch (key) {
        case 1: /* GAME_UP */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP) != 0;
        case 6: /* GAME_DOWN */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN) != 0;
        case 2: /* GAME_LEFT */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT) != 0;
        case 5: /* GAME_RIGHT */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT) != 0;
        case 8: /* GAME_FIRE */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_A) != 0;
        case 9: /* GAME_A */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_Y) != 0;
        case 10: /* GAME_B */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L) != 0;
        case 11: /* GAME_C */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_R) != 0;
        case 12: /* GAME_D */
            return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L2) != 0;
        default:
            return false;
    }
}

/* Get graphics context */
MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

/* Audio initialization stub */
int sdl_audio_init_simple(uint32_t sample_rate) {
    (void)sample_rate;
    return 0;
}

/* Audio shutdown stub */
void sdl_audio_shutdown(void) {
}

/* Load resource from JAR - stub */
uint8_t* load_jar_resource(const char* path, size_t* size) {
    if (size) *size = 0;
    (void)path;
    return NULL;
}

/* Present framebuffer */
void sdl_present(SdlContext* ctx) {
    sdl_update_screen(ctx);
}
