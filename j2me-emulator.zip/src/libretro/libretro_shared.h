/*
 * libretro_shared.h - Shared declarations between libretro.c and sdl_backend_stubs.c
 */

#ifndef LIBRETRO_SHARED_H
#define LIBRETRO_SHARED_H

#include <stdint.h>
#include <stdbool.h>
#include "libretro.h"

/* Libretro callbacks - shared between files */
extern retro_video_refresh_t g_video_cb;
extern retro_audio_sample_batch_t g_audio_batch_cb;
extern retro_input_poll_t g_input_poll_cb;
extern retro_input_state_t g_input_state_cb;
extern retro_environment_t g_environ_cb;

/* Framebuffer access - используем uint16_t для RGB565 */
extern uint16_t* libretro_get_framebuffer(void);
extern int libretro_get_screen_width(void);
extern int libretro_get_screen_height(void);
extern void libretro_set_key_states(int states);
extern int libretro_get_key_states(void);

#endif /* LIBRETRO_SHARED_H */
