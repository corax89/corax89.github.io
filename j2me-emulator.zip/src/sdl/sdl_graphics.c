/*
 * J2ME Emulator - SDL2 Backend
 * Cross-platform graphics, input, and audio using SDL2
 * Falls back to stub implementation if SDL2 is not available
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifndef _WIN32
#include <unistd.h>
#else
#include <windows.h>
#endif
#include <time.h>

/* Try to include SDL2 - support multiple header locations */
#if defined(HAVE_SDL2) || \
    defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    define SDL2_AVAILABLE 1
#    include <SDL2/SDL.h>
#  elif __has_include(<SDL.h>)
#    define SDL2_AVAILABLE 1
#    include <SDL.h>
#  else
#    define SDL2_AVAILABLE 0
#  endif
#else
/* Assume SDL2 might be available, try to include */
#  if defined(_WIN32) || defined(__MINGW32__)
#    define SDL2_AVAILABLE 1
#    include <SDL.h>
#  else
#    define SDL2_AVAILABLE 0
#  endif
#endif

#include "sdl_backend.h"
#include "midp.h"
#include "midi.h"
#include "debug.h"

/* Global context */
static SdlContext* g_sdl_ctx_ptr = NULL;

/* Mutex for thread-safe SDL access */
#ifdef _WIN32
#include <windows.h>
static CRITICAL_SECTION g_sdl_mutex;
static bool g_sdl_mutex_initialized = false;
#define SDL_LOCK() EnterCriticalSection(&g_sdl_mutex)
#define SDL_UNLOCK() LeaveCriticalSection(&g_sdl_mutex)
#else
#include <pthread.h>
static pthread_mutex_t g_sdl_mutex = PTHREAD_MUTEX_INITIALIZER;
#define SDL_LOCK() pthread_mutex_lock(&g_sdl_mutex)
#define SDL_UNLOCK() pthread_mutex_unlock(&g_sdl_mutex)
#endif

#if SDL2_AVAILABLE
static SDL_Window* g_window = NULL;
static SDL_Renderer* g_renderer = NULL;
static SDL_Texture* g_texture = NULL;
static SDL_AudioDeviceID g_audio_dev = 0;

/* Key mapping tables */
static const struct {
    SDL_Keycode sdl_key;
    int midp_key;
    int game_action;
} key_map[] = {
    {SDLK_0, '0', 0}, {SDLK_1, '1', 0}, {SDLK_2, '2', 0},
    {SDLK_3, '3', 0}, {SDLK_4, '4', 0}, {SDLK_5, '5', 0},
    {SDLK_6, '6', 0}, {SDLK_7, '7', 0}, {SDLK_8, '8', 0},
    {SDLK_9, '9', 0}, {SDLK_ASTERISK, '*', 0}, {SDLK_HASH, '#', 0},
    {SDLK_UP, 0, GAME_UP}, {SDLK_DOWN, 0, GAME_DOWN},
    {SDLK_LEFT, 0, GAME_LEFT}, {SDLK_RIGHT, 0, GAME_RIGHT},
    {SDLK_RETURN, 0, GAME_FIRE}, {SDLK_SPACE, 0, GAME_FIRE},
    {SDLK_a, 0, GAME_A}, {SDLK_b, 0, GAME_B},
    {SDLK_c, 0, GAME_C}, {SDLK_d, 0, GAME_D},
    {SDLK_ESCAPE, 0, 0},
};
#define KEY_MAP_SIZE (sizeof(key_map) / sizeof(key_map[0]))

/* Audio callback - generates MIDI and WAV audio */
static void audio_callback(void* userdata, Uint8* stream, int len) {
    (void)userdata;
    
    /* Clear the buffer */
    memset(stream, 0, len);
    
    /* Get MIDI audio from media.c */
    extern MidiFile* media_get_midi_for_audio(void);
    extern void media_generate_wav_samples(int16_t* buffer, int samples_needed);
    
    int16_t* buf = (int16_t*)stream;
    int samples = len / 4;  /* 16-bit stereo = 4 bytes per sample */
    
    /* Generate MIDI audio */
    MidiFile* midi = media_get_midi_for_audio();
    if (midi) {
        midi_generate_samples(midi, buf, samples);
    }
    
    /* Mix in WAV audio */
    media_generate_wav_samples(buf, samples);
}
#endif /* SDL2_AVAILABLE */

/* Initialize SDL */
int sdl_init(JVM* jvm, int width, int height, int scale) {
    DEBUG_LOG("[SDL] Initializing %dx%d (scale: %d)", width, height, scale);

#ifdef _WIN32
    /* Initialize mutex for Windows */
    if (!g_sdl_mutex_initialized) {
        InitializeCriticalSection(&g_sdl_mutex);
        g_sdl_mutex_initialized = true;
    }
#endif

    /* Use the global context pointer set by main.c */
    if (!g_sdl_ctx_ptr) {
        DEBUG_LOG("[SDL] ERROR: g_sdl_ctx_ptr is NULL - must be set before sdl_init");
        return -1;
    }
    
    SdlContext* ctx = g_sdl_ctx_ptr;
    memset(ctx, 0, sizeof(SdlContext));
    ctx->width = width;
    ctx->height = height;
    ctx->scale = scale;
    ctx->jvm = jvm;
    ctx->running = true;
    ctx->target_fps = 60;  /* Default FPS */
    ctx->input.pointer_x = 0;
    ctx->input.pointer_y = 0;
    ctx->input.pointer_pressed = false;
    memset(ctx->input.key_states, 0, sizeof(ctx->input.key_states));

    /* Allocate framebuffer */
    ctx->framebuffer = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    if (!ctx->framebuffer) {
        return -1;
    }

#if SDL2_AVAILABLE
    /* Set hints to avoid Direct3D issues on Windows */
    SDL_SetHint(SDL_HINT_RENDER_DRIVER, "software");
    SDL_SetHint(SDL_HINT_FRAMEBUFFER_ACCELERATION, "0");
    SDL_SetHint(SDL_HINT_RENDER_VSYNC, "0");
    
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) {
        DEBUG_LOG("[SDL] Failed to initialize: %s", SDL_GetError());
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    g_window = SDL_CreateWindow(
        "J2ME Emulator",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        width * scale, height * scale,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );

    if (!g_window) {
        DEBUG_LOG("[SDL] Failed to create window: %s", SDL_GetError());
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    /* Use software renderer directly to avoid Direct3D issues */
    g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_SOFTWARE);

    if (!g_renderer) {
        /* Fallback: try any available renderer */
        g_renderer = SDL_CreateRenderer(g_window, -1, 0);
    }

    if (!g_renderer) {
        DEBUG_LOG("[SDL] Failed to create renderer: %s", SDL_GetError());
        SDL_DestroyWindow(g_window);
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    SDL_RenderSetLogicalSize(g_renderer, width, height);

    g_texture = SDL_CreateTexture(g_renderer,
        SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING,
        width, height);

    if (!g_texture) {
        DEBUG_LOG("[SDL] Failed to create texture: %s", SDL_GetError());
        SDL_DestroyRenderer(g_renderer);
        SDL_DestroyWindow(g_window);
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    DEBUG_LOG("[SDL] Initialized with real SDL2");
#else
    DEBUG_LOG("[SDL] Running in headless mode (no SDL2)");
    DEBUG_LOG("[SDL] Press Ctrl+C to exit");
#endif

    DEBUG_LOG("[SDL] Context: %p, target_fps: %d", (void*)ctx, ctx->target_fps);
    return 0;
}

/* Destroy SDL */
void sdl_destroy(SdlContext* ctx) {
#if SDL2_AVAILABLE
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    SDL_Quit();
#endif

    if (ctx && ctx->framebuffer) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
    }
}

/* Process events */
void sdl_process_events(SdlContext* ctx) {
#if SDL2_AVAILABLE
    SDL_Event event;

    /* Forward declarations for MIDP input functions */
    extern void midp_call_keyPressed(JVM* jvm, int keycode);
    extern void midp_call_keyReleased(JVM* jvm, int keycode);
    extern void midp_call_pointerPressed(JVM* jvm, int x, int y);
    extern void midp_call_pointerReleased(JVM* jvm, int x, int y);
    extern void midp_call_pointerDragged(JVM* jvm, int x, int y);
    
    /* Track previous pointer state for drag detection */
    static int prev_pointer_x = -1;
    static int prev_pointer_y = -1;
    static bool prev_pointer_pressed = false;

    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                ctx->running = false;
                if (ctx->jvm) ctx->jvm->running = false;
                break;

            case SDL_KEYDOWN:
            case SDL_KEYUP:
                {
                    bool pressed = (event.type == SDL_KEYDOWN);
                    SDL_Keycode key = event.key.keysym.sym;
                    
                    /* Ignore key repeat events - only process initial press and release */
                    if (pressed && event.key.repeat) {
                        break;
                    }
                    
                    int midp_key = 0;
                    int game_action = 0;

                    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
                        if (key_map[i].sdl_key == key) {
                            if (key_map[i].midp_key) {
                                midp_key = key_map[i].midp_key;
                                ctx->input.key_states[midp_key] = pressed;
                            }
                            if (key_map[i].game_action) {
                                game_action = key_map[i].game_action;
                                ctx->input.key_states[game_action] = pressed;
                                fprintf(stderr, "[SDL] Key %s: SDL=%d -> game_action=%d, key_states[%d]=%d\n",
                                        pressed ? "DOWN" : "UP", key, game_action, game_action, pressed);
                            }
                            break;
                        }
                    }

                    /* Call keyPressed/keyReleased on Canvas */
                    if (ctx->jvm && (midp_key || game_action)) {
                        /* Use negative values for game actions (MIDP standard) */
                        int keycode = midp_key ? midp_key : -game_action;
                        
                        if (pressed) {
                            DEBUG_LOG("[SDL] Key pressed: SDL=%d -> MIDP=%d", key, keycode);
                            midp_call_keyPressed(ctx->jvm, keycode);
                        } else {
                            midp_call_keyReleased(ctx->jvm, keycode);
                        }
                    }

                    if (key == SDLK_ESCAPE && pressed) {
                        ctx->running = false;
                        if (ctx->jvm) ctx->jvm->running = false;
                    }
                }
                break;

            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
                {
                    bool pressed = (event.type == SDL_MOUSEBUTTONDOWN);
                    int x = event.button.x / ctx->scale;
                    int y = event.button.y / ctx->scale;
                    
                    ctx->input.pointer_x = x;
                    ctx->input.pointer_y = y;
                    ctx->input.pointer_pressed = pressed;
                    
                    /* Call pointer event handlers */
                    if (ctx->jvm) {
                        if (pressed && !prev_pointer_pressed) {
                            /* pointerPressed: transition from not pressed to pressed */
                            DEBUG_LOG("[SDL] Pointer pressed at (%d, %d)", x, y);
                            midp_call_pointerPressed(ctx->jvm, x, y);
                        } else if (!pressed && prev_pointer_pressed) {
                            /* pointerReleased: transition from pressed to not pressed */
                            DEBUG_LOG("[SDL] Pointer released at (%d, %d)", x, y);
                            midp_call_pointerReleased(ctx->jvm, x, y);
                        }
                    }
                    
                    prev_pointer_x = x;
                    prev_pointer_y = y;
                    prev_pointer_pressed = pressed;
                }
                break;

            case SDL_MOUSEMOTION:
                {
                    int x = event.motion.x / ctx->scale;
                    int y = event.motion.y / ctx->scale;
                    
                    ctx->input.pointer_x = x;
                    ctx->input.pointer_y = y;
                    
                    /* Check for drag: pointer is pressed and moving */
                    if (ctx->jvm && prev_pointer_pressed && 
                        (x != prev_pointer_x || y != prev_pointer_y)) {
                        DEBUG_LOG("[SDL] Pointer dragged to (%d, %d)", x, y);
                        midp_call_pointerDragged(ctx->jvm, x, y);
                    }
                    
                    prev_pointer_x = x;
                    prev_pointer_y = y;
                }
                break;

            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_RESIZED) {
                    int new_w = event.window.data1;
                    int new_h = event.window.data2;
                    ctx->scale = (new_w / ctx->width < new_h / ctx->height)
                        ? new_w / ctx->width : new_h / ctx->height;
                    if (ctx->scale < 1) ctx->scale = 1;
                }
                break;
        }
    }
#endif
}

/* Minimal event processing for cooperative threading - called from Thread.sleep() */
void sdl_process_events_minimal(void) {
#if SDL2_AVAILABLE
    if (!g_sdl_ctx_ptr) return;
    
    SDL_LOCK();
    SDL_Event event;
    /* Process only quit events to allow clean shutdown during sleep */
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            g_sdl_ctx_ptr->running = false;
            if (g_sdl_ctx_ptr->jvm) g_sdl_ctx_ptr->jvm->running = false;
        } else if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
            g_sdl_ctx_ptr->running = false;
            if (g_sdl_ctx_ptr->jvm) g_sdl_ctx_ptr->jvm->running = false;
        }
    }
    SDL_UNLOCK();
#endif
}

/* Set global context (called by main.c before sdl_init) */
void sdl_set_global_context(SdlContext* ctx) {
    g_sdl_ctx_ptr = ctx;
    DEBUG_LOG("[SDL] Global context set to %p", (void*)ctx);
}

/* Get global context */
SdlContext* sdl_get_global_context(void) {
    return g_sdl_ctx_ptr;
}

/* Run main loop */
void sdl_run(SdlContext* ctx) {
    if (!ctx) {
        DEBUG_LOG("[SDL] ERROR: sdl_run called with NULL context");
        return;
    }
    
    /* Check if context was properly initialized */
    if (ctx->target_fps <= 0 || ctx->framebuffer == NULL) {
        DEBUG_LOG("[SDL] ERROR: Context not properly initialized");
        DEBUG_LOG("[SDL] target_fps=%d, framebuffer=%p, width=%d, height=%d",
                ctx->target_fps, (void*)ctx->framebuffer, ctx->width, ctx->height);
        DEBUG_LOG("[SDL] This usually means sdl_init() failed or was not called");
        return;
    }

    DEBUG_LOG("[SDL] Running main loop (FPS: %d, %dx%d)", ctx->target_fps, ctx->width, ctx->height);

    /* External function from display.c for callSerially processing */
    extern void midp_process_call_serially_queue(JVM* jvm);
    extern void jvm_process_timers(JVM* jvm);

#if SDL2_AVAILABLE
    uint64_t last_time = SDL_GetTicks();
    const uint64_t frame_time = 1000 / ctx->target_fps;

    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        sdl_process_events(ctx);
        
        /* Process timers (synchronously in main thread) */
        jvm_process_timers(ctx->jvm);
        
        /* Process callSerially queue after events, before rendering */
        midp_process_call_serially_queue(ctx->jvm);
        
        /* Lock SDL for rendering */
        SDL_LOCK();
        sdl_update_texture(ctx);
        SDL_RenderClear(g_renderer);
        SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
        SDL_RenderPresent(g_renderer);
        SDL_UNLOCK();

        uint64_t current_time = SDL_GetTicks();
        uint64_t elapsed = current_time - last_time;
        if (elapsed < frame_time) {
            SDL_Delay(frame_time - elapsed);
        }
        last_time = SDL_GetTicks();
    }
#else
    /* Headless mode - simple delay loop */
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        /* Process timers */
        jvm_process_timers(ctx->jvm);
        
        /* Process callSerially queue */
        midp_process_call_serially_queue(ctx->jvm);
        
#ifdef _WIN32
        Sleep(16);  /* ~60 FPS on Windows */
#else
        usleep(16000);  /* ~60 FPS on POSIX */
#endif
    }
#endif
}

/* Stop */
void sdl_stop(SdlContext* ctx) {
    if (ctx) ctx->running = false;
}

/* Get framebuffer */
uint32_t* sdl_get_framebuffer(SdlContext* ctx) {
    return ctx ? ctx->framebuffer : NULL;
}

/* Clear */
void sdl_clear(SdlContext* ctx, uint32_t color) {
    if (!ctx || !ctx->framebuffer) return;
    for (int i = 0; i < ctx->width * ctx->height; i++) {
        ctx->framebuffer[i] = color;
    }
}

/* Present */
void sdl_present(SdlContext* ctx) {
#if SDL2_AVAILABLE
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) return;
    
    SDL_LOCK();
    sdl_update_texture(ctx);
    SDL_RenderClear(g_renderer);
    SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
    SDL_RenderPresent(g_renderer);
    SDL_UNLOCK();
#endif
}

/* Update texture */
void sdl_update_texture(SdlContext* ctx) {
#if SDL2_AVAILABLE
    if (ctx && ctx->framebuffer && g_texture) {
        SDL_UpdateTexture(g_texture, NULL, ctx->framebuffer,
            ctx->width * sizeof(uint32_t));
    }
#endif
}

/* Key mapping */
int sdl_key_to_midp(int sdl_key) {
#if SDL2_AVAILABLE
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == sdl_key) return key_map[i].midp_key;
    }
#endif
    return sdl_key;
}

int sdl_key_to_game_action(int sdl_key) {
#if SDL2_AVAILABLE
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == sdl_key) return key_map[i].game_action;
    }
#endif
    return 0;
}

/* Key state - uses SDL_GetKeyboardState for real-time state */
bool sdl_key_pressed(SdlContext* ctx, int keycode) {
    (void)ctx;  /* Not needed when using SDL_GetKeyboardState */
    
#if SDL2_AVAILABLE
    /* Pump events to ensure keyboard state is current */
    SDL_PumpEvents();
    
    /* Get the current keyboard state directly from SDL */
    const Uint8* keyboard_state = SDL_GetKeyboardState(NULL);
    if (!keyboard_state) {
        return false;
    }
    
    /* Map game action to SDL scancode */
    SDL_Scancode scancode = 0;
    switch (keycode) {
        case GAME_UP:    scancode = SDL_SCANCODE_UP; break;
        case GAME_DOWN:  scancode = SDL_SCANCODE_DOWN; break;
        case GAME_LEFT:  scancode = SDL_SCANCODE_LEFT; break;
        case GAME_RIGHT: scancode = SDL_SCANCODE_RIGHT; break;
        case GAME_FIRE:  /* FIRE can be Return or Space */
            if (keyboard_state[SDL_SCANCODE_RETURN] || keyboard_state[SDL_SCANCODE_SPACE]) {
                fprintf(stderr, "[sdl_key_pressed] FIRE (keycode=%d) -> pressed\n", keycode);
                return true;
            }
            return false;
        case GAME_A: scancode = SDL_SCANCODE_A; break;
        case GAME_B: scancode = SDL_SCANCODE_B; break;
        case GAME_C: scancode = SDL_SCANCODE_C; break;
        case GAME_D: scancode = SDL_SCANCODE_D; break;
        default:
            /* For other keycodes (regular keys), check keyboard state directly */
            if (keycode >= 0 && keycode < 256) {
                /* Try to map ASCII to scancode */
                if (keycode >= '0' && keycode <= '9') {
                    scancode = SDL_SCANCODE_0 + (keycode - '0');
                } else if (keycode >= 'a' && keycode <= 'z') {
                    scancode = SDL_SCANCODE_A + (keycode - 'a');
                } else {
                    return false;
                }
            } else {
                return false;
            }
            break;
    }
    
    bool state = keyboard_state[scancode];
    if (state) {
        fprintf(stderr, "[sdl_key_pressed] keycode=%d -> pressed (scancode=%d)\n", keycode, scancode);
    }
    return state;
#else
    (void)keycode;
    return false;
#endif
}

/* Pointer */
void sdl_get_pointer(SdlContext* ctx, int* x, int* y) {
    if (!ctx) { if (x) *x = 0; if (y) *y = 0; return; }
    if (x) *x = ctx->input.pointer_x;
    if (y) *y = ctx->input.pointer_y;
}

bool sdl_pointer_pressed(SdlContext* ctx) {
    return ctx ? ctx->input.pointer_pressed : false;
}

/* Audio */
int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
    (void)ctx; (void)frequency; (void)channels; (void)samples;
#if SDL2_AVAILABLE
    if (g_audio_dev) SDL_CloseAudioDevice(g_audio_dev);

    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof(want));
    want.freq = frequency;
    want.format = AUDIO_S16;
    want.channels = channels;
    want.samples = samples;
    want.callback = audio_callback;
    want.userdata = ctx;

    g_audio_dev = SDL_OpenAudioDevice(NULL, 0, &want, &have,
        SDL_AUDIO_ALLOW_FREQUENCY_CHANGE | SDL_AUDIO_ALLOW_CHANNELS_CHANGE);

    if (g_audio_dev == 0) {
        DEBUG_LOG("[SDL] Failed to open audio: %s", SDL_GetError());
        return -1;
    }

    SDL_PauseAudioDevice(g_audio_dev, 0);
    DEBUG_LOG("[SDL] Audio: %d Hz, %d channels", have.freq, have.channels);
    return 0;
#else
    return 0;
#endif
}

void sdl_audio_close(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) { SDL_CloseAudioDevice(g_audio_dev); g_audio_dev = 0; }
#endif
}

int sdl_audio_queue(SdlContext* ctx, const void* data, size_t length) {
    (void)ctx; (void)data; (void)length;
#if SDL2_AVAILABLE
    if (g_audio_dev) return SDL_QueueAudio(g_audio_dev, data, length);
#endif
    return -1;
}

uint32_t sdl_audio_queued_size(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) return SDL_GetQueuedAudioSize(g_audio_dev);
#endif
    return 0;
}

void sdl_audio_clear(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) SDL_ClearQueuedAudio(g_audio_dev);
#endif
}

/* Simple audio init without context */
int sdl_audio_init_simple(uint32_t sample_rate) {
#if SDL2_AVAILABLE
    if (g_audio_dev) return 0;  /* Already initialized */
    
    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof(want));
    want.freq = sample_rate;
    want.format = AUDIO_S16;
    want.channels = 2;  /* Stereo */
    want.samples = 1024;
    want.callback = audio_callback;
    want.userdata = NULL;
    
    g_audio_dev = SDL_OpenAudioDevice(NULL, 0, &want, &have,
        SDL_AUDIO_ALLOW_FREQUENCY_CHANGE | SDL_AUDIO_ALLOW_CHANNELS_CHANGE);
    
    if (g_audio_dev == 0) {
        DEBUG_LOG("[SDL] Failed to open audio: %s", SDL_GetError());
        return -1;
    }
    
    SDL_PauseAudioDevice(g_audio_dev, 0);  /* Start audio */
    DEBUG_LOG("[SDL] Audio initialized: %d Hz, %d channels", have.freq, have.channels);
    return 0;
#else
    (void)sample_rate;
    return 0;
#endif
}

void sdl_audio_shutdown(void) {
#if SDL2_AVAILABLE
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
#endif
}

/* Timing */
uint64_t sdl_get_ticks(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    return SDL_GetTicks();
#else
#ifdef _WIN32
    return GetTickCount();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
#endif
}

void sdl_sleep(uint32_t ms) {
#if SDL2_AVAILABLE
    SDL_Delay(ms);
#else
#ifdef _WIN32
    Sleep(ms);
#else
    usleep(ms * 1000);
#endif
#endif
}

/* Window */
void sdl_set_title(SdlContext* ctx, const char* title) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_window && title) SDL_SetWindowTitle(g_window, title);
#endif
}

void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) {
    (void)ctx; (void)fullscreen;
#if SDL2_AVAILABLE
    if (g_window) SDL_SetWindowFullscreen(g_window,
        fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
#endif
}

void sdl_toggle_fullscreen(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_window) {
        Uint32 flags = SDL_GetWindowFlags(g_window);
        SDL_SetWindowFullscreen(g_window,
            (flags & SDL_WINDOW_FULLSCREEN_DESKTOP) ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP);
    }
#endif
}

int sdl_resize(SdlContext* ctx, int width, int height) {
    if (!ctx || width <= 0 || height <= 0) return -1;

    /* ИСПРАВЛЕНО: Сначала выделяем новую память, потом освобождаем старую */
    uint32_t* new_framebuffer = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    if (!new_framebuffer) {
        ERROR_LOG("[SDL] Failed to allocate new framebuffer in sdl_resize");
        return -1;
    }

#if SDL2_AVAILABLE
    SDL_Texture* new_texture = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
        SDL_TEXTUREACCESS_STREAMING, width, height);
    if (!new_texture) {
        ERROR_LOG("[SDL] Failed to create new texture in sdl_resize: %s", SDL_GetError());
        free(new_framebuffer);
        return -1;
    }
#endif

    /* Only free old resources after successful allocation */
    free(ctx->framebuffer);
    ctx->framebuffer = new_framebuffer;
    ctx->width = width;
    ctx->height = height;

#if SDL2_AVAILABLE
    if (g_texture) SDL_DestroyTexture(g_texture);
    g_texture = new_texture;
    SDL_RenderSetLogicalSize(g_renderer, width, height);
#endif
    return 0;
}

int sdl_screenshot(SdlContext* ctx, const char* filename) {
    if (!ctx || !filename) return -1;
#if SDL2_AVAILABLE
    if (g_renderer) {
        SDL_Surface* surface = SDL_CreateRGBSurface(0,
            ctx->width * ctx->scale, ctx->height * ctx->scale, 32,
            0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        if (surface) {
            SDL_RenderReadPixels(g_renderer, NULL, SDL_PIXELFORMAT_ARGB8888,
                surface->pixels, surface->pitch);
            int result = SDL_SaveBMP(surface, filename);
            SDL_FreeSurface(surface);
            return result;
        }
    }
#endif
    return -1;
}

MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    static MidpGraphics gfx;
    if (!ctx) {
        DEBUG_LOG("[SDL] WARNING: sdl_get_graphics called with NULL context");
        return NULL;
    }
    if (!ctx->framebuffer) {
        DEBUG_LOG("[SDL] WARNING: sdl_get_graphics - framebuffer is NULL");
        return NULL;
    }
    midp_graphics_init(&gfx, ctx->framebuffer, ctx->width, ctx->height);
    return &gfx;
}

MidpPlatformCallbacks* sdl_get_platform_callbacks(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

void sdl_dump_info(SdlContext* ctx) {
    if (!ctx) return;
    DEBUG_LOG("[SDL] Window: %dx%d (scale: %d)", ctx->width, ctx->height, ctx->scale);
#if SDL2_AVAILABLE
    DEBUG_LOG("[SDL] Renderer: %s", SDL_GetCurrentVideoDriver());
    if (g_window) {
        int w, h;
        SDL_GetWindowSize(g_window, &w, &h);
        DEBUG_LOG("[SDL] Window size: %dx%d", w, h);
    }
#else
    DEBUG_LOG("[SDL] Running in headless mode");
#endif
}
