/*
 * J2ME Emulator - MIDP2 Display and Game Canvas
 */

#define _GNU_SOURCE  /* For strdup */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "midp.h"
#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "sdl_backend.h"
#include "threads.h"
#include "opcodes.h"  /* For ACC_PRIVATE */
#include "debug.h"

/* Sprite transform constants - used by Graphics.drawRegion and Image.createImage */
#define SPRITE_TRANS_NONE           0
#define SPRITE_TRANS_MIRROR_ROT180  1
#define SPRITE_TRANS_MIRROR         2
#define SPRITE_TRANS_ROT180         3
#define SPRITE_TRANS_MIRROR_ROT270  4
#define SPRITE_TRANS_ROT90          5
#define SPRITE_TRANS_ROT270         6
#define SPRITE_TRANS_MIRROR_ROT90   7

/* Forward declaration from execute.c */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args, JavaValue* result);

/* Global Graphics object - reused for all paint() calls */
static JavaObject* g_graphics_object = NULL;
static MidpGraphics g_screen_graphics;  /* Static Graphics for screen rendering */

/* Current displayable - stored as GC root */
static JavaObject* current_displayable_obj = NULL;

/* Forward declaration */
static void ensure_native_peer_field(JavaClass* clazz);

/* Register global objects as GC roots */
static void register_gc_roots(JVM* jvm) {
    /* Register g_graphics_object as a GC root */
    gc_add_root(jvm, (void**)&g_graphics_object);
    /* Register current_displayable_obj as a GC root */
    gc_add_root(jvm, (void**)&current_displayable_obj);
}

/* Create a Java Graphics object bound to screen framebuffer */
static JavaObject* create_graphics_object(JVM* jvm) {
    if (g_graphics_object) {
        /* Reset clip to full screen before reusing */
        g_screen_graphics.clip_x = 0;
        g_screen_graphics.clip_y = 0;
        g_screen_graphics.clip_width = g_screen_graphics.width;
        g_screen_graphics.clip_height = g_screen_graphics.height;
        g_screen_graphics.translate_x = 0;
        g_screen_graphics.translate_y = 0;
        return g_graphics_object;
    }
    
    /* Get the Graphics class */
    JavaClass* gfx_class = jvm_load_class(jvm, "javax/microedition/lcdui/Graphics");
    if (!gfx_class) {
        ERROR_LOG("Failed to load Graphics class");
        return NULL;
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(gfx_class);
    
    /* Create Graphics object */
    g_graphics_object = jvm_new_object(jvm, gfx_class);
    if (!g_graphics_object) {
        ERROR_LOG("Failed to create Graphics object");
        return NULL;
    }
    
    /* Register as GC root to prevent collection */
    gc_add_root(jvm, (void**)&g_graphics_object);
    
    /* Initialize the MidpGraphics structure for screen */
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (sdl_ctx && sdl_ctx->framebuffer) {
        midp_graphics_init(&g_screen_graphics, sdl_ctx->framebuffer, 
                          sdl_ctx->width, sdl_ctx->height);
    }
    
    /* Store the MidpGraphics* in the first field */
    g_graphics_object->fields[0].ref = &g_screen_graphics;
    
    DISP_DEBUG("Created Graphics object: %p, MidpGraphics: %p (%dx%d)", 
            (void*)g_graphics_object, (void*)&g_screen_graphics,
            g_screen_graphics.width, g_screen_graphics.height);
    
    return g_graphics_object;
}

/* Get MidpGraphics from a Java Graphics object */
MidpGraphics* get_graphics_from_object(JavaObject* obj) {
    if (!obj) return NULL;
    /* For the screen graphics object, return the global */
    if (obj == g_graphics_object) {
        return &g_screen_graphics;
    }
    /* For other Graphics objects (from Images), check first field as pointer */
    /* The Graphics class may have a native peer field */
    if (obj->header.clazz && obj->header.clazz->instance_size >= sizeof(void*)) {
        MidpGraphics* gfx = (MidpGraphics*)obj->fields[0].ref;
        if (gfx) return gfx;
    }
    /* Fallback to screen graphics */
    return &g_screen_graphics;
}

/* Event queue */
#define MAX_EVENTS 256

static struct {
    MidpEvent events[MAX_EVENTS];
    int head;
    int tail;
    int count;
} event_queue;

/* Game canvas state */
static struct {
    int key_states;
    MidpGraphics* graphics;
    bool suppress_key_events;
} game_canvas;

/* Platform callbacks */
static MidpPlatformCallbacks platform_callbacks;

/* Forward declarations */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args, JavaValue* result);

/* Call keyPressed on the current displayable */
void midp_call_keyPressed(JVM* jvm, int keycode) {
    if (!jvm || !current_displayable_obj) {
        DISP_DEBUG("keyPressed: no current displayable");
        return;
    }
    
    JavaObject* displayable = current_displayable_obj;
    JavaClass* clazz = displayable->header.clazz;
    
    if (!clazz) {
        ERROR_LOG("keyPressed: displayable has no class");
        return;
    }
    
    /* Check if this is a high-level UI that needs form key handling */
    if (clazz->class_name) {
        bool is_high_level_ui = false;
        JavaClass* check = clazz;
        while (check) {
            if (check->class_name) {
                if (strcmp(check->class_name, "javax/microedition/lcdui/Form") == 0 ||
                    strcmp(check->class_name, "javax/microedition/lcdui/List") == 0 ||
                    strcmp(check->class_name, "javax/microedition/lcdui/TextBox") == 0 ||
                    strcmp(check->class_name, "javax/microedition/lcdui/Alert") == 0) {
                    is_high_level_ui = true;
                    break;
                }
            }
            check = check->super_class;
        }
        
        if (is_high_level_ui) {
            /* Handle key for high-level UI (forms, lists, virtual keyboard) */
            DISP_DEBUG("keyPressed: high-level UI detected (%s)", clazz->class_name);
            
            /* Convert keycode to game action if negative */
            int game_action = 0;
            if (keycode < 0) {
                game_action = -keycode;
            } else {
                /* Map regular keycodes to game actions */
                switch (keycode) {
                    case -1: game_action = 1; break;  /* UP */
                    case -2: game_action = 6; break;  /* DOWN */
                    case -3: game_action = 2; break;  /* LEFT */
                    case -4: game_action = 5; break;  /* RIGHT */
                    case -5: game_action = 8; break;  /* FIRE */
                    default: game_action = keycode; break;
                }
            }
            
            /* First check if virtual keyboard is active */
            if (midp_is_vkb_active()) {
                midp_vkb_process_key(jvm, game_action);
                /* Re-render the form/textbox */
                if (midp_is_vkb_active()) {
                    /* Keyboard still active, re-render */
                    if (strstr(clazz->class_name, "Form")) {
                        midp_render_form(jvm, displayable);
                    } else if (strstr(clazz->class_name, "TextBox")) {
                        midp_render_textbox(jvm, displayable, "", 0);
                    }
                } else {
                    /* Keyboard closed, re-render form */
                    midp_render_form(jvm, displayable);
                }
                return;
            }
            
            /* Handle form navigation */
            if (midp_form_handle_key(jvm, game_action)) {
                DISP_DEBUG("Key handled by form handler");
                return;
            }
            
            /* Key not handled, fall through to default behavior */
        }
    }
    
    /* Find keyPressed method */
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "keyPressed", "(I)V");
    if (!method) {
        DISP_DEBUG("keyPressed method not found in %s", clazz->class_name);
        return;
    }
    
    fprintf(stderr, "[Input] Calling keyPressed(%d) on %s\n", keycode, clazz->class_name);
    fflush(stderr);
    
    /* Prepare arguments: this + keycode */
    JavaValue args[2];
    args[0].ref = displayable;       /* this */
    args[1].i = keycode;            /* keyCode */
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    
    int ret = execute_method(jvm, thread, method, args, &result);
    fprintf(stderr, "[Input] keyPressed returned %d\n", ret);
    fflush(stderr);
    
    /* Repaint the canvas after key press */
    if (ret == 0) {
        fprintf(stderr, "[Input] keyPressed successful, calling repaint...\n");
        fflush(stderr);
        
        /* Call paint to redraw */
        JavaObject* gfx_obj = create_graphics_object(jvm);
        if (gfx_obj) {
            JavaMethod* paint_method = jvm_resolve_method(jvm, clazz, "paint", "(Ljavax/microedition/lcdui/Graphics;)V");
            if (paint_method) {
                fprintf(stderr, "[Input] Calling paint() after keyPressed\n");
                fflush(stderr);
                
                JavaValue paint_args[2];
                paint_args[0].ref = displayable;
                paint_args[1].ref = gfx_obj;
                execute_method(jvm, thread, paint_method, paint_args, &result);
                
                /* Present to screen */
                SdlContext* sdl_ctx = sdl_get_global_context();
                if (sdl_ctx) {
                    fprintf(stderr, "[Input] Presenting to screen after paint\n");
                    fflush(stderr);
                    sdl_present(sdl_ctx);
                }
            } else {
                fprintf(stderr, "[Input] paint() method not found!\n");
                fflush(stderr);
            }
        }
    }
}

/* Call keyReleased on the current displayable */
void midp_call_keyReleased(JVM* jvm, int keycode) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* canvas = current_displayable_obj;
    JavaClass* clazz = canvas->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "keyReleased", "(I)V");
    if (!method) return;
    
    fprintf(stderr, "[Input] Calling keyReleased(%d) on %s\n", keycode, clazz->class_name);
    
    JavaValue args[2];
    args[0].ref = canvas;
    args[1].i = keycode;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Call pointerPressed on the current displayable */
void midp_call_pointerPressed(JVM* jvm, int x, int y) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* canvas = current_displayable_obj;
    JavaClass* clazz = canvas->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "pointerPressed", "(II)V");
    if (!method) {
        fprintf(stderr, "[Input] pointerPressed method not found in %s\n", clazz->class_name);
        return;
    }
    
    fprintf(stderr, "[Input] Calling pointerPressed(%d, %d) on %s\n", x, y, clazz->class_name);
    
    JavaValue args[3];
    args[0].ref = canvas;
    args[1].i = x;
    args[2].i = y;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Call pointerReleased on the current displayable */
void midp_call_pointerReleased(JVM* jvm, int x, int y) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* canvas = current_displayable_obj;
    JavaClass* clazz = canvas->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "pointerReleased", "(II)V");
    if (!method) {
        fprintf(stderr, "[Input] pointerReleased method not found in %s\n", clazz->class_name);
        return;
    }
    
    fprintf(stderr, "[Input] Calling pointerReleased(%d, %d) on %s\n", x, y, clazz->class_name);
    
    JavaValue args[3];
    args[0].ref = canvas;
    args[1].i = x;
    args[2].i = y;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Call pointerDragged on the current displayable */
void midp_call_pointerDragged(JVM* jvm, int x, int y) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* canvas = current_displayable_obj;
    JavaClass* clazz = canvas->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "pointerDragged", "(II)V");
    if (!method) {
        fprintf(stderr, "[Input] pointerDragged method not found in %s\n", clazz->class_name);
        return;
    }
    
    fprintf(stderr, "[Input] Calling pointerDragged(%d, %d) on %s\n", x, y, clazz->class_name);
    
    JavaValue args[3];
    args[0].ref = canvas;
    args[1].i = x;
    args[2].i = y;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Call showNotify on the current displayable */
void midp_call_showNotify(JVM* jvm) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* displayable = current_displayable_obj;
    JavaClass* clazz = displayable->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "showNotify", "()V");
    if (!method) return;  /* Not all classes implement this */
    
    fprintf(stderr, "[Display] Calling showNotify() on %s\n", clazz->class_name);
    
    JavaValue args[1];
    args[0].ref = displayable;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Call hideNotify on the current displayable */
void midp_call_hideNotify(JVM* jvm) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* displayable = current_displayable_obj;
    JavaClass* clazz = displayable->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "hideNotify", "()V");
    if (!method) return;  /* Not all classes implement this */
    
    fprintf(stderr, "[Display] Calling hideNotify() on %s\n", clazz->class_name);
    
    JavaValue args[1];
    args[0].ref = displayable;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Call sizeChanged on the current displayable */
void midp_call_sizeChanged(JVM* jvm, int w, int h) {
    if (!jvm || !current_displayable_obj) return;
    
    JavaObject* displayable = current_displayable_obj;
    JavaClass* clazz = displayable->header.clazz;
    if (!clazz) return;
    
    JavaMethod* method = jvm_resolve_method(jvm, clazz, "sizeChanged", "(II)V");
    if (!method) return;  /* Not all classes implement this */
    
    fprintf(stderr, "[Display] Calling sizeChanged(%d, %d) on %s\n", w, h, clazz->class_name);
    
    JavaValue args[3];
    args[0].ref = displayable;
    args[1].i = w;
    args[2].i = h;
    
    JavaValue result;
    JavaThread* thread = jvm_current_thread(jvm);
    execute_method(jvm, thread, method, args, &result);
}

/* Queue event */
void midp_event_queue(MidpEvent* event) {
    if (event_queue.count >= MAX_EVENTS) return;
    
    event_queue.events[event_queue.tail] = *event;
    event_queue.tail = (event_queue.tail + 1) % MAX_EVENTS;
    event_queue.count++;
}

/* Poll event */
bool midp_event_poll(MidpEvent* event) {
    if (event_queue.count == 0) return false;
    
    *event = event_queue.events[event_queue.head];
    event_queue.head = (event_queue.head + 1) % MAX_EVENTS;
    event_queue.count--;
    
    return true;
}

/* Process event */
void midp_event_process(JVM* jvm, MidpEvent* event) {
    if (!jvm || !event) return;
    
    /* TODO: Find the current Displayable and call appropriate methods */
    switch (event->type) {
        case MIDP_EVENT_KEY_PRESSED:
            /* Call keyPressed(int keyCode) */
            break;
            
        case MIDP_EVENT_KEY_RELEASED:
            /* Call keyReleased(int keyCode) */
            break;
            
        case MIDP_EVENT_KEY_REPEATED:
            /* Call keyRepeated(int keyCode) */
            break;
            
        case MIDP_EVENT_POINTER_PRESSED:
            /* Call pointerPressed(int x, int y) */
            break;
            
        case MIDP_EVENT_POINTER_RELEASED:
            /* Call pointerReleased(int x, int y) */
            break;
            
        case MIDP_EVENT_POINTER_DRAGGED:
            /* Call pointerDragged(int x, int y) */
            break;
            
        case MIDP_EVENT_COMMAND:
            /* Call commandAction */
            break;
            
        case MIDP_EVENT_SHOW_NOTIFY:
            /* Call showNotify */
            break;
            
        case MIDP_EVENT_HIDE_NOTIFY:
            /* Call hideNotify */
            break;
            
        case MIDP_EVENT_SIZE_CHANGED:
            /* Call sizeChanged */
            break;
            
        case MIDP_EVENT_REPAINT:
            /* Call paint */
            break;
    }
}

/* Set platform callbacks */
void midp_set_platform_callbacks(MidpPlatformCallbacks* callbacks) {
    if (callbacks) {
        platform_callbacks = *callbacks;
    }
}

/*
 * Display native methods
 */

/* Singleton Display instance */
static JavaObject* g_display_instance = NULL;

static JavaValue native_display_getDisplay(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    (void)args;  /* MIDlet parameter */
    
    fprintf(stderr, "[Display] getDisplay() called\n");
    fflush(stderr);
    
    /* Return singleton Display instance */
    if (!g_display_instance) {
        /* Create Display instance */
        JavaClass* display_class = jvm_load_class(jvm, "javax/microedition/lcdui/Display");
        if (display_class) {
            g_display_instance = jvm_new_object(jvm, display_class);
            /* Register as GC root to prevent collection */
            gc_add_root(jvm, (void**)&g_display_instance);
            fprintf(stderr, "[Display] Created Display instance: %p\n", (void*)g_display_instance);
            fflush(stderr);
        }
    }
    
    return NATIVE_RETURN_OBJECT(g_display_instance);
}

static JavaValue native_display_setCurrent(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* display = (JavaObject*)args[0].ref;
    JavaObject* displayable = (JavaObject*)args[1].ref;
    
    fprintf(stderr, "[Display] setCurrent(display=%p, displayable=%p)\n", 
            (void*)display, (void*)displayable);
    fflush(stderr);
    
    /* Store current displayable - register as GC root if first time */
    if (!current_displayable_obj) {
        gc_add_root(jvm, (void**)&current_displayable_obj);
    }
    current_displayable_obj = displayable;
    
    /* Also update form.c's g_current_displayable for key handling */
    midp_set_current_displayable(displayable);
    
    /* For Canvas, we need to call paint() automatically */
    if (displayable) {
        JavaClass* clazz = displayable->header.clazz;
        if (clazz && clazz->class_name) {
            fprintf(stderr, "[Display] Displayable class: %s\n", clazz->class_name);
            
            /* Check if this is a Form */
            bool is_form = false;
            bool is_list = false;
            bool is_alert = false;
            bool is_textbox = false;
            bool is_canvas = false;
            
            JavaClass* check = clazz;
            while (check) {
                if (check->class_name) {
                    if (strcmp(check->class_name, "javax/microedition/lcdui/Form") == 0 ||
                        strstr(check->class_name, "Form") != NULL) {
                        is_form = true;
                        break;
                    }
                    if (strcmp(check->class_name, "javax/microedition/lcdui/List") == 0 ||
                        strstr(check->class_name, "List") != NULL) {
                        is_list = true;
                        break;
                    }
                    if (strcmp(check->class_name, "javax/microedition/lcdui/Alert") == 0 ||
                        strstr(check->class_name, "Alert") != NULL) {
                        is_alert = true;
                        break;
                    }
                    if (strcmp(check->class_name, "javax/microedition/lcdui/TextBox") == 0 ||
                        strstr(check->class_name, "TextBox") != NULL) {
                        is_textbox = true;
                        break;
                    }
                    if (strcmp(check->class_name, "javax/microedition/lcdui/Canvas") == 0 ||
                        strstr(check->class_name, "Canvas") != NULL) {
                        is_canvas = true;
                        break;
                    }
                }
                check = check->super_class;
            }
            
            if (is_form) {
                fprintf(stderr, "[Display] Form detected, rendering...\n");
                midp_set_current_displayable(displayable);
                midp_render_form(jvm, displayable);
            } else if (is_list) {
                fprintf(stderr, "[Display] List detected, rendering...\n");
                midp_set_current_displayable(displayable);
                midp_render_list(jvm, displayable, 0);
                SdlContext* sdl_ctx = sdl_get_global_context();
                if (sdl_ctx) sdl_present(sdl_ctx);
            } else if (is_alert) {
                fprintf(stderr, "[Display] Alert detected, rendering...\n");
                midp_set_current_displayable(displayable);
                JavaObject* gfx_obj = create_graphics_object(jvm);
                if (gfx_obj) {
                    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
                    if (gfx) {
                        midp_render_alert(jvm, gfx, displayable);
                        SdlContext* sdl_ctx = sdl_get_global_context();
                        if (sdl_ctx) sdl_present(sdl_ctx);
                    }
                }
            } else if (is_textbox) {
                fprintf(stderr, "[Display] TextBox detected, rendering...\n");
                midp_set_current_displayable(displayable);
                midp_render_textbox(jvm, displayable, "", 0);
                SdlContext* sdl_ctx = sdl_get_global_context();
                if (sdl_ctx) sdl_present(sdl_ctx);
            } else if (is_canvas) {
                fprintf(stderr, "[Display] Canvas detected, calling paint()...\n");
                fflush(stderr);
                
                /* Create Java Graphics object bound to screen */
                JavaObject* gfx_obj = create_graphics_object(jvm);
                if (gfx_obj) {
                    fprintf(stderr, "[Display] Graphics object: %p, MidpGraphics: %p (%dx%d)\n", 
                            (void*)gfx_obj, (void*)&g_screen_graphics, 
                            g_screen_graphics.width, g_screen_graphics.height);
                    
                    /* Find and call paint(Graphics g) method */
                    JavaMethod* paint_method = jvm_resolve_method(jvm, clazz, "paint", "(Ljavax/microedition/lcdui/Graphics;)V");
                    if (paint_method) {
                        fprintf(stderr, "[Display] Found paint() method, calling...\n");
                        
                        /* Call paint(gfx) - args[0] = this, args[1] = Graphics */
                        JavaValue paint_args[2];
                        paint_args[0].ref = displayable;  /* this */
                        paint_args[1].ref = gfx_obj;      /* Graphics object */
                        
                        JavaValue result;
                        JavaThread* th = jvm_current_thread(jvm);
                        int ret = execute_method(jvm, th, paint_method, paint_args, &result);
                        
                        fprintf(stderr, "[Display] paint() returned %d\n", ret);
                        
                        /* Present to screen */
                        SdlContext* sdl_ctx = sdl_get_global_context();
                        if (sdl_ctx) {
                            sdl_present(sdl_ctx);
                        }
                    } else {
                        fprintf(stderr, "[Display] paint() method not found in %s\n", clazz->class_name);
                    }
                } else {
                    fprintf(stderr, "[Display] Failed to create Graphics object\n");
                }
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Display.getCurrent() - return current displayable */
static JavaValue native_display_getCurrent(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* display = (JavaObject*)args[0].ref;
    (void)display;  /* Display instance not used */
    
    fprintf(stderr, "[Display] getCurrent() -> displayable=%p\n", (void*)current_displayable_obj);
    
    return NATIVE_RETURN_OBJECT(current_displayable_obj);
}

/*
 * ============================================
 * CallSerially Queue Implementation
 * Stores Runnables for deferred execution on UI thread
 * ============================================
 */

#define CALLSERIALLY_QUEUE_SIZE 64

static struct {
    JavaObject* runnables[CALLSERIALLY_QUEUE_SIZE];
    int head;
    int tail;
    int count;
    bool gc_registered;
} g_call_serially_queue;

/* Queue a Runnable for later execution */
static bool call_serially_enqueue(JVM* jvm, JavaObject* runnable) {
    if (g_call_serially_queue.count >= CALLSERIALLY_QUEUE_SIZE) {
        fprintf(stderr, "[CallSerially] Queue full, cannot enqueue\n");
        return false;
    }
    
    g_call_serially_queue.runnables[g_call_serially_queue.tail] = runnable;
    g_call_serially_queue.tail = (g_call_serially_queue.tail + 1) % CALLSERIALLY_QUEUE_SIZE;
    g_call_serially_queue.count++;
    
    /* Register all queue slots as GC roots (only once) */
    if (!g_call_serially_queue.gc_registered) {
        for (int i = 0; i < CALLSERIALLY_QUEUE_SIZE; i++) {
            gc_add_root(jvm, (void**)&g_call_serially_queue.runnables[i]);
        }
        g_call_serially_queue.gc_registered = true;
    }
    
    return true;
}

/* Dequeue and execute all pending Runnables - called from event loop */
void midp_process_call_serially_queue(JVM* jvm) {
    JavaThread* thread = jvm_current_thread(jvm);
    
    while (g_call_serially_queue.count > 0) {
        JavaObject* runnable = g_call_serially_queue.runnables[g_call_serially_queue.head];
        g_call_serially_queue.runnables[g_call_serially_queue.head] = NULL;  /* Clear slot for GC */
        g_call_serially_queue.head = (g_call_serially_queue.head + 1) % CALLSERIALLY_QUEUE_SIZE;
        g_call_serially_queue.count--;
        
        if (runnable && runnable->header.clazz) {
            JavaClass* runnable_class = runnable->header.clazz;
            JavaMethod* run_method = jvm_resolve_method(jvm, runnable_class, "run", "()V");
            
            if (run_method) {
                JavaValue run_args[1];
                run_args[0].ref = runnable;
                JavaValue result;
                execute_method(jvm, thread, run_method, run_args, &result);
            }
        }
    }
}

/* Display.callSerially(Runnable) - queue Runnable for later execution */
static JavaValue native_display_callSerially(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* display = (JavaObject*)args[0].ref;
    JavaObject* runnable = (JavaObject*)args[1].ref;
    (void)display;
    
    if (!runnable) {
        fprintf(stderr, "[Display] callSerially: Runnable is NULL\n");
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Display] callSerially: queueing Runnable %p for deferred execution\n", (void*)runnable);
    
    /* Queue the Runnable instead of executing immediately */
    if (!call_serially_enqueue(jvm, runnable)) {
        fprintf(stderr, "[Display] callSerially: failed to queue Runnable\n");
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_display_getWidth(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    int width, height;
    midp_display_get_dimensions(&width, &height);
    return NATIVE_RETURN_INT(width);
}

/* Canvas.getGameAction(int keyCode) - convert key code to game action */
static JavaValue native_canvas_getGameAction(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* args[0] = this (Canvas object), args[1] = keyCode (first method argument) */
    jint keyCode = args[1].i;
    
    /* Game keys are sent as negative values (-game_action) */
    /* So getGameAction(-X) should return X */
    if (keyCode < 0) {
        int gameAction = -keyCode;
        /* Validate it's a valid game action (1-12) */
        if (gameAction >= 1 && gameAction <= 12) {
            fprintf(stderr, "[Canvas] getGameAction(%d) -> %d\n", keyCode, gameAction);
            return NATIVE_RETURN_INT(gameAction);
        }
    }
    
    /* No game action for this key */
    fprintf(stderr, "[Canvas] getGameAction(%d) -> 0 (no action)\n", keyCode);
    return NATIVE_RETURN_INT(0);
}

/* Canvas.getKeyCode(int gameAction) - convert game action to key code */
static JavaValue native_canvas_getKeyCode(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* args[0] = this (Canvas object), args[1] = gameAction */
    jint gameAction = args[1].i;
    
    /* J2ME Game Action constants:
     * UP = 1, LEFT = 2, RIGHT = 5, DOWN = 6, FIRE = 8
     * GAME_A = 9, GAME_B = 10, GAME_C = 11, GAME_D = 12
     * 
     * We return negative values to distinguish from regular key codes
     * (same convention as in getGameAction)
     */
    switch (gameAction) {
        case 1:  /* UP */
            DISP_DEBUG("getKeyCode(UP) -> %d", -gameAction);
            return NATIVE_RETURN_INT(-gameAction);
        case 2:  /* LEFT */
            DISP_DEBUG("getKeyCode(LEFT) -> %d", -gameAction);
            return NATIVE_RETURN_INT(-gameAction);
        case 5:  /* RIGHT */
            DISP_DEBUG("getKeyCode(RIGHT) -> %d", -gameAction);
            return NATIVE_RETURN_INT(-gameAction);
        case 6:  /* DOWN */
            DISP_DEBUG("getKeyCode(DOWN) -> %d", -gameAction);
            return NATIVE_RETURN_INT(-gameAction);
        case 8:  /* FIRE */
            DISP_DEBUG("getKeyCode(FIRE) -> %d", -gameAction);
            return NATIVE_RETURN_INT(-gameAction);
        case 9:  /* GAME_A */
        case 10: /* GAME_B */
        case 11: /* GAME_C */
        case 12: /* GAME_D */
            DISP_DEBUG("getKeyCode(GAME_%c) -> %d", 'A' + (gameAction - 9), -gameAction);
            return NATIVE_RETURN_INT(-gameAction);
        default:
            DISP_DEBUG("getKeyCode(%d) -> 0 (invalid game action)", gameAction);
            return NATIVE_RETURN_INT(0);
    }
}

/* Canvas.getKeyName(int keyCode) - get name for a key */
static JavaValue native_canvas_getKeyName(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    /* args[0] = this (Canvas object), args[1] = keyCode */
    jint keyCode = args[1].i;
    
    const char* keyName = NULL;
    
    /* Handle game actions (negative values) */
    if (keyCode < 0) {
        switch (-keyCode) {
            case 1:  keyName = "UP"; break;
            case 2:  keyName = "LEFT"; break;
            case 5:  keyName = "RIGHT"; break;
            case 6:  keyName = "DOWN"; break;
            case 8:  keyName = "FIRE"; break;
            case 9:  keyName = "GAME_A"; break;
            case 10: keyName = "GAME_B"; break;
            case 11: keyName = "GAME_C"; break;
            case 12: keyName = "GAME_D"; break;
            default: keyName = "Unknown"; break;
        }
    }
    /* Handle standard ITU-T keys */
    else if (keyCode >= '0' && keyCode <= '9') {
        static char num_name[2] = {0, 0};
        num_name[0] = (char)keyCode;
        keyName = num_name;
    }
    else if (keyCode == '*') {
        keyName = "STAR";
    }
    else if (keyCode == '#') {
        keyName = "POUND";
    }
    /* Handle SDL key codes for arrow keys */
    else {
        switch (keyCode) {
            case 0x40000052: keyName = "UP"; break;    /* SDL_SCANCODE_UP */
            case 0x40000051: keyName = "DOWN"; break;  /* SDL_SCANCODE_DOWN */
            case 0x40000050: keyName = "LEFT"; break;  /* SDL_SCANCODE_LEFT */
            case 0x4000004F: keyName = "RIGHT"; break; /* SDL_SCANCODE_RIGHT */
            case 0x4000002C: keyName = "FIRE"; break;  /* SDL_SCANCODE_SPACE (space = fire) */
            case 0x40000029: keyName = "FIRE"; break;  /* SDL_SCANCODE_RETURN */
            default: keyName = "Unknown"; break;
        }
    }
    
    DISP_DEBUG("getKeyName(%d) -> \"%s\"", keyCode, keyName);
    
    /* Create Java string */
    JavaString* str = jvm_new_string(jvm, (char*)keyName);
    if (!str) {
        ERROR_LOG("getKeyName: failed to create string");
        str = jvm_new_string(jvm, "Unknown");
        if (!str) {
            /* Fallback - should never happen, but return null */
            return NATIVE_RETURN_NULL();
        }
    }
    
    return NATIVE_RETURN_OBJECT(str);
}

/* Canvas.hasPointerEvents() - check if device supports pointer events */
static JavaValue native_canvas_hasPointerEvents(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Desktop emulators always support pointer events (mouse) */
    return NATIVE_RETURN_INT(1);  /* true */
}

/* Canvas.hasPointerMotionEvents() - check if device supports pointer drag */
static JavaValue native_canvas_hasPointerMotionEvents(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Desktop emulators always support pointer motion events (mouse drag) */
    return NATIVE_RETURN_INT(1);  /* true */
}

/* Canvas.hasRepeatEvents() - check if device supports key repeat */
static JavaValue native_canvas_hasRepeatEvents(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Desktop emulators support key repeat events */
    return NATIVE_RETURN_INT(1);  /* true */
}

/* Canvas.isDoubleBuffered() - check if Canvas is double buffered */
static JavaValue native_canvas_isDoubleBuffered(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* Our implementation is always double buffered via SDL */
    return NATIVE_RETURN_INT(1);  /* true */
}

static JavaValue native_display_getHeight(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    int width, height;
    midp_display_get_dimensions(&width, &height);
    return NATIVE_RETURN_INT(height);
}

static JavaValue native_display_isColor(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(midp_display_is_color() ? 1 : 0);
}

static JavaValue native_display_numColors(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(midp_display_num_colors());
}

static JavaValue native_display_numAlphaLevels(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(midp_display_num_alpha_levels());
}

static JavaValue native_display_vibrate(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint duration = args[0].i;
    
    if (platform_callbacks.vibrate) {
        platform_callbacks.vibrate(duration);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_display_flashBacklight(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint duration = args[0].i;
    
    if (platform_callbacks.flash_backlight) {
        platform_callbacks.flash_backlight(duration);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Canvas.repaint() - schedule a repaint by calling paint() immediately */
static JavaValue native_canvas_repaint(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* canvas = (JavaObject*)args[0].ref;
    
    if (!canvas) {
        return NATIVE_RETURN_VOID();
    }
    
    JavaClass* clazz = canvas->header.clazz;
    if (!clazz) {
        return NATIVE_RETURN_VOID();
    }
    
    /*fprintf(stderr, "[Canvas] repaint() called on %s\n", clazz->class_name);
    fflush(stderr);*/
    
    /* Create Graphics object bound to screen */
    JavaObject* gfx_obj = create_graphics_object(jvm);
    if (!gfx_obj) {
        fprintf(stderr, "[Canvas] repaint: failed to create Graphics\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Find and call paint(Graphics g) method */
    JavaMethod* paint_method = jvm_resolve_method(jvm, clazz, "paint", "(Ljavax/microedition/lcdui/Graphics;)V");
    if (paint_method) {
        JavaValue paint_args[2];
        paint_args[0].ref = canvas;    /* this */
        paint_args[1].ref = gfx_obj;   /* Graphics object */
        
        JavaValue result;
        execute_method(jvm, thread, paint_method, paint_args, &result);
        
        /* Present to screen */
        SdlContext* sdl_ctx = sdl_get_global_context();
        if (sdl_ctx) {
            sdl_present(sdl_ctx);
        }
    } else {
        fprintf(stderr, "[Canvas] repaint: paint() method not found in %s\n", clazz->class_name);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Canvas.repaint(int x, int y, int w, int h) - repaint a region */
static JavaValue native_canvas_repaint_region(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)arg_count;
    /* For simplicity, just do a full repaint */
    return native_canvas_repaint(jvm, thread, args, 1);
}

/* Canvas.serviceRepaints() - process any pending repaints */
static JavaValue native_canvas_serviceRepaints(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    /* No-op since we process repaints immediately */
    return NATIVE_RETURN_VOID();
}

/*
 * ============================================
 * Sprite native methods
 * ============================================
 */

/* Sprite.<init>(Image image) */
static JavaValue native_sprite_init_image(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* image_obj = (JavaObject*)args[1].ref;
    
    if (!this_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Sprite] init(Image): this=%p, image=%p\n", 
            (void*)this_obj, (void*)image_obj);
    
    /* Store image reference and set default dimensions */
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name) {
            if (strcmp(sprite_class->fields[i].name, "image") == 0) {
                this_obj->fields[i].ref = image_obj;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.<init>(Image image, int frameWidth, int frameHeight) */
static JavaValue native_sprite_init_frames(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* image_obj = (JavaObject*)args[1].ref;
    jint frame_width = args[2].i;
    jint frame_height = args[3].i;
    
    if (!this_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Sprite] init(Image, %d, %d): this=%p, image=%p\n", 
            frame_width, frame_height, (void*)this_obj, (void*)image_obj);
    
    /* Store image reference and frame dimensions */
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name) {
            if (strcmp(sprite_class->fields[i].name, "image") == 0) {
                this_obj->fields[i].ref = image_obj;
            } else if (strcmp(sprite_class->fields[i].name, "frameWidth") == 0) {
                this_obj->fields[i].i = frame_width;
            } else if (strcmp(sprite_class->fields[i].name, "frameHeight") == 0) {
                this_obj->fields[i].i = frame_height;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.<init>(Sprite sprite) - copy constructor */
static JavaValue native_sprite_init_copy(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* other_sprite = (JavaObject*)args[1].ref;
    
    if (!this_obj || !other_sprite) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Sprite] init(copy): this=%p, other=%p\n", 
            (void*)this_obj, (void*)other_sprite);
    
    /* Copy fields from other sprite */
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        this_obj->fields[i] = other_sprite->fields[i];
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.setPosition(int x, int y) */
static JavaValue native_sprite_setPosition(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name) {
            if (strcmp(sprite_class->fields[i].name, "x") == 0) {
                this_obj->fields[i].i = x;
            } else if (strcmp(sprite_class->fields[i].name, "y") == 0) {
                this_obj->fields[i].i = y;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.move(int dx, int dy) */
static JavaValue native_sprite_move(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint dx = args[1].i;
    jint dy = args[2].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name) {
            if (strcmp(sprite_class->fields[i].name, "x") == 0) {
                this_obj->fields[i].i += dx;
            } else if (strcmp(sprite_class->fields[i].name, "y") == 0) {
                this_obj->fields[i].i += dy;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Helper: Get field value from object by name */
static jint get_object_field_int(JavaObject* obj, const char* field_name) {
    if (!obj || !obj->header.clazz) return 0;
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, field_name) == 0) {
            return obj->fields[i].i;
        }
    }
    return 0;
}

/* Helper: Set field value in object by name */
static void set_object_field_int(JavaObject* obj, const char* field_name, jint value) {
    if (!obj || !obj->header.clazz) return;
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, field_name) == 0) {
            obj->fields[i].i = value;
            return;
        }
    }
}

/* Helper: Get object field reference by name */
static JavaObject* get_object_field_ref(JavaObject* obj, const char* field_name) {
    if (!obj || !obj->header.clazz) return NULL;
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, field_name) == 0) {
            return (JavaObject*)obj->fields[i].ref;
        }
    }
    return NULL;
}

/* Sprite.paint(Graphics g) */
static JavaValue native_sprite_paint(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* gfx_obj = (JavaObject*)args[1].ref;
    
    if (!this_obj || !gfx_obj) return NATIVE_RETURN_VOID();
    
    /* Get MidpGraphics from Java Graphics object */
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (!gfx) {
        fprintf(stderr, "[Sprite] paint: failed to get MidpGraphics\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Get sprite properties */
    jint x = get_object_field_int(this_obj, "x");
    jint y = get_object_field_int(this_obj, "y");
    jint width = get_object_field_int(this_obj, "width");
    jint height = get_object_field_int(this_obj, "height");
    jint frameWidth = get_object_field_int(this_obj, "frameWidth");
    jint frameHeight = get_object_field_int(this_obj, "frameHeight");
    jint currentFrame = get_object_field_int(this_obj, "currentFrame");
    jint visible = get_object_field_int(this_obj, "visible");
    jint transform = get_object_field_int(this_obj, "transform");
    jint refX = get_object_field_int(this_obj, "refX");
    jint refY = get_object_field_int(this_obj, "refY");
    
    /* Skip if not visible */
    if (!visible) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Get image from sprite */
    JavaObject* image_obj = get_object_field_ref(this_obj, "image");
    if (!image_obj) {
        fprintf(stderr, "[Sprite] paint: no image\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Get MidpImage from Image object */
    MidpImage* img = NULL;
    if (OBJECT_HAS_FIELDS(image_obj, 1)) {
        img = (MidpImage*)image_obj->fields[0].ref;
    }
    
    if (!img || !img->pixels) {
        fprintf(stderr, "[Sprite] paint: no image data\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Calculate frame offset if using frame animation */
    jint src_x = 0, src_y = 0;
    jint src_w = width > 0 ? width : img->width;
    jint src_h = height > 0 ? height : img->height;
    
    if (frameWidth > 0 && frameHeight > 0) {
        int frames_per_row = img->width / frameWidth;
        if (frames_per_row > 0) {
            src_x = (currentFrame % frames_per_row) * frameWidth;
            src_y = (currentFrame / frames_per_row) * frameHeight;
            src_w = frameWidth;
            src_h = frameHeight;
        }
    }
    
    /* Apply reference pixel offset */
    jint dest_x = x - refX;
    jint dest_y = y - refY;
    
    /* Apply transformation (simple flip/rotate) */
    /* Transform values: 0=NONE, 1=MIRROR_ROT90, 2=MIRROR_ROT180, etc. */
    /* For simplicity, implement basic rendering */
    
    /* Draw the sprite region to the graphics context */
    if (transform == 0) {
        /* No transformation - direct blit */
        midp_graphics_draw_region(gfx, img, src_x, src_y, src_w, src_h,
                                   0, dest_x, dest_y, 0);
    } else {
        /* Apply transform */
        midp_graphics_draw_region(gfx, img, src_x, src_y, src_w, src_h,
                                   transform, dest_x, dest_y, 0);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.getX() */
static JavaValue native_sprite_getX(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "x") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.getY() */
static JavaValue native_sprite_getY(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "y") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.getWidth() */
static JavaValue native_sprite_getWidth(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "width") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.getHeight() */
static JavaValue native_sprite_getHeight(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "height") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.setVisible(boolean visible) */
static JavaValue native_sprite_setVisible(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jboolean visible = args[1].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "visible") == 0) {
            this_obj->fields[i].i = visible;
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.isVisible() */
static JavaValue native_sprite_isVisible(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(1);  /* Default visible */
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "visible") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/* Sprite.setFrame(int frame) */
static JavaValue native_sprite_setFrame(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint frame = args[1].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "currentFrame") == 0) {
            this_obj->fields[i].i = frame;
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.getFrame() */
static JavaValue native_sprite_getFrame(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "currentFrame") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.setTransform(int transform) - rotate/mirror sprite */
static JavaValue native_sprite_setTransform(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint transform = args[1].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    /* Find and set transform field */
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "transform") == 0) {
            this_obj->fields[i].i = transform;
            return NATIVE_RETURN_VOID();
        }
    }
    
    /* If transform field doesn't exist, store it in unused field (frameWidth as temp) */
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "frameWidth") == 0) {
            /* Store transform in high bits to not interfere with width */
            jint width = this_obj->fields[i].i & 0xFFFF;
            this_obj->fields[i].i = width | (transform << 16);
            return NATIVE_RETURN_VOID();
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.getTransform() */
static JavaValue native_sprite_getTransform(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "transform") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    /* Check frameWidth for stored transform */
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "frameWidth") == 0) {
            return NATIVE_RETURN_INT((this_obj->fields[i].i >> 16) & 0xFFFF);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Forward declaration for get_image_from_object (defined later in file) */
static MidpImage* get_image_from_object(JavaObject* obj);

/* Helper to get Sprite image */
static MidpImage* get_sprite_image(JavaObject* sprite_obj) {
    if (!sprite_obj) return NULL;
    
    JavaClass* sprite_class = sprite_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "image") == 0) {
            JavaObject* image_obj = (JavaObject*)sprite_obj->fields[i].ref;
            if (image_obj) {
                return get_image_from_object(image_obj);
            }
        }
    }
    return NULL;
}

/* Sprite.collidesWith(Sprite s, boolean pixelLevel) */
static JavaValue native_sprite_collidesWith_sprite(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* other_sprite = (JavaObject*)args[1].ref;
    jboolean pixel_level = args[2].i;
    
    if (!this_obj || !other_sprite) {
        return NATIVE_RETURN_INT(0); /* false */
    }
    
    /* Get bounds of this sprite */
    int this_x = 0, this_y = 0, this_w = 0, this_h = 0;
    int other_x = 0, other_y = 0, other_w = 0, other_h = 0;
    
    JavaClass* this_class = this_obj->header.clazz;
    for (int i = 0; i < this_class->fields_count; i++) {
        if (this_class->fields[i].name) {
            if (strcmp(this_class->fields[i].name, "x") == 0) this_x = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "y") == 0) this_y = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "width") == 0) this_w = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "height") == 0) this_h = this_obj->fields[i].i;
        }
    }
    
    JavaClass* other_class = other_sprite->header.clazz;
    for (int i = 0; i < other_class->fields_count; i++) {
        if (other_class->fields[i].name) {
            if (strcmp(other_class->fields[i].name, "x") == 0) other_x = other_sprite->fields[i].i;
            else if (strcmp(other_class->fields[i].name, "y") == 0) other_y = other_sprite->fields[i].i;
            else if (strcmp(other_class->fields[i].name, "width") == 0) other_w = other_sprite->fields[i].i;
            else if (strcmp(other_class->fields[i].name, "height") == 0) other_h = other_sprite->fields[i].i;
        }
    }
    
    /* Rectangle intersection test */
    int intersect_x1 = this_x > other_x ? this_x : other_x;
    int intersect_y1 = this_y > other_y ? this_y : other_y;
    int intersect_x2 = (this_x + this_w) < (other_x + other_w) ? (this_x + this_w) : (other_x + other_w);
    int intersect_y2 = (this_y + this_h) < (other_y + other_h) ? (this_y + this_h) : (other_y + other_h);
    
    /* No intersection */
    if (intersect_x1 >= intersect_x2 || intersect_y1 >= intersect_y2) {
        return NATIVE_RETURN_INT(0); /* false */
    }
    
    /* If not pixel-level, bounding box collision is enough */
    if (!pixel_level) {
        return NATIVE_RETURN_INT(1); /* true */
    }
    
    /* Pixel-level collision detection */
    MidpImage* this_img = get_sprite_image(this_obj);
    MidpImage* other_img = get_sprite_image(other_sprite);
    
    if (!this_img || !other_img) {
        return NATIVE_RETURN_INT(0); /* false - no images */
    }
    
    /* Check each pixel in intersection region */
    for (int y = intersect_y1; y < intersect_y2; y++) {
        for (int x = intersect_x1; x < intersect_x2; x++) {
            /* Get pixel from this sprite */
            int this_px = x - this_x;
            int this_py = y - this_y;
            int this_idx = this_py * this_img->width + this_px;
            
            /* Get pixel from other sprite */
            int other_px = x - other_x;
            int other_py = y - other_y;
            int other_idx = other_py * other_img->width + other_px;
            
            /* Check bounds */
            if (this_px < 0 || this_px >= this_img->width || this_py < 0 || this_py >= this_img->height) continue;
            if (other_px < 0 || other_px >= other_img->width || other_py < 0 || other_py >= other_img->height) continue;
            
            /* Check if both pixels are non-transparent */
            uint32_t this_pixel = this_img->pixels[this_idx];
            uint32_t other_pixel = other_img->pixels[other_idx];
            
            uint8_t this_alpha = (this_pixel >> 24) & 0xFF;
            uint8_t other_alpha = (other_pixel >> 24) & 0xFF;
            
            if (this_alpha > 0 && other_alpha > 0) {
                return NATIVE_RETURN_INT(1); /* true - collision found */
            }
        }
    }
    
    return NATIVE_RETURN_INT(0); /* false */
}

/* Sprite.collidesWith(TiledLayer t, boolean pixelLevel) */
static JavaValue native_sprite_collidesWith_tiledlayer(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* tiledlayer = (JavaObject*)args[1].ref;
    jboolean pixel_level = args[2].i;
    
    if (!this_obj || !tiledlayer) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Get sprite bounds */
    int this_x = 0, this_y = 0, this_w = 0, this_h = 0;
    JavaClass* this_class = this_obj->header.clazz;
    for (int i = 0; i < this_class->fields_count; i++) {
        if (this_class->fields[i].name) {
            if (strcmp(this_class->fields[i].name, "x") == 0) this_x = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "y") == 0) this_y = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "width") == 0) this_w = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "height") == 0) this_h = this_obj->fields[i].i;
        }
    }
    
    /* Get tiled layer bounds */
    int tl_x = 0, tl_y = 0, tl_w = 0, tl_h = 0;
    JavaClass* tl_class = tiledlayer->header.clazz;
    for (int i = 0; i < tl_class->fields_count; i++) {
        if (tl_class->fields[i].name) {
            if (strcmp(tl_class->fields[i].name, "x") == 0) tl_x = tiledlayer->fields[i].i;
            else if (strcmp(tl_class->fields[i].name, "y") == 0) tl_y = tiledlayer->fields[i].i;
            else if (strcmp(tl_class->fields[i].name, "width") == 0) tl_w = tiledlayer->fields[i].i;
            else if (strcmp(tl_class->fields[i].name, "height") == 0) tl_h = tiledlayer->fields[i].i;
        }
    }
    
    /* Rectangle intersection test */
    int intersect_x1 = this_x > tl_x ? this_x : tl_x;
    int intersect_y1 = this_y > tl_y ? this_y : tl_y;
    int intersect_x2 = (this_x + this_w) < (tl_x + tl_w) ? (this_x + this_w) : (tl_x + tl_w);
    int intersect_y2 = (this_y + this_h) < (tl_y + tl_h) ? (this_y + this_h) : (tl_y + tl_h);
    
    if (intersect_x1 < intersect_x2 && intersect_y1 < intersect_y2) {
        return NATIVE_RETURN_INT(1);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.collidesWith(Image image, int x, int y, boolean pixelLevel) */
static JavaValue native_sprite_collidesWith_image(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* image_obj = (JavaObject*)args[1].ref;
    jint img_x = args[2].i;
    jint img_y = args[3].i;
    jboolean pixel_level = args[4].i;
    
    if (!this_obj || !image_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Get sprite bounds */
    int this_x = 0, this_y = 0, this_w = 0, this_h = 0;
    JavaClass* this_class = this_obj->header.clazz;
    for (int i = 0; i < this_class->fields_count; i++) {
        if (this_class->fields[i].name) {
            if (strcmp(this_class->fields[i].name, "x") == 0) this_x = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "y") == 0) this_y = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "width") == 0) this_w = this_obj->fields[i].i;
            else if (strcmp(this_class->fields[i].name, "height") == 0) this_h = this_obj->fields[i].i;
        }
    }
    
    /* Get image dimensions */
    MidpImage* img = get_image_from_object(image_obj);
    if (!img) return NATIVE_RETURN_INT(0);
    
    /* Rectangle intersection test */
    int intersect_x1 = this_x > img_x ? this_x : img_x;
    int intersect_y1 = this_y > img_y ? this_y : img_y;
    int intersect_x2 = (this_x + this_w) < (img_x + img->width) ? (this_x + this_w) : (img_x + img->width);
    int intersect_y2 = (this_y + this_h) < (img_y + img->height) ? (this_y + this_h) : (img_y + img->height);
    
    if (intersect_x1 < intersect_x2 && intersect_y1 < intersect_y2) {
        return NATIVE_RETURN_INT(1);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Sprite.defineCollisionRectangle(int x, int y, int width, int height) */
static JavaValue native_sprite_defineCollisionRectangle(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint width = args[3].i;
    jint height = args[4].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    /* Store collision rectangle - could use extra fields if available */
    /* For now, we use the full sprite bounds for collision */
    /* In future: store collision rect offset/dimensions in sprite fields */
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.setFrameSequence(int[] sequence) */
static JavaValue native_sprite_setFrameSequence(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaArray* sequence = (JavaArray*)args[1].ref;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    /* Store frame sequence reference */
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "frameSequence") == 0) {
            this_obj->fields[i].ref = sequence;
            return NATIVE_RETURN_VOID();
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.nextFrame() */
static JavaValue native_sprite_nextFrame(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* sprite_class = this_obj->header.clazz;
    int current_frame = 0;
    int frame_idx = -1;
    int sequence_idx = -1;
    int raw_frame_count_idx = -1;
    
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name) {
            if (strcmp(sprite_class->fields[i].name, "currentFrame") == 0) {
                current_frame = this_obj->fields[i].i;
                frame_idx = i;
            } else if (strcmp(sprite_class->fields[i].name, "frameSequence") == 0) {
                sequence_idx = i;
            } else if (strcmp(sprite_class->fields[i].name, "rawFrameCount") == 0) {
                raw_frame_count_idx = i;
            }
        }
    }
    
    if (frame_idx >= 0) {
        int max_frames = raw_frame_count_idx >= 0 ? this_obj->fields[raw_frame_count_idx].i : 1;
        int new_frame = current_frame + 1;
        if (new_frame >= max_frames) new_frame = 0;
        this_obj->fields[frame_idx].i = new_frame;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.prevFrame() */
static JavaValue native_sprite_prevFrame(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* sprite_class = this_obj->header.clazz;
    int current_frame = 0;
    int frame_idx = -1;
    int raw_frame_count_idx = -1;
    
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name) {
            if (strcmp(sprite_class->fields[i].name, "currentFrame") == 0) {
                current_frame = this_obj->fields[i].i;
                frame_idx = i;
            } else if (strcmp(sprite_class->fields[i].name, "rawFrameCount") == 0) {
                raw_frame_count_idx = i;
            }
        }
    }
    
    if (frame_idx >= 0) {
        int max_frames = raw_frame_count_idx >= 0 ? this_obj->fields[raw_frame_count_idx].i : 1;
        int new_frame = current_frame - 1;
        if (new_frame < 0) new_frame = max_frames - 1;
        this_obj->fields[frame_idx].i = new_frame;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Sprite.getRawFrameCount() */
static JavaValue native_sprite_getRawFrameCount(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* sprite_class = this_obj->header.clazz;
    for (int i = 0; i < sprite_class->fields_count; i++) {
        if (sprite_class->fields[i].name && strcmp(sprite_class->fields[i].name, "rawFrameCount") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/*
 * ============================================
 * Layer native methods (abstract base class)
 * ============================================
 */

/* Layer.getX() */
static JavaValue native_layer_getX(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name && strcmp(layer_class->fields[i].name, "x") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Layer.getY() */
static JavaValue native_layer_getY(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name && strcmp(layer_class->fields[i].name, "y") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Layer.getWidth() */
static JavaValue native_layer_getWidth(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name && strcmp(layer_class->fields[i].name, "width") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Layer.getHeight() */
static JavaValue native_layer_getHeight(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name && strcmp(layer_class->fields[i].name, "height") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Layer.setPosition(int x, int y) */
static JavaValue native_layer_setPosition(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name) {
            if (strcmp(layer_class->fields[i].name, "x") == 0) {
                this_obj->fields[i].i = x;
            } else if (strcmp(layer_class->fields[i].name, "y") == 0) {
                this_obj->fields[i].i = y;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Layer.move(int dx, int dy) */
static JavaValue native_layer_move(JVM* jvm, JavaThread* thread,
                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint dx = args[1].i;
    jint dy = args[2].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name) {
            if (strcmp(layer_class->fields[i].name, "x") == 0) {
                this_obj->fields[i].i += dx;
            } else if (strcmp(layer_class->fields[i].name, "y") == 0) {
                this_obj->fields[i].i += dy;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Layer.setVisible(boolean visible) */
static JavaValue native_layer_setVisible(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jboolean visible = args[1].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name && strcmp(layer_class->fields[i].name, "visible") == 0) {
            this_obj->fields[i].i = visible;
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Layer.isVisible() */
static JavaValue native_layer_isVisible(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(1);
    
    JavaClass* layer_class = this_obj->header.clazz;
    for (int i = 0; i < layer_class->fields_count; i++) {
        if (layer_class->fields[i].name && strcmp(layer_class->fields[i].name, "visible") == 0) {
            return NATIVE_RETURN_INT(this_obj->fields[i].i);
        }
    }
    
    return NATIVE_RETURN_INT(1);
}

/*
 * ============================================
 * LayerManager native methods
 * ============================================
 */

/* LayerManager.<init>() */
static JavaValue native_layermanager_init(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[LayerManager] init: this=%p\n", (void*)this_obj);
    
    return NATIVE_RETURN_VOID();
}

/* LayerManager.append(Layer layer) */
static JavaValue native_layermanager_append(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* layer = (JavaObject*)args[1].ref;
    
    fprintf(stderr, "[LayerManager] append: layer=%p\n", (void*)layer);
    
    return NATIVE_RETURN_INT(0);  /* Return layer index */
}

/* LayerManager.insert(Layer layer, int index) */
static JavaValue native_layermanager_insert(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* layer = (JavaObject*)args[1].ref;
    jint index = args[2].i;
    
    fprintf(stderr, "[LayerManager] insert: layer=%p at %d\n", (void*)layer, index);
    
    return NATIVE_RETURN_VOID();
}

/* LayerManager.remove(Layer layer) */
static JavaValue native_layermanager_remove(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* layer = (JavaObject*)args[1].ref;
    
    fprintf(stderr, "[LayerManager] remove: layer=%p\n", (void*)layer);
    
    return NATIVE_RETURN_VOID();
}

/* LayerManager.getLayerAt(int index) */
static JavaValue native_layermanager_getLayerAt(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    fprintf(stderr, "[LayerManager] getLayerAt: %d\n", index);
    
    return NATIVE_RETURN_NULL();
}

/* LayerManager.getSize() */
static JavaValue native_layermanager_getSize(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    /* LayerManager has a layers[] array field */
    JavaArray* layers = (JavaArray*)get_object_field_ref(this_obj, "layers");
    if (layers) {
        return NATIVE_RETURN_INT(layers->length);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Helper: Paint a single layer (Sprite or TiledLayer) */
static void paint_layer(JVM* jvm, JavaObject* layer, JavaObject* gfx_obj, int x, int y) {
    if (!layer || !gfx_obj) return;
    
    JavaClass* clazz = layer->header.clazz;
    if (!clazz || !clazz->class_name) return;
    
    /* Find the paint method on the layer */
    JavaMethod* paint_method = jvm_resolve_method(jvm, clazz, "paint", "(Ljavax/microedition/lcdui/Graphics;)V");
    if (paint_method) {
        JavaValue paint_args[2];
        paint_args[0].ref = layer;
        paint_args[1].ref = gfx_obj;
        
        JavaValue result;
        JavaThread* th = jvm_current_thread(jvm);
        execute_method(jvm, th, paint_method, paint_args, &result);
    }
}

/* LayerManager.paint(Graphics g, int x, int y) */
static JavaValue native_layermanager_paint(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* gfx_obj = (JavaObject*)args[1].ref;
    jint x = args[2].i;
    jint y = args[3].i;
    
    if (!this_obj || !gfx_obj) return NATIVE_RETURN_VOID();
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (!gfx) {
        fprintf(stderr, "[LayerManager] paint: failed to get MidpGraphics\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Get view window parameters */
    jint viewX = get_object_field_int(this_obj, "viewX");
    jint viewY = get_object_field_int(this_obj, "viewY");
    jint viewWidth = get_object_field_int(this_obj, "viewWidth");
    jint viewHeight = get_object_field_int(this_obj, "viewHeight");
    
    /* Default view window to screen size if not set */
    if (viewWidth <= 0) viewWidth = gfx->width;
    if (viewHeight <= 0) viewHeight = gfx->height;
    
    /* Get layers array */
    JavaArray* layers = (JavaArray*)get_object_field_ref(this_obj, "layers");
    if (!layers || layers->element_type != DESC_OBJECT) {
        return NATIVE_RETURN_VOID();
    }
    
    void** layer_data = (void**)array_data(layers);
    int layer_count = layers->length;
    
    /* Apply translation for the paint offset */
    int old_tx = gfx->translate_x;
    int old_ty = gfx->translate_y;
    gfx->translate_x += x - viewX;
    gfx->translate_y += y - viewY;
    
    /* Clip to view window */
    int old_clip_x = gfx->clip_x;
    int old_clip_y = gfx->clip_y;
    int old_clip_w = gfx->clip_width;
    int old_clip_h = gfx->clip_height;
    
    midp_graphics_clip_rect(gfx, x, y, viewWidth, viewHeight);
    
    /* Paint each layer from bottom (index 0) to top */
    for (int i = 0; i < layer_count; i++) {
        JavaObject* layer = (JavaObject*)layer_data[i];
        if (layer) {
            /* Check if layer is visible */
            jint visible = get_object_field_int(layer, "visible");
            if (visible) {
                paint_layer(jvm, layer, gfx_obj, x, y);
            }
        }
    }
    
    /* Restore graphics state */
    gfx->translate_x = old_tx;
    gfx->translate_y = old_ty;
    gfx->clip_x = old_clip_x;
    gfx->clip_y = old_clip_y;
    gfx->clip_width = old_clip_w;
    gfx->clip_height = old_clip_h;
    
    return NATIVE_RETURN_VOID();
}

/* LayerManager.setViewWindow(int x, int y, int width, int height) */
static JavaValue native_layermanager_setViewWindow(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint width = args[3].i;
    jint height = args[4].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    /* Store view window in LayerManager fields */
    set_object_field_int(this_obj, "viewX", x);
    set_object_field_int(this_obj, "viewY", y);
    set_object_field_int(this_obj, "viewWidth", width);
    set_object_field_int(this_obj, "viewHeight", height);
    
    return NATIVE_RETURN_VOID();
}

/*
 * ============================================
 * TiledLayer native methods
 * ============================================
 */

/* TiledLayer.<init>(int columns, int rows, Image image, int tileWidth, int tileHeight) */
static JavaValue native_tiledlayer_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint columns = args[1].i;
    jint rows = args[2].i;
    JavaObject* image = (JavaObject*)args[3].ref;
    jint tile_width = args[4].i;
    jint tile_height = args[5].i;
    
    if (!this_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Store properties in TiledLayer fields */
    set_object_field_int(this_obj, "columns", columns);
    set_object_field_int(this_obj, "rows", rows);
    set_object_field_int(this_obj, "tileWidth", tile_width);
    set_object_field_int(this_obj, "tileHeight", tile_height);
    
    /* Store image reference */
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "image") == 0) {
            this_obj->fields[i].ref = image;
            break;
        }
    }
    
    /* Create cell map array */
    JavaArray* cell_map = jvm_new_array(jvm, T_INT, columns * rows);
    if (cell_map) {
        /* Initialize all cells to 0 (no tile) */
        jint* cells = (jint*)array_data(cell_map);
        for (int i = 0; i < columns * rows; i++) {
            cells[i] = 0;
        }
        /* Store in field */
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "cellMap") == 0) {
                this_obj->fields[i].ref = cell_map;
                break;
            }
        }
    }
    
    fprintf(stderr, "[TiledLayer] init: %dx%d tiles, image=%p, tile=%dx%d\n", 
            columns, rows, (void*)image, tile_width, tile_height);
    
    return NATIVE_RETURN_VOID();
}

/* TiledLayer.setCell(int col, int row, int tileIndex) */
static JavaValue native_tiledlayer_setCell(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint col = args[1].i;
    jint row = args[2].i;
    jint tile_index = args[3].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    jint columns = get_object_field_int(this_obj, "columns");
    jint rows = get_object_field_int(this_obj, "rows");
    
    if (col < 0 || col >= columns || row < 0 || row >= rows) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Get cell map array */
    JavaArray* cell_map = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "cellMap") == 0) {
            cell_map = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    if (cell_map && cell_map->element_type == T_INT) {
        jint* cells = (jint*)array_data(cell_map);
        cells[row * columns + col] = tile_index;
    }
    
    return NATIVE_RETURN_VOID();
}

/* TiledLayer.getCell(int col, int row) */
static JavaValue native_tiledlayer_getCell(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint col = args[1].i;
    jint row = args[2].i;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    jint columns = get_object_field_int(this_obj, "columns");
    jint rows = get_object_field_int(this_obj, "rows");
    
    if (col < 0 || col >= columns || row < 0 || row >= rows) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Get cell map array */
    JavaArray* cell_map = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "cellMap") == 0) {
            cell_map = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    if (cell_map && cell_map->element_type == T_INT) {
        jint* cells = (jint*)array_data(cell_map);
        return NATIVE_RETURN_INT(cells[row * columns + col]);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* TiledLayer.fillCells(int col, int row, int numCols, int numRows, int tileIndex) */
static JavaValue native_tiledlayer_fillCells(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint col = args[1].i;
    jint row = args[2].i;
    jint num_cols = args[3].i;
    jint num_rows = args[4].i;
    jint tile_index = args[5].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    jint columns = get_object_field_int(this_obj, "columns");
    jint rows = get_object_field_int(this_obj, "rows");
    
    /* Validate bounds */
    if (col < 0 || row < 0 || num_cols < 0 || num_rows < 0) {
        return NATIVE_RETURN_VOID();
    }
    if (col + num_cols > columns || row + num_rows > rows) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Get cell map array */
    JavaArray* cell_map = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "cellMap") == 0) {
            cell_map = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    if (cell_map && cell_map->element_type == T_INT) {
        jint* cells = (jint*)array_data(cell_map);
        /* Fill the rectangular region */
        for (int r = row; r < row + num_rows; r++) {
            for (int c = col; c < col + num_cols; c++) {
                cells[r * columns + c] = tile_index;
            }
        }
    }
    
    fprintf(stderr, "[TiledLayer] fillCells: (%d,%d) %dx%d = tile %d\n",
            col, row, num_cols, num_rows, tile_index);
    
    return NATIVE_RETURN_VOID();
}

/* TiledLayer.createAnimatedTile(int staticTileIndex) */
static JavaValue native_tiledlayer_createAnimatedTile(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint static_tile_index = args[1].i;
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    /* Get or create animated tiles array */
    JavaArray* anim_tiles = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "animatedTiles") == 0) {
            anim_tiles = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    /* Create array if not exists (initial capacity: 10) */
    if (!anim_tiles) {
        anim_tiles = jvm_new_array(jvm, T_INT, 10);
        if (!anim_tiles) return NATIVE_RETURN_INT(0);
        
        /* Store in field */
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "animatedTiles") == 0) {
                this_obj->fields[i].ref = anim_tiles;
                break;
            }
        }
    }
    
    /* Get current count */
    jint anim_count = get_object_field_int(this_obj, "animatedTileCount");
    
    /* Check if we need to grow the array */
    if (anim_count >= (jint)anim_tiles->length) {
        /* Create larger array */
        int new_size = anim_tiles->length * 2;
        JavaArray* new_array = jvm_new_array(jvm, T_INT, new_size);
        if (!new_array) return NATIVE_RETURN_INT(0);
        
        /* Copy old data */
        jint* old_data = (jint*)array_data(anim_tiles);
        jint* new_data = (jint*)array_data(new_array);
        for (int i = 0; i < anim_count; i++) {
            new_data[i] = old_data[i];
        }
        
        /* Replace array */
        for (int i = 0; i < clazz->fields_count; i++) {
            if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "animatedTiles") == 0) {
                this_obj->fields[i].ref = new_array;
                break;
            }
        }
        anim_tiles = new_array;
    }
    
    /* Store static tile index */
    jint* anim_data = (jint*)array_data(anim_tiles);
    anim_data[anim_count] = static_tile_index;
    
    /* Update count */
    anim_count++;
    set_object_field_int(this_obj, "animatedTileCount", anim_count);
    
    /* Return negative animated tile index (-1 for first, -2 for second, etc.) */
    /* Animated tile index is 1-based, so first animated tile is -1 */
    jint result = -anim_count;
    
    fprintf(stderr, "[TiledLayer] createAnimatedTile: static=%d -> animated=%d\n",
            static_tile_index, result);
    
    return NATIVE_RETURN_INT(result);
}

/* TiledLayer.setAnimatedTile(int animatedTileIndex, int staticTileIndex) */
static JavaValue native_tiledlayer_setAnimatedTile(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint anim_tile_index = args[1].i;  /* Negative value */
    jint static_tile_index = args[2].i;
    
    if (!this_obj) return NATIVE_RETURN_VOID();
    
    /* Convert negative index to 0-based array index */
    /* -1 -> 0, -2 -> 1, etc. */
    if (anim_tile_index >= 0) return NATIVE_RETURN_VOID();  /* Invalid index */
    
    int array_index = -anim_tile_index - 1;
    
    /* Get animated tiles array */
    JavaArray* anim_tiles = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "animatedTiles") == 0) {
            anim_tiles = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    if (!anim_tiles || array_index >= (int)anim_tiles->length) {
        return NATIVE_RETURN_VOID();
    }
    
    jint* anim_data = (jint*)array_data(anim_tiles);
    anim_data[array_index] = static_tile_index;
    
    fprintf(stderr, "[TiledLayer] setAnimatedTile: anim=%d -> static=%d\n",
            anim_tile_index, static_tile_index);
    
    return NATIVE_RETURN_VOID();
}

/* TiledLayer.getAnimatedTile(int animatedTileIndex) */
static JavaValue native_tiledlayer_getAnimatedTile(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    jint anim_tile_index = args[1].i;  /* Negative value */
    
    if (!this_obj) return NATIVE_RETURN_INT(0);
    
    /* Convert negative index to 0-based array index */
    if (anim_tile_index >= 0) return NATIVE_RETURN_INT(0);  /* Invalid index */
    
    int array_index = -anim_tile_index - 1;
    
    /* Get animated tiles array */
    JavaArray* anim_tiles = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "animatedTiles") == 0) {
            anim_tiles = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    if (!anim_tiles || array_index >= (int)anim_tiles->length) {
        return NATIVE_RETURN_INT(0);
    }
    
    jint* anim_data = (jint*)array_data(anim_tiles);
    return NATIVE_RETURN_INT(anim_data[array_index]);
}

/* TiledLayer.paint(Graphics g) */
static JavaValue native_tiledlayer_paint(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* gfx_obj = (JavaObject*)args[1].ref;
    
    if (!this_obj || !gfx_obj) return NATIVE_RETURN_VOID();
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (!gfx) {
        fprintf(stderr, "[TiledLayer] paint: failed to get MidpGraphics\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Get TiledLayer properties */
    jint x = get_object_field_int(this_obj, "x");
    jint y = get_object_field_int(this_obj, "y");
    jint columns = get_object_field_int(this_obj, "columns");
    jint rows = get_object_field_int(this_obj, "rows");
    jint tile_width = get_object_field_int(this_obj, "tileWidth");
    jint tile_height = get_object_field_int(this_obj, "tileHeight");
    
    if (columns <= 0 || rows <= 0 || tile_width <= 0 || tile_height <= 0) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Get image */
    JavaObject* image_obj = get_object_field_ref(this_obj, "image");
    if (!image_obj) return NATIVE_RETURN_VOID();
    
    MidpImage* img = NULL;
    if (OBJECT_HAS_FIELDS(image_obj, 1)) {
        img = (MidpImage*)image_obj->fields[0].ref;
    }
    if (!img || !img->pixels) return NATIVE_RETURN_VOID();
    
    /* Get cell map */
    JavaArray* cell_map = NULL;
    JavaClass* clazz = this_obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "cellMap") == 0) {
            cell_map = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    
    if (!cell_map || cell_map->element_type != T_INT) {
        return NATIVE_RETURN_VOID();
    }
    
    jint* cells = (jint*)array_data(cell_map);
    
    /* Get animated tiles array for resolving animated tile indices */
    JavaArray* anim_tiles = NULL;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "animatedTiles") == 0) {
            anim_tiles = (JavaArray*)this_obj->fields[i].ref;
            break;
        }
    }
    jint* anim_data = anim_tiles ? (jint*)array_data(anim_tiles) : NULL;
    
    /* Calculate tiles per row in source image */
    int tiles_per_row = img->width / tile_width;
    if (tiles_per_row <= 0) tiles_per_row = 1;
    
    /* Paint each cell */
    for (int row = 0; row < rows; row++) {
        for (int col = 0; col < columns; col++) {
            int tile_index = cells[row * columns + col];
            
            if (tile_index != 0) {
                /* Handle animated tiles (negative index) */
                if (tile_index < 0) {
                    /* Convert negative animated index to array index: -1 -> 0, -2 -> 1, etc. */
                    int anim_array_index = -tile_index - 1;
                    if (anim_data && anim_tiles && anim_array_index < (int)anim_tiles->length) {
                        tile_index = anim_data[anim_array_index];
                    } else {
                        tile_index = 0;  /* Invalid animated tile, skip */
                    }
                }
                
                if (tile_index > 0) {
                    /* Tile index is 1-based, convert to 0-based */
                    tile_index--;
                    
                    /* Calculate source position in tile set */
                    int src_col = tile_index % tiles_per_row;
                    int src_row = tile_index / tiles_per_row;
                    int src_x = src_col * tile_width;
                    int src_y = src_row * tile_height;
                    
                    /* Calculate destination position */
                    int dest_x = x + col * tile_width;
                    int dest_y = y + row * tile_height;
                    
                    /* Draw the tile */
                    midp_graphics_draw_region(gfx, img, src_x, src_y, 
                                              tile_width, tile_height,
                                              0, dest_x, dest_y, 0);
                }
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_image_createImage_from_bytes(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaArray* data = (JavaArray*)args[0].ref;
    jint offset = args[1].i;
    jint length = args[2].i;
    
    if (!data) {
        /* COMPATIBILITY: Return null instead of throwing NPE for null data */
        fprintf(stderr, "[Image] createImage: WARNING - null data, returning null for compatibility\n");
        fflush(stderr);
        return NATIVE_RETURN_NULL();
    }
    
    uint8_t* img_data = (uint8_t*)array_data(data) + offset;
    
    /* Decode image using stb_image */
    MidpImage* img = midp_image_create_from_data(img_data, 0, length);
    if (!img) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create Java Image object */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        fprintf(stderr, "[Image] createImage_from_bytes: Failed to load Image class\n");
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(image_class);
    
    JavaObject* image_obj = jvm_new_object(jvm, image_class);
    if (!image_obj) {
        fprintf(stderr, "[Image] createImage_from_bytes: Failed to create Image object\n");
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    image_obj->fields[0].ref = img;
    
    fprintf(stderr, "[Image] createImage_from_bytes: Created Image %dx%d, obj=%p, native=%p\n", 
            img->width, img->height, (void*)image_obj, (void*)img);
    
    return NATIVE_RETURN_OBJECT(image_obj);
}

/*
 * GameCanvas native methods
 */

/* GameCanvas key state bit masks */
#define GAME_KEY_UP_PRESSED     (1 << 1)   /* bit 1 = UP */
#define GAME_KEY_DOWN_PRESSED   (1 << 6)   /* bit 6 = DOWN */
#define GAME_KEY_LEFT_PRESSED   (1 << 2)   /* bit 2 = LEFT */
#define GAME_KEY_RIGHT_PRESSED  (1 << 5)   /* bit 5 = RIGHT */
#define GAME_KEY_FIRE_PRESSED   (1 << 8)   /* bit 8 = FIRE */
#define GAME_KEY_A_PRESSED      (1 << 9)   /* bit 9 = GAME_A */
#define GAME_KEY_B_PRESSED      (1 << 10)  /* bit 10 = GAME_B */
#define GAME_KEY_C_PRESSED      (1 << 11)  /* bit 11 = GAME_C */
#define GAME_KEY_D_PRESSED      (1 << 12)  /* bit 12 = GAME_D */

static int compute_key_states(SdlContext* sdl_ctx) {
    int states = 0;
    if (!sdl_ctx) return 0;
    
    /* Arrow keys */
    if (sdl_key_pressed(sdl_ctx, GAME_UP))    states |= GAME_KEY_UP_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_DOWN))  states |= GAME_KEY_DOWN_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_LEFT))  states |= GAME_KEY_LEFT_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_RIGHT)) states |= GAME_KEY_RIGHT_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_FIRE))  states |= GAME_KEY_FIRE_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_A))     states |= GAME_KEY_A_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_B))     states |= GAME_KEY_B_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_C))     states |= GAME_KEY_C_PRESSED;
    if (sdl_key_pressed(sdl_ctx, GAME_D))     states |= GAME_KEY_D_PRESSED;
    
    return states;
}

static JavaValue native_gamecanvas_getKeyStates(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    SdlContext* sdl_ctx = sdl_get_global_context();
    return NATIVE_RETURN_INT(compute_key_states(sdl_ctx));
}

static JavaValue native_gamecanvas_suppressKeyEvents(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jboolean suppress = args[0].i;
    game_canvas.suppress_key_events = suppress != 0;
    return NATIVE_RETURN_VOID();
}

/* GameCanvas.getGraphics() - returns Graphics bound to screen framebuffer */
static JavaValue native_gamecanvas_getGraphics(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    (void)args;  /* this reference */
    
    fprintf(stderr, "[GameCanvas] getGraphics() called\n");
    fflush(stderr);
    
    /* Get the SDL context */
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (!sdl_ctx || !sdl_ctx->framebuffer) {
        fprintf(stderr, "[GameCanvas] getGraphics: no SDL context or framebuffer\n");
        fflush(stderr);
        return NATIVE_RETURN_NULL();
    }
    
    /* Return graphics bound to screen framebuffer */
    MidpGraphics* gfx = sdl_get_graphics(sdl_ctx);
    fprintf(stderr, "[GameCanvas] getGraphics: returning gfx=%p, pixels=%p, %dx%d\n", 
            (void*)gfx, gfx ? (void*)gfx->pixels : NULL, 
            gfx ? gfx->width : 0, gfx ? gfx->height : 0);
    fflush(stderr);
    return NATIVE_RETURN_OBJECT(gfx);
}

/* GameCanvas.flushGraphics() - flush the entire buffer to the screen */
static JavaValue native_gamecanvas_flushGraphics(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    fprintf(stderr, "[GameCanvas] flushGraphics() called\n");
    fflush(stderr);
    
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (sdl_ctx) {
        sdl_present(sdl_ctx);
    }
    
    return NATIVE_RETURN_VOID();
}

/* GameCanvas.flushGraphics(int x, int y, int w, int h) - flush a region */
static JavaValue native_gamecanvas_flushGraphicsRegion(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* For simplicity, flush entire screen */
    (void)args;
    
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (sdl_ctx) {
        sdl_present(sdl_ctx);
    }
    
    return NATIVE_RETURN_VOID();
}

/*
 * Image native methods
 */

/* Helper to get MidpImage from Java Image object */
static MidpImage* get_image_from_object(JavaObject* obj) {
    if (!obj) {
        fprintf(stderr, "[Image] get_image_from_object: NULL object\n");
        return NULL;
    }
    
    /* Check if object has fields */
    if (!obj->header.clazz) {
        fprintf(stderr, "[Image] get_image_from_object: object has NULL class\n");
        return NULL;
    }
    
    JavaClass* clazz = obj->header.clazz;
    fprintf(stderr, "[Image] get_image_from_object: obj=%p, class=%s, fields_count=%d, instance_size=%zu\n",
            (void*)obj, clazz->class_name ? clazz->class_name : "?", 
            clazz->fields_count, clazz->instance_size);
    
    if (clazz->fields_count == 0) {
        fprintf(stderr, "[Image] get_image_from_object: class has no fields!\n");
        return NULL;
    }
    
    /* The MidpImage* is stored in the first field */
    MidpImage* img = (MidpImage*)obj->fields[0].ref;
    fprintf(stderr, "[Image] get_image_from_object: fields[0].ref = %p\n", (void*)img);
    
    return img;
}

/* Ensure a class has at least one field for storing native pointer */
static void ensure_native_peer_field(JavaClass* clazz) {
    if (!clazz) return;
    
    /* Minimum size needed: ObjectHeader + 1 field (JavaValue) */
    size_t min_size = sizeof(ObjectHeader) + sizeof(JavaValue);
    
    /* 1. Если поле уже есть и размер достаточен — ничего делать не нужно */
    if (clazz->fields_count > 0 && clazz->instance_size >= min_size) {
        return;
    }

    /* 2. Если полей нет, добавляем поле nativePeer */
    if (clazz->fields_count == 0) {
        /* Выделяем память ровно под 1 поле */
        JavaField* new_fields = (JavaField*)calloc(1, sizeof(JavaField));
        if (!new_fields) return; /* OOM */
        
        clazz->fields = new_fields;
        clazz->fields_count = 1;
        
        /* Заполняем поле */
        clazz->fields[0].name = strdup("nativePeer");
        clazz->fields[0].descriptor = strdup("J"); /* Long type */
        clazz->fields[0].access_flags = ACC_PRIVATE;
    }
    
    /* 3. КРИТИЧЕСКИ ВАЖНО: Устанавливаем instance_size
     * Должен включать ObjectHeader + пространство для полей.
     * ObjectHeader = 16 байт (на 64-бит), JavaValue = 8 байт.
     * Для 1 поля: 16 + 8 = 24 байта.
     */
    clazz->instance_size = sizeof(ObjectHeader) + clazz->fields_count * sizeof(JavaValue);

    fprintf(stderr, "[Display] ensure_native_peer_field: Fixed class %s, fields_count=%d, instance_size=%zu\n",
            clazz->class_name ? clazz->class_name : "?", clazz->fields_count, clazz->instance_size);
}

static JavaValue native_image_createImage(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint width = args[0].i;
    jint height = args[1].i;
    
    fprintf(stderr, "[Image] createImage(%d, %d)\n", width, height);
    fflush(stderr);
    
    /* Create the native image */
    MidpImage* img = midp_image_create(width, height, true);
    if (!img) {
        native_throw_oome(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Create a Java Image object to wrap it */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        fprintf(stderr, "[Image] Failed to load Image class\n");
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(image_class);
    
    JavaObject* image_obj = jvm_new_object(jvm, image_class);
    if (!image_obj) {
        fprintf(stderr, "[Image] Failed to create Image object\n");
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Store the MidpImage* in the first field */
    image_obj->fields[0].ref = img;
    
    fprintf(stderr, "[Image] Created Image object: %p, native: %p\n", (void*)image_obj, (void*)img);
    fflush(stderr);
    
    return NATIVE_RETURN_OBJECT(image_obj);
}

/* Image.createImage(String) - load image from JAR resource */
static JavaValue native_image_createImage_from_string(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* name_str = (JavaString*)args[0].ref;
    
    if (!name_str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Get the resource name */
    const char* name = string_utf8(jvm, name_str);
    if (!name) {
        return NATIVE_RETURN_NULL();
    }
    
    fprintf(stderr, "[Image] createImage(\"%s\")\n", name);
    fflush(stderr);
    
    /* Skip leading slash if present (JAR resources don't have leading slash) */
    const char* resource_name = name;
    if (resource_name[0] == '/') {
        resource_name++;
    }
    
    /* Load the resource from JAR */
    size_t data_size;
    uint8_t* data = load_jar_resource(resource_name, &data_size);

    if (!data) {
        fprintf(stderr, "[Image] Resource not found: %s (throwing IOException)\n", name);
        native_throw_ioe(jvm, thread, name);
        return NATIVE_RETURN_NULL();
    }

    fprintf(stderr, "[Image] Loaded %zu bytes from %s\n", data_size, name);

    /* Decode PNG */
    MidpImage* img = midp_image_create_from_data(data, 0, data_size);
    free(data);

    if (!img) {
        fprintf(stderr, "[Image] Failed to decode: %s (throwing IOException)\n", name);
        native_throw_ioe(jvm, thread, "Failed to decode image");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create a Java Image object to wrap it */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(image_class);
    
    JavaObject* image_obj = jvm_new_object(jvm, image_class);
    if (!image_obj) {
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Store the MidpImage* in the first field */
    fprintf(stderr, "[Image] Storing img=%p in fields[0] of object %p (class fields_count=%d, instance_size=%zu)\n",
            (void*)img, (void*)image_obj, image_class->fields_count, image_class->instance_size);
    image_obj->fields[0].ref = img;
    
    /* Verify the storage */
    fprintf(stderr, "[Image] Verification: fields[0].ref = %p\n", (void*)image_obj->fields[0].ref);
    
    fprintf(stderr, "[Image] Created Image %dx%d from %s\n", img->width, img->height, name);
    
    return NATIVE_RETURN_OBJECT(image_obj);
}

static JavaValue native_image_createRGBImage(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaArray* rgb_array = (JavaArray*)args[0].ref;
    jint width = args[1].i;
    jint height = args[2].i;
    jboolean process_alpha = args[3].i;
    
    if (!rgb_array) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    jint* rgb = (jint*)array_data(rgb_array);
    MidpImage* img = midp_image_create_from_rgb(rgb, width, height, process_alpha != 0);
    
    if (!img) {
        native_throw_oome(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    /* Create a Java Image object to wrap it */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(image_class);
    
    JavaObject* image_obj = jvm_new_object(jvm, image_class);
    if (!image_obj) {
        midp_image_destroy(img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Store the MidpImage* in the first field */
    image_obj->fields[0].ref = img;
    
    return NATIVE_RETURN_OBJECT(image_obj);
}

static JavaValue native_image_getWidth(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    MidpImage* img = get_image_from_object(obj);
    return NATIVE_RETURN_INT(img ? img->width : 0);
}

static JavaValue native_image_getHeight(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    MidpImage* img = get_image_from_object(obj);
    return NATIVE_RETURN_INT(img ? img->height : 0);
}

static JavaValue native_image_isMutable(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    MidpImage* img = get_image_from_object(obj);
    return NATIVE_RETURN_INT(img && img->mutable ? 1 : 0);
}

static JavaValue native_image_getRGB(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    MidpImage* img = get_image_from_object(obj);
    JavaArray* rgb_data = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint scanlength = args[3].i;
    jint x = args[4].i;
    jint y = args[5].i;
    jint width = args[6].i;
    jint height = args[7].i;
    
    if (!img || !rgb_data) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    midp_image_get_rgb(img, (jint*)array_data(rgb_data), offset, scanlength, x, y, width, height);
    
    return NATIVE_RETURN_VOID();
}

/* Image.createImage(Image source, int x, int y, int width, int height, int transform)
 * CRITICAL: Creates a sub-image with optional transformation
 */
static JavaValue native_image_createImage_region(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* src_image_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint width = args[3].i;
    jint height = args[4].i;
    jint transform = args[5].i;
    
    if (!src_image_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    MidpImage* src_img = get_image_from_object(src_image_obj);
    if (!src_img) {
        fprintf(stderr, "[Image] createImage_region: source image has no native data\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Bounds check */
    if (x < 0 || y < 0 || width <= 0 || height <= 0) {
        return NATIVE_RETURN_NULL();
    }
    if (x + width > src_img->width || y + height > src_img->height) {
        fprintf(stderr, "[Image] createImage_region: region out of bounds\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Calculate output dimensions based on transform */
    int dest_w = width, dest_h = height;
    if (transform == SPRITE_TRANS_ROT90 || transform == SPRITE_TRANS_ROT270 ||
        transform == SPRITE_TRANS_MIRROR_ROT90 || transform == SPRITE_TRANS_MIRROR_ROT270) {
        dest_w = height;
        dest_h = width;
    }
    
    /* Allocate new image */
    MidpImage* new_img = (MidpImage*)calloc(1, sizeof(MidpImage));
    if (!new_img) return NATIVE_RETURN_NULL();
    
    new_img->width = dest_w;
    new_img->height = dest_h;
    new_img->mutable = false;
    new_img->alpha = src_img->alpha;
    new_img->pixels = (uint32_t*)malloc(dest_w * dest_h * sizeof(uint32_t));
    if (!new_img->pixels) {
        free(new_img);
        return NATIVE_RETURN_NULL();
    }
    
    /* Copy pixels with transformation */
    for (int dy = 0; dy < height; dy++) {
        for (int dx = 0; dx < width; dx++) {
            int src_idx = (y + dy) * src_img->width + (x + dx);
            uint32_t pixel = src_img->pixels[src_idx];
            
            int dest_x, dest_y;
            switch (transform) {
                case SPRITE_TRANS_NONE:
                    dest_x = dx; dest_y = dy; break;
                case SPRITE_TRANS_MIRROR:
                    dest_x = dx; dest_y = height - 1 - dy; break;
                case SPRITE_TRANS_ROT180:
                    dest_x = width - 1 - dx; dest_y = height - 1 - dy; break;
                case SPRITE_TRANS_MIRROR_ROT180:
                    dest_x = width - 1 - dx; dest_y = height - 1 - dy; break;
                case SPRITE_TRANS_ROT90:
                    dest_x = height - 1 - dy; dest_y = dx; break;
                case SPRITE_TRANS_ROT270:
                    dest_x = dy; dest_y = width - 1 - dx; break;
                case SPRITE_TRANS_MIRROR_ROT90:
                    dest_x = dy; dest_y = width - 1 - dx; break;
                case SPRITE_TRANS_MIRROR_ROT270:
                    dest_x = height - 1 - dy; dest_y = dx; break;
                default:
                    dest_x = dx; dest_y = dy; break;
            }
            
            int dest_idx = dest_y * dest_w + dest_x;
            new_img->pixels[dest_idx] = pixel;
        }
    }
    
    /* Create Java Image object */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) {
        free(new_img->pixels);
        free(new_img);
        return NATIVE_RETURN_NULL();
    }
    
    ensure_native_peer_field(image_class);
    JavaObject* image_obj = jvm_new_object(jvm, image_class);
    if (!image_obj) {
        free(new_img->pixels);
        free(new_img);
        return NATIVE_RETURN_NULL();
    }
    
    image_obj->fields[0].ref = new_img;
    
    fprintf(stderr, "[Image] Created region image: %dx%d (transform=%d)\n", dest_w, dest_h, transform);
    return NATIVE_RETURN_OBJECT(image_obj);
}

/* Image.createImage(Image source) - creates a copy */
static JavaValue native_image_createImage_copy(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* src_image_obj = (JavaObject*)args[0].ref;
    
    if (!src_image_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    MidpImage* src_img = get_image_from_object(src_image_obj);
    if (!src_img) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create copy with transform=NONE */
    JavaValue region_args[6];
    region_args[0].ref = src_image_obj;
    region_args[1].i = 0;
    region_args[2].i = 0;
    region_args[3].i = src_img->width;
    region_args[4].i = src_img->height;
    region_args[5].i = SPRITE_TRANS_NONE;
    
    return native_image_createImage_region(jvm, thread, region_args, 6);
}

/* Image.createImage(InputStream stream) - load from stream */
static JavaValue native_image_createImage_stream(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* stream_obj = (JavaObject*)args[0].ref;
    
    if (!stream_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Try to read all bytes from the stream */
    /* For now, we'll return a stub implementation */
    fprintf(stderr, "[Image] createImage(InputStream) - not fully implemented\n");
    
    /* Create a small placeholder image */
    JavaClass* image_class = jvm_load_class(jvm, "javax/microedition/lcdui/Image");
    if (!image_class) return NATIVE_RETURN_NULL();
    
    ensure_native_peer_field(image_class);
    JavaObject* image_obj = jvm_new_object(jvm, image_class);
    if (!image_obj) return NATIVE_RETURN_NULL();
    
    MidpImage* img = (MidpImage*)calloc(1, sizeof(MidpImage));
    if (!img) return NATIVE_RETURN_NULL();
    
    img->width = 1;
    img->height = 1;
    img->mutable = false;
    img->alpha = false;
    img->pixels = (uint32_t*)malloc(sizeof(uint32_t));
    if (img->pixels) img->pixels[0] = 0; /* Transparent pixel */
    
    image_obj->fields[0].ref = img;
    return NATIVE_RETURN_OBJECT(image_obj);
}

/* Image.getGraphics() - returns Graphics for mutable images */
static JavaValue native_image_getGraphics(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* image_obj = (JavaObject*)args[0].ref;
    
    fprintf(stderr, "[Image] getGraphics() called, obj=%p\n", (void*)image_obj);
    fflush(stderr);
    
    if (!image_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    MidpImage* img = get_image_from_object(image_obj);
    if (!img) {
        fprintf(stderr, "[Image] getGraphics: no native image\n");
        return NATIVE_RETURN_NULL();
    }
    
    if (!img->mutable) {
        fprintf(stderr, "[Image] getGraphics: image is not mutable\n");
        /* IllegalStateException for immutable image */
        return NATIVE_RETURN_NULL();
    }
    
    /* Create a Graphics object for this image */
    MidpGraphics* gfx = midp_image_get_graphics(img);
    if (!gfx) {
        fprintf(stderr, "[Image] getGraphics: failed to create graphics\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create a Java Graphics object */
    JavaClass* gfx_class = jvm_load_class(jvm, "javax/microedition/lcdui/Graphics");
    if (!gfx_class) {
        fprintf(stderr, "[Image] getGraphics: failed to load Graphics class\n");
        free(gfx);
        return NATIVE_RETURN_NULL();
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(gfx_class);
    
    JavaObject* gfx_obj = jvm_new_object(jvm, gfx_class);
    if (!gfx_obj) {
        fprintf(stderr, "[Image] getGraphics: failed to create Graphics object\n");
        free(gfx);
        return NATIVE_RETURN_NULL();
    }
    
    /* Store the MidpGraphics* in the first field */
    gfx_obj->fields[0].ref = gfx;
    
    fprintf(stderr, "[Image] getGraphics: returning Graphics obj=%p, native gfx=%p\n", 
            (void*)gfx_obj, (void*)gfx);
    fflush(stderr);
    
    return NATIVE_RETURN_OBJECT(gfx_obj);
}

/*
 * Graphics native methods
 */

static JavaValue native_graphics_setColor(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint rgb = args[1].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    /*fprintf(stderr, "[Graphics] setColor(RGB): obj=%p, gfx=%p, RGB=0x%06X\n", 
            (void*)gfx_obj, (void*)gfx, rgb & 0xFFFFFF);
    fflush(stderr);*/
    
    if (gfx) {
        midp_graphics_set_color(gfx, rgb, 255);
    }
    
    return NATIVE_RETURN_VOID();
}

/* setColor(int red, int green, int blue) - separate RGB components */
static JavaValue native_graphics_setColorRGB(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint red = args[1].i;
    jint green = args[2].i;
    jint blue = args[3].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    jint rgb = ((red & 0xFF) << 16) | ((green & 0xFF) << 8) | (blue & 0xFF);
    
    /*fprintf(stderr, "[Graphics] setColor(R,G,B): obj=%p, gfx=%p, R=%d, G=%d, B=%d -> 0x%06X\n", 
            (void*)gfx_obj, (void*)gfx, red, green, blue, rgb);
    fflush(stderr);*/
    
    if (gfx) {
        midp_graphics_set_color(gfx, rgb, 255);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_drawLine(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x1 = args[1].i;
    jint y1 = args[2].i;
    jint x2 = args[3].i;
    jint y2 = args[4].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    /*fprintf(stderr, "[Graphics] drawLine: gfx=%p, (%d,%d)->(%d,%d)\n", 
            (void*)gfx, x1, y1, x2, y2);
    fflush(stderr);*/
    
    if (gfx) {
        midp_graphics_draw_line(gfx, x1, y1, x2, y2);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_fillRect(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    /*fprintf(stderr, "[Graphics] fillRect: gfx=%p, (%d,%d) %dx%d\n", 
            (void*)gfx, x, y, w, h);
    fflush(stderr);*/
    
    if (gfx) {
        midp_graphics_fill_rect(gfx, x, y, w, h);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_drawRect(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_draw_rect(gfx, x, y, w, h);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_drawImage(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    JavaObject* image_obj = (JavaObject*)args[1].ref;
    jint x = args[2].i;
    jint y = args[3].i;
    jint anchor = args[4].i;
    
    /*fprintf(stderr, "[Graphics] drawImage: gfx_obj=%p, image_obj=%p, x=%d, y=%d, anchor=%d\n",
            (void*)gfx_obj, (void*)image_obj, x, y, anchor);
    fflush(stderr);*/
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    MidpImage* img = get_image_from_object(image_obj);
    
    /*fprintf(stderr, "[Graphics] drawImage: gfx=%p, img=%p\n", (void*)gfx, (void*)img);
    fflush(stderr);*/
    
    if (!gfx || !img) {
        fprintf(stderr, "[Graphics] drawImage: NULL pointer! gfx=%p, img=%p\n", (void*)gfx, (void*)img);
        fflush(stderr);
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    /* Detailed debug with translation and anchor calculation */
    int final_x = x + gfx->translate_x;
    int final_y = y + gfx->translate_y;
    
    /* Calculate anchor adjustments */
    int anchor_dx = 0, anchor_dy = 0;
    if (anchor & 0x01) anchor_dx = -img->width / 2;      /* HCENTER */
    else if (anchor & 0x08) anchor_dx = -img->width;     /* RIGHT */
    if (anchor & 0x02) anchor_dy = -img->height / 2;     /* VCENTER */
    else if (anchor & 0x20) anchor_dy = -img->height;    /* BOTTOM */
    
    /*fprintf(stderr, "[Graphics] drawImage: img=%dx%d, src=(%d,%d), translate=(%d,%d), anchor=%d (dx=%d,dy=%d), final=(%d,%d), clip=(%d,%d %dx%d)\n",
            img->width, img->height, x, y, gfx->translate_x, gfx->translate_y, 
            anchor, anchor_dx, anchor_dy,
            final_x + anchor_dx, final_y + anchor_dy,
            gfx->clip_x, gfx->clip_y, gfx->clip_width, gfx->clip_height);
    fflush(stderr);*/
    
    midp_graphics_draw_image(gfx, img, x, y, anchor);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_setClip(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    /*fprintf(stderr, "[Graphics] setClip: (%d,%d) %dx%d, gfx=%p\n", x, y, w, h, (void*)gfx);
    fflush(stderr);*/
    
    if (gfx) {
        midp_graphics_set_clip(gfx, x, y, w, h);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_translate(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_translate(gfx, x, y);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_getTranslateX(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->translate_x : 0);
}

static JavaValue native_graphics_getTranslateY(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->translate_y : 0);
}

static JavaValue native_graphics_getClipX(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->clip_x : 0);
}

static JavaValue native_graphics_getClipY(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->clip_y : 0);
}

static JavaValue native_graphics_getClipWidth(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->clip_width : 0);
}

static JavaValue native_graphics_getClipHeight(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->clip_height : 0);
}

static JavaValue native_graphics_getColor(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    return NATIVE_RETURN_INT(gfx ? gfx->rgb_color : 0);
}

/* Forward declaration for get_font_from_object (defined in Font section below) */
static MidpFont* get_font_from_object(JavaObject* obj);

static JavaValue native_graphics_setFont(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    JavaObject* font_obj = (JavaObject*)args[1].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    /*fprintf(stderr, "[Graphics] setFont: gfx=%p, font_obj=%p, font=%p\n", 
            (void*)gfx, (void*)font_obj, (void*)font);
    fflush(stderr);*/
    
    if (gfx && font) {
        /* Store font pointer as jint (hack but works) */
        gfx->font = (jint)(intptr_t)font;
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_clipRect(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_clip_rect(gfx, x, y, w, h);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_drawRoundRect(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    jint arc_w = args[5].i;
    jint arc_h = args[6].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_draw_round_rect(gfx, x, y, w, h, arc_w, arc_h);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_fillRoundRect(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    jint arc_w = args[5].i;
    jint arc_h = args[6].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_fill_round_rect(gfx, x, y, w, h, arc_w, arc_h);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_drawArc(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    jint start = args[5].i;
    jint arc = args[6].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_draw_arc(gfx, x, y, w, h, start, arc);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_fillArc(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    jint start = args[5].i;
    jint arc = args[6].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    if (gfx) {
        midp_graphics_fill_arc(gfx, x, y, w, h, start, arc);
    }
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_graphics_drawString(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    const char* str = native_get_string_utf8(jvm, args, 1);
    jint x = args[2].i;
    jint y = args[3].i;
    jint anchor = args[4].i;
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    
    fprintf(stderr, "[Graphics] drawString: gfx=%p, str='%s', x=%d, y=%d, anchor=%d\n",
            (void*)gfx, str ? str : "(null)", x, y, anchor);
    fflush(stderr);
    
    if (gfx && str) {
        midp_graphics_draw_string(gfx, str, x, y, anchor);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Helper to apply transform to source coordinates */
static void transform_coord(int transform, int src_x, int src_y, int src_w, int src_h,
                           int *out_x, int *out_y) {
    switch (transform) {
        case SPRITE_TRANS_NONE:           /* No transform */
            *out_x = src_x;
            *out_y = src_y;
            break;
        case SPRITE_TRANS_MIRROR_ROT180:  /* Mirror vertical + rotate 180 */
            *out_x = src_w - 1 - src_x;
            *out_y = src_h - 1 - src_y;
            break;
        case SPRITE_TRANS_MIRROR:         /* Mirror vertical */
            *out_x = src_x;
            *out_y = src_h - 1 - src_y;
            break;
        case SPRITE_TRANS_ROT180:         /* Rotate 180 */
            *out_x = src_w - 1 - src_x;
            *out_y = src_h - 1 - src_y;
            break;
        case SPRITE_TRANS_MIRROR_ROT270:  /* Mirror + rotate 270 (90 CCW) */
            *out_x = src_h - 1 - src_y;
            *out_y = src_x;
            break;
        case SPRITE_TRANS_ROT90:          /* Rotate 90 CW */
            *out_x = src_h - 1 - src_y;
            *out_y = src_w - 1 - src_x;
            break;
        case SPRITE_TRANS_ROT270:         /* Rotate 270 CW (90 CCW) */
            *out_x = src_y;
            *out_y = src_x;
            break;
        case SPRITE_TRANS_MIRROR_ROT90:   /* Mirror + rotate 90 */
            *out_x = src_y;
            *out_y = src_w - 1 - src_x;
            break;
        default:
            *out_x = src_x;
            *out_y = src_y;
            break;
    }
}

/* Get output dimensions after transform */
static void get_transformed_size(int transform, int src_w, int src_h, int *out_w, int *out_h) {
    switch (transform) {
        case SPRITE_TRANS_ROT90:
        case SPRITE_TRANS_ROT270:
        case SPRITE_TRANS_MIRROR_ROT270:
        case SPRITE_TRANS_MIRROR_ROT90:
            *out_w = src_h;
            *out_h = src_w;
            break;
        default:
            *out_w = src_w;
            *out_h = src_h;
            break;
    }
}

/* Graphics.drawRegion(Image src, int x_src, int y_src, int width, int height, 
 *                    int transform, int x_dest, int y_dest, int anchor)
 * CRITICAL for game compatibility!
 */
static JavaValue native_graphics_drawRegion(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    JavaObject* src_image_obj = (JavaObject*)args[1].ref;
    jint x_src = args[2].i;
    jint y_src = args[3].i;
    jint width = args[4].i;
    jint height = args[5].i;
    jint transform = args[6].i;
    jint x_dest = args[7].i;
    jint y_dest = args[8].i;
    jint anchor = args[9].i;
    
    if (!gfx_obj || !src_image_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    MidpImage* src_img = get_image_from_object(src_image_obj);
    
    if (!gfx || !src_img || !src_img->pixels) {
        fprintf(stderr, "[Graphics] drawRegion: invalid graphics or image\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Bounds check source region */
    if (x_src < 0 || y_src < 0 || width <= 0 || height <= 0) {
        return NATIVE_RETURN_VOID();
    }
    if (x_src + width > src_img->width || y_src + height > src_img->height) {
        fprintf(stderr, "[Graphics] drawRegion: source region out of bounds\n");
        return NATIVE_RETURN_VOID();
    }
    
    /* Get transformed dimensions */
    int dest_w, dest_h;
    get_transformed_size(transform, width, height, &dest_w, &dest_h);
    
    /* Calculate anchor offset */
    int anchor_x = 0, anchor_y = 0;
    if (anchor & 0x02) anchor_x = -dest_w;        /* RIGHT */
    else if (anchor & 0x01) anchor_x = -dest_w/2; /* HCENTER */
    if (anchor & 0x20) anchor_y = -dest_h;        /* BOTTOM */
    else if (anchor & 0x10) anchor_y = -dest_h/2; /* VCENTER */
    else if (anchor & 0x40) anchor_y = 0;         /* BASELINE - treat as TOP */
    
    /* Apply translation */
    int draw_x = x_dest + anchor_x + gfx->translate_x;
    int draw_y = y_dest + anchor_y + gfx->translate_y;
    
    /* Clip to graphics clip region */
    int clip_x1 = gfx->clip_x;
    int clip_y1 = gfx->clip_y;
    int clip_x2 = gfx->clip_x + gfx->clip_width;
    int clip_y2 = gfx->clip_y + gfx->clip_height;
    
    /* Draw with transform */
    for (int dy = 0; dy < height; dy++) {
        for (int dx = 0; dx < width; dx++) {
            /* Get source pixel */
            int sx, sy;
            transform_coord(transform, dx, dy, width, height, &sx, &sy);
            
            int src_idx = (y_src + sy) * src_img->width + (x_src + sx);
            uint32_t pixel = src_img->pixels[src_idx];
            
            /* Skip transparent pixels (alpha == 0) */
            uint8_t alpha = (pixel >> 24) & 0xFF;
            if (alpha == 0) continue;
            
            /* Calculate destination position */
            int dest_px, dest_py;
            switch (transform) {
                case SPRITE_TRANS_ROT90:
                case SPRITE_TRANS_MIRROR_ROT90:
                    dest_px = draw_x + (height - 1 - dy);
                    dest_py = draw_y + dx;
                    break;
                case SPRITE_TRANS_ROT270:
                case SPRITE_TRANS_MIRROR_ROT270:
                    dest_px = draw_x + dy;
                    dest_py = draw_y + (width - 1 - dx);
                    break;
                default:
                    dest_px = draw_x + dx;
                    dest_py = draw_y + dy;
                    break;
            }
            
            /* Clip check */
            if (dest_px < clip_x1 || dest_px >= clip_x2 ||
                dest_py < clip_y1 || dest_py >= clip_y2) continue;
            
            /* Bounds check */
            if (dest_px < 0 || dest_px >= gfx->width ||
                dest_py < 0 || dest_py >= gfx->height) continue;
            
            /* Draw pixel */
            int dest_idx = dest_py * gfx->width + dest_px;
            
            /* Alpha blending if needed */
            if (alpha == 255 || !src_img->alpha) {
                gfx->pixels[dest_idx] = pixel;
            } else {
                uint32_t dest_pixel = gfx->pixels[dest_idx];
                uint8_t da = (dest_pixel >> 24) & 0xFF;
                uint8_t dr = (dest_pixel >> 16) & 0xFF;
                uint8_t dg = (dest_pixel >> 8) & 0xFF;
                uint8_t db = dest_pixel & 0xFF;
                uint8_t sr = (pixel >> 16) & 0xFF;
                uint8_t sg = (pixel >> 8) & 0xFF;
                uint8_t sb = pixel & 0xFF;
                uint8_t out_a = 255;
                uint8_t out_r = (sr * alpha + dr * (255 - alpha)) / 255;
                uint8_t out_g = (sg * alpha + dg * (255 - alpha)) / 255;
                uint8_t out_b = (sb * alpha + db * (255 - alpha)) / 255;
                gfx->pixels[dest_idx] = (out_a << 24) | (out_r << 16) | (out_g << 8) | out_b;
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics.drawImage(Image img, int x, int y, int anchor) - simplified version */
static JavaValue native_graphics_drawImage_anchor(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    JavaObject* image_obj = (JavaObject*)args[1].ref;
    jint x = args[2].i;
    jint y = args[3].i;
    jint anchor = args[4].i;
    
    if (!gfx_obj || !image_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    MidpImage* img = get_image_from_object(image_obj);
    
    if (!gfx || !img || !img->pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Calculate anchor offset */
    int anchor_x = 0, anchor_y = 0;
    if (anchor & 0x02) anchor_x = -img->width;      /* RIGHT */
    else if (anchor & 0x01) anchor_x = -img->width/2; /* HCENTER */
    if (anchor & 0x20) anchor_y = -img->height;     /* BOTTOM */
    else if (anchor & 0x10) anchor_y = -img->height/2; /* VCENTER */
    
    int draw_x = x + anchor_x + gfx->translate_x;
    int draw_y = y + anchor_y + gfx->translate_y;
    
    /* Clip to graphics bounds and clip region */
    int clip_x1 = gfx->clip_x;
    int clip_y1 = gfx->clip_y;
    int clip_x2 = gfx->clip_x + gfx->clip_width;
    int clip_y2 = gfx->clip_y + gfx->clip_height;
    
    for (int py = 0; py < img->height; py++) {
        for (int px = 0; px < img->width; px++) {
            int dest_x = draw_x + px;
            int dest_y = draw_y + py;
            
            /* Clip check */
            if (dest_x < clip_x1 || dest_x >= clip_x2 ||
                dest_y < clip_y1 || dest_y >= clip_y2) continue;
            
            /* Bounds check */
            if (dest_x < 0 || dest_x >= gfx->width ||
                dest_y < 0 || dest_y >= gfx->height) continue;
            
            uint32_t pixel = img->pixels[py * img->width + px];
            uint8_t alpha = (pixel >> 24) & 0xFF;
            
            /* Skip transparent pixels */
            if (alpha == 0) continue;
            
            int dest_idx = dest_y * gfx->width + dest_x;
            
            /* Alpha blending */
            if (alpha == 255 || !img->alpha) {
                gfx->pixels[dest_idx] = pixel;
            } else {
                uint32_t dest_pixel = gfx->pixels[dest_idx];
                uint8_t dr = (dest_pixel >> 16) & 0xFF;
                uint8_t dg = (dest_pixel >> 8) & 0xFF;
                uint8_t db = dest_pixel & 0xFF;
                uint8_t sr = (pixel >> 16) & 0xFF;
                uint8_t sg = (pixel >> 8) & 0xFF;
                uint8_t sb = pixel & 0xFF;
                gfx->pixels[dest_idx] = (255 << 24) |
                    (((sr * alpha + dr * (255 - alpha)) / 255) << 16) |
                    (((sg * alpha + dg * (255 - alpha)) / 255) << 8) |
                    ((sb * alpha + db * (255 - alpha)) / 255);
            }
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics.copyArea(int x_src, int y_src, int width, int height, int x_dest, int y_dest, int anchor) */
static JavaValue native_graphics_copyArea(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint x_src = args[1].i;
    jint y_src = args[2].i;
    jint width = args[3].i;
    jint height = args[4].i;
    jint x_dest = args[5].i;
    jint y_dest = args[6].i;
    jint anchor = args[7].i;
    
    if (!gfx_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (!gfx || !gfx->pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Calculate anchor offset */
    int anchor_x = 0, anchor_y = 0;
    if (anchor & 0x02) anchor_x = -width;
    else if (anchor & 0x01) anchor_x = -width/2;
    if (anchor & 0x20) anchor_y = -height;
    else if (anchor & 0x10) anchor_y = -height/2;
    
    int dest_x = x_dest + anchor_x + gfx->translate_x;
    int dest_y = y_dest + anchor_y + gfx->translate_y;
    
    /* Copy region (need temp buffer for overlapping copy) */
    uint32_t* temp = (uint32_t*)malloc(width * height * sizeof(uint32_t));
    if (!temp) return NATIVE_RETURN_VOID();
    
    /* Copy source to temp */
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int sx = x_src + x;
            int sy = y_src + y;
            if (sx >= 0 && sx < gfx->width && sy >= 0 && sy < gfx->height) {
                temp[y * width + x] = gfx->pixels[sy * gfx->width + sx];
            } else {
                temp[y * width + x] = 0;
            }
        }
    }
    
    /* Copy temp to destination */
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int dx = dest_x + x;
            int dy = dest_y + y;
            if (dx >= 0 && dx < gfx->width && dy >= 0 && dy < gfx->height) {
                gfx->pixels[dy * gfx->width + dx] = temp[y * width + x];
            }
        }
    }
    
    free(temp);
    return NATIVE_RETURN_VOID();
}

/* Graphics.getDisplayColor(int color) - returns the color that will be displayed */
static JavaValue native_graphics_getDisplayColor(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint color = args[1].i;
    /* On color display, return the same color */
    return NATIVE_RETURN_INT(color);
}

/* Graphics.setStrokeStyle(int style) - SOLID=0, DOTTED=1 */
static JavaValue native_graphics_setStrokeStyle(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint style = args[1].i;
    
    if (!gfx_obj) return NATIVE_RETURN_VOID();
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (gfx) {
        gfx->stroke_style = style;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics.getStrokeStyle() */
static JavaValue native_graphics_getStrokeStyle(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    
    if (!gfx_obj) return NATIVE_RETURN_INT(0);
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (gfx) {
        return NATIVE_RETURN_INT(gfx->stroke_style);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Graphics.setGrayScale(int value) */
static JavaValue native_graphics_setGrayScale(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    jint value = args[1].i;
    
    if (!gfx_obj) return NATIVE_RETURN_VOID();
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (gfx) {
        /* Convert grayscale to RGB */
        uint8_t gray = value & 0xFF;
        gfx->rgb_color = 0xFF000000 | (gray << 16) | (gray << 8) | gray;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics.getGrayScale() */
static JavaValue native_graphics_getGrayScale(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gfx_obj = (JavaObject*)args[0].ref;
    
    if (!gfx_obj) return NATIVE_RETURN_INT(0);
    
    MidpGraphics* gfx = get_graphics_from_object(gfx_obj);
    if (gfx) {
        uint8_t r = (gfx->rgb_color >> 16) & 0xFF;
        uint8_t g = (gfx->rgb_color >> 8) & 0xFF;
        uint8_t b = gfx->rgb_color & 0xFF;
        return NATIVE_RETURN_INT((r + g + b) / 3);
    }
    
    return NATIVE_RETURN_INT(0);
}

/*
 * Font native methods
 */

/* Helper to get MidpFont from Java Font object */
static MidpFont* get_font_from_object(JavaObject* obj) {
    if (!obj) {
        fprintf(stderr, "[Font] get_font_from_object: NULL object\n");
        return NULL;
    }
    
    /* Check if object has fields */
    if (!obj->header.clazz) {
        fprintf(stderr, "[Font] get_font_from_object: object has NULL class\n");
        return NULL;
    }
    
    JavaClass* clazz = obj->header.clazz;
    
    if (clazz->fields_count == 0) {
        fprintf(stderr, "[Font] get_font_from_object: class has no fields!\n");
        return NULL;
    }
    
    /* The MidpFont* is stored in the first field */
    MidpFont* font = (MidpFont*)obj->fields[0].ref;
    return font;
}

/* Cached default Font Java object */
static JavaObject* g_default_font_object = NULL;

/* Helper to create a Java Font object wrapping a MidpFont */
static JavaObject* create_font_object(JVM* jvm, MidpFont* font) {
    if (!font) return NULL;
    
    /* Get the Font class */
    JavaClass* font_class = jvm_load_class(jvm, "javax/microedition/lcdui/Font");
    if (!font_class) {
        fprintf(stderr, "[Font] Failed to load Font class\n");
        return NULL;
    }
    
    /* Ensure class has space for nativePeer */
    ensure_native_peer_field(font_class);
    
    /* Create Font object */
    JavaObject* font_obj = jvm_new_object(jvm, font_class);
    if (!font_obj) {
        fprintf(stderr, "[Font] Failed to create Font object\n");
        return NULL;
    }
    
    /* Store the MidpFont* in the first field */
    font_obj->fields[0].ref = font;
    
    fprintf(stderr, "[Font] Created Font object: %p, native: %p\n", (void*)font_obj, (void*)font);
    fflush(stderr);
    
    return font_obj;
}

static JavaValue native_font_getDefaultFont(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    
    fprintf(stderr, "[Font] getDefaultFont() called\n");
    fflush(stderr);
    
    /* Return cached default Font object */
    if (!g_default_font_object) {
        MidpFont* default_font = midp_font_get_default();
        g_default_font_object = create_font_object(jvm, default_font);
        /* Register as GC root to prevent collection */
        if (g_default_font_object) {
            gc_add_root(jvm, (void**)&g_default_font_object);
        }
    }
    
    return NATIVE_RETURN_OBJECT(g_default_font_object);
}

static JavaValue native_font_stringWidth(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    const char* str = native_get_string_utf8(jvm, args, 1);
    
    return NATIVE_RETURN_INT(midp_font_string_width(font, str));
}

static JavaValue native_font_height(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    fprintf(stderr, "[Font] getHeight() called, obj=%p, font=%p, height=%d\n", 
            (void*)font_obj, (void*)font, font ? font->height : 0);
    fflush(stderr);
    
    return NATIVE_RETURN_INT(midp_font_height(font));
}

/* Font.charWidth(char ch) */
static JavaValue native_font_charWidth(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    jchar ch = (jchar)args[1].i;
    
    MidpFont* font = get_font_from_object(font_obj);
    if (!font) return NATIVE_RETURN_INT(0);
    
    /* For bitmap fonts, character width is typically fixed or based on character */
    int width = midp_font_char_width(font, ch);
    return NATIVE_RETURN_INT(width);
}

/* Font.charsWidth(char[] ch, int offset, int length) */
static JavaValue native_font_charsWidth(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    JavaArray* char_array = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    MidpFont* font = get_font_from_object(font_obj);
    if (!font || !char_array) return NATIVE_RETURN_INT(0);
    
    /* Calculate total width */
    int total_width = 0;
    jchar* chars = (jchar*)array_data(char_array);
    for (int i = 0; i < length && (offset + i) < (int)char_array->length; i++) {
        total_width += midp_font_char_width(font, chars[offset + i]);
    }
    
    return NATIVE_RETURN_INT(total_width);
}

/* Font.substringWidth(String str, int offset, int len) */
static JavaValue native_font_substringWidth(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    JavaString* str = (JavaString*)args[1].ref;
    jint offset = args[2].i;
    jint len = args[3].i;
    
    MidpFont* font = get_font_from_object(font_obj);
    if (!font || !str) return NATIVE_RETURN_INT(0);
    
    /* Get the substring and calculate width */
    const jchar* chars = string_chars(str);
    int total_width = 0;
    for (int i = 0; i < len && (offset + i) < str->length; i++) {
        total_width += midp_font_char_width(font, chars[offset + i]);
    }
    
    return NATIVE_RETURN_INT(total_width);
}

/* Font.getBaselinePosition() */
static JavaValue native_font_getBaselinePosition(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    
    /* Baseline is typically near the bottom of the font height */
    return NATIVE_RETURN_INT(font->baseline);
}

/* Font.getFace() */
static JavaValue native_font_getFace(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(font->face);
}

/* Font.getStyle() */
static JavaValue native_font_getStyle(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(font->style);
}

/* Font.getSize() */
static JavaValue native_font_getSize(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(font->size);
}

/* Font.isPlain(), isBold(), isItalic(), isUnderlined() */
static JavaValue native_font_isBold(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT((font->style & FONT_STYLE_BOLD) != 0);
}

static JavaValue native_font_isItalic(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT((font->style & FONT_STYLE_ITALIC) != 0);
}

static JavaValue native_font_isUnderlined(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT((font->style & FONT_STYLE_UNDERLINED) != 0);
}

static JavaValue native_font_isPlain(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* font_obj = (JavaObject*)args[0].ref;
    MidpFont* font = get_font_from_object(font_obj);
    
    if (!font) return NATIVE_RETURN_INT(1);
    return NATIVE_RETURN_INT(font->style == FONT_STYLE_PLAIN);
}

static JavaValue native_font_getFont(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint face = args[0].i;
    jint style = args[1].i;
    jint size = args[2].i;
    
    fprintf(stderr, "[Font] getFont(%d, %d, %d) called\n", face, style, size);
    fflush(stderr);
    
    /* Get or create native font */
    MidpFont* font = midp_font_get(face, style, size);
    if (!font) {
        fprintf(stderr, "[Font] getFont: failed to create native font\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create Java Font object to wrap it */
    JavaObject* font_obj = create_font_object(jvm, font);
    
    return NATIVE_RETURN_OBJECT(font_obj);
}

/*
 * Initialize native methods
 */

void init_javax_microedition_lcdui_display(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/lcdui/Display", "getDisplay", "(Ljavax/microedition/midlet/MIDlet;)Ljavax/microedition/lcdui/Display;", native_display_getDisplay},
        {"javax/microedition/lcdui/Display", "setCurrent", "(Ljavax/microedition/lcdui/Displayable;)V", native_display_setCurrent},
        {"javax/microedition/lcdui/Display", "getCurrent", "()Ljavax/microedition/lcdui/Displayable;", native_display_getCurrent},
        {"javax/microedition/lcdui/Display", "callSerially", "(Ljava/lang/Runnable;)V", native_display_callSerially},
        {"javax/microedition/lcdui/Display", "getWidth", "()I", native_display_getWidth},
        {"javax/microedition/lcdui/Display", "getHeight", "()I", native_display_getHeight},
        {"javax/microedition/lcdui/Display", "isColor", "()Z", native_display_isColor},
        {"javax/microedition/lcdui/Display", "numColors", "()I", native_display_numColors},
        {"javax/microedition/lcdui/Display", "numAlphaLevels", "()I", native_display_numAlphaLevels},
        {"javax/microedition/lcdui/Display", "vibrate", "(I)Z", native_display_vibrate},
        {"javax/microedition/lcdui/Display", "flashBacklight", "(I)Z", native_display_flashBacklight},
        /* Canvas/Displayable methods */
        {"javax/microedition/lcdui/Canvas", "getWidth", "()I", native_display_getWidth},
        {"javax/microedition/lcdui/Canvas", "getHeight", "()I", native_display_getHeight},
        {"javax/microedition/lcdui/Canvas", "getGameAction", "(I)I", native_canvas_getGameAction},
        {"javax/microedition/lcdui/Canvas", "getKeyCode", "(I)I", native_canvas_getKeyCode},
        {"javax/microedition/lcdui/Canvas", "getKeyName", "(I)Ljava/lang/String;", native_canvas_getKeyName},
        {"javax/microedition/lcdui/Canvas", "hasPointerEvents", "()Z", native_canvas_hasPointerEvents},
        {"javax/microedition/lcdui/Canvas", "hasPointerMotionEvents", "()Z", native_canvas_hasPointerMotionEvents},
        {"javax/microedition/lcdui/Canvas", "hasRepeatEvents", "()Z", native_canvas_hasRepeatEvents},
        {"javax/microedition/lcdui/Canvas", "isDoubleBuffered", "()Z", native_canvas_isDoubleBuffered},
        {"javax/microedition/lcdui/Canvas", "repaint", "()V", native_canvas_repaint},
        {"javax/microedition/lcdui/Canvas", "repaint", "(IIII)V", native_canvas_repaint_region},
        {"javax/microedition/lcdui/Canvas", "serviceRepaints", "()V", native_canvas_serviceRepaints},
        {"javax/microedition/lcdui/Displayable", "getWidth", "()I", native_display_getWidth},
        {"javax/microedition/lcdui/Displayable", "getHeight", "()I", native_display_getHeight},
        {"javax/microedition/lcdui/Displayable", "repaint", "()V", native_canvas_repaint},
        {"javax/microedition/lcdui/Displayable", "repaint", "(IIII)V", native_canvas_repaint_region},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

void init_javax_microedition_lcdui_game_gamecanvas(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* GameCanvas */
        {"javax/microedition/lcdui/game/GameCanvas", "getKeyStates", "()I", native_gamecanvas_getKeyStates},
        {"javax/microedition/lcdui/game/GameCanvas", "suppressKeyEvents", "(Z)V", native_gamecanvas_suppressKeyEvents},
        {"javax/microedition/lcdui/game/GameCanvas", "getGraphics", "()Ljavax/microedition/lcdui/Graphics;", native_gamecanvas_getGraphics},
        {"javax/microedition/lcdui/game/GameCanvas", "flushGraphics", "()V", native_gamecanvas_flushGraphics},
        {"javax/microedition/lcdui/game/GameCanvas", "flushGraphics", "(IIII)V", native_gamecanvas_flushGraphicsRegion},
        
        /* Sprite constructors */
        {"javax/microedition/lcdui/game/Sprite", "<init>", "(Ljavax/microedition/lcdui/Image;)V", native_sprite_init_image},
        {"javax/microedition/lcdui/game/Sprite", "<init>", "(Ljavax/microedition/lcdui/Image;II)V", native_sprite_init_frames},
        {"javax/microedition/lcdui/game/Sprite", "<init>", "(Ljavax/microedition/lcdui/game/Sprite;)V", native_sprite_init_copy},
        
        /* Sprite methods */
        {"javax/microedition/lcdui/game/Sprite", "setPosition", "(II)V", native_sprite_setPosition},
        {"javax/microedition/lcdui/game/Sprite", "move", "(II)V", native_sprite_move},
        {"javax/microedition/lcdui/game/Sprite", "paint", "(Ljavax/microedition/lcdui/Graphics;)V", native_sprite_paint},
        {"javax/microedition/lcdui/game/Sprite", "getX", "()I", native_sprite_getX},
        {"javax/microedition/lcdui/game/Sprite", "getY", "()I", native_sprite_getY},
        {"javax/microedition/lcdui/game/Sprite", "getWidth", "()I", native_sprite_getWidth},
        {"javax/microedition/lcdui/game/Sprite", "getHeight", "()I", native_sprite_getHeight},
        {"javax/microedition/lcdui/game/Sprite", "setVisible", "(Z)V", native_sprite_setVisible},
        {"javax/microedition/lcdui/game/Sprite", "isVisible", "()Z", native_sprite_isVisible},
        {"javax/microedition/lcdui/game/Sprite", "setFrame", "(I)V", native_sprite_setFrame},
        {"javax/microedition/lcdui/game/Sprite", "getFrame", "()I", native_sprite_getFrame},
        /* CRITICAL: Sprite collision and transform methods */
        {"javax/microedition/lcdui/game/Sprite", "setTransform", "(I)V", native_sprite_setTransform},
        {"javax/microedition/lcdui/game/Sprite", "getTransform", "()I", native_sprite_getTransform},
        {"javax/microedition/lcdui/game/Sprite", "collidesWith", "(Ljavax/microedition/lcdui/game/Sprite;Z)Z", native_sprite_collidesWith_sprite},
        {"javax/microedition/lcdui/game/Sprite", "collidesWith", "(Ljavax/microedition/lcdui/game/TiledLayer;Z)Z", native_sprite_collidesWith_tiledlayer},
        {"javax/microedition/lcdui/game/Sprite", "collidesWith", "(Ljavax/microedition/lcdui/Image;IIZ)Z", native_sprite_collidesWith_image},
        {"javax/microedition/lcdui/game/Sprite", "defineCollisionRectangle", "(IIII)V", native_sprite_defineCollisionRectangle},
        {"javax/microedition/lcdui/game/Sprite", "setFrameSequence", "([I)V", native_sprite_setFrameSequence},
        {"javax/microedition/lcdui/game/Sprite", "nextFrame", "()V", native_sprite_nextFrame},
        {"javax/microedition/lcdui/game/Sprite", "prevFrame", "()V", native_sprite_prevFrame},
        {"javax/microedition/lcdui/game/Sprite", "getRawFrameCount", "()I", native_sprite_getRawFrameCount},
        
        /* Layer methods (inherited by Sprite and TiledLayer) */
        {"javax/microedition/lcdui/game/Layer", "getX", "()I", native_layer_getX},
        {"javax/microedition/lcdui/game/Layer", "getY", "()I", native_layer_getY},
        {"javax/microedition/lcdui/game/Layer", "getWidth", "()I", native_layer_getWidth},
        {"javax/microedition/lcdui/game/Layer", "getHeight", "()I", native_layer_getHeight},
        {"javax/microedition/lcdui/game/Layer", "setPosition", "(II)V", native_layer_setPosition},
        {"javax/microedition/lcdui/game/Layer", "move", "(II)V", native_layer_move},
        {"javax/microedition/lcdui/game/Layer", "setVisible", "(Z)V", native_layer_setVisible},
        {"javax/microedition/lcdui/game/Layer", "isVisible", "()Z", native_layer_isVisible},
        
        /* LayerManager */
        {"javax/microedition/lcdui/game/LayerManager", "<init>", "()V", native_layermanager_init},
        {"javax/microedition/lcdui/game/LayerManager", "append", "(Ljavax/microedition/lcdui/game/Layer;)I", native_layermanager_append},
        {"javax/microedition/lcdui/game/LayerManager", "insert", "(Ljavax/microedition/lcdui/game/Layer;I)V", native_layermanager_insert},
        {"javax/microedition/lcdui/game/LayerManager", "remove", "(Ljavax/microedition/lcdui/game/Layer;)V", native_layermanager_remove},
        {"javax/microedition/lcdui/game/LayerManager", "getLayerAt", "(I)Ljavax/microedition/lcdui/game/Layer;", native_layermanager_getLayerAt},
        {"javax/microedition/lcdui/game/LayerManager", "getSize", "()I", native_layermanager_getSize},
        {"javax/microedition/lcdui/game/LayerManager", "paint", "(Ljavax/microedition/lcdui/Graphics;II)V", native_layermanager_paint},
        {"javax/microedition/lcdui/game/LayerManager", "setViewWindow", "(IIII)V", native_layermanager_setViewWindow},
        
        /* TiledLayer */
        {"javax/microedition/lcdui/game/TiledLayer", "<init>", "(IILjavax/microedition/lcdui/Image;II)V", native_tiledlayer_init},
        {"javax/microedition/lcdui/game/TiledLayer", "setCell", "(III)V", native_tiledlayer_setCell},
        {"javax/microedition/lcdui/game/TiledLayer", "getCell", "(II)I", native_tiledlayer_getCell},
        {"javax/microedition/lcdui/game/TiledLayer", "fillCells", "(IIIII)V", native_tiledlayer_fillCells},
        {"javax/microedition/lcdui/game/TiledLayer", "createAnimatedTile", "(I)I", native_tiledlayer_createAnimatedTile},
        {"javax/microedition/lcdui/game/TiledLayer", "setAnimatedTile", "(II)V", native_tiledlayer_setAnimatedTile},
        {"javax/microedition/lcdui/game/TiledLayer", "getAnimatedTile", "(I)I", native_tiledlayer_getAnimatedTile},
        {"javax/microedition/lcdui/game/TiledLayer", "paint", "(Ljavax/microedition/lcdui/Graphics;)V", native_tiledlayer_paint},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

void init_javax_microedition_lcdui_image(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/lcdui/Image", "createImage", "(II)Ljavax/microedition/lcdui/Image;", native_image_createImage},
        {"javax/microedition/lcdui/Image", "createImage", "(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;", native_image_createImage_from_string},
        {"javax/microedition/lcdui/Image", "createImage", "([BII)Ljavax/microedition/lcdui/Image;", native_image_createImage_from_bytes},
        /* CRITICAL: createImage with transform and from Image source */
        {"javax/microedition/lcdui/Image", "createImage", "(Ljavax/microedition/lcdui/Image;IIIII)Ljavax/microedition/lcdui/Image;", native_image_createImage_region},
        {"javax/microedition/lcdui/Image", "createImage", "(Ljavax/microedition/lcdui/Image;)Ljavax/microedition/lcdui/Image;", native_image_createImage_copy},
        {"javax/microedition/lcdui/Image", "createImage", "(Ljava/io/InputStream;)Ljavax/microedition/lcdui/Image;", native_image_createImage_stream},
        {"javax/microedition/lcdui/Image", "createRGBImage", "([IIIZ)Ljavax/microedition/lcdui/Image;", native_image_createRGBImage},
        {"javax/microedition/lcdui/Image", "getWidth", "()I", native_image_getWidth},
        {"javax/microedition/lcdui/Image", "getHeight", "()I", native_image_getHeight},
        {"javax/microedition/lcdui/Image", "isMutable", "()Z", native_image_isMutable},
        {"javax/microedition/lcdui/Image", "getRGB", "([IIIIII)V", native_image_getRGB},
        {"javax/microedition/lcdui/Image", "getGraphics", "()Ljavax/microedition/lcdui/Graphics;", native_image_getGraphics},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

void init_javax_microedition_lcdui_graphics(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/lcdui/Graphics", "setColor", "(I)V", native_graphics_setColor},
        {"javax/microedition/lcdui/Graphics", "setColor", "(III)V", native_graphics_setColorRGB},
        {"javax/microedition/lcdui/Graphics", "getColor", "()I", native_graphics_getColor},
        {"javax/microedition/lcdui/Graphics", "setFont", "(Ljavax/microedition/lcdui/Font;)V", native_graphics_setFont},
        {"javax/microedition/lcdui/Graphics", "drawLine", "(IIII)V", native_graphics_drawLine},
        {"javax/microedition/lcdui/Graphics", "fillRect", "(IIII)V", native_graphics_fillRect},
        {"javax/microedition/lcdui/Graphics", "drawRect", "(IIII)V", native_graphics_drawRect},
        {"javax/microedition/lcdui/Graphics", "fillRoundRect", "(IIIIII)V", native_graphics_fillRoundRect},
        {"javax/microedition/lcdui/Graphics", "drawRoundRect", "(IIIIII)V", native_graphics_drawRoundRect},
        {"javax/microedition/lcdui/Graphics", "fillArc", "(IIIIII)V", native_graphics_fillArc},
        {"javax/microedition/lcdui/Graphics", "drawArc", "(IIIIII)V", native_graphics_drawArc},
        {"javax/microedition/lcdui/Graphics", "drawString", "(Ljava/lang/String;III)V", native_graphics_drawString},
        {"javax/microedition/lcdui/Graphics", "drawImage", "(Ljavax/microedition/lcdui/Image;III)V", native_graphics_drawImage},
        /* CRITICAL: drawRegion - used by most games for sprite rendering */
        {"javax/microedition/lcdui/Graphics", "drawRegion", "(Ljavax/microedition/lcdui/Image;IIIIIIII)V", native_graphics_drawRegion},
        /* Additional drawing methods */
        {"javax/microedition/lcdui/Graphics", "drawImage", "(Ljavax/microedition/lcdui/Image;IIII)V", native_graphics_drawImage_anchor},
        {"javax/microedition/lcdui/Graphics", "copyArea", "(IIIIIII)V", native_graphics_copyArea},
        /* Clip methods */
        {"javax/microedition/lcdui/Graphics", "setClip", "(IIII)V", native_graphics_setClip},
        {"javax/microedition/lcdui/Graphics", "clipRect", "(IIII)V", native_graphics_clipRect},
        {"javax/microedition/lcdui/Graphics", "getClipX", "()I", native_graphics_getClipX},
        {"javax/microedition/lcdui/Graphics", "getClipY", "()I", native_graphics_getClipY},
        {"javax/microedition/lcdui/Graphics", "getClipWidth", "()I", native_graphics_getClipWidth},
        {"javax/microedition/lcdui/Graphics", "getClipHeight", "()I", native_graphics_getClipHeight},
        /* Translate methods */
        {"javax/microedition/lcdui/Graphics", "translate", "(II)V", native_graphics_translate},
        {"javax/microedition/lcdui/Graphics", "getTranslateX", "()I", native_graphics_getTranslateX},
        {"javax/microedition/lcdui/Graphics", "getTranslateY", "()I", native_graphics_getTranslateY},
        /* Stroke style */
        {"javax/microedition/lcdui/Graphics", "setStrokeStyle", "(I)V", native_graphics_setStrokeStyle},
        {"javax/microedition/lcdui/Graphics", "getStrokeStyle", "()I", native_graphics_getStrokeStyle},
        /* Gray scale */
        {"javax/microedition/lcdui/Graphics", "setGrayScale", "(I)V", native_graphics_setGrayScale},
        {"javax/microedition/lcdui/Graphics", "getGrayScale", "()I", native_graphics_getGrayScale},
        /* Display color */
        {"javax/microedition/lcdui/Graphics", "getDisplayColor", "(I)I", native_graphics_getDisplayColor},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

void init_javax_microedition_lcdui_font(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/lcdui/Font", "getDefaultFont", "()Ljavax/microedition/lcdui/Font;", native_font_getDefaultFont},
        {"javax/microedition/lcdui/Font", "getFont", "(III)Ljavax/microedition/lcdui/Font;", native_font_getFont},
        {"javax/microedition/lcdui/Font", "stringWidth", "(Ljava/lang/String;)I", native_font_stringWidth},
        {"javax/microedition/lcdui/Font", "getHeight", "()I", native_font_height},
        /* Additional Font methods */
        {"javax/microedition/lcdui/Font", "charWidth", "(C)I", native_font_charWidth},
        {"javax/microedition/lcdui/Font", "charsWidth", "([CII)I", native_font_charsWidth},
        {"javax/microedition/lcdui/Font", "substringWidth", "(Ljava/lang/String;II)I", native_font_substringWidth},
        {"javax/microedition/lcdui/Font", "getBaselinePosition", "()I", native_font_getBaselinePosition},
        {"javax/microedition/lcdui/Font", "getFace", "()I", native_font_getFace},
        {"javax/microedition/lcdui/Font", "getStyle", "()I", native_font_getStyle},
        {"javax/microedition/lcdui/Font", "getSize", "()I", native_font_getSize},
        {"javax/microedition/lcdui/Font", "isBold", "()Z", native_font_isBold},
        {"javax/microedition/lcdui/Font", "isItalic", "()Z", native_font_isItalic},
        {"javax/microedition/lcdui/Font", "isUnderlined", "()Z", native_font_isUnderlined},
        {"javax/microedition/lcdui/Font", "isPlain", "()Z", native_font_isPlain},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}

