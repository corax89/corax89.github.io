/*
 * J2ME Emulator - MIDP2 RMS (Record Management System)
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup - only on POSIX systems */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "midp.h"
#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"  /* For DESC_OBJECT */

/* Maximum record stores */
#define MAX_RECORD_STORES 64
#define MAX_RECORDS_PER_STORE 1024

/* Record structure */
typedef struct {
    int id;
    uint8_t* data;
    int size;
    bool valid;
} Record;

/* Record store structure */
typedef struct {
    char* name;
    Record records[MAX_RECORDS_PER_STORE];
    int next_id;
    bool open;
    int ref_count;
} NativeRecordStore;

/* Record stores */
static NativeRecordStore record_stores[MAX_RECORD_STORES];
static int record_store_count = 0;
static bool rms_initialized = false;

/* Initialize RMS */
static void rms_init(void) {
    if (rms_initialized) return;
    
    memset(record_stores, 0, sizeof(record_stores));
    rms_initialized = true;
}

/* Open/create record store - returns native handle */
static int rms_open(const char* name, bool create_if_necessary) {
    rms_init();
    
    /* Find existing store */
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && strcmp(record_stores[i].name, name) == 0) {
            record_stores[i].ref_count++;
            record_stores[i].open = true;
            return i;
        }
    }
    
    if (!create_if_necessary) {
        return -1;  /* RecordStoreNotFoundException */
    }
    
    /* Create new store */
    if (record_store_count >= MAX_RECORD_STORES) {
        return -2;  /* Out of memory */
    }
    
    int handle = record_store_count++;
    NativeRecordStore* store = &record_stores[handle];
    
    store->name = strdup(name);
    store->next_id = 1;
    store->open = true;
    store->ref_count = 1;
    
    memset(store->records, 0, sizeof(store->records));
    
    return handle;
}

/* Get native record store from Java RecordStore object */
static NativeRecordStore* get_native_store(JavaObject* rs_obj) {
    if (!rs_obj) return NULL;
    
    JavaClass* clazz = rs_obj->header.clazz;
    if (!clazz || !clazz->fields) return NULL;
    
    /* Find nativeHandle field */
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "nativeHandle") == 0) {
            int handle = rs_obj->fields[i].i;
            if (handle >= 0 && handle < record_store_count) {
                return &record_stores[handle];
            }
            return NULL;
        }
    }
    
    return NULL;
}

/*
 * Native methods for RecordStore
 */

/* RecordStore.openRecordStore(String, boolean) - returns RecordStore object */
static JavaValue native_rms_openRecordStore(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* name_str = (JavaString*)args[0].ref;
    jboolean create = args[1].i;
    
    if (!name_str) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    const char* name = string_utf8(jvm, name_str);
    fprintf(stderr, "[RMS] openRecordStore: %s, create=%d\n", name, create);
    
    int handle = rms_open(name, create != 0);
    
    if (handle < 0) {
        /* TODO: Throw RecordStoreNotFoundException or RecordStoreFullException */
        fprintf(stderr, "[RMS] Failed to open store: %s (handle=%d)\n", name, handle);
        return NATIVE_RETURN_NULL();
    }
    
    fprintf(stderr, "[RMS] Opened store '%s' with handle %d\n", name, handle);
    
    /* Create RecordStore Java object */
    JavaClass* rs_class = jvm_load_class(jvm, "javax/microedition/rms/RecordStore");
    if (!rs_class) {
        fprintf(stderr, "[RMS] Failed to load RecordStore class\n");
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* rs_obj = jvm_new_object(jvm, rs_class);
    if (!rs_obj) {
        fprintf(stderr, "[RMS] Failed to create RecordStore object\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store native handle in nativeHandle field */
    if (rs_class->fields) {
        for (int i = 0; i < rs_class->fields_count; i++) {
            if (rs_class->fields[i].name && strcmp(rs_class->fields[i].name, "nativeHandle") == 0) {
                rs_obj->fields[i].i = handle;
                fprintf(stderr, "[RMS] Set nativeHandle=%d in field %d\n", handle, i);
                break;
            }
        }
    }
    
    fprintf(stderr, "[RMS] Returning RecordStore object: %p\n", (void*)rs_obj);
    return NATIVE_RETURN_OBJECT(rs_obj);
}

/* RecordStore.closeRecordStore() */
static JavaValue native_rms_closeRecordStore(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (store) {
        store->ref_count--;
        if (store->ref_count <= 0) {
            store->open = false;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.addRecord(byte[], int, int) - returns record ID */
static JavaValue native_rms_addRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        fprintf(stderr, "[RMS] addRecord: invalid store\n");
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!data) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Find free slot */
    int id = -1;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (!store->records[i].valid) {
            id = i;
            break;
        }
    }
    
    if (id < 0) {
        fprintf(stderr, "[RMS] addRecord: no space\n");
        return NATIVE_RETURN_INT(-1);
    }
    
    store->records[id].id = id;
    store->records[id].size = length;
    store->records[id].data = (uint8_t*)malloc(length);
    store->records[id].valid = true;
    
    memcpy(store->records[id].data, (uint8_t*)array_data(data) + offset, length);
    
    if (id >= store->next_id) {
        store->next_id = id + 1;
    }
    
    fprintf(stderr, "[RMS] addRecord: id=%d, size=%d\n", id, length);
    return NATIVE_RETURN_INT(id);
}

/* RecordStore.getRecord(int) - returns byte[] */
static JavaValue native_rms_getRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    fprintf(stderr, "[RMS] getRecord: record_id=%d\n", record_id);
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        fprintf(stderr, "[RMS] getRecord: invalid store\n");
        return NATIVE_RETURN_NULL();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        fprintf(stderr, "[RMS] getRecord: invalid record_id=%d\n", record_id);
        return NATIVE_RETURN_NULL();
    }
    
    if (!store->records[record_id].valid) {
        fprintf(stderr, "[RMS] getRecord: record %d not valid\n", record_id);
        return NATIVE_RETURN_NULL();
    }
    
    int length = store->records[record_id].size;
    uint8_t* data = store->records[record_id].data;
    
    /* Create byte array */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, (jsize)length);
    if (!byte_array) {
        fprintf(stderr, "[RMS] getRecord: failed to allocate byte array\n");
        return NATIVE_RETURN_NULL();
    }
    
    memcpy(array_data(byte_array), data, length);
    
    fprintf(stderr, "[RMS] getRecord: returning %d bytes\n", length);
    return NATIVE_RETURN_OBJECT(byte_array);
}

/* RecordStore.getRecord(int, byte[], int) - returns size */
static JavaValue native_rms_getRecord_array(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    JavaArray* dest = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !dest) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_INT(-1);
    }
    
    int length = store->records[record_id].size;
    uint8_t* data = store->records[record_id].data;
    
    if (offset + length > (jint)dest->length) {
        return NATIVE_RETURN_INT(-1);
    }
    
    memcpy((uint8_t*)array_data(dest) + offset, data, length);
    
    return NATIVE_RETURN_INT(length);
}

/* RecordStore.getRecordSize(int) - returns size */
static JavaValue native_rms_getRecordSize(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(store->records[record_id].size);
}

/* RecordStore.setRecord(int, byte[], int, int) */
static JavaValue native_rms_setRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    JavaArray* data = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    jint length = args[4].i;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !data) {
        return NATIVE_RETURN_VOID();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_VOID();
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_VOID();
    }
    
    free(store->records[record_id].data);
    store->records[record_id].size = length;
    store->records[record_id].data = (uint8_t*)malloc(length);
    
    memcpy(store->records[record_id].data, (uint8_t*)array_data(data) + offset, length);
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.deleteRecord(int) */
static JavaValue native_rms_deleteRecord(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_VOID();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_VOID();
    }
    
    free(store->records[record_id].data);
    memset(&store->records[record_id], 0, sizeof(Record));
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.getNumRecords() */
static JavaValue native_rms_getNumRecords(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(0);
    }
    
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    return NATIVE_RETURN_INT(count);
}

/* RecordStore.enumerateRecords - returns RecordEnumeration */
static JavaValue native_rms_enumerateRecords(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    /* Filter filter = args[1], boolean keepUpdated = args[2] */
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Count valid records */
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    if (count == 0) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create int array with record IDs */
    JavaArray* ids = jvm_new_array(jvm, T_INT, count);
    if (!ids) {
        return NATIVE_RETURN_NULL();
    }
    
    jint* ids_data = (jint*)array_data(ids);
    int idx = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE && idx < count; i++) {
        if (store->records[i].valid) {
            ids_data[idx++] = i;
        }
    }
    
    /* Return as int array (simplified - should be RecordEnumeration object) */
    return NATIVE_RETURN_OBJECT(ids);
}

/* RecordStore.deleteRecordStore(String) - static method */
static JavaValue native_rms_deleteRecordStore(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* name_str = (JavaString*)args[0].ref;
    
    if (!name_str) {
        return NATIVE_RETURN_VOID();
    }
    
    const char* name = string_utf8(jvm, name_str);
    rms_init();
    
    /* Find store */
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && strcmp(record_stores[i].name, name) == 0) {
            /* Free all records */
            for (int j = 1; j < MAX_RECORDS_PER_STORE; j++) {
                free(record_stores[i].records[j].data);
            }
            
            free(record_stores[i].name);
            
            /* Remove from array */
            if (i < record_store_count - 1) {
                memmove(&record_stores[i], &record_stores[i + 1],
                        (record_store_count - i - 1) * sizeof(NativeRecordStore));
            }
            
            record_store_count--;
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.listRecordStores() - returns String[] */
static JavaValue native_rms_listRecordStores(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    rms_init();
    
    if (record_store_count == 0) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create String array */
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, record_store_count);
    if (!array) {
        return NATIVE_RETURN_NULL();
    }
    
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name) {
            JavaString* str = jvm_new_string(jvm, record_stores[i].name);
            array_set_ref(array, i, str);
        }
    }
    
    return NATIVE_RETURN_OBJECT(array);
}

/* RecordStore.getNextRecordID() */
static JavaValue native_rms_getNextRecordID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(store->next_id);
}

void init_javax_microedition_rms(JVM* jvm) {
    /* RecordStore stub class should already have nativeHandle field from stubs.c */
    
    NativeMethodEntry methods[] = {
        /* Static methods */
        {"javax/microedition/rms/RecordStore", "openRecordStore", 
         "(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;", native_rms_openRecordStore},
        {"javax/microedition/rms/RecordStore", "deleteRecordStore", 
         "(Ljava/lang/String;)V", native_rms_deleteRecordStore},
        {"javax/microedition/rms/RecordStore", "listRecordStores", 
         "()[Ljava/lang/String;", native_rms_listRecordStores},
        
        /* Instance methods */
        {"javax/microedition/rms/RecordStore", "closeRecordStore", 
         "()V", native_rms_closeRecordStore},
        {"javax/microedition/rms/RecordStore", "addRecord", 
         "([BII)I", native_rms_addRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", 
         "(I)[B", native_rms_getRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", 
         "(I[BI)I", native_rms_getRecord_array},
        {"javax/microedition/rms/RecordStore", "getRecordSize", 
         "(I)I", native_rms_getRecordSize},
        {"javax/microedition/rms/RecordStore", "setRecord", 
         "(I[BII)V", native_rms_setRecord},
        {"javax/microedition/rms/RecordStore", "deleteRecord", 
         "(I)V", native_rms_deleteRecord},
        {"javax/microedition/rms/RecordStore", "getNumRecords", 
         "()I", native_rms_getNumRecords},
        {"javax/microedition/rms/RecordStore", "enumerateRecords", 
         "(Ljavax/microedition/rms/RecordFilter;Ljavax/microedition/rms/RecordComparator;Z)Ljavax/microedition/rms/RecordEnumeration;",
         native_rms_enumerateRecords},
        {"javax/microedition/rms/RecordStore", "getNextRecordID", 
         "()I", native_rms_getNextRecordID},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    
    fprintf(stderr, "[RMS] Registered %zu native methods\n", sizeof(methods) / sizeof(methods[0]));
}
