/*
 * J2ME Emulator - MIDP2 RMS (Record Management System)
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

#include "midp.h"
#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"

/* Maximum record stores */
#define MAX_RECORD_STORES 64
#define MAX_RECORDS_PER_STORE 1024
#define MAX_RECORD_SIZE 65536  /* 64KB max per record */

/* Record structure */
typedef struct {
    int id;
    uint8_t* data;
    int size;
    bool valid;
} Record;

/* Record store structure */
typedef struct {
    char* name;
    Record records[MAX_RECORDS_PER_STORE];
    int next_id;
    bool open;
    int ref_count;
} NativeRecordStore;

/* Record stores */
static NativeRecordStore record_stores[MAX_RECORD_STORES];
static int record_store_count = 0;
static bool rms_initialized = false;

/* Initialize RMS */
static void rms_init(void) {
    if (rms_initialized) return;
    
    memset(record_stores, 0, sizeof(record_stores));
    rms_initialized = true;
}

/* Open/create record store - returns native handle */
static int rms_open(const char* name, bool create_if_necessary) {
    rms_init();
    
    if (!name) return -1;
    
    /* Find existing store */
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && strcmp(record_stores[i].name, name) == 0) {
            record_stores[i].ref_count++;
            record_stores[i].open = true;
            fprintf(stderr, "[RMS] Reopened existing store '%s' (handle=%d, refs=%d)\n", 
                    name, i, record_stores[i].ref_count);
            return i;
        }
    }
    
    if (!create_if_necessary) {
        fprintf(stderr, "[RMS] Store '%s' not found and create=false\n", name);
        return -1;  /* RecordStoreNotFoundException */
    }
    
    /* Create new store */
    if (record_store_count >= MAX_RECORD_STORES) {
        fprintf(stderr, "[RMS] Max stores reached (%d)\n", MAX_RECORD_STORES);
        return -2;  /* RecordStoreFullException */
    }
    
    int handle = record_store_count;
    NativeRecordStore* store = &record_stores[handle];
    
    store->name = strdup(name);
    if (!store->name) {
        fprintf(stderr, "[RMS] Out of memory for store name\n");
        return -2;
    }
    
    store->next_id = 1;
    store->open = true;
    store->ref_count = 1;
    
    memset(store->records, 0, sizeof(store->records));
    
    record_store_count++;
    fprintf(stderr, "[RMS] Created new store '%s' with handle %d\n", name, handle);
    
    return handle;
}

/* Get native record store from Java RecordStore object */
static NativeRecordStore* get_native_store(JavaObject* rs_obj) {
    if (!rs_obj) {
        fprintf(stderr, "[RMS] get_native_store: NULL object\n");
        return NULL;
    }
    
    /* Проверка валидности объекта */
    if (!rs_obj->header.clazz) {
        fprintf(stderr, "[RMS] get_native_store: Object has NULL class!\n");
        return NULL;
    }
    
    JavaClass* clazz = rs_obj->header.clazz;
    
    /* Find nativeHandle field */
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "nativeHandle") == 0) {
            int handle = rs_obj->fields[i].i;
            
            /* Проверка валидности handle */
            if (handle >= 0 && handle < record_store_count) {
                NativeRecordStore* store = &record_stores[handle];
                if (store->open) {
                    return store;
                } else {
                    fprintf(stderr, "[RMS] get_native_store: store %d is closed\n", handle);
                    return NULL;
                }
            } else {
                fprintf(stderr, "[RMS] get_native_store: invalid handle %d (max=%d)\n", 
                        handle, record_store_count);
                return NULL;
            }
        }
    }
    
    fprintf(stderr, "[RMS] get_native_store: nativeHandle field not found in class %s\n",
            clazz->class_name ? clazz->class_name : "?");
    return NULL;
}

/*
 * Native methods for RecordStore
 */

/* RecordStore.openRecordStore(String, boolean) - returns RecordStore object */
static JavaValue native_rms_openRecordStore(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)arg_count;
    
    /* args[0] - this (null for static), args[1] - name, args[2] - create */
    JavaString* name_str = (JavaString*)args[1].ref;
    jboolean create = args[2].i;
    
    if (!name_str) {
        fprintf(stderr, "[RMS] openRecordStore: name is NULL\n");
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    const char* name = string_utf8(jvm, name_str);
    fprintf(stderr, "[RMS] openRecordStore: '%s', create=%d\n", name, create);
    
    int handle = rms_open(name, create != 0);
    
    if (handle < 0) {
        /* Бросаем соответствующее исключение */
        if (handle == -1) {
            jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotFoundException", name);
        } else {
            jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreFullException", NULL);
        }
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    /* Load RecordStore class */
    JavaClass* rs_class = jvm_load_class(jvm, "javax/microedition/rms/RecordStore");
    if (!rs_class) {
        fprintf(stderr, "[RMS] Failed to load RecordStore class\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create RecordStore Java object */
    JavaObject* rs_obj = jvm_new_object(jvm, rs_class);
    if (!rs_obj) {
        fprintf(stderr, "[RMS] Failed to create RecordStore object\n");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store native handle in nativeHandle field */
    bool found = false;
    for (int i = 0; i < rs_class->fields_count; i++) {
        if (rs_class->fields[i].name && strcmp(rs_class->fields[i].name, "nativeHandle") == 0) {
            rs_obj->fields[i].i = handle;
            fprintf(stderr, "[RMS] Set nativeHandle=%d in field %d\n", handle, i);
            found = true;
            break;
        }
    }
    
    if (!found) {
        fprintf(stderr, "[RMS] WARNING: nativeHandle field not found in RecordStore class\n");
    }
    
    fprintf(stderr, "[RMS] Returning RecordStore object: %p\n", (void*)rs_obj);
    return NATIVE_RETURN_OBJECT(rs_obj);
}

/* RecordStore.closeRecordStore() */
static JavaValue native_rms_closeRecordStore(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (store) {
        store->ref_count--;
        fprintf(stderr, "[RMS] closeRecordStore: refs now %d\n", store->ref_count);
        
        if (store->ref_count <= 0) {
            store->open = false;
            fprintf(stderr, "[RMS] Store closed\n");
        }
    } else {
        fprintf(stderr, "[RMS] closeRecordStore: invalid store\n");
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.addRecord(byte[], int, int) - returns record ID */
static JavaValue native_rms_addRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    fprintf(stderr, "[RMS] addRecord: offset=%d, length=%d\n", offset, length);
    
    if (!rs_obj || !data) {
        fprintf(stderr, "[RMS] addRecord: NULL parameter\n");
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Проверка длины */
    if (length <= 0) {
        fprintf(stderr, "[RMS] addRecord: invalid length %d\n", length);
        return NATIVE_RETURN_INT(-1);
    }
    
    if (length > MAX_RECORD_SIZE) {
        fprintf(stderr, "[RMS] addRecord: record too large (%d > %d)\n", 
                length, MAX_RECORD_SIZE);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Проверка границ массива */
    if (offset < 0 || length < 0 || offset + length > (jint)data->length) {
        fprintf(stderr, "[RMS] addRecord: array bounds error: offset=%d, length=%d, array_len=%d\n",
                offset, length, data->length);
        native_throw_aioobe(jvm, thread, offset);
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        fprintf(stderr, "[RMS] addRecord: invalid store\n");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->open) {
        fprintf(stderr, "[RMS] addRecord: store is closed\n");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Find free slot */
    int id = -1;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (!store->records[i].valid) {
            id = i;
            break;
        }
    }
    
    if (id < 0) {
        fprintf(stderr, "[RMS] addRecord: no free slots\n");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreFullException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Allocate and copy data */
    uint8_t* record_data = (uint8_t*)malloc(length);
    if (!record_data) {
        fprintf(stderr, "[RMS] addRecord: out of memory\n");
        jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    uint8_t* src_data = (uint8_t*)array_data(data);
    memcpy(record_data, src_data + offset, length);
    
    /* Store record */
    store->records[id].id = id;
    store->records[id].data = record_data;
    store->records[id].size = length;
    store->records[id].valid = true;
    
    /* Update next_id if needed */
    if (id >= store->next_id) {
        store->next_id = id + 1;
    }
    
    fprintf(stderr, "[RMS] addRecord: SUCCESS - id=%d, size=%d, next_id=%d\n", 
            id, length, store->next_id);
    
    return NATIVE_RETURN_INT(id);
}

/* RecordStore.getRecord(int) - returns byte[] */
static JavaValue native_rms_getRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    fprintf(stderr, "[RMS] getRecord: record_id=%d\n", record_id);
    
    if (!rs_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        fprintf(stderr, "[RMS] getRecord: invalid store\n");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    if (!store->open) {
        fprintf(stderr, "[RMS] getRecord: store is closed\n");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        fprintf(stderr, "[RMS] getRecord: invalid record_id=%d\n", record_id);
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    if (!store->records[record_id].valid) {
        fprintf(stderr, "[RMS] getRecord: record %d not found\n", record_id);
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    int length = store->records[record_id].size;
    uint8_t* data = store->records[record_id].data;
    
    /* Create byte array */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, (jsize)length);
    if (!byte_array) {
        fprintf(stderr, "[RMS] getRecord: failed to allocate byte array\n");
        jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    memcpy(array_data(byte_array), data, length);
    
    fprintf(stderr, "[RMS] getRecord: returning %d bytes\n", length);
    return NATIVE_RETURN_OBJECT(byte_array);
}

/* RecordStore.getRecord(int, byte[], int) - returns size */
static JavaValue native_rms_getRecord_array(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    JavaArray* dest = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    
    if (!rs_obj || !dest) {
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_INT(-1);
    }
    
    int length = store->records[record_id].size;
    
    if (offset < 0 || length > (jint)dest->length - offset) {
        return NATIVE_RETURN_INT(-1);
    }
    
    memcpy((uint8_t*)array_data(dest) + offset, store->records[record_id].data, length);
    
    return NATIVE_RETURN_INT(length);
}

/* RecordStore.getRecordSize(int) - returns size */
static JavaValue native_rms_getRecordSize(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(store->records[record_id].size);
}

/* RecordStore.setRecord(int, byte[], int, int) */
static JavaValue native_rms_setRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    JavaArray* data = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    jint length = args[4].i;
    
    if (!rs_obj || !data) {
        return NATIVE_RETURN_VOID();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_VOID();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_VOID();
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Check bounds */
    if (offset < 0 || length < 0 || offset + length > (jint)data->length) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Allocate new data */
    uint8_t* new_data = (uint8_t*)malloc(length);
    if (!new_data) {
        return NATIVE_RETURN_VOID();
    }
    
    memcpy(new_data, (uint8_t*)array_data(data) + offset, length);
    
    /* Replace old data */
    free(store->records[record_id].data);
    store->records[record_id].data = new_data;
    store->records[record_id].size = length;
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.deleteRecord(int) */
static JavaValue native_rms_deleteRecord(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    if (!rs_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_VOID();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_VOID();
    }
    
    if (store->records[record_id].valid) {
        free(store->records[record_id].data);
        memset(&store->records[record_id], 0, sizeof(Record));
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.getNumRecords() */
static JavaValue native_rms_getNumRecords(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(0);
    }
    
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    return NATIVE_RETURN_INT(count);
}

/* RecordStore.enumerateRecords - возвращает массив ID (упрощенно) */
static JavaValue native_rms_enumerateRecords(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Count valid records */
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    if (count == 0) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create int array with record IDs */
    JavaArray* ids = jvm_new_array(jvm, T_INT, count);
    if (!ids) {
        return NATIVE_RETURN_NULL();
    }
    
    jint* ids_data = (jint*)array_data(ids);
    int idx = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE && idx < count; i++) {
        if (store->records[i].valid) {
            ids_data[idx++] = i;
        }
    }
    
    return NATIVE_RETURN_OBJECT(ids);
}

/* RecordStore.deleteRecordStore(String) - static method */
static JavaValue native_rms_deleteRecordStore(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaString* name_str = (JavaString*)args[1].ref;  /* args[0] - this (null), args[1] - name */
    
    if (!name_str) {
        return NATIVE_RETURN_VOID();
    }
    
    const char* name = string_utf8(jvm, name_str);
    fprintf(stderr, "[RMS] deleteRecordStore: '%s'\n", name);
    
    rms_init();
    
    /* Find store */
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && strcmp(record_stores[i].name, name) == 0) {
            /* Free all records */
            for (int j = 1; j < MAX_RECORDS_PER_STORE; j++) {
                if (record_stores[i].records[j].valid) {
                    free(record_stores[i].records[j].data);
                }
            }
            
            free(record_stores[i].name);
            
            /* Remove from array */
            if (i < record_store_count - 1) {
                memmove(&record_stores[i], &record_stores[i + 1],
                        (record_store_count - i - 1) * sizeof(NativeRecordStore));
            }
            
            record_store_count--;
            fprintf(stderr, "[RMS] Store deleted\n");
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.listRecordStores() - returns String[] */
static JavaValue native_rms_listRecordStores(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)args; (void)arg_count;
    
    rms_init();
    
    if (record_store_count == 0) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create String array */
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, record_store_count);
    if (!array) {
        return NATIVE_RETURN_NULL();
    }
    
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && record_stores[i].open) {
            JavaString* str = jvm_new_string(jvm, record_stores[i].name);
            array_set_ref(array, i, str);
        }
    }
    
    return NATIVE_RETURN_OBJECT(array);
}

/* RecordStore.getNextRecordID() */
static JavaValue native_rms_getNextRecordID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(store->next_id);
}

/* RecordStore.getVersion() - возвращает версию (упрощенно) */
static JavaValue native_rms_getVersion(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Простая версия на основе количества записей */
    int version = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) version++;
    }
    
    return NATIVE_RETURN_INT(version);
}

/* RecordStore.getLastModified() - время последнего изменения */
static JavaValue native_rms_getLastModified(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_LONG(0);
    }
    
    jlong current_time;
    
#ifdef _WIN32
    /* Windows implementation - simple version using GetTickCount */
    current_time = (jlong)GetTickCount();
#else
    /* POSIX implementation */
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    current_time = (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
    
    return NATIVE_RETURN_LONG(current_time);
}

/* RecordStore.getSize() - возвращает размер данных */
static JavaValue native_rms_getSize(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(0);
    }
    
    int total = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) {
            total += store->records[i].size;
        }
    }
    
    return NATIVE_RETURN_INT(total);
}

/* RecordStore.getSizeAvailable() - доступное место */
static JavaValue native_rms_getSizeAvailable(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    
    /* Возвращаем большое число (нет ограничений) */
    return NATIVE_RETURN_INT(1024 * 1024);  /* 1MB */
}

/* RecordStore.getName() - имя хранилища */
static JavaValue native_rms_getName(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->name) {
        return NATIVE_RETURN_NULL();
    }
    
    return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, store->name));
}

void init_javax_microedition_rms(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Static methods */
        {"javax/microedition/rms/RecordStore", "openRecordStore", 
         "(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;", native_rms_openRecordStore},
        {"javax/microedition/rms/RecordStore", "deleteRecordStore", 
         "(Ljava/lang/String;)V", native_rms_deleteRecordStore},
        {"javax/microedition/rms/RecordStore", "listRecordStores", 
         "()[Ljava/lang/String;", native_rms_listRecordStores},
        
        /* Instance methods */
        {"javax/microedition/rms/RecordStore", "closeRecordStore", 
         "()V", native_rms_closeRecordStore},
        {"javax/microedition/rms/RecordStore", "addRecord", 
         "([BII)I", native_rms_addRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", 
         "(I)[B", native_rms_getRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", 
         "(I[BI)I", native_rms_getRecord_array},
        {"javax/microedition/rms/RecordStore", "getRecordSize", 
         "(I)I", native_rms_getRecordSize},
        {"javax/microedition/rms/RecordStore", "setRecord", 
         "(I[BII)V", native_rms_setRecord},
        {"javax/microedition/rms/RecordStore", "deleteRecord", 
         "(I)V", native_rms_deleteRecord},
        {"javax/microedition/rms/RecordStore", "getNumRecords", 
         "()I", native_rms_getNumRecords},
        {"javax/microedition/rms/RecordStore", "enumerateRecords", 
         "(Ljavax/microedition/rms/RecordFilter;Ljavax/microedition/rms/RecordComparator;Z)Ljavax/microedition/rms/RecordEnumeration;",
         native_rms_enumerateRecords},
        {"javax/microedition/rms/RecordStore", "getNextRecordID", 
         "()I", native_rms_getNextRecordID},
        {"javax/microedition/rms/RecordStore", "getVersion", 
         "()I", native_rms_getVersion},
        {"javax/microedition/rms/RecordStore", "getLastModified", 
         "()J", native_rms_getLastModified},
        {"javax/microedition/rms/RecordStore", "getSize", 
         "()I", native_rms_getSize},
        {"javax/microedition/rms/RecordStore", "getSizeAvailable", 
         "()I", native_rms_getSizeAvailable},
        {"javax/microedition/rms/RecordStore", "getName", 
         "()Ljava/lang/String;", native_rms_getName},
    };
    
    int count = sizeof(methods) / sizeof(methods[0]);
    native_register_methods(jvm, methods, count);
    
    fprintf(stderr, "[RMS] Registered %d native methods\n", count);
}