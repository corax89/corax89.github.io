/*
 * J2ME Emulator - MIDP2 RMS (Record Management System)
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup - only on POSIX systems */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "midp.h"
#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"  /* For DESC_OBJECT */

/* Maximum record stores */
#define MAX_RECORD_STORES 64
#define MAX_RECORDS_PER_STORE 1024

/* Record structure */
typedef struct {
    int id;
    uint8_t* data;
    int size;
    bool valid;
} Record;

/* Record store structure */
typedef struct {
    char* name;
    Record records[MAX_RECORDS_PER_STORE];
    int next_id;
    bool open;
    int ref_count;
} RecordStore;

/* Record stores */
static RecordStore record_stores[MAX_RECORD_STORES];
static int record_store_count = 0;
static bool rms_initialized = false;

/* Initialize RMS */
static void rms_init(void) {
    if (rms_initialized) return;
    
    /* TODO: Create RMS directory - platform-specific */
    /* Skipping for now to avoid cross-platform issues */
    
    memset(record_stores, 0, sizeof(record_stores));
    rms_initialized = true;
}

/* Open/create record store */
int midp_rms_open_record_store(const char* name, bool create_if_necessary) {
    rms_init();
    
    /* Find existing store */
    for (int i = 0; i < record_store_count; i++) {
        if (strcmp(record_stores[i].name, name) == 0) {
            record_stores[i].ref_count++;
            record_stores[i].open = true;
            return i;
        }
    }
    
    if (!create_if_necessary) {
        return -1;  /* RecordStoreNotFoundException */
    }
    
    /* Create new store */
    if (record_store_count >= MAX_RECORD_STORES) {
        return -2;  /* Out of memory */
    }
    
    int handle = record_store_count++;
    RecordStore* store = &record_stores[handle];
    
    store->name = strdup(name);
    store->next_id = 1;
    store->open = true;
    store->ref_count = 1;
    
    memset(store->records, 0, sizeof(store->records));
    
    /* TODO: Load existing data from disk - skipping for now */
    
    return handle;
}

/* Close record store */
void midp_rms_close_record_store(int handle) {
    if (handle < 0 || handle >= record_store_count) return;
    
    RecordStore* store = &record_stores[handle];
    store->ref_count--;
    
    if (store->ref_count <= 0) {
        /* TODO: Save to disk - skipping for now */
        store->open = false;
    }
}

/* Add record */
int midp_rms_add_record(int handle, const uint8_t* data, int offset, int length) {
    if (handle < 0 || handle >= record_store_count) return -1;
    
    RecordStore* store = &record_stores[handle];
    if (!store->open) return -1;
    
    /* Find free slot */
    int id = -1;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (!store->records[i].valid) {
            id = i;
            break;
        }
    }
    
    if (id < 0) return -1;  /* No space */
    
    store->records[id].id = id;
    store->records[id].size = length;
    store->records[id].data = (uint8_t*)malloc(length);
    store->records[id].valid = true;
    
    memcpy(store->records[id].data, data + offset, length);
    
    if (id >= store->next_id) {
        store->next_id = id + 1;
    }
    
    return id;
}

/* Set record */
void midp_rms_set_record(int handle, int record_id, const uint8_t* data, int offset, int length) {
    if (handle < 0 || handle >= record_store_count) return;
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) return;
    
    RecordStore* store = &record_stores[handle];
    if (!store->open) return;
    
    if (!store->records[record_id].valid) return;
    
    free(store->records[record_id].data);
    store->records[record_id].size = length;
    store->records[record_id].data = (uint8_t*)malloc(length);
    
    memcpy(store->records[record_id].data, data + offset, length);
}

/* Get record */
uint8_t* midp_rms_get_record(int handle, int record_id, int* length) {
    if (length) *length = 0;
    
    if (handle < 0 || handle >= record_store_count) return NULL;
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) return NULL;
    
    RecordStore* store = &record_stores[handle];
    if (!store->open) return NULL;
    
    if (!store->records[record_id].valid) return NULL;
    
    if (length) *length = store->records[record_id].size;
    return store->records[record_id].data;
}

/* Delete record */
void midp_rms_delete_record(int handle, int record_id) {
    if (handle < 0 || handle >= record_store_count) return;
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) return;
    
    RecordStore* store = &record_stores[handle];
    if (!store->open) return;
    
    free(store->records[record_id].data);
    memset(&store->records[record_id], 0, sizeof(Record));
}

/* Get number of records */
int midp_rms_get_num_records(int handle) {
    if (handle < 0 || handle >= record_store_count) return 0;
    
    RecordStore* store = &record_stores[handle];
    if (!store->open) return 0;
    
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    return count;
}

/* Get record IDs */
int* midp_rms_get_record_ids(int handle, int* count) {
    if (count) *count = 0;
    
    if (handle < 0 || handle >= record_store_count) return NULL;
    
    RecordStore* store = &record_stores[handle];
    if (!store->open) return NULL;
    
    int num_records = midp_rms_get_num_records(handle);
    int* ids = (int*)malloc(num_records * sizeof(int));
    if (!ids) return NULL;
    
    int idx = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) {
            ids[idx++] = i;
        }
    }
    
    if (count) *count = num_records;
    return ids;
}

/* Delete record store */
void midp_rms_delete_record_store(const char* name) {
    rms_init();
    
    /* Find store */
    for (int i = 0; i < record_store_count; i++) {
        if (strcmp(record_stores[i].name, name) == 0) {
            /* Free all records */
            for (int j = 1; j < MAX_RECORDS_PER_STORE; j++) {
                free(record_stores[i].records[j].data);
            }
            
            free(record_stores[i].name);
            
            /* Remove from array */
            if (i < record_store_count - 1) {
                memmove(&record_stores[i], &record_stores[i + 1],
                        (record_store_count - i - 1) * sizeof(RecordStore));
            }
            
            record_store_count--;
            break;
        }
    }
    
    /* TODO: Delete file from disk - skipping for now */
}

/* List record stores */
char** midp_rms_list_record_stores(int* count) {
    rms_init();
    
    if (count) *count = 0;
    
    /* List from memory instead of filesystem */
    if (record_store_count == 0) return NULL;
    
    /* Allocate array */
    char** names = (char**)malloc(record_store_count * sizeof(char*));
    if (!names) return NULL;
    
    /* Copy names from memory */
    int idx = 0;
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name) {
            names[idx] = strdup(record_stores[i].name);
            if (names[idx]) idx++;
        }
    }
    
    if (count) *count = idx;
    return names;
}

/*
 * Native methods for RMS
 */

static JavaValue native_rms_openRecordStore(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)arg_count;
    const char* name = native_get_string_utf8(jvm, args, 1);
    jboolean create = args[2].i;
    
    int handle = midp_rms_open_record_store(name, create != 0);
    
    if (handle < 0) {
        /* TODO: Throw appropriate exception */
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(handle);
}

static JavaValue native_rms_closeRecordStore(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint handle = args[0].i;
    
    midp_rms_close_record_store(handle);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_rms_addRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint handle = args[0].i;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    if (!data) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    int id = midp_rms_add_record(handle, (const uint8_t*)array_data(data), offset, length);
    return NATIVE_RETURN_INT(id);
}

static JavaValue native_rms_getRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    jint handle = args[0].i;
    jint record_id = args[1].i;
    JavaArray* data = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    
    int length;
    uint8_t* record_data = midp_rms_get_record(handle, record_id, &length);
    
    if (!record_data) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (data && offset + length <= data->length) {
        memcpy((uint8_t*)array_data(data) + offset, record_data, length);
    }
    
    return NATIVE_RETURN_INT(length);
}

static JavaValue native_rms_getRecordSize(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint handle = args[0].i;
    jint record_id = args[1].i;
    
    int length;
    midp_rms_get_record(handle, record_id, &length);
    
    return NATIVE_RETURN_INT(length);
}

static JavaValue native_rms_setRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint handle = args[0].i;
    jint record_id = args[1].i;
    JavaArray* data = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    jint length = args[4].i;
    
    if (!data) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    midp_rms_set_record(handle, record_id, (const uint8_t*)array_data(data), offset, length);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_rms_deleteRecord(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint handle = args[0].i;
    jint record_id = args[1].i;
    
    midp_rms_delete_record(handle, record_id);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_rms_getNumRecords(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint handle = args[0].i;
    
    return NATIVE_RETURN_INT(midp_rms_get_num_records(handle));
}

static JavaValue native_rms_deleteRecordStore(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    const char* name = native_get_string_utf8(jvm, args, 1);
    
    midp_rms_delete_record_store(name);
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_rms_listRecordStores(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    int count;
    char** names = midp_rms_list_record_stores(&count);
    
    if (!names || count == 0) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Create String array */
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, count);
    if (!array) {
        for (int i = 0; i < count; i++) free(names[i]);
        free(names);
        return NATIVE_RETURN_NULL();
    }
    
    for (int i = 0; i < count; i++) {
        JavaString* str = jvm_new_string(jvm, names[i]);
        array_set_ref(array, i, str);
        free(names[i]);
    }
    free(names);
    
    return NATIVE_RETURN_OBJECT(array);
}

void init_javax_microedition_rms(JVM* jvm) {
    NativeMethodEntry methods[] = {
        {"javax/microedition/rms/RecordStore", "openRecordStore", "(Ljava/lang/String;Z)I", native_rms_openRecordStore},
        {"javax/microedition/rms/RecordStore", "closeRecordStore", "()V", native_rms_closeRecordStore},
        {"javax/microedition/rms/RecordStore", "addRecord", "([BII)I", native_rms_addRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", "(I[BI)I", native_rms_getRecord},
        {"javax/microedition/rms/RecordStore", "getRecordSize", "(I)I", native_rms_getRecordSize},
        {"javax/microedition/rms/RecordStore", "setRecord", "(I[BII)V", native_rms_setRecord},
        {"javax/microedition/rms/RecordStore", "deleteRecord", "(I)V", native_rms_deleteRecord},
        {"javax/microedition/rms/RecordStore", "getNumRecords", "()I", native_rms_getNumRecords},
        {"javax/microedition/rms/RecordStore", "deleteRecordStore", "(Ljava/lang/String;)V", native_rms_deleteRecordStore},
        {"javax/microedition/rms/RecordStore", "listRecordStores", "()[Ljava/lang/String;", native_rms_listRecordStores},
    };
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
}
