/*
 * J2ME Emulator - MIDP2 RMS (Record Management System)
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include "debug.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

#include "midp.h"
#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"

/* Maximum record stores */
#define MAX_RECORD_STORES 64
#define MAX_RECORDS_PER_STORE 1024
#define MAX_RECORD_SIZE 65536  /* 64KB max per record */

/* Record structure */
typedef struct {
    int id;
    uint8_t* data;
    int size;
    bool valid;
} Record;

/* Record store structure */
typedef struct {
    char* name;
    Record records[MAX_RECORDS_PER_STORE];
    int next_id;
    bool open;
    int ref_count;
} NativeRecordStore;

/* Record stores */
static NativeRecordStore record_stores[MAX_RECORD_STORES];
static int record_store_count = 0;
static bool rms_initialized = false;

/* Initialize RMS */
static void rms_init(void) {
    if (rms_initialized) return;
    
    memset(record_stores, 0, sizeof(record_stores));
    rms_initialized = true;
}

/* Open/create record store - returns native handle */
static int rms_open(const char* name, bool create_if_necessary) {
    rms_init();
    
    if (!name) return -1;
    
    /* Find existing store */
    for (int i = 0; i < MAX_RECORD_STORES; i++) {
        if (record_stores[i].name && strcmp(record_stores[i].name, name) == 0) {
            record_stores[i].ref_count++;
            record_stores[i].open = true;
            RMS_DEBUG("Reopened existing store '%s' (handle=%d, refs=%d)", 
                    name, i, record_stores[i].ref_count);
            return i;
        }
    }
    
    if (!create_if_necessary) {
        RMS_DEBUG("Store '%s' not found and create=false", name);
        return -1;  /* RecordStoreNotFoundException */
    }
    
    /* Find a free slot (not just at the end, since we don't shift anymore) */
    int handle = -1;
    for (int i = 0; i < MAX_RECORD_STORES; i++) {
        if (!record_stores[i].name) {
            handle = i;
            break;
        }
    }
    
    if (handle < 0) {
        RMS_DEBUG("Max stores reached (%d)", MAX_RECORD_STORES);
        return -2;  /* RecordStoreFullException */
    }
    
    NativeRecordStore* store = &record_stores[handle];
    
    store->name = strdup(name);
    if (!store->name) {
        RMS_DEBUG("Out of memory for store name");
        return -2;
    }
    
    store->next_id = 1;
    store->open = true;
    store->ref_count = 1;
    
    memset(store->records, 0, sizeof(store->records));
    
    /* Update count for high-water mark */
    if (handle >= record_store_count) {
        record_store_count = handle + 1;
    }
    
    RMS_DEBUG("Created new store '%s' with handle %d", name, handle);
    
    return handle;
}

/* Get native record store from Java RecordStore object */
static NativeRecordStore* get_native_store(JavaObject* rs_obj) {
    if (!rs_obj) {
        RMS_DEBUG("get_native_store: NULL object");
        return NULL;
    }
    
    /* Проверка валидности объекта */
    if (!rs_obj->header.clazz) {
        RMS_DEBUG("get_native_store: Object has NULL class!");
        return NULL;
    }
    
    JavaClass* clazz = rs_obj->header.clazz;
    
    /* Find nativeHandle field */
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "nativeHandle") == 0) {
            int handle = rs_obj->fields[i].i;
            
            /* Проверка валидности handle */
            if (handle >= 0 && handle < MAX_RECORD_STORES) {
                NativeRecordStore* store = &record_stores[handle];
                if (store->name && store->open) {
                    return store;
                } else if (!store->name) {
                    RMS_DEBUG("get_native_store: store %d has been deleted", handle);
                    return NULL;
                } else {
                    RMS_DEBUG("get_native_store: store %d is closed", handle);
                    return NULL;
                }
            } else {
                RMS_DEBUG("get_native_store: invalid handle %d (max=%d)", 
                        handle, MAX_RECORD_STORES);
                return NULL;
            }
        }
    }
    
    RMS_DEBUG("get_native_store: nativeHandle field not found in class %s",
            clazz->class_name ? clazz->class_name : "?");
    return NULL;
}

/*
 * Native methods for RecordStore
 */

/* RecordStore.openRecordStore(String, boolean) - returns RecordStore object */
static JavaValue native_rms_openRecordStore(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)arg_count;
    
    /* STATIC METHOD - no 'this' argument!
     * args[0] - name (String)
     * args[1] - create (boolean)
     */
    JavaString* name_str = (JavaString*)args[0].ref;
    jboolean create = args[1].i;
    
    if (!name_str) {
        RMS_DEBUG("openRecordStore: name is NULL");
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    const char* name = string_utf8(jvm, name_str);
    RMS_DEBUG("openRecordStore: '%s', create=%d", name, create);
    
    int handle = rms_open(name, create != 0);
    
    if (handle < 0) {
        /* Бросаем соответствующее исключение */
        if (handle == -1) {
            jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotFoundException", name);
        } else {
            jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreFullException", NULL);
        }
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    /* Load RecordStore class */
    JavaClass* rs_class = jvm_load_class(jvm, "javax/microedition/rms/RecordStore");
    if (!rs_class) {
        RMS_DEBUG("Failed to load RecordStore class");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create RecordStore Java object */
    JavaObject* rs_obj = jvm_new_object(jvm, rs_class);
    if (!rs_obj) {
        RMS_DEBUG("Failed to create RecordStore object");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store native handle in nativeHandle field */
    bool found = false;
    for (int i = 0; i < rs_class->fields_count; i++) {
        if (rs_class->fields[i].name && strcmp(rs_class->fields[i].name, "nativeHandle") == 0) {
            rs_obj->fields[i].i = handle;
            RMS_DEBUG("Set nativeHandle=%d in field %d", handle, i);
            found = true;
            break;
        }
    }
    
    if (!found) {
        RMS_DEBUG("WARNING: nativeHandle field not found in RecordStore class");
    }
    
    RMS_DEBUG("Returning RecordStore object: %p", (void*)rs_obj);
    return NATIVE_RETURN_OBJECT(rs_obj);
}

/* RecordStore.closeRecordStore() */
static JavaValue native_rms_closeRecordStore(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_VOID();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (store) {
        store->ref_count--;
        RMS_DEBUG("closeRecordStore: refs now %d", store->ref_count);
        
        if (store->ref_count <= 0) {
            store->open = false;
            RMS_DEBUG("Store closed");
        }
    } else {
        RMS_DEBUG("closeRecordStore: invalid store");
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.addRecord(byte[], int, int) - returns record ID */
static JavaValue native_rms_addRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    JavaArray* data = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    RMS_DEBUG("addRecord: offset=%d, length=%d", offset, length);
    
    if (!rs_obj || !data) {
        RMS_DEBUG("addRecord: NULL parameter");
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Проверка длины */
    if (length <= 0) {
        RMS_DEBUG("addRecord: invalid length %d", length);
        return NATIVE_RETURN_INT(-1);
    }
    
    if (length > MAX_RECORD_SIZE) {
        RMS_DEBUG("addRecord: record too large (%d > %d)", 
                length, MAX_RECORD_SIZE);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Проверка границ массива */
    if (offset < 0 || length < 0 || offset + length > (jint)data->length) {
        RMS_DEBUG("addRecord: array bounds error: offset=%d, length=%d, array_len=%d",
                offset, length, data->length);
        native_throw_aioobe(jvm, thread, offset);
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        RMS_DEBUG("addRecord: invalid store");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->open) {
        RMS_DEBUG("addRecord: store is closed");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Find free slot */
    int id = -1;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (!store->records[i].valid) {
            id = i;
            break;
        }
    }
    
    if (id < 0) {
        RMS_DEBUG("addRecord: no free slots");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreFullException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Allocate and copy data */
    uint8_t* record_data = (uint8_t*)malloc(length);
    if (!record_data) {
        RMS_DEBUG("addRecord: out of memory");
        jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_INT(-1);
    }
    
    uint8_t* src_data = (uint8_t*)array_data(data);
    memcpy(record_data, src_data + offset, length);
    
    /* Store record */
    store->records[id].id = id;
    store->records[id].data = record_data;
    store->records[id].size = length;
    store->records[id].valid = true;
    
    /* Update next_id if needed */
    if (id >= store->next_id) {
        store->next_id = id + 1;
    }
    
    RMS_DEBUG("addRecord: SUCCESS - id=%d, size=%d, next_id=%d", 
            id, length, store->next_id);
    
    return NATIVE_RETURN_INT(id);
}

/* RecordStore.getRecord(int) - returns byte[] */
static JavaValue native_rms_getRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    RMS_DEBUG("getRecord: record_id=%d", record_id);
    
    if (!rs_obj) {
        native_throw_npe(jvm, thread);
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        RMS_DEBUG("getRecord: invalid store");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    if (!store->open) {
        RMS_DEBUG("getRecord: store is closed");
        jvm_throw_by_name(jvm, "javax/microedition/rms/RecordStoreNotOpenException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        RMS_DEBUG("getRecord: invalid record_id=%d", record_id);
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    if (!store->records[record_id].valid) {
        RMS_DEBUG("getRecord: record %d not found", record_id);
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    int length = store->records[record_id].size;
    uint8_t* data = store->records[record_id].data;
    
    RMS_DEBUG("getRecord: record %d has size=%d", record_id, length);
    
    /* Create byte array */
    JavaArray* byte_array = jvm_new_array(jvm, T_BYTE, (jsize)length, NULL);
    if (!byte_array) {
        RMS_DEBUG("getRecord: failed to allocate byte array");
        jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
        thread->pending_exception = jvm_exception_pending(jvm);
        return NATIVE_RETURN_NULL();
    }
    
    memcpy(array_data(byte_array), data, length);
    
    RMS_DEBUG("getRecord: returning %d bytes", length);
    return NATIVE_RETURN_OBJECT(byte_array);
}

/* RecordStore.getRecord(int, byte[], int) - returns size */
static JavaValue native_rms_getRecord_array(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    JavaArray* dest = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    
    if (!rs_obj || !dest) {
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_INT(-1);
    }
    
    int length = store->records[record_id].size;
    
    if (offset < 0 || length > (jint)dest->length - offset) {
        return NATIVE_RETURN_INT(-1);
    }
    
    memcpy((uint8_t*)array_data(dest) + offset, store->records[record_id].data, length);
    
    return NATIVE_RETURN_INT(length);
}

/* RecordStore.getRecordSize(int) - returns size */
static JavaValue native_rms_getRecordSize(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_INT(-1);
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(store->records[record_id].size);
}

/* RecordStore.setRecord(int, byte[], int, int) */
static JavaValue native_rms_setRecord(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    JavaArray* data = (JavaArray*)args[2].ref;
    jint offset = args[3].i;
    jint length = args[4].i;
    
    if (!rs_obj || !data) {
        return NATIVE_RETURN_VOID();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_VOID();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_VOID();
    }
    
    if (!store->records[record_id].valid) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Check bounds */
    if (offset < 0 || length < 0 || offset + length > (jint)data->length) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Allocate new data */
    uint8_t* new_data = (uint8_t*)malloc(length);
    if (!new_data) {
        return NATIVE_RETURN_VOID();
    }
    
    memcpy(new_data, (uint8_t*)array_data(data) + offset, length);
    
    /* Replace old data */
    free(store->records[record_id].data);
    store->records[record_id].data = new_data;
    store->records[record_id].size = length;
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.deleteRecord(int) */
static JavaValue native_rms_deleteRecord(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    jint record_id = args[1].i;
    
    if (!rs_obj) {
        return NATIVE_RETURN_VOID();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_VOID();
    }
    
    if (record_id < 1 || record_id >= MAX_RECORDS_PER_STORE) {
        return NATIVE_RETURN_VOID();
    }
    
    if (store->records[record_id].valid) {
        free(store->records[record_id].data);
        memset(&store->records[record_id], 0, sizeof(Record));
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.getNumRecords() */
static JavaValue native_rms_getNumRecords(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(0);
    }
    
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    return NATIVE_RETURN_INT(count);
}

/* RecordStore.enumerateRecords - возвращает RecordEnumeration объект */
static JavaValue native_rms_enumerateRecords(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)arg_count;
    (void)thread;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    RMS_DEBUG("enumerateRecords called");
    
    if (!rs_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Count valid records */
    int count = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) count++;
    }
    
    RMS_DEBUG("enumerateRecords: %d records found", count);
    
    /* Load RecordEnumerationImpl class (concrete implementation) */
    JavaClass* enum_class = jvm_load_class(jvm, "javax/microedition/rms/RecordEnumerationImpl");
    if (!enum_class) {
        RMS_DEBUG("Failed to load RecordEnumerationImpl class");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create RecordEnumerationImpl object */
    JavaObject* enum_obj = heap_alloc_object(jvm, enum_class);
    if (!enum_obj) {
        RMS_DEBUG("Failed to allocate RecordEnumeration");
        return NATIVE_RETURN_NULL();
    }
    
    /* Create int array with record IDs - store in first field */
    JavaArray* ids = jvm_new_array(jvm, T_INT, count > 0 ? count : 0, NULL);
    if (!ids && count > 0) {
        RMS_DEBUG("Failed to allocate IDs array");
        return NATIVE_RETURN_NULL();
    }
    
    if (count > 0 && ids) {
        jint* ids_data = (jint*)array_data(ids);
        int idx = 0;
        for (int i = 1; i < MAX_RECORDS_PER_STORE && idx < count; i++) {
            if (store->records[i].valid) {
                ids_data[idx++] = i;
            }
        }
    }
    
    /* Store IDs array in field 0, current index in field 1, store handle in field 2 */
    /* Ensure the class has enough fields */
    if (enum_class->instance_size < sizeof(ObjectHeader) + 3 * sizeof(JavaValue)) {
        enum_class->instance_size = sizeof(ObjectHeader) + 3 * sizeof(JavaValue);
    }
    
    /* Get the store handle from the RecordStore object */
    jint store_handle = -1;
    JavaClass* rs_class = rs_obj->header.clazz;
    if (rs_class && rs_class->fields) {
        for (int i = 0; i < rs_class->fields_count; i++) {
            if (rs_class->fields[i].name && strcmp(rs_class->fields[i].name, "nativeHandle") == 0) {
                store_handle = rs_obj->fields[i].i;
                break;
            }
        }
    }
    
    enum_obj->fields[0].ref = ids;       /* recordIds array */
    enum_obj->fields[1].i = 0;           /* currentIndex */
    enum_obj->fields[2].i = store_handle; /* store handle for nextRecord */
    
    RMS_DEBUG("Created RecordEnumeration with %d records, store_handle=%d", count, store_handle);
    
    return NATIVE_RETURN_OBJECT(enum_obj);
}

/* RecordStore.deleteRecordStore(String) - static method */
static JavaValue native_rms_deleteRecordStore(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)arg_count;
    /* STATIC METHOD - no 'this' argument!
     * args[0] - name (String)
     */
    JavaString* name_str = (JavaString*)args[0].ref;
    
    if (!name_str) {
        return NATIVE_RETURN_VOID();
    }
    
    const char* name = string_utf8(jvm, name_str);
    RMS_DEBUG("deleteRecordStore: '%s'", name);
    
    rms_init();
    
    /* Find store */
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && strcmp(record_stores[i].name, name) == 0) {
            /* Free all records */
            for (int j = 1; j < MAX_RECORDS_PER_STORE; j++) {
                if (record_stores[i].records[j].valid) {
                    free(record_stores[i].records[j].data);
                }
            }
            
            free(record_stores[i].name);
            record_stores[i].name = NULL;
            record_stores[i].open = false;
            record_stores[i].ref_count = 0;
            
            /* DON'T shift the array - this would invalidate handles!
             * Just mark the slot as free by setting name to NULL.
             * The handle indices must remain stable for existing RecordStore objects.
             */
            RMS_DEBUG("Store deleted (slot %d marked free)", i);
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordStore.listRecordStores() - returns String[] */
static JavaValue native_rms_listRecordStores(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)args; (void)arg_count;
    
    rms_init();
    
    /* Always return an array (even if empty), never null 
     * This matches some game expectations better than returning null */
    int count = 0;
    for (int i = 0; i < record_store_count; i++) {
        if (record_stores[i].name && record_stores[i].open) {
            count++;
        }
    }
    
    /* Create String array */
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, count, NULL);
    if (!array) {
        return NATIVE_RETURN_NULL();
    }
    
    int idx = 0;
    for (int i = 0; i < record_store_count && idx < count; i++) {
        if (record_stores[i].name && record_stores[i].open) {
            JavaString* str = jvm_new_string(jvm, record_stores[i].name);
            array_set_ref(array, idx++, str);
        }
    }
    
    return NATIVE_RETURN_OBJECT(array);
}

/* RecordStore.getNextRecordID() */
static JavaValue native_rms_getNextRecordID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(-1);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->open) {
        return NATIVE_RETURN_INT(-1);
    }
    
    return NATIVE_RETURN_INT(store->next_id);
}

/* RecordStore.getVersion() - возвращает версию (упрощенно) */
static JavaValue native_rms_getVersion(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Простая версия на основе количества записей */
    int version = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) version++;
    }
    
    return NATIVE_RETURN_INT(version);
}

/* RecordStore.getLastModified() - время последнего изменения */
static JavaValue native_rms_getLastModified(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_LONG(0);
    }
    
    jlong current_time;
    
#ifdef _WIN32
    /* Windows implementation - simple version using GetTickCount */
    current_time = (jlong)GetTickCount();
#else
    /* POSIX implementation */
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    current_time = (jlong)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
    
    return NATIVE_RETURN_LONG(current_time);
}

/* RecordStore.getSize() - возвращает размер данных */
static JavaValue native_rms_getSize(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store) {
        return NATIVE_RETURN_INT(0);
    }
    
    int total = 0;
    for (int i = 1; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid) {
            total += store->records[i].size;
        }
    }
    
    return NATIVE_RETURN_INT(total);
}

/* RecordStore.getSizeAvailable() - доступное место */
static JavaValue native_rms_getSizeAvailable(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    
    /* Возвращаем большое число (нет ограничений) */
    return NATIVE_RETURN_INT(1024 * 1024);  /* 1MB */
}

/* RecordStore.getName() - имя хранилища */
static JavaValue native_rms_getName(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* rs_obj = (JavaObject*)args[0].ref;
    
    if (!rs_obj) {
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = get_native_store(rs_obj);
    if (!store || !store->name) {
        return NATIVE_RETURN_NULL();
    }
    
    return NATIVE_RETURN_OBJECT(jvm_new_string(jvm, store->name));
}

/* RecordEnumeration.hasNextElement() */
static JavaValue native_enumeration_hasNextElement(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (!enum_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    /* Field 0 = recordIds array, Field 1 = currentIndex */
    JavaArray* ids = (JavaArray*)enum_obj->fields[0].ref;
    jint current = enum_obj->fields[1].i;
    
    if (!ids) {
        return NATIVE_RETURN_INT(0);
    }
    
    jboolean has_next = (current < (jint)ids->length) ? JNI_TRUE : JNI_FALSE;
    RMS_DEBUG("hasNextElement: current=%d, length=%d, result=%d", 
            current, ids->length, has_next);
    return NATIVE_RETURN_INT(has_next);
}

/* RecordEnumeration.nextRecordId() */
static JavaValue native_enumeration_nextRecordId(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (!enum_obj) {
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        return NATIVE_RETURN_INT(-1);
    }
    
    JavaArray* ids = (JavaArray*)enum_obj->fields[0].ref;
    jint current = enum_obj->fields[1].i;
    
    if (!ids || current >= (jint)ids->length) {
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        return NATIVE_RETURN_INT(-1);
    }
    
    jint* ids_data = (jint*)array_data(ids);
    jint record_id = ids_data[current];
    
    /* Advance index */
    enum_obj->fields[1].i = current + 1;
    
    RMS_DEBUG("nextRecordId: returning %d", record_id);
    return NATIVE_RETURN_INT(record_id);
}

/* RecordEnumeration.nextRecord() - returns byte[] of next record */
static JavaValue native_enumeration_nextRecord(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (!enum_obj) {
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        return NATIVE_RETURN_NULL();
    }
    
    JavaArray* ids = (JavaArray*)enum_obj->fields[0].ref;
    jint current = enum_obj->fields[1].i;
    
    if (!ids || current >= (jint)ids->length) {
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        return NATIVE_RETURN_NULL();
    }
    
    jint* ids_data = (jint*)array_data(ids);
    jint record_id = ids_data[current];
    
    /* Advance index */
    enum_obj->fields[1].i = current + 1;
    
    /* Get the record store handle from field 2 */
    jint store_handle = enum_obj->fields[2].i;
    
    if (store_handle < 0 || store_handle >= record_store_count) {
        jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
        return NATIVE_RETURN_NULL();
    }
    
    NativeRecordStore* store = &record_stores[store_handle];
    
    /* Find the record */
    for (int i = 0; i < MAX_RECORDS_PER_STORE; i++) {
        if (store->records[i].valid && store->records[i].id == record_id) {
            Record* rec = &store->records[i];
            
            /* Create byte array */
            JavaArray* data = jvm_new_array(jvm, T_BYTE, rec->size, NULL);
            if (!data) {
                jvm_throw_by_name(jvm, "java/lang/OutOfMemoryError", NULL);
                return NATIVE_RETURN_NULL();
            }
            
            memcpy(array_data(data), rec->data, rec->size);
            
            RMS_DEBUG("nextRecord: returning %d bytes for record %d", rec->size, record_id);
            return NATIVE_RETURN_OBJECT(data);
        }
    }
    
    jvm_throw_by_name(jvm, "javax/microedition/rms/InvalidRecordIDException", NULL);
    return NATIVE_RETURN_NULL();
}

/* RecordEnumeration.destroy() - cleanup enumeration */
static JavaValue native_enumeration_destroy(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (enum_obj) {
        /* Clear the ids array reference */
        enum_obj->fields[0].ref = NULL;
        enum_obj->fields[1].i = 0;
    }
    
    return NATIVE_RETURN_VOID();
}

/* RecordEnumeration.numRecords() */
static JavaValue native_enumeration_numRecords(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* enum_obj = (JavaObject*)args[0].ref;
    
    if (!enum_obj) {
        return NATIVE_RETURN_INT(0);
    }
    
    JavaArray* ids = (JavaArray*)enum_obj->fields[0].ref;
    return NATIVE_RETURN_INT(ids ? ids->length : 0);
}

void init_javax_microedition_rms(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Static methods */
        {"javax/microedition/rms/RecordStore", "openRecordStore", 
         "(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;", native_rms_openRecordStore},
        {"javax/microedition/rms/RecordStore", "deleteRecordStore", 
         "(Ljava/lang/String;)V", native_rms_deleteRecordStore},
        {"javax/microedition/rms/RecordStore", "listRecordStores", 
         "()[Ljava/lang/String;", native_rms_listRecordStores},
        
        /* Instance methods */
        {"javax/microedition/rms/RecordStore", "closeRecordStore", 
         "()V", native_rms_closeRecordStore},
        {"javax/microedition/rms/RecordStore", "addRecord", 
         "([BII)I", native_rms_addRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", 
         "(I)[B", native_rms_getRecord},
        {"javax/microedition/rms/RecordStore", "getRecord", 
         "(I[BI)I", native_rms_getRecord_array},
        {"javax/microedition/rms/RecordStore", "getRecordSize", 
         "(I)I", native_rms_getRecordSize},
        {"javax/microedition/rms/RecordStore", "setRecord", 
         "(I[BII)V", native_rms_setRecord},
        {"javax/microedition/rms/RecordStore", "deleteRecord", 
         "(I)V", native_rms_deleteRecord},
        {"javax/microedition/rms/RecordStore", "getNumRecords", 
         "()I", native_rms_getNumRecords},
        {"javax/microedition/rms/RecordStore", "enumerateRecords", 
         "(Ljavax/microedition/rms/RecordFilter;Ljavax/microedition/rms/RecordComparator;Z)Ljavax/microedition/rms/RecordEnumeration;",
         native_rms_enumerateRecords},
        {"javax/microedition/rms/RecordStore", "getNextRecordID", 
         "()I", native_rms_getNextRecordID},
        {"javax/microedition/rms/RecordStore", "getVersion", 
         "()I", native_rms_getVersion},
        {"javax/microedition/rms/RecordStore", "getLastModified", 
         "()J", native_rms_getLastModified},
        {"javax/microedition/rms/RecordStore", "getSize", 
         "()I", native_rms_getSize},
        {"javax/microedition/rms/RecordStore", "getSizeAvailable", 
         "()I", native_rms_getSizeAvailable},
        {"javax/microedition/rms/RecordStore", "getName", 
         "()Ljava/lang/String;", native_rms_getName},
        
        /* RecordEnumeration interface methods */
        {"javax/microedition/rms/RecordEnumeration", "hasNextElement", 
         "()Z", native_enumeration_hasNextElement},
        {"javax/microedition/rms/RecordEnumeration", "nextRecordId", 
         "()I", native_enumeration_nextRecordId},
        {"javax/microedition/rms/RecordEnumeration", "nextRecord", 
         "()[B", native_enumeration_nextRecord},
        {"javax/microedition/rms/RecordEnumeration", "destroy", 
         "()V", native_enumeration_destroy},
        {"javax/microedition/rms/RecordEnumeration", "numRecords", 
         "()I", native_enumeration_numRecords},
        
        /* RecordEnumerationImpl concrete class methods (same implementations) */
        {"javax/microedition/rms/RecordEnumerationImpl", "hasNextElement", 
         "()Z", native_enumeration_hasNextElement},
        {"javax/microedition/rms/RecordEnumerationImpl", "nextRecordId", 
         "()I", native_enumeration_nextRecordId},
        {"javax/microedition/rms/RecordEnumerationImpl", "nextRecord", 
         "()[B", native_enumeration_nextRecord},
        {"javax/microedition/rms/RecordEnumerationImpl", "destroy", 
         "()V", native_enumeration_destroy},
        {"javax/microedition/rms/RecordEnumerationImpl", "numRecords", 
         "()I", native_enumeration_numRecords},
    };
    
    int count = sizeof(methods) / sizeof(methods[0]);
    native_register_methods(jvm, methods, count);
    
    RMS_DEBUG("Registered %d native methods", count);
}