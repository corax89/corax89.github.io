/*
 * J2ME Emulator - Media API Implementation
 * javax.microedition.media native methods
 * Supports MIDI and WAV audio formats
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include "debug.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include "jvm.h"
#include "native.h"
#include "midi.h"
#include "heap.h"

/* Forward declarations from SDL audio */
extern int sdl_audio_init_simple(uint32_t sample_rate);
extern void sdl_audio_shutdown(void);

/* ============================================
 * WAV File Support
 * ============================================ */

typedef struct {
    uint16_t audio_format;      /* 1 = PCM */
    uint16_t num_channels;
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample;
    uint8_t* data;
    uint32_t data_size;
    uint32_t duration_ms;       /* Duration in milliseconds */
} WavFile;

/* Parse WAV file from memory */
static WavFile* wav_parse(const uint8_t* data, uint32_t size) {
    if (size < 44) {
        MEDIA_DEBUG("File too small: %u bytes", size);
        return NULL;
    }
    
    /* Check RIFF header */
    if (memcmp(data, "RIFF", 4) != 0) {
        MEDIA_DEBUG("Invalid RIFF header");
        return NULL;
    }
    
    uint32_t file_size = data[4] | (data[5] << 8) | (data[6] << 16) | (data[7] << 24);
    (void)file_size;
    
    /* Check WAVE format */
    if (memcmp(data + 8, "WAVE", 4) != 0) {
        MEDIA_DEBUG("Invalid WAVE format");
        return NULL;
    }
    
    WavFile* wav = (WavFile*)calloc(1, sizeof(WavFile));
    if (!wav) return NULL;
    
    /* Parse chunks */
    uint32_t pos = 12;
    while (pos + 8 <= size) {
        uint32_t chunk_size = data[pos+4] | (data[pos+5] << 8) | (data[pos+6] << 16) | (data[pos+7] << 24);
        
        if (pos + 8 + chunk_size > size) {
            MEDIA_DEBUG("Chunk exceeds file size");
            break;
        }
        
        /* Check chunk ID using memcmp (more reliable) */
        if (memcmp(data + pos, "fmt ", 4) == 0) {
            /* fmt chunk */
            pos += 8;  /* Skip chunk ID and size */
            if (chunk_size >= 16) {
                wav->audio_format = data[pos] | (data[pos+1] << 8);
                wav->num_channels = data[pos+2] | (data[pos+3] << 8);
                wav->sample_rate = data[pos+4] | (data[pos+5] << 8) | 
                                   (data[pos+6] << 16) | (data[pos+7] << 24);
                wav->byte_rate = data[pos+8] | (data[pos+9] << 8) | 
                                 (data[pos+10] << 16) | (data[pos+11] << 24);
                wav->block_align = data[pos+12] | (data[pos+13] << 8);
                wav->bits_per_sample = data[pos+14] | (data[pos+15] << 8);
                
                MEDIA_DEBUG("Format: %d channels, %d Hz, %d bits, format=%d",
                        wav->num_channels, wav->sample_rate, wav->bits_per_sample, wav->audio_format);
            }
            pos += chunk_size;
        } else if (memcmp(data + pos, "data", 4) == 0) {
            /* data chunk */
            pos += 8;  /* Skip chunk ID and size */
            wav->data = (uint8_t*)malloc(chunk_size);
            if (wav->data) {
                memcpy(wav->data, data + pos, chunk_size);
                wav->data_size = chunk_size;
                
                /* Calculate duration */
                if (wav->byte_rate > 0) {
                    wav->duration_ms = (chunk_size * 1000) / wav->byte_rate;
                }
            }
            pos += chunk_size;
        } else {
            /* Unknown chunk - skip it */
            pos += 8 + chunk_size;
        }
        
        /* Chunks are word-aligned */
        if (chunk_size & 1) pos++;
    }
    
    /* Validate */
    if (wav->audio_format != 1) {
        MEDIA_DEBUG("Unsupported format: %d (only PCM supported)", wav->audio_format);
        free(wav->data);
        free(wav);
        return NULL;
    }
    
    if (!wav->data) {
        MEDIA_DEBUG("No data chunk found");
        free(wav);
        return NULL;
    }
    
    MEDIA_DEBUG("Parsed successfully: %u bytes, %u ms duration", 
            wav->data_size, wav->duration_ms);
    
    return wav;
}

/* Free WAV file */
static void wav_free(WavFile* wav) {
    if (wav) {
        free(wav->data);
        free(wav);
    }
}

/* ============================================
 * Audio Player Types
 * ============================================ */

typedef enum {
    PLAYER_TYPE_NONE = 0,
    PLAYER_TYPE_MIDI,
    PLAYER_TYPE_WAV
} PlayerType;

/* Active players */
#define MAX_PLAYERS 16

typedef struct {
    int id;
    PlayerType type;
    bool playing;
    bool looping;
    char* content_type;
    
    /* MIDI data */
    MidiFile* midi;
    
    /* WAV data */
    WavFile* wav;
    uint32_t wav_position;  /* Current playback position in WAV */
    float wav_volume;
    
    /* Original data for seeking */
    uint8_t* data;
    uint32_t size;
} MediaPlayer;

static MediaPlayer g_players[MAX_PLAYERS];
static int g_next_player_id = 1;
static bool g_audio_initialized = false;

/* Initialize audio if needed */
static void ensure_audio_init(void) {
    if (!g_audio_initialized) {
        sdl_audio_init_simple(44100);
        midi_init(44100);
        g_audio_initialized = true;
    }
}

/* Find free player slot */
static int find_free_player_slot(void) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].type == PLAYER_TYPE_NONE) {
            return i;
        }
    }
    return -1;
}

/* Find player by object */
static MediaPlayer* find_player(JavaObject* obj) {
    if (!obj) return NULL;
    int id = obj->fields[0].i;  /* playerId field */
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].id == id && g_players[i].type != PLAYER_TYPE_NONE) {
            return &g_players[i];
        }
    }
    MEDIA_DEBUG("find_player: player id=%d not found", id);
    return NULL;
}

/* ============================================
 * Manager native methods
 * ============================================ */

/* Manager.createPlayer(String locator) */
static JavaValue native_manager_createPlayer_locator(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* locator_str = (JavaString*)args[0].ref;
    
    ensure_audio_init();
    
    const char* locator_cstr = NULL;
    if (locator_str) {
        locator_cstr = string_utf8(jvm, locator_str);
    }
    
    MEDIA_DEBUG("Manager.createPlayer: locator=%s", 
            locator_cstr ? locator_cstr : "(null)");
    
    /* Return null - we don't support locator-based players yet */
    return NATIVE_RETURN_NULL();
}

/* Manager.createPlayer(InputStream stream, String type) */
static JavaValue native_manager_createPlayer_stream(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* stream = (JavaObject*)args[0].ref;
    JavaString* type_str = (JavaString*)args[1].ref;
    
    ensure_audio_init();
    
    const char* type_cstr = NULL;
    if (type_str) {
        type_cstr = string_utf8(jvm, type_str);
    }
    
    MEDIA_DEBUG("Manager.createPlayer: stream=%p, type=%s",
            (void*)stream, type_cstr ? type_cstr : "(null)");
    
    if (!stream) {
        MEDIA_DEBUG("createPlayer: NULL stream");
        return NATIVE_RETURN_NULL();
    }
    
    /* Read data from ByteArrayInputStream */
    JavaClass* stream_class = stream->header.clazz;
    if (!stream_class || !stream_class->class_name) {
        MEDIA_DEBUG("createPlayer: Invalid stream class");
        return NATIVE_RETURN_NULL();
    }
    
    /* Find fields in ByteArrayInputStream: buf, pos, count */
    JavaArray* buf = NULL;
    int pos = 0, count = 0;
    
    for (int i = 0; i < stream_class->fields_count; i++) {
        const char* fname = stream_class->fields[i].name;
        if (fname) {
            if (strcmp(fname, "buf") == 0) {
                buf = (JavaArray*)stream->fields[i].ref;
            } else if (strcmp(fname, "pos") == 0) {
                pos = stream->fields[i].i;
            } else if (strcmp(fname, "count") == 0) {
                count = stream->fields[i].i;
            }
        }
    }
    
    if (!buf || count <= 0) {
        MEDIA_DEBUG("createPlayer: No data in stream (buf=%p, count=%d)", 
                (void*)buf, count);
        return NATIVE_RETURN_NULL();
    }
    
    int data_len = count - pos;
    if (data_len <= 0) {
        MEDIA_DEBUG("createPlayer: No data left (pos=%d, count=%d)", pos, count);
        return NATIVE_RETURN_NULL();
    }
    
    uint8_t* data = (uint8_t*)array_data(buf) + pos;
    
    MEDIA_DEBUG("createPlayer: %d bytes available", data_len);
    
    /* Find free player slot */
    int slot = find_free_player_slot();
    if (slot < 0) {
        MEDIA_DEBUG("createPlayer: No free player slots");
        return NATIVE_RETURN_NULL();
    }
    
    MediaPlayer* player = &g_players[slot];
    memset(player, 0, sizeof(MediaPlayer));
    player->id = g_next_player_id++;
    player->data = (uint8_t*)malloc(data_len);
    if (!player->data) {
        MEDIA_DEBUG("createPlayer: Out of memory");
        return NATIVE_RETURN_NULL();
    }
    memcpy(player->data, data, data_len);
    player->size = data_len;
    player->wav_volume = 1.0f;
    
    /* Determine type and parse */
    if (type_cstr && strstr(type_cstr, "wav")) {
        player->type = PLAYER_TYPE_WAV;
        player->wav = wav_parse(player->data, player->size);
        if (!player->wav) {
            MEDIA_DEBUG("createPlayer: Failed to parse WAV");
            free(player->data);
            memset(player, 0, sizeof(MediaPlayer));
            return NATIVE_RETURN_NULL();
        }
    } else if (type_cstr && strstr(type_cstr, "midi")) {
        player->type = PLAYER_TYPE_MIDI;
        player->midi = midi_load(player->data, player->size);
        if (!player->midi) {
            MEDIA_DEBUG("createPlayer: Failed to parse MIDI");
            free(player->data);
            memset(player, 0, sizeof(MediaPlayer));
            return NATIVE_RETURN_NULL();
        }
    } else {
        /* Auto-detect by magic bytes */
        if (data_len >= 4 && memcmp(player->data, "RIFF", 4) == 0) {
            player->type = PLAYER_TYPE_WAV;
            player->wav = wav_parse(player->data, player->size);
        } else if (data_len >= 4 && memcmp(player->data, "MThd", 4) == 0) {
            player->type = PLAYER_TYPE_MIDI;
            player->midi = midi_load(player->data, player->size);
        } else {
            /* Default to WAV */
            player->type = PLAYER_TYPE_WAV;
            player->wav = wav_parse(player->data, player->size);
        }
        
        if (player->type == PLAYER_TYPE_WAV && !player->wav) {
            MEDIA_DEBUG("createPlayer: Failed to parse as WAV");
            free(player->data);
            memset(player, 0, sizeof(MediaPlayer));
            return NATIVE_RETURN_NULL();
        }
        if (player->type == PLAYER_TYPE_MIDI && !player->midi) {
            MEDIA_DEBUG("createPlayer: Failed to parse as MIDI");
            free(player->data);
            if (player->wav) wav_free(player->wav);
            memset(player, 0, sizeof(MediaPlayer));
            return NATIVE_RETURN_NULL();
        }
    }
    
    MEDIA_DEBUG("createPlayer: Created player id=%d, type=%d", 
            player->id, player->type);
    
    /* Create a PlayerImpl object which implements Player interface */
    JavaClass* player_class = jvm_load_class(jvm, "javax/microedition/media/PlayerImpl");
    if (!player_class) {
        MEDIA_DEBUG("createPlayer: Failed to load PlayerImpl class");
        free(player->data);
        if (player->wav) wav_free(player->wav);
        if (player->midi) midi_free(player->midi);
        memset(player, 0, sizeof(MediaPlayer));
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* player_obj = jvm_new_object(jvm, player_class);
    if (!player_obj) {
        MEDIA_DEBUG("createPlayer: Failed to create PlayerImpl object");
        free(player->data);
        if (player->wav) wav_free(player->wav);
        if (player->midi) midi_free(player->midi);
        memset(player, 0, sizeof(MediaPlayer));
        return NATIVE_RETURN_NULL();
    }
    
    /* Store player ID in first field (playerId) */
    if (player_class->fields_count >= 1) {
        player_obj->fields[0].i = player->id;
    }
    /* Store state (0 = UNREALIZED) in second field */
    if (player_class->fields_count >= 2) {
        player_obj->fields[1].i = 0;  /* UNREALIZED */
    }
    
    MEDIA_DEBUG("createPlayer: Created PlayerImpl object %p with id=%d",
            (void*)player_obj, player->id);
    
    return NATIVE_RETURN_OBJECT(player_obj);
}

/* Manager.playTone(int note, int duration, int volume) */
static JavaValue native_manager_playTone(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint note = args[0].i;
    jint duration = args[1].i;
    jint volume = args[2].i;
    
    ensure_audio_init();
    
    MEDIA_DEBUG("Manager.playTone: note=%d, duration=%d, volume=%d",
            note, duration, volume);
    
    /* Play a single tone using MIDI synthesizer */
    midi_note_on(0, note, (volume * 127) / 100);
    
    /* TODO: Actually wait for duration and turn off */
    
    return NATIVE_RETURN_VOID();
}

/* ============================================
 * Player native methods
 * ============================================ */

/* Player.realize() */
static JavaValue native_player_realize(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        MEDIA_DEBUG("Player.realize: player not found");
        return NATIVE_RETURN_INT(-1);  /* Throw exception */
    }
    
    MEDIA_DEBUG("Player.realize: id=%d, type=%d", player->id, player->type);
    
    return NATIVE_RETURN_VOID();
}

/* Player.prefetch() */
static JavaValue native_player_prefetch(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_INT(-1);
    }
    
    MEDIA_DEBUG("Player.prefetch: id=%d", player->id);
    
    return NATIVE_RETURN_VOID();
}

/* Player.start() */
static JavaValue native_player_start(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        MEDIA_DEBUG("Player.start: player not found");
        return NATIVE_RETURN_INT(-1);
    }
    
    MEDIA_DEBUG("Player.start: id=%d, type=%d", player->id, player->type);
    
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        midi_play(player->midi);
        player->playing = true;
    } else if (player->type == PLAYER_TYPE_WAV && player->wav) {
        player->playing = true;
        player->wav_position = 0;  /* Start from beginning */
    }
    
    return NATIVE_RETURN_VOID();
}

/* Player.stop() */
static JavaValue native_player_stop(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_VOID();
    }
    
    MEDIA_DEBUG("Player.stop: id=%d", player->id);
    
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        midi_stop(player->midi);
    }
    player->playing = false;
    
    return NATIVE_RETURN_VOID();
}

/* Player.deallocate() */
static JavaValue native_player_deallocate(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_VOID();
    }
    
    MEDIA_DEBUG("Player.deallocate: id=%d", player->id);
    
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        midi_stop(player->midi);
        midi_free(player->midi);
        player->midi = NULL;
    } else if (player->type == PLAYER_TYPE_WAV && player->wav) {
        wav_free(player->wav);
        player->wav = NULL;
    }
    player->playing = false;
    
    return NATIVE_RETURN_VOID();
}

/* Player.close() */
static JavaValue native_player_close(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_VOID();
    }
    
    MEDIA_DEBUG("Player.close: id=%d", player->id);
    
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        midi_stop(player->midi);
        midi_free(player->midi);
        player->midi = NULL;
    } else if (player->type == PLAYER_TYPE_WAV && player->wav) {
        wav_free(player->wav);
        player->wav = NULL;
    }
    
    if (player->data) {
        free(player->data);
        player->data = NULL;
    }
    
    if (player->content_type) {
        free(player->content_type);
        player->content_type = NULL;
    }
    
    player->id = 0;
    player->type = PLAYER_TYPE_NONE;
    player->playing = false;
    
    return NATIVE_RETURN_VOID();
}

/* Player.setLoopCount(int count) */
static JavaValue native_player_setLoopCount(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    jint count = args[1].i;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_VOID();
    }
    
    MEDIA_DEBUG("Player.setLoopCount: id=%d, count=%d", player->id, count);
    
    player->looping = (count != 1);
    
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        midi_set_loop(player->midi, player->looping);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Player.getDuration() */
static JavaValue native_player_getDuration(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_INT(-1);  /* TIME_UNKNOWN */
    }
    
    /* Return duration in microseconds */
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        float duration = midi_get_length(player->midi);
        return NATIVE_RETURN_INT((int)(duration * 1000000));
    } else if (player->type == PLAYER_TYPE_WAV && player->wav) {
        return NATIVE_RETURN_INT((int)(player->wav->duration_ms * 1000));
    }
    
    return NATIVE_RETURN_INT(-1);  /* TIME_UNKNOWN */
}

/* Player.getMediaTime() */
static JavaValue native_player_getMediaTime(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_INT(0);
    }
    
    if (player->type == PLAYER_TYPE_MIDI && player->midi) {
        float pos = midi_get_position(player->midi);
        return NATIVE_RETURN_INT((int)(pos * 1000000));
    } else if (player->type == PLAYER_TYPE_WAV && player->wav) {
        /* Calculate position in microseconds based on byte position */
        uint32_t ms = 0;
        if (player->wav->byte_rate > 0) {
            ms = (player->wav_position * 1000) / player->wav->byte_rate;
        }
        return NATIVE_RETURN_INT((int)(ms * 1000));
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Player.getState() */
static JavaValue native_player_getState(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || player->type == PLAYER_TYPE_NONE) {
        return NATIVE_RETURN_INT(0);  /* UNREALIZED */
    }
    
    if (player->playing) {
        return NATIVE_RETURN_INT(400);  /* STARTED */
    }
    if (player->midi || player->wav) {
        return NATIVE_RETURN_INT(300);  /* PREFETCHED */
    }
    return NATIVE_RETURN_INT(200);  /* REALIZED */
}

/* Player.getContentType() */
static JavaValue native_player_getContentType(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->content_type) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaString* str = jvm_new_string(jvm, player->content_type);
    return NATIVE_RETURN_OBJECT(str);
}

/* Player.getControl(String controlType) - returns Control or null */
static JavaValue native_player_getControl(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    JavaString* control_type_str = (JavaString*)args[1].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        MEDIA_DEBUG("Player.getControl: player not found");
        return NATIVE_RETURN_NULL();
    }
    
    /* Get control type string */
    const char* control_type = NULL;
    if (control_type_str && control_type_str->utf8) {
        control_type = control_type_str->utf8;
    }
    
    MEDIA_DEBUG("Player.getControl: type=%s", control_type ? control_type : "null");
    
    if (!control_type) {
        return NATIVE_RETURN_NULL();
    }
    
    /* Check for VolumeControl */
    if (strstr(control_type, "VolumeControl") != NULL) {
        /* Create VolumeControlImpl object */
        JavaClass* vc_class = jvm_load_class(jvm, "javax/microedition/media/control/VolumeControlImpl");
        if (!vc_class) {
            MEDIA_DEBUG("VolumeControlImpl class not found");
            return NATIVE_RETURN_NULL();
        }
        
        JavaObject* vc_obj = jvm_new_object(jvm, vc_class);
        if (!vc_obj) {
            MEDIA_DEBUG("Failed to create VolumeControlImpl object");
            return NATIVE_RETURN_NULL();
        }
        
        /* Set player_id field (field 1) */
        vc_obj->fields[1].i = player->id;
        
        /* Set initial level */
        vc_obj->fields[2].i = 100;
        
        MEDIA_DEBUG("Created VolumeControlImpl for player %d", player->id);
        return NATIVE_RETURN_OBJECT(vc_obj);
    }
    
    /* Check for MIDIControl */
    if (strstr(control_type, "MIDIControl") != NULL && player->type == PLAYER_TYPE_MIDI) {
        /* Create MIDIControlImpl object */
        JavaClass* mc_class = jvm_load_class(jvm, "javax/microedition/media/control/MIDIControlImpl");
        if (!mc_class) {
            MEDIA_DEBUG("MIDIControlImpl class not found");
            return NATIVE_RETURN_NULL();
        }
        
        JavaObject* mc_obj = jvm_new_object(jvm, mc_class);
        if (!mc_obj) {
            MEDIA_DEBUG("Failed to create MIDIControlImpl object");
            return NATIVE_RETURN_NULL();
        }
        
        /* Set player_id field */
        mc_obj->fields[1].i = player->id;
        
        MEDIA_DEBUG("Created MIDIControlImpl for player %d", player->id);
        return NATIVE_RETURN_OBJECT(mc_obj);
    }
    
    MEDIA_DEBUG("Control type '%s' not supported", control_type);
    return NATIVE_RETURN_NULL();
}

/* ============================================
 * VolumeControl native methods
 * ============================================ */

/* VolumeControl.setLevel(int level) */
static JavaValue native_volumecontrol_setLevel(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* control_obj = (JavaObject*)args[0].ref;
    jint level = args[1].i;
    
    if (level < 0) level = 0;
    if (level > 100) level = 100;
    
    /* Find associated player */
    int player_id = control_obj->fields[1].i;  /* player_id field */
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].id == player_id) {
            if (g_players[i].type == PLAYER_TYPE_MIDI && g_players[i].midi) {
                midi_set_volume(g_players[i].midi, level / 100.0f);
            } else if (g_players[i].type == PLAYER_TYPE_WAV) {
                g_players[i].wav_volume = level / 100.0f;
            }
            break;
        }
    }
    
    MEDIA_DEBUG("VolumeControl.setLevel: %d", level);
    
    return NATIVE_RETURN_VOID();
}

/* VolumeControl.getLevel() */
static JavaValue native_volumecontrol_getLevel(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* control_obj = (JavaObject*)args[0].ref;
    
    int player_id = control_obj->fields[1].i;  /* player_id field */
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].id == player_id && g_players[i].type == PLAYER_TYPE_WAV) {
            return NATIVE_RETURN_INT((int)(g_players[i].wav_volume * 100));
        }
    }
    
    return NATIVE_RETURN_INT(100);
}

/* ============================================
 * MIDIControl native methods
 * ============================================ */

/* MIDIControl.shortMidiEvent(int type, int data1, int data2) */
static JavaValue native_midicontrol_shortMidiEvent(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint type = args[0].i;
    jint data1 = args[1].i;
    jint data2 = args[2].i;
    
    uint8_t status = (uint8_t)type;
    uint8_t channel = status & 0x0F;
    uint8_t event = status & 0xF0;
    
    switch (event) {
        case 0x80:  /* Note Off */
            midi_note_off(channel, data1);
            break;
        case 0x90:  /* Note On */
            midi_note_on(channel, data1, data2);
            break;
        case 0xB0:  /* Control Change */
            midi_control_change(channel, data1, data2);
            break;
        case 0xC0:  /* Program Change */
            midi_program_change(channel, data1);
            break;
        case 0xE0:  /* Pitch Bend */
            midi_pitch_bend(channel, (data2 << 7) | data1);
            break;
    }
    
    return NATIVE_RETURN_VOID();
}

/* MIDIControl.longMidiEvent(byte[] data, int offset, int length) */
static JavaValue native_midicontrol_longMidiEvent(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaArray* data_arr = (JavaArray*)args[0].ref;
    jint offset = args[1].i;
    jint length = args[2].i;
    
    if (!data_arr) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* TODO: Process SysEx message */
    MEDIA_DEBUG("MIDIControl.longMidiEvent: offset=%d, length=%d", offset, length);
    
    return NATIVE_RETURN_INT(length);
}

/* ============================================
 * Internal: Create player from data
 * ============================================ */

int media_create_player_from_data(const uint8_t* data, uint32_t size, const char* type) {
    ensure_audio_init();
    
    int slot = find_free_player_slot();
    if (slot < 0) return -1;
    
    /* Determine content type */
    bool is_midi = false;
    bool is_wav = false;
    
    if (type) {
        if (strcmp(type, "audio/midi") == 0 ||
            strcmp(type, "audio/mid") == 0 ||
            strcmp(type, "audio/x-midi") == 0) {
            is_midi = true;
        } else if (strcmp(type, "audio/x-wav") == 0 ||
                   strcmp(type, "audio/wav") == 0 ||
                   strcmp(type, "wave") == 0 ||
                   strcmp(type, "audio/wave") == 0) {
            is_wav = true;
        }
    }
    
    /* Also check headers */
    if (!is_midi && !is_wav && size >= 4) {
        if (memcmp(data, "MThd", 4) == 0) {
            is_midi = true;
        } else if (memcmp(data, "RIFF", 4) == 0) {
            is_wav = true;
        }
    }
    
    if (!is_midi && !is_wav) {
        MEDIA_DEBUG("Unsupported content type: %s", type ? type : "unknown");
        return -1;
    }
    
    /* Initialize player slot */
    g_players[slot].id = g_next_player_id++;
    g_players[slot].playing = false;
    g_players[slot].looping = false;
    g_players[slot].content_type = strdup(type ? type : (is_midi ? "audio/midi" : "audio/x-wav"));
    g_players[slot].data = (uint8_t*)malloc(size);
    if (g_players[slot].data) {
        memcpy(g_players[slot].data, data, size);
    }
    g_players[slot].size = size;
    g_players[slot].wav_volume = 1.0f;
    
    if (is_midi) {
        /* Load MIDI file */
        MidiFile* midi = midi_load(data, size);
        if (!midi) {
            MEDIA_DEBUG("Failed to load MIDI file");
            free(g_players[slot].data);
            free(g_players[slot].content_type);
            g_players[slot].content_type = NULL;  /* ИСПРАВЛЕНО: предотвращаем dangling pointer */
            g_players[slot].type = PLAYER_TYPE_NONE;
            g_players[slot].id = 0;
            return -1;
        }
        
        g_players[slot].type = PLAYER_TYPE_MIDI;
        g_players[slot].midi = midi;
        
        MEDIA_DEBUG("Created MIDI player id=%d", g_players[slot].id);
    } else {
        /* Load WAV file */
        WavFile* wav = wav_parse(data, size);
        if (!wav) {
            MEDIA_DEBUG("Failed to load WAV file");
            free(g_players[slot].data);
            free(g_players[slot].content_type);
            g_players[slot].content_type = NULL;  /* ИСПРАВЛЕНО: предотвращаем dangling pointer */
            g_players[slot].type = PLAYER_TYPE_NONE;
            g_players[slot].id = 0;
            return -1;
        }
        
        g_players[slot].type = PLAYER_TYPE_WAV;
        g_players[slot].wav = wav;
        g_players[slot].wav_position = 0;
        
        MEDIA_DEBUG("Created WAV player id=%d", g_players[slot].id);
    }
    
    return g_players[slot].id;
}

/* ============================================
 * Audio Generation for SDL callback
 * ============================================ */

/* Get MIDI file for audio generation */
MidiFile* media_get_midi_for_audio(void) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].playing && g_players[i].type == PLAYER_TYPE_MIDI && g_players[i].midi) {
            return g_players[i].midi;
        }
    }
    return NULL;
}

/* Generate WAV samples - resample to target rate and mix */
void media_generate_wav_samples(int16_t* buffer, int samples_needed) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (!g_players[i].playing || g_players[i].type != PLAYER_TYPE_WAV || !g_players[i].wav) {
            continue;
        }
        
        WavFile* wav = g_players[i].wav;
        float volume = g_players[i].wav_volume;
        
        /* Calculate resampling ratio (44100 Hz output) */
        float ratio = (float)wav->sample_rate / 44100.0f;
        
        for (int s = 0; s < samples_needed; s++) {
            /* Check if we need to loop or stop */
            if (g_players[i].wav_position >= wav->data_size) {
                if (g_players[i].looping) {
                    g_players[i].wav_position = 0;
                } else {
                    g_players[i].playing = false;
                    break;
                }
            }
            
            /* Calculate source position */
            uint32_t src_pos = (uint32_t)(s * ratio) + g_players[i].wav_position;
            if (src_pos >= wav->data_size) {
                src_pos = wav->data_size - 1;
            }
            
            int16_t sample_left = 0;
            int16_t sample_right = 0;
            
            /* Read sample based on format */
            if (wav->bits_per_sample == 8) {
                /* 8-bit unsigned */
                uint8_t l = wav->data[src_pos];
                sample_left = (int16_t)((l - 128) * 256);
                if (wav->num_channels >= 2 && src_pos + 1 < wav->data_size) {
                    uint8_t r = wav->data[src_pos + 1];
                    sample_right = (int16_t)((r - 128) * 256);
                } else {
                    sample_right = sample_left;
                }
                src_pos += wav->num_channels;
            } else if (wav->bits_per_sample == 16) {
                /* 16-bit signed */
                if (src_pos + 1 < wav->data_size) {
                    sample_left = (int16_t)(wav->data[src_pos] | (wav->data[src_pos + 1] << 8));
                }
                if (wav->num_channels >= 2 && src_pos + 3 < wav->data_size) {
                    sample_right = (int16_t)(wav->data[src_pos + 2] | (wav->data[src_pos + 3] << 8));
                    src_pos += 4;
                } else {
                    sample_right = sample_left;
                    src_pos += 2;
                }
            }
            
            /* Apply volume and mix into buffer with clipping */
            int32_t mixed_left = (int32_t)(sample_left * volume);
            int32_t mixed_right = (int32_t)(sample_right * volume);
            
            /* ИСПРАВЛЕНО: Clip to int16_t range to prevent distortion */
            int32_t existing_left = buffer[s * 2];
            int32_t existing_right = buffer[s * 2 + 1];
            int32_t result_left = existing_left + mixed_left;
            int32_t result_right = existing_right + mixed_right;
            
            /* Hard clipping */
            if (result_left > 32767) result_left = 32767;
            else if (result_left < -32768) result_left = -32768;
            if (result_right > 32767) result_right = 32767;
            else if (result_right < -32768) result_right = -32768;
            
            buffer[s * 2] = (int16_t)result_left;
            buffer[s * 2 + 1] = (int16_t)result_right;
        }
        
        /* Update position for next callback */
        g_players[i].wav_position += (uint32_t)(samples_needed * ratio * wav->num_channels * (wav->bits_per_sample / 8));
    }
}

/* ============================================
 * Initialize media native methods
 * ============================================ */

void init_javax_microedition_media(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Manager */
        {"javax/microedition/media/Manager", "createPlayer", 
         "(Ljava/lang/String;)Ljavax/microedition/media/Player;", 
         native_manager_createPlayer_locator},
        {"javax/microedition/media/Manager", "createPlayer",
         "(Ljava/io/InputStream;Ljava/lang/String;)Ljavax/microedition/media/Player;",
         native_manager_createPlayer_stream},
        {"javax/microedition/media/Manager", "playTone",
         "(III)V",
         native_manager_playTone},
        
        /* Player interface methods */
        {"javax/microedition/media/Player", "realize", "()V", native_player_realize},
        {"javax/microedition/media/Player", "prefetch", "()V", native_player_prefetch},
        {"javax/microedition/media/Player", "start", "()V", native_player_start},
        {"javax/microedition/media/Player", "stop", "()V", native_player_stop},
        {"javax/microedition/media/Player", "deallocate", "()V", native_player_deallocate},
        {"javax/microedition/media/Player", "close", "()V", native_player_close},
        {"javax/microedition/media/Player", "setLoopCount", "(I)V", native_player_setLoopCount},
        {"javax/microedition/media/Player", "getDuration", "()J", native_player_getDuration},
        {"javax/microedition/media/Player", "getMediaTime", "()J", native_player_getMediaTime},
        {"javax/microedition/media/Player", "getState", "()I", native_player_getState},
        {"javax/microedition/media/Player", "getContentType", "()Ljava/lang/String;", native_player_getContentType},
        {"javax/microedition/media/Player", "getControl", "(Ljava/lang/String;)Ljavax/microedition/media/Control;", native_player_getControl},
        
        /* PlayerImpl concrete class methods (same implementations) */
        {"javax/microedition/media/PlayerImpl", "realize", "()V", native_player_realize},
        {"javax/microedition/media/PlayerImpl", "prefetch", "()V", native_player_prefetch},
        {"javax/microedition/media/PlayerImpl", "start", "()V", native_player_start},
        {"javax/microedition/media/PlayerImpl", "stop", "()V", native_player_stop},
        {"javax/microedition/media/PlayerImpl", "deallocate", "()V", native_player_deallocate},
        {"javax/microedition/media/PlayerImpl", "close", "()V", native_player_close},
        {"javax/microedition/media/PlayerImpl", "setLoopCount", "(I)V", native_player_setLoopCount},
        {"javax/microedition/media/PlayerImpl", "getDuration", "()J", native_player_getDuration},
        {"javax/microedition/media/PlayerImpl", "getMediaTime", "()J", native_player_getMediaTime},
        {"javax/microedition/media/PlayerImpl", "getState", "()I", native_player_getState},
        {"javax/microedition/media/PlayerImpl", "getContentType", "()Ljava/lang/String;", native_player_getContentType},
        {"javax/microedition/media/PlayerImpl", "getControl", "(Ljava/lang/String;)Ljavax/microedition/media/Control;", native_player_getControl},
        
        /* VolumeControl */
        {"javax/microedition/media/control/VolumeControl", "setLevel", "(I)V", native_volumecontrol_setLevel},
        {"javax/microedition/media/control/VolumeControl", "getLevel", "()I", native_volumecontrol_getLevel},
        
        /* MIDIControl */
        {"javax/microedition/media/control/MIDIControl", "shortMidiEvent", "(III)V", native_midicontrol_shortMidiEvent},
        {"javax/microedition/media/control/MIDIControl", "longMidiEvent", "([BII)I", native_midicontrol_longMidiEvent},
    };
    
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    MEDIA_DEBUG("Registered %zu media native methods", 
            sizeof(methods) / sizeof(methods[0]));
}
