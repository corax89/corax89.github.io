/*
 * J2ME Emulator - JSR 184 Mobile 3D Graphics API (Software Implementation)
 * 
 * This implements the M3G (Mobile 3D Graphics) API in pure software mode.
 * JSR 184 provides a retained-mode 3D graphics API for mobile devices.
 * 
 * Implemented features:
 * - Graphics3D rendering context
 * - Transform (4x4 matrix operations)
 * - VertexArray (vertex data storage)
 * - IndexBuffer (triangle indices)
 * - Mesh (renderable 3D objects)
 * - Camera (view/projection)
 * - Light (directional, point, spot)
 * - Material and Texture2D
 * - Background
 * - World (scene graph)
 * - Software rasterization with Z-buffer
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup */
#endif

#include <stdio.h>
#include "debug.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"  /* For T_* array type constants */
#include "midp.h"     /* For load_jar_resource */

/* ============================================================================
 * HELPER FUNCTIONS FOR FIELD ACCESS
 * ============================================================================ */

/* Find the slot index for a named field in an object.
 * This correctly traverses the class hierarchy from Object down to the actual class,
 * calculating the cumulative slot index for instance fields.
 * Returns -1 if field not found. */
static int m3g_find_field_slot(JavaObject* obj, const char* field_name) {
    if (!obj || !field_name) return -1;
    
    JavaClass* clazz = obj->header.clazz;
    if (!clazz) return -1;
    
    /* Build class hierarchy from Object to actual class */
    JavaClass* hierarchy[64];
    int depth = 0;
    JavaClass* c = clazz;
    while (c && depth < 64) {
        hierarchy[depth++] = c;
        c = c->super_class;
    }
    
    /* Search for field and calculate slot from Object down to actual class */
    int slot = 0;
    for (int h = depth - 1; h >= 0; h--) {
        JavaClass* current = hierarchy[h];
        if (!current->fields) continue;
        
        for (int i = 0; i < current->fields_count; i++) {
            JavaField* field = &current->fields[i];
            
            /* Skip static fields */
            if (field->access_flags & ACC_STATIC) continue;
            
            if (field->name && strcmp(field->name, field_name) == 0) {
                return slot;
            }
            
            slot++;
            /* Long and double take 2 slots */
            if (field->descriptor && 
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                slot++;
            }
        }
    }
    
    return -1;  /* Field not found */
}

/* Helper to get an int field value by name */
static jint m3g_get_int_field(JavaObject* obj, const char* field_name, jint default_val) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return obj->fields[slot].i;
    }
    return default_val;
}

/* Helper to set an int field value by name */
static void m3g_set_int_field(JavaObject* obj, const char* field_name, jint value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].i = value;
    }
}

/* Helper to get a float field value by name */
static jfloat m3g_get_float_field(JavaObject* obj, const char* field_name, jfloat default_val) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return obj->fields[slot].f;
    }
    return default_val;
}

/* Helper to set a float field value by name */
static void m3g_set_float_field(JavaObject* obj, const char* field_name, jfloat value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].f = value;
    }
}

/* Helper to get a reference field value by name */
static JavaObject* m3g_get_ref_field(JavaObject* obj, const char* field_name) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return (JavaObject*)obj->fields[slot].ref;
    }
    return NULL;
}

/* Helper to set a reference field value by name */
static void m3g_set_ref_field(JavaObject* obj, const char* field_name, JavaObject* value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].ref = value;
    }
}

/* ============================================================================
 * M3G Constants (from JSR 184 specification)
 * ============================================================================ */

/* Light types */
#define M3G_LIGHT_AMBIENT       1
#define M3G_LIGHT_DIRECTIONAL   2
#define M3G_LIGHT_OMNI          4
#define M3G_LIGHT_SPOT          8

/* Material components */
#define M3G_MATERIAL_AMBIENT    1
#define M3G_MATERIAL_DIFFUSE    2
#define M3G_MATERIAL_EMISSIVE   4
#define M3G_MATERIAL_SPECULAR   8

/* Rendering hints */
#define M3G_ANTIALIAS           1
#define M3G_DITHER              2
#define M3G_TRUE_COLOR          4

/* Compositing modes */
#define M3G_ALPHA_BLEND         64
#define M3G_ALPHA_ADDITIVE      65
#define M3G_ALPHA_MULTIPLY      66
#define M3G_ALPHA_REPLACE       67

/* Polygon modes */
#define M3G_POLYGON_MODE_SOLID          64
#define M3G_POLYGON_MODE_WIREFRAME      65
#define M3G_POLYGON_MODE_POINT          66
#define M3G_POLYGON_MODE_POINT_SPRITE   67

/* Crop modes */
#define M3G_CROP_CENTER        96
#define M3G_CROP_STRETCH       97
#define M3G_CROP_FILL          98

/* ============================================================================
 * M3G Internal Data Structures
 * ============================================================================ */

/* 4x4 Transformation Matrix (column-major, OpenGL style) */
typedef struct {
    float m[16];  /* Column-major: m[col*4+row] */
} M3GTransform;

/* Vertex data */
typedef struct {
    float* positions;     /* XYZ positions */
    float* normals;       /* XYZ normals (optional) */
    float* texcoords;     /* UV coordinates (optional) */
    uint8_t* colors;      /* RGBA colors (optional) */
    int vertex_count;
    int vertex_stride;    /* Components per vertex */
} M3GVertexArray;

/* Triangle indices */
typedef struct {
    uint16_t* indices;
    int index_count;
    int primitive_type;   /* TRIANGLES=4, LINES=3, POINTS=2 */
} M3GIndexBuffer;

/* Material properties */
typedef struct {
    float ambient[4];     /* RGBA */
    float diffuse[4];
    float specular[4];
    float emissive[4];
    float shininess;
} M3GMaterial;

/* Texture data */
typedef struct {
    uint32_t* pixels;     /* ARGB pixels */
    int width;
    int height;
    int blend_s, blend_t; /* Wrapping mode */
    int filter_level;
} M3GTexture2D;

/* Light source */
typedef struct {
    int type;             /* AMBIENT, DIRECTIONAL, OMNI, SPOT */
    float color[4];       /* RGBA intensity */
    float direction[4];   /* For directional/spot */
    float position[4];    /* For omni/spot */
    float attenuation[3]; /* Constant, linear, quadratic */
    float spot_angle;     /* Spot cone angle */
    float spot_exponent;
} M3GLight;

/* Appearance state */
typedef struct {
    M3GMaterial* material;
    M3GTexture2D* texture;
    int compositing_mode;
    int polygon_mode;
    int layer;
} M3GAppearance;

/* Mesh object */
typedef struct {
    M3GVertexArray* vertices;
    M3GIndexBuffer* indices;
    M3GAppearance* appearance;
    int submesh_count;
} M3GMesh;

/* Camera */
typedef struct {
    float position[3];
    float look_at[3];
    float up[3];
    float fov;            /* Field of view in degrees */
    float aspect;         /* Width / Height */
    float near_plane;
    float far_plane;
    int projection_type;  /* 0=perspective, 1=parallel */
} M3GCamera;

/* Rendering context */
typedef struct {
    /* Viewport */
    int viewport_x, viewport_y;
    int viewport_width, viewport_height;
    
    /* Target buffer */
    uint32_t* color_buffer;
    float* depth_buffer;
    int buffer_width, buffer_height;
    
    /* Current transformation */
    M3GTransform modelview;
    M3GTransform projection;
    M3GTransform mvp;     /* ModelView * Projection */
    
    /* Lights (max 8) */
    M3GLight lights[8];
    int light_count;
    
    /* Global ambient */
    float ambient_light[4];
    
    /* Render states */
    int depth_test_enabled;
    int depth_write_enabled;
    int blending_enabled;
    int culling_enabled;    /* Back-face culling */
    
    /* Statistics */
    int triangles_rendered;
    int vertices_processed;
} M3GContext;

/* Global M3G context */
static M3GContext g_m3g;

/* ============================================================================
 * M3G Math Functions
 * ============================================================================ */

/* Create identity matrix */
static void m3g_transform_identity(M3GTransform* t) {
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = 1.0f;   t->m[5] = 1.0f;   t->m[10] = 1.0f;  t->m[15] = 1.0f;
}

/* Multiply two matrices: result = a * b */
static void m3g_transform_multiply(M3GTransform* result, 
                                    const M3GTransform* a, 
                                    const M3GTransform* b) {
    float r[16];
    for (int col = 0; col < 4; col++) {
        for (int row = 0; row < 4; row++) {
            float sum = 0.0f;
            for (int k = 0; k < 4; k++) {
                sum += a->m[k * 4 + row] * b->m[col * 4 + k];
            }
            r[col * 4 + row] = sum;
        }
    }
    memcpy(result->m, r, sizeof(r));
}

/* Translate */
static void m3g_transform_translate(M3GTransform* t, float x, float y, float z) {
    M3GTransform trans;
    m3g_transform_identity(&trans);
    trans.m[12] = x;  trans.m[13] = y;  trans.m[14] = z;
    m3g_transform_multiply(t, t, &trans);
}

/* Scale */
static void m3g_transform_scale(M3GTransform* t, float x, float y, float z) {
    M3GTransform scale;
    m3g_transform_identity(&scale);
    scale.m[0] = x;  scale.m[5] = y;  scale.m[10] = z;
    m3g_transform_multiply(t, t, &scale);
}

/* Rotate around axis (angle in radians) */
static void m3g_transform_rotate(M3GTransform* t, float angle, 
                                  float ax, float ay, float az) {
    /* Normalize axis */
    float len = sqrtf(ax*ax + ay*ay + az*az);
    if (len < 0.0001f) return;
    ax /= len;  ay /= len;  az /= len;
    
    float c = cosf(angle);
    float s = sinf(angle);
    float omc = 1.0f - c;
    
    M3GTransform rot;
    m3g_transform_identity(&rot);
    
    rot.m[0] = ax*ax*omc + c;
    rot.m[1] = ax*ay*omc + az*s;
    rot.m[2] = ax*az*omc - ay*s;
    
    rot.m[4] = ax*ay*omc - az*s;
    rot.m[5] = ay*ay*omc + c;
    rot.m[6] = ay*az*omc + ax*s;
    
    rot.m[8] = ax*az*omc + ay*s;
    rot.m[9] = ay*az*omc - ax*s;
    rot.m[10] = az*az*omc + c;
    
    m3g_transform_multiply(t, t, &rot);
}

/* Set perspective projection */
static void m3g_transform_perspective(M3GTransform* t, float fov, 
                                       float aspect, float near, float far) {
    float f = 1.0f / tanf(fov * 3.14159f / 360.0f);
    float range = 1.0f / (near - far);
    
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = f / aspect;
    t->m[5] = f;
    t->m[10] = (near + far) * range;
    t->m[11] = -1.0f;
    t->m[14] = 2.0f * near * far * range;
}

/* Set orthographic projection */
static void m3g_transform_ortho(M3GTransform* t, float left, float right,
                                 float bottom, float top, float near, float far) {
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = 2.0f / (right - left);
    t->m[5] = 2.0f / (top - bottom);
    t->m[10] = 2.0f / (near - far);
    t->m[12] = -(right + left) / (right - left);
    t->m[13] = -(top + bottom) / (top - bottom);
    t->m[14] = (near + far) / (near - far);
    t->m[15] = 1.0f;
}

/* Set look-at matrix */
static void m3g_transform_look_at(M3GTransform* t,
                                   float eye_x, float eye_y, float eye_z,
                                   float at_x, float at_y, float at_z,
                                   float up_x, float up_y, float up_z) {
    /* Forward vector (Z) */
    float fx = at_x - eye_x;
    float fy = at_y - eye_y;
    float fz = at_z - eye_z;
    float flen = sqrtf(fx*fx + fy*fy + fz*fz);
    fx /= flen; fy /= flen; fz /= flen;
    
    /* Side vector (X) = forward x up */
    float sx = fy * up_z - fz * up_y;
    float sy = fz * up_x - fx * up_z;
    float sz = fx * up_y - fy * up_x;
    float slen = sqrtf(sx*sx + sy*sy + sz*sz);
    sx /= slen; sy /= slen; sz /= slen;
    
    /* Recalculate up (Y) = side x forward */
    float ux = sy * fz - sz * fy;
    float uy = sz * fx - sx * fz;
    float uz = sx * fy - sy * fx;
    
    /* Build rotation matrix */
    t->m[0] = sx;   t->m[4] = ux;   t->m[8]  = -fx;  t->m[12] = 0;
    t->m[1] = sy;   t->m[5] = uy;   t->m[9]  = -fy;  t->m[13] = 0;
    t->m[2] = sz;   t->m[6] = uz;   t->m[10] = -fz;  t->m[14] = 0;
    t->m[3] = 0;    t->m[7] = 0;    t->m[11] = 0;    t->m[15] = 1;
    
    /* Apply translation */
    M3GTransform trans;
    m3g_transform_identity(&trans);
    trans.m[12] = -eye_x;
    trans.m[13] = -eye_y;
    trans.m[14] = -eye_z;
    m3g_transform_multiply(t, t, &trans);
}

/* Transform a point by matrix */
static void m3g_transform_point(float* result, const M3GTransform* t, 
                                 const float* point) {
    float x = point[0], y = point[1], z = point[2], w = point[3];
    result[0] = t->m[0]*x + t->m[4]*y + t->m[8]*z + t->m[12]*w;
    result[1] = t->m[1]*x + t->m[5]*y + t->m[9]*z + t->m[13]*w;
    result[2] = t->m[2]*x + t->m[6]*y + t->m[10]*z + t->m[14]*w;
    result[3] = t->m[3]*x + t->m[7]*y + t->m[11]*z + t->m[15]*w;
}

/* Transform a vector (no translation) */
static void m3g_transform_vector(float* result, const M3GTransform* t,
                                  const float* vec) {
    float x = vec[0], y = vec[1], z = vec[2];
    result[0] = t->m[0]*x + t->m[4]*y + t->m[8]*z;
    result[1] = t->m[1]*x + t->m[5]*y + t->m[9]*z;
    result[2] = t->m[2]*x + t->m[6]*y + t->m[10]*z;
}

/* Vector operations */
static void m3g_vec3_normalize(float* v) {
    float len = sqrtf(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    if (len > 0.0001f) {
        v[0] /= len; v[1] /= len; v[2] /= len;
    }
}

static void m3g_vec3_cross(float* result, const float* a, const float* b) {
    result[0] = a[1]*b[2] - a[2]*b[1];
    result[1] = a[2]*b[0] - a[0]*b[2];
    result[2] = a[0]*b[1] - a[1]*b[0];
}

static float m3g_vec3_dot(const float* a, const float* b) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

/* ============================================================================
 * M3G Software Rasterizer
 * ============================================================================ */

/* Initialize M3G context */
static void m3g_context_init(int width, int height) {
    memset(&g_m3g, 0, sizeof(g_m3g));
    
    g_m3g.buffer_width = width;
    g_m3g.buffer_height = height;
    g_m3g.viewport_width = width;
    g_m3g.viewport_height = height;
    
    g_m3g.color_buffer = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    g_m3g.depth_buffer = (float*)calloc(width * height, sizeof(float));
    
    /* Initialize transforms */
    m3g_transform_identity(&g_m3g.modelview);
    m3g_transform_identity(&g_m3g.projection);
    m3g_transform_identity(&g_m3g.mvp);
    
    /* Default render state */
    g_m3g.depth_test_enabled = 1;
    g_m3g.depth_write_enabled = 1;
    g_m3g.culling_enabled = 1;
    
    /* Default ambient */
    g_m3g.ambient_light[0] = 0.2f;
    g_m3g.ambient_light[1] = 0.2f;
    g_m3g.ambient_light[2] = 0.2f;
    g_m3g.ambient_light[3] = 1.0f;
    
    GFX_DEBUG("Context initialized: %dx%d", width, height);
}

/* Clear buffers */
static void m3g_clear(float r, float g, float b, float a, float depth) {
    uint32_t color = ((uint32_t)(a * 255) << 24) |
                     ((uint32_t)(r * 255) << 16) |
                     ((uint32_t)(g * 255) << 8) |
                     ((uint32_t)(b * 255));
    
    for (int i = 0; i < g_m3g.buffer_width * g_m3g.buffer_height; i++) {
        g_m3g.color_buffer[i] = color;
        g_m3g.depth_buffer[i] = depth;
    }
}

/* Convert clip coordinates to screen coordinates */
static void m3g_clip_to_screen(float* screen, const float* clip) {
    /* Perspective divide */
    float w = clip[3];
    if (fabsf(w) < 0.0001f) w = 0.0001f;
    
    float ndc_x = clip[0] / w;
    float ndc_y = clip[1] / w;
    float ndc_z = clip[2] / w;
    
    /* NDC to screen */
    screen[0] = (ndc_x + 1.0f) * 0.5f * g_m3g.viewport_width + g_m3g.viewport_x;
    screen[1] = (1.0f - ndc_y) * 0.5f * g_m3g.viewport_height + g_m3g.viewport_y;  /* Y-flip */
    screen[2] = (ndc_z + 1.0f) * 0.5f;  /* Depth to [0,1] */
    screen[3] = 1.0f / w;  /* 1/w for perspective correction */
}

/* Edge function for triangle rasterization */
static inline float m3g_edge_function(const float* a, const float* b, const float* c) {
    return (c[0] - a[0]) * (b[1] - a[1]) - (c[1] - a[1]) * (b[0] - a[0]);
}

/* Compute barycentric coordinates */
static void m3g_barycentric(float* bary, const float* v0, const float* v1, 
                            const float* v2, float x, float y) {
    float area = m3g_edge_function(v0, v1, v2);
    if (fabsf(area) < 0.0001f) {
        bary[0] = bary[1] = bary[2] = 0;
        return;
    }
    
    float p[2] = {x, y};
    bary[0] = m3g_edge_function(v1, v2, p) / area;
    bary[1] = m3g_edge_function(v2, v0, p) / area;
    bary[2] = m3g_edge_function(v0, v1, p) / area;
}

/* Simple color interpolation */
static void m3g_interpolate_color(uint8_t* result, 
                                   const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                   float w0, float w1, float w2) {
    for (int i = 0; i < 4; i++) {
        result[i] = (uint8_t)(c0[i] * w0 + c1[i] * w1 + c2[i] * w2);
    }
}

/* Interpolate texture coordinates */
static void m3g_interpolate_texcoord(float* result,
                                      const float* t0, const float* t1, const float* t2,
                                      float w0, float w1, float w2, float one_over_w) {
    /* Perspective-correct interpolation */
    float u = (t0[0] * w0 + t1[0] * w1 + t2[0] * w2) * one_over_w;
    float v = (t0[1] * w0 + t1[1] * w1 + t2[1] * w2) * one_over_w;
    result[0] = u;
    result[1] = v;
}

/* Sample texture (bilinear filtering) */
static uint32_t m3g_sample_texture(M3GTexture2D* tex, float u, float v) {
    if (!tex || !tex->pixels) return 0xFFFFFFFF;
    
    /* Wrap coordinates */
    u = u - floorf(u);
    v = v - floorf(v);
    if (u < 0) u += 1.0f;
    if (v < 0) v += 1.0f;
    
    /* Nearest neighbor (simple version) */
    int x = (int)(u * tex->width) % tex->width;
    int y = (int)(v * tex->height) % tex->height;
    if (x < 0) x += tex->width;
    if (y < 0) y += tex->height;
    
    return tex->pixels[y * tex->width + x];
}

/* Apply lighting to a vertex */
static void m3g_light_vertex(float* result, const float* position, 
                              const float* normal, M3GMaterial* mat) {
    /* Start with ambient */
    result[0] = g_m3g.ambient_light[0] * mat->ambient[0] + mat->emissive[0];
    result[1] = g_m3g.ambient_light[1] * mat->ambient[1] + mat->emissive[1];
    result[2] = g_m3g.ambient_light[2] * mat->ambient[2] + mat->emissive[2];
    
    float N[3] = {normal[0], normal[1], normal[2]};
    m3g_vec3_normalize(N);
    
    /* Process each light */
    for (int i = 0; i < g_m3g.light_count; i++) {
        M3GLight* light = &g_m3g.lights[i];
        
        float L[3];  /* Light direction */
        float attenuation = 1.0f;
        
        if (light->type == M3G_LIGHT_DIRECTIONAL) {
            L[0] = -light->direction[0];
            L[1] = -light->direction[1];
            L[2] = -light->direction[2];
        } else if (light->type == M3G_LIGHT_OMNI) {
            L[0] = light->position[0] - position[0];
            L[1] = light->position[1] - position[1];
            L[2] = light->position[2] - position[2];
            float dist = sqrtf(L[0]*L[0] + L[1]*L[1] + L[2]*L[2]);
            if (dist > 0.0001f) {
                L[0] /= dist; L[1] /= dist; L[2] /= dist;
            }
            attenuation = 1.0f / (light->attenuation[0] + 
                                  light->attenuation[1] * dist +
                                  light->attenuation[2] * dist * dist);
        } else {
            continue;  /* Skip unsupported light types */
        }
        
        /* Diffuse */
        float NdotL = m3g_vec3_dot(N, L);
        if (NdotL > 0) {
            result[0] += light->color[0] * mat->diffuse[0] * NdotL * attenuation;
            result[1] += light->color[1] * mat->diffuse[1] * NdotL * attenuation;
            result[2] += light->color[2] * mat->diffuse[2] * NdotL * attenuation;
        }
        
        /* Specular (simplified) */
        float V[3] = {0, 0, 1};  /* View direction (assumed) */
        float H[3];  /* Half vector */
        H[0] = L[0] + V[0];
        H[1] = L[1] + V[1];
        H[2] = L[2] + V[2];
        m3g_vec3_normalize(H);
        
        float NdotH = m3g_vec3_dot(N, H);
        if (NdotH > 0) {
            float spec = powf(NdotH, mat->shininess);
            result[0] += light->color[0] * mat->specular[0] * spec * attenuation;
            result[1] += light->color[1] * mat->specular[1] * spec * attenuation;
            result[2] += light->color[2] * mat->specular[2] * spec * attenuation;
        }
    }
    
    /* Clamp */
    result[0] = result[0] > 1.0f ? 1.0f : result[0];
    result[1] = result[1] > 1.0f ? 1.0f : result[1];
    result[2] = result[2] > 1.0f ? 1.0f : result[2];
}

/* Rasterize a single triangle */
static void m3g_rasterize_triangle(const float* v0, const float* v1, const float* v2,
                                    const float* t0, const float* t1, const float* t2,
                                    const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                    M3GAppearance* appearance) {
    /* Screen coordinates */
    float s0[4], s1[4], s2[4];
    m3g_clip_to_screen(s0, v0);
    m3g_clip_to_screen(s1, v1);
    m3g_clip_to_screen(s2, v2);
    
    /* Skip triangles outside viewport */
    if (s0[2] < 0 && s1[2] < 0 && s2[2] < 0) return;
    if (s0[2] > 1 && s1[2] > 1 && s2[2] > 1) return;
    
    /* Back-face culling */
    if (g_m3g.culling_enabled) {
        float e = m3g_edge_function(s0, s1, s2);
        if (e < 0) return;  /* Back-facing */
    }
    
    /* Bounding box */
    int min_x = (int)(s0[0] < s1[0] ? (s0[0] < s2[0] ? s0[0] : s2[0]) : (s1[0] < s2[0] ? s1[0] : s2[0]));
    int max_x = (int)(s0[0] > s1[0] ? (s0[0] > s2[0] ? s0[0] : s2[0]) : (s1[0] > s2[0] ? s1[0] : s2[0]));
    int min_y = (int)(s0[1] < s1[1] ? (s0[1] < s2[1] ? s0[1] : s2[1]) : (s1[1] < s2[1] ? s1[1] : s2[1]));
    int max_y = (int)(s0[1] > s1[1] ? (s0[1] > s2[1] ? s0[1] : s2[1]) : (s1[1] > s2[1] ? s1[1] : s2[1]));
    
    /* Clip to viewport */
    min_x = min_x < 0 ? 0 : min_x;
    max_x = max_x >= g_m3g.buffer_width ? g_m3g.buffer_width - 1 : max_x;
    min_y = min_y < 0 ? 0 : min_y;
    max_y = max_y >= g_m3g.buffer_height ? g_m3g.buffer_height - 1 : max_y;
    
    /* Area for barycentric */
    float area = m3g_edge_function(s0, s1, s2);
    if (fabsf(area) < 0.001f) return;
    
    /* Rasterize */
    for (int y = min_y; y <= max_y; y++) {
        for (int x = min_x; x <= max_x; x++) {
            float px = x + 0.5f;
            float py = y + 0.5f;
            
            /* Barycentric coordinates */
            float w0 = m3g_edge_function(s1, s2, (float[]){px, py}) / area;
            float w1 = m3g_edge_function(s2, s0, (float[]){px, py}) / area;
            float w2 = m3g_edge_function(s0, s1, (float[]){px, py}) / area;
            
            /* Inside triangle? */
            if (w0 < 0 || w1 < 0 || w2 < 0) continue;
            
            /* Depth test */
            float z = s0[2] * w0 + s1[2] * w1 + s2[2] * w2;
            int idx = y * g_m3g.buffer_width + x;
            
            if (g_m3g.depth_test_enabled && z > g_m3g.depth_buffer[idx]) {
                continue;  /* Failed depth test */
            }
            
            /* Perspective correction */
            float one_over_w = s0[3] * w0 + s1[3] * w1 + s2[3] * w2;
            
            /* Interpolate color */
            uint8_t color[4] = {255, 255, 255, 255};
            if (c0 && c1 && c2) {
                m3g_interpolate_color(color, c0, c1, c2, w0, w1, w2);
            }
            
            /* Texture sampling */
            if (appearance && appearance->texture && t0 && t1 && t2) {
                float uv[2];
                m3g_interpolate_texcoord(uv, t0, t1, t2, w0, w1, w2, one_over_w);
                uint32_t tex_color = m3g_sample_texture(appearance->texture, uv[0], uv[1]);
                
                /* Modulate with vertex color */
                uint8_t tr = (tex_color >> 16) & 0xFF;
                uint8_t tg = (tex_color >> 8) & 0xFF;
                uint8_t tb = tex_color & 0xFF;
                uint8_t ta = (tex_color >> 24) & 0xFF;
                
                color[0] = (uint8_t)(color[0] * tr / 255);
                color[1] = (uint8_t)(color[1] * tg / 255);
                color[2] = (uint8_t)(color[2] * tb / 255);
                color[3] = (uint8_t)(color[3] * ta / 255);
            }
            
            /* Write to buffers */
            g_m3g.color_buffer[idx] = (color[3] << 24) | (color[0] << 16) | 
                                       (color[1] << 8) | color[2];
            if (g_m3g.depth_write_enabled) {
                g_m3g.depth_buffer[idx] = z;
            }
        }
    }
    
    g_m3g.triangles_rendered++;
}

/* ============================================================================
 * Java Object <-> Native Object Mapping
 * ============================================================================ */

/* Get native transform from Java Transform object */
static M3GTransform* get_native_transform(JavaObject* obj) {
    if (!obj || !OBJECT_HAS_FIELDS(obj, 1)) return NULL;
    
    /* Transform stores 16 floats in a float[] field */
    JavaArray* arr = (JavaArray*)obj->fields[0].ref;
    if (!arr || arr->element_type != T_FLOAT) return NULL;
    
    /* We'll create a temp transform - for real use, cache it */
    static M3GTransform temp;
    float* data = (float*)array_data(arr);
    memcpy(temp.m, data, 16 * sizeof(float));
    return &temp;
}

/* Set native transform to Java Transform object */
static void set_native_transform(JavaObject* obj, M3GTransform* t) {
    if (!obj || !t || !OBJECT_HAS_FIELDS(obj, 1)) return;
    
    JavaArray* arr = (JavaArray*)obj->fields[0].ref;
    if (!arr || arr->element_type != T_FLOAT) return;
    
    float* data = (float*)array_data(arr);
    memcpy(data, t->m, 16 * sizeof(float));
}

/* Get VertexArray data */
static M3GVertexArray* get_vertex_array(JavaObject* obj, M3GVertexArray* temp) {
    if (!obj || !temp) return NULL;
    
    memset(temp, 0, sizeof(M3GVertexArray));
    
    /* VertexArray fields: data (byte[]/short[]), componentCount, componentSize, count */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    int component_count = m3g_get_int_field(obj, "componentCount", 3);
    int component_size = m3g_get_int_field(obj, "componentSize", 1);
    int vertex_count = m3g_get_int_field(obj, "vertexCount", 0);
    
    if (!data || vertex_count == 0) return NULL;
    
    /* Convert to float positions */
    temp->positions = (float*)malloc(vertex_count * 3 * sizeof(float));
    if (!temp->positions) return NULL;
    
    temp->vertex_count = vertex_count;
    temp->vertex_stride = component_count;
    
    if (component_size == 1) {
        int8_t* src = (int8_t*)array_data(data);
        for (int i = 0; i < vertex_count * component_count; i++) {
            temp->positions[i] = (float)src[i];
        }
    } else {
        int16_t* src = (int16_t*)array_data(data);
        for (int i = 0; i < vertex_count * component_count; i++) {
            temp->positions[i] = (float)src[i];
        }
    }
    
    return temp;
}

/* ============================================================================
 * Native Method Implementations
 * ============================================================================ */

/* Graphics3D.getInstance() */
static JavaValue native_graphics3d_getInstance(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    
    /* Find Graphics3D class */
    JavaClass* g3d_class = jvm_load_class(jvm, "javax/microedition/m3g/Graphics3D");
    if (!g3d_class) {
        GFX_DEBUG("Graphics3D class not found");
        return NATIVE_RETURN_NULL();
    }
    
    /* Check for static instance field */
    for (int i = 0; i < g3d_class->static_fields_count; i++) {
        if (strcmp(g3d_class->static_fields[i].name, "instance") == 0) {
            if (g3d_class->static_fields[i].value.ref) {
                return NATIVE_RETURN_OBJECT(g3d_class->static_fields[i].value.ref);
            }
            break;
        }
    }
    
    /* Create new instance */
    JavaObject* instance = jvm_new_object(jvm, g3d_class);
    if (!instance) {
        GFX_DEBUG("Failed to create Graphics3D instance");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store as static field */
    for (int i = 0; i < g3d_class->static_fields_count; i++) {
        if (strcmp(g3d_class->static_fields[i].name, "instance") == 0) {
            g3d_class->static_fields[i].value.ref = instance;
            break;
        }
    }
    
    GFX_DEBUG("Graphics3D.getInstance() -> %p", (void*)instance);
    return NATIVE_RETURN_OBJECT(instance);
}

/* Graphics3D.bindTarget(Image2D) */
static JavaValue native_graphics3d_bindTarget(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* target = (JavaObject*)args[1].ref;
    
    (void)g3d;  /* Instance not used in this simple impl */
    
    if (!target) {
        GFX_DEBUG("bindTarget: null target");
        return NATIVE_RETURN_VOID();
    }
    
    /* Get image dimensions from target */
    int width = m3g_get_int_field(target, "width", 240);
    int height = m3g_get_int_field(target, "height", 320);
    
    /* Initialize or reinitialize context */
    if (g_m3g.color_buffer) {
        free(g_m3g.color_buffer);
        free(g_m3g.depth_buffer);
    }
    m3g_context_init(width, height);
    
    GFX_DEBUG("bindTarget: %dx%d", width, height);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.releaseTarget() */
static JavaValue native_graphics3d_releaseTarget(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    GFX_DEBUG("releaseTarget: triangles=%d", g_m3g.triangles_rendered);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.clear(Background) */
static JavaValue native_graphics3d_clear(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* background = (JavaObject*)args[1].ref;
    
    float r = 0.0f, g = 0.0f, b = 0.0f, a = 1.0f;
    float depth = 1.0f;
    
    if (background) {
        /* Background has clearColor field (int ARGB) */
        int argb = m3g_get_int_field(background, "clearColor", 0);
        a = ((argb >> 24) & 0xFF) / 255.0f;
        r = ((argb >> 16) & 0xFF) / 255.0f;
        g = ((argb >> 8) & 0xFF) / 255.0f;
        b = (argb & 0xFF) / 255.0f;
    }
    
    m3g_clear(r, g, b, a, depth);
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setViewport(int x, int y, int width, int height) */
static JavaValue native_graphics3d_setViewport(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    (void)g3d;
    
    g_m3g.viewport_x = args[1].i;
    g_m3g.viewport_y = args[2].i;
    g_m3g.viewport_width = args[3].i;
    g_m3g.viewport_height = args[4].i;
    
    GFX_DEBUG("setViewport: %d,%d %dx%d", 
            g_m3g.viewport_x, g_m3g.viewport_y, 
            g_m3g.viewport_width, g_m3g.viewport_height);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.setIdentity() */
static JavaValue native_transform_setIdentity(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    M3GTransform t;
    m3g_transform_identity(&t);
    set_native_transform(obj, &t);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postMultiply(Transform) */
static JavaValue native_transform_postMultiply(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* other_obj = (JavaObject*)args[1].ref;
    
    M3GTransform this_t, other_t;
    if (!get_native_transform(this_obj) || !get_native_transform(other_obj)) {
        return NATIVE_RETURN_VOID();
    }
    
    memcpy(this_t.m, get_native_transform(this_obj)->m, sizeof(this_t.m));
    memcpy(other_t.m, get_native_transform(other_obj)->m, sizeof(other_t.m));
    
    M3GTransform result;
    m3g_transform_multiply(&result, &this_t, &other_t);
    set_native_transform(this_obj, &result);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postTranslate(float x, float y, float z) */
static JavaValue native_transform_postTranslate(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_translate(&temp, x, y, z);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postRotate(float angle, float ax, float ay, float az) */
static JavaValue native_transform_postRotate(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float angle = args[1].f * 3.14159f / 180.0f;  /* Degrees to radians */
    float ax = args[2].f;
    float ay = args[3].f;
    float az = args[4].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_rotate(&temp, angle, ax, ay, az);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postScale(float sx, float sy, float sz) */
static JavaValue native_transform_postScale(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float sx = args[1].f;
    float sy = args[2].f;
    float sz = args[3].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_scale(&temp, sx, sy, sz);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* VertexArray.<init>(int numVertices, int numComponents, int componentSize) */
static JavaValue native_vertexarray_init(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint num_vertices = args[1].i;
    jint num_components = args[2].i;
    jint component_size = args[3].i;
    
    if (!obj || num_vertices <= 0 || num_components < 2 || num_components > 4) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Create data array */
    int data_size = num_vertices * num_components * component_size;
    JavaArray* data = jvm_new_array(jvm, component_size == 1 ? T_BYTE : T_SHORT, data_size);
    if (!data) {
        GFX_DEBUG("VertexArray: failed to allocate data array");
        return NATIVE_RETURN_VOID();
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "data", (JavaObject*)data);
    m3g_set_int_field(obj, "componentCount", num_components);
    m3g_set_int_field(obj, "componentSize", component_size);
    m3g_set_int_field(obj, "vertexCount", num_vertices);
    
    GFX_DEBUG("VertexArray.init: %d vertices, %d components, %d bytes",
            num_vertices, num_components, component_size);
    
    return NATIVE_RETURN_VOID();
}

/* Camera.setPerspective(float fov, float aspectRatio, float near, float far) */
static JavaValue native_camera_setPerspective(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float fov = args[1].f;
    float aspect = args[2].f;
    float near = args[3].f;
    float far = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Update projection matrix */
    m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
    
    GFX_DEBUG("Camera.setPerspective: fov=%.1f, aspect=%.2f, near=%.2f, far=%.2f",
            fov, aspect, near, far);
    
    return NATIVE_RETURN_VOID();
}

/* Camera.setParallel(float height, float aspectRatio, float near, float far) */
static JavaValue native_camera_setParallel(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float height = args[1].f;
    float aspect = args[2].f;
    float near = args[3].f;
    float far = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    float half_h = height / 2.0f;
    float half_w = half_h * aspect;
    
    m3g_transform_ortho(&g_m3g.projection, -half_w, half_w, -half_h, half_h, near, far);
    
    GFX_DEBUG("Camera.setParallel: height=%.1f, aspect=%.2f", height, aspect);
    
    return NATIVE_RETURN_VOID();
}

/* Light.setType(int type) */
static JavaValue native_light_setType(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint type = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Add to lights array if new */
    int light_idx = -1;
    for (int i = 0; i < g_m3g.light_count; i++) {
        /* Check if this object is already registered */
        /* Simple approach: just use next slot */
    }
    
    if (g_m3g.light_count < 8) {
        light_idx = g_m3g.light_count++;
        g_m3g.lights[light_idx].type = type;
    }
    
    GFX_DEBUG("Light.setType: %d (idx=%d)", type, light_idx);
    
    return NATIVE_RETURN_VOID();
}

/* World.addCamera(Camera) */
static JavaValue native_world_addCamera(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* camera = (JavaObject*)args[1].ref;
    (void)world; (void)camera;
    
    GFX_DEBUG("World.addCamera");
    return NATIVE_RETURN_VOID();
}

/* World.setBackground(Background) */
static JavaValue native_world_setBackground(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* background = (JavaObject*)args[1].ref;
    (void)world; (void)background;
    
    GFX_DEBUG("World.setBackground");
    return NATIVE_RETURN_VOID();
}

/* World.render(World) - Simple version for testing */
static JavaValue native_graphics3d_renderWorld(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* world = (JavaObject*)args[1].ref;
    (void)g3d; (void)world;
    
    GFX_DEBUG("renderWorld: Basic rendering (placeholder)");
    
    /* Reset stats */
    g_m3g.triangles_rendered = 0;
    
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Extended M3G Native Methods - Additional JSR 184 Support
 * ============================================================================ */

/* VertexArray.set(int firstVertex, int numVertices, byte[] src) */
static JavaValue native_vertexarray_set_byte(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint count = args[2].i;
    JavaArray* src = (JavaArray*)args[3].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get internal data array using helper functions */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    int component_size = m3g_get_int_field(obj, "componentSize", 1);
    
    if (!data) return NATIVE_RETURN_VOID();
    
    /* Copy data */
    int8_t* dst_data = (int8_t*)array_data(data);
    int8_t* src_data = (int8_t*)array_data(src);
    
    int copy_count = count;
    if (first + copy_count > (int)data->length) {
        copy_count = (int)data->length - first;
    }
    
    if (copy_count > 0) {
        memcpy(dst_data + first, src_data, copy_count * component_size);
    }
    
    GFX_DEBUG("VertexArray.set: first=%d, count=%d", first, count);
    return NATIVE_RETURN_VOID();
}

/* VertexArray.set(int firstVertex, int numVertices, short[] src) */
static JavaValue native_vertexarray_set_short(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint count = args[2].i;
    JavaArray* src = (JavaArray*)args[3].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get internal data array using helper function */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    
    if (!data || data->element_type != T_SHORT) return NATIVE_RETURN_VOID();
    
    /* Copy data */
    int16_t* dst_data = (int16_t*)array_data(data);
    int16_t* src_data = (int16_t*)array_data(src);
    
    int copy_count = count;
    if (first + copy_count > (int)data->length) {
        copy_count = (int)data->length - first;
    }
    
    if (copy_count > 0) {
        memcpy(dst_data + first, src_data, copy_count * sizeof(int16_t));
    }
    
    GFX_DEBUG("VertexArray.set(short[]): first=%d, count=%d", first, count);
    return NATIVE_RETURN_VOID();
}

/* Transform.invert() */
static JavaValue native_transform_invert(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    M3GTransform* t = get_native_transform(obj);
    if (!t) return NATIVE_RETURN_VOID();
    
    /* 4x4 matrix inversion using Gauss-Jordan elimination */
    float m[16], inv[16];
    memcpy(m, t->m, sizeof(m));
    memset(inv, 0, sizeof(inv));
    inv[0] = inv[5] = inv[10] = inv[15] = 1.0f;
    
    for (int col = 0; col < 4; col++) {
        /* Find pivot */
        int pivot = col;
        for (int row = col + 1; row < 4; row++) {
            if (fabsf(m[row * 4 + col]) > fabsf(m[pivot * 4 + col])) {
                pivot = row;
            }
        }
        
        /* Swap rows */
        if (pivot != col) {
            for (int i = 0; i < 4; i++) {
                float tmp = m[col * 4 + i];
                m[col * 4 + i] = m[pivot * 4 + i];
                m[pivot * 4 + i] = tmp;
                
                tmp = inv[col * 4 + i];
                inv[col * 4 + i] = inv[pivot * 4 + i];
                inv[pivot * 4 + i] = tmp;
            }
        }
        
        /* Check for singular matrix */
        if (fabsf(m[col * 4 + col]) < 0.00001f) {
            GFX_DEBUG("Transform.invert: singular matrix");
            return NATIVE_RETURN_VOID();
        }
        
        /* Scale pivot row */
        float scale = m[col * 4 + col];
        for (int i = 0; i < 4; i++) {
            m[col * 4 + i] /= scale;
            inv[col * 4 + i] /= scale;
        }
        
        /* Eliminate column */
        for (int row = 0; row < 4; row++) {
            if (row != col) {
                float factor = m[row * 4 + col];
                for (int i = 0; i < 4; i++) {
                    m[row * 4 + i] -= factor * m[col * 4 + i];
                    inv[row * 4 + i] -= factor * inv[col * 4 + i];
                }
            }
        }
    }
    
    set_native_transform(obj, &(M3GTransform){.m = {inv[0], inv[1], inv[2], inv[3],
                                                    inv[4], inv[5], inv[6], inv[7],
                                                    inv[8], inv[9], inv[10], inv[11],
                                                    inv[12], inv[13], inv[14], inv[15]}});
    
    GFX_DEBUG("Transform.invert");
    return NATIVE_RETURN_VOID();
}

/* Transform.transform(float[] vectors) */
static JavaValue native_transform_transform(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* vectors = (JavaArray*)args[1].ref;
    
    if (!obj || !vectors || vectors->element_type != T_FLOAT) {
        return NATIVE_RETURN_VOID();
    }
    
    M3GTransform* t = get_native_transform(obj);
    if (!t) return NATIVE_RETURN_VOID();
    
    float* data = (float*)array_data(vectors);
    int count = vectors->length / 4;
    
    for (int i = 0; i < count; i++) {
        float x = data[i * 4 + 0];
        float y = data[i * 4 + 1];
        float z = data[i * 4 + 2];
        float w = data[i * 4 + 3];
        
        data[i * 4 + 0] = t->m[0]*x + t->m[4]*y + t->m[8]*z + t->m[12]*w;
        data[i * 4 + 1] = t->m[1]*x + t->m[5]*y + t->m[9]*z + t->m[13]*w;
        data[i * 4 + 2] = t->m[2]*x + t->m[6]*y + t->m[10]*z + t->m[14]*w;
        data[i * 4 + 3] = t->m[3]*x + t->m[7]*y + t->m[11]*z + t->m[15]*w;
    }
    
    GFX_DEBUG("Transform.transform: %d vectors", count);
    return NATIVE_RETURN_VOID();
}

/* Light.setColor(int ARGB) */
static JavaValue native_light_setColor(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Find light index from object (simplified: use next light) */
    if (g_m3g.light_count > 0) {
        M3GLight* light = &g_m3g.lights[g_m3g.light_count - 1];
        light->color[0] = ((argb >> 16) & 0xFF) / 255.0f;
        light->color[1] = ((argb >> 8) & 0xFF) / 255.0f;
        light->color[2] = (argb & 0xFF) / 255.0f;
        light->color[3] = ((argb >> 24) & 0xFF) / 255.0f;
    }
    
    GFX_DEBUG("Light.setColor: 0x%08X", argb);
    return NATIVE_RETURN_VOID();
}

/* Light.setIntensity(float intensity) */
static JavaValue native_light_setIntensity(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float intensity = args[1].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store in color's alpha or a separate field */
    if (g_m3g.light_count > 0) {
        M3GLight* light = &g_m3g.lights[g_m3g.light_count - 1];
        light->color[3] = intensity;
    }
    
    GFX_DEBUG("Light.setIntensity: %.2f", intensity);
    return NATIVE_RETURN_VOID();
}

/* Light.setDirection(float x, float y, float z) */
static JavaValue native_light_setDirection(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    if (g_m3g.light_count > 0) {
        M3GLight* light = &g_m3g.lights[g_m3g.light_count - 1];
        light->direction[0] = x;
        light->direction[1] = y;
        light->direction[2] = z;
        light->direction[3] = 0.0f;  /* Direction, not position */
    }
    
    GFX_DEBUG("Light.setDirection: (%.2f, %.2f, %.2f)", x, y, z);
    return NATIVE_RETURN_VOID();
}

/* Material.setColor(int target, int ARGB) */
static JavaValue native_material_setColor(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint target = args[1].i;
    jint argb = args[2].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store in fields using helper functions */
    if (target & M3G_MATERIAL_AMBIENT) {
        m3g_set_int_field(obj, "ambient", argb);
    }
    if (target & M3G_MATERIAL_DIFFUSE) {
        m3g_set_int_field(obj, "diffuse", argb);
    }
    if (target & M3G_MATERIAL_SPECULAR) {
        m3g_set_int_field(obj, "specular", argb);
    }
    if (target & M3G_MATERIAL_EMISSIVE) {
        m3g_set_int_field(obj, "emissive", argb);
    }
    
    GFX_DEBUG("Material.setColor: target=%d, ARGB=0x%08X", target, argb);
    return NATIVE_RETURN_VOID();
}

/* Material.setShininess(float shininess) */
static JavaValue native_material_setShininess(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float shininess = args[1].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store shininess using helper function */
    m3g_set_float_field(obj, "shininess", shininess);
    
    GFX_DEBUG("Material.setShininess: %.2f", shininess);
    return NATIVE_RETURN_VOID();
}

/* Appearance.setMaterial(Material) */
static JavaValue native_appearance_setMaterial(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* material = (JavaObject*)args[1].ref;
    (void)obj; (void)material;
    
    GFX_DEBUG("Appearance.setMaterial");
    return NATIVE_RETURN_VOID();
}

/* Appearance.setTexture(int index, Texture2D) */
static JavaValue native_appearance_setTexture(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* texture = (JavaObject*)args[2].ref;
    (void)obj; (void)index; (void)texture;
    
    GFX_DEBUG("Appearance.setTexture: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.<init>(Image2D) */
static JavaValue native_texture2d_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Get image data using helper functions */
    if (image) {
        m3g_set_ref_field(obj, "pixels", m3g_get_ref_field(image, "pixels"));
        m3g_set_int_field(obj, "width", m3g_get_int_field(image, "width", 64));
        m3g_set_int_field(obj, "height", m3g_get_int_field(image, "height", 64));
    }
    
    GFX_DEBUG("Texture2D.<init>: image=%p", (void*)image);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.setFiltering(int level) */
static JavaValue native_texture2d_setFiltering(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint level = args[1].i;
    (void)obj; (void)level;
    
    GFX_DEBUG("Texture2D.setFiltering: level=%d", level);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.setWrapping(int wrapS, int wrapT) */
static JavaValue native_texture2d_setWrapping(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint wrap_s = args[1].i;
    jint wrap_t = args[2].i;
    (void)obj; (void)wrap_s; (void)wrap_t;
    
    GFX_DEBUG("Texture2D.setWrapping: s=%d, t=%d", wrap_s, wrap_t);
    return NATIVE_RETURN_VOID();
}

/* Mesh.<init>(VertexArray, IndexBuffer, Appearance) */
static JavaValue native_mesh_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* vertices = (JavaObject*)args[1].ref;
    JavaObject* indices = (JavaObject*)args[2].ref;
    JavaObject* appearance = (JavaObject*)args[3].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store references using helper functions */
    m3g_set_ref_field(obj, "vertices", vertices);
    m3g_set_ref_field(obj, "indices", indices);
    m3g_set_ref_field(obj, "appearance", appearance);
    
    GFX_DEBUG("Mesh.<init>: vertices=%p, indices=%p, appearance=%p",
            (void*)vertices, (void*)indices, (void*)appearance);
    return NATIVE_RETURN_VOID();
}

/* TriangleStripArray.<init>(int firstIndex, int[] stripLengths) */
static JavaValue native_trianglestrip_init(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    JavaArray* lengths = (JavaArray*)args[2].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Calculate total indices needed */
    int total_indices = 0;
    int strip_count = lengths ? lengths->length : 0;
    jint* len_data = lengths ? (jint*)array_data(lengths) : NULL;
    
    for (int i = 0; i < strip_count; i++) {
        int strip_len = len_data[i];
        /* Each strip of n vertices produces (n-2) triangles */
        total_indices += (strip_len - 2) * 3;
    }
    
    /* Create index buffer */
    JavaArray* indices = jvm_new_array(jvm, T_SHORT, total_indices);
    if (indices) {
        int idx = 0;
        int vertex = first;
        
        for (int strip = 0; strip < strip_count; strip++) {
            int strip_len = len_data[strip];
            
            /* Generate triangle strip indices */
            for (int t = 0; t < strip_len - 2; t++) {
                int16_t* data = (int16_t*)array_data(indices);
                if (t % 2 == 0) {
                    data[idx++] = vertex + t;
                    data[idx++] = vertex + t + 1;
                    data[idx++] = vertex + t + 2;
                } else {
                    /* Swap last two for correct winding */
                    data[idx++] = vertex + t;
                    data[idx++] = vertex + t + 2;
                    data[idx++] = vertex + t + 1;
                }
            }
            vertex += strip_len;
        }
        
        /* Store index buffer using helper function */
        m3g_set_ref_field(obj, "indices", (JavaObject*)indices);
    }
    
    GFX_DEBUG("TriangleStripArray.<init>: first=%d, strips=%d, indices=%d",
            first, strip_count, total_indices);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.render(Node, Transform) - Immediate mode rendering */
static JavaValue native_graphics3d_render_node(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* node = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d; (void)node; (void)transform;
    
    GFX_DEBUG("Graphics3D.render(Node, Transform): immediate mode");
    
    /* TODO: Implement actual mesh rendering using software rasterizer */
    
    return NATIVE_RETURN_VOID();
}

/* Node.setScale(float sx, float sy, float sz) */
static JavaValue native_node_setScale(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float sx = args[1].f;
    float sy = args[2].f;
    float sz = args[3].f;
    (void)obj; (void)sx; (void)sy; (void)sz;
    
    GFX_DEBUG("Node.setScale: (%.2f, %.2f, %.2f)", sx, sy, sz);
    return NATIVE_RETURN_VOID();
}

/* Node.setTranslation(float x, float y, float z) */
static JavaValue native_node_setTranslation(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    (void)obj; (void)x; (void)y; (void)z;
    
    GFX_DEBUG("Node.setTranslation: (%.2f, %.2f, %.2f)", x, y, z);
    return NATIVE_RETURN_VOID();
}

/* Node.setRotation(float angle, float ax, float ay, float az) */
static JavaValue native_node_setRotation(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float angle = args[1].f;
    float ax = args[2].f;
    float ay = args[3].f;
    float az = args[4].f;
    (void)obj; (void)angle; (void)ax; (void)ay; (void)az;
    
    GFX_DEBUG("Node.setRotation: angle=%.1f, axis=(%.2f, %.2f, %.2f)", angle, ax, ay, az);
    return NATIVE_RETURN_VOID();
}

/* Camera.setGeneric(Transform) */
static JavaValue native_camera_setGeneric(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    (void)obj; (void)transform;
    
    GFX_DEBUG("Camera.setGeneric");
    return NATIVE_RETURN_VOID();
}

/* Background.setColor(int ARGB) */
static JavaValue native_background_setColor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store color using helper function */
    m3g_set_int_field(obj, "clearColor", argb);
    
    GFX_DEBUG("Background.setColor: 0x%08X", argb);
    return NATIVE_RETURN_VOID();
}

/* Image2D.<init>(int format, int width, int height) */
static JavaValue native_image2d_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint format = args[1].i;
    jint width = args[2].i;
    jint height = args[3].i;
    
    if (!obj || width <= 0 || height <= 0) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Create pixel array (ARGB format) */
    JavaArray* pixels = jvm_new_array(jvm, T_INT, width * height);
    if (!pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "pixels", (JavaObject*)pixels);
    m3g_set_int_field(obj, "width", width);
    m3g_set_int_field(obj, "height", height);
    m3g_set_int_field(obj, "format", format);
    
    GFX_DEBUG("Image2D.<init>: format=%d, %dx%d", format, width, height);
    return NATIVE_RETURN_VOID();
}

/* Image2D.<init>(int format, Object image) - creates Image2D from LCDUI Image */
static JavaValue native_image2d_init_from_image(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint format = args[1].i;
    JavaObject* image = (JavaObject*)args[2].ref;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    GFX_DEBUG("Image2D.<init>(int, Object): format=%d, image=%p", format, (void*)image);
    
    int width = 0, height = 0;
    JavaArray* src_pixels = NULL;
    
    /* Try to get image data from LCDUI Image object using helper functions */
    if (image) {
        width = m3g_get_int_field(image, "width", 0);
        height = m3g_get_int_field(image, "height", 0);
        src_pixels = (JavaArray*)m3g_get_ref_field(image, "pixels");
        if (!src_pixels) src_pixels = (JavaArray*)m3g_get_ref_field(image, "data");
        if (!src_pixels) src_pixels = (JavaArray*)m3g_get_ref_field(image, "imageData");
    }
    
    /* If no valid dimensions, use defaults */
    if (width <= 0) width = 64;
    if (height <= 0) height = 64;
    
    /* Create pixel array (ARGB format) */
    JavaArray* pixels = jvm_new_array(jvm, T_INT, width * height);
    if (!pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Copy source pixels if available */
    if (src_pixels && src_pixels->length > 0) {
        int copy_count = src_pixels->length < width * height ? src_pixels->length : width * height;
        jint* dst_data = (jint*)((uint8_t*)pixels + sizeof(JavaArray));
        jint* src_data = (jint*)((uint8_t*)src_pixels + sizeof(JavaArray));
        for (int i = 0; i < copy_count; i++) {
            dst_data[i] = src_data[i];
        }
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "pixels", (JavaObject*)pixels);
    m3g_set_int_field(obj, "width", width);
    m3g_set_int_field(obj, "height", height);
    m3g_set_int_field(obj, "format", format);
    
    return NATIVE_RETURN_VOID();
}

/* Image2D.set(int x, int y, int width, int height, byte[] pixels) */
static JavaValue native_image2d_set(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    JavaArray* src = (JavaArray*)args[5].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get destination pixel array using helper functions */
    JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "pixels");
    int img_width = m3g_get_int_field(obj, "width", 0);
    
    if (!dst) return NATIVE_RETURN_VOID();
    
    uint8_t* src_data = (uint8_t*)array_data(src);
    uint32_t* dst_data = (uint32_t*)array_data(dst);
    
    /* Copy and convert to ARGB */
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) {
            int src_idx = (row * w + col) * 4;  /* Assume RGBA */
            int dst_idx = (y + row) * img_width + (x + col);
            
            if (dst_idx < (int)dst->length) {
                dst_data[dst_idx] = (0xFF << 24) |  /* Alpha */
                                    (src_data[src_idx] << 16) |  /* R */
                                    (src_data[src_idx + 1] << 8) |  /* G */
                                    src_data[src_idx + 2];  /* B */
            }
        }
    }
    
    GFX_DEBUG("Image2D.set: (%d,%d) %dx%d", x, y, w, h);
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Extended JSR 184 Implementation - Additional Features
 * ============================================================================ */

/* World.addChild(Node) */
static JavaValue native_world_addChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!world || !child) return NATIVE_RETURN_VOID();
    
    /* Get children array using helper function */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children) {
        /* Add child to array - simplified: just store first child */
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j] == NULL) {
                arr[j] = child;
                break;
            }
        }
    }
    
    GFX_DEBUG("World.addChild: %p", (void*)child);
    return NATIVE_RETURN_VOID();
}

/* World.getActiveCamera() */
static JavaValue native_world_getActiveCamera(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    
    if (!world) return NATIVE_RETURN_NULL();
    
    /* Get active camera from World using helper function */
    JavaObject* camera = m3g_get_ref_field(world, "activeCamera");
    if (camera) {
        return NATIVE_RETURN_OBJECT(camera);
    }
    
    /* Try to find camera in children */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children && children->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j]) {
                JavaClass* child_class = arr[j]->header.clazz;
                if (child_class && child_class->class_name && 
                    strstr(child_class->class_name, "Camera")) {
                    return NATIVE_RETURN_OBJECT(arr[j]);
                }
            }
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* Object3D.find(int userID) */
static JavaValue native_object3d_find(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint user_id = args[1].i;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    /* Check if this object matches using helper function */
    jint obj_user_id = m3g_get_int_field(obj, "userID", -1);
    if (obj_user_id == user_id) {
        return NATIVE_RETURN_OBJECT(obj);
    }
    
    /* TODO: Search children if this is a Group */
    
    GFX_DEBUG("Object3D.find: userID=%d (not found)", user_id);
    return NATIVE_RETURN_NULL();
}

/* Object3D.getUserID() */
static JavaValue native_object3d_getUserID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_INT(0);
    
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "userID", 0));
}

/* Object3D.setUserID(int id) */
static JavaValue native_object3d_setUserID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint user_id = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_int_field(obj, "userID", user_id);
    
    GFX_DEBUG("Object3D.setUserID: %d", user_id);
    return NATIVE_RETURN_VOID();
}

/* Node.getTransform(Transform) */
static JavaValue native_node_getTransform(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    
    if (!node || !transform) return NATIVE_RETURN_VOID();
    
    /* Copy node's transform to the provided Transform object using helper functions */
    JavaArray* node_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (node_arr && node_arr->element_type == T_FLOAT) {
        float* node_matrix = (float*)array_data(node_arr);
        
        JavaArray* trans_arr = (JavaArray*)m3g_get_ref_field(transform, "matrix");
        if (trans_arr && trans_arr->element_type == T_FLOAT) {
            float* trans_matrix = (float*)array_data(trans_arr);
            memcpy(trans_matrix, node_matrix, 16 * sizeof(float));
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Node.setTransform(Transform) */
static JavaValue native_node_setTransform(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    
    if (!node || !transform) return NATIVE_RETURN_VOID();
    
    /* Copy transform to node's transform field */
    M3GTransform* t = get_native_transform(transform);
    if (!t) return NATIVE_RETURN_VOID();
    
    JavaArray* node_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (node_arr && node_arr->element_type == T_FLOAT) {
        float* node_matrix = (float*)array_data(node_arr);
        memcpy(node_matrix, t->m, 16 * sizeof(float));
    }
    
    GFX_DEBUG("Node.setTransform");
    return NATIVE_RETURN_VOID();
}

/* Node.setAlphaFactor(float factor) */
static JavaValue native_node_setAlphaFactor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    float factor = args[1].f;
    
    if (!node) return NATIVE_RETURN_VOID();
    
    m3g_set_float_field(node, "alphaFactor", factor);
    
    GFX_DEBUG("Node.setAlphaFactor: %.2f", factor);
    return NATIVE_RETURN_VOID();
}

/* Group.addChild(Node) */
static JavaValue native_group_addChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!group || !child) return NATIVE_RETURN_VOID();
    
    /* Get children list */
    JavaClass* clazz = group->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "children") == 0) {
            JavaArray* children = (JavaArray*)group->fields[i].ref;
            if (children && children->element_type == DESC_OBJECT) {
                JavaObject** arr = (JavaObject**)array_data(children);
                /* Find empty slot */
                for (jsize j = 0; j < children->length; j++) {
                    if (arr[j] == NULL) {
                        arr[j] = child;
                        GFX_DEBUG("Group.addChild: added child at index %d", j);
                        break;
                    }
                }
            }
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Group.removeChild(Node) */
static JavaValue native_group_removeChild(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!group || !child) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = group->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "children") == 0) {
            JavaArray* children = (JavaArray*)group->fields[i].ref;
            if (children && children->element_type == DESC_OBJECT) {
                JavaObject** arr = (JavaObject**)array_data(children);
                for (jsize j = 0; j < children->length; j++) {
                    if (arr[j] == child) {
                        arr[j] = NULL;
                        GFX_DEBUG("Group.removeChild: removed child at index %d", j);
                        break;
                    }
                }
            }
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Group.getChild(int index) */
static JavaValue native_group_getChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    if (!group) return NATIVE_RETURN_NULL();
    
    JavaClass* clazz = group->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "children") == 0) {
            JavaArray* children = (JavaArray*)group->fields[i].ref;
            if (children && children->element_type == DESC_OBJECT && index >= 0 && index < (jint)children->length) {
                JavaObject** arr = (JavaObject**)array_data(children);
                return NATIVE_RETURN_OBJECT(arr[index]);
            }
            break;
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* CompositingMode.setBlending(int mode) */
static JavaValue native_compositingmode_setBlending(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "blending") == 0) {
            obj->fields[i].i = mode;
            break;
        }
    }
    
    GFX_DEBUG("CompositingMode.setBlending: %d", mode);
    return NATIVE_RETURN_VOID();
}

/* PolygonMode.setCulling(int mode) */
static JavaValue native_polygonmode_setCulling(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    g_m3g.culling_enabled = (mode != 0);
    
    GFX_DEBUG("PolygonMode.setCulling: %d", mode);
    return NATIVE_RETURN_VOID();
}

/* Mesh.setVertexBuffer(int index, VertexArray) */
static JavaValue native_mesh_setVertexBuffer(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* mesh = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* va = (JavaObject*)args[2].ref;
    
    if (!mesh) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = mesh->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "vertexBuffers") == 0) {
            JavaArray* buffers = (JavaArray*)mesh->fields[i].ref;
            if (buffers && buffers->element_type == DESC_OBJECT && index >= 0 && index < (jint)buffers->length) {
                JavaObject** arr = (JavaObject**)array_data(buffers);
                arr[index] = va;
            }
            break;
        }
    }
    
    GFX_DEBUG("Mesh.setVertexBuffer: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* Camera.lookAt(float x, float y, float z, float atX, float atY, float atZ, float upX, float upY, float upZ) */
static JavaValue native_camera_lookAt(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float eye_x = args[1].f;
    float eye_y = args[2].f;
    float eye_z = args[3].f;
    float at_x = args[4].f;
    float at_y = args[5].f;
    float at_z = args[6].f;
    float up_x = args[7].f;
    float up_y = args[8].f;
    float up_z = args[9].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Update modelview matrix */
    m3g_transform_look_at(&g_m3g.modelview, eye_x, eye_y, eye_z, at_x, at_y, at_z, up_x, up_y, up_z);
    
    GFX_DEBUG("Camera.lookAt: eye=(%.2f,%.2f,%.2f), at=(%.2f,%.2f,%.2f)", 
            eye_x, eye_y, eye_z, at_x, at_y, at_z);
    return NATIVE_RETURN_VOID();
}

/* Loader.load(String name) - Basic M3G file loading stub */
static JavaValue native_loader_load(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* name_str = (JavaString*)args[0].ref;
    
    if (!name_str) {
        GFX_DEBUG("Loader.load: null name");
        return NATIVE_RETURN_NULL();
    }
    
    const char* name = string_utf8(jvm, name_str);
    GFX_DEBUG("Loader.load: '%s'", name ? name : "NULL");
    
    /* TODO: Implement actual M3G file parsing */
    /* For now, return null to indicate file not found or parsing not implemented */
    
    /* Try to load from JAR */
    size_t data_size;
    uint8_t* data = load_jar_resource(name, &data_size);
    if (data) {
        GFX_DEBUG("Loader.load: found %zu bytes, but M3G parsing not yet implemented", data_size);
        free(data);
    }
    
    return NATIVE_RETURN_NULL();
}

/* Loader.load(byte[] data, int offset) - Load from byte array */
static JavaValue native_loader_load_bytes(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaArray* data = (JavaArray*)args[0].ref;
    jint offset = args[1].i;
    
    if (!data) {
        GFX_DEBUG("Loader.load: null data");
        return NATIVE_RETURN_NULL();
    }
    
    GFX_DEBUG("Loader.load: byte[%d] at offset %d (M3G parsing not yet implemented)", 
            data->length, offset);
    
    /* TODO: Implement M3G binary file parsing */
    /* M3G file format is a binary format with sections for:
     * - Header
     * - External objects (textures, etc.)
     * - Scene graph objects
     * - Animation data
     */
    
    return NATIVE_RETURN_NULL();
}

/* RayIntersection methods for picking */
static JavaValue native_rayintersection_getDistance(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_FLOAT(0.0f);
    
    /* Get distance from field */
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "distance") == 0) {
            return NATIVE_RETURN_FLOAT(obj->fields[i].f);
        }
    }
    
    return NATIVE_RETURN_FLOAT(0.0f);
}

static JavaValue native_rayintersection_getIntersected(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "intersected") == 0) {
            return NATIVE_RETURN_OBJECT(obj->fields[i].ref);
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* Graphics3D.addLight(Light, Transform) */
static JavaValue native_graphics3d_addLight(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* light = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d; (void)transform;
    
    if (!light) return NATIVE_RETURN_VOID();
    
    /* Add light to context */
    if (g_m3g.light_count < 8) {
        /* Get light properties from object */
        int idx = g_m3g.light_count++;
        memset(&g_m3g.lights[idx], 0, sizeof(M3GLight));
        
        JavaClass* light_class = light->header.clazz;
        for (int i = 0; i < light_class->fields_count; i++) {
            if (!light_class->fields[i].name) continue;
            if (strcmp(light_class->fields[i].name, "type") == 0) {
                g_m3g.lights[idx].type = light->fields[i].i;
            } else if (strcmp(light_class->fields[i].name, "color") == 0) {
                int argb = light->fields[i].i;
                g_m3g.lights[idx].color[0] = ((argb >> 16) & 0xFF) / 255.0f;
                g_m3g.lights[idx].color[1] = ((argb >> 8) & 0xFF) / 255.0f;
                g_m3g.lights[idx].color[2] = (argb & 0xFF) / 255.0f;
            } else if (strcmp(light_class->fields[i].name, "intensity") == 0) {
                g_m3g.lights[idx].color[3] = light->fields[i].f;
            }
        }
        
        GFX_DEBUG("Graphics3D.addLight: type=%d (idx=%d)", g_m3g.lights[idx].type, idx);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setLight(int index, Light, Transform) */
static JavaValue native_graphics3d_setLight(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* light = (JavaObject*)args[2].ref;
    JavaObject* transform = (JavaObject*)args[3].ref;
    (void)g3d; (void)transform;
    
    if (index < 0 || index >= 8) return NATIVE_RETURN_VOID();
    
    if (light) {
        /* Update light at index */
        memset(&g_m3g.lights[index], 0, sizeof(M3GLight));
        
        JavaClass* light_class = light->header.clazz;
        for (int i = 0; i < light_class->fields_count; i++) {
            if (!light_class->fields[i].name) continue;
            if (strcmp(light_class->fields[i].name, "type") == 0) {
                g_m3g.lights[index].type = light->fields[i].i;
            }
        }
        
        GFX_DEBUG("Graphics3D.setLight: index=%d", index);
    } else {
        /* Remove light */
        if (index < g_m3g.light_count) {
            g_m3g.lights[index].type = 0;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* AnimationTrack methods */
static JavaValue native_animationtrack_setController(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* track = (JavaObject*)args[0].ref;
    JavaObject* controller = (JavaObject*)args[1].ref;
    (void)track; (void)controller;
    
    GFX_DEBUG("AnimationTrack.setController");
    return NATIVE_RETURN_VOID();
}

/* KeyframeSequence methods */
static JavaValue native_keyframesequence_setKeyframe(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    jint time = args[2].i;
    JavaArray* values = (JavaArray*)args[3].ref;
    (void)seq; (void)index; (void)time; (void)values;
    
    GFX_DEBUG("KeyframeSequence.setKeyframe: index=%d, time=%d", index, time);
    return NATIVE_RETURN_VOID();
}

/* Sprite3D methods */
static JavaValue native_sprite3d_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jboolean scaled = args[1].i;
    JavaObject* image = (JavaObject*)args[2].ref;
    JavaObject* appearance = (JavaObject*)args[3].ref;
    (void)obj; (void)scaled; (void)image; (void)appearance;
    
    GFX_DEBUG("Sprite3D.<init>");
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sprite3d_setImage(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    (void)obj; (void)image;
    
    GFX_DEBUG("Sprite3D.setImage");
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Stub Class Registration for M3G Classes
 * ============================================================================ */

/* Additional stub classes for M3G */
static const struct {
    const char* name;
    const char* super;
    uint16_t flags;
} m3g_stub_classes[] = {
    /* Core M3G classes */
    { "javax/microedition/m3g/Graphics3D", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Object3D", "java/lang/Object", 1 | 1024 },
    { "javax/microedition/m3g/Transform", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Node", "javax/microedition/m3g/Object3D", 1 | 1024 },
    { "javax/microedition/m3g/Group", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/World", "javax/microedition/m3g/Group", 1 },
    { "javax/microedition/m3g/Camera", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/Mesh", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/Sprite3D", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/Light", "javax/microedition/m3g/Node", 1 },
    
    /* Vertex data */
    { "javax/microedition/m3g/VertexArray", "java/lang/Object", 1 },
    { "javax/microedition/m3g/IndexBuffer", "java/lang/Object", 1 | 1024 },
    { "javax/microedition/m3g/TriangleStripArray", "javax/microedition/m3g/IndexBuffer", 1 },
    
    /* Appearance */
    { "javax/microedition/m3g/Appearance", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Material", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Texture2D", "javax/microedition/m3g/Object3D", 1 },
    { "javax/microedition/m3g/CompositingMode", "java/lang/Object", 1 },
    { "javax/microedition/m3g/PolygonMode", "java/lang/Object", 1 },
    
    /* Image and background */
    { "javax/microedition/m3g/Image2D", "javax/microedition/m3g/Object3D", 1 },
    { "javax/microedition/m3g/Background", "javax/microedition/m3g/Object3D", 1 },
    
    /* Animation */
    { "javax/microedition/m3g/AnimationController", "java/lang/Object", 1 },
    { "javax/microedition/m3g/AnimationTrack", "java/lang/Object", 1 },
    { "javax/microedition/m3g/KeyframeSequence", "java/lang/Object", 1 },
    
    /* Morphing and skinning */
    { "javax/microedition/m3g/MorphingMesh", "javax/microedition/m3g/Mesh", 1 },
    { "javax/microedition/m3g/SkinnedMesh", "javax/microedition/m3g/Mesh", 1 },
    
    /* Loader and picking */
    { "javax/microedition/m3g/Loader", "java/lang/Object", 1 },
    { "javax/microedition/m3g/RayIntersection", "java/lang/Object", 1 },
    
    { NULL, NULL, 0 }
};

/* Register M3G stub classes */
int init_m3g_stub_classes(JVM* jvm) {
    if (!jvm) return 0;
    
    int count = 0;
    
    /* Use get_or_create_stub_class from stubs.c to create classes */
    extern JavaClass* get_or_create_stub_class(JVM* jvm, const char* class_name);
    
    for (int i = 0; m3g_stub_classes[i].name != NULL; i++) {
        /* get_or_create_stub_class will check if already loaded */
        JavaClass* stub = get_or_create_stub_class(jvm, m3g_stub_classes[i].name);
        if (!stub) continue;
        
        count++;
    }
    
    GFX_DEBUG("Registered %d M3G stub classes", count);
    return count;
}

/* ============================================================================
 * Native Method Registration
 * ============================================================================ */

void init_javax_microedition_m3g(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Graphics3D */
        {"javax/microedition/m3g/Graphics3D", "getInstance", "()Ljavax/microedition/m3g/Graphics3D;", native_graphics3d_getInstance},
        {"javax/microedition/m3g/Graphics3D", "bindTarget", "(Ljavax/microedition/m3g/Image2D;)V", native_graphics3d_bindTarget},
        {"javax/microedition/m3g/Graphics3D", "releaseTarget", "()V", native_graphics3d_releaseTarget},
        {"javax/microedition/m3g/Graphics3D", "clear", "(Ljavax/microedition/m3g/Background;)V", native_graphics3d_clear},
        {"javax/microedition/m3g/Graphics3D", "setViewport", "(IIII)V", native_graphics3d_setViewport},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/World;)V", native_graphics3d_renderWorld},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/Node;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_render_node},
        {"javax/microedition/m3g/Graphics3D", "addLight", "(Ljavax/microedition/m3g/Light;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_addLight},
        {"javax/microedition/m3g/Graphics3D", "setLight", "(ILjavax/microedition/m3g/Light;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_setLight},
        
        /* Transform */
        {"javax/microedition/m3g/Transform", "setIdentity", "()V", native_transform_setIdentity},
        {"javax/microedition/m3g/Transform", "postMultiply", "(Ljavax/microedition/m3g/Transform;)V", native_transform_postMultiply},
        {"javax/microedition/m3g/Transform", "postTranslate", "(FFF)V", native_transform_postTranslate},
        {"javax/microedition/m3g/Transform", "postRotate", "(FFFF)V", native_transform_postRotate},
        {"javax/microedition/m3g/Transform", "postScale", "(FFF)V", native_transform_postScale},
        {"javax/microedition/m3g/Transform", "invert", "()V", native_transform_invert},
        {"javax/microedition/m3g/Transform", "transform", "([F)V", native_transform_transform},
        
        /* VertexArray */
        {"javax/microedition/m3g/VertexArray", "<init>", "(III)V", native_vertexarray_init},
        {"javax/microedition/m3g/VertexArray", "set", "(II[B)V", native_vertexarray_set_byte},
        {"javax/microedition/m3g/VertexArray", "set", "(II[S)V", native_vertexarray_set_short},
        
        /* Camera */
        {"javax/microedition/m3g/Camera", "setPerspective", "(FFFF)V", native_camera_setPerspective},
        {"javax/microedition/m3g/Camera", "setParallel", "(FFFF)V", native_camera_setParallel},
        {"javax/microedition/m3g/Camera", "setGeneric", "(Ljavax/microedition/m3g/Transform;)V", native_camera_setGeneric},
        {"javax/microedition/m3g/Camera", "lookAt", "(FFFFFFFFF)V", native_camera_lookAt},
        
        /* Light */
        {"javax/microedition/m3g/Light", "setType", "(I)V", native_light_setType},
        {"javax/microedition/m3g/Light", "setColor", "(I)V", native_light_setColor},
        {"javax/microedition/m3g/Light", "setIntensity", "(F)V", native_light_setIntensity},
        {"javax/microedition/m3g/Light", "setDirection", "(FFF)V", native_light_setDirection},
        
        /* Material */
        {"javax/microedition/m3g/Material", "setColor", "(II)V", native_material_setColor},
        {"javax/microedition/m3g/Material", "setShininess", "(F)V", native_material_setShininess},
        
        /* Appearance */
        {"javax/microedition/m3g/Appearance", "setMaterial", "(Ljavax/microedition/m3g/Material;)V", native_appearance_setMaterial},
        {"javax/microedition/m3g/Appearance", "setTexture", "(ILjavax/microedition/m3g/Texture2D;)V", native_appearance_setTexture},
        
        /* Texture2D */
        {"javax/microedition/m3g/Texture2D", "<init>", "(Ljavax/microedition/m3g/Image2D;)V", native_texture2d_init},
        {"javax/microedition/m3g/Texture2D", "setFiltering", "(I)V", native_texture2d_setFiltering},
        {"javax/microedition/m3g/Texture2D", "setWrapping", "(II)V", native_texture2d_setWrapping},
        
        /* Mesh */
        {"javax/microedition/m3g/Mesh", "<init>", "(Ljavax/microedition/m3g/VertexArray;Ljavax/microedition/m3g/IndexBuffer;Ljavax/microedition/m3g/Appearance;)V", native_mesh_init},
        {"javax/microedition/m3g/Mesh", "setVertexBuffer", "(ILjavax/microedition/m3g/VertexArray;)V", native_mesh_setVertexBuffer},
        
        /* TriangleStripArray */
        {"javax/microedition/m3g/TriangleStripArray", "<init>", "(I[I)V", native_trianglestrip_init},
        
        /* Node */
        {"javax/microedition/m3g/Node", "setScale", "(FFF)V", native_node_setScale},
        {"javax/microedition/m3g/Node", "setTranslation", "(FFF)V", native_node_setTranslation},
        {"javax/microedition/m3g/Node", "setRotation", "(FFFF)V", native_node_setRotation},
        {"javax/microedition/m3g/Node", "getTransform", "(Ljavax/microedition/m3g/Transform;)V", native_node_getTransform},
        {"javax/microedition/m3g/Node", "setTransform", "(Ljavax/microedition/m3g/Transform;)V", native_node_setTransform},
        {"javax/microedition/m3g/Node", "setAlphaFactor", "(F)V", native_node_setAlphaFactor},
        
        /* Group */
        {"javax/microedition/m3g/Group", "addChild", "(Ljavax/microedition/m3g/Node;)V", native_group_addChild},
        {"javax/microedition/m3g/Group", "removeChild", "(Ljavax/microedition/m3g/Node;)V", native_group_removeChild},
        {"javax/microedition/m3g/Group", "getChild", "(I)Ljavax/microedition/m3g/Node;", native_group_getChild},
        
        /* World */
        {"javax/microedition/m3g/World", "addCamera", "(Ljavax/microedition/m3g/Camera;)V", native_world_addCamera},
        {"javax/microedition/m3g/World", "setBackground", "(Ljavax/microedition/m3g/Background;)V", native_world_setBackground},
        {"javax/microedition/m3g/World", "addChild", "(Ljavax/microedition/m3g/Node;)V", native_world_addChild},
        {"javax/microedition/m3g/World", "getActiveCamera", "()Ljavax/microedition/m3g/Camera;", native_world_getActiveCamera},
        
        /* Object3D */
        {"javax/microedition/m3g/Object3D", "find", "(I)Ljavax/microedition/m3g/Object3D;", native_object3d_find},
        {"javax/microedition/m3g/Object3D", "getUserID", "()I", native_object3d_getUserID},
        {"javax/microedition/m3g/Object3D", "setUserID", "(I)V", native_object3d_setUserID},
        
        /* Background */
        {"javax/microedition/m3g/Background", "setColor", "(I)V", native_background_setColor},
        
        /* Image2D */
        {"javax/microedition/m3g/Image2D", "<init>", "(III)V", native_image2d_init},
        {"javax/microedition/m3g/Image2D", "<init>", "(ILjava/lang/Object;)V", native_image2d_init_from_image},
        {"javax/microedition/m3g/Image2D", "set", "(IIII[B)V", native_image2d_set},
        
        /* CompositingMode */
        {"javax/microedition/m3g/CompositingMode", "setBlending", "(I)V", native_compositingmode_setBlending},
        
        /* PolygonMode */
        {"javax/microedition/m3g/PolygonMode", "setCulling", "(I)V", native_polygonmode_setCulling},
        
        /* Loader */
        {"javax/microedition/m3g/Loader", "load", "(Ljava/lang/String;)Ljavax/microedition/m3g/Object3D;", native_loader_load},
        {"javax/microedition/m3g/Loader", "load", "([BI)[Ljavax/microedition/m3g/Object3D;", native_loader_load_bytes},
        
        /* RayIntersection */
        {"javax/microedition/m3g/RayIntersection", "getDistance", "()F", native_rayintersection_getDistance},
        {"javax/microedition/m3g/RayIntersection", "getIntersected", "()Ljavax/microedition/m3g/Node;", native_rayintersection_getIntersected},
        
        /* AnimationTrack */
        {"javax/microedition/m3g/AnimationTrack", "setController", "(Ljavax/microedition/m3g/AnimationController;)V", native_animationtrack_setController},
        
        /* KeyframeSequence */
        {"javax/microedition/m3g/KeyframeSequence", "setKeyframe", "(II[F)V", native_keyframesequence_setKeyframe},
        
        /* Sprite3D */
        {"javax/microedition/m3g/Sprite3D", "<init>", "(ZLjavax/microedition/m3g/Image2D;Ljavax/microedition/m3g/Appearance;)V", native_sprite3d_init},
        {"javax/microedition/m3g/Sprite3D", "setImage", "(Ljavax/microedition/m3g/Image2D;)V", native_sprite3d_setImage},
    };
    
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    
    /* Register stub classes */
    init_m3g_stub_classes(jvm);
    
    GFX_DEBUG("Registered %zu native methods for JSR 184", 
            sizeof(methods) / sizeof(methods[0]));
}
