import com.nokia.mid.ui.DeviceControl;
import com.nokia.mid.ui.FullCanvas;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Random;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import javax.microedition.media.control.VolumeControl;
import javax.microedition.rms.RecordStore;

final class a extends FullCanvas implements Runnable {
   private static final int[] a = new int[]{42, 55, 50, 55, 52, 51};
   private int i = 0;
   private boolean a = false;
   private int j = 0;
   private String[] a;
   private int[] b;
   private int k;
   private long a;
   private static long b;
   private static Image a;
   static Font a = Font.getFont(0, 0, 0);
   private final int l;
   private final int m;
   private final int n;
   private static Image[] a;
   private boolean b;
   private boolean c;
   static int a = 0;
   static int b;
   static int c;
   private static int o;
   private static int p = 99;
   private static int q = 0;
   private static int r;
   private static int s;
   private static int t;
   private static int u;
   private static int v;
   private static int w;
   private static int x;
   private static int y;
   private static int z;
   private static int A;
   private static int B;
   private static int C;
   private static int D;
   private static int E;
   private static int F;
   private static int G;
   private static int H;
   private static int I;
   private static int J;
   private static int K;
   private static int L;
   private static int M;
   private static int[] c = new int[5];
   private static int[] d = new int[5];
   private static int[] e = new int[5];
   private static int[] f = new int[5];
   private static int[] g = new int[5];
   private static int[] h = new int[5];
   private static int[] i = new int[5];
   private static int N;
   private static int O;
   private static int P;
   private static int Q;
   private static int R;
   private static int S;
   private static int T;
   private static int U;
   private static int V;
   private static int W;
   private static int X;
   private static int Y;
   private static int Z;
   private static int aa;
   private static int ab;
   private static int ac;
   private static int ad;
   private static int ae;
   private static int af;
   private static int ag;
   private static int ah;
   private static int ai;
   private static int aj;
   private static int[] j = new int[5];
   private static int ak;
   private static int al;
   private static int am;
   private static int an;
   private static int ao;
   static Random a = new Random();
   static String a;
   private String[] b;
   private boolean d;
   private int ap;
   private int aq;
   private Main a;
   private Player a;
   private String[] c;
   private boolean e;
   private boolean f;
   private byte[] a;
   private String[] d;
   int d;
   int e;
   int f;
   int g;
   int h;

   public a(Main var1) {
      this.l = a.getHeight();
      this.m = this.getWidth();
      this.n = this.getHeight();
      this.b = true;
      this.c = true;
      this.b = new String[]{"", ""};
      this.d = false;
      this.ap = 0;
      this.aq = 0;
      this.c = new String[]{"0.mid", "1.mid", "2.mid", "3.mid"};
      this.e = true;
      this.f = false;
      this.a = null;
      this.d = null;
      this.d = 1;
      this.e = 5;
      this.f = 4;
      this.g = 8;
      this.h = 3;
      this.a = var1;
   }

   private void b() throws Exception {
      p = 99;
      this.f();
      this.d = this.a();
      a = Image.createImage("/logo.png");
      this.a(this.b = new int[36], 35);
      a = new Image[35];

      for(int var1 = 0; var1 < 35; ++var1) {
         a[var1] = this.a(var1);
      }

   }

   private void a(int[] var1, int var2) throws Exception {
      DataInputStream var3 = null;

      try {
         var3 = new DataInputStream(this.getClass().getResourceAsStream("img"));

         int var5;
         for(var5 = 0; var5 < var2; ++var5) {
            var1[var5] = var3.readInt();
         }

         var1[35] = 21198;
         var5 = 21198 - var1[0];
         this.a = new byte[var5];

         for(int var6 = 0; var6 < var5; ++var6) {
            this.a[var6] = var3.readByte();
         }
      } catch (Exception var8) {
      }

      try {
         var3.close();
      } catch (Exception var7) {
      }
   }

   private Image a(int var1) {
      Object var2 = null;

      try {
         Image var3 = Image.createImage(this.a, this.b[var1] - this.b[0], this.b[var1 + 1] - this.b[var1]);
         return var3;
      } catch (Exception var7) {
      } finally {
         System.gc();
      }

      return null;
   }

   public final void run() {
      try {
         this.b();
      } catch (Exception var7) {
         this.e = false;
         this.a.a();
      }

      p = -2;
      b = System.currentTimeMillis();

      while(this.e) {
         long var3;
         if ((var3 = System.currentTimeMillis() - b - 83L) < 0L) {
            try {
               Thread.sleep(-var3);
            } catch (Exception var6) {
            }
         }

         b = System.currentTimeMillis();
         this.repaint();
      }

   }

   public final void paint(Graphics var1) {
      var1.setFont(a);
      if (p != r) {
         r = p;
      }

      label865: {
         boolean var2;
         String var8;
         int var9;
         Graphics var10;
         String[] var11;
         byte var12;
         byte var13;
         int[] var14;
         int var10000;
         Image[] var10001;
         int var10002;
         int var10003;
         switch (p) {
            case -2:
               this.f = true;
               var1.setColor(0);
               var1.fillRect(0, 0, this.m, this.n + 1);
               var1.drawImage(a, (this.m - a.getWidth()) / 2, (this.n - a.getHeight()) / 2, 0);
               p = -1;
               break label865;
            case -1:
               this.f = false;
               if (!this.d) {
                  try {
                     Thread.sleep(1000L);
                  } catch (Exception var6) {
                  }

                  this.d = true;
               }

               var1.setColor(0);
               var1.fillRect(0, 0, this.m, this.n + 1);
               int var7 = 0;

               while(true) {
                  if (var7 >= 5) {
                     break label865;
                  }

                  var1.setColor(16777215);
                  if (this.aq == var7) {
                     var1.setColor(16776960);
                  }

                  var1.drawString(this.d[var7], (this.m - a.stringWidth(this.d[var7])) / 2, this.n / 5 * var7 + 6, 20);
                  ++var7;
               }
            case 0:
               label579: {
                  this.f = false;
                  q = 0;
                  ao = 1;
                  ak = 0;
                  al = 0;
                  am = 0;
                  an = 0;
                  ac = 0;
                  this.ap = 0;
                  var1.setColor(0, 0, 0);
                  var1.fillRect(0, 0, this.m, this.n + 1);
                  var1.drawImage(a[8], (this.m - 160) / 2, 0, 20);
                  this.a(0, "");
                  this.a(1, this.a[37]);
                  var1.setColor(0, 3, 152);
                  var1.fillRect(0, this.n / 20 * 17 - 1, this.m, this.l + 4);
                  this.a(var1, 31, 5, this.n / 20 * 17 + this.l / 4, false);
                  this.a(var1, 33, this.m - 5 - 16, this.n / 20 * 17 + this.l / 4, true);
                  switch (W) {
                     case 0:
                        var11 = this.a;
                        var12 = 13;
                        break;
                     case 1:
                        if (this.b) {
                           var11 = this.a;
                           var12 = 15;
                        } else {
                           var11 = this.a;
                           var12 = 16;
                        }
                        break;
                     default:
                        break label579;
                  }

                  a = var11[var12];
               }

               var1.setColor(16777215);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, (this.n - this.l) / 8 * 8 - 19, 0);
               var1.setColor(16777215);
               a = String.valueOf(a);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 20 * 14 + this.l + 2 - 15, 0);
               a = this.a[19];
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 20 * 14 - 16, 0);
               this.a(1, this.a[37]);
               var1.setColor(16777215);
               var1.drawString(this.b[0], 0, this.n, 36);
               var1.drawString(this.b[1], this.m, this.n, 40);
               if (this.a) {
                  a = this.a[20];
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 20 * 19 + 12 - 15, 0);
               }
               break label865;
            case 1:
               this.f = false;
               d[0] = c[0];
               d[1] = c[1];
               d[2] = c[2];
               d[3] = c[3];
               d[4] = c[4];
               if (q != 1) {
                  this.a(0, this.a[40]);
                  if (this.b) {
                     var11 = this.a;
                     var12 = 15;
                  } else {
                     var11 = this.a;
                     var12 = 16;
                  }

                  a = var11[var12];
                  this.a(1, a);
                  D += F;
                  if (D <= 0) {
                     D = 0;
                  }

                  if (D >= 4) {
                     D = 4;
                  }

                  if (G == 1) {
                     H = D;
                  }

                  F = 0;
                  if (u == 0) {
                     if (C != 0) {
                        --C;
                        if (C <= 0) {
                           B = 6;
                        }
                     }

                     ++x;
                     if (P == 0) {
                        O = 0;
                        var10000 = L;

                        label788:
                        while(true) {
                           o = var10000;
                           if (o >= M) {
                              if (O == 0) {
                                 al = 1;
                                 this.j = 2;
                                 P = 30;
                                 Y = Q != 0 && ai != 3 ? 42 : 30;
                                 ac = 0;
                                 af = 0;
                                 X = 1;
                                 switch (ai) {
                                    case 3:
                                       Z = 2;
                                       aa = -40;
                                       ad = 3;
                                       ae = -40;
                                       break label788;
                                    default:
                                       Z = 2;
                                       aa = -40;
                                 }
                              }
                              break;
                           }

                           if (j[o] > 0) {
                              O = 1;
                           }

                           var10000 = o + 1;
                        }
                     } else {
                        if (ab == 0) {
                           ab = 1;
                        }

                        if (P <= 1) {
                           P = 0;
                           x = 0;
                           y = 1;
                           u = 40;
                           p = 3;
                           am = 1;
                           this.j = 3;
                        }
                     }

                     var10000 = L;

                     label777:
                     while(true) {
                        o = var10000;
                        if (o >= M) {
                           if (ab != 0) {
                              label881: {
                                 if (af != 0) {
                                    af = af < 0 ? af + 2 : af - 2;
                                 }

                                 switch (ai) {
                                    case 1:
                                       if (P == 30) {
                                          ++aa;
                                          if (aa >= 1) {
                                             P = 10;
                                          }
                                          break label881;
                                       }

                                       var10000 = aa;
                                       var9 = this.d;
                                       break;
                                    case 2:
                                       if (ab != 1) {
                                          aa -= 10;
                                          if (aa <= 0) {
                                             aa = -30;
                                             ab = 1;
                                             Z = 0 == a.nextInt() % 2 ? Z + 1 : Z - 1;
                                             if (Z <= -1) {
                                                Z = 1;
                                             }

                                             if (Z >= 5) {
                                                Z = 3;
                                             }
                                          }
                                          break label881;
                                       }

                                       if (P == 30) {
                                          aa += 2;
                                          if (aa >= 1) {
                                             P = 10;
                                          }
                                          break label881;
                                       }

                                       var10000 = aa;
                                       var9 = this.e;
                                       break;
                                    case 3:
                                       if (P == 30) {
                                          aa += 2;
                                          if (aa >= 1) {
                                             P = 10;
                                          }
                                       } else {
                                          aa += this.f;
                                          if (Y >= 3 || ae >= -41) {
                                             ae += 5;
                                          }
                                       }
                                       break label881;
                                    default:
                                       if (P == 30) {
                                          aa += 2;
                                          if (aa >= 1) {
                                             P = 10;
                                          }
                                          break label881;
                                       }

                                       var10000 = aa;
                                       var9 = 3;
                                 }

                                 aa = var10000 + var9;
                              }
                           }

                           if (G == 1) {
                              H = D;
                              J = 3;
                              --B;
                              if (B <= 0) {
                                 C = Q == 0 ? 5 : 2;
                              }

                              if (j[H] > 0 && e[H] == 0) {
                                 G = 2;
                                 I = c[H];
                                 f[H] = 0;
                                 if (H != 0 && H != 4) {
                                    if (Q == 0) {
                                       var14 = c;
                                       var9 = H;
                                       var10002 = c[H];
                                       var10003 = 25;
                                    } else {
                                       var14 = c;
                                       var9 = H;
                                       var10002 = c[H];
                                       var10003 = 15;
                                    }

                                    var14[var9] = var10002 - var10003;
                                    v += 100;
                                    var14 = e;
                                    var9 = H;
                                    var13 = 10;
                                 } else {
                                    if (Q == 0) {
                                       var14 = c;
                                       var9 = H;
                                       var10002 = c[H];
                                       var10003 = 40;
                                    } else {
                                       var14 = c;
                                       var9 = H;
                                       var10002 = c[H];
                                       var10003 = 20;
                                    }

                                    var14[var9] = var10002 - var10003;
                                    v += 200;
                                    var14 = e;
                                    var9 = H;
                                    var13 = 0;
                                 }

                                 var14[var9] = var13;
                                 var10002 = j[H]--;
                                 if (0 >= c[H]) {
                                    c[H] = 0;
                                 }
                              } else {
                                 G = 3;
                                 if (j[H] > 0) {
                                    v += 50;
                                    var10002 = j[H]--;
                                 }

                                 if (Q == 0) {
                                    var14 = c;
                                    var9 = H;
                                    var10002 = c[H];
                                    var10003 = 5;
                                 } else {
                                    var14 = c;
                                    var9 = H;
                                    var10002 = c[H];
                                    var10003 = 1;
                                 }

                                 var14[var9] = var10002 - var10003;
                                 if (0 >= c[H]) {
                                    c[H] = 0;
                                 }

                                 I = c[H];
                              }

                              if (ab == 1 && P == 10) {
                                 if (H == Z) {
                                    label914: {
                                       switch (ai) {
                                          case 1:
                                             --Y;
                                             if (Y <= 0) {
                                                Y = 0;
                                                ac = 1;
                                                P = 1;
                                                ag = Z;
                                                ah = aa;
                                             }

                                             if (Y % this.g == 0) {
                                                aa -= 12;
                                             }

                                             var10000 = aa;
                                             break;
                                          case 2:
                                             --Y;
                                             if (Y <= 0) {
                                                Y = 0;
                                                ac = 1;
                                                P = 1;
                                                ag = Z;
                                                ah = aa;
                                             }

                                             if (Y % this.h == 0) {
                                                ab = 2;
                                                aa -= 15;
                                             }

                                             var10000 = aa;
                                             break;
                                          case 3:
                                             --Y;
                                             if (Y <= 0) {
                                                Y = 0;
                                                ac = 1;
                                                P = 1;
                                                ag = Z;
                                                ah = aa;
                                             }

                                             aa = -40;
                                             Z = a.nextInt() % 5;
                                             if (Z < 0) {
                                                Z = -Z;
                                             }

                                             if (Z == ad) {
                                                Z = (Z + 1) % 5;
                                             }
                                             break label914;
                                          default:
                                             --Y;
                                             if (Y <= 0) {
                                                Y = 0;
                                                ac = 1;
                                                P = 1;
                                                ag = Z;
                                                ah = aa;
                                             }

                                             if (Y % 3 == 0) {
                                                aa -= 18;
                                                byte var16;
                                                if (0 == a.nextInt() % 2) {
                                                   ++Z;
                                                   var16 = -6;
                                                } else {
                                                   --Z;
                                                   var16 = 6;
                                                }

                                                af = var16;
                                                if (Z <= -1) {
                                                   Z = 1;
                                                   af = -6;
                                                }

                                                if (Z >= 5) {
                                                   Z = 3;
                                                   af = 6;
                                                }
                                             }

                                             var10000 = aa;
                                       }

                                       I = var10000;
                                    }
                                 }

                                 if (H == ad && ai == 3 && (Y >= 3 || ae >= -41)) {
                                    --Y;
                                    if (Y <= 0) {
                                       Y = 0;
                                       ac = 1;
                                       P = 1;
                                       ag = ad;
                                       ah = ae;
                                    }

                                    ae = Y < 2 ? -42 : -40;
                                    ad = a.nextInt() % 5;
                                    if (ad < 0) {
                                       ad = -ad;
                                    }

                                    if (Z == ad) {
                                       ad = (ad + 1) % 5;
                                    }
                                 }
                              }
                           }

                           if (w > 2 && v >= 8000) {
                              L = 0;
                              M = 4;
                           } else {
                              j[0] = 0;
                              j[4] = 0;
                           }

                           if (w > 3 && v >= 15000) {
                              L = 0;
                              M = 5;
                           } else {
                              j[4] = 0;
                           }

                           var2 = false;
                           if (y != 0) {
                              break;
                           }

                           var10000 = L;

                           while(true) {
                              o = var10000;
                              if (o >= M) {
                                 if (ab != 0) {
                                    label686: {
                                       if (ai != 3) {
                                          if (aa < this.n - this.n / 8 - 40 - 31 - 16 + 9) {
                                             break label686;
                                          }

                                          var10000 = Z;
                                       } else {
                                          if (aa >= this.n - this.n / 8 - 40 - 32 - 12 + 9) {
                                             t = Z;
                                             --A;
                                          }

                                          if (ae < this.n - this.n / 8 - 40 - 32 - 12 + 9) {
                                             break label686;
                                          }

                                          var10000 = ad;
                                       }

                                       t = var10000;
                                       --A;
                                    }
                                 }

                                 if (A <= 0) {
                                    p = 5;
                                    s = 35;
                                    S = 25;
                                    am = 1;
                                    this.j = 3;
                                 }
                                 break label777;
                              }

                              if (c[o] >= this.n - this.n / 8 - 40 - 31 - 12 + 9) {
                                 t = o;
                                 --A;
                              }

                              var10000 = o + 1;
                           }
                        }

                        if (j[o] > 0) {
                           label917: {
                              label773: {
                                 if (i[o] == 0) {
                                    if (f[o] == 0) {
                                       if (e[o] != 0) {
                                          break label917;
                                       }

                                       g[o] = (g[o] + 1) % 2;
                                       if (g[o] == 0) {
                                          h[o] = (h[o] + 1) % 2;
                                       }

                                       if (o != 0 && o != 4) {
                                          c[o] += K;
                                          if (w == 1) {
                                             if (0 != a.nextInt() % 8) {
                                                break label917;
                                             }

                                             f[o] = a.nextInt() % 4;
                                             if (f[o] < 0) {
                                                f[o] = -f[o];
                                             }

                                             var14 = f;
                                             var9 = o;
                                             var10002 = (f[o] + 1) * 10;
                                          } else {
                                             if (0 != a.nextInt() % 16) {
                                                break label917;
                                             }

                                             f[o] = a.nextInt() % 3;
                                             if (f[o] < 0) {
                                                f[o] = -f[o];
                                             }

                                             var14 = f;
                                             var9 = o;
                                             var10002 = (f[o] + 1) * 10;
                                          }
                                       } else {
                                          var10002 = c[o]++;
                                          if (0 != a.nextInt() % 64) {
                                             break label917;
                                          }

                                          f[o] = a.nextInt() % 3;
                                          if (f[o] < 0) {
                                             f[o] = -f[o];
                                          }

                                          var14 = f;
                                          var9 = o;
                                          var10002 = (f[o] + 1) * 10;
                                       }
                                       break label773;
                                    }

                                    var14 = f;
                                 } else {
                                    var14 = i;
                                 }

                                 var9 = o;
                                 var10002 = var14[var9] - 1;
                              }

                              var14[var9] = var10002;
                           }
                        }

                        var10000 = o + 1;
                     }
                  }

                  if (z == 0) {
                     z = 1;
                     var1.drawRect(0, 0, this.m, this.n);
                     var1.setColor(240, 0, 0);
                     if (u != 0) {
                        p = 4;
                     }
                  }

                  var1.setColor(0, 0, 0);
                  var1.fillRect(0, 0, this.m, this.n);
                  var1.setColor(240, 0, 0);
                  var1.fillRect(0, this.n / 8, this.m, this.n);
                  var1.setColor(255, 0, 255);
                  var1.setColor(240, 0, 0);
                  if (ab == 0) {
                     var10000 = 0;

                     while(true) {
                        o = var10000;
                        if (o >= 5) {
                           break;
                        }

                        if (i[o] != 0) {
                           var1.drawImage(a[29], o * (this.m / 5) + (this.m / 5 - 32) / 2, 28, 0);
                        } else {
                           var1.fillRect(o * (this.m / 5) + (this.m / 5 - 32) / 2, 48, 28, 8);
                        }

                        var10000 = o + 1;
                     }
                  }

                  Image var15;
                  byte var10004;
                  if (ab != 0 && Y > 0) {
                     label661: {
                        X = (X + 1) % 16;
                        label660:
                        switch (ai) {
                           case 2:
                              var10000 = 0;

                              while(true) {
                                 o = var10000;
                                 if (o >= 8) {
                                    var1.drawImage(a[15], Z * (this.m / 5) + (this.m / 5 - 32) / 2, aa + 4, 0);
                                    if (P == 30) {
                                       var10 = var1;
                                       var10001 = a;
                                       var13 = 16;
                                    } else if (ab == 1) {
                                       var10 = var1;
                                       var10001 = a;
                                       var13 = 17;
                                    } else {
                                       var10 = var1;
                                       var10001 = a;
                                       var13 = 16;
                                    }
                                    break label660;
                                 }

                                 N = aa / 8 * o + 28;
                                 var1.drawImage(a[15], Z * (this.m / 5) + (this.m / 5 - 32) / 2, N - 36, 0);
                                 var10000 = o + 1;
                              }
                           case 3:
                              if (P == 30) {
                                 if (0 == X % 2) {
                                    var10 = var1;
                                    var15 = a[19];
                                    var10002 = Z * (this.m / 5) + (this.m / 5 - 31) / 2;
                                    var10003 = aa;
                                    var10004 = 28;
                                 } else {
                                    var10 = var1;
                                    var15 = a[18];
                                    var10002 = Z * (this.m / 5) + (this.m / 5 - 31) / 2;
                                    var10003 = aa;
                                    var10004 = 28;
                                 }
                              } else {
                                 var10 = var1;
                                 var15 = a[20];
                                 var10002 = Z * (this.m / 5) + (this.m / 5 - 31) / 2;
                                 var10003 = aa;
                                 var10004 = 34;
                              }

                              var10.drawImage(var15, var10002, var10003 + var10004, 0);
                              var10 = var1;
                              var15 = a[20];
                              var10002 = ad * (this.m / 5) + (this.m / 5 - 31) / 2;
                              var10003 = ae;
                              var10004 = 34;
                              break label661;
                           default:
                              if (X < 8) {
                                 var10 = var1;
                                 var10001 = a;
                                 var13 = 12;
                              } else {
                                 var10 = var1;
                                 var10001 = a;
                                 var13 = 13;
                              }
                        }

                        var15 = var10001[var13];
                        var10002 = Z * (this.m / 5) + (this.m / 5 - 32) / 2;
                        var10003 = aa;
                        var10004 = 28;
                     }

                     var10.drawImage(var15, var10002, var10003 + var10004, 0);
                  }

                  if (ac == 1) {
                     label645: {
                        label644:
                        switch (ai) {
                           case 2:
                              var10000 = 0;

                              while(true) {
                                 o = var10000;
                                 if (o >= 8) {
                                    var1.drawImage(a[15], ag * (this.m / 5) + (this.m / 5 - 32) / 2, ah + 18, 0);
                                    var10 = var1;
                                    var10001 = a;
                                    var13 = 16;
                                    break label644;
                                 }

                                 N = ah / 8 * o + 28;
                                 var1.drawImage(a[15], ag * (this.m / 5) + (this.m / 5 - 32) / 2, N - 24, 0);
                                 var10000 = o + 1;
                              }
                           case 3:
                              var10 = var1;
                              var15 = a[18];
                              var10002 = ag * (this.m / 5);
                              var10003 = this.m / 5;
                              var10004 = 31;
                              break label645;
                           default:
                              var10 = var1;
                              var10001 = a;
                              var13 = 14;
                        }

                        var15 = var10001[var13];
                        var10002 = ag * (this.m / 5);
                        var10003 = this.m / 5;
                        var10004 = 32;
                     }

                     var10.drawImage(var15, var10002 + (var10003 - var10004) / 2, ah + 28, 0);
                     var1.setColor(255, 255, 80);
                     var1.fillRect(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 2, ah + 24 + 4, 6, 12);
                     var1.fillRect(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, ah + 24 + 2, 2, 16);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 5, ah + 24 + 0, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 5, I + 28 + 8 + 10);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 0, ah + 24 + 5, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 10, I + 28 + 8 + 5);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 2, ah + 24 + 2, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 8, I + 28 + 8 + 8);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 8, ah + 24 + 2, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 2, I + 28 + 8 + 8);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, ah + 24 + 1, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, I + 28 + 8 + 9);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 6, ah + 24 + 1, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 6, I + 28 + 8 + 9);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 1, ah + 24 + 4, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 9, I + 28 + 8 + 4);
                     var1.drawLine(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 1, ah + 24 + 6, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 9, I + 28 + 8 + 6);
                     var1.setColor(255, 255, 255);
                     var1.fillRect(4 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, ah + 24 + 4, 2, 12);
                     var1.setColor(255, 255, 80);
                     var1.fillRect(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 2, ah + 14 + 4, 6, 12);
                     var1.fillRect(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, ah + 14 + 2, 2, 16);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 5, ah + 14 + 0, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 5, I + 28 + 8 + 10);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 0, ah + 14 + 5, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 10, I + 28 + 8 + 5);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 2, ah + 14 + 2, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 8, I + 28 + 8 + 8);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 8, ah + 14 + 2, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 2, I + 28 + 8 + 8);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, ah + 14 + 1, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, I + 28 + 8 + 9);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 6, ah + 14 + 1, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 6, I + 28 + 8 + 9);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 1, ah + 14 + 4, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 9, I + 28 + 8 + 4);
                     var1.drawLine(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 1, ah + 14 + 6, H * (this.m / 5) + (this.m / 5 - 32) / 2 + 9, I + 28 + 8 + 6);
                     var1.setColor(255, 255, 255);
                     var1.fillRect(8 + ag * (this.m / 5) + (this.m / 5 - 32) / 2 + 4, ah + 14 + 4, 2, 12);
                  }

                  D += F;
                  if (D <= 0) {
                     D = 0;
                  }

                  if (D >= 4) {
                     D = 4;
                  }

                  F = 0;
                  var1.setColor(0, 0, 0);
                  var1.fillRect(0, 0, this.m, 26);
                  if (B == 0) {
                     var1.drawImage(a[0], 5, 7, 0);
                  } else {
                     var10000 = 0;

                     while(true) {
                        o = var10000;
                        if (o >= B) {
                           break;
                        }

                        var1.drawImage(a[28], o * 8 + 5, 5, 0);
                        var10000 = o + 1;
                     }
                  }

                  var1.setColor(255, 0, 255);
                  var1.fillRect(0, this.n - a[5].getHeight(), this.m, 50);
                  var1.setColor(16777215);
                  var1.drawString(this.b[0], 0, this.n, 36);
                  var1.drawString(this.b[1], this.m, this.n, 40);
                  if (Q == 0) {
                     if (J == 3 && G != 0) {
                        var10 = var1;
                        var10001 = a;
                        var13 = 5;
                     } else {
                        var10 = var1;
                        var10001 = a;
                        var13 = 4;
                     }
                  } else if (J == 3 && G != 0) {
                     var10 = var1;
                     var10001 = a;
                     var13 = 7;
                  } else {
                     var10 = var1;
                     var10001 = a;
                     var13 = 6;
                  }

                  var10.drawImage(var10001[var13], D * (this.m / 5) + (this.m / 5 - 28) / 2, E, 0);
                  var10000 = L;

                  while(true) {
                     o = var10000;
                     if (o >= M) {
                        if (p != 5) {
                           if (G == 2) {
                              if (J == 3) {
                                 var10 = var1;
                                 var10001 = a;
                                 var13 = 25;
                              } else {
                                 var10 = var1;
                                 var10001 = a;
                                 var13 = 24;
                              }

                              var10.drawImage(var10001[var13], H * (this.m / 5) + (this.m / 5 - 20) / 2, I + 32, 0);
                              --J;
                              if (J <= 0) {
                                 G = 0;
                                 J = 0;
                              }
                           }

                           if (G == 3) {
                              G = 0;
                              var1.drawImage(a[25], H * (this.m / 5) + (this.m / 5 - 20) / 2, I + 32, 0);
                           }
                        }

                        if (99999999 <= v) {
                           v = 99999999;
                        }

                        var1.setColor(255, 255, 255);
                        if (a <= v) {
                           var1.setColor(255, 0, 0);
                        }

                        a = String.valueOf(v);
                        var1.drawString(a, this.m - a.stringWidth(a), this.n / 10 - 15, 0);
                        if (P == 30) {
                           var1.setColor(0, 0, 80);
                           a = this.a[21];
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 2, 0);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2, 0);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, this.n / 2 + 1, 0);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, this.n / 2 + 1, 0);
                           var1.setColor(200, 200, 200);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 1, 0);
                           switch (ai) {
                              case 2:
                                 var8 = "Yawn";
                                 break;
                              case 3:
                                 var8 = "Crow";
                                 break;
                              default:
                                 var8 = "Tyrant";
                           }

                           a = var8;
                           var1.setColor(0, 0, 80);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 5, 0);
                           var1.setColor(200, 200, 200);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 5, 0);
                        }
                        break label865;
                     }

                     if (j[o] > 0) {
                        label924: {
                           if (i[o] == 0) {
                              if (e[o] <= 0) {
                                 e[o] = 0;
                                 if (o != 0 && o != 4) {
                                    var10 = var1;
                                    var15 = a[g[o] + 1];
                                    var10002 = o * (this.m / 5) + (this.m / 5 - 32) / 2;
                                    var10003 = c[o] + 28;
                                 } else {
                                    var10 = var1;
                                    var15 = a[h[o] + 9];
                                    var10002 = o * (this.m / 5) + (this.m / 5 - 32) / 2;
                                    var10003 = c[o] + 28;
                                 }
                              } else {
                                 var10002 = e[o]--;
                                 if (o != 0 && o != 4) {
                                    var10 = var1;
                                    var15 = a[3];
                                    var10002 = o * (this.m / 5) + (this.m / 5 - 28) / 2;
                                    var10003 = c[o] + 28;
                                 } else {
                                    var10 = var1;
                                    var15 = a[11];
                                    var10002 = o * (this.m / 5) + (this.m / 5 - 24) / 2;
                                    var10003 = c[o] + 28;
                                 }
                              }
                           } else {
                              if (i[o] == 1) {
                                 var10 = var1;
                                 var10001 = a;
                                 var13 = 30;
                              } else {
                                 if (ab != 0) {
                                    break label924;
                                 }

                                 var10 = i[o] != 2 && i[o] != 4 && i[o] != 6 ? var1 : var1;
                                 var10001 = a;
                                 var13 = 29;
                              }

                              var15 = var10001[var13];
                              var10002 = o * (this.m / 5) + (this.m / 5 - 32) / 2;
                              var10003 = 28;
                           }

                           var10.drawImage(var15, var10002, var10003, 0);
                        }
                     }

                     var10000 = o + 1;
                  }
               } else {
                  this.a(0, this.a[39]);
                  this.a(1, this.a[38]);
                  a = this.a[34];
                  var1.setColor(0);
                  var1.fillRect(0, this.n / 2 - 8, this.m, 15);
                  var1.setColor(16777215);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 - 6, 0);
                  var1.setColor(255, 0, 255);
                  var1.fillRect(0, this.n - a[5].getHeight(), this.m, 50);
                  if (Q == 0) {
                     if (J == 3 && G != 0) {
                        var10 = var1;
                        var10001 = a;
                        var13 = 5;
                     } else {
                        var10 = var1;
                        var10001 = a;
                        var13 = 4;
                     }
                  } else if (J == 3 && G != 0) {
                     var10 = var1;
                     var10001 = a;
                     var13 = 7;
                  } else {
                     var10 = var1;
                     var10001 = a;
                     var13 = 6;
                  }

                  var10.drawImage(var10001[var13], D * (this.m / 5) + (this.m / 5 - 28) / 2, E, 0);
                  var1.setColor(16777215);
                  var1.drawString(this.b[0], 0, this.n, 36);
                  var1.drawString(this.b[1], this.m, this.n, 40);
                  break label865;
               }
            case 2:
               this.f = true;
               if (q != 1) {
                  this.a(0, this.a[40]);
                  if (this.b) {
                     var11 = this.a;
                     var12 = 15;
                  } else {
                     var11 = this.a;
                     var12 = 16;
                  }

                  a = var11[var12];
                  this.a(1, a);
                  var1.setColor(0, 0, 0);
                  var1.fillRect(0, 0, this.m, this.n);
                  var1.setColor(0, 0, 80);
                  a = this.a[22] + w;
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 2, 0);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2, 0);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, this.n / 2 + 1, 0);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, this.n / 2 + 1, 0);
                  var1.setColor(120, 120, 255);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 1, 0);
                  if (U <= -40) {
                     U = -40;
                  }

                  if (V <= -20) {
                     V = -20;
                  }

                  var1.setColor(40, 0, 0);
                  var1.fillRect((this.m - 53) / 2 + U, this.n / 2 + 53 - 0 - V, (this.m - 53) / 2 + 53 - U * 2, 5);
                  var1.setColor(80, 0, 0);
                  var1.fillRect((this.m - 53) / 2 + U, this.n / 2 + 53 - 5 - V, (this.m - 53) / 2 + 53 - U * 2, 5);
                  var1.setColor(120, 0, 0);
                  var1.fillRect((this.m - 53) / 2 + U, this.n / 2 + 53 - 10 - V, (this.m - 53) / 2 + 53 - U * 2, 5);
                  var1.setColor(40, 40, 40);
                  if (U < 40) {
                     var1.fillRect(0, 0, (this.m - 53) / 2 + U, this.n);
                     var1.fillRect((this.m - 53) / 2 + 53 - U, 0, this.m, this.n);
                  }

                  if (U < 20) {
                     var1.fillRect(0, 0, this.m, (this.n - 106) / 2 + V);
                     var1.setColor(0, 0, 0);
                     var1.fillRect(0, (this.n - 106) / 2 + 106 - V, this.m, this.n);
                  }

                  label804: {
                     if (T > 25) {
                        this.j = 0;
                        var10 = var1;
                        var10001 = a;
                        var13 = 21;
                     } else if (T > 20) {
                        var10 = var1;
                        var10001 = a;
                        var13 = 22;
                     } else {
                        if (T < 15) {
                           break label804;
                        }

                        var10 = var1;
                        var10001 = a;
                        var13 = 23;
                     }

                     var10.drawImage(var10001[var13], (this.m - 53) / 2, (this.n - 106) / 2, 0);
                  }

                  if (T < 15) {
                     var1.setColor(100, 0, 0);
                     var1.fillRect((this.m - 53) / 2 + 53 - U, 20 + V, 4, this.n);
                     U -= 3;
                     V -= 3;
                  }

                  --T;
                  if (T == 0) {
                     p = 1;
                     ak = 1;
                     this.j = 1;
                  }

                  var1.setColor(0, 0, 0);
               } else {
                  this.a(0, this.a[39]);
                  this.a(1, this.a[38]);
                  a = this.a[34];
                  var1.setColor(0);
                  var1.fillRect(0, this.n / 2 - 8, this.m, 15);
                  var1.setColor(16777215);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 - 9, 0);
               }
               break label865;
            case 3:
               this.f = true;
               P = 0;
               p = 4;
               ab = 0;
               an = 1;
               this.j = 4;
               break label865;
            case 4:
               this.f = true;
               if (q != 1) {
                  this.a(0, this.a[40]);
                  if (this.b) {
                     var11 = this.a;
                     var9 = 15;
                  } else {
                     var11 = this.a;
                     var9 = 16;
                  }

                  a = var11[var9];
                  this.a(1, a);
                  if (y == 0) {
                     if (u != 0) {
                        --u;
                        var1.setColor(16777215);
                        a = this.a[35];
                        var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2, 0);
                     }

                     if (u <= 0) {
                        p = 1;
                        z = 0;
                     }
                  } else {
                     if (u != 0) {
                        --u;
                        var1.setColor(255, 255, 255);
                        a = this.a[36];
                        var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 3, 0);
                        var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 3 + 2, 0);
                        var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, this.n / 8 * 3 + 1, 0);
                        var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, this.n / 8 * 3 + 1, 0);
                        var1.setColor(0, 0, 255);
                        var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 3 + 1, 0);
                        if (u < 15) {
                           var1.setColor(255, 255, 255);
                           a = this.a[23] + w + "000";
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2, 0);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 2, 0);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, this.n / 2 + 1, 0);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, this.n / 2 + 1, 0);
                           var1.setColor(0, 0, 255);
                           var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 1, 0);
                        }
                     }

                     if (u <= 0) {
                        y = 0;
                        v += w * 1000;
                        ++w;
                        ++ai;
                        if (ai >= 5) {
                           ai = 2;
                        }

                        T = 35;
                        U = 0;
                        V = 0;
                        p = 2;
                        ac = 0;
                        z = 0;
                        G = 0;
                        var10000 = 0;

                        while(true) {
                           o = var10000;
                           if (o >= 5) {
                              break label865;
                           }

                           c[o] = 0;
                           e[o] = 0;
                           i[o] = 7;
                           if (this.a) {
                              var14 = j;
                              var9 = o;
                              var10002 = 1;
                           } else {
                              var14 = j;
                              var9 = o;
                              var10002 = 20 + w * 5;
                           }

                           var14[var9] = var10002;
                           var10000 = o + 1;
                        }
                     }
                  }
               } else {
                  this.a(0, this.a[39]);
                  this.a(1, this.a[38]);
                  a = this.a[34];
                  var1.setColor(0);
                  var1.fillRect(0, this.n / 2 - 8, this.m, 15);
                  var1.setColor(16777215);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 - 9, 0);
               }
               break label865;
            case 5:
               this.f = true;
               if (q != 1) {
                  this.a(0, "");
                  this.a(1, "");
                  --s;
                  if (S > 0) {
                     --S;
                  }

                  var1.setColor(120, 120, 0);
                  var1.drawLine(0, this.n - 40, this.m, this.n - 40);
                  var1.setColor(255, 255, 0);
                  var1.drawLine(t * (this.m / 5) + (this.m / 5 - 32) / 2, this.n - 40 + 1, t * (this.m / 5) + (this.m / 5 - 32) / 2 + 32, this.n - 40 + 1);
                  var1.setColor(240, 0, 0);
                  if (ab != 1 || ai != 2) {
                     var1.fillRect(t * (this.m / 5) + (this.m / 5 - 32) / 2, d[t] + 18, 15, 10);
                     var1.setColor(0, 0, 0);
                     var1.fillRect(0, 0, this.m, 26);
                  }

                  if (ab == 0) {
                     if (t != 0 && t != 4) {
                        var10 = var1;
                        var10001 = a;
                        var10002 = s % 2;
                        var10003 = 1;
                     } else {
                        var10 = var1;
                        var10001 = a;
                        var10002 = s % 2;
                        var10003 = 9;
                     }

                     var10.drawImage(var10001[var10002 + var10003], t * (this.m / 5) + (this.m / 5 - 32) / 2, c[t] + 28, 0);
                  }

                  if (s == 0) {
                     p = 0;
                     z = 0;
                     if (a <= v) {
                        a = v;
                     }
                  }

                  if (S < 20) {
                     ++this.ap;
                     var2 = false;
                     var1.setColor(120, 10, 10);
                     var1.fillRect(0, 0, this.m, this.n - S * 6);
                     var1.fillRect(10, 0, 10, (this.n / 6 - S) * 8);
                     var1.fillRect(20, 0, 10, (this.n / 6 - S) * 10);
                     var1.fillRect(30, 0, 10, (this.n / 6 - S) * 13);
                     var1.fillRect(35, 0, 10, (this.n / 6 - S) * 11);
                     var1.fillRect(40, 0, 10, (this.n / 6 - S) * 9);
                     var1.fillRect(50, 0, 10, (this.n / 6 - S) * 16);
                     var1.fillRect(60, 0, 10, (this.n / 6 - S) * 20);
                     var1.fillRect(65, 0, 10, (this.n / 6 - S) * 19);
                     var1.fillRect(70, 0, 10, (this.n / 6 - S) * 18);
                     var1.fillRect(80, 0, 10, (this.n / 6 - S) * 12);
                     var1.fillRect(85, 0, 10, (this.n / 6 - S) * 10);
                     var1.fillRect(90, 0, 10, (this.n / 6 - S) * 7);
                     var1.fillRect(110, 0, 10, (this.n / 6 - S) * 11);
                     var1.fillRect(2, 0, 6, 2 + (this.n / 6 - S) * 6);
                     var1.fillRect(12, 0, 6, 2 + (this.n / 6 - S) * 8);
                     var1.fillRect(22, 0, 6, 2 + (this.n / 6 - S) * 10);
                     var1.fillRect(32, 0, 6, 2 + (this.n / 6 - S) * 13);
                     var1.fillRect(42, 0, 6, 2 + (this.n / 6 - S) * 9);
                     var1.fillRect(52, 0, 6, 2 + (this.n / 6 - S) * 16);
                     var1.fillRect(62, 0, 6, 2 + (this.n / 6 - S) * 20);
                     var1.fillRect(72, 0, 6, 2 + (this.n / 6 - S) * 18);
                     var1.fillRect(82, 0, 6, 2 + (this.n / 6 - S) * 12);
                     var1.fillRect(92, 0, 6, 2 + (this.n / 6 - S) * 7);
                     var1.fillRect(102, 0, 6, 2 + (this.n / 6 - S) * 6);
                     var1.fillRect(112, 0, 6, 2 + (this.n / 6 - S) * 11);
                  }

                  if (s <= 10) {
                     var1.setColor(255, 255, 255);
                     a = this.a[24];
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, this.n / 8 * 3, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, this.n / 8 * 3, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 3 + 1, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 3 - 1, 0);
                     var1.setColor(0, 0, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 8 * 3, 0);
                     var1.setColor(255, 255, 255);
                     a = this.a[25] + v;
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, this.n / 2, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, this.n / 2, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 + 1, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 - 1, 0);
                     var1.setColor(0, 0, 0);
                     var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2, 0);

                     try {
                        Thread.sleep(200L);
                     } catch (Exception var5) {
                     }
                  }
               } else {
                  this.a(0, this.a[39]);
                  this.a(1, this.a[38]);
                  a = this.a[34];
                  var1.setColor(0);
                  var1.fillRect(0, this.n / 2 - 8, this.m, 15);
                  var1.setColor(16777215);
                  var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 2 - 9, 0);
               }

               try {
                  if (this.c) {
                     DeviceControl.startVibra(100, 1000L);
                  }
               } catch (Exception var4) {
               }
            case 6:
            case 7:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 44:
            case 45:
            default:
               break label865;
            case 8:
               this.f = false;
               this.a(0, "");
               this.a(1, this.a[38]);
               R += 5;
               if (R >= 140) {
                  R = -40;
               }

               var1.setColor(50, 50, 120);
               var1.fillRect(0, 0, this.m, this.n);
               var1.setColor(255, 255, 255);
               a = this.a[29];
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, this.n / 12 - 16, 0);
               this.a(var1, 31, 5, this.n / 4, false);
               this.a(var1, 33, this.m - 5 - 16, this.n / 4, true);
               var1.setColor(255, 255, 0);
               a = this.a[26];
               var1.drawString(a, this.m / 2 - a.stringWidth(a), this.n / 10 * 7 + this.l - 16, 0);
               a = this.a[27];
               var1.drawString(a, this.m / 2 - a.stringWidth(a), this.n / 10 * 7 + this.l * 2 + 10 - 16, 0);
               if (Q == 0) {
                  var1.drawImage(a[26], this.m / 2 - a[26].getWidth() / 2 - 1, this.n / 8, 0);
                  var1.setColor(255, 0, 0);
                  var1.fillRect(this.m / 2, this.n / 10 * 7, this.m / 2 / 3 * 2, this.l);
                  var1.setColor(0, 255, 255);
                  var1.fillRect(this.m / 2, this.n / 10 * 7 + this.l + 10, this.m / 2 / 3, this.l);
                  var8 = "Leon Kennedy";
               } else {
                  var1.drawImage(a[27], this.m / 2 - a[26].getWidth() / 2 - 1, this.n / 8, 0);
                  var1.setColor(255, 0, 0);
                  var1.fillRect(this.m / 2, this.n / 10 * 7, this.m / 2 / 3, this.l);
                  var1.setColor(0, 255, 255);
                  var1.fillRect(this.m / 2, this.n / 10 * 7 + this.l + 10, this.m / 2 / 3 * 2, this.l);
                  var8 = "Claire Redfield";
               }

               a = var8;
               var1.setColor(255, 0, 0);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2 - 1, a[26].getHeight() + 5 + this.n / 8 + 2, 0);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2 + 1, a[26].getHeight() + 5 + this.n / 8 + 2, 0);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, a[26].getHeight() + 5 + this.n / 8 + 1, 0);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, a[26].getHeight() + 5 + this.n / 8 + 3, 0);
               var1.setColor(255, 255, 0);
               var1.drawString(a, (this.m - a.stringWidth(a)) / 2, a[26].getHeight() + 5 + this.n / 8 + 2, 0);
               var1.setColor(16777215);
               var1.drawString(this.b[0], 0, this.n, 36);
               var1.drawString(this.b[1], this.m, this.n, 40);
               break label865;
            case 41:
               aj = -1;
               p = 42;
            case 42:
               if (aj == -1) {
                  break label865;
               }

               var10000 = 43;
               break;
            case 43:
               if (aj == -1) {
                  break label865;
               }

               var10000 = 40;
         }

         p = var10000;
         aj = -1;
      }

      this.e();
   }

   private void a(String var1) {
      if (this.a != null) {
         this.d();
      }

      try {
         this.a = Manager.createPlayer(this.getClass().getResourceAsStream(var1), "Audio/midi");
         this.a.realize();
         this.b(100);
         this.a.prefetch();
         this.a.getControl("MIDIControl");
      } catch (Exception var3) {
         System.out.println(var3);
      }
   }

   private void a(int var1) {
      if (this.a != null) {
         try {
            this.a.setLoopCount(var1);
            this.a.start();
         } catch (Exception var3) {
            System.out.println(var3);
         }
      }
   }

   private void c() {
      if (this.a != null) {
         if (this.a.getState() == 400) {
            try {
               this.a.stop();
               return;
            } catch (Exception var2) {
               System.out.println(var2);
            }
         }

      }
   }

   private void d() {
      if (this.a != null) {
         this.c();

         while(true) {
            if (this.a.getState() != 400) {
               this.a.close();
               this.a = null;
               break;
            }
         }
      }

   }

   private void b(int var1) {
      ((VolumeControl)this.a.getControl("VolumeControl")).setLevel(var1);
   }

   private void e() {
      if (this.b) {
         if (ak == 1 || c == 1) {
            this.j = 1;

            try {
               this.a(this.c[0]);
               this.a(-1);
            } catch (Exception var6) {
            }

            b = 1;
            ak = 0;
            c = 0;
         }

         if (al == 1) {
            this.j = 2;

            try {
               this.a(this.c[1]);
               this.a(-1);
            } catch (Exception var5) {
            }

            b = 0;
            al = 0;
         }

         if (am == 1) {
            this.j = 3;

            try {
               this.a(this.c[2]);
               this.a(1);
            } catch (Exception var4) {
            }

            b = 0;
            am = 0;
            c = 0;
         }

         if (an == 1) {
            this.j = 4;

            try {
               this.a(this.c[3]);
               this.a(1);
            } catch (Exception var3) {
            }

            b = 2;
            an = 0;
         }
      }

      if (ao == 1) {
         try {
            this.d();
         } catch (Exception var2) {
         }

         b = 0;
         ao = 0;
      }

   }

   public final void keyPressed(int var1) {
      if (!this.f) {
         int var2 = this.getGameAction(var1);
         if (var1 == -6 || var1 == -7) {
            this.c(var1);
         }

         aj = var1;
         a var10000;
         int var5;
         switch (p) {
            case -1:
               if (var2 == 1 || var1 == -1) {
                  if (this.aq == 0) {
                     var10000 = this;
                     var5 = 4;
                  } else {
                     var10000 = this;
                     var5 = this.aq - 1;
                  }

                  var10000.aq = var5;
               }

               if (var2 == 6 || var1 == -6) {
                  if (this.aq == 4) {
                     var10000 = this;
                     var5 = 0;
                  } else {
                     var10000 = this;
                     var5 = this.aq + 1;
                  }

                  var10000.aq = var5;
               }

               if (var1 == -5 || var1 == 5 || var1 == 53) {
                  this.d(this.aq);
                  this.a(0, "");
                  this.a(1, this.a[37]);
                  p = 0;
                  return;
               }
               break;
            case 0:
               label134: {
                  if (a[this.i] == var1) {
                     if (++this.i != a.length) {
                        break label134;
                     }

                     this.a = !this.a;
                  }

                  this.i = 0;
               }

               if (var1 == 52 || var1 == -3) {
                  ++W;
                  if (W > 1) {
                     W = 0;
                  }
               }

               if (var1 == 54 || var1 == -4) {
                  --W;
                  if (W < 0) {
                     W = 1;
                  }
               }

               if (var1 == -5 || var1 == 5 || var1 == 53) {
                  switch (W) {
                     case 0:
                        v = 0;
                        A = 1;
                        B = 6;
                        D = 2;
                        E = this.n - a[5].getHeight();
                        z = 0;
                        G = 0;
                        K = 2;
                        int var3 = 0;

                        while(true) {
                           o = var3;
                           if (o >= 5) {
                              j[0] = 0;
                              j[4] = 0;
                              L = 1;
                              M = 4;
                              u = 10;
                              x = 0;
                              y = 0;
                              w = 1;
                              p = 8;
                              T = 35;
                              U = 0;
                              V = 0;
                              u = 10;
                              ai = 1;
                              P = 0;
                              ab = 0;
                              return;
                           }

                           c[o] = 0;
                           e[o] = 0;
                           i[o] = 7;
                           byte var10002;
                           int[] var4;
                           if (this.a) {
                              var4 = j;
                              var5 = o;
                              var10002 = 1;
                           } else {
                              var4 = j;
                              var5 = o;
                              var10002 = 20;
                           }

                           var4[var5] = var10002;
                           var3 = o + 1;
                        }
                     case 1:
                        boolean var10001;
                        if (this.b) {
                           var10000 = this;
                           var10001 = false;
                        } else {
                           var10000 = this;
                           var10001 = true;
                        }

                        var10000.b = var10001;
                     default:
                        return;
                  }
               }
               break;
            case 1:
            case 2:
               if (q != 1) {
                  if (var1 == 52 || var1 == -3 || var1 == 49 || var1 == 55) {
                     F = -1;
                     return;
                  }

                  if (var1 == 54 || var1 == -4 || var1 == 51 || var1 == 57) {
                     F = 1;
                     return;
                  }

                  if ((var1 == -1 || var1 == 53 || var1 == -5 || var1 == -5 || var1 == 50 || var1 == 56) && B != 0) {
                     G = 1;
                     H = D;
                     return;
                  }
               }
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            default:
               break;
            case 8:
               if (var1 != 52 && var1 != -3) {
                  if (var1 != 54 && var1 != -4) {
                     if (var1 == -5 || var1 == 5 || var1 == 53) {
                        p = 2;
                     }

                     this.f = true;
                     return;
                  }

                  ++Q;
                  Q %= 2;
                  return;
               }

               ++Q;
               Q %= 2;
               return;
         }

      }
   }

   private void a(Graphics var1, int var2, int var3, int var4, boolean var5) {
      var1.drawImage(a[var2 + this.k], var3, var4, 0);
      if (var5 && System.currentTimeMillis() - this.a > 100L) {
         if (++this.k > 1) {
            this.k = 0;
         }

         this.a = System.currentTimeMillis();
      }

   }

   private void a(int var1, String var2) {
      this.b[var1] = var2;
   }

   private void c(int var1) {
      switch (p) {
         case 0:
            if (var1 == -7) {
               this.e = false;
            }

            this.a.a();
            return;
         case 1:
         case 2:
            if (var1 == -6) {
               if (q == 1) {
                  q = 0;
                  if (this.b) {
                     switch (this.j) {
                        case 1:
                           ak = 1;
                           break;
                        case 2:
                           al = 1;
                           break;
                        case 3:
                           am = 1;
                           break;
                        case 4:
                           an = 1;
                     }
                  }
               } else {
                  q = 1;
                  ao = 1;
               }
            }

            if (q == 1 && var1 == -7) {
               p = 0;
            }

            if (q != 1 && var1 == -7) {
               if (this.b) {
                  this.b = false;
                  ao = 1;
                  return;
               }

               this.b = true;
               ao = 0;
               switch (this.j) {
                  case 1:
                     ak = 1;
                     return;
                  case 2:
                     al = 1;
                     return;
                  case 3:
                     am = 1;
                     return;
                  case 4:
                     an = 1;
                  default:
                     return;
               }
            }

            return;
         case 3:
            if (var1 != -7) {
               return;
            }
            break;
         case 5:
            if (var1 == -7) {
               if (this.b) {
                  this.b = false;
                  ao = 1;
                  return;
               }

               this.b = true;
               ao = 0;
               switch (this.j) {
                  case 1:
                     ak = 1;
                     return;
                  case 2:
                     al = 1;
                     return;
                  case 3:
                     am = 1;
                     return;
                  case 4:
                     an = 1;
                  default:
                     return;
               }
            }

            return;
         case 8:
            if (var1 != -7) {
               return;
            }
            break;
         case 99:
            if (var1 == -7) {
               this.e = false;
            }

            this.a.a();
            return;
         default:
            return;
      }

      p = 0;
   }

   private final String[] a() {
      DataInputStream var1 = null;
      new StringBuffer();
      this.a = new String[5];
      boolean var11 = false;

      label101: {
         try {
            var11 = true;
            var1 = new DataInputStream(this.getClass().getResourceAsStream("all.txt"));

            for(int var3 = 0; var3 < 5; ++var3) {
               this.a[var3] = var1.readUTF();
            }

            var11 = false;
            break label101;
         } catch (Throwable var15) {
            var11 = false;
         } finally {
            if (var11) {
               if (var1 != null) {
                  try {
                     var1.close();
                  } catch (Exception var12) {
                  }
               }

            }
         }

         if (var1 != null) {
            try {
               var1.close();
            } catch (Exception var13) {
            }

            return this.a;
         }

         return this.a;
      }

      try {
         var1.close();
      } catch (Exception var14) {
      }

      return this.a;
   }

   private final void d(int var1) {
      DataInputStream var2 = null;
      int var4 = 0;
      new StringBuffer();
      this.a = new String[41];
      String var5 = null;
      int var6 = var1 * 41 + 5;
      boolean var15 = false;

      label110: {
         try {
            var15 = true;
            var2 = new DataInputStream(this.getClass().getResourceAsStream("all.txt"));

            for(int var7 = 0; var7 < var6; ++var7) {
               var2.readUTF();
            }

            while((var5 = var2.readUTF()) != null) {
               this.a[var4] = var5;
               ++var4;
            }

            var15 = false;
            break label110;
         } catch (Throwable var19) {
            var15 = false;
         } finally {
            if (var15) {
               if (var2 != null) {
                  try {
                     var2.close();
                  } catch (Exception var16) {
                  }
               }

            }
         }

         if (var2 != null) {
            try {
               var2.close();
               return;
            } catch (Exception var17) {
               return;
            }
         }

         return;
      }

      try {
         var2.close();
      } catch (Exception var18) {
      }
   }

   private void f() {
      RecordStore var1 = null;

      try {
         try {
            if ((var1 = RecordStore.openRecordStore("ZBuster", true)).getNumRecords() == 0) {
               a = 0;
               this.b = true;
               this.c = true;
            } else {
               byte[] var3 = var1.getRecord(1);
               a = (new DataInputStream(new ByteArrayInputStream(var3, 0, 4))).readInt();
               DataInputStream var2 = new DataInputStream(new ByteArrayInputStream(var3, 4, 1));
               this.b = var2.readBoolean();
               var2 = new DataInputStream(new ByteArrayInputStream(var3, 5, 1));
               this.c = var2.readBoolean();
               var2.close();
            }
         } finally {
            if (var1 != null) {
               var1.closeRecordStore();
            }

         }
      } catch (Exception var8) {
         System.out.println(var8);
         a = 0;
         this.b = true;
         this.c = true;
      }

   }

   public final void a() {
      RecordStore var1 = null;

      try {
         try {
            RecordStore.deleteRecordStore("ZBuster");
            var1 = RecordStore.openRecordStore("ZBuster", true);
            ByteArrayOutputStream var2 = new ByteArrayOutputStream();
            DataOutputStream var3;
            (var3 = new DataOutputStream(var2)).writeInt(a);
            var3.writeBoolean(this.b);
            var3.writeBoolean(this.c);
            byte[] var4 = var2.toByteArray();
            var1.addRecord(var4, 0, var4.length);
         } finally {
            if (var1 != null) {
               var1.closeRecordStore();
            }

         }
      } catch (Exception var9) {
         System.out.println(var9);
      }

   }
}
