/* rtlwifi_test.c — хост-тест драйвера RTL8192EU N2600-OS.
 *
 * Компилирует НАСТОЯЩИЕ src/rtl8192eu.c + src/wifi_core.c + src/wpa2.c
 * против СИМУЛЯТОРА USB-устройства RTL8192EU (usb_ehci_ctrl_xfer/
 * usb_ehci_bulk_xfer — заглушки уровня EHCI). Проверяет:
 *   1. attach: VID/PID 0bda:818b, разбор bulk-эндпоинтов;
 *   2. probe: полный bring-up, загрузка прошивки БАЙТ-В-БАЙТ (страницы
 *      в 0x1000 через vendor writeN = встроенный rtl8192eu_fw_data),
 *      запуск 8051 (MCU_WINT_INIT_READY), MAC из efuse;
 *   3. скан: смены каналов (RF 0x18), beacon -> список AP (SSID/защита);
 *      список ПЕРЕЖИВАЕТ повторный скан (регрессия «поиск заново»);
 *   4. подключение WPA2: AUTH REQ -> AUTH resp -> ASSOC REQ (SSID+RSN IE)
 *      -> ASSOC resp -> M1 -> M2 (MIC по PTK) -> M3 -> CONNECTED + CAM
 *      (PTK idx0 с TA=BSSID, GTK keyid) + M4;
 *   5. данные: wifi_net_send -> TX data кадр (ToDS+Protected, LLC/SNAP,
 *      BSSID/DA), RX data кадр -> wifi_net_recv Ethernet-кадр;
 *   6. дескриптор TX: чексумма (XOR 16 слов = 0), queue_sel (MGNT/BE),
 *      OWN/FIRST/LAST, pkt_offset=40;
 *   7. профиль: wifi_profile_save/load через RAM-заглушку ramfs.
 *
 * Сборка: run_rtlwifi.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "types.h"
#include "wifi_core.h"
#include "usb_ehci.h"
#include "wpa2.h"

/* ============ счётчики/проверки ============ */
static int fails, checks;
#define CHECK(cond, name) do { \
    checks++; if (cond) { printf("  ok  %s\n", name); } \
    else { fails++; printf("  FAIL %s (%s:%d)\n", name, __FILE__, __LINE__); } \
} while (0)

/* ============ симулятор устройства ============ */

/* vendor-регистры: байтовый файл 64 КиБ */
static u8 sim_regs[65536];
/* прошивка, записанная в RAM чипа (0x1000..) */
static u8 sim_fw_ram[65536];
static int sim_fw_written;
static int sim_fw_pages_mark;      /* содержимое REG_MCU_FW_DL+2 (page idx) */
static int sim_mcu_started;
static int sim_8051_reset_count;
static int sim_llt_done;
static u8 sim_rf_last_reg[2];
static u32 sim_cam_pending;
static int sim_fw_dl_active;
/* RF-регистры (2 пути) */
static u32 sim_rf[2][64];
/* efuse-карта (512 байт) */
static u8 sim_efuse[512];
/* CAM: 8 ячеек по 6 слов */
static u32 sim_cam[8][6];
static int sim_cam_writes;
/* TX-захваты */
#define TXCAP_MAX 64
static struct {
    int ep; int len;
    u8 desc[40];
    u8 frame[1600];
} sim_tx[TXCAP_MAX];
static int sim_tx_n;
/* очередь RX (кадры, которые «принял чип») */
#define RXQ_MAX 32
static u8 sim_rxq[RXQ_MAX][2048];
static int sim_rx_len[RXQ_MAX];
static int sim_rx_head, sim_rx_count;

/* константы, симулятору нужные */
#define S_REG_MCU_FW_DL     0x0080
#define S_REG_MCU_FW_DL_C   0x0082
#define S_REG_SYS_CFG       0x00F0
#define S_REG_HPON_FSM      0x00E0
#define S_REG_EFUSE_CTRL    0x0030   /* REG_EFUSE_CTRL реальный = 0x30 */
#define S_REG_EFUSE_ACCESS  0x0043
#define S_REG_AUTO_LLT      0x0224
#define S_REG_APS_FSMCO     0x0004
#define S_FW_BASE           0x1000
#define S_RF_MODE_AG        0x18

static const u8 sim_mac[6] = { 0x48, 0x5b, 0x39, 0x22, 0x33, 0x44 };
static const u8 sim_bssid[6] = { 0xc0, 0x25, 0xe9, 0x11, 0x22, 0x33 };
/* изменяемая копия: тест СЕССИИ 32 подключается к ДРУГОЙ точке (другой
 * BSSID — иначе парсер обновит запись HomeNet, а не создаст новую) */
static u8 cur_bssid[6];
static const char *sim_ssid = "HomeNet";
#define SIM_CHANNEL 6
#define SIM_PASS    "password123"

static u8 g_rx_eth_dst[6], g_rx_eth_src[6];

static void sim_reset(void) {
    memset(sim_regs, 0, sizeof(sim_regs));
    memset(sim_fw_ram, 0, sizeof(sim_fw_ram));
    memset(sim_rf, 0, sizeof(sim_rf));
    memset(sim_cam, 0, sizeof(sim_cam));
    memset(sim_efuse, 0xff, sizeof(sim_efuse));
    sim_tx_n = 0; sim_rx_head = 0; sim_rx_count = 0;
    sim_fw_written = 0; sim_fw_pages_mark = 0;
    sim_mcu_started = 0; sim_8051_reset_count = 0; sim_llt_done = 0;
    sim_fw_dl_active = 0; sim_rf_last_reg[0] = sim_rf_last_reg[1] = 0;
    sim_cam_pending = 0;
    sim_cam_writes = 0;

    /* SYS_CFG: версия 5 в битах 12-15, не тестовый, SPS_LDO_SEL=0 */
    sim_regs[S_REG_SYS_CFG + 0] = 0x25;
    sim_regs[S_REG_SYS_CFG + 1] = 0x50;   /* bit12 = версия (5<<12 = 0x5000) */
    /* HPON_FSM: bonding != 1T2R -> 8192EU (2T) */
    /* efuse-карта: rtl_id=0x8129 @0, tx power @0x10/0x3a, xtal @0xb9,
     * MAC @0xd7 */
    /* сырой поток efuse: 8-байтовые юниты карты; юнит >= 16 кодируется
     * расширенным заголовком (как в rtl8xxxu_read_efuse) */
    {
        int p = 0;
        u8 unit0[8]  = { 0x29, 0x81, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
        u8 unit26[8] = { 0, 0, 0, 0, 0, 0, 0, sim_mac[0] };
        u8 unit27[8] = { sim_mac[1], sim_mac[2], sim_mac[3],
                         sim_mac[4], sim_mac[5], 0xff, 0xff, 0xff };
        const u8 *units[3] = { unit0, unit26, unit27 };
        const int unitno[3] = { 0, 26, 27 };
        for (int u = 0; u < 3; u++) {
            sim_efuse[p++] = (u8)(0x0f | ((unitno[u] & 7) << 5));
            sim_efuse[p++] = (u8)(((unitno[u] & 0x18) << 1) | 0x00);
            memcpy(sim_efuse + p, units[u], 8);
            p += 8;
        }
    }
    /* EAPOL/данные от точки: eth dst = мы, src = AP (по умолчанию) */
    memcpy(g_rx_eth_dst, sim_mac, 6);
    memcpy(g_rx_eth_src, sim_bssid, 6);
}

/* --- efuse-чтение через REG_EFUSE_CTRL (бит 31 = готово, данные в байте 0) */
static void sim_efuse_trigger(u16 offset) {
    if (offset < 40) printf("    dbg: efuse_trigger off=%d data=%02x\n",
                            offset, sim_efuse[offset & 511]);
    /* хост little-endian: пишем данные в байты 0..3 регистра */
    /* ВАЖНО: байт0 = данные, бит31 (байт3) = готово; байты 1-2 (адрес)
     * НЕ трогаем — как на железе */
    sim_regs[S_REG_EFUSE_CTRL + 0] = sim_efuse[offset & 511];
    sim_regs[S_REG_EFUSE_CTRL + 3] |= 0x80;
}

/* vendor control (заглушка usb_ehci.c) */
int usb_ehci_ctrl_xfer(int addr, u8 bmReqType, u8 bReq,
                       u16 wValue, u16 wIndex, void *data, int len, int data_in) {
    (void)addr; (void)wIndex; (void)bReq;
    if (data_in) {
        /* чтение регистра: bmReqType 0xC5 */
        u16 a = wValue;
        if (a == S_REG_EFUSE_CTRL) {
            sim_efuse_trigger((u16)(sim_regs[S_REG_EFUSE_CTRL + 1] |
                                    ((sim_regs[S_REG_EFUSE_CTRL + 2] & 3) << 8)));
        }
        /* RF readback: LSSI_READBACK XA(0x8a0)/XB(0x8a4) — последнее
         * значение RF-регистра пути (упрощённая модель HSSI);
         * пишем в sim_regs — общий memcpy ниже отдаст значение */
        if (a == 0x08a0 || a == 0x08a4 || a == 0x08b8 || a == 0x08bc) {
            int rpath = (a == 0x08a0 || a == 0x08b8) ? 0 : 1;
            u32 v = sim_rf[rpath][sim_rf_last_reg[rpath] & 63];
            memcpy(sim_regs + a, &v, 4);
        }
        memset(data, 0, (size_t)len);
        memcpy(data, sim_regs + a, (size_t)len);
        /* спец-поведения регистров при чтении */
        if (a == S_REG_MCU_FW_DL) {
            u32 v;
            memcpy(&v, data, 4);
            if (sim_mcu_started) v |= 0x40;         /* MCU_WINT_INIT_READY */
            else if (sim_fw_written > 0) v |= 0x04; /* CSUM_REPORT после записи */
            memcpy(data, &v, 4);
        }
        if (a == S_REG_AUTO_LLT && sim_llt_done) {
            u32 v; memcpy(&v, data, 4); v &= ~0x10000u; memcpy(data, &v, 4);
        }
        if (a == S_REG_APS_FSMCO) {
            u32 v; memcpy(&v, data, 4);
            v |= 0x20000;                 /* PFM_READY (bit 17) всегда */
            if (v & 0x100) v &= ~0x100u;  /* MAC_ENABLE (bit 8) самосбрасывается */
            memcpy(data, &v, 4);
        }
        return len;
    }
    /* запись */
    u16 a = wValue;
    if (a == S_REG_MCU_FW_DL) {
        u32 v; memcpy(&v, data, 4);
        sim_fw_dl_active = (v & 1) != 0;    /* MCU_FW_DL_ENABLE */
    }
    if (a == S_REG_MCU_FW_DL + 2) {
        /* выбор страницы прошивки (0x82 = page idx, биты 0-2) */
        sim_fw_pages_mark = data ? ((u8 *)data)[0] & 7 : 0;
    }
    if (a >= S_FW_BASE && sim_fw_dl_active) {
        /* прошивка: vendor writeN блоками; страница выбирается 0x82 */
        u32 dst = (u32)sim_fw_pages_mark * 4096u + (a - S_FW_BASE);
        if (dst + (u32)len <= sizeof(sim_fw_ram))
            memcpy(sim_fw_ram + dst, data, (size_t)len);
        if ((int)(dst + (u32)len) > sim_fw_written)
            sim_fw_written = (int)(dst + (u32)len);
        return len;
    }
    if (len == 1) sim_regs[a] = ((u8 *)data)[0];
    else if (len == 2) {
        u16 v; memcpy(&v, data, 2);
        sim_regs[a] = (u8)(v & 0xff); sim_regs[a + 1] = (u8)(v >> 8);
    } else if (len == 4) {
        memcpy(sim_regs + a, data, 4);
    }
    /* спец-поведения при записи */
    if (a == S_REG_MCU_FW_DL) {
        u32 v; memcpy(&v, data, 4);
        /* MCU_FW_DL_READY (bit1) при снятом INIT_READY (bit6) — команда
         * «прошивка стартует» (сразу после неё эталон сбрасывает 8051) */
        if ((v & 0x02) && !(v & 0x40)) sim_mcu_started = 1;
        if (v == 0) { sim_mcu_started = 0; sim_fw_written = 0; }
    }
    if (a == S_REG_AUTO_LLT) {
        u32 v; memcpy(&v, data, 4);
        printf("    dbg: write AUTO_LLT %08x\n", (unsigned)v);
        if (v & 0x10000) sim_llt_done = 1;   /* AUTO_LLT_INIT_LLT = BIT(16) */
    }
    if (a == 0x001d) {   /* REG_RSV_CTRL+1 */
        sim_8051_reset_count++;              /* reset_8051 трогает 0x1D дважды */
    }
    if (a >= 0x800 && a <= 0x8ff && (a & 3) == 0 && getenv("RTL_TRACE"))
        printf("    dbg: W32 %04x <- %08x\n", a, *(unsigned *)data);
    /* RF-записи: LSSI PARM XA(0x840)/XB(0x844) = (reg<<20)|data */
    /* Security CAM: REG_CAM_WRITE (0x674) -> REG_CAM_CMD (0x670, WRITE) */
    if (a == 0x0674) {
        u32 v; memcpy(&v, data, 4);
        sim_cam_pending = v;
    }
    if (a == 0x0670) {
        u32 v; memcpy(&v, data, 4);
        if ((v & 0x80010000u) == 0x80010000u) {   /* POLLING|WRITE */
            int cell = (int)((v & 0x3FF8) >> 3) & 7;
            int word = (int)(v & 7);
            sim_cam[cell][word] = sim_cam_pending;
            sim_cam_writes++;
        }
    }
    if (a == 0x0840 || a == 0x0844) {
        u32 v; memcpy(&v, data, 4);
        int rpath = (a == 0x0840) ? 0 : 1;
        u8 rreg = (u8)((v >> 20) & 0x3f);
        u32 rdata = v & 0x000fffff;
        if (rreg < 64) sim_rf[rpath][rreg] = rdata;
        sim_rf_last_reg[rpath] = rreg;
    }
    return len;
}

/* bulk (заглушка usb_ehci.c) */
int usb_ehci_bulk_xfer(int addr, int ep, int ep_size, int data_in,
                       void *buf, int len) {
    (void)addr; (void)ep_size;
    if (data_in) {
        if (sim_rx_count == 0) return -1;      /* NAK/пусто */
        int n = sim_rx_len[sim_rx_head];
        if (n > len) n = len;
        memcpy(buf, sim_rxq[sim_rx_head], (size_t)n);
        sim_rx_head = (sim_rx_head + 1) % RXQ_MAX;
        sim_rx_count--;
        return n;
    }
    /* OUT: TX-кадр [desc40][frame] */
    if (sim_tx_n < TXCAP_MAX && len > 40) {
        memcpy(sim_tx[sim_tx_n].desc, buf, 40);
        sim_tx[sim_tx_n].len = len - 40;
        memcpy(sim_tx[sim_tx_n].frame, (u8 *)buf + 40, (size_t)(len - 40));
        sim_tx[sim_tx_n].ep = ep;
        sim_tx_n++;
    }
    return len;
}

/* Сессия 32: bulk с явным таймаутом — симулятору таймаут безразличен */
int usb_ehci_bulk_xfer_to(int addr, int ep, int ep_size, int data_in,
                          void *buf, int len, u32 timeout_us) {
    (void)timeout_us;
    return usb_ehci_bulk_xfer(addr, ep, ep_size, data_in, buf, len);
}

static void sim_inject_rx(const u8 *pkt, int len, u8 rxmcs) {
    if (sim_rx_count >= RXQ_MAX) return;
    u8 *dst = sim_rxq[(sim_rx_head + sim_rx_count) % RXQ_MAX];
    /* [rxdesc24][phystats 32][frame] */
    memset(dst, 0, 24 + 32);
    u32 w0 = (u32)len | (4u << 16) /* drvinfo_sz=4 */ ;
    /* rxmcs в слове 3, биты 0-6 */
    u32 w3 = rxmcs & 0x7f;
    memcpy(dst + 0, &w0, 4);
    memcpy(dst + 12, &w3, 4);
    /* PHY-статистика: CCK: cck_agc_rpt @+6 (lna 2 = -10, vga 18) */
    dst[24 + 6] = (u8)((2 << 5) | 18);
    dst[24 + 4] = 130;               /* pwdb_all (для OFDM) -> (130>>1)-110 = -45 */
    memcpy(dst + 24 + 32, pkt, (size_t)len);
    sim_rx_len[(sim_rx_head + sim_rx_count) % RXQ_MAX] = 24 + 32 + len;
    sim_rx_count++;
}

static u16 fc_of(int type, int subtype) {
    return (u16)((type << 2) | (subtype << 4));
}

/* beacon: SSID + DS Param (канал) + RSN IE (WPA2-PSK CCMP) */
static int make_beacon(u8 *f, const char *ssid, int channel, int wpa2) {
    memset(f, 0, 64);
    u16 fc = fc_of(0, 8);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memset(f + 4, 0xff, 6);                       /* DA */
    memcpy(f + 10, sim_bssid, 6);                 /* SA */
    memcpy(f + 16, sim_bssid, 6);                 /* BSSID */
    /* [24..35] timestamp, interval, cap */
    f[34] = 0x11; f[35] = 0x00;                   /* cap: ESS + privacy? нет */
    int p = 36;
    /* SSID */
    int sl = (int)strlen(ssid);
    f[p++] = 0; f[p++] = (u8)sl; memcpy(f + p, ssid, (size_t)sl); p += sl;
    /* DS Params */
    f[p++] = 3; f[p++] = 1; f[p++] = (u8)channel;
    if (wpa2) {
        /* RSN IE: ver1, group CCMP, pairwise CCMP x1, AKM PSK x1 */
        static const u8 rsn[] = {
            0x30, 18, 0x01, 0x00,
            0x00, 0x0F, 0xAC, 0x04,
            0x01, 0x00, 0x00, 0x0F, 0xAC, 0x04,
            0x01, 0x00, 0x00, 0x0F, 0xAC, 0x02,
        };
        memcpy(f + p, rsn, sizeof(rsn)); p += (int)sizeof(rsn);
    }
    return p;
}

/* mgmt-ответ (AUTH/ASSOC) от точки */
static int make_auth_resp(u8 *f, u16 status) {
    memset(f, 0, 40);
    u16 fc = fc_of(0, 11);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memcpy(f + 4, sim_mac, 6);                    /* DA = мы */
    memcpy(f + 10, cur_bssid, 6);
    memcpy(f + 16, cur_bssid, 6);
    f[24] = 0; f[25] = 0;                         /* algo = open */
    f[26] = 2; f[27] = 0;                         /* seq = 2 */
    f[28] = (u8)(status & 0xff); f[29] = (u8)(status >> 8);
    return 30;
}

static int make_assoc_resp(u8 *f, u16 aid) {
    memset(f, 0, 40);
    u16 fc = fc_of(0, 1);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memcpy(f + 4, sim_mac, 6);
    memcpy(f + 10, cur_bssid, 6);
    memcpy(f + 16, cur_bssid, 6);
    f[26] = 0; f[27] = 0;                         /* status = 0 */
    f[28] = (u8)(aid & 0xff); f[29] = (u8)((aid >> 8) & 0x3f);
    return 30;
}

/* данные от точки: FromDS + LLC/SNAP + payload; protected добавляет IV/MIC */
/* DA/SA ожидаемого eth (заполняет тест) */

static int make_data_from_ap(u8 *f, const u8 *eth_payload, u32 plen, int protected_) {
    memset(f, 0, 1600);
    f[0] = 0x08;                                  /* data */
    f[1] = 0x02;                                  /* FromDS */
    if (protected_) f[1] |= 0x40;
    memcpy(f + 4, g_rx_eth_dst, 6);               /* addr1 = DA */
    memcpy(f + 10, sim_bssid, 6);                 /* addr2 = BSSID */
    memcpy(f + 16, g_rx_eth_src, 6);              /* addr3 = SA */
    int p = 24;
    if (protected_) {
        memset(f + p, 0x77, 8); p += 8;           /* CCMP IV (симуляция) */
    }
    memcpy(f + p, "\xAA\xAA\x03\x00\x00\x00", 6); p += 6;
    memcpy(f + p, eth_payload, plen); p += (int)plen;
    if (protected_) {
        memset(f + p, 0x5A, 8); p += 8;           /* MIC (симуляция) */
    }
    return p;
}

/* last TX captures helpers */
static int last_tx_of_type(int type) {
    for (int i = sim_tx_n - 1; i >= 0; i--) {
        u16 fc = (u16)(sim_tx[i].frame[0] | (sim_tx[i].frame[1] << 8));
        if (((fc >> 2) & 3) == type) return i;
    }
    return -1;
}

/* ============ заглушки окружения ядра ============ */

/* snprintf/vsnprintf в сигнатуре ядра (u32) — локальный string.h
 * переименовывает объявления real-исходников в эти обёртки */
int test_vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap) {
    return vsnprintf(out, n, fmt, ap);
}
int test_snprintf(char *out, u32 n, const char *fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(out, n, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

static u32 fake_ticks;
u32 timer_ticks(void) { return fake_ticks; }
static void advance(int n) { fake_ticks += (u32)n; }

void klog_puts(const char *s) { (void)s; }
void serial_puts(const char *s) { fputs(s, stdout); }   /* лог драйвера виден */

/* ramfs: один файл WIFI.CFG */
static char ram_cfg[256];
static int ram_cfg_len;
int  ramfs_ready(void) { return 1; }
int  ramfs_delete(const char *name) { (void)name; ram_cfg_len = 0; return 1; }
int  ramfs_create(const char *name, u32 size) { (void)name; (void)size; return 1; }
int  ramfs_write(const char *name, const void *buf, u32 size) {
    (void)name;
    if (size > sizeof(ram_cfg)) return 0;
    memcpy(ram_cfg, buf, size); ram_cfg_len = (int)size;
    return 1;
}
u32  ramfs_read(const char *name, void *buf, u32 max) {
    (void)name;
    if (ram_cfg_len == 0) return 0;
    u32 n = (u32)ram_cfg_len; if (n > max) n = max;
    memcpy(buf, ram_cfg, n);
    return n;
}

/* ============ реальный код ============ */

/* Atheros на хосте не проверяем — wifi_init пойдёт в RTL */
int ath9k_wifi_probe(void) { return 0; }
int usb_ehci_present(void)  { return 1; }   /* EHCI «есть» */

#include "wpa2.c"
#include "rtl8192eu_fw.c"
#include "rtl8192eu.c"
/* wifi_core.c включаем отдельно (ниже) — он с rtl в одном TU, чтобы
 * видеть wifi_log и не дублировать wifi_* (в ядре их держат раздельные TU) */
#include "wifi_core.c"

/* ============ тесты ============ */

static void test_attach_and_probe(void) {
    printf("== attach + probe (прошивка, MAC, 8051) ==\n");
    sim_reset();

    /* конфигурация: interface class 0 (vendor), EP1 IN bulk 512,
     * EP2/EP3/EP4 OUT bulk 512 */
    static u8 cfg[64];
    memset(cfg, 0, sizeof(cfg));
    int p = 0;
    /* config descriptor (9 байт) */
    cfg[p++] = 9; cfg[p++] = 2; cfg[p++] = (u8)36; cfg[p++] = 0; /* wTotalLength */
    cfg[p++] = 1; cfg[p++] = 1; cfg[p++] = 0; cfg[p++] = 0x80;
    cfg[p++] = 50;
    /* endpoint IN EP1 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x81; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;
    /* endpoint OUT EP2 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x02; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;
    /* endpoint OUT EP3 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x03; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;
    /* endpoint OUT EP4 */
    cfg[p++] = 7; cfg[p++] = 5; cfg[p++] = 0x04; cfg[p++] = 2;
    cfg[p++] = 0x00; cfg[p++] = 0x02; cfg[p++] = 0;

    CHECK(usb_wifi_try_attach(12, 0x0bda, 0x818b, cfg, p) == 1,
          "usb_wifi_try_attach принял 0bda:818b");
    printf("    dbg: ep_in=%d nr_out=%d eps=%d %d %d count=%d\n",
           rtl.ep_in, rtl.nr_out_eps, rtl.out_ep[0], rtl.out_ep[1],
           rtl.out_ep[2], rtl.ep_tx_count);
    CHECK(usb_wifi_try_attach(13, 0x0bda, 0x8187, cfg, p) == 0,
          "чужой VID/PID отвергнут");
    CHECK(usb_wifi_try_attach(13, 0x0bda, 0x818c, cfg, p) == 1,
          "уже занято — повторный attach глушится");

    CHECK(rtl8192eu_probe() == 1, "rtl8192eu_probe принёс адаптер");
    CHECK(wifi_present() == 1 && wifi_ready() == 1, "wifi_present/ready");
    CHECK(strcmp(wifi_chip_name(), "RTL8192EU") == 0,
          "chip_name = RTL8192EU (2T2R bonding)");

    /* прямая диагностика efuse */
    {
        u8 b;
        int rc = rtl_read_efuse8(0, &b);
        printf("    dbg: rtl_read_efuse8(0) rc=%d val=%02x\n", rc, b);
        rc = rtl_read_efuse8(1, &b);
        printf("    dbg: rtl_read_efuse8(1) rc=%d val=%02x\n", rc, b);
        int r2 = rtl_read_efuse();
        printf("    dbg: rtl_read_efuse rc=%d map[0..3]=%02x %02x %02x %02x\n",
               r2, rtl.efuse_map[0], rtl.efuse_map[1], rtl.efuse_map[2],
               rtl.efuse_map[3]);
    }

    /* прошивка: байт-в-байт после 32-байтового заголовка */
    extern const u8 rtl8192eu_fw_data[];
    u32 fw_size = 32286u - 32u;
    printf("    dbg: fw_written=%d (ожидалось %d)\n", sim_fw_written, (int)fw_size);
    printf("    dbg: efuse_ok=%d map[0..7]=%02x %02x %02x %02x %02x %02x %02x %02x\n",
           rtl.efuse_ok, rtl.efuse_map[0], rtl.efuse_map[1], rtl.efuse_map[2],
           rtl.efuse_map[3], rtl.efuse_map[4], rtl.efuse_map[5],
           rtl.efuse_map[6], rtl.efuse_map[7]);
    printf("    dbg: map[D0..D7]=%02x %02x %02x %02x %02x %02x %02x %02x\n",
           rtl.efuse_map[0xd0], rtl.efuse_map[0xd1], rtl.efuse_map[0xd2],
           rtl.efuse_map[0xd3], rtl.efuse_map[0xd4], rtl.efuse_map[0xd5],
           rtl.efuse_map[0xd6], rtl.efuse_map[0xd7]);
    CHECK(sim_fw_written == (int)fw_size,
          "прошивка записана целиком (32254 б)");
    int bad = 0;
    for (u32 i = 0; i < fw_size; i++)
        if (sim_fw_ram[i] != rtl8192eu_fw_data[32 + i]) { bad++; break; }
    CHECK(bad == 0, "байты прошивки совпадают байт-в-байт");
    CHECK(sim_8051_reset_count >= 1, "8051 сбрасывался (старт прошивки)");
    CHECK(sim_mcu_started, "MCU стартовал (WINT_INIT_READY увиден)");

    /* MAC из efuse */
    u8 mac[6];
    wifi_net_get_mac(mac);
    CHECK(memcmp(mac, sim_mac, 6) == 0, "MAC из efuse (48:5b:39:22:33:44)");
}

static void test_scan_and_persist(void) {
    printf("== скан: каналы, beacon, список переживает повтор ==\n");
    /* скан стартует с канала 1 */
    fake_ticks += 100;
    wifi_scan_start();
    CHECK(wifi_scan_active(), "скан активен");

    /* RF 0x18 канал 1 записан? */
    printf("    dbg: sim_rf[0][0x18]=%06x sim_rf[1][0x18]=%06x\n",
           (unsigned)sim_rf[0][S_RF_MODE_AG], (unsigned)sim_rf[1][S_RF_MODE_AG]);
    CHECK((sim_rf[0][S_RF_MODE_AG] & 0xff) == 1, "RF channel = 1 (путь A)");

    /* прокручиваем до канала 6 */
    int cur = 1;
    while (cur < SIM_CHANNEL) {
        advance(120);          /* dwell 110 мс (сессия 33) + запас */
        wifi_poll();
        cur++;
    }
    CHECK((sim_rf[0][S_RF_MODE_AG] & 0xff) == SIM_CHANNEL,
          "скан дошёл до канала 6");

    /* beacon на канале 6 */
    u8 bcn[256];
    int bl = make_beacon(bcn, sim_ssid, SIM_CHANNEL, 1);
    if (getenv("RTL_TRACE")) {
        printf("    dbg: beacon[%d]:", bl);
        for (int i = 36; i < bl; i++) printf(" %02x", bcn[i]);
        printf("\n");
    }
    sim_inject_rx(bcn, bl, 0x00 /* CCK 1M */);
    advance(21);          /* гейт poll_rx — 20 мс (сессия 33) + запас */
    wifi_poll();

    wifi_ap_t aps[WIFI_MAX_APS];
    int n = wifi_scan_results(aps, WIFI_MAX_APS);
    CHECK(n >= 1, "сеть найдена");
    int found = -1;
    for (int i = 0; i < n; i++)
        if (strcmp(aps[i].ssid, sim_ssid) == 0) found = i;
    CHECK(found >= 0, "SSID \"HomeNet\" в списке");
    if (found >= 0) {
        CHECK(aps[found].channel == SIM_CHANNEL, "канал сети = 6");
        printf("    dbg: ap.sec=%d encrypted=%d cap=%04x\n",
               aps[found].sec, aps[found].encrypted, aps[found].capability);
        CHECK(aps[found].sec == WIFI_SEC_WPA2_PSK, "защита распознана (WPA2-PSK)");
    } else {
        return;   /* дальше без сети нет смысла */
    }

    /* завершаем скан до конца */
    while (cur < 14) {
        advance(120);
        wifi_poll();
        cur++;
    }
    advance(120);
    wifi_poll();
    CHECK(!wifi_scan_active(), "скан завершён");

    /* ПОВТОРНЫЙ скан: список НЕ очищается (регрессия сессии 28) */
    wifi_scan_start();
    CHECK(wifi_scan_active(), "повторный скан активен");
    n = wifi_scan_results(aps, WIFI_MAX_APS);
    CHECK(n >= 1, "список сетей сохранён между сканами");
    wifi_disconnect();
}

static void test_connect_wpa2(void) {
    printf("== подключение WPA2-PSK (AUTH/ASSOC/M1-M4/CAM) ==\n");

    /* PMK/PTK считаем сами (как AP): pmk = PBKDF2(pass, ssid) */
    u8 pmk[32], ptk[48];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);

    CHECK(wifi_connect_psk(sim_ssid, SIM_PASS) == 1, "wifi_connect_psk запущен");
    CHECK(wifi_conn_state() == WIFI_CONN_SCAN, "состояние = SCAN");

    /* скан завершится сам (адаптер уже на канале 6 — conn_step найдёт AP) */
    for (int i = 0; i < 40 && wifi_conn_state() == WIFI_CONN_SCAN; i++) {
        advance(120); wifi_poll();
    }
    CHECK(wifi_conn_state() == WIFI_CONN_AUTH, "AUTH отправлен (точка найдена)");

    int t = last_tx_of_type(0);
    CHECK(t >= 0, "mgmt TX захвачен");
    if (t < 0) return;   /* дальше без кадра нет смысла */
    u16 fc = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
    CHECK((fc & 0x00F0) == 0x00B0, "это AUTH REQ (subtype 11)");
    CHECK(memcmp(sim_tx[t].frame + 10, sim_mac, 6) == 0, "addr2 = наш MAC");
    CHECK(memcmp(sim_tx[t].frame + 16, sim_bssid, 6) == 0, "addr3 = BSSID");
    /* дескриптор: mgmt -> queue MGNT */
    u32 qsel = (sim_tx[t].desc[5] & 0x1f);   /* txdw1 биты 12:8 */
    CHECK(qsel == TXDESC_QUEUE_MGNT, "mgmt уходит в очередь MGNT");

    /* AUTH ok -> ASSOC REQ */
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_ASSOC, "AUTH принят, ASSOC REQ");
    t = last_tx_of_type(0);
    fc = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
    CHECK((fc & 0x00F0) == 0x0000, "это ASSOC REQ (subtype 0)");
    {
        /* в ASSOC REQ должен быть RSN IE (WPA2) */
        int p = 24 + 2 + 2;
        int rsn = 0;
        while (p + 2 <= sim_tx[t].len) {
            if (sim_tx[t].frame[p] == 48) { rsn = 1; break; }
            p += 2 + sim_tx[t].frame[p + 1];
        }
        CHECK(rsn, "ASSOC REQ содержит RSN IE");
    }

    /* ASSOC ok -> 4WAY, ждём M1 */
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC001), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "ASSOC ok, ждём 4-way");

    /* ---- M1 (от AP): ANonce, ACK, без MIC ---- */
    u8 anonce[32];
    memset(anonce, 0xA5, sizeof(anonce));
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key(m1, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK,
                                     anonce, (const u8 *)"\x01\x00\x00\x00\x00\x00\x00\x00",
                                     NULL, 0);
    /* FromDS data + LLC/SNAP + 888E */
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c /* 6M OFDM */);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "M1 принят, ждём M3");

    printf("    dbg: после M1 state=%d tx_captures=%d\n",
           (int)wifi_conn_state(), sim_tx_n);
    /* ---- M2 (наш): проверить SNonce + MIC по PTK ---- */
    t = last_tx_of_type(2);
    CHECK(t >= 0, "EAPOL M2 передан (data TX)");
    u16 dfc = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
    CHECK((dfc & 0x0008) == 0x0008, "EAPOL = data ToDS");
    CHECK((dfc & 0x4000) == 0, "EAPOL НЕ Protected");
    /* вытащить SNonce из M2 (key data нулевой; nonce поле = смещение
     * eth14 + eapol 4 + keyhdr: nonce @ 99 байт кадра EAPOL) */
    u8 snonce[32];
    {
        /* M2 eth: [14 hdr][eapol ...]: eapol key nonce @ +14+ (99-14) */
        /* в 802.11: 24 hdr + LLC 6 + ethertype 2 + body */
        const u8 *e = sim_tx[t].frame + 24 + 8;
        /* eapol key hdr: ver type len(2) key_info(2) keylen(2) replay(8)
         * nonce(32) => nonce @ e+ 14 (eth src/dst восстановлены) + 21 */
        memcpy(snonce, e + 17, 32);
    }
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce, snonce, ptk);
    /* MIC в M2: последние 16 байт EAPOL-кадра */
    {
        const u8 *e = sim_tx[t].frame + 24 + 8;
        int elen = sim_tx[t].len - 24 - 8;
        /* e = начало EAPOL (802.11 hdr 24 + LLC/SNAP+888E 8).
         * eth-кадр = [dst src 888E][e]; MIC покрывает eth+14.. (сам EAPOL) */
        u8 mic[16];
        static u8 tmp[1600];
        memcpy(tmp + 14, e, (size_t)elen);
        memset(tmp + 95, 0, 16);          /* MIC в eth+95 */
        wpa2_eapol_mic(ptk, tmp, (u32)(elen + 14), mic);
        printf("    dbg: t.kck=");
        for (int q = 0; q < 16; q++) printf("%02x", ptk[q]);
        printf("\n");
        CHECK(memcmp(mic, e + 81, 16) == 0, "MIC M2 сходится (KCK)");
    }

    /* ---- M3: GTK KDE зашифрован KEK, MIC, Secure, Install ---- */
    u8 gtk[16];
    memset(gtk, 0x71, sizeof(gtk));
    u8 kde[32];
    kde[0] = 0xDD; kde[1] = 22;
    memcpy(kde + 2, "\x00\x0F\xAC\x01", 4);
    kde[6] = 0x00;                                 /* keyid 0 */
    memcpy(kde + 7, gtk, 16);
    kde[23] = 0xDD; kde[24] = 0x00;                /* паддинг до 24? (16+7=23 -> +1) */
    u8 wrapped[40];
    wpa2_aes_wrap(ptk + 16, kde, 24, wrapped);     /* 24 байт + IV 8 = 32 */

    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key(m3, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK | WPA2_KI_MIC |
                                     WPA2_KI_SECURE | WPA2_KI_ENCR_DATA,
                                     anonce, (const u8 *)"\x01\x00\x00\x00\x00\x00\x00\x00",
                                     wrapped, 32);
    /* MIC по кадру с нулём в поле MIC */
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    /* строитель добавляет 2 нулевых байта хвоста — стандартная длина
     * EAPOL-Key кадра = 14+4+95+kd (по ней считает и точка) */
    wpa2_eapol_mic(ptk, m3, (u32)(m3len - 2), mic3);
    memcpy(m3 + 14 + 81, mic3, 16);

    if (getenv("WIFI_PARSE_DBG")) {
        /* контрольная проверка: тот же расчёт, что у драйвера
         * (eb-подобный буфер: [12 нулей][888E][m3+12..], MIC=0) */
        u8 ctrl[1600];
        memset(ctrl, 0, sizeof(ctrl));
        memcpy(ctrl + 12, m3 + 12, (size_t)(m3len - 12));
        memset(ctrl + 95, 0, 16);
        u8 cmic[16];
        wpa2_eapol_mic(ptk, ctrl, (u32)(m3len - 2), cmic);
        printf("    dbg: ctrl-mic=%02x%02x%02x%02x (должен = mic3)\n",
               cmic[0], cmic[1], cmic[2], cmic[3]);
        printf("    dbg: m3[14..29]:");
        for (int q = 14; q < 30; q++) printf(" %02x", m3[q]);
        printf("\n    dbg: m3-full:");
        for (int q = 0; q < m3len; q++) printf("%02x", m3[q]);
        printf("\n    dbg: m3 mic3=%02x%02x%02x%02x\n",
               mic3[0], mic3[1], mic3[2], mic3[3]);
    }
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "M3 принят -> CONNECTED");
    CHECK(wifi_conn_secured() == 1, "ключи установлены (wifi_conn_secured)");

    /* CAM: PTK idx0 с TA=BSSID, GTK keyid0 CCMP */
    int cam_ok = 0;
    for (int i = 0; i < 8; i++) {
        if (sim_cam[i][0] == 0 && sim_cam[i][1] == 0) continue;
        cam_ok = 1;
    }
    CHECK(sim_cam_writes >= 12, "CAM-записи выполнены (PTK+GTK)");
    CHECK(cam_ok, "CAM ячейки не пусты");
    /* PTK TK (ptk+32) должен оказаться в CAM (слова 2..5 ячейки idx0) */
    {
        u32 expect = (u32)ptk[32] | ((u32)ptk[33] << 8) |
                     ((u32)ptk[34] << 16) | ((u32)ptk[35] << 24);
        printf("    dbg: cam[0][0..5]=%08x %08x %08x %08x %08x %08x expect=%08x\n",
               (unsigned)sim_cam[0][0], (unsigned)sim_cam[0][1],
               (unsigned)sim_cam[0][2], (unsigned)sim_cam[0][3],
               (unsigned)sim_cam[0][4], (unsigned)sim_cam[0][5],
               (unsigned)expect);
        CHECK(sim_cam[4][2] == expect, "CAM[4] содержит PTK TK (CCMP)");
    }
    /* M4 передан */
    int t4 = last_tx_of_type(2);
    CHECK(t4 > t, "M4 передан");

    /* ---- данные: TX из стека ---- */
    u8 eth[64];
    memset(eth, 0, sizeof(eth));
    eth[0] = 0x11; eth[1] = 0x22; eth[2] = 0x33; eth[3] = 0x44; eth[4] = 0x55; eth[5] = 0x66;
    eth[6] = sim_mac[0]; eth[7] = sim_mac[1]; eth[8] = sim_mac[2];
    eth[9] = sim_mac[3]; eth[10] = sim_mac[4]; eth[11] = sim_mac[5];
    eth[12] = 0x08; eth[13] = 0x00;
    for (int i = 14; i < 64; i++) eth[i] = (u8)i;
    int r = wifi_net_send(eth, 64);
    CHECK(r == 64, "wifi_net_send вернул длину");
    int td = last_tx_of_type(2);
    CHECK(td >= 0, "data TX захвачен");
    dfc = (u16)(sim_tx[td].frame[0] | (sim_tx[td].frame[1] << 8));
    CHECK((dfc & 0x4000) != 0, "data кадр Protected (шифруется железом)");
    CHECK(memcmp(sim_tx[td].frame + 4, sim_bssid, 6) == 0, "addr1 = BSSID");
    CHECK(memcmp(sim_tx[td].frame + 16, eth, 6) == 0, "addr3 = DA");
    /* LLC/SNAP + ethertype 0800 */
    CHECK(memcmp(sim_tx[td].frame + 24, "\xAA\xAA\x03\x00\x00\x00\x08\x00", 8) == 0,
          "LLC/SNAP + IPv4 ethertype");
    /* чексумма дескриптора: XOR 16 слов = 0 */
    {
        u16 *w = (u16 *)sim_tx[td].desc;
        u16 x = 0;
        for (int i = 0; i < 16; i++) x ^= w[i];
        CHECK(x == 0, "TX-дескриптор: чексумма (XOR слов) = 0");
    }
    u32 dq = (sim_tx[td].desc[5] & 0x1f);    /* txdw1 биты 12:8 */
    CHECK(dq == TXDESC_QUEUE_BE, "data уходит в очередь BE");

    /* ---- RX данных из сети ---- */
    memcpy(g_rx_eth_dst, eth, 6);        /* DA */
    memcpy(g_rx_eth_src, eth + 6, 6);    /* SA */
    u8 dfr[1600];
    int dl = make_data_from_ap(dfr, eth + 12, 64 - 12, 1);
    sim_inject_rx(dfr, dl, 0x0c);
    advance(21); wifi_poll();
    u8 rxbuf[1600];
    u32 rn = wifi_net_recv(rxbuf, sizeof(rxbuf));
    CHECK(rn == 64, "wifi_net_recv вернул Ethernet-кадр");
    CHECK(rn >= 14 && memcmp(rxbuf, eth, 14) == 0, "Ethernet-заголовок верный");
}

static void test_profile(void) {
    printf("== профиль WIFI.CFG ==\n");
    /* psk установлен (мы подключены) — сохранение с паролем */
    wifi_profile_save(sim_ssid);
    char ssid[33], psk[65];
    CHECK(wifi_profile_load(ssid, sizeof(ssid)) == 1, "SSID читается из профиля");
    CHECK(strcmp(ssid, sim_ssid) == 0, "SSID совпадает");
    CHECK(wifi_profile_load_psk(psk, sizeof(psk)) == 1, "psk читается из профиля");
    CHECK(strcmp(psk, SIM_PASS) == 0, "psk совпадает");
}

static void test_ap_reject_password(void) {
    printf("== неверный пароль: M3 с плохим MIC -> FAILED ==\n");
    wifi_disconnect();
    CHECK(wifi_connect_psk(sim_ssid, "wrongpassword") == 1, "второе подключение");
    for (int i = 0; i < 40 && wifi_conn_state() != WIFI_CONN_AUTH; i++) {
        advance(120); wifi_poll();
    }
    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    sim_inject_rx(fr, make_assoc_resp(fr, 0xC002), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_4WAY, "снова ждём 4-way");

    /* M1 заново (с другим ANonce) */
    u8 anonce2[32];
    memset(anonce2, 0x5A, sizeof(anonce2));
    u8 m1[256];
    u32 m1len = wpa2_build_eapol_key(m1, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK,
                                     anonce2, (const u8 *)"\x02\x00\x00\x00\x00\x00\x00\x00",
                                     NULL, 0);
    u8 d1[1600];
    sim_inject_rx(d1, make_data_from_ap(d1, m1 + 12, m1len - 12, 0), 0x0c);
    advance(21); wifi_poll();

    /* наш M2 -> snonce */
    int t = last_tx_of_type(2);
    CHECK(t >= 0, "M2 отправлен");
    if (t < 0) return;
    u8 pmk[32], ptk[48], snonce[32];
    wpa2_pbkdf2_sha1((const u8 *)"wrongpassword", 13,
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk, 32);
    {
        const u8 *e = sim_tx[t].frame + 24 + 8;
        memcpy(snonce, e + 17, 32);
    }
    wpa2_derive_ptk(pmk, sim_bssid, sim_mac, anonce2, snonce, ptk);

    /* M3 с МИК от ДРУГОГО ключа (AP думает, что пароль другой) */
    u8 gtk[16]; memset(gtk, 0x71, sizeof(gtk));
    u8 kde[32];
    kde[0] = 0xDD; kde[1] = 22;
    memcpy(kde + 2, "\x00\x0F\xAC\x01", 4);
    kde[6] = 0x00;
    memcpy(kde + 7, gtk, 16);
    kde[23] = 0xDD; kde[24] = 0x00;
    u8 wrapped[40];
    wpa2_aes_wrap(ptk + 16, kde, 24, wrapped);
    u8 m3[256];
    u32 m3len = wpa2_build_eapol_key(m3, sim_mac, sim_bssid,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_ACK | WPA2_KI_MIC |
                                     WPA2_KI_SECURE | WPA2_KI_ENCR_DATA,
                                     anonce2, (const u8 *)"\x02\x00\x00\x00\x00\x00\x00\x00",
                                     wrapped, 32);
    /* MIC по кадру с ДРУГИМ PMK (наш драйвер посчитает по "wrongpassword",
     * AP — по "password123" -> MIC не сойдётся) */
    u8 pmk_ap[32], ptk_ap[48];
    wpa2_pbkdf2_sha1((const u8 *)SIM_PASS, (u32)strlen(SIM_PASS),
                     (const u8 *)sim_ssid, (u32)strlen(sim_ssid),
                     4096, pmk_ap, 32);
    wpa2_derive_ptk(pmk_ap, sim_bssid, sim_mac, anonce2, snonce, ptk_ap);
    memset(m3 + 14 + 81, 0, 16);
    u8 mic3[16];
    wpa2_eapol_mic(ptk_ap, m3, (u32)(m3len - 2), mic3);
    memcpy(m3 + 14 + 81, mic3, 16);
    u8 d3[1600];
    sim_inject_rx(d3, make_data_from_ap(d3, m3 + 12, m3len - 12, 0), 0x0c);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_FAILED, "плохой MIC -> WIFI_CONN_FAILED");
}

/* ---- СЕССИЯ 32: маяк с настраиваемыми рейты/capability ---- */
static int make_beacon_rates(u8 *f, const char *ssid, int channel,
                             const u8 *r1, int r1len,
                             const u8 *r2, int r2len, u16 cap) {
    memset(f, 0, 128);
    u16 fc = fc_of(0, 8);
    f[0] = (u8)(fc & 0xff); f[1] = (u8)(fc >> 8);
    memset(f + 4, 0xff, 6);                       /* DA */
    memcpy(f + 10, cur_bssid, 6);
    memcpy(f + 16, cur_bssid, 6);
    f[34] = (u8)(cap & 0xff); f[35] = (u8)(cap >> 8);
    int p = 36;
    int sl = (int)strlen(ssid);
    f[p++] = 0; f[p++] = (u8)sl; memcpy(f + p, ssid, (size_t)sl); p += sl;
    f[p++] = 3; f[p++] = 1; f[p++] = (u8)channel; /* DS Params */
    if (r1len > 0) {
        f[p++] = 1; f[p++] = (u8)r1len;
        memcpy(f + p, r1, (size_t)r1len); p += r1len;
    }
    if (r2len > 0) {
        f[p++] = 50; f[p++] = (u8)r2len;
        memcpy(f + p, r2, (size_t)r2len); p += r2len;
    }
    return p;
}

static void test_assoc_rates_and_deauth_cap(void) {
    printf("== СЕССИЯ 32: рейты точки в ASSOC REQ + остановка DEAUTH-шторма ==\n");
    wifi_disconnect();
    {   /* ДРУГАЯ точка (другой BSSID): иначе parse_beacon обновит
         * запись HomeNet и OpenGNet в списке не появится */
        static const u8 nb[6] = { 0xc0, 0x25, 0xe9, 0x11, 0xaa, 0x55 };
        memcpy(cur_bssid, nb, 6);
    }

    /* g-only точка: basic 6/12/24 + ext 9..54, short preamble —
     * против СТАРОГО кода (хардкод basic 1/2/5.5/11) такая точка
     * отвечала ASSOC status=18; теперь рейты идут из маяка 1:1 */
    static const u8 r1[] = { 0x8C, 0x98, 0xB0 };            /* 6B 12B 24B */
    static const u8 r2[] = { 0x12, 0x24, 0x30, 0x48, 0x60, 0x6C };
    u8 bcn[128];
    int bl = make_beacon_rates(bcn, "OpenGNet", SIM_CHANNEL,
                               r1, (int)sizeof(r1), r2, (int)sizeof(r2),
                               0x0021 /* ESS + short preamble */);
    (void)bl;
    wifi_scan_start();
    CHECK(wifi_scan_active(), "скан активен");
    int cur = 1;
    while (cur < SIM_CHANNEL) { advance(120); wifi_poll(); cur++; }
    sim_inject_rx(bcn, bl, 0x00);
    advance(21); wifi_poll();
    while (cur <= 14) { advance(120); wifi_poll(); cur++; }
    CHECK(!wifi_scan_active(), "скан завершён");

    CHECK(wifi_connect_psk("OpenGNet", NULL) == 1, "подключение к открытой g-only сети");
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_AUTH,
          "AUTH сразу (кэш свежего скана — без полного рескана)");

    u8 fr[64];
    sim_inject_rx(fr, make_auth_resp(fr, 0), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_ASSOC, "AUTH ok, посылаем ASSOC REQ");

    int t = last_tx_of_type(0);
    CHECK(t >= 0, "ASSOC REQ захвачен");
    if (t >= 0) {
        u16 fcv = (u16)(sim_tx[t].frame[0] | (sim_tx[t].frame[1] << 8));
        CHECK(fcv == 0x0000, "FC = assoc request");
        u16 cap = (u16)(sim_tx[t].frame[24] | (sim_tx[t].frame[25] << 8));
        CHECK((cap & 0x0020) != 0, "Short Preamble зеркален из capability маяка");
        int p = 28;                           /* 24 hdr + 2 cap + 2 listen */
        int seen_ssid = 0;
        u8 got[24]; int got_n = 0;
        while (p + 2 <= sim_tx[t].len) {
            u8 tag = sim_tx[t].frame[p];
            u8 tl = sim_tx[t].frame[p + 1];
            if (tag == 0) seen_ssid = 1;
            else if ((tag == 1 || tag == 50) && got_n + tl <= (int)sizeof(got)) {
                memcpy(got + got_n, sim_tx[t].frame + p + 2, tl);
                got_n += tl;
            }
            p += 2 + tl;
        }
        /* набор точки конкатенатом: split 8+1 как у wpa_supplicant */
        static const u8 want[] = { 0x8C, 0x98, 0xB0, 0x12, 0x24, 0x30,
                                   0x48, 0x60, 0x6C };
        CHECK(seen_ssid, "SSID IE на месте");
        CHECK(got_n == (int)sizeof(want) && memcmp(got, want, sizeof(want)) == 0,
              "рейты ASSOC REQ = набору точки (basic 6/12/24 + ext 9..54)");
    }

    sim_inject_rx(fr, make_assoc_resp(fr, 0xC003), 0x00);
    advance(21); wifi_poll();
    CHECK(wifi_conn_state() == WIFI_CONN_CONNECTED, "открытая g-only сеть: CONNECTED");

    /* ---- DEAUTH-шторм: точка отшивает reason=2. Раньше: скан→AUTH→
     * DEAUTH бесконечно (шторм из лога пользователя). Теперь после
     * 2 быстрых переподключений и 4 DEAUTH — FAILED. ---- */
    u8 de[32];
    u16 dfc = fc_of(0, 12);
    de[0] = (u8)(dfc & 0xff); de[1] = (u8)(dfc >> 8);
    memcpy(de + 4, sim_mac, 6);
    memcpy(de + 10, cur_bssid, 6);
    memcpy(de + 16, cur_bssid, 6);
    de[24] = 2; de[25] = 0;                    /* reason 2 */
    int deauths = 0, guard = 0;
    while (wifi_conn_state() != WIFI_CONN_FAILED && guard++ < 60) {
        if (wifi_conn_state() != WIFI_CONN_SCAN) {
            sim_inject_rx(de, 26, 0x00);
            deauths++;
        }
        advance(21); wifi_poll();
        int k = 0;
        while (wifi_scan_active() && k++ < 20) { advance(120); wifi_poll(); }
    }
    printf("    dbg: DEAUTH подано %d, итог state=%d scanning=%d\n",
           deauths, (int)wifi_conn_state(), wifi_scan_active());
    CHECK(deauths >= 5, "шторм реально подавался (>=5 DEAUTH)");
    CHECK(wifi_conn_state() == WIFI_CONN_FAILED,
          "после CONN_MAX_DEAUTH — FAILED (петля остановлена)");
    CHECK(!wifi_scan_active(), "рескан-петля не осталась жить");
    wifi_disconnect();
}

int main(void) {
    memcpy(cur_bssid, sim_bssid, 6);   /* по умолчанию — та же точка */
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("=== rtlwifi: RTL8192EU + wifi_core (хост-тест) ===\n");

    test_attach_and_probe();
    test_scan_and_persist();
    test_connect_wpa2();
    test_profile();
    test_ap_reject_password();
    test_assoc_rates_and_deauth_cap();

    printf("\n=== итог: проверок %d, провалов %d ===\n", checks, fails);
    return fails ? 1 : 0;
}
