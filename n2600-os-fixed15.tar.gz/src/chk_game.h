/* chk_game.h — «Шашки» РУССКИЕ (8x8): ЧИСТАЯ логика (header-only,
 * без fb/wm/libc).
 *
 * Порт консольной игры пользователя (драфты с ИИ minimax + alpha-beta:
 * CLASSIC/GIVEAWAY, уровни Новичок/Игрок/Мастер, обязательное взятие,
 * цепочки взятий с продолжением, превращение в дамку). Консольная
 * обвязка (stdin/printf/файлы) заменена вызовами из GUI
 * (src/apps_checkers.c).
 *
 * Сессия 25 — правила приведены к РУССКИМ ШАШКАМ (запрос пользователя:
 * «сейчас нельзя бить назад, в русских можно»):
 *   1. простые бьют во ВСЕ 4 направления (раньше — только вперёд);
 *   2. дамка ЛЕТАЮЩАЯ: обычный ход на любое расстояние по диагонали,
 *      взятие через шашку на любом расстоянии с посадкой на ЛЮБУЮ
 *      пустую клетку за ней (раньше дамка ходила/била на 1 клетку);
 *   3. «турецкий удар»: битые шашки НЕ снимаются до конца хода —
 *      блокируют диагональ, вторично бить их нельзя;
 *   4. превращение В ХОДЕ боя: простая, достигшая последней
 *      горизонтали прыжком, продолжает бой уже как дамка.
 *
 * Осознанные отличия от консольного оригинала (сохранены с сессии 22):
 *  - ГСЧ — xorshift32 от seed (в ядре нет srand/time; как в msweeper.h);
 *  - генерация ходов работает над ЛЮБОЙ доской (chk_gen_*_on), а не
 *    над глобальным состоянием — ИИ не «подменяет» игру;
 *  - история для отмены — СНИМКИ начала хода;
 *  - правило ничьей: 60 тихих полуходов подряд.
 *
 * Хост-тест: work/test/chk_test.c (логика без GUI, ASan-чисто).
 */
#ifndef CHK_GAME_H
#define CHK_GAME_H

#include "types.h"

#define CHK_BOARD     8
#define CHK_MAX_MOVES 160    /* летающая дамка даёт больше ходов: до 14 на
                              * одну дамку (центр); с запасом на позиции
                              * «много дамок» (было 50) */
#define CHK_MAX_CAP   12     /* максимум битых в одной цепочке = все шашки
                              * противника на 8x8 (было 10) */
#define CHK_HIST_MAX  256    /* глубина отмены (снимков начала хода) */
#define CHK_QUIET_DRAW 60    /* тихих полуходов подряд -> ничья */

/* содержимое клетки */
#define CHK_EMPTY 0
#define CHK_WMAN  1
#define CHK_WKING 2
#define CHK_BMAN  3
#define CHK_BKING 4

#define CHK_WHITE 0
#define CHK_BLACK 1

#define CHK_MODE_CLASSIC  0  /* CLASSIC_MODE оригинала */
#define CHK_MODE_GIVEAWAY 1  /* GIVEAWAY_MODE («поддавки»: кто не может
                              * ходить — тот выиграл) */

#define CHK_STATE_PLAY 0
#define CHK_STATE_OVER 1

#define CHK_WIN_NONE  255
#define CHK_WIN_WHITE 0
#define CHK_WIN_BLACK 1
#define CHK_WIN_DRAW  2

typedef struct {
    unsigned char from_r, from_c, to_r, to_c;
    unsigned char cap_r[CHK_MAX_CAP], cap_c[CHK_MAX_CAP];
    unsigned char ncap;
    unsigned char promoted;   /* сессия 25: простая стала дамкой В ХОДЕ
                               * боя (до конечной посадки) — иначе
                               * chk_apply не видит промежуточного
                               * превращения */
} chk_move_t;

typedef struct {
    unsigned char board[CHK_BOARD][CHK_BOARD];
    unsigned char player;      /* чей ход */
    unsigned char must_cont;   /* 1 = обязаны продолжать взятие этой шашкой */
    unsigned char cont_r, cont_c;
    unsigned char rule_mode;   /* CHK_MODE_* */
    unsigned char vs_ai;       /* 1 = за ЧЁРНЫХ играет компьютер (человек — белые) */
    unsigned char ai_level;    /* 0 Новичок / 1 Игрок / 2 Мастер */
    unsigned char state;       /* CHK_STATE_* */
    unsigned char winner;      /* CHK_WIN_* */
    unsigned int  rng;         /* xorshift32 (seed != 0) */
    chk_move_t legal[CHK_MAX_MOVES];
    int nlegal;
    int has_cap;
    int quiet;                 /* тихих полуходов подряд (ничья) */
    /* последний полуход (подсветка в GUI) */
    unsigned char last_fr, last_fc, last_tr, last_tc;
    int last_valid;
    /* undo-снимки НАЧАЛА хода: 16 u32 = доска, +3 служебных */
    unsigned int snap[CHK_HIST_MAX][19];
    int nsnap;
} chk_game_t;

/* ------------------------------ ГСЧ ------------------------------ */

static inline unsigned int chk_rand(chk_game_t *g)
{
    unsigned int x = g->rng;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    g->rng = x ? x : 0x9E3779B9u;
    return g->rng;
}

/* --------------------------- служебное --------------------------- */

static inline int chk_in_board(int r, int c)
{
    return r >= 0 && r < CHK_BOARD && c >= 0 && c < CHK_BOARD;
}

static inline int chk_piece_side(int p)
{
    return (p == CHK_WMAN || p == CHK_WKING) ? CHK_WHITE : CHK_BLACK;
}

static inline int chk_is_king(int p)
{
    return p == CHK_WKING || p == CHK_BKING;
}

static inline int chk_count_side(const chk_game_t *g, int side)
{
    int n = 0;
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int p = g->board[r][c];
            if (p != CHK_EMPTY && chk_piece_side(p) == side) n++;
        }
    return n;
}

/* --------------------- генерация ходов (РУССКИЕ ПРАВИЛА) ---------------------
 * Работает над ПРОИЗВОЛЬНОЙ доской b[8][8] — её использует и игра,
 * и ИИ (chk_lite_*), без подмены глобального состояния.
 *
 * Русские правила (сессия 25):
 *   - простая бьёт во все 4 направления через соседнюю шашку
 *     противника на клетку сразу за ней;
 *   - дамка «летает»: ходит на любое расстояние по диагонали;
 *     бьёт шашку на любом расстоянии, садясь на ЛЮБУЮ пустую клетку
 *     за ней (каждая посадка — отдельная ветка цепочки);
 *   - битые шашки остаются на доске до конца хода («турецкий удар»):
 *     блокируют диагонали, вторично бить их нельзя — отслеживаются
 *     списком cap_* текущей цепочки;
 *   - простая, прыгнувшая на последнюю горизонталь, продолжает бой
 *     уже как дамка (превращение в середине хода). */

static const signed char chk_dirs[4][2] = { {-1,-1}, {-1,1}, {1,-1}, {1,1} };

/* Шашка (r,c) уже бита в текущей цепочке? */
static inline int chk_is_capped(const chk_move_t *cur, int r, int c)
{
    for (int i = 0; i < cur->ncap; i++)
        if (cur->cap_r[i] == (unsigned char)r &&
            cur->cap_c[i] == (unsigned char)c) return 1;
    return 0;
}

/* Все МАКСИМАЛЬНО глубокие продолжения боя шашки (r,c). Путь-цепочка
 * передаётся параметром (cur): это исправляет ЛАТЕНТНЫЙ БАГ ОРИГИНАЛА
 * (склейка чужих веток при ветвлении) — сохранён с сессии 22. */
static void chk_gen_captures_rec(unsigned char b[CHK_BOARD][CHK_BOARD],
                                 int r, int c, const chk_move_t *cur,
                                 chk_move_t *moves, int *count)
{
    int piece = b[r][c];
    int side = chk_piece_side(piece);
    int is_king = chk_is_king(piece);

    int any = 0;
    for (int d = 0; d < 4; d++) {
        int dr = chk_dirs[d][0], dc = chk_dirs[d][1];

        if (!is_king) {
            /* --- простая: бой в любом направлении (русские правила) --- */
            int jr = r + dr, jc = c + dc;
            int lr = r + 2 * dr, lc = c + 2 * dc;
            if (!chk_in_board(lr, lc)) continue;
            int jp = b[jr][jc];
            if (jp == CHK_EMPTY || chk_piece_side(jp) == side) continue;
            if (chk_is_capped(cur, jr, jc)) continue;   /* битая — нельзя */
            if (b[lr][lc] != CHK_EMPTY) continue;       /* посадка занята
                                                         * (в т.ч. битой) */

            chk_move_t next = *cur;
            next.to_r = (unsigned char)lr; next.to_c = (unsigned char)lc;
            next.cap_r[next.ncap] = (unsigned char)jr;
            next.cap_c[next.ncap] = (unsigned char)jc;
            next.ncap++;

            unsigned char ol = b[lr][lc], os = b[r][c];
            /* превращение В ХОДЕ боя: на последней горизонтали бьём
             * дальше уже по правилам дамки */
            int npiece = piece;
            if (piece == CHK_WMAN && lr == 0)              npiece = CHK_WKING;
            else if (piece == CHK_BMAN && lr == CHK_BOARD - 1) npiece = CHK_BKING;
            if (npiece != piece) next.promoted = 1;
            b[lr][lc] = (unsigned char)npiece;
            b[r][c] = CHK_EMPTY;
            /* битую НЕ снимаем: до конца хода она блокирует диагональ */

            chk_gen_captures_rec(b, lr, lc, &next, moves, count);

            b[lr][lc] = ol; b[r][c] = os;
            any = 1;
        } else {
            /* --- дамка: сканируем диагональ до первой шашки --- */
            int jr = r + dr, jc = c + dc;
            while (chk_in_board(jr, jc) && b[jr][jc] == CHK_EMPTY) {
                jr += dr; jc += dc;
            }
            if (!chk_in_board(jr, jc)) continue;
            int jp = b[jr][jc];
            if (chk_piece_side(jp) == side) continue;   /* своя — блок */
            if (chk_is_capped(cur, jr, jc)) continue;   /* битая — блок */

            /* посадочные клетки: все пустые за шашкой противника */
            int lr = jr + dr, lc = jc + dc;
            while (chk_in_board(lr, lc) && b[lr][lc] == CHK_EMPTY) {
                if (*count < CHK_MAX_MOVES) {
                    chk_move_t next = *cur;
                    next.to_r = (unsigned char)lr; next.to_c = (unsigned char)lc;
                    next.cap_r[next.ncap] = (unsigned char)jr;
                    next.cap_c[next.ncap] = (unsigned char)jc;
                    next.ncap++;

                    unsigned char ol = b[lr][lc], os = b[r][c];
                    b[lr][lc] = (unsigned char)piece;
                    b[r][c] = CHK_EMPTY;

                    chk_gen_captures_rec(b, lr, lc, &next, moves, count);

                    b[lr][lc] = ol; b[r][c] = os;
                    any = 1;
                }
                lr += dr; lc += dc;
            }
            /* за первой шашкой (битой/своей) дальше по диагонали не ищем */
        }
    }

    if (!any && cur->ncap > 0 && *count < CHK_MAX_MOVES)
        moves[(*count)++] = *cur;          /* цепочка завершена (корень с
                                            * ncap==0 не добавляется — это
                                            * просто «взятий нет») */
}

static void chk_gen_captures_on(unsigned char b[CHK_BOARD][CHK_BOARD],
                                int r, int c, chk_move_t *moves, int *count)
{
    if (*count >= CHK_MAX_MOVES) return;
    if (b[r][c] == CHK_EMPTY) return;
    chk_move_t root;
    root.from_r = (unsigned char)r; root.from_c = (unsigned char)c;
    root.to_r = (unsigned char)r;   root.to_c = (unsigned char)c;
    root.ncap = 0;
    root.promoted = 0;
    chk_gen_captures_rec(b, r, c, &root, moves, count);
}

static void chk_gen_regular_on(unsigned char b[CHK_BOARD][CHK_BOARD],
                               int r, int c, chk_move_t *moves, int *count)
{
    if (*count >= CHK_MAX_MOVES) return;
    int piece = b[r][c];
    if (piece == CHK_EMPTY) return;

    int side = chk_piece_side(piece);
    int is_king = chk_is_king(piece);
    int start_dir = 0, end_dir = 4;
    if (!is_king) {
        if (side == CHK_WHITE) end_dir = 2;   /* простые белые — только вперёд */
        else                   start_dir = 2; /* простые чёрные — только вперёд */
    }

    for (int d = start_dir; d < end_dir; d++) {
        /* сессия 25: дамка ходит на ЛЮБОЕ расстояние по диагонали,
         * простая — ровно на 1 клетку вперёд */
        int steps = is_king ? 8 : 1;
        int nr = r + chk_dirs[d][0], nc = c + chk_dirs[d][1];
        while (steps-- > 0 && chk_in_board(nr, nc) && b[nr][nc] == CHK_EMPTY) {
            if (*count >= CHK_MAX_MOVES) return;
            chk_move_t m;
            m.from_r = (unsigned char)r; m.from_c = (unsigned char)c;
            m.to_r = (unsigned char)nr;  m.to_c = (unsigned char)nc;
            m.ncap = 0;
            m.promoted = 0;               /* обычный ход — без превращения */
            moves[(*count)++] = m;
            nr += chk_dirs[d][0]; nc += chk_dirs[d][1];
        }
    }
}

/* Пересчитать legal[] для текущего игрока (порт generate_legal_moves):
 * сначала ВСЕ взятия всех шашек, если взятий нет — обычные ходы. */
static void chk_gen_legal(chk_game_t *g)
{
    g->nlegal = 0;
    g->has_cap = 0;

    if (g->must_cont) {
        chk_gen_captures_on(g->board, g->cont_r, g->cont_c,
                            g->legal, &g->nlegal);
        g->has_cap = (g->nlegal > 0);
        return;
    }

    chk_move_t all[CHK_MAX_MOVES];
    int cnt = 0;
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int p = g->board[r][c];
            if (p == CHK_EMPTY || chk_piece_side(p) != g->player) continue;
            chk_gen_captures_on(g->board, r, c, all, &cnt);
        }

    if (cnt > 0) {
        g->has_cap = 1;
        for (int i = 0; i < cnt && i < CHK_MAX_MOVES; i++)
            g->legal[i] = all[i];
        g->nlegal = cnt;
        return;
    }

    cnt = 0;
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int p = g->board[r][c];
            if (p == CHK_EMPTY || chk_piece_side(p) != g->player) continue;
            chk_gen_regular_on(g->board, r, c, all, &cnt);
        }
    for (int i = 0; i < cnt && i < CHK_MAX_MOVES; i++)
        g->legal[i] = all[i];
    g->nlegal = cnt;
}

static int chk_find_move(const chk_game_t *g, int fr, int fc, int tr, int tc)
{
    for (int i = 0; i < g->nlegal; i++)
        if (g->legal[i].from_r == fr && g->legal[i].from_c == fc &&
            g->legal[i].to_r == tr && g->legal[i].to_c == tc)
            return i;
    return -1;
}

/* ------------------- конец партии / ничья ------------------- */

static void chk_check_over(chk_game_t *g)
{
    if (g->quiet >= CHK_QUIET_DRAW) {       /* добавленное правило ничьей */
        g->state = CHK_STATE_OVER;
        g->winner = CHK_WIN_DRAW;
        return;
    }
    if (g->nlegal > 0) return;

    int wc = chk_count_side(g, CHK_WHITE);
    int bc = chk_count_side(g, CHK_BLACK);
    if (wc == 0) {
        g->winner = (g->rule_mode == CHK_MODE_CLASSIC) ? CHK_WIN_BLACK : CHK_WIN_WHITE;
        g->state = CHK_STATE_OVER;
        return;
    }
    if (bc == 0) {
        g->winner = (g->rule_mode == CHK_MODE_CLASSIC) ? CHK_WIN_WHITE : CHK_WIN_BLACK;
        g->state = CHK_STATE_OVER;
        return;
    }
    /* ходов нет, шашки есть: в классике проигрывает тот, кто не ходит;
     * в «поддавках» — наоборот, выигрывает */
    g->winner = (g->rule_mode == CHK_MODE_CLASSIC) ? (unsigned char)(1 - g->player)
                                                   : g->player;
    g->state = CHK_STATE_OVER;
}

/* ---------------------- снимки (undo) ---------------------- */

static void chk_snap_push(chk_game_t *g)
{
    if (g->nsnap >= CHK_HIST_MAX) {       /* переполнение: вытесняем старейший */
        for (int i = 1; i < CHK_HIST_MAX; i++)
            for (int k = 0; k < 19; k++) g->snap[i - 1][k] = g->snap[i][k];
        g->nsnap--;
    }
    unsigned int *s = g->snap[g->nsnap];
    const unsigned char *b = &g->board[0][0];
    for (int i = 0; i < 16; i++)
        s[i] = (unsigned int)b[i * 4] |
               ((unsigned int)b[i * 4 + 1] << 8) |
               ((unsigned int)b[i * 4 + 2] << 16) |
               ((unsigned int)b[i * 4 + 3] << 24);
    s[16] = (unsigned int)g->player |
            ((unsigned int)g->must_cont << 8) |
            ((unsigned int)g->cont_r << 16) |
            ((unsigned int)g->cont_c << 24);
    s[17] = (unsigned int)g->state |
            ((unsigned int)g->winner << 8) |
            ((unsigned int)(g->last_valid ? 1 : 0) << 16) |
            ((unsigned int)(g->quiet & 0xFF) << 24);
    s[18] = (unsigned int)g->last_fr | ((unsigned int)g->last_fc << 4) |
            ((unsigned int)g->last_tr << 8) | ((unsigned int)g->last_tc << 12);
    g->nsnap++;
}

static void chk_snap_pop(chk_game_t *g)
{
    if (g->nsnap <= 0) return;
    g->nsnap--;
    const unsigned int *s = g->snap[g->nsnap];
    unsigned char *b = &g->board[0][0];
    for (int i = 0; i < 16; i++) {
        b[i * 4]     = (unsigned char)(s[i] & 0xFF);
        b[i * 4 + 1] = (unsigned char)((s[i] >> 8) & 0xFF);
        b[i * 4 + 2] = (unsigned char)((s[i] >> 16) & 0xFF);
        b[i * 4 + 3] = (unsigned char)((s[i] >> 24) & 0xFF);
    }
    g->player    = (unsigned char)(s[16] & 0xFF);
    g->must_cont = (unsigned char)((s[16] >> 8) & 0xFF);
    g->cont_r    = (unsigned char)((s[16] >> 16) & 0xFF);
    g->cont_c    = (unsigned char)((s[16] >> 24) & 0xFF);
    g->state     = (unsigned char)(s[17] & 0xFF);
    g->winner    = (unsigned char)((s[17] >> 8) & 0xFF);
    g->last_valid = (int)((s[17] >> 16) & 0xFF);
    g->quiet     = (int)((s[17] >> 24) & 0xFF);
    g->last_fr = (unsigned char)(s[18] & 0xF);
    g->last_fc = (unsigned char)((s[18] >> 4) & 0xF);
    g->last_tr = (unsigned char)((s[18] >> 8) & 0xF);
    g->last_tc = (unsigned char)((s[18] >> 12) & 0xF);
    chk_gen_legal(g);
}

/* Отменить ХОД (до его начала): против компьютера откатываем к началу
 * хода ЧЕЛОВЕКА (обычно 2 снимка), в горячем режиме — один. */
static int chk_undo(chk_game_t *g)
{
    if (g->nsnap <= 0) return 0;
    if (!g->vs_ai) { chk_snap_pop(g); return 1; }
    do {
        chk_snap_pop(g);
    } while (g->nsnap > 0 && g->player != CHK_WHITE);
    return 1;
}

/* --------------------- применение хода --------------------- */

/* Порт make_move: снятие битых, перемещение, превращение, продолжение
 * взятия (must_cont), смена игрока, проверка конца. */
static void chk_apply(chk_game_t *g, const chk_move_t *mv)
{
    unsigned char piece = g->board[mv->from_r][mv->from_c];

    for (int i = 0; i < mv->ncap; i++)
        g->board[mv->cap_r[i]][mv->cap_c[i]] = CHK_EMPTY;

    g->board[mv->from_r][mv->from_c] = CHK_EMPTY;
    g->board[mv->to_r][mv->to_c] = piece;

    if (piece == CHK_WMAN && (mv->to_r == 0 || mv->promoted))
        g->board[mv->to_r][mv->to_c] = CHK_WKING;
    else if (piece == CHK_BMAN &&
             (mv->to_r == CHK_BOARD - 1 || mv->promoted))
        g->board[mv->to_r][mv->to_c] = CHK_BKING;

    g->last_fr = mv->from_r; g->last_fc = mv->from_c;
    g->last_tr = mv->to_r;   g->last_tc = mv->to_c;
    g->last_valid = 1;

    /* прогресс партии: взятие или ход простой (не дамки) */
    int progressed = (mv->ncap > 0) || piece == CHK_WMAN || piece == CHK_BMAN;
    g->quiet = progressed ? 0 : g->quiet + 1;

    /* Сессия 22 (репро пользователя: «черные побили белых и не имеют
     * больше возможности бить, но выбрать белую нельзя — игра требует
     * продолжать взятие непонятно какой шашкой»).
     *
     * БЫЛО: cont_r/c ставились, chk_gen_legal() вызывался СО СТАРЫМ
     * must_cont==0 — генерировал взятия ВСЕХ шашек текущего игрока; если
     * бить могла ДРУГАЯ шашка (а не та, что только что завершила цепочку),
     * ставился must_cont=1 с конт-позицией бившей шашки, у которой ходов
     * НЕТ — игра блокировалась навсегда (выбор чужих шашек запрещён
     * must_cont, у конт-шашки legal пуст).
     *
     * СТАЛО: must_cont=1 ставится ДО генерации — legal[] строится ТОЛЬКО
     * для шашки взятия (chk_gen_legal в ветке must_cont). Продолжение
     * возможно лишь когда ЭТА шашка реально может бить дальше; иначе —
     * обычная смена хода, даже если у других шашек есть взятия
     * (правильно: бившая шашка свой ход уже закончила). */
    if (mv->ncap > 0) {
        g->cont_r = mv->to_r;
        g->cont_c = mv->to_c;
        g->must_cont = 1;
        chk_gen_legal(g);
        if (g->nlegal > 0)
            return;                   /* ход не закончен: бьём дальше */
    }

    g->must_cont = 0;
    g->cont_r = 0;
    g->cont_c = 0;
    g->player = (unsigned char)(1 - g->player);
    chk_gen_legal(g);
    chk_check_over(g);
}

/* Ход ЧЕЛОВЕКА: снимок ставится в начале хода (не на продолжении
 * мультивзятия), затем ход применяется. */
static int chk_human_move(chk_game_t *g, const chk_move_t *mv)
{
    if (g->state != CHK_STATE_PLAY || g->nlegal <= 0) return 0;
    if (g->vs_ai && g->player != CHK_WHITE) return 0;   /* сейчас ходит ИИ */
    if (!g->must_cont) chk_snap_push(g);
    chk_apply(g, mv);
    return 1;
}

/* ------------------------------ ИИ ------------------------------ */

typedef struct {
    unsigned char b[CHK_BOARD][CHK_BOARD];
    unsigned char player;
} chk_lite_t;

static int chk_lite_eval(const chk_lite_t *lb, int player)
{
    int score = 0;
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int p = lb->b[r][c];
            if (p == CHK_EMPTY) continue;
            int mine = (chk_piece_side(p) == player);
            int king = chk_is_king(p);
            int val = king ? 30 : 10;
            if (!king) val += (player == CHK_WHITE) ? (7 - r) : r;
            score += mine ? val : -val;
        }
    return score;
}

static chk_lite_t chk_lite_apply(const chk_lite_t *src, const chk_move_t *mv)
{
    chk_lite_t dst = *src;
    unsigned char piece = dst.b[mv->from_r][mv->from_c];
    dst.b[mv->from_r][mv->from_c] = CHK_EMPTY;
    for (int i = 0; i < mv->ncap; i++)
        dst.b[mv->cap_r[i]][mv->cap_c[i]] = CHK_EMPTY;
    dst.b[mv->to_r][mv->to_c] = piece;
    if (piece == CHK_WMAN && (mv->to_r == 0 || mv->promoted))
        dst.b[mv->to_r][mv->to_c] = CHK_WKING;
    if (piece == CHK_BMAN &&
        (mv->to_r == CHK_BOARD - 1 || mv->promoted))
        dst.b[mv->to_r][mv->to_c] = CHK_BKING;
    dst.player = (unsigned char)(1 - src->player);
    return dst;
}

static int chk_lite_gen(const chk_lite_t *lb, chk_move_t *out)
{
    chk_move_t all[CHK_MAX_MOVES];
    int cnt = 0;
    /* копия доски: генераторы временно «ставят» шашки на посадочные
     * клетки при поиске цепочек — константную lb->b не трогаем */
    unsigned char b[CHK_BOARD][CHK_BOARD];
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++)
            b[r][c] = lb->b[r][c];

    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int p = b[r][c];
            if (p == CHK_EMPTY || chk_piece_side(p) != lb->player) continue;
            chk_gen_captures_on(b, r, c, all, &cnt);
        }
    if (cnt == 0) {
        for (int r = 0; r < CHK_BOARD; r++)
            for (int c = 0; c < CHK_BOARD; c++) {
                int p = b[r][c];
                if (p == CHK_EMPTY || chk_piece_side(p) != lb->player) continue;
                chk_gen_regular_on(b, r, c, all, &cnt);
            }
    }
    int n = cnt < CHK_MAX_MOVES ? cnt : CHK_MAX_MOVES;
    for (int i = 0; i < n; i++) out[i] = all[i];
    return n;
}

static int chk_lite_minimax(chk_lite_t lb, int depth, int alpha, int beta,
                            int mm_player)
{
    if (depth == 0) return chk_lite_eval(&lb, mm_player);
    chk_move_t moves[CHK_MAX_MOVES];
    int nmoves = chk_lite_gen(&lb, moves);
    if (nmoves == 0) return chk_lite_eval(&lb, mm_player);
    int is_max = (lb.player == mm_player);
    int best = is_max ? -32000 : 32000;
    for (int i = 0; i < nmoves; i++) {
        chk_lite_t next = chk_lite_apply(&lb, &moves[i]);
        int score = chk_lite_minimax(next, depth - 1, alpha, beta, mm_player);
        if (is_max) {
            if (score > best) best = score;
            if (score > alpha) alpha = score;
        } else {
            if (score < best) best = score;
            if (score < beta) beta = score;
        }
        if (beta <= alpha) break;
    }
    return best;
}

/* Выбрать и СДЕЛАТЬ ход компьютера. 1 = ход сделан. */
static int chk_ai_move(chk_game_t *g)
{
    if (g->state != CHK_STATE_PLAY || g->nlegal <= 0) return 0;
    int n = g->nlegal;

    chk_snap_push(g);                     /* отменяется как обычный ход */

    if (g->ai_level == 0) {               /* Новичок: случайный ход */
        chk_move_t mv = g->legal[chk_rand(g) % (unsigned int)n];
        chk_apply(g, &mv);
        return 1;
    }

    int best_score = -32000, best_idx = 0;
    int depth = (g->ai_level == 1) ? 2 : 4;   /* Игрок / Мастер */
    chk_lite_t root;
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++)
            root.b[r][c] = g->board[r][c];
    root.player = g->player;

    for (int i = 0; i < n; i++) {
        chk_lite_t after = chk_lite_apply(&root, &g->legal[i]);
        int score = chk_lite_minimax(after, depth, -32000, 32000, root.player);
        if (g->ai_level == 1) score += (int)(chk_rand(g) % 3u);  /* вариативность */
        if (score > best_score) { best_score = score; best_idx = i; }
    }

    chk_move_t mv = g->legal[best_idx];
    chk_apply(g, &mv);
    return 1;
}

/* ------------------------------ новая игра ------------------------------ */

static void chk_init(chk_game_t *g, int rule_mode, int vs_ai, int ai_level,
                     unsigned int seed)
{
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++)
            g->board[r][c] = CHK_EMPTY;

    for (int r = 0; r < 3; r++)                       /* чёрные сверху */
        for (int c = 0; c < CHK_BOARD; c++)
            if ((r + c) % 2 == 1) g->board[r][c] = CHK_BMAN;

    for (int r = 5; r < 8; r++)                       /* белые снизу */
        for (int c = 0; c < CHK_BOARD; c++)
            if ((r + c) % 2 == 1) g->board[r][c] = CHK_WMAN;

    g->player = CHK_WHITE;
    g->must_cont = 0;
    g->cont_r = g->cont_c = 0;
    g->rule_mode = (unsigned char)rule_mode;
    g->vs_ai = (unsigned char)vs_ai;
    g->ai_level = (unsigned char)ai_level;
    g->state = CHK_STATE_PLAY;
    g->winner = CHK_WIN_NONE;
    g->rng = seed ? seed : 0x9E3779B9u;
    g->nlegal = 0;
    g->has_cap = 0;
    g->quiet = 0;
    g->last_valid = 0;
    g->last_fr = g->last_fc = g->last_tr = g->last_tc = 0;
    g->nsnap = 0;
    chk_gen_legal(g);
}

/* ------------------------- сохранение / загрузка -------------------------
 * Текстовый формат (надёжен к переводу строк и проверяем глазами):
 *   CHECKERS1
 *   <rule> <vsai> <ai> <player> <must> <cont_r> <cont_c> <state> <winner> <quiet>
 *   8 строк доски по 8 чисел 0..4
 *   <last_fr> <last_fc> <last_tr> <last_tc> <last_valid> */

static int chk__emit(char *out, int max, int *o, const char *s)
{
    while (*s) {
        if (*o >= max - 1) return 0;
        out[(*o)++] = *s++;
    }
    return 1;
}

static int chk__emiti(char *out, int max, int *o, long v)
{
    char t[12];
    int i = 0;
    unsigned long u = (v < 0) ? (unsigned long)(-v) : (unsigned long)v;
    do { t[i++] = (char)('0' + (u % 10)); u /= 10; } while (u);
    if (v < 0) {
        if (*o >= max - 1) return 0;
        out[(*o)++] = '-';
    }
    while (i) {
        if (*o >= max - 1) return 0;
        out[(*o)++] = t[--i];
    }
    return 1;
}

static int chk__emitc(char *out, int max, int *o, char c)
{
    if (*o >= max - 1) return 0;
    out[(*o)++] = c;
    return 1;
}

static int chk_serialize(const chk_game_t *g, char *out, int max)
{
    int o = 0;
    if (!chk__emit(out, max, &o, "CHECKERS1\n")) return 0;
    long vals[10] = { g->rule_mode, g->vs_ai, g->ai_level, g->player,
                      g->must_cont, g->cont_r, g->cont_c, g->state,
                      g->winner, g->quiet };
    for (int i = 0; i < 10; i++) {
        if (!chk__emiti(out, max, &o, vals[i])) return 0;
        if (!chk__emitc(out, max, &o, i == 9 ? '\n' : ' ')) return 0;
    }
    for (int r = 0; r < CHK_BOARD; r++) {
        for (int c = 0; c < CHK_BOARD; c++) {
            if (!chk__emiti(out, max, &o, g->board[r][c])) return 0;
            if (!chk__emitc(out, max, &o, c == 7 ? '\n' : ' ')) return 0;
        }
    }
    long tail[5] = { g->last_fr, g->last_fc, g->last_tr, g->last_tc,
                     g->last_valid };
    for (int i = 0; i < 5; i++) {
        if (!chk__emiti(out, max, &o, tail[i])) return 0;
        if (!chk__emitc(out, max, &o, i == 4 ? '\n' : ' ')) return 0;
    }
    out[o] = 0;
    return o;
}

static int chk__next_int(const char **p, long *out)
{
    const char *s = *p;
    while (*s == ' ' || *s == '\n' || *s == '\r' || *s == '\t') s++;
    int neg = 0;
    if (*s == '-') { neg = 1; s++; }
    if (*s < '0' || *s > '9') return 0;
    long v = 0;
    while (*s >= '0' && *s <= '9') {
        v = v * 10 + (*s - '0');
        if (v > 1000000) return 0;         /* защита от мусора */
        s++;
    }
    *p = s;
    *out = neg ? -v : v;
    return 1;
}

/* Восстановить партию. Возвращает 1 при успехе (состояние гарантированно
 * валидно), 0 — файл испорчен (состояние g не меняется). */
static int chk_deserialize(chk_game_t *g, const char *s)
{
    static const char hdr[] = "CHECKERS1";
    chk_game_t t;

    const char *p = s;
    while (*p == '\r' || *p == '\n' || *p == ' ' || *p == '\t') p++;
    for (int i = 0; hdr[i]; i++)
        if (p[i] != hdr[i]) return 0;
    p += sizeof(hdr) - 1;

    long v[10];
    for (int i = 0; i < 10; i++)
        if (!chk__next_int(&p, &v[i])) return 0;

    if (v[0] < 0 || v[0] > 1) return 0;              /* rule_mode */
    if (v[1] < 0 || v[1] > 1) return 0;              /* vs_ai */
    if (v[2] < 0 || v[2] > 2) return 0;              /* ai_level */
    if (v[3] < 0 || v[3] > 1) return 0;              /* player */
    if (v[4] < 0 || v[4] > 1) return 0;              /* must_cont */
    if (v[5] < 0 || v[5] > 7 || v[6] < 0 || v[6] > 7) return 0;
    if (v[7] < 0 || v[7] > 1) return 0;              /* state */
    if (v[8] != CHK_WIN_NONE && v[8] != CHK_WIN_WHITE &&
        v[8] != CHK_WIN_BLACK && v[8] != CHK_WIN_DRAW) return 0;
    if (v[9] < 0 || v[9] > CHK_QUIET_DRAW + 8) return 0;

    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            long cell;
            if (!chk__next_int(&p, &cell)) return 0;
            if (cell < CHK_EMPTY || cell > CHK_BKING) return 0;
            t.board[r][c] = (unsigned char)cell;
        }

    long tail[5];
    for (int i = 0; i < 5; i++)
        if (!chk__next_int(&p, &tail[i])) return 0;
    for (int i = 0; i < 4; i++)
        if (tail[i] < 0 || tail[i] > 7) return 0;
    if (tail[4] < 0 || tail[4] > 1) return 0;

    /* состояние валидно — переносим */
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++)
            g->board[r][c] = t.board[r][c];
    g->rule_mode = (unsigned char)v[0];
    g->vs_ai     = (unsigned char)v[1];
    g->ai_level  = (unsigned char)v[2];
    g->player    = (unsigned char)v[3];
    g->must_cont = (unsigned char)v[4];
    g->cont_r    = (unsigned char)v[5];
    g->cont_c    = (unsigned char)v[6];
    g->state     = (unsigned char)v[7];
    g->winner    = (unsigned char)v[8];
    g->quiet     = (int)v[9];
    g->last_fr = (unsigned char)tail[0];
    g->last_fc = (unsigned char)tail[1];
    g->last_tr = (unsigned char)tail[2];
    g->last_tc = (unsigned char)tail[3];
    g->last_valid = (int)tail[4];
    g->nsnap = 0;                     /* история отмен не сохраняется */
    g->rng = 0x9E3779B9u;
    chk_gen_legal(g);
    if (g->must_cont && g->nlegal <= 0) return 0;   /* повреждённые данные */
    return 1;
}

#endif /* CHK_GAME_H */
