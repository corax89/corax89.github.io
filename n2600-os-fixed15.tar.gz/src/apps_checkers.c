/* apps_checkers.c — «Шашки» для N2600-OS (GUI-порт).
 *
 * Логика — src/chk_game.h: порт консольных шашек пользователя
 * (минимакс + альфа-бета, классика/поддавки, уровни Новичок/Игрок/
 * Мастер, обязательное взятие, цепочки взятий, дамки). Консоль оригинала
 * заменена:
 *   - доска 8x8 рисуется клетками 38x38 (fb_*), шашки — «монетами»;
 *   - мышь: ЛКМ по своей шашке — выбор, ЛКМ по подсвеченной цели — ход;
 *     ПКМ — меню (правила/соперник/уровень/сохранение);
 *   - клавиатура: стрелки — курсор, Enter — выбрать/ход, N — новая
 *     партия, U — отмена хода, Esc — закрыть;
 *   - кнопки панели: Новая / Отмена / Сохранить / Загрузить (файловый
 *     диалог, формат .chk — текстовая сериализация chk_game.h);
 *   - ИИ ходит в on_tick (окно успевает показать «думает...»);
 *   - статус-строка внизу.
 *
 * Состояние игры — chk_game_t внутри checkers_t (malloc окна).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "filedlg.h"
#include "ramfs.h"
#include "fat32.h"
#include "chk_game.h"

/* --------------------------- геометрия --------------------------- */
#define CELL      38          /* клетка доски, px */
#define BD        (CHK_BOARD * CELL)
#define BOARD_X   8
#define BOARD_Y   8
#define PANEL_X   (BOARD_X + BD + 8)
#define PANEL_W   112
#define STATUS_H  18

#define CHK_WW    (PANEL_X + PANEL_W + 6)
#define CHK_WH    (BOARD_Y + BD + 6 + STATUS_H + TITLE_H + 2)

/* кнопки панели. Сессия 22 (репро со скриншота): кнопки стояли вплотную
 * к значению «Уровень:» (текст y=162 занимает 162..177 при шрифте 8x16)
 * и перекрывали его кнопкой «Новая» (y=168). Опущены ниже подписей:
 * теперь панель всегда читаема при обоих режимах (с ИИ и без). */
enum { CB_NEW = 0, CB_UNDO, CB_SAVE, CB_LOAD, CB_COUNT };
static const int cb_y[CB_COUNT] = { 184, 208, 232, 256 };
static const char *const cb_labels[CB_COUNT] = {
    "Новая", "Отмена", "Сохранить", "Загрузить"
};

#define C_BTN_HOT  fb_rgb(0x32, 0x60, 0x8E)   /* кнопка под курсором */

static void cb_rect(int i, int *x, int *y, int *w, int *h)
{
    *x = PANEL_X; *y = cb_y[i]; *w = PANEL_W; *h = 20;
}

/* --------------------------- цвета --------------------------- */
#define C_LIGHT    fb_rgb(0xB0, 0x92, 0x6A)   /* светлая клетка */
#define C_DARK     fb_rgb(0x5A, 0x46, 0x34)   /* тёмная клетка */
#define C_W_BODY   fb_rgb(0xE8, 0xEC, 0xF0)   /* белая шашка */
#define C_W_RIM    fb_rgb(0x50, 0x58, 0x62)
#define C_B_BODY   fb_rgb(0x14, 0x18, 0x1E)   /* чёрная шашка */
#define C_B_RIM    fb_rgb(0x8A, 0x94, 0x9E)
#define C_TARGET   fb_rgb(0x8A, 0xC8, 0xE8)   /* точка хода */
#define C_CAPT     fb_rgb(0xE8, 0x8A, 0x5A)   /* точка взятия */
#define C_LAST     fb_rgb(0x6F, 0xB3, 0xF2)   /* контур последнего хода */
#define C_KB       fb_rgb(0xFF, 0xE0, 0x60)   /* клавиатурный курсор */

typedef struct {
    chk_game_t g;
    int sel_r, sel_c;          /* выбранная шашка (-1 = нет) */
    int kr, kc;                /* клавиатурный курсор */
    int ai_pending;            /* ИИ должен подумать в on_tick */
    int dlg;                   /* открыт файловый диалог */
    int btn_hot, btn_pressed;
    char status[80];
    int msg_timer;             /* тики показа status вместо подсказки */
    unsigned int seed_ctr;
} checkers_t;

/* --------------------------- отрисовка --------------------------- */

static void chk_fill_circle(int cx, int cy, int r, u32 col)
{
    for (int dy = -r; dy <= r; dy++) {
        int dx = 0;
        while ((dx + 1) * (dx + 1) + dy * dy <= r * r) dx++;
        fb_hline(cx - dx, cx + dx, cy + dy, col);
    }
}

static const char *chk_level_name(int lvl)
{
    switch (lvl) {
    case 0: return "Новичок";
    case 1: return "Игрок";
    default: return "Мастер";
    }
}

static void draw_piece(int x, int y, int piece)
{
    int cx = x + CELL / 2, cy = y + CELL / 2;
    u32 body, rim;
    if (chk_piece_side(piece) == CHK_WHITE) { body = C_W_BODY; rim = C_W_RIM; }
    else                                    { body = C_B_BODY; rim = C_B_RIM; }

    chk_fill_circle(cx, cy, 15, rim);
    chk_fill_circle(cx, cy, 13, body);

    if (chk_is_king(piece)) {
        /* дамка: кольцо + метка в центре */
        chk_fill_circle(cx, cy, 9, rim);
        chk_fill_circle(cx, cy, 7, body);
        chk_fill_circle(cx, cy, 3, rim);
    } else {
        /* простая: пару концентрических бороздок */
        chk_fill_circle(cx, cy, 9, rim);
        chk_fill_circle(cx, cy, 8, body);
    }
}

static void chk_cell_rect(int r, int c, int *x, int *y)
{
    *x = BOARD_X + c * CELL;
    *y = BOARD_Y + r * CELL;
}

static int chk_cell_at(const checkers_t *d, int mx, int my, int *r, int *c)
{
    (void)d;
    int cc = (mx - BOARD_X) / CELL;
    int rr = (my - BOARD_Y) / CELL;
    if (!chk_in_board(rr, cc)) return 0;
    if (mx < BOARD_X || my < BOARD_Y) return 0;
    *r = rr; *c = cc;
    return 1;
}

static void chk_set_status(checkers_t *d, const char *msg)
{
    strncpy(d->status, msg, sizeof(d->status) - 1);
    d->status[sizeof(d->status) - 1] = 0;
    d->msg_timer = 4;               /* ~2 с (on_tick 2 Гц) */
}

/* эффективное выделение: при обязательном продолжении — шашка взятия */
static void chk_effective_sel(const checkers_t *d, int *sr, int *sc)
{
    if (d->g.must_cont) { *sr = d->g.cont_r; *sc = d->g.cont_c; }
    else                { *sr = d->sel_r;    *sc = d->sel_c;    }
}

static void chk_draw(window_t *w)
{
    checkers_t *d = (checkers_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    /* --- доска --- */
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int x, y;
            chk_cell_rect(r, c, &x, &y);
            fb_fill_rect(x, y, CELL, CELL,
                         ((r + c) % 2 == 0) ? C_LIGHT : C_DARK);
        }

    /* контур последнего полухода */
    if (d->g.last_valid) {
        int x, y;
        chk_cell_rect(d->g.last_fr, d->g.last_fc, &x, &y);
        fb_rect(x + 1, y + 1, CELL - 2, CELL - 2, C_LAST);
        chk_cell_rect(d->g.last_tr, d->g.last_tc, &x, &y);
        fb_rect(x + 1, y + 1, CELL - 2, CELL - 2, C_LAST);
    }

    /* шашки */
    for (int r = 0; r < CHK_BOARD; r++)
        for (int c = 0; c < CHK_BOARD; c++) {
            int p = d->g.board[r][c];
            if (p != CHK_EMPTY) {
                int x, y;
                chk_cell_rect(r, c, &x, &y);
                draw_piece(x, y, p);
            }
        }

    /* подсветка выбранной шашки и целей */
    {
        int sr, sc;
        chk_effective_sel(d, &sr, &sc);
        if (sr >= 0) {
            int x, y;
            chk_cell_rect(sr, sc, &x, &y);
            fb_rect(x + 1, y + 1, CELL - 2, CELL - 2, wm_theme_accent());
            fb_rect(x + 2, y + 2, CELL - 4, CELL - 4, wm_theme_accent());
            for (int i = 0; i < d->g.nlegal; i++) {
                const chk_move_t *mv = &d->g.legal[i];
                if (mv->from_r != sr || mv->from_c != sc) continue;
                chk_cell_rect(mv->to_r, mv->to_c, &x, &y);
                chk_fill_circle(x + CELL / 2, y + CELL / 2, 5,
                                mv->ncap > 0 ? C_CAPT : C_TARGET);
            }
        }
    }

    /* клавиатурный курсор */
    {
        int x, y;
        chk_cell_rect(d->kr, d->kc, &x, &y);
        fb_rect(x, y, CELL, CELL, C_KB);
    }

    /* --- панель --- */
    fb_fill_rect(PANEL_X - 4, 0, PANEL_W + 10, ch, wm_theme_win_bg_alt());

    const char *turn = (d->g.player == CHK_WHITE) ? "белые" : "чёрные";
    char line[48];
    if (d->g.state == CHK_STATE_PLAY) {
        snprintf(line, sizeof(line), "Ход: %s", turn);
        fb_text(PANEL_X, 10, line, wm_theme_text_info(), -1);
    } else {
        wm_text_fit(PANEL_X, 10, "Игра окончена", PANEL_W,
                    wm_theme_text_info(), 0);
    }

    snprintf(line, sizeof(line), "Белые: %d", chk_count_side(&d->g, CHK_WHITE));
    fb_text(PANEL_X, 30, line, wm_theme_text(), -1);
    snprintf(line, sizeof(line), "Чёрные: %d", chk_count_side(&d->g, CHK_BLACK));
    fb_text(PANEL_X, 48, line, wm_theme_text(), -1);

    fb_text(PANEL_X, 74, "Правила:", wm_theme_text_dim(), -1);
    fb_text(PANEL_X, 90,
            d->g.rule_mode == CHK_MODE_CLASSIC ? "русские" : "поддавки",
            wm_theme_text(), -1);
    fb_text(PANEL_X, 110, "Соперник:", wm_theme_text_dim(), -1);
    fb_text(PANEL_X, 126, d->g.vs_ai ? "компьютер" : "человек",
            wm_theme_text(), -1);
    if (d->g.vs_ai) {
        fb_text(PANEL_X, 146, "Уровень:", wm_theme_text_dim(), -1);
        fb_text(PANEL_X, 162, chk_level_name(d->g.ai_level),
                wm_theme_text(), -1);
    }

    /* кнопки (сессия 20: подписи гарантированно внутри) */
    for (int i = 0; i < CB_COUNT; i++) {
        int x, y, bw, bh;
        cb_rect(i, &x, &y, &bw, &bh);
        int disabled = (i == CB_UNDO && d->g.nsnap <= 0);
        u32 bg = (d->btn_pressed == i) ? wm_theme_sel_bg()
               : (d->btn_hot == i && !disabled) ? C_BTN_HOT
               : wm_theme_title();
        wm_button_draw(x, y, bw, bh, cb_labels[i],
                       disabled ? wm_theme_title_unfoc() : bg,
                       disabled ? wm_theme_text_dim()
                                : wm_theme_title_text(),
                       wm_theme_border());
    }

    /* статус-строка: гарантированно внутри окна (сессия 20) */
    fb_fill_rect(0, ch - STATUS_H, cw, STATUS_H, wm_theme_win_bg_alt());
    fb_hline(0, cw - 1, ch - STATUS_H, wm_theme_border());

    const char *st;
    if (d->msg_timer > 0) {
        st = d->status;
    } else if (d->g.state == CHK_STATE_OVER) {
        if (d->g.winner == CHK_WIN_DRAW)      st = "Ничья (60 тихих ходов)";
        else if (d->g.winner == CHK_WIN_WHITE) st = "Победа белых!";
        else if (d->g.winner == CHK_WIN_BLACK) st = "Победа чёрных!";
        else                                   st = "Партия окончена";
    } else if (d->ai_pending) {
        st = "Компьютер думает...";
    } else if (d->g.must_cont) {
        st = "Продолжайте взятие этой шашкой!";
    } else if (d->g.vs_ai && d->g.player == CHK_WHITE) {
        st = "Ваш ход: ЛКМ — шашка, затем цель; ПКМ — меню";
    } else {
        st = (d->g.vs_ai) ? "Компьютер думает..."
                          : "ЛКМ — шашка, затем цель; ПКМ — меню";
    }
    wm_text_fit(4, ch - STATUS_H + 1, st, cw - 8, wm_theme_text_dim(), 0);
}

/* ------------------------- файловые диалоги ------------------------- */

static void chk_dlg_save_ok(void *ctx, const fd_save_t *save)
{
    checkers_t *d = (checkers_t *)ctx;
    d->dlg = 0;

    char buf[512];
    int len = chk_serialize(&d->g, buf, (int)sizeof(buf) - 1);
    if (len <= 0) { chk_set_status(d, "Ошибка сериализации партии"); return; }

    if (save->source == FD_SRC_RAMFS) {
        char full[232];
        const char *base = save->path;
        if (base[0] == '/' && !base[1]) snprintf(full, sizeof(full), "%s", save->name);
        else snprintf(full, sizeof(full), "%s/%s", base, save->name);
        if (!ramfs_ready()) { chk_set_status(d, "RAM disk недоступен"); return; }
        ramfs_delete(full);
        if (!ramfs_create(full, (u32)len + 1) ||
            !ramfs_write(full, buf, (u32)len + 1)) {
            chk_set_status(d, "Ошибка записи в RAM disk");
            return;
        }
        char msg[96];
        snprintf(msg, sizeof(msg), "Сохранено: %s", full);
        chk_set_status(d, msg);
    } else {
        if (!fat32_ready()) { chk_set_status(d, "FAT32 не смонтирована"); return; }
        if (!fat32_write_file(save->cluster, save->name, buf, (u32)len + 1)) {
            chk_set_status(d, "Ошибка записи на диск");
            return;
        }
        char msg[96];
        const char *src = save->source == FD_SRC_ATA ? "HDD" : "USB";
        snprintf(msg, sizeof(msg), "Сохранено: %s:%s/%s", src, save->path,
                 save->name);
        chk_set_status(d, msg);
    }
}

static void chk_dlg_open_ok(void *ctx, const fd_pick_t *pick,
                            char *content, int len)
{
    checkers_t *d = (checkers_t *)ctx;
    d->dlg = 0;
    if (!content || len <= 0) { chk_set_status(d, "Пустой файл"); return; }
    /* страховка: файл мог не поместиться в буфер диалога без хвоста */
    content[len - 1] = 0;
    if (!chk_deserialize(&d->g, content)) {
        free(content);
        chk_set_status(d, "Файл не партия шашек или повреждён");
        return;
    }
    free(content);
    d->sel_r = d->sel_c = -1;
    d->ai_pending = 0;
    char msg[96];
    snprintf(msg, sizeof(msg), "Загружено: %s", pick->name);
    chk_set_status(d, msg);
    /* если в сохранённой партии ход компьютера — он подумает сам */
    if (d->g.vs_ai && d->g.player == CHK_BLACK && d->g.state == CHK_STATE_PLAY)
        d->ai_pending = 1;
}

static void chk_dlg_cancel(void *ctx)
{
    checkers_t *d = (checkers_t *)ctx;
    d->dlg = 0;
    chk_set_status(d, "Отменено");
}

static void chk_save_as(checkers_t *d)
{
    if (d->dlg) return;
    d->dlg = 1;
    chk_set_status(d, "Сохранение: выберите диск и имя (Tab — диск)");
    filedlg_save("Сохранить партию", "party.chk", FD_SRC_RAMFS,
                 chk_dlg_save_ok, chk_dlg_cancel, d);
}

static void chk_load_file(checkers_t *d)
{
    if (d->dlg) return;
    d->dlg = 1;
    chk_set_status(d, "Загрузка: выберите файл партии (.chk)");
    filedlg_open("Загрузить партию", ".chk", NULL,
                 chk_dlg_open_ok, chk_dlg_cancel, d);
}

/* ------------------------------ действия ------------------------------ */

static u32 chk_seed(checkers_t *d)
{
    d->seed_ctr += 0x9E3779B9u;
    return (timer_ticks() * 1664525u + d->seed_ctr) | 1u;
}

/* Новая партия с текущими настройками. */
static void chk_new_game(checkers_t *d)
{
    chk_init(&d->g, d->g.rule_mode, d->g.vs_ai, d->g.ai_level, chk_seed(d));
    d->sel_r = d->sel_c = -1;
    d->ai_pending = 0;
}

/* Применить настройку из меню (правила/соперник/уровень) — с новой
 * партией: менять правила на середине партии нельзя. */
static void chk_apply_setting(checkers_t *d, int rule, int vs_ai, int level)
{
    chk_init(&d->g, rule, vs_ai, level, chk_seed(d));
    d->sel_r = d->sel_c = -1;
    d->ai_pending = 0;
    chk_set_status(d, "Настройки применены — новая партия");
}

static void chk_do_undo(checkers_t *d)
{
    if (d->g.nsnap <= 0) { chk_set_status(d, "Отменять нечего"); return; }
    chk_undo(&d->g);
    d->sel_r = d->sel_c = -1;
    d->ai_pending = 0;
    chk_set_status(d, "Ход отменён");
}

/* ------------------------------ контекстное меню ------------------------------ */

static void chk_menu_cb(int id, void *uctx)
{
    checkers_t *d = (checkers_t *)uctx;
    switch (id) {
    case 1: chk_new_game(d); break;
    case 2: chk_do_undo(d); break;
    case 3: chk_save_as(d); break;
    case 4: chk_load_file(d); break;
    case 5:
        chk_apply_setting(d, d->g.rule_mode == CHK_MODE_CLASSIC ?
                          CHK_MODE_GIVEAWAY : CHK_MODE_CLASSIC,
                          d->g.vs_ai, d->g.ai_level);
        break;
    case 6:
        chk_apply_setting(d, d->g.rule_mode, d->g.vs_ai ? 0 : 1,
                          d->g.ai_level);
        break;
    case 7: {
        int lvl = (d->g.ai_level + 1) % 3;
        chk_apply_setting(d, d->g.rule_mode, d->g.vs_ai, lvl);
        break;
    }
    default: break;
    }
}

static void chk_open_menu(window_t *w, int mx, int my)
{
    checkers_t *d = (checkers_t *)w->data;
    static char l_rule[44], l_opp[44], l_lvl[44];
    static wm_menu_item_t it[8];
    int n = 0;

    it[n].label = "Новая игра";          it[n].id = 1; n++;
    it[n].label = "Отменить ход";        it[n].id = 2; n++;
    it[n].label = "Сохранить партию..."; it[n].id = 3; n++;
    it[n].label = "Загрузить партию..."; it[n].id = 4; n++;
    it[n].label = 0;                     it[n].id = 0; n++;   /* разделитель */
    snprintf(l_rule, sizeof(l_rule), "Правила: %s",
             d->g.rule_mode == CHK_MODE_CLASSIC ? "русские" : "поддавки");
    it[n].label = l_rule;                it[n].id = 5; n++;
    snprintf(l_opp, sizeof(l_opp), "Соперник: %s",
             d->g.vs_ai ? "компьютер" : "человек");
    it[n].label = l_opp;                 it[n].id = 6; n++;
    if (d->g.vs_ai) {
        snprintf(l_lvl, sizeof(l_lvl), "Уровень ИИ: %s",
                 chk_level_name(d->g.ai_level));
        it[n].label = l_lvl;             it[n].id = 7; n++;
    }
    wm_menu_open(w, mx, my, it, n, chk_menu_cb, d);
}

/* ------------------------------ ввод ------------------------------ */

/* Ход человека по клеткам (from -> to); отдаёт статус при ошибке. */
static void chk_try_move(checkers_t *d, int fr, int fc, int tr, int tc)
{
    int mi = chk_find_move(&d->g, fr, fc, tr, tc);
    if (mi < 0) { chk_set_status(d, "Так ходить нельзя"); return; }
    chk_human_move(&d->g, &d->g.legal[mi]);
    d->sel_r = d->sel_c = -1;
    if (d->g.state == CHK_STATE_PLAY && d->g.vs_ai &&
        d->g.player == CHK_BLACK)
        d->ai_pending = 1;
}

static int chk_human_turn(const checkers_t *d)
{
    return d->g.state == CHK_STATE_PLAY && !d->ai_pending &&
           (!d->g.vs_ai || d->g.player == CHK_WHITE);
}

static int chk_btn_at(int mx, int my)
{
    for (int i = 0; i < CB_COUNT; i++) {
        int x, y, w, h;
        cb_rect(i, &x, &y, &w, &h);
        if (mx >= x && mx < x + w && my >= y && my < y + h) return i;
    }
    return -1;
}

static void chk_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    checkers_t *d = (checkers_t *)w->data;
    if (d->dlg) return;

    /* ПКМ — меню (в любом месте содержимого) */
    if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
        chk_open_menu(w, mx, my);
        return;
    }

    /* кнопки панели */
    if (mx >= PANEL_X - 4) {
        int hot = chk_btn_at(mx, my);
        if (hot != d->btn_hot) { d->btn_hot = hot; win_invalidate(w); }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            if (hot >= 0) { d->btn_pressed = hot; win_invalidate(w); }
        }
        if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
            int wp = d->btn_pressed;
            d->btn_pressed = -1;
            if (wp >= 0 && hot == wp) {
                if (wp == CB_NEW)   chk_new_game(d);
                else if (wp == CB_UNDO) chk_do_undo(d);
                else if (wp == CB_SAVE) chk_save_as(d);
                else if (wp == CB_LOAD) chk_load_file(d);
            }
            win_invalidate(w);
        }
        return;
    }

    /* курсор ушёл с панели — сброс hover */
    if (d->btn_hot != -1 || d->btn_pressed != -1) {
        d->btn_hot = -1;
        d->btn_pressed = -1;
        win_invalidate(w);
    }

    /* доска */
    if (!chk_human_turn(d)) return;
    int r, c;
    if (!chk_cell_at(d, mx, my, &r, &c)) return;
    d->kr = r; d->kc = c;

    if (!((changed & MSB_LEFT) && (btn & MSB_LEFT))) return;

    int piece = d->g.board[r][c];
    int sr, sc;
    chk_effective_sel(d, &sr, &sc);

    if (sr >= 0 && (r != sr || c != sc)) {
        /* клик по цели выделенной шашки? */
        for (int i = 0; i < d->g.nlegal; i++) {
            const chk_move_t *mv = &d->g.legal[i];
            if (mv->from_r == sr && mv->from_c == sc &&
                mv->to_r == r && mv->to_c == c) {
                chk_try_move(d, sr, sc, r, c);
                win_invalidate(w);
                return;
            }
        }
    }

    /* клик по своей шашке — выбор/перевыбор/снятие */
    if (piece != CHK_EMPTY &&
        chk_piece_side(piece) == d->g.player &&
        !(d->g.must_cont && (r != d->g.cont_r || c != d->g.cont_c))) {
        if (!d->g.must_cont && r == d->sel_r && c == d->sel_c) {
            d->sel_r = d->sel_c = -1;          /* снятие выбора */
        } else {
            d->sel_r = r; d->sel_c = c;
        }
        win_invalidate(w);
        return;
    }

    /* промах: снять выбор (если не must_cont) */
    if (!d->g.must_cont && d->sel_r >= 0) {
        d->sel_r = d->sel_c = -1;
        win_invalidate(w);
    }
}

static void chk_key(window_t *w, const key_event_t *ev)
{
    checkers_t *d = (checkers_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (d->dlg) return;

    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }

    switch (ev->code) {
    case KBD_UP:    if (d->kr > 0) d->kr--; win_invalidate(w); return;
    case KBD_DOWN:  if (d->kr < CHK_BOARD - 1) d->kr++; win_invalidate(w); return;
    case KBD_LEFT:  if (d->kc > 0) d->kc--; win_invalidate(w); return;
    case KBD_RIGHT: if (d->kc < CHK_BOARD - 1) d->kc++; win_invalidate(w); return;
    default: break;
    }

    if (ev->ch == 'n' || ev->ch == 'N') { chk_new_game(d); win_invalidate(w); return; }
    if (ev->ch == 'u' || ev->ch == 'U') { chk_do_undo(d); win_invalidate(w); return; }

    if (ev->code == 0x1C || ev->ch == ' ') {              /* Enter / Space */
        if (!chk_human_turn(d)) return;
        int piece = d->g.board[d->kr][d->kc];
        int sr, sc;
        chk_effective_sel(d, &sr, &sc);

        if (sr >= 0 && (d->kr != sr || d->kc != sc)) {
            for (int i = 0; i < d->g.nlegal; i++) {
                const chk_move_t *mv = &d->g.legal[i];
                if (mv->from_r == sr && mv->from_c == sc &&
                    mv->to_r == d->kr && mv->to_c == d->kc) {
                    chk_try_move(d, sr, sc, d->kr, d->kc);
                    win_invalidate(w);
                    return;
                }
            }
        }
        if (piece != CHK_EMPTY && chk_piece_side(piece) == d->g.player &&
            !(d->g.must_cont &&
              (d->kr != d->g.cont_r || d->kc != d->g.cont_c))) {
            if (!d->g.must_cont && d->kr == d->sel_r && d->kc == d->sel_c)
                d->sel_r = d->sel_c = -1;
            else { d->sel_r = d->kr; d->sel_c = d->kc; }
        }
        win_invalidate(w);
    }
}

static void chk_tick(window_t *w)
{
    checkers_t *d = (checkers_t *)w->data;

    if (d->msg_timer > 0) {
        d->msg_timer--;
        win_invalidate(w);
        return;                    /* статус показывается — ИИ подождёт */
    }

    if (d->ai_pending && !d->dlg &&
        d->g.state == CHK_STATE_PLAY && d->g.player == CHK_BLACK) {
        chk_ai_move(&d->g);        /* может занять до пары секунд (Мастер) */
        d->ai_pending = 0;
        d->sel_r = d->sel_c = -1;
    }
    win_invalidate(w);
}

static void chk_close(window_t *w)
{
    free(w->data);
}

void app_checkers_open(void)
{
    checkers_t *d = (checkers_t *)malloc(sizeof(checkers_t));
    if (!d) return;
    memset(d, 0, sizeof(*d));
    chk_init(&d->g, CHK_MODE_CLASSIC, 1, 1, 0);   /* классика, против ИИ, Игрок */
    d->g.rng = (timer_ticks() * 1664525u + 0x9E3779B9u) | 1u;
    d->sel_r = d->sel_c = -1;
    d->btn_hot = d->btn_pressed = -1;
    d->kr = CHK_BOARD - 1; d->kc = 0;

    u32 W = fb_width(), H = fb_height();
    int ww = CHK_WW, wh = CHK_WH;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    int wx = (int)W / 2 - ww / 2;
    int wy = (int)(H - TBAR_H) / 2 - wh / 2;
    if (wx < 0) wx = 0;
    if (wy < 0) wy = 0;

    window_t *w = win_create("Шашки", wx, wy, ww, wh,
                             chk_draw, chk_key, chk_mouse,
                             chk_tick, chk_close, d);
    if (!w) free(d);
}
