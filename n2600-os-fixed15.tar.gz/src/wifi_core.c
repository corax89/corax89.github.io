/* wifi_core.c — чипо-НЕЗАВИСИМЫЙ WiFi-стек N2600-OS (сессия 28).
 *
 * Переехал из ath9k_wifi.c без изменения логики: журнал, профиль
 * WIFI.CFG, сканирование (пошагово, каналы 1-14), парсинг beacon
 * (RSN/WPA IE), машина подключения (SCAN→AUTH→ASSOC→4WAY→CONNECTED),
 * WPA2-PSK (PBKDF2/PTK/EAPOL M1-M4 + group rekey), мост
 * 802.11<->Ethernet для net.c.
 *
 * Драйверы (ath9k_wifi.c, rtl8192eu.c) регистрируют wifi_hw_ops_t и
 * доставляют принятые кадры через wc_rx_frame(). ИЗМЕНЕНИЕ ПОВЕДЕНИЯ:
 * wifi_scan_start() больше НЕ очищает список найденных точек — он
 * обновляется маяками. Раньше очистка при подключении выглядела как
 * «поиск начался заново» сразу после ввода пароля (жалоба сессии 28).
 */
#include "wifi_core.h"
#include "wpa2.h"
#include "string.h"
#include "mem.h"
#include "timer.h"
#include "sync.h"
#include "kernel.h"
#include "ramfs.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);
extern int  vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* ================= конфигурация (бывший ath9k_wifi.c) ================= */

/* СЕССИЯ 33: 1 тик = 1 мс (PIT 1000 Гц; было 10 мс при 100 Гц).
 * Все тайминги ниже — в тиках, численно равны миллисекундам. */
#define WIFI_SCAN_DWELL   110       /* мс на канал (было 220 — скан вдвое быстрее) */
#define WIFI_TXBUF_SZ     2360      /* 24 hdr + LLC/SNAP 8 + 1500 + запас */
#define WIFI_NET_RXQ      8         /* кадров Ethernet в кольце к net.c */
#define WIFI_NET_RXSZ     1600
/* тайминги ассоциации (тики = мс при 1000 Гц) */
#define CONN_4WAY_TO     5000  /* 5 с на шаг рукопожатия */
#define CONN_MAX_4WAY    3     /* попыток рукопожатия */
#define CONN_AUTH_TO       600         /* 600 мс на попытку AUTH/ASSOC */
#define CONN_MAX_ATTEMPTS  3
#define CONN_SCAN_TRIES    3          /* проходов скана при поиске сети */
#define CONN_BEACON_LOST   6000       /* 6 с без маяков = связь потеряна */
/* СЕССИЯ 32 (анти-шторм): точка, которая стабильно отшивает DEAUTH'ом,
 * раньше ЗАЦИКЛИВАЛА машину подключения: полный скан (3 с) → AUTH →
 * DEAUTH → снова полный скан… до бесконечности, с сожжённым CPU.
 * Теперь: сначала 2 быстрых переподключения к ТОЙ ЖЕ точке без скана,
 * после 4 DEAUTH — FAILED (переподключение — по клику пользователя). */
#define CONN_MAX_DEAUTH    4          /* DEAUTH за сессию подключения */
#define CONN_FAST_RETRIES  2          /* из них — без пересканирования */

#define WIFI_LOG_LINES    28
#define WIFI_LOG_LINE     96

const u16 wc_channel_freq[14] = {
    2412, 2417, 2422, 2427, 2432, 2437, 2442,
    2447, 2452, 2457, 2462, 2467, 2472, 2484
};

typedef struct {
    int present, ready;
    char chip_name[40];

    /* сканирование */
    int      scanning;
    int      scan_channel;   /* индекс 0..13 */
    u32      dwell_start;
    int      pass;           /* 1 = основной, 2 = повтор драйвера */
    wifi_ap_t aps[WIFI_MAX_APS];
    int      ap_count;
    wifi_stats_t stats;

    /* ---- подключение ---- */
    wifi_conn_state_t conn;
    char     conn_ssid[33];
    u8       conn_bssid[6];
    int      conn_channel;   /* индекс 0..13 */
    u16      conn_aid;
    int      conn_attempts;
    int      conn_scans;
    u32      conn_timer;
    u32      beacon_last;
    int      conn_rssi;
    char     conn_fail_reason[48];
    /* СЕССИЯ 32: параметры выбранной точки для ASSOC REQ (рейты —
     * ровно как в маяке; capability — для короткой преамбулы) */
    u16      conn_capab;
    u8       conn_rates[12];
    u8       conn_rates_len;
    int      conn_retries;   /* DEAUTH-переподключения за сессию */
    u32      last_scan_end;  /* тик завершения последнего полного скана */
    /* ротация BSSID: одноимённые SSID бывают на нескольких точках;
 * если одна стабильно отказывает — следующая попытка берёт другую */
    u8       tried_bssid[4][6];
    int      tried_n;
    char     tried_ssid[33];

    /* ---- WPA2-PSK ---- */
    u8       sec;            /* WIFI_SEC_* целевой сети */
    char     psk[65];        /* "" = открытая сеть */
    int      fw_phase;       /* 0 = ждём M1, 1 = ждём M3 */
    u32      fw_timer;
    int      fw_attempts;
    u8       anonce[32];
    u8       snonce[32];
    u8       replay[8];
    u8       pmk[32];
    char     pmk_ssid[33];
    char     pmk_psk[65];
    int      pmk_valid;
    u8       ptk[48];        /* KCK16+KEK16+TK16 после M1 */
    u8       gtk[32];
    int      gtk_is_tkip;
    int      gtk_keyid;
    int      keys_installed;
    u8       ap_group_tkip;
    u32      rng_state;

    u8       mac[6];
    u16      tx_seq;
    volatile int tx_lock;

    /* ---- мост 802.11 -> Ethernet (к net.c) ---- */
    u8           netrx[WIFI_NET_RXQ][WIFI_NET_RXSZ];
    u16          netrx_len[WIFI_NET_RXQ];
    int          netrx_head, netrx_tail;
    volatile int rx_lock;

    const wifi_hw_ops_t *ops;
} wifi_core_t;

static wifi_core_t wc;

/* ================= журнал (виден в приложении WiFi и dmesg) ================= */

static char    g_wlog[WIFI_LOG_LINES][WIFI_LOG_LINE];
static volatile int g_wlog_head = 0;
static volatile int g_wlog_count = 0;

void wifi_log(const char *fmt, ...) {
    char line[WIFI_LOG_LINE];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    __builtin_va_end(ap);

    int idx = g_wlog_head;
    u32 L = (u32)strlen(line);
    if (L >= WIFI_LOG_LINE) L = WIFI_LOG_LINE - 1;
    memcpy(g_wlog[idx], line, L);
    g_wlog[idx][L] = 0;
    g_wlog_head = (idx + 1) % WIFI_LOG_LINES;
    if (g_wlog_count < WIFI_LOG_LINES) g_wlog_count++;

    serial_puts("[wifi] ");
    serial_puts(g_wlog[(g_wlog_head + WIFI_LOG_LINES - 1) % WIFI_LOG_LINES]);
    serial_puts("\n");
    char kline[WIFI_LOG_LINE + 8];
    strcpy(kline, "[wifi] ");
    {
        char *d = kline + 7;
        const char *s = g_wlog[(g_wlog_head + WIFI_LOG_LINES - 1) % WIFI_LOG_LINES];
        while (*s) *d++ = *s++;
        *d = 0;
    }
    klog_puts(kline);
}

int wifi_log_tail(char *buf, int buf_sz, int n_lines) {
    if (!buf || buf_sz <= 0) return 0;
    int pos = 0;
    int total = g_wlog_count;
    if (n_lines <= 0 || n_lines > total) n_lines = total;
    for (int i = total - n_lines; i < total; i++) {
        int idx = (g_wlog_head + WIFI_LOG_LINES - total + i) % WIFI_LOG_LINES;
        const char *s = g_wlog[idx];
        while (*s && pos < buf_sz - 2) buf[pos++] = *s++;
        if (pos < buf_sz - 1) buf[pos++] = '\n';
    }
    if (pos < buf_sz) buf[pos] = 0; else buf[buf_sz - 1] = 0;
    return pos;
}

int wifi_log_count(void) { return g_wlog_count; }

/* ================= MAC (драйвер <- efuse/EEPROM) ================= */

void wc_set_mac(const u8 mac[6]) { memcpy(wc.mac, mac, 6); }
void wc_get_mac(u8 out[6])       { memcpy(out, wc.mac, 6); }

void wc_set_chip_name(const char *name) {
    strncpy(wc.chip_name, name ? name : "?", sizeof(wc.chip_name) - 1);
    wc.chip_name[sizeof(wc.chip_name) - 1] = 0;
}

void wc_set_state(int present, int ready) {
    wc.present = present;
    wc.ready = ready;
}

/* ================= профиль автоподключения (RAM disk WIFI.CFG) ================= */

#define WIFI_CFG_FILE "WIFI.CFG"

static int wifi_cfg_get(const char *buf, const char *key, char *out, int max)
{
    u32 klen = (u32)strlen(key);
    const char *p = buf;
    while (*p) {
        if (memcmp(p, key, klen) == 0) {
            p += klen;
            int L = 0;
            while (*p && *p != '\n' && *p != '\r' && L < max - 1)
                out[L++] = *p++;
            out[L] = 0;
            return L > 0;
        }
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    return 0;
}

int wifi_profile_load(char *out_ssid, int max) {
    out_ssid[0] = 0;
    if (!ramfs_ready()) return 0;
    char buf[192];
    u32 n = ramfs_read(WIFI_CFG_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    return wifi_cfg_get(buf, "ssid=", out_ssid, max > 33 ? 33 : max);
}

int wifi_profile_load_psk(char *out_psk, int max) {
    out_psk[0] = 0;
    if (!ramfs_ready()) return 0;
    char buf[192];
    u32 n = ramfs_read(WIFI_CFG_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    return wifi_cfg_get(buf, "psk=", out_psk, max > 65 ? 65 : max);
}

void wifi_profile_save(const char *ssid) {
    if (!ramfs_ready()) return;
    if (!ssid || !ssid[0]) {
        ramfs_delete(WIFI_CFG_FILE);
        return;
    }
    char buf[128];
    int L;
    if (wc.psk[0] && wc.sec == WIFI_SEC_WPA2_PSK)
        L = snprintf(buf, sizeof(buf), "ssid=%s\npsk=%s\n", ssid, wc.psk);
    else
        L = snprintf(buf, sizeof(buf), "ssid=%s\n", ssid);
    ramfs_delete(WIFI_CFG_FILE);
    if (ramfs_create(WIFI_CFG_FILE, (u32)L + 1))
        ramfs_write(WIFI_CFG_FILE, buf, (u32)L + 1);
}

/* ================= парсинг beacon ================= */

/* 802.11 beacon: FC(2) Dur(2) DA(6) SA(6) BSSID(6) Seq(2) |
 * TS(8) Interval(2) Cap(2) | tags. RSSI — от драйвера. */
static void parse_beacon(const u8 *data, int len, i8 rssi) {
    if (len < 38) return;                       /* заголовок + хоть один тег */
    if ((data[0] & 0xFC) != 0x80) return;       /* не beacon */
    const u8 *bssid = data + 16;

    u16 interval = (u16)(data[32] | (data[33] << 8));
    u16 capability = (u16)(data[34] | (data[35] << 8));

    char ssid[33];
    memset(ssid, 0, sizeof(ssid));
    u8 channel = 0;
    u8 sec = WIFI_SEC_OTHER;   /* tmp: не встретили RSN/WPA — по capability */
    u8 group_tkip = 0;         /* групповой шифр точки = TKIP */
    u8 rates[12];              /* Supported + Ext Supported из маяка */
    u8 rates_len = 0;
    const char *rsn_reject = NULL;
    int pos = 36;
    int guard = 0;
    while (pos + 2 <= len && guard++ < 64) {
        u8 tag = data[pos], tlen = data[pos + 1];
        pos += 2;
        if (pos + tlen > len) break;
        if (tag == 0) {
            int sl = tlen;
            if (sl > 32) sl = 32;
            memcpy(ssid, data + pos, sl);
            ssid[sl] = 0;
        } else if (tag == 1 && tlen >= 1) {
            /* СЕССИЯ 32: IE Supported Rates — запоминаем РОВНО как
             * рекламирует точка (старший бит = её basic-рейт) */
            for (u8 k = 0; k < tlen && rates_len < 12; k++)
                rates[rates_len++] = data[pos + k];
        } else if (tag == 50 && tlen >= 1) {
            /* IE Extended Supported Rates — дописываем в хвост */
            for (u8 k = 0; k < tlen && rates_len < 12; k++)
                rates[rates_len++] = data[pos + k];
        } else if (tag == 3 && tlen >= 1) {
            channel = data[pos];
        } else if (tag == 48 && tlen >= 2) {
            /* RSN IE — WPA2. Поддерживаем: pairwise CCMP, AKM PSK.
             * ГРУППОВОЙ шифр ЛЮБОЙ (смешанный режим TKIP+AES). */
            const u8 *p = data + pos;
            u32 L = tlen, off = 2;
            int ok_ver = (p[0] == 1 && p[1] == 0);
            int pairwise_ccmp = 0, akm_psk = 0;
            int any_akm = 0, any_pair = 0;
            if (off + 4 <= L) {
                group_tkip = (memcmp(p + off, "\x00\x0F\xAC\x02", 4) == 0);
                off += 4;
            }
            if (off + 2 <= L) {
                u32 pcnt = (u32)p[off] | ((u32)p[off + 1] << 8);
                off += 2;
                for (u32 k = 0; k < pcnt && off + 4 <= L; k++, off += 4) {
                    any_pair = 1;
                    if (memcmp(p + off, "\x00\x0F\xAC\x04", 4) == 0)
                        pairwise_ccmp = 1;
                }
            }
            if (off + 2 <= L) {
                u32 acnt = (u32)p[off] | ((u32)p[off + 1] << 8);
                off += 2;
                for (u32 k = 0; k < acnt && off + 4 <= L; k++, off += 4) {
                    any_akm = 1;
                    if (memcmp(p + off, "\x00\x0F\xAC\x02", 4) == 0)
                        akm_psk = 1;
                }
            }
            if (ok_ver && pairwise_ccmp && akm_psk)
                sec = WIFI_SEC_WPA2_PSK;
            else if (ok_ver) {
                sec = WIFI_SEC_OTHER;         /* Enterprise/SAE/TKIP-only */
                if (!pairwise_ccmp && any_pair)
                    rsn_reject = "pairwise без CCMP";
                else if (!akm_psk && any_akm)
                    rsn_reject = "AKM без PSK (Enterprise/SAE?)";
                else if (!any_pair || !any_akm)
                    rsn_reject = "короткий RSN IE";
                else
                    rsn_reject = "версия RSN != 1";
            }
        } else if (tag == 221 && tlen >= 8 &&
                   memcmp(data + pos, "\x00\x50\xF2\x01\x01\x00", 6) == 0) {
            /* WPA IE (Microsoft OUI 00:50:F2, тип 01, версия 01:00) */
            const u8 *p = data + pos + 6;
            u32 left = tlen - 6;
            int pairwise_ccmp = 0, akm_psk = 0;
            if (left >= 4) {
                group_tkip = (memcmp(p, "\x00\x50\xF2\x02", 4) == 0);
                p += 4; left -= 4;
            }
            if (left >= 2) {
                u32 pcnt = (u32)p[0] | ((u32)p[1] << 8);
                p += 2;
                for (u32 k = 0; k < pcnt && left >= 6; k++, p += 4, left -= 4)
                    if (memcmp(p, "\x00\x50\xF2\x04", 4) == 0)
                        pairwise_ccmp = 1;
            }
            if (left >= 2) {
                u32 acnt = (u32)p[0] | ((u32)p[1] << 8);
                p += 2;
                for (u32 k = 0; k < acnt && left >= 6; k++, p += 4, left -= 4)
                    if (memcmp(p, "\x00\x50\xF2\x02", 4) == 0)
                        akm_psk = 1;
            }
            if (pairwise_ccmp && akm_psk)
                sec = WIFI_SEC_WPA2_PSK;      /* WPA с CCMP — как WPA2 */
            else if (sec == WIFI_SEC_OTHER)
                sec = WIFI_SEC_WPA_PSK;       /* TKIP-only — не поддержано */
        }
        pos += tlen;
    }
    if (ssid[0] == 0) return;                   /* hidden SSID */

    if (channel == 0) channel = (u8)(wc.scan_channel + 1);
    if (channel < 1 || channel > 14) channel = 1;

    /* уже видели эту точку? — обновляем RSSI/канал/защиту */
    for (int i = 0; i < wc.ap_count; i++) {
        if (memcmp(wc.aps[i].bssid, bssid, 6) == 0) {
            if (rssi > wc.aps[i].rssi) wc.aps[i].rssi = rssi;
            if (channel) wc.aps[i].channel = channel;
            u8 encrypted = (capability & 0x0010) ? 1 : 0;
            wc.aps[i].sec = encrypted ? (u8)sec : (u8)WIFI_SEC_OPEN;
            wc.aps[i].group_tkip = group_tkip;
            if (wc.aps[i].rates_len == 0 && rates_len > 0) {
                memcpy(wc.aps[i].rates, rates, rates_len);
                wc.aps[i].rates_len = rates_len;
            }
            return;
        }
    }
    if (wc.ap_count < WIFI_MAX_APS) {
        wifi_ap_t *ap = &wc.aps[wc.ap_count++];
        memset(ap, 0, sizeof(*ap));
        strncpy(ap->ssid, ssid, 32);
        memcpy(ap->bssid, bssid, 6);
        ap->rssi = rssi;
        ap->channel = channel;
        ap->beacon_interval = (u8)(interval / 10);
        ap->capability = capability;
        ap->encrypted = (capability & 0x0010) ? 1 : 0;
        if (!ap->encrypted)
            sec = WIFI_SEC_OPEN;
        ap->sec = (u8)sec;
        ap->group_tkip = group_tkip;
        if (rates_len > 0) {
            memcpy(ap->rates, rates, rates_len);
            ap->rates_len = rates_len;
        }
        wc.stats.aps = (u32)wc.ap_count;
        static const char *secname[4] = { "открытая", "WPA2", "WPA", "WEP/др" };
        wifi_log("ch %d: новая сеть \"%s\" RSSI %d dBm [%s%s]",
                 channel, ssid, (int)rssi, secname[sec],
                 (sec == WIFI_SEC_WPA2_PSK && group_tkip)
                     ? ", группа TKIP" : "");
        if (rsn_reject && ap->encrypted)
            wifi_log("  RSN сети \"%s\" не поддержан: %s", ssid, rsn_reject);
    }
}

/* ==== ТЕСТОВЫЙ ДОСТУП (харнесс rtlwifi компилирует этот файл) ==== */
#ifdef WIFI_CORE_TEST
wifi_stats_t *wc_test_stats(void) { return &wc.stats; }
int wc_test_ap_count(void) { return wc.ap_count; }
const wifi_ap_t *wc_test_ap(int i) { return &wc.aps[i]; }
wifi_conn_state_t wc_test_conn(void) { return wc.conn; }
const char *wc_test_conn_fail(void) { return wc.conn_fail_reason; }
const char *wc_test_ssid(void) { return wc.conn_ssid; }
int wc_test_keys_installed(void) { return wc.keys_installed; }
void wc_test_set_ready(void) { wc.present = 1; wc.ready = 1; wc.scan_channel = -1; }
#endif

/* ================= RX: приём кадров от драйвера ================= */

static void conn_handle_mgmt(const u8 *frame, u32 len);
static void bridge_rx_to_net(const u8 *frame, u32 len);
static void wpa2_rx_eapol(const u8 *eth_payload, u32 len);

void wc_rx_err(int crc) {
    if (crc) {
        wc.stats.crc_err++;
        if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
            wc.stats.chan_crc[wc.scan_channel]++;
    } else {
        wc.stats.other++;
    }
}

void wc_rx_frame(const u8 *frame, int len, i8 rssi) {
    wc.stats.frames++;
    if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
        wc.stats.chan_frames[wc.scan_channel]++;
    if (len < 2) return;
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if ((fc & 0xFC) == 0x80) {            /* beacon */
        wc.stats.beacons++;
        if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
            wc.stats.chan_beacons[wc.scan_channel]++;
        parse_beacon(frame, len, rssi);
        /* маяк нашей точки: живём (контроль потери связи) */
        if (wc.conn == WIFI_CONN_CONNECTED && len >= 22 &&
            memcmp(frame + 16, wc.conn_bssid, 6) == 0) {
            wc.beacon_last = timer_ticks();
            wc.conn_rssi = rssi;
        }
        return;
    }
    /* кадры ассоциации и данные нашей точки */
    if (wc.conn == WIFI_CONN_OFF || wc.conn == WIFI_CONN_FAILED)
        return;
    u8 type = (u8)((fc >> 2) & 0x3);
    if (type == 0)
        conn_handle_mgmt(frame, (u32)len);        /* mgmt: AUTH/ASSOC/DEAUTH */
    else if (type == 2 && (wc.conn == WIFI_CONN_CONNECTED ||
                           wc.conn == WIFI_CONN_4WAY))
        /* data: в стек (после подключения) и EAPOL рукопожатию (в 4WAY) */
        bridge_rx_to_net(frame, (u32)len);
}

/* ================= TX: построители кадров 802.11 =================
 * Драйвер получает готовый кадр через ops->tx_frame (рейт логический). */

/* Общий заголовок mgmt: FC(2) Dur(2) addr1=DA addr2=SA addr3=BSSID Seq(2) */
static void put_mgmt_hdr(u8 *f, u16 fc, const u8 *da, u32 *pos) {
    f[0] = (u8)(fc & 0xFF);
    f[1] = (u8)(fc >> 8);
    f[2] = 0x3A; f[3] = 0x00;                 /* duration 58 мкс */
    memcpy(f + 4, da, 6);
    memcpy(f + 10, wc.mac, 6);
    memcpy(f + 16, wc.conn_bssid, 6);
    f[22] = (u8)(wc.tx_seq << 4);
    f[23] = (u8)(wc.tx_seq >> 4);
    wc.tx_seq = (u16)((wc.tx_seq + 1) & 0xFFF);
    *pos = 24;
}

static int tx_mgmt_frame(u16 fc, const u8 *body, u32 body_len) {
    u8 f[128];
    u32 pos = 0;
    u8 da[6];
    memcpy(da, wc.conn_bssid, 6);
    put_mgmt_hdr(f, fc, da, &pos);
    if (pos + body_len > sizeof(f)) return 0;
    memcpy(f + pos, body, body_len);
    pos += body_len;
    return wc.ops->tx_frame(f, pos, WCRATE_1M, 7, 0, -1);
}

/* Authentication Request (открытая система): algo=0, seq=1, status=0 */
static int tx_auth_req(void) {
    u8 body[6] = { 0, 0, 1, 0, 0, 0 };
    return tx_mgmt_frame(0x00B0, body, 6);
}

/* Association Request: listen=3, IE: SSID + rates.
 * СЕССИЯ 32: capability зеркалим по точке (ESS всегда, Short Preamble —
 * если точка сама его рекламирует: строгие точки отказывают в ассоциации
 * без него). Рейты — РОВНО набор точки из маяка (с её basic-битами):
 * отказ со статусом 18 = «STA не поддерживает все BSSBasicRateSet» —
 * раньше мы хардкодили 1/2/5.5/11 basic + 6..54, и точка с другим
 * набором базовых рейтов (например g-only с basic 6/12/24) отшивала
 * ассоциацию, хотя нужные рейты мы «рекламировали» без basic-бита. */
static int tx_assoc_req(const char *ssid) {
    u8 f[128];
    u32 pos = 0;
    put_mgmt_hdr(f, 0x0000, wc.conn_bssid, &pos);
    u16 cap = 0x0001;                          /* ESS */
    if (wc.conn_capab & 0x0020) cap |= 0x0020; /* Short Preamble как у точки */
    f[pos++] = (u8)(cap & 0xFF);
    f[pos++] = (u8)(cap >> 8);
    f[pos++] = 3;   f[pos++] = 0x00;           /* listen interval (как у реальных клиентов) */
    /* IE 0: SSID */
    u32 sl = (u32)strlen(ssid);
    if (sl > 32) sl = 32;
    f[pos++] = 0;
    f[pos++] = (u8)sl;
    memcpy(f + pos, ssid, sl); pos += sl;
    /* IE 1 + IE 50: рейты. Известен набор точки — предлагаем его
     * 1:1 (как wpa_supplicant); нет — полный b+g fallback. */
    if (wc.conn_rates_len > 0) {
        u32 n1 = wc.conn_rates_len > 8 ? 8 : wc.conn_rates_len;
        f[pos++] = 1; f[pos++] = (u8)n1;
        memcpy(f + pos, wc.conn_rates, n1); pos += n1;
        if (wc.conn_rates_len > n1) {
            u32 n2 = wc.conn_rates_len - n1;
            f[pos++] = 50; f[pos++] = (u8)n2;
            memcpy(f + pos, wc.conn_rates + n1, n2); pos += n2;
        }
    } else {
        /* IE 1: Supported rates (1,2,5.5,11 — basic) */
        f[pos++] = 1; f[pos++] = 4;
        f[pos++] = 0x82; f[pos++] = 0x84; f[pos++] = 0x8B; f[pos++] = 0x96;
        /* IE 50: Extended rates (6..54) */
        static const u8 ext[] = { 0x0C, 0x12, 0x18, 0x24, 0x30, 0x48, 0x60, 0x6C };
        f[pos++] = 50; f[pos++] = sizeof(ext);
        memcpy(f + pos, ext, sizeof(ext)); pos += sizeof(ext);
    }
    /* RSN IE для WPA2-сетей (CCMP + PSK) — без него точка отклонит
     * ассоциацию или не начнёт рукопожатие */
    if (wc.sec == WIFI_SEC_WPA2_PSK)
        pos += wpa2_build_rsn_ie(f + pos, wc.ap_group_tkip);
    return wc.ops->tx_frame(f, pos, WCRATE_1M, 7, 0, -1);
}

/* Deauthentication (reason 3 = STATION LEAVING) */
static int tx_deauth(void) {
    u8 body[2] = { 3, 0 };
    return tx_mgmt_frame(0x00C0, body, 2);
}

/* ---- Ethernet -> 802.11 (TX данных) ----
 * Кадр: data+ToDS, addr1=BSSID addr2=наш MAC addr3=eth.dst, LLC/SNAP. */
int wifi_net_send(const void *eth_frame, u32 len) {
    if (!wc.ops || wc.conn != WIFI_CONN_CONNECTED || !wc.ready)
        return -1;
    if (len < 14 || len > 1518) return -1;
    const u8 *eth = (const u8 *)eth_frame;

    s_lock(&wc.tx_lock);
    static u8 f[WIFI_TXBUF_SZ];
    u32 pos = 0;
    f[0] = 0x08; f[1] = 0x01;                 /* data, ToDS */
    /* WPA2: бит Protected (FC.14) — данные уходят шифрованными;
     * железо строит CCMP/TKIP-заголовок и шифрует по ключу. */
    int fc_protected = (wc.keys_installed != 0);
    if (fc_protected)
        f[1] = 0x01 | 0x40;                   /* ToDS + Protected */
    f[2] = 0x3A; f[3] = 0x00;                 /* duration */
    memcpy(f + 4, wc.conn_bssid, 6);          /* addr1 = BSSID */
    memcpy(f + 10, wc.mac, 6);                /* addr2 = мы */
    memcpy(f + 16, eth, 6);                   /* addr3 = dst MAC */
    f[22] = (u8)(wc.tx_seq << 4);
    f[23] = (u8)(wc.tx_seq >> 4);
    wc.tx_seq = (u16)((wc.tx_seq + 1) & 0xFFF);
    pos = 24;
    f[pos++] = 0xAA; f[pos++] = 0xAA; f[pos++] = 0x03;   /* LLC/SNAP */
    f[pos++] = 0x00; f[pos++] = 0x00; f[pos++] = 0x00;
    memcpy(f + pos, eth + 12, len - 12);      /* ethertype + payload */
    pos += len - 12;

    /* broadcast/multicast — без ACK, basic-рейт */
    int noack = (eth[0] & 1) != 0;
    wc_rate_t rate = noack ? WCRATE_2M : WCRATE_11M;
    int tries = noack ? 3 : 4;
    /* EAPOL сюда не попадает — у него свой путь (wpa2_tx_eapol_eth) */
    int keyidx = -1;
    if (wc.keys_installed && fc_protected)
        keyidx = noack ? wc.gtk_keyid : 4;    /* 4 = запись PTK (общая
                                                 * конвенция обоих драйверов) */
    int r = wc.ops->tx_frame(f, pos, rate, tries, noack, keyidx) ? (int)len : 0;
    s_unlock(&wc.tx_lock);
    return r;
}

/* ---- 802.11 -> Ethernet (RX данных) ----
 * От точки (FromDS): addr1=DA, addr2=BSSID, addr3=SA; после заголовка
 * LLC/SNAP. Складывается в кольцо к net.c (забирает wifi_net_recv).
 * tail_cut — байт шифрхвоста (MIC/ICV), hdr_iv_skip — пропустить
 * CCMP/TKIP-заголовок после 802.11-заголовка. */
static void bridge_rx_to_net_ex(const u8 *frame, u32 len,
                                u32 hdr_iv_skip, u32 tail_cut) {
    if (len < 30) return;                     /* 24 hdr + LLC 6 + ethertype 2 */
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if ((fc & 0x0C) != 0x08) return;          /* не data */
    if (!(fc & 0x0200)) return;               /* не FromDS */
    u8 subtype = (u8)((fc >> 4) & 0xF);
    u32 hdr = (subtype & 0x8) ? 26 : 24;      /* QoS-data: +2 байта */
    if (len < hdr + 8) return;
    if (memcmp(frame + 4, wc.mac, 6) != 0 &&
        (frame[4] & 1) == 0)
        return;                               /* не нам и не mcast */
    u32 plen = len;
    if (hdr_iv_skip) hdr += hdr_iv_skip;      /* CCMP/TKIP-заголовок */
    if (tail_cut && plen > tail_cut) plen -= tail_cut;  /* MIC/ICV в хвосте */
    if (plen < hdr + 8) return;
    if (memcmp(frame + hdr, "\xAA\xAA\x03\x00\x00\x00", 6) != 0)
        return;                               /* не LLC/SNAP */

    /* EAPOL (0x888E) — в обработчик рукопожатия WPA2, не в сетевой стек */
    u16 ethertype = (u16)((frame[hdr + 6] << 8) | frame[hdr + 7]);
    if (ethertype == 0x888E) {
        wpa2_rx_eapol(frame + hdr + 6, plen - hdr - 6);
        return;
    }
    if (wc.conn != WIFI_CONN_CONNECTED) return;   /* мост только после 4-way */

    u32 eth_len = 14 + (plen - hdr - 8);
    if (eth_len > WIFI_NET_RXSZ) return;
    int nxt = (wc.netrx_head + 1) % WIFI_NET_RXQ;
    if (nxt == wc.netrx_tail) return;         /* кольцо полно — теряем кадр */
    s_lock(&wc.rx_lock);
    u8 *dst = wc.netrx[wc.netrx_head];
    memcpy(dst, frame + 4, 6);                /* dst MAC = addr1 (DA) */
    memcpy(dst + 6, frame + 16, 6);           /* src MAC = addr3 (SA) */
    memcpy(dst + 12, frame + hdr + 6, plen - hdr - 6);
    wc.netrx_len[wc.netrx_head] = (u16)eth_len;
    wc.netrx_head = nxt;
    s_unlock(&wc.rx_lock);
}

/* защищённый кадр: железо расшифровало, но IV (8 б после hdr) и
 * хвост (MIC 8 + для TKIP ещё ICV 4) остались в буфере */
static void bridge_rx_to_net(const u8 *frame, u32 len) {
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if (fc & 0x4000) {                        /* Protected */
        /* TKIP: +4 ICV; определяем по факту — GTK TKIP установлен */
        u32 tail = (wc.keys_installed && wc.gtk_is_tkip) ? 12 : 8;
        bridge_rx_to_net_ex(frame, len, 8, tail);
    } else {
        bridge_rx_to_net_ex(frame, len, 0, 0);
    }
}

u32 wifi_net_recv(void *buf, u32 max) {
    if (wc.netrx_tail == wc.netrx_head) return 0;
    s_lock(&wc.rx_lock);
    u32 n = wc.netrx_len[wc.netrx_tail];
    if (n > max) n = max;
    memcpy(buf, wc.netrx[wc.netrx_tail], n);
    wc.netrx_tail = (wc.netrx_tail + 1) % WIFI_NET_RXQ;
    s_unlock(&wc.rx_lock);
    return n;
}

void wifi_net_get_mac(u8 out_mac[6]) { memcpy(out_mac, wc.mac, 6); }
int  wifi_net_link(void) { return wc.ops && wc.conn == WIFI_CONN_CONNECTED; }

/* ================= публичный API скана/статуса ================= */

void wifi_scan_start(void) {
    if (!wc.present || !wc.ready || !wc.ops) return;
    if (wc.scanning) return;
    memset(&wc.stats, 0, sizeof(wc.stats));
    /* СЕССИЯ 28: список точек СОХРАНЯЕТСЯ между сканами — он
     * обновляется маяками. Очистка при подключении выглядела как
     * «поиск начался заново» сразу после Enter в поле пароля. */
    wc.scanning = 1;
    wc.scan_channel = 0;
    wc.dwell_start = timer_ticks();
    wifi_log("скан: старт (каналы 1-14, %d мс/канал)", WIFI_SCAN_DWELL);
    if (!wc.ops->set_channel(0))
        wifi_log("скан: смена канала не удалась");
}

int  wifi_present(void)    { return wc.present; }
int  wifi_ready(void)      { return wc.ready; }
const char *wifi_chip_name(void) { return wc.chip_name; }
int  wifi_scan_active(void) { return wc.scanning; }

int wifi_scan_results(wifi_ap_t *out, int max) {
    s_lock(&wc.rx_lock);
    int n = wc.ap_count;
    if (n > max) n = max;
    memcpy(out, wc.aps, (u32)n * sizeof(wifi_ap_t));
    s_unlock(&wc.rx_lock);
    return n;
}

void wifi_get_stats(wifi_stats_t *out) {
    if (!out) return;
    s_lock(&wc.rx_lock);
    wc.stats.channel = wc.scanning ? wc.scan_channel + 1 : 0;
    wc.stats.pass = wc.pass;
    *out = wc.stats;
    s_unlock(&wc.rx_lock);
}

/* ================= WPA2-PSK: рукопожатие и ключи ================= */

/* Генератор для SNonce: xorshift32, засеянный таймером + MAC. */
static void wpa2_rng_seed(void)
{
    wc.rng_state ^= timer_ticks() * 2654435761u;
    for (int i = 0; i < 6; i++)
        wc.rng_state = (wc.rng_state << 8) | wc.mac[i];
    wc.rng_state ^= ((u32)wc.conn_aid << 16) ^ (u32)wc.tx_seq;
    if (!wc.rng_state) wc.rng_state = 0x9E3779B9u;
}

static u32 wpa2_rng_next(void)
{
    u32 x = wc.rng_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    wc.rng_state = x;
    return x;
}

/* PMK для текущего ssid+psk (с кэшем — PBKDF2 4096 итераций). */
static int wpa2_ensure_pmk(void)
{
    if (wc.pmk_valid &&
        strcmp(wc.pmk_ssid, wc.conn_ssid) == 0 &&
        strcmp(wc.pmk_psk, wc.psk) == 0)
        return 1;
    u32 t0 = timer_ticks();
    wpa2_pbkdf2_sha1((const u8 *)wc.psk, (u32)strlen(wc.psk),
                     (const u8 *)wc.conn_ssid, (u32)strlen(wc.conn_ssid),
                     4096, wc.pmk, 32);
    strncpy(wc.pmk_ssid, wc.conn_ssid, sizeof(wc.pmk_ssid) - 1);
    wc.pmk_ssid[sizeof(wc.pmk_ssid) - 1] = 0;
    strncpy(wc.pmk_psk, wc.psk, sizeof(wc.pmk_psk) - 1);
    wc.pmk_psk[sizeof(wc.pmk_psk) - 1] = 0;
    wc.pmk_valid = 1;
    wifi_log("PMK посчитан (%u мс)", (unsigned)(timer_ticks() - t0));
    return 1;
}

static void wpa2_install_keys(void)
{
    if (!wc.ops->keys_install) return;
    if (wc.ops->keys_install(wc.conn_bssid, wc.ptk, wc.gtk,
                             wc.gtk_is_tkip, wc.gtk_keyid)) {
        wc.keys_installed = 1;
        wifi_log("ключи установлены: PTK + GTK(keyid=%d%s)",
                 wc.gtk_keyid, wc.gtk_is_tkip ? ", TKIP" : "");
    } else {
        wifi_log("ключи НЕ установлены (ошибка железа)");
    }
}

static void wpa2_clear_keys(void)
{
    if (wc.ops && wc.ops->keys_clear) wc.ops->keys_clear();
    wc.keys_installed = 0;
}

/* Отправка EAPOL-кадра точке (ВСЕГДА без шифрования — Protected=0:
 * даже после установки ключей рукопожатие идёт открыто, шифруется
 * только key data). eth = [dst=AP][src=мы][888E]. */
static int wpa2_tx_eapol_eth(const u8 *eth, u32 eth_len)
{
    if (eth_len > 1518) return 0;
    static u8 f[WIFI_TXBUF_SZ];
    u32 pos = 0;
    f[0] = 0x08; f[1] = 0x01;                 /* data, ToDS, НЕ Protected */
    f[2] = 0x3A; f[3] = 0x00;
    memcpy(f + 4, wc.conn_bssid, 6);          /* addr1 = BSSID */
    memcpy(f + 10, wc.mac, 6);                /* addr2 = мы */
    memcpy(f + 16, eth, 6);                   /* addr3 = DA (точка) */
    f[22] = (u8)(wc.tx_seq << 4);
    f[23] = (u8)(wc.tx_seq >> 4);
    wc.tx_seq = (u16)((wc.tx_seq + 1) & 0xFFF);
    pos = 24;
    f[pos++] = 0xAA; f[pos++] = 0xAA; f[pos++] = 0x03;
    f[pos++] = 0x00; f[pos++] = 0x00; f[pos++] = 0x00;
    memcpy(f + pos, eth + 12, eth_len - 12);  /* ethertype + тело */
    pos += eth_len - 12;
    return wc.ops->tx_frame(f, pos, WCRATE_11M, 4, 0, -1);
}

/* Обработать входящий EAPOL-Key (вызывается из bridge_rx_to_net).
 * eth указывает на LLC-payload: [ethertype 888E][EAPOL...].
 * Робастность (сессия 15): версия 2/3, ретрансмиссия M1, групповой
 * rekey в CONNECTED. */
static void wpa2_rx_eapol(const u8 *eth_payload, u32 len)
{
    if (wc.conn != WIFI_CONN_4WAY && wc.conn != WIFI_CONN_CONNECTED) return;
    /* len = [ethertype 888E 2 б][EAPOL hdr 4 б][Key-дескриптор >= 95 б];
     * раньше сравнивали с 14+4+95+2 (как ПОЛНЫЙ eth-кадр) — минимальный
     * M1 (99 б EAPOL-Key без key data) отбрасывался как «короткий» */
    if (len < 2 + 4 + 95) return;             /* короткий EAPOL-Key */

    static u8 eb[WIFI_NET_RXSZ];
    if (len + 14 > sizeof(eb)) return;
    memset(eb, 0, 14);
    memcpy(eb + 12, eth_payload, len);        /* 888E + тело */

    eapol_key_t k;
    if (!wpa2_parse_eapol_key(eb, len + 14, &k)) return;

    u16 ki = k.key_info;
    /* ver 2 = AES (CCMP), ver 3 = AES-128-CMAC (PMF-capable точки;
    * AKM тот же PSK-SHA1 — обрабатываем как ver 2) */
    int ver_ok = ((ki & WPA2_KI_VER_MASK) == WPA2_KI_VER_AES) ||
                 ((ki & WPA2_KI_VER_MASK) == 3);
    int pairwise = (ki & WPA2_KI_KEY_TYPE) != 0;
    int has_mic  = (ki & WPA2_KI_MIC) != 0;
    int has_ack  = (ki & WPA2_KI_ACK) != 0;

    /* ---- ГРУППОВОЕ рукопожатие (rekey GTK) в CONNECTED ---- */
    if (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed &&
        !pairwise && has_ack && has_mic && (ki & WPA2_KI_ENCR_DATA) &&
        ver_ok) {
        static u8 micbuf[WIFI_NET_RXSZ];
        u32 flen = k.frame_len;
        if (flen > sizeof(micbuf)) return;
        memcpy(micbuf, eb, flen);
        memset(micbuf + 95, 0, 16);
        u8 mic[16];
        wpa2_eapol_mic(wc.ptk, micbuf, flen, mic);
        if (memcmp(mic, k.mic, 16) != 0) {
            wifi_log("WPA2: group-M1 MIC неверный — игнор");
            return;
        }
        if (k.key_data_len < 16 || (k.key_data_len & 7)) return;
        static u8 kd[WIFI_NET_RXSZ];
        if (k.key_data_len > sizeof(kd)) return;
        if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data, k.key_data_len, kd))
            return;
        u32 kdn = k.key_data_len - 8;
        int have_gtk = 0;
        u32 off = 0;
        while (off + 2 <= kdn) {
            u8 t = kd[off], l = kd[off + 1];
            if (t == 0xDD && l >= 8 && off + 2 + 8 <= kdn &&
                memcmp(kd + off + 2, "\x00\x0F\xAC\x01", 4) == 0) {
                u8 flags = kd[off + 6];
                u32 klen = (u32)l - 6;
                /* GTK: 16 б (CCMP) или 32 б (TKIP: TK+RX MIC+TX MIC) */
                if (klen > 32) klen = 32;
                if (klen < 16) klen = 16;
                memcpy(wc.gtk, kd + off + 7, klen);
                if (klen > 16) memset(wc.gtk + klen, 0, 32 - klen);
                wc.gtk_is_tkip = (klen == 32);
                wc.gtk_keyid = flags & 3;
                have_gtk = 1;
            }
            if (t == 0xDD && l == 0) { off += 2; continue; }
            if (l == 0 && t == 0) break;
            off += 2u + l;
        }
        if (!have_gtk) {
            wifi_log("WPA2: GTK KDE не найден в group-M1");
            return;
        }
        wpa2_install_keys();
        u32 n = wpa2_build_eapol_key(eb, wc.conn_bssid, wc.mac,
                                     WPA2_KI_VER_AES | WPA2_KI_MIC |
                                     ((ki & WPA2_KI_SECURE) ? WPA2_KI_SECURE : 0),
                                     NULL, k.replay, NULL, 0);
        wpa2_eapol_mic(wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        wpa2_tx_eapol_eth(eb, n);
        wifi_log("WPA2: групповой ключ обновлён (GTK keyid=%d)", wc.gtk_keyid);
        return;
    }

    /* ---- Сообщение 1: ANonce, без MIC, с ACK ---- */
    if (wc.fw_phase == 0 && pairwise && has_ack && !has_mic && ver_ok) {
        memcpy(wc.anonce, k.nonce, 32);
        memcpy(wc.replay, k.replay, 8);

        wpa2_rng_seed();
        for (int i = 0; i < 8; i++) {
            u32 r = wpa2_rng_next();
            wc.snonce[i*4+0] = (u8)r; wc.snonce[i*4+1] = (u8)(r >> 8);
            wc.snonce[i*4+2] = (u8)(r >> 16); wc.snonce[i*4+3] = (u8)(r >> 24);
        }
        wpa2_ensure_pmk();
        wpa2_derive_ptk(wc.pmk, wc.conn_bssid, wc.mac,
                        wc.anonce, wc.snonce, wc.ptk);

        /* M2: наш RSN IE в key data, MIC */
        u8 kd[32];
        u32 kdl = wpa2_build_rsn_ie(kd, wc.ap_group_tkip);   /* 22 байта */
        u32 n = wpa2_build_eapol_key(eb, wc.conn_bssid, wc.mac,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_MIC,
                                     wc.snonce, wc.replay, kd, (u16)kdl);
        u8 mic[16];
        wpa2_eapol_mic(wc.ptk, eb, n, mic);  /* KCK = ptk[0..15] */
        wpa2_eapol_set_mic(eb, mic);
        if (!wpa2_tx_eapol_eth(eb, n)) {
            wifi_log("M2 не отправлен (TX отказ)");
            return;
        }
        wc.fw_phase = 1;                     /* ждём M3 */
        wc.fw_timer = timer_ticks();
        wifi_log("WPA2: M1 получен, M2 отправлен (PTK выведен)");
        return;
    }

    /* ---- РЕТРАНСМИССИЯ M1 (ждём M3, пришёл снова M1) ---- */
    if (wc.fw_phase == 1 && wc.conn == WIFI_CONN_4WAY &&
        pairwise && has_ack && !has_mic && ver_ok &&
        memcmp(k.nonce, wc.anonce, 32) == 0) {
        u8 kd[32];
        u32 kdl = wpa2_build_rsn_ie(kd, wc.ap_group_tkip);
        u32 n = wpa2_build_eapol_key(eb, wc.conn_bssid, wc.mac,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_MIC,
                                     wc.snonce, wc.replay, kd, (u16)kdl);
        u8 mic[16];
        wpa2_eapol_mic(wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        wpa2_tx_eapol_eth(eb, n);
        wifi_log("WPA2: повторный M1 — M2 перепослан");
        return;
    }

    /* ---- Сообщение 3: MIC + Secure + Install + зашифрованный key data ---- */
    if (wc.fw_phase == 1 && pairwise && (ki & WPA2_KI_ACK) &&
        (ki & WPA2_KI_MIC) && (ki & WPA2_KI_SECURE) &&
        (ki & WPA2_KI_ENCR_DATA) && ver_ok) {
        if (memcmp(k.replay, wc.replay, 8) != 0) {
            wifi_log("WPA2: M3 с чужим replay counter — игнор");
            return;
        }
        if (memcmp(k.nonce, wc.anonce, 32) != 0) {
            wifi_log("WPA2: ANonce в M3 != M1 — игнор");
            return;
        }
        static u8 micbuf[WIFI_NET_RXSZ];
        u32 flen = k.frame_len;
        if (flen > sizeof(micbuf)) return;
        memcpy(micbuf, eb, flen);
        memset(micbuf + 95, 0, 16);           /* MIC := 0 (смещ. в кадре) */
        u8 mic[16];
        wpa2_eapol_mic(wc.ptk, micbuf, flen, mic);
        if (memcmp(mic, k.mic, 16) != 0) {
            wifi_log("WPA2: MIC M3 неверный — пароль не подходит?");
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "WPA2: неверный MIC (пароль?)");
            wc.conn = WIFI_CONN_FAILED;
            tx_deauth();
            return;
        }

        u8 kd[WIFI_NET_RXSZ];
        if (k.key_data_len > sizeof(kd) || (k.key_data_len & 7) ||
            k.key_data_len < 16) {
            wifi_log("WPA2: key data повреждён (len=%u)", k.key_data_len);
            return;
        }
        if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data, k.key_data_len, kd)) {
            wifi_log("WPA2: unwrap key data не прошёл");
            return;
        }
        u32 kdn = k.key_data_len - 8;
        int have_gtk = 0;
        u32 off = 0;
        while (off + 2 <= kdn) {
            u8 t = kd[off], l = kd[off + 1];
            if (t == 0xDD && l >= 8 && off + 2 + 8 <= kdn &&
                memcmp(kd + off + 2, "\x00\x0F\xAC\x01", 4) == 0) {
                u8 flags = kd[off + 6];
                u32 klen = (u32)l - 6;
                if (klen > 32) klen = 32;
                if (klen < 16) klen = 16;
                memcpy(wc.gtk, kd + off + 7, klen);
                if (klen > 16) memset(wc.gtk + klen, 0, 32 - klen);
                wc.gtk_is_tkip = (klen == 32);
                wc.gtk_keyid = flags & 3;
                have_gtk = 1;
            }
            if (t == 0xDD && l == 0) { off += 2; continue; }   /* паддинг */
            if (l == 0 && t == 0) break;
            off += 2u + l;
        }
        if (!have_gtk) {
            wifi_log("WPA2: GTK KDE не найден в key data");
            return;
        }

        wpa2_install_keys();
        u32 n = wpa2_build_eapol_key(eb, wc.conn_bssid, wc.mac,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_MIC | WPA2_KI_SECURE,
                                     NULL, wc.replay, NULL, 0);
        wpa2_eapol_mic(wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        if (!wpa2_tx_eapol_eth(eb, n)) {
            wifi_log("M4 не отправлен — переповтор");
            return;
        }
        wc.conn = WIFI_CONN_CONNECTED;
        wc.beacon_last = timer_ticks();
        wifi_log("WPA2: рукопожатие завершено — \"%s\" доступна (CCMP)",
                 wc.conn_ssid);
        wifi_profile_save(wc.conn_ssid);
        return;
    }
}

/* ================= машина подключения ================= */

/* СЕССИЯ 32: ротация BSSID — одноимённый SSID бывает на нескольких
 * точках («byfly WiFi» в логе пользователя — на 6!), и если одна
 * стабильно отказывает — следующая попытка подключения берёт другую. */
static int conn_bssid_tried(const wifi_ap_t *ap) {
    if (wc.tried_n <= 0) return 0;
    if (strcmp(wc.tried_ssid, wc.conn_ssid) != 0) return 0;
    for (int k = 0; k < wc.tried_n && k < 4; k++)
        if (memcmp(wc.tried_bssid[k], ap->bssid, 6) == 0) return 1;
    return 0;
}

static void conn_remember_tried(const wifi_ap_t *ap) {
    if (strcmp(wc.tried_ssid, wc.conn_ssid) != 0) {
        strncpy(wc.tried_ssid, wc.conn_ssid, sizeof(wc.tried_ssid) - 1);
        wc.tried_ssid[sizeof(wc.tried_ssid) - 1] = 0;
        wc.tried_n = 0;
    }
    if (conn_bssid_tried(ap)) return;
    int slot = wc.tried_n < 4 ? wc.tried_n : (wc.tried_n % 4);  /* кольцо */
    memcpy(wc.tried_bssid[slot], ap->bssid, 6);
    wc.tried_n++;
}

static void conn_handle_mgmt(const u8 *frame, u32 len) {
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    u8 type = (u8)((fc >> 2) & 0x3);
    u8 subtype = (u8)((fc >> 4) & 0xF);
    if (type != 0) return;                    /* только management */
    if (len < 26) return;
    /* кадры нашей точки */
    if (memcmp(frame + 16, wc.conn_bssid, 6) != 0 &&
        memcmp(frame + 10, wc.conn_bssid, 6) != 0)
        return;

    if (subtype == 11 && len >= 30) {         /* Authentication */
        if (wc.conn != WIFI_CONN_AUTH) return;
        u16 algo = (u16)(frame[24] | (frame[25] << 8));
        u16 seq  = (u16)(frame[26] | (frame[27] << 8));
        u16 st   = (u16)(frame[28] | (frame[29] << 8));
        if (algo == 0 && seq == 2 && st == 0) {
            wifi_log("AUTH ok — посылаем ASSOC REQ");
            wc.conn = WIFI_CONN_ASSOC;
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            tx_assoc_req(wc.conn_ssid);
        } else {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "AUTH отклонён (status=%u)", (unsigned)st);
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
        }
    } else if (subtype == 1 && len >= 30) {   /* Association Response */
        if (wc.conn != WIFI_CONN_ASSOC) return;
        u16 st  = (u16)(frame[26] | (frame[27] << 8));
        u16 aid = (u16)(frame[28] | (frame[29] << 8));
        if (st == 0) {
            wc.conn_aid = aid & 0x3FFF;
            wc.beacon_last = timer_ticks();
            if (wc.conn_retries > 0) wc.conn_retries--;  /* точка нас приняла — смягчаем счётчик */
            /* RX-фильтр: только наша BSS + bcast/mcast + маяки */
            wc.ops->rx_filter_bss();
            if (wc.sec == WIFI_SEC_WPA2_PSK) {
                wc.conn = WIFI_CONN_4WAY;
                wc.fw_phase = 0;
                wc.fw_attempts = 0;
                wc.fw_timer = timer_ticks();
                wifi_log("ASSOC ok: \"%s\" AID=%u (ch %d) — WPA2: ждём ключи",
                         wc.conn_ssid, (unsigned)wc.conn_aid,
                         wc.conn_channel + 1);
            } else {
                wc.conn = WIFI_CONN_CONNECTED;
                wifi_log("ASSOC ok: \"%s\" AID=%u (ch %d) — сеть доступна",
                         wc.conn_ssid, (unsigned)wc.conn_aid,
                         wc.conn_channel + 1);
                wifi_profile_save(wc.conn_ssid);
            }
        } else {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "ASSOC отклонён (status=%u)", (unsigned)st);
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
        }
    } else if (subtype == 12 && len >= 26) {  /* Deauthentication */
        if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_ASSOC ||
            wc.conn == WIFI_CONN_AUTH || wc.conn == WIFI_CONN_4WAY) {
            u16 reason = (u16)(frame[24] | (frame[25] << 8));
            wc.conn_retries++;
            if (wc.conn_retries > CONN_MAX_DEAUTH) {
                /* СЕССИЯ 32 (анти-шторм): точка стабильно отшивает —
                 * СТОП. Раньше цикл скан→AUTH→DEAUTH крутился вечно,
                 * выжигая CPU на полных сканах и EHCI-поллинге. */
                snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                         "точка отшивает (DEAUTH reason=%u)", (unsigned)reason);
                wifi_log("%s", wc.conn_fail_reason);
                wc.conn = WIFI_CONN_FAILED;
                wc.ops->rx_filter_promisc();
            } else if (wc.conn_retries <= CONN_FAST_RETRIES) {
                /* быстрая переподключалка к ТОЙ ЖЕ точке: канал уже
                 * настроен, полный скан (3 с) не нужен */
                wifi_log("точка послала DEAUTH (reason=%u) — переподключение",
                         (unsigned)reason);
                wc.conn = WIFI_CONN_AUTH;
                wc.conn_attempts = 1;
                wc.conn_timer = timer_ticks();
                tx_auth_req();
            } else {
                /* быстрые попытки кончились — рескан (другая BSSID
                 * того же SSID может принять) */
                wifi_log("точка послала DEAUTH (reason=%u) — рескан",
                         (unsigned)reason);
                wc.conn = WIFI_CONN_SCAN;
                wc.conn_scans = 0;
                wc.conn_attempts = 0;
                wc.ops->rx_filter_promisc();
                wifi_scan_start();
            }
        }
    } else if (subtype == 10 && len >= 26) {  /* Disassociation */
        if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_ASSOC) {
            wc.conn_retries++;
            if (wc.conn_retries > CONN_MAX_DEAUTH) {
                snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                         "точка отвязывает (DISASSOC)");
                wifi_log("%s", wc.conn_fail_reason);
                wc.conn = WIFI_CONN_FAILED;
                wc.ops->rx_filter_promisc();
            } else {
                wifi_log("DISASSOC от точки — переподключение к той же");
                wc.conn = WIFI_CONN_AUTH;
                wc.conn_attempts = 1;
                wc.conn_timer = timer_ticks();
                tx_auth_req();
            }
        }
    }
}

/* ---- шаг машины подключения (вызывается из wifi_poll) ---- */
static void conn_step(void) {
    switch (wc.conn) {
    case WIFI_CONN_SCAN:
        /* скан завершён? — ищем сеть */
        if (wc.scanning) return;
        {
            /* сильнейшая точка с нужным SSID. Открытая — без пароля;
             * ЗАЩИЩЕННАЯ ЛЮБОГО ТИПА — с паролем (пробуем как WPA2-PSK).
             * СЕССИЯ 32: непробованные BSSID приоритетнее (ротация). */
            int best = -1, best_fresh = -1;
            for (int i = 0; i < wc.ap_count; i++) {
                if (strcmp(wc.aps[i].ssid, wc.conn_ssid) != 0) continue;
                u8 sec = wc.aps[i].sec;
                if (sec == WIFI_SEC_OPEN && wc.psk[0]) continue;
                if (sec != WIFI_SEC_OPEN && !wc.psk[0]) continue;
                if (best < 0 || wc.aps[i].rssi > wc.aps[best].rssi)
                    best = i;
                if (!conn_bssid_tried(&wc.aps[i]) &&
                    (best_fresh < 0 || wc.aps[i].rssi > wc.aps[best_fresh].rssi))
                    best_fresh = i;
            }
            if (best_fresh >= 0) best = best_fresh;
            if (best < 0) {
                int enc = -1;
                for (int i = 0; i < wc.ap_count; i++)
                    if (strcmp(wc.aps[i].ssid, wc.conn_ssid) == 0) { enc = i; break; }
                if (enc >= 0) {
                    const char *why = wc.psk[0]
                        ? "открытая сеть — пароль не нужен"
                        : "нужен пароль (WPA2/WPA)";
                    snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                             "\"%s\": %s", wc.conn_ssid, why);
                    wifi_log("%s", wc.conn_fail_reason);
                    wc.conn = WIFI_CONN_FAILED;
                    return;
                }
                wc.conn_scans++;
                if (wc.conn_scans >= CONN_SCAN_TRIES) {
                    snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                             "сеть \"%s\" не найдена", wc.conn_ssid);
                    wifi_log("%s", wc.conn_fail_reason);
                    wc.conn = WIFI_CONN_FAILED;
                    return;
                }
                wifi_log("скан %d: сети нет — повтор", wc.conn_scans);
                wifi_scan_start();
                return;
            }
            /* нашли: тип защиты точки + настройка канала и BSSID */
            wc.sec = wc.psk[0] ? WIFI_SEC_WPA2_PSK : wc.aps[best].sec;
            wc.ap_group_tkip = wc.aps[best].group_tkip;
            memcpy(wc.conn_bssid, wc.aps[best].bssid, 6);
            wc.conn_channel = wc.aps[best].channel - 1;
            if (wc.conn_channel < 0 || wc.conn_channel >= WC_NUM_CHANNELS)
                wc.conn_channel = 0;
            wc.conn_rssi = wc.aps[best].rssi;
            /* СЕССИЯ 32: рейты/capability точки — для ASSOC REQ */
            wc.conn_capab = wc.aps[best].capability;
            wc.conn_rates_len = wc.aps[best].rates_len;
            memcpy(wc.conn_rates, wc.aps[best].rates, wc.conn_rates_len);
            conn_remember_tried(&wc.aps[best]);
            wifi_log("точка найдена: %02x:%02x:%02x:%02x:%02x:%02x ch %d (%d dBm)"
                     " — AUTH",
                     wc.conn_bssid[0], wc.conn_bssid[1], wc.conn_bssid[2],
                     wc.conn_bssid[3], wc.conn_bssid[4], wc.conn_bssid[5],
                     wc.conn_channel + 1, wc.conn_rssi);
            if (!wc.ops->set_channel(wc.conn_channel)) {
                wifi_log("смена канала не удалась — полный init");
                wc.ops->full_reset();
            }
            wc.ops->rx_filter_bss();          /* фильтр на время ассоциации */
            wc.conn = WIFI_CONN_AUTH;
            wc.conn_attempts = 1;
            wc.conn_timer = timer_ticks();
            if (!tx_auth_req()) {
                wifi_log("AUTH не отправлен (TX отказ)");
                wc.conn = WIFI_CONN_FAILED;
            }
        }
        break;

    case WIFI_CONN_AUTH:
    case WIFI_CONN_ASSOC:
        if ((int)(timer_ticks() - wc.conn_timer) < CONN_AUTH_TO) return;
        if (wc.conn_attempts >= CONN_MAX_ATTEMPTS) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "%s: нет ответа точки",
                     wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC");
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
            return;
        }
        wc.conn_attempts++;
        wc.conn_timer = timer_ticks();
        wifi_log("таймаут — повтор %d (%s)", wc.conn_attempts,
                 wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC");
        if (wc.conn == WIFI_CONN_AUTH) tx_auth_req();
        else                           tx_assoc_req(wc.conn_ssid);
        break;

    case WIFI_CONN_4WAY:
        if ((int)(timer_ticks() - wc.fw_timer) < CONN_4WAY_TO) return;
        wc.fw_attempts++;
        if (wc.fw_attempts >= CONN_MAX_4WAY) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "WPA2: рукопожатие не завершено");
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
            return;
        }
        wc.fw_phase = 0;
        wc.fw_timer = timer_ticks();
        wifi_log("WPA2: нет сообщений EAPOL — повтор ассоциации (%d)",
                 wc.fw_attempts);
        wc.conn = WIFI_CONN_ASSOC;
        wc.conn_attempts = 1;
        wc.conn_timer = timer_ticks();
        tx_assoc_req(wc.conn_ssid);
        break;

    case WIFI_CONN_CONNECTED:
        /* контроль потери связи: нет маяков давно → рескан */
        if ((int)(timer_ticks() - wc.beacon_last) < CONN_BEACON_LOST) return;
        wifi_log("маяки пропали >6 с — переподключение к \"%s\"", wc.conn_ssid);
        wc.conn = WIFI_CONN_SCAN;
        wc.conn_scans = 0;
        wc.conn_attempts = 0;
        wc.ops->rx_filter_promisc();
        wifi_scan_start();
        break;

    default:
        break;
    }
}

/* ================= публичный API подключения ================= */

int wifi_connect_psk(const char *ssid, const char *psk) {
    if (!wc.present || !wc.ready || !wc.ops) return 0;
    if (!ssid || !ssid[0]) return 0;
    u32 L = (u32)strlen(ssid);
    if (L > 32) return 0;

    if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_AUTH ||
        wc.conn == WIFI_CONN_ASSOC || wc.conn == WIFI_CONN_4WAY)
        wifi_disconnect();

    strncpy(wc.conn_ssid, ssid, 32);
    wc.conn_ssid[32] = 0;
    wc.sec = 0;                 /* уточним по маяку при скане */
    wc.psk[0] = 0;
    if (psk && psk[0]) {
        if (strlen(psk) < 8) {
            wifi_log("WPA2: пароль короче 8 символов");
            return 0;
        }
        strncpy(wc.psk, psk, sizeof(wc.psk) - 1);
        wc.psk[sizeof(wc.psk) - 1] = 0;
        wc.sec = WIFI_SEC_WPA2_PSK;   /* попытаемся как WPA2 */
    }
    wc.conn_scans = 0;
    wc.conn_attempts = 0;
    wc.conn_fail_reason[0] = 0;
    wc.conn_retries = 0;      /* сессия подключения новая — счётчик DEAUTH с нуля */
    wc.conn = WIFI_CONN_SCAN;
    wc.netrx_head = wc.netrx_tail = 0;
    /* СЕССИЯ 32: свежий скан (< 15 с) уже видел эту сеть — НЕ гоняем
     * полный скан (~1.5 с при dwell 110 мс) на каждую попытку подключения:
     * клик по сети из списка должен сразу AUTH-ить по готовым данным. */
    int have_cached = 0;
    if (!wc.scanning && wc.ap_count > 0 && wc.last_scan_end != 0 &&
        (u32)(timer_ticks() - wc.last_scan_end) < 15000) {
        for (int i = 0; i < wc.ap_count; i++) {
            if (strcmp(wc.aps[i].ssid, wc.conn_ssid) != 0) continue;
            u8 s = wc.aps[i].sec;
            if (s == WIFI_SEC_OPEN && wc.psk[0]) continue;
            if (s != WIFI_SEC_OPEN && !wc.psk[0]) continue;
            have_cached = 1;
            break;
        }
    }
    if (have_cached) {
        wifi_log("подключение к \"%s\"%s: сеть в свежем скане — AUTH сразу",
                 wc.conn_ssid, wc.psk[0] ? " (WPA2)" : "");
        /* scanning=0 — conn_step(SCAN) сам выберет точку и отправит AUTH */
        return 1;
    }
    wifi_log("подключение к \"%s\"%s: скан...", wc.conn_ssid,
             wc.psk[0] ? " (WPA2)" : "");
    if (!wc.scanning)
        wifi_scan_start();
    else
        wc.conn_scans = 1;      /* скан уже идёт — учтём текущий проход */
    return 1;
}

int wifi_connect(const char *ssid) {
    /* если в профиле есть пароль — подключаемся с ним */
    char psk[65];
    if (wifi_profile_load_psk(psk, sizeof(psk)))
        return wifi_connect_psk(ssid, psk);
    return wifi_connect_psk(ssid, NULL);
}

int wifi_conn_secured(void)
{
    return (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed) ? 1 : 0;
}

void wifi_disconnect(void) {
    if (!wc.ops) return;
    if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_4WAY)
        tx_deauth();
    if (wc.conn != WIFI_CONN_OFF) {
        wc.conn = WIFI_CONN_OFF;
        wc.conn_ssid[0] = 0;
        wpa2_clear_keys();          /* ключи железа больше не валидны */
        wc.ops->rx_filter_promisc();
        wifi_log("отключено");
    }
}

wifi_conn_state_t wifi_conn_state(void) { return wc.conn; }
const char *wifi_conn_ssid(void) { return wc.conn_ssid; }
int  wifi_conn_rssi(void)   { return wc.conn_rssi; }
int  wifi_conn_channel(void) { return wc.conn_channel + 1; }

const char *wifi_conn_state_name(void) {
    switch (wc.conn) {
        case WIFI_CONN_OFF:       return "не подключаемся";
        case WIFI_CONN_SCAN:      return "поиск сети";
        case WIFI_CONN_AUTH:      return "аутентификация";
        case WIFI_CONN_ASSOC:     return "ассоциация";
        case WIFI_CONN_4WAY:      return "WPA2-рукопожатие";
        case WIFI_CONN_CONNECTED: return "подключено";
        case WIFI_CONN_FAILED:    return "не удалось";
    }
    return "?";
}

/* ================= опрос из главного цикла ================= */

void wifi_poll(void) {
    if (!wc.present || !wc.ready || !wc.ops) return;

    wc.ops->poll_rx();

    /* машина подключения (после опроса RX — ответы уже разобраны) */
    conn_step();

    if (!wc.scanning) return;

    u32 now = timer_ticks();
    if ((int)(now - wc.dwell_start) < WIFI_SCAN_DWELL) return;   /* ещё слушаем */

    int idx = wc.scan_channel;
    wifi_log("ch %d (%u МГц): кадров %u, маяков %u, CRC %u, сетей %d",
             idx + 1, (unsigned)wc_channel_freq[idx],
             (unsigned)wc.stats.chan_frames[idx],
             (unsigned)wc.stats.chan_beacons[idx],
             (unsigned)wc.stats.chan_crc[idx], wc.ap_count);

    if (idx + 1 >= WC_NUM_CHANNELS) {
        /* скан завершён */
        wc.scanning = 0;
        wc.last_scan_end = timer_ticks();   /* для кэша при подключении */
        /* повторный проход? (ath9k AR9485: опорник 25 МГц) */
        if (wc.pass == 1 && wc.stats.frames == 0 && wc.ops->scan_retry &&
            wc.ops->scan_retry(0)) {
            wc.pass = 2;
            memset(&wc.stats, 0, sizeof(wc.stats));
            wc.scanning = 1;
            wc.scan_channel = 0;
            wc.dwell_start = timer_ticks();
            if (!wc.ops->set_channel(0)) {
                wc.scanning = 0;
                wc.pass = 1;
            }
            return;
        }
        wifi_log("скан завершён: %d сетей, %u кадров, %u CRC, %u прочих",
                 wc.ap_count, (unsigned)wc.stats.frames,
                 (unsigned)wc.stats.crc_err, (unsigned)wc.stats.other);
        return;
    }

    wc.scan_channel = idx + 1;
    wc.dwell_start = now;
    if (!wc.ops->set_channel(wc.scan_channel)) {
        wc.scanning = 0;
        wifi_log("скан прерван: смена канала не удалась");
    }
}

/* ================= bind + init (диспетчер драйверов) ================= */

void wifi_core_bind(const wifi_hw_ops_t *ops) {
    wc.ops = ops;
}

void wifi_init(void) {
    memset(&wc, 0, sizeof(wc));
    wc.scan_channel = -1;
    wc.pass = 1;
    /* запасной MAC до чтения EEPROM/efuse: локально-администрируемый */
    wc.mac[0] = 0x02; wc.mac[1] = 0x1A; wc.mac[2] = 0x2B;

    wifi_log("wifi: поиск адаптеров (Atheros PCI, Realtek RTL8192EU USB)...");

    if (ath9k_wifi_probe())
        goto found;
    if (rtl8192eu_probe())
        goto found;

    wifi_log("адаптер не найден (нужен AR9285/9287/9485 или RTL8192EU)");
    return;

found:
    wifi_log("%s готов к работе (RX+TX)", wc.chip_name);
    /* автоподключение к сохранённой сети (WIFI.CFG) */
    char ssid[33];
    if (wifi_profile_load(ssid, sizeof(ssid))) {
        wifi_log("профиль: \"%s\" — автоподключение", ssid);
        wifi_connect(ssid);
    } else {
        wifi_log("профиль не задан — подключение из WiFi/Настроек");
    }
}
