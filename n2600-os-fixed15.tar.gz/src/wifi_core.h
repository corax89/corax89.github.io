/* wifi_core.h — общий слой WiFi-стека N2600-OS.
 *
 * До сессии 28 весь WiFi-стек жил в ath9k_wifi.c (драйвер + скан +
 * beacon-парсер + машина подключения + WPA2 + мост 802.11<->Ethernet).
 * Теперь чипо-НЕЗАВИСИМАЯ часть вынесена сюда, а драйверы регистрируют
 * только «железные» операции (wifi_hw_ops_t):
 *
 *   ath9k_wifi.c  — Atheros AR9285/AR9287/AR9485 (PCI)
 *   rtl8192eu.c   — Realtek RTL8192EU/8191EU (USB, требует прошивку)
 *
 * Публичный API ДЛЯ ПРИЛОЖЕНИЙ НЕ ИЗМЕНИЛСЯ (wifi_* — как раньше,
 * см. старый ath9k_wifi.h): apps_wifi.c, net.c, kernel.c тронуты
 * только заменой include.
 */
#ifndef WIFI_CORE_H
#define WIFI_CORE_H

#include "types.h"

#define WIFI_MAX_APS 32

typedef struct {
    char     ssid[33];       /* SSID (NUL-terminated) */
    u8       bssid[6];       /* BSSID (MAC адрес точки) */
    i8       rssi;           /* Signal strength (dBm, отрицательное) */
    u8       channel;        /* Номер канала (1-14) */
    u8       beacon_interval; /* Интервал beacon (в 1024 us единицах) */
    u16      capability;     /* Capability info */
    u8       encrypted;      /* 1 = сеть зашифрована */
    u8       sec;            /* WIFI_SEC_* (тип защиты) */
    u8       group_tkip;     /* групповой шифр TKIP (смешанный режим) */
    /* Сессия 32: набор рейтов ТОЧКИ (Supported+Ext из маяка, с её
     * basic-битами) — в ASSOC REQ предлагаем ровно его (как делает
     * wpa_supplicant). Несовпадение базовых рейтов — самая частая
     * причина отказа ассоциации со статусом 18. */
    u8       rates[12];
    u8       rates_len;      /* 0 = рейты точки не известны */
} wifi_ap_t;

/* Статистика приёма/сканирования */
typedef struct {
    u32 frames;              /* всего кадров принято */
    u32 beacons;             /* из них beacon-кадров */
    u32 crc_err;             /* кадров с CRC/PHY-ошибкой */
    u32 other;               /* прочие ошибки */
    u32 aps;                 /* найдено сетей */
    int  channel;            /* текущий канал сканирования (1-14; 0 = нет) */
    int  pass;               /* 1 = основной проход, 2 = повтор */
    u32 chan_beacons[14];    /* маяков на каждом канале */
    u32 chan_frames[14];     /* кадров (FrameOK) на каждом канале */
    u32 chan_crc[14];        /* CRC/PHY-ошибок на каждом канале */
    int  nf_chain0;          /* NF (dBm) цепи 0 по CCA */
} wifi_stats_t;

/* Тип защиты сети (разбор RSN/WPA IE из маяка) */
#define WIFI_SEC_OPEN      0   /* без шифрования */
#define WIFI_SEC_WPA2_PSK  1   /* WPA2/WPA-PSK + CCMP — поддержано */
#define WIFI_SEC_WPA_PSK   2   /* только WPA/TKIP — не поддержано */
#define WIFI_SEC_OTHER     3   /* WEP / Enterprise / TKIP-only — нет */

typedef enum {
    WIFI_CONN_OFF = 0,     /* не подключаемся */
    WIFI_CONN_SCAN,        /* ищем сеть из профиля */
    WIFI_CONN_AUTH,        /* отправлен AUTH, ждём ответ */
    WIFI_CONN_ASSOC,       /* отправлен ASSOC REQ, ждём ответ */
    WIFI_CONN_4WAY,        /* WPA2: 4-стороннее рукопожатие */
    WIFI_CONN_CONNECTED,   /* ассоциированы — IP-трафик разрешён */
    WIFI_CONN_FAILED       /* не удалось (таймаут/отказ/шифрование) */
} wifi_conn_state_t;

/* ==================== публичный API приложений ==================== */

void wifi_init(void);                  /* пробует все драйверы по очереди */
void wifi_poll(void);                  /* главный цикл: RX + conn + скан */
void wifi_scan_start(void);
int  wifi_scan_active(void);
int  wifi_scan_results(wifi_ap_t *out, int max);
int  wifi_present(void);
int  wifi_ready(void);
const char *wifi_chip_name(void);
void wifi_get_stats(wifi_stats_t *out);

/* Диагностика (общий журнал для всех драйверов) */
void wifi_log(const char *fmt, ...);
int  wifi_log_count(void);
int  wifi_log_tail(char *buf, int buf_sz, int n_lines);

/* Подключение (асинхронно, состояние — wifi_conn_state()) */
int  wifi_connect(const char *ssid);
int  wifi_connect_psk(const char *ssid, const char *psk);
int  wifi_conn_secured(void);
void wifi_disconnect(void);
wifi_conn_state_t wifi_conn_state(void);
const char *wifi_conn_state_name(void);
const char *wifi_conn_ssid(void);     /* текущий/целевой SSID ("" = нет) */
int  wifi_conn_rssi(void);            /* RSSI последнего маяка, dBm */
int  wifi_conn_channel(void);         /* канал точки (0 = нет) */

/* Профиль автоподключения (RAM disk WIFI.CFG) */
int  wifi_profile_load(char *out_ssid, int max);
int  wifi_profile_load_psk(char *out_psk, int max);
void wifi_profile_save(const char *ssid);   /* "" — удалить профиль */

/* ---- NIC-интерфейс для net.c (мост 802.11 <-> Ethernet) ---- */
void wifi_net_get_mac(u8 out_mac[6]);
int  wifi_net_link(void);              /* 1 = ассоциированы */
int  wifi_net_send(const void *eth_frame, u32 len);   /* -1/0/1 */
u32  wifi_net_recv(void *buf, u32 max);               /* байт (0 = пусто) */

/* частоты 2.4 ГГц (каналы 1..14) — нужны и драйверам */
extern const u16 wc_channel_freq[14];
#define WC_NUM_CHANNELS 14

/* ==================== интерфейс драйвера ==================== */

/* Логические рейты для ops->tx_frame (2.4 ГГц CCK) */
typedef enum {
    WCRATE_1M = 0, WCRATE_2M, WCRATE_5_5M, WCRATE_11M
} wc_rate_t;

typedef struct wifi_hw_ops {
    /* Выгрузить принятые кадры (вызывается из wifi_poll). Драйвер
     * сам разбирает дескрипторы и отдаёт кадры через wc_rx_frame(). */
    void (*poll_rx)(void);

    /* Перестроить радио на канал idx (0..13). 1 = успех. */
    int  (*set_channel)(int idx);

    /* Передать готовый кадр 802.11 (mgmt и data — общий путь).
     * rate — логический CCK-рейт; tries — попыток (драйвер может
     * игнорировать); noack = 1 для broadcast/multicast;
     * keyidx = -1 без шифрования, иначе номер ключа (см. keys_install). */
    int  (*tx_frame)(const u8 *f, u32 len, wc_rate_t rate,
                     int tries, int noack, int keyidx);

    /* RX-фильтр: scan/отвал = принимать всё; ассоциация = наша BSS */
    void (*rx_filter_promisc)(void);
    void (*rx_filter_bss)(void);

    /* WPA2: ключи в железо. bssid = MAC точки (фильтр PTK);
     * ptk = 48 б (KCK16+KEK16+TK16, для шифрования берётся +32);
     * gtk = 32 б (CCMP 16 или TKIP 32: TK+RXMIC+TXMIC).
     * Возвращает 1 при успехе. */
    int  (*keys_install)(const u8 *bssid, const u8 *ptk,
                         const u8 *gtk, int gtk_is_tkip, int gtk_keyid);
    void (*keys_clear)(void);

    /* Полный bring-up заново (fallback при неудаче смены канала) */
    void (*full_reset)(void);

    /* Скан завершён, кадров 0. Драйвер может попросить повторный
     * проход (ath9k AR9485: опорник 25 МГц) — вернуть 1. */
    int  (*scan_retry)(u32 frames_seen);
} wifi_hw_ops_t;

/* Драйвер связывает себя (внутри probe при успехе) */
void wifi_core_bind(const wifi_hw_ops_t *ops);

/* Пробники драйверов (wifi_init вызывает по очереди) */
int ath9k_wifi_probe(void);
int rtl8192eu_probe(void);
int rtl8192eu_attached(void);   /* сессия 33: устройство уже зааттачено перечислением */

/* ---- ядро <- драйвер: доставить принятый кадр 802.11 ----
 * rssi в dBm (отрицательный). Статистика/скан/conn обрабатываются тут. */
void wc_rx_frame(const u8 *frame, int len, i8 rssi);
/* учёт ошибок приёма (crc = 1 при CRC/PHY-ошибке) */
void wc_rx_err(int crc);

/* MAC адрес (драйвер пишет после чтения EEPROM/efuse) */
void wc_set_mac(const u8 mac[6]);
void wc_get_mac(u8 out[6]);

/* Имя чипа и состояние (драйвер после probe/bring-up) */
void wc_set_chip_name(const char *name);
void wc_set_state(int present, int ready);

#endif /* WIFI_CORE_H */
