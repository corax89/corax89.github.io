/* filedlg.c — стандартные диалоги открытия/сохранения файлов N2600-OS.
 *
 * Диалог — обычное окно WM (поверх остальных). Пока он открыт, вызывающее
 * окно должно игнорировать ввод (см. флаг dlg в apps_editor.c).
 *
 * Устройство окна (координаты содержимого):
 *   +----------------------------------------------------------+
 *   | [RAM] [HDD] [USB]   info об источнике      (панель, 22) |
 *   |----------------------------------------------------------|
 *   | [Назад] RAM/путь/по/частям (крошки)   (заголовок, 22)   |
 *   |----------------------------------------------------------|
 *   | [D] dir                                                   |
 *   |      file.c    123 B     (список, скролл)                 |
 *   |      ...                                                  |
 *   |----------------------------------------------------------|
 *   | Имя: [prog.c___________]                  (поле, 26)     |
 *   |----------------------------------------------------------|
 *   | [Вверх]  [Открыть]  [Отмена]               (кнопки, 30) |
 *   |----------------------------------------------------------|
 *   | статус                                     (строка, 16) |
 *   +----------------------------------------------------------+
 *
 * Управление: Up/Down — выбор в списке; Enter — войти в каталог/подтвердить;
 * Backspace — стереть символ (пустое имя в FAT32 — уровень выше); Tab —
 * смена источника (диалог открытия); Esc — отмена; остальное — ввод имени.
 * Мышью: клик по источнику/строке/кнопке; клик по уже выделенной строке
 * файла = «активировать» (как в fileman).
 */
#include "textinput.h"  /* Task 64 [TI-WIDGET]: поле имени — общий виджет */
#include "filedlg.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mem.h"
#include "string.h"
#include "mouse.h"
#include "ramfs.h"
#include "fat32.h"
#include "ata.h"
#include "usb_ehci.h"
#include "clipboard.h"   /* [TI-WIDGET]: Ctrl+V в поле имени */

/* ------------------------------ геометрия ------------------------------ */
#define FD_DEVBAR   22    /* панель источников */
#define FD_HDR      22    /* строка пути */
#define FD_ROW      18    /* высота строки списка */
#define FD_NAMEROW  26    /* поле имени */
#define FD_BTNS     30    /* ряд кнопок */
#define FD_STATUS   16    /* статус-строка */
#define FD_WIN_W    560
#define FD_WIN_H    430   /* включая заголовок и рамку окна */
#define FD_LIST_MAX 256   /* сколько записей читаем из ФС */

/* кнопки нижнего ряда */
#define FD_BTN_UP   0
#define FD_BTN_OK   1
#define FD_BTN_CAN  2
#define FD_BTN_N    3
#define FD_BTN_W    92
#define FD_BTN_H    24
#define FD_BACK_W   64   /* кнопка «Назад» в строке пути (сессия 62) */
#define FD_CRUMB_X  (4 + FD_BACK_W + 8)  /* «крошки» адреса — правее кнопки */

typedef enum { FDLG_OPEN = 0, FDLG_SAVE = 1 } fd_kind_t;

typedef struct {
    fd_kind_t kind;
    /* параметры вызова */
    char  filter[32];          /* ".c,.cs,.txt" | "*" */
    void (*on_ok)(void *ctx, const fd_pick_t *pick, char *content, int len);
    void (*on_save_ok)(void *ctx, const fd_save_t *save);   /* сессия 14: назначение */
    void (*on_cancel)(void *ctx);
    void *ctx;
    window_t *win;

    /* состояние источника: сессия 14 — сохранение больше НЕ привязано
     * к RAM: источник переключается как в файловом менеджере, список
     * RAM идёт по иерархии (list_dir + стек путей), FAT32 — по кластерам */
    int   src;                 /* активный источник (FD_SRC_*) */
    int   src_avail[3];        /* 0/1 */
    int   src_hover;           /* -1 или индекс кнопки источника */
    int   crumb_hover;         /* сессия 62: сегмент «крошек» под курсором, -1 */
    int   back_hover;          /* сессия 62: курсор на кнопке «Назад» */
    struct { u32 cluster; char path[200]; } stk[16];
    int   depth;
    fat32_dirent_t fat_ents[FD_LIST_MAX];
    ramfs_dirent_t ram_ents[FD_LIST_MAX];
    int   fat_n, ram_n;
    int   sel;                 /* выделенная строка или -1 */
    int   scroll;

    /* поле имени.
     * Task 64 [TI-WIDGET]: редактирование — общий виджет (кириллица,
     * курсор в СИМВОЛАХ, Backspace по ЦЕЛОМУ символу). */
    char  name[FD_NAME_MAX + 1];
    ti_t  name_ti;

    /* кнопки/UX */
    int   hot;                 /* индекс кнопки под курсором: -1..2 */
    int   pressed;             /* что зажато, -1 */
    int   confirm;             /* 1 = ждём повторное «Сохранить» для перезаписи */
    int   closed;              /* защита от двойного завершения */
    char  status[96];
} fdlg_t;

/* --------------------------- утилиты --------------------------- */

static void fd_status(fdlg_t *d, const char *msg)
{
    strncpy(d->status, msg, sizeof(d->status) - 1);
    d->status[sizeof(d->status) - 1] = 0;
}

/* Совпадает ли расширение имени с одним из элементов фильтра ("*" — всё). */
static int fd_ext_match(const char *filter, const char *name)
{
    if (!filter || !filter[0] || strcmp(filter, "*") == 0) return 1;

    int L = (int)strlen(name);
    int dot = -1;
    for (int i = L - 1; i >= 0; i--)
        if (name[i] == '.') { dot = i; break; }
    if (dot < 0) return 0;                 /* нет расширения — мимо фильтра */

    const char *p = filter;
    while (*p) {
        while (*p == ',' || *p == ' ') p++;
        if (!*p) break;
        const char *start = p;
        while (*p && *p != ',') p++;
        int flen = (int)(p - start);
        if (flen >= 2 && start[0] == '.') {
            int elen = L - dot - 1;
            if (elen == flen - 1) {
                int ok = 1;
                for (int k = 0; k < elen; k++) {
                    char a = name[dot + 1 + k];
                    char b = start[1 + k];
                    if (a >= 'A' && a <= 'Z') a += 32;
                    if (b >= 'A' && b <= 'Z') b += 32;
                    if (a != b) { ok = 0; break; }
                }
                if (ok) return 1;
            }
        }
        if (*p) p++;
    }
    return 0;
}

/* seg-я (1-based) компонента пути "/a/b/c" в out (0 — нет такой). */
static int fd_path_comp(const char *path, int seg, char *out, int outsz)
{
    int idx = 0, i = 0;
    while (path[i]) {
        while (path[i] == '/') i++;
        if (!path[i]) break;
        int start = i;
        while (path[i] && path[i] != '/') i++;
        if (++idx == seg) {
            int len = i - start;
            if (len > outsz - 1) len = outsz - 1;
            memcpy(out, path + start, len);
            out[len] = 0;
            return 1;
        }
    }
    out[0] = 0;
    return 0;
}

/* ---- Сессия 62: «крошки» в строке пути ----
 * Корень (RAM/HDD/USB) и каждая папка пути — отдельная «кнопка»:
 * клик по части адреса — переход на ту глубину стека каталогов.
 * Сегменты, не влезающие в max_w, не рисуются и не кликаются.
 * draw=1 — рисование (подсветка сегмента из crumb_hover);
 * draw=0 — hit-тест: возврат глубины сегмента под курсором (-1). */
static int fd_crumbs(fdlg_t *d, int x, int hy, int max_w, int draw, int hit_x)
{
    const char *root = d->src == FD_SRC_RAMFS ? "RAM" :
                       d->src == FD_SRC_ATA  ? "HDD" : "USB";
    const char *path = d->stk[d->depth].path;
    int lim = x + max_w;
    int cx  = x;
    int ty  = hy + 3;
    int hit = -1;

    for (int seg = 0; seg <= d->depth; seg++) {
        char comp[64];
        const char *name;
        if (seg == 0) name = root;
        else {
            if (!fd_path_comp(path, seg, comp, sizeof(comp))) break;
            name = comp;
        }
        int bw = (int)fb_text_w(name) + 8;
        if (cx + bw > lim) break;
        int cur = (seg == d->depth);   /* текущий каталог — не кнопка */
        if (draw) {
            if (!cur && d->crumb_hover == seg)
                fb_fill_rect(cx, hy + 2, bw, FD_HDR - 4, wm_theme_sel_bg());
            fb_text(cx + 4, ty, name,
                    cur ? wm_theme_text() : fb_rgb(0x8F, 0xC8, 0xFF), -1);
        } else if (hit_x >= cx && hit_x < cx + bw) {
            hit = seg;
        }
        cx += bw;
        if (seg < d->depth) {
            if (draw) fb_text(cx + 2, ty, "/", wm_theme_text_dim(), -1);
            cx += 12;
        }
    }
    return hit;
}

static void fd_path_join(char *dst, const char *name)
{
    int l = (int)strlen(dst);
    if (l && dst[l-1] != '/') dst[l++] = '/';
    int i = 0;
    while (name[i] && l < 190) dst[l++] = name[i++];
    dst[l] = 0;
}

/* Перечитать текущий каталог источника.
 * Сессия 14: RAM — иерархический список ТЕКУЩЕГО каталога (list_dir),
 * как в файловом менеджере; действует для диалога сохранения тоже. */
static void fd_reload(fdlg_t *d)
{
    d->fat_n = d->ram_n = 0;
    if (d->src == FD_SRC_RAMFS) {
        d->ram_n = ramfs_ready()
                 ? ramfs_list_dir(d->stk[d->depth].path, d->ram_ents, FD_LIST_MAX)
                 : 0;
    } else {
        if (!fat32_ready()) {              /* ленивая инициализация, как в fileman */
            if (d->src == FD_SRC_ATA) fat32_init();
            else fat32_init_usb_all();   /* [USB-MULTI]: перебор накопителей */
        }
        d->fat_n = fat32_ready()
                 ? fat32_list(d->stk[d->depth].cluster, d->fat_ents, FD_LIST_MAX)
                 : 0;
    }
    d->sel = -1;
    d->scroll = 0;
    d->confirm = 0;
}

/* число строк списка и доступ к строке по индексу */
static int fd_rows(fdlg_t *d)
{
    return (d->src == FD_SRC_RAMFS) ? d->ram_n : d->fat_n;
}

static void fd_row_get(fdlg_t *d, int idx,
                       const char **name, u32 *size, int *is_dir)
{
    if (d->src == FD_SRC_RAMFS) {
        ramfs_dirent_t *e = &d->ram_ents[idx];
        *name = e->name; *size = e->size; *is_dir = e->is_dir;
    } else {
        fat32_dirent_t *e = &d->fat_ents[idx];
        *name = e->name; *size = e->size;
        *is_dir = (e->attr & 0x10) ? 1 : 0;
    }
}

/* --------------------------- завершение --------------------------- */

static void fd_finish_cancel(fdlg_t *d)
{
    if (d->closed) return;
    d->closed = 1;
    if (d->on_cancel) d->on_cancel(d->ctx);
}

static void fd_finish_open_ok(fdlg_t *d, fd_source_t src, const char *name,
                              const char *path, char *content, int len)
{
    if (d->closed) { free(content); return; }
    d->closed = 1;
    if (d->on_ok) {
        fd_pick_t pick;
        memset(&pick, 0, sizeof(pick));
        pick.source = src;
        strncpy(pick.name, name, FD_NAME_MAX);
        pick.name[FD_NAME_MAX] = 0;
        strncpy(pick.path, path, sizeof(pick.path) - 1);
        pick.path[sizeof(pick.path) - 1] = 0;
        /* сессия 14: каталог+кластер — чтобы вызывающий мог сохранить обратно */
        snprintf(pick.dir, sizeof(pick.dir), "%s", d->stk[d->depth].path);
        pick.cluster = d->stk[d->depth].cluster;
        d->on_ok(d->ctx, &pick, content, len);
    } else {
        free(content);
    }
    if (d->win) win_close(d->win);   /* диалог выполнил задачу — закрыть */
}

static void fd_finish_save_ok(fdlg_t *d, const fd_save_t *save_rec)
{
    if (d->closed) return;
    d->closed = 1;
    if (d->on_save_ok) d->on_save_ok(d->ctx, save_rec);
    if (d->win) win_close(d->win);   /* диалог выполнил задачу — закрыть */
}

/* --------------------------- действия --------------------------- */

/* Чтение файла-результата диалога открытия. */
static void fd_do_open(fdlg_t *d)
{
    const char *name;
    int have_row = (d->sel >= 0 && d->sel < fd_rows(d));

    if (have_row) {
        const char *rn; u32 rs; int rd;
        fd_row_get(d, d->sel, &rn, &rs, &rd);
        if (rd) { fd_status(d, "Выбран каталог — нажмите Enter, чтобы войти"); return; }
        name = rn;
    } else {
        name = d->name;                     /* введено вручную */
        if (!name[0]) { fd_status(d, "Введите или выберите имя файла"); return; }
    }

    char *content = (char *)malloc(FD_READ_MAX);
    if (!content) { fd_status(d, "Нет памяти под чтение файла"); return; }

    int len = 0;
    char path[200];
    if (d->src == FD_SRC_RAMFS) {
        /* сессия 14: иерархия — полный путь текущего каталога + имя */
        snprintf(path, sizeof(path), "%s", d->stk[d->depth].path);
        if (path[0] == '/' && !path[1]) snprintf(path, sizeof(path), "%s", name);
        else fd_path_join(path, name);
        len = (int)ramfs_read(path, content, FD_READ_MAX - 1);
    } else {
        /* ищем запись (для варианта «ввели имя руками») */
        fat32_dirent_t *e = NULL;
        if (have_row) e = &d->fat_ents[d->sel];
        else {
            for (int i = 0; i < d->fat_n; i++)
                if (strcmp(d->fat_ents[i].name, name) == 0) { e = &d->fat_ents[i]; break; }
        }
        if (!e) { free(content); fd_status(d, "Файл не найден"); return; }
        len = (int)fat32_read_file(e->first_cluster, e->size, content, FD_READ_MAX - 1);
        snprintf(path, sizeof(path), "%s", d->stk[d->depth].path);
        fd_path_join(path, name);
    }

    if (len <= 0) { free(content); fd_status(d, "Файл не найден или пуст"); return; }
    content[len] = 0;
    fd_finish_open_ok(d, (fd_source_t)d->src, name, path, content, len);
}

/* «Сохранить»: валидация имени + подтверждение перезаписи.
 * Сессия 14: цель — ЛЮБОЙ источник (RAM иерархия / HDD / USB FAT32),
 * как в файловом менеджере. */
static void fd_do_save(fdlg_t *d)
{
    const char *nm = d->name;
    if (!nm[0]) { fd_status(d, "Введите имя файла"); return; }
    if (strchr(nm, '/')) { fd_status(d, "Имя не должно содержать /"); return; }

    int exists = 0;
    if (d->src == FD_SRC_RAMFS) {
        if (!ramfs_ready()) { fd_status(d, "RAM disk недоступен"); return; }
        for (int i = 0; i < d->ram_n; i++)
            if (strcmp(d->ram_ents[i].name, nm) == 0) { exists = 1; break; }
    } else {
        if (!fat32_ready()) { fd_status(d, "FAT32 не смонтирована"); return; }
        exists = fat32_find_entry(d->stk[d->depth].cluster, nm, NULL) ? 1 : 0;
    }

    if (exists && !d->confirm) {
        d->confirm = 1;
        fd_status(d, "Файл существует. Нажмите «Сохранить» ещё раз для перезаписи");
        return;
    }
    {
        fd_save_t rec;
        memset(&rec, 0, sizeof(rec));
        rec.source = (fd_source_t)d->src;
        snprintf(rec.path, sizeof(rec.path), "%s", d->stk[d->depth].path);
        rec.cluster = d->stk[d->depth].cluster;
        snprintf(rec.name, sizeof(rec.name), "%s", nm);
        fd_finish_save_ok(d, &rec);
    }
}

static void fd_enter_dir(fdlg_t *d)
{
    if (d->sel < 0 || d->sel >= fd_rows(d)) return;
    const char *name; u32 size; int is_dir;
    fd_row_get(d, d->sel, &name, &size, &is_dir);
    if (!is_dir) return;
    if (d->depth + 1 >= 16) return;
    d->depth++;
    if (d->src != FD_SRC_RAMFS)
        d->stk[d->depth].cluster = d->fat_ents[d->sel].first_cluster;
    strcpy(d->stk[d->depth].path, d->stk[d->depth-1].path);
    fd_path_join(d->stk[d->depth].path, name);
    fd_reload(d);
}

static void fd_up(fdlg_t *d)
{
    if (d->depth == 0) return;
    d->depth--;
    d->crumb_hover = -1;    /* сегменты сместились — подсветка устарела */
    d->back_hover  = 0;
    fd_reload(d);
}

static void fd_switch_src(fdlg_t *d, int src)
{
    /* Сессия 14: работает и для диалога СОХРАНЕНИЯ — цель выбирается
     * кнопками, как в файловом менеджере (прежде было «только RAM»). */
    if (src == d->src) return;
    if (!d->src_avail[src]) { fd_status(d, "Источник недоступен"); return; }
    d->src = src;
    d->depth = 0;
    if (src == FD_SRC_RAMFS) {
        d->stk[0].cluster = 0;
        strcpy(d->stk[0].path, "/");
    } else {
        if (src == FD_SRC_ATA) fat32_init();
        else fat32_init_usb_all();   /* [USB-MULTI]: перебор накопителей */
        d->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
        strcpy(d->stk[0].path, "/");
    }
    fd_reload(d);
}

/* Активация: Enter/двойной клик. Каталог — войти; файл — OK. */
static void fd_activate(fdlg_t *d)
{
    if (d->sel < 0 || d->sel >= fd_rows(d)) {
        if (d->kind == FDLG_SAVE) fd_do_save(d);
        else                      fd_do_open(d);
        return;
    }
    const char *name; u32 size; int is_dir;
    fd_row_get(d, d->sel, &name, &size, &is_dir);
    if (is_dir) { fd_enter_dir(d); return; }
    if (d->kind == FDLG_SAVE) { fd_do_save(d); return; }
    fd_do_open(d);
}

/* --------------------------- отрисовка --------------------------- */

static void fd_button_rect(int idx, int *bx, int *by, int *bw, int *bh,
                           int btns_y)
{
    *bw = FD_BTN_W; *bh = FD_BTN_H; *by = btns_y + 3;
    *bx = 8 + idx * (*bw + 6);
}

static void fd_draw(window_t *w)
{
    fdlg_t *d = (fdlg_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    int list_y0 = FD_DEVBAR + FD_HDR;
    int btns_y  = ch - FD_STATUS - FD_BTNS;
    int name_y  = btns_y - FD_NAMEROW;
    int list_h  = name_y - list_y0;

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x17, 0x1C));

    /* === панель источников === */
    fb_fill_rect(0, 0, cw, FD_DEVBAR, fb_rgb(0x0C, 0x0F, 0x14));
    fb_hline(0, cw - 1, FD_DEVBAR - 1, fb_rgb(0x2C, 0x31, 0x38));
    {
        const char *names[3] = {"[RAM]", "[HDD]", "[USB]"};
        int bx = 6;
        for (int i = 0; i < 3; i++) {
            int bw = 54;
            int en = d->src_avail[i];   /* сессия 14: сохранение тоже может выбрать любой источник */
            int hot = (d->src == i);
            int hov = (d->src_hover == i);
            u32 bg = hot ? wm_theme_sel_bg()
                    : (hov && en ? fb_rgb(0x1E, 0x33, 0x4A) : wm_theme_win_bg_alt());
            u32 fg = en ? (hot ? wm_theme_text() : wm_theme_text_dim())
                        : fb_rgb(0x40, 0x40, 0x40);
            fb_fill_rect(bx, 2, bw, FD_DEVBAR - 4, bg);
            fb_rect(bx, 2, bw, FD_DEVBAR - 4, fb_rgb(0x2C, 0x31, 0x38));
            fb_text(bx + 7, 4, names[i], fg, -1);
            bx += bw + 4;
        }
        const char *info;
        char infobuf[64];
        if (d->src == FD_SRC_RAMFS) {
            snprintf(infobuf, sizeof(infobuf), "RAM disk: занято %u из %u KiB",
                     (unsigned)((ramfs_total_space() - ramfs_free_space()) / 1024),
                     (unsigned)(ramfs_total_space() / 1024));
            info = infobuf;
        } else {
            info = fat32_ready() ? fat32_label() : "нет FAT32";
        }
        fb_text(bx + 8, 4, info, wm_theme_text_info(), -1);
    }

    /* === строка пути: [Назад] + «крошки» (сессия 62) ===
     * Кнопка «Назад» — уровень выше (дублирует «Вверх»/Backspace);
     * каждая часть адреса — кнопка: клик — переход на эту глубину. */
    {
        int by = FD_DEVBAR + 3, bh = FD_HDR - 6;
        int en = d->depth > 0;
        fb_fill_rect(0, FD_DEVBAR, cw, FD_HDR, wm_theme_title());
        wm_button_draw(4, by, FD_BACK_W, bh, "Назад",
                       !en ? wm_theme_win_bg_alt()
                           : (d->back_hover ? fb_rgb(0x32, 0x60, 0x8E)
                                            : fb_rgb(0x1B, 0x21, 0x27)),
                       en ? wm_theme_text() : wm_theme_text_dim(),
                       en ? wm_theme_accent() : fb_rgb(0x2C, 0x31, 0x38));
        fd_crumbs(d, FD_CRUMB_X, FD_DEVBAR, cw - FD_CRUMB_X - 6, 1, 0);
    }

    /* === список === */
    {
        fb_fill_rect(0, list_y0, cw, list_h, wm_theme_win_bg());
        int vis = list_h / FD_ROW;
        if (vis < 1) vis = 1;
        int total = fd_rows(d);
        if (d->sel >= 0) {
            if (d->sel < d->scroll) d->scroll = d->sel;
            if (d->sel >= d->scroll + vis) d->scroll = d->sel - vis + 1;
        }
        if (d->kind == FDLG_OPEN && d->src != FD_SRC_RAMFS && !fat32_ready()) {
            fb_text(12, list_y0 + 8, "Источник не готов (нет FAT32)",
                    fb_rgb(0xE0, 0x9A, 0x9A), -1);
        } else if (total == 0) {
            fb_text(12, list_y0 + 8,
                    d->kind == FDLG_SAVE ? "RAM disk пуст — введите имя нового файла"
                                         : "Каталог пуст",
                    wm_theme_text_dim(), -1);
        }

        for (int i = 0; i < vis; i++) {
            int idx = d->scroll + i;
            if (idx >= total) break;
            const char *name; u32 size; int is_dir;
            fd_row_get(d, idx, &name, &size, &is_dir);

            int yy = list_y0 + 2 + i * FD_ROW;
            if (idx == d->sel)
                fb_fill_rect(0, yy, cw, FD_ROW, wm_theme_sel_bg());

            u32 col = is_dir ? fb_rgb(0x8F, 0xC8, 0xFF)
                     : (d->kind == FDLG_OPEN && !fd_ext_match(d->filter, name)
                        ? fb_rgb(0x5A, 0x62, 0x6A) : wm_theme_text());
            fb_text(6, yy + 1, is_dir ? "[D]" : "   ", col, -1);
            fb_text(6 + 4*8, yy + 1, name, col, -1);

            if (!is_dir) {
                char buf[24];
                if (size < 1024)            snprintf(buf, sizeof(buf), "%u B",   (unsigned)size);
                else if (size < 1024u*1024) snprintf(buf, sizeof(buf), "%u KiB", (unsigned)(size/1024));
                else                        snprintf(buf, sizeof(buf), "%u MiB", (unsigned)(size/(1024u*1024)));
                int tw = (int)fb_text_w(buf);
                fb_text(cw - tw - 8, yy + 1, buf, wm_theme_text_dim(), -1);
            }
        }
    }

    /* === поле имени === */
    {
        fb_fill_rect(0, name_y, cw, FD_NAMEROW, wm_theme_win_bg_alt());
        fb_hline(0, cw - 1, name_y, fb_rgb(0x2C, 0x31, 0x38));
        int fx = 8 + 5 * 8;                 /* правее метки «Имя:» */
        int fy = name_y + 4;
        int fw = cw - fx - 10;
        fb_fill_rect(fx, fy, fw, 20, wm_theme_win_bg());
        fb_rect(fx, fy, fw, 20, fb_rgb(0x2C, 0x60, 0x8E));
        /* сессия 20: имя гарантированно внутри поля (обрезка по символам).
         * Task 64 [TI-WIDGET]: каретка — на позиции КУРСОРА виджета
         * (в СИМВОЛАХ: кириллица 2 байта, но 8 px). */
        wm_text_fit(fx + 6, fy + 2, d->name, fw - 12, wm_theme_text(), 0);
        if (wm_blink()) {
            int cpos = utf8_count_chars(d->name, d->name_ti.cur);
            int tl_px = cpos * 8;
            if (tl_px + 14 < fw)
                fb_fill_rect(fx + 6 + tl_px, fy + 3, 8, 14, wm_theme_accent());
        }
        fb_text(8, fy + 4, "Имя:", wm_theme_text_dim(), -1);
    }

    /* === кнопки === */
    {
        fb_fill_rect(0, btns_y, cw, FD_BTNS, wm_theme_win_bg_alt());
        fb_hline(0, cw - 1, btns_y, fb_rgb(0x2C, 0x31, 0x38));
        const char *labels[FD_BTN_N];
        labels[FD_BTN_UP]  = "Вверх";
        labels[FD_BTN_OK]  = d->kind == FDLG_SAVE ? "Сохранить" : "Открыть";
        labels[FD_BTN_CAN] = "Отмена";
        for (int i = 0; i < FD_BTN_N; i++) {
            int bx, by, bw, bh;
            fd_button_rect(i, &bx, &by, &bw, &bh, btns_y);
            u32 bg = (d->pressed == i) ? fb_rgb(0x4A, 0x7F, 0xB0)
                   : (d->hot == i) ? fb_rgb(0x32, 0x60, 0x8E)
                   : (i == FD_BTN_OK) ? fb_rgb(0x25, 0x4A, 0x70) : fb_rgb(0x1B, 0x21, 0x27);
            /* сессия 20: подпись гарантированно внутри кнопки */
            wm_button_draw(bx, by, bw, bh, labels[i],
                           bg, wm_theme_text(), wm_theme_accent());
        }
        int hx = 8 + FD_BTN_N * (FD_BTN_W + 6) + 8;
        const char *hint = d->kind == FDLG_SAVE
            ? "клик по файлу подставит его имя"
            : "Tab — источник; Enter — открыть";
        if (hx < cw - (int)fb_text_w(hint))
            fb_text(hx, btns_y + 8, hint, wm_theme_text_dim(), -1);
    }

    /* === статус === */
    fb_fill_rect(0, ch - FD_STATUS, cw, FD_STATUS, fb_rgb(0x0C, 0x0F, 0x14));
    fb_text(4, ch - FD_STATUS + 2, d->status, wm_theme_text_info(), -1);
}

/* --------------------------- клавиатура --------------------------- */

static void fd_key(window_t *w, const key_event_t *ev)
{
    fdlg_t *d = (fdlg_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* Esc — отмена */
    if (ev->ch == 0x1B || ev->code == 0x01) {
        fd_finish_cancel(d);
        win_close(w);
        return;
    }

    /* Enter — активация выделенного/введённого */
    if (ev->code == 0x1C || ev->ch == '\n') { fd_activate(d); win_invalidate(w); return; }

    /* Tab — смена источника (открытие И сохранение — сессия 14) */
    if (ev->code == 0x0F) {
        fd_switch_src(d, (d->src + 1) % 3);
        win_invalidate(w);
        return;
    }

    /* Backspace: если поле имени непусто — стереть ЦЕЛЫЙ символ UTF-8
     * ([TI-WIDGET]), иначе (FAT32) — вверх по каталогу */
    if (ev->ch == '\b' || ev->code == 0x0E) {
        int l = (int)strlen(d->name);
        if (l > 0) {
            ti_backspace(&d->name_ti);
            d->confirm = 0;
        } else {
            fd_up(d);
        }
        win_invalidate(w);
        return;
    }

    /* Up/Down — навигация по списку (копирует имя файла в поле) */
    if (ev->code == KBD_UP) {
        int total = fd_rows(d);
        if (total > 0) {
            if (d->sel < 0) d->sel = 0;
            else if (d->sel > 0) d->sel--;
            const char *name; u32 size; int is_dir;
            fd_row_get(d, d->sel, &name, &size, &is_dir);
            if (!is_dir) { strncpy(d->name, name, FD_NAME_MAX); d->name[FD_NAME_MAX] = 0; ti_reset(&d->name_ti, d->name); }
            d->confirm = 0;
        }
        win_invalidate(w);
        return;
    }
    if (ev->code == KBD_DOWN) {
        int total = fd_rows(d);
        if (total > 0) {
            if (d->sel < total - 1) d->sel++;
            else d->sel = 0;
            const char *name; u32 size; int is_dir;
            fd_row_get(d, d->sel, &name, &size, &is_dir);
            if (!is_dir) { strncpy(d->name, name, FD_NAME_MAX); d->name[FD_NAME_MAX] = 0; ti_reset(&d->name_ti, d->name); }
            d->confirm = 0;
        }
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x49) { d->scroll -= 8; if (d->scroll < 0) d->scroll = 0; win_invalidate(w); return; }
    if (ev->code == 0x51) { d->scroll += 8; win_invalidate(w); return; }

    /* Печатаемый символ — в поле имени ([TI-WIDGET]: кириллица тоже —
     * имена файлов в RAM disk/FAT32 LFN хранятся байтами UTF-8). */
    if ((ev->ch >= 32 && ev->ch < 127) || (unsigned char)ev->ch >= 0x80) {
        if (!ti_insert_char(&d->name_ti, ev->ch)) {
            fd_status(d, "Слишком длинное имя");
            win_invalidate(w);
            return;
        }
        d->confirm = 0;
        /* сброс выделения, если имя перестало совпадать */
        if (d->sel >= 0 && d->sel < fd_rows(d)) {
            const char *name; u32 size; int is_dir;
            fd_row_get(d, d->sel, &name, &size, &is_dir);
            if (!is_dir && strcmp(name, d->name) != 0) d->sel = -1;
        }
        win_invalidate(w);
        return;
    }
}

/* --------------------------- мышь --------------------------- */

static void fd_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    fdlg_t *d = (fdlg_t *)w->data;
    int ch = win_content_h(w);
    int list_y0 = FD_DEVBAR + FD_HDR;
    int btns_y  = ch - FD_STATUS - FD_BTNS;
    int name_y  = btns_y - FD_NAMEROW;
    int list_h  = name_y - list_y0;
    int total = fd_rows(d);

    /* --- панель источников --- */
    if (my < FD_DEVBAR) {
        int bx = 6, hit = -1;
        for (int i = 0; i < 3; i++) {
            if (mx >= bx && mx < bx + 54) { hit = i; break; }
            bx += 54 + 4;
        }
        if (hit != d->src_hover) { d->src_hover = hit; win_invalidate(w); }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && hit >= 0)
            fd_switch_src(d, hit);
        return;
    }
    if (d->src_hover != -1) { d->src_hover = -1; win_invalidate(w); }

    /* --- строка пути: кнопка «Назад» + «крошки» (сессия 62) --- */
    if (my < FD_DEVBAR + FD_HDR) {
        int cw = win_content_w(w);
        int bhov = wm_button_hit(mx, my, 4, FD_DEVBAR + 3,
                                 FD_BACK_W, FD_HDR - 6);
        int hov = fd_crumbs(d, FD_CRUMB_X, FD_DEVBAR,
                            cw - FD_CRUMB_X - 6, 0, mx);
        if (hov == d->depth) hov = -1;  /* текущий каталог не подсвечиваем */
        if (bhov != d->back_hover || hov != d->crumb_hover) {
            d->back_hover  = bhov;
            d->crumb_hover = hov;
            win_invalidate(w);
        }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            if (bhov) {
                fd_up(d);
                d->confirm = 0;
                win_invalidate(w);
            } else if (hov >= 0 && hov < d->depth) {
                d->depth = hov;
                fd_reload(d);
                d->crumb_hover = -1;
                d->back_hover  = 0;
                win_invalidate(w);
            }
        }
        return;
    }
    if (d->back_hover || d->crumb_hover != -1) {
        d->back_hover  = 0;
        d->crumb_hover = -1;
        win_invalidate(w);
    }

    /* --- список --- */
    if (my >= list_y0 && my < name_y) {
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            int vis = list_h / FD_ROW;
            if (vis < 1) vis = 1;
            int row = (my - list_y0 - 2) / FD_ROW;
            if (row >= 0 && row < vis) {
                int idx = d->scroll + row;
                if (idx >= 0 && idx < total) {
                    const char *name; u32 size; int is_dir;
                    fd_row_get(d, idx, &name, &size, &is_dir);
                    if (idx == d->sel) {
                        /* второй клик по той же строке — активация */
                        if (is_dir) fd_enter_dir(d);
                        else {
                            strncpy(d->name, name, FD_NAME_MAX);
                            d->name[FD_NAME_MAX] = 0;
                            ti_reset(&d->name_ti, d->name);
                            d->confirm = 0;
                            fd_activate(d);
                        }
                    } else {
                        d->sel = idx;
                        if (!is_dir) {
                            strncpy(d->name, name, FD_NAME_MAX);
                            d->name[FD_NAME_MAX] = 0;
                            ti_reset(&d->name_ti, d->name);
                        }
                        d->confirm = 0;
                    }
                    win_invalidate(w);
                }
            }
        }
        return;
    }

    /* --- поле имени: ЛКМ ничего не меняет (ввод всегда активен);
     * [TI-CLIPMENU] ПКМ — меню «Копировать/Вставить» для имени --- */
    if (my >= name_y && my < btns_y) {
        if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
            ti_menu_open(w, &d->name_ti, mx, my);
            win_invalidate(w);
        }
        return;
    }

    /* --- кнопки --- */
    if (my >= btns_y && my < btns_y + FD_BTNS) {
        int hot = -1;
        for (int i = 0; i < FD_BTN_N; i++) {
            int bx, by, bw, bh;
            fd_button_rect(i, &bx, &by, &bw, &bh, btns_y);
            if (mx >= bx && mx < bx + bw && my >= by && my < by + bh) { hot = i; break; }
        }
        if (hot != d->hot) { d->hot = hot; win_invalidate(w); }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && d->hot >= 0) {
            d->pressed = d->hot;
            win_invalidate(w);
        }
        if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
            int was = d->pressed;
            d->pressed = -1;
            if (was >= 0 && was == d->hot) {
                if (was == FD_BTN_UP)  { fd_up(d); d->confirm = 0; }
                if (was == FD_BTN_OK)  { if (d->kind == FDLG_SAVE) fd_do_save(d); else fd_do_open(d); }
                if (was == FD_BTN_CAN) { fd_finish_cancel(d); win_close(w); return; }
            }
            win_invalidate(w);
        }
        return;
    }
    if (d->hot != -1 || d->pressed != -1) { d->hot = -1; d->pressed = -1; win_invalidate(w); }
}

/* Task 66 [FD-DETACH]: реестр ЖИВЫХ диалогов. Владелец (окно браузера)
 * может закрыться, пока диалог открыт — колбэки с его ctx стали бы
 * use-after-free. filedlg_detach_ctx(ctx) обнуляет колбэки у всех
 * диалогов с таким ctx: диалог продолжает работать, но результаты
 * больше никуда не доставляются. */
#define FD_LIVE_MAX 8
static fdlg_t *fd_live[FD_LIVE_MAX];

static void fd_live_add(fdlg_t *d)
{
    for (int i = 0; i < FD_LIVE_MAX; i++)
        if (!fd_live[i]) { fd_live[i] = d; return; }
}

static void fd_live_del(fdlg_t *d)
{
    for (int i = 0; i < FD_LIVE_MAX; i++)
        if (fd_live[i] == d) { fd_live[i] = NULL; return; }
}

void filedlg_detach_ctx(void *ctx)
{
    if (!ctx) return;
    for (int i = 0; i < FD_LIVE_MAX; i++) {
        fdlg_t *d = fd_live[i];
        if (d && d->ctx == ctx) {
            d->ctx = NULL;
            d->on_ok = NULL;
            d->on_save_ok = NULL;
            d->on_cancel = NULL;
        }
    }
}

static void fd_close(window_t *w)
{
    fdlg_t *d = (fdlg_t *)w->data;
    if (!d) return;
    fd_live_del(d);
    fd_finish_cancel(d);      /* закрытие крестиком = отмена */
    free(d);
}

/* --------------------------- общие точки входа --------------------------- */

static int fd_spawn(fdlg_t *d, const char *title)
{
    u32 W = fb_width(), H = fb_height();
    int ww = FD_WIN_W, wh = FD_WIN_H;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    d->win = win_create(title, 120, 56, ww, wh,
                        fd_draw, fd_key, fd_mouse, NULL, fd_close, d);
    return d->win != NULL;
}

static void fd_common_init(fdlg_t *d, void (*on_cancel)(void *), void *ctx)
{
    memset(d, 0, sizeof(*d));
    ti_init(&d->name_ti, d->name, FD_NAME_MAX + 1);   /* [TI-WIDGET] */
    d->on_cancel = on_cancel;
    d->ctx = ctx;
    fd_live_add(d);   /* [FD-DETACH] */

    d->src_avail[FD_SRC_RAMFS] = ramfs_ready() ? 1 : (ramfs_init() ? 1 : 0);
    d->src_avail[FD_SRC_ATA]  = (ata_present() && !ata_is_cdrom()) ? 1 : 0;
    d->src_avail[FD_SRC_USB]  = usb_ehci_storage_ready() ? 1 : 0;

    d->src = FD_SRC_RAMFS;
    d->depth = 0;
    d->stk[0].cluster = 0;
    strcpy(d->stk[0].path, "/");
    d->sel = -1;
    d->hot = -1;
    d->pressed = -1;
    d->src_hover = -1;
    d->crumb_hover = -1;
    strcpy(d->filter, "*");
}

void filedlg_open(const char *title, const char *filter, const char *default_name,
                  void (*on_open_ok)(void *ctx, const fd_pick_t *pick,
                                     char *content, int len),
                  void (*on_cancel)(void *ctx),
                  void *ctx)
{
    fdlg_t *d = (fdlg_t *)malloc(sizeof(fdlg_t));
    if (!d) { if (on_cancel) on_cancel(ctx); return; }
    fd_common_init(d, on_cancel, ctx);

    d->kind = FDLG_OPEN;
    d->on_ok = on_open_ok;

    if (filter && filter[0]) {
        strncpy(d->filter, filter, sizeof(d->filter) - 1);
        d->filter[sizeof(d->filter) - 1] = 0;
    }
    if (default_name && default_name[0]) {
        strncpy(d->name, default_name, FD_NAME_MAX);
        d->name[FD_NAME_MAX] = 0;
        ti_reset(&d->name_ti, d->name);   /* [TI-WIDGET] */
    }

    /* стартуем с HDD, если доступен, иначе USB, иначе RAM disk */
    if (d->src_avail[FD_SRC_ATA]) {
        d->src = FD_SRC_ATA;
        fat32_init();
        d->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else if (d->src_avail[FD_SRC_USB]) {
        d->src = FD_SRC_USB;
        fat32_init_usb_all();   /* [USB-MULTI]: перебор накопителей */
        d->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    }
    fd_reload(d);
    fd_status(d, "Enter — открыть, Tab — источник, Esc — отмена");

    if (!fd_spawn(d, title ? title : "Открыть файл")) { free(d); if (on_cancel) on_cancel(ctx); }
}

void filedlg_save(const char *title, const char *default_name, fd_source_t default_src,
                  void (*on_save_ok)(void *ctx, const fd_save_t *save),
                  void (*on_cancel)(void *ctx),
                  void *ctx)
{
    fdlg_t *d = (fdlg_t *)malloc(sizeof(fdlg_t));
    if (!d) { if (on_cancel) on_cancel(ctx); return; }
    fd_common_init(d, on_cancel, ctx);

    d->kind = FDLG_SAVE;
    d->on_save_ok = on_save_ok;

    if (default_name && default_name[0]) {
        strncpy(d->name, default_name, FD_NAME_MAX);
        d->name[FD_NAME_MAX] = 0;
        ti_reset(&d->name_ti, d->name);   /* [TI-WIDGET] */
    }
    /* Сессия 14: стартовый источник — как подсказал вызывающий (обычно тот,
     * откуда файл открыт), иначе первый доступный перезаписываемый. */
    {
        int s = (default_src == FD_SRC_ATA || default_src == FD_SRC_USB) ? (int)default_src : FD_SRC_RAMFS;
        if (!d->src_avail[s]) s = FD_SRC_RAMFS;
        if (s != FD_SRC_RAMFS) {
            d->src = s;
            if (s == FD_SRC_ATA) fat32_init();
            else fat32_init_usb_all();   /* [USB-MULTI]: перебор накопителей */
            d->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
        }
    }
    fd_reload(d);
    fd_status(d, "Tab — источник, Enter — сохранить, Esc — отмена");

    if (!fd_spawn(d, title ? title : "Сохранить как")) { free(d); if (on_cancel) on_cancel(ctx); }
}

/* ===================== диалог ввода имени (сессия 13) =====================
 * Модальное окно с одной строкой ввода: «Создать папку» / «Создать файл»
 * в проводнике, переименование и т.п. Переиспользуется любым приложением. */
#include "kbd.h"
#include "mouse.h"

typedef struct {
    char        buf[FD_NAME_MAX + 1];
    int         len;
    int         maxlen;
    char        prompt[80];
    fd_input_ok_fn     ok;
    fd_input_cancel_fn cancel;
    void       *ctx;
    /* Task 64 [TI-WIDGET]: редактирование — общий виджет (кириллица,
     * курсор в СИМВОЛАХ, Backspace по ЦЕЛОМУ символу, Ctrl+V) */
    ti_t        ti;
    struct { int x, y, w, h; int action; } hot[4]; int hot_n;
} fd_input_t;

#define FDIN_OK     1
#define FDIN_CANCEL 2

static void fdin_draw(window_t *w)
{
    fd_input_t *d = (fd_input_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x17, 0x1C));

    fb_text(10, 8, d->prompt, fb_rgb(0x8A, 0xC8, 0xE8), -1);

    /* поле ввода */
    int fx = 10, fy = 26, fw = cw - 20, fh = 20;
    fb_fill_rect(fx, fy, fw, fh, wm_theme_win_bg());
    fb_rect(fx, fy, fw, fh, fb_rgb(0x2C, 0x31, 0x38));
    /* Task 64 [TI-WIDGET]: каретка — в СИМВОЛАХ (кириллица 2 байта);
     * окно видимости — вокруг курсора, если текст шире поля */
    {
        int maxc = (fw - 10) / 8;
        if (maxc < 1) maxc = 1;
        ti_view_off(&d->ti, maxc);
        int from = d->ti.view_off;
        int vlen = d->ti.len - from;
        if (vlen < 0) vlen = 0;
        if (vlen > (int)sizeof(d->buf) - 1) vlen = (int)sizeof(d->buf) - 1;
        int nch = utf8_count_chars(d->buf + from, vlen);
        if (nch > maxc) vlen = utf8_take_bytes(d->buf + from, vlen, maxc);
        char shown[FD_NAME_MAX + 2];
        if (vlen > 0) memcpy(shown, d->buf + from, (u32)vlen);
        shown[vlen] = 0;
        fb_text(fx + 4, fy + 4, shown, wm_theme_text(), -1);
        int cpos = utf8_count_chars(d->buf + from, d->ti.cur - from);
        if (cpos > maxc) cpos = maxc;
        if (wm_blink())
            fb_rect(fx + 1 + cpos * 8, fy + 4, 8, 12, wm_theme_text());
    }

    /* кнопки */
    d->hot_n = 0;
    int bw = 96, bh = 22;
    int bx1 = cw / 2 - bw - 6, bx2 = cw / 2 + 6;
    int by = fy + fh + 10;
    fb_fill_rect(bx1, by, bw, bh, wm_theme_sel_bg());
    fb_rect(bx1, by, bw, bh, wm_theme_accent());
    fb_text(bx1 + bw / 2 - 3 * 8, by + 4, "OK (Enter)", wm_theme_text(), -1);
    {
        int hn = d->hot_n;
        d->hot[hn].x = bx1; d->hot[hn].y = by; d->hot[hn].w = bw;
        d->hot[hn].h = bh; d->hot[hn].action = FDIN_OK; d->hot_n++;
    }
    fb_fill_rect(bx2, by, bw, bh, wm_theme_win_bg_alt());
    fb_rect(bx2, by, bw, bh, fb_rgb(0x2C, 0x31, 0x38));
    fb_text(bx2 + bw / 2 - 2 * 8, by + 4, "Отмена", wm_theme_text_dim(), -1);
    {
        int hn = d->hot_n;
        d->hot[hn].x = bx2; d->hot[hn].y = by; d->hot[hn].w = bw;
        d->hot[hn].h = bh; d->hot[hn].action = FDIN_CANCEL; d->hot_n++;
    }
    (void)ch;
}

static void fdin_key(window_t *w, const key_event_t *ev)
{
    fd_input_t *d = (fd_input_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    /* Task 64 [TI-WIDGET]:Esc — отмена, Enter — OK, остальное — виджет
     * (кириллица принимается: имя файла может быть русским) */
    int r = ti_key(&d->ti, ev);
    if (r == TI_K_ESC) {
        fd_input_cancel_fn c = d->cancel;
        void *ctx = d->ctx;
        win_close(w);
        if (c) c(ctx);
        return;
    }
    if (r == TI_K_ENTER) {
        fd_input_ok_fn o = d->ok;
        void *ctx = d->ctx;
        char name[FD_NAME_MAX + 1];
        strncpy(name, d->buf, FD_NAME_MAX);
        name[FD_NAME_MAX] = 0;
        win_close(w);
        if (o && name[0]) o(ctx, name);
        return;
    }
    if (r == TI_K_EATEN) {
        d->len = d->ti.len;          /* совместимость: len — байты */
        win_invalidate(w);
    }
}

static void fdin_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    fd_input_t *d = (fd_input_t *)w->data;
    /* [TI-CLIPMENU] ПКМ — меню копировать/вставить для поля диалога */
    if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
        ti_menu_open(w, &d->ti, mx, my);
        win_invalidate(w);
        return;
    }
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        for (int i = 0; i < d->hot_n; i++) {
            if (mx >= d->hot[i].x && mx < d->hot[i].x + d->hot[i].w &&
                my >= d->hot[i].y && my < d->hot[i].y + d->hot[i].h) {
                if (d->hot[i].action == FDIN_OK) {
                    fd_input_ok_fn o = d->ok;
                    void *ctx = d->ctx;
                    char name[FD_NAME_MAX + 1];
                    strncpy(name, d->buf, FD_NAME_MAX);
                    name[FD_NAME_MAX] = 0;
                    win_close(w);
                    if (o && name[0]) o(ctx, name);
                } else {
                    fd_input_cancel_fn c = d->cancel;
                    void *ctx = d->ctx;
                    win_close(w);
                    if (c) c(ctx);
                }
                return;
            }
        }
    }
}

static void fdin_close(window_t *w)
{
    free(w->data);
}

void filedlg_input_open(const char *title, const char *prompt,
                         const char *defname, int maxlen,
                         fd_input_ok_fn ok, fd_input_cancel_fn cancel,
                         void *ctx)
{
    fd_input_t *d = (fd_input_t *)malloc(sizeof(fd_input_t));
    if (!d) return;
    memset(d, 0, sizeof(fd_input_t));
    if (maxlen <= 0 || maxlen > FD_NAME_MAX) maxlen = FD_NAME_MAX;
    d->maxlen = maxlen;
    strncpy(d->prompt, prompt ? prompt : "Введите имя:", sizeof(d->prompt) - 1);
    d->prompt[sizeof(d->prompt) - 1] = 0;
    ti_init(&d->ti, d->buf, (int)sizeof(d->buf));   /* [TI-WIDGET] */
    d->ti.paste_fn = clip_text_get;
    if (defname) {
        strncpy(d->buf, defname, maxlen);
        d->buf[maxlen] = 0;
        d->len = (int)strlen(d->buf);
        ti_reset(&d->ti, d->buf);
    }
    d->ok = ok;
    d->cancel = cancel;
    d->ctx = ctx;

    u32 W = fb_width(), H = fb_height();
    int ww = 420, wh = 130;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title ? title : "Ввод", 200, 200, ww, wh,
               fdin_draw, fdin_key, fdin_mouse, NULL, fdin_close, d);
}
