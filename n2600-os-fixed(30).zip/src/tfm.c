/* tfm.c — текстовый файловый менеджер для telnet (реализация, Task 46).
 *
 * См. tfm.h (режимы, команды, встраивание в telnetd). Правила безопасности
 * строк: все snprintf с размерами, склейка путей только через хелпер с
 * проверкой вместимости, индексы <N> проверяются на диапазон 1..nents. */
#include "tfm.h"
#include "string.h"
#include "mem.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

/* ---------------- утилиты ---------------- */

typedef struct {
    void (*out)(void *ud, const char *s);
    void *ud;
} tfm_io_t;

static void tfm_ed_open(tfm_t *f, tfm_io_t *io);   /* вперед: редактор */

static void tfm_say(tfm_io_t *io, const char *s)
{
    io->out(io->ud, s);
}

/* dir + "/" + name (ramfs-путь без ведущего слеша). 0 = не влезло. */
static int tfm_join(char *out, int cap, const char *dir, const char *name)
{
    if (!dir[0]) {
        if ((int)strlen(name) >= cap) return 0;
        strcpy(out, name);
        return 1;
    }
    if (snprintf(out, (u32)cap, "%s/%s", dir, name) >= cap) return 0;
    return 1;
}

/* показать путь с ведущим слешем */
static void tfm_show(const char *path, char *out, int cap)
{
    if (!path[0]) snprintf(out, (u32)cap, "/");
    else          snprintf(out, (u32)cap, "/%s", path);
}

/* Разрешить arg относительно cwd (как в терминале: ".", "..", "/..."). */
static int tfm_resolve(const char *cwd, const char *arg, char *out, int cap)
{
    char acc[TFM_CWD_MAX + TFM_NAME_MAX + 2];
    if (arg[0] == '/') acc[0] = 0;
    else snprintf(acc, sizeof(acc), "%s", cwd);
    const char *p = arg;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        char comp[TFM_NAME_MAX + 1];
        int ci = 0;
        while (*p && *p != '/' && ci < (int)sizeof(comp) - 1)
            comp[ci++] = *p++;
        comp[ci] = 0;
        if (!strcmp(comp, ".")) continue;
        if (!strcmp(comp, "..")) {
            char *sl = strrchr(acc, '/');
            if (sl) *sl = 0;
            else    acc[0] = 0;
            continue;
        }
        int L = (int)strlen(acc);
        if (L + 1 + ci >= (int)sizeof(acc)) return 0;
        if (L) acc[L++] = '/';
        strcpy(acc + L, comp);
    }
    if ((int)strlen(acc) >= cap) return 0;
    strcpy(out, acc);
    return 1;
}

static int tfm_is_dir(const char *path)
{
    if (!path[0]) return 1;
    ramfs_dirent_t de;
    if (!ramfs_stat_ci(path, &de)) return 0;
    return de.is_dir ? 1 : 0;
}

/* перечитать кэш каталога cwd; 1 = ок */
static int tfm_scan(tfm_t *f)
{
    f->nents = ramfs_list_dir(f->cwd[0] ? f->cwd : "/", f->ents, TFM_ENTS_MAX);
    return 1;
}

/* номер -> запись кэша (1..nents); NULL мимо */
static ramfs_dirent_t *tfm_pick(tfm_t *f, const char *num)
{
    if (!num || !*num) return NULL;
    int idx = 0;
    for (const char *p = num; *p >= '0' && *p <= '9'; p++)
        idx = idx * 10 + (*p - '0');
    if (idx <= 0 || idx > f->nents) return NULL;
    return &f->ents[idx - 1];
}

/* ---------------- меню каталога ---------------- */

static void tfm_show_cwd(tfm_t *f, tfm_io_t *io)
{
    char show[TFM_CWD_MAX + 2], line[TFM_CWD_MAX + 24];
    tfm_show(f->cwd, show, (int)sizeof(show));
    snprintf(line, sizeof(line), "Каталог: %s", show);
    tfm_say(io, line);
}

static void tfm_ls(tfm_t *f, tfm_io_t *io)
{
    if (!ramfs_ready()) { tfm_say(io, "RAM disk недоступен"); return; }
    tfm_scan(f);
    if (f->nents == 0) {
        tfm_say(io, "(пусто)");
        return;
    }
    char line[TFM_NAME_MAX + 48];
    int nd = 0, nf = 0;
    /* сначала каталоги, потом файлы; номера — для open/del/cat/edit */
    for (int pass = 0; pass < 2; pass++) {
        for (int i = 0; i < f->nents; i++) {
            ramfs_dirent_t *e = &f->ents[i];
            if ((pass == 0) != (e->is_dir != 0)) continue;
            if (e->is_dir) {
                nd++;
                snprintf(line, sizeof(line), " %2d. %s/", i + 1, e->name);
            } else {
                nf++;
                snprintf(line, sizeof(line), " %2d. %s (%u байт)",
                         i + 1, e->name, (unsigned)e->size);
            }
            tfm_say(io, line);
        }
    }
    snprintf(line, sizeof(line), "Итого: %d каталог(ов), %d файл(ов)", nd, nf);
    tfm_say(io, line);
}

static void tfm_menu_help(tfm_io_t *io)
{
    tfm_say(io, "Файловый менеджер (RAM disk). Команды:");
    tfm_say(io, "  ls          - список (с номерами)");
    tfm_say(io, "  cd <имя>    - войти в каталог (cd .. наверх, cd — в корень)");
    tfm_say(io, "  open <N>    - каталог N открыть, текстовый файл N показать");
    tfm_say(io, "  edit <N>    - править файл N в построчном редакторе");
    tfm_say(io, "  new <имя>   - создать текстовый файл и открыть редактор");
    tfm_say(io, "  mkdir <имя> - создать каталог");
    tfm_say(io, "  del <N>     - удалить файл/пустой каталог N");
    tfm_say(io, "  info        - место на RAM disk");
    tfm_say(io, "  q           - выход в shell");
}

static void tfm_menu_cmd(tfm_t *f, char *cmd, tfm_io_t *io)
{
    /* разбор: первое слово, остальное — аргумент */
    char *sp = cmd;
    while (*sp && *sp != ' ') sp++;
    char *arg = NULL;
    if (*sp) { *sp = 0; arg = sp + 1; while (*arg == ' ') arg++; }

    char show[TFM_CWD_MAX + 2], path[TFM_CWD_MAX + TFM_NAME_MAX + 2];
    char line[TFM_NAME_MAX + 80];

    if (!strcmp(cmd, "q") || !strcmp(cmd, "quit") || !strcmp(cmd, "exit")) {
        f->mode = 0;
        tfm_say(io, "Выход из файлового менеджера (help — список команд)");
        return;
    }
    if (!*cmd || !strcmp(cmd, "ls")) { tfm_ls(f, io); return; }
    if (!strcmp(cmd, "help") || !strcmp(cmd, "?")) { tfm_menu_help(io); return; }
    if (!strcmp(cmd, "info")) {
        u32 tot = ramfs_total_space(), fr = ramfs_free_space();
        snprintf(line, sizeof(line),
                 "RAM disk: %u КиБ всего, свободно %u КиБ, файлов %d",
                 (unsigned)(tot / 1024), (unsigned)(fr / 1024),
                 ramfs_file_count());
        tfm_say(io, line);
        return;
    }
    if (!strcmp(cmd, "cd")) {
        if (!arg || !*arg) { f->cwd[0] = 0; tfm_show_cwd(f, io); return; }
        if (!tfm_resolve(f->cwd, arg, path, (int)sizeof(path))) {
            tfm_say(io, "Слишком длинный путь");
            return;
        }
        if (!tfm_is_dir(path)) {
            tfm_show(path, show, (int)sizeof(show));
            snprintf(line, sizeof(line), "Нет такого каталога: %s", show);
            tfm_say(io, line);
            return;
        }
        if (strlen(path) < sizeof(f->cwd))
            snprintf(f->cwd, sizeof(f->cwd), "%s", path);
        else { tfm_say(io, "Слишком длинный путь"); return; }
        tfm_show_cwd(f, io);
        tfm_ls(f, io);
        return;
    }
    if (!strcmp(cmd, "mkdir")) {
        if (!arg || !*arg) { tfm_say(io, "Использование: mkdir <имя>"); return; }
        if (!tfm_resolve(f->cwd, arg, path, (int)sizeof(path))) {
            tfm_say(io, "Слишком длинный путь");
            return;
        }
        if (ramfs_mkdir(path)) {
            tfm_show(path, show, (int)sizeof(show));
            snprintf(line, sizeof(line), "Каталог создан: %s", show);
            tfm_say(io, line);
        } else {
            tfm_say(io, "Не удалось (родителя нет/имя занято)");
        }
        return;
    }
    if (!strcmp(cmd, "cat") || !strcmp(cmd, "open")) {
        ramfs_dirent_t *e = tfm_pick(f, arg);
        if (!e) { tfm_say(io, "Укажите номер из списка (ls)"); return; }
        if (e->is_dir) {
            /* каталог: войти */
            if (!tfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
                tfm_say(io, "Слишком длинный путь");
                return;
            }
            if (strlen(path) < sizeof(f->cwd))
                snprintf(f->cwd, sizeof(f->cwd), "%s", path);
            else { tfm_say(io, "Слишком длинный путь"); return; }
            tfm_show_cwd(f, io);
            tfm_ls(f, io);
            return;
        }
        /* файл: показать текст (до TFM_CAT_MAX байт) */
        if (!tfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
            tfm_say(io, "Слишком длинный путь");
            return;
        }
        u32 cap = e->size < TFM_CAT_MAX ? e->size : TFM_CAT_MAX;
        char *buf = (char *)malloc(cap + 1);
        if (!buf) { tfm_say(io, "Нет памяти"); return; }
        u32 got = ramfs_read(path, buf, cap);
        buf[got] = 0;
        int binary = 0;
        for (u32 i = 0; i < got && i < 64; i++) {
            u8 b = (u8)buf[i];
            if (b < 32 && b != '\t' && b != '\n' && b != '\r') { binary = 1; break; }
        }
        if (binary) {
            snprintf(line, sizeof(line),
                     "%s: двоичный файл (%u байт) — текст не показан",
                     e->name, (unsigned)e->size);
            tfm_say(io, line);
        } else if (got == 0) {
            tfm_say(io, "(пустой файл)");
        } else {
            for (char *q = buf; *q; q++)                       /* CRLF -> LF */
                if (*q == '\r' && q[1] == '\n') memmove(q, q + 1, strlen(q));
            tfm_say(io, "----- начало -----");
            /* строки по одной: out рассчитан на строку */
            char *p = buf;
            while (*p) {
                char *nl = p;
                while (*nl && *nl != '\n') nl++;
                int L = (int)(nl - p);
                if (L > 96) L = 96;
                char seg[100];
                memcpy(seg, p, (u32)L);
                seg[L] = 0;
                tfm_say(io, seg);
                p = (*nl) ? nl + 1 : nl;
            }
            tfm_say(io, "----- конец -----");
            if (e->size > cap) {
                snprintf(line, sizeof(line), "... (показано %u из %u байт)",
                         (unsigned)cap, (unsigned)e->size);
                tfm_say(io, line);
            }
        }
        free(buf);
        return;
    }
    if (!strcmp(cmd, "edit")) {
        ramfs_dirent_t *e = tfm_pick(f, arg);
        if (!e) { tfm_say(io, "Укажите номер файла из списка (ls)"); return; }
        if (e->is_dir) { tfm_say(io, "Это каталог"); return; }
        if (e->size > TFM_ED_MAX) {
            snprintf(line, sizeof(line), "Файл больше %u КиБ редактор не тянет",
                     (unsigned)(TFM_ED_MAX / 1024));
            tfm_say(io, line);
            return;
        }
        if (!tfm_join(f->ed_path, (int)sizeof(f->ed_path), f->cwd, e->name)) {
            tfm_say(io, "Слишком длинный путь");
            return;
        }
        tfm_ed_open(f, io);
        return;
    }
    if (!strcmp(cmd, "new")) {
        if (!arg || !*arg) { tfm_say(io, "Использование: new <имя.txt>"); return; }
        if (!tfm_resolve(f->cwd, arg, path, (int)sizeof(path))) {
            tfm_say(io, "Слишком длинный путь");
            return;
        }
        /* предупреждение о перезаписи — файл будет открыт в редакторе */
        {
            ramfs_dirent_t ex;
            if (ramfs_stat_ci(path, &ex) && !ex.is_dir)
                tfm_say(io, "Файл уже существует — открываю его содержимое");
        }
        snprintf(f->ed_path, sizeof(f->ed_path), "%s", path);
        tfm_say(io, "Открываю редактор (создать/править)...");
        tfm_ed_open(f, io);
        return;
    }
    if (!strcmp(cmd, "del") || !strcmp(cmd, "rm")) {
        ramfs_dirent_t *e = tfm_pick(f, arg);
        if (!e) { tfm_say(io, "Укажите номер из списка (ls)"); return; }
        if (!tfm_join(path, (int)sizeof(path), f->cwd, e->name)) {
            tfm_say(io, "Слишком длинный путь");
            return;
        }
        if (ramfs_delete(path)) {
            snprintf(line, sizeof(line), "Удалено: %s%s", e->name,
                     e->is_dir ? "/" : "");
            tfm_say(io, line);
            tfm_scan(f);
        } else {
            tfm_say(io, e->is_dir ? "Каталог не пуст (или не найден)"
                                  : "Не удалось удалить (не найден?)");
        }
        return;
    }
    tfm_say(io, "Неизвестная команда менеджера (help — список)");
}

/* ---------------- редактор (построчный) ---------------- */

/* число строк в буфере */
static u32 tfm_ed_lines(const char *b, u32 len)
{
    u32 n = 0;
    for (u32 i = 0; i < len; i++)
        if (b[i] == '\n') n++;
    if (len && b[len - 1] != '\n') n++;     /* хвост без \n — тоже строка */
    return n;
}

/* смещение начала строки no (1-based) и её длина (без \n);
 * 0 = строки нет */
static u32 tfm_ed_line_off(const char *b, u32 len, u32 no, u32 *out_len)
{
    u32 cur = 1, i = 0;
    while (i < len) {
        if (cur == no) {
            u32 j = i;
            while (j < len && b[j] != '\n') j++;
            *out_len = j - i;
            return i;
        }
        while (i < len && b[i] != '\n') i++;
        if (i < len) i++;
        cur++;
    }
    return 0;
}

void tfm_ed_open(tfm_t *f, tfm_io_t *io)
{
    if (f->ed) { tfm_say(io, "Редактор уже открыт (q/wq — выход)"); return; }
    f->ed = (char *)malloc(TFM_ED_MAX);
    if (!f->ed) { tfm_say(io, "Нет памяти под редактор"); return; }
    f->ed_len = 0;
    f->ed_dirty = 0;
    ramfs_dirent_t de;
    if (ramfs_stat_ci(f->ed_path, &de) && !de.is_dir && de.size > 0) {
        u32 cap = de.size < TFM_ED_MAX ? de.size : TFM_ED_MAX;
        f->ed_len = ramfs_read(f->ed_path, f->ed, cap);
        f->ed[f->ed_len] = 0;
    }
    f->mode = 2;
    char show[TFM_CWD_MAX + 2], line[TFM_CWD_MAX + 48];
    tfm_show(f->ed_path, show, (int)sizeof(show));
    snprintf(line, sizeof(line), "Редактор: %s (%u байт, %u строк)",
             show, (unsigned)f->ed_len,
             (unsigned)tfm_ed_lines(f->ed, f->ed_len));
    tfm_say(io, line);
    if (f->ed_len == 0) tfm_say(io, "(файл пуст/новый)");
    tfm_say(io, "Команды: l - список строк; v <N> - показать строку;");
    tfm_say(io, "  s <N> <текст> - заменить строку; a <N> <текст> - вставить ПОСЛЕ строки N (a 0 - в начало);");
    tfm_say(io, "  d <N> - удалить строку; w - записать; wq - записать и выйти; q - выйти БЕЗ записи.");
    tfm_say(io, "  Строка ввода ограничена длиной telnet-строки (~80 символов).");
}

/* вывести строки с номерами (кап 200 строк) */
static void tfm_ed_list(tfm_t *f, tfm_io_t *io)
{
    char line[TFM_NAME_MAX + 24];
    u32 n = tfm_ed_lines(f->ed, f->ed_len);
    if (!n) { tfm_say(io, "(пусто)"); return; }
    u32 shown = 0;
    for (u32 no = 1; no <= n && shown < 200; no++, shown++) {
        u32 L = 0;
        u32 off = tfm_ed_line_off(f->ed, f->ed_len, no, &L);
        if (!off && L == 0 && no > 1) break;
        if (L > 80) L = 80;
        char seg[96];
        memcpy(seg, f->ed + off, L);
        seg[L] = 0;
        snprintf(line, sizeof(line), "%3u| %s", (unsigned)no, seg);
        tfm_say(io, line);
    }
    if (shown < n) {
        snprintf(line, sizeof(line), "... (показано %u из %u строк)", shown, n);
        tfm_say(io, line);
    }
}

/* вставка текста после строки after (0 = в начало; nlines+1 = в конец).
 * Хвост без завершающего \n сначала закрывается \n. 1 = ок. */
static int tfm_ed_insert(tfm_t *f, u32 after, const char *text)
{
    u32 tlen = (u32)strlen(text);
    if (f->ed_len + tlen + 1 > TFM_ED_MAX) return 0;   /* +1 под '\n' */
    u32 nlines = tfm_ed_lines(f->ed, f->ed_len);
    u32 off = 0;
    if (after > 0) {
        if (after <= nlines) {
            u32 L;
            off = tfm_ed_line_off(f->ed, f->ed_len, after, &L);
            off += L;                                  /* конец строки after */
            if (off < f->ed_len) off++;                /* за её '\n' */
            else if (off > 0 && f->ed[off - 1] != '\n') {
                /* последняя строка без '\n' — закрыть её */
                if (f->ed_len + 1 > TFM_ED_MAX) return 0;
                f->ed[off] = '\n';
                f->ed_len++;
                off++;
            }
        } else if (after == nlines + 1) {
            /* дописать в конец файла */
            off = f->ed_len;
            if (off > 0 && f->ed[off - 1] != '\n') {
                if (f->ed_len + 1 > TFM_ED_MAX) return 0;
                f->ed[off] = '\n';
                f->ed_len++;
                off++;
            }
        } else return 0;                               /* нет такой строки */
    }
    /* сдвиг хвоста и вписывание текста с '\n' */
    memmove(f->ed + off + tlen + 1, f->ed + off, f->ed_len - off);
    memcpy(f->ed + off, text, tlen);
    f->ed[off + tlen] = '\n';
    f->ed_len += tlen + 1;
    f->ed[f->ed_len] = 0;
    return 1;
}

static int tfm_ed_delete(tfm_t *f, u32 no)
{
    u32 L = 0;
    u32 off = tfm_ed_line_off(f->ed, f->ed_len, no, &L);
    if (!off && L == 0 && no > 1) return 0;
    u32 nl = (off + L < f->ed_len) ? 1 : 0;            /* съесть и \n */
    memmove(f->ed + off, f->ed + off + L + nl, f->ed_len - off - L - nl);
    f->ed_len -= L + nl;
    f->ed[f->ed_len] = 0;
    return 1;
}

static int tfm_ed_replace(tfm_t *f, u32 no, const char *text)
{
    if (!tfm_ed_delete(f, no)) return 0;
    return tfm_ed_insert(f, no - 1, text);
}

static void tfm_ed_save(tfm_t *f, tfm_io_t *io)
{
    if (!ramfs_ready()) { tfm_say(io, "RAM disk недоступен"); return; }
    /* перезапись: создать поверх (create после delete) */
    ramfs_delete(f->ed_path);
    if (!ramfs_create(f->ed_path, f->ed_len ? f->ed_len : 1)) {
        tfm_say(io, "Не удалось создать файл (место/длина имени?)");
        return;
    }
    if (f->ed_len && !ramfs_write(f->ed_path, f->ed, f->ed_len)) {
        ramfs_delete(f->ed_path);
        tfm_say(io, "Ошибка записи");
        return;
    }
    f->ed_dirty = 0;
    char show[TFM_CWD_MAX + 2], line[TFM_CWD_MAX + 40];
    tfm_show(f->ed_path, show, (int)sizeof(show));
    snprintf(line, sizeof(line), "Записано: %s (%u байт)",
             show, (unsigned)f->ed_len);
    tfm_say(io, line);
}

static void tfm_ed_close(tfm_t *f)
{
    if (f->ed) free(f->ed);
    f->ed = 0;
    f->ed_len = 0;
    f->ed_dirty = 0;
    f->mode = 1;
}

static void tfm_ed_cmd(tfm_t *f, char *cmd, tfm_io_t *io)
{
    char line[TFM_NAME_MAX + 40];
    if (!strcmp(cmd, "q") || !strcmp(cmd, "quit")) {
        int was_dirty = f->ed_dirty;
        tfm_ed_close(f);
        tfm_say(io, was_dirty ? "Выход БЕЗ записи (правки потеряны)"
                              : "Выход из редактора");
        return;
    }
    if (!strcmp(cmd, "wq")) { tfm_ed_save(f, io); if (!f->ed_dirty) tfm_ed_close(f); return; }
    if (!strcmp(cmd, "w") || !strcmp(cmd, "write")) { tfm_ed_save(f, io); return; }
    if (!strcmp(cmd, "l") || !strcmp(cmd, "list") || !*cmd) {
        tfm_ed_list(f, io);
        return;
    }
    if (cmd[0] == 'v' && (cmd[1] == ' ' || cmd[1] == 0)) {
        u32 no = 0;
        for (const char *p = cmd + 2; *p >= '0' && *p <= '9'; p++)
            no = no * 10 + (u32)(*p - '0');
        u32 L = 0;
        u32 off = no ? tfm_ed_line_off(f->ed, f->ed_len, no, &L) : 0;
        if (!no || (!off && L == 0 && no > 1)) {
            tfm_say(io, "Нет такой строки (l — список)");
        } else {
            if (L > 80) L = 80;
            char seg[96];
            memcpy(seg, f->ed + off, L);
            seg[L] = 0;
            snprintf(line, sizeof(line), "%3u| %s", (unsigned)no, seg);
            tfm_say(io, line);
        }
        return;
    }
    if ((cmd[0] == 's' || cmd[0] == 'a') && cmd[1] == ' ') {
        /* s|a <N> <текст> */
        u32 no = 0;
        const char *p = cmd + 2;
        while (*p >= '0' && *p <= '9') { no = no * 10 + (u32)(*p - '0'); p++; }
        while (*p == ' ') p++;
        const char *text = p;
        if (!text[0]) { tfm_say(io, "Нужен текст: s|a <N> <текст>"); return; }
        if (cmd[0] == 'a' && no == 0) {
            if (tfm_ed_insert(f, 0, text)) {
                f->ed_dirty = 1;
                tfm_say(io, "Вставлено в начало");
            } else tfm_say(io, "Нет места в буфере");
            return;
        }
        if (no == 0) { tfm_say(io, "Номер строки: 1..N"); return; }
        u32 n = tfm_ed_lines(f->ed, f->ed_len);
        if (no > n + (cmd[0] == 'a' ? 1 : 0)) {
            snprintf(line, sizeof(line), "Строк всего %u (l — список)", n);
            tfm_say(io, line);
            return;
        }
        if (cmd[0] == 's') {
            if (tfm_ed_replace(f, no, text)) {
                f->ed_dirty = 1;
                snprintf(line, sizeof(line), "Строка %u заменена", (unsigned)no);
                tfm_say(io, line);
            } else tfm_say(io, "Нет такой строки");
        } else {
            if (tfm_ed_insert(f, no, text)) {
                f->ed_dirty = 1;
                snprintf(line, sizeof(line), "Вставлено после строки %u",
                         (unsigned)no);
                tfm_say(io, line);
            } else tfm_say(io, "Нет места в буфере");
        }
        return;
    }
    if (cmd[0] == 'd' && cmd[1] == ' ') {
        u32 no = 0;
        for (const char *p = cmd + 2; *p >= '0' && *p <= '9'; p++)
            no = no * 10 + (u32)(*p - '0');
        if (!no || !tfm_ed_delete(f, no)) {
            tfm_say(io, "Нет такой строки (l — список)");
        } else {
            f->ed_dirty = 1;
            snprintf(line, sizeof(line), "Строка %u удалена", (unsigned)no);
            tfm_say(io, line);
        }
        return;
    }
    tfm_say(io, "Неизвестная команда редактора (l, v/s/a/d <N>, w, wq, q)");
}

/* ---------------- общий вход ---------------- */

void tfm_reset(tfm_t *f)
{
    if (f->ed) free(f->ed);
    memset(f, 0, sizeof(*f));
    f->mode = 0;
}

int tfm_active(const tfm_t *f)
{
    return f->mode ? 1 : 0;
}

void tfm_line(tfm_t *f, const char *line,
              void (*out)(void *ud, const char *s), void *ud)
{
    tfm_io_t io = { out, ud };
    if (!f->mode) return;
    char cmd[TFM_CWD_MAX + 8];
    snprintf(cmd, sizeof(cmd), "%s", line ? line : "");
    if (f->mode == 2) { tfm_ed_cmd(f, cmd, &io); return; }
    tfm_menu_cmd(f, cmd, &io);
}
