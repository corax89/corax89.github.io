/* fb.c — вывод в VESA-фреймбуфер: backbuffer -> LFB, dirty-область, шрифт.
 * Размер и адрес фреймбуфера берутся из Multiboot (GRUB сам выставляет
 * видеорежим VESA согласно grub.cfg, включая 1280x600x32). */
#include "fb.h"
#include "font.h"
#include "mem.h"
#include "string.h"
#include "task.h"
#include "smp.h"
#include "utf8.h"
#include "cpu.h"      /* CPUID-диспетчер: cpu_has_sse2 (SIMD-ветки ниже) */

extern void serial_puts(const char *s);   /* [WM_PROFILE] */
extern u32  timer_ticks(void);            /* [WM_PROFILE] */

/* fwd: SSE2-хелперы CPUID-диспетчера (определения — перед fill32).
 * fb_flush_rects использует blit_row_wc_sse2 раньше по тексту. */
static void fill32_sse2(u32 *p, u32 v, u32 n);
static void copy_row_sse2(u32 *dst, const u32 *src, u32 n);
static void blit_row_wc_sse2(u32 *dst, const u32 *src, u32 n);

static u32 fbw = 0, fbh = 0, fbpitch = 0, fbbpp = 0;
static u32 *lfb = NULL;       /* реальный фреймбуфер */
static u32 *back = NULL;      /* Backbuffer экрана (рисуем сюда) */
static u32 *bg = NULL;        /* фон рабочего стола */
/* COMPOSE-буфер (двойная буферизация композитора): wm.c собирает кадр
 * dirty-области ЗДЕСЬ (атомарный снимок состояния всех окон) и одним
 * flush'ем выносит на lfb. Без него частичные перерисовки в back от
 * разных кадров накладывались друг на друга — на экране оставался
 * «лоскутный» микс (чужой заголовок сквозь окно, тело окна сквозь
 * заголовок и т.п.). Если malloc не дал памяти — NULL и композитор
 * работает по-старому (в back). */
static u32 *compose = NULL;
/* [2D-ускорение] compose в VRAM (voodoo3): free() делать нельзя — память
 * не из кучи; буфер принадлежит драйверу. flush2d — аппаратный вынос
 * dirty-прямоугольников compose->LFB (2D-движок карты). */
static int  compose_ext = 0;
static int (*flush2d)(const u32 *src, const fb_drect_t *rects, int n) = NULL;

/* ---------------- по-задачные цели рендера (многопоточный WM) ----------------
 *
 * Активный контекст рендера (цель) — «жivoй» набор глобальных переменных
 * rt_*: примитивы fb_* работают с ним. При переключении задач
 * (task_schedule -> fb_task_switch) текущий контекст сохраняется в запись
 * прежней задачи и загружается запись новой. Задача без canvas (напр.
 * kmain/task0 и внешние loader-приложения без окна) использует экранную
 * запись [0] — разделяемую, как в старой однопоточной модели.
 *
 * Canvas-контексты: marking=0 — примитивы, рисующие в canvas, НЕ трогают
 * dirty-область ЭКРАНА (координаты canvas ≠ координаты экрана); окно само
 * вызывает win_invalidate() -> fb_touch(прямоугольник окна на экране).
 * Экранная запись: marking=1/0 — управление fb_mark_enable/disable теперь
 * касается только текущей цели: touch'и из ДРУГИХ потоков не теряются. */
#define FB_MAX_CANVAS 64   /* сессия 12: было 40 — при множестве окон и c4-
 * програм слоты кончались, attach молча проваливался и окно рисовало
 * ПОВЕРХ экрана (canvas-контекст не подключился) */
typedef struct {
    u32 *base;
    int  w, h;
    int  marking;
    int  cx0, cy0, cx1, cy1;
    int  ox, oy;
} fb_ctx_t;

static fb_ctx_t fb_recs[1 + FB_MAX_CANVAS];  /* [0] = экран, [1..] = canvas */
static fb_ctx_t g_rtctx[SMP_MAX_CPUS];       /* [ядро] = активный контекст */
static u8       fb_tmap[MAX_TASKS];          /* задача -> запись (0 = экран) */

/* СЕССИЯ 75: per-core наборы «активного» контекста. Примитивы fb_*
 * (задачный контекст) работают с набором ядра-исполнителя — под ядровым
 * замком исполняется ровно одна задача, поэтому task_exec_core() даёт
 * корректный набор. Планировщики (контекст IRQ, ядра могут исполняться
 * ОДНОВРЕМЕННО) используют rec_save_at/rec_load_at с ЯВНЫМ набором и
 * короткий спинлок fb_sched_lock. */
#define rt_base   (g_rtctx[task_exec_core()].base)
#define rt_w      (g_rtctx[task_exec_core()].w)
#define rt_h      (g_rtctx[task_exec_core()].h)
#define rt_marking (g_rtctx[task_exec_core()].marking)
#define rt_cx0    (g_rtctx[task_exec_core()].cx0)
#define rt_cy0    (g_rtctx[task_exec_core()].cy0)
#define rt_cx1    (g_rtctx[task_exec_core()].cx1)
#define rt_cy1    (g_rtctx[task_exec_core()].cy1)
#define rt_ox     (g_rtctx[task_exec_core()].ox)
#define rt_oy     (g_rtctx[task_exec_core()].oy)

static volatile int fb_sched_lock = 0;       /* планировщики обоих ядер */

static void rec_save_at(int set, int idx)
{
    fb_recs[idx].base    = g_rtctx[set].base;
    fb_recs[idx].w       = g_rtctx[set].w;
    fb_recs[idx].h       = g_rtctx[set].h;
    fb_recs[idx].marking = g_rtctx[set].marking;
    fb_recs[idx].cx0 = g_rtctx[set].cx0; fb_recs[idx].cy0 = g_rtctx[set].cy0;
    fb_recs[idx].cx1 = g_rtctx[set].cx1; fb_recs[idx].cy1 = g_rtctx[set].cy1;
    fb_recs[idx].ox  = g_rtctx[set].ox;  fb_recs[idx].oy  = g_rtctx[set].oy;
}

static void rec_load_at(int set, int idx)
{
    g_rtctx[set].base    = fb_recs[idx].base;
    g_rtctx[set].w       = fb_recs[idx].w;
    g_rtctx[set].h       = fb_recs[idx].h;
    g_rtctx[set].marking = fb_recs[idx].marking;
    g_rtctx[set].cx0 = fb_recs[idx].cx0; g_rtctx[set].cy0 = fb_recs[idx].cy0;
    g_rtctx[set].cx1 = fb_recs[idx].cx1; g_rtctx[set].cy1 = fb_recs[idx].cy1;
    g_rtctx[set].ox  = fb_recs[idx].ox;  g_rtctx[set].oy  = fb_recs[idx].oy;
}

/* СЕССИЯ 81 [KMAIN-RECOVER]: восстановление fb-конtextа после CPU-исключения
 * в kmain. Композитор мог упасть посреди кадра: rt-цель BSP переключена на
 * compose-буфер (fb_compose_begin), клип сужен до dirty-прямоугольника,
 * marking выключен. Возвращаем набор BSP к ЭКРАННОЙ записи (полный экран,
 * полный клип) — как это делает планировщик при входе в task0 — и
 * планируем полный перерисовочный кадр: прерванный compose не успел
 * вывестись на LFB (композиция льётся одним memcpy в конце), но прямой
 * вывод мимо композитора мог оставить частичные пиксели.
 * Вызывается ТОЛЬКО из exc_panic (idt.c, BSP, IF=0). */
void fb_panic_reset(void)
{
    rec_load_at(0, 0);      /* набор BSP <- экранная запись fb_recs[0] */
    /* Явное включение маркировки: прерванный кадр умер ПОСЛЕ
     * fb_mark_disable() (rt_marking=0), а экранная запись могла быть
     * сохранена планировщиком именно в этом состоянии — тогда ВСЕ
     * fb_touch после восстановления игнорировались бы навсегда
     * (dirty не заполняется, композитор не рисует) — экран «замерзал»
     * при живой системе. */
    g_rtctx[0].marking = 1;
    fb_touch_all();         /* следующий кадр kmain — полная перерисовка */
}

/* Вызывается из task_schedule (контекст IRQ0 BSP, IF=0).
 * Спинлок: на AP одновременно может исполняться свой планировщик —
 * без него rec_save/rec_load разных ядер перемешали бы контексты. */
void fb_task_switch(int from_task, int to_task)
{
    if (from_task == to_task) return;
    if (from_task < 0 || from_task >= MAX_TASKS) return;
    if (to_task < 0 || to_task >= MAX_TASKS) return;
    while (!smp_trylock(&fb_sched_lock)) __asm__ __volatile__("pause");
    rec_save_at(0, fb_tmap[from_task] ? fb_tmap[from_task] : 0);
    rec_load_at(0, fb_tmap[to_task] ? fb_tmap[to_task] : 0);
    smp_spin_unlock(&fb_sched_lock);
}

/* СЕССИЯ 75: переключение контекста на AP-ядре (из task_ap_schedule).
 * from_task = -1 — вход из idle (сохранять нечего); to_task = -1 —
 * выход в idle (загрузить экранную запись — idle не рисует, это просто
 * консистентное состояние набора ядра). */
void fb_task_switch_ap(int from_task, int to_task, int core)
{
    if (core <= 0 || core >= SMP_MAX_CPUS) return;
    if (from_task == to_task) return;
    while (!smp_trylock(&fb_sched_lock)) __asm__ __volatile__("pause");
    if (from_task >= 0 && from_task < MAX_TASKS)
        rec_save_at(core, fb_tmap[from_task] ? fb_tmap[from_task] : 0);
    rec_load_at(core, (to_task >= 0 && to_task < MAX_TASKS)
                          ? (fb_tmap[to_task] ? fb_tmap[to_task] : 0) : 0);
    smp_spin_unlock(&fb_sched_lock);
}

int fb_task_canvas_attach(int task, u32 *mem, int w, int h)
{
    if (task <= 0 || task >= MAX_TASKS || !mem || w <= 0 || h <= 0)
        return 0;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");

    /* слот уже занят чужим canvas (задачу убили, она не успела
     * отсоединиться) — освобождаем старую запись */
    if (fb_tmap[task]) {
        fb_recs[fb_tmap[task]].base = NULL;
        fb_tmap[task] = 0;
    }

    int idx = -1;
    for (int i = 1; i <= FB_MAX_CANVAS; i++) {
        if (!fb_recs[i].base) { idx = i; break; }
    }
    if (idx > 0) {
        fb_recs[idx].base    = mem;
        fb_recs[idx].w       = w;
        fb_recs[idx].h       = h;
        fb_recs[idx].marking = 0;
        fb_recs[idx].cx0 = 0; fb_recs[idx].cy0 = 0;
        fb_recs[idx].cx1 = w - 1; fb_recs[idx].cy1 = h - 1;
        fb_recs[idx].ox  = 0; fb_recs[idx].oy  = 0;
        fb_tmap[task] = (u8)idx;
        /* FIX (c4gfx): attach ИЗ КОНТЕКСТА САМОЙ задачи (ленивое окно
         * графики c4-программы) — canvas должен стать активной целью
         * НЕМЕДЛЕННО: следующий fb_task_switch в эту задачу случится
         * только после вытеснения, а программа рисует ПРЯМО СЕЙЧАС.
         * Раньше rt_base оставался экраном и рисунок уходил мимо
         * canvas (композитор его стирал). */
        if (task_current() == task) rec_load_at(task_exec_core(), idx);
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return idx > 0;
}

void fb_task_canvas_detach(int task)
{
    if (task <= 0 || task >= MAX_TASKS) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (fb_tmap[task]) {
        fb_recs[fb_tmap[task]].base = NULL;
        fb_tmap[task] = 0;
        /* если отсоединяемся сами (текущая задача) — сразу вернуть
         * экранную запись, чтобы дальнейший вывод шёл на экран */
        if (task_current() == task) rec_load_at(task_exec_core(), 0);
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* Сессия 12: есть ли у задачи подключённый canvas? Поток окна ждёт
 * этого ПЕРЕД первым рисованием: между task_spawn() и attach() в
 * win_create() нас может вытеснить, и рисование без canvas ушло бы
 * в ЭКРАННЫЙ контекст — прямо поверх чужих окон (это и было
 * «окна прорисовываются сквозь друг друга»). */
int fb_task_has_canvas(int task)
{
    if (task <= 0 || task >= MAX_TASKS) return 0;
    return fb_tmap[task] != 0;
}

/* dirty-область кадра — СПИСОК прямоугольников (см. блок ниже) */

static int glyph_index(unsigned cp)
{
    if (cp >= 0x20 && cp <= 0x7E)  return (int)cp - 0x20;
    if (cp >= 0x410 && cp <= 0x44F) return 95 + (int)cp - 0x410;
    switch (cp) {
    case 0x401: return 159; /* Ё */
    case 0x451: return 160; /* ё */
    case 0x0AB: return 161; /* « */
    case 0x0BB: return 162; /* » */
    case 0x0B0: return 163; /* ° */
    /* иконки/символы интерфейса, добавленные в шрифт (запрос пользователя:
     * «какие иконки из ui отсутствуют в шрифте — добавить») */
    case 0x2014: return 164; /* — длинное тире (тексты UI) */
    case 0x2022: return 165; /* • маркер списка (плеер) */
    case 0x2191: return 166; /* ↑ вверх (терминал/подсказки) */
    case 0x2192: return 167; /* → вправо (терминал/подсказки) */
    case 0x2193: return 168; /* ↓ вниз (терминал/подсказки) */
    case 0x2026: return 169; /* … многоточие (плейлист) */
    case 0x25B6: return 170; /* ▶ играть (плеер) */
    case 0x25C0: return 171; /* ◀ предыдущий (плеер) */
    /* Session 92: псевдографика таблиц/списков/селекта/прогресса */
    case 0x2500: return 172; /* ─ */
    case 0x2502: return 173; /* │ */
    case 0x250C: return 174; /* ┌ */
    case 0x2510: return 175; /* ┐ */
    case 0x2514: return 176; /* └ */
    case 0x2518: return 177; /* ┘ */
    case 0x251C: return 178; /* ├ */
    case 0x2524: return 179; /* ┤ */
    case 0x252C: return 180; /* ┬ */
    case 0x2534: return 181; /* ┴ */
    case 0x253C: return 182; /* ┼ */
    case 0x25E6: return 183; /* ◦ маркер уровня 2 */
    case 0x25AA: return 184; /* ▪ маркер уровня 3 */
    case 0x25BC: return 185; /* ▼ раскрытый select */
    case 0x2588: return 186; /* █ полный блок (прогресс) */
    case 0x2591: return 187; /* ░ светлый блок (прогресс) */
    /* Session 94 [FONT-ENT]: символы entities/cp1251/NBSP/SHY,
     * индексы продолжают Session 92 (188..) */
    case 0x00A0: return 188; /* NBSP */
    case 0x00A2: return 189; /* ¢ */
    case 0x00A3: return 190; /* £ */
    case 0x00A5: return 191; /* ¥ */
    case 0x00A7: return 192; /* § */
    case 0x00A9: return 193; /* © */
    case 0x00AE: return 194; /* ® */
    case 0x00AD: return 195; /* SOFT */
    case 0x00B1: return 196; /* ± */
    case 0x00B6: return 197; /* ¶ */
    case 0x00B7: return 198; /* · */
    case 0x00D7: return 199; /* × */
    case 0x00F7: return 200; /* ÷ */
    case 0x2013: return 201; /* – */
    case 0x2018: return 202; /* ‘ */
    case 0x2019: return 203; /* ’ */
    case 0x201C: return 204; /* “ */
    case 0x201D: return 205; /* ” */
    case 0x20AC: return 206; /* € */
    case 0x2116: return 207; /* № */
    case 0x2122: return 208; /* ™ */
    case 0x2190: return 209; /* ← */
    /* Session 97 [FONT-UPTRI]: ▲ — зеркало ▼ (стрелки/сортировка) */
    case 0x25B2: return 210; /* ▲ */
    }
    return -1;
}

/* Общая настройка геометрии и буферов (fb_init и fb_reinit).
 * При повторном вызове старые back/bg/compose освобождаются.
 * [GMA3600]: fb_reinit вызывается из kmain после нативного переключения
 * режима (1024x600 на Cedarview) — LFB остётся тем же (адрес от
 * загрузчика), меняются только размеры/pitch и буферы. */
static int fb_setup(u32 *lfb_addr, u32 w, u32 h, u32 pitch, u32 bpp)
{
    if (back)    { free(back);    back = NULL; }
    if (bg)      { free(bg);      bg = NULL; }
    if (compose) {
        if (!compose_ext) free(compose);   /* VRAM-буфер кучи не принадлежит */
        compose = NULL;
        compose_ext = 0;
    }
    flush2d = NULL;   /* новая геометрия — аппаратный путь переустановит сам */

    fbw = w;
    fbh = h;
    fbpitch = pitch;
    fbbpp = bpp;
    lfb = lfb_addr;

    /* Backbuffer всегда 32-битный (внутренний формат), конвертируем при flush. */
    back = (u32 *)malloc(fbw * fbh * 4);
    bg = (u32 *)malloc(fbw * fbh * 4);
    compose = (u32 *)malloc(fbw * fbh * 4);   /* не критично: NULL → fallback */
    if (!back || !bg) return 0;

    /* Сессия 56: буферы из кучи НЕ обнуляются — заливаем ЧЁРНЫМ (bg/compose
     * тоже — fb_make_bg перестроит bg). */
    memset(back, 0, (u32)fbw * fbh * 4);
    memset(bg, 0, (u32)fbw * fbh * 4);
    if (compose) memset(compose, 0, (u32)fbw * fbh * 4);

    /* экранная запись контекста [0] */
    fb_recs[0].base    = back;
    fb_recs[0].w       = (int)fbw;
    fb_recs[0].h       = (int)fbh;
    fb_recs[0].marking = 1;
    fb_recs[0].cx0 = 0; fb_recs[0].cy0 = 0;
    fb_recs[0].cx1 = (int)fbw - 1; fb_recs[0].cy1 = (int)fbh - 1;
    fb_recs[0].ox  = 0; fb_recs[0].oy  = 0;
    for (int i = 0; i < MAX_TASKS; i++) fb_tmap[i] = 0;
    /* СЕССИЯ 75: экранная запись — активный контекст ВСЕХ ядер (до
     * первого переключения задач AP-ядро рисует «в экран», как BSP). */
    for (int c = 0; c < SMP_MAX_CPUS; c++) rec_load_at(c, 0);

    fb_set_clip(0, 0, (int)fbw - 1, (int)fbh - 1);
    fb_touch_all();
    return 1;
}

int fb_init(const mb_info_t *mb)
{
    int have_mb = (mb->flags & MBIF_FRAMEBUFFER) &&
                  mb->framebuffer_type == MB_FT_RGB &&
                  mb->framebuffer_bpp >= 16 &&
                  mb->framebuffer_addr && mb->framebuffer_width;

    if (!have_mb) {
        /* Headless-фолбэк (сессия 13): эмулятор не выставил VESA (Bochs в
         * некоторых конфигурациях, текстовые VGA). Поднимаем RAM-backed
         * фреймбуфер 1024x768x32: ОС и приложения работают «вслепую», но
         * serial/klog/WM живы — пригодно для автотестов (AUTORUN) и для
         * машин, где GRUB не смог переключить видеорежим. На реальном
         * железе GRUB+VESA даёт настоящий LFB — сюда не попадаем. */
        extern void serial_puts(const char *s);
        serial_puts("[fb] no VESA LFB: headless RAM-фреймбуфер 1024x768\n");
        u32 *head_lfb = (u32 *)malloc(1024u * 768u * 4u);
        if (!head_lfb) return 0;
        return fb_setup(head_lfb, 1024, 768, 1024u * 4u, 32);
    }
    return fb_setup((u32 *)(u32)mb->framebuffer_addr,
                    mb->framebuffer_width, mb->framebuffer_height,
                    mb->framebuffer_pitch, mb->framebuffer_bpp);
}

int fb_reinit(u64 addr, u32 w, u32 h, u32 pitch, u32 bpp)
{
    return fb_setup((u32 *)(u32)addr, w, h, pitch, bpp);
}

int fb_ready(void) { return back != NULL; }
u32 fb_rgb(u8 r, u8 g, u8 b) { return 0xFF000000u | ((u32)r << 16) | ((u32)g << 8) | b; }
u32 fb_width(void)  { return fbw; }
u32 fb_height(void) { return fbh; }
u32 fb_bpp(void)    { return fbbpp; }
u32 fb_pitch(void)  { return fbpitch; }

/* CPU-адрес LFB (для аппаратного курсора GMA3600: битмап пишется в
 * офф-скрин области ПОВЕРХНОСТИ кадра, см. gma3600_2d.c) */
void *fb_lfb_addr(void) { return (void *)lfb; }

/* Прокрутка экрана вверх на px пикселей (консоль загрузки).
 * Сдвигаем backbuffer, нижнюю полосу очищаем. Вызывающий код затем
 * рисует новую строку лога внизу и делает fb_flush(). Без этого
 * загрузочный лог при >45 строках (1024x768) уходил за нижний край
 * экрана и его было не прочитать. */
void fb_scroll_up(int px)
{
    if (!back || px <= 0) return;
    if ((u32)px > fbh) px = (int)fbh;
    u32 rows = fbh - (u32)px;
    if (rows)
        memmove(back, back + (u32)px * fbw, rows * fbw * 4);
    fb_fill_rect(0, (int)fbh - px, (int)fbw, px, fb_rgb(0x00, 0x00, 0x00));
    fb_touch_all();
}

/* ------------------------------ фон стола ------------------------------ */

void fb_make_bg(void)
{
    u32 top = fb_rgb(0x21, 0x26, 0x2D);
    u32 bot = fb_rgb(0x0B, 0x0D, 0x10);
    for (u32 y = 0; y < fbh; y++) {
        u32 t = (y * 256u) / (fbh ? fbh : 1);
        u32 r = ((top >> 16) & 0xFF) + ((((bot >> 16) & 0xFF) - ((top >> 16) & 0xFF)) * t) / 256;
        u32 g = ((top >> 8) & 0xFF) + ((((bot >> 8) & 0xFF) - ((top >> 8) & 0xFF)) * t) / 256;
        u32 b = (top & 0xFF) + (((bot & 0xFF) - (top & 0xFF)) * t) / 256;
        u32 c = fb_rgb((u8)r, (u8)g, (u8)b);
        u32 *row = bg + (u32)y * fbw;
        for (u32 x = 0; x < fbw; x++) row[x] = c;
    }
    /* едва заметный водяной знак */
    const char *wm = "N2600-OS";
    u32 wc = fb_rgb(0x19, 0x1E, 0x25);
    u32 tw = fb_text_w(wm);
    fb_text((int)fbw - tw - 24, (int)fbh - 28 - 16 - 24, wm, wc, -1);
}

/* ---------------------------- dirty-область ----------------------------
 * СПИСОК прямоугольников (до FB_DIRTY_MAX, тип в fb.h) вместо одного
 * bbox: курсор, бегущий по диагонали, раздувал bbox почти до всего
 * экрана, и каждый кадр перерисовывал его целиком — на медленных
 * устройствах (Atom N2600) это съедало весь CPU. Теперь точечные
 * обновления остаются точечными. При переполнении списка два
 * прямоугольника с минимальной площадью объединения сливаются. */
static fb_drect_t d_rects[FB_DIRTY_MAX];
static int        d_nrects = 0;

void fb_mark_enable(void)  { rt_marking = 1; }
void fb_mark_disable(void) { rt_marking = 0; }

/* добавить прямоугольник в список (со слиянием пересечений) */
static void drect_add(int x0, int y0, int x1, int y1)
{
    int i;
    for (i = 0; i < d_nrects; i++) {
        if (x0 <= d_rects[i].x1 + 1 && d_rects[i].x0 - 1 <= x1 &&
            y0 <= d_rects[i].y1 + 1 && d_rects[i].y0 - 1 <= y1) {
            if (x0 < d_rects[i].x0) d_rects[i].x0 = x0;
            if (y0 < d_rects[i].y0) d_rects[i].y0 = y0;
            if (x1 > d_rects[i].x1) d_rects[i].x1 = x1;
            if (y1 > d_rects[i].y1) d_rects[i].y1 = y1;
            return;
        }
    }
    if (d_nrects < FB_DIRTY_MAX) {
        d_rects[d_nrects].x0 = x0; d_rects[d_nrects].y0 = y0;
        d_rects[d_nrects].x1 = x1; d_rects[d_nrects].y1 = y1;
        d_nrects++;
        return;
    }
    /* ПЕРФ (запрос пользователя): переполнение больше НЕ ищет лучшую
     * пару за O(N^2) под cli — fb_touch зовётся с выключенными
     * прерываниями из любого потока. Вместо этого новый прямоугольник
     * ПОГЛОЩАЕТСЯ тем из имеющихся, с которым площадь объединения
     * минимальна (O(N), N = FB_DIRTY_MAX = 12 — копейки). Кадр станет
     * чуть крупнее, но микро-фризы при активной мыши исчезают. */
    int bi = 0;
    long best = 0x7FFFFFFFL;
    for (i = 0; i < d_nrects; i++) {
        int ux0 = (d_rects[i].x0 < x0) ? d_rects[i].x0 : x0;
        int uy0 = (d_rects[i].y0 < y0) ? d_rects[i].y0 : y0;
        int ux1 = (d_rects[i].x1 > x1) ? d_rects[i].x1 : x1;
        int uy1 = (d_rects[i].y1 > y1) ? d_rects[i].y1 : y1;
        long area = (long)(ux1 - ux0 + 1) * (long)(uy1 - uy0 + 1);
        if (area < best) { best = area; bi = i; }
    }
    if (x0 < d_rects[bi].x0) d_rects[bi].x0 = x0;
    if (y0 < d_rects[bi].y0) d_rects[bi].y0 = y0;
    if (x1 > d_rects[bi].x1) d_rects[bi].x1 = x1;
    if (y1 > d_rects[bi].y1) d_rects[bi].y1 = y1;
}

void fb_touch(int x, int y, int w, int h)
{
    /* ЯВНАЯ отметка ЭКРАННОЙ области (в отличие от авто-touch примитивов):
     * работает из ЛЮБОГО контекста (поток окна помечает свой прямоугольник
     * после отрисовки canvas). Была ошибка: раньше touch гейтился rt_marking
     * текущей цели — для canvas-контекста (marking=0) ЯВНЫЕ отметки
     * поглощались, и экран не обновлялся. */
    if (!back) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > (int)fbw) w = (int)fbw - x;
    if (y + h > (int)fbh) h = (int)fbh - y;
    if (w > 0 && h > 0)
        drect_add(x, y, x + w - 1, y + h - 1);
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

void fb_touch_all(void)
{
    if (!rt_marking || !back) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    d_nrects = 1;
    d_rects[0].x0 = 0; d_rects[0].y0 = 0;
    d_rects[0].x1 = (int)fbw - 1; d_rects[0].y1 = (int)fbh - 1;
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

int fb_dirty(int *x0, int *y0, int *x1, int *y1)
{
    if (d_nrects <= 0 || !back) return 0;
    int i, bx0 = d_rects[0].x0, by0 = d_rects[0].y0;
    int bx1 = d_rects[0].x1, by1 = d_rects[0].y1;
    for (i = 1; i < d_nrects; i++) {
        if (d_rects[i].x0 < bx0) bx0 = d_rects[i].x0;
        if (d_rects[i].y0 < by0) by0 = d_rects[i].y0;
        if (d_rects[i].x1 > bx1) bx1 = d_rects[i].x1;
        if (d_rects[i].y1 > by1) by1 = d_rects[i].y1;
    }
    if (x0) *x0 = bx0;
    if (y0) *y0 = by0;
    if (x1) *x1 = bx1;
    if (y1) *y1 = by1;
    return 1;
}

int fb_dirty_count(void) { return d_nrects; }

void fb_dirty_rect(int i, int *x0, int *y0, int *x1, int *y1)
{
    if (i < 0 || i >= d_nrects) return;
    if (x0) *x0 = d_rects[i].x0;
    if (y0) *y0 = d_rects[i].y0;
    if (x1) *x1 = d_rects[i].x1;
    if (y1) *y1 = d_rects[i].y1;
}

/* Атомарно ЗАБРАТЬ список dirty-прямоугольников (cli): wm_frame работает
 * со своим снимком; touch'и во время сборки кадра копятся в свежий список
 * и уйдут в следующий кадр. Возвращает число забранных (≤ max). */
int fb_dirty_take(fb_drect_t *out, int max)
{
    if (!out || max <= 0) return 0;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int n = d_nrects;
    if (n > max) n = max;            /* не бывает: max == FB_DIRTY_MAX */
    for (int i = 0; i < n; i++) out[i] = d_rects[i];
    d_nrects = 0;
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return n;
}

/* Вынести ЗАДАННЫЕ прямоугольники из src (compose-буфер композитора или
 * back) в реальный LFB. src == NULL означает back. Список НЕ очищается
 * (он уже забран fb_dirty_take) — кто звал, тот и владеет. */
void fb_flush_rects(const u32 *src, const fb_drect_t *rects, int n)
{
    if (!lfb || !back) return;
    if (!src) src = back;
    if (!rects || n <= 0) return;

#ifdef WM_PROFILE
    u32 prof_t0 = timer_ticks();
#endif

    /* [2D-ускорение] аппаратный вынос compose->LFB (voodoo3 blit):
     * 1 = все прямоугольники вынесены движком, CPU-копия не нужна.
     * back (RAM) аппаратно недоступен — только compose. */
    if (flush2d && src == compose) {
        if (flush2d(src, rects, n)) return;
    }

    u8 *dst = (u8 *)lfb;
    int used_wc = 0;              /* [CPUID-SIMD]: нужен один sfence на пачку */
    for (int r = 0; r < n; r++) {
        int d_x0 = rects[r].x0, d_y0 = rects[r].y0;
        int d_x1 = rects[r].x1, d_y1 = rects[r].y1;
        int w = d_x1 - d_x0 + 1;
        if (d_x0 < 0 || d_y0 < 0 ||
            d_x1 >= (int)fbw || d_y1 >= (int)fbh || w <= 0) continue;

        if (fbbpp == 32) {
            if (cpu_has_sse2) {
                /* [CPUID-SIMD] уровень 2: RAM->LFB через movntdq —
                 * WC-буферы LFB (mtrr_lfb_wc) реально используются */
                for (int y = d_y0; y <= d_y1; y++)
                    blit_row_wc_sse2(
                        (u32 *)(dst + (u32)y * fbpitch) + (u32)d_x0,
                        src + (u32)y * fbw + (u32)d_x0,
                        (u32)w);
                used_wc = 1;
            } else {
                /* Fast path: прямой memcpy по 4 байта на пиксель */
                for (int y = d_y0; y <= d_y1; y++) {
                    memcpy(dst + (u32)y * fbpitch + (u32)d_x0 * 4,
                           (const u8 *)(src + (u32)y * fbw + (u32)d_x0),
                           (u32)w * 4);
                }
            }
        }
        else if (fbbpp == 24) {
            /* 24bpp: конвертация 0x00RRGGBB → 3 байта (B, G, R) */
            for (int y = d_y0; y <= d_y1; y++) {
                u8 *row = dst + (u32)y * fbpitch + (u32)d_x0 * 3;
                const u32 *s = src + (u32)y * fbw + (u32)d_x0;
                for (int x = 0; x < w; x++) {
                    u32 c = s[x];
                    row[x * 3]     = (u8)(c);          /* B */
                    row[x * 3 + 1] = (u8)(c >> 8);     /* G */
                    row[x * 3 + 2] = (u8)(c >> 16);     /* R */
                }
            }
        }
        else if (fbbpp == 16) {
            /* 16bpp RGB565: конвертация 0x00RRGGBB → 0xRRRRRGGG GGGBBBBB */
            for (int y = d_y0; y <= d_y1; y++) {
                u8 *row = dst + (u32)y * fbpitch + (u32)d_x0 * 2;
                const u32 *s = src + (u32)y * fbw + (u32)d_x0;
                for (int x = 0; x < w; x++) {
                    u32 c = s[x];
                    u8 rr = (u8)((c >> 16) & 0xFF);
                    u8 gg = (u8)((c >> 8) & 0xFF);
                    u8 bb = (u8)(c & 0xFF);
                    u16 rgb565 = (u16)(((rr >> 3) << 11) | ((gg >> 2) << 5) | (bb >> 3));
                    row[x * 2]     = (u8)(rgb565 & 0xFF);
                    row[x * 2 + 1] = (u8)((rgb565 >> 8) & 0xFF);
                }
            }
        }
    }

    /* [CPUID-SIMD]: sfence ОДИН раз после всей пачки movntdq —
     * упорядочивает non-temporal stores относительно последующего
     * чтения LFB (курсор BIOS, скриншоты, 2D-движок) */
    if (used_wc)
        __asm__ __volatile__("sfence" ::: "memory");

#ifdef WM_PROFILE
    prof_fr_sum += timer_ticks() - prof_t0;
    if (++prof_fr_n >= 512) {
        char pb[80];
        snprintf(pb, sizeof(pb), "[fb-prof] flush_rects avg %u ticks (x%u)\n",
                 prof_fr_sum / prof_fr_n, prof_fr_n);
        serial_puts(pb);
        prof_fr_sum = 0;
        prof_fr_n = 0;
    }
#endif
}

/* fb_flush — совместимая обёртка для загрузочного консоли/внекадровых
 * выводов в back (boot-лог, паники, c4gfx, flip). Композитор N2600-OS
 * использует fb_dirty_take + fb_flush_rects. */
void fb_flush(void)
{
    fb_drect_t fr[FB_DIRTY_MAX];
    int n = fb_dirty_take(fr, FB_DIRTY_MAX);
    fb_flush_rects(NULL, fr, n);
}

/* ------------------------------ примитивы ------------------------------ */

/* Авто-отметка примитивов: только если текущая цель — экран с включённым
 * маркированием (не canvas и не composite под mark_disable). */
static void prim_touch(int x, int y, int w, int h)
{
    if (!rt_marking) return;
    fb_touch(x, y, w, h);
}

void fb_set_clip(int x0, int y0, int x1, int y1)
{
    /* Жёстко зажимаем область отсечения в границах ТЕКУЩЕЙ цели рендера
     * (экран или canvas окна). Иначе при выходе за границы пиксели
     * пишутся со «сдвигом на следующую строку» — содержимое появляется
     * с противоположной стороны. */
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > rt_w - 1) x1 = rt_w - 1;
    if (y1 > rt_h - 1) y1 = rt_h - 1;

    rt_cx0 = x0; rt_cy0 = y0; rt_cx1 = x1; rt_cy1 = y1;
}

void fb_set_origin(int ox, int oy)
{
    rt_ox = ox; rt_oy = oy;
}

/* Текущий клип активной цели (для caller-сайд skip'ов: не вызывать
 * fb_text/fb_fill_* там, где клип всё равно всё отсечёт — композитор
 * рисует таскбар/окна в узкий dirty-прямоугольник). */
void fb_get_clip(int *x0, int *y0, int *x1, int *y1)
{
    if (x0) *x0 = rt_cx0;
    if (y0) *y0 = rt_cy0;
    if (x1) *x1 = rt_cx1;
    if (y1) *y1 = rt_cy1;
}

/* Быстрая заливка n пикселей (32 бита каждый): rep stosl покрывает
 * длинные строки одной инструкцией (на Atom это в разы быстрее
 * попиксельного цикла с обобщённой арифметикой указателей). */

/* ---------------- CPUID-диспетчер SIMD (см. cpu.c/cpu.h) ----------------
 * Уровни: 0 = скаляр/rep stosl (SSE нет — всё как раньше, ничего не
 * ломается), 1 = SSE (fxsave в планировщике), 2 = SSE2+ (movdqa/movntdq).
 * Compile-time baseline (-mno-sse...) не даёт компилятору вставить SIMD
 * куда попало; эти функции помечены target("sse2") — SIMD только ЗДЕСЬ.
 * xmm-состояние между задачами сохраняет планировщик (task.c:
 * fxsave/fxrstor), CR4.OSFXSR на каждом ядре ставит cpu_fpu_enable().
 * MMX сознательно НЕ тянем (emms в горячем пути, штраф на переключении). */

/* Уровень 2: заливка для средних n (большие n уже хороши через rep stosl,
 * мелкие — скалярный хвост дешевле настройки xmm). */
__attribute__((target("sse2")))
static void fill32_sse2(u32 *p, u32 v, u32 n)
{
    /* movdqa требует выровненный адрес — головной хвост скалярно */
    while (n && ((u32)(unsigned long)p & 15u)) { *p++ = v; n--; }
    if (n >= 4) {
        u32 blocks = n >> 2;
        __asm__ __volatile__(
            "movd %2, %%xmm0\n\t"
            "pshufd $0, %%xmm0, %%xmm0\n"
            "1:\n\t"
            "movdqa %%xmm0, (%0)\n\t"
            "addl $16, %0\n\t"
            "decl %1\n\t"
            "jnz 1b"
            : "+r"(p), "+r"(blocks)
            : "r"(v)
            : "xmm0", "memory", "cc");
        n &= 3u;
    }
    while (n--) *p++ = v;
}

/* Уровень 2: строка RAM->RAM (fb_blit_bg / fb_sync_back /
 * fb_blit_to_screen в compose). movdqu грузит с любого адреса. */
__attribute__((target("sse2")))
static void copy_row_sse2(u32 *dst, const u32 *src, u32 n)
{
    u32 i = 0;
    u32 blocks = n >> 2;
    if (blocks) {
        u32 *d = dst;
        const u32 *s = src;
        __asm__ __volatile__(
            "1:\n\t"
            "movdqu (%1), %%xmm0\n\t"
            "movdqu %%xmm0, (%0)\n\t"
            "addl $16, %0\n\t"
            "addl $16, %1\n\t"
            "decl %2\n\t"
            "jnz 1b"
            : "+r"(d), "+r"(s), "+r"(blocks)
            :
            : "xmm0", "memory", "cc");
        i = (u32)(unsigned long)(d - dst);
    }
    for (; i < n; i++) dst[i] = src[i];
}

/* Уровень 2: строка RAM->LFB (write-combining) — ГЛАВНЫЙ выигрыш
 * CPUID-диспетчера: movntdq пишет МИМО кэша, и WC-буферы LFB
 * (mtrr_lfb_wc) наконец реально используются; старый memcpy валил в
 * WC-память обычными store — эффект WC не включался, это был главный
 * боттлнек кадра. dst выравнивается на 16 (pitch кратен 4 пикселям на
 * типовых VESA), src произвольный (movdqu). sfence — ОДИН на всю пачку
 * прямоугольников в fb_flush_rects, а не после каждой строки. */
__attribute__((target("sse2")))
static void blit_row_wc_sse2(u32 *dst, const u32 *src, u32 n)
{
    u32 i = 0;
    while (i < n && ((u32)(unsigned long)(dst + i) & 15u)) {
        dst[i] = src[i];
        i++;
    }
    u32 blocks = (n - i) >> 2;
    if (blocks) {
        u32 *d = dst + i;
        const u32 *s = src + i;
        __asm__ __volatile__(
            "1:\n\t"
            "movdqu (%1), %%xmm0\n\t"
            "movntdq %%xmm0, (%0)\n\t"
            "addl $16, %0\n\t"
            "addl $16, %1\n\t"
            "decl %2\n\t"
            "jnz 1b"
            : "+r"(d), "+r"(s), "+r"(blocks)
            :
            : "xmm0", "memory", "cc");
        i = (u32)(unsigned long)(d - dst);
    }
    for (; i < n; i++) dst[i] = src[i];
}

static inline void fill32(u32 *p, u32 v, u32 n)
{
    /* [CPUID-SIMD] уровень 2: SSE2-заливка для средних n */
    if (cpu_has_sse2 && n >= 32 && n < 4096) {
        fill32_sse2(p, v, n);
        return;
    }
#if defined(__i386__) || defined(__x86_64__)
    if (n >= 16) {
        __asm__ __volatile__("rep stosl"
                             : "+D"(p), "+c"(n)
                             : "a"(v)
                             : "memory");
        return;
    }
#endif
    while (n >= 8) {
        p[0] = v; p[1] = v; p[2] = v; p[3] = v;
        p[4] = v; p[5] = v; p[6] = v; p[7] = v;
        p += 8; n -= 8;
    }
    while (n--) *p++ = v;
}

void fb_fill_screen(u32 c) { fb_fill_rect(0, 0, (int)fbw, (int)fbh, c); }

void fb_fill_rect(int x, int y, int w, int h, u32 c)
{
    x += rt_ox; y += rt_oy;
    if (x < rt_cx0) { w -= rt_cx0 - x; x = rt_cx0; }
    if (y < rt_cy0) { h -= rt_cy0 - y; y = rt_cy0; }
    if (x + w - 1 > rt_cx1) w = rt_cx1 - x + 1;
    if (y + h - 1 > rt_cy1) h = rt_cy1 - y + 1;
    if (w <= 0 || h <= 0 || !rt_base) return;
    u32 *row = rt_base + (u32)y * (u32)rt_w + (u32)x;
    if (w == (int)rt_w) {
        /* вся строка — одна сплошная заливка (частый случай:
         * fill_screen, фон окна во всю ширину) */
        fill32(row, c, (u32)w * (u32)h);
    } else {
        for (int yy = 0; yy < h; yy++) {
            fill32(row, c, (u32)w);
            row += rt_w;
        }
    }
    prim_touch(x, y, w, h);
}

void fb_rect(int x, int y, int w, int h, u32 c)
{
    fb_hline(x, x + w - 1, y, c);
    fb_hline(x, x + w - 1, y + h - 1, c);
    fb_vline(x, y, y + h - 1, c);
    fb_vline(x + w - 1, y, y + h - 1, c);
}

void fb_hline(int x0, int x1, int y, u32 c)
{
    x0 += rt_ox; x1 += rt_ox; y += rt_oy;
    if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
    if (x0 < rt_cx0) x0 = rt_cx0;
    if (x1 > rt_cx1) x1 = rt_cx1;
    if (y < rt_cy0 || y > rt_cy1 || x0 > x1 || !rt_base) return;
    fill32(rt_base + (u32)y * (u32)rt_w + (u32)x0, c, (u32)(x1 - x0 + 1));
    prim_touch(x0, y, x1 - x0 + 1, 1);
}

void fb_vline(int x, int y0, int y1, u32 c)
{
    x += rt_ox; y0 += rt_oy; y1 += rt_oy;
    if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
    if (y0 < rt_cy0) y0 = rt_cy0;
    if (y1 > rt_cy1) y1 = rt_cy1;
    if (x < rt_cx0 || x > rt_cx1 || y0 > y1 || !rt_base) return;
    u32 *p = rt_base + (u32)y0 * (u32)rt_w + (u32)x;
    for (int y = y0; y <= y1; y++) {
        *p = c;
        p += rt_w;              /* следующая строка без умножения */
    }
    prim_touch(x, y0, 1, y1 - y0 + 1);
}

void fb_char(int x, int y, unsigned cp, u32 fg, int bg)
{
    x += rt_ox; y += rt_oy;
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];

    /* ПЕРФ (запрос пользователя): раньше каждый пиксель глифа делал
     * умножение y*rt_w + проверку клипа. Теперь: клип глифа целиком
     * вычислен ОДИН раз, указатель строки сдвигается БЕЗ умножения,
     * внутри строки — только записи по биту.
     * Семантика прежняя: строки с bits==0 НЕ заливаются фоном (bg)
     * и пропускаются целиком; пиксели вне клипа не пишутся. */
    if (x + 7 < rt_cx0 || x > rt_cx1 || y + 15 < rt_cy0 || y > rt_cy1)
        return;                             /* глиф целиком вне клипа */
    if (!rt_base) return;

    int rx0 = 0, rx1 = 7;                   /* видимый диапазон столбцов */
    if (x < rt_cx0) rx0 = rt_cx0 - x;
    if (x + 7 > rt_cx1) rx1 = rt_cx1 - x;
    int ry0 = 0, ry1 = 15;
    if (y < rt_cy0) ry0 = rt_cy0 - y;
    if (y + 15 > rt_cy1) ry1 = rt_cy1 - y;

    u32 *row = rt_base + (u32)(y + ry0) * (u32)rt_w + (u32)(x + rx0);
    for (int ry = ry0; ry <= ry1; ry++) {
        u8 bits = g[ry];
        if (bits) {
            for (int rx = rx0; rx <= rx1; rx++) {
                if (bits & (0x80 >> rx))
                    row[rx - rx0] = fg;
                else if (bg >= 0)
                    row[rx - rx0] = (u32)bg;
            }
        }
        row += rt_w;                        /* следующая строка глифа */
    }
    prim_touch(x, y, 8, 16);
}

void fb_char2x(int x, int y, unsigned cp, u32 fg)
{
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];
    for (int ry = 0; ry < 16; ry++) {
        u8 bits = g[ry];
        if (!bits) continue;
        for (int rx = 0; rx < 8; rx++) {
            if (bits & (0x80 >> rx)) {
                fb_fill_rect(x + rx * 2, y + ry * 2, 2, 2, fg);
            }
        }
    }
}

void fb_text(int x, int y, const char *s, u32 fg, int bg)
{
    int cx = x;
    while (*s) {
        unsigned cp = utf8_next(&s);
        if (cp == '\n') break;
        fb_char(cx, y, cp, fg, bg);
        cx += 8;
    }
}

/* [BR-HEAD-2X]: строка шрифтом 2x. Прозрачный фон (bg нет) — заголовки
 * рисуются поверх плашки окна; клип цели применяется внутри fb_fill_rect. */
void fb_text2x(int x, int y, const char *s, u32 fg)
{
    int cx = x;
    while (*s) {
        unsigned cp = utf8_next(&s);
        if (cp == '\n') break;
        fb_char2x(cx, y, cp, fg);
        cx += 16;
    }
}

/* ────── Session 93 [FB-FX]: псевдожирный / псевдокурсив ──────
 * Отдельный глиф в шрифте один (8x16), «жирный» и «курсив» рисуются
 * трансформацией битов на лету:
 *   bold   — бит и его правый сосед (бит |= бит>>1): штрихи толще;
 *   italic — построчный сдвиг вправо до 3 px у верхних строк глифа
 *            (dx = (15-ry)/4): правый наклон, как у курсива.
 * bg<0 — прозрачный фон (штатный случай браузера); при bg>=0 ячейка
 * заливается целиком ДО трансформации (сдвиги не рвут фон). */

void fb_text_fx(int x, int y, const char *s, u32 fg, int bg,
                int bold, int italic)
{
    int cx = x;
    while (*s) {
        unsigned cp = utf8_next(&s);
        if (cp == '\n') break;
        if (!bold && !italic) {
            fb_char(cx, y, cp, fg, bg);
        } else {
            fb_char_fx(cx, y, cp, fg, bg, bold, italic);
        }
        cx += 8;
    }
}

void fb_char_fx(int x, int y, unsigned cp, u32 fg, int bg,
                int bold, int italic)
{
    x += rt_ox; y += rt_oy;
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];

    if (!rt_base) return;

    if (bg >= 0) {
        /* ячейка целиком (трансформация не оставит дыр в фоне) */
        int bx0 = x, by0 = y, bx1 = x + 7 + (italic ? 3 : 0), by1 = y + 15;
        if (bx0 < rt_cx0) bx0 = rt_cx0;
        if (by0 < rt_cy0) by0 = rt_cy0;
        if (bx1 > rt_cx1) bx1 = rt_cx1;
        if (by1 > rt_cy1) by1 = rt_cy1;
        for (int py = by0; py <= by1; py++) {
            u32 *row = rt_base + (u32)py * (u32)rt_w;
            for (int px = bx0; px <= bx1; px++) row[px] = (u32)bg;
        }
        prim_touch(x, y, 9 + (italic ? 3 : 0), 16);
        bg = -1;                       /* дальше только fg */
    }

    for (int ry = 0; ry < 16; ry++) {
        u8 bits = g[ry];
        if (bold) bits |= (u8)(bits >> 1);         /* утолщение вправо */
        if (!bits) continue;
        int dx = italic ? (15 - ry) >> 2 : 0;      /* 0..3 px наклона */
        int py = y + ry;
        if (py < rt_cy0 || py > rt_cy1) continue;
        u32 *row = rt_base + (u32)py * (u32)rt_w;
        for (int rx = 0; rx < 8; rx++) {
            if (!(bits & (0x80 >> rx))) continue;
            int px = x + rx + dx;
            if (px < rt_cx0 || px > rt_cx1) continue;
            row[px] = fg;
        }
    }
    prim_touch(x, y, 8 + (italic ? 3 : 0) + (bold ? 1 : 0), 16);
}

void fb_text_screen_centered(int clip_y0, int y, const char *s, u32 fg)
{
    int x = (int)(fbw - fb_text_w(s)) / 2;
    fb_set_clip(0, clip_y0, (int)fbw - 1, (int)fbh - 1);
    fb_text(x, y, s, fg, -1);
}

u32 fb_text_w(const char *s)
{
    /* Ширина в СИМВОЛАХ, не в байтах: fb_text рисует 8 px на символ,
     * а кириллица в UTF-8 занимает 2 байта. Прежний strlen*8 считал
     * кириллическую строку вдвое шире нарисованной (ломалось
     * центрирование и «правый край» всех окон). */
    return (u32)utf8_count_chars(s, -1) * 8;
}

/* Копировать фон рабочего стола в ТЕКУЩУЮ цель рендера (rt_base).
 * Композитор вызывает это в начале каждого dirty-прямоугольника;
 * с compose-буфером цель — compose, без него — back. */
void fb_blit_bg(int x0, int y0, int x1, int y1)
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 >= (int)fbw) x1 = (int)fbw - 1;
    if (y1 >= (int)fbh) y1 = (int)fbh - 1;
    if (x0 > x1 || y0 > y1 || !bg || !rt_base) return;
#ifdef WM_PROFILE
    u32 prof_t0 = timer_ticks();
#endif
    for (int y = y0; y <= y1; y++) {
        u32 nw = (u32)(x1 - x0 + 1);
        u32 *d = rt_base + (u32)y * fbw + (u32)x0;
        const u32 *s = bg + (u32)y * fbw + (u32)x0;
        /* [CPUID-SIMD] уровень 2: SSE2-копия (x1.5-2 на RAM->RAM) */
        if (cpu_has_sse2) copy_row_sse2(d, s, nw);
        else memcpy(d, s, nw * 4);
    }
#ifdef WM_PROFILE
    prof_bg_sum += timer_ticks() - prof_t0;
    if (++prof_bg_n >= 512) {
        char pb[80];
        snprintf(pb, sizeof(pb), "[fb-prof] blit_bg avg %u ticks (x%u)\n",
                 prof_bg_sum / prof_bg_n, prof_bg_n);
        serial_puts(pb);
        prof_bg_sum = 0;
        prof_bg_n = 0;
    }
#endif
}

/* Blit прямоугольника из произвольного буфера (canvas окна) в ТЕКУЩУЮ
 * цель рендера композитора (compose-буфер, либо back — fallback).
 * Используется ТОЛЬКО композитором wm.c; клип берётся текущий
 * (контекст kmain). */
void fb_blit_to_screen(const u32 *src, int src_w, int src_h,
                        int dx, int dy, int w, int h)
{
    if (!src || !rt_base || w <= 0 || h <= 0 || src_w <= 0 || src_h <= 0)
        return;

    for (int row = 0; row < h; row++) {
        int sy = row;                 /* строка источника */
        int syy = dy + row;           /* строка цели */
        if (syy < rt_cy0 || syy > rt_cy1) continue;    /* вне клипа */
        if (sy < 0 || sy >= src_h) continue;           /* вне источника */

        /* столбцы: пересечение [0,w) источника с клипом цели */
        int sx0 = 0;
        int sx1 = w - 1;
        if (sx1 >= src_w) sx1 = src_w - 1;
        int scr_x0 = dx + sx0;
        int scr_x1 = dx + sx1;
        if (scr_x0 < rt_cx0) { sx0 += rt_cx0 - scr_x0; scr_x0 = rt_cx0; }
        if (scr_x1 > rt_cx1) { sx1 -= scr_x1 - rt_cx1; scr_x1 = rt_cx1; }
        if (scr_x0 > scr_x1 || sx0 > sx1) continue;

        {
            u32 nw = (u32)(sx1 - sx0 + 1);
            u32 *d = rt_base + (u32)syy * (u32)rt_w + (u32)scr_x0;
            const u32 *s = src + (u32)sy * (u32)src_w + (u32)sx0;
            /* [CPUID-SIMD] уровень 2: SSE2-копия строки */
            if (cpu_has_sse2) copy_row_sse2(d, s, nw);
            else memcpy(d, s, nw * 4);
        }
    }
}

/* Blit RGBA8-картинки (стб-декодирование, imgsvc.h) в ТЕКУЩУЮ цель
 * рендера с учётом origin/клипа. Прозрачные пиксели (a<128) пропускаются
 * — сквозь них виден фон страницы/окна. Формат внутреннего буфера
 * XRGB8888 == fb_rgb(); конвертация попиксельная, ЦЕЛОЧИСЛЕННАЯ —
 * функция безопасна в любом потоке БЕЗ лока imgsvc (float не использует;
 * FPU-состояние ядра не сохраняется планировщиком).
 * При dw==sw и dh==sh — прямое копирование; иначе nearest-neighbor
 * (билинейное сглаживание — img_scale(), под локом, до отрисовки). */
void fb_blit_rgba(const u8 *rgba, int sw, int sh,
                  int dx, int dy, int dw, int dh)
{
    if (!rgba || !rt_base || sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0)
        return;

    dx += rt_ox;
    dy += rt_oy;

    /* видимый прямоугольник цели: пересечение [0..dw)x[0..dh) с клипом */
    int vx0 = dx, vy0 = dy;
    int vx1 = dx + dw - 1, vy1 = dy + dh - 1;
    if (vx0 < rt_cx0) vx0 = rt_cx0;
    if (vy0 < rt_cy0) vy0 = rt_cy0;
    if (vx1 > rt_cx1) vx1 = rt_cx1;
    if (vy1 > rt_cy1) vy1 = rt_cy1;
    if (vx0 > vx1 || vy0 > vy1) return;

    for (int y = vy0; y <= vy1; y++) {
        int sy = ((y - dy) * sh) / dh;          /* nearest по вертикали */
        if (sy < 0 || sy >= sh) continue;
        const u8 *srow = rgba + (u32)sy * (u32)sw * 4;
        u32 *drow = rt_base + (u32)y * (u32)rt_w;
        int sx_prev = -1;
        u32 cached = 0;
        for (int x = vx0; x <= vx1; x++) {
            int sx = ((x - dx) * sw) / dw;      /* nearest по горизонтали */
            if (sx < 0 || sx >= sw) continue;
            const u8 *p = srow + (u32)sx * 4;
            if (p[3] < 128) continue;           /* прозрачный — фон сквозь */
            if (sx != sx_prev) {
                cached = 0xFF000000u |
                         ((u32)p[0] << 16) | ((u32)p[1] << 8) | (u32)p[2];
                sx_prev = sx;
            }
            drow[x] = cached;
        }
    }
    prim_touch(vx0, vy0, vx1 - vx0 + 1, vy1 - vy0 + 1);
}

/* ---------- compose-цель композитора (двойная буферизация) ----------
 * wm_frame перед сборкой каждого dirty-прямоугольника переключает
 * rt-цель на compose; все примитивы (включ blit'ы) пишут туда.
 * По завершении — восстановление. Вызывается ТОЛЬКО из kmain
 * (вложенности нет). Если compose не выделился — цель не меняется
 * (композитор честно рисует в back — поведение как раньше). */
static fb_ctx_t compose_save;

#ifdef WM_PROFILE
/* [WM_PROFILE] (запрос пользователя: «профилировать fb_flush_rects и
 * fb_blit_bg и вывести среднее в dmesg/лог»): сборка с -DWM_PROFILE —
 * каждые 512 вызовов функция печатает среднюю стоимость в тиках в
 * serial (видно и в dmesg). Выключено по умолчанию: ноль стоимости
 * в боевом ядре. */
static u32 prof_fr_sum = 0, prof_fr_n = 0;
static u32 prof_bg_sum = 0, prof_bg_n = 0;
#endif

void fb_compose_begin(int x0, int y0, int x1, int y1)
{
    compose_save.base    = rt_base;
    compose_save.w       = rt_w;
    compose_save.h       = rt_h;
    compose_save.marking = rt_marking;
    compose_save.cx0 = rt_cx0; compose_save.cy0 = rt_cy0;
    compose_save.cx1 = rt_cx1; compose_save.cy1 = rt_cy1;
    compose_save.ox  = rt_ox;  compose_save.oy  = rt_oy;
    if (compose) {
        rt_base = compose;
        rt_w    = (int)fbw;
        rt_h    = (int)fbh;
        rt_ox   = 0;
        rt_oy   = 0;
    }
    /* примитивы в compose не маркируют экран */
    rt_marking = 0;
    rt_cx0 = x0; rt_cy0 = y0; rt_cx1 = x1; rt_cy1 = y1;
}

void fb_compose_end(void)
{
    rt_base    = compose_save.base;
    rt_w       = compose_save.w;
    rt_h       = compose_save.h;
    rt_marking = compose_save.marking;
    rt_cx0 = compose_save.cx0; rt_cy0 = compose_save.cy0;
    rt_cx1 = compose_save.cx1; rt_cy1 = compose_save.cy1;
    rt_ox  = compose_save.ox;  rt_oy  = compose_save.oy;
}

/* Синхронизировать back с фактически выведенным кадром (compose → back).
 * Нужна для прямых выводов МИМО композитора (скриптовые fill_rect/draw_text
 * + flip, паники, c4gfx-фолбэк): они пишут в back и сами делают
 * fb_flush(back→LFB) — back должен отражать АКТУАЛЬНЫЙ экран, иначе их
 * flush покажет устаревший кадр. Вызывается только из wm_frame. */
void fb_sync_back(const fb_drect_t *rects, int n)
{
    if (!back || !compose || !rects || n <= 0) return;
    for (int r = 0; r < n; r++) {
        int x0 = rects[r].x0, y0 = rects[r].y0;
        int x1 = rects[r].x1, y1 = rects[r].y1;
        if (x0 < 0 || y0 < 0 || x1 >= (int)fbw || y1 >= (int)fbh) continue;
        for (int y = y0; y <= y1; y++) {
            u32 nw = (u32)(x1 - x0 + 1);
            u32 *d = back + (u32)y * fbw + (u32)x0;
            const u32 *s = compose + (u32)y * fbw + (u32)x0;
            /* [CPUID-SIMD] уровень 2: SSE2-копия строки */
            if (cpu_has_sse2) copy_row_sse2(d, s, nw);
            else memcpy(d, s, nw * 4);
        }
    }
}

u32 *fb_compose_buf(void) { return compose; }

/* ---------- [2D-ускорение] compose в VRAM + аппаратный вынос ----------
 * fb_compose_alloc: выделить compose заранее (voodoo3_init идёт ДО
 * первого кадра композитора; 0 — композитор работает без compose).
 * fb_compose_relocate: перенести compose в VRAM (старый RAM-буфер
 * освобождается; вызов с NULL возвращает RAM-режим).
 * fb_set_flush2d: хук аппаратного выноса (см. fb_flush_rects). */
int fb_compose_alloc(void)
{
    if (!back) return 0;                    /* геометрия ещё не готова */
    if (!compose) compose = (u32 *)malloc(fbw * fbh * 4);
    return compose != NULL;
}

void fb_compose_relocate(u32 *vram)
{
    if (compose && !compose_ext) free(compose);
    compose     = vram;
    compose_ext = (vram != NULL);
}

void fb_set_flush2d(int (*fn)(const u32 *src, const fb_drect_t *rects, int n))
{
    flush2d = fn;
}
