/* textinput.c — отрисовка виджета ввода текста (Task 64 [TI-WIDGET]).
 * ЯДРО (буфер/курсор/клавиши) — header-only в textinput.h; здесь только
 * fb-примитивы, чтобы хост-тесты ядро виджета собирали без fb.h.
 *
 * Два вида отрисовки:
 *   ti_draw_box    — поле с рамкой (диалоги файлов, формы, скриптовые
 *                    окна, пароль WiFi): фон, рамка (акцент при
 *                    фокусе), текст с окном видимости вокруг курсора,
 *                    мигающая каретка-полоска, режим password ('*').
 *   ti_draw_inline — строка ввода БЕЗ рамки (терминал: "> приглашение"
 *                    уже нарисовано embedder'ом): тот же текст+каретка.
 */
#include "textinput.h"
#include "fb.h"
#include "wm.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#define TI_ROW_H  16

/* Общий хвост отрисовки: маскировка пароля (в buf вызывающего — НЕ
 * меняем виджет), окно видимости, каретка. Возвращает px-позицию
 * каретки относительно x0, или -1 (курсора нет). */
static int ti_draw_text_at(const ti_t *ti, int x0, int y, int max_px,
                           u32 fg, int focused)
{
    char shown[260];
    int max_chars = max_px / TI_CHAR_W;
    if (max_chars < 1) max_chars = 1;
    if (max_chars > (int)sizeof(shown) - 8) max_chars = (int)sizeof(shown) - 8;

    /* окно видимости: виджет держит view_off, пересчитываем (курсор
     * мог остаться на месте, а ширина поля — измениться) */
    int from = ti_view_off((ti_t *)ti, max_chars);
    int total = utf8_count_chars(ti->buf, ti->len);
    int view_chars = total - utf8_count_chars(ti->buf, from);
    if (view_chars > max_chars) view_chars = max_chars;
    if (view_chars < 0) view_chars = 0;

    /* взять view_chars СИМВОЛОВ с позиции from (не рвать UTF-8) */
    int take = utf8_take_bytes(ti->buf + from, ti->len - from, view_chars);
    if (take > (int)sizeof(shown) - 8) take = (int)sizeof(shown) - 8;
    if (take < 0) take = 0;

    /* [TI-SEL]: плашка выделения ПОД текстом (в пароль-режиме диапазон
     * тот же — звёзд столько же, сколько символов) */
    {
        int d0, d1;
        if (ti_sel_px(ti, from, view_chars, &d0, &d1))
            fb_fill_rect(x0 + d0, y, d1 - d0, TI_ROW_H, wm_theme_sel_bg());
    }

    if (ti->password) {
        int nch = utf8_count_chars(ti->buf + from, take);
        if (nch > (int)sizeof(shown) - 2) nch = (int)sizeof(shown) - 2;
        for (int i = 0; i < nch; i++) shown[i] = '*';
        shown[nch] = 0;
    } else {
        for (int i = 0; i < take; i++) shown[i] = ti->buf[from + i];
        shown[take] = 0;
    }
    fb_text(x0, y, shown, fg, -1);

    if (!focused) return -1;
    /* каретка: px = (символов от начала окна до курсора) * 8 */
    int curc = utf8_count_chars(ti->buf, ti->cur);
    int fromc = utf8_count_chars(ti->buf, from);
    int cpos = curc - fromc;
    if (cpos < 0) cpos = 0;
    if (cpos > max_chars) cpos = max_chars;
    return cpos * TI_CHAR_W;
}

/* Поле с рамкой. focused: рамка акцентом + мигающая каретка. */
void ti_draw_box(ti_t *ti, int x, int y, int w, int h, int focused)
{
    fb_fill_rect(x, y, w, h, wm_theme_win_bg());
    fb_rect(x, y, w, h, focused ? wm_theme_accent()
                                : fb_rgb(0x2C, 0x31, 0x38));
    int tx = x + 4, ty = y + (h - TI_ROW_H) / 2 + 1;
    int max_px = w - 8;
    if (max_px < TI_CHAR_W) max_px = TI_CHAR_W;

    int cx = ti_draw_text_at(ti, tx, ty, max_px,
                             focused ? wm_theme_text() : wm_theme_text_dim(),
                             focused);
    if (focused && cx >= 0 && wm_blink())
        fb_fill_rect(tx + cx, ty, 2, TI_ROW_H - 2, wm_theme_text());
}

/* Строка без рамки (терминал). Возвращает px-смещение каретки от x0
 * (embedder рисует каретку сам, если хочет) или -1. */
int ti_draw_inline(ti_t *ti, int x0, int y, int max_px, u32 fg)
{
    int cx = ti_draw_text_at(ti, x0, y, max_px, fg, 1);
    if (cx >= 0 && wm_blink())
        fb_fill_rect(x0 + cx, y, 8, TI_ROW_H, fg);
    return cx;
}

/* ───── [TI-CLIPMENU] контекстное меню поля ввода (см. textinput.h) ───── */

#include "clipboard.h"

void ti_clip_copy(ti_t *ti)
{
    if (!ti) return;
    /* [TI-SEL]: есть выделение — копируем ЕГО, нет — весь текст поля */
    int a, b;
    if (ti_sel_range(ti, &a, &b)) {
        clip_text_set(ti->buf + a, b - a);
        return;
    }
    if (ti->len > 0) clip_text_set(ti->buf, ti->len);
}

/* [TI-SEL]: цель для ti_t.copy_fn — буфер обмена общий (см. textinput.h). */
void ti_clip_set(const char *s, int n)
{
    if (s && n > 0) clip_text_set(s, n);
}

void ti_clip_paste(ti_t *ti)
{
    if (!ti) return;
    const char *t = ti->paste_fn ? ti->paste_fn() : clip_text_get();
    if (t && t[0]) {
        int n = 0;
        while (t[n]) n++;
        ti_insert_bytes(ti, t, n);
    }
}

/* Один слот контекста: меню в системе ОДНО (wm перехватывает весь ввод,
 * пока меню открыто; новое wm_menu_open заменяет прежнее вместе со
 * слотом), поэтому статический слот повторяет семантику g_cmenu. */
static struct {
    ti_t        *ti;
    struct window *win;
} g_ti_mnu;

static void ti_menu_cb(int id, void *uctx)
{
    (void)uctx;    /* слот валиднее: WEV_MENU приходит владельцу, живому
                    * на момент клика; g_ti_mnu перезаписывается только
                    * следующим ti_menu_open (после закрытия текущего) */
    if (id == TI_MNU_COPY)
        ti_clip_copy(g_ti_mnu.ti);
    else if (id == TI_MNU_PASTE)
        ti_clip_paste(g_ti_mnu.ti);
    else if (id == TI_MNU_SELALL)
        ti_sel_all(g_ti_mnu.ti);
    else
        return;
    if (g_ti_mnu.win)
        win_invalidate((window_t *)g_ti_mnu.win);
}

void ti_menu_open(struct window *w, ti_t *ti, int mx, int my)
{
    /* [TI-MENU-STATIC] FIX (сессия 99, критический): массив пунктов был
     * НА СТЕКЕ — wm_menu_open запоминает УКАЗАТЕЛЬ на него и читает
     * массив ПОЗЖЕ (отрисовка меню в композиторе, клики, hit-тест —
     * всё происходит ПОСЛЕ возврата ti_menu_open). Читался мёртвый
     * кадр стека: меню рисовалось мусором/не открывалось/промахивалось
     * кликом. Симптом пользователя: «контекстного меню всё еще нет».
     * Статический слот корректен по семантике wm-меню: оно в системе
     * ОДНО (g_cmenu), новое открытие заменяет прежнее целиком. */
    static wm_menu_item_t it[3];
    if (!w || !ti) return;
    g_ti_mnu.ti  = ti;
    g_ti_mnu.win = w;
    it[0].label    = "Копировать";
    it[0].id       = TI_MNU_COPY;
    it[0].disabled = (u8)(ti->len == 0);   /* выделение subrange len>0 */
    it[1].label    = "Вставить";
    it[1].id       = TI_MNU_PASTE;
    it[1].disabled = (u8)(clip_text_len() == 0);
    /* [TI-SEL] (сессия 100): «выделить всё» — Ctrl+A в клавишах, пункт
     * меню — для мыши; после него «Копировать» даёт весь текст поля */
    it[2].label    = "Выделить всё";
    it[2].id       = TI_MNU_SELALL;
    it[2].disabled = (u8)(ti->len == 0);
    wm_menu_open((window_t *)w, mx, my, it, 3, ti_menu_cb, &g_ti_mnu);
}
