/* assert.h — перехватчик <assert.h> для ядра N2600-OS.
 *
 * Зачем: simplewebp.h (src/simplewebp.h) безусловно делает
 * #include <assert.h> в секции реализации. В freestanding-сборке libc
 * нет, а собственного assert.h у GCC нет (в отличие от stddef.h/
 * stdint.h/stdbool.h). Реализация simplewebp сам assert() НЕ вызывает
 * (проверено: 0 вызовов) — макрос ниже существует только чтобы файл
 * компилировался.
 *
 * На хост-сборках (тесты, __STDC_HOSTED__ != 0) заглушка прозрачна:
 * include_next проводит к настоящей libc-версии.
 */
#ifndef ASSERT_H
#define ASSERT_H

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include_next <assert.h>          /* хост: настоящая libc */
#else
#define assert(x) ((void)0)       /* freestanding: no-op */
#endif

#endif /* ASSERT_H */
