/* gunzip.c — движок распаковки DEFLATE/zlib/gzip (см. gunzip.h).
 *
 * Задача 63: единая точка zlib-кода. Раньше идентичный движок лежал
 * приватной секцией в stb_image.h (public domain zlib decode v0.2,
 * Sean Barrett 2006-11-18) и был доступен только PNG-пути; прошивка
 * RTL8192EU и ini-таблицы Atheros лежали в ядре НЕсжатыми, потому что
 * «достать» inflate было нельзя. Теперь движок здесь — и PNG, и
 * gzip-блобы ядра используют ОДНУ копию кода.
 *
 * Отличия от stb-версии (алгоритм и битовая логика — 1:1):
 *   - имена gz_* вместо stbi__*; типы ядра u8/u16/u32;
 *   - вместо stbi__err(...) — gz_fail (текст ошибки в gz_last_err);
 *   - вывод в фиксированный буфер (переполнение = ошибка), а для
 *     gz_zlib_decode_alloc_hdr — рост буфера x2 через gz_grow
 *     (в ядре нет realloc: malloc+memcpy+free, как stbi_krealloc);
 *   - добавлены обёртки zlib/gzip (RFC 1950/1952) с проверкой
 *     Adler-32/CRC-32/ISIZE — stb умел только «голый» zlib-поток PNG.
 *
 * Freestanding: libc не использует (memcpy/memset — из string.h ядра;
 * GCC вправе вызывать их сам даже в freestanding-режиме). Хост-сборка:
 * -DGZ_HOST.
 */
#include "gunzip.h"

#ifdef GZ_HOST
#include <stdlib.h>
#include <string.h>
#define GZ_MALLOC(sz)      malloc((size_t)(sz))
#define GZ_FREE(p)         free(p)
#else
#include "mem.h"
#include "string.h"
#define GZ_MALLOC(sz)      malloc((u32)(sz))
#define GZ_FREE(p)         free(p)
#endif

/* fast-way is faster to check than jpeg huffman, but slow way is slower */
#define GZ_ZFAST_BITS  9    /* accelerate all cases in default tables */
#define GZ_ZFAST_MASK  ((1 << GZ_ZFAST_BITS) - 1)
#define GZ_ZNSYMS 288       /* number of symbols in literal/length alphabet */

static const char *gz_last_err;

/* Последняя ошибка движка (текст, не владеем) — для логов драйверов.
 * NULL если последняя операция была успешной. */
const char *gz_last_err_pub(void)
{
    return gz_last_err;
}

static int gz_fail(const char *msg)
{
    gz_last_err = msg;
    return 0;
}

void *gz_grow(void *p, gz_u32 oldsz, gz_u32 newsz)
{
    void *q = GZ_MALLOC(newsz);
    if (!q) return NULL;
    if (p) {
        if (oldsz > newsz) oldsz = newsz;
        if (oldsz) memcpy(q, p, oldsz);
        GZ_FREE(p);
    }
    return q;
}

/* ================= huffman-таблицы (fast table + slowpath) ================= */

static gz_u16 gz_bitreverse16(gz_u16 n)
{
    n = ((n & 0xAAAA) >>  1) | ((n & 0x5555) << 1);
    n = ((n & 0xCCCC) >>  2) | ((n & 0x3333) << 2);
    n = ((n & 0xF0F0) >>  4) | ((n & 0x0F0F) << 4);
    n = ((n & 0xFF00) >>  8) | ((n & 0x00FF) << 8);
    return n;
}

static int gz_bit_reverse(int v, int bits)
{
    /* to bit reverse n bits, reverse 16 and shift (напр. 11 бит: сдвиг 5) */
    return gz_bitreverse16((gz_u16)v) >> (16 - bits);
}

typedef struct {
    gz_u16 fast[1 << GZ_ZFAST_BITS];
    gz_u16 firstcode[16];
    int    maxcode[17];
    gz_u16 firstsymbol[16];
    gz_u8  size[GZ_ZNSYMS];
    gz_u16 value[GZ_ZNSYMS];
} gz_huffman;

static int gz_zbuild_huffman(gz_huffman *z, const gz_u8 *sizelist, int num)
{
    int i, k = 0;
    int code, next_code[16], sizes[17];

    /* DEFLATE spec for generating codes */
    memset(sizes, 0, sizeof(sizes));
    memset(z->fast, 0, sizeof(z->fast));
    for (i = 0; i < num; ++i)
        ++sizes[sizelist[i]];
    sizes[0] = 0;
    for (i = 1; i < 16; ++i)
        if (sizes[i] > (1 << i))
            return gz_fail("bad sizes");
    code = 0;
    for (i = 1; i < 16; ++i) {
        next_code[i] = code;
        z->firstcode[i] = (gz_u16)code;
        z->firstsymbol[i] = (gz_u16)k;
        code = (code + sizes[i]);
        if (sizes[i])
            if (code - 1 >= (1 << i)) return gz_fail("bad codelengths");
        z->maxcode[i] = code << (16 - i);  /* preshift for inner loop */
        code <<= 1;
        k += sizes[i];
    }
    z->maxcode[16] = 0x10000; /* sentinel */
    for (i = 0; i < num; ++i) {
        int s = sizelist[i];
        if (s) {
            int c = next_code[s] - z->firstcode[s] + z->firstsymbol[s];
            gz_u16 fastv = (gz_u16)((s << 9) | i);
            z->size[c]  = (gz_u8)s;
            z->value[c] = (gz_u16)i;
            if (s <= GZ_ZFAST_BITS) {
                int j = gz_bit_reverse(next_code[s], s);
                while (j < (1 << GZ_ZFAST_BITS)) {
                    z->fast[j] = fastv;
                    j += (1 << s);
                }
            }
            ++next_code[s];
        }
    }
    return 1;
}

/* ================= битовый поток ================= */

typedef struct {
    const gz_u8 *zbuffer, *zbuffer_end;
    int  num_bits;
    int  hit_zeof_once;
    gz_u32 code_buffer;
    /* Session 95 [GZ-PARTIAL2]: инвариант real_bits == число РЕАЛЬНЫХ
     * битов, находящихся в code_buffer ПРЯМО СЕЙЧАС (num_bits — всего;
     * разница — фиктивные нули после исчерпания ввода). Уменьшается
     * gz_zreceive/gz_zhuffman_decode на длину потреблённого кода;
     * отрицательное значение = код перешёл границу реальных данных
     * (для tolerant-режима — сигнал отката вывода). */
    int  real_bits;

    gz_u8 *zout;
    gz_u8 *zout_start;
    gz_u8 *zout_end;
    int    z_expandable;

    gz_huffman z_length, z_distance;
} gz_zbuf;

static int gz_zeof(gz_zbuf *z)
{
    return (z->zbuffer >= z->zbuffer_end);
}

static gz_u8 gz_zget8(gz_zbuf *z)
{
    return gz_zeof(z) ? 0 : *z->zbuffer++;
}

static void gz_fill_bits(gz_zbuf *z)
{
    do {
        if (z->code_buffer >= (1U << z->num_bits)) {
            z->zbuffer = z->zbuffer_end;  /* treat this as EOF so we fail. */
            return;
        }
        if (gz_zeof(z)) {
            /* [GZ-PARTIAL2]: байт фиктивный (ввод исчерпан) — биты
             * добавляются, real_bits НЕ растёт */
            z->code_buffer |= 0u << z->num_bits;
            z->num_bits += 8;
        } else {
            z->code_buffer |= (unsigned int)*z->zbuffer++ << z->num_bits;
            z->num_bits += 8;
            z->real_bits += 8;        /* [GZ-PARTIAL2] реальный байт */
        }
    } while (z->num_bits <= 24);
}

static unsigned int gz_zreceive(gz_zbuf *z, int n)
{
    unsigned int k;
    if (z->num_bits < n) gz_fill_bits(z);
    k = z->code_buffer & ((1 << n) - 1);
    z->code_buffer >>= n;
    z->num_bits -= n;
    /* [GZ-PARTIAL2]: zreceive — ЕДИНСТВЕННАЯ точка побитового потребления
     * вне хаффман-декода (заголовки блоков, HLIT/HDIST/HCLEN,
     * код-длины, экстра-биты): учёт здесь закрывает и заголовок блока,
     * который раньше оставлял real_bits завышенным на ~800 бит. */
    z->real_bits -= n;
    return k;
}

static int gz_zhuffman_decode_slowpath(gz_zbuf *a, gz_huffman *z)
{
    int b, s, k;
    /* not resolved by fast table, so compute it the slow way
     * use jpeg approach, which requires MSbits at top */
    k = gz_bit_reverse((int)a->code_buffer, 16);
    for (s = GZ_ZFAST_BITS + 1; ; ++s)
        if (k < z->maxcode[s])
            break;
    if (s >= 16) return -1; /* invalid code! */
    /* code size is s, so: */
    b = (k >> (16 - s)) - z->firstcode[s] + z->firstsymbol[s];
    if (b >= GZ_ZNSYMS) return -1; /* some data was corrupt somewhere! */
    if (z->size[b] != s) return -1; /* was originally an assert */
    a->code_buffer >>= s;
    a->num_bits -= s;
    a->real_bits -= s;            /* [GZ-PARTIAL2]: учёт реальных битов */
    return z->value[b];
}

static int gz_zhuffman_decode(gz_zbuf *a, gz_huffman *z)
{
    int b, s;
    if (a->num_bits < 16) {
        if (gz_zeof(a)) {
            if (!a->hit_zeof_once) {
                /* Первый выход на eof: вставляем 16 доп. нулевых бит,
                 * чтобы декодер мог спекулятивно продолжить; если они
                 * реально потребились — real_bits уйдёт в минус и
                 * блок-цикл откатит вывод (gz_parse_huffman_block). */
                a->hit_zeof_once = 1;
                a->num_bits += 16;
            } else {
                return -1; /* prematurely terminated stream */
            }
        } else {
            gz_fill_bits(a);
        }
    }
    b = z->fast[a->code_buffer & GZ_ZFAST_MASK];
    if (b) {
        s = b >> 9;
        a->code_buffer >>= s;
        a->num_bits -= s;
        a->real_bits -= s;        /* [GZ-PARTIAL2]: учёт ЗДЕСЬ — покрывает
                                   * и код-длины заголовка блока, и данные,
                                   * и дистанции (везде, где зовётся декод) */
        return b & 511;
    }
    return gz_zhuffman_decode_slowpath(a, z);
}

static int gz_zexpand(gz_zbuf *z, gz_u8 *zout, int n) /* need room for n bytes */
{
    gz_u8 *q;
    unsigned int cur, limit, old_limit;
    z->zout = zout;
    if (!z->z_expandable) return gz_fail("output buffer limit");
    cur       = (unsigned int)(z->zout - z->zout_start);
    limit = old_limit = (unsigned)(z->zout_end - z->zout_start);
    if (0xFFFFFFFFu - cur < (unsigned)n) return gz_fail("outofmem");
    while (cur + n > limit) {
        if (limit > 0xFFFFFFFFu / 2) return gz_fail("outofmem");
        limit *= 2;
    }
    /* ВАЖНО: старый размер = old_limit (емкость прошлой аллокации),
     * НЕ limit/2 — цикл удвоения может пройти несколько шагов. */
    q = (gz_u8 *)gz_grow(z->zout_start, old_limit, limit);
    if (q == NULL) return gz_fail("outofmem");
    z->zout_start = q;
    z->zout       = q + cur;
    z->zout_end   = q + limit;
    return 1;
}

/* ================= блоки DEFLATE ================= */

static const int gz_zlength_base[31] = {
    3,4,5,6,7,8,9,10,11,13,
    15,17,19,23,27,31,35,43,51,59,
    67,83,99,115,131,163,195,227,258,0,0 };

static const int gz_zlength_extra[31] =
{ 0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0 };

static const int gz_zdist_base[32] = { 1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,
    257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0 };

static const int gz_zdist_extra[32] =
{ 0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13 };

static int gz_parse_huffman_block(gz_zbuf *a)
{
    gz_u8 *zout = a->zout;
    for (;;) {
        /* Session 95 [GZ-PARTIAL2] FIX (критический): раньше a->zout
         * синхронизировался с локальным zout ТОЛЬКО при успешном
         * конце блока (символ 256) — при сбое посреди блока (обрыв
         * потока!) a->zout оставался СТАРЫМ, tolerant-обёртка видела
         * got==0 и теряла ВЕСЬ частично декодированный вывод
         * (симптом: habr.com — «gzip: не распакован (сжато 15447 б,
         * обрыв)» вместо «ОБРЫВ — частично NNNN байт»). Теперь
         * a->zout фиксируется перед КАЖДЫМ выходом по ошибке.
         * Потребление реальных битов учитывается САМИМ декодером
         * (gz_zhuffman_decode/gz_zreceive уменьшают real_bits);
         * real_bits < 0 — код перешёл границу реальных данных
         * (фиктивные нулевые биты): откат вывода ровно на границу. */
        int z = gz_zhuffman_decode(a, &a->z_length);
        if (z < 0) { a->zout = zout; return gz_fail("bad huffman code"); }
        if (a->real_bits < 0) {
            a->zout = zout;
            return gz_fail("real data exhausted");
        }
        if (z < 256) {
            if (zout >= a->zout_end) {
                if (!gz_zexpand(a, zout, 1)) return 0;
                zout = a->zout;
            }
            *zout++ = (gz_u8)z;
        } else {
            gz_u8 *p;
            int len, dist;
            if (z == 256) {
                a->zout = zout;
                if (a->hit_zeof_once && a->num_bits < 16) {
                    /* реально потреблены вставленные «на всякий случай»
                     * 16 бит — поток оборван посреди блока */
                    return gz_fail("unexpected end");
                }
                return 1;
            }
            if (z >= 286) { a->zout = zout; return gz_fail("bad huffman code"); } /* length codes 286/287 */
            z -= 257;
            len = gz_zlength_base[z];
            if (gz_zlength_extra[z])
                len += (int)gz_zreceive(a, gz_zlength_extra[z]);
            if (a->real_bits < 0) { a->zout = zout; return gz_fail("real data exhausted"); }
            z = gz_zhuffman_decode(a, &a->z_distance);
            if (z < 0 || z >= 30) { a->zout = zout; return gz_fail("bad huffman code"); } /* dist codes 30/31 */
            if (a->real_bits < 0) { a->zout = zout; return gz_fail("real data exhausted"); }
            dist = gz_zdist_base[z];
            if (gz_zdist_extra[z])
                dist += (int)gz_zreceive(a, gz_zdist_extra[z]);
            if (a->real_bits < 0) { a->zout = zout; return gz_fail("real data exhausted"); }
            if (zout - a->zout_start < dist) { a->zout = zout; return gz_fail("bad dist"); }
            if (len > a->zout_end - zout) {
                if (!gz_zexpand(a, zout, len)) return 0;
                zout = a->zout;
            }
            p = (gz_u8 *)(zout - dist);
            if (dist == 1) { /* run of one byte; common in images */
                gz_u8 v = *p;
                if (len) { do *zout++ = v; while (--len); }
            } else {
                if (len) { do *zout++ = *p++; while (--len); }
            }
        }
    }
}

static int gz_compute_huffman_codes(gz_zbuf *a)
{
    static const gz_u8 length_dezigzag[19] = { 16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15 };
    gz_huffman z_codelength;
    gz_u8 lencodes[286 + 32 + 137]; /* padding for maximum single op */
    gz_u8 codelength_sizes[19];
    int i, n;

    int hlit  = (int)gz_zreceive(a, 5) + 257;
    int hdist = (int)gz_zreceive(a, 5) + 1;
    int hclen = (int)gz_zreceive(a, 4) + 4;
    int ntot  = hlit + hdist;

    memset(codelength_sizes, 0, sizeof(codelength_sizes));
    for (i = 0; i < hclen; ++i) {
        int s = (int)gz_zreceive(a, 3);
        codelength_sizes[length_dezigzag[i]] = (gz_u8)s;
    }
    if (!gz_zbuild_huffman(&z_codelength, codelength_sizes, 19)) return 0;

    n = 0;
    while (n < ntot) {
        int c = gz_zhuffman_decode(a, &z_codelength);
        if (c < 0 || c >= 19) return gz_fail("bad codelengths");
        if (c < 16)
            lencodes[n++] = (gz_u8)c;
        else {
            gz_u8 fill = 0;
            if (c == 16) {
                c = (int)gz_zreceive(a, 2) + 3;
                if (n == 0) return gz_fail("bad codelengths");
                fill = lencodes[n - 1];
            } else if (c == 17) {
                c = (int)gz_zreceive(a, 3) + 3;
            } else if (c == 18) {
                c = (int)gz_zreceive(a, 7) + 11;
            } else {
                return gz_fail("bad codelengths");
            }
            if (ntot - n < c) return gz_fail("bad codelengths");
            memset(lencodes + n, fill, c);
            n += c;
        }
    }
    if (n != ntot) return gz_fail("bad codelengths");
    if (!gz_zbuild_huffman(&a->z_length,  lencodes, hlit)) return 0;
    if (!gz_zbuild_huffman(&a->z_distance, lencodes + hlit, hdist)) return 0;
    return 1;
}

static int gz_parse_uncompressed_block(gz_zbuf *a)
{
    gz_u8 header[4];
    int len, nlen, k;
    if (a->num_bits & 7)
        gz_zreceive(a, a->num_bits & 7); /* discard */
    /* drain the bit-packed data into header */
    k = 0;
    while (a->num_bits > 0) {
        header[k++] = (gz_u8)(a->code_buffer & 255);
        a->code_buffer >>= 8;
        a->num_bits -= 8;
    }
    a->real_bits = 0;             /* [GZ-PARTIAL2]: буфер битов опустел */
    if (a->num_bits < 0) return gz_fail("zlib corrupt");
    /* now fill header the normal way */
    while (k < 4)
        header[k++] = gz_zget8(a);
    len  = header[1] * 256 + header[0];
    nlen = header[3] * 256 + header[2];
    if (nlen != (len ^ 0xffff)) return gz_fail("zlib corrupt");
    if (a->zbuffer + len > a->zbuffer_end) return gz_fail("read past buffer");
    if (a->zout + len > a->zout_end)
        if (!gz_zexpand(a, a->zout, len)) return 0;
    memcpy(a->zout, a->zbuffer, len);
    a->zbuffer += len;
    a->zout += len;
    return 1;
}

static int gz_parse_zlib_header(gz_zbuf *a)
{
    int cmf = gz_zget8(a);
    int cm  = cmf & 15;
    /* int cinfo = cmf >> 4; */
    int flg = gz_zget8(a);
    if (gz_zeof(a)) return gz_fail("bad zlib header"); /* zlib spec */
    if ((cmf * 256 + flg) % 31 != 0) return gz_fail("bad zlib header");
    if (flg & 32) return gz_fail("no preset dict");    /* preset dictionary */
    if (cm != 8) return gz_fail("bad compression");    /* DEFLATE required */
    return 1;
}

static const gz_u8 gz_zdefault_length[GZ_ZNSYMS] =
{
    /* 0..143=8, 144..255=9, 256..279=7, 280..287=8 (RFC 1951, 3.2.6) */
    8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
    8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
    8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
    8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
    8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
    9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
    9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
    9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8
};

static const gz_u8 gz_zdefault_distance[32] =
{
    5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
};

static int gz_parse_zlib(gz_zbuf *a, int parse_header)
{
    int final, type;
    if (parse_header)
        if (!gz_parse_zlib_header(a)) return 0;
    a->num_bits = 0;
    a->code_buffer = 0;
    a->hit_zeof_once = 0;
    a->real_bits = 0;            /* [GZ-PARTIAL2] */
    do {
        final = (int)gz_zreceive(a, 1);
        type  = (int)gz_zreceive(a, 2);
        if (type == 0) {
            if (!gz_parse_uncompressed_block(a)) return 0;
        } else if (type == 3) {
            return gz_fail("invalid block type");
        } else {
            if (type == 1) {
                /* use fixed code lengths */
                if (!gz_zbuild_huffman(&a->z_length,  gz_zdefault_length,  GZ_ZNSYMS)) return 0;
                if (!gz_zbuild_huffman(&a->z_distance, gz_zdefault_distance, 32)) return 0;
            } else {
                if (!gz_compute_huffman_codes(a)) return 0;
            }
            if (!gz_parse_huffman_block(a)) return 0;
        }
    } while (!final);
    return 1;
}

/* ================= публичный API ================= */

/* Adler-32 (RFC 1950) — проверка целостности zlib-потока */
static gz_u32 gz_adler32(const gz_u8 *p, gz_u32 n)
{
    gz_u32 s1 = 1, s2 = 0;
    while (n) {
        gz_u32 chunk = n > 5552 ? 5552 : n; /* max iterations before mod */
        n -= chunk;
        while (chunk--) {
            s1 += *p++;
            s2 += s1;
        }
        s1 %= 65521;
        s2 %= 65521;
    }
    return (s2 << 16) | s1;
}

static int gz_do_inflate(const gz_u8 *in, gz_u32 in_len,
                         gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len,
                         gz_u32 *consumed, int expandable)
{
    gz_zbuf a;
    gz_last_err = NULL;
    a.zbuffer      = in;
    a.zbuffer_end  = in + in_len;
    a.zout_start   = out;
    a.zout         = out;
    a.zout_end     = out + out_cap;
    a.z_expandable = expandable;
    if (!gz_parse_zlib(&a, 0)) return -1;
    if (out_len) *out_len = (gz_u32)(a.zout - a.zout_start);
    if (consumed) *consumed = (gz_u32)(a.zbuffer - in);
    return 0;
}

/* Session 92 [GZ-PARTIAL]: то же, но при ошибке разбора (обрыв потока)
 * ВОЗВРАЩАЕТ ЧАСТИЧНЫЙ РЕЗУЛЬТАТ: всё, что успело декодироваться до
 * сбоя, валидно (zout продвигается только полностью декодированными
 * байтами). Вызывающий сам знает про обрыв — частичный вывод лучше,
 * чем потеря всего ответа. 0 = есть хотя бы 1 байт, -1 = пусто.
 * Session 95 [GZ-PARTIAL2]: при сбое a.zout синхронизирован декодером
 * ровно до последнего символа из РЕАЛЬНЫХ битов ввода (учёт real_bits
 * в gz_fill_bits/gz_parse_huffman_block), так что частичный вывод —
 * бит-в-бит то, что дала бы строгая распаковка полного потока. */
static int gz_do_inflate_tolerant(const gz_u8 *in, gz_u32 in_len,
                                  gz_u8 *out, gz_u32 out_cap,
                                  gz_u32 *out_len)
{
    gz_zbuf a;
    gz_last_err = NULL;
    a.zbuffer      = in;
    a.zbuffer_end  = in + in_len;
    a.zout_start   = out;
    a.zout         = out;
    a.zout_end     = out + out_cap;
    a.z_expandable = 0;
    if (!gz_parse_zlib(&a, 0)) {
        /* [GZ-PARTIAL2]: a.zout синхронизирован декодером ровно до
         * последнего символа из РЕАЛЬНЫХ битов ввода */
        gz_u32 got = (gz_u32)(a.zout - a.zout_start);
        if (got == 0) return -1;      /* распознать нечего — честный сбой */
        if (out_len) *out_len = got;
        return 0;
    }
    if (out_len) *out_len = (gz_u32)(a.zout - a.zout_start);
    return 0;
}

int gz_inflate_raw(const gz_u8 *in, gz_u32 in_len,
                   gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len,
                   gz_u32 *consumed)
{
    return gz_do_inflate(in, in_len, out, out_cap, out_len, consumed, 0);
}

int gz_inflate_zlib(const gz_u8 *in, gz_u32 in_len,
                    gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len)
{
    gz_u32 ulen = 0;
    int cmf, flg;

    gz_last_err = NULL;
    if (in_len < 6) return gz_fail("zlib too short"), -1;
    cmf = in[0];
    flg = in[1];
    if ((cmf * 256 + flg) % 31 != 0) return gz_fail("bad zlib header"), -1;
    if ((cmf & 15) != 8) return gz_fail("bad compression"), -1;
    if (flg & 32) return gz_fail("no preset dict"), -1;

    if (gz_inflate_raw(in + 2, in_len - 2, out, out_cap, &ulen, NULL))
        return -1;
    /* Adler-32 (RFC 1950): БОЛЬШОЙ-endian, ПОСЛЕДНИЕ 4 байта потока
     * (позицию конца DEFLATE из битового ридера брать нельзя — он
     * спекулятивно докачивает биты и уходит за конец блока). */
    if (in_len - 2 < 4) return gz_fail("no adler32"), -1;
    {
        const gz_u8 *ad = in + (in_len - 4);
        gz_u32 adler = ((gz_u32)ad[0] << 24) | ((gz_u32)ad[1] << 16) |
                       ((gz_u32)ad[2] << 8) | (gz_u32)ad[3];
        if (gz_adler32(out, ulen) != adler) return gz_fail("adler mismatch"), -1;
    }
    if (out_len) *out_len = ulen;
    return 0;
}

int gz_inflate_gzip(const gz_u8 *in, gz_u32 in_len,
                    gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len)
{
    gz_u32 off = 10, ulen = 0;

    gz_last_err = NULL;
    if (in_len < 18) return gz_fail("gzip too short"), -1; /* 10 hdr + 8 trailer */
    if (in[0] != 0x1f || in[1] != 0x8b) return gz_fail("bad gzip magic"), -1;
    if (in[2] != 8) return gz_fail("bad gzip method"), -1;  /* CM = deflate */
    {
        gz_u8 flg = in[3];
        /* in[4..7] mtime, in[8] XFL, in[9] OS — не используются */
        if (flg & 0x04) {                       /* FEXTRA */
            gz_u16 xlen;
            if (off + 2 > in_len) return gz_fail("bad gzip extra"), -1;
            xlen = (gz_u16)(in[off] | (in[off + 1] << 8));
            off += 2 + xlen;
            if (off > in_len) return gz_fail("bad gzip extra"), -1;
        }
        if (flg & 0x08) {                       /* FNAME (NUL-термин.) */
            while (off < in_len && in[off]) off++;
            off++;
        }
        if (flg & 0x10) {                       /* FCOMMENT */
            while (off < in_len && in[off]) off++;
            off++;
        }
        if (flg & 0x02) off += 2;               /* FHCRC */
        if (off >= in_len) return gz_fail("bad gzip header"), -1;
    }

    if (gz_inflate_raw(in + off, in_len - off, out, out_cap, &ulen, NULL))
        return -1;

    /* Трейлер — последние 8 байт члена: CRC32 (LE), ISIZE (LE, mod 2^32) */
    {
        const gz_u8 *tr = in + in_len - 8;
        gz_u32 crc = (gz_u32)tr[0] | ((gz_u32)tr[1] << 8) |
                     ((gz_u32)tr[2] << 16) | ((gz_u32)tr[3] << 24);
        gz_u32 isz = (gz_u32)tr[4] | ((gz_u32)tr[5] << 8) |
                     ((gz_u32)tr[6] << 16) | ((gz_u32)tr[7] << 24);
        if (ulen != isz) return gz_fail("isize mismatch"), -1;
        if (gz_crc32(out, ulen) != crc) return gz_fail("crc mismatch"), -1;
    }
    if (out_len) *out_len = ulen;
    return 0;
}

/* Session 92 [GZ-PARTIAL]: gzip-член с ОБРЫВОМ (конец соединения до
 * получения полного тела — «gzip: тело не распаковано (битый/обрезан)»).
 * Строгая gz_inflate_gzip при этом теряла ВСЁ. Здесь: заголовок —
 * строго, DEFLATE — толерантно (частичный вывод), CRC/ISIZE — не
 * проверяются (их у обрыва нет). 0 = *out_len > 0, -1 = пусто.
 * Session 95 [GZ-PARTIAL2]: раньше механизм фактически НЕ РАБОТАЛ для
 * обрыва ВНУТРИ блока (типичный случай — habr.com отдаёт всё одним
 * гигантским dynamic-блоком): gz_parse_huffman_block держал вывод
 * в локальном zout и синхронизировал a->zout лишь при УСПЕШНОМ
 * завершении блока, поэтому при сбое got всегда был 0 и вызывающий
 * получал честный отказ вместо частичной страницы. Теперь вывод
 * синхронизируется на всех путях, а первый символ, декодированный
 * ЗА пределами реальных битов (real_bits), откатывает вывод ровно
 * на границу настоящих данных — мусорный хвост отсекается. */
int gz_inflate_gzip_partial(const gz_u8 *in, gz_u32 in_len,
                            gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len)
{
    gz_u32 off = 10, ulen = 0;

    gz_last_err = NULL;
    if (out_len) *out_len = 0;
    if (in_len < 11) return gz_fail("gzip too short"), -1; /* 10 hdr + >=1 байт */
    if (in[0] != 0x1f || in[1] != 0x8b) return gz_fail("bad gzip magic"), -1;
    if (in[2] != 8) return gz_fail("bad gzip method"), -1;
    {
        gz_u8 flg = in[3];
        if (flg & 0x04) {                       /* FEXTRA */
            gz_u16 xlen;
            if (off + 2 > in_len) return gz_fail("bad gzip extra"), -1;
            xlen = (gz_u16)(in[off] | (in[off + 1] << 8));
            off += 2 + xlen;
            if (off > in_len) return gz_fail("bad gzip extra"), -1;
        }
        if (flg & 0x08) {                       /* FNAME (NUL-термин.) */
            while (off < in_len && in[off]) off++;
            off++;
        }
        if (flg & 0x10) {                       /* FCOMMENT */
            while (off < in_len && in[off]) off++;
            off++;
        }
        if (flg & 0x02) off += 2;               /* FHCRC */
        if (off >= in_len) return gz_fail("bad gzip header"), -1;
    }

    if (gz_do_inflate_tolerant(in + off, in_len - off,
                               out, out_cap, &ulen))
        return -1;
    if (out_len) *out_len = ulen;
    return 0;
}

gz_u8 *gz_zlib_decode_alloc_hdr(const gz_u8 *in, gz_u32 in_len,
                                gz_u32 guess, gz_u32 *out_len,
                                int parse_header)
{
    gz_zbuf a;
    gz_u8 *p;

    gz_last_err = NULL;
    if (guess == 0) guess = 16384;
    p = (gz_u8 *)GZ_MALLOC(guess);
    if (p == NULL) { gz_fail("outofmem"); return NULL; }
    a.zbuffer      = in;
    a.zbuffer_end  = in + in_len;
    a.zout_start   = p;
    a.zout         = p;
    a.zout_end     = p + guess;
    a.z_expandable = 1;
    if (!gz_parse_zlib(&a, parse_header)) {
        GZ_FREE(p);
        return NULL;
    }
    if (out_len) *out_len = (gz_u32)(a.zout - a.zout_start);
    return a.zout_start;
}

gz_u32 gz_crc32(const gz_u8 *p, gz_u32 n)
{
    gz_u32 crc = 0xFFFFFFFFu;
    if (p) {
        while (n--) {
            int k;
            crc ^= *p++;
            for (k = 0; k < 8; k++)
                crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1)));
        }
    }
    return ~crc;
}
