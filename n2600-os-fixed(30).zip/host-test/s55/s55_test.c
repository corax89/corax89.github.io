/* s55_test.c — хост-тест сессии 55: картинки (stb_image/imgsvc) и
 * ссылки (htmlconv/brpage/brlines) в браузере N2600-OS.
 *
 * Проверяет:
 *   A. html_to_md: <a href> -> [текст](url); <img src> -> ![alt](src);
 *   B. brp_analyze: маркеры картинок -> якоря \x02 + записи;
 *      ссылки с абсолютными смещениями; line_off[];
 *   C. brl_wrap: srcidx/srcoff кусков; клик по ссылке (точный и мимо);
 *   D. stb-декод PNG (img_decode_mem) + img_scale (размеры/пиксели);
 *   E. регресс: обычные строки/перенос не сломаны (brl_wrap).
 *
 * Прогон: ./run_s55.sh [asan]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
#include "utf8.h"

/* utf8_next — в ядре объявлена в string.h (string.c); на хосте — своя
 * копия (семантика 1:1 с src/string.c: 1-2 байта декодируются,
 * 3+ — '?'). Объявление ДО включения brpage.h/brlines.h. */
static unsigned utf8_next(const char **ps);

#include "brlines.h"
#include "brpage.h"
#include "htmlconv.h"

/* ---- imgsvc на хосте: заглушки окружения в stubs/ ---- */
#include "imgsvc.h"
/* сессия 67: тестовая таблица RAM disk (стаб) — ramfs_test_add */
#include "ramfs.h"

static unsigned utf8_next(const char **ps)
{
    const unsigned char *s = (const unsigned char *)*ps;
    unsigned c;
    if (s[0] < 0x80) {
        c = s[0];
        *ps += 1;
    } else if ((s[0] & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
        c = ((unsigned)(s[0] & 0x1F) << 6) | (s[1] & 0x3F);
        *ps += 2;
    } else {
        c = '?';
        do { *ps += 1; } while (((**ps) & 0xC0) == 0x80);
    }
    return c;
}

static int fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); \
                   printf(__VA_ARGS__); printf("\n"); } \
} while (0)

/* ---------- A: htmlconv ---------- */
static void test_htmlconv(void)
{
    const char *html =
        "<html><body>\n"
        "<p>См. <a href=\"http://example.com/x?a=1&amp;b=2\">пример</a> и"
        " <a href=\"/rel/path\">относительную</a>.</p>\n"
        "<img src=\"pics/logo.png\" alt=\"логотип\">\n"
        "<a name=\"anchor\">без href</a>\n"
        "</body></html>\n";
    char md[4096];
    int n = html_to_md(html, (int)strlen(html), md, (int)sizeof(md));
    CHECK(n > 0, "html_to_md вернул %d", n);
    CHECK(strstr(md, "[пример](http://example.com/x?a=1&b=2)") != NULL,
          "нет [пример](http://...): '%.80s'", md);
    CHECK(strstr(md, "[относительную](/rel/path)") != NULL,
          "нет [относительную](/rel/path)");
    CHECK(strstr(md, "![логотип](pics/logo.png)") != NULL,
          "нет ![логотип](pics/logo.png): '%s'", md);
    /* <a> без href — старое поведение ]() */
    CHECK(strstr(md, "[без href]()") != NULL, "нет [без href]()");
    /* маркер картинки — СТРОКА (переводы строк вокруг) */
    const char *im = strstr(md, "![логотип]");
    CHECK(im != NULL && (im == md || im[-1] == '\n'),
          "маркер картинки не на отдельной строке");
}

/* ---------- B/C: разбор страницы + клики ---------- */
static void test_brpage(void)
{
    const char *mdsrc =
        "# Заголовок\n"
        "![картинка один](LOGO.PNG)\n"
        "Текст со ссылкой [кликни меня](http://a.b/c) и хвост.\n"
        "![второй](pics/two.png)\n"
        "Без ссылок и картинок.\n";
    int len = (int)strlen(mdsrc);
    char *md = (char *)malloc((u32)len + 2);
    memcpy(md, mdsrc, (u32)len + 1);

    brp_page_t pg;
    memset(&pg, 0, sizeof(pg));
    int nlen = brp_analyze(&pg, md, len);

    CHECK(pg.nimgs == 2, "nimgs=%d (ожидалось 2)", pg.nimgs);
    CHECK(pg.nlinks == 1, "nlinks=%d (ожидалось 1)", pg.nlinks);
    CHECK(!strcmp(pg.imgs[0].url, "LOGO.PNG"), "img0.url=%s", pg.imgs[0].url);
    CHECK(!strcmp(pg.imgs[1].url, "pics/two.png"), "img1.url=%s", pg.imgs[1].url);
    CHECK(pg.imgs[0].src_idx == 1, "img0.src_idx=%d", pg.imgs[0].src_idx);
    CHECK(pg.imgs[1].src_idx == 3, "img1.src_idx=%d", pg.imgs[1].src_idx);
    /* якоря \x02 в md */
    CHECK(strchr(md, BRP_IMG_MARK) != NULL, "нет якоря \\x02");
    int anchors = 0;
    for (int i = 0; i < nlen; i++)
        if (md[i] == BRP_IMG_MARK) anchors++;
    CHECK(anchors == 2, "якорей %d", anchors);
    /* ссылка */
    CHECK(!strcmp(pg.links[0].url, "http://a.b/c"), "link.url=%s",
          pg.links[0].url);
    CHECK(pg.links[0].src_idx == 2, "link.src_idx=%d", pg.links[0].src_idx);

    /* --- сессия 56: разметка [T](U) ВЫРЕЗАНА из md --- */
    CHECK(strstr(md, "[кликни меня](http://a.b/c)") == NULL,
          "разметка ссылки осталась в md: '%.60s'", md);
    CHECK(strstr(md, "кликни меня") != NULL, "видимый текст потерян");
    CHECK(strstr(md, "http://a.b/c") == NULL,
          "URL протёк в видимый текст");
    /* интервал ссылки указывает точно на видимый текст */
    {
        const brp_link_t *l = &pg.links[0];
        CHECK(l->b_abs < l->t_end_abs, "пустой интервал ссылки");
        CHECK(!strncmp(md + l->b_abs, "кликни меня", 11),
              "b_abs не на начале текста: '%.14s'", md + l->b_abs);
        CHECK(l->t_end_abs - l->b_abs == 21,
              "длина текста %d (ожидалось 21 байт)", l->t_end_abs - l->b_abs);
    }
    /* line_off: строка 2 начинается с "Текст" */
    CHECK(!strncmp(md + pg.line_off[2], "Текст", 5), "line_off[2] неверен");

    /* --- клик: wrap шириной 30 --- */
    brl_list_t L;
    memset(&L, 0, sizeof(L));
    brl_wrap(md, nlen, 30, &L);
    CHECK(L.srcidx != NULL && L.srcoff != NULL, "нет srcidx/srcoff");

    /* найти строку отображения, где начинается текст ссылки
     * (перенос может разорвать «кликни меня» — ищем «кликни») */
    int row = -1;
    for (int i = 0; i < L.nlines; i++)
        if (strstr(L.lines[i], "кликни")) { row = i; break; }
    CHECK(row >= 0, "текст ссылки не найден в отображении");

    if (row >= 0) {
        const char *piece = L.lines[row];
        const char *hit = strstr(piece, "кликни");
        /* колонка клика — в СИМВОЛАХ (как из мыши: (mx-4)/8),
        * а strstr даёт байтовое смещение */
        int col = hit ? utf8_count_chars(piece, (int)(hit - piece)) : 0;
        const char *u = brp_click_link(&pg, md, L.srcidx[row], L.srcoff[row],
                                       piece, (int)strlen(piece), col, 0);
        CHECK(u && !strcmp(u, "http://a.b/c"), "клик по тексту: %s",
              u ? u : "(NULL)");
    }

    /* клик по ХВОСТУ ссылки: кусок ПЕРЕНОСА («и хвост.»), ссылка
     * кончилась раньше — точный режим даёт мимо, allow_tail (класс
     * LINK, единственная ссылка в строке) возвращает её же */
    int row2 = -1;
    for (int i = 0; i < L.nlines; i++)
        if (strstr(L.lines[i], "и хвост")) { row2 = i; break; }
    CHECK(row2 >= 0, "кусок переноса не найден");
    if (row2 >= 0) {
        const char *p2 = L.lines[row2];
        const char *hit = strstr(p2, "и хвост");
        int col2 = hit ? utf8_count_chars(p2, (int)(hit - p2)) : 0;
        const char *u = brp_click_link(&pg, md, L.srcidx[row2], L.srcoff[row2],
                                       p2, (int)strlen(p2), col2, 0);
        CHECK(u == NULL, "клик мимо (точный режим) дал %s",
              u ? u : "(NULL)");
        u = brp_click_link(&pg, md, L.srcidx[row2], L.srcoff[row2],
                           p2, (int)strlen(p2), col2, 1);
        CHECK(u && !strcmp(u, "http://a.b/c"), "allow_tail: %s",
              u ? u : "(NULL)");
    }

    /* якоря картинок в отображении: строка '\x02' с классом TEXT
     * (класс IMG назначает браузер при раскладке) */
    int img_rows = 0;
    for (int i = 0; i < L.nlines; i++)
        if (L.lines[i][0] == BRP_IMG_MARK && L.lines[i][1] == 0)
            img_rows++;
    CHECK(img_rows == 2, "якорных строк %d", img_rows);

    /* srcidx якорной строки == src_idx картинки */
    for (int i = 0; i < L.nlines; i++) {
        if (L.lines[i][0] == BRP_IMG_MARK && L.lines[i][1] == 0) {
            int found = 0;
            for (int k = 0; k < pg.nimgs; k++)
                if (pg.imgs[k].src_idx == L.srcidx[i]) found = 1;
            CHECK(found, "якорь строки %d не соответствует картинке", i);
        }
    }

    /* вставка пустых строк под картинку (раскладка браузера):
     * после якоря 2 пустые строки — якорь сдвигается вверх */
    {
        int n0 = L.nlines;
        int ok = brl_insert_blanks(&L, 1, 2, 77);
        CHECK(ok == 1 && L.nlines == n0 + 2, "insert: nlines %d->%d",
              n0, L.nlines);
        CHECK(L.cls[1] == BRL_CLS_IMG && L.cls[2] == BRL_CLS_IMG,
              "вставленные классы");
        CHECK(L.srcidx[1] == 77 && L.srcidx[2] == 77, "вставленные srcidx");
        CHECK(!strcmp(L.lines[1], "") && !strcmp(L.lines[2], ""),
              "вставленные строки пусты");
        /* [BR-HEAD-2X]: строка 1 — спейсер 2x-заголовка (пустая, класс
         * HEAD); после вставки прежняя строка 1 на позиции 3, якорь
         * картинки (бывшая строка 2) — на позиции 4 */
        CHECK(L.nlines == n0 ||
              (L.lines[3][0] == 0 && L.lines[4][0] == BRP_IMG_MARK),
              "сдвиг строк");
    }

    brl_free(&L);
    brp_reset(&pg);
    free(pg.line_off);
    free(md);
}

/* ---------- B2 (сессия 56): сегменты отрисовки и несколько ссылок
 * на строке ---------- */
static void test_brpage_multilink(void)
{
    const char *mdsrc =
        "A [первая](http://one/) B [вторая](https://two/) C\n";
    int len = (int)strlen(mdsrc);
    char *md = (char *)malloc((u32)len + 2);
    memcpy(md, mdsrc, (u32)len + 1);

    brp_page_t pg;
    memset(&pg, 0, sizeof(pg));
    int nlen = brp_analyze(&pg, md, len);

    CHECK(pg.nlinks == 2, "nlinks=%d (ожидалось 2)", pg.nlinks);
    /* после вырезания: "A первая B вторая C\n" */
    CHECK(!strncmp(md, "A первая B вторая C", 19),
          "md после вырезания: '%.24s'", md);
    CHECK(!strcmp(pg.links[0].url, "http://one/"), "link0=%s", pg.links[0].url);
    CHECK(!strcmp(pg.links[1].url, "https://two/"), "link1=%s", pg.links[1].url);
    CHECK(!strncmp(md + pg.links[0].b_abs, "первая", 12),
          "link0 b_abs: '%.12s'", md + pg.links[0].b_abs);
    CHECK(!strncmp(md + pg.links[1].b_abs, "вторая", 12),
          "link1 b_abs: '%.12s'", md + pg.links[1].b_abs);

    /* сегменты для отрисовки куска = вся строка */
    brp_seg_t segs[12];
    int ns = brp_link_segs(&pg, 0, pg.line_off[0], md, nlen - 1,
                           segs, 12);
    CHECK(ns == 2, "сегментов %d (ожидалось 2)", ns);
    if (ns == 2) {
        CHECK(segs[0].col0 == 2 && segs[0].col1 == 8,
              "сег0 колонки %d..%d (ожидалось 2..8)",
              segs[0].col0, segs[0].col1);
        CHECK(segs[1].col0 == 11 && segs[1].col1 == 17,
              "сег1 колонки %d..%d (ожидалось 11..17)",
              segs[1].col0, segs[1].col1);
    }

    /* клики: по первому и второму тексту, между ними — мимо */
    brl_list_t L;
    memset(&L, 0, sizeof(L));
    brl_wrap(md, nlen, 80, &L);
    CHECK(L.nlines >= 1, "нет строк");
    const char *piece = L.lines[0];
    int srcoff = L.srcoff[0];
    const char *u1 = brp_click_link(&pg, md, L.srcidx[0], srcoff,
                                    piece, (int)strlen(piece), 3, 0);
    CHECK(u1 && !strcmp(u1, "http://one/"), "клик по первой: %s",
          u1 ? u1 : "(NULL)");
    const char *u2 = brp_click_link(&pg, md, L.srcidx[0], srcoff,
                                    piece, (int)strlen(piece), 13, 0);
    CHECK(u2 && !strcmp(u2, "https://two/"), "клик по второй: %s",
          u2 ? u2 : "(NULL)");
    const char *u3 = brp_click_link(&pg, md, L.srcidx[0], srcoff,
                                    piece, (int)strlen(piece), 9, 0);
    CHECK(u3 == NULL, "клик между ссылками дал %s", u3 ? u3 : "(NULL)");
    /* allow_tail при ДВУХ ссылках на строке не угадывает */
    const char *u4 = brp_click_link(&pg, md, L.srcidx[0], srcoff,
                                    piece, (int)strlen(piece), 9, 1);
    CHECK(u4 == NULL, "allow_tail при 2 ссылках дал %s", u4 ? u4 : "(NULL)");

    /* img_url_resolve: абсолютный/схемо-относительный URL — как есть */
    {
        char out[300];
        img_url_resolve("http://page.host/dir/page.htm",
                        "http://other.host/x.htm", out, (int)sizeof(out));
        CHECK(!strcmp(out, "http://other.host/x.htm"),
              "resolve absolute: %s", out);
        img_url_resolve("http://page.host/dir/page.htm",
                        "//third.host/y.htm", out, (int)sizeof(out));
        CHECK(!strcmp(out, "http://third.host/y.htm"),
              "resolve scheme-rel: %s", out);
        img_url_resolve("http://page.host/dir/page.htm",
                        "/root/z.htm", out, (int)sizeof(out));
        CHECK(!strcmp(out, "http://page.host/root/z.htm"),
              "resolve root-rel: %s", out);
    }

    brl_free(&L);
    brp_reset(&pg);
    free(pg.line_off);
    free(md);
}

/* ---------- D: декод PNG + масштаб ---------- */
static void test_img(const char *png_path)
{
    FILE *f = fopen(png_path, "rb");
    CHECK(f != NULL, "нет файла %s", png_path);
    if (!f) return;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    u8 *buf = (u8 *)malloc((u32)sz);
    if (fread(buf, 1, (size_t)sz, f) != (size_t)sz) sz = 0;
    fclose(f);
    CHECK(sz > 100, "пустой PNG");
    if (sz <= 100) { free(buf); return; }

    img_t t;
    CHECK(img_decode_mem(buf, (u32)sz, &t) == 0, "декод PNG не удался");
    CHECK(t.w == 240 && t.h == 90, "размеры %dx%d (ожидалось 240x90)",
          t.w, t.h);
    if (t.w == 240 && t.h == 90) {
        /* рамка (0,0) — точный цвет (0x7e, 0xa8, 0xd8) */
        const u8 *p = t.rgba;
        CHECK(p[0] == 0x7e && p[1] == 0xa8 && p[2] == 0xd8,
              "угол-рамка %u,%u,%u", p[0], p[1], p[2]);
        /* фон внутри рамки — синий канал больше красного */
        p = t.rgba + (10 * 240 + 10) * 4;
        CHECK(p[2] > p[0] && p[2] > 0x30, "синий фон %u,%u,%u",
              p[0], p[1], p[2]);
        /* жёлтая полоса: y=7, x=100 */
        p = t.rgba + (7 * 240 + 100) * 4;
        CHECK(p[0] > 0xE0 && p[1] > 0xC0 && p[2] < 0x90,
              "жёлтая полоса %u,%u,%u", p[0], p[1], p[2]);
        /* белая надпись: где-то в зоне текста есть почти белый пиксель */
        int whites = 0;
        for (int y = 30; y < 50; y++)
            for (int x = 20; x < 220; x++) {
                const u8 *q = t.rgba + ((u32)y * 240 + (u32)x) * 4;
                if (q[0] > 0xD0 && q[1] > 0xD0 && q[2] > 0xD0) whites++;
            }
        CHECK(whites > 200, "белых пикселей надписи %d", whites);
    }

    /* масштаб: 120x45 и апскейл 480x180 */
    img_t s;
    CHECK(img_scale(&t, 120, 45, &s) == 0, "scale 120x45");
    CHECK(s.w == 120 && s.h == 45, "масштаб размеры %dx%d", s.w, s.h);
    /* центр жёлтой полосы в масштабе: (50, 3.5) ~ (50,3) */
    if (s.w == 120 && s.h == 45) {
        const u8 *p = s.rgba + (3 * 120 + 50) * 4;
        CHECK(p[0] > 0xB0 && p[2] < 0xC0, "после downscale полоса %u,%u,%u",
              p[0], p[1], p[2]);
    }
    img_dispose(&s);

    CHECK(img_scale(&t, 480, 180, &s) == 0, "scale 480x180");
    CHECK(s.w == 480 && s.h == 180, "апскейл размеры %dx%d", s.w, s.h);
    img_dispose(&s);
    img_dispose(&t);

    /* битые данные */
    CHECK(img_decode_mem(buf, 10, &t) != 0, "битый PNG должен дать ошибку");
    free(buf);
}

/* ---------- E: регресс переноса ---------- */
static void test_wrap_regression(void)
{
    /* длинная строка переносится; srcidx у кусков одной строки равен */
    char *md = (char *)malloc(300);
    strcpy(md, "слово раз два три четыре пять шесть семь восемь девять десять\n");
    int len = (int)strlen(md);
    brl_list_t L;
    memset(&L, 0, sizeof(L));
    brl_wrap(md, len, 12, &L);
    CHECK(L.nlines >= 5, "мало строк: %d", L.nlines);
    for (int i = 0; i < L.nlines; i++)
        CHECK(L.srcidx[i] == 0, "srcidx[%d]=%d", i, L.srcidx[i]);
    /* каждый следующий кусок начинается дальше в исходной строке */
    for (int i = 1; i < L.nlines; i++)
        CHECK(L.srcoff[i] > L.srcoff[i-1], "srcoff не растёт: %d@%d",
              L.srcoff[i], i);
    brl_free(&L);
    free(md);

    /* пустые строки и CRLF */
    md = (char *)malloc(64);
    strcpy(md, "один\r\n\r\nдва\r\n");
    len = (int)strlen(md);
    memset(&L, 0, sizeof(L));
    brl_wrap(md, len, 40, &L);
    CHECK(L.nlines == 3, "CRLF: строк %d", L.nlines);
    CHECK(!strcmp(L.lines[0], "один") && !strcmp(L.lines[2], "два"),
          "CRLF содержимое");
    brl_free(&L);
    free(md);
}

/* ---------- F (сессия 67): пути картинок — относительные/абсолютные ---------- */
static void test_urls_s67(const char *png_path)
{
    /* зарегистрировать LOGO.PNG в стабе RAM disk (раньше стаб был пуст —
     * img_decode_url можно было проверить только на resolve-уровне) */
    FILE *f = fopen(png_path, "rb");
    CHECK(f != NULL, "нет файла %s", png_path);
    if (!f) return;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    u8 *buf = (u8 *)malloc((u32)sz);
    if (fread(buf, 1, (size_t)sz, f) != (size_t)sz) sz = 0;
    fclose(f);
    CHECK(sz > 100, "пустой PNG");
    if (sz <= 100) { free(buf); return; }

    system("rm -rf ramfs_test");
    CHECK(ramfs_test_put("LOGO.PNG", buf, (unsigned)sz), "ramfs put LOGO.PNG");
    CHECK(ramfs_test_put("docs/pic.png", buf, (unsigned)sz),
          "ramfs put docs/pic.png");

    char out[300];
    img_t t;

    /* --- resolve: ЛОКАЛЬНАЯ страница (RAM disk) --- */
    img_url_resolve("docs/page.md", "img/x.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "docs/img/x.png"), "local dir-rel: %s", out);
    img_url_resolve("docs/sub/page.md", "../up.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "docs/up.png"), "local ../: %s", out);
    img_url_resolve("docs/page.md", "/LOGO.PNG", out, (int)sizeof(out));
    CHECK(!strcmp(out, "LOGO.PNG"), "local absolute -> root: %s", out);
    img_url_resolve("page.md", "x.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "x.png"), "local root page: %s", out);
    img_url_resolve("", "./LOGO.PNG", out, (int)sizeof(out));
    CHECK(!strcmp(out, "LOGO.PNG"), "no base ./ -> norm: %s", out);
    img_url_resolve("docs/page.md", "./pic.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "docs/pic.png"), "local ./ -> dir: %s", out);

    /* --- resolve: HTTP-страница (нормализация пути) --- */
    img_url_resolve("http://h/dir/page.htm", "./x.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "http://h/dir/x.png"), "http ./: %s", out);
    img_url_resolve("http://h/dir/page.htm", "a/../x.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "http://h/dir/x.png"), "http ../: %s", out);
    img_url_resolve("http://h/dir/page.htm", "/r/x.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "http://h/r/x.png"), "http root: %s", out);
    img_url_resolve("http://h/dir/page.htm",
                    "http://o/d/./y.png", out, (int)sizeof(out));
    CHECK(!strcmp(out, "http://o/d/y.png"), "http abs norm: %s", out);

    /* --- сквозная загрузка (RAM disk) --- */
    CHECK(img_decode_url("/LOGO.PNG", "docs/page.md", &t) == 0 &&
          t.w == 240, "e2e абсолютный /LOGO.PNG");
    if (t.rgba) img_dispose(&t);
    CHECK(img_decode_url("./LOGO.PNG", "docs/page.md", &t) == 0 &&
          t.w == 240, "e2e ./LOGO.PNG (кандидат 2 — корень)");
    if (t.rgba) img_dispose(&t);
    CHECK(img_decode_url("LOGO.PNG", "HELP.MD", &t) == 0 && t.w == 240,
          "e2e LOGO.PNG со страницы в корне");
    if (t.rgba) img_dispose(&t);
    CHECK(img_decode_url("pic.png", "docs/page.md", &t) == 0 && t.w == 240,
          "e2e pic.png рядом со страницей docs/");
    if (t.rgba) img_dispose(&t);
    CHECK(img_decode_url("file:///LOGO.PNG", NULL, &t) == 0 && t.w == 240,
          "e2e file:///LOGO.PNG");
    if (t.rgba) img_dispose(&t);
    /* http без сети — fallback на RAM disk по пути из URL */
    CHECK(img_decode_url("http://localhost/LOGO.PNG", NULL, &t) == 0 &&
          t.w == 240, "e2e http-fallback -> RAM disk");
    if (t.rgba) img_dispose(&t);
    /* несуществующий — честная ошибка */
    CHECK(img_decode_url("nope.png", "HELP.MD", &t) != 0,
          "e2e несуществующий должен дать ошибку");

    free(buf);
}

int main(int argc, char **argv)
{
    const char *png = (argc > 1) ? argv[1] : "sample.png";
    test_htmlconv();
    test_brpage();
    test_brpage_multilink();
    test_wrap_regression();
    test_img(png);
    test_urls_s67(png);
    if (fails == 0) printf("== s55: ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ ==\n");
    else printf("== s55: провалов %d ==\n", fails);
    return fails ? 1 : 0;
}
