/* simplewebp.c — единственная единица трансляции simplewebp.h в ядре
 * N2600-OS (декодер WebP: lossy VP8 + lossless VP8L).
 *
 * Схема как у stb_image.c (см. его шапку). Конфигурация для
 * freestanding-ядра (-m32, без libc, без SSE):
 *   SIMPLEWEBP_IMPLEMENTATION — реализация только здесь;
 *   SIMPLEWEBP_DISABLE_STDIO  — чтение только из памяти (ramfs/сеть),
 *     секции с FILE и fopen/fread/fseek вырезаются;
 *   malloc/free               — куча ядра (mem.h): аллокатор по
 *     умолчанию библиотеки (swebp__malloc/swebp__free) попадает на
 *     объявления mem.h, включённые выше. <stdlib.h> перехватывает
 *     src/stdlib.h (freestanding: только size_t/NULL);
 *   abs()                     — libc-функции нет: раскрываем во
 *     встроенную операцию GCC (тот же приём, что в stb_image.c);
 *   <assert.h>                — перехватывает src/assert.h (no-op);
 *   <string.h>                — src/string.h (memcpy/memset/memcmp);
 *   <stdint.h>/<stdbool.h>/<stddef.h> — встроенные заголовки GCC
 *     (freestanding-набор).
 *
 * thread_local в библиотеке НЕТ (проверено) — все состояния в аллокации
 * вызывающего (simplewebp* handle). Float-путь (YUV->RGB lossy) — как
 * у stb: выполняется под глобальным FPU-локом imgsvc (см. imgsvc.h),
 * поэтому вызывать simplewebp_* можно только из imgsvc.c.
 *
 * Все обращения извне — через imgsvc.c/imgsvc.h (img_decode_mem по
 * сигнатуре RIFF....WEBP).
 */
#include "types.h"
#include "mem.h"
#include "string.h"

#define SIMPLEWEBP_IMPLEMENTATION
#define SIMPLEWEBP_DISABLE_STDIO

/* libc abs() во freestanding нет (используется в VP8-фильтре цветов) */
#define abs(x) __builtin_abs(x)

#include "simplewebp.h"
