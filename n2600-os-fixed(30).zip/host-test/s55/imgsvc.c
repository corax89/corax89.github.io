/* imgsvc.c — сервис изображений N2600-OS (см. imgsvc.h).
 *
 * Session 55. Декодирование — stb_image (src/stb_image.c), форматы
 * PNG/JPEG/BMP/GIF. Все long-running операции (stb-декодирование,
 * билинейное масштабирование) — под глобальным спящим локом: stb не
 * реентерабелен, x87-состояние ядра не сохраняется планировщиком.
 */
#include "types.h"
#include "mem.h"
#include "string.h"
#include "sync.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "task.h"
#include "imgsvc.h"

/* stb_image.h — только объявления (реализация в stb_image.c) */
#define STBI_NO_STDIO
#define STBI_NO_SIMD
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_ONLY_BMP
#define STBI_ONLY_GIF
#include "stb_image.h"

/* simplewebp.h — только объявления (реализация в simplewebp.c).
 * [IMG-WEBP]: WebP (lossy VP8 + lossless VP8L) для браузера/просмотрщика;
 * float-путь декодера — под тем же FPU-локом, что и stb.
 * SIMPLEWEBP_DISABLE_STDIO обязан совпадать с simplewebp.c (иначе
 * декларации тянут <stdio.h>, которого во freestanding нет). */
#define SIMPLEWEBP_DISABLE_STDIO
#include "simplewebp.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

/* хост-харнессы (host-test/s55) определяют serial_puts макросом-заглушкой —
 * extern-объявление тогда пропускаем (в ядре макроса нет, объявление живо) */
#ifndef serial_puts
extern void serial_puts(const char *s);   /* ядро; в HOST_TEST не вызывается */
#endif

/* ---------------- глобальный лок (спящий, sync.h) ---------------- */

static volatile int img_lock_v = 0;

static void img_lk(void)    { s_lock(&img_lock_v); }
static void img_unlk(void)  { s_unlock(&img_lock_v); }

/* Сессия 60: общий FPU-лок для всех float-библиотек ядра
 * (stb_image — здесь, dr_mp3 — в mp3svc). См. imgsvc.h. */
void img_fpu_lock(void)   { img_lk(); }
void img_fpu_unlock(void) { img_unlk(); }

/* ---------------- ошибки ---------------- */

static char img_err[96];

static void img_seterr(const char *msg)
{
    if (msg) {
        strncpy(img_err, msg, sizeof(img_err) - 1);
        img_err[sizeof(img_err) - 1] = 0;
    }
}

const char *img_errstr(void) { return img_err[0] ? img_err : "unknown"; }

/* ---------------- декодирование ---------------- */

void img_dispose(img_t *t)
{
    if (!t) return;
    if (t->rgba) { free(t->rgba); t->rgba = NULL; }
    t->w = 0; t->h = 0;
}

/* [IMG-WEBP]: сигнатура WebP — RIFF....WEBP (байты 0-3 "RIFF",
 * 8-11 "WEBP"). stb_image WebP не понимает — отдаём simplewebp. */
static int img_is_webp(const u8 *d, u32 len)
{
    return len >= 12 &&
        d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' &&
        d[8] == 'W' && d[9] == 'E' && d[10] == 'B' && d[11] == 'P';
}

/* [IMG-WEBP]: декодирование WebP через simplewebp (src/simplewebp.c).
 * Вызывается под img_lk() (float-путь YUV->RGB). Порядок обязанностей:
 * 1) load (внутри аллокации от заголовка — декомпрессионная бомба
 * упрётся в отказ malloc и вернёт SIMPLEWEBP_ALLOC_ERROR);
 * 2) габариты -> лимит IMG_MAX_PIXELS; 3) своё полотно RGBA8 ->
 * simplewebp_decode; 4) unload ДО возврата (декодер держит ссылку
 * на буфер данных вызывателя до unload — в img_decode_mem он жив). */
static int img_decode_webp(const u8 *data, u32 len, img_t *out)
{
    simplewebp      *sw = NULL;
    simplewebp_error err;
    size_t           w = 0, h = 0;
    u8               *px;

    err = simplewebp_load_from_memory((void *)data, (size_t)len, NULL, &sw);
    if (err != SIMPLEWEBP_NO_ERROR || !sw) {
        img_seterr("img: webp битый/не поддержан");
        return -1;
    }
    simplewebp_get_dimensions(sw, &w, &h);
    if (w == 0 || h == 0 || (u64)w * (u64)h > (u64)IMG_MAX_PIXELS) {
        simplewebp_unload(sw);
        img_seterr("img: слишком большая картинка");
        return -1;
    }
    px = (u8 *)malloc((u32)w * (u32)h * 4);
    if (!px) {
        simplewebp_unload(sw);
        img_seterr("img: нет памяти под полотно");
        return -1;
    }
    err = simplewebp_decode(sw, px, NULL);
    simplewebp_unload(sw);   /* буфер data вызывателя декодеру больше не нужен */
    if (err != SIMPLEWEBP_NO_ERROR) {
        free(px);
        img_seterr("img: webp битый");
        return -1;
    }
    out->w = (int)w;
    out->h = (int)h;
    out->rgba = px;
    return 0;
}

int img_decode_mem(const u8 *data, u32 len, img_t *out)
{
    int w = 0, h = 0, comp = 0;
    u8 *px;
    u32 npix;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!data || len < 8) { img_seterr("img: пустые данные"); return -1; }

    img_lk();
    /* [IMG-WEBP]: сигнатурная проверка ДО stb — stbi_info на WebP даёт
     * "формат не распознан", а свой заголовок дешевле и точнее */
    if (img_is_webp(data, len)) {
        int wrc = img_decode_webp(data, len, out);
        img_unlk();
        return wrc;
    }
    /* [IMG-PRECHECK] (отчёт, баг 4): заголовок СНАЧАЛА, декодирование
     * ПОТОМ. stbi_load_from_memory аллоцирует ВСЁ полотно ещё до
     * возврата — картинка 20000x20000 (заявленная в заголовке)
     * съедала кучу (160 МБ RGBA) и только потом отвергалась лимитом
     * IMG_MAX_PIXELS; на 1 ГБ ОЗЗ malloc отказывал где-то в глубине
     * stb, а отказ трактовался как «битый формат». stbi_info_* читает
     * только заголовок (без аллокаций) — лимит проверяем до декода. */
    if (!stbi_info_from_memory(data, (int)len, &w, &h, &comp) ||
        w <= 0 || h <= 0) {
        img_unlk();
        img_seterr("img: формат не распознан/битый");
        return -1;
    }
    if ((u32)w * (u32)h > IMG_MAX_PIXELS) {
        img_unlk();
        img_seterr("img: слишком большая картинка");
        return -1;
    }
    /* 4 компоненты (RGBA): альфа нужна GIF/PNG с прозрачностью
     * (fb_blit_rgba пропускает прозрачные пиксели); в остальных
     * случаях stb сам дольёт 0xFF. */
    px = stbi_load_from_memory(data, (int)len, &w, &h, &comp, 4);
    img_unlk();

    if (!px) { img_seterr("img: формат не распознан/битый"); return -1; }
    if (w <= 0 || h <= 0) { free(px); img_seterr("img: нулевые размеры"); return -1; }

    /* защита от «заголовок обещал одно, декодер выдал другое»
     * (злонамеренный PNG с двумя IHDR-подобными блоками) */
    npix = (u32)w * (u32)h;
    if (npix > IMG_MAX_PIXELS) {
        free(px);
        img_seterr("img: слишком большая картинка");
        return -1;
    }

    out->w = w;
    out->h = h;
    out->rgba = px;
    return 0;
}

/* Поиск в RAM disk без учёта регистра (как apps_browser.c ramfs_lookup) */
static int img_ramfs_lookup(const char *name, u32 *out_size)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        const char *a = ents[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) {
            if (out_size) *out_size = ents[i].size;
            return 1;
        }
    }
    return 0;
}

int img_decode_file(const char *ramfs_name, img_t *out)
{
    u32 fsize = 0;
    u8 *buf;
    u32 got;
    int rc;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!ramfs_name || !ramfs_name[0]) { img_seterr("img: пустое имя файла"); return -1; }
    if (!img_ramfs_lookup(ramfs_name, &fsize)) {
        img_seterr("img: файла нет в RAM disk");
        return -1;
    }
    if (fsize == 0 || fsize > IMG_FETCH_MAX) {
        img_seterr("img: размер файла вне лимита");
        return -1;
    }
    buf = (u8 *)malloc(fsize);
    if (!buf) { img_seterr("img: нет памяти под файл"); return -1; }
    got = ramfs_read(ramfs_name, buf, fsize);
    if (got == 0) { free(buf); img_seterr("img: ошибка чтения RAM disk"); return -1; }
    rc = img_decode_mem(buf, got, out);
    free(buf);
    return rc;
}

/* ---------- разбор ссылок ---------- */

static int ci_starts_with(const char *s, const char *pre)
{
    while (*pre) {
        char a = *s, b = *pre;
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a != b) return 0;
        s++; pre++;
    }
    return 1;
}

/* Task 61 [BR-2SLASH]: нормализация ПУТИ http-URL (публичная, см.
 * imgsvc.h — используется и браузером). Отличия от img_norm_inplace
 * (та — для имён RAM disk, где слеши по краям не значимы):
 *   - ведущий '/' и хвостовой '/' СОХРАНЯЮТСЯ ("/dir/" — адрес
 *     каталога, сервер отвечает на него редиректом; ломать нельзя);
 *   - "//" сворачивается, "./" и "../" разворачиваются (за корнем —
 *     остаёмся в корне);
 *   - всё после первого '?' НЕ трогается: в query бывают base64-строки
 *     с '/' и "//" — сворачивать их нельзя.
 * max — размер буфера path (результат всегда <= входа, но проверяем). */
void img_norm_url_path(char *path, int max)
{
    char tmp[600];
    char out[680];
    int  seg[96];                /* начала сегментов в tmp */
    int  nseg = 0;
    int  o = 0, wo = 0;
    const char *query;
    int  plen, i, starts, trail;

    if (!path || max <= 0) return;

    query = strchr(path, '?');
    plen = query ? (int)(query - path) : (int)strlen(path);
    if (plen > (int)sizeof(tmp) - 2) plen = (int)sizeof(tmp) - 2;
    starts = (plen > 0 && path[0] == '/');
    trail  = (plen > 0 && path[plen - 1] == '/');

    /* сегменты: "" и "." пропускаем, ".." снимает предыдущий сегмент */
    i = 0;
    while (i < plen) {
        int j = i;
        int sl, dot, dotdot;
        while (j < plen && path[j] != '/') j++;
        sl = j - i;
        dot    = (sl == 1 && path[i] == '.');
        dotdot = (sl == 2 && path[i] == '.' && path[i + 1] == '.');
        if (!dot && !dotdot && sl > 0) {
            if (nseg < (int)(sizeof(seg) / sizeof(seg[0])) &&
                o + sl + 1 <= (int)sizeof(tmp) - 1) {
                seg[nseg++] = o;
                for (int k = 0; k < sl; k++) tmp[o++] = path[i + k];
                tmp[o++] = '/';
            }
        } else if (dotdot && nseg > 0) {
            nseg--;
            o = seg[nseg];
        }
        i = j + 1;
    }

    /* сборка: [ведущий '/'] сегменты через '/' [хвостовой '/'] [query] */
    if (starts) out[wo++] = '/';
    for (int k = 0; k + 1 < o; k++)      /* tmp кончается '/', не пишем его */
        if (wo < (int)sizeof(out) - 2) out[wo++] = tmp[k];
    if (trail && wo > 0 && out[wo - 1] != '/') out[wo++] = '/';
    if (query) {
        for (const char *q = query; *q && wo < (int)sizeof(out) - 2; q++)
            out[wo++] = *q;
    }
    out[wo] = 0;
    if (wo < max) strcpy(path, out);
}

/* Task 61 [BR-PCT]: процентное кодирование URL-пути с query (публичная,
 * см. imgsvc.h). Небезопасные байты — пробел, '"', '#', '<', '>', '[',
 * ']', '\\', '^', '`', '{', '|', '}', управляющие и всё >= 0x80
 * (UTF-8-пути вроде /wiki/Статья) — кодируются в %XX: иначе request-line
 * ломается (лишний пробел = 400) либо сервер не понимает путь.
 * '?' переводит в query-режим (один раз пишется как есть); «безопасные»
 * (alnum и -._~!$&'()*+,;=:@/) не кодируются; "%XX" с шестнадцатеричными
 * XX не кодируется повторно. Возвращает длину результата (стоп по
 * ёмкости out_max). */
int img_url_encode_path(const char *src, char *out, int out_max)
{
    static const char hexdig[] = "0123456789ABCDEF";
    int o = 0, query = 0;

    if (!src || !out || out_max <= 0) return 0;
    for (int i = 0; src[i]; i++) {
        unsigned char c = (unsigned char)src[i];
        int safe;
        if (c == '?' && !query) {
            query = 1;
            if (o + 1 >= out_max) break;
            out[o++] = (char)c;
            continue;
        }
        safe = ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                (c >= '0' && c <= '9') ||
                c == '-' || c == '.' || c == '_' || c == '~' ||
                c == '!' || c == '$' || c == '&' || c == '\'' ||
                c == '(' || c == ')' || c == '*' || c == '+' ||
                c == ',' || c == ';' || c == '=' || c == ':' ||
                c == '@' || c == '/');
        if (!safe && c == '%' &&
            ((src[i + 1] >= '0' && src[i + 1] <= '9') ||
             (src[i + 1] >= 'A' && src[i + 1] <= 'F') ||
             (src[i + 1] >= 'a' && src[i + 1] <= 'f')) &&
            ((src[i + 2] >= '0' && src[i + 2] <= '9') ||
             (src[i + 2] >= 'A' && src[i + 2] <= 'F') ||
             (src[i + 2] >= 'a' && src[i + 2] <= 'f')))
            safe = 1;                    /* уже закодировано — не двоим */
        if (safe) {
            if (o + 1 >= out_max) break;
            out[o++] = (char)c;
        } else {
            if (o + 3 >= out_max) break;
            out[o++] = '%';
            out[o++] = hexdig[(c >> 4) & 15];
            out[o++] = hexdig[c & 15];
        }
    }
    out[o] = 0;
    return o;
}

/* host[:port] -> host, port; path = остаток (начинается с '/'). */
static int img_parse_http(const char *p, int https, char *host, int host_max,
                          u16 *port, char *path, int path_max)
{
    int hi = 0;
    *port = https ? 443 : 80;
    while (*p && *p != '/' && hi < host_max - 1) host[hi++] = *p++;
    host[hi] = 0;
    {
        char *colon = strchr(host, ':');
        if (colon) {
            u32 pv = 0;
            *colon = 0;
            for (const char *q = colon + 1; *q; q++) {
                if (*q < '0' || *q > '9') return 0;
                pv = pv * 10 + (u32)(*q - '0');
                if (pv > 65535) return 0;
            }
            if (pv == 0) return 0;
            *port = (u16)pv;
        }
    }
    if (!host[0]) return 0;
    if (!*p) p = "/";
    if ((int)strlen(p) >= path_max) return 0;
    strcpy(path, p);
    /* Task 61 [BR-2SLASH]/[BR-PCT]: путь картинки нормализуем и
     * процентно кодируем ("host//a", "/a/./b", пробелы и кириллица
     * в src раньше уходили в GET как есть — строгие серверы давали 404,
     * пробел ломал request-line). */
    img_norm_url_path(path, path_max);
    {
        char enc[768];
        int el = img_url_encode_path(path, enc, (int)sizeof(enc));
        if (el > 0 && el < path_max) strcpy(path, enc);
    }
    return 1;
}

/* СЕССИЯ 67: нормализовать путь НА МЕСТЕ: выкинуть сегменты "./",
 * разрешить "../" (за корнем — остаться в корне), свернуть "//",
 * срезать хвостовой '/'. Возвращает новую длину.
 * Используется для имён RAM disk (они хранятся БЕЗ ведущего '/'),
 * поэтому ведущий '/' тоже "съедается" как сегмент-пустышка. */
static int img_norm_inplace(char *p)
{
    char *w = p, *r = p;
    while (*r) {
        if (r[0] == '/' && r[1] == '/') { r++; continue; }        /* // */
        if (r[0] == '.' && (r[1] == '/' || r[1] == 0)) {          /* ./  */
            r += (r[1] ? 2 : 1);
            continue;
        }
        if (r[0] == '.' && r[1] == '.' && (r[2] == '/' || r[2] == 0)) {
            /* ../ — съесть предыдущий сегмент; за корнем — остаться */
            if (w > p) {
                w--;
                while (w > p && w[-1] != '/') w--;
            }
            r += (r[2] == '/') ? 3 : 2;
            continue;
        }
        *w++ = *r++;
    }
    while (w > p && w[-1] == '/') w--;      /* хвостовой '/' */
    *w = 0;
    return (int)(w - p);
}

/* СЕССИЯ 67: нормализовать ПУТЬ полного http(s)-URL (подстрока после
 * "scheme://host"): "./", "../", "//". Строгие серверы (в т.ч. наш
 * httpd) "dir/./x.png" и "dir/a/../x.png" не разворачивают — 404.
 * Схему не трогаем: нормализация с первого '/' ПОСЛЕ хоста (иначе
 * свернулась бы "//" в "://").
 * Task 61 [BR-2SLASH]: путь нормализуется С УЧЁТОМ query — часть после
 * '?' не трогается (base64 "a//b" в параметрах не должен сворачиваться). */
static void img_norm_http_path(char *url)
{
    char *ps = strstr(url, "://");
    if (!ps) return;
    ps = strchr(ps + 3, '/');
    if (ps) img_norm_url_path(ps, (int)strlen(ps) + 1);
}

/* СЕССИЯ 67: соединить каталог страницы base[0..dlen) с rel-ссылкой
 * и нормализовать (./ ../ //). Выход — имя RAM disk без ведущего '/'.
 * 1 = успех (out заполнен), 0 = не влезло/пусто. */
static int img_join_norm(const char *base, int dlen, const char *rel,
                         char *out, int out_max)
{
    char tmp[RAMFS_NAME_MAX * 2 + 8];
    int n = 0;

    if (dlen < 0) dlen = 0;
    for (int i = 0; i < dlen && n < (int)sizeof(tmp) - 2; i++)
        tmp[n++] = base[i];
    if (n > 0 && tmp[n - 1] != '/' && rel[0] && rel[0] != '/')
        tmp[n++] = '/';
    for (const char *q = rel; *q && n < (int)sizeof(tmp) - 1; q++)
        tmp[n++] = *q;
    tmp[n] = 0;

    img_norm_inplace(tmp);
    if (!tmp[0] || (int)strlen(tmp) >= out_max) return 0;
    strcpy(out, tmp);
    return 1;
}

/* СЕССИЯ 67: последний шанс после НЕУДАЧНОЙ сетевой загрузки картинки —
 * путь из URL как имя RAM disk. Локальный httpd раздаёт файлы ramdisk,
 * и если сервер уже не отвечает (а страница осталась открытой/сохранны
 * ссылки), картинка всё равно может лежать в RAM disk. При неудаче
 * ВОССТАНАВЛИВАЕТ prev_err — статус должен показывать сетевую причину,
 * а не "файла нет в RAM disk". */
static int img_ramfs_url_fallback(const char *path, img_t *out)
{
    char prev[96];
    char cand[RAMFS_NAME_MAX + 4];
    int n = 0;

    /* снимок сетевой ошибки: при неудаче fallback вернём её в статус */
    snprintf(prev, sizeof(prev), "%s", img_err[0] ? img_err : "unknown");

    /* срезаем ведущие '/', "./", "../" (path может быть "/LOGO.PNG",
 * "./x.png", "../dir/x.png") */
    const char *q = path;
    for (;;) {
        if (*q == '/') q++;
        else if (q[0] == '.' && q[1] == '/') q += 2;
        else if (q[0] == '.' && q[1] == '.' && q[2] == '/') q += 3;
        else break;
    }
    for (; *q && n < RAMFS_NAME_MAX; q++) cand[n++] = *q;
    cand[n] = 0;
    if (!cand[0]) { img_seterr(prev); return -1; }
    if (!img_ramfs_lookup(cand, NULL)) { img_seterr(prev); return -1; }
    {
        int rc = img_decode_file(cand, out);
        if (rc != 0) img_seterr(prev);
        return rc;
    }
}

/* Относительная ссылка -> абсолютная (наивно): тот же хост;
 * "/..." — от корня, иначе — каталог текущей страницы.
 * Публичная (imgsvc.h): браузер разрешает ею и ссылки, и картинки.
 * СЕССИЯ 67: для ЛОКАЛЬНОЙ страницы (base_url без "://" — имя файла
 * RAM disk) rel теперь разрешается относительно КАТАЛОГА страницы с
 * нормализацией "./"/"../" ("docs/page.md" + "img/x.png" ->
 * "docs/img/x.png"), а rel с ведущим '/' — от корня RAM disk (без
 * ведущего '/'). Прежде rel копировался как есть: картинки и ссылки
 * рядом с локальной страницей в подкаталоге, "./x" и "/x" не работали.
 * Task 61 [BR-REDIR2]: схему в rel распознаём БЕЗ учёта регистра
 * ("HTTPS://..." в href/Location раньше склеивался с хостом страницы);
 * [BR-URL1SLASH] "http:/host/path" (одинарный слеш — битые Location)
 * восстанавливается до "http://host/path";
 * [BR-QREL] "?new=7" (только query) ведёт на ТЕ ЖЕ путь страницы
 * с новой query, а не в каталог (пагинация "?page=2" работала неверно). */
void img_url_resolve(const char *base_url, const char *rel,
                     char *out, int out_max)
{
    const char *h, *hend, *slash;
    int pos = 0;
    char schfix[600];               /* [BR-URL1SLASH] восстановленная схема */
    const char *rel_use = rel;

    out[0] = 0;
    if (!rel || !rel[0]) {
        if (base_url) { strncpy(out, base_url, (u32)out_max - 1); out[out_max - 1] = 0; }
        return;
    }

    /* [BR-URL1SLASH]: "http:/host/path" / "https:/host" — один слеш
     * после схемы (бывает в кривых Location/ссылках) — чиним ДО
     * остальных проверок, иначе rel ушёл бы в относительные. */
    {
        int sl = ci_starts_with(rel, "https:/") ? 7 :
                 ci_starts_with(rel, "http:/")  ? 6 : 0;
        if (sl && rel[sl] != '/' && rel[sl] != 0) {
            int scl = sl - 1;       /* "http:" или "https:" без слеша */
            int o = 0;
            for (int k = 0; k < scl && o < (int)sizeof(schfix) - 3; k++)
                schfix[o++] = rel[k];
            schfix[o++] = '/';
            schfix[o++] = '/';
            for (const char *q = rel + sl; *q && o < (int)sizeof(schfix) - 1; q++)
                schfix[o++] = *q;
            schfix[o] = 0;
            rel_use = schfix;
        }
    }

    /* Сессия 56: АБСОЛЮТНЫЙ адрес в rel — вернуть как есть. Раньше
     * клик по <a href="http://другой.хост/"> со сетевой страницы
     * склеивался с хостом страницы ("http://страница/http://другой")
     * и вёл в никуда; то же с Location: из 302-ответов.
     * Task 61: схема без учёта регистра ("HTTPS://YA.RU"). */
    if (ci_starts_with(rel_use, "http://") ||
        ci_starts_with(rel_use, "https://")) {
        strncpy(out, rel_use, (u32)out_max - 1);
        out[out_max - 1] = 0;
        img_norm_http_path(out);
        return;
    }
    if (rel_use[0] == '/' && rel_use[1] == '/') {
        /* схемо-относительный //host/path -> схема БАЗЫ (Task 67
         * [IMG-PRSCHEME]: прежде всегда "http:" — ресурс //cdn-хоста
         * на https-странице шёл по http: лишний редирект либо отказ
         * CDN; по RFC 3986 схема наследуется от базового URL). */
        const char *sch = (base_url && ci_starts_with(base_url, "https://"))
                          ? "https:" : "http:";
        char tmp[300];
        snprintf(tmp, sizeof(tmp), "%s%s", sch, rel_use);
        strncpy(out, tmp, (u32)out_max - 1);
        out[out_max - 1] = 0;
        img_norm_http_path(out);
        return;
    }

    /* [BR-QREL]: rel = "?query" — тот же путь страницы, новая query.
     * Раньше склеивалось с КАТАЛОГОМ ("/dir/?page=2" вместо
     * "/dir/page?page=2") — пагинация вела не туда. */
    if (rel_use[0] == '?' && base_url && base_url[0]) {
        int bl = 0;
        while (base_url[bl] && base_url[bl] != '?' &&
               base_url[bl] != '#' && bl < out_max - 1)
            out[bl] = base_url[bl], bl++;
        for (const char *q = rel_use; *q && bl < out_max - 1; q++)
            out[bl++] = *q;
        out[bl] = 0;
        return;
    }

    if (!base_url || !base_url[0]) {
        /* нет базы — считаем имя файла RAM disk (нормализуем "/", "./") */
        char tmp[RAMFS_NAME_MAX + 8];
        if ((int)strlen(rel) < (int)sizeof(tmp)) {
            strcpy(tmp, rel);
            img_norm_inplace(tmp);
            if (tmp[0]) { strncpy(out, tmp, (u32)out_max - 1); out[out_max - 1] = 0; return; }
        }
        strncpy(out + pos, rel, (u32)out_max - 1 - (u32)pos);
        out[out_max - 1] = 0;
        return;
    }

    h = strstr(base_url, "://");
    if (!h) {
        /* СЕССИЯ 67: ЛОКАЛЬНАЯ страница (имя RAM disk, без "://"). */
        if (rel[0] == '/') {
            /* от корня RAM disk: срезаем ведущие '/' */
            const char *q = rel;
            while (*q == '/') q++;
            strncpy(out, q, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return;
        }
        {
            const char *slash = strrchr(base_url, '/');
            if (slash && slash != base_url &&
                img_join_norm(base_url, (int)(slash - base_url), rel,
                              out, out_max))
                return;                     /* рядом со страницей */
        }
        strncpy(out, rel, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return;
    }
    h += 3;
    hend = h;
    while (*hend && *hend != '/') hend++;

    for (const char *q = base_url; q < hend && pos < out_max - 1; q++)
        out[pos++] = *q;

    if (*rel_use == '/') {
        /* от корня */
    } else {
        /* каталог страницы: обрезаем path после последнего '/' */
        slash = strrchr(hend, '/');
        if (slash) {
            for (const char *q = hend; q <= slash && pos < out_max - 1; q++)
                out[pos++] = *q;
        } else if (pos < out_max - 1) {
            out[pos++] = '/';
        }
    }
    for (const char *q = rel_use; *q && pos < out_max - 1; q++)
        out[pos++] = *q;
    out[pos] = 0;
    img_norm_http_path(out);
}

/* Task 66 [IMG-REDIR]: код статуса из начала ответа (0 = не разобрать) */
static int img_http_status(const char *resp, int n)
{
    /* "HTTP/1.x NNN ..." */
    if (n < 12 || memcmp(resp, "HTTP/", 5) != 0) return 0;
    const char *p = resp + 5;
    while (p < resp + n && *p != ' ') p++;          /* версия */
    while (p < resp + n && *p == ' ') p++;
    int code = 0;
    for (int i = 0; i < 3 && p < resp + n; i++) {
        if (*p < '0' || *p > '9') return 0;
        code = code * 10 + (*p - '0');
        p++;
    }
    return code;
}

/* Значение заголовка (по началу строки, без учёта регистра ключа) */
static int img_http_header(const char *resp, int n, const char *key,
                           char *out, int out_max)
{
    int kl = (int)strlen(key);
    int sol = 1;
    for (int i = 0; i < n; i++) {
        if (sol) {
            sol = 0;
            int j = 0;
            while (j < kl && i + j < n) {
                char a = resp[i + j], b = key[j];
                if (a >= 'A' && a <= 'Z') a = (char)(a | 0x20);
                if (b >= 'A' && b <= 'Z') b = (char)(b | 0x20);
                if (a != b) break;
                j++;
            }
            if (j == kl && i + j < n && resp[i + j] == ':') {
                int k = i + j + 1;
                while (k < n && (resp[k] == ' ' || resp[k] == '\t')) k++;
                int o = 0;
                while (k < n && resp[k] != '\r' && resp[k] != '\n' &&
                       o < out_max - 1)
                    out[o++] = resp[k++];
                out[o] = 0;
                return o;
            }
        }
        if (resp[i] == '\n') sol = 1;
        if (resp[i] == '\r' && i + 1 < n && resp[i + 1] == '\n') {
            /* конец заголовков */
            if (i + 2 < n && resp[i + 1] == '\r') { /* недостижимо */ }
        }
        if (resp[i] == '\r' && i + 3 < n &&
            resp[i + 1] == '\n' && resp[i + 2] == '\r' && resp[i + 3] == '\n')
            break;
    }
    return 0;
}

/* Task 66 [IMG-DATAURI]: base64-декодер для data:-URI (без проверки
 * строгости: '=' паддинг и пробелы/переводы строк пропускаем,
 * посторонние символы пропускаем же — данные URL часто «косые») */
static int img_b64_decode(const char *src, u8 *out, int out_max)
{
    static const char alphabet[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    int o = 0;
    u32 acc = 0;
    int bits = 0;
    for (; *src; src++) {
        char c = *src;
        int v;
        if (c == '=' || c == '\n' || c == '\r' || c == ' ' || c == '\t')
            continue;
        {
            const char *hit = strchr(alphabet, c);
            if (!hit || !*hit) continue;        /* посторонний — пропускаем */
            v = (int)(hit - alphabet);
        }
        acc = (acc << 6) | (u32)v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            if (o >= out_max) return -1;
            out[o++] = (u8)(acc >> bits);
        }
    }
    return o;
}

int img_decode_url(const char *url, const char *base_url, img_t *out)
{
    char clean[380];   /* Task 66: было 300 (согласовано с BRP_URL_MAX) */
    int ci = 0;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!url || !url[0]) { img_seterr("img: пустой адрес"); return -1; }

    /* фрагменты #... отбрасываем, пробелы убираем */
    for (const char *q = url; *q && ci < (int)sizeof(clean) - 1; q++) {
        if (*q == '#') break;
        if (*q != ' ') clean[ci++] = *q;
    }
    clean[ci] = 0;
    if (!clean[0]) { img_seterr("img: пустой адрес"); return -1; }

    /* Task 66 [IMG-DATAURI]: data:image/png;base64,.... */
    if (ci_starts_with(clean, "data:")) {
        const char *comma = strchr(clean, ',');
        if (comma && comma - clean < 64) {
            char meta[64];
            int ml = (int)(comma - clean) - 5;
            if (ml > 0 && ml < (int)sizeof(meta)) {
                memcpy(meta, clean + 5, (u32)ml);
                meta[ml] = 0;
                /* метаданные до ';': image/xxx; признак base64 — после ';' */
                int is_b64 = 0;
                for (const char *q = meta; *q; q++)
                    if (*q == ';') { is_b64 = ci_starts_with(q + 1, "base64"); break; }
                if (is_b64) {
                    int blen = (int)strlen(comma + 1);
                    if (blen > 700000) { img_seterr("img: data: слишком велик"); return -1; }
                    u8 *buf = (u8 *)malloc((u32)blen + 4);
                    if (!buf) { img_seterr("img: нет памяти"); return -1; }
                    int dn = img_b64_decode(comma + 1, buf, blen + 4);
                    if (dn <= 0) { free(buf); img_seterr("img: битый base64"); return -1; }
                    int rc2 = img_decode_mem(buf, (u32)dn, out);
                    free(buf);
                    return rc2;
                }
            }
        }
        img_seterr("img: data:-URI не base64");
        return -1;
    }

    if (ci_starts_with(clean, "http://") || ci_starts_with(clean, "https://")) {
        int https = (clean[4] == 's');
        const char *p = clean + (https ? 8 : 7);
        char host[128], path[256];
        u16 port;
        char *resp = NULL;   /* Task 66 [IMG-REDIR]: живёт через цикл */
        int n, rc;
        const char *body;
        int blen;
        const char *enc;

        if (!img_parse_http(p, https, host, (int)sizeof(host), &port,
                            path, (int)sizeof(path))) {
            img_seterr("img: неверный адрес");
            return -1;
        }
        /* СЕССИЯ 63: картинки с loopback (страница с 127.0.0.1, картинки
         * с localhost) грузим без NIC/IP — стек замыкает соединение сам. */
        if (!net_host_is_loopback(host) &&
            (!net_nic_present() || net_get_ip() == 0)) {
            img_seterr("img: сеть не настроена");
            /* СЕССИЯ 67: сети нет — но картинка может лежать в RAM disk
             * (локальный httpd раздаёт ramdisk): путь как имя файла. */
            return img_ramfs_url_fallback(path, out);
        }
        /* Task 66 [IMG-REDIR]: CDN/счётчики часто отвечают 301/302 на
         * картинку. Раньше тело редиректа (HTML) шло в декодер и
         * картинка «не грузилась»; теперь до 3 переходов, Location —
         * абсолютный и относительный (img_url_resolve). */
        int got = 0;
        for (int redir = 0; redir <= 3; redir++) {
            int code;
            char loc[380], absu[460], baseu[520];
            if (resp) { free(resp); resp = NULL; }
            resp = (char *)malloc(IMG_FETCH_MAX);
            if (!resp) { img_seterr("img: нет памяти под ответ"); return -1; }
            n = net_http_get(host, port, path, resp, IMG_FETCH_MAX, 15000);
            if (n <= 0) {
                snprintf(img_err, sizeof(img_err), "img: сеть: %s",
                         net_http_errstr());
                free(resp);
                /* СЕССИЯ 67: сеть не удалась — последний шанс: RAM disk */
                return img_ramfs_url_fallback(path, out);
            }
            code = img_http_status(resp, n);
            if ((code == 301 || code == 302 || code == 303 ||
                 code == 307 || code == 308) && redir < 3 &&
                img_http_header(resp, n, "Location", loc, (int)sizeof(loc)) > 0 &&
                loc[0]) {
                snprintf(baseu, sizeof(baseu), "%s://%s:%u%s",
                         https ? "https" : "http", host, (unsigned)port, path);
                img_url_resolve(baseu, loc, absu, (int)sizeof(absu));
                {
                    const char *q = absu;
                    int tls2 = 0;
                    if (ci_starts_with(q, "https://")) { tls2 = 1; q += 8; }
                    else if (ci_starts_with(q, "http://")) q += 7;
                    else break;               /* не http — отдаём как есть */
                    char h2[128], pa2[256];
                    u16 po2;
                    if (!img_parse_http(q, tls2, h2, (int)sizeof(h2), &po2,
                                        pa2, (int)sizeof(pa2)))
                        break;
                    memcpy(host, h2, sizeof(h2));
                    memcpy(path, pa2, sizeof(pa2));
                    port = po2;
                    https = tls2;
#ifndef HOST_TEST
                    serial_puts("[img] редирект следуется\n");
#endif
                    continue;
                }
            }
            got = 1;
            break;
        }
        if (!got) { free(resp); img_seterr("img: слишком много редиректов"); return -1; }
        /* gzip/deflate не умеем — честно отказываемся */
        enc = NULL;
        for (const char *q = resp; q < resp + n - 20; q++) {
            if ((*q == 'C' || *q == 'c') &&
                !strncmp(q, "ontent-encoding:", 16)) {
                enc = q + 16;
                break;
            }
        }
        if (enc) {
            while (enc < resp + n && (*enc == ' ' || *enc == '\t')) enc++;
            if (!strncmp(enc, "gzip", 4) || !strncmp(enc, "deflate", 7)) {
                img_seterr("img: сжатый ответ (gzip) не поддержан");
                free(resp);
                return img_ramfs_url_fallback(path, out);
            }
        }
        /* тело: после \r\n\r\n (или \n\n) */
        body = resp;
        blen = n;
        for (int i = 0; i < n && i < 4096; i++) {
            if (i + 3 < n && resp[i] == '\r' && resp[i+1] == '\n' &&
                resp[i+2] == '\r' && resp[i+3] == '\n') {
                body = resp + i + 4;
                blen = n - (i + 4);
                break;
            }
            if (i + 1 < n && resp[i] == '\n' && resp[i+1] == '\n') {
                body = resp + i + 2;
                blen = n - (i + 2);
                break;
            }
        }
        if (blen <= 0) {
            img_seterr("img: пустое тело ответа");
            free(resp);
            return img_ramfs_url_fallback(path, out);
        }
        rc = img_decode_mem((const u8 *)body, (u32)blen, out);
        free(resp);
        if (rc != 0) {
            /* декод не удался (404-страница, битый файл) — RAM disk */
            return img_ramfs_url_fallback(path, out);
        }
        return 0;
    }

    if (ci_starts_with(clean, "file://")) {
        /* СЕССИЯ 67: "file:///LOGO.PNG" и "file://dir/x.png" — ramfs имена
 * хранятся без ведущего '/': нормализуем (раньше "/LOGO.PNG" искался
 * буквально и не находился). */
        const char *nm = clean + 7;
        for (;;) {
            if (*nm == '/') nm++;
            else if (nm[0] == '.' && nm[1] == '/') nm += 2;
            else if (nm[0] == '.' && nm[1] == '.' && nm[2] == '/') nm += 3;
            else break;
        }
        return img_decode_file(nm[0] ? nm : clean + 7, out);
    }

    /* без схемы: ЛОКАЛЬНАЯ страница — RAM disk. СЕССИЯ 67: rel
 * разрешается относительно каталога страницы (см. img_url_resolve),
 * затем нормализуется: ramfs имена хранятся без ведущего '/'. */
    if (!base_url || !base_url[0] || !strstr(base_url, "://")) {
        char cand[RAMFS_NAME_MAX + 8];
        img_url_resolve(base_url ? base_url : "", clean, cand,
                        (int)sizeof(cand));
        if (cand[0]) {
            const char *nm = cand;
            for (;;) {
                if (*nm == '/') nm++;
                else if (nm[0] == '.' && nm[1] == '/') nm += 2;
                else if (nm[0] == '.' && nm[1] == '.' && nm[2] == '/') nm += 3;
                else break;
            }
            if (nm[0] && img_decode_file(nm, out) == 0) return 0;
        }
        /* кандидат 2: имя от КОРНЯ (страница из подкаталога может
 * ссылаться на картинку в корне; старое поведение — поиск "как
 * есть" — сохранён здесь же). */
        {
            const char *nm = clean;
            for (;;) {
                if (*nm == '/') nm++;
                else if (nm[0] == '.' && nm[1] == '/') nm += 2;
                else if (nm[0] == '.' && nm[1] == '.' && nm[2] == '/') nm += 3;
                else break;
            }
            if (nm[0] && img_decode_file(nm, out) == 0) return 0;
        }
        img_seterr("img: файла нет в RAM disk");
        return -1;
    }
    {
        char abs[400];
        img_url_resolve(base_url, clean, abs, (int)sizeof(abs));
        return img_decode_url(abs, NULL, out);
    }
}

/* ---------------- масштабирование (билинейное, float, под локом) ---------------- */

int img_scale(const img_t *src, int dw, int dh, img_t *out)
{
    u8 *dst;
    int sw, sh;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!src || !src->rgba || src->w <= 0 || src->h <= 0) {
        img_seterr("img: пустой источник");
        return -1;
    }
    if (dw <= 0 || dh <= 0 || dw > 4096 || dh > 4096) {
        img_seterr("img: неверные размеры");
        return -1;
    }
    sw = src->w; sh = src->h;
    dst = (u8 *)malloc((u32)dw * (u32)dh * 4);
    if (!dst) { img_seterr("img: нет памяти под масштаб"); return -1; }

    img_lk();
    if (dw == sw && dh == sh) {
        memcpy(dst, src->rgba, (u32)dw * (u32)dh * 4);
    } else {
        for (int dy = 0; dy < dh; dy++) {
            /* центр исходного пикселя по вертикали */
            float fy = ((float)dy + 0.5f) * (float)sh / (float)dh - 0.5f;
            int y0 = (int)fy;
            float wy = fy - (float)y0;
            if (y0 < 0) { y0 = 0; wy = 0.0f; }
            if (y0 >= sh - 1) { y0 = sh - 1; wy = 0.0f; }
            int y1 = (y0 + 1 < sh) ? y0 + 1 : y0;

            u8 *drow = dst + (u32)dy * (u32)dw * 4;
            for (int dx = 0; dx < dw; dx++) {
                float fx = ((float)dx + 0.5f) * (float)sw / (float)dw - 0.5f;
                int x0 = (int)fx;
                float wx = fx - (float)x0;
                if (x0 < 0) { x0 = 0; wx = 0.0f; }
                if (x0 >= sw - 1) { x0 = sw - 1; wx = 0.0f; }
                int x1 = (x0 + 1 < sw) ? x0 + 1 : x0;

                const u8 *p00 = src->rgba + ((u32)y0 * (u32)sw + (u32)x0) * 4;
                const u8 *p10 = src->rgba + ((u32)y0 * (u32)sw + (u32)x1) * 4;
                const u8 *p01 = src->rgba + ((u32)y1 * (u32)sw + (u32)x0) * 4;
                const u8 *p11 = src->rgba + ((u32)y1 * (u32)sw + (u32)x1) * 4;
                float w00 = (1.0f - wx) * (1.0f - wy);
                float w10 = wx * (1.0f - wy);
                float w01 = (1.0f - wx) * wy;
                float w11 = wx * wy;

                drow[dx * 4 + 0] = (u8)(p00[0] * w00 + p10[0] * w10 +
                                        p01[0] * w01 + p11[0] * w11);
                drow[dx * 4 + 1] = (u8)(p00[1] * w00 + p10[1] * w10 +
                                        p01[1] * w01 + p11[1] * w11);
                drow[dx * 4 + 2] = (u8)(p00[2] * w00 + p10[2] * w10 +
                                        p01[2] * w01 + p11[2] * w11);
                drow[dx * 4 + 3] = (u8)(p00[3] * w00 + p10[3] * w10 +
                                        p01[3] * w01 + p11[3] * w11);
            }
        }
    }
    img_unlk();

    out->w = dw;
    out->h = dh;
    out->rgba = dst;
    return 0;
}

/* ---------------- дескрипторы ---------------- */

typedef struct {
    int   used;
    int   ref;
    img_t t;
} img_handle_t;

static img_handle_t g_handles[IMG_MAX_HANDLES];

int img_open(const img_t *t)
{
    int id = -1;
    if (!t || !t->rgba || t->w <= 0 || t->h <= 0) {
        img_seterr("img: пустая картинка для img_open");
        return -1;
    }
    img_lk();
    for (int i = 0; i < IMG_MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            g_handles[i].used = 1;
            g_handles[i].ref = 1;
            g_handles[i].t = *t;
            id = i + 1;
            break;
        }
    }
    img_unlk();
    if (id < 0) img_seterr("img: таблица дескрипторов полна");
    return id;
}

int img_retain(int id)
{
    int rc = -1;
    if (id <= 0 || id > IMG_MAX_HANDLES) return -1;
    img_lk();
    if (g_handles[id - 1].used) {
        g_handles[id - 1].ref++;
        rc = 0;
    }
    img_unlk();
    return rc;
}

void img_release(int id)
{
    if (id <= 0 || id > IMG_MAX_HANDLES) return;
    img_lk();
    if (g_handles[id - 1].used && g_handles[id - 1].ref > 0) {
        g_handles[id - 1].ref--;
        if (g_handles[id - 1].ref == 0) {
            img_dispose(&g_handles[id - 1].t);
            g_handles[id - 1].used = 0;
        }
    }
    img_unlk();
}

int img_get(int id, img_t *out)
{
    int rc = -1;
    if (!out || id <= 0 || id > IMG_MAX_HANDLES) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    img_lk();
    if (g_handles[id - 1].used) {
        *out = g_handles[id - 1].t;
        rc = 0;
    }
    img_unlk();
    return rc;
}
