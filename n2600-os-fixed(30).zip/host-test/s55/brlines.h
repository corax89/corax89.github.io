/* brlines.h — разбиение текста на строки отображения с ПЕРЕНОСОМ по
 * СИМВОЛАМ UTF-8 (header-only).
 *
 * Используется браузером N2600-OS (apps_browser.c) и хост-тестом
 * (work/test/brlines_test.c). Вызывающий обязан включить заголовки
 * malloc/free/memcpy/memset (в ядре — mem.h/string.h, в хост-тестах —
 * <stdlib.h>/<string.h>) и utf8.h.
 *
 * Правила переноса (FIX «ограничение на длину строки» в браузере):
 *  - ширина строки задаётся в СИМВОЛАХ (кириллица = 1 символ, 2 байта);
 *  - кусок не влез целиком — перенос по последнему пробелу;
 *  - слово длиннее строки — разрез по границе символа (не байта);
 *  - пустые строки сохраняются (абзацы), CRLF приводится к LF.
 *
 * КЛАСС СТРОКИ (сессия 19, FIX «при переносе цвет терялся»): каждая
 * строка отображения помнит класс своей ИСХОДНОЙ строки Markdown
 * ('#' заголовок, '[' ссылка, '-' список). Раньше цвет выбирался по
 * ПЕРВОМУ СИМВОЛУ строки отображения: у переносной строки он был
 * только у первого куска, середина оставалась белой, цветной снова
 * становился лишь следующий пункт списка. Теперь куски-продолжения
 * наследуют класс исходной строки; строка с отступа наследует класс
 * предыдущей (продолжение пункта списка в .md), пустая строка класс
 * сбрасывает. */
#ifndef BRLINES_H
#define BRLINES_H

/* классы строк отображения (см. apps_browser.c: цвет по классу) */
#define BRL_CLS_TEXT  0   /* обычный текст */
#define BRL_CLS_HEAD  1   /* '#'-заголовок */
#define BRL_CLS_LINK  2   /* '['-ссылка */
#define BRL_CLS_LIST  3   /* '-'-пункт списка */
#define BRL_CLS_IMG   4   /* сессия 55: строка-якорь картинки/заполнитель
                             (текст НЕ рисуется — место под blit картинки) */
#define BRL_CLS_FORM  5   /* Task 47: строка-якорь поля формы (рисуется
                             контролом — br_draw_field в apps_browser.c) */
#define BRL_CLS_CODE  6   /* [BR-CODE]: строка внутри ```-фенса (рисуется
                             на плашке, блок — в рамке, apps_browser.c) */

typedef struct {
    char **lines;
    unsigned char *cls;    /* класс каждой строки (параллельный массив) */
    int    nlines;
    int    cap;
    /* сессия 55 (кликабельные ссылки): для каждой строки отображения —
     * ИНДЕКС исходной строки (в md) и байтовое смещение куска внутри неё.
     * По клику: строка -> исходная строка -> байт -> ссылка. */
    int   *srcidx;
    int   *srcoff;
    int    cur_src;        /* заполняется brl_wrap: индекс текущей строки */
    int    cur_off;        /* и смещение очередного куска */
} brl_list_t;

/* Освободить все строки списка. */
static void brl_free(brl_list_t *L)
{
    if (!L) return;
    for (int i = 0; i < L->nlines; i++) free(L->lines[i]);
    free(L->lines);
    free(L->cls);
    free(L->srcidx);
    free(L->srcoff);
    L->lines = NULL;
    L->cls = NULL;
    L->srcidx = NULL;
    L->srcoff = NULL;
    L->nlines = 0;
    L->cap = 0;
}

/* Добавить строку (копия len байт) с классом cls. 1 = успех,
 * 0 = нет памяти. srcidx/srcoff берутся из L->cur_src/cur_off. */
static int brl_push(brl_list_t *L, const char *s, int len,
                    unsigned char cls)
{
    if (L->nlines == L->cap) {
        /* realloc в куче ОС нет — удвоение вручную (все массивы) */
        int ncap = L->cap ? L->cap * 2 : 64;
        char **nl = (char **)malloc((u32)ncap * sizeof(char *));
        int *ni, *no;
        unsigned char *nc;
        if (!nl) return 0;
        ni = (int *)malloc((u32)ncap * sizeof(int));
        no = (int *)malloc((u32)ncap * sizeof(int));
        nc = (unsigned char *)malloc((u32)ncap);
        if (!ni || !no || !nc) {
            free(nl); free(ni); free(no); free(nc);
            return 0;
        }
        if (L->lines) {
            memcpy(nl, L->lines, (u32)L->nlines * sizeof(char *));
            free(L->lines);
            memcpy(ni, L->srcidx, (u32)L->nlines * sizeof(int));
            free(L->srcidx);
            memcpy(no, L->srcoff, (u32)L->nlines * sizeof(int));
            free(L->srcoff);
            memcpy(nc, L->cls, (u32)L->nlines);
            free(L->cls);
        }
        L->lines = nl;
        L->srcidx = ni;
        L->srcoff = no;
        L->cls = nc;
        L->cap = ncap;
    }
    char *dup = (char *)malloc((u32)len + 1);
    if (!dup) return 0;
    if (len > 0) memcpy(dup, s, (u32)len);
    dup[len] = 0;
    L->lines[L->nlines] = dup;
    L->cls[L->nlines] = cls;
    L->srcidx[L->nlines] = L->cur_src;
    L->srcoff[L->nlines] = L->cur_off;
    L->cur_off += len;              /* +1 за \n добавит brl_wrap */
    L->nlines++;
    return 1;
}

/* Сессия 55: вставить count ПУСТЫХ строк после pos (включительно —
 * сами они занимают позиции pos..pos+count-1, прежняя строка pos
 * сдвигается вверх). Для резерва места под картинки. srcidx — как у
 * якорной строки (двигаются вместе), класс — BRL_CLS_IMG. */
static int brl_insert_blanks(brl_list_t *L, int pos, int count, int srcidx)
{
    if (count <= 0 || pos < 0 || pos > L->nlines) return 1;
    if (L->nlines + count > L->cap) {
        int ncap = L->cap ? L->cap : 64;
        while (ncap < L->nlines + count) ncap *= 2;
        char **nl = (char **)malloc((u32)ncap * sizeof(char *));
        int *ni = (int *)malloc((u32)ncap * sizeof(int));
        int *no = (int *)malloc((u32)ncap * sizeof(int));
        unsigned char *nc = (unsigned char *)malloc((u32)ncap);
        if (!nl || !ni || !no || !nc) {
            free(nl); free(ni); free(no); free(nc);
            return 0;
        }
        memcpy(nl, L->lines, (u32)L->nlines * sizeof(char *));
        memcpy(ni, L->srcidx, (u32)L->nlines * sizeof(int));
        memcpy(no, L->srcoff, (u32)L->nlines * sizeof(int));
        memcpy(nc, L->cls, (u32)L->nlines);
        free(L->lines); free(L->srcidx); free(L->srcoff); free(L->cls);
        L->lines = nl; L->srcidx = ni; L->srcoff = no; L->cls = nc;
        L->cap = ncap;
    }
    for (int i = L->nlines - 1; i >= pos; i--) {
        L->lines[i + count] = L->lines[i];
        L->srcidx[i + count] = L->srcidx[i];
        L->srcoff[i + count] = L->srcoff[i];
        L->cls[i + count] = L->cls[i];
    }
    for (int k = 0; k < count; k++) {
        L->lines[pos + k] = (char *)malloc(1);
        if (!L->lines[pos + k]) {
            /* частичная вставка: откатывать нечего — строки пустые,
             * счётчик честный */
            L->nlines = pos + k;
            return 0;
        }
        L->lines[pos + k][0] = 0;
        L->srcidx[pos + k] = srcidx;
        L->srcoff[pos + k] = 0;
        L->cls[pos + k] = BRL_CLS_IMG;
    }
    L->nlines += count;
    return 1;
}

/* Разбить md[0..md_len) на строки отображения шириной max_chars
 * СИМВОЛОВ. Старое содержимое L освобождается. Параллельные массивы
 * srcidx/srcoff заполняются всегда (сессия 55). */
static void brl_wrap(const char *md, int md_len, int max_chars, brl_list_t *L)
{
    brl_free(L);
    if (max_chars < 8) max_chars = 8;
    if (!md || md_len <= 0) {
        brl_push(L, "", 0, BRL_CLS_TEXT);
        return;
    }

    unsigned char prev_cls = BRL_CLS_TEXT;   /* класс предыдущей исходной строки */
    int in_code = 0;   /* [BR-CODE]: внутри ```-фенса (сырой код) */
    const char *p = md;
    const char *end = md + md_len;
    L->cur_src = 0;
    L->cur_off = 0;
    while (p < end) {
        const char *nl = p;
        while (nl < end && *nl != '\n') nl++;
        const char *src = p;
        int src_len = (int)(nl - p);
        if (src_len > 0 && src[src_len - 1] == '\r') src_len--;   /* CRLF */

        if (src_len == 0) {
            prev_cls = BRL_CLS_TEXT;            /* абзац сбрасывает продолжение */
            L->cur_off = 0;
            brl_push(L, "", 0, BRL_CLS_TEXT);   /* пустая строка — абзац */
        } else {
            /* [BR-CODE]: фенс — строка, начинающаяся (после ведущих
             * пробелов) с ```. Открывающий и закрывающий фенсы НЕ
             * рисуются (как в настоящих рендерах), строка-фенс даёт
             * пустой паддинг внутри рамки блока. htmlconv выдаёт ``` */
            int fence = 0;
            {
                int q2 = 0;
                while (q2 < src_len && (src[q2] == ' ' || src[q2] == '\t'))
                    q2++;
                if (q2 + 2 < src_len && src[q2] == '`' &&
                    src[q2 + 1] == '`' && src[q2 + 2] == '`')
                    fence = 1;
            }
            if (fence) in_code = !in_code;

            /* класс исходной строки (сессия 19 + Session 92 [HC-LIST]):
             * маркер ищется ПОСЛЕ ведущих отступов — пункты списков
             * теперь пишутся с отступом 4*уровень и маркерами •/◦/▪,
             * нумерация ol — "a) "/"i) "; раньше отступ «съедал» класс. */
            unsigned char cls = BRL_CLS_TEXT;
            int q = 0;
            while (q < src_len && (src[q] == ' ' || src[q] == '\t')) q++;
            unsigned char c0 = (q < src_len) ? (unsigned char)src[q] : 0;
            if (fence) {
                cls = BRL_CLS_CODE;
                prev_cls = BRL_CLS_TEXT;        /* за фенсом класс не тянется */
                L->cur_off = 0;
                brl_push(L, "", 0, BRL_CLS_CODE);   /* паддинг рамки */
                p = (nl < end) ? nl + 1 : nl;
                L->cur_src++;
                L->cur_off = 0;
                continue;
            }
            if (in_code) {
                /* сырой код: БЕЗ распознавания маркеров (иначе '#'-строки
                 * кода рисовались бы заголовками, ']'( — ссылкой) */
                cls = BRL_CLS_CODE;
            } else if (q >= src_len) {
                cls = prev_cls;                     /* строка из одних пробелов */
            } else if (c0 == '#') {
                cls = BRL_CLS_HEAD;
            } else if (c0 == '[') {
                cls = BRL_CLS_LINK;
            } else if (c0 == '-') {
                cls = BRL_CLS_LIST;
            } else if (c0 == 0xE2 && q + 2 < src_len &&
                       (unsigned char)src[q + 1] == 0x80 &&
                       ((unsigned char)src[q + 2] == 0xA2 ||   /* • */
                        (unsigned char)src[q + 2] == 0xA6 ||   /* ◦ */
                        (unsigned char)src[q + 2] == 0xAA)) {  /* ▪ */
                cls = BRL_CLS_LIST;
            } else if (c0 >= '0' && c0 <= '9') {
                /* "12. " / "3) " — нумерованный пункт */
                int k = q;
                while (k < src_len && src[k] >= '0' && src[k] <= '9') k++;
                if (k < src_len && (src[k] == '.' || src[k] == ')') &&
                    k + 1 < src_len && src[k + 1] == ' ')
                    cls = BRL_CLS_LIST;
            } else if (((c0 >= 'a' && c0 <= 'z') ||
                        (c0 >= 'A' && c0 <= 'Z')) &&
                       q + 1 < src_len && src[q + 1] == ')' &&
                       q + 2 < src_len && src[q + 2] == ' ') {
                /* "a) "/"ii) " — буквенная/римская нумерация */
                cls = BRL_CLS_LIST;
            } else if (c0 == ' ' || c0 == '\t') {
                cls = prev_cls;                     /* продолжение */
            }
            /* строка с отступа без маркера — продолжение предыдущей
             * (прежнее поведение; маркерные ветки выше уже отработали) */
            if (!in_code && cls == BRL_CLS_TEXT && q > 0)
                cls = prev_cls;
            /* сессия 55: строка с markdown-ссылкой ](http — красим целиком
             * (кликабельность по позициям — см. brpage.h) */
            if (!in_code && cls == BRL_CLS_TEXT) {
                for (int j = 0; j + 5 < src_len; j++) {
                    if (src[j] == ']' && src[j+1] == '(' &&
                        (src[j+2] == 'h') ) {
                        cls = BRL_CLS_LINK;
                        break;
                    }
                }
            }
            prev_cls = cls;

            int off = 0;
            L->cur_off = 0;
            /* [BR-HEAD-2X]: заголовок рисуется шрифтом 2x (символ — 16px,
             * не 8) — перенос по ПОЛОВИНЕ ширины, иначе 2x-строка
             * вылезает за правый край окна. */
            int line_max = (cls == BRL_CLS_HEAD) ? max_chars / 2 : max_chars;
            if (line_max < 8) line_max = 8;
            while (off < src_len) {
                int room = utf8_take_bytes(src + off, src_len - off, line_max);
                int take = room;
                if (off + room < src_len) {
                    /* кусок не влез целиком: перенос по последнему пробелу */
                    int cut = -1;
                    for (int j = off; j < off + room; j++)
                        if (src[j] == ' ') cut = j;
                    if (cut > off) take = cut - off;
                }
                /* хвостовой пробел при переносе не показываем */
                while (take > 0 && off + take < src_len &&
                       src[off + take - 1] == ' ')
                    take--;
                if (take <= 0) take = 1;   /* страховка от зацикливания */
                if (!brl_push(L, src + off, take, cls)) {
                    off = src_len;   /* нет памяти — остаток строки теряем */
                    break;
                }
                off += take;
            }
            /* [BR-HEAD-2X]: спейсер под заголовком — нижняя половина 2x
             * глифов рисуется В ЕГО строку (строки отображения 16px).
             * Спейсер с тем же классом ничего не рисует, но держит место,
             * чтобы 2x-строка не наезжала на следующий текст. */
            if (cls == BRL_CLS_HEAD)
                brl_push(L, "", 0, BRL_CLS_HEAD);
        }
        p = (nl < end) ? nl + 1 : nl;
        L->cur_src++;
        L->cur_off = 0;
    }
    if (L->nlines == 0) brl_push(L, "", 0, BRL_CLS_TEXT);
}

#endif /* BRLINES_H */
