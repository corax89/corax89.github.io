#!/bin/sh
# run_webp_test.sh — хост-тест WebP-декодера (imgsvc/simplewebp).
# Запускать ПОСЛЕ run_s55.sh (он копирует свежие исходники и собирает
# imgsvc_h.o / simplewebp_h.o).
set -e
cd "$(dirname "$0")"

# тестовые WebP рядом (генерируются scripts/gen_webp_samples.py)
cp -f /home/z/my-project/work/webp/samples/*.webp . 2>/dev/null || true

FLAGS="-std=c99 -D_GNU_SOURCE -g -Wall -Wextra -Wno-unused-parameter"
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address -fno-omit-frame-pointer"
    BIN=webp_test_asan
else
    BIN=webp_test
fi

gcc $FLAGS webp_test.c imgsvc_h.o simplewebp_h.o stb_image_h.o gunzip_h.o -o $BIN
echo "== Запуск $BIN =="
./$BIN
