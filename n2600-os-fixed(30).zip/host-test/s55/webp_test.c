/* webp_test.c — хост-тест [IMG-WEBP]: WebP-декодирование через
 * imgsvc (simplewebp). Компилируется после run_s55.sh (объекты
 * imgsvc_h.o / simplewebp_h.o уже в каталоге).
 *
 * Проверяет:
 *   A. lossless VP8L 4x4 — точные пиксели RGBA (в т.ч. полупрозрачный);
 *   B. lossy VP8 64x48 — пиксели с допуском (квантование);
 *   C. 1600x1200 — ровно на границе IMG_MAX_PIXELS, принимается;
 *   D. 1700x1200 — за лимитом, отказ "слишком большая";
 *   E. обрезанный WebP — отказ (не падает);
 *   F. не-WebP с RIFF-заголовком — отказ (уходит в stb и там отваливается).
 *
 * Прогон: ./run_s55.sh && ./run_webp_test.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
/* стабы окружения imgsvc (static inline — включаем все, чтобы тела
 * функций попали в этот TU и линковка прошла без libkernel-стабов) */
#include "sync.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "task.h"
#include "imgsvc.h"

static int fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); \
                   printf(__VA_ARGS__); printf("\n"); } \
} while (0)

static u8 *load_file(const char *path, u32 *out_len)
{
    FILE *f = fopen(path, "rb");
    u8 *buf;
    long n;
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0) { fclose(f); return NULL; }
    buf = (u8 *)malloc((size_t)n);
    if (!buf) { fclose(f); return NULL; }
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) {
        free(buf); fclose(f); return NULL;
    }
    fclose(f);
    *out_len = (u32)n;
    return buf;
}

static int px_near(const u8 *rgba, int idx,
                   int r, int g, int b, int a, int tol)
{
    const u8 *p = rgba + (size_t)idx * 4;
    return abs(p[0] - r) <= tol && abs(p[1] - g) <= tol &&
           abs(p[2] - b) <= tol && abs(p[3] - a) <= tol;
}

int main(void)
{
    img_t t;
    u32 len;
    u8 *d;

    /* A: lossless 4x4, точные пиксели */
    d = load_file("ll4.webp", &len);
    CHECK(d != NULL, "ll4.webp не прочитан");
    if (d) {
        CHECK(img_decode_mem(d, len, &t) == 0,
              "lossless webp не декодирован: %s", img_errstr());
        if (t.rgba) {
            CHECK(t.w == 4 && t.h == 4, "размеры %dx%d != 4x4", t.w, t.h);
            CHECK(px_near(t.rgba, 0, 255, 0, 0, 255, 0),
                  "px(0,0) не красный: %02x%02x%02x%02x",
                  t.rgba[0], t.rgba[1], t.rgba[2], t.rgba[3]);
            CHECK(px_near(t.rgba, 15, 0, 255, 0, 255, 0),
                  "px(3,3) не зелёный");
            CHECK(px_near(t.rgba, 3, 0, 0, 255, 128, 0),
                  "px(3,0) не полупрозрачный синий: a=%d", t.rgba[11]);
            img_dispose(&t);
        }
        free(d);
    }

    /* B: lossy 64x48 с допуском */
    d = load_file("ls64.webp", &len);
    CHECK(d != NULL, "ls64.webp не прочитан");
    if (d) {
        CHECK(img_decode_mem(d, len, &t) == 0,
              "lossy webp не декодирован: %s", img_errstr());
        if (t.rgba) {
            CHECK(t.w == 64 && t.h == 48,
                  "размеры %dx%d != 64x48", t.w, t.h);
            CHECK(px_near(t.rgba, 4 * 64 + 4, 255, 255, 255, 255, 40),
                  "px(4,4) не белый");
            CHECK(px_near(t.rgba, 12 * 64 + 4, 30, 144, 255, 255, 40),
                  "px(4,12) не синий (30,144,255)");
            img_dispose(&t);
        }
        free(d);
    }

    /* C: 1600x1200 — на границе, принимается */
    d = load_file("max.webp", &len);
    CHECK(d != NULL, "max.webp не прочитан");
    if (d) {
        CHECK(img_decode_mem(d, len, &t) == 0,
              "1600x1200 должен приниматься: %s", img_errstr());
        if (t.rgba) {
            CHECK(t.w == 1600 && t.h == 1200,
                  "размеры %dx%d != 1600x1200", t.w, t.h);
            CHECK(px_near(t.rgba, 0, 10, 20, 30, 255, 0),
                  "px(0,0) не (10,20,30)");
            img_dispose(&t);
        }
        free(d);
    }

    /* D: 1700x1200 — за лимитом IMG_MAX_PIXELS */
    d = load_file("big.webp", &len);
    CHECK(d != NULL, "big.webp не прочитан");
    if (d) {
        CHECK(img_decode_mem(d, len, &t) != 0,
              "1700x1200 должен отвергаться");
        CHECK(t.rgba == NULL, "out.rgba должен быть NULL после отказа");
        free(d);
    }

    /* E: обрезанный WebP — отказ без падения */
    d = load_file("trunc.webp", &len);
    CHECK(d != NULL, "trunc.webp не прочитан");
    if (d) {
        CHECK(img_decode_mem(d, len, &t) != 0,
              "обрезанный webp должен отвергаться");
        free(d);
    }

    /* F: RIFF, но не WEBP — не наш путь, stb тоже отказывает */
    d = load_file("fake.webp", &len);
    CHECK(d != NULL, "fake.webp не прочитан");
    if (d) {
        CHECK(img_decode_mem(d, len, &t) != 0,
              "RIFF без WEBP должен отвергаться");
        free(d);
    }

    printf(fails ? "== webp_test: %d ОШИБОК ==\n" : "== webp_test: ок ==\n",
           fails);
    return fails ? 1 : 0;
}
