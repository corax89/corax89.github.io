/* htmlconv.c — HTML -> Markdown конвертер N2600-OS.
 *
 * Task 60 [HC-DOM]: ПОЛНОЕ ПЕРЕПИСЫВАНИЕ на базе DOM-парсера
 * html_parser.c (html_parse_begin/stream/end). Прежняя версия разбирала
 * HTML ручными эвристиками (сканирование '<', кавычек в атрибутах,
 * прыжки через <script>/<style>, комментарии) — на сложных страницах
 * эвристики расходились с реальной структурой, что вместе с тихой
 * обрезкой по ENSURE/PUT давало «просачивание скриптов» и потерю
 * контента (см. разбор Task 60: сценарии A/B/E/F).
 *
 * Теперь: html_parser строит дерево (теги, атрибуты с декодированными
 * entities, сырой код <script>/<textarea>, пропуск <style>/<template>),
 * а этот модуль ОБХОДИТ дерево итеративно (стек кадров в куче — стек
 * задачи не расходуется) и выдаёт тот же формат, что раньше:
 *
 *   Поддерживаемые теги (формат вывода НЕ менялся — brform.h/brpage.h
 *   и тесты продолжают читать прежние маркеры):
 *   <h1>-<h6> -> #..######; <p> -> пустая строка; <br> -> \n;
 *   <hr> -> ---; <b>/<strong> -> **; <i>/<em> -> *; <code> -> `;
 *   <pre> -> ```; <ul>/<ol>/<li> -> списки с нумерацией;
 *   <a href> -> [текст](href); <img src> -> строка ![alt](src);
 *   формы/скрипты -> маркеры \x01 (разбирает brform.h):
 *     \x01FORM action=".." method=".."
 *     \x01INPUT type=".." name=".." value=".." id=".." ph=".." js=".." [checked]
 *     \x01TEXTAREA .. \n сырой текст \n \x01/TEXTAREA
 *     \x01SELECT name=".." / \x01OPT value=".." label=".." / \x01/SELECT
 *     \x01BUTTON .. label=".."
 *     \x01SCRIPTSRC src="U"  /  \x01SCRIPT \n КОД \n \x01/SCRIPT
 *     \x01REFRESH content="N; url=U"
 *
 * Ключевые исправления Task 60:
 *   [HC-PAIR]  Маркерные строки пишутся АТОМАРНО (влезла строка целиком
 *              или не пишется вовсе — никаких полумаркетов «\x01INPUT
 *              type="te» при обрезке). Блоки \x01SCRIPT/\x01TEXTAREA
 *              резервируют место под закрывающий маркер ЗАРАНЕЕ; если
 *              буфер кончился посреди кода — закрывающий маркер
 *              дописывается, а при невозможности ВСЯ открывашка
 *              откатывается (mi = позиция до маркера). «Висячих»
 *              \x01SCRIPT больше не бывает (сценарий A из разбора).
 *   [HC-TRUNC] html_to_md2 сообщает обрезку через out-параметр
 *              truncated — браузер показывает «страница обрезана»,
 *              раньше статус выглядел как норма (сценарий 1.4/1.5).
 *   [HC-PH-JS] INPUT-маркер теперь пишет ph=".." и js=".." (как ожидает
 *              brf_attr); прежний код писал placeholder=".."/onclick="..",
 *              которые brf_attr НЕ читал — placeholder и onclick полей
 *              молча терялись.
 *   [HC-NOTRIM] Пробелы на стыках текстовых узлов сохраняются
 *              (парсер их больше не режет, нормализация — здесь).
 *
 * Task 67 (улучшения после Task 66):
 *   [HC-HIDDEN] Скрытый контент больше не рисуется: <el hidden>,
 *              style="display:none"/"display: none"/"visibility:hidden"
 *              -> поддерево пропускается (меню-бургеры, скрытые
 *              модалки, счётчики; на живых сайтах их много).
 *   [HC-BQ]     <blockquote> -> префикс "> " (цитата больше не сливается
 *              с основным текстом; многострочность — префикс на первой).
 *   [HC-DL]     <dl>/<dt>/<dd>: термин — **жирным**, определение — с
 *              отступом (прежде сливались с текстом).
 *   [HC-TBL]    Таблицы: наивный TSV — конец ячейки \t, конец строки \n
 *              (прежде структура терялась ПОЛНОСТЬЮ; wiki/доки/прайсы
 *              стали читаемыми). TH/колонки/выравнивание — позже.
 *   [HC-SUM]    <summary> -> '### ' (заголовок раскрытия);
 *              <details>/<figure>/<figcaption> — блочные (ensure_nl).
 *   [HC-AGGR]   Флаг htmlconv_set_aggressive(): 1 = выкидывать
 *              <nav>/<footer>/<aside>/<noscript>. По умолчанию ВЫКЛ
 *              (в <nav> бывает основной контент).
 *   [HC-ENC29]  ')' в href/img-src пишется как %29: раньше URL вида
 *              .../Foo_(bar) обрезался до .../Foo_ (обрыв на первой ')'
 *              — пользователь попадал на неверную страницу).
 *
 * Не поддерживается: полная таблица entities (расширенные мнемоники даёт
 * html_parser.c: copy, mdash, laquo и т.д. — уже UTF-8).
 *
 * Session 92 [HC-TBL2]: таблицы — ПСЕВДОГРАФИКОЙ вместо TSV: рамка
 * ┌─┬┐│├┼┤└┴┘, автоширина колонок (2 прохода: сбор -> рендер),
 * выравнивание ячеек (align=, style="text-align:.."), перенос длинного
 * текста ВНУТРИ ячейки, colspan/rowspan (занятые позиции — пустые
 * ячейки), разделитель после заголовка TH. Лимиты: 64 строки x 12
 * колонок, ячейка 120 байт; превышение — честный откат на TSV-вывод
 * (контент НЕ теряется). Ширина подгоняется под htmlconv_set_table_width().
 *
 * Session 92 [HC-ENC]: кодировки входа windows-1251/koi8-r/iso-8859-5/
 * latin1 — перекодировка в UTF-8 при подаче (hc_stream_feed / перед
 * html_to_md2). Задача кодировки назначается ДО подачи данных.
 *
 * Session 92 [HC-LIST]: маркеры списков по уровням (•/◦/▪/-), нумерация
 * <ol type=...> (a)/A)/i)/I)/1.), отступ 4 пробела на уровень.
 *
 * Session 93 [HC-CSS]: МИНИМАЛЬНЫЙ CSS из style-атрибутов и legacy
 * color="": color: #RRGGBB / именованные -> маркер \x05RRGGBBf
 * (6 hex + флаг b/i/z/-) перед текстом и \x06 при закрытии элемента;
 * font-weight: bold / font-style: italic -> флаги маркера (рисует
 * fb_text_fx: псевдожирный/псевдокурсив); margin-left: Npx -> N/8
 * пробелов в начале строки блочного элемента (p/h1-6/div/blockquote/
 * ul/ol/li/table/form/details/figure). Маркеры вырезает brp_analyze
 * ([BR-CSS] в brpage.h) ДО переноса строк — ширина/клики не ломаются.
 * В <pre>/<script>/<textarea> и ячейках таблиц (коллектор [HC-TBL2])
 * маркеры НЕ выдаются. Вложенность: внутренний стиль переопределяет
 * внешний на время действия, после закрытия внешний восстанавливается
 * (стек стилей в hc_ctx_t, ленивая выдача маркера при первом тексте).
 */

#ifdef HOST_TEST
#include <string.h>   /* хостовой тест: стандартная библиотека */
#include <stdio.h>
#include <stdlib.h>
#include "types.h"    /* u32; тест-харнессы кладут копию types.h рядом */
#else
#include "string.h"   /* ядро: freestanding-версия (src/string.c) */
#include "types.h"
#include "mem.h"
#endif

#include "htmlconv.h"
#include "html_parser.h"
#include "utf8.h"     /* Session 92 [HC-TBL2]: ширина ячеек в СИМВОЛАХ */

/* FIX [HC-HEXESC] (Task 65): маркеры в СТРОКОВЫХ литералах пишутся как
 * "\x01" "FORM" (КОНКАТЕНАЦИЯ), а не "\x01FORM". Причина: в C hex-escape
 * ЖАДНЫЙ — "\x01FORM" это ОДИН байт 0x01F=31 (0x1F) + "ORM", а "\x01BUTTON"
 * — 0x01B=27 (0x1B) + "UTTON" ('F' и 'B' — hex-цифры!). GCC молчит
 * (0x01F < 256), байт в бинарнике портится, brform.h (ждёт 0x01) маркер
 * не узнаёт: формы не работают, строки "ORM action=..."/"UTTON ..."
 * РИСУЮТСЯ как текст страницы (гutenberg, habr и любые страницы с
 * <form>/<button>). Символьная константа HC_MARK не страдает (max 2 цифры). */
#define HC_MARK '\x01'   /* первый символ строки-маркера формы/скрипта */

/* Task 67 [HC-AGGR]: «читательский» режим. 0 = ВЫКЛ (поведение
 * прежнее); 1 = <nav>/<footer>/<aside>/<noscript> выкидываются целиком.
 * Включается вызывающим через htmlconv_set_aggressive() (см. htmlconv.h). */
static int hc_aggressive = 0;

void htmlconv_set_aggressive(int on)
{
    hc_aggressive = on ? 1 : 0;
}

/* Session 92 [HC-TBL2]: ширина таблицы в символах (см. htmlconv.h). */
static int hc_tbl_width = 76;

void htmlconv_set_table_width(int chars)
{
    if (chars < 32) chars = 32;
    if (chars > 200) chars = 200;
    hc_tbl_width = chars;
}

/* ═══════════ Session 92 [HC-ENC]: кодировки однобайтовых страниц ═══════════
 * Каждый байт >= 0x80 разворачивается в последовательность UTF-8 по
 * статической таблице (128 строк; строки в \u-эскейпах — исходник
 * остаётся ASCII, значения сверены с кодеками Python 1:1).
 * Неопределённые позиции кодировки -> "?" (не рвём UTF-8 поток). */

typedef const char *hc_utf8_row_t[128];

static const hc_utf8_row_t hc_cp1251_utf8 = {
    "\u0402","\u0403","\u201a","\u0453","\u201e","\u2026","\u2020","\u2021",
    "\u20ac","\u2030","\u0409","\u2039","\u040a","\u040c","\u040b","\u040f",
    "\u0452","\u2018","\u2019","\u201c","\u201d","\u2022","\u2013","\u2014",
    "?","\u2122","\u0459","\u203a","\u045a","\u045c","\u045b","\u045f",
    "\u00a0","\u040e","\u045e","\u0408","\u00a4","\u0490","\u00a6","\u00a7",
    "\u0401","\u00a9","\u0404","\u00ab","\u00ac","\u00ad","\u00ae","\u0407",
    "\u00b0","\u00b1","\u0406","\u0456","\u0491","\u00b5","\u00b6","\u00b7",
    "\u0451","\u2116","\u0454","\u00bb","\u0458","\u0405","\u0455","\u0457",
    "\u0410","\u0411","\u0412","\u0413","\u0414","\u0415","\u0416","\u0417",
    "\u0418","\u0419","\u041a","\u041b","\u041c","\u041d","\u041e","\u041f",
    "\u0420","\u0421","\u0422","\u0423","\u0424","\u0425","\u0426","\u0427",
    "\u0428","\u0429","\u042a","\u042b","\u042c","\u042d","\u042e","\u042f",
    "\u0430","\u0431","\u0432","\u0433","\u0434","\u0435","\u0436","\u0437",
    "\u0438","\u0439","\u043a","\u043b","\u043c","\u043d","\u043e","\u043f",
    "\u0440","\u0441","\u0442","\u0443","\u0444","\u0445","\u0446","\u0447",
    "\u0448","\u0449","\u044a","\u044b","\u044c","\u044d","\u044e","\u044f"
};

static const hc_utf8_row_t hc_koi8r_utf8 = {
    "\u2500","\u2502","\u250c","\u2510","\u2514","\u2518","\u251c","\u2524",
    "\u252c","\u2534","\u253c","\u2580","\u2584","\u2588","\u258c","\u2590",
    "\u2591","\u2592","\u2593","\u2320","\u25a0","\u2219","\u221a","\u2248",
    "\u2264","\u2265","\u00a0","\u2321","\u00b0","\u00b2","\u00b7","\u00f7",
    "\u2550","\u2551","\u2552","\u0451","\u2553","\u2554","\u2555","\u2556",
    "\u2557","\u2558","\u2559","\u255a","\u255b","\u255c","\u255d","\u255e",
    "\u255f","\u2560","\u2561","\u0401","\u2562","\u2563","\u2564","\u2565",
    "\u2566","\u2567","\u2568","\u2569","\u256a","\u256b","\u256c","\u00a9",
    "\u044e","\u0430","\u0431","\u0446","\u0434","\u0435","\u0444","\u0433",
    "\u0445","\u0438","\u0439","\u043a","\u043b","\u043c","\u043d","\u043e",
    "\u043f","\u044f","\u0440","\u0441","\u0442","\u0443","\u0436","\u0432",
    "\u044c","\u044b","\u0437","\u0448","\u044d","\u0449","\u0447","\u044a",
    "\u042e","\u0410","\u0411","\u0426","\u0414","\u0415","\u0424","\u0413",
    "\u0425","\u0418","\u0419","\u041a","\u041b","\u041c","\u041d","\u041e",
    "\u041f","\u042f","\u0420","\u0421","\u0422","\u0423","\u0416","\u0412",
    "\u042c","\u042b","\u0417","\u0428","\u042d","\u0429","\u0427","\u042a"
};

static const hc_utf8_row_t hc_iso8859_5_utf8 = {
    "?","?","?","?","?","?","?","?",
    "?","?","?","?","?","?","?","?",
    "?","?","?","?","?","?","?","?",
    "?","?","?","?","?","?","?","?",
    "\u00a0","\u0401","\u0402","\u0403","\u0404","\u0405","\u0406","\u0407",
    "\u0408","\u0409","\u040a","\u040b","\u040c","\u00ad","\u040e","\u040f",
    "\u0410","\u0411","\u0412","\u0413","\u0414","\u0415","\u0416","\u0417",
    "\u0418","\u0419","\u041a","\u041b","\u041c","\u041d","\u041e","\u041f",
    "\u0420","\u0421","\u0422","\u0423","\u0424","\u0425","\u0426","\u0427",
    "\u0428","\u0429","\u042a","\u042b","\u042c","\u042d","\u042e","\u042f",
    "\u0430","\u0431","\u0432","\u0433","\u0434","\u0435","\u0436","\u0437",
    "\u0438","\u0439","\u043a","\u043b","\u043c","\u043d","\u043e","\u043f",
    "\u0440","\u0441","\u0442","\u0443","\u0444","\u0445","\u0446","\u0447",
    "\u0448","\u0449","\u044a","\u044b","\u044c","\u044d","\u044e","\u044f",
    "\u2116","\u0451","\u0452","\u0453","\u0454","\u0455","\u0456","\u0457",
    "\u0458","\u0459","\u045a","\u045b","\u045c","\u00a7","\u045e","\u045f"
};

static const hc_utf8_row_t hc_cp1252_utf8 = {
    "\u20ac","?","\u201a","\u0192","\u201e","\u2026","\u2020","\u2021",
    "\u02c6","\u2030","\u0160","\u2039","\u0152","?","\u017d","?",
    "?","\u2018","\u2019","\u201c","\u201d","\u2022","\u2013","\u2014",
    "\u02dc","\u2122","\u0161","\u203a","\u0153","?","\u017e","\u0178",
    "\u00a0","\u00a1","\u00a2","\u00a3","\u00a4","\u00a5","\u00a6","\u00a7",
    "\u00a8","\u00a9","\u00aa","\u00ab","\u00ac","\u00ad","\u00ae","\u00af",
    "\u00b0","\u00b1","\u00b2","\u00b3","\u00b4","\u00b5","\u00b6","\u00b7",
    "\u00b8","\u00b9","\u00ba","\u00bb","\u00bc","\u00bd","\u00be","\u00bf",
    "\u00c0","\u00c1","\u00c2","\u00c3","\u00c4","\u00c5","\u00c6","\u00c7",
    "\u00c8","\u00c9","\u00ca","\u00cb","\u00cc","\u00cd","\u00ce","\u00cf",
    "\u00d0","\u00d1","\u00d2","\u00d3","\u00d4","\u00d5","\u00d6","\u00d7",
    "\u00d8","\u00d9","\u00da","\u00db","\u00dc","\u00dd","\u00de","\u00df",
    "\u00e0","\u00e1","\u00e2","\u00e3","\u00e4","\u00e5","\u00e6","\u00e7",
    "\u00e8","\u00e9","\u00ea","\u00eb","\u00ec","\u00ed","\u00ee","\u00ef",
    "\u00f0","\u00f1","\u00f2","\u00f3","\u00f4","\u00f5","\u00f6","\u00f7",
    "\u00f8","\u00f9","\u00fa","\u00fb","\u00fc","\u00fd","\u00fe","\u00ff"
};

/* Установленная кодировка входа (NULL = UTF-8, перекодировки нет). */
static const hc_utf8_row_t *g_hc_charset = NULL;

/* Распознать имя кодировки (регистр/дефисы/подчёркивания произвольные).
 * Возвращает таблицу или NULL (utf-8/неизвестное — без конвертации). */
static const hc_utf8_row_t *hc_charset_by_name(const char *name)
{
    if (!name || !*name) return NULL;
    char buf[24];
    int k = 0;
    for (; name[k] && k < 23; k++) {
        char c = name[k];
        if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
        if (c == '-' || c == '_') c = ' ';
        buf[k] = c;
    }
    buf[k] = 0;
    static const struct { const char *n; const hc_utf8_row_t *t; } tbl[] = {
        { "windows 1251", &hc_cp1251_utf8 },
        { "cp1251",       &hc_cp1251_utf8 },
        { "cp 1251",      &hc_cp1251_utf8 },
        { "ansi 1251",    &hc_cp1251_utf8 },
        { "koi8 r",       &hc_koi8r_utf8 },
        { "koi8",         &hc_koi8r_utf8 },
        { "koi",          &hc_koi8r_utf8 },
        { "iso 8859 5",   &hc_iso8859_5_utf8 },
        { "latin1",       &hc_cp1252_utf8 },
        { "iso 8859 1",   &hc_cp1252_utf8 },
        { "cp1252",       &hc_cp1252_utf8 },
        { "cp 1252",      &hc_cp1252_utf8 },
        { "windows 1252", &hc_cp1252_utf8 },
        { "ansi",         &hc_cp1252_utf8 },
    };
    for (unsigned i = 0; i < sizeof(tbl) / sizeof(tbl[0]); i++) {
        const char *a = buf, *b = tbl[i].n;
        while (*a && *b && *a == *b) { a++; b++; }
        if (*a == 0 && *b == 0) return tbl[i].t;
    }
    return NULL;
}

int htmlconv_charset_known(const char *name)
{
    if (!name || !*name) return 0;
    if (hc_charset_by_name(name)) return 1;
    /* utf-8 тоже «известна» (просто не требует конвертации) */
    char buf[16];
    int k = 0;
    for (; name[k] && k < 15; k++) {
        char c = name[k];
        if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
        if (c == '-' || c == '_') c = ' ';
        buf[k] = c;
    }
    buf[k] = 0;
    return !strcmp(buf, "utf8") || !strcmp(buf, "utf 8");
}

void htmlconv_set_charset(const char *name)
{
    g_hc_charset = hc_charset_by_name(name);
}

/* Session 92 [HC-ENC]: имя charset= в первых байтах HTML (meta charset
 * или http-equiv/content). Возвращает 1 и имя (или 0). */
static int hc_sniff_charset(const char *d, int len, char *out, int out_max)
{
    if (!d || len < 8) return 0;
    for (int i = 0; i + 8 <= len; i++) {
        if ((d[i] | 0x20) == 'c' && (d[i + 1] | 0x20) == 'h' &&
            (d[i + 2] | 0x20) == 'a' && (d[i + 3] | 0x20) == 'r' &&
            (d[i + 4] | 0x20) == 's' && (d[i + 5] | 0x20) == 'e' &&
            (d[i + 6] | 0x20) == 't' && d[i + 7] == '=') {
            const char *p = d + i + 8;
            int n = 0;
            while (p < d + len && (*p == ' ' || *p == '\t' || *p == '"' ||
                   *p == '\'')) p++;
            while (p < d + len && *p != '"' && *p != '\'' && *p != ';' &&
                   *p != '>' && *p != ' ' && *p != '/' && n < out_max - 1)
                out[n++] = *p++;
            out[n] = 0;
            return n > 0;
        }
    }
    return 0;
}

/* Перекодировать src[0..n) в UTF-8 по таблице cs (NULL — без смены).
 * Пишет в dst (ёмкость dst_max), возвращает число байт. Буферы НЕ
 * пересекаются. Кодировка передаётся ЯВНО: у потока — своя
 * (hs->charset), у буферного пути — одноразовая глобаль. */
static int hc_recode_chunk(const hc_utf8_row_t *cs, const char *src, int n,
                           char *dst, int dst_max)
{
    int o = 0;
    for (int i = 0; i < n; i++) {
        unsigned char c = (unsigned char)src[i];
        const char *u;
        int ulen;
        if (c >= 0x80) {
            u = (*cs)[c - 0x80];
            ulen = (int)strlen(u);
        } else {
            u = src + i;
            ulen = 1;
        }
        if (o + ulen >= dst_max) break;
        memcpy(dst + o, u, (u32)ulen);
        o += ulen;
    }
    return o;
}

/* ═══════════ Session 93 [HC-CSS]: минимальный CSS ═══════════
 * Из style-атрибутов и legacy color="" берётся ТРИ вещи:
 *   цвет текста (color: #RRGGBB / именованный; атрибут color="#..."),
 *   жирность (font-weight: bold|bolder|600..900) и
 *   курсив   (font-style: italic|oblique),
 *   отступ   (margin-left: Npx -> N/8 пробелов в начале блочной строки).
 * Стиль-спан помечается в md маркером \x05 + "RRGGBB" + флаг ('b'/'i'/
 * 'z'/'-') = 8 байт; сброс — \x06. Маркеры вырезает brp_analyze ([BR-CSS]
 * в brpage.h) до переноса строк, поэтому ширина/клики/поиск не страдают.
 * Вложенность: стек стилей в hc_ctx_t; маркер пишется ЛЕНИВО — перед
 * первым нормализованным текстом после смены стиля (пустые спаны не
 * мусорят md). В pre/script/textarea и ячейках таблиц маркеров нет. */

#define HC_STY_MAX 40              /* глубина стека стилей */

typedef struct hc_ctx_s hc_ctx_t;   /* определение ниже (раздел кадров) */

/* прямые объявления (блок [HC-CSS] выше утилит) */
static const char *hc_attr(const HtmlElement *el, HtmlAttribKey key);
static void hc_ensure_nl(hc_ctx_t *ctx);

typedef struct {
    u32 rgb;                       /* 0xRRGGBB, 0 = цвет не задан */
    u8  bold;
    u8  italic;
} hc_sty_t;

/* лимиты формата маркеров (согласованы с brform.h) */
#define HC_JS_MAX 96          /* onclick в маркере (BRF_JS_MAX) */
#define HC_LB_MAX 512         /* строковый конструктор маркера */
#define HC_LIST_MAX 16        /* максимальная глубина списков */
#define HC_HREF_MAX 300       /* href <a> (Task 66: было 220 — согласовано
                              * с BRP_URL_MAX; длинные URL трекинга
                              * обрезались и вели не туда) */
/* Глубина дерева ограничена парсером 128 уровнями (MAX_PARSE_DEPTH в
 * html_parser.c) + виртуальный корень; запас +4. */
#define HC_MAX_DEPTH 132

/* ═══════════ Session 92 [HC-TBL2]: таблицы псевдографикой ═══════════
 * Двухпроходная схема в ПОТОКОВОМ режиме: пока идут события <tr>/<td>,
 * текст ячеек КОПИТСЯ в hc_tbl_t (malloc, освобождается на </table>);
 * на закрытии таблицы — рендер: ширины по максимуму контента, рамка
 * ┌─┬┐│├┼┤└┴┘, выравнивание, перенос текста внутри ячейки.
 * Лимиты исчерпаны (64 строки/12 колонок/120 байт ячейка) — откат на
 * прежний TSV-вывод: контент НЕ теряется, лишь оформление. */
#define HC_TBL_MAX_ROWS 48
#define HC_TBL_MAX_COLS 10
#define HC_TBL_CELL_MAX 96          /* байт текста ячейки */
#define HC_TBL_COL_MIN  5           /* колонка уже — перенос по словам */
#define HC_TBL_COL_MAX  42          /* одна колонка не отъедает весь экран */

typedef struct {
    char text[HC_TBL_CELL_MAX];   /* UTF-8, NUL-терминирован */
    int  len;                     /* байт */
    int  chars;                   /* символов (ширина) */
    int  align;                   /* 0 left, 1 right, 2 center */
    int  header;                  /* 1 = TH */
    int  colspan;
    int  rowspan;
} hc_cell_t;

typedef struct {
    hc_cell_t col[HC_TBL_MAX_COLS];
    int ncols;
    int all_header;               /* все ячейки — TH (для разделителя) */
} hc_trow_t;

typedef struct {
    hc_trow_t row[HC_TBL_MAX_ROWS];
    int nrows;
    int ncols;                    /* максимум колонок по строкам */
    /* текущая собираемая ячейка */
    char cur[HC_TBL_CELL_MAX];
    int  cur_len;
    int  cur_ovf;                 /* текст ячейки обрезан по лимиту */
    int  cur_align, cur_header, cur_colspan, cur_rowspan;
    int  cell_open;               /* 1 = текст идёт в cur (hc_put) */
    int  row_open;                /* 1 = строка начата */
    int  fallback;                /* 1 = лимиты — старый TSV-вывод */
    /* [HC-TBLA]: открытая ссылка в ячейке (<a href=...>text): разметка
     * [T](U) пишется в cur; '[' стоит на cur_a_br; закрытие — по </a>
     * или АВТОМАТОМ в hc_tbl_cell_end (парсер может не прислать </a>). */
    int  cur_a_open;              /* 1 = ссылка не закрыта */
    int  cur_a_br;                /* байтовый индекс '[' в cur */
    char cur_a_href[HC_HREF_MAX]; /* href без изменений */
} hc_tbl_t;

/* ---- кадры итеративного обхода дерева ---- */

enum {
    HC_K_PLAIN = 0,   /* обычный контейнер: текст нормализуем */
    HC_K_PRE,         /* внутри <pre>: текст сырой, элементы прозрачны */
    HC_K_SCRIPT,      /* внутри <script>: сырой код */
    HC_K_TA,          /* внутри <textarea>: сырое значение */
    HC_K_OPT,         /* внутри <option>: копим подпись */
    HC_K_BTN          /* внутри <button>: копим подпись */
};

typedef struct {
    HtmlElement *el;              /* элемент, чьи дети обходим */
    HtmlElement *next;            /* следующий необработанный ребёнок */
    int          kind;            /* HC_K_* */
    int          transparent;     /* Task 66 [HC-TRANSPARENT]: кадр создан
                                  * «прозрачным» спуском внутри pre/script/ta/
                                  * opt/btn — hc_open_tag НЕ звался, его
                                  * закрывающие эффекты НЕ нужны. Без флага
                                  * hc_close_frame смотрит только el->tag и
                                  * для <pre><code>x</code></pre> пишет лишний
                                  * '`' от </code> (и '**' от </b> в pre). */
    int          pre_first;       /* HC_K_PRE: пропустить ведущий \n */
    int          li_count;        /* UL/OL: счётчик номеров <li> */
    char         href[HC_HREF_MAX];   /* <a>: отложенный href */
    int          a_open_mi;       /* <a>: позиция '[' в md (FIX [HC-A-NL]) */
    char         pend_attrs[128]; /* option/button: атрибуты маркера */
    char         label[64];       /* option/button: подпись */
    int          label_len;
    /* Session 93 [HC-CSS]: свой стиль элемента (парсится в hc_open_tag).
     * sty_own=1 -> при создании кадра стиль кладётся в стек ctx (sty_slot),
     * hc_close_frame снимет. Отступ margin учитывается отдельно. */
    int          sty_own;
    int          sty_slot;        /* 1-базный индекс в стеке, 0 = не в стеке */
    hc_sty_t     sty;
} hc_frame_t;

typedef struct hc_ctx_s {
    char *md;
    int   md_max;
    int   mi;
    int   trunc;                  /* FIX [HC-TRUNC]: буфер исчерпан */
    /* FIX [HC-PAIR]: состояние открытых блоков */
    int   sc_open;                /* открыт \x01SCRIPT без закрытия */
    int   sc_pos;                 /* mi ДО открывающего маркера */
    int   ta_open;
    int   ta_pos;
    int   pre_depth;              /* вложенность <pre> */
    char  lb[HC_LB_MAX];          /* конструктор маркерной строки */
    int   lb_len;
    /* Task 68 [HC-GROW]: потоковый режим (hc_stream_*) может расширять
     * буфер вызывателя по мере роста страницы — заранее неизвестной.
     * grow = NULL (обычный html_to_md2) — поведение прежнее. Индексы
     * (sc_pos/ta_pos/a_open_mi) переживают realloc — указателей на md
     * вне ctx никто не хранит. */
    int (*grow)(void *ud, char **md, int *max, int want);
    void *grow_ud;
    int   hard_max;               /* потолок роста (0 = без роста) */
    /* Session 92 [HC-TBL2]: активный сбор таблицы (NULL — нет) */
    hc_tbl_t *tbl;
    /* Session 93 [HC-CSS]: стек активных стилей + «маркер устарел».
     * Маркер пишется лениво — перед первым текстом после изменения.
     * sty_emit — последний ФАКТИЧЕСКИ выданный маркер (лишние \x06
     * без пары и повторные одинаковые \x05 не пишутся). */
    hc_sty_t sty[HC_STY_MAX];
    int      sty_n;
    int      sty_dirty;
    hc_sty_t sty_emit;
    int      sty_emit_valid;
} hc_ctx_t;

/* Session 92 [HC-TBL2]: активная ячейка таблицы — текст в неё */
static void hc_cell_add(hc_ctx_t *ctx, char c)
{
    hc_tbl_t *t = ctx->tbl;
    if (t->cur_len < HC_TBL_CELL_MAX - 1) {
        t->cur[t->cur_len++] = c;
    } else if (!t->cur_ovf) {
        t->cur_ovf = 1;
        /* многоточие вместо обрыва — 3 байта запаса есть (см. above) */
        t->cur[t->cur_len - 1] = '.';
    }
}

/* ================= примитивы вывода ================= */
static int hc_room(hc_ctx_t *ctx, int n)
{
    if (ctx->trunc) return 0;
    if (ctx->md_max - 1 - ctx->mi >= n) return 1;
    /* Task 68 [HC-GROW]: потоковая конвертация — буфер растёт вдвое до
     * hard_max; не хватило (или grow == NULL) — честный trunc. */
    if (ctx->grow && ctx->hard_max > ctx->md_max) {
        int want = ctx->md_max * 2;
        if (want > ctx->hard_max) want = ctx->hard_max;
        if (want < ctx->mi + n + 2) want = ctx->mi + n + 2;
        if (want <= ctx->hard_max &&
            ctx->grow(ctx->grow_ud, &ctx->md, &ctx->md_max, want))
            return (ctx->md_max - 1 - ctx->mi >= n);
    }
    return 0;
}

static void hc_put(hc_ctx_t *ctx, char c)
{
    if (ctx->trunc) return;
    if (ctx->tbl && ctx->tbl->cell_open && !ctx->tbl->fallback) {
        hc_cell_add(ctx, c);      /* [HC-TBL2] */
        return;
    }
    if (!hc_room(ctx, 1)) { ctx->trunc = 1; return; }   /* [HC-GROW] */
    ctx->md[ctx->mi++] = c;
}

/* n байт целиком или ничего (с выставлением trunc) */
static void hc_put_n(hc_ctx_t *ctx, const char *s, int n)
{
    if (ctx->trunc || n <= 0) return;
    if (ctx->tbl && ctx->tbl->cell_open && !ctx->tbl->fallback) {
        for (int i = 0; i < n; i++) hc_cell_add(ctx, s[i]);   /* [HC-TBL2] */
        return;
    }
    if (!hc_room(ctx, n)) { ctx->trunc = 1; return; }   /* [HC-GROW] */
    memcpy(ctx->md + ctx->mi, s, (u32)n);
    ctx->mi += n;
}

static void hc_put2(hc_ctx_t *ctx, char a, char b)
{
    if (ctx->trunc) return;
    if (ctx->tbl && ctx->tbl->cell_open && !ctx->tbl->fallback) {
        hc_cell_add(ctx, a);      /* [HC-TBL2] */
        hc_cell_add(ctx, b);
        return;
    }
    if (!hc_room(ctx, 2)) { ctx->trunc = 1; return; }   /* [HC-GROW] */
    ctx->md[ctx->mi++] = a;
    ctx->md[ctx->mi++] = b;
}

/* удалить пробелы перед переводом строки, чтобы не было " \n" */
static void hc_trim_sp(hc_ctx_t *ctx)
{
    while (ctx->mi > 0 && ctx->md[ctx->mi - 1] == ' ')
        ctx->mi--;
}

/* перевод строки с удалением хвостовых пробелов (старый EMIT_NL) */
static void hc_brk(hc_ctx_t *ctx)
{
    hc_trim_sp(ctx);
    hc_put(ctx, '\n');
}

/* гарантировать перевод строки в конце (старый ENSURE_NL; в старом
 * коде ВСЕ вызовы, кроме <img>, стояли под if (mi > 0) — пустой вывод
 * ведущего \n не даёт; для <img> — hc_brk напрямую) */
static void hc_ensure_nl(hc_ctx_t *ctx)
{
    if (ctx->mi == 0) return;
    if (ctx->md[ctx->mi - 1] != '\n')
        hc_brk(ctx);
}

/* как hc_ensure_nl, но без удаления пробелов (закрытие <pre>) */
static void hc_ensure_nl_raw(hc_ctx_t *ctx)
{
    if (ctx->mi == 0 || ctx->md[ctx->mi - 1] != '\n')
        hc_put(ctx, '\n');
}

/* гарантировать пустую строку (старый ENSURE_BLANK) */
static void hc_ensure_blank(hc_ctx_t *ctx)
{
    if (ctx->mi > 0) {
        hc_ensure_nl(ctx);
        if (ctx->mi < 2 || ctx->md[ctx->mi - 2] != '\n')
            hc_put(ctx, '\n');
    }
}

/* ================= строковый конструктор маркера ================= */

static void hc_lb_reset(hc_ctx_t *ctx)
{
    ctx->lb_len = 0;
    ctx->lb[0] = 0;
}

static void hc_lb_put(hc_ctx_t *ctx, char c)
{
    if (ctx->lb_len < HC_LB_MAX - 1) {
        ctx->lb[ctx->lb_len++] = c;
        ctx->lb[ctx->lb_len] = 0;
    }
}

static void hc_lb_str(hc_ctx_t *ctx, const char *s)
{
    while (*s) hc_lb_put(ctx, *s++);
}

/* значение атрибута маркера: '"' -> &quot;, \n/\r/\x01 -> ' ' */
static void hc_lb_attr(hc_ctx_t *ctx, const char *s)
{
    for (; *s; s++) {
        if (*s == '"')
            hc_lb_str(ctx, "&quot;");
        else if (*s == '\n' || *s == '\r' || *s == HC_MARK)
            hc_lb_put(ctx, ' ');
        else
            hc_lb_put(ctx, *s);
    }
}

/* Task 66 [HC-JS-CAP]: то же с обрезкой значения до max символов.
 * Прежде onclick длиннее HC_LB_MAX-1 молча резался hc_lb_put — маркер
 * уходил в md УСЕЧЁННЫМ ("js=\"...." без закрывающей кавычки), brf_attr
 * читал мусор. BRF_JS_MAX всё равно режет при разборе — режем ЗАРАНЕЕ,
 * чтобы маркер оставался корректным (и комментарий про HC_JS_MAX стал
 * правдой). */
static void hc_lb_attr_cap(hc_ctx_t *ctx, const char *s, int max)
{
    int n = 0;
    for (; *s && n < max; s++, n++) {
        if (*s == '"')
            hc_lb_str(ctx, "&quot;");
        else if (*s == '\n' || *s == '\r' || *s == HC_MARK)
            hc_lb_put(ctx, ' ');
        else
            hc_lb_put(ctx, *s);
    }
}

/* Атомарная маркерная строка: конец текущей строки (с чисткой
 * хвостовых пробелов) + lb + '\n'. Строка целиком или trunc. */
static void hc_flush_line(hc_ctx_t *ctx)
{
    if (ctx->trunc) return;
    if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n') {
        hc_trim_sp(ctx);
        hc_put(ctx, '\n');
        if (ctx->trunc) return;
    }
    /* FIX [HC-GROW2]: было прямое «не влезло -> trunc» мимо grow-хука:
     * потоковая конвертация замирала на первой маркерной строке, не
     * влезшей в стартовый буфер (OPT/SELECT/INPUT исчезали после 63 б).
     * Теперь — hc_room: рост через хук, при отказе — честный trunc. */
    if (!hc_room(ctx, ctx->lb_len + 1)) {
        ctx->trunc = 1;
        return;
    }
    memcpy(ctx->md + ctx->mi, ctx->lb, (u32)ctx->lb_len);
    ctx->mi += ctx->lb_len;
    ctx->md[ctx->mi++] = '\n';
}

/* ================= утилиты ================= */

/* значение атрибута элемента по ключу (уже декодировано парсером) */
static const char *hc_attr(const HtmlElement *el, HtmlAttribKey key)
{
    const HtmlAttrib *a;
    for (a = el->attrib; a; a = a->next)
        if (a->key == key)
            return a->value;
    return NULL;
}

/* сравнение без регистра (для http-equiv="refresh") */
static int hc_ci_eq(const char *a, const char *b)
{
    for (;;) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca = (char)(ca | 0x20);
        if (cb >= 'A' && cb <= 'Z') cb = (char)(cb | 0x20);
        if (ca != cb) return 0;
        if (!ca) return 1;
        a++;
        b++;
    }
}

/* Task 67 [HC-HIDDEN]: подстрока БЕЗ УЧЁТА регистра и БЕЗ УЧЁТА
 * пробелов в haystack (CSS-значения пишут и "display:none", и
 * "display: none", и "display : none"). Пропуски whitespace в HAY
 * разрешены в любых позициях — идентификаторы CSS пробелы внутрь не
 * содержат, ложных срабатываний это не даёт. */
static int hc_ci_strstr(const char *hay, const char *needle)
{
    for (const char *h = hay; *h; h++) {
        const char *p = h;
        const char *q = needle;
        for (;;) {
            while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
            if (!*q) return 1;                  /* весь needle сошёлся */
            if (!*p) break;                     /* hay кончился */
            char a = *p, b = *q;
            if (a >= 'A' && a <= 'Z') a = (char)(a | 0x20);
            if (b >= 'A' && b <= 'Z') b = (char)(b | 0x20);
            if (a != b) break;
            p++; q++;
        }
    }
    return 0;
}

/* [HC-CSS]: подстрока без регистра в haystack ограниченной длины. */
static int hc_ci_strstr_n(const char *hay, int n, const char *needle)
{
    for (int i = 0; i < n; i++) {
        const char *p = hay + i;
        const char *q = needle;
        int left = n - i;
        for (;;) {
            while (left > 0 && (*p == ' ' || *p == '\t' ||
                                *p == '\n' || *p == '\r')) { p++; left--; }
            if (!*q) return 1;
            if (left <= 0 || !*p) break;
            char a = *p, b = *q;
            if (a >= 'A' && a <= 'Z') a = (char)(a | 0x20);
            if (b >= 'A' && b <= 'Z') b = (char)(b | 0x20);
            if (a != b) break;
            p++; left--; q++;
        }
    }
    return 0;
}

static int hc_hex_digit(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/* Значение цвета: "#RRGGBB", "#RGB" или именованный (CSS1 + частые).
 * 1 = распознано. */
static int hc_parse_color(const char *s, int len, u32 *rgb)
{
    while (len > 0 && (*s == ' ' || *s == '\t')) { s++; len--; }
    if (len <= 0) return 0;
    if (*s == '#') {
        s++; len--;
        int d[6], nd = 0;
        while (nd < 6 && len > 0 && hc_hex_digit(*s) >= 0) {
            d[nd++] = hc_hex_digit(*s); s++; len--;
        }
        if (nd == 6) {
            *rgb = ((u32)d[0] << 20) | ((u32)d[1] << 16) |
                   ((u32)d[2] << 12) | ((u32)d[3] << 8) |
                   ((u32)d[4] << 4) | (u32)d[5];
            return 1;
        }
        if (nd == 3) {                       /* #RGB -> дублирование цифр */
            *rgb = ((u32)d[0] << 20) | ((u32)d[0] << 16) |
                   ((u32)d[1] << 12) | ((u32)d[1] << 8) |
                   ((u32)d[2] << 4) | (u32)d[2];
            return 1;
        }
        return 0;
    }
    /* именованный (без регистра) */
    static const struct { const char *n; u32 v; } named[] = {
        { "black",   0x000000 }, { "white",   0xFFFFFF },
        { "red",     0xFF0000 }, { "green",   0x008000 },
        { "lime",    0x00FF00 }, { "blue",    0x0000FF },
        { "yellow",  0xFFFF00 }, { "cyan",    0x00FFFF },
        { "aqua",    0x00FFFF }, { "magenta", 0xFF00FF },
        { "fuchsia", 0xFF00FF }, { "gray",    0x808080 },
        { "grey",    0x808080 }, { "silver",  0xC0C0C0 },
        { "maroon",  0x800000 }, { "olive",   0x808000 },
        { "purple",  0x800080 }, { "teal",    0x008080 },
        { "navy",    0x000080 }, { "orange",  0xFFA500 },
        { "gold",    0xFFD700 }, { "pink",    0xFFC0CB },
        { "brown",   0xA52A2A }, { "violet",  0xEE82EE }
    };
    /* обрезать хвост (';' уже отрезан вызывающим; хвостовые пробелы) */
    while (len > 0 && (s[len - 1] == ' ' || s[len - 1] == '\t')) len--;
    for (unsigned i = 0; i < sizeof(named) / sizeof(named[0]); i++) {
        const char *a = s, *b = named[i].n;
        int n = 0;
        while (n < len && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca = (char)(ca | 0x20);
            if (ca != cb) break;
            a++; b++; n++;
        }
        if (n == len && *b == 0) {
            *rgb = named[i].v;
            return 1;
        }
    }
    return 0;
}

/* Одно объявление "prop: value" (без ';'). */
static void hc_css_decl(const char *p, int n, hc_sty_t *sty, int *margin_px)
{
    /* имя до ':', значение после */
    int ci = 0;
    while (ci < n && p[ci] != ':') ci++;
    if (ci >= n) return;
    const char *v = p + ci + 1;
    int vn = n - ci - 1;
    while (vn > 0 && (*v == ' ' || *v == '\t')) { v++; vn--; }
    /* имя (без регистра, без хвостовых пробелов) */
    char name[16];
    int nn = 0;
    while (ci > 0 && (p[ci - 1] == ' ' || p[ci - 1] == '\t')) ci--;
    while (nn < 15 && nn < ci) {
        char c = p[nn];
        if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
        name[nn++] = c;
    }
    name[nn] = 0;

    if (!strcmp(name, "color")) {
        u32 c;
        if (hc_parse_color(v, vn, &c)) sty->rgb = c;
    } else if (!strcmp(name, "font-weight")) {
        if (hc_ci_strstr_n(v, vn, "bold") || hc_ci_strstr_n(v, vn, "bolder"))
            sty->bold = 1;
        else {
            /* числовой: 600..900 — жирный */
            int num = 0, digits = 0;
            int k = 0;
            while (k < vn && v[k] >= '0' && v[k] <= '9') {
                num = num * 10 + (v[k] - '0'); k++; digits++;
            }
            if (digits && num >= 600) sty->bold = 1;
        }
    } else if (!strcmp(name, "font-style")) {
        if (hc_ci_strstr_n(v, vn, "italic") || hc_ci_strstr_n(v, vn, "oblique"))
            sty->italic = 1;
    } else if (!strcmp(name, "margin-left")) {
        /* Npx / Npt(≈px) / Nem(16px на em) — только неотрицательные */
        int num = 0, digits = 0;
        int k = 0;
        while (k < vn && (v[k] == ' ' || v[k] == '\t' || v[k] == '+')) k++;
        while (k < vn && v[k] >= '0' && v[k] <= '9') {
            num = num * 10 + (v[k] - '0'); k++; digits++;
            if (num > 4096) num = 4096;
        }
        if (!digits) return;
        if (k < vn && (v[k] == 'e' || v[k] == 'E')) num *= 16;   /* em */
        else if (k < vn && (v[k] == 'p' || v[k] == 'P')) {       /* pt/px */
            if (k + 1 < vn && (v[k + 1] == 't' || v[k + 1] == 'T'))
                num = num * 4 / 3;
        } else if (k < vn && v[k] == '%') {
            num = num * 6 / 100;             /* % от ширины окна ~600px/8 */
        }
        if (num > *margin_px) *margin_px = num;
    }
}

/* style="..." -> объявления через ';'. */
static void hc_css_style_attr(const char *s, hc_sty_t *sty, int *margin_px)
{
    int seg = 0;
    for (int i = 0; ; i++) {
        if (s[i] == ';' || s[i] == 0) {
            if (i > seg) hc_css_decl(s + seg, i - seg, sty, margin_px);
            if (!s[i]) break;
            seg = i + 1;
        }
    }
}

/* Разобрать стиль элемента. 1 = есть СВОЙ стиль (цвет/жирность/курсив);
 * margin_px — всегда (отдельно, отступ не создаёт спан). */
static int hc_css_parse(const HtmlElement *el, hc_sty_t *sty, int *margin_px)
{
    sty->rgb = 0;
    sty->bold = 0;
    sty->italic = 0;
    *margin_px = 0;
    const char *st = hc_attr(el, HTML_ATTRIB_STYLE);
    if (st && *st)
        hc_css_style_attr(st, sty, margin_px);
    /* legacy color="#RRGGBB"/color="red" (<font>, <body>, <td>...) */
    if (!sty->rgb) {
        const char *cv = hc_attr(el, HTML_ATTRIB_COLOR);
        if (cv && *cv) {
            u32 c;
            if (hc_parse_color(cv, (int)strlen(cv), &c)) sty->rgb = c;
        }
    }
    return (sty->rgb != 0) || sty->bold || sty->italic;
}

/* Отступ margin-left блочного элемента: пробелы в начале строки
 * (1 колонка = 8 px, потолок 24 — дальше перенос всё равно съест). */
static void hc_margin_indent(hc_ctx_t *ctx, int px)
{
    int n = px / 8;
    if (n <= 0) return;
    if (n > 24) n = 24;
    hc_ensure_nl(ctx);
    for (int i = 0; i < n; i++) hc_put(ctx, ' ');
}

/* Ленивая выдача маркера стиля перед очередным текстом. \x05 несёт
 * ПОЛНЫЙ текущий стиль (верх стека), \x06 — сброс к обычному тексту.
 * Не пишется: повторный тот же стиль; \x06 без парного \x05. */
static void hc_style_flush(hc_ctx_t *ctx)
{
    if (!ctx->sty_dirty) return;
    if (ctx->tbl) return;              /* ячейка: маркеры в текст не пишем */
    ctx->sty_dirty = 0;
    if (ctx->sty_n == 0) {
        if (ctx->sty_emit_valid) {
            hc_put(ctx, '\x06');
            ctx->sty_emit_valid = 0;
        }
        return;
    }
    const hc_sty_t *s = &ctx->sty[ctx->sty_n - 1];
    if (ctx->sty_emit_valid &&
        ctx->sty_emit.rgb == s->rgb &&
        ctx->sty_emit.bold == s->bold &&
        ctx->sty_emit.italic == s->italic)
        return;                        /* стиль не менялся по сути */
    static const char hexd[] = "0123456789abcdef";
    char m[8];
    m[0] = '\x05';
    m[1] = hexd[(s->rgb >> 20) & 15];
    m[2] = hexd[(s->rgb >> 16) & 15];
    m[3] = hexd[(s->rgb >> 12) & 15];
    m[4] = hexd[(s->rgb >> 8) & 15];
    m[5] = hexd[(s->rgb >> 4) & 15];
    m[6] = hexd[s->rgb & 15];
    m[7] = (s->bold && s->italic) ? 'z' : s->bold ? 'b' : s->italic ? 'i' : '-';
    hc_put_n(ctx, m, 8);
    ctx->sty_emit = *s;
    ctx->sty_emit_valid = 1;
}

/* ═══════════ Session 92 [HC-TBL2]: сбор и рендер таблицы ═══════════ */

static void hc_tbl_cell_end(hc_ctx_t *ctx);   /* взаимные вызовы */
static void hc_tbl_render(hc_ctx_t *ctx, hc_tbl_t *t);

/* ───── [HC-TBLA]: ссылки внутри ячеек таблицы ─────
 * Запрос: на wiki-страницах ВСЕ ссылки лежат в <td> — прежде разметка
 * [T](U) в ячейки не писалась вовсе (перехватчик тегов её давил), и
 * браузер показывал таблицу с НЕКЛИКАБЕЛЬНЫМ текстом ("ссылки не
 * подсвечиваются"). Теперь: <a href> в ячейке пишет '[', href — в
 * cur_a_href; закрытие '](' U ')' — по </a> или автоматом при конце
 * ячейки. URL не помещается в ячейку целиком — разметка снимается
 * (текст остаётся, '[' убирается: мусор "](..." в ячейку не попадает).
 * Ширины колонок и паддинг считает hc_cell_vis_chars — по ВИДИМОМУ
 * тексту (URL невидим), поэтому после вырезки разметки brp_analyze
 * рамка таблицы НЕ разъезжается. */

/* если s[i] — начало разметки '[T](U)' целиком в [0..n): вернуть
 * индекс ЗА ')', в *br_out — индекс ']' (может быть NULL); иначе -1. */
static int hc_cell_mk_end(const char *s, int n, int i, int *br_out)
{
    if (i < 0 || i >= n || s[i] != '[') return -1;
    int j = i + 1;
    while (j < n && s[j] != ']') j++;
    if (j + 1 >= n || s[j] != ']' || s[j + 1] != '(') return -1;
    int k = j + 2;
    while (k < n && s[k] != ')') k++;
    if (k >= n) return -1;
    if (br_out) *br_out = j;
    return k + 1;
}

/* видимые СИМВОЛЫ среза s[0..n): разметка [T](U) считается как T
 * (URL/скобки браузер вырежет). Совпадает с utf8_count_chars там,
 * где разметки нет. */
static int hc_cell_vis_chars(const char *s, int n)
{
    int vis = 0, i = 0;
    while (i < n) {
        int br = 0;
        int mk = hc_cell_mk_end(s, n, i, &br);
        if (mk > 0) {
            vis += utf8_count_chars(s + i + 1, br - i - 1);
            i = mk;
            continue;
        }
        int adv = utf8_seq_len((unsigned char)s[i]);
        if (i + adv > n) adv = n - i;
        i += adv;
        vis++;
    }
    return vis;
}

/* Закрыть разметку открытой ссылки в текущей ячейке (](U) с
 * экранированием скобок URL — [HC-ENC29]). Не влезает целиком —
 * снимаем '[': текст остаётся видимым без разметки. */
static void hc_tbl_a_close(hc_ctx_t *ctx)
{
    hc_tbl_t *t = ctx->tbl;
    if (!t || !t->cur_a_open) return;
    t->cur_a_open = 0;
    if (!t->cell_open || t->fallback) return;
    int need = 3;
    for (const char *u = t->cur_a_href; *u; u++)
        need += (*u == ')' || *u == '(') ? 3 : 1;
    if (need > HC_TBL_CELL_MAX - 1 - t->cur_len) {
        /* URL не влезает: убрать '[' (текст Т сдвигом влево) */
        if (t->cur_a_br < t->cur_len && t->cur[t->cur_a_br] == '[') {
            for (int k = t->cur_a_br; k < t->cur_len; k++)
                t->cur[k] = t->cur[k + 1];
            t->cur_len--;
            t->cur[t->cur_len] = 0;
        }
        return;
    }
    t->cur[t->cur_len++] = ']';
    t->cur[t->cur_len++] = '(';
    for (const char *u = t->cur_a_href; *u; u++) {
        if (*u == ')') {
            t->cur[t->cur_len++] = '%';
            t->cur[t->cur_len++] = '2';
            t->cur[t->cur_len++] = '9';
        } else if (*u == '(') {
            t->cur[t->cur_len++] = '%';
            t->cur[t->cur_len++] = '2';
            t->cur[t->cur_len++] = '8';
        } else {
            t->cur[t->cur_len++] = *u;
        }
    }
    t->cur[t->cur_len++] = ')';
    t->cur[t->cur_len] = 0;
}

/* Начало ячейки (TD/TH/CAPTION). Незакрытая предыдущая — закрывается. */
static void hc_tbl_cell_begin(hc_ctx_t *ctx, HtmlElement *el, int is_th)
{
    hc_tbl_t *t = ctx->tbl;
    if (t->fallback) return;
    if (t->cell_open) hc_tbl_cell_end(ctx);
    if (!t->row_open) {
        if (t->nrows >= HC_TBL_MAX_ROWS) { t->fallback = 1; return; }
        t->row_open = 1;
        memset(&t->row[t->nrows], 0, sizeof(t->row[t->nrows]));
    }
    t->cur_len = 0;
    t->cur[0] = 0;
    t->cur_ovf = 0;
    t->cur_header = is_th;
    t->cur_colspan = 1;
    t->cur_rowspan = 1;
    t->cur_align = 0;
    t->cur_a_open = 0;            /* [HC-TBLA]: новая ячейка — без ссылки */
    const char *al = hc_attr(el, HTML_ATTRIB_ALIGN);
    if (al && *al) {
        if (hc_ci_eq(al, "right")) t->cur_align = 1;
        else if (hc_ci_eq(al, "center")) t->cur_align = 2;
    } else {
        const char *st = hc_attr(el, HTML_ATTRIB_STYLE);
        if (st && *st) {
            if (hc_ci_strstr(st, "text-align:right")) t->cur_align = 1;
            else if (hc_ci_strstr(st, "text-align:center")) t->cur_align = 2;
        }
    }
    /* colspan/rowspan: 1..лимиты; мусор/0/отрицательные — как 1 */
    const char *sp = hc_attr(el, HTML_ATTRIB_COLSPAN);
    if (sp && *sp >= '1' && *sp <= '9') {
        int v = 0;
        for (int k = 0; sp[k] >= '0' && sp[k] <= '9'; k++)
            v = v * 10 + (sp[k] - '0');
        if (v < 1) v = 1;
        if (v > HC_TBL_MAX_COLS) v = HC_TBL_MAX_COLS;
        t->cur_colspan = v;
    }
    sp = hc_attr(el, HTML_ATTRIB_ROWSPAN);
    if (sp && *sp >= '1' && *sp <= '9') {
        int v = 0;
        for (int k = 0; sp[k] >= '0' && sp[k] <= '9'; k++)
            v = v * 10 + (sp[k] - '0');
        if (v < 1) v = 1;
        if (v > HC_TBL_MAX_ROWS) v = HC_TBL_MAX_ROWS;
        t->cur_rowspan = v;
    }
    t->cell_open = 1;
}

/* Конец ячейки: текст из cur — в строку. Лениво (след. ячейка/TR/
 * конец таблицы). */
static void hc_tbl_cell_end(hc_ctx_t *ctx)
{
    hc_tbl_t *t = ctx->tbl;
    if (!t || !t->cell_open) return;
    hc_tbl_a_close(ctx);          /* [HC-TBLA]: автозакрытие [T](U) */
    t->cell_open = 0;
    if (t->fallback || !t->row_open) return;
    hc_trow_t *r = &t->row[t->nrows];
    if (r->ncols >= HC_TBL_MAX_COLS) {
        t->fallback = 1;          /* колонок больше лимита — честный TSV */
        return;
    }
    hc_cell_t *c = &r->col[r->ncols++];
    /* хвостовые пробелы долой (hc_text_norm схлопнул внутренние) */
    while (t->cur_len > 0 && t->cur[t->cur_len - 1] == ' ')
        t->cur_len--;
    if (t->cur_len > HC_TBL_CELL_MAX - 1) t->cur_len = HC_TBL_CELL_MAX - 1;
    t->cur[t->cur_len] = 0;
    memcpy(c->text, t->cur, (u32)t->cur_len + 1);
    c->len = t->cur_len;
    /* [HC-TBLA]: ширина — по ВИДИМОМУ тексту (разметка [T](U) невидима:
     * после вырезки её brp_analyze колонка останется той же) */
    c->chars = hc_cell_vis_chars(c->text, c->len);
    c->align = t->cur_align;
    c->header = t->cur_header;
    c->colspan = t->cur_colspan;
    c->rowspan = t->cur_rowspan;
    if (!c->header) r->all_header = 0;
    if (r->ncols == 1) r->all_header = c->header;
    if (r->ncols > t->ncols) t->ncols = r->ncols;
}

/* Граница строки (TR/CAPTION-конец): ячейку долой, строку закрыть. */
static void hc_tbl_row_break(hc_ctx_t *ctx)
{
    hc_tbl_t *t = ctx->tbl;
    if (!t || t->fallback) {
        if (t && t->cell_open) t->cell_open = 0;
        return;
    }
    if (t->cell_open) hc_tbl_cell_end(ctx);
    if (t->row_open) {
        t->row_open = 0;
        if (t->row[t->nrows].ncols > 0 && t->nrows < HC_TBL_MAX_ROWS)
            t->nrows++;
    }
}

/* ────── рендер ────── */

static const char HC_CH_H[]   = "\xe2\x94\x80";  /* ─ */
static const char HC_CH_V[]   = "\xe2\x94\x82";  /* │ */
static const char HC_CH_LTC[] = "\xe2\x94\x8c";  /* ┌ */
static const char HC_CH_RTC[] = "\xe2\x94\x90";  /* ┐ */
static const char HC_CH_LBC[] = "\xe2\x94\x94";  /* └ */
static const char HC_CH_RBC[] = "\xe2\x94\x98";  /* ┘ */
static const char HC_CH_MID[] = "\xe2\x94\xbc";  /* ┼ */
static const char HC_CH_TOP[] = "\xe2\x94\xac";  /* ┬ */
static const char HC_CH_BOT[] = "\xe2\x94\xb4";  /* ┴ */
static const char HC_CH_LJ[]  = "\xe2\x94\x9c";  /* ├ */
static const char HC_CH_RJ[]  = "\xe2\x94\xa4";  /* ┤ */

/* Линия рамки: left + (─×w[0] + mid + ─×w[1]...) + right */
static void hc_tbl_border(hc_ctx_t *ctx, int maxc, const int *w,
                          const char *left, const char *mid,
                          const char *right)
{
    hc_put_n(ctx, left, 3);
    for (int c = 0; c < maxc; c++) {
        if (c > 0) hc_put_n(ctx, mid, 3);
        for (int k = 0; k < w[c]; k++) hc_put_n(ctx, HC_CH_H, 3);
    }
    hc_put_n(ctx, right, 3);
    hc_put(ctx, '\n');
}

/* line_idx-я строка ячейки c (перенос по словам в width ВИДИМЫХ
 * символов). [HC-TBLA]: разметка ссылки [T](U) — АТОМНЫЙ токен (видима
 * как текст T, URL невидим; между строками не рвётся). Токен шире
 * колонки: разметка отдаётся как ОБЫЧНЫЙ ТЕКСТ (первые width символов
 * T, хвост и URL долой) — мусор "](..." в ячейку не попадает.
 * Возвращает 1 и s/len (срез внутри c->text; sp/sl могут быть NULL
 * при подсчёте строк), 0 — строкей больше нет. */
static int hc_tbl_cell_line(const hc_cell_t *c, int width, int line_idx,
                            const char **sp, int *sl)
{
    if (width < 1) width = 1;
    int off = 0;
    for (int li = 0; ; li++) {
        /* пропустить ведущие пробелы */
        while (off < c->len && c->text[off] == ' ') off++;
        if (off >= c->len) return 0;
        int vis = 0;              /* видимых символов набрано */
        int take = 0;             /* байт куска от (off+skip) */
        int skip = 0;             /* байт от off ДО начала куска (снятый '[') */
        int next_off = -1;        /* >=0 — перепрыгнуть токен (остаток долой) */
        int p = off;
        while (p < c->len) {
            if (c->text[p] == ' ') {
                if (vis == 0) { p++; continue; }      /* ведущие */
                if (vis + 1 > width) break;           /* перенос */
                vis++;
                take = p + 1 - off;
                p++;
                continue;
            }
            /* токен: разметка [T](U) или слово до пробела/конца */
            int br = 0;
            int mk = hc_cell_mk_end(c->text, c->len, p, &br);
            int tb, tv;
            if (mk > 0) {
                tb = mk - p;
                tv = utf8_count_chars(c->text + p + 1, br - p - 1);
            } else {
                int q = p;
                while (q < c->len && c->text[q] != ' ') q++;
                tb = q - p;
                tv = utf8_count_chars(c->text + p, tb);
            }
            if (vis + tv <= width) {
                vis += tv;
                take = p + tb - off;
                p += tb;
                continue;
            }
            if (vis > 0) break;       /* токен целиком — на след. строку */
            /* токен шире колонки: слово режем по границе символов;
             * разметку СНИМАЕМ — отдаём первые width символов T
             * (срез после '['), хвост T и URL пропускаем целиком */
            if (mk > 0) {
                skip = 1;             /* '[' не показываем */
                take = utf8_take_bytes(c->text + p + 1, br - p - 1, width);
                next_off = mk;        /* хвост T и ](U) — мимо */
            } else {
                take = utf8_take_bytes(c->text + p, tb, width);
            }
            break;                    /* строка заполнена */
        }
        if (take == 0) {
            /* страховка от зацикливания: минимум 1 символ */
            take = utf8_take_bytes(c->text + off + skip, c->len - off - skip, 1);
        }
        /* хвостовые пробелы куска долой */
        while (take > skip && c->text[off + take - 1] == ' ') take--;
        if (take <= skip) take = skip + 1;
        if (li == line_idx) {
            if (sp) *sp = c->text + off + skip;
            if (sl) *sl = take - skip;
            return 1;
        }
        off = (next_off >= 0) ? next_off : off + take;
    }
}

/* Отдать собранную таблицу в md. */
static void hc_tbl_render(hc_ctx_t *ctx, hc_tbl_t *t)
{
    if (t->fallback) {
        /* собранные строки — прежний TSV (контент не теряем) */
        for (int r = 0; r < t->nrows; r++) {
            for (int k = 0; k < t->row[r].ncols; k++) {
                if (k) hc_put(ctx, '\t');
                hc_put_n(ctx, t->row[r].col[k].text, t->row[r].col[k].len);
            }
            hc_ensure_nl(ctx);
        }
        return;
    }
    if (t->nrows == 0 || t->ncols == 0) return;

    /* занятость сетки: 0xFF пусто, 0xFE занято span-ом, 0..ncols-1 —
     * индекс ячейки-якоря в своей строке */
    u8 grid[HC_TBL_MAX_ROWS][HC_TBL_MAX_COLS];
    memset(grid, 0xFF, sizeof(grid));
    for (int r = 0; r < t->nrows; r++) {
        int c = 0;
        for (int k = 0; k < t->row[r].ncols; k++) {
            hc_cell_t *cell = &t->row[r].col[k];
            while (c < HC_TBL_MAX_COLS && grid[r][c] != 0xFF) c++;
            if (c >= HC_TBL_MAX_COLS) break;
            grid[r][c] = (u8)k;
            for (int dr = r; dr < r + cell->rowspan && dr < HC_TBL_MAX_ROWS;
                 dr++)
                for (int dc = (dr == r ? c + 1 : c);
                     dc < c + cell->colspan && dc < HC_TBL_MAX_COLS; dc++)
                    if (grid[dr][dc] == 0xFF) grid[dr][dc] = 0xFE;
            c += cell->colspan;
        }
    }
    int maxc = 0;
    for (int r = 0; r < t->nrows; r++)
        for (int c = HC_TBL_MAX_COLS - 1; c >= 0; c--)
            if (grid[r][c] != 0xFF) {
                if (c + 1 > maxc) maxc = c + 1;
                break;
            }
    if (maxc == 0) return;

    /* ширины колонок: максимум по якорным ячейкам */
    int w[HC_TBL_MAX_COLS];
    for (int c = 0; c < maxc; c++) {
        w[c] = 1;
        for (int r = 0; r < t->nrows; r++) {
            u8 g = grid[r][c];
            if (g != 0xFF && g != 0xFE) {
                hc_cell_t *cell = &t->row[r].col[g];
                if (cell->chars > w[c]) w[c] = cell->chars;
            }
        }
        if (w[c] > HC_TBL_COL_MAX) w[c] = HC_TBL_COL_MAX;
        if (w[c] < HC_TBL_COL_MIN) w[c] = HC_TBL_COL_MIN;
    }
    /* бюджет ширины (рамка = maxc+1 символов): самую широкую — вниз */
    {
        int sum = 0;
        for (int c = 0; c < maxc; c++) sum += w[c];
        while (sum + maxc + 1 > hc_tbl_width) {
            int big = -1, bv = HC_TBL_COL_MIN;
            for (int c = 0; c < maxc; c++)
                if (w[c] > bv) { bv = w[c]; big = c; }
            if (big < 0) break;   /* всё на минимуме — переносит brl_wrap */
            w[big]--;
            sum--;
        }
    }

    hc_tbl_border(ctx, maxc, w, HC_CH_LTC, HC_CH_TOP, HC_CH_RTC);
    for (int r = 0; r < t->nrows; r++) {
        if (t->row[r].ncols == 0) continue;
        int nl[HC_TBL_MAX_COLS], mx = 1;
        for (int c = 0; c < maxc; c++) {
            u8 g = grid[r][c];
            nl[c] = 0;
            if (g != 0xFF && g != 0xFE) {
                hc_cell_t *cell = &t->row[r].col[g];
                nl[c] = 1;
                while (hc_tbl_cell_line(cell, w[c], nl[c], NULL, NULL))
                    nl[c]++;
                if (nl[c] > mx) mx = nl[c];
            }
        }
        for (int li = 0; li < mx; li++) {
            hc_put_n(ctx, HC_CH_V, 3);
            for (int c = 0; c < maxc; c++) {
                u8 g = grid[r][c];
                const char *s = "";
                int n = 0;
                if (g != 0xFF && g != 0xFE) {
                    hc_cell_t *cell = &t->row[r].col[g];
                    if (!hc_tbl_cell_line(cell, w[c], li, &s, &n)) {
                        s = ""; n = 0;
                    }
                }
                /* [HC-TBLA]: паддинг — по ВИДИМЫМ символам куска (в срезе
                 * может быть разметка [T](U): URL невидим и после
                 * вырезки brp_analyze колонка останется выровненной) */
                int pad = w[c] - hc_cell_vis_chars(s, n);
                if (pad < 0) pad = 0;
                int pre = 0;
                if (li == 0 && g != 0xFF && g != 0xFE) {
                    hc_cell_t *cell = &t->row[r].col[g];
                    if (cell->align == 1) pre = pad;
                    else if (cell->align == 2) pre = pad / 2;
                }
                for (int k = 0; k < pre; k++) hc_put(ctx, ' ');
                hc_put_n(ctx, s, n);
                for (int k = 0; k < pad - pre; k++) hc_put(ctx, ' ');
                hc_put_n(ctx, HC_CH_V, 3);
            }
            hc_put(ctx, '\n');
        }
        /* разделитель после блока заголовков TH: ├─┼─┤ (внутри рамки) */
        if (t->row[r].all_header && r + 1 < t->nrows &&
            t->row[r + 1].ncols > 0 && !t->row[r + 1].all_header)
            hc_tbl_border(ctx, maxc, w, HC_CH_LJ, HC_CH_MID, HC_CH_RJ);
    }
    hc_tbl_border(ctx, maxc, w, HC_CH_LBC, HC_CH_BOT, HC_CH_RBC);
}

/* Перехват тегов при активном сборе таблицы. Возврат: 0 лист, 1 кадр
 * (transparent), -1 поддерево прочь; НИКОГДА не пускает теги в общий
 * switch — эффекты разметки внутри ячеек подавлены. */
static int hc_tbl_open_tag(hc_ctx_t *ctx, HtmlElement *el, hc_frame_t *nf,
                           int *kind)
{
    hc_tbl_t *t = ctx->tbl;
    *kind = HC_K_PLAIN;
    nf->transparent = 1;          /* закрывающие эффекты не нужны */

    switch (el->tag) {
    case HTML_TAG_TABLE:
        return -1;                /* вложенная таблица — содержимое мимо */
    case HTML_TAG_A: {
        /* [HC-TBLA]: ссылка в ячейке — пишем разметку [T](U) в текст
         * ячейки: '[' сейчас, '](href)' — по </a> или автоматом при
         * конце ячейки (hc_tbl_a_close). Без href — обычный текст. */
        const char *h = hc_attr(el, HTML_ATTRIB_HREF);
        if (t->cur_a_open)
            hc_tbl_a_close(ctx);      /* вложенный <a> — закрыть прежний */
        if (h && *h && t->cell_open && !t->fallback) {
            int k = 0;
            for (; h[k] && k < HC_HREF_MAX - 1; k++)
                t->cur_a_href[k] = h[k];
            t->cur_a_href[k] = 0;
            if (t->cur_len < HC_TBL_CELL_MAX - 1) {
                t->cur_a_br = t->cur_len;
                t->cur[t->cur_len++] = '[';
                t->cur[t->cur_len] = 0;
                t->cur_a_open = 1;
            }
        }
        return 1;
    }
    case HTML_TAG_TR:
        hc_tbl_row_break(ctx);
        return 1;
    case HTML_TAG_TD:
    case HTML_TAG_TH:
        hc_tbl_cell_begin(ctx, el, el->tag == HTML_TAG_TH);
        return 1;
    case HTML_TAG_THEAD:
    case HTML_TAG_TBODY:
    case HTML_TAG_TFOOT:
        return 1;
    case HTML_TAG_IMG: {
        const char *alt = hc_attr(el, HTML_ATTRIB_ALT);
        if (t->cell_open) {
            hc_cell_add(ctx, '[');
            if (alt && *alt) {
                for (const char *p = alt; *p; p++) hc_cell_add(ctx, *p);
            } else {
                hc_cell_add(ctx, 'i');
                hc_cell_add(ctx, 'm');
                hc_cell_add(ctx, 'g');
            }
            hc_cell_add(ctx, ']');
        }
        return 0;
    }
    case HTML_TAG_BR:
        if (t->cell_open) hc_cell_add(ctx, ' ');
        return 0;
    case HTML_TAG_INPUT: {
        if (!t->cell_open) return 0;
        const char *vv = hc_attr(el, HTML_ATTRIB_VALUE);
        const char *ty = hc_attr(el, HTML_ATTRIB_TYPE);
        const char *s = (vv && *vv) ? vv
                        : (ty && hc_ci_eq(ty, "submit")) ? "OK"
                        : (ty && hc_ci_eq(ty, "checkbox")) ? "[x]"
                        : (ty && hc_ci_eq(ty, "radio")) ? "(@)" : "[поле]";
        for (; *s; s++) hc_cell_add(ctx, *s);
        return 0;
    }
    case HTML_TAG_SELECT:
    case HTML_TAG_TEXTAREA:
    case HTML_TAG_FORM:
    case HTML_TAG_SCRIPT:
    case HTML_TAG_BUTTON:
    case HTML_TAG_OPTION:
        return -1;                /* формы/скрипты внутри таблиц — мимо */
    default:
        return 1;                 /* контейнер: текст течёт в ячейку */
    }
}

/* ---------------- текст ---------------- */

/* нормализованный текст: '\n'/\r/\t -> ' ', пробелы схлопываются,
 * \x01 (мусор из страницы) -> ' ' — как старое «сжатие пробелов» */
/* Task 68 [HC-SAX]: текст приходит (указатель, длина) — событийный
 * режим парсера не обязан NUL-терминировать буфер. */
static void hc_text_norm(hc_ctx_t *ctx, const char *s, int n)
{
    /* [HC-CSS]: маркер стиля — перед первым текстом после смены */
    if (ctx->sty_dirty)
        hc_style_flush(ctx);
    for (int i = 0; i < n && s[i]; i++) {
        char c = s[i];
        if (c == '\n' || c == '\r' || c == '\t') c = ' ';
        if (c == HC_MARK) c = ' ';
        if (c == '\x05' || c == '\x06')
            c = ' ';             /* [HC-CSS]: мусорные маркеры из текста */
        if (c == ' ') {
            /* Session 92 [HC-TBL2]: при сборе ячейки «предыдущий» —
             * в буфере ячейки, а не в md (иначе пробелы ВНУТРИ ячейки
             * схлопывались по хвосту md — слова склеивались). */
            char prev;
            if (ctx->tbl && ctx->tbl->cell_open && !ctx->tbl->fallback)
                prev = ctx->tbl->cur_len > 0
                       ? ctx->tbl->cur[ctx->tbl->cur_len - 1] : '\n';
            else {
                prev = (ctx->mi == 0) ? '\n' : ctx->md[ctx->mi - 1];
                /* [HC-CSS]: сразу после маркера стиля (\x05..8 байт или
                 * \x06) ведущий пробел текста спана схлопывается —
                 * он был форматировкой исходника, не словоразделителем */
                if (ctx->mi >= 8 && ctx->md[ctx->mi - 8] == '\x05')
                    prev = '\n';
                else if (ctx->mi >= 1 && ctx->md[ctx->mi - 1] == '\x06')
                    prev = '\n';
            }
            if (prev == ' ' || prev == '\n')
                continue;
        }
        hc_put(ctx, c);
    }
}

/* сырой текст (код скрипта, значение textarea, содержимое <pre>) */
static void hc_text_raw(hc_ctx_t *ctx, const char *s, int n)
{
    for (int i = 0; i < n && s[i]; i++) {
        char c = s[i];
        /* [HC-CSS]: случайные \x05/\x06 в сыром тексте (pre) не должны
         * превращаться в маркеры стилей при разборе страницы */
        if (c == '\x05' || c == '\x06') c = ' ';
        hc_put(ctx, c);
    }
}

/* подпись option/button: переносы/табы -> пробел, пробелы схлопываются */
static void hc_label_add(hc_frame_t *fr, const char *s, int n)
{
    for (int i = 0; i < n && s[i]; i++) {
        char c = s[i];
        if (c == '\n' || c == '\r' || c == '\t') c = ' ';
        if (c == ' ' && (fr->label_len == 0 ||
                         fr->label[fr->label_len - 1] == ' '))
            continue;
        if (fr->label_len < (int)sizeof(fr->label) - 1)
            fr->label[fr->label_len++] = c;
    }
    fr->label[fr->label_len] = 0;
}

/* дописать " name=\"..\""-фрагмент в pend_attrs option/button */
static void hc_pa_add(hc_frame_t *nf, const char *name, const char *val,
                      int lower)
{
    char tmp[96];
    int k = 0;
    int l;
    if (!val || !*val) return;
    for (; val[k] && k < 94; k++)
        tmp[k] = (lower && val[k] >= 'A' && val[k] <= 'Z')
                 ? (char)(val[k] | 0x20) : val[k];
    tmp[k] = 0;
    l = (int)strlen(nf->pend_attrs);
    snprintf(nf->pend_attrs + l, sizeof(nf->pend_attrs) - (u32)l,
             " %s=\"%s\"", name, tmp);
}

/* Session 92 [HC-LIST]: маркер <ol type=...> для пункта v.
 * type 'a'/'A' — буквы (v=1..26), 'i'/'I' — римские (v=1..30),
 * иначе/переполнение — десятичные "N. ". Буквы/римские — с ") ". */
static int hc_ol_marker(const char *type, int v, char *out, int out_max)
{
    int o = 0;
    char lc = (type && *type) ? type[0] : 0;
    if (lc == 'a' || lc == 'A') {
        if (v >= 1 && v <= 26) {
            out[o++] = (char)(lc + (v - 1));
            out[o++] = ')';
            out[o++] = ' ';
            out[o] = 0;
            return o;
        }
        lc = 0;                       /* за алфавитом — десятичные */
    } else if (lc == 'i' || lc == 'I') {
        if (v >= 1 && v <= 30) {
            static const struct { int val; const char *s; } rom[] = {
                { 10, "x" }, { 9, "ix" }, { 5, "v" }, { 4, "iv" }, { 1, "i" }
            };
            int vv = v;
            for (int k = 0; k < 5 && vv > 0; k++)
                while (vv >= rom[k].val) {
                    for (const char *p = rom[k].s; *p; p++)
                        out[o++] = (lc == 'I') ? (char)(*p - 32) : *p;
                    vv -= rom[k].val;
                }
            out[o++] = ')';
            out[o++] = ' ';
            out[o] = 0;
            return o;
        }
        lc = 0;
    }
    /* десятичные "N. " (и default без type, и переполнения) */
    if (o + 12 > out_max) return 0;
    if (v <= 0) {
        out[o++] = '0';
    } else {
        char tmp[12];
        int n = 0;
        while (v > 0 && n < (int)sizeof(tmp)) {
            tmp[n++] = (char)('0' + (v % 10));
            v /= 10;
        }
        while (n > 0) out[o++] = tmp[--n];
    }
    out[o++] = '.';
    out[o++] = ' ';
    out[o] = 0;
    return o;
}

/* ================= открытие/закрытие элементов ================= */

static int hc_open_tag_impl(hc_ctx_t *ctx, hc_frame_t *frames, int depth,
                            HtmlElement *el, hc_frame_t *nf, int *kind);

/* Открытие элемента: реализация + [HC-CSS] push СВОЕГО стиля в стек
 * (только когда создан кадр — r==1; снимет hc_close_frame). */
static int hc_open_tag(hc_ctx_t *ctx, hc_frame_t *frames, int depth,
                       HtmlElement *el, hc_frame_t *nf, int *kind)
{
    int r = hc_open_tag_impl(ctx, frames, depth, el, nf, kind);
    if (r == 1 && nf->sty_own) {
        if (ctx->sty_n < HC_STY_MAX) {
            ctx->sty[ctx->sty_n] = nf->sty;
            ctx->sty_n++;
            nf->sty_slot = ctx->sty_n;    /* 1-базный */
            ctx->sty_dirty = 1;           /* маркер — при первом тексте */
        }
        /* стек полон — стиль элемента не применяется (не бывает: парсер
         * держит глубину 128, стек 40 покрывает реальные страницы) */
    }
    return r;
}

/* Открытие: выдаёт открывающую разметку/маркер. kind — режим кадра для
 * детей. Возврат: 1 = спуститься в детей (кадр создаётся даже для
 * пустого элемента — закрывающие эффекты обязаны сработать),
 * 0 = лист (спуск не нужен), -1 = поддерево пропустить (маркер уже
 * выдан: <script src>). frames/depth — для вычисления уровня <li>. */
static int hc_open_tag_impl(hc_ctx_t *ctx, hc_frame_t *frames, int depth,
                            HtmlElement *el, hc_frame_t *nf, int *kind)
{
    const char *av;

    *kind = HC_K_PLAIN;

    /* Session 92 [HC-TBL2]: активный сбор таблицы — перехват ВСЕХ тегов
     * (эффекты разметки внутри ячеек подавлены, текст течёт в ячейку).
     * hc_tbl_open_tag никогда не возвращает -2: весь switch ниже — вне
     * таблиц. */
    if (ctx->tbl)
        return hc_tbl_open_tag(ctx, el, nf, kind);

    /* Task 67 [HC-AGGR]: «читательский» режим (по умолчанию ВЫКЛ).
     * До всех остальных веток: поддерево пропускается ЦЕЛИКОМ. */
    if (hc_aggressive) {
        switch (el->tag) {
        case HTML_TAG_NAV:
        case HTML_TAG_FOOTER:
        case HTML_TAG_ASIDE:
        case HTML_TAG_NOSCRIPT:
            return -1;
        default:
            break;
        }
    }

    /* Task 67 [HC-HIDDEN]: скрытый контент не рисуем (в реальных
     * браузерах он невидим): булев hidden, display:none (в т.ч.
     * с пробелами/регистром), visibility:hidden. БЕЗ CSS остальные
     * стили разобрать нельзя — проверяем только эти три признака. */
    if (hc_attr(el, HTML_ATTRIB_HIDDEN))
        return -1;
    {
        const char *st = hc_attr(el, HTML_ATTRIB_STYLE);
        if (st && *st &&
            (hc_ci_strstr(st, "display:none") ||
             hc_ci_strstr(st, "visibility:hidden")))
            return -1;
    }

    /* Session 93 [HC-CSS]: свой стиль (цвет/жирность/курсив) и отступ
     * элемента. push стиля делает обёртка hc_open_tag при создании кадра;
     * отступ применяют блочные case'ы ниже. */
    hc_sty_t my_sty;
    int my_margin = 0;
    nf->sty_own = hc_css_parse(el, &my_sty, &my_margin);
    if (nf->sty_own)
        nf->sty = my_sty;

    switch (el->tag) {

    case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
    case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6: {
        /* теги H1..H6 идут подряд в enum html_parser.h */
        int v = (int)(el->tag - HTML_TAG_H1) + 1;
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        for (int i = 0; i < v; i++) hc_put(ctx, '#');
        hc_put(ctx, ' ');
        return 1;
    }

    case HTML_TAG_P:
        hc_ensure_blank(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        return 1;

    case HTML_TAG_DIV:
        /* [HC-CSS]: div — блочный; отступ требует новой строки.
         * Без margin div остаётся прозрачным (как прежде). */
        if (my_margin > 0)
            hc_margin_indent(ctx, my_margin);
        return 1;

    case HTML_TAG_BR:
        hc_brk(ctx);
        return 0;

    case HTML_TAG_HR:
        hc_ensure_nl(ctx);
        hc_put_n(ctx, "---\n", 4);
        return 0;

    case HTML_TAG_B:
    case HTML_TAG_STRONG:
        hc_put2(ctx, '*', '*');
        return 1;

    case HTML_TAG_I:
    case HTML_TAG_EM:
        hc_put(ctx, '*');
        return 1;

    case HTML_TAG_CODE:
        hc_put(ctx, '`');
        return 1;

    case HTML_TAG_PRE:
        if (ctx->pre_depth == 0) {
            hc_ensure_nl(ctx);
            hc_put_n(ctx, "```\n", 4);
        }
        ctx->pre_depth++;
        *kind = HC_K_PRE;
        nf->pre_first = 1;
        return 1;

    case HTML_TAG_UL:
    case HTML_TAG_OL:
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        nf->li_count = 0;
        return 1;

    case HTML_TAG_LI: {
        int lvl = 0;
        hc_frame_t *lf = NULL;
        for (int k = 0; k <= depth; k++) {
            HtmlTag t = frames[k].el->tag;
            if (t == HTML_TAG_UL || t == HTML_TAG_OL) {
                lvl++;
                lf = &frames[k];
            }
        }
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        /* Session 92 [HC-LIST]: 4 пробела на уровень (было 2) */
        {
            int ind = lvl > 0 ? lvl - 1 : 0;
            if (ind > HC_LIST_MAX) ind = HC_LIST_MAX;
            for (int i = 0; i < ind * 4; i++) hc_put(ctx, ' ');
        }
        if (lvl > 0 && lf && lf->el->tag == HTML_TAG_OL) {
            /* [HC-LIST]: нумерация по type <ol>: a)/A)/i)/I)/1. */
            int v = ++lf->li_count;
            const char *ty = hc_attr(lf->el, HTML_ATTRIB_TYPE);
            char num[24];
            int n = hc_ol_marker(ty, v, num, (int)sizeof(num));
            hc_put_n(ctx, num, n);
        } else {
            /* [HC-LIST]: маркер по уровню: •/◦/▪/- */
            static const char *const ul_markers[4] = {
                "\xe2\x80\xa2 ",   /* • уровень 1 */
                "\xe2\x97\xa6 ",   /* ◦ уровень 2 */
                "\xe2\x96\xaa ",   /* ▪ уровень 3 */
                "- "              /* глубже — обычный дефис */
            };
            int mi2 = (lvl > 0 ? lvl - 1 : 0) % 4;
            const char *m = ul_markers[mi2];
            hc_put_n(ctx, m, (int)strlen(m));
        }
        return 1;
    }

    case HTML_TAG_A: {
        const char *h = hc_attr(el, HTML_ATTRIB_HREF);
        nf->href[0] = 0;
        if (h && *h) {
            int k = 0;
            for (; h[k] && k < HC_HREF_MAX - 1; k++) nf->href[k] = h[k];
            nf->href[k] = 0;
        }
        hc_put(ctx, '[');
        /* FIX [HC-A-NL]: запомнить позицию '[' — при закрытии проверим,
         * не разбило ли текст ссылки на строки (картинка/блочный child
         * внутри <a>). У такой "многострочной" ссылки разметку [..](..)
         * придётся снять: brp_analyze ищет '](' на ОДНОЙ строке, иначе
         * пользователь видел мусор "](https://...)" в тексте (Hacker
         * News: [\n![](y18.svg)\n](https://news.ycombinator.com)). */
        nf->a_open_mi = ctx->trunc ? -1 : ctx->mi - 1;
        return 1;
    }

    case HTML_TAG_IMG: {
        const char *src = hc_attr(el, HTML_ATTRIB_SRC);
        const char *alt;
        if (!src || !*src) return 0;          /* без src — пропуск */
        alt = hc_attr(el, HTML_ATTRIB_ALT);
        hc_brk(ctx);                          /* старый unguarded ENSURE_NL */
        hc_lb_reset(ctx);
        hc_lb_put(ctx, '!');
        hc_lb_put(ctx, '[');
        if (alt) {
            for (int k = 0; alt[k] && k < 48; k++) {
                if (alt[k] == ']' || alt[k] == '\n' || alt[k] == '\r') break;
                hc_lb_put(ctx, alt[k]);
            }
        }
        hc_lb_put(ctx, ']');
        hc_lb_put(ctx, '(');
        /* Task 67 [HC-ENC29]: ')' и '(' в URL пишутся как %29/%28 —
         * раньше .../Foo_(bar).png обрезался до .../Foo_ (обрыв на
         * первой скобке), картинка/ссылка вели не туда. Обе скобки:
         * иначе разборщик [T](U) в brpage.h находит ')' внутри URL. */
        for (const char *u = src; *u; u++) {
            if (*u == '\n' || *u == '\r' || *u == '"' || *u == '<')
                break;
            if (*u == ')')
                hc_lb_str(ctx, "%29");
            else if (*u == '(')
                hc_lb_str(ctx, "%28");
            else
                hc_lb_put(ctx, *u);
        }
        hc_lb_put(ctx, ')');
        hc_flush_line(ctx);
        return 0;
    }

    case HTML_TAG_INPUT: {
        /* FIX [HC-PH-JS]: маркер пишет ph=/js= — имена, которые реально
         * читает brf_attr (прежде писались placeholder=/onclick= и
         * молча терялись). */
        char ttype[16];
        hc_ensure_nl(ctx);
        if ((av = hc_attr(el, HTML_ATTRIB_TYPE)) && *av) {
            int k = 0;
            for (; av[k] && k < 15; k++)
                ttype[k] = (av[k] >= 'A' && av[k] <= 'Z')
                           ? (char)(av[k] | 0x20) : av[k];
            ttype[k] = 0;
        } else {
            strcpy(ttype, "text");
        }
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "INPUT type=\"");
        hc_lb_str(ctx, ttype);
        hc_lb_put(ctx, '"');
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_VALUE)) && *av) {
            hc_lb_str(ctx, " value=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ID)) && *av) {
            hc_lb_str(ctx, " id=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if (!strcmp(ttype, "text") || !strcmp(ttype, "password") ||
            !strcmp(ttype, "search") || !strcmp(ttype, "email") ||
            !strcmp(ttype, "url") || !strcmp(ttype, "number") ||
            !strcmp(ttype, "tel")) {
            /* Task 66: placeholder есть у всех текстоподобных типов */
            if ((av = hc_attr(el, HTML_ATTRIB_PLACEHOLDER)) && *av) {
                hc_lb_str(ctx, " ph=\""); hc_lb_attr(ctx, av);
                hc_lb_put(ctx, '"');
            }
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ONCLICK)) && *av) {
            hc_lb_str(ctx, " js=\""); hc_lb_attr_cap(ctx, av, HC_JS_MAX);
            hc_lb_put(ctx, '"');
        }
        if (hc_attr(el, HTML_ATTRIB_CHECKED))
            hc_lb_str(ctx, " checked");
        hc_flush_line(ctx);
        return 0;
    }

    case HTML_TAG_TEXTAREA: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "TEXTAREA");
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ID)) && *av) {
            hc_lb_str(ctx, " id=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        /* FIX [HC-PAIR]: резерв под закрывающий "\n\x01/TEXTAREA\n" */
        if (!hc_room(ctx, ctx->lb_len + 11 + 2)) {
            ctx->trunc = 1;
            return 1;              /* без маркера: текст пойдёт обычным */
        }
        ctx->ta_pos = ctx->mi;
        hc_flush_line(ctx);
        if (ctx->trunc) return 1;
        ctx->ta_open = 1;
        *kind = HC_K_TA;
        return 1;
    }

    case HTML_TAG_SELECT: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "SELECT");
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        hc_flush_line(ctx);
        return 1;
    }

    case HTML_TAG_OPTION: {
        const char *ov = hc_attr(el, HTML_ATTRIB_VALUE);
        nf->pend_attrs[0] = 0;
        if (ov && *ov) hc_pa_add(nf, "value", ov, 0);
        if (hc_attr(el, HTML_ATTRIB_SELECTED)) {
            int l = (int)strlen(nf->pend_attrs);
            if (l + 10 < (int)sizeof(nf->pend_attrs))
                strcpy(nf->pend_attrs + l, " selected");
        }
        nf->label[0] = 0;
        nf->label_len = 0;
        *kind = HC_K_OPT;
        return 1;
    }

    /* Task 66 [HC-OPT-NOVALUE]: <option>Label</option> без value раньше
     * терялся ЦЕЛИКОМ (close писал маркер только при непустых
     * pend_attrs). По HTML5 value по умолчанию — ТЕКСТ опции: brform.h
     * сам подставит label в значение, если value пуст. */
    case HTML_TAG_BUTTON: {
        nf->pend_attrs[0] = 0;
        if ((av = hc_attr(el, HTML_ATTRIB_TYPE)) && *av)
            hc_pa_add(nf, "type", av, 1);
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av)
            hc_pa_add(nf, "name", av, 0);
        if ((av = hc_attr(el, HTML_ATTRIB_VALUE)) && *av)
            hc_pa_add(nf, "value", av, 0);
        if ((av = hc_attr(el, HTML_ATTRIB_ONCLICK)) && *av)
            hc_pa_add(nf, "js", av, 0);
        nf->label[0] = 0;
        nf->label_len = 0;
        *kind = HC_K_BTN;
        return 1;
    }

    case HTML_TAG_FORM: {
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "FORM");
        if ((av = hc_attr(el, HTML_ATTRIB_ACTION)) && *av) {
            hc_lb_str(ctx, " action=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_METHOD)) && *av) {
            hc_lb_str(ctx, " method=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        hc_flush_line(ctx);
        return 1;
    }

    case HTML_TAG_META: {
        /* FIX [META-REFRESH]: только http-equiv=refresh */
        const char *he = hc_attr(el, HTML_ATTRIB_HTTP_EQUIV);
        const char *co = hc_attr(el, HTML_ATTRIB_CONTENT);
        if (he && co && *co && hc_ci_eq(he, "refresh")) {
            hc_ensure_nl(ctx);
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01" "REFRESH content=\"");
            hc_lb_attr(ctx, co);
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
        }
        return 0;
    }

    case HTML_TAG_SCRIPT: {
        const char *src = hc_attr(el, HTML_ATTRIB_SRC);
        if (src && *src) {
            /* внешний код: маркер-строка, поддерево пропускаем */
            hc_ensure_nl(ctx);
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01" "SCRIPTSRC src=\"");
            for (const char *u = src; *u; u++) {
                if (*u == '"' || *u == ' ' || *u == '\n' || *u == '\r' ||
                    *u == HC_MARK)
                    break;
                hc_lb_put(ctx, *u);
            }
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
            return -1;
        }
        /* инлайн: маркер + сырой код + закрытие. FIX [HC-PAIR]: резерв
         * под закрывающий "\n\x01/SCRIPT\n" ЗАРАНЕЕ — блок либо
         * открывается с гарантией закрытия, либо не открывается. */
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "SCRIPT");
        if (!hc_room(ctx, ctx->lb_len + 10 + 2)) {
            ctx->trunc = 1;
            return 1;              /* без маркера: остаток — обычный текст */
        }
        ctx->sc_pos = ctx->mi;
        hc_flush_line(ctx);
        if (ctx->trunc) return 1;
        ctx->sc_open = 1;
        *kind = HC_K_SCRIPT;
        return 1;
    }

    case HTML_TAG_BLOCKQUOTE:
        /* Task 67 [HC-BQ]: цитата — с префиксом "> ". Многострочные
         * цитаты префиксуют только первую строку (полная блок-цитата
         * требует перестройки уже выведенного текста — позже). */
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        hc_put_n(ctx, "> ", 2);
        return 1;

    case HTML_TAG_DT:
        /* Task 67 [HC-DL]: термин списка определений — **жирным** */
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        hc_put2(ctx, '*', '*');
        return 1;

    case HTML_TAG_DD:
        /* определение — с отступом */
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        hc_put2(ctx, ' ', ' ');
        return 1;

    case HTML_TAG_TABLE:
        /* Session 92 [HC-TBL2]: сбор в hc_tbl_t, рендер на закрытии.
         * Нет памяти — таблица идёт старым TSV-путём (кадры ниже). */
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        ctx->tbl = (hc_tbl_t *)malloc((u32)sizeof(hc_tbl_t));
        if (ctx->tbl) memset(ctx->tbl, 0, sizeof(hc_tbl_t));
        return 1;

    case HTML_TAG_TR:
        hc_ensure_nl(ctx);
        return 1;

    case HTML_TAG_TD:
    case HTML_TAG_TH:
        /* содержимое ячейки течёт обычным текстом; сепаратор — в close */
        return 1;

    case HTML_TAG_SUMMARY:
        /* Task 67 [HC-SUM]: заголовок раскрытия — как h3 */
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        hc_put_n(ctx, "### ", 4);
        return 1;

    case HTML_TAG_DETAILS:
    case HTML_TAG_FIGURE:
    case HTML_TAG_FIGCAPTION:
        hc_ensure_nl(ctx);
        hc_margin_indent(ctx, my_margin);        /* [HC-CSS] */
        return 1;

    default:
        /* нейтральные/неизвестные теги (html/head/div/span/table/title,
         * label, nav, ...) — разметку не выдаём, содержимое сохраняем */
        return 1;
    }
}

/* Закрытие элемента (кадр завершён) */
static void hc_close_frame(hc_ctx_t *ctx, hc_frame_t *fr)
{
    HtmlElement *el = fr->el;

    /* Session 93 [HC-CSS]: кадр со СВОИМ стилем — снять со стека
     * (SAX закрывает LIFO — sty_n совпадает; проверка — защита).
     * До transparent-выхода: slot у прозрачных кадров всё равно 0. */
    if (fr->sty_slot > 0 && fr->sty_slot <= ctx->sty_n) {
        ctx->sty_n = fr->sty_slot - 1;
        ctx->sty_dirty = 1;      /* следующий текст получит \x06/маркер */
    }

    /* Task 66 [HC-TRANSPARENT]: «прозрачный» кадр (спуск внутри pre/
     * script/textarea/option/button) открывался БЕЗ hc_open_tag — любые
     * закрывающие эффекты по tag здесь ЛОЖНЫЕ (лишний '`' от </code>
     * внутри <pre>, '**' от </b>, ']' от </a>...). */
    /* [HC-TBLA]: </a> в ячейке — закрыть разметку ссылки (кадр прозрачен,
     * но ТЕКСТ ячейки должен получить '](href)' сразу — между </a> и
     * </td> может идти ещё текст/другие ссылки). */
    if (ctx->tbl && el->tag == HTML_TAG_A && ctx->tbl->cur_a_open)
        hc_tbl_a_close(ctx);

    if (fr->transparent) return;

    switch (el->tag) {

    case HTML_TAG_A: {
        hc_put(ctx, ']');
        /* FIX [HC-A-NL]: многострочная ссылка (child-элемент с разрывом
         * строки — картинка, заголовок) — снимаем разметку: '[' и ']'
         * затираем пробелами, (href) НЕ пишем. Текст/картинки остаются
         * видимыми, мусор "](url)" в текст не попадает. */
        if (fr->a_open_mi >= 0 && fr->a_open_mi < ctx->mi) {
            int has_nl = 0;
            for (int q = fr->a_open_mi; q < ctx->mi; q++)
                if (ctx->md[q] == '\n') { has_nl = 1; break; }
            if (has_nl) {
                ctx->md[fr->a_open_mi] = ' ';
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] == ']')
                    ctx->md[ctx->mi - 1] = ' ';
                break;                /* (href) не пишем */
            }
        }
        if (fr->href[0]) {
            /* Task 67 [HC-ENC29]: ')' внутри URL пишется как %29 —
             * раньше href резался на ПЕРВОЙ ')': .../Foo_(bar) ->
             * .../Foo_ (пользователь попадал на неверную страницу).
             * Сначала считаем точную ёмкость (скобка расширяется x3). */
            int need = 2;
            for (const char *u = fr->href; *u; u++)
                need += (*u == ')' || *u == '(') ? 3 : 1;
            if (hc_room(ctx, need)) {
                hc_put(ctx, '(');
                for (const char *u = fr->href; *u; u++) {
                    if (*u == ')') hc_put_n(ctx, "%29", 3);
                    else if (*u == '(') hc_put_n(ctx, "%28", 3);
                    else hc_put(ctx, *u);
                }
                hc_put(ctx, ')');
            } else {
                ctx->trunc = 1;
            }
        } else if (hc_room(ctx, 2)) {
            hc_put(ctx, '(');
            hc_put(ctx, ')');
        } else {
            ctx->trunc = 1;
        }
        break;
    }

    case HTML_TAG_DT:
        /* Task 67 [HC-DL]: закрывающие '**' термина */
        hc_put2(ctx, '*', '*');
        break;

    case HTML_TAG_TD:
    case HTML_TAG_TH:
        /* Task 67 [HC-TBL]: конец ячейки — табулятор. Session 92: в
         * режиме сборки таблицы кадры прозрачны — сюда не доходим;
         * ветка жива для TSV-пути (нет памяти под коллектор). */
        hc_put(ctx, '\t');
        break;

    case HTML_TAG_DD:
        /* Task 67 [HC-DL]: блок завершается строкой (как P) */
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_TR:
        /* Task 67 [HC-TBL]: конец строки таблицы; хвостовой '\t' после
         * ПОСЛЕДНЕЙ ячейки убираем (иначе TSV с висячим сепаратором) */
        while (ctx->mi > 0 && ctx->md[ctx->mi - 1] == '\t')
            ctx->mi--;
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_TABLE:
        /* Session 92 [HC-TBL2]: коллектор жил — рендер псевдографики,
         * память долой. Иначе — прежний TSV (ensure_nl). */
        if (ctx->tbl) {
            if (ctx->tbl->cell_open) hc_tbl_cell_end(ctx);
            hc_tbl_row_break(ctx);
            hc_tbl_render(ctx, ctx->tbl);
            free(ctx->tbl);
            ctx->tbl = NULL;
            hc_ensure_nl(ctx);
            break;
        }
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_DETAILS:
    case HTML_TAG_FIGURE:
    case HTML_TAG_FIGCAPTION:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_SUMMARY:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
    case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6:
    case HTML_TAG_P:
    case HTML_TAG_LI:
    case HTML_TAG_UL:
    case HTML_TAG_OL:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_B:
    case HTML_TAG_STRONG:
        hc_put2(ctx, '*', '*');
        break;

    case HTML_TAG_I:
    case HTML_TAG_EM:
        hc_put(ctx, '*');
        break;

    case HTML_TAG_CODE:
        hc_put(ctx, '`');
        break;

    case HTML_TAG_PRE:
        ctx->pre_depth--;
        if (ctx->pre_depth == 0) {
            hc_ensure_nl_raw(ctx);
            hc_put_n(ctx, "```\n", 4);
        }
        break;

    case HTML_TAG_FORM:
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "/FORM");
        hc_flush_line(ctx);
        break;

    case HTML_TAG_SELECT:
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "/SELECT");
        hc_flush_line(ctx);
        break;

    case HTML_TAG_OPTION:
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "OPT");
        hc_lb_str(ctx, fr->pend_attrs);       /* может быть пусто — ок */
        hc_lb_str(ctx, " label=\"");
        for (int i = 0; i < fr->label_len; i++) {
            if (fr->label[i] == '"') hc_lb_str(ctx, "&quot;");
            else hc_lb_put(ctx, fr->label[i]);
        }
        hc_lb_put(ctx, '"');
        hc_flush_line(ctx);
        break;

    case HTML_TAG_BUTTON:
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "BUTTON");
        hc_lb_str(ctx, fr->pend_attrs);
        hc_lb_str(ctx, " label=\"");
        for (int i = 0; i < fr->label_len; i++) {
            if (fr->label[i] == '"') hc_lb_str(ctx, "&quot;");
            else hc_lb_put(ctx, fr->label[i]);
        }
        hc_lb_put(ctx, '"');
        hc_flush_line(ctx);
        break;

    case HTML_TAG_SCRIPT:
        /* FIX [HC-PAIR]: закрывашка влезла (резерв был) — пишем; при
         * обрыве посреди кода (trunc) закрывашку допишет finish либо
         * блок откатится целиком. */
        if (ctx->sc_open && !ctx->trunc) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 9;
            if (ctx->md_max - 1 - ctx->mi >= need) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/SCRIPT\n", 9);
                ctx->mi += 9;
                ctx->sc_open = 0;
            }
        }
        break;

    case HTML_TAG_TEXTAREA:
        if (ctx->ta_open && !ctx->trunc) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 11;
            if (ctx->md_max - 1 - ctx->mi >= need) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/TEXTAREA\n", 11);
                ctx->mi += 11;
                ctx->ta_open = 0;
            }
        }
        break;

    default:
        break;
    }
}

/* инициализация кадра (перед hc_open_tag, чтобы он мог заполнить
 * href/pend_attrs нового кадра) */
static void hc_frame_init(hc_frame_t *nf, HtmlElement *el, int kind)
{
    nf->el = el;
    nf->next = el->child;
    nf->kind = kind;
    nf->transparent = 0;
    nf->pre_first = 0;
    nf->li_count = 0;
    nf->href[0] = 0;
    nf->pend_attrs[0] = 0;
    nf->label[0] = 0;
    nf->label_len = 0;
    nf->sty_own = 0;              /* [HC-CSS] */
    nf->sty_slot = 0;
    nf->sty.rgb = 0;
    nf->sty.bold = 0;
    nf->sty.italic = 0;
    nf->a_open_mi = -1;           /* Session 95 [HC-FIX]: не-<a> кадры —
                                   * валидное значение по умолчанию */
}

/* ═══════════════════════════════════════════════════════
   Task 68 [HC-SAX]: событийная конвертация (без построения DOM)
   ═══════════════════════════════════════════════════════
   Парсер (html_parser.c, режим [HP-EVENT]) присылает open/text/close
   В ПОРЯДКЕ ДОКУМЕНТА; конвертер ведёт СВОЙ стек кадров — тот же, что
   был у обхода дерева (hc_frame_t), поэтому формат вывода не меняется
   вовсе. Элементы освобождаются парсером сразу после on_close —
   память пропорциональна ОТКРЫТЫМ элементам, а не всему документу. */

typedef struct {
    hc_ctx_t    ctx;
    hc_frame_t *frames;
    int         depth;
    int         skip_depth;   /* внутри поддерева с r==-1 (hidden/svg/...) */
} hc_sax_t;

static void hc_sax_open(void *ud, HtmlElement *el)
{
    hc_sax_t *s = (hc_sax_t *)ud;
    hc_ctx_t *ctx = &s->ctx;

    if (s->skip_depth) { s->skip_depth++; return; }
    if (ctx->trunc) { s->skip_depth++; return; }   /* структуру гасим */

    /* элемент внутри «сырого»/копящего контейнера: прозрачный спуск */
    int k = s->frames[s->depth].kind;
    if (k == HC_K_PRE || k == HC_K_SCRIPT || k == HC_K_TA ||
        k == HC_K_OPT || k == HC_K_BTN) {
        if (s->depth + 1 < HC_MAX_DEPTH) {
            hc_frame_init(&s->frames[s->depth + 1], el, k);
            s->frames[s->depth + 1].transparent = 1;   /* [HC-TRANSPARENT] */
            s->depth++;
        }
        return;
    }

    if (s->depth + 1 < HC_MAX_DEPTH) {
        int r;
        hc_frame_init(&s->frames[s->depth + 1], el, HC_K_PLAIN);
        r = hc_open_tag(ctx, s->frames, s->depth, el,
                        &s->frames[s->depth + 1],
                        &s->frames[s->depth + 1].kind);
        if (r == 1)
            s->depth++;            /* кадр остаётся: закроется на close */
        else if (r == -1)
            s->skip_depth = 1;     /* поддерево пропущено (эффекты выданы) */
        /* r == 0: лист — кадра нет, close(el) пройдёт мимо */
    } else {
        /* глубина исчерпана (не бывает: парсер ограничен 128) */
        int kind = HC_K_PLAIN;
        hc_frame_t tmp;
        memset(&tmp, 0, sizeof(tmp));
        /* hc_open_tag_impl (не обёртка): tmp никто не закроет — push
         * стиля в стек без pop накапливал бы мусор */
        (void)hc_open_tag_impl(ctx, s->frames, s->depth, el, &tmp, &kind);
    }
}

static void hc_sax_text(void *ud, const char *tx, int len)
{
    hc_sax_t *s = (hc_sax_t *)ud;
    hc_ctx_t *ctx = &s->ctx;

    if (s->skip_depth || ctx->trunc || !tx || len <= 0) return;

    hc_frame_t *fr = &s->frames[s->depth];
    /* Session 92 [HC-TBL2]: пробелы между ячейками/строками в таблице
     * не рисуются (в md попадали одиночные « » до/после рамки) */
    if (ctx->tbl && !ctx->tbl->fallback && !ctx->tbl->cell_open &&
        fr->kind == HC_K_PLAIN)
        return;
    switch (fr->kind) {
    case HC_K_PRE:
        if (fr->pre_first) {
            fr->pre_first = 0;
            if (tx[0] == '\n') { tx++; len--; }   /* HTML5: первый \n
                                                   * после <pre> игнорируется */
        }
        hc_text_raw(ctx, tx, len);
        break;
    case HC_K_SCRIPT:
    case HC_K_TA:
        hc_text_raw(ctx, tx, len);
        break;
    case HC_K_OPT:
    case HC_K_BTN:
        hc_label_add(fr, tx, len);
        break;
    default:
        hc_text_norm(ctx, tx, len);
        break;
    }
}

static void hc_sax_close(void *ud, HtmlElement *el)
{
    hc_sax_t *s = (hc_sax_t *)ud;

    if (s->skip_depth) { s->skip_depth--; return; }

    /* снять кадры до элемента (неявные закрытия приходят СОБЫТИЯМИ по
     * одному, так что совпадение — обычно верхний кадр; цикл — защита) */
    while (s->depth > 0 && s->frames[s->depth].el != el) {
        hc_close_frame(&s->ctx, &s->frames[s->depth]);
        s->depth--;
    }
    if (s->depth > 0 && s->frames[s->depth].el == el) {
        hc_close_frame(&s->ctx, &s->frames[s->depth]);
        s->depth--;
    }
}

static const HtmlParseEvents hc_events = {
    NULL, hc_sax_open, hc_sax_text, hc_sax_close
};

/* ═══════════════════════════════════════════════════════
   Task 68 [HC-STREAM]: потоковая конвертация
   ═══════════════════════════════════════════════════════
   Браузер кормит куски сети, не накапливая весь HTML: конвертация
   идёт синхронно с приёмом, память О(текущий md + открытые элементы).
   Буфер md принадлежит ВЫЗЫВАТЕЛЮ и расширяется его же grow-хуком
   (в ядре нет realloc — malloc+копия+free). */

struct hc_stream {
    hc_sax_t        sax;
    HtmlParseState *st;
    HtmlElement     root_el;      /* фиктивный корень для frames[0] (LI-
                                   * уровню нужен валидный el у КАЖДОГО
                                   * кадра ниже depth) */
    int (*grow_cb)(void *ud, char **md, int *max, int want);
    void           *grow_ud;
    int             finished;
    /* Session 92 [HC-ENC]: кодировка входа этого потока (NULL = UTF-8).
     * На каждый экземпляр — глобаль не гонится между окнами. */
    const hc_utf8_row_t *charset;
    /* Session 93 [BR-LAZY]: суммарные байты, ушедшие парсеру (все feed) */
    int             st_in;
};

/* grow-хук для hc_room: расширение делает колбэк вызывателя — он
 * перевыделяет СВОЙ буфер и обновляет *md и *max (указатели ctx); в ядре
 * realloc нет — malloc+копия+free внутри колбэка браузера. */
static int hc_stream_grow(void *ud, char **md, int *max, int want)
{
    hc_stream_t *hs = (hc_stream_t *)ud;
    if (!hs->grow_cb) return 0;
    /* колбэк обязан обновить *md (новый буфер) и *max (новая ёмкость) */
    return hs->grow_cb(hs->grow_ud, md, max, want);
}

hc_stream_t *hc_stream_begin(char *md, int md_max, int hard_max,
                             int (*grow_cb)(void *ud, char **md, int *max,
                                            int want),
                             void *grow_ud)
{
    if (!md || md_max < 4) return NULL;

    /* calloc в ядре нет — malloc + обнуление (поле за полем не нужно:
     * SAX/ctx заполняются ниже, но обнулим всё сразу для безопасности) */
    hc_stream_t *hs = (hc_stream_t *)malloc((u32)sizeof(hc_stream_t));
    if (!hs) return NULL;
    memset(hs, 0, sizeof(hc_stream_t));

    hs->grow_cb = grow_cb;
    hs->grow_ud = grow_ud;

    hs->sax.frames = (hc_frame_t *)malloc((u32)sizeof(hc_frame_t)
                                          * (u32)HC_MAX_DEPTH);
    if (!hs->sax.frames) { free(hs); return NULL; }

    memset(&hs->root_el, 0, sizeof(hs->root_el));
    hs->root_el.tag = HTML_TAG_UNKNOWN;      /* как корень DOM-режима */
    hs->root_el.display = DISPLAY_BLOCK;
    hc_frame_init(&hs->sax.frames[0], &hs->root_el, HC_K_PLAIN);

    memset(&hs->sax.ctx, 0, sizeof(hs->sax.ctx));
    hs->sax.ctx.md = md;
    hs->sax.ctx.md_max = md_max;
    hs->sax.ctx.grow = grow_cb ? hc_stream_grow : NULL;
    hs->sax.ctx.grow_ud = hs;
    hs->sax.ctx.hard_max = grow_cb ? hard_max : 0;
    md[0] = 0;

    hs->st = html_parse_begin();
    if (!hs->st) { free(hs->sax.frames); free(hs); return NULL; }
    html_parse_set_events(hs->st, &hc_events, &hs->sax);
    return hs;
}

void hc_stream_set_charset(hc_stream_t *hs, const char *name)
{
    if (!hs) return;
    /* применяется к ПОСЛЕДУЮЩИМ feed: вызыватель обязан выставить
     * кодировку до первой подачи тела (см. htmlconv.h) */
    hs->charset = hc_charset_by_name(name);
}

/* Session 93 [BR-LAZY]: сколько байт входа уже ушло парсеру (все feed
 * суммарно, включая перекодированные). Браузер по этому значению
 * решает, когда перейти в режим спула хвоста. */
int hc_stream_input_done(hc_stream_t *hs)
{
    if (!hs || !hs->st) return 0;
    return (int)hs->st_in;
}

/* Session 93 [BR-LAZY]: текущая длина md БЕЗ завершения разбора
 * (между feed и finish). Пишет NUL в md[mi] для безопасности вызывателя. */
int hc_stream_md_len(hc_stream_t *hs)
{
    if (!hs) return 0;
    hc_ctx_t *ctx = &hs->sax.ctx;
    if (ctx->mi < ctx->md_max)
        ctx->md[ctx->mi] = 0;
    return ctx->mi;
}

void hc_stream_feed(hc_stream_t *hs, const char *data, int len)
{
    if (!hs || hs->finished || !data || len <= 0) return;
    if (hs->charset) {
        /* Session 92 [HC-ENC]: перекодировка куска в UTF-8 до парсера.
         * Куски ≤ 1200 байт: расширение до 3 байт/символ ≤ 3600 < буфер. */
        char conv[4096];
        int off = 0;
        while (off < len) {
            int chunk = len - off;
            if (chunk > 1200) chunk = 1200;
            int n = hc_recode_chunk(hs->charset, data + off, chunk,
                                    conv, (int)sizeof(conv));
            if (n > 0) {
                hs->st_in += n;         /* [BR-LAZY]: счётчик входа */
                html_parse_stream(hs->st, NULL, conv, (size_t)n);
            }
            off += chunk;
        }
        return;
    }
    hs->st_in += len;                   /* [BR-LAZY]: счётчик входа */
    html_parse_stream(hs->st, NULL, data, (size_t)len);
}

int hc_stream_finish(hc_stream_t *hs, int *truncated)
{
    if (!hs) return 0;
    hc_ctx_t *ctx = &hs->sax.ctx;

    if (!hs->finished) {
        hs->finished = 1;
        html_parse_end(hs->st);       /* хвост/закрытия; state освобождён */
        hs->st = NULL;

        /* Session 93 [HC-CSS]: если стиль был открыт, но документ
         * кончился раньше сброса (нет текста после </span>) — дописать
         * закрывающий \x06, чтобы маркеры были парными в сыром md */
        if (ctx->sty_emit_valid && !ctx->trunc && hc_room(ctx, 1)) {
            ctx->md[ctx->mi++] = '\x06';
            ctx->sty_emit_valid = 0;
        }

        /* FIX [HC-PAIR]: блоки, оборванные исчерпанием буфера посреди
         * кода: закрывашка дописывается, при нехватке места ВЕСЬ блок
         * (включая открывашку) откатывается — «висячий» маркер
         * невозможен. (Как в прежнем html_to_md2.) */
        if (ctx->sc_open) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 9;
            if (hc_room(ctx, need)) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/SCRIPT\n", 9);
                ctx->mi += 9;
            } else {
                ctx->mi = ctx->sc_pos;
            }
        }
        if (ctx->ta_open) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 11;
            if (hc_room(ctx, need)) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/TEXTAREA\n", 11);
                ctx->mi += 11;
            } else {
                ctx->mi = ctx->ta_pos;
            }
        }
        if (ctx->mi < ctx->md_max)
            ctx->md[ctx->mi] = 0;
        else if (ctx->md_max > 0)
            ctx->md[ctx->md_max - 1] = 0;
        if (ctx->trunc && truncated) *truncated = 1;
    }
    return ctx->mi;
}

void hc_stream_abort(hc_stream_t *hs)
{
    if (!hs) return;
    /* оборвать парсер, НЕ трогая буфер вызывателя (он освободит сам) */
    if (hs->st) { html_parse_end(hs->st); hs->st = NULL; }
    free(hs->sax.frames);
    free(hs);
}

/* освободить состояние конвертера ПОСЛЕ finish (буфер вызывателя — не
 * здесь). finish сам не освобождает: браузер читает md_len из возврата. */
void hc_stream_free(hc_stream_t *hs)
{
    if (!hs) return;
    if (hs->st) { html_parse_end(hs->st); hs->st = NULL; }
    free(hs->sax.frames);
    free(hs);
}

int html_to_md2(const char *html, int html_len, char *md, int md_max,
                int *truncated)
{
    if (truncated) *truncated = 0;
    if (!md || md_max < 4) {
        if (md && md_max > 0) md[0] = 0;
        return 0;
    }
    md[0] = 0;
    if (!html || html_len <= 0) return 0;

    /* Task 68: прежний обход DOM заменён событийной конвертацией —
     * вход тот же, формат вывода тот же, памяти меньше (без дерева). */
    hc_stream_t *hs = hc_stream_begin(md, md_max, 0, NULL, NULL);
    if (!hs) return 0;
    /* Session 92 [HC-ENC]: кодировка, выставленная htmlconv_set_charset
     * ПЕРЕД вызовом (глобаль «одноразовая» — после вызова сбрасывается,
     * чтобы не протекать в соседние окна/потоки). Если явной установки
     * не было — снифф meta-charset в первых 2 КиБ (браузер сниффит
     * потоковый путь отдельно; здесь — curl/файлы/буферный путь). */
    hs->charset = g_hc_charset;
    g_hc_charset = NULL;
    if (!hs->charset) {
        char cs[24];
        int scan = html_len < 2048 ? html_len : 2048;
        if (hc_sniff_charset(html, scan, cs, (int)sizeof(cs)))
            hs->charset = hc_charset_by_name(cs);  /* utf-8/неизвестная -> NULL */
    }
    hc_stream_feed(hs, html, html_len);
    int md_len = hc_stream_finish(hs, truncated);
    hc_stream_free(hs);
    return md_len;
}

int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    return html_to_md2(html, html_len, md, md_max, NULL);
}

