/* fake_server_stub.c — заглушка модели сервера для харнесов, которым
 * она не нужна (loop_client): fake_nic.c зовёт её на каждый TX. */
#include "types.h"
void fake_server_on_tx(const u8 *frame, u32 len) { (void)frame; (void)len; }

/* [RX-CSUM] (сессия 98): зависимости, появившиеся в net.c/net_tcp.c/
 * net_http.c после последнего обновления харнеса. */
void klog_puts(const char *s) { (void)s; }
int gz_inflate_gzip(const unsigned char *in, unsigned in_len,
                    unsigned char *out, unsigned out_cap, unsigned *out_len)
{ (void)in; (void)in_len; (void)out; (void)out_cap; (void)out_len; return -1; }
int gz_inflate_gzip_partial(const unsigned char *in, unsigned in_len,
                            unsigned char *out, unsigned out_cap, unsigned *out_len)
{ (void)in; (void)in_len; (void)out; (void)out_cap; (void)out_len; return -1; }
int ramfs_delete(const char *name) { (void)name; return -1; }
