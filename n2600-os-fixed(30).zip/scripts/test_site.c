/* test_site.c — прогон РЕАЛЬНОГО HTML (скачанного с сайта) через полный
 * конвейер браузера n2600-os: html_to_md → brf_parse → brf_scrub →
 * brp_analyze → brl_wrap. Печатает то, что увидит пользователь.
 * Использование: ./test_site file.html [width] [maxlines] */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
typedef uint8_t u8;
typedef uint32_t u32;

#include "../src/htmlconv.h"
#include "../src/html_parser.h"

/* локальная копия utf8_next (как в test_wiki_page.c) */
static unsigned t_utf8_next(const char **ps)
{
    const unsigned char *p = (const unsigned char *)*ps;
    if (*p == 0) { return 0; }
    int n = 1;
    if      ((*p & 0xE0) == 0xC0) n = 2;
    else if ((*p & 0xF0) == 0xE0) n = 3;
    else if ((*p & 0xF8) == 0xF0) n = 4;
    while (n > 1 && *p) { p++; n--; }
    *ps = (const char *)p;
    return 1;
}
#define utf8_next t_utf8_next

#include "../src/utf8.h"
#include "../src/brpage.h"
#include "../src/brlines.h"
#include "../src/brform.h"

int main(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "usage: %s file.html [width] [maxlines]\n", argv[0]); return 1; }
    int cw = argc > 2 ? atoi(argv[2]) : 78;
    int maxl = argc > 3 ? atoi(argv[3]) : 60;

    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open"); return 1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *html = malloc(sz + 1);
    if (fread(html, 1, sz, f) != (size_t)sz) { perror("read"); return 1; }
    fclose(f);
    html[sz] = 0;
    printf("=== input: %s, %ld bytes ===\n", argv[1], sz);

    int cap = 6u * 1024u * 1024u;
    char *md = malloc(cap);
    int n = html_to_md(html, (int)sz, md, cap);
    printf("=== html_to_md -> %d bytes ===\n", n);

    brf_forms_t forms;
    memset(&forms, 0, sizeof(forms));
    n = brf_parse(&forms, md, n);
    printf("=== brf_parse: fields=%d scripts=%d ===\n", forms.nfields, forms.nscripts);
    n = brf_scrub(md, n);

    brp_page_t pg;
    memset(&pg, 0, sizeof(pg));
    int md_len = brp_analyze(&pg, md, n);
    printf("=== brp_analyze: md_len=%d links=%d imgs=%d ===\n",
           md_len, pg.nlinks, pg.nimgs);

    brl_list_t L;
    memset(&L, 0, sizeof(L));
    brl_wrap(md, md_len, cw, &L);
    printf("=== brl_wrap: %d lines (cw=%d) — RENDERED VIEW ===\n", L.nlines, cw);
    for (int i = 0; i < L.nlines && i < maxl; i++)
        printf("%3d|%s\n", i, L.lines[i]);
    if (L.nlines > maxl) printf("... (%d more lines)\n", L.nlines - maxl);
    return 0;
}
