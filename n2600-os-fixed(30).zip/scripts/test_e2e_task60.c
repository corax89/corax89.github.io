/* test_e2e_task60.c — E2E: html_to_md2 -> brf_parse (как в браузере при
 * загрузке страницы). Проверяем: скрипты собраны, в md не осталось
 * \x01-маркеров, rescue редиректора работает, brf_scrub чистит вставки.
 *
 * gcc -DHOST_TEST -fsanitize=address,undefined -g test_e2e_task60.c \
 *     ../src/html_parser.c -o test_e2e
 */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include "../src/htmlconv.c"
#include "../src/brform.h"
extern unsigned utf8_next(const char **ps);  /* src/string.h */
#include "../src/brpage.h"
#include "../src/brlines.h"
#undef HOST_TEST

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails = 0, total = 0;

static void ok(const char *name, int cond)
{
    total++;
    if (cond) printf("PASS %s\n", name);
    else { fails++; printf("FAIL %s\n", name); }
}

int main(void)
{
    /* --- E2E: сложная страница: 12 скриптов + редиректор 13-м --- */
    {
        char doc[16384];
        int o = 0;
        char md[16384];
        brf_forms_t forms;
        int ml;
        o += snprintf(doc + o, sizeof(doc) - o, "<h1>Page</h1>");
        for (int i = 0; i < 12; i++)
            o += snprintf(doc + o, sizeof(doc) - o,
                          "<p>sec %d</p><script>var a%d = %d;"
                          " analytics(%d);</script>", i, i, i, i);
        o += snprintf(doc + o, sizeof(doc) - o,
                      "<script>location.href = \"/next.html\";</script>"
                      "<p>tail</p>");
        ml = html_to_md2(doc, o, md, (int)sizeof(md), NULL);
        memset(&forms, 0, sizeof(forms));
        ml = brf_parse(&forms, md, ml);
        ok("E2E: all 13 scripts collected", forms.nscripts == 13);
        ok("E2E: no \\x01 markers left in md", strchr(md, '\x01') == NULL);
        ok("E2E: tail content preserved", strstr(md, "tail") != NULL);
        /* 13-й — редиректор: старый код с BRJ_MAX=10 терял его */
        ok("E2E: redirector rescued (last script)",
           forms.scripts[forms.nscripts - 1].code &&
           strstr(forms.scripts[forms.nscripts - 1].code,
                  "location.href") != NULL);
        brf_reset(&forms);
    }

    /* --- E2E: перегруз кода: 10 скриптов по ~7 КиБ + редиректор --- */
    {
        char *doc = (char *)malloc(131072);
        char *md = (char *)malloc(262144);
        brf_forms_t forms;
        int o = 0, ml;
        o += snprintf(doc + o, 1024, "<p>big</p>");
        for (int i = 0; i < 10; i++) {
            o += snprintf(doc + o, 128, "<script>/* pad%d */", i);
            for (int k = 0; k < 7000; k++)
                doc[o++] = (char)('a' + (k % 26));
            o += snprintf(doc + o, 32, ";\n</script>");
        }
        o += snprintf(doc + o, 256,
                      "<script>location.replace(\"/go\");</script><p>end</p>");
        ml = html_to_md2(doc, o, md, 262144, NULL);
        memset(&forms, 0, sizeof(forms));
        ml = brf_parse(&forms, md, ml);
        ok("E2E-big: budget overflow, redirector rescued",
           brf_is_redirect(forms.scripts[0].code, forms.scripts[0].code_len));
        ok("E2E-big: script count still bounded", forms.nscripts <= BRJ_MAX);
        ok("E2E-big: no markers leaked", strchr(md, '\x01') == NULL);
        ok("E2E-big: end content kept", strstr(md, "end") != NULL);
        brf_reset(&forms);
        free(doc);
        free(md);
    }

    /* --- E2E: document.write-канал: конвертация вставки с <script> ---
     * (имитация br_docwrite_emit: convert -> brf_parse(tmp) ->
     *  strip anchors -> scrub) */
    {
        const char *whtml =
            "<b>inserted</b><script>location.href=\"/r\";</script>"
            "<input type=\"text\" name=\"q\">";
        char wmd[4096];
        brf_forms_t tmp;
        int wl;
        wl = html_to_md2(whtml, (int)strlen(whtml), wmd,
                         (int)sizeof(wmd), NULL);
        memset(&tmp, 0, sizeof(tmp));
        wl = brf_parse(&tmp, wmd, wl);
        wl = brf_strip_script_anchors(wmd, wl);
        ok("DW: script extracted from insertion",
           tmp.nscripts == 1 && strstr(tmp.scripts[0].code, "location.href"));
        ok("DW: field extracted from insertion", tmp.nfields == 1);
        ok("DW: no \\x04 anchors in spliced md", strchr(wmd, '\x04') == NULL);
        ok("DW: no \\x01 markers in spliced md", strchr(wmd, '\x01') == NULL);
        ok("DW: visible content kept",
           strstr(wmd, "inserted") != NULL);
        {
            brf_forms_t main_f;
            memset(&main_f, 0, sizeof(main_f));
            brf_adopt(&main_f, &tmp);
            ok("DW: adopt field", main_f.nfields == 1 &&
               !strcmp(main_f.fields[0].name, "q"));
        }
        brf_reset(&tmp);
    }

    /* --- brf_scrub: вставка с обрывом посреди SCRIPT --- */
    {
        char dirtied[512];
        int dl;
        strcpy(dirtied, "text before\n\x01SCRIPT\nvar half =\nmore text\n");
        dl = (int)strlen(dirtied);
        dl = brf_scrub(dirtied, dl);
        ok("SCRUB: dangling SCRIPT block swallowed",
           strchr(dirtied, '\x01') == NULL &&
           strstr(dirtied, "text before") != NULL &&
           strstr(dirtied, "var half") == NULL);
        /* --- scrub не трогает якоря --- */
        strcpy(dirtied, "a\n\x03\nb\n\x04\nc\n\x01INPUT type=\"text\"\nd\n");
        dl = (int)strlen(dirtied);
        dl = brf_scrub(dirtied, dl);
        ok("SCRUB: anchors \\x03/\\x04 kept",
           strchr(dirtied, '\x03') && strchr(dirtied, '\x04') &&
           strchr(dirtied, '\x01') == NULL);
    }

    /* --- E2E [S100-DOCWRITE]: «скрипт переписывает страницу» ---
     * Полная имитация br_page_scripts_run + br_docwrite_emit +
     * br_page_refresh (сессия 100): страница со СКРИПТОМ-ПЕРЕПИСЫВАТЕЛЕМ
     * (document.write формы и ссылки) и ПОСЛЕДУЮЩИМ отложенным скриптом —
     * после splice/adopt/reindex его src_line обязан указывать на свою
     * строку, повторный refresh не должен терять/дублировать поля,
     * а ссылка из вставки — кликабельна (brp_analyze). */
    {
        const char *page =
            "<h1>Site</h1>"
            "<p>intro text</p>"
            "<script>document.write('<form action=\"/go\">"
            "<input type=\"text\" name=\"q\" value=\"\">"
            "<input type=\"submit\" value=\"Go\"></form>"
            "<p>see <a href=\"/next\">the next page</a></p>');</script>"
            "<p>after content</p>"
            "<script>tracker(42);</script>";
        char md[8192];
        char wmd[4096];
        brp_page_t pg;
        brl_list_t L;
        brf_forms_t main_f, tmp;
        int ml = html_to_md2(page, (int)strlen(page), md,
                             (int)sizeof(md), NULL);
        memset(&main_f, 0, sizeof(main_f));
        ml = brf_parse(&main_f, md, ml);
        ok("S100: два скрипта собраны", main_f.nscripts == 2);
        ok("S100: маркеры форм уже якорями \\x03", strchr(md, '\x01') == NULL);

        /* скрипт 0 — критичный (document.write): исполняется сейчас.
         * Его вывод: код document.write('...') — вырезаем аргумент. */
        const char *code = main_f.scripts[0].code;
        const char *q1 = strchr(code, '\'');
        const char *q2 = q1 ? strchr(q1 + 1, '\'') : NULL;
        ok("S100: аргумент document.write найден", q1 && q2 && q2 > q1);
        if (q1 && q2) {
            /* 1) конвертация вставки (как br_docwrite_emit) */
            int wl = html_to_md2(q1 + 1, (int)(q2 - q1 - 1), wmd,
                                 (int)sizeof(wmd), NULL);
            ok("S100: вставка конвертирована", wl > 0);
            /* 2) временная модель вставки (скриптов/форм внутри нет) */
            memset(&tmp, 0, sizeof(tmp));
            wl = brf_parse(&tmp, wmd, wl);
            /* 3) якоря tmp-скриптов долой + чистка маркеров */
            wl = brf_strip_script_anchors(wmd, wl);
            wl = brf_scrub(wmd, wl);
            /* 4) splice ПЕРЕД строкой якоря \x04 (якорь сохраняется —
             *    [S100-DOCWRITE], тот же фикс, что в br_splice_at_line) */
            {
                int src_line = main_f.scripts[0].src_line;
                int pos = 0, line = 0;
                while (line < src_line && pos < ml) {
                    while (pos < ml && md[pos] != '\n') pos++;
                    if (pos >= ml) break;
                    pos++; line++;
                }
                int keep_len = ml - pos;
                char nb[8192];
                int no = 0;
                memcpy(nb, md, (size_t)pos); no = pos;
                memcpy(nb + no, wmd, (size_t)wl); no += wl;
                memcpy(nb + no, md + pos, (size_t)keep_len); no += keep_len;
                nb[no] = 0;
                memcpy(md, nb, (size_t)no + 1);
                ml = no;
            }
            /* 5) усыновление + реиндекс (как br_docwrite_emit) */
            brf_adopt(&main_f, &tmp);
            brf_reindex(&main_f, md, ml);
            brf_reset(&tmp);

            ok("S100: поле из вставки усыновлено",
               main_f.nfields == 2 && !strcmp(main_f.fields[0].name, "q"));
            ok("S100: \\x03-якоря вставки в md",
               strchr(md, '\x03') != NULL);
            ok("S100: вставленный текст в md",
               strstr(md, "the next page") != NULL);
            /* отложенный скрипт (tracker) должен смотреть на СВОЮ строку:
             * до вставки он был последней строкой; после — сместился */
            ok("S100: src_line отложенного реиндексирован",
               main_f.scripts[1].src_line > main_f.scripts[0].src_line &&
               main_f.scripts[1].src_line <
                   main_f.scripts[1].src_line + 100000);
            {
                /* строка src_line скрипта 1 действительно содержит его
                 * якорь \x04 (иначе document.write отложенного ушёл бы
                 * не туда — тот самый класс «ломает страницы») */
                int pos = 0;
                for (int i = 0; i < main_f.scripts[1].src_line; i++) {
                    while (pos < ml && md[pos] != '\n') pos++;
                    pos++;
                }
                ok("S100: якорь \\x04 отложенного на своей строке",
                   pos < ml && md[pos] == BRJ_MARK);
            }
            ok("S100: \\x01-маркеров нет после чистки",
               strchr(md, '\x01') == NULL);
        }

        /* 6) br_page_refresh: scrub + reindex + brp_analyze + brl_wrap */
        ml = brf_scrub(md, ml);
        brf_reindex(&main_f, md, ml);
        memset(&pg, 0, sizeof(pg));
        ml = brp_analyze(&pg, md, ml);
        memset(&L, 0, sizeof(L));
        brl_wrap(md, ml, 60, &L);
        ok("S100: ссылка из вставки собрана brp_analyze",
           pg.nlinks == 1 && !strcmp(pg.links[0].url, "/next"));
        ok("S100: строки отображения содержат вставку",
           L.nlines > 4);
        int saw_field_anchor = 0;
        for (int i = 0; i < L.nlines; i++)
            if (L.lines[i][0] == BRF_MARK && L.lines[i][1] == 0)
                saw_field_anchor = 1;
        ok("S100: якорь поля дошёл до строк отображения", saw_field_anchor);
        brl_free(&L);
        brp_free_images(&pg);
        if (pg.line_off) free(pg.line_off);
        brf_reset(&main_f);
    }

    printf("=== E2E %d/%d passed, %d failed ===\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
