#!/bin/sh
# run.sh — хост-тест URL-логики браузера (Task 61) на РЕАЛЬНЫХ
# src/brurl.h + src/imgsvc.c + src/brform.h (ASan/UBSan):
#   [BR-REDIR2] [BR-2SLASH] [BR-NOSLASH] [BR-URL1SLASH] [BR-QREL]
#   [BR-PCT] [BR-REFRESHQ]
# [IMG-WEBP]: imgsvc теперь тянет simplewebp (декодер WebP) — собираем
# его отдельной единицей трансляции теми же флагами.
# Детали — test_brurl.c. Запуск: sh scripts/brhost/run.sh
set -e
cd "$(dirname "$0")"
cp ../../src/imgsvc.c ../../src/imgsvc.h ../../src/types.h \
   ../../src/stb_image.h ../../src/simplewebp.c ../../src/simplewebp.h \
   ../../src/assert.h .
gcc -DHOST_TEST -g -O1 -fsanitize=address,undefined -Ishim -I. -I../../src \
    -o test_brurl test_brurl.c imgsvc.c simplewebp.c
./test_brurl
