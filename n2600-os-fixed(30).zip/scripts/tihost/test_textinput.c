/* test_textinput.c — хост-тест ЯДРА виджета ввода (textinput.h,
 * Task 64 [TI-WIDGET]) на реальном src/textinput.h.
 *
 * Проверяется UTF-8-логика: русский ввод серией байтов (как от kbd),
 * курсор в СИМВОЛАХ, Backspace/Delete по ЦЕЛОМУ символу, вставка в
 * середину кириллицы, лимиты (символы/байты), Ctrl+V (paste_fn),
 * окно видимости, коды возврата. Запуск: sh scripts/tihost/run.sh
 */
#include <stdio.h>
#include <string.h>
#include "textinput.h"

static int g_pass = 0, g_fail = 0;
#define CHECK(name, cond) do { \
    if (cond) { g_pass++; printf("  [PASS] %s\n", name); } \
    else      { g_fail++; printf("  [FAIL] %s  (%s:%d)\n", name, __FILE__, __LINE__); } \
} while (0)

static const char *RU_PRIVET = "\xD0\xBF\xD1\x80\xD0\xB8\xD0\xB2\xD0\xB5\xD1\x82"; /* привет: 6 симв/12 байт */

/* «напечатать ASCII-строку» */
static void type_ascii(ti_t *ti, const char *s)
{
    key_event_t ev;
    for (const char *p = s; *p; p++) {
        memset(&ev, 0, sizeof(ev));
        ev.code = 0x00; ev.ch = *p;
        ti_key(ti, &ev);
    }
}

/* «нажать клавишу» с юникод-кодом: имитация push_utf8 из kbd.c —
 * серия событий по ОДНОМУ байту (кириллица = 2 события) */
static void type_cp(ti_t *ti, unsigned cp)
{
    key_event_t ev;
    char b[4];
    int n = 0;
    if (cp < 0x80) b[n++] = (char)cp;
    else if (cp < 0x800) {
        b[n++] = (char)(0xC0 | (cp >> 6));
        b[n++] = (char)(0x80 | (cp & 0x3F));
    } else {
        b[n++] = (char)(0xE0 | (cp >> 12));
        b[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
        b[n++] = (char)(0x80 | (cp & 0x3F));
    }
    for (int i = 0; i < n; i++) {
        memset(&ev, 0, sizeof(ev));
        ev.code = 0x10; ev.ch = b[i];
        ti_key(ti, &ev);
    }
}

static int press(ti_t *ti, u8 code, char ch, u8 flags)
{
    key_event_t ev;
    memset(&ev, 0, sizeof(ev));
    ev.code = code; ev.ch = ch; ev.flags = flags;
    return ti_key(ti, &ev);
}

static const char *g_clip;
static const char *fake_clip(void) { return g_clip; }

int main(void)
{
    char buf[64], buf2[64], buf3[48], tiny[8];
    ti_t ti;
    printf("== host-тест виджета ввода текста (Task 64 [TI-WIDGET]) ==\n");

    /* ---------- 1. Русский ввод серией байтов ---------- */
    printf("-- русский ввод --\n");
    ti_init(&ti, buf, sizeof(buf));
    {
        unsigned word[6] = {0x043F,0x0440,0x0438,0x0432,0x0435,0x0442}; /* привет */
        for (int i = 0; i < 6; i++) type_cp(&ti, word[i]);
    }
    CHECK("введено 6 символов", ti_chars(&ti) == 6);
    CHECK("введено 12 байт", ti_len(&ti) == 12);
    CHECK("строка = привет", strcmp(ti_text(&ti), RU_PRIVET) == 0);
    CHECK("курсор в конце (12 байт)", ti.cur == 12);
    CHECK("курсор = 6-й символ", ti_cur_char(&ti) == 6);

    /* ---------- 2. Backspace/Delete по ЦЕЛОМУ символу ---------- */
    printf("-- backspace/delete --\n");
    press(&ti, 0x0E, '\b', 0);
    CHECK("после BS 5 символов", ti_chars(&ti) == 5);
    CHECK("после BS 10 байт", ti_len(&ti) == 10);
    CHECK("хвост = приве (битого UTF-8 нет)",
          (unsigned char)buf[9] == 0xB5 && buf[10] == 0);
    ti_reset(&ti, "");
    press(&ti, 0x0E, '\b', 0);
    CHECK("BS в пустой — ок", ti_len(&ti) == 0);

    ti_reset(&ti, RU_PRIVET);           /* привет */
    ti_home(&ti);
    ti_move(&ti, +1);                   /* курсор после «п» */
    press(&ti, 0x53, 0, 0);             /* Delete: убрать «р» */
    CHECK("Delete в середине: 5 символов", ti_chars(&ti) == 5);
    CHECK("Delete: строка = пивет",
          ti_len(&ti) == 10 &&
          memcmp(buf, "\xD0\xBF\xD0\xB8\xD0\xB2\xD0\xB5\xD1\x82", 10) == 0);

    /* ---------- 3. Курсор по символам, вставка в середину ---------- */
    printf("-- курсор/вставка в середину --\n");
    ti_reset(&ti, RU_PRIVET);
    ti_home(&ti);
    ti_move(&ti, +1); ti_move(&ti, +1); /* после «пр»: 2 симв = 4 байта */
    CHECK("курсор: 2 симв = 4 байта", ti.cur == 4);
    type_cp(&ti, 'X');
    CHECK("вставка X: 7 символов", ti_chars(&ti) == 7);
    CHECK("строка = прXивет", ti_len(&ti) == 13 && buf[4] == 'X');
    ti_move(&ti, -1);
    CHECK("влево: курсор на 4 байта (не на полсимвола)", ti.cur == 4);
    press(&ti, 0x47, 0, 0);
    CHECK("Home: курсор 0", ti.cur == 0);
    press(&ti, 0x4F, 0, 0);
    CHECK("End: курсор 13", ti.cur == 13);

    for (int i = 0; i < 10; i++) press(&ti, KBD_LEFT, 0, 0);
    CHECK("влево до упора — курсор 0", ti.cur == 0);
    press(&ti, KBD_RIGHT, 0, 0);
    ti_home(&ti);
    press(&ti, KBD_LEFT, 0, 0);
    CHECK("Home+влево — 0", ti.cur == 0);

    /* ---------- 4. Лимиты ---------- */
    printf("-- лимиты --\n");
    ti_init(&ti, buf2, sizeof(buf2));     /* cap 63 */
    ti.max_chars = 5;
    for (int i = 0; i < 8; i++) type_cp(&ti, 'a' + i);
    CHECK("max_chars: 5 символов", ti_chars(&ti) == 5);
    CHECK("max_chars: 5 байт", ti_len(&ti) == 5);
    CHECK("rejected выставлен", ti.rejected == 1);

    ti_reset(&ti, "");
    ti.rejected = 0;
    for (int i = 0; i < 7; i++) type_cp(&ti, 0x0430);   /* 7 «а» */
    CHECK("кириллица: 5 симв = 10 байт",
          ti_chars(&ti) == 5 && ti_len(&ti) == 10);
    CHECK("rejected (6-я буква не поместилась)", ti.rejected == 1);

    /* чисто байтовый предел: cap 8 → room 7 байт */
    ti_init(&ti, tiny, sizeof(tiny));
    ti.max_chars = 0;
    for (int i = 0; i < 6; i++) type_cp(&ti, 0x0430);
    CHECK("байтовый cap: 3 симв/6 байт",
          ti_chars(&ti) == 3 && ti_len(&ti) == 6);
    type_cp(&ti, 'z');
    CHECK("последний ASCII влез (7 байт)", ti_len(&ti) == 7);
    type_cp(&ti, 'y');
    CHECK("дальше — rejected, без перезаписи",
          ti.rejected == 1 && ti_len(&ti) == 7);

    /* ---------- 5. Ctrl+V (paste_fn) ---------- */
    printf("-- вставка из буфера --\n");
    ti_init(&ti, buf2, sizeof(buf2));
    ti.paste_fn = fake_clip;
    g_clip = "ab\xD0\xB0\xD0\xB1\x01\x02" "cd";    /* abаб<ctl><ctl>cd */
    press(&ti, 0x2F, 'v', KF_CTRL);
    CHECK("paste: 8 байт (управляющие отброшены)", ti_len(&ti) == 8);
    CHECK("paste: 6 символов", ti_chars(&ti) == 6);
    CHECK("paste: строка abабcd",
          memcmp(buf2, "ab\xD0\xB0\xD0\xB1" "cd", 8) == 0);
    ti_home(&ti);
    ti_move(&ti, +1);
    g_clip = "Z";
    press(&ti, 0x2F, 'v', KF_CTRL);
    CHECK("paste в середину: aZb...",
          memcmp(buf2, "aZb\xD0\xB0", 4) == 0);
    ti.paste_fn = 0;
    g_clip = 0;

    /* ---------- 6. Окно видимости ---------- */
    printf("-- окно видимости --\n");
    ti_init(&ti, buf3, sizeof(buf3));
    for (int i = 0; i < 12; i++) type_cp(&ti, 0x0430);  /* 12 «а» = 24 байта */
    CHECK("End-состояние: окно хвоста (off 14 = 7 симв)",
          ti_view_off(&ti, 5) == 14);
    ti_home(&ti);
    CHECK("Home: окно к началу", ti_view_off(&ti, 5) == 0);
    ti_end(&ti);
    CHECK("End: окно снова хвост", ti_view_off(&ti, 5) == 14);
    /* курсор на 9-м символе — окно [7..12) его уже показывает:
     * лишней прокрутки нет (off остаётся 14) */
    ti_move(&ti, -1); ti_move(&ti, -1); ti_move(&ti, -1);  /* 9 симв */
    CHECK("курсор в окне — окно не дёргается (off 14)",
          ti_view_off(&ti, 5) == 14);
    ti_move(&ti, -1); ti_move(&ti, -1); ti_move(&ti, -1); ti_move(&ti, -1);
    /* 5-й символ (байт 10): вне окна [7..) */
    CHECK("курсор вышел влево — окно сдвинулось (off 10 = 5 симв)",
          ti_view_off(&ti, 5) == 10);

    /* ---------- 7. Коды возврата ---------- */
    printf("-- коды возврата --\n");
    ti_reset(&ti, "x");
    CHECK("Enter -> TI_K_ENTER", press(&ti, 0x1C, '\n', 0) == TI_K_ENTER);
    CHECK("Esc -> TI_K_ESC", press(&ti, 0x01, 0x1B, 0) == TI_K_ESC);
    CHECK("Ctrl+C -> IGNORE", press(&ti, 0x2E, 'c', KF_CTRL) == TI_K_IGNORE);
    CHECK("Tab -> IGNORE", press(&ti, 0x0F, '\t', 0) == TI_K_IGNORE);
    CHECK("release -> IGNORE", press(&ti, 0x10, 'q', KF_RELEASED) == TI_K_IGNORE);
    CHECK("Enter/Esc текст не меняют", ti_len(&ti) == 1);

    /* ---------- 8. ti_snap после внешних правок ---------- */
    printf("-- ti_snap --\n");
    ti_reset(&ti, RU_PRIVET);
    ti.cur = 5;
    ti_snap(&ti);
    CHECK("snap: 5 -> 4 (граница символа)", ti.cur == 4);
    ti.cur = 99;
    ti_snap(&ti);
    CHECK("snap: 99 -> len", ti.cur == ti.len);

    /* ---------- 9. Смешанный текст (имя файла с кириллицей) ---------- */
    printf("-- смешанный текст --\n");
    ti_reset(&ti, "");
    type_ascii(&ti, "file");
    type_cp(&ti, 0x0430);                 /* + «а» */
    type_ascii(&ti, ".txt");
    CHECK("fileа.txt: 9 символов", ti_chars(&ti) == 9);
    CHECK("fileа.txt: 10 байт", ti_len(&ti) == 10);
    ti_home(&ti);
    ti_move(&ti, +1); ti_move(&ti, +1); ti_move(&ti, +1); ti_move(&ti, +1);
    ti_backspace(&ti);                    /* убрать 'e' */
    CHECK("после BS: fil+а.txt (9 байт)",
          memcmp(buf3, "fil", 3) == 0 && ti_len(&ti) == 9);
    press(&ti, 0x47, 0, 0);
    press(&ti, 0x4F, 0, 0);
    ti_backspace(&ti);                    /* последний символ 't' */
    CHECK("BS в конце убрал целый 't'",
          ti_len(&ti) == 8 && buf3[8] == 0 && buf3[7] == 'x');

    /* ---------- 10. [TI-SEL] (сессия 100): выделение текста ---------- */
    printf("-- [TI-SEL] выделение (Shift+стрелки, Ctrl+A/C/X, замена) --\n");
    static char clipbuf[64];
    static int  clipn;
    void sel_copy(const char *s, int n) {
        if (n > 0 && n < (int)sizeof(clipbuf)) {
            memcpy(clipbuf, s, (size_t)n);
            clipbuf[n] = 0;
            clipn = n;
        } else { clipn = 0; }
    }
    ti_reset(&ti, "abcdef");
    ti_home(&ti);                             /* курсор в начало: есть куда расширять */
    CHECK("сначала выделения нет", !ti_sel_active(&ti));
    press(&ti, KBD_RIGHT, 0, KF_SHIFT);      /* Shift+Right */
    press(&ti, KBD_RIGHT, 0, KF_SHIFT);
    press(&ti, KBD_RIGHT, 0, KF_SHIFT);
    CHECK("Shift+Right x3: выделение активно", ti_sel_active(&ti));
    {
        int a, b;
        ti_sel_range(&ti, &a, &b);
        CHECK("диапазон [0,3)", a == 0 && b == 3);
    }
    clipn = 0;
    ti.copy_fn = sel_copy;
    CHECK("Ctrl+C съеден", press(&ti, 0x2E, 'c', KF_CTRL) == TI_K_EATEN);
    CHECK("скопировано 'abc'", clipn == 3 && memcmp(clipbuf, "abc", 3) == 0);
    CHECK("копия не меняет текст", ti_len(&ti) == 6);
    type_ascii(&ti, "XY");                    /* печатаем ПОВЕРХ выделения */
    CHECK("ввод заменил выделение: XYdef", ti_len(&ti) == 5 &&
          memcmp(ti.buf, "XYdef", 6) == 0);
    CHECK("после ввода выделение снято", !ti_sel_active(&ti));
    /* Ctrl+A -> весь текст; Ctrl+X — вырезать */
    CHECK("Ctrl+A съеден", press(&ti, 0x1E, 'a', KF_CTRL) == TI_K_EATEN);
    clipn = 0;
    CHECK("Ctrl+X съеден", press(&ti, 0x2D, 'x', KF_CTRL) == TI_K_EATEN);
    CHECK("вырезано 'XYdef'", clipn == 5 && memcmp(clipbuf, "XYdef", 6) == 0);
    CHECK("после вырезки поле пусто", ti_len(&ti) == 0);
    /* Backspace/Delete с выделением удаляют выделение */
    ti_reset(&ti, RU_PRIVET);                 /* 6 симв/12 байт */
    press(&ti, 0x47, 0, KF_SHIFT);            /* Shift+Home: всё до начала */
    CHECK("Shift+Home: выделение всего", ti_sel_active(&ti));
    ti_backspace(&ti);
    CHECK("BS с выделением очистил поле", ti_len(&ti) == 0);
    /* обычные стрелки СКЛАДЫВАЮТ выделение на соответствующий край */
    ti_reset(&ti, "hello");
    press(&ti, 0x47, 0, KF_SHIFT);            /* Shift+Home */
    press(&ti, KBD_RIGHT, 0, 0);              /* обычный Right */
    CHECK("Right сложил выделение на правый край", !ti_sel_active(&ti) &&
          ti.cur == 5);
    press(&ti, KBD_LEFT, 0, KF_SHIFT);
    press(&ti, KBD_LEFT, 0, KF_SHIFT);
    {
        int a, b;
        ti_sel_range(&ti, &a, &b);
        CHECK("Shift+Left x2: [3,5)", a == 3 && b == 5);
    }
    press(&ti, KBD_LEFT, 0, 0);               /* обычный Left */
    CHECK("Left сложил на левый край (cur=3)", !ti_sel_active(&ti) &&
          ti.cur == 3);
    /* Ctrl+V заменяет выделение (paste_fn) */
    ti_reset(&ti, "one two");
    press(&ti, 0x47, 0, KF_SHIFT);            /* Shift+Home -> [0,7) */
    g_clip = "ONE";
    ti.paste_fn = fake_clip;
    press(&ti, 0x2F, 'v', KF_CTRL);
    CHECK("Ctrl+V заменил выделение: ONE", ti_len(&ti) == 3 &&
          memcmp(ti.buf, "ONE", 3) == 0);
    /* ti_sel_px: пересечение выделения с видимым окном */
    ti_reset(&ti, "0123456789");
    ti.sel_a = 2; ti.sel_b = 6;
    {
        int d0 = -1, d1 = -1;
        CHECK("sel_px: окно [0,5) -> [16,40)", ti_sel_px(&ti, 0, 5, &d0, &d1) &&
              d0 == 16 && d1 == 40);
        d0 = d1 = -1;
        CHECK("sel_px: окно [6,4) мимо", !ti_sel_px(&ti, 6, 4, &d0, &d1));
        d0 = d1 = -1;
        CHECK("sel_px: окно [4,10) -> [0,16)", ti_sel_px(&ti, 4, 10, &d0, &d1) &&
              d0 == 0 && d1 == 16);
    }
    ti.copy_fn = 0;                           /* не мешать секциям выше */

    printf("\n== ИТОГО: PASS=%d FAIL=%d ==\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
