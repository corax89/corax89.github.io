/* textinput.h — переиспользуемый ОДНОСТРОЧНЫЙ виджет ввода текста
 * N2600-OS (Task 64 [TI-WIDGET]). Header-only ЯДРО (без отрисовки —
 * она в textinput.c), самодостаточно: работает в ядре и в хост-тестах.
 *
 * ЗАЧЕМ. Клавиатура шлёт кириллицу СЕРИЕЙ UTF-8-байтов (2 байта на
 * букву), а самодельные поля ввода в терминале/диалогах/браузере
 * считали БАЙТЫ: курсор уезжал на два символа, Backspace стирал
 * ПОЛБУКВЫ (битый UTF-8), русский ввод в диалоги вообще не проходил
 * (фильтр 0x20..0x7F). Каждый чинил по-своему. Теперь ОДИН виджет:
 *
 *   - буфер ВНЕШНИЙ (embedder даёт char[] — виджет НЕ аллоцирует);
 *   - курсор в БАЙТАХ, всегда на границе символа (utf8_align_back);
 *   - перемещение/удаление — по СИМВОЛАМ (не байтам);
 *   - вставка в произвольную позицию (не только append);
 *   - лимит в СИМВОЛАХ (max_chars) и/или ёмкость буфера (cap байт);
 *   - Ctrl+V — вставка из буфера обмена через paste_fn (embedder
 *     подставляет clip_text_get; в хост-тестах — свой);
 *   - режим password (отрисовка '*' — в textinput.c).
 *
 * ПРАВИЛО ДЛЯ ВСТРОЯТЕЛЕЙ (терминал, диалоги, браузер, скриптовые
 * окна): рисует embedder (ti_draw_box/ti_draw_inline из textinput.c
 * или своими примитивами), клавиши — ti_key, текст — ti_text.
 *
 * C API (виджет): ti_init/ti_reset/ti_key/ti_text/ti_chars/
 *   ti_cur_char/ti_insert_bytes/ti_backspace/ti_delete/ti_move/
 *   ti_home/ti_end/ti_view_off/ti_draw_box/ti_draw_inline.
 *
 * JS API (скриптовые окна, mquickjs_api.c): ti_add(win,x,y,w,maxlen)
 *   — поле в окне скрипта; ti_get(win) — строка; ti_set(win,s) —
 *   записать; ti_entered(win) — 1, если в поле нажали Enter.
 *   (Один виджет на окно; фокус — клик по полю, Enter отдаётся
 *   скрипту через флаг.)
 */
#ifndef TEXTINPUT_H
#define TEXTINPUT_H

#include "types.h"
#include "kbd.h"
#include "utf8.h"

/* Ширина символа виджета в пикселях (шрифт ОС моноширинный 8x16).
 * Нужна и ядру (ti_sel_px ниже), и отрисовке (textinput.c). */
#define TI_CHAR_W 8

/* Отрисовка (textinput.c — только ядро; в хост-тестах не линкуется). */
struct ti_s;
void ti_draw_box(struct ti_s *ti, int x, int y, int w, int h, int focused);
int  ti_draw_inline(struct ti_s *ti, int x, int y, int max_px, u32 fg);

#ifdef __cplusplus
extern "C" {
#endif

/* ---- результаты ti_key (что сделал виджет) ---- */
#define TI_K_IGNORE  0   /* клавиша не для виджета — решает embedder */
#define TI_K_EATEN   1   /* обработана (вставка/курсор/удаление) */
#define TI_K_ENTER   2   /* Enter (текст не тронут) */
#define TI_K_ESC     3   /* Esc (embedder: снять фокус/закрыть диалог) */

/* Виджет: НЕ владеет буфером, только указатель. Копируйте структуру
 * осторожно (buf остаётся общим) — лучше держать ti_t в одном месте. */
typedef struct ti_s {
    char *buf;               /* внешний буфер, NUL-терминирован */
    int   cap;               /* ёмкость буфера В БАЙТАХ (вкл. место под '\0') */
    int   len;               /* занято байт (без '\0') */
    int   cur;               /* курсор, БАЙТЫ, всегда на границе символа */
    int   max_chars;         /* лимит СИМВОЛОВ (0 = без лимита, кроме cap) */
    int   password;          /* 1 = рисовать '*' вместо символов */
    int   multiline;         /* 1 = Enter вставляет '\n' (textarea),
                              * а не отдаётся embedder'у как TI_K_ENTER */
    int   rejected;          /* 1 = последний ввод НЕ поместился (embedder
                              * показывает «Слишком длинное имя»); сброс —
                              * любая успешная вставка/удаление */
    int   view_off;          /* байтовое смещение первого видимого символа
                              * (считает ti_view_off, использует отрисовка) */
    /* Ctrl+V: откуда брать буфер обмена (NULL = вставка выключена).
     * Возвращает NUL-терминированный текст или NULL. */
    const char *(*paste_fn)(void);
    /* [TI-SEL] Ctrl+C/Ctrl+X: куда класть ВЫДЕЛЕННЫЙ текст (NULL = копия
     * выделения виджетом выключена; embedder может обработать сам).
     * Обрезку по cap делает вызывающий — виджет передаёт точный диапазон. */
    void (*copy_fn)(const char *s, int n);
    /* [TI-SEL] выделение, БАЙТЫ: sel_a — якорь (не двигается при
     * Shift+стрелках), sel_b — второй конец (следует за курсором).
     * Активно, только если sel_a >= 0 && sel_a != sel_b. */
    int   sel_a;
    int   sel_b;
} ti_t;

/* Привязать внешний буфер (cap — полная ёмкость, включая '\0'). */
static inline void ti_init(ti_t *ti, char *buf, int cap)
{
    ti->buf = buf;
    ti->cap = cap > 0 ? cap : 1;
    ti->len = 0;
    ti->cur = 0;
    ti->max_chars = 0;
    ti->password = 0;
    ti->multiline = 0;
    ti->rejected = 0;
    ti->view_off = 0;
    ti->paste_fn = (const char *(*)(void))0;
    ti->copy_fn = (void (*)(const char *, int))0;
    ti->sel_a = -1;
    ti->sel_b = -1;
    buf[0] = 0;
}

/* Заменить текст целиком (курсор в конец). */
static inline void ti_reset(ti_t *ti, const char *text)
{
    int i = 0;
    if (text)
        while (text[i] && i < ti->cap - 1) { ti->buf[i] = text[i]; i++; }
    ti->buf[i] = 0;
    ti->len = i;
    ti->cur = i;
    ti->rejected = 0;
    ti->view_off = 0;
    ti->sel_a = -1;
    ti->sel_b = -1;
}

/* ───── [TI-SEL] выделение текста (Shift+стрелки, Ctrl+A/C/X, мышь) ─────
 * Запрос сессии 100: «нельзя скопировать часть адресной строки — она
 * не выделяется». Ядро хранит диапазон в БАЙТАХ (границы символов);
 * встраиватели ставят sel_a/sel_b из мыши, клавиши — ti_key. */
static inline void ti_sel_clear(ti_t *ti)
{
    ti->sel_a = -1;
    ti->sel_b = -1;
}

static inline int ti_sel_active(const ti_t *ti)
{
    return ti->sel_a >= 0 && ti->sel_a != ti->sel_b;
}

/* Нормализованный диапазон [a, b): 1 = есть выделение. */
static inline int ti_sel_range(const ti_t *ti, int *a, int *b)
{
    if (!ti_sel_active(ti)) return 0;
    int x = ti->sel_a, y = ti->sel_b;
    if (x > y) { int t = x; x = y; y = t; }
    if (x < 0) x = 0;
    if (y > ti->len) y = ti->len;
    if (y <= x) return 0;
    if (a) *a = x;
    if (b) *b = y;
    return 1;
}

/* Удалить выделенный текст (курсор — в начало диапазона).
 * Возвращает число удалённых байт. */
static inline int ti_sel_delete(ti_t *ti)
{
    int a, b;
    if (!ti_sel_range(ti, &a, &b)) { ti_sel_clear(ti); return 0; }
    int cut = b - a;
    for (int k = a; k <= ti->len - cut; k++)
        ti->buf[k] = ti->buf[k + cut];
    ti->len -= cut;
    ti->cur = a;
    ti_sel_clear(ti);
    ti->buf[ti->len] = 0;
    return cut;
}

/* Выделить весь текст (курсор — в конец). */
static inline void ti_sel_all(ti_t *ti)
{
    if (ti->len <= 0) { ti_sel_clear(ti); return; }
    ti->sel_a = 0;
    ti->sel_b = ti->len;
    ti->cur = ti->len;
}

/* Плашка выделения для КАСТОМНОЙ отрисовки встраивателя (адресная
 * строка браузера, поля форм — те рисуют текст сами, мимо
 * ti_draw_box/ti_draw_inline). view_from — байтовое начало видимого
 * окна, view_chars — его ширина в СИМВОЛАХ. Возвращает 1 и пишет
 * d0/d1 — пиксельные смещения ПЕРЕСЕЧЕНИЯ выделения с окном
 * относительно начала текста (умножать на px не надо, уже *8). */
static inline int ti_sel_px(const ti_t *ti, int view_from, int view_chars,
                            int *d0, int *d1)
{
    int a, b;
    if (view_chars <= 0 || !ti_sel_range(ti, &a, &b)) return 0;
    if (b <= view_from) return 0;
    int fromc = utf8_count_chars(ti->buf, view_from);
    int endc  = fromc + view_chars;
    int ac = utf8_count_chars(ti->buf, a);
    int bc = utf8_count_chars(ti->buf, b);
    if (ac < fromc) ac = fromc;
    if (bc > endc)  bc = endc;
    if (bc <= ac) return 0;
    if (d0) *d0 = (ac - fromc) * TI_CHAR_W;
    if (d1) *d1 = (bc - fromc) * TI_CHAR_W;
    return 1;
}

static inline const char *ti_text(const ti_t *ti) { return ti->buf; }
static inline int         ti_len(const ti_t *ti)  { return ti->len; }

/* Число СИМВОЛОВ во всём тексте (кириллица = 1, не 2). */
static inline int ti_chars(const ti_t *ti)
{
    return utf8_count_chars(ti->buf, ti->len);
}

/* Позиция курсора в СИМВОЛАХ от начала строки (для пиксельных карт). */
static inline int ti_cur_char(const ti_t *ti)
{
    return utf8_count_chars(ti->buf, ti->cur);
}

/* Убедиться, что cur — на границе символа (после внешних правок buf). */
static inline void ti_snap(ti_t *ti)
{
    if (ti->cur < 0) ti->cur = 0;
    if (ti->cur > ti->len) ti->cur = ti->len;
    ti->cur = utf8_align_back(ti->buf, ti->cur);
}

/* Вставить n байт (UTF-8-строка s) В ПОЗИЦИЮ КУРСОРА. Контроль:
 *  - не превысить cap (обрезка — по границе символа);
 *  - не превысить max_chars СИМВОЛОВ;
 *  - управляющие байты (<0x20 и 0x7F) пропускаются.
 * Возвращает число ВСТАВЛЕННЫХ байт (0 = не поместилось; rejected=1). */
static inline int ti_insert_bytes(ti_t *ti, const char *s, int n)
{
    /* [TI-SEL]: печатаемый ввод/вставка ЗАМЕНЯЮТ выделение (как везде) */
    if (ti_sel_active(ti))
        ti_sel_delete(ti);
    int room = ti->cap - 1 - ti->len;
    /* запас по СИМВОЛАМ до max_chars (вставка идёт в курсор — до него) */
    int lim_chars = ti->max_chars > 0
                        ? ti->max_chars - utf8_count_chars(ti->buf, ti->cur)
                        : 0;
    int inserted = 0, i = 0;
    ti->rejected = 0;
    while (i < n && s[i]) {
        unsigned char c = (unsigned char)s[i];
        int need = utf8_seq_len(c);       /* место под ЦЕЛЫЙ символ */
        int adv = need;
        if (n > 1 && adv > n - i) break;  /* paste: не рвать символ на хвосте */
        if (n == 1) adv = 1;              /* событие kbd — ОДИН байт (серия
                                           * событий склеится в символ) */
        if ((c < 0x20 && !(c == '\n' && ti->multiline)) || c == 0x7F)
            { i++; continue; }               /* управляющие ('\n' в
                                              * multiline — исключение) */
        /* Продолжающий байт (0x80..0xBF) валиден ТОЛЬКО если завершает
         * начатую перед курсором последовательность (иначе — «сирота»:
         * его lead был отвергнут капом/лимитом — не портить UTF-8). */
        if ((c & 0xC0) == 0x80) {
            int back = 0;          /* cont-байтов между lead'ом и курсором */
            int seq = 0;           /* длина seq lead'а (0 = lead'а нет) */
            while (back < 3 && ti->cur - 1 - back >= 0) {
                unsigned char pb =
                    (unsigned char)ti->buf[ti->cur - 1 - back];
                if ((pb & 0xC0) == 0x80) { back++; continue; }
                if      ((pb & 0xE0) == 0xE0) seq = 3;   /* lead 3-байтной */
                else if ((pb & 0xC0) == 0xC0) seq = 2;   /* lead 2-байтной */
                break;                                   /* ASCII/мусор: 0 */
            }
            if (seq < 2 || back >= seq - 1) {
                ti->rejected = 1;        /* ввод не принят целиком */
                i++;
                continue;
            }
        }
        /* не влезает по байтам (проверка под целый символ: иначе у края
         * оставался бы «повисший» lead-байт — битый UTF-8) */
        if (need > room) { ti->rejected = 1; break; }
        if (ti->max_chars > 0 && lim_chars <= 0) { ti->rejected = 1; break; }
        /* сдвинуть хвост вправо на adv (включая '\0') */
        for (int k = ti->len; k >= ti->cur; k--)
            ti->buf[k + adv] = ti->buf[k];
        for (int k = 0; k < adv; k++)
            ti->buf[ti->cur + k] = s[i + k];
        ti->cur += adv;
        ti->len += adv;
        room -= adv;
        lim_chars--;
        inserted += adv;
        i += adv;
    }
    ti->buf[ti->len] = 0;
    return inserted;
}

/* Удобство: вставить один ASCII-символ. */
static inline int ti_insert_char(ti_t *ti, char ch)
{
    return ti_insert_bytes(ti, &ch, 1);
}

/* Backspace: удалить СИМВОЛ ПЕРЕД курсором (целый UTF-8). */
static inline int ti_backspace(ti_t *ti)
{
    ti->rejected = 0;
    /* [TI-SEL]: с выделением Backspace удаляет ВЫДЕЛЕНИЕ */
    if (ti_sel_active(ti)) { ti_sel_delete(ti); return 1; }
    if (ti->cur <= 0) return 0;
    int start = utf8_align_back(ti->buf, ti->cur - 1);
    int cut = ti->cur - start;
    for (int k = start; k <= ti->len - cut; k++)
        ti->buf[k] = ti->buf[k + cut];
    ti->len -= cut;
    ti->cur = start;
    return 1;
}

/* Delete: удалить СИМВОЛ НА курсоре. */
static inline int ti_delete(ti_t *ti)
{
    ti->rejected = 0;
    /* [TI-SEL]: с выделением Delete удаляет ВЫДЕЛЕНИЕ */
    if (ti_sel_active(ti)) { ti_sel_delete(ti); return 1; }
    if (ti->cur >= ti->len) return 0;
    int adv = utf8_seq_len((unsigned char)ti->buf[ti->cur]);
    if (ti->cur + adv > ti->len) adv = ti->len - ti->cur;
    for (int k = ti->cur; k <= ti->len - adv; k++)
        ti->buf[k] = ti->buf[k + adv];
    ti->len -= adv;
    return 1;
}

/* Курсор влево/вправо НА СИМВОЛ (dir < 0 — влево). */
static inline int ti_move(ti_t *ti, int dir)
{
    if (dir < 0) {
        if (ti->cur <= 0) return 0;
        ti->cur = utf8_align_back(ti->buf, ti->cur - 1);
    } else {
        if (ti->cur >= ti->len) return 0;
        ti->cur += utf8_seq_len((unsigned char)ti->buf[ti->cur]);
        if (ti->cur > ti->len) ti->cur = ti->len;
    }
    return 1;
}

static inline void ti_home(ti_t *ti) { ti->cur = 0; }
static inline void ti_end(ti_t *ti)  { ti->cur = ti->len; }

/* Окно видимости: сместить view_off так, чтобы курсор был виден при
 * ширине avail_chars СИМВОЛОВ (возвращает view_off, байты). */
static inline int ti_view_off(ti_t *ti, int avail_chars)
{
    if (avail_chars < 1) avail_chars = 1;
    int total = utf8_count_chars(ti->buf, ti->len);
    int curc = utf8_count_chars(ti->buf, ti->cur);
    if (total <= avail_chars) { ti->view_off = 0; return 0; }
    /* окно [view_char, view_char+avail); держим курсор внутри */
    int view_char = utf8_count_chars(ti->buf, ti->view_off);
    if (curc < view_char) view_char = curc;
    if (curc >= view_char + avail_chars) view_char = curc - avail_chars + 1;
    if (view_char > total - avail_chars) view_char = total - avail_chars;
    if (view_char < 0) view_char = 0;
    ti->view_off = utf8_take_bytes(ti->buf, ti->len, view_char);
    return ti->view_off;
}

/* ГЛАВНЫЙ ВХОД: обработать клавишу. Возвращает TI_K_*.
 * Обрабатывает: печатные ASCII + UTF-8-байты (>=0x80; серия событий
 * от kbd склеивается в символ сама), Backspace/Delete, стрелки,
 * Home/End, Ctrl+V (через paste_fn). Enter/Esc — КОДЫ embedder'у. */
static inline int ti_key(ti_t *ti, const key_event_t *ev)
{
    if (ev->flags & KF_RELEASED) return TI_K_IGNORE;

    if (ev->code == 0x1C || ev->ch == '\n' || ev->ch == '\r') {
        if (ti->multiline && ev->ch != '\r') {
            char nl = '\n';
            ti_insert_bytes(ti, &nl, 1);   /* исключение из фильтра <0x20 */
            return TI_K_EATEN;
        }
        return TI_K_ENTER;
    }
    if (ev->ch == 0x1B || ev->code == 0x01)
        return TI_K_ESC;

    if (ev->code == 0x0E || ev->ch == '\b') {           /* Backspace */
        ti_backspace(ti);
        return TI_K_EATEN;
    }
    if (ev->code == 0x53) {                             /* Delete */
        ti_delete(ti);
        return TI_K_EATEN;
    }
    /* [TI-SEL]: стрелки и Home/End. С Shift — РАСШИРЯЮТ выделение
     * (якорь sel_a стоит, sel_b следует за курсором); без Shift —
     * СКЛАДЫВАЮТ выделение (курсор на соответствующий край). */
    if (ev->code == KBD_LEFT || ev->code == KBD_RIGHT) {
        int dir = (ev->code == KBD_LEFT) ? -1 : 1;
        if (ev->flags & KF_SHIFT) {
            if (!ti_sel_active(ti)) {
                ti->sel_a = ti->cur;
                ti->sel_b = ti->cur;
            }
            ti_move(ti, dir);
            ti->sel_b = ti->cur;
        } else if (ti_sel_active(ti)) {
            int a, b;
            ti_sel_range(ti, &a, &b);
            ti->cur = (dir < 0) ? a : b;
            ti_sel_clear(ti);
        } else {
            ti_move(ti, dir);
        }
        return TI_K_EATEN;
    }
    if (ev->code == 0x47 || ev->code == 0x4F) {          /* Home / End */
        int home = (ev->code == 0x47);
        if (ev->flags & KF_SHIFT) {
            if (!ti_sel_active(ti)) ti->sel_a = ti->cur;
            ti->cur = home ? 0 : ti->len;
            ti->sel_b = ti->cur;
        } else if (ti_sel_active(ti)) {
            int a, b;
            ti_sel_range(ti, &a, &b);
            ti->cur = home ? a : b;
            ti_sel_clear(ti);
        } else if (home) {
            ti_home(ti);
        } else {
            ti_end(ti);
        }
        return TI_K_EATEN;
    }

    /* Ctrl+V — вставка из буфера обмена (если embedder дал paste_fn).
     * [TI-SEL]: вставка ЗАМЕНЯЕТ выделение (ti_insert_bytes сам удалит). */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'v' || ev->ch == 'V' || ev->code == 0x2F)) {
        if (ti->paste_fn) {
            const char *t = ti->paste_fn();
            if (t && t[0]) {
                int n = 0;
                while (t[n]) n++;
                ti_insert_bytes(ti, t, n);
            }
        }
        return TI_K_EATEN;
    }

    /* [TI-SEL]: Ctrl+A — выделить всё; Ctrl+C — копировать выделения;
     * Ctrl+X — вырезать. Без выделения Ctrl+C — TI_K_IGNORE: встраиватель
     * (браузер) решает сам — обычно копирует весь текст поля. */
    if (ev->flags & KF_CTRL) {
        if (ev->ch == 'a' || ev->ch == 'A' || ev->code == 0x1E) {
            ti_sel_all(ti);
            return TI_K_EATEN;
        }
        int want_cut = (ev->ch == 'x' || ev->ch == 'X' || ev->code == 0x2D);
        int want_cpy = (ev->ch == 'c' || ev->ch == 'C' || ev->code == 0x2E);
        if ((want_cut || want_cpy) && ti->copy_fn) {
            int a, b;
            if (ti_sel_range(ti, &a, &b)) {
                ti->copy_fn(ti->buf + a, b - a);
                if (want_cut) ti_sel_delete(ti);
                return TI_K_EATEN;
            }
            if (want_cut) return TI_K_EATEN;   /* резать нечего — но съедаем */
        }
    }

    /* Прочие ctrl-комбинации — НЕ для виджета */
    if (ev->flags & KF_CTRL) return TI_K_IGNORE;

    if ((ev->ch >= 0x20 && ev->ch < 0x7F) || (unsigned char)ev->ch >= 0x80) {
        ti_insert_bytes(ti, &ev->ch, 1);
        return TI_K_EATEN;
    }
    return TI_K_IGNORE;
}

#ifdef __cplusplus
}
#endif

/* ---- Контекстное меню поля ввода (сессия 97 [TI-CLIPMENU]) ----
 * Запрос: «добавь контекстное меню для копирования текста, а также его
 * вставки в поле ввода (для всех полей ввода, не только браузера)».
 *
 * ОДИН переиспользуемый пункт для ЛЮБОГО окна с ti-виджетом
 * (браузер — адресная строка и поля форм, терминал, диалоги файлов,
 * ввод-диалоги, скриптовые окна). Открытие — из on_mouse потока окна
 * по ПРАВОЙ кнопке:
 *     ti_menu_open(w, &d->ti, mx, my);
 * Пункты: «Копировать» (весь текст поля -> буфер обмена) и «Вставить»
 * (буфер -> в позицию курсора, через paste_fn если задан). Недоступные
 * пункты серые (пустое поле / пустой буфер). Выбор доставляется
 * потоку окна как WEV_MENU — колбэк wm исполняется в его потоке,
 * отрисовку поля обновляет win_invalidate внутри ti_menu_cb.
 * Окно может закрыться, пока меню открыто: win_post проверяет живость
 * владельца (тот же контракт, что у всех пользователей wm_menu_open). */
#define TI_MNU_COPY  1           /* пункт «Копировать» */
#define TI_MNU_PASTE 2           /* пункт «Вставить» */
#define TI_MNU_SELALL 3          /* [TI-SEL] пункт «Выделить всё» */

struct window;
void ti_menu_open(struct window *w, ti_t *ti, int mx, int my);
/* Действия отдельно (встраивателям со своими меню/клавишами): */
void ti_clip_copy(ti_t *ti);     /* выделение или весь текст -> буфер обмена */
void ti_clip_paste(ti_t *ti);    /* буфер -> в позицию курсора поля */
void ti_clip_set(const char *s, int n);   /* [TI-SEL] цель для ti_t.copy_fn */

#endif /* TEXTINPUT_H */
