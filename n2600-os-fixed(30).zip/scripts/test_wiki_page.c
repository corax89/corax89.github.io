/* test_wiki_page.c — диагностика: почему wiki-страница рендерится без
 * подсветки ссылок и без таблицы. Прогоняем ТОЧНЫЙ HTML из запроса через
 * реальный конвейер: html_to_md → brp_analyze → brl_wrap, печатаем
 * промежуточные стадии. Сборка:
 *   gcc -DHOST_TEST -fsanitize=address,undefined -I../src \
 *       test_wiki_page.c ../src/htmlconv.c ../src/html_parser.c \
 *       ../src/brpage.c(?) -o test_wiki_page
 * (brpage/brlines header-only — см. s55-тест). */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
typedef uint8_t u8;
typedef uint32_t u32;

#include "../src/htmlconv.h"
#include "../src/html_parser.h"

/* utf8_next — из src/string.c (ядра); на хосте — локальная копия
 * (та же семантика: продвигает указатель на один символ UTF-8). */
static unsigned t_utf8_next(const char **ps)
{
    const unsigned char *p = (const unsigned char *)*ps;
    if (*p == 0) { return 0; }
    int n = 1;
    if      ((*p & 0xE0) == 0xC0) n = 2;
    else if ((*p & 0xF0) == 0xE0) n = 3;
    else if ((*p & 0xF8) == 0xF0) n = 4;
    while (n > 1 && *p) { p++; n--; }
    *ps = (const char *)p;
    return 1;
}
#define utf8_next t_utf8_next

#include "../src/utf8.h"
#include "../src/brpage.h"
#include "../src/brlines.h"
#include "../src/brform.h"

static const char *WIKI_HTML =
"<body>\n"
"<div class=\"titlebar\">All Pages <span style=\"font-weight: normal;\"></span></div>\n"
"<div class=\"toolbar\"><a class=\"tool first\" href=\"/wiki/index.php?action=edit&amp;page=\">Edit</a> "
"<a class=\"tool\" href=\"/wiki/index.php?action=new\">New</a> "
"<a class=\"tool\" href=\"/wiki/index.php?action=upload\">Upload</a> "
"<a class=\"tool\" href=\"/wiki/index.php?action=all_name\">All</a> "
"<a class=\"tool\" href=\"/wiki/index.php?action=all_date\">Recent</a> "
"<a class=\"tool\" href=\"/wiki/index.php\">Home</a>"
"<form method=\"post\" action=\"/wiki/index.php?action=search\">\n"
"<input class=\"tool\" placeholder=\"Search\" size=\"6\" id=\"search\" type=\"text\" name=\"q\"></form>\n"
"</div>\n"
"<div class=\"main\">\n"
/* реалистичный РАЗМЕТКА-HTML: переводы строк между тегами таблицы */
"<table>\n"
"<tr style=\"background-color: #ffffff;\">\n"
"<td><a href=\"/wiki/index.php/Game Boy Advance\">Game Boy Advance</a></td>\n"
"<td width=\"20\"></td>\n"
"<td><a href=\"?action=edit&amp;page=Game+Boy+Advance\">edit</a></td>\n"
"</tr>\n"
"<tr style=\"background-color: #f4f4f4;\">\n"
"<td><a href=\"/wiki/index.php/Dreamcast\">Dreamcast</a></td>\n"
"<td width=\"20\"></td>\n"
"<td><a href=\"?action=edit&amp;page=Dreamcast\">edit</a></td>\n"
"</tr>\n"
"<tr style=\"background-color: #ffffff;\">\n"
"<td><a href=\"/wiki/index.php/NES\">NES</a></td>\n"
"<td width=\"20\"></td>\n"
"<td><a href=\"?action=edit&amp;page=NES\">edit</a></td>\n"
"</tr>\n"
"</table>\n"
"\n"
"</div>\n"
"<script src=\"/wiki/editor/tinyhighlight.js\"></script>\n"
"\n"
"</body>";

/* урезанная копия конвейера браузера: публичные функции brpage.h/brlines.h */
int main(void)
{
    char md[16384];
    int n = html_to_md(WIKI_HTML, (int)strlen(WIKI_HTML), md, (int)sizeof(md));
    printf("=== html_to_md -> %d bytes ===\n", n);
    for (int i = 0; i < n && i < 4000; i++)
        putchar(md[i] == '\x01' ? '@' : md[i]);
    printf("\n=== END MD ===\n");

    /* --- как в браузере: brf_parse ДО brp_analyze --- */
    brf_forms_t forms;
    memset(&forms, 0, sizeof(forms));
    n = brf_parse(&forms, md, n);
    printf("=== after brf_parse: md_len=%d fields=%d scripts=%d ===\n",
           n, forms.nfields, forms.nscripts);
    n = brf_scrub(md, n);
    printf("=== after brf_scrub: md_len=%d ===\n", n);
    for (int i = 0; i < n; i++)
        putchar(md[i] == '\x01' ? '@' : (md[i] == '\x03' ? '#' :
                (md[i] == '\x04' ? '$' : md[i])));
    printf("\n=== END MD1b ===\n");

    /* разбор страницы: ссылки/поля/картинки */
    brp_page_t pg;
    memset(&pg, 0, sizeof(pg));
    int md_len = brp_analyze(&pg, md, n);
    printf("=== after brp_analyze: md_len=%d ===\n", md_len);
    for (int i = 0; i < md_len; i++)
        putchar(md[i] == '\x01' ? '@' : md[i]);
    printf("\n=== END MD2 ===\n");
    printf("=== brp_analyze: links=%d imgs=%d ===\n",
           pg.nlinks, pg.nimgs);
    for (int i = 0; i < pg.nlinks && i < 30; i++) {
        printf("  link[%02d] src=%d b=%d t_end=%d url=\"%.48s\"\n",
               i, pg.links[i].src_idx, pg.links[i].b_abs,
               pg.links[i].t_end_abs, pg.links[i].url);
    }

    /* перенос строк */
    brl_list_t L;
    memset(&L, 0, sizeof(L));
    int cw = 78;
    brl_wrap(md, md_len, cw, &L);
    printf("=== brl_wrap: %d lines (cw=%d) ===\n", L.nlines, cw);
    for (int i = 0; i < L.nlines && i < 40; i++) {
        printf("%3d|%-.*s|%d\n", i, 80, L.lines[i], L.cls[i]);
    }
    /* hex-дамп строки 4 (рамка) и её источника в md */
    if (L.nlines > 4) {
        const char *s4 = L.lines[4];
        int l4 = (int)strlen(s4);
        printf("=== line4 bytes=%d ===\n", l4);
        for (int i = 0; i < l4 && i < 130; i++)
            printf("%02x ", (unsigned char)s4[i]);
        printf("\n");
    }
    /* где в md рамка: ищем ┌ (E2 94 8C) */
    for (int i = 0; i + 2 < md_len; i++) {
        if ((unsigned char)md[i] == 0xE2 && (unsigned char)md[i+1] == 0x94 &&
            (unsigned char)md[i+2] == 0x8C) {
            printf("=== md border at %d, md[0..130) from there ===\n", i);
            for (int j = 0; j < 130 && i + j < md_len; j++)
                printf("%02x ", (unsigned char)md[i + j]);
            printf("\n");
            break;
        }
    }
    return 0;
}
