/* как test_site, но печатает md ПОСЛЕ brf_parse (маркеры \x01 видны как @) */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
typedef uint8_t u8; typedef uint32_t u32;
#include "../src/htmlconv.h"
#include "../src/html_parser.h"
static unsigned t_utf8_next(const char **ps){const unsigned char*p=(const unsigned char*)*ps;if(*p==0)return 0;int n=1;if((*p&0xE0)==0xC0)n=2;else if((*p&0xF0)==0xE0)n=3;else if((*p&0xF8)==0xF0)n=4;while(n>1&&*p){p++;n--;}*ps=(const char*)p;return 1;}
#define utf8_next t_utf8_next
#include "../src/utf8.h"
#include "../src/brpage.h"
#include "../src/brlines.h"
#include "../src/brform.h"
int main(int argc, char **argv) {
    if (argc < 2) return 1;
    const char *cs = argc > 2 ? argv[2] : NULL;
    if (cs) htmlconv_set_charset(cs);
    FILE *f = fopen(argv[1], "rb");
    if (!f) return 1;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    char *html = malloc(sz + 1);
    if (fread(html, 1, sz, f) != (size_t)sz) return 1;
    fclose(f); html[sz] = 0;
    int cap = 6*1024*1024;
    char *md = malloc(cap);
    int n = html_to_md(html, (int)sz, md, cap);
    fprintf(stderr, "html_to_md -> %d\n", n);
    /* маркеры \x01 видны */
    for (int i = 0; i < n; i++) {
        unsigned char c = (unsigned char)md[i];
        if (c == 1) putchar('@');
        else if (c == 3) putchar('#');
        else if (c == 4) putchar('$');
        else if (c == 6) putchar('~');
        else if (c >= 32 || c == '\n') putchar(c);
        else putchar('.');
    }
    return 0;
}
