/* test_s93.c — хост-тест Session 93: минимальный CSS (цвет/жирность/
 * курсив/отступ) в конвертере и разбор стилевых спанов в brpage.h.
 *
 * Схема как в run_test_s92.sh: свежие исходники + -DHOST_TEST.
 *
 * Покрывает:
 *   [HC-CSS]  маркеры \x05RRGGBBf / \x06: hex/именованный/legacy color,
 *             флаги b/i/z, вложенность с восстановлением, отступ
 *             margin-left, отсутствие маркеров в таблицах/pre,
 *             санитизация \x05 из текста, потоковый путь (hc_stream_feed).
 *   [BR-LAZY] hc_stream_input_done / hc_stream_md_len без finish.
 *   [BR-CSS]  brp_analyze: вырезание маркеров, интервалы run'ов,
 *             смещения ссылок внутри спанов, brp_style_segs.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "htmlconv.h"
#include "html_parser.h"

/* utf8_next живёт в string.c ЯДРА; в хост-тесте — локальная копия
 * (как в host-test/s55/string.h). ДО brpage.h/utf8.h, которые зовут. */
static unsigned utf8_next(const char **ps)
{
    const unsigned char *s = (const unsigned char *)*ps;
    unsigned c;
    if (s[0] < 0x80) {
        c = s[0];
        *ps += 1;
    } else if ((s[0] & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
        c = ((unsigned)(s[0] & 0x1F) << 6) | (s[1] & 0x3F);
        *ps += 2;
    } else {
        c = '?';
        do { *ps += 1; } while (((**ps) & 0xC0) == 0x80);
    }
    return c;
}

#include "brpage.h"
#include "utf8.h"

static int total = 0, fails = 0;

static void ok(int cond, const char *name, const char *detail)
{
    total++;
    if (cond) {
        printf("  ok  %s\n", name);
    } else {
        fails++;
        printf("  FAIL %s%s%s\n", name, detail ? ": " : "",
               detail ? detail : "");
    }
}

/* html -> md c NUL-гарантией */
static int conv(const char *html, char *md, int cap)
{
    int n = html_to_md(html, (int)strlen(html), md, cap);
    if (n >= 0 && n < cap) md[n] = 0;
    return n;
}

/* ═══════════ [HC-CSS]: маркеры стиля в md ═══════════ */

static void test_css_markers(void)
{
    char md[1024];

    printf("== [HC-CSS] маркеры стиля ==\n");

    conv("<span style=\"color:#FF8000\">текст</span>", md, sizeof(md));
    ok(strcmp(md, "\x05" "ff8000-текст" "\x06") == 0,
       "style color hex -> \\x05ff8000-...\\x06", md);

    conv("<span style=\"color:red\">x</span>", md, sizeof(md));
    ok(strcmp(md, "\x05" "ff0000-x" "\x06") == 0,
       "именованный red -> ff0000", md);

    conv("<font color=\"#102030\">y</font>", md, sizeof(md));
    ok(strcmp(md, "\x05" "102030-y" "\x06") == 0,
       "legacy color=\"#102030\"", md);

    conv("<span style=\"color:#ABC\">z</span>", md, sizeof(md));
    ok(strcmp(md, "\x05" "aabbcc-z" "\x06") == 0,
       "короткий #RGB -> дублирование цифр", md);

    conv("<span style=\"font-weight:bold\">ж</span>", md, sizeof(md));
    ok(strcmp(md, "\x05" "000000bж" "\x06") == 0,
       "font-weight:bold -> флаг b", md);

    conv("<span style=\"font-weight:700\">ж</span>", md, sizeof(md));
    ok(strcmp(md, "\x05" "000000bж" "\x06") == 0,
       "font-weight:700 -> флаг b", md);

    conv("<span style=\"font-style:italic\">к</span>", md, sizeof(md));
    ok(strcmp(md, "\x05" "000000iк" "\x06") == 0,
       "font-style:italic -> флаг i", md);

    conv("<span style=\"font-weight:bold;font-style:italic\">жк</span>",
         md, sizeof(md));
    ok(strcmp(md, "\x05" "000000zжк" "\x06") == 0,
       "bold+italic -> флаг z", md);

    /* вложенность: внутренний переопределяет, после закрытия внешний
     * восстанавливается (у <b> свои '**' — они в md тоже пишутся) */
    conv("<span style=\"color:#111111\">a<b style=\"color:#222222\">bb</b>c</span>",
         md, sizeof(md));
    ok(strcmp(md, "\x05" "111111-a"
                  "**" "\x05" "222222-" "bb" "**"
                  "\x05" "111111-c" "\x06") == 0,
       "вложенность: переопределение и восстановление", md);

    /* отступ margin-left: 24px -> 3 пробела в начале строки <p> */
    conv("<p style=\"margin-left:24px\">отступ</p>", md, sizeof(md));
    ok(strncmp(md, "   отступ", 10) == 0,
       "margin-left:24px -> 3 пробела", md);

    /* div с отступом становится блочным (новая строка) */
    conv("до<div style=\"margin-left:16px\">блок</div>после", md, sizeof(md));
    ok(strstr(md, "после") != NULL && strstr(md, "  блок") != NULL,
       "div с margin — блочный с отступом", md);

    /* margin БЕЗ других свойств не создаёт спан */
    conv("<p style=\"margin-left:8px\">п</p>", md, sizeof(md));
    ok(strchr(md, '\x05') == NULL && strchr(md, '\x06') == NULL,
       "margin сам по себе — без маркеров", md);

    /* в таблице маркеров нет (коллектор ячеек) */
    conv("<table><tr><td style=\"color:red\">ячейка</td></tr></table>",
         md, sizeof(md));
    ok(strchr(md, '\x05') == NULL && strstr(md, "ячейка") != NULL,
       "в таблице маркеров нет, текст цел", md);

    /* в <pre> маркеров нет (сырой текст) */
    conv("<span style=\"color:red\">вне</span><pre>внутри pre</pre>",
         md, sizeof(md));
    {
        const char *pre = strstr(md, "```");
        ok(pre != NULL && strchr(pre, '\x05') == NULL,
           "в pre маркеров нет", md);
    }

    /* \x05 из исходного текста не становится маркером */
    {
        char in[64];
        snprintf(in, sizeof(in), "a\x05""666666-мусор\x06""b");
        conv(in, md, sizeof(md));
        ok(strchr(md, '\x05') == NULL && strchr(md, '\x06') == NULL,
           "\\x05/\\x06 из текста санитизируются", md);
    }

    /* ссылка внутри цветного спана — href цел */
    conv("<span style=\"color:blue\">см. <a href=\"http://e.x/\">тут</a></span>",
         md, sizeof(md));
    ok(strstr(md, "](http://e.x/)") != NULL,
       "href внутри спана не пострадал", md);

    /* пустой спан не мусорит md */
    conv("<span style=\"color:red\"></span>хвост", md, sizeof(md));
    ok(strcmp(md, "хвост") == 0, "пустой спан — маркеров нет", md);
}

/* ═══════════ [HC-CSS]: потоковый путь ═══════════ */

static void test_css_stream(void)
{
    printf("== [HC-CSS] поток + [BR-LAZY] счётчики ==\n");

    static char md[4096];
    memset(md, 0, sizeof(md));
    hc_stream_t *hs = hc_stream_begin(md, (int)sizeof(md), 0, NULL, NULL);
    ok(hs != NULL, "hc_stream_begin", NULL);

    const char *part1 = "<p style=\"color:#010203\">а";
    const char *part2 = "б</p><b style=\"font-style:italic\">в</b>";
    hc_stream_feed(hs, part1, (int)strlen(part1));
    int done1 = hc_stream_input_done(hs);
    hc_stream_feed(hs, part2, (int)strlen(part2));
    int done2 = hc_stream_input_done(hs);
    /* парсер может придерживать хвостовой текст (возможна entity) —
     * длина md между feed >= 0 и не больше входа */
    int len_mid = hc_stream_md_len(hs);
    int trunc = 0;
    int n = hc_stream_finish(hs, &trunc);
    int len_fin = hc_stream_md_len(hs);
    hc_stream_free(hs);

    ok(done1 == (int)strlen(part1) && done2 == (int)strlen(part1) + (int)strlen(part2),
       "hc_stream_input_done считает вход", NULL);
    ok(len_mid >= 0 && len_mid <= (int)strlen(part1) + (int)strlen(part2),
       "hc_stream_md_len между feed в границах входа", NULL);
    ok(len_fin == n, "hc_stream_md_len после finish == длине md", NULL);
    ok(n > 0 && !trunc, "поток: конвертация без обреза", NULL);
    ok(strstr(md, "\x05" "010203-аб") != NULL &&
       strstr(md, "000000iв") != NULL,
       "стили через поток кусками", md);
}

/* ═══════════ [BR-CSS]: разбор стилей в brp_analyze ═══════════ */

static void test_brp_styles(void)
{
    printf("== [BR-CSS] brp_analyze: спаны ==\n");

    {
        brp_page_t p;
        memset(&p, 0, sizeof(p));
        char md[512];
        int n = (int)strlen("\x05" "ff0000-красный обычный" "\x06 хвост");
        memcpy(md, "\x05" "ff0000-красный обычный" "\x06 хвост", (u32)n + 1);

        int out = brp_analyze(&p, md, n);
        ok(strcmp(md, "красный обычный хвост") == 0,
           "маркеры вырезаны, текст цел", md);
        ok(out == (int)strlen("красный обычный хвост"),
           "длина после вырезки корректна", NULL);
        ok(p.nstyles == 1, "один стилевой run", NULL);
        if (p.nstyles == 1) {
            ok(p.styles[0].b_abs == 0 &&
               p.styles[0].e_abs == (int)strlen("красный обычный") &&
               p.styles[0].rgb == 0xff0000,
               "интервал и цвет run'а", NULL);
        }
    }

    {
        /* ссылка внутри спана: смещения ссылки корректны после вырезки */
        brp_page_t p;
        memset(&p, 0, sizeof(p));
        char buf[512];
        int n = 0;
        const char *m1 = "\x05" "0000ff-см. ";
        const char *lk = "[сайт](http://s.ru/)";
        const char *m2 = "\x06";
        memcpy(buf + n, m1, strlen(m1)); n += (int)strlen(m1);
        memcpy(buf + n, lk, strlen(lk)); n += (int)strlen(lk);
        memcpy(buf + n, m2, strlen(m2)); n += (int)strlen(m2);
        buf[n] = 0;

        int out = brp_analyze(&p, buf, n);
        ok(strcmp(buf, "см. сайт") == 0, "спан+ссылка: текст цел", buf);
        ok(p.nlinks == 1, "ссылка собрана", NULL);
        ok(p.nstyles == 1, "стиль собран", NULL);
        if (p.nlinks == 1 && p.nstyles == 1) {
            /* видимый текст: "см. сайт"; ссылка занимает "сайт" */
            int tb = p.links[0].b_abs, te = p.links[0].t_end_abs;
            ok(tb >= 0 && te <= out &&
               strncmp(buf + tb, "сайт", 4) == 0,
               "интервал ссылки указывает на «сайт»", buf + tb);
            ok(p.styles[0].b_abs == 0 &&
               p.styles[0].e_abs == out,
               "спан покрывает весь видимый текст", NULL);
            ok(p.styles[0].rgb == 0x0000ff, "цвет спана", NULL);
        }
    }

    {
        /* спан рвётся по строкам: run на каждую строку */
        brp_page_t p;
        memset(&p, 0, sizeof(p));
        char buf[256];
        int n = 0;
        const char *m1 = "\x05" "00ff00-";
        memcpy(buf + n, m1, strlen(m1)); n += (int)strlen(m1);
        const char *t = "строка1\nстрока2";
        memcpy(buf + n, t, strlen(t)); n += (int)strlen(t);
        memcpy(buf + n, "\x06", 1); n += 1;
        buf[n] = 0;

        brp_analyze(&p, buf, n);
        ok(p.nstyles == 2, "перевод строки рвёт run на два", NULL);
        if (p.nstyles == 2) {
            ok(p.styles[0].e_abs == (int)strlen("строка1") &&
               p.styles[1].b_abs == (int)strlen("строка1") + 1,
               "интервалы run'ов по строкам", NULL);
        }
    }

    {
        /* brp_style_segs: пересечение с куском отображения */
        brp_page_t p;
        memset(&p, 0, sizeof(p));
        char buf[256];
        const char *m1 = "\x05" "808080-abcdef" "\x06ghijkl";
        int n = (int)strlen(m1);
        memcpy(buf, m1, (u32)n + 1);
        brp_analyze(&p, buf, n);

        brp_styseg_t segs[8];
        /* кусок = весь видимый текст "abcdefghijkl" */
        int ns = brp_style_segs(&p, 0, buf, (int)strlen(buf), segs, 8);
        ok(ns == 1 && segs[0].col0 == 0 && segs[0].col1 == 6 &&
           segs[0].rgb == 0x808080,
           "brp_style_segs: колонки пересечения", NULL);
        /* кусок-хвост (например, вторая строка отображения) */
        ns = brp_style_segs(&p, 6, buf + 6, 6, segs, 8);
        ok(ns == 0, "brp_style_segs: вне спана — пусто", NULL);
    }

    {
        /* md без маркеров — nstyles == 0, md не тронут */
        brp_page_t p;
        memset(&p, 0, sizeof(p));
        char buf[64];
        strcpy(buf, "просто текст");
        brp_analyze(&p, buf, (int)strlen(buf));
        ok(p.nstyles == 0 && strcmp(buf, "просто текст") == 0,
           "без маркеров изменений нет", NULL);
    }
}

int main(void)
{
    test_css_markers();
    test_css_stream();
    test_brp_styles();

    printf("\n== s93: %s (%d/%d) ==\n",
           fails ? "ЕСТЬ ОШИБКИ" : "ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ",
           total - fails, total);
    return fails ? 1 : 0;
}
