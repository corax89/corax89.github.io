#!/bin/sh
# run_test_s92.sh — хост-тест Session 92 (таблицы/списки/кодировки/
# gzip-partial). Схема как в host-test/s55: свежие исходники + -DHOST_TEST.
set -e
cd "$(dirname "$0")"

WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

SRC=../src
for f in htmlconv.c htmlconv.h html_parser.c html_parser.h gunzip.c gunzip.h \
         types.h utf8.h; do
    cp "$SRC/$f" "$WORK/"
done
cp test_s92.c "$WORK/"

gcc -std=gnu99 -g -Wall -Wextra -Wno-unused-parameter -Wno-comment \
    -I "$WORK" -DHOST_TEST -DGZ_HOST \
    "$WORK/test_s92.c" "$WORK/htmlconv.c" "$WORK/html_parser.c" \
    "$WORK/gunzip.c" -o "$WORK/s92"
"$WORK/s92"
