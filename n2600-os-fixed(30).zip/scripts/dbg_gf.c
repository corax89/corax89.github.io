#ifndef HOST_TEST
#define HOST_TEST
#endif
#include "../src/htmlconv.c"
#undef HOST_TEST
#include <stdio.h>
#include <string.h>
int main(void) {
    char md[4096];
    const char *gf =
        "<form action=\"/search\"><table><tr><td width=\"25%\">&nbsp;</td>"
        "<td><input name=\"ie\" value=\"ISO-8859-1\" type=\"hidden\">"
        "<input value=\"zh-HK\" name=\"hl\" type=\"hidden\">"
        "<div><input class=\"lst\" name=\"q\" size=\"57\"></div>"
        "<input value=\"Поиск\" name=\"btnG\" type=\"submit\"></td>"
        "<td><a href=\"/adv\">advanced</a></td></tr></table></form>";
    int n = html_to_md(gf, (int)strlen(gf), md, (int)sizeof(md));
    for (int i = 0; i < n; i++) {
        unsigned char c = (unsigned char)md[i];
        if (c == 1) putchar('@');
        else putchar(c >= 32 || c == '\n' ? c : '?');
    }
    putchar('\n');
    return 0;
}
