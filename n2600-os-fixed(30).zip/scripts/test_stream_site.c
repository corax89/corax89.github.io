/* test_stream_site.c — прогон реального HTML через ПОТОКОВЫЙ конвертер
 * (hc_stream_begin/feed/finish) кусками по 32 КиБ — как браузер. */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
typedef uint8_t u8; typedef uint32_t u32;
#include "../src/htmlconv.h"
#include "../src/html_parser.h"
static unsigned t_utf8_next(const char **ps){const unsigned char*p=(const unsigned char*)*ps;if(*p==0)return 0;int n=1;if((*p&0xE0)==0xC0)n=2;else if((*p&0xF0)==0xE0)n=3;else if((*p&0xF8)==0xF0)n=4;while(n>1&&*p){p++;n--;}*ps=(const char*)p;return 1;}
#define utf8_next t_utf8_next
#include "../src/utf8.h"
#include "../src/brpage.h"
#include "../src/brlines.h"
#include "../src/brform.h"

static int grow(void *ud, char **md, int *max, int want) {
    (void)ud;
    char *nb = (char*)malloc((u32)want);
    if (!nb) return 0;
    if (*md) { memcpy(nb, *md, (u32)*max); free(*md); }
    *md = nb; *max = want;
    return 1;
}

int main(int argc, char **argv) {
    if (argc < 2) return 1;
    FILE *f = fopen(argv[1], "rb");
    if (!f) return 1;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    char *html = malloc(sz + 1);
    if (fread(html, 1, sz, f) != (size_t)sz) return 1;
    fclose(f);
    int cap = 6*1024*1024;
    char *md = (char*)malloc(cap);
    hc_stream_t *hs = hc_stream_begin(md, cap, cap, grow, NULL);
    if (!hs) { fprintf(stderr, "no hs\n"); return 1; }
    long off = 0;
    int feeds = 0;
    while (off < sz) {
        long take = sz - off; if (take > 32768) take = 32768;
        hc_stream_feed(hs, html + off, (int)take);
        off += take; feeds++;
        /* промежуточная длина (как браузер читает md между фидами) */
        volatile int cur = hc_stream_md_len(hs); (void)cur;
    }
    int trunc = 0;
    int n = hc_stream_finish(hs, &trunc);
    hc_stream_free(hs);
    fprintf(stderr, "feeds=%d md=%d trunc=%d\n", feeds, n, trunc);

    brf_forms_t forms; memset(&forms, 0, sizeof(forms));
    n = brf_parse(&forms, md, n);
    n = brf_scrub(md, n);
    brp_page_t pg; memset(&pg, 0, sizeof(pg));
    int md_len = brp_analyze(&pg, md, n);
    brl_list_t L; memset(&L, 0, sizeof(L));
    brl_wrap(md, md_len, 78, &L);
    fprintf(stderr, "links=%d lines=%d\n", pg.nlinks, L.nlines);
    for (int i = 0; i < L.nlines && i < 12; i++)
        printf("%3d|%s\n", i, L.lines[i]);
    return 0;
}
