/* test_s92.c — хост-тест Session 92:
 *   [HC-TBL2] таблицы псевдографикой (рамка, автоширина, align,
 *             colspan/rowspan, TH-разделитель, fallback TSV, вложенная
 *             таблица не рушит конвертер);
 *   [HC-LIST] маркеры •/◦/▪/- по уровням, <ol type=a/i/A/I>, отступ 4;
 *   [HC-ENC]  windows-1251 / koi8-r -> UTF-8 при подаче (буферно и
 *             потоково, meta-charset и http-equiv);
 *   [GZ-PARTIAL] gz_inflate_gzip_partial на обрыве потока.
 * Запуск: sh run_test_s92.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
#include "htmlconv.h"
#include "gunzip.h"

static int fails = 0;

#define CHECK(cond, name) do { \
    if (cond) printf("  ok  %s\n", name); \
    else { printf("FAIL  %s\n", name); fails++; } \
} while (0)

/* strstr по куче маркеров: строка содержит подстроку? */
static int has(const char *hay, const char *needle)
{
    return strstr(hay, needle) != NULL;
}

/* ---------------- таблицы ---------------- */
static void test_tables(void)
{
    char md[16384];
    int trunc = 0;

    /* 1. простая таблица + TH-разделитель */
    {
        const char *html =
            "<table>"
            "<tr><th>Название</th><th>Цена</th></tr>"
            "<tr><td>Хлеб</td><td>50</td></tr>"
            "<tr><td>Молоко</td><td>90</td></tr>"
            "</table>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("table1:\n%s\n", md);
        CHECK(!trunc, "table1: без обреза");
        CHECK(has(md, "\xe2\x94\x8c") && has(md, "\xe2\x94\x90"), "table1: рамка ┌ ┐");
        CHECK(has(md, "\xe2\x94\x94") && has(md, "\xe2\x94\x98"), "table1: рамка └ ┘");
        CHECK(has(md, "Название"), "table1: текст TH");
        CHECK(has(md, "Хлеб") && has(md, "Молоко"), "table1: данные");
        CHECK(has(md, "\xe2\x94\x82"), "table1: вертикали │");
        /* разделитель под заголовком: строка ├──┼──┤ */
        CHECK(has(md, "\xe2\x94\xbc"), "table1: ┼ после TH");
        /* выравнивание колонок: '│' на тех же колонках — грубая проверка:
         * в каждой строке таблицы ровно 3 '│' */
        int rows = 0, ok3 = 1;
        for (const char *p = md; *p; p++) {
            const char *e = strchr(p, '\n');
            int len = e ? (int)(e - p) : (int)strlen(p);
            if (len > 0 && p[0] == '\xe2' && p[1] == '\x94' && p[2] == '\x82') {
                int bars = 0;
                for (int k = 0; k < len - 2; k++)
                    if (p[k] == '\xe2' && p[k+1] == '\x94' && p[k+2] == '\x82')
                        bars++;
                if (bars != 3) ok3 = 0;
                rows++;
            }
            p = e ? e : p + strlen(p) - 1;
            if (!e) break;
        }
        CHECK(ok3 && rows >= 2, "table1: 3 '│' в каждой строке, >=2 строк");
    }

    /* 2. выравнивание align=right */
    {
        const char *html =
            "<table><tr><td>ab</td><td align=\"right\">cd</td></tr></table>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("table2:\n%s\n", md);
        /* ячейка 'cd' прижата вправо: перед ней пробелы */
        CHECK(has(md, "  cd") || has(md, " │ cd │"), "table2: right-выравнивание");
    }

    /* 3. colspan: занятые позиции — пустые ячейки, структура цела */
    {
        const char *html =
            "<table>"
            "<tr><th colspan=\"2\">Заголовок</th></tr>"
            "<tr><td>a</td><td>b</td></tr>"
            "</table>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("table3:\n%s\n", md);
        CHECK(has(md, "Заголовок"), "table3: colspan-ячейка на месте");
        CHECK(has(md, "a") && has(md, "b"), "table3: вторая строка цела");
    }

    /* 4. длинный текст ячейки: перенос ВНУТРИ ячейки, рамка цела */
    {
        const char *html =
            "<table><tr>"
            "<td>очень длинное описание товара которое не влезает в одну строку колонки</td>"
            "<td>ok</td>"
            "</tr></table>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("table4:\n%s\n", md);
        CHECK(has(md, "влезает"), "table4: текст сохранён (перенос)");
    }

    /* 5. переполнение лимитов -> честный TSV-фолбэк (контент не теряем) */
    {
        char html[8192];
        strcpy(html, "<table>");
        for (int r = 0; r < 60; r++)
            sprintf(html + strlen(html),
                    "<tr><td>R%dC1</td><td>R%dC2</td></tr>", r, r);
        strcat(html, "</table>");
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        CHECK(has(md, "R59C2"), "table5: строки за лимитом не потеряны (фолбэк)");
        CHECK(has(md, "R0C1"), "table5: собранные строки выведены");
    }

    /* 6. вложенная таблица не роняет конвертер */
    {
        const char *html =
            "<table><tr><td>внешняя"
            "<table><tr><td>внутренняя</td></tr></table>"
            "</td><td>x</td></tr></table>после";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("table6:\n%s\n", md);
        CHECK(has(md, "после"), "table6: конвертер жив, хвост на месте");
        CHECK(has(md, "внешняя"), "table6: внешняя таблица отрисована");
    }
}

/* ---------------- списки ---------------- */
static void test_lists(void)
{
    char md[8192];
    int trunc = 0;

    {
        const char *html =
            "<ul><li>уровень1"
            "<ul><li>уровень2"
            "<ul><li>уровень3</li></ul>"
            "</li></ul></li></ul>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("list1:\n%s\n", md);
        CHECK(has(md, "\xe2\x80\xa2 уровень1"), "list1: • на уровне 1");
        CHECK(has(md, "\xe2\x97\xa6 уровень2"), "list1: ◦ на уровне 2");
        CHECK(has(md, "\xe2\x96\xaa уровень3"), "list1: ▪ на уровне 3");
        CHECK(has(md, "    \xe2\x97\xa6"), "list1: отступ 4 пробела на ур.2");
    }

    {
        const char *html =
            "<ol type=\"a\"><li>первый</li><li>второй</li></ol>"
            "<ol type=\"i\"><li>один</li><li>два</li></ol>"
            "<ol><li>число</li></ol>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("list2:\n%s\n", md);
        CHECK(has(md, "a) первый"), "list2: type=a -> a)");
        CHECK(has(md, "b) второй"), "list2: type=a -> b)");
        CHECK(has(md, "i) один"), "list2: type=i -> i)");
        CHECK(has(md, "ii) два"), "list2: type=i -> ii)");
        CHECK(has(md, "1. число"), "list2: без type -> 1.");
    }

    {
        const char *html =
            "<ol type=\"I\"><li>x</li><li>y</li><li>z</li><li>w</li></ol>";
        int n = html_to_md2(html, (int)strlen(html), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("list3:\n%s\n", md);
        CHECK(has(md, "I) x") && has(md, "II) y") &&
              has(md, "III) z") && has(md, "IV) w"), "list3: римские I..IV");
    }
}

/* ---------------- кодировки ---------------- */
static void test_charset(void)
{
    char md[4096];
    int trunc = 0;

    /* windows-1251: "Привет" = \cf\xf0\xe8\xe2\xe5\xf2 */
    {
        static const char page[] =
            "<html><head><meta charset=\"windows-1251\"></head>"
            "<body><p>\xcf\xf0\xe8\xe2\xe5\xf2</p></body></html>";
        int n = html_to_md2(page, (int)sizeof(page) - 1,
                            md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("charset1: %s\n", md);
        CHECK(has(md, "\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82"),
              "charset1: cp1251 meta -> UTF-8 «Привет»");
    }

    /* http-equiv Content-Type */
    {
        static const char page[] =
            "<html><head>"
            "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">"
            "</head><body>\xd1\xc2\xc5\xd2</body></html>"; /* СВЕТ */
        int n = html_to_md2(page, (int)strlen(page),
                            md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("charset2: %s\n", md);
        CHECK(has(md, "\xd0\xa1\xd0\x92\xd0\x95\xd0\xa2"),
              "charset2: http-equiv cp1251 -> «СВЕТ»");
    }

    /* koi8-r: "Привет" = \xf0\xd2\xc9\xd7\xc5\xd4 (П=0xF0 в koi8-r) */
    {
        static const char page[] =
            "<meta charset=\"koi8-r\">\xf0\xd2\xc9\xd7\xc5\xd4";
        int n = html_to_md2(page, (int)strlen(page),
                            md, (int)sizeof(md), &trunc);
        md[n] = 0;
        printf("charset3: %s\n", md);
        CHECK(has(md, "\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82"),
              "charset3: koi8-r -> «Привет»");
    }

    /* потоковый путь: подача по кускам (границы кусков посреди текста) */
    {
        static const char page[] =
            "<html><head><meta charset=\"windows-1251\"></head>"
            "<body><p>\xcf\xf0\xe8\xe2\xe5\xf2 \xec\xe8\xf0</p></body></html>";
        int plen = (int)strlen(page);
        static char big[65536];
        hc_stream_t *hs = hc_stream_begin(big, (int)sizeof(big),
                                          (int)sizeof(big), NULL, NULL);
        CHECK(hs != NULL, "charset4: hc_stream_begin");
        if (hs) {
            hc_stream_set_charset(hs, "windows-1251");
            int off = 0;
            while (off < plen) {           /* куски по 7 байт — рвём посреди */
                int take = plen - off < 7 ? plen - off : 7;
                hc_stream_feed(hs, page + off, take);
                off += take;
            }
            int n = hc_stream_finish(hs, &trunc);
            hc_stream_free(hs);
            big[n] = 0;
            printf("charset4: %s\n", big);
            CHECK(has(big, "\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82") &&
                  has(big, "\xd0\xbc\xd0\xb8\xd1\x80"),
                  "charset4: поток cp1251 кусками -> «Привет мир»");
        }
    }

    /* UTF-8 страница: таблица не портится (без перекодировки) */
    {
        const char *page = "<p>\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82</p>";
        int n = html_to_md2(page, (int)strlen(page), md, (int)sizeof(md), &trunc);
        md[n] = 0;
        CHECK(has(md, "\xd0\x9f\xd1\x80\xd0\xb8"), "charset5: UTF-8 без перекодировки");
    }
}

/* ---------------- gzip partial ---------------- */
static void test_gz_partial(void)
{
    /* генерируем gzip снаружи? Нет — берём подход: raw deflate недоступен,
     * поэтому проверяем через «битый» заголовок + полный прогон в
     * test_gz (resp.bin). Здесь — сверка отказа на мусоре и что partial
     * не падает на усечённом zlib-подобном входе. */
    gz_u8 junk[64];
    memset(junk, 0xAB, sizeof(junk));
    gz_u8 out[512];
    gz_u32 olen = 0;
    CHECK(gz_inflate_gzip_partial(junk, sizeof(junk), out,
                                  (u32)sizeof(out), &olen) == -1,
          "gz_partial: мусор -> -1");
    CHECK(gz_inflate_gzip_partial(junk, 5, out, (u32)sizeof(out), &olen) == -1,
          "gz_partial: слишком коротко -> -1");
}

int main(void)
{
    printf("== test_s92: Session 92 ==\n");
    test_tables();
    test_lists();
    test_charset();
    test_gz_partial();
    if (fails) {
        printf("== ПРОВАЛОВ: %d ==\n", fails);
        return 1;
    }
    printf("== s92: ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ ==\n");
    return 0;
}
