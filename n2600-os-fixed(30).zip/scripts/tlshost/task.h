#ifndef TASK_H
#define TASK_H
static inline void task_yield(void) { }
#endif
