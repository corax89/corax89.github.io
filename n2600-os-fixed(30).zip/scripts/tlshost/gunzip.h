/* gunzip.h — общий модуль распаковки DEFLATE/zlib/gzip для N2600-OS.
 *
 * Task 63: код распаковки zlib/deflate РАНЬШЕ был приватной секцией
 * внутри stb_image.h (public domain zlib decode, Sean Barrett) и был
 * доступен только PNG-декодеру. Теперь движок вынесен сюда и
 * используется всеми потребителями сжатых данных:
 *   - stb_image.h  (PNG IDAT)               — через gz_zlib_decode_alloc_hdr;
 *   - rtl8192eu.c  (gzip-прошивка)          — через gz_inflate_gzip;
 *   - rtl8192eu_tables.h (gzip-таблицы)     — через gz_inflate_gzip;
 *   - ath9k_wifi.c (gzip-ini таблицы)       — через gz_inflate_gzip.
 *
 * API:
 *   gz_inflate_raw   — «голый» DEFLATE-поток (RFC 1951);
 *   gz_inflate_zlib  — zlib-обёртка (RFC 1950) с проверкой Adler-32;
 *   gz_inflate_gzip  — gzip-обёртка (RFC 1952) с проверкой CRC-32/ISIZE;
 *   gz_zlib_decode_alloc_hdr — вариант с кучей (выход растёт), для stb;
 *   gz_crc32         — CRC-32 (IEEE, побитово, без таблицы).
 *
 * Все inflate-функции пишут в ЗАРАНЕЕ ВЫДЕЛЕННЫЙ буфер out (out_cap);
 * при нехватке места возвращают ошибку (распаковочная «бомба» не
 * может переполнить буфер). Возвращают 0 при успехе и -1 при ошибке
 * (как syscalls), *out_len = число распакованных байт.
 *
 * Freestanding: не использует libc (только types.h + string.h ядра);
 * для хост-тестов собирается с -DGZ_HOST (libc malloc/string).
 */
#ifndef GUNZIP_H
#define GUNZIP_H

#ifdef GZ_HOST
#include <stddef.h>
typedef unsigned char  gz_u8;
typedef unsigned short gz_u16;
typedef unsigned int   gz_u32;
#else
#include "types.h"
typedef u8  gz_u8;
typedef u16 gz_u16;
typedef u32 gz_u32;
#endif

/* Распаковать raw DEFLATE (RFC 1951). Если consumed != NULL — туда
 * пишется число БАЙТ ВХОДА, реально потреблённых до конца последнего
 * блока (нужно gz_inflate_zlib, чтобы найти Adler-32 после потока). */
int gz_inflate_raw(const gz_u8 *in, gz_u32 in_len,
                   gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len,
                   gz_u32 *consumed);

/* Распаковать zlib-поток (RFC 1950): 2-байтовый заголовок, DEFLATE,
 * Adler-32 в конце (проверяется). */
int gz_inflate_zlib(const gz_u8 *in, gz_u32 in_len,
                    gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len);

/* Распаковать gzip-член (RFC 1952): заголовок с опц. полями
 * (FEXTRA/FNAME/FCOMMENT/FHCRC), DEFLATE, CRC-32 + ISIZE в конце
 * (оба проверяются). Ожидается ровно один член без хвостового мусора. */
int gz_inflate_gzip(const gz_u8 *in, gz_u32 in_len,
                    gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len);

/* Session 92 [GZ-PARTIAL]: gzip-член с ОБРЫВОМ (сервер закрыл соединение
 * до конца тела). Заголовок — строго, DEFLATE — толерантно: отдаётся
 * ЧАСТИЧНЫЙ результат (все полностью декодированные байты), CRC/ISIZE
 * не проверяются. 0 = *out_len > 0, -1 = распознать нечего. */
int gz_inflate_gzip_partial(const gz_u8 *in, gz_u32 in_len,
                            gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len);

/* Session 98 [GZ-CORRUPT]: та же толерантная распаковка, но с ВЕРДИКТОМ
 * «обрыв» или «ПОРЧА». Дискриминатор честный и точный:
 *  - ВАЛИДНЫЙ, но ОБОРВАННЫЙ поток — префикс корректного кодирования:
 *    декодер НЕ МОЖЕТ упереться в невалидный код, он лишь исчерпывает
 *    реальный ввод («real data exhausted» / «unexpected end»). Вывод —
 *    побайтово чистый префикс;
 *  - ПОРЧЕННЫЙ поток (битый сегмент в проводе): битовая позиция сбивается,
 *    и декодер рано или поздно читает НЕВАЛИДНЫЙ код («bad huffman code»,
 *    «bad dist») ПРИ ОСТАВШИХСЯ реальных байтах — валидный поток такого
 *    не допускает. Вывод с точки сбоя содержит мусор (битый DEFLATE
 *    «декодируется» полным деревом Хаффмана как текст-подобный шум —
 *    симптом habr.com «сломанная кодировка после осмысленного начала»).
 * verdict (если не NULL): GZ_PARTIAL_TRUNC = обрыв (вывод чист),
 * GZ_PARTIAL_CORRUPT = порча (выводу доверять нельзя — вызывателю лучше
 * честная ошибка, чем страница из шума). Возврат и out_len — как у
 * gz_inflate_gzip_partial. */
#define GZ_PARTIAL_TRUNC   0
#define GZ_PARTIAL_CORRUPT 1
int gz_inflate_gzip_partial_v(const gz_u8 *in, gz_u32 in_len,
                              gz_u8 *out, gz_u32 out_cap, gz_u32 *out_len,
                              int *verdict);

/* Вариант для stb_image (PNG IDAT): выход в куче, растёт при
 * необходимости. guess — стартовый размер буфера (0 => 16 КиБ).
 * parse_header: 1 = zlib-обёртка (PNG), 0 = raw DEFLATE.
 * Возвращает malloc-буфер (освобождает вызывающий free()) или NULL.
 * *out_len — фактический размер. */
gz_u8 *gz_zlib_decode_alloc_hdr(const gz_u8 *in, gz_u32 in_len,
                                gz_u32 guess, gz_u32 *out_len,
                                int parse_header);

/* CRC-32 (IEEE 802.3, poly 0xEDB88320) — побитовая реализация без
 * таблицы (без гонок за заполнение таблицы и без 1 КиБ BSS). */
gz_u32 gz_crc32(const gz_u8 *p, gz_u32 n);

/* Текст последней ошибки движка (или NULL) — только для логов. */
const char *gz_last_err_pub(void);

#endif /* GUNZIP_H */
