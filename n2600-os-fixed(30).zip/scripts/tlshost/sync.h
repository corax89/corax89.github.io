#ifndef SYNC_H
#define SYNC_H
static inline void s_lock(volatile int *l) { (void)l; }
static inline void s_unlock(volatile int *l) { (void)l; }
static inline int s_trylock(volatile int *l) { (void)l; return 1; }
static inline int slock_owner_of(int v) { (void)v; return 0; }
#endif
