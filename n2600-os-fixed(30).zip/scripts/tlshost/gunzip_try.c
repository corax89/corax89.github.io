#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char gz_u8; typedef unsigned short gz_u16; typedef unsigned int gz_u32;
#include "gunzip.h"
int main(int argc, char **argv) {
    FILE *f = fopen(argv[1], "rb");
    static gz_u8 in[8*1024*1024], out[8*1024*1024];
    gz_u32 n = (gz_u32)fread(in, 1, sizeof(in), f); fclose(f);
    gz_u32 olen = 0;
    int rc = gz_inflate_gzip(in, n, out, sizeof(out), &olen);
    printf("strict: rc=%d out_len=%u\n", rc, olen);
    if (rc == 0) {
        FILE *r = fopen(argv[2], "rb");
        static gz_u8 ref[8*1024*1024];
        gz_u32 rn = (gz_u32)fread(ref, 1, sizeof(ref), r); fclose(r);
        printf("ref=%u match=%s\n", rn,
               (rn == olen && !memcmp(ref, out, olen)) ? "YES" : "NO");
        if (rn == olen) {
            gz_u32 mm = 0; while (mm < olen && ref[mm] == out[mm]) mm++;
            printf("first diff at %u\n", mm);
        }
    }
    return 0;
}
