#ifndef RTC_H
#define RTC_H
int rtc_get_time(int*,int*,int*);
int rtc_get_date(int*,int*,int*);
#endif
