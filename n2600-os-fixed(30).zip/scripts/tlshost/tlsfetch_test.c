/* tlsfetch_test.c — хост-тест ПОЛНОГО HTTPS-пути браузера против ЖИВОЙ
 * сети (сессия 99, диагностика habr.com «gzip: вывод похож на мусор»).
 *
 * Что проверяется настоящим кодом ОС:
 *   net_http.c  — потоковый GET (net_http_get_stream, allow_gzip=1),
 *                 накопитель gzip, санити-проверка вывода, отдача порциями;
 *   net_tls.c   — BearSSL-клиент ([TLS-GUARD2] сторож — в однопоточном
 *                 хост-прогоне всегда снят, но код должен корректно
 *                 компилироваться и качать);
 *   gunzip.c    — строгая/толерантная распаковка.
 * TCP/IP (net.c/net_tcp.c) и NIC-драйверы НЕ участвуют: шим кладёт
 * шифротекст из BSD-сокета прямо в tls_tcp_recv (как колбэк стека).
 *
 * Сравнение: curl с ТОЧНО теми же заголовками (HTTP/1.0, UA, AE: gzip).
 * Для статического файла — побайтово; для живой ленты (habr) —
 * эвристика: HTML-начало, русский UTF-8, разумный размер.
 *
 * Сборка (из каталога tlshost): sh run.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

typedef unsigned int  u32;
typedef unsigned short u16;
typedef unsigned char  u8;
typedef int  i32;

/* ---- настоящие заголовки ОС (копии в этом каталоге) ---- */
#include "net.h"
#include "net_tls.h"

/* ================== шимы ядра ================== */

void serial_puts(const char *s) { fputs(s, stderr); }

static u32 t0_ms;
static u32 now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (u32)(ts.tv_sec * 1000u + ts.tv_nsec / 1000000u);
}
u32 timer_ticks(void) { return now_ms() - t0_ms; }
void task_yield(void) { usleep(500); }

/* RTC: реальное время (проверка сертификатов X.509 требует честную дату) */
int rtc_get_time(int *h, int *mi, int *s)
{
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    *h = tmv.tm_hour; *mi = tmv.tm_min; *s = tmv.tm_sec;
    return 1;
}
int rtc_get_date(int *y, int *mo, int *d)
{
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    *y = tmv.tm_year + 1900; *mo = tmv.tm_mon + 1; *d = tmv.tm_mday;
    return 1;
}

/* ---- TCP-шим: BSD-сокеты под API стека ---- */

typedef struct {
    int  fd;
    tcp_state_t st;
} hsock_t;
static hsock_t g_hs[8];
static net_tcp_recv_cb_t g_cb = NULL;

void net_tcp_set_callback(net_tcp_recv_cb_t cb) { g_cb = cb; }

static int hs_alloc(void)
{
    for (int i = 0; i < 8; i++)
        if (g_hs[i].fd < 0) return i;
    return -1;
}

int net_tcp_connect(u32 dst_ip, u16 dst_port, u16 local_port)
{
    (void)local_port;
    int idx = hs_alloc();
    if (idx < 0) return -1;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port = htons(dst_port);
    sa.sin_addr.s_addr = htonl(dst_ip);
    if (connect(fd, (struct sockaddr *)&sa, sizeof(sa)) != 0) {
        close(fd);
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
    g_hs[idx].fd = fd;
    g_hs[idx].st = TCP_ESTABLISHED;
    return idx;
}

tcp_state_t net_tcp_state(int sock)
{
    if (sock < 0 || sock >= 8 || g_hs[sock].fd < 0) return TCP_CLOSED;
    return g_hs[sock].st;
}

const char *tcp_state_name(tcp_state_t s)
{
    switch (s) {
    case TCP_CLOSED: return "CLOSED";
    case TCP_CLOSE_WAIT: return "CLOSE_WAIT";
    case TCP_ESTABLISHED: return "ESTABLISHED";
    default: return "?";
    }
}

int net_tcp_send(int sock, const void *buf, u32 len)
{
    if (sock < 0 || sock >= 8 || g_hs[sock].fd < 0) return -1;
    ssize_t n = send(g_hs[sock].fd, buf, len, MSG_NOSIGNAL);
    if (n < 0) return (errno == EAGAIN || errno == EWOULDBLOCK) ? 0 : -1;
    return (int)n;
}

void net_tcp_close(int sock)
{
    if (sock < 0 || sock >= 8) return;
    if (g_hs[sock].fd >= 0) close(g_hs[sock].fd);
    g_hs[sock].fd = -1;
    g_hs[sock].st = TCP_CLOSED;
}

int net_tcp_send_pending(int sock) { (void)sock; return 0; }
void net_tcp_kick(int sock) { (void)sock; }
int  net_tcp_was_reset(int sock) { (void)sock; return 0; }
int  net_tcp_rst_info(int sock, u32 *ip, u16 *port, u8 *ttl)
{ (void)sock; (void)ip; (void)port; (void)ttl; return 0; }

/* net_poll: вычитать сокет -> колбэку (tls_tcp_recv или http_tcp_recv) */
static u32 g_peer_ip = 0;
static u16 g_peer_port = 0;

void net_poll(void)
{
    for (int i = 0; i < 8; i++) {
        if (g_hs[i].fd < 0 || g_hs[i].st == TCP_CLOSE_WAIT) continue;
        u8 buf[65536];
        ssize_t n = recv(g_hs[i].fd, buf, sizeof(buf), 0);
        if (n > 0) {
            if (g_cb) g_cb(i, g_peer_ip, g_peer_port, buf, (u32)n);
        } else if (n == 0) {
            g_hs[i].st = TCP_CLOSE_WAIT;      /* FIN сервера */
        } else if (errno != EAGAIN && errno != EWOULDBLOCK) {
            g_hs[i].st = TCP_CLOSE_WAIT;      /* ошибка = конец */
        }
    }
}

/* ---- прочие заглушки net.h ---- */
int  net_aton(const char *s, u32 *ip)
{
    struct in_addr a;
    if (inet_aton(s, &a)) { *ip = ntohl(a.s_addr); return 1; }
    return 0;
}
int  net_dns_resolve(const char *host, u32 *ip, u32 max_ms)
{
    (void)max_ms;
    struct addrinfo hints, *res = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    if (getaddrinfo(host, NULL, &hints, &res) != 0 || !res) return 0;
    *ip = ntohl(((struct sockaddr_in *)res->ai_addr)->sin_addr.s_addr);
    freeaddrinfo(res);
    return 1;
}
int  net_wait_arp(u32 ip, u32 max_ms) { (void)ip; (void)max_ms; return 1; }
u32  net_get_ip(void) { return 0xC0A80001u; }
void net_get_mac(u8 *m) { memset(m, 0x02, 6); }
int net_ntoa(u32 ip, char *buf, u32 n)
{
    snprintf(buf, (size_t)n, "%u.%u.%u.%u",
             (ip >> 24) & 0xFF, (ip >> 16) & 0xFF, (ip >> 8) & 0xFF, ip & 0xFF);
    return 0;
}

/* ================== тест ================== */

typedef struct {
    char *buf;
    u32   cap, len;
    int   aborted;
    int   status;
    char  ctype[64];
} acc_t;

static int on_hdr(void *ud, int status, const char *hdrs, u32 hlen)
{
    acc_t *a = (acc_t *)ud;
    a->status = status;
    /* Content-Type */
    const char *p = hdrs, *e = hdrs + hlen;
    a->ctype[0] = 0;
    while (p < e) {
        const char *le = memchr(p, '\n', (size_t)(e - p));
        if (!le) le = e;
        size_t ll = (size_t)(le - p);
        if (ll > 14 && strncasecmp(p, "content-type:", 13) == 0) {
            const char *v = p + 13;
            while (v < le && (*v == ' ' || *v == '\t')) v++;
            size_t n = (size_t)(le - v);
            while (n > 0 && (v[n-1] == '\r' || v[n-1] == '\n')) n--;
            if (n >= sizeof(a->ctype)) n = sizeof(a->ctype) - 1;
            memcpy(a->ctype, v, n);
            a->ctype[n] = 0;
            break;
        }
        p = le + 1;
    }
    if (status >= 300 && status < 400) {
        /* редирект: пусть тест знает (Location ищет main по hdrs) */
        return 1;
    }
    return 0;
}

static int on_body(void *ud, const char *data, u32 len)
{
    acc_t *a = (acc_t *)ud;
    if (a->len + len > a->cap) return -1;
    memcpy(a->buf + a->len, data, len);
    a->len += len;
    return 0;
}

/* Число невалидных UTF-8 байт (та же метрика, что http_gz_out_sane) */
static long utf8_bad_count(const u8 *p, u32 n)
{
    long bad = 0;
    u32 i = 0;
    while (i < n) {
        u8 c = p[i];
        if (c < 0x80) { if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') bad++; i++; continue; }
        int need = (c & 0xE0) == 0xC0 ? 1 : (c & 0xF0) == 0xE0 ? 2
                 : (c & 0xF8) == 0xF0 ? 3 : -1;
        if (need < 0 || i + (u32)need >= n) { bad++; i++; continue; }
        u32 k;
        for (k = 1; k <= (u32)need; k++)
            if ((p[i + k] & 0xC0) != 0x80) break;
        if (k <= (u32)need) { bad++; i++; continue; }
        i += (u32)need + 1;
    }
    return bad;
}

static int fetch(const char *host, u16 port, const char *path,
                 char *out, u32 cap, u32 *out_len, int *status)
{
    acc_t a;
    memset(&a, 0, sizeof(a));
    a.buf = out;
    a.cap = cap;
    t0_ms = now_ms();
    int rc = net_http_get_stream(host, port, path, 30000, 1, on_hdr, on_body, &a);
    *out_len = a.len;
    {
        const char *o = getenv("OS_OUT");
        if (o && a.len) {
            FILE *f = fopen(o, "wb");
            if (f) { fwrite(out, 1, a.len, f); fclose(f); }
        }
    }
    *status = a.status;
    fprintf(stderr, "[test] %s%s -> rc=%d status=%d ctype='%s' got=%u б, err='%s'\n",
            (port == 443) ? "https://" : "http://", host, rc, a.status,
            a.ctype, a.len, net_http_errstr());
    return rc;
}

static int dump_mode(const char *host, const char *path, const char *outfile);

int main(int argc, char **argv)
{
    for (int i = 0; i < 8; i++) { g_hs[i].fd = -1; g_hs[i].st = TCP_CLOSED; }
    t0_ms = now_ms();

    if (argc >= 4 && !strcmp(argv[1], "--dump")) {
        return dump_mode(argv[2], argv[3], argc > 4 ? argv[4] : "dump.bin");
    }

    static char out[2 * 1024 * 1024];
    u32 olen = 0;
    int status = 0;
    int fails = 0;

    const char *host = (argc > 1) ? argv[1] : "habr.com";
    const char *path = (argc > 2) ? argv[2] : "/ru/feed/";
    int is_static = (argc > 3) ? atoi(argv[3]) : 0;
    const char *ref_path = (argc > 4) ? argv[4] : NULL;

    int rc = fetch(host, 443, path, out, sizeof(out), &olen, &status);

    if (rc < 0) {
        printf("FAIL: rc=%d (%s)\n", rc, net_http_errstr());
        return 1;
    }
    if (olen == 0) {
        printf("FAIL: пустое тело\n");
        return 1;
    }
    long bad = utf8_bad_count((const u8 *)out, olen);
    printf("[test] невалидных UTF-8 байт: %ld на %u (%.4f%%)\n",
           bad, olen, 100.0 * bad / (double)olen);

    if (is_static && ref_path) {
        /* статический файл: побайтовое сравнение с curl */
        FILE *f = fopen(ref_path, "rb");
        if (!f) { printf("FAIL: нет эталона %s\n", ref_path); return 1; }
        fseek(f, 0, SEEK_END);
        long rn = ftell(f);
        fseek(f, 0, SEEK_SET);
        static char ref[2 * 1024 * 1024];
        if (rn > (long)sizeof(ref)) rn = sizeof(ref);
        size_t got = fread(ref, 1, (size_t)rn, f);
        fclose(f);
        if ((u32)got != olen || memcmp(ref, out, olen) != 0) {
            u32 mm = 0;
            while (mm < olen && mm < (u32)got && ref[mm] == out[mm]) mm++;
            printf("FAIL: эталон %zu б vs ОС %u б, первое расхождение @%u\n",
                   got, olen, mm);
            fails++;
        } else {
            printf("OK: ПОБАЙТОВО совпадает с curl (%u б)\n", olen);
        }
    } else {
        /* живая лента: эвристики */
        if (bad > 8) {
            printf("FAIL: вывод похож на мусор (%ld bad)\n", bad);
            fails++;
        } else {
            printf("OK: текст чистый\n");
        }
        if (olen < 20000) {
            printf("FAIL: подозрительно мало байт (%u)\n", olen);
            fails++;
        }
    }
    printf("%s\n", fails ? "== ПРОВАЛ ==" : "== УСПЕХ ==");
    return fails ? 1 : 0;
}

/* net.c: loopback-хост (localhost и литерал 127.0.0.1) */
int net_host_is_loopback(const char *host)
{
    return host && (!strcmp(host, "localhost") ||
                    !strncmp(host, "127.", 4));
}

/* ================== [--dump] сырое тело через настоящий TLS ==================
 * Минимальный повтор flow net_http (TLS-рукопожатие -> запрос -> pump),
 * но plaintext пишется в файл КАК ЕСТЬ (это то, что получил бы
 * http_gz_sink). Дальше сравнение с curl и раздельная распаковка. */
static const char *g_dump_path = "dump.bin";

static void dump_plain(const void *data, u32 len)
{
    FILE *f = fopen(g_dump_path, "ab");
    if (f) { fwrite(data, 1, len, f); fclose(f); }
}

static int dump_mode(const char *host, const char *path, const char *outfile)
{
    static char req[512];
    u32 ip = 0;
    if (!net_dns_resolve(host, &ip, 15000)) { printf("FAIL: dns\n"); return 1; }
    for (int i = 0; i < 8; i++) { g_hs[i].fd = -1; g_hs[i].st = TCP_CLOSED; }
    int sock = net_tcp_connect(ip, 443, 40000);
    if (sock < 0) { printf("FAIL: connect\n"); return 1; }
    g_dump_path = outfile;
    unlink(outfile);
    tls_set_sink(dump_plain);
    net_tcp_set_callback(NULL);   /* прямой вызов tls_tcp_recv из net_poll */
    g_cb = tls_tcp_recv;
    if (!tls_start(sock, host, 30000)) { printf("FAIL: tls: %s\n", tls_errstr()); return 1; }
    snprintf(req, sizeof(req),
             "GET %s HTTP/1.0\r\n"
             "Host: %s\r\n"
             "User-Agent: N2600-OS/0.1\r\n"
             "Accept-Encoding: gzip\r\n"
             "Connection: close\r\n"
             "\r\n", path, host);
    if (!tls_send_all(req, (u32)strlen(req))) { printf("FAIL: send\n"); return 1; }
    u32 t0 = timer_ticks();
    while (net_tcp_state(sock) == TCP_ESTABLISHED &&
           (timer_ticks() - t0) < 30000) {
        tls_pump();
        net_poll();
    }
    for (int i = 0; i < 8; i++) tls_pump();
    tls_shutdown();
    net_tcp_close(sock);
    printf("[dump] %s: %ld б\n", outfile, ftell(fopen(outfile, "rb")));
    return 0;
}
