#!/bin/sh
# run.sh — хост-тест полного HTTPS-пути ОС (net_http+net_tls+bearssl+gunzip)
# против живой сети. Запуск: sh run.sh [хост путь [статический эталон]]
set -e
cd "$(dirname "$0")"
SRC=${SRC:-../../src}

# настоящие исходники/заголовки ОС
for f in net_http.c net_tls.c bearssl.c gunzip.c \
         net.h net_tls.h gunzip.h types.h bearssl.h tls_anchors.h; do
    cp $SRC/$f .
done

# редиректы libc + заглушки ядра (наши версии перекрывают локально)
printf '#include <string.h>\n#include <stdio.h>\n#include <stdlib.h>\n' > string.h
printf '#include <stdlib.h>\n' > mem.h
printf '#ifndef TIMER_H\n#define TIMER_H\n#include "types.h"\nu32 timer_ticks(void);\n#endif\n' > timer.h
printf '#ifndef TASK_H\n#define TASK_H\nstatic inline void task_yield(void) { }\n#endif\n' > task.h
printf '#ifndef RTC_H\n#define RTC_H\nint rtc_get_time(int*,int*,int*);\nint rtc_get_date(int*,int*,int*);\n#endif\n' > rtc.h
cat > sync.h <<'EOF'
#ifndef SYNC_H
#define SYNC_H
static inline void s_lock(volatile int *l) { (void)l; }
static inline void s_unlock(volatile int *l) { (void)l; }
static inline int s_trylock(volatile int *l) { (void)l; return 1; }
static inline int slock_owner_of(int v) { (void)v; return 0; }
#endif
EOF

gcc -O1 -g -Wall -Wno-unused-parameter -o tlsfetch_test \
    tlsfetch_test.c net_http.c net_tls.c bearssl.c gunzip.c -DGZ_HOST
echo "== tlsfetch_test собран =="
