#!/bin/sh
# test_gzpartial.sh — Session 95 [GZ-PARTIAL2]: регрессионный тест
# толерантной распаковки ОБОРВАННОГО gzip-потока.
#
# Сценарий (реальный кейс habr.com: сервер закрыл соединение посреди
# тела — «gzip: не распакован (сжато 15447 б, обрыв)»): большой
# HTML-текст сжимается gzip'ом, поток режется в разных точках, для
# каждой:
#   1) строгая gz_inflate_gzip обязана вернуть -1 (поток неполный);
#   2) толерантная gz_inflate_gzip_partial обязана вернуть ровно ТУ
#      длину, что даёт zlib (python) на том же обрывке, и байты
#      обязаны быть префиксом эталона (никакого мусорного хвоста).
# Эталонные длины генерирует python (zlib) -> expected_len.h.
# Запуск: sh scripts/test_gzpartial.sh
set -e
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$(dirname "$0")"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "[1/3] фикстура: сжимаем текст, считаем эталонные длины zlib"
python3 - "$TMP" <<'EOF'
import gzip, sys, zlib, random

tmp = sys.argv[1]
random.seed(2600)
words = [" habr", "<div", "class=\"post\"", "текст", "комментарий",
         "namespace", "kernel", "</p>", "&amp;", "сессия", "gzip",
         "поток", "deflate", "хабр", "статья", "{", "}", "\n", "  "]
parts = []
for i in range(30000):
    parts.append(random.choice(words))
    if i % 37 == 0:
        parts.append(f"<a href=\"/ru/post/{i}/\">")
html = "".join(parts).encode("utf-8")
gz = gzip.compress(html, 9)
open(f"{tmp}/full.gz", "wb").write(gz)
open(f"{tmp}/ref.bin", "wb").write(html)

# точки обрыва: каждые ~2% длины + окрестность конца
n = len(gz)
pts = sorted(set([12, 40, 100, 300, 1000]
                 + [n * i // 50 for i in range(1, 50)]
                 + [n - 1, n]))
lines = []
for p in pts:
    o = zlib.decompressobj(16 + zlib.MAX_WBITS)
    part = o.decompress(gz[:p])
    lines.append(f"{{ {p}u, {len(part)}u }}")
open(f"{tmp}/expected_len.h", "w").write(
    "/* генерируется test_gzpartial.sh: { смещение_обрыва, ожидаемая длина } */\n"
    "static const struct { unsigned cut, want; } GZP_CASES[] = {\n    "
    + ",\n    ".join(lines) + "\n};\n"
    f"#define GZP_NCASES {len(pts)}u\n")
print(f"  gzip {n} б -> текст {len(html)} б, точек обрыва: {len(pts)}")
EOF

echo "[2/3] сборка теста"
cat > "$TMP/main.c" <<'EOF'
#define GZ_HOST 1
#include "gunzip.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "expected_len.h"

int main(void)
{
    FILE *f = fopen("full.gz", "rb");
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    unsigned char *gz = malloc((size_t)n);
    fread(gz, 1, (size_t)n, f); fclose(f);
    f = fopen("ref.bin", "rb");
    fseek(f, 0, SEEK_END); long rn = ftell(f); fseek(f, 0, SEEK_SET);
    unsigned char *ref = malloc((size_t)rn);
    fread(ref, 1, (size_t)rn, f); fclose(f);

    int fail = 0;
    unsigned char *out = malloc(8u * 1024u * 1024u);
    for (unsigned i = 0; i < GZP_NCASES; i++) {
        unsigned cut = GZP_CASES[i].cut, want = GZP_CASES[i].want;
        unsigned out_len = 0;
        int rc = gz_inflate_gzip_partial(gz, cut, out,
                                         8u * 1024u * 1024u, &out_len);
        if (want == 0) {
            /* zlib тоже не декодировала ничего: пусто — корректно */
            if (rc == 0 && out_len > 0) {
                printf("[FAIL] обрыв %u: получено %u б, zlib даёт 0\n",
                       cut, out_len);
                fail = 1;
            }
        } else if (rc != 0 || out_len != want) {
            printf("[FAIL] обрыв %u: rc=%d out_len=%u, zlib даёт %u\n",
                   cut, rc, out_len, want);
            fail = 1;
            continue;
        } else if (out_len > 0 && memcmp(out, ref, out_len) != 0) {
            unsigned k;
            for (k = 0; k < out_len && out[k] == ref[k]; k++) {}
            printf("[FAIL] обрыв %u: байты расходятся с эталоном на %u\n",
                   cut, k);
            fail = 1;
            continue;
        }
        /* строгая распаковка обрыва обязана падать (кроме полного) */
        if (cut < (unsigned)n) {
            unsigned sl = 0;
            if (gz_inflate_gzip(gz, cut, out, 8u * 1024u * 1024u, &sl) == 0) {
                printf("[FAIL] обрыв %u: строгая распаковка вдруг УСПЕХ\n", cut);
                fail = 1;
            }
        }
    }
    /* полный поток: строгая обязана пройти и дать CRC-валидный результат */
    {
        unsigned out_len = 0;
        if (gz_inflate_gzip(gz, (unsigned)n, out,
                            8u * 1024u * 1024u, &out_len) != 0 ||
            out_len != (unsigned)rn || memcmp(out, ref, out_len) != 0) {
            printf("[FAIL] полный поток: строгая распаковка не сошлась\n");
            fail = 1;
        }
    }
    if (!fail) printf("GZ-PARTIAL2: %u/%u passed\n", GZP_NCASES, GZP_NCASES);
    free(out); free(gz); free(ref);
    return fail;
}
EOF
gcc -DGZ_HOST -O1 -g -fsanitize=address,undefined \
    -I"$SCRIPT_DIR/../src" \
    -o "$TMP/test" "$TMP/main.c" "$SCRIPT_DIR/../src/gunzip.c"

echo "[3/3] прогон"
(cd "$TMP" && ./test)
RC=$?
exit $RC
