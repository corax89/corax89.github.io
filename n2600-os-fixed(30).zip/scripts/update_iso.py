#!/usr/bin/env python3
"""Обновление kernel.bin внутри готового os.iso — In-place, без пересборки GRUB.

Заменяет /boot/kernel.bin (и, опционально, /boot/grub/grub.cfg) в готовом
загрузочном образе, НЕ переписывая структуру ISO:

  * новое ядро записывается по ТОМУ ЖЕ экстенту, что у старого
    (kernel.bin — последний файл образа, за ним ~530 КиБ свободного места);
  * в каталогах Primary (ISO9660) и Supplementary (Joliet) томов правится
    только 4-байтовое поле размера записи;
  * El Torito-каталог и гибридный (isohybrid) MBR не затрагиваются вовсе —
    образ остаётся грузимым и с CD (El Torito), и с USB (dd).

Никаких зависимостей: чистый Python 3 + struct.

Почему не pycdlib: rm_file()+add_file() переставляет ВСЕ файлы образа,
при этом гибридный MBR (первые 512 байт, код загрузки с USB) теряется —
запись образа на флешку через dd перестала бы работать.

Использование (из корня проекта, после build.sh):
    python3 scripts/update_iso.py

Обновляет:
    os.iso              — собранный образ (основной выход);
    prebuilt/os.iso     — тот же образ в prebuilt (чтобы дерево проекта
                          оставалось самосогласованным: готовое = свежее);
    prebuilt/kernel.bin — копия нового ядра.

grub.cfg заменяется только если новый файл НЕ больше старого
(вписывается в его слот); иначе — предупреждение и пропуск.
"""
import os
import struct
import sys

SECT = 2048

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(BASE_DIR, ".."))


# ---------------------------------------------------------------- разбор ISO

def dir_records(data, extent, size):
    """Итератор записей каталога ISO9660: (rec_off_in_data, lba, size, flags, name)."""
    off = 0
    end = extent * SECT + size
    abs_start = extent * SECT
    while abs_start + off < end:
        rec = abs_start + off
        ln = data[rec]
        if ln == 0:
            # выравнивание на сектор — прыжок к следующему сектору
            nxt = (off // SECT + 1) * SECT
            if nxt >= size:
                return
            off = nxt
            continue
        lba = struct.unpack('<I', data[rec + 2:rec + 6])[0]
        fsize = struct.unpack('<I', data[rec + 10:rec + 14])[0]
        flags = data[rec + 25]
        nlen = data[rec + 32]
        raw = data[rec + 33:rec + 33 + nlen]
        yield rec, lba, fsize, flags, raw
        off += ln
        if ln == 0:
            return


def iso_name(raw, joliet):
    """Нормализованное имя: нижний регистр, без ';1', UTF-16BE для Joliet.
    Записи '.'/'..' в ISO9660/Joliet — ОДНОБАЙТОВЫЕ 0x00/0x01 (даже в Joliet,
    где прочие имена двухбайтовые): возвращаем их как \x00/\x01 для фильтра."""
    if len(raw) == 1 and raw[0] in (0, 1):
        return chr(raw[0])
    if joliet:
        try:
            s = raw.decode('utf-16-be', errors='replace')
        except Exception:
            s = raw.decode('latin1', errors='replace')
    else:
        s = raw.decode('latin1', errors='replace')
    s = s.split(';')[0]
    return s.lower().rstrip()


def walk_tree(data, root_lba, root_size, joliet=False):
    """Полное дерево: { '/a/b': (lba, size, dir_record_offset) } (файлы и каталоги)."""
    out = {}
    seen_dirs = {root_lba}          # защита от циклов ('.' в Joliet и т.п.)
    stack = [("/", root_lba, root_size)]
    while stack:
        prefix, lb, sz = stack.pop()
        for rec, lba, fsize, flags, raw in dir_records(data, lb, sz):
            nm = iso_name(raw, joliet)
            if nm in ("", "\x00", "\x01"):
                continue
            path = prefix + nm
            out[path] = (lba, fsize, rec)
            if flags & 0x02:
                if lba in seen_dirs:      # уже обойдён — не зацикливаемся
                    continue
                seen_dirs.add(lba)
                stack.append((path + "/", lba, fsize))
    return out


def volume_descriptors(data):
    """[(type, sector), ...] для PVD (1) и SVD/Joliet (2)."""
    vds = []
    sec = 16
    while True:
        vd = data[sec * SECT:(sec + 1) * SECT]
        if vd[1:6] != b"CD001":
            break
        t = vd[0]
        if t == 255:
            break
        if t in (1, 2):
            vds.append((t, sec))
        sec += 1
    return vds


# ---------------------------------------------------------------- патчинг

def patch_size_field(data, rec_off, new_size):
    """Записать новый размер в поле size записи каталога (смещение 10)."""
    data[rec_off + 10:rec_off + 14] = struct.pack('<I', new_size)


def find_in_tree(tree, base):
    """Найти файл по базовому имени (path/базовое_имя) в любом каталоге."""
    for nm, val in tree.items():
        p = nm.rstrip('/')
        if p == base or p.endswith('/' + base):
            return nm, val
    return None, None



# ================================================================ ramdisk
# Упаковка каталога ramdisk/ проекта в /boot/ramdisk внутри ISO.
# «Рядом с ядром»: ядро лежит в /boot, содержимое ramdisk/ доступно
# ОС при загрузке как файлы RAM disk (копирует ядро, ramfs_seed_from_iso).
#
# Раскладка хвоста образа (все смещения кратны сектору 2048):
#   [ядро @ его LBA, растёт] [pad] [каталог ramdisk 1 сект] [файлы]
#   [pad] [grub.cfg @ САМЫЙ КОНЕЦ образа]
# grub.cfg ВСЕГДА переносится в хвост — одна детерминированная раскладка,
# повторные запуски дают байт-в-байт тот же образ (идемпотентность).

RAMDISK_SRC = os.path.join(PROJ, "ramdisk")
RAMDISK_NAME = b"ramdisk"


def boot_dir_record(data, pvd_tree):
    """(rec_off /boot, lba /boot, size /boot) — PVD-запись каталога /boot."""
    val = pvd_tree.get("/boot")
    if val is None:
        return None
    lba, fsize, rec = val
    return (rec, lba, fsize)


def scan_dir_records(data, lba, size):
    """Записи каталога как список dict-ов (для поиска по имени + вставки)."""
    out = []
    end = lba * SECT + size
    off = 0
    while lba * SECT + off < end:
        rec = lba * SECT + off
        ln = data[rec]
        if ln == 0:
            break
        nlen = data[rec + 32]
        raw = data[rec + 33:rec + 33 + nlen]
        out.append({
            "off": off, "abs": rec, "len": ln,
            "lba": struct.unpack('<I', data[rec + 2:rec + 6])[0],
            "size": struct.unpack('<I', data[rec + 10:rec + 14])[0],
            "flags": data[rec + 25],
            "name": raw.split(b';')[0].rstrip(),
            "raw": raw,
        })
        off += ln
    return out, off   # off = конец последней записи (для вставки в slack)


def make_dir_record(lba, size, is_dir, name_bytes):
    """ECMA-119 запись каталога (без SUSP). name=b'\x00'/b'\x01' => '.'/'..'.
    Длина записи всегда чётная (ECMA-119). Каталоги — без ';1'."""
    if name_bytes in (b'\x00', b'\x01'):
        nm = name_bytes
    elif is_dir:
        nm = name_bytes
    else:
        nm = name_bytes + b';1'
    n = 33 + len(nm)
    total = n + (n % 2)              # чётная длина записи
    rec = bytearray(total)
    rec[0] = total                   # rec_len
    # ext len (байт 1) = 0
    struct.pack_into('<I', rec, 2, lba)
    struct.pack_into('>I', rec, 6, lba)
    struct.pack_into('<I', rec, 10, size)
    struct.pack_into('>I', rec, 14, size)
    # 18..24: дата/время записи — нули (читатели не проверяют)
    rec[25] = 0x02 if is_dir else 0x00
    rec[26] = 0                       # file unit size
    rec[27] = 0                       # interleave gap
    struct.pack_into('<H', rec, 28, 1)
    struct.pack_into('>H', rec, 30, 1)
    rec[32] = len(nm)
    rec[33:33 + len(nm)] = nm
    if n % 2:
        rec[33 + len(nm)] = 0         # pad до чётной длины
    return bytes(rec)


def pack_ramdisk(data, pvd_tree, kernel_end_abs, iso_size, grub_bytes):
    """Возвращает (ramdisk_dir_lba, grub_lba) или (None, grub_lba).

    1) чистит хвост [align(kernel_end), iso_size) от мусора;
    2) размещает /boot/ramdisk (запись каталога в /boot + экстент + файлы);
       если файлов НЕТ — удаляет запись ramdisk из /boot;
    3) размещает grub.cfg в самый конец образа — В ЛЮБОМ СЛУЧАЕ
       (хвост только что затёрт, старая копия grub.cfg уничтожена!).

    FIX: раньше при пустом ramdisk/ функция возвращала (None, None)
    ПОСЛЕ затирания хвоста — grub.cfg оставался нулевым, и образ
    переставал грузиться (GRUB находил пустой конфиг).

    Вызывается ПОСЛЕ записи ядра и ДО контроля пересечений.
    """
    k_end = (kernel_end_abs + SECT - 1) // SECT * SECT
    if k_end >= iso_size:
        raise RuntimeError("kernel does not fit")

    # 1) затереть весь хвост (идемпотентность: старые ramdisk-экстенты,
    #    старый grub.cfg и мусор исчезают; ядро заканчивается ДО k_end)
    for i in range(k_end, iso_size):
        data[i] = 0

    # grub.cfg — в самый конец (в ЛЮБОМ случае: хвост стёрт выше)
    cfg_sects = (len(grub_bytes) + SECT - 1) // SECT
    grub_lba = iso_size // SECT - cfg_sects

    files = []
    if os.path.isdir(RAMDISK_SRC):
        for nm in sorted(os.listdir(RAMDISK_SRC)):
            p = os.path.join(RAMDISK_SRC, nm)
            if os.path.isfile(p):
                files.append((nm, open(p, "rb").read()))

    boot_rec = boot_dir_record(data, pvd_tree)
    if boot_rec is None:
        raise RuntimeError("/boot record not found")
    b_rec, b_lba, b_size = boot_rec

    if not files:
        print("  ramdisk: исходники пусты (каталог ramdisk/ отсутствует) — "
              "запись /boot/ramdisk удаляется")
        # убрать запись 'ramdisk' из /boot (она ПОСЛЕДНЯЯ — вставлялась в
        # slack; обнуление = чистое завершение каталога)
        recs, last_off = scan_dir_records(data, b_lba, b_size)
        for r in recs:
            if r["name"].lower() == RAMDISK_NAME:
                for k in range(r["len"]):
                    data[r["abs"] + k] = 0
                break
        # grub.cfg всё равно пишем (хвост стёрт)
        off = grub_lba * SECT
        if off < k_end:                      # k_end уже в байтах!
            raise RuntimeError("grub.cfg does not fit into tail")
        data[off:off + len(grub_bytes)] = grub_bytes
        return None, grub_lba

    # 2) экстент каталога ramdisk: 1 сектор
    cursor = k_end
    rd_lba = cursor // SECT
    cursor += SECT
    # файлы: каждый со своего сектора
    fslots = []
    for nm, blob in files:
        if not blob:
            fslots.append((nm, blob, None, 0))
            continue
        lba = cursor // SECT
        cursor += (len(blob) + SECT - 1) // SECT * SECT
        fslots.append((nm, blob, lba, len(blob)))

    if grub_lba * SECT < cursor:
        raise RuntimeError("ramdisk+grub.cfg do not fit into tail")

    # содержимое каталога: '.', '..', файлы
    dirbuf = bytearray()
    dirbuf += make_dir_record(rd_lba, SECT, True, b'\x00')
    dirbuf += make_dir_record(b_lba, b_size or SECT, True, b'\x01')
    for nm, blob, lba, ln in fslots:
        if lba is None:
            continue
        dirbuf += make_dir_record(lba, ln, False, nm.encode('latin-1', 'replace').lower())
    while len(dirbuf) < SECT:
        dirbuf.append(0)
    if len(dirbuf) > SECT:
        raise RuntimeError("ramdisk dir overflow")
    data[rd_lba * SECT:rd_lba * SECT + SECT] = dirbuf

    # файлы
    for nm, blob, lba, ln in fslots:
        if lba is None:
            continue
        data[lba * SECT:lba * SECT + len(blob)] = blob

    # 3) запись 'ramdisk' в /boot (в slack после последней записи)
    recs, last_off = scan_dir_records(data, b_lba, b_size)
    slot_abs = None
    for r in recs:
        if r["name"].lower() == RAMDISK_NAME:
            slot_abs = r["abs"]
            break
    if slot_abs is None:
        slot_abs = b_lba * SECT + last_off
        if last_off + 64 > b_size:
            raise RuntimeError("no slack in /boot dir for ramdisk record")
    rec = make_dir_record(rd_lba, SECT, True, RAMDISK_NAME)
    data[slot_abs:slot_abs + len(rec)] = rec
    # затереть за новой записью до конца сектора (аккуратность)
    print(f"  ramdisk: /boot/ramdisk @LBA {rd_lba}, файлов: {len(fslots)}, "
          f"байт: {sum(len(b) for _, b, _, _ in fslots)}")
    return rd_lba, grub_lba


def main():
    iso_out = os.path.join(PROJ, "os.iso")
    kernel = os.path.join(PROJ, "kernel.bin")
    grubcfg = os.path.join(PROJ, "grub", "grub.cfg")

    # [ISO-FLOW] FIX: источник образа — prebuilt/os.iso, при отсутствии
    # (архив поставляется с os.iso в корне) — корневой os.iso; создаём
    # prebuilt/ при первом запуске, чтобы дерево стало самосогласованным.
    prebuilt_dir = os.path.join(PROJ, "prebuilt")
    iso_in = os.path.join(prebuilt_dir, "os.iso")
    if not os.path.exists(iso_in):
        iso_in = iso_out            # корневой os.iso — источник
    if not os.path.exists(iso_in):
        print(f"ERROR: не найден os.iso (ни {prebuilt_dir}/os.iso, ни корневой)",
              file=sys.stderr)
        return 1
    if not os.path.exists(kernel):
        print(f"ERROR: {kernel} не найден — сначала выполните build.sh", file=sys.stderr)
        return 1

    with open(kernel, "rb") as f:
        new_kernel = f.read()
    if not new_kernel:
        print("ERROR: kernel.bin пуст", file=sys.stderr)
        return 1

    with open(iso_in, "rb") as f:
        data = bytearray(f.read())
    iso_size = len(data)
    print(f"Образ: {iso_in} ({iso_size} байт)")
    print(f"Ядро:  {kernel} ({len(new_kernel)} байт)")

    vds = volume_descriptors(bytes(data))
    if not vds:
        print("ERROR: не найдены дескрипторы тома (не ISO9660?)", file=sys.stderr)
        return 1

    # --- собрать деревья PVD и (если есть) Joliet ---
    trees = {}
    for t, sec in vds:
        root_lba = struct.unpack('<I', data[sec * SECT + 158:sec * SECT + 162])[0]
        root_size = struct.unpack('<I', data[sec * SECT + 166:sec * SECT + 170])[0]
        trees[t] = walk_tree(bytes(data), root_lba, root_size, joliet=(t == 2))

    pvd_tree = trees.get(1)
    jol_tree = trees.get(2)
    if not pvd_tree:
        print("ERROR: нет Primary Volume Descriptor", file=sys.stderr)
        return 1

    # --- найти kernel.bin во всех деревьях ---
    base_name = "kernel.bin"
    entries = []
    for tree, tag in ((pvd_tree, "ISO9660/PVD"), (jol_tree, "Joliet/SVD")):
        if tree is None:
            continue
        path, val = find_in_tree(tree, base_name)
        if val is None:
            print(f"WARNING: kernel.bin не найден в дереве {tag} — пропускаю")
            continue
        lba, fsize, rec = val
        entries.append((tag, path, lba, fsize, rec))
        print(f"  {tag}: {path} — LBA {lba}, {fsize} байт (record @{rec})")

    if not entries:
        print("ERROR: kernel.bin не найден ни в одном дереве", file=sys.stderr)
        return 1

    # --- проверки: хватает ли места в хвосте образа ---
    k_lba = entries[0][2]
    k_old = entries[0][3]
    new_end = k_lba * SECT + len(new_kernel)
    if new_end > iso_size:
        print(f"ERROR: новое ядро ({len(new_kernel)} байт, конец @{new_end}) "
              f"не помещается в образ ({iso_size} байт).", file=sys.stderr)
        print(f"       Свободно за текущим ядром: {iso_size - k_lba * SECT} байт.",
              file=sys.stderr)
        return 1
    if len(new_kernel) < k_old // 2:
        print(f"NOTE: ядро стало заметно меньше ({len(new_kernel)} < {k_old}) — "
              f"проверьте сборку")

    # --- записать новое содержимое по тому же экстенту ---
    start = k_lba * SECT
    data[start:start + len(new_kernel)] = new_kernel
    # затереть хвост старого ядра (в слоте не должно остаться мусора)
    if len(new_kernel) < k_old:
        for i in range(start + len(new_kernel), start + k_old):
            data[i] = 0

    # --- обновить поле size во всех найденных записях каталогов ---
    for tag, path, lba, fsize, rec in entries:
        patch_size_field(data, rec, len(new_kernel))
        print(f"  {tag}: размер {path} -> {len(new_kernel)}")

    # --- grub.cfg: ВСЕГДА в самый конец образа (одна раскладка на все
    #     запуски — см. pack_ramdisk), плюс упаковка /boot/ramdisk ---
    grub_eff_lba = None
    if os.path.exists(grubcfg):
        with open(grubcfg, "rb") as f:
            new_cfg = f.read()
        g_recs = []
        for tree, tag in ((pvd_tree, "ISO9660/PVD"), (jol_tree, "Joliet/SVD")):
            if tree is None:
                continue
            gpath, gval = find_in_tree(tree, "grub.cfg")
            if gval is not None:
                glba, gsize, grec = gval
                g_recs.append((tag, gpath, glba, gsize, grec))
        kernel_end = k_lba * SECT + len(new_kernel)

        try:
            rd_lba, grub_eff_lba = pack_ramdisk(
                data, pvd_tree, kernel_end, iso_size, new_cfg)
        except RuntimeError as e:
            print(f"ERROR: ramdisk: {e}", file=sys.stderr)
            return 1

        if grub_eff_lba is not None:
            off = grub_eff_lba * SECT
            data[off:off + len(new_cfg)] = new_cfg
            for tag, gpath, _, _, grec in g_recs:
                data[grec + 2:grec + 6] = struct.pack('<I', grub_eff_lba)
                data[grec + 10:grec + 14] = struct.pack('<I', len(new_cfg))
            print(f"  grub.cfg: перенесён в конец (LBA {grub_eff_lba}, "
                  f"{len(new_cfg)} байт)")

    # --- контроль: ничьи данные не попали в зону ядра ---
    kernel_start = k_lba * SECT
    kernel_end2 = kernel_start + len(new_kernel)
    for tree, tag in ((pvd_tree, "ISO9660/PVD"), (jol_tree, "Joliet/SVD")):
        if tree is None:
            continue
        for nm, (lba, fsize, rec) in tree.items():
            if nm.rstrip('/').endswith('kernel.bin'):
                continue
            if '/ramdisk/' in nm or nm.rstrip('/').endswith('/ramdisk'):
                continue    # размещается pack_ramdisk ПОСЛЕ ядра по построению
            if nm.rstrip('/').endswith('grub.cfg'):
                if grub_eff_lba is None:
                    continue
                lba, fsize = grub_eff_lba, len(open(grubcfg, 'rb').read())
            if fsize == 0:
                continue
            fs, fe = lba * SECT, lba * SECT + fsize
            if fe > kernel_start and fs < kernel_end2:
                print(f"ERROR: файл {nm} (LBA {lba}) пересекается с зоной ядра "
                      f"[{kernel_start:#x}..{kernel_end2:#x}) — отказ",
                      file=sys.stderr)
                return 1

    # --- выгрузка ---
    with open(iso_out, "wb") as f:
        f.write(data)
    print(f"Готово: {iso_out} ({len(data)} байт)")

    # синхронизировать prebuilt/, чтобы дерево проекта было самосогласовано
    os.makedirs(prebuilt_dir, exist_ok=True)
    if iso_in != iso_out:
        with open(iso_in, "wb") as f:
            f.write(data)
    import shutil
    shutil.copyfile(kernel, os.path.join(prebuilt_dir, "kernel.bin"))
    print(f"Синхронизировано: {iso_out} и prebuilt/kernel.bin")
    return 0


if __name__ == "__main__":
    sys.exit(main())
