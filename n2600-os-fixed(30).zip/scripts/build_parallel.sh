#!/bin/sh
# build_parallel.sh — параллельная сборка kernel.bin (тот же CFLAGS, что
# build.sh, но компиляция через xargs -P). Для песочницы с 2 ядрами:
# амальгамации (mquickjs.c, bearssl.c) — часы последовательной сборки.
set -e
cd "$(dirname "$0")/.."

CC=gcc
CFLAGS="-m32 -mtune=atom -ffreestanding -fno-pic -fno-pie -fno-stack-protector \
-fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe \
-O2 -Wall -Wextra -Isrc"

mkdir -p build

echo "[1/3] Компиляция (параллельно, $(nproc) ядер)..."
ls src/*.c | xargs -P "$(nproc)" -I{} sh -c '
    f="{}"
    b=$(basename "${f%.c}")
    EXTRA=""
    case "$f" in
        */mquickjs.c|*/mquickjs_api.c) EXTRA="-Os" ;;
    esac
    echo "  CC $f"
    gcc -m32 -mtune=atom -ffreestanding -fno-pic -fno-pie -fno-stack-protector \
        -fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe \
        -O2 -Wall -Wextra -Isrc $EXTRA -c "$f" -o "build/$b.o" || {
        echo "FAIL $f" >&2; exit 1; }
'

echo "[2/3] Линковка..."
$CC -m32 -nostdlib -no-pie -Wl,-T,linker.ld -Wl,--image-base=0x100000 \
    -o build/kernel.tmp.exe build/*.o

echo "[3/3] Плоский бинарник..."
objcopy -O binary --only-section=.text build/kernel.tmp.exe kernel.bin

echo "[OK] Готово: kernel.bin ($(stat -c%s kernel.bin) байт)"
