import javax.microedition.midlet.MIDlet;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import java.io.InputStream;

/**
 * v36.34 TestMP3 — E2E verification of minimp3-based MP3 playback:
 * CBR stereo (no tag), ID3v2.3 tag skip, 22 kHz mono + resample, VBR/Xing,
 * the old null-contract for non-MP3 data, infinite looping, and MP3+WAV
 * co-sounding through the shared saturating mixer.
 *
 * Signatures (checked spectrally by analyze_testmp3.py on the audio dump):
 *   P1 t1.mp3 "audio/mpeg"   L=440 R=880   (plain CBR)
 *   P2 t2.mp3 "audio/mp3"    L=550 R=1100  (ID3v2.3 must be skipped)
 *   P3 t3.mp3 null type      660 both      (sniff path, mono 22050)
 *   P4 t4.mp3 "audio/mpeg"   L=330 R=1320  (VBR)
 *   P5 t1.mp3 "audio/aac"    EXPECT NULL (old contract preserved)
 *   P6 t1.mp3 loop=-1        L=440 R=880 for >2.2 s, state stays STARTED
 *   P7 t3.mp3 + tw.wav       660 AND 500 simultaneously
 *
 * Like TestAudio: startApp returns fast; phases run on a worker thread so
 * the audio pump actually runs (libretro pumps from retro_run).
 */
public class TestMP3 extends MIDlet {

    private void phase(String res, String type, String tag) {
        System.out.println(tag + ":BEGIN");
        try {
            InputStream is = getClass().getResourceAsStream(res);
            if (is == null) {
                System.out.println(tag + ":NO-STREAM");
                return;
            }
            Player p = Manager.createPlayer(is, type);
            if (p == null) {
                System.out.println(tag + ":NULL-PLAYER");
                return;
            }
            System.out.println(tag + ":DUR=" + p.getDuration());
            p.start();
            Thread.sleep(900);
            System.out.println(tag + ":STATE=" + p.getState()
                    + " MT=" + p.getMediaTime());
            p.close();
        } catch (Exception e) {
            System.out.println(tag + ":EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}
    }

    private void runPhases() {
        System.out.println("TM:START");

        System.out.println("TM:CAPS " + Manager.getSupportedContentTypes("file")[0]
                + " count=" + Manager.getSupportedContentTypes("file").length);

        phase("/t1.mp3", "audio/mpeg", "TM:P1");
        phase("/t2.mp3", "audio/mp3",  "TM:P2");
        phase("/t3.mp3", null,         "TM:P3");
        phase("/t4.mp3", "audio/mpeg", "TM:P4");

        // P5: negative - declared AAC must keep the null contract
        System.out.println("TM:P5:BEGIN");
        try {
            InputStream is = getClass().getResourceAsStream("/t1.mp3");
            Player p = Manager.createPlayer(is, "audio/aac");
            System.out.println("TM:P5:PLAYER=" + (p == null ? "NULL" : "NONNULL"));
        } catch (Exception e) {
            System.out.println("TM:P5:EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}

        // P6: infinite loop - 1.2 s track must still be STARTED and wrapped
        // back inside [0, duration) after 3 s
        System.out.println("TM:P6:BEGIN");
        try {
            InputStream is = getClass().getResourceAsStream("/t1.mp3");
            Player p = Manager.createPlayer(is, "audio/mpeg");
            if (p == null) {
                System.out.println("TM:P6:NULL-PLAYER");
            } else {
                p.setLoopCount(-1);
                p.start();
                Thread.sleep(3000);
                long mt = p.getMediaTime();
                System.out.println("TM:P6:STATE=" + p.getState() + " MT=" + mt
                        + " DUR=" + p.getDuration());
                p.stop();
                p.close();
            }
        } catch (Exception e) {
            System.out.println("TM:P6:EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}

        // P7: MP3 + WAV at the same time (mixer coexistence, the field
        // report class "одновременно играет только один тип")
        System.out.println("TM:P7:BEGIN");
        try {
            InputStream im = getClass().getResourceAsStream("/t3.mp3");
            InputStream iw = getClass().getResourceAsStream("/tw.wav");
            Player pm = Manager.createPlayer(im, "audio/mpeg");
            Player pw = Manager.createPlayer(iw, "audio/x-wav");
            if (pm != null && pw != null) {
                pm.start();
                pw.start();
                Thread.sleep(1300);
                System.out.println("TM:P7:STATE_MP3=" + pm.getState()
                        + " STATE_WAV=" + pw.getState()
                        + " MT_MP3=" + pm.getMediaTime()
                        + " MT_WAV=" + pw.getMediaTime());
                pm.close();
                pw.close();
            } else {
                System.out.println("TM:P7:NULL-PLAYER m=" + pm + " w=" + pw);
            }
        } catch (Exception e) {
            System.out.println("TM:P7:EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}

        System.out.println("TM:DONE");
        notifyDestroyed();
    }

    public void startApp() {
        Thread t = new Thread(new Runnable() {
            public void run() { runPhases(); }
        });
        t.start();
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}
}
