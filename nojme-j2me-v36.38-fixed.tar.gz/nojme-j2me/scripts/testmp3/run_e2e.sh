#!/bin/bash
# v36.34 TestMP3 E2E — build the suite, run it through the libretro core
# headless (lr_run), verify the midlet markers and analyze the audio dump.
# Usage: bash scripts/testmp3/run_e2e.sh
set -e
D="$(cd "$(dirname "$0")" && pwd)"
ROOT="$D/../.."

echo "== build fixtures + jar =="
bash "$D/build.sh"

OUTDIR=/tmp/testmp3
rm -rf "$OUTDIR"; mkdir -p "$OUTDIR"

echo "== run (lr_run, 900 frames) =="
PACED=1 NOJME_LOG=1 NOJME_AUDIO_DUMP="$OUTDIR/dump.wav" \
  timeout 180 "$ROOT/bin/lr_run" "$ROOT/bin/nojme_libretro.so" \
  games/TestMP3.jar 900 "$OUTDIR" 0 > "$OUTDIR/run.log" 2>&1
rc=$?
echo "lr_run rc=$rc"

echo "== marker checks =="
fail() { echo "FAIL: $1"; exit 1; }
grep -q "TM:DONE" "$OUTDIR/run.log" || fail "midlet did not complete"
grep -q "TM:P5:PLAYER=NULL" "$OUTDIR/run.log" || fail "aac negative contract broken (P5)"
grep -q "TM:P6:STATE=400" "$OUTDIR/run.log" || fail "loop did not stay STARTED (P6)"
echo "markers OK (TM:DONE, P5 NULL, P6 loop STARTED)"

grep -o "TM:P[0-9]:DUR=[0-9-]*" "$OUTDIR/run.log" | head -8
grep -o "TM:P6:STATE=[0-9]* MT=[0-9-]*" "$OUTDIR/run.log"
grep -c "MP3 decoded" "$OUTDIR/run.log" >/dev/null 2>&1 && \
  echo "core log: $(grep -c 'MP3 decoded' "$OUTDIR/run.log") MP3 decoded lines" || true

echo "== spectral analysis of dump =="
python3 "$D/analyze_testmp3.py" "$OUTDIR/dump.wav"
echo "E2E PASSED"
