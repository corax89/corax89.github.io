#!/bin/bash
# Build TestMP3.jar — v36.34 selftest for minimp3-based MP3 playback.
# Class version 48 (no stack maps); only the test classes are packaged —
# the emulator supplies the midlet/lcdui/media classes at runtime.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

[ -f "$D/res/t1.mp3" ] || bash "$D/gen_fixtures.sh"

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestMP3.java" \
    "$D/stubs/javax/microedition/media/"*.java \
    "$D/../testfinish/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TM, , TestMP3\r\nMIDlet-Name: TestMP3\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestMP3*.class "$PKG/"
cp "$D"/res/t1.mp3 "$D"/res/t2.mp3 "$D"/res/t3.mp3 "$D"/res/t4.mp3 "$D"/res/tw.wav "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestMP3.jar" META-INF && zip -q "$D/TestMP3.jar" *.class t1.mp3 t2.mp3 t3.mp3 t4.mp3 tw.wav )

cp "$D/TestMP3.jar" "$D/../../games/TestMP3.jar"
echo "built: $D/TestMP3.jar (installed to games/)"
