/* Standalone check of the mp3_decode_to_wav loop (replicates media.c logic)
 * compile: gcc -O1 -std=c11 -I include t_dec.c -o /tmp/t_dec -lm */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MINIMP3_IMPLEMENTATION
#define MINIMP3_NO_SIMD
#include "minimp3.h"

int main(int argc, char** argv) {
    FILE* f = fopen(argv[1], "rb");
    if (!f) { perror("open"); return 1; }
    fseek(f, 0, SEEK_END); long size = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t* data = malloc(size);
    if (fread(data, 1, size, f) != (size_t)size) return 1;
    fclose(f);
    printf("file %s: %ld bytes, magic ID3? %d\n", argv[1], size,
           size > 3 && !memcmp(data, "ID3", 3));

    uint32_t pos = 0;
    if (size >= 10 && !memcmp(data, "ID3", 3)) {
        uint32_t tag = ((uint32_t)(data[6] & 0x7F) << 21) |
                       ((uint32_t)(data[7] & 0x7F) << 14) |
                       ((uint32_t)(data[8] & 0x7F) << 7) |
                       (uint32_t)(data[9] & 0x7F);
        pos = 10 + tag + ((data[5] & 0x10) ? 10u : 0u);
        printf("ID3 tag=%u -> pos=%u\n", tag, pos);
    }

    mp3dec_t dec; mp3dec_init(&dec);
    size_t cap = 1u << 20, used = 0;
    uint8_t* pcm = malloc(cap);
    int ch = 0, hz = 0, frames = 0, resyncs = 0;
    while (pos < (uint32_t)size) {
        mp3d_sample_t frame[MINIMP3_MAX_SAMPLES_PER_FRAME];
        mp3dec_frame_info_t info; memset(&info, 0, sizeof(info));
        int n = mp3dec_decode_frame(&dec, data + pos, (int)((uint32_t)size - pos), frame, &info);
        if (info.frame_bytes > 0) pos += (uint32_t)info.frame_bytes;
        else { resyncs++; pos++; continue; }
        if (n > 0 && info.channels >= 1 && info.channels <= 2 && info.hz > 0) {
            size_t need = used + (size_t)n * info.channels * 2;
            if (need > cap) { while (cap < need) cap <<= 1; pcm = realloc(pcm, cap); }
            memcpy(pcm + used, frame, (size_t)n * info.channels * 2);
            used += (size_t)n * info.channels * 2;
            ch = info.channels; hz = info.hz; frames++;
        }
    }
    printf("frames=%d ch=%d hz=%d used=%zu resyncs=%d duration_ms=%llu\n",
           frames, ch, hz, used, resyncs,
           (unsigned long long)((used / (ch * 2)) * 1000ull / hz));
    /* amplitude scan */
    short* s = (short*)pcm; size_t ns = used / 2;
    long mx = 0; size_t nz = 0;
    for (size_t i = 0; i < ns; i++) { if (abs(s[i]) > mx) mx = abs(s[i]); if (s[i]) nz++; }
    printf("max amplitude=%ld, nonzero samples=%zu / %zu (%.1f%%)\n",
           mx, nz, ns, 100.0 * nz / ns);
    /* first frame peaks */
    printf("first 32 samples: ");
    for (int i = 0; i < 32; i++) printf("%d ", s[i]);
    printf("\n");
    return (frames > 0 && mx > 1000) ? 0 : 2;
}
