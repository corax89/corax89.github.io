#!/bin/bash
# v36.34 TestMP3 fixtures — generated with ffmpeg (libmp3lame).
# Every fixture has a UNIQUE channel/frequency signature so the spectral
# analyzer can identify each phase in the mixed audio dump:
#   t1.mp3  44.1k stereo 128k CBR, L=440 R=880, 1.2 s, NO ID3   (plain CBR)
#   t2.mp3  44.1k stereo 128k CBR, L=550 R=1100, 1.2 s, ID3v2.3 (tag skip)
#   t3.mp3  22050 mono 64k CBR, 660 Hz, 1.0 s                   (mono+resample)
#   t4.mp3  44.1k stereo VBR q4, L=330 R=1320, 1.1 s            (VBR/Xing)
#   tw.wav  44.1k stereo 16-bit PCM, 500 Hz, 1.0 s              (mix partner)
set -e
D="$(cd "$(dirname "$0")" && pwd)"
cd "$D/res"

# envelope: 50 ms fade in/out to keep the mixer and analysis clean

gen_stereo() { # out Lhz Rhz dur bitrate extra...
    out=$1; lh=$2; rh=$3; dur=$4; br=$5; shift 5
    ffmpeg -y -loglevel error \
        -f lavfi -i "aevalsrc='0.5*sin(2*PI*$lh*t)*min(1\,t*20)*min(1\,max(0\,($dur-t))*20)':d=$dur:s=44100" \
        -f lavfi -i "aevalsrc='0.5*sin(2*PI*$rh*t)*min(1\,t*20)*min(1\,max(0\,($dur-t))*20)':d=$dur:s=44100" \
        -filter_complex "[0:a][1:a]join=inputs=2:channel_layout=stereo[a]" \
        -map "[a]" -c:a libmp3lame -b:a "$br" "$@" "$out"
}

# t1: plain CBR stereo, NO metadata (no ID3 at all)
gen_stereo t1.mp3 440 880 1.2 128k -map_metadata -1 -fflags +bitexact -flags:a +bitexact

# t2: CBR stereo WITH an ID3v2.3 tag (tests the ID3 skip)
gen_stereo t2.mp3 550 1100 1.2 128k -id3v2_version 3 \
    -metadata title="TestMP3 ID3 skip" -metadata artist="nojme"

# t3: low-rate MONO (tests mono decode + fractional resample to 44.1k)
ffmpeg -y -loglevel error \
    -f lavfi -i "aevalsrc='0.5*sin(2*PI*660*t)*min(1\,t*0.05)*min(1\,max(0\,(1.0-t))*20)':d=1.0:s=22050" \
    -map_metadata -1 -c:a libmp3lame -b:a 64k t3.mp3

# t4: VBR (tests the Xing/Info first frame + VBR header sizes)
gen_stereo t4.mp3 330 1320 1.1 128k -map_metadata -1 -q:a 4

# tw.wav: plain PCM WAV partner for the simultaneous-mix phase
ffmpeg -y -loglevel error \
    -f lavfi -i "aevalsrc='0.4*sin(2*PI*500*t)*min(1\,t*0.05)*min(1\,max(0\,(1.0-t))*20)':d=1.0:s=44100" \
    -ac 2 -c:a pcm_s16le -map_metadata -1 tw.wav

ls -la t1.mp3 t2.mp3 t3.mp3 t4.mp3 tw.wav
echo "fixtures generated"
