#!/usr/bin/env python3
"""fontform_bandcheck.py <dump-dir> top|bottom

Восстановлено в v36.32 (хелпер не попал в tarball v36.31 — packaging gap).

Анализирует ПОСЛЕДНИЙ кадр дампа канвы (game_*.ppm, 240x320, P6) построчно
(«чернила» = тёмные пиксели < 128) и проверяет вид длинной Form:

  top    — вид = ВЕРХ документа: полоса y25..32 ПЛОТНАЯ (там лежит строка
           TOPMARK; при прокрутке в этом месте будут хвосты абзацев с
           межстрочными пустыми рядами — полоса рыхлая).
           Порог: >=5 из 8 рядов с ink>=8 и суммарно >=120 тёмных пикселей.

  bottom — вид = НИЗ документа: в зоне y190..285 есть ПРОБЕЛ >=45 рядов
           подряд (Spacer(60) перед ENDMARKER) и НИЖЕ пробела есть чернила
           (ENDMARKER). Сверху документа такой длинной пустой зоны нет
           (абзацы идут до y288, ниже — скроллбар на y292).
"""
import glob
import sys


def load_last_ppm(dump_dir):
    files = sorted(glob.glob(dump_dir.rstrip('/') + '/game_*.ppm'))
    if not files:
        sys.exit(2)
    with open(files[-1], 'rb') as f:
        data = f.read()
    # P6: "P6\n<W> <H>\n255\n<raw>"
    if not data.startswith(b'P6'):
        sys.exit(2)
    nl1 = data.index(b'\n')
    nl2 = data.index(b'\n', nl1 + 1)
    w, h = map(int, data[nl1 + 1:nl2].split())
    nl3 = data.index(b'\n', nl2 + 1)
    pix = data[nl3 + 1:]
    if len(pix) < w * h * 3:
        sys.exit(2)
    return w, h, pix


def row_ink(w, h, pix, thresh=128):
    rows = []
    for y in range(h):
        row = pix[y * w * 3:(y + 1) * w * 3]
        dark = 0
        for i in range(0, len(row), 3):
            if row[i] < thresh:  # красный канал достаточен для ч/б текста
                dark += 1
        rows.append(dark)
    return rows


def check_top(rows):
    band = rows[25:33]  # y25..32 включительно
    dense = sum(1 for v in band if v >= 8)
    total = sum(band)
    return dense >= 5 and total >= 120


def check_bottom(rows):
    h = len(rows)
    lo, hi = 190, min(285, h - 1)
    run = 0
    best_start = -1
    best_len = 0
    for y in range(lo, hi + 1):
        if rows[y] == 0:
            if run == 0:
                start = y
            run += 1
            if run > best_len:
                best_len = run
                best_start = start
        else:
            run = 0
    if best_len < 45 or best_start < 0:
        return False
    end = best_start + best_len
    below = [v for v in rows[end:min(end + 30, h)] if v > 0]
    return len(below) >= 2


def main():
    if len(sys.argv) != 3 or sys.argv[2] not in ('top', 'bottom'):
        print(__doc__)
        sys.exit(2)
    w, h, pix = load_last_ppm(sys.argv[1])
    rows = row_ink(w, h, pix)
    ok = check_top(rows) if sys.argv[2] == 'top' else check_bottom(rows)
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
