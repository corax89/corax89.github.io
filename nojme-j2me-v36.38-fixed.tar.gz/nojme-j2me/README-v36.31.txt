NOJME v36.31 — [EXIT-FENCE-EXT] + [EXIT-DOUBLE-DELIVERY] + [RMS-FLUSH-LOCK]
+ ОТКРЫТЫЙ ТЕСТ-СЬЮТ MICROEMULATOR
Nintendo Switch (NRO / hbloader) — J2ME/MIDP эмулятор
Program ID: 010062B01525C000

ЧТО СДЕЛАНО (по вашему отчёту:
«Все еще есть проблемы при выходе из некоторых игр (особенно если выход
был с ошибкой) эмулятор пишет |E| Cpu InvalidAccessHandler: Invalid memory
access at virtual address 0x745364726F636572» + просьба «поискать различные
тесты для j2me которые есть в открытом доступе и провести на них
тестирование»):

0) ДЕКОДИРОВКА АДРЕСА ПАДЕНИЯ
   0x745364726F636572 — это текст "recordSt" (8 байт little-endian):
   начало строки "recordStore...". Такой литерал в коде NOJME отсутствует —
   строка лежала в памяти, принадлежавшей Java-куче игры (имя RecordStore
   или обфусцированного класса). Вывод: указатель прочитан из уже
   освобождённого и переиспользованного блока — use-after-free на пути
   выхода. Воспроизвести на хосте (ASAN + симуляция медленной SD) не
   удалось, поэтому в v36.31 закрыты ДОКАЗАННЫЕ окна этого класса и
   добавлена диагностика, которая при рецидиве назовёт виновника.

1) [EXIT-FENCE-EXT] ФЕНС ТЕПЕРЬ ДЕРЖИТ РАННЕРЫ ВСЁ ВРЕМЯ destroyApp
   Доказанное окно: фенс v36.30 ограничен 2.5 с, а RMS-флеш на медленной
   SD стоит 100-800 мс на стор — destroyApp с несколькими сохранениями
   выходит за кап, и раннеры возвращаются в кучу СЕРЕДИНЫ destroyApp
   (гонка «два интерпретатора»). Теперь пока destroyApp исполняется,
   кап продлевается (до 15 с), досрочный release — только по
   kill-переключателю. Проверено на хосте с симуляцией SD: раньше
   «[FENCE] held >2.5s - proceeding» на каждом выходе, теперь —
   «[FENCE] 2.5s cap during destroyApp — extending runner hold».

2) [EXIT-DOUBLE-DELIVERY] ПОВТОРНЫЙ destroyApp БОЛЬШЕ НЕ ВЫЗЫВАЕТСЯ
   Если мидлет сам вышел (свой EXIT-командой), а затем выход выполнен из
   меню паузы / quit / stuck-recovery — destroyApp раньше исполнялся
   ВТОРОЙ раз (сейв-код дважды, второй раз с исключениями на закрытых
   RMS/стримах — ваш класс «выход с ошибкой»). Теперь второй вызов
   отсекается: «[MIDLET] destroyApp skipped (midlet already destroyed)».

3) [RMS-FLUSH-LOCK] + ДИАГНОСТИКА МЕДЛЕННОЙ SD
   - Флеш грязных сторов теперь под RMS-блокировкой (раньше обходил и
     писал без замка, пока раннер мог мутировать тот же стор).
   - Новая постоянная строка лога: «[RMS-SLOW] dirty flush of store N
     took X ms» при флеше >300 мс — полевое доказательство медленной SD,
     растягивающей destroyApp за кап фенса. Пришлите лог с этой строкой,
     если вылет повторится.

4) ОТКРЫТЫЙ ТЕСТ-СЬЮТ J2ME — НАЙДЕН, СОБРАН, ПРОГНАН
   Использован org.microemu.tests из MicroEmulator 2.0.4 — единственный
   полноценный ОТКРЫТЫЙ тест-сьют J2ME (LGPL2.1/Apache2):
   - ErrorHandlingForm/Canvas: намеренные НЕПЕРЕХВАЧЕННЫЕ исключения в
     commandAction/keyPressed/paint (контракт: «Emulator Should still
     work»);
   - RecordStoreForm: полный цикл RMS (store/load/list/delete);
   - ThreadTestsForm: runaway Thread + runaway java.util.Timer;
   - ItemsOnForm, PreporcessorTestCanvas, OverrideNewJSR (классы).
   В пакете: scripts/meTests/ (исходники, стабы, build.sh,
   MicroEmuTests.jar + MicroEmuTestsAuto.jar с драйвером) и новый
   автотест scripts/test_switch_metests.sh.
   РЕЗУЛЬТАТ НА NOJME: сьют проходит ВСЕ свои сценарии — неперехваченное
   исключение корректно разматывается и НЕ роняет эмулятор, runaway
   thread живёт до самого teardown, двойная доставка destroyApp
   переживается, выходы/релаунчи чистые. Отдельно games/TestRMS.jar
   (20+ проверок RMS) — ALL PASS. Полный регресс (20+ тестов) — ALL
   PASSED, ASAN-прогоны чистые.
   Чего НЕ удалось: воспроизвести ваш адрес 0x745364726F636572 на хосте.
   Поэтому в лог добавлены самоназывающиеся строки ([RMS-SLOW],
   [FENCE] extending, [JVM-DESTROY]) — при рецидиве пришлите лог
   (log.txt из /switch/j2me/), они укажут точное окно.

УСТАНОВКА:
1. Пересоберите nojme.nro из исходников (README-СБОРКА.txt) и положите
   в sdmc:/switch/j2me/ как обычно. В банере лога должно быть
   «nojme v36.31-2026-09-26».
2. Тест-сьют: скопируйте scripts/meTests/MicroEmuTestsAuto.jar в
   sdmc:/switch/j2me/games/ — он сам прогонит все сценарии и напечатает
   [AUTO]-строки; MicroEmuTests.jar — интерактивное меню сьютов.

СОСТАВ ПАКЕТА:
- исходники (src/, include/, Makefile) — CORE_BUILD_ID v36.31-2026-09-26
- games/              — тестовые jar'ы (включая meTests)
- scripts/            — тестовая обвязка (meTests — новый)
- FIXES.txt           — полный changelog (СЕССИЯ 74)
