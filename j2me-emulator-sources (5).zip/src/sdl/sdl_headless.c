/*
 * Headless SDL Backend for Testing
 * No display, no audio - just executes bytecode
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/time.h>
#include <unistd.h>

#define LIBRETRO  /* Use stubs */
#include "sdl_backend.h"
#include "midp.h"

/* Global context */
static SdlContext g_headless_ctx = {0};

SdlContext* sdl_get_global_context(void) { return &g_headless_ctx; }

void sdl_set_global_context(SdlContext* ctx) {
    if (ctx) g_headless_ctx = *ctx;
    else memset(&g_headless_ctx, 0, sizeof(SdlContext));
}

int sdl_init(JVM* jvm, int width, int height, int scale, bool headless) {
    (void)scale; (void)headless;
    
    if (width <= 0) width = 240;
    if (height <= 0) height = 320;
    
    g_headless_ctx.jvm = jvm;
    g_headless_ctx.width = width;
    g_headless_ctx.height = height;
    g_headless_ctx.scale = 1;
    g_headless_ctx.target_fps = 30;
    g_headless_ctx.running = true;
    g_headless_ctx.headless = true;
    
    /* Allocate framebuffer */
    g_headless_ctx.framebuffer = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    if (!g_headless_ctx.framebuffer) {
        fprintf(stderr, "[Headless] Failed to allocate framebuffer\n");
        return -1;
    }
    
    fprintf(stderr, "[Headless] Initialized %dx%d\n", width, height);
    return 0;
}

void sdl_destroy(SdlContext* ctx) {
    if (ctx && ctx->framebuffer) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
    }
}

void sdl_run(SdlContext* ctx) {
    if (!ctx) return;
    
    /* In headless mode, just wait for MIDlet to finish */
    fprintf(stderr, "[Headless] Running headless mode (waiting for MIDlet)...\n");
    
    int frames = 0;
    int max_frames = 60000; /* Safety limit - 10 minutes at 10ms per iteration */
    
    while (ctx->running && frames < max_frames) {
        frames++;
        usleep(10000); /* 10ms per iteration */
        
        /* Process repaints in headless mode */
        sdl_process_events_minimal();
        
        /* Check if MIDlet is still running */
        if (ctx->jvm && !ctx->jvm->running) {
            fprintf(stderr, "[Headless] JVM stopped after %d iterations\n", frames);
            break;
        }
    }
    
    if (frames >= max_frames) {
        fprintf(stderr, "[Headless] Reached max iterations\n");
    }
    
    fprintf(stderr, "[Headless] Finished\n");
}

void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) { (void)ctx; (void)fullscreen; }
uint64_t sdl_get_ticks(SdlContext* ctx) { (void)ctx; return 0; }
void sdl_delay(uint32_t ms) { usleep(ms * 1000); }

void sdl_update_screen(SdlContext* ctx) { (void)ctx; }
void sdl_handle_events(SdlContext* ctx) { (void)ctx; }

bool sdl_key_pressed(SdlContext* ctx, int key) { (void)ctx; (void)key; return false; }
MidpGraphics* sdl_get_graphics(SdlContext* ctx) { (void)ctx; return NULL; }

int sdl_audio_init_simple(uint32_t sample_rate) { (void)sample_rate; return 0; }
void sdl_audio_shutdown(void) {}
void sdl_audio_queue_samples(const int16_t* samples, size_t count) { (void)samples; (void)count; }
size_t sdl_audio_get_queued_size(void) { return 0; }

void sdl_present(SdlContext* ctx) { (void)ctx; }

/* Headless mode needs to process repaints */
static bool g_headless_needs_redraw = false;

void sdl_request_redraw(void) {
    g_headless_needs_redraw = true;
}

bool sdl_needs_redraw(SdlContext* ctx) { 
    (void)ctx; 
    return g_headless_needs_redraw; 
}

void sdl_clear_redraw(SdlContext* ctx) { 
    (void)ctx; 
    g_headless_needs_redraw = false; 
}

void sdl_process_events_minimal(void) {
    /* Process any pending repaints */
    extern void midp_process_repaints(JVM* jvm);
    if (g_headless_needs_redraw && g_headless_ctx.jvm) {
        midp_process_repaints(g_headless_ctx.jvm);
        g_headless_needs_redraw = false;
    }
}

void sdl_update_texture(SdlContext* ctx) { (void)ctx; }

void sdl_clear(SdlContext* ctx, uint32_t color) {
    if (!ctx || !ctx->framebuffer) return;
    for (int i = 0; i < ctx->width * ctx->height; i++)
        ctx->framebuffer[i] = color;
}

int sdl_resize(SdlContext* ctx, int width, int height) { (void)ctx; (void)width; (void)height; return 0; }
int sdl_screenshot(SdlContext* ctx, const char* filename) { (void)ctx; (void)filename; return -1; }
void sdl_frame_end(SdlContext* ctx) { (void)ctx; }
void sdl_sleep(uint32_t ms) { usleep(ms * 1000); }
void sdl_set_title(SdlContext* ctx, const char* title) { (void)ctx; (void)title; }
void sdl_toggle_fullscreen(SdlContext* ctx) { (void)ctx; }
void sdl_get_window_size(SdlContext* ctx, int* width, int* height) {
    if (width && ctx) *width = ctx->width;
    if (height && ctx) *height = ctx->height;
}
void sdl_stop(SdlContext* ctx) { if (ctx) ctx->running = false; }
MidpPlatformCallbacks* sdl_get_platform_callbacks(SdlContext* ctx) { (void)ctx; return NULL; }
bool sdl_is_screen_graphics(MidpGraphics* gfx) { (void)gfx; return true; }

int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
    (void)ctx; (void)frequency; (void)channels; (void)samples;
    return 0;
}

int sdl_audio_queue(SdlContext* ctx, const void* data, size_t length) {
    (void)ctx; (void)data; (void)length;
    return 0;
}

uint32_t sdl_audio_queued_size(SdlContext* ctx) { (void)ctx; return 0; }
void sdl_audio_clear(SdlContext* ctx) { (void)ctx; }
void sdl_process_events(SdlContext* ctx) { (void)ctx; }
int sdl_key_to_midp(int sdl_key) { (void)sdl_key; return 0; }
int sdl_key_to_game_action(int sdl_key) { (void)sdl_key; return 0; }
void sdl_get_pointer(SdlContext* ctx, int* x, int* y) { if (x) *x = 0; if (y) *y = 0; (void)ctx; }
bool sdl_pointer_pressed(SdlContext* ctx) { (void)ctx; return false; }
void sdl_dump_info(SdlContext* ctx) { (void)ctx; }
void sdl_save_framebuffer_to_file(SdlContext* ctx, const char* filename) { (void)ctx; (void)filename; }

/* JAR resource loading - provided by main.c */
extern uint8_t* load_jar_resource(const char* path, size_t* size);
