int g_j2me_runtime_debug = 0;
