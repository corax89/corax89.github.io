/*
 * J2ME Emulator - DRM Bypass System
 * Based on KEmulator analysis
 * 
 * This module implements various DRM/protection bypass mechanisms
 * similar to those found in KEmulator:
 * 
 * 1. hideEmulation - hide emulator presence
 * 2. IMEI spoofing - fake device identifiers  
 * 3. checkPermission bypass - always return "allowed"
 * 4. Platform spoofing - fake device model
 */

#ifndef DRM_BYPASS_H
#define DRM_BYPASS_H

#include <stdbool.h>
#include <stdint.h>

/* Global DRM bypass configuration */
typedef struct {
    /* Hide emulator presence (like KEmulator's hideEmulation) */
    bool hide_emulation;
    
    /* Spoof device identifiers */
    char imei[16];           /* 15-digit IMEI + null */
    char imsi[16];           /* IMSI */
    char platform[64];       /* microedition.platform */
    char device_model[32];   /* Device model name */
    
    /* Permission bypass */
    bool bypass_permissions; /* Always return "allowed" for checkPermission */
    
    /* Vserv/ALW1 bypass */
    bool bypass_vserv;
    
    /* Debug */
    bool debug_drm;
} DrmBypassConfig;

/* Global configuration instance */
extern DrmBypassConfig g_drm_bypass;

/* Initialize DRM bypass with defaults */
void drm_bypass_init(void);

/* Load DRM bypass config from file */
void drm_bypass_load_config(const char* filename);

/* 
 * Check if property should be hidden (hideEmulation mode)
 * Returns true if property should return null
 */
bool drm_should_hide_property(const char* key);

/*
 * Get spoofed device property
 * Returns value if property is spoofed, NULL otherwise
 */
const char* drm_get_spoofed_property(const char* key);

/*
 * Check if class should be hidden from application
 * Used to hide emulator-specific classes
 */
bool drm_should_hide_class(const char* class_name);

/*
 * Get spoofed IMEI
 */
const char* drm_get_imei(void);

/*
 * Check permission - always returns allowed if bypass enabled
 * Returns: 1 = allowed, 0 = denied, -1 = unknown
 */
int drm_check_permission(const char* permission);

#endif /* DRM_BYPASS_H */
