/*
 * J2ME Emulator - JSR 184 Mobile 3D Graphics API - VertexBuffer and Rendering Patch
 * 
 * This adds:
 * - VertexBuffer class support
 * - Real 3D mesh rendering in renderWorld
 * - M3G file format parsing improvements
 */

/* Add to stub classes array: */
/* { "javax/microedition/m3g/VertexBuffer", "java/lang/Object", 1 }, */

/* ============================================================================
 * VertexBuffer Native Methods
 * ============================================================================ */

/* VertexBuffer.<init>() */
static JavaValue native_vertexbuffer_init(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_int_field(obj, "vertexCount", 0);
    m3g_set_ref_field(obj, "positions", NULL);
    m3g_set_ref_field(obj, "normals", NULL);
    m3g_set_ref_field(obj, "texCoords", NULL);
    m3g_set_ref_field(obj, "colors", NULL);
    m3g_set_float_field(obj, "positionScale", 1.0f);
    m3g_set_float_field(obj, "normalScale", 1.0f);
    
    GFX_DEBUG("VertexBuffer.<init>");
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setPositions(VertexArray positions, float scale, float[] bias) */
static JavaValue native_vertexbuffer_setPositions(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* positions = (JavaObject*)args[1].ref;
    float scale = args[2].f;
    JavaArray* bias = (JavaArray*)args[3].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "positions", positions);
    m3g_set_float_field(obj, "positionScale", scale);
    
    if (positions) {
        int count = m3g_get_int_field(positions, "vertexCount", 0);
        m3g_set_int_field(obj, "vertexCount", count);
    }
    
    if (bias && bias->element_type == T_FLOAT && bias->length >= 3) {
        float* bias_data = (float*)array_data(bias);
        m3g_set_float_field(obj, "biasX", bias_data[0]);
        m3g_set_float_field(obj, "biasY", bias_data[1]);
        m3g_set_float_field(obj, "biasZ", bias_data[2]);
    }
    
    GFX_DEBUG("VertexBuffer.setPositions: scale=%.2f", scale);
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setNormals(VertexArray normals) */
static JavaValue native_vertexbuffer_setNormals(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* normals = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "normals", normals);
    
    GFX_DEBUG("VertexBuffer.setNormals");
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setTexCoords(int index, VertexArray texCoords, float scale, float[] bias) */
static JavaValue native_vertexbuffer_setTexCoords(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* texCoords = (JavaObject*)args[2].ref;
    float scale = args[3].f;
    JavaArray* bias = (JavaArray*)args[4].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    if (index == 0) {
        m3g_set_ref_field(obj, "texCoords", texCoords);
        m3g_set_float_field(obj, "texCoordScale", scale);
    }
    
    GFX_DEBUG("VertexBuffer.setTexCoords: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setColors(VertexArray colors) */
static JavaValue native_vertexbuffer_setColors(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* colors = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "colors", colors);
    
    GFX_DEBUG("VertexBuffer.setColors");
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Helper: Render a single mesh
 * ============================================================================ */

static void m3g_render_mesh(JavaObject* mesh, M3GTransform* modelview) {
    if (!mesh) return;
    
    /* Get vertex buffer and index buffer */
    JavaObject* vertexBuffer = m3g_get_ref_field(mesh, "vertexBuffer");
    JavaObject* indexBuffer = m3g_get_ref_field(mesh, "indexBuffer");
    JavaObject* appearance = m3g_get_ref_field(mesh, "appearance");
    
    if (!vertexBuffer || !indexBuffer) return;
    
    /* Get position array */
    JavaObject* positions = m3g_get_ref_field(vertexBuffer, "positions");
    if (!positions) return;
    
    int vertex_count = m3g_get_int_field(positions, "vertexCount", 0);
    int component_count = m3g_get_int_field(positions, "componentCount", 3);
    int component_size = m3g_get_int_field(positions, "componentSize", 1);
    float pos_scale = m3g_get_float_field(vertexBuffer, "positionScale", 1.0f);
    
    JavaArray* pos_data = (JavaArray*)m3g_get_ref_field(positions, "data");
    if (!pos_data || vertex_count == 0) return;
    
    /* Get index data */
    int index_count = m3g_get_int_field(indexBuffer, "indexCount", 0);
    JavaArray* idx_data = (JavaArray*)m3g_get_ref_field(indexBuffer, "indices");
    if (!idx_data || index_count == 0) return;
    
    GFX_DEBUG("render_mesh: %d vertices, %d indices", vertex_count, index_count);
    
    /* Convert positions to float */
    float* vertices = (float*)malloc(vertex_count * 3 * sizeof(float));
    if (!vertices) return;
    
    if (component_size == 1) {
        int8_t* src = (int8_t*)array_data(pos_data);
        for (int i = 0; i < vertex_count * component_count && i < (int)pos_data->length; i++) {
            vertices[i] = (float)src[i] * pos_scale;
        }
    } else {
        int16_t* src = (int16_t*)array_data(pos_data);
        for (int i = 0; i < vertex_count * component_count && i < (int)pos_data->length; i++) {
            vertices[i] = (float)src[i] * pos_scale;
        }
    }
    
    /* Build MVP matrix */
    M3GTransform mvp;
    m3g_transform_multiply(&mvp, modelview, &g_m3g.projection);
    
    /* Get indices */
    uint16_t* indices = NULL;
    int need_free_indices = 0;
    
    if (idx_data->element_type == T_INT) {
        jint* src = (jint*)array_data(idx_data);
        indices = (uint16_t*)malloc(index_count * sizeof(uint16_t));
        need_free_indices = 1;
        for (int i = 0; i < index_count; i++) {
            indices[i] = (uint16_t)src[i];
        }
    } else if (idx_data->element_type == T_SHORT) {
        indices = (uint16_t*)array_data(idx_data);
    }
    
    if (!indices) {
        free(vertices);
        return;
    }
    
    /* Render triangles */
    for (int t = 0; t + 2 < index_count; t += 3) {
        float v0[4], v1[4], v2[4];
        float clip0[4], clip1[4], clip2[4];
        
        int i0 = indices[t] * component_count;
        int i1 = indices[t+1] * component_count;
        int i2 = indices[t+2] * component_count;
        
        if (component_count >= 3 && 
            i0 + 2 < vertex_count * component_count &&
            i1 + 2 < vertex_count * component_count &&
            i2 + 2 < vertex_count * component_count) {
            
            v0[0] = vertices[i0]; v0[1] = vertices[i0+1]; v0[2] = vertices[i0+2]; v0[3] = 1.0f;
            v1[0] = vertices[i1]; v1[1] = vertices[i1+1]; v1[2] = vertices[i1+2]; v1[3] = 1.0f;
            v2[0] = vertices[i2]; v2[1] = vertices[i2+1]; v2[2] = vertices[i2+2]; v2[3] = 1.0f;
            
            m3g_transform_point(clip0, &mvp, v0);
            m3g_transform_point(clip1, &mvp, v1);
            m3g_transform_point(clip2, &mvp, v2);
            
            /* Default color */
            uint8_t color[4] = {200, 200, 200, 255};
            
            m3g_rasterize_triangle(clip0, clip1, clip2,
                                   NULL, NULL, NULL,
                                   color, color, color, NULL);
        }
    }
    
    if (need_free_indices) free(indices);
    free(vertices);
}

/* ============================================================================
 * Helper: Traverse scene graph and render
 * ============================================================================ */

static void m3g_traverse_and_render(JavaObject* node, M3GTransform* transform) {
    if (!node) return;
    
    JavaClass* clazz = node->header.clazz;
    if (!clazz || !clazz->class_name) return;
    
    /* Check node type */
    if (strstr(clazz->class_name, "Mesh")) {
        m3g_render_mesh(node, transform);
    }
    
    /* If it's a Group/World, recurse into children */
    if (strstr(clazz->class_name, "Group") || strstr(clazz->class_name, "World")) {
        JavaArray* children = (JavaArray*)m3g_get_ref_field(node, "children");
        if (children && children->element_type == DESC_OBJECT) {
            JavaObject** child_arr = (JavaObject**)array_data(children);
            for (jsize i = 0; i < children->length; i++) {
                if (child_arr[i]) {
                    m3g_traverse_and_render(child_arr[i], transform);
                }
            }
        }
    }
}

/* ============================================================================
 * Improved renderWorld Implementation
 * ============================================================================ */

/* Replace the existing renderWorld implementation with this */

static JavaValue native_graphics3d_renderWorld_fixed(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* world = (JavaObject*)args[1].ref;
    (void)g3d;
    
    GFX_DEBUG("renderWorld: world=%p", (void*)world);
    
    g_m3g.triangles_rendered = 0;
    
    if (!world) return NATIVE_RETURN_VOID();
    
    /* Clear with background */
    JavaObject* background = m3g_get_ref_field(world, "background");
    float r = 0.0f, g = 0.0f, b = 0.0f, a = 1.0f;
    
    if (background) {
        int argb = m3g_get_int_field(background, "clearColor", 0xFF000000);
        a = ((argb >> 24) & 0xFF) / 255.0f;
        r = ((argb >> 16) & 0xFF) / 255.0f;
        g = ((argb >> 8) & 0xFF) / 255.0f;
        b = (argb & 0xFF) / 255.0f;
    }
    
    m3g_clear(r, g, b, a, 1.0f);
    
    /* Set up camera */
    JavaObject* camera = m3g_get_ref_field(world, "activeCamera");
    if (camera) {
        float fov = m3g_get_float_field(camera, "fov", 60.0f);
        float aspect = m3g_get_float_field(camera, "aspect", 
                     (float)g_m3g.viewport_width / g_m3g.viewport_height);
        float near = m3g_get_float_field(camera, "near", 1.0f);
        float far = m3g_get_float_field(camera, "far", 1000.0f);
        
        m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
    }
    
    /* Reset modelview */
    m3g_transform_identity(&g_m3g.modelview);
    
    /* Render all nodes in the scene graph */
    if (g_m3g.color_buffer && g_m3g.buffer_width > 0) {
        m3g_traverse_and_render(world, &g_m3g.modelview);
    }
    
    GFX_DEBUG("renderWorld: rendered %d triangles", g_m3g.triangles_rendered);
    
    return NATIVE_RETURN_VOID();
}

/* Native method registration entries to add:

        // VertexBuffer
        {"javax/microedition/m3g/VertexBuffer", "<init>", "()V", native_vertexbuffer_init},
        {"javax/microedition/m3g/VertexBuffer", "setPositions", "(Ljavax/microedition/m3g/VertexArray;F[F)V", native_vertexbuffer_setPositions},
        {"javax/microedition/m3g/VertexBuffer", "setNormals", "(Ljavax/microedition/m3g/VertexArray;)V", native_vertexbuffer_setNormals},
        {"javax/microedition/m3g/VertexBuffer", "setTexCoords", "(ILjavax/microedition/m3g/VertexArray;F[F)V", native_vertexbuffer_setTexCoords},
        {"javax/microedition/m3g/VertexBuffer", "setColors", "(Ljavax/microedition/m3g/VertexArray;)V", native_vertexbuffer_setColors},

*/
