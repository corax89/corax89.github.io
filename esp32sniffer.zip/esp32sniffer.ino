/*
 * =====================================================================
 *  ESP32 AP RATE TESTER v7
 *  =====================================================================
 *  ESP32 работает как SoftAP (генерация ACK аппаратная), в режиме
 *  promiscuous ловит кадры клиента, а по команде 't' автоматически
 *  прогоняет цикл:
 *
 *    для rate in {1M, 6M, 24M, 54M}:
 *      deauth всех клиентов
 *      esp_wifi_internal_set_fix_rate(WIFI_IF_AP, rate)
 *      ждём 15 с переподключения клиента (WiFi event STACONNECTED)
 *      фиксируем: успех/провал, время до connect, на каком этапе
 *                  умер handshake (probe/auth/assoc/eapol)
 *      лог + сводная таблица
 *
 *  Диагноз на каждом rate:
 *    - много AUTH-REQ от клиента, но connect не случился
 *        → AUTH-RESP на 54M не декодируется клиентом (SNR)
 *    - connect OK, но M2→M4 нет
 *        → M3 (54M) не декодируется
 *    - всё OK
 *        → rate рабочий
 *
 *  Проверки [W-PHYERR] и rate= в каждой строке — как в v5/v6.
 *
 *  КОМАНДЫ:
 *    h  справка          t  запустить полный авто-тест
 *    s  сводка STA       c  конфиг           r  сброс
 *    p  pcap-hex         x  hex в логе       b  BEACON
 *    d  verbose rx_state
 *    q  тихий режим (не дампить все кадры)
 * =====================================================================
 */

#include <Arduino.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_wifi_internal.h>
#include <stdint.h>

// ==================== КОНФИГ AP ====================
#define AP_SSID       "esp32test"
#define AP_PASS       "12341234"        // >=8 символов
#define AP_CHANNEL    6
#define AP_MAX_STA    4
#define AP_HIDDEN     0

#define SERIAL_BAUD   115200
#define PROBE_RL_MS   500
#define CONNECT_TIMEOUT_MS  15000       // сколько ждём переподключения
#define DISC_TIMEOUT_MS     3000        // сколько ждём отключения после deauth
#define BETWEEN_TESTS_MS    2000        // пауза между rate-тестами

// ==================== РАЗМЕРЫ ====================
#define RB_SLOTS      48
#define RB_CAP        512
#define MAX_STA       8
#define MAX_STA_TRACK 12
#define PRL_SLOTS     8

// ==================== ТИПЫ ====================
struct PktRec {
  uint16_t len, olen;
  int8_t   rssi;
  uint8_t  ptype;            // 0=MGMT 1=CTRL 2=DATA 3=PHYERR
  uint8_t  rate;
  uint8_t  rxState;
  uint32_t tms, tus;
  uint8_t  data[RB_CAP];
};

struct IEs {
  char     ssid[33];
  int      dsChan;
  bool     rsn, wpa1, wps, ht40, vht;
  uint16_t htCap;
};

struct RsnInfo {
  bool     present;
  uint8_t  gOUI[3], gType;
  int      pCount; uint8_t pOUI[4][3], pType[4];
  int      aCount; uint8_t aOUI[4][3], aType[4];
  bool     hasCaps; uint16_t caps;
  bool     hasMgmtCipher; uint8_t mgOUI[3], mgType;
};

enum StaStage : uint8_t {
  ST_NONE=0, ST_PROBED=1, ST_AUTH_SENT=2, ST_AUTH_OK=3,
  ST_ASSOC_SENT=4, ST_ASSOC_OK=5, ST_M1=6, ST_M2=7,
  ST_M3=8, ST_M4=9, ST_DHCP=10, ST_CONNECTED=11,
  ST_DEAUTH=12, ST_DISASSOC=13, ST_FAILED=14
};

struct StaInfo {
  uint8_t  mac[6];
  bool     inUse;
  uint32_t firstSeen, lastSeen;
  uint16_t probeOur, probeEmpty, probeOther;
  uint16_t authReq, authResp, authOk;
  uint16_t authLastStatus;
  uint16_t assocReq, assocResp, assocOk;
  uint16_t assocLastStatus;
  uint16_t m1, m2, m3, m4;
  uint16_t eapolGtk;
  uint16_t handshakeRetries;
  uint16_t dhcpDisc, dhcpReq, dhcpAck;
  bool     dhcpOk;
  uint16_t deauth, disassoc;
  uint16_t dataFrom, dataTo, retries, acks;
  uint32_t connectAt;
  uint8_t  stage;
};

// ==================== RATE TEST ====================
struct RateTest {
  const char*   name;
  wifi_phy_rate_t value;
};
static const RateTest rateTests[] = {
  {"1 Mbps",  WIFI_PHY_RATE_1M_L},
  {"6 Mbps",  WIFI_PHY_RATE_6M},
  {"24 Mbps", WIFI_PHY_RATE_24M},
  {"54 Mbps", WIFI_PHY_RATE_54M},
};
#define RATE_TEST_COUNT ((int)(sizeof(rateTests)/sizeof(rateTests[0])))

struct TestResult {
  bool     attempted;
  bool     success;
  uint32_t connectMs;
  uint16_t authReqCount;     // из sniffed кадров
  uint16_t assocReqCount;
  uint16_t m2Count;
  uint16_t m4Count;
  uint16_t dataCount;
  uint8_t  failStage;        // ST_* на котором застряли
};
static TestResult testResults[RATE_TEST_COUNT];

enum TestPhase {
  TP_IDLE,
  TP_DEAUTH,
  TP_WAIT_DISC,
  TP_SET_RATE,
  TP_WAIT_CONNECT,
  TP_RECORD,
  TP_BETWEEN,
  TP_DONE
};
static TestPhase testPhase = TP_IDLE;
static int        testRateIdx = 0;
static uint32_t   testPhaseStart = 0;
static bool       testAutoQuiet = false;   // приглушаем дамп кадров во время теста

// ==================== ГЛОБАЛ ====================
static PktRec            rb[RB_SLOTS];
static volatile uint16_t rbHead=0, rbTail=0;
static volatile uint32_t rbDrops=0;

static uint8_t  apMac[6] = {0,0,0,0,0,0};
static uint8_t  staMacs[MAX_STA][6];
static int      staCnt = 0;
static StaInfo  staInfo[MAX_STA_TRACK];
static int      staInfoCnt = 0;

static bool     dumpHexOn = false;
static bool     dumpBeacons = false;
static bool     verboseRx = false;
static bool     quietMode = false;
static bool     clientConnected = false;
static volatile uint32_t connectTimestamp = 0;
static volatile uint32_t disconnectTimestamp = 0;
static volatile bool     staGotIp = false;

static uint8_t  prlMac[PRL_SLOTS][6];
static uint32_t prlMs[PRL_SLOTS];
static int      prlCnt = 0;

static const uint8_t WPA_OUI[3] = {0x00,0x50,0xF2};

// ==================== УТИЛИТЫ ====================
static inline uint16_t le16(const uint8_t*p){return(uint16_t)p[0]|((uint16_t)p[1]<<8);}
static inline uint16_t be16(const uint8_t*p){return((uint16_t)p[0]<<8)|(uint16_t)p[1];}
static inline bool isMcast(const uint8_t*m){return(m[0]&0x01)!=0;}
static void mac2str(const uint8_t*m,char*o){sprintf(o,"%02X:%02X:%02X:%02X:%02X:%02X",m[0],m[1],m[2],m[3],m[4],m[5]);}
static void ip2str(uint32_t ip,char*o){sprintf(o,"%u.%u.%u.%u",(unsigned)(ip>>24)&0xFF,(unsigned)(ip>>16)&0xFF,(unsigned)(ip>>8)&0xFF,(unsigned)ip&0xFF);}

static bool isKnown(const uint8_t*m){
  if(memcmp(m,apMac,6)==0)return true;
  for(int i=0;i<staCnt;i++)if(memcmp(m,staMacs[i],6)==0)return true;
  return false;
}
static StaInfo *staLookup(const uint8_t*m){
  for(int i=0;i<staInfoCnt;i++) if(memcmp(staInfo[i].mac,m,6)==0) return &staInfo[i];
  if(staInfoCnt<MAX_STA_TRACK){
    StaInfo*s=&staInfo[staInfoCnt++];
    memset(s,0,sizeof(*s));
    memcpy(s->mac,m,6); s->inUse=true;
    s->firstSeen=s->lastSeen=millis();
    return s;
  }
  return NULL;
}
static void staLearn(const uint8_t*m){
  if(memcmp(m,apMac,6)==0||isMcast(m)||isKnown(m))return;
  if(staCnt>=MAX_STA)return;
  memcpy(staMacs[staCnt++],m,6);
}
static void staAdvance(StaInfo*s,uint8_t st){
  if(!s)return;
  s->lastSeen=millis();
  if(st>s->stage)s->stage=st;
}
static bool probeThrottled(const uint8_t*mac){
  uint32_t now=millis();
  for(int i=0;i<prlCnt;i++){
    if(memcmp(prlMac[i],mac,6)==0){
      if(now-prlMs[i]<PROBE_RL_MS)return true;
      prlMs[i]=now; return false;
    }
  }
  if(prlCnt<PRL_SLOTS){memcpy(prlMac[prlCnt],mac,6);prlMs[prlCnt++]=now;}
  return false;
}
static bool ssidIsOurs(const uint8_t*p,uint16_t len,uint16_t ieOff){
  size_t wl=strlen(AP_SSID);
  uint16_t off=ieOff;
  while(off+2<=len){
    uint8_t id=p[off],l=p[off+1];
    if(off+2+(uint16_t)l>len)break;
    if(id==0)return(l==wl)&&(memcmp(p+off+2,AP_SSID,l)==0);
    off+=2+l;
  }
  return false;
}

// ==================== IE ПАРСЕРЫ ====================
static void getIEs(const uint8_t*p,uint16_t ieOff,uint16_t len,IEs&o){
  memset(&o,0,sizeof(o)); o.dsChan=-1;
  uint16_t off=ieOff;
  while(off+2<=len){
    uint8_t id=p[off],l=p[off+1];
    if(off+2+(uint16_t)l>len){off+=2;continue;}
    const uint8_t*b=p+off+2;
    if(id==0){int n=(l>32)?32:l;memcpy(o.ssid,b,n);o.ssid[n]=0;}
    else if(id==3&&l>=1){o.dsChan=b[0];}
    else if(id==45&&l>=2){o.htCap=le16(b);o.ht40=(o.htCap&0x0002)!=0;}
    else if(id==48){o.rsn=true;}
    else if(id==191){o.vht=true;}
    else if(id==221&&l>=4){
      if(memcmp(b,WPA_OUI,3)==0){
        if(b[3]==1)o.wpa1=true;
        if(b[3]==4)o.wps=true;
      }
    }
    off+=2+l;
  }
}
static const char *cipherName(uint8_t t){
  switch(t){case 1:return"WEP40";case 2:return"TKIP";case 4:return"CCMP";case 5:return"WEP104";case 8:return"GCMP256";default:return"?";}
}
static const char *akmName(uint8_t t){
  switch(t){case 1:return"8021X";case 2:return"PSK";case 4:return"FT-PSK";case 6:return"PSK-SHA256";case 8:return"SAE";case 18:return"OWE";default:return"?";}
}
static bool parseRsnIE(const uint8_t*b,uint16_t l,RsnInfo&ri){
  memset(&ri,0,sizeof(ri)); ri.present=true;
  if(l<2)return false;
  uint16_t off=2;
  if(off+4>l)return false;
  memcpy(ri.gOUI,b+off,3);ri.gType=b[off+3];off+=4;
  if(off+2>l)return true;
  ri.pCount=le16(b+off);off+=2;
  if(ri.pCount>4)ri.pCount=4;
  for(int i=0;i<ri.pCount;i++){if(off+4>l)break;memcpy(ri.pOUI[i],b+off,3);ri.pType[i]=b[off+3];off+=4;}
  if(off+2>l)return true;
  ri.aCount=le16(b+off);off+=2;
  if(ri.aCount>4)ri.aCount=4;
  for(int i=0;i<ri.aCount;i++){if(off+4>l)break;memcpy(ri.aOUI[i],b+off,3);ri.aType[i]=b[off+3];off+=4;}
  if(off+2<=l){ri.caps=le16(b+off);ri.hasCaps=true;off+=2;}
  if(off+2<=l){uint16_t pmkid=le16(b+off);off+=2;off+=pmkid*16;}
  if(off+4<=l){memcpy(ri.mgOUI,b+off,3);ri.mgType=b[off+3];ri.hasMgmtCipher=true;}
  return true;
}
static void printRsnInfo(const RsnInfo&ri){
  if(!ri.present)return;
  Serial.printf("  RSN group=%s pairwise=[",cipherName(ri.gType));
  for(int i=0;i<ri.pCount;i++)Serial.printf("%s%s",i?",":"",cipherName(ri.pType[i]));
  Serial.print("] AKM=[");
  for(int i=0;i<ri.aCount;i++)Serial.printf("%s%s",i?",":"",akmName(ri.aType[i]));
  Serial.print("]");
  if(ri.hasCaps){
    bool mfpr=ri.caps&0x0040,mfpc=ri.caps&0x0080;
    Serial.printf(" MFPR=%d MFPC=%d",(int)mfpr,(int)mfpc);
  }
  if(ri.hasMgmtCipher)Serial.print(" +PMF-mgmt-cipher");
  Serial.println();
}

// ==================== PHYERR ====================
static const char *phyErrName(uint8_t c){
  switch(c){
    case 0:return"OK";case 1:return"SFD-TIMEOUT";case 2:return"PLCP-HDR-TIMEOUT";
    case 3:return"OFDM-TIMING";case 4:return"OFDM-SIGNAL";case 5:return"OFDM-SERVICE";
    case 6:return"OFDM-RATE";case 7:return"OFDM-LENGTH";case 8:return"OFDM-PARITY";
    case 9:return"OFDM-RESTART";case 10:return"OFDM-ILLEGAL";case 11:return"OFDM-RATE-ILLEGAL";
    case 12:return"OFDM-LENGTH-ILLEGAL";case 13:return"OFDM-PARITY-ILLEGAL";
    case 14:return"OFDM-SERVICE-ILLEGAL";case 15:return"OFDM-TIMING-ILLEGAL";
    case 16:return"OFDM-SIGNAL-ILLEGAL";case 17:return"OFDM-TIMING";
    case 18:return"OFDM-SIGNAL";case 19:return"OFDM-SERVICE";case 20:return"OFDM-RATE";
    case 21:return"OFDM-LENGTH";case 22:return"OFDM-PARITY";case 23:return"OFDM-RESTART";
    case 24:return"OFDM-ILLEGAL";case 25:return"CCK-TIMING";case 26:return"CCK-SIGNAL";
    case 27:return"CCK-SERVICE";case 28:return"CCK-RATE";case 29:return"CCK-LENGTH";
    case 30:return"CCK-PARITY";case 31:return"CCK-RESTART";case 32:return"DSSS-TIMING";
    case 33:return"DSSS-SIGNAL";case 34:return"DSSS-SERVICE";case 35:return"DSSS-RATE";
    case 36:return"DSSS-LENGTH";case 37:return"DSSS-PARITY";case 38:return"DSSS-RESTART";
    case 98:return"AGC/SYNC-FAIL (ESP32)";
    default:return"UNKNOWN";
  }
}
static const char *rateToMbps(uint8_t r){
  switch(r){
    case 0:return"1";case 1:return"2";case 2:return"5.5";case 3:return"11";
    case 4:return"6";case 5:return"9";case 6:return"12";case 7:return"18";
    case 8:return"24";case 9:return"36";case 10:return"48";case 11:return"54";
    default:return"HT/VHT";
  }
}

// ==================== DHCP/ARP/DNS ====================
static const char *dhcpMsgName(uint8_t t){
  switch(t){case 1:return"DISCOVER";case 2:return"OFFER";case 3:return"REQUEST";case 4:return"DECLINE";case 5:return"ACK";case 6:return"NAK";case 7:return"RELEASE";case 8:return"INFORM";default:return"?";}
}
static void emitArp(const uint8_t*p,uint16_t len){
  if(len<28)return;
  uint16_t op=be16(p+6);
  char sha[18],spa[16],tpa[16];
  mac2str(p+8,sha);
  ip2str(((uint32_t)p[14]<<24)|((uint32_t)p[15]<<16)|((uint32_t)p[16]<<8)|p[17],spa);
  ip2str(((uint32_t)p[24]<<24)|((uint32_t)p[25]<<16)|((uint32_t)p[26]<<8)|p[27],tpa);
  if(op==1)Serial.printf("  ARP who-has %s ? tell %s (%s)\r\n",tpa,spa,sha);
  else if(op==2)Serial.printf("  ARP is-at %s -> %s\r\n",spa,sha);
}
static void emitDhcp(const uint8_t*p,uint16_t len,StaInfo*si){
  if(len<240)return;
  uint8_t op=p[0];
  uint32_t xid=((uint32_t)p[4]<<24)|((uint32_t)p[5]<<16)|((uint32_t)p[6]<<8)|p[7];
  char yi[16]; ip2str(((uint32_t)p[16]<<24)|((uint32_t)p[17]<<16)|((uint32_t)p[18]<<8)|p[19],yi);
  const uint8_t*opt=p+240; uint16_t optlen=len-240;
  const char*mt="?"; uint8_t mtCode=0; uint16_t off=0;
  while(off<optlen){
    uint8_t c=opt[off];
    if(c==255)break;
    if(c==0){off++;continue;}
    if(off+1>=optlen)break;
    uint8_t olen=opt[off+1];
    if(off+2+olen>optlen)break;
    if(c==53&&olen>=1){mtCode=opt[off+2];mt=dhcpMsgName(mtCode);break;}
    off+=2+olen;
  }
  Serial.printf("  DHCP %-8s op=%u xid=0x%08lX yiaddr=%s\r\n",mt,op,(unsigned long)xid,yi);
  if(si){
    if(mtCode==1)si->dhcpDisc++;
    else if(mtCode==3)si->dhcpReq++;
    else if(mtCode==5){si->dhcpAck++;si->dhcpOk=true;staAdvance(si,ST_CONNECTED);}
  }
}
static void emitDns(const uint8_t*p,uint16_t len){
  if(len<12)return;
  uint16_t flags=be16(p+2),qd=be16(p+4);
  bool isResp=(flags&0x8000)!=0;
  if(qd<1)return;
  uint16_t off=12;
  char name[80]; uint16_t ni=0;
  while(off<len&&p[off]!=0&&ni<sizeof(name)-1){
    uint8_t l=p[off++];
    if(l>63)break;
    if(off+l>len)break;
    if(ni)name[ni++]='.';
    for(uint8_t i=0;i<l&&ni<sizeof(name)-1;i++)name[ni++]=p[off+i];
    off+=l;
  }
  name[ni]=0;
  if(off+4>len)return;
  uint16_t qtype=be16(p+off);
  const char*qn=(qtype==1)?"A":(qtype==28)?"AAAA":(qtype==12)?"PTR":"?";
  Serial.printf("  DNS %s q=\"%s\" type=%s\r\n",isResp?"RESP":"QUERY",name,qn);
}
static void parseIPv4(const uint8_t*p,uint16_t len,StaInfo*si){
  if(len<20)return;
  uint8_t ihl=(p[0]&0x0F)*4;
  if(ihl<20||len<ihl)return;
  if(p[9]!=17)return;
  if(len<ihl+8)return;
  char src[16],dst[16];
  ip2str(((uint32_t)p[12]<<24)|((uint32_t)p[13]<<16)|((uint32_t)p[14]<<8)|p[15],src);
  ip2str(((uint32_t)p[16]<<24)|((uint32_t)p[17]<<16)|((uint32_t)p[18]<<8)|p[19],dst);
  uint16_t sp=be16(p+ihl),dp=be16(p+ihl+2);
  const uint8_t*udp=p+ihl+8; uint16_t ulen=len-ihl-8;
  if((sp==67&&dp==68)||(sp==68&&dp==67)){
    Serial.printf("  UDP %s:%u -> %s:%u\r\n",src,sp,dst,dp);
    emitDhcp(udp,ulen,si);
  } else if(sp==53||dp==53){
    Serial.printf("  UDP %s:%u -> %s:%u\r\n",src,sp,dst,dp);
    emitDns(udp,ulen);
  }
}

// ==================== EAPOL ====================
static void emitEapol(const uint8_t*p,uint16_t len,StaInfo*si,bool fromAp){
  if(len<4)return;
  uint8_t ver=p[0],type=p[1];
  if(type!=3){
    const char*tn=(type==0)?"EAP":(type==1)?"Start":(type==2)?"Logoff":"?";
    Serial.printf("  EAPOL type=%u(%s) ver=%u len=%u\r\n",type,tn,ver,len);
    return;
  }
  if(len<4+91){Serial.printf("  EAPOL-Key short len=%u\r\n",len);return;}
  const uint8_t*k=p+4;
  uint8_t desc=k[0];
  uint16_t ki=le16(k+1);
  uint16_t klen=be16(k+3);
  uint64_t replay=0; for(int i=0;i<8;i++)replay=(replay<<8)|k[5+i];
  bool pair=(ki&0x0008)!=0, ack=(ki&0x0080)!=0, mic=(ki&0x0100)!=0,
       sec=(ki&0x0200)!=0, encr=(ki&0x1000)!=0;
  uint8_t kdv=ki&0x0007;
  const char*msg;
  if(!pair) msg=(ack&&mic&&sec)?"GTK-M1":(!ack&&mic&&sec)?"GTK-M2":"GTK-?";
  else msg=(ack&&!mic&&!sec)?"M1":(!ack&&mic&&!sec)?"M2":
           (ack&&mic&&sec)?"M3":(!ack&&mic&&sec)?"M4 (GTK-install)":
           (!ack&&mic)?"M4":"?";
  Serial.printf("  EAPOL-Key %s %s ver=%u KDV=%u keylen=%u replay=%llu ki=0x%04X [pair=%d ack=%d mic=%d sec=%d encr=%d]\r\n",
                fromAp?"AP->STA":"STA->AP",msg,ver,kdv,klen,(unsigned long long)replay,ki,
                (int)pair,(int)ack,(int)mic,(int)sec,(int)encr);
  if(si){
    if(!strcmp(msg,"M1")){if(si->m1)si->handshakeRetries++;si->m1++;staAdvance(si,ST_M1);}
    else if(!strcmp(msg,"M2")){si->m2++;staAdvance(si,ST_M2);}
    else if(!strcmp(msg,"M3")){si->m3++;staAdvance(si,ST_M3);}
    else if(!strcmp(msg,"M4")||!strcmp(msg,"M4 (GTK-install)")){
      si->m4++;staAdvance(si,ST_M4);
      if(!si->connectAt)si->connectAt=millis();
      Serial.println("    >> 4-way handshake OK");
    } else if(!strncmp(msg,"GTK",3)) si->eapolGtk++;
  }
}

// ==================== REASON/STATUS ====================
static const char *statusName(uint16_t c){
  switch(c){
    case 0:return"SUCCESS";case 1:return"UNSPEC-FAIL";case 2:return"AUTH-NOT-VALID";
    case 4:return"INACTIVITY";case 5:return"AP-FULL";case 6:return"CLASS2-NONAUTH";
    case 7:return"CLASS3-NONASSOC";case 9:return"NOT-AUTHED";case 11:return"UNSUPPORTED-CHANNEL";
    case 13:return"UNSUPPORTED-AUTH-ALG";case 14:return"AUTH-SEQ-UNEXPECTED";
    case 15:return"AUTH-CHALLENGE-FAIL";case 16:return"AUTH-TIMEOUT";
    case 17:return"AP-FULL-ASSOC";case 18:return"RATES-NOT-SUPPORTED";
    case 40:return"HT-NOT-SUPPORTED";case 41:return"RSN-NOT-SUPPORTED";
    case 43:return"CIPHER-REJECT";case 44:return"UNSUPPORTED-AKMP";
    case 45:return"RSN-VERSION";case 46:return"RSN-CAP";
    case 47:return"MFP-NOT-CAPABLE";case 48:return"MFP-REQUIRED";
    case 51:return"UNSUPPORTED-OP-MODE"; default:return"code?";
  }
}
static const char *reasonName(uint16_t c){
  switch(c){
    case 1:return"UNSPEC";case 2:return"PREV-AUTH-INVALID";case 3:return"STA-LEAVING";
    case 4:return"INACTIVITY";case 5:return"AP-FULL";case 6:return"CLASS2-NONAUTH";
    case 7:return"CLASS3-NONASSOC";case 8:return"LEAVING-BSS";case 9:return"NOT-AUTHED";
    case 10:return"POWER-CAP";case 11:return"UNSUPPORTED-CHANNEL";case 12:return"BSS-TRANSITION";
    case 13:return"INVALID-IE";case 14:return"MIC-FAILURE";case 15:return"4WAY-TIMEOUT";
    case 16:return"GROUP-KEY-TIMEOUT";case 23:return"8021X-FAIL";case 24:return"CIPHER-REJECT";
    case 32:return"UNSPEC-QOS";case 35:return"NOT-EXIST";case 37:return"REQUEST-DECLINED";
    case 38:return"INVALID-PARAMS"; default:return"code?";
  }
}
static const char *mgmtSubName(uint8_t s){
  switch(s){case 0:return"ASSOC-REQ";case 1:return"ASSOC-RESP";case 2:return"REASSOC-REQ";
    case 3:return"REASSOC-RESP";case 4:return"PROBE-REQ";case 5:return"PROBE-RESP";
    case 8:return"BEACON";case 10:return"DISASSOC";case 11:return"AUTH";
    case 12:return"DEAUTH";case 13:return"ACTION"; default:return"MGMT?";}
}
static const char *ctrlSubName(uint8_t s){
  switch(s){case 8:return"BLOCKACK-REQ";case 9:return"BLOCKACK";case 10:return"PS-POLL";
    case 11:return"RTS";case 12:return"CTS";case 13:return"ACK";case 14:return"CF-END";
    default:return"CTRL?";}
}
static const char *stageName(uint8_t st){
  switch(st){case ST_NONE:return"NONE";case ST_PROBED:return"PROBED";
    case ST_AUTH_SENT:return"AUTH-SENT";case ST_AUTH_OK:return"AUTH-OK";
    case ST_ASSOC_SENT:return"ASSOC-SENT";case ST_ASSOC_OK:return"ASSOC-OK";
    case ST_M1:return"M1";case ST_M2:return"M2";case ST_M3:return"M3";case ST_M4:return"M4";
    case ST_DHCP:return"DHCP";case ST_CONNECTED:return"CONNECTED";
    case ST_DEAUTH:return"DEAUTH";case ST_DISASSOC:return"DISASSOC";case ST_FAILED:return"FAILED";
    default:return"?";}
}

// ==================== WIFI EVENT HANDLER ====================
// ВАЖНО: этот код для Arduino-ESP32 core 1.x
static void onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info){
  // В версии 1.x использовались константы SYSTEM_EVENT_*
  if(event == SYSTEM_EVENT_AP_STACONNECTED){
    clientConnected = true;
    connectTimestamp = millis();
    const uint8_t* m = info.sta_connected.mac; // поле структуры тоже отличается
    char s[18]; mac2str(m, s);
    if(testPhase == TP_WAIT_CONNECT){
      Serial.printf("  >> WiFi event: STACONNECTED %s @ %s\r\n", s, rateTests[testRateIdx].name);
    }
  } else if(event == SYSTEM_EVENT_AP_STADISCONNECTED){
    clientConnected = false;
    disconnectTimestamp = millis();
    staGotIp = false;
    if(testPhase == TP_WAIT_DISC || testPhase == TP_WAIT_CONNECT){
      const uint8_t* m = info.sta_disconnected.mac;
      char s[18]; mac2str(m, s);
      Serial.printf("  >> WiFi event: STADISCONNECTED %s\r\n", s);
    }
  } else if(event == SYSTEM_EVENT_AP_STAIPASSIGNED){
    staGotIp = true;
  }
}

// ==================== SNIFFER CALLBACK ====================
static void IRAM_ATTR snifferCb(void*buf,wifi_promiscuous_pkt_type_t type){
  const wifi_promiscuous_pkt_t*pkt=(const wifi_promiscuous_pkt_t*)buf;
  const uint8_t*p=pkt->payload;
  uint16_t olen=pkt->rx_ctrl.sig_len;
  uint8_t rxState=pkt->rx_ctrl.rx_state;

  if(rxState!=0||type==WIFI_PKT_MISC){
    uint16_t nh=(rbHead+1)&(RB_SLOTS-1);
    if(nh==rbTail){rbDrops++;return;}
    PktRec&r=rb[rbHead];
    r.len=0;r.olen=olen;r.rssi=pkt->rx_ctrl.rssi;
    r.ptype=3;r.rate=pkt->rx_ctrl.rate;r.rxState=rxState;
    r.tms=millis();r.tus=pkt->rx_ctrl.timestamp;r.data[0]=rxState;
    rbHead=nh;
    return;
  }
  if(olen<10)return;
  uint8_t t=(p[0]>>2)&3, s=(p[0]>>4)&0xF;
  const uint8_t*a1=p+4;
  const uint8_t*a2=(t==1&&(s==12||s==13))?a1:p+10;
  const uint8_t*a3=p+16;

  // Фильтр — только кадры, касающиеся нашего AP
  bool hit = (memcmp(a1,apMac,6)==0) || (memcmp(a2,apMac,6)==0) ||
             (olen>=24 && memcmp(a3,apMac,6)==0);
  if(!hit && t==0 && s==4) hit = ssidIsOurs(p,olen,24);
  if(!hit && t==1)          hit = isKnown(a1);
  if(!hit) return;
  if(t==0 && s==8 && !dumpBeacons) return;
  if(t==0 && s==4 && probeThrottled(a2)) return;

  StaInfo*si=NULL;
  if(t==0 && !isMcast(a2) && memcmp(a2,apMac,6)!=0) si=staLookup(a2);
  else if(t==2 && !isMcast(a2) && memcmp(a2,apMac,6)!=0) si=staLookup(a2);

  if(t==0){
    if(s==4){ staLearn(a2);
      bool our=ssidIsOurs(p,olen,24);
      if(si){ if(our){si->probeOur++;staAdvance(si,ST_PROBED);} else si->probeEmpty++; }
    } else if(s==11 && olen>=30){
      staLearn(a2);
      const uint8_t*b=p+24;
      uint16_t st=le16(b+4);
      bool fromAp=(memcmp(a2,apMac,6)==0);
      if(si){
        if(!fromAp){si->authReq++;staAdvance(si,ST_AUTH_SENT);}
        else{si->authResp++;si->authLastStatus=st;
             if(st==0){si->authOk++;staAdvance(si,ST_AUTH_OK);}
             else staAdvance(si,ST_FAILED);}
      }
    } else if((s==0||s==2) && olen>=28){
      staLearn(a2);
      if(si){if(s==0)si->assocReq++;staAdvance(si,ST_ASSOC_SENT);}
    } else if((s==1||s==3) && olen>=30){
      const uint8_t*b=p+24; uint16_t st=le16(b+2);
      if(si){
        si->assocResp++;si->assocLastStatus=st;
        if(st==0){si->assocOk++;staAdvance(si,ST_ASSOC_OK);}
        else staAdvance(si,ST_FAILED);
      }
    } else if((s==10||s==12) && olen>=26){
      if(si){
        if(s==10){si->disassoc++;staAdvance(si,ST_DISASSOC);}
        else     {si->deauth++;  staAdvance(si,ST_DEAUTH);}
      }
    }
  } else if(t==1){
    if(si && s==13) si->acks++;
  } else if(t==2){
    if(si){
      bool fromAp=(memcmp(a2,apMac,6)==0);
      if(fromAp) si->dataTo++;
      else {si->dataFrom++; staLearn(a2);}
    }
  }

  // Сохранение кадра
  uint16_t nh=(rbHead+1)&(RB_SLOTS-1);
  if(nh==rbTail){rbDrops++;return;}
  PktRec&r=rb[rbHead];
  r.len=(olen>RB_CAP)?RB_CAP:olen;
  r.olen=olen;r.rssi=pkt->rx_ctrl.rssi;
  r.ptype=(t<=2)?t:2;r.rate=pkt->rx_ctrl.rate;r.rxState=0;
  r.tms=millis();r.tus=pkt->rx_ctrl.timestamp;
  memcpy(r.data,p,r.len);
  rbHead=nh;
}

// ==================== DUMP PACKET ====================
static void dumpPacket(const PktRec&r){
  if(r.ptype==3){
    Serial.printf("[W-PHYERR] [%s] code=%u rssi=%d rate=%s Mbps len=%u\r\n",
                  phyErrName(r.rxState),r.rxState,r.rssi,rateToMbps(r.rate),r.olen);
    return;
  }
  const uint8_t*p=r.data; uint16_t len=r.len;
  if(len<10)return;
  uint8_t t=(p[0]>>2)&3, s=(p[0]>>4)&0xF;
  uint8_t f1=p[1];
  bool toDS=f1&0x01,fromDS=f1&0x02;
  bool retry=(f1>>3)&1, wep=(f1>>6)&1;
  bool four=toDS&&fromDS;
  const uint8_t*a1=p+4;
  const uint8_t*a2=(t==1&&(s==12||s==13))?a1:p+10;
  const uint8_t*a3=p+16;
  char a1s[18],a2s[18],a3s[18];
  mac2str(a1,a1s);mac2str(a2,a2s);mac2str(a3,a3s);
  const char*tn=(r.ptype==0)?"MGMT":(r.ptype==1)?"CTRL":"DATA";
  char subn[24];
  if(r.ptype==0) snprintf(subn,sizeof(subn),"%s",mgmtSubName(s));
  else if(r.ptype==1) snprintf(subn,sizeof(subn),"%s",ctrlSubName(s));
  else snprintf(subn,sizeof(subn),"DATA-0x%02X",s);
  const char*dir="ext";
  if(t==0){
    if(memcmp(a2,apMac,6)==0)dir="AP->STA";
    else if(memcmp(a1,apMac,6)==0||memcmp(a3,apMac,6)==0)dir="STA->AP";
  } else if(t==2){
    if(toDS&&!fromDS)dir=(memcmp(a1,apMac,6)==0)?"STA->AP":"STA->ext";
    else if(fromDS&&!toDS)dir=(memcmp(a2,apMac,6)==0)?"AP->STA":"ext->STA";
  } else dir=(memcmp(a1,apMac,6)==0)?"ACK->AP":"ACK->oth";

  bool fromSta=(r.ptype==0)&&(memcmp(a2,apMac,6)!=0);
  bool isReq=fromSta&&(s==0||s==4||s==11||s==10||s==12);
  if(isReq) Serial.println("------------------------------------------------");
  Serial.printf("[P %6lu.%03lu] rssi=%d rate=%sM %s/%s len=%u retry=%d dir=%s",
                (unsigned long)(r.tms/1000UL),(unsigned long)(r.tms%1000UL),
                (int)r.rssi,rateToMbps(r.rate),tn,subn,(unsigned)r.olen,(int)retry,dir);
  if(verboseRx&&r.rxState) Serial.printf(" rx_state=%u(%s)",r.rxState,phyErrName(r.rxState));
  Serial.println();
  if(len>=24&&!four){
    uint16_t sc=le16(p+22);
    Serial.printf("  A1=%s A2=%s A3=%s seq=%u\r\n",a1s,a2s,a3s,(unsigned)(sc>>4));
  } else Serial.printf("  A1=%s A2=%s A3=%s\r\n",a1s,a2s,a3s);

  if(r.ptype==0 && len>=24){
    const uint8_t*b=p+24; uint16_t bl=len-24;
    if(s==11&&bl>=6){
      uint16_t alg=le16(b),txn=le16(b+2),st=le16(b+4);
      const char*algN=(alg==0)?"open":(alg==1)?"shared":(alg==3)?"SAE":"?";
      Serial.printf("  AUTH alg=%u(%s) txn=%u status=%u(%s)\r\n",alg,algN,txn,st,statusName(st));
    } else if(s==0&&bl>=4){
      IEs ie; getIEs(p,28,len,ie);
      Serial.printf("  ASSOC-REQ caps=0x%04X ssid=\"%s\" rsn=%d\r\n",le16(b),ie.ssid,(int)ie.rsn);
    } else if(s==1&&bl>=6){
      Serial.printf("  ASSOC-RESP status=%u(%s) aid=0x%04X\r\n",
                    le16(b+2),statusName(le16(b+2)),le16(b+4));
    } else if((s==10||s==12)&&bl>=2){
      Serial.printf("  %s reason=%u(%s)\r\n",
                    (s==10)?"DISASSOC":"DEAUTH",le16(b),reasonName(le16(b)));
    } else if(s==4||s==5){
      IEs ie; getIEs(p,(s==4)?24:36,len,ie);
      Serial.printf("  %s ssid=\"%s\" chan=%d rsn=%d ht40=%d vht=%d\r\n",
                    (s==4)?"PROBE-REQ":"PROBE-RESP",
                    ie.ssid,ie.dsChan,(int)ie.rsn,(int)ie.ht40,(int)ie.vht);
    }
  }

  if(r.ptype==2 && !wep){
    bool toDS2=p[1]&0x01,fromDS2=p[1]&0x02;
    uint8_t qos=((p[0]>>4)&0x08)?2:0, htc=qos&&((p[1]>>7)&1)?4:0;
    uint16_t hdr=24+qos+htc;
    if(len>=hdr+8){
      const uint8_t*llc=p+hdr;
      if(llc[0]==0xAA&&llc[1]==0xAA&&llc[2]==0x03){
        uint16_t eth=be16(llc+6);
        const uint8_t*pl=llc+8; uint16_t plen=len-hdr-8;
        StaInfo*si=NULL;
        if(!isMcast(a2)&&memcmp(a2,apMac,6)!=0)si=staLookup(a2);
        if(!si&&!isMcast(a1)&&memcmp(a1,apMac,6)!=0)si=staLookup(a1);
        if(eth==0x888E)      emitEapol(pl,plen,si,fromDS2&&!toDS2);
        else if(eth==0x0806) emitArp(pl,plen);
        else if(eth==0x0800) parseIPv4(pl,plen,si);
        else if(eth==0x86DD) Serial.printf("  IPv6 len=%u\r\n",(unsigned)plen);
      }
    }
  }

  if(dumpHexOn){
    uint16_t cap=(r.ptype==0)?96:48;
    if(cap>len)cap=len;
    if(cap>0){
      Serial.print("  HEX:");
      for(uint16_t i=0;i<cap;i++)Serial.printf(" %02X",p[i]);
      if(len>cap)Serial.printf(" ...(+%u)",len-cap);
      Serial.println();
    }
  }
}

// ==================== PCAP ====================
static void pcapDump(){
  static const uint8_t HDR[24]={
    0xD4,0xC3,0xB2,0xA1,0x02,0x00,0x04,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0xFF,0xFF,0x00,0x00,0x69,0x00,0x00,0x00};
  Serial.println("<<<PCAP-HEX BEGIN>>>");
  for(uint16_t i=0;i<24;i++)Serial.printf("%02X",HDR[i]);
  Serial.println();
  for(uint16_t i=rbTail;i!=rbHead;i=(i+1)&(RB_SLOTS-1)){
    const PktRec&r=rb[i];
    if(r.ptype==3)continue;
    uint32_t s=r.tms/1000UL, u=(r.tms%1000UL)*1000UL;
    uint8_t h[16]={(uint8_t)(s&0xFF),(uint8_t)((s>>8)&0xFF),(uint8_t)((s>>16)&0xFF),(uint8_t)((s>>24)&0xFF),
                   (uint8_t)(u&0xFF),(uint8_t)((u>>8)&0xFF),(uint8_t)((u>>16)&0xFF),(uint8_t)((u>>24)&0xFF),
                   (uint8_t)(r.len&0xFF),(uint8_t)((r.len>>8)&0xFF),0,0,
                   (uint8_t)(r.olen&0xFF),(uint8_t)((r.olen>>8)&0xFF),0,0};
    for(int j=0;j<16;j++)Serial.printf("%02X",h[j]);
    for(uint16_t j=0;j<r.len;j++)Serial.printf("%02X",r.data[j]);
    Serial.println();
  }
  Serial.println("<<<PCAP-HEX END>>>");
}

// ==================== RATE TEST STATE MACHINE ====================
static void resetTestCounters(){
  staInfoCnt=0; staCnt=0; prlCnt=0;
  memset(staInfo,0,sizeof(staInfo));
  staGotIp=false;
}

static void beginRateTest(){
  Serial.println();
  Serial.println("╔══════════════════════════════════════════════╗");
  Serial.println("║  AUTO RATE TEST — начинаем                   ║");
  Serial.printf ("║  %d скоростей × %d с таймаут                ║\r\n",
                 RATE_TEST_COUNT, CONNECT_TIMEOUT_MS/1000);
  Serial.println("║  Подключите клиент к \"" AP_SSID "\"           ║");
  Serial.println("║  и оставьте его с автоподключением.          ║");
  Serial.println("╚══════════════════════════════════════════════╝");
  for(int i=0;i<RATE_TEST_COUNT;i++) memset(&testResults[i],0,sizeof(TestResult));
  testRateIdx=0;
  testAutoQuiet=true;
  testPhase=TP_DEAUTH;
  testPhaseStart=millis();
}

static void runRateTest(){
  uint32_t elapsed=millis()-testPhaseStart;
  switch(testPhase){
    case TP_DEAUTH:
      Serial.printf("\r\n=== RATE TEST %d/%d: %s ===\r\n",
                    testRateIdx+1,RATE_TEST_COUNT,rateTests[testRateIdx].name);
      esp_wifi_deauth_sta(0);
      testPhase=TP_WAIT_DISC;
      testPhaseStart=millis();
      break;
    case TP_WAIT_DISC:
      if(!clientConnected||elapsed>=DISC_TIMEOUT_MS){
        testPhase=TP_SET_RATE;
        testPhaseStart=millis();
      }
      break;
    case TP_SET_RATE:{
      esp_err_t e=esp_wifi_internal_set_fix_rate(WIFI_IF_AP,true,rateTests[testRateIdx].value);
      Serial.printf("  fix-rate %s → %s\r\n",
                    rateTests[testRateIdx].name,(e==ESP_OK)?"OK":"FAIL");
      resetTestCounters();
      testResults[testRateIdx].attempted=true;
      testPhase=TP_WAIT_CONNECT;
      testPhaseStart=millis();
      break;
    }
    case TP_WAIT_CONNECT:
      if(clientConnected){
        testResults[testRateIdx].success=true;
        testResults[testRateIdx].connectMs=connectTimestamp-testPhaseStart;
        // Собираем счётчики со всех STA
        uint16_t aR=0,aS=0,m2=0,m4=0,dt=0; uint8_t fst=ST_NONE;
        for(int i=0;i<staInfoCnt;i++){
          StaInfo&s=staInfo[i];
          aR+=s.authReq; aS+=s.assocReq; m2+=s.m2; m4+=s.m4; dt+=s.dataFrom;
          if(s.stage>fst)fst=s.stage;
        }
        testResults[testRateIdx].authReqCount=aR;
        testResults[testRateIdx].assocReqCount=aS;
        testResults[testRateIdx].m2Count=m2;
        testResults[testRateIdx].m4Count=m4;
        testResults[testRateIdx].dataCount=dt;
        testResults[testRateIdx].failStage=fst;
        Serial.printf("  ✓ SUCCESS @ %u мс (AUTH-REQ=%u, ASSOC-REQ=%u, M2=%u, M4=%u)\r\n",
                      testResults[testRateIdx].connectMs,aR,aS,m2,m4);
        testPhase=TP_RECORD;
        testPhaseStart=millis();
        break;
      }
      if(elapsed>=CONNECT_TIMEOUT_MS){
        // Таймаут — фиксируем, что успели насниффить
        uint16_t aR=0,aS=0,m2=0,m4=0,dt=0; uint8_t fst=ST_NONE;
        for(int i=0;i<staInfoCnt;i++){
          StaInfo&s=staInfo[i];
          aR+=s.authReq; aS+=s.assocReq; m2+=s.m2; m4+=s.m4; dt+=s.dataFrom;
          if(s.stage>fst)fst=s.stage;
        }
        testResults[testRateIdx].authReqCount=aR;
        testResults[testRateIdx].assocReqCount=aS;
        testResults[testRateIdx].m2Count=m2;
        testResults[testRateIdx].m4Count=m4;
        testResults[testRateIdx].dataCount=dt;
        testResults[testRateIdx].failStage=fst;
        Serial.printf("  ✗ FAILED (timeout) — застряли на: %s\r\n", stageName(fst));
        Serial.printf("    AUTH-REQ=%u, ASSOC-REQ=%u, M2=%u, M4=%u\r\n",aR,aS,m2,m4);
        if(aR>3 && aS==0)
          Serial.println("    >> клиент долбит AUTH-REQ — AUTH-RESP на этой скорости не декодируется");
        else if(aS>3 && m2==0)
          Serial.println("    >> клиент долбит ASSOC-REQ — ASSOC-RESP не декодируется");
        else if(m2>0 && m4==0)
          Serial.println("    >> M2 получен, но M4 нет — M3 на этой скорости не декодируется");
        testPhase=TP_RECORD;
        testPhaseStart=millis();
      }
      break;
    case TP_RECORD:
      testPhase=TP_BETWEEN;
      testPhaseStart=millis();
      break;
    case TP_BETWEEN:
      if(elapsed>=BETWEEN_TESTS_MS){
        esp_wifi_deauth_sta(0);
        testRateIdx++;
        if(testRateIdx>=RATE_TEST_COUNT){
          testPhase=TP_DONE;
        } else {
          testPhase=TP_DEAUTH;
        }
        testPhaseStart=millis();
      }
      break;
    case TP_DONE:{
      testAutoQuiet=false;
      Serial.println();
      Serial.println("╔══════════════════════════════════════════════╗");
      Serial.println("║  РЕЗУЛЬТАТЫ АВТО-ТЕСТА                       ║");
      Serial.println("╚══════════════════════════════════════════════╝");
      int maxWorking=-1;
      for(int i=0;i<RATE_TEST_COUNT;i++){
        TestResult&r=testResults[i];
        if(r.success){
          Serial.printf("  ✓ %-8s: OK  (%u мс, M2=%u, M4=%u)\r\n",
                        rateTests[i].name,r.connectMs,r.m2Count,r.m4Count);
          maxWorking=i;
        } else {
          Serial.printf("  ✗ %-8s: FAIL (stage=%s, AUTH=%u, ASSOC=%u, M2=%u)\r\n",
                        rateTests[i].name,stageName(r.failStage),
                        r.authReqCount,r.assocReqCount,r.m2Count);
        }
      }
      Serial.println();
      if(maxWorking>=0){
        Serial.printf("Вывод: макс. рабочая скорость = %s\r\n",rateTests[maxWorking].name);
        if(maxWorking<RATE_TEST_COUNT-1)
          Serial.println("Следующие скорости не прошли — AP нельзя использовать "
                         "с фиксированным rate выше этой.");
      } else {
        Serial.println("Вывод: ни одна скорость не дала подключения — "
                       "проблема не в rate, а в клиенте/конфиге.");
      }
      Serial.println();
      Serial.println("Откат на авто-скорость...");
      esp_wifi_internal_set_fix_rate(WIFI_IF_AP,false,WIFI_PHY_RATE_1M_L);
      testPhase=TP_IDLE;
      break;
    }
    default:
      testPhase=TP_IDLE;
  }
}

// ==================== STA SUMMARY ====================
static void staSummary(){
  char mm[18]; mac2str(apMac,mm);
  Serial.printf("=== STA SUMMARY (AP %s \"%s\" ch=%d) ===\r\n",
                mm,AP_SSID,(int)AP_CHANNEL);
  if(staInfoCnt==0){Serial.println("(никого не видели)");return;}
  for(int i=0;i<staInfoCnt;i++){
    StaInfo&s=staInfo[i];
    if(s.stage==ST_NONE)continue;
    uint32_t age=(millis()-s.lastSeen)/1000UL;
    char m[18]; mac2str(s.mac,m);
    Serial.printf("\r\n[%d] %s stage=%s age=%lus\r\n",
                  i,m,stageName(s.stage),(unsigned long)age);
    Serial.printf("    probe=%u/%u/%u  auth=%u/%u/%u lastStatus=%s\r\n",
                  s.probeOur,s.probeEmpty,s.probeOther,
                  s.authReq,s.authResp,s.authOk,
                  statusName(s.authLastStatus));
    Serial.printf("    assoc=%u/%u/%u lastStatus=%s\r\n",
                  s.assocReq,s.assocResp,s.assocOk,
                  statusName(s.assocLastStatus));
    Serial.printf("    eapol M1=%u M2=%u M3=%u M4=%u retries=%u GTK=%u\r\n",
                  s.m1,s.m2,s.m3,s.m4,s.handshakeRetries,s.eapolGtk);
    Serial.printf("    dhcp=%u/%u/%u ok=%d\r\n",
                  s.dhcpDisc,s.dhcpReq,s.dhcpAck,(int)s.dhcpOk);
    Serial.printf("    data rx=%u tx=%u | deauth=%u disassoc=%u\r\n",
                  s.dataFrom,s.dataTo,s.deauth,s.disassoc);
  }
}

// ==================== КОМАНДЫ ====================
static void printHelp(){
  Serial.println("h  справка          t  авто-тест rate (1M→6M→24M→54M)");
  Serial.println("s  сводка STA       c  конфиг           r  сброс");
  Serial.println("p  pcap-hex         x  hex в логе       b  BEACON");
  Serial.println("d  verbose rx_state q  тихий режим");
}
static void printConfig(){
  char m[18]; mac2str(apMac,m);
  Serial.printf("AP: ssid=\"%s\" ch=%d bssid=%s\r\n",AP_SSID,(int)AP_CHANNEL,m);
  Serial.printf("STA подключено: %u (event=%d)\r\n",
                (unsigned)WiFi.softAPgetStationNum(),(int)clientConnected);
  Serial.printf("hex=%d beacons=%d verboseRx=%d quiet=%d buf=%u/%u drops=%u\r\n",
                (int)dumpHexOn,(int)dumpBeacons,(int)verboseRx,(int)quietMode,
                (unsigned)((rbHead-rbTail)&(RB_SLOTS-1)),(unsigned)RB_SLOTS,(unsigned)rbDrops);
  Serial.printf("testPhase=%d rate=%d\r\n",(int)testPhase,testRateIdx);
}

// ==================== SETUP / LOOP ====================
void setup(){
  Serial.begin(SERIAL_BAUD);
  delay(400);
  Serial.println();
  Serial.println("==================================================");
  Serial.println("  ESP32 AP RATE TESTER v7");
  Serial.println("  SoftAP + sniffer + автоматический цикл скоростей");
  Serial.println("==================================================");

  WiFi.mode(WIFI_AP);
  bool ok=WiFi.softAP(AP_SSID,AP_PASS,AP_CHANNEL,AP_HIDDEN,AP_MAX_STA);
  delay(100);
  WiFi.softAPmacAddress(apMac);
  char m[18]; mac2str(apMac,m);
  Serial.printf("SoftAP: \"%s\" ch=%d bssid=%s → %s\r\n",
                AP_SSID,(int)AP_CHANNEL,m,ok?"OK":"FAIL");
  Serial.printf("IP: %s\r\n",WiFi.softAPIP().toString().c_str());

  WiFi.onEvent(onWiFiEvent);

  wifi_promiscuous_filter_t filt;
  filt.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT |
                     WIFI_PROMIS_FILTER_MASK_CTRL |
                     WIFI_PROMIS_FILTER_MASK_DATA |
                     WIFI_PROMIS_FILTER_MASK_MISC;
  esp_wifi_set_promiscuous_filter(&filt);
  esp_wifi_set_promiscuous_rx_cb(&snifferCb);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_ps(WIFI_PS_NONE);

  printHelp();
  Serial.println();
  Serial.println("1) Подключите клиент к \"" AP_SSID "\" (пароль \"" AP_PASS "\")");
  Serial.println("2) Убедитесь, что клиент автоподключается (телефон/ноут)");
  Serial.println("3) Нажмите 't' — пройдёт тест 4 скоростей");
  Serial.println("4) В конце — таблица результатов");
  Serial.println();
}

void loop(){
  // 1) Слив кольцевого буфера
  while(rbTail!=rbHead){
    if(!quietMode && !(testAutoQuiet && testPhase==TP_WAIT_CONNECT)){
      dumpPacket(rb[rbTail]);
    }
    rbTail=(rbTail+1)&(RB_SLOTS-1);
  }

  // 2) Команды
  while(Serial.available()>0){
    int c=Serial.read();
    if(c=='h'||c=='?') printHelp();
    else if(c=='c') printConfig();
    else if(c=='s') staSummary();
    else if(c=='p') pcapDump();
    else if(c=='x'){dumpHexOn=!dumpHexOn;Serial.printf("hexdump=%d\r\n",(int)dumpHexOn);}
    else if(c=='b'){dumpBeacons=!dumpBeacons;Serial.printf("beacons=%d\r\n",(int)dumpBeacons);}
    else if(c=='d'){verboseRx=!verboseRx;Serial.printf("verboseRx=%d\r\n",(int)verboseRx);}
    else if(c=='q'){quietMode=!quietMode;Serial.printf("quiet=%d\r\n",(int)quietMode);}
    else if(c=='r'){resetTestCounters();Serial.println("сброс");}
    else if(c=='t'){
      if(testPhase==TP_IDLE) beginRateTest();
      else Serial.println("тест уже идёт, дождитесь окончания");
    }
  }

  // 3) State machine теста
  if(testPhase!=TP_IDLE) runRateTest();

  // 4) Периодический отчёт о дропах
  static uint32_t lastMs=0;
  uint32_t now=millis();
  if(now-lastMs>=1000){
    lastMs=now;
    if(rbDrops){
      Serial.printf("!! буфер переполнен, потеряно %u кадров\r\n",(unsigned)rbDrops);
      rbDrops=0;
    }
  }
}
