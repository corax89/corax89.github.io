==========================================================================
 NOJME v36.09 — «NULL.STR» РАСКРЫТ + ЧИСТЫЙ ПРОЦЕСС НА КАЖДЫЙ ЗАПУСК
==========================================================================

ЧТО ПОКАЗАЛ ПОЛЕВОЙ ЛОГ v36.08
------------------------------
Guard сработал ровно как задуман: 3-й запуск, [STM-SPIN] (131072 подряд
EOF на исчерпанном 922B потоке) -> IOException -> поток завершён, висяка
НЕТ. Но в логе появилось новое, важнейшее свидетельство — за мгновение до
сбоя игра запросила:

    [RESOURCE] FAILED 'en/null.str': jar-miss
    [RESOURCE] FAILED 'null.str':    jar-miss
    [RESOURCE] 'entities.db' -> 922 bytes

имя ресурса — БУКВАЛЬНО "null.str" вместо "entities.str".

РАСКОД «NULL.STR»
-----------------
Построение имени (класс d игры):

    b("/entities.db") -> substring(1, 9) + ".str" -> "entities.str"

Подстрока "null" НЕ СОДЕРЖИТСЯ в "/entities.db", значит substring вернул
ССЫЛКУ null, и конкатенация Java дала "null" + ".str" = "null.str".

Почему substring вернул null:
  - [HEAP-OOM] в логе НЕТ -> heap_alloc НЕ падал;
  - gc=0 -> GC не запускался, «освобождение» не при чём;
  - остаётся string_chars(): объект-строка выглядела как
    stale/переиспользованный блок (класс v34.80: stale pointer) или его
    value-поле было повреждено. Это накопленная за сеансы порча:
    _exit(0) НЕ убивает процесс (см. ниже), и следующий запуск VM
    работает в той же куче поверх обломков предыдущего.

Дальше цепочка известна: entities.str=NULL -> парсеру нужно 2762 байта из
922-байтового entities.db -> readFully-спин -> guard v36.08 разорвал.

ИСПРАВЛЕНИЯ v36.09
------------------
1) STR-NULL GUARD (src/jvm/native.c).
   substring(I/II), trim, toLowerCase, toUpperCase, replace(CC), concat,
   valueOf([C), ByteArrayOutputStream.toString, StringBuffer.toString:
   если натив вернул NULL без pending exception — это нарушение контракта
   Java. Теперь: строка [STR-NULL] в trace + ловимый
   java/lang/OutOfMemoryError. Тихая порча имён ресурсов невозможна.

2) [STR-CHARS-NULL] (src/jvm/heap.c, string_chars()).
   Все три NULL-выхода (не heap-указатель / свободный блок / битое
   value-поле) логируются: адрес строки, in_heap, тип блока (первые 8).
   Следующий полевой лог назовёт отравленный объект ТОЧНО.

3) [STR-BADSLOT] (src/jvm/jvm.c, jvm_new_string_utf16).
   Неразрешённые value/count слоты java/lang/String — в trace (мягко,
   без ломания раннего бута).

4) svcExitProcess(0) ПЕРЕД _exit(0) (src/main.c) — запрос пользователя.
   Доказано комментарием v36.02 в самом main.c: _exit(0) НЕ убивает
   процесс — он только разгружает NRO и возвращает в HBmenu; процесс
   (куча, ~200+МБ утечек за 3 сеанса, состояние hbloader, detached-нити)
   переживает «выход». Следующий запуск NRO наследует это и Data-Abort'ит
   («вылет при повторном запуске», PC nojme_switch+0x5bbad8).
   svcExitProcess убивает процесс целиком -> hbloader перезапускает HBmenu
   ЧИСТЫМ -> каждый запуск эмулятора начинается с нулевого состояния.

ПРОВЕРКА
--------
- scripts/testspin: SPIN-OK (guard IOException, 113 мс), CTRL-OK, DIS-OK;
  [STM-SPIN] fire — воспроизведение поля v36.08.
- DoomRPG headless: 13.6 с / 37M инструкций / 27.2% framebuffer —
  идентично базе v36.08; строк STR-* — ноль (ложных сработок нет).

ЧТО ЖДАТЬ ОТ СЛЕДУЮЩЕГО ПОЛЕВОГО ЛОГА
-------------------------------------
- 3-й запуск в одном сеансе: либо чистая загрузка (порча больше не
  накапливается между запусками приложения), либо — если где-то ещё остался
  stale-указатель — явная пара:
      [STR-CHARS-NULL] #1 str=0x... why=freed-block in_heap=1 hdr_type=...
      [STR-NULL] substring(II) produced a NULL String (src=0x...) ...
  и игра получит ловимый OutOfMemoryError вместо тихого "null.str".
- «Вылет при повторном запуске»: должен уйти полностью — процесс теперь
  всегда умирает честно, HBmenu стартует заново.

КАК СОБРАТЬ
-----------
Desktop (проверка):   make headless   ->  bin/j2me-headless
Switch:               см. README-СБОРКА.txt / scripts/armv7_build.sh
Самопроверка guard'а: make headless && ./bin/j2me-headless scripts/testspin/TestSpin.jar
                      (в stderr: [STM-SPIN] ... -> SPIN-OK)
