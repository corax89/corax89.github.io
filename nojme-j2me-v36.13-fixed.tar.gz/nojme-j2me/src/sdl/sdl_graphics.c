/*
 * J2ME Emulator - SDL2 Backend
 * Cross-platform graphics, input, and audio using SDL2
 * Falls back to stub implementation if SDL2 is not available
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <limits.h> /* v35.09 GAMEKEYS sentinel INT_MIN */
#include <string.h>
#include <stdint.h>
#ifndef _WIN32
#include <unistd.h>
#else
#include <windows.h>
#endif
#include <time.h>

/* Try to include SDL2 - support multiple header locations */
#if defined(HAVE_SDL2) || \
    defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    define SDL2_AVAILABLE 1
#    include <SDL2/SDL.h>
#  elif __has_include(<SDL.h>)
#    define SDL2_AVAILABLE 1
#    include <SDL.h>
#  else
#    define SDL2_AVAILABLE 0
#  endif
#else
/* Assume SDL2 might be available, try to include */
#  if defined(_WIN32) || defined(__MINGW32__)
#    define SDL2_AVAILABLE 1
#    include <SDL.h>
#  else
#    define SDL2_AVAILABLE 0
#  endif
#endif

/* v34.86 FIX (pre-existing since the v34.84 key-event refactor): with
 * SDL2_AVAILABLE == 0 the shared helper sdl_handle_key_event() still
 * referenced the SDL_Keycode type in its signature, so `make app` on a
 * host without SDL2 dev headers died with "unknown type name
 * 'SDL_Keycode'" (line ~802). Give the no-SDL no-op backend a dummy
 * typedef so the documented "build WITHOUT SDL" path compiles again. */
#if !SDL2_AVAILABLE
typedef int SDL_Keycode;
#endif

/* v34.88 FIX (devkitA64 "implicit declaration of 'sdl_switch_game_begin'"
* at the sdl_init call site + "'sdl_handle_key_event' defined but not used"):
* both diagnostics together mean this file was compiled WITHOUT any SDL2
* headers on the include path, so the __SWITCH__ glue section (which pulls
* switch/switch_glue.h — the declaration) was compiled out while the
* #ifdef __SWITCH__ call sites stayed. On the Switch, SDL2 is MANDATORY
* (the whole frontend is SDL2): fail loud and early with the actual cause
* instead of a cascade of unrelated errors. See the Makefile v34.88 note
* (PORTLIBS must point at $(DEVKITPRO)/portlibs/switch). */
#if defined(__SWITCH__) && !SDL2_AVAILABLE
#  error "__SWITCH__ build: SDL2 headers not found on the include path. The Switch frontend requires switch-SDL2 (dkp-pacman -S switch-SDL2). Check the PORTLIBS/SDL2 discovery in the Makefile (v34.88)."
#endif

#include "sdl_backend.h"
#include "midp.h"
#include "midi.h"
#include "debug.h"
#include "debug_macros.h"
/* v34.91 freeze triage: stage breadcrumbs — audio-open is a classic
 * emulator hang point, so the shared audio path traces too. Macro no-op
 * when neither __SWITCH__ nor NOJME_SWITCH_TRACE is defined. */
#include "switch/switch_trace.h"

/* Global context */
static SdlContext* g_sdl_ctx_ptr = NULL;

/* Mutex for thread-safe SDL access (only needed when the SDL2 backend is
 * active; without SDL2 the lock macros are never expanded, and defining the
 * mutex unconditionally trips -Wunused-variable) */
#ifdef _WIN32
#include <windows.h>
#endif

#if SDL2_AVAILABLE
#ifdef _WIN32
static CRITICAL_SECTION g_sdl_mutex;
static bool g_sdl_mutex_initialized = false;
#define SDL_LOCK() EnterCriticalSection(&g_sdl_mutex)
#define SDL_UNLOCK() LeaveCriticalSection(&g_sdl_mutex)
#else
#include <pthread.h>
static pthread_mutex_t g_sdl_mutex = PTHREAD_MUTEX_INITIALIZER;
#define SDL_LOCK() pthread_mutex_lock(&g_sdl_mutex)
#define SDL_UNLOCK() pthread_mutex_unlock(&g_sdl_mutex)
#endif
#endif /* SDL2_AVAILABLE */

#if SDL2_AVAILABLE
static SDL_Window* g_window = NULL;
static SDL_Renderer* g_renderer = NULL;
static SDL_Texture* g_texture = NULL;
static SDL_AudioDeviceID g_audio_dev = 0;

/* v34.94: audio-queue backpressure cap + device handle lock (defined here
 * so every audio function below sees them; see sdl_audio_queue_samples for
 * the freeze rationale). */
#include <pthread.h>
#define NOJME_AUDIO_QUEUE_CAP_BYTES (192 * 1024)  /* ~0.55 s @44.1 kHz stereo S16 */
static pthread_mutex_t g_audio_dev_mutex = PTHREAD_MUTEX_INITIALIZER;

/* v34.94: current game jar (set by main.c at session start) — the PLUS
 * per-game settings overlay keys off this; per-game overrides
 * (-1 = inherit the global setting). */
char g_switch_current_jar[1024] = {0};
int g_pg_scale = -1;
int g_pg_filter = -1;

/* Key mapping tables
 * 
 * ИСПРАВЛЕНО: Теперь отправляем правильные keyCode по стандарту Nokia FullCanvas:
 * - UP: keyCode = -1 (FULL_UP)
 * - DOWN: keyCode = -2 (FULL_DOWN)
 * - LEFT: keyCode = -3 (FULL_LEFT)
 * - RIGHT: keyCode = -4 (FULL_RIGHT)
 * - FIRE: keyCode = -5 (FULL_FIRE)
 * 
 * game_action используется для getGameAction() конверсии.
 * Многие игры (например Bobby Carrot) проверяют keyCode напрямую,
 * а не через getGameAction(), поэтому keyCode должен быть правильным.
 */
static const struct {
    SDL_Keycode sdl_key;
    int midp_key;       /* keyCode отправляемый в keyPressed() */
    int game_action;    /* game action для getGameAction() */
} key_map[] = {
    /* Цифры - отправляем ASCII коды */
    {SDLK_0, '0', 0}, {SDLK_1, '1', 0}, {SDLK_2, '2', 0},
    {SDLK_3, '3', 0}, {SDLK_4, '4', 0}, {SDLK_5, '5', 0},
    {SDLK_6, '6', 0}, {SDLK_7, '7', 0}, {SDLK_8, '8', 0},
    {SDLK_9, '9', 0}, {SDLK_ASTERISK, '*', 0}, {SDLK_HASH, '#', 0},
    /* Game keys - отправляем keyCode по стандарту Nokia FullCanvas */
    /* Игра Bobby Carrot проверяет: var1 == -5 || var1 == 5 || var1 == 53 для FIRE */
    {SDLK_UP, -1, GAME_UP},      /* keyCode=-1 (Nokia FULL_UP), gameAction=1 */
    {SDLK_DOWN, -2, GAME_DOWN},  /* keyCode=-2 (Nokia FULL_DOWN), gameAction=6 */
    {SDLK_LEFT, -3, GAME_LEFT},  /* keyCode=-3 (Nokia FULL_LEFT), gameAction=2 */
    {SDLK_RIGHT, -4, GAME_RIGHT},/* keyCode=-4 (Nokia FULL_RIGHT), gameAction=5 */
    {SDLK_RETURN, -5, GAME_FIRE},/* keyCode=-5 (Nokia FULL_FIRE), gameAction=8 */
    {SDLK_SPACE, -5, GAME_FIRE}, /* keyCode=-5 (Nokia FULL_FIRE), gameAction=8 */
    /* Soft buttons - F1 = Left Soft, F2 = Right Soft (по стандарту Nokia) */
    /* F1 отправляет keyCode=-6 (стандартный код левой софт-кнопки) */
    /* F2 отправляет keyCode=-7 (стандартный код правой софт-кнопки) */
    {SDLK_F1, -6, 0},            /* Left Soft Key: keyCode=-6 */
    {SDLK_F2, -7, 0},            /* Right Soft Key: keyCode=-7 */
    /* Game A/B/C/D - альтернативные клавиши (используются реже) */
    {SDLK_a, -6, GAME_A},        /* keyCode=-6, gameAction=9 */
    {SDLK_b, -7, GAME_B},        /* keyCode=-7, gameAction=10 */
    {SDLK_c, -8, GAME_C},        /* keyCode=-8, gameAction=11 */
    {SDLK_d, -9, GAME_D},        /* keyCode=-9, gameAction=12 */
    {SDLK_ESCAPE, 0, 0},
};
#define KEY_MAP_SIZE (sizeof(key_map) / sizeof(key_map[0]))

/* Software key repeat for SDL build.
 * SDL2 doesn't generate key repeat events by default.
 * Many J2ME Canvas games rely on repeated keyPressed events for
 * continuous movement. This implements the same repeat behavior as
 * real J2ME phones: initial delay ~400ms, then repeat at ~80ms interval.
 */
#define SDL_KEY_REPEAT_DELAY_MS   400
#define SDL_KEY_REPEAT_INTERVAL_MS 80
#define SDL_KEY_REPEAT_MAX_KEYS   256  /* Based on SDL_Keycode range */

static struct {
    uint64_t press_time[SDL_KEY_REPEAT_MAX_KEYS];      /* When key was first pressed */
    uint64_t last_repeat_time[SDL_KEY_REPEAT_MAX_KEYS]; /* Last repeat event time */
    bool is_held[SDL_KEY_REPEAT_MAX_KEYS];             /* Key is currently held */
} g_sdl_key_repeat = {{0}, {0}, {false}};

/* Convert SDL_Keycode to index for repeat tracking (handles negative values) */
static int sdl_key_to_repeat_idx(SDL_Keycode key) {
    /* SDL_Keycode values can be negative (e.g. SDLK_RETURN = 13)
     * Map them to positive indices by adding an offset */
    int idx = (int)key + 128;  /* Shift to make most keys positive */
    if (idx < 0) idx = 0;
    if (idx >= SDL_KEY_REPEAT_MAX_KEYS) idx = SDL_KEY_REPEAT_MAX_KEYS - 1;
    return idx;
}

/* Get current time in milliseconds */
static uint64_t sdl_get_time_ms(void) {
    return SDL_GetTicks();
}

/* Process software key repeat - call this after event handling */
static void sdl_process_key_repeat(SdlContext* ctx) {
    if (!ctx || !ctx->jvm) return;
    
    uint64_t now = sdl_get_time_ms();
    
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        SDL_Keycode key = key_map[i].sdl_key;
        int midp_key = key_map[i].midp_key;
        int game_action = key_map[i].game_action;
        
        /* Skip soft keys, escape, etc. - they should not repeat */
        if (key == SDLK_F1 || key == SDLK_F2 || key == SDLK_ESCAPE || key == SDLK_F12) {
            continue;
        }
        
        /* Skip if no valid key to send */
        if (!midp_key && !game_action) continue;
        
        int idx = sdl_key_to_repeat_idx(key);
        
        if (g_sdl_key_repeat.is_held[idx]) {
            uint64_t hold_duration = now - g_sdl_key_repeat.press_time[idx];
            uint64_t since_last = now - g_sdl_key_repeat.last_repeat_time[idx];
            
            if (hold_duration >= SDL_KEY_REPEAT_DELAY_MS &&
                since_last >= SDL_KEY_REPEAT_INTERVAL_MS) {
                /* Generate repeat event.
                 * FIX (audit M-3, v18): deliver as keyRepeated() on canvases
                 * that implement it, not as a phantom extra keyPressed(). */
                g_sdl_key_repeat.last_repeat_time[idx] = now;
                int keycode = midp_key ? midp_key : game_action;
                midp_call_keyRepeated(ctx->jvm, keycode);
            }
        }
    }
}

/* Note: Audio uses SDL_QueueAudio() for queue-based playback.
 * No callback needed - samples are generated in media.c audio thread. */

#endif /* SDL2_AVAILABLE */

/*
 * switch_glue_impl.c.txt — the __SWITCH__ section of sdl_graphics.c.
 * Inserted by scripts/switch_patch_sdl.py after the key-repeat block.
 * Everything here is compiled ONLY when __SWITCH__ is defined (real
 * devkitPro build) or in the Linux verification build (same define).
 */
#if defined(__SWITCH__) && SDL2_AVAILABLE

#include "switch/switch_glue.h"
#include "switch/switch_common.h"
#include "switch/switch_scaling.h"
#include "switch/switch_font.h"
#include "switch/switch_ui.h" /* v34.94: per-game settings overlay (PLUS) */
#include "switch/switch_trace.h" /* v34.91: freeze triage (real impl: __SWITCH__/verify) */

extern void midlet_call_destroy_app(JVM* jvm, bool unconditional);

/* defined below (extracted v34.84): shared keyboard-event handler the
 * gamepad path re-dispatches through */
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat);

/* ============================ state ============================ */

static SDL_Texture* g_ui_tex = NULL;      /* 1280x720 menu canvas */
static uint32_t* g_ui_canvas = NULL;      /* CPU side of the same */
static SDL_Texture* g_bg_tex = NULL;      /* small blurred background */
static uint32_t* g_bg_buf = NULL;
static int g_bg_w = 0, g_bg_h = 0;
static SDL_Rect g_game_rect = {0, 0, 0, 0};  /* last presented game rect */
static volatile int g_switch_game_active = 0; /* between game_begin/game_end */
static unsigned g_menu_held = 0;          /* held menu-key bitmask */

/* v34.89: RAW-JOYSTICK input replaces the GameController API.
 * switch-SDL2 exposes the pads as plain joysticks and often ships NO
 * GameController mapping: SDL_IsGameController() returns false, no
 * SDL_CONTROLLER* events are ever delivered and the frontend looks
 * completely dead (user report: controls do not work in an emulator).
 * Raw SDL_JOY* events are the devkitPro-example pattern that works on
 * real hardware AND in emulators. Joystick events only flow for OPENED
 * devices, so every pad is opened right after SDL_Init. */
#define SWITCH_JOY_SLOTS 4
static SDL_Joystick* g_joy[SWITCH_JOY_SLOTS];         /* opened pads */
static SDL_JoystickID g_joy_instance[SWITCH_JOY_SLOTS] = {-1,-1,-1,-1};
static volatile int g_switch_pause_req = 0;  /* v34.90: vestigial latch (nothing sets it
                                              * anymore - MINUS is handled inline by
                                              * the frame pump); kept for ABI/log parity */
static volatile int g_switch_pause_open = 0; /* pause menu is on screen */

/* Raw button indices of the switch-SDL2 joystick driver — libnx HID bit
 * order (A..MINUS are bits 0..11, D-pad L,U,R,D are bits 12..15). */
enum {
    SWJB_A = 0,  SWJB_B = 1,  SWJB_X = 2,  SWJB_Y = 3,
    SWJB_LSTICK = 4, SWJB_RSTICK = 5,
    SWJB_L = 6,  SWJB_R = 7,  SWJB_ZL = 8, SWJB_ZR = 9,
    SWJB_PLUS = 10, SWJB_MINUS = 11,
    SWJB_LEFT = 12, SWJB_UP = 13, SWJB_RIGHT = 14, SWJB_DOWN = 15
};

/* ---------------- v34.90 central input state ----------------
 * Single source of truth for ALL Switch input (see the full design comment
 * at switch_input_pump below). Declared before every consumer, filled only
 * by switch_input_pump() on the main/frame context. */
typedef struct {
    uint16_t held[SWITCH_JOY_SLOTS];    /* live button state (bit = SWJB_*) */
    uint16_t prev[SWITCH_JOY_SLOTS];    /* state at the previous pump */
    uint16_t latch[SWITCH_JOY_SLOTS];   /* JOYBUTTONDOWN events seen this pump */
    int      dir[SWITCH_JOY_SLOTS];     /* stick->dpad mask: 1=u 2=d 4=l 8=r */
    int      dir_prev[SWITCH_JOY_SLOTS];
    unsigned kb_edge;                   /* keyboard press edges this pump */
    unsigned kb_held;                   /* keyboard held bits */
    int      touch_x, touch_y;          /* window pixels (SWITCH_UI_*) */
    int      touch_down;
    int      touch_moved;               /* FINGERMOTION seen while down */
    int      quit;                      /* SDL_QUIT seen this pump */
} SwitchInputState;

static SwitchInputState g_sw_in;

static void switch_input_reset(void) {
    memset(&g_sw_in, 0, sizeof(g_sw_in));
}

/* Acknowledge the CURRENT held state without firing edges (pause-menu
 * open/close): a button held THROUGH the menu must not re-press when the
 * game resumes. */
static void switch_input_settle(void) {
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        g_sw_in.prev[i] = g_sw_in.held[i];
        g_sw_in.latch[i] = 0;
        g_sw_in.dir_prev[i] = g_sw_in.dir[i];
    }
    g_sw_in.kb_edge = 0;
    g_sw_in.touch_moved = 0;
}

/* Event instance-id -> slot (events only arrive for OPENED pads). */
static int switch_joy_slot(SDL_JoystickID id) {
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++)
        if (g_joy[i] && g_joy_instance[i] == id) return i;
    return -1;
}

/* Open device `idx' into a free slot (idempotent for already-open pads). */
static void switch_joy_open_index(int idx) {
    if (idx < 0 || idx >= SDL_NumJoysticks()) return;
#if SDL_VERSION_ATLEAST(2, 0, 14)
    {   /* SDL2 queues SDL_JOYDEVICEADDED for pads present at SDL_Init —
         * skip the duplicate open when the direct init-time open won. */
        SDL_JoystickID iid = SDL_JoystickGetDeviceInstanceID(idx);
        if (iid >= 0 && switch_joy_slot(iid) >= 0) return;
    }
#endif
    int slot = -1;
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) if (!g_joy[i]) { slot = i; break; }
    if (slot < 0) return;
    g_joy[slot] = SDL_JoystickOpen(idx);
    if (g_joy[slot]) {
        SDL_JoystickID new_iid = SDL_JoystickInstanceID(g_joy[slot]);
        /* v34.90: if ANOTHER slot already holds this instance, the same
         * physical pad is being opened a second time (the init-time open
         * won and the queued SDL_JOYDEVICEADDED was processed on an SDL
         * older than 2.0.14, where the GetDeviceInstanceID guard above is
         * compiled out). A pad opened twice double-fires every event;
         * close the duplicate immediately. */
        for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
            if (i != slot && g_joy[i] && g_joy_instance[i] == new_iid) {
                SDL_JoystickClose(g_joy[slot]);
                g_joy[slot] = NULL;
                LOG_SAFE("[SWITCH] joystick device %d already open in slot %d - duplicate closed\n",
                         idx, i);
                return;
            }
        }
        g_joy_instance[slot] = new_iid;
        const char* nm = SDL_JoystickName(g_joy[slot]);
        LOG_SAFE("[SWITCH] joystick slot %d (device %d) open: %s\n",
                 slot, idx, nm ? nm : "(unnamed)");
    } else {
        LOG_SAFE("[SWITCH] joystick slot %d (device %d) open FAILED\n", slot, idx);
    }
}

/* SDL_JOYDEVICEADDED / SDL_JOYDEVICEREMOVED (rails attach/detach, pads).
 * ADDED carries a device INDEX, REMOVED an instance id (SDL2 semantics). */
static void switch_joy_hotplug(const SDL_Event* e) {
    if (e->type == SDL_JOYDEVICEADDED) {
        switch_joy_open_index(e->jdevice.which);
        return;
    }
    if (e->type == SDL_JOYDEVICEREMOVED) {
        int slot = switch_joy_slot(e->jdevice.which);
        if (slot >= 0) {
            SDL_JoystickClose(g_joy[slot]);
            g_joy[slot] = NULL;
            g_joy_instance[slot] = -1;
            /* v34.90: clear the slot in the central input state as well */
            g_sw_in.held[slot] = g_sw_in.prev[slot] = g_sw_in.latch[slot] = 0;
            g_sw_in.dir[slot] = g_sw_in.dir_prev[slot] = 0;
            LOG_SAFE("[SWITCH] joystick slot %d removed\n", slot);
        }
    }
}

/* ======================= platform bootstrap ======================= */

int sdl_switch_platform_init(void) {
    static int done = 0;
    if (done) return g_window ? 0 : -1;
    done = 1;

    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"); /* linear filtering */
    /* v34.89: SDL_INIT_JOYSTICK, not GAMECONTROLLER — raw SDL_JOY* events
     * are the only input path that works on every switch-SDL2 setup.
     * v34.91: + SDL_INIT_TIMER — the freeze-triage heartbeat (see
     * switch_trace.c) rides an SDL timer thread. */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS |
                 SDL_INIT_JOYSTICK | SDL_INIT_TIMER) != 0) {
        LOG_SAFE("[SWITCH] SDL_Init failed: %s\n", SDL_GetError());
        return -1;
    }
#ifdef __SWITCH__
    g_window = SDL_CreateWindow("J2ME Emulator",
                                SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                                SDL_WINDOW_FULLSCREEN);
#else
    /* verification build: windowed, resizable off, same geometry */
    g_window = SDL_CreateWindow("nojme Switch UI (verify)",
                                SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                                SDL_WINDOW_SHOWN);
#endif
    if (!g_window) {
        LOG_SAFE("[SWITCH] window failed: %s\n", SDL_GetError());
        return -1;
    }
    g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_ACCELERATED);
    if (!g_renderer) {
        g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_SOFTWARE);
    }
    if (!g_renderer) {
        LOG_SAFE("[SWITCH] renderer failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(g_window);
        g_window = NULL;
        SDL_Quit();
        return -1;
    }
    g_ui_tex = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
                                 SDL_TEXTUREACCESS_STREAMING,
                                 SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT);
    if (!g_ui_tex) {
        LOG_SAFE("[SWITCH] UI texture failed: %s\n", SDL_GetError());
        return -1;
    }
    SDL_SetTextureBlendMode(g_ui_tex, SDL_BLENDMODE_BLEND);
    g_ui_canvas = (uint32_t*)malloc((size_t)SWITCH_UI_WIDTH * SWITCH_UI_HEIGHT * 4);
    if (!g_ui_canvas) return -1;

    /* v34.89: open up to SWITCH_JOY_SLOTS raw pads — joystick events are
     * delivered only for OPENED devices (1 combined pad in handheld
     * mode, 2 when the joy-cons are paired separately, up to 4 pads). */
    for (int i = 0; i < SDL_NumJoysticks() && i < SWITCH_JOY_SLOTS; i++) {
        switch_joy_open_index(i);
    }
    if (SDL_NumJoysticks() <= 0) {
        LOG_SAFE("[SWITCH] no joystick detected (keyboard fallback active)\n");
    }
    LOG_SAFE("[SWITCH] platform init OK (%s renderer)\n",
             SDL_GetCurrentVideoDriver());
    return 0;
}

void sdl_switch_platform_shutdown(void) {
    /* v35.13 EXIT BREADCRUMBS: the user's device log ends at the last
     * session line when the exit path crashes — every teardown step now
     * names itself in the trace (sw_trace = raw write, survives crashes),
     * so the NEXT report pinpoints the faulting stage exactly. The
     * heartbeat timer stays alive until just before SDL_Quit() (the trace
     * sink is a raw fd, safe during the destroys; the v34.95 host-build
     * wedge involved stdio, not this path). */
    sw_trace("exit: sdl begin");
#define ET_MARK(name) do { sw_trace("exit: %s", name); } while (0)
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        if (g_joy[i]) { SDL_JoystickClose(g_joy[i]); g_joy[i] = NULL; }
    }
    ET_MARK("joysticks closed");
    if (g_ui_tex) { SDL_DestroyTexture(g_ui_tex); g_ui_tex = NULL; }
    free(g_ui_canvas); g_ui_canvas = NULL;
    ET_MARK("texture freed");
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    ET_MARK("renderer destroyed");
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    ET_MARK("window destroyed");
    sw_trace("exit: sdl teardown ok, quitting");
    sw_trace_shutdown();
    SDL_Quit();
#undef ET_MARK
}

/* ======================= menu canvas / input ======================= */

uint32_t* sdl_switch_ui_canvas(void) { return g_ui_canvas; }

static unsigned kb_key_bit(const SDL_Event* e) {
    switch (e->key.keysym.sym) {
        case SDLK_UP:    return SWK_UP;
        case SDLK_DOWN:  return SWK_DOWN;
        case SDLK_LEFT:  return SWK_LEFT;
        case SDLK_RIGHT: return SWK_RIGHT;
        case SDLK_RETURN:
        case SDLK_KP_ENTER:
        case SDLK_SPACE: return SWK_A;
        case SDLK_ESCAPE:
        case SDLK_BACKSPACE: return SWK_B;
        case SDLK_q:     return SWK_EXIT;
        default: return 0;
    }
}

/* ==================== v34.90 SINGLE-PUMP input ====================
 * FORENSICS (user report: «кнопки сразу работали, но затем перестали, я так
 * и не смог попасть ни в один из пунктов меню — возможно ВМ перехватывает
 * события»): v34.89 still drained the SDL queue from TWO places during a
 * game — the frame pump (sdl_process_events) AND the game-thread pump
 * (sdl_process_events_minimal, called from thread_yield() every ~16k
 * opcodes MID-BYTECODE on a yielding VM fiber, plus from Thread.sleep).
 * The game-thread pump re-dispatched soft keys (X/B ->
 * midp_handle_soft_button), FIRE while a command menu was open and EVERY
 * touch event through paths that execute JAVA directly
 * (call_command_action / pointerPressed -> execute_method) RE-ENTRANTLY
 * from the middle of the yield — corrupting interpreter state and/or
 * leaving the command menu stuck open, after which it swallows every
 * FIRE/UP/DOWN («не смог попасть ни в один из пунктов меню»). That is
 * exactly «ВМ перехватывает события».
 *
 * FIX (the user's own suggestion — «лучше забирать их из одного места»):
 * ONE pump owns the SDL queue on __SWITCH__. switch_input_pump() runs only
 * on the main/frame context: the frontend menu loop, the frame pump, the
 * pause menu and the finished screen. The game thread (Thread.sleep /
 * thread_yield) NEVER touches SDL events — sdl_process_events_minimal()
 * is a no-op on __SWITCH__, so mid-bytecode re-entrant Java execution is
 * impossible by construction. Input reaches a game with at most one frame
 * (~16 ms) of latency.
 *
 * ROBUSTNESS (the «then they stopped» insurance): press edges are
 * EVENT-FIRST (SDL_JOYBUTTONDOWN latches — a tap shorter than one pump
 * interval still registers) plus STATE-REPAIR (SDL_JoystickGetButton
 * ground truth on every pump — lost, duplicated or swallowed events
 * self-heal on the next pump). Stick->dpad uses hysteresis (enter past
 * 0.50, exit below 0.35) so threshold jitter cannot spam direction edges. */
/* THE pump: drain the queue, refresh ground-truth pad state, derive edges.
 * Press edge  per button = (held | latch) & ~prev   — a full tap inside one
 * pump interval still counts (latch), a lost event still counts (state).
 * Release edge per button = ~held & (prev | latch).  All state lives in one
 * struct updated ONLY from the main/frame context — no locking needed. */
static void switch_frontend_keys_tick(void); /* v35.10 fwd: sandbox FRONT_KEYS */

static void switch_input_pump(void) {
    __sync_fetch_and_add(&g_sd_pump, 1); /* v34.94 diag */
    g_sw_in.quit = 0;
    g_sw_in.touch_moved = 0;
    g_sw_in.kb_edge = 0;
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) g_sw_in.latch[i] = 0;

    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        switch (e.type) {
            case SDL_QUIT:
                g_sw_in.quit = 1;
                break;
            case SDL_JOYDEVICEADDED:
            case SDL_JOYDEVICEREMOVED:
                switch_joy_hotplug(&e);
                break;
            case SDL_JOYBUTTONDOWN:
                if (e.jbutton.button < 16) {
                    for (int i = 0; i < SWITCH_JOY_SLOTS; i++)
                        if (g_joy[i] && g_joy_instance[i] == e.jbutton.which)
                            g_sw_in.latch[i] |= (uint16_t)(1u << e.jbutton.button);
                }
                break;
            case SDL_KEYDOWN:
            case SDL_KEYUP: {
                unsigned bit = kb_key_bit(&e);
                if (bit) {
                    if (e.type == SDL_KEYDOWN) {
                        if (!e.key.repeat) g_sw_in.kb_edge |= bit;
                        g_sw_in.kb_held |= bit;
                    } else {
                        g_sw_in.kb_held &= ~bit;
                    }
                }
                break;
            }
            case SDL_FINGERDOWN:
            case SDL_FINGERUP:
            case SDL_FINGERMOTION:
                g_sw_in.touch_x = (int)(e.tfinger.x * SWITCH_UI_WIDTH);
                g_sw_in.touch_y = (int)(e.tfinger.y * SWITCH_UI_HEIGHT);
                if (e.type == SDL_FINGERDOWN) g_sw_in.touch_down = 1;
                if (e.type == SDL_FINGERUP)   g_sw_in.touch_down = 0;
                if (e.type == SDL_FINGERMOTION && g_sw_in.touch_down)
                    g_sw_in.touch_moved = 1;
                break;
            default:
                break; /* drained and ignored (MOUSE*, AXIS, WINDOWEVENT...) */
        }
    }

    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        if (!g_joy[i]) {
            g_sw_in.prev[i] = g_sw_in.held[i] = 0;
            g_sw_in.dir_prev[i] = g_sw_in.dir[i] = 0;
            continue;
        }
        uint16_t h = 0;
        for (int b = 0; b < 16; b++)
            if (SDL_JoystickGetButton(g_joy[i], b)) h |= (uint16_t)(1u << b);
        g_sw_in.prev[i] = g_sw_in.held[i];
        g_sw_in.held[i] = h;

        /* stick -> dpad with hysteresis: enter past 0.50, exit below 0.35 */
        float ax = (float)SDL_JoystickGetAxis(g_joy[i], 0) / 32767.0f;
        float ay = (float)SDL_JoystickGetAxis(g_joy[i], 1) / 32767.0f;
        int dir = g_sw_in.dir[i];
        if (ax < -0.50f) dir |= 4; else if (ax > -0.35f) dir &= ~4;
        if (ax >  0.50f) dir |= 8; else if (ax <  0.35f) dir &= ~8;
        if (ay < -0.50f) dir |= 1; else if (ay > -0.35f) dir &= ~1;
        if (ay >  0.50f) dir |= 2; else if (ay <  0.35f) dir &= ~2;
        g_sw_in.dir_prev[i] = g_sw_in.dir[i];
        g_sw_in.dir[i] = dir;
    }

    /* v35.10: synthetic frontend-button edges (sandbox repro harness,
     * no-op unless NOJME_FRONT_KEYS is set). Runs AFTER the SDL drain so
     * the injected latch is seen by this pump's consumers. */
    switch_frontend_keys_tick();
}

/* ================= v35.10 sandbox frontend-button script =================
 * NOJME_FRONT_KEYS="MINUS:12000,B:800" — real frontend button EDGES
 * (SWJB_* bits) injected into the central pump state on a wall-clock
 * schedule: drives the in-game MINUS pause menu, the PLUS per-game screen
 * and their A/B buttons exactly like a thumb would (NOJME_SWITCH_KEYS only
 * reaches the frontend menu, NOJME_GAME_KEYS only reaches the MIDP key
 * queue). Token "BIT:delay" = press `delay` ms AFTER the previous token
 * (the first token is delayed from process start), so a script is stable
 * regardless of when the first pump happens. Sandbox-only repro driver
 * for the v35.10 exit deadlock; zero effect unless the env var is set
 * (production never sets it). */
static struct {
    int      armed;       /* env seen and parsed */
    int      done;        /* script exhausted / malformed */
    int      pending_bit; /* parsed token waiting for its due time (-1 = none) */
    uint64_t next_at;     /* when pending_bit fires */
    int      pos;         /* parse cursor */
    char     script[192]; /* own copy of the env */
} g_fk;

static int fk_key_bit(const char* key) {
    if      (!strcmp(key, "A"))     return SWJB_A;
    else if (!strcmp(key, "B"))     return SWJB_B;
    else if (!strcmp(key, "X"))     return SWJB_X;
    else if (!strcmp(key, "Y"))     return SWJB_Y;
    else if (!strcmp(key, "L"))     return SWJB_L;
    else if (!strcmp(key, "R"))     return SWJB_R;
    else if (!strcmp(key, "PLUS"))  return SWJB_PLUS;
    else if (!strcmp(key, "MINUS")) return SWJB_MINUS;
    else if (!strcmp(key, "UP"))    return SWJB_UP;
    else if (!strcmp(key, "DOWN"))  return SWJB_DOWN;
    else if (!strcmp(key, "LEFT"))  return SWJB_LEFT;
    else if (!strcmp(key, "RIGHT")) return SWJB_RIGHT;
    return -1;
}

static void switch_frontend_keys_tick(void) {
    if (!g_fk.armed) {
        const char* env = getenv("NOJME_FRONT_KEYS");
        g_fk.armed = 1;
        g_fk.pending_bit = -1;
        if (env && env[0]) {
            snprintf(g_fk.script, sizeof(g_fk.script), "%s", env);
            g_fk.pos = 0;
            g_fk.next_at = 0;
            LOG_SAFE("[FRONTKEYS] script active: %.64s\n", g_fk.script);
        } else {
            g_fk.done = 1; /* no script */
        }
    }
    if (g_fk.done) return;
    uint64_t now = sdl_get_time_ms();
    if (g_fk.pending_bit < 0) {
        /* parse the next token and schedule it */
        char key[16] = {0};
        int delay = 0, consumed = 0;
        if (sscanf(g_fk.script + g_fk.pos, "%15[^:]:%d%n", key, &delay, &consumed) >= 2 &&
            consumed > 0) {
            g_fk.pos += consumed;
            while (g_fk.script[g_fk.pos] == ',' || g_fk.script[g_fk.pos] == ' ') g_fk.pos++;
            if (delay < 20) delay = 20;
            int bit = fk_key_bit(key);
            if (bit < 0) {
                LOG_SAFE("[FRONTKEYS] unknown key '%s' - stop\n", key);
                g_fk.done = 1;
                return;
            }
            g_fk.pending_bit = bit;
            g_fk.next_at = now + (uint64_t)delay;
        } else {
            g_fk.done = 1; /* exhausted / malformed */
        }
        return;
    }
    if (now < g_fk.next_at) return;
    /* due: one-pump press edge (latch is cleared at the next pump start) */
    LOG_SAFE("[FRONTKEYS] press bit %d at +%llu ms\n",
             g_fk.pending_bit, (unsigned long long)(now - g_fk.next_at));
    g_sw_in.latch[0] |= (uint16_t)(1u << g_fk.pending_bit);
    g_fk.pending_bit = -1;
}

/* ================= v35.09 sandbox in-game key script =================
 * NOJME_GAME_KEYS="-5:300,-1:150,-5:2000" — raw MIDP keycodes driven from
 * the frame pump through the SAME deferred queue real pad keys use
 * (midp_call_keyPressed/Released). Token "code:delay" = press, hold for
 * `delay` ms, release; the next token starts after that. Lets the
 * switchui-verify sandbox drive a game's OWN menu/race (the NOJME_SWITCH_KEYS
 * driver only reaches the frontend menu). Zero effect unless the env var is
 * set (production never sets it). */
static struct {
    int          armed;        /* env seen and parsed */
    int          hold_code;    /* key currently held by the script (0 = none) */
    uint64_t     hold_until;   /* release time for hold_code */
    uint64_t     next_at;      /* when the next token may fire */
    int          pos;          /* parse cursor */
    char         script[512];  /* own copy of the env */
} g_gk;

static void switch_game_keys_tick(SdlContext* ctx) {
    if (!ctx || !ctx->jvm) return;
    if (!g_gk.armed) {
        const char* env = getenv("NOJME_GAME_KEYS");
        g_gk.armed = 1;
        if (env && env[0]) {
            snprintf(g_gk.script, sizeof(g_gk.script), "%s", env);
            g_gk.pos = 0;
            g_gk.next_at = 0;
            LOG_SAFE("[GAMEKEYS] script active: %.64s\n", g_gk.script);
        }
        if (!g_gk.script[0]) { g_gk.hold_code = INT_MIN; } /* mark: nothing to do */
    }
    if (g_gk.hold_code == INT_MIN) return; /* no script */

    uint64_t now = sdl_get_time_ms();
    if (g_gk.hold_code != 0 && now >= g_gk.hold_until) {
        extern void midp_call_keyReleased(JVM* jvm, int keycode);
        midp_call_keyReleased(ctx->jvm, g_gk.hold_code);
        LOG_SAFE("[GAMEKEYS] release %d\n", g_gk.hold_code);
        g_gk.hold_code = 0;
        g_gk.next_at = now; /* next token immediately after release */
    }
    if (g_gk.hold_code != 0 || now < g_gk.next_at) return;

    int code = 0, delay = 0, consumed = 0;
    if (sscanf(g_gk.script + g_gk.pos, "%d:%d%n", &code, &delay, &consumed) >= 2 &&
        consumed > 0 && code != 0) {
        g_gk.pos += consumed;
        while (g_gk.script[g_gk.pos] == ',' || g_gk.script[g_gk.pos] == ' ') g_gk.pos++;
        if (delay < 20) delay = 20; /* one frame minimum so the queue sees it */
        extern void midp_call_keyPressed(JVM* jvm, int keycode);
        midp_call_keyPressed(ctx->jvm, code);
        LOG_SAFE("[GAMEKEYS] press %d for %d ms\n", code, delay);
        g_gk.hold_code = code;
        g_gk.hold_until = now + (uint64_t)delay;
    } else {
        g_gk.hold_code = INT_MIN; /* script exhausted / malformed: stop */
    }
}

unsigned sdl_switch_ui_pump_keys(void) {
    switch_input_pump();
    unsigned pressed = 0;
    unsigned held = 0;
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        uint16_t pe = (uint16_t)((g_sw_in.held[i] | g_sw_in.latch[i]) & ~g_sw_in.prev[i]);
        uint16_t h  = g_sw_in.held[i];
        int de = g_sw_in.dir[i] & ~g_sw_in.dir_prev[i]; /* stick edges navigate too */
        if (pe & (1u << SWJB_UP))    pressed |= SWK_UP;
        if (pe & (1u << SWJB_DOWN))  pressed |= SWK_DOWN;
        if (pe & (1u << SWJB_LEFT))  pressed |= SWK_LEFT;
        if (pe & (1u << SWJB_RIGHT)) pressed |= SWK_RIGHT;
        if (pe & ((1u << SWJB_A) | (1u << SWJB_PLUS))) pressed |= SWK_A;
        if (pe & (1u << SWJB_B))     pressed |= SWK_B;
        if (pe & (1u << SWJB_MINUS)) pressed |= SWK_MINUS; /* v34.90: язык */
        if (de & 1) pressed |= SWK_UP;
        if (de & 2) pressed |= SWK_DOWN;
        if (de & 4) pressed |= SWK_LEFT;
        if (de & 8) pressed |= SWK_RIGHT;
        if (h & (1u << SWJB_UP))    held |= SWK_UP;
        if (h & (1u << SWJB_DOWN))  held |= SWK_DOWN;
        if (h & (1u << SWJB_LEFT))  held |= SWK_LEFT;
        if (h & (1u << SWJB_RIGHT)) held |= SWK_RIGHT;
        if (h & ((1u << SWJB_A) | (1u << SWJB_PLUS))) held |= SWK_A;
        if (h & (1u << SWJB_B))     held |= SWK_B;
    }
    pressed |= g_sw_in.kb_edge;
    if (g_sw_in.quit) pressed |= SWK_EXIT;
    /* v34.90: held is the LIVE pad state — valid on EVERY call (v34.89 kept
     * it only in the pump that happened to see the DOWN event, so browser
     * hold-to-repeat could never engage). */
    g_menu_held = held | g_sw_in.kb_held;
    return pressed;
}

unsigned sdl_switch_ui_held_keys(void) { return g_menu_held; }

/* v34.98 SDL RENDER-THREAD GUARD — "вся отрисовка SDL только в основном
 * потоке". SDL's renderer API is officially single-threaded; the reference
 * thread is armed by sdl_init()/sdl_run() (the main loop thread) and every
 * render entry point verifies the caller. A violation is throttled to one
 * line per 10 s so a looping offender cannot flood the log. */
#ifdef _WIN32
static volatile long g_sdl_render_tid = 0;
static volatile int  g_sdl_render_tid_valid = 0;
static void sdl_render_thread_arm(void) {
    g_sdl_render_tid = (long)GetCurrentThreadId();
    g_sdl_render_tid_valid = 1;
}
static void sdl_render_thread_check(const char* site) {
    if (!g_sdl_render_tid_valid) return;
    if ((long)GetCurrentThreadId() != g_sdl_render_tid) {
        static volatile long long s_last_viol_ms = 0;
        long long now = (long long)GetTickCount64();
        if (now - s_last_viol_ms >= 10000) {
            s_last_viol_ms = now;
            LOG_SAFE("[SDL-THREAD-VIOLATION] %s called OUTSIDE the render thread "
                     "(SDL rendering must stay on the main thread)\n", site);
        }
    }
}
#else
#include <pthread.h>
static pthread_t g_sdl_render_pt;
static volatile int g_sdl_render_pt_valid = 0;
static void sdl_render_thread_arm(void) {
    g_sdl_render_pt = pthread_self();
    g_sdl_render_pt_valid = 1;
}
static void sdl_render_thread_check(const char* site) {
    if (!g_sdl_render_pt_valid) return;
    if (!pthread_equal(pthread_self(), g_sdl_render_pt)) {
        static volatile long long s_last_viol_ms = 0;
        long long now = (long long)SDL_GetTicks();
        if (now - s_last_viol_ms >= 10000) {
            s_last_viol_ms = now;
            LOG_SAFE("[SDL-THREAD-VIOLATION] %s called OUTSIDE the render thread "
                     "(SDL rendering must stay on the main thread)\n", site);
        }
    }
}
#endif

void sdl_switch_ui_present(void) {
    if (!g_ui_tex || !g_renderer || !g_ui_canvas) return;
    sdl_render_thread_check("ui_present");
    SDL_UpdateTexture(g_ui_tex, NULL, g_ui_canvas,
                      SWITCH_UI_WIDTH * sizeof(uint32_t));
    SDL_RenderClear(g_renderer);
    SDL_RenderCopy(g_renderer, g_ui_tex, NULL, NULL);
    SDL_RenderPresent(g_renderer);
}

static uint64_t switch_ticks_ms(void) {
    static Uint64 freq = 0;
    if (!freq) freq = SDL_GetPerformanceFrequency();
    Uint64 c = SDL_GetPerformanceCounter();
    return freq ? (uint64_t)(c * 1000ULL / freq) : SDL_GetTicks();
}

uint64_t sdl_switch_ui_ticks_ms(void) { return switch_ticks_ms(); }

void sdl_switch_ui_wait(uint32_t ms) { SDL_Delay(ms); }

/* ================= v35.13 LOADING SCREEN =================
 * A fresh session has NO settled frame until the midlet completes its
 * first paint. On a VM-paced loader (field case: 3D Asia Rally at
 * "Обычная" speed) that takes tens of seconds; before v35.13 the
 * presenter kept scanning out the PREVIOUS midlet's last settled frame
 * (the session-reset in display.c now also clears that snapshot), which
 * looked exactly like "the game did not load". Instead we compose a
 * private black frame: "Загрузка <имя> (N с)" +, when the budget pacer
 * is eating the VM wall time, the remedy hint. The screen disappears by
 * itself on the first settled frame of the session. */
static uint64_t s_loadscr_begin_ms = 0;    /* session begin tick (0 = none) */
static int s_loadscr_on = 0;               /* last present composed loading */
static int s_loadscr_traced_on = 0;
static int s_loadscr_traced_off = 0;

static void sdl_switch_compose_loading_frame(uint32_t* dst, int w, int h) {
    char title[96];
    char name[160];
    const char* hint1 = NULL;
    const char* hint2 = NULL;
    unsigned secs;
    int cx;

    memset(dst, 0, (size_t)w * (size_t)h * sizeof(uint32_t));
    if (w < 96 || h < 96) return; /* degenerate fb — plain black is fine */

    secs = (unsigned)((switch_ticks_ms() - s_loadscr_begin_ms) / 1000u);
    snprintf(title, sizeof(title), "%s... (%u %s)", switch_text(ST_LOADING),
             secs, switch_text(ST_LOADING_SEC));

    /* short jar name from the session path set by main.c */
    {
        const char* jar = g_switch_current_jar;
        const char* slash = jar[0] ? strrchr(jar, '/') : NULL;
        const char* nm = slash ? slash + 1 : jar;
        snprintf(name, sizeof(name), "%.150s", nm); /* explicit clamp */
    }

    /* v35.13: the VM-paced remedy hint (weak extern — same pattern as
     * the settled-frame primitives; absent in white-box test links). */
    {
        extern int jvm_vmpace_active(void) __attribute__((weak));
        if (jvm_vmpace_active && jvm_vmpace_active()) {
            hint1 = switch_text(ST_LOADING_VM1);
            hint2 = switch_text(ST_LOADING_VM2);
        }
    }

    /* title at 2x, centered */
    cx = (w - switch_font_text_width(title, 2)) / 2;
    if (cx < 0) cx = 0;
    switch_font_draw_text(dst, w, h, cx, h / 2 - 48, title, 0xFFFFFFFFu, 0, 2);
    /* jar name at 1x, centered, clipped to the screen */
    cx = (w - switch_font_text_width(name, 1)) / 2;
    if (cx < 0) cx = 0;
    switch_font_draw_text(dst, w, h, cx, h / 2 + 8, name, 0xFF80C8FFu, 0, 1);
    /* pacing hint (only while the pacer dominates the VM wall time) */
    if (hint1) {
        cx = (w - switch_font_text_width(hint1, 1)) / 2;
        if (cx < 0) cx = 0;
        switch_font_draw_text(dst, w, h, cx, h / 2 + 40, hint1, 0xFFB0B0B0u, 0, 1);
    }
    if (hint2) {
        cx = (w - switch_font_text_width(hint2, 1)) / 2;
        if (cx < 0) cx = 0;
        switch_font_draw_text(dst, w, h, cx, h / 2 + 60, hint2, 0xFFB0B0B0u, 0, 1);
    }
}

int sdl_switch_game_begin(int fb_w, int fb_h) {
    if (!g_renderer) return -1;
    sdl_render_thread_check("game_begin");
    sw_trace("game: begin %dx%d", fb_w, fb_h); /* v34.91 */
    /* v35.13: loading-screen bookkeeping — the session starts with NO
     * settled frame; until the first one lands we compose a black
     * "Загрузка ..." frame instead of scanning out stale content. */
    s_loadscr_begin_ms = switch_ticks_ms();
    s_loadscr_on = 0;
    s_loadscr_traced_on = 0;
    s_loadscr_traced_off = 0;
    if (g_switch_game_active) {
        /* v34.98: a mid-session recreation is the prime suspect behind
         * corrupted-frame moments; make it LOUD if it ever happens. */
        LOG_SAFE("[SURFACE-RECREATE] game_begin while session active: %dx%d\n", fb_w, fb_h);
    }
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }

    /* v34.94: per-game overrides (PLUS menu) — loaded by main.c at session
     * start into g_pg_scale/g_pg_filter (-1 = inherit global). */
    const SwitchSettings* st = switch_settings_get();
    int eff_filter = (g_pg_filter >= 0) ? g_pg_filter : st->filter;
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY,
                eff_filter == NOJME_FILTER_LINEAR ? "1" : "0");

    g_texture = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
                                  SDL_TEXTUREACCESS_STREAMING, fb_w, fb_h);
    if (!g_texture) {
        LOG_SAFE("[SWITCH] game texture %dx%d failed: %s\n",
                 fb_w, fb_h, SDL_GetError());
        return -1;
    }
    switch_scaling_bg_size(fb_w, fb_h, &g_bg_w, &g_bg_h);
    if (g_bg_tex) { SDL_DestroyTexture(g_bg_tex); g_bg_tex = NULL; }
    g_bg_tex = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
                                 SDL_TEXTUREACCESS_STREAMING, g_bg_w, g_bg_h);
    free(g_bg_buf);
    g_bg_buf = (uint32_t*)malloc((size_t)g_bg_w * g_bg_h * sizeof(uint32_t));
    if (!g_bg_buf) {
        LOG_SAFE("[SWITCH] blur bg buffer malloc FAILED (%dx%d) — blur disabled\n",
                 g_bg_w, g_bg_h);
    }
    g_switch_game_active = 1;
    switch_input_reset(); /* v34.90: no edges leak across the menu->game seam */
    g_game_rect.x = g_game_rect.y = g_game_rect.w = g_game_rect.h = 0;
    LOG_SAFE("[SWITCH] game session %dx%d (scale=%d filter=%d bg=%dx%d)\n",
             fb_w, fb_h, st->scale_mode, st->filter, g_bg_w, g_bg_h);
    return 0;
}

void sdl_switch_game_end(void) {
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_bg_tex) { SDL_DestroyTexture(g_bg_tex); g_bg_tex = NULL; }
    free(g_bg_buf); g_bg_buf = NULL;
    g_switch_game_active = 0;
    s_loadscr_begin_ms = 0; /* v35.13 */
    s_loadscr_on = 0;
    switch_input_reset(); /* v34.90: the frontend menu starts from clean edges */
    /* close any game audio so the menu is silent */
    if (g_audio_dev) { SDL_CloseAudioDevice(g_audio_dev); g_audio_dev = 0; }
    LOG_SAFE("[SWITCH] game session end\n");
}

/* ======================= present with scaling ======================= */

/* v34.94 diag: settled-frame version bookkeeping for skip=/fl= counters. */
static uint32_t s_switch_frame_version_seen = 0;
static int s_switch_frame_version_advanced = 0;

static void sdl_switch_present_game(SdlContext* ctx) {
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) return;
    sdl_render_thread_check("present_game");

    /* v35.01: present-cost telemetry — the v35.00 trace froze with the
     * frontend loop alive but over budget (stl 0 -> 1299 ms/period, loop
     * 300 -> 222) and the blur border visibly updating while the game view
     * froze. pv/pk/pw split the loop cost into RenderPresent vs the whole
     * present so the next trace names the stalled stage directly. */
    struct timespec pw_t0, pv_t1, pv_t2;
    clock_gettime(CLOCK_MONOTONIC, &pw_t0);

    const SwitchSettings* st = switch_settings_get();
    int eff_scale = (g_pg_scale >= 0) ? g_pg_scale : st->scale_mode;
    int x, y, w, h;
    switch_scaling_game_rect(eff_scale, ctx->width, ctx->height,
                             SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT, &x, &y, &w, &h);
    g_game_rect.x = x; g_game_rect.y = y; g_game_rect.w = w; g_game_rect.h = h;

    /* v35.06 PHONE-FAITHFUL DIRECT-RENDER DELIVERY ("кадры не отбрасываются
     * при финальном выводе"): before resolving the scanout source, deliver
     * any content the game drew into the live framebuffer OUTSIDE the
     * repaint pump (a Graphics cached from an earlier paint / direct
     * rendering). On a real phone that drawing hits the LCD immediately;
     * the settled-frame model used to withhold it until the next pump
     * paint. Gated by midp_canvas_mid_frame() — never fires inside a
     * paint() or an open M3G bind, so the torn-3D-frame class stays
     * impossible; at most one extra settle per frontend frame.
     *   dset = how often this path delivered (0 on pump-paced games);
     *   lvc  = how often the live framebuffer changed at all, so the diag
     *          can prove lvc == fl ("nothing dropped") per period. */
    {
        extern int midp_present_settle_if_stale(void) __attribute__((weak));
        extern int midp_present_live_changed(void) __attribute__((weak));
        if (midp_present_settle_if_stale && midp_present_settle_if_stale())
            __sync_fetch_and_add(&g_sd_dset, 1);
        if (midp_present_live_changed && midp_present_live_changed())
            __sync_fetch_and_add(&g_sd_lvc, 1);
    }

    /* v35.01 SINGLE-SOURCE PRESENT ("вывод на экран из того же источника,
     * что и блюр"): resolve the frame source ONCE and feed BOTH consumers —
     * the game texture and the blurred border fill. Since v34.98 both read
     * the settled snapshot, but each ran its own stable_copy: two lock
     * round-trips per frame and a theoretical divergence window when a
     * settle lands between them. Now one copy per frame, one decision,
     * zero divergence — and the sharp image can never lag the blur.
     * Semantics unchanged (v34.61): the latest SETTLED snapshot when one
     * exists; the live framebuffer only as the nothing-settled bootstrap. */
    static uint32_t* s_scanout = NULL;
    static int s_scanout_px = 0;
    const uint32_t* present_src = ctx->framebuffer;
    {
        extern uint32_t midp_present_stable_copy(uint32_t* dst, int dst_px);
        int px = ctx->width * ctx->height;
        if (px > 0 && px <= 8192 * 8192) {
            if (px > s_scanout_px) {
                uint32_t* nb = (uint32_t*)realloc(s_scanout,
                                                  (size_t)px * sizeof(uint32_t));
                if (nb) { s_scanout = nb; s_scanout_px = px; }
            }
            if (s_scanout && midp_present_stable_copy(s_scanout, px) != 0)
                present_src = s_scanout;
        }
    }

    /* v35.13 LOADING SCREEN: while THIS session has not completed a single
     * settled frame (stable_copy returned 0 => present_src is still the
     * live bootstrap), present a private black "Загрузка <jar> (N s)"
     * frame. The stale-frame class this kills:
     *   - the previous midlet's last frame leaking into the new session
     *     (settled snapshot is now also cleared on the session reset), and
     *   - a VM-paced loader silently showing that stale content for tens
     *     of seconds with no feedback ("the game did not load").
     * The screen goes away by itself when the first settled frame lands. */
    if (present_src == ctx->framebuffer && s_loadscr_begin_ms != 0 &&
        s_scanout && s_scanout_px >= ctx->width * ctx->height) {
        s_loadscr_on = 1;
        if (!s_loadscr_traced_on) {
            s_loadscr_traced_on = 1;
            sw_trace("load-screen: on (no settled frame yet)");
        }
        sdl_switch_compose_loading_frame(s_scanout, ctx->width, ctx->height);
        present_src = s_scanout;
    } else if (s_loadscr_on) {
        s_loadscr_on = 0;
        if (!s_loadscr_traced_off) {
            s_loadscr_traced_off = 1;
            sw_trace("load-screen: off (first frame settled)");
        }
    }

    /* v35.07 FRAME COUNTER OVERLAY (settings row "Счётчик кадров").
     * The decisive on-device instrument for the recurring "blur updates
     * ~10x more often than the main screen" report. Since v35.01 the game
     * texture and the blurred fill are fed from ONE present_src, so their
     * content cadence is identical by construction — but that is hard to
     * feel by eye on a blurred, full-screen-stretched copy (soft blobs
     * hide the 14 fps chop that sharp sprites show). Drawing the
     * settled-sequence token INTO present_src puts the same counter into
     * BOTH consumers: it ticks exactly when the content changes, in the
     * sharp image and inside the blurred backdrop alike. If the blur
     * really changed 10x more often, the counter inside it would too —
     * it cannot: same buffer. Format "F<seq> <age>ms": seq advances once
     * per settled frame (the game's TRUE frame rate), age = how old the
     * displayed content is. Drawn before UpdateTexture/blur, never
     * persisted anywhere, scale 1 (one 8x16 cell row in the corner). */
    if (!s_loadscr_on && present_src == s_scanout && st->frame_counter) {
        extern uint32_t midp_present_stable_seq(void) __attribute__((weak));
        extern uint64_t midp_present_stable_age_ms(void) __attribute__((weak));
        if (midp_present_stable_seq) {
            char fbuf[40];
            uint32_t seq = midp_present_stable_seq();
            uint64_t age = midp_present_stable_age_ms()
                               ? midp_present_stable_age_ms() : 0;
            snprintf(fbuf, sizeof(fbuf), "F%u %ums",
                     (unsigned)(seq % 1000000u), (unsigned)age);
            /* 1px black shadow pass + bright green glyph pass: readable
             * on any game content, no opaque box over the frame. Drawn
             * through s_scanout (our private non-const buffer; present_src
             * is const-qualified by the single-source contract). */
            switch_font_draw_text(s_scanout, ctx->width, ctx->height,
                                  3, 3, fbuf, 0xFF000000u, 0, 1);
            switch_font_draw_text(s_scanout, ctx->width, ctx->height,
                                  2, 2, fbuf, 0xFF40FF40u, 0, 1);
        }
    }

    SDL_UpdateTexture(g_texture, NULL, present_src,
                      ctx->width * sizeof(uint32_t));

    if (eff_scale == NOJME_SCALE_FIT_BLUR && g_bg_tex && g_bg_buf) {
        /* 1/8-size box downsample + blur, GPU stretches it linearly.
         * v34.98 CRITICAL FIX: the stable-copy check was INVERTED here —
         * midp_present_stable_copy returns the snapshot SEQUENCE number
         * (0 = nothing settled yet), and the old `== 0` branch used the
         * scanout copy only while NOTHING was settled, i.e. the blur was
         * computed from the LIVE framebuffer on every normal frame while
         * the main texture got the settled snapshot. During the slow-bind
         * degradation the live framebuffer holds a half-painted/garbage
         * frame: the user saw the blur turn into a garbage blob ("зеленое
         * пятно") while the main image stayed correct — exactly the field
         * report. v35.01: the blur consumes the SAME single-source
         * decision as the game texture (present_src above). */
        switch_scaling_blur_bg(present_src, ctx->width, ctx->height,
                               g_bg_buf, g_bg_w, g_bg_h, 2);
        SDL_UpdateTexture(g_bg_tex, NULL, g_bg_buf, g_bg_w * sizeof(uint32_t));
        SDL_RenderCopy(g_renderer, g_bg_tex, NULL, NULL); /* stretched full screen */
    } else {
        SDL_SetRenderDrawColor(g_renderer, 0, 0, 0, 255);
        SDL_RenderClear(g_renderer);
    }
    SDL_RenderCopy(g_renderer, g_texture, NULL, &g_game_rect);
    clock_gettime(CLOCK_MONOTONIC, &pv_t1);
    SDL_RenderPresent(g_renderer);
    clock_gettime(CLOCK_MONOTONIC, &pv_t2);
    {
        int64_t rp_ms = (int64_t)(pv_t2.tv_sec - pv_t1.tv_sec) * 1000 +
                        (int64_t)(pv_t2.tv_nsec - pv_t1.tv_nsec) / 1000000;
        int64_t pw_ms = (int64_t)(pv_t2.tv_sec - pw_t0.tv_sec) * 1000 +
                        (int64_t)(pv_t2.tv_nsec - pw_t0.tv_nsec) / 1000000;
        if (rp_ms > 0) __sync_fetch_and_add(&g_sd_pv_ms, (uint32_t)rp_ms);
        if (rp_ms > (int64_t)g_sd_pv_ms_max) g_sd_pv_ms_max = (uint32_t)rp_ms;
        if (pw_ms > (int64_t)g_sd_pw_ms_max) g_sd_pw_ms_max = (uint32_t)pw_ms;
        /* A RenderPresent over 250 ms is the display-pipeline stall
         * signature (vsync fence / VI hiccup) — log it throttled, forced
         * (bypasses the logging gate) so the frozen-state log names it. */
        if (rp_ms > 250) {
            static uint64_t s_last_pslow = 0;
            uint64_t nowm = sdl_switch_ui_ticks_ms();
            if (nowm - s_last_pslow >= 5000) {
                s_last_pslow = nowm;
                sw_trace_force("[PRESENT-SLOW] SDL_RenderPresent %lld ms "
                               "(whole present %lld ms) — display pipeline stall?",
                               (long long)rp_ms, (long long)pw_ms);
            }
        }
    }
    /* v34.94 diag: pr/skip/fl — track whether the game actually produced a
     * new settled frame since the last present. Weak: the white-box input
     * test links this file without the JVM/midp objects. */
    {
        extern uint32_t midp_present_stable_seq(void) __attribute__((weak));
        if (midp_present_stable_seq) {
            uint32_t v = midp_present_stable_seq();
            if (v != s_switch_frame_version_seen) {
                s_switch_frame_version_seen = v;
                s_switch_frame_version_advanced = 1;
                __sync_fetch_and_add(&g_sd_fl, 1);
            }
        }
    }
    __sync_fetch_and_add(&g_sd_pr, 1);
    if (!s_switch_frame_version_advanced) {
        __sync_fetch_and_add(&g_sd_skip, 1); /* stale content re-presented */
    }
    s_switch_frame_version_advanced = 0;
}

/* ======================= gamepad -> MIDP keys ======================= */

/* Raw joystick button index -> synthetic keycode. Re-dispatch through
 * sdl_handle_key_event: feeds the SAME soft-button, menu-navigation
 * and key-repeat bookkeeping as the keyboard path. */
static SDL_Keycode switch_joy_button_to_keycode(int b) {
    switch (b) {
        case SWJB_UP:    return SDLK_UP;
        case SWJB_DOWN:  return SDLK_DOWN;
        case SWJB_LEFT:  return SDLK_LEFT;
        case SWJB_RIGHT: return SDLK_RIGHT;
        case SWJB_A:     return SDLK_RETURN; /* FIRE */
        case SWJB_B:     return SDLK_F2;     /* right soft */
        case SWJB_X:     return SDLK_F1;     /* left soft */
        case SWJB_Y:     return SDLK_c;      /* GAME_C/clear */
        case SWJB_L:     return SDLK_ASTERISK;
        case SWJB_R:     return SDLK_HASH;
        case SWJB_PLUS:  return 0; /* v34.94: PLUS = per-game settings (was 2nd FIRE) */
        default: return 0;
    }
}

/* v34.90: stick->dpad direction edges from the CENTRAL pump state
 * (hysteresis-protected — see switch_input_pump). Dispatched only by the
 * frame pump. */
static void sdl_switch_dir_dispatch(SdlContext* ctx, int slot) {
    struct { int bit; SDL_Keycode key; } dirs[4] = {
        {1, SDLK_UP}, {2, SDLK_DOWN}, {4, SDLK_LEFT}, {8, SDLK_RIGHT},
    };
    int d = g_sw_in.dir[slot], dp = g_sw_in.dir_prev[slot];
    for (int i = 0; i < 4; i++) {
        int was = (dp >> i) & 1, now = (d >> i) & 1;
        if (was != now) sdl_handle_key_event(ctx, dirs[i].key, now ? true : false, false);
    }
}

/* ======================= in-game pause menu ======================= */

/* Runs while the main frame loop is blocked. v34.97: the VM is parked
 * EXPLICITLY by jvm_frontend_pause_begin() below (virtual time freezes,
 * all interpreter threads park at their next 64-instruction poll) — the
 * v34.81 stall probe no longer participates: with the loop holding
 * run_active=1 it could not tell "blocked in the menu" from "busy in a
 * heavy frame" and froze the game mid-run (trace v34.96). A resumes,
 * B exits the game back to the frontend menu. */
static void sdl_switch_pause_menu(SdlContext* ctx) {
    LOG_SAFE("[SWITCH] pause menu open\n");
    sw_trace("pause: open"); /* v34.91 */
    g_switch_pause_open = 1;
    g_switch_pause_req = 0; /* drop duplicate MINUS requests */
    switch_input_settle(); /* v34.90: drop the MINUS latch that opened us */
    {
        /* v34.97: паркуем VM ЯВНО и сразу — прежний stall-детектор (300 мс
         * без тика кадра) больше не участвует: цикл держит active=1, и
         * единственный путь взведения паузы — эти скобки begin/end. */
        extern void jvm_frontend_pause_begin(void);
        jvm_frontend_pause_begin();
    }
    uint32_t* cv = sdl_switch_ui_canvas();
    if (!cv) {
        /* v34.97: begin уже взведён — ранний выход обязан его снять. */
        extern void jvm_frontend_pause_end(void);
        jvm_frontend_pause_end();
        g_switch_pause_open = 0;
        return;
    }

    for (;;) {
        unsigned keys = sdl_switch_ui_pump_keys();
        /* v34.90: MINUS switches the UI language here too; the badge in the
         * top-left corner shows the current language and the hint. */
        if (keys & SWK_MINUS) switch_lang_toggle();
        if (keys & SWK_A) break;                 /* продолжить */
        if (keys & SWK_B || keys & SWK_EXIT) {   /* выход в меню */
            /* v35.10 FIX: destroyApp исполняет байткод — под ещё активной
             * паузой оверлея он вечно паркуется на первом 64-инструкционном
             * опросе: взаимная блокировка (STUCK stage=events 12-20 с,
             * AsiaRally trace v35.09 — «при выходе не работает
             * управление»). Снимаем паузу ДО вызова; страховка
             * продублирована внутри midlet_call_destroy_app (native.c). */
            {
                extern void jvm_frontend_pause_end(void);
                jvm_frontend_pause_end();
            }
            if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
            ctx->running = false;
            if (ctx->jvm) ctx->jvm->running = false;
            LOG_SAFE("[SWITCH] pause menu -> exit game\n");
            break;
        }

        /* отрисовка: последний кадр игры + полупрозрачное затемнение */
        if (g_texture && g_renderer) {
            const SwitchSettings* st = switch_settings_get();
            int eff_scale = (g_pg_scale >= 0) ? g_pg_scale : st->scale_mode;
            int x, y, w, h;
            switch_scaling_game_rect(eff_scale, ctx->width, ctx->height,
                                     SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT, &x, &y, &w, &h);
            SDL_SetRenderDrawColor(g_renderer, 0, 0, 0, 255);
            SDL_RenderClear(g_renderer);
            if (eff_scale == NOJME_SCALE_FIT_BLUR && g_bg_tex && g_bg_buf) {
                SDL_RenderCopy(g_renderer, g_bg_tex, NULL, NULL);
            }
            SDL_RenderCopy(g_renderer, g_texture, NULL,
                           &(SDL_Rect){x, y, w, h});
        }
        /* overlay */
        for (int i = 0; i < SWITCH_UI_WIDTH * SWITCH_UI_HEIGHT; i++)
            cv[i] = 0x90000000u;
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              480, 200, switch_text(ST_PAUSE_TITLE), 0xFFFFFFFF, 0, 4);
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              480, 320, switch_text(ST_PAUSE_RESUME), 0xFFE8ECF4, 0, 2);
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              480, 360, switch_text(ST_PAUSE_EXIT), 0xFFE8ECF4, 0, 2);
        /* v34.90: language badge in the top-left corner of the pause overlay */
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              32, 24, switch_lang_badge_text(), 0xFFB9C2D4, 0, 2);
        if (g_ui_tex && g_renderer) {
            SDL_UpdateTexture(g_ui_tex, NULL, cv, SWITCH_UI_WIDTH * sizeof(uint32_t));
            SDL_RenderCopy(g_renderer, g_ui_tex, NULL, NULL);
            SDL_RenderPresent(g_renderer);
        }
        SDL_Delay(16);
    }
    g_switch_pause_open = 0;
    g_switch_pause_req = 0; /* a MINUS stolen during the menu must not reopen it */
    switch_input_settle(); /* v34.90: held-through buttons must not re-press */
    {
        /* v34.97: снимаем паузу ДО возврата в цикл кадра — иначе VM остался
         * бы запаркован до первого frame_tick следующей итерации. */
        extern void jvm_frontend_pause_end(void);
        jvm_frontend_pause_end();
    }
    sw_trace("pause: close"); /* v34.91 */
    LOG_SAFE("[SWITCH] pause menu close\n");
}

/* ======================= touch -> pointer ======================= */

/* v34.90: touch dispatch from the CENTRAL pump state (one
 * pressed/released/dragged transition per frame — motion floods collapse
 * by design). Runs only on the frame thread: pointerPressed/
 * pointerReleased execute Java (execute_method), so delivering them from
 * the game-thread pump was the re-entrancy hole. */
static void sdl_switch_pointer_dispatch(SdlContext* ctx) {
    if (!ctx->jvm) return;
    extern void midp_call_pointerPressed(JVM* jvm, int x, int y);
    extern void midp_call_pointerReleased(JVM* jvm, int x, int y);
    extern void midp_call_pointerDragged(JVM* jvm, int x, int y);

    static int prev_down = 0;
    static int prev_x = -1, prev_y = -1;

    /* map window -> game canvas through the CURRENT game rect */
    int gx = 0, gy = 0;
    if (g_game_rect.w > 0 && g_game_rect.h > 0) {
        gx = (g_sw_in.touch_x - g_game_rect.x) * ctx->width / g_game_rect.w;
        gy = (g_sw_in.touch_y - g_game_rect.y) * ctx->height / g_game_rect.h;
        if (gx < 0) gx = 0;
        if (gy < 0) gy = 0;
        if (gx >= ctx->width) gx = ctx->width - 1;
        if (gy >= ctx->height) gy = ctx->height - 1;
    }
    ctx->input.pointer_x = gx;
    ctx->input.pointer_y = gy;

    if (g_sw_in.touch_down && !prev_down) {
        ctx->input.pointer_pressed = true;
        midp_call_pointerPressed(ctx->jvm, gx, gy);
    } else if (!g_sw_in.touch_down && prev_down) {
        ctx->input.pointer_pressed = false;
        midp_call_pointerReleased(ctx->jvm, gx, gy);
    } else if (g_sw_in.touch_down && prev_down && g_sw_in.touch_moved &&
               (gx != prev_x || gy != prev_y)) {
        midp_call_pointerDragged(ctx->jvm, gx, gy);
    }
    prev_down = g_sw_in.touch_down;
    prev_x = gx; prev_y = gy;
}

#endif /* __SWITCH__ && SDL2_AVAILABLE */


/* Initialize SDL */
int sdl_init(JVM* jvm, int width, int height, int scale, bool headless) {
    /* v34.98: the thread that initializes SDL is THE render thread; every
     * render entry point verifies its caller against it from now on. */
    sdl_render_thread_arm();
    DEBUG_LOG("[SDL] Initializing %dx%d (scale: %d, headless: %s)", width, height, scale, headless ? "yes" : "no");

#ifdef _WIN32
    /* Initialize mutex for Windows */
    if (!g_sdl_mutex_initialized) {
        InitializeCriticalSection(&g_sdl_mutex);
        g_sdl_mutex_initialized = true;
    }
#endif

    /* Use the global context pointer set by main.c */
    if (!g_sdl_ctx_ptr) {
        DEBUG_LOG("[SDL] ERROR: g_sdl_ctx_ptr is NULL - must be set before sdl_init");
        return -1;
    }
    
    SdlContext* ctx = g_sdl_ctx_ptr;
    memset(ctx, 0, sizeof(SdlContext));
    ctx->width = width;
    ctx->height = height;
    ctx->scale = scale;
    ctx->jvm = jvm;
    ctx->running = true;
    ctx->target_fps = 60;  /* Default FPS */
    ctx->headless = headless;  /* Store headless flag */
    ctx->input.pointer_x = 0;
    ctx->input.pointer_y = 0;
    ctx->input.pointer_pressed = false;
    memset(ctx->input.key_states, 0, sizeof(ctx->input.key_states));

    /* v35.02 SINGLE-PUMP: the SDL-family frontends (Switch UI, Windows/SDL2,
     * headless) pump repaints from THIS thread every iteration — arm the
     * protocol so game threads in serviceRepaints() wait for the frontend
     * to paint instead of racing it for the UI lock (the lost-logic-tick
     * machine behind the "race crawls ~1 Hz then freezes" field report).
     * libretro never arms it -> legacy synchronous behavior there. */
    {
        extern void midp_set_external_pump_active(int on);
        midp_set_external_pump_active(1);
    }

    /* Allocate framebuffer */
    ctx->framebuffer = (uint32_t*)malloc(width * height * sizeof(uint32_t));
    if (!ctx->framebuffer) {
        return -1;
    }
    
    /* ИСПРАВЛЕНО: Инициализируем framebuffer чёрным непрозрачным цветом.
     * calloc инициализирует нулями, что означает alpha=0 (прозрачный).
     * Но для J2ME игр нужен чёрный фон с alpha=255 (непрозрачный).
     * Формат ARGB: 0xFF000000 = чёрный, непрозрачный
     */
    for (int i = 0; i < width * height; i++) {
        ctx->framebuffer[i] = 0xFF000000;  /* Чёрный, непрозрачный */
    }

    /* ИСПРАВЛЕНО: В headless режиме не создаём SDL окно */
    if (headless) {
        DEBUG_LOG("[SDL] Headless mode - skipping SDL window creation");
        return 0;
    }

#ifdef __SWITCH__
    /* v34.84 Switch frontend: the window/renderer/UI texture already
     * exist (sdl_switch_platform_init, called from the menu bootstrap);
     * a game session only adds the canvas texture (+ blur bg). */
    if (sdl_switch_game_begin(width, height) != 0) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }
    return 0;
#endif

#if SDL2_AVAILABLE
    /* ИСПРАВЛЕНИЕ: Включаем VSync для устранения мерцания и tearing */
    /* Используем OpenGL или DirectX вместо software renderer */
    SDL_SetHint(SDL_HINT_RENDER_DRIVER, "opengl");
    SDL_SetHint(SDL_HINT_RENDER_VSYNC, "1");
    
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) {
        DEBUG_LOG("[SDL] Failed to initialize: %s", SDL_GetError());
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;

    /* v17: bridge the Nokia Clipboard to the OS clipboard */
    {
        extern void sdl_setup_clipboard_hooks(void);
        sdl_setup_clipboard_hooks();
    }
    }

    g_window = SDL_CreateWindow(
        "J2ME Emulator",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        width * scale, height * scale,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );

    if (!g_window) {
        DEBUG_LOG("[SDL] Failed to create window: %s", SDL_GetError());
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    /* ИСПРАВЛЕНО: Пробуем hardware-accelerated renderer с VSync */
    g_renderer = SDL_CreateRenderer(g_window, -1, 
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

    if (!g_renderer) {
        /* Fallback: try without VSync */
        g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_ACCELERATED);
    }
    
    if (!g_renderer) {
        /* Last resort: software renderer */
        DEBUG_LOG("[SDL] Hardware acceleration not available, using software renderer");
        g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_SOFTWARE);
    }

    if (!g_renderer) {
        DEBUG_LOG("[SDL] Failed to create renderer: %s", SDL_GetError());
        SDL_DestroyWindow(g_window);
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    SDL_RenderSetLogicalSize(g_renderer, width, height);

    g_texture = SDL_CreateTexture(g_renderer,
        SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING,
        width, height);

    if (!g_texture) {
        DEBUG_LOG("[SDL] Failed to create texture: %s", SDL_GetError());
        SDL_DestroyRenderer(g_renderer);
        SDL_DestroyWindow(g_window);
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    DEBUG_LOG("[SDL] Initialized with real SDL2");
#else
    DEBUG_LOG("[SDL] Running in headless mode (no SDL2)");
    DEBUG_LOG("[SDL] Press Ctrl+C to exit");
#endif

    DEBUG_LOG("[SDL] Context: %p, target_fps: %d", (void*)ctx, ctx->target_fps);
    return 0;
}

/* Destroy SDL */
void sdl_destroy(SdlContext* ctx) {
#if SDL2_AVAILABLE
#ifdef __SWITCH__
    /* v34.84: per-GAME teardown only — the shared window/renderer/UI
     * texture live until sdl_switch_platform_shutdown() at app exit. */
    sdl_switch_game_end();
#else
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    SDL_Quit();
#endif
#endif

    if (ctx && ctx->framebuffer) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
    }
}

/* v34.72: finished-MIDlet probe (native.c) — see the revive guard in
 * sdl_run(). */
extern bool midlet_is_destroyed(void);

/* v34.89: declared for EVERY SDL2 build (was __SWITCH__-only since
 * v34.84): the SDL_QUIT handler calls it unconditionally, so a desktop
 * GCC 14 build with SDL2 died on an implicit declaration. */
extern void midlet_call_destroy_app(JVM* jvm, bool unconditional);

/* v34.86: the shared key-event handler uses the SDL-only key_map /
 * repeat bookkeeping, and both of its callers (the SDL event loop and
 * the __SWITCH__&&SDL2 gamepad path) exist only when SDL2_AVAILABLE —
 * compile the body only for SDL builds, stub otherwise (no-SDL hosts
 * have no keyboard events by construction). */
#if SDL2_AVAILABLE
/*
 * sdl_handle_key_event — the shared SDL_KEYDOWN/UP body (extracted v34.84
 * so the __SWITCH__ gamepad path can re-dispatch synthesized keyboard
 * events through the identical logic: repeat bookkeeping, soft buttons,
 * command-menu navigation, ESC/F12 handling).
 */
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat) {
    
    /* Track key hold state for software key repeat.
     * On real J2ME phones, holding a key generates repeated
     * keyPressed events. We track hold state here and
     * generate repeats in sdl_process_key_repeat(). */
    /* v17: refresh DeviceControl inactivity timer */
    {
        extern void midp_input_activity_mark(void);
        midp_input_activity_mark();
    }

    int repeat_idx = sdl_key_to_repeat_idx(key);
    if (pressed && !is_repeat) {
        /* Initial press - start tracking for repeat */
        uint64_t now_ts = sdl_get_time_ms();
        g_sdl_key_repeat.is_held[repeat_idx] = true;
        g_sdl_key_repeat.press_time[repeat_idx] = now_ts;
        g_sdl_key_repeat.last_repeat_time[repeat_idx] = now_ts;
    } else if (!pressed) {
        /* Key released - clear repeat state */
        g_sdl_key_repeat.is_held[repeat_idx] = false;
    }
    
    /* Ignore SDL native repeat events - we handle repeat ourselves */
    if (pressed && is_repeat) {
        return;
    }
    
    int midp_key = 0;
    int game_action = 0;

    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == key) {
            midp_key = key_map[i].midp_key;
            game_action = key_map[i].game_action;
            
            /* Сохраняем состояние клавиши для game_action (положительное) */
            /* midp_key не используем для key_states, т.к. он может быть отрицательным */
            if (game_action > 0 && game_action < 256) {
                ctx->input.key_states[game_action] = pressed;
                GFX_DEBUG("[SDL] Key %s: SDL=%d -> keyCode=%d, gameAction=%d",
                        pressed ? "DOWN" : "UP", key, midp_key, game_action);
            }
            break;
        }
    }

    /* ИСПРАВЛЕНО: Soft button handling (F1/F2) делаем ПЕРВЫМ!
     * По стандарту MIDP:
     * - Если displayable имеет Commands, вызываем commandAction()
     * - Если нет Commands, передаём keyPressed(-6/-7) в игру
     * F1 = -6 (Left Soft Key), F2 = -7 (Right Soft Key)
     */
    if (pressed && ctx->jvm && (key == SDLK_F1 || key == SDLK_F2)) {
        int soft_button = (key == SDLK_F1) ? 0 : 1;
        int soft_keycode = (key == SDLK_F1) ? -6 : -7;
        
        GFX_DEBUG("[SDL] Soft button: key=%s -> button=%d, keyCode=%d",
                key == SDLK_F1 ? "F1" : "F2", soft_button, soft_keycode);
        
        extern bool midp_handle_soft_button(JVM* jvm, int button_index);
        if (!midp_handle_soft_button(ctx->jvm, soft_button)) {
            /* No commands handled - pass keyPressed to game */
            GFX_DEBUG("[SDL] No commands, passing keyPressed(%d) to game", soft_keycode);
            midp_call_keyPressed(ctx->jvm, soft_keycode);
        }
        return; /* Обработано, не передаём дальше */
    }

    /* Call keyPressed/keyReleased on Canvas */
    if (ctx->jvm && (midp_key || game_action)) {
        /* Check if menu navigation should be handled first */
        if (pressed && game_action) {
            extern bool midp_is_command_menu_open(void);
            extern bool midp_handle_menu_navigation(int direction);
            extern bool midp_handle_soft_button(JVM* jvm, int button_index);
            
            if (midp_is_command_menu_open()) {
                if (game_action == 1) { /* UP */
                    midp_handle_menu_navigation(-1);
                    GFX_DEBUG("[SDL] Menu navigation UP");
                    return; /* Don't pass to game */
                } else if (game_action == 6) { /* DOWN */
                    midp_handle_menu_navigation(1);
                    GFX_DEBUG("[SDL] Menu navigation DOWN");
                    return; /* Don't pass to game */
                } else if (game_action == 8) { /* FIRE - confirm selection */
                    /* Right button (index 1) confirms selection */
                    midp_handle_soft_button(ctx->jvm, 1);
                    GFX_DEBUG("[SDL] Menu FIRE - confirm selection");
                    return; /* Don't pass to game */
                }
            }
        }
        
        /* ИСПРАВЛЕНО: Отправляем keyCode по стандарту Nokia FullCanvas:
         * - UP = -1, DOWN = -2, LEFT = -3, RIGHT = -4, FIRE = -5
         * Игра сама вызовет getGameAction() для конвертации в game action
         */
        int keycode = midp_key ? midp_key : game_action;
        
        if (pressed) {
            DEBUG_LOG("[SDL] Key pressed: SDL=%d -> MIDP keyCode=%d (gameAction=%d)", key, keycode, game_action);
            midp_call_keyPressed(ctx->jvm, keycode);
        } else {
            midp_call_keyReleased(ctx->jvm, keycode);
        }
    }

    if (key == SDLK_ESCAPE && pressed) {
        ctx->running = false;
        if (ctx->jvm) ctx->jvm->running = false;
    }
    
    /* F12: Toggle debug mode at runtime */
    if (key == SDLK_F12 && pressed) {
        bool new_state = j2me_debug_toggle();
        /* Also update the window title to show debug state */
        char title[256];
        snprintf(title, sizeof(title), "J2ME Emulator [Debug: %s]", 
                 new_state ? "ON" : "OFF");
        sdl_set_title(ctx, title);
    }}

/* Process events */
void sdl_process_events(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    /* Forward declarations for MIDP input functions */
    extern void midp_call_keyPressed(JVM* jvm, int keycode);
    extern void midp_call_keyReleased(JVM* jvm, int keycode);
    extern void midp_call_pointerPressed(JVM* jvm, int x, int y);
    extern void midp_call_pointerReleased(JVM* jvm, int x, int y);
    extern void midp_call_pointerDragged(JVM* jvm, int x, int y);
#ifndef __SWITCH__
    SDL_Event event;
    /* Track previous pointer state for drag detection (desktop loop) */
    static int prev_pointer_x = -1;
    static int prev_pointer_y = -1;
    static bool prev_pointer_pressed = false;
#endif

#ifdef __SWITCH__
    /* v34.90 SINGLE-PUMP dispatch: this is the ONLY place SDL events are
     * consumed during a game (see the state-block comment above
     * switch_input_pump). Everything below the desktop loop is bypassed. */
    if (g_switch_pause_req) { /* vestigial latch — kept for log parity */
        g_switch_pause_req = 0;
        sdl_switch_pause_menu(ctx);
    }
    switch_input_pump();
    switch_game_keys_tick(ctx); /* v35.09 sandbox in-game key script (env-gated) */
    /* v34.91: the first frame of the first game session proves the VM is
     * actually RENDERING (missing line = stuck before the frame pump). */
    {
        static int s_first_frame = 1;
        if (s_first_frame) {
            s_first_frame = 0;
            sw_trace("frame: first");
        }
    }
    if (g_sw_in.quit) {
        if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
        ctx->running = false;
        if (ctx->jvm) ctx->jvm->running = false;
    }
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        uint16_t press = (uint16_t)((g_sw_in.held[i] | g_sw_in.latch[i]) & ~g_sw_in.prev[i]);
        uint16_t release = (uint16_t)(~g_sw_in.held[i] & (g_sw_in.prev[i] | g_sw_in.latch[i]));
        if (press & (1u << SWJB_MINUS)) {
            /* MINUS — in-game pause menu (VM parks via the v34.81 watchdog;
             * virtual time freezes). Handled HERE on the frame thread —
             * never mid-bytecode on a VM fiber. */
            sdl_switch_pause_menu(ctx);
        }
        if (press & (1u << SWJB_PLUS)) {
            /* v34.94: PLUS — per-game settings overlay (resolution /
             * scaling / filter for THIS jar). Same frame-thread contract
             * as the pause menu. */
            if (g_switch_current_jar[0]) {
                switch_ui_pergame_screen(g_switch_current_jar);
                switch_input_settle(); /* the PLUS release must not leak into the game */
            }
        }
        for (int b = 0; b < 16; b++) {
            if (b == SWJB_MINUS || b == SWJB_PLUS) continue; /* handled above */
            uint16_t bit = (uint16_t)(1u << b);
            if (press & bit) {
                SDL_Keycode mapped = switch_joy_button_to_keycode(b);
                /* re-dispatch through the shared keyboard path: soft buttons,
                 * menu navigation and key repeat bookkeeping all come along. */
                if (mapped) sdl_handle_key_event(ctx, mapped, true, false);
            }
            if (release & bit) {
                SDL_Keycode mapped = switch_joy_button_to_keycode(b);
                if (mapped) sdl_handle_key_event(ctx, mapped, false, false);
            }
        }
        sdl_switch_dir_dispatch(ctx, i);
    }
    sdl_switch_pointer_dispatch(ctx);
    sdl_process_key_repeat(ctx);
    return; /* the desktop event loop below does not run on __SWITCH__ */
#endif /* __SWITCH__ */

#ifndef __SWITCH__
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                /* FIX (audit T-1, v18): give the MIDlet a chance to run
                 * destroyApp (save progress) before the interpreter stops. */
                if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
                ctx->running = false;
                if (ctx->jvm) ctx->jvm->running = false;
                break;

            case SDL_KEYDOWN:
            case SDL_KEYUP:
                sdl_handle_key_event(ctx, event.key.keysym.sym,
                                     event.type == SDL_KEYDOWN,
                                     event.key.repeat ? true : false);
                break;

            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
                {
                    bool pressed = (event.type == SDL_MOUSEBUTTONDOWN);
                    int x = event.button.x / ctx->scale;
                    int y = event.button.y / ctx->scale;
                    
                    ctx->input.pointer_x = x;
                    ctx->input.pointer_y = y;
                    ctx->input.pointer_pressed = pressed;
                    
                    /* Call pointer event handlers */
                    if (ctx->jvm) {
                        if (pressed && !prev_pointer_pressed) {
                            /* pointerPressed: transition from not pressed to pressed */
                            DEBUG_LOG("[SDL] Pointer pressed at (%d, %d)", x, y);
                            midp_call_pointerPressed(ctx->jvm, x, y);
                        } else if (!pressed && prev_pointer_pressed) {
                            /* pointerReleased: transition from pressed to not pressed */
                            DEBUG_LOG("[SDL] Pointer released at (%d, %d)", x, y);
                            midp_call_pointerReleased(ctx->jvm, x, y);
                        }
                    }
                    
                    prev_pointer_x = x;
                    prev_pointer_y = y;
                    prev_pointer_pressed = pressed;
                }
                break;

            case SDL_MOUSEMOTION:
                {
                    int x = event.motion.x / ctx->scale;
                    int y = event.motion.y / ctx->scale;
                    
                    ctx->input.pointer_x = x;
                    ctx->input.pointer_y = y;
                    
                    /* Check for drag: pointer is pressed and moving */
                    if (ctx->jvm && prev_pointer_pressed && 
                        (x != prev_pointer_x || y != prev_pointer_y)) {
                        DEBUG_LOG("[SDL] Pointer dragged to (%d, %d)", x, y);
                        midp_call_pointerDragged(ctx->jvm, x, y);
                    }
                    
                    prev_pointer_x = x;
                    prev_pointer_y = y;
                }
                break;

            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_RESIZED) {
                    int new_w = event.window.data1;
                    int new_h = event.window.data2;
                    ctx->scale = (new_w / ctx->width < new_h / ctx->height)
                        ? new_w / ctx->width : new_h / ctx->height;
                    if (ctx->scale < 1) ctx->scale = 1;
                }
                break;
        }
    }
#endif /* !__SWITCH__ */
    
    /* Process software key repeat after all events are handled.
     * Generates repeated keyPressed events for held game keys. */
    sdl_process_key_repeat(ctx);
#endif
}

#else /* !SDL2_AVAILABLE */
#if defined(__GNUC__) || defined(__clang__)
__attribute__((unused))
#endif
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat) {
    (void)ctx; (void)key; (void)pressed; (void)is_repeat; /* no-SDL no-op */
}
#endif /* SDL2_AVAILABLE */

/* Minimal event processing for cooperative threading - called from Thread.sleep() */
void sdl_process_events_minimal(void) {
#if SDL2_AVAILABLE
    if (!g_sdl_ctx_ptr) return;
    
    /* Only process events if we have a valid SDL window */
    if (!g_window) return;

#ifdef __SWITCH__
    /* v34.90 SINGLE-PUMP RULE: the game thread NEVER drains the SDL queue.
     * This pump used to run from thread_yield()/Thread.sleep — MID-BYTECODE
     * on a yielding VM fiber — and re-dispatched soft keys / FIRE with the
     * command menu open / touches through paths that execute Java
     * re-entrantly (execute_method from the middle of the yield): the
     * «buttons work, then stop; cannot enter any menu item» bug. Input
     * now flows exclusively through the frame pump (<= 1 frame latency). */
    return;
#endif
    
    /* ИСПРАВЛЕНО: Кооперативные потоки выполняются в контексте главного потока
     * через ucontext, поэтому SDL_PollEvent безопасен для вызова.
     * Обрабатываем события клавиш, чтобы игры могли реагировать на ввод
     * даже во время выполнения своих игровых циклов. */
    SDL_Event event;
    
    /* Forward declarations for MIDP input functions */
    extern void midp_call_keyPressed(JVM* jvm, int keycode);
    extern void midp_call_keyReleased(JVM* jvm, int keycode);
    
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                g_sdl_ctx_ptr->running = false;
                if (g_sdl_ctx_ptr->jvm) g_sdl_ctx_ptr->jvm->running = false;
                break;

            case SDL_KEYDOWN:
            case SDL_KEYUP:
                {
                    bool pressed = (event.type == SDL_KEYDOWN);
                    SDL_Keycode key = event.key.keysym.sym;
                    
                    /* Track key hold state for software key repeat */
                    int repeat_idx2 = sdl_key_to_repeat_idx(key);
                    if (pressed && !event.key.repeat) {
                        uint64_t now_ts2 = sdl_get_time_ms();
                        g_sdl_key_repeat.is_held[repeat_idx2] = true;
                        g_sdl_key_repeat.press_time[repeat_idx2] = now_ts2;
                        g_sdl_key_repeat.last_repeat_time[repeat_idx2] = now_ts2;
                    } else if (!pressed) {
                        g_sdl_key_repeat.is_held[repeat_idx2] = false;
                    }
                    
                    /* Ignore SDL native repeat events - we handle repeat ourselves */
                    if (pressed && event.key.repeat) {
                        break;
                    }
                    
                    int midp_key = 0;
                    int game_action = 0;

                    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
                        if (key_map[i].sdl_key == key) {
                            midp_key = key_map[i].midp_key;
                            game_action = key_map[i].game_action;
                            break;
                        }
                    }

                    /* ИСПРАВЛЕНО: Soft button handling (F1/F2) делаем ПЕРВЫМ! */
                    if (pressed && g_sdl_ctx_ptr->jvm && (key == SDLK_F1 || key == SDLK_F2)) {
                        int soft_button = (key == SDLK_F1) ? 0 : 1;
                        int soft_keycode = (key == SDLK_F1) ? -6 : -7;
                        
                        extern bool midp_handle_soft_button(JVM* jvm, int button_index);
                        if (!midp_handle_soft_button(g_sdl_ctx_ptr->jvm, soft_button)) {
                            midp_call_keyPressed(g_sdl_ctx_ptr->jvm, soft_keycode);
                        }
                        break; /* Обработано, не передаём дальше */
                    }

                    /* Call keyPressed/keyReleased on Canvas */
                    /* Используем keyCode (midp_key) по стандарту Nokia FullCanvas */
                    if (g_sdl_ctx_ptr->jvm && (midp_key || game_action)) {
                        int keycode = midp_key ? midp_key : game_action;
                        
                        if (pressed) {
                            DEBUG_LOG("[SDL] Minimal: Key pressed SDL=%d -> keyCode=%d", key, keycode);
                            midp_call_keyPressed(g_sdl_ctx_ptr->jvm, keycode);
                        } else {
                            midp_call_keyReleased(g_sdl_ctx_ptr->jvm, keycode);
                        }
                    }

                    if (key == SDLK_ESCAPE && pressed) {
                        g_sdl_ctx_ptr->running = false;
                        if (g_sdl_ctx_ptr->jvm) g_sdl_ctx_ptr->jvm->running = false;
                    }
                }
                break;

        }
    }
    
    /* Process software key repeat for minimal event loop too */
    sdl_process_key_repeat(g_sdl_ctx_ptr);
#endif
}

/* Set global context (called by main.c before sdl_init) */
void sdl_set_global_context(SdlContext* ctx) {
    g_sdl_ctx_ptr = ctx;
    DEBUG_LOG("[SDL] Global context set to %p", (void*)ctx);
}

/* Get global context */
SdlContext* sdl_get_global_context(void) {
    return g_sdl_ctx_ptr;
}

/* ИСПРАВЛЕНО: Thread-safe запрос на перерисовку экрана */
void sdl_request_redraw(void) {
    if (g_sdl_ctx_ptr) {
        atomic_store_explicit(&g_sdl_ctx_ptr->needs_redraw, true, memory_order_release);
        /* DEBUG: Log first 20 calls */
        static int redraw_count = 0;
        redraw_count++;
        if (redraw_count <= 20) {
            LOG_SAFE("[SDL] sdl_request_redraw() #%d: set needs_redraw=true, ptr=%p\n", 
                    redraw_count, (void*)g_sdl_ctx_ptr);
        }
    } else {
        LOG_SAFE("[SDL] WARNING: sdl_request_redraw() called but g_sdl_ctx_ptr is NULL!\n");
    }
}

/* Check if redraw is needed */
bool sdl_needs_redraw(SdlContext* ctx) {
    return ctx ? atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire) : false;
}

/* Clear redraw flag */
void sdl_clear_redraw(SdlContext* ctx) {
    if (ctx) {
        atomic_store_explicit(&ctx->needs_redraw, false, memory_order_release);
    }
}

/* v35.04 stage-cost gauge: keep the worst single elapsed (ms) since t0 in
 * the per-period slot. Worst-value only (no sum) — one giant paint must
 * stand out the same way mx= does for whole iterations. Racy write is
 * acceptable (diagnostics). */
static void sd_stage_max(volatile uint32_t* slot, const struct timespec* t0) {
    struct timespec t1;
    clock_gettime(CLOCK_MONOTONIC, &t1);
    int64_t ms = (int64_t)(t1.tv_sec - t0->tv_sec) * 1000 +
                 (int64_t)(t1.tv_nsec - t0->tv_nsec) / 1000000;
    if (ms > 0 && (uint32_t)ms > *slot) *slot = (uint32_t)ms;
}

/* Run main loop */
void sdl_run(SdlContext* ctx) {
    if (!ctx) {
        DEBUG_LOG("[SDL] ERROR: sdl_run called with NULL context");
        return;
    }
    /* v34.98: sdl_run owns the frame loop — (re)arm the render-thread
     * reference here in case the loop thread differs from sdl_init's. */
    sdl_render_thread_arm();
    
    /* Check if context was properly initialized */
    if (ctx->target_fps <= 0 || ctx->framebuffer == NULL) {
        DEBUG_LOG("[SDL] ERROR: Context not properly initialized");
        DEBUG_LOG("[SDL] target_fps=%d, framebuffer=%p, width=%d, height=%d",
                ctx->target_fps, (void*)ctx->framebuffer, ctx->width, ctx->height);
        DEBUG_LOG("[SDL] This usually means sdl_init() failed or was not called");
        return;
    }

    DEBUG_LOG("[SDL] Running main loop (FPS: %d, %dx%d)", ctx->target_fps, ctx->width, ctx->height);

    /* External function from display.c for callSerially processing */
    extern void midp_process_call_serially_queue(JVM* jvm);
    extern void jvm_process_timers(JVM* jvm);
    extern bool midp_check_alert_timeout(JVM* jvm);
    
    /* ИСПРАВЛЕНО: Функция для вызова paint() на текущем displayable */
    extern void midp_repaint_current(JVM* jvm);

    /* ИСПРАВЛЕНО: Если running=false, принудительно устанавливаем true */
    if (!ctx->running) {
        LOG_SAFE("[HEADLESS] WARNING: ctx->running was false, forcing to true\n");
        ctx->running = true;
    }
    /* v34.72: revive the VM ONLY when it did not deliberately finish
     * (notifyDestroyed/System.exit inside startApp). Reviving a finished
     * VM left a dead pump on a frozen screen forever — the finished
     * MIDlet now falls through to the explicit black finished screen. */
    if (ctx->jvm && !ctx->jvm->running &&
        !ctx->jvm->exiting && !midlet_is_destroyed()) {
        LOG_SAFE("[HEADLESS] WARNING: ctx->jvm->running was false, forcing to true\n");
        ctx->jvm->running = true;
    }

#if SDL2_AVAILABLE
    /* Headless-style mode: SDL2 available but no window (headless or headless-like) */
    /* ИСПРАВЛЕНО: Проверяем g_window ПЕРЕД основным циклом, а не после */
    if (!g_window) {
        /* Headless mode - simple delay loop (SDL2 available but no window created) */
        
        LOG_SAFE("[HEADLESS] Starting headless main loop (SDL2 available, no window)\n");
        LOG_SAFE("[HEADLESS] ctx=%p, ctx->running=%d, ctx->jvm=%p, ctx->jvm->running=%d\n",
                (void*)ctx, ctx->running, (void*)ctx->jvm, ctx->jvm ? ctx->jvm->running : -1);
        
        /* ИСПРАВЛЕНО: Используем clock_gettime вместо SDL_GetTicks, т.к. SDL не инициализирован */
        uint64_t last_auto_redraw = 0;
        const uint64_t auto_redraw_interval = 16;  /* ~60 FPS */
        int headless_loop_count = 0;
        
        /* Get current time using clock_gettime */
        struct timespec start_ts;
        clock_gettime(CLOCK_MONOTONIC, &start_ts);
        last_auto_redraw = (uint64_t)start_ts.tv_sec * 1000 + start_ts.tv_nsec / 1000000;
        
        while (ctx->running && ctx->jvm && ctx->jvm->running) {
            headless_loop_count++;
            
            /* Check for error display mode */
            if (sdl_has_error()) {
                sdl_draw_error_screen(ctx);
                sdl_present(ctx);
                
                /* Short delay in error mode */
#ifdef _WIN32
                Sleep(16);
#else
                struct timespec ts = { .tv_sec = 0, .tv_nsec = 16000000 };
                nanosleep(&ts, NULL);
#endif
                continue;
            }
            
            /* Process timers */
            jvm_process_timers(ctx->jvm);
            
            /* v35: age key queue + fallback delivery (event-driven menus) */
            {
                extern void midp_frame_tick(void);
                extern void midp_pump_deferred_keys(JVM* jvm);
                midp_frame_tick();
                midp_pump_deferred_keys(ctx->jvm);
            }

            /* Process callSerially queue */
            midp_process_call_serially_queue(ctx->jvm);
            
            /* Check Alert timeout */
            midp_check_alert_timeout(ctx->jvm);
            
            /* ИСПРАВЛЕНО: Автоматическая перерисовка в headless режиме */
            struct timespec current_ts;
            clock_gettime(CLOCK_MONOTONIC, &current_ts);
            uint64_t current_time = (uint64_t)current_ts.tv_sec * 1000 + current_ts.tv_nsec / 1000000;
            uint64_t elapsed = current_time - last_auto_redraw;
            
            if (elapsed >= auto_redraw_interval) {
                ctx->needs_redraw = true;
                last_auto_redraw = current_time;
                if (headless_loop_count <= 10) {
                    LOG_SAFE("[HEADLESS] Auto-redraw at iteration %d (elapsed=%lu ms)\n", 
                            headless_loop_count, (unsigned long)elapsed);
                }
            }
            
            /* Process pending repaints */
            if (ctx->needs_redraw) {
                /* v35.02: conditional clear — only a pump that ran may
                 * consume the pending state (see the Switch main loop). */
                int painted = midp_process_repaints(ctx->jvm);
                ctx->needs_redraw = false;

                /* ИСПРАВЛЕНО: Сигнализируем что repaint обработан */
                if (painted) {
                    extern void midp_clear_pending_repaint(void);
                    midp_clear_pending_repaint();
                }
                
                /* В J2ME, поток с необработанным исключением НЕ останавливает приложение.
                 * Только этот поток завершается, остальные продолжают работать.
                 */
                
                /* ИСПРАВЛЕНО: Сохраняем кадр в файл для отладки */
                if (headless_loop_count <= 5 || headless_loop_count % 30 == 0) {
                    char filename[256];
                    snprintf(filename, sizeof(filename), "/tmp/j2me_frame_%d.ppm", headless_loop_count);
                    sdl_save_framebuffer_to_file(ctx, filename);
                }
            }
            
            /* ИСПРАВЛЕНО: В headless режиме SDL не инициализирован, используем nanosleep */
#ifdef _WIN32
            Sleep(16);
#else
            struct timespec ts = { .tv_sec = 0, .tv_nsec = 16000000 };
            nanosleep(&ts, NULL);
#endif
            
            /* Limit headless execution time */
            if (headless_loop_count > 6000) {
                LOG_SAFE("[HEADLESS] Maximum iterations reached\n");
                break;
            }
        }
        return;  /* Headless mode done */
    }
    
    /* Normal SDL2 mode with window - main loop */
    uint64_t last_time = SDL_GetTicks();
    const uint64_t frame_time = 1000 / ctx->target_fps;
    
    ctx->needs_redraw = true;
    uint64_t last_auto_redraw = SDL_GetTicks();
    const uint64_t auto_redraw_interval = 16;

    int loop_count = 0;
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        loop_count++;
        struct timespec sd_iter_t0;
        clock_gettime(CLOCK_MONOTONIC, &sd_iter_t0);
#ifdef __SWITCH__
        /* v34.97 FREEZE FIX: только frame_tick — стоявший следом run_exit
         * обнулял g_frontend_run_active на ВСЮ оставшуюся часть итерации,
         * из-за чего stall-детектор мерил ПОЛНОЕ время итерации и взводил
         * паузу посреди игры, как только одна итерация превышала 300 мс
         * (тяжёлый кадр + GC-шторм: фриз из trace v34.96, fl 50->84->160
         * прямо перед STUCK stage=repaints). Пока цикл жив, active всё
         * время TRUE — детектор больше не может взвести паузу сам; оверлеи
         * (меню MINUS, per-game экран PLUS) делают это детерминированно
         * через jvm_frontend_pause_begin/end (v34.97). */
        {
            extern void jvm_frontend_frame_tick(void);
            jvm_frontend_frame_tick();
        }
        SW_DIAG_STAGE("watchdog");
#endif
        
        /* Check for error display mode */
        if (sdl_has_error()) {
            sdl_draw_error_screen(ctx);
            
            SDL_LOCK();
            sdl_update_texture(ctx);
            SDL_RenderClear(g_renderer);
            SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
            SDL_RenderPresent(g_renderer);
            SDL_UNLOCK();
            
            /* Still process events so ESC works */
            sdl_process_events(ctx);
            
            SDL_Delay(16);  /* ~60 FPS in error mode */
            continue;
        }
        
        if (loop_count % 60 == 0) {
            DEBUG_LOG("[MAIN_LOOP] Still running, iteration=%d, needs_redraw=%d", loop_count, ctx->needs_redraw);
        }
        
        SW_DIAG_STAGE("events");
        sdl_process_events(ctx);
        /* v36.05 [MIDLET-STUCK] self-recovery consumer: the heartbeat
         * watchdog raised g_midp_stuck_recover_req after ~15 s of VM dead
         * air (loader thread died uncaught — see [VM-THREAD-DEATH] — and
         * the midlet thread spins forever; the Doom RPG [Rus] 2nd-launch
         * hang). Perform the SAME graceful exit as the pause-menu
         * "exit to menu" (destroyApp -> running=false), so the user lands
         * in the frontend menu instead of a dead loading screen. Runs on
         * THIS thread (the session owner) — never from the timer thread. */
        if (g_midp_stuck_recover_req) {
            g_midp_stuck_recover_req = 0; /* consume once */
            sw_trace("[MIDLET-STUCK] consuming recovery request: graceful exit to menu");
            LOG_SAFE("[SWITCH] midlet stuck (VM dead air) -> graceful exit to menu\n");
            if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
            ctx->running = false;
            if (ctx->jvm) ctx->jvm->running = false;
        }
        /* v35.04 STAGE-COST GAUGES: worst single ms per diag period for the
         * three VM-hosting stages (fields tj=/rj=/sj= in the diag line).
         * The v35.03 race trace showed 19 ms iterations with present at
         * 1-3 ms — loop/stl/mx cannot say WHERE the time went; these three
         * gauges name the stage directly. Cheap: one clock_gettime pair per
         * stage, worst-value only, no allocation. */
        SW_DIAG_STAGE("timers");
        {
            struct timespec sd_tj_t0;
            clock_gettime(CLOCK_MONOTONIC, &sd_tj_t0);
            /* v35.05 SHOWNOTIFY PUMP (Bobby Carrot 4 freeze-on-load fix):
             * the deferred showNotify from Display.setCurrent (v34.33) was
             * delivered by the headless and libretro loops but NEVER by this
             * Switch/SDL2 frame loop — on Switch, Canvas.showNotify() did
             * not fire AT ALL. Games that gate their paint loop on a
             * showNotify-set flag (BC4: `if (this.d && ...) repaint()`,
             * d=false forever) painted the first frame and then froze with
             * a live game thread and music playing: [NO-FRAME] fl=0,
             * skip=loop, td m stale at the last drawImage. Deliver here,
             * once per iteration, BEFORE timers/repaints/callSerially —
             * the same position the headless loop uses. */
            {
                extern void midp_pump_pending_shownotify(JVM* jvm);
                midp_pump_pending_shownotify(ctx->jvm);
            }
            jvm_process_timers(ctx->jvm);
            {
                /* v35: age key queue + fallback delivery (event-driven menus) */
                extern void midp_frame_tick(void);
                extern void midp_pump_deferred_keys(JVM* jvm);
                midp_frame_tick();
                midp_pump_deferred_keys(ctx->jvm);
            }
            sd_stage_max(&g_sd_tj_ms_max, &sd_tj_t0);
        }
        uint64_t current_time = SDL_GetTicks();
        bool current_needs_redraw = atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire);
        if (!current_needs_redraw && (current_time - last_auto_redraw) >= auto_redraw_interval) {
            atomic_store_explicit(&ctx->needs_redraw, true, memory_order_release);
            last_auto_redraw = current_time;
        }

        /* DEBUG: Log first 30 checks */
        if (loop_count <= 30) {
            bool needs_redraw_val = atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire);
            LOG_SAFE("[MAIN_LOOP] iteration=%d, needs_redraw=%d\n", loop_count, needs_redraw_val);
        }

        bool needs_redraw_val = atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire);
        if (needs_redraw_val) {
            /* Clear the flag BEFORE processing to avoid race condition */
            atomic_store_explicit(&ctx->needs_redraw, false, memory_order_release);

            struct timespec sd_rj_t0;
            clock_gettime(CLOCK_MONOTONIC, &sd_rj_t0);
            SW_DIAG_STAGE("repaints");
            /* v35.02: pump FIRST, then drain the game-logic queue. MIDP
             * ordering: a queued Runnable (the game's frame logic) runs
             * after the repaint it requested has been painted. The old
             * order (drain before pump) made the drain's repaint gate
             * defer the logic on EVERY iteration where the game thread had
             * a paint in flight — under load that collapsed the logic
             * cadence to ~1 Hz (the race crawl) and then to 0 (freeze). */
            {
                extern int midp_process_repaints(JVM* jvm);
                int painted = midp_process_repaints(ctx->jvm);
                /* v35.02 CONDITIONAL CLEAR: only a pump that actually ran
                 * may consume the pending state. The old unconditional
                 * clear also fired after SKIPPED pumps (UI lock busy) and
                 * (a) dropped g_dirty_valid = lost frame content,
                 * (b) told the game thread's serviceRepaints a paint had
                 * completed when none had — both desynchronize the
                 * handshake and starve the logic queue. */
                if (painted) {
                    extern void midp_clear_pending_repaint(void);
                    midp_clear_pending_repaint();
                }
            }
            sd_stage_max(&g_sd_rj_ms_max, &sd_rj_t0);

            /* В J2ME, поток с необработанным исключением НЕ останавливает приложение.
             * Только этот поток завершается, остальные продолжают работать.
             */
        }

        SW_DIAG_STAGE("callserially");
        {
            struct timespec sd_sj_t0;
            clock_gettime(CLOCK_MONOTONIC, &sd_sj_t0);
            midp_process_call_serially_queue(ctx->jvm);
            midp_check_alert_timeout(ctx->jvm);
            sd_stage_max(&g_sd_sj_ms_max, &sd_sj_t0);
        }

        SW_DIAG_STAGE("present");
#ifdef __SWITCH__
        /* v34.94 ASPECT FIX: the old inline RenderCopy used a NULL dst rect —
         * SDL stretched the game texture over the WHOLE screen regardless of
         * the Масштаб setting (the pause menu drew with the correct rect,
         * which is exactly the user's "только в паузе пропорции верные").
         * Present through the same path the pause menu uses. */
        SDL_LOCK();
        sdl_switch_present_game(ctx);
        SDL_UNLOCK();
#else
        SDL_LOCK();
        sdl_update_texture(ctx);
        SDL_RenderClear(g_renderer);
        SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
        SDL_RenderPresent(g_renderer);
        SDL_UNLOCK();
#endif

        /* v50 (Asphalt image freeze): end-of-frame vsync tick — game-thread
         * serviceRepaints() paces itself on this (KVM vblank semantics). */
        SW_DIAG_STAGE("vsync");
        {
            extern void midp_vsync_tick(void);
            midp_vsync_tick();
            __sync_fetch_and_add(&g_sd_vs, 1);
        }

        SW_DIAG_STAGE("pace");
#ifdef __SWITCH__
        /* v34.94 diag: iteration bookkeeping (loop/stl) + 5 s diag line. */
        {
            struct timespec sd_iter_t1;
            clock_gettime(CLOCK_MONOTONIC, &sd_iter_t1);
            int64_t iter_ms = (int64_t)(sd_iter_t1.tv_sec - sd_iter_t0.tv_sec) * 1000 +
                             (int64_t)(sd_iter_t1.tv_nsec - sd_iter_t0.tv_nsec) / 1000000;
            int64_t over_ms = iter_ms - 17;
            if (over_ms > 0) __sync_fetch_and_add(&g_sd_stl_ms, (uint32_t)over_ms);
            /* v35.01: worst single iteration this period (mx=) — splits
             * "uniformly slow" (many mid-size stalls) from "one giant
             * stall" (a blocked present / a hundred-ms paint); stl alone
             * cannot tell 78 x 17 ms from 1 x 1300 ms. */
            if (iter_ms > (int64_t)g_sd_iter_ms_max)
                g_sd_iter_ms_max = (uint32_t)iter_ms;
            __sync_fetch_and_add(&g_sd_loop, 1);
            sw_diag_tick();
        }
#endif
        current_time = SDL_GetTicks();
        uint64_t elapsed = current_time - last_time;
        if (elapsed < frame_time) {
            SDL_Delay(1);
        }
        last_time = SDL_GetTicks();
    }

#ifdef __SWITCH__
    /* v34.94: game loop left — disarm the STUCK watchdog (the frontend
     * menu runs its own pump loop and must not be reported as stuck). */
    SW_DIAG_STAGE(NULL);
#endif

    /* v34.72: the loop above exited because the MIDlet finished
     * (ctx->jvm->running == false while ctx->running is still true —
     * the window-close path clears BOTH). Show the explicit "finished"
     * screen and keep the window responsive until the user closes it;
     * without this the window vanished without any indication that the
     * MIDlet had ended normally. */
    if (ctx->running && ctx->jvm && !ctx->jvm->running && !sdl_has_error()) {
        LOG_SAFE("[SDL] MIDlet finished — showing finished screen until window close\n");
        sdl_draw_midlet_finished_screen(ctx);
        SDL_LOCK();
        sdl_update_texture(ctx);
        SDL_RenderClear(g_renderer);
        SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
        SDL_RenderPresent(g_renderer);
        SDL_UNLOCK();
#ifdef __SWITCH__
        /* Switch: show the finished screen until A/B or 3 s, then fall
         * through — control returns to the frontend menu (switch main).
         * v34.90: same single pump as everything else (hotplug included). */
        {
            uint64_t t0 = SDL_GetTicks();
            switch_input_reset();
            for (;;) {
                unsigned keys = sdl_switch_ui_pump_keys();
                if (keys & (SWK_A | SWK_B) || keys & SWK_EXIT) break;
                if (SDL_GetTicks() - t0 > 3000) break;
                SDL_Delay(16);
            }
        }
#else
        for (;;) {
            SDL_Event ev;
            bool quit = false;
            while (SDL_PollEvent(&ev)) {
                if (ev.type == SDL_QUIT) quit = true;
                if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) quit = true;
            }
            if (quit) break;
            SDL_Delay(16);
        }
#endif
    }
#else
    /* Headless mode - simple delay loop (No SDL2) */
    uint64_t last_auto_redraw = 0;
    const uint64_t auto_redraw_interval = 16;  /* ~60 FPS */
    int headless_loop_count = 0;
    
    LOG_SAFE("[HEADLESS] Starting headless main loop (No SDL2)\n");
    
    /* ИСПРАВЛЕНО: Устанавливаем начальную перерисовку */
    ctx->needs_redraw = true;
    last_auto_redraw = 0;
    
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        headless_loop_count++;
        
        /* Process timers */
        jvm_process_timers(ctx->jvm);
        
        /* Process callSerially queue */
        midp_process_call_serially_queue(ctx->jvm);
        
        /* Check Alert timeout */
        midp_check_alert_timeout(ctx->jvm);
        
        /* ИСПРАВЛЕНО: Автоматическая перерисовка в headless режиме */
        uint64_t current_time = sdl_get_ticks(ctx);
        uint64_t elapsed = current_time - last_auto_redraw;
        
        if (elapsed >= auto_redraw_interval) {
            ctx->needs_redraw = true;
            last_auto_redraw = current_time;
            if (headless_loop_count <= 10) {
                LOG_SAFE("[HEADLESS] Auto-redraw at iteration %d (elapsed=%lu ms)\n", 
                        headless_loop_count, (unsigned long)elapsed);
            }
        }
        
        /* Process pending repaints */
        if (ctx->needs_redraw) {
            /* v35.02: conditional clear — only a pump that ran may consume
             * the pending state (see the Switch main loop). */
            int painted = midp_process_repaints(ctx->jvm);
            ctx->needs_redraw = false;

            /* ИСПРАВЛЕНО: Сигнализируем что repaint обработан */
            if (painted) {
                extern void midp_clear_pending_repaint(void);
                midp_clear_pending_repaint();
            }
            
            /* В J2ME, поток с необработанным исключением НЕ останавливает приложение.
             * Только этот поток завершается, остальные продолжают работать.
             */
        }
        
#ifdef _WIN32
        Sleep(16);  /* ~60 FPS on Windows */
#else
        usleep(16000);  /* ~60 FPS on POSIX */
#endif

        /* v50 (Asphalt image freeze): vsync tick for this fallback loop too. */
        {
            extern void midp_vsync_tick(void);
            midp_vsync_tick();
        }

        /* Limit headless execution time */
        if (headless_loop_count > 6000) {
            LOG_SAFE("[HEADLESS] Maximum iterations reached\n");
            break;
        }
    }
#endif
}

/* Stop */
void sdl_stop(SdlContext* ctx) {
    if (ctx) ctx->running = false;
}

/* Get framebuffer */
uint32_t* sdl_get_framebuffer(SdlContext* ctx) {
    return ctx ? ctx->framebuffer : NULL;
}

/* Clear */
void sdl_clear(SdlContext* ctx, uint32_t color) {
    if (!ctx || !ctx->framebuffer) return;
    for (int i = 0; i < ctx->width * ctx->height; i++) {
        ctx->framebuffer[i] = color;
    }
}

/* Save framebuffer to file (for headless mode debugging) */
void sdl_save_framebuffer_to_file(SdlContext* ctx, const char* filename) {
    if (!ctx || !ctx->framebuffer) return;
    
    FILE* f = fopen(filename, "wb");
    if (!f) {
        LOG_SAFE("[SDL] Failed to open %s for writing\n", filename);
        return;
    }
    
    /* Write PPM header (P6 = RGB binary) */
    fprintf(f, "P6\n%d %d\n255\n", ctx->width, ctx->height);
    
    /* Write pixels (convert ARGB to RGB) */
    for (int i = 0; i < ctx->width * ctx->height; i++) {
        uint32_t pixel = ctx->framebuffer[i];
        uint8_t r = (pixel >> 16) & 0xFF;
        uint8_t g = (pixel >> 8) & 0xFF;
        uint8_t b = pixel & 0xFF;
        fwrite(&r, 1, 1, f);
        fwrite(&g, 1, 1, f);
        fwrite(&b, 1, 1, f);
    }
    
    fclose(f);
    LOG_SAFE("[SDL] Saved framebuffer to %s (%dx%d)\n", filename, ctx->width, ctx->height);
}

/* Present */
void sdl_present(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    sdl_render_thread_check("present");
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) {
        GFX_DEBUG("[SDL] present: invalid context or texture");
        return;
    }
#ifdef __SWITCH__
    SDL_LOCK();
    sdl_switch_present_game(ctx);
    SDL_UNLOCK();
    return;
#endif
    
    static int present_count = 0;
    present_count++;
    if (present_count <= 10) {
        /* Check pixels at position where title.png should be (y=53) */
        int y = 53;
        GFX_DEBUG("[SDL] present #%d: pixel at (0,0)=0x%08X, pixel at (120,53)=0x%08X, pixel at (0,53)=0x%08X", 
                present_count, ctx->framebuffer[0], 
                ctx->framebuffer[y * ctx->width + 120],
                ctx->framebuffer[y * ctx->width + 0]);
    }
    
    SDL_LOCK();
    sdl_update_texture(ctx);
    SDL_RenderClear(g_renderer);
    SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
    SDL_RenderPresent(g_renderer);
    SDL_UNLOCK();
#endif
}

/* Update texture */
void sdl_update_texture(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    sdl_render_thread_check("update_texture");
    if (ctx && ctx->framebuffer && g_texture) {
        /* Debug: show first few pixels */
        static int update_count = 0;
        update_count++;
        if (update_count <= 5) {
            GFX_DEBUG("[SDL] update_texture #%d: first pixels = 0x%08X 0x%08X 0x%08X", 
                    update_count, ctx->framebuffer[0], ctx->framebuffer[1], ctx->framebuffer[2]);
        }
        
        /* v34.61 (Asphalt 3 3D "rarely delivers 3D frames" - same fix as
         * libretro_end_frame): upload the latest SETTLED frame, not the live
         * framebuffer. The game thread paints asynchronously into
         * ctx->framebuffer; uploading it mid-paint showed torn/partial
         * frames (background only). A settled snapshot exists only after a
         * COMPLETE frame, so tearing is impossible by construction. */
        {
            extern uint32_t midp_present_stable_copy(uint32_t* dst, int dst_px);
            static uint32_t* s_scanout = NULL;
            static int s_scanout_px = 0;
            int px = ctx->width * ctx->height;
            if (px > 0 && px <= 8192 * 8192) {
                if (px > s_scanout_px) {
                    uint32_t* nb = (uint32_t*)realloc(s_scanout,
                                                      (size_t)px * sizeof(uint32_t));
                    if (nb) { s_scanout = nb; s_scanout_px = px; }
                }
                if (s_scanout &&
                    midp_present_stable_copy(s_scanout, s_scanout_px) != 0) {
                    SDL_UpdateTexture(g_texture, NULL, s_scanout,
                                      ctx->width * sizeof(uint32_t));
                    return;
                }
            }
        }
        /* Bootstrap / fallback (nothing settled yet): live framebuffer,
         * pre-v34.61 behavior */
        SDL_UpdateTexture(g_texture, NULL, ctx->framebuffer,
            ctx->width * sizeof(uint32_t));
    }
#endif
}

/* Key mapping */
int sdl_key_to_midp(int sdl_key) {
#if SDL2_AVAILABLE
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == sdl_key) return key_map[i].midp_key;
    }
#endif
    return sdl_key;
}

int sdl_key_to_game_action(int sdl_key) {
    (void)sdl_key;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == sdl_key) return key_map[i].game_action;
    }
#endif
    return 0;
}

/* Key state - uses SDL_GetKeyboardState for real-time state */
bool sdl_key_pressed(SdlContext* ctx, int keycode) {
    (void)ctx;  /* Not needed when using SDL_GetKeyboardState */
    
#if SDL2_AVAILABLE
    /* Pump events to ensure keyboard state is current */
    SDL_PumpEvents();
    
    /* Get the current keyboard state directly from SDL */
    const Uint8* keyboard_state = SDL_GetKeyboardState(NULL);
    if (!keyboard_state) {
        return false;
    }
    
    /* Map Nokia FullCanvas keyCode to SDL scancode */
    /* -1=UP, -2=DOWN, -3=LEFT, -4=RIGHT, -5=FIRE */
    SDL_Scancode scancode = 0;
    switch (keycode) {
        case -1:  /* UP (Nokia FULL_UP) */
        case GAME_UP:
            scancode = SDL_SCANCODE_UP; 
            break;
        case -2:  /* DOWN (Nokia FULL_DOWN) */
        case GAME_DOWN:
            scancode = SDL_SCANCODE_DOWN; 
            break;
        case -3:  /* LEFT (Nokia FULL_LEFT) */
        case GAME_LEFT:
            scancode = SDL_SCANCODE_LEFT; 
            break;
        case -4:  /* RIGHT (Nokia FULL_RIGHT) */
        case GAME_RIGHT:
            scancode = SDL_SCANCODE_RIGHT; 
            break;
        case -5:  /* FIRE (Nokia FULL_FIRE) */
        case GAME_FIRE:
            /* FIRE can be Return or Space */
            if (keyboard_state[SDL_SCANCODE_RETURN] || keyboard_state[SDL_SCANCODE_SPACE]) {
                GFX_DEBUG("[sdl_key_pressed] FIRE (keycode=%d) -> pressed", keycode);
                return true;
            }
            return false;
        case -6:  /* GAME_A */
        case GAME_A:
            scancode = SDL_SCANCODE_A; 
            break;
        case -7:  /* GAME_B */
        case GAME_B:
            scancode = SDL_SCANCODE_B; 
            break;
        case -8:  /* GAME_C */
        case GAME_C:
            scancode = SDL_SCANCODE_C; 
            break;
        case -9:  /* GAME_D */
        case GAME_D:
            scancode = SDL_SCANCODE_D; 
            break;
        default:
            /* For other keycodes (regular keys), check keyboard state directly */
            if (keycode >= 0 && keycode < 256) {
                /* Try to map ASCII to scancode */
                if (keycode >= '0' && keycode <= '9') {
                    scancode = SDL_SCANCODE_0 + (keycode - '0');
                } else if (keycode >= 'a' && keycode <= 'z') {
                    scancode = SDL_SCANCODE_A + (keycode - 'a');
                } else {
                    return false;
                }
            } else {
                return false;
            }
            break;
    }
    
    bool state = keyboard_state[scancode];
    if (state) {
        GFX_DEBUG("[sdl_key_pressed] keycode=%d -> pressed (scancode=%d)", keycode, scancode);
    }
    return state;
#else
    (void)keycode;
    return false;
#endif
}

/* Pointer */
void sdl_get_pointer(SdlContext* ctx, int* x, int* y) {
    if (!ctx) { if (x) *x = 0; if (y) *y = 0; return; }
    if (x) *x = ctx->input.pointer_x;
    if (y) *y = ctx->input.pointer_y;
}

bool sdl_pointer_pressed(SdlContext* ctx) {
    return ctx ? ctx->input.pointer_pressed : false;
}

/* Audio */
int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
#if defined(__SWITCH__) && SDL2_AVAILABLE
    if (!switch_settings_get()->audio_enabled) return -1; /* Звук: Выкл */
#endif
    (void)ctx; (void)frequency; (void)channels; (void)samples;
#if SDL2_AVAILABLE
    if (g_audio_dev) SDL_CloseAudioDevice(g_audio_dev);

    sw_trace("audio: open %d Hz %d ch", frequency, channels); /* v34.91: emulator hang point #1 */

    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof(want));
    want.freq = frequency;
    want.format = AUDIO_S16;
    want.channels = channels;
    want.samples = samples;
    want.callback = NULL;  /* Use SDL_QueueAudio instead of callback */
    want.userdata = ctx;

    g_audio_dev = SDL_OpenAudioDevice(NULL, 0, &want, &have,
        SDL_AUDIO_ALLOW_FREQUENCY_CHANGE | SDL_AUDIO_ALLOW_CHANNELS_CHANGE);

    if (g_audio_dev == 0) {
        DEBUG_LOG("[SDL] Failed to open audio: %s", SDL_GetError());
        return -1;
    }

    SDL_PauseAudioDevice(g_audio_dev, 0);
    DEBUG_LOG("[SDL] Audio: %d Hz, %d channels, buffer=%d samples", have.freq, have.channels, have.samples);
    return 0;
#else
    return 0;
#endif
}

void sdl_audio_close(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    pthread_mutex_lock(&g_audio_dev_mutex);
    if (g_audio_dev) { SDL_CloseAudioDevice(g_audio_dev); g_audio_dev = 0; }
    pthread_mutex_unlock(&g_audio_dev_mutex);
#endif
}

int sdl_audio_queue(SdlContext* ctx, const void* data, size_t length) {
    (void)ctx; (void)data; (void)length;
#if SDL2_AVAILABLE
    if (g_audio_dev) return SDL_QueueAudio(g_audio_dev, data, length);
#endif
    return -1;
}

uint32_t sdl_audio_queued_size(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) return SDL_GetQueuedAudioSize(g_audio_dev);
#endif
    return 0;
}

void sdl_audio_clear(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) SDL_ClearQueuedAudio(g_audio_dev);
#endif
}

/* Simple audio init without context */
int sdl_audio_init_simple(uint32_t sample_rate) {
#if SDL2_AVAILABLE
    pthread_mutex_lock(&g_audio_dev_mutex);
    if (g_audio_dev) { pthread_mutex_unlock(&g_audio_dev_mutex); return 0; }  /* Already initialized */
#ifdef __SWITCH__
    if (!switch_settings_get()->audio_enabled) { pthread_mutex_unlock(&g_audio_dev_mutex); return -1; } /* Звук: Выкл */
#endif
    pthread_mutex_unlock(&g_audio_dev_mutex);

    sw_trace("audio: open %lu Hz stereo", (unsigned long)sample_rate); /* v34.91 */

    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof(want));
    want.freq = sample_rate;
    want.format = AUDIO_S16;
    want.channels = 2;  /* Stereo */
    want.samples = 2048;  /* Larger buffer for queue-based audio */
    want.callback = NULL;  /* Use SDL_QueueAudio instead of callback */
    want.userdata = NULL;

    SDL_AudioDeviceID dev = SDL_OpenAudioDevice(NULL, 0, &want, &have,
        SDL_AUDIO_ALLOW_FREQUENCY_CHANGE | SDL_AUDIO_ALLOW_CHANNELS_CHANGE);

    if (dev == 0) {
        DEBUG_LOG("[SDL] Failed to open audio: %s", SDL_GetError());
        sw_trace("audio: open FAILED"); /* v34.94: name the failure in the log */
        return -1;
    }

    SDL_PauseAudioDevice(dev, 0);  /* Start audio */
    pthread_mutex_lock(&g_audio_dev_mutex);
    g_audio_dev = dev;
    pthread_mutex_unlock(&g_audio_dev_mutex);
    DEBUG_LOG("[SDL] Audio initialized: %d Hz, %d channels, buffer=%d samples",
              have.freq, have.channels, have.samples);
    return 0;
#else
    (void)sample_rate;
    return 0;
#endif
}

void sdl_audio_shutdown(void) {
#if SDL2_AVAILABLE
    pthread_mutex_lock(&g_audio_dev_mutex);
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
    pthread_mutex_unlock(&g_audio_dev_mutex);
#endif
}

/* Timing */
uint64_t sdl_get_ticks(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    return SDL_GetTicks();
#else
#ifdef _WIN32
    return GetTickCount();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
#endif
}

void sdl_sleep(uint32_t ms) {
#if SDL2_AVAILABLE
    SDL_Delay(ms);
#else
#ifdef _WIN32
    Sleep(ms);
#else
    usleep(ms * 1000);
#endif
#endif
}

/* Window */
void sdl_set_title(SdlContext* ctx, const char* title) {
    (void)ctx;
    (void)title;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (g_window && title) SDL_SetWindowTitle(g_window, title);
#endif
}

void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) {
    (void)ctx; (void)fullscreen;
#if SDL2_AVAILABLE
    if (g_window) SDL_SetWindowFullscreen(g_window,
        fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
#endif
}

void sdl_toggle_fullscreen(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_window) {
        Uint32 flags = SDL_GetWindowFlags(g_window);
        SDL_SetWindowFullscreen(g_window,
            (flags & SDL_WINDOW_FULLSCREEN_DESKTOP) ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP);
    }
#endif
}

int sdl_resize(SdlContext* ctx, int width, int height) {
    if (!ctx || width <= 0 || height <= 0) return -1;

    /* ИСПРАВЛЕНО: Сначала выделяем новую память, потом освобождаем старую */
    uint32_t* new_framebuffer = (uint32_t*)malloc(width * height * sizeof(uint32_t));
    if (!new_framebuffer) {
        ERROR_LOG("[SDL] Failed to allocate new framebuffer in sdl_resize");
        return -1;
    }
    
    /* Инициализируем чёрным непрозрачным цветом */
    for (int i = 0; i < width * height; i++) {
        new_framebuffer[i] = 0xFF000000;
    }

#if SDL2_AVAILABLE
    SDL_Texture* new_texture = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
        SDL_TEXTUREACCESS_STREAMING, width, height);
    if (!new_texture) {
        ERROR_LOG("[SDL] Failed to create new texture in sdl_resize: %s", SDL_GetError());
        free(new_framebuffer);
        return -1;
    }
#endif

    /* Only free old resources after successful allocation */
    free(ctx->framebuffer);
    ctx->framebuffer = new_framebuffer;
    ctx->width = width;
    ctx->height = height;

#if SDL2_AVAILABLE
    if (g_texture) SDL_DestroyTexture(g_texture);
    g_texture = new_texture;
    SDL_RenderSetLogicalSize(g_renderer, width, height);
#endif
    return 0;
}

int sdl_screenshot(SdlContext* ctx, const char* filename) {
    if (!ctx || !filename) return -1;
#if SDL2_AVAILABLE
    if (g_renderer) {
        SDL_Surface* surface = SDL_CreateRGBSurface(0,
            ctx->width * ctx->scale, ctx->height * ctx->scale, 32,
            0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        if (surface) {
            SDL_RenderReadPixels(g_renderer, NULL, SDL_PIXELFORMAT_ARGB8888,
                surface->pixels, surface->pitch);
            int result = SDL_SaveBMP(surface, filename);
            SDL_FreeSurface(surface);
            return result;
        }
    }
#endif
    return -1;
}

/* Global graphics context for screen - used by display.c */
static MidpGraphics g_sdl_graphics;

MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    if (!ctx) {
        DEBUG_LOG("[SDL] WARNING: sdl_get_graphics called with NULL context");
        return NULL;
    }
    if (!ctx->framebuffer) {
        DEBUG_LOG("[SDL] WARNING: sdl_get_graphics - framebuffer is NULL");
        return NULL;
    }
    /* Only re-init if dimensions changed */
    if (g_sdl_graphics.width != ctx->width || g_sdl_graphics.height != ctx->height ||
        g_sdl_graphics.pixels != ctx->framebuffer) {
        midp_graphics_init(&g_sdl_graphics, ctx->framebuffer, ctx->width, ctx->height);
    }
    return &g_sdl_graphics;
}

/* Check if the given graphics context is the screen graphics */
bool sdl_is_screen_graphics(MidpGraphics* gfx) {
    return gfx == &g_sdl_graphics;
}

MidpPlatformCallbacks* sdl_get_platform_callbacks(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

void sdl_dump_info(SdlContext* ctx) {
    if (!ctx) return;
    DEBUG_LOG("[SDL] Window: %dx%d (scale: %d)", ctx->width, ctx->height, ctx->scale);
#if SDL2_AVAILABLE
    DEBUG_LOG("[SDL] Renderer: %s", SDL_GetCurrentVideoDriver());
    if (g_window) {
        int w, h;
        SDL_GetWindowSize(g_window, &w, &h);
        DEBUG_LOG("[SDL] Window size: %dx%d", w, h);
    }
#else
    DEBUG_LOG("[SDL] Running in headless mode");
#endif
}

/* Queue audio samples directly
 * v34.94 FREEZE FIX: the media audio thread produced ~realtime slices with
 * blind 5 ms pacing; any production/consumption drift accumulated in the
 * SDL queue forever (the user's v34.93 diag: sb 0 -> 812+ and climbing,
 * stl/sr climbing with it, then a full frontend freeze). Two guards now:
 *  1. HARD CAP — when the queue already holds more than
 *     NOJME_AUDIO_QUEUE_CAP_BYTES, the fresh slice is DROPPED (never
 *     queued): backlog can no longer grow unboundedly whatever the drift.
 *  2. DEVICE LOCK — g_audio_dev is read/written from the media thread and
 *     closed from the frontend thread; a small mutex keeps check+queue
 *     atomic against SDL_CloseAudioDevice.
 * sr (sound-related stall ms per diag period) is accumulated around the
 * SDL_QueueAudio call so the next diag line SHOWS if this path stalls. */
void sdl_audio_queue_samples(const int16_t* samples, size_t count) {
    (void)samples; (void)count;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (!samples || count == 0) return;
    struct timespec ts0, ts1;
    int stamped = 0;
    pthread_mutex_lock(&g_audio_dev_mutex);
    if (g_audio_dev) {
        size_t queued = SDL_GetQueuedAudioSize(g_audio_dev);
        if (queued < NOJME_AUDIO_QUEUE_CAP_BYTES) {
            clock_gettime(CLOCK_MONOTONIC, &ts0); stamped = 1;
            SDL_QueueAudio(g_audio_dev, samples, count * sizeof(int16_t));
            if (stamped) {
                clock_gettime(CLOCK_MONOTONIC, &ts1);
                uint32_t ms = (uint32_t)((ts1.tv_sec - ts0.tv_sec) * 1000 +
                                         (ts1.tv_nsec - ts0.tv_nsec) / 1000000);
                if (ms) __sync_fetch_and_add(&g_sd_sr_ms, ms);
            }
        }
        /* else: queue over the cap — drop the slice (backpressure) */
    }
    pthread_mutex_unlock(&g_audio_dev_mutex);
#endif
}

/* Get queued audio size (samples) — also used by the v34.94 diag (sb). */
size_t sdl_audio_get_queued_size(void) {
#if SDL2_AVAILABLE
    if (g_audio_dev) {
        return SDL_GetQueuedAudioSize(g_audio_dev) / sizeof(int16_t);
    }
#endif
    return 0;
}

/* v34.94 diag + media pacing: raw queued BYTES (sb= in the diag line) and
 * a device-alive probe (the media thread idles when no device is open). */
size_t sdl_audio_queued_bytes(void) {
#if SDL2_AVAILABLE
    pthread_mutex_lock(&g_audio_dev_mutex);
    SDL_AudioDeviceID dev = g_audio_dev;
    pthread_mutex_unlock(&g_audio_dev_mutex);
    if (dev) return SDL_GetQueuedAudioSize(dev);
#endif
    return 0;
}

int sdl_audio_device_alive(void) {
#if SDL2_AVAILABLE
    pthread_mutex_lock(&g_audio_dev_mutex);
    int alive = (g_audio_dev != 0);
    pthread_mutex_unlock(&g_audio_dev_mutex);
    return alive;
#else
    return 0;
#endif
}

/* ============================================================
 * Error Screen Display - Shows unhandled exception info
 * ============================================================ */

/* Include bitmap font for error display */
#include "midp/bitmap_font.h"

/* Draw a single character at position (uses bitmap font) */
static void draw_error_char(uint32_t* framebuffer, int fb_width, int fb_height,
                            int codepoint, int x, int y, uint32_t color) {
    if (!framebuffer || x < 0 || y < 0) return;
    if (x + FONT_WIDTH > fb_width || y + FONT_HEIGHT > fb_height) return;
    
    const uint8_t* char_data = get_char_data_unicode(codepoint);
    if (!char_data) return;
    
    for (int row = 0; row < FONT_HEIGHT; row++) {
        uint8_t row_data = char_data[row];
        for (int col = 0; col < FONT_WIDTH; col++) {
            if (row_data & (1 << (4 - col))) {  /* MSB is leftmost */
                int px = x + col;
                int py = y + row;
                if (px >= 0 && px < fb_width && py >= 0 && py < fb_height) {
                    framebuffer[py * fb_width + px] = color;
                }
            }
        }
    }
}

/* Draw a UTF-8 string at position */
static void draw_error_string(uint32_t* framebuffer, int fb_width, int fb_height,
                              const char* str, int x, int y, uint32_t color) {
    if (!framebuffer || !str) return;
    
    int cur_x = x;
    int cur_y = y;
    int len = 0;
    while (str[len]) len++;
    
    int i = 0;
    while (i < len) {
        int codepoint = utf8_decode(str, &i, len);
        if (codepoint < 0) break;
        
        /* Handle newline */
        if (codepoint == '\n') {
            cur_x = x;
            cur_y += FONT_HEIGHT + 2;
            continue;
        }
        
        /* Handle tab */
        if (codepoint == '\t') {
            cur_x += (FONT_WIDTH + 1) * 4;
            continue;
        }
        
        /* Skip if outside screen */
        if (cur_x + FONT_WIDTH > fb_width) {
            cur_x = x;
            cur_y += FONT_HEIGHT + 2;
        }
        
        if (cur_y + FONT_HEIGHT > fb_height) break;
        
        draw_error_char(framebuffer, fb_width, fb_height, codepoint, cur_x, cur_y, color);
        cur_x += FONT_WIDTH + 1;  /* +1 for spacing */
    }
}

/* Word-wrap text to fit width */
static int wrap_text_line(const char* text, int max_chars_per_line, char* buffer, int buffer_size) {
    if (!text || !buffer || buffer_size <= 0) return 0;
    
    int text_len = 0;
    while (text[text_len]) text_len++;
    
    int chars_written = 0;
    int line_pos = 0;
    int i = 0;
    
    while (i < text_len && chars_written < buffer_size - 1) {
        int codepoint = utf8_decode(text, &i, text_len);
        if (codepoint < 0) break;
        
        /* Count character width (simplified - all chars are 1 char width) */
        line_pos++;
        
        if (line_pos > max_chars_per_line && codepoint == ' ') {
            buffer[chars_written++] = '\n';
            line_pos = 0;
        } else {
            /* Convert codepoint to UTF-8 for buffer */
            if (codepoint < 0x80) {
                if (chars_written < buffer_size - 1) {
                    buffer[chars_written++] = (char)codepoint;
                }
            } else if (codepoint < 0x800) {
                if (chars_written < buffer_size - 2) {
                    buffer[chars_written++] = (char)(0xC0 | (codepoint >> 6));
                    buffer[chars_written++] = (char)(0x80 | (codepoint & 0x3F));
                }
            } else if (codepoint < 0x10000) {
                if (chars_written < buffer_size - 3) {
                    buffer[chars_written++] = (char)(0xE0 | (codepoint >> 12));
                    buffer[chars_written++] = (char)(0x80 | ((codepoint >> 6) & 0x3F));
                    buffer[chars_written++] = (char)(0x80 | (codepoint & 0x3F));
                }
            }
        }
    }
    
    buffer[chars_written] = '\0';
    return chars_written;
}

/* Global error message storage */
static char g_error_title[512] = {0};
static char g_error_message[2048] = {0};
static char g_error_stack[8192] = {0};
static char g_error_extra[2048] = {0};
static bool g_has_error = false;

/* Set error information for display */
void sdl_set_error_info(const char* title, const char* message, const char* stack_trace) {
    g_has_error = true;
    
    if (title) {
        strncpy(g_error_title, title, sizeof(g_error_title) - 1);
        g_error_title[sizeof(g_error_title) - 1] = '\0';
    } else {
        strcpy(g_error_title, "Error");
    }
    
    if (message) {
        strncpy(g_error_message, message, sizeof(g_error_message) - 1);
        g_error_message[sizeof(g_error_message) - 1] = '\0';
    } else {
        g_error_message[0] = '\0';
    }
    
    if (stack_trace) {
        strncpy(g_error_stack, stack_trace, sizeof(g_error_stack) - 1);
        g_error_stack[sizeof(g_error_stack) - 1] = '\0';
    } else {
        g_error_stack[0] = '\0';
    }
    
    /* Log to stderr */
    LOG_SAFE("\n========================================\n");
    LOG_SAFE("  [J2ME UNCAUGHT EXCEPTION]\n");
    LOG_SAFE("========================================\n");
    LOG_SAFE("  Exception: %s\n", g_error_title);
    if (g_error_message[0]) LOG_SAFE("  Message:   %s\n", g_error_message);
    if (g_error_extra[0]) LOG_SAFE("  Details:   %s\n", g_error_extra);
    if (g_error_stack[0]) LOG_SAFE("  Stack:\n%s", g_error_stack);
    LOG_SAFE("========================================\n\n");
}

/* Set extra detail info */
void sdl_set_error_extra(const char* extra) {
    if (extra) {
        strncpy(g_error_extra, extra, sizeof(g_error_extra) - 1);
        g_error_extra[sizeof(g_error_extra) - 1] = '\0';
    } else {
        g_error_extra[0] = '\0';
    }
}

/* Check if there's an error to display */
bool sdl_has_error(void) {
    return g_has_error;
}

/* Clear error state */
void sdl_clear_error(void) {
    g_has_error = false;
    g_error_title[0] = '\0';
    g_error_message[0] = '\0';
    g_error_stack[0] = '\0';
    g_error_extra[0] = '\0';
}

/* Draw the error screen */
void sdl_draw_error_screen(SdlContext* ctx) {
    if (!ctx || !ctx->framebuffer) return;
    
    int width = ctx->width;
    int height = ctx->height;
    uint32_t* fb = ctx->framebuffer;
    
    /* Colors: ARGB format */
    const uint32_t bg_color = 0xFF800000;      /* Dark red background */
    const uint32_t title_color = 0xFFFFFFFF;   /* White title */
    const uint32_t msg_color = 0xFFFFFF00;     /* Yellow message */
    const uint32_t stack_color = 0xFFCCCCCC;   /* Light gray stack trace */
    const uint32_t border_color = 0xFFFF0000;  /* Red border */
    
    /* Fill background */
    for (int i = 0; i < width * height; i++) {
        fb[i] = bg_color;
    }
    
    /* Draw border */
    int border_width = 2;
    for (int y = 0; y < border_width; y++) {
        for (int x = 0; x < width; x++) {
            fb[y * width + x] = border_color;
            fb[(height - 1 - y) * width + x] = border_color;
        }
    }
    for (int x = 0; x < border_width; x++) {
        for (int y = 0; y < height; y++) {
            fb[y * width + x] = border_color;
            fb[y * width + (width - 1 - x)] = border_color;
        }
    }
    
    /* Calculate character width for wrapping */
    int char_width = FONT_WIDTH + 1;
    int max_chars = (width - 20) / char_width;
    if (max_chars < 10) max_chars = 10;
    if (max_chars > 60) max_chars = 60;
    
    /* Draw title with prefix */
    char title_line[300];
    /* %.280s caps the copy: g_error_title is 512 bytes, title_line is 300 */
    snprintf(title_line, sizeof(title_line), "[ERROR] %.280s", g_error_title);
    draw_error_string(fb, width, height, title_line, 10, 10, title_color);
    
    /* Draw separator */
    int sep_y = 10 + FONT_HEIGHT + 4;
    for (int x = 10; x < width - 10; x++) {
        fb[sep_y * width + x] = border_color;
    }
    
    /* Draw message */
    int msg_y = sep_y + 10;
    if (g_error_message[0]) {
        char wrapped_msg[3000];
        wrap_text_line(g_error_message, max_chars, wrapped_msg, sizeof(wrapped_msg));
        draw_error_string(fb, width, height, wrapped_msg, 10, msg_y, msg_color);
        msg_y += FONT_HEIGHT * 3;  /* Move down for stack trace */
    }
    
    /* Draw stack trace header */
    if (g_error_stack[0]) {
        draw_error_string(fb, width, height, "Stack trace:", 10, msg_y, title_color);
        msg_y += FONT_HEIGHT + 4;
        
        /* Draw separator */
        for (int x = 10; x < width - 10; x++) {
            fb[msg_y * width + x] = border_color;
        }
        msg_y += 4;
        
        /* Draw stack trace with wrapping */
        char wrapped_stack[6000];
        wrap_text_line(g_error_stack, max_chars, wrapped_stack, sizeof(wrapped_stack));
        draw_error_string(fb, width, height, wrapped_stack, 10, msg_y, stack_color);
    }
    
    /* Draw instructions */
    int inst_y = height - FONT_HEIGHT - 15;
    draw_error_string(fb, width, height, "Press ESC to exit", 10, inst_y, stack_color);
    
    /* v34.61: the error screen is drawn straight into the framebuffer by
     * the main thread; make it the settled frame so the scanout presenter
     * (which no longer reads the live framebuffer) actually shows it. */
    {
        extern void midp_present_settled_snapshot(void);
        midp_present_settled_snapshot();
    }
    
    /* Force redraw flag */
    ctx->needs_redraw = true;
}

/* ============================================
 * v34.72: "MIDlet finished" screen (SDL window app).
 * Same rationale as the libretro twin in sdl_backend_stubs.c: a finished
 * MIDlet must be visibly finished, not a frozen last frame.
 * ============================================ */
static int finished_text_width_px(const char* s) {
    int n = 0, i = 0, len = 0;
    if (!s) return 0;
    while (s[len]) len++;
    while (i < len) {
        int codepoint = utf8_decode(s, &i, len);
        if (codepoint < 0) break;
        n++;
    }
    return n > 0 ? n * (FONT_WIDTH + 1) - 1 : 0;
}

void sdl_draw_midlet_finished_screen(SdlContext* ctx) {
    if (!ctx || !ctx->framebuffer) return;

    int width = ctx->width;
    int height = ctx->height;
    uint32_t* fb = ctx->framebuffer;

    /* Black background */
    for (int i = 0; i < width * height; i++) {
        fb[i] = 0xFF000000;
    }

    const uint32_t title_color = 0xFFFFFFFF;  /* white */
    const uint32_t sub_color   = 0xFFA8A8A8;  /* light gray */
    const uint32_t dim_color   = 0xFF707070;  /* dim gray */
    const uint32_t frame_color = 0xFF303030;  /* thin frame */

    /* Thin frame */
    for (int x = 0; x < width; x++) {
        fb[x] = frame_color;
        fb[(height - 1) * width + x] = frame_color;
    }
    for (int y = 1; y < height - 1; y++) {
        fb[y * width] = frame_color;
        fb[y * width + width - 1] = frame_color;
    }

    int center_y = (height / 2) - 24;

    const char* title = "MIDlet finished";
    {
        int x = (width - finished_text_width_px(title)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, title, x, center_y, title_color);
    }
    {
        const char* sub = "\xD0\x9C\xD0\xB8\xD0\xB4\xD0\xBB\xD0\xB5\xD1\x82 \xD0\xB7\xD0\xB0\xD0\xB2\xD0\xB5\xD1\x80\xD1\x88\xD1\x91\xD0\xBD";  /* "Мидлет завершён" */
        int x = (width - finished_text_width_px(sub)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, sub, x, center_y + FONT_HEIGHT + 6, sub_color);
    }
    {
        int y = center_y + 2 * (FONT_HEIGHT + 6) + 2;
        for (int x = width / 4; x < width - width / 4; x++) {
            fb[y * width + x] = frame_color;
        }
    }
    {
        const char* hint = "The application has ended";
        int x = (width - finished_text_width_px(hint)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, hint, x, center_y + 3 * (FONT_HEIGHT + 6), dim_color);
    }
    {
        const char* hint = "Close the window or press ESC";
        int x = (width - finished_text_width_px(hint)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, hint, x, height - 15, dim_color);
    }

    /* v34.61 semantics: make it the settled frame for the scanout. */
    {
        extern void midp_present_settled_snapshot(void);
        midp_present_settled_snapshot();
    }

    ctx->needs_redraw = true;
}

/* =========================================================================
 * v17: SDL clipboard bridge for com.nokia.mid.ui.Clipboard
 * v34.21: SDL_SetClipboardText/SDL_GetClipboardText need SDL >= 2.26; older
 * distros and mock-SDL builds don't have them — compile-time guard keeps
 * every configuration (real SDL2 new/old, mock, none) warning-free.
 * ========================================================================= */
#include <stdlib.h>
#if defined(__has_include)
#  if __has_include(<SDL2/SDL_version.h>)
#    include <SDL2/SDL_version.h>
#  elif __has_include(<SDL_version.h>)
#    include <SDL_version.h>
#  endif
#endif
#ifndef SDL_VERSION_ATLEAST
#  define SDL_VERSION_ATLEAST(X, Y, Z) 0
#endif

static void sdl_clipboard_set(const char* text) {
#if SDL_VERSION_ATLEAST(2, 26, 0)
    if (text && text[0]) {
        SDL_SetClipboardText(text);
    }
#else
    (void)text; /* clipboard unsupported on this SDL2 */
#endif
}

static char* sdl_clipboard_get(void) {
#if SDL_VERSION_ATLEAST(2, 26, 0)
    char* sys = SDL_GetClipboardText();
    if (!sys || !sys[0]) {
        if (sys) SDL_free(sys);
        return NULL;
    }
    /* Caller frees with free(); SDL requires SDL_free, so copy out */
    char* out = strdup(sys);
    SDL_free(sys);
    return out;
#else
    return NULL; /* clipboard unsupported on this SDL2 */
#endif
}

void sdl_setup_clipboard_hooks(void) {
    extern void midp_set_clipboard_hooks(void (*set_fn)(const char*), char* (*get_fn)(void));
    midp_set_clipboard_hooks(sdl_clipboard_set, sdl_clipboard_get);
}
