import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.midlet.MIDlet;

/**
 * scripts/testkeys — GameCanvas.getKeyStates() hold-semantics self-test.
 *
 * Verifies the v36.00 KEY-HOLD-BY-DELIVERY fix: held bits are maintained by
 * key DELIVERY events (not by polling SDL_GetKeyboardState, which is always
 * empty for gamepad synthetics on Switch — the "dead controls in 3D Asia
 * Rally" bug). The harness (j2me-headless) presses FIRE (-5) at frame 100
 * and holds it for NOJME_HEADLESS_KEYHOLD frames, then releases.
 *
 * PASS = FIRE visible in >= 300 consecutive getKeyStates() polls during the
 * hold (old behavior: 1 poll — the tap latch only) AND FIRE absent after
 * release.
 */
public class TestKeys extends MIDlet implements Runnable {
    private TestCanvas canvas;
    private Thread thread;

    public TestKeys() {
        canvas = new TestCanvas();
    }

    public void startApp() {
        Display.getDisplay(this).setCurrent(canvas);
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public void pauseApp() { }

    public void destroyApp(boolean unconditional) { }

    public void run() {
        // Phase 1: wait for the harness FIRE press; count consecutive polls
        // with FIRE visible. Poll cadence follows Thread.sleep quantization
        // (~10-30 ms per iteration on this VM) — the loop adapts and prints
        // a heartbeat so the harness log shows the cadence.
        int maxHold = 0, cur = 0;
        for (int i = 0; i < 4000; i++) {
            int ks = canvas.getKeyStates();
            if ((ks & 0x0100) != 0) {          // FIRE_PRESSED
                cur++;
                if (cur > maxHold) maxHold = cur;
            } else {
                cur = 0;
            }
            if ((i % 200) == 0) {
                System.out.println("[TESTKEYS] beat i=" + i + " cur=" + cur
                        + " maxHold=" + maxHold);
            }
            // once we have seen a hold and it just ended, move on
            if (maxHold > 0 && cur == 0 && i > 100) break;
            sleep(10);
        }

        System.out.println("[TESTKEYS] hold_polls=" + maxHold);

        // Phase 2: after release FIRE must be gone in every poll.
        int afterBad = 0;
        for (int i = 0; i < 50; i++) {
            if ((canvas.getKeyStates() & 0x0100) != 0) afterBad++;
            sleep(10);
        }

        System.out.println("[TESTKEYS] after_release_bad=" + afterBad);
        boolean pass = (maxHold >= 250) && (afterBad == 0);
        System.out.println(pass ? "[TESTKEYS] PASS" : "[TESTKEYS] FAIL");
        notifyDestroyed();
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { }
    }

    private static class TestCanvas extends GameCanvas {
        TestCanvas() {
            super(false); // do NOT suppress key events: keyPressed must also
                          // be delivered alongside getKeyStates
        }
        protected void paint(javax.microedition.lcdui.Graphics g) { }
    }
}
