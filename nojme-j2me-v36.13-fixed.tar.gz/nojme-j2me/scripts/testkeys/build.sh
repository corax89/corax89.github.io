#!/bin/bash
# Build TestKeys.jar — the v36.00 getKeyStates hold-semantics selftest midlet.
# Requires: JRE (java) + ECJ (ecj.jar).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestKeys.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java" \
    "$D/stubs/javax/microedition/lcdui/Display.java" \
    "$D/stubs/javax/microedition/lcdui/Displayable.java" \
    "$D/stubs/javax/microedition/lcdui/Canvas.java" \
    "$D/stubs/javax/microedition/lcdui/Graphics.java" \
    "$D/stubs/javax/microedition/lcdui/game/GameCanvas.java"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestKeys\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT/TestKeys.class" "$OUT/pkg/"
cp "$OUT/'TestKeys\$TestCanvas.class'" "$OUT/pkg/" 2>/dev/null || \
    cp "$OUT/TestKeys\$TestCanvas.class" "$OUT/pkg/" 2>/dev/null || true
( cd "$OUT/pkg" && rm -f "$D/TestKeys.jar" && zip -q -r "$D/TestKeys.jar" . )
echo "built: $D/TestKeys.jar"
