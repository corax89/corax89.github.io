#!/bin/bash
# v36.00 scripts/testkeys — GameCanvas.getKeyStates() hold-semantics selftest
# through the REAL headless frontend.
#
# Scenario: TestKeys MIDlet polls getKeyStates() every 10 ms on its own
# thread; the harness presses FIRE (-5) at frame 100 and holds it for
# NOJME_HEADLESS_KEYHOLD frames, then releases.
#
# PASS = "[TESTKEYS] PASS" in the output: FIRE visible in >= 300 consecutive
# polls (event-driven HELD bits; the old SDL_GetKeyboardState implementation
# yielded exactly 1 poll via the tap latch), no FIRE after release.
set -u
T=${T:-$(cd "$(dirname "$0")/../.." && pwd)}
cd "$T"

[ -f scripts/testkeys/TestKeys.jar ] || bash scripts/testkeys/build.sh
[ -f bin/j2me-headless ] || { echo "bin/j2me-headless missing — run 'make headless' first"; exit 2; }

export NOJME_LOG=1
export NOJME_HEADLESS_MAX_MS=120000
export NOJME_HEADLESS_KEYSCRIPT="100:-5"
export NOJME_HEADLESS_KEYHOLD=1500
export NOJME_HEADLESS_NOKEYS=1
export NOJME_HEADLESS_IDLE=2500

OUT=$(mktemp -d)
timeout 150 ./bin/j2me-headless scripts/testkeys/TestKeys.jar > "$OUT/out.log" 2> "$OUT/err.log"
rc=$?

ok=1
grep -q "\[TESTKEYS\] PASS" "$OUT/err.log" "$OUT/out.log" || { echo "FAIL: no PASS marker"; ok=0; }
grep -q "\[TESTKEYS\] hold_polls=" "$OUT/err.log" "$OUT/out.log" || { echo "FAIL: no stats line"; ok=0; }
if [ $ok -eq 1 ]; then
    echo "TESTKEYS: ALL CHECKS PASSED"
    grep -h "\[TESTKEYS\]" "$OUT/err.log" "$OUT/out.log" | head -3
else
    echo "TESTKEYS: FAILED — tail of output:"
    tail -25 "$OUT/err.log" "$OUT/out.log" 2>/dev/null
fi
rm -rf "$OUT"
exit $((1 - ok))
