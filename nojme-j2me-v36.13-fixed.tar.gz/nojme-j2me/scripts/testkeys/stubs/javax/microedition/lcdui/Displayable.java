package javax.microedition.lcdui;
public abstract class Displayable {
    protected Displayable() {}
    public boolean isShown() { return true; }
    public void setTitle(String s) { }
}
