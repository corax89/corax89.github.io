package javax.microedition.lcdui;
public class Display {
    private static Display singleton = new Display();
    public static Display getDisplay(javax.microedition.midlet.MIDlet m) { return singleton; }
    public void setCurrent(Displayable d) { }
    public Displayable getCurrent() { return null; }
}
