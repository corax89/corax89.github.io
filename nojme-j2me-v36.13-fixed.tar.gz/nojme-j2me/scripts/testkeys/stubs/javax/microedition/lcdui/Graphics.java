package javax.microedition.lcdui;
public class Graphics {
    /* test-only stub: the core implements all drawing natively */
}
