package javax.microedition.lcdui.game;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public abstract class GameCanvas extends Canvas {
    public static final int UP_PRESSED    = 1 << 1;  /* 0x0002 */
    public static final int LEFT_PRESSED  = 1 << 2;  /* 0x0004 */
    public static final int RIGHT_PRESSED = 1 << 5;  /* 0x0020 */
    public static final int DOWN_PRESSED  = 1 << 6;  /* 0x0040 */
    public static final int FIRE_PRESSED  = 1 << 8;  /* 0x0100 */
    public static final int GAME_A_PRESSED = 1 << 9; /* 0x0200 */
    public static final int GAME_B_PRESSED = 1 << 10;/* 0x0400 */
    public static final int GAME_C_PRESSED = 1 << 11;/* 0x0800 */
    public static final int GAME_D_PRESSED = 1 << 12;/* 0x1000 */

    protected GameCanvas(boolean suppressKeyEvents) { }
    public Graphics getGraphics() { return null; }
    public int getKeyStates() { return 0; }
    public void flushGraphics() { }
    public void flushGraphics(int x, int y, int w, int h) { }
}
