package javax.microedition.lcdui;
public abstract class Canvas extends Displayable {
    public static final int UP = 1;
    public static final int DOWN = 6;
    public static final int LEFT = 2;
    public static final int RIGHT = 5;
    public static final int FIRE = 8;
    public static final int GAME_A = 9;
    public static final int GAME_B = 10;
    public static final int GAME_C = 11;
    public static final int GAME_D = 12;
    public static final int KEY_NUM0 = 48;
    public static final int KEY_NUM1 = 49;
    public static final int KEY_NUM2 = 50;
    public static final int KEY_NUM3 = 51;
    public static final int KEY_NUM4 = 52;
    public static final int KEY_NUM5 = 53;
    public static final int KEY_NUM6 = 54;
    public static final int KEY_NUM7 = 55;
    public static final int KEY_NUM8 = 56;
    public static final int KEY_NUM9 = 57;
    protected Canvas() {}
    protected abstract void paint(Graphics g);
    public void keyPressed(int keyCode) { }
    public void keyReleased(int keyCode) { }
    public void keyRepeated(int keyCode) { }
    public void pointerPressed(int x, int y) { }
    public void pointerReleased(int x, int y) { }
    public void pointerDragged(int x, int y) { }
    public void repaint() { }
    public void repaint(int x, int y, int w, int h) { }
    public void serviceRepaints() { }
    public int getGameAction(int keyCode) { return 0; }
    public int getKeyCode(int gameAction) { return 0; }
    public String getKeyName(int keyCode) { return "?"; }
    protected void hideNotify() { }
    protected void showNotify() { }
}
