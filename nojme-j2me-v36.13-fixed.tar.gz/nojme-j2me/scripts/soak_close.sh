#!/bin/bash
# v36.12 SOAK: N open/close cycles of a REAL game in ONE process, through
# the exact user flow: menu A,A -> game runs -> MINUS (pause) -> B (exit to
# menu) -> menu A,A -> ... Repeated opening/closing is the field scenario
# ("при повторном открытии многих игр происходят зависания").
#
# PASS criteria (per session, parsed from the trace log):
#   - session i started (midlet: start) AND ended (mem: sess=i)
#   - leakv stays 0 (no stranded VM arenas)
#   - os_threads returns to the session-1 value (no runner leaks)
#   - rss/uord do not grow monotonically (allow ±few MB drift; a step of
#     ~64 MB per session = a leaked VM arena; slow creep = a resource leak)
#   - no FATAL / init: FAILED
#
# usage: soak_close.sh <jar> [sessions=5] [ms-per-session=16000] [budget]
cd "$(dirname "$0")/.." || exit 1
JAR="$1"; N="${2:-5}"; SESS_MS="${3:-16000}"
[ -f "$JAR" ] || { echo "usage: $0 <jar> [sessions] [ms-per-session]"; exit 2; }
BUDGET="${4:-$(((N * SESS_MS / 1000) + 120))}"
D=/tmp/soak_close
rm -rf "$D"; mkdir -p "$D/roms"
cp "$JAR" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# frontend script restarts at every menu session; N sessions relaunch the jar
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_SESSIONS="$N"
# v36.12: clean process exit N+1 menu idles 4 s (valgrind needs a normal exit;
# timeout below stays only as the hang safety net)
export NOJME_SWITCH_AUTOTEST_EXIT_MS=4000

# FRONT_KEYS is a ONE-SHOT wall-clock schedule from process start: session i
# pauses at SESS_MS*i, B 800 ms later exits to the menu. With SESS_MS=0 the
# jar is expected to SELF-END each session (test jars) — no close schedule.
if [ "${SESS_MS:-0}" -gt 0 ]; then
SCHED=""
for i in $(seq 1 "$N"); do
    SCHED+="MINUS:$((SESS_MS)),B:800,"
done
SCHED="${SCHED%,}"
export NOJME_FRONT_KEYS="$SCHED"
fi

echo "soak: $N sessions x ${SESS_MS} ms of $(basename "$JAR") (budget ${BUDGET}s)"
timeout -k 5 "$BUDGET" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?

LOG="$D/log.txt"
echo "rc=$rc (124=timeout OK for a live app)"
echo "--- per-session lifecycle:"
grep -acE "midlet: start" "$LOG" | xargs echo "  midlet: start  ="
grep -acE "mem: sess=" "$LOG" | xargs echo "  mem lines      ="
echo "--- [MEM] curve (sess / arena / uord / ford / leakv / rss / os_threads):"
grep -aoE "mem: sess=[0-9]+ arena=[0-9]+K uord=[0-9]+K ford=[0-9]+K leakv=[0-9]+ rss=[0-9-]+K os_threads=[0-9-]+" "$LOG"
echo "--- strands / failures:"
grep -aE "JVM-DESTROY|init: FAILED|FATAL|still busy" "$LOG" | head -10

# verdict
ok=1
starts=$(grep -ac "midlet: start" "$LOG")
mems=$(grep -ac "mem: sess=" "$LOG")
[ "$starts" -ge "$N" ] || { echo "FAIL: starts=$starts < $N"; ok=0; }
[ "$mems" -ge "$N" ] || { echo "FAIL: session-end mem lines=$mems < $N"; ok=0; }
grep -aq "leakv=0" "$LOG" || { echo "FAIL: stranded VM arena(s)"; ok=0; }
if grep -aqE "leakv=[1-9]" "$LOG"; then echo "FAIL: leakv>0"; ok=0; fi
grep -aq "init: FAILED" "$LOG" && { echo "FAIL: init FAILED in a session"; ok=0; }

# thread-leak check: last os_threads vs first
T_FIRST=$(grep -aoE "os_threads=[0-9]+" "$LOG" | head -1 | cut -d= -f2)
T_LAST=$(grep -aoE "os_threads=[0-9]+" "$LOG" | tail -1 | cut -d= -f2)
if [ -n "$T_FIRST" ] && [ -n "$T_LAST" ]; then
    echo "os_threads: first=$T_FIRST last=$T_LAST"
    [ "$T_LAST" -le "$T_FIRST" ] || { echo "FAIL: OS thread leak ($T_FIRST -> $T_LAST)"; ok=0; }
fi

# memory-leak heuristic: uord session-N vs session-1 (>24 MB growth = leak)
U_FIRST=$(grep -aoE "^\[TRACE\] mem: sess=[0-9]+ arena=[0-9]+K uord=[0-9]+" "$LOG" | head -1 | grep -aoE "uord=[0-9]+" | cut -d= -f2)
U_LAST=$(grep -aoE "^\[TRACE\] mem: sess=[0-9]+ arena=[0-9]+K uord=[0-9]+" "$LOG" | tail -1 | grep -aoE "uord=[0-9]+" | cut -d= -f2)
if [ -n "$U_FIRST" ] && [ -n "$U_LAST" ]; then
    GROW=$(( U_LAST - U_FIRST ))
    echo "uord: first=${U_FIRST}K last=${U_LAST}K growth=${GROW}K"
    [ "$GROW" -le 24576 ] || { echo "FAIL: uord grew >24 MB over the soak"; ok=0; }
fi

if [ $ok -eq 1 ]; then
    echo "SOAK CLOSE: ALL CHECKS PASSED"
else
    echo "SOAK CLOSE: FAILED"
    tail -30 "$D/err.log" 2>/dev/null
fi
exit $((1 - ok))
