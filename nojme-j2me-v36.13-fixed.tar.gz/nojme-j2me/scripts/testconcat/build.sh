#!/bin/bash
# Build TestConcat*.jar — v36.04 selftests (String-concat char-loss /
# interpreter frame-stack family, deferred (a)/(b) from session 48).
# Usage: build.sh [MainClassName]   (default: TestConcat)
set -e
NAME="${1:-TestConcat}"
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out-$NAME"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/$NAME.java" \
    "$D/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , %s\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    "$NAME" > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/$NAME.jar" META-INF && zip -q "$D/$NAME.jar" *.class )
echo "built: $D/$NAME.jar"
