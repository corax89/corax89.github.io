import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import java.util.Vector;

/* TestConcat — v36.04 selftest for the deferred (b) bug from session 48:
 * "interpreter frame-stack leak — a String-concatenation loop in a CALLED
 * method trips ASAN (write past frame stack, execute.c ILOAD_n)".
 *
 * The field shape (DoomRPG second launch): a loader thread parses records
 * into Strings through long concat loops. Suspect opcode in the concat
 * sequence leaks operand-stack/frame state; the next ILOAD_n writes past
 * the frame. This midlet runs several concat shapes on the main thread:
 *
 *   T1  plain loop concat (s = s + i) in a CALLED static method
 *   T2  concat loop with try/catch INSIDE the loop (unwind paths)
 *   T3  concat loop calling an instance method that throws+catches
 *   T4  concat loop over a temp object field (getfield-heavy shape)
 *   T5  deep call chain (a->b->c->d) each with its own concat loop
 *
 * PASS = CONCAT:DONE 6/0 (exact expected strings; a wrong/short string means
 * frame state leaked). Under ASAN a frame/stack write bug aborts loudly.
 */
public class TestConcat extends MIDlet {
    static int pass = 0, fail = 0;

    static void chk(String id, boolean cond, String detail) {
        if (cond) { pass++; System.out.println("C:" + id + " PASS " + detail); }
    else      { fail++; System.out.println("C:" + id + " FAIL " + detail); }
    }

    static String T1_concat(int n) {
        String s = "";
        for (int i = 0; i < n; i++) s = s + i;
        return s;
    }

    static String T2_concatCatch(int n) {
        String s = "";
        for (int i = 0; i < n; i++) {
            try {
                if (i == 3) throw new RuntimeException("x" + i);
                s = s + i;
            } catch (RuntimeException e) {
                s = s + "E";
            }
        }
        return s;
    }

    static String T3_helper(int i) throws Exception {
        if (i == 2) throw new Exception("h" + i);
        return "v" + i;
    }

    static String probeMessage() {
        try {
            throw new Exception("h" + 2);
        } catch (Exception e) {
            return "[" + e.getMessage() + "]";
        }
    }

    /* Element whose toString() (BYTECODE, invoked from native Vector.toString)
     * runs the suspect concat loop. */
    static class ConcatBomb {
        int n;
        ConcatBomb(int n) { this.n = n; }
        public String toString() {
            String s = "";
            for (int i = 0; i < 400; i++) s = s + i;
            return "Bomb#" + n + "-loop" + 399 + "len" + s.length();
        }
    }

    static Vector makeBombVector(Vector v) { return v; }

    static String T3_concatThrows(int n) {
        String s = "";
        for (int i = 0; i < n; i++) {
            try {
                s = s + T3_helper(i);
            } catch (Exception e) {
                s = s + "[" + e.getMessage() + "]";
            }
        }
        return s;
    }

    String prefixField = "f";

    String T4_concatField(int n) {
        String s = "";
        for (int i = 0; i < n; i++) s = s + prefixField + i + ";";
        return s;
    }

    static String T5_d(int k) { return "d" + k; }
    static String T5_c(int k) { String s = ""; for (int i = 0; i < 3; i++) s += T5_d(k + i); return s; }
    static String T5_b(int k) { String s = ""; for (int i = 0; i < 3; i++) s += T5_c(k + i); return s; }
    static String T5_a(int k) { String s = ""; for (int i = 0; i < 3; i++) s += T5_b(k + i); return s; }

    public void startApp() throws MIDletStateChangeException {
        System.out.println("CONCAT-TEST-START");

        String r1 = T1_concat(400);
        chk("T1.plain", r1.startsWith("0123") && r1.endsWith("399") && r1.length() == 1090,
            "len=" + r1.length());

        String r2 = T2_concatCatch(60);
        chk("T2.catch", r2.startsWith("012E456") && r2.indexOf("E") == 3
            && r2.endsWith("59") && r2.length() == 110, "len=" + r2.length());

        String r3 = T3_concatThrows(40);
        chk("T3.throws", r3.startsWith("v0v1[h2]v3") && r3.indexOf("[h2]") == 4
            && r3.endsWith("v39"), r3);

        String r4 = new TestConcat().T4_concatField(50);
        chk("T4.field", r4.startsWith("f0;f1;f2;") && r4.endsWith("f49;") && r4.length() == 190,
            "len=" + r4.length());

        String r5 = T5_a(0);
        chk("T5.deep", r5.startsWith("d0d1d2d1d2d3") && r5.endsWith("d4d5d6") && r5.length() == 54,
            "len=" + r5.length());

        /* Repeat T1 twice: a leak shows up on the SECOND pass (frame state
         * already walked off the end after the first). */
        String r1b = T1_concat(400);
        chk("T1.repeat", r1b.equals(r1), "second pass identical");

        /* T6: NESTED execution — the session-48 (a)/(b) family. Vector.toString
         * (native util_to_string_of) invokes element toString() BYTECODE from C;
         * that toString runs a String-concat loop (the suspected stack-effect
         * shape). With the 48 (a) bug this died in class_hash_lookup; with (b)
         * ASAN caught a frame-stack write in ILOAD_n. */
        Vector v6 = new Vector();
        for (int i = 0; i < 12; i++) v6.addElement(new ConcatBomb(i));
        String r6 = makeBombVector(v6).toString();
        chk("T6.nested", r6.indexOf("Bomb#0-loop399") >= 0 && r6.indexOf("Bomb#11-loop399") >= 0
            && r6.indexOf(", ") > 0, "nested toString concat ok");

        /* T7: exact exception-message roundtrip (the T3 char-loss probe). */
        String msg = probeMessage();
        chk("T7.msg", "[h2]".equals(msg), "msg=\"" + msg + "\"");

        System.out.println("CONCAT:DONE " + pass + "/" + fail);
        notifyDestroyed();
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) { }
}
