import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/* TestConcat2 — isolates WHERE "[h" is lost: in-VM concat (chk says the
 * string is correct) vs the println path (print shows "2]"). */
public class TestConcat2 extends MIDlet {
    static void p(String id, String v) {
        System.out.println("M:" + id + " =<" + v + "> len=" + v.length());
    }

    public void startApp() throws MIDletStateChangeException {
        System.out.println("M2-START");

        /* E-group: literal vs concat-built identical content */
        System.out.println("E1lit:<v0v1[h2]v3v4>");                    // pure literal
        String built = "v0v1" + "[h2]" + "v3v4";
        System.out.println("E2cat:<" + built + ">");
        System.out.print("E3print:"); System.out.println(built);
        String lit = "v0v1[h2]v3v4";
        System.out.println("E4litvar:<" + lit + ">");
        char[] cc = new char[lit.length()];
        lit.getChars(0, lit.length(), cc, 0);
        System.out.println("E5chars:<" + new String(cc) + ">");
        System.out.println("E6idx: i4=" + built.indexOf("[h2]") + " c4=" + (int)built.charAt(4)
            + " c5=" + (int)built.charAt(5) + " c6=" + (int)built.charAt(6));
        System.out.println("E7eq:" + built.equals(lit));

        /* A-group: minimal shapes */
        p("A3", "[" + "h2" + "]");
        String m = "h" + 2;
        p("A3b", "[" + m + "]");
        p("A6", "[" + 2 + "]");
        p("A8", "[" + "x" + "]");
        p("A9", "[" + "xy" + "]");
        p("A10", "[" + "xyz" + "]");
        p("A11", "<" + "h2" + ">");
        p("A12", "(" + "h2" + ")");

        /* B-group: exception message */
        Exception e = new Exception("h2");
        p("B1", e.getMessage());
        p("B2", "[" + e.getMessage() + "]");
        String gm = e.getMessage();
        p("B3", "[" + gm + "]");

        System.out.println("M2:DONE");
        notifyDestroyed();
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) { }
}
