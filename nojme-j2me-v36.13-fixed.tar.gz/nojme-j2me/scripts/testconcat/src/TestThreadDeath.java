import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class TestThreadDeath extends MIDlet {
    public void startApp() throws MIDletStateChangeException {
        Thread t = new Thread() {
            public void run() {
                try { Thread.sleep(100); } catch (InterruptedException e) { }
                throw new RuntimeException("boom-from-loader");
            }
        };
        t.start();
        try { Thread.sleep(600); } catch (InterruptedException e) { }
        System.out.println("TTD:DONE");
        notifyDestroyed();
    }
    public void pauseApp() { }
    public void destroyApp(boolean unconditional) { }
}
