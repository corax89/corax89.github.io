/* fat32.h — чтение FAT32-раздела */
#ifndef FAT32_H
#define FAT32_H

#include "types.h"

#define FAT32_NAME_MAX 255

typedef struct {
    char name[FAT32_NAME_MAX + 1];  /* UTF-8, длинное имя если есть */
    u8   attr;                       /* 0x10 — каталог */
    u32  size;
    u32  first_cluster;
} fat32_dirent_t;

int  fat32_init(void);
int  fat32_init_usb(void);          /* Инициализация с USB-флешкой как backend */
int  fat32_init_part(int part_index); /* сессия 25: конкретный раздел disk_part() */
int  fat32_is_usb(void);            /* 1 = USB backend активен, 0 = ATA */
int  fat32_ready(void);
void fat32_deinit(void);   /* сессия 12: снять монтирование (формат) */
u32  fat32_root_cluster(void);

/* Перечислить содержимое каталога (без "." и ".."), до max записей. */
int  fat32_list(u32 dir_cluster, fat32_dirent_t *out, int max);

/* Прочитать файл (не более max байт). Возвращает число прочитанных байт. */
u32  fat32_read_file(u32 first_cluster, u32 size, void *buf, u32 max);

const char *fat32_label(void);
const char *fat32_fsname(void);   /* «FAT32» или «exFAT» (сессия 75) */

/* ===================== СЕССИЯ 14: ЗАПИСЬ В FAT32 =====================
 * Полный набор операций записи с поддержкой ПОДКАТАЛОГОВ (LFN + 8.3,
 * кириллица, пробелы), рост каталогов, цепочки кластеров, обе копии FAT.
 * Работает на обоих backend'ах: ATA (disk_hdd_write) и USB
 * (usb_ehci_write_sector). Все операции атомарны относительно fat32_io_lock.
 *
 * Запрос пользователя: «файлы создаются только в корне, но не в папках» —
 * все функции принимают кластер ТЕКУЩЕГО каталога (m->stk[depth].cluster),
 * поэтому создание происходит там, где находится пользователь. */
int  fat32_writable(void);

/* Создать каталог name внутри dir_cluster. 1 = ок. */
int  fat32_mkdir(u32 dir_cluster, const char *name);

/* Создать пустой файл name внутри dir_cluster. 1 = ок. */
int  fat32_create_file(u32 dir_cluster, const char *name);

/* Найти запись по имени (без учёта регистра, LFN и 8.3). 1 = найдено. */
int  fat32_find_entry(u32 dir_cluster, const char *name, fat32_dirent_t *out);

/* Прочитать файл по имени из каталога. Возвращает число прочитанных байт. */
u32  fat32_read_file_by_name(u32 dir_cluster, const char *name,
                             void *buf, u32 max);

/* Записать файл целиком (создать или ПЕРЕЗАПИСАТЬ) в каталог.
 * Возвращает len при успехе, 0 при ошибке. */
u32  fat32_write_file(u32 dir_cluster, const char *name,
                      const void *buf, u32 len);

/* Удалить файл или ПУСТОЙ каталог name из dir_cluster. 1 = ок. */
int  fat32_delete(u32 dir_cluster, const char *name);

#endif