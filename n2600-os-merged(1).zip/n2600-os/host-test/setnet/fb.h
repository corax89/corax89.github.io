/* fb.h — фреймбуфер VESA LFB (из Multiboot), двойная буферизация, примитивы */
#ifndef FB_H
#define FB_H

#include "types.h"
#include "boot.h"

int   fb_init(const mb_info_t *mb);
int   fb_ready(void);
u32   fb_rgb(u8 r, u8 g, u8 b);
u32   fb_width(void);
u32   fb_height(void);
u32   fb_bpp(void);
u32   fb_pitch(void);

void  fb_make_bg(void);                     /* построить фон рабочего стола */
void  fb_scroll_up(int px);                 /* прокрутка экрана вверх (консоль загрузки) */

void  fb_mark_enable(void);                 /* вкл/выкл накопление dirty-области */
void  fb_mark_disable(void);
void  fb_touch(int x, int y, int w, int h); /* пометить область на вывод */
void  fb_touch_all(void);

/* ---- dirty-область: СПИСОК прямоугольников (для скорости на слабых CPU) ---- */
#define FB_DIRTY_MAX 12
typedef struct { int x0, y0, x1, y1; } fb_drect_t;

void  fb_flush(void);                       /* back → LFB (boot-консоль, паники) */
int   fb_dirty(int *x0, int *y0, int *x1, int *y1);   /* bbox всех областей */
int   fb_dirty_count(void);                 /* число dirty-прямоугольников */
void  fb_dirty_rect(int i, int *x0, int *y0, int *x1, int *y1);
int   fb_dirty_take(fb_drect_t *out, int max); /* атомарно забрать список */
void  fb_flush_rects(const u32 *src, const fb_drect_t *rects, int n); /* src=NULL: back */

/* compose-цель композитора (двойная буферизация кадра): между begin и
 * end ВСЕ примитивы fb_* пишут в compose-буфер; в конце wm_frame
 * fb_flush_rects(compose, ...) одним проходом выносит области в LFB.
 * Если compose не выделился — цель не меняется (fallback: back). */
void  fb_compose_begin(int x0, int y0, int x1, int y1);
void  fb_compose_end(void);
u32  *fb_compose_buf(void);
void  fb_sync_back(const fb_drect_t *rects, int n); /* compose → back (dirty) */

void  fb_set_clip(int x0, int y0, int x1, int y1);
void  fb_set_origin(int ox, int oy);  /* приложения рисуют от левого-верхнего угла содержимого */
void  fb_get_clip(int *x0, int *y0, int *x1, int *y1); /* текущий клип цели (для skip'ов отрисовки) */

void  fb_fill_screen(u32 c);
void  fb_fill_rect(int x, int y, int w, int h, u32 c);
void  fb_rect(int x, int y, int w, int h, u32 c);
void  fb_hline(int x0, int x1, int y, u32 c);
void  fb_vline(int x, int y0, int y1, u32 c);

void  fb_char(int x, int y, unsigned cp, u32 fg, int bg); /* bg=-1: прозрачный фон */
void  fb_char2x(int x, int y, unsigned cp, u32 fg);
void  fb_text(int x, int y, const char *s, u32 fg, int bg);
void  fb_text_screen_centered(int clip_y0, int y, const char *s, u32 fg);
u32   fb_text_w(const char *s);
void  fb_blit_bg(int x0, int y0, int x1, int y1);

/* Копировать прямоугольник w x h из src (строка src_w пикселей) в
 * ТЕКУЩУЮ цель рендера композитора (compose или back) в позицию (dx,dy),
 * honouring текущий клип. Выходы за границы src и цели обрезаются.
 * Для композитинга canvas'ов окон (wm.c). */
void  fb_blit_to_screen(const u32 *src, int src_w, int src_h,
                         int dx, int dy, int w, int h);

/* Blit RGBA8-картинки (imgsvc/stb_image) в текущую цель рендера с
 * origin/клипом; прозрачные пиксели (a<128) пропускаются. Целочисленный
 * (без float — безопасно в любом потоке). dw/dh == sw/sh — копия 1:1,
 * иначе nearest-neighbor; сглаживание заранее — img_scale(). */
void  fb_blit_rgba(const u8 *rgba, int sw, int sh,
                    int dx, int dy, int dw, int dh);

/* ---------------- по-задачные цели рендера (многопоточный WM) ----------------
 *
 * Каждое окно WM рисует в СОБСТВЕННЫЙ canvas (пиксельный буфер размера
 * содержимого окна) из СВОЕГО потока. fb.c подкачивает активный контекст
 * (base/ширина/клип/origin/marking) при переключении задач:
 * task_schedule() вызывает fb_task_switch(из, в).
 *
 * fb_width()/fb_height() — всегда РАЗМЕР ЭКРАНА (для раскладки окон);
 * размеры цели рендера видны только внутри примитивов fb_*.
 *
 * fb_task_canvas_attach() вызывается wm.c при создании окна;
 * поток окна сам вызывает fb_task_canvas_detach() перед завершением. */
int   fb_task_canvas_attach(int task, u32 *mem, int w, int h); /* 1=ок */
void  fb_task_canvas_detach(int task);
int   fb_task_has_canvas(int task);   /* 1 = canvas подключён (сессия 12) */
void  fb_task_switch(int from_task, int to_task);  /* из task_schedule (BSP) */
/* СЕССИЯ 75: переключение контекста на AP-ядре (из task_ap_schedule):
 * per-core набор «активных» fb-контекстов — ядра не топчут друг друга.
 * from_task = -1 — вход из idle (сохранять некуда); to_task = -1 — выход
 * в idle (загрузить экранную запись). Оба вызова — из контекста IRQ
 * соответствующего ядра. */
void  fb_task_switch_ap(int from_task, int to_task, int core);

#endif /* FB_H */
