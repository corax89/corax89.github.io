/* smp.h — хост-стаб для сборки tmfmt_test (хост-тесты диспетчера задач).
 * Ядро тянет полную версию (src/smp.h); на хосте достаточно счётчиков.
 * Самодостаточен: types.h локально отсутствует, u32 объявлен в tm_stubs.h. */
#ifndef SMP_H_STUB
#define SMP_H_STUB
#define SMP_MAX_CPUS 8
#define SMP_FAIR_TICKS 2
static int smp_cpu_count(void)    { return 1; }
static int smp_online_count(void) { return 1; }
static int smp_topo_cores(void)   { return 1; }
static int smp_topo_threads(void) { return 1; }
static int smp_cpu_load(int idx)  { (void)idx; return 0; }
static unsigned int smp_cpu_apic_id(int i) { (void)i; return 0; }
static int smp_ready(void)        { return 1; }
#endif
