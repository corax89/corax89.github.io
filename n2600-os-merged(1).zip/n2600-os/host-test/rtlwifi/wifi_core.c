/* wifi_core.c — чипо-НЕЗАВИСИМЫЙ WiFi-стек N2600-OS (сессия 28).
 *
 * Переехал из ath9k_wifi.c без изменения логики: журнал, профиль
 * WIFI.CFG, сканирование (пошагово, каналы 1-14), парсинг beacon
 * (RSN/WPA IE), машина подключения (SCAN→AUTH→ASSOC→4WAY→CONNECTED),
 * WPA2-PSK (PBKDF2/PTK/EAPOL M1-M4 + group rekey), мост
 * 802.11<->Ethernet для net.c.
 *
 * Драйверы (ath9k_wifi.c, rtl8192eu.c) регистрируют wifi_hw_ops_t и
 * доставляют принятые кадры через wc_rx_frame(). ИЗМЕНЕНИЕ ПОВЕДЕНИЯ:
 * wifi_scan_start() больше НЕ очищает список найденных точек — он
 * обновляется маяками. Раньше очистка при подключении выглядела как
 * «поиск начался заново» сразу после ввода пароля (жалоба сессии 28).
 */
#include "wifi_core.h"
#include "wpa2.h"
#include "string.h"
#include "mem.h"
#include "timer.h"
#include "sync.h"
#include "kernel.h"
#include "ramfs.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);
extern int  vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* ================= конфигурация (бывший ath9k_wifi.c) ================= */

/* СЕССИЯ 33: 1 тик = 1 мс (PIT 1000 Гц; было 10 мс при 100 Гц).
 * Все тайминги ниже — в тиках, численно равны миллисекундам. */
#define WIFI_SCAN_DWELL   110       /* мс на канал (было 220 — скан вдвое быстрее) */
#define WIFI_TXBUF_SZ     2360      /* 24 hdr + LLC/SNAP 8 + 1500 + запас */
#define WIFI_NET_RXQ      8         /* кадров Ethernet в кольце к net.c */
#define WIFI_NET_RXSZ     1600
/* тайминги ассоциации (тики = мс при 1000 Гц) */
#define CONN_4WAY_TO     5000  /* 5 с на шаг рукопожатия */
#define CONN_MAX_4WAY    3     /* попыток рукопожатия */
#define CONN_AUTH_TO       600         /* 600 мс на попытку AUTH/ASSOC */
#define CONN_MAX_ATTEMPTS  3
#define CONN_SCAN_TRIES    3          /* проходов скана при поиске сети */
#define CONN_BEACON_LOST   6000       /* 6 с без маяков = связь потеряна */
/* СЕССИЯ 32 (анти-шторм): точка, которая стабильно отшивает DEAUTH'ом,
 * раньше ЗАЦИКЛИВАЛА машину подключения: полный скан (3 с) → AUTH →
 * DEAUTH → снова полный скан… до бесконечности, с сожжённым CPU.
 * Теперь: сначала 2 быстрых переподключения к ТОЙ ЖЕ точке без скана,
 * после 4 DEAUTH — FAILED (переподключение — по клику пользователя). */
#define CONN_MAX_DEAUTH    4          /* DEAUTH за сессию подключения */
#define CONN_FAST_RETRIES  2          /* из них — без пересканирования */

#define WIFI_LOG_LINES    28
/* СЕССИЯ 73 [CONSOLE]: 96 -> 160 — строки со счётчиками (скан PCI с
 * «пробую RTL8192EU (USB attach=N)») упирались в 96 байт и обрезались
 * без перевода строки — «исчезает часть текста» в логе */
#define WIFI_LOG_LINE     160

const u16 wc_channel_freq[14] = {
    2412, 2417, 2422, 2427, 2432, 2437, 2442,
    2447, 2452, 2457, 2462, 2467, 2472, 2484
};

typedef struct {
    int present, ready;
    char chip_name[40];

    /* сканирование */
    int      scanning;
    int      scan_channel;   /* индекс 0..13 */
    u32      dwell_start;
    int      pass;           /* 1 = основной, 2 = повтор драйвера */
    wifi_ap_t aps[WIFI_MAX_APS];
    int      ap_count;
    wifi_stats_t stats;

    /* ---- подключение ---- */
    wifi_conn_state_t conn;
    char     conn_ssid[33];
    u8       conn_bssid[6];
    int      conn_channel;   /* индекс 0..13 */
    u16      conn_aid;
    int      conn_attempts;
    int      conn_scans;
    u32      conn_timer;
    u32      beacon_last;
    int      conn_rssi;
    char     conn_fail_reason[48];
    /* СЕССИЯ 32: параметры выбранной точки для ASSOC REQ (рейты —
     * ровно как в маяке; capability — для короткой преамбулы) */
    u16      conn_capab;
    u8       conn_rates[12];
    u8       conn_rates_len;
    u8       assoc_rate_alt; /* 1 = после отказа status=18 слать полный набор b/g */
    /* Сессия 43: профиль точки — HT/WPA IE/PMF (в ASSOC REQ как у
     * настоящего клиента) */
    u8       conn_ht;
    u8       conn_wpa;
    u8       conn_pmf;
    int      conn_retries;   /* DEAUTH-переподключения за сессию */
    u32      last_scan_end;  /* тик завершения последнего полного скана */
    /* ротация BSSID: одноимённые SSID бывают на нескольких точках;
 * если одна стабильно отказывает — следующая попытка берёт другую */
    u8       tried_bssid[4][6];
    int      tried_n;
    char     tried_ssid[33];

    /* ---- WPA2-PSK ---- */
    u8       sec;            /* WIFI_SEC_* целевой сети */
    char     psk[65];        /* "" = открытая сеть */
    int      fw_phase;       /* 0 = ждём M1, 1 = ждём M3,
                              * 2 = ждём групповой ключ (WPA, после M4) */
    u8       fw_desc;        /* СЕССИЯ 45: дескриптор рукопожатия (2 RSN / 254 WPA) */
    u8       fw_ver;         /* версия дескриптора M1 (1 = MD5/TKIP, 2 = AES) */
    u32      fw_timer;
    int      fw_attempts;
    u32      fourway_data;   /* СЕССИЯ 44: data-кадров от точки за окно 4WAY
                              * (0 = эфир глухой — искать проблему в RX) */
    u8       anonce[32];
    u8       snonce[32];
    u8       replay[8];
    u8       replay_m1[8];   /* replay M1 — для повторного M2 после M3 */
    u8       ap_wpa_ie[40];  /* WPA IE точки (из key data M3) для эха в M2 */
    u8       ap_wpa_ie_len;
    u8       ap_rsn_ie[40];  /* СЕССИЯ 51: RSN IE точки (из assoc-resp) —
                              * Ralink сверяет IE в M2 с СОБСТВЕННЫМ IE
                              * побайтно; наш (1 пара) != её (2 пары) */
    u8       ap_rsn_ie_len;
    int      m2_rsn_tries;   /* сколько M2 уже ушло в этом рукопожатии:
                              * 0 = первый (свой IE), 1+ = эхо IE точки */
    u8       m2_apie_sent;   /* повторный M2 с IE точки уже отправлен */
    u8       pmk[32];
    char     pmk_ssid[33];
    char     pmk_psk[65];
    int      pmk_valid;
    u8       ptk[64];        /* KCK16+KEK16+TK16 (+MIC RX@48/TX@56 у
                              * TKIP-пары) после M1 */
    int      ptk_is_tkip;    /* пара TKIP (PTK-64) или CCMP (PTK-48) */
    int      pairwise_tkip;  /* СЕССИЯ 48: какой pairwise предлагаем в
                              * IE этой попытки (0=CCMP, 1=TKIP) */
    u8       assoc_variant;  /* СЕССИЯ 50: состав IE ассоциации по попыткам:
                              * 0-1 = ТОЛЬКО RSN IE (точка обязана взять
                              * RSN/WPA2-протокол; Ralink с двумя IE берёт
                              * свой сырой WPA-режим), 2-3 = оба IE;
                              * бит 0 = пара TKIP */
    int      assoc_rsn_only; /* СЕССИЯ 50: 1 = в assoc ТОЛЬКО RSN IE */
    int      assoc_fallback_tried; /* уже пробовали оба IE после отказа */
    u8       gtk[32];
    int      gtk_is_tkip;
    int      gtk_keyid;
    int      keys_installed;
    u8       ap_group_tkip;
    u32      rng_state;
    /* СЕССИЯ 51: TX-счётчик пакетных номеров (IV-заголовок строим САМИ:
     * железо 8192EU только шифрует, IV кладёт драйвер — как mac80211
     * с IEEE80211_KEY_FLAG_GENERATE_IV). Один 48-битный PN на ключ:
     * CCMP берёт его целиком, TKIP — iv16=pn&0xffff, iv32=pn>>16.
     * СЕССИЯ 52: TX только парным ключом (802.11i: станция шифрует
     * ВСЁ в сторону точки PTK, включая broadcast) — gtk_pn не нужен. */
    u64      ptk_pn;
    /* СЕССИЯ 51: диагностика data-пути (DHCP/ARP не отвечают — видно
     * уходят ли наши кадры и приходит ли хоть что-то).
     * СЕССИЯ 52: data_rx_uc — юникаст-кадры ОТ точки: бродкасты точка
     * шлёт и без нашего участия (соседи), а юникаст идёт только если
     * точка приняла наш M4/наши данные и порт открыт. */
    u32      data_tx, data_rx, data_rx_uc;
    /* Сессия 53: сколько из data_tx — ЮНИКАСТ (не бродкаст). Только
     * отправив юникаст (TCP SYN, ARP-ответ), мы вправе ждать юникаст
     * назад; во время DHCP весь наш трафик бродкастный — критерий
     * «RXuc==0 = проблема» там давал ложную тревогу. */
    u32      data_tx_uc;
    u32      data_stat_timer;

    u8       mac[6];
    u16      tx_seq;
    volatile int tx_lock;

    /* ---- мост 802.11 -> Ethernet (к net.c) ---- */
    u8           netrx[WIFI_NET_RXQ][WIFI_NET_RXSZ];
    u16          netrx_len[WIFI_NET_RXQ];
    int          netrx_head, netrx_tail;
    volatile int rx_lock;

    const wifi_hw_ops_t *ops;
} wifi_core_t;

static wifi_core_t wc;

/* СЕССИЯ 51: условная компиляция частых логов. По умолчанию молчат:
 * ретрансмиссии M1/M3, пофреймовые строки EAPOL — на фоне живой сети
 * их десятки, а milestone-логи (M1/M2/M3/ключи) остаются всегда. */
#ifndef WIFI_VERBOSE
#define WIFI_VERBOSE 0
#endif
#if WIFI_VERBOSE
#define WLOGV(...) wifi_log(__VA_ARGS__)
#else
#define WLOGV(...) do {} while (0)
#endif

/* ================= журнал (виден в приложении WiFi и dmesg) ================= */

static char    g_wlog[WIFI_LOG_LINES][WIFI_LOG_LINE];
static volatile int g_wlog_head = 0;
static volatile int g_wlog_count = 0;

void wifi_log(const char *fmt, ...) {
    char line[WIFI_LOG_LINE];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    __builtin_va_end(ap);

    int idx = g_wlog_head;
    u32 L = (u32)strlen(line);
    if (L >= WIFI_LOG_LINE) L = WIFI_LOG_LINE - 1;
    memcpy(g_wlog[idx], line, L);
    g_wlog[idx][L] = 0;
    g_wlog_head = (idx + 1) % WIFI_LOG_LINES;
    if (g_wlog_count < WIFI_LOG_LINES) g_wlog_count++;

    /* СЕССИЯ 73 [CONSOLE]: печать ОДНИМ serial_puts. serial_puts атомарен
     * на СТРОКУ (cli/sti), а три отдельных вызова («[wifi] » / текст /
 * «\n») вклинивались [boot]-логом фоновых задач между префиксом и
 * текстом — «…RTL8192EU USB)...[boot] » в журнале. */
    char sfull[WIFI_LOG_LINE + 8];
    snprintf(sfull, sizeof(sfull), "[wifi] %s\n",
             g_wlog[(g_wlog_head + WIFI_LOG_LINES - 1) % WIFI_LOG_LINES]);
    serial_puts(sfull);
    {   /* в klog — без хвостового '\n': klog_puts добавляет перевод сам,
         * иначе в dmesg после каждой wifi-строки появляется пустая */
        u32 fl = (u32)strlen(sfull);
        if (fl && sfull[fl - 1] == '\n') sfull[fl - 1] = 0;
        klog_puts(sfull);
    }
}

int wifi_log_tail(char *buf, int buf_sz, int n_lines) {
    if (!buf || buf_sz <= 0) return 0;
    int pos = 0;
    int total = g_wlog_count;
    if (n_lines <= 0 || n_lines > total) n_lines = total;
    for (int i = total - n_lines; i < total; i++) {
        int idx = (g_wlog_head + WIFI_LOG_LINES - total + i) % WIFI_LOG_LINES;
        const char *s = g_wlog[idx];
        while (*s && pos < buf_sz - 2) buf[pos++] = *s++;
        if (pos < buf_sz - 1) buf[pos++] = '\n';
    }
    if (pos < buf_sz) buf[pos] = 0; else buf[buf_sz - 1] = 0;
    return pos;
}

int wifi_log_count(void) { return g_wlog_count; }

/* ================= MAC (драйвер <- efuse/EEPROM) ================= */

void wc_set_mac(const u8 mac[6]) { memcpy(wc.mac, mac, 6); }
void wc_get_mac(u8 out[6])       { memcpy(out, wc.mac, 6); }

void wc_set_chip_name(const char *name) {
    strncpy(wc.chip_name, name ? name : "?", sizeof(wc.chip_name) - 1);
    wc.chip_name[sizeof(wc.chip_name) - 1] = 0;
}

void wc_set_state(int present, int ready) {
    wc.present = present;
    wc.ready = ready;
}

/* ================= профиль автоподключения (RAM disk WIFI.CFG) ================= */

#define WIFI_CFG_FILE "WIFI.CFG"

static int wifi_cfg_get(const char *buf, const char *key, char *out, int max)
{
    u32 klen = (u32)strlen(key);
    const char *p = buf;
    while (*p) {
        if (memcmp(p, key, klen) == 0) {
            p += klen;
            int L = 0;
            while (*p && *p != '\n' && *p != '\r' && L < max - 1)
                out[L++] = *p++;
            out[L] = 0;
            return L > 0;
        }
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    return 0;
}

int wifi_profile_load(char *out_ssid, int max) {
    out_ssid[0] = 0;
    if (!ramfs_ready()) return 0;
    char buf[192];
    u32 n = ramfs_read(WIFI_CFG_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    return wifi_cfg_get(buf, "ssid=", out_ssid, max > 33 ? 33 : max);
}

int wifi_profile_load_psk(char *out_psk, int max) {
    out_psk[0] = 0;
    if (!ramfs_ready()) return 0;
    char buf[192];
    u32 n = ramfs_read(WIFI_CFG_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return 0;
    buf[n] = 0;
    return wifi_cfg_get(buf, "psk=", out_psk, max > 65 ? 65 : max);
}

void wifi_profile_save(const char *ssid) {
    if (!ramfs_ready()) return;
    if (!ssid || !ssid[0]) {
        ramfs_delete(WIFI_CFG_FILE);
        return;
    }
    char buf[128];
    int L;
    if (wc.psk[0] && wc.sec == WIFI_SEC_WPA2_PSK)
        L = snprintf(buf, sizeof(buf), "ssid=%s\npsk=%s\n", ssid, wc.psk);
    else
        L = snprintf(buf, sizeof(buf), "ssid=%s\n", ssid);
    ramfs_delete(WIFI_CFG_FILE);
    if (ramfs_create(WIFI_CFG_FILE, (u32)L + 1))
        ramfs_write(WIFI_CFG_FILE, buf, (u32)L + 1);
}

/* ================= парсинг beacon ================= */

/* 802.11 beacon: FC(2) Dur(2) DA(6) SA(6) BSSID(6) Seq(2) |
 * TS(8) Interval(2) Cap(2) | tags. RSSI — от драйвера. */
static void parse_beacon(const u8 *data, int len, i8 rssi) {
    if (len < 38) return;                       /* заголовок + хоть один тег */
    if ((data[0] & 0xFC) != 0x80) return;       /* не beacon */
    const u8 *bssid = data + 16;

    u16 interval = (u16)(data[32] | (data[33] << 8));
    u16 capability = (u16)(data[34] | (data[35] << 8));

    char ssid[33];
    memset(ssid, 0, sizeof(ssid));
    u8 channel = 0;
    u8 sec = WIFI_SEC_OTHER;   /* tmp: не встретили RSN/WPA — по capability */
    u8 group_tkip = 0;         /* групповой шифр точки = TKIP */
    u8 rates[12];              /* Supported + Ext Supported из маяка */
    u8 rates_len = 0;
    /* Сессия 43: HT/смешанный WPA/PMF — из маяка */
    u8 ap_ht = 0, ap_wpa = 0, ap_pmf = 0;
    const char *rsn_reject = NULL;
    int pos = 36;
    int guard = 0;
    while (pos + 2 <= len && guard++ < 64) {
        u8 tag = data[pos], tlen = data[pos + 1];
        pos += 2;
        if (pos + tlen > len) break;
        if (tag == 0) {
            int sl = tlen;
            if (sl > 32) sl = 32;
            memcpy(ssid, data + pos, sl);
            ssid[sl] = 0;
        } else if (tag == 1 && tlen >= 1) {
            /* СЕССИЯ 32: IE Supported Rates — запоминаем РОВНО как
             * рекламирует точка (старший бит = её basic-рейт).
             * СЕССИЯ 43: 0x7E/0x7F — BSS Membership Selectors (VHT/HT),
             * это НЕ рейты — в список не кладём, но помечаем точку HT */
            for (u8 k = 0; k < tlen && rates_len < 12; k++) {
                u8 r = data[pos + k];
                if (r == 0x7E || r == 0x7F) { ap_ht = 1; continue; }
                rates[rates_len++] = r;
            }
        } else if (tag == 50 && tlen >= 1) {
            /* IE Extended Supported Rates — дописываем в хвост */
            for (u8 k = 0; k < tlen && rates_len < 12; k++) {
                u8 r = data[pos + k];
                if (r == 0x7E || r == 0x7F) { ap_ht = 1; continue; }
                rates[rates_len++] = r;
            }
        } else if (tag == 45 && tlen >= 26) {
            ap_ht = 1;                 /* HT Capabilities — точка 11n */
        } else if (tag == 3 && tlen >= 1) {
            channel = data[pos];
        } else if (tag == 48 && tlen >= 2) {
            /* RSN IE — WPA2. Поддерживаем: pairwise CCMP, AKM PSK.
             * ГРУППОВОЙ шифр ЛЮБОЙ (смешанный режим TKIP+AES). */
            const u8 *p = data + pos;
            u32 L = tlen, off = 2;
            int ok_ver = (p[0] == 1 && p[1] == 0);
            int pairwise_ccmp = 0, akm_psk = 0;
            int any_akm = 0, any_pair = 0;
            if (off + 4 <= L) {
                group_tkip = (memcmp(p + off, "\x00\x0F\xAC\x02", 4) == 0);
                off += 4;
            }
            if (off + 2 <= L) {
                u32 pcnt = (u32)p[off] | ((u32)p[off + 1] << 8);
                off += 2;
                for (u32 k = 0; k < pcnt && off + 4 <= L; k++, off += 4) {
                    any_pair = 1;
                    if (memcmp(p + off, "\x00\x0F\xAC\x04", 4) == 0)
                        pairwise_ccmp = 1;
                }
            }
            if (off + 2 <= L) {
                u32 acnt = (u32)p[off] | ((u32)p[off + 1] << 8);
                off += 2;
                for (u32 k = 0; k < acnt && off + 4 <= L; k++, off += 4) {
                    any_akm = 1;
                    if (memcmp(p + off, "\x00\x0F\xAC\x02", 4) == 0)
                        akm_psk = 1;
                }
            }
            /* RSN capabilities: бит 6 (0x40) = Management Frame
             * Protection Required — такие точки не принимают клиентов
             * без PMF; мы его не умеем — честно покажем в диагностике */
            if (off + 2 <= L && ((u16)(p[off] | (p[off + 1] << 8)) & 0x0040))
                ap_pmf = 1;
            if (ok_ver && pairwise_ccmp && akm_psk)
                sec = WIFI_SEC_WPA2_PSK;
            else if (ok_ver) {
                sec = WIFI_SEC_OTHER;         /* Enterprise/SAE/TKIP-only */
                if (!pairwise_ccmp && any_pair)
                    rsn_reject = "pairwise без CCMP";
                else if (!akm_psk && any_akm)
                    rsn_reject = "AKM без PSK (Enterprise/SAE?)";
                else if (!any_pair || !any_akm)
                    rsn_reject = "короткий RSN IE";
                else
                    rsn_reject = "версия RSN != 1";
            }
        } else if (tag == 221 && tlen >= 8 &&
                   memcmp(data + pos, "\x00\x50\xF2\x01\x01\x00", 6) == 0) {
            /* WPA IE (Microsoft OUI 00:50:F2, тип 01, версия 01:00).
             * СЕССИЯ 43: маяк с WPA IE = смешанная точка — в ассоциации
             * реальный клиент шлёт ОБА IE (RSN + WPA) */
            ap_wpa = 1;
            const u8 *p = data + pos + 6;
            u32 left = tlen - 6;
            int pairwise_ccmp = 0, akm_psk = 0;
            if (left >= 4) {
                group_tkip = (memcmp(p, "\x00\x50\xF2\x02", 4) == 0);
                p += 4; left -= 4;
            }
            if (left >= 2) {
                u32 pcnt = (u32)p[0] | ((u32)p[1] << 8);
                p += 2;
                for (u32 k = 0; k < pcnt && left >= 6; k++, p += 4, left -= 4)
                    if (memcmp(p, "\x00\x50\xF2\x04", 4) == 0)
                        pairwise_ccmp = 1;
            }
            if (left >= 2) {
                u32 acnt = (u32)p[0] | ((u32)p[1] << 8);
                p += 2;
                for (u32 k = 0; k < acnt && left >= 6; k++, p += 4, left -= 4)
                    if (memcmp(p, "\x00\x50\xF2\x02", 4) == 0)
                        akm_psk = 1;
            }
            if (pairwise_ccmp && akm_psk)
                sec = WIFI_SEC_WPA2_PSK;      /* WPA с CCMP — как WPA2 */
            else if (sec == WIFI_SEC_OTHER)
                sec = WIFI_SEC_WPA_PSK;       /* TKIP-only — не поддержано */
        }
        pos += tlen;
    }
    if (ssid[0] == 0) return;                   /* hidden SSID */

    if (channel == 0) channel = (u8)(wc.scan_channel + 1);
    if (channel < 1 || channel > 14) channel = 1;

    /* уже видели эту точку? — обновляем RSSI/канал/защиту */
    for (int i = 0; i < wc.ap_count; i++) {
        if (memcmp(wc.aps[i].bssid, bssid, 6) == 0) {
            if (rssi > wc.aps[i].rssi) wc.aps[i].rssi = rssi;
            if (channel) wc.aps[i].channel = channel;
            u8 encrypted = (capability & 0x0010) ? 1 : 0;
            wc.aps[i].sec = encrypted ? (u8)sec : (u8)WIFI_SEC_OPEN;
            wc.aps[i].group_tkip = group_tkip;
            wc.aps[i].ht = ap_ht;
            wc.aps[i].wpa = ap_wpa;
            wc.aps[i].pmf = ap_pmf;
            if (wc.aps[i].rates_len == 0 && rates_len > 0) {
                memcpy(wc.aps[i].rates, rates, rates_len);
                wc.aps[i].rates_len = rates_len;
            }
            return;
        }
    }
    if (wc.ap_count < WIFI_MAX_APS) {
        wifi_ap_t *ap = &wc.aps[wc.ap_count++];
        memset(ap, 0, sizeof(*ap));
        strncpy(ap->ssid, ssid, 32);
        memcpy(ap->bssid, bssid, 6);
        ap->rssi = rssi;
        ap->channel = channel;
        ap->beacon_interval = (u8)(interval / 10);
        ap->capability = capability;
        ap->encrypted = (capability & 0x0010) ? 1 : 0;
        if (!ap->encrypted)
            sec = WIFI_SEC_OPEN;
        ap->sec = (u8)sec;
        ap->group_tkip = group_tkip;
        ap->ht = ap_ht;
        ap->wpa = ap_wpa;
        ap->pmf = ap_pmf;
        if (rates_len > 0) {
            memcpy(ap->rates, rates, rates_len);
            ap->rates_len = rates_len;
        }
        wc.stats.aps = (u32)wc.ap_count;
        static const char *secname[4] = { "открытая", "WPA2", "WPA", "WEP/др" };
        wifi_log("ch %d: новая сеть \"%s\" RSSI %d dBm [%s%s]",
                 channel, ssid, (int)rssi, secname[sec],
                 (sec == WIFI_SEC_WPA2_PSK && group_tkip)
                     ? ", группа TKIP" : "");
        if (rsn_reject && ap->encrypted)
            wifi_log("  RSN сети \"%s\" не поддержан: %s", ssid, rsn_reject);
        if (ap_pmf)
            wifi_log("  сеть \"%s\" требует PMF (802.11w) — подключение не гарантируется", ssid);
    }
}

/* ==== ТЕСТОВЫЙ ДОСТУП (харнесс rtlwifi компилирует этот файл) ==== */
#ifdef WIFI_CORE_TEST
wifi_stats_t *wc_test_stats(void) { return &wc.stats; }
int wc_test_ap_count(void) { return wc.ap_count; }
const wifi_ap_t *wc_test_ap(int i) { return &wc.aps[i]; }
wifi_conn_state_t wc_test_conn(void) { return wc.conn; }
const char *wc_test_conn_fail(void) { return wc.conn_fail_reason; }
const char *wc_test_ssid(void) { return wc.conn_ssid; }
int wc_test_keys_installed(void) { return wc.keys_installed; }
void wc_test_set_ready(void) { wc.present = 1; wc.ready = 1; wc.scan_channel = -1; }
#endif

/* ================= RX: приём кадров от драйвера ================= */

static void conn_handle_mgmt(const u8 *frame, u32 len);
static void bridge_rx_to_net(const u8 *frame, u32 len);
static void wpa2_rx_eapol(const u8 *eth_payload, u32 len);

void wc_rx_err(int crc) {
    if (crc) {
        wc.stats.crc_err++;
        if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
            wc.stats.chan_crc[wc.scan_channel]++;
    } else {
        wc.stats.other++;
    }
}

void wc_rx_frame(const u8 *frame, int len, i8 rssi) {
    wc.stats.frames++;
    if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
        wc.stats.chan_frames[wc.scan_channel]++;
    if (len < 2) return;
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if ((fc & 0xFC) == 0x80) {            /* beacon */
        wc.stats.beacons++;
        if (wc.scan_channel >= 0 && wc.scan_channel < WC_NUM_CHANNELS)
            wc.stats.chan_beacons[wc.scan_channel]++;
        parse_beacon(frame, len, rssi);
        /* маяк нашей точки: живём (контроль потери связи) */
        if (wc.conn == WIFI_CONN_CONNECTED && len >= 22 &&
            memcmp(frame + 16, wc.conn_bssid, 6) == 0) {
            wc.beacon_last = timer_ticks();
            wc.conn_rssi = rssi;
        }
        return;
    }
    /* кадры ассоциации и данные нашей точки */
    if (wc.conn == WIFI_CONN_OFF || wc.conn == WIFI_CONN_FAILED)
        return;
    u8 type = (u8)((fc >> 2) & 0x3);
    if (type == 0)
        conn_handle_mgmt(frame, (u32)len);        /* mgmt: AUTH/ASSOC/DEAUTH */
    else if (type == 2 && (wc.conn == WIFI_CONN_CONNECTED ||
                           wc.conn == WIFI_CONN_4WAY)) {
        /* data: в стек (после подключения) и EAPOL рукопожатию (в 4WAY) */
        if (wc.conn == WIFI_CONN_4WAY) {
            wc.fourway_data++;
            /* СЕССИЯ 44: первые data-кадры в окне рукопожатия — раньше
             * по логу нельзя было понять, доходит ли эфир вообще (если
             * счётчик = 0 при таймауте, M1 теряется в RX, а не в парсере) */
            if (wc.fourway_data <= 3)
                WLOGV("4WAY: data-кадр #%u (len=%d fc=%04x)",
                         (unsigned)wc.fourway_data, len, fc);
        }
        bridge_rx_to_net(frame, (u32)len);
    }
}

/* ================= TX: построители кадров 802.11 =================
 * Драйвер получает готовый кадр через ops->tx_frame (рейт логический). */

/* Общий заголовок mgmt: FC(2) Dur(2) addr1=DA addr2=SA addr3=BSSID Seq(2) */
static void put_mgmt_hdr(u8 *f, u16 fc, const u8 *da, u32 *pos) {
    f[0] = (u8)(fc & 0xFF);
    f[1] = (u8)(fc >> 8);
    f[2] = 0x3A; f[3] = 0x00;                 /* duration 58 мкс */
    memcpy(f + 4, da, 6);
    memcpy(f + 10, wc.mac, 6);
    memcpy(f + 16, wc.conn_bssid, 6);
    f[22] = (u8)(wc.tx_seq << 4);
    f[23] = (u8)(wc.tx_seq >> 4);
    wc.tx_seq = (u16)((wc.tx_seq + 1) & 0xFFF);
    *pos = 24;
}

static int tx_mgmt_frame(u16 fc, const u8 *body, u32 body_len) {
    u8 f[128];
    u32 pos = 0;
    u8 da[6];
    memcpy(da, wc.conn_bssid, 6);
    put_mgmt_hdr(f, fc, da, &pos);
    if (pos + body_len > sizeof(f)) return 0;
    memcpy(f + pos, body, body_len);
    pos += body_len;
    return wc.ops->tx_frame(f, pos, WCRATE_1M, 7, 0, -1);
}

/* Authentication Request (открытая система): algo=0, seq=1, status=0 */
static int tx_auth_req(void) {
    u8 body[6] = { 0, 0, 1, 0, 0, 0 };
    return tx_mgmt_frame(0x00B0, body, 6);
}

/* Association Request: listen=3, IE: SSID + rates (+RSN/WPA/HT/WMM).
 * СЕССИЯ 32: capability зеркалим по точке (ESS всегда, Short Preamble —
 * если точка сама его рекламирует: строгие точки отказывают в ассоциации
 * без него).
 * СЕССИЯ 38 (status=18): рейты — ОБЪЕДИНЕНИЕ набора точки из маяка
 * (с её basic-битами) и полного стандарта b/g.
 * СЕССИЯ 43 (status=18 на WPA2-точке с полным набором b/g): по
 * 802.11-2016 status 18 = REFUSED_BASIC_RATES_MISMATCH покрывает и
 * Basic HT-MCS Set — точка 11n отвечает 18 клиенту без HT Capabilities
 * IE. Запрос приведён к виду настоящего клиента (wpa_supplicant):
 *  - рейты отсортированы по возрастанию (basic-биты точки сохранены);
 *  - Short Slot Time (0x0400) зеркалим из capability точки;
 *  - HT Capabilities IE (45), если точка HT (IE 45 или селектор 0x7E/0x7F);
 *  - RSN IE + WPA IE для смешанных точек (оба, как у реального клиента);
 *  - WMM IE — заявляем QoS-клиента (RX-мост умеет QoS и A-MSDU). */
static const u8 wc_std_rates[12] = {   /* 1,2,5.5,11,6,9,12,18,24,36,48,54 Мбит */
    0x02, 0x04, 0x0B, 0x16, 0x0C, 0x12, 0x18, 0x24, 0x30, 0x48, 0x60, 0x6C
};

/* HT Capabilities IE (26 байт): 20 МГц, SM Power Save disabled,
 * MCS 0-15 (2T2R), A-MPDU до 64К. Хватает, чтобы точка видела нас
 * HT-клиентом (данные и RX-агрегаты тянет железо RTL). */
static u32 wc_build_ht_caps(u8 *out) {
    static const u8 body[26] = {
        0x03, 0x00,                   /* HT caps info: SM PS off, 20 МГц */
        0x0F,                         /* A-MPDU: exp 3, spacing 7 */
        0xFF, 0xFF,                   /* RX MCS 0-15 */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00,                   /* HT extended caps */
        0x00, 0x00, 0x00, 0x00,       /* TX beamforming */
        0x00                          /* ASEL */
    };
    out[0] = 45;
    out[1] = sizeof(body);
    memcpy(out + 2, body, sizeof(body));
    return (u32)sizeof(body) + 2;
}

/* WMM Information IE станции (221, тело 7 байт): заявка QoS-клиента */
static const u8 wc_wmm_ie[9] = {
    221, 7, 0x00, 0x50, 0xF2, 0x02, 0x00, 0x01, 0x00
};

/* Объединённый набор рейтов + сортировка по возрастанию (вставками,
 * стабильная — basic-биты точки остаются на своих значениях). */
static u32 wc_build_rates(u8 *out) {
    u8 rates[24];
    u32 rn = 0;
    if (!wc.assoc_rate_alt) {
        for (u32 k = 0; k < wc.conn_rates_len && rn < 24; k++)
            rates[rn++] = wc.conn_rates[k];
    } else {
        rates[rn++] = 0x82; rates[rn++] = 0x84;   /* 1, 2 — basic */
        rates[rn++] = 0x8B; rates[rn++] = 0x96;   /* 5.5, 11 — basic */
    }
    for (u32 k = 0; k < 12 && rn < 24; k++) {
        u8 r = wc_std_rates[k];
        int have = 0;
        for (u32 j = 0; j < rn; j++)
            if ((rates[j] & 0x7F) == (r & 0x7F)) { have = 1; break; }
        if (!have) rates[rn++] = r;               /* добавляем без basic-бита */
    }
    for (u32 i = 1; i < rn; i++) {                /* сортировка по рейту */
        u8 v = rates[i];
        u32 j = i;
        while (j > 0 && (rates[j - 1] & 0x7F) > (v & 0x7F)) {
            rates[j] = rates[j - 1];
            j--;
        }
        rates[j] = v;
    }
    memcpy(out, rates, rn);
    return rn;
}

static int tx_assoc_req(const char *ssid) {
    u8 f[256];
    u32 pos = 0;
    put_mgmt_hdr(f, 0x0000, wc.conn_bssid, &pos);
    u16 cap = 0x0001;                          /* ESS */
    if (wc.conn_capab & 0x0020) cap |= 0x0020; /* Short Preamble как у точки */
    if (wc.conn_capab & 0x0010) cap |= 0x0010; /* Privacy как у точки (WEP/WPA) */
    if (wc.conn_capab & 0x0400) cap |= 0x0400; /* Short Slot Time как у точки */
    f[pos++] = (u8)(cap & 0xFF);
    f[pos++] = (u8)(cap >> 8);
    f[pos++] = 3;   f[pos++] = 0x00;           /* listen interval (как у реальных клиентов) */
    /* IE 0: SSID */
    u32 sl = (u32)strlen(ssid);
    if (sl > 32) sl = 32;
    f[pos++] = 0;
    f[pos++] = (u8)sl;
    memcpy(f + pos, ssid, sl); pos += sl;
    /* IE 1 + IE 50: рейты — отсортированное объединение набора точки
     * и стандарта b/g (как у wpa_supplicant) */
    u8 rates[24];
    u32 rn = wc_build_rates(rates);
    u32 n1 = rn > 8 ? 8 : rn;
    f[pos++] = 1; f[pos++] = (u8)n1;
    memcpy(f + pos, rates, n1); pos += n1;
    if (rn > n1) {
        u32 n2 = rn - n1;
        f[pos++] = 50; f[pos++] = (u8)n2;
        memcpy(f + pos, rates + n1, n2); pos += n2;
    }
    /* диагностика (СЕССИЯ 38/43): что реально уходит в ASSOC REQ */
    {
        char dbg[96];
        u32 o = 0;
        o += (u32)snprintf(dbg + o, sizeof(dbg) - o, "ASSOC REQ: rates %u:",
                           (unsigned)rn);
        for (u32 k = 0; k < rn && k < 12 && o + 4 < sizeof(dbg); k++)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " %02x", rates[k]);
        if (rn > 12)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " +%u",
                               (unsigned)(rn - 12));
        if (wc.conn_ht)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " HT");
        if (wc.conn_wpa)
            o += (u32)snprintf(dbg + o, sizeof(dbg) - o, " WPA");
        wifi_log("%s (cap=%04x)", dbg, (unsigned)cap);
    }
    /* HT Capabilities — точка 11n считает клиента без него несовместимым
     * (status 18 «Basic HT-MCS»/27 «нет HT») */
    if (wc.conn_ht)
        pos += wc_build_ht_caps(f + pos);
    /* RSN IE для WPA2-сетей (CCMP + PSK) — без него точка отклонит
     * ассоциацию или не начнёт рукопожатие */
    if (wc.sec == WIFI_SEC_WPA2_PSK) {
        pos += wpa2_build_rsn_ie(f + pos, wc.ap_group_tkip,
                                 wc.pairwise_tkip);
        /* СЕССИЯ 50: WPA IE добавляем ТОЛЬКО если точка отказала ассоциа-
         * ции без него (fallback). С двумя IE Ralink-точки выбирают свой
         * WPA-режим (дескриптор 254) вместо стандартного RSN — из-за этого
         * рукопожатие и буксовало. RSN-only = как WPA2-only клиент. */
        if (wc.conn_wpa && !wc.assoc_rsn_only)
            pos += wpa2_build_wpa_ie(f + pos, wc.ap_group_tkip,
                                     wc.pairwise_tkip);
    }
    /* WMM IE — заявка QoS-клиента (строгие точки с WMM-only отказывают
     * ассоциацию без него) */
    memcpy(f + pos, wc_wmm_ie, sizeof(wc_wmm_ie));
    pos += sizeof(wc_wmm_ie);
    return wc.ops->tx_frame(f, pos, WCRATE_1M, 7, 0, -1);
}

/* Deauthentication (reason 3 = STATION LEAVING) */
static int tx_deauth(void) {
    u8 body[2] = { 3, 0 };
    return tx_mgmt_frame(0x00C0, body, 2);
}

/* ---- IV-заголовки шифрхвостов (СЕССИЯ 51) ----
 * Железо 8192EU ШИФРУЕТ тело (sec_type в дескрипторе), но IV-заголовок
 * в кадр обязан положить драйвер — эталон rtl8xxxu берёт его из mac80211
 * (IEEE80211_KEY_FLAG_GENERATE_IV), сам чип IV не строит. Без IV-хвоста
 * точка видит «Protected»-кадр без CCMP/TKIP-заголовка и молча роняет
 * ЕЩЁ ДО расшифровки — это и убивало DHCP/ARP после рукопожатия.
 * Раскладка байт — дословно из net/mac80211 (wpa.c:ccmp_pn2hdr,
 * tkip.c:ieee80211_tkip_add_iv), PN растёт с 1 (increment-before-use). */

/* CCMP: 8 байт [PN5][PN4][00][0x20|keyid<<6][PN3][PN2][PN1][PN0].
 * СЕССИЯ 52: прежняя раскладка клала PN в LE-порядке ([PN0][PN1]...,
 * [PN2..PN5] в хвосте) — а 802.11/802.11i требует PN СТАРШИМ байтом
 * вперёд (mac80211 ccmp_pn2hdr: hdr[0]=pn[5]... hdr[7]=pn[0], hostapd
 * то же). Для pn<256 точка видела PN=pn*2^40 (монотонно — маскировалось),
 * после 256 кадров PN «прыгал» назад — точка роняла всё как replay. */
static void wpa2_tx_iv_ccmp(u8 *out, u64 pn, int keyid) {
    out[0] = (u8)(pn >> 40);
    out[1] = (u8)(pn >> 32);
    out[2] = 0;
    out[3] = (u8)(0x20 | ((keyid & 3) << 6));
    out[4] = (u8)(pn >> 24);
    out[5] = (u8)(pn >> 16);
    out[6] = (u8)(pn >> 8);
    out[7] = (u8)(pn);
}

/* TKIP: [TSC1][TSC1|0x20 (&0x7f)][TSC0][keyid<<6|EXT][IV32 LE32],
 * iv16 = pn & 0xffff, iv32 = pn >> 16 */
static void wpa2_tx_iv_tkip(u8 *out, u64 pn, int keyid) {
    u16 iv16 = (u16)(pn & 0xFFFFu);
    u32 iv32 = (u32)(pn >> 16);
    out[0] = (u8)(iv16 >> 8);
    out[1] = (u8)(((iv16 >> 8) | 0x20) & 0x7F);
    out[2] = (u8)(iv16 & 0xFF);
    out[3] = (u8)(((keyid & 3) << 6) | 0x20);   /* Ext IV */
    out[4] = (u8)(iv32);
    out[5] = (u8)(iv32 >> 8);
    out[6] = (u8)(iv32 >> 16);
    out[7] = (u8)(iv32 >> 24);
}

/* ---- Ethernet -> 802.11 (TX данных) ----
 * Кадр: data+ToDS, addr1=BSSID addr2=наш MAC addr3=eth.dst, LLC/SNAP. */
int wifi_net_send(const void *eth_frame, u32 len) {
    if (!wc.ops || wc.conn != WIFI_CONN_CONNECTED || !wc.ready)
        return -1;
    if (len < 14 || len > 1518) return -1;
    const u8 *eth = (const u8 *)eth_frame;

    s_lock(&wc.tx_lock);
    static u8 f[WIFI_TXBUF_SZ];
    u32 pos = 0, iv_pos = 0;
    f[0] = 0x08; f[1] = 0x01;                 /* data, ToDS */
    /* WPA2: бит Protected (FC.14) — данные уходят шифрованными;
     * железо строит CCMP/TKIP-заголовок и шифрует по ключу. */
    int fc_protected = (wc.keys_installed != 0);
    if (fc_protected)
        f[1] = 0x01 | 0x40;                   /* ToDS + Protected */
    f[2] = 0x3A; f[3] = 0x00;                 /* duration */
    memcpy(f + 4, wc.conn_bssid, 6);          /* addr1 = BSSID */
    memcpy(f + 10, wc.mac, 6);                /* addr2 = мы */
    memcpy(f + 16, eth, 6);                   /* addr3 = dst MAC */
    f[22] = (u8)(wc.tx_seq << 4);
    f[23] = (u8)(wc.tx_seq >> 4);
    wc.tx_seq = (u16)((wc.tx_seq + 1) & 0xFFF);
    pos = 24;
    /* СЕССИЯ 51→52: IV-заголовок строим САМИ (см. коммент над билдерами).
     * СЕССИЯ 52: ШИФРУЕМ ТОЛЬКО ПАРНЫМ КЛЮЧОМ — по 802.11i (12.5.x)
     * станция в BSS защищает группо-адресованные MSDU к своей точке
     * ПАРНЫМ шифром (точка расшифрует PTK и перезашифрует GTK соседям);
     * mac80211 так и делает (ieee80211_tx_h_select_key берёт sta->ptk
     * для ВСЕХ данных). Прежний broadcast→GTK-TKIP точка не могла даже
     * расшифровать (ждёт CCMP-PTK) — DHCP DISCOVER/ARP молча падали.
     * keyid парного ключа всегда 0 → CAM-ячейка 0. */
    if (fc_protected) {
        u64 pn = ++wc.ptk_pn;
        iv_pos = pos;
        if (wc.ptk_is_tkip) wpa2_tx_iv_tkip(f + pos, pn, 0);
        else                wpa2_tx_iv_ccmp(f + pos, pn, 0);
        pos += 8;
    }
    f[pos++] = 0xAA; f[pos++] = 0xAA; f[pos++] = 0x03;   /* LLC/SNAP */
    f[pos++] = 0x00; f[pos++] = 0x00; f[pos++] = 0x00;
    memcpy(f + pos, eth + 12, len - 12);      /* ethertype + payload */
    pos += len - 12;
    if (fc_protected && wc.ptk_is_tkip) {
        /* СЕССИЯ 51: Michael MIC — В СОФТЕ (железо 8192EU делает
         * только RC4; эталон rtl8xxxu — GENERATE_MMIC в mac80211).
         * Вход MIC = MSDU (LLC/SNAP+payload, ПОСЛЕ IV), ключ — наш
         * TX-MIC парного ключа (ptk+56; KDE несёт [TK][RX][TX]).
         * В кадре: [IV 8][MSDU][MIC 8], ICV 4 добавит железо.
         * СЕССИЯ 52: TKIP-пара и для broadcast (PTK, см. выше). */
        u8 mic8[8];
        wpa2_tkip_michael(wc.ptk + 56, eth, eth + 6, f + iv_pos + 8,
                          pos - iv_pos - 8, mic8);
        memcpy(f + pos, mic8, 8);
        pos += 8;
    }

    /* broadcast/multicast — без ACK, basic-рейт */
    int noack = (eth[0] & 1) != 0;
    wc_rate_t rate = noack ? WCRATE_2M : WCRATE_11M;
    int tries = noack ? 3 : 4;
    /* EAPOL сюда не попадает — у него свой путь (wpa2_tx_eapol_eth).
     * СЕССИЯ 52: шифруем всегда парным ключом (см. коммент выше):
     * у Atheros keyidx — номер ячейки keycache (PTK = KC_PTK_ENTRY=4),
     * у Realtek — только признак «шифровать» (алгоритм берётся из
     * ptk_is_tkip, сама ячейка = CAM[0] по keyid из IV). */
    int keyidx = -1;
    if (wc.keys_installed && fc_protected)
        keyidx = 4;
    int r = wc.ops->tx_frame(f, pos, rate, tries, noack, keyidx) ? (int)len : 0;
    if (r > 0) {
        wc.data_tx++;
        if (!noack) wc.data_tx_uc++;   /* сессия 53: юникаст-TX */
    }
    s_unlock(&wc.tx_lock);
    return r;
}

/* ---- 802.11 -> Ethernet (RX данных) ----
 * От точки (FromDS): addr1=DA, addr2=BSSID, addr3=SA; после заголовка
 * LLC/SNAP. Складывается в кольцо к net.c (забирает wifi_net_recv).
 * tail_cut — байт шифрхвоста (MIC/ICV), hdr_iv_skip — пропустить
 * CCMP/TKIP-заголовок после 802.11-заголовка.
 * СЕССИЯ 43: разбор A-MSDU (QoS-кадр с битом A-MSDU) — HT-точки
 * агрегируют несколько MSDU в один кадр, без разбора сетевой стек
 * получал бы мусор. */

/* Положить ethernet-кадр в кольцо к net.c (или EAPOL — в рукопожатие).
 * da/sa — MAC адреса, payload — LLC/SNAP (8) + данные. */
static void bridge_push_eth(const u8 da[6], const u8 sa[6],
                            const u8 *payload, u32 payload_len) {
    if (payload_len < 8) return;
    u16 ethertype = (u16)((payload[6] << 8) | payload[7]);
    if (ethertype == 0x888E) {
        /* EAPOL — в обработчик рукопожатия WPA2, не в сетевой стек */
        wpa2_rx_eapol(payload + 6, payload_len - 6);
        return;
    }
    if (wc.conn != WIFI_CONN_CONNECTED) return;   /* мост только после 4-way */
    wc.data_rx++;
    if ((da[0] & 1) == 0) wc.data_rx_uc++;        /* юникаст от точки */
    u32 eth_len = 14 + (payload_len - 8);
    if (eth_len > WIFI_NET_RXSZ) return;
    int nxt = (wc.netrx_head + 1) % WIFI_NET_RXQ;
    if (nxt == wc.netrx_tail) return;         /* кольцо полно — теряем кадр */
    s_lock(&wc.rx_lock);
    u8 *dst = wc.netrx[wc.netrx_head];
    memcpy(dst, da, 6);
    memcpy(dst + 6, sa, 6);
    memcpy(dst + 12, payload + 6, payload_len - 6);
    wc.netrx_len[wc.netrx_head] = (u16)eth_len;
    wc.netrx_head = nxt;
    s_unlock(&wc.rx_lock);
}

static void bridge_rx_to_net_ex(const u8 *frame, u32 len,
                                u32 hdr_iv_skip, u32 tail_cut) {
    if (len < 30) return;                     /* 24 hdr + LLC 6 + ethertype 2 */
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if ((fc & 0x0C) != 0x08) return;          /* не data */
    if (!(fc & 0x0200)) return;               /* не FromDS */
    u8 subtype = (u8)((fc >> 4) & 0xF);
    u32 hdr = (subtype & 0x8) ? 26 : 24;      /* QoS-data: +2 байта */
    if (fc & 0x8000) hdr += 4;                /* Order: +HTC (11n, редко) */
    if (len < hdr + 8) return;
    if (memcmp(frame + 4, wc.mac, 6) != 0 &&
        (frame[4] & 1) == 0)
        return;                               /* не нам и не mcast */
    u32 plen = len;
    if (hdr_iv_skip) hdr += hdr_iv_skip;      /* CCMP/TKIP-заголовок */
    if (tail_cut && plen > tail_cut) plen -= tail_cut;  /* MIC/ICV в хвосте */
    if (plen < hdr + 8) return;

    /* A-MSDU: у QoS-кадра бит 7 второго байта QoS Control (frame[25]).
     * Поддкадры: DA(6) SA(6) len(2, LE) + MSDU, паддинг до 4 байт. */
    if ((subtype & 0x8) && (frame[25] & 0x80)) {
        u32 p = hdr;
        u32 pushed = 0;
        while (p + 14 <= plen) {
            u32 sl = (u32)frame[p + 12] | ((u32)frame[p + 13] << 8);
            if (sl < 8 || p + 14 + sl > plen) break;   /* мусор/конец */
            bridge_push_eth(frame + p, frame + p + 6, frame + p + 14, sl);
            pushed++;
            p += 14 + sl;
            u32 pad = (4 - (sl & 3)) & 3;    /* паддинг не после последнего */
            if (p + pad < plen) p += pad;
            if (pushed > 32) break;          /* защита от кривого кадра */
        }
        return;
    }

    if (memcmp(frame + hdr, "\xAA\xAA\x03\x00\x00\x00", 6) != 0)
        return;                               /* не LLC/SNAP */
    bridge_push_eth(frame + 4, frame + 16, frame + hdr, plen - hdr);
}

/* защищённый кадр: железо расшифровало, но IV (8 б после hdr) и
 * хвост (MIC 8 + для TKIP ещё ICV 4) остались в буфере.
 * СЕССИЯ 51: хвост выбираем по НАПРАВЛЕНИЮ кадра: broadcast/multicast
 * шифрован GTK (TKIP у этой точки → 12), unicast — парой (CCMP → 8).
 * Прежний выбор по gtk_is_tkip резал CCMP-юникаст на 4 байта больше —
 * у уникаст-кадров от точки отваливался хвост LLC. */
static void bridge_rx_to_net(const u8 *frame, u32 len) {
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    if (fc & 0x4000) {                        /* Protected */
        int mcast = (frame[4] & 1) != 0;
        u32 tail = mcast ? (wc.gtk_is_tkip ? 12 : 8)
                         : (wc.ptk_is_tkip ? 12 : 8);
        bridge_rx_to_net_ex(frame, len, 8, tail);
    } else {
        bridge_rx_to_net_ex(frame, len, 0, 0);
    }
}

u32 wifi_net_recv(void *buf, u32 max) {
    if (wc.netrx_tail == wc.netrx_head) return 0;
    s_lock(&wc.rx_lock);
    u32 n = wc.netrx_len[wc.netrx_tail];
    if (n > max) n = max;
    memcpy(buf, wc.netrx[wc.netrx_tail], n);
    wc.netrx_tail = (wc.netrx_tail + 1) % WIFI_NET_RXQ;
    s_unlock(&wc.rx_lock);
    return n;
}

void wifi_net_get_mac(u8 out_mac[6]) { memcpy(out_mac, wc.mac, 6); }
int  wifi_net_link(void) { return wc.ops && wc.conn == WIFI_CONN_CONNECTED; }

/* ================= публичный API скана/статуса ================= */

void wifi_scan_start(void) {
    if (!wc.present || !wc.ready || !wc.ops) return;
    if (wc.scanning) return;
    memset(&wc.stats, 0, sizeof(wc.stats));
    /* СЕССИЯ 28: список точек СОХРАНЯЕТСЯ между сканами — он
     * обновляется маяками. Очистка при подключении выглядела как
     * «поиск начался заново» сразу после Enter в поле пароля. */
    wc.scanning = 1;
    wc.scan_channel = 0;
    wc.dwell_start = timer_ticks();
    wifi_log("скан: старт (каналы 1-14, %d мс/канал)", WIFI_SCAN_DWELL);
    if (!wc.ops->set_channel(0))
        wifi_log("скан: смена канала не удалась");
}

int  wifi_present(void)    { return wc.present; }
int  wifi_ready(void)      { return wc.ready; }
const char *wifi_chip_name(void) { return wc.chip_name; }
int  wifi_scan_active(void) { return wc.scanning; }

int wifi_scan_results(wifi_ap_t *out, int max) {
    s_lock(&wc.rx_lock);
    int n = wc.ap_count;
    if (n > max) n = max;
    memcpy(out, wc.aps, (u32)n * sizeof(wifi_ap_t));
    s_unlock(&wc.rx_lock);
    return n;
}

void wifi_get_stats(wifi_stats_t *out) {
    if (!out) return;
    s_lock(&wc.rx_lock);
    wc.stats.channel = wc.scanning ? wc.scan_channel + 1 : 0;
    wc.stats.pass = wc.pass;
    *out = wc.stats;
    s_unlock(&wc.rx_lock);
}

/* ================= WPA2-PSK: рукопожатие и ключи ================= */

/* Генератор для SNonce: xorshift32, засеянный таймером + MAC. */
static void wpa2_rng_seed(void)
{
    wc.rng_state ^= timer_ticks() * 2654435761u;
    for (int i = 0; i < 6; i++)
        wc.rng_state = (wc.rng_state << 8) | wc.mac[i];
    wc.rng_state ^= ((u32)wc.conn_aid << 16) ^ (u32)wc.tx_seq;
    if (!wc.rng_state) wc.rng_state = 0x9E3779B9u;
}

static u32 wpa2_rng_next(void)
{
    u32 x = wc.rng_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    wc.rng_state = x;
    return x;
}

/* PMK для текущего ssid+psk (с кэшем — PBKDF2 4096 итераций). */
static int wpa2_ensure_pmk(void)
{
    if (wc.pmk_valid &&
        strcmp(wc.pmk_ssid, wc.conn_ssid) == 0 &&
        strcmp(wc.pmk_psk, wc.psk) == 0)
        return 1;
    u32 t0 = timer_ticks();
    wpa2_pbkdf2_sha1((const u8 *)wc.psk, (u32)strlen(wc.psk),
                     (const u8 *)wc.conn_ssid, (u32)strlen(wc.conn_ssid),
                     4096, wc.pmk, 32);
    strncpy(wc.pmk_ssid, wc.conn_ssid, sizeof(wc.pmk_ssid) - 1);
    wc.pmk_ssid[sizeof(wc.pmk_ssid) - 1] = 0;
    strncpy(wc.pmk_psk, wc.psk, sizeof(wc.pmk_psk) - 1);
    wc.pmk_psk[sizeof(wc.pmk_psk) - 1] = 0;
    wc.pmk_valid = 1;
    wifi_log("PMK посчитан (%u мс)", (unsigned)(timer_ticks() - t0));
    return 1;
}

static void wpa2_install_keys(void)
{
    if (!wc.ops->keys_install) return;
    /* СЕССИЯ 51: свежие ключи = свежие PN-счётчики (повтор PN после
     * переустановки точка считает replay и роняет кадры). */
    wc.ptk_pn = 0;
    if (wc.ops->keys_install(wc.conn_bssid, wc.ptk, wc.ptk_is_tkip,
                             wc.gtk, wc.gtk_is_tkip, wc.gtk_keyid)) {
        wc.keys_installed = 1;
        wifi_log("ключи установлены: PTK(%s) + GTK(keyid=%d%s)",
                 wc.ptk_is_tkip ? "TKIP-64" : "CCMP",
                 wc.gtk_keyid, wc.gtk_is_tkip ? ", TKIP" : "");
    } else {
        wifi_log("ключи НЕ установлены (ошибка железа)");
    }
}

static void wpa2_clear_keys(void)
{
    if (wc.ops && wc.ops->keys_clear) wc.ops->keys_clear();
    wc.keys_installed = 0;
}

/* Отправка EAPOL-кадра точке (ВСЕГДА без шифрования — Protected=0:
 * даже после установки ключей рукопожатие идёт открыто, шифруется
 * только key data). eth = [dst=AP][src=мы][888E]. */
static int wpa2_tx_eapol_eth(const u8 *eth, u32 eth_len)
{
    if (eth_len > 1518) return 0;
    static u8 f[WIFI_TXBUF_SZ];
    u32 pos = 0;
    f[0] = 0x08; f[1] = 0x01;                 /* data, ToDS, НЕ Protected */
    f[2] = 0x3A; f[3] = 0x00;
    memcpy(f + 4, wc.conn_bssid, 6);          /* addr1 = BSSID */
    memcpy(f + 10, wc.mac, 6);                /* addr2 = мы */
    memcpy(f + 16, eth, 6);                   /* addr3 = DA (точка) */
    f[22] = (u8)(wc.tx_seq << 4);
    f[23] = (u8)(wc.tx_seq >> 4);
    wc.tx_seq = (u16)((wc.tx_seq + 1) & 0xFFF);
    pos = 24;
    f[pos++] = 0xAA; f[pos++] = 0xAA; f[pos++] = 0x03;
    f[pos++] = 0x00; f[pos++] = 0x00; f[pos++] = 0x00;
    memcpy(f + pos, eth + 12, eth_len - 12);  /* ethertype + тело */
    pos += eth_len - 12;
    return wc.ops->tx_frame(f, pos, WCRATE_11M, 4, 0, -1);
}

/* Обработать входящий EAPOL-Key (вызывается из bridge_rx_to_net).
 * eth указывает на LLC-payload: [ethertype 888E][EAPOL...].
 * Робастность (сессия 15): версия 2/3, ретрансмиссия M1, групповой
 * rekey в CONNECTED. */
static void wpa2_rx_eapol(const u8 *eth_payload, u32 len)
{
    if (wc.conn != WIFI_CONN_4WAY && wc.conn != WIFI_CONN_CONNECTED) return;
    /* len = [ethertype 888E 2 б][EAPOL hdr 4 б][Key-дескриптор >= 95 б];
     * раньше сравнивали с 14+4+95+2 (как ПОЛНЫЙ eth-кадр) — минимальный
     * M1 (99 б EAPOL-Key без key data) отбрасывался как «короткий» */
    if (len < 2 + 4 + 95) return;             /* короткий EAPOL-Key */

    /* СЕССИЯ 44: диагностика рукопожатия. eth_payload =
     * [888E 2б][EAPOL hdr 4б][дескриптор]: ver @+2, type @+3,
     * body len @+4, desc type @+6, key info @+7..8. Раньше ВСЕ отказы
     * ниже были тихими — по логу нельзя было понять, где теряется M1. */
    WLOGV("[wpa2] EAPOL: len=%u v%u d%u ki=0x%04x klen=%u kd=%u",
             (unsigned)len, eth_payload[2], eth_payload[6],
             (u16)(((u32)eth_payload[7] << 8) | eth_payload[8]),
             (u16)(((u32)eth_payload[9] << 8) | eth_payload[10]),
             (u16)(((u32)eth_payload[99] << 8) | eth_payload[100]));

    static u8 eb[WIFI_NET_RXSZ];
    if (len + 14 > sizeof(eb)) return;
    memset(eb, 0, 14);
    memcpy(eb + 12, eth_payload, len);        /* 888E + тело */

    eapol_key_t k;
    if (!wpa2_parse_eapol_key(eb, len + 14, &k)) {
        wifi_log("[wpa2] разбор EAPOL-Key не прошёл (body=%u)",
                 (u32)(((u32)eth_payload[4] << 8) | eth_payload[5]));
        return;
    }

    u16 ki = k.key_info;
    u8  kv = (u8)(ki & WPA2_KI_VER_MASK);    /* версия дескриптора */
    /* СЕССИЯ 45: is_wpa = дескриптор 254 — смешанные точки согласуют
     * WPA-протокол; прежняя ветка «только RSN» отбрасывала такое
     * рукопожатие (лог: desc=254, «разбор не прошёл (body=95)») */
    int is_wpa  = (k.desc_type == 254);
    /* ver 2 = AES (CCMP), ver 3 = AES-128-CMAC (PMF-capable точки;
     * AKM тот же PSK-SHA1 — обрабатываем как ver 2), ver 1 = HMAC-MD5
     * (WPA/TKIP) — только для дескриптора 254 */
    int ver_ok = ((ki & WPA2_KI_VER_MASK) == WPA2_KI_VER_AES) ||
                 ((ki & WPA2_KI_VER_MASK) == 3) || (is_wpa && kv == 1);
    int pairwise = (ki & WPA2_KI_KEY_TYPE) != 0;
    int has_mic  = (ki & WPA2_KI_MIC) != 0;
    int has_ack  = (ki & WPA2_KI_ACK) != 0;

    /* ---- ГРУППОВОЙ КЛЮЧ: WPA — после M4 (fw_phase 2); RSN — rekey GTK
     *      в CONNECTED. Сверяно с wpa_supplicant_process_1_of_2_wpa():
     *      GTK = расшифрованный key data целиком, длина в поле
     *      Key Length (WPA); ver1 = RC4(KeyIV||KEK, skip 256),
     *      ver2 = AES-KW. */
    if (!pairwise && has_mic && ver_ok &&
        (wc.fw_phase == 2 ||
         (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed))) {
        static u8 micbuf[WIFI_NET_RXSZ];
        u32 flen = k.frame_len;
        if (flen > sizeof(micbuf)) return;
        memcpy(micbuf, eb, flen);
        memset(micbuf + 95, 0, 16);
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, micbuf, flen, mic);
        if (!wpa2_ct_equal(mic, k.mic, 16)) {
            wifi_log("WPA2: group-M1 MIC неверный — игнор");
            return;
        }
        int rekey = (wc.conn == WIFI_CONN_CONNECTED);
        u8 gtkk[32];
        memset(gtkk, 0, sizeof(gtkk));
        int have_gtk = 0;
        if (is_wpa) {
            u16 gtk_len = k.key_len;
            if (gtk_len != 16 && gtk_len != 32) {
                wifi_log("WPA: групповой ключ длины %u — игнор",
                         (unsigned)gtk_len);
                return;
            }
            static u8 kd[WIFI_NET_RXSZ];
            if (kv == 1) {
                if (k.key_data_len < gtk_len || k.key_data_len > sizeof(kd)) {
                    wifi_log("WPA: group-M1 kd короткий (%u < %u)",
                             (unsigned)k.key_data_len, (unsigned)gtk_len);
                    return;
                }
                memcpy(kd, k.key_data, k.key_data_len);
                u8 ek[32];
                memcpy(ek, k.iv, 16);
                memcpy(ek + 16, wc.ptk + 16, 16);
                wpa2_rc4_skip(ek, 32, 256, kd, k.key_data_len);
                memset(ek, 0, sizeof(ek));
            } else {
                if (k.key_data_len < 16 || (k.key_data_len & 7) ||
                    k.key_data_len > sizeof(kd)) {
                    wifi_log("WPA: group-M1 kd повреждён (len=%u)",
                             (unsigned)k.key_data_len);
                    return;
                }
                if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data,
                                     k.key_data_len, kd)) {
                    wifi_log("WPA: group-M1 unwrap не прошёл");
                    return;
                }
            }
            memcpy(gtkk, kd, gtk_len);
            if (gtk_len > 16) memset(gtkk + gtk_len, 0, 32 - gtk_len);
            wc.gtk_is_tkip = (gtk_len == 32);
            wc.gtk_keyid = (ki & WPA2_KI_KEY_INDEX) >> 4;
            have_gtk = 1;
        } else {
            static u8 kd[WIFI_NET_RXSZ];
            if (k.key_data_len < 16 || (k.key_data_len & 7) ||
                k.key_data_len > sizeof(kd)) {
                wifi_log("WPA2: group-M1 kd повреждён (len=%u)",
                         (unsigned)k.key_data_len);
                return;
            }
            if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data,
                                 k.key_data_len, kd)) {
                wifi_log("WPA2: group-M1 unwrap не прошёл");
                return;
            }
            u32 kdn = k.key_data_len - 8;
            u32 off = 0;
            while (off + 2 <= kdn) {
                u8 t = kd[off], l = kd[off + 1];
                if (t == 0xDD && l >= 8 && off + 2 + 8 <= kdn &&
                    memcmp(kd + off + 2, "\x00\x0F\xAC\x01", 4) == 0) {
                    u8 flags = kd[off + 6];
                    u32 klen = (u32)l - 6;
                    /* СЕССИЯ 51: GTK с off+8 (OUI4+keyid+reserved —
                     * канонический GTK KDE; было off+7 — сдвиг на байт) */
                    if (klen > 32) klen = 32;
                    if (klen < 16) klen = 16;
                    if (off + 2 + 6 + klen <= kdn) {
                        memcpy(gtkk, kd + off + 8, klen);
                        if (klen > 16) memset(gtkk + klen, 0, 32 - klen);
                        wc.gtk_is_tkip = (klen == 32);
                        wc.gtk_keyid = flags & 3;
                        have_gtk = 1;
                    }
                }
                if (t == 0xDD && l == 0) { off += 2; continue; }
                if (l == 0 && t == 0) break;
                off += 2u + l;
            }
            if (!have_gtk) {
                wifi_log("WPA2: GTK KDE не найден в group-M1");
                return;
            }
        }
        memcpy(wc.gtk, gtkk, sizeof(wc.gtk));
        memcpy(wc.replay, k.replay, 8);       /* M2 отвечает счётчиком M1 */
        wpa2_install_keys();
        /* групповой M2: keyidx эхом (биты 4..5), ver, SECURE, MIC */
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        k.desc_type,
                                        (u16)(kv | (ki & WPA2_KI_KEY_INDEX) |
                                              WPA2_KI_MIC | WPA2_KI_SECURE),
                                        k.key_len, NULL, wc.replay, NULL, 0);
        if (k.ver) eb[14] = k.ver;           /* эхо EAPOL-версии точки */
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        wpa2_tx_eapol_eth(eb, n);
        if (!rekey) {
            wc.fw_phase = 0;
            wc.conn = WIFI_CONN_CONNECTED;
            wc.beacon_last = timer_ticks();
            wifi_log("WPA: рукопожатие завершено — \"%s\" доступна (%s)",
                     wc.conn_ssid, is_wpa ? "WPA/PSK" : "WPA2/PSK");
            wifi_profile_save(wc.conn_ssid);
        } else {
            wifi_log("WPA2: групповой ключ обновлён (GTK keyid=%d)",
                     wc.gtk_keyid);
        }
        return;
    }

    /* ---- Сообщение 1: ANonce, без MIC, с ACK ---- */
    if (wc.fw_phase == 0 && pairwise && has_ack && !has_mic && !ver_ok) {
        /* СЕССИЯ 44: ver 1 = TKIP-pairwise (HMAC-MD5/RC4), ver 2/3 = AES.
         * Раньше такой M1 отбрасывался МОЛЧА и выглядел как «нет EAPOL». */
        wifi_log("[wpa2] M1 с версией ключа %u не поддержан "
                 "(1 = пара TKIP, ждали AES)", ki & WPA2_KI_VER_MASK);
        return;
    }
    if ((wc.fw_phase == 0 || wc.conn == WIFI_CONN_CONNECTED) &&
        pairwise && has_ack && !has_mic && ver_ok) {
        wc.fw_desc = (u8)k.desc_type;         /* 2 RSN / 254 WPA */
        wc.fw_ver  = kv;
        wc.m2_apie_sent = 0;
        wc.m2_rsn_tries = 0;
        memcpy(wc.replay_m1, k.replay, 8);
        /* СЕССИЯ 48: ver 1 = TKIP-пара — теперь ПОЛНАЯ поддержка:
         * PTK-64 (KCK+KEK+TK+2 MIC), MIC M2 = HMAC-MD5, железо —
         * 32-байтная CAM-запись. Родной режим старых WPA-точек. */
        wc.ptk_is_tkip = (kv == 1);
        if (wc.ptk_is_tkip)
            wifi_log("WPA: точка выбрала TKIP-пару (ver 1) — PTK-64/HMAC-MD5");
        memcpy(wc.anonce, k.nonce, 32);
        memcpy(wc.replay, k.replay, 8);

        wpa2_rng_seed();
        for (int i = 0; i < 8; i++) {
            u32 r = wpa2_rng_next();
            wc.snonce[i*4+0] = (u8)r; wc.snonce[i*4+1] = (u8)(r >> 8);
            wc.snonce[i*4+2] = (u8)(r >> 16); wc.snonce[i*4+3] = (u8)(r >> 24);
        }
        wpa2_ensure_pmk();
        wpa2_derive_ptk_ex(wc.pmk, wc.conn_bssid, wc.mac,
                           wc.anonce, wc.snonce, wc.ptk,
                           wc.ptk_is_tkip ? 64 : 48);

        /* СЕССИЯ 45 (send_2_of_4): M2 несёт ТОТ IE, по которому
         * согласовано рукопожатие — WPA IE для дескриптора 254,
         * RSN IE для 2. Прежний M2 всегда нёс RSN IE + дескриптор 2:
         * точка WPA отвергала его как чужой (или мы молчали).
         * Key Length: WPA — эхо точки, RSN — 0. MIC по версии. */
        u8 kd[32];
        u16 keylen = (u16)(is_wpa ? k.key_len : 0);
        u32 kdl = is_wpa ? wpa2_build_wpa_ie(kd, wc.ap_group_tkip,
                                             wc.pairwise_tkip)
                         : wpa2_build_rsn_ie(kd, wc.ap_group_tkip,
                                             wc.pairwise_tkip);
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        k.desc_type,
                                        (u16)(kv | WPA2_KI_KEY_TYPE |
                                              WPA2_KI_MIC),
                                        keylen,
                                        wc.snonce, wc.replay, kd, (u16)kdl);
        /* СЕССИЯ 47: эхо EAPOL-версии точки (она шлёт v1, мы v2 —
         * часть точек-Broadcom/Realtek rejects чужую версию) */
        if (k.ver) eb[14] = k.ver;
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);  /* KCK = ptk[0..15] */
        wpa2_eapol_set_mic(eb, mic);
        if (!wpa2_tx_eapol_eth(eb, n)) {
            wifi_log("M2 не отправлен (TX отказ)");
            return;
        }
        wifi_log("TX M2: desc=%u ki=0x%04x klen=%u kd=%u",
                 k.desc_type, (u16)(kv | WPA2_KI_KEY_TYPE | WPA2_KI_MIC),
                 keylen, (unsigned)kdl);
        wc.m2_rsn_tries = 1;
        wc.fw_phase = 1;                     /* ждём M3 */
        wc.fw_timer = timer_ticks();
        wifi_log("WPA2: M1 получен, M2 отправлен (PTK выведен%s)",
                 is_wpa ? ", WPA-протокол" : "");
        return;
    }

    /* ---- РЕТРАНСМИССИЯ M1 (ждём M3, пришёл снова M1) ----
     * СЕССИЯ 51: с 1-й ретрансмиссии RSN-M2 несёт RSN IE ТОЧКИ
     * (захвачен из assoc-resp). Ralink сверяет IE в M2 с СОБСТВЕННЫМ
     * побайтно: наш (1 пара CCMP) != её (2 пары) — все M2 молча
     * ронялись, точка по таймауту уходила в «оптимистичный» M3 и
     * игнорировала M4 (луп M3 → DEAUTH). hostapd такой второй M2
     * роняет по replay — безопасно. */
    if (wc.fw_phase == 1 && wc.conn == WIFI_CONN_4WAY &&
        pairwise && has_ack && !has_mic && ver_ok &&
        memcmp(k.nonce, wc.anonce, 32) == 0) {
        u8 kd[40];
        u16 keylen = (u16)(is_wpa ? k.key_len : 0);
        u32 kdl;
        int apie = 0;
        if (!is_wpa && wc.m2_rsn_tries >= 1 && wc.ap_rsn_ie_len >= 20) {
            memcpy(kd, wc.ap_rsn_ie, wc.ap_rsn_ie_len);
            kdl = wc.ap_rsn_ie_len;
            apie = 1;
        } else if (is_wpa) {
            kdl = wpa2_build_wpa_ie(kd, wc.ap_group_tkip,
                                    wc.pairwise_tkip);
        } else {
            kdl = wpa2_build_rsn_ie(kd, wc.ap_group_tkip,
                                    wc.pairwise_tkip);
        }
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        k.desc_type,
                                        (u16)(kv | WPA2_KI_KEY_TYPE |
                                              WPA2_KI_MIC),
                                        keylen,
                                        wc.snonce, wc.replay, kd, (u16)kdl);
        if (k.ver) eb[14] = k.ver;           /* эхо EAPOL-версии точки */
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        wpa2_tx_eapol_eth(eb, n);
        if (apie && !wc.m2_apie_sent) {
            wc.m2_apie_sent = 1;             /* однократный milestone-лог */
            wifi_log("повтор M2 с RSN IE точки (%u б) — ждём её M3",
                     (unsigned)kdl);
        } else {
            WLOGV("WPA2: повторный M1 — M2 перепослан");
        }
        return;
    }

    /* ---- Сообщение 3: ACK + MIC + pairwise. RSN: key data зашифрован
     *      (ENCR_DATA+SECURE), GTK KDE внутри — ключи сразу; WPA (254):
     *      СЕССИЯ 46 — M3 у WPA-точек БЕЗ бита Secure (лог:
     *      ki=0x01ca = ver|pairwise|install|ack|mic), hostap принимает
     *      M3 по ACK|MIC|pairwise; GTK в M3 НЕ передаётся — M4 и
     *      групповое рукопожатие (как wpa_supplicant_process_3_of_4_wpa). */
    if (wc.fw_phase >= 1 && wc.fw_phase <= 2 && pairwise &&
        (ki & WPA2_KI_ACK) && (ki & WPA2_KI_MIC) && ver_ok &&
        (is_wpa || ((ki & WPA2_KI_SECURE) && (ki & WPA2_KI_ENCR_DATA)))) {
        /* СЕССИЯ 51: БЫСТРЫЙ ПУТЬ — ретранслированный M3 после
         * завершённого рукопожатия (тот же replay + тот же ANonce):
         * тихо отвечаем кэшированным M4, НЕ переустанавливая ключи.
         * Прежний путь на каждый повтор M3 переписывал CAM и сыпал
         * логами; переустановка ещё и сбросила бы PN-счётчики —
         * точка считала бы наши data-кадры replay. Новый 4-way rekey
         * (другой ANonce) сюда не попадает — уйдёт в обычный путь. */
        if (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed &&
            memcmp(k.replay, wc.replay, 8) == 0 &&
            memcmp(k.nonce, wc.anonce, 32) == 0) {
            u32 n4 = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                             k.desc_type,
                                             (u16)(kv | WPA2_KI_KEY_TYPE |
                                                   WPA2_KI_MIC |
                                                   (ki & WPA2_KI_SECURE)),
                                             0, NULL, wc.replay, NULL, 0);
            if (k.ver) eb[14] = k.ver;
            u8 mic4[16];
            wpa2_eapol_mic2(kv, wc.ptk, eb, n4, mic4);
            wpa2_eapol_set_mic(eb, mic4);
            wpa2_tx_eapol_eth(eb, n4);
            WLOGV("M3 повтор после завершения — M4 перепослан");
            return;
        }
        /* СЕССИЯ 44: точка ИНКРЕМЕНТИРУЕТ replay counter между M1 и M3
         * (M1 = R, M3 = R+1). Прежнее точное равенство с M1 отбрасывало
         * КАЖДЫЙ M3 от настоящей точки. Правило: принимаем M3 с счётчиком
         * НЕ СТАРШЕ последнего увиденного, и отвечаем M4 счётчиком M3. */
        if (memcmp(k.replay, wc.replay, 8) < 0) {
            wifi_log("WPA2: M3 со старым replay counter — игнор");
            return;
        }
        memcpy(wc.replay, k.replay, 8);       /* M4 отвечает счётчиком M3 */
        if (memcmp(k.nonce, wc.anonce, 32) != 0) {
            wifi_log("WPA2: ANonce в M3 != M1 — игнор");
            return;
        }
        static u8 micbuf[WIFI_NET_RXSZ];
        u32 flen = k.frame_len;
        if (flen > sizeof(micbuf)) return;
        memcpy(micbuf, eb, flen);
        memset(micbuf + 95, 0, 16);           /* MIC := 0 (смещ. в кадре) */
        u8 mic[16];
        wpa2_eapol_mic2(kv, wc.ptk, micbuf, flen, mic);
        if (!wpa2_ct_equal(mic, k.mic, 16)) {
            wifi_log("WPA2: MIC M3 неверный — пароль не подходит?");
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "WPA2: неверный MIC (пароль?)");
            wc.conn = WIFI_CONN_FAILED;
            tx_deauth();
            return;
        }

        /* СЕССИЯ 47: некоторые точки доставляют GTK прямо в M3 (KDE
         * 00:50:F2:01 / 00:0F:AC:01) — тогда группового рукопожатия НЕ
         * будет вовсе. Сканируем key data (с расшифровкой при ENCR_DATA);
         * hex-дамп первых 20 байт — чтобы увидеть содержимое (у этой
         * точки kd=28 б: WPA IE или GTK?). */
        int m3_gtk = 0;
        if (is_wpa && k.key_data_len) {
            const u8 *kdp = k.key_data;
            u32 kdn = k.key_data_len;
            static u8 kdd[WIFI_NET_RXSZ];
            if ((ki & WPA2_KI_ENCR_DATA) && k.key_data_len >= 16 &&
                !(k.key_data_len & 7) && k.key_data_len <= sizeof(kdd) &&
                wpa2_aes_unwrap(wc.ptk + 16, k.key_data,
                                k.key_data_len, kdd)) {
                kdp = kdd; kdn = k.key_data_len - 8;
            }
            {   char hx[64]; u32 p = 0;
                for (u32 i = 0; i < kdn && i < 20 && p + 4 < sizeof(hx); i++)
                    p += (u32)snprintf(hx + p, sizeof(hx) - p,
                                       "%02x ", kdp[i]);
                hx[p] = 0;
                wifi_log("[wpa2] M3 kd(%u): %s", (unsigned)kdn, hx);
            }
            /* СЕССИЯ 49: захват WPA IE ТОЧКИ (element DD, OUI 00:50:F2:01,
             * version=1 после OUI — отличаем от GTK KDE, у него там
             * keyid=0..3). Некоторые точки сверяют IE в M2 с СОБСТВЕННЫМ
             * (а не с assoc-IE как hostapd) — наш IE с одной парой не
             * совпадает с её {TKIP,CCMP} → M2 молча отброшен, M3 шлётся
             * всё равно (PTK из нашего SNonce), а M4 игнорируется — точка
             * всё ещё ждёт валидный M2. */
            u32 apie_off = (u32)-1;
            if (!wc.m2_apie_sent && !wc.ap_wpa_ie_len) {
                u32 off = 0;
                while (off + 2 <= kdn) {
                    u8 t = kdp[off], l = kdp[off + 1];
                    if (t == 0xDD && l >= 24 &&
                        off + 2 + (u32)l <= kdn &&
                        memcmp(kdp + off + 2, "\x00\x50\xF2\x01", 4) == 0 &&
                        kdp[off + 6] == 0x01 && kdp[off + 7] == 0x00 &&
                        kdp[off + 8] == 0x00 &&
                        l + 2 <= sizeof(wc.ap_wpa_ie)) {
                        wc.ap_wpa_ie[0] = 0xDD;
                        wc.ap_wpa_ie[1] = l;
                        memcpy(wc.ap_wpa_ie + 2, kdp + off + 2, l);
                        wc.ap_wpa_ie_len = (u8)(l + 2);
                        apie_off = off;
                        break;
                    }
                    if (t == 0xDD && l == 0) { off += 2; continue; }
                    if (l == 0 && t == 0) break;
                    off += 2u + l;
                }
            }
            u32 off = 0;
            while (off + 6 <= kdn) {
                if (off == apie_off) {           /* это WPA IE, не GTK KDE */
                    off += 2u + kdp[off + 1];
                    continue;
                }
                u8 t = kdp[off], l = kdp[off + 1];
                if (t == 0xDD && l >= 6 && off + 2 + (u32)l <= kdn &&
                    (memcmp(kdp + off + 2, "\x00\x50\xF2\x01", 4) == 0 ||
                     memcmp(kdp + off + 2, "\x00\x0F\xAC\x01", 4) == 0)) {
                    /* GTK: 2-байтный заголовок (keyid+reserved, как в
                     * hostap); запасной 1-байтный (старый WPA-стиль) */
                    u32 k2 = (u32)l - 6, k1 = (u32)l - 5;
                    u32 klen = 0, hdr = 0;
                    if (k2 == 16 || k2 == 32) { klen = k2; hdr = 2; }
                    else if (k1 == 16 || k1 == 32) { klen = k1; hdr = 1; }
                    if (klen) {
                        memcpy(wc.gtk, kdp + off + 6 + hdr, klen);
                        if (klen > 16) memset(wc.gtk + klen, 0, 32 - klen);
                        wc.gtk_is_tkip = (klen == 32);
                        wc.gtk_keyid = kdp[off + 6] & 3;
                        m3_gtk = 1;
                    }
                }
                if (t == 0xDD && l == 0) { off += 2; continue; }
                if (l == 0 && t == 0) break;
                off += 2u + l;
            }
        }

        if (is_wpa && wc.ap_wpa_ie_len && !wc.m2_apie_sent) {
            /* повторный M2: эхо WPA IE ТОЧКИ (hostapd такой M2 безболезненно
             * роняет по состоянию; точка-одиночка — принимает) */
            u8 kd2[40];
            memcpy(kd2, wc.ap_wpa_ie, wc.ap_wpa_ie_len);
            u32 n2 = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                             k.desc_type,
                                             (u16)(kv | WPA2_KI_KEY_TYPE |
                                                   WPA2_KI_MIC),
                                             k.key_len, wc.snonce,
                                             wc.replay_m1, kd2,
                                             (u16)wc.ap_wpa_ie_len);
            if (k.ver) eb[14] = k.ver;
            u8 mic2b[16];
            wpa2_eapol_mic2(kv, wc.ptk, eb, n2, mic2b);
            wpa2_eapol_set_mic(eb, mic2b);
            wpa2_tx_eapol_eth(eb, n2);
            wc.m2_apie_sent = 1;
            wifi_log("повтор M2 с WPA IE точки (%u б) — ждём её M3",
                     (unsigned)wc.ap_wpa_ie_len);
        }
        if (is_wpa) {
            /* WPA: GTK обычно в групповом M1 — сейчас только M4:
             * Secure-бит эхом из M3, replay = M3 (wc.replay — НЕ k.replay:
             * сборщик очищает eb, куда указывает k.replay!), Key Length
             * = эхо. Ключи ставим после группового M1 (или сразу, если
             * GTK был в M3). */
            u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                            k.desc_type,
                                            (u16)(kv | WPA2_KI_KEY_TYPE |
                                                  WPA2_KI_MIC |
                                                  (ki & WPA2_KI_SECURE)),
                                            k.key_len, NULL, wc.replay,
                                            NULL, 0);
            if (k.ver) eb[14] = k.ver;   /* эхо EAPOL-версии точки */
            wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
            wpa2_eapol_set_mic(eb, mic);
            if (!wpa2_tx_eapol_eth(eb, n)) {
                wifi_log("M4 не отправлен — переповтор");
                return;
            }
            wifi_log("TX M4: desc=%u ki=0x%04x klen=%u",
                     k.desc_type,
                     (u16)(kv | WPA2_KI_KEY_TYPE | WPA2_KI_MIC |
                           (ki & WPA2_KI_SECURE)),
                     k.key_len);
            if (m3_gtk) {
                /* СЕССИЯ 47: GTK пришёл прямо в M3 — группового M1 не
                 * будет: ставим ключи и завершаем */
                wc.fw_phase = 0;
                wpa2_install_keys();
                wc.conn = WIFI_CONN_CONNECTED;
                wc.beacon_last = timer_ticks();
                wifi_log("WPA: рукопожатие завершено (GTK из M3) — \"%s\" доступна",
                         wc.conn_ssid);
                wifi_profile_save(wc.conn_ssid);
            } else {
                wc.fw_phase = 2;             /* ждём групповой M1 */
                wc.fw_timer = timer_ticks();
                wifi_log("WPA: M3 ok, M4 отправлен — ждём групповой ключ (GTK)");
            }
            return;
        }

        u8 kd[WIFI_NET_RXSZ];
        if (k.key_data_len > sizeof(kd) || (k.key_data_len & 7) ||
            k.key_data_len < 16) {
            wifi_log("WPA2: key data повреждён (len=%u)", k.key_data_len);
            return;
        }
        if (!wpa2_aes_unwrap(wc.ptk + 16, k.key_data, k.key_data_len, kd)) {
            wifi_log("WPA2: unwrap key data не прошёл");
            return;
        }
        u32 kdn = k.key_data_len - 8;
        int have_gtk = 0;
        u32 off = 0;
        while (off + 2 <= kdn) {
            u8 t = kd[off], l = kd[off + 1];
            if (t == 0xDD && l >= 8 && off + 2 + 8 <= kdn &&
                memcmp(kd + off + 2, "\x00\x0F\xAC\x01", 4) == 0) {
                /* СЕССИЯ 51 (исправление off-by-one): GTK KDE по hostap:
                 * [OUI 4][keyid/tx 1][reserved 1][GTK]. Раньше GTK
                 * копировался с off+7 — на байт СДВИНУТ: ключи
                 * получались мусорные, бродкаст-путь (DHCP!) не работал. */
                u8 flags = kd[off + 6];
                u32 klen = (u32)l - 6;
                if (klen > 32) klen = 32;
                if (klen < 16) klen = 16;
                if (off + 2 + 6 + klen <= kdn) {
                    memcpy(wc.gtk, kd + off + 8, klen);
                    if (klen > 16) memset(wc.gtk + klen, 0, 32 - klen);
                    wc.gtk_is_tkip = (klen == 32);
                    wc.gtk_keyid = flags & 3;
                    have_gtk = 1;
                }
            }
            if (t == 0xDD && l == 0) { off += 2; continue; }   /* паддинг */
            if (l == 0 && t == 0) break;
            off += 2u + l;
        }
        if (!have_gtk) {
            wifi_log("WPA2: GTK KDE не найден в key data");
            return;
        }

        wpa2_install_keys();
        u32 n = wpa2_build_eapol_key_ex(eb, wc.conn_bssid, wc.mac,
                                        2,
                                        (u16)(kv | WPA2_KI_KEY_TYPE |
                                              WPA2_KI_MIC | WPA2_KI_SECURE),
                                        0, NULL, wc.replay, NULL, 0);
        if (k.ver) eb[14] = k.ver;           /* эхо EAPOL-версии точки */
        wpa2_eapol_mic2(kv, wc.ptk, eb, n, mic);
        wpa2_eapol_set_mic(eb, mic);
        if (!wpa2_tx_eapol_eth(eb, n)) {
            wifi_log("M4 не отправлен — переповтор");
            return;
        }
        wifi_log("TX M4: desc=2 ki=0x%04x klen=0 kd=0 — ждём data-канал",
                 (u16)(kv | WPA2_KI_KEY_TYPE | WPA2_KI_MIC | WPA2_KI_SECURE));
        wc.conn = WIFI_CONN_CONNECTED;
        /* fw_phase оставляем 1: ретранслированные M3 попадут в
         * быстрый путь (тихий ресенд M4) выше, а новый 4-way rekey
         * примет ветка M1 ниже (она допускает CONNECTED). */
        wc.beacon_last = timer_ticks();
        wc.data_stat_timer = timer_ticks();
        wc.data_tx = 0; wc.data_rx = 0; wc.data_rx_uc = 0;   /* сессия 52 */
        wc.data_tx_uc = 0;                                   /* сессия 53 */
        wifi_log("WPA2: рукопожатие завершено — \"%s\" доступна (CCMP)",
                 wc.conn_ssid);
        wifi_profile_save(wc.conn_ssid);
        return;
    }
}

/* ================= машина подключения ================= */

/* СЕССИЯ 32: ротация BSSID — одноимённый SSID бывает на нескольких
 * точках («byfly WiFi» в логе пользователя — на 6!), и если одна
 * стабильно отказывает — следующая попытка подключения берёт другую. */
static int conn_bssid_tried(const wifi_ap_t *ap) {
    if (wc.tried_n <= 0) return 0;
    if (strcmp(wc.tried_ssid, wc.conn_ssid) != 0) return 0;
    for (int k = 0; k < wc.tried_n && k < 4; k++)
        if (memcmp(wc.tried_bssid[k], ap->bssid, 6) == 0) return 1;
    return 0;
}

static void conn_remember_tried(const wifi_ap_t *ap) {
    if (strcmp(wc.tried_ssid, wc.conn_ssid) != 0) {
        strncpy(wc.tried_ssid, wc.conn_ssid, sizeof(wc.tried_ssid) - 1);
        wc.tried_ssid[sizeof(wc.tried_ssid) - 1] = 0;
        wc.tried_n = 0;
    }
    if (conn_bssid_tried(ap)) return;
    int slot = wc.tried_n < 4 ? wc.tried_n : (wc.tried_n % 4);  /* кольцо */
    memcpy(wc.tried_bssid[slot], ap->bssid, 6);
    wc.tried_n++;
}

static void conn_handle_mgmt(const u8 *frame, u32 len) {
    u16 fc = (u16)(frame[0] | (frame[1] << 8));
    u8 type = (u8)((fc >> 2) & 0x3);
    u8 subtype = (u8)((fc >> 4) & 0xF);
    if (type != 0) return;                    /* только management */
    if (len < 26) return;
    /* кадры нашей точки */
    if (memcmp(frame + 16, wc.conn_bssid, 6) != 0 &&
        memcmp(frame + 10, wc.conn_bssid, 6) != 0)
        return;

    if (subtype == 11 && len >= 30) {         /* Authentication */
        if (wc.conn != WIFI_CONN_AUTH) return;
        u16 algo = (u16)(frame[24] | (frame[25] << 8));
        u16 seq  = (u16)(frame[26] | (frame[27] << 8));
        u16 st   = (u16)(frame[28] | (frame[29] << 8));
        if (algo == 0 && seq == 2 && st == 0) {
            /* СЕССИЯ 38: скан обязан молчать с этого момента — радио
             * закреплено на канале точки до конца ассоциации */
            wc.scanning = 0;
            wc.assoc_rate_alt = 0;
            wifi_log("AUTH ok — посылаем ASSOC REQ");
            wc.conn = WIFI_CONN_ASSOC;
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            tx_assoc_req(wc.conn_ssid);
        } else {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "AUTH отклонён (status=%u)", (unsigned)st);
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
        }
    } else if (subtype == 1 && len >= 30) {   /* Association Response */
        if (wc.conn != WIFI_CONN_ASSOC) return;
        u16 st  = (u16)(frame[26] | (frame[27] << 8));
        u16 aid = (u16)(frame[28] | (frame[29] << 8));
        if (st == 0) {
            wc.conn_aid = aid & 0x3FFF;
            wc.beacon_last = timer_ticks();
            /* СЕССИЯ 51: RSN IE точки из assoc-resp — эталон для эха в M2
             * (Ralink сверяет IE в M2 с собственным побайтно). Assoc resp:
                 * cap@24 status@26 AID@28, IEs с 30. */
            {
                u32 ie_off = 30, ie_len = len - 30;
                u32 io = 0;
                wc.ap_rsn_ie_len = 0;
                while (io + 2 <= ie_len) {
                    u8 t = frame[ie_off + io], l = frame[ie_off + io + 1];
                    /* СЕССИЯ 51: копируем ЦЕЛЫЙ элемент (30 18 + тело) —
                     * в key data M2 IE идёт как полный элемент */
                    if (t == 48 && l >= 20 && l <= 38 &&
                        io + 2 + l <= ie_len && 2u + l <= sizeof(wc.ap_rsn_ie)) {
                        memcpy(wc.ap_rsn_ie, frame + ie_off + io, 2u + l);
                        wc.ap_rsn_ie_len = (u8)(2u + l);
                        wifi_log("точка: RSN IE в assoc-resp (%u б) — эхо в M2 готово",
                                 (unsigned)(2u + l));
                        break;
                    }
                    if (l == 0 && t == 0) break;
                    io += 2u + l;
                }
            }
            if (wc.conn_retries > 0) wc.conn_retries--;  /* точка нас приняла — смягчаем счётчик */
            /* RX-фильтр: только наша BSS + bcast/mcast + маяки */
            wc.ops->rx_filter_bss();
            if (wc.sec == WIFI_SEC_WPA2_PSK) {
                wc.conn = WIFI_CONN_4WAY;
                wc.fw_phase = 0;
                wc.fw_attempts = 0;
                wc.fourway_data = 0;
                wc.fw_timer = timer_ticks();
                wifi_log("ASSOC ok: \"%s\" AID=%u (ch %d) — WPA2: ждём ключи",
                         wc.conn_ssid, (unsigned)wc.conn_aid,
                         wc.conn_channel + 1);
            } else {
                wc.conn = WIFI_CONN_CONNECTED;
                wifi_log("ASSOC ok: \"%s\" AID=%u (ch %d) — сеть доступна",
                         wc.conn_ssid, (unsigned)wc.conn_aid,
                         wc.conn_channel + 1);
                wifi_profile_save(wc.conn_ssid);
            }
        } else if (st == 18 && !wc.assoc_rate_alt) {
            /* СЕССИЯ 38: status 18 = «STA не поддерживает все
             * BSSBasicRateSet». Объединённый набор уже покрывал рейты
             * точки — вторая попытка с классическим набором b/g
             * (basic 1/2/5.5/11), как у самого обычного клиента. */
            wc.assoc_rate_alt = 1;
            wifi_log("ASSOC отклонён (status=18, рейты) — повтор с полным набором b/g");
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            tx_assoc_req(wc.conn_ssid);
        } else if (st == 18) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "ASSOC отклонён (status=18, рейты/BSS)");
            wifi_log("%s", wc.conn_fail_reason);
            wifi_log("  если точка не принимает: фильтр MAC у точки / 11n-only / PMF");
            wifi_log("  MAC адаптера: %02x:%02x:%02x:%02x:%02x:%02x",
                     wc.mac[0], wc.mac[1], wc.mac[2],
                     wc.mac[3], wc.mac[4], wc.mac[5]);
            wc.conn = WIFI_CONN_FAILED;
        } else if (wc.conn_wpa && wc.assoc_rsn_only &&
                   !wc.assoc_fallback_tried) {
            /* СЕССИЯ 50: точка не взяла RSN-only ассоциацию — повторяем
             * с обоими IE (как раньше) */
            wc.assoc_fallback_tried = 1;
            wc.assoc_variant = 2;
            wc.assoc_rsn_only = 0;
            wc.pairwise_tkip = 0;
            wifi_log("ASSOC отклонён (status=%u) без WPA IE — повтор с обоими IE",
                     (unsigned)st);
            wc.conn_attempts = 0;
            wc.conn_timer = timer_ticks();
            tx_assoc_req(wc.conn_ssid);
        } else {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "ASSOC отклонён (status=%u)", (unsigned)st);
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
        }
    } else if (subtype == 12 && len >= 26) {  /* Deauthentication */
        if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_ASSOC ||
            wc.conn == WIFI_CONN_AUTH || wc.conn == WIFI_CONN_4WAY) {
            u16 reason = (u16)(frame[24] | (frame[25] << 8));
            wc.conn_retries++;
            if (wc.conn_retries > CONN_MAX_DEAUTH) {
                /* СЕССИЯ 32 (анти-шторм): точка стабильно отшивает —
                 * СТОП. Раньше цикл скан→AUTH→DEAUTH крутился вечно,
                 * выжигая CPU на полных сканах и EHCI-поллинге. */
                snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                         "точка отшивает (DEAUTH reason=%u)", (unsigned)reason);
                wifi_log("%s", wc.conn_fail_reason);
                wc.conn = WIFI_CONN_FAILED;
                wc.ops->rx_filter_promisc();
            } else if (wc.conn_retries <= CONN_FAST_RETRIES) {
                /* быстрая переподключалка к ТОЙ ЖЕ точке: канал уже
                 * настроен, полный скан (3 с) не нужен */
                wifi_log("точка послала DEAUTH (reason=%u) — переподключение",
                         (unsigned)reason);
                wc.conn = WIFI_CONN_AUTH;
                wc.conn_attempts = 1;
                wc.conn_timer = timer_ticks();
                tx_auth_req();
            } else {
                /* быстрые попытки кончились — рескан (другая BSSID
                 * того же SSID может принять) */
                wifi_log("точка послала DEAUTH (reason=%u) — рескан",
                         (unsigned)reason);
                wc.ops->rx_filter_promisc();
                wifi_scan_start();
                /* СЕССИЯ 38: conn=SCAN ПОСЛЕ старта скана — иначе в окне
                 * между ними conn_step(SCAN) успеет начать AUTH, и скан
                 * начнёт прыгать по каналам поверх ассоциации */
                wc.conn = WIFI_CONN_SCAN;
                wc.conn_scans = 0;
                wc.conn_attempts = 0;
            }
        }
    } else if (subtype == 10 && len >= 26) {  /* Disassociation */
        if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_ASSOC) {
            wc.conn_retries++;
            if (wc.conn_retries > CONN_MAX_DEAUTH) {
                snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                         "точка отвязывает (DISASSOC)");
                wifi_log("%s", wc.conn_fail_reason);
                wc.conn = WIFI_CONN_FAILED;
                wc.ops->rx_filter_promisc();
            } else {
                wifi_log("DISASSOC от точки — переподключение к той же");
                wc.conn = WIFI_CONN_AUTH;
                wc.conn_attempts = 1;
                wc.conn_timer = timer_ticks();
                tx_auth_req();
            }
        }
    }
}

/* ---- шаг машины подключения (вызывается из wifi_poll) ---- */
static void conn_step(void) {
    switch (wc.conn) {
    case WIFI_CONN_SCAN:
        /* скан завершён? — ищем сеть */
        if (wc.scanning) return;
        {
            /* сильнейшая точка с нужным SSID. Открытая — без пароля;
             * ЗАЩИЩЕННАЯ ЛЮБОГО ТИПА — с паролем (пробуем как WPA2-PSK).
             * СЕССИЯ 32: непробованные BSSID приоритетнее (ротация). */
            int best = -1, best_fresh = -1;
            for (int i = 0; i < wc.ap_count; i++) {
                if (strcmp(wc.aps[i].ssid, wc.conn_ssid) != 0) continue;
                u8 sec = wc.aps[i].sec;
                if (sec == WIFI_SEC_OPEN && wc.psk[0]) continue;
                if (sec != WIFI_SEC_OPEN && !wc.psk[0]) continue;
                if (best < 0 || wc.aps[i].rssi > wc.aps[best].rssi)
                    best = i;
                if (!conn_bssid_tried(&wc.aps[i]) &&
                    (best_fresh < 0 || wc.aps[i].rssi > wc.aps[best_fresh].rssi))
                    best_fresh = i;
            }
            if (best_fresh >= 0) best = best_fresh;
            if (best < 0) {
                int enc = -1;
                for (int i = 0; i < wc.ap_count; i++)
                    if (strcmp(wc.aps[i].ssid, wc.conn_ssid) == 0) { enc = i; break; }
                if (enc >= 0) {
                    const char *why = wc.psk[0]
                        ? "открытая сеть — пароль не нужен"
                        : "нужен пароль (WPA2/WPA)";
                    snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                             "\"%s\": %s", wc.conn_ssid, why);
                    wifi_log("%s", wc.conn_fail_reason);
                    wc.conn = WIFI_CONN_FAILED;
                    return;
                }
                wc.conn_scans++;
                if (wc.conn_scans >= CONN_SCAN_TRIES) {
                    snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                             "сеть \"%s\" не найдена", wc.conn_ssid);
                    wifi_log("%s", wc.conn_fail_reason);
                    wc.conn = WIFI_CONN_FAILED;
                    return;
                }
                wifi_log("скан %d: сети нет — повтор", wc.conn_scans);
                wifi_scan_start();
                return;
            }
            /* нашли: тип защиты точки + настройка канала и BSSID */
            wc.sec = wc.psk[0] ? WIFI_SEC_WPA2_PSK : wc.aps[best].sec;
            wc.ap_group_tkip = wc.aps[best].group_tkip;
            /* СЕССИЯ 43: HT/WPA/PMF профиля точки */
            wc.conn_ht  = wc.aps[best].ht;
            wc.conn_wpa = wc.aps[best].wpa;
            wc.conn_pmf = wc.aps[best].pmf;
            memcpy(wc.conn_bssid, wc.aps[best].bssid, 6);
            wc.conn_channel = wc.aps[best].channel - 1;
            if (wc.conn_channel < 0 || wc.conn_channel >= WC_NUM_CHANNELS)
                wc.conn_channel = 0;
            wc.conn_rssi = wc.aps[best].rssi;
            /* СЕССИЯ 32: рейты/capability точки — для ASSOC REQ */
            wc.conn_capab = wc.aps[best].capability;
            wc.conn_rates_len = wc.aps[best].rates_len;
            memcpy(wc.conn_rates, wc.aps[best].rates, wc.conn_rates_len);
            /* СЕССИЯ 38: скан остановлен до AUTH — каналы не перекидываются,
             * радио остаётся на канале точки до конца ассоциации */
            wc.scanning = 0;
            wc.assoc_rate_alt = 0;
            conn_remember_tried(&wc.aps[best]);
            wifi_log("точка найдена: %02x:%02x:%02x:%02x:%02x:%02x ch %d (%d dBm)"
                     " — AUTH",
                     wc.conn_bssid[0], wc.conn_bssid[1], wc.conn_bssid[2],
                     wc.conn_bssid[3], wc.conn_bssid[4], wc.conn_bssid[5],
                     wc.conn_channel + 1, wc.conn_rssi);
            if (wc.sec == WIFI_SEC_WPA2_PSK)
                wifi_log("точка: группа %s%s%s%s, рейтов %u",
                         wc.ap_group_tkip ? "TKIP" : "CCMP",
                         wc.conn_ht  ? ", HT(11n)" : "",
                         wc.conn_wpa ? ", +WPA(смешанный)" : "",
                         wc.conn_pmf ? ", PMF обязателен!" : "",
                         (unsigned)wc.conn_rates_len);
            if (!wc.ops->set_channel(wc.conn_channel)) {
                wifi_log("смена канала не удалась — полный init");
                wc.ops->full_reset();
            }
            wc.ops->rx_filter_bss();          /* фильтр на время ассоциации */
            wc.conn = WIFI_CONN_AUTH;
            wc.conn_attempts = 1;
            wc.conn_timer = timer_ticks();
            if (!tx_auth_req()) {
                wifi_log("AUTH не отправлен (TX отказ)");
                wc.conn = WIFI_CONN_FAILED;
            }
        }
        break;

    case WIFI_CONN_AUTH:
    case WIFI_CONN_ASSOC:
        if ((int)(timer_ticks() - wc.conn_timer) < CONN_AUTH_TO) return;
        if (wc.conn_attempts >= CONN_MAX_ATTEMPTS) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "%s: нет ответа точки",
                     wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC");
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
            return;
        }
        wc.conn_attempts++;
        wc.conn_timer = timer_ticks();
        wifi_log("таймаут — повтор %d (%s)", wc.conn_attempts,
                 wc.conn == WIFI_CONN_AUTH ? "AUTH" : "ASSOC");
        if (wc.conn == WIFI_CONN_AUTH) tx_auth_req();
        else                           tx_assoc_req(wc.conn_ssid);
        break;

    case WIFI_CONN_4WAY:
        if ((int)(timer_ticks() - wc.fw_timer) < CONN_4WAY_TO) return;
        wc.fw_attempts++;
        if (wc.fw_attempts >= CONN_MAX_4WAY) {
            snprintf(wc.conn_fail_reason, sizeof(wc.conn_fail_reason),
                     "WPA2: рукопожатие не завершено");
            wifi_log("%s", wc.conn_fail_reason);
            wc.conn = WIFI_CONN_FAILED;
            return;
        }
        int was_phase = wc.fw_phase;
        wc.fw_phase = 0;
        wc.fw_timer = timer_ticks();
        /* СЕССИЯ 48: чередуем pairwise в WPA IE — у старых WPA-точек
         * путь «WPA+CCMP-пара» бывает непроверен, TKIP-пара — родной */
        wc.assoc_variant = (u8)((wc.assoc_variant + 1) & 3);
        wc.pairwise_tkip   = (int)(wc.assoc_variant & 1);
        wc.assoc_rsn_only  = (int)(wc.assoc_variant < 2);
        wifi_log("следующая попытка: assoc %s, пара %s",
                 wc.assoc_rsn_only ? "RSN-only" : "RSN+WPA",
                 wc.pairwise_tkip ? "TKIP" : "CCMP");
        wifi_log("RX-статистика: кадров=%u crc=%u прочих=%u",
                 (unsigned)wc.stats.frames, (unsigned)wc.stats.crc_err,
                 (unsigned)wc.stats.other);
        /* СЕССИЯ 44: счётчик data-кадров за окно 4WAY отличает «эфир глухой,
         * M1 не доходил» (0) от «кадры идут, но EAPOL нет/отвергнут» (>0) */
        if (was_phase == 2)
            wifi_log("WPA: групповой ключ не пришёл (data от точки: %u) — "
                     "повтор ассоциации (%d)",
                     (unsigned)wc.fourway_data, wc.fw_attempts);
        else
            wifi_log("WPA2: нет сообщений EAPOL (data от точки: %u) — "
                     "повтор ассоциации (%d)",
                     (unsigned)wc.fourway_data, wc.fw_attempts);
        wc.conn = WIFI_CONN_ASSOC;
        wc.conn_attempts = 1;
        wc.conn_timer = timer_ticks();
        tx_assoc_req(wc.conn_ssid);
        break;

    case WIFI_CONN_CONNECTED:
        /* Сессия 53: диагностика data-канала раз в 10 с, только при
         * РЕАЛЬНОЙ проблеме. Старый критерий (RXuc==0 при RX>0 или
         * data_tx==0) срабатывал ложно: во время DHCP весь трафик
         * бродкастный — юникаста легитимно нет; в простой сети точка
         * тоже не обязана слать data-кадры. Проблема — только когда
         * мы сами отправляли ЮНИКАСТ (TCP SYN и т.п.), а назад не
         * пришло ни одного юникаста: точка не приняла наш кадр
         * (ключ/порт) — классика «M4 не принят». */
        if (wc.data_stat_timer &&
            (u32)(timer_ticks() - wc.data_stat_timer) > 10000) {
            wc.data_stat_timer = timer_ticks();
            if (wc.data_tx_uc > 0 && wc.data_rx_uc == 0)
                wifi_log("data-канал: TX=%u (unicast %u) RX=%u RXuc=%u — "
                         "наши юникасты не возвращаются",
                         (unsigned)wc.data_tx, (unsigned)wc.data_tx_uc,
                         (unsigned)wc.data_rx, (unsigned)wc.data_rx_uc);
        }
        /* контроль потери связи: нет маяков давно → рескан */
        if ((int)(timer_ticks() - wc.beacon_last) < CONN_BEACON_LOST) return;
        wifi_log("маяки пропали >6 с — переподключение к \"%s\"", wc.conn_ssid);
        wc.ops->rx_filter_promisc();
        wifi_scan_start();
        /* СЕССИЯ 38: conn=SCAN ПОСЛЕ старта скана (гонка скан↔AUTH) */
        wc.conn = WIFI_CONN_SCAN;
        wc.conn_scans = 0;
        wc.conn_attempts = 0;
        break;

    default:
        break;
    }
}

/* ================= публичный API подключения ================= */

int wifi_connect_psk(const char *ssid, const char *psk) {
    if (!wc.present || !wc.ready || !wc.ops) return 0;
    if (!ssid || !ssid[0]) return 0;
    u32 L = (u32)strlen(ssid);
    if (L > 32) return 0;

    if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_AUTH ||
        wc.conn == WIFI_CONN_ASSOC || wc.conn == WIFI_CONN_4WAY)
        wifi_disconnect();

    strncpy(wc.conn_ssid, ssid, 32);
    wc.conn_ssid[32] = 0;
    wc.sec = 0;                 /* уточним по маяку при скане */
    wc.psk[0] = 0;
    if (psk && psk[0]) {
        if (strlen(psk) < 8) {
            wifi_log("WPA2: пароль короче 8 символов");
            return 0;
        }
        strncpy(wc.psk, psk, sizeof(wc.psk) - 1);
        wc.psk[sizeof(wc.psk) - 1] = 0;
        wc.sec = WIFI_SEC_WPA2_PSK;   /* попытаемся как WPA2 */
    }
    wc.conn_scans = 0;
    wc.conn_attempts = 0;
    wc.conn_fail_reason[0] = 0;
    wc.conn_retries = 0;      /* сессия подключения новая — счётчик DEAUTH с нуля */
    wc.pairwise_tkip = 0;     /* новая сессия — начинаем с CCMP-пары */
    wc.assoc_variant = 0;     /* и с RSN-only ассоциации (СЕССИЯ 50) */
    wc.assoc_rsn_only = 1;
    wc.assoc_rate_alt = 0;
    wc.netrx_head = wc.netrx_tail = 0;
    /* СЕССИЯ 32: свежий скан (< 15 с) уже видел эту сеть — НЕ гоняем
     * полный скан (~1.5 с при dwell 110 мс) на каждую попытку подключения:
     * клик по сети из списка должен сразу AUTH-ить по готовым данным. */
    int have_cached = 0;
    if (!wc.scanning && wc.ap_count > 0 && wc.last_scan_end != 0 &&
        (u32)(timer_ticks() - wc.last_scan_end) < 15000) {
        for (int i = 0; i < wc.ap_count; i++) {
            if (strcmp(wc.aps[i].ssid, wc.conn_ssid) != 0) continue;
            u8 s = wc.aps[i].sec;
            if (s == WIFI_SEC_OPEN && wc.psk[0]) continue;
            if (s != WIFI_SEC_OPEN && !wc.psk[0]) continue;
            have_cached = 1;
            break;
        }
    }
    /* СЕССИЯ 38 (гонка скан↔подключение): conn=SCAN ставится ПОСЛЕДНИМ.
     * Раньше между «conn=SCAN» и «wifi_scan_start()» планировщик мог
     * переключиться на wifi_poll: conn_step(SCAN) при scanning==0
     * немедленно выбирал точку и посылал AUTH — а затем стартовал скан,
     * который ПЕРЕСКАКИВАЛ каналы 1-14 поверх ассоциации. Радио оказывалось
     * на чужом канале: ответы точки не слышны («AUTH ok» наудачу →
     * «ASSOC: нет ответа точки»). */
    if (have_cached) {
        wifi_log("подключение к \"%s\"%s: сеть в свежем скане — AUTH сразу",
                 wc.conn_ssid, wc.psk[0] ? " (WPA2)" : "");
        /* scanning=0 — conn_step(SCAN) сам выберет точку и отправит AUTH */
        wc.conn = WIFI_CONN_SCAN;
        return 1;
    }
    wifi_log("подключение к \"%s\"%s: скан...", wc.conn_ssid,
             wc.psk[0] ? " (WPA2)" : "");
    if (!wc.scanning)
        wifi_scan_start();
    else
        wc.conn_scans = 1;      /* скан уже идёт — учтём текущий проход */
    wc.conn = WIFI_CONN_SCAN;
    return 1;
}

int wifi_connect(const char *ssid) {
    /* если в профиле есть пароль — подключаемся с ним */
    char psk[65];
    if (wifi_profile_load_psk(psk, sizeof(psk)))
        return wifi_connect_psk(ssid, psk);
    return wifi_connect_psk(ssid, NULL);
}

int wifi_conn_secured(void)
{
    return (wc.conn == WIFI_CONN_CONNECTED && wc.keys_installed) ? 1 : 0;
}

void wifi_disconnect(void) {
    if (!wc.ops) return;
    if (wc.conn == WIFI_CONN_CONNECTED || wc.conn == WIFI_CONN_4WAY)
        tx_deauth();
    if (wc.conn != WIFI_CONN_OFF) {
        wc.conn = WIFI_CONN_OFF;
        wc.conn_ssid[0] = 0;
        wpa2_clear_keys();          /* ключи железа больше не валидны */
        wc.ops->rx_filter_promisc();
        wifi_log("отключено");
    }
}

wifi_conn_state_t wifi_conn_state(void) { return wc.conn; }
const char *wifi_conn_ssid(void) { return wc.conn_ssid; }
int  wifi_conn_rssi(void)   { return wc.conn_rssi; }
int  wifi_conn_channel(void) { return wc.conn_channel + 1; }

const char *wifi_conn_state_name(void) {
    switch (wc.conn) {
        case WIFI_CONN_OFF:       return "не подключаемся";
        case WIFI_CONN_SCAN:      return "поиск сети";
        case WIFI_CONN_AUTH:      return "аутентификация";
        case WIFI_CONN_ASSOC:     return "ассоциация";
        case WIFI_CONN_4WAY:      return "WPA2-рукопожатие";
        case WIFI_CONN_CONNECTED: return "подключено";
        case WIFI_CONN_FAILED:    return "не удалось";
    }
    return "?";
}

/* ================= опрос из главного цикла ================= */

void wifi_poll(void) {
    if (!wc.present || !wc.ready || !wc.ops) return;

    wc.ops->poll_rx();

    /* машина подключения (после опроса RX — ответы уже разобраны) */
    conn_step();

    if (!wc.scanning) return;
    /* СЕССИЯ 38: во время ассоциации каналы не перекидывать — AUTH/
     * ASSOC/4WAY идут на ЗАКРЕПЛЁННОМ канале точки; прыжок канала
     * делает нас глухими и немыми для неё */
    if (wc.conn == WIFI_CONN_AUTH || wc.conn == WIFI_CONN_ASSOC ||
        wc.conn == WIFI_CONN_4WAY) {
        wc.scanning = 0;
        return;
    }

    u32 now = timer_ticks();
    if ((int)(now - wc.dwell_start) < WIFI_SCAN_DWELL) return;   /* ещё слушаем */

    int idx = wc.scan_channel;
    wifi_log("ch %d (%u МГц): кадров %u, маяков %u, CRC %u, сетей %d",
             idx + 1, (unsigned)wc_channel_freq[idx],
             (unsigned)wc.stats.chan_frames[idx],
             (unsigned)wc.stats.chan_beacons[idx],
             (unsigned)wc.stats.chan_crc[idx], wc.ap_count);

    if (idx + 1 >= WC_NUM_CHANNELS) {
        /* скан завершён */
        wc.scanning = 0;
        wc.last_scan_end = timer_ticks();   /* для кэша при подключении */
        /* [ATH-SCAN2] повторный проход при МАЛОМ числе маяков (<10):
         * на загруженном эфире маяк периодически сдвигается за край
         * окна 110 мс — сеть пропускается. Прежде pass-2 запускался
         * только при НУЛЕ кадров (AR9485, опорник 25 МГц). */
        if (wc.pass == 1 && wc.stats.beacons < 10 && wc.ops->scan_retry &&
            wc.ops->scan_retry(wc.stats.frames)) {
            wc.pass = 2;
            wifi_log("маяков %u (<10) — второй проход скана",
                     (unsigned)wc.stats.beacons);
            memset(&wc.stats, 0, sizeof(wc.stats));
            wc.scanning = 1;
            wc.scan_channel = 0;
            wc.dwell_start = timer_ticks();
            if (!wc.ops->set_channel(0)) {
                wc.scanning = 0;
                wc.pass = 1;
            }
            return;
        }
        wifi_log("скан завершён: %d сетей, %u кадров, %u CRC, %u прочих",
                 wc.ap_count, (unsigned)wc.stats.frames,
                 (unsigned)wc.stats.crc_err, (unsigned)wc.stats.other);
        return;
    }

    wc.scan_channel = idx + 1;
    wc.dwell_start = now;
    if (!wc.ops->set_channel(wc.scan_channel)) {
        wc.scanning = 0;
        wifi_log("скан прерван: смена канала не удалась");
    }
}

/* ================= bind + init (диспетчер драйверов) ================= */

void wifi_core_bind(const wifi_hw_ops_t *ops) {
    wc.ops = ops;
}

void wifi_init(void) {
    memset(&wc, 0, sizeof(wc));
    wc.scan_channel = -1;
    wc.pass = 1;
    /* запасной MAC до чтения EEPROM/efuse: локально-администрируемый */
    wc.mac[0] = 0x02; wc.mac[1] = 0x1A; wc.mac[2] = 0x2B;

    wifi_log("wifi: поиск адаптеров (Atheros PCI, Realtek RTL8192EU USB)...");

    /* СЕССИЯ 37: диагностика фазы probe — раньше после «поиск Atheros»
     * в serial-логе могла быть тишина на минуты (BG-крошки), и по логу
     * было не понять: задача жива? скан идёт? донгл зааттачен? */
    {
        u32 t0 = timer_ticks();
        if (ath9k_wifi_probe())
            goto found;
        wifi_log("wifi: скан PCI занял %u мс, Atheros не найден — пробую RTL8192EU (USB attach=%d)",
                 (unsigned)(timer_ticks() - t0), rtl8192eu_attached() ? 1 : 0);
    }
    if (rtl8192eu_probe())
        goto found;

    wifi_log("адаптер не найден (нужен AR9285/9287/9485 или RTL8192EU)");
    return;

found:
    wifi_log("%s готов к работе (RX+TX)", wc.chip_name);
    /* автоподключение к сохранённой сети (WIFI.CFG) */
    char ssid[33];
    if (wifi_profile_load(ssid, sizeof(ssid))) {
        wifi_log("профиль: \"%s\" — автоподключение", ssid);
        wifi_connect(ssid);
    } else {
        wifi_log("профиль не задан — подключение из WiFi/Настроек");
    }
}
