#!/usr/bin/env python3
# test_snpf_utf8_host.py — хост-тест [CONSOLE] (сессия 73):
# snprintf/vsnprintf при обрезке НЕ оставляет обрубок многобайтового
# UTF-8 символа. Раньше «…837632 сек» + обрезанный lead байт давали
# мусорный глиф в сериал-консоли («секћahci]»), а съеденный '\n' клеил
# следующее сообщение к обрезанному хвосту.
#
# string.c компилируется на хосте как есть (freestanding, без ОС-API);
# проверяются сценарии: обрезка в начале кириллического символа, внутри,
# на латинице, точность %.N, полная вместимость (обрезки нет), 3-байтные
# символы у края буфера.
#
# Запуск: python3 scripts/test_snpf_utf8_host.py
import os, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "src")
TMP  = tempfile.mkdtemp(prefix="snpu8_")

main_c = r'''
/* freestanding-сборка string.c: без libc-заголовков, printf — extern */
typedef unsigned char u8;
typedef unsigned int  u32;
typedef unsigned long long u64;
typedef long long i64;
typedef short i16;
typedef unsigned short u16;
int snprintf(char *out, u32 n, const char *fmt, ...);
extern int printf(const char *fmt, ...);
extern unsigned long strlen(const char *s);   /* наш strlen(u32) совпадает по ABI */

static char *t_strstr(const char *hay, const char *needle) {
    for (; *hay; hay++) {
        const char *a = hay, *b = needle;
        while (*b && *a == *b) { a++; b++; }
        if (!*b) return (char *)hay;
    }
    return 0;
}
static int t_strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}
#define strstr t_strstr
#define strcmp t_strcmp

/* валиден ли усечённый буфер: ни один lead не остался без полного хвоста */
static int utf8_valid(const char *s) {
    while (*s) {
        unsigned char c = (unsigned char)*s;
        int need = (c & 0xE0) == 0xC0 ? 2 : (c & 0xF0) == 0xE0 ? 3 : 1;
        if ((c & 0xC0) == 0x80) return 0;          /* продолжающий без lead */
        for (int i = 1; i < need; i++)
            if ((((unsigned char)s[i]) & 0xC0) != 0x80) return 0;
        s += need;
    }
    return 1;
}

static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
                              else printf("ok: %s\n", msg); } while (0)

int main(void) {
    /* 1. сам баг: длинная строка диска в буфер 64 (реальный кейс ahci) */
    char b[64];
    snprintf(b, sizeof(b), "[ahci] диск: VMware Virtual SATA Hard Drive, 837632 секторов (%u МиБ)\n", 409u);
    CHECK(utf8_valid(b), "ahci-кейс: буфер без обрубка UTF-8");
    CHECK(!strstr(b, "\n") || b[strlen(b)-1] == '\n', "ahci-кейс: конец не рвёт строку насильно");
    CHECK(b[strlen(b)-1] != (char)0xD1 && (unsigned char)b[strlen(b)-1] < 0x80 ||
          utf8_valid(b), "ahci-кейс: последний байт не lead/continuation");

    /* 2. обрезка точно внутри кириллицы (каждый символ = 2 байта) */
    char c2[20];
    snprintf(c2, sizeof(c2), "абвгдежзийклмнопрст");
    CHECK(utf8_valid(c2), "кириллица: обрезка посреди символов");
    CHECK(strlen(c2) <= 19, "кириллица: не вышел за буфер");

    /* 3. 3-байтные символы у края */
    char c3[16];
    snprintf(c3, sizeof(c3), "日日日日日日日日");
    CHECK(utf8_valid(c3), "3-байтные у края буфера");

    /* 4. всё влезает — обрезки нет, содержимое полное */
    char c4[64];
    snprintf(c4, sizeof(c4), "строка %d влезает", 42);
    CHECK(strcmp(c4, "строка 42 влезает") == 0, "без обрезки: содержимое точно");

    /* 5. точность %.N по БАЙТАМ не рвёт символ? (prec — байтовая; тут
     *    проверяем только отсутствие обрубка на конце) */
    char c5[32];
    snprintf(c5, sizeof(c5), "%.7s", "приветмир");
    CHECK(utf8_valid(c5), "%.N у кириллицы");

    /* 6. буфер в 1 байт */
    char c6[1];
    snprintf(c6, sizeof(c6), "кириллица");
    CHECK(c6[0] == 0, "буфер 1 байт: пустая строка, без записи за границу");

    /* 7. буфер 2 байта: data[0] + NUL */
    char c7[2];
    snprintf(c7, sizeof(c7), "кириллица");
    CHECK(utf8_valid(c7), "буфер 2 байта: без обрубка");

    if (fails) { printf("ИТОГ: %d провал(ов)\n", fails); return 1; }
    printf("ИТОГ: snprintf UTF-8-обрезка — все проверки пройдены\n");
    return 0;
}
'''

open(os.path.join(TMP, "t.c"), "w").write(main_c)
cmd = ("cc -O0 -ffreestanding -fno-builtin -nostdinc -I" + SRC +
       " -o " + TMP + "/t " + TMP + "/t.c " + SRC + "/string.c -lc")
r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
if r.returncode != 0:
    print(r.stderr[:3000]); sys.exit(1)
r = subprocess.run([os.path.join(TMP, "t")], capture_output=True, text=True)
print(r.stdout)
sys.exit(r.returncode)
