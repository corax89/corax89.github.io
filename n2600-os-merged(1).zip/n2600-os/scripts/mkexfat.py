#!/usr/bin/env python3
# mkexfat.py — конструктор тестового exFAT-образа (сессия 75).
#
# Строит валидный exFAT-том (VBR, FAT, битовая карта, UpCase, корень
# с файлами/каталогом) — для хост-теста exfat.c (test_exfat_host.py):
# монтирование, список, чтение, запись, mkdir, удаление + проверка
# структур на диске после записи (чек-суммы наборов, хэши имён,
# FAT-цепочки, биты карты).
#
# Использование:  import mkexfat; img = mkexfat.build(path_or_None)
import struct

SECTOR = 512
SPC_SHIFT = 3                       # 8 секторов = 4 КиБ кластер
CLUSTER = SECTOR << SPC_SHIFT
TOTAL_SECTORS = 16384               # 8 МиБ
NFATS = 1
FAT_OFF = 100

UPCASE_ENTRIES = 0x500              # 0x000..0x4FF: ASCII+латиница+кириллица+греческий
UPCASE_BYTES = UPCASE_ENTRIES * 2

# ---- UpCase (зеркало запасного апкейса exfat.c; для имён теста хватает) ----
def upcase16(c):
    if 0x61 <= c <= 0x7A: return c - 32
    if 0xE0 <= c <= 0xFE and c != 0xF7: return c - 32
    if c == 0xFF: return 0x178
    if c == 0xB5: return 0x39C
    if c == 0x17F: return ord('S')
    if 0x100 <= c <= 0x137 and (c & 1): return c - 1
    if 0x13A <= c <= 0x148 and not (c & 1): return c - 1
    if 0x14B <= c <= 0x177 and (c & 1): return c - 1
    if 0x17A <= c <= 0x17E and not (c & 1): return c - 1
    if 0x430 <= c <= 0x44F: return c - 32
    if 0x450 <= c <= 0x45F: return c - 80
    if 0x3B1 <= c <= 0x3B9 and (c & 1): return c - 32
    if 0x3B2 <= c <= 0x3BA and not (c & 1): return c - 32
    if 0x3C3 <= c <= 0x3CB and (c & 1): return c - 32
    if 0x3C4 <= c <= 0x3CC and not (c & 1): return c - 32
    return c

def build_upcase():
    return b''.join(struct.pack('<H', upcase16(c))
                    for c in range(UPCASE_ENTRIES))

def name_hash(name_u16):
    h = 0
    for ch in name_u16:
        h = ((h << 15) | (h >> 1)) & 0xFFFF
        h = (h + upcase16(ch)) & 0xFFFF
    return h

def set_checksum(data):
    """Контрольная сумма набора записей (все байты кроме [2],[3] 0x85)."""
    s = 0
    for i, b in enumerate(data):
        if i == 2 or i == 3:
            continue
        s = ((s << 15) | (s >> 1)) & 0xFFFF
        s = (s + b) & 0xFFFF
    return s

def utf16(name):
    return name.encode('utf-16-le') if isinstance(name, str) else name

def nname_entries(name):
    return (len(utf16(name)) // 2 + 14) // 15

def build_entry_set(name, attr, first, dlen, valid=None, sflags=0x01):
    """Набор 0x85 + 0xC0 + N x 0xC1 (с чек-суммой и хэшем)."""
    u16name = struct.unpack('<%dH' % (len(utf16(name)) // 2), utf16(name))
    nn = nname_entries(name)
    n = 2 + nn
    st = bytearray(32 * n)
    # 0x85 File
    st[0] = 0x85
    st[1] = n - 1
    st[4:8] = struct.pack('<I', attr)
    ts_d = (41 << 9) | (3 << 5) | 15          # 2021-03-15
    ts_t = (12 << 11) | (30 << 5)             # 12:30:00
    # ms-fscc: Create@12, LastModified@16, 10ms/UTC@20-23, LastAccess@24
    st[12:16] = struct.pack('<HH', ts_d, ts_t)   # Create
    st[16:20] = struct.pack('<HH', ts_d, ts_t)   # LastModified
    st[20] = 0; st[21] = 0; st[22] = 0; st[23] = 0
    st[24:28] = struct.pack('<HH', ts_d, ts_t)   # LastAccess
    # 0xC0 Stream
    o = 32
    st[o] = 0xC0
    st[o+1] = sflags
    st[o+3] = len(u16name)
    h = name_hash(u16name)
    st[o+4:o+6] = struct.pack('<H', h)
    v = dlen if valid is None else valid
    st[o+8:o+16] = struct.pack('<Q', v)
    st[o+16:o+20] = struct.pack('<I', first)
    st[o+20:o+28] = struct.pack('<Q', dlen)
    # 0xC1 Name
    for k in range(nn):
        base = 32 * (2 + k)
        st[base] = 0xC1
        st[base+1] = 0
        for i in range(15):
            ci = k * 15 + i
            ch = u16name[ci] if ci < len(u16name) else 0
            st[base+2+i*2:base+2+i*2+2] = struct.pack('<H', ch)
    cs = set_checksum(st)
    st[2:4] = struct.pack('<H', cs)
    return bytes(st)

def special_entry(etype, flags, first=0, size=0, extra=None):
    e = bytearray(32)
    e[0] = etype
    e[1] = flags
    if etype == 0x83:                        # VolumeLabel: chars с 2
        lbl = utf16(extra or b'')
        e[1] = len(lbl) // 2
        e[2:2+len(lbl)] = lbl
    else:
        e[8:16] = struct.pack('<Q', size)
        e[16:20] = struct.pack('<I', first)
    return bytes(e)

def build(out_path=None, files=None):
    """Собрать образ. files: доп. (name, bytes|dict) поверх стандартных.
    Возвращает (bytes_образа, dict параметров)."""
    fat_len = 16                              # 2000 кластеров * 4 б -> 16 секторов
    heap_off = FAT_OFF + fat_len * NFATS      # 116
    clusters = (TOTAL_SECTORS - heap_off) * SECTOR // CLUSTER    # 2033
    clusters = 2000
    root = 4

    img = bytearray(TOTAL_SECTORS * SECTOR)

    def put_cluster(c, data):
        off = (heap_off + (c - 2) * (CLUSTER // SECTOR)) * SECTOR
        img[off:off+len(data)] = data

    # ---- FAT ----
    fat = bytearray(fat_len * SECTOR)
    def set_fat(c, v):
        struct.pack_into('<I', fat, c * 4, v)
    struct.pack_into('<I', fat, 0, 0xFFFFFFF8)
    struct.pack_into('<I', fat, 4, 0xFFFFFFFF)

    next_free = [5]
    def alloc(n=1, link=True):
        first = next_free[0]
        prev = 0
        for i in range(n):
            c = next_free[0]
            next_free[0] += 1
            set_fat(c, 0xFFFFFFFF)            # EOC
            if prev:
                set_fat(prev, c)              # связать цепочку
            prev = c
        return first

    # служебные файлы
    bm_clusters = (clusters + 7) // 8
    bm_clus_n = (bm_clusters + CLUSTER - 1) // CLUSTER
    bm_first = alloc(bm_clus_n)
    up_first = alloc(1)
    root_c = root
    set_fat(root_c, 0xFFFFFFFF)

    bitmap = bytearray(bm_clusters)
    def bm_set(c, val):
        idx = c - 2
        if val: bitmap[idx >> 3] |= (1 << (idx & 7))
        else:   bitmap[idx & 0x7FFFFFFF] &= 0xFF & ~(1 << (idx & 7))
    # ВАЖНО: биты выставляются ПОСЛЕ всех выделений (файлы/каталоги ниже)

    # ---- UpCase (один кластер, NoFatChain) ----
    up = build_upcase()
    assert len(up) == UPCASE_BYTES <= CLUSTER

    # ---- файлы ----
    std_files = [
        ('hello.txt', b'Hello, exFAT!\n' * 4),
        ('данные.dat', bytes((i * 7 + 3) & 0xFF for i in range(5000))),
        ('docs', {'dir': [
            ('readme.md', ('# exFAT v N2600-OS\nCHtenie i zapis rabotayut.\n').encode('utf-8')),
        ]}),
    ]
    all_files = std_files + (files or [])

    root_entries = bytearray()
    root_entries += special_entry(0x83, 0, extra='TESTVOL'.encode('utf-16-le'))
    root_entries += special_entry(0x81, 0x03, first=bm_first, size=bm_clusters)
    root_entries += special_entry(0x82, 0x03, first=up_first, size=UPCASE_BYTES)

    # проще без замыканий: линейная сборка
    def add_file(parent, name, content):
        n = (len(content) + CLUSTER - 1) // CLUSTER
        c = alloc(n)
        off_c, pos = c, 0
        while pos < len(content) or (pos == 0 and n == 1):
            chunk = content[pos:pos+CLUSTER]
            put_cluster(off_c, bytes(chunk) + bytes(CLUSTER - len(chunk)))
            pos += CLUSTER
            off_c += 1
            if pos >= len(content):
                break
        return build_entry_set(name, 0x20, c, len(content))

    def add_dir(parent, name, subentries):
        c = alloc()
        sub = bytearray()
        for name2, content2 in subentries:
            if isinstance(content2, dict):
                sub += add_dir(c, name2, content2['dir'])
            else:
                sub += add_file(c, name2, content2)
        put_cluster(c, bytes(sub) + bytes(CLUSTER - len(sub)))
        return build_entry_set(name, 0x10, c, 0)

    for name, content in all_files:
        if isinstance(content, dict):
            root_entries += add_dir(root_c, name, content['dir'])
        else:
            root_entries += add_file(root_c, name, content)

    put_cluster(root_c, bytes(root_entries) +
                bytes(CLUSTER - len(root_entries)))
    # теперь все кластеры выделены — финальная карта занятости
    for c in range(2, next_free[0]):
        bm_set(c, 1)
    put_cluster(bm_first, bytes(bitmap) + bytes(CLUSTER * bm_clus_n - len(bitmap)))
    put_cluster(up_first, up)

    # ---- FAT в образ (ранее массив терялся — все цепочки «читались»
    # только по непрерывности) ----
    fat_bytes = bytes(fat)
    img[FAT_OFF * SECTOR:(FAT_OFF + fat_len * NFATS) * SECTOR] = \
        fat_bytes[:fat_len * SECTOR * NFATS]

    # ---- VBR ----
    vbr = bytearray(SECTOR)
    vbr[0:3] = b'\xEB\x76\x90'
    vbr[3:11] = b'EXFAT   '
    vbr[64:72] = struct.pack('<Q', TOTAL_SECTORS)
    vbr[72:76] = struct.pack('<I', FAT_OFF)
    vbr[76:80] = struct.pack('<I', fat_len)
    vbr[80:84] = struct.pack('<I', heap_off)
    vbr[84:88] = struct.pack('<I', clusters)
    vbr[88:92] = struct.pack('<I', root)
    vbr[92:96] = struct.pack('<I', 0x20251021)   # серийный номер
    vbr[96:98] = struct.pack('<H', 0x0100)       # ревизия 1.00
    vbr[100] = 9                                 # bps shift (512)
    vbr[101] = SPC_SHIFT
    vbr[102] = NFATS
    vbr[510:512] = b'\x55\xAA'
    img[0:SECTOR] = vbr

    params = dict(clusters=clusters, fat_off=FAT_OFF, fat_len=fat_len,
                  heap_off=heap_off, root=root, cluster=CLUSTER,
                  bm_first=bm_first, up_first=up_first)
    if out_path:
        with open(out_path, 'wb') as f:
            f.write(img)
    return bytes(img), params

if __name__ == '__main__':
    import sys
    data, p = build(sys.argv[1] if len(sys.argv) > 1 else None)
    print("exFAT-образ:", len(data), "байт;", p)
