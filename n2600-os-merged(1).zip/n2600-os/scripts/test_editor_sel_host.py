#!/usr/bin/env python3
# test_editor_sel_host.py — хост-тест ВЫДЕЛЕНИЯ/БУФЕРА редактора.
#
# Собирает НАСТОЯЩИЙ src/editor.c на хосте (64-бит) с заглушками
# fb/wm/mouse (editor.c не рисует в этих функциях: ed_key/ed_mouse/
# ed_sel_* работают только с памятью). Проверяются сценарии запроса:
#   - выделение мышью (нажатие -> drag -> отпускание) через ed_mouse;
#   - Ctrl+C копирует в общий буфер, Ctrl+V вставляет (и заменяет
#     выделение), Ctrl+X вырезает, Ctrl+A выделяет всё;
#   - правка (печать/Backspace/Delete/Enter) заменяет выделение;
#   - удаление многострочного выделения: хвост последней строки
#     дописывается к первой (регрессия порядка урезки/дописи);
#   - UTF-8: кириллица не рвётся ни при копировании, ни при вставке;
#   - каретка: ed_cursor_rx для вертикальной линии (колонка в символах).
#
# Запуск: python3 scripts/test_editor_sel_host.py
import os, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "src")
TMP  = tempfile.mkdtemp(prefix="edsel_")

# ---------- заглушки системных заголовков ----------
os.makedirs(os.path.join(TMP, "stub"), exist_ok=True)
def w(fn, text): open(os.path.join(TMP, "stub", fn), "w").write(text)

w("types.h", r"""#ifndef TYPES_H
#define TYPES_H
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
typedef signed char i8; typedef short i16; typedef int i32;
typedef unsigned long long u64; typedef long long i64;
typedef unsigned int size_t_k;
#define NULL ((void*)0)
#endif
""")
w("mem.h", r"""#ifndef MEM_H
#define MEM_H
#include <stdlib.h>
#include "types.h"
#endif
""")
w("mouse.h", r"""#ifndef MOUSE_H
#define MOUSE_H
#include "types.h"
#define MSB_LEFT  0x01
#define MSB_RIGHT 0x02
#define MSB_MID   0x04
#endif
""")
# wm.h: нужны только wm_theme_* и wm_scrollbar_t (редактор хранит их)
w("wm.h", r"""#ifndef WM_H
#define WM_H
#include "types.h"
typedef struct { int dragging, pos, max, vis; } wm_scrollbar_t;
u32 wm_theme_win_bg(void); u32 wm_theme_win_bg_alt(void);
u32 wm_theme_text(void); u32 wm_theme_text_dim(void);
u32 wm_theme_text_info(void); u32 wm_theme_accent(void);
u32 wm_theme_sel_bg(void);
int wm_scrollbar_mouse(wm_scrollbar_t *sb, int mx, int my, u8 btn, u8 changed);
int wm_scrollbar_hmouse(wm_scrollbar_t *sb, int mx, int my, u8 btn, u8 changed);
void wm_scrollbar_draw(wm_scrollbar_t *sb, int x, int y, int w, int h, int pos, int max, int vis);
void wm_scrollbar_hdraw(wm_scrollbar_t *sb, int x, int y, int w, int h, int pos, int max, int vis);
#endif
""")
# kbd.h настоящий (KBD_UP.., KF_*)
os.link(os.path.join(SRC, "kbd.h"), os.path.join(TMP, "stub", "kbd.h"))
w("fb.h", r"""#ifndef FB_H
#define FB_H
#include "types.h"
static inline u32 fb_rgb(int r,int g,int b){ return ((u32)r<<16)|((u32)g<<8)|(u32)b; }
/* редактор НИКОГДА не зовёт их в тестируемых путях (ed_key/ed_mouse/
 * ed_sel_*), но линкер требует определения: безоперационные заглушки */
static inline void fb_text(int x,int y,const char *s,u32 c,int bg){(void)x;(void)y;(void)s;(void)c;(void)bg;}
static inline void fb_fill_rect(int x,int y,int w,int h,u32 c){(void)x;(void)y;(void)w;(void)h;(void)c;}
#endif
""")

# ---------- тест ----------
test = r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "editor.h"
#include "wm.h"      /* заглушка (stub/) — wm_scrollbar_t */
#include "kbd.h"
#include "mouse.h"
#include "clipboard.h"

/* заглушки темы (не вызываются в путях правки, но линкуются) */
u32 wm_theme_win_bg(void){return 0;} u32 wm_theme_win_bg_alt(void){return 0;}
u32 wm_theme_text(void){return 0;} u32 wm_theme_text_dim(void){return 0;}
u32 wm_theme_text_info(void){return 0;} u32 wm_theme_accent(void){return 0;}
u32 wm_theme_sel_bg(void){return 0;}
int wm_scrollbar_mouse(wm_scrollbar_t *s,int a,int b,u8 c,u8 d){(void)s;(void)a;(void)b;(void)c;(void)d;return -1;}
int wm_scrollbar_hmouse(wm_scrollbar_t *s,int a,int b,u8 c,u8 d){(void)s;(void)a;(void)b;(void)c;(void)d;return -1;}
void wm_scrollbar_draw(wm_scrollbar_t *s,int a,int b,int c,int d,int e,int f,int g){(void)s;(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;}
void wm_scrollbar_hdraw(wm_scrollbar_t *s,int a,int b,int c,int d,int e,int f,int g){(void)s;(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;}

static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
                              else printf("ok: %s\n", msg); } while (0)

static key_event_t *key(int code, char ch, u8 flags) {
    static key_event_t e; e.code = code; e.ch = ch; e.flags = flags;
    return &e;
}
/* область 40x10 клеток */
#define AW (40*8)
#define AH (10*16)

/* координаты мыши внутри текстовой области: ed_mouse считает бюджет
 * колонок как (x - PAD_L - linenr_px)/CHAR_W; у 3-строчного текста
 * PAD_L=4, linenr_px=2*8=16 (до 9 строк), поэтому колонка col — это
 * x = 4 + 16 + col*8 (в пределах символа). */
#define MX(col) (4 + 16 + (col) * 8)

/* drag мыши по тексту: (строка, колонка-в-символах) */
static void drag(ed_t *E, int r0, int c0, int r1, int c1) {
    ed_mouse(E, MX(c0), r0*16, MSB_LEFT, MSB_LEFT, AW, AH);     /* нажатие */
    if (r1 != r0 || c1 != c0)
        ed_mouse(E, MX(c1), r1*16, MSB_LEFT, 0, AW, AH);        /* drag */
    ed_mouse(E, MX(c1), r1*16, 0, MSB_LEFT, AW, AH);            /* отпускание */
}

int main(void) {
    ed_t *E = ed_create(0);

    /* --- текст: 3 строки с кириллицей --- */
    ed_set_text(E, "alpha\nбета\nгамма", (int)strlen("alpha\nбета\nгамма"));
    CHECK(ed_numrows(E) == 3, "3 строки загружены");

    /* Ctrl+A: выделить всё, Ctrl+C: скопировать */
    ed_key(E, key(0x1E, 'a', KF_CTRL), AW, AH);
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(strcmp(clip_text_get(), "alpha\nбета\nгамма") == 0, "Ctrl+A+Ctrl+C: весь текст с \\n");

    /* Ctrl+A затем печать заменяет ВСЁ */
    ed_key(E, key(0x1E, 'a', KF_CTRL), AW, AH);
    ed_key(E, key(0, 'X', 0), AW, AH);
    { int l1, c1, nr; ed_cursor_pos(E, &l1, &c1, &nr);
      char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "X") == 0, "печать заменяет выделение (Ctrl+A)");
      free(t); (void)l1; (void)c1; (void)nr; }

    /* мышиное выделение одной строки: drag по строке 0 "X" -> весь ряд */
    ed_set_text(E, "hello world\nsecond line\nthird", (int)strlen("hello world\nsecond line\nthird"));
    drag(E, 0, 0, 0, 5);
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(strcmp(clip_text_get(), "hello") == 0, "drag по строке: копия 'hello'");

    /* drag в обратную сторону (справа налево) */
    drag(E, 0, 11, 0, 6);
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(strcmp(clip_text_get(), "world") == 0, "обратный drag: 'world'");

    /* многострочное выделение (частичные края) + копия */
    drag(E, 0, 6, 1, 6);   /* "world\nsecond" */
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(strcmp(clip_text_get(), "world\nsecond") == 0, "многострочная копия с краями");

    /* Ctrl+X вырезает то же самое: края МНОГОстрочного выделения
     * склеиваются ("hello " + " line" -> "hello  line") */
    drag(E, 0, 6, 1, 6);
    ed_key(E, key(0x2D, 'x', KF_CTRL), AW, AH);
    { char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "hello  line\nthird") == 0, "Ctrl+X удалил 'world\\nsecond' (края склеены)");
      free(t); }

    /* Ctrl+V вставляет скопированное в позицию курсора */
    ed_key(E, key(0x2F, 'v', KF_CTRL), AW, AH);
    { char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "hello world\nsecond line\nthird") == 0, "Ctrl+V вернул текст");
      free(t); }

    /* выделение -> Ctrl+V заменяет выделение */
    drag(E, 1, 0, 1, 6);                 /* "second" */
    ed_key(E, key(0x2F, 'v', KF_CTRL), AW, AH);
    { char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "hello world\nworld\nsecond line\nthird") == 0,
            "Ctrl+V заменил выделенную 'second' на 'world\\nsecond'");
      free(t); }

    /* кириллица: выделить 'бета' целиком и скопировать (границы символов) */
    ed_set_text(E, "alpha\nбета\nгамма", (int)strlen("alpha\nбета\nгамма"));
    drag(E, 1, 0, 1, 4);
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(strcmp(clip_text_get(), "бета") == 0, "кириллица копируется целиком");

    /* UTF-8: замена выделения кириллицей, стрелки снимают выделение */
    clip_text_clear();               /* буфер мог быть непуст с прошлых шагов */
    drag(E, 1, 0, 1, 4);
    ed_key(E, key(KBD_RIGHT, 0, 0), AW, AH);
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(clip_text_len() == 0, "стрелка сняла выделение (копировать нечего)");

    /* Delete/Backspace при выделении удаляют только выделенное */
    ed_set_text(E, "abcdef", (int)strlen("abcdef"));
    drag(E, 0, 2, 0, 4);                 /* "cd" */
    ed_key(E, key(0x53, 0, 0), AW, AH);  /* Delete */
    { char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "abef") == 0, "Delete удалил выделение 'cd'");
      free(t); }
    drag(E, 0, 1, 0, 3);                 /* "be" */
    ed_key(E, key(0x0E, 0, 0), AW, AH);  /* Backspace */
    { char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "af") == 0, "Backspace удалил выделение 'be'");
      free(t); }

    /* Enter при выделении заменяет его переводом строки */
    ed_set_text(E, "one\ntwo", (int)strlen("one\ntwo"));
    drag(E, 0, 1, 0, 3);
    ed_key(E, key(0x1C, '\n', 0), AW, AH);
    { char *t = ed_get_text_alloc(E, NULL);
      CHECK(strcmp(t, "o\n\ntwo") == 0, "Enter заменил выделение (сырая замена)");
      free(t); }

    /* клик без движения снимает выделение */
    ed_set_text(E, "abcdef", (int)strlen("abcdef"));
    drag(E, 0, 1, 0, 4);
    drag(E, 0, 2, 0, 2);                 /* клик на месте */
    ed_key(E, key(0x2E, 'c', KF_CTRL), AW, AH);
    CHECK(clip_text_len() == 0, "клик без движения снял выделение");

    /* каретка-линия: экранная колонка курсора в СИМВОЛАХ */
    ed_set_text(E, "абвгд", (int)strlen("абвгд"));
    drag(E, 0, 5, 0, 5);                 /* курсор в конец: 5 СИМВОЛОВ */
    { int l1, c1, nr; ed_cursor_pos(E, &l1, &c1, &nr);
      CHECK(c1 - 1 == 5 && l1 == 1, "колонка каретки в символах (кириллица=1)"); }

    if (fails) { printf("ИТОГ: %d провал(ов)\n", fails); return 1; }
    printf("ИТОГ: выделение/буфер редактора — все проверки пройдены\n");
    return 0;
}
'''
open(os.path.join(TMP, "t_ed.c"), "w").write(test)

# КСЯ: editor.c делает #include "fb.h"/"mem.h" КАВЫЧНЫМ включением —
# они ищутся в каталоге САМОГО editor.c (SRC) раньше -I. Поэтому для
# теста компилируется КОПИЯ editor.c из TMP: там кавычные include
# попадают в заглушки (stub/), а недостающее (editor.h, utf8.h,
# string.h, clipboard.h, kbd.h) берётся из SRC через -I.
import shutil
shutil.copy(os.path.join(SRC, "editor.c"), os.path.join(TMP, "editor.c"))

cmd = (f"cc -O0 -I{TMP}/stub -I{SRC} -o {TMP}/t_ed {TMP}/t_ed.c "
       f"{TMP}/editor.c {SRC}/clipboard.c")
r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
if r.returncode != 0:
    print(r.stdout); print(r.stderr); sys.exit(1)
r = subprocess.run([os.path.join(TMP, "t_ed")], capture_output=True, text=True)
print(r.stdout)
sys.exit(r.returncode)
