#!/usr/bin/env python3
# test_ci_clip_host.py — хост-тест исправлений сессии (запрос):
#   1) ramfs: find_file БЕЗ УЧЁТА РЕГИСТРА (ramfs_name_eq) — первопричина
#      «img.js не открывает LOGO.PNG»: сидинг приводит имена к нижнему
#      регистру (rs_lower), скрипты передают «LOGO.PNG» как набрано.
#      Проверяем: чтение/удаление/создание-дубликат находят файл при
#      любом регистре; имитируется плоская таблица ramfs.
#   2) clipboard.c: clip_text_set/get — круговорот, обрезка по границе
#      символа UTF-8, очистка. Собирается НА ХОСТЕ как есть (1 в 1
#      с ядром), заглушки не нужны (types/string/sync портируемы).
#   3) fileman: name_is_web_doc — md/html/htm распознаются в любом
#      регистре, txt/c/js — нет (классификатор вырезается regex-ом,
#      как в test_crumbs_host.py).
#
# Запуск: python3 scripts/test_ci_clip_host.py

import os, re, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "src")
TMP  = tempfile.mkdtemp(prefix="ci_clip_")

def sh(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout); print(r.stderr); sys.exit(1)
    return r.stdout

# ---------- 1) ramfs_name_eq (вырезка из ramfs.c) ----------
ram = open(os.path.join(SRC, "ramfs.c")).read()
m = re.search(r"static int ramfs_name_eq\(const char \*a, const char \*b\) \{.*?\n\}", ram, re.S)
if not m: sys.exit("FAIL: ramfs_name_eq не найден в ramfs.c")
fn = m.group(0)

# мини-имитация таблицы ramfs: имена как после сидинга (rs_lower)
test_c = r'''
#include <stdio.h>
#include <string.h>
static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
                              else printf("ok: %s\n", msg); } while (0)
@@FN@@

/* плоская таблица имён (как в RAM disk после сидинга) */
static const char *table[] = { "logo.png", "img.js", "help.md", "autorun.txt" };
static int find_file(const char *name) {
    for (unsigned i = 0; i < sizeof(table)/sizeof(table[0]); i++)
        if (ramfs_name_eq(table[i], name)) return (int)i;
    return -1;
}
int main(void) {
    /* главный сценарий бага: скрипт просит ВЕРХНИЙ регистр */
    CHECK(find_file("LOGO.PNG") == 0, "LOGO.PNG -> logo.png");
    CHECK(find_file("img.js")   == 1, "img.js -> img.js (точный)");
    CHECK(find_file("IMG.JS")   == 1, "IMG.JS -> img.js");
    CHECK(find_file("Help.Md")  == 2, "Help.Md -> help.md");
    CHECK(find_file("AUTORUN.TXT") == 3, "AUTORUN.TXT -> autorun.txt");
    CHECK(find_file("logo.png") == 0, "нижний регистр тоже работает");
    CHECK(find_file("nosuch.png") == -1, "нет файла -> -1");
    CHECK(find_file("log.png") == -1, "префикс не матчится");
    CHECK(find_file("logo.pngx") == -1, "хвост не матчится");
    CHECK(find_file("") == -1, "пустое имя -> -1");
    CHECK(ramfs_name_eq("aBc", "AbC") == 1, "внутренние регистры");
    CHECK(ramfs_name_eq("ab", "abc") == 0, "разная длина");
    if (fails) { printf("ИТОГ: %d провал(ов)\n", fails); return 1; }
    printf("ИТОГ: ramfs_name_eq — все проверки пройдены\n");
    return 0;
}'''
test_c = test_c.replace('@@FN@@', fn)
open(os.path.join(TMP, "t_ci.c"), "w").write(test_c)
out = sh(f"cc -o {TMP}/t_ci {TMP}/t_ci.c && {TMP}/t_ci")
print(out.strip())

# ---------- 2) clipboard.c как есть ----------
harness = r'''
#include <stdio.h>
#include <string.h>
#include "clipboard.h"
int main(void) {
    static int fails = 0;
    #define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
                                  else printf("ok: %s\n", msg); } while (0)

    CHECK(clip_text_len() == 0 && clip_text_get()[0] == 0, "старт: буфер пуст");

    clip_text_set("привет, мир", -1);
    CHECK(clip_text_len() == (int)strlen("привет, мир"), "длина UTF-8 в байтах");
    CHECK(strcmp(clip_text_get(), "привет, мир") == 0, "круговорот строки");

    clip_text_set("abc", 2);
    CHECK(strcmp(clip_text_get(), "ab") == 0, "set с явной длиной");

    /* обрезка по границе символа: кириллица = 2 байта, режем посередине */
    {
        char big[CLIP_TEXT_MAX + 40];
        memset(big, 0x61, sizeof(big));            /* 'a' */
        clip_text_set(big, (int)sizeof(big));
        CHECK(clip_text_len() == CLIP_TEXT_MAX, "лимит CLIP_TEXT_MAX");
        /* хвост — валидный UTF-8 (последний байт не продолжение) */
        const unsigned char *t = (const unsigned char *)clip_text_get();
        CHECK(t[clip_text_len()] == 0, "NUL на конце");
    }
    {
        /* длинный буфер, где граница попадает в 2-байтовый символ */
        char big[CLIP_TEXT_MAX + 8];
        memset(big, 0x61, sizeof(big));
        big[CLIP_TEXT_MAX - 1] = (char)0xD0;       /* начало 'п' */
        big[CLIP_TEXT_MAX]     = (char)0xBF;       /* конец 'п' */
        big[sizeof(big) - 1] = 0;
        clip_text_set(big, -1);
        const unsigned char *t = (const unsigned char *)clip_text_get();
        CHECK(clip_text_len() == CLIP_TEXT_MAX - 1, "обрез до границы символа");
        CHECK((t[clip_text_len() - 1] & 0xC0) != 0x80, "нет половины буквы");
    }
    clip_text_set(NULL, 5);
    CHECK(clip_text_len() == 0, "NULL очищает");
    clip_text_set("x", -1);
    clip_text_clear();
    CHECK(clip_text_len() == 0 && clip_text_get()[0] == 0, "clear очищает");

    if (fails) { printf("ИТОГ: %d провал(ов)\n", fails); return 1; }
    printf("ИТОГ: clipboard — все проверки пройдены\n");
    return 0;
}
'''
open(os.path.join(TMP, "t_clip.c"), "w").write(harness)
# -m32 недоступен? собираем как есть: 64-бит хост, типы ОС совместимы
out = sh(f"cc -I{SRC} -o {TMP}/t_clip {TMP}/t_clip.c {SRC}/clipboard.c && {TMP}/t_clip")
print(out.strip())

# ---------- 3) name_is_web_doc (вырезка из fileman.c) ----------
fm = open(os.path.join(SRC, "fileman.c")).read()
mne = re.search(r"static int name_ext_is\(const char \*name, const char \*ext\)\n\{.*?\n\}", fm, re.S)
mwd = re.search(r"static int name_is_web_doc\(const char \*name\)\n\{.*?\n\}", fm, re.S)
mnt = re.search(r"static int name_is_text\(const char \*name\)\n\{.*?\n\}", fm, re.S)
if not (mne and mwd and mnt): sys.exit("FAIL: классификаторы fileman.c не найдены")
test_wd = r'''
#include <stdio.h>
#include <string.h>
static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
                              else printf("ok: %s\n", msg); } while (0)
@@FNE@@
@@FNT@@
@@FNW@@
int main(void) {
    CHECK(name_is_web_doc("IMGTEST.MD"), ".md (верхний)");
    CHECK(name_is_web_doc("imgtest.md"), ".md (нижний)");
    CHECK(name_is_web_doc("page.html"), ".html");
    CHECK(name_is_web_doc("PAGE.HTM"), ".htm (верхний)");
    CHECK(name_is_web_doc("a.b.htm"), ".htm с точкой в имени");
    CHECK(!name_is_web_doc("md"), "без точки");
    CHECK(!name_is_web_doc("md.txt"), "md внутри имени");
    CHECK(!name_is_web_doc("logo.png"), "png не web-doc");
    CHECK(!name_is_web_doc("mdx"), "mdx без расширения");
    CHECK(!name_is_web_doc("a.md.txt"), "расширение .txt");
    CHECK(name_is_text("README.TXT"), "txt по-прежнему текст");
    CHECK(!name_is_text("HELP.MD"), "md больше НЕ в редакторе по умолчанию");
    if (fails) { printf("ИТОГ: %d провал(ов)\n", fails); return 1; }
    printf("ИТОГ: name_is_web_doc — все проверки пройдены\n");
    return 0;
}
'''
test_wd = test_wd.replace('@@FNE@@', mne.group(0)).replace('@@FNT@@', mnt.group(0)).replace('@@FNW@@', mwd.group(0))
open(os.path.join(TMP, "t_wd.c"), "w").write(test_wd)
out = sh(f"cc -o {TMP}/t_wd {TMP}/t_wd.c && {TMP}/t_wd")
print(out.strip())

print("\nИТОГ: все проверки пройдены")
