#!/usr/bin/env python3
# test_usb_mbr_host.py — хост-тест ФИКСА «флешка не появляется в Файловом».
#
# Первопричина: fat32_init_usb монтировал только «суперфлоппи» (FAT32
# с LBA 0) и НИКОГДА не разбирал MBR, а fat32_read_usb игнорировал
# g_base_lba. Любая штатно отформатированная флешка (Windows/Rufus)
# имеет MBR с разделом FAT32 — монтирование всегда проваливалось.
#
# Тест компилирует ВЫРЕЗАННЫЙ БАЙТ-В-БАЙТ фрагмент fat32_init_usb
# (между 'rc = 0;' и концом if (usb_ehci_storage_ready())) с заглушками:
# fat32_init_internal «монтирует», если g_base_lba == ожидаемый LBA;
# fat32_read_usb отдаёт тестовый MBR. Проверяются сценарии:
#   суперфлоппи / FAT32-разделы типов 0x0B/0x0C (проход 1) / раздел с
#   «врущим» типом (проход 2) / пропуск расширенных / сброс базы при
#   неудаче / отсутствие устройства.
#
# Запуск: python3 scripts/test_usb_mbr_host.py
import os, re, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "src")
TMP  = tempfile.mkdtemp(prefix="usbmbr_")

fat = open(os.path.join(SRC, "fat32.c")).read()

# --- вырезка тела if (usb_ehci_storage_ready()) {...} из fat32_init_usb ---
# СЕССИЯ 73: перед if добавились лог-строки попытки монтирования —
# начало вырезки сдвинуто на строку после "is_usb = 1;".
start = fat.index("    is_usb = 1;\n") + len("    is_usb = 1;\n")
end_marker = "            if (!rc) g_base_lba = 0;    /* не смонтировалось — сброс базы */\n        }\n    }"
end = fat.index(end_marker, start) + len(end_marker)
body = fat[start:end]

# снимаем ОС-специфику: extern snprintf не нужен на хосте
body = body.replace("                            extern int snprintf(char *o, u32 n, const char *f, ...);\n", "")

harness = r'''
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef unsigned char u8; typedef unsigned int u32;
static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
                              else printf("ok: %s\n", msg); } while (0)

/* ---- заглушки окружения fat32.c ---- */
static int (*fat32_read_fn)(u32, void *);
static int (*fat32_write_fn)(u32, const void *);
static u32  g_free_hint;
static int  is_usb;
static u32  g_base_lba;
static int  g_storage_ready = 1;
static u8   g_mbr[512];              /* что отдаёт чтение LBA 0 */
static int  g_mbr_present;
static u32  g_expect_lba;            /* какой base «монтируется» (или 0xFFFFFFFF — никогда) */
static u32  g_tried[8]; static int g_tried_n;

static int usb_ehci_storage_ready(void) { return g_storage_ready; }
static int fat32_read_usb(u32 lba, void *buf) {
    if (lba == 0 && g_mbr_present) { memcpy(buf, g_mbr, 512); return 1; }
    return 1;   /* прочие сектора «читаются» */
}
static void serial_puts(const char *s) { (void)s; }
static int fat32_init_internal(void) {
    if (g_tried_n < 8) g_tried[g_tried_n++] = g_base_lba;
    if (g_base_lba == g_expect_lba) return 1;
    return 0;
}

/* ---- ВЫРЕЗКА ИЗ fat32.c (байт-в-байт) ---- */
@@BODY@@

static int run(void) { g_tried_n = 0; return fat32_init_usb_body(); }

static void put_part(int idx, u8 type, u32 start, u32 size) {
    u8 *e = g_mbr + 446 + idx * 16;
    memset(e, 0, 16);
    e[4] = type;
    e[8] = (u8)start; e[9] = (u8)(start >> 8);
    e[10] = (u8)(start >> 16); e[11] = (u8)(start >> 24);
    e[12] = (u8)size; e[13] = (u8)(size >> 8);
    e[14] = (u8)(size >> 16); e[15] = (u8)(size >> 24);
    g_mbr[510] = 0x55; g_mbr[511] = 0xAA;
}

int main(void) {
    /* 1. суперфлоппи: FAT32 прямо с LBA 0 */
    memset(g_mbr, 0, sizeof(g_mbr)); g_mbr_present = 1;
    g_expect_lba = 0;
    CHECK(run() == 1 && g_base_lba == 0, "суперфлоппи: смонтирован LBA 0");

    /* 2. MBR: один раздел FAT32 (0x0C) @ 2048 — штатный случай Windows */
    memset(g_mbr, 0, sizeof(g_mbr)); g_mbr_present = 1;
    put_part(0, 0x0C, 2048, 15656959);
    g_expect_lba = 2048;
    CHECK(run() == 1 && g_base_lba == 2048, "MBR: раздел 0x0C @2048 смонтирован");

    /* 3. MBR: FAT32 (0x0B) во ВТОРОЙ записи */
    memset(g_mbr, 0, sizeof(g_mbr));
    put_part(0, 0x07, 1024, 500);      /* NTFS-подобный — мимо */
    put_part(1, 0x0B, 4096, 1000);
    g_expect_lba = 4096;
    CHECK(run() == 1 && g_base_lba == 4096, "MBR: раздел 0x0B @4096 (запись 1)");

    /* 4. «врущий» тип: 0x06 (FAT16), но BPB — FAT32: находится проходом 2 */
    memset(g_mbr, 0, sizeof(g_mbr));
    put_part(0, 0x06, 8192, 1000);
    g_expect_lba = 8192;
    CHECK(run() == 1 && g_base_lba == 8192, "проход 2: нестандартный тип 0x06");

    /* 5. расширенные разделы (0x05/0x0F) не пробуются вовсе */
    memset(g_mbr, 0, sizeof(g_mbr));
    put_part(0, 0x0F, 100, 1000);
    g_expect_lba = 0xFFFFFFFFu;
    g_tried_n = 0;
    run();
    int tried_ext = 0;
    for (int i = 0; i < g_tried_n; i++) if (g_tried[i] == 100) tried_ext = 1;
    CHECK(!tried_ext, "extended (0x0F) пропущен");

    /* 6. ничего не смонтировалось — база сброшена в 0 */
    memset(g_mbr, 0, sizeof(g_mbr));
    put_part(0, 0x07, 512, 1000);
    g_expect_lba = 0xFFFFFFFFu;
    CHECK(run() == 0 && g_base_lba == 0, "неудача: база сброшена в 0");

    /* 7. нет устройства (storage не готов) — без чтений */
    g_storage_ready = 0; g_expect_lba = 0xFFFFFFFFu;
    CHECK(run() == 0, "нет устройства: rc=0");
    g_storage_ready = 1;

    /* 8. пустые записи (type=0) не пробуются */
    memset(g_mbr, 0, sizeof(g_mbr));
    put_part(2, 0x00, 777, 1000);
    g_tried_n = 0;
    g_expect_lba = 0xFFFFFFFFu;
    run();
    int tried777 = 0;
    for (int i = 0; i < g_tried_n; i++) if (g_tried[i] == 777) tried777 = 1;
    CHECK(!tried777, "пустая запись (type 0) пропущена");

    /* 9. порядок: FAT32-типы раньше прочих (проход 1 первым) */
    memset(g_mbr, 0, sizeof(g_mbr));
    put_part(0, 0x06, 100, 100);       /* не-FAT тип */
    put_part(1, 0x0C, 200, 100);       /* FAT32 */
    g_expect_lba = 200;
    /* g_tried[0] всегда 0 (первой всегда идёт попытка суперфлоппи);
     * главное: 200 (проход 1) опробован РАНЬШЕ 100 (проход 2) */
    int r9 = run();                     /* сначала прогон — потом анализ */
    int i200 = -1, i100 = -1;
    for (int i = 0; i < g_tried_n; i++) {
        if (g_tried[i] == 200) i200 = i;
        if (g_tried[i] == 100) i100 = i;
    }
    CHECK(r9 == 1 && g_base_lba == 200 && i200 > 0 &&
          (i100 < 0 || i200 < i100),
          "проход 1 (FAT32) выполняется раньше прохода 2");

    if (fails) { printf("ИТОГ: %d провал(ов)\n", fails); return 1; }
    printf("ИТОГ: fat32_init_usb (MBR-скан) — все проверки пройдены\n");
    return 0;
}
'''

# оборачиваем вырезку в функцию: она объявляет g_base_lba и прочие СНАРУЖИ,
# поэтому вырезку кладём в функцию с extern-глобальными
test_c = harness.replace("@@BODY@@", "static int fat32_init_usb_body(void) {\n    int rc;\n" + body + "\n    return rc;\n}")
open(os.path.join(TMP, "t.c"), "w").write(test_c)
r = subprocess.run(f"cc -O0 -o {TMP}/t {TMP}/t.c", shell=True, capture_output=True, text=True)
if r.returncode != 0:
    print(r.stderr[:3000]); sys.exit(1)
r = subprocess.run([os.path.join(TMP, "t")], capture_output=True, text=True)
print(r.stdout)

# --- структурные проверки (регрессия сессии 73: потерянный g_base_lba) ---
# Харнесс заглушает fat32_read_usb, поэтому сама база раздела здесь не
# тестируется — проверяем исходник структурно: и чтение, и запись USB
# ОБЯЗАНЫ применять g_base_lba, иначе fat32_init_internal() с
# g_base_lba = pstart снова начнёт читать MBR вместо BR раздела.
sfails = 0
def scheck(cond, msg):
    global sfails
    print(("ok:   " if cond else "FAIL: ") + msg)
    if not cond: sfails += 1

scheck("usb_ehci_read_sector(g_base_lba + lba" in fat,
       "fat32_read_usb применяет g_base_lba (чтение раздела, а не MBR)")
scheck("usb_ehci_write_sector(g_base_lba + lba" in fat,
       "fat32_write_usb применяет g_base_lba (запись в раздел, а не MBR)")

if r.returncode or sfails:
    print("ИТОГ: ПРОВАЛЫ" + (f": {sfails} структурн." if sfails else ""))
    sys.exit(1)
print("ИТОГ: fat32_init_usb (MBR-скан) + структурные проверки — все пройдены")
sys.exit(0)
