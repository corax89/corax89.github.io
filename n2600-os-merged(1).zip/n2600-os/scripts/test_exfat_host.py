#!/usr/bin/env python3
# test_exfat_host.py — хост-тест exFAT чтение+запись (сессия 75).
#
# 1. mkexfat.py строит валидный exFAT-образ (VBR/FAT/битовая карта/
#    UpCase/корень с файлами, кириллица, подкаталог).
# 2. Харнесс test_exfat_host.c (+ src/exfat.c) проверяет монтирование,
#    список, чтение, поиск, создание, перезапись, mkdir, удаление,
#    перемонтирование.
# 3. Питон-проверка структур НА ДИСКЕ после записи: контрольная сумма
#    набора записей, хэш имени, EOC-конец FAT-цепочки нового файла,
#    биты карты занятости (создание/удаление), снятие InUse.
#
# Запуск: python3 scripts/test_exfat_host.py
import os, struct, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import mkexfat

TMP = tempfile.mkdtemp(prefix="exfat_")
IMG = os.path.join(TMP, "exfat.img")
BIN = os.path.join(TMP, "exfat_test")
SRC = os.path.join(ROOT, "src")

fails = 0
def check(cond, what):
    global fails
    print(("  [OK]   " if cond else "  [FAIL] ") + what)
    if not cond:
        fails += 1

# ---------- 1. образ ----------
data, P = mkexfat.build(IMG)
check(len(data) == 8388608, "образ 8 МиБ построен")

# ---------- 2. компиляция и прогон харнесса ----------
cc = ["gcc", "-O2", "-Wall", "-Wno-unused-function",
      "-I" + SRC,
      "-Dmalloc=exfat_hmalloc", "-Dfree=exfat_hfree",
      os.path.join(HERE, "test_exfat_host.c"),
      os.path.join(SRC, "exfat.c"),
      "-o", BIN]
r = subprocess.run(cc, capture_output=True, text=True)
check(r.returncode == 0, "харнесс скомпилирован (exfat.c на хосте)")
if r.returncode != 0:
    print(r.stderr[:2000])
    sys.exit(1)

IMG_OUT = os.path.join(TMP, "exfat-after.img")
r = subprocess.run([BIN, IMG, IMG_OUT], capture_output=True,
                   text=True, errors="replace")
print(r.stdout.rstrip())
c_ok = "ВСЕ ТЕСТЫ ПРОШЛИ" in r.stdout
check(c_ok, "харнесс: все C-тесты прошли")
if not c_ok:
    fails += 1

# ---------- 3. структуры на диске ----------
def root_entries():
    heap = P["heap_off"]
    rootc = P["root"]
    off = (heap + (rootc - 2) * 8) * 512
    out = []
    pos = off
    while True:
        t = data[pos]
        if t == 0 or t == 0x00:
            break
        if (t & 0x7F) == 0x05:            # 0x85 (в т.ч. удалённый 0x05)
            sec = data[pos + 1]
            out.append((pos, sec))
            pos += 32 * sec
            continue
        pos += 32
    return out

def cluster_bytes(c, n=1):
    off = (P["heap_off"] + (c - 2) * 8) * 512
    return data[off:off + n * 4096]

def fat_val(c):
    fo = P["fat_off"] * 512
    return struct.unpack_from("<I", data, fo + c * 4)[0]

data = open(IMG_OUT, 'rb').read()
img = bytearray(data)

def upcase16(c):
    return mkexfat.upcase16(c)

check(len(root_entries()) >= 3, "в корне есть наборы записей (0x85)")

# контрольная сумма + хэш набора hello.txt после перезаписи
fe = None
for pos, sec in root_entries():
    first = 0
    dlen = 0
    chars = []
    for k in range(1, sec + 1):        # файл + все secondary (sec_count+1)
        eb = data[pos + k * 32:pos + k * 32 + 32]
        if eb[0] == 0xC1:
            for i in range(15):
                ch = struct.unpack_from("<H", eb, 2 + i * 2)[0]
                if ch:
                    chars.append(chr(ch))
        elif eb[0] == 0xC0:
            first = struct.unpack_from("<I", eb, 16)[0]
            dlen = struct.unpack_from("<Q", eb, 20)[0]
    name = "".join(chars)
    if name == "hello.txt":
        fe = (pos, sec, first, dlen)

check(fe is not None, "набор hello.txt найден на диске")
if fe:
    pos, sec, first, dlen = fe
    st = data[pos:pos + 32 * (sec + 1)]
    s = 0
    for i, b in enumerate(st):
        if i == 2 or i == 3:
            continue
        s = ((s << 15) | (s >> 1)) & 0xFFFF
        s = (s + b) & 0xFFFF
    stored = struct.unpack_from("<H", st, 2)[0]
    check(stored == s, "контрольная сумма набора hello.txt корректна")
    check(dlen == 12, "DataLength hello.txt = 12 (после перезаписи)")
    u16name = "hello.txt".encode("utf-16-le")
    h = 0
    for (ch,) in struct.iter_unpack("<H", u16name):
        h = ((h << 15) | (h >> 1)) & 0xFFFF
        h = (h + upcase16(ch)) & 0xFFFF
    stored_hash = struct.unpack_from("<H", st, 32 + 4)[0]
    check(stored_hash == h, "NameHash hello.txt совпадает со spec-расчётом")
    # FAT-цепочка: 12 байт = 1 кластер, EOC
    check(fat_val(first) == 0xFFFFFFFF,
          "FAT-цепочка hello.txt заканчивается EOC")

# биты карты: sub(каталог) занят, new.txt свободен
fe_sub = None
for pos, sec in root_entries():
    chars = []
    for k in range(1, sec + 1):
        eb = data[pos + k * 32:pos + k * 32 + 32]
        if eb[0] == 0xC1:
            for i in range(15):
                ch = struct.unpack_from("<H", eb, 2 + i * 2)[0]
                if ch:
                    chars.append(chr(ch))
        elif eb[0] == 0xC0:
            pass
    name = "".join(chars)
    if name == "sub":
        eb = data[pos + 32:pos + 64]
        fe_sub = struct.unpack_from("<I", eb, 16)[0]
# (имя sub ищется в наборе с range(1, sec+1) выше по тексту — блок ниже)

check(fe_sub is not None and fe_sub >= 2, "каталог sub имеет кластер")
if fe_sub:
    bm_off = 0
    # карта: bit N = cluster N+2
    bit_idx = fe_sub - 2
    bm_byte = data[(P["heap_off"] + 0) * 512 + (P["bm_first"] - 2) * 4096 + (bit_idx >> 3)]
    check((bm_byte >> (bit_idx & 7)) & 1,
          "бит карты занятости выставлен для кластера sub")

# удалённый new.txt: InUse снят у 0x85
found_deleted = False
pos = (P["heap_off"] + (P["root"] - 2) * 8) * 512
while data[pos] != 0:
    t = data[pos]
    if t == 0x05:
        found_deleted = True
        break
    if t == 0x85:
        pos += 32 * data[pos + 1]
        continue
    pos += 32
check(found_deleted, "удалённая запись new.txt: тип 0x05 (InUse снят)")

print()
print("ИТОГ: " + ("ВСЕ ПРОВЕРКИ ПРОШЛИ" if fails == 0 else f"{fails} ПРОВАЛ(ОВ)"))
sys.exit(1 if fails else 0)
