/* test_exfat_host.c — хост-харнесс для exfat.c (сессия 75).
 *
 * Компилируется вместе с src/exfat.c на хосте (64-битный gcc):
 *   gcc -Isrc -Dmalloc=exfat_hmalloc -Dfree=exfat_hfree ...
 * Заглушки: чтение/запись 512-байтных секторов из файла-образа
 * (строит mkexfat.py), RTC — фиксированное время.
 *
 * Проверяет: монтирование, список корня/каталога, чтение файлов
 * (ASCII/кириллица), поиск без учёта регистра, создание, запись
 * (создание+перезапись), mkdir, удаление (в т.ч. отказ на непустом
 * каталоге), перемонтирование с сохранением состояния.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- замена malloc/free ядра (exfat.c включает mem.h с u32-сигнатурой).
 * -Dmalloc=exfat_hmalloc переименовывает и обращения в ЭТОМ файле —
 * тело зовёт __builtin_malloc (макросом не подменяется). */
void *exfat_hmalloc(__SIZE_TYPE__ n) { return __builtin_malloc(n); }
void  exfat_hfree(void *p)           { __builtin_free(p); }

/* ---- заглушки ОС ---- */
void serial_puts(const char *s) { fputs(s, stdout); }

/* ---- заглушки RTC ---- */
void rtc_get_time(int *h, int *m, int *s) { *h = 12; *m = 34; *s = 56; }
void rtc_get_date(int *y, int *mo, int *d) { *y = 2025; *mo = 10; *d = 21; }

#include "exfat.h"

/* ---- образ ---- */
static unsigned char *g_img = NULL;
static unsigned long  g_img_size = 0;

static int host_rd(u32 lba, void *buf)
{
    unsigned long off = (unsigned long)lba * 512;
    if (off + 512 > g_img_size) return 0;
    memcpy(buf, g_img + off, 512);
    return 1;
}

static int host_wr(u32 lba, const void *buf)
{
    unsigned long off = (unsigned long)lba * 512;
    if (off + 512 > g_img_size) return 0;
    memcpy(g_img + off, buf, 512);
    return 1;
}

static int fails = 0;
#define CHECK(cond, msg) do { if (cond) printf("ok: %s\n", msg); \
    else { printf("FAIL: %s\n", msg); fails++; } } while (0)

static int load_image(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    g_img = malloc((size_t)n);
    if (!g_img) { fclose(f); return 0; }
    g_img_size = (unsigned long)n;
    size_t got = fread(g_img, 1, (size_t)n, f);
    fclose(f);
    return got == (size_t)n;
}

static int find_in_list(const fat32_dirent_t *ents, int n,
                        const char *name, u32 *size, u32 *cluster, u8 *attr)
{
    for (int i = 0; i < n; i++) {
        if (strcmp(ents[i].name, name) == 0) {
            if (size) *size = ents[i].size;
            if (cluster) *cluster = ents[i].first_cluster;
            if (attr) *attr = ents[i].attr;
            return 1;
        }
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: %s image\n", argv[0]); return 2; }
    if (!load_image(argv[1])) { printf("FAIL: образ не читается\n"); return 2; }

    CHECK(exfat_probe(g_img) == 1, "probe распознал exFAT");

    CHECK(exfat_mount(host_rd, host_wr) == 1, "монтирование");
    CHECK(exfat_ready() == 1, "ready после mount");
    CHECK(strcmp(exfat_label(), "TESTVOL") == 0, "метка тома TESTVOL");

    /* ---- список корня ---- */
    fat32_dirent_t ents[32];
    int n = exfat_list(0, ents, 32);
    CHECK(n == 3, "в корне 3 объекта (hello.txt, данные.dat, docs)");
    u32 sz = 0, cl = 0, data_cl = 0; u8 attr = 0;
    CHECK(find_in_list(ents, n, "hello.txt", &sz, &cl, &attr) && sz == 56,
          "hello.txt в списке, размер 56");
    CHECK(find_in_list(ents, n, "данные.dat", &sz, &data_cl, &attr) && sz == 5000,
          "данные.dat в списке (кириллица), размер 5000");
    CHECK(find_in_list(ents, n, "docs", &sz, &cl, &attr) && (attr & 0x10),
          "docs — каталог (attr 0x10)");

    /* ---- чтение ---- */
    {
        u8 buf[6000];
        u32 got = exfat_read_file(data_cl, 5000, buf, sizeof(buf));
        CHECK(got == 5000, "данные.dat прочитан целиком");
        int eq = got == 5000;
        for (u32 i = 0; eq && i < 5000; i++)
            if (buf[i] != (u8)((i * 7 + 3) & 0xFF)) eq = 0;
        CHECK(eq, "содержимое данные.dat совпадает байт-в-байт");
    }
    {
        fat32_dirent_t h;
        CHECK(exfat_find_entry(0, "HELLO.TXT", &h) == 1,
              "поиск HELLO.TXT без учёта регистра");
        char buf[128];
        u32 got = exfat_read_file(h.first_cluster, h.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == 56 && memcmp(buf, "Hello, exFAT!\n", 14) == 0,
              "содержимое hello.txt корректно");
    }

    /* ---- каталог docs ---- */
    {
        fat32_dirent_t d;
        CHECK(exfat_find_entry(0, "docs", &d) == 1 && (d.attr & 0x10),
              "docs найден");
        fat32_dirent_t sub[8];
        int sn = exfat_list(d.first_cluster, sub, 8);
        CHECK(sn == 1 && strcmp(sub[0].name, "readme.md") == 0,
              "docs содержит readme.md");
    }

    /* ---- создание + запись нового файла ---- */
    {
        const char *msg = "Файл создан из N2600-OS (запись в exFAT).\n";
        u32 len = (u32)strlen(msg);
        u32 rc = exfat_write_file(0, "new.txt", msg, len);
        CHECK(rc == len, "запись new.txt (создание)");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "new.txt", &e) == 1 && e.size == len,
              "new.txt присутствует с верным размером");
        char buf[128];
        u32 got = exfat_read_file(e.first_cluster, e.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == len && memcmp(buf, msg, len) == 0,
              "прочитано ровно то, что записано");
    }

    /* ---- перезапись существующего ---- */
    {
        const char *msg2 = "Overwritten!";
        u32 rc = exfat_write_file(0, "hello.txt", msg2, 12);
        CHECK(rc == 12, "перезапись hello.txt");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "hello.txt", &e) == 1 && e.size == 12,
              "hello.txt имеет новый размер 12");
        char buf[32];
        u32 got = exfat_read_file(e.first_cluster, e.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == 12 && strcmp(buf, "Overwritten!") == 0,
              "содержимое после перезаписи верно");
    }

    /* ---- mkdir + файл в подкаталоге ---- */
    {
        CHECK(exfat_mkdir(0, "sub") == 1, "mkdir sub");
        fat32_dirent_t d;
        CHECK(exfat_find_entry(0, "sub", &d) == 1 && (d.attr & 0x10),
              "sub найден как каталог");
        u32 rc = exfat_write_file(d.first_cluster, "вложенный.txt",
                                  "nested", 6);
        CHECK(rc == 6, "запись в подкаталог (вложенный.txt)");
        fat32_dirent_t sub[8];
        int sn = exfat_list(d.first_cluster, sub, 8);
        CHECK(sn == 1 && strcmp(sub[0].name, "вложенный.txt") == 0,
              "вложенный.txt виден в списке sub");
    }

    /* ---- удаление ---- */
    {
        CHECK(exfat_delete(0, "new.txt") == 1, "удаление new.txt");
        fat32_dirent_t ents2[32];
        int n2 = exfat_list(0, ents2, 32);
        CHECK(!find_in_list(ents2, n2, "new.txt", NULL, NULL, NULL),
              "new.txt исчез из списка");
        CHECK(exfat_delete(0, "docs") == 0, "непустой docs удалить НЕЛЬЗЯ");
        fat32_dirent_t d;
        CHECK(exfat_find_entry(0, "docs", &d) == 1, "docs остался на месте");
        fat32_dirent_t r;
        CHECK(exfat_find_entry(d.first_cluster, "readme.md", &r) == 1 &&
              exfat_delete(d.first_cluster, "readme.md") == 1,
              "удаление readme.md внутри docs");
        CHECK(exfat_delete(0, "docs") == 1, "теперь пустой docs удаляется");
    }

    /* ---- перемонтирование: состояние на диске консистентно ---- */
    {
        exfat_detach();
        CHECK(exfat_mount(host_rd, host_wr) == 1, "перемонтирование после записи");
        fat32_dirent_t ents3[32];
        int n3 = exfat_list(0, ents3, 32);
        CHECK(find_in_list(ents3, n3, "hello.txt", NULL, NULL, NULL),
              "после ремоунта hello.txt на месте");
        CHECK(find_in_list(ents3, n3, "sub", NULL, NULL, NULL),
              "после ремоунта sub на месте");
        CHECK(!find_in_list(ents3, n3, "new.txt", NULL, NULL, NULL),
              "после ремоунта new.txt удалён");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "hello.txt", &e) == 1 && e.size == 12,
              "размер hello.txt после ремоунта = 12");
        char buf[32];
        u32 got = exfat_read_file(e.first_cluster, e.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == 12 && strcmp(buf, "Overwritten!") == 0,
              "содержимое hello.txt после ремоунта верно");
    }

    /* сохранить итоговый образ для питон-проверок структур на диске */
    if (argc >= 3) {
        FILE *o = fopen(argv[2], "wb");
        if (o) {
            fwrite(g_img, 1, g_img_size, o);
            fclose(o);
        }
    }

    printf(fails ? "\nИТОГ: %d ПРОВАЛ(ОВ)\n" : "\nИТОГ: ВСЕ ТЕСТЫ ПРОШЛИ\n",
           fails);
    return fails ? 1 : 0;
}
