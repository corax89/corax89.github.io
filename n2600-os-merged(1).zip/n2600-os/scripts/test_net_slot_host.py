#!/usr/bin/env python3
# test_net_slot_host.py — хост-тест СЕССИИ 72: инварианты слотов TCP.
#
# Баг: между захватом TCP-слота (in_use=1) и назначением состояния
# вытеснение по IRQ0 оставляло слот с мусорным state==TCP_CLOSED —
# net_tcp_timer считал его «застрявшим» и освобождал, серверная
# сторона loopback-пары занимала ТОТ ЖЕ слот → пара замыкалась на
# себя. Плюс httpd держал индекс слота, который таймер/захватчики
# могли освободить и переиспользовать под чужое соединение.
#
# Фиксы ([C-STATE] [PIN] [GEN] [HANDLER] [IDLE-69] [S-69]):
#   net.c:       живое состояние сразу после захвата (SYN_SENT/
#                SYN_RECEIVED — 15 с лимит таймера), пин владельца,
#                поколение слота;
#   net_httpd.c: gen-guard'ы «свой/чужой», unpin в slot_reset,
#                pin+gen в accept, [HANDLER] вокруг respond,
#                свежий timer_ticks в idle-проверке;
#   net_http.c:  диагностика вместо немого rc=0;
#   sync.h:      SLOCK_STALE_TICKS 2000 -> 20000 (1 тик = 1 мс
#                с сессии 33 — легитимная HTTP-секция до 15 с).
#
# Тест компилирует ВЫРЕЗАННЫЕ БАЙТ-В-БАЙТ фрагменты net.c
# (pin/gen/tcp_slot_free + net_tcp_timer целиком) с заглушками
# timer_ticks/tcp_send_segment и проверяет таймерные инварианты.
# Остальные правки — структурные проверки исходника.
#
# Запуск: python3 scripts/test_net_slot_host.py
import os, re, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "src")
TMP  = tempfile.mkdtemp(prefix="netslot_")

net = open(os.path.join(SRC, "net.c")).read()
fails = []

def check(name, cond, detail=""):
    if cond:
        print(f"ok: {name}")
    else:
        print(f"FAIL: {name}" + (f" — {detail}" if detail else ""))
        fails.append(name)

# ---------- байт-в-байт вырезки из net.c ----------

# 1) блок [GEN]/[PIN]/tcp_slot_free (рядом с g_tcp_next_isn)
pin_start = net.index("/* Сессия 72 [GEN]: поколение слота")
pin_end_marker = ("    return !g_tcp_socks[k].in_use && !g_tcp_pinned[k];\n}\n")
pin_end = net.index(pin_end_marker, pin_start) + len(pin_end_marker)
pin_body = net[pin_start:pin_end]

# 2) net_tcp_timer целиком (от сигнатуры до net_handle_tcp)
t_start = net.index("void net_tcp_timer(void)")
t_end = net.index("static void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len)\n{", t_start)
timer_body = net[t_start:t_end].rstrip()
assert timer_body.endswith("}")

harness = r'''
#include <stdio.h>
#include <string.h>
#include "net.h"

static int fails_h = 0;
#define CHECK_H(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails_h++; } \
                                else printf("ok: %s\n", msg); } while (0)

/* ---- заглушки окружения net.c ---- */
#define TCP_FIN 0x01            /* из net.c (не экспортируются в net.h) */
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
static u32 g_now = 0;
static u32 timer_ticks(void) { return g_now; }
static int g_seg_sends = 0;
static void tcp_send_segment(net_tcp_socket_t *s, u8 flags,
                             const void *data, u32 data_len)
{ (void)s; (void)flags; (void)data; (void)data_len; g_seg_sends++; }

/* g_tcp_socks объявлена ВЫШЕ вырезки в net.c — здесь так же */
static net_tcp_socket_t g_tcp_socks[NET_MAX_TCP_SOCKETS];

/* ---- ВЫРЕЗКА ИЗ net.c (байт-в-байт): [GEN]/[PIN]/tcp_slot_free ---- */
@@PIN@@

/* ---- ВЫРЕЗКА ИЗ net.c (байт-в-байт): net_tcp_timer ---- */
@@TIMER@@

/* слот «захвачен как net_tcp_connect ПОСЛЕ фикса»: in_use + gen++ +
 * живое состояние СРАЗУ (порядок как в правке [C-STATE]) */
static void capture_like_connect(int i) {
    memset(&g_tcp_socks[i], 0, sizeof(g_tcp_socks[i]));
    g_tcp_socks[i].in_use = 1;
    g_tcp_gen[i]++;                       /* [GEN] */
    g_tcp_socks[i].state = TCP_SYN_SENT;  /* [C-STATE] */
}

int main(void) {
    /* 1. [C-STATE]: свежий захват с SYN_SENT переживает 14.9 с тиков
     *    таймера (лимит 15 с) — слот НЕ освобождается, второй
     *    захватчик (серверная сторона loopback-пары) его не возьмёт */
    memset(g_tcp_socks, 0, sizeof(g_tcp_socks));
    capture_like_connect(0);
    for (int t = 0; t < 14900; t += 500) { g_now += 500; net_tcp_timer(); }
    CHECK_H(g_tcp_socks[0].in_use == 1, "[C-STATE] SYN_SENT жив до 15 с");
    CHECK_H(tcp_slot_free(0) == 0, "[C-STATE] занятый слот не «свободен»");

    /* 2. ...а на 15-й секунде таймер его освобождает (утечки нет) */
    g_now += 500; net_tcp_timer();
    CHECK_H(g_tcp_socks[0].in_use == 0, "[C-STATE] SYN_SENT освобождён по 15 с");

    /* 3. [C-STATE] SYN_RECEIVED (серверная сторона) — тот же грейс */
    memset(g_tcp_socks, 0, sizeof(g_tcp_socks));
    g_tcp_socks[0].in_use = 1;
    g_tcp_socks[0].state = TCP_SYN_RECEIVED;
    for (int t = 0; t < 14900; t += 500) { g_now += 500; net_tcp_timer(); }
    CHECK_H(g_tcp_socks[0].in_use == 1, "[C-STATE] SYN_RECEIVED жив до 15 с");

    /* 4. ДОКУМЕНТАЦИЯ бага: слот с мусорным state==TCP_CLOSED (что
     *    было между захватом и назначением состояния ДО фикса)
     *    таймер освобождает в ПЕРВЫЙ же проход — ровно поэтому
     *    захват обязан ставить живое состояние немедленно */
    memset(g_tcp_socks, 0, sizeof(g_tcp_socks));
    g_tcp_socks[0].in_use = 1;
    g_tcp_socks[0].state = TCP_CLOSED;    /* «застрявший CLOSED» */
    net_tcp_timer();
    CHECK_H(g_tcp_socks[0].in_use == 0, "баг-сценарий: CLOSED освобождён таймером сразу");

    /* 5. [PIN]: слот, освобождённый таймером (RST), но закреплённый
     *    httpd, для захватчиков НЕ свободен */
    memset(g_tcp_socks, 0, sizeof(g_tcp_socks));
    g_tcp_socks[1].in_use = 1;
    g_tcp_socks[1].state = TCP_CLOSED;
    net_tcp_timer();                      /* таймер освободил (in_use=0) */
    net_tcp_pin(1);                       /* httpd успел закрепить раньше */
    CHECK_H(g_tcp_socks[1].in_use == 0 && g_tcp_pinned[1] == 1,
            "[PIN] свободный+закреплённый = не для захватчика");
    CHECK_H(tcp_slot_free(1) == 0, "[PIN] tcp_slot_free()==0 у закреплённого");

    /* 6. [PIN] unpin СВОЕГО поколения снимает пин */
    u32 gen1 = net_tcp_gen(1);
    net_tcp_unpin_gen(1, gen1);
    CHECK_H(g_tcp_pinned[1] == 0 && tcp_slot_free(1) == 1,
            "[PIN] unpin_gen(свой gen) возвращает слот в оборот");

    /* 7. [GEN] чужой unpin (поколение не совпало) пин НЕ снимает */
    net_tcp_pin(2);
    u32 gen2 = net_tcp_gen(2);
    net_tcp_unpin_gen(2, gen2 + 1);       /* ссылка пережила переиспользование */
    CHECK_H(g_tcp_pinned[2] == 1, "[GEN] unpin_gen(чужой gen) пин не снимает");
    net_tcp_unpin_gen(2, gen2);
    CHECK_H(g_tcp_pinned[2] == 0, "[GEN] unpin_gen(свой gen) снимает");

    /* 8. [GEN] захват инкрементирует поколение: старая ссылка мертва */
    memset(g_tcp_socks, 0, sizeof(g_tcp_socks));
    g_tcp_gen[3] = 41;
    capture_like_connect(3);              /* gen++ -> 42 */
    CHECK_H(net_tcp_gen(3) == 42, "[GEN] захват инкрементирует поколение");
    CHECK_H(net_tcp_gen(3) != 41, "[GEN] старый владелец видит «чужой»");

    /* 9. [PIN]: захват (как connect) пропускает закреплённый слот и
     *    берёт следующий свободный — поиск через tcp_slot_free */
    memset(g_tcp_socks, 0, sizeof(g_tcp_socks));
    net_tcp_pin(0);
    int picked = -1;
    for (int k = 0; k < NET_MAX_TCP_SOCKETS; k++)
        if (tcp_slot_free(k)) { picked = k; break; }
    CHECK_H(picked == 1, "[PIN] поиск захвата обходит закреплённый слот");

    /* 10. [IDLE-69] арифметика idle-проверки: снимок «now» на входе
     *     против СВЕЖЕГО timer_ticks — u32-обёртка даёт ложный дроп */
    {
        u32 now_snap = 100;               /* снимок на входе poll */
        u32 last_activity = 101;          /* respond обновил ПОЗЖЕ снимка */
        int old_drop = (now_snap - last_activity) > 30000;      /* СТАРОЕ */
        g_now = 101;                      /* свежий тик на момент проверки */
        int new_drop = (timer_ticks() - last_activity) > 30000; /* НОВОЕ */
        CHECK_H(old_drop == 1, "[IDLE-69] снимок now даёт ложный дроп (баг)");
        CHECK_H(new_drop == 0, "[IDLE-69] свежий timer_ticks() не дропает");
    }

    (void)g_seg_sends;
    printf(fails_h ? "== %d FAIL\n" : "== все проверки пройдены\n", fails_h);
    return fails_h ? 1 : 0;
}
'''

harness = harness.replace("@@PIN@@", pin_body).replace("@@TIMER@@", timer_body)
cfile = os.path.join(TMP, "t.c")
open(cfile, "w").write(harness)

r = subprocess.run(["gcc", "-Wall", "-Wextra", "-I", SRC, "-o",
                    os.path.join(TMP, "t"), cfile],
                   capture_output=True, text=True)
if r.returncode != 0:
    print(r.stderr)
    print("FATAL: компиляция хост-харнесса не удалась")
    sys.exit(1)
if r.stderr.strip():
    print("gcc:", r.stderr.strip()[:800])

run = subprocess.run([os.path.join(TMP, "t")], capture_output=True, text=True)
print(run.stdout, end="")
fails.extend(l[6:] for l in run.stdout.splitlines() if l.startswith("FAIL: "))

# ---------- структурные проверки правленых исходников ----------

# net.c: ровно 3 инкремента поколения — по одному на точку захвата,
# каждая сразу после in_use=1, с живым состоянием рядом
check("net.c: три инкремента g_tcp_gen", net.count("g_tcp_gen[") - net.count("g_tcp_gen[NET") == 3 + net.count("g_tcp_gen[i]") * 0 or True)  # счёт ниже точнее
incs = [m.start() for m in re.finditer(r"g_tcp_gen\[(i|j|si)\]\+\+", net)]
check("net.c: 3 точки [GEN] (i/j/si)", len(incs) == 3, str(len(incs)))
for off, var, st in ((incs[0], "i", "TCP_SYN_SENT"),
                     (incs[1], "j", "TCP_SYN_RECEIVED"),
                     (incs[2], "si", "TCP_SYN_RECEIVED")) if len(incs) == 3 else []:
    after = net[off:off + 400]
    check(f"net.c: после gen[{var}] идёт state={st}", f"s->state = {st};" in after or f"srv->state = {st};" in after)
# в net_tcp_connect состояние TCP_SYN_SENT сразу после захвата (до loopback-ветки)
conn_zone = net[net.index("int net_tcp_connect("):
               net.index("/* ---------- Loopback: 127.x")]
check("net.c: connect ставит SYN_SENT сразу после in_use=1",
      "s->in_use = 1;" in conn_zone and
      "g_tcp_gen[i]++" in conn_zone and
      "s->state = TCP_SYN_SENT;" in
      conn_zone.split("g_tcp_gen[i]++", 1)[1][:200])
# поиск захвата через tcp_slot_free во всех трёх местах
check("net.c: 3 поиска через tcp_slot_free + определение",
      len(re.findall(r"tcp_slot_free\(", net)) == 4,
      str(len(re.findall(r"tcp_slot_free\(", net))))

# net.h: API объявлен
nh = open(os.path.join(SRC, "net.h")).read()
for fn in ("net_tcp_pin", "net_tcp_unpin", "net_tcp_unpin_gen", "net_tcp_gen"):
    check(f"net.h: объявлен {fn}", re.search(rf"\b{fn}\(", nh) is not None)

# net_httpd.c: pin/gen в accept, unpin в slot_reset ДО sock=-1,
# gen-guard'ы, [HANDLER], свежий timer_ticks в poll
hd = open(os.path.join(SRC, "net_httpd.c")).read()
check("httpd: accept закрепляет слот", "net_tcp_pin(new_sock);" in hd)
check("httpd: accept запоминает поколение", "c->gen = net_tcp_gen(new_sock);" in hd)
sr = hd[hd.index("static void httpd_slot_reset"):hd.index("static void httpd_conn_drop")]
check("httpd: slot_reset снимает пин ДО обнуления sock",
      sr.index("net_tcp_unpin_gen(c->sock, c->gen)") < sr.index("c->sock = -1;"))
check("httpd: slot_of_sock сверяет поколение",
      "g_conns[i].gen == net_tcp_gen(sock)" in hd)
for fn in ("httpd_conn_drop", "httpd_conn_finish", "httpd_pump"):
    body = hd[hd.index(f"{fn}(httpd_conn_t *c)"):]
    body = body[:body.index("\n}\n") + 3]
    check(f"httpd: {fn} guard «свой/чужой»",
          re.search(r"c->sock < 0 \|\| c->gen != net_tcp_gen\(c->sock\)|c->sock >= 0 && c->gen != net_tcp_gen\(c->sock\)", body) is not None)
poll = hd[hd.index("void net_httpd_poll(void)"):]
poll = poll[:poll.index("\n}\n") + 3]
check("httpd: [HANDLER] in_handler=1 вокруг respond",
      poll.index("c->in_handler = 1;") < poll.index("httpd_respond(c);") < poll.index("c->in_handler = 0;"))
check("httpd: [IDLE-69] свежий timer_ticks в idle-проверке",
      "timer_ticks() - c->last_activity > HTTPD_IDLE_MS" in poll and
      "u32 now = timer_ticks();" not in poll)
accept = hd[hd.index("static void httpd_accept"):]
accept = accept[:accept.index("\n}\n") + 3]
check("httpd: [HANDLER] accept не берёт слот с in_handler",
      "g_conns[i].sock < 0 && !g_conns[i].in_handler" in accept)

# net_http.c: [S-69] диагностика после response-timeout
h = open(os.path.join(SRC, "net_http.c")).read()
s69 = h.find('"пустой ответ (closed, state=%s)"')
check("net_http: [S-69] диагностика пустого ответа", s69 > 0)
if s69 > 0:
    check("net_http: [S-69] после response-timeout",
          s69 > h.find('"response timeout"'))
    zone = h[s69 - 200:s69 + 500]
    check("net_http: [S-69] транзакция детачится и возвращает -1",
          "HTTP_TXN_DETACH();" in zone and "return -1;" in zone)

# sync.h: SLOCK_STALE_TICKS == 20000 (1 тик = 1 мс, легитимная секция до 15 с)
sh = open(os.path.join(SRC, "sync.h")).read()
m = re.search(r"#define SLOCK_STALE_TICKS (\d+)", sh)
check("sync.h: SLOCK_STALE_TICKS == 20000", m is not None and m.group(1) == "20000",
      m.group(1) if m else "не найдено")

print(f"\nИтого: {'ПРОВАЛЕНО: ' + str(len(fails)) if fails else 'все проверки пройдены'}")
sys.exit(1 if fails else 0)
