/* smp.c — многоядерные/многопоточные (SMT) процессоры N2600-OS.
 *
 * АРХИТЕКТУРА (сессия 74):
 *
 *   BSP (ядро 0)                AP (ядра 1..N)
 *   ------------                ------------------------------------
 *   PIT IRQ0 -> планировщик     LAPIC-таймер 1000 Гц -> планировщик
 *   задачи с cpu==0             задачи, назначенные этому AP
 *   (task_schedule)             (task_ap_schedule + учёт загрузки)
 *   LAPIC ВКЛ на время SIPI,    замок: AP-задача исполняется под
 *   затем ВЫКЛ: путь PIC->      ядровым замком + маскировкой PIC,
 *   LINT0->INTR не меняется     каждые SMP_FAIR_TICKS тиков —
 *                               один тик отдаётся BSP
 *
 * СЕССИЯ 75: задачи размещаются по наименее загруженному онлайн-ядру
 * (task_pick_core) и ИСПОЛНЯЮТСЯ на своих ядрах. Взаимоисключение
 * kernel-кода задач — «ядровый замок» (smp_klock, cmpxchg-спинлок):
 * одновременно исполняется не более одной задачи во всей системе,
 * поэтому ВСЯ прежняя синхронизация (cli, s_lock, общие буферы)
 * сохраняет смысл. Замок передаётся при переключении контекста
 * (holds-флаг задачи), не выжигая циклы на unlock/lock.
 *
 * ДВА независимых базовых адреса LAPIC:
 *   g_lapic_base    — только код BSP (калибровка, IPI), обнуляется
 *                     при выключении LAPIC на BSP;
 *   g_apic_base_ap  — только AP-ядра: ставится BSP ОДИН раз ДО первого
 *                     SIPI и больше не меняется (иначе AP, уже
 *                     обслуживающий таймер, вдруг стал бы писать по
 *                     адресу 0 — порча нижней памяти).
 *
 * Запуск AP: trampoline в низкой памяти 0x7000 (ниже stage2 0x7E00):
 *   real mode -> lgdt (мини-GDT из патч-области 0x7100) -> CR0.PE ->
 *   far jump (патчится BSP по магии 0xDEADBEEF) -> smp_ap_pm_entry
 *   (32-bit: flat-сегменты, свой стек из патч-области) -> smp_ap_main.
 *
 * Трамплин НЕ содержит абсолютных ссылок на свой адрес: все адреса
 * либо относительные, либо из патч-области, либо заплачены BSP до SIPI
 * (в коде лежит магия 0xDEADBEEF вместо адреса 32-битного входа).
 *
 * Почему задачи пока не переезжают на другие ядра: ВСЯ синхронизация
 * ядра построена на cli() (куча, tasks[], fb, wm, драйверы). cli
 * глушит прерывания только СВОЕГО ядра — на SMP это не защита. Первый
 * же malloc с двух ядер = порча кучи. Поэтому в этой сессии: полная
 * поддержка железа (детект/запуск/учёт) + спин-блокировки (smp.h) для
 * следующих шагов, задачи — на BSP. Загрузка ядер честная: у AP это
 * «hlt + обработка собственного таймера», у BSP — планировщик.
 *
 * Учёт загрузки AP: LAPIC-таймер тикает 1000 раз/с. Если в момент тика
 * ядро спало в hlt (in_hlt=1) — idle-тик, иначе busy-тик. Раз в 1000
 * тиков (1 с) фиксируется load_pct = busy/total. Хвост «между hlt и
 * установкой in_hlt» засчитывается как busy — это честные ~0-1%
 * накладных расходов таймера.
 */
#include "smp.h"
#include "types.h"
#include "io.h"
#include "string.h"
#include "timer.h"
#include "gdt.h"
#include "idt.h"
#include "kernel.h"
#include "task.h"
#include <cpuid.h>

extern void serial_puts(const char *s);
extern void serial_putc(char c);

/* ---------------- конфигурация ---------------- */
#define SMP_TRAMP_ADDR   0x7000u   /* ниже stage2 (0x7E00) и MBI (0x500) */
#define SMP_TRAMP_SIZE   64u       /* байт трамплина копируем с запасом  */
#define SMP_PATCH_OFF    0x100u    /* патч-область: +0x100               */
#define SMP_GDT_OFF      0x180u    /* мини-GDT:      +0x180              */
#define SMP_AP_STACK     8192u     /* стек простоя AP                    */
#define SMP_LOAD_WINDOW  1000u     /* тиков LAPIC-таймера в окне = 1 с   */

#define LAPIC_TIMER_VEC  0x60u     /* вектор LAPIC-таймера AP (свободен) */
#define LAPIC_SPUR_VEC   0xEFu     /* вектор ложных прерываний           */

/* смещения регистров LAPIC (xAPIC MMIO) */
#define LAPIC_ID         0x020u
#define LAPIC_VERSION    0x030u
#define LAPIC_TPR        0x080u
#define LAPIC_EOI        0x0B0u
#define LAPIC_SPURIOUS   0x0F0u
#define LAPIC_ICR_LO     0x300u
#define LAPIC_ICR_HI     0x310u
#define LAPIC_LVT_TIMER  0x320u
#define LAPIC_LVT_LINT0  0x350u
#define LAPIC_LVT_LINT1  0x360u
#define LAPIC_LVT_ERROR  0x370u
#define LAPIC_ICOUNT     0x380u
#define LAPIC_CCOUNT     0x390u
#define LAPIC_DIVIDE     0x3E0u
#define LAPIC_ICR_INIT   0x4500u   /* delivery INIT, assert, phys       */
#define LAPIC_ICR_SIPI   0x4600u   /* delivery StartUp, level=1, phys   */

/* Трамплин в asm ЖЁСТКО привязан к 0x7000 (disp16 в lgdt, absolute
 * 0x7100/0x7104 в pm-входе) — зафиксируем это на этапе компиляции. */
STATIC_ASSERT(SMP_TRAMP_ADDR == 0x7000u, tramp_addr_fixed);
STATIC_ASSERT(SMP_TRAMP_ADDR + SMP_PATCH_OFF == 0x7100u, tramp_patch_at_7100);
STATIC_ASSERT(SMP_TRAMP_ADDR + SMP_PATCH_OFF + 8u == 0x7108u, tramp_gdtr_at_7108);
STATIC_ASSERT(SMP_TRAMP_ADDR + SMP_GDT_OFF == 0x7180u, tramp_gdt_at_7180);

/* ---------------- per-CPU данные ---------------- */
typedef struct {
    volatile u32 online;      /* 1 = ядро завершило инициализацию   */
    u32          apic_id;     /* аппаратный APIC ID                 */
    volatile u32 in_hlt;      /* 1 = ядро спит в hlt                */
    volatile u32 busy_acc;    /* busy-тики в текущем окне           */
    volatile u32 idle_acc;    /* idle-тики в текущем окне           */
    volatile u32 load_pct;    /* загрузка за последнее окно, %      */
    u32          stack_top;   /* вершина стека (диагностика)        */
    volatile u32 idle_esp;    /* сохранённый кадр idle-цикла (AP)   */
} smp_cpu_t;

static smp_cpu_t smp_cpus[SMP_MAX_CPUS];
static int       g_cpu_count = 1;   /* обнаружено (включая BSP)       */
static int       g_online    = 1;   /* запущено (включая BSP)         */
static int       g_topo_cores   = 1;
static int       g_topo_threads = 1;
static int       g_smp_ready    = 0;
static int       s_apic_present = 0;
static u32       g_lapic_base   = 0; /* база LAPIC — ТОЛЬКО код BSP    */
static u32       g_apic_base_ap = 0; /* база LAPIC — ТОЛЬКО AP-ядра    */
static u32       g_lapic_ticks_per_ms = 0;

/* ---------------- ядровый замок (сессия 75) ----------------
 * 0 = свободен, 1 = захвачен. Захватывает ядро-исполнитель задачи;
 * учёт «чьего» замка — holds-флаг задачи в task.c (замок передаётся
 * при переключении контекста без unlock/lock). */
volatile int smp_klock = 0;

/* PIC-маска на время исполнения AP-задачи: сохранённый IMR + признак.
 *
 * СЕССИЯ 78 [PIC-IRQ0]: раньше маскировалось ВСЁ (0xFF/0xFF), включая
 * IRQ0 — пока AP-задача держала ядровый замок, BSP оставался без тиков:
 * планировщик не вызывался, ватчдог стоял, sti;hlt ожиданий не будились.
 * Зависшая AP-задача = гарантированное мёртвое зависание ВСЕЙ системы
 * (никто не мог ни убить виновника, ни отобрать замок). Теперь IRQ0
 * НАМЕРЕННО остаётся незамаскированным (master IMR = saved | 0xFE):
 * тики BSP продолжаются под AP-задачей, ожидания с hlt просыпаются,
 * ватчдог работает. Обработчик IRQ0 (task_schedule) при занятом замке
 * просто НЕ переключает задачи (smp_klock_try неудача) и не трогает
 * драйверы — пересечений с AP-кодом нет, как и раньше. */
static u8  s_pic_imr_saved[2] = { 0xFF, 0xFF };
static int s_pic_masked       = 0;    /* 1 = маскировано нами         */

void smp_pic_mask(void)
{
    if (s_pic_masked) return;
    s_pic_imr_saved[0] = inb(0x21);
    s_pic_imr_saved[1] = inb(0xA1);
    outb(0x21, (u8)(s_pic_imr_saved[0] | 0xFE));   /* всё, КРОМЕ IRQ0 */
    outb(0xA1, 0xFF);
    s_pic_masked = 1;
}

void smp_pic_restore(void)
{
    if (!s_pic_masked) return;
    outb(0x21, s_pic_imr_saved[0]);
    outb(0xA1, s_pic_imr_saved[1]);
    s_pic_masked = 0;
}

static u8 smp_ap_stacks[SMP_MAX_CPUS - 1][SMP_AP_STACK]
        __attribute__((aligned(16)));

/* ---------------- MSR (копия логики kernel.c — там static) ---------------- */
static void msr_write(u32 msr, u64 v)
{
    __asm__ __volatile__("wrmsr"
                         :: "c"(msr), "a"((u32)v), "d"((u32)(v >> 32))
                         : "memory");
}

static u64 msr_read(u32 msr)
{
    u32 lo, hi;
    __asm__ __volatile__("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((u64)hi << 32) | (u64)lo;
}

/* ---------------- LAPIC MMIO ----------------
 * ВАЖНО: чтение/запись через g_lapic_base (BSP) или g_apic_base_ap
 * (AP) — НИКОГДА не наоборот. Выбор базы задаётся тем, чей код идёт:
 * всё до запуска AP и после их запуска на BSP — g_lapic_base; всё,
 * что исполняется НА AP (smp_ap_main, ap_timer_irq_c), — только
 * g_apic_base_ap, который BSP больше не трогает. */
static inline u32 lapic_read_bsp(u32 reg)
{
    return *(volatile u32 *)(unsigned long)(g_lapic_base + reg);
}

static inline void lapic_write_bsp(u32 reg, u32 v)
{
    *(volatile u32 *)(unsigned long)(g_lapic_base + reg) = v;
}

static inline u32 lapic_read_ap(u32 reg)
{
    return *(volatile u32 *)(unsigned long)(g_apic_base_ap + reg);
}

static inline void lapic_write_ap(u32 reg, u32 v)
{
    *(volatile u32 *)(unsigned long)(g_apic_base_ap + reg) = v;
}

/* ---------------- лог ---------------- */
static void smp_log(const char *s)
{
    serial_puts("[smp] ");
    serial_puts(s);
    serial_putc('\n');
    klog_puts(s);
}

/* =====================================================================
 * 1. Топология CPU (CPUID: листья 1, 4, 0x0B)
 * ===================================================================== */
static void smp_detect_topology(void)
{
    unsigned a, b, c, d;
    unsigned max_leaf = 0;
    unsigned logical  = 1;
    unsigned tpc      = 1;      /* потоков на ядро (SMT)   */
    unsigned cores    = 1;
    int      apic_ok  = 0;

    if (__get_cpuid(0, &max_leaf, &b, &c, &d)) {
        if (__get_cpuid(1, &a, &b, &c, &d)) {
            apic_ok = (int)((d >> 9) & 1);          /* APIC present   */
            unsigned ml = (b >> 16) & 0xFF;         /* max logical/pk */
            if (ml) logical = ml;
        }
    }
    cores = logical;

    /* лист 0x0B (x2APIC-топология): уровень 0 = SMT (EBX = потоков
     * на ядро), уровень 1 = ядро (EBX = логических ЦП на пакет) */
    if (max_leaf >= 0x0B) {
        unsigned a0, b0, c0, d0, a1, b1, c1, d1;
        __cpuid_count(0x0B, 0, a0, b0, c0, d0);
        __cpuid_count(0x0B, 1, a1, b1, c1, d1);
        if (b1) {
            unsigned lpp = b1;
            unsigned t  = b0 ? b0 : 1;
            unsigned co = lpp / t;
            if (co == 0) co = 1;
            if (lpp > logical) logical = lpp;
            tpc   = t;
            cores = co;
        }
    }
    /* запасной путь: лист 4 (параметры кэша) — физических ядер */
    if (cores == logical && max_leaf >= 4) {
        unsigned a4, b4, c4, d4;
        __cpuid_count(4, 0, a4, b4, c4, d4);
        unsigned cper = ((a4 >> 26) & 0x3F) + 1;
        if (cper > 1 && cper <= logical) {
            cores = cper;
            tpc   = logical / cper;
            if (tpc == 0) tpc = 1;
        }
    }

    g_topo_cores   = (int)cores;
    g_topo_threads = (int)tpc;
    g_cpu_count    = (int)logical;
    s_apic_present = apic_ok;
}

/* =====================================================================
 * 2. ACPI: RSDP -> RSDT/XSDT -> MADT (список реальных APIC ID)
 * ===================================================================== */
static int rsdp_checksum_ok(const u8 *p)
{
    u8 sum = 0;
    for (int i = 0; i < 20; i++) sum += p[i];
    return sum == 0;
}

/* Найти RSDP: EBDA (слово 0x40E) и область 0xE0000..0xFFFFF, шаг 16 */
static const u8 *rsdp_find(void)
{
    u32 ebda = ((u32)*(const volatile u16 *)0x40E) << 4;
    if (ebda >= 0x400 && ebda < 0x9F000) {
        for (u32 a = ebda; a + 20 <= ebda + 0x400; a += 16) {
            const u8 *p = (const u8 *)(unsigned long)a;
            if (p[0] == 'R' && p[1] == 'S' && p[2] == 'D' && p[3] == ' ' &&
                p[4] == 'P' && p[5] == 'T' && p[6] == 'R' && p[7] == ' ' &&
                rsdp_checksum_ok(p))
                return p;
        }
    }
    for (u32 a = 0xE0000; a + 20 <= 0xFFFFF; a += 16) {
        const u8 *p = (const u8 *)(unsigned long)a;
        if (p[0] == 'R' && p[1] == 'S' && p[2] == 'D' && p[3] == ' ' &&
            p[4] == 'P' && p[5] == 'T' && p[6] == 'R' && p[7] == ' ' &&
            rsdp_checksum_ok(p))
            return p;
    }
    return 0;
}

/* Пройти таблицу-контейнер (RSDT: u32-записи, XSDT: u64-записи) и
 * вернуть указатель на таблицу с сигнатурой sig4, либо 0. */
static const u8 *find_table(const u8 *root, const char *sig4)
{
    if (!root) return 0;
    u32 len = *(const u32 *)(root + 4);
    if (len < 40 || len > 0x40000) return 0;
    int is_xsdt = (root[0] == 'X');
    u32 off = 36;
    while (off + (u32)(is_xsdt ? 8 : 4) <= len) {
        u32 ent;
        if (is_xsdt)
            ent = (u32)*(const u64 *)(root + off);
        else
            ent = *(const u32 *)(root + off);
        if (ent) {
            const u8 *t = (const u8 *)(unsigned long)ent;
            if (t[0] == sig4[0] && t[1] == sig4[1] &&
                t[2] == sig4[2] && t[3] == sig4[3])
                return t;
        }
        off += is_xsdt ? 8 : 4;
    }
    return 0;
}

/* Разбор MADT: собрать APIC ID включённых LAPIC-записей.
 * Возвращает число найденных (0 = MADT не найден/не разобран). */
static int madt_scan(u8 *ids, int max)
{
    const u8 *rsdp = rsdp_find();
    if (!rsdp) return 0;

    const u8 *madt = find_table((const u8 *)(unsigned long)
                                *(const u32 *)(rsdp + 16), "APIC");
    if (!madt && rsdp[15] >= 2) {
        /* ACPI 2.0+: запасной путь через XSDT (u64-адрес @24) */
        u64 xsdt = *(const u64 *)(rsdp + 24);
        if (xsdt && xsdt < 0x100000000ULL)
            madt = find_table((const u8 *)(unsigned long)xsdt, "APIC");
    }
    if (!madt) return 0;

    u32 tlen = *(const u32 *)(madt + 4);
    if (tlen < 44 || tlen > 0x10000) return 0;

    /* начало записей: ACPI 1.0 = 40 (без поля flags), ACPI 2.0+ = 44.
     * Не верим ревизии — валидируем структуру: записи имеют тип <= 5,
     * длину >= 2 и укладываются в таблицу. */
    static const u32 starts[2] = { 44, 40 };
    for (int si = 0; si < 2; si++) {
        u32 off = starts[si];
        int  n  = 0;
        int  ok = 1;
        while (off + 2 <= tlen) {
            u8 type = madt[off];
            u8 elen = madt[off + 1];
            if (elen < 2 || off + elen > tlen || type > 5) { ok = 0; break; }
            if (type == 0 && elen >= 8) {
                u32 flags = *(const u32 *)(madt + off + 4);
                if ((flags & 1) && n < max)
                    ids[n++] = madt[off + 3];    /* apic_id */
            }
            off += elen;
        }
        if (ok && n > 0) return n;
        /* не разобралось — пробуем альтернативное начало */
    }
    return 0;
}

/* =====================================================================
 * 3. LAPIC: включение/выключение на BSP, калибровка таймера
 * ===================================================================== */
static int lapic_bsp_enable(void)
{
    u64 msr = msr_read(0x1B);
    if (msr & (1ULL << 10)) {
        /* x2APIC-режим: вернуться в xAPIC через выключенное состояние
         * (MMIO-регистры в x2APIC недоступны) */
        msr_write(0x1B, msr & ~(u64)0xC00);
        msr = msr_read(0x1B);
        if (msr & (1ULL << 10)) return 0;      /* не получилось */
    }
    msr_write(0x1B, msr | 0x800ULL);           /* APIC global enable */
    u32 base = (u32)(msr_read(0x1B) & 0xFFFFF000ULL);
    if (!base) base = 0xFEE00000u;
    g_lapic_base = base;

    u32 ver = lapic_read_bsp(LAPIC_VERSION);
    if (ver == 0xFFFFFFFFu || ver == 0) {
        g_lapic_base = 0;
        msr_write(0x1B, msr & ~(u64)0x800);
        return 0;
    }
    lapic_write_bsp(LAPIC_SPURIOUS, LAPIC_SPUR_VEC | 0x100); /* sw enable */
    lapic_write_bsp(LAPIC_TPR, 0);
    lapic_write_bsp(LAPIC_LVT_LINT0, 0x700); /* ExtINT: PIC жив             */
    lapic_write_bsp(LAPIC_LVT_LINT1, 0x10000); /* LINT1 mask               */
    return 1;
}

/* ВЫКЛЮЧИТЬ LAPIC на BSP: LINT0 снова прямой вход INTR — путь
 * прерываний BSP становится ТОЧНО таким же, как до SMP (в обработчиках
 * IRQ0/IRQn ничего менять не нужно). AP-ядра держат СВОИ LAPIC
 * включёнными (у каждого ядра свой MSR 0x1B и СВОЯ база g_apic_base_ap,
 * которую BSP после этого не трогает). */
static void lapic_bsp_disable(void)
{
    if (!g_lapic_base) return;
    lapic_write_bsp(LAPIC_LVT_TIMER, 0x10000);
    lapic_write_bsp(LAPIC_LVT_LINT0, 0x10000);
    u64 msr = msr_read(0x1B);
    msr_write(0x1B, msr & ~(u64)0x800);
    g_lapic_base = 0;
}

/* Калибровка LAPIC-таймера по PIT каналу 2 (timer.c): 10 мс, делитель
 * 16. Выполняется на BSP, пока LAPIC включён, ДО sti — однопоточно. */
static void lapic_calibrate(void)
{
    lapic_write_bsp(LAPIC_DIVIDE, 0x3);                    /* делитель 16 */
    lapic_write_bsp(LAPIC_LVT_TIMER, LAPIC_TIMER_VEC | 0x10000); /* mask  */
    lapic_write_bsp(LAPIC_ICOUNT, 0xFFFFFFFFu);

    u32 t0 = timer_poll_deadline();
    while (!timer_poll_expired(t0, 10000)) { io_wait(); }   /* 10 мс */

    u32 elapsed = 0xFFFFFFFFu - lapic_read_bsp(LAPIC_CCOUNT);
    u32 per_ms  = elapsed / 10;               /* тиков (после /16) на 1 мс */
    if (per_ms == 0) per_ms = 1;
    g_lapic_ticks_per_ms = per_ms;
}

/* =====================================================================
 * 4. MTRR: скопировать конфигурацию BSP на AP (одинаковые атрибуты
 *    памяти; WC для LFB из mtrr_lfb_wc тоже переносится)
 * ===================================================================== */
static void mtrr_ap_copy(void)
{
    unsigned a, b, c, d;
    if (!__get_cpuid(1, &a, &b, &c, &d)) return;
    if (!((d >> 12) & 1)) return;               /* MTRR нет            */
    u64 def = msr_read(0x2FF);
    if (!((def >> 11) & 1)) return;             /* механизм выключен   */
    u32 nvar = (u32)(msr_read(0xFE) & 0xFF);    /* MTRRcap: число var  */
    if (nvar > 8) nvar = 8;

    static const u32 fixed[] = { 0x250, 0x258, 0x259,
                                 0x268, 0x269, 0x26A, 0x26B,
                                 0x26C, 0x26D, 0x26E, 0x26F };
    for (unsigned i = 0; i < sizeof(fixed) / sizeof(fixed[0]); i++)
        msr_write(fixed[i], msr_read(fixed[i]));
    for (u32 i = 0; i < nvar; i++) {
        msr_write(0x200 + i * 2, msr_read(0x200 + i * 2));
        msr_write(0x201 + i * 2, msr_read(0x201 + i * 2));
    }
    msr_write(0x2FF, def);                      /* DEFTYPE — последним */
}

/* =====================================================================
 * 5. Трамплин AP (real mode, копируется в 0x7000)
 *
 *    Без абсолютных ссылок на свой адрес: lgdt читает псевдодескриптор
 *    из патч-области (DS=0,disp16), far jump несёт магию 0xDEADBEEF,
 *    которую BSP заменяет адресом smp_ap_pm_entry ДО отправки SIPI.
 * ===================================================================== */
__attribute__((naked, noinline, used, section(".text.tramp")))
static void smp_trampoline(void)
{
    __asm__ __volatile__(
        ".code16gcc\n\t"
        "cli\n\t"
        "cld\n\t"
        "xorw %ax, %ax\n\t"
        "movw %ax, %ds\n\t"
        "movw %ax, %es\n\t"
        "movw %ax, %ss\n\t"
        "movw $0x6FF0, %sp\n\t"        /* временный стек под трамплином */
        /* lgdtl [0x7108]: 66 0F 01 16 <disp16> */
        ".byte 0x66, 0x0F, 0x01, 0x16\n\t"
        ".word 0x7108\n\t"
        "movl %cr0, %eax\n\t"
        "orl $1, %eax\n\t"
        "movl %eax, %cr0\n\t"          /* PE=1 */
        /* far jump 0x08:<адрес из патча>: 66 EA <off32> <sel16> */
        ".byte 0x66, 0xEA\n\t"
        ".long 0xDEADBEEF\n\t"
        ".word 0x08\n\t"
        ".globl smp_trampoline_end\n\t"
        "smp_trampoline_end:\n\t"
        ".code32\n\t"
    );
}

/* Метка конца трамплина: asm-имя БЕЗ декорации — на MinGW переименовываем */
extern const u8 smp_trampoline_end[] __asm__("smp_trampoline_end");

/* 32-битный вход AP (исполняется уже на стеке патч-области):
 * flat-сегменты, esp/индекс из патч-области, вызов C-инициализации */
__attribute__((naked, noinline, used, section(".text.tramp2")))
static void smp_ap_pm_entry(void)
{
    __asm__ __volatile__(
        "movw $0x10, %ax\n\t"
        "movw %ax, %ds\n\t"
        "movw %ax, %es\n\t"
        "movw %ax, %ss\n\t"
        "movw %ax, %fs\n\t"
        "movw %ax, %gs\n\t"
        "movl 0x7100, %esp\n\t"        /* вершина стека этого AP     */
        "movl 0x7104, %eax\n\t"        /* индекс ядра                */
        "pushl %eax\n\t"
        "call _smp_ap_main\n\t"
        "1:\n\t"
        "hlt\n\t"
        "jmp 1b\n\t"
    );
}

/* Записать мини-GDT (null + flat code/data) и его псевдодескриптор */
static void tramp_write_gdt(void)
{
    volatile u8 *g = (volatile u8 *)(unsigned long)(SMP_TRAMP_ADDR + SMP_GDT_OFF);
    /* null */
    for (int i = 0; i < 8; i++) g[i] = 0;
    /* code: limit 0xFFFF, base 0, access 0x9A, gran 0xCF */
    *(volatile u32 *)(g + 8)  = 0x0000FFFFu;
    *(volatile u32 *)(g + 12) = 0x00CF9A00u;
    /* data: access 0x92 */
    *(volatile u32 *)(g + 16) = 0x0000FFFFu;
    *(volatile u32 *)(g + 20) = 0x00CF9200u;

    volatile u8 *gdtr = (volatile u8 *)(unsigned long)
                        (SMP_TRAMP_ADDR + SMP_PATCH_OFF + 0x08);
    *(volatile u16 *)gdtr = 23;                                     /* limit */
    *(volatile u32 *)(gdtr + 2) = SMP_TRAMP_ADDR + SMP_GDT_OFF;     /* base  */
}

/* Скопировать трамплин в 0x7000 и заплатить адрес 32-битного входа.
 * Возвращает 0, если магия не найдена (трамплин изменился) — тогда
 * SMP запускать НЕЛЬЗЯ: far jump ушёл бы по адресу 0xDEADBEEF. */
static int tramp_install(void)
{
    u32 size = (u32)(unsigned long)smp_trampoline_end -
               (u32)(unsigned long)&smp_trampoline;
    if (size == 0 || size > SMP_TRAMP_SIZE) size = SMP_TRAMP_SIZE;
    memcpy((void *)(unsigned long)SMP_TRAMP_ADDR, &smp_trampoline, size);

    tramp_write_gdt();

    /* магия 0xDEADBEEF -> адрес smp_ap_pm_entry. Сканируем ПОБАЙТНО:
     * магия в кодовом потоке НЕ выровнена на 4 байта (проверено на
     * реальном kernel.bin), dword-скан её не находит. */
    {
        volatile u8 *q = (volatile u8 *)(unsigned long)SMP_TRAMP_ADDR;
        int patched = 0;
        for (u32 i = 0; i + 4 <= SMP_TRAMP_SIZE; i++) {
            if (q[i]     == 0xEFu && q[i + 1] == 0xBEu &&
                q[i + 2] == 0xADu && q[i + 3] == 0xDEu) {
                *(volatile u32 *)(q + i) =
                    (u32)(unsigned long)&smp_ap_pm_entry;
                patched = 1;
                break;
            }
        }
        if (!patched) {
            /* магия потерялась (изменился трамплин) — SMP НЕ запускаем */
            smp_log("smp: патч трамплина не найден — SMP отключён");
            return 0;
        }
    }
    return 1;
}

/* Проверить по карте multiboot, что [0x7000..0x8000) — доступная RAM */
static int tramp_addr_ok(const mb_info_t *mb)
{
    if (!mb || !(mb->flags & MBIF_MMAP) || !mb->mmap_addr || !mb->mmap_length)
        return 1;                        /* карты нет — используем 0x7000 */
    const u8 *p   = (const u8 *)(unsigned long)mb->mmap_addr;
    const u8 *end = p + mb->mmap_length;
    while (p + 24 <= end) {
        const mb_mmap_t *e = (const mb_mmap_t *)p;
        if (e->type == 1 && e->addr <= SMP_TRAMP_ADDR &&
            SMP_TRAMP_ADDR + 0x1000 <= e->addr + e->len)
            return 1;
        p += e->size + 4;
    }
    return 0;
}

/* =====================================================================
 * 6. Сторона AP: C-инициализация и цикл простоя с учётом загрузки
 * ===================================================================== */

/* Обработчик LAPIC-таймера AP (глобальный: алиас _ap_timer_irq_c в
 * linker.ld — зовётся из ap_timer_stub). Выполняется НА AP: доступ к
 * LAPIC — строго через g_apic_base_ap.
 *
 * СЕССИЯ 75: помимо учёта загрузки и EOI — ПЛАНИРОВАНИЕ задач,
 * назначенных этому ядру (task_ap_schedule в task.c): сохранение/переключение
 * контекста, захват/освобождение ядрового замка, fair-share для BSP.
 * Возвращает ESP для iret (кадр задачи или idle-цикла). */
u32 ap_timer_irq_c(u32 saved_esp)
{
    u32 id = lapic_read_ap(LAPIC_ID) >> 24;
    smp_cpu_t *c = 0;
    int  my_core = 0;
    for (int i = 0; i < SMP_MAX_CPUS; i++) {
        if (smp_cpus[i].online && smp_cpus[i].apic_id == id) {
            c = &smp_cpus[i];
            my_core = i;
            break;
        }
    }
    if (c) {
        if (c->in_hlt) c->idle_acc++; else c->busy_acc++;
        u32 tot = c->busy_acc + c->idle_acc;
        if (tot >= SMP_LOAD_WINDOW) {
            c->load_pct = c->busy_acc * 100u / tot;
            c->busy_acc = 0;
            c->idle_acc = 0;
        }
    }
    lapic_write_ap(LAPIC_EOI, 0);       /* EOI обязателен (LAPIC-таймер) */
    if (!c) return saved_esp;           /* не опознано — продолжаем как было */
    {
        u32 next = task_ap_schedule(saved_esp, my_core, (u32 *)&c->idle_esp);
        c->in_hlt = task_ap_is_idle() ? 1u : 0u;
        return next;
    }
}

/* СЕССИЯ 76 (FIX паники #13 с лога пользователя): кадр ДОЛЖЕН быть
 * идентичен кадру irq_stub_0 (BSP): pusha + SS + DS + ES, ESP -> слот ES.
 * Задачи строятся под ЭТУ схему (task_spawn_impl: [SS][DS][ES][pusha]
 * [EIP][CS][EFLAGS]), а задачи мигрируют AP<->BSP — раскладка общая.
 * Раньше стаб делал только pusha: popa/iret читали кадр со сдвигом
 * 3 слота -> EIP=0, CS=мусор -> #GP(13) при ПЕРВОМ переключении
 * idle->задача (ramfs-сервер — первая задача на AP), причём замок уже
 * был захвачен и PIC замаскирован -> замерзала вся ОС. */
__attribute__((naked, used)) void ap_timer_stub(void)
{
    __asm__ __volatile__(
        "pusha\n\t"
        "pushl %ss\n\t"                 /* сегменты прерванного контекста */
        "pushl %ds\n\t"
        "pushl %es\n\t"
        "cld\n\t"
        "pushl %esp\n\t"                /* arg: кадр (es,ds,ss,pusha)      */
        "call _ap_timer_irq_c\n\t"
        "movl %eax, %esp\n\t"           /* переключение на выбранный кадр  */
        "popl %es\n\t"                  /* сегменты НОВОГО контекста       */
        "popl %ds\n\t"
        "popl %eax\n\t"                 /* слот SS                         */
        "movw %ax, %ss\n\t"
        "popa\n\t"
        "iret\n\t"
    );
}

/* Ложное прерывание: без EOI, немедленный возврат */
__attribute__((naked, used)) void ap_spurious_stub(void)
{
    __asm__ __volatile__("iret");
}

/* Главная функция AP (глобальная: алиас _smp_ap_main для трамплина).
 * Возвращает НИКОГДА — ядро живёт в цикле простоя. */
void smp_ap_main(u32 idx)
{
    smp_cpu_t *me = &smp_cpus[idx];

    gdt_init();        /* общая GDT ядра + перезагрузка сегментов      */
    idt_load_ap();     /* общий IDT (включая 0x60/0xEF)                */
    mtrr_ap_copy();    /* те же атрибуты памяти, что у BSP             */

    /* LAPIC ЭТОГО ядра: та же база, что у BSP, глобальное включение
     * (после INIT x2APIC-бит сброшен, база = сбросовая 0xFEE00000 —
     * прописываем фактическую базу BSP на случай relocation) */
    {
        u64 m = msr_read(0x1B);
        m = (m & ~(u64)0xFFFFF000ULL) | (u64)g_apic_base_ap | 0x800ULL;
        msr_write(0x1B, m);
    }
    lapic_write_ap(LAPIC_SPURIOUS, LAPIC_SPUR_VEC | 0x100);
    lapic_write_ap(LAPIC_TPR, 0);
    lapic_write_ap(LAPIC_LVT_LINT0, 0x10000);
    lapic_write_ap(LAPIC_LVT_LINT1, 0x10000);
    lapic_write_ap(LAPIC_LVT_ERROR, 0x10000);

    /* LAPIC-таймер: периодический, делитель 16 (как при калибровке) */
    lapic_write_ap(LAPIC_DIVIDE, 0x3);
    lapic_write_ap(LAPIC_LVT_TIMER, LAPIC_TIMER_VEC | (1u << 17)); /* periodic */
    lapic_write_ap(LAPIC_ICOUNT, g_lapic_ticks_per_ms ? g_lapic_ticks_per_ms : 1);

    sti();

    me->apic_id = lapic_read_ap(LAPIC_ID) >> 24;
    me->stack_top = (u32)(unsigned long)&smp_ap_stacks[idx - 1][SMP_AP_STACK];
    me->online = 1;    /* последний шаг — BSP ждёт именно этот флаг   */

    for (;;) {
        me->in_hlt = 1;
        __asm__ __volatile__("" ::: "memory");
        hlt();
        me->in_hlt = 0;
        __asm__ __volatile__("" ::: "memory");
    }
}

/* =====================================================================
 * 7. Запуск одного AP: INIT -> SIPI -> ожидание online
 * ===================================================================== */
static void pit_wait_ms(u32 ms)
{
    u32 t0 = timer_poll_deadline();
    while (!timer_poll_expired(t0, ms * 1000u)) { io_wait(); }
}

static int wait_online(int idx, u32 ms)
{
    u32 t0 = timer_poll_deadline();
    while (!timer_poll_expired(t0, ms * 1000u)) {
        if (smp_cpus[idx].online) return 1;
    }
    return smp_cpus[idx].online;
}

static int boot_one_ap(u32 apic_id, int idx)
{
    volatile u32 *patch = (volatile u32 *)(unsigned long)
                          (SMP_TRAMP_ADDR + SMP_PATCH_OFF);

    smp_cpus[idx].online   = 0;
    smp_cpus[idx].apic_id  = apic_id;
    smp_cpus[idx].in_hlt   = 0;
    smp_cpus[idx].busy_acc = 0;
    smp_cpus[idx].idle_acc = 0;
    smp_cpus[idx].load_pct = 0;
    smp_cpus[idx].idle_esp = 0;
    smp_cpus[idx].stack_top =
        (u32)(unsigned long)&smp_ap_stacks[idx - 1][SMP_AP_STACK];

    patch[0] = smp_cpus[idx].stack_top;    /* +0x100: esp */
    patch[1] = (u32)idx;                   /* +0x104: индекс ядра */

    /* INIT IPI (assert); 10 мс по спецификации мультипроцессорного старта */
    lapic_write_bsp(LAPIC_ICR_HI, apic_id << 24);
    lapic_write_bsp(LAPIC_ICR_LO, LAPIC_ICR_INIT);
    pit_wait_ms(10);

    /* SIPI: до двух попыток (рекомендация Intel SDM для медленных AP) */
    for (int attempt = 0; attempt < 2; attempt++) {
        lapic_write_bsp(LAPIC_ICR_HI, apic_id << 24);
        lapic_write_bsp(LAPIC_ICR_LO, LAPIC_ICR_SIPI | (SMP_TRAMP_ADDR >> 12));
        if (wait_online(idx, 200)) {
            char b[80];
            snprintf(b, sizeof(b), "smp: ядро %d (APIC id %u) онлайн",
                     idx, (unsigned)apic_id);
            smp_log(b);
            return idx;
        }
    }
    {
        char b[80];
        snprintf(b, sizeof(b), "smp: ядро %d (APIC id %u) НЕ стартовало",
                 idx, (unsigned)apic_id);
        smp_log(b);
    }
    /* Страховка «опоздавшего» AP: если ядро всё же вылезет из INIT уже
     * ПОСЛЕ таймаутов, оно прочитало бы патч-блок СЛЕДУЮЩЕГО ядра
     * (общий стек = порча). Даём 100 мс пройти точку чтения патчей в
     * pm-входе (реальный AP доходит до неё за микросекунды — это
     * чистая защита от экзотики, а не основной механизм). */
    pit_wait_ms(100);
    return -1;
}

/* =====================================================================
 * 8. smp_init: детект топологии + запуск всех AP
 * ===================================================================== */
void smp_init(const mb_info_t *mb)
{
    if (g_smp_ready) return;
    g_smp_ready = 1;

    /* BSP — ядро 0, всегда онлайн */
    smp_cpus[0].online  = 1;
    smp_cpus[0].apic_id = 0;

    smp_detect_topology();
    {
        char b[112];
        snprintf(b, sizeof(b),
                 "smp: CPU %u логических, %u ядер, %u поток(ов)/ядро (SMT%s)",
                 (unsigned)g_cpu_count, (unsigned)g_topo_cores,
                 (unsigned)g_topo_threads,
                 g_topo_threads > 1 ? ": да" : ": нет");
        smp_log(b);
    }

    if (!s_apic_present) {
        smp_log("smp: APIC отсутствует — однопроцессорный режим");
        g_online = 1;
        return;
    }

    /* Проверить место под трамплин ДО включения LAPIC */
    if (!tramp_addr_ok(mb)) {
        smp_log("smp: 0x7000 помечена reserved в mmap — SMP отключён");
        g_online = 1;
        return;
    }

    if (!lapic_bsp_enable()) {
        smp_log("smp: LAPIC не включился — однопроцессорный режим");
        g_online = 1;
        return;
    }

    /* Список APIC ID: MADT (надёжно), без него — CPUID 0..N-1 */
    u8 ids[SMP_MAX_CPUS];
    int n = madt_scan(ids, SMP_MAX_CPUS);
    int from_madt = n > 0;
    if (!from_madt) {
        n = g_cpu_count;
        if (n > SMP_MAX_CPUS) n = SMP_MAX_CPUS;
        for (int i = 0; i < n; i++) ids[i] = (u8)i;
        smp_log("smp: MADT не найден — APIC ID по счёту CPUID");
    } else if (n != g_cpu_count) {
        char b[96];
        snprintf(b, sizeof(b),
                 "smp: MADT: %d проц., CPUID: %d — беру список MADT",
                 n, g_cpu_count);
        smp_log(b);
        g_cpu_count = n;
    }

    /* BSP может быть не первым в MADT: ставим его на индекс 0 */
    {
        u32 bsp_id = lapic_read_bsp(LAPIC_ID) >> 24;
        int  bpos  = -1;
        for (int i = 0; i < n; i++)
            if (ids[i] == bsp_id) { bpos = i; break; }
        if (bpos < 0 && n < SMP_MAX_CPUS) {
            /* BSP не в списке (ошибка прошивки) — впишем его */
            ids[n++] = (u8)bsp_id;
            bpos = n - 1;
        }
        if (bpos > 0) {
            u8 t = ids[0]; ids[0] = ids[bpos]; ids[bpos] = t;
        }
        smp_cpus[0].apic_id = bsp_id;
    }

    /* Калибровка таймера (пока LAPIC BSP включён, до sti — однопоточно) */
    lapic_calibrate();

    if (!tramp_install()) {
        lapic_bsp_disable();
        g_online = 1;
        return;
    }

    /* База LAPIC для AP: ставится ОДИН раз, до первого SIPI, и больше
     * никогда не меняется (BSP-код после этого пользуется только своей
     * g_lapic_base и обнуляет ТОЛЬКО её при выключении LAPIC). */
    g_apic_base_ap = (u32)(msr_read(0x1B) & 0xFFFFF000ULL);
    if (!g_apic_base_ap) g_apic_base_ap = 0xFEE00000u;

    /* Запуск AP по очереди; BSP (ids[0]) пропускаем */
    int online = 1;
    for (int i = 1; i < n; i++) {
        if (boot_one_ap(ids[i], i) >= 0) online++;
    }

    /* LAPIC на BSP больше не нужен: путь прерываний как до SMP */
    lapic_bsp_disable();

    g_online = online;
    {
        char b[96];
        snprintf(b, sizeof(b),
                 "smp: итог: %d логических ЦП, %d онлайн (%s)",
                 g_cpu_count, g_online,
                 from_madt ? "список из MADT" : "счёт CPUID");
        smp_log(b);
    }
}

/* ---------------- публичное API ---------------- */
int smp_cpu_count(void)    { return g_cpu_count; }
int smp_online_count(void) { return g_online; }
int smp_topo_cores(void)   { return g_topo_cores; }
int smp_topo_threads(void) { return g_topo_threads; }
int smp_ready(void)        { return g_smp_ready; }

/* --- СЕССИЯ 77 [SMP-BOOT-GATE]: планирование задач на AP — только
 * после завершения загрузки. До вызова smp_tasks_enable() AP-ядра
 * живут в idle (hlt + учёт нагрузки), все задачи исполняет BSP —
 * как в до-SMP ядре. Это убирает целый класс гонок загрузки:
 * sata/wifi/ramfs задачи больше не печатают dbg() и не берут
 * dbg_lock/кучу ПАРАЛЛЕЛЬНО с boot-логом BSP (ждущий в s_lock BSP
 * делал sti;hlt при замаскированном IRQ0 — вечный сон, лог обрывался
 * на «[boot] wm_init...»). */
static volatile int s_tasks_go = 0;

void smp_tasks_enable(void)
{
    s_tasks_go = 1;
    __asm__ __volatile__("" ::: "memory");   /* публикация до дальнейших действий */
}

int smp_tasks_enabled(void)
{
    return s_tasks_go;
}

int smp_cpu_load(int idx)
{
    if (idx <= 0 || idx >= SMP_MAX_CPUS) return -1;   /* BSP не измеряем */
    if (!smp_cpus[idx].online) return -1;
    return (int)smp_cpus[idx].load_pct;
}

u32 smp_cpu_apic_id(int idx)
{
    if (idx < 0 || idx >= SMP_MAX_CPUS) return 0;
    return smp_cpus[idx].apic_id;
}

/* СЕССИЯ 76: этот CPU — AP? Используется exc_panic (idt.c), чтобы
 * отличить панику на AP от паники на BSP. Надёжно без per-CPU данных:
 *   - до SMP g_apic_base_ap == 0 (LAPIC-путь не запускался);
 *   - у AP бит APIC-global-enable (MSR 0x1B, бит 8) ставится в
 *     smp_ap_main и остаётся включённым;
 *   - у BSP после запуска ядер LAPIC выключается (lapic_bsp_disable
 *     сбрасывает тот же бит) — путь прерываний BSP как до SMP.
 * Контекст вызова — обработчик исключения (IF=0), rdmsr безопасен. */
int smp_this_cpu_is_ap(void)
{
    if (!g_apic_base_ap) return 0;
    return (int)((msr_read(0x1B) >> 8) & 1u);
}
