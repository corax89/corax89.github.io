/* sync.h — мини-блокировки для многозадачного ядра (без зависимостей).
 *
 * FIX (зависший процесс вешает систему): блокировки теперь ХРАНЯТ ВЛАДЕЛЬЦА.
 * Значение блокировки: 0 = свободна, N>0 = владелец — задача N-1.
 *
 * Два сценария, которые раньше намертво фризили всю ОС:
 *
 *  1. УБИЙСТВО ДЕРЖАТЕЛЯ. task_kill (диспетчер задач, команда kill) и
 *     ватчдог помечают задачу finished в ПРОИЗВОЛЬНОЙ точке исполнения —
 *     в том числе внутри критической секции (между s_lock и s_unlock).
 *     Блокировка оставалась захваченной навсегда. Дальше: kmain берёт её
 *     (composite -> wm_glock каждый кадр; wm_key -> qlock окна) и крутится
 *     в цикле ожидания ВЕЧНО — а kmain делает всё: мышь, клавиатура,
 *     композитинг, опрос сети. Итог: полное зависание системы от одного
 *     зависшего/убитого процесса. Теперь ждущий видит, что владелец мёртв
 *     (task_finished), принудительно освобождает блокировку и продолжает.
 *
 *  2. ЗАВИСАНИЕ ДЕРЖАТЕЛЯ ВНУТРИ СЕКЦИИ. Задача зависла (бесконечный
 *     цикл) в критической секции — жива, но никогда не отпустит.
 *     Ватчдог её не видит (она исправно получает слоты round-robin).
 *     Теперь ждущий держит счётчик ожидания: если владелец жив, но не
 *     отпускает блокировку дольше SLOCK_STALE_TICKS (20 с) — блокировка
 *     освобождается принудительно (с громким предупреждением в serial).
 *
 * s_unlock отпускает ТОЛЬКО СВОЮ блокировку (сверяет владельца):
 * поздний unlock задачи, у которой блокировку отобрали по таймауту,
 * не сбивает захват нового владельца.
 *
 * Использование: volatile int mylock = 0; в модуле,
 *   s_lock(&mylock); ... s_unlock(&mylock);
 * Критическая секция держателя прерываема (IF восстановлен) — можно
 * держать долго (дисковый I/O, HTTP-транзакция); конкурент спит (hlt).
 */
#ifndef SYNC_H
#define SYNC_H

#include "types.h"

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
/* ======== хост-сборки (тесты движка/моста на Linux): однопоточные
 * заглушки вместо cli/sti-спинлоков и зависимостей task.h.
 * Ядро N2600-OS собирается с -ffreestanding и идёт полной веткой.
 * Тест моста (test_mqjs_host.c) определяет MQJS_HOST_TASK_STUBS_EXTERN:
 * тогда task_current/task_finished берутся ВНЕШНИМИ — тест эмулирует
 * смерть задач (самолечение REPL после ватчдога/kill). ======== */
#ifdef MQJS_HOST_TASK_STUBS_EXTERN
extern int task_current(void);
extern int task_finished(int t);
#else
static inline int task_current(void) { return 0; }
static inline int task_finished(int t) { (void)t; return 0; }
#endif
static inline void task_set_lockwait_me(int v) { (void)v; }
static inline void s_lock(volatile int *l) { (void)l; __asm__ __volatile__("" ::: "memory"); }
static inline void s_unlock(volatile int *l) { (void)l; __asm__ __volatile__("" ::: "memory"); }
static inline int s_trylock(volatile int *l) { (void)l; return 1; }
extern void serial_puts(const char *s);

#else /* --- ядро N2600-OS: полная реализация --- */

#include "task.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* Сколько тиков ждать живого, но не отпускающего блокировку
 * владельца, прежде чем отобрать её силой. СЕССИЯ 72: таймер с
 * сессии 33 работает на 1000 Гц (1 тик = 1 мс) — прежние 2000
 * «тиков» незаметно стали 2 СЕКУНДАМИ вместо задуманных 20 с.
 * Легитимная HTTP-транзакция держит http_busy_lock до 15 с
 * (imgsvc): блокировку отбирали ПОСРЕДИ секции, второй вход в
 * глобальные буферы клиента портил кучу (подпись лога сессии 68:
 * «[sync] блокировка отобрана» рядом с «ПОРЧА КУЧИ»).
 * 20000 = честные 20 с: с запасом дольше самой долгой легитимной
 * секции (HTTP-таймаут 15 с, FAT32-чтение и компиляция c4 —
 * доли секунды..секунды). */
#define SLOCK_STALE_TICKS 20000

/* [SYNC-DIAG] сессия 78: отбор блокировки на cli-пути (IF=0): тики
 * стоят, время меряем pit2 (микросекунды). 5 с — заведомо дольше любой
 * легитимной cli-секции (те — миллисекунды), но меньше вечного зависания. */
#define SLOCK_STALE_CLI_US 5000000u

/* Значение блокировки = владелец + 1 (0 = свободна). Задача 0 (kmain)
 * кодируется как 1 — блокировки совместимы со старым смыслом «1 = занято». */
static inline int slock_owner_of(int v)
{
    return v > 0 ? v - 1 : -1;
}

static inline void s_unlock(volatile int *l)
{
    /* Отпускаем только СВОЙ захват: если блокировку уже отобрали
     * (мы зависли >20 с внутри секции), поздний unlock не должен
     * сбить захват нового владельца. */
    int me = task_current() + 1;
    if (*l == me) *l = 0;
    __asm__ __volatile__("" ::: "memory");
}

/* [SYNC-DIAG] сессия 78: десятичный/шестнадцатеричный вывод без libc —
 * для диагностики реентерабельности (какая задача, какой замок). */
static inline void slock_diag_put(const char *s)
{
    serial_puts(s);
}
static inline void slock_diag_dec(char *b, int *n, u32 v)
{
    char t[12];
    int  k = 0;
    do { t[k++] = (char)('0' + (v % 10u)); v /= 10u; } while (v);
    while (k) b[(*n)++] = t[--k];
}
static inline void slock_diag_hex(char *b, int *n, u32 v)
{
    static const char hx[] = "0123456789abcdef";
    b[(*n)++] = '0'; b[(*n)++] = 'x';
    for (int i = 28; i >= 0; i -= 4) b[(*n)++] = hx[(v >> i) & 0xFu];
}

static inline void s_lock(volatile int *l)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (*l == 0) {
        *l = task_current() + 1;
        __asm__ __volatile__("" ::: "memory");
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return;
    }
    /* СЕССИЯ 68: ПОВТОРНЫЙ захват СВОЕЙ блокировки (reentrancy).
     * Раньше задача ждала 20 с, ОТБИРАЛА блокировку у самой себя и
     * продолжала — два «входа» в нереентерабельную секцию одной задачей
     * (глобальные буферы транзакции, связные списки) = порча кучи.
     * Теперь: немедленный вход (владелец — мы сами; чужих в секции нет).
     *
     * СЕССИЯ 78 [SYNC-DIAG]: диагностика с № задачи и адресом замка —
     * прежний обезличенный текст не позволял найти вызывающего. ЧАСТАЯ
     * причина этого сообщения была не в вызывающем, а в task_current()
     * (см. [TASKC-CPU] в task.c): BSP записывал владельцем ЧУЖУЮ AP-
     * задачу, и её следующий вход выглядел «повторным». После per-CPU
     * фикса сообщение означает РЕАЛЬНУЮ рекурсию s_lock в коде задачи —
     * печатаем первые 8 случаев (далее молча, чтобы не завалить serial). */
    if (slock_owner_of((int)*l) == task_current()) {
        static volatile int reentr_shown = 0;
        if (reentr_shown < 8) {
            char b[80];
            int  n = 0;
            reentr_shown++;
            slock_diag_put("[sync] s_lock: ПОВТОРНЫЙ вход задачи ");
            slock_diag_dec(b, &n, (u32)task_current());
            b[n++] = ' ';
            b[n++] = '(';
            slock_diag_hex(b, &n, (u32)(unsigned long)l);
            b[n++] = ')';
            b[n++] = 0;
            slock_diag_put(b);
            slock_diag_put(" — реентерабельность, проверить вызывающего!\n");
        }
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return;
    }
    /* занято: ждём (прерываемо), контролируя состояние владельца */
    {
        u32 wait_start = 0;
        int  timed = 0;
        u32 cli_start = 0;    /* [SYNC-DIAG] cli-путь: реальное время по pit2 */
        int  cli_timed = 0;
        /* ВАЖНО (ватчдог): помечаем себя как «жду блокировку» — ватчдог
         * НЕ убивает такие задачи (ими управляет SLOCK_STALE_TICKS ниже).
         * Без этого ватчдог выкашивал ждущие окна через 5 с, ещё до
         * отбора блокировки у зависшего держателя. Мы под cli — атомарно. */
        task_set_lockwait_me(1);
        while (*l) {
            int owner = slock_owner_of((int)*l);
            if (owner >= 1 && task_finished(owner)) {
                /* владелец УБИТ, держа блокировку — освобождаем силой */
                serial_puts("[sync] блокировка освобождена: владелец-задача мёртв\n");
                *l = 0;
                break;
            }
            if (owner >= 1 && !timed) {
                wait_start = timer_ticks();
                timed = 1;
            } else if (owner >= 1 && timed &&
                       timer_ticks() - wait_start > SLOCK_STALE_TICKS) {
                /* владелец жив, но завис внутри секции >20 с — отбираем */
                serial_puts("[sync] блокировка отобрана: владелец завис >20 c\n");
                *l = 0;
                break;
            }
            /* впускаем прерывания и спим до тика (ожидающий не жжёт CPU;
             * планировщик продолжает переключать задачи).
             * СЕССИЯ 75: перед сном отпускаем ЯДРОВЫЙ ЗАМОК — иначе
             * пока мы ждём чужую блокировку, AP-задачи не получают CPU
             * (замок удерживает спящий).
             * СЕССИЯ 77 [SMP-HLT]: если мы вошли под cli (IF=0 — фаза
             * загрузки, драйверная секция), sti+hlt = ВЕЧНЫЙ сон: во
             * время загрузки IRQ0 на BSP ещё ЗАМАСКИРОВАН, будить некому
             * (наблюдалось как «лог обрывался на [boot] wm_init...»).
             * Под cli крутимся на pause: держатель на ДРУГОМ ядре
             * получает CPU от собственного LAPIC-таймера и освобождает
             * замок за миллисекунды; проверка мёртвого владельца — в
             * начале каждой итерации этого же цикла.
             *
             * СЕССИЯ 78 [SYNC-DIAG]: на cli-пути timer_ticks() СТОИТ
             * (IRQ0 заблокирован тем же cli на BSP; тики до нас не
             * доходят) — проверка SLOCK_STALE_TICKS не срабатывала, и
             * зависший владелец замка (на другом ядре) замораживал и
             * нас навсегда. Теперь cli-путь ведёт отсчёт по pit2
             * (реальное время, работает под cli) и отбирает блокировку
             * через SLOCK_STALE_CLI_US. */
            if (if_had & 0x200) {
                task_klock_release_me();
                __asm__ __volatile__("sti\n\thlt" ::: "memory");
                __asm__ __volatile__("cli" ::: "memory");
                task_klock_acquire_me();
            } else {
                if (!cli_timed) {
                    cli_start = timer_poll_deadline();
                    cli_timed = 1;
                } else if (timer_poll_expired(cli_start, SLOCK_STALE_CLI_US)) {
                    serial_puts("[sync] блокировка отобрана: cli-ожидание >5 c\n");
                    *l = 0;
                    break;
                }
                __asm__ __volatile__("pause" ::: "memory");
            }
        }
        task_set_lockwait_me(0);
        *l = task_current() + 1;
        __asm__ __volatile__("" ::: "memory");
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* Попытка захвата без ожидания. Тоже чинит мёртвого владельца:
 * без этого trylock ПОСТОЯННО отказывал бы на блокировке, утёкшей
 * с убитой задачей (окно навсегда оставалось бы с заглушкой кадра). */
static inline int s_trylock(volatile int *l)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (*l == 0) {
        *l = task_current() + 1;
        __asm__ __volatile__("" ::: "memory");
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return 1;
    }
    {
        int owner = slock_owner_of((int)*l);
        if (owner >= 1 && task_finished(owner)) {
            serial_puts("[sync] trylock: освобождена мёртвым владельцем\n");
            *l = task_current() + 1;
            __asm__ __volatile__("" ::: "memory");
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
            return 1;
        }
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return 0;
}

#endif /* hosted */

#endif /* SYNC_H */
