/* smp.h — многоядерные/многопоточные (SMT) процессоры N2600-OS.
 *
 * ЧТО ДЕЛАЕТ ЭТОТ МОДУЛЬ (сессия 74):
 *   1. Определяет топологию CPU: логические ЦП, физические ядра,
 *      потоки на ядро (Hyper-Threading/SMT) — CPUID (листья 1/4/0x0B).
 *   2. Ищет реальные APIC ID всех процессоров в ACPI MADT (через
 *      RSDP -> RSDT), при отсутствии — берёт счёт CPUID.
 *   3. Включает LAPIC на BSP, отправляет каждому AP INIT-SIPI-SIPI
 *      (трамплин real->protected mode в низкой памяти), AP получают
 *      собственный стек, общую GDT/IDT, LAPIC-таймер 1000 Гц и уходят
 *      в hlt-цикл простоя.
 *   4. LAPIC-таймер каждого AP ведёт учёт busy/idle тиков — это и есть
 *      «проценты загрузки ядер» для диспетчера задач (smp_cpu_load).
 *   5. После запуска всех AP LAPIC на BSP ВЫКЛЮЧАЕТСЯ обратно: путь
 *      прерываний BSP (PIC -> LINT0 -> INTR) остаётся ровно таким же,
 *      как до SMP (никаких ExtINT/EOI-изменений в планировщике).
 *
 * ПЛАНИРОВЩИК (сессия 75): задачи размещаются на ядрах по принципу
 * «наименее нагруженное ядро» (task.c: task_pick_core) и РЕАЛЬНО
 * исполняются на AP. Безопасность — «ядровый замок» (klock):
 * kernel-код задач исполняется только под замком, поэтому ВСЯ старая
 * синхронизация ядра (cli(), s_lock, общие буферы) сохраняет смысл —
 * одновременно исполняется не более одной задачи во всей системе.
 * Параллелизм реален, когда задачи BSP спят в hlt (типичный GUI):
 * AP-задачи исполняются свободно; при работе AP-задачи PIC маскируется
 * (драйверные IRQ не пересекаются с кодом задачи на другом ядре),
 * каждые SMP_FAIR_TICKS тиков ядро-исполнитель отдаёт BSP один тик.
 * Замок передаётся между задачами при переключении (holds-флаг задачи),
 * голодающая AP-задача (>300 мс без CPU) мигрирует на BSP.
 *
 * API:
 *   smp_init(mb)              — детект топологии + запуск AP (один раз, до sti())
 *   smp_cpu_count()           — обнаружено логических ЦП (включая BSP), >= 1
 *   smp_online_count()        — реально запущено ядер (включая BSP)
 *   smp_topo_cores()          — физических ядер на пакет
 *   smp_topo_threads()        — потоков (SMT) на физическое ядро
 *   smp_cpu_load(idx)         — загрузка ядра idx в %, 0..100;
 *                               idx == 0 (BSP) и офлайн-ядра: -1
 *   smp_cpu_apic_id(idx)      — аппаратный APIC ID ядра idx
 *   smp_ready()               — 1 = smp_init выполнен
 *   smp_klock_try/unlock      — ядровый замок (0/1 cmpxchg-спинлок);
 *                               владелец — ЗАДАЧА (holds-флаг), замком
 *                               владеет ядро-исполнитель
 *   smp_pic_mask/restore      — маскировка PIC на время исполнения
 *                               AP-задачи (драйверные IRQ только на BSP)
 *   smp_spin_lock/unlock      — спин-блокировка для коротких
 *                               межъядерных секций (fb_task_switch)
 */
#ifndef SMP_H
#define SMP_H

#include "types.h"
#include "boot.h"

#define SMP_MAX_CPUS 8

/* Справедливое распределение: AP-задача непрерывно исполняется не
 * дольше этого числа тиков LAPIC-таймера (1 мс каждый), затем ядро
 * отдаёт BSP один тик (распаковка PIC — события/таймеры BSP):
 * тайминги ожиданий в задачах на AP искажаются не более чем в 1.5x,
 * BSP не голодает дольше ~3 мс. */
#define SMP_FAIR_TICKS 2

void smp_init(const mb_info_t *mb);

int  smp_cpu_count(void);
int  smp_online_count(void);
int  smp_topo_cores(void);
int  smp_topo_threads(void);
int  smp_cpu_load(int idx);       /* % или -1 */
u32  smp_cpu_apic_id(int idx);
int  smp_ready(void);
int  smp_this_cpu_is_ap(void);    /* сессия 76: исполняемся на AP? (exc_panic) */

/* --- СЕССИЯ 77 [SMP-BOOT-GATE] ---
 * Пуск задач на AP только ПОСЛЕ завершения загрузки. Пока ядро грузится
 * (IRQ0 на BSP замаскирован, IF=0), AP-планировщик не получает задач:
 * иначе фоновые задачи (sata/wifi/ramfs) стартуют на AP прямо посреди
 * boot-лога BSP и конкурируют с ним за dbg_lock/klog_lock/кучу —
 * ожидающий в s_lock BSP делает sti;hlt и засыпает НАВСЕГДА (IRQ0 ещё
 * замаскирован — будить некому): лог обрывался на «[boot] wm_init...». */
void smp_tasks_enable(void);      /* вызов из kmain после «Загрузка завершена» */
int  smp_tasks_enabled(void);     /* 0 = загрузка (задачи только на BSP)      */

/* --- спин-блокировки (межъядерные критические секции) --- */
static inline int smp_trylock(volatile int *l)
{
    int expected = 0;
    __asm__ __volatile__("lock cmpxchgl %2, %0"
                         : "+m"(*l), "+a"(expected)
                         : "r"(1)
                         : "memory", "cc");
    return expected == 0;         /* 1 = захват получен */
}

static inline void smp_spin_lock(volatile int *l)
{
    while (!smp_trylock(l))
        __asm__ __volatile__("pause");
}

static inline void smp_spin_unlock(volatile int *l)
{
    __asm__ __volatile__("movl $0, %0" : "=m"(*l) :: "memory");
}

/* --- ядровый замок (klock) ---
 * 0/1-спинлок на cmpxchg. Захватывает ЯДРО-исполнитель; «владелец» в
 * смысле учёта — ЗАДАЧА (holds-флаг в task.c, замок передаётся при
 * переключении контекста без unlock/lock). AP-исполнитель при захвате
 * маскирует PIC (smp_pic_mask), при освобождении восстанавливает. */
extern volatile int smp_klock;

static inline int smp_klock_try(void)
{
    return smp_trylock(&smp_klock);
}

static inline void smp_klock_unlock(void)
{
    smp_spin_unlock(&smp_klock);
}

/* Маскировка PIC (master+slave) на время исполнения AP-задачи:
 * драйверные IRQ приходят ТОЛЬКО на BSP, их обработчики не должны
 * пересекаться с кодом задачи на другом ядре. Восстановление — по
 * сохранённой копии IMR. Вызывается только пока замок держит AP. */
void smp_pic_mask(void);
void smp_pic_restore(void);

#endif /* SMP_H */
