
---
Task ID: 75
Agent: main (Z.ai)
Task: Сессия 75 — (1) перенести в диспетчере задач цифры загрузки ядер под графики; (2) запуск процессов на разных ядрах (простой алгоритм — наименее нагруженные ядра); (3) чтение и запись exFAT.

Work Log:
- Прочитал smp.c/h (сессия 74: AP в hlt с учётом загрузки, задачи только на BSP), task.c/h, apps_taskmgr.c, fb.c, sync.h, fat32.c, kernel.c, wm/ramfs/usb_ehci (hlt-точки).
- Спроектировал и реализовал SMP-планировщик: ядровый замок (klock, cmpxchg), передача замка через holds-флаг задачи, task_ap_schedule на LAPIC-таймере, размещение task_pick_core (наименее нагруженное ядро, AP предпочтительнее, UI/песочницы на BSP), миграция голодающих (>300 мс) на BSP, fair-share (2 тика AP / 1 тик BSP), маскировка PIC на время AP-задачи.
- task_current() стал «исполняющейся задачей» (AP-aware): владельцы s_lock, waiting/lockwait, task_stack_range, trampoline, task_exit корректны на обоих ядрах. Все hlt-точки задач обёрнуты в task_hlt_idle (task_yield/msleep, sync.h, wm.c, ramfs.c x2, usb_ehci.ehci_wait_pause, kmain).
- fb.c: per-core наборы активных контекстов + fb_task_switch_ap + спинлок планировщиков; fb_init грузит экранную запись во все наборы.
- apps_taskmgr.c: блок «Ядра, %» перенесён под графики (правая колонка, под NET), список от TM_HDR_H+18; статус задачи показывает ядро («idle@1»).
- exFAT: новый src/exfat.c/.h (VBR/FAT/bitmap/UpCase/entry-sets по ms-fscc, кириллица, чтение и запись, mkdir/delete/overwrite, кэш кластера); fat32.c — personality-диспетчеризация (нулевые изменения в fileman/filedlg/settings); disk.c — "exFAT" в disk_part_fstype; fileman/settings — отображение имени ФС.
- Тесты: scripts/mkexfat.py (конструктор образа), scripts/test_exfat_host.py (хост-тест настоящего exfat.c + питон-проверка структур на диске) — ВСЕ ПРОШЛИ. Найдены и исправлены в процессе: layout FileName (символы с байта 2), timestamps FileEntry (Create@12/Modified@16/Access@24), set = sec_count+1, find_free_run (0x00 = свободный слот, забег не пересекает кластер), позиции записей (cur_cl/cur_off).
- test_smp_host.py обновлён (+20 проверок сессии 75); починены упавшие харнессы: setnet (стабы wm_theme_get_dim/set_accent/wm_button_draw/fat32_fsname), tmfmt (стаб smp.h + task_cpu/...), mp3svc (путь SRC).
- Установлено (git stash на чистый HEAD): tcpnet/httpd60 сломаны ДО сессии 75 (гниль харнессов) — не наша регрессия, задокументировано в CHANGES.
- Сборка: build.sh exit=0; kernel.bin 1076628 (md5 f8c0b8055a08eb763c29027483fafbe2); patch_iso_grow.py (LBA 2980, Volume Space 3506); floppy.img/n2600-raw.img/prebuilt синхронны;unicorn boot OK.

Stage Summary:
- SMP: задачи реально исполняются на назначенных ядрах; GUI на BSP, вычисления на AP; синхронизация — ядровый замок + маскировка PIC; миграция и fair-share защищают от голода.
- exFAT: чтение и запись (файлы/каталоги, кириллица, большие кластеры) через прозрачную personality fat32 — файловый менеджер работает с exFAT-флешкой без изменений UI.
- Артефакты: src/{exfat.c,exfat.h,smp.c,smp.h,task.c,task.h,fb.c,fb.h,sync.h,wm.c,ramfs.c,usb_ehci.c,kernel.c,apps_taskmgr.c,fat32.c,fat32.h,disk.c,fileman.c,apps_settings.c}; scripts/{mkexfat.py,test_exfat_host.py,test_exfat_host.c,test_smp_host.py}; host-test/{tmfmt,setnet,mp3svc} харнессы починены.

---
Task ID: 78
Agent: main
Task: FIX зависаний запусков JS (per-CPU task_current, отбор ядрового замка,
PIC-IRQ0, логи [mqjs]/[wm]) — реализация разбора пользователя.

Work Log:
- task.c: task_current/task_exec_core per-CPU (smp_this_cpu_is_ap);
  task_klock_acquire_me — batch-спин + скан держателя + отбор (мёртвый
  немедленно, живой через 5 c pit2, потерянный — восстановление);
  task_kill/ватчдог отпускают замок убитой; SPAWN-GATE таймаут;
  ватчдог-миграция без migrating=1; task_ap_schedule чистит migrating
  при сохранении кадра.
- smp.c: smp_pic_mask — IRQ0 не маскируется (IMR = saved|0xFE).
- sync.h: [sync] реентерабельность с № задачи и адресом замка; cli-путь
  s_lock — pit2-отбор через 5 с (SLOCK_STALE_CLI_US).
- kernel.c: serial_putc — дедлайн 100 мс.
- mquickjs_api.c: [mqjs] run/done для file и repl eval (задача/байты/
  gen/rc/мс). wm.c: [wm] ЛИМИТ ОКОН — кто запросил.
- Тесты: smp 99/99 (+21), exfat, usb_mbr, crumbs, unicorn boot — ЗЕЛЁНЫЕ.
- Сборка: kernel.bin 1089204 байт; os.iso 7192576 (LBA 2980, VS 3512);
  floppy.img, n2600-raw.img синхронны; CHANGES.md — сессия 78.

Stage Summary:
- SMP-зависания класса «JS-запуск повесил систему» закрыты на трёх
  уровнях: честное ядро-исполнитель (per-CPU), живой таймер BSP под
  AP-задачей, ограниченное ожидание/принудительный отбор замка.
- Диагностика: [mqjs] run/done, [wm] ЛИМИТ ОКОН, [klock] ОТБОР,
  [smp] spawn слот застрял — следующий лог пользователя покажет виновника.
