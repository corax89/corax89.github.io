#!/bin/bash
# ========================================
# JSR-184 M3G Test Build Script
# ========================================

SDK_HOME="/opt/Java_ME_platform_SDK_3.0"
LOCAL_LIB="lib"

# Check which SDK to use
if [ -f "$SDK_HOME/lib/cldc_1.1.jar" ]; then
    echo "Using Java ME SDK: $SDK_HOME"
    CLDC="$SDK_HOME/lib/cldc_1.1.jar"
    MIDP="$SDK_HOME/lib/midp_2.0.jar"
    JSR184="$SDK_HOME/lib/jsr_184.jar"
else
    echo "Using local lib folder"
    CLDC="$LOCAL_LIB/cldc_1.1.jar"
    MIDP="$LOCAL_LIB/midp_2.0.jar"
    JSR184="$LOCAL_LIB/jsr_184.jar"
fi

echo ""
echo "========================================"
echo "Building JSR-184 M3G Test for J2ME"
echo "========================================"
echo ""

# Create directories
mkdir -p classes
mkdir -p bin

echo "[1/3] Cleaning old files..."
rm -f classes/*.class 2>/dev/null
rm -f bin/*.jar 2>/dev/null

echo "[2/3] Compiling..."
javac -source 1.3 -target 1.3 -bootclasspath "$CLDC:$MIDP:$JSR184" -d classes src/JSR184TestMidlet.java 2>&1

if [ $? -ne 0 ]; then
    echo ""
    echo "========================================"
    echo "BUILD FAILED!"
    echo "========================================"
    echo ""
    echo "Possible solutions:"
    echo "1. Install Java ME Platform SDK 3.0"
    echo "2. Download jsr_184.jar and put it in lib/ folder"
    echo ""
    echo "Download JSR-184 from:"
    echo "https://www.oracle.com/java/technologies/java-me-sdk-downloads.html"
    exit 1
fi

echo "[3/3] Creating JAR..."
cd classes
jar cfm ../bin/JSR184Test.jar ../manifest.mf *.class
cd ..

# Get JAR size
JARSIZE=$(stat -c%s "bin/JSR184Test.jar" 2>/dev/null || stat -f%z "bin/JSR184Test.jar" 2>/dev/null)

# Create JAD
cat > JSR184Test.jad << EOF
MIDlet-Name: JSR-184 M3G Test
MIDlet-Version: 1.0
MIDlet-Vendor: Test
MIDlet-1: JSR184Test, , JSR184TestMidlet
MIDlet-Jar-URL: JSR184Test.jar
MIDlet-Jar-Size: $JARSIZE
MicroEdition-Profile: MIDP-2.0
MicroEdition-Configuration: CLDC-1.1
EOF

echo ""
echo "========================================"
echo "Build successful!"
echo "========================================"
echo "JAR: bin/JSR184Test.jar"
echo "Size: $JARSIZE bytes"
