@echo off
echo ========================================
echo Searching for jsr_184.jar...
echo ========================================
echo.

REM Search in common locations
if exist "C:\Java_ME_platform_SDK_3.0\lib\jsr_184.jar" (
    echo FOUND: C:\Java_ME_platform_SDK_3.0\lib\jsr_184.jar
    goto end
)
if exist "C:\Java_ME_platform_SDK_3.0\lib\jsr184.jar" (
    echo FOUND: C:\Java_ME_platform_SDK_3.0\lib\jsr184.jar
    goto end
)

if exist "C:\WTK2.5.2\lib\jsr_184.jar" (
    echo FOUND: C:\WTK2.5.2\lib\jsr_184.jar
    goto end
)
if exist "C:\WTK2.5.2\lib\jsr184.jar" (
    echo FOUND: C:\WTK2.5.2\lib\jsr184.jar
    goto end
)

if exist "C:\Nokia\Devices\Nokia_S40_SDK\lib\jsr_184.jar" (
    echo FOUND: C:\Nokia\Devices\Nokia_S40_SDK\lib\jsr_184.jar
    goto end
)

if exist "C:\SonyEricsson\JavaME_SDK\lib\jsr_184.jar" (
    echo FOUND: C:\SonyEricsson\JavaME_SDK\lib\jsr_184.jar
    goto end
)

if exist "%USERPROFILE%\.netbeans\*\jsr_184.jar" (
    echo FOUND in NetBeans folder
    goto end
)

echo NOT FOUND in common locations.
echo.
echo Please download jsr_184.jar:
echo 1. Nokia SDK: https://www.nokia.com/developer-tools
echo 2. Search "jsr_184.jar download" on Google
echo 3. Put it in lib\ folder of this project

:end
echo.
pause
