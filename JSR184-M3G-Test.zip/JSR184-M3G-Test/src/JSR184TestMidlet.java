import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.m3g.*;

public class JSR184TestMidlet extends MIDlet {
    private Display display;
    private TestCanvas canvas;
    
    public JSR184TestMidlet() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
    }
    
    public void startApp() {
        display.setCurrent(canvas);
        canvas.startTests();
    }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
}

class TestCanvas extends Canvas {
    private MIDlet midlet;
    private String[] results;
    private String[] testNames;
    private boolean testsRunning = true;
    private int currentTest = 0;
    private String[] log = new String[15];
    private int logIndex = 0;
    
    // M3G objects for testing
    private Graphics3D g3d;
    private World world;
    private Camera camera;
    private Light light;
    private Mesh cubeMesh;
    private Group group;
    private Transform transform;
    
    public TestCanvas(MIDlet m) {
        this.midlet = m;
        
        testNames = new String[] {
            "Graphics3D.getInstance()",
            "World creation",
            "Camera creation",
            "Camera.setPerspective()",
            "Light creation",
            "Transform creation",
            "Transform.postRotate()",
            "VertexBuffer creation",
            "VertexArray (positions)",
            "VertexArray (normals)",
            "TriangleStripArray",
            "Mesh creation",
            "Material creation",
            "Appearance creation",
            "Background rendering"
        };
        results = new String[testNames.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = "?";
        }
        
        // Clear log
        for (int i = 0; i < log.length; i++) {
            log[i] = "";
        }
    }
    
    private void addLog(String msg) {
        log[logIndex % log.length] = msg;
        logIndex++;
        repaint();
    }
    
    public void startTests() {
        new Thread() {
            public void run() {
                runTests();
                testsRunning = false;
                repaint();
            }
        }.start();
    }
    
    private void runTests() {
        // Test 1: Graphics3D.getInstance()
        currentTest = 0;
        try {
            g3d = Graphics3D.getInstance();
            results[0] = (g3d != null) ? "PASS" : "FAIL";
            addLog("Test 1: Graphics3D " + (g3d != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[0] = "FAIL";
            addLog("Test 1: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 2: World creation
        currentTest = 1;
        try {
            world = new World();
            results[1] = (world != null) ? "PASS" : "FAIL";
            addLog("Test 2: World " + (world != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[1] = "FAIL";
            addLog("Test 2: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 3: Camera creation
        currentTest = 2;
        try {
            camera = new Camera();
            results[2] = (camera != null) ? "PASS" : "FAIL";
            addLog("Test 3: Camera " + (camera != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[2] = "FAIL";
            addLog("Test 3: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 4: Camera.setPerspective()
        currentTest = 3;
        try {
            camera.setPerspective(60.0f, (float)getWidth() / (float)getHeight(), 1.0f, 1000.0f);
            results[3] = "PASS";
            addLog("Test 4: setPerspective OK");
        } catch (Exception e) {
            results[3] = "FAIL";
            addLog("Test 4: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 5: Light creation
        currentTest = 4;
        try {
            light = new Light();
            light.setMode(Light.AMBIENT);
            light.setColor(0x00FFFFFF);
            results[4] = (light != null) ? "PASS" : "FAIL";
            addLog("Test 5: Light " + (light != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[4] = "FAIL";
            addLog("Test 5: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 6: Transform creation
        currentTest = 5;
        try {
            transform = new Transform();
            results[5] = (transform != null) ? "PASS" : "FAIL";
            addLog("Test 6: Transform " + (transform != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[5] = "FAIL";
            addLog("Test 6: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 7: Transform.postRotate()
        currentTest = 6;
        try {
            transform.postRotate(45.0f, 0.0f, 1.0f, 0.0f);
            results[6] = "PASS";
            addLog("Test 7: postRotate OK");
        } catch (Exception e) {
            results[6] = "FAIL";
            addLog("Test 7: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 8: VertexBuffer creation
        currentTest = 7;
        try {
            VertexBuffer vb = new VertexBuffer();
            results[7] = (vb != null) ? "PASS" : "FAIL";
            addLog("Test 8: VertexBuffer " + (vb != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[7] = "FAIL";
            addLog("Test 8: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 9: VertexArray (positions)
        currentTest = 8;
        try {
            // Cube vertices (8 vertices for a simple cube)
            short[] positions = {
                -1, -1, 1,   1, -1, 1,   1, 1, 1,   -1, 1, 1,    // front
                -1, -1, -1,  -1, 1, -1,  1, 1, -1,  1, -1, -1   // back
            };
            VertexArray posArray = new VertexArray(8, 3, 2);
            posArray.set(0, 8, positions);
            results[8] = (posArray != null) ? "PASS" : "FAIL";
            addLog("Test 9: VertexArray positions OK");
        } catch (Exception e) {
            results[8] = "FAIL";
            addLog("Test 9: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 10: VertexArray (normals)
        currentTest = 9;
        try {
            // Simple normals
            byte[] normals = {
                0, 0, 127,   0, 0, 127,   0, 0, 127,   0, 0, 127,
                0, 0, -127,  0, 0, -127,  0, 0, -127,  0, 0, -127
            };
            VertexArray normArray = new VertexArray(8, 3, 1);
            normArray.set(0, 8, normals);
            results[9] = (normArray != null) ? "PASS" : "FAIL";
            addLog("Test 10: VertexArray normals OK");
        } catch (Exception e) {
            results[9] = "FAIL";
            addLog("Test 10: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 11: TriangleStripArray
        currentTest = 10;
        try {
            // Indices for cube faces
            int[] indices = {
                0, 1, 2, 3,    // front
                0, 0, 0, 0,    // placeholder for strip lengths
            };
            int[] stripLengths = {4};
            TriangleStripArray tsa = new TriangleStripArray(0, stripLengths);
            results[10] = (tsa != null) ? "PASS" : "FAIL";
            addLog("Test 11: TriangleStripArray OK");
        } catch (Exception e) {
            results[10] = "FAIL";
            addLog("Test 11: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 12: Mesh creation
        currentTest = 11;
        try {
            // Create a simple quad mesh
            short[] positions = {-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 1, 0};
            VertexArray posArray = new VertexArray(4, 3, 2);
            posArray.set(0, 4, positions);
            
            VertexBuffer vb = new VertexBuffer();
            vb.setPositions(posArray, 1.0f, null);
            
            int[] stripLengths = {4};
            IndexBuffer ib = new TriangleStripArray(0, stripLengths);
            
            Appearance app = new Appearance();
            cubeMesh = new Mesh(vb, ib, app);
            results[11] = (cubeMesh != null) ? "PASS" : "FAIL";
            addLog("Test 12: Mesh " + (cubeMesh != null ? "OK" : "NULL"));
        } catch (Exception e) {
            results[11] = "FAIL";
            addLog("Test 12: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 13: Material creation
        currentTest = 12;
        try {
            Material mat = new Material();
            mat.setColor(Material.DIFFUSE, 0xFF0000FF);
            mat.setColor(Material.SPECULAR, 0xFFFFFFFF);
            mat.setShininess(100.0f);
            results[12] = (mat != null) ? "PASS" : "FAIL";
            addLog("Test 13: Material OK");
        } catch (Exception e) {
            results[12] = "FAIL";
            addLog("Test 13: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 14: Appearance creation
        currentTest = 13;
        try {
            Appearance app = new Appearance();
            Material mat = new Material();
            mat.setColor(Material.DIFFUSE, 0xFF00FF00);
            app.setMaterial(mat);
            results[13] = (app != null && app.getMaterial() != null) ? "PASS" : "FAIL";
            addLog("Test 14: Appearance OK");
        } catch (Exception e) {
            results[13] = "FAIL";
            addLog("Test 14: ERROR - " + e.getClass().getName());
        }
        sleep(300);
        
        // Test 15: Background and rendering setup
        currentTest = 14;
        try {
            Background bg = new Background();
            bg.setColor(0x00003366);
            
            if (world != null) {
                world.setBackground(bg);
                
                if (camera != null) {
                    world.addChild(camera);
                    world.setActiveCamera(camera);
                }
                
                if (light != null) {
                    world.addChild(light);
                }
                
                if (cubeMesh != null) {
                    world.addChild(cubeMesh);
                }
            }
            
            results[14] = "PASS";
            addLog("Test 15: Background & World setup OK");
        } catch (Exception e) {
            results[14] = "FAIL";
            addLog("Test 15: ERROR - " + e.getClass().getName());
        }
        
        addLog("=== ALL JSR-184 TESTS COMPLETED ===");
    }
    
    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }
    
    protected void paint(Graphics g) {
        // Clear screen
        g.setColor(255, 255, 255);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        int y = 15;
        int width = getWidth();
        
        // Title
        g.setColor(0, 0, 0);
        g.drawString("JSR-184 M3G Tests", width/2, y, Graphics.TOP | Graphics.HCENTER);
        y += 20;
        
        if (testsRunning) {
            // Show current test
            g.setColor(0, 0, 150);
            g.drawString("Running test " + (currentTest + 1) + "/" + testNames.length, 
                        5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            g.drawString(testNames[currentTest], 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            g.drawString("Result: " + results[currentTest], 5, y, Graphics.TOP | Graphics.LEFT);
            y += 25;
            
            // Execution log
            g.setColor(100, 100, 100);
            g.drawString("--- Log ---", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;
            
            for (int i = 0; i < log.length; i++) {
                int idx = (logIndex - log.length + i + log.length) % log.length;
                if (log[idx].length() > 0) {
                    g.drawString(log[idx], 10, y, Graphics.TOP | Graphics.LEFT);
                    y += 14;
                }
            }
            
            // Progress bar
            y = getHeight() - 30;
            int progressWidth = (width - 40) * (currentTest + 1) / testNames.length;
            g.setColor(0, 150, 0);
            g.fillRect(20, y, progressWidth, 15);
            g.setColor(200, 200, 200);
            g.fillRect(20 + progressWidth, y, (width - 40) - progressWidth, 15);
            
        } else {
            // Show all results
            g.setColor(0, 0, 0);
            g.drawString("JSR-184 M3G RESULTS:", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 18;
            
            for (int i = 0; i < testNames.length; i++) {
                if (results[i].equals("PASS")) {
                    g.setColor(0, 150, 0);
                } else {
                    g.setColor(200, 0, 0);
                }
                g.drawString(results[i] + " - " + testNames[i], 5, y, Graphics.TOP | Graphics.LEFT);
                y += 16;
            }
            
            y += 10;
            g.setColor(0, 0, 150);
            g.drawString("Press any key to exit", width/2, getHeight() - 20, 
                        Graphics.BOTTOM | Graphics.HCENTER);
        }
    }
    
    protected void keyPressed(int keyCode) {
        if (!testsRunning) {
            midlet.notifyDestroyed();
        }
    }
}
