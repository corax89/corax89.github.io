@echo off
setlocal enabledelayedexpansion

REM ========================================
REM JSR-184 M3G Test Build Script
REM ========================================

set SDK_HOME=C:\Java_ME_platform_SDK_3.0
set LOCAL_LIB=lib

echo.
echo ========================================
echo Building JSR-184 M3G Test for J2ME
echo ========================================
echo.

REM Create directories
if not exist classes mkdir classes
if not exist bin mkdir bin

echo [1/5] Checking libraries...

REM Set CLDC and MIDP paths
if exist "%SDK_HOME%\lib\cldc_1.1.jar" (
    set CLDC=%SDK_HOME%\lib\cldc_1.1.jar
    set MIDP=%SDK_HOME%\lib\midp_2.0.jar
    echo Using Java ME SDK: %SDK_HOME%
) else (
    set CLDC=%LOCAL_LIB%\cldc_1.1.jar
    set MIDP=%LOCAL_LIB%\midp_2.0.jar
    echo Using local lib folder
)

REM Find JSR-184 (check multiple locations)
set JSR184=
if exist "lib\jsr_184.jar" (
    set JSR184=lib\jsr_184.jar
    echo Found: lib\jsr_184.jar
) else if exist "lib\jsr184.jar" (
    set JSR184=lib\jsr184.jar
    echo Found: lib\jsr184.jar
) else if exist "jsr_184_stub.jar" (
    set JSR184=jsr_184_stub.jar
    echo Found: jsr_184_stub.jar
)

REM If not found, try to create stub from jsr184-stub folder
if "%JSR184%"=="" (
    if exist "jsr184-stub\javax\microedition\m3g\Object3D.java" (
        echo.
        echo JSR-184 library not found. Creating stub from jsr184-stub...
        echo.

        echo [2/5] Compiling stub classes...
        javac -source 1.3 -target 1.3 -bootclasspath "%CLDC%;%MIDP%" -d . jsr184-stub\javax\microedition\m3g\*.java 2>&1
        if errorlevel 1 (
            echo.
            echo Warning: Stub compilation had errors, trying alternative...
        )

        if exist "javax\microedition\m3g\Object3D.class" (
            echo Creating jsr_184_stub.jar...
            jar cf jsr_184_stub.jar javax\microedition\m3g\*.class
            set JSR184=jsr_184_stub.jar
            echo Created: jsr_184_stub.jar

            REM Cleanup compiled stub classes
            rmdir /s /q javax 2>nul
        )
    )
)

if "%JSR184%"=="" (
    echo.
    echo ========================================
    echo ERROR: JSR-184 library not found!
    echo ========================================
    echo.
    echo Solutions:
    echo 1. Ensure jsr184-stub folder exists
    echo 2. Or put jsr_184.jar in lib\ folder
    echo.
    pause
    exit /b 1
)

echo.
echo [3/5] Cleaning old files...
if exist classes\*.class del /q classes\*.class 2>nul
if exist classes\*$*.class del /q classes\*$*.class 2>nul
if exist bin\*.jar del /q bin\*.jar 2>nul

echo [4/5] Compiling...
javac -source 1.3 -target 1.3 -bootclasspath "%CLDC%;%MIDP%;%JSR184%" -d classes src\JSR184TestMidlet.java 2>&1
if errorlevel 1 goto error

echo [5/5] Creating JAR...

REM Create MANIFEST.MF in bin folder (like original)
echo MIDlet-Name: JSR-184 M3G Test> bin\MANIFEST.MF
echo MIDlet-Vendor: Test>> bin\MANIFEST.MF
echo MIDlet-Version: 1.0>> bin\MANIFEST.MF
echo MIDlet-1: JSR184Test,,JSR184TestMidlet>> bin\MANIFEST.MF
echo MicroEdition-Configuration: CLDC-1.1>> bin\MANIFEST.MF
echo MicroEdition-Profile: MIDP-2.0>> bin\MANIFEST.MF
echo.>> bin\MANIFEST.MF

cd classes
jar cfm ..\bin\JSR184Test.jar ..\bin\MANIFEST.MF *.class
cd ..

REM Get JAR size
for %%I in (bin\JSR184Test.jar) do set JARSIZE=%%~zI

REM Create JAD (like original)
echo MIDlet-Name: JSR-184 M3G Test> JSR184Test.jad
echo MIDlet-Vendor: Test>> JSR184Test.jad
echo MIDlet-Version: 1.0>> JSR184Test.jad
echo MIDlet-1: JSR184Test,,JSR184TestMidlet>> JSR184Test.jad
echo MIDlet-Jar-URL: JSR184Test.jar>> JSR184Test.jad
echo MIDlet-Jar-Size: %JARSIZE%>> JSR184Test.jad
echo MicroEdition-Configuration: CLDC-1.1>> JSR184Test.jad
echo MicroEdition-Profile: MIDP-2.0>> JSR184Test.jad

echo.
echo ========================================
echo Build successful!
echo ========================================
echo JAR: bin\JSR184Test.jar
echo Size: %JARSIZE% bytes
echo.
echo Contents of JAR:
jar tf bin\JSR184Test.jar
echo.
echo MANIFEST.MF contents:
type bin\MANIFEST.MF
echo.
pause
goto end

:error
echo.
echo ========================================
echo BUILD FAILED!
echo ========================================
echo.
pause

:end
endlocal
