@echo off
echo ========================================
echo Creating JSR-184 Stub JAR
echo ========================================
echo.
echo This script creates jsr_184_stub.jar
echo from the stub source files.
echo.

if not exist "javax\microedition\m3g" (
    echo ERROR: Stub source files not found!
    echo Please run this script from jsr184-stub folder
    pause
    exit /b 1
)

echo Compiling stub classes...
javac -source 1.3 -target 1.3 javax\microedition\m3g\*.java
if errorlevel 1 (
    echo.
    echo Compilation failed!
    pause
    exit /b 1
)

echo Creating JAR...
jar cf jsr_184_stub.jar javax\microedition\m3g\*.class

if exist jsr_184_stub.jar (
    echo.
    echo ========================================
    echo SUCCESS!
    echo ========================================
    echo Created: jsr_184_stub.jar
    echo.
    echo Copy this file to your project's lib\ folder:
    echo   copy jsr_184_stub.jar ..\jsr184-test\lib\jsr_184.jar
    echo.
) else (
    echo Failed to create JAR!
)

pause
