package javax.microedition.m3g;

public class CompositingMode extends Object3D {
    public static final int ALPHA = 64;
    public static final int ALPHA_ADD = 65;
    public static final int MODULATE = 66;
    public static final int MODULATE_X2 = 67;
    public static final int REPLACE = 68;
    public void setBlending(int mode) {}
    public int getBlending() { return ALPHA; }
    public void setAlphaThreshold(float threshold) {}
    public float getAlphaThreshold() { return 0.0f; }
    public void setAlphaWriteEnable(boolean enable) {}
    public boolean isAlphaWriteEnabled() { return false; }
    public void setColorWriteEnable(boolean enable) {}
    public boolean isColorWriteEnabled() { return true; }
    public void setDepthWriteEnable(boolean enable) {}
    public boolean isDepthWriteEnabled() { return true; }
    public void setDepthTestEnable(boolean enable) {}
    public boolean isDepthTestEnabled() { return true; }
}
