package javax.microedition.m3g;

public class Mesh extends Node {
    private VertexBuffer vertices;
    private IndexBuffer indices;
    private Appearance appearance;
    public Mesh(VertexBuffer vertices, IndexBuffer indices, Appearance appearance) {
        this.vertices = vertices;
        this.indices = indices;
        this.appearance = appearance;
    }
    public VertexBuffer getVertexBuffer() { return vertices; }
    public IndexBuffer getIndexBuffer() { return indices; }
    public Appearance getAppearance() { return appearance; }
    public void setAppearance(Appearance appearance) { this.appearance = appearance; }
    public int getSubmeshCount() { return 1; }
    public Appearance getAppearance(int index) { return appearance; }
    public void setAppearance(int index, Appearance appearance) { this.appearance = appearance; }
    public IndexBuffer getIndexBuffer(int index) { return indices; }
}
