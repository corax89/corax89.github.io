package javax.microedition.m3g;

public class Texture2D extends Object3D {
    public static final int FILTER_BASE_LEVEL = 208;
    public static final int FILTER_NEAREST = 209;
    public static final int FILTER_LINEAR = 210;
    public static final int WRAP_CLAMP = 240;
    public static final int WRAP_REPEAT = 241;
    public static final int FUNC_ADD = 224;
    public static final int FUNC_BLEND = 225;
    public static final int FUNC_DECAL = 226;
    public static final int FUNC_MODULATE = 227;
    public static final int FUNC_REPLACE = 228;
    private Image2D image;
    public Texture2D(Image2D image) { this.image = image; }
    public Image2D getImage() { return image; }
    public void setFiltering(int levelFilter, int imageFilter) {}
    public int getLevelFilter() { return FILTER_BASE_LEVEL; }
    public int getImageFilter() { return FILTER_NEAREST; }
    public void setWrapping(int wrapS, int wrapT) {}
    public int getWrappingS() { return WRAP_CLAMP; }
    public int getWrappingT() { return WRAP_CLAMP; }
    public void setBlending(int blending) {}
    public int getBlending() { return FUNC_MODULATE; }
    public void setBlendColor(int color) {}
    public int getBlendColor() { return 0; }
    public void setImageTransform(Transform transform) {}
    public Transform getImageTransform(Transform transform) { return transform; }
}
