package javax.microedition.m3g;

public class PolygonMode extends Object3D {
    public static final int SHADE_FLAT = 1;
    public static final int SHADE_SMOOTH = 2;
    public static final int WINDING_CCW = 3;
    public static final int WINDING_CW = 4;
    public static final int CULL_BACK = 5;
    public static final int CULL_FRONT = 6;
    public static final int CULL_NONE = 7;
    public void setCulling(int mode) {}
    public int getCulling() { return CULL_BACK; }
    public void setShading(int mode) {}
    public int getShading() { return SHADE_SMOOTH; }
    public void setWinding(int mode) {}
    public int getWinding() { return WINDING_CCW; }
    public void setTwoSidedLightingEnable(boolean enable) {}
    public boolean isTwoSidedLightingEnabled() { return false; }
    public void setPerspectiveCorrectionEnable(boolean enable) {}
    public boolean isPerspectiveCorrectionEnabled() { return true; }
    public void setLocalCameraLightingEnable(boolean enable) {}
    public boolean isLocalCameraLightingEnabled() { return false; }
}
