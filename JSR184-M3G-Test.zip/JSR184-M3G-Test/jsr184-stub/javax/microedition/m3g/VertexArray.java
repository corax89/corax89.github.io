package javax.microedition.m3g;

public class VertexArray extends Object3D {
    private int vertexCount;
    private int componentSize;
    private int componentCount;
    public VertexArray(int numVertices, int numComponents, int componentSize) {
        this.vertexCount = numVertices;
        this.componentCount = numComponents;
        this.componentSize = componentSize;
    }
    public void set(int firstVertex, int numVertices, byte[] values) {}
    public void set(int firstVertex, int numVertices, short[] values) {}
    public int getVertexCount() { return vertexCount; }
    public int getComponentCount() { return componentCount; }
    public int getComponentType() { return componentSize; }
    public void get(int firstVertex, int numVertices, byte[] values) {}
    public void get(int firstVertex, int numVertices, short[] values) {}
}
