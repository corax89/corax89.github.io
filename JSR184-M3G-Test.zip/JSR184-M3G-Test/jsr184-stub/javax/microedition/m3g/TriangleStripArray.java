package javax.microedition.m3g;

public class TriangleStripArray extends IndexBuffer {
    private int[] stripLengths;
    public TriangleStripArray(int[] indices, int[] stripLengths) {
        this.stripLengths = stripLengths;
    }
    public TriangleStripArray(int firstIndex, int[] stripLengths) {
        this.stripLengths = stripLengths;
    }
    public int getIndexCount() {
        int count = 0;
        for (int i = 0; i < stripLengths.length; i++) {
            count += (stripLengths[i] - 2) * 3;
        }
        return count;
    }
}
