package javax.microedition.m3g;

public class Light extends Node {
    public static final int AMBIENT = 1;
    public static final int DIRECTIONAL = 2;
    public static final int OMNI = 3;
    public static final int SPOT = 4;
    private int mode = DIRECTIONAL;
    private int color = 0x00FFFFFF;
    public void setMode(int mode) { this.mode = mode; }
    public int getMode() { return mode; }
    public void setColor(int color) { this.color = color; }
    public int getColor() { return color; }
    public void setIntensity(float intensity) {}
    public float getIntensity() { return 1.0f; }
    public void setSpotAngle(float angle) {}
    public float getSpotAngle() { return 45.0f; }
    public void setSpotExponent(float exponent) {}
    public float getSpotExponent() { return 0.0f; }
}
