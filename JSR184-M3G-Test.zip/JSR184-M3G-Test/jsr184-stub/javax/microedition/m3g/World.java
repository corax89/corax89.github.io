package javax.microedition.m3g;

public class World extends Group {
    private Camera activeCamera;
    private Background background;
    public void setActiveCamera(Camera camera) { activeCamera = camera; }
    public Camera getActiveCamera() { return activeCamera; }
    public void setBackground(Background background) { this.background = background; }
    public Background getBackground() { return background; }
}
