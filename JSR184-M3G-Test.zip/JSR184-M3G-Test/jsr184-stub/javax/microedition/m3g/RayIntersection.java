package javax.microedition.m3g;

public class RayIntersection {
    private float[] ray = new float[6];
    private Node intersected = null;
    private float distance = 0;
    private int submeshIndex = 0;
    private float[] texture = new float[2];
    public float getDistance() { return distance; }
    public Node getIntersected() { return intersected; }
    public float[] getRay() { return ray; }
    public int getSubmeshIndex() { return submeshIndex; }
    public void getNormal(float[] normal) {}
    public void getTexture(float[] texture) {}
    public float[] getTextureS(int index) { return texture; }
}
