package javax.microedition.m3g;

public class Object3D {
    public int getUserID() { return 0; }
    public void setUserID(int userID) {}
    public Object3D duplicate() { return null; }
    public void addAnimationTrack(AnimationTrack animationTrack) {}
    public void animate(int time) {}
    public AnimationTrack getAnimationTrack(int index) { return null; }
    public int getAnimationTrackCount() { return 0; }
}
