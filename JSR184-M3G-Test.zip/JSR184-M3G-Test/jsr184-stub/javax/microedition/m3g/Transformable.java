package javax.microedition.m3g;

public class Transformable extends Object3D {
    private Transform transform = new Transform();
    public void setTransform(Transform transform) { if (transform != null) this.transform = transform; }
    public Transform getTransform(Transform transform) { return this.transform; }
    public void getCompositeTransform(Transform transform) {}
    public void setTranslation(float tx, float ty, float tz) {}
    public void getTranslation(float[] translation) {}
    public void setOrientation(float angle, float ax, float ay, float az) {}
    public void getOrientation(float[] orientation) {}
    public void setScale(float sx, float sy, float sz) {}
    public void getScale(float[] scale) {}
    public void preMultiply(Transform transform) {}
    public void postMultiply(Transform transform) {}
}
