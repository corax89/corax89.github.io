package javax.microedition.m3g;

import java.io.IOException;
public class Loader {
    public static Object3D[] load(String name) throws IOException { return null; }
    public static Object3D[] load(byte[] data, int offset) throws IOException { return null; }
}
