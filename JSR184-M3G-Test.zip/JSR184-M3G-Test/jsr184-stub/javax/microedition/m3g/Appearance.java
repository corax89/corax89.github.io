package javax.microedition.m3g;

public class Appearance extends Object3D {
    private Material material;
    private CompositingMode compositingMode;
    private PolygonMode polygonMode;
    public void setMaterial(Material material) { this.material = material; }
    public Material getMaterial() { return material; }
    public void setCompositingMode(CompositingMode mode) { this.compositingMode = mode; }
    public CompositingMode getCompositingMode() { return compositingMode; }
    public void setPolygonMode(PolygonMode mode) { this.polygonMode = mode; }
    public PolygonMode getPolygonMode() { return polygonMode; }
    public void setTexture(int index, Texture2D texture) {}
    public Texture2D getTexture(int index) { return null; }
    public int getTextureCount() { return 0; }
}
