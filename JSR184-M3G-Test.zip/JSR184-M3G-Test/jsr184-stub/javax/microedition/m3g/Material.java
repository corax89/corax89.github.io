package javax.microedition.m3g;

public class Material extends Object3D {
    public static final int AMBIENT = 1;
    public static final int DIFFUSE = 2;
    public static final int EMISSIVE = 3;
    public static final int SPECULAR = 4;
    private int ambientColor = 0x00333333;
    private int diffuseColor = 0xFFCCCCCC;
    private int emissiveColor = 0;
    private int specularColor = 0;
    private float shininess = 0.0f;
    public void setColor(int target, int color) {}
    public int getColor(int target) { return 0; }
    public void setShininess(float shininess) { this.shininess = shininess; }
    public float getShininess() { return shininess; }
    public void setVertexColorTrackingEnable(boolean enable) {}
    public boolean isVertexColorTrackingEnabled() { return false; }
}
