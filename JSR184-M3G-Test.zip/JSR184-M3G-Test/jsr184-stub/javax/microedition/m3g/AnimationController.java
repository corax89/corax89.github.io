package javax.microedition.m3g;

public class AnimationController extends Object3D {
    private int activeIntervalStart = 0;
    private int activeIntervalEnd = Integer.MAX_VALUE;
    private float speed = 1.0f;
    private float weight = 1.0f;
    private float position = 0.0f;
    private int referenceSequenceTime = 0;
    public void setActiveInterval(int start, int end) { activeIntervalStart = start; activeIntervalEnd = end; }
    public int getActiveIntervalStart() { return activeIntervalStart; }
    public int getActiveIntervalEnd() { return activeIntervalEnd; }
    public void setSpeed(float speed) { this.speed = speed; }
    public float getSpeed() { return speed; }
    public void setWeight(float weight) { this.weight = weight; }
    public float getWeight() { return weight; }
    public void setPosition(float position) { this.position = position; }
    public float getPosition() { return position; }
    public void setRefWorldTime(int worldTime) { referenceSequenceTime = worldTime; }
    public int getRefWorldTime() { return referenceSequenceTime; }
}
