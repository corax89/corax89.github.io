package javax.microedition.m3g;

public class Transform {
    private float[] m = new float[16];
    public Transform() {
        setIdentity();
    }
    public Transform(Transform transform) {
        for (int i = 0; i < 16; i++) m[i] = transform.m[i];
    }
    public void setIdentity() {
        for (int i = 0; i < 16; i++) m[i] = (i % 5 == 0) ? 1.0f : 0.0f;
    }
    public void set(Transform transform) {
        for (int i = 0; i < 16; i++) m[i] = transform.m[i];
    }
    public void set(float[] matrix) {
        for (int i = 0; i < 16 && i < matrix.length; i++) m[i] = matrix[i];
    }
    public void get(float[] matrix) {
        for (int i = 0; i < 16 && i < matrix.length; i++) matrix[i] = m[i];
    }
    public void multiply(Transform transform) {}
    public void postMultiply(Transform transform) {}
    public void preMultiply(Transform transform) {}
    public void postRotate(float angle, float ax, float ay, float az) {}
    public void preRotate(float angle, float ax, float ay, float az) {}
    public void postScale(float sx, float sy, float sz) {}
    public void preScale(float sx, float sy, float sz) {}
    public void postTranslate(float tx, float ty, float tz) {}
    public void preTranslate(float tx, float ty, float tz) {}
    public void transpose() {}
    public void invert() { }
    public void transform(float[] vectors) {}
    public void transform(VertexArray vertices, float[] floatArray, boolean w) {}
}
