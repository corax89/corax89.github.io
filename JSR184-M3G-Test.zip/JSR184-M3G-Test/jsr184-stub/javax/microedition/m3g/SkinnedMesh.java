package javax.microedition.m3g;

public class SkinnedMesh extends Mesh {
    private Group skeleton;
    public SkinnedMesh(VertexBuffer vertices, IndexBuffer indices, Appearance appearance, Group skeleton) {
        super(vertices, indices, appearance);
        this.skeleton = skeleton;
    }
    public SkinnedMesh(VertexBuffer vertices, IndexBuffer[] indices, Appearance[] appearances, Group skeleton) {
        super(vertices, indices[0], appearances[0]);
        this.skeleton = skeleton;
    }
    public Group getSkeleton() { return skeleton; }
    public void addTransform(Node bone, int weight, int firstVertex, int numVertices) {}
}
