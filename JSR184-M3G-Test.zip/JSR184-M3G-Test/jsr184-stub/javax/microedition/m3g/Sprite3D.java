package javax.microedition.m3g;

public class Sprite3D extends Node {
    private boolean scaled;
    private Image2D image;
    private Appearance appearance;
    public Sprite3D(boolean scaled, Image2D image, Appearance appearance) {
        this.scaled = scaled;
        this.image = image;
        this.appearance = appearance;
    }
    public void setImage(Image2D image) { this.image = image; }
    public Image2D getImage() { return image; }
    public void setAppearance(Appearance appearance) { this.appearance = appearance; }
    public Appearance getAppearance() { return appearance; }
    public void setCrop(int cropX, int cropY, int width, int height) {}
    public int getCropX() { return 0; }
    public int getCropY() { return 0; }
    public int getCropWidth() { return 0; }
    public int getCropHeight() { return 0; }
    public boolean isScaled() { return scaled; }
}
