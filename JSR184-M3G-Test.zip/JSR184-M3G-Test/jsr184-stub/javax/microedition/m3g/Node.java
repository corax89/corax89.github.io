package javax.microedition.m3g;

public class Node extends Object3D {
    public static final int NONE = 0;
    public boolean getTransformTo(Node target, Transform transform) { return false; }
    public void setTransform(Transform transform) {}
    public void preTransform(Transform transform) {}
    public void postTransform(Transform transform) {}
    public boolean isPickingEnabled() { return true; }
    public void setPickingEnable(boolean enable) {}
    public boolean isRenderingEnabled() { return true; }
    public void setRenderingEnable(boolean enable) {}
    public int getScope() { return -1; }
    public void setScope(int scope) {}
    public void setAlignment(Node zRef, int zTarget, Node yRef, int yTarget) {}
    public void translate(float tx, float ty, float tz) {}
    public void rotate(float angle, float ax, float ay, float az) {}
    public void scale(float sx, float sy, float sz) {}
    public void align() {}
}
