package javax.microedition.m3g;

public class VertexBuffer extends Object3D {
    private VertexArray positions;
    private VertexArray normals;
    public void setPositions(VertexArray positions, float scale, float[] bias) {
        this.positions = positions;
    }
    public VertexArray getPositions() { return positions; }
    public void setNormals(VertexArray normals) { this.normals = normals; }
    public VertexArray getNormals() { return normals; }
    public void setColors(VertexArray colors) {}
    public VertexArray getColors() { return null; }
    public void setTexCoords(int index, VertexArray texCoords, float scale, float[] bias) {}
    public VertexArray getTexCoords(int index, float[] scaleBias) { return null; }
    public int getVertexCount() { return positions != null ? positions.getVertexCount() : 0; }
}
