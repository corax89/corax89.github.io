package javax.microedition.m3g;

public class Graphics3D {
    private static Graphics3D instance = new Graphics3D();
    public static Graphics3D getInstance() { return instance; }
    public void bindTarget(Object target) {}
    public void releaseTarget() {}
    public void clear(Background background) {}
    public void render(World world) {}
    public void render(Node node, Transform transform) {}
    public void render(VertexBuffer vertices, IndexBuffer indices, Appearance appearance, Transform transform) {}
    public void render(VertexBuffer vertices, IndexBuffer indices, Appearance appearance, Transform transform, int scope) {}
    public void setViewport(int x, int y, int width, int height) {}
    public int getViewportWidth() { return 0; }
    public int getViewportHeight() { return 0; }
    public void setCamera(Camera camera, Transform transform) {}
    public void setLight(int index, Light light, Transform transform) {}
    public int getLightCount() { return 0; }
    public void resetLights() {}
}
