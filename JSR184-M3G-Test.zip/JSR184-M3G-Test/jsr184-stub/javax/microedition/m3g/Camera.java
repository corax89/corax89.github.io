package javax.microedition.m3g;

public class Camera extends Node {
    public static final int GENERIC = 0;
    public static final int PARALLEL = 1;
    public static final int PERSPECTIVE = 2;
    public void setPerspective(float fovy, float aspectRatio, float near, float far) {}
    public void setParallel(float height, float aspectRatio, float near, float far) {}
    public void setGeneric() {}
    public int getProjectionType() { return PERSPECTIVE; }
    public void getProjection(float[] params) {}
    public void getProjection(Transform transform) {}
}
