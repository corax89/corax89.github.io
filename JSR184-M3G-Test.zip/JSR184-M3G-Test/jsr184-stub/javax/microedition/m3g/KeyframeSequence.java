package javax.microedition.m3g;

public class KeyframeSequence extends Object3D {
    public static final int LINEAR = 176;
    public static final int SLERP = 177;
    public static final int SPLINE = 178;
    public static final int SQUAD = 179;
    public static final int STEP = 180;
    public static final int CONSTANT = 192;
    public static final int LOOP = 193;
    private int duration = 0;
    private int repeatMode = CONSTANT;
    public KeyframeSequence(int numKeyframes, int numComponents, int interpolation) {}
    public void setKeyframe(int index, int time, float[] value) {}
    public void setDuration(int duration) { this.duration = duration; }
    public int getDuration() { return duration; }
    public void setRepeatMode(int mode) { this.repeatMode = mode; }
    public int getRepeatMode() { return repeatMode; }
    public void setValidRange(int first, int last) {}
    public int getValidRangeFirst() { return 0; }
    public int getValidRangeLast() { return 0; }
    public int getKeyframeCount() { return 0; }
    public int getKeyframeTime(int index) { return 0; }
    public void getKeyframe(int index, float[] value) {}
}
