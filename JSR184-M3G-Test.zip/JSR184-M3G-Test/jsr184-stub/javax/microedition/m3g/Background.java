package javax.microedition.m3g;

public class Background extends Object3D {
    public static final int BORDER = 32;
    public static final int REPEAT = 33;
    private int color = 0x00000000;
    private Image2D backgroundImage;
    public void setColor(int color) { this.color = color; }
    public int getColor() { return color; }
    public void setImage(Image2D image) { this.backgroundImage = image; }
    public Image2D getImage() { return backgroundImage; }
    public void setImageMode(int modeX, int modeY) {}
    public int getImageModeX() { return BORDER; }
    public int getImageModeY() { return BORDER; }
    public void setCrop(int cropX, int cropY, int width, int height) {}
    public int getCropX() { return 0; }
    public int getCropY() { return 0; }
    public int getCropWidth() { return 0; }
    public int getCropHeight() { return 0; }
    public void setDepthClearEnable(boolean enable) {}
    public boolean isDepthClearEnabled() { return true; }
    public void setColorClearEnable(boolean enable) {}
    public boolean isColorClearEnabled() { return true; }
}
