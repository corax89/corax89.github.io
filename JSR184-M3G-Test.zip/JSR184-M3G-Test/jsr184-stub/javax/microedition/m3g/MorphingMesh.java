package javax.microedition.m3g;

public class MorphingMesh extends Mesh {
    private VertexBuffer[] morphTargets;
    private float[] weights;
    public MorphingMesh(VertexBuffer base, VertexBuffer[] morphTargets, IndexBuffer indices, Appearance appearance) {
        super(base, indices, appearance);
        this.morphTargets = morphTargets;
    }
    public void setWeights(float[] weights) { this.weights = weights; }
    public float[] getWeights() { return weights; }
    public VertexBuffer getMorphTarget(int index) { return morphTargets != null && index < morphTargets.length ? morphTargets[index] : null; }
    public int getMorphTargetCount() { return morphTargets != null ? morphTargets.length : 0; }
}
