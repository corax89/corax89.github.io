JSR-184 M3G Test Suite
======================

Тест для проверки поддержки JSR-184 (Mobile 3D Graphics API) на J2ME устройствах.

СОДЕРЖИМОЕ АРХИВА
-----------------
jsr184-test/
├── src/JSR184TestMidlet.java  - исходный код теста (15 тестов)
├── lib/                       - библиотеки CLDC/MIDP
├── bin/                       - сюда будет помещен JAR
├── build.bat                  - скрипт сборки (Windows)
├── build.sh                   - скрипт сборки (Linux/Mac)
├── manifest.mf                - манифест
├── JSR184Test.jad             - JAD дескриптор

jsr184-stub/                   - STUB библиотека JSR-184!
├── javax/microedition/m3g/    - исходники заглушки
└── make_stub.bat              - создание jsr_184_stub.jar


КАК СОБРАТЬ ПРОЕКТ
------------------
1. Распакуйте архив
2. Запустите build.bat

Скрипт автоматически:
- Найдет CLDC/MIDP в Java ME SDK или lib/
- Создаст jsr_184_stub.jar из jsr184-stub/
- Скомпилирует и упакует проект


ЧТО ТАКОЕ STUB?
---------------
jsr184-stub - это заглушка (stub) для JSR-184 API.
Содержит только объявления классов и методов без реализации.

Это позволяет:
- Компилировать код без настоящего jsr_184.jar
- Запускать на устройстве с реальной поддержкой JSR-184


ТЕСТЫ (15 штук)
---------------
1.  Graphics3D.getInstance()  - синглтон 3D графики
2.  World creation            - корневой узел сцены
3.  Camera creation           - камера
4.  Camera.setPerspective()   - перспективная проекция
5.  Light creation            - источник света
6.  Transform creation        - матрица трансформации
7.  Transform.postRotate()    - поворот
8.  VertexBuffer creation     - буфер вершин
9.  VertexArray (positions)   - позиции вершин
10. VertexArray (normals)     - нормали
11. TriangleStripArray        - индексный буфер
12. Mesh creation             - 3D меш
13. Material creation         - материал
14. Appearance creation       - внешний вид
15. Background rendering      - фон и сборка сцены


ТРЕБОВАНИЯ
----------
- JDK 1.8+ (для сборки)
- Java ME Platform SDK 3.0 ИЛИ CLDC/MIDP в lib/
- Устройство/эмулятор с поддержкой JSR-184 (для запуска)


ЗАПУСК НА УСТРОЙСТВЕ
--------------------
- Скопируйте JSR184Test.jar и JSR184Test.jad на устройство
- Запустите JAD файл для установки
