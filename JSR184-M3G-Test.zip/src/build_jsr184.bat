@echo off
echo Building JSR-184 M3G Test Midlet
echo.

REM Set paths - adjust JAVA_HOME to your JDK installation
set JAVA_HOME=C:\Program Files\Java\jdk1.8.0
set PATH=%JAVA_HOME%\bin;%PATH%
set CLDC_LIB=..\lib\cldc_1.1.jar
set MIDP_LIB=..\lib\midp_2.0.jar
set STUB_DIR=jsr184-stub
set STUB_JAR=..\jsr184_stub.jar

echo Step 1: Clean old files
if exist %STUB_JAR% del %STUB_JAR%
if exist JSR184Test.jar del JSR184Test.jar
if not exist build mkdir build
del /q build\*.* 2>nul

echo Step 2: Compile stub classes
javac -source 1.3 -target 1.3 -classpath %MIDP_LIB% -d build %STUB_DIR%\javax\microedition\m3g\*.java
if errorlevel 1 goto error

echo Step 3: Create stub jar
cd build
jar cf ..\%STUB_JAR% javax
cd ..
if errorlevel 1 goto error

echo Step 4: Compile midlet
javac -source 1.3 -target 1.3 -bootclasspath %CLDC_LIB% -classpath %STUB_JAR%;%MIDP_LIB% -d build JSR184TestMidlet.java
if errorlevel 1 goto error

echo Step 5: Create JAR with manifest
cd build
jar cfm ..\JSR184Test.jar ..\manifest.mf *.class javax
cd ..
if errorlevel 1 goto error

echo Step 6: Create JAD
echo MIDlet-1: JSR184Test, , JSR184TestMidlet > JSR184Test.jad
echo MIDlet-Name: JSR-184 M3G Test >> JSR184Test.jad
echo MIDlet-Vendor: Test >> JSR184Test.jad
echo MIDlet-Version: 1.0 >> JSR184Test.jad
echo MicroEdition-Configuration: CLDC-1.1 >> JSR184Test.jad
echo MicroEdition-Profile: MIDP-2.0 >> JSR184Test.jad
echo MIDlet-Jar-URL: JSR184Test.jar >> JSR184Test.jad
echo MIDlet-Jar-Size: >> JSR184Test.jad
for %%I in (JSR184Test.jar) do echo MIDlet-Jar-Size: %%~zI >> JSR184Test.jad

echo.
echo Build complete!
echo JAR: JSR184Test.jar
echo JAD: JSR184Test.jad
goto end

:error
echo.
echo BUILD FAILED!
echo Check the error messages above.

:end
pause
