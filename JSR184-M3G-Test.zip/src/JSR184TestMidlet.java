import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.m3g.*;

public class JSR184TestMidlet extends MIDlet {
    private Display display;
    private TestCanvas canvas;
    
    public JSR184TestMidlet() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
    }
    
    public void startApp() {
        display.setCurrent(canvas);
        canvas.startTests();
    }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
}

class TestCanvas extends Canvas implements Runnable {
    private MIDlet midlet;
    private String[] testNames;
    private String[] results;
    private int passCount = 0;
    private int failCount = 0;
    private boolean testsDone = false;
    private boolean testsRunning = false;
    
    // Current test info
    private int currentTest = -1;
    private String currentStatus = "Starting...";
    
    // Failed tests list
    private String failedTests = "";
    
    // M3G objects
    private Graphics3D g3d;
    private World world;
    private Camera camera;
    private Light light;
    private Mesh cubeMesh;
    private Background background;
    private VertexBuffer vertexBuffer;
    private IndexBuffer indexBuffer;
    private Appearance appearance;
    private Material material;
    
    // Animation
    private int animationAngle = 0;
    private boolean cubeReady = false;
    
    public TestCanvas(MIDlet m) {
        this.midlet = m;
        
        testNames = new String[] {
            "Graphics3D.getInstance",
            "World creation",
            "Background creation",
            "Camera creation",
            "Camera.setPerspective",
            "Light creation",
            "Light.setMode",
            "Transform creation",
            "Transform.setIdentity",
            "Transform.postRotate",
            "VertexBuffer creation",
            "VertexArray positions",
            "VertexArray normals",
            "VertexBuffer.setPos",
            "VertexBuffer.setNorm",
            "TriangleStripArray",
            "Appearance creation",
            "Material creation",
            "Material.setColor",
            "Appearance.setMat",
            "PolygonMode",
            "CompositingMode",
            "Image2D creation",
            "Texture2D creation",
            "Mesh creation",
            "Group creation",
            "Group.addChild",
            "World.addChild",
            "World.setActiveCam",
            "World.setBackground",
            "UserID set/get",
            "bindTarget",
            "setViewport",
            "clear",
            "render(World)",
            "releaseTarget",
            "AnimationController",
            "KeyframeSequence",
            "AnimationTrack",
            "World.animate",
            "setTranslation",
            "setScale",
            "setOrientation"
        };
        results = new String[testNames.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = "?";
        }
    }
    
    public void startTests() {
        if (!testsRunning) {
            testsRunning = true;
            new Thread(this).start();
        }
    }
    
    public void run() {
        runTests();
    }
    
    private void sleepMs(int ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }
    
    private void testPass(int idx) {
        results[idx] = "PASS";
        passCount++;
        currentTest = idx;
        currentStatus = testNames[idx] + ": PASS";
        repaint();
        serviceRepaints();
    }
    
    private void testFail(int idx, String err) {
        results[idx] = "FAIL";
        failCount++;
        currentTest = idx;
        currentStatus = testNames[idx] + ": " + err;
        failedTests += (idx + 1) + "." + testNames[idx] + "\n";
        repaint();
        serviceRepaints();
    }
    
    private void runTests() {
        int i = 0;
        
        // Test 1: Graphics3D.getInstance()
        try { g3d = Graphics3D.getInstance(); if (g3d != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 2: World creation
        try { world = new World(); if (world != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 3: Background creation
        try { background = new Background(); if (background != null) { background.setColor(0x00224466); testPass(i); } else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 4: Camera creation
        try { camera = new Camera(); if (camera != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 5: Camera.setPerspective()
        try { camera.setPerspective(60.0f, (float)getWidth()/(float)getHeight(), 1.0f, 100.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 6: Light creation
        try { light = new Light(); if (light != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 7: Light.setMode
        try { light.setMode(Light.AMBIENT); light.setIntensity(1.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 8: Transform creation
        Transform transform = null;
        try { transform = new Transform(); if (transform != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 9: Transform.setIdentity()
        try { transform.setIdentity(); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 10: Transform.postRotate()
        try { transform.postRotate(45.0f, 0.0f, 1.0f, 0.0f); transform.postTranslate(0.0f, 0.0f, -5.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 11: VertexBuffer creation
        try { vertexBuffer = new VertexBuffer(); if (vertexBuffer != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 12: VertexArray positions
        VertexArray positions = null;
        try {
            short[] posData = {
                -1,-1,1, 1,-1,1, 1,1,1, -1,1,1,
                -1,-1,-1, -1,1,-1, 1,1,-1, 1,-1,-1,
                -1,1,-1, -1,1,1, 1,1,1, 1,1,-1,
                -1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,1,
                1,-1,-1, 1,1,-1, 1,1,1, 1,-1,1,
                -1,-1,-1, -1,-1,1, -1,1,1, -1,1,-1
            };
            positions = new VertexArray(24, 3, 2);
            positions.set(0, 24, posData);
            testPass(i);
        } catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 13: VertexArray normals
        VertexArray normals = null;
        try {
            byte[] normData = {
                0,0,127, 0,0,127, 0,0,127, 0,0,127,
                0,0,-128, 0,0,-128, 0,0,-128, 0,0,-128,
                0,127,0, 0,127,0, 0,127,0, 0,127,0,
                0,-128,0, 0,-128,0, 0,-128,0, 0,-128,0,
                127,0,0, 127,0,0, 127,0,0, 127,0,0,
                -128,0,0, -128,0,0, -128,0,0, -128,0,0
            };
            normals = new VertexArray(24, 3, 1);
            normals.set(0, 24, normData);
            testPass(i);
        } catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 14: VertexBuffer.setPositions()
        try { vertexBuffer.setPositions(positions, 1.0f, null); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 15: VertexBuffer.setNormals()
        try { vertexBuffer.setNormals(normals); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 16: TriangleStripArray
        try {
            int[] stripLengths = {4, 4, 4, 4, 4, 4};
            int[] indices = {0,1,2,3, 4,5,6,7, 8,9,10,11, 12,13,14,15, 16,17,18,19, 20,21,22,23};
            indexBuffer = new TriangleStripArray(indices, stripLengths);
            if (indexBuffer != null) testPass(i); else testFail(i, "null");
        } catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 17: Appearance creation
        try { appearance = new Appearance(); if (appearance != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 18: Material creation
        try { material = new Material(); if (material != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 19: Material.setColor()
        try { material.setColor(Material.DIFFUSE, 0x00FF6600); material.setColor(Material.SPECULAR, 0x00FFFFFF); material.setShininess(32.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 20: Appearance.setMaterial()
        try { appearance.setMaterial(material); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 21: PolygonMode
        try { PolygonMode pm = new PolygonMode(); pm.setCulling(PolygonMode.CULL_BACK); appearance.setPolygonMode(pm); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 22: CompositingMode
        try { CompositingMode cm = new CompositingMode(); appearance.setCompositingMode(cm); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 23: Image2D creation
        Image2D textureImage = null;
        try { textureImage = new Image2D(Image2D.RGB, 16, 16); if (textureImage != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 24: Texture2D creation
        Texture2D texture = null;
        try {
            texture = new Texture2D(textureImage);
            if (texture != null) { texture.setFiltering(Texture2D.FILTER_LINEAR, Texture2D.FILTER_LINEAR); appearance.setTexture(0, texture); testPass(i); }
            else testFail(i, "null");
        } catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 25: Mesh creation
        try { cubeMesh = new Mesh(vertexBuffer, indexBuffer, appearance); if (cubeMesh != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 26: Group creation
        Group group = null;
        try { group = new Group(); if (group != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 27: Group.addChild()
        try { group.addChild(cubeMesh); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 28: World.addChild()
        try { world.addChild(camera); world.addChild(light); world.addChild(cubeMesh); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 29: World.setActiveCamera()
        try { world.setActiveCamera(camera); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 30: World.setBackground()
        try { world.setBackground(background); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 31: UserID set/get
        try { cubeMesh.setUserID(12345); int id = cubeMesh.getUserID(); if (id == 12345) testPass(i); else testFail(i, "id=" + id); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 32: bindTarget
        try { g3d.bindTarget(this); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 33: setViewport
        try { g3d.setViewport(0, 0, getWidth(), getHeight()); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 34: clear
        try { g3d.clear(background); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 35: render(World)
        try { g3d.render(world); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 36: releaseTarget
        try { g3d.releaseTarget(); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 37: AnimationController
        AnimationController animCtrl = null;
        try { animCtrl = new AnimationController(); if (animCtrl != null) testPass(i); else testFail(i, "null"); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 38: KeyframeSequence
        KeyframeSequence keySeq = null;
        try { keySeq = new KeyframeSequence(4, 3, KeyframeSequence.LINEAR); keySeq.setDuration(1000); keySeq.setValidRange(0, 3); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 39: AnimationTrack
        AnimationTrack animTrack = null;
        try { animTrack = new AnimationTrack(keySeq, AnimationTrack.TRANSLATION); animTrack.setController(animCtrl); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 40: World.animate()
        try { world.animate(0); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 41: setTranslation
        try { cubeMesh.setTranslation(0.0f, 0.0f, -5.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 42: setScale
        try { cubeMesh.setScale(1.0f, 1.0f, 1.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // Test 43: setOrientation
        try { cubeMesh.setOrientation(0.0f, 0.0f, 1.0f, 0.0f); testPass(i); }
        catch (Throwable e) { testFail(i, e.getClass().getName()); }
        sleepMs(100); i++;
        
        // All tests done
        testsDone = true;
        cubeReady = true;
        testsRunning = false;
        currentStatus = "DONE: " + passCount + "/" + testNames.length;
        
        // Start animation loop
        new Thread() {
            public void run() {
                while (cubeReady) {
                    animationAngle += 2;
                    if (animationAngle >= 360) animationAngle = 0;
                    repaint();
                    try { Thread.sleep(33); } catch (Exception e) {}
                }
            }
        }.start();
    }
    
    protected void paint(Graphics g) {
        int w = getWidth();
        int h = getHeight();
        
        if (cubeReady && g3d != null && world != null) {
            // Render 3D cube
            try {
                g3d.bindTarget(g);
                g3d.setViewport(0, 0, w, h);
                g3d.clear(background);
                
                // Update cube rotation
                if (cubeMesh != null) {
                    cubeMesh.setOrientation(animationAngle, 1.0f, 1.0f, 0.0f);
                }
                
                g3d.render(world);
                g3d.releaseTarget();
            } catch (Throwable e) {
                // If 3D fails, fall back to 2D
                g.setColor(0x000000);
                g.fillRect(0, 0, w, h);
                g.setColor(0xFF0000);
                g.drawString("3D Error: " + e.getMessage(), w/2, h/2, Graphics.HCENTER | Graphics.VCENTER);
            }
        } else {
            // During tests - show status
            g.setColor(0x000000);
            g.fillRect(0, 0, w, h);
            
            // Title
            g.setColor(0xFFFFFF);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM));
            g.drawString("JSR-184 M3G Test", w/2, 5, Graphics.HCENTER | Graphics.TOP);
            
            // Progress bar
            int progress = (currentTest + 1);
            int total = testNames.length;
            int barWidth = w - 20;
            int barHeight = 20;
            int barX = 10;
            int barY = 30;
            
            g.setColor(0x333333);
            g.fillRect(barX, barY, barWidth, barHeight);
            
            g.setColor(0x00AA00);
            if (total > 0) {
                int fillWidth = (progress * barWidth) / total;
                g.fillRect(barX, barY, fillWidth, barHeight);
            }
            
            g.setColor(0xFFFFFF);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
            g.drawString(progress + "/" + total, w/2, barY + 5, Graphics.HCENTER | Graphics.TOP);
            
            // Current test
            g.setColor(0x00FF00);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_LARGE));
            g.drawString(currentStatus, w/2, barY + barHeight + 10, Graphics.HCENTER | Graphics.TOP);
            
            // Stats
            g.setColor(0xAAAAAA);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
            g.drawString("PASS: " + passCount + "  FAIL: " + failCount, w/2, h - 30, Graphics.HCENTER | Graphics.TOP);
        }
        
        // After tests - overlay results
        if (testsDone) {
            // Draw semi-transparent overlay at bottom
            g.setColor(0x80000000);
            g.fillRect(0, h - 70, w, 70);
            
            // Result summary
            g.setColor(0xFFFFFF);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM));
            g.drawString("JSR-184: " + passCount + "/" + testNames.length + " passed", w/2, h - 65, Graphics.HCENTER | Graphics.TOP);
            
            // Failed tests
            if (failCount > 0) {
                g.setColor(0xFF6666);
                g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
                
                String[] fails = splitFailedTests();
                int y = h - 45;
                for (int i = 0; i < fails.length && i < 2; i++) {
                    g.drawString("FAIL: " + fails[i], w/2, y, Graphics.HCENTER | Graphics.TOP);
                    y += 15;
                }
                if (fails.length > 2) {
                    g.drawString("... and " + (fails.length - 2) + " more", w/2, y, Graphics.HCENTER | Graphics.TOP);
                }
            } else {
                g.setColor(0x00FF00);
                g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_LARGE));
                g.drawString("ALL TESTS PASSED!", w/2, h - 40, Graphics.HCENTER | Graphics.TOP);
            }
        }
    }
    
    private String[] splitFailedTests() {
        if (failedTests.length() == 0) return new String[0];
        int count = 0;
        for (int i = 0; i < failedTests.length(); i++) {
            if (failedTests.charAt(i) == '\n') count++;
        }
        String[] result = new String[count];
        int start = 0;
        int idx = 0;
        for (int i = 0; i < failedTests.length(); i++) {
            if (failedTests.charAt(i) == '\n') {
                result[idx++] = failedTests.substring(start, i);
                start = i + 1;
            }
        }
        return result;
    }
}
