# JSR-184 (M3G) Test MIDlet

Этот мидлет предназначен для тестирования эмуляторов J2ME с поддержкой JSR-184 (Mobile 3D Graphics API).

## Требования

- Устройство или эмулятор с поддержкой **JSR-184/M3G**
- MIDP 2.0, CLDC 1.1

## Структура проекта

```
src/
├── JSR184TestMidlet.java    - исходный код
├── manifest.mf              - манифест
├── JSR184Test.jad           - дескриптор приложения
├── build_jsr184.bat         - скрипт сборки
└── jsr184-stub/             - заглушки JSR-184 для компиляции
lib/
├── cldc_1.1.jar
└── midp_2.0.jar
```

## Список тестов (44 теста)

### Core Tests (5 тестов)
| # | Тест | Описание |
|---|------|----------|
| 1 | Graphics3D.getInstance() | Получение singleton Graphics3D |
| 2 | World creation | Создание World объекта |
| 3 | Background creation | Создание Background |
| 4 | Camera creation | Создание Camera |
| 5 | Camera.setPerspective() | Установка перспективной проекции |

### Light Tests (2 теста)
| # | Тест | Описание |
|---|------|----------|
| 6 | Light creation | Создание источника света |
| 7 | Light.setMode(AMBIENT) | Установка режима освещения |

### Transform Tests (3 теста)
| # | Тест | Описание |
|---|------|----------|
| 8 | Transform creation | Создание Transform |
| 9 | Transform.setIdentity() | Сброс матрицы |
| 10 | Transform.postRotate() | Поворот и трансляция |

### VertexBuffer Tests (5 тестов)
| # | Тест | Описание |
|---|------|----------|
| 11 | VertexBuffer creation | Создание буфера вершин |
| 12 | VertexArray positions | Позиции вершин куба (24 вершины) |
| 13 | VertexArray normals | Нормали для освещения |
| 14 | VertexBuffer.setPositions() | Установка позиций |
| 15 | VertexBuffer.setNormals() | Установка нормалей |

### IndexBuffer Tests (1 тест)
| # | Тест | Описание |
|---|------|----------|
| 16 | TriangleStripArray creation | Создание индексного буфера |

### Appearance Tests (6 тестов)
| # | Тест | Описание |
|---|------|----------|
| 17 | Appearance creation | Создание Appearance |
| 18 | Material creation | Создание материала |
| 19 | Material.setColor() | Установка цветов материала |
| 20 | Appearance.setMaterial() | Привязка материала |
| 21 | PolygonMode creation | Режим полигона |
| 22 | CompositingMode creation | Режим композитинга |

### Texture Tests (2 теста)
| # | Тест | Описание |
|---|------|----------|
| 23 | Image2D creation | Создание изображения 16x16 |
| 24 | Texture2D creation | Создание и настройка текстуры |

### Mesh Tests (1 тест)
| # | Тест | Описание |
|---|------|----------|
| 25 | Mesh creation | Создание меша из буферов |

### Group Tests (2 теста)
| # | Тест | Описание |
|---|------|----------|
| 26 | Group creation | Создание группы |
| 27 | Group.addChild() | Добавление дочернего узла |

### World Tests (3 теста)
| # | Тест | Описание |
|---|------|----------|
| 28 | World.addChild() | Добавление объектов в сцену |
| 29 | World.setActiveCamera() | Установка активной камеры |
| 30 | World.setBackground() | Установка фона |

### Object3D Tests (2 теста)
| # | Тест | Описание |
|---|------|----------|
| 31 | Object3D.setUserID() | Установка ID |
| 32 | Object3D.getUserID() | Получение ID |

### Rendering Tests (5 тестов)
| # | Тест | Описание |
|---|------|----------|
| 33 | Graphics3D.bindTarget() | Привязка Canvas |
| 34 | Graphics3D.setViewport() | Установка viewport |
| 35 | Graphics3D.clear() | Очистка буфера |
| 36 | render(World) | Рендеринг сцены |
| 37 | Graphics3D.releaseTarget() | Освобождение цели |

### Animation Tests (4 теста)
| # | Тест | Описание |
|---|------|----------|
| 38 | AnimationController creation | Создание контроллера |
| 39 | KeyframeSequence creation | Создание ключевых кадров |
| 40 | AnimationTrack creation | Создание трека анимации |
| 41 | World.animate() | Запуск анимации |

### Transformable Tests (3 теста)
| # | Тест | Описание |
|---|------|----------|
| 42 | Transformable.setTranslation() | Установка позиции |
| 43 | Transformable.setScale() | Установка масштаба |
| 44 | Transformable.setOrientation() | Установка ориентации |

## Особенности

### Рисование кубика
Мидлет создаёт полноценный 3D куб:
- VertexBuffer с 24 вершинами (4 на грань × 6 граней)
- Нормали для освещения
- TriangleStripArray для индексации
- Material с освещением
- Camera с перспективной проекцией
- Ambient Light

### Оптимизация для стабильности
- Увеличенные задержки между тестами (200ms)
- Синхронизированные методы обновления UI
- Проверка на null для всех созданных объектов
- Обработка Throwable вместо Exception

## Сборка

```batch
cd src
build_jsr184.bat
```

Требования для сборки:
- JDK 1.8 или выше
- CLDC 1.1 и MIDP 2.0 библиотеки в lib/

## Запуск

1. Убедитесь, что эмулятор поддерживает JSR-184
2. Загрузите JAR/JAD файлы
3. Запустите приложение

### Проверенные эмуляторы
- KEmulator (с плагином M3G)
- J2ME Wireless Toolkit 2.5.x
- Java ME SDK 3.x
- Sony Ericsson SDK
- Nokia SDK

## Результаты тестов

После завершения отображается:
- Количество пройденных тестов (PASS)
- Количество проваленных тестов (FAIL/ERR)
- Общий результат

Ожидаемый результат: **44/44 PASS** на эмуляторе с полной поддержкой JSR-184.

## Устранение неполадок

### Эмулятор зависает
- Увеличьте задержки между тестами (параметр sleep())
- Проверьте версию JSR-184 в эмуляторе
- Попробуйте уменьшить размер текстуры

### Ошибки ERR
- Проверьте поддержку конкретного метода в документации эмулятора
- Некоторые методы могут быть не реализованы
