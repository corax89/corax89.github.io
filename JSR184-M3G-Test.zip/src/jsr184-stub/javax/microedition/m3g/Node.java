package javax.microedition.m3g;

public class Node extends Transformable {
    public static final int NONE = 0;
    public boolean getTransformTo(Node target, Transform transform) { return false; }
    public boolean isPickingEnabled() { return true; }
    public void setPickingEnable(boolean enable) {}
    public boolean isRenderingEnabled() { return true; }
    public void setRenderingEnable(boolean enable) {}
    public int getScope() { return -1; }
    public void setScope(int scope) {}
    public void setAlignment(Node zRef, int zTarget, Node yRef, int yTarget) {}
    public void align() {}
}
