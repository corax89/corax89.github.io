package javax.microedition.m3g;

public class Image2D extends Object3D {
    public static final int RGB = 96;
    public static final int RGBA = 97;
    public static final int ALPHA = 98;
    public static final int LUMINANCE = 99;
    public static final int LUMINANCE_ALPHA = 100;
    private int format;
    private int width;
    private int height;
    public Image2D(int format, int width, int height) {
        this.format = format;
        this.width = width;
        this.height = height;
    }
    public Image2D(int format, Object image) {
        this.format = format;
        this.width = 16;
        this.height = 16;
    }
    public int getFormat() { return format; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public void set(int x, int y, int width, int height, byte[] image) {}
    public boolean isMutable() { return false; }
}
