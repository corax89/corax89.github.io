/*
 * J2ME Emulator - Heap and Garbage Collector
 * Memory management for Java objects
 */

#ifndef HEAP_H
#define HEAP_H

#include "jvm.h"

/*
 * Object types for GC
 */
typedef enum {
    OBJ_TYPE_OBJECT,
    OBJ_TYPE_ARRAY,
    OBJ_TYPE_STRING,
    OBJ_TYPE_CLASS
} ObjectType;

/*
 * Object header for GC tracking
 */
typedef struct GCObjectHeader {
    struct GCObjectHeader* next;    /* Next object in heap */
    JavaClass* clazz;               /* Object's class */
    uint32_t size;                  /* Object size including header */
    uint8_t type;                   /* Object type */
    uint8_t marked;                 /* GC mark flag */
    uint8_t pinned;                 /* Cannot be moved */
    uint8_t reserved;
} GCObjectHeader;

/*
 * Heap statistics
 */
typedef struct {
    size_t total_size;
    size_t used_size;
    size_t free_size;
    size_t object_count;
    size_t gc_cycles;
    size_t gc_time_ms;
} HeapStats;

/*
 * Heap initialization
 */
int heap_init(JVM* jvm, size_t initial_size, size_t max_size);
void heap_destroy(JVM* jvm);

/*
 * Object allocation
 */
void* heap_alloc(JVM* jvm, size_t size, JavaClass* clazz, ObjectType type);

/* Allocate object */
JavaObject* heap_alloc_object(JVM* jvm, JavaClass* clazz);

/* Allocate array */
JavaArray* heap_alloc_array(JVM* jvm, uint8_t element_type, jsize length);

/* Allocate string */
JavaString* heap_alloc_string(JVM* jvm, jsize length);

/*
 * Garbage Collection
 */

/* Run garbage collection */
void gc_collect(JVM* jvm);

/* Add GC root */
void gc_add_root(JVM* jvm, void** root);

/* Remove GC root */
void gc_remove_root(JVM* jvm, void** root);

/* Pin object (prevent GC from moving it) */
void gc_pin(JVM* jvm, void* object);

/* Unpin object */
void gc_unpin(JVM* jvm, void* object);

/* Get heap statistics */
HeapStats heap_get_stats(JVM* jvm);

/*
 * Object operations
 */

/* Get object class */
JavaClass* object_get_class(void* object);

/* Get object size */
size_t object_get_size(void* object);

/* Get object hash code */
jint object_hash_code(void* object);

/* Check if object is an array */
bool object_is_array(void* object);

/* Check if object is a string */
bool object_is_string(void* object);

/* Check if object is instance of class */
bool object_instance_of(void* object, JavaClass* clazz);

/*
 * Array operations
 */

/* Get array length */
jsize array_length(JavaArray* array);

/* Get array element type */
uint8_t array_element_type(JavaArray* array);

/* Get array element */
JavaValue array_get(JavaArray* array, jsize index);

/* Set array element */
void array_set(JavaArray* array, jsize index, JavaValue value);

/* Get reference from object array */
void* array_get_ref(JavaArray* array, jsize index);

/* Set reference in object array */
void array_set_ref(JavaArray* array, jsize index, void* ref);

/*
 * String operations
 */

/* Get string length */
jsize string_length(JavaString* str);

/* Get string characters (UTF-16) */
const jchar* string_chars(JavaString* str);

/* Get string as UTF-8 */
const char* string_utf8(JVM* jvm, JavaString* str);

/* Compare strings */
bool string_equals(JavaString* a, JavaString* b);

/* String hash code */
jint string_hash(JavaString* str);

/*
 * Memory debugging
 */
void heap_dump(JVM* jvm);
void heap_validate(JVM* jvm);

#endif /* HEAP_H */
