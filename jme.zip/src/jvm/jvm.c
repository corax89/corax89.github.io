/*
 * J2ME Emulator - JVM Core Implementation
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup - only on POSIX systems */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#include "jvm.h"
#include "classfile.h"
#include "heap.h"
#include "threads.h"
#include "opcodes.h"
#include "native.h"

/* Helper functions for JAR reading */
static uint16_t read_u16_jar(const uint8_t* p) {
    return p[0] | (p[1] << 8);
}

static uint32_t read_u32_jar(const uint8_t* p) {
    return p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
}

/* Find file in JAR by name - uses Central Directory for reliable reading */
static uint8_t* jar_find_file_internal(const uint8_t* jar_data, size_t jar_size, 
                                       const char* filename, size_t* out_size) {
    *out_size = 0;
    
    /* Find End of Central Directory record */
    size_t eocd_offset = 0;
    for (size_t i = jar_size - 22; i > 0; i--) {
        if (jar_data[i] == 0x50 && jar_data[i+1] == 0x4B &&
            jar_data[i+2] == 0x05 && jar_data[i+3] == 0x06) {
            eocd_offset = i;
            break;
        }
    }
    
    if (eocd_offset == 0) {
        return NULL;
    }
    
    /* Get Central Directory start offset */
    uint32_t cd_start = read_u32_jar(jar_data + eocd_offset + 16);
    uint16_t cd_entries = read_u16_jar(jar_data + eocd_offset + 10);
    
    /* Scan Central Directory entries */
    size_t cde_offset = cd_start;
    for (int i = 0; i < cd_entries && cde_offset < eocd_offset; i++) {
        uint32_t cd_sig = read_u32_jar(jar_data + cde_offset);
        if (cd_sig != 0x02014B50) break;
        
        uint16_t cd_filename_len = read_u16_jar(jar_data + cde_offset + 28);
        uint16_t cd_extra_len = read_u16_jar(jar_data + cde_offset + 30);
        uint16_t cd_comment_len = read_u16_jar(jar_data + cde_offset + 32);
        uint32_t cd_comp_size = read_u32_jar(jar_data + cde_offset + 20);
        uint32_t cd_uncomp_size = read_u32_jar(jar_data + cde_offset + 24);
        uint16_t compression = read_u16_jar(jar_data + cde_offset + 10);
        uint32_t local_header_offset = read_u32_jar(jar_data + cde_offset + 42);
        
        const char* entry_name = (const char*)(jar_data + cde_offset + 46);
        bool is_dir = (cd_filename_len > 0 && entry_name[cd_filename_len - 1] == '/');
        
        if (!is_dir && cd_filename_len == strlen(filename) &&
            memcmp(entry_name, filename, cd_filename_len) == 0) {
            
            /* Calculate data offset from local header */
            size_t local_offset = local_header_offset;
            uint16_t local_filename_len = read_u16_jar(jar_data + local_offset + 26);
            uint16_t local_extra_len = read_u16_jar(jar_data + local_offset + 28);
            size_t data_offset = local_offset + 30 + local_filename_len + local_extra_len;
            
            if (compression == 0) {
                /* Stored (uncompressed) */
                *out_size = cd_uncomp_size;
                uint8_t* data = (uint8_t*)malloc(*out_size + 1);
                if (data) {
                    memcpy(data, jar_data + data_offset, *out_size);
                    data[*out_size] = '\0';
                }
                return data;
            } else if (compression == 8) {
                /* Deflate compressed */
                if (cd_comp_size == 0 || cd_uncomp_size == 0) {
                    return NULL;
                }
                
                uint8_t* data = (uint8_t*)malloc(cd_uncomp_size + 1);
                if (!data) return NULL;
                
                z_stream stream;
                memset(&stream, 0, sizeof(stream));
                
                int ret = inflateInit2(&stream, -MAX_WBITS);
                if (ret != Z_OK) {
                    free(data);
                    return NULL;
                }
                
                stream.next_in = (Bytef*)(jar_data + data_offset);
                stream.avail_in = cd_comp_size;
                stream.next_out = data;
                stream.avail_out = cd_uncomp_size;
                
                ret = inflate(&stream, Z_FINISH);
                inflateEnd(&stream);
                
                if (ret != Z_STREAM_END) {
                    free(data);
                    return NULL;
                }
                
                data[cd_uncomp_size] = '\0';
                *out_size = cd_uncomp_size;
                return data;
            }
        }
        
        cde_offset += 46 + cd_filename_len + cd_extra_len + cd_comment_len;
    }
    
    return NULL;
}

/* Load class from JAR */
JavaClass* jvm_load_class_from_jar(JVM* jvm, const char* class_name) {
    if (!jvm || !class_name) return NULL;
    if (!jvm->class_loader.jar_data || jvm->class_loader.jar_size == 0) return NULL;
    
    /* Build filename */
    char filename[512];
    snprintf(filename, sizeof(filename), "%s.class", class_name);
    
    size_t class_size;
    uint8_t* class_data = jar_find_file_internal(jvm->class_loader.jar_data, 
                                                   jvm->class_loader.jar_size, 
                                                   filename, &class_size);
    if (!class_data) return NULL;
    
    JavaClass* clazz = classfile_parse(jvm, class_data, class_size);
    free(class_data);
    
    if (!clazz) return NULL;
    
    /* Resolve super_class reference */
    if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
        fprintf(stderr, "[JVM] Resolving super_class %s for %s\n", 
                clazz->super_class_name, clazz->class_name);
        fflush(stderr);
        /* Try to load super class */
        JavaClass* super = jvm_load_class(jvm, clazz->super_class_name);
        if (super) {
            clazz->super_class = super;
            fprintf(stderr, "[JVM] Resolved super_class: %s -> %s\n", 
                    clazz->class_name, super->class_name);
            fflush(stderr);
        } else {
            fprintf(stderr, "[JVM] Failed to resolve super_class %s for %s\n",
                    clazz->super_class_name, clazz->class_name);
            fflush(stderr);
        }
    }
    
    /* Add to loaded classes */
    if (jvm->class_loader.count >= jvm->class_loader.capacity) {
        jvm->class_loader.capacity *= 2;
        jvm->class_loader.classes = (JavaClass**)realloc(
            jvm->class_loader.classes, 
            jvm->class_loader.capacity * sizeof(JavaClass*)
        );
    }
    
    jvm->class_loader.classes[jvm->class_loader.count++] = clazz;
    
    if (jvm->config.verbose_class) {
        printf("[Loaded class from JAR: %s (super: %s)]\n", class_name, 
               clazz->super_class ? clazz->super_class->class_name : 
               (clazz->super_class_name ? clazz->super_class_name : "(none)"));
    }
    
    /* Log all methods for Canvas subclasses to help debug */
    if (clazz->class_name && strstr(clazz->class_name, "Canvas") != NULL) {
        fprintf(stderr, "\n[Canvas] Class %s methods (%d total):\n", 
                clazz->class_name, clazz->methods_count);
        for (int i = 0; i < clazz->methods_count; i++) {
            JavaMethod* m = &clazz->methods[i];
            fprintf(stderr, "  [%d] %s%s (code: %u bytes, native: %s)\n",
                    i, m->name, m->descriptor, m->code.code_length,
                    m->is_native ? "yes" : "no");
        }
        fprintf(stderr, "[Canvas] Fields (%d total):\n", clazz->fields_count);
        for (int i = 0; i < clazz->fields_count; i++) {
            JavaField* f = &clazz->fields[i];
            fprintf(stderr, "  [%d] %s %s\n", i, f->descriptor, f->name);
        }
        fflush(stderr);
    }
    
    return clazz;
}

/* Create JVM instance */
JVM* jvm_create(void) {
    JVM* jvm = (JVM*)calloc(1, sizeof(JVM));
    if (!jvm) return NULL;
    
    /* Set default configuration */
    jvm->config.heap_size = HEAP_INITIAL_SIZE;
    jvm->config.stack_size = JAVA_STACK_SIZE;
    jvm->config.max_threads = MAX_JAVA_THREADS;
    
    return jvm;
}

/* Destroy JVM instance */
void jvm_destroy(JVM* jvm) {
    if (!jvm) return;
    
    jvm->running = false;
    
    /* Destroy all threads */
    for (int i = 0; i < jvm->thread_count; i++) {
        if (jvm->threads[i]) {
            thread_destroy(jvm, jvm->threads[i]);
        }
    }
    
    /* Free class loader */
    if (jvm->class_loader.classes) {
        for (size_t i = 0; i < jvm->class_loader.count; i++) {
            JavaClass* clazz = jvm->class_loader.classes[i];
            if (!clazz) continue;
            
            /* For stub classes, free only what was allocated */
            if (clazz->is_stub) {
                /* Free class_name and super_class_name allocated by strdup */
                free((void*)clazz->class_name);
                free((void*)clazz->super_class_name);
                
                /* Free constant pool UTF8 entries */
                if (clazz->constant_pool) {
                    for (uint16_t j = 1; j < clazz->constant_pool_count; j++) {
                        if (clazz->constant_pool[j].tag == CONSTANT_Utf8) {
                            free(clazz->constant_pool[j].info.utf8.bytes);
                        }
                    }
                    free(clazz->constant_pool);
                }
                
                /* Free methods - stub methods have allocated name/descriptor */
                if (clazz->methods) {
                    for (uint16_t j = 0; j < clazz->methods_count; j++) {
                        free((void*)clazz->methods[j].name);
                        free((void*)clazz->methods[j].descriptor);
                        free(clazz->methods[j].code.code);
                    }
                    free(clazz->methods);
                }
                
                /* Free fields */
                if (clazz->fields) {
                    for (uint16_t j = 0; j < clazz->fields_count; j++) {
                        free((void*)clazz->fields[j].name);
                        free((void*)clazz->fields[j].descriptor);
                    }
                    free(clazz->fields);
                }
                
                free(clazz);
            } else {
                /* Use regular classfile_free for non-stub classes */
                classfile_free(clazz);
            }
        }
        free(jvm->class_loader.classes);
    }
    
    if (jvm->class_loader.class_path) {
        for (size_t i = 0; i < jvm->class_loader.class_path_count; i++) {
            free(jvm->class_loader.class_path[i]);
        }
        free(jvm->class_loader.class_path);
    }
    
    /* Free jar_path if allocated */
    free((void*)jvm->class_loader.jar_path);
    
    /* Free string pool - only free utf8 as chars is part of heap allocation */
    if (jvm->string_pool.strings) {
        for (size_t i = 0; i < jvm->string_pool.count; i++) {
            JavaString* str = jvm->string_pool.strings[i];
            if (str) {
                /* utf8 is allocated separately with strdup */
                free(str->utf8);
                /* chars is part of the heap allocation, don't free separately */
                /* The whole JavaString struct is freed by heap_destroy */
            }
        }
        free(jvm->string_pool.strings);
    }
    
    /* Destroy heap - this frees all objects including JavaString structs */
    heap_destroy(jvm);
    
    free(jvm);
}

/* Initialize JVM */
int jvm_init(JVM* jvm) {
    if (!jvm) return JNI_ERR;
    
    /* Initialize heap */
    if (heap_init(jvm, jvm->config.heap_size, HEAP_MAX_SIZE) != JNI_OK) {
        fprintf(stderr, "Failed to initialize heap\n");
        return JNI_ERR;
    }
    
    /* Initialize thread system */
    if (threads_init(jvm) != JNI_OK) {
        fprintf(stderr, "Failed to initialize threads\n");
        return JNI_ERR;
    }
    
    /* Create main thread */
    jvm->main_thread = thread_create(jvm, "main", THREAD_PRIORITY_NORM, NULL);
    if (!jvm->main_thread) {
        fprintf(stderr, "Failed to create main thread\n");
        return JNI_ERR;
    }
    
    jvm->threads[0] = jvm->main_thread;
    jvm->thread_count = 1;
    
    /* Initialize class loader */
    jvm->class_loader.capacity = 256;
    jvm->class_loader.classes = (JavaClass**)calloc(jvm->class_loader.capacity, sizeof(JavaClass*));
    if (!jvm->class_loader.classes) {
        return JNI_ERR;
    }
    
    /* Initialize string pool */
    jvm->string_pool.capacity = 256;
    jvm->string_pool.strings = (JavaString**)calloc(jvm->string_pool.capacity, sizeof(JavaString*));
    if (!jvm->string_pool.strings) {
        return JNI_ERR;
    }
    
    /* Initialize built-in stub classes for J2ME API */
    int stub_count = init_stub_classes(jvm);
    if (jvm->config.verbose_class) {
        printf("[JVM] Initialized %d stub classes\n", stub_count);
    }
    
    jvm->running = true;
    
    return JNI_OK;
}

/* Set JAR data for class loading */
void jvm_set_jar_data(JVM* jvm, uint8_t* data, size_t size, const char* path) {
    if (!jvm) return;
    jvm->class_loader.jar_data = data;
    jvm->class_loader.jar_size = size;
    jvm->class_loader.jar_path = path ? strdup(path) : NULL;
}

/* Load a class by name */
JavaClass* jvm_load_class(JVM* jvm, const char* class_name) {
    if (!jvm || !class_name) return NULL;
    
    /* Check if already loaded */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->class_name && strcmp(clazz->class_name, class_name) == 0) {
            /* Resolve super_class if not already done */
            if (clazz->super_class == NULL && clazz->super_class_name != NULL) {
                clazz->super_class = jvm_load_class(jvm, clazz->super_class_name);
            }
            return clazz;
        }
    }
    
    /* Try to load from JAR first if JAR data is available */
    if (jvm->class_loader.jar_data && jvm->class_loader.jar_size > 0) {
        JavaClass* clazz = jvm_load_class_from_jar(jvm, class_name);
        if (clazz) return clazz;
    }
    
    /* Convert class name to path */
    char* path = class_name_to_internal(class_name);
    if (!path) return NULL;
    
    /* Try to load from classpath */
    char filename[1024];
    JavaClass* clazz = NULL;
    
    for (size_t i = 0; i < jvm->class_loader.class_path_count; i++) {
        snprintf(filename, sizeof(filename), "%s/%s.class", 
                 jvm->class_loader.class_path[i], path);
        
        clazz = classfile_parse_file(jvm, filename);
        if (clazz) break;
    }
    
    /* If not found, try current directory */
    if (!clazz) {
        snprintf(filename, sizeof(filename), "%s.class", path);
        clazz = classfile_parse_file(jvm, filename);
    }
    
    free(path);
    
    if (!clazz) {
        /* Class not found in filesystem - create or get a stub class */
        clazz = get_or_create_stub_class(jvm, class_name);
        if (!clazz) {
            if (jvm->config.verbose_class) {
                fprintf(stderr, "Class not found and stub creation failed: %s\n", class_name);
            }
            return NULL;
        }
        return clazz;  /* Stub already added to class loader */
    }
    
    /* Add to loaded classes */
    if (jvm->class_loader.count >= jvm->class_loader.capacity) {
        jvm->class_loader.capacity *= 2;
        jvm->class_loader.classes = (JavaClass**)realloc(
            jvm->class_loader.classes, 
            jvm->class_loader.capacity * sizeof(JavaClass*)
        );
    }
    
    jvm->class_loader.classes[jvm->class_loader.count++] = clazz;
    
    if (jvm->config.verbose_class) {
        printf("[Loaded class: %s]\n", class_name);
    }
    
    return clazz;
}

/* Define a class from raw bytes */
JavaClass* jvm_define_class(JVM* jvm, const uint8_t* data, size_t length) {
    if (!jvm || !data || length == 0) return NULL;
    
    JavaClass* clazz = classfile_parse(jvm, data, length);
    if (!clazz) return NULL;
    
    /* Resolve class name */
    if (clazz->this_class > 0) {
        clazz->class_name = (char*)classfile_get_class_name(clazz, clazz->this_class);
    }
    
    /* Add to loaded classes */
    if (jvm->class_loader.count >= jvm->class_loader.capacity) {
        jvm->class_loader.capacity *= 2;
        jvm->class_loader.classes = (JavaClass**)realloc(
            jvm->class_loader.classes, 
            jvm->class_loader.capacity * sizeof(JavaClass*)
        );
    }
    
    jvm->class_loader.classes[jvm->class_loader.count++] = clazz;
    
    return clazz;
}

/* Resolve a method in a class */
JavaMethod* jvm_resolve_method(JVM* jvm, JavaClass* clazz, const char* name, const char* descriptor) {
    if (!clazz || !name || !descriptor) return NULL;
    
    /* Check method cache */
    for (int i = 0; i < 64; i++) {
        if (clazz->method_cache[i]) {
            JavaMethod* m = clazz->method_cache[i];
            if (strcmp(m->name, name) == 0 && strcmp(m->descriptor, descriptor) == 0) {
                return m;
            }
        }
    }
    
    /* Search in class methods */
    for (int i = 0; i < clazz->methods_count; i++) {
        JavaMethod* method = &clazz->methods[i];
        if (method->name && method->descriptor &&
            strcmp(method->name, name) == 0 && 
            strcmp(method->descriptor, descriptor) == 0) {
            
            /* Cache the method */
            int slot = clazz->methods_count % 64;
            clazz->method_cache[slot] = method;
            
            return method;
        }
    }
    
    /* Search in superclass */
    if (clazz->super_class) {
        return jvm_resolve_method(jvm, clazz->super_class, name, descriptor);
    }
    
    return NULL;
}

/* Resolve a field in a class */
JavaField* jvm_resolve_field(JVM* jvm, JavaClass* clazz, const char* name, const char* descriptor) {
    if (!clazz || !name || !descriptor) return NULL;
    
    /* Search in class fields */
    for (int i = 0; i < clazz->fields_count; i++) {
        JavaField* field = &clazz->fields[i];
        if (field->name && field->descriptor &&
            strcmp(field->name, name) == 0 &&
            strcmp(field->descriptor, descriptor) == 0) {
            return field;
        }
    }
    
    /* Search in superclass */
    if (clazz->super_class) {
        return jvm_resolve_field(jvm, clazz->super_class, name, descriptor);
    }
    
    return NULL;
}

/* Create new object */
JavaObject* jvm_new_object(JVM* jvm, JavaClass* clazz) {
    if (!jvm || !clazz) return NULL;
    
    /* Initialize class if needed */
    if (!clazz->initialized) {
        /* TODO: Call <clinit> */
        clazz->initialized = true;
    }
    
    if (jvm->config.verbose_class) {
        printf("[JVM] Creating object of class: %s\n", clazz->class_name);
    }
    
    return heap_alloc_object(jvm, clazz);
}

/* Create new array */
JavaArray* jvm_new_array(JVM* jvm, uint8_t type, jsize length) {
    return heap_alloc_array(jvm, type, length);
}

/* Create new string */
JavaString* jvm_new_string(JVM* jvm, const char* utf8) {
    if (!jvm || !utf8) return NULL;
    
    size_t len = strlen(utf8);
    
    /* Convert UTF-8 to UTF-16 */
    jchar* chars = (jchar*)malloc(len * sizeof(jchar));
    if (!chars) return NULL;
    
    /* Simple ASCII to UTF-16 conversion */
    for (size_t i = 0; i < len; i++) {
        chars[i] = (jchar)(uint8_t)utf8[i];
    }
    
    JavaString* str = jvm_new_string_utf16(jvm, chars, (jsize)len);
    free(chars);
    
    if (str) {
        str->utf8 = strdup(utf8);
    }
    
    return str;
}

/* Create new string from UTF-16 */
JavaString* jvm_new_string_utf16(JVM* jvm, const jchar* chars, jsize length) {
    if (!jvm || !chars || length < 0) return NULL;
    
    JavaString* str = heap_alloc_string(jvm, length);
    if (!str) return NULL;
    
    memcpy(str->chars, chars, length * sizeof(jchar));
    str->length = length;
    
    return str;
}

/* Throw an exception */
void jvm_throw(JVM* jvm, JavaObject* exception) {
    if (!jvm || !exception) return;
    
    JavaThread* thread = jvm_current_thread(jvm);
    if (thread) {
        thread->pending_exception = exception;
    }
}

/* Throw exception by class name */
void jvm_throw_by_name(JVM* jvm, const char* class_name, const char* message) {
    if (!jvm || !class_name) return;
    
    JavaClass* clazz = jvm_load_class(jvm, class_name);
    if (!clazz) {
        fprintf(stderr, "Exception class not found: %s\n", class_name);
        return;
    }
    
    JavaObject* exception = jvm_new_object(jvm, clazz);
    if (!exception) return;
    
    /* TODO: Set message field */
    (void)message;
    
    jvm_throw(jvm, exception);
}

/* Check for pending exception */
JavaObject* jvm_exception_pending(JVM* jvm) {
    JavaThread* thread = jvm_current_thread(jvm);
    return thread ? thread->pending_exception : NULL;
}

/* Clear pending exception */
JavaObject* jvm_exception_clear(JVM* jvm) {
    JavaThread* thread = jvm_current_thread(jvm);
    if (!thread) return NULL;
    
    JavaObject* ex = thread->pending_exception;
    thread->pending_exception = NULL;
    return ex;
}

/* Get current thread */
JavaThread* jvm_current_thread(JVM* jvm) {
    if (!jvm) return NULL;
    return jvm->main_thread;  /* Simplified - TODO: TLS */
}

/* Allocate memory */
void* jvm_alloc(JVM* jvm, size_t size) {
    return heap_alloc(jvm, size, NULL, OBJ_TYPE_OBJECT);
}

/* Run garbage collection */
void jvm_gc(JVM* jvm) {
    gc_collect(jvm);
}

/* Add GC root */
void jvm_add_root(JVM* jvm, JavaObject* obj) {
    gc_add_root(jvm, (void**)&obj);
}

/* Remove GC root */
void jvm_remove_root(JVM* jvm, JavaObject* obj) {
    gc_remove_root(jvm, (void**)&obj);
}

/* Convert string to UTF-8 */
char* jvm_string_to_utf8(JVM* jvm, JavaString* str) {
    (void)jvm;
    if (!str) return NULL;
    
    if (str->utf8) return strdup(str->utf8);
    
    /* Convert UTF-16 to UTF-8 */
    char* result = (char*)malloc(str->length + 1);
    if (!result) return NULL;
    
    for (jsize i = 0; i < str->length; i++) {
        result[i] = (char)(str->chars[i] & 0xFF);
    }
    result[str->length] = '\0';
    
    return result;
}

/* Utility functions */
uint16_t jvm_read_u16(const uint8_t* data) {
    return ((uint16_t)data[0] << 8) | data[1];
}

uint32_t jvm_read_u32(const uint8_t* data) {
    return ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
           ((uint32_t)data[2] << 8) | data[3];
}

uint64_t jvm_read_u64(const uint8_t* data) {
    return ((uint64_t)data[0] << 56) | ((uint64_t)data[1] << 48) |
           ((uint64_t)data[2] << 40) | ((uint64_t)data[3] << 32) |
           ((uint64_t)data[4] << 24) | ((uint64_t)data[5] << 16) |
           ((uint64_t)data[6] << 8) | data[7];
}

int16_t jvm_read_s16(const uint8_t* data) {
    return (int16_t)jvm_read_u16(data);
}

int32_t jvm_read_s32(const uint8_t* data) {
    return (int32_t)jvm_read_u32(data);
}

int64_t jvm_read_s64(const uint8_t* data) {
    return (int64_t)jvm_read_u64(data);
}

/* Class name conversion */
char* class_name_to_java(const char* internal_name) {
    if (!internal_name) return NULL;
    
    size_t len = strlen(internal_name);
    char* result = (char*)malloc(len + 1);
    if (!result) return NULL;
    
    for (size_t i = 0; i < len; i++) {
        result[i] = (internal_name[i] == '/') ? '.' : internal_name[i];
    }
    result[len] = '\0';
    
    return result;
}

char* class_name_to_internal(const char* java_name) {
    if (!java_name) return NULL;
    
    size_t len = strlen(java_name);
    char* result = (char*)malloc(len + 1);
    if (!result) return NULL;
    
    for (size_t i = 0; i < len; i++) {
        result[i] = (java_name[i] == '.') ? '/' : java_name[i];
    }
    result[len] = '\0';
    
    return result;
}
