/*
 * J2ME Emulator - Bytecode Opcode Handlers
 * Implementation of all Java bytecode instructions
 * 
 * FIXED: Added proper bounds checking and error handling to prevent crashes
 */

/* For strdup on POSIX */
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* For Windows strdup compatibility */
#ifdef _WIN32
#ifndef strdup
#define strdup _strdup
#endif
#endif

#include "opcodes.h"
#include "jvm.h"
#include "classfile.h"
#include "heap.h"
#include "native.h"
#include "threads.h"  /* For monitor_enter/exit */

/* External function from native.c */
extern int count_args(const char* descriptor);

/* External function from execute.c */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, 
                          JavaValue* args, JavaValue* result);

/* Forward declarations for long/double specific opcodes */
int op_lload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_lstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame);
int op_dstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame);

/* Global error flag for stack underflow */
static __thread int stack_error = 0;

/* Opcode information table */
const OpcodeInfo opcode_table[256] = {
    [OPC_NOP]           = {"nop", 0, 0, op_nop},
    [OPC_ACONST_NULL]   = {"aconst_null", 0, 1, op_aconst_null},
    [OPC_ICONST_M1]     = {"iconst_m1", 0, 1, op_iconst},
    [OPC_ICONST_0]      = {"iconst_0", 0, 1, op_iconst},
    [OPC_ICONST_1]      = {"iconst_1", 0, 1, op_iconst},
    [OPC_ICONST_2]      = {"iconst_2", 0, 1, op_iconst},
    [OPC_ICONST_3]      = {"iconst_3", 0, 1, op_iconst},
    [OPC_ICONST_4]      = {"iconst_4", 0, 1, op_iconst},
    [OPC_ICONST_5]      = {"iconst_5", 0, 1, op_iconst},
    [OPC_LCONST_0]      = {"lconst_0", 0, 2, op_lconst},
    [OPC_LCONST_1]      = {"lconst_1", 0, 2, op_lconst},
    [OPC_FCONST_0]      = {"fconst_0", 0, 1, op_fconst},
    [OPC_FCONST_1]      = {"fconst_1", 0, 1, op_fconst},
    [OPC_FCONST_2]      = {"fconst_2", 0, 1, op_fconst},
    [OPC_DCONST_0]      = {"dconst_0", 0, 2, op_dconst},
    [OPC_DCONST_1]      = {"dconst_1", 0, 2, op_dconst},
    [OPC_BIPUSH]        = {"bipush", 1, 1, op_bipush},
    [OPC_SIPUSH]        = {"sipush", 2, 1, op_sipush},
    [OPC_LDC]           = {"ldc", 1, 1, op_ldc},
    [OPC_LDC_W]         = {"ldc_w", 2, 1, op_ldc_w},
    [OPC_LDC2_W]        = {"ldc2_w", 2, 2, op_ldc2_w},
    
    /* Load instructions */
    [OPC_ILOAD]         = {"iload", 1, 1, op_iload},
    [OPC_LLOAD]         = {"lload", 1, 2, op_lload},
    [OPC_FLOAD]         = {"fload", 1, 1, op_fload},
    [OPC_DLOAD]         = {"dload", 1, 2, op_dload},
    [OPC_ALOAD]         = {"aload", 1, 1, op_aload},
    [OPC_ILOAD_0]       = {"iload_0", 0, 1, op_load_0},
    [OPC_ILOAD_1]       = {"iload_1", 0, 1, op_load_1},
    [OPC_ILOAD_2]       = {"iload_2", 0, 1, op_load_2},
    [OPC_ILOAD_3]       = {"iload_3", 0, 1, op_load_3},
    [OPC_LLOAD_0]       = {"lload_0", 0, 2, op_lload_0},
    [OPC_LLOAD_1]       = {"lload_1", 0, 2, op_lload_1},
    [OPC_LLOAD_2]       = {"lload_2", 0, 2, op_lload_2},
    [OPC_LLOAD_3]       = {"lload_3", 0, 2, op_lload_3},
    [OPC_FLOAD_0]       = {"fload_0", 0, 1, op_load_0},
    [OPC_FLOAD_1]       = {"fload_1", 0, 1, op_load_1},
    [OPC_FLOAD_2]       = {"fload_2", 0, 1, op_load_2},
    [OPC_FLOAD_3]       = {"fload_3", 0, 1, op_load_3},
    [OPC_DLOAD_0]       = {"dload_0", 0, 2, op_dload_0},
    [OPC_DLOAD_1]       = {"dload_1", 0, 2, op_dload_1},
    [OPC_DLOAD_2]       = {"dload_2", 0, 2, op_dload_2},
    [OPC_DLOAD_3]       = {"dload_3", 0, 2, op_dload_3},
    [OPC_ALOAD_0]       = {"aload_0", 0, 1, op_load_0},
    [OPC_ALOAD_1]       = {"aload_1", 0, 1, op_load_1},
    [OPC_ALOAD_2]       = {"aload_2", 0, 1, op_load_2},
    [OPC_ALOAD_3]       = {"aload_3", 0, 1, op_load_3},
    
    /* Array load */
    [OPC_IALOAD]        = {"iaload", 0, -1, op_array_load},
    [OPC_LALOAD]        = {"laload", 0, 0, op_array_load},
    [OPC_FALOAD]        = {"faload", 0, -1, op_array_load},
    [OPC_DALOAD]        = {"daload", 0, 0, op_array_load},
    [OPC_AALOAD]        = {"aaload", 0, -1, op_array_load},
    [OPC_BALOAD]        = {"baload", 0, -1, op_array_load},
    [OPC_CALOAD]        = {"caload", 0, -1, op_array_load},
    [OPC_SALOAD]        = {"saload", 0, -1, op_array_load},
    
    /* Store instructions */
    [OPC_ISTORE]        = {"istore", 1, -1, op_store},
    [OPC_LSTORE]        = {"lstore", 1, -2, op_store},
    [OPC_FSTORE]        = {"fstore", 1, -1, op_store},
    [OPC_DSTORE]        = {"dstore", 1, -2, op_store},
    [OPC_ASTORE]        = {"astore", 1, -1, op_store},
    [OPC_ISTORE_0]      = {"istore_0", 0, -1, op_store_0},
    [OPC_ISTORE_1]      = {"istore_1", 0, -1, op_store_1},
    [OPC_ISTORE_2]      = {"istore_2", 0, -1, op_store_2},
    [OPC_ISTORE_3]      = {"istore_3", 0, -1, op_store_3},
    [OPC_LSTORE_0]      = {"lstore_0", 0, -2, op_lstore_0},
    [OPC_LSTORE_1]      = {"lstore_1", 0, -2, op_lstore_1},
    [OPC_LSTORE_2]      = {"lstore_2", 0, -2, op_lstore_2},
    [OPC_LSTORE_3]      = {"lstore_3", 0, -2, op_lstore_3},
    [OPC_FSTORE_0]      = {"fstore_0", 0, -1, op_store_0},
    [OPC_FSTORE_1]      = {"fstore_1", 0, -1, op_store_1},
    [OPC_FSTORE_2]      = {"fstore_2", 0, -1, op_store_2},
    [OPC_FSTORE_3]      = {"fstore_3", 0, -1, op_store_3},
    [OPC_DSTORE_0]      = {"dstore_0", 0, -2, op_dstore_0},
    [OPC_DSTORE_1]      = {"dstore_1", 0, -2, op_dstore_1},
    [OPC_DSTORE_2]      = {"dstore_2", 0, -2, op_dstore_2},
    [OPC_DSTORE_3]      = {"dstore_3", 0, -2, op_dstore_3},
    [OPC_ASTORE_0]      = {"astore_0", 0, -1, op_store_0},
    [OPC_ASTORE_1]      = {"astore_1", 0, -1, op_store_1},
    [OPC_ASTORE_2]      = {"astore_2", 0, -1, op_store_2},
    [OPC_ASTORE_3]      = {"astore_3", 0, -1, op_store_3},
    
    /* Array store */
    [OPC_IASTORE]       = {"iastore", 0, -3, op_array_store},
    [OPC_LASTORE]       = {"lastore", 0, -4, op_array_store},
    [OPC_FASTORE]       = {"fastore", 0, -3, op_array_store},
    [OPC_DASTORE]       = {"dastore", 0, -4, op_array_store},
    [OPC_AASTORE]       = {"aastore", 0, -3, op_array_store},
    [OPC_BASTORE]       = {"bastore", 0, -3, op_array_store},
    [OPC_CASTORE]       = {"castore", 0, -3, op_array_store},
    [OPC_SASTORE]       = {"sastore", 0, -3, op_array_store},
    
    /* Stack operations */
    [OPC_POP]           = {"pop", 0, -1, op_pop},
    [OPC_POP2]          = {"pop2", 0, -2, op_pop2},
    [OPC_DUP]           = {"dup", 0, 1, op_dup},
    [OPC_DUP_X1]        = {"dup_x1", 0, 1, op_dup_x1},
    [OPC_DUP_X2]        = {"dup_x2", 0, 1, op_dup_x2},
    [OPC_DUP2]          = {"dup2", 0, 2, op_dup2},
    [OPC_DUP2_X1]       = {"dup2_x1", 0, 2, op_dup2_x1},
    [OPC_DUP2_X2]       = {"dup2_x2", 0, 2, op_dup2_x2},
    [OPC_SWAP]          = {"swap", 0, 0, op_swap},
    
    /* Arithmetic */
    [OPC_IADD]          = {"iadd", 0, -1, op_add},
    [OPC_LADD]          = {"ladd", 0, -2, op_add},
    [OPC_FADD]          = {"fadd", 0, -1, op_add},
    [OPC_DADD]          = {"dadd", 0, -2, op_add},
    [OPC_ISUB]          = {"isub", 0, -1, op_sub},
    [OPC_LSUB]          = {"lsub", 0, -2, op_sub},
    [OPC_FSUB]          = {"fsub", 0, -1, op_sub},
    [OPC_DSUB]          = {"dsub", 0, -2, op_sub},
    [OPC_IMUL]          = {"imul", 0, -1, op_mul},
    [OPC_LMUL]          = {"lmul", 0, -2, op_mul},
    [OPC_FMUL]          = {"fmul", 0, -1, op_mul},
    [OPC_DMUL]          = {"dmul", 0, -2, op_mul},
    [OPC_IDIV]          = {"idiv", 0, -1, op_div},
    [OPC_LDIV]          = {"ldiv", 0, -2, op_div},
    [OPC_FDIV]          = {"fdiv", 0, -1, op_div},
    [OPC_DDIV]          = {"ddiv", 0, -2, op_div},
    [OPC_IREM]          = {"irem", 0, -1, op_rem},
    [OPC_LREM]          = {"lrem", 0, -2, op_rem},
    [OPC_FREM]          = {"frem", 0, -1, op_rem},
    [OPC_DREM]          = {"drem", 0, -2, op_rem},
    [OPC_INEG]          = {"ineg", 0, 0, op_neg},
    [OPC_LNEG]          = {"lneg", 0, 0, op_neg},
    [OPC_FNEG]          = {"fneg", 0, 0, op_neg},
    [OPC_DNEG]          = {"dneg", 0, 0, op_neg},
    
    /* Bit operations */
    [OPC_ISHL]          = {"ishl", 0, -1, op_shl},
    [OPC_LSHL]          = {"lshl", 0, -1, op_shl},
    [OPC_ISHR]          = {"ishr", 0, -1, op_shr},
    [OPC_LSHR]          = {"lshr", 0, -1, op_shr},
    [OPC_IUSHR]         = {"iushr", 0, -1, op_ushr},
    [OPC_LUSHR]         = {"lushr", 0, -1, op_ushr},
    [OPC_IAND]          = {"iand", 0, -1, op_and},
    [OPC_LAND]          = {"land", 0, -2, op_and},
    [OPC_IOR]           = {"ior", 0, -1, op_or},
    [OPC_LOR]           = {"lor", 0, -2, op_or},
    [OPC_IXOR]          = {"ixor", 0, -1, op_xor},
    [OPC_LXOR]          = {"lxor", 0, -2, op_xor},
    [OPC_IINC]          = {"iinc", 2, 0, op_iinc},
    
    /* Conversions */
    [OPC_I2L]           = {"i2l", 0, 1, op_convert},
    [OPC_I2F]           = {"i2f", 0, 0, op_convert},
    [OPC_I2D]           = {"i2d", 0, 1, op_convert},
    [OPC_L2I]           = {"l2i", 0, -1, op_convert},
    [OPC_L2F]           = {"l2f", 0, -1, op_convert},
    [OPC_L2D]           = {"l2d", 0, 0, op_convert},
    [OPC_F2I]           = {"f2i", 0, 0, op_convert},
    [OPC_F2L]           = {"f2l", 0, 1, op_convert},
    [OPC_F2D]           = {"f2d", 0, 1, op_convert},
    [OPC_D2I]           = {"d2i", 0, -1, op_convert},
    [OPC_D2L]           = {"d2l", 0, 0, op_convert},
    [OPC_D2F]           = {"d2f", 0, -1, op_convert},
    [OPC_I2B]           = {"i2b", 0, 0, op_convert},
    [OPC_I2C]           = {"i2c", 0, 0, op_convert},
    [OPC_I2S]           = {"i2s", 0, 0, op_convert},
    
    /* Comparisons */
    [OPC_LCMP]          = {"lcmp", 0, -3, op_lcmp},
    [OPC_FCMPL]         = {"fcmpl", 0, -1, op_fcmpl},
    [OPC_FCMPG]         = {"fcmpg", 0, -1, op_fcmpg},
    [OPC_DCMPL]         = {"dcmpl", 0, -3, op_dcmpl},
    [OPC_DCMPG]         = {"dcmpg", 0, -3, op_dcmpg},
    
    /* Branches */
    [OPC_IFEQ]          = {"ifeq", 2, -1, op_if},
    [OPC_IFNE]          = {"ifne", 2, -1, op_if},
    [OPC_IFLT]          = {"iflt", 2, -1, op_if},
    [OPC_IFGE]          = {"ifge", 2, -1, op_if},
    [OPC_IFGT]          = {"ifgt", 2, -1, op_if},
    [OPC_IFLE]          = {"ifle", 2, -1, op_if},
    [OPC_IF_ICMPEQ]     = {"if_icmpeq", 2, -2, op_if_icmp},
    [OPC_IF_ICMPNE]     = {"if_icmpne", 2, -2, op_if_icmp},
    [OPC_IF_ICMPLT]     = {"if_icmplt", 2, -2, op_if_icmp},
    [OPC_IF_ICMPGE]     = {"if_icmpge", 2, -2, op_if_icmp},
    [OPC_IF_ICMPGT]     = {"if_icmpgt", 2, -2, op_if_icmp},
    [OPC_IF_ICMPLE]     = {"if_icmple", 2, -2, op_if_icmp},
    [OPC_IF_ACMPEQ]     = {"if_acmpeq", 2, -2, op_if_acmp},
    [OPC_IF_ACMPNE]     = {"if_acmpne", 2, -2, op_if_acmp},
    [OPC_GOTO]          = {"goto", 2, 0, op_goto},
    [OPC_JSR]           = {"jsr", 2, 1, op_jsr},
    [OPC_RET]           = {"ret", 1, 0, op_ret},
    [OPC_TABLESWITCH]   = {"tableswitch", 0, -1, op_tableswitch},
    [OPC_LOOKUPSWITCH]  = {"lookupswitch", 0, -1, op_lookupswitch},
    
    /* Returns */
    [OPC_IRETURN]       = {"ireturn", 0, -1, op_ireturn},
    [OPC_LRETURN]       = {"lreturn", 0, -2, op_lreturn},
    [OPC_FRETURN]       = {"freturn", 0, -1, op_freturn},
    [OPC_DRETURN]       = {"dreturn", 0, -2, op_dreturn},
    [OPC_ARETURN]       = {"areturn", 0, -1, op_areturn},
    [OPC_RETURN]        = {"return", 0, 0, op_return},
    
    /* Field access */
    [OPC_GETSTATIC]     = {"getstatic", 2, 1, op_getstatic},
    [OPC_PUTSTATIC]     = {"putstatic", 2, -1, op_putstatic},
    [OPC_GETFIELD]      = {"getfield", 2, 0, op_getfield},
    [OPC_PUTFIELD]      = {"putfield", 2, -2, op_putfield},
    
    /* Method invocation */
    [OPC_INVOKEVIRTUAL]   = {"invokevirtual", 2, 0, op_invokevirtual},
    [OPC_INVOKESPECIAL]   = {"invokespecial", 2, 0, op_invokespecial},
    [OPC_INVOKESTATIC]    = {"invokestatic", 2, 0, op_invokestatic},
    [OPC_INVOKEINTERFACE] = {"invokeinterface", 4, 0, op_invokeinterface},
    
    /* Object creation */
    [OPC_NEW]             = {"new", 2, 1, op_new},
    [OPC_NEWARRAY]        = {"newarray", 1, 0, op_newarray},
    [OPC_ANEWARRAY]       = {"anewarray", 2, 0, op_anewarray},
    [OPC_ARRAYLENGTH]     = {"arraylength", 0, 1, op_arraylength},
    [OPC_ATHROW]          = {"athrow", 0, 0, op_athrow},
    [OPC_CHECKCAST]       = {"checkcast", 2, 0, op_checkcast},
    [OPC_INSTANCEOF]      = {"instanceof", 2, 0, op_instanceof},
    [OPC_MONITORENTER]    = {"monitorenter", 0, -1, op_monitorenter},
    [OPC_MONITOREXIT]     = {"monitorexit", 0, -1, op_monitorexit},
    
    /* Extended */
    [OPC_WIDE]            = {"wide", 0, 0, op_wide},
    [OPC_MULTIANEWARRAY]  = {"multianewarray", 3, 1, op_multianewarray},
    [OPC_IFNULL]          = {"ifnull", 2, -1, op_ifnull},
    [OPC_IFNONNULL]       = {"ifnonnull", 2, -1, op_ifnonnull},
    [OPC_GOTO_W]          = {"goto_w", 4, 0, op_goto_w},
    [OPC_JSR_W]           = {"jsr_w", 4, 1, op_jsr_w},
};

/* Initialize opcodes */
void opcodes_init(void) {
    /* Opcode table is statically initialized */
    stack_error = 0;
}

/* Macro helpers */
#define FETCH_U1(frame) ((frame)->code[(frame)->pc++])
#define FETCH_U2(frame) (frame->pc += 2, jvm_read_u16(frame->code + frame->pc - 2))
#define FETCH_S1(frame) ((int8_t)FETCH_U1(frame))
#define FETCH_S2(frame) ((int16_t)FETCH_U2(frame))

/* Stack operations with bounds checking - FIXED to properly handle errors */
#define PUSH(frame, val) do { \
    if ((frame)->stack_top >= (int)(frame)->max_stack - 1) { \
        fprintf(stderr, "[EXEC] Stack overflow in %s: top=%d, max=%d\n", \
                (frame)->method->name, (frame)->stack_top, (frame)->max_stack); \
        return -1; \
    } \
    (frame)->stack[++(frame)->stack_top] = (val); \
} while(0)

/* FIXED: Safe pop that properly signals error on underflow */
static inline int safe_pop_with_value(JavaFrame* frame, JavaValue* out) {
    if (frame->stack_top < 0) {
        fprintf(stderr, "[EXEC] Stack underflow in %s at PC=%d\n", 
                frame->method->name, frame->pc - 1);
        stack_error = 1;
        out->raw = 0;
        return -1;
    }
    *out = frame->stack[frame->stack_top--];
    return 0;
}

/* Macro that checks for errors after pop */
#define POP_SAFE(frame, var) do { \
    if (safe_pop_with_value(frame, &var) != 0) { \
        return -1; \
    } \
} while(0)

/* Simple pop that ignores the value but checks for errors */
static inline int safe_pop_discard(JavaFrame* frame) {
    if (frame->stack_top < 0) {
        fprintf(stderr, "[EXEC] Stack underflow in %s at PC=%d\n", 
                frame->method->name, frame->pc - 1);
        return -1;
    }
    frame->stack_top--;
    return 0;
}

/* Backward compatible POP macro that returns value (use with caution) */
#define POP(frame) ({ \
    JavaValue _v; \
    if (safe_pop_with_value(frame, &_v) != 0) { \
        _v.raw = 0; \
    } \
    _v; \
})

/* Safe peek with bounds check */
static inline int safe_peek(JavaFrame* frame, JavaValue* out) {
    if (frame->stack_top < 0) {
        fprintf(stderr, "[EXEC] Stack underflow (peek) in %s at PC=%d\n",
                frame->method->name, frame->pc - 1);
        out->raw = 0;
        return -1;
    }
    *out = frame->stack[frame->stack_top];
    return 0;
}

#define PEEK(frame) ({ \
    JavaValue _v; \
    if (safe_peek(frame, &_v) != 0) { \
        _v.raw = 0; \
    } \
    _v; \
})

/* Safe local variable access with bounds checking */
static inline JavaValue* safe_local_ptr(JavaFrame* frame, uint16_t idx) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return NULL;
    }
    return &frame->locals[idx];
}

/* For simple cases where we want to return error on out-of-bounds */
static inline int load_local(JavaFrame* frame, uint16_t idx, JavaValue* result) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return -1;
    }
    *result = frame->locals[idx];
    return 0;
}

static inline int store_local(JavaFrame* frame, uint16_t idx, JavaValue value) {
    if (idx >= frame->max_locals) {
        fprintf(stderr, "[EXEC] Local variable out of bounds in %s: index=%d, max_locals=%d\n",
                frame->method->name, idx, frame->max_locals);
        return -1;
    }
    frame->locals[idx] = value;
    return 0;
}

/* Macros for backward compatibility with bounds checking */
#define LOCAL(frame, idx) (*safe_local_ptr(frame, idx))

/* Basic opcodes */
int op_nop(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    return 0;
}

int op_aconst_null(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v = { .ref = NULL };
    PUSH(frame, v);
    return 0;
}

int op_iconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jint value = opcode - OPC_ICONST_0;  /* -1 to 5 */
    JavaValue v = { .i = value };
    PUSH(frame, v);
    return 0;
}

int op_lconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jlong value = opcode - OPC_LCONST_0;  /* 0 or 1 */
    JavaValue v = { .j = value };
    PUSH(frame, v);
    return 0;
}

int op_fconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jfloat value = (jfloat)(opcode - OPC_FCONST_0);  /* 0.0, 1.0, or 2.0 */
    JavaValue v = { .f = value };
    PUSH(frame, v);
    return 0;
}

int op_dconst(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    jdouble value = (jdouble)(opcode - OPC_DCONST_0);  /* 0.0 or 1.0 */
    JavaValue v = { .d = value };
    PUSH(frame, v);
    return 0;
}

int op_bipush(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int8_t value = FETCH_S1(frame);
    JavaValue v = { .i = (jint)value };
    PUSH(frame, v);
    return 0;
}

int op_sipush(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t value = FETCH_S2(frame);
    JavaValue v = { .i = (jint)value };
    PUSH(frame, v);
    return 0;
}

int op_ldc(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaClass* clazz = frame->clazz;
    
    if (index == 0 || index >= clazz->constant_pool_count) {
        fprintf(stderr, "[EXEC] ldc: Invalid constant pool index %d (count=%d)\n",
                index, clazz->constant_pool_count);
        return -1;
    }
    
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Integer:
            v.i = entry->info.integer.value;
            break;
        case CONSTANT_Float:
            v.f = entry->info.float_val.value;
            break;
        case CONSTANT_String: {
            const char* str = classfile_get_utf8(clazz, entry->info.string_info.string_index);
            v.ref = jvm_new_string(jvm, str ? str : "");
            break;
        }
        case CONSTANT_Class: {
            const char* name = classfile_get_utf8(clazz, entry->info.class_info.name_index);
            v.ref = jvm_load_class(jvm, name ? name : "");
            break;
        }
        default:
            fprintf(stderr, "[EXEC] ldc: Unknown constant tag %d at index %d\n", 
                    entry->tag, index);
            return -1;
    }
    
    PUSH(frame, v);
    return 0;
}

int op_ldc_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaClass* clazz = frame->clazz;
    
    if (index == 0 || index >= clazz->constant_pool_count) {
        fprintf(stderr, "[EXEC] ldc_w: Invalid constant pool index %d\n", index);
        return -1;
    }
    
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Integer:
            v.i = entry->info.integer.value;
            break;
        case CONSTANT_Float:
            v.f = entry->info.float_val.value;
            break;
        case CONSTANT_String: {
            const char* str = classfile_get_utf8(clazz, entry->info.string_info.string_index);
            v.ref = jvm_new_string(jvm, str ? str : "");
            break;
        }
        default:
            fprintf(stderr, "[EXEC] ldc_w: Unknown constant tag %d\n", entry->tag);
            return -1;
    }
    
    PUSH(frame, v);
    return 0;
}

int op_ldc2_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaClass* clazz = frame->clazz;
    
    if (index == 0 || index >= clazz->constant_pool_count) {
        fprintf(stderr, "[EXEC] ldc2_w: Invalid constant pool index %d\n", index);
        return -1;
    }
    
    ConstantPoolEntry* entry = &clazz->constant_pool[index];
    
    JavaValue v = { .raw = 0 };
    
    switch (entry->tag) {
        case CONSTANT_Long:
            v.j = entry->info.long_val.value;
            break;
        case CONSTANT_Double:
            v.d = entry->info.double_val.value;
            break;
        default:
            fprintf(stderr, "[EXEC] ldc2_w: Expected Long/Double, got tag %d\n", entry->tag);
            return -1;
    }
    
    /* Long/double occupy 2 stack slots */
    PUSH(frame, v);
    PUSH(frame, v);
    return 0;
}

/* Load opcodes */
int op_iload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        return -1;
    }
    PUSH(frame, v);
    return 0;
}

int op_lload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v1, v2;
    if (load_local(frame, index, &v1) != 0) return -1;
    if (load_local(frame, index + 1, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_fload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_dload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v1, v2;
    if (load_local(frame, index, &v1) != 0) return -1;
    if (load_local(frame, index + 1, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_aload(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        return -1;
    }
    PUSH(frame, v);
    return 0;
}

int op_load_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 0, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 1, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 2, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_load_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (load_local(frame, 3, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

/* Long/Double load opcodes - these need 2 stack slots */
int op_lload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v0, v1;
    if (load_local(frame, 0, &v0) != 0) return -1;
    if (load_local(frame, 1, &v1) != 0) return -1;
    PUSH(frame, v0);
    PUSH(frame, v1);
    return 0;
}

int op_lload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (load_local(frame, 1, &v1) != 0) return -1;
    if (load_local(frame, 2, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_lload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v3;
    if (load_local(frame, 2, &v2) != 0) return -1;
    if (load_local(frame, 3, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v3);
    return 0;
}

int op_lload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v4;
    if (load_local(frame, 3, &v3) != 0) return -1;
    if (load_local(frame, 4, &v4) != 0) return -1;
    PUSH(frame, v3);
    PUSH(frame, v4);
    return 0;
}

/* dload_X same as lload_X */
int op_dload_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v0, v1;
    if (load_local(frame, 0, &v0) != 0) return -1;
    if (load_local(frame, 1, &v1) != 0) return -1;
    PUSH(frame, v0);
    PUSH(frame, v1);
    return 0;
}

int op_dload_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (load_local(frame, 1, &v1) != 0) return -1;
    if (load_local(frame, 2, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

int op_dload_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v3;
    if (load_local(frame, 2, &v2) != 0) return -1;
    if (load_local(frame, 3, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v3);
    return 0;
}

int op_dload_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v4;
    if (load_local(frame, 3, &v3) != 0) return -1;
    if (load_local(frame, 4, &v4) != 0) return -1;
    PUSH(frame, v3);
    PUSH(frame, v4);
    return 0;
}

/* Array load */
int op_array_load(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm;
    JavaValue index_val, array_val;
    
    if (safe_pop_with_value(frame, &index_val) != 0) return -1;
    if (safe_pop_with_value(frame, &array_val) != 0) return -1;
    
    jint index = index_val.i;
    JavaArray* array = (JavaArray*)array_val.ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (index < 0 || index >= array->length) {
        native_throw_aioobe(jvm, thread, index);
        return -1;
    }
    
    JavaValue v = array_get(array, index);
    PUSH(frame, v);
    return 0;
}

/* Store opcodes */
int op_store(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) {
        fprintf(stderr, "[EXEC] op_store: failed to pop value\n");
        return -1;
    }
    if (store_local(frame, index, v) != 0) {
        fprintf(stderr, "[EXEC] op_store: failed to store at index %d (max_locals=%d)\n", 
                index, frame->max_locals);
        return -1;
    }
    return 0;
}

int op_store_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    if (store_local(frame, 0, v) != 0) return -1;
    return 0;
}

int op_store_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    if (store_local(frame, 1, v) != 0) return -1;
    return 0;
}

int op_store_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    if (store_local(frame, 2, v) != 0) return -1;
    return 0;
}

int op_store_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    if (store_local(frame, 3, v) != 0) return -1;
    return 0;
}

/* Long/Double store opcodes - these need 2 stack slots */
int op_lstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v0;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v0) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    if (store_local(frame, 0, v0) != 0) return -1;
    return 0;
}

int op_lstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    return 0;
}

int op_lstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v2;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    return 0;
}

int op_lstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v4, v3;
    if (safe_pop_with_value(frame, &v4) != 0) return -1;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    if (store_local(frame, 4, v4) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    return 0;
}

/* dstore_X same as lstore_X */
int op_dstore_0(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v0;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v0) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    if (store_local(frame, 0, v0) != 0) return -1;
    return 0;
}

int op_dstore_1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    if (store_local(frame, 1, v1) != 0) return -1;
    return 0;
}

int op_dstore_2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v3, v2;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    if (store_local(frame, 2, v2) != 0) return -1;
    return 0;
}

int op_dstore_3(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v4, v3;
    if (safe_pop_with_value(frame, &v4) != 0) return -1;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    if (store_local(frame, 4, v4) != 0) return -1;
    if (store_local(frame, 3, v3) != 0) return -1;
    return 0;
}

/* Array store */
int op_array_store(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaValue value, index_val, array_val;
    
    if (safe_pop_with_value(frame, &value) != 0) return -1;
    if (safe_pop_with_value(frame, &index_val) != 0) return -1;
    if (safe_pop_with_value(frame, &array_val) != 0) return -1;
    
    jint index = index_val.i;
    JavaArray* array = (JavaArray*)array_val.ref;
    
    if (!array) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    if (index < 0 || index >= array->length) {
        native_throw_aioobe(jvm, thread, index);
        return -1;
    }
    
    array_set(array, index, value);
    return 0;
}

/* Stack operations */
int op_pop(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    return safe_pop_discard(frame);
}

int op_pop2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    if (safe_pop_discard(frame) != 0) return -1;
    if (safe_pop_discard(frame) != 0) return -1;
    return 0;
}

int op_dup(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_peek(frame, &v) != 0) return -1;
    PUSH(frame, v);
    return 0;
}

int op_dup_x1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup_x2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2, v3;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2_x1(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2, v3;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_dup2_x2(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2, v3, v4;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v3) != 0) return -1;
    if (safe_pop_with_value(frame, &v4) != 0) return -1;
    PUSH(frame, v2);
    PUSH(frame, v1);
    PUSH(frame, v4);
    PUSH(frame, v3);
    PUSH(frame, v2);
    PUSH(frame, v1);
    return 0;
}

int op_swap(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v1, v2;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    PUSH(frame, v1);
    PUSH(frame, v2);
    return 0;
}

/* Include the rest of the opcodes from the original file - continuing with the same pattern */
/* Note: For brevity, I'll include key remaining functions that are most likely to cause crashes */

/* Arithmetic operations */
int op_add(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IADD: result.i = v1.i + v2.i; break;
        case OPC_LADD: result.j = v1.j + v2.j; break;
        case OPC_FADD: result.f = v1.f + v2.f; break;
        case OPC_DADD: result.d = v1.d + v2.d; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_sub(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_ISUB: result.i = v1.i - v2.i; break;
        case OPC_LSUB: result.j = v1.j - v2.j; break;
        case OPC_FSUB: result.f = v1.f - v2.f; break;
        case OPC_DSUB: result.d = v1.d - v2.d; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_mul(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IMUL: result.i = v1.i * v2.i; break;
        case OPC_LMUL: result.j = v1.j * v2.j; break;
        case OPC_FMUL: result.f = v1.f * v2.f; break;
        case OPC_DMUL: result.d = v1.d * v2.d; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_div(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    /* Check for division by zero */
    switch (opcode) {
        case OPC_IDIV:
            if (v2.i == 0) {
                native_throw_iae(jvm, thread, "Division by zero");
                return -1;
            }
            result.i = v1.i / v2.i;
            break;
        case OPC_LDIV:
            if (v2.j == 0) {
                native_throw_iae(jvm, thread, "Division by zero");
                return -1;
            }
            result.j = v1.j / v2.j;
            break;
        case OPC_FDIV:
            if (v2.f == 0.0f) {
                result.f = v1.f / v2.f;  /* IEEE floating point handles this */
            } else {
                result.f = v1.f / v2.f;
            }
            break;
        case OPC_DDIV:
            result.d = v1.d / v2.d;  /* IEEE floating point handles this */
            break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_rem(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IREM:
            if (v2.i == 0) {
                native_throw_iae(jvm, thread, "Division by zero");
                return -1;
            }
            result.i = v1.i % v2.i;
            break;
        case OPC_LREM:
            if (v2.j == 0) {
                native_throw_iae(jvm, thread, "Division by zero");
                return -1;
            }
            result.j = v1.j % v2.j;
            break;
        case OPC_FREM: result.f = fmodf(v1.f, v2.f); break;
        case OPC_DREM: result.d = fmod(v1.d, v2.d); break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_neg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_INEG: result.i = -v.i; break;
        case OPC_LNEG: result.j = -v.j; break;
        case OPC_FNEG: result.f = -v.f; break;
        case OPC_DNEG: result.d = -v.d; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_shl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue shift_val, v;
    if (safe_pop_with_value(frame, &shift_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    
    jint shift = shift_val.i & 0x3F;
    JavaValue result;
    
    switch (opcode) {
        case OPC_ISHL: result.i = v.i << shift; break;
        case OPC_LSHL: result.j = v.j << shift; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_shr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue shift_val, v;
    if (safe_pop_with_value(frame, &shift_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    
    jint shift = shift_val.i & 0x3F;
    JavaValue result;
    
    switch (opcode) {
        case OPC_ISHR: result.i = v.i >> shift; break;
        case OPC_LSHR: result.j = v.j >> shift; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_ushr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue shift_val, v;
    if (safe_pop_with_value(frame, &shift_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    
    jint shift = shift_val.i & 0x3F;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IUSHR: result.i = ((juint)v.i) >> shift; break;
        case OPC_LUSHR: result.j = ((julong)v.j) >> shift; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_and(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IAND: result.i = v1.i & v2.i; break;
        case OPC_LAND: result.j = v1.j & v2.j; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_or(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IOR: result.i = v1.i | v2.i; break;
        case OPC_LOR: result.j = v1.j | v2.j; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_xor(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_IXOR: result.i = v1.i ^ v2.i; break;
        case OPC_LXOR: result.j = v1.j ^ v2.j; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

int op_iinc(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t index = FETCH_U1(frame);
    int8_t constant = FETCH_S1(frame);
    JavaValue v;
    if (load_local(frame, index, &v) != 0) {
        fprintf(stderr, "[EXEC] iinc: failed to load from index %d\n", index);
        return -1;
    }
    v.i += constant;
    if (store_local(frame, index, v) != 0) {
        fprintf(stderr, "[EXEC] iinc: failed to store to index %d\n", index);
        return -1;
    }
    return 0;
}

/* Conversion operations */
int op_convert(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint8_t opcode = frame->code[frame->pc - 1];
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    JavaValue result;
    
    switch (opcode) {
        case OPC_I2L: result.j = (jlong)v.i; break;
        case OPC_I2F: result.f = (jfloat)v.i; break;
        case OPC_I2D: result.d = (jdouble)v.i; break;
        case OPC_L2I: result.i = (jint)v.j; break;
        case OPC_L2F: result.f = (jfloat)v.j; break;
        case OPC_L2D: result.d = (jdouble)v.j; break;
        case OPC_F2I: result.i = (jint)v.f; break;
        case OPC_F2L: result.j = (jlong)v.f; break;
        case OPC_F2D: result.d = (jdouble)v.f; break;
        case OPC_D2I: result.i = (jint)v.d; break;
        case OPC_D2L: result.j = (jlong)v.d; break;
        case OPC_D2F: result.f = (jfloat)v.d; break;
        case OPC_I2B: result.i = (jint)(int8_t)v.i; break;
        case OPC_I2C: result.i = (jint)(uint8_t)v.i; break;
        case OPC_I2S: result.i = (jint)(int16_t)v.i; break;
        default: return -1;
    }
    
    PUSH(frame, result);
    return 0;
}

/* Comparison operations */
int op_lcmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2_val, v1_val;
    if (safe_pop_with_value(frame, &v2_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v1_val) != 0) return -1;
    
    jlong v2 = v2_val.j;
    jlong v1 = v1_val.j;
    JavaValue result;
    result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_fcmpl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2_val, v1_val;
    if (safe_pop_with_value(frame, &v2_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v1_val) != 0) return -1;
    
    jfloat v2 = v2_val.f;
    jfloat v1 = v1_val.f;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = -1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_fcmpg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2_val, v1_val;
    if (safe_pop_with_value(frame, &v2_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v1_val) != 0) return -1;
    
    jfloat v2 = v2_val.f;
    jfloat v1 = v1_val.f;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = 1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_dcmpl(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2_val, v1_val;
    if (safe_pop_with_value(frame, &v2_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v1_val) != 0) return -1;
    
    jdouble v2 = v2_val.d;
    jdouble v1 = v1_val.d;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = -1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

int op_dcmpg(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v2_val, v1_val;
    if (safe_pop_with_value(frame, &v2_val) != 0) return -1;
    if (safe_pop_with_value(frame, &v1_val) != 0) return -1;
    
    jdouble v2 = v2_val.d;
    jdouble v1 = v1_val.d;
    JavaValue result;
    if (isnan(v1) || isnan(v2)) result.i = 1;
    else result.i = (v1 > v2) ? 1 : (v1 < v2) ? -1 : 0;
    PUSH(frame, result);
    return 0;
}

/* Branch operations - need to properly check for errors */
int op_if(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    
    uint8_t opcode = frame->code[frame->pc - 3];
    jint value = v.i;
    int branch = 0;
    
    switch (opcode) {
        case OPC_IFEQ: branch = (value == 0); break;
        case OPC_IFNE: branch = (value != 0); break;
        case OPC_IFLT: branch = (value < 0); break;
        case OPC_IFGE: branch = (value >= 0); break;
        case OPC_IFGT: branch = (value > 0); break;
        case OPC_IFLE: branch = (value <= 0); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;  /* -3 because we already read opcode + 2 bytes */
    }
    
    return 0;
}

int op_if_icmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    
    uint8_t opcode = frame->code[frame->pc - 3];
    jint val2 = v2.i;
    jint val1 = v1.i;
    int branch = 0;
    
    switch (opcode) {
        case OPC_IF_ICMPEQ: branch = (val1 == val2); break;
        case OPC_IF_ICMPNE: branch = (val1 != val2); break;
        case OPC_IF_ICMPLT: branch = (val1 < val2); break;
        case OPC_IF_ICMPGE: branch = (val1 >= val2); break;
        case OPC_IF_ICMPGT: branch = (val1 > val2); break;
        case OPC_IF_ICMPLE: branch = (val1 <= val2); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_if_acmp(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue v2, v1;
    if (safe_pop_with_value(frame, &v2) != 0) return -1;
    if (safe_pop_with_value(frame, &v1) != 0) return -1;
    
    uint8_t opcode = frame->code[frame->pc - 3];
    int branch = 0;
    
    switch (opcode) {
        case OPC_IF_ACMPEQ: branch = (v1.ref == v2.ref); break;
        case OPC_IF_ACMPNE: branch = (v1.ref != v2.ref); break;
    }
    
    if (branch) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_goto(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    frame->pc += offset - 3;
    return 0;
}

/* Add the remaining opcodes as needed - for now include the most critical ones */

int op_ireturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    /* Return value is in stack, need to pass to caller */
    return 1;  /* Signal return */
}

int op_return(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    (void)frame;
    return 1;  /* Signal return */
}

/* newarray - FIXED with proper error handling */
int op_newarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint8_t atype = FETCH_U1(frame);
    JavaValue count_val;
    
    if (safe_pop_with_value(frame, &count_val) != 0) {
        fprintf(stderr, "[EXEC] newarray: Failed to pop count\n");
        return -1;
    }
    
    jint count = count_val.i;
    
    if (count < 0) {
        fprintf(stderr, "[EXEC] newarray: Negative array size %d\n", count);
        native_throw_iae(jvm, thread, "Negative array size");
        return -1;
    }
    
    /* Sanity check for very large arrays */
    if (count > 1000000) {
        fprintf(stderr, "[EXEC] newarray: Array size too large: %d\n", count);
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaArray* array = jvm_new_array(jvm, atype, count);
    if (!array) {
        fprintf(stderr, "[EXEC] newarray: Failed to allocate array of size %d, type %d\n", count, atype);
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = array };
    PUSH(frame, v);
    return 0;
}

int op_anewarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    uint16_t index = FETCH_U2(frame);
    JavaValue count_val;
    
    if (safe_pop_with_value(frame, &count_val) != 0) {
        return -1;
    }
    
    jint count = count_val.i;
    (void)index;
    
    if (count < 0) {
        native_throw_iae(jvm, thread, "Negative array size");
        return -1;
    }
    
    if (count > 1000000) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaArray* array = jvm_new_array(jvm, DESC_OBJECT, count);
    if (!array) {
        native_throw_oome(jvm, thread);
        return -1;
    }
    
    JavaValue v = { .ref = array };
    PUSH(frame, v);
    return 0;
}

/* FIXED: arraylength with proper null check */
int op_arraylength(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    JavaValue array_val;
    
    if (safe_pop_with_value(frame, &array_val) != 0) {
        return -1;
    }
    
    JavaArray* array = (JavaArray*)array_val.ref;
    
    if (!array) {
        fprintf(stderr, "[EXEC] arraylength: null array\n");
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    JavaValue result = { .i = array->length };
    PUSH(frame, result);
    return 0;
}

/* ifnull and ifnonnull - FIXED */
int op_ifnull(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue v;
    
    if (safe_pop_with_value(frame, &v) != 0) {
        return -1;
    }
    
    if (v.ref == NULL) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

int op_ifnonnull(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int16_t offset = FETCH_S2(frame);
    JavaValue v;
    
    if (safe_pop_with_value(frame, &v) != 0) {
        return -1;
    }
    
    if (v.ref != NULL) {
        frame->pc += offset - 3;
    }
    
    return 0;
}

/* Placeholder implementations for remaining opcodes - to be completed */
int op_jsr(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] jsr not implemented\n");
    return -1;
}

int op_ret(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] ret not implemented\n");
    return -1;
}

int op_tableswitch(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] tableswitch not implemented\n");
    return -1;
}

int op_lookupswitch(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] lookupswitch not implemented\n");
    return -1;
}

int op_lreturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    if (safe_pop_discard(frame) != 0) return -1;  /* Second slot */
    return 1;
}

int op_freturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    return 1;
}

int op_dreturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    if (safe_pop_discard(frame) != 0) return -1;
    return 1;
}

int op_areturn(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    return 1;
}

int op_getstatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    /* TODO: Implement */
    uint16_t index = FETCH_U2(frame);
    (void)index;
    JavaValue v = { .i = 0 };
    PUSH(frame, v);
    return 0;
}

int op_putstatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    /* TODO: Implement */
    uint16_t index = FETCH_U2(frame);
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    (void)index; (void)v;
    return 0;
}

int op_getfield(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    /* TODO: Implement properly */
    uint16_t index = FETCH_U2(frame);
    JavaValue obj_val;
    if (safe_pop_with_value(frame, &obj_val) != 0) return -1;
    
    JavaObject* obj = (JavaObject*)obj_val.ref;
    if (!obj) {
        native_throw_npe(jvm, thread);
        return -1;
    }
    
    /* For now return 0 */
    JavaValue v = { .i = 0 };
    PUSH(frame, v);
    (void)index;
    return 0;
}

int op_putfield(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    /* TODO: Implement properly */
    uint16_t index = FETCH_U2(frame);
    JavaValue value, obj_val;
    if (safe_pop_with_value(frame, &value) != 0) return -1;
    if (safe_pop_with_value(frame, &obj_val) != 0) return -1;
    
    (void)index; (void)value; (void)obj_val;
    return 0;
}

int op_invokevirtual(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    /* This is handled by execute.c */
    fprintf(stderr, "[EXEC] invokevirtual should not be called directly\n");
    return -1;
}

int op_invokespecial(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] invokespecial should not be called directly\n");
    return -1;
}

int op_invokestatic(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] invokestatic should not be called directly\n");
    return -1;
}

int op_invokeinterface(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] invokeinterface should not be called directly\n");
    return -1;
}

int op_new(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] new should not be called directly\n");
    return -1;
}

int op_athrow(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] athrow not implemented\n");
    return -1;
}

int op_checkcast(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint16_t index = FETCH_U2(frame);
    (void)index;
    /* No-op for now */
    return 0;
}

int op_instanceof(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    uint16_t index = FETCH_U2(frame);
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    
    JavaValue result = { .i = (v.ref != NULL) ? 1 : 0 };
    PUSH(frame, result);
    (void)index;
    return 0;
}

int op_monitorenter(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    /* No-op for now */
    return 0;
}

int op_monitorexit(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    JavaValue v;
    if (safe_pop_with_value(frame, &v) != 0) return -1;
    /* No-op for now */
    return 0;
}

int op_wide(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] wide not implemented\n");
    return -1;
}

int op_multianewarray(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] multianewarray not implemented\n");
    return -1;
}

int op_goto_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread;
    int32_t offset = (int32_t)FETCH_U2(frame);  /* Simplified */
    frame->pc += offset;
    return 0;
}

int op_jsr_w(JVM* jvm, JavaThread* thread, JavaFrame* frame) {
    (void)jvm; (void)thread; (void)frame;
    fprintf(stderr, "[EXEC] jsr_w not implemented\n");
    return -1;
}
