/*
 * J2ME Emulator - Heap and Garbage Collector
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "heap.h"
#include "jvm.h"
#include "opcodes.h"    /* For T_BOOLEAN, T_BYTE, etc. */
#include "classfile.h"  /* For classfile_get_class_name */

/* Heap state */
static struct {
    uint8_t* start;
    uint8_t* current;
    uint8_t* end;
    size_t size;
    size_t allocated;
    
    GCObjectHeader* objects;
    size_t object_count;
    
    void*** roots;
    size_t root_count;
    size_t root_capacity;
} heap;

/* Initialize heap */
int heap_init(JVM* jvm, size_t initial_size, size_t max_size) {
    (void)jvm; (void)max_size;
    
    heap.start = (uint8_t*)malloc(initial_size);
    if (!heap.start) return JNI_ERR;
    
    heap.current = heap.start;
    heap.end = heap.start + initial_size;
    heap.size = initial_size;
    heap.allocated = 0;
    heap.objects = NULL;
    heap.object_count = 0;
    
    heap.roots = (void***)malloc(1024 * sizeof(void**));
    heap.root_capacity = 1024;
    heap.root_count = 0;
    
    return JNI_OK;
}

/* Destroy heap */
void heap_destroy(JVM* jvm) {
    (void)jvm;
    
    free(heap.start);
    free(heap.objects);
    free(heap.roots);
    
    heap.start = NULL;
    heap.current = NULL;
    heap.end = NULL;
}

/* Allocate memory */
void* heap_alloc(JVM* jvm, size_t size, JavaClass* clazz, ObjectType type) {
    (void)jvm;
    
    /* Align size */
    size = (size + OBJECT_ALIGNMENT - 1) & ~(OBJECT_ALIGNMENT - 1);
    
    /* Add header size */
    size_t total_size = sizeof(GCObjectHeader) + size;
    
    /* Check if we have enough space */
    if (heap.current + total_size > heap.end) {
        /* Try garbage collection */
        gc_collect(jvm);
        
        if (heap.current + total_size > heap.end) {
            return NULL;  /* Out of memory */
        }
    }
    
    /* Allocate */
    GCObjectHeader* header = (GCObjectHeader*)heap.current;
    heap.current += total_size;
    heap.allocated += total_size;
    
    /* Initialize header */
    header->next = heap.objects;
    header->clazz = clazz;
    header->size = (uint32_t)total_size;
    header->type = (uint8_t)type;
    header->marked = 0;
    header->pinned = 0;
    header->reserved = 0;
    
    /* Add to object list */
    heap.objects = header;
    heap.object_count++;
    
    /* Return pointer after header */
    return (void*)(header + 1);
}

/* Allocate object */
JavaObject* heap_alloc_object(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return NULL;
    
    /* Calculate instance size */
    size_t size = clazz->instance_size;
    if (size == 0) {
        /* Calculate from fields */
        size = sizeof(JavaValue) * clazz->fields_count;
    }
    
    JavaObject* obj = (JavaObject*)heap_alloc(jvm, sizeof(ObjectHeader) + size, 
                                               clazz, OBJ_TYPE_OBJECT);
    if (obj) {
        obj->header.clazz = clazz;
        obj->header.hashcode = (jint)(intptr_t)obj;  /* Simple identity hash */
        obj->header.gc_mark = 0;
        obj->header.reserved = 0;
        
        /* Zero fields */
        memset(obj->fields, 0, size);
    }
    
    return obj;
}

/* Allocate array */
JavaArray* heap_alloc_array(JVM* jvm, uint8_t element_type, jsize length) {
    /* Calculate element size */
    size_t elem_size;
    switch (element_type) {
        case T_BOOLEAN:
        case T_BYTE:    elem_size = 1; break;
        case T_CHAR:
        case T_SHORT:   elem_size = 2; break;
        case T_INT:
        case T_FLOAT:   elem_size = 4; break;
        case T_LONG:
        case T_DOUBLE:  elem_size = 8; break;
        case DESC_OBJECT:
        case DESC_ARRAY: elem_size = sizeof(void*); break;
        default: elem_size = 4; break;
    }
    
    size_t data_size = elem_size * length;
    JavaArray* array = (JavaArray*)heap_alloc(jvm, sizeof(JavaArray) + data_size,
                                               NULL, OBJ_TYPE_ARRAY);
    if (array) {
        array->header.clazz = NULL;  /* Arrays don't have regular class */
        array->header.hashcode = (jint)(intptr_t)array;
        array->length = length;
        array->element_type = element_type;
        
        /* Set data pointer */
        if (element_type == DESC_OBJECT || element_type == DESC_ARRAY) {
            array->data.refs = (void**)((uint8_t*)array + sizeof(JavaArray));
        } else {
            array->data.bytes = (uint8_t*)array + sizeof(JavaArray);
        }
        
        /* Zero data */
        memset(array->data.bytes, 0, data_size);
    }
    
    return array;
}

/* Allocate string */
JavaString* heap_alloc_string(JVM* jvm, jsize length) {
    size_t data_size = length * sizeof(jchar);
    JavaString* str = (JavaString*)heap_alloc(jvm, sizeof(JavaString) + data_size,
                                               NULL, OBJ_TYPE_STRING);
    if (str) {
        /* Set the String class - find it from the class loader */
        for (size_t i = 0; i < jvm->class_loader.count; i++) {
            JavaClass* clazz = jvm->class_loader.classes[i];
            if (clazz->class_name && strcmp(clazz->class_name, "java/lang/String") == 0) {
                str->header.clazz = clazz;
                break;
            }
        }
        str->header.hashcode = (jint)(intptr_t)str;
        str->length = length;
        str->chars = (jchar*)((uint8_t*)str + sizeof(JavaString));
        str->utf8 = NULL;
        str->hash = 0;
    }
    
    return str;
}

/* Mark phase */
static void gc_mark_object(void* ptr) {
    if (!ptr) return;
    
    GCObjectHeader* header = (GCObjectHeader*)ptr - 1;
    
    if (header->marked) return;  /* Already marked */
    
    header->marked = 1;
    
    /* Mark referenced objects */
    if (header->type == OBJ_TYPE_OBJECT) {
        JavaObject* obj = (JavaObject*)ptr;
        JavaClass* clazz = obj->header.clazz;
        
        if (clazz) {
            /* Mark class */
            gc_mark_object(clazz);
            
            /* Mark reference fields */
            for (int i = 0; i < clazz->fields_count; i++) {
                JavaField* field = &clazz->fields[i];
                if (field->descriptor && field->descriptor[0] == 'L') {
                    gc_mark_object(obj->fields[i].ref);
                }
            }
        }
    } else if (header->type == OBJ_TYPE_ARRAY) {
        JavaArray* array = (JavaArray*)ptr;
        
        if (array->element_type == DESC_OBJECT || array->element_type == DESC_ARRAY) {
            for (jsize i = 0; i < array->length; i++) {
                gc_mark_object(array->data.refs[i]);
            }
        }
    }
}

/* Run garbage collection */
void gc_collect(JVM* jvm) {
    if (!jvm) return;
    
    /* Mark phase */
    
    /* Mark from roots */
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] && *heap.roots[i]) {
            gc_mark_object(*heap.roots[i]);
        }
    }
    
    /* Mark from thread stacks */
    for (int i = 0; i < jvm->thread_count; i++) {
        JavaThread* thread = jvm->threads[i];
        if (!thread) continue;
        
        /* Mark pending exception */
        if (thread->pending_exception) {
            gc_mark_object(thread->pending_exception);
        }
        
        /* Mark stack frames */
        JavaFrame* frame = thread->current_frame;
        while (frame) {
            /* Mark local variables */
            for (uint16_t j = 0; j < frame->max_locals; j++) {
                if (frame->locals[j].ref) {
                    gc_mark_object(frame->locals[j].ref);
                }
            }
            
            /* Mark operand stack */
            for (int16_t j = 0; j <= frame->stack_top; j++) {
                if (frame->stack[j].ref) {
                    gc_mark_object(frame->stack[j].ref);
                }
            }
            
            frame = frame->prev;
        }
    }
    
    /* Sweep phase */
    GCObjectHeader** pp = &heap.objects;
    while (*pp) {
        GCObjectHeader* obj = *pp;
        
        if (!obj->marked && !obj->pinned) {
            /* Free object */
            *pp = obj->next;
            heap.allocated -= obj->size;
            heap.object_count--;
            /* Note: We don't actually free memory in this simple collector */
        } else {
            /* Clear mark for next collection */
            obj->marked = 0;
            pp = &obj->next;
        }
    }
}

/* Add GC root */
void gc_add_root(JVM* jvm, void** root) {
    (void)jvm;
    
    if (heap.root_count >= heap.root_capacity) {
        heap.root_capacity *= 2;
        heap.roots = (void***)realloc(heap.roots, heap.root_capacity * sizeof(void**));
    }
    
    heap.roots[heap.root_count++] = root;
}

/* Remove GC root */
void gc_remove_root(JVM* jvm, void** root) {
    (void)jvm;
    
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] == root) {
            heap.roots[i] = heap.roots[--heap.root_count];
            return;
        }
    }
}

/* Pin object */
void gc_pin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object) return;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 1;
}

/* Unpin object */
void gc_unpin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object) return;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 0;
}

/* Get heap statistics */
HeapStats heap_get_stats(JVM* jvm) {
    HeapStats stats = {0};
    (void)jvm;
    
    stats.total_size = heap.size;
    stats.used_size = heap.allocated;
    stats.free_size = heap.size - heap.allocated;
    stats.object_count = heap.object_count;
    
    return stats;
}

/* Get object class */
JavaClass* object_get_class(void* object) {
    if (!object) return NULL;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->clazz;
}

/* Get object size */
size_t object_get_size(void* object) {
    if (!object) return 0;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->size;
}

/* Get object hash code */
jint object_hash_code(void* object) {
    if (!object) return 0;
    
    JavaObject* obj = (JavaObject*)object;
    return obj->header.hashcode;
}

/* Check if object is an array */
bool object_is_array(void* object) {
    if (!object) return false;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_ARRAY;
}

/* Check if object is a string */
bool object_is_string(void* object) {
    if (!object) return false;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_STRING;
}

/* Check if object is instance of class */
bool object_instance_of(void* object, JavaClass* clazz) {
    if (!object || !clazz) return false;
    
    JavaClass* obj_class = object_get_class(object);
    if (!obj_class) return false;
    
    /* Check class hierarchy */
    while (obj_class) {
        if (obj_class == clazz) return true;
        
        /* Check interfaces */
        for (int i = 0; i < obj_class->interfaces_count; i++) {
            const char* iface_name = classfile_get_class_name(obj_class, obj_class->interfaces[i]);
            if (strcmp(iface_name, clazz->class_name) == 0) {
                return true;
            }
        }
        
        obj_class = obj_class->super_class;
    }
    
    return false;
}

/* Get array length */
jsize array_length(JavaArray* array) {
    return array ? array->length : 0;
}

/* Get array element type */
uint8_t array_element_type(JavaArray* array) {
    return array ? array->element_type : 0;
}

/* Get array element */
JavaValue array_get(JavaArray* array, jsize index) {
    JavaValue v = { .raw = 0 };
    
    if (!array || index < 0 || index >= array->length) {
        return v;
    }
    
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:
            v.i = array->data.bytes[index];
            break;
        case T_CHAR:
            v.i = array->data.chars[index];
            break;
        case T_SHORT:
            v.i = array->data.shorts[index];
            break;
        case T_INT:
            v.i = array->data.ints[index];
            break;
        case T_LONG:
            v.j = array->data.longs[index];
            break;
        case T_FLOAT:
            v.f = array->data.floats[index];
            break;
        case T_DOUBLE:
            v.d = array->data.doubles[index];
            break;
        case DESC_OBJECT:
        case DESC_ARRAY:
            v.ref = array->data.refs[index];
            break;
    }
    
    return v;
}

/* Set array element */
void array_set(JavaArray* array, jsize index, JavaValue value) {
    if (!array || index < 0 || index >= array->length) {
        return;
    }
    
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:
            array->data.bytes[index] = (uint8_t)value.i;
            break;
        case T_CHAR:
            array->data.chars[index] = (jchar)value.i;
            break;
        case T_SHORT:
            array->data.shorts[index] = (jshort)value.i;
            break;
        case T_INT:
            array->data.ints[index] = value.i;
            break;
        case T_LONG:
            array->data.longs[index] = value.j;
            break;
        case T_FLOAT:
            array->data.floats[index] = value.f;
            break;
        case T_DOUBLE:
            array->data.doubles[index] = value.d;
            break;
        case DESC_OBJECT:
        case DESC_ARRAY:
            array->data.refs[index] = value.ref;
            break;
    }
}

/* Get reference from object array */
void* array_get_ref(JavaArray* array, jsize index) {
    if (!array || index < 0 || index >= array->length) return NULL;
    return array->data.refs[index];
}

/* Set reference in object array */
void array_set_ref(JavaArray* array, jsize index, void* ref) {
    if (!array || index < 0 || index >= array->length) return;
    array->data.refs[index] = ref;
}

/* Get string length */
jsize string_length(JavaString* str) {
    return str ? str->length : 0;
}

/* Get string characters */
const jchar* string_chars(JavaString* str) {
    return str ? str->chars : NULL;
}

/* Get string as UTF-8 */
const char* string_utf8(JVM* jvm, JavaString* str) {
    if (!str) return NULL;
    if (str->utf8) return str->utf8;
    
    /* Convert UTF-16 to UTF-8 */
    char* result = (char*)malloc(str->length * 3 + 1);
    if (!result) return NULL;
    
    char* p = result;
    for (jsize i = 0; i < str->length; i++) {
        jchar c = str->chars[i];
        if (c < 0x80) {
            *p++ = (char)c;
        } else if (c < 0x800) {
            *p++ = (char)(0xC0 | (c >> 6));
            *p++ = (char)(0x80 | (c & 0x3F));
        } else {
            *p++ = (char)(0xE0 | (c >> 12));
            *p++ = (char)(0x80 | ((c >> 6) & 0x3F));
            *p++ = (char)(0x80 | (c & 0x3F));
        }
    }
    *p = '\0';
    
    str->utf8 = result;
    return result;
}

/* Compare strings */
bool string_equals(JavaString* a, JavaString* b) {
    if (a == b) return true;
    if (!a || !b) return false;
    if (a->length != b->length) return false;
    
    return memcmp(a->chars, b->chars, a->length * sizeof(jchar)) == 0;
}

/* String hash code */
jint string_hash(JavaString* str) {
    if (!str) return 0;
    if (str->hash) return str->hash;
    
    jint hash = 0;
    for (jsize i = 0; i < str->length; i++) {
        hash = 31 * hash + str->chars[i];
    }
    
    str->hash = hash;
    return hash;
}

/* Dump heap */
void heap_dump(JVM* jvm) {
    if (!jvm) return;
    
    printf("=== Heap Dump ===\n");
    printf("Total: %zu bytes\n", heap.size);
    printf("Used: %zu bytes\n", heap.allocated);
    printf("Objects: %zu\n", heap.object_count);
    
    GCObjectHeader* obj = heap.objects;
    while (obj) {
        printf("Object @ %p: size=%u, type=%d, class=%s\n",
               (void*)(obj + 1), obj->size, obj->type,
               obj->clazz ? obj->clazz->class_name : "(null)");
        obj = obj->next;
    }
}
