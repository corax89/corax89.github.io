/*
 * J2ME Emulator - Heap and Garbage Collector
 * Mark-Sweep with free list for memory reclamation
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "heap.h"
#include "jvm.h"
#include "opcodes.h"    /* For T_BOOLEAN, T_BYTE, etc. */
#include "classfile.h"  /* For classfile_get_class_name */

/* Free list entry for recycled memory */
typedef struct FreeBlock {
    struct FreeBlock* next;
    size_t size;
} FreeBlock;

/* Heap state */
static struct {
    uint8_t* start;
    uint8_t* current;
    uint8_t* end;
    size_t size;
    size_t allocated;
    size_t freed;  /* Track freed bytes */
    
    GCObjectHeader* objects;
    size_t object_count;
    
    FreeBlock* free_list;  /* Free list for recycled memory */
    
    void*** roots;
    size_t root_count;
    size_t root_capacity;
    
    /* GC statistics */
    size_t gc_cycles;
    size_t gc_total_freed;
} heap;

/* Forward declarations */
static void gc_mark_object(void* ptr);
static void* try_alloc_from_free_list(size_t total_size);

/* Check if pointer is within heap */
static inline bool is_heap_ptr(void* ptr) {
    return ptr >= (void*)heap.start && ptr < (void*)heap.end;
}

/* Initialize heap */
int heap_init(JVM* jvm, size_t initial_size, size_t max_size) {
    (void)jvm; (void)max_size;
    
    heap.start = (uint8_t*)malloc(initial_size);
    if (!heap.start) return JNI_ERR;
    
    heap.current = heap.start;
    heap.end = heap.start + initial_size;
    heap.size = initial_size;
    heap.allocated = 0;
    heap.freed = 0;
    heap.objects = NULL;
    heap.object_count = 0;
    heap.free_list = NULL;
    heap.gc_cycles = 0;
    heap.gc_total_freed = 0;
    
    heap.roots = (void***)malloc(1024 * sizeof(void**));
    heap.root_capacity = 1024;
    heap.root_count = 0;
    
    return JNI_OK;
}

/* Destroy heap */
void heap_destroy(JVM* jvm) {
    (void)jvm;
    
    free(heap.start);
    free(heap.roots);
    
    heap.start = NULL;
    heap.current = NULL;
    heap.end = NULL;
    heap.free_list = NULL;
}

/* Try to allocate from free list */
static void* try_alloc_from_free_list(size_t total_size) {
    FreeBlock** pp = &heap.free_list;
    
    while (*pp) {
        FreeBlock* block = *pp;
        
        /* Check if block is large enough */
        if (block->size >= total_size) {
            /* Found a suitable block */
            *pp = block->next;
            
            /* If block is much larger, split it */
            if (block->size >= total_size + sizeof(FreeBlock) + 64) {
                FreeBlock* remainder = (FreeBlock*)((uint8_t*)block + total_size);
                remainder->size = block->size - total_size;
                remainder->next = heap.free_list;
                heap.free_list = remainder;
            }
            
            return block;
        }
        
        pp = &block->next;
    }
    
    return NULL;
}

/* Allocate memory */
void* heap_alloc(JVM* jvm, size_t size, JavaClass* clazz, ObjectType type) {
    (void)jvm;
    
    /* Align size */
    size = (size + OBJECT_ALIGNMENT - 1) & ~(OBJECT_ALIGNMENT - 1);
    
    /* Add header size */
    size_t total_size = sizeof(GCObjectHeader) + size;
    
    /* Try free list first */
    GCObjectHeader* header = (GCObjectHeader*)try_alloc_from_free_list(total_size);
    
    if (!header) {
        /* Check if we have enough space */
        if (heap.current + total_size > heap.end) {
            /* Try garbage collection */
            gc_collect(jvm);
            
            /* Try free list again after GC */
            header = (GCObjectHeader*)try_alloc_from_free_list(total_size);
            
            if (!header && heap.current + total_size > heap.end) {
                fprintf(stderr, "[GC] Out of memory! Requested: %zu, Available: %zu\n",
                        total_size, (size_t)(heap.end - heap.current));
                return NULL;  /* Out of memory */
            }
        }
        
        if (!header) {
            /* Allocate from bump pointer */
            header = (GCObjectHeader*)heap.current;
            heap.current += total_size;
        }
    }
    
    heap.allocated += total_size;
    
    /* Initialize header */
    header->next = heap.objects;
    header->clazz = clazz;
    header->size = (uint32_t)total_size;
    header->type = (uint8_t)type;
    header->marked = 0;
    header->pinned = 0;
    header->reserved = 0;
    
    /* Add to object list */
    heap.objects = header;
    heap.object_count++;
    
    /* Return pointer after header */
    void* ptr = (void*)(header + 1);
    memset(ptr, 0, size);  /* Zero-initialize */
    
    return ptr;
}

/* Allocate object */
JavaObject* heap_alloc_object(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return NULL;
    
    /* Calculate instance size - include all fields from super classes */
    size_t size = clazz->instance_size;
    if (size == 0) {
        /* Calculate from field count */
        size = sizeof(JavaValue) * clazz->fields_count;
    }
    
    /* Ensure minimum size for ObjectHeader */
    if (size < sizeof(ObjectHeader)) {
        size = sizeof(ObjectHeader);
    }
    
    JavaObject* obj = (JavaObject*)heap_alloc(jvm, size, clazz, OBJ_TYPE_OBJECT);
    if (obj) {
        obj->header.clazz = clazz;
        obj->header.hashcode = (jint)(intptr_t)obj;  /* Simple identity hash */
        obj->header.gc_mark = 0;
        obj->header.reserved = 0;
    }
    
    return obj;
}

/* Allocate array - data inline after structure */
JavaArray* heap_alloc_array(JVM* jvm, uint8_t element_type, jsize length) {
    /* Calculate element size */
    size_t elem_size;
    switch (element_type) {
        case T_BOOLEAN:
        case T_BYTE:    elem_size = 1; break;
        case T_CHAR:
        case T_SHORT:   elem_size = 2; break;
        case T_INT:
        case T_FLOAT:   elem_size = 4; break;
        case T_LONG:
        case T_DOUBLE:  elem_size = 8; break;
        case DESC_OBJECT:
        case DESC_ARRAY: elem_size = sizeof(void*); break;
        default: elem_size = 4; break;
    }
    
    size_t data_size = elem_size * length;
    size_t total_size = sizeof(JavaArray) + data_size;
    
    JavaArray* array = (JavaArray*)heap_alloc(jvm, total_size, NULL, OBJ_TYPE_ARRAY);
    if (!array) return NULL;
    
    array->header.clazz = NULL;  /* Arrays don't have regular class */
    array->header.hashcode = (jint)(intptr_t)array;
    array->length = length;
    array->element_type = element_type;
    memset(array->_padding, 0, sizeof(array->_padding));
    
    /* Data is already zero-initialized by heap_alloc */
    
    return array;
}

/* Get pointer to array data */
static inline void* array_data_ptr(JavaArray* array) {
    return (void*)((uint8_t*)array + sizeof(JavaArray));
}

/* Allocate string - chars inline after structure */
JavaString* heap_alloc_string(JVM* jvm, jsize length) {
    size_t data_size = length * sizeof(jchar);
    size_t total_size = sizeof(JavaString) + data_size;
    
    JavaString* str = (JavaString*)heap_alloc(jvm, total_size, NULL, OBJ_TYPE_STRING);
    if (!str) return NULL;
    
    /* Set the String class - find it from the class loader */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (clazz->class_name && strcmp(clazz->class_name, "java/lang/String") == 0) {
            str->header.clazz = clazz;
            break;
        }
    }
    str->header.hashcode = (jint)(intptr_t)str;
    str->length = length;
    str->hash = 0;
    str->utf8 = NULL;
    
    /* Chars are already zero-initialized by heap_alloc */
    
    return str;
}

/* Mark phase - iterative to avoid stack overflow */
#define GC_MARK_STACK_SIZE 4096

typedef struct {
    void* ptr;
    int field_idx;
    int array_idx;
} MarkStackEntry;

static MarkStackEntry gc_mark_stack[GC_MARK_STACK_SIZE];
static int gc_mark_stack_top = 0;

static inline void gc_push_mark(void* ptr) {
    if (gc_mark_stack_top < GC_MARK_STACK_SIZE) {
        gc_mark_stack[gc_mark_stack_top].ptr = ptr;
        gc_mark_stack[gc_mark_stack_top].field_idx = 0;
        gc_mark_stack[gc_mark_stack_top].array_idx = 0;
        gc_mark_stack_top++;
    }
}

static void gc_mark_object(void* ptr) {
    if (!ptr) return;
    
    /* Check if pointer is within heap */
    if (!is_heap_ptr(ptr)) {
        return;  /* Not a heap object (could be static data, class data, etc.) */
    }
    
    /* Get the GC header */
    GCObjectHeader* header = (GCObjectHeader*)ptr - 1;
    
    /* Validate header - check if it looks reasonable */
    if (header->size == 0 || header->size > heap.size) {
        return;  /* Invalid header */
    }
    
    if (header->marked) {
        return;  /* Already marked */
    }
    
    header->marked = 1;
    
    /* Handle different object types */
    switch (header->type) {
        case OBJ_TYPE_OBJECT: {
            JavaObject* obj = (JavaObject*)ptr;
            JavaClass* clazz = obj->header.clazz;
            
            /* Mark reference fields in class hierarchy */
            while (clazz) {
                for (int i = 0; i < clazz->fields_count; i++) {
                    JavaField* field = &clazz->fields[i];
                    if (field->descriptor) {
                        char c = field->descriptor[0];
                        if (c == 'L' || c == '[') {
                            /* Reference field */
                            void* ref = obj->fields[field->offset].ref;
                            if (ref && is_heap_ptr(ref)) {
                                gc_push_mark(ref);
                            }
                        }
                    }
                }
                clazz = clazz->super_class;
            }
            break;
        }
        
        case OBJ_TYPE_ARRAY: {
            JavaArray* array = (JavaArray*)ptr;
            
            if (array->element_type == DESC_OBJECT || array->element_type == DESC_ARRAY) {
                /* Reference array - mark all elements */
                void** refs = (void**)array_data_ptr(array);
                for (jsize i = 0; i < array->length; i++) {
                    void* ref = refs[i];
                    if (ref && is_heap_ptr(ref)) {
                        gc_push_mark(ref);
                    }
                }
            }
            break;
        }
        
        case OBJ_TYPE_STRING: {
            /* String chars are embedded in the string object, no need to mark separately */
            /* But utf8 cache is malloc'd, we need to free it if object is collected */
            break;
        }
        
        case OBJ_TYPE_CLASS:
            /* Class objects - mark static reference fields */
            if (header->clazz && header->clazz->static_fields) {
                JavaClass* clazz = header->clazz;
                for (int i = 0; i < clazz->static_fields_count; i++) {
                    JavaStaticField* sf = &clazz->static_fields[i];
                    if (sf->descriptor && (sf->descriptor[0] == 'L' || sf->descriptor[0] == '[')) {
                        if (sf->value.ref && is_heap_ptr(sf->value.ref)) {
                            gc_push_mark(sf->value.ref);
                        }
                    }
                }
            }
            break;
    }
}

/* Process mark stack iteratively */
static void gc_process_mark_stack(void) {
    while (gc_mark_stack_top > 0) {
        gc_mark_stack_top--;
        MarkStackEntry entry = gc_mark_stack[gc_mark_stack_top];
        gc_mark_object(entry.ptr);
    }
}

/* Run garbage collection */
void gc_collect(JVM* jvm) {
    if (!jvm) return;
    
    size_t start_allocated = heap.allocated;
    
    /* Reset mark stack */
    gc_mark_stack_top = 0;
    
    /* Mark phase */
    
    /* Mark from roots */
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] && *heap.roots[i]) {
            if (is_heap_ptr(*heap.roots[i])) {
                gc_push_mark(*heap.roots[i]);
            }
        }
    }
    
    /* Mark from thread stacks */
    for (int i = 0; i < jvm->thread_count; i++) {
        JavaThread* thread = jvm->threads[i];
        if (!thread) continue;
        
        /* Mark pending exception */
        if (thread->pending_exception && is_heap_ptr(thread->pending_exception)) {
            gc_push_mark(thread->pending_exception);
        }
        
        /* Mark thread object */
        if (thread->thread_object && is_heap_ptr(thread->thread_object)) {
            gc_push_mark(thread->thread_object);
        }
        
        /* Mark stack frames */
        JavaFrame* frame = thread->current_frame;
        while (frame) {
            /* Mark local variables */
            for (uint16_t j = 0; j < frame->max_locals; j++) {
                void* ref = frame->locals[j].ref;
                if (ref && is_heap_ptr(ref)) {
                    gc_push_mark(ref);
                }
            }
            
            /* Mark operand stack */
            for (int16_t j = 0; j <= frame->stack_top; j++) {
                void* ref = frame->stack[j].ref;
                if (ref && is_heap_ptr(ref)) {
                    gc_push_mark(ref);
                }
            }
            
            frame = frame->prev;
        }
    }
    
    /* Mark from loaded classes' static fields */
    for (size_t i = 0; i < jvm->class_loader.count; i++) {
        JavaClass* clazz = jvm->class_loader.classes[i];
        if (!clazz || !clazz->static_fields) continue;
        
        for (int j = 0; j < clazz->static_fields_count; j++) {
            JavaStaticField* sf = &clazz->static_fields[j];
            if (sf->descriptor && (sf->descriptor[0] == 'L' || sf->descriptor[0] == '[')) {
                if (sf->value.ref && is_heap_ptr(sf->value.ref)) {
                    gc_push_mark(sf->value.ref);
                }
            }
        }
    }
    
    /* Process mark stack */
    gc_process_mark_stack();
    
    /* Sweep phase */
    size_t freed_this_cycle = 0;
    size_t objects_freed = 0;
    
    GCObjectHeader** pp = &heap.objects;
    while (*pp) {
        GCObjectHeader* obj = *pp;
        
        if (!obj->marked && !obj->pinned) {
            /* Free object */
            *pp = obj->next;
            
            freed_this_cycle += obj->size;
            objects_freed++;
            heap.object_count--;
            
            /* Free malloc'd data for strings */
            if (obj->type == OBJ_TYPE_STRING) {
                JavaString* str = (JavaString*)(obj + 1);
                if (str->utf8) {
                    free(str->utf8);
                    str->utf8 = NULL;
                }
            }
            
            /* Add to free list */
            FreeBlock* block = (FreeBlock*)obj;
            block->size = obj->size;
            block->next = heap.free_list;
            heap.free_list = block;
        } else {
            /* Clear mark for next collection */
            obj->marked = 0;
            pp = &obj->next;
        }
    }
    
    heap.allocated -= freed_this_cycle;
    heap.freed += freed_this_cycle;
    heap.gc_cycles++;
    heap.gc_total_freed += freed_this_cycle;
    
    if (freed_this_cycle > 0) {
        fprintf(stderr, "[GC] Cycle %zu: freed %zu bytes (%zu objects), %zu bytes allocated\n",
                heap.gc_cycles, freed_this_cycle, objects_freed, heap.allocated);
    }
}

/* Add GC root */
void gc_add_root(JVM* jvm, void** root) {
    (void)jvm;
    
    if (heap.root_count >= heap.root_capacity) {
        heap.root_capacity *= 2;
        heap.roots = (void***)realloc(heap.roots, heap.root_capacity * sizeof(void**));
    }
    
    heap.roots[heap.root_count++] = root;
}

/* Remove GC root */
void gc_remove_root(JVM* jvm, void** root) {
    (void)jvm;
    
    for (size_t i = 0; i < heap.root_count; i++) {
        if (heap.roots[i] == root) {
            heap.roots[i] = heap.roots[--heap.root_count];
            return;
        }
    }
}

/* Pin object */
void gc_pin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object || !is_heap_ptr(object)) return;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 1;
}

/* Unpin object */
void gc_unpin(JVM* jvm, void* object) {
    (void)jvm;
    if (!object || !is_heap_ptr(object)) return;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    header->pinned = 0;
}

/* Get heap statistics */
HeapStats heap_get_stats(JVM* jvm) {
    HeapStats stats = {0};
    (void)jvm;
    
    stats.total_size = heap.size;
    stats.used_size = heap.allocated;
    stats.free_size = heap.size - heap.allocated;
    stats.object_count = heap.object_count;
    stats.gc_cycles = heap.gc_cycles;
    stats.gc_time_ms = 0;  /* Not tracked */
    
    return stats;
}

/* Get object class */
JavaClass* object_get_class(void* object) {
    if (!object || !is_heap_ptr(object)) return NULL;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->clazz;
}

/* Get object size */
size_t object_get_size(void* object) {
    if (!object || !is_heap_ptr(object)) return 0;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->size;
}

/* Get object hash code */
jint object_hash_code(void* object) {
    if (!object) return 0;
    
    JavaObject* obj = (JavaObject*)object;
    return obj->header.hashcode;
}

/* Check if object is an array */
bool object_is_array(void* object) {
    if (!object || !is_heap_ptr(object)) return false;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_ARRAY;
}

/* Check if object is a string */
bool object_is_string(void* object) {
    if (!object || !is_heap_ptr(object)) return false;
    
    GCObjectHeader* header = (GCObjectHeader*)object - 1;
    return header->type == OBJ_TYPE_STRING;
}

/* Check if object is instance of class */
bool object_instance_of(void* object, JavaClass* clazz) {
    if (!object || !clazz) return false;
    
    JavaClass* obj_class = object_get_class(object);
    if (!obj_class) return false;
    
    /* Check class hierarchy */
    while (obj_class) {
        if (obj_class == clazz) return true;
        
        /* Check interfaces */
        for (int i = 0; i < obj_class->interfaces_count; i++) {
            const char* iface_name = classfile_get_class_name(obj_class, obj_class->interfaces[i]);
            if (iface_name && clazz->class_name && strcmp(iface_name, clazz->class_name) == 0) {
                return true;
            }
        }
        
        obj_class = obj_class->super_class;
    }
    
    return false;
}

/* Get array length */
jsize array_length(JavaArray* array) {
    return array ? array->length : 0;
}

/* Get array element type */
uint8_t array_element_type(JavaArray* array) {
    return array ? array->element_type : 0;
}

/* Get array element */
JavaValue array_get(JavaArray* array, jsize index) {
    JavaValue v = { .raw = 0 };
    
    if (!array || index < 0 || index >= array->length) {
        return v;
    }
    
    void* data = array_data_ptr(array);
    
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:
            v.i = ((uint8_t*)data)[index];
            break;
        case T_CHAR:
            v.i = ((jchar*)data)[index];
            break;
        case T_SHORT:
            v.i = ((jshort*)data)[index];
            break;
        case T_INT:
            v.i = ((jint*)data)[index];
            break;
        case T_LONG:
            v.j = ((jlong*)data)[index];
            break;
        case T_FLOAT:
            v.f = ((jfloat*)data)[index];
            break;
        case T_DOUBLE:
            v.d = ((jdouble*)data)[index];
            break;
        case DESC_OBJECT:
        case DESC_ARRAY:
            v.ref = ((void**)data)[index];
            break;
    }
    
    return v;
}

/* Set array element */
void array_set(JavaArray* array, jsize index, JavaValue value) {
    if (!array || index < 0 || index >= array->length) {
        return;
    }
    
    void* data = array_data_ptr(array);
    
    switch (array->element_type) {
        case T_BOOLEAN:
        case T_BYTE:
            ((uint8_t*)data)[index] = (uint8_t)value.i;
            break;
        case T_CHAR:
            ((jchar*)data)[index] = (jchar)value.i;
            break;
        case T_SHORT:
            ((jshort*)data)[index] = (jshort)value.i;
            break;
        case T_INT:
            ((jint*)data)[index] = value.i;
            break;
        case T_LONG:
            ((jlong*)data)[index] = value.j;
            break;
        case T_FLOAT:
            ((jfloat*)data)[index] = value.f;
            break;
        case T_DOUBLE:
            ((jdouble*)data)[index] = value.d;
            break;
        case DESC_OBJECT:
        case DESC_ARRAY:
            ((void**)data)[index] = value.ref;
            break;
    }
}

/* Get reference from object array */
void* array_get_ref(JavaArray* array, jsize index) {
    if (!array || index < 0 || index >= array->length) return NULL;
    void* data = array_data_ptr(array);
    return ((void**)data)[index];
}

/* Set reference in object array */
void array_set_ref(JavaArray* array, jsize index, void* ref) {
    if (!array || index < 0 || index >= array->length) return;
    void* data = array_data_ptr(array);
    ((void**)data)[index] = ref;
}

/* Get string length */
jsize string_length(JavaString* str) {
    return str ? str->length : 0;
}

/* Get string characters - inline after structure */
const jchar* string_chars(JavaString* str) {
    if (!str) return NULL;
    return (const jchar*)((uint8_t*)str + sizeof(JavaString));
}

/* Get string as UTF-8 */
const char* string_utf8(JVM* jvm, JavaString* str) {
    (void)jvm;
    if (!str) return NULL;
    if (str->utf8) return str->utf8;
    
    const jchar* chars = string_chars(str);
    
    /* Convert UTF-16 to UTF-8 */
    char* result = (char*)malloc(str->length * 3 + 1);
    if (!result) return NULL;
    
    char* p = result;
    for (jsize i = 0; i < str->length; i++) {
        jchar c = chars[i];
        if (c < 0x80) {
            *p++ = (char)c;
        } else if (c < 0x800) {
            *p++ = (char)(0xC0 | (c >> 6));
            *p++ = (char)(0x80 | (c & 0x3F));
        } else {
            *p++ = (char)(0xE0 | (c >> 12));
            *p++ = (char)(0x80 | ((c >> 6) & 0x3F));
            *p++ = (char)(0x80 | (c & 0x3F));
        }
    }
    *p = '\0';
    
    str->utf8 = result;
    return result;
}

/* Compare strings */
bool string_equals(JavaString* a, JavaString* b) {
    if (a == b) return true;
    if (!a || !b) return false;
    if (a->length != b->length) return false;
    
    const jchar* chars_a = string_chars(a);
    const jchar* chars_b = string_chars(b);
    
    return memcmp(chars_a, chars_b, a->length * sizeof(jchar)) == 0;
}

/* String hash code */
jint string_hash(JavaString* str) {
    if (!str) return 0;
    if (str->hash) return str->hash;
    
    const jchar* chars = string_chars(str);
    
    jint hash = 0;
    for (jsize i = 0; i < str->length; i++) {
        hash = 31 * hash + chars[i];
    }
    
    str->hash = hash;
    return hash;
}

/* Dump heap */
void heap_dump(JVM* jvm) {
    if (!jvm) return;
    
    printf("=== Heap Dump ===\n");
    printf("Total: %zu bytes\n", heap.size);
    printf("Used: %zu bytes\n", heap.allocated);
    printf("Freed: %zu bytes total\n", heap.freed);
    printf("Objects: %zu\n", heap.object_count);
    printf("GC cycles: %zu\n", heap.gc_cycles);
    
    GCObjectHeader* obj = heap.objects;
    int count = 0;
    while (obj && count < 100) {
        const char* class_name = "(null)";
        if (obj->clazz && obj->clazz->class_name) {
            class_name = obj->clazz->class_name;
        } else if (obj->type == OBJ_TYPE_ARRAY) {
            class_name = "(array)";
        } else if (obj->type == OBJ_TYPE_STRING) {
            class_name = "(string)";
        }
        printf("Object @ %p: size=%u, type=%d, class=%s, marked=%d\n",
               (void*)(obj + 1), obj->size, obj->type, class_name, obj->marked);
        obj = obj->next;
        count++;
    }
    if (obj) {
        printf("... (more objects)\n");
    }
}

/* Validate heap integrity */
void heap_validate(JVM* jvm) {
    (void)jvm;
    
    size_t computed_allocated = 0;
    size_t computed_count = 0;
    
    GCObjectHeader* obj = heap.objects;
    while (obj) {
        computed_allocated += obj->size;
        computed_count++;
        
        /* Check for corruption */
        if (obj->size == 0 || obj->size > heap.size) {
            fprintf(stderr, "[GC] ERROR: Corrupted object header at %p\n", (void*)obj);
            break;
        }
        
        obj = obj->next;
    }
    
    if (computed_count != heap.object_count) {
        fprintf(stderr, "[GC] ERROR: Object count mismatch: %zu vs %zu\n",
                computed_count, heap.object_count);
    }
}
