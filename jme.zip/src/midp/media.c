/*
 * J2ME Emulator - Media API Implementation
 * javax.microedition.media native methods
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "jvm.h"
#include "native.h"
#include "midi.h"
#include "heap.h"

/* Forward declarations from SDL audio */
extern int sdl_audio_init_simple(uint32_t sample_rate);
extern void sdl_audio_shutdown(void);

/* Active players */
#define MAX_PLAYERS 16

typedef struct {
    MidiFile* midi;
    int id;
    bool playing;
    char* content_type;
    uint8_t* data;
    uint32_t size;
} MediaPlayer;

static MediaPlayer g_players[MAX_PLAYERS];
static int g_next_player_id = 1;
static bool g_audio_initialized = false;

/* Initialize audio if needed */
static void ensure_audio_init(void) {
    if (!g_audio_initialized) {
        sdl_audio_init_simple(44100);
        midi_init(44100);
        g_audio_initialized = true;
    }
}

/* Find free player slot */
static int find_free_player_slot(void) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].midi == NULL) {
            return i;
        }
    }
    return -1;
}

/* Find player by object */
static MediaPlayer* find_player(JavaObject* obj) {
    if (!obj) return NULL;
    int id = obj->fields[0].i;  /* player_id field */
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].id == id) {
            return &g_players[i];
        }
    }
    return NULL;
}

/* ============================================
 * Manager native methods
 * ============================================ */

/* Manager.createPlayer(String locator) */
static JavaValue native_manager_createPlayer_locator(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaString* locator_str = (JavaString*)args[0].ref;
    
    ensure_audio_init();
    
    /* For now, only support device://midi */
    /* TODO: Handle other locators */
    
    const char* locator_cstr = NULL;
    if (locator_str) {
        locator_cstr = string_utf8(jvm, locator_str);
    }
    
    fprintf(stderr, "[Media] Manager.createPlayer: locator=%s\n", 
            locator_cstr ? locator_cstr : "(null)");
    
    /* Return null - we don't support locator-based players yet */
    return NATIVE_RETURN_NULL();
}

/* Manager.createPlayer(InputStream stream, String type) */
static JavaValue native_manager_createPlayer_stream(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* stream = (JavaObject*)args[0].ref;
    JavaString* type_str = (JavaString*)args[1].ref;
    
    ensure_audio_init();
    
    const char* type_cstr = NULL;
    if (type_str) {
        type_cstr = string_utf8(jvm, type_str);
    }
    
    fprintf(stderr, "[Media] Manager.createPlayer: stream=%p, type=%s\n",
            (void*)stream, type_cstr ? type_cstr : "(null)");
    
    /* TODO: Read from stream */
    return NATIVE_RETURN_NULL();
}

/* Manager.playTone(int note, int duration, int volume) */
static JavaValue native_manager_playTone(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint note = args[0].i;
    jint duration = args[1].i;
    jint volume = args[2].i;
    
    ensure_audio_init();
    
    fprintf(stderr, "[Media] Manager.playTone: note=%d, duration=%d, volume=%d\n",
            note, duration, volume);
    
    /* Play a single tone using MIDI synthesizer */
    midi_note_on(0, note, (volume * 127) / 100);
    
    /* TODO: Actually wait for duration and turn off */
    
    return NATIVE_RETURN_VOID();
}

/* ============================================
 * Player native methods
 * ============================================ */

/* Player.realize() */
static JavaValue native_player_realize(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        fprintf(stderr, "[Media] Player.realize: player not found\n");
        return NATIVE_RETURN_INT(-1);  /* Throw exception */
    }
    
    fprintf(stderr, "[Media] Player.realize: id=%d\n", player->id);
    
    return NATIVE_RETURN_VOID();
}

/* Player.prefetch() */
static JavaValue native_player_prefetch(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_INT(-1);
    }
    
    fprintf(stderr, "[Media] Player.prefetch: id=%d\n", player->id);
    
    return NATIVE_RETURN_VOID();
}

/* Player.start() */
static JavaValue native_player_start(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->midi) {
        fprintf(stderr, "[Media] Player.start: player not found or no MIDI\n");
        return NATIVE_RETURN_INT(-1);
    }
    
    fprintf(stderr, "[Media] Player.start: id=%d\n", player->id);
    
    midi_play(player->midi);
    player->playing = true;
    
    return NATIVE_RETURN_VOID();
}

/* Player.stop() */
static JavaValue native_player_stop(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->midi) {
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Media] Player.stop: id=%d\n", player->id);
    
    midi_stop(player->midi);
    player->playing = false;
    
    return NATIVE_RETURN_VOID();
}

/* Player.deallocate() */
static JavaValue native_player_deallocate(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Media] Player.deallocate: id=%d\n", player->id);
    
    if (player->midi) {
        midi_stop(player->midi);
        midi_free(player->midi);
        player->midi = NULL;
    }
    player->playing = false;
    
    return NATIVE_RETURN_VOID();
}

/* Player.close() */
static JavaValue native_player_close(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Media] Player.close: id=%d\n", player->id);
    
    if (player->midi) {
        midi_stop(player->midi);
        midi_free(player->midi);
        player->midi = NULL;
    }
    
    if (player->data) {
        free(player->data);
        player->data = NULL;
    }
    
    if (player->content_type) {
        free(player->content_type);
        player->content_type = NULL;
    }
    
    player->id = 0;
    player->playing = false;
    
    return NATIVE_RETURN_VOID();
}

/* Player.setLoopCount(int count) */
static JavaValue native_player_setLoopCount(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    jint count = args[1].i;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->midi) {
        return NATIVE_RETURN_VOID();
    }
    
    fprintf(stderr, "[Media] Player.setLoopCount: id=%d, count=%d\n", player->id, count);
    
    midi_set_loop(player->midi, count != 1);
    
    return NATIVE_RETURN_VOID();
}

/* Player.getDuration() */
static JavaValue native_player_getDuration(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->midi) {
        return NATIVE_RETURN_INT(-1);  /* TIME_UNKNOWN */
    }
    
    /* Return duration in microseconds */
    float duration = midi_get_length(player->midi);
    return NATIVE_RETURN_INT((int)(duration * 1000000));
}

/* Player.getMediaTime() */
static JavaValue native_player_getMediaTime(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->midi) {
        return NATIVE_RETURN_INT(0);
    }
    
    float pos = midi_get_position(player->midi);
    return NATIVE_RETURN_INT((int)(pos * 1000000));
}

/* Player.getState() */
static JavaValue native_player_getState(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player) {
        return NATIVE_RETURN_INT(0);  /* UNREALIZED */
    }
    
    if (player->playing) {
        return NATIVE_RETURN_INT(400);  /* STARTED */
    }
    if (player->midi) {
        return NATIVE_RETURN_INT(300);  /* PREFETCHED */
    }
    return NATIVE_RETURN_INT(200);  /* REALIZED */
}

/* Player.getContentType() */
static JavaValue native_player_getContentType(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* player_obj = (JavaObject*)args[0].ref;
    
    MediaPlayer* player = find_player(player_obj);
    if (!player || !player->content_type) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaString* str = jvm_new_string(jvm, player->content_type);
    return NATIVE_RETURN_OBJECT(str);
}

/* ============================================
 * VolumeControl native methods
 * ============================================ */

/* VolumeControl.setLevel(int level) */
static JavaValue native_volumecontrol_setLevel(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* control_obj = (JavaObject*)args[0].ref;
    jint level = args[1].i;
    
    if (level < 0) level = 0;
    if (level > 100) level = 100;
    
    /* Find associated player */
    int player_id = control_obj->fields[1].i;  /* player_id field */
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].id == player_id && g_players[i].midi) {
            midi_set_volume(g_players[i].midi, level / 100.0f);
            break;
        }
    }
    
    fprintf(stderr, "[Media] VolumeControl.setLevel: %d\n", level);
    
    return NATIVE_RETURN_VOID();
}

/* VolumeControl.getLevel() */
static JavaValue native_volumecontrol_getLevel(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* control_obj = (JavaObject*)args[0].ref;
    
    /* TODO: Track volume per player */
    return NATIVE_RETURN_INT(100);
}

/* ============================================
 * MIDIControl native methods
 * ============================================ */

/* MIDIControl.shortMidiEvent(int type, int data1, int data2) */
static JavaValue native_midicontrol_shortMidiEvent(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint type = args[0].i;
    jint data1 = args[1].i;
    jint data2 = args[2].i;
    
    uint8_t status = (uint8_t)type;
    uint8_t channel = status & 0x0F;
    uint8_t event = status & 0xF0;
    
    switch (event) {
        case 0x80:  /* Note Off */
            midi_note_off(channel, data1);
            break;
        case 0x90:  /* Note On */
            midi_note_on(channel, data1, data2);
            break;
        case 0xB0:  /* Control Change */
            midi_control_change(channel, data1, data2);
            break;
        case 0xC0:  /* Program Change */
            midi_program_change(channel, data1);
            break;
        case 0xE0:  /* Pitch Bend */
            midi_pitch_bend(channel, (data2 << 7) | data1);
            break;
    }
    
    return NATIVE_RETURN_VOID();
}

/* MIDIControl.longMidiEvent(byte[] data, int offset, int length) */
static JavaValue native_midicontrol_longMidiEvent(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaArray* data_arr = (JavaArray*)args[0].ref;
    jint offset = args[1].i;
    jint length = args[2].i;
    
    if (!data_arr) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* TODO: Process SysEx message */
    fprintf(stderr, "[Media] MIDIControl.longMidiEvent: offset=%d, length=%d\n", offset, length);
    
    return NATIVE_RETURN_INT(length);
}

/* ============================================
 * Internal: Create player from data
 * ============================================ */

int media_create_player_from_data(const uint8_t* data, uint32_t size, const char* type) {
    ensure_audio_init();
    
    int slot = find_free_player_slot();
    if (slot < 0) return -1;
    
    /* Check content type */
    bool is_midi = false;
    if (type) {
        if (strcmp(type, "audio/midi") == 0 ||
            strcmp(type, "audio/mid") == 0 ||
            strcmp(type, "audio/x-midi") == 0) {
            is_midi = true;
        }
    }
    
    /* Also check for MIDI header */
    if (!is_midi && size >= 4) {
        if (memcmp(data, "MThd", 4) == 0) {
            is_midi = true;
        }
    }
    
    if (!is_midi) {
        fprintf(stderr, "[Media] Unsupported content type: %s\n", type ? type : "unknown");
        return -1;
    }
    
    /* Load MIDI file */
    MidiFile* midi = midi_load(data, size);
    if (!midi) {
        fprintf(stderr, "[Media] Failed to load MIDI file\n");
        return -1;
    }
    
    /* Store player */
    g_players[slot].id = g_next_player_id++;
    g_players[slot].midi = midi;
    g_players[slot].playing = false;
    g_players[slot].content_type = strdup(type ? type : "audio/midi");
    g_players[slot].data = (uint8_t*)malloc(size);
    if (g_players[slot].data) {
        memcpy(g_players[slot].data, data, size);
    }
    g_players[slot].size = size;
    
    fprintf(stderr, "[Media] Created player id=%d\n", g_players[slot].id);
    
    return g_players[slot].id;
}

/* Get MIDI file for audio generation */
MidiFile* media_get_midi_for_audio(void) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (g_players[i].playing && g_players[i].midi) {
            return g_players[i].midi;
        }
    }
    return NULL;
}

/* ============================================
 * Initialize media native methods
 * ============================================ */

void init_javax_microedition_media(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Manager */
        {"javax/microedition/media/Manager", "createPlayer", 
         "(Ljava/lang/String;)Ljavax/microedition/media/Player;", 
         native_manager_createPlayer_locator},
        {"javax/microedition/media/Manager", "createPlayer",
         "(Ljava/io/InputStream;Ljava/lang/String;)Ljavax/microedition/media/Player;",
         native_manager_createPlayer_stream},
        {"javax/microedition/media/Manager", "playTone",
         "(III)V",
         native_manager_playTone},
        
        /* Player */
        {"javax/microedition/media/Player", "realize", "()V", native_player_realize},
        {"javax/microedition/media/Player", "prefetch", "()V", native_player_prefetch},
        {"javax/microedition/media/Player", "start", "()V", native_player_start},
        {"javax/microedition/media/Player", "stop", "()V", native_player_stop},
        {"javax/microedition/media/Player", "deallocate", "()V", native_player_deallocate},
        {"javax/microedition/media/Player", "close", "()V", native_player_close},
        {"javax/microedition/media/Player", "setLoopCount", "(I)V", native_player_setLoopCount},
        {"javax/microedition/media/Player", "getDuration", "()J", native_player_getDuration},
        {"javax/microedition/media/Player", "getMediaTime", "()J", native_player_getMediaTime},
        {"javax/microedition/media/Player", "getState", "()I", native_player_getState},
        {"javax/microedition/media/Player", "getContentType", "()Ljava/lang/String;", native_player_getContentType},
        
        /* VolumeControl */
        {"javax/microedition/media/control/VolumeControl", "setLevel", "(I)V", native_volumecontrol_setLevel},
        {"javax/microedition/media/control/VolumeControl", "getLevel", "()I", native_volumecontrol_getLevel},
        
        /* MIDIControl */
        {"javax/microedition/media/control/MIDIControl", "shortMidiEvent", "(III)V", native_midicontrol_shortMidiEvent},
        {"javax/microedition/media/control/MIDIControl", "longMidiEvent", "([BII)I", native_midicontrol_longMidiEvent},
    };
    
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    fprintf(stderr, "[Media] Registered %zu media native methods\n", 
            sizeof(methods) / sizeof(methods[0]));
}
