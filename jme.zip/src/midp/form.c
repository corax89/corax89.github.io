/*
 * J2ME Emulator - Form and UI Components
 * MIDP2 high-level UI implementation
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "midp.h"
#include "jvm.h"
#include "native.h"
#include "sdl_backend.h"
#include "threads.h"
#include "opcodes.h"  /* For T_BOOLEAN, DESC_OBJECT */

/* Forward declaration */
extern int execute_method(JVM* jvm, JavaThread* thread, JavaMethod* method, JavaValue* args, JavaValue* result);
extern MidpGraphics* get_graphics_from_object(JavaObject* obj);

/* Current form state */
static JavaObject* g_current_form = NULL;
static int g_focused_item_index = 0;
static char g_textfield_buffer[256] = {0};
static int g_textfield_cursor = 0;

/* Item types */
#define ITEM_STRINGITEM   1
#define ITEM_TEXTFIELD    2
#define ITEM_IMAGEITEM    3
#define ITEM_CHOICEGROUP  4
#define ITEM_GAUGE        5
#define ITEM_SPACER       6
#define ITEM_DATEFIELD    7

/* Choice constants */
#define CHOICE_EXCLUSIVE  1
#define CHOICE_MULTIPLE   2
#define CHOICE_POPUP      3
#define CHOICE_IMPLICIT   4

/* TextField constraints */
#define TEXTFIELD_ANY        0
#define TEXTFIELD_EMAILADDR  1
#define TEXTFIELD_NUMERIC    2
#define TEXTFIELD_PHONENUMBER 3
#define TEXTFIELD_URL        4
#define TEXTFIELD_DECIMAL    5
#define TEXTFIELD_PASSWORD   0x10000

/* Get MidpGraphics for screen */
static MidpGraphics* get_screen_graphics(void) {
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (!sdl_ctx || !sdl_ctx->framebuffer) return NULL;
    
    static MidpGraphics gfx;
    midp_graphics_init(&gfx, sdl_ctx->framebuffer, sdl_ctx->width, sdl_ctx->height);
    return &gfx;
}

/* Get item type from object */
static int get_item_type(JavaObject* item) {
    if (!item || !item->header.clazz) return 0;
    
    const char* class_name = item->header.clazz->class_name;
    if (!class_name) return 0;
    
    if (strstr(class_name, "StringItem")) return ITEM_STRINGITEM;
    if (strstr(class_name, "TextField")) return ITEM_TEXTFIELD;
    if (strstr(class_name, "ImageItem")) return ITEM_IMAGEITEM;
    if (strstr(class_name, "ChoiceGroup")) return ITEM_CHOICEGROUP;
    if (strstr(class_name, "Gauge")) return ITEM_GAUGE;
    if (strstr(class_name, "Spacer")) return ITEM_SPACER;
    if (strstr(class_name, "DateField")) return ITEM_DATEFIELD;
    
    return 0;
}

/* Get string from Java String object */
static const char* get_string_from_object(JVM* jvm, JavaObject* str_obj) {
    if (!str_obj) return "";
    
    JavaString* str = (JavaString*)str_obj;
    if (str->utf8) return str->utf8;
    
    /* Convert from UTF-16 */
    if (str->chars && str->length > 0) {
        str->utf8 = (char*)malloc(str->length * 3 + 1);
        if (str->utf8) {
            for (int i = 0; i < str->length; i++) {
                jchar c = str->chars[i];
                if (c < 0x80) {
                    str->utf8[i] = (char)c;
                } else {
                    /* Simple UTF-8 encoding */
                    str->utf8[i] = '?';
                }
            }
            str->utf8[str->length] = '\0';
        }
        return str->utf8 ? str->utf8 : "";
    }
    
    return "";
}

/* Render StringItem */
static int render_stringitem(JVM* jvm, MidpGraphics* gfx, JavaObject* item, int y) {
    /* StringItem has: text (String), label (String), appearanceMode (int) */
    const char* label = "";
    const char* text = "";
    
    /* Try to get label (field 0) and text (field 1) */
    if (item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        JavaString* label_str = (JavaString*)item->fields[0].ref;
        JavaString* text_str = (JavaString*)item->fields[1].ref;
        
        if (label_str) label = get_string_from_object(jvm, (JavaObject*)label_str);
        if (text_str) text = get_string_from_object(jvm, (JavaObject*)text_str);
    }
    
    int font_height = 12; /* Default font height */
    MidpFont* font = midp_font_get_default();
    if (font) font_height = midp_font_height(font);
    
    /* Draw label */
    if (label && *label) {
        midp_graphics_set_color(gfx, 0x0000FF, 255); /* Blue for labels */
        midp_graphics_draw_string(gfx, label, 5, y, 0);
        y += font_height + 2;
    }
    
    /* Draw text */
    if (text && *text) {
        midp_graphics_set_color(gfx, 0x000000, 255); /* Black for text */
        midp_graphics_draw_string(gfx, text, 5, y, 0);
        y += font_height + 4;
    }
    
    return y;
}

/* Render TextField */
static int render_textfield(JVM* jvm, MidpGraphics* gfx, JavaObject* item, int y, bool focused) {
    const char* label = "";
    const char* text = "";
    int max_size = 32;
    int constraints = 0;
    
    /* TextField fields: label, text, maxSize, constraints */
    if (item->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaString* label_str = (JavaString*)item->fields[0].ref;
        JavaString* text_str = (JavaString*)item->fields[1].ref;
        
        if (label_str) label = get_string_from_object(jvm, (JavaObject*)label_str);
        if (text_str) text = get_string_from_object(jvm, (JavaObject*)text_str);
        
        max_size = item->fields[2].i;
        constraints = item->fields[3].i;
    }
    
    int font_height = 12;
    MidpFont* font = midp_font_get_default();
    if (font) font_height = midp_font_height(font);
    
    int box_height = font_height + 8;
    
    /* Draw label */
    if (label && *label) {
        midp_graphics_set_color(gfx, 0x0000FF, 255);
        midp_graphics_draw_string(gfx, label, 5, y, 0);
        y += font_height + 2;
    }
    
    /* Draw text box */
    int box_y = y;
    midp_graphics_set_color(gfx, 0xFFFFFF, 255); /* White background */
    midp_graphics_fill_rect(gfx, 5, box_y, 230, box_height);
    midp_graphics_set_color(gfx, focused ? 0x0000FF : 0x808080, 255); /* Border */
    midp_graphics_draw_rect(gfx, 5, box_y, 230, box_height);
    
    /* Draw text content */
    midp_graphics_set_color(gfx, 0x000000, 255);
    if (constraints & TEXTFIELD_PASSWORD) {
        /* Draw asterisks for password */
        int len = text ? strlen(text) : 0;
        char* stars = (char*)malloc(len + 1);
        if (stars) {
            memset(stars, '*', len);
            stars[len] = '\0';
            midp_graphics_draw_string(gfx, stars, 8, box_y + 3, 0);
            free(stars);
        }
    } else {
        if (text && *text) {
            midp_graphics_draw_string(gfx, text, 8, box_y + 3, 0);
        }
    }
    
    /* Draw cursor if focused */
    if (focused) {
        int cursor_x = 8;
        if (text) {
            cursor_x += midp_font_string_width(font, text);
        }
        midp_graphics_set_color(gfx, 0x000000, 255);
        midp_graphics_draw_line(gfx, cursor_x, box_y + 2, cursor_x, box_y + box_height - 2);
    }
    
    return y + box_height + 6;
}

/* Render ChoiceGroup */
static int render_choicegroup(JVM* jvm, MidpGraphics* gfx, JavaObject* item, int y, bool focused) {
    const char* label = "";
    int choice_type = CHOICE_EXCLUSIVE;
    int num_choices = 0;
    JavaArray* strings = NULL;
    JavaArray* selected = NULL;
    
    /* ChoiceGroup fields: label, choiceType, strings[], selected[] */
    if (item->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaString* label_str = (JavaString*)item->fields[0].ref;
        if (label_str) label = get_string_from_object(jvm, (JavaObject*)label_str);
        
        choice_type = item->fields[1].i;
        strings = (JavaArray*)item->fields[2].ref;
        selected = (JavaArray*)item->fields[3].ref;
    }
    
    int font_height = 12;
    MidpFont* font = midp_font_get_default();
    if (font) font_height = midp_font_height(font);
    
    /* Draw label */
    if (label && *label) {
        midp_graphics_set_color(gfx, 0x0000FF, 255);
        midp_graphics_draw_string(gfx, label, 5, y, 0);
        y += font_height + 4;
    }
    
    /* Draw choices */
    if (strings && strings->element_type == DESC_OBJECT) {
        num_choices = strings->length;
        
        for (int i = 0; i < num_choices; i++) {
            JavaString* choice_str = (JavaString*)strings->data.refs[i];
            const char* choice_text = choice_str ? get_string_from_object(jvm, (JavaObject*)choice_str) : "";
            bool is_selected = false;
            
            if (selected && selected->element_type == T_BOOLEAN) {
                is_selected = selected->data.booleans[i] != 0;
            }
            
            int check_x = 10;
            int check_y = y + font_height / 2;
            
            /* Draw checkbox/radio */
            midp_graphics_set_color(gfx, 0x000000, 255);
            
            if (choice_type == CHOICE_EXCLUSIVE || choice_type == CHOICE_POPUP) {
                /* Radio button - circle */
                midp_graphics_draw_arc(gfx, check_x - 5, check_y - 5, 10, 10, 0, 360);
                if (is_selected) {
                    midp_graphics_set_color(gfx, 0x000000, 255);
                    midp_graphics_fill_arc(gfx, check_x - 3, check_y - 3, 6, 6, 0, 360);
                }
            } else {
                /* Checkbox - square */
                midp_graphics_draw_rect(gfx, check_x - 5, check_y - 5, 10, 10);
                if (is_selected) {
                    /* Draw X */
                    midp_graphics_draw_line(gfx, check_x - 3, check_y - 3, check_x + 3, check_y + 3);
                    midp_graphics_draw_line(gfx, check_x - 3, check_y + 3, check_x + 3, check_y - 3);
                }
            }
            
            /* Draw choice text */
            midp_graphics_set_color(gfx, 0x000000, 255);
            midp_graphics_draw_string(gfx, choice_text, check_x + 10, y, 0);
            
            y += font_height + 4;
        }
    }
    
    return y + 4;
}

/* Render Gauge */
static int render_gauge(JVM* jvm, MidpGraphics* gfx, JavaObject* item, int y, bool focused) {
    const char* label = "";
    int max_value = 100;
    int current_value = 0;
    bool interactive = false;
    
    /* Gauge fields: label, interactive, maxValue, value */
    if (item->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaString* label_str = (JavaString*)item->fields[0].ref;
        if (label_str) label = get_string_from_object(jvm, (JavaObject*)label_str);
        
        interactive = item->fields[1].i != 0;
        max_value = item->fields[2].i;
        current_value = item->fields[3].i;
    }
    
    int font_height = 12;
    MidpFont* font = midp_font_get_default();
    if (font) font_height = midp_font_height(font);
    
    /* Draw label */
    if (label && *label) {
        midp_graphics_set_color(gfx, 0x0000FF, 255);
        midp_graphics_draw_string(gfx, label, 5, y, 0);
        y += font_height + 4;
    }
    
    int bar_y = y;
    int bar_height = 20;
    int bar_width = 220;
    
    /* Draw bar background */
    midp_graphics_set_color(gfx, 0xC0C0C0, 255);
    midp_graphics_fill_rect(gfx, 10, bar_y, bar_width, bar_height);
    
    /* Draw filled portion */
    if (max_value > 0) {
        int fill_width = (current_value * bar_width) / max_value;
        midp_graphics_set_color(gfx, interactive ? 0x0000FF : 0x008000, 255);
        midp_graphics_fill_rect(gfx, 10, bar_y, fill_width, bar_height);
    }
    
    /* Draw border */
    midp_graphics_set_color(gfx, focused ? 0x0000FF : 0x000000, 255);
    midp_graphics_draw_rect(gfx, 10, bar_y, bar_width, bar_height);
    
    /* Draw value text */
    char val_text[32];
    snprintf(val_text, sizeof(val_text), "%d/%d", current_value, max_value);
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_string(gfx, val_text, 100, bar_y + 4, 0x10); /* HCENTER */
    
    return y + bar_height + 8;
}

/* Render Spacer */
static int render_spacer(JVM* jvm, MidpGraphics* gfx, JavaObject* item, int y) {
    int width = 0, height = 0;
    
    /* Spacer fields: width, height */
    if (item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        width = item->fields[0].i;
        height = item->fields[1].i;
    }
    
    if (height <= 0) height = 10;
    
    return y + height;
}

/* Render Alert */
static void render_alert(JVM* jvm, MidpGraphics* gfx, JavaObject* alert) {
    const char* title = "Alert";
    const char* text = "";
    int type = 0;
    
    /* Alert fields: title, text, type */
    if (alert->header.clazz->instance_size >= 3 * sizeof(JavaValue)) {
        JavaString* title_str = (JavaString*)alert->fields[0].ref;
        JavaString* text_str = (JavaString*)alert->fields[1].ref;
        
        if (title_str) title = get_string_from_object(jvm, (JavaObject*)title_str);
        if (text_str) text = get_string_from_object(jvm, (JavaObject*)text_str);
        
        type = alert->fields[2].i;
    }
    
    int screen_width = gfx->width;
    int screen_height = gfx->height;
    
    int box_width = screen_width - 20;
    int box_height = 100;
    int box_x = 10;
    int box_y = (screen_height - box_height) / 2;
    
    /* Draw background */
    midp_graphics_set_color(gfx, 0xFFFFCC, 255); /* Light yellow */
    midp_graphics_fill_rect(gfx, box_x, box_y, box_width, box_height);
    
    /* Draw border */
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_rect(gfx, box_x, box_y, box_width, box_height);
    
    /* Draw title */
    midp_graphics_set_color(gfx, 0x0000FF, 255);
    midp_graphics_draw_string(gfx, title, screen_width / 2, box_y + 5, 0x10); /* HCENTER | TOP */
    
    /* Draw text */
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_string(gfx, text, screen_width / 2, box_y + 30, 0x10);
    
    /* Draw OK button */
    int btn_width = 60;
    int btn_height = 25;
    int btn_x = (screen_width - btn_width) / 2;
    int btn_y = box_y + box_height - 35;
    
    midp_graphics_set_color(gfx, 0xC0C0C0, 255);
    midp_graphics_fill_rect(gfx, btn_x, btn_y, btn_width, btn_height);
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_rect(gfx, btn_x, btn_y, btn_width, btn_height);
    midp_graphics_draw_string(gfx, "OK", screen_width / 2, btn_y + 5, 0x10);
}

/* Render List */
static void render_list(JVM* jvm, MidpGraphics* gfx, JavaObject* list, int focused_index) {
    const char* title = "";
    int list_type = CHOICE_IMPLICIT;
    JavaArray* strings = NULL;
    JavaArray* selected = NULL;
    
    /* List fields: title, listType, strings[], selected[] */
    if (list->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaString* title_str = (JavaString*)list->fields[0].ref;
        if (title_str) title = get_string_from_object(jvm, (JavaObject*)title_str);
        
        list_type = list->fields[1].i;
        strings = (JavaArray*)list->fields[2].ref;
        selected = (JavaArray*)list->fields[3].ref;
    }
    
    int font_height = 12;
    MidpFont* font = midp_font_get_default();
    if (font) font_height = midp_font_height(font);
    
    int y = 30;
    
    /* Draw title */
    midp_graphics_set_color(gfx, 0x0000FF, 255);
    midp_graphics_draw_string(gfx, title, gfx->width / 2, 5, 0x10);
    
    /* Draw separator */
    midp_graphics_set_color(gfx, 0x808080, 255);
    midp_graphics_draw_line(gfx, 0, 25, gfx->width, 25);
    
    /* Draw items */
    if (strings && strings->element_type == DESC_OBJECT) {
        for (int i = 0; i < strings->length; i++) {
            JavaString* item_str = (JavaString*)strings->data.refs[i];
            const char* item_text = item_str ? get_string_from_object(jvm, (JavaObject*)item_str) : "";
            
            /* Highlight focused item */
            if (i == focused_index) {
                midp_graphics_set_color(gfx, 0x000080, 255);
                midp_graphics_fill_rect(gfx, 0, y - 2, gfx->width, font_height + 4);
                midp_graphics_set_color(gfx, 0xFFFFFF, 255);
            } else {
                midp_graphics_set_color(gfx, 0x000000, 255);
            }
            
            /* Draw selection indicator for EXCLUSIVE/MULTIPLE */
            int text_x = 5;
            if (list_type == CHOICE_EXCLUSIVE || list_type == CHOICE_MULTIPLE) {
                bool is_selected = false;
                if (selected && selected->element_type == T_BOOLEAN) {
                    is_selected = selected->data.booleans[i] != 0;
                }
                
                int check_x = 15;
                int check_y = y + font_height / 2;
                
                if (list_type == CHOICE_EXCLUSIVE) {
                    midp_graphics_draw_arc(gfx, check_x - 5, check_y - 5, 10, 10, 0, 360);
                    if (is_selected) {
                        midp_graphics_fill_arc(gfx, check_x - 3, check_y - 3, 6, 6, 0, 360);
                    }
                } else {
                    midp_graphics_draw_rect(gfx, check_x - 5, check_y - 5, 10, 10);
                    if (is_selected) {
                        midp_graphics_draw_line(gfx, check_x - 3, check_y - 3, check_x + 3, check_y + 3);
                        midp_graphics_draw_line(gfx, check_x - 3, check_y + 3, check_x + 3, check_y - 3);
                    }
                }
                text_x = 30;
            }
            
            midp_graphics_draw_string(gfx, item_text, text_x, y, 0);
            y += font_height + 6;
        }
    }
}

/* Render TextBox */
static void render_textbox(JVM* jvm, MidpGraphics* gfx, JavaObject* textbox, const char* input_text, int cursor_pos) {
    const char* title = "";
    int max_size = 32;
    int constraints = 0;
    
    /* TextBox fields: title, text, maxSize, constraints */
    if (textbox->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaString* title_str = (JavaString*)textbox->fields[0].ref;
        if (title_str) title = get_string_from_object(jvm, (JavaObject*)title_str);
        
        max_size = textbox->fields[2].i;
        constraints = textbox->fields[3].i;
    }
    
    int font_height = 12;
    MidpFont* font = midp_font_get_default();
    if (font) font_height = midp_font_height(font);
    
    /* Draw title bar */
    midp_graphics_set_color(gfx, 0x000080, 255);
    midp_graphics_fill_rect(gfx, 0, 0, gfx->width, 25);
    midp_graphics_set_color(gfx, 0xFFFFFF, 255);
    midp_graphics_draw_string(gfx, title, gfx->width / 2, 5, 0x10);
    
    /* Draw text area */
    int text_y = 30;
    int text_height = gfx->height - 80;
    
    midp_graphics_set_color(gfx, 0xFFFFFF, 255);
    midp_graphics_fill_rect(gfx, 5, text_y, gfx->width - 10, text_height);
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_rect(gfx, 5, text_y, gfx->width - 10, text_height);
    
    /* Draw text content */
    midp_graphics_set_color(gfx, 0x000000, 255);
    if (input_text && *input_text) {
        if (constraints & TEXTFIELD_PASSWORD) {
            int len = strlen(input_text);
            char* stars = (char*)malloc(len + 1);
            if (stars) {
                memset(stars, '*', len);
                stars[len] = '\0';
                midp_graphics_draw_string(gfx, stars, 10, text_y + 5, 0);
                free(stars);
            }
        } else {
            midp_graphics_draw_string(gfx, input_text, 10, text_y + 5, 0);
        }
    }
    
    /* Draw cursor */
    if (cursor_pos >= 0) {
        int cursor_x = 10;
        if (input_text && cursor_pos > 0) {
            char* temp = (char*)malloc(cursor_pos + 1);
            if (temp) {
                strncpy(temp, input_text, cursor_pos);
                temp[cursor_pos] = '\0';
                cursor_x += midp_font_string_width(font, temp);
                free(temp);
            }
        }
        midp_graphics_draw_line(gfx, cursor_x, text_y + 5, cursor_x, text_y + font_height + 5);
    }
    
    /* Draw soft buttons */
    int btn_height = 25;
    midp_graphics_set_color(gfx, 0xC0C0C0, 255);
    midp_graphics_fill_rect(gfx, 0, gfx->height - btn_height, gfx->width, btn_height);
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_line(gfx, 0, gfx->height - btn_height, gfx->width, gfx->height - btn_height);
    
    /* Cancel and OK buttons */
    midp_graphics_draw_string(gfx, "Cancel", 10, gfx->height - btn_height + 5, 0);
    midp_graphics_draw_string(gfx, "OK", gfx->width - 30, gfx->height - btn_height + 5, 0);
}

/*
 * Native method implementations
 */

/* Form.append(Item) */
static JavaValue native_form_append(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* form = (JavaObject*)args[0].ref;
    JavaObject* item = (JavaObject*)args[1].ref;
    
    if (!form || !item) {
        return NATIVE_RETURN_INT(-1);
    }
    
    /* Form has items[] array at field 1 (after title) */
    /* We need to grow the array and add the item */
    /* For simplicity, just return success */
    
    fprintf(stderr, "[Form] append: form=%p, item=%p (type=%d)\n", 
            (void*)form, (void*)item, get_item_type(item));
    
    return NATIVE_RETURN_INT(0);
}

/* Form.delete(int) */
static JavaValue native_form_delete(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* form = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    fprintf(stderr, "[Form] delete: form=%p, index=%d\n", (void*)form, index);
    
    return NATIVE_RETURN_VOID();
}

/* Form.size() */
static JavaValue native_form_size(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* form = (JavaObject*)args[0].ref;
    
    /* Count items in the form */
    if (form && form->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        JavaArray* items = (JavaArray*)form->fields[1].ref;
        if (items) {
            return NATIVE_RETURN_INT(items->length);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Form.getTitle() */
static JavaValue native_form_getTitle(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* form = (JavaObject*)args[0].ref;
    
    if (form && form->header.clazz->instance_size >= sizeof(JavaValue)) {
        JavaString* title = (JavaString*)form->fields[0].ref;
        return NATIVE_RETURN_OBJECT(title);
    }
    
    return NATIVE_RETURN_NULL();
}

/* Form.setTitle(String) */
static JavaValue native_form_setTitle(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* form = (JavaObject*)args[0].ref;
    JavaString* title = (JavaString*)args[1].ref;
    
    if (form && form->header.clazz->instance_size >= sizeof(JavaValue)) {
        form->fields[0].ref = title;
    }
    
    return NATIVE_RETURN_VOID();
}

/* StringItem.setText(String) */
static JavaValue native_stringitem_setText(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    JavaString* text = (JavaString*)args[1].ref;
    
    if (item && item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        item->fields[1].ref = text; /* text is at field 1 */
    }
    
    return NATIVE_RETURN_VOID();
}

/* StringItem.getText() */
static JavaValue native_stringitem_getText(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    
    if (item && item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        return NATIVE_RETURN_OBJECT(item->fields[1].ref);
    }
    
    return NATIVE_RETURN_NULL();
}

/* TextField.setString(String) */
static JavaValue native_textfield_setString(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    JavaString* text = (JavaString*)args[1].ref;
    
    if (item && item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        item->fields[1].ref = text;
    }
    
    return NATIVE_RETURN_VOID();
}

/* TextField.getString() */
static JavaValue native_textfield_getString(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    
    if (item && item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        return NATIVE_RETURN_OBJECT(item->fields[1].ref);
    }
    
    return NATIVE_RETURN_NULL();
}

/* TextField.setChars(char[], int, int) */
static JavaValue native_textfield_setChars(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    JavaArray* chars = (JavaArray*)args[1].ref;
    jint offset = args[2].i;
    jint length = args[3].i;
    
    if (item && chars && chars->element_type == T_CHAR) {
        /* Create new String from char array */
        JavaString* str = jvm_new_string_utf16(jvm, chars->data.chars + offset, length);
        if (item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
            item->fields[1].ref = str;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* TextField.size() */
static JavaValue native_textfield_size(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    
    if (item && item->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        JavaString* text = (JavaString*)item->fields[1].ref;
        if (text) {
            return NATIVE_RETURN_INT(text->length);
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* ChoiceGroup.append(String, Image) */
static JavaValue native_choicegroup_append(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaString* text = (JavaString*)args[1].ref;
    JavaObject* image = (JavaObject*)args[2].ref;
    
    fprintf(stderr, "[ChoiceGroup] append: text=%s\n", 
            text ? get_string_from_object(jvm, (JavaObject*)text) : "(null)");
    
    return NATIVE_RETURN_INT(0);
}

/* ChoiceGroup.setSelectedIndex(int, boolean) */
static JavaValue native_choicegroup_setSelectedIndex(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    jboolean selected = args[2].i;
    
    fprintf(stderr, "[ChoiceGroup] setSelectedIndex: index=%d, selected=%d\n", index, selected);
    
    return NATIVE_RETURN_VOID();
}

/* ChoiceGroup.getSelectedIndex() */
static JavaValue native_choicegroup_getSelectedIndex(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    
    /* Return first selected index */
    if (group && group->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaArray* selected = (JavaArray*)group->fields[3].ref;
        if (selected && selected->element_type == T_BOOLEAN) {
            for (int i = 0; i < selected->length; i++) {
                if (selected->data.booleans[i]) {
                    return NATIVE_RETURN_INT(i);
                }
            }
        }
    }
    
    return NATIVE_RETURN_INT(-1);
}

/* Gauge.setValue(int) */
static JavaValue native_gauge_setValue(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gauge = (JavaObject*)args[0].ref;
    jint value = args[1].i;
    
    if (gauge && gauge->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        gauge->fields[3].i = value;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Gauge.getValue() */
static JavaValue native_gauge_getValue(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* gauge = (JavaObject*)args[0].ref;
    
    if (gauge && gauge->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        return NATIVE_RETURN_INT(gauge->fields[3].i);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* List.append(String, Image) */
static JavaValue native_list_append(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* list = (JavaObject*)args[0].ref;
    JavaString* text = (JavaString*)args[1].ref;
    
    fprintf(stderr, "[List] append: text=%s\n", 
            text ? get_string_from_object(jvm, (JavaObject*)text) : "(null)");
    
    return NATIVE_RETURN_INT(0);
}

/* List.getSelectedIndex() */
static JavaValue native_list_getSelectedIndex(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* list = (JavaObject*)args[0].ref;
    
    /* Return first selected index */
    if (list && list->header.clazz->instance_size >= 4 * sizeof(JavaValue)) {
        JavaArray* selected = (JavaArray*)list->fields[3].ref;
        if (selected && selected->element_type == T_BOOLEAN) {
            for (int i = 0; i < selected->length; i++) {
                if (selected->data.booleans[i]) {
                    return NATIVE_RETURN_INT(i);
                }
            }
        }
    }
    
    return NATIVE_RETURN_INT(0);
}

/* List.setSelectedIndex(int) */
static JavaValue native_list_setSelectedIndex(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* list = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    fprintf(stderr, "[List] setSelectedIndex: %d\n", index);
    
    return NATIVE_RETURN_VOID();
}

/* Alert.setString(String) */
static JavaValue native_alert_setString(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* alert = (JavaObject*)args[0].ref;
    JavaString* text = (JavaString*)args[1].ref;
    
    if (alert && alert->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        alert->fields[1].ref = text;
    }
    
    return NATIVE_RETURN_VOID();
}

/* TextBox.setString(String) */
static JavaValue native_textbox_setString(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* textbox = (JavaObject*)args[0].ref;
    JavaString* text = (JavaString*)args[1].ref;
    
    if (textbox && textbox->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        textbox->fields[1].ref = text;
    }
    
    return NATIVE_RETURN_VOID();
}

/* TextBox.getString() */
static JavaValue native_textbox_getString(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* textbox = (JavaObject*)args[0].ref;
    
    if (textbox && textbox->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        return NATIVE_RETURN_OBJECT(textbox->fields[1].ref);
    }
    
    return NATIVE_RETURN_NULL();
}

/* Item.setLabel(String) */
static JavaValue native_item_setLabel(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    JavaString* label = (JavaString*)args[1].ref;
    
    if (item && item->header.clazz->instance_size >= sizeof(JavaValue)) {
        item->fields[0].ref = label;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Item.getLabel() */
static JavaValue native_item_getLabel(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    
    if (item && item->header.clazz->instance_size >= sizeof(JavaValue)) {
        return NATIVE_RETURN_OBJECT(item->fields[0].ref);
    }
    
    return NATIVE_RETURN_NULL();
}

/* Command constructor */
static JavaValue native_command_init(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cmd = (JavaObject*)args[0].ref;
    JavaString* label = (JavaString*)args[1].ref;
    jint type = args[2].i;
    jint priority = args[3].i;
    
    if (cmd && cmd->header.clazz->instance_size >= 3 * sizeof(JavaValue)) {
        cmd->fields[0].ref = label;     /* label */
        cmd->fields[1].i = type;        /* type */
        cmd->fields[2].i = priority;    /* priority */
    }
    
    fprintf(stderr, "[Command] <init>: label=%s, type=%d, priority=%d\n",
            label ? get_string_from_object(jvm, (JavaObject*)label) : "(null)",
            type, priority);
    
    return NATIVE_RETURN_VOID();
}

/* Displayable.addCommand(Command) */
static JavaValue native_displayable_addCommand(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* displayable = (JavaObject*)args[0].ref;
    JavaObject* cmd = (JavaObject*)args[1].ref;
    
    fprintf(stderr, "[Displayable] addCommand: displayable=%p, cmd=%p\n",
            (void*)displayable, (void*)cmd);
    
    return NATIVE_RETURN_VOID();
}

/* Displayable.setCommandListener(CommandListener) */
static JavaValue native_displayable_setCommandListener(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* displayable = (JavaObject*)args[0].ref;
    JavaObject* listener = (JavaObject*)args[1].ref;
    
    fprintf(stderr, "[Displayable] setCommandListener: displayable=%p, listener=%p\n",
            (void*)displayable, (void*)listener);
    
    return NATIVE_RETURN_VOID();
}

/* Spacer.setSize(int, int) */
static JavaValue native_spacer_setSize(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* spacer = (JavaObject*)args[0].ref;
    jint width = args[1].i;
    jint height = args[2].i;
    
    if (spacer && spacer->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        spacer->fields[0].i = width;
        spacer->fields[1].i = height;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Spacer.setMinimumSize(int, int) */
static JavaValue native_spacer_setMinimumSize(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    return native_spacer_setSize(jvm, thread, args, arg_count);
}

/* ImageItem.setImage(Image) */
static JavaValue native_imageitem_setImage(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* item = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    
    if (item && item->header.clazz->instance_size >= 3 * sizeof(JavaValue)) {
        item->fields[2].ref = image; /* image is at field 2 */
    }
    
    return NATIVE_RETURN_VOID();
}

/*
 * Initialize Form API native methods
 */
void init_javax_microedition_lcdui_form(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Form methods */
        {"javax/microedition/lcdui/Form", "append", "(Ljavax/microedition/lcdui/Item;)I", native_form_append},
        {"javax/microedition/lcdui/Form", "delete", "(I)V", native_form_delete},
        {"javax/microedition/lcdui/Form", "size", "()I", native_form_size},
        {"javax/microedition/lcdui/Form", "getTitle", "()Ljava/lang/String;", native_form_getTitle},
        {"javax/microedition/lcdui/Form", "setTitle", "(Ljava/lang/String;)V", native_form_setTitle},
        
        /* Item methods */
        {"javax/microedition/lcdui/Item", "setLabel", "(Ljava/lang/String;)V", native_item_setLabel},
        {"javax/microedition/lcdui/Item", "getLabel", "()Ljava/lang/String;", native_item_getLabel},
        
        /* StringItem methods */
        {"javax/microedition/lcdui/StringItem", "setText", "(Ljava/lang/String;)V", native_stringitem_setText},
        {"javax/microedition/lcdui/StringItem", "getText", "()Ljava/lang/String;", native_stringitem_getText},
        
        /* TextField methods */
        {"javax/microedition/lcdui/TextField", "setString", "(Ljava/lang/String;)V", native_textfield_setString},
        {"javax/microedition/lcdui/TextField", "getString", "()Ljava/lang/String;", native_textfield_getString},
        {"javax/microedition/lcdui/TextField", "setChars", "([CII)V", native_textfield_setChars},
        {"javax/microedition/lcdui/TextField", "size", "()I", native_textfield_size},
        
        /* ChoiceGroup methods */
        {"javax/microedition/lcdui/ChoiceGroup", "append", "(Ljava/lang/String;Ljavax/microedition/lcdui/Image;)I", native_choicegroup_append},
        {"javax/microedition/lcdui/ChoiceGroup", "setSelectedIndex", "(IZ)V", native_choicegroup_setSelectedIndex},
        {"javax/microedition/lcdui/ChoiceGroup", "getSelectedIndex", "()I", native_choicegroup_getSelectedIndex},
        
        /* Gauge methods */
        {"javax/microedition/lcdui/Gauge", "setValue", "(I)V", native_gauge_setValue},
        {"javax/microedition/lcdui/Gauge", "getValue", "()I", native_gauge_getValue},
        
        /* List methods */
        {"javax/microedition/lcdui/List", "append", "(Ljava/lang/String;Ljavax/microedition/lcdui/Image;)I", native_list_append},
        {"javax/microedition/lcdui/List", "getSelectedIndex", "()I", native_list_getSelectedIndex},
        {"javax/microedition/lcdui/List", "setSelectedIndex", "(I)V", native_list_setSelectedIndex},
        
        /* Alert methods */
        {"javax/microedition/lcdui/Alert", "setString", "(Ljava/lang/String;)V", native_alert_setString},
        
        /* TextBox methods */
        {"javax/microedition/lcdui/TextBox", "setString", "(Ljava/lang/String;)V", native_textbox_setString},
        {"javax/microedition/lcdui/TextBox", "getString", "()Ljava/lang/String;", native_textbox_getString},
        
        /* Spacer methods */
        {"javax/microedition/lcdui/Spacer", "setMinimumSize", "(II)V", native_spacer_setMinimumSize},
        
        /* ImageItem methods */
        {"javax/microedition/lcdui/ImageItem", "setImage", "(Ljavax/microedition/lcdui/Image;)V", native_imageitem_setImage},
        
        /* Command methods */
        {"javax/microedition/lcdui/Command", "<init>", "(Ljava/lang/String;II)V", native_command_init},
        
        /* Displayable methods */
        {"javax/microedition/lcdui/Displayable", "addCommand", "(Ljavax/microedition/lcdui/Command;)V", native_displayable_addCommand},
        {"javax/microedition/lcdui/Displayable", "setCommandListener", "(Ljavax/microedition/lcdui/CommandListener;)V", native_displayable_setCommandListener},
    };
    
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    
    fprintf(stderr, "[Form] Registered %zu UI native methods\n", sizeof(methods) / sizeof(methods[0]));
}

/*
 * Render a Form on screen
 * This is called from display.c when setCurrent() is called with a Form
 */
void midp_render_form(JVM* jvm, JavaObject* form) {
    if (!form) return;
    
    MidpGraphics* gfx = get_screen_graphics();
    if (!gfx) return;
    
    /* Clear screen */
    midp_graphics_set_color(gfx, 0xFFFFFF, 255);
    midp_graphics_fill_rect(gfx, 0, 0, gfx->width, gfx->height);
    
    /* Draw title bar */
    const char* title = "";
    if (form->header.clazz->instance_size >= sizeof(JavaValue)) {
        JavaString* title_str = (JavaString*)form->fields[0].ref;
        if (title_str) title = get_string_from_object(jvm, (JavaObject*)title_str);
    }
    
    /* Title background */
    midp_graphics_set_color(gfx, 0x000080, 255);
    midp_graphics_fill_rect(gfx, 0, 0, gfx->width, 20);
    midp_graphics_set_color(gfx, 0xFFFFFF, 255);
    midp_graphics_draw_string(gfx, title, gfx->width / 2, 3, 0x10); /* HCENTER */
    
    /* Draw separator */
    midp_graphics_set_color(gfx, 0x808080, 255);
    midp_graphics_draw_line(gfx, 0, 20, gfx->width, 20);
    
    /* Get items array from form */
    int y = 25;
    
    if (form->header.clazz->instance_size >= 2 * sizeof(JavaValue)) {
        JavaArray* items = (JavaArray*)form->fields[1].ref;
        
        if (items && items->element_type == DESC_OBJECT) {
            for (int i = 0; i < items->length && y < gfx->height - 30; i++) {
                JavaObject* item = (JavaObject*)items->data.refs[i];
                if (!item) continue;
                
                bool focused = (i == g_focused_item_index);
                int item_type = get_item_type(item);
                
                switch (item_type) {
                    case ITEM_STRINGITEM:
                        y = render_stringitem(jvm, gfx, item, y);
                        break;
                    case ITEM_TEXTFIELD:
                        y = render_textfield(jvm, gfx, item, y, focused);
                        break;
                    case ITEM_CHOICEGROUP:
                        y = render_choicegroup(jvm, gfx, item, y, focused);
                        break;
                    case ITEM_GAUGE:
                        y = render_gauge(jvm, gfx, item, y, focused);
                        break;
                    case ITEM_SPACER:
                        y = render_spacer(jvm, gfx, item, y);
                        break;
                    default:
                        /* Unknown item type - skip */
                        y += 20;
                        break;
                }
            }
        }
    }
    
    /* Draw soft button area */
    midp_graphics_set_color(gfx, 0xC0C0C0, 255);
    midp_graphics_fill_rect(gfx, 0, gfx->height - 25, gfx->width, 25);
    midp_graphics_set_color(gfx, 0x000000, 255);
    midp_graphics_draw_line(gfx, 0, gfx->height - 25, gfx->width, gfx->height - 25);
    
    /* Draw soft buttons */
    midp_graphics_draw_string(gfx, "Exit", 5, gfx->height - 20, 0);
    midp_graphics_draw_string(gfx, "Select", gfx->width - 40, gfx->height - 20, 0);
    
    /* Present to screen */
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (sdl_ctx) {
        sdl_present(sdl_ctx);
    }
}

/* Public function: Render Alert */
void midp_render_alert(JVM* jvm, MidpGraphics* gfx, JavaObject* alert) {
    if (!alert || !gfx) return;
    render_alert(jvm, gfx, alert);
}

/* Public function: Render List */
void midp_render_list(JVM* jvm, JavaObject* list, int focused_index) {
    if (!list) return;
    MidpGraphics* gfx = get_screen_graphics();
    if (!gfx) return;
    
    /* Clear screen */
    midp_graphics_set_color(gfx, 0xFFFFFF, 255);
    midp_graphics_fill_rect(gfx, 0, 0, gfx->width, gfx->height);
    
    render_list(jvm, gfx, list, focused_index);
    
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (sdl_ctx) sdl_present(sdl_ctx);
}

/* Public function: Render TextBox */
void midp_render_textbox(JVM* jvm, JavaObject* textbox, const char* input_text, int cursor_pos) {
    if (!textbox) return;
    MidpGraphics* gfx = get_screen_graphics();
    if (!gfx) return;
    
    /* Clear screen */
    midp_graphics_set_color(gfx, 0xFFFFFF, 255);
    midp_graphics_fill_rect(gfx, 0, 0, gfx->width, gfx->height);
    
    render_textbox(jvm, gfx, textbox, input_text, cursor_pos);
    
    SdlContext* sdl_ctx = sdl_get_global_context();
    if (sdl_ctx) sdl_present(sdl_ctx);
}
