/*
 * J2ME Emulator - MIDP2 Graphics API
 */

#define _USE_MATH_DEFINES
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "midp.h"
#include "jvm.h"
#include "bitmap_font.h"

/* Current graphics context */
static MidpGraphics* current_gfx = NULL;

/* Forward declaration */
static void set_pixel(MidpGraphics* gfx, int x, int y);

/* Draw a single character using the bitmap font */
static void midp_graphics_draw_char(MidpGraphics* gfx, char c, int x, int y) {
    const uint8_t* char_data = get_char_data(c);
    
    for (int row = 0; row < FONT_HEIGHT; row++) {
        uint8_t row_data = char_data[row];
        for (int col = 0; col < FONT_WIDTH; col++) {
            /* MSB is leftmost pixel, so use (FONT_WIDTH - 1 - col) to get correct bit */
            if (row_data & (1 << (FONT_WIDTH - 1 - col))) {
                set_pixel(gfx, x + col, y + row);
            }
        }
    }
}

/* Initialize MIDP2 */
int midp_init(JVM* jvm) {
    /* Initialize MIDP2 native methods */
    init_javax_microedition_lcdui_graphics(jvm);
    init_javax_microedition_lcdui_display(jvm);
    init_javax_microedition_lcdui_image(jvm);
    init_javax_microedition_lcdui_font(jvm);
    init_javax_microedition_lcdui_game_gamecanvas(jvm);
    init_javax_microedition_lcdui_form(jvm);  /* Form, TextField, ChoiceGroup, etc. */
    init_javax_microedition_rms(jvm);
    
    /* Initialize Java lang classes */
    extern void init_java_lang_integer(JVM* jvm);
    extern void init_java_util_random(JVM* jvm);
    init_java_lang_integer(jvm);
    init_java_util_random(jvm);
    
    /* Seed random number generator */
    srand((unsigned int)time(NULL));
    
    return JNI_OK;
}

/*
 * Graphics operations
 */

void midp_graphics_init(MidpGraphics* gfx, uint32_t* pixels, int width, int height) {
    gfx->pixels = pixels;
    gfx->width = width;
    gfx->height = height;
    gfx->clip_x = 0;
    gfx->clip_y = 0;
    gfx->clip_width = width;
    gfx->clip_height = height;
    gfx->translate_x = 0;
    gfx->translate_y = 0;
    gfx->rgb_color = 0x000000;
    gfx->alpha = 255;
    gfx->stroke_style = 0;
    gfx->font = 0;
}

void midp_graphics_set_clip(MidpGraphics* gfx, int x, int y, int width, int height) {
    gfx->clip_x = x;
    gfx->clip_y = y;
    gfx->clip_width = width;
    gfx->clip_height = height;
}

void midp_graphics_clip_rect(MidpGraphics* gfx, int x, int y, int width, int height) {
    /* Intersect with current clip */
    int x1 = gfx->clip_x > x ? gfx->clip_x : x;
    int y1 = gfx->clip_y > y ? gfx->clip_y : y;
    int x2 = (gfx->clip_x + gfx->clip_width) < (x + width) ? 
             (gfx->clip_x + gfx->clip_width) : (x + width);
    int y2 = (gfx->clip_y + gfx->clip_height) < (y + height) ?
             (gfx->clip_y + gfx->clip_height) : (y + height);
    
    gfx->clip_x = x1;
    gfx->clip_y = y1;
    gfx->clip_width = x2 - x1;
    gfx->clip_height = y2 - y1;
}

void midp_graphics_translate(MidpGraphics* gfx, int x, int y) {
    gfx->translate_x += x;
    gfx->translate_y += y;
}

void midp_graphics_set_color(MidpGraphics* gfx, int rgb, int alpha) {
    fprintf(stderr, "[GFX] setColor: RGB=0x%06X, alpha=%d\n", rgb & 0xFFFFFF, alpha);
    fflush(stderr);
    gfx->rgb_color = rgb & 0xFFFFFF;
    gfx->alpha = alpha;
}

static void set_pixel(MidpGraphics* gfx, int x, int y) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    if (x < gfx->clip_x || x >= gfx->clip_x + gfx->clip_width ||
        y < gfx->clip_y || y >= gfx->clip_y + gfx->clip_height) {
        return;
    }
    
    if (x < 0 || x >= gfx->width || y < 0 || y >= gfx->height) {
        return;
    }
    
    uint32_t color = (gfx->alpha << 24) | gfx->rgb_color;
    gfx->pixels[y * gfx->width + x] = color;
}

void midp_graphics_draw_line(MidpGraphics* gfx, int x1, int y1, int x2, int y2) {
    fprintf(stderr, "[GFX] drawLine: (%d,%d) -> (%d,%d), color=0x%06X\n", 
            x1, y1, x2, y2, gfx->rgb_color);
    fflush(stderr);
    x1 += gfx->translate_x;
    y1 += gfx->translate_y;
    x2 += gfx->translate_x;
    y2 += gfx->translate_y;
    
    /* Bresenham's line algorithm */
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = x1 < x2 ? 1 : -1;
    int sy = y1 < y2 ? 1 : -1;
    int err = dx - dy;
    
    while (true) {
        set_pixel(gfx, x1 - gfx->translate_x, y1 - gfx->translate_y);
        
        if (x1 == x2 && y1 == y2) break;
        
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
}

void midp_graphics_fill_rect(MidpGraphics* gfx, int x, int y, int w, int h) {
    fprintf(stderr, "[GFX] fillRect: (%d,%d) %dx%d, color=0x%06X, clip=(%d,%d %dx%d)\n", 
            x, y, w, h, gfx->rgb_color, gfx->clip_x, gfx->clip_y, gfx->clip_width, gfx->clip_height);
    fflush(stderr);
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    /* Clip to bounds */
    int x1 = x > gfx->clip_x ? x : gfx->clip_x;
    int y1 = y > gfx->clip_y ? y : gfx->clip_y;
    int x2 = (x + w) < (gfx->clip_x + gfx->clip_width) ? (x + w) : (gfx->clip_x + gfx->clip_width);
    int y2 = (y + h) < (gfx->clip_y + gfx->clip_height) ? (y + h) : (gfx->clip_y + gfx->clip_height);
    
    uint32_t color = (gfx->alpha << 24) | gfx->rgb_color;
    
    for (int py = y1; py < y2 && py < gfx->height; py++) {
        if (py < 0) continue;
        for (int px = x1; px < x2 && px < gfx->width; px++) {
            if (px < 0) continue;
            gfx->pixels[py * gfx->width + px] = color;
        }
    }
}

void midp_graphics_draw_rect(MidpGraphics* gfx, int x, int y, int w, int h) {
    midp_graphics_draw_line(gfx, x, y, x + w - 1, y);
    midp_graphics_draw_line(gfx, x, y + h - 1, x + w - 1, y + h - 1);
    midp_graphics_draw_line(gfx, x, y, x, y + h - 1);
    midp_graphics_draw_line(gfx, x + w - 1, y, x + w - 1, y + h - 1);
}

void midp_graphics_draw_arc(MidpGraphics* gfx, int x, int y, int w, int h,
                            int start_angle, int arc_angle) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    double cx = x + w / 2.0;
    double cy = y + h / 2.0;
    double rx = w / 2.0;
    double ry = h / 2.0;
    
    double start_rad = start_angle * M_PI / 180.0;
    double end_rad = (start_angle + arc_angle) * M_PI / 180.0;
    
    int steps = abs(arc_angle) * 2;
    double step = arc_angle > 0 ? (end_rad - start_rad) / steps : (start_rad - end_rad) / steps;
    
    for (int i = 0; i <= steps; i++) {
        double angle = start_rad + i * step;
        int px = (int)(cx + rx * cos(angle));
        int py = (int)(cy + ry * sin(angle));
        set_pixel(gfx, px - gfx->translate_x, py - gfx->translate_y);
    }
}

void midp_graphics_fill_arc(MidpGraphics* gfx, int x, int y, int w, int h,
                            int start_angle, int arc_angle) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    double cx = x + w / 2.0;
    double cy = y + h / 2.0;
    double rx = w / 2.0;
    double ry = h / 2.0;
    
    double start_rad = start_angle * M_PI / 180.0;
    double end_rad = (start_angle + arc_angle) * M_PI / 180.0;
    
    /* Fill using scanlines */
    for (int py = y; py < y + h && py < gfx->height; py++) {
        if (py < 0 || py < gfx->clip_y || py >= gfx->clip_y + gfx->clip_height) continue;
        
        for (int px = x; px < x + w && px < gfx->width; px++) {
            if (px < 0 || px < gfx->clip_x || px >= gfx->clip_x + gfx->clip_width) continue;
            
            double dx = (px - cx) / rx;
            double dy = (py - cy) / ry;
            
            if (dx * dx + dy * dy <= 1.0) {
                double angle = atan2(dy, dx);
                if (angle < 0) angle += 2 * M_PI;
                
                bool in_arc = false;
                if (arc_angle > 0) {
                    in_arc = (angle >= start_rad && angle <= end_rad);
                } else {
                    in_arc = (angle <= start_rad && angle >= end_rad);
                }
                
                if (in_arc) {
                    set_pixel(gfx, px - gfx->translate_x, py - gfx->translate_y);
                }
            }
        }
    }
}

void midp_graphics_draw_round_rect(MidpGraphics* gfx, int x, int y, int w, int h,
                                   int arc_w, int arc_h) {
    /* Draw lines */
    midp_graphics_draw_line(gfx, x + arc_w/2, y, x + w - arc_w/2 - 1, y);
    midp_graphics_draw_line(gfx, x + arc_w/2, y + h - 1, x + w - arc_w/2 - 1, y + h - 1);
    midp_graphics_draw_line(gfx, x, y + arc_h/2, x, y + h - arc_h/2 - 1);
    midp_graphics_draw_line(gfx, x + w - 1, y + arc_h/2, x + w - 1, y + h - arc_h/2 - 1);
    
    /* Draw arcs */
    midp_graphics_draw_arc(gfx, x, y, arc_w, arc_h, 90, 90);
    midp_graphics_draw_arc(gfx, x + w - arc_w, y, arc_w, arc_h, 0, 90);
    midp_graphics_draw_arc(gfx, x + w - arc_w, y + h - arc_h, arc_w, arc_h, 270, 90);
    midp_graphics_draw_arc(gfx, x, y + h - arc_h, arc_w, arc_h, 180, 90);
}

void midp_graphics_fill_round_rect(MidpGraphics* gfx, int x, int y, int w, int h,
                                   int arc_w, int arc_h) {
    /* Fill center */
    midp_graphics_fill_rect(gfx, x + arc_w/2, y, w - arc_w, h);
    midp_graphics_fill_rect(gfx, x, y + arc_h/2, arc_w/2, h - arc_h);
    midp_graphics_fill_rect(gfx, x + w - arc_w/2, y + arc_h/2, arc_w/2, h - arc_h);
    
    /* Fill corners */
    midp_graphics_fill_arc(gfx, x, y, arc_w, arc_h, 90, 90);
    midp_graphics_fill_arc(gfx, x + w - arc_w, y, arc_w, arc_h, 0, 90);
    midp_graphics_fill_arc(gfx, x + w - arc_w, y + h - arc_h, arc_w, arc_h, 270, 90);
    midp_graphics_fill_arc(gfx, x, y + h - arc_h, arc_w, arc_h, 180, 90);
}

void midp_graphics_draw_string(MidpGraphics* gfx, const char* str,
                               int x, int y, int anchor) {
    fprintf(stderr, "[GFX] drawString: str='%s', x=%d, y=%d, anchor=%d, color=0x%06X\n",
            str ? str : "(null)", x, y, anchor, gfx ? gfx->rgb_color : 0);
    fflush(stderr);
    
    if (!str || !gfx) return;
    
    int len = strlen(str);
    if (len == 0) return;
    
    /* Calculate text dimensions */
    int text_width = len * (FONT_WIDTH + 1) - 1;  /* +1 for spacing between chars */
    int text_height = FONT_HEIGHT;
    
    /* Apply translation */
    int draw_x = x + gfx->translate_x;
    int draw_y = y + gfx->translate_y;
    
    /* MIDP2 anchor constants:
     * HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64
     */
    
    /* Apply horizontal anchor */
    if (anchor & 0x01) {        /* HCENTER = 1 */
        draw_x -= text_width / 2;
    } else if (anchor & 0x08) { /* RIGHT = 8 */
        draw_x -= text_width;
    }
    /* LEFT = 4 is default (no adjustment needed) */
    
    /* Apply vertical anchor */
    if (anchor & 0x02) {        /* VCENTER = 2 */
        draw_y -= text_height / 2;
    } else if (anchor & 0x40) { /* BASELINE = 64 */
        draw_y -= FONT_HEIGHT - 2;  /* Baseline is near bottom */
    } else if (anchor & 0x20) { /* BOTTOM = 32 */
        draw_y -= text_height;
    }
    /* TOP = 16 is default (no adjustment needed) */
    
    /* Debug output for anchor calculation */
    fprintf(stderr, "[GFX] drawString: text_width=%d, draw_x=%d, draw_y=%d (anchor: HCENTER=%d RIGHT=%d LEFT=%d)\n",
            text_width, draw_x, draw_y, 
            (anchor & 0x01) ? 1 : 0, 
            (anchor & 0x08) ? 1 : 0,
            (anchor & 0x04) ? 1 : 0);
    fflush(stderr);
    
    /* Draw each character */
    int cur_x = draw_x;
    for (int i = 0; i < len; i++) {
        midp_graphics_draw_char(gfx, str[i], cur_x, draw_y);
        cur_x += FONT_WIDTH + 1;  /* +1 for spacing between characters */
    }
}

void midp_graphics_draw_image(MidpGraphics* gfx, MidpImage* img,
                              int x, int y, int anchor) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    if (!img || !img->pixels) return;
    
    /* MIDP2 anchor constants:
     * HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64
     */
    
    /* Apply horizontal anchor */
    if (anchor & 0x01) {        /* HCENTER */
        x -= img->width / 2;
    } else if (anchor & 0x08) { /* RIGHT */
        x -= img->width;
    }
    /* LEFT = 4 is default */
    
    /* Apply vertical anchor */
    if (anchor & 0x02) {        /* VCENTER */
        y -= img->height / 2;
    } else if (anchor & 0x20) { /* BOTTOM */
        y -= img->height;
    }
    /* TOP = 16 is default */
    
    /* Copy pixels */
    for (int py = 0; py < img->height; py++) {
        int dst_y = y + py;
        if (dst_y < gfx->clip_y || dst_y >= gfx->clip_y + gfx->clip_height) continue;
        if (dst_y < 0 || dst_y >= gfx->height) continue;
        
        for (int px = 0; px < img->width; px++) {
            int dst_x = x + px;
            if (dst_x < gfx->clip_x || dst_x >= gfx->clip_x + gfx->clip_width) continue;
            if (dst_x < 0 || dst_x >= gfx->width) continue;
            
            uint32_t src_color = img->pixels[py * img->width + px];
            
            /* Alpha blending */
            uint8_t alpha = (src_color >> 24) & 0xFF;
            if (alpha == 255) {
                gfx->pixels[dst_y * gfx->width + dst_x] = src_color;
            } else if (alpha > 0) {
                uint32_t dst_color = gfx->pixels[dst_y * gfx->width + dst_x];
                uint8_t inv_alpha = 255 - alpha;
                
                uint8_t r = ((src_color >> 16) & 0xFF) * alpha / 255 + 
                           ((dst_color >> 16) & 0xFF) * inv_alpha / 255;
                uint8_t g = ((src_color >> 8) & 0xFF) * alpha / 255 +
                           ((dst_color >> 8) & 0xFF) * inv_alpha / 255;
                uint8_t b = (src_color & 0xFF) * alpha / 255 +
                           (dst_color & 0xFF) * inv_alpha / 255;
                
                gfx->pixels[dst_y * gfx->width + dst_x] = (0xFF << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }
}

void midp_graphics_get_rgb(MidpGraphics* gfx, jint* rgb_data,
                           int offset, int scanlength, int x, int y, int w, int h) {
    x += gfx->translate_x;
    y += gfx->translate_y;
    
    for (int py = 0; py < h; py++) {
        int src_y = y + py;
        if (src_y < 0 || src_y >= gfx->height) continue;
        
        for (int px = 0; px < w; px++) {
            int src_x = x + px;
            if (src_x < 0 || src_x >= gfx->width) continue;
            
            rgb_data[offset + py * scanlength + px] = 
                (jint)gfx->pixels[src_y * gfx->width + src_x];
        }
    }
}

/*
 * Image operations
 */

MidpImage* midp_image_create(int width, int height, bool mutable) {
    MidpImage* img = (MidpImage*)malloc(sizeof(MidpImage));
    if (!img) return NULL;
    
    img->pixels = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    if (!img->pixels) {
        free(img);
        return NULL;
    }
    
    img->width = width;
    img->height = height;
    img->mutable = mutable;
    img->alpha = true;
    
    return img;
}

MidpImage* midp_image_create_from_rgb(const jint* rgb, int width, int height,
                                       bool process_alpha) {
    MidpImage* img = midp_image_create(width, height, true);
    if (!img) return NULL;
    
    for (int i = 0; i < width * height; i++) {
        if (process_alpha) {
            img->pixels[i] = (uint32_t)rgb[i];
        } else {
            img->pixels[i] = 0xFF000000 | ((uint32_t)rgb[i] & 0xFFFFFF);
        }
    }
    
    img->alpha = process_alpha;
    return img;
}

void midp_image_destroy(MidpImage* img) {
    if (img) {
        free(img->pixels);
        free(img);
    }
}

void midp_image_get_rgb(MidpImage* img, jint* rgb, int offset, int scanlength,
                        int x, int y, int width, int height) {
    if (!img || !rgb) return;
    
    for (int py = 0; py < height; py++) {
        int src_y = y + py;
        if (src_y < 0 || src_y >= img->height) continue;
        
        for (int px = 0; px < width; px++) {
            int src_x = x + px;
            if (src_x < 0 || src_x >= img->width) continue;
            
            rgb[offset + py * scanlength + px] = 
                (jint)img->pixels[src_y * img->width + src_x];
        }
    }
}

MidpGraphics* midp_image_get_graphics(MidpImage* img) {
    if (!img || !img->mutable) return NULL;
    
    MidpGraphics* gfx = (MidpGraphics*)malloc(sizeof(MidpGraphics));
    if (!gfx) return NULL;
    
    midp_graphics_init(gfx, img->pixels, img->width, img->height);
    return gfx;
}

/*
 * Font operations
 */

MidpFont* midp_font_get_default(void) {
    static MidpFont default_font = {
        .face = FONT_FACE_SYSTEM,
        .style = FONT_STYLE_PLAIN,
        .size = FONT_SIZE_MEDIUM,
        .height = FONT_HEIGHT,
        .baseline = FONT_HEIGHT - 2,
        .native_font = NULL
    };
    return &default_font;
}

MidpFont* midp_font_get(int face, int style, int size) {
    MidpFont* font = (MidpFont*)malloc(sizeof(MidpFont));
    if (!font) return NULL;
    
    font->face = face;
    font->style = style;
    font->size = size;
    /* Use bitmap font dimensions */
    font->height = FONT_HEIGHT;
    font->baseline = FONT_HEIGHT - 2;
    font->native_font = NULL;
    
    return font;
}

int midp_font_string_width(MidpFont* font, const char* str) {
    if (!font || !str) return 0;
    /* Each character is FONT_WIDTH pixels + 1 pixel spacing */
    int len = strlen(str);
    return len > 0 ? len * (FONT_WIDTH + 1) - 1 : 0;
}

int midp_font_char_width(MidpFont* font, jchar ch) {
    (void)ch;
    if (!font) return 0;
    return FONT_WIDTH;
}

int midp_font_height(MidpFont* font) {
    return font ? font->height : FONT_HEIGHT;
}

int midp_font_baseline_position(MidpFont* font) {
    return font ? font->baseline : FONT_HEIGHT - 2;
}

/*
 * Display operations
 */

void midp_display_get_dimensions(int* width, int* height) {
    if (width) *width = MIDP_DEFAULT_WIDTH;
    if (height) *height = MIDP_DEFAULT_HEIGHT;
}

bool midp_display_is_color(void) {
    return true;
}

int midp_display_num_colors(void) {
    return 65536;
}

int midp_display_num_alpha_levels(void) {
    return 256;
}
