import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import java.util.Vector;
import java.util.Stack;

/* TestVector — v36.03 NATIVE-ARGS-ROOTED selftest.
 *
 * Field crash this guards against: the invoke wrappers pop the receiver from
 * the java operand stack before dispatching a native, so during a native
 * call the receiver was invisible to the GC frame scan. Vector.toString()
 * walks elementData through C locals while util_to_string_of() runs
 * bytecode/allocations; a GC triggered mid-loop swept a TEMPORARY Vector
 * (the only reference was the popped receiver) and recycled elementData —
 * elements turned into garbage "refs" (recycled 32-bit data read as
 * pointers) and the float formatting path crashed (Data Abort 0xd7cf9088).
 *
 * The test reproduces the exact shape: a temporary Vector whose elements'
 * toString() FORCES a full GC (System.gc()) while only the popped receiver
 * still references the vector. With the fix the vector survives every
 * mid-loop GC and the joined string is exact. Without it the elements are
 * recycled garbage (FAIL / mojibake / crash).
 */
public class TestVector extends MIDlet {
    static int pass = 0, fail = 0;

    static void chk(String id, boolean cond, String detail) {
        if (cond) { pass++; System.out.println("V:" + id + " PASS " + detail); }
        else      { fail++; System.out.println("V:" + id + " FAIL " + detail); }
    }

    /* Element whose toString allocates hard and forces a full GC — the GC
     * fires while the outer Vector.toString() C loop holds elementData. */
    static class GcBomb {
        int n;
        GcBomb(int n) { this.n = n; }
        public String toString() {
            /* GC pressure WITHOUT bytecode string-concat loops (the known
             * interpreter stack-effect bug feeds on those): large array
             * allocations push the periodic-GC budget instead. */
            byte[] junk = new byte[16384];
            junk[n & 8191] = (byte) n;
            if (n == 7) System.gc();
            return "B" + n;
        }
    }

    public void startApp() throws MIDletStateChangeException {
        System.out.println("VEC-TEST-START");

        /* 1. Temporary vector, GC-bomb elements: the exact field-crash shape
         *    (no live local references the vector during toString()). */
        String r1 = makeBombVector().toString();
        /* v36.04: bytecode toString now RUNS (resolution order fixed) —
         * GcBomb.toString returns "B"+n. Also the operand-stack leak that
         * each nested call used to leave on the caller frame is gone. */
        chk("T1.bombs", r1.startsWith("[B0, B1, B2, B3, B4, B5, B6, B7]")
            && r1.endsWith("B7]") && r1.indexOf(", ") >= 0,
            "8 elements joined: " + r1);

        /* 2. Exact content: mixed Float/Integer/String/null (Float forces
         *    the snprintf/dtoa path from the field crash). */
        Vector v2 = new Vector();
        v2.addElement(new Float(1.5f));
        v2.addElement(new Integer(42));
        v2.addElement("str");
        v2.addElement(null);
        String r2 = v2.toString();
        chk("T2.float",  r2.indexOf("1.5") >= 0, r2);
        chk("T2.int",    r2.indexOf("42") >= 0, r2);
        chk("T2.str",    r2.indexOf("str") >= 0, r2);
        chk("T2.null",   r2.indexOf("null") >= 0, r2);
        chk("T2.braces", r1.endsWith("]") && r2.startsWith("[") && r2.endsWith("]"),
            "r2=" + r2);

        /* 3. Long vector: exercises the realloc growth path of the joiner
         *    (old code dereferenced a NULL realloc result unchecked). */
        Vector v3 = new Vector();
        for (int i = 0; i < 500; i++) v3.addElement(new Integer(100000 + i));
        String r3 = v3.toString();
        boolean ok3 = r3.startsWith("[100000") && r3.endsWith("100499]")
            && r3.length() > 3900 && r3.indexOf("100250") >= 0;
        chk("T3.long", ok3, "len=" + r3.length());

        /* 4. toString() under GC pressure from the element side, long mix. */
        Vector v4 = new Vector();
        for (int i = 0; i < 60; i++) {
            v4.addElement(new GcBomb(i));
            v4.addElement(new Float(i * 1.25f));
        }
        String r4 = v4.toString();
        chk("T4.gc-mix", r4.indexOf("73.75") >= 0 && r4.indexOf("0.0") >= 0
            && r4.indexOf("B0, 0.0, B1, 1.25") == 1, "120 elements joined");

        /* 5. Stack.toString (inherited Vector fields — same protection). */
        Stack st = new Stack();
        st.addElement(new Float(2.25f));
        st.addElement("tail");
        String r5 = makeBombStack(st).toString();
        chk("T5.stack", r5.indexOf("2.25") >= 0 && r5.indexOf("B99") >= 0, r5);

        System.out.println("VEC:DONE " + pass + "/" + fail);
        notifyDestroyed();
    }

    /* Build-and-return temporaries: after return the ONLY reference the
     * caller has arrives as the popped receiver of toString(). */
    static Vector makeBombVector() {
        Vector v = new Vector();
        for (int i = 0; i < 8; i++) v.addElement(new GcBomb(i));
        return v;
    }

    static Stack makeBombStack(Stack st) {
        st.addElement(new GcBomb(99));
        return st;
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) { }
}
