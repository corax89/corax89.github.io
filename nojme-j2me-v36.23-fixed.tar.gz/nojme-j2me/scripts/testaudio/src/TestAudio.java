import javax.microedition.midlet.MIDlet;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import java.io.InputStream;

/**
 * v34.73 TestAudio — E2E verification of the pure-C audio pipeline:
 * WAV (PCM 16/8-bit, mono/stereo, 11/22/44 kHz), IMA ADPCM, A-law, mu-law,
 * MIDI, Manager.playTone, and the saturating 2-player mixer.
 *
 * IMPORTANT (libretro architecture): startApp must RETURN quickly and run
 * the phases on a background thread, exactly like real games. The audio
 * pump (libretro_process_audio) only runs from retro_run — everything done
 * synchronously inside startApp (which the core executes during
 * retro_load_game, before the first frame) would produce ZERO audio.
 */
public class TestAudio extends MIDlet {

    private void phase(String res, String type, String tag) {
        System.out.println(tag + ":BEGIN");
        try {
            InputStream is = getClass().getResourceAsStream(res);
            if (is == null) {
                System.out.println(tag + ":NO-STREAM");
                return;
            }
            Player p = Manager.createPlayer(is, type);
            if (p == null) {
                System.out.println(tag + ":NULL-PLAYER");
                return;
            }
            p.start();
            Thread.sleep(900);
            System.out.println(tag + ":STATE=" + p.getState());
            p.close();
        } catch (Exception e) {
            System.out.println(tag + ":EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}
    }

    private void runPhases() {
        System.out.println("TA:START");

        // v36.21 [CAP-REPORT]: capability properties as seen from INSIDE the
        // VM — exactly the probes games make before using M3G / MMAPI.
        System.out.println("TA:PROP m3g=" + System.getProperty("microedition.m3g.version"));
        System.out.println("TA:PROP media=" + System.getProperty("microedition.media.version"));
        System.out.println("TA:PROP mixing=" + System.getProperty("supports.mixing"));
        // v36.21 [PROP-MISS]: unknown key -> null + one diagnostic line
        // "[PROP-MISS] '...' -> null" in the emulator log
        System.out.println("TA:PROP unknown=" + System.getProperty("com.example.nonexistent.prop"));

        phase("/t1.wav", "audio/x-wav", "TA:P1");   // 16-bit mono 22050, 440 Hz
        phase("/t2.wav", "audio/x-wav", "TA:P2");   // 16-bit stereo 44100, 880/1320 Hz
        phase("/t3.wav", "audio/x-wav", "TA:P3");   // 8-bit mono 11025, 220 Hz
        phase("/t4.wav", "audio/x-wav", "TA:P4");   // IMA ADPCM, 440 Hz
        phase("/t5.wav", "audio/x-wav", "TA:P5");   // A-law (fmt 6), 440 Hz
        phase("/t6.wav", "audio/x-wav", "TA:P6");   // mu-law (fmt 7), 440 Hz

        // P7: mixer — two simultaneous loud players (440 + 660 Hz, amp 20000
        // each: raw sum 40000 > 32767 -> the mixer must SATURATE, not wrap)
        System.out.println("TA:P7:BEGIN");
        try {
            InputStream i1 = getClass().getResourceAsStream("/t7.wav");
            InputStream i2 = getClass().getResourceAsStream("/t8.wav");
            Player a = Manager.createPlayer(i1, "audio/x-wav");
            Player b = Manager.createPlayer(i2, "audio/x-wav");
            if (a != null && b != null) {
                a.start();
                b.start();
                Thread.sleep(900);
                System.out.println("TA:P7:STATE_A=" + a.getState()
                        + " STATE_B=" + b.getState());
                a.close();
                b.close();
            } else {
                System.out.println("TA:P7:NULL-PLAYER");
            }
        } catch (Exception e) {
            System.out.println("TA:P7:EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}

        phase("/t9.mid", "audio/midi", "TA:P8");    // MIDI single A4

        // P9: Manager.playTone (JSR-135 mandatory): note 69 = A4 = 440 Hz
        System.out.println("TA:P9:BEGIN");
        try {
            Manager.playTone(69, 600, 100);
            Thread.sleep(900);
        } catch (Exception e) {
            System.out.println("TA:P9:EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}

        // v36.21: MIXED TYPES — MIDI music + WAV sfx sounding AT THE SAME
        // TIME (field report: "одновременно проигрывается только один
        // тип"). Both players must reach STARTED and BOTH media times must
        // advance: proves the mixer feeds and advances both streams.
        System.out.println("TA:P10:BEGIN");
        try {
            InputStream iw = getClass().getResourceAsStream("/t1.wav");
            InputStream im = getClass().getResourceAsStream("/t9.mid");
            Player pw = Manager.createPlayer(iw, "audio/x-wav");
            Player pm = Manager.createPlayer(im, "audio/midi");
            if (pw != null && pm != null) {
                pm.start();
                pw.start();
                // EARLY check (+300 ms): оба ещё ЗВУЧАТ -> оба STARTED (400)
                Thread.sleep(300);
                System.out.println("TA:P10:EARLY STATE_WAV=" + pw.getState()
                        + " STATE_MIDI=" + pm.getState());
                // +1200 ms: короткие t1.wav/t9.mid уже доиграли — смотрим
                // media-time: ОБА должны продвинуться >=0.5 c co-sounding.
                Thread.sleep(900);
                long mtw = pw.getMediaTime();
                long mtm = pm.getMediaTime();
                System.out.println("TA:P10:STATE_WAV=" + pw.getState()
                        + " STATE_MIDI=" + pm.getState()
                        + " MT_WAV=" + mtw + " MT_MIDI=" + mtm);
                pw.close();
                pm.close();
            } else {
                System.out.println("TA:P10:NULL-PLAYER w=" + pw + " m=" + pm);
            }
        } catch (Exception e) {
            System.out.println("TA:P10:EXC " + e);
        }
        try { Thread.sleep(250); } catch (InterruptedException ie) {}

        System.out.println("TA:DONE");
        notifyDestroyed();
    }

    public void startApp() {
        Thread t = new Thread(new Runnable() {
            public void run() { runPhases(); }
        });
        t.start();
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}
}
