#!/bin/bash
# v36.15 автотест: per-game поворот экрана + разрешение 176x220 + окно
# описаний настроек. Сценарий:
#   главное меню -> Настройки (всплывающие описания рисуются всегда) ->
#   навигация по строкам -> назад -> Управление (проверка-wrap к 0) ->
#   Открыть игру -> sub/TestDosWrite.jar с pergame ini:
#     res=176x220, rotation=right
#   -> сессия обязана стартовать с rot=right и повёрнутой геометрией
#      (bg 27x28 — от повёрнутой 220x176, а не от канвы 176x220).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_rotation
rm -rf "$D"; mkdir -p "$D/roms/sub" "$D/pergame"
cp scripts/testdosw/TestDosWrite.jar "$D/roms/sub/"
# per-game ini: явное разрешение 176x220 + поворот вправо (числовая форма
# тоже валидна, но берём словесную — как пишет сам UI)
cat > "$D/pergame/TestDosWrite.jar.ini" <<'EOF'
# nojme per-game settings (v36.15 autotest)
res=176x220
scale=fit_black
filter=nearest
flip=inherit
vm_speed=inherit
tex_filter=inherit
rotation=right
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# меню: sel=0 Открыть -> DOWN (Настройки) -> A (вход, описания) -> DOWN x3 ->
# UP -> B (назад) -> DOWN x2 (wraps: Управление -> Открыть) -> A (браузер) ->
# A (sub) -> A (jar) -> EXIT
export NOJME_SWITCH_KEYS="DOWN:300,A:400,DOWN:300,DOWN:300,DOWN:300,UP:300,B:400,DOWN:250,DOWN:250,A:400,A:400,A:400,EXIT:9000"

timeout 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
grep -q "TDW:DONE ALL DOS CHECKS PASSED" "$D/err.log" || { echo "FAIL: игра не выполнилась"; ok=0; }
grep -q "pergame settings loaded.*res=176x220.*rot=1" "$D/err.log" || { echo "FAIL: pergame ini не прочитан (res/rot)"; ok=0; }
grep -q "per-game rotation: 90 right" "$D/err.log" || { echo "FAIL: main.c не применил поворот"; ok=0; }
# game session строка: канва 176x220, rot=right, bg от ПОВЁРНУТОЙ 220x176:
# bg = 220/8=27 x 176/8=22 -> 27x22
grep -q "game session 176x220 (scale=1 filter=0 bg=27x22 rot=right)" "$D/err.log" || { echo "FAIL: game_begin не в повёрнутой геометрии"; ok=0; }
grep -q "session complete — back to menu" "$D/err.log" || { echo "FAIL: нет возврата в меню"; ok=0; }
grep -q "menu session end (result=0)" "$D/err.log" || { echo "FAIL: приложение не вышло из меню"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }

# второй прогон: rotation=left + словесная форма и «off»-переход (числовая 2)
cat > "$D/pergame/TestDosWrite.jar.ini" <<'EOF'
res=176x220
rotation=left
EOF
rm -f "$D/log.txt"
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,EXIT:9000"  # sel=0 уже Открыть
timeout 90 ./bin/switchui-verify > "$D/out2.log" 2> "$D/err2.log"
grep -q "game session 176x220 (scale=1 filter=0 bg=27x22 rot=left)" "$D/err2.log" || { echo "FAIL: rot=left не применился"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "SWITCH-ROTATION E2E: ALL CHECKS PASSED"
else
    echo "SWITCH-ROTATION E2E: FAILED — последние строки err.log:"; tail -25 "$D/err.log"
fi
exit $((1 - ok))
