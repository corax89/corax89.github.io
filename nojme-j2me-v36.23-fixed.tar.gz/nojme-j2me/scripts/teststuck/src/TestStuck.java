/* v36.05 [MIDLET-STUCK] self-recovery repro.
 *
 * The Doom RPG [Rus] 2nd-launch signature (trace v36.04):
 *   - the game's loader thread dies ~1.2 s into the load with an uncaught
 *     NPE (thrown inside the game's own catch-handler: c.toString());
 *   - the midlet's main thread then spins in pure bytecode forever
 *     (last native: Runtime.freeMemory; no paints, no new natives);
 *   - the frontend loop stays ALIVE (pause/menu work), the session never
 *     ends, the user stares at the loading screen.
 *
 * Test topology mirrors it: the MIDlet main thread (executed on the
 * frontend loop) STARTS two worker threads and RETURNS — a loader that
 * dies with an uncaught NPE, and a spinner that spins in pure bytecode
 * (the hung "m" role). Expected v36.05 behavior:
 *   [VM-THREAD-DEATH] ... uncaught exception java/lang/NullPointerException
 *   [VM-THREAD-DEATH]  at ... one line per frame (full stack)
 *   [EX-THROW] java/lang/NullPointerException at ...Loader.run PC=..
 *   ~15 s later: [MIDLET-STUCK] -> graceful exit -> session end -> menu.
 * PASS = "game: session end" + "session-reset" appear without any user
 * input after the death, and the process survives.
 */
public class TestStuck extends javax.microedition.midlet.MIDlet {

    static class Loader extends Thread {
        public void run() {
            try { Thread.sleep(1000); } catch (InterruptedException e) { }
            String s = null;
            int n = s.length(); /* NPE, uncaught */
            System.out.println("NEVER " + n);
        }
    }

    static class Spinner extends Thread {
        public void run() {
            /* pure-Java spin: no natives, no paint, no sleep */
            int x = 1;
            while (!stop) {
                x = x * 31 + 7;
                if (x < 0) x = 1;
            }
            System.out.println("SPINNER: ended");
        }
    }

    static boolean stop = false;

    protected void startApp() {
        System.out.println("STUCK-TEST: starting loader + spinner");
        new Loader().start();
        new Spinner().start();
        /* startApp RETURNS - the frontend loop stays alive (like the
         * field hang: menu/pause worked, the VM was dead air). */
    }

    protected void pauseApp() { }
    protected void destroyApp(boolean u) {
        System.out.println("STUCK-TEST: destroyApp called");
        stop = true;
    }
}
