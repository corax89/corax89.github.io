#!/bin/bash
# Build TestStuck.jar — v36.05 [MIDLET-STUCK] self-recovery repro.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestStuck.java" \
    "$D/../testrms/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestStuck\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestStuck.jar" META-INF && zip -q "$D/TestStuck.jar" *.class )
echo "built: $D/TestStuck.jar"
