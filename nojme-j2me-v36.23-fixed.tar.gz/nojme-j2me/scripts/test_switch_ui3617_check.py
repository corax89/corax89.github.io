#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Пиксельные проверки дампов канвы v36.17 (test_switch_ui3617.sh).

Тест 1 (dump1, без игры):
  A) главное меню: зона слогана (x 36..700, y 350..392) — чистый фон
     (надпись «MIDP2 ...» убрана);
  B) настройки: в полосе подсказок (y 524..556) есть светлые пиксели текста
     scale 2 (описание выделенного пункта);
  C) «Управление»: у ПРАВОЙ колонки (x 700..940, y 130..170) есть акцентные
     пиксели заголовка «В меню:», у левой (x 36..300) — своего;
  D) анимация курсора: среди дампов настроек есть кадр, где синяя полоса
     выделения НЕ на стандартной позиции строки (движение поймано) — или
     хотя бы полоса всегда в разумных границах списка.

Тест 2 (dump2, AsiaRally3D + PLUS):
  E) «Настройки игры»: кадр ПОД меню не однотонный (много уникальных
     цветов в центральной зоне) — игра видна сквозь затемнение;
  F) тот же кадр: зона строк списка содержит белый текст (строки читаемы).
"""
import glob
import os
import sys

from PIL import Image

BG = (0x10, 0x13, 0x1A)
COL_BG_ALT = (0x18, 0x1C, 0x26)


def load_sorted(path_pattern):
    fs = sorted(glob.glob(path_pattern))
    return [(f, Image.open(f).convert('RGB')) for f in fs]


def near(p, ref, tol):
    return all(abs(p[i] - ref[i]) <= tol for i in range(3))


def count_matching(im, box, pred):
    x0, y0, x1, y1 = box
    px = im.load()
    n = 0
    for y in range(y0, y1):
        for x in range(x0, x1):
            if pred(px[x, y]):
                n += 1
    return n


def unique_colors(im, box, limit=100000):
    x0, y0, x1, y1 = box
    px = im.load()
    seen = set()
    for y in range(y0, y1):
        for x in range(x0, x1):
            seen.add(px[x, y])
            if len(seen) > limit:
                break
    return len(seen)


def main():
    d = sys.argv[1]
    n1 = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    n2 = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    fails = []
    oks = []

    d1 = load_sorted(os.path.join(d, 'dump1', 'ui_*.ppm'))
    d2 = load_sorted(os.path.join(d, 'dump2', 'ui_*.ppm'))

    if not d1:
        fails.append('dump1 пуст — нет дампов теста 1')
    if n2 > 0 and not d2:
        fails.append('dump2 пуст, хотя pgset открывался')

    # --- A) главное меню без слогана: ищем кадр с 3 строками меню (фон за
    # последней строкой чистый в зоне бывшего слогана y 350..392).
    tagline_zone = (36, 350, 700, 392)
    checked = 0
    for f, im in d1:
        # признак главного меню: заголовок «J2ME Эмулятор» сверху слева и
        # зона слогана полностью фоновая БЕЗ синей полосы выделения.
        # Полоса выделения синяя 0x2E7CF6; если слоган рисован, в зоне будут
        # серые пиксели текста 0x8A93A6.
        grey_text = count_matching(im, tagline_zone, lambda p: near(p, (0x8A, 0x93, 0xA6), 40))
        if grey_text == 0:
            checked += 1
    if checked == 0:
        fails.append('A: во всех кадрах в зоне слогана есть текст (надпись не убрана?)')
    else:
        oks.append('A: слоган отсутствует (%d кадров главного меню чисты)' % checked)

    # --- B) подсказки scale 2: ищем кадр настроек — полоса 514..660 содержит
    # светлый текст (0xE8ECF4) и рамку окна; высота текста scale 2 =>
    # строки глифов не менее 24px сплошной плотности. Проще: есть >=200
    # светлых пикселей в y 524..556 (первая строка описания, глиф 32px).
    hint_frames = 0
    for f, im in d1:
        light = count_matching(im, (48, 522, 1240, 558), lambda p: p[0] > 200 and p[1] > 200 and p[2] > 200)
        if light >= 200:
            hint_frames += 1
    if hint_frames == 0:
        fails.append('B: не найден кадр с текстом подсказки scale 2 в полосе описаний')
    else:
        oks.append('B: подсказка scale 2 рисуется (%d кадров)' % hint_frames)

    # --- C) «Управление»: правая колонка «В меню:» (акцент 0x2E7CF6) в
    # x 700..940, y 130..170, ПРИ ОТСУТСТВИИ полосы выделения на всю ширину
    # (иначе это экран настроек с синим хайлайтом строки). Левая колонка —
    # x 36..300, и заголовок «Назначенные кнопки» длиннее «Настройки».
    keys_right = 0
    keys_left = 0
    for f, im in d1:
        px = im.load()
        # экран настроек: полоса выделения на y=140 в центре — синяя
        p_mid = px[640, 140]
        is_strip = near(p_mid, (0x2E, 0x7C, 0xF6), 30)
        acc_r = count_matching(im, (700, 130, 940, 172), lambda p: near(p, (0x2E, 0x7C, 0xF6), 40))
        acc_l = count_matching(im, (36, 130, 300, 172), lambda p: near(p, (0x2E, 0x7C, 0xF6), 40))
        if acc_r >= 50 and not is_strip:
            keys_right += 1
        if acc_l >= 50 and not is_strip:
            keys_left += 1
    if keys_right == 0:
        fails.append('C: правая колонка «Управления» не найдена')
    else:
        oks.append('C: экран «Управление» двухколоночный (%d кадров с правой колонкой)' % keys_right)
    if keys_left == 0:
        fails.append('C: левая колонка «Управления» не найдена')
    else:
        oks.append('C: левая колонка на месте')

    # --- D) анимация курсора: среди кадров настроек полоса выделения должна
    # встречаться на РАЗНЫХ y (движение между строками) и оставаться в
    # границах списка (y 130..520).
    sel_ys = set()
    for f, im in d1:
        # синяя полоса 0x2E7CF6 шириной почти во весь список
        px = im.load()
        for y in range(130, 524):
            p = px[640, y]
            if near(p, (0x2E, 0x7C, 0xF6), 30):
                sel_ys.add(y)
                break
    if len(sel_ys) >= 2:
        oks.append('D: полоса выделения видна на разных y (движение есть): %s' % sorted(sel_ys))
    elif len(sel_ys) == 1:
        oks.append('D: полоса стабильна на y=%s (анимация между кадрами не поймана — не фатально)' % list(sel_ys))
    else:
        fails.append('D: синяя полоса выделения не найдена ни в одном кадре')

    # --- E/F) прозрачный фон «Настроек игры» ---
    pg_frames = 0
    best_unique = 0
    best_luma = 0.0
    white_frames = 0
    for f, im in d2:
        # признак per-game экрана: заголовок «НАСТРОЙКИ ИГРЫ» — светлый текст
        # в шапке слева (x 32..500, y 46..80). Считаем кадры с большим числом
        # уникальных цветов в центральной зоне (игра видна).
        title = count_matching(im, (32, 46, 500, 82), lambda p: p[0] > 200 and p[1] > 200 and p[2] > 200)
        if title < 100:
            continue
        pg_frames += 1
        box = (100, 300, 1180, 500)
        uniq = unique_colors(im, box)
        # средняя яркость зоны: плоский бленд чёрного даёт ~12; любой
        # реальный кадр игры светлее/пёстрее
        px = im.load()
        tot = 0
        n = 0
        for y in range(box[1], box[3], 3):
            for x in range(box[0], box[2], 3):
                p = px[x, y]
                tot += (p[0] + p[1] + p[2]) / 3
                n += 1
        luma = tot / max(n, 1)
        if uniq > best_unique:
            best_unique = uniq
        if luma > best_luma:
            best_luma = luma
        white = count_matching(im, (40, 140, 1240, 500), lambda p: p[0] > 220 and p[1] > 220 and p[2] > 220)
        if white >= 300:
            white_frames += 1
    if n2 > 0:
        if pg_frames == 0:
            fails.append('E: не найдено ни одного кадра «Настроек игры» (заголовок)')
        else:
            # плоский фон (не видно игру): уникальных <= ~10 и яркость ~12
            if best_unique < 25 and best_luma < 30.0:
                fails.append('E: фон «Настроек игры» однотонный (uniq=%d luma=%.1f) — игра не видна'
                             % (best_unique, best_luma))
            else:
                oks.append('E: игра видна за настройками (uniq=%d, luma=%.1f)' % (best_unique, best_luma))
        if white_frames == 0:
            fails.append('F: строки настроек игры без светлого текста')
        else:
            oks.append('F: текст строк читаем поверх кадра (%d кадров)' % white_frames)

    print('--- v36.17 pixel checks ---')
    for s in oks:
        print('PASS:', s)
    for s in fails:
        print('FAIL:', s)
    if not fails:
        print('UI3617 PIXEL CHECKS: ALL PASSED')
        return 0
    print('UI3617 PIXEL CHECKS: FAILED (%d)' % len(fails))
    return 1


if __name__ == '__main__':
    sys.exit(main())
