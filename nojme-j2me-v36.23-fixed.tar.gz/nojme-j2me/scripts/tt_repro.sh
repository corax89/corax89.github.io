#!/bin/bash
# Разведка: Treasure Towers — запуск 1 (выход через меню паузы), затем запуск 2.
# Цель: увидеть, какая ошибка показывается на втором запуске.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tt_repro
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp "games/Treasure Towers (1.3)[128x160].jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"          # изолированный RMS
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_SESSIONS=2
export NOJME_SWITCH_AUTOTEST_EXIT_MS=20000
# Сессия 1: старт ~1с, пауза на 8с, «Выйти» ~8.8с; сессия 2 стартует ~11с,
# пауза на 25с, «Выйти» ~25.8с.
export NOJME_FRONT_KEYS="MINUS:8000,DOWN:400,DOWN:400,A:900,MINUS:25000,DOWN:400,DOWN:400,A:900"

timeout -k 5 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc"

echo "=== session markers ==="
grep -ah "session" "$D/err.log" "$D/log.txt" 2>/dev/null | grep -ai "start\|complete" | head -20 || true

echo "=== errors / exceptions ==="
grep -ah -i "exception\|error" "$D/log.txt" "$D/err.log" 2>/dev/null | head -60 || true

echo "=== UNCAUGHT banners ==="
grep -ahc "UNCAUGHT" "$D/log.txt" "$D/err.log" 2>/dev/null | awk '{s+=$1} END{print s+0}' || true

echo "=== tail err.log ==="
tail -40 "$D/err.log"
