#!/bin/bash
# v36.18 автотест: счётчик кадров = полоса FPS в пустой области СЛЕВА от
# игры (точка (4,4) ПОЛНОГО экрана 1280x720), ТОЛЬКО FPS, обновление
# раз в секунду.
# Сценарий (sandbox, AsiaRally3D — настоящая сцена с settled-кадрами):
#   settings.ini: frame_counter=on
#   меню: A -> запуск игры -> 8 c работы (несколько секундных окон) -> EXIT
# Проверки: одноразовый лог «fps strip on» (полоса создана и нарисована),
# сессия завершилась чисто, нет крашей/STUCK, exit code 0.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_fpsstrip
rm -rf "$D"; mkdir -p "$D/roms" "$D/pergame"
cp "games/AsiaRally3D.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
frame_counter=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:60000"
# в игре 8 c работы (несколько секундных окон) -> MINUS (пауза) -> B (в меню)
# v36.19: MINUS открывает ЕДИНОЕ меню паузы (Продолжить/Настройки игры/Выйти);
# DOWN,DOWN,A — курсор на «Выйти» и активация (раньше был просто B)
export NOJME_FRONT_KEYS="MINUS:8000,DOWN:400,DOWN:400,A:900"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
[ "$rc" -eq 0 ] || { echo "FAIL: ненулевой exit code"; ok=0; }
grep -q "fps strip on:" "$D/err.log" || { echo "FAIL: полоса FPS не включилась (нет 'fps strip on')"; ok=0; }
grep -q "session complete — back to menu" "$D/err.log" || { echo "FAIL: сессия не завершилась чисто"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }
STUCK=$(grep -ac "STUCK:" "$D/log.txt" 2>/dev/null || true)
[ "${STUCK:-0}" -gt 0 ] && { echo "FAIL: STUCK в логе ($STUCK)"; ok=0; }

if [ "$ok" -eq 1 ]; then
    echo "SWITCH-FPSSTRIP E2E: ALL CHECKS PASSED"
else
    echo "SWITCH-FPSSTRIP E2E: FAILED"
    exit 1
fi
