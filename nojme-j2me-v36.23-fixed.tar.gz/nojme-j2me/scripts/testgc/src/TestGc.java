import javax.microedition.midlet.MIDlet;

public class TestGc extends MIDlet {
    public void startApp() {
        System.out.println("GCSTORM:START");
        byte[][] live = new byte[200][];
        for (int i = 0; i < live.length; i++) {
            live[i] = new byte[10240];
            live[i][0] = (byte) i;
        }
        System.out.println("GCSTORM:LIVE-DONE");
        for (int i = 0; i < 200; i++) {
            byte[] junk = new byte[8192];
            junk[0] = (byte) i;
        }
        System.out.println("GCSTORM:CHURN-DONE");
        long t0 = System.currentTimeMillis();
        final int N = 1200;
        for (int i = 0; i < N; i++) {
            System.gc();
        }
        long t1 = System.currentTimeMillis();
        System.out.println("GCSTORM:DONE explicit=" + N + " ms=" + (t1 - t0));
        notifyDestroyed();
    }
    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}
}
