#!/bin/bash
# Build TestGc.jar — v35.07 selftest for the explicit-gc debounce.
# Run:  ./bin/j2me-headless scripts/testgc/TestGc.jar
# Expect SYSOUT: "GCSTORM:DONE explicit=1200 ms=<small>" (v35.07: ~13 real
# GCs; v35.06 semantics ran all 1200 stop-the-world collections).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=...)"; exit 1; }
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestGc.java" \
    "$D/../testdosw/stubs/javax/microedition/midlet/"*.java
PKG="$OUT/pkg"; rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestGc\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/TestGc.class" "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestGc.jar" META-INF && zip -q "$D/TestGc.jar" TestGc.class )
echo "built: $D/TestGc.jar"
