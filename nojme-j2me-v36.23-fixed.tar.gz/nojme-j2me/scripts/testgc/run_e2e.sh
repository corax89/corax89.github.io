#!/bin/bash
# v35.07 selftest: explicit System.gc() debounce, driven through the
# switchui-verify frontend (headless binary does not echo [SYSOUT]).
# PASS: [SYSOUT] GCSTORM:DONE explicit=1200 ms=<small> in the run log
# (v35.06 semantics: 1200 stop-the-world collections — visibly larger ms=).
set -e
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/sw_gchint
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/testgc/TestGc.jar "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1  # v35.08: diag lines follow the logging gate
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:400,A:400,A:400,B:8000"

timeout 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

if grep -q "GCSTORM:DONE explicit=1200" "$D/err.log"; then
    grep "GCSTORM" "$D/err.log"
    echo "GC-DEBOUNCE E2E: LINE PRESENT"
else
    echo "GC-DEBOUNCE E2E: FAILED — no GCSTORM line"; tail -25 "$D/err.log"; exit 1
fi
