#!/bin/bash
# v36.20 автотест: фильтр scale2x — сессия игры с новой 2x-текстурой.
# Фикс v36.20: fit растяжение Scale2x БЕЗ сглаживания (раньше 2x-текстура
# создавалась с hint "1"/linear и GPU размывал результат Scale2x).
# Сценарий (sandbox, AsiaRally3D):
#   settings.ini: filter=scale2x
#   меню: A -> запуск игры -> 6 c работы ->
#   пауз-меню v36.19: MINUS -> DOWN,DOWN («Выйти») -> A -> выход в меню ->
#   меню: EXIT (+30 c после возобновления цикла меню) -> чистый выход
# Проверки:
#   - одноразовый лог «scale2x: ... (..., fit=nearest v36.20)» — текстура
#     создана, ядро запущено, режим nearest записан;
#   - лог сессии filter=2;
#   - сессия завершилась чисто, нет крашей/STUCK, exit code 0.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_s2x
rm -rf "$D"; mkdir -p "$D/roms" "$D/pergame"
cp "games/AsiaRally3D.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=scale2x
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:30000"
export NOJME_FRONT_KEYS="MINUS:6000,DOWN:400,DOWN:400,A:900"

timeout -k 5 45 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
[ "$rc" -eq 0 ] || { echo "FAIL: ненулевой exit code"; ok=0; }
grep -q "scale2x: .*fit=nearest v36.20" "$D/err.log" || \
  { echo "FAIL: нет лога scale2x (fit=nearest v36.20)"; ok=0; }
grep -q "game session .*filter=2" "$D/err.log" || \
  { echo "FAIL: сессия без filter=2"; ok=0; }
grep -q "session complete — back to menu" "$D/err.log" || \
  { echo "FAIL: сессия не завершилась чисто"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }
STUCK=$(grep -ac "STUCK:" "$D/log.txt" 2>/dev/null || true)
[ "${STUCK:-0}" -gt 0 ] && { echo "FAIL: STUCK в логе ($STUCK)"; ok=0; }

echo "--- ключевые строки ---"
grep "scale2x" "$D/err.log" | head -3 || true
grep "game session" "$D/err.log" | head -2 || true

if [ "$ok" -eq 1 ]; then
    echo "SWITCH-S2X E2E: ALL CHECKS PASSED"
else
    echo "SWITCH-S2X E2E: FAILED"
    exit 1
fi
