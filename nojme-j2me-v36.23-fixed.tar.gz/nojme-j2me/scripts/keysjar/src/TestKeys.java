import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

/**
 * v36.23 TestKeys — E2E proof of the [KEY-STUCK] fix (RIGHT sticks in games).
 *
 * A plain Canvas that LOGS every keyPressed/keyRepeated/keyReleased with a
 * small per-(kind,code) print cap so the E2E log stays readable:
 *   [JK] pressed -4 / [JK] repeated -4 / [JK] released -4 ...
 *
 * Two properties are observable from the sandbox log:
 *   1) REPEAT SLOTS (v36.23 FIX-A): holding RIGHT must repeat ONLY -4.
 *      The old shared-slot code (all extended keycodes clamped to one
 *      repeat slot) fired repeated -1/-2/-3/-4 together.
 *   2) PAUSE FLUSH (v36.23 FIX-B): a game key held at pause-menu open and
 *      released inside the menu must produce a real keyReleased after the
 *      menu closes. The sandbox NEVER sees a release edge (FRONT_KEYS is
 *      press-only), so any "released -4" line proves the flush delivered it.
 *
 * Driven by scripts/test_switch_keystuck.sh.
 */
public class TestKeys extends MIDlet {

    static final int CAP = 4; /* print at most CAP first events per (kind,code) */
    static int[] cP  = new int[128];
    static int[] cR  = new int[128];
    static int[] cRl = new int[128];

    static int idx(int code) {
        int i = code + 16;             /* -16..111 -> 0..127 */
        if (i < 0 || i > 127) i = 0;   /* out-of-range codes share slot 0 */
        return i;
    }

    static void mark(String kind, int code, int[] ctr) {
        int i = idx(code);
        if (ctr[i] < CAP) {
            ctr[i]++;
            System.out.println("[JK] " + kind + " " + code + " (n=" + ctr[i] + ")");
        }
    }

    static class KeysCanvas extends Canvas {
        int alive = 0;
        protected void paint(Graphics g) {
            g.setColor(0x001018);
            g.fillRect(0, 0, getWidth(), getHeight());
            if ((++alive % 5) == 1) System.out.println("[JK] alive " + alive);
            try { Thread.sleep(300); } catch (InterruptedException e) {}
            repaint();
        }
        protected void keyPressed(int code)  { mark("pressed",  code, cP);  }
        protected void keyRepeated(int code) { mark("repeated", code, cR);  }
        protected void keyReleased(int code) { mark("released", code, cRl); }
    }

    protected void startApp() {
        System.out.println("[JK] start");
        Display.getDisplay(this).setCurrent(new KeysCanvas());
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean unconditional) {}
}
