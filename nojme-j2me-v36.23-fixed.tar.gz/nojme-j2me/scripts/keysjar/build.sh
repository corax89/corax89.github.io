#!/bin/bash
# Build TestKeys.jar — v36.23 [KEY-STUCK] selftest: a Canvas that logs
# keyPressed/keyRepeated/keyReleased (per-(kind,code) print cap 4).
# Driven by scripts/test_switch_keystuck.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestKeys.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TK, , TestKeys\r\nMIDlet-Name: TestKeys\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestKeys*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestKeys.jar" META-INF && zip -q "$D/TestKeys.jar" *.class )

echo "built: $D/TestKeys.jar"
