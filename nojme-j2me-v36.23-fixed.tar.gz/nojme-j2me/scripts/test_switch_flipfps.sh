#!/bin/bash
# v36.16 автотест: живой флип 3D (без перезапуска игры) + счётчик кадров с FPS.
# Сценарий (sandbox, AsiaRally3D — настоящая M3G-сцена):
#   settings.ini: frame_counter=on (v36.18: полоса FPS слева от игры в
#                 точке (4,4) полного экрана, обновление раз в секунду)
#   меню: A,A -> запуск игры
#   в игре: PLUS:15000 (МЕНЮ ПАУЗЫ v36.19) -> DOWN -> A (пункт «Настройки
#           игры» -> per-game экран) -> DOWN x3 (строка «Флип 3D») ->
#           A (наследовать -> Выкл, сохранение ini) -> A (Выкл -> Авто) ->
#           B (закрыть настройки -> назад в меню паузы; смена флипа обязана
#           примениться БЕЗ перезапуска) -> B (продолжить) ->
#           MINUS (пауза) -> DOWN,DOWN,A (пункт «Выйти» -> выход в меню) -> EXIT
# Проверки: pgset open/close, pergame ini получил flip=auto, сессия
# завершилась чисто, settled-кадры шли после закрытия PLUS (флип применён
# на живом рендере), нет крашей/STUCK.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_flipfps
rm -rf "$D"; mkdir -p "$D/roms" "$D/pergame"
cp "games/AsiaRally3D.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
frame_counter=on
EOF
# ini ДО PLUS: флип per-game не задан (наследовать)
cat > "$D/pergame/AsiaRally3D.jar.ini" <<'EOF'
flip=inherit
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:60000"
# в игре: PLUS:15000 (МЕНЮ ПАУЗЫ v36.19) -> DOWN (пункт «Настройки игры»)
# -> A (открыть per-game экран) -> DOWN x3 (0=res,1=scale,2=filter,3=flip)
# -> A,A -> B (закрыть настройки -> назад в меню паузы) -> B (продолжить;
# смена флипа обязана примениться БЕЗ перезапуска) ->
# MINUS (пауза снова) -> DOWN,DOWN,A (пункт «Выйти» -> выход в меню)
export NOJME_FRONT_KEYS="PLUS:15000,DOWN:600,A:800,DOWN:300,DOWN:300,DOWN:300,A:300,A:300,B:600,B:800,MINUS:6000,DOWN:400,DOWN:400,A:900"

timeout -k 5 100 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1
grep -q "pgset: open" "$D/log.txt" 2>/dev/null || { echo "FAIL: per-game экран не открывался"; ok=0; }
grep -q "pgset: close" "$D/log.txt" 2>/dev/null || { echo "FAIL: per-game экран не закрылся"; ok=0; }
grep -q "flip=auto" "$D/pergame/AsiaRally3D.jar.ini" || { echo "FAIL: pergame ini не сохранил flip=auto"; ok=0; }
grep -q "session complete — back to menu" "$D/err.log" || { echo "FAIL: сессия не завершилась чисто"; ok=0; }
grep -q "menu: session end" "$D/log.txt" 2>/dev/null || { echo "FAIL: нет возврата в меню"; ok=0; }
grep -qi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }
STUCK=$(grep -ac "STUCK:" "$D/log.txt" 2>/dev/null || true)
[ "${STUCK:-0}" -gt 0 ] && { echo "FAIL: STUCK в логе ($STUCK)"; ok=0; }

# settled-кадры/бинды ПОСЛЕ закрытия PLUS (флип сменился на живом рендере):
# diag-строка в окне (pgset: close .. pause: open) обязана показать fl>0 и
# bn>0 (кадры и M3G-бинды продолжились с новым режимом флипа).
if [ -f "$D/log.txt" ]; then
    L0=$(grep -an "pgset: close" "$D/log.txt" | head -1 | cut -d: -f1)
    L1=$(grep -an "pause: open" "$D/log.txt" | tail -1 | cut -d: -f1)
    if [ -n "$L0" ] && [ -n "$L1" ] && [ "$L1" -gt "$L0" ]; then
        WIN=$(sed -n "${L0},${L1}p" "$D/log.txt")
        FL=$(echo "$WIN" | grep -oE "fl=[0-9]+" | grep -oE "[0-9]+" | sort -n | tail -1)
        BN=$(echo "$WIN" | grep -oE "bn=[0-9]+" | grep -oE "[0-9]+" | sort -n | tail -1)
        echo "после закрытия PLUS (окно до паузы): fl=${FL:-0} bn=${BN:-0}"
        [ "${FL:-0}" -gt 0 ] || { echo "FAIL: нет settled-кадров после смены флипа"; ok=0; }
        # bn — информационно: в меню-фазах игры M3G-биндов нет (это норма)
    else
        echo "FAIL: нет окна pgset close .. pause open"; ok=0
    fi
fi

if [ "$ok" = 1 ]; then echo "SWITCH-FLIPFPS E2E: ALL CHECKS PASSED"; else
    echo "--- log tail:"; tail -30 "$D/log.txt" 2>/dev/null; exit 1
fi
