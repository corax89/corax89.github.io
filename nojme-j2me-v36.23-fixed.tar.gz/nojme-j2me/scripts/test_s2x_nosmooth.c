/*
 * test_s2x_nosmooth.c — v36.20 host proof for the Scale2x "no smoothing"
 * fix (sdl_graphics.c game_begin).
 *
 * Reproduces, on the host SDL2 (sandbox, dummy video + software renderer),
 * the EXACT texture-creation sequences of both code versions and measures
 * the visible result:
 *
 *   A) v36.14..v36.19 (bug): texture created with hint "1" (linear)
 *      -> GPU stretch of the 2x Scale2x buffer to the game rect BLENDs
 *         neighboring pixels -> intermediate gray shades appear.
 *
 *   B) v36.20 (fix): texture created with hint "0" + explicit
 *      SDL_SetTextureScaleMode(SDL_ScaleModeNearest) (the exact call the
 *      fixed game_begin makes) -> point sampling only -> ZERO new colors.
 *
 * Pipeline per mode: 4x4 checkerboard -- switch_scaling_scale2x() --> 8x8
 * -- upload -> RenderCopy stretched to 34x34 (non-integer 4.25x, same
 * situation as 480x640 -> 540x720 on the Switch) -- ReadPixels -> count
 * pixels that are neither pure white nor pure black.
 *
 * PASS = A has intermediate (smoothed) pixels AND B has none.
 *
 * Build (host, sandbox SDL2):
 *   gcc -Wall -Wextra -std=c11 -O2 -I src/switch \
 *       scripts/test_s2x_nosmooth.c src/switch/switch_scaling.c \
 *       -o bin/test_s2x_nosmooth -lSDL2 -lm
 */
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "switch_scaling.h"

#define SRC_W 4
#define SRC_H 4
#define DST_W 34
#define DST_H 34

static uint32_t s_src[SRC_W * SRC_H];
static uint32_t s_s2x[SRC_W * 2 * SRC_H * 2];
static uint32_t s_read[DST_W * DST_H];

/* 2x2 checkerboard: sharp edges everywhere — any linear blending is
 * immediately visible as gray. */
static void make_checkerboard(void) {
    for (int y = 0; y < SRC_H; y++) {
        for (int x = 0; x < SRC_W; x++) {
            int white = ((x / 2) + (y / 2)) % 2 == 0;
            s_src[y * SRC_W + x] = white ? 0xFFFFFFFFu : 0xFF000000u;
        }
    }
}

/* Run one stretch experiment; returns the number of intermediate
 * (neither pure-white nor pure-black) pixels in the readback. */
static int stretch_and_count(int hint_linear, int force_nearest) {
    SDL_Window* w = NULL;
    SDL_Renderer* r = NULL;
    SDL_Texture* src = NULL;
    SDL_Texture* dst = NULL;
    int intermediate = 0;

    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, hint_linear ? "1" : "0");
    w = SDL_CreateWindow("s2x", SDL_WINDOWPOS_UNDEFINED,
                         SDL_WINDOWPOS_UNDEFINED, 64, 64,
                         SDL_WINDOW_HIDDEN);
    if (!w) { fprintf(stderr, "window: %s\n", SDL_GetError()); exit(2); }
    r = SDL_CreateRenderer(w, -1, SDL_RENDERER_SOFTWARE);
    if (!r) { fprintf(stderr, "renderer: %s\n", SDL_GetError()); exit(2); }

    /* == the exact sequences from sdl_graphics.c game_begin == */
    src = SDL_CreateTexture(r, SDL_PIXELFORMAT_ARGB8888,
                            SDL_TEXTUREACCESS_STREAMING,
                            SRC_W * 2, SRC_H * 2);
    if (force_nearest && src) {
        if (SDL_SetTextureScaleMode(src, SDL_ScaleModeNearest) != 0) {
            fprintf(stderr, "SetTextureScaleMode: %s\n", SDL_GetError());
            exit(2);
        }
    }
    if (!src) { fprintf(stderr, "src tex: %s\n", SDL_GetError()); exit(2); }
    SDL_SetTextureBlendMode(src, SDL_BLENDMODE_NONE);
    if (SDL_UpdateTexture(src, NULL, s_s2x,
                          (int)(SRC_W * 2 * sizeof(uint32_t))) != 0) {
        fprintf(stderr, "update: %s\n", SDL_GetError()); exit(2);
    }

    dst = SDL_CreateTexture(r, SDL_PIXELFORMAT_ARGB8888,
                            SDL_TEXTUREACCESS_TARGET, DST_W, DST_H);
    if (!dst) { fprintf(stderr, "dst tex: %s\n", SDL_GetError()); exit(2); }

    if (SDL_SetRenderTarget(r, dst) != 0) {
        fprintf(stderr, "set target: %s\n", SDL_GetError()); exit(2);
    }
    SDL_SetRenderDrawColor(r, 0, 0, 0, 255);
    SDL_RenderClear(r);
    /* stretch the whole 2x texture into the whole target (like
     * SDL_RenderCopy(g_renderer, g_s2x_tex, NULL, &g_game_rect)) */
    if (SDL_RenderCopy(r, src, NULL, NULL) != 0) {
        fprintf(stderr, "copy: %s\n", SDL_GetError()); exit(2);
    }
    if (SDL_RenderReadPixels(r, NULL, SDL_PIXELFORMAT_ARGB8888,
                             s_read, DST_W * sizeof(uint32_t)) != 0) {
        fprintf(stderr, "readpixels: %s\n", SDL_GetError()); exit(2);
    }
    SDL_SetRenderTarget(r, NULL);

    for (int i = 0; i < DST_W * DST_H; i++) {
        uint32_t p = s_read[i] & 0x00FFFFFFu;
        if (p != 0xFFFFFFu && p != 0x000000u) intermediate++;
    }

    SDL_DestroyTexture(dst);
    SDL_DestroyTexture(src);
    SDL_DestroyRenderer(r);
    SDL_DestroyWindow(w);
    return intermediate;
}

int main(void) {
    SDL_SetMainReady();
    SDL_SetHint(SDL_HINT_VIDEODRIVER, "dummy");
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "init: %s\n", SDL_GetError());
        return 2;
    }

    make_checkerboard();
    switch_scaling_scale2x(s_src, SRC_W, SRC_H, s_s2x);

    int smoothed = stretch_and_count(1 /* hint "1" like v36.14..19 */,
                                     0);
    int crisp    = stretch_and_count(0 /* hint "0" like v36.20 */,
                                     1 /* + SDL_SetTextureScaleMode */);

    printf("scale2x 8x8 -> 34x34 stretch:\n");
    printf("  A) v36.14..v36.19 (hint \"1\", linear): intermediate pixels = %d\n",
           smoothed);
    printf("  B) v36.20 fix (hint \"0\" + SetTextureScaleMode(Nearest)): "
           "intermediate pixels = %d\n", crisp);

    SDL_Quit();

    if (smoothed > 0 && crisp == 0) {
        printf("S2X-NOSMOOTH: ALL CHECKS PASSED "
               "(bug reproduced, fix removes all smoothing)\n");
        return 0;
    }
    if (smoothed == 0) {
        printf("S2X-NOSMOOTH: INCONCLUSIVE — this SDL2 build does not "
               "blend on stretch (host renderer lacks the linear path); "
               "the Switch GPU renderer does blend (field report).\n");
        return 3;
    }
    printf("S2X-NOSMOOTH: FAILED — nearest path still produces %d "
           "intermediate pixels\n", crisp);
    return 1;
}
