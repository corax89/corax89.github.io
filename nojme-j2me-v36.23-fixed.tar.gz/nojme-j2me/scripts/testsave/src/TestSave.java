import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordEnumeration;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;

/* TestSave — v36.05 repro for "DoomRPG hangs on SECOND load" (trace v36.04:
 * uncaught NPE in c.a(StringBuffer) <- c.toString() <- DoomRPG.a(...)).
 *
 * Models the game-save lifecycle: session 1 writes a save (settings ints,
 * profile with CYRILLIC strings via writeUTF, highscore records), session
 * 2 opens the store (create=true), enumerates, decodes and VERIFIES every
 * field. Any deviation prints S:FAIL <detail>; success prints S:DONE.
 *
 * Session discrimination: NOJME test harness runs the same jar twice in
 * one process (menu -> game -> menu -> game). Session 1 sees no store and
 * writes; session 2 sees the store and verifies.
 */
public class TestSave extends MIDlet {
    static final String STORE = "TSave";

    static void log(String s) { System.out.println(s); }

    protected void startApp() {
        try {
            run();
        } catch (Throwable t) {
            log("S:EXCEPTION " + t);
            log("S:FAIL exception");
        }
        notifyDestroyed();
    }

    void run() {
        boolean exists = false;
        try {
            String[] names = RecordStore.listRecordStores();
            if (names != null) {
                for (int i = 0; i < names.length; i++) {
                    if (STORE.equals(names[i])) { exists = true; break; }
                }
            }
        } catch (Throwable t) {
            log("S:FAIL listRecordStores " + t);
            return;
        }
        log("S:session store-exists=" + exists);
        if (!exists) {
            write();
        } else {
            verify();
        }
    }

    /* DoomRPG-style save: record 1 = settings (ints/bools), record 2 =
     * profile (writeUTF Cyrillic + ints + long), records 3..5 = scores
     * (writeUTF name + int). Mirrors typical J2ME write patterns. */
    void write() {
        try {
            try { RecordStore.deleteRecordStore(STORE); } catch (Throwable t) { }

            RecordStore rs = RecordStore.openRecordStore(STORE, true);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(bos);
            dos.writeInt(3);            /* version */
            dos.writeBoolean(true);     /* sound */
            dos.writeBoolean(false);    /* vibration */
            dos.writeInt(2);            /* difficulty */
            byte[] b1 = bos.toByteArray();
            rs.addRecord(b1, 0, b1.length);

            bos = new ByteArrayOutputStream();
            dos = new DataOutputStream(bos);
            dos.writeUTF("Сержант");     /* profile name (Cyrillic) */
            dos.writeUTF("Глава 3: Лаборатория"); /* level title (Cyrillic) */
            dos.writeInt(7);             /* level */
            dos.writeInt(245);           /* hp */
            dos.writeLong(1234567890123L);
            dos.writeBoolean(true);
            byte[] b2 = bos.toByteArray();
            rs.addRecord(b2, 0, b2.length);

            for (int i = 0; i < 3; i++) {
                bos = new ByteArrayOutputStream();
                dos = new DataOutputStream(bos);
                dos.writeUTF("Игрок" + (i + 1));
                dos.writeInt(1000 - i * 111);
                byte[] b = bos.toByteArray();
                rs.addRecord(b, 0, b.length);
            }

            int n = rs.getNumRecords();
            int nid = rs.getNextRecordID();
            rs.closeRecordStore();
            log("S:WROTE records=" + n + " nextid=" + nid);
            if (n != 5) log("S:FAIL wrote " + n + " != 5");
            else log("S:WRITE-OK");
        } catch (Throwable t) {
            log("S:FAIL write " + t);
        }
    }

    void verify() {
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(STORE, true);
            int n = rs.getNumRecords();
            log("S:READ records=" + n);
            if (n != 5) {
                log("S:FAIL numRecords " + n + " != 5");
                return;
            }

            RecordEnumeration re = rs.enumerateRecords(null, null, false);
            int count = 0;
            boolean ok = true;

            /* record 1: settings */
            if (re.hasNextElement()) {
                byte[] d = re.nextRecord();
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(d));
                int ver = dis.readInt();
                boolean snd = dis.readBoolean();
                boolean vib = dis.readBoolean();
                int diff = dis.readInt();
                count++;
                if (ver != 3 || !snd || vib || diff != 2) {
                    ok = false;
                    log("S:FAIL settings v=" + ver + " snd=" + snd + " vib=" + vib + " diff=" + diff);
                }
            }

            /* record 2: profile with Cyrillic strings */
            if (re.hasNextElement()) {
                byte[] d = re.nextRecord();
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(d));
                String name = dis.readUTF();
                String level = dis.readUTF();
                int lvl = dis.readInt();
                int hp = dis.readInt();
                long tm = dis.readLong();
                bool_check(dis.readBoolean());
                count++;
                if (!"Сержант".equals(name) || !"Глава 3: Лаборатория".equals(level)
                        || lvl != 7 || hp != 245 || tm != 1234567890123L) {
                    ok = false;
                    log("S:FAIL profile name=[" + name + "] level=[" + level
                        + "] lvl=" + lvl + " hp=" + hp + " tm=" + tm);
                } else {
                    log("S:profile-ok [" + name + "] [" + level + "]");
                }
            }

            /* records 3..5: scores */
            while (re.hasNextElement()) {
                byte[] d = re.nextRecord();
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(d));
                String nm = dis.readUTF();
                int sc = dis.readInt();
                count++;
                int idx = -1;
                for (int i = 0; i < 3; i++) {
                    if (("Игрок" + (i + 1)).equals(nm) && sc == 1000 - i * 111) idx = i;
                }
                if (idx < 0) {
                    ok = false;
                    log("S:FAIL score name=[" + nm + "] score=" + sc);
                }
            }
            re.destroy();

            if (count != 5) { ok = false; log("S:FAIL enumerated " + count + " != 5"); }
            rs.closeRecordStore();

            log(ok && count == 5 ? "S:DONE ALL-OK" : "S:FAIL summary count=" + count);
        } catch (Throwable t) {
            log("S:FAIL verify " + t);
            try { if (rs != null) rs.closeRecordStore(); } catch (Throwable t2) { }
        }
    }

    /* separate helper so the boolean read is not optimized into the
     * previous line in some javac layouts */
    void bool_check(boolean b) { if (!b) log("S:FAIL profile bool"); }

    protected void pauseApp() { }
    protected void destroyApp(boolean u) { }
}
