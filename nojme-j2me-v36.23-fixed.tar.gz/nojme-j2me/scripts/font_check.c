/* v36.04 font render check — draws sample strings through the SAME
 * switch_font.c the Switch UI uses and dumps PPMs for visual inspection.
 * Build: see scripts/font_check.sh */
#include "switch/switch_font.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void dump_ppm(const char* path, const uint32_t* fb, int w, int h) {
    FILE* f = fopen(path, "wb");
    if (!f) { perror(path); exit(1); }
    fprintf(f, "P6\n%d %d\n255\n", w, h);
    for (int i = 0; i < w * h; i++) {
        uint32_t px = fb[i];
        unsigned char rgb[3] = { (unsigned char)(px & 0xFF),
                                 (unsigned char)((px >> 8) & 0xFF),
                                 (unsigned char)((px >> 16) & 0xFF) };
        fwrite(rgb, 1, 3, f);
    }
    fclose(f);
}

static void render_line(const char* path, const char* s, int scale) {
    int w = switch_font_text_width(s, scale) + 16;
    int h = switch_font_h() * scale + 16;
    uint32_t* fb = calloc((size_t)w * h, 4);
    for (int i = 0; i < w * h; i++) fb[i] = 0xFF202830u; /* dark bg */
    switch_font_draw_text(fb, w, h, 8, 8, s, 0xFFE8E8E8u, 0, scale);
    dump_ppm(path, fb, w, h);
    free(fb);
    printf("%-38s scale=%d px=%4d  \"%s\"\n", path, scale,
           switch_font_text_width(s, scale), s);
}

int main(void) {
    render_line("/tmp/font_i.png.ppm",
                "iii lll IIIlliilliillll   Shirokiy Sh SCH", 2);
    render_line("/tmp/font_ru.ppm",
                "Ш ШШ Широкая буква Ш и узкая i — пропорционально", 2);
    render_line("/tmp/font_menu.ppm",
                "Настройки | Игры | Выход | Глобальный флип 3D | Масштаб", 2);
    render_line("/tmp/font_num.ppm",
                "18 entries  240x320  v36.04  09/22", 1);
    return 0;
}
