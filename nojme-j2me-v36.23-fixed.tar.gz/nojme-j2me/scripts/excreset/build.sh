#!/bin/bash
# Build TestExcReset.jar — v36.21 [EXC-RESET] selftest: launch 1 throws an
# UNCAUGHT ArithmeticException (error screen), launch 2 (RMS flag) runs a
# clean canvas loop. Driven by scripts/test_switch_excreset.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestExcReset.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java \
    "$D/stubs/javax/microedition/rms/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TXR, , TestExcReset\r\nMIDlet-Name: TestExcReset\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestExcReset*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestExcReset.jar" META-INF && zip -q "$D/TestExcReset.jar" *.class )

echo "built: $D/TestExcReset.jar"
