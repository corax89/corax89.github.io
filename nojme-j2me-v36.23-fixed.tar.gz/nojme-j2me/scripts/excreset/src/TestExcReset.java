import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.rms.RecordStore;

/**
 * v36.21 TestExcReset — E2E proof of the [EXC-RESET] fix.
 *
 * STATEFUL ACROSS LAUNCHES (RMS flag "excreset"):
 *   launch 1: no flag -> writes the flag, then the CONSTRUCTOR divides by
 *             zero UNCAUGHT. An exception in the MIDlet CONSTRUCTOR is NOT
 *             swallowed by the startApp DRM-bypass (execute.c) — it makes
 *             jvm_run_midlet return -1 and main.c draws the fullscreen
 *             error screen ("[ERROR] java/lang/ArithmeticException").
 *   launch 2: flag found -> clean endless canvas loop.
 *
 * The SAME jar is launched twice in ONE process (NOJME_SWITCH_AUTOTEST_
 * SESSIONS=2). Session 1 leaves g_has_error armed in the frontend; the
 * fix must clear it at teardown/before the next launch. If the fix is
 * broken, session 2's game loop spends forever in the error branch and
 * "canvas alive (clean)" markers NEVER appear.
 */
public class TestExcReset extends MIDlet {

    private boolean clean = false;

    static class ArmedCanvas extends Canvas {
        protected void paint(Graphics g) {
            g.setColor(0x101018);
            g.fillRect(0, 0, getWidth(), getHeight());
            System.out.println("[EXC-RESET] canvas alive (armed)");
            try { Thread.sleep(400); } catch (InterruptedException e) {}
            repaint();
        }
    }

    static class CleanCanvas extends Canvas {
        protected void paint(Graphics g) {
            g.setColor(0x001018);
            g.fillRect(0, 0, getWidth(), getHeight());
            System.out.println("[EXC-RESET] canvas alive (clean)");
            try { Thread.sleep(400); } catch (InterruptedException e) {}
            repaint();
        }
    }

    public TestExcReset() {
        boolean flag = false;
        try {
            RecordStore rs = RecordStore.openRecordStore("excreset", true);
            if (rs.getNumRecords() > 0) {
                flag = true;
            } else {
                rs.addRecord(new byte[] { 'x' }, 0, 1);
            }
            rs.closeRecordStore();
        } catch (Throwable t) {
            System.out.println("[EXC-RESET] rms failed: " + t);
        }

        if (!flag) {
            System.out.println("[EXC-RESET] session 1: throwing ArithmeticException in constructor");
            int zero = 0;
            int boom = 42 / zero;   /* ArithmeticException "/ by zero", uncaught */
            System.out.println("[EXC-RESET] NOT REACHED: " + boom);
        } else {
            System.out.println("[EXC-RESET] ctor: flag found -> clean session");
            clean = true;
        }
    }

    protected void startApp() {
        if (clean) {
            System.out.println("[EXC-RESET] session 2: clean run");
            Display.getDisplay(this).setCurrent(new CleanCanvas());
        } else {
            /* Session 1 never reaches here (constructor threw), but the
             * tolerant VM would still show something if it did. */
            Display.getDisplay(this).setCurrent(new ArmedCanvas());
        }
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean unconditional) {}
}
