package javax.microedition.rms;

/* Compile-only stub: the VM implements the real methods natively
 * (src/midp/rms.c). Signatures follow the MIDP 2.0 spec subset used by
 * the test. */
public class RecordStore {
    public static RecordStore openRecordStore(String recordStoreName,
                                              boolean createIfNecessary)
            throws RecordStoreException, RecordStoreFullException,
                   RecordStoreNotFoundException {
        return null;
    }

    public int getNumRecords() throws RecordStoreNotOpenException {
        return 0;
    }

    public int addRecord(byte[] data, int offset, int numBytes)
            throws RecordStoreException {
        return 0;
    }

    public void closeRecordStore()
            throws RecordStoreException, RecordStoreNotOpenException {
    }
}
