document.addEventListener('DOMContentLoaded', () => {
    
    const getSort = ({ target }) => {
        const order = (target.dataset.order = -(target.dataset.order || -1));
        const index = [...target.parentNode.cells].indexOf(target);
        const collator = new Intl.Collator(['en', 'ru'], { numeric: true });
        const comparator = (index, order) => (a, b) => order * collator.compare(
            a.children[index].innerHTML,
            b.children[index].innerHTML
        );

        for(const tBody of target.closest('table').tBodies)
            tBody.append(...[...tBody.rows].sort(comparator(index, order)));

        for(const cell of target.parentNode.cells)
            cell.classList.toggle('sorted', cell === target);
    };

    document.querySelectorAll('table').forEach(tableTH => tableTH.addEventListener('click', () => getSort(event)));
    
    var h2_collection = document.getElementsByTagName('H2'),
        result = [];
    for(var i = 0; i<h2_collection.length;i++ ){
        result.push("<a>" + h2_collection[i].innerText + "<br>");
    }

    document.querySelector(".titlebar").innerHTML += result;
    
    var editor = new Editor();
    editor.render();
    
});
