# RomFS Binary Structure Specification

## File System Layout

| Section                | Offset      | Size          | Alignment | Description |
|------------------------|-------------|---------------|-----------|-------------|
| **Header**             | 0x00000000  | 0x50 bytes    | 1         | Metadata header |
| **File Data**          | 0x00000200  | Variable      | 0x10      | Actual file contents |
| **Dir Hash Table**     | Variable    | 4*N entries   | 4         | Directory lookup table |
| **Directory Table**    | Variable    | Variable      | 4         | All directory entries |
| **File Hash Table**    | Variable    | 4*M entries   | 4         | File lookup table |
| **File Table**         | Variable    | Variable      | 4         | All file entries |

## Header Structure (0x50 bytes)

| Offset | Field                 | Size  | Type     | Description |
|--------|-----------------------|-------|----------|-------------|
| 0x00   | header_size           | 0x08  | uint64_t | Always 0x50 |
| 0x08   | dir_hash_table_ofs    | 0x08  | uint64_t | Offset to directory hash table |
| 0x10   | dir_hash_table_size   | 0x08  | uint64_t | Size in bytes |
| 0x18   | dir_table_ofs         | 0x08  | uint64_t | Offset to directory entries |
| 0x20   | dir_table_size        | 0x08  | uint64_t | Size in bytes |
| 0x28   | file_hash_table_ofs   | 0x08  | uint64_t | Offset to file hash table |
| 0x30   | file_hash_table_size  | 0x08  | uint64_t | Size in bytes |
| 0x38   | file_table_ofs        | 0x08  | uint64_t | Offset to file entries |
| 0x40   | file_table_size       | 0x08  | uint64_t | Size in bytes |
| 0x48   | file_partition_ofs    | 0x08  | uint64_t | Always 0x200 |

## Directory Entry Format

| Offset | Field      | Size  | Type     | Description |
|--------|------------|-------|----------|-------------|
| 0x00   | parent     | 0x04  | uint32_t | Parent directory offset |
| 0x04   | sibling    | 0x04  | uint32_t | Next sibling directory |
| 0x08   | child      | 0x04  | uint32_t | First child directory |
| 0x0C   | file       | 0x04  | uint32_t | First file in directory |
| 0x10   | hash       | 0x04  | uint32_t | Next in hash chain |
| 0x14   | name_size  | 0x04  | uint32_t | Name length |
| 0x18   | name[]     | Variable | char[] | Directory name (4-byte aligned) |

## File Entry Format

| Offset | Field      | Size  | Type     | Description |
|--------|------------|-------|----------|-------------|
| 0x00   | parent     | 0x04  | uint32_t | Parent directory offset |
| 0x04   | sibling    | 0x04  | uint32_t | Next sibling file |
| 0x08   | offset     | 0x08  | uint64_t | Data offset from 0x200 |
| 0x10   | size       | 0x08  | uint64_t | File size |
| 0x18   | hash       | 0x04  | uint32_t | Next in hash chain |
| 0x1C   | name_size  | 0x04  | uint32_t | Name length |
| 0x20   | name[]     | Variable | char[] | Filename (4-byte aligned) |

## Hash Tables

- Both directory and file hash tables use same structure:
  - Array of uint32_t values (little-endian)
  - 0xFFFFFFFF indicates empty slot
  - Otherwise contains offset to first entry in chain

## Key Algorithms

### Hash Calculation

uint32_t calc_path_hash(uint32_t parent, const char *path, uint32_t start, uint32_t len) {
    uint32_t hash = parent ^ 123456789;
    for (uint32_t i = 0; i < len; i++) {
        hash = (hash >> 5) | (hash << 27);
        hash ^= path[start + i];
    }
    return hash;
}

Hash Table Size Calculation
c

> uint32_t romfs_get_hash_table_count(uint32_t num_entries) {
>     if (num_entries < 3) return 3;
>     if (num_entries < 19) return num_entries | 1;
>     
>     uint32_t count = num_entries;
>     while (count % 2 == 0 || count % 3 == 0 || 
>            count % 5 == 0 || count % 7 == 0 ||
>            count % 11 == 0 || count % 13 == 0 || 
>            count % 17 == 0) {
>         count++;
>     }
>     return count;
> }

Alignment Rules

    File data: 16-byte aligned (0x10)

    All metadata: 4-byte aligned

    String fields: Padded to 4-byte multiples

Special Values

    ROMFS_ENTRY_EMPTY = 0xFFFFFFFF

    Root directory:

        parent points to itself (offset 0)

        name_size = 0********