|Видеоядро|Чипсет|Техпроцесс|Частота|GFlops|
|---------|------|----------|-------|------|
|NDS |ARM946E-S (CPU) |180nm<br>130nm |67 MHz |0.6 |
|N3DS |PICA 200 |45nm |200 MHz |4.8 |
|PSP |R4000 x 2 |90nm |333 MHz |2.6 |
|PS VITA |SGX543 MP4+ |45nm |222 MHz |28.4 |
|Dreamcast |PowerVR2 CLX2 |250nm |100 MHz |2.1 |
|XBOX |NVIDIA NV2A |150nm |233 MHz |7.3 |
|XBOX 360 |ATI R500 Xenos |90nm |500 MHz |240 |
|XBOX ONE |AMD GCN 1.0 Durango |28nm |853 MHz |1311.5|
|XBOX ONE S |AMD GCN 1.0 Edmondton |16nm |914 MHz |1405.2|
|XBOX ONE X |AMD GCN 4.0 Scorpio |16nm |1172 MHz |6000 |
|PlayStation 2 |GS (Graphics Synthesize) |180nm<br>150nm<br>90nm |147 MHz |6.2 |
|PlayStation 3 |NVIDIA RSX (2006) |90nm |550 MHz |228.8 |
|PlayStation 3 |NVIDIA RSX (2008) |65nm |550 MHz |228.8 |
|PlayStation 3 |NVIDIA RSX (2010) |45nm |550 MHz |400.4 |
|PlayStation 4 |AMD GCN 1.0 Liverpool |28nm/16nm |800 MHz |1840 |
|PlayStation 4 Pro|AMD GCN 4.0 Neo |16nm |911 MHz |4200 |
|PlayStation 5 |AMD RDNA 2.0 |7nm |2230MHz |10280 |
|N64 |SGI RCP |350nm |62.5 MHz |0.2 |
|GameCube |ATI Flipper |180nm |162 MHz |9.4 |
|Wii |ATI HollyWood |90nm |243 MHz |14.1 |
|Wii U |ATI RV770 Latte |40nm |550 MHz |352 |
|Switch Undocked |Tegra X1 Maxwell |20nm (2017)<br>16nm (2019)|307.2 MHz|157.18|
|Switch Undocked |Tegra X1 Maxwell Turbo |20nm (2017)<br>16nm (2019)|384 MHz |196.6 |
|Switch Docked |Tegra X1 Maxwell |20nm (2017)<br>16nm (2019)|768 MHz |393.2 |
|Switch Docked |Tegra X1 Maxwell Turbo |20nm (2017)<br>16nm (2019)|921 MHz |471.55|
|Ouya |Tegra 3 (Geforce ULP x 12)|40nm |520 Mhz |12.5 |
|SHIELD portable |Tegra 4 (Geforce ULP x 72)|28nm |672 MHz |96.8 |
|SHIELD TV |Tegra X1 Maxwell |20nm |1000 MHz |512 |
|Adreno 130|ARM11MSM7201A|90nm|133 MHz|1.2|
|Adreno 200|"Snapdragon S1 MSM7225|65nm|133 MHz|2.1|
|Adreno 200|"Snapdragon S1 MSM7627A|45nm|145 MHz|3.92|
|Adreno 203 |Snapdragon 200 MSM8225Q<br>Snapdragon 200 MSM8625Q |45nm|294 MHz|9.4 |
|Adreno 205 |Snapdragon S2 MSM7230<br>Snapdragon S2 MSM7630<br>Snapdragon S2 MSM8255<br>Snapdragon S2 MSM8255T<br>Snapdragon S2 MSM8655<br>Snapdragon S2 MSM8655T<br>Snapdragon S2 APQ8055 |45nm|266 MHz|8.5 |
|Adreno 220 |Snapdragon S3 MSM8260<br>Snapdragon S3 MSM8660<br>Snapdragon S3 APQ8060 |45nm|266MHz |17 |
|Adreno 225 |Snapdragon S4 Plus APQ8060A<br>Snapdragon S4 Plus MSM8260A |28nm|200 MHz|12.8 |
|Adreno 225 |Snapdragon S4 Plus MSM8660A |28nm|300 MHz|19.2 |
|Adreno 225 |Snapdragon S4 Plus MSM8960 |28nm|400 MHz|25.6 |
|Adreno 302 |Snapdragon 200 MSM8210<br>Snapdragon 200 MSM8212<br>Snapdragon 200 MSM8610<br>Snapdragon 200 MSM8612 |28nm|400 MHz|19.2 |
|Adreno 304 |Qualcomm SDA212<br>Qualcomm APQ8009<br>Qualcomm 205 MSM8905<br>Snapdragon 208 MSM8208<br>Snapdragon 210 MSM8909<br>Snapdragon 212 MSM8909v2<br>Snapdragon Wear 2100 MSM8909w<br>Snapdragon Wear 2500 MSM8909w<br>Snapdragon Wear 3100 MSM8909w |28nm|400 MHz|19.2 |
|Adreno 305 |Snapdragon S4 Plus MSM8227<br>Snapdragon S4 Plus MSM8627<br>Snapdragon S4 Plus MSM8230<br>Snapdragon S4 Plus MSM8630<br>Snapdragon S4 Plus MSM8930<br>Snapdragon S4 Plus APQ8030<br>Snapdragon 400 APQ8026<br>Snapdragon 400 APQ8030AB<br>Snapdragon 400 MSM8226<br>Snapdragon 400 MSM8230<br>Snapdragon 400 MSM8230AB<br>Snapdragon 400 MSM8626<br>Snapdragon 400 MSM8630<br>Snapdragon 400 MSM8630AB<br>Snapdragon 400 MSM8926<br>Snapdragon 400 MSM8930<br>Snapdragon 400 MSM8930AB|28nm|400MHz |19.2 |
|Adreno 305 |Snapdragon 400 APQ8028<br>Snapdragon 400 MSM8228<br>Snapdragon 400 MSM8628<br>Snapdragon 400 MSM8928<br>Snapdragon 400 |28nm |450 MHz|21.6 |
|Adreno 306 |Snapdragon 410 MSM8916<br>Snapdragon 410E APQ8016E<br>Snapdragon 412 MSM8916v2 |28nm|400 MHz|21.6 |
|Adreno 308 |Qualcomm 215<br>Qualcomm APQ8017<br>Snapdragon 425 MSM8917<br>Snapdragon 427 MSM8920 |28nm|500 MHz|27 |
|Adreno 320 (64 ALU)|Snapdragon S4 Pro APQ8064<br>Snapdragon S4 Pro MSM8260A Pro<br>Snapdragon S4 Pro MSM8960T<br>Snapdragon S4 Pro MSM8960DT<br>Snapdragon S4 Pro MSM8960T Pro<br>Snapdragon S4 Prime MPQ8064 |28nm|400 MHz|57.6 |
|Adreno 320 (96 ALU)|Snapdragon 600 APQ8064-1AA<br>Snapdragon 600 APQ8064-DEB<br>Snapdragon 600 APQ8064-FLO<br>Snapdragon 600 APQ8064M<br>Snapdragon 600 APQ8064T<br>Snapdragon 600E APQ8064E |28nm|400 MHz|86.4 |
|Adreno 320 (96 ALU)|Snapdragon 600 APQ8064AB<br>Snapdragon 602A APQ8064AU |28nm |450 MHz|97.2 |
|Adreno 330 |Snapdragon 800 APQ8074AA<br>Snapdragon 800 MSM8274AA<br>Snapdragon 800 MSM8674AA<br>Snapdragon 800 MSM8974AA<br>Snapdragon 801 MSM8974AAv3 |28nm|450 MHz|129.8 |
|Adreno 330 |Snapdragon 800 MSM8274AB<br>Snapdragon 801 APQ8074AB<br>Snapdragon 801 MSM8274AC<br>Snapdragon 801 MSM8674AB<br>Snapdragon 801 MSM8974AB<br>Snapdragon 801 MSM8974AC |28nm |578 MHz|166.5 |
|Adreno 405 |Snapdragon 415 MSM8929 |28nm|465 MHz|50.2 |
|Adreno 405 |Snapdragon 610 MSM8936<br>Snapdragon 615 MSM8939<br>Snapdragon 616 MSM8939v2<br>Snapdragon 617 MSM8952 |28nm |550 MHz|59.4 |
|Adreno 418 |Snapdragon 808 MSM8992 |20nm|600 MHz|172.8 |
|Adreno 420 |Snapdragon 805 APQ8084 |28nm|600 MHz|172.8 |
|Adreno 430 |Snapdragon 810 APQ8094<br>Snapdragon 810 MSM8994 |20nm|600 MHz|388.8 |
|Adreno 430 |Snapdragon 810 MSM8994v2 |20nm|630MHz |408 |
|Adreno 430 |Snapdragon 810E APQ8094 |20nm|650MHz |421.2 |
|Adreno 504 |Snapdragon 429 SDM429 |12nm|650MHz |421.2 |
|Adreno 505 |Snapdragon 430 MSM8937<br>Snapdragon 435 MSM8940<br>Snapdragon 439 SDM439 |28nm|450 MHz|48.6 |
|Adreno 506 |Snapdragon 450 SDM450 |14nm|600 MHz|120 |
|Adreno 506 |Qualcomm SDA624<br>Snapdragon 625 MSM8953<br>Snapdragon 626 MSM8953 Pro |14nm|650 MHz|130 |
|Adreno 506 |Snapdragon 632 SDM632 |14nm|624 MHz|124.8 |
|Adreno 508 |Snapdragon 630 SDM630 |14nm|850 MHz|170 |
|Adreno 509 |Snapdragon 636 SDM636 |14nm|720 MHz|184.3 |
|Adreno 510 |Snapdragon 650 MSM8956<br>Snapdragon 652 MSM8976<br>Snapdragon 653 MSM8976PRO |28nm|600 MHz|180 |
|Adreno 512 |Snapdragon 660 SDM660 |14nm|850 MHz|255 |
|Adreno 530 |Snapdragon 820 MSM8996 Lite |14nm|510 MHz|407.4 |
|Adreno 530 |Snapdragon 820 MSM8996<br>Snapdragon 820A MSM8996AU<br>Snapdragon 820E APQ8096 |14nm |624 MHz|498.5 |
|Adreno 530 |Snapdragon 821 MSM8996 Pro<br>Snapdragon 821 MSM8996 Pro-AB |14nm |650 MHz|519.2 |
|Adreno 540 |Snapdragon 835 MSM8998 |10nm|710 MHz|567 |
|Adreno 610 |Snapdragon 460 SM4250-AA |10nm|710 MHz|567 |
|Adreno 610 |Snapdragon 662 SM6115<br>Snapdragon 665 SM6125 | 14nm|710 MHz|567 |
|Adreno 612 |Snapdragon 675 SM6150 |10nm|710 MHz|567 |
|Adreno 615 |Snapdragon 670 SDM670 |10nm|700 MHz|358.4 |
|Adreno 616 |Snapdragon 710 SDM710<br>Snapdragon 712 SDM712 |10nm|750 MHz|384 |
|Adreno 618 |Snapdragon 7c<br>Snapdragon 720G MSM7125<br>Snapdragon 730 MSM7150-AA<br>Snapdragon 730G MSM7150-AB |8nm |825 MHz|422.4 |
|Adreno 620 |Snapdragon 765 MSM7250-AA<br>Snapdragon 765G MSM7250-AB |7nm |825 MHz |422.4 |
|Adreno 630 |Snapdragon 845 SDM845<br>Snapdragon 850 SDM850 |10nm|710MHz |737 |
|Adreno 640 |Snapdragon 855 SM8150 |7nm |585 MHz|899 |
|Adreno 640 |Snapdragon 855+ SM8150-AC |7nm |675 MHz|1037 |
|Adreno 650 |Snapdragon 865 SM8250 |7nm |587 MHz|1202 |
|Adreno 675 |Snapdragon 8c |7nm |587 MHz|1202 |
|Adreno 680 |Snapdragon 8cx |7nm |587 MHz|1842.5|
|Adreno 685 |Microsoft SQ1 (Based on 8cx) |7nm |587 MHz|2100 |
|Mali-400 |AML8726-M3 ||200 MHz |1.8 |
|Mali-400 |AML8726-M3 ||250 MHz |2.25 |
|Mali-400 |ST-E U8500 ||275 MHz |2.48 |
|Mali-400 |WM8850<br>WM8950<br>SC6815A<br>SC7710<br>SC8810<br>SC9820<br>Allwinner A10<br>Allwinner A10s<br>Allwinner A13 ||300 MHz |2.7 |
|Mali-400 |RK292X ||330 MHz |2.97 |
|Mali-400 |SC7715<br>SC7727S<br>ST-E U8520<br>Telechips TCC892x-i<br>Rk2926<br>RK2928<br>MT6290<br>MT8638T<br>MT6572M ||400 MHz |3.6 |
|Mali-400 |MT6570<br>MT6572<br>MT8312<br>MT8321<br>XMM6321<br>S5P4418 ||500 MHz |4.5 |
|Mali-400 |MT6570<br>MT6572<br>MT8312<br>MT8321<br>XMM6321<br>S5P4418 ||533 MHz |4.8 |
|Mali-400 MP2 |LC1810<br>LC1811 ||300 MHz |5.4 |
|Mali-400 MP2 |WM8880<br>WM8980<br>SC6825<br>SC8825<br>Allwinner A20<br>Allwinner A23<br>Allwinner A33 ||350 MHz |6.3 |
|Mali-400 MP2 |SC5735A<br>SC7730A<br>SC7730S<br>SC7731G<br>SC8830<br>SC8830A<br>SC8831G<br>SC9830A<br>SC9830I<br>SC9836<br>MT6582M<br>AML7366-M6C<br>AML8726-MX<br>AML8726-MXS<br>AML8726-MXL<br>NS115<br>LC1813<br>LC1913<br>RTD1195<br>Exynos 3250||400 MHz |7.2 |
|Mali-400 MP2 |SC8831G ||480 MHz |8.64 |
|Mali-400 MP2 |MT6580<br>MT6582<br>MT8382<br>RK3026<br>RK3036 ||500 MHz |9.0 |
|Mali-400 MP2 |RK3126<br>RK3128<br>RK3228<br>RK3229<br>Allwinner H3<br>Atom x3-C3130 ||600 MHz |10.8 |
|Mali-400 MP4 |RK3066<br>Exynos 4210 ||266 MHz |9.6 |
|Mali-400 MP4 |Exynos 4212<br>SC7735S<br>SC8735S<br>SC8835S<br>Hi3716<br>Hi3718<br>Hi3719<br>Rockchip PX2<br>AML7366-M6L ||400 MHz |14.4 |
|Mali-400 MP4 |Exynos 4412 ||440 MHz |15.84|
|Mali-400 MP4 |Exynos 3470 ||450 MHz |16.2 |
|Mali-400 MP4 |Exynos 4412 v2<br>RK3188<br>S5P6818 ||533 MHz |19.2 |
|Mali-450 |WM8860 ||300 MHz |4.5 |
|Mali-450 MP2 |AML7366-M6D ||400 MHz |12 |
|Mali-450 MP2 |Amlogic M803<br>Amlogic M805<br>Amlogic M805T<br>Amlogic M806<br>Amlogic S805 ||500 MHz |15 |
|Mali-450 MP3 |Amlogic S905<br>Amlogic S905X ||750 MHz |33.75|
|Mali-450 MP4 |MT8685 ||416 MHz |24.8 |
|Mali-450 MP4 |Kirin 620<br>Mstar 6A908<br>Mstar 6A918 ||500 MHz |29.8 |
|Mali-450 MP4 |Kirin 910 ||533 MHz |32 |
|Mali-450 MP4 |MT6588<br>MT6592M<br>MT8127<br>MT6591<br>MT6591H<br>Atom x3-C3230RK<br>Hi3796M V100<br>Hi3798M V100 ||600 MHz |35.8 |
|Mali-450 MP4 |MT6592<br>MT8392<br>Kirin 910T ||700 MHz |41.8 |
|Mali-450 MP6 |Amlogic M801<br>Amlogic M802<br>Amlogic S801<br>Amlogic S802<br>Amlogic S802H<br>Amlogic S812<br>Amlogic T866<br>Hi3796<br>Hi3798 ||600 MHz |53.8 |
|Mali-450 MP8 |\- ||600 MHz |71.7 |
|Mali-T604 |\- ||533 MHz |17 |
|Mali-T604 MP2 |\- ||533 MHz |34 |
|Mali-T604 MP4 |Exynos 5250 ||533 MHz |68.2 |
|Mali-T622 |\- ||533 MHz |8.5 |
|Mali-T624 |\- ||533 MHz |17 |
|Mali-T624 MP4 |Kirin 920<br>Kirin 925<br>Kirin 928<br>Exynos 5260 ||600 MHz |76.8 |
|Mali-T628 |\- ||533 MHz |17 |
|Mali-T628 MP2 |LC1860<br>LC1860C<br>LC1960 ||600 MHz |38.4 |
|Mali-T628 MP3 |\- ||533 MHz |51.2 |
|Mali-T628 MP4 |Kirin 930<br>Kirin 935 ||680 MHz |87 |
|Mali-T628 MP6 |Exynos 5420<br>Exynos 5422 ||533 MHz |102.4|
|Mali-T628 MP6 |Exynos 5430 ||600 MHz |115.2|
|Mali-T720 |Exynos 7270<br>Exynos 7570 ||450 MHz |7.65 |
|Mali-T720 MP2 |MT6735P<br>MT8735P ||400 MHz |13.6 |
|Mali-T720 MP2 |MT6735M<br>MT8735M ||500 MHz |17 |
|Mali-T720 MP2 |MT8163V/B ||520 MHz |17.68|
|Mali-T720 MP2 |MT6737<br>MT8735D<br>MT8735B ||550 MHz |18.7 |
|Mali-T720 MP2 |Atom x3-C3440<br>Exynos 3475<br>MT6735<br>MT6737T<br>MT8163V/A ||600 MHz |20.4 |
|Mali-T720 MP2 |Exynos 7580 ||668 MHz |22.7 |
|Mali-T720 MP3 |MT6753<br>MT6753T<br>MT8783 ||700 MHz |35.7 |
|Mali-T760 |\- ||600 MHz |20.4 |
|Mali-T760 MP2 |MT6732<br>MT6732M<br>MT8732 ||500 MHz |34 |
|Mali-T760 MP2 |MT6752<br>MT6752M<br>MT8752 ||700 MHz |47.6 |
|Mali-T760 MP4 |Mstar 6A928 ||552 MHz |75 |
|Mali-T760 MP4 |RK3288<br>RK3288-C ||600 MHz |81.6 |
|Mali-T760 MP6 |Exynos 5433<br>Exynos 7410 ||700 MHz |142.8|
|Mali-T760 MP8 |Exynos 7420 ||772 MHz |210 |
|Mali-T820 |SC9850 ||600 MHz |10.2 |
|Mali-T820 MP3 |Amlogic S912<br>Mstar 6A938 ||600 MHz |30.6 |
|Mali-T830 |\- ||600 MHz |20.4 |
|Mali-T830 MP2 |Amlogic S966<br>Amlogic T966<br>Amlogic T968 ||650 MHz |44.2 |
|Mali-T830 MP2 |Kirin 650<br>Kirin 655<br>Kirin 658 ||900 MHz |61.2 |
|Mali-T830 MP2 |Exynos 7870 ||700 MHz |47.6 |
|Mali-T830 MP3 |Exynos 7880 ||950 MHz |71.4 |
|Mali-T860 MP2 |MT6738 ||350 MHz |23.8 |
|Mali-T860 MP2 |MT6750<br>MT6738T ||520 MHz |35.3 |
|Mali-T860 MP2 |Helio P10<br>MT6755M ||550 MHz |37.4 |
|Mali-T860 MP2 |MT6750T ||650 MHz |44.2 |
|Mali-T860 MP2 |Helio P10<br>MT6755<br>MT8785 ||700 MHz |47.6 |
|Mali-T860 MP2 |MT6739<br>Helio P15<br>MT6755T ||800 MHz |54.4 |
|Mali-T860 MP3 |Exynos 7650 ||700 MHz |71.4 |
|Mali-T860 MP4 |RK3399 ||600 MHz |81.6 |
|Mali-T860 MP4 |Pinecone S1<br>V670 ||922 MHz |125.4|
|Mali-T880 MP??|LG Nuclun 2 ||850 MHz |28.9 |
|Mali-T880 MP2 |Helio P20 (MT6757) ||900 MHz |61.2 |
|Mali-T880 MP2 |Helio P25 (MT6757CD) ||1000 MHz|68 |
|Mali-T880 MP4 |SC9860GV ||1000 MHz|68 |
|Mali-T880 MP4 |Helio X20 (MT6797)<br>Helio X23 (MT6797D) ||780 MHz |106 |
|Mali-T880 MP4 |Helio X25 (MT6797T) ||850 MHz |115.6|
|Mali-T880 MP4 |Helio X27 (MT6797X) ||875 MHz |119 |
|Mali-T880 MP4 |Kirin 950<br>Kirin 955 ||900 MHz |122.4|
|Mali-T880 MP10|Exynos 8890 (Lite) ||650 MHz |221 |
|Mali-T880 MP12|Exynos 8890 ||650 MHz |265.2|
|Mali-G51 |\- ||650 MHz |265.2|
|Mali-G71 |\- ||850 MHz |28.9 |
|Mali-G71 MP2 |MT6763<br>Helio P23 (MT6763T) ||770 MHz |52.36|
|Mali-G71 MP2 |Helio P30 (MT6758) ||950 MHz |64.6 |
|Mali-G71 MP8 |Kirin 960 ||1037 MHz|282 |
|Mali-G71 MP12 |Pinecone S2? (V970) ||900 MHz |367.2|
|Mali-G71 MP18 |Exynos 8895 (Lite) ||546 MHz |334 |
|Mali-G71 MP20 |Exynos 8895 ||546 MHz |371.2|
|Mali-G72 |\- ||850 MHz |28.9 |
|Mali-G72 MP3 |Exynos 9610 ||850 MHz |28.9 |
|Mali-G72 MP12 |Kirin 970 ||850 MHz |346.8|
|Geforce ULP x 8 |Tegra 2 AP20H |40nm |300 MHz |4.8 |
|Geforce ULP x 8 |Tegra 2 T20 |40nm |333 MHz |5.3 |
|Geforce ULP x 8 |Tegra 2 AP25<br>Tegra 2 T25 |40nm |400 MHz |6.4 |
|Geforce ULP x 12 |Tegra 3 T30L<br>Tegra 3 AP33 |40nm|416 MHz|10 |
|Geforce ULP x 12|Tegra 3 T30<br>Tegra 3 T33<br>Tegra 3 AP37|40nm |520 MHz |12.5 |
|Geforce ULP x 60 |Tegra 4i |28nm |660 MHz |79.2 |
|Geforce ULP x 72 |Tegra 4 |28nm |672 MHz |96.8 |
|Kepler Cores x 192 |Tegra K1 |28nm |951 MHz |365.2|
|Maxwell Cores x 256|Tegra X1 |20nm |1000 MHz|512 |
|Maxwell Cores x 256|Tegra X1+ |16nm |1267 MHz|648.7|
|Pascal Cores x 256 |Tegra X2 |16nm |1465 MHz|750 |
|Volta Cores x 512 |Tegra Xavier  |12nm |1377 MHz|1410 |
|VivanteGC500 |PXA920 ||315 MHz|0.96|
|VivanteGC800 |RK2918 / ATM7013 / ATM7019||575 MHz|4.6 |
|VivanteGC1000 |PXA986 / PXA988 / PXA1088 ||600 MHz|9.6 |
|VivanteGC1000 Plus|ATM7029 ||630 MHz|10.1|
|VivanteGC2000 |i.MX6D / i.MX6Q ||600 MHz|19.2|
|VivanteGC4000 |K3V2 ||480 MHz|30.7|
|VivanteGC3000 |S32V234 ||800 MHz|32 |
|VivanteGC5000 |PXA1928 ||800 MHz|64 |
|VivanteGC7000UL |PXA1908 ||800 MHz|16 |
|VivanteGC7000L |PXA1936 ||800 MHz|32 |
|SGX530 |OMAP 3530 ||110 MHz|0.88 |
|SGX530 |DM3730 ||200 MHz|1.6 |
|SGX531 |MT6513<br>MT6573<br>MT6575M ||281 MHz|2.25 |
|SGX531 |R-Car E1 ||400 MHz|3.2 |
|SGX531 Ultra |MT6515<br>MT6575<br>MT6517<br>MT6517T<br>MT6577<br>MT6577T<br>MT8317<br>MT8317T<br>MT8377||522 MHz|4.2 |
|SGX535 |S5PC100<br>Apple A4 ||200 MHz|1.6 |
|SGX535 |Apple A4 (iPad) ||250 MHz|2.0 |
|SGX540 |Exynos 3110 ||200 MHz|3.2 |
|SGX540 |OMAP 4430 ||307 MHz|4.9 |
|SGX540 |OMAP 4460 ||384 MHz|6.1 |
|SGX540 |Atom Z2420<br>R-Car E2<br>R-Car M1A / M1S ||400 MHz|6.4 |
|SGX540 |ATM7021<br>ATM7021A<br>ATM7029B ||500 MHz|8.0 |
|SGX540 |RK3168 ||600 MHz|9.6 |
|SGX543 MP2 |Apple A5 ||200 MHz|12.8 |
|SGX543 MP2 |Apple A5 (iPad2) ||250 MHz|16.0 |
|SGX543 MP2 |MT5327 ||400 MHz|25.6 |
|SGX543 MP2 |R-Car H1 ||520 MHz|33.28|
|SGX543 MP3 |Apple A6 ||266 MHz|25.5 |
|SGX543 MP4 |Apple A5X ||250 MHz|32.0 |
|SGX544 |MT6589M<br>MT8117<br>MT8121 ||156 MHz|5 |
|SGX544 |MT6589<br>MT8389 ||286 MHz|9.2 |
|SGX544 |MT8125 ||300 MHz|9.6 |
|SGX544 |MT6589T<br>MT8389T ||357 MHz|11.4 |
|SGX544 |OMAP 4470 ||384 MHz|12.3 |
|SGX544 |ATM7039 ||450 MHz|14.4 |
|SGX544 MP2 |Atom Z2520 ||300 MHZ|19.2 |
|SGX544 MP2 |Allwinner A31<br>Allwinner A31s ||350 MHz|22.4 |
|SGX544 MP2 |Atom Z2560 ||400 MHz|25.6 |
|SGX544 MP2 |R-Car M2 ||520 MHz|33.28|
|SGX544 MP2 |Atom Z2580 ||533 MHz|34.1 |
|SGX544 MP2 |Allwinner A83T<br>Allwinner H8 ||700 MHz|44.8 |
|SGX544 MP3 |Exynos 5410 ||533 MHz|51.1 |
|SGX545 |Atom Z2460<br>Atom Z2760 ||533 MHz|8.5 |
|SGX554 MP4 |Apple A6X ||266 MHz|68.1 |
|G6100<br>G6110 (1 Clusters)|RK3368 ||600 MHz|38.4 |
|G6200 (2 Clusters) |MT6595M<br>MT8135 ||450 MHz|57.6 |
|G6200 (2 Clusters) |MT6795M ||550 MHz|70.4 |
|G6200 (2 Clusters) |MT6595<br>MT6595T ||600 MHz|76.8 |
|G6200 (2 Clusters) |MT6793<br>Helio X10<br>MT6795<br>MT6795T ||700 MHz|89.6 |
|G6230 (2 Clusters) |Allwinner A80<br>Allwinner A80T ||533 MHz|68.0 |
|G6230 (2 Clusters) |ATM9009 ||600 MHz|76.8 |
|GX6250 (2 Clusters) |MT8173<br>MT8176 ||600 MHz|76.8 |
|GX6250 (2 Clusters) |MT8693 ||700 MHz|89.6 |
|G6400 (4 Clusters) |Atom Z3460<br>Atom Z3480 ||533 MHz|136.4|
|G6400 (4 Clusters) |R-Car H2 ||600 MHz|153.6|
|G6430 (4 Clusters) |Apple A7<br>Apple A7 (iPad Air) ||450 MHz|115.2|
|G6430 (4 Clusters) |Atom Z3530 ||457 MHz|117 |
|G6430 (4 Clusters) |Atom Z3560<br>Atom Z3580 ||533 MHz|136.4|
|G6430 (4 Clusters) |Atom Z3570<br>Atom Z3590 ||640 MHz|163.8|
|GX6450 (4 Clusters) |Apple A8 ||450 MHz|115.2|
|GX6650 (6 Clusters) |R-Car H3 ||600 MHz|230.4|
|GX6850 (8 Clusters) |Apple A8X ||450 MHz|230.4|
|GT7200 (2 Clusters) |SC9861G-IA ||650 MHz|83.2 |
|GT7400 Plus (4 Clusters) |Helio X30 ||800 MHz|204.8|
|GT7600 (6 Clusters) |Apple A9 ||450 MHz|172.8|
|GT7600 Plus (6 Clusters) |Apple A10 Fusion ||650 MHz|249.6|
|GT7800+ (12 Clusters) |Apple A9X ||450 MHz|345.6|
|GT7800? (12 Clusters) |Apple A10X Fusion ||650 MHz|499.2|
|GMA 4500 Series |G41 / G43 / G45 |65nm|533-800 |21-32 |
|HD Graphics |Clarkdale<br>Arrandale |45nm|533-900 |25.6-43.2 |
|HD Graphics<br>HD Graphics 2000 |SandyBridge GT1 |32nm|950-1350 |45.6-64.8 |
|HD Graphics 3000 |SandyBridge GT2 |32nm|1000-1350|96-129.6 |
|HD Graphics |Bay Trail-T<br>Atom Z37xx<br>Atom E38xx<br>Bay Trail-M<br>Pentium N35xx<br>Celeron N2xxx<br>Bay Trail-D<br>Pentium J2xxx<br>Celeron J1xxx|22nm|400-896 |25.6-57.3 |
|HD Graphics<br>HD Graphics 2500 |IvyBridge GT1 |22nm|800-1150 |76.8-110.4 |
|HD Graphics 4000<br>HD Graphics P4000 |IvyBridge GT2 |22nm|850-1300 |217.6-332.8|
|HD Graphics |Haswell GT1 |22nm|850-1150 |136-184 |
|HD Graphics 4400 |Haswell GT1.5 |22nm|1150-1300|220.8-249.6|
|HD Graphics 4200<br>HD Graphics 4400<br>HD Graphics 4600<br>HD Graphics P4600<br>HD Graphics P4700|Haswell GT2 |22nm|850-1350 |272-432 |
|HD Graphics 5000<br>Iris Graphics 5100 |Haswell GT3 |22nm|1000-1100|640-704 |
|Iris Pro 5200<br>(with 128MB eDRAM) |Haswell GT3e |22nm|1200-1300|768-832 |
|HD Graphics<br>HD Graphics 400 |Cherry Trail<br>Atom x5-Z83xx<br>Atom x5-Z85xx<br>Braswell<br>Celeron N30xx<br>Celeron N31xx<br>Celeron J30xx<br>Celeron J31xx |14nm|500-700 |96-134.4 |
|HD Graphics<br>HD Graphics 405 |Cherry Trail<br>Atom x7-Z87xx<br>Braswell<br>Pentium N37xx |14nm|600-700 |153.6-179.2|
|HD Graphics 405 |Braswell<br>Pentium J3710 |14nm|740 |213.12 |
|HD Graphics |Broadwell-U GT1 |14nm|800-850 |153.6-163.2|
|HD Graphics 5300 |Broadwell-Y GT2<br>Core M-5Yxx |14nm|800-850 |307.2-326.4|
|HD Graphics 5500 |Broadwell-U GT2 |14nm|850-900 |312.8-331.2|
|HD Graphics 5500 |Broadwell-U GT2 |14nm|900-950 |345.6-364.8|
|HD Graphics 5600<br>HD Graphics P5700 |Broadwell-U GT2 |14nm|1000-1050|384-403.2 |
|HD Graphics 6000 |Broadwell-U GT3 |14nm|950-1000 |729.6-768 |
|Iris Graphics 6100 |Broadwell-U GT3 |14nm|1050-1100|806.4-844.8|
|Iris Pro Graphics 6200<br>Iris Pro Graphics P6300<br>(with 128MB eDRAM) |Broadwell GT3e |14nm|1000-1150|768-883.2 |
|HD Graphics 500 |Apollo Lake<br>Celeron N3350<br>Celeron N3450<br>Celeron J3355<br>Celeron J3455 |14nm|650-750 |124.8-144 |
|HD Graphics 505 |Apollo Lake<br>Pentium N4200<br>Pentium J4205 |14nm|750-800 |216-230.4 |
|HD Graphics 510 |Skylake GT1 |14nm|900-1000 |172.8-192 |
|HD Graphics 515 |Skylake-Y GT2<br>Core M3/M5/M7 |14nm|800-1000 |307.2-384 |
|HD Graphics 520 |Skylake-U GT2 |14nm|1000-1050|384-403.2 |
|HD Graphics 530<br>HD Graphics P530 |Skylake GT2 |14nm|900-1150 |345.6-441.6|
|Iris Graphics 540<br>Iris Graphics 550<br>(with 64MB eDRAM) |Skylake GT3e |14nm|950-1100 |729.6-844.8|
|Iris Pro Graphics 580<br>Iris Pro Graphics P580<br>(with 128MB eDRAM) |Skylake GT4e |14nm|1000 |1152 |
|HD Graphics 610 |Kaby Lake GT1 |14nm|900-1050 |172.8-201.6|
|HD Graphics 615 |Kaby Lake-Y GT2<br>Pentium 4410Y<br>Core M3-7Yxx<br>Core i5-7Yxx<br>Core i7-7Yxx |14nm|850-1050 |326.4-403.2|
|HD Graphics 620 |Kaby Lake-U GT2 |14nm|1000-1150|384-441.6 |
|HD Graphics 630<br>HD Graphics P630 |Kaby Lake GT2 |14nm|950-1150 |364.8-441.6|
|Iris Plus Graphics 640<br>Iris Plus Graphics 650<br>(with 64MB eDRAM) |Kaby Lake GT3e |14nm|950-1150 |729.6-883.2|
|NVIDIA G86|GS 8300 8core| 80nm | 450Mhz| 21,6 |
|NVIDIA GT218|G 210 16core| 40nm | 1400Mhz | 67 |
|NVIDIA GT216|G 220 48core| 40nm | 1360Mhz | 196|
|NVIDIA GK107|GTX 650	384core|28nm|1058Mhz GDDR5|	812.5|
|NVIDIA GK107|GT 640 384core|28nm|900Mhz DDR3|691.2|
|NVIDIA GK106|GTX 660	960core|28nm|1032Mhz GDDR5|1881.6|
|NVIDIA GK106|GTX 650Ti 768core|28nm|928Mhz GDDR5|1425.4|
|NVIDIA GP108|GT 1030 384core|14nm|1228Mhz|942,3|
|NVIDIA GP107|GT 1050 640core|14nm|1354Mhz|1733,1|
|NVIDIA TU117|GTX 1650 896core|12nm|1485Mhz|2661,1|
