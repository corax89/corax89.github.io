#!/bin/bash
# v36.23 E2E: [KEY-STUCK] — «в играх залипает кнопка вправо».
#
# ДВА фикса в одной сборке:
#   FIX-A (repeat slots): слот повтора был ОДИН на все расширенные коды
#        (UP/DOWN/LEFT/RIGHT/F1/F2/ESC клампились в idx=255) — удержание
#        RIGHT порождало keyRepeated(-1..-4) одновременно. Теперь слот —
#        на каждую запись key_map: повторяется ТОЛЬКО реально удержанная.
#   FIX-B (pause flush): меню паузы проглатывало game-key события; ключ,
#        ОТПУЩЕННЫЙ внутри меню, никогда не посылал keyReleased в игру —
#        бит key_level в getKeyStates() залипал навсегда (игра «сама едет»).
#
# TestKeys.jar — Canvas, логирующий keyPressed/keyRepeated/keyReleased
# (по 4 первых на пару вид/код): [JK] pressed -4 / [JK] repeated -4 ...
#
# Сценарий (одна сессия): RIGHT в игре -> пауза (MINUS) пока RIGHT «держится»
# -> B «Продолжить» -> выход. Песочница НЕ ВИДИТ отпусканий (FRONT_KEYS даёт
# только press-edge), поэтому:
#   - "repeated -4" БЕЗ "repeated -1/-2/-3"  => FIX-A работает;
#   - "released -4" ПОСЛЕ "pause menu close" => FIX-B доставил проглоченный
#     keyReleased (в старом коде его не было бы НИКОГДА);
#   - "[KEYFLUSH] captured 1 held game key(s)" => capture увидел залипший RIGHT.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_keystuck
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp "games/TestKeys.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"          # изолированный RMS
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_EXIT_MS=13000
# wall-clock от старта процесса: браузер ~на 0.6-1.0-й, игра стартует ~на 2-й,
# RIGHTON ~на 4-й (виртуально УДЕРЖИВАЕТСЯ — press-edge виден, release нет),
# повторы keyRepeated(-4) идут с ~4.4-й, пауза на 5.3-й (capture видит
# залипший RIGHT), B «Продолжить» на 6.1-й (flush доставляет released -4),
# RIGHTOFF на 6.6-й, выход через меню на 7.6-й.
export NOJME_FRONT_KEYS="RIGHTON:4000,MINUS:5300,B:6100,RIGHTOFF:6600,MINUS:7600,DOWN:400,DOWN:400,A:900"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"
grep -ahq "JK] start" $ALL || { echo "FAIL: TestKeys.jar не стартовал"; ok=0; }
# v36.32: версия берётся из core_version.h — проверка больше не ломается
# при каждом подъезде версии (сообщение ниже историческое)
CORE_VER=$(sed -n 's/.*CORE_BUILD_ID "\(v[0-9.]*\)[^"]*".*/\1/p' include/core_version.h 2>/dev/null | head -1)
CORE_VER=${CORE_VER:-v36.32}
grep -ahq "$CORE_VER" $ALL || { echo "FAIL: в логе нет баннера $CORE_VER"; ok=0; }

# press доставлен в игру
grep -ahq "JK] pressed -4" $ALL || { echo "FAIL: keyPressed(-4) не дошёл до канвы"; ok=0; }

# FIX-A: повторы ТОЛЬКО от реально удержанной RIGHT
grep -ahq "JK] repeated -4" $ALL || { echo "FAIL: keyRepeated(-4) не генерируется (сломан софт-повтор?)"; ok=0; }
for bad in -1 -2 -3; do
  if grep -ahq "JK] repeated $bad" $ALL; then
    echo "FAIL: фантомный keyRepeated($bad) — слоты повтора всё ещё общие"; ok=0
  fi
done

# FIX-B: capture увидел залипший RIGHT, flush доставил release после меню
grep -ahq "KEYFLUSH] captured 1 held game key(s)" $ALL || { echo "FAIL: capture не увидил удержанный RIGHT"; ok=0; }
grep -ahq "KEYFLUSH] pause-flush keyReleased -4" $ALL || { echo "FAIL: flush не доставил keyReleased(-4)"; ok=0; }
grep -ahq "JK] released -4" $ALL || { echo "FAIL: канва не получила keyReleased(-4)"; ok=0; }

# released -4 должен появиться ПОСЛЕ закрытия меню (flush, не обычный путь)
F=$(grep -al "JK] released -4" $D/log.txt $D/err.log $D/out.log 2>/dev/null | head -1)
if [ -n "$F" ]; then
  LM=$(grep -an "pause menu close" "$F" | head -1 | cut -d: -f1)
  LK=$(grep -an "JK] released -4" "$F" | head -1 | cut -d: -f1)
  [ -n "$LM" ] && [ -n "$LK" ] && [ "$LK" -ge "$LM" ] || { echo "FAIL: released -4 раньше закрытия меню — не flush"; ok=0; }
fi

grep -ahq "session complete — back to menu" $ALL || { echo "FAIL: сессия не завершилась чисто"; ok=0; }

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
