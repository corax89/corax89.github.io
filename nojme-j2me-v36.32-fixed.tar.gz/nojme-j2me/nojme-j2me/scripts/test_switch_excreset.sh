#!/bin/bash
# v36.21 E2E: [EXC-RESET] — экран необработанного исключения не должен
# «прилипать» к следующей игре.
#
# TestExcReset.jar — СОСТОЯНИЕ в RMS (store "excreset"):
#   запуск 1: флага нет -> пишет флаг, рисует, ДЕЛИТ НА НОЛЬ без catch
#             -> красный экран "[ERROR] java/lang/ArithmeticException".
#   запуск 2: флаг есть -> чистый canvas-цикл с маркерами
#             "[EXC-RESET] canvas alive (clean)".
#
# Один jar, ДВЕ сессии в одном процессе (NOJME_SWITCH_AUTOTEST_SESSIONS=2).
# Выход из сессии 1 — через единое меню паузы (MINUS,DOWN,DOWN,A «Выйти»),
# которое доступно и в error-режиме (pump жив).
#
# КЛЮЧЕВАЯ проверка: в сессии 2 появляются "canvas alive (clean)" ПОСЛЕ
# маркера "session 2: clean run". До фикса g_has_error оставался взведённым,
# игровой цикл сессии 2 навсегда уходил в error-ветку и canvas НЕ рисовался.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_excreset
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
cp "games/TestExcReset.jar" "$D/roms/"

cat > "$D/switchui_settings.ini" <<EOF
settings_version=2
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
saves_dir=$D/saves
EOF
# v36.32: saves_dir изолирован в \$D — раньше тест читал флаг из общего
# каталога сейвов CWD (sdmc:/.../TestExcReset/excreset.rms от прошлого
# прогона) и сессия 1 сразу шла «чистой», ломая сам тест.

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"          # изолированный RMS
export NOJME_SWITCH_KEYS="A:600,A:800"
export NOJME_SWITCH_AUTOTEST_SESSIONS=2
export NOJME_SWITCH_AUTOTEST_EXIT_MS=5000
# wall-clock от старта процесса: сессия 1 падает ~на 4-й секунде,
# пауза на 8-й, «Выйти» ~на 8.8-й; сессия 2 стартует ~на 11-й,
# пауза на 20-й, «Выйти» ~на 20.8-й.
export NOJME_FRONT_KEYS="MINUS:8000,DOWN:400,DOWN:400,A:900,MINUS:20000,DOWN:400,DOWN:400,A:900"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"
grep -ahq "EXC-RESET] session 1: throwing"  $ALL || { echo "FAIL: сессия 1 не вооружила исключение"; ok=0; }
grep -ahq "EXC-RESET] session 2: clean run" $ALL || { echo "FAIL: сессия 2 не стартовала чисто (RMS-флаг потерян?)"; ok=0; }

N_EXC=$(grep -ahc "UNCAUGHT EXCEPTION" $ALL | awk '{s+=$1} END{print s+0}')
echo "uncaught banners: $N_EXC (want 1)"
[ "$N_EXC" -eq 1 ] || { echo "FAIL: баннер исключения не ровно 1"; ok=0; }
grep -ahq "ArithmeticException" $ALL || { echo "FAIL: ArithmeticException не виден"; ok=0; }

# КЛЮЧЕВОЕ: маркеры чистого canvas ПОСЛЕ маркера второй сессии
L2=$(grep -ahn "EXC-RESET] session 2: clean run" $ALL | head -1 | cut -d: -f1)
[ -n "$L2" ] || { echo "FAIL: нет маркера сессии 2"; ok=0; }
N_CLEAN=$(tail -n +"$((L2+1))" "${ALL// /$'\n'}" 2>/dev/null | grep -ac "canvas alive (clean)" || true)
# надёжнее: по файлам
N_CLEAN=0
for f in $D/log.txt $D/err.log $D/out.log; do
  [ -f "$f" ] || continue
  LN=$(grep -an "EXC-RESET] session 2: clean run" "$f" | head -1 | cut -d: -f1)
  [ -n "$LN" ] || continue
  C=$(tail -n +"$((LN+1))" "$f" | grep -ac "canvas alive (clean)" || true)
  N_CLEAN=$((N_CLEAN + C))
done
echo "clean canvas markers after session 2 start: $N_CLEAN (want >=3)"
[ "$N_CLEAN" -ge 3 ] || { echo "FAIL: сессия 2 рисует error-экран вместо игры — сброс не работает"; ok=0; }

[ "$ok" = 1 ] && echo "ALL CHECKS PASSED" || { echo "CHECKS FAILED"; exit 1; }
