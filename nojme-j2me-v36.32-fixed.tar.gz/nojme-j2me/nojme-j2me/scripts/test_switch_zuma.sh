#!/bin/bash
# v36.32 автотест: Zuma X [640x480] — «выход с ошибкой» (полевой кейс краша
# 0x745364726F636572 на устройстве).
#
# Игра NET_Lizard-загрузчик: в jar НЕТ файлов уровней (l64dr1.png и пр.) и
# контент-классов (w.class, a/b/c.cfg) — игра сыплет NPE, сама вызывает
# notifyDestroyed -> destroyApp (сейв-код), destroyApp падает на
# String.length(null) (баг игры, ловится на телефоне), поток умирает,
# VM завершается естественно. Раньше этот путь additionally:
#   - создавал String'и с value=NULL ([STR-CHARS-NULL] x8 за прогон);
#   - ТЕРЯЛ все RMS-сейвы (fopen в несуществующий sdmc_/... каталог);
#   - оставлял окно двойной доставки destroyApp.
#
# Сценарии:
#   [A] свежий запуск — игра сама выходит (~4 c) -> возврат в меню ->
#       повторный запуск (персистентность процесса);
#   [B] сейвы, записанные в [A], грузятся с ДИСКА во второй сессии
#       ("-> DISK" с records>0);
#   [C] цикл выход/запуск x3 (soak) — ни краша, ни деградации.
# Проверки:
#   - ни одной строки [STR-CHARS-NULL] (фикс [STRING-CTOR-SPEC]);
#   - .rms-файлы РЕАЛЬНО записаны в каталог сейвов (фикс [RMS-PATH-FIX]);
#   - вторая сессия читает стор с диска;
#   - destroyApp доставляется ровно один раз за сессию (guard против
#     двойной доставки — v36.31/v36.32);
#   - сессии завершаются чисто ("session complete — back to menu").
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_zuma
JAR="games/ZumaX_640x480.jar"
[ -f "$JAR" ] || JAR="games/ZumaX.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }

rm -rf "$D"; mkdir -p "$D/roms"
cp "$JAR" "$D/roms/ZumaX.jar"
printf 'settings_version=2\nscale=fit_black\nfilter=nearest\naudio=off\nvm_speed=turbo\nlogging=on\nsaves_dir=%s/saves\n' "$D" > "$D/switchui_settings.ini"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# A: запуск, ждём само-выход игры, снова запускаем, затем EXIT
export NOJME_SWITCH_KEYS="A:600,A:800,A:5000,A:5000,EXIT:8000"
# FRONT-клавиши не нужны: игра выходит сама
export NOJME_FRONT_KEYS=""

timeout -k 5 90 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit code: $rc (want 0)"

ok=1

# 1) [STRING-CTOR-SPEC]: ни одного срабатывания детектора битых String
N=$(grep -ac "STR-CHARS-NULL" "$D/log.txt" "$D/err.log" 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')
[ "$N" -eq 0 ] || { echo "FAIL: [STR-CHARS-NULL] x$N — String'и с value=NULL остались"; ok=0; }

# 2) [RMS-PATH-FIX]: сейвы реально записаны (saves_dir задан в настройках)
RMS_FILES=$(find "$D/saves" -name "*.rms" 2>/dev/null | wc -l)
[ "$RMS_FILES" -ge 2 ] || { echo "FAIL: записано .rms-файлов: $RMS_FILES (хотим >=2) — сейвы теряются"; ok=0; }

# 3) игра сама завершилась (error-exit путь) и сессия вернулась в меню
grep -aq "VM-THREAD-DEATH" "$D/err.log" || { echo "FAIL: нет само-выхода игры (VM-THREAD-DEATH)"; ok=0; }
grep -aq "session complete — back to menu" "$D/err.log" || { echo "FAIL: нет чистого возврата в меню"; ok=0; }

# 4) повторный запуск состоялся (2 сессии); сторы во 2-й сессии открываются
#    с уже накопленными записями (RAM reuse — таблица сторов процесс-глобальна,
#    дисковый путь покрывает проверка #2 файлов) или прямо с диска
SESSIONS=$(grep -ac "MIDLET STARTED" "$D/err.log" 2>/dev/null || true)
[ "${SESSIONS:-0}" -ge 2 ] || { echo "FAIL: сессий $SESSIONS (хотим >=2 — релаунч)"; ok=0; }
DISKLOAD=$(grep -acE "\-> (DISK|RAM reuse)" "$D/log.txt" 2>/dev/null || true)
[ "${DISKLOAD:-0}" -ge 1 ] || { echo "FAIL: во 2-й сессии ни одного переоткрытия стора"; ok=0; }

# 5) destroyApp без повторной доставки: один вызов или skip-маркер
CALLS=$(grep -ac "Calling destroyApp" "$D/err.log" 2>/dev/null || true)
SKIPS=$(grep -ac "destroyApp skipped" "$D/err.log" 2>/dev/null || true)
[ "$((CALLS + SKIPS))" -le "$SESSIONS" ] || { echo "FAIL: доставок destroyApp ($CALLS+$SKIPS) больше сессий ($SESSIONS)"; ok=0; }

# 6) без крашей
grep -aqi "segfault\|SIGSEGV" "$D/err.log" && { echo "FAIL: краш"; ok=0; }

if [ $ok -eq 1 ]; then
    echo "SWITCH-UI ZUMA-X: ALL CHECKS PASSED (сейвов: $RMS_FILES, сессий: $SESSIONS)"
else
    echo "SWITCH-UI ZUMA-X: FAILED — последние строки err.log:"; tail -25 "$D/err.log"
fi
exit $((1 - ok))
