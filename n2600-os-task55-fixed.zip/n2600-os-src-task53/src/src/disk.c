/* disk.c — диспетчер блочных устройств: AHCI (SATA) -> ATA (IDE).
 *
 * Контекст: в VMware НЖМД по умолчанию — SATA/AHCI, CD — IDE. Легаси-ATA
 * драйвер SATA не видит, и «кроме ramfs нет дисков». Слой пробует AHCI
 * первым; если SATA-диска нет — откат на ATA (QEMU IDE, старое железо).
 *
 * Сессия 11: + слой разделов MBR (общий для fat32/ntfs). Таблица
 * сканируется один раз; разделы отдаются драйверам ФС по индексу.
 */
#include "disk.h"
#include "ahci.h"
#include "ata.h"
#include "string.h"
#include "sync.h"

static int g_backend = 0;   /* 1 = AHCI, 2 = ATA */

int disk_hdd_init(void)
{
    if (ahci_hdd_present()) { g_backend = 1; return 1; }
    if (ata_hdd_present())  { g_backend = 2; return 1; }
    return 0;
}

int disk_hdd_present(void)
{
    if (g_backend == 1 && ahci_hdd_present()) return 1;
    if (g_backend == 2 && ata_hdd_present()) return 1;
    if (ahci_hdd_present()) { g_backend = 1; return 1; }
    if (ata_hdd_present())  { g_backend = 2; return 1; }
    return 0;
}

u32 disk_hdd_sectors(void)
{
    if (disk_hdd_present())
        return (g_backend == 1) ? ahci_hdd_sectors() : ata_hdd_sectors();
    return 0;
}

const char *disk_hdd_model(void)
{
    if (disk_hdd_present())
        return (g_backend == 1) ? ahci_hdd_model() : ata_hdd_model();
    return "";
}

const char *disk_hdd_bus(void)
{
    return (g_backend == 1) ? "AHCI" : "ATA";
}

int disk_hdd_read(u32 lba, u8 count, void *buf)
{
    if (ahci_hdd_present())
        return ahci_read_hdd(lba, count, buf);
    if (ata_hdd_present())
        return ata_read_hdd(lba, count, buf);
    return 0;
}

/* Запись секторов НЖМД (сессия 12) — используется форматированием
 * в FAT32 (Настройки → Диски). Маршрутизация та же, что у чтения. */
int disk_hdd_write(u32 lba, u8 count, const void *buf)
{
    if (ahci_hdd_present())
        return ahci_write_hdd(lba, count, buf);
    if (ata_hdd_present())
        return ata_write_hdd(lba, count, buf);
    return 0;
}

int disk_cd_read(u32 lba, void *buf)
{
    /* AHCI ATAPI (SATA-привод) приоритетнее */
    if (ahci_cd_present())
        return ahci_read_cd(lba, buf);
    if (ata_present() && !ata_is_hdd_active())
        return ata_read(lba, 1, buf);
    return 0;
}

int disk_cd_present(void)
{
    if (ahci_cd_present()) return 1;
    if (ata_present() && !ata_is_hdd_active()) return 1;
    return 0;
}

/* ================= разделы MBR / GPT (сессии 11/25) ================= */

#define DISK_MAX_PARTS 16
static disk_part_t g_parts[DISK_MAX_PARTS];
static int g_part_count = 0;
static int g_part_scanned = 0;
static volatile int g_part_lock = 0;

/* Task 55 [FS-CACHE]: кэш типа ФС по индексу раздела. disk_part_fstype()
 * вызывается файловым менеджером при КАЖДОЙ отрисовке (fm_scan_vols) —
 * раньше это был ЧТЕНИЕ ДИСКА на каждый кадр на каждый раздел. */
static char g_fs_type[DISK_MAX_PARTS][8];
static u8   g_fs_known[DISK_MAX_PARTS];
static char g_sf_fs[8];          /* Task 55: ФС superfloppy (сектор 0) */
static u8   g_sf_known = 0;

static int part_rd_sector(u32 lba, void *buf)
{
    return disk_hdd_read(lba, 1, buf);
}

static u32 part_rd32(const u8 *p)
{
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

static u64 part_rd64(const u8 *p)
{
    return (u64)part_rd32(p) | ((u64)part_rd32(p + 4) << 32);
}

static void part_add(u8 type, u32 start, u32 nsec, int gpt, const char *label)
{
    if (g_part_count >= DISK_MAX_PARTS) return;
    if (start == 0 || nsec == 0) return;
    /* дедуп: тот же диапазон уже добавлен (GPT поверх защитной MBR и т.п.) */
    for (int i = 0; i < g_part_count; i++)
        if (g_parts[i].start_lba == start && g_parts[i].nsectors == nsec)
            return;
    g_parts[g_part_count].type      = type;
    g_parts[g_part_count].start_lba = start;
    g_parts[g_part_count].nsectors  = nsec;
    g_parts[g_part_count].gpt       = (u8)gpt;
    int k = 0;
    if (label)
        for (; k < (int)sizeof(g_parts[0].label) - 1 && label[k]; k++)
            g_parts[g_part_count].label[k] = label[k];
    g_parts[g_part_count].label[k] = 0;
    g_part_count++;
}

/* Имя раздела GPT: UTF-16LE, 72 байта → UTF-8 (обрезка по буферу). */
static void part_gpt_name(const u8 *u16name, char *out, int outmax)
{
    int o = 0;
    for (int i = 0; i < 36; i++) {
        u32 c = (u32)u16name[i * 2] | ((u32)u16name[i * 2 + 1] << 8);
        if (c == 0) break;
        if (c < 0x80) {
            if (o + 2 > outmax) break;
            out[o++] = (char)c;
        } else if (c < 0x800) {
            if (o + 3 > outmax) break;
            out[o++] = (char)(0xC0 | (c >> 6));
            out[o++] = (char)(0x80 | (c & 0x3F));
        } else {
            if (o + 4 > outmax) break;
            out[o++] = (char)(0xE0 | (c >> 12));
            out[o++] = (char)(0x80 | ((c >> 6) & 0x3F));
            out[o++] = (char)(0x80 | (c & 0x3F));
        }
    }
    out[o] = 0;
}

/* GPT: LBA 1 — заголовок "EFI PART", записи — по PartitionEntryLBA.
 * Возврат: число найденных разделов (0 = GPT нет/не разобран). */
static int part_scan_gpt(void)
{
    u8 hdr[512];
    if (!part_rd_sector(1, hdr)) return 0;
    if (memcmp(hdr, "EFI PART", 8) != 0) return 0;

    u32 entry_lba  = (u32)part_rd64(hdr + 72);
    u32 entry_num  = part_rd32(hdr + 80);
    u32 entry_size = part_rd32(hdr + 84);
    if (entry_lba == 0 || entry_num == 0 || entry_num > 128) return 0;
    if (entry_size < 128 || entry_size > 512 || (entry_size & 7)) return 0;

    static const u8 guid_efi[16] = {            /* C12A7328-F81F-... */
        0x28, 0x73, 0x2A, 0xC1, 0x1F, 0xF8, 0xD2, 0x11,
        0xBA, 0x4B, 0x00, 0xA0, 0xC9, 0x3E, 0xC9, 0x3B };
    /* GUID «basic data» (EBD0A0A2-…) и прочие типы сознательно не
     * фильтруются: ФС определяется загрузочным сектором раздела */

    int found = 0;
    u8 sec[512];
    u32 cur_lba = 0xFFFFFFFFu;                  /* сектор, лежащий в sec[] */
    for (u32 i = 0; i < entry_num && g_part_count < DISK_MAX_PARTS; i++) {
        u32 lba  = entry_lba + (i * entry_size) / 512;
        u32 off  = (i * entry_size) % 512;
        if (lba != cur_lba) {
            if (!part_rd_sector(lba, sec)) break;
            cur_lba = lba;
        }
        const u8 *e = sec + off;
        int zero = 1;
        for (int k = 0; k < 16; k++)
            if (e[k]) { zero = 0; break; }
        if (zero) continue;                     /* пустая запись */

        u64 s64 = part_rd64(e + 32), n64;
        u64 e64 = part_rd64(e + 40);
        if (e64 < s64) continue;
        n64 = e64 - s64 + 1;
        /* u32 LBA/длины: диски >2 ТиБ не поддерживаются остальным стеком */
        if (s64 > 0xFFFFFFFFull || n64 > 0xFFFFFFFFull) continue;

        int is_efi = (memcmp(e, guid_efi, 16) == 0);
        /* тип GUID не фильтруем: «чужие» разделы (Linux fs, MSR, прочие)
         * тоже показываем — ФС определяется загрузочным сектором */
        char name[24];
        part_gpt_name(e + 56, name, (int)sizeof(name));
        part_add(is_efi ? 0xEF : 0x07, (u32)s64, (u32)n64, 1, name);
        found++;
    }
    return found;
}

/* Разбор MBR: 4 первичные записи + цепочка EBR (логические), затем GPT
 * (если диск размечен по EFI — защитная MBR с записью 0xEE). Сессия 25:
 * цепочка EBR следует по ссылке «от базы расширенного раздела» (стандарт
 * MS); если по ней не нашлось валидного EBR — пробуем вариант «от
 * предыдущего EBR» (так пишут некоторые старые утилиты). */
static int part_scan_impl(void)
{
    u8 mbr[512];
    g_part_count = 0;
    memset(g_fs_known, 0, sizeof(g_fs_known));   /* [FS-CACHE] сброс */
    memset(g_fs_type, 0, sizeof(g_fs_type));
    memset(g_sf_fs, 0, sizeof(g_sf_fs));
    if (!disk_hdd_present()) return 0;
    if (!part_rd_sector(0, mbr)) return 0;
    if (mbr[510] != 0x55 || mbr[511] != 0xAA) return 0;

    u32 ebr_base = 0;
    for (int i = 0; i < 4 && g_part_count < DISK_MAX_PARTS; i++) {
        const u8 *e = mbr + 0x1BE + i * 16;
        u8 type = e[4];
        if (type == 0) continue;
        u32 start = part_rd32(e + 8);
        u32 nsec = part_rd32(e + 12);
        if (type == 0xEE) {
            /* защитная MBR: диск размечен по GPT — читаем настоящую
             * таблицу; первичные записи MBR не добавляем */
            part_scan_gpt();
            return g_part_count > 0;
        }
        if (type == 0x05 || type == 0x0F) {
            ebr_base = start;               /* extended — после первичных */
            continue;
        }
        part_add(type, start, nsec, 0, NULL);
    }
    /* extended: цепочка EBR (до 8 логических разделов) */
    if (ebr_base) {
        u32 next = ebr_base;
        u32 prev = ebr_base;                /* вариант ссылки от прошлого EBR */
        for (int k = 0; k < 8 && next; k++) {
            u8 ebr[512];
            if (!part_rd_sector(next, ebr)) break;
            if (ebr[510] != 0x55 || ebr[511] != 0xAA) break;
            const u8 *e0 = ebr + 0x1BE;     /* первая запись = сам раздел */
            if (e0[4] != 0 && e0[4] != 0x05 && e0[4] != 0x0F) {
                u32 start = next + part_rd32(e0 + 8);
                u32 nsec = part_rd32(e0 + 12);
                part_add(e0[4], start, nsec, 0, NULL);
            }
            const u8 *e1 = ebr + 0x1CE;     /* вторая = следующий EBR */
            if (e1[4] == 0x05 || e1[4] == 0x0F) {
                u32 rel = part_rd32(e1 + 8);
                u32 cand = ebr_base + rel;  /* стандарт MS: от базы ext */
                u8 probe[512];
                if (cand == next || cand == 0 ||
                    !part_rd_sector(cand, probe) ||
                    probe[510] != 0x55 || probe[511] != 0xAA)
                    cand = prev + rel;      /* старый вариант: от EBR */
                prev = next;
                next = cand;
            } else {
                next = 0;
            }
        }
    }
    return g_part_count > 0;
}

int disk_part_count(void)
{
    if (!g_part_scanned) {
        s_lock(&g_part_lock);
        if (!g_part_scanned) {
            part_scan_impl();
            g_part_scanned = 1;
        }
        s_unlock(&g_part_lock);
    }
    return g_part_count;
}

/* Сессия 12: перечитать таблицу разделов (после форматирования диска —
 * superfloppy не имеет MBR, старый список недействителен). */
void disk_part_rescan(void)
{
    s_lock(&g_part_lock);
    part_scan_impl();
    g_part_scanned = 1;
    s_unlock(&g_part_lock);
}

const disk_part_t *disk_part(int i)
{
    if (i < 0 || i >= disk_part_count()) return NULL;
    return &g_parts[i];
}

const char *disk_part_fstype(int i)
{
    if (i < 0 || i >= disk_part_count()) return "";
    if (g_fs_known[i]) return g_fs_type[i];   /* [FS-CACHE] */
    g_fs_known[i] = 1;
    g_fs_type[i][0] = 0;    /* сброс значения: нет ФС -> честно "" */
    u8 bs[512];
    if (!part_rd_sector(g_parts[i].start_lba, bs)) return g_fs_type[i];
    if (memcmp(bs + 3, "NTFS    ", 8) == 0) {
        strcpy(g_fs_type[i], "NTFS");
        return g_fs_type[i];
    }
    if (memcmp(bs + 3, "EXFAT   ", 8) == 0) {
        strcpy(g_fs_type[i], "exFAT");   /* сессия 75 */
        return g_fs_type[i];
    }
    if (memcmp(bs + 0x52, "FAT32", 5) == 0 ||
        memcmp(bs + 0x36, "FAT32", 5) == 0) {
        strcpy(g_fs_type[i], "FAT32");
        return g_fs_type[i];
    }
    return g_fs_type[i];
}

/* ================= Task 55 [NTFS-SUPERFLOPPY] ========================
 * ФС прямо в секторе 0 — диск БЕЗ таблицы разделов (внешние боксы,
 * флешки, образы; в Проводнике выглядят как «диск с одним разделом»).
 * Возвращает "NTFS" / "exFAT" / "FAT32" или "" (нет узнаваемой ФС /
 * нет диска / есть таблица разделов — тогда используется disk_part()).
 * Результат кэшируется до disk_part_rescan(). */
const char *disk_superfloppy_fs(void)
{
    if (!g_sf_known) {
        g_sf_known = 1;
        if (disk_hdd_present() && disk_part_count() == 0) {
            u8 bs[512];
            if (part_rd_sector(0, bs)) {
                if (memcmp(bs + 3, "NTFS    ", 8) == 0)
                    strcpy(g_sf_fs, "NTFS");
                else if (memcmp(bs + 3, "EXFAT   ", 8) == 0)
                    strcpy(g_sf_fs, "exFAT");
                else if (memcmp(bs + 0x52, "FAT32", 5) == 0 ||
                         memcmp(bs + 0x36, "FAT32", 5) == 0)
                    strcpy(g_sf_fs, "FAT32");
            }
        }
    }
    return g_sf_fs;
}
