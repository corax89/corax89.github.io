/* ========================================================================
 *  cmscript.c -- Single-file CMScript interpreter (C99)
 * ------------------------------------------------------------------------
 *  Original project : https://github.com/SUNSETDEVER/KernelCDM
 *  Original author  : SUNSETDEVER (Apache-2.0)
 *  Combined for     : self-hosted graphical x86 OS
 *
 *  This file aggregates the entire CMScript interpreter (preprocessor,
 *  parser, AST evaluator, std-library bridge, host-function registry)
 *  into one translation unit so it can be linked into a custom kernel
 *  or userspace binary without a separate library.
 *
 *  All libc dependencies are gated behind feature macros (see "Config"
 *  below). On a freestanding x86 OS you can disable the parts of libc
 *  you have not implemented yet and the file will still compile and
 *  run, just with the corresponding runtime features unavailable from
 *  script code.
 *
 *  License: Apache-2.0
 *
 *  ----------------------------------------------------------------------
 *  CHANGELOG (рефакторинг дедупликации + C-образность):
 *   Дедупликация:
 *    1. CDM_Std_Init: таблица g_std_entries[] вместо ~50 строк регистрации.
 *    2. Удалены дубликаты mk_f/mk_i (=> make_float/make_int) и
 *       as_double/as_int/as_str (=> val_to_double/val_to_int/val_to_str).
 *    3. set_string_slot(): единый паттерн "освободить старое, скопировать
 *       новое" (CDM_AssignRef, write_lvalue, std_strncpy, std_sprintf,
 *       std_snprintf, std_fgets, std_fread). Копирование ДО освобождения
 *       — фикс use-after-free при `s = s;`.
 *    4. std_sprintf/std_snprintf -> общее ядро std_format_common().
 *    5. is_cout_chain/is_cin_chain -> одна is_stream_chain().
 *    6. val_is_* свернуты в макрос VAL_IS.
 *    7. cdm_atoll() = cdm_strtoll(s, 10).
 *    8. Убран двойной #define fputs/fgets (!CDM_HAS_FILES дублировал
 *       !CDM_HAS_STDIO).
 *    9. Локальный static strcat удален — strcat теперь живет в string.c
 *       хост-ОС (рядом с strstr). Если в string.c её еще нет:
 *         char *strcat(char *dst, const char *src) {
 *             char *r = dst;
 *             while (*dst) dst++;
 *             while ((*dst++ = *src++));
 *             return r;
 *         }
 *   Багфиксы по ходу:
 *    - CDM_MAX_HOST_EX 64 -> 96: в CDM_Std_Init 69 регистраций, последние
 *      5 (std::fputs/fgets/feof/fread/fwrite) молча терялись.
 *    - atof() без libc возвращала только int-часть: литерал 2.1 парсился
 *      как 2.0 (ceil(2.1)==2, 1.5+2==3). Добавлен полноценный разбор.
 *   C-образность:
 *    1. Символьные литералы 'a', '\n', '\0' (токенизатор).
 *    2. Оператор -> : p->field сводится к (*p).field; *p на указателе
 *       со struct_id возвращает struct-значение (do_new проставляет
 *       struct_id для new Struct).
 *    3. typedef (таблица алиасов, forward-typedef поддержан через имя
 *       struct-цели): typedef struct Point Point; typedef unsigned int uint;
 *    4. goto/метки (AST_GOTO/AST_LABEL, поиск метки в текущем блоке с
 *       раскруткой наружу).
 *    5. union — парсится как struct (флаг is_union в CDM_StructDef_t).
 *    6. Битовые поля int f : 3; — парсятся, ширина игнорируется.
 *    7. Квалификаторы extern/volatile/register/inline/restrict/_Bool —
 *       ключевые слова, семантика игнорируется.
 *    8. #if/#elif с выражениями: defined(NAME), числа (10/0x/0), макросы,
 *       ( ) ! ~ + - * / % << >> < <= > >= == != & ^ | && ||; исправлена
 *       семантика цепочек (#else после сработавшей ветки больше не
 *       активируется).
 *    9. Функциональные макросы #define MAX(a,b) ... (до 6 параметров,
 *       подстановка с учетом строк/скобок в аргументах).
 *  ========================================================================
 */

#ifndef CMSCRIPT_SINGLE_FILE_C
#define CMSCRIPT_SINGLE_FILE_C

/* ----------------------------------------------------------------------
 *  Config -- override with -D flags on the compiler command line
 * ----------------------------------------------------------------------
 *  CDM_HAS_STDIO        -- <stdio.h> printf/snprintf/fputs (debug + std::printf)
 *  CDM_HAS_FILES        -- fopen/fclose/fread/fwrite/fgets/feof/fprintf
 *  CDM_HAS_MATH         -- <math.h> sqrt/sin/cos/... (std::sqrt etc.)
 *  CDM_HAS_TIME         -- clock()/CLOCKS_PER_SEC for "exit after Xs"
 *  CDM_HAS_STDLIB       -- <stdlib.h> rand/srand/atoi/atof (script-level)
 *  CDM_HAS_FLOATING     -- double/float hardware support (set 0 for soft-FP-less kernel)
 *  CDM_DEBUG_PRINTF     -- internal [Parse]/[PP]/[AST] trace prints
 *  CDM_HAS_ARDUINO      -- Arduino bridge (pinMode/digitalWrite/...) -- not for x86
 *
 *  If your OS does not provide one of these, define it to 0 at compile
 *  time. Example for a bare-minimum kernel build:
 *      gcc -std=c99 -ffreestanding \
 *          -DCDM_HAS_FILES=0 -DCDM_HAS_MATH=0 -DCDM_DEBUG_PRINTF=0 \
 *          -c cmscript.c -o cmscript.o
 * ---------------------------------------------------------------------- */
#ifndef CDM_HAS_STDIO
#define CDM_HAS_STDIO      0
#endif
#ifndef CDM_HAS_FILES
#define CDM_HAS_FILES      0
#endif
#ifndef CDM_HAS_MATH
#define CDM_HAS_MATH       0
#endif
#ifndef CDM_HAS_TIME
#define CDM_HAS_TIME       0
#endif
#ifndef CDM_HAS_STDLIB
#define CDM_HAS_STDLIB     0
#endif
#ifndef CDM_HAS_FLOATING
#define CDM_HAS_FLOATING   0
#endif
#ifndef CDM_DEBUG_PRINTF
#define CDM_DEBUG_PRINTF   0
#endif
#ifndef CDM_HAS_ARDUINO
#define CDM_HAS_ARDUINO    0
#endif

/* ----------------------------------------------------------------------
 *  Platform includes — N2600-OS freestanding headers
 * ---------------------------------------------------------------------- */
#include "types.h"
#include "string.h"
#include "mem.h"
#include "timer.h"

/* va_list / va_start / va_end — GCC builtins, не требуют заголовка */
typedef __builtin_va_list va_list;
#define va_start(v, l)  __builtin_va_start(v, l)
#define va_end(v)       __builtin_va_end(v)

/* int64_t / uint64_t — наши типы */
#define int64_t   i64
#define uint64_t  u64
#define int32_t   i32
#define uint32_t  u32
#define int16_t   i16
#define uint16_t  u16
#define int8_t    i8
#define uint8_t   u8
#define intptr_t  i32
#define uintptr_t u32

/* isxdigit — нет в нашем ctype */
static int isxdigit_c(int c) { return (c>='0'&&c<='9')||(c>='a'&&c<='f')||(c>='A'&&c<='F'); }
#define isxdigit(c) isxdigit_c(c)

/* Наши snprintf/vsnprintf заменяют cdm_no_stdio_* */
extern int snprintf(char *out, unsigned int n, const char *fmt, ...);
extern int vsnprintf(char *out, unsigned int n, const char *fmt, __builtin_va_list ap);
#define cdm_no_stdio_snprintf  snprintf
#define cdm_no_stdio_vsnprintf vsnprintf

/* Override platform hooks for N2600-OS */
#define cdm_platform_putc(c)  do { } while (0)
#define cdm_platform_clock()  ((unsigned long)(timer_ticks() * 10))

/* ctype.h replacements */
static int isdigit_c(int c) { return c >= '0' && c <= '9'; }
static int isalpha_c(int c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
static int isalnum_c(int c) { return isdigit_c(c) || isalpha_c(c); }
#define isdigit(c) isdigit_c(c)
#define isalpha(c) isalpha_c(c)
#define isalnum(c) isalnum_c(c)
/* isspace в интерпретаторе не используется — tokenizer проверяет пробелы
 * инлайн; заглушка убрана, чтобы не ловить -Wunused-function. */
#define toupper(c) (((c)>='a'&&(c)<='z')?(c)-32:(c))
#define tolower(c) (((c)>='A'&&(c)<='Z')?(c)+32:(c))

/* size_t — уже определён через наши типы */
typedef unsigned long size_t;

/* strstr и strcat — в string.c хост-ОС (strstr добавлялась для HTTP Trace,
 * strcat перенесена туда же — снимает конфликт объявлений со string.h).
 * Если в вашей string.c strcat еще нет — реализация в шапке файла. */

/* atoi — простая реализация */
static int atoi(const char *s) {
    int sign = 1, r = 0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { sign = -1; s++; }
    else if (*s == '+') s++;
    while (*s >= '0' && *s <= '9') { r = r * 10 + (*s - '0'); s++; }
    return r * sign;
}

/* atof — полноценный разбор double. Раньше возвращала только int-часть,
 * из-за чего без libc литерал 2.1 парсился как 2.0 (ceil(2.1)==2,
 * 1.5+2==3). */
static double atof(const char *s) {
    double r = 0.0, frac = 0.0, scale = 0.1;
    int sign = 1;
    if (!s) return 0.0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { sign = -1; s++; }
    else if (*s == '+') s++;
    while (*s >= '0' && *s <= '9') { r = r * 10.0 + (*s - '0'); s++; }
    if (*s == '.') {
        s++;
        while (*s >= '0' && *s <= '9') { frac += (*s - '0') * scale; scale *= 0.1; s++; }
    }
    r += frac;
    if (*s == 'e' || *s == 'E') {
        int esign = 1, e = 0;
        s++;
        if (*s == '-') { esign = -1; s++; }
        else if (*s == '+') s++;
        while (*s >= '0' && *s <= '9') { e = e * 10 + (*s - '0'); s++; }
        while (e-- > 0) r = (esign > 0) ? r * 10.0 : r / 10.0;
    }
    return sign * r;
}

/* NULL */
#ifndef NULL
#define NULL ((void*)0)
#endif

/* ----------------------------------------------------------------------
 *  Platform hooks — уже определены выше для N2600-OS
 * ---------------------------------------------------------------------- */

/* Internal debug printf -- no-op when CDM_DEBUG_PRINTF=0 */
#if CDM_DEBUG_PRINTF && CDM_HAS_STDIO
#define CDM_DBG(...)  do { printf(__VA_ARGS__); } while (0)
#else
#define CDM_DBG(...)  do { } while (0)
#endif

/* Stub out stdio/stdlib/math functions when not available, so the rest of
 * the file can be written as if libc is always present. */
#if !CDM_HAS_STDIO
#define snprintf   cdm_no_stdio_snprintf
#define vsnprintf  cdm_no_stdio_vsnprintf
#define printf(...)  do { } while (0)
/* Не выражение-макрос, а настоящая функция: вызов-выражение сохраняет int
 * (std_fputs/std_fwrite используют возвращаемое значение), а вызов-оператор
 * не даёт "statement with no effect". Имя cdm_stub_fputs — чтобы не
 * конфликтовать со встроенным объявлением fputs. */
static int cdm_stub_fputs(const char* s, void* fp) { (void)s; (void)fp; return 0; }
#define fputs(s, fp)  cdm_stub_fputs((s), (fp))
#define fgets(b, n, fp)  ((void)(b), (void)(n), (void)(fp), (char*)0)
#ifndef stdout
#define stdout  ((void*)0)
#endif
#ifndef stderr
#define stderr  ((void*)0)
#endif
#ifndef stdin
#define stdin   ((void*)0)
#endif
#endif

#if !CDM_HAS_STDLIB
/* N2600-OS: используем наши malloc/free, не заглушки! */
#define calloc(n, sz)  memset(malloc((n)*(sz)), 0, (n)*(sz))
#define realloc(p, n)  ((void)(p), malloc(n))
#define atoll(s)  (0LL)
#define rand()    (0)
#define srand(s)  ((void)(s))
#endif

#if !CDM_HAS_FILES
#if !CDM_HAS_STDIO
typedef void FILE;
#endif
#define fopen(p, m)  ((void)(p), (void)(m), (FILE*)0)
#define fclose(fp)   ((void)(fp), 0)
#define fread(b, sz, n, fp)  ((void)(b), (void)(sz), (void)(n), (void)(fp), (size_t)0)
#define fwrite(b, sz, n, fp) ((void)(b), (void)(sz), (void)(n), (void)(fp), (size_t)0)
/* fputs/fgets уже определены в #if !CDM_HAS_STDIO выше — дубликаты убраны */
#define feof(fp)  ((void)(fp), 1)
#define fprintf(...)  ((void)0, 0)
#endif

#if !CDM_HAS_MATH
/* Fallbacks so file compiles without libm. Script math calls return 0. */
#define sqrt(x)   (0.0)
#define sin(x)    (0.0)
#define cos(x)    (0.0)
#define tan(x)    (0.0)
#define asin(x)   (0.0)
#define acos(x)   (0.0)
#define atan(x)   (0.0)
#define atan2(y,x) (0.0)
#define floor(x)  (0.0)
#define ceil(x)   (0.0)
#define round(x)  (0.0)
#define fabs(x)   (0.0)
#define fmod(a,b) (0.0)
#define pow(a,b)  (0.0)
#define exp(x)    (0.0)
#define log(x)    (0.0)
#define log10(x)  (0.0)
#define log2(x)   (0.0)
#endif

#if !CDM_HAS_FLOATING
/* Even without FP hardware we still keep double/float as types but warn.
 * The interpreter uses doubles internally for the `float` CDM type. */
#endif


/* ========================================================================
 *  Begin section: CDM_AST.h
 * ======================================================================== */




typedef enum {
    CDM_TYPE_INT = 0,
    CDM_TYPE_FLOAT,
    CDM_TYPE_PTR,
    CDM_TYPE_STRUCT,
    CDM_TYPE_ARRAY,
    CDM_TYPE_STRING,
    CDM_TYPE_REF
} CDM_ValueType_t;

typedef struct {
    CDM_ValueType_t type;
    int             struct_id;
    int             array_len;
    int             array_dim;
    int             array_sizes[4];
    CDM_ValueType_t array_elem_type;
    int             array_elem_struct_id;
    int             owned;
    int             from_new;
    union {
        int64_t i;
        double  f;
        void*   p;
    } v;
} CDM_Value_t;

#define CDM_MAX_STRUCT_TYPES      16
#define CDM_MAX_FIELDS_PER_STRUCT 16

typedef struct {
    char            name[32];
    CDM_ValueType_t type;
    int             struct_id;
    int             array_len;
} CDM_FieldDef_t;

typedef struct {
    char            name[32];
    CDM_FieldDef_t  fields[CDM_MAX_FIELDS_PER_STRUCT];
    int             field_count;
    int             is_union;   /* 1 = union (парсится как struct) */
} CDM_StructDef_t;

typedef enum {
    TOK_EOF = 0, TOK_IDENT, TOK_NUMBER, TOK_STRING,
    TOK_OP, TOK_PUNCT, TOK_KEYWORD
} TokenType_t;

typedef struct { TokenType_t type; char text[64]; int line; } Token_t;

typedef enum {
    AST_PROGRAM = 0,
    AST_FUNC_DECL, AST_PARAM,
    AST_VAR_DECL, AST_ARRAY_DECL, AST_STRUCT_DEF,
    AST_ENUM_DECL,                     /* ★ 新增 */
    AST_BLOCK, AST_RETURN, AST_EXPR_STMT,
    AST_IF, AST_WHILE, AST_FOR, AST_RANGE_FOR,
    AST_DO_WHILE,
    AST_SWITCH, AST_CASE, AST_DEFAULT,
    AST_BREAK, AST_CONTINUE,
    AST_TERNARY,
    AST_BINARY, AST_UNARY, AST_ASSIGN,
    AST_CAST,                          /* ★ 新增 */
    AST_SIZEOF,                        /* ★ 新增 */
    AST_FUNC_CALL, AST_METHOD_CALL,
    AST_IDENTIFIER,
    AST_NUMBER, AST_STRING, AST_MEMBER,
    AST_MEMBER_ACCESS, AST_ARRAY_SUBSCRIPT, AST_ARRAY_INIT,
    AST_NEW, AST_NEW_ARRAY, AST_DELETE, AST_DELETE_ARRAY,
    AST_GOTO, AST_LABEL, AST_TYPEDEF   /* ★ C-образность: goto/метки/typedef */
} ASTType_t;

typedef struct ASTNode {
    ASTType_t type;
    char      name[64];
    int64_t   ival;
    double    fval;
    int       is_ptr;
    int       is_auto;
    int       struct_id;
    CDM_ValueType_t decl_type;
    int       line;

    int             array_dim;
    int             array_len;
    int             array_sizes[4];

    void*  cached_symbol;
    void*  cached_host_func;
    void*  cached_host_ex;
    int    cached_sym_tried;
    int    cached_hf_tried;
    int    cached_he_tried;

    struct ASTNode* first_child;
    struct ASTNode* next_sibling;
    struct ASTNode* left;
    struct ASTNode* right;
    struct ASTNode* body;
    struct ASTNode* init;
    struct ASTNode* update;
    struct ASTNode* cond;
    struct ASTNode* step;

    struct ASTNode** args;
    int              arg_count;
    struct ASTNode** elems;
    int              elem_count;
} ASTNode_t;

typedef struct { const char* src; int pos; int len; int line; Token_t cur; } CDM_Parser_t;

#define CDM_MAX_ERRORS 16
typedef struct { int line; int col; char message[80]; } CDM_Error_t;

void               CDM_ClearErrors(void);
int                CDM_GetErrorCount(void);
const CDM_Error_t* CDM_GetError(int idx);

ASTNode_t* CDM_Parse(const char* source);
void       CDM_FreeAST(ASTNode_t* root);
void       CDM_PrintAST(ASTNode_t* node, int indent);
int        CDM_Execute(ASTNode_t* root);

typedef int (*CDM_HostFunc_t)(int argc, const char** argv);
void CDM_RegisterHostFunc(const char* name, CDM_HostFunc_t fn);
void CDM_RegisterHostFuncFloat(const char* name, CDM_HostFunc_t fn);

typedef CDM_Value_t (*CDM_HostFuncEx_t)(int argc, CDM_Value_t* argv);
void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn);

CDM_Value_t CDM_MakeString(const char* s);
CDM_Value_t CDM_MakeStringOwned(char* s);
CDM_Value_t CDM_MakePtr(void* p, int owned);

int          CDM_IsRef(CDM_Value_t v);
CDM_Value_t  CDM_Deref(CDM_Value_t v);
CDM_Value_t* CDM_RefPtr(CDM_Value_t v);
void         CDM_AssignRef(CDM_Value_t ref, CDM_Value_t value);

/* ========================================================================
 *  Begin section: CDM_PREPROC.h
 * ======================================================================== */

typedef char* (*CDM_IncludeResolver_t)(const char* filename);

void CDM_SetIncludeResolver(CDM_IncludeResolver_t fn);

void CDM_ResetIncludes(void);

char* CDM_Preprocess(const char* src);

/* ========================================================================
 *  Begin section: CDM_STD.h
 * ======================================================================== */




void CDM_Std_Init(void);

/* ========================================================================
 *  Begin section: CDM_ArduinoBridge.h
 * ======================================================================== */




  void CDM_ArduinoBridge_Init(void);

/* ========================================================================
 *  Begin section: CMScript.h
 * ======================================================================== */




void CMScript_Init(void);

/* ========================================================================
 *  Begin section: CDM_AST.cpp
 * ======================================================================== */


static int64_t cdm_strtoll(const char* s, int base) {
  if (!s) return 0;
  int64_t r = 0;
  int sign = 1;
  int auto_base = (base == 0);
  while (*s == ' ' || *s == '\t') s++;
  if (*s == '-') { sign = -1; s++; }
  else if (*s == '+') s++;
  if (auto_base) {
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) { base = 16; s += 2; }
    else if (s[0] == '0') { base = 8; s++; }
    else base = 10;
  } else if (base == 16) {
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
  }
  while (*s) {
    int d;
    if (*s >= '0' && *s <= '9') d = *s - '0';
    else if (*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
    else if (*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
    else break;
    if (d >= base) break;
    r = r * base + d;
    s++;
  }
  return sign * r;
}

/* cdm_atoll — теперь просто обёртка над cdm_strtoll(s, 10) */
static int64_t cdm_atoll(const char* s) { return cdm_strtoll(s, 10); }

#define CDM_MAX_HOST_FUNCS 128
#define CDM_MAX_HOST_EX 128  /* 69 (std) + до 40 host-функций ОС (см. cmscript_api.c) */
#define MAX_SYMBOLS 256
#define MAX_SCOPE_DEPTH 32
#define MAX_USER_FUNCS 64
#define CDM_ARR_MAGIC 0xDEADBEEF

typedef struct {
  char name[64];
  CDM_HostFunc_t func;
} HostFuncEntry_t;
typedef struct {
  char name[64];
  CDM_HostFuncEx_t func;
} HostExEntry_t;
typedef struct {
  char name[64];
  CDM_Value_t value;
  int in_use;
} Symbol_t;

static HostFuncEntry_t* g_host_funcs = NULL;
static char* g_float_funcs = NULL;
static HostExEntry_t* g_host_ex = NULL;
static CDM_StructDef_t* g_struct_defs = NULL;
static Symbol_t* g_symbols = NULL;
static ASTNode_t** g_user_funcs = NULL;

static int g_host_func_count = 0;
static int g_float_func_count = 0;
static int g_host_ex_count = 0;
static int g_struct_def_count = 0;
static int g_symbol_count = 0;
static int g_user_func_count = 0;

static int g_scope_mark[MAX_SCOPE_DEPTH];
static int g_scope_depth = 0;

static int g_cdm_allocated = 0;

static int g_break_flag = 0;
static int g_continue_flag = 0;

/* goto/метки: pending-флаг раскручивается по блокам вверх,
 * пока не найден блок с меткой с этим именем */
static char g_goto_label[64] = {0};
static int  g_goto_pending = 0;

static int g_parse_line = 1;
static int g_current_line = 0;

static int g_panic_mode = 0;

#define MAX_ENUM_ENTRIES 128
typedef struct {
  char    name[64];
  int64_t value;
} EnumEntry_t;
static EnumEntry_t g_enums[MAX_ENUM_ENTRIES];
static int g_enum_count = 0;

static int find_enum(const char* name) {
  for (int i = 0; i < g_enum_count; i++)
    if (strcmp(g_enums[i].name, name) == 0) return i;
  return -1;
}

static int cdm_ensure_alloc(void) {
  if (g_cdm_allocated) return 1;
  g_host_funcs = (HostFuncEntry_t*)calloc(CDM_MAX_HOST_FUNCS, sizeof(HostFuncEntry_t));
  g_float_funcs = (char*)calloc(CDM_MAX_HOST_FUNCS, 64);
  g_host_ex = (HostExEntry_t*)calloc(CDM_MAX_HOST_EX, sizeof(HostExEntry_t));
  g_struct_defs = (CDM_StructDef_t*)calloc(CDM_MAX_STRUCT_TYPES, sizeof(CDM_StructDef_t));
  g_symbols = (Symbol_t*)calloc(MAX_SYMBOLS, sizeof(Symbol_t));
  g_user_funcs = (ASTNode_t**)calloc(MAX_USER_FUNCS, sizeof(ASTNode_t*));
  if (!g_host_funcs || !g_float_funcs || !g_host_ex || !g_struct_defs || !g_symbols || !g_user_funcs)
    return 0;
  g_cdm_allocated = 1;
  return 1;
}

static const char* float_func_at(int i) { return g_float_funcs + i * 64; }

void CDM_RegisterHostFunc(const char* name, CDM_HostFunc_t fn) {
  if (!cdm_ensure_alloc()) return;
  if (g_host_func_count >= CDM_MAX_HOST_FUNCS) return;
  strncpy(g_host_funcs[g_host_func_count].name, name, 63);
  g_host_funcs[g_host_func_count].name[63] = '\0';
  g_host_funcs[g_host_func_count].func = fn;
  g_host_func_count++;
}
void CDM_RegisterHostFuncFloat(const char* name, CDM_HostFunc_t fn) {
  if (!cdm_ensure_alloc()) return;
  if (g_host_func_count >= CDM_MAX_HOST_FUNCS) return;
  strncpy(g_host_funcs[g_host_func_count].name, name, 63);
  g_host_funcs[g_host_func_count].name[63] = '\0';
  g_host_funcs[g_host_func_count].func = fn;
  g_host_func_count++;
  if (g_float_func_count < CDM_MAX_HOST_FUNCS) {
    strncpy(g_float_funcs + g_float_func_count * 64, name, 63);
    g_float_funcs[g_float_func_count * 64 + 63] = '\0';
    g_float_func_count++;
  }
}
void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn) {
  if (!cdm_ensure_alloc()) return;
  if (g_host_ex_count >= CDM_MAX_HOST_EX) return;
  strncpy(g_host_ex[g_host_ex_count].name, name, 63);
  g_host_ex[g_host_ex_count].name[63] = '\0';
  g_host_ex[g_host_ex_count].func = fn;
  g_host_ex_count++;
}

static CDM_HostFunc_t find_host_func(const char* name) {
  if (!g_host_funcs) return NULL;
  for (int i = 0; i < g_host_func_count; i++)
    if (strcmp(g_host_funcs[i].name, name) == 0) return g_host_funcs[i].func;
  return NULL;
}
static CDM_HostFuncEx_t find_host_ex(const char* name) {
  if (!g_host_ex) return NULL;
  for (int i = 0; i < g_host_ex_count; i++)
    if (strcmp(g_host_ex[i].name, name) == 0) return g_host_ex[i].func;
  return NULL;
}
static int is_float_func(const char* name) {
  if (!g_float_funcs) return 0;
  for (int i = 0; i < g_float_func_count; i++)
    if (strcmp(float_func_at(i), name) == 0) return 1;
  return 0;
}

static int find_struct_def(const char* name) {
  if (!g_struct_defs) return -1;
  for (int i = 0; i < g_struct_def_count; i++)
    if (strcmp(g_struct_defs[i].name, name) == 0) return i;
  return -1;
}
static int find_field_index(int sid, const char* name) {
  if (sid < 0 || sid >= g_struct_def_count) return -1;
  CDM_StructDef_t* s = &g_struct_defs[sid];
  for (int i = 0; i < s->field_count; i++)
    if (strcmp(s->fields[i].name, name) == 0) return i;
  return -1;
}
static int is_user_type(const char* name) { return find_struct_def(name) >= 0; }

/* ----------------------------------------------------------------------
 *  typedef — таблица алиасов типов.
 *  target — имя struct/union-цели: резолвится при ИСПОЛЬЗОВАНИИ алиаса
 *  (typedef_struct_id), поэтому forward-typedef работает:
 *      typedef struct Node Node;      -- Node еще не определена
 *      struct Node { ... };
 * ---------------------------------------------------------------------- */
#define MAX_TYPEDEFS 64
typedef struct {
  char            name[64];
  char            target[64];   /* имя struct/union-цели или "" */
  CDM_ValueType_t type;
  int             struct_id;
  int             is_ptr;
} TypedefEntry_t;
static TypedefEntry_t g_typedefs[MAX_TYPEDEFS];
static int g_typedef_count = 0;

static int find_typedef(const char* name) {
  for (int i = 0; i < g_typedef_count; i++)
    if (strcmp(g_typedefs[i].name, name) == 0) return i;
  return -1;
}
static int typedef_struct_id(int td) {
  if (td < 0 || td >= g_typedef_count) return -1;
  if (g_typedefs[td].target[0]) return find_struct_def(g_typedefs[td].target);
  return g_typedefs[td].struct_id;
}
static void add_typedef(const char* name, CDM_ValueType_t t, int sid,
                        int is_ptr, const char* target) {
  if (find_typedef(name) >= 0) return;   /* повторный typedef игнорируем */
  if (g_typedef_count >= MAX_TYPEDEFS) return;
  TypedefEntry_t* td = &g_typedefs[g_typedef_count++];
  strncpy(td->name, name, 63);   td->name[63] = '\0';
  td->target[0] = '\0';
  if (target) { strncpy(td->target, target, 63); td->target[63] = '\0'; }
  td->type = t;
  td->struct_id = sid;
  td->is_ptr = is_ptr;
}

static CDM_Error_t g_errors[CDM_MAX_ERRORS];
static int g_error_count = 0;
static int g_error_overflow = 0;

void CDM_ClearErrors(void) {
  g_error_count = 0;
  g_error_overflow = 0;
  g_panic_mode = 0;
}
int CDM_GetErrorCount(void) { return g_error_count + (g_error_overflow ? 1 : 0); }
const CDM_Error_t* CDM_GetError(int idx) {
  if (idx < 0 || idx >= g_error_count) return NULL;
  return &g_errors[idx];
}

static void report_error(CDM_Parser_t* p, const char* fmt, ...) {
  if (g_error_count >= CDM_MAX_ERRORS) { g_error_overflow = 1; return; }
  CDM_Error_t* e = &g_errors[g_error_count++];
  e->line = p ? p->line : g_current_line;
  e->col = p ? p->pos : 0;
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(e->message, sizeof(e->message), fmt, ap);
  va_end(ap);
}

static int64_t sizeof_value(CDM_Value_t v) {
  switch (v.type) {
    case CDM_TYPE_FLOAT:  return 8;
    case CDM_TYPE_INT:    return 4;
    case CDM_TYPE_PTR:    return 8;
    case CDM_TYPE_STRING: return 8;
    case CDM_TYPE_ARRAY: {
      int64_t es = 4;
      if (v.array_elem_type == CDM_TYPE_FLOAT) es = 8;
      else if (v.array_elem_type == CDM_TYPE_PTR) es = 8;
      return es * v.array_len;
    }
    case CDM_TYPE_STRUCT: {
      if (v.struct_id < 0) return 0;
      int64_t total = 0;
      CDM_StructDef_t* sd = &g_struct_defs[v.struct_id];
      for (int i = 0; i < sd->field_count; i++) {
        int64_t es = 4;
        if (sd->fields[i].type == CDM_TYPE_FLOAT) es = 8;
        else if (sd->fields[i].type == CDM_TYPE_PTR) es = 8;
        if (sd->fields[i].array_len > 0) total += es * sd->fields[i].array_len;
        else total += es;
      }
      return total;
    }
    default: return 4;
  }
}

static int64_t eval_const(ASTNode_t* node) {
  if (!node) return 0;
  if (node->type == AST_NUMBER) return node->ival;
  if (node->type == AST_IDENTIFIER) {
    int i = find_enum(node->name);
    return (i >= 0) ? g_enums[i].value : 0;
  }
  if (node->type == AST_UNARY && strcmp(node->name, "-") == 0)
    return -eval_const(node->left);
  if (node->type == AST_UNARY && strcmp(node->name, "~") == 0)
    return ~eval_const(node->left);
  if (node->type == AST_UNARY && strcmp(node->name, "!") == 0)
    return !eval_const(node->left);
  if (node->type == AST_BINARY) {
    int64_t l = eval_const(node->left);
    int64_t r = eval_const(node->right);
    const char* op = node->name;
    if (strcmp(op, "+") == 0)  return l + r;
    if (strcmp(op, "-") == 0)  return l - r;
    if (strcmp(op, "*") == 0)  return l * r;
    if (strcmp(op, "/") == 0)  return r != 0 ? l / r : 0;
    if (strcmp(op, "%") == 0)  return r != 0 ? l % r : 0;
    if (strcmp(op, "&") == 0)  return l & r;
    if (strcmp(op, "|") == 0)  return l | r;
    if (strcmp(op, "^") == 0)  return l ^ r;
    if (strcmp(op, "<<") == 0) return l << r;
    if (strcmp(op, ">>") == 0) return l >> r;
  }
  return 0;
}

static void init_common(CDM_Value_t* v) {
  v->struct_id = -1;
  v->array_len = 0;
  v->array_dim = 0;
  v->array_sizes[0] = v->array_sizes[1] = v->array_sizes[2] = v->array_sizes[3] = 0;
  v->array_elem_type = CDM_TYPE_INT;
  v->array_elem_struct_id = -1;
  v->owned = 0;
  v->from_new = 0;
  v->v.p = NULL;
}
static CDM_Value_t make_int(int64_t i) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_INT; v.v.i = i; return v;
}
static CDM_Value_t make_float(double f) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_FLOAT; v.v.f = f; return v;
}
static CDM_Value_t make_ptr(void* p, int owned) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_PTR; v.owned = owned; v.v.p = p; return v;
}
static CDM_Value_t make_struct(void* p, int sid, int owned) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_STRUCT; v.struct_id = sid; v.owned = owned; v.v.p = p; return v;
}
static CDM_Value_t make_array(void* p, int len, int dim,
                              const int* sizes, CDM_ValueType_t elem, int esid, int owned) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_ARRAY;
  v.array_len = len;
  v.array_dim = dim;
  for (int i = 0; i < 4; i++) v.array_sizes[i] = (i < dim) ? sizes[i] : 0;
  v.array_elem_type = elem;
  v.array_elem_struct_id = esid;
  v.owned = owned;
  v.v.p = p;
  return v;
}
static CDM_Value_t make_ref(CDM_Value_t* ptr) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_REF; v.v.p = ptr; return v;
}

CDM_Value_t CDM_MakeString(const char* s) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_STRING;
  size_t n = s ? strlen(s) : 0;
  char* buf = (char*)malloc(n + 1);
  if (!buf) return v;
  if (s) memcpy(buf, s, n);
  buf[n] = '\0';
  v.owned = 1;
  v.v.p = buf;
  return v;
}
CDM_Value_t CDM_MakeStringOwned(char* s) {
  CDM_Value_t v; init_common(&v);
  v.type = CDM_TYPE_STRING; v.owned = 1; v.v.p = s; return v;
}
CDM_Value_t CDM_MakePtr(void* p, int owned) { return make_ptr(p, owned); }

int CDM_IsRef(CDM_Value_t v) { return v.type == CDM_TYPE_REF; }
CDM_Value_t* CDM_RefPtr(CDM_Value_t v) {
  return (v.type == CDM_TYPE_REF && v.v.p) ? (CDM_Value_t*)v.v.p : NULL;
}
CDM_Value_t CDM_Deref(CDM_Value_t v) {
  int guard = 0;
  while (v.type == CDM_TYPE_REF && v.v.p && guard < 8) {
    v = *(CDM_Value_t*)v.v.p;
    guard++;
  }
  return v;
}

static void value_release(CDM_Value_t v);
static void set_string_slot(CDM_Value_t* slot, const char* s);

void CDM_AssignRef(CDM_Value_t ref, CDM_Value_t value) {
  CDM_Value_t* slot = CDM_RefPtr(ref);
  if (!slot) return;

  if (value.type == CDM_TYPE_STRING) {
    set_string_slot(slot, value.v.p ? (const char*)value.v.p : "");
    return;
  }

  value_release(*slot);
  *slot = value;
  slot->owned = 0;
  slot->from_new = 0;
}

#define VAL_IS(v, t)       ((v).type == (t))
#define val_is_float(v)    VAL_IS(v, CDM_TYPE_FLOAT)
#define val_is_ptr(v)      VAL_IS(v, CDM_TYPE_PTR)
#define val_is_struct(v)   VAL_IS(v, CDM_TYPE_STRUCT)
#define val_is_array(v)    VAL_IS(v, CDM_TYPE_ARRAY)
#define val_is_string(v)   VAL_IS(v, CDM_TYPE_STRING)

static double val_to_double_raw(CDM_Value_t v) {
  if (v.type == CDM_TYPE_FLOAT) return v.v.f;
  if (v.type == CDM_TYPE_INT) return (double)v.v.i;
  if (v.type == CDM_TYPE_STRING && v.v.p) return atof((const char*)v.v.p);
  return 0.0;
}
static int64_t val_to_int_raw(CDM_Value_t v) {
  if (v.type == CDM_TYPE_FLOAT) return (int64_t)v.v.f;
  if (v.type == CDM_TYPE_PTR) return (int64_t)(intptr_t)v.v.p;
  if (v.type == CDM_TYPE_STRING && v.v.p) return cdm_atoll((const char*)v.v.p);
  return v.v.i;
}
static const char* val_to_str_raw(CDM_Value_t v) {
  if (v.type == CDM_TYPE_STRING && v.v.p) return (const char*)v.v.p;
  return "";
}
static const char* val_to_str(CDM_Value_t v) { return val_to_str_raw(CDM_Deref(v)); }
static double val_to_double(CDM_Value_t v) { return val_to_double_raw(CDM_Deref(v)); }
static int64_t val_to_int(CDM_Value_t v)   { return val_to_int_raw(CDM_Deref(v)); }

static void value_release(CDM_Value_t v) {
  if (v.type == CDM_TYPE_REF) return;
  if (!v.v.p) return;
  if (v.type == CDM_TYPE_STRING && v.owned) { free(v.v.p); return; }
  if (v.type == CDM_TYPE_ARRAY && v.owned) {
    CDM_Value_t* elems = (CDM_Value_t*)v.v.p;
    for (int i = 0; i < v.array_len; i++) value_release(elems[i]);
    free(elems);
    return;
  }
  if (v.owned) free(v.v.p);
}

/* Единая точка "положить строку в слот" — заменяет 5 повторов паттерна
 * "освободить старое / malloc + memcpy / записать". Копирование выполняется
 * ДО освобождения слота, чтобы `s = s;` не читало освобождённую память.
 * buf==NULL после неудачного malloc даст owned-пустую строку (v.p=NULL). */
static void set_string_slot(CDM_Value_t* slot, const char* s) {
  if (!slot) return;
  size_t n = s ? strlen(s) : 0;
  char* buf = (char*)malloc(n + 1);
  if (buf) { if (s) memcpy(buf, s, n); buf[n] = '\0'; }
  if (slot->type == CDM_TYPE_STRING) {
    if (slot->owned && slot->v.p) free(slot->v.p);
  } else if (slot->owned) {
    value_release(*slot);
  }
  *slot = CDM_MakeStringOwned(buf);
}

typedef struct {
  uint32_t magic;
  uint32_t count;
  uint32_t elem_type;
  int32_t elem_struct_id;
} CDM_ArrayHeader_t;

static CDM_Value_t* array_new(int n, CDM_ValueType_t et, int esid) {
  size_t total = sizeof(CDM_ArrayHeader_t) + n * sizeof(CDM_Value_t);
  uint8_t* raw = (uint8_t*)malloc(total);
  if (!raw) return NULL;
  CDM_ArrayHeader_t* h = (CDM_ArrayHeader_t*)raw;
  h->magic = CDM_ARR_MAGIC;
  h->count = (uint32_t)n;
  h->elem_type = (uint32_t)et;
  h->elem_struct_id = esid;
  CDM_Value_t* arr = (CDM_Value_t*)(raw + sizeof(CDM_ArrayHeader_t));
  for (int i = 0; i < n; i++) {
    if (et == CDM_TYPE_STRUCT && esid >= 0) {
      int nf = g_struct_defs[esid].field_count;
      CDM_Value_t* fblock = (CDM_Value_t*)calloc(nf, sizeof(CDM_Value_t));
      for (int j = 0; j < nf; j++) fblock[j] = make_int(0);
      arr[i] = make_struct(fblock, esid, 1);
    } else if (et == CDM_TYPE_FLOAT) {
      arr[i] = make_float(0.0);
    } else if (et == CDM_TYPE_STRING) {
      arr[i] = CDM_MakeString("");
    } else {
      arr[i] = make_int(0);
    }
  }
  return arr;
}
static int array_free(void* p) {
  if (!p) return 0;
  uint8_t* raw = (uint8_t*)p - sizeof(CDM_ArrayHeader_t);
  CDM_ArrayHeader_t* h = (CDM_ArrayHeader_t*)raw;
  if (h->magic != CDM_ARR_MAGIC) return 0;
  CDM_Value_t* arr = (CDM_Value_t*)p;
  for (uint32_t i = 0; i < h->count; i++) value_release(arr[i]);
  free(raw);
  return 1;
}

static void scope_enter(void) {
  if (g_scope_depth < MAX_SCOPE_DEPTH) {
    g_scope_mark[g_scope_depth] = g_symbol_count;
    g_scope_depth++;
  }
}
static void scope_exit(void) {
  if (g_scope_depth > 0) {
    g_scope_depth--;
    int mark = g_scope_mark[g_scope_depth];
    for (int i = mark; i < g_symbol_count; i++) {
      if (g_symbols[i].in_use) value_release(g_symbols[i].value);
      g_symbols[i].in_use = 0;
    }
    g_symbol_count = mark;
  }
}
static Symbol_t* find_symbol(const char* name) {
  if (!g_symbols) return NULL;
  for (int i = g_symbol_count - 1; i >= 0; i--)
    if (g_symbols[i].in_use && strcmp(g_symbols[i].name, name) == 0) return &g_symbols[i];
  return NULL;
}
static Symbol_t* create_symbol(const char* name) {
  if (!g_symbols) return NULL;
  if (g_symbol_count >= MAX_SYMBOLS) return NULL;
  Symbol_t* s = &g_symbols[g_symbol_count++];
  strncpy(s->name, name, 63);
  s->name[63] = '\0';
  s->value = make_int(0);
  s->in_use = 1;
  return s;
}

static void collect_user_funcs(ASTNode_t* program) {
  g_user_func_count = 0;
  ASTNode_t* c = program->first_child;
  while (c) {
    if (c->type == AST_FUNC_DECL && g_user_func_count < MAX_USER_FUNCS)
      g_user_funcs[g_user_func_count++] = c;
    c = c->next_sibling;
  }
}
static ASTNode_t* find_user_func(const char* name) {
  for (int i = 0; i < g_user_func_count; i++)
    if (strcmp(g_user_funcs[i]->name, name) == 0) return g_user_funcs[i];
  return NULL;
}

static void clear_ast_cache(ASTNode_t* node) {
  if (!node) return;
  node->cached_symbol = NULL;
  node->cached_host_func = NULL;
  node->cached_host_ex = NULL;
  node->cached_sym_tried = 0;
  node->cached_hf_tried = 0;
  node->cached_he_tried = 0;
  ASTNode_t* c = node->first_child;
  while (c) { clear_ast_cache(c); c = c->next_sibling; }
  if (node->left)   clear_ast_cache(node->left);
  if (node->right)  clear_ast_cache(node->right);
  if (node->body)   clear_ast_cache(node->body);
  if (node->init)   clear_ast_cache(node->init);
  if (node->update) clear_ast_cache(node->update);
  if (node->cond)   clear_ast_cache(node->cond);
  if (node->step)   clear_ast_cache(node->step);
  for (int i = 0; i < node->arg_count; i++)  clear_ast_cache(node->args[i]);
  for (int i = 0; i < node->elem_count; i++) clear_ast_cache(node->elems[i]);
}

static const char* KEYWORDS[] = {
  "int", "char", "void", "float", "double", "return",
  "if", "else", "while", "for", "break", "continue",
  "switch", "case", "default", "do",
  "enum", "sizeof", "typedef", "goto",
  "const", "static", "long", "short", "unsigned", "signed",
  "extern", "volatile", "register", "inline", "restrict", "_Bool",
  "struct", "union", "class", "true", "false", "nullptr",
  "new", "delete", "auto",
  "int8_t", "uint8_t", "int16_t", "uint16_t",
  "int32_t", "uint32_t", "int64_t", "uint64_t",
  "size_t", "ssize_t", "intptr_t", "uintptr_t",
  "intmax_t", "uintmax_t",
  "int_fast8_t", "uint_fast8_t", "int_fast16_t", "uint_fast16_t",
  "int_fast32_t", "uint_fast32_t", "int_fast64_t", "uint_fast64_t",
  "int_least8_t", "uint_least8_t", "int_least16_t", "uint_least16_t",
  "int_least32_t", "uint_least32_t", "int_least64_t", "uint_least64_t"
};
#define NUM_KEYWORDS (sizeof(KEYWORDS) / sizeof(KEYWORDS[0]))
static int is_keyword(const char* s) {
  for (int i = 0; i < (int)NUM_KEYWORDS; i++)
    if (strcmp(s, KEYWORDS[i]) == 0) return 1;
  return 0;
}
static int is_ident_start(char c) { return isalpha((unsigned char)c) || c == '_'; }
static int is_ident_char(char c)  { return isalnum((unsigned char)c) || c == '_'; }

static void next_token(CDM_Parser_t* p) {
  while (p->pos < p->len) {
    char c = p->src[p->pos];
    if (c == ' ' || c == '\t' || c == '\r') { p->pos++; continue; }
    if (c == '\n') { p->line++; p->pos++; continue; }
    if (c == '/' && p->pos + 1 < p->len && p->src[p->pos + 1] == '/') {
      while (p->pos < p->len && p->src[p->pos] != '\n') p->pos++;
      continue;
    }
    if (c == '/' && p->pos + 1 < p->len && p->src[p->pos + 1] == '*') {
      p->pos += 2;
      while (p->pos + 1 < p->len && !(p->src[p->pos] == '*' && p->src[p->pos + 1] == '/')) {
        if (p->src[p->pos] == '\n') p->line++;
        p->pos++;
      }
      p->pos += 2;
      continue;
    }
    break;
  }
  g_parse_line = p->line;

  if (p->pos >= p->len) {
    p->cur.type = TOK_EOF;
    p->cur.text[0] = '\0';
    return;
  }
  char c = p->src[p->pos];

  if (c == '"') {
    p->pos++;
    int j = 0;
    while (p->pos < p->len && p->src[p->pos] != '"' && j < 63) {
      char ch = p->src[p->pos];
      if (ch == '\\' && p->pos + 1 < p->len) {
        p->pos++;
        char esc = p->src[p->pos];
        if (esc == 'n') ch = '\n';
        else if (esc == 't') ch = '\t';
        else if (esc == '\\') ch = '\\';
        else if (esc == '"') ch = '"';
        else ch = esc;
      }
      p->cur.text[j++] = ch;
      p->pos++;
    }
    p->cur.text[j] = '\0';
    if (p->pos < p->len) p->pos++;
    p->cur.type = TOK_STRING;
    return;
  }

  /* ★ C-образность: символьные литералы 'a', '\n', '\0'.
   * Значение кодируется числом (как в C: мульти-символьные 'ab' тоже
   * допустимы), текст токена — десятичная запись, дальше идет как число. */
  if (c == '\'') {
    p->pos++;
    int value = 0;
    while (p->pos < p->len && p->src[p->pos] != '\'') {
      char ch = p->src[p->pos];
      if (ch == '\\' && p->pos + 1 < p->len) {
        p->pos++;
        char esc = p->src[p->pos];
        if (esc == 'n') ch = '\n';
        else if (esc == 't') ch = '\t';
        else if (esc == 'r') ch = '\r';
        else if (esc == '0') ch = '\0';
        else if (esc == '\\') ch = '\\';
        else if (esc == '\'') ch = '\'';
        else if (esc == '"') ch = '"';
        else ch = esc;
      }
      value = (value << 8) | (unsigned char)ch;
      p->pos++;
    }
    if (p->pos < p->len) p->pos++;   /* закрывающая кавычка */
    snprintf(p->cur.text, sizeof(p->cur.text), "%d", value);
    p->cur.type = TOK_NUMBER;
    return;
  }

  if (isdigit((unsigned char)c) || (c == '.' && p->pos + 1 < p->len && isdigit((unsigned char)p->src[p->pos + 1]))) {
    int j = 0;
    if (c == '0' && p->pos + 1 < p->len && (p->src[p->pos + 1] == 'x' || p->src[p->pos + 1] == 'X')) {
      p->cur.text[j++] = p->src[p->pos++];
      p->cur.text[j++] = p->src[p->pos++];
      while (p->pos < p->len && isxdigit((unsigned char)p->src[p->pos]) && j < 63)
        p->cur.text[j++] = p->src[p->pos++];
    } else {
      while (p->pos < p->len && isdigit((unsigned char)p->src[p->pos]) && j < 63)
        p->cur.text[j++] = p->src[p->pos++];
      if (p->pos < p->len && p->src[p->pos] == '.') {
        p->cur.text[j++] = p->src[p->pos++];
        while (p->pos < p->len && isdigit((unsigned char)p->src[p->pos]) && j < 63)
          p->cur.text[j++] = p->src[p->pos++];
      }
      if (p->pos < p->len && (p->src[p->pos] == 'e' || p->src[p->pos] == 'E')) {
        p->cur.text[j++] = p->src[p->pos++];
        if (p->pos < p->len && (p->src[p->pos] == '+' || p->src[p->pos] == '-'))
          p->cur.text[j++] = p->src[p->pos++];
        while (p->pos < p->len && isdigit((unsigned char)p->src[p->pos]) && j < 63)
          p->cur.text[j++] = p->src[p->pos++];
      }
    }

    while (p->pos < p->len) {
      char sfx = p->src[p->pos];
      if (sfx == 'f' || sfx == 'F' || sfx == 'l' || sfx == 'L' ||
          sfx == 'u' || sfx == 'U') {
        p->pos++;
        continue;
      }
      break;
    }

    p->cur.text[j] = '\0';
    p->cur.type = TOK_NUMBER;
    return;
  }

  if (is_ident_start(c)) {
    int j = 0;
    while (p->pos < p->len && is_ident_char(p->src[p->pos]) && j < 63)
      p->cur.text[j++] = p->src[p->pos++];
    p->cur.text[j] = '\0';
    p->cur.type = is_keyword(p->cur.text) ? TOK_KEYWORD : TOK_IDENT;
    return;
  }

  static const char* TWO[] = {
    "::", "<<", ">>", "==", "!=", "<=", ">=", "&&", "||",
    "++", "--", "->", "+=", "-=", "*=", "/=",
    "%=", "&=", "|=", "^="
  };
  if (p->pos + 3 < p->len) {
    char four[5] = { p->src[p->pos], p->src[p->pos+1], p->src[p->pos+2], p->src[p->pos+3], '\0' };
    if (strcmp(four, "<<==") == 0 || strcmp(four, ">>==") == 0) {
      strcpy(p->cur.text, four);
      p->cur.type = TOK_OP;
      p->pos += 4;
      return;
    }
  }
  if (p->pos + 2 < p->len) {
    char three[4] = { p->src[p->pos], p->src[p->pos+1], p->src[p->pos+2], '\0' };
    if (strcmp(three, "<<=") == 0 || strcmp(three, ">>=") == 0) {
      strcpy(p->cur.text, three);
      p->cur.type = TOK_OP;
      p->pos += 3;
      return;
    }
  }
  if (p->pos + 1 < p->len) {
    char two[3] = { p->src[p->pos], p->src[p->pos + 1], '\0' };
    for (int i = 0; i < (int)(sizeof(TWO) / sizeof(TWO[0])); i++) {
      if (strcmp(two, TWO[i]) == 0) {
        strcpy(p->cur.text, two);
        p->cur.type = TOK_OP;
        p->pos += 2;
        return;
      }
    }
  }
  p->cur.text[0] = c;
  p->cur.text[1] = '\0';
  if (strchr("+-*/%=<>!&|^~?:.", c)) p->cur.type = TOK_OP;
  else p->cur.type = TOK_PUNCT;
  p->pos++;
}

static ASTNode_t* new_node(ASTType_t type) {
  ASTNode_t* n = (ASTNode_t*)calloc(1, sizeof(ASTNode_t));
  if (!n) return NULL;
  n->type = type;
  n->struct_id = -1;
  n->line = g_parse_line;
  return n;
}
static void add_child(ASTNode_t* parent, ASTNode_t* child) {
  if (!parent || !child) return;
  if (child->next_sibling) {
    CDM_DBG("[AST] WARN: child already has sibling!\n");
    return;
  }
  if (!parent->first_child) parent->first_child = child;
  else {
    ASTNode_t* s = parent->first_child;
    while (s->next_sibling) s = s->next_sibling;
    s->next_sibling = child;
  }
}

static ASTNode_t* parse_expression(CDM_Parser_t* p);
static ASTNode_t* parse_statement(CDM_Parser_t* p);
static ASTNode_t* parse_block(CDM_Parser_t* p);
static ASTNode_t* parse_declaration(CDM_Parser_t* p, int consume_semi);
static ASTNode_t* parse_struct_def(CDM_Parser_t* p);
static ASTNode_t* parse_enum(CDM_Parser_t* p);

static int match_op(CDM_Parser_t* p, const char* op) {
  if (p->cur.type == TOK_OP && strcmp(p->cur.text, op) == 0) { next_token(p); return 1; }
  return 0;
}
static int match_punct(CDM_Parser_t* p, const char* c) {
  if (p->cur.type == TOK_PUNCT && strcmp(p->cur.text, c) == 0) { next_token(p); return 1; }
  return 0;
}
static int match_kw(CDM_Parser_t* p, const char* kw) {
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, kw) == 0) { next_token(p); return 1; }
  return 0;
}

static void require_punct(CDM_Parser_t* p, const char* c) {
  if (p->cur.type == TOK_PUNCT && strcmp(p->cur.text, c) == 0) {
    next_token(p);
  } else if (p->cur.type == TOK_EOF) {
    report_error(p, "expected '%s' at end of file", c);
    g_panic_mode = 1;
  } else {
    report_error(p, "expected '%s', got '%s'", c, p->cur.text);
    g_panic_mode = 1;
  }
}

static void require_op(CDM_Parser_t* p, const char* op) {
  if (p->cur.type == TOK_OP && strcmp(p->cur.text, op) == 0) {
    next_token(p);
  } else if (p->cur.type == TOK_EOF) {
    report_error(p, "expected '%s' at end of file", op);
    g_panic_mode = 1;
  } else {
    report_error(p, "expected '%s', got '%s'", op, p->cur.text);
    g_panic_mode = 1;
  }
}

static int require_identifier(CDM_Parser_t* p, char* out, int out_size) {
  if (p->cur.type == TOK_IDENT) {
    strncpy(out, p->cur.text, out_size - 1);
    out[out_size - 1] = '\0';
    next_token(p);
    return 1;
  }
  if (p->cur.type == TOK_EOF) {
    report_error(p, "expected identifier at end of file");
  } else {
    report_error(p, "expected identifier, got '%s'", p->cur.text);
  }
  g_panic_mode = 1;
  out[0] = '\0';
  return 0;
}

static void skip_to_sync(CDM_Parser_t* p) {
  int guard = 0;
  while (p->cur.type != TOK_EOF && guard < 256) {
    if (p->cur.type == TOK_PUNCT) {
      if (p->cur.text[0] == ';') return;
      if (p->cur.text[0] == '}') return;
    }
    next_token(p);
    guard++;
  }
}

static void recover_statement(CDM_Parser_t* p) {
  skip_to_sync(p);
  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == ';') {
    next_token(p);
  }
  g_panic_mode = 0;
}

static int is_type_keyword(CDM_Parser_t* p) {
  if (p->cur.type != TOK_KEYWORD) return 0;
  const char* t = p->cur.text;
  if (strcmp(t, "auto") == 0) return 1;
  return (strcmp(t, "int") == 0 || strcmp(t, "char") == 0 || strcmp(t, "void") == 0 ||
          strcmp(t, "float") == 0 || strcmp(t, "double") == 0 || strcmp(t, "long") == 0 ||
          strcmp(t, "short") == 0 || strcmp(t, "unsigned") == 0 || strcmp(t, "signed") == 0 ||
          strcmp(t, "static") == 0 || strcmp(t, "const") == 0 ||
          strcmp(t, "extern") == 0 || strcmp(t, "volatile") == 0 ||
          strcmp(t, "register") == 0 || strcmp(t, "inline") == 0 ||
          strcmp(t, "restrict") == 0 || strcmp(t, "_Bool") == 0 ||
          strncmp(t, "int", 3) == 0 || strncmp(t, "uint", 4) == 0 ||
          strncmp(t, "size_t", 6) == 0 || strncmp(t, "ssize_t", 7) == 0);
}
static CDM_ValueType_t type_from_keyword(const char* kw) {
  if (strstr(kw, "float") || strstr(kw, "double")) return CDM_TYPE_FLOAT;
  return CDM_TYPE_INT;
}

/* Старт объявления типа: ключевое слово-тип, имя struct/union
 * или typedef-алиас. */
static int is_type_start(CDM_Parser_t* p) {
  if (is_type_keyword(p)) return 1;
  if (p->cur.type != TOK_IDENT) return 0;
  return is_user_type(p->cur.text) || find_typedef(p->cur.text) >= 0;
}

/* Читает спецификатор типа: ключевые слова, struct/union-имя, typedef-алиас,
 * квалификаторы (const/static/extern/volatile/...) и звёздочки.
 * Выходы всегда инициализированы (INT/-1/0/0), даже при возврате 0. */
static int parse_type_spec(CDM_Parser_t* p, CDM_ValueType_t* dt, int* sid,
                           int* is_ptr, int* is_auto) {
  *sid = -1; *is_ptr = 0; *is_auto = 0; *dt = CDM_TYPE_INT;

  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "auto") == 0) {
    *is_auto = 1;
    next_token(p);
    return 1;
  }
  if (is_type_keyword(p)) {
    *dt = type_from_keyword(p->cur.text);
    next_token(p);
    while (is_type_keyword(p)) next_token(p);
  } else if (p->cur.type == TOK_IDENT) {
    int td = find_typedef(p->cur.text);
    if (td >= 0) {
      *dt = g_typedefs[td].type;
      *sid = typedef_struct_id(td);
      *is_ptr = g_typedefs[td].is_ptr;
      next_token(p);
    } else if (is_user_type(p->cur.text)) {
      *sid = find_struct_def(p->cur.text);
      *dt = CDM_TYPE_STRUCT;
      next_token(p);
    } else {
      return 0;
    }
  } else {
    return 0;
  }
  while (p->cur.type == TOK_OP && strcmp(p->cur.text, "*") == 0) {
    *is_ptr = 1;
    next_token(p);
  }
  if (*is_ptr) *dt = CDM_TYPE_PTR;
  return 1;
}

static ASTNode_t* parse_args(CDM_Parser_t* p) {
  ASTNode_t* call = new_node(AST_FUNC_CALL);
  if (!match_punct(p, "(")) return call;
  ASTNode_t* args[32];
  int argc = 0;
  if (p->cur.type != TOK_PUNCT || p->cur.text[0] != ')') {
    while (argc < 32) {
      args[argc++] = parse_expression(p);
      if (!match_punct(p, ",")) break;
    }
  }
  require_punct(p, ")");
  call->arg_count = argc;
  if (argc > 0) {
    call->args = (ASTNode_t**)calloc(argc, sizeof(ASTNode_t*));
    for (int i = 0; i < argc; i++) call->args[i] = args[i];
  }
  return call;
}

static ASTNode_t* parse_new(CDM_Parser_t* p) {
  match_kw(p, "new");
  ASTNode_t* n = new_node(AST_NEW);
  if (p->cur.type != TOK_IDENT && !is_type_keyword(p)) {
    report_error(p, "expected type after 'new', got '%s'", p->cur.text);
    g_panic_mode = 1;
    return n;
  }
  strncpy(n->name, p->cur.text, 63);
  if (is_user_type(n->name)) {
    n->decl_type = CDM_TYPE_STRUCT;
    n->struct_id = find_struct_def(n->name);
  } else {
    n->decl_type = type_from_keyword(n->name);
  }
  next_token(p);
  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
    next_token(p);
    if (p->cur.type != TOK_PUNCT || p->cur.text[0] != ']') {
      n->left = parse_expression(p);
    }
    require_punct(p, "]");
    n->type = AST_NEW_ARRAY;
  }
  return n;
}

/* Суффиксные операции над primary: [i], .field, ->field, ++/--.
 * Вынесена из parse_primary, чтобы применялась и к (expr):
 * работает (*p).field, (a+b)[0] и т.п.
 * ★ C-образность: p->field сводится к (*p).field. */
static ASTNode_t* parse_postfix_suffixes(CDM_Parser_t* p, ASTNode_t* base) {
  while (base) {
    if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
      next_token(p);
      ASTNode_t* idx = parse_expression(p);
      require_punct(p, "]");
      ASTNode_t* sub = new_node(AST_ARRAY_SUBSCRIPT);
      sub->left = base; sub->right = idx; base = sub;
    } else if (p->cur.type == TOK_OP && strcmp(p->cur.text, ".") == 0) {
      next_token(p);
      if (p->cur.type != TOK_IDENT) {
        report_error(p, "expected member name after '.', got '%s'", p->cur.text);
        g_panic_mode = 1;
        break;
      }
      char member[64];
      strncpy(member, p->cur.text, 63);
      member[63] = '\0';
      next_token(p);
      if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '(') {
        ASTNode_t* call = parse_args(p);
        strncpy(call->name, member, 63);
        call->type = AST_METHOD_CALL;
        call->left = base;
        base = call;
      } else {
        ASTNode_t* acc = new_node(AST_MEMBER_ACCESS);
        strncpy(acc->name, member, 63);
        acc->left = base;
        base = acc;
      }
    }
    else if (p->cur.type == TOK_OP && strcmp(p->cur.text, "->") == 0) {
      next_token(p);
      if (p->cur.type != TOK_IDENT) {
        report_error(p, "expected member name after '->', got '%s'", p->cur.text);
        g_panic_mode = 1;
        break;
      }
      char member[64];
      strncpy(member, p->cur.text, 63);
      member[63] = '\0';
      next_token(p);
      ASTNode_t* deref = new_node(AST_UNARY);
      strncpy(deref->name, "*", 63);
      deref->left = base;
      ASTNode_t* acc = new_node(AST_MEMBER_ACCESS);
      strncpy(acc->name, member, 63);
      acc->left = deref;
      base = acc;
    }
    else if (p->cur.type == TOK_OP &&
             (strcmp(p->cur.text, "++") == 0 || strcmp(p->cur.text, "--") == 0)) {
      char opc[4];
      strncpy(opc, p->cur.text, 3);
      opc[3] = '\0';
      next_token(p);
      ASTNode_t* post = new_node(AST_UNARY);
      strncpy(post->name, opc, 63);
      post->is_ptr = 1;
      post->left = base;
      base = post;
    } else {
      break;
    }
  }
  return base;
}

static ASTNode_t* parse_primary(CDM_Parser_t* p) {
  if (p->cur.type == TOK_NUMBER) {
    ASTNode_t* n = new_node(AST_NUMBER);
    strncpy(n->name, p->cur.text, 63);
    if (strchr(p->cur.text, '.') || strchr(p->cur.text, 'e') || strchr(p->cur.text, 'E'))
      n->fval = atof(p->cur.text);
    else
      n->ival = cdm_strtoll(p->cur.text, 0);
    next_token(p);
    return n;
  }
  if (p->cur.type == TOK_STRING) {
    ASTNode_t* n = new_node(AST_STRING);
    strncpy(n->name, p->cur.text, 63);
    next_token(p);
    return n;
  }

  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "sizeof") == 0) {
    next_token(p);
    if (!match_punct(p, "(")) {
      report_error(p, "expected '(' after sizeof");
      g_panic_mode = 1;
    }
    if (is_type_keyword(p)) {
      const char* t = p->cur.text;
      int64_t sz = 4;
      if (strstr(t, "char") || strcmp(t, "int8_t") == 0 || strcmp(t, "uint8_t") == 0) sz = 1;
      else if (strstr(t, "short") || strstr(t, "int16")) sz = 2;
      else if (strstr(t, "long") || strstr(t, "int64")) sz = 8;
      else if (strstr(t, "float") || strstr(t, "double")) sz = 8;
      else sz = 4;
      next_token(p);
      while (is_type_keyword(p)) next_token(p);
      while (p->cur.type == TOK_OP && strcmp(p->cur.text, "*") == 0) {
        sz = 8;
        next_token(p);
      }
      require_punct(p, ")");
      ASTNode_t* n = new_node(AST_NUMBER);
      n->ival = sz;
      snprintf(n->name, 63, "%lld", (long long)sz);
      return n;
    }
    ASTNode_t* e = parse_expression(p);
    require_punct(p, ")");
    ASTNode_t* sz_node = new_node(AST_SIZEOF);
    sz_node->left = e;
    return sz_node;
  }

  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '(') {
    int saved_pos = p->pos;
    int saved_line = p->line;
    Token_t saved_tok = p->cur;
    next_token(p);
    if (p->cur.type == TOK_KEYWORD && is_type_keyword(p)) {
      CDM_ValueType_t target = type_from_keyword(p->cur.text);
      next_token(p);
      while (is_type_keyword(p)) next_token(p);
      int is_ptr = 0;
      while (p->cur.type == TOK_OP && strcmp(p->cur.text, "*") == 0) {
        is_ptr = 1;
        next_token(p);
      }
      require_punct(p, ")");
      ASTNode_t* cast = new_node(AST_CAST);
      cast->decl_type = is_ptr ? CDM_TYPE_PTR : target;
      cast->is_ptr = is_ptr;
      cast->left = parse_primary(p);
      return cast;
    }
    p->pos = saved_pos;
    p->line = saved_line;
    p->cur = saved_tok;
    next_token(p);
    ASTNode_t* n = parse_expression(p);
    require_punct(p, ")");
    n = parse_postfix_suffixes(p, n);   /* (*p).field, (expr)[i], ... */
    return n;
  }

  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "new") == 0)
    return parse_new(p);
  if (p->cur.type == TOK_KEYWORD) {
    if (strcmp(p->cur.text, "true") == 0) {
      ASTNode_t* n = new_node(AST_NUMBER); n->ival = 1; next_token(p); return n;
    }
    if (strcmp(p->cur.text, "false") == 0 || strcmp(p->cur.text, "nullptr") == 0) {
      ASTNode_t* n = new_node(AST_NUMBER); n->ival = 0; next_token(p); return n;
    }
  }
  if (p->cur.type == TOK_OP) {
    const char* op = p->cur.text;
    int is_unary = (strcmp(op, "-") == 0 || strcmp(op, "!") == 0 || strcmp(op, "~") == 0 ||
                    strcmp(op, "++") == 0 || strcmp(op, "--") == 0 ||
                    strcmp(op, "&") == 0 || strcmp(op, "*") == 0);
    if (is_unary) {
      char opc[8];
      strncpy(opc, op, 7); opc[7] = '\0';
      next_token(p);
      ASTNode_t* n = new_node(AST_UNARY);
      strncpy(n->name, opc, 63);
      n->is_ptr = 0;
      n->left = parse_primary(p);
      return n;
    }
  }

  if (p->cur.type == TOK_IDENT || p->cur.type == TOK_KEYWORD) {
    char name[64];
    strncpy(name, p->cur.text, 63);
    name[63] = '\0';
    next_token(p);

    ASTNode_t* base = new_node(AST_IDENTIFIER);
    strncpy(base->name, name, 63);

    base = parse_postfix_suffixes(p, base);
    if (!base) return new_node(AST_NUMBER);

    /* Ветки :: и вызова — только для «голого» идентификатора без суффиксов
     * (как и в исходной версии: после a[0] / a.b вызов/:: не обрабатывался).
     * base при вызове освобождаем — раньше узел терялся (утечка на каждый
     * вызов функции!). */
    if (base->type == AST_IDENTIFIER) {
      if (p->cur.type == TOK_OP && strcmp(p->cur.text, "::") == 0) {
        next_token(p);
        char sub_name[64];
        strncpy(sub_name, p->cur.text, 63);
        sub_name[63] = '\0';
        next_token(p);
        if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '(') {
          CDM_FreeAST(base);
          ASTNode_t* call = parse_args(p);
          snprintf(call->name, 64, "%s::%s", name, sub_name);
          return call;
        }
        ASTNode_t* m = new_node(AST_MEMBER);
        strncpy(m->name, name, 63);
        CDM_FreeAST(base);
        ASTNode_t* sub = new_node(AST_IDENTIFIER);
        strncpy(sub->name, sub_name, 63);
        add_child(m, sub);
        return m;
      }
      if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '(') {
        CDM_FreeAST(base);
        ASTNode_t* call = parse_args(p);
        strncpy(call->name, name, 63);
        return call;
      }
    }
    return base;
  }

  report_error(p, "unexpected token '%s' in expression", p->cur.text);
  g_panic_mode = 1;
  ASTNode_t* n = new_node(AST_NUMBER);
  n->ival = 0;
  next_token(p);
  return n;
}

static int precedence(const char* op) {
  if (strcmp(op, "=") == 0 || strcmp(op, "+=") == 0 || strcmp(op, "-=") == 0 ||
      strcmp(op, "*=") == 0 || strcmp(op, "/=") == 0 || strcmp(op, "%=") == 0 ||
      strcmp(op, "&=") == 0 || strcmp(op, "|=") == 0 || strcmp(op, "^=") == 0 ||
      strcmp(op, "<<=") == 0 || strcmp(op, ">>=") == 0) return 1;
  if (strcmp(op, "||") == 0) return 2;
  if (strcmp(op, "&&") == 0) return 3;
  if (strcmp(op, "|") == 0) return 4;
  if (strcmp(op, "^") == 0) return 5;
  if (strcmp(op, "&") == 0) return 6;
  if (strcmp(op, "==") == 0 || strcmp(op, "!=") == 0) return 7;
  if (strcmp(op, "<") == 0 || strcmp(op, ">") == 0 ||
      strcmp(op, "<=") == 0 || strcmp(op, ">=") == 0) return 8;
  if (strcmp(op, "<<") == 0 || strcmp(op, ">>") == 0) return 9;
  if (strcmp(op, "+") == 0 || strcmp(op, "-") == 0) return 10;
  if (strcmp(op, "*") == 0 || strcmp(op, "/") == 0 || strcmp(op, "%") == 0) return 11;
  return 0;
}
static int is_right_assoc(const char* op) {
  return (strcmp(op, "=") == 0 || strcmp(op, "+=") == 0 || strcmp(op, "-=") == 0 ||
          strcmp(op, "*=") == 0 || strcmp(op, "/=") == 0 || strcmp(op, "%=") == 0 ||
          strcmp(op, "&=") == 0 || strcmp(op, "|=") == 0 || strcmp(op, "^=") == 0 ||
          strcmp(op, "<<=") == 0 || strcmp(op, ">>=") == 0);
}

static ASTNode_t* parse_binary(CDM_Parser_t* p, int min_prec) {
  ASTNode_t* left = parse_primary(p);
  while (p->cur.type == TOK_OP) {
    if (strcmp(p->cur.text, ".") == 0) break;
    if (strcmp(p->cur.text, "?") == 0) break;
    int prec = precedence(p->cur.text);
    if (prec == 0 || prec < min_prec) break;
    char op[8];
    strncpy(op, p->cur.text, 7); op[7] = '\0';
    next_token(p);
    int next_min = is_right_assoc(op) ? prec : prec + 1;
    ASTNode_t* right = parse_binary(p, next_min);
    ASTNode_t* bin = new_node(AST_BINARY);
    strncpy(bin->name, op, 63);
    bin->left = left;
    bin->right = right;
    left = bin;
  }
  return left;
}

static ASTNode_t* parse_expression(CDM_Parser_t* p) {
  ASTNode_t* cond = parse_binary(p, 1);
  if (p->cur.type == TOK_OP && strcmp(p->cur.text, "?") == 0) {
    next_token(p);
    ASTNode_t* then_e = parse_expression(p);
    require_op(p, ":");
    ASTNode_t* else_e = parse_expression(p);
    ASTNode_t* t = new_node(AST_TERNARY);
    t->left = cond;
    t->right = then_e;
    t->init = else_e;
    return t;
  }
  return cond;
}

static ASTNode_t* parse_if(CDM_Parser_t* p) {
  match_kw(p, "if");
  require_punct(p, "(");
  ASTNode_t* cond = parse_expression(p);
  require_punct(p, ")");
  ASTNode_t* node = new_node(AST_IF);
  node->left = cond;
  node->body = parse_statement(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "else") == 0) {
    next_token(p);
    node->right = parse_statement(p);
  }
  return node;
}
static ASTNode_t* parse_while(CDM_Parser_t* p) {
  match_kw(p, "while");
  require_punct(p, "(");
  ASTNode_t* cond = parse_expression(p);
  require_punct(p, ")");
  ASTNode_t* node = new_node(AST_WHILE);
  node->left = cond;
  node->body = parse_statement(p);
  return node;
}

static ASTNode_t* parse_do_while(CDM_Parser_t* p) {
  match_kw(p, "do");
  ASTNode_t* node = new_node(AST_DO_WHILE);
  node->body = parse_statement(p);
  match_kw(p, "while");
  require_punct(p, "(");
  node->left = parse_expression(p);
  require_punct(p, ")");
  require_punct(p, ";");
  return node;
}

static ASTNode_t* parse_switch(CDM_Parser_t* p) {
  match_kw(p, "switch");
  require_punct(p, "(");
  ASTNode_t* cond = parse_expression(p);
  require_punct(p, ")");
  require_punct(p, "{");

  ASTNode_t* node = new_node(AST_SWITCH);
  node->left = cond;
  ASTNode_t* body = new_node(AST_BLOCK);
  node->body = body;

  while (p->cur.type != TOK_EOF &&
         !(p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')) {
    if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "case") == 0) {
      next_token(p);
      ASTNode_t* c = new_node(AST_CASE);
      c->left = parse_expression(p);
      require_op(p, ":");
      while (p->cur.type != TOK_EOF) {
        if (p->cur.type == TOK_KEYWORD &&
            (strcmp(p->cur.text, "case") == 0 || strcmp(p->cur.text, "default") == 0))
          break;
        if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')
          break;
        int old_pos = p->pos;
        ASTNode_t* s = parse_statement(p);
        if (s) add_child(c, s);
        if (p->pos == old_pos) next_token(p);
      }
      add_child(body, c);
    }
    else if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "default") == 0) {
      next_token(p);
      require_op(p, ":");
      ASTNode_t* d = new_node(AST_DEFAULT);
      while (p->cur.type != TOK_EOF) {
        if (p->cur.type == TOK_KEYWORD &&
            (strcmp(p->cur.text, "case") == 0 || strcmp(p->cur.text, "default") == 0))
          break;
        if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')
          break;
        int old_pos = p->pos;
        ASTNode_t* s = parse_statement(p);
        if (s) add_child(d, s);
        if (p->pos == old_pos) next_token(p);
      }
      add_child(body, d);
    }
    else {
      next_token(p);
    }
  }
  require_punct(p, "}");
  return node;
}

static ASTNode_t* parse_for(CDM_Parser_t* p) {
  match_kw(p, "for");
  require_punct(p, "(");
  ASTNode_t* node = new_node(AST_FOR);
  scope_enter();
  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == ';') next_token(p);
  else {
    if (is_type_start(p)) {
      CDM_ValueType_t dt;
      int sid, is_ptr, is_auto;
      parse_type_spec(p, &dt, &sid, &is_ptr, &is_auto);
      if (p->cur.type == TOK_IDENT) {
        char varname[64];
        strncpy(varname, p->cur.text, 63); varname[63] = '\0';
        next_token(p);
        if (p->cur.type == TOK_OP && strcmp(p->cur.text, ":") == 0) {
          next_token(p);
          ASTNode_t* arr = parse_expression(p);
          require_punct(p, ")");
          node->type = AST_RANGE_FOR;
          strncpy(node->name, varname, 63);
          node->decl_type = dt;
          node->struct_id = sid;
          node->is_auto = is_auto;
          node->left = arr;
          node->body = parse_statement(p);
          return node;
        }
        ASTNode_t* v = new_node(AST_VAR_DECL);
        strncpy(v->name, varname, 63);
        v->decl_type = dt; v->struct_id = sid; v->is_auto = is_auto;
        if (match_op(p, "=")) v->left = parse_expression(p);
        node->init = v;
      }
    } else {
      ASTNode_t* e = parse_expression(p);
      ASTNode_t* stmt = new_node(AST_EXPR_STMT);
      stmt->left = e;
      node->init = stmt;
    }
    require_punct(p, ";");
  }
  if (!(p->cur.type == TOK_PUNCT && p->cur.text[0] == ';')) node->left = parse_expression(p);
  require_punct(p, ";");
  if (!(p->cur.type == TOK_PUNCT && p->cur.text[0] == ')')) node->update = parse_expression(p);
  require_punct(p, ")");
  node->body = parse_statement(p);
  return node;
}

static ASTNode_t* parse_return(CDM_Parser_t* p) {
  match_kw(p, "return");
  ASTNode_t* node = new_node(AST_RETURN);
  if (!(p->cur.type == TOK_PUNCT && p->cur.text[0] == ';'))
    node->left = parse_expression(p);
  require_punct(p, ";");
  return node;
}
static ASTNode_t* parse_delete(CDM_Parser_t* p) {
  match_kw(p, "delete");
  ASTNode_t* node;
  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
    next_token(p);
    require_punct(p, "]");
    node = new_node(AST_DELETE_ARRAY);
  } else {
    node = new_node(AST_DELETE);
  }
  node->left = parse_expression(p);
  require_punct(p, ";");
  return node;
}
static ASTNode_t* parse_block(CDM_Parser_t* p) {
  if (!match_punct(p, "{")) return NULL;
  ASTNode_t* block = new_node(AST_BLOCK);
  while (p->cur.type != TOK_EOF &&
         !(p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')) {
    int old_pos = p->pos;
    ASTNode_t* s = parse_statement(p);
    if (s) add_child(block, s);
    if (p->pos == old_pos) next_token(p);
    if (g_error_count >= CDM_MAX_ERRORS) break;
  }
  require_punct(p, "}");
  return block;
}

static ASTNode_t* parse_struct_def(CDM_Parser_t* p) {
  int is_union = 0;
  if (match_kw(p, "union")) is_union = 1;   /* ★ union — синтаксис C */
  else match_kw(p, "struct");
  char sname[32];
  if (!require_identifier(p, sname, sizeof(sname))) return NULL;
  if (find_struct_def(sname) >= 0) {
    report_error(p, "struct '%s' already defined", sname);
    g_panic_mode = 1;
    return NULL;
  }
  if (g_struct_def_count >= CDM_MAX_STRUCT_TYPES) {
    report_error(p, "too many structs (max %d)", CDM_MAX_STRUCT_TYPES);
    g_panic_mode = 1;
    return NULL;
  }
  int sid = g_struct_def_count++;
  CDM_StructDef_t* sd = &g_struct_defs[sid];
  strncpy(sd->name, sname, 31); sd->name[31] = '\0';
  sd->field_count = 0;
  sd->is_union = is_union;
  require_punct(p, "{");
  while (p->cur.type != TOK_EOF &&
         !(p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')) {
    if (sd->field_count >= CDM_MAX_FIELDS_PER_STRUCT) {
      report_error(p, "too many fields in struct (max %d)", CDM_MAX_FIELDS_PER_STRUCT);
      g_panic_mode = 1;
      break;
    }
    if (!is_type_start(p)) {
      report_error(p, "expected type in struct, got '%s'", p->cur.text);
      g_panic_mode = 1;
      recover_statement(p);
      continue;
    }
    CDM_ValueType_t ft;
    int fsid, fptr, fauto;
    parse_type_spec(p, &ft, &fsid, &fptr, &fauto);
    char fname[32];
    if (!require_identifier(p, fname, sizeof(fname))) {
      recover_statement(p);
      break;
    }
    CDM_FieldDef_t* f = &sd->fields[sd->field_count];
    strncpy(f->name, fname, 31); f->name[31] = '\0';
    f->type = ft; f->struct_id = fsid; f->array_len = 0;
    /* ★ битовые поля: int flags : 3; — ширину парсим и игнорируем */
    if (p->cur.type == TOK_OP && strcmp(p->cur.text, ":") == 0) {
      next_token(p);
      if (p->cur.type == TOK_NUMBER) {
        next_token(p);
      } else {
        report_error(p, "expected bit-field width, got '%s'", p->cur.text);
        g_panic_mode = 1;
      }
    }
    if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
      next_token(p);
      if (p->cur.type == TOK_NUMBER) {
        f->array_len = atoi(p->cur.text);
        next_token(p);
      } else {
        report_error(p, "expected constant array size, got '%s'", p->cur.text);
        g_panic_mode = 1;
      }
      require_punct(p, "]");
    }
    sd->field_count++;
    require_punct(p, ";");
  }
  require_punct(p, "}");
  require_punct(p, ";");
  ASTNode_t* node = new_node(AST_STRUCT_DEF);
  strncpy(node->name, sname, 63);
  node->struct_id = sid;
  return node;
}

static ASTNode_t* parse_enum(CDM_Parser_t* p) {
  match_kw(p, "enum");
  if (p->cur.type == TOK_IDENT) next_token(p);

  require_punct(p, "{");

  int64_t next_val = 0;
  while (p->cur.type != TOK_EOF &&
         !(p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')) {
    char name[64];
    if (!require_identifier(p, name, sizeof(name))) {
      recover_statement(p);
      break;
    }

    if (match_op(p, "=")) {
      ASTNode_t* ve = parse_expression(p);
      next_val = eval_const(ve);
      CDM_FreeAST(ve);
    }

    if (g_enum_count < MAX_ENUM_ENTRIES) {
      strncpy(g_enums[g_enum_count].name, name, 63);
      g_enums[g_enum_count].name[63] = '\0';
      g_enums[g_enum_count].value = next_val;
      g_enum_count++;
    } else {
      report_error(p, "too many enum entries");
      g_panic_mode = 1;
    }
    next_val++;

    if (!match_punct(p, ",")) break;
  }
  require_punct(p, "}");
  require_punct(p, ";");

  return new_node(AST_ENUM_DECL);
}

/* ★ typedef — таблица алиасов типов:
 *   typedef struct Point Point;   typedef unsigned int uint;
 *   typedef Point* PointPtr;      typedef PointT PointT2; */
static ASTNode_t* parse_typedef(CDM_Parser_t* p) {
  match_kw(p, "typedef");

  CDM_ValueType_t dt = CDM_TYPE_INT;
  int sid = -1, is_ptr = 0;
  char target[64] = { 0 };

  if (match_kw(p, "struct") || match_kw(p, "union")) {
    if (p->cur.type == TOK_IDENT) {
      strncpy(target, p->cur.text, 63);
      target[63] = '\0';
      next_token(p);
      dt = CDM_TYPE_STRUCT;
      sid = find_struct_def(target);   /* может быть -1 (forward-typedef) */
    }
  } else if (p->cur.type == TOK_IDENT) {
    int td = find_typedef(p->cur.text);
    if (td >= 0) {
      dt = g_typedefs[td].type;
      sid = typedef_struct_id(td);
      is_ptr = g_typedefs[td].is_ptr;
      strncpy(target, g_typedefs[td].target, 63);
      target[63] = '\0';
      next_token(p);
    } else if (is_user_type(p->cur.text)) {
      strncpy(target, p->cur.text, 63);
      target[63] = '\0';
      sid = find_struct_def(target);
      dt = CDM_TYPE_STRUCT;
      next_token(p);
    } else {
      report_error(p, "typedef: unknown type '%s'", p->cur.text);
      g_panic_mode = 1;
      recover_statement(p);
      return NULL;
    }
  } else if (is_type_keyword(p)) {
    dt = type_from_keyword(p->cur.text);
    next_token(p);
    while (is_type_keyword(p)) next_token(p);
  } else {
    report_error(p, "typedef: expected type, got '%s'", p->cur.text);
    g_panic_mode = 1;
    recover_statement(p);
    return NULL;
  }

  while (p->cur.type == TOK_OP && strcmp(p->cur.text, "*") == 0) {
    is_ptr = 1;
    next_token(p);
  }

  if (dt == CDM_TYPE_STRUCT && sid < 0 && !target[0]) {
    report_error(p, "typedef: anonymous struct/union is not supported");
    g_panic_mode = 1;
    recover_statement(p);
    return NULL;
  }

  char alias[64];
  if (!require_identifier(p, alias, sizeof(alias))) {
    recover_statement(p);
    return NULL;
  }
  require_punct(p, ";");

  add_typedef(alias, dt, sid, is_ptr, target);
  ASTNode_t* node = new_node(AST_TYPEDEF);
  strncpy(node->name, alias, 63);
  node->decl_type = dt;
  node->struct_id = sid;
  node->is_ptr = is_ptr;
  return node;
}

static ASTNode_t* parse_declaration(CDM_Parser_t* p, int consume_semi) {
  if (!is_type_start(p)) return NULL;

  CDM_ValueType_t dt;
  int sid, is_ptr, is_auto;
  if (!parse_type_spec(p, &dt, &sid, &is_ptr, &is_auto)) return NULL;

  char name[64];
  if (!require_identifier(p, name, sizeof(name))) return NULL;

  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '(') {
    ASTNode_t* func = new_node(AST_FUNC_DECL);
    strncpy(func->name, name, 63);
    func->decl_type = dt;
    func->struct_id = sid;
    next_token(p);
    int argc = 0;
    ASTNode_t* params[32];
    while (!(p->cur.type == TOK_PUNCT && p->cur.text[0] == ')')) {
      CDM_ValueType_t pt;
      int psid, pptr, pauto;
      /* неуказанный тип допустим: f(x) трактуется как f(int x) */
      if (!parse_type_spec(p, &pt, &psid, &pptr, &pauto) &&
          p->cur.type != TOK_IDENT) {
        report_error(p, "expected parameter type, got '%s'", p->cur.text);
        g_panic_mode = 1;
        break;
      }
      if (p->cur.type == TOK_IDENT) {
        ASTNode_t* param = new_node(AST_PARAM);
        strncpy(param->name, p->cur.text, 63);
        param->decl_type = pt;
        param->struct_id = psid;
        next_token(p);
        while (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
          param->array_dim++;
          next_token(p);
          if (p->cur.type == TOK_NUMBER) { param->array_len = atoi(p->cur.text); next_token(p); }
          while (!(p->cur.type == TOK_PUNCT && p->cur.text[0] == ']')) next_token(p);
          next_token(p);
        }
        if (argc < 32) params[argc++] = param;
      } else {
        report_error(p, "expected parameter name, got '%s'", p->cur.text);
        g_panic_mode = 1;
        break;
      }
      if (!match_punct(p, ",")) break;
    }
    require_punct(p, ")");
    if (argc > 0) {
      func->args = (ASTNode_t**)calloc(argc, sizeof(ASTNode_t*));
      for (int i = 0; i < argc; i++) func->args[i] = params[i];
      func->arg_count = argc;
    }
    func->body = parse_block(p);
    return func;
  }

  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
    ASTNode_t* arr = new_node(AST_ARRAY_DECL);
    strncpy(arr->name, name, 63);
    arr->decl_type = dt;
    arr->struct_id = sid;
    arr->array_dim = 0;
    arr->array_len = 1;
    while (p->cur.type == TOK_PUNCT && p->cur.text[0] == '[') {
      next_token(p);
      if (p->cur.type != TOK_NUMBER) {
        report_error(p, "array size must be constant, got '%s'", p->cur.text);
        g_panic_mode = 1;
        while (p->cur.type != TOK_EOF &&
               !(p->cur.type == TOK_PUNCT && p->cur.text[0] == ']'))
          next_token(p);
        match_punct(p, "]");
        break;
      }
      int sz = atoi(p->cur.text);
      if (arr->array_dim < 4) arr->array_sizes[arr->array_dim] = sz;
      arr->array_len *= sz;
      arr->array_dim++;
      next_token(p);
      require_punct(p, "]");
    }
    if (match_op(p, "=")) {
      if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '{') {
        next_token(p);
        ASTNode_t* init_list = new_node(AST_ARRAY_INIT);
        ASTNode_t* items[64];
        int n = 0;
        if (!(p->cur.type == TOK_PUNCT && p->cur.text[0] == '}')) {
          while (n < 64) {
            items[n++] = parse_expression(p);
            if (!match_punct(p, ",")) break;
          }
        }
        require_punct(p, "}");
        init_list->elems = (ASTNode_t**)calloc(n, sizeof(ASTNode_t*));
        for (int i = 0; i < n; i++) init_list->elems[i] = items[i];
        init_list->elem_count = n;
        arr->init = init_list;
      } else {
        report_error(p, "expected '{' for array initializer, got '%s'", p->cur.text);
        g_panic_mode = 1;
      }
    }
    if (consume_semi) require_punct(p, ";");
    return arr;
  }

  ASTNode_t* v = new_node(AST_VAR_DECL);
  strncpy(v->name, name, 63);
  v->is_ptr = is_ptr;
  v->is_auto = is_auto;
  v->decl_type = dt;
  v->struct_id = sid;
  if (match_op(p, "=")) v->left = parse_expression(p);
  if (consume_semi) require_punct(p, ";");
  return v;
}

static ASTNode_t* parse_statement(CDM_Parser_t* p) {
  if (g_panic_mode) {
    recover_statement(p);
    return NULL;
  }

  if (p->cur.type == TOK_KEYWORD &&
      (strcmp(p->cur.text, "struct") == 0 || strcmp(p->cur.text, "union") == 0))
    return parse_struct_def(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "typedef") == 0)
    return parse_typedef(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "enum") == 0) return parse_enum(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "return") == 0) return parse_return(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "if") == 0) return parse_if(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "while") == 0) return parse_while(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "for") == 0) return parse_for(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "do") == 0) return parse_do_while(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "switch") == 0) return parse_switch(p);
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "delete") == 0) return parse_delete(p);
  /* ★ goto <метка>; */
  if (p->cur.type == TOK_KEYWORD && strcmp(p->cur.text, "goto") == 0) {
    next_token(p);
    ASTNode_t* n = new_node(AST_GOTO);
    if (!require_identifier(p, n->name, (int)sizeof(n->name))) {
      recover_statement(p);
      return NULL;
    }
    require_punct(p, ";");
    return n;
  }

  if (p->cur.type == TOK_KEYWORD &&
      (strcmp(p->cur.text, "break") == 0 || strcmp(p->cur.text, "continue") == 0)) {
    ASTNode_t* n = new_node(strcmp(p->cur.text, "break") == 0 ? AST_BREAK : AST_CONTINUE);
    next_token(p);
    require_punct(p, ";");
    return n;
  }

  /* ★ метка: identifier ':' — отличаем от выражения заглядыванием на 1 токен */
  if (p->cur.type == TOK_IDENT) {
    int saved_pos = p->pos;
    int saved_line = p->line;
    Token_t saved_tok = p->cur;
    next_token(p);
    if (p->cur.type == TOK_OP && strcmp(p->cur.text, ":") == 0) {
      ASTNode_t* lbl = new_node(AST_LABEL);
      strncpy(lbl->name, saved_tok.text, 63);
      lbl->name[63] = '\0';
      next_token(p);   /* ':' */
      return lbl;
    }
    p->pos = saved_pos;
    p->line = saved_line;
    p->cur = saved_tok;
  }

  if (is_type_start(p))
    return parse_declaration(p, 1);
  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == '{') return parse_block(p);

  if (p->cur.type == TOK_PUNCT && p->cur.text[0] == ';') {
    next_token(p);
    return NULL;
  }

  ASTNode_t* e = parse_expression(p);
  require_punct(p, ";");
  ASTNode_t* stmt = new_node(AST_EXPR_STMT);
  stmt->left = e;
  return stmt;
}

ASTNode_t* CDM_Parse(const char* source) {
  if (!cdm_ensure_alloc()) return NULL;
  CDM_ClearErrors();
  g_struct_def_count = 0;
  g_enum_count = 0;
  g_typedef_count = 0;
  g_parse_line = 1;
  g_panic_mode = 0;
  CDM_Parser_t p;
  p.src = source;
  p.pos = 0;
  p.len = (int)strlen(source);
  p.line = 1;
  ASTNode_t* program = new_node(AST_PROGRAM);
  next_token(&p);
  int tick = 0;
  while (p.cur.type != TOK_EOF) {
    if ((++tick & 0x3F) == 0) {
      CDM_DBG("[Parse] tick=%d pos=%d/%d line=%d tok='%s'\n",
             tick, p.pos, p.len, p.line, p.cur.text);
    }
    if (g_error_count >= CDM_MAX_ERRORS) break;

    if (g_panic_mode) {
      recover_statement(&p);
      continue;
    }

    int old_pos = p.pos;
    ASTNode_t* decl = parse_declaration(&p, 1);
    if (!decl) decl = parse_statement(&p);
    if (decl) add_child(program, decl);
    else if (p.pos == old_pos) {
      report_error(&p, "unexpected token '%s' at top level", p.cur.text);
      g_panic_mode = 1;
      next_token(&p);
    }
  }
  CDM_DBG("[Parse] done pos=%d, %d error(s)\n", p.pos, g_error_count);
  return program;
}

void CDM_FreeAST(ASTNode_t* node) {
  if (!node) return;
  ASTNode_t* save_first_child = node->first_child; node->first_child = NULL;
  ASTNode_t* save_left = node->left;               node->left = NULL;
  ASTNode_t* save_right = node->right;             node->right = NULL;
  ASTNode_t* save_body = node->body;               node->body = NULL;
  ASTNode_t* save_init = node->init;               node->init = NULL;
  ASTNode_t* save_update = node->update;           node->update = NULL;
  ASTNode_t* save_cond = node->cond;               node->cond = NULL;
  ASTNode_t* save_step = node->step;               node->step = NULL;
  ASTNode_t** save_args = node->args;              node->args = NULL;
  int save_args_n = node->arg_count;               node->arg_count = 0;
  ASTNode_t** save_elems = node->elems;            node->elems = NULL;
  int save_elems_n = node->elem_count;             node->elem_count = 0;
  ASTNode_t* save_next = node->next_sibling;       node->next_sibling = NULL;
  (void)save_next;

  ASTNode_t* c = save_first_child;
  while (c) {
    ASTNode_t* next = c->next_sibling;
    CDM_FreeAST(c);
    c = next;
  }
  if (save_args) {
    for (int i = 0; i < save_args_n; i++) CDM_FreeAST(save_args[i]);
    free(save_args);
  }
  if (save_elems) {
    for (int i = 0; i < save_elems_n; i++) CDM_FreeAST(save_elems[i]);
    free(save_elems);
  }
  if (save_left && save_left != save_first_child) CDM_FreeAST(save_left);
  if (save_right && save_right != save_first_child) CDM_FreeAST(save_right);
  if (save_body && save_body != save_first_child) CDM_FreeAST(save_body);
  if (save_init && save_init != save_first_child) CDM_FreeAST(save_init);
  if (save_update && save_update != save_first_child) CDM_FreeAST(save_update);
  if (save_cond && save_cond != save_first_child) CDM_FreeAST(save_cond);
  if (save_step && save_step != save_first_child) CDM_FreeAST(save_step);
  free(node);
}

static int g_returning = 0;
static CDM_Value_t g_return_value;

static CDM_Value_t eval_primary(ASTNode_t* node);
static int exec_statement(ASTNode_t* node);
static int resolve_any_lvalue(ASTNode_t* node, CDM_Value_t* out_slot);

static int is_stream_chain(ASTNode_t* n, const char* op, const char* member) {
  if (!n) return 0;
  if (n->type == AST_MEMBER && strcmp(n->name, "std") == 0 &&
      n->first_child && strcmp(n->first_child->name, member) == 0) return 1;
  if (n->type == AST_BINARY && strcmp(n->name, op) == 0)
    return is_stream_chain(n->left, op, member);
  return 0;
}
#define is_cout_chain(n) is_stream_chain((n), "<<", "cout")
#define is_cin_chain(n)  is_stream_chain((n), ">>", "cin")

static void output_value(ASTNode_t* node) {
  if (!node) return;
  if (node->type == AST_STRING) {
    CDM_HostFunc_t fn = find_host_func("__print_str");
    if (fn) { const char* args[1] = { node->name }; fn(1, args); }
    return;
  }
  CDM_Value_t v = CDM_Deref(eval_primary(node));
  if (v.type == CDM_TYPE_STRING) {
    CDM_HostFunc_t fn = find_host_func("__print_str");
    if (fn) { const char* args[1] = { val_to_str_raw(v) }; fn(1, args); }
  } else if (v.type == CDM_TYPE_FLOAT) {
    CDM_HostFunc_t fn = find_host_func("__print_float");
    if (fn) {
      char buf[32]; snprintf(buf, sizeof(buf), "%g", v.v.f);
      const char* args[1] = { buf }; fn(1, args);
    }
  } else if (v.type == CDM_TYPE_ARRAY || v.type == CDM_TYPE_STRUCT) {
    CDM_HostFunc_t fn = find_host_func("__print_str");
    if (fn) { const char* args[1] = { "<object>" }; fn(1, args); }
  } else {
    CDM_HostFunc_t fn = find_host_func("__print_int");
    if (fn) {
      char buf[32]; snprintf(buf, sizeof(buf), "%lld", (long long)val_to_int_raw(v));
      const char* args[1] = { buf }; fn(1, args);
    }
  }
  if (v.owned) value_release(v);
}

static void input_value(ASTNode_t* node) {
  if (!node || node->type != AST_IDENTIFIER) return;
  Symbol_t* s = find_symbol(node->name);
  if (!s) s = create_symbol(node->name);
  if (!s) return;
  if (s->value.type == CDM_TYPE_FLOAT) {
    CDM_HostFunc_t fn = find_host_func("__read_float");
    if (fn) {
      int32_t bits = (int32_t)fn(0, NULL);
      float f; memcpy(&f, &bits, sizeof(f));
      s->value.v.f = (double)f;
    }
  } else if (s->value.type == CDM_TYPE_STRING) {
    CDM_HostFunc_t fn = find_host_func("__read_str");
    if (fn) {
      const char* s2 = (const char*)fn(0, NULL);
      if (s2) { value_release(s->value); s->value = CDM_MakeString(s2); }
    }
  } else {
    CDM_HostFunc_t fn = find_host_func("__read_int");
    if (fn) s->value.v.i = fn(0, NULL);
  }
}

static ASTNode_t* collect_indices(ASTNode_t* node, ASTNode_t** idxs, int* dim) {
  if (!node) return NULL;
  if (node->type == AST_ARRAY_SUBSCRIPT) {
    ASTNode_t* base = collect_indices(node->left, idxs, dim);
    if (*dim < 8) idxs[(*dim)++] = node->right;
    return base;
  }
  return node;
}
static int flatten_index(CDM_Value_t arr, ASTNode_t** idxs, int dim) {
  if (dim <= 0) return 0;
  int n = dim < arr.array_dim ? dim : arr.array_dim;
  int offset = 0;
  for (int i = 0; i < n; i++) {
    CDM_Value_t iv = CDM_Deref(eval_primary(idxs[i]));
    int idx = (int)val_to_int_raw(iv);
    if (iv.owned) value_release(iv);
    if (idx < 0 || idx >= arr.array_sizes[i]) {
      report_error(NULL, "array index [%d]=%d out of range [0,%d)", i, idx, arr.array_sizes[i]);
      return -1;
    }
    int mult = 1;
    for (int j = i + 1; j < arr.array_dim; j++) mult *= arr.array_sizes[j];
    offset += idx * mult;
  }
  return offset;
}
static int resolve_array_lvalue(ASTNode_t* node, CDM_Value_t* out_arr, int* out_idx) {
  if (!node || node->type != AST_ARRAY_SUBSCRIPT) return 0;
  ASTNode_t* idxs[8];
  int dim = 0;
  ASTNode_t* base = collect_indices(node, idxs, &dim);
  if (!base || base->type != AST_IDENTIFIER) return 0;
  Symbol_t* s = find_symbol(base->name);
  if (!s || s->value.type != CDM_TYPE_ARRAY) return 0;
  int off = flatten_index(s->value, idxs, dim);
  if (off < 0) return 0;
  *out_arr = s->value;
  *out_idx = off;
  return 1;
}
static int resolve_member_lvalue(ASTNode_t* node, CDM_Value_t* out_struct, int* out_field) {
  if (!node || node->type != AST_MEMBER_ACCESS) return 0;
  CDM_Value_t obj;
  if (node->left->type == AST_IDENTIFIER) {
    Symbol_t* s = find_symbol(node->left->name);
    if (!s) return 0;
    obj = CDM_Deref(s->value);
  } else if (node->left->type == AST_MEMBER_ACCESS) {
    CDM_Value_t inner; int f;
    if (!resolve_member_lvalue(node->left, &inner, &f)) return 0;
    inner = CDM_Deref(inner);
    if (inner.type != CDM_TYPE_STRUCT || !inner.v.p) return 0;
    obj = ((CDM_Value_t*)inner.v.p)[f];
  } else if (node->left->type == AST_ARRAY_SUBSCRIPT) {
    CDM_Value_t arr; int idx;
    if (!resolve_array_lvalue(node->left, &arr, &idx)) return 0;
    if (arr.type != CDM_TYPE_ARRAY || !arr.v.p) return 0;
    obj = ((CDM_Value_t*)arr.v.p)[idx];
  } else {
    obj = CDM_Deref(eval_primary(node->left));
  }
  obj = CDM_Deref(obj);
  if (obj.type != CDM_TYPE_STRUCT || obj.struct_id < 0) return 0;
  int fidx = find_field_index(obj.struct_id, node->name);
  if (fidx < 0) return 0;
  *out_struct = obj;
  *out_field = fidx;
  return 1;
}
static int resolve_any_lvalue(ASTNode_t* node, CDM_Value_t* out_slot) {
  if (!node) return 0;
  if (node->type == AST_IDENTIFIER) {
    Symbol_t* s = find_symbol(node->name);
    if (!s) s = create_symbol(node->name);
    if (!s) return 0;
    *out_slot = make_ref(&s->value);
    return 1;
  }
  if (node->type == AST_MEMBER_ACCESS) {
    CDM_Value_t obj; int f;
    if (resolve_member_lvalue(node, &obj, &f)) {
      *out_slot = make_ref(&((CDM_Value_t*)obj.v.p)[f]);
      return 1;
    }
  }
  if (node->type == AST_ARRAY_SUBSCRIPT) {
    CDM_Value_t arr; int idx;
    if (resolve_array_lvalue(node, &arr, &idx)) {
      *out_slot = make_ref(&((CDM_Value_t*)arr.v.p)[idx]);
      return 1;
    }
  }
  return 0;
}

static CDM_Value_t write_lvalue(ASTNode_t* node, CDM_Value_t r) {
  CDM_Value_t none; init_common(&none); none.type = CDM_TYPE_INT;

  CDM_Value_t slot;
  if (!resolve_any_lvalue(node, &slot)) {
    if (r.owned) value_release(r);
    return none;
  }
  CDM_Value_t* p = (CDM_Value_t*)slot.v.p;
  if (!p) {
    if (r.owned) value_release(r);
    return none;
  }

  if (p->type == CDM_TYPE_STRING && r.type == CDM_TYPE_STRING) {
    /* set_string_slot копирует ДО освобождения — `s = s;` безопасно */
    set_string_slot(p, r.v.p ? (const char*)r.v.p : "");
    if (r.owned) value_release(r);
    CDM_Value_t ret = *p; ret.owned = 0; return ret;
  }
  if (p->type == CDM_TYPE_FLOAT && r.type != CDM_TYPE_FLOAT) {
    double v = val_to_double_raw(r);
    value_release(*p);
    *p = make_float(v);
    if (r.owned) value_release(r);
    CDM_Value_t ret = *p; ret.owned = 0; return ret;
  }
  if (p->type == CDM_TYPE_INT && r.type == CDM_TYPE_FLOAT) {
    value_release(*p);
    *p = make_int((int64_t)r.v.f);
    if (r.owned) value_release(r);
    CDM_Value_t ret = *p; ret.owned = 0; return ret;
  }
  if (p->type == CDM_TYPE_STRUCT && r.type == CDM_TYPE_STRUCT &&
      p->struct_id == r.struct_id && p->v.p && r.v.p) {
    int nf = g_struct_defs[p->struct_id].field_count;
    memcpy(p->v.p, r.v.p, nf * sizeof(CDM_Value_t));
    if (r.owned) value_release(r);
    CDM_Value_t ret = *p; ret.owned = 0; return ret;
  }
  value_release(*p);
  *p = r;
  CDM_Value_t ret = *p; ret.owned = 0; return ret;
}

static CDM_Value_t call_user_func(ASTNode_t* func, ASTNode_t* call) {
  int saved_returning = g_returning;
  CDM_Value_t saved_rv = g_return_value;
  g_returning = 0;
  g_return_value = make_int(0);
  scope_enter();
  int n = func->arg_count < call->arg_count ? func->arg_count : call->arg_count;
  for (int i = 0; i < n; i++) {
    CDM_Value_t v = CDM_Deref(eval_primary(call->args[i]));
    /* Always create a fresh symbol for the parameter in this   */
    /* scope. The original find_symbol() would return a parent */
    /* scope's symbol and overwrite it, breaking recursion.    */
    Symbol_t* s = create_symbol(func->args[i]->name);
    if (s) { value_release(s->value); s->value = v; }
  }
  if (func->body) exec_statement(func->body);
  if (g_goto_pending) {
    /* goto не нашел метку в теле функции */
    report_error(NULL, "undefined label '%s'", g_goto_label);
    g_goto_pending = 0;
  }
  CDM_Value_t result = g_return_value;
  scope_exit();
  g_returning = saved_returning;
  g_return_value = saved_rv;
  return result;
}

static void build_host_args(ASTNode_t* node, CDM_Value_t* out, int* out_n) {
  int n = node->arg_count < 32 ? node->arg_count : 32;
  for (int i = 0; i < n; i++) {
    ASTNode_t* arg = node->args[i];
    CDM_Value_t slot;
    if ((arg->type == AST_IDENTIFIER || arg->type == AST_MEMBER_ACCESS || arg->type == AST_ARRAY_SUBSCRIPT)
        && resolve_any_lvalue(arg, &slot)) {
      CDM_Value_t* p = (CDM_Value_t*)slot.v.p;
      if (p) { out[i] = make_ref(p); continue; }
    }
    out[i] = eval_primary(arg);
  }
  *out_n = n;
}

static CDM_Value_t eval_method_call(ASTNode_t* node) {
  CDM_Value_t obj = CDM_Deref(eval_primary(node->left));
  const char* type_prefix = NULL;
  if (obj.type == CDM_TYPE_STRING) type_prefix = "std::string";
  else if (obj.type == CDM_TYPE_STRUCT && obj.struct_id >= 0)
    type_prefix = g_struct_defs[obj.struct_id].name;
  else {
    if (obj.owned) value_release(obj);
    return make_int(0);
  }

  char fname[128];
  snprintf(fname, sizeof(fname), "%s.%s", type_prefix, node->name);

  CDM_HostFuncEx_t ex = find_host_ex(fname);
  if (!ex) {
    report_error(NULL, "no method '%s'", fname);
    if (obj.owned) value_release(obj);
    return make_int(0);
  }
  CDM_Value_t args[32];
  args[0] = obj;
  int n = node->arg_count < 31 ? node->arg_count : 31;
  for (int i = 0; i < n; i++) args[i + 1] = CDM_Deref(eval_primary(node->args[i]));

  CDM_Value_t result = ex(n + 1, args);

  if (obj.owned) value_release(obj);
  for (int i = 0; i < n; i++)
    if (args[i + 1].owned) value_release(args[i + 1]);

  return result;
}

static CDM_Value_t eval_func_call(ASTNode_t* node) {
  ASTNode_t* uf = find_user_func(node->name);
  if (uf) return call_user_func(uf, node);

  CDM_HostFuncEx_t ex = NULL;
  if (node->cached_he_tried) {
    ex = (CDM_HostFuncEx_t)node->cached_host_ex;
  } else {
    ex = find_host_ex(node->name);
    node->cached_host_ex = (void*)ex;
    node->cached_he_tried = 1;
  }
  if (ex) {
    CDM_Value_t args[32];
    int n = 0;
    build_host_args(node, args, &n);
    CDM_Value_t result = ex(n, args);
    for (int i = 0; i < n; i++)
      if (!CDM_IsRef(args[i]) && args[i].owned) value_release(args[i]);
    return result;
  }

  CDM_HostFunc_t fn = NULL;
  if (node->cached_hf_tried) {
    fn = (CDM_HostFunc_t)node->cached_host_func;
  } else {
    fn = find_host_func(node->name);
    node->cached_host_func = (void*)fn;
    node->cached_hf_tried = 1;
  }
  if (!fn) {
    report_error(NULL, "undefined function '%s'", node->name);
    return make_int(0);
  }

  const char* argv[32];
  char* heap_args[32];
  int heap_count = 0;
  for (int i = 0; i < node->arg_count && i < 32; i++) {
    if (node->args[i]->type == AST_STRING) {
      argv[i] = node->args[i]->name;
    } else {
      CDM_Value_t v = CDM_Deref(eval_primary(node->args[i]));
      char* buf = (char*)malloc(64);
      if (v.type == CDM_TYPE_FLOAT) snprintf(buf, 64, "%g", v.v.f);
      else if (v.type == CDM_TYPE_STRING) snprintf(buf, 64, "%s", val_to_str_raw(v));
      else snprintf(buf, 64, "%lld", (long long)val_to_int_raw(v));
      if (v.owned) value_release(v);
      argv[i] = buf;
      heap_args[heap_count++] = buf;
    }
  }
  int ret = fn(node->arg_count, argv);
  for (int i = 0; i < heap_count; i++) free(heap_args[i]);

  if (is_float_func(node->name)) {
    float f; memcpy(&f, &ret, sizeof(f));
    return make_float((double)f);
  }
  return make_int(ret);
}

static CDM_Value_t do_new(ASTNode_t* node) {
  if (node->type == AST_NEW_ARRAY) {
    int n = 1;
    if (node->left) {
      CDM_Value_t nv = CDM_Deref(eval_primary(node->left));
      n = (int)val_to_int_raw(nv);
      if (nv.owned) value_release(nv);
    }
    if (n <= 0) n = 1;
    CDM_Value_t* arr = array_new(n, node->decl_type, node->struct_id);
    if (!arr) return make_ptr(NULL, 0);
    CDM_Value_t v = make_ptr(arr, 1);
    v.from_new = 1;
    return v;
  } else {
    if (node->decl_type == CDM_TYPE_STRUCT && node->struct_id >= 0) {
      int nf = g_struct_defs[node->struct_id].field_count;
      CDM_Value_t* block = (CDM_Value_t*)calloc(nf, sizeof(CDM_Value_t));
      for (int i = 0; i < nf; i++) block[i] = make_int(0);
      CDM_Value_t r = make_ptr(block, 1);
      r.struct_id = node->struct_id;   /* чтобы p->field работал через (*p) */
      return r;
    } else if (node->decl_type == CDM_TYPE_FLOAT) {
      double* p = (double*)malloc(sizeof(double));
      if (!p) return make_ptr(NULL, 0);
      *p = 0;
      return make_ptr(p, 1);
    } else {
      int64_t* p = (int64_t*)malloc(sizeof(int64_t));
      if (!p) return make_ptr(NULL, 0);
      *p = 0;
      return make_ptr(p, 1);
    }
  }
}

static CDM_Value_t eval_assign(ASTNode_t* node, const char* op) {
  if (strcmp(op, "=") == 0) {
    CDM_Value_t r = CDM_Deref(eval_primary(node->right));
    return write_lvalue(node->left, r);
  }

  CDM_Value_t slot;
  if (!resolve_any_lvalue(node->left, &slot)) {
    CDM_Value_t r = CDM_Deref(eval_primary(node->right));
    if (r.owned) value_release(r);
    return make_int(0);
  }
  CDM_Value_t* p = (CDM_Value_t*)slot.v.p;
  if (!p) return make_int(0);

  CDM_Value_t old = *p;
  CDM_Value_t r = CDM_Deref(eval_primary(node->right));

  if (strcmp(op, "+=") == 0 &&
      old.type == CDM_TYPE_STRING && r.type == CDM_TYPE_STRING) {
    const char* a = val_to_str_raw(old);
    const char* b = val_to_str_raw(r);
    size_t la = strlen(a), lb = strlen(b);
    char* buf = (char*)malloc(la + lb + 1);
    CDM_Value_t nv;
    if (buf) {
      memcpy(buf, a, la);
      memcpy(buf + la, b, lb);
      buf[la + lb] = '\0';
      nv = CDM_MakeStringOwned(buf);
    } else {
      nv = make_int(0);
    }
    if (r.owned) value_release(r);
    value_release(*p);
    *p = nv;
    CDM_Value_t ret = *p; ret.owned = 0;
    return ret;
  }

  if (op[0] == '&' || op[0] == '|' || op[0] == '^' ||
      (op[0] == '<' && op[1] == '<') || (op[0] == '>' && op[1] == '>')) {
    int64_t o = val_to_int_raw(old);
    int64_t x = val_to_int_raw(r);
    int64_t z = o;
    if (strcmp(op, "&=") == 0) z = o & x;
    else if (strcmp(op, "|=") == 0) z = o | x;
    else if (strcmp(op, "^=") == 0) z = o ^ x;
    else if (strcmp(op, "<<=") == 0) z = o << x;
    else if (strcmp(op, ">>=") == 0) z = o >> x;
    if (r.owned) value_release(r);
    value_release(*p);
    *p = make_int(z);
    CDM_Value_t ret = *p; ret.owned = 0;
    return ret;
  }

  double o = val_to_double_raw(old);
  double x = val_to_double_raw(r);
  double z = o;
  if (strcmp(op, "+=") == 0) z = o + x;
  else if (strcmp(op, "-=") == 0) z = o - x;
  else if (strcmp(op, "*=") == 0) z = o * x;
  else if (strcmp(op, "/=") == 0) z = x != 0 ? o / x : 0;
  else if (strcmp(op, "%=") == 0) z = x != 0 ? (double)((int64_t)o % (int64_t)x) : 0;
  if (r.owned) value_release(r);
  value_release(*p);
  *p = (old.type == CDM_TYPE_FLOAT) ? make_float(z) : make_int((int64_t)z);
  CDM_Value_t ret = *p; ret.owned = 0;
  return ret;
}

static CDM_Value_t eval_binary_values(const char* op,
                                      CDM_Value_t l, CDM_Value_t r) {
  if (strcmp(op, "+") == 0 && (val_is_string(l) || val_is_string(r))) {
    const char* ls = val_is_string(l) ? val_to_str_raw(l) : "";
    const char* rs = val_is_string(r) ? val_to_str_raw(r) : "";
    size_t ln = strlen(ls), rn = strlen(rs);
    char* buf = (char*)malloc(ln + rn + 1);
    if (!buf) return make_int(0);
    memcpy(buf, ls, ln);
    memcpy(buf + ln, rs, rn);
    buf[ln + rn] = '\0';
    return CDM_MakeStringOwned(buf);
  }

  if (strcmp(op, "&&") == 0) return make_int(val_to_int_raw(l) && val_to_int_raw(r));
  if (strcmp(op, "||") == 0) return make_int(val_to_int_raw(l) || val_to_int_raw(r));

  if (strcmp(op, "==") == 0) {
    if (val_is_string(l) || val_is_string(r))
      return make_int(strcmp(val_to_str_raw(l), val_to_str_raw(r)) == 0);
    if (val_is_float(l) || val_is_float(r))
      return make_int(val_to_double_raw(l) == val_to_double_raw(r));
    if (val_is_ptr(l) || val_is_ptr(r))
      return make_int(l.v.p == r.v.p);
    return make_int(val_to_int_raw(l) == val_to_int_raw(r));
  }
  if (strcmp(op, "!=") == 0) {
    if (val_is_string(l) || val_is_string(r))
      return make_int(strcmp(val_to_str_raw(l), val_to_str_raw(r)) != 0);
    if (val_is_float(l) || val_is_float(r))
      return make_int(val_to_double_raw(l) != val_to_double_raw(r));
    if (val_is_ptr(l) || val_is_ptr(r))
      return make_int(l.v.p != r.v.p);
    return make_int(val_to_int_raw(l) != val_to_int_raw(r));
  }

  if (strcmp(op, "<") == 0)  return make_int(val_to_double_raw(l) <  val_to_double_raw(r));
  if (strcmp(op, ">") == 0)  return make_int(val_to_double_raw(l) >  val_to_double_raw(r));
  if (strcmp(op, "<=") == 0) return make_int(val_to_double_raw(l) <= val_to_double_raw(r));
  if (strcmp(op, ">=") == 0) return make_int(val_to_double_raw(l) >= val_to_double_raw(r));

  if (val_is_float(l) || val_is_float(r)) {
    double ld = val_to_double_raw(l), rd = val_to_double_raw(r);
    if (strcmp(op, "+") == 0) return make_float(ld + rd);
    if (strcmp(op, "-") == 0) return make_float(ld - rd);
    if (strcmp(op, "*") == 0) return make_float(ld * rd);
    if (strcmp(op, "/") == 0) return make_float(rd != 0 ? ld / rd : 0);
    if (strcmp(op, "%") == 0) return make_float(rd != 0 ? (double)((int64_t)ld % (int64_t)rd) : 0);
  }

  int64_t li = val_to_int_raw(l), ri = val_to_int_raw(r);
  if (strcmp(op, "+") == 0)  return make_int(li + ri);
  if (strcmp(op, "-") == 0)  return make_int(li - ri);
  if (strcmp(op, "*") == 0)  return make_int(li * ri);
  if (strcmp(op, "/") == 0) {
    if (ri == 0) { report_error(NULL, "division by zero"); return make_int(0); }
    return make_int(li / ri);
  }
  if (strcmp(op, "%") == 0) {
    if (ri == 0) { report_error(NULL, "modulo by zero"); return make_int(0); }
    return make_int(li % ri);
  }
  if (strcmp(op, "&") == 0)  return make_int(li & ri);
  if (strcmp(op, "|") == 0)  return make_int(li | ri);
  if (strcmp(op, "^") == 0)  return make_int(li ^ ri);
  if (strcmp(op, "<<") == 0) return make_int(li << ri);
  if (strcmp(op, ">>") == 0) return make_int(li >> ri);
  return make_int(0);
}

static CDM_Value_t eval_binary(ASTNode_t* node) {
  const char* op = node->name;

  if (strcmp(op, "<<") == 0 && is_cout_chain(node)) {
    eval_primary(node->left);
    output_value(node->right);
    return make_int(0);
  }
  if (strcmp(op, ">>") == 0 && is_cin_chain(node)) {
    eval_primary(node->left);
    input_value(node->right);
    return make_int(0);
  }

  if (strcmp(op, "=") == 0 || strcmp(op, "+=") == 0 || strcmp(op, "-=") == 0 ||
      strcmp(op, "*=") == 0 || strcmp(op, "/=") == 0 || strcmp(op, "%=") == 0 ||
      strcmp(op, "&=") == 0 || strcmp(op, "|=") == 0 || strcmp(op, "^=") == 0 ||
      strcmp(op, "<<=") == 0 || strcmp(op, ">>=") == 0) {
    return eval_assign(node, op);
  }

  CDM_Value_t l = CDM_Deref(eval_primary(node->left));
  CDM_Value_t r = CDM_Deref(eval_primary(node->right));

  CDM_Value_t result = eval_binary_values(op, l, r);

  if (l.owned) value_release(l);
  if (r.owned) value_release(r);

  return result;
}

static CDM_Value_t eval_primary(ASTNode_t* node) {
  if (!node) return make_int(0);
  if (node->line) g_current_line = node->line;

  switch (node->type) {
    case AST_NUMBER:
      if (strchr(node->name, '.') || strchr(node->name, 'e') || strchr(node->name, 'E'))
        return make_float(node->fval);
      return make_int(node->ival);
    case AST_STRING:
      return CDM_MakeString(node->name);
    case AST_IDENTIFIER:
      {
        int ei = find_enum(node->name);
        if (ei >= 0) return make_int(g_enums[ei].value);

        /* Symbol cache disabled: it returns stale pointers in */
        /* recursive calls (the function body's AST is shared  */
        /* across invocations, but each has its own 'n' slot). */
        Symbol_t* s = find_symbol(node->name);
        if (!s) return make_int(0);
        CDM_Value_t v = s->value;
        v.owned = 0;
        v.from_new = 0;
        return v;
      }
    case AST_BINARY: return eval_binary(node);
    case AST_FUNC_CALL: return eval_func_call(node);
    case AST_METHOD_CALL: return eval_method_call(node);
    case AST_NEW:
    case AST_NEW_ARRAY: return do_new(node);
    case AST_MEMBER_ACCESS:
      {
        CDM_Value_t obj; int fidx;
        if (resolve_member_lvalue(node, &obj, &fidx)) {
          CDM_Value_t v = ((CDM_Value_t*)obj.v.p)[fidx];
          v.owned = 0;
          v.from_new = 0;
          return v;
        }
        return make_int(0);
      }
    case AST_ARRAY_SUBSCRIPT:
      {
        CDM_Value_t arr; int idx;
        if (resolve_array_lvalue(node, &arr, &idx)) {
          if (idx < 0 || idx >= arr.array_len) return make_int(0);
          CDM_Value_t v = ((CDM_Value_t*)arr.v.p)[idx];
          v.owned = 0;
          v.from_new = 0;
          return v;
        }
        return make_int(0);
      }
    case AST_TERNARY:
      {
        CDM_Value_t c = CDM_Deref(eval_primary(node->left));
        int cond = val_to_int_raw(c);
        if (c.owned) value_release(c);
        return cond ? eval_primary(node->right) : eval_primary(node->init);
      }
    case AST_UNARY:
      {
        if (strcmp(node->name, "++") == 0 || strcmp(node->name, "--") == 0) {
          CDM_Value_t slot;
          if (resolve_any_lvalue(node->left, &slot)) {
            CDM_Value_t* p = (CDM_Value_t*)slot.v.p;
            if (p) {
              CDM_Value_t old = *p;
              int delta = (node->name[0] == '+') ? 1 : -1;
              if (old.type == CDM_TYPE_FLOAT) p->v.f += delta;
              else p->v.i += delta;
              CDM_Value_t ret = node->is_ptr ? old : *p;
              ret.owned = 0;
              return ret;
            }
          }
          return make_int(0);
        }
        if (strcmp(node->name, "*") == 0) {
          /* ВАЖНО: после CDM_Deref мы уже имеем указуемое значение.
           * Старый код проверял REF после deref — ветка была мертвой,
           * и *p для p = &structvar всегда давал 0. */
          CDM_Value_t ptr = CDM_Deref(eval_primary(node->left));
          if (ptr.type == CDM_TYPE_STRUCT) {
            /* *p на struct-значении: отдаем struct, поля общие (v.p) */
            ptr.owned = 0;
            return ptr;
          }
          if (ptr.type == CDM_TYPE_REF && ptr.v.p) {
            CDM_Value_t v = *(CDM_Value_t*)ptr.v.p;
            v.owned = 0;
            return v;
          }
          if (ptr.type == CDM_TYPE_PTR && ptr.v.p) {
            /* указатель на struct (do_new ставит struct_id):
             * *p дает struct-значение — на нем работает (*p).field / p->field */
            if (ptr.struct_id >= 0)
              return make_struct(ptr.v.p, ptr.struct_id, 0);
            return make_ptr(ptr.v.p, 0);
          }
          return make_int(0);
        }
        if (strcmp(node->name, "&") == 0) {
          if (node->left->type == AST_IDENTIFIER) {
            Symbol_t* s = find_symbol(node->left->name);
            if (!s) s = create_symbol(node->left->name);
            if (s) return make_ref(&s->value);
          }
          return make_ptr(NULL, 0);
        }
        CDM_Value_t v = CDM_Deref(eval_primary(node->left));
        CDM_Value_t result;
        if (strcmp(node->name, "-") == 0) {
          result = val_is_float(v) ? make_float(-v.v.f) : make_int(-v.v.i);
        } else if (strcmp(node->name, "!") == 0) {
          result = make_int(!val_to_int_raw(v));
        } else if (strcmp(node->name, "~") == 0) {
          result = make_int(~val_to_int_raw(v));
        } else {
          result = v;
          result.owned = 0;
        }
        if (v.owned) value_release(v);
        return result;
      }
    case AST_ENUM_DECL:
      return make_int(0);

    case AST_SIZEOF:
      {
        if (node->left && node->left->type == AST_ARRAY_SUBSCRIPT) {
          CDM_Value_t arr; int idx;
          if (resolve_array_lvalue(node->left, &arr, &idx)) {
            int64_t es = 4;
            if (arr.array_elem_type == CDM_TYPE_FLOAT) es = 8;
            else if (arr.array_elem_type == CDM_TYPE_PTR) es = 8;
            return make_int(es);
          }
        }
        if (node->left && node->left->type == AST_IDENTIFIER) {
          Symbol_t* s = find_symbol(node->left->name);
          if (s) return make_int(sizeof_value(s->value));
        }
        CDM_Value_t v = CDM_Deref(eval_primary(node->left));
        int64_t sz = sizeof_value(v);
        if (v.owned) value_release(v);
        return make_int(sz);
      }

    case AST_CAST:
      {
        CDM_Value_t v = CDM_Deref(eval_primary(node->left));
        CDM_Value_t result;
        init_common(&result);
        if (node->decl_type == CDM_TYPE_FLOAT) {
          result = make_float(val_to_double_raw(v));
        } else if (node->decl_type == CDM_TYPE_PTR) {
          void* ptr = (v.type == CDM_TYPE_PTR) ? v.v.p : (void*)(intptr_t)val_to_int_raw(v);
          result = make_ptr(ptr, 0);
        } else {
          result = make_int(val_to_int_raw(v));
        }
        if (v.owned) value_release(v);
        return result;
      }

    case AST_MEMBER: return make_int(0);
    /* эти узлы исполняются в exec_statement; здесь нейтральные значения */
    case AST_LABEL:
    case AST_GOTO:
    case AST_TYPEDEF:
      return make_int(0);

    default: break; /* statement-узлы исполняются в exec_statement; сюда
                       попасть не должны — нейтральное значение ниже */
  }
  return make_int(0);
}

/* Поиск метки среди прямых детей блока (для goto) */
static ASTNode_t* find_label_in_block(ASTNode_t* block, const char* name) {
  if (!block) return NULL;
  for (ASTNode_t* c = block->first_child; c; c = c->next_sibling)
    if (c->type == AST_LABEL && strcmp(c->name, name) == 0) return c;
  return NULL;
}

static int exec_statement(ASTNode_t* node) {
  if (!node || g_returning || g_break_flag || g_continue_flag) return 0;
  if (node->line) g_current_line = node->line;

  switch (node->type) {
    case AST_BLOCK:
      {
        scope_enter();
        ASTNode_t* c = node->first_child;
        while (c && !g_returning && !g_break_flag && !g_continue_flag) {
          exec_statement(c);
          if (g_goto_pending) {
            /* метка в этом же блоке — продолжаем с неё (в т.ч. назад) */
            ASTNode_t* lbl = find_label_in_block(node, g_goto_label);
            if (lbl) { g_goto_pending = 0; c = lbl; continue; }
            break;   /* метки здесь нет — ищем снаружи */
          }
          c = c->next_sibling;
        }
        scope_exit();
        return 0;
      }
    case AST_RETURN:
      g_returning = 1;
      g_return_value = node->left ? eval_primary(node->left) : make_int(0);
      return 0;

    case AST_BREAK:    g_break_flag = 1;    return 0;
    case AST_CONTINUE: g_continue_flag = 1; return 0;

    case AST_VAR_DECL:
      {
        /* Symbol cache disabled for recursion safety. */
        Symbol_t* s = find_symbol(node->name);
        if (!s) s = create_symbol(node->name);
        if (!s) return 0;

        if (node->decl_type == CDM_TYPE_STRUCT && node->struct_id >= 0 && !node->is_auto) {
          int nf = g_struct_defs[node->struct_id].field_count;
          CDM_Value_t* block = (CDM_Value_t*)calloc(nf, sizeof(CDM_Value_t));
          for (int i = 0; i < nf; i++) block[i] = make_int(0);
          value_release(s->value);
          s->value = make_struct(block, node->struct_id, 1);
          if (node->left) {
            CDM_Value_t r = CDM_Deref(eval_primary(node->left));
            if (r.type == CDM_TYPE_STRUCT && r.v.p && r.struct_id == node->struct_id)
              memcpy(block, r.v.p, nf * sizeof(CDM_Value_t));
            if (r.owned) value_release(r);
          }
        } else {
          if (node->left) {
            /* ВАЖНО: без CDM_Deref! &x даёт REF на слот; старый код
             * разворачивал ссылку и клонировал значение с owned=1 —
             * один блок освобождался дважды (слот оригинала + клон).
             * Point* p = &x; теперь честно держит ссылку. */
            CDM_Value_t v = eval_primary(node->left);
            if (node->is_auto) {
              value_release(s->value);
              s->value = v;
              s->value.owned = 0;
              if (v.type == CDM_TYPE_STRING) {
                s->value = CDM_MakeString(val_to_str_raw(v));
                if (v.owned) value_release(v);
              }
            } else if (v.type == CDM_TYPE_STRING && node->decl_type == CDM_TYPE_STRING) {
              value_release(s->value); s->value = CDM_MakeString(val_to_str_raw(v));
              if (v.owned) value_release(v);
            } else if (node->decl_type == CDM_TYPE_FLOAT && v.type != CDM_TYPE_FLOAT) {
              value_release(s->value); s->value = make_float((double)val_to_double_raw(v));
              if (v.owned) value_release(v);
            } else if (node->decl_type == CDM_TYPE_INT && v.type == CDM_TYPE_FLOAT) {
              value_release(s->value); s->value = make_int((int64_t)v.v.f);
              if (v.owned) value_release(v);
            } else {
              value_release(s->value);
              s->value = v;
            }
          } else {
            value_release(s->value);
            if (node->decl_type == CDM_TYPE_FLOAT) s->value = make_float(0.0);
            else if (node->decl_type == CDM_TYPE_PTR) s->value = make_ptr(NULL, 0);
            else if (node->decl_type == CDM_TYPE_STRING) s->value = CDM_MakeString("");
            else s->value = make_int(0);
          }
        }
        return 0;
      }
    case AST_ARRAY_DECL:
      {
        /* Symbol cache disabled for recursion safety. */
        Symbol_t* s = find_symbol(node->name);
        if (!s) s = create_symbol(node->name);
        if (!s) return 0;
        int n = node->array_len > 0 ? node->array_len : 1;
        CDM_Value_t* block = (CDM_Value_t*)calloc(n, sizeof(CDM_Value_t));
        if (node->decl_type == CDM_TYPE_STRUCT && node->struct_id >= 0) {
          int nf = g_struct_defs[node->struct_id].field_count;
          for (int i = 0; i < n; i++) {
            CDM_Value_t* fblock = (CDM_Value_t*)calloc(nf, sizeof(CDM_Value_t));
            for (int j = 0; j < nf; j++) fblock[j] = make_int(0);
            block[i] = make_struct(fblock, node->struct_id, 1);
          }
        } else if (node->decl_type == CDM_TYPE_STRING) {
          for (int i = 0; i < n; i++) block[i] = CDM_MakeString("");
        } else {
          for (int i = 0; i < n; i++) block[i] = make_int(0);
        }
        value_release(s->value);
        s->value = make_array(block, n, node->array_dim,
                              node->array_sizes, node->decl_type, node->struct_id, 1);
        if (node->init && node->init->type == AST_ARRAY_INIT) {
          int cnt = node->init->elem_count;
          if (cnt > n) cnt = n;
          for (int i = 0; i < cnt; i++) {
            CDM_Value_t v = CDM_Deref(eval_primary(node->init->elems[i]));
            if (node->decl_type == CDM_TYPE_STRUCT && v.type == CDM_TYPE_STRUCT &&
                v.struct_id == node->struct_id && v.v.p) {
              int nf = g_struct_defs[node->struct_id].field_count;
              memcpy(block[i].v.p, v.v.p, nf * sizeof(CDM_Value_t));
              if (v.owned) value_release(v);
            } else if (node->decl_type == CDM_TYPE_STRING && v.type == CDM_TYPE_STRING) {
              block[i] = CDM_MakeString(val_to_str_raw(v));
              if (v.owned) value_release(v);
            } else {
              block[i] = v;
            }
          }
        }
        return 0;
      }
    case AST_EXPR_STMT:
      {
        CDM_Value_t v = CDM_Deref(eval_primary(node->left));
        if (v.owned) value_release(v);
        return 0;
      }
    case AST_IF:
      {
        CDM_Value_t c = CDM_Deref(eval_primary(node->left));
        int v = val_to_int_raw(c);
        if (c.owned) value_release(c);
        if (v) exec_statement(node->body);
        else if (node->right) exec_statement(node->right);
        return 0;
      }
    case AST_WHILE:
      {
        long long guard = 0;
        while (!g_returning && !g_goto_pending) {
          CDM_Value_t c = CDM_Deref(eval_primary(node->left));
          int v = val_to_int_raw(c);
          if (c.owned) value_release(c);
          if (!v) break;
          exec_statement(node->body);
          if (g_break_flag) { g_break_flag = 0; break; }
          if (g_goto_pending) break;   /* goto покидает цикл */
          if (g_continue_flag) g_continue_flag = 0;
          if (++guard > 1000000LL) break;
        }
        g_break_flag = 0; g_continue_flag = 0;
        return 0;
      }
    case AST_DO_WHILE:
      {
        long long guard = 0;
        int cond = 1;
        while (!g_returning && cond && !g_goto_pending) {
          g_continue_flag = 0;
          exec_statement(node->body);
          if (g_break_flag) { g_break_flag = 0; break; }
          if (g_goto_pending) break;
          CDM_Value_t c = CDM_Deref(eval_primary(node->left));
          cond = val_to_int_raw(c);
          if (c.owned) value_release(c);
          if (++guard > 1000000LL) break;
        }
        g_break_flag = 0; g_continue_flag = 0;
        return 0;
      }
    case AST_FOR:
      {
        scope_enter();
        if (node->init) exec_statement(node->init);
        long long guard = 0;
        while (!g_returning && !g_goto_pending) {
          if (node->left) {
            CDM_Value_t c = CDM_Deref(eval_primary(node->left));
            int v = val_to_int_raw(c);
            if (c.owned) value_release(c);
            if (!v) break;
          }
          exec_statement(node->body);
          if (g_break_flag) { g_break_flag = 0; break; }
          if (g_goto_pending) break;
          if (g_continue_flag) g_continue_flag = 0;
          if (node->update) {
            CDM_Value_t u = CDM_Deref(eval_primary(node->update));
            if (u.owned) value_release(u);
          }
          if (++guard > 1000000LL) break;
        }
        g_break_flag = 0; g_continue_flag = 0;
        scope_exit();
        return 0;
      }
    case AST_RANGE_FOR:
      {
        CDM_Value_t arr = CDM_Deref(node->left ? eval_primary(node->left) : make_int(0));
        if (arr.type != CDM_TYPE_ARRAY || !arr.v.p) return 0;
        scope_enter();
        Symbol_t* s = find_symbol(node->name);
        if (!s) s = create_symbol(node->name);
        if (!s) { scope_exit(); return 0; }
        long long guard = 0;
        for (int i = 0; i < arr.array_len; i++) {
          if (g_returning || g_break_flag || g_goto_pending) break;
          g_continue_flag = 0;
          value_release(s->value);
          s->value = ((CDM_Value_t*)arr.v.p)[i];
          s->value.owned = 0;
          exec_statement(node->body);
          if (g_break_flag) break;
          if (g_goto_pending) break;
          if (++guard > 1000000LL) break;
        }
        g_break_flag = 0; g_continue_flag = 0;
        scope_exit();
        return 0;
      }
    case AST_SWITCH:
      {
        CDM_Value_t sw_v = CDM_Deref(eval_primary(node->left));
        long long sw = val_to_int_raw(sw_v);
        if (sw_v.owned) value_release(sw_v);

        ASTNode_t* body = node->body;
        ASTNode_t* c = body ? body->first_child : NULL;
        ASTNode_t* start = NULL;
        ASTNode_t* default_case = NULL;

        ASTNode_t* scan = c;
        while (scan) {
          if (scan->type == AST_CASE) {
            CDM_Value_t cv = CDM_Deref(eval_primary(scan->left));
            long long cval = val_to_int_raw(cv);
            if (cv.owned) value_release(cv);
            if (cval == sw) { start = scan; break; }
          } else if (scan->type == AST_DEFAULT) {
            default_case = scan;
          }
          scan = scan->next_sibling;
        }
        if (!start) start = default_case;
        if (!start) return 0;

        while (start && !g_returning && !g_break_flag && !g_goto_pending) {
          ASTNode_t* s = start->first_child;
          while (s && !g_returning && !g_break_flag && !g_goto_pending) {
            exec_statement(s);
            s = s->next_sibling;
          }
          start = start->next_sibling;
        }
        g_break_flag = 0;
        return 0;
      }
    case AST_CASE:
    case AST_DEFAULT:
      {
        ASTNode_t* s = node->first_child;
        while (s && !g_returning && !g_break_flag && !g_goto_pending) {
          exec_statement(s);
          s = s->next_sibling;
        }
        return 0;
      }
    case AST_DELETE:
      {
        /* delete через lvalue-слот: освобождаем и сбрасываем владение,
         * иначе слот переменной останется owned=1 и освободит блок
         * второй раз при выходе из scope (double free) */
        CDM_Value_t slot;
        if (resolve_any_lvalue(node->left, &slot)) {
          CDM_Value_t* p = (CDM_Value_t*)slot.v.p;
          if (p && p->type == CDM_TYPE_PTR && p->v.p) {
            free(p->v.p);
            p->v.p = NULL;
            p->owned = 0;
          }
        } else {
          CDM_Value_t p = CDM_Deref(node->left ? eval_primary(node->left) : make_int(0));
          if (p.type == CDM_TYPE_PTR && p.v.p) free(p.v.p);
          if (p.owned) value_release(p);
        }
        return 0;
      }
    case AST_DELETE_ARRAY:
      {
        CDM_Value_t slot;
        if (resolve_any_lvalue(node->left, &slot)) {
          CDM_Value_t* p = (CDM_Value_t*)slot.v.p;
          if (p && p->type == CDM_TYPE_PTR && p->v.p) {
            if (!array_free(p->v.p)) free(p->v.p);
            p->v.p = NULL;
            p->owned = 0;
          }
        } else {
          CDM_Value_t p = CDM_Deref(node->left ? eval_primary(node->left) : make_int(0));
          if (p.type == CDM_TYPE_PTR && p.v.p) {
            if (!array_free(p.v.p)) free(p.v.p);
          }
          if (p.owned) value_release(p);
        }
        return 0;
      }
    case AST_LABEL: return 0;   /* метка — no-op, куда переходить знает AST_BLOCK */
    case AST_GOTO:
      strncpy(g_goto_label, node->name, sizeof(g_goto_label) - 1);
      g_goto_label[sizeof(g_goto_label) - 1] = '\0';
      g_goto_pending = 1;
      return 0;
    case AST_TYPEDEF:    return 0;
    case AST_STRUCT_DEF: return 0;
    case AST_ENUM_DECL:  return 0;
    case AST_FUNC_DECL:  return 0;
    default: {
      CDM_Value_t v = eval_primary(node);
      if (v.owned) value_release(v);
      return 0;
    }
  }
}

int CDM_Execute(ASTNode_t* root) {
  if (!root) return -1;
  if (CDM_GetErrorCount() > 0) return -2;

  /* Тайминг нужен только для CDM_DBG — иначе -Wunused-variable */
#if CDM_DEBUG_PRINTF && CDM_HAS_STDIO
  unsigned long t_start_ms = cdm_platform_clock();
#endif

  clear_ast_cache(root);
  g_current_line = 0;

  g_symbol_count = 0;
  g_scope_depth = 0;
  g_returning = 0;
  g_return_value = make_int(0);
  g_break_flag = 0;
  g_continue_flag = 0;
  g_goto_pending = 0;
  g_goto_label[0] = '\0';
  collect_user_funcs(root);

  int ret = 0;
  ASTNode_t* c = root->first_child;
  while (c) {
    if (c->type == AST_FUNC_DECL && strcmp(c->name, "main") == 0) {
      exec_statement(c->body);
      ret = (int)val_to_int_raw(g_return_value);
      break;
    }
    c = c->next_sibling;
  }

  if (g_goto_pending) {   /* goto на верхнем уровне не нашел метку */
    g_goto_pending = 0;
  }

#if CDM_DEBUG_PRINTF && CDM_HAS_STDIO
  unsigned long t_end_ms = cdm_platform_clock();
  double elapsed = (double)(t_end_ms - t_start_ms) / 1000.0;
  CDM_DBG("exit after %.3fs returned %d\n", elapsed, ret);
#endif

  return ret;
}

/* ========================================================================
 *  Begin section: CDM_PREPROC.cpp
 * ======================================================================== */


// ============================================================
//  配置
// ============================================================
#define PP_MAX_MACROS   64
#define PP_MAX_NAME     64
#define PP_MAX_VALUE    256
#define PP_MAX_DEPTH    8
#define PP_MAX_OUT      (64 * 1024)
#define PP_MAX_COND     16
#define PP_MAX_INCLUDED 32
#define PP_MAX_PARAMS   6    /* максимум параметров функционального макроса */
#define PP_MAX_PARAM    32

// ============================================================
//  状态 / состояние
// ============================================================
typedef struct {
    char name[PP_MAX_NAME];
    char value[PP_MAX_VALUE];
    int  is_func;                          /* функциональный макрос F(a,b) */
    int  param_count;
    char params[PP_MAX_PARAMS][PP_MAX_PARAM];
} PP_Macro_t;

typedef struct {
    PP_Macro_t macros[PP_MAX_MACROS];
    int        macro_count;
    char*      out;
    int        out_len;
    int        out_cap;
    int        cond_stack[PP_MAX_COND];   /* 1 = активна, 0 = пропускать */
    int        cond_done[PP_MAX_COND];    /* ветка уже была истинной (#elif/#else) */
    int        cond_depth;
} PP_State_t;

// ---- 全局 include 回调 ----
static CDM_IncludeResolver_t g_include_resolver = NULL;

// ---- 已 include 文件表（#pragma once 效果）----
static char g_included[PP_MAX_INCLUDED][PP_MAX_NAME];
static int  g_included_count = 0;

void CDM_SetIncludeResolver(CDM_IncludeResolver_t fn) {
    g_include_resolver = fn;
}

void CDM_ResetIncludes(void) {
    g_included_count = 0;
}

// ============================================================
//  输出缓冲
// ============================================================
static void out_init(PP_State_t* s) {
    s->out_cap = PP_MAX_OUT;
    s->out = (char*)malloc(s->out_cap);
    if (!s->out) { s->out_len = 0; s->out_cap = 0; return; }
    s->out_len = 0;
    s->out[0] = '\0';
}

static void out_append(PP_State_t* s, const char* txt, int len) {
    if (!s->out || !txt) return;
    if (len < 0) len = (int)strlen(txt);
    if (len == 0) return;
    int remain = s->out_cap - s->out_len - 1;
    if (remain <= 0) return;
    if (len > remain) len = remain;
    memcpy(s->out + s->out_len, txt, len);
    s->out_len += len;
    s->out[s->out_len] = '\0';
}

static void out_append_ch(PP_State_t* s, char c) {
    if (!s->out) return;
    if (s->out_len + 1 >= s->out_cap) return;
    s->out[s->out_len++] = c;
    s->out[s->out_len] = '\0';
}

// ============================================================
//  宏表
// ============================================================
static int pp_find(PP_State_t* s, const char* name) {
    for (int i = 0; i < s->macro_count; i++)
        if (strcmp(s->macros[i].name, name) == 0) return i;
    return -1;
}

static int pp_defined(PP_State_t* s, const char* name) {
    return pp_find(s, name) >= 0;
}

static void pp_define(PP_State_t* s, const char* name, const char* value) {
    int idx = pp_find(s, name);
    if (idx < 0) {
        if (s->macro_count >= PP_MAX_MACROS) return;
        idx = s->macro_count++;
    }
    strncpy(s->macros[idx].name, name, PP_MAX_NAME - 1);
    s->macros[idx].name[PP_MAX_NAME - 1] = '\0';
    strncpy(s->macros[idx].value, value ? value : "", PP_MAX_VALUE - 1);
    s->macros[idx].value[PP_MAX_VALUE - 1] = '\0';
    s->macros[idx].is_func = 0;
    s->macros[idx].param_count = 0;
}

/* функциональный макрос: pcount >= 0 всегда, is_func = 1 */
static void pp_define_func(PP_State_t* s, const char* name,
                           char params[][PP_MAX_PARAM], int pcount,
                           const char* value) {
    int idx = pp_find(s, name);
    if (idx < 0) {
        if (s->macro_count >= PP_MAX_MACROS) return;
        idx = s->macro_count++;
    }
    strncpy(s->macros[idx].name, name, PP_MAX_NAME - 1);
    s->macros[idx].name[PP_MAX_NAME - 1] = '\0';
    strncpy(s->macros[idx].value, value ? value : "", PP_MAX_VALUE - 1);
    s->macros[idx].value[PP_MAX_VALUE - 1] = '\0';
    s->macros[idx].is_func = 1;
    if (pcount < 0) pcount = 0;
    if (pcount > PP_MAX_PARAMS) pcount = PP_MAX_PARAMS;
    s->macros[idx].param_count = pcount;
    for (int i = 0; i < pcount; i++) {
        strncpy(s->macros[idx].params[i], params[i], PP_MAX_PARAM - 1);
        s->macros[idx].params[i][PP_MAX_PARAM - 1] = '\0';
    }
}

static void pp_undef(PP_State_t* s, const char* name) {
    int idx = pp_find(s, name);
    if (idx < 0) return;
    for (int i = idx; i < s->macro_count - 1; i++)
        s->macros[i] = s->macros[i + 1];
    s->macro_count--;
}

// ============================================================
//  Условный стек: push с учётом "ветка уже срабатывала"
// ============================================================
static void pp_push_cond(PP_State_t* s, int cond) {
    if (s->cond_depth >= PP_MAX_COND) return;
    s->cond_stack[s->cond_depth] = cond ? 1 : 0;
    s->cond_done[s->cond_depth] = cond ? 1 : 0;
    s->cond_depth++;
}

// ============================================================
//  ★ Вычислитель выражений #if / #elif
//  defined(NAME) / defined NAME, числа (10 / 0x1F / 010), объектные
//  макросы (рекурсивно, неопределённый идентификатор == 0),
//  ( ) ! ~ - + * / % << >> < <= > >= == != & ^ | && ||
// ============================================================
typedef struct {
    const char* p;
    PP_State_t* st;
    int depth;
} PP_Expr_t;

static int64_t pp_expr_bin(PP_Expr_t* e, int min_prec);

static void pp_expr_ws(PP_Expr_t* e) {
    while (*e->p == ' ' || *e->p == '\t') e->p++;
}

static int64_t pp_expr_primary(PP_Expr_t* e) {
    pp_expr_ws(e);
    char c = *e->p;

    if (c == '(') {
        e->p++;
        int64_t v = pp_expr_bin(e, 0);
        pp_expr_ws(e);
        if (*e->p == ')') e->p++;
        return v;
    }
    if (c == '!') { e->p++; return !pp_expr_primary(e); }
    if (c == '~') { e->p++; return ~pp_expr_primary(e); }
    if (c == '-') { e->p++; return -pp_expr_primary(e); }
    if (c == '+') { e->p++; return  pp_expr_primary(e); }

    if (strncmp(e->p, "defined", 7) == 0 &&
        !(isalnum((unsigned char)e->p[7]) || e->p[7] == '_')) {
        e->p += 7;
        pp_expr_ws(e);
        int has_paren = (*e->p == '(');
        if (has_paren) { e->p++; pp_expr_ws(e); }
        char name[PP_MAX_NAME];
        int j = 0;
        while ((isalnum((unsigned char)*e->p) || *e->p == '_') && j < PP_MAX_NAME - 1)
            name[j++] = *e->p++;
        name[j] = '\0';
        if (has_paren) { pp_expr_ws(e); if (*e->p == ')') e->p++; }
        return pp_defined(e->st, name) ? 1 : 0;
    }

    if (isdigit((unsigned char)c)) {
        char num[32];
        int j = 0;
        while (isalnum((unsigned char)*e->p) && j < (int)sizeof(num) - 1)
            num[j++] = *e->p++;   /* 0x1F, 123, 10L, 30U */
        num[j] = '\0';
        return cdm_strtoll(num, 0);
    }

    if (isalpha((unsigned char)c) || c == '_') {
        char name[PP_MAX_NAME];
        int j = 0;
        while ((isalnum((unsigned char)*e->p) || *e->p == '_') && j < PP_MAX_NAME - 1)
            name[j++] = *e->p++;
        name[j] = '\0';
        int idx = pp_find(e->st, name);
        if (idx >= 0 && e->depth < PP_MAX_DEPTH) {
            PP_Expr_t sub;
            sub.p = e->st->macros[idx].value;
            sub.st = e->st;
            sub.depth = e->depth + 1;
            return pp_expr_bin(&sub, 0);
        }
        return 0;   /* неопределённый идентификатор == 0 (как в C) */
    }
    return 0;
}

static int pp_expr_op(const char* p, int* oplen) {
    /* двухсимвольные операции проверяются раньше односимвольных */
    static const struct { const char* op; int prec; } OPS[] = {
        { "||", 1 }, { "&&", 2 }, { "==", 6 }, { "!=", 6 },
        { "<=", 7 }, { ">=", 7 }, { "<<", 8 }, { ">>", 8 },
        { "|", 3 }, { "^", 4 }, { "&", 5 },
        { "<", 7 }, { ">", 7 }, { "+", 9 }, { "-", 9 },
        { "*", 10 }, { "/", 10 }, { "%", 10 }
    };
    for (int i = 0; i < (int)(sizeof(OPS) / sizeof(OPS[0])); i++) {
        int n = 0;
        while (OPS[i].op[n] && p[n] == OPS[i].op[n]) n++;
        if (OPS[i].op[n] == '\0') { *oplen = n; return OPS[i].prec; }
    }
    *oplen = 0;
    return 0;
}

static int64_t pp_apply_op(const char* op, int64_t l, int64_t r) {
    if (strcmp(op, "||") == 0) return l || r;
    if (strcmp(op, "&&") == 0) return l && r;
    if (strcmp(op, "|") == 0)  return l | r;
    if (strcmp(op, "^") == 0)  return l ^ r;
    if (strcmp(op, "&") == 0)  return l & r;
    if (strcmp(op, "==") == 0) return l == r;
    if (strcmp(op, "!=") == 0) return l != r;
    if (strcmp(op, "<=") == 0) return l <= r;
    if (strcmp(op, ">=") == 0) return l >= r;
    if (strcmp(op, "<") == 0)  return l < r;
    if (strcmp(op, ">") == 0)  return l > r;
    if (strcmp(op, "<<") == 0) return (r >= 0 && r < 64) ? (l << r) : 0;
    if (strcmp(op, ">>") == 0) return (r >= 0 && r < 64) ? (l >> r) : 0;
    if (strcmp(op, "+") == 0)  return l + r;
    if (strcmp(op, "-") == 0)  return l - r;
    if (strcmp(op, "*") == 0)  return l * r;
    if (strcmp(op, "/") == 0)  return r != 0 ? l / r : 0;
    if (strcmp(op, "%") == 0)  return r != 0 ? l % r : 0;
    return 0;
}

static int64_t pp_expr_bin(PP_Expr_t* e, int min_prec) {
    int64_t lhs = pp_expr_primary(e);
    while (1) {
        pp_expr_ws(e);
        int oplen = 0;
        int prec = pp_expr_op(e->p, &oplen);
        if (prec == 0 || prec < min_prec) break;
        char op[4];
        if (oplen > 3) oplen = 3;
        memcpy(op, e->p, (size_t)oplen);
        op[oplen] = '\0';
        e->p += oplen;
        int64_t rhs = pp_expr_bin(e, prec + 1);
        lhs = pp_apply_op(op, lhs, rhs);
    }
    return lhs;
}

static int pp_eval_expr(PP_State_t* s, const char* expr) {
    PP_Expr_t e;
    e.p = expr;
    e.st = s;
    e.depth = 0;
    return pp_expr_bin(&e, 0) != 0;
}

// ============================================================
//  条件栈
// ============================================================
static int pp_active(PP_State_t* s) {
    for (int i = 0; i < s->cond_depth; i++)
        if (!s->cond_stack[i]) return 0;
    return 1;
}

// ============================================================
//  词法辅助
// ============================================================
static const char* parse_word(const char* p, char* out, int out_size) {
    int j = 0;
    while (*p && (isalnum((unsigned char)*p) || *p == '_') && j < out_size - 1)
        out[j++] = *p++;
    out[j] = '\0';
    while (*p == ' ' || *p == '\t') p++;
    return p;
}

// ============================================================
//  ★ Функциональные макросы: сбор аргументов и подстановка
// ============================================================
static void expand_line(PP_State_t* s, const char* line, int depth);

/* Считывает аргументы вызова F(a, b(c, d), "x,y"). *ppos указывает на '('.
 * Возвращает число аргументов; *ppos сдвигается за закрывающую ')'. */
static int pp_collect_args(const char** ppos, char args[][PP_MAX_VALUE], int max_args) {
    const char* p = *ppos;
    int depth = 0, argc = 0, j = 0;

    if (*p != '(') return 0;
    p++;

#define PPARG_PUT(ch) do { if (argc < max_args && j < PP_MAX_VALUE - 1) args[argc][j++] = (ch); } while (0)

    while (*p) {
        if (*p == '"' || *p == '\'') {
            char q = *p;
            PPARG_PUT(*p);
            p++;
            while (*p && *p != q) {
                if (*p == '\\' && *(p + 1)) { PPARG_PUT(*p); p++; }
                PPARG_PUT(*p);
                p++;
            }
            if (*p == q) { PPARG_PUT(*p); p++; }
            continue;
        }
        if (*p == '(') { depth++; PPARG_PUT(*p); p++; continue; }
        if (*p == ')') {
            if (depth == 0) {
                if (argc < max_args) args[argc][j] = '\0';
                argc++;
                p++;
                break;
            }
            depth--;
            PPARG_PUT(*p);
            p++;
            continue;
        }
        if (*p == ',' && depth == 0) {
            if (argc < max_args) args[argc][j] = '\0';
            argc++;
            j = 0;
            p++;
            continue;
        }
        PPARG_PUT(*p);
        p++;
    }
#undef PPARG_PUT
    *ppos = p;
    return argc;
}

/* Подставляет аргументы в тело макроса (учитывая строки/символы),
 * затем рекурсивно раскрывает результат. */
static void pp_expand_func_macro(PP_State_t* s, PP_Macro_t* m,
                                 char args[][PP_MAX_VALUE], int argc, int depth) {
    char buf[PP_MAX_VALUE * 2];
    int j = 0;
    const char* b = m->value;

    while (*b && j < (int)sizeof(buf) - 2) {
        if (*b == '"' || *b == '\'') {
            char q = *b;
            buf[j++] = *b++;
            while (*b && *b != q && j < (int)sizeof(buf) - 2) {
                if (*b == '\\' && *(b + 1)) buf[j++] = *b++;
                buf[j++] = *b++;
            }
            if (*b == q) buf[j++] = *b++;
            continue;
        }
        if (isalpha((unsigned char)*b) || *b == '_') {
            char pname[PP_MAX_NAME];
            int k = 0;
            while ((isalnum((unsigned char)*b) || *b == '_') && k < PP_MAX_NAME - 1)
                pname[k++] = *b++;
            pname[k] = '\0';
            int pi = -1;
            for (int i = 0; i < m->param_count && i < PP_MAX_PARAMS; i++)
                if (strcmp(m->params[i], pname) == 0) { pi = i; break; }
            if (pi >= 0 && pi < argc) {
                const char* a = args[pi];
                while (*a && j < (int)sizeof(buf) - 2) buf[j++] = *a++;
            } else {
                for (int t = 0; pname[t] && j < (int)sizeof(buf) - 2; t++) buf[j++] = pname[t];
            }
            continue;
        }
        buf[j++] = *b++;
    }
    buf[j] = '\0';
    expand_line(s, buf, depth + 1);
}

// ============================================================
//  宏展开 / раскрытие макросов
// ============================================================
static void expand_line(PP_State_t* s, const char* line, int depth) {
    if (depth > PP_MAX_DEPTH) {
        out_append(s, line, -1);
        return;
    }
    const char* p = line;
    while (*p) {
        if (*p == '"') {
            out_append_ch(s, *p++);
            while (*p && *p != '"') {
                if (*p == '\\' && *(p + 1)) {
                    out_append_ch(s, *p++);
                    out_append_ch(s, *p++);
                } else {
                    out_append_ch(s, *p++);
                }
            }
            if (*p == '"') out_append_ch(s, *p++);
            continue;
        }
        if (*p == '\'') {
            out_append_ch(s, *p++);
            while (*p && *p != '\'') {
                if (*p == '\\' && *(p + 1)) {
                    out_append_ch(s, *p++);
                    out_append_ch(s, *p++);
                } else {
                    out_append_ch(s, *p++);
                }
            }
            if (*p == '\'') out_append_ch(s, *p++);
            continue;
        }
        if (*p == '/' && *(p + 1) == '/') {
            out_append(s, p, -1);
            return;
        }
        if (*p == '/' && *(p + 1) == '*') {
            out_append_ch(s, *p++);
            out_append_ch(s, *p++);
            while (*p) {
                if (*p == '*' && *(p + 1) == '/') {
                    out_append_ch(s, *p++);
                    out_append_ch(s, *p++);
                    break;
                }
                out_append_ch(s, *p++);
            }
            continue;
        }
        if (isalpha((unsigned char)*p) || *p == '_') {
            char name[PP_MAX_NAME];
            int j = 0;
            while ((isalnum((unsigned char)*p) || *p == '_') && j < PP_MAX_NAME - 1)
                name[j++] = *p++;
            name[j] = '\0';
            int idx = pp_find(s, name);
            if (idx >= 0) {
                if (s->macros[idx].is_func) {
                    /* функциональный макрос раскрываем только при вызове F(...) */
                    const char* q = p;
                    while (*q == ' ' || *q == '\t') q++;
                    if (*q == '(') {
                        char args[PP_MAX_PARAMS][PP_MAX_VALUE];
                        int na = pp_collect_args(&q, args, PP_MAX_PARAMS);
                        p = q;
                        pp_expand_func_macro(s, &s->macros[idx], args, na, depth);
                    } else {
                        out_append(s, name, -1);
                    }
                } else {
                    expand_line(s, s->macros[idx].value, depth + 1);
                }
            } else {
                out_append(s, name, -1);
            }
            continue;
        }
        out_append_ch(s, *p++);
    }
}

// ============================================================
//  前向声明
// ============================================================
static void pp_process(PP_State_t* s, const char* src, int depth);

// ============================================================
//  处理 #include
// ============================================================
static int handle_include(PP_State_t* s, const char* rest,
                          const char* line_end, int depth) {
    if (!pp_active(s)) return 0;

    const char* q = rest;
    while (q < line_end && (*q == ' ' || *q == '\t')) q++;
    if (q >= line_end) {
        CDM_DBG("[PP] include: missing filename\n");
        return -1;
    }

    char filename[PP_MAX_NAME];
    int j = 0;
    char closer = 0;

    if (*q == '"')       { closer = '"'; q++; }
    else if (*q == '<')  { closer = '>'; q++; }
    else {
        CDM_DBG("[PP] include: expected \"...\" or <...>\n");
        return -1;
    }

    while (q < line_end && *q != closer && j < PP_MAX_NAME - 1)
        filename[j++] = *q++;
    filename[j] = '\0';

    if (j == 0) {
        CDM_DBG("[PP] include: empty filename\n");
        return -1;
    }

    for (int i = 0; i < g_included_count; i++) {
        if (strcmp(g_included[i], filename) == 0) return 0;
    }

    if (!g_include_resolver) {
        CDM_DBG("[PP] include: no resolver set, skipping '%s'\n", filename);
        return -1;
    }

    if (depth >= PP_MAX_DEPTH) {
        CDM_DBG("[PP] include: depth limit reached, skipping '%s'\n", filename);
        return -1;
    }

    char* content = g_include_resolver(filename);
    if (!content) {
        CDM_DBG("[PP] include: failed to load '%s'\n", filename);
        return -1;
    }

    pp_process(s, content, depth + 1);
    free(content);

    if (g_included_count < PP_MAX_INCLUDED) {
        strncpy(g_included[g_included_count], filename, PP_MAX_NAME - 1);
        g_included[g_included_count][PP_MAX_NAME - 1] = '\0';
        g_included_count++;
    } else {
        CDM_DBG("[PP] include: table full, no more tracking\n");
    }
    return 0;
}

// ============================================================
//  ★ #define — общий разбор (объектные и функциональные макросы)
// ============================================================
static void pp_handle_define(PP_State_t* s, const char* rest, const char* line_end) {
    const char* np = rest;
    while (np < line_end && (*np == ' ' || *np == '\t')) np++;

    char name[PP_MAX_NAME];
    int j = 0;
    while (np < line_end && (isalnum((unsigned char)*np) || *np == '_') && j < PP_MAX_NAME - 1)
        name[j++] = *np++;
    name[j] = '\0';
    if (j == 0) return;

    const char* v = np;
    if (np < line_end && *np == '(') {
        /* '(' сразу после имени — функциональный макрос.
         * "#define F (x)" с пробелом — объектный макрос со значением "(x)",
         * как в настоящем C. */
        np++;
        char params[PP_MAX_PARAMS][PP_MAX_PARAM];
        int pcount = 0;
        while (np < line_end && *np != ')') {
            while (np < line_end && (*np == ' ' || *np == '\t')) np++;
            char tmpname[PP_MAX_PARAM];
            int k = 0;
            while (np < line_end && (isalnum((unsigned char)*np) || *np == '_') &&
                   k < PP_MAX_PARAM - 1)
                tmpname[k++] = *np++;
            tmpname[k] = '\0';
            if (k > 0 && pcount < PP_MAX_PARAMS) {
                memcpy(params[pcount], tmpname, (size_t)k + 1);
                pcount++;
            }
            while (np < line_end && (*np == ' ' || *np == '\t')) np++;
            if (np < line_end && *np == ',') np++;
            else break;
        }
        if (np < line_end && *np == ')') np++;
        v = np;
        int vlen = (int)(line_end - v);
        while (vlen > 0 && (v[vlen-1] == ' ' || v[vlen-1] == '\t' || v[vlen-1] == '\r'))
            vlen--;
        char val[PP_MAX_VALUE];
        if (vlen > PP_MAX_VALUE - 1) vlen = PP_MAX_VALUE - 1;
        if (vlen > 0) memcpy(val, v, (size_t)vlen);
        val[vlen] = '\0';
        pp_define_func(s, name, params, pcount, val);
    } else {
        int vlen = (int)(line_end - v);
        while (vlen > 0 && (v[vlen-1] == ' ' || v[vlen-1] == '\t' || v[vlen-1] == '\r'))
            vlen--;
        char val[PP_MAX_VALUE];
        if (vlen > PP_MAX_VALUE - 1) vlen = PP_MAX_VALUE - 1;
        if (vlen > 0) memcpy(val, v, (size_t)vlen);
        val[vlen] = '\0';
        pp_define(s, name, val);
    }
}

// ============================================================
//  处理一段源码 / обработка исходника
// ============================================================
static void pp_process(PP_State_t* s, const char* src, int depth) {
    if (depth > PP_MAX_DEPTH) {
        out_append(s, "/* include depth exceeded */\n", -1);
        return;
    }

    const char* p = src;
    while (*p) {
        const char* line_start = p;
        while (*p && *p != '\n') p++;
        int line_len = (int)(p - line_start);
        if (*p == '\n') p++;

        const char* q = line_start;
        const char* line_end = line_start + line_len;
        while (q < line_end && (*q == ' ' || *q == '\t')) q++;

        if (q < line_end && *q == '#') {
            q++;
            while (q < line_end && (*q == ' ' || *q == '\t')) q++;

            char cmd[32];
            const char* rest = parse_word(q, cmd, sizeof(cmd));

            // ---------------- #define ----------------
            if (strcmp(cmd, "define") == 0) {
                if (pp_active(s)) {
                    pp_handle_define(s, rest, line_end);
                }
                out_append_ch(s, '\n');
            }
            // ---------------- #undef ----------------
            else if (strcmp(cmd, "undef") == 0) {
                if (pp_active(s)) {
                    char name[PP_MAX_NAME];
                    parse_word(rest, name, sizeof(name));
                    pp_undef(s, name);
                }
                out_append_ch(s, '\n');
            }
            // ---------------- #ifdef / #ifndef ----------------
            else if (strcmp(cmd, "ifdef") == 0 || strcmp(cmd, "ifndef") == 0) {
                char name[PP_MAX_NAME];
                parse_word(rest, name, sizeof(name));
                int def = pp_defined(s, name);
                int cond = (cmd[2] == 'n') ? !def : def;
                if (!pp_active(s)) cond = 0;
                pp_push_cond(s, cond);
                out_append_ch(s, '\n');
            }
            // ---------------- ★ #if с выражением ----------------
            else if (strcmp(cmd, "if") == 0) {
                int cond = 0;
                if (pp_active(s)) {
                    char exprbuf[PP_MAX_VALUE];
                    int elen = (int)(line_end - rest);
                    while (elen > 0 && (rest[elen-1] == '\r' || rest[elen-1] == ' ' || rest[elen-1] == '\t'))
                        elen--;
                    if (elen > PP_MAX_VALUE - 1) elen = PP_MAX_VALUE - 1;
                    if (elen < 0) elen = 0;
                    if (elen > 0) memcpy(exprbuf, rest, (size_t)elen);
                    exprbuf[elen] = '\0';
                    cond = pp_eval_expr(s, exprbuf);
                }
                pp_push_cond(s, cond);
                out_append_ch(s, '\n');
            }
            // ---------------- #elif (полноценное выражение) ----------------
            else if (strcmp(cmd, "elif") == 0) {
                if (s->cond_depth > 0) {
                    int top = s->cond_depth - 1;
                    int parent_active = 1;
                    for (int i = 0; i < top; i++)
                        if (!s->cond_stack[i]) { parent_active = 0; break; }

                    if (!parent_active || s->cond_done[top]) {
                        /* родитель неактивен или ветка уже была истинной */
                        s->cond_stack[top] = 0;
                    } else {
                        char exprbuf[PP_MAX_VALUE];
                        int elen = (int)(line_end - rest);
                        while (elen > 0 && (rest[elen-1] == '\r' || rest[elen-1] == ' ' || rest[elen-1] == '\t'))
                            elen--;
                        if (elen > PP_MAX_VALUE - 1) elen = PP_MAX_VALUE - 1;
                        if (elen < 0) elen = 0;
                        if (elen > 0) memcpy(exprbuf, rest, (size_t)elen);
                        exprbuf[elen] = '\0';
                        int r = pp_eval_expr(s, exprbuf);
                        s->cond_stack[top] = r ? 1 : 0;
                        if (r) s->cond_done[top] = 1;
                    }
                }
                out_append_ch(s, '\n');
            }
            // ---------------- #else ----------------
            else if (strcmp(cmd, "else") == 0) {
                if (s->cond_depth > 0) {
                    int top = s->cond_depth - 1;
                    int parent_active = 1;
                    for (int i = 0; i < top; i++)
                        if (!s->cond_stack[i]) { parent_active = 0; break; }
                    if (!parent_active || s->cond_done[top]) {
                        /* родитель неактивен или одна из веток уже сработала */
                        s->cond_stack[top] = 0;
                    } else {
                        s->cond_stack[top] = !s->cond_stack[top];
                        if (s->cond_stack[top]) s->cond_done[top] = 1;
                    }
                }
                out_append_ch(s, '\n');
            }
            // ---------------- #endif ----------------
            else if (strcmp(cmd, "endif") == 0) {
                if (s->cond_depth > 0) s->cond_depth--;
                out_append_ch(s, '\n');
            }
            // ---------------- #include ----------------
            else if (strcmp(cmd, "include") == 0) {
                handle_include(s, rest, line_end, depth);
                out_append_ch(s, '\n');
            }
            // ---------------- #pragma ----------------
            else if (strcmp(cmd, "pragma") == 0) {
                out_append_ch(s, '\n');
            }
            // ---------------- 其它 ----------------
            else {
                out_append_ch(s, '\n');
            }
        }
        else {
            if (pp_active(s) && line_len > 0) {
                char* tmp = (char*)malloc(line_len + 1);
                if (tmp) {
                    memcpy(tmp, line_start, line_len);
                    tmp[line_len] = '\0';
                    expand_line(s, tmp, 0);
                    free(tmp);
                }
            }
            out_append_ch(s, '\n');
        }
    }
}

// ============================================================
//  主入口
// ============================================================
char* CDM_Preprocess(const char* src) {
    CDM_ResetIncludes();

    PP_State_t* s = (PP_State_t*)calloc(1, sizeof(PP_State_t));
    if (!s) return NULL;

    out_init(s);
    if (!s->out) { free(s); return NULL; }

    pp_process(s, src, 0);

    char* result = s->out;
    free(s);
    return result;
}

/* ========================================================================
 *  Begin section: CDM_STD.cpp
 * ======================================================================== */


// ============================================================
//  Обёртки значений — только val_* семейство (mk_f/mk_i и
//  as_double/as_int/as_str были дубликатами make_*/val_*)
// ============================================================
#define STD1(name, expr) \
    static CDM_Value_t std_##name(int argc, CDM_Value_t* argv) { \
        double x = argc >= 1 ? val_to_double(argv[0]) : 0.0; \
        (void)x; return make_float(expr); \
    }
#define STD2(name, expr) \
    static CDM_Value_t std_##name(int argc, CDM_Value_t* argv) { \
        double a = argc >= 1 ? val_to_double(argv[0]) : 0.0; \
        double b = argc >= 2 ? val_to_double(argv[1]) : 0.0; \
        (void)a; (void)b; return make_float(expr); \
    }

STD1(sqrt,  sqrt(x))
STD1(sin,   sin(x))
STD1(cos,   cos(x))
STD1(tan,   tan(x))
STD1(asin,  asin(x))
STD1(acos,  acos(x))
STD1(atan,  atan(x))
STD1(floor, floor(x))
STD1(ceil,  ceil(x))
STD1(round, round(x))
STD1(fabs,  fabs(x))
STD1(exp,   exp(x))
STD1(log,   log(x))
STD1(log10, log10(x))
STD1(log2,  log2(x))
STD2(atan2, atan2(a, b))
STD2(fmod,  fmod(a, b))
STD2(pow,   pow(a, b))
STD2(min,   a < b ? a : b)
STD2(max,   a > b ? a : b)

static CDM_Value_t std_abs(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(0);
    CDM_Value_t v = CDM_Deref(argv[0]);
    if (v.type == CDM_TYPE_INT) {
        int64_t x = v.v.i;
        return make_int(x < 0 ? -x : x);
    }
    return make_float(fabs(val_to_double(v)));
}
static CDM_Value_t std_rand(int argc, CDM_Value_t* argv) { (void)argc; (void)argv; return make_int(rand()); }
static CDM_Value_t std_srand(int argc, CDM_Value_t* argv) {
    if (argc >= 1) srand((unsigned)val_to_int(argv[0]));
    return make_int(0);
}

// ============================================================
//  std::string 构造
// ============================================================
static CDM_Value_t std_string_ctor(int argc, CDM_Value_t* argv) {
    if (argc < 1) return CDM_MakeString("");
    CDM_Value_t v = CDM_Deref(argv[0]);
    if (v.type == CDM_TYPE_STRING) return CDM_MakeString(val_to_str_raw(v));
    if (v.type == CDM_TYPE_FLOAT) {
        char buf[64]; snprintf(buf, sizeof(buf), "%g", v.v.f);
        return CDM_MakeString(buf);
    }
    if (v.type == CDM_TYPE_INT) {
        char buf[64]; snprintf(buf, sizeof(buf), "%lld", (long long)v.v.i);
        return CDM_MakeString(buf);
    }
    return CDM_MakeString("");
}

// ============================================================
//  std::string 方法
// ============================================================
static CDM_Value_t str_length(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(0);
    return make_int((int64_t)strlen(val_to_str(argv[0])));
}
static CDM_Value_t str_empty(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(1);
    return make_int(strlen(val_to_str(argv[0])) == 0);
}
static CDM_Value_t str_substr(int argc, CDM_Value_t* argv) {
    const char* s = argc >= 1 ? val_to_str(argv[0]) : "";
    int slen = (int)strlen(s);
    int pos = argc >= 2 ? (int)val_to_int(argv[1]) : 0;
    int len = argc >= 3 ? (int)val_to_int(argv[2]) : slen - pos;
    if (pos < 0) pos = 0;
    if (pos > slen) pos = slen;
    if (len < 0) len = 0;
    if (pos + len > slen) len = slen - pos;
    char* buf = (char*)malloc(len + 1);
    if (!buf) return CDM_MakeString("");
    memcpy(buf, s + pos, len);
    buf[len] = '\0';
    return CDM_MakeStringOwned(buf);
}
static CDM_Value_t str_find(int argc, CDM_Value_t* argv) {
    const char* s = argc >= 1 ? val_to_str(argv[0]) : "";
    const char* needle = argc >= 2 ? val_to_str(argv[1]) : "";
    const char* p = strstr(s, needle);
    return make_int(p ? (int64_t)(p - s) : -1);
}
static CDM_Value_t str_append(int argc, CDM_Value_t* argv) {
    const char* a = argc >= 1 ? val_to_str(argv[0]) : "";
    const char* b = argc >= 2 ? val_to_str(argv[1]) : "";
    size_t la = strlen(a), lb = strlen(b);
    char* buf = (char*)malloc(la + lb + 1);
    if (!buf) return CDM_MakeString("");
    memcpy(buf, a, la);
    memcpy(buf + la, b, lb);
    buf[la + lb] = '\0';
    return CDM_MakeStringOwned(buf);
}
static CDM_Value_t str_replace(int argc, CDM_Value_t* argv) {
    const char* s = argc >= 1 ? val_to_str(argv[0]) : "";
    int pos = argc >= 2 ? (int)val_to_int(argv[1]) : 0;
    int len = argc >= 3 ? (int)val_to_int(argv[2]) : 0;
    const char* repl = argc >= 4 ? val_to_str(argv[3]) : "";
    int slen = (int)strlen(s);
    int rlen = (int)strlen(repl);
    if (pos < 0) pos = 0;
    if (pos > slen) pos = slen;
    if (len < 0) len = 0;
    if (pos + len > slen) len = slen - pos;
    int new_len = slen - len + rlen;
    char* buf = (char*)malloc(new_len + 1);
    if (!buf) return CDM_MakeString("");
    memcpy(buf, s, pos);
    memcpy(buf + pos, repl, rlen);
    memcpy(buf + pos + rlen, s + pos + len, slen - pos - len);
    buf[new_len] = '\0';
    return CDM_MakeStringOwned(buf);
}
static CDM_Value_t str_trim(int argc, CDM_Value_t* argv) {
    const char* s = argc >= 1 ? val_to_str(argv[0]) : "";
    while (*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') s++;
    int len = (int)strlen(s);
    while (len > 0 && (s[len-1] == ' ' || s[len-1] == '\t' || s[len-1] == '\n' || s[len-1] == '\r')) len--;
    char* buf = (char*)malloc(len + 1);
    if (!buf) return CDM_MakeString("");
    memcpy(buf, s, len);
    buf[len] = '\0';
    return CDM_MakeStringOwned(buf);
}
static CDM_Value_t str_c_str(int argc, CDM_Value_t* argv) {
    if (argc < 1) return CDM_MakeString("");
    return CDM_MakeString(val_to_str(argv[0]));
}
static CDM_Value_t str_at(int argc, CDM_Value_t* argv) {
    const char* s = argc >= 1 ? val_to_str(argv[0]) : "";
    int i = argc >= 2 ? (int)val_to_int(argv[1]) : 0;
    int slen = (int)strlen(s);
    if (i < 0 || i >= slen) return CDM_MakeString("");
    char buf[2] = { s[i], '\0' };
    return CDM_MakeString(buf);
}

// ============================================================
//  全局字符串函数
// ============================================================
static CDM_Value_t std_strlen(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(0);
    return make_int((int64_t)strlen(val_to_str(argv[0])));
}
static CDM_Value_t std_strcmp(int argc, CDM_Value_t* argv) {
    if (argc < 2) return make_int(0);
    return make_int(strcmp(val_to_str(argv[0]), val_to_str(argv[1])));
}
static CDM_Value_t std_strcpy(int argc, CDM_Value_t* argv) {
    if (argc < 2) return CDM_MakeString("");
    if (CDM_IsRef(argv[0])) {
        CDM_Value_t v = CDM_MakeString(val_to_str(argv[1]));
        CDM_AssignRef(argv[0], v);
        return v;
    }
    return CDM_MakeString(val_to_str(argv[1]));
}
static CDM_Value_t std_strcat(int argc, CDM_Value_t* argv) {
    if (argc < 2) return CDM_MakeString("");
    const char* a = val_to_str(argv[0]);
    const char* b = val_to_str(argv[1]);
    size_t la = strlen(a), lb = strlen(b);
    char* buf = (char*)malloc(la + lb + 1);
    if (!buf) return CDM_MakeString("");
    memcpy(buf, a, la);
    memcpy(buf + la, b, lb);
    buf[la + lb] = '\0';
    CDM_Value_t res = CDM_MakeStringOwned(buf);
    if (CDM_IsRef(argv[0])) CDM_AssignRef(argv[0], res);
    return res;
}

/* strncpy(dst, src, n) — dst должен быть REF. set_string_slot
 * заменяет ручной паттерн "free + MakeStringOwned". */
static CDM_Value_t std_strncpy(int argc, CDM_Value_t* argv) {
    if (argc < 3) return CDM_MakeString("");
    const char* src = val_to_str(argv[1]);
    int n = (int)val_to_int(argv[2]);
    if (n <= 0) return CDM_MakeString("");

    size_t sl = strlen(src);
    size_t copy_len = (sl < (size_t)n) ? sl : (size_t)n;
    char* buf = (char*)malloc(copy_len + 1);
    if (!buf) return CDM_MakeString("");
    memcpy(buf, src, copy_len);
    buf[copy_len] = '\0';

    if (CDM_IsRef(argv[0])) {
        CDM_Value_t* slot = CDM_RefPtr(argv[0]);
        if (slot && slot->type == CDM_TYPE_STRING) {
            set_string_slot(slot, buf);
            free(buf);
            CDM_Value_t ret = *slot; ret.owned = 0;
            return ret;
        }
    }
    return CDM_MakeStringOwned(buf);
}

/* strncmp(a, b, n) */
static CDM_Value_t std_strncmp(int argc, CDM_Value_t* argv) {
    if (argc < 3) return make_int(0);
    int n = (int)val_to_int(argv[2]);
    if (n < 0) n = 0;
    return make_int(strncmp(val_to_str(argv[0]), val_to_str(argv[1]), (size_t)n));
}

/* strchr(s, c) — возвращает позицию, если не найдено — -1 */
static CDM_Value_t std_strchr(int argc, CDM_Value_t* argv) {
    if (argc < 2) return make_int(-1);
    const char* s = val_to_str(argv[0]);
    char c = (char)val_to_int(argv[1]);
    const char* p = strchr(s, c);
    return make_int(p ? (int64_t)(p - s) : -1);
}

// ============================================================
//  数值转换
// ============================================================
static CDM_Value_t std_atoi(int argc, CDM_Value_t* argv) {
    /* val_to_int использует cdm_atoll — работает и без libc. Раньше здесь
     * был atoll, который без CDM_HAS_STDLIB превращался в заглушку 0LL,
     * и std::atoi("123") возвращала 0. */
    return make_int(argc >= 1 ? val_to_int(argv[0]) : 0);
}
static CDM_Value_t std_atof(int argc, CDM_Value_t* argv) {
    return make_float(argc >= 1 ? val_to_double(argv[0]) : 0.0);
}
static CDM_Value_t std_to_string(int argc, CDM_Value_t* argv) {
    if (argc < 1) return CDM_MakeString("");
    CDM_Value_t v = CDM_Deref(argv[0]);
    if (v.type == CDM_TYPE_STRING) return CDM_MakeString(val_to_str_raw(v));
    if (v.type == CDM_TYPE_FLOAT) {
        char buf[64]; snprintf(buf, sizeof(buf), "%g", v.v.f);
        return CDM_MakeString(buf);
    }
    char buf[64]; snprintf(buf, sizeof(buf), "%lld", (long long)v.v.i);
    return CDM_MakeString(buf);
}

// ============================================================
//  格式化器
// ============================================================
static char* fmt_impl(const char* fmt, CDM_Value_t* argv, int argc, int first_arg_idx) {
    int cap = 128;
    char* out = (char*)malloc(cap);
    if (!out) return NULL;
    int len = 0;
    int argi = first_arg_idx;

    for (const char* p = fmt; *p; p++) {
        if (len + 64 > cap) {
            int new_cap = cap * 2;
            char* n = (char*)realloc(out, new_cap);
            if (!n) { free(out); return NULL; }
            out = n;
            cap = new_cap;
        }
        if (*p != '%') { out[len++] = *p; continue; }
        p++;
        if (*p == '\0') { out[len++] = '%'; break; }
        if (*p == '%') { out[len++] = '%'; continue; }
        while (*p && (*p == '-' || *p == '+' || *p == ' ' || *p == '#' || *p == '0')) p++;
        if (*p == '*') p++;
        else while (*p && isdigit((unsigned char)*p)) p++;
        if (*p == '.') {
            p++;
            if (*p == '*') p++;
            else while (*p && isdigit((unsigned char)*p)) p++;
        }
        while (*p && (*p == 'h' || *p == 'l' || *p == 'L' ||
                      *p == 'q' || *p == 'j' || *p == 'z' || *p == 't')) p++;
        char spec = *p;
        if (!spec) { out[len++] = '%'; break; }

        CDM_Value_t v = (argi < argc) ? CDM_Deref(argv[argi]) : make_int(0);
        argi++;

        char buf[64];
        int n = 0;
        switch (spec) {
            case 'd': case 'i':
                n = snprintf(buf, sizeof(buf), "%lld", (long long)val_to_int(v));
                break;
            case 'u':
                n = snprintf(buf, sizeof(buf), "%llu", (unsigned long long)val_to_int(v));
                break;
            case 'x':
                n = snprintf(buf, sizeof(buf), "%llx", (unsigned long long)val_to_int(v));
                break;
            case 'X':
                n = snprintf(buf, sizeof(buf), "%llX", (unsigned long long)val_to_int(v));
                break;
            case 'o':
                n = snprintf(buf, sizeof(buf), "%llo", (unsigned long long)val_to_int(v));
                break;
            case 'f': case 'e': case 'E': case 'g': case 'G':
                n = snprintf(buf, sizeof(buf), "%g", val_to_double(v));
                break;
            case 'c':
                n = snprintf(buf, sizeof(buf), "%c", (char)val_to_int(v));
                break;
            case 's': {
                const char* s = val_to_str(v);
                while (*s) {
                    if (len + 1 >= cap) {
                        int new_cap = cap * 2;
                        char* nn = (char*)realloc(out, new_cap);
                        if (!nn) { free(out); return NULL; }
                        out = nn;
                        cap = new_cap;
                    }
                    out[len++] = *s++;
                }
                continue;
            }
            case 'p':
                n = snprintf(buf, sizeof(buf), "%p", v.v.p);
                break;
            default:
                if (len + 2 >= cap) {
                    int new_cap = cap * 2;
                    char* nn = (char*)realloc(out, new_cap);
                    if (!nn) { free(out); return NULL; }
                    out = nn;
                    cap = new_cap;
                }
                out[len++] = '%';
                out[len++] = spec;
                continue;
        }
        if (n > 0) {
            if (len + n + 1 > cap) {
                int new_cap = len + n + 32;
                char* nn = (char*)realloc(out, new_cap);
                if (!nn) { free(out); return NULL; }
                out = nn;
                cap = new_cap;
            }
            memcpy(out + len, buf, n);
            len += n;
        }
    }
    out[len] = '\0';
    return out;
}

// ---- sprintf / snprintf / printf: общее ядро (отличались только maxlen
// и обрезкой; запись в REF-слот через set_string_slot) ----
static CDM_Value_t std_format_common(int argc, CDM_Value_t* argv,
                                     int fmt_idx, int maxlen) {
    const char* fmt = val_to_str(argv[fmt_idx]);
    char* result = fmt_impl(fmt, argv, argc, fmt_idx + 1);
    if (!result) return CDM_MakeString("");
    if (maxlen > 0 && (int)strlen(result) >= maxlen) result[maxlen - 1] = '\0';

    if (CDM_IsRef(argv[0])) {
        CDM_Value_t* slot = CDM_RefPtr(argv[0]);
        if (slot && slot->type == CDM_TYPE_STRING) {
            set_string_slot(slot, result);
            free(result);
            CDM_Value_t ret = *slot;
            ret.owned = 0;
            return ret;
        }
    }
    return CDM_MakeStringOwned(result);
}

static CDM_Value_t std_sprintf(int argc, CDM_Value_t* argv) {
    return argc < 2 ? CDM_MakeString("") : std_format_common(argc, argv, 1, 0);
}

static CDM_Value_t std_snprintf(int argc, CDM_Value_t* argv) {
    if (argc < 3) return CDM_MakeString("");
    int maxlen = (int)val_to_int(argv[1]);
    if (maxlen <= 0) return CDM_MakeString("");
    return std_format_common(argc, argv, 2, maxlen);
}

static CDM_Value_t std_printf(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(0);
    const char* fmt = val_to_str(argv[0]);
    char* result = fmt_impl(fmt, argv, argc, 1);
    if (!result) return make_int(-1);
    int n = (int)strlen(result);
    fputs(result, stdout);
    free(result);
    return make_int(n);
}

// ============================================================
//  文件 IO
//  用法：
//    auto fp = fopen("/littlefs/foo.txt", "w");
//    if (fp) { fprintf(fp, "hello %d\n", 42); fclose(fp); }
// ============================================================
static FILE* as_filep(CDM_Value_t v) {
    v = CDM_Deref(v);
    if (v.type != CDM_TYPE_PTR || !v.v.p) return NULL;
    return (FILE*)v.v.p;
}

static CDM_Value_t std_fopen(int argc, CDM_Value_t* argv) {
    if (argc < 2) return make_int(0);
    const char* path = val_to_str(argv[0]);
    const char* mode = val_to_str(argv[1]);
    FILE* fp = fopen(path, mode);
    if (!fp) {
        CDM_DBG("[fopen] failed: %s (mode=%s)\n", path, mode);
        return make_int(0);
    }
    return CDM_MakePtr(fp, 0);   /* FILE* закрывает fclose, CDM не освобождает */
}

static CDM_Value_t std_fclose(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(-1);
    FILE* fp = as_filep(argv[0]);
    if (!fp) return make_int(-1);
    return make_int(fclose(fp));
}

static CDM_Value_t std_fprintf(int argc, CDM_Value_t* argv) {
    if (argc < 2) return make_int(-1);
    FILE* fp = as_filep(argv[0]);
    if (!fp) return make_int(-1);
    const char* fmt = val_to_str(argv[1]);
    char* text = fmt_impl(fmt, argv, argc, 2);
    if (!text) return make_int(-1);
    int r = fputs(text, fp);
    free(text);
    return make_int(r);
}

static CDM_Value_t std_fputs(int argc, CDM_Value_t* argv) {
    if (argc < 2) return make_int(-1);
    const char* s = val_to_str(argv[0]);
    FILE* fp = as_filep(argv[1]);
    if (!fp) return make_int(-1);
    return make_int(fputs(s, fp));
}

/* fgets(buf, n, fp) — buf это REF (std::string) */
static CDM_Value_t std_fgets(int argc, CDM_Value_t* argv) {
    if (argc < 3) return CDM_MakeString("");
    int n = (int)val_to_int(argv[1]);
    if (n <= 0 || n > 4096) n = 256;
    FILE* fp = as_filep(argv[2]);
    if (!fp) return CDM_MakeString("");

    char* tmp = (char*)malloc((size_t)n);
    if (!tmp) return CDM_MakeString("");
    char* r = fgets(tmp, n, fp);
    if (!r) { free(tmp); return CDM_MakeString(""); }

    /* убираем завершающий перевод строки */
    size_t L = strlen(tmp);
    if (L > 0 && tmp[L-1] == '\n') tmp[L-1] = '\0';

    if (CDM_IsRef(argv[0])) {
        CDM_Value_t* slot = CDM_RefPtr(argv[0]);
        if (slot && slot->type == CDM_TYPE_STRING) {
            set_string_slot(slot, tmp);
            free(tmp);
            CDM_Value_t ret = *slot;
            ret.owned = 0;
            return ret;
        }
    }
    return CDM_MakeStringOwned(tmp);
}

static CDM_Value_t std_feof(int argc, CDM_Value_t* argv) {
    if (argc < 1) return make_int(1);
    FILE* fp = as_filep(argv[0]);
    if (!fp) return make_int(1);
    return make_int(feof(fp));
}

static CDM_Value_t std_fread(int argc, CDM_Value_t* argv) {
    if (argc < 3) return make_int(0);
    FILE* fp = as_filep(argv[2]);
    if (!fp) return make_int(0);
    int n = (int)val_to_int(argv[1]);
    if (n <= 0 || n > 4096) n = 256;
    char* tmp = (char*)malloc((size_t)n + 1);
    if (!tmp) return make_int(0);
    size_t got = fread(tmp, 1, (size_t)n, fp);
    tmp[got] = '\0';
    if (CDM_IsRef(argv[0])) {
        CDM_Value_t* slot = CDM_RefPtr(argv[0]);
        if (slot && slot->type == CDM_TYPE_STRING) {
            set_string_slot(slot, tmp);
            free(tmp);
            CDM_Value_t ret = *slot;
            ret.owned = 0;
            return ret;
        }
    }
    return CDM_MakeStringOwned(tmp);
}

static CDM_Value_t std_fwrite(int argc, CDM_Value_t* argv) {
    if (argc < 2) return make_int(0);
    const char* s = val_to_str(argv[0]);
    FILE* fp = as_filep(argv[1]);
    if (!fp) return make_int(0);
    size_t n = strlen(s);
    return make_int((int64_t)fwrite(s, 1, n, fp));
}

// ============================================================
//  Регистрация: таблица вместо ~50 почти одинаковых строк.
//  Псевдонимы (sprintf / std::sprintf) — просто ещё одна строка.
// ============================================================
typedef struct { const char* name; CDM_HostFuncEx_t fn; } StdEntry_t;

static const StdEntry_t g_std_entries[] = {
    /* математика */
    {"std::sqrt",  std_sqrt},  {"std::sin",   std_sin},
    {"std::cos",   std_cos},   {"std::tan",   std_tan},
    {"std::asin",  std_asin},  {"std::acos",  std_acos},
    {"std::atan",  std_atan},  {"std::atan2", std_atan2},
    {"std::floor", std_floor}, {"std::ceil",  std_ceil},
    {"std::round", std_round}, {"std::fabs",  std_fabs},
    {"std::fmod",  std_fmod},  {"std::pow",   std_pow},
    {"std::exp",   std_exp},   {"std::log",   std_log},
    {"std::log10", std_log10}, {"std::log2",  std_log2},
    {"std::abs",   std_abs},   {"std::min",   std_min},
    {"std::max",   std_max},
    {"std::rand",  std_rand},  {"std::srand", std_srand},
    {"std::string", std_string_ctor},
    /* методы std::string */
    {"std::string.length", str_length}, {"std::string.size",    str_length},
    {"std::string.empty",  str_empty},  {"std::string.substr",  str_substr},
    {"std::string.find",   str_find},   {"std::string.append",  str_append},
    {"std::string.replace", str_replace}, {"std::string.trim",  str_trim},
    {"std::string.c_str",  str_c_str},  {"std::string.at",      str_at},
    /* строки C */
    {"std::strlen", std_strlen}, {"std::strcmp", std_strcmp},
    {"std::strcpy", std_strcpy}, {"std::strcat", std_strcat},
    {"std::atoi",   std_atoi},   {"std::atof",   std_atof},
    {"std::to_string", std_to_string},
    {"std::strncpy", std_strncpy}, {"std::strncmp", std_strncmp},
    {"std::strchr",  std_strchr},
    {"strncpy", std_strncpy}, {"strncmp", std_strncmp}, {"strchr", std_strchr},
    /* форматирование */
    {"sprintf",   std_sprintf}, {"snprintf",  std_snprintf},
    {"printf",    std_printf},
    {"std::sprintf", std_sprintf}, {"std::snprintf", std_snprintf},
    {"std::printf",  std_printf},
    /* файлы */
    {"fopen", std_fopen},  {"fclose", std_fclose}, {"fprintf", std_fprintf},
    {"fputs", std_fputs},  {"fgets",  std_fgets},  {"feof",    std_feof},
    {"fread", std_fread},  {"fwrite", std_fwrite},
    {"std::fopen", std_fopen},  {"std::fclose", std_fclose},
    {"std::fprintf", std_fprintf}, {"std::fputs", std_fputs},
    {"std::fgets", std_fgets},  {"std::feof", std_feof},
    {"std::fread", std_fread},  {"std::fwrite", std_fwrite}
};

void CDM_Std_Init(void) {
    for (int i = 0; i < (int)(sizeof(g_std_entries) / sizeof(g_std_entries[0])); i++)
        CDM_RegisterHostFuncEx(g_std_entries[i].name, g_std_entries[i].fn);
}

/* ========================================================================
 *  Begin section: CDM_ArduinoBridge.cpp
 * ======================================================================== */

#if CDM_HAS_ARDUINO
/* Arduino-specific helpers -- disabled on x86. */
/* Provide an Arduino.h shim and define CDM_HAS_ARDUINO=1 */
/* to re-enable them. Original implementations kept for */
/* reference inside this #if block. */
static int arg_int(int argc, const char** argv, int idx) {
    if (idx < 0 || idx >= argc || !argv[idx]) return 0;
    return atoi(argv[idx]);
}

static int ar_pinMode(int argc, const char** argv)      { if (argc<2) return -1; pinMode(arg_int(argc,argv,0),arg_int(argc,argv,1)); return 0; }
static int ar_digitalWrite(int argc, const char** argv) { if (argc<2) return -1; digitalWrite(arg_int(argc,argv,0),arg_int(argc,argv,1)); return 0; }
static int ar_digitalRead(int argc, const char** argv)  { if (argc<1) return 0; return digitalRead(arg_int(argc,argv,0)); }
static int ar_analogWrite(int argc, const char** argv)  { if (argc<2) return -1; analogWrite(arg_int(argc,argv,0),arg_int(argc,argv,1)); return 0; }
static int ar_analogRead(int argc, const char** argv)   { if (argc<1) return 0; return analogRead(arg_int(argc,argv,0)); }
static int ar_delay(int argc, const char** argv)        { if (argc<1) return -1; delay((unsigned long)arg_int(argc,argv,0)); return 0; }
static int ar_millis(int argc, const char** argv)       { (void)argc; (void)argv; return (int)millis(); }
static int ar_micros(int argc, const char** argv)       { (void)argc; (void)argv; return (int)micros(); }

// ★ 新增
static int ar_delayMicroseconds(int argc, const char** argv) {
    if (argc < 1) return -1;
    delayMicroseconds((unsigned int)arg_int(argc, argv, 0));
    return 0;
}

// ★ 新增：Arduino map() 整数版
static int ar_map(int argc, const char** argv) {
    if (argc < 5) return 0;
    long x      = (long)arg_int(argc, argv, 0);
    long in_min = (long)arg_int(argc, argv, 1);
    long in_max = (long)arg_int(argc, argv, 2);
    long out_min= (long)arg_int(argc, argv, 3);
    long out_max= (long)arg_int(argc, argv, 4);
    return (int)map(x, in_min, in_max, out_min, out_max);
}

// ★ 新增：constrain
static int ar_constrain(int argc, const char** argv) {
    if (argc < 3) return 0;
    long x  = (long)arg_int(argc, argv, 0);
    long lo = (long)arg_int(argc, argv, 1);
    long hi = (long)arg_int(argc, argv, 2);
    if (x < lo) return (int)lo;
    if (x > hi) return (int)hi;
    return (int)x;
}

// 读取 int
static int ar_read_int(int argc, const char** argv) {
    (void)argc; (void)argv;
    while (Serial.available() <= 0) delay(10);
    return Serial.parseInt();
}

// 读取 float（把 bit pattern 装进 int 返回）
static int ar_read_float(int argc, const char** argv) {
    (void)argc; (void)argv;
    while (Serial.available() <= 0) delay(10);
    float f = Serial.parseFloat();
    int32_t bits;
    memcpy(&bits, &f, sizeof(bits));
    return (int)bits;
}


#endif /* CDM_HAS_ARDUINO */

void CDM_ArduinoBridge_Init(void) {
#if CDM_HAS_ARDUINO
    /* On Arduino targets the original library registers pinMode, */
    /* digitalWrite, delay, millis, etc. here. On a custom x86 OS */
    /* we leave this empty -- register your own host functions. */
    /* If you have an Arduino.h-compatible shim, you can paste the */
    /* original body back here. */
#endif
}

/* ========================================================================
 *  Begin section: CMScript.cpp
 * ======================================================================== */


void CMScript_Init(void) {
    CDM_ArduinoBridge_Init();
    CDM_Std_Init();
}

/* ========================================================================
 *  End of cmscript.c
 * ========================================================================
 *  Public API summary (see also original CMScript.h):
 *
 *    void              CMScript_Init(void);
 *    char*             CDM_Preprocess(const char* src);
 *    ASTNode_t*        CDM_Parse(const char* src);
 *    int               CDM_Execute(ASTNode_t* root);
 *    void              CDM_FreeAST(ASTNode_t* root);
 *    void              CDM_ClearErrors(void);
 *    int               CDM_GetErrorCount(void);
 *    const CDM_Error_t* CDM_GetError(int idx);
 *
 *    void CDM_RegisterHostFunc(const char* name, CDM_HostFunc_t fn);
 *    void CDM_RegisterHostFuncFloat(const char* name, CDM_HostFunc_t fn);
 *    void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn);
 *
 *    void CDM_SetIncludeResolver(CDM_IncludeResolver_t fn);
 *    void CDM_ResetIncludes(void);
 *
 *    CDM_Value_t CDM_MakeString(const char* s);
 *    CDM_Value_t CDM_MakeStringOwned(char* s);
 *    CDM_Value_t CDM_MakePtr(void* p, int owned);
 *    int          CDM_IsRef(CDM_Value_t v);
 *    CDM_Value_t  CDM_Deref(CDM_Value_t v);
 *    CDM_Value_t* CDM_RefPtr(CDM_Value_t v);
 *    void         CDM_AssignRef(CDM_Value_t ref, CDM_Value_t value);
 *
 *  Minimal usage:
 *
 *    static int my_print(int argc, const char** argv) {
 *        if (argc >= 1) my_os_puts(argv[0]);
 *        return 0;
 *    }
 *
 *    void run_script(const char* src) {
 *        CMScript_Init();
 *        CDM_RegisterHostFunc("__print_str",   my_print);
 *        CDM_RegisterHostFunc("__print_int",   my_print);
 *        CDM_RegisterHostFunc("__print_float", my_print);
 *
 *        char* pre = CDM_Preprocess(src);
 *        ASTNode_t* root = CDM_Parse(pre);
 *        cdm_free(pre);           // or free() if your libc has it
 *        if (root && CDM_GetErrorCount() == 0) {
 *            CDM_Execute(root);
 *        }
 *        if (root) CDM_FreeAST(root);
 *    }
 * ======================================================================== */
#endif /* CMSCRIPT_SINGLE_FILE_C */
