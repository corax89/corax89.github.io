/* cmscript.h — заголовок для встроенного CMScript интерпретатора.
 *
 * CMScript — скриптовый язык от SUNSETDEVER (Apache-2.0), портирован
 * под freestanding N2600-OS. Регистрирует host-функции для доступа
 * к API ОС: окна, кнопки, файлы, графика.
 *
 * API для .cs-скриптов:
 *   print(str)              — вывод текста в окно вывода
 *   print_int(n)            — вывод числа
 *   screen_width()          — ширина экрана
 *   screen_height()          — высота экрана
 *   fill_rect(x,y,w,h,c)    — заливка прямоугольника
 *   draw_text(x,y,str,color) — вывод текста
 *   get_color(r,g,b)        — получить цвет
 *   clear_screen(color)      — очистка экрана
 *   flip()                   — перерисовка экрана
 *   delay(ms)                — задержка
 *   uptime()                 — время работы в секундах
 */
#ifndef CMSCRIPT_H
#define CMSCRIPT_H

#include "types.h"

/* Запустить .cs-скрипт. Возвращает 0 при успехе, -1 при ошибке.
 * src     — NUL-terminated исходник.
 * out     — буфер под вывод (print/print_int).
 * out_max — размер буфера out. */
int cmscript_run(const char *src, char *out, u32 out_max);

#endif /* CMSCRIPT_H */
