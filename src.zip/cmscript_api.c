/* cmscript_api.c — мост между CMScript и API N2600-OS.
 *
 * Регистрирует host-функции, доступные из .cs-скриптов:
 *   print(str)              — вывод текста
 *   print_int(n)            — вывод числа
 *   screen_width()          — ширина экрана
 *   screen_height()          — высота экрана
 *   fill_rect(x,y,w,h,c)    — заливка прямоугольника
 *   draw_text(x,y,str,color) — вывод текста
 *   get_color(r,g,b)        — получить цвет
 *   clear_screen(color)      — очистка экрана
 *   flip()                   — перерисовка экрана
 *   delay(ms)                — задержка
 *   uptime()                 — время работы в секундах
 *   file_read(name, buf, max) — чтение файла из RAMFS
 */
#include "cmscript.h"
#include "sync.h"
#include "types.h"
#include "mem.h"
#include "string.h"
#include "fb.h"
#include "timer.h"
#include "task.h"
#include "ramfs.h"

/* CMScript internal types — объявлены в cmscript.c */
#define CDM_TYPE_INT     1
#define CDM_TYPE_FLOAT   2
#define CDM_TYPE_VOID    0
#define CDM_TYPE_STRING  5

typedef struct {
    int type;
    int struct_id;
    int array_len;
    int array_dim;
    int array_sizes[4];
    int array_elem_type;
    int array_elem_struct_id;
    int owned;
    int from_new;
    union {
        long long i;
        double f;
        void *p;
    } v;
} CDM_Value_t;

typedef CDM_Value_t (*CDM_HostFuncEx_t)(int argc, CDM_Value_t* argv);
extern void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn);
extern void *CDM_Parse(const char* source);
extern int CDM_Execute(void *root);
extern void CDM_FreeAST(void *root);
extern int CDM_GetErrorCount(void);
extern void CDM_ClearErrors(void);

/* Выводной буфер — заполняется host-функциями print/print_int */
static char *g_cs_out = 0;
static u32   g_cs_out_pos = 0;
static u32   g_cs_out_max = 0;

static void cs_putc(char c) {
    if (g_cs_out_pos + 1 < g_cs_out_max)
        g_cs_out[g_cs_out_pos++] = c;
}
static void cs_puts(const char *s) {
    while (*s) cs_putc(*s++);
}
static void cs_putint(int v) {
    char b[12]; int i = 0;
    if (v < 0) { cs_putc('-'); v = -v; }
    if (v == 0) { cs_putc('0'); return; }
    while (v) { b[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) cs_putc(b[i]);
}

static CDM_Value_t make_int(int v) {
    CDM_Value_t r;
    memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT;
    r.v.i = v;
    return r;
}

/* ---------- Host-функции для .cs-скриптов ---------- */

static CDM_Value_t cs_print(int argc, CDM_Value_t* argv) {
    (void)argc;
    if (argv[0].type == CDM_TYPE_STRING && argv[0].v.p)
        cs_puts((const char*)argv[0].v.p);
    return make_int(0);
}

static CDM_Value_t cs_print_int(int argc, CDM_Value_t* argv) {
    (void)argc;
    if (argv[0].type == CDM_TYPE_INT)
        cs_putint((int)argv[0].v.i);
    else if (argv[0].type == CDM_TYPE_STRING && argv[0].v.p)
        cs_puts((const char*)argv[0].v.p);
    return make_int(0);
}

static CDM_Value_t cs_screen_width(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    return make_int((int)fb_width());
}

static CDM_Value_t cs_screen_height(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    return make_int((int)fb_height());
}

static CDM_Value_t cs_fill_rect(int argc, CDM_Value_t* argv) {
    (void)argc;
    fb_fill_rect((int)argv[3].v.i, (int)argv[2].v.i, (int)argv[1].v.i, (int)argv[0].v.i,
                 (u32)argv[4].v.i);
    return make_int(0);
}

static CDM_Value_t cs_draw_text(int argc, CDM_Value_t* argv) {
    (void)argc;
    if (argv[2].type == CDM_TYPE_STRING && argv[2].v.p)
        fb_text((int)argv[3].v.i, (int)argv[2].v.i,
                (const char*)argv[2].v.p,
                (u32)argv[1].v.i, -1);
    return make_int(0);
}

static CDM_Value_t cs_get_color(int argc, CDM_Value_t* argv) {
    (void)argc;
    return make_int((int)fb_rgb((u8)argv[2].v.i, (u8)argv[1].v.i, (u8)argv[0].v.i));
}

static CDM_Value_t cs_clear_screen(int argc, CDM_Value_t* argv) {
    (void)argc;
    fb_fill_screen((u32)argv[0].v.i);
    return make_int(0);
}

static CDM_Value_t cs_flip(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    fb_touch_all();
    fb_flush();
    return make_int(0);
}

static CDM_Value_t cs_delay(int argc, CDM_Value_t* argv) {
    (void)argc;
    u32 start = timer_ticks();
    u32 need = (u32)argv[0].v.i / 10;
    while (timer_ticks() - start < need) task_yield();
    return make_int(0);
}

static CDM_Value_t cs_uptime(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    return make_int((int)uptime_sec());
}

static CDM_Value_t cs_strlen(int argc, CDM_Value_t* argv) {
    (void)argc;
    if (argv[0].type == CDM_TYPE_STRING && argv[0].v.p)
        return make_int((int)strlen((const char*)argv[0].v.p));
    return make_int(0);
}

static CDM_Value_t cs_malloc(int argc, CDM_Value_t* argv) {
    (void)argc;
    void *p = malloc((u32)argv[0].v.i);
    CDM_Value_t r = make_int(0);
    r.v.p = p;
    return r;
}

static CDM_Value_t cs_free(int argc, CDM_Value_t* argv) {
    (void)argc;
    free(argv[0].v.p);
    return make_int(0);
}

static CDM_Value_t cs_memset(int argc, CDM_Value_t* argv) {
    (void)argc;
    memset(argv[2].v.p, (int)argv[1].v.i, (u32)argv[0].v.i);
    return make_int(0);
}

static CDM_Value_t cs_memcmp(int argc, CDM_Value_t* argv) {
    (void)argc;
    return make_int(memcmp(argv[2].v.p, argv[1].v.p, (u32)argv[0].v.i));
}

static CDM_Value_t cs_ramfs_read(int argc, CDM_Value_t* argv) {
    (void)argc;
    if (argv[2].type == CDM_TYPE_STRING && argv[2].v.p) {
        int n = (int)ramfs_read((const char*)argv[2].v.p, argv[1].v.p, (u32)argv[0].v.i);
        return make_int(n);
    }
    return make_int(0);
}

static CDM_Value_t cs_ramfs_write(int argc, CDM_Value_t* argv) {
    (void)argc;
    if (argv[3].type == CDM_TYPE_STRING && argv[3].v.p) {
        ramfs_delete((const char*)argv[3].v.p);
        if (ramfs_create((const char*)argv[3].v.p, (u32)(argv[2].v.i + 1))) {
            ramfs_write((const char*)argv[3].v.p, argv[1].v.p, (u32)(argv[2].v.i + 1));
            return make_int(1);
        }
    }
    return make_int(0);
}

static CDM_Value_t cs_ramfs_list(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    /* TODO: list files */
    return make_int(0);
}

/* ---------- Регистрация host-функций ---------- */

static void cs_register_all(void) {
    CDM_RegisterHostFuncEx("print",       cs_print);
    CDM_RegisterHostFuncEx("print_int",   cs_print_int);
    CDM_RegisterHostFuncEx("screen_width", cs_screen_width);
    CDM_RegisterHostFuncEx("screen_height", cs_screen_height);
    CDM_RegisterHostFuncEx("fill_rect",   cs_fill_rect);
    CDM_RegisterHostFuncEx("draw_text",   cs_draw_text);
    CDM_RegisterHostFuncEx("get_color",   cs_get_color);
    CDM_RegisterHostFuncEx("clear_screen", cs_clear_screen);
    CDM_RegisterHostFuncEx("flip",        cs_flip);
    CDM_RegisterHostFuncEx("delay",       cs_delay);
    CDM_RegisterHostFuncEx("uptime",      cs_uptime);
    CDM_RegisterHostFuncEx("strlen",      cs_strlen);
    CDM_RegisterHostFuncEx("malloc",      cs_malloc);
    CDM_RegisterHostFuncEx("free",        cs_free);
    CDM_RegisterHostFuncEx("memset",      cs_memset);
    CDM_RegisterHostFuncEx("memcmp",      cs_memcmp);
    CDM_RegisterHostFuncEx("ramfs_read",  cs_ramfs_read);
    CDM_RegisterHostFuncEx("ramfs_write", cs_ramfs_write);
    CDM_RegisterHostFuncEx("ramfs_list",  cs_ramfs_list);
}

/* ---------- Публичный API ---------- */

/* FIX (многозадачность): интерпретатор CMScript — на глобалах
 * (g_cs_out и VM). Вызывается задачей запуска (cs_run_task), а таких
 * может быть несколько одновременно. Обёртка сериализует. */
static volatile int cms_run_lock = 0;

int cmscript_run(const char *src, char *out, u32 out_max);
static int cmscript_run_impl(const char *src, char *out, u32 out_max);

int cmscript_run(const char *src, char *out, u32 out_max) {
    int rc;
    s_lock(&cms_run_lock);
    rc = cmscript_run_impl(src, out, out_max);
    s_unlock(&cms_run_lock);
    return rc;
}

static int cmscript_run_impl(const char *src, char *out, u32 out_max) {
    g_cs_out = out;
    g_cs_out_pos = 0;
    g_cs_out_max = out_max;
    if (out && out_max) out[0] = 0;

    cs_register_all();
    CDM_ClearErrors();

    void *ast = CDM_Parse(src);
    if (!ast) {
        if (out && out_max > 0) {
            const char *err = "CMScript: parse error\n";
            int n = (int)strlen(err);
            if (n >= (int)out_max) n = (int)out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        return -1;
    }

    if (CDM_GetErrorCount() > 0) {
        if (out && out_max > 0) {
            const char *err = "CMScript: parse errors detected\n";
            int n = (int)strlen(err);
            if (n >= (int)out_max) n = (int)out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        CDM_FreeAST(ast);
        return -1;
    }

    int ret = CDM_Execute(ast);
    CDM_FreeAST(ast);

    if (g_cs_out && g_cs_out_pos < g_cs_out_max)
        g_cs_out[g_cs_out_pos] = 0;

    return ret;
}
