#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <msettings.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <libgen.h>
#include <time.h>
#include <sys/stat.h>
#include <sched.h>
#include <errno.h>
#include <zlib.h>
#include <arm_neon.h>
#include <dirent.h>

#define TJE_IMPLEMENTATION
#include "tiny_jpeg.h"
#include "libretro.h"
#include "defines.h"
#include "api.h"
#include "utils.h"
#include "animated_list.h"
#include "cpu.h"
#include "scaler.h"
#include "minarchconfig.h"

extern int last_integer_scale; 
extern float last_aspect;
static ListAnimation menu_animation;
static volatile int screenshot_requested = 0;
static volatile int save_state_requested = 0;
static volatile int load_state_requested = 0;
static volatile int reset_requested = 0;
static volatile int cycle_scale_requested = 0;
static volatile int rewind_activation_requested = 0;
static volatile int rewind_holding = 0;
static pthread_mutex_t rewind_global_mutex;
static int rewind_global_mutex_initialized = 0;
static int disable_sound_init = 0;

///////////////////////////////////////

void set_debug_text(const char* text);
extern void PLAT_showPopup(const char* text);
extern void PLAT_clearPopup(void);
extern int PLAT_isPopupActive(void);
extern int PLAT_getPopupRemainingTime(void);

static int frame_counter_skip = 0;   // счётчик кадров для скипа
static int quit;
static int show_menu;
static int simple_mode = 0;

//static int has_custom_controllers = 0;
static int gamepad_type = 0; // index in gamepad_labels/gamepad_values
static int downsample = 0; // set to 1 to convert from 8888 to 565

char file_name[256];
char file_path[256];
char txt_path[512];

static void localize_frontend_options(void) {
	onoff_labels[0] = (char*)language_get_string("OFF");
	onoff_labels[1] = (char*)language_get_string("ON");
	onoff_labels[2] = NULL;
	// --- FE_OPT_SCALING ---
	config.frontend.options[FE_OPT_SCALING].name = language_get_string("SCREEN_SCALING");
#ifdef CROP_OVERSCAN
	config.frontend.options[FE_OPT_SCALING].desc = language_get_string("INFO_SCREEN_SCALING"); // Если нужно — можно сделать отдельный ключ для CROP
#else
	config.frontend.options[FE_OPT_SCALING].desc = language_get_string("INFO_SCREEN_SCALING");
#endif

	// --- FE_OPT_SHARPNESS ---
	config.frontend.options[FE_OPT_SHARPNESS].name = language_get_string("SCREEN_SHARPNESS");
	config.frontend.options[FE_OPT_SHARPNESS].desc = language_get_string("INFO_SCREEN_SHARPNESS");

	// --- FE_OPT_DEBUG ---
	config.frontend.options[FE_OPT_DEBUG].name = language_get_string("DEBUG_HUD");
	config.frontend.options[FE_OPT_DEBUG].desc = ""; 

	// --- FE_OPT_MAXFF ---
	config.frontend.options[FE_OPT_MAXFF].name = language_get_string("MAX_FF_SPEED");
	config.frontend.options[FE_OPT_MAXFF].desc = language_get_string("INFO_SCREEN_MAX_FF_SPEED");

	// --- FE_OPT_CPU_CORES ---
	config.frontend.options[FE_OPT_CPU_CORES].name = language_get_string("CPU_CORES");
	config.frontend.options[FE_OPT_CPU_CORES].desc = "";

	// --- FE_OPT_THREAD ---
	config.frontend.options[FE_OPT_THREAD].name = language_get_string("THREAD_CORE"); 
	config.frontend.options[FE_OPT_THREAD].desc = language_get_string("INFO_THREAD_CORE");
	
	config.frontend.options[FE_OPT_REWIND].name = language_get_string("REWIND");
	config.frontend.options[FE_OPT_REWIND].desc = language_get_string("INFO_REWIND");
	
	// --- FE_OPT_THREAD ---
	thread_labels[0] = (char*)language_get_string("OFF");
	thread_labels[1] = (char*)language_get_string("ON");
	thread_labels[2] = NULL;
	config.frontend.options[FE_OPT_THREAD].labels = thread_labels;
	
	// --- FE_OPT_DEBUG ---
	debug_labels[0] = (char*)language_get_string("DEBUG_OFF");
	debug_labels[1] = (char*)language_get_string("DEBUG_FPS");
	debug_labels[2] = (char*)language_get_string("DEBUG_BAT");
	debug_labels[3] = (char*)language_get_string("DEBUG_FPS_BAT");
	debug_labels[4] = (char*)language_get_string("DEBUG_FPS_BAT_CPU");
	debug_labels[5] = NULL;
	config.frontend.options[FE_OPT_DEBUG].labels = debug_labels;
	
	// --- FE_OPT_SCALING ---
	scaling_labels[0] = (char*)language_get_string("SCALING_NATIVE");
	scaling_labels[1] = (char*)language_get_string("SCALING_ASPECT");
	scaling_labels[2] = (char*)language_get_string("SCALING_FULLSCREEN");
	#ifdef CROP_OVERSCAN
	scaling_labels[3] = (char*)language_get_string("SCALING_CROPPED");
	scaling_labels[4] = NULL;
	#else
	scaling_labels[3] = NULL;
	#endif
	config.frontend.options[FE_OPT_SCALING].labels = scaling_labels;
	
	// --- FE_OPT_FRAMESKIP ---
	config.frontend.options[FE_OPT_FRAMESKIP].name = language_get_string("FRAME_SKIP");
	config.frontend.options[FE_OPT_FRAMESKIP].desc = language_get_string("INFO_FRAME_SKIP");
	config.frontend.options[FE_OPT_FRAMESKIP].labels = onoff_labels; // используем уже существующие "Off"/"On"
	// --- FE_OPT_RENDER_MODE ---
	config.frontend.options[FE_OPT_RENDER_MODE].name = language_get_string("RENDER_MODE");
	config.frontend.options[FE_OPT_RENDER_MODE].desc = language_get_string("INFO_RENDER_MODE");
	
	render_mode_labels[0] = (char*)language_get_string("RENDER_SDL");
	render_mode_labels[1] = (char*)language_get_string("RENDER_FRAMEBUFFER");
	render_mode_labels[2] = NULL;
	config.frontend.options[FE_OPT_RENDER_MODE].labels = render_mode_labels;

	// Локализуем метки
	const char* sharpness_keys[] = {
    	"SHARP",
    	"CRISP",
    	"SOFT",
    	"FAST",
    	"CRT1",
    	"CRT2",
    	"CRT3",
    	"NOISE",
    	"SCALE2X",
    	NULL
	};
	
	for (int i = 0; i < ARRAY_SIZE(sharpness_values); i++) {
    	sharpness_labels[i] = (char*)language_get_string(sharpness_keys[i]);
	}
	sharpness_labels[ARRAY_SIZE(sharpness_values)] = NULL;
	
	config.frontend.options[FE_OPT_SHARPNESS].labels = sharpness_labels;
	config.frontend.options[FE_OPT_REWIND].labels = onoff_labels;
	config.frontend.options[FE_OPT_THREAD].labels = onoff_labels;
}

static void generate_preview_frame_to_buffer(
    uint16_t* out_buf, int out_w, int out_h,
    const void* full_frame, int src_w, int src_h, int pitch)
{
    if (!out_buf || !full_frame || out_w <= 0 || out_h <= 0) return;

    const uint16_t* src = (const uint16_t*)full_frame;
    uint16_t* dst = out_buf;
    int src_pitch_pixels = pitch / sizeof(uint16_t);

    for (int y = 0; y < out_h; y++) {
        int src_y1 = MIN(y * 2, src_h - 1);
        int src_y2 = MIN(src_y1 + 1, src_h - 1);
        for (int x = 0; x < out_w; x++) {
            int src_x1 = MIN(x * 2, src_w - 1);
            int src_x2 = MIN(src_x1 + 1, src_w - 1);

            uint16_t p1 = src[src_y1 * src_pitch_pixels + src_x1];
            uint16_t p2 = src[src_y1 * src_pitch_pixels + src_x2];
            uint16_t p3 = src[src_y2 * src_pitch_pixels + src_x1];
            uint16_t p4 = src[src_y2 * src_pitch_pixels + src_x2];

            uint32_t r = ((p1 >> 11) & 0x1F) + ((p2 >> 11) & 0x1F) +
                         ((p3 >> 11) & 0x1F) + ((p4 >> 11) & 0x1F);
            uint32_t g = ((p1 >> 5) & 0x3F) + ((p2 >> 5) & 0x3F) +
                         ((p3 >> 5) & 0x3F) + ((p4 >> 5) & 0x3F);
            uint32_t b = (p1 & 0x1F) + (p2 & 0x1F) +
                         (p3 & 0x1F) + (p4 & 0x1F);

            r = (r + 2) >> 2;
            g = (g + 2) >> 2;
            b = (b + 2) >> 2;

            *dst++ = ((r & 0x1F) << 11) | ((g & 0x3F) << 5) | (b & 0x1F);
        }
    }
}

static void Rewind_saveFrame(void) {
    if (!core.serialize_size || !core.serialize) return;
    if (!renderer.src || renderer.true_w == 0 || renderer.true_h == 0) return;

    // 🔒 ГЛОБАЛЬНАЯ БЛОКИРОВКА для безопасной работы с буфером
    pthread_mutex_lock(&rewind_global_mutex);

    // 🔒 ПАУЗИМ ЯДРО ЭМУЛЯЦИИ НА ВРЕМЯ СОХРАНЕНИЯ
    int was_paused = coreThreadPaused;
    if (!was_paused && thread_video) {
        pthread_mutex_lock(&core_mx);
        coreThreadPaused = 1;
        should_run_core = 0;
        pthread_mutex_unlock(&core_mx);
        
        // Ждем завершения текущего кадра
        usleep(16666); // ~1 кадр при 60FPS
    }

    // === ИНИЦИАЛИЗАЦИЯ БУФЕРА (один раз) ===
    if (!rewind_initialized) {
        size_t state_size = core.serialize_size();
        if (state_size == 0) {
            LOG_error("serialize_size returned 0 — disabling rewind\n");
            rewind_enabled = 0;
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }

        int preview_w = (renderer.true_w + 1) >> 1;
        int preview_h = (renderer.true_h + 1) >> 1;
        size_t preview_size = (size_t)preview_w * preview_h * 2;
        size_t slot_size = state_size + preview_size;
        const size_t memory_limit = 50 * 1024 * 1024; // 50MB
        
        rewind_buffer_size = (int)(memory_limit / slot_size);
        if (rewind_buffer_size < 2) {
            LOG_warn("Not enough memory for rewind buffer — disabling\n");
            rewind_enabled = 0;
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }
        if (rewind_buffer_size > 120) rewind_buffer_size = 120;

        // Выделяем память для буфера
        rewind_buffer = calloc(rewind_buffer_size, sizeof(RewindFrame));
        if (!rewind_buffer) {
            LOG_error("Failed to allocate rewind buffer\n");
            rewind_enabled = 0;
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }
        
        // Выделяем память для мьютексов слотов
        rewind_slot_mutexes = calloc(rewind_buffer_size, sizeof(pthread_mutex_t));
        if (!rewind_slot_mutexes) {
            LOG_error("Failed to allocate slot mutexes\n");
            free(rewind_buffer);
            rewind_buffer = NULL;
            rewind_enabled = 0;
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }

        for (int i = 0; i < rewind_buffer_size; i++) {
            // Инициализируем мьютекс слота
            pthread_mutex_init(&rewind_slot_mutexes[i], NULL);
            
            // Выделяем память для данных состояния
            rewind_buffer[i].data = malloc(state_size);
            if (!rewind_buffer[i].data) {
                LOG_error("Failed to allocate state buffer for slot %d\n", i);
                rewind_enabled = 0;
                break;
            }
            
            // Выделяем память для превью
            rewind_buffer[i].preview = malloc(preview_size);
            if (!rewind_buffer[i].preview) {
                LOG_error("Failed to allocate preview buffer for slot %d\n", i);
                free(rewind_buffer[i].data);
                rewind_enabled = 0;
                break;
            }
            
            rewind_buffer[i].size = state_size;
            rewind_buffer[i].preview_w = preview_w;
            rewind_buffer[i].preview_h = preview_h;
        }

        if (!rewind_enabled) {
            // Освобождаем все выделенные ресурсы
            for (int i = 0; i < rewind_buffer_size; i++) {
                if (rewind_buffer[i].data) free(rewind_buffer[i].data);
                if (rewind_buffer[i].preview) free(rewind_buffer[i].preview);
                if (rewind_slot_mutexes) pthread_mutex_destroy(&rewind_slot_mutexes[i]);
            }
            free(rewind_buffer);
            free(rewind_slot_mutexes);
            rewind_buffer = NULL;
            rewind_slot_mutexes = NULL;
            rewind_buffer_size = 0;
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }

        // 🔥 Правильная инициализация индексов
		rewind_start = 0;
		rewind_index = 0;  // Следующий свободный слот
		rewind_count = 0;  // Количество заполненных слотов
		
		LOG_info("Rewind buffer initialized: size=%d, start=%d, index=%d\n",
				 rewind_buffer_size, rewind_start, rewind_index);
		
		rewind_initialized = 1;
    }

    // Проверяем валидность индекса
    if (rewind_index < 0 || rewind_index >= rewind_buffer_size) {
        pthread_mutex_unlock(&rewind_global_mutex);
        goto resume_and_exit;
    }

    // === СОХРАНЕНИЕ СОСТОЯНИЯ ===
    RewindFrame* slot = &rewind_buffer[rewind_index];
    
    // 🔒 Блокируем этот конкретный слот на время записи
    pthread_mutex_lock(&rewind_slot_mutexes[rewind_index]);
    
    // Проверяем, что размер состояния не изменился
    size_t current_state_size = core.serialize_size();
    if (slot->size != current_state_size) {
        LOG_warn("State size changed (%zu -> %zu), reallocating\n", 
                 slot->size, current_state_size);
        
        // Проверяем, не используется ли этот слот для чтения
        int slot_in_use = 0;
        for (int i = 0; i < rewind_count; i++) {
            int idx = (rewind_start + i) % rewind_buffer_size;
            if (idx == rewind_index) {
                slot_in_use = 1;
                break;
            }
        }
        
        if (slot_in_use) {
            LOG_error("Cannot reallocate slot %d - it's in use!\n", rewind_index);
            pthread_mutex_unlock(&rewind_slot_mutexes[rewind_index]);
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }
        
        // Освобождаем старый буфер и выделяем новый
        free(slot->data);
        free(slot->preview);
        
        slot->data = malloc(current_state_size);
        if (!slot->data) {
            LOG_error("Failed to reallocate state buffer\n");
            pthread_mutex_unlock(&rewind_slot_mutexes[rewind_index]);
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }
        
        int preview_w = (renderer.true_w + 1) >> 1;
        int preview_h = (renderer.true_h + 1) >> 1;
        size_t preview_size = (size_t)preview_w * preview_h * 2;
        
        slot->preview = malloc(preview_size);
        if (!slot->preview) {
            LOG_error("Failed to reallocate preview buffer\n");
            free(slot->data);
            slot->data = NULL;
            pthread_mutex_unlock(&rewind_slot_mutexes[rewind_index]);
            pthread_mutex_unlock(&rewind_global_mutex);
            goto resume_and_exit;
        }
        
        slot->size = current_state_size;
        slot->preview_w = preview_w;
        slot->preview_h = preview_h;
    }

    // Сохраняем состояние (ядро уже остановлено)
    if (!core.serialize(slot->data, slot->size)) {
        LOG_warn("Failed to serialize state\n");
        pthread_mutex_unlock(&rewind_slot_mutexes[rewind_index]);
        pthread_mutex_unlock(&rewind_global_mutex);
        goto resume_and_exit;
    }

    // 🔥 Барьер памяти для гарантии видимости данных
    __sync_synchronize();

    // === ГЕНЕРАЦИЯ ПРЕВЬЮ ===
    // Защищаем доступ к renderer.src на время копирования
    pthread_mutex_lock(&renderer_mutex);
    generate_preview_frame_to_buffer(
        slot->preview, slot->preview_w, slot->preview_h,
        renderer.src, renderer.true_w, renderer.true_h, renderer.src_p
    );
    pthread_mutex_unlock(&renderer_mutex);
    
    // 🔥 Еще один барьер после генерации превью
    __sync_synchronize();

    // 🔓 Разблокируем слот
    pthread_mutex_unlock(&rewind_slot_mutexes[rewind_index]);

    // === ОБНОВЛЕНИЕ БУФЕРА (под глобальной блокировкой) ===
    if (rewind_count == rewind_buffer_size) {
        rewind_start = (rewind_start + 1) % rewind_buffer_size;
    } else {
        rewind_count++;
    }
    rewind_index = (rewind_start + rewind_count) % rewind_buffer_size;
    
    LOG_debug("Rewind frame saved: %d/%d\n", rewind_count, rewind_buffer_size);
    
    // 🔓 Разблокируем глобальный мьютекс
    pthread_mutex_unlock(&rewind_global_mutex);

resume_and_exit:
    // 🔓 ВОЗОБНОВЛЯЕМ ЯДРО ЭМУЛЯЦИИ
    if (!was_paused && thread_video) {
        pthread_mutex_lock(&core_mx);
        coreThreadPaused = 0;
        should_run_core = 1;
        pthread_cond_signal(&core_rq);
        pthread_mutex_unlock(&core_mx);
    }
}

static int Rewind_loadFrameByIndex(int steps_back) {
    // Проверяем базовые условия
    if (!rewind_enabled || !rewind_buffer || rewind_count == 0) {
        LOG_info("Rewind: not enabled or no frames\n");
        return 0;
    }
    
    if (steps_back < 0 || steps_back >= rewind_count) {
        LOG_info("Rewind: invalid steps_back %d (count=%d)\n", steps_back, rewind_count);
        return 0;
    }

    // 🔒 Глобальная блокировка для безопасного доступа к индексам
    pthread_mutex_lock(&rewind_global_mutex);
    
    // ВАЖНО: перемотка идет от новых к старым
    // rewind_selected = 0 - самый новый кадр
    // rewind_selected = rewind_count-1 - самый старый кадр
    
    // Правильный расчет индекса в буфере
    int timeline_index = steps_back; // steps_back = 0 - последний сохраненный, 1 - предпоследний и т.д.
    
    if (timeline_index < 0 || timeline_index >= rewind_count) {
        LOG_error("Rewind: timeline_index %d out of range (count=%d)\n", 
                  timeline_index, rewind_count);
        pthread_mutex_unlock(&rewind_global_mutex);
        return 0;
    }
    
    // Вычисляем индекс в кольцевом буфере
    // Самый новый кадр находится по индексу (rewind_index - 1) или (rewind_start + rewind_count - 1)
    int buffer_index = (rewind_start + timeline_index) % rewind_buffer_size;
    
    LOG_info("Rewind: loading timeline_index=%d, buffer_index=%d (start=%d, count=%d)\n",
             timeline_index, buffer_index, rewind_start, rewind_count);
    
    // Проверяем валидность индекса
    if (buffer_index < 0 || buffer_index >= rewind_buffer_size) {
        LOG_error("Rewind: buffer_index %d out of range (size=%d)\n", 
                  buffer_index, rewind_buffer_size);
        pthread_mutex_unlock(&rewind_global_mutex);
        return 0;
    }
    
    RewindFrame* frame = &rewind_buffer[buffer_index];
    
    // Блокируем слот для чтения
    pthread_mutex_lock(&rewind_slot_mutexes[buffer_index]);
    pthread_mutex_unlock(&rewind_global_mutex); // Можно отпустить глобальную
    
    if (!frame->data || frame->size == 0) {
        LOG_error("Rewind: frame %d has no data\n", buffer_index);
        pthread_mutex_unlock(&rewind_slot_mutexes[buffer_index]);
        return 0;
    }
    
    // 🔥 Барьер памяти перед чтением
    __sync_synchronize();
    
    // Сохраняем текущее состояние на случай отката
    static void* backup_state = NULL;
    static size_t backup_size = 0;
    
    if (!backup_state) {
        backup_size = core.serialize_size();
        if (backup_size > 0) {
            backup_state = malloc(backup_size);
        }
    }
    
    // Сохраняем текущее состояние перед загрузкой
    int backup_ok = 0;
    if (backup_state && backup_size == core.serialize_size()) {
        backup_ok = core.serialize(backup_state, backup_size);
    }
    
    // Пробуем загрузить
    int success = core.unserialize(frame->data, frame->size);
    
    if (!success) {
        LOG_error("Rewind: failed to unserialize frame %d\n", buffer_index);
        if (backup_ok) {
            // Откатываемся если загрузка не удалась
            core.unserialize(backup_state, backup_size);
            LOG_warn("Rewind: restored backup after failed load\n");
        }
    }
    
    if (success) {
        LOG_info("Rewind: successfully loaded frame %d\n", buffer_index);
        
        // 🔒 Обновляем индексы под глобальной блокировкой
        pthread_mutex_lock(&rewind_global_mutex);
        
        // После загрузки кадра, мы "отматываем" на steps_back+1 кадров назад
        // Уменьшаем количество доступных кадров
        rewind_count = steps_back + 1;
        if (rewind_count < 0) rewind_count = 0;
        
        // Обновляем индекс для следующего сохранения
        rewind_index = (rewind_start + rewind_count) % rewind_buffer_size;
        
        LOG_info("Rewind: new count=%d, new index=%d\n", rewind_count, rewind_index);
        
        pthread_mutex_unlock(&rewind_global_mutex);
    }
    
    // 🔓 Разблокируем слот
    pthread_mutex_unlock(&rewind_slot_mutexes[buffer_index]);
    return success;
}

static void Rewind_loadFrame(void) {
    if (rewind_count == 0) {
        LOG_info("No rewind frames available\n");
        return;
    }

    int prev_index = (rewind_index - 1 + rewind_buffer_size) % rewind_buffer_size;
    while (rewind_count > 0 && !rewind_buffer[prev_index].data) {
        rewind_count--;
        rewind_index = prev_index;
        prev_index = (rewind_index - 1 + rewind_buffer_size) % rewind_buffer_size;
    }

    if (!rewind_buffer[prev_index].data) return;

    RewindFrame* frame = &rewind_buffer[prev_index];
    if (core.unserialize(frame->data, frame->size)) {
        LOG_info("Rewind: loaded frame %d\n", prev_index);
        rewind_index = prev_index;
        rewind_count = MAX(0, rewind_count - 1);
    }
}

static void cleanup_threads(void) {
    quit = 1;
    
    // 🔒 Останавливаем сохранение кадров перемотки
    rewind_enabled = 0;
    
    // Ждем завершения всех операций с перемоткой
    if (rewind_global_mutex_initialized) {
        pthread_mutex_lock(&rewind_global_mutex);
    }
    
    // Сигнализируем всем потокам о завершении
    pthread_mutex_lock(&core_mx);
    should_run_core = 0;
    coreThreadPaused = 0;
    pthread_cond_signal(&core_rq);
    pthread_mutex_unlock(&core_mx);
    
    // Ждем завершения потока ядра
    pthread_join(core_pt, NULL);
    
    // Освобождаем ресурсы перемотки
    if (rewind_buffer) {
        for (int i = 0; i < rewind_buffer_size; i++) {
            free(rewind_buffer[i].data);
            free(rewind_buffer[i].preview);
            if (rewind_slot_mutexes) {
                pthread_mutex_destroy(&rewind_slot_mutexes[i]);
            }
        }
        free(rewind_buffer);
        free(rewind_slot_mutexes);
        rewind_buffer = NULL;
        rewind_slot_mutexes = NULL;
        rewind_buffer_size = 0;
        rewind_initialized = 0;
    }
    
    if (rewind_global_mutex_initialized) {
        pthread_mutex_unlock(&rewind_global_mutex);
        pthread_mutex_destroy(&rewind_global_mutex);
        rewind_global_mutex_initialized = 0;
    }
    
    // Уничтожаем мьютексы и условные переменные
    pthread_mutex_destroy(&core_mx);
    pthread_cond_destroy(&core_rq);
}

static void pause_core_thread(void) {
    pthread_mutex_lock(&core_mx);
    coreThreadPaused = 1;
    should_run_core = 0;
    pthread_mutex_unlock(&core_mx);
}

static void resume_core_thread(void) {
    pthread_mutex_lock(&core_mx);
    coreThreadPaused = 0;
    should_run_core = 1;
    pthread_cond_signal(&core_rq);
    pthread_mutex_unlock(&core_mx);
}

static void* coreThread(void *arg) {
    LOG_info("coreThread started on cpu %i\n", sched_getcpu());
    coreThreadStarted = 1;
    coreThreadPaused = 0;

    while (!quit) {
        pthread_mutex_lock(&core_mx);
        while ((!should_run_core || coreThreadPaused) && !quit) {
            struct timespec ts;
            clock_gettime(CLOCK_REALTIME, &ts);
            ts.tv_sec += 1;
            pthread_cond_timedwait(&core_rq, &core_mx, &ts);
        }
        int run = should_run_core && !coreThreadPaused;
        pthread_mutex_unlock(&core_mx);

        if (run && !quit) {
            core.run();
            limitFF();

            // 🔥 Сохраняем кадр для перемотки — ТОЛЬКО если включено и не в меню
            if (rewind_enabled && !rewind_ui_active && !show_menu) {
                static uint32_t last_save = 0;
                uint32_t now = SDL_GetTicks();
                if (now - last_save >= REWIND_INTERVAL_MS) {
                    Rewind_saveFrame(); // ← вызывается в потоке ядра!
                    last_save = now;
                }
            }

            // Сигнализируем основному потоку, что можно запускать core снова
            pthread_mutex_lock(&core_mx);
            pthread_cond_signal(&core_rq);
            pthread_mutex_unlock(&core_mx);
        } else {
            usleep(1000);
        }
    }

    coreThreadStarted = 0;
    LOG_info("coreThread exiting\n");
    pthread_exit(NULL);
}

// 🔥 ДОБАВЬТЕ эту функцию для однопоточного режима:
static void handle_rewind_in_single_thread(void) {
    if (!rewind_enabled || rewind_ui_active || show_menu || !config_load_done) 
        return;
    
    static uint32_t last_save = 0;
    uint32_t now = SDL_GetTicks();
    
    if (now - last_save >= REWIND_INTERVAL_MS) {
        // В однопоточном режиме сохраняем прямо в основном потоке
        Rewind_saveFrame();
        last_save = now;
    }
}

static void toggle_threading(int enable) {
    static int initialized = 0;
    
    if (enable == thread_video && initialized) {
        LOG_info("Многопоточность уже в состоянии: %d\n", enable);
        return;
    }
    
    LOG_info("Переключение многопоточности с %d на %d\n", thread_video, enable);
    
    // ВАЖНО: Восстанавливаем оригинальный vsync режим
    int original_vsync = prevent_tearing;
    
    if (enable) {
        // ===== ВКЛЮЧЕНИЕ МНОГОПОТОЧНОСТИ =====
        
        // 1. Разблокируем потоки
        pthread_mutex_lock(&core_mx);
        should_run_core = 1;
        coreThreadPaused = 0;
        pthread_cond_signal(&core_rq);
        pthread_mutex_unlock(&core_mx);
        
        // 2. Даем время на инициализацию
        usleep(100000); // 100ms
        
        LOG_info("Многопоточность ВКЛЮЧЕНА\n");
        
    } else {
        // ===== ВЫКЛЮЧЕНИЕ МНОГОПОТОЧНОСТИ =====
        
        // 1. Блокируем потоки
        pthread_mutex_lock(&core_mx);
        should_run_core = 0;
        coreThreadPaused = 1;
        pthread_cond_signal(&core_rq);
        pthread_mutex_unlock(&core_mx);
        
        
        // 2. Ждем завершения текущих операций
        int timeout = 200;
        while (timeout-- > 0) {
            usleep(1000);
        }
        
        // 3. Очищаем экран
        GFX_clearAll();
        GFX_flip(screen);
        
        LOG_info("Многопоточность ВЫКЛЮЧЕНА\n");
    }
    
    thread_video = enable;
    initialized = 1;
    
    // Восстанавливаем оригинальный vsync режим
    if (prevent_tearing != original_vsync) {
        LOG_info("Восстанавливаем оригинальный vsync: %d\n", original_vsync);
        prevent_tearing = original_vsync;
        GFX_setVsync(original_vsync);
    }
}

// Конвертация RGB565 -> RGB888 (оптимизированная)
static void rgb565_to_rgb888(const uint16_t* src, unsigned char* dst, int width, int height, int src_pitch_pixels) {
    // src_pitch_pixels - pitch в количестве пикселей (не байтах)
    
    for (int y = 0; y < height; y++) {
        const uint16_t* src_row = src + (y * src_pitch_pixels);
        unsigned char* dst_row = dst + (y * width * 3);
        
        for (int x = 0; x < width; x++) {
            uint16_t pixel = src_row[x];
            
            // Быстрая конвертация RGB565 -> RGB888
            dst_row[x*3]   = ((pixel >> 8) & 0xF8) | ((pixel >> 13) & 0x07);
            dst_row[x*3+1] = ((pixel >> 3) & 0xFC) | ((pixel >> 9) & 0x03);
            dst_row[x*3+2] = ((pixel << 3) & 0xF8) | ((pixel >> 2) & 0x07);
        }
    }
}

// Функция сохранения JPEG через Tiny JPEG Encoder
static int save_as_jpeg_tje(SDL_Surface* surface, const char* filename, int quality) {
    if (!surface || !filename) {
        LOG_error("Invalid parameters for JPEG save\n");
        return 0;
    }
    
    // Проверяем формат
    if (surface->format->format != SDL_PIXELFORMAT_RGB565) {
        LOG_error("Unsupported pixel format for JPEG: %d\n", surface->format->format);
        return 0;
    }
    
    SDL_LockSurface(surface);
    
    int width = surface->w;
    int height = surface->h;
    uint16_t* src_pixels = (uint16_t*)surface->pixels;
    int src_pitch_pixels = surface->pitch / sizeof(uint16_t); // pitch в пикселях
    
    // Выделяем память для RGB888
    unsigned char* rgb888 = malloc(width * height * 3);
    if (!rgb888) {
        LOG_error("Cannot allocate memory for JPEG conversion\n");
        SDL_UnlockSurface(surface);
        return 0;
    }
    
    // Конвертируем RGB565 -> RGB888 с учетом pitch
    rgb565_to_rgb888(src_pixels, rgb888, width, height, src_pitch_pixels);
    
    SDL_UnlockSurface(surface);
    
    // Сохраняем как JPEG
    int result;
    if (quality > 0) {
        // Качество 1-3 как в оригинальной TJE
        int tje_quality;
        if (quality >= 90) tje_quality = 3;      // Высокое
        else if (quality >= 70) tje_quality = 2; // Среднее
        else tje_quality = 1;                    // Низкое
        
        result = tje_encode_to_file_at_quality(filename, tje_quality, 
                                               width, height, 3, rgb888);
    } else {
        // Качество по умолчанию
        result = tje_encode_to_file(filename, width, height, 3, rgb888);
    }
    
    free(rgb888);
    
    if (result) {
        LOG_info("JPEG saved with TJE: %s (quality: %d, size: %dx%d)\n", 
                filename, quality, width, height);
    } else {
        LOG_error("Failed to save JPEG with TJE: %s\n", filename);
    }
    
    return result;
}

void loadSettingsFromIni(){
	int color_select = 0;
	const char*  colors_name_in_ini[] = {"yellow", "green", "blue", "red", "violet"};
	if (ini_haskey("sleep", "val", inifile)){
		PWR_changeSleepDelay(ini_getl("sleep", "val", -1, inifile));
		}
	if (ini_haskey("settings", "hide", inifile))
		emulators_settings_hide = ini_getl("settings", "hide", -1, inifile);
	if (ini_haskey("color", "val", inifile)){
		int r, g, b;
		char str[7];
		color_select = ini_getl("color", "val", -1, inifile);
		if(color_select > 5 || color_select < 0)
			color_select = 0;
		for(int i = 0; i < 5; i++){
			if (ini_haskey("color", colors_name_in_ini[i], inifile)){
				if(ini_gets("color", colors_name_in_ini[i], "dummy", str, 7, inifile)){
					sscanf(str, "%02x%02x%02x", &r, &g, &b);
					colors_b[i + 1][0] = r;
					colors_b[i + 1][1] = g;
					colors_b[i + 1][2] = b;
				}
			}
		}
	}
	if (ini_haskey("swapbutton", "L3", inifile)){
		int swap_buttonL3 = ini_getl("swapbutton","L3", -1, inifile);
		if(swap_buttonL3 != 0)
			swap_buttonL3 = 1;
		PAD_swapMenuL3(swap_buttonL3);
	}
	color_triad_black_r = colors_b[color_select][0];
	color_triad_black_g = colors_b[color_select][1];
	color_triad_black_b = colors_b[color_select][2];
	language_init(-1);
}

///////////////////////////////////////
// based on picoarch/unzip.c

#define ZIP_HEADER_SIZE 30
#define ZIP_CHUNK_SIZE 65536
#define ZIP_LE_READ16(buf) ((uint16_t)(((uint8_t *)(buf))[1] << 8 | ((uint8_t *)(buf))[0]))
#define ZIP_LE_READ32(buf) ((uint32_t)(((uint8_t *)(buf))[3] << 24 | ((uint8_t *)(buf))[2] << 16 | ((uint8_t *)(buf))[1] << 8 | ((uint8_t *)(buf))[0]))
typedef int (*Zip_extract_t)(FILE* zip, FILE* dst, size_t size);

static int Zip_copy(FILE* zip, FILE* dst, size_t size) { // uncompressed?
	uint8_t buffer[ZIP_CHUNK_SIZE];
	while (size) {
		size_t sz = MIN(size, ZIP_CHUNK_SIZE);
		if (sz!= fread(buffer, 1, sz, zip)) return -1;
		if (sz!=fwrite(buffer, 1, sz, dst)) return -1;
		size -= sz;
	}
	return 0;
}
static int Zip_inflate(FILE* zip, FILE* dst, size_t size) { // compressed
	z_stream stream = {0};
	size_t have = 0;
	uint8_t  in[ZIP_CHUNK_SIZE];
	uint8_t out[ZIP_CHUNK_SIZE];
	int ret = -1;

	ret = inflateInit2(&stream, -MAX_WBITS);
	if (ret != Z_OK)
		return ret;
	
	do {
		size_t insize = MIN(size, ZIP_CHUNK_SIZE);

		stream.avail_in = fread(in, 1, insize, zip);
		if (ferror(zip)) {
			(void)inflateEnd(&stream);
			return Z_ERRNO;
		}

		if (!stream.avail_in)
			break;
		stream.next_in = in;

		do {
			stream.avail_out = ZIP_CHUNK_SIZE;
			stream.next_out = out;

			ret = inflate(&stream, Z_NO_FLUSH);
			switch(ret) {
				case Z_NEED_DICT:
					ret = Z_DATA_ERROR;
				case Z_DATA_ERROR:
				case Z_MEM_ERROR:
					(void)inflateEnd(&stream);
					return ret;
			}

			have = ZIP_CHUNK_SIZE - stream.avail_out;
			if (fwrite(out, 1, have, dst) != have || ferror(dst)) {
				(void)inflateEnd(&stream);
				return Z_ERRNO;
			}
		} while (stream.avail_out == 0);

		size -= insize;
	} while (size && ret != Z_STREAM_END);

	(void)inflateEnd(&stream);

	if (!size || ret == Z_STREAM_END) {
		return Z_OK;
	} else {
		return Z_DATA_ERROR;
	}
}

///////////////////////////////////////

static void Game_open(char* path) {
	LOG_info("Game_open\n");
	memset(&game, 0, sizeof(game));
	
	strcpy((char*)game.path, path);
	strcpy((char*)game.name, strrchr(path, '/')+1);
	
	// if we have a zip file
	if (suffixMatch(".zip", game.path)) {
		LOG_info("is zip file\n");
		int supports_zip = 0;
		int i = 0;
		char* ext;
		char exts[128];
		char* extensions[32];
		strcpy(exts,core.extensions);
		while ((ext=strtok(i?NULL:exts,"|"))) {
			extensions[i++] = ext;
			if (!strcmp("zip", ext)) {
				supports_zip = 1;
				break;
			}
		}
		extensions[i] = NULL;
	
		// if the core doesn't support zip files natively
		if (!supports_zip) {
			FILE *zip = fopen(game.path, "r");
			if (zip==NULL) {
				LOG_error("Error opening archive: %s\n\t%s\n", game.path, strerror(errno));
				return;
			}
			
			// extract a known file format
			uint8_t header[ZIP_HEADER_SIZE];
			uint32_t next = 0;
			uint16_t len = 0;
			char filename[MAX_PATH];
			uint32_t compressed_size = 0;
			char extension[8];
			while (1) {
				if (next) fseek(zip, next, SEEK_CUR);
				
				if (ZIP_HEADER_SIZE!=fread(header, 1, ZIP_HEADER_SIZE, zip)) break;
				
				if ((uint16_t)(header[6]) & 0x0008) break;
				
				len = ZIP_LE_READ16(&header[26]);
				if (len>=MAX_PATH) break;
				
				if (len!=fread(filename,1,len,zip)) break;
				filename[len] = '\0';
				LOG_info("filename: %s\n", filename);
				
				compressed_size = ZIP_LE_READ32(&header[18]);
				
				fseek(zip, ZIP_LE_READ16(&header[28]), SEEK_CUR);
				next = compressed_size;
				
				int found = 0;
				for (i=0; extensions[i]; i++) {
					sprintf(extension, ".%s", extensions[i]);
					if (suffixMatch(extension, filename)) {
						
						found = 1;
						break;
					}
				}
				if (!found) continue;
				
				char tmp_template[MAX_PATH];
				strcpy(tmp_template, "/tmp/minarch-XXXXXX");
				char* tmp_dirname = mkdtemp(tmp_template);
				// LOG_info("tmp_dirname: %s\n", tmp_dirname);
				sprintf(game.tmp_path, "%s/%s", tmp_dirname, basename(filename));
				
				// TODO: we need to clear game.tmp_path if anything below this point fails!
				
				FILE* dst = fopen(game.tmp_path, "w");
				if (dst==NULL) {
					game.tmp_path[0] = '\0';
					LOG_error("Error extracting file: %s\n\t%s\n", filename, strerror(errno));
					return;
				}
				
				Zip_extract_t extract = NULL;
				switch (ZIP_LE_READ16(&header[8])) {
					case 0: extract = Zip_copy; break;
					case 8: extract = Zip_inflate; break;
				}
				
				if (!extract || extract(zip,dst,compressed_size)) {
					game.tmp_path[0] = '\0';
					LOG_error("Error extracting file: %s\n\t%s\n", filename, strerror(errno));
					return;
				}
				
				fclose(dst);
				
				break;
			}
			
			fclose(zip);
		}
	}
		
	// some cores handle opening files themselves, eg. pcsx_rearmed
	// if the frontend tries to load a 500MB file itself bad things happen
	if (!core.need_fullpath) {
		path = game.tmp_path[0]=='\0'?game.path:game.tmp_path;
		
		FILE *file = fopen(path, "r");
		if (file==NULL) {
			LOG_error("Error opening game: %s\n\t%s\n", path, strerror(errno));
			return;
		}
	
		fseek(file, 0, SEEK_END);
		game.size = ftell(file);
	
		rewind(file);
		game.data = malloc(game.size);
		if (game.data==NULL) {
			LOG_error("Couldn't allocate memory for file: %s\n", path);
			return;
		}
	
		fread(game.data, sizeof(uint8_t), game.size, file);
	
		fclose(file);
	}
	
	// m3u-based?
	char* tmp;
	char m3u_path[256];
	char base_path[256];
	char dir_name[256];

	strcpy(m3u_path, game.path);
	tmp = strrchr(m3u_path, '/') + 1;
	tmp[0] = '\0';
	
	strcpy(base_path, m3u_path);
	
	tmp = strrchr(m3u_path, '/');
	tmp[0] = '\0';

	tmp = strrchr(m3u_path, '/');
	strcpy(dir_name, tmp);
	
	tmp = m3u_path + strlen(m3u_path); 
	strcpy(tmp, dir_name);
	
	tmp = m3u_path + strlen(m3u_path);
	strcpy(tmp, ".m3u");
	
	if (exists(m3u_path)) {
		strcpy(game.m3u_path, m3u_path);
		strcpy((char*)game.name, strrchr(m3u_path, '/')+1);
	}
	
	game.is_open = 1;
}
static void Game_close(void) {
	if (game.data) free(game.data);
	if (game.tmp_path[0]) remove(game.tmp_path);
	game.is_open = 0;
	VIB_setStrength(0); // just in case
}

static struct retro_disk_control_ext_callback disk_control_ext;
static void Game_changeDisc(char* path) {
	
	if (exactMatch(game.path, path) || !exists(path)) return;
	
	Game_close();
	Game_open(path);
	
	struct retro_game_info game_info = {};
	game_info.path = game.path;
	game_info.data = game.data;
	game_info.size = game.size;
	
	disk_control_ext.replace_image_index(0, &game_info);
	putFile(CHANGE_DISC_PATH, path); // MinUI still needs to know this to update recents.txt
}

///////////////////////////////////////

static void SRAM_getPath(char* filename) {
	sprintf(filename, "%s/%s.sav", core.saves_dir, game.name);
}
static void SRAM_read(void) {
	size_t sram_size = core.get_memory_size(RETRO_MEMORY_SAVE_RAM);
	if (!sram_size) return;
	
	char filename[MAX_PATH];
	SRAM_getPath(filename);
	LOG_info("sav path (read): %s\n", filename);
	
	FILE *sram_file = fopen(filename, "r");
	if (!sram_file) return;

	void* sram = core.get_memory_data(RETRO_MEMORY_SAVE_RAM);

	if (!sram || !fread(sram, 1, sram_size, sram_file)) {
		LOG_error("Error reading SRAM data\n");
	}

	fclose(sram_file);
}
static void SRAM_write(void) {
	size_t sram_size = core.get_memory_size(RETRO_MEMORY_SAVE_RAM);
	if (!sram_size) return;
	
	char filename[MAX_PATH];
	SRAM_getPath(filename);
	LOG_info("sav path (write): %s\n", filename);
		
	FILE *sram_file = fopen(filename, "w");
	if (!sram_file) {
		LOG_error("Error opening SRAM file: %s\n", strerror(errno));
		return;
	}

	void *sram = core.get_memory_data(RETRO_MEMORY_SAVE_RAM);

	if (!sram || sram_size != fwrite(sram, 1, sram_size, sram_file)) {
		LOG_error("Error writing SRAM data to file\n");
	}

	fclose(sram_file);

	sync();
}

///////////////////////////////////////

static void RTC_getPath(char* filename) {
	sprintf(filename, "%s/%s.rtc", core.saves_dir, game.name);
}
static void RTC_read(void) {
	size_t rtc_size = core.get_memory_size(RETRO_MEMORY_RTC);
	if (!rtc_size) return;
	
	char filename[MAX_PATH];
	RTC_getPath(filename);
	LOG_info("rtc path (read): %s\n", filename);
	
	FILE *rtc_file = fopen(filename, "r");
	if (!rtc_file) return;

	void* rtc = core.get_memory_data(RETRO_MEMORY_RTC);

	if (!rtc || !fread(rtc, 1, rtc_size, rtc_file)) {
		LOG_error("Error reading RTC data\n");
	}

	fclose(rtc_file);
}
static void RTC_write(void) {
	size_t rtc_size = core.get_memory_size(RETRO_MEMORY_RTC);
	if (!rtc_size) return;
	
	char filename[MAX_PATH];
	RTC_getPath(filename);
	LOG_info("rtc path (write) size(%u): %s\n", rtc_size, filename);
		
	FILE *rtc_file = fopen(filename, "w");
	if (!rtc_file) {
		LOG_error("Error opening RTC file: %s\n", strerror(errno));
		return;
	}

	void *rtc = core.get_memory_data(RETRO_MEMORY_RTC);

	if (!rtc || rtc_size != fwrite(rtc, 1, rtc_size, rtc_file)) {
		LOG_error("Error writing RTC data to file\n");
	}

	fclose(rtc_file);

	sync();
}

///////////////////////////////////////

static int state_slot = 0;
static void State_getPath(char* filename) {
	sprintf(filename, "%s/%s.st%i", core.states_dir, game.name, state_slot);
}
static void State_read(void) { // from picoarch
	size_t state_size = core.serialize_size();
	if (!state_size) return;

	int was_ff = fast_forward;
	fast_forward = 0;

	void *state = calloc(1, state_size);
	if (!state) {
		LOG_error("Couldn't allocate memory for state\n");
		goto error;
	}

	char filename[MAX_PATH];
	State_getPath(filename);
	
	FILE *state_file = fopen(filename, "r");
	if (!state_file) {
		if (state_slot!=8) { // st8 is a default state in MiniUI and may not exist, that's okay
			LOG_error("Error opening state file: %s (%s)\n", filename, strerror(errno));
		}
		goto error;
	}
	
	// some cores report the wrong serialize size initially for some games, eg. mgba: Wario Land 4
	// so we allow a size mismatch as long as the actual size fits in the buffer we've allocated
	if (state_size < fread(state, 1, state_size, state_file)) {
		LOG_error("Error reading state data from file: %s (%s)\n", filename, strerror(errno));
		goto error;
	}

	if (!core.unserialize(state, state_size)) {
		LOG_error("Error restoring save state: %s (%s)\n", filename, strerror(errno));
		goto error;
	}

error:
	if (state) free(state);
	if (state_file) fclose(state_file);
	
	fast_forward = was_ff;
}
static void State_write(void) { // from picoarch
	size_t state_size = core.serialize_size();
	if (!state_size) return;
	
	int was_ff = fast_forward;
	fast_forward = 0;

	void *state = calloc(1, state_size);
	if (!state) {
		LOG_error("Couldn't allocate memory for state\n");
		goto error;
	}

	char filename[MAX_PATH];
	State_getPath(filename);
	
	FILE *state_file = fopen(filename, "w");
	if (!state_file) {
		LOG_error("Error opening state file: %s (%s)\n", filename, strerror(errno));
		goto error;
	}

	if (!core.serialize(state, state_size)) {
		LOG_error("Error creating save state: %s (%s)\n", filename, strerror(errno));
		goto error;
	}

	if (state_size != fwrite(state, 1, state_size, state_file)) {
		LOG_error("Error writing state data to file: %s (%s)\n", filename, strerror(errno));
		goto error;
	}

error:
	if (state) free(state);
	if (state_file) fclose(state_file);

	sync();
	
	fast_forward = was_ff;
}
static void State_autosave(void) {
	int last_state_slot = state_slot;
	state_slot = AUTO_RESUME_SLOT;
	State_write();
	state_slot = last_state_slot;
}
static void State_resume(void) {
	if (!exists(RESUME_SLOT_PATH)) return;
	
	int last_state_slot = state_slot;
	state_slot = getInt(RESUME_SLOT_PATH);
	unlink(RESUME_SLOT_PATH);
	State_read();
	state_slot = last_state_slot;
}
///////////////////////////////

static void Menu_beforeSleep(void);
static void Menu_afterSleep(void);

static void Menu_saveState(void);
static void Menu_loadState(void);

static uint32_t buttons = 0; // RETRO_DEVICE_ID_JOYPAD_* buttons
static int ignore_menu = 0;
static uint16_t* menu_background = NULL;
static size_t menu_bg_size = 0;

static void take_screenshot(void) {
    char screenshot_file[256];
    unsigned width = renderer.true_w;
    unsigned height = renderer.true_h;
    size_t src_pitch = renderer.src_p;  // pitch в байтах

    if (!renderer.src || width == 0 || height == 0) return;

    // Вычисляем фактический pitch в пикселях
    int src_pitch_pixels = src_pitch / sizeof(uint16_t);

    // Выделяем плотный буфер: без выравнивания
    size_t dst_pitch = width * sizeof(uint16_t);
    uint16_t* packed_buffer = malloc(height * dst_pitch);
    if (!packed_buffer) {
        LOG_error("Failed to allocate packed buffer for screenshot");
        return;
    }

    // Копируем построчно, убирая выравнивание
    const uint16_t* src = (const uint16_t*)renderer.src;
    uint16_t* dst = packed_buffer;
    for (int y = 0; y < height; y++) {
        memcpy(dst, src + y * src_pitch_pixels, width * sizeof(uint16_t));
        dst += width;
    }

    // Создаём поверхность из плотного буфера
    SDL_Surface* bitmap = SDL_CreateRGBSurfaceFrom(
        packed_buffer,
        width,
        height,
        16,
        dst_pitch,
        0xF800, 0x07E0, 0x001F, 0  // явные маски для RGB565
    );

    if (!bitmap) {
        LOG_error("Failed to create surface for screenshot: %s", SDL_GetError());
        free(packed_buffer);
        return;
    }
    
    // Создаем папку если нет
    system("mkdir -p \"/sdcard/Roms/Gallery (JPEG)\"");
    
    // Ищем свободный номер для файла
    for(int j = 0; j < 1000; j++){
        sprintf(screenshot_file, "/sdcard/Screenshots/%s_%d.jpg", file_name, j);
        system("mkdir -p \"/sdcard/Screenshots\"");
        
        if(!exists(screenshot_file)){
            int saved = save_as_jpeg_tje(bitmap, screenshot_file, 90);
            
            if (!saved) {
                LOG_error("Failed to save JPEG, trying BMP fallback\n");
                
                char fallback_file[256];
                sprintf(fallback_file, "/sdcard/Screenshots/%s_%d.bmp", file_name, j);
                
                // Для BMP тоже используем правильный pitch
                SDL_RWops* out = SDL_RWFromFile(fallback_file, "wb");
                if (out) {
                    // Важно: сохраняем с тем же pitch
                    SDL_SaveBMP_RW(bitmap, out, 1);
                    LOG_info("Screenshot saved as BMP (fallback): %s\n", fallback_file);
                }
            } else {
                LOG_info("Screenshot saved as JPEG: %s (size: %dx%d, pitch: %zu)\n", 
                        screenshot_file, width, height, src_pitch);
                PLAT_clearPopup();
                PLAT_showPopup(language_get_string("SCREENSHOT_SAVED"));
            }
            
            SDL_FreeSurface(bitmap);
            free(packed_buffer);
            break;
        }
    }
}

static volatile int shortcut_flags[SHORTCUT_COUNT] = {0};

static inline int get_shortcut_flag(int idx) {
    if (idx < 0 || idx >= SHORTCUT_COUNT) return 0;
    return shortcut_flags[idx];
}

static inline void set_shortcut_flag(int idx, int val) {
    if (idx >= 0 && idx < SHORTCUT_COUNT) {
        shortcut_flags[idx] = val;
    }
}

// === Сброс флага после выполнения ===
static inline void clear_shortcut_flag(int idx) {
    set_shortcut_flag(idx, 0);
}

static void input_poll_callback(void) {
    PAD_poll();
    int show_setting = 0;
    PWR_update(NULL, &show_setting, Menu_beforeSleep, Menu_afterSleep);

    if (PAD_justPressed(BTN_MENU)) {
        ignore_menu = 0;
    }
    if (PAD_isPressed(BTN_MENU) && (PAD_isPressed(BTN_PLUS) || PAD_isPressed(BTN_MINUS))) {
        ignore_menu = 1;
    }

    // Сброс флагов удержания
    static int rewind_holding = 0;
    static int ff_holding = 0;

    for (int i = 0; i < SHORTCUT_COUNT; i++) {
        ButtonMapping* mapping = &config.shortcuts[i];
        int btn = 1 << mapping->local;
        if (btn == BTN_NONE) continue;
        int mod_active = (!mapping->mod) || (mapping->mod && PAD_isPressed(BTN_MENU));
        if (!mod_active) continue;

        int btn_pressed = PAD_isPressed(btn);
        int btn_just_pressed = PAD_justPressed(btn);

        switch (i) {
            // === УДЕРЖИВАЕМЫЕ ===
            case SHORTCUT_HOLD_FF:
                if (btn_pressed) {
                    fast_forward = 1;
                    ff_holding = 1;
                } else if (ff_holding) {
                    fast_forward = 0;
                    ff_holding = 0;
                }
                break;

            case SHORTCUT_REWIND_HOLD:
                // УПРОЩЕННАЯ ЛОГИКА: только устанавливаем флаг
                if (btn_just_pressed) {
                    rewind_activation_requested = 1;
                }
                break;

            // === МГНОВЕННЫЕ (гарантированное срабатывание) ===
            default: {
                // Если кнопка нажата — устанавливаем флаг, даже если justPressed пропущен
                if (btn_just_pressed || (btn_pressed && !get_shortcut_flag(i))) {
                    set_shortcut_flag(i, 1);
                }
                break;
            }
        }
    }

    if (!ignore_menu && PAD_justReleased(BTN_MENU) && !rewind_ui_active) {
        show_menu = 1;
    }

    // Обновление buttons для эмулятора
    buttons = 0;
    for (int i = 0; config.controls[i].name; i++) {
        ButtonMapping* mapping = &config.controls[i];
        int btn = 1 << mapping->local;
        if (btn == BTN_NONE) continue;
        if (PAD_isPressed(btn) && (!mapping->mod || PAD_isPressed(BTN_MENU))) {
            buttons |= 1 << mapping->retro;
            if (mapping->mod) ignore_menu = 1;
        }
    }
}
static int16_t input_state_callback(unsigned port, unsigned device, unsigned index, unsigned id) {
	// id == RETRO_DEVICE_ID_JOYPAD_MASK or RETRO_DEVICE_ID_JOYPAD_*
	if (port == 0 && device == RETRO_DEVICE_JOYPAD && index == 0) {
		if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return buttons;
		return (buttons >> id) & 1;
	}
	else if (port==0 && device==RETRO_DEVICE_ANALOG) {
		// LOG_info("wants analog input\n");
		if (index==RETRO_DEVICE_INDEX_ANALOG_LEFT) {
			// LOG_info("wants left stick %i,%i\n", pad.laxis.x,pad.laxis.y);
			if (id==RETRO_DEVICE_ID_ANALOG_X) return pad.laxis.x;
			else if (id==RETRO_DEVICE_ID_ANALOG_Y) return pad.laxis.y;
		}
		else if (index==RETRO_DEVICE_INDEX_ANALOG_RIGHT) {
			// LOG_info("wants right stick %i,%i\n", pad.raxis.x,pad.raxis.y);
			if (id==RETRO_DEVICE_ID_ANALOG_X) return pad.raxis.x;
			else if (id==RETRO_DEVICE_ID_ANALOG_Y) return pad.raxis.y;
		}
	}
	return 0;
}
///////////////////////////////

static void Input_init(const struct retro_input_descriptor *vars) {
	static int input_initialized = 0;
	if (input_initialized) return;

	LOG_info("Input_init\n");
	
	config.controls = core_button_mapping[0].name ? core_button_mapping : default_button_mapping;
	
	puts("---------------------------------");

	const char* core_button_names[RETRO_BUTTON_COUNT] = {0};
	int present[RETRO_BUTTON_COUNT];
	int core_mapped = 0;
	if (vars) {
		core_mapped = 1;
		// identify buttons available in this core
		for (int i=0; vars[i].description; i++) {
			const struct retro_input_descriptor* var = &vars[i];
			if (var->port!=0 || var->device!=RETRO_DEVICE_JOYPAD || var->index!=0) continue;

			// TODO: don't ignore unavailable buttons, just override them to BTN_ID_NONE!
			if (var->id>=RETRO_BUTTON_COUNT) {
				LOG_info("UNAVAILABLE: %s\n", var->description); fflush(stdout);
				continue;
			}
			else {
				LOG_info("PRESENT    : %s\n", var->description); fflush(stdout);
			}
			present[var->id] = 1;
			core_button_names[var->id] = var->description;
		}
	}
	
	puts("---------------------------------");

	for (int i=0;default_button_mapping[i].name; i++) {
		ButtonMapping* mapping = &default_button_mapping[i];
		LOG_info("DEFAULT %s (%s): <%s>\n", core_button_names[mapping->retro], mapping->name, (mapping->local==BTN_ID_NONE ? "NONE" : device_button_names[mapping->local]));
		if (core_button_names[mapping->retro]) mapping->name = (char*)core_button_names[mapping->retro];
	}
	
	puts("---------------------------------");

	for (int i=0; config.controls[i].name; i++) {
		ButtonMapping* mapping = &config.controls[i];
		mapping->default_ = mapping->local;

		// ignore mappings that aren't available in this core
		if (core_mapped && !present[mapping->retro]) {
			mapping->ignore = 1;
			continue;
		}
		LOG_info("%s: <%s> (%i:%i)\n", mapping->name, (mapping->local==BTN_ID_NONE ? "NONE" : device_button_names[mapping->local]), mapping->local, mapping->retro);
	}
	
	puts("---------------------------------");
	input_initialized = 1;
}

static bool set_rumble_state(unsigned port, enum retro_rumble_effect effect, uint16_t strength) {
	// TODO: handle other args? not sure I can
	VIB_setStrength(strength);
	return 1;
}
static bool environment_callback(unsigned cmd, void *data) { // copied from picoarch initially
	// LOG_info("environment_callback: %i\n", cmd);
	
	switch(cmd) {
	case RETRO_ENVIRONMENT_GET_OVERSCAN: { /* 2 */
		bool *out = (bool *)data;
		if (out)
			*out = true;
		break;
	}
	case RETRO_ENVIRONMENT_GET_CAN_DUPE: { /* 3 */
		bool *out = (bool *)data;
		if (out)
			*out = true;
		break;
	}
	case RETRO_ENVIRONMENT_SET_MESSAGE: { /* 6 */
		const struct retro_message *message = (const struct retro_message*)data;
		if (message) LOG_info("%s\n", message->msg);
		break;
	}
	case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL: { /* 8 */
		// puts("RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL");
		// TODO: used by fceumm at least
	}
	case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: { /* 9 */
		const char **out = (const char **)data;
		if (out) {
			*out = core.bios_dir;
		}
		
		break;
	}
	case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: { /* 10 */
		const enum retro_pixel_format *format = (enum retro_pixel_format *)data;

		if (*format != RETRO_PIXEL_FORMAT_RGB565) { // TODO: pull from platform.h?
			/* 565 is only supported format */
			LOG_info("use downsample from 8888 to 565\n");
			downsample = 1; // TODO: not ready for primetime yet
		}
		break;
	}
	case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS: { /* 11 */
		// puts("RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS\n");
		Input_init((const struct retro_input_descriptor *)data);
		return false;
	} break;
	case RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE: { /* 13 */
		const struct retro_disk_control_callback *var =
			(const struct retro_disk_control_callback *)data;

		if (var) {
			memset(&disk_control_ext, 0, sizeof(struct retro_disk_control_ext_callback));
			memcpy(&disk_control_ext, var, sizeof(struct retro_disk_control_callback));
		}
		break;
	}

	// TODO: this is called whether using variables or options
	case RETRO_ENVIRONMENT_GET_VARIABLE: { /* 15 */
		// puts("RETRO_ENVIRONMENT_GET_VARIABLE");
		struct retro_variable *var = (struct retro_variable *)data;
		if (var && var->key) {
			var->value = OptionList_getOptionValue(&config.core, var->key);
			// printf("\t%s = %s\n", var->key, var->value);
		}
		break;
	}
	// TODO: I think this is where the core reports its variables (the precursor to options)
	// TODO: this is called if RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION sets out to 0
	// TODO: not used by anything yet
	case RETRO_ENVIRONMENT_SET_VARIABLES: { /* 16 */
		// puts("RETRO_ENVIRONMENT_SET_VARIABLES");
		const struct retro_variable *vars = (const struct retro_variable *)data;
		if (vars) {
			OptionList_reset();
			OptionList_vars(vars);
		}
		break;
	}
	case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME: { /* 18 */
		bool flag = *(bool*)data;
		// LOG_info("%i: RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME: %i\n", cmd, flag);
		break;
	}
	case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: { /* 17 */
		bool *out = (bool *)data;
		if (out) {
			*out = config.core.changed;
			config.core.changed = 0;
		}
		break;
	}
	case RETRO_ENVIRONMENT_SET_FRAME_TIME_CALLBACK: { /* 21 */
		// LOG_info("%i: RETRO_ENVIRONMENT_SET_FRAME_TIME_CALLBACK\n", cmd);
		break;
	}
	case RETRO_ENVIRONMENT_SET_AUDIO_CALLBACK: { /* 22 */
		// LOG_info("%i: RETRO_ENVIRONMENT_SET_AUDIO_CALLBACK\n", cmd);
		break;
	}
	case RETRO_ENVIRONMENT_GET_RUMBLE_INTERFACE: { /* 23 */
	        struct retro_rumble_interface *iface = (struct retro_rumble_interface*)data;

	        // LOG_info("Setup rumble interface.\n");
	        iface->set_rumble_state = set_rumble_state;
		break;
	}
	case RETRO_ENVIRONMENT_GET_INPUT_DEVICE_CAPABILITIES: {
		unsigned *out = (unsigned *)data;
		if (out)
			*out = (1 << RETRO_DEVICE_JOYPAD) | (1 << RETRO_DEVICE_ANALOG);
		break;
	}
	case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: { /* 27 */
		struct retro_log_callback *log_cb = (struct retro_log_callback *)data;
		if (log_cb)
			log_cb->log = (void (*)(enum retro_log_level, const char*, ...))LOG_note; // same difference
		break;
	}
	case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: { /* 31 */
		const char **out = (const char **)data;
		if (out)
			*out = core.saves_dir; // save_dir;
		break;
	}
	case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO: { /* 35 */
		// LOG_info("RETRO_ENVIRONMENT_SET_CONTROLLER_INFO\n");
		const struct retro_controller_info *infos = (const struct retro_controller_info *)data;
		if (infos) {
			// TODO: store to gamepad_values/gamepad_labels for gamepad_device
			const struct retro_controller_info *info = &infos[0];
			for (int i=0; i<info->num_types; i++) {
				const struct retro_controller_description *type = &info->types[i];
				/*
				if (exactMatch((char*)type->desc,"dualshock")) { // currently only enabled for PlayStation
					has_custom_controllers = 1;
					break;
				}
				*/
				// printf("\t%i: %s\n", type->id, type->desc);
			}
		}
		fflush(stdout);
		return false; // TODO: tmp
		break;
	}
	// RETRO_ENVIRONMENT_SET_MEMORY_MAPS (36 | RETRO_ENVIRONMENT_EXPERIMENTAL)
	case RETRO_ENVIRONMENT_GET_LANGUAGE: { /* 39 */
    	unsigned *out = (unsigned *)data;
    	if (out) {
        	unsigned lang_code = getRetroLanguageCode();
        	*out = lang_code;
        	LOG_info("Core requested language: %d (system language: %s)\n", 
                 	lang_code, language_get_string("SELECT_LANGUAGE"));
    	}
    	break;
	}
	// RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS (42 | RETRO_ENVIRONMENT_EXPERIMENTAL)
	// RETRO_ENVIRONMENT_GET_VFS_INTERFACE (45 | RETRO_ENVIRONMENT_EXPERIMENTAL)
	// RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE (47 | RETRO_ENVIRONMENT_EXPERIMENTAL)
	// RETRO_ENVIRONMENT_GET_INPUT_BITMASKS (51 | RETRO_ENVIRONMENT_EXPERIMENTAL)
	case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: { /* 51 | RETRO_ENVIRONMENT_EXPERIMENTAL */
		bool *out = (bool *)data;
		if (out)
			*out = true;
		break;
	}
	case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: { /* 52 */
		// puts("RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION");
		unsigned *out = (unsigned *)data;
		if (out)
			*out = 1;
		break;
	}
	case RETRO_ENVIRONMENT_SET_CORE_OPTIONS: { /* 53 */
		// puts("RETRO_ENVIRONMENT_SET_CORE_OPTIONS");
		if (data) {
			OptionList_reset();
			OptionList_init((const struct retro_core_option_definition *)data); 
		}
		break;
	}
	case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL: { /* 54 */
		// puts("RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL");
		const struct retro_core_options_intl *options = (const struct retro_core_options_intl *)data;
		if (options && options->us) {
			OptionList_reset();
			OptionList_init(options->us);
		}
		break;
	}
	case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY: { /* 55 */
		// puts("RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY");
		// const struct retro_core_option_display *display = (const struct retro_core_option_display *)data;
	// 	if (display) OptionList_setOptionVisibility(&config.core, display->key, display->visible);
		break;
	}
	case RETRO_ENVIRONMENT_GET_DISK_CONTROL_INTERFACE_VERSION: { /* 57 */
		unsigned *out =	(unsigned *)data;
		if (out) *out = 1;
		break;
	}
	case RETRO_ENVIRONMENT_SET_DISK_CONTROL_EXT_INTERFACE: { /* 58 */
		const struct retro_disk_control_ext_callback *var =
			(const struct retro_disk_control_ext_callback *)data;

		if (var) {
			memcpy(&disk_control_ext, var, sizeof(struct retro_disk_control_ext_callback));
		}
		break;
	}
	// TODO: RETRO_ENVIRONMENT_GET_MESSAGE_INTERFACE_VERSION 59
	// TODO: used by mgba, (but only during frameskip?)
	// case RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK: { /* 62 */
	// 	LOG_info("RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK\n");
	// 	const struct retro_audio_buffer_status_callback *cb = (const struct retro_audio_buffer_status_callback *)data;
	// 	if (cb) {
	// 		LOG_info("has audo_buffer_status callback\n");
	// 		core.audio_buffer_status = cb->callback;
	// 	} else {
	// 		LOG_info("no audo_buffer_status callback\n");
	// 		core.audio_buffer_status = NULL;
	// 	}
	// 	break;
	// }
	// TODO: used by mgba, (but only during frameskip?)
	// case RETRO_ENVIRONMENT_SET_MINIMUM_AUDIO_LATENCY: { /* 63 */
	// 	LOG_info("RETRO_ENVIRONMENT_SET_MINIMUM_AUDIO_LATENCY\n");
	//
	// 	const unsigned *latency_ms = (const unsigned *)data;
	// 	if (latency_ms) {
	// 		unsigned frames = *latency_ms * core.fps / 1000;
	// 		if (frames < 30)
	// 			// audio_buffer_size_override = frames;
	// 			LOG_info("audio_buffer_size_override = %i (unused?)\n", frames);
	// 		else
	// 			LOG_info("Audio buffer change out of range (%d), ignored\n", frames);
	// 	}
	// 	break;
	// }

	// TODO: RETRO_ENVIRONMENT_SET_FASTFORWARDING_OVERRIDE 64
	case RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE: { /* 65 */
		// const struct retro_system_content_info_override* info = (const struct retro_system_content_info_override* )data;
		// if (info) LOG_info("has overrides");
		break;
	}
	// RETRO_ENVIRONMENT_GET_GAME_INFO_EXT 66
	// TODO: RETRO_ENVIRONMENT_SET_CORE_OPTIONS_UPDATE_DISPLAY_CALLBACK 69
	// used by fceumm
	// TODO: used by gambatte for L/R palette switching (seems like it needs to return true even if data is NULL to indicate support)
	case RETRO_ENVIRONMENT_SET_VARIABLE: {
		// puts("RETRO_ENVIRONMENT_SET_VARIABLE");
		const struct retro_variable *var = (const struct retro_variable *)data;
		if (var && var->key) {
			// printf("\t%s = %s\n", var->key, var->value);
			OptionList_setOptionValue(&config.core, var->key, var->value);
			break;
		}

		int *out = (int *)data;
		if (out) *out = 1;
		
		break;
	}
	
	// unused
	// case RETRO_ENVIRONMENT_SET_FRAME_TIME_CALLBACK: {
	// 	puts("RETRO_ENVIRONMENT_SET_FRAME_TIME_CALLBACK"); fflush(stdout);
	// 	break;
	// }
	// case RETRO_ENVIRONMENT_GET_THROTTLE_STATE: {
	// 	puts("RETRO_ENVIRONMENT_GET_THROTTLE_STATE"); fflush(stdout);
	// 	break;
	// }
	// case RETRO_ENVIRONMENT_GET_FASTFORWARDING: {
	// 	puts("RETRO_ENVIRONMENT_GET_FASTFORWARDING"); fflush(stdout);
	// 	break;
	// };
	
	default:
		// LOG_debug("Unsupported environment cmd: %u\n", cmd);
		return false;
	}
	return true;
}

///////////////////////////////

// TODO: this is a dumb API
SDL_Surface* digits;
#define DIGIT_WIDTH 9
#define DIGIT_HEIGHT 8
#define DIGIT_TRACKING -2
enum {
	DIGIT_SLASH = 10,
	DIGIT_DOT,
	DIGIT_PERCENT,
	DIGIT_X,
	DIGIT_OP, // (
	DIGIT_CP, // )
	DIGIT_COUNT,
};
#define DIGIT_SPACE DIGIT_COUNT
static void MSG_init(void) {
	digits = SDL_CreateRGBSurface(SDL_SWSURFACE,SCALE2(DIGIT_WIDTH*DIGIT_COUNT,DIGIT_HEIGHT),FIXED_DEPTH, 0,0,0,0);
	SDL_FillRect(digits, NULL, RGB_BLACK);
	
	SDL_Surface* digit;
	char* chars[] = { "0","1","2","3","4","5","6","7","8","9","/",".","%","x","(",")", NULL };
	char* c;
	int i = 0;
	while ((c = chars[i])) {
		digit = TTF_RenderUTF8_Blended(font.tiny, c, COLOR_WHITE);
		SDL_BlitSurface(digit, NULL, digits, &(SDL_Rect){ (i * SCALE1(DIGIT_WIDTH)) + (SCALE1(DIGIT_WIDTH) - digit->w)/2, (SCALE1(DIGIT_HEIGHT) - digit->h)/2});
		SDL_FreeSurface(digit);
		i += 1;
	}
}
static int MSG_blitChar(int n, int x, int y) {
	if (n!=DIGIT_SPACE) SDL_BlitSurface(digits, &(SDL_Rect){n*SCALE1(DIGIT_WIDTH),0,SCALE2(DIGIT_WIDTH,DIGIT_HEIGHT)}, screen, &(SDL_Rect){x,y});
	return x + SCALE1(DIGIT_WIDTH + DIGIT_TRACKING);
}
static int MSG_blitInt(int num, int x, int y) {
	int i = num;
	int n;
	
	if (i > 999) {
		n = i / 1000;
		i -= n * 1000;
		x = MSG_blitChar(n,x,y);
	}
	if (i > 99) {
		n = i / 100;
		i -= n * 100;
		x = MSG_blitChar(n,x,y);
	}
	else if (num>99) {
		x = MSG_blitChar(0,x,y);
	}
	if (i > 9) {
		n = i / 10;
		i -= n * 10;
		x = MSG_blitChar(n,x,y);
	}
	else if (num>9) {
		x = MSG_blitChar(0,x,y);
	}
	
	n = i;
	x = MSG_blitChar(n,x,y);
	
	return x;
}
static int MSG_blitDouble(double num, int x, int y) {
	int i = num;
	int r = (num-i) * 10;
	int n;
	
	x = MSG_blitInt(i, x,y);

	n = DIGIT_DOT;
	x = MSG_blitChar(n,x,y);
	
	n = r;
	x = MSG_blitChar(n,x,y);
	return x;
}
static void MSG_quit(void) {
	SDL_FreeSurface(digits);
}

///////////////////////////////

static int cpu_ticks = 0;
static int fps_ticks = 0;
static int use_ticks = 0;
static double fps_double = 0;
static double cpu_double = 0;
static double use_double = 0;
static uint32_t sec_start = 0;

static SDL_Surface* scaler_surface;

#ifdef USES_SWSCALER
	static int fit = 1;
#else
	static int fit = 0;
#endif	

// buffer to convert xrgb8888 to rgb565
static void* buffer = NULL;
static void buffer_dealloc(void) {
	if (!buffer) return;
	free(buffer);
	buffer = NULL;
}
static void buffer_realloc(int w, int h, int p) {
	buffer_dealloc();
	buffer = malloc((w * sizeof(uint16_t)) * h * 2);
}
static void buffer_downsample(const void *data, unsigned width, unsigned height, size_t pitch) {
	const uint32_t *input = data;
	uint16_t *output = buffer;
	size_t extra = pitch / sizeof(uint32_t) - width;
	
	for (int y = 0; y < height; y++) {
    	int x = 0;
    	
    	for (; x + 3 < width; x += 4) {
        	// Загружаем 4 пикселя
        	uint32x4_t pixels = vld1q_u32(input);
        	
        	// Применяем точно такие же операции как в скалярном коде
        	uint32x4_t r_part = vshrq_n_u32(vandq_u32(pixels, vdupq_n_u32(0x00F80000)), 8);
        	uint32x4_t g_part = vshrq_n_u32(vandq_u32(pixels, vdupq_n_u32(0x0000FC00)), 5);
        	uint32x4_t b_part = vshrq_n_u32(vandq_u32(pixels, vdupq_n_u32(0x000000F8)), 3);
        	
        	// Объединяем
        	uint32x4_t rgb32 = vorrq_u32(vorrq_u32(r_part, g_part), b_part);
        	
        	// Преобразуем 32-битные в 16-битные
        	uint16x4_t rgb565 = vmovn_u32(rgb32);
        	
        	vst1_u16(output, rgb565);
        	
        	input += 4;
        	output += 4;
    	}
    	
    	for (; x < width; x++) {
        	*output =  (*input & 0xF80000) >> 8;
        	*output |= (*input & 0xFC00) >> 5;
        	*output |= (*input & 0xF8) >> 3;
        	input++;
        	output++;
    	}
    	
    	output += width;
    	input += extra;
	}
}	

void selectScaler(int src_w, int src_h, int src_p) {
	LOG_info("selectScaler\n");
	
	if (downsample) buffer_realloc(src_w, src_h, src_p);
	
	int src_x, src_y, dst_x, dst_y, dst_w, dst_h, dst_p, scale;
	double aspect;
	
	int aspect_w = src_w;
	int aspect_h = CEIL_DIV(aspect_w, core.aspect_ratio);
	
	if (aspect_h < src_h) {
		aspect_h = src_h;
		aspect_w = aspect_h * core.aspect_ratio;
		aspect_w += aspect_w % 2;
	}

	char scaler_name[16];
	
	src_x = 0;
	src_y = 0;
	dst_x = 0;
	dst_y = 0;

	renderer.true_w = src_w;
	renderer.true_h = src_h;
	
	int scaling = screen_scaling;
	if (scaling == SCALE_NATIVE && ((src_h > DEVICE_HEIGHT) || (src_w > DEVICE_WIDTH))) {
		scaling = SCALE_ASPECT;
	}
	
	if (scaling == SCALE_NATIVE || scaling == SCALE_CROPPED) {
		scale = MIN(DEVICE_WIDTH / src_w, DEVICE_HEIGHT / src_h);
		if (!scale) {
			sprintf(scaler_name, "forced crop");
			dst_w = DEVICE_WIDTH;
			dst_h = DEVICE_HEIGHT;
			dst_p = DEVICE_PITCH;
			
			int ox = (DEVICE_WIDTH - src_w) / 2;
			int oy = (DEVICE_HEIGHT - src_h) / 2;
			
			if (ox < 0) src_x = -ox;
			else dst_x = ox;
			
			if (oy < 0) src_y = -oy;
			else dst_y = oy;
		}
		else if (scaling == SCALE_CROPPED) {
			int scale_x = CEIL_DIV(DEVICE_WIDTH, src_w);
			int scale_y = CEIL_DIV(DEVICE_HEIGHT, src_h);
			scale = MIN(scale_x, scale_y);

			sprintf(scaler_name, "cropped");
			dst_w = DEVICE_WIDTH;
			dst_h = DEVICE_HEIGHT;
			dst_p = DEVICE_PITCH;

			int scaled_w = src_w * scale;
			int scaled_h = src_h * scale;

			int ox = (DEVICE_WIDTH - scaled_w) / 2;
			int oy = (DEVICE_HEIGHT - scaled_h) / 2;

			if (ox < 0) {
				src_x = -ox / scale;
				src_w -= src_x * 2;
			} else {
				dst_x = ox;
			}

			if (oy < 0) {
				src_y = -oy / scale;
				src_h -= src_y * 2;
			} else {
				dst_y = oy;
			}
		}
		else {
			sprintf(scaler_name, "integer");
			int scaled_w = src_w * scale;
			int scaled_h = src_h * scale;
			dst_w = DEVICE_WIDTH;
			dst_h = DEVICE_HEIGHT;
			dst_p = DEVICE_PITCH;
			dst_x = (DEVICE_WIDTH - scaled_w) / 2;
			dst_y = (DEVICE_HEIGHT - scaled_h) / 2;
		}
	}
	else if (fit) {
		if (scaling == SCALE_FULLSCREEN) {
			sprintf(scaler_name, "full fit");
			dst_w = DEVICE_WIDTH;
			dst_h = DEVICE_HEIGHT;
			dst_p = DEVICE_PITCH;
			scale = -1;
		}
		else {
			double scale_f = MIN(((double)DEVICE_WIDTH) / aspect_w, ((double)DEVICE_HEIGHT) / aspect_h);
			LOG_info("scale_f:%f\n", scale_f);
			
			sprintf(scaler_name, "aspect fit");
			dst_w = aspect_w * scale_f;
			dst_h = aspect_h * scale_f;
			dst_w = (dst_w + 7) & ~7;  // ← выравнивание
			dst_p = DEVICE_PITCH;      // ← pitch фиксированный, но убедитесь, что DEVICE_PITCH >= dst_w * 2!
			dst_x = (DEVICE_WIDTH - dst_w) / 2;
			dst_y = (DEVICE_HEIGHT - dst_h) / 2;
			scale = (scale_f == 1.0 && dst_w == src_w && dst_h == src_h) ? 1 : -1;
		}
	}
	else {
		int scale_x = CEIL_DIV(DEVICE_WIDTH, src_w);
		int scale_y = CEIL_DIV(DEVICE_HEIGHT, src_h);
		int r = (DEVICE_HEIGHT - src_h) % 8;
		if (r && r < 8) scale_y -= 1;
		
		scale = MAX(scale_x, scale_y);
		int scaled_w = src_w * scale;
		int scaled_h = src_h * scale;
		
		if (scaling == SCALE_FULLSCREEN) {
			sprintf(scaler_name, "full%i", scale);
			dst_w = scaled_w;
			dst_h = scaled_h;
			dst_w = (dst_w + 7) & ~7;        // ← выравнивание
			dst_p = dst_w * FIXED_BPP;       // ← pitch = ширина * 2
		}
		else {
			double src_aspect_ratio = ((double)src_w) / src_h;
			double fixed_aspect_ratio = ((double)DEVICE_WIDTH) / DEVICE_HEIGHT;
			int core_aspect = core.aspect_ratio * 1000;
			int fixed_aspect = fixed_aspect_ratio * 1000;
			
			if (core_aspect > fixed_aspect) {
				sprintf(scaler_name, "aspect%iL", scale);
				int aspect_h_val = DEVICE_WIDTH / core.aspect_ratio;
				double aspect_hr = ((double)aspect_h_val) / DEVICE_HEIGHT;
				dst_w = scaled_w;
				dst_h = scaled_h / aspect_hr;
				dst_w = (dst_w + 7) & ~7;
				dst_p = dst_w * FIXED_BPP;
				dst_y = (dst_h - scaled_h) / 2;
			}
			else if (core_aspect < fixed_aspect) {
				sprintf(scaler_name, "aspect%iP", scale);
				int aspect_w_val = DEVICE_HEIGHT * core.aspect_ratio;
				double aspect_wr = ((double)aspect_w_val) / DEVICE_WIDTH;
				dst_w = scaled_w / aspect_wr;
				dst_h = scaled_h;
				dst_w = (dst_w + 7) & ~7;        // ← критически важно
				dst_p = dst_w * FIXED_BPP;       // ← обязательно!
				dst_x = (dst_w - scaled_w) / 2;
			}
			else {
				sprintf(scaler_name, "aspect%iM", scale);
				dst_w = scaled_w;
				dst_h = scaled_h;
				dst_w = (dst_w + 7) & ~7;
				dst_p = dst_w * FIXED_BPP;
			}
		}
	}

	// Заполняем renderer
	renderer.src_x = src_x;
	renderer.src_y = src_y;
	renderer.src_w = src_w;
	renderer.src_h = src_h;
	renderer.src_p = src_p;
	renderer.dst_x = dst_x;
	renderer.dst_y = dst_y;
	renderer.dst_w = dst_w;
	renderer.dst_h = dst_h;
	renderer.dst_p = dst_p;
	renderer.scale = scale;
	renderer.aspect = (scaling == SCALE_NATIVE || scaling == SCALE_CROPPED) ? 0 :
	                  (scaling == SCALE_FULLSCREEN) ? -1 : core.aspect_ratio;
	LOG_info("aspect: %f\n", renderer.aspect);
	LOG_info("selectScaler: src_w=%d, src_h=%d, aspect_ratio=%f\n", src_w, src_h, core.aspect_ratio);
	renderer.blit = GFX_getScaler(&renderer);

	if (fit) {
		dst_w = DEVICE_WIDTH;
		dst_h = DEVICE_HEIGHT;
	}

	screen = GFX_resize(dst_w, dst_h, dst_p);

	// DEBUG HUD
	if (scaler_surface) 
		SDL_FreeSurface(scaler_surface);
	scaler_surface = TTF_RenderUTF8_Blended(font.tiny, scaler_name, COLOR_WHITE);
	last_integer_scale = scale;
	last_aspect = (float)renderer.aspect;
}

static int frame_counter = 0;
static unsigned last_width = 0, last_height = 0;

static void video_refresh_callback(const void *data, unsigned width, unsigned height, size_t pitch) {
    if (!data || width == 0 || height == 0) return;

    if (!thread_video) {
        video_refresh_callback_main(data, width, height, pitch);
        return;
    }

    // Просто сохраняем указатель — НИКАКОГО КОПИРОВАНИЯ!
    int wi = write_index;
    frame_slots[wi].data = data;
    frame_slots[wi].w = width;
    frame_slots[wi].h = height;
    frame_slots[wi].pitch = pitch;
    frame_slots[wi].ready = 1;

    pthread_mutex_lock(&buffer_swap_mutex);
    read_index = wi;
    write_index = 1 - wi;
    pthread_mutex_unlock(&buffer_swap_mutex);
}

static void video_refresh_callback_main(const void *data, unsigned width, unsigned height, size_t pitch) {
    static uint32_t last_flip_time = 0;
    static uint32_t last_debug_update = 0;
    static unsigned last_width = 0, last_height = 0;
    static int frame_counter = 0;

    if (frame_counter < 3 || width != last_width || height != last_height) {
        LOG_info("VIDEO_REFRESH_CALLBACK [frame=%d]:\n", frame_counter);
        LOG_info("  width=%u, height=%u, pitch=%zu\n", width, height, pitch);
        LOG_info("  renderer.true_w=%d, renderer.true_h=%d\n",
                 renderer.true_w, renderer.true_h);
        LOG_info("  renderer.dst_p=%d\n", renderer.dst_p);
        LOG_info("  renderer.aspect=%f\n", renderer.aspect);
        last_width = width;
        last_height = height;
    }
    frame_counter++;

    // Fast-forward скип
    if (fast_forward && SDL_GetTicks() - last_flip_time < 10) return;

    fps_ticks += 1;

    // Смена разрешения → пересоздать скалер
    if (renderer.dst_p == 0 || width != renderer.true_w || height != renderer.true_h) {
        selectScaler(width, height, pitch);
        GFX_clearAll();
    }

    // === 🔥 АВТОСКИП В FAST-РЕЖИМЕ ===
    if (frame_skip_enabled && !show_menu) {
        static int frame_counter_skip = 0;
        frame_counter_skip++;
        if (frame_counter_skip & 1) { // пропускаем нечётные кадры
            return;
        }
    }

    // Подготовка данных для рендерера
    if (downsample) {
        buffer_downsample(data, width, height, pitch);
        renderer.src = buffer;
    } else {
        renderer.src = (void*)data;
    }

    // Обновление отладочного HUD
    if (show_debug > DEBUG_OFF) {
        uint32_t current_time = SDL_GetTicks();
        if (current_time - last_debug_update >= 1000) {
            char debug_text[256] = "";
            char cpu_text[128] = "";
            int charge = 0;
            int active_cores = 0;

            if (show_debug >= DEBUG_BATTERY) {
                FILE* bat_fp = fopen("/sys/class/power_supply/battery/capacity", "r");
                if (bat_fp) {
                    fscanf(bat_fp, "%d", &charge);
                    fclose(bat_fp);
                }
            }

            if (show_debug == DEBUG_FPS_BATTERY_CPU) {
                active_cores = get_active_cpu_count();
                if (active_cores < 0) active_cores = 0;
            }

            if (show_debug == DEBUG_FPS_BATTERY_CPU && active_cores > 0) {
                active_cores = get_active_cpu_count();
                if (active_cores < 0) active_cores = 0;
                
                // Получаем загрузку активных ядер
                
                if (active_cores > 0) {
                    static unsigned long long prev_idle[32] = {0};
                    static unsigned long long prev_total[32] = {0};
                    static int first_run = 1;
                    
                    FILE* fp = fopen("/proc/stat", "r");
                    if (fp) {
                        char line[256];
                        int core_index = 0;
                        
                        // Читаем общую статистику (cpu)
                        fgets(line, sizeof(line), fp);
                        
                        // Читаем статистику для каждого ядра
                        for (int i = 0; i < 32; i++) {
                            if (!fgets(line, sizeof(line), fp)) break;
                            
                            if (strncmp(line, "cpu", 3) != 0) continue;
                            
                            int core_num;
                            if (sscanf(line, "cpu%d", &core_num) != 1) continue;
                            
                            // Проверяем, активно ли это ядро
                            char cpu_online_path[64];
                            snprintf(cpu_online_path, sizeof(cpu_online_path), 
                                    "/sys/devices/system/cpu/cpu%d/online", core_num);
                            
                            if (core_num > 0 && access(cpu_online_path, F_OK) == 0) {
                                FILE* online_fp = fopen(cpu_online_path, "r");
                                if (online_fp) {
                                    char status;
                                    if (fread(&status, 1, 1, online_fp) == 1 && status == '0') {
                                        fclose(online_fp);
                                        continue;
                                    }
                                    fclose(online_fp);
                                }
                            }
                            
                            unsigned long long user, nice, system, idle, iowait, irq, softirq, steal;
                            unsigned long long total, idle_time;
                            
                            sscanf(line + 5, "%llu %llu %llu %llu %llu %llu %llu %llu",
                                   &user, &nice, &system, &idle, &iowait, 
                                   &irq, &softirq, &steal);
                            
                            idle_time = idle + iowait;
                            total = user + nice + system + idle_time + irq + softirq + steal;
                            
                            if (!first_run && prev_total[core_num] > 0) {
                                unsigned long long total_diff = total - prev_total[core_num];
                                unsigned long long idle_diff = idle_time - prev_idle[core_num];
                                if (total_diff > 0) {
                                    float load = 100.0f * (total_diff - idle_diff) / total_diff;
                                    
                                    char core_text[16];
                                    sprintf(core_text, " %d:%.0f%%", core_num, load);
                                    strcat(cpu_text, core_text);
                                }
                            }
                            
                            prev_idle[core_num] = idle_time;
                            prev_total[core_num] = total;
                        }
                        fclose(fp);
                        first_run = 0;
                    }
                }
                
                // Формируем полную строку
                if (strlen(cpu_text) > 0) {
                    sprintf(debug_text, "%.1ffps %d%% cpu(%d)%s", 
                            fps_double, charge, active_cores, cpu_text);
                } else {
                    sprintf(debug_text, "%.1ffps %d%% cpu:%d", 
                            fps_double, charge, active_cores);
                }
            }

            // Формирование строки
            if (show_debug == DEBUG_FPS_BATTERY_CPU && strlen(cpu_text) > 0) {
                sprintf(debug_text, "%.1ffps %d%% cpu(%d)%s", fps_double, charge, active_cores, cpu_text);
            } else if (show_debug == DEBUG_FPS_BATTERY) {
                sprintf(debug_text, "%.1ffps %d%%", fps_double, charge);
            } else if (show_debug == DEBUG_BATTERY) {
                sprintf(debug_text, "%d%%", charge);
            } else if (show_debug == DEBUG_FPS) {
                sprintf(debug_text, "%.1ffps", fps_double);
            }

            set_debug_text(debug_text);
            last_debug_update = current_time;
        }
    }

    // Смена разрешения → пересоздать скалер
    if (renderer.dst_p == 0 || width != renderer.true_w || height != renderer.true_h) {
        selectScaler(width, height, pitch);
        GFX_clearAll();
    }

    // Подготовка данных для рендерера
    const void* render_src = data; // ← это безопасно в основном потоке
	if (downsample) {
    	buffer_downsample(data, width, height, pitch);
    	render_src = buffer;
	}
	renderer.src = (void*)render_src; // ← временно, только для скалера
    renderer.dst = screen->pixels;
    GFX_blitRenderer(&renderer);
	GFX_flip(screen); // ← ОБЯЗАТЕЛЬНО!
    last_flip_time = SDL_GetTicks();
}

///////////////////////////////

// NOTE: sound must be disabled for fast forward to work...
static void audio_sample_callback(int16_t left, int16_t right) {
    if (!fast_forward && !disable_sound_init) {
        SND_batchSamples(&(const SND_Frame){left, right}, 1);
    }
}

static size_t audio_sample_batch_callback(const int16_t *data, size_t frames) { 
    if (!fast_forward && !disable_sound_init) {
        return SND_batchSamples((const SND_Frame*)data, frames);
    } else {
        return frames;
    }
}

///////////////////////////////////////

void Core_getName(char* in_name, char* out_name) {
    if (!in_name || !out_name) {
        LOG_error("Core_getName: invalid parameters\n");
        if (out_name) out_name[0] = '\0';
        return;
    }
    
    LOG_info("Core_getName input: '%s'\n", in_name);
    
    // Создаем копию для безопасной обработки
    char temp_name[MAX_PATH];
    strncpy(temp_name, in_name, sizeof(temp_name) - 1);
    temp_name[sizeof(temp_name) - 1] = '\0';
    
    // Берем только имя файла (без пути)
    char* base = basename(temp_name);
    LOG_info("Basename: '%s'\n", base);
    
    // Копируем базовое имя
    strncpy(out_name, base, MAX_PATH - 1);
    out_name[MAX_PATH - 1] = '\0';
    
    // Убираем расширение .so
    char* dot = strrchr(out_name, '.');
    if (dot && (strcmp(dot, ".so") == 0 || strcmp(dot, ".dll") == 0)) {
        *dot = '\0';
    }
    
    // Убираем суффикс _libretro если есть
    char* suffix = strstr(out_name, "_libretro");
    if (suffix) {
        *suffix = '\0';
    }
    
    LOG_info("Core_getName output: '%s'\n", out_name);
}
void Core_open(const char* core_path, const char* tag_name) {
	LOG_info("Core_open\n");
	core.handle = dlopen(core_path, RTLD_LAZY);
	
	if (!core.handle) LOG_error("%s\n", dlerror());
	
	core.init = dlsym(core.handle, "retro_init");
	core.deinit = dlsym(core.handle, "retro_deinit");
	core.get_system_info = dlsym(core.handle, "retro_get_system_info");
	core.get_system_av_info = dlsym(core.handle, "retro_get_system_av_info");
	core.set_controller_port_device = dlsym(core.handle, "retro_set_controller_port_device");
	core.reset = dlsym(core.handle, "retro_reset");
	core.run = dlsym(core.handle, "retro_run");
	core.serialize_size = dlsym(core.handle, "retro_serialize_size");
	core.serialize = dlsym(core.handle, "retro_serialize");
	core.unserialize = dlsym(core.handle, "retro_unserialize");
	core.load_game = dlsym(core.handle, "retro_load_game");
	core.load_game_special = dlsym(core.handle, "retro_load_game_special");
	core.unload_game = dlsym(core.handle, "retro_unload_game");
	core.get_region = dlsym(core.handle, "retro_get_region");
	core.get_memory_data = dlsym(core.handle, "retro_get_memory_data");
	core.get_memory_size = dlsym(core.handle, "retro_get_memory_size");
	
	void (*set_environment_callback)(retro_environment_t);
	void (*set_video_refresh_callback)(retro_video_refresh_t);
	void (*set_audio_sample_callback)(retro_audio_sample_t);
	void (*set_audio_sample_batch_callback)(retro_audio_sample_batch_t);
	void (*set_input_poll_callback)(retro_input_poll_t);
	void (*set_input_state_callback)(retro_input_state_t);
	
	set_environment_callback = dlsym(core.handle, "retro_set_environment");
	set_video_refresh_callback = dlsym(core.handle, "retro_set_video_refresh");
	set_audio_sample_callback = dlsym(core.handle, "retro_set_audio_sample");
	set_audio_sample_batch_callback = dlsym(core.handle, "retro_set_audio_sample_batch");
	set_input_poll_callback = dlsym(core.handle, "retro_set_input_poll");
	set_input_state_callback = dlsym(core.handle, "retro_set_input_state");
	
	struct retro_system_info info = {};
	core.get_system_info(&info);
	
	Core_getName((char*)core_path, (char*)core.name);
	sprintf((char*)core.version, "%s (%s)", info.library_name, info.library_version);
	strcpy((char*)core.tag, tag_name);
	strcpy((char*)core.extensions, info.valid_extensions);
	
	core.need_fullpath = info.need_fullpath;
	
	LOG_info("core: %s version: %s tag: %s (valid_extensions: %s need_fullpath: %i)\n", core.name, core.version, core.tag, info.valid_extensions, info.need_fullpath);
	
	sprintf((char*)core.config_dir, USERDATA_PATH "/%s-%s", core.tag, core.name);
	sprintf((char*)core.states_dir, SHARED_USERDATA_PATH "/%s-%s", core.tag, core.name);
	sprintf((char*)core.saves_dir, SDCARD_PATH "/Saves/%s", core.tag);
	sprintf((char*)core.bios_dir, SDCARD_PATH "/Bios/%s", core.tag);
	
	char cmd[512];
	sprintf(cmd, "mkdir -p \"%s\"; mkdir -p \"%s\"", core.config_dir, core.states_dir);
	system(cmd);

	set_environment_callback(environment_callback);
	set_video_refresh_callback(video_refresh_callback);
	set_audio_sample_callback(audio_sample_callback);
	set_audio_sample_batch_callback(audio_sample_batch_callback);
	set_input_poll_callback(input_poll_callback);
	set_input_state_callback(input_state_callback);
}
void Core_init(void) {
	LOG_info("Core_init\n");
	core.init();
	core.initialized = 1;
}
void Core_load(void) {
    LOG_info("Core_load\n");
    struct retro_game_info game_info;
    game_info.path = game.tmp_path[0]?game.tmp_path:game.path;
    game_info.data = game.data;
    game_info.size = game.size;
    
    core.load_game(&game_info);
    
    SRAM_read();
    RTC_read();
    
    // NOTE: must be called after core.load_game!
    struct retro_system_av_info av_info = {};
    core.get_system_av_info(&av_info);

    // ДЕБАГ: логируем информацию от ядра
    LOG_info("CORE INFO FROM GET_SYSTEM_AV_INFO:\n");
    LOG_info("  Geometry: base=%dx%d, max=%dx%d, aspect_ratio=%f\n",
        av_info.geometry.base_width, av_info.geometry.base_height,
        av_info.geometry.max_width, av_info.geometry.max_height,
        av_info.geometry.aspect_ratio);
    LOG_info("  Timing: fps=%f, sample_rate=%f\n",
        av_info.timing.fps, av_info.timing.sample_rate);

    // FIX: some cores need configure a default controller.
    core.set_controller_port_device(0, RETRO_DEVICE_JOYPAD); // set a default, may update after loading configs

    core.fps = av_info.timing.fps;
    core.sample_rate = av_info.timing.sample_rate;
    double a = av_info.geometry.aspect_ratio;
    if (a<=0) {
        LOG_info("  Aspect ratio <=0, calculating from base: %f\n", 
            (double)av_info.geometry.base_width / av_info.geometry.base_height);
        a = (double)av_info.geometry.base_width / av_info.geometry.base_height;
    }
    core.aspect_ratio = a;
    
    LOG_info("  Final core.aspect_ratio = %f\n", core.aspect_ratio);
    LOG_info("  Final core.fps = %f\n", core.fps);
    
    LOG_info("aspect_ratio: %f fps: %f\n", a, core.fps);
}
void Core_reset(void) {
	core.reset();
}
void Core_unload(void) {
	SND_quit();
}
void Core_quit(void) {
	if (core.initialized) {
		SRAM_write();
		RTC_write();
		core.unload_game();
		core.deinit();
		core.initialized = 0;
	}
}
void Core_close(void) {
	if (core.handle) dlclose(core.handle);
}

///////////////////////////////////////

#define MENU_ITEM_COUNT 6
#define MENU_SLOT_COUNT 8

enum {
	ITEM_CONT,
	ITEM_SAVE,
	ITEM_LOAD,
	ITEM_OPTS,
	ITEM_INFO,
	ITEM_QUIT,
};

enum {
	STATUS_CONT =  0,
	STATUS_SAVE =  1,
	STATUS_LOAD = 11,
	STATUS_OPTS = 23,
	STATUS_DISC = 24,
	STATUS_QUIT = 30,
	STATUS_RESET= 31,
	STATUS_INFO = 40,
};

// TODO: I don't love how overloaded this has become
static struct {
	SDL_Surface* bitmap;
	SDL_Surface* cached_preview;
	SDL_Surface* overlay;
	char* items[MENU_ITEM_COUNT];
	char* disc_paths[9]; // up to 9 paths, Arc the Lad Collection is 7 discs
	char minui_dir[256];
	char slot_path[256];
	char base_path[256];
	char bmp_path[256];
	char txt_path[256];
	int disc;
	int total_discs;
	int slot;
	int save_exists;
	int preview_exists;
    int cached_slot; 
} menu = {
	.bitmap = NULL,
	.disc = -1,
	.total_discs = 0,
	.save_exists = 0,
	.preview_exists = 0,
	
	.items = {
		[ITEM_CONT] = "CONTINUE",
		[ITEM_SAVE] = "SAVE",
		[ITEM_LOAD] = "LOAD",
		[ITEM_OPTS] = "SETTINGS",
		[ITEM_INFO] = "INFORMATION",
		[ITEM_QUIT] = "OUT",
		
	}
};

void Menu_init(void) {
	menu.overlay = SDL_CreateRGBSurface(SDL_SWSURFACE,DEVICE_WIDTH,DEVICE_HEIGHT,FIXED_DEPTH,RGBA_MASK_AUTO);
	SDLX_SetAlpha(menu.overlay, SDL_SRCALPHA, 0x80);
	SDL_FillRect(menu.overlay, NULL, 0);
	
	char emu_name[256];
	getEmuName(game.path, emu_name);
	sprintf(menu.minui_dir, SHARED_USERDATA_PATH "/.minui/%s", emu_name);
	mkdir(menu.minui_dir, 0755);

	sprintf(menu.slot_path, "%s/%s.txt", menu.minui_dir, game.name);
	
	if (simple_mode || emulators_settings_hide) menu.items[ITEM_OPTS] = "RESET";
	
	if (game.m3u_path[0]) {
		char* tmp;
		strcpy(menu.base_path, game.m3u_path);
		tmp = strrchr(menu.base_path, '/') + 1;
		tmp[0] = '\0';
		
		//read m3u file
		FILE* file = fopen(game.m3u_path, "r");
		if (file) {
			char line[256];
			while (fgets(line,256,file)!=NULL) {
				normalizeNewline(line);
				trimTrailingNewlines(line);
				if (strlen(line)==0) continue; // skip empty lines
		
				char disc_path[256];
				strcpy(disc_path, menu.base_path);
				tmp = disc_path + strlen(disc_path);
				strcpy(tmp, line);
				
				// found a valid disc path
				if (exists(disc_path)) {
					menu.disc_paths[menu.total_discs] = strdup(disc_path);
					// matched our current disc
					if (exactMatch(disc_path, game.path)) {
						menu.disc = menu.total_discs;
					}
					menu.total_discs += 1;
				}
			}
			fclose(file);
		}
	}
}
void Menu_quit(void) {
	SDL_FreeSurface(menu.overlay);
}
void Menu_beforeSleep(void) {
	SRAM_write();
	RTC_write();
	State_autosave();
	putFile(AUTO_RESUME_PATH, game.path + strlen(SDCARD_PATH));
	PWR_setCPUSpeed(CPU_SPEED_MENU);
}
void Menu_afterSleep(void) {
	unlink(AUTO_RESUME_PATH);
	setOverclock(overclock);
}

typedef struct MenuList MenuList;
typedef struct MenuItem MenuItem;
enum {
	MENU_CALLBACK_NOP,
	MENU_CALLBACK_EXIT,
	MENU_CALLBACK_NEXT_ITEM,
};
typedef int (*MenuList_callback_t)(MenuList* list, int i);
typedef struct MenuItem {
	char* name;
	char* desc;
	char** values;
	char* key; // optional, used by options
	int id; // optional, used by bindings
	int value;
	MenuList* submenu;
	MenuList_callback_t on_confirm;
	MenuList_callback_t on_change;
} MenuItem;

enum {
	MENU_LIST, // eg. save and main menu
	MENU_VAR, // eg. frontend
	MENU_FIXED, // eg. emulator
	MENU_INPUT, // eg. renders like but MENU_VAR but handles input differently
};
typedef struct MenuList {
	int type;
	int max_width; // cached on first draw
	char* desc;
	MenuItem* items;
	MenuList_callback_t on_confirm;
	MenuList_callback_t on_change;
} MenuList;

static int Menu_message(char* message, char** pairs) {
	GFX_setMode(MODE_MAIN);
	int dirty = 1;
	while (1) {
		GFX_startFrame();
		PAD_poll();

		if (PAD_justPressed(BTN_A) || PAD_justPressed(BTN_B)) break;
		
		PWR_update(&dirty, NULL, Menu_beforeSleep, Menu_afterSleep);
		
		if (dirty) {
			GFX_clear(screen);
			SDL_FillRect(screen, &(SDL_Rect){0, 0, DEVICE_WIDTH, DEVICE_HEIGHT}, SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
			GFX_blitMessage(font.medium, message, screen, &(SDL_Rect){0,SCALE1(PADDING),screen->w,screen->h-SCALE1(PILL_SIZE+PADDING)});
			GFX_blitButtonGroup(pairs, 0, screen, 1);
			GFX_flip(screen);
			dirty = 0;
		}
		else GFX_sync();
	}
	GFX_setMode(MODE_MENU);
	return MENU_CALLBACK_NOP; // TODO: this should probably be an arg
}

#define OPTION_PADDING 8
#define MAX_VISIBLE_OPTIONS 7
static int Menu_options(MenuList* list);

static int MenuList_freeItems(MenuList* list, int i) {
	// TODO: what calls this? do menu's register for needing it? then call it on quit for each?
	if (list->items) free(list->items);
	return MENU_CALLBACK_NOP;
}

static int OptionFrontend_optionChanged(MenuList* list, int i) {
    MenuItem* item = &list->items[i];
    
    // Получаем старое значение из конфига
    Option* option = OptionList_getOption(&config.frontend, item->key);
    if (option) {
        int old_value = option->value;
        
        // Сохраняем новое значение
        Config_syncFrontend(item->key, item->value);
        
        // Проверяем, изменился ли render_mode
        if (strcmp(item->key, "minarch_render_mode") == 0 && 
            old_value != item->value) {
            // Немедленно показываем сообщение
            PLAT_showPopup(language_get_string("DO_SAVE_REBOOT"));
        }
    }
    
    return MENU_CALLBACK_NOP;
}

static MenuList OptionFrontend_menu = {
	.type = MENU_VAR,
	.on_change = OptionFrontend_optionChanged,
	.items = NULL,
};
static int OptionFrontend_openMenu(MenuList* list, int i) {
	if (OptionFrontend_menu.items==NULL) {
		// TODO: where do I free this? I guess I don't :sweat_smile:
		config.frontend.options[FE_OPT_DEBUG].lock = 0;
		if (!config.frontend.enabled_count) {
			int enabled_count = 0;
			for (int i=0; i<config.frontend.count; i++) {
				if (!config.frontend.options[i].lock) enabled_count += 1;
			}
			config.frontend.enabled_count = enabled_count;
			config.frontend.enabled_options = calloc(enabled_count+1, sizeof(Option*));
			int j = 0;
			for (int i=0; i<config.frontend.count; i++) {
				Option* item = &config.frontend.options[i];
				if (item->lock) continue;
				config.frontend.enabled_options[j] = item;
				j += 1;
			}
		}

		OptionFrontend_menu.items = calloc(config.frontend.enabled_count+1, sizeof(MenuItem));
		for (int j=0; j<config.frontend.enabled_count; j++) {
			Option* option = config.frontend.enabled_options[j];
			MenuItem* item = &OptionFrontend_menu.items[j];
			item->key = option->key;
			item->name = option->name;
			item->desc = option->desc;
			item->value = option->value;
			item->values = option->labels;
		}
	}
	else {
		// update values
		for (int j=0; j<config.frontend.enabled_count; j++) {
			Option* option = config.frontend.enabled_options[j];
			MenuItem* item = &OptionFrontend_menu.items[j];
			item->value = option->value;
		}
	}
	
	Menu_options(&OptionFrontend_menu);
	return MENU_CALLBACK_NOP;
}

static int OptionEmulator_optionChanged(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	Option* option = OptionList_getOption(&config.core, item->key);
	LOG_info("%s (%s) changed from `%s` (%s) to `%s` (%s)\n", item->name, item->key, 
		item->values[option->value], option->values[option->value], 
		item->values[item->value], option->values[item->value]
	);
	OptionList_setOptionRawValue(&config.core, item->key, item->value);
	return MENU_CALLBACK_NOP;
}
static int OptionEmulator_optionDetail(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	Option* option = OptionList_getOption(&config.core, item->key);
	if (option->full) return Menu_message(option->full, (char*[]){ "B",language_get_string("BACK"), NULL });
	else return MENU_CALLBACK_NOP;
}
static MenuList OptionEmulator_menu = {
	.type = MENU_FIXED,
	.on_confirm = OptionEmulator_optionDetail, // TODO: this needs pagination to be truly useful
	.on_change = OptionEmulator_optionChanged,
	.items = NULL,
};
static int OptionEmulator_openMenu(MenuList* list, int i) {
	if (OptionEmulator_menu.items==NULL) {
		// TODO: where do I free this? I guess I don't :sweat_smile:
		if (!config.core.enabled_count) {
			int enabled_count = 0;
			for (int i=0; i<config.core.count; i++) {
				if (!config.core.options[i].lock) enabled_count += 1;
			}
			config.core.enabled_count = enabled_count;
			config.core.enabled_options = calloc(enabled_count+1, sizeof(Option*));
			int j = 0;
			for (int i=0; i<config.core.count; i++) {
				Option* item = &config.core.options[i];
				if (item->lock) continue;
				config.core.enabled_options[j] = item;
				j += 1;
			}
		}
		
		OptionEmulator_menu.items = calloc(config.core.enabled_count+1, sizeof(MenuItem));
		for (int j=0; j<config.core.enabled_count; j++) {
			Option* option = config.core.enabled_options[j];
			MenuItem* item = &OptionEmulator_menu.items[j];
			item->key = option->key;
			item->name = option->name;
			item->desc = option->desc;
			item->value = option->value;
			item->values = option->labels;
		}
	}
	else {
		// update values
		for (int j=0; j<config.core.enabled_count; j++) {
			Option* option = config.core.enabled_options[j];
			MenuItem* item = &OptionEmulator_menu.items[j];
			item->value = option->value;
		}
	}
	
	if (OptionEmulator_menu.items[0].name) { // TODO: why doesn't this just use (enabled_)count?
		Menu_options(&OptionEmulator_menu);
	}
	else {
		Menu_message(language_get_string("CORE_NO_OPTIONS"), (char*[]){ "B",language_get_string("BACK"), NULL });
	}
	
	return MENU_CALLBACK_NOP;
}

int OptionControls_bind(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	if (item->values!=button_labels) {
		// LOG_info("changed gamepad_type\n");
		return MENU_CALLBACK_NOP;
	}
	
	ButtonMapping* button = &config.controls[item->id];
	
	int bound = 0;
	while (!bound) {
		GFX_startFrame();
		PAD_poll();
		
		// NOTE: off by one because of the initial NONE value
		for (int id=0; id<=LOCAL_BUTTON_COUNT; id++) {
			if (PAD_justPressed(1 << (id-1))) {
				item->value = id;
				button->local = id - 1;
				if (PAD_isPressed(BTN_MENU)) {
					item->value += LOCAL_BUTTON_COUNT;
					button->mod = 1;
				}
				else {
					button->mod = 0;
				}
				bound = 1;
				break;
			}
		}
		GFX_sync();
	}
	return MENU_CALLBACK_NEXT_ITEM;
}
static int OptionControls_unbind(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	if (item->values!=button_labels) return MENU_CALLBACK_NOP;
	
	ButtonMapping* button = &config.controls[item->id];
	button->local = -1;
	button->mod = 0;
	return MENU_CALLBACK_NOP;
}
/*
static int OptionControls_optionChanged(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	if (item->values!=gamepad_labels) return MENU_CALLBACK_NOP;
	
	if (has_custom_controllers) {
		gamepad_type = item->value;
		int device = strtol(gamepad_values[item->value], NULL, 0);
		core.set_controller_port_device(0, device);
	}
	
	return MENU_CALLBACK_NOP;
}
*/
MenuList OptionControls_menu = {
	.type = MENU_INPUT,
	.desc = "Нажмите А для назначения или Х для очистки." 
		"\nПоддерживается отдельная кнопка или сочетание МЕНЮ + кнопка." // TODO: not supported on nano because POWER doubles as MENU
	,
	.on_confirm = OptionControls_bind,
	.on_change = OptionControls_unbind,
	.items = NULL
};
static int OptionControls_openMenu(MenuList* list, int i) {
	LOG_info("OptionControls_openMenu\n");
	if (OptionControls_menu.items==NULL) {
		// TODO: where do I free this?
		OptionControls_menu.items = calloc(RETRO_BUTTON_COUNT+1, sizeof(MenuItem));
		int k = 0;
		/*
		if (has_custom_controllers) {
			MenuItem* item = &OptionControls_menu.items[k++];
			item->name = "Controller";
			item->desc = "Select the type of controller.";
			item->value = gamepad_type;
			item->values = gamepad_labels;
			item->on_change = OptionControls_optionChanged;
		}
		*/
		for (int j=0; config.controls[j].name; j++) {
			ButtonMapping* button = &config.controls[j];
			if (button->ignore) continue;
			
			LOG_info("\t%s (%i:%i)\n", button->name, button->local, button->retro);
			
			MenuItem* item = &OptionControls_menu.items[k++];
			item->id = j;
			item->name = button->name;
			item->desc = NULL;
			item->value = button->local + 1;
			if (button->mod) item->value += LOCAL_BUTTON_COUNT;
			item->values = button_labels;
		}
	}
	else {
		// update values
		int k = 0;
		/*
		if (has_custom_controllers) {
			MenuItem* item = &OptionControls_menu.items[k++];
			item->value = gamepad_type;
		}
		*/
		for (int j=0; config.controls[j].name; j++) {
			ButtonMapping* button = &config.controls[j];
			if (button->ignore) continue;
			
			MenuItem* item = &OptionControls_menu.items[k++];
			item->value = button->local + 1;
			if (button->mod) item->value += LOCAL_BUTTON_COUNT;
		}
	}
	Menu_options(&OptionControls_menu);
	return MENU_CALLBACK_NOP;
}

static int OptionShortcuts_bind(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	ButtonMapping* button = &config.shortcuts[item->id];
	int bound = 0;
	while (!bound) {
		GFX_startFrame();
		PAD_poll();
		
		// NOTE: off by one because of the initial NONE value
		for (int id=0; id<=LOCAL_BUTTON_COUNT; id++) {
			if (PAD_justPressed(1 << (id-1))) {
				item->value = id;
				button->local = id - 1;
				if (PAD_isPressed(BTN_MENU)) {
					item->value += LOCAL_BUTTON_COUNT;
					button->mod = 1;
				}
				else {
					button->mod = 0;
				}
				bound = 1;
				break;
			}
		}
		GFX_sync();
	}
	return MENU_CALLBACK_NEXT_ITEM;
}
static int OptionShortcuts_unbind(MenuList* list, int i) {
	MenuItem* item = &list->items[i];
	ButtonMapping* button = &config.shortcuts[item->id];
	button->local = -1;
	button->mod = 0;
	return MENU_CALLBACK_NOP;
}
MenuList OptionShortcuts_menu = {
	.type = MENU_INPUT,
	.desc = "Нажмите А для назначения или Х для очистки." 
		"\nПоддерживается отдельная кнопка или сочетание МЕНЮ + кнопка." // TODO: not supported on nano because POWER doubles as MENU
	,
	.on_confirm = OptionShortcuts_bind,
	.on_change = OptionShortcuts_unbind,
	.items = NULL
};
static char* getSaveDesc(void) {
	switch (config.loaded) {
		case CONFIG_NONE:		return language_get_string("CONFIG_NONE"); break;
		case CONFIG_CONSOLE:	return language_get_string("CONFIG_CONSOLE"); break;
		case CONFIG_GAME:		return language_get_string("CONFIG_GAME"); break;
	}
	return NULL;
}
static int OptionShortcuts_openMenu(MenuList* list, int i) {
	if (OptionShortcuts_menu.items==NULL) {
		// TODO: where do I free this? I guess I don't :sweat_smile:
		OptionShortcuts_menu.items = calloc(SHORTCUT_COUNT+1, sizeof(MenuItem));
		for (int j=0; config.shortcuts[j].name; j++) {
			ButtonMapping* button = &config.shortcuts[j];
			MenuItem* item = &OptionShortcuts_menu.items[j];
			item->id = j;
			item->name = language_get_string(shortcuts_key[j]);
			item->desc = NULL;
			item->value = button->local + 1;
			if (button->mod) item->value += LOCAL_BUTTON_COUNT;
			item->values = button_labels;
		}
	}
	else {
		// update values
		for (int j=0; config.shortcuts[j].name; j++) {
			ButtonMapping* button = &config.shortcuts[j];
			MenuItem* item = &OptionShortcuts_menu.items[j];
			item->value = button->local + 1;
			if (button->mod) item->value += LOCAL_BUTTON_COUNT;
		}
	}
	Menu_options(&OptionShortcuts_menu);
	return MENU_CALLBACK_NOP;
}

static void OptionSaveChanges_updateDesc(void);
static int OptionSaveChanges_onConfirm(MenuList* list, int i) {
	char* message;
	switch (i) {
		case 0: {
			Config_write(CONFIG_WRITE_ALL);
			message = language_get_string("CONFIG_WRITE_ALL");
			break;
		}
		case 1: {
			Config_write(CONFIG_WRITE_GAME);
			message = language_get_string("CONFIG_WRITE_GAME");
			break;
		}
		default: {
			Config_restore();
			message = language_get_string("CONFIG_RESTORE");
			break;
		}
	}
	Menu_message(message, (char*[]){ "A",language_get_string("OK"), NULL });
	OptionSaveChanges_updateDesc();
	return MENU_CALLBACK_EXIT;
}
MenuList OptionSaveChanges_menu = {
	.type = MENU_LIST,
	.on_confirm = OptionSaveChanges_onConfirm,
	.items = (MenuItem[]){
		{"Сохранить для ядра"},
		{"Сохранить в игре"},
		{"Восстановить стандартные"},
		{NULL},
	}
};
static int OptionSaveChanges_openMenu(MenuList* list, int i) {
	OptionSaveChanges_updateDesc();
	OptionSaveChanges_menu.desc = getSaveDesc();
	Menu_options(&OptionSaveChanges_menu);
	return MENU_CALLBACK_NOP;
}

static int OptionQuicksave_onConfirm(MenuList* list, int i) {
	Menu_beforeSleep();
	PWR_powerOff();
}

MenuList options_menu = {
	.type = MENU_LIST,
	.items = (MenuItem[]) {
		{"", "",.on_confirm=OptionFrontend_openMenu},
		{"",.on_confirm=OptionEmulator_openMenu},
		{"",.on_confirm=OptionControls_openMenu},
		{"",.on_confirm=OptionShortcuts_openMenu}, 
		{"",.on_confirm=OptionSaveChanges_openMenu},
		{NULL},
		{NULL},
		{NULL},
	}
};

static void OptionSaveChanges_updateDesc(void) {
	options_menu.items[4].desc = getSaveDesc();
}

static int Menu_options(MenuList* list) {
    MenuItem* items = list->items;
    int type = list->type;

    int dirty = 1;
    int show_options = 1;
    int show_settings = 0;
    int await_input = 0;
    
    int count;
    for (count=0; items[count].name; count++);
    int selected = 0;
    int start = 0;
    int end = MIN(count,MAX_VISIBLE_OPTIONS);
    int visible_rows = end;
    
    // Константы для анимации
    const int ANIMATION_SPEED = 4;
    
    // Переменные для анимации
    int anim_old_selected = 0;
    int anim_new_selected = 0;
    int anim_frame = 0;
    float anim_progress = 0.0f;
    int need_final_redraw = 0;
    
    OptionSaveChanges_updateDesc();
    
    int defer_menu = false;
    while (show_options) {
        if (await_input) {
            defer_menu = true;
            list->on_confirm(list, selected);
            
            anim_old_selected = selected;
            selected += 1;
            if (selected>=count) {
                selected = 0;
                start = 0;
                end = visible_rows;
            }
            else if (selected>=end) {
                start += 1;
                end += 1;
            }
            
            anim_new_selected = selected;
            anim_frame = ANIMATION_SPEED;
            dirty = 1;
            await_input = false;
        }
        
        GFX_startFrame();
        PAD_poll();
        
        int old_selected = selected;
        
        if (PAD_justRepeated(BTN_UP)) {
            if (selected > 0) {
                selected -= 1;
                
                if (selected < start) {
                    start -= 1;
                    end -= 1;
                }
                
                if (old_selected != selected) {
                    anim_old_selected = old_selected;
                    anim_new_selected = selected;
                    anim_frame = ANIMATION_SPEED;
                    dirty = 1;
                }
            }
        }
        else if (PAD_justRepeated(BTN_DOWN)) {
            if (selected < count - 1) {
                selected += 1;
                
                if (selected >= end) {
                    start += 1;
                    end += 1;
                }
                
                if (old_selected != selected) {
                    anim_old_selected = old_selected;
                    anim_new_selected = selected;
                    anim_frame = ANIMATION_SPEED;
                    dirty = 1;
                }
            }
        }
        else {
            MenuItem* item = &items[selected];
            if (item->values!=button_labels) { // not an input binding
                if (PAD_justRepeated(BTN_LEFT)) {
                    if (item->value>0) item->value -= 1;
                    else {
                        int j;
                        for (j=0; item->values[j]; j++);
                        item->value = j - 1;
                    }
                
                    if (item->on_change) item->on_change(list, selected);
                    else if (list->on_change) list->on_change(list, selected);
                    
                    dirty = 1;
                }
                else if (PAD_justRepeated(BTN_RIGHT)) {
                    if (item->values[item->value+1]) item->value += 1;
                    else item->value = 0;
                
                    if (item->on_change) item->on_change(list, selected);
                    else if (list->on_change) list->on_change(list, selected);
                    
                    dirty = 1;
                }
            }
        }
        
        if (PAD_justPressed(getButtonB())) {
            show_options = 0;
        }
        else if (PAD_justPressed(getButtonA())) {
            MenuItem* item = &items[selected];
            int result = MENU_CALLBACK_NOP;
            if (item->on_confirm) result = item->on_confirm(list, selected);
            else if (item->submenu) result = Menu_options(item->submenu);
            else if (list->on_confirm) {
                if (item->values==button_labels) await_input = 1;
                else result = list->on_confirm(list, selected);
            }
            if (result==MENU_CALLBACK_EXIT) show_options = 0;
            else {
                if (result==MENU_CALLBACK_NEXT_ITEM) {
                    anim_old_selected = selected;
                    selected += 1;
                    if (selected>=count) {
                        selected = 0;
                        start = 0;
                        end = visible_rows;
                    }
                    else if (selected>=end) {
                        start += 1;
                        end += 1;
                    }
                    anim_new_selected = selected;
                    anim_frame = ANIMATION_SPEED;
                }
                dirty = 1;
            }
        }
        else if (type==MENU_INPUT) {
            if (PAD_justPressed(BTN_X)) {
                MenuItem* item = &items[selected];
                item->value = 0;
                
                if (item->on_change) item->on_change(list, selected);
                else if (list->on_change) list->on_change(list, selected);
                
                anim_old_selected = selected;
                selected += 1;
                if (selected>=count) {
                    selected = 0;
                    start = 0;
                    end = visible_rows;
                }
                else if (selected>=end) {
                    start += 1;
                    end += 1;
                }
                anim_new_selected = selected;
                anim_frame = ANIMATION_SPEED;
                dirty = 1;
            }
        }
        
        if (!defer_menu) PWR_update(&dirty, &show_settings, Menu_beforeSleep, Menu_afterSleep);
        
        if (defer_menu && PAD_justReleased(BTN_MENU)) defer_menu = false;
        
        // Обновляем прогресс анимации
        if (anim_frame > 0) {
            anim_frame--;
            
            if (anim_frame == 0) {
                anim_progress = 1.0f;
                need_final_redraw = 1;
            } else {
                anim_progress = 1.0f - ((float)anim_frame / (float)ANIMATION_SPEED);
            }
            
            dirty = 1;
        }
        
        if (need_final_redraw) {
            need_final_redraw = 0;
            dirty = 1;
        }
        
        if (dirty || anim_frame > 0  || PLAT_isPopupActive()) {
            GFX_clear(screen);
            SDL_FillRect(screen, &(SDL_Rect){0, 0, DEVICE_WIDTH, DEVICE_HEIGHT}, SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
            GFX_blitHardwareGroup(screen, show_settings);
            
            char* desc = NULL;
            SDL_Surface* text;

            if (type==MENU_LIST) {
                int mw = list->max_width;
                if (!mw) {
                    for (int i=0; i<count; i++) {
                        MenuItem* item = &items[i];
                        int w = 0;
                        TTF_SizeUTF8(font.small, item->name, &w, NULL);
                        w += SCALE1(OPTION_PADDING*2);
                        if (w>mw) mw = w;
                    }
                    list->max_width = mw = MIN(mw, screen->w - SCALE1(PADDING *2));
                }
                
                int ox = (screen->w - mw) / 2;
                int oy = SCALE1(PADDING + PILL_SIZE);
                int selected_row = selected - start;
                
                // ПЕРВЫЙ ПРОХОД: рисуем ВСЕ тексты (белые, без фона)
                for (int i=start,j=0; i<end; i++,j++) {
                    MenuItem* item = &items[i];
                    int item_oy = oy + SCALE1(j * BUTTON_SIZE);
                    
                    // Все тексты белые
                    text = TTF_RenderUTF8_Blended(font.small, item->name, COLOR_WHITE);
                    SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                        ox+SCALE1(OPTION_PADDING),
                        item_oy + SCALE1(1)
                    });
                    SDL_FreeSurface(text);
                    
                    // Сохраняем описание
                    if (j==selected_row) {
                        if (item->desc) desc = item->desc;
                    }
                }
                
                // ВТОРОЙ ПРОХОД: рисуем движущийся белый фон для выделенного элемента
                if (anim_frame > 0) {
                    // Вычисляем позиции в видимой области
                    int old_j = anim_old_selected - start;
                    int new_j = anim_new_selected - start;
                    
                    if (old_j >= 0 && old_j < visible_rows && new_j >= 0 && new_j < visible_rows) {
                        int old_y = oy + SCALE1(old_j * BUTTON_SIZE);
                        int new_y = oy + SCALE1(new_j * BUTTON_SIZE);
                        
                        // Вычисляем текущую позицию
                        float current_y = old_y + (new_y - old_y) * anim_progress;
                        
                        // Получаем ширину текста
                        MenuItem* new_item = &items[anim_new_selected];
                        int new_text_width = 0;
                        TTF_SizeUTF8(font.small, new_item->name, &new_text_width, NULL);
                        int new_width = new_text_width + SCALE1(OPTION_PADDING * 2);
                        
                        MenuItem* old_item = &items[anim_old_selected];
                        int old_text_width = 0;
                        TTF_SizeUTF8(font.small, old_item->name, &old_text_width, NULL);
                        int old_width = old_text_width + SCALE1(OPTION_PADDING * 2);
                        
                        // Вычисляем текущую ширину
                        float current_width = old_width + (new_width - old_width) * anim_progress;
                        
                        // Рисуем анимированный белый фон
                        if (current_width > 0) {
                            GFX_blitPill(ASSET_BUTTON, screen, &(SDL_Rect){
                                ox,
                                (int)current_y,
                                (int)current_width,
                                SCALE1(BUTTON_SIZE)
                            });
                            
                            // Перерисовываем текст черным поверх белого фона
                            MenuItem* current_item;
                            if (anim_progress < 0.5f) {
                                current_item = old_item;
                            } else {
                                current_item = new_item;
                            }
                            
                            text = TTF_RenderUTF8_Blended(font.small, current_item->name, COLOR_BLACK_V);
                            SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                                ox+SCALE1(OPTION_PADDING),
                                (int)current_y + SCALE1(1)
                            });
                            SDL_FreeSurface(text);
                        }
                    }
                } else {
                    // Без анимации - рисуем обычный белый фон для выбранного элемента
                    if (selected_row >= 0 && selected_row < visible_rows) {
                        MenuItem* item = &items[selected];
                        int text_width = 0;
                        TTF_SizeUTF8(font.small, item->name, &text_width, NULL);
                        int width = text_width + SCALE1(OPTION_PADDING * 2);
                        
                        GFX_blitPill(ASSET_BUTTON, screen, &(SDL_Rect){
                            ox,
                            oy + SCALE1(selected_row * BUTTON_SIZE),
                            width,
                            SCALE1(BUTTON_SIZE)
                        });
                        
                        // Перерисовываем текст черным поверх белого фона
                        text = TTF_RenderUTF8_Blended(font.small, item->name, COLOR_BLACK_V);
                        SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                            ox+SCALE1(OPTION_PADDING),
                            oy + SCALE1(selected_row * BUTTON_SIZE + 1)
                        });
                        SDL_FreeSurface(text);
                    }
                }
            }
            else if (type==MENU_FIXED || type==MENU_VAR || type==MENU_INPUT) {
                int mw = screen->w - SCALE1(PADDING*2);
                int ox, oy;
                ox = oy = SCALE1(PADDING);
                oy += SCALE1(PILL_SIZE);
                
                if (type == MENU_VAR || type == MENU_INPUT) {
                    mw = list->max_width;
                    if (!mw) {
                        int mrw = 0;
                        for (int i=0; i<count; i++) {
                            MenuItem* item = &items[i];
                            int w = 0;
                            int lw = 0;
                            int rw = 0;
                            TTF_SizeUTF8(font.small, item->name, &lw, NULL);
                            
                            if (!mrw || type!=MENU_INPUT) {
                                for (int j=0; item->values[j]; j++) {
                                    TTF_SizeUTF8(font.tiny, item->values[j], &rw, NULL);
                                    if (lw+rw>w) w = lw+rw;
                                    if (rw>mrw) mrw = rw;
                                }
                            }
                            else {
                                w = lw + mrw;
                            }
                            w += SCALE1(OPTION_PADDING*4);
                            if (w>mw) mw = w;
                        }
                        list->max_width = mw = MIN(mw, screen->w - SCALE1(PADDING *2));
                    }
                    ox = (screen->w - mw) / 2;
                }
                
                int selected_row = selected - start;
                
                // ПЕРВЫЙ ПРОХОД: рисуем ВСЕ элементы (тексты белые, без фона)
                for (int i=start,j=0; i<end; i++,j++) {
                    MenuItem* item = &items[i];
                    int item_oy = oy + SCALE1(j * BUTTON_SIZE);
                    
                    // Рисуем значение справа (белое для всех)
                    if (await_input && j==selected_row) {
                        text = TTF_RenderUTF8_Blended(font.tiny, "...", COLOR_WHITE);
                        SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                            ox + mw - text->w - SCALE1(OPTION_PADDING),
                            item_oy + SCALE1(3)
                        });
                        SDL_FreeSurface(text);
                    }
                    else if (item->value>=0) {
                        // Для всех элементов значение белое
                        text = TTF_RenderUTF8_Blended(font.tiny, item->values[item->value], COLOR_WHITE);
                        SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                            ox + mw - text->w - SCALE1(OPTION_PADDING),
                            item_oy + SCALE1(3)
                        });
                        SDL_FreeSurface(text);
                    }
                    
                    // Рисуем название (белое для всех)
                    text = TTF_RenderUTF8_Blended(font.small, item->name, COLOR_WHITE);
                    SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                        ox+SCALE1(OPTION_PADDING),
                        item_oy + SCALE1(1)
                    });
                    SDL_FreeSurface(text);
                    
                    // Сохраняем описание
                    if (j==selected_row) {
                        if (item->desc) desc = item->desc;
                    }
                }
                
                // ВТОРОЙ ПРОХОД: рисуем черный фон для значений и белый фон для выделенного элемента
                if (anim_frame > 0) {
                    // Вычисляем позиции в видимой области
                    int old_j = anim_old_selected - start;
                    int new_j = anim_new_selected - start;
                    
                    if (old_j >= 0 && old_j < visible_rows && new_j >= 0 && new_j < visible_rows) {
                        int old_y = oy + SCALE1(old_j * BUTTON_SIZE);
                        int new_y = oy + SCALE1(new_j * BUTTON_SIZE);
                        
                        // Вычисляем текущую позицию
                        float current_y = old_y + (new_y - old_y) * anim_progress;
                        
                        // Получаем ширину текста для названия
                        MenuItem* new_item = &items[anim_new_selected];
                        int new_text_width = 0;
                        TTF_SizeUTF8(font.small, new_item->name, &new_text_width, NULL);
                        int new_width = new_text_width + SCALE1(OPTION_PADDING * 2);
                        
                        MenuItem* old_item = &items[anim_old_selected];
                        int old_text_width = 0;
                        TTF_SizeUTF8(font.small, old_item->name, &old_text_width, NULL);
                        int old_width = old_text_width + SCALE1(OPTION_PADDING * 2);
                        
                        // Вычисляем текущую ширину
                        float current_width = old_width + (new_width - old_width) * anim_progress;
                        
                        // Определяем какой элемент сейчас "активен" в анимации
                        MenuItem* current_item;
                        if (anim_progress < 0.5f) {
                            current_item = old_item;
                        } else {
                            current_item = new_item;
                        }
                        
                        // 1. Сначала рисуем черный фон для значения (если есть)
                        if (current_item->value>=0 && !(await_input && anim_new_selected == selected)) {
                            // Получаем ширину значения
                            int value_width = 0;
                            TTF_SizeUTF8(font.tiny, current_item->values[current_item->value], &value_width, NULL);
                            int value_bg_width = value_width + SCALE1(OPTION_PADDING * 2);
                            
                            // Рисуем черный фон для значения
                            GFX_blitPill(ASSET_BLACK_PILL, screen, &(SDL_Rect){
                                ox,
                                (int)current_y,
                                mw,
                                SCALE1(BUTTON_SIZE)
                            });
                            
                            // Рисуем значение белым поверх черного фона
                            text = TTF_RenderUTF8_Blended(font.tiny, current_item->values[current_item->value], COLOR_WHITE);
                            SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                                ox + mw - text->w - SCALE1(OPTION_PADDING),
                                (int)current_y + SCALE1(3)
                            });
                            SDL_FreeSurface(text);
                        }
                        
                        // 2. Затем рисуем белый фон для названия поверх черного
                        if (current_width > 0) {
                            GFX_blitPill(ASSET_BUTTON, screen, &(SDL_Rect){
                                ox,
                                (int)current_y,
                                (int)current_width,
                                SCALE1(BUTTON_SIZE)
                            });
                            
                            // Рисуем название черным поверх белого фона
                            text = TTF_RenderUTF8_Blended(font.small, current_item->name, COLOR_BLACK_V);
                            SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                                ox+SCALE1(OPTION_PADDING),
                                (int)current_y + SCALE1(1)
                            });
                            SDL_FreeSurface(text);
                        }
                    }
                } else {
                    // Без анимации - рисуем обычные фоны для выбранного элемента
                    if (selected_row >= 0 && selected_row < visible_rows) {
                        MenuItem* item = &items[selected];
                        int text_width = 0;
                        TTF_SizeUTF8(font.small, item->name, &text_width, NULL);
                        int width = text_width + SCALE1(OPTION_PADDING * 2);
                        
                        // 1. Сначала рисуем черный фон для значения (если есть)
                        if (item->value>=0 && !await_input) {
                            // Получаем ширину значения
                            int value_width = 0;
                            TTF_SizeUTF8(font.tiny, item->values[item->value], &value_width, NULL);
                            int value_bg_width = value_width + SCALE1(OPTION_PADDING * 2);
                            
                            // Рисуем черный фон для значения
                            GFX_blitPill(ASSET_BLACK_PILL, screen, &(SDL_Rect){
                                ox,
                                oy + SCALE1(selected_row * BUTTON_SIZE),
                                mw,
                                SCALE1(BUTTON_SIZE)
                            });
                            
                            // Рисуем значение белым поверх черного фона
                            text = TTF_RenderUTF8_Blended(font.tiny, item->values[item->value], COLOR_WHITE);
                            SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                                ox + mw - text->w - SCALE1(OPTION_PADDING),
                                oy + SCALE1(selected_row * BUTTON_SIZE + 3)
                            });
                            SDL_FreeSurface(text);
                        }
                        
                        // 2. Затем рисуем белый фон для названия поверх черного
                        GFX_blitPill(ASSET_BUTTON, screen, &(SDL_Rect){
                            ox,
                            oy + SCALE1(selected_row * BUTTON_SIZE),
                            width,
                            SCALE1(BUTTON_SIZE)
                        });
                        
                        // Рисуем название черным поверх белого фона
                        text = TTF_RenderUTF8_Blended(font.small, item->name, COLOR_BLACK_V);
                        SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
                            ox+SCALE1(OPTION_PADDING),
                            oy + SCALE1(selected_row * BUTTON_SIZE + 1)
                        });
                        SDL_FreeSurface(text);
                    }
                }
            }
            
            // Полосы прокрутки
            if (count>MAX_VISIBLE_OPTIONS) {
                #define SCROLL_WIDTH 24
                #define SCROLL_HEIGHT 4
                int scroll_x = (screen->w - SCALE1(SCROLL_WIDTH))/2;
                int scroll_y = SCALE1((PILL_SIZE - SCROLL_HEIGHT) / 2);
                if (start>0) GFX_blitAsset(ASSET_SCROLL_UP, NULL, screen, &(SDL_Rect){scroll_x, SCALE1(PADDING) + scroll_y});
                if (end<count) GFX_blitAsset(ASSET_SCROLL_DOWN, NULL, screen, &(SDL_Rect){scroll_x, screen->h - SCALE1(PADDING + PILL_SIZE + BUTTON_SIZE) + scroll_y});
            }
            
            if (!desc && list->desc) desc = list->desc;
            
            if (desc) {
                int w,h;
                GFX_sizeText(font.tiny, desc, SCALE1(12), &w,&h);
                GFX_blitText(font.tiny, desc, SCALE1(12), COLOR_WHITE, screen, &(SDL_Rect){
                    (screen->w - w) / 2,
                    screen->h - SCALE1(PADDING) - h,
                    w,h
                });
            }
            
            GFX_flip(screen);
            dirty = 0;
        }
        else GFX_sync();
    }
    
    return 0;
}

static void Menu_scale(SDL_Surface* src, SDL_Surface* dst) {
	// LOG_info("Menu_scale src: %ix%i dst: %ix%i\n", src->w,src->h,dst->w,dst->h);
	
	uint16_t* s = src->pixels;
	uint16_t* d = dst->pixels;
	
	int sw = src->w;
	int sh = src->h;
	int sp = src->pitch / FIXED_BPP;
	
	int dw = dst->w;
	int dh = dst->h;
	int dp = dst->pitch / FIXED_BPP;
	
	int rx = 0;
	int ry = 0;
	int rw = dw;
	int rh = dh;
	
	int scaling = screen_scaling;
	if (scaling==SCALE_CROPPED && DEVICE_WIDTH==HDMI_WIDTH) {
		scaling = SCALE_NATIVE;
	}
	if (scaling==SCALE_NATIVE) {
		// LOG_info("native\n");
		
		rx = renderer.dst_x;
		ry = renderer.dst_y;
		rw = renderer.src_w;
		rh = renderer.src_h;
		if (renderer.scale) {
			// LOG_info("scale: %i\n", renderer.scale);
			rw *= renderer.scale;
			rh *= renderer.scale;
		}
		else {
			// LOG_info("forced crop\n"); // eg. fc on nano, vb on smart
			rw -= renderer.src_x * 2;
			rh -= renderer.src_y * 2;
			sw = rw;
			sh = rh;
		}
		
		if (dw==DEVICE_WIDTH/2) {
			// LOG_info("halve\n");
			rx /= 2;
			ry /= 2;
			rw /= 2;
			rh /= 2;
		}
	}
	else if (scaling==SCALE_CROPPED) {
		// LOG_info("cropped\n");
		sw -= renderer.src_x * 2;
		sh -= renderer.src_y * 2;

		rx = renderer.dst_x;
		ry = renderer.dst_y;
		rw = sw * renderer.scale;
		rh = sh * renderer.scale;
		
		if (dw==DEVICE_WIDTH/2) {
			// LOG_info("halve\n");
			rx /= 2;
			ry /= 2;
			rw /= 2;
			rh /= 2;
		}
	}
	
	if (scaling==SCALE_ASPECT || rw>dw || rh>dh) {
		// LOG_info("aspect\n");
		double fixed_aspect_ratio = ((double)DEVICE_WIDTH) / DEVICE_HEIGHT;
		int core_aspect = core.aspect_ratio * 1000;
		int fixed_aspect = fixed_aspect_ratio * 1000;
		
		if (core_aspect>fixed_aspect) {
			// LOG_info("letterbox\n");
			rw = dw;
			rh = rw / core.aspect_ratio;
			rh += rh%2;
		}
		else if (core_aspect<fixed_aspect) {
			// LOG_info("pillarbox\n");
			rh = dh;
			rw = rh * core.aspect_ratio;
			rw += rw%2;
			rw = (rw/8)*8; // probably necessary here since we're not scaling by an integer
		}
		else {
			// LOG_info("perfect match\n");
			rw = dw;
			rh = dh;
		}
		
		rx = (dw - rw) / 2;
		ry = (dh - rh) / 2;
	}
	
	// LOG_info("Menu_scale (r): %i,%i %ix%i\n",rx,ry,rw,rh);
	// LOG_info("offset: %i,%i\n", renderer.src_x, renderer.src_y);

	// dumb nearest neighbor scaling
	int mx = (sw << 16) / rw;
	int my = (sh << 16) / rh;
	int ox = (renderer.src_x << 16);
	int sx = ox;
	int sy = (renderer.src_y << 16);
	int lr = -1;
	int sr = 0;
	int dr = ry * dp;
	int cp = dp * FIXED_BPP;
	
	// LOG_info("Menu_scale (s): %i,%i %ix%i\n",sx,sy,sw,sh);
	// LOG_info("mx:%i my:%i sx>>16:%i sy>>16:%i\n",mx,my,((sx+mx) >> 16),((sy+my) >> 16));

	for (int dy=0; dy<rh; dy++) {
		sx = ox;
		sr = (sy >> 16) * sp;
		if (sr==lr) {
			memcpy(d+dr,d+dr-dp,cp);
		}
		else {
	        for (int dx=0; dx<rw; dx++) {
	            d[dr + rx + dx] = s[sr + (sx >> 16)];
				sx += mx;
	        }
		}
		lr = sr;
		sy += my;
		dr += dp;
    }
	
	// LOG_info("successful\n");
}

static void Menu_initState(void) {
	if (exists(menu.slot_path)) menu.slot = getInt(menu.slot_path);
	if (menu.slot==8) menu.slot = 0;
	
	menu.save_exists = 0;
	menu.preview_exists = 0;
}
static void Menu_updateState(void) {
    int last_slot = state_slot;
    state_slot = menu.slot;
    char save_path[256];
    State_getPath(save_path);
    state_slot = last_slot;

    sprintf(menu.bmp_path, "%s/%s.%d.bmp", menu.minui_dir, game.name, menu.slot);
    sprintf(menu.txt_path, "%s/%s.%d.txt", menu.minui_dir, game.name, menu.slot);
    menu.save_exists = exists(save_path);
    menu.preview_exists = menu.save_exists && exists(menu.bmp_path);

    // === КЭШИРОВАНИЕ ПРЕВЬЮ ===
    if (menu.slot != menu.cached_slot) {
        // Освобождаем старый кэш
        if (menu.cached_preview) {
            SDL_FreeSurface(menu.cached_preview);
            menu.cached_preview = NULL;
        }
        menu.cached_slot = -1;

        // Загружаем новое превью, если оно существует
        if (menu.preview_exists) {
            SDL_Surface* bmp = IMG_Load(menu.bmp_path);
            if (bmp) {
                menu.cached_preview = SDL_ConvertSurface(bmp, screen->format, SDL_SWSURFACE);
                SDL_FreeSurface(bmp);
                if (menu.cached_preview) {
                    menu.cached_slot = menu.slot;
                }
            }
        }
    }
}
static void Menu_saveState(void) {
    LOG_info("Menu_saveState\n");
    
    Menu_updateState();
    
    // 🔥 ИСПОЛЬЗУЕМ КАДР, УЖЕ ЗАХВАЧЕННЫЙ ДЛЯ МЕНЮ
    SDL_Surface* saved_bitmap = NULL;
    
    if (menu.bitmap) {
        // 1. Кадр уже захвачен для меню - используем его
        LOG_debug("Menu_saveState: using already captured menu frame: %dx%d\n", 
                  menu.bitmap->w, menu.bitmap->h);
        
        // Проверяем формат поверхности
        if (menu.bitmap->format->format == SDL_PIXELFORMAT_RGB565) {
            // Поверхность уже в правильном формате
            saved_bitmap = menu.bitmap;
            LOG_debug("Menu_saveState: menu bitmap is already RGB565\n");
        } else {
            // Конвертируем в RGB565 если нужно
            saved_bitmap = SDL_ConvertSurface(menu.bitmap, screen->format, SDL_SWSURFACE);
            LOG_debug("Menu_saveState: converted menu bitmap to RGB565\n");
        }
    } else {
        // 2. Резервный вариант: захватываем новый кадр
        LOG_warn("Menu_saveState: menu.bitmap is NULL, capturing new frame\n");
        
        uint16_t* captured_frame = NULL;
        unsigned captured_w = 0, captured_h = 0, captured_p = 0;
        int capture_success = 0;
        
        if (thread_video) {
            // Многопоточный режим: берем из буфера кадров
            pthread_mutex_lock(&buffer_swap_mutex);
            int ri = read_index;
            if (ri >= 0 && ri < 2 && frame_slots[ri].ready) {
                FrameSlot *slot = &frame_slots[ri];
                size_t sz = slot->pitch * slot->h;
                captured_frame = malloc(sz);
                if (captured_frame) {
                    memcpy(captured_frame, slot->data, sz);
                    captured_w = slot->w;
                    captured_h = slot->h;
                    captured_p = slot->pitch;
                    capture_success = 1;
                }
                slot->ready = 0;
            }
            pthread_mutex_unlock(&buffer_swap_mutex);
        } else {
            // Однопоточный режим: берем из renderer
            if (renderer.src && renderer.true_w > 0 && renderer.true_h > 0) {
                size_t sz = renderer.src_p * renderer.true_h;
                captured_frame = malloc(sz);
                if (captured_frame) {
                    memcpy(captured_frame, renderer.src, sz);
                    captured_w = renderer.true_w;
                    captured_h = renderer.true_h;
                    captured_p = renderer.src_p;
                    capture_success = 1;
                }
            }
        }
        
        if (capture_success && captured_frame) {
            saved_bitmap = SDL_CreateRGBSurfaceFrom(
                captured_frame, captured_w, captured_h, 
                FIXED_DEPTH, captured_p, 
                0xF800, 0x07E0, 0x001F, 0
            );
            free(captured_frame);
        }
    }
    
    // Сохраняем превью
    if (saved_bitmap) {
        SDL_RWops* out = SDL_RWFromFile(menu.bmp_path, "wb");
        if (out) {
            SDL_SaveBMP_RW(saved_bitmap, out, 1);
            LOG_info("Preview saved: %s (%dx%d)\n", menu.bmp_path, 
                     saved_bitmap->w, saved_bitmap->h);
        } else {
            LOG_error("Failed to open file for writing: %s\n", menu.bmp_path);
        }
        
        // Освобождаем только если это не menu.bitmap
        if (saved_bitmap != menu.bitmap) {
            SDL_FreeSurface(saved_bitmap);
        }
    } else {
        LOG_error("Failed to get frame for preview\n");
    }
    
    // Сохраняем состояние игры
    int last_slot = state_slot;
    state_slot = menu.slot;
    char save_path[256];
    State_getPath(save_path);
    LOG_info("Saving game state to: %s\n", save_path);
    
    putInt(menu.slot_path, menu.slot);
    State_write();
    state_slot = last_slot;
    
    // Обновляем кэш превью
    Menu_updateState();
}
static void Menu_loadState(void) {
	// LOG_info("Menu_loadState\n");

	Menu_updateState();
	
	if (menu.save_exists && menu.total_discs) {
		char slot_disc_name[256];
		getFile(menu.txt_path, slot_disc_name, 256);
		
		char slot_disc_path[256];
		if (slot_disc_name[0]=='/') strcpy(slot_disc_path, slot_disc_name);
		else sprintf(slot_disc_path, "%s%s", menu.base_path, slot_disc_name);
		
		char* disc_path = menu.disc_paths[menu.disc];
		if (!exactMatch(slot_disc_path, disc_path)) {
			Game_changeDisc(slot_disc_path);
		}
	}
	
	state_slot = menu.slot;
	putInt(menu.slot_path, menu.slot);
	State_read();
}


#define STR_SIZE 1024 * 1024
char str_buf_f[STR_SIZE];
char str_buf_v[256];
int string_count[100 * 1024];
int string_count_pos = 0;
int string_length = 0;
int string_source_length = 0;
int info_text_start_pos = 0;
int info_text_is_opened = 0;

void do_string_count(char *s){
    int i = 0;
    int j = 0;
    int charw, charh;
    string_length = 0;
    string_count_pos = 1;
    char string_text_buffer[512];
    char char_utf8[5];
    
    while((i < string_source_length) && (string_count_pos < (100 * 1024 - 1))){     
		if ((s[i] & 0xF0) == 0xF0) {
			string_text_buffer[j++] = s[i++];
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j] = '\0';
        } else if ((s[i] & 0xE0) == 0xE0) {
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j] = '\0';
        } else if ((s[i] & 0xC0) == 0xC0) {
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j++] = s[i++];
            string_text_buffer[j] = '\0';
        } else {
        	if(s[i] == '\n'){
        		string_count[string_count_pos] = i;
        		string_count_pos++;
        		j = 0;
        		string_text_buffer[0] = '\0';
        	}
        	if(s[i] < 0x20)
        		s[i] = 0x20;
        	string_text_buffer[j++] = s[i++];
        	string_text_buffer[j] = '\0';
    	}
        TTF_SizeUTF8(font.large, string_text_buffer, &charw, &charh);
        if(charw >= DEVICE_WIDTH  - 30){
            for(int k = 0; k < 12; k++){
                if(s[i - k] == ' '){
                    string_count[string_count_pos++] = i - k + 1;
                    i -= k;
                    break;
                }
                if(k == 11){
                    string_count[string_count_pos++] = i;
                    break;
                }
            }
            j = 0;
        }
    }
    string_count[string_count_pos] = i;
}

int get_line (char dst[], char src[], int start, int end){
  int limit = end - start;
  if(limit > 250)
  	limit = 250;

  for(int i = 0; i < limit; i++){
  	dst[i] = src[start + i];
  }
  	
  dst[limit] = 0;

  return limit;
}


static void View_txt(SDL_Surface* backing){
	int quit = 0;
	int dirty = 1;
	int show_setting = 0;
	int hw = DEVICE_WIDTH  - 10;
	int hh = DEVICE_HEIGHT - 10;
	
    char counter[64];
    int end_pos = 0;
	FILE* file;
	
	if (exists(txt_path) && (info_text_is_opened == 0)){
		file = fopen(txt_path, "r");
		string_source_length = fread(str_buf_f, sizeof(char), STR_SIZE, file);
		fclose(file);
		do_string_count(str_buf_f);
		if(str_buf_f[0] == '\xEF' && str_buf_f[1] == '\xBB' && str_buf_f[2] == '\xBF'){
			string_count[0] = 2;
		}
		info_text_is_opened = 1;
	}
	while(!quit){
		GFX_startFrame();
		uint32_t now = SDL_GetTicks();
	
		PAD_poll();
		if (PAD_justPressed(getButtonB())) {
			quit = 1;
		}
		else if (PAD_justPressed(BTN_DOWN)) {
			info_text_start_pos += 11;
			if(info_text_start_pos >= string_count_pos)
				info_text_start_pos -= 11;
			dirty = 1;
		}
		else if (PAD_justPressed(BTN_UP)) {
			info_text_start_pos -= 11;
			if(info_text_start_pos < 0)
				info_text_start_pos = 0;
			dirty = 1;
		}
		else if (PAD_isPressed(BTN_RIGHT)) {
			info_text_start_pos += 11;
			if(info_text_start_pos >= string_count_pos)
				info_text_start_pos -= 11;
			dirty = 1;
		}
		else if (PAD_isPressed(BTN_LEFT)) {
			info_text_start_pos -= 11;
			if(info_text_start_pos < 0)
				info_text_start_pos = 0;
			dirty = 1;
		}
		else if (PAD_isPressed(BTN_R1)) {
			info_text_start_pos += 110;
			if(info_text_start_pos >= string_count_pos){
				info_text_start_pos -= 110;
				info_text_start_pos += 11;
				if(info_text_start_pos >= string_count_pos)
					info_text_start_pos -= 11;
			}
			dirty = 1;
		}
		else if (PAD_isPressed(BTN_L1)) {
			info_text_start_pos -= 110;
			if(info_text_start_pos < 0)
				info_text_start_pos = 0;
			dirty = 1;
		}
		
		PWR_update(&dirty, &show_setting, Menu_beforeSleep, Menu_afterSleep);
		
		if (dirty) {
			GFX_clear(screen);
			SDL_BlitSurface(backing, NULL, screen, NULL);
			SDL_BlitSurface(menu.overlay, NULL, screen, NULL);
			SDL_Rect preview_rect = {DEVICE_WIDTH / 2 - 120 , DEVICE_HEIGHT / 2 - 15, 240, 30};
			
			if (exists(txt_path) || info_text_is_opened){
				if(file == NULL && info_text_is_opened == 0){ // Проверяем что файл открылся
					SDL_FillRect(screen, &preview_rect, 0);
        			GFX_blitMessage(font.large, language_get_string("ERROOR_FILE_OPEN"), screen, &preview_rect);
    			}else{
    				SDL_Surface* text;
    				end_pos = (string_count_pos < (info_text_start_pos + 11)) ? string_count_pos : (info_text_start_pos + 11);
    				for(int i = info_text_start_pos; i < end_pos; i++){
        				if(get_line(str_buf_v, str_buf_f, string_count[i], string_count[i + 1]) > 0){	
        					text = TTF_RenderUTF8_Blended(font.large, str_buf_v, COLOR_WHITE);
							SDL_BlitSurface(text, &(SDL_Rect){
								0,
								0,
								hw-SCALE1(BUTTON_PADDING*2),
								text->h
							}, screen, &(SDL_Rect){
								SCALE1(PADDING+BUTTON_PADDING),
								(i - info_text_start_pos) * 20
							});
							SDL_FreeSurface(text);
						}
    				}
    				sprintf(counter, "%d/%d", info_text_start_pos / 11, string_count_pos / 11);
					text = TTF_RenderUTF8_Blended(font.large, counter, COLOR_WHITE);
					GFX_blitPill(ASSET_DARK_GRAY_PILL, screen, &(SDL_Rect){
						SCALE1(PADDING),
						DEVICE_HEIGHT - 42,
						text->w + 22,
						SCALE1(PILL_SIZE)
					});
					SDL_BlitSurface(text, &(SDL_Rect){
						0,
						0,
						hw-SCALE1(BUTTON_PADDING*2),
						text->h
					}, screen, &(SDL_Rect){
						SCALE1(PADDING+BUTTON_PADDING),
						DEVICE_HEIGHT - 36
					});
					if(getSwapButtonAB() == 1)
						GFX_blitButtonGroup((char*[]){ "A",language_get_string("BACK"), NULL }, 1, screen, 1);
					else
						GFX_blitButtonGroup((char*[]){ "B",language_get_string("BACK"), NULL }, 1, screen, 1);
					SDL_FreeSurface(text);
				}
			}
			else {
				SDL_FillRect(screen, &preview_rect, 0);
				GFX_blitMessage(font.large, language_get_string("NO_INFORMATION_FILE"), screen, &preview_rect);
			}
			GFX_blitHardwareGroup(screen, show_setting);
			GFX_flip(screen);
			dirty = 0;
		}
		else GFX_sync();
	}
}

void Menu_loop(void) {
    uint16_t* safe_frame = NULL;
    unsigned w = 0, h = 0, p = 0;
    
    // БЛОКИРУЕМ ПОТОКИ ПЕРЕД КОПИРОВАНИЕМ КАДРА
    if (thread_video) {
        // 1. Приостанавливаем поток эмуляции
        pthread_mutex_lock(&core_mx);
        coreThreadPaused = 1;
        should_run_core = 0;
        pthread_mutex_unlock(&core_mx);
        
        // 2. Даем время завершить текущий кадр
        usleep(20000);
        
        // 3. Блокируем доступ к буферу кадров
        pthread_mutex_lock(&buffer_swap_mutex);
        
        // 4. Ищем последний доступный кадр
        int ri = read_index;
        if (ri >= 0 && frame_slots[ri].ready) {
            FrameSlot *slot = &frame_slots[ri];
            size_t sz = slot->pitch * slot->h;
            safe_frame = malloc(sz);
            if (safe_frame) {
                memcpy(safe_frame, slot->data, sz);
                w = slot->w;
                h = slot->h;
                p = slot->pitch;
            }
            slot->ready = 0;
        }
        
        // 5. Разблокируем буфер
        pthread_mutex_unlock(&buffer_swap_mutex);
    } else {
        if (renderer.src && renderer.true_w > 0 && renderer.true_h > 0) {
            size_t sz = renderer.src_p * renderer.true_h;
            safe_frame = malloc(sz);
            if (safe_frame) {
                memcpy(safe_frame, renderer.src, sz);
                w = renderer.true_w;
                h = renderer.true_h;
                p = renderer.src_p;
            }
        }
    }
    
    // Создаем поверхность для меню
    if (safe_frame) {
        menu.bitmap = SDL_CreateRGBSurfaceFrom(safe_frame, w, h, FIXED_DEPTH, p, RGBA_MASK_565);
        if (!menu.bitmap) {
            free(safe_frame);
        }
    }
    
    // Fallback
    if (!menu.bitmap) {
        menu.bitmap = SDL_CreateRGBSurface(SDL_SWSURFACE, 320, 240, FIXED_DEPTH, RGBA_MASK_565);
        if (menu.bitmap) {
            SDL_FillRect(menu.bitmap, NULL, 0);
        }
    }

    SDL_Surface* backing = SDL_CreateRGBSurface(
        SDL_SWSURFACE, DEVICE_WIDTH, DEVICE_HEIGHT, FIXED_DEPTH, RGBA_MASK_565
    );
    Menu_scale(menu.bitmap, backing);
    
    int restore_w = screen->w;
    int restore_h = screen->h;
    int restore_p = screen->pitch;
    if (restore_w!=DEVICE_WIDTH || restore_h!=DEVICE_HEIGHT) {
        screen = GFX_resize(DEVICE_WIDTH,DEVICE_HEIGHT,DEVICE_PITCH);
    }
    
    SRAM_write();
    RTC_write();
    PWR_warn(0);
    if (!HAS_POWER_BUTTON) PWR_enableSleep();
    PWR_setCPUSpeed(CPU_SPEED_MENU);
    GFX_setVsync(VSYNC_STRICT);
    
    int rumble_strength = VIB_getStrength();
    VIB_setStrength(0);
    
    PWR_enableAutosleep();
    PAD_reset();
    
    // path and string things
    char rom_name[256];
    getDisplayName(game.name, rom_name);
    
    int rom_disc = -1;
    char disc_name[16];
    if (menu.total_discs) {
        rom_disc = menu.disc;
        sprintf(disc_name, "Disc %i", menu.disc+1);
    }
        
    int selected = 0;
    Menu_initState();
    
    int status = STATUS_CONT;
    int show_setting = 0;
    int dirty = 1;
    int ignore_menu = 0;
    int menu_start = 0;
    
    SDL_Surface* preview = SDL_CreateRGBSurface(SDL_SWSURFACE,DEVICE_WIDTH/2,DEVICE_HEIGHT/2,FIXED_DEPTH,RGBA_MASK_565);
    
    // Константы для анимации
    const int ANIMATION_SPEED = 4;
    
    // Переменные для анимации
    int anim_old_selected = 0;
    int anim_new_selected = 0;
    int anim_frame = 0;
    float anim_progress = 0.0f;
    int need_final_redraw = 0;
    
    // ==================== КЭШИРОВАНИЕ ====================
    #define MAX_CACHED_TEXT 32
    
    typedef struct {
        char text[64];
        SDL_Color color;
        SDL_Surface* surface;
    } CachedText;
    
    static CachedText text_cache[MAX_CACHED_TEXT] = {0};
    static int cache_size = 0;
    
    SDL_Surface* get_cached_text(const char* text, SDL_Color color) {
        if (!text) return NULL;
        
        for (int i = 0; i < cache_size; i++) {
            if (strcmp(text_cache[i].text, text) == 0 &&
                text_cache[i].color.r == color.r &&
                text_cache[i].color.g == color.g &&
                text_cache[i].color.b == color.b) {
                return text_cache[i].surface;
            }
        }
        
        if (cache_size >= MAX_CACHED_TEXT) {
            if (text_cache[0].surface) {
                SDL_FreeSurface(text_cache[0].surface);
            }
            memmove(&text_cache[0], &text_cache[1], sizeof(CachedText) * (MAX_CACHED_TEXT - 1));
            cache_size--;
        }
        
        SDL_Surface* surface = TTF_RenderUTF8_Blended(font.large, text, color);
        if (!surface) return NULL;
        
        strncpy(text_cache[cache_size].text, text, sizeof(text_cache[cache_size].text) - 1);
        text_cache[cache_size].text[sizeof(text_cache[cache_size].text) - 1] = '\0';
        text_cache[cache_size].color = color;
        text_cache[cache_size].surface = surface;
        
        cache_size++;
        return surface;
    }
    
    void clear_text_cache(void) {
        for (int i = 0; i < cache_size; i++) {
            if (text_cache[i].surface) {
                SDL_FreeSurface(text_cache[i].surface);
                text_cache[i].surface = NULL;
            }
            text_cache[i].text[0] = '\0';
        }
        cache_size = 0;
    }
    
    // Предварительное кэширование
    for (int i = 0; i < MENU_ITEM_COUNT; i++) {
        char* item_text = language_get_string(menu.items[i]);
        get_cached_text(item_text, COLOR_WHITE);
        get_cached_text(item_text, COLOR_BLACK_V);
    }
    
    get_cached_text(rom_name, COLOR_WHITE);
    get_cached_text(language_get_string("MENU"), COLOR_WHITE);
    get_cached_text(language_get_string("SLEEP"), COLOR_WHITE);
    get_cached_text(language_get_string("BACK"), COLOR_WHITE);
    get_cached_text(language_get_string("OK"), COLOR_WHITE);
    get_cached_text(language_get_string("NO_IMAGE"), COLOR_WHITE);
    get_cached_text(language_get_string("FREE_SLOT"), COLOR_WHITE);
    
    if (menu.total_discs) {
        get_cached_text(disc_name, COLOR_WHITE);
    }
    
    while (show_menu) {
        GFX_startFrame();
        uint32_t now = SDL_GetTicks();

        PAD_poll();
        
        int old_selected = selected;
        
        if (PAD_justPressed(BTN_UP)) {
            selected -= 1;
            if (selected < 0) selected += MENU_ITEM_COUNT;
            
            if (old_selected != selected) {
                anim_old_selected = old_selected;
                anim_new_selected = selected;
                anim_frame = ANIMATION_SPEED;
                dirty = 1;
            }
        }
        else if (PAD_justPressed(BTN_DOWN)) {
            selected += 1;
            if (selected >= MENU_ITEM_COUNT) selected -= MENU_ITEM_COUNT;
            
            if (old_selected != selected) {
                anim_old_selected = old_selected;
                anim_new_selected = selected;
                anim_frame = ANIMATION_SPEED;
                dirty = 1;
            }
        }
        else if (PAD_justPressed(BTN_LEFT)) {
            if (menu.total_discs>1 && selected==ITEM_CONT) {
                menu.disc -= 1;
                if (menu.disc<0) menu.disc += menu.total_discs;
                dirty = 1;
                sprintf(disc_name, "Disc %i", menu.disc+1);
                get_cached_text(disc_name, COLOR_WHITE);
            }
            else if (selected==ITEM_SAVE || selected==ITEM_LOAD) {
                menu.slot -= 1;
                if (menu.slot<0) menu.slot += MENU_SLOT_COUNT;
                dirty = 1;
            }
        }
        else if (PAD_justPressed(BTN_RIGHT)) {
            if (menu.total_discs>1 && selected==ITEM_CONT) {
                menu.disc += 1;
                if (menu.disc==menu.total_discs) menu.disc -= menu.total_discs;
                dirty = 1;
                sprintf(disc_name, "Disc %i", menu.disc+1);
                get_cached_text(disc_name, COLOR_WHITE);
            }
            else if (selected==ITEM_SAVE || selected==ITEM_LOAD) {
                menu.slot += 1;
                if (menu.slot>=MENU_SLOT_COUNT) menu.slot -= MENU_SLOT_COUNT;
                dirty = 1;
            }
        }
        
        if (dirty && (selected==ITEM_SAVE || selected==ITEM_LOAD)) {
            Menu_updateState();
        }
        
        if (PAD_justPressed(getButtonB()) || (BTN_WAKE!=BTN_MENU && PAD_tappedMenu(now))) {
            status = STATUS_CONT;
            show_menu = 0;
        }
        else if (PAD_justPressed(getButtonA())) {
            switch(selected) {
                case ITEM_CONT:
                    if (menu.total_discs && rom_disc!=menu.disc) {
                        status = STATUS_DISC;
                        char* disc_path = menu.disc_paths[menu.disc];
                        Game_changeDisc(disc_path);
                    } else {
                        status = STATUS_CONT;
                    }
                    show_menu = 0;
                    break;
                    
                case ITEM_SAVE: {
                    Menu_saveState();
                    status = STATUS_SAVE;
                    show_menu = 0;
                    break;
                }
                case ITEM_LOAD: {
                    Menu_loadState();
                    status = STATUS_LOAD;
                    show_menu = 0;
                    break;
                }
                case ITEM_OPTS: {
                    if (simple_mode || emulators_settings_hide) {
                        core.reset();
                        status = STATUS_RESET;
                        show_menu = 0;
                    } else {
                        int old_scaling = screen_scaling;
                        Menu_options(&options_menu);
                        if (screen_scaling!=old_scaling) {
                            selectScaler(renderer.true_w,renderer.true_h,renderer.src_p);
                            restore_w = screen->w;
                            restore_h = screen->h;
                            restore_p = screen->pitch;
                            screen = GFX_resize(DEVICE_WIDTH,DEVICE_HEIGHT,DEVICE_PITCH);
                            SDL_FillRect(backing, NULL, 0);
                            Menu_scale(menu.bitmap, backing);
                        }
                        dirty = 1;
                    }
                    break;
                }
                case ITEM_INFO:
                    View_txt(backing);
                    show_menu = 0;
                    status = STATUS_INFO;
                    dirty = 1;
                    break;
                case ITEM_QUIT:
                    status = STATUS_QUIT;
                    show_menu = 0;
                    quit = 1;
                    break;
            }
            if (!show_menu) break;
        }

        PWR_update(&dirty, &show_setting, Menu_beforeSleep, Menu_afterSleep);
        
        if (anim_frame > 0) {
            anim_frame--;
            
            if (anim_frame == 0) {
                anim_progress = 1.0f;
                need_final_redraw = 1;
            } else {
                anim_progress = 1.0f - ((float)anim_frame / (float)ANIMATION_SPEED);
            }
            
            dirty = 1;
        }
        
        if (need_final_redraw) {
            need_final_redraw = 0;
            dirty = 1;
        }
        
        if (dirty || anim_frame > 0 || PLAT_isPopupActive()) {
            // Очищаем экран
            SDL_FillRect(screen, &(SDL_Rect){0, 0, DEVICE_WIDTH, DEVICE_HEIGHT}, 
                        SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
            
            // Копируем фон игры
            SDL_BlitSurface(backing, NULL, screen, NULL);
            
            // Копируем оверлей меню
            if (menu.overlay) {
                SDL_BlitSurface(menu.overlay, NULL, screen, NULL);
            }

            int ox, oy;
            int ow = GFX_blitHardwareGroup(screen, show_setting);
            int max_width = screen->w - SCALE1(PADDING * 2) - ow;
            
            char display_name[256];
            int text_width = GFX_truncateText(font.large, rom_name, display_name, max_width, SCALE1(BUTTON_PADDING*2));
            max_width = MIN(max_width, text_width);

            // Заголовок
            SDL_Surface* title_text = get_cached_text(display_name, COLOR_WHITE);
            
            GFX_blitPill(ASSET_BLACK_PILL, screen, &(SDL_Rect){
                SCALE1(PADDING),
                SCALE1(PADDING),
                max_width,
                SCALE1(PILL_SIZE)
            });
            
            if (title_text) {
                SDL_BlitSurface(title_text, &(SDL_Rect){
                    0, 0, max_width-SCALE1(BUTTON_PADDING*2), title_text->h
                }, screen, &(SDL_Rect){
                    SCALE1(PADDING+BUTTON_PADDING),
                    SCALE1(PADDING+4)
                });
            }
                
            // Кнопки и батарея
            if (show_setting) {
                GFX_blitHardwareHints(screen, show_setting);
            } else {
                GFX_blitButtonGroup((char*[]){ 
                    BTN_SLEEP==BTN_POWER?language_get_string("POWER"):language_get_string("MENU"),
                    language_get_string("SLEEP"), 
                    NULL 
                }, 0, screen, 0);
                
                int battery_x = DEVICE_WIDTH - 50;
                int battery_y = 10;
                drawBatteryPercentage(screen, battery_x, battery_y);
            }
            
            if(getSwapButtonAB() == 1) {
                GFX_blitButtonGroup((char*[]){ 
                    "A", language_get_string("BACK"), 
                    "B", language_get_string("OK"), 
                    NULL 
                }, 1, screen, 1);
            } else {
                GFX_blitButtonGroup((char*[]){ 
                    "B", language_get_string("BACK"), 
                    "A", language_get_string("OK"), 
                    NULL 
                }, 1, screen, 1);
            }
            
            // ==================== ИСПРАВЛЕНИЕ: ПРАВИЛЬНОЕ ПОЗИЦИОНИРОВАНИЕ МЕНЮ ====================
            // Вычисляем позицию списка меню по центру экрана
            int total_menu_height = MENU_ITEM_COUNT * PILL_SIZE;
            int available_height = (DEVICE_HEIGHT / FIXED_SCALE) - PADDING * 2;
            
            // Убеждаемся, что меню не выходит за пределы экрана
            if (total_menu_height > available_height) {
                total_menu_height = available_height;
            }
            
            // Центрируем по вертикали
            oy = (available_height - total_menu_height) / 2 + PADDING;
            
            // Если получилось отрицательное значение - исправляем
            if (oy < PADDING) {
                oy = PADDING;
            }
            
            // ПРОВЕРКА: Логика для отладки (можно удалить после тестирования)
            static int last_oy = -1;
            if (last_oy != oy) {
                last_oy = oy;
            }
            
            // Рендерим пункты меню
            for (int i=0; i<MENU_ITEM_COUNT; i++) {
                char* item = language_get_string(menu.items[i]);
                int item_oy = oy + (i * PILL_SIZE);
                
                // Проверяем, что пункт меню видим на экране
                if (item_oy < PADDING || item_oy + PILL_SIZE > (DEVICE_HEIGHT / FIXED_SCALE) - PADDING) {
                    continue; // Пропускаем невидимые пункты
                }
                
                // Определяем цвет текста
                SDL_Color text_color = COLOR_WHITE;
                int is_selected = (i == selected) || (anim_frame > 0 && i == anim_new_selected);
                
                if (is_selected) {
                    text_color = COLOR_BLACK_V;
                }
                
                // Получаем текст из кэша
                SDL_Surface* item_text = get_cached_text(item, text_color);
                
                if (item_text) {
                    // Для невыбранных элементов рисуем тень
                    if (!is_selected) {
                        SDL_Surface* shadow_text = get_cached_text(item, COLOR_BLACK_V);
                        if (shadow_text) {
                            SDL_Rect shadow_rect = {
                                SCALE1(PADDING + BUTTON_PADDING + 1),
                                SCALE1(item_oy + 5),
                                shadow_text->w,
                                shadow_text->h
                            };
                            SDL_BlitSurface(shadow_text, NULL, screen, &shadow_rect);
                        }
                    }
                    
                    // Рисуем текст
                    SDL_BlitSurface(item_text, NULL, screen, &(SDL_Rect){
                        SCALE1(PADDING + BUTTON_PADDING),
                        SCALE1(item_oy + 4)
                    });
                }
            }
            
            // Анимированный фон для выбранного элемента
            if (anim_frame > 0) {
                int old_y = oy + (anim_old_selected * PILL_SIZE);
                int new_y = oy + (anim_new_selected * PILL_SIZE);
                float current_y = old_y + (new_y - old_y) * anim_progress;
                
                // Получаем ширину текста
                char* new_item = language_get_string(menu.items[anim_new_selected]);
                int new_text_width = 0;
                TTF_SizeUTF8(font.large, new_item, &new_text_width, NULL);
                int new_width = new_text_width + SCALE1(BUTTON_PADDING * 2);
                
                char* old_item = language_get_string(menu.items[anim_old_selected]);
                int old_text_width = 0;
                TTF_SizeUTF8(font.large, old_item, &old_text_width, NULL);
                int old_width = old_text_width + SCALE1(BUTTON_PADDING * 2);
                
                float current_width = old_width + (new_width - old_width) * anim_progress;
                
                // Рисуем анимированный фон
                if (current_width > 0 && current_y >= PADDING && 
                    current_y + PILL_SIZE <= (DEVICE_HEIGHT / FIXED_SCALE) - PADDING) {
                    
                    GFX_blitPill(ASSET_WHITE_PILL, screen, &(SDL_Rect){
                        SCALE1(PADDING),
                        SCALE1(current_y),
                        (int)current_width,
                        SCALE1(PILL_SIZE)
                    });
                    
                    // Для disc change рисуем дополнительный серый фон
                    if (menu.total_discs>1 && anim_new_selected==ITEM_CONT) {
                        GFX_blitPill(ASSET_DARK_GRAY_PILL, screen, &(SDL_Rect){
                            SCALE1(PADDING),
                            SCALE1(current_y),
                            screen->w - SCALE1(PADDING * 2),
                            SCALE1(PILL_SIZE)
                        });
                        
                        SDL_Surface* disc_text = get_cached_text(disc_name, COLOR_WHITE);
                        if (disc_text) {
                            SDL_BlitSurface(disc_text, NULL, screen, &(SDL_Rect){
                                screen->w - SCALE1(PADDING + BUTTON_PADDING) - disc_text->w,
                                SCALE1(current_y + 4)
                            });
                        }
                    }
                }
            } 
            else {
                // Статичный фон для выбранного элемента
                if (selected >= 0 && selected < MENU_ITEM_COUNT) {
                    int item_oy = oy + (selected * PILL_SIZE);
                    
                    // Проверяем, что элемент видим
                    if (item_oy >= PADDING && item_oy + PILL_SIZE <= (DEVICE_HEIGHT / FIXED_SCALE) - PADDING) {
                        char* item = language_get_string(menu.items[selected]);
                        int text_width = 0;
                        TTF_SizeUTF8(font.large, item, &text_width, NULL);
                        int width = text_width + SCALE1(BUTTON_PADDING * 2);
                        
                        // Белый фон для выбранного элемента
                        GFX_blitPill(ASSET_WHITE_PILL, screen, &(SDL_Rect){
                            SCALE1(PADDING),
                            SCALE1(item_oy),
                            width,
                            SCALE1(PILL_SIZE)
                        });
                        
                        // Для disc change рисуем дополнительный серый фон
                        if (menu.total_discs>1 && selected==ITEM_CONT) {
                            GFX_blitPill(ASSET_DARK_GRAY_PILL, screen, &(SDL_Rect){
                                SCALE1(PADDING),
                                SCALE1(item_oy),
                                screen->w - SCALE1(PADDING * 2),
                                SCALE1(PILL_SIZE)
                            });
                            
                            SDL_Surface* disc_text = get_cached_text(disc_name, COLOR_WHITE);
                            if (disc_text) {
                                SDL_BlitSurface(disc_text, NULL, screen, &(SDL_Rect){
                                    screen->w - SCALE1(PADDING + BUTTON_PADDING) - disc_text->w,
                                    SCALE1(item_oy + 4)
                                });
                            }
                        }
                        
                        // Текст поверх фона
                        SDL_Surface* black_text = get_cached_text(item, COLOR_BLACK_V);
                        if (black_text) {
                            SDL_BlitSurface(black_text, NULL, screen, &(SDL_Rect){
                                SCALE1(PADDING + BUTTON_PADDING),
                                SCALE1(item_oy + 4)
                            });
                        }
                    }
                }
            }
            
            // Превью слотов
            if (selected==ITEM_SAVE || selected==ITEM_LOAD) {
                #define WINDOW_RADIUS 4
                #define PAGINATION_HEIGHT 6
                
                int hw = DEVICE_WIDTH / 2;
                int hh = DEVICE_HEIGHT / 2;
                int pw = hw + SCALE1(WINDOW_RADIUS*2);
                int ph = hh + SCALE1(WINDOW_RADIUS*2 + PAGINATION_HEIGHT + WINDOW_RADIUS);
                ox = DEVICE_WIDTH - pw - SCALE1(PADDING);
                oy = (DEVICE_HEIGHT - ph) / 2;
                
                // window
                GFX_blitRect(ASSET_STATE_BG, screen, &(SDL_Rect){ox,oy,pw,ph});
                ox += SCALE1(WINDOW_RADIUS);
                oy += SCALE1(WINDOW_RADIUS);
                
                if (menu.cached_preview) {
                    SDL_FillRect(preview, NULL, 0);
                    Menu_scale(menu.cached_preview, preview);
                    SDL_BlitSurface(preview, NULL, screen, &(SDL_Rect){ox, oy});
                } else {
                    SDL_Rect preview_rect = {ox,oy,hw,hh};
                    SDL_FillRect(screen, &preview_rect, 0);
                    
                    SDL_Surface* message_text = NULL;
                    if (menu.save_exists) {
                        message_text = get_cached_text(language_get_string("NO_IMAGE"), COLOR_WHITE);
                    } else {
                        message_text = get_cached_text(language_get_string("FREE_SLOT"), COLOR_WHITE);
                    }
                    
                    if (message_text) {
                        int text_x = ox + (hw - message_text->w) / 2;
                        int text_y = oy + (hh - message_text->h) / 2;
                        SDL_BlitSurface(message_text, NULL, screen, &(SDL_Rect){text_x, text_y});
                    }
                }
                
                // pagination
                ox += (pw-SCALE1(15*MENU_SLOT_COUNT))/2;
                oy += hh+SCALE1(WINDOW_RADIUS);
                for (int i=0; i<MENU_SLOT_COUNT; i++) {
                    if (i==menu.slot) {
                        GFX_blitAsset(ASSET_PAGE, NULL, screen, &(SDL_Rect){ox+SCALE1(i*15),oy});
                    } else {
                        GFX_blitAsset(ASSET_DOT, NULL, screen, &(SDL_Rect){ox+SCALE1(i*15)+4,oy+SCALE1(2)});
                    }
                }
            }
    
            GFX_flip(screen);
            dirty = 0;
        }
        else {
            GFX_sync();
        }
    }
    
    clear_text_cache();
    
    if (menu.cached_preview) {
        SDL_FreeSurface(menu.cached_preview);
        menu.cached_preview = NULL;
    }
    menu.cached_slot = -1;
    
    SDL_FreeSurface(preview);
    
    PAD_reset();
    GFX_clearAll();
    PWR_warn(1);
    
    if (!quit) {
        if (restore_w!=DEVICE_WIDTH || restore_h!=DEVICE_HEIGHT) {
            screen = GFX_resize(restore_w,restore_h,restore_p);
        }
        GFX_clear(screen);
        video_refresh_callback(renderer.src, renderer.true_w, renderer.true_h, renderer.src_p);

        setOverclock(overclock);
        if (rumble_strength) VIB_setStrength(rumble_strength);
        
        GFX_setVsync(prevent_tearing);
        if (!HAS_POWER_BUTTON) PWR_disableSleep();
    }
    
    SDL_FreeSurface(backing);
    PWR_disableAutosleep();
    
    if (thread_video && coreThreadPaused) {
        pthread_mutex_lock(&core_mx);
        coreThreadPaused = 0;
        should_run_core = 1;
        pthread_cond_signal(&core_rq);
        pthread_mutex_unlock(&core_mx);
    }
    
    if (safe_frame && menu.bitmap) {
        free(safe_frame);
    }
}

// TODO: move to PWR_*?
static unsigned getUsage(void) { // from picoarch
	long unsigned ticks = 0;
	long ticksps = 0;
	FILE *file = NULL;

	file = fopen("/proc/self/stat", "r");
	if (!file)
		goto finish;

	if (!fscanf(file, "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu", &ticks))
		goto finish;

	ticksps = sysconf(_SC_CLK_TCK);

	if (ticksps)
		ticks = ticks * 100 / ticksps;

finish:
	if (file)
		fclose(file);

	return ticks;
}

static void resetFPSCounter(void) {
    sec_start = SDL_GetTicks();
    fps_ticks = 0;
}

static void trackFPS(void) {
    cpu_ticks += 1;
    static int last_use_ticks = 0;
    static float fps_smoothed = 60.0; // Сглаженный FPS
    
    uint32_t now = SDL_GetTicks();
    
    if (now - sec_start >= 1000) {
        double last_time = (double)(now - sec_start) / 1000;
        fps_double = fps_ticks / last_time;
        
        // Экспоненциальное сглаживание FPS
        fps_smoothed = fps_smoothed * 0.7f + fps_double * 0.3f;
        
        cpu_double = cpu_ticks / last_time;
        use_ticks = getUsage();
        
        if (use_ticks && last_use_ticks) {
            use_double = (use_ticks - last_use_ticks) / last_time;
        }
        
        last_use_ticks = use_ticks;
        sec_start = now;
        cpu_ticks = 0;
        fps_ticks = 0;
    }
}

static void limitFF(void) {
	static uint64_t ff_frame_time = 0;
	static uint64_t last_time = 0;
	static int last_max_speed = -1;
	if (last_max_speed!=max_ff_speed) {
		last_max_speed = max_ff_speed;
		ff_frame_time = 1000000 / (core.fps * (max_ff_speed + 1));
	}
	
	uint64_t now = getMicroseconds();
	if (fast_forward && max_ff_speed) {
		if (last_time == 0) last_time = now;
		int elapsed = now - last_time;
		if (elapsed>0 && elapsed<0x80000) {
			if (elapsed<ff_frame_time) {
				int delay = (ff_frame_time - elapsed) / 1000;
				if (delay>0 && delay<17) { // don't allow a delay any greater than a frame
					SDL_Delay(delay);
				}
			}
			last_time += ff_frame_time;
			return;
		}
	}
	last_time = now;
}

void get_name(char* pt, char* name, const char* path){
    size_t n;
    const char* a, *b = path + strlen(path);
    if(b > path)
        --b;
 
    a = b;
    while((a >= path) && (*a != '\\') && (*a != '/')){
        --a;
    }
 
    if(a < path)
        return;
    ++a;
 
    n = (size_t)(b - a);
    strncpy(name, a, n + 1);
    name[n + 1] = '\0';
    strncpy(pt, path, strlen(path) - n);
    pt[strlen(path) - n - 1] = '\0';
}

static void draw_rewind_timeline(int mode) {
    if (rewind_count == 0) return;

    const int MAX_VISIBLE = 16;
    int thumb_w = 60;
    int thumb_h = 45;
    int spacing = 10;
    int y = DEVICE_HEIGHT - thumb_h - 30;

    // Курсор (выбранный кадр) всегда по центру экрана
    int center_x = DEVICE_WIDTH / 2 - thumb_w / 2;
    int center_y = y;

    // Сколько кадров можно показать слева (новее) и справа (старее)
    int left_count = MIN(rewind_count - 1 - rewind_selected, MAX_VISIBLE / 2);   // новые
    int right_count = MIN(rewind_selected, MAX_VISIBLE / 2);                    // старые

    // Ограничиваем общее число, если мало кадров
    if (left_count + right_count + 1 > MAX_VISIBLE) {
        int excess = (left_count + right_count + 1) - MAX_VISIBLE;
        // Уменьшаем с той стороны, где больше
        if (left_count > right_count) {
            left_count -= excess;
            if (left_count < 0) {
                right_count += left_count;
                left_count = 0;
            }
        } else {
            right_count -= excess;
            if (right_count < 0) {
                left_count += right_count;
                right_count = 0;
            }
        }
    }

    // Рисуем кадры: сначала слева (новее), потом центр, потом справа (старее)
    // Слева: rewind_selected + 1, +2, ..., +left_count
    for (int i = 1; i <= left_count; i++) {
        int timeline_idx = rewind_selected + i;
        if (timeline_idx >= rewind_count) break;

        int buffer_idx = (rewind_start + (rewind_count - 1 - timeline_idx)) % rewind_buffer_size;
        RewindFrame* frame = &rewind_buffer[buffer_idx];

        int x = center_x - (thumb_w + spacing) * i;
        SDL_Rect r = {x, y, thumb_w, thumb_h};

        // Обводка
        SDL_Rect border = {x - 2, y - 2, thumb_w + 4, thumb_h + 4};
        SDL_FillRect(screen, &border, SDL_MapRGB(screen->format, 80, 80, 80));

        if (frame->preview) {
            SDL_Surface* surf = SDL_CreateRGBSurfaceFrom(
                frame->preview, frame->preview_w, frame->preview_h,
                16, frame->preview_w * 2, RGBA_MASK_565
            );
            if (surf) {
                SDL_Surface* scaled = SDL_CreateRGBSurface(0, thumb_w - 4, thumb_h - 4, 16, 0, 0, 0, 0);
                if (scaled) {
                    SDL_BlitScaled(surf, NULL, scaled, NULL);
                    SDL_BlitSurface(scaled, NULL, screen,
                        &(SDL_Rect){r.x + 2, r.y + 2, thumb_w - 4, thumb_h - 4});
                    SDL_FreeSurface(scaled);
                }
                SDL_FreeSurface(surf);
            }
        } else {
            SDL_FillRect(screen, &(SDL_Rect){r.x + 2, r.y + 2, thumb_w - 4, thumb_h - 4},
                         SDL_MapRGB(screen->format, 40, 40, 40));
        }

        char num[8];
        snprintf(num, sizeof(num), "%d", timeline_idx + 1);
        SDL_Surface* text = TTF_RenderUTF8_Blended(font.tiny, num, COLOR_WHITE);
        if (text) {
            SDL_BlitSurface(text, NULL, screen,
                &(SDL_Rect){x + (thumb_w - text->w) / 2, y - text->h - 5, text->w, text->h});
            SDL_FreeSurface(text);
        }
    }

    // Центр: выбранный кадр
    {
        int timeline_idx = rewind_selected;
        int buffer_idx = (rewind_start + (rewind_count - 1 - timeline_idx)) % rewind_buffer_size;
        RewindFrame* frame = &rewind_buffer[buffer_idx];

        SDL_Rect r = {center_x, center_y, thumb_w, thumb_h};
        SDL_Rect border = {center_x - 2, center_y - 2, thumb_w + 4, thumb_h + 4};
        SDL_FillRect(screen, &border, SDL_MapRGB(screen->format, 255, 200, 0)); // выделение

        if (frame->preview) {
            SDL_Surface* surf = SDL_CreateRGBSurfaceFrom(
                frame->preview, frame->preview_w, frame->preview_h,
                16, frame->preview_w * 2, RGBA_MASK_565
            );
            if (surf) {
                SDL_Surface* scaled = SDL_CreateRGBSurface(0, thumb_w - 4, thumb_h - 4, 16, 0, 0, 0, 0);
                if (scaled) {
                    SDL_BlitScaled(surf, NULL, scaled, NULL);
                    SDL_BlitSurface(scaled, NULL, screen,
                        &(SDL_Rect){r.x + 2, r.y + 2, thumb_w - 4, thumb_h - 4});
                    SDL_FreeSurface(scaled);
                }
                SDL_FreeSurface(surf);
            }
        } else {
            SDL_FillRect(screen, &(SDL_Rect){r.x + 2, r.y + 2, thumb_w - 4, thumb_h - 4},
                         SDL_MapRGB(screen->format, 40, 40, 40));
        }

        char num[8];
        snprintf(num, sizeof(num), "%d", timeline_idx + 1);
        SDL_Surface* text = TTF_RenderUTF8_Blended(font.tiny, num, COLOR_BLACK);
        if (text) {
            SDL_BlitSurface(text, NULL, screen,
                &(SDL_Rect){center_x + (thumb_w - text->w) / 2, center_y - text->h - 5, text->w, text->h});
            SDL_FreeSurface(text);
        }

        if (timeline_idx == 0) {
            SDL_Surface* first = TTF_RenderUTF8_Blended(font.tiny, "1st", COLOR_WHITE);
            if (first) {
                SDL_BlitSurface(first, NULL, screen,
                    &(SDL_Rect){center_x + (thumb_w - first->w) / 2, center_y + thumb_h + 2, first->w, first->h});
                SDL_FreeSurface(first);
            }
        }
    }

    // Справа: старые кадры — rewind_selected - 1, -2, ..., -right_count
    for (int i = right_count; i >= 1 ; i--) {
        int timeline_idx = rewind_selected - i;
        if (timeline_idx < 0) break;

        int buffer_idx = (rewind_start + (rewind_count - 1 - timeline_idx)) % rewind_buffer_size;
        RewindFrame* frame = &rewind_buffer[buffer_idx];

        int x = center_x + (thumb_w + spacing) * i;
        SDL_Rect r = {x, y, thumb_w, thumb_h};

        SDL_Rect border = {x - 2, y - 2, thumb_w + 4, thumb_h + 4};
        SDL_FillRect(screen, &border, SDL_MapRGB(screen->format, 80, 80, 80));

        if (frame->preview) {
            SDL_Surface* surf = SDL_CreateRGBSurfaceFrom(
                frame->preview, frame->preview_w, frame->preview_h,
                16, frame->preview_w * 2, RGBA_MASK_565
            );
            if (surf) {
                SDL_Surface* scaled = SDL_CreateRGBSurface(0, thumb_w - 4, thumb_h - 4, 16, 0, 0, 0, 0);
                if (scaled) {
                    SDL_BlitScaled(surf, NULL, scaled, NULL);
                    SDL_BlitSurface(scaled, NULL, screen,
                        &(SDL_Rect){r.x + 2, r.y + 2, thumb_w - 4, thumb_h - 4});
                    SDL_FreeSurface(scaled);
                }
                SDL_FreeSurface(surf);
            }
        } else {
            SDL_FillRect(screen, &(SDL_Rect){r.x + 2, r.y + 2, thumb_w - 4, thumb_h - 4},
                         SDL_MapRGB(screen->format, 40, 40, 40));
        }

        char num[8];
        snprintf(num, sizeof(num), "%d", timeline_idx + 1);
        SDL_Surface* text = TTF_RenderUTF8_Blended(font.tiny, num, COLOR_WHITE);
        if (text) {
            SDL_BlitSurface(text, NULL, screen,
                &(SDL_Rect){x + (thumb_w - text->w) / 2, y - text->h - 5, text->w, text->h});
            SDL_FreeSurface(text);
        }

        if (timeline_idx == 0) {
            SDL_Surface* first = TTF_RenderUTF8_Blended(font.tiny, "1st", COLOR_WHITE);
            if (first) {
                SDL_BlitSurface(first, NULL, screen,
                    &(SDL_Rect){x + (thumb_w - first->w) / 2, y + thumb_h + 2, first->w, first->h});
                SDL_FreeSurface(first);
            }
        }
    }

    // Стрелки навигации
    if (rewind_selected > 0) {
        // Можно идти к старым → BTN_RIGHT
        SDL_Surface* right_arrow = TTF_RenderUTF8_Blended(font.small, ">", COLOR_WHITE);
        if (right_arrow) {
            int x = center_x + (thumb_w + spacing) * (right_count + 1);
            SDL_BlitSurface(right_arrow, NULL, screen,
                &(SDL_Rect){x, y + thumb_h/2 - right_arrow->h/2,
                           right_arrow->w, right_arrow->h});
            SDL_FreeSurface(right_arrow);
        }
    }

    if (rewind_selected < rewind_count - 1) {
        // Можно идти к новым → BTN_LEFT
        SDL_Surface* left_arrow = TTF_RenderUTF8_Blended(font.small, "<", COLOR_WHITE);
        if (left_arrow) {
            int x = center_x - (thumb_w + spacing) * (left_count + 1) - left_arrow->w;
            SDL_BlitSurface(left_arrow, NULL, screen,
                &(SDL_Rect){x, y + thumb_h/2 - left_arrow->h/2,
                           left_arrow->w, left_arrow->h});
            SDL_FreeSurface(left_arrow);
        }
    }
}

// =========== УПРОЩЕННАЯ handle_rewind_mode ===========
static int handle_rewind_mode(void) {
    if (!rewind_ui_active) {
        // Если режим перемотки не активен, но есть запрос на активацию
        ButtonMapping* hold_mapping = &config.shortcuts[SHORTCUT_REWIND_HOLD];
        int hold_btn = 1 << hold_mapping->local;
        int menu_pressed = hold_mapping->mod && PAD_isPressed(BTN_MENU);
        int btn_pressed = PAD_isPressed(hold_btn);
        
        // Проверяем, нужно ли активировать перемотку
        if (btn_pressed && (!hold_mapping->mod || menu_pressed) && rewind_count > 0 && rewind_enabled) {
            rewind_ui_active = 1;
            rewind_holding = 1;
            rewind_mode = 2;
            rewind_selected = 0;  // Начинаем с самого старого кадра (0 = самый старый)
            rewind_hold_index = 0;
            rewind_auto_scroll = 1;
            last_rewind_frame_time = SDL_GetTicks();
            LOG_info("Rewind activated in handle_rewind_mode (frames: %d)\n", rewind_count);
        }
        return 0;
    }
    
    if (!rewind_enabled || rewind_count == 0) {
        rewind_ui_active = 0;
        rewind_holding = 0;
        return 0;
    }
    
    // Проверяем границы
    if (rewind_selected < 0) rewind_selected = 0;
    if (rewind_selected >= rewind_count) rewind_selected = rewind_count - 1;
    if (rewind_hold_index >= rewind_count) rewind_hold_index = rewind_count - 1;
    
    LOG_debug("Rewind UI: selected=%d/%d, hold_index=%d, auto_scroll=%d\n",
              rewind_selected, rewind_count, rewind_hold_index, rewind_auto_scroll);

    // Проверяем, удерживается ли еще кнопка перемотки
    ButtonMapping* hold_mapping2 = &config.shortcuts[SHORTCUT_REWIND_HOLD];
    int hold_btn2 = 1 << hold_mapping2->local;
    int menu_pressed2 = hold_mapping2->mod && PAD_isPressed(BTN_MENU);
    int btn_pressed2 = PAD_isPressed(hold_btn2);
    
    // Если кнопка отпущена - завершаем перемотку
    if (!btn_pressed2 || (hold_mapping2->mod && !menu_pressed2)) {
        // 🔒 Паузируем эмуляцию перед загрузкой состояния
        int was_paused = coreThreadPaused;
        if (thread_video && !was_paused) {
            pthread_mutex_lock(&core_mx);
            coreThreadPaused = 1;
            should_run_core = 0;
            pthread_mutex_unlock(&core_mx);
            usleep(10000); // 10ms для стабилизации
        }
        
        if (rewind_selected >= 0 && rewind_selected < rewind_count) {
            LOG_info("Loading rewind frame %d (timeline index)\n", rewind_selected);
            // rewind_selected = индекс кадра (0 = самый старый, rewind_count-1 = самый новый)
            // При загрузке нужно передать количество шагов назад: rewind_count - 1 - rewind_selected
            int steps_back = (rewind_count - 1) - rewind_selected;
            Rewind_loadFrameByIndex(steps_back);
        }
        
        // 🔓 Возобновляем эмуляцию
        if (thread_video && !was_paused) {
            pthread_mutex_lock(&core_mx);
            coreThreadPaused = 0;
            should_run_core = 1;
            pthread_cond_signal(&core_rq);
            pthread_mutex_unlock(&core_mx);
        }
        
        rewind_mode = 0;
        rewind_ui_active = 0;
        rewind_holding = 0;  // Важно: сбросить
        rewind_hold_index = 0;
        rewind_selected = 0;
        rewind_auto_scroll = 1;
        
        // Возобновляем эмуляцию если нужно
        if (thread_video && coreThreadPaused) {
            pthread_mutex_lock(&core_mx);
            coreThreadPaused = 0;
            should_run_core = 1;
            pthread_cond_signal(&core_rq);
            pthread_mutex_unlock(&core_mx);
        }
        return 0;
    }

    PAD_poll();
    uint32_t now = SDL_GetTicks();
    
    // Проверяем, не отключили ли автопрокрутку
    if (PAD_isPressed(BTN_UP) || PAD_isPressed(BTN_DOWN)) {
        rewind_auto_scroll = 0;
    }
    
    // Останавливаем эмуляцию, если не остановлена
    if (thread_video && !coreThreadPaused) {
        pthread_mutex_lock(&core_mx);
        coreThreadPaused = 1;
        should_run_core = 0;
        pthread_mutex_unlock(&core_mx);
    }

    GFX_startFrame();

    // === УПРАВЛЕНИЕ ===
    // Автопрокрутка - идет от старых к новым кадрам (увеличиваем индекс)
    if (rewind_auto_scroll && now - last_rewind_frame_time >= 100) {
        if (rewind_hold_index < rewind_count - 1) {
            rewind_hold_index++;
            rewind_selected = rewind_hold_index; 
            LOG_debug("Auto-scroll: hold_index=%d, selected=%d\n", rewind_hold_index, rewind_selected);
        }
        last_rewind_frame_time = now;
    }

    // Ручное управление - ПРАВИЛЬНАЯ ЛОГИКА:
    // BTN_RIGHT -> к БОЛЕЕ НОВЫМ кадрам (увеличиваем индекс)
    // BTN_LEFT  -> к БОЛЕЕ СТАРЫМ кадрам (уменьшаем индекс)
    if (PAD_justRepeated(BTN_RIGHT)) {  // ⬅️ ЛЕВАЯ стрелка = БОЛЕЕ СТАРЫЕ кадры
        if (rewind_selected > 0) {
            rewind_selected--;
            rewind_auto_scroll = 0;
            LOG_info("Rewind: selected OLDER frame %d/%d\n", rewind_selected, rewind_count);
        }
    } else if (PAD_justRepeated(BTN_LEFT)) {  // ➡️ ПРАВАЯ стрелка = БОЛЕЕ НОВЫЕ кадры
        if (rewind_selected < rewind_count - 1) {
            rewind_selected++;
            rewind_auto_scroll = 0;
            LOG_info("Rewind: selected NEWER frame %d/%d\n", rewind_selected, rewind_count);
        }
    }

    // === ЧЕРНЫЙ ФОН ===
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    
    // === ОТОБРАЖЕНИЕ ПРЕВЬЮ ЧЕРЕЗ Menu_scale ===
    // ВАЖНО: rewind_selected - это индекс в "таймлайне" (0 = самый старый, rewind_count-1 = самый новый)
    // Для получения индекса в буфере: самый старый = rewind_start, самый новый = (rewind_start + rewind_count - 1) % size
    int buffer_idx = (rewind_start + (rewind_count - 1 - rewind_selected)) % rewind_buffer_size;
    
    if (buffer_idx >= 0 && buffer_idx < rewind_buffer_size) {
        RewindFrame* frame = &rewind_buffer[buffer_idx];
        
        if (frame->preview && frame->preview_w > 0 && frame->preview_h > 0) {
            // Создаём поверхность из превью
            SDL_Surface* preview_surf = SDL_CreateRGBSurfaceFrom(
                frame->preview, frame->preview_w, frame->preview_h,
                16, frame->preview_w * 2,
                0xF800, 0x07E0, 0x001F, 0
            );
            if (preview_surf) {
                // Создаём временную поверхность того же размера, что и экран
                SDL_Surface* temp_screen = SDL_CreateRGBSurface(
                    0, DEVICE_WIDTH, DEVICE_HEIGHT, FIXED_DEPTH,
                    screen->format->Rmask, screen->format->Gmask,
                    screen->format->Bmask, 0
                );
                if (temp_screen) {
                    // Очищаем её в чёрный
                    SDL_FillRect(temp_screen, NULL, SDL_MapRGB(temp_screen->format, 0, 0, 0));
    
                    // Масштабируем превью ТОЧНО ТАК ЖЕ, как основной экран
                    Menu_scale(preview_surf, temp_screen);
    
                    // Копируем результат в основной экран
                    SDL_BlitSurface(temp_screen, NULL, screen, NULL);
    
                    SDL_FreeSurface(temp_screen);
                }
                SDL_FreeSurface(preview_surf);
            }
        } else {
            // Если нет превью, показываем серый экран
            SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 40, 40, 40));
        }
    } else {
        // Неверный индекс буфера
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 60, 0, 0));
    }
    
    // === ТАЙМЛАЙН И ТЕКСТ ПОВЕРХ ===
    draw_rewind_timeline(0);

    // Информация о текущем кадре
    char progress_text[64];
    snprintf(progress_text, sizeof(progress_text), "%s: %d/%d",
             language_get_string("REWIND"), rewind_selected + 1, rewind_count);
    SDL_Surface* progress_surf = TTF_RenderUTF8_Blended(font.small, progress_text, COLOR_WHITE);
    if (progress_surf) {
        SDL_BlitSurface(progress_surf, NULL, screen,
            &(SDL_Rect){(DEVICE_WIDTH - progress_surf->w) / 2, 10,
                        progress_surf->w, progress_surf->h});
        SDL_FreeSurface(progress_surf);
    }

    // Подсказка о направлении времени
    char time_direction[64];
    if (rewind_selected == 0) {
        snprintf(time_direction, sizeof(time_direction), "(%s)", language_get_string("NEWEST"));
    } else if (rewind_selected == rewind_count - 1) {
        snprintf(time_direction, sizeof(time_direction), "(%s)", language_get_string("OLDEST"));
    } else {
        // Вычисляем примерное время назад
        float seconds_ago = (rewind_selected) * (REWIND_INTERVAL_MS / 1000.0f);
        snprintf(time_direction, sizeof(time_direction), "(~%.1fs %s)", 
                 seconds_ago, language_get_string("AGO"));
    }
    
    SDL_Surface* time_surf = TTF_RenderUTF8_Blended(font.tiny, time_direction, COLOR_WHITE);
    if (time_surf) {
        SDL_BlitSurface(time_surf, NULL, screen,
            &(SDL_Rect){(DEVICE_WIDTH - time_surf->w) / 2, 35,
                        time_surf->w, time_surf->h});
        SDL_FreeSurface(time_surf);
    }

    // Подсказки управления
    char controls_text[128];
    snprintf(controls_text, sizeof(controls_text), "%s %s / %s %s / %s: %s",
             language_get_string("LEFT"), language_get_string("OLDER"),
             language_get_string("RIGHT"), language_get_string("NEWER"),
             language_get_string("AUTO_SCROLL"), 
             rewind_auto_scroll ? language_get_string("ON") : language_get_string("OFF"));
    
    SDL_Surface* controls_surf = TTF_RenderUTF8_Blended(font.tiny, controls_text, COLOR_WHITE);
    if (controls_surf) {
        SDL_BlitSurface(controls_surf, NULL, screen,
            &(SDL_Rect){(DEVICE_WIDTH - controls_surf->w) / 2, 60,
                        controls_surf->w, controls_surf->h});
        SDL_FreeSurface(controls_surf);
    }

    // Подсказка для выхода
    char exit_hint[64];
    snprintf(exit_hint, sizeof(exit_hint), "%s: %s",
             language_get_string("RELEASE_TO_LOAD"), 
             device_button_names[config.shortcuts[SHORTCUT_REWIND_HOLD].local]);
    
    SDL_Surface* exit_surf = TTF_RenderUTF8_Blended(font.tiny, exit_hint, COLOR_WHITE);
    if (exit_surf) {
        SDL_BlitSurface(exit_surf, NULL, screen,
            &(SDL_Rect){(DEVICE_WIDTH - exit_surf->w) / 2, 
                       DEVICE_HEIGHT - exit_surf->h - 20,
                       exit_surf->w, exit_surf->h});
        SDL_FreeSurface(exit_surf);
    }

    GFX_flip(screen);
    return 1;  // Продолжаем режим перемотки
}

// Функция для парсинга информации о ядре из пути
static int ParseCoreInfoFromPath(const char* core_path, const char* rom_path,
                                 char* tag_name, char* clean_core_name) {
    // Получаем тег из пути к ROM
    getEmuName(rom_path, tag_name);
    
    // Извлекаем имя ядра из имени файла .so
    const char* basename_start = strrchr(core_path, '/');
    if (!basename_start) return 0;
    basename_start++;
    
    char core_filename[MAX_PATH];
    strncpy(core_filename, basename_start, sizeof(core_filename) - 1);
    core_filename[sizeof(core_filename) - 1] = '\0';
    
    // Убираем расширение .so
    char* dot = strrchr(core_filename, '.');
    if (dot && (strcmp(dot, ".so") == 0 || strcmp(dot, ".dll") == 0)) {
        *dot = '\0';
    }
    
    // Убираем суффикс _libretro если есть
    char* suffix = strstr(core_filename, "_libretro");
    if (suffix) {
        *suffix = '\0';
    }
    
    strncpy(clean_core_name, core_filename, MAX_PATH - 1);
    clean_core_name[MAX_PATH - 1] = '\0';
    
    return 1;
}

// Функция для чтения конфигов без загрузки ядра
static int ReadConfigsWithoutCore(const char* tag_name, const char* clean_core_name,
                                  const char* clean_rom_name, int* early_render_mode) {
    LOG_info("Reading configs without loading core...\n");
    // Формируем путь к каталогу конфигов
    char config_dir[MAX_PATH];
    snprintf(config_dir, sizeof(config_dir), "%s/%s-%s", USERDATA_PATH, tag_name, clean_core_name);
    
    LOG_info("Config dir: %s\n", config_dir);
    LOG_info("Clean ROM name: '%s'\n", clean_rom_name);
    
    // Порядок приоритета (от высшего к низшему):
    // 1. Конфиг конкретной игры (game.cfg)
    // 2. Глобальный конфиг ядра (minarch.cfg)
    // 3. Конфиг системы (default.cfg)
    // 4. Системный конфиг (system.cfg)
    
    // 1. Конфиг конкретной игры (наивысший приоритет)
    if (clean_rom_name[0] != '\0') {
        char game_config_path[MAX_PATH];
        snprintf(game_config_path, sizeof(game_config_path), "%s/%s.cfg", config_dir, clean_rom_name);
        
        LOG_info("Checking game config: %s\n", game_config_path);
        if (exists(game_config_path)) {
            *early_render_mode = read_ini_int_value(game_config_path, "minarch_render_mode", -1);
            if (*early_render_mode != -1) {
                LOG_info("Render mode from GAME config: %s\n", *early_render_mode ? "Framebuffer" : "SDL");
                return 1;
            } else {
                LOG_info("Render mode not found in game config\n");
            }
        } else {
            LOG_info("Game config not found\n");
        }
    }
    
    // 2. Глобальный конфиг ядра (minarch.cfg)
    char global_config_path[MAX_PATH];
    snprintf(global_config_path, sizeof(global_config_path), "%s/minarch.cfg", config_dir);
    
    LOG_info("Checking global config: %s\n", global_config_path);
    if (exists(global_config_path)) {
        *early_render_mode = read_ini_int_value(global_config_path, "minarch_render_mode", -1);
        if (*early_render_mode != -1) {
            LOG_info("Render mode from GLOBAL config: %s\n", *early_render_mode ? "Framebuffer" : "SDL");
            return 1;
        } else {
            LOG_info("Render mode not found in global config\n");
        }
    } else {
        LOG_info("Global config not found\n");
    }
    
    // 3. Конфиг системы (default.cfg)
    char default_path[MAX_PATH];
    // Создаем временную копию tag_name для getEmuPath
    char tag_name_copy[MAX_PATH];
    strncpy(tag_name_copy, tag_name, sizeof(tag_name_copy) - 1);
    tag_name_copy[sizeof(tag_name_copy) - 1] = '\0';
    
    getEmuPath(tag_name_copy, default_path);
    char* tmp = strrchr(default_path, '/');
    if (tmp) {
        // Преобразуем /launch.sh в /default.cfg
        strcpy(tmp, "/default.cfg");
        
        LOG_info("Checking default config: %s\n", default_path);
        if (exists(default_path)) {
            *early_render_mode = read_ini_int_value(default_path, "minarch_render_mode", -1);
            if (*early_render_mode != -1) {
                LOG_info("Render mode from DEFAULT config: %s\n", *early_render_mode ? "Framebuffer" : "SDL");
                return 1;
            } else {
                LOG_info("Render mode not found in default config\n");
            }
        } else {
            LOG_info("Default config not found\n");
        }
    }
    
    // 4. Системный конфиг (system.cfg)
    char system_path[MAX_PATH];
    snprintf(system_path, sizeof(system_path), "%s/system.cfg", SYSTEM_PATH);
    
    LOG_info("Checking system config: %s\n", system_path);
    if (exists(system_path)) {
        *early_render_mode = read_ini_int_value(system_path, "minarch_render_mode", 0);
        LOG_info("Render mode from SYSTEM config: %s\n", *early_render_mode ? "Framebuffer" : "SDL");
    } else {
        *early_render_mode = 0; // SDL по умолчанию
        LOG_info("Using DEFAULT render mode: SDL\n");
    }
    
    return 1;
}

// Основная функция загрузки и инициализации (без загрузки ядра!)
static int LoadAndInitialize(const char* core_path, const char* rom_path, 
                             char* tag_name, char* clean_rom_name, 
                             char* clean_core_name, int* early_render_mode) {
    
    LOG_info("LoadAndInitialize started\n");
    
    // === ШАГ 1: Получаем очищенное имя игры ===
    const char* rom_basename = strrchr(rom_path, '/') ? strrchr(rom_path, '/') + 1 : rom_path;
    sanitize_game_name(rom_basename, clean_rom_name, MAX_PATH);
    LOG_info("Game name (cleaned): '%s'\n", clean_rom_name);
    
    // === ШАГ 2: Парсим информацию о ядре ИЗ ПУТИ (без загрузки!) ===
    if (!ParseCoreInfoFromPath(core_path, rom_path, tag_name, clean_core_name)) {
        LOG_error("Failed to parse core info from path\n");
        return 0;
    }
    
    // === ШАГ 3: Читаем конфиги (без загрузки ядра!) ===
    if (!ReadConfigsWithoutCore(tag_name, clean_core_name, clean_rom_name, early_render_mode)) {
        LOG_error("Failed to read configs\n");
        return 0;
    }
    
    LOG_info("Final early render_mode: %s\n", *early_render_mode ? "Framebuffer" : "SDL");
    
    return 1;
}

static void force_frame_update(void) {
    if (!thread_video) return;
    
    // Запрашиваем один кадр от эмулятора
    pthread_mutex_lock(&core_mx);
    if (coreThreadPaused) {
        coreThreadPaused = 0;
        should_run_core = 1;
        pthread_cond_signal(&core_rq);
        
        // Ждем обновления буфера
        pthread_mutex_unlock(&core_mx);
        usleep(30000); // 30ms для гарантированного обновления
        
        // Снова паузируем
        pthread_mutex_lock(&core_mx);
        coreThreadPaused = 1;
        should_run_core = 0;
    }
    pthread_mutex_unlock(&core_mx);
}

int main(int argc, char* argv[]) {
    LOG_info("MinArch started\n");
    
    // === КРИТИЧЕСКИ ВАЖНО: сначала загружаем настройки из INI ===
    // Это включает вывод лога в файл и другие базовые настройки
    loadSettingsFromIni();
    LOG_info("INI settings loaded, logging initialized\n");
    
    // === ДИАГНОСТИКА: начальная информация ===
    LOG_info("=== STARTING DIAGNOSTIC LOG ===\n");
    LOG_info("Compiled: %s %s\n", __DATE__, __TIME__);
    LOG_info("rewind_global_mutex_initialized: %d\n", rewind_global_mutex_initialized);
    LOG_info("rewind_global_mutex address: %p\n", (void*)&rewind_global_mutex);
    
    // === ШАГ 0: Базовая инициализация без экрана ===
    InitSettings();
    PAD_init();
    
    // === Парсинг аргументов ===
    if (argc < 3) {
        LOG_error("Usage: %s <core_path> <rom_path>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    disable_sound_init = 0;
    
    char core_path[MAX_PATH];
    char rom_path[MAX_PATH];
    char tag_name[MAX_PATH] = {0};
    char clean_rom_name[MAX_PATH] = {0};
    char clean_core_name[MAX_PATH] = {0};
    int early_render_mode = 0;
    
    // Проверяем аргументы
    if (strlen(argv[1]) >= MAX_PATH || strlen(argv[2]) >= MAX_PATH) {
        LOG_error("Path too long\n");
        return EXIT_FAILURE;
    }
    
    strcpy(core_path, argv[1]);
    strcpy(rom_path, argv[2]);
    
    LOG_info("Core path: %s\n", core_path);
    LOG_info("ROM path: %s\n", rom_path);
    
    for (int i = 3; i < argc; i++) {
        if (strcmp(argv[i], "--disable-sound-init") == 0) {
            disable_sound_init = 1;
            LOG_info("Sound initialization disabled via command line\n");
        }
    }
    
    // Проверяем существование файлов
    if (!exists(core_path)) {
        LOG_error("Core file does not exist: %s\n", core_path);
        return EXIT_FAILURE;
    }
    
    if (!exists(rom_path)) {
        LOG_error("ROM file does not exist: %s\n", rom_path);
        return EXIT_FAILURE;
    }
    
    // === ШАГ 1: Получаем базовую информацию БЕЗ загрузки ядра ===
    // 1.1. Получаем тег эмулятора из пути к ROM
    getEmuName(rom_path, tag_name);
    LOG_info("Emulator tag: %s\n", tag_name);
    
    // 1.2. Парсим имя ядра из имени файла .so
    const char* basename_start = strrchr(core_path, '/');
    if (!basename_start) {
        LOG_error("Invalid core path: %s\n", core_path);
        return EXIT_FAILURE;
    }
    
    basename_start++; // Пропускаем '/'
    
    // Копируем имя файла
    char core_filename[MAX_PATH];
    strncpy(core_filename, basename_start, sizeof(core_filename) - 1);
    core_filename[sizeof(core_filename) - 1] = '\0';
    
    LOG_info("Core filename: '%s'\n", core_filename);
    
    // Убираем расширение .so
    char* dot = strrchr(core_filename, '.');
    if (dot && (strcmp(dot, ".so") == 0 || strcmp(dot, ".dll") == 0)) {
        *dot = '\0';
    }
    
    // Убираем суффикс _libretro если есть
    char* suffix = strstr(core_filename, "_libretro");
    if (suffix) {
        *suffix = '\0';
    }
    
    // Копируем результат
    strncpy(clean_core_name, core_filename, MAX_PATH - 1);
    clean_core_name[MAX_PATH - 1] = '\0';
    
    LOG_info("Parsed core name: '%s'\n", clean_core_name);
    
    // 1.3. Очищенное имя игры
    const char* rom_basename = strrchr(rom_path, '/') ? strrchr(rom_path, '/') + 1 : rom_path;
    sanitize_game_name(rom_basename, clean_rom_name, MAX_PATH);
    LOG_info("Game name (cleaned): '%s'\n", clean_rom_name);
    
    // === ШАГ 2: Читаем конфиги для определения render_mode ===
    LOG_info("Reading configs without loading core...\n");
    
    // Формируем путь к каталогу конфигов
    char config_dir[MAX_PATH];
    snprintf(config_dir, sizeof(config_dir), "%s/%s-%s", 
             USERDATA_PATH, tag_name, clean_core_name);
    
    LOG_info("Config dir: %s\n", config_dir);
    LOG_info("Clean ROM name: '%s'\n", clean_rom_name);
    
    // Порядок приоритета (от высшего к низшему):
    // 1. Конфиг конкретной игры (game.cfg) - наивысший приоритет
    if (clean_rom_name[0] != '\0') {
        char game_config_path[MAX_PATH];
        snprintf(game_config_path, sizeof(game_config_path), "%s/%s.cfg", 
                 config_dir, clean_rom_name);
        
        LOG_info("Checking game config: %s\n", game_config_path);
        if (exists(game_config_path)) {
            early_render_mode = read_ini_int_value(game_config_path, "minarch_render_mode", -1);
            if (early_render_mode != -1) {
                LOG_info("Render mode from GAME config: %s\n", 
                         early_render_mode ? "Framebuffer" : "SDL");
            } else {
                LOG_info("Render mode not found in game config\n");
            }
        } else {
            LOG_info("Game config not found\n");
        }
    }
    
    // 2. Глобальный конфиг ядра (minarch.cfg)
    if (early_render_mode == -1) {
        char global_config_path[MAX_PATH];
        snprintf(global_config_path, sizeof(global_config_path), "%s/minarch.cfg", config_dir);
        
        LOG_info("Checking global config: %s\n", global_config_path);
        if (exists(global_config_path)) {
            early_render_mode = read_ini_int_value(global_config_path, "minarch_render_mode", -1);
            if (early_render_mode != -1) {
                LOG_info("Render mode from GLOBAL config: %s\n", 
                         early_render_mode ? "Framebuffer" : "SDL");
            } else {
                LOG_info("Render mode not found in global config\n");
            }
        } else {
            LOG_info("Global config not found\n");
        }
    }
    
    // 3. Системный конфиг (system.cfg) - самый низкий приоритет
    if (early_render_mode == -1) {
        char system_path[MAX_PATH];
        snprintf(system_path, sizeof(system_path), "%s/system.cfg", SYSTEM_PATH);
        
        LOG_info("Checking system config: %s\n", system_path);
        if (exists(system_path)) {
            early_render_mode = read_ini_int_value(system_path, "minarch_render_mode", 0);
            LOG_info("Render mode from SYSTEM config: %s\n", 
                     early_render_mode ? "Framebuffer" : "SDL");
        } else {
            early_render_mode = 0; // SDL по умолчанию
            LOG_info("Using DEFAULT render mode: SDL\n");
        }
    }
    
    LOG_info("Final early render_mode: %s\n", 
             early_render_mode ? "Framebuffer" : "SDL");
    
    // === ДИАГНОСТИКА: перед инициализацией мьютекса перемотки ===
    LOG_info("=== DEBUG: Before rewind mutex initialization ===\n");
    LOG_info("rewind_global_mutex_initialized: %d\n", rewind_global_mutex_initialized);
    
    // === ШАГ 2.5: Инициализация мьютекса перемотки (ОЧЕНЬ ВАЖНО!) ===
    if (!rewind_global_mutex_initialized) {
        LOG_info("Initializing rewind_global_mutex...\n");
        int mutex_result = pthread_mutex_init(&rewind_global_mutex, NULL);
        if (mutex_result == 0) {
            rewind_global_mutex_initialized = 1;
            LOG_info("rewind_global_mutex initialized successfully\n");
        } else {
            LOG_error("FAILED to initialize rewind_global_mutex: %d (%s)\n", 
                     mutex_result, strerror(mutex_result));
            // НЕ падаем здесь, но отмечаем что ревинд будет отключен
            rewind_enabled = 0;
        }
    } else {
        LOG_warn("rewind_global_mutex already initialized - possible double init?\n");
    }
    
    // === ДИАГНОСТИКА: тестируем мьютекс ===
    LOG_info("=== DEBUG: Testing rewind mutex ===\n");
    if (rewind_global_mutex_initialized) {
        LOG_info("Testing rewind_global_mutex...\n");
        int lock_result = pthread_mutex_trylock(&rewind_global_mutex);
        if (lock_result == 0) {
            LOG_info("Mutex is unlocked (can acquire) - GOOD\n");
            pthread_mutex_unlock(&rewind_global_mutex);
            LOG_info("Mutex unlocked successfully\n");
        } else if (lock_result == EBUSY) {
            LOG_warn("Mutex is already locked by another thread (should not happen yet!)\n");
        } else {
            LOG_error("Mutex test failed: %d (%s)\n", lock_result, strerror(lock_result));
            // Отключаем ревинд если мьютекс сломан
            rewind_enabled = 0;
        }
    }
    
    // === ШАГ 3: Инициализация графики ===
    LOG_info("Initializing graphics with render_mode: %s\n", 
             early_render_mode ? "Framebuffer" : "SDL");
    
    PLAT_setRenderMode(early_render_mode);
    screen = GFX_init(MODE_MENU);
    
    if (!screen) {
        LOG_error("Failed to initialize graphics!\n");
        // Fallback: пробуем другой режим
        LOG_info("Trying fallback render mode...\n");
        PLAT_setRenderMode(!early_render_mode);
        screen = GFX_init(MODE_MENU);
        
        if (!screen) {
            LOG_error("Failed to initialize graphics in any mode!\n");
            // Очищаем мьютекс перед выходом
            if (rewind_global_mutex_initialized) {
                pthread_mutex_destroy(&rewind_global_mutex);
                rewind_global_mutex_initialized = 0;
            }
            return EXIT_FAILURE;
        }
        early_render_mode = !early_render_mode;
        LOG_info("Using fallback render_mode: %s\n", 
                 early_render_mode ? "Framebuffer" : "SDL");
    }
    
    // Размеры экрана теперь известны
    DEVICE_WIDTH = screen->w;
    DEVICE_HEIGHT = screen->h;
    DEVICE_PITCH = screen->pitch;
    
    LOG_info("Screen initialized: %dx%d, pitch=%d\n", 
             DEVICE_WIDTH, DEVICE_HEIGHT, DEVICE_PITCH);
    
    // Сохраняем очищенное имя игры в глобальной переменной
    strncpy(g_clean_rom_name, clean_rom_name, sizeof(g_clean_rom_name) - 1);
    g_clean_rom_name[sizeof(g_clean_rom_name) - 1] = '\0';
    
    // Создаем пути для файлов
    get_name(file_path, file_name, rom_path);
    snprintf(txt_path, sizeof(txt_path), "/mnt%s.res/%s.txt", file_path, file_name);
    LOG_info("ROM file path: %s, file name: %s\n", file_path, file_name);
    LOG_info("TXT path: %s\n", txt_path);
    
    // === ШАГ 4: ТЕПЕРЬ загружаем ядро ПОЛНОСТЬЮ ===
    ShowLoadingProgress(1, 8, language_get_string("LOAD_CORE"));
    LOG_info("=== DEBUG: Before Core_open ===\n");
    LOG_info("rewind_global_mutex_initialized: %d\n", rewind_global_mutex_initialized);
    
    Core_open(core_path, tag_name);
    
    if (!core.handle) {
        LOG_error("Failed to load core library\n");
        ShowLoadingProgress(8, 8, language_get_string("ERROR_LOAD_CORE"));
        SDL_Delay(2000);
        // Очищаем мьютекс перед выходом
        if (rewind_global_mutex_initialized) {
            pthread_mutex_destroy(&rewind_global_mutex);
            rewind_global_mutex_initialized = 0;
        }
        GFX_quit(COLOR_BLACK_V);
        return EXIT_FAILURE;
    }
    
    // Проверяем информацию о ядре
    if (core.get_system_info) {
        struct retro_system_info loaded_info = {0};
        core.get_system_info(&loaded_info);
        
        LOG_info("Core fully loaded: %s %s\n", 
                 loaded_info.library_name ? loaded_info.library_name : "Unknown",
                 loaded_info.library_version ? loaded_info.library_version : "Unknown");
    }
    
    // === ДИАГНОСТИКА: после загрузки ядра ===
    LOG_info("=== DEBUG: After Core_open ===\n");
    LOG_info("core.handle: %p\n", (void*)core.handle);
    LOG_info("rewind_global_mutex_initialized: %d\n", rewind_global_mutex_initialized);
    
    // === ШАГ 5: Полная загрузка конфигурации ===
    ShowLoadingProgress(2, 8, language_get_string("LOAD_SETTINGS"));
    simple_mode = exists(SIMPLE_MODE_PATH);
    
    // Включаем все ядра CPU для корректной загрузки
    LOG_info("Enabling all CPU cores for config loading...\n");
    set_active_cpu_cores(0);
    
    // Используем СТАНДАРТНЫЙ механизм загрузки конфига
    Config_load();
    Config_init();
    
    // Читаем опции из всех доступных конфигов
    Config_readOptionsString(config.system_cfg);
    Config_readOptionsString(config.default_cfg);
    Config_readOptionsString(config.user_cfg);
    
    // Синхронизируем render_mode с уже установленным значением
    Option* render_option = &config.frontend.options[FE_OPT_RENDER_MODE];
    render_option->value = early_render_mode;
    LOG_info("Synced render_mode to config: %s\n", 
             early_render_mode ? "Framebuffer" : "SDL");
    
    // === ДИАГНОСТИКА: перед настройкой CPU ===
    LOG_info("=== DEBUG: Before CPU configuration ===\n");
    
    // ПРИМЕНЯЕМ НАСТРОЙКИ CPU
    Option* cpu_option = &config.frontend.options[FE_OPT_CPU_CORES];
    int cores_to_keep = cpu_option->value;
    
    LOG_info("CPU cores configuration:\n");
    LOG_info("  cpu_option->value: %d\n", cpu_option->value);
    LOG_info("  cores_to_keep: %d\n", cores_to_keep);
    LOG_info("  Current thread: %lu\n", (unsigned long)pthread_self());
    
    // Включаем все ядра перед настройкой
    LOG_info("Enabling all CPU cores before configuration...\n");
    set_active_cpu_cores(0);
    usleep(500000); // 500ms для стабилизации
    
    LOG_info("Applying CPU settings: %d cores\n", cores_to_keep);
    
    // === ДИАГНОСТИКА: Временная заглушка для управления CPU ===
    LOG_info("=== DEBUG: Entering set_active_cpu_cores STUB ===\n");
    LOG_info("Requested cores: %d\n", cores_to_keep);
    LOG_info("Doing nothing in stub (keeping all cores active)...\n");
    // НИЧЕГО не делаем в заглушке - просто логируем
    usleep(1000); // Минимальная задержка для стабильности
    
    LOG_info("=== DEBUG: After CPU configuration ===\n");
    
    // === ШАГ 6: Инициализация ядра эмулятора ===
    ShowLoadingProgress(3, 8, language_get_string("CORE_INIT"));
    LOG_info("=== DEBUG: Before Core_init ===\n");
    
    Core_init();
    
    LOG_info("=== DEBUG: After Core_init ===\n");
    LOG_info("core.initialized: %d\n", core.initialized);
    
    if (!core.initialized) {
        LOG_error("Failed to initialize core!\n");
        ShowLoadingProgress(8, 8, language_get_string("ERROR_CORE_INIT"));
        SDL_Delay(2000);
        goto finish;
    }

    // === ШАГ 7: Настройка меню ===
    localize_frontend_options();
    options_menu.items = (MenuItem[]) {
        {language_get_string("FRONTEND"), "MinUIcustom (" BUILD_DATE ")", .on_confirm=OptionFrontend_openMenu},
        {language_get_string("EMULATOR"), .on_confirm=OptionEmulator_openMenu},
        {language_get_string("CONTROLS"), .on_confirm=OptionControls_openMenu},
        {language_get_string("SHORTCUTS"), .on_confirm=OptionShortcuts_openMenu},
        {language_get_string("SAVE_CHANGES"), .on_confirm=OptionSaveChanges_openMenu},
        {NULL},
        {NULL},
        {NULL},
    };
    OptionSaveChanges_menu.items = (MenuItem[]){
        {language_get_string("SAVE_FOR_CONSOLE")},
        {language_get_string("SAVE_FOR_GAME")},
        {language_get_string("SAVE_RESTORE")},
        {NULL},
    };
    OptionControls_menu.desc = language_get_string("INFO_PRESS_A_OR_X");
    OptionShortcuts_menu.desc = language_get_string("INFO_PRESS_A_OR_X");

    // === ШАГ 8: Загрузка игры ===
    ShowLoadingProgress(4, 8, language_get_string("LOAD_GAME"));
    Game_open(rom_path);
    if (!game.is_open) {
        LOG_error("Failed to load game\n");
        ShowLoadingProgress(8, 8, language_get_string("ERROR_LOAD_GAME"));
        SDL_Delay(2000);
        goto finish;
    }

    options_menu.items[1].desc = (char*)core.version;

    // === ШАГ 9: Загрузка эмулятора ===
    ShowLoadingProgress(5, 8, language_get_string("LOAD_EMULATOR"));
    Core_load();
    
    // Инициализация ввода
    Input_init(NULL);
    
    // Чтение управлений
    Config_readControls();
    Config_free();
    
    // Инициализация меню и состояний
    Menu_init();
    State_resume();
    Menu_initState();
    
    // Инициализация вибрации
    VIB_init();
    
    // Инициализация питания
    PWR_init();
    if (!HAS_POWER_BUTTON) PWR_disableSleep();
    
    // Инициализация цифрового отображения
    MSG_init();
    
    // Инициализация звука (если не отключена через параметр)
    if (!disable_sound_init) {
        SND_init(core.sample_rate, core.fps);
        LOG_info("Sound system initialized (sample rate: %.0f, fps: %.2f)\n", 
                core.sample_rate, core.fps);
    } else {
        LOG_info("Sound initialization SKIPPED (core provides its own audio)\n");
    }
    
    // === ШАГ 10: Отображаем прогресс загрузки ===
    ShowLoadingProgress(7, 8, language_get_string("LOAD_END"));
    
    // === ДИАГНОСТИКА: перед созданием потоков ===
    LOG_info("=== DEBUG: Before thread creation ===\n");
    LOG_info("rewind_global_mutex_initialized: %d\n", rewind_global_mutex_initialized);
    LOG_info("Memory check:\n");
    LOG_info("  rewind_buffer: %p\n", (void*)rewind_buffer);
    LOG_info("  rewind_slot_mutexes: %p\n", (void*)rewind_slot_mutexes);
    LOG_info("  rewind_buffer_size: %d\n", rewind_buffer_size);
    LOG_info("  rewind_enabled: %d\n", rewind_enabled);
    
    // Инициализация потоков
    if (pthread_mutex_init(&core_mx, NULL) != 0 ||
        pthread_cond_init(&core_rq, NULL) != 0) {
        LOG_error("Failed to initialize threading primitives");
        goto finish;
    }
    
    // Создаем потоки
    should_run_core = 0;
    should_run_flip = 0;
    coreThreadPaused = 1;
    
    int active_cores = get_active_cpu_count();
    if (active_cores < 0) active_cores = 4;
    LOG_info("Creating threads. Active cores: %d\n", active_cores);
    
    if (pthread_create(&core_pt, NULL, &coreThread, NULL) != 0) {
        LOG_error("Failed to create emulation thread\n");
        goto finish;
    }
    
    // Ждем инициализации потоков
    int timeout = 500;
    int core_started = 0;

    while ((!core_started) && timeout-- > 0) {
        usleep(10000);
        
        if (!core_started && coreThreadStarted) {
            core_started = 1;
            LOG_info("Emulation thread started\n");
        }
    }

    if (!core_started) {
        LOG_error("Threads failed to initialize\n");
        quit = 1;
        goto finish;
    }
    
    // Настройка привязки потоков
    if (active_cores >= 2) {
        if (set_thread_affinity(core_pt, 1) == 0) {
            LOG_info("Emulation thread bound to CPU1\n");
        } else {
            set_thread_affinity(core_pt, 0);
        }
    }
    
    // Основной поток на CPU0
    cpu_set_t cpuset_main;
    CPU_ZERO(&cpuset_main);
    CPU_SET(0, &cpuset_main);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset_main);
    
    // Включаем многопоточность если нужно
    Option* thread_option = &config.frontend.options[FE_OPT_THREAD];
    if (thread_option->value == 1) {
        LOG_info("Enabling multithreading\n");
        toggle_threading(1);
    }
    
    // Инициализация переменных
    PWR_warn(1);
    PWR_disableAutosleep();
    sec_start = SDL_GetTicks();
    config_load_done = 1;
    
    // Применяем отложенные настройки
    ApplyDeferredGraphicsSettings();
    
    // Очищаем экран
    GFX_clearAll();
    
    // === ДИАГНОСТИКА: перед входом в главный цикл ===
    LOG_info("=== DEBUG: Entering main loop ===\n");
    LOG_info("Current state:\n");
    LOG_info("  quit: %d\n", quit);
    LOG_info("  rewind_global_mutex_initialized: %d\n", rewind_global_mutex_initialized);
    LOG_info("  rewind_enabled: %d\n", rewind_enabled);
    LOG_info("  show_menu: %d\n", show_menu);
    LOG_info("  config_load_done: %d\n", config_load_done);
    
    // === НАЧАЛО ИГРОВОГО ЦИКЛА ===
    while (!quit) {
    	// === ПЕРЕМОТКА ИМЕЕТ ПРИОРИТЕТ ===
    	if (handle_rewind_mode()) continue;

    	GFX_startFrame();
    	
    	// === ОБРАБОТКА ЗАПРОСОВ SHORTCUT'ов ===
		if (!show_menu && !rewind_ui_active && !fast_forward) {
    		if (get_shortcut_flag(SHORTCUT_SCREENSHOT)) {
        		screenshot_requested = 1;
        		clear_shortcut_flag(SHORTCUT_SCREENSHOT);
    		}
    		if (get_shortcut_flag(SHORTCUT_SAVE_STATE)) {
        		save_state_requested = 1;
        		clear_shortcut_flag(SHORTCUT_SAVE_STATE);
    		}
    		if (get_shortcut_flag(SHORTCUT_LOAD_STATE)) {
        		load_state_requested = 1;
        		clear_shortcut_flag(SHORTCUT_LOAD_STATE);
    		}
    		if (get_shortcut_flag(SHORTCUT_RESET_GAME)) {
        		reset_requested = 1;
        		clear_shortcut_flag(SHORTCUT_RESET_GAME);
    		}
    		if (get_shortcut_flag(SHORTCUT_CYCLE_SCALE)) {
        		cycle_scale_requested = 1;
        		clear_shortcut_flag(SHORTCUT_CYCLE_SCALE);
    		}
		}
		if (rewind_activation_requested && !rewind_ui_active && rewind_count > 0 && rewind_enabled) {
			rewind_activation_requested = 0;
			rewind_holding = 1;
			rewind_ui_active = 1;
			rewind_mode = 2;
			rewind_selected = 0;  // Начинаем с самого нового кадра
			rewind_hold_index = 0;
			rewind_auto_scroll = 1;
			last_rewind_frame_time = SDL_GetTicks();
			LOG_info("Rewind activated (frames available: %d)\n", rewind_count);
		}
		
		// === ВЫПОЛНЕНИЕ ЗАПРОСОВ ===
		if (screenshot_requested) {
    		take_screenshot();
    		screenshot_requested = 0;
		}
		if (save_state_requested) {
    		Menu_saveState();
    		save_state_requested = 0;
		}
		if (load_state_requested) {
    		Menu_loadState();
    		load_state_requested = 0;
		}
		if (reset_requested) {
    		core.reset();
    		reset_requested = 0;
		}
		if (cycle_scale_requested) {
    		screen_scaling = (screen_scaling + 1) % SCALE_COUNT;
    		Config_syncFrontend(config.frontend.options[FE_OPT_SCALING].key, screen_scaling);
    		selectScaler(renderer.true_w, renderer.true_h, renderer.src_p);
    		cycle_scale_requested = 0;
		}
	
    	if (thread_video && config_load_done && !show_menu && !rewind_ui_active) {
    		pthread_mutex_lock(&buffer_swap_mutex);
    		int ri = read_index;
    		pthread_mutex_unlock(&buffer_swap_mutex);
		
    		if (ri >= 0 && frame_slots[ri].ready) {
        		FrameSlot *slot = &frame_slots[ri];
        		video_refresh_callback_main(slot->data, slot->w, slot->h, slot->pitch);
        		slot->ready = 0;
    		}
		
    		trackFPS();
    		usleep(1000);
		}
    	else if (!thread_video && config_load_done && !show_menu && !rewind_ui_active) {
			core.run();
			limitFF();
			trackFPS();
			
			// 🔥 Сохраняем кадры для перемотки в однопоточном режиме
			handle_rewind_in_single_thread();
		}
    	
    	// Меню
    	PAD_poll();
    	static uint32_t last_menu_check = 0;
    	uint32_t now = SDL_GetTicks();
    	if (PAD_justReleased(BTN_MENU) && (now - last_menu_check > 100) && !rewind_ui_active) {
    		// ПРИНУДИТЕЛЬНО ОБНОВЛЯЕМ БУФЕР ПЕРЕД МЕНЮ
    		if (thread_video) {
        		force_frame_update();
    		}
    		
    		show_menu = 1;
    		last_menu_check = now;
		}
    	
    	if (show_menu) {
    		if (thread_video && !coreThreadPaused) {
        		// Приостанавливаем поток эмуляции
        		pthread_mutex_lock(&core_mx);
        		coreThreadPaused = 1;
        		should_run_core = 0;
        		pthread_mutex_unlock(&core_mx);
        		// Ждём, пока он завершит текущий кадр
        		usleep(10000); // 10 мс — достаточно для корректной остановки
    		}
    		Menu_loop();
    		// После выхода из меню — возобновляем
    		if (thread_video && coreThreadPaused) {
        		pthread_mutex_lock(&core_mx);
        		coreThreadPaused = 0;
        		should_run_core = 1;
        		pthread_cond_signal(&core_rq);
        		pthread_mutex_unlock(&core_mx);
    		}
    		show_menu = 0;
		}
    	
    	if (toggle_thread) {
        	toggle_thread = 0;
        	toggle_threading(waitforthread);
    	}
    	
    	if (!thread_video && !rewind_ui_active) {
        	usleep(1000);
    	}
	}
    
    // Завершение работы
    Menu_quit();
    QuitSettings();
    
finish:
    Game_close();
    Core_unload();
    Core_quit();
    Core_close();
    Config_quit();

    // ЕДИНСТВЕННЫЙ вызов завершения потоков
    cleanup_threads();
    
    if (rewind_buffer) {
    	for (int i = 0; i < rewind_buffer_size; i++) {
        	free(rewind_buffer[i].data);
        	free(rewind_buffer[i].preview);
        	if (rewind_slot_mutexes) {
            	pthread_mutex_destroy(&rewind_slot_mutexes[i]);
        	}
    	}
    	free(rewind_buffer);
    	free(rewind_slot_mutexes);
    	rewind_buffer = NULL;
    	rewind_slot_mutexes = NULL;
    	rewind_buffer_size = 0;
    	rewind_initialized = 0;
	}

    // Восстановление CPU ядер
    LOG_info("Включаем все CPU ядра перед выходом...\n");
    DIR *dir = opendir(SYS_CPU_PATH);
    if (dir) {
        struct dirent *entry;
        int max_cpus = 0;
        while ((entry = readdir(dir)) != NULL) {
            if (strncmp(entry->d_name, "cpu", 3) == 0) {
                int cpu_num = atoi(entry->d_name + 3);
                if (cpu_num > max_cpus) max_cpus = cpu_num;
            }
        }
        closedir(dir);
        for (int i = 0; i <= max_cpus; i++) {
            enable_cpu_core(i);
        }
        LOG_info("Все %d ядер CPU включены\n", max_cpus + 1);
    }
    
    for (int i = 0; i < rewind_buffer_size; i++) {
    	if (rewind_buffer[i].data) {
        	free(rewind_buffer[i].data);
        	rewind_buffer[i].data = NULL;
    	}
	}
    MSG_quit();
    PWR_quit();
    VIB_quit();
    SND_quit();
    PAD_quit();
    GFX_quit(COLOR_BLACK_V);
    buffer_dealloc();

    return EXIT_SUCCESS;
}
