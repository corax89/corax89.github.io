#include <sys/sysinfo.h>
#include "libretro.h"
#include "defines.h"
#include "api.h"
#include "utils.h"
#include "scaler.h"

#ifndef MAX_WIDTH
#define MAX_WIDTH 800
#endif
#ifndef MAX_HEIGHT
#define MAX_HEIGHT 600
#endif

#define MAX_CORE_BUTTONS 32

#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]) - 1)

static int DEVICE_WIDTH = FIXED_WIDTH;
static int DEVICE_HEIGHT = FIXED_HEIGHT;
static int DEVICE_PITCH = FIXED_PITCH;
#define COLOR_BLACK_V			(SDL_Color){color_triad_black_r, color_triad_black_g, color_triad_black_b}

extern void PLAT_setRenderMode(int use_fb);

GFX_Renderer renderer;

static char g_clean_rom_name[MAX_PATH] = {0};

enum {
	SCALE_NATIVE,
	SCALE_ASPECT,
	SCALE_FULLSCREEN,
#ifdef CROP_OVERSCAN
	SCALE_CROPPED,
#endif
	SCALE_COUNT,
};

static int has_pending_opt_change = 0;

#define DOUBLE_BUFFER_COUNT 2

typedef struct {
    const void* data;        // ← указатель от ядра
    unsigned w, h;
    size_t pitch;
    volatile int ready;
} FrameSlot;

static FrameSlot frame_slots[DOUBLE_BUFFER_COUNT];
static volatile int write_index = 0;
static volatile int read_index = -1;
static pthread_mutex_t buffer_swap_mutex = PTHREAD_MUTEX_INITIALIZER;

static int has_pending_thread_change = 0;
static SDL_Surface* screen;
static int frame_skip_enabled = 0;   // включён ли автоскип

typedef struct {
    void* data;
    size_t size;
    uint16_t* preview;
    int preview_w, preview_h;
    // Флаг готовности не нужен - используем мьютексы
} RewindFrame;

static RewindFrame* rewind_buffer = NULL;
static int rewind_buffer_size = 0; // фактический размер буфера (в слотах)
static int rewind_initialized = 0; // флаг: буфер уже выделен?
static int rewind_index = 0;
#define rewind_enabled (config.frontend.options[FE_OPT_REWIND].value)
static int rewind_ui_active = 0;
static int rewind_selected = 0;
static int rewind_auto_scroll = 1;
static int rewind_mode = 0; // 0 = выкл, 1 = меню, 2 = удержание
static int rewind_hold_index = 0;
static uint32_t last_rewind_save = 0;
static const uint32_t REWIND_INTERVAL_MS = 500; // ~2 кадров при 30 FPS
static int rewind_start = 0; // индекс первого валидного кадра
static int rewind_count = 0; // количество валидных кадров (<= REWIND_BUFFER_SIZE)
static uint32_t rewind_hold_start = 0;
static uint32_t rewind_frame_delay = 150; // мс между кадрами при удержании
static uint32_t last_rewind_frame_time = 0;
// Мьютекс для защиты renderer.src
static pthread_mutex_t renderer_mutex = PTHREAD_MUTEX_INITIALIZER;

// Мьютексы для каждого слота перемотки (инициализируются динамически)
static pthread_mutex_t* rewind_slot_mutexes = NULL;

const char inifile[] = SYSTEM_PATH "/uisettings.ini";

int emulators_settings_hide = 0;

int color_triad_black_r = 0x1;
int color_triad_black_g = 0x1;
int color_triad_black_b = 0x1;

int colors_b[6][3] = {
	{0x1, 0x1, 0x1},
	{0xfe, 0xc2, 0x60},
	{0x1e, 0x51, 0x28},
	{0x09, 0x26, 0x35},
	{0x75, 0x0e, 0x21},
	{0x43, 0x0a, 0x5d},
	};

// === THREAD SUPPORT ===
static int thread_video = 0;
static int should_run_core = 0;
static int should_run_flip = 0;
static int coreThreadStarted = 0;
static int coreThreadPaused = 0;
static int toggle_thread = 0;
static int waitforthread = 0;
static int config_load_done = 0;

static pthread_t		core_pt;
static pthread_mutex_t	core_mx;
static pthread_cond_t	core_rq;
// =======================

// default frontend options
static int screen_scaling = SCALE_ASPECT;
static int screen_sharpness = SHARPNESS_SOFT;
static int prevent_tearing = 1; // lenient
static int max_ff_speed = 3; // 4x
static int fast_forward = 0;
static int overclock = 1; // normal
extern char debug_text;
extern int show_debug;

///////////////////////////////////////

static struct Core {
	int initialized;
	int need_fullpath;
	
	const char tag[8]; // eg. GBC
	const char name[128]; // eg. gambatte
	const char version[128]; // eg. Gambatte (v0.5.0-netlink 7e02df6)
	const char extensions[128]; // eg. gb|gbc|dmg
	
	const char config_dir[MAX_PATH]; // eg. /mnt/sdcard/.userdata/rg35xx/GB-gambatte
	const char states_dir[MAX_PATH]; // eg. /mnt/sdcard/.userdata/arm-480/GB-gambatte
	const char saves_dir[MAX_PATH]; // eg. /mnt/sdcard/Saves/GB
	const char bios_dir[MAX_PATH]; // eg. /mnt/sdcard/Bios/GB
	
	double fps;
	double sample_rate;
	double aspect_ratio;
	
	void* handle;
	void (*init)(void);
	void (*deinit)(void);
	
	void (*get_system_info)(struct retro_system_info *info);
	void (*get_system_av_info)(struct retro_system_av_info *info);
	void (*set_controller_port_device)(unsigned port, unsigned device);
	
	void (*reset)(void);
	void (*run)(void);
	size_t (*serialize_size)(void);
	bool (*serialize)(void *data, size_t size);
	bool (*unserialize)(const void *data, size_t size);
	bool (*load_game)(const struct retro_game_info *game);
	bool (*load_game_special)(unsigned game_type, const struct retro_game_info *info, size_t num_info);
	void (*unload_game)(void);
	unsigned (*get_region)(void);
	void *(*get_memory_data)(unsigned id);
	size_t (*get_memory_size)(unsigned id);
	
	// retro_audio_buffer_status_callback_t audio_buffer_status;
} core;

static struct Game {
	char path[MAX_PATH];
	char name[MAX_PATH]; // TODO: rename to basename?
	char m3u_path[MAX_PATH];
	char tmp_path[MAX_PATH]; // location of unzipped file
	void* data;
	size_t size;
	int is_open;
} game;

#ifndef CROP_OVERSCAN
	int SCALE_CROPPED = -1;
#endif

enum {
    DEBUG_OFF = 0,
    DEBUG_FPS,
    DEBUG_BATTERY,
    DEBUG_FPS_BATTERY,
    DEBUG_FPS_BATTERY_CPU,
    DEBUG_COUNT
};

///////////////////////////////

typedef struct Option {
	char* key;
	char* name; // desc
	char* desc; // info, truncated
	char* full; // info, longer but possibly still truncated
	char* var;
	int default_value;
	int value;
	int count; // TODO: drop this?
	int lock;
	char** values;
	char** labels;
} Option;
typedef struct OptionList {
	int count;
	int changed;
	Option* options;
	
	int enabled_count;
	Option** enabled_options;
	// OptionList_callback_t on_set;
} OptionList;

static char* onoff_values[] = {
	"Off",
	"On",
	NULL
};
static char* scaling_values[] = {
	"Native",
	"Aspect",
	"Fullscreen",
#ifdef CROP_OVERSCAN
	"Cropped",
#endif
	NULL
};
static char* sharpness_values[] = {
	"Sharp",
	"Crisp",
	"Soft",
	"Fast",
	"Crt1",
	"Crt2",
	"Crt3",
	"Noise",
	"Scale2x",
	NULL
};
static char* sharpness_labels[] = {
	"Sharp",
	"Crisp",
	"Soft",
	"Fast",
	"Crt1",
	"Crt2",
	"Crt3",
	"Noise",
	"Scale2x",
	NULL
};
static char* tearing_labels[] = {
	"Off",
	"Lenient",
	"Strict",
	NULL
};
static char* max_ff_labels[] = {
	"None",
	"2x",
	"3x",
	"4x",
	"5x",
	"6x",
	"7x",
	"8x",
	NULL,
};
static char* debug_values[] = {
    "OFF", 
    "FPS", 
    "BAT", 
    "FPS+BAT", 
    "FPS+BAT+CPU", 
    NULL
};

static char* onoff_labels[3];
static char* thread_labels[3];     // 2 + NULL
static char* debug_labels[6];      // 5 + NULL
static char* scaling_labels[5];    // 3 или 4 + NULL (в зависимости от CROP_OVERSCAN)

static char* cpu_cores_values[] = {
    "4", "1", "2", "3", NULL
};

static char* cpu_cores_labels[] = {
    "all", "1", "2", "3", NULL
};

static char* thread_values[] = {
    "Off", "On", NULL
};

static char* frameskip_values[] = {
    "Off","On", NULL
};
static char* frameskip_labels[] = {
    "Off","On", NULL
};
static char* render_mode_values[] = {
    "SDL",
    "Framebuffer",
    NULL
};
static char* render_mode_labels[3]; // будет заполнено локализацией
static char* rewind_values[] = { "Off", "On", NULL };
static char* rewind_labels[] = { "Off", "On", NULL };
static char* localized_sharpness_labels[sizeof(sharpness_values) / sizeof(sharpness_values[0])];

enum {
	FE_OPT_SCALING,
	FE_OPT_SHARPNESS,
	FE_OPT_DEBUG,
	FE_OPT_MAXFF,
	FE_OPT_CPU_CORES,
	FE_OPT_THREAD,
	FE_OPT_REWIND,
	FE_OPT_FRAMESKIP,
	FE_OPT_RENDER_MODE,
	FE_OPT_COUNT,
};

enum {
	SHORTCUT_SAVE_STATE,
	SHORTCUT_LOAD_STATE,
	SHORTCUT_RESET_GAME,
	SHORTCUT_CYCLE_SCALE,
	SHORTCUT_TOGGLE_FF,
	SHORTCUT_HOLD_FF,
	SHORTCUT_SCREENSHOT,
    SHORTCUT_REWIND_HOLD,    // удержание для перемотки
	SHORTCUT_COUNT,
};

#define LOCAL_BUTTON_COUNT 16 // depends on device
#define RETRO_BUTTON_COUNT 16 // allow L3/R3 to be remapped by user if desired, eg. Virtual Boy uses extra buttons for right d-pad

typedef struct ButtonMapping { 
	char* name;
	int retro;
	int local; // TODO: dislike this name...
	int mod;
	int default_;
	int ignore;
} ButtonMapping;

static ButtonMapping default_button_mapping[MAX_CORE_BUTTONS] = { // used if pak.cfg doesn't exist or doesn't have bindings
	{"Up",			RETRO_DEVICE_ID_JOYPAD_UP,		BTN_ID_UP},
	{"Down",		RETRO_DEVICE_ID_JOYPAD_DOWN,	BTN_ID_DOWN},
	{"Left",		RETRO_DEVICE_ID_JOYPAD_LEFT,	BTN_ID_LEFT},
	{"Right",		RETRO_DEVICE_ID_JOYPAD_RIGHT,	BTN_ID_RIGHT},
	{"A Button",	RETRO_DEVICE_ID_JOYPAD_A,		BTN_ID_A},
	{"B Button",	RETRO_DEVICE_ID_JOYPAD_B,		BTN_ID_B},
	{"X Button",	RETRO_DEVICE_ID_JOYPAD_X,		BTN_ID_X},
	{"Y Button",	RETRO_DEVICE_ID_JOYPAD_Y,		BTN_ID_Y},
	{"Start",		RETRO_DEVICE_ID_JOYPAD_START,	BTN_ID_START},
	{"Select",		RETRO_DEVICE_ID_JOYPAD_SELECT,	BTN_ID_SELECT},
	{"L1 Button",	RETRO_DEVICE_ID_JOYPAD_L,		BTN_ID_L1},
	{"R1 Button",	RETRO_DEVICE_ID_JOYPAD_R,		BTN_ID_R1},
	{"L2 Button",	RETRO_DEVICE_ID_JOYPAD_L2,		BTN_ID_L2},
	{"R2 Button",	RETRO_DEVICE_ID_JOYPAD_R2,		BTN_ID_R2},
	{"L3 Button",	RETRO_DEVICE_ID_JOYPAD_L3,		BTN_ID_L3},
	{"R3 Button",	RETRO_DEVICE_ID_JOYPAD_R3,		BTN_ID_R3},
	{NULL,0,0}
};
static ButtonMapping button_label_mapping[MAX_CORE_BUTTONS] = { // used to lookup the retro_id and local btn_id from button name
	{"NONE",	-1,								BTN_ID_NONE},
	{"UP",		RETRO_DEVICE_ID_JOYPAD_UP,		BTN_ID_UP},
	{"DOWN",	RETRO_DEVICE_ID_JOYPAD_DOWN,	BTN_ID_DOWN},
	{"LEFT",	RETRO_DEVICE_ID_JOYPAD_LEFT,	BTN_ID_LEFT},
	{"RIGHT",	RETRO_DEVICE_ID_JOYPAD_RIGHT,	BTN_ID_RIGHT},
	{"A",		RETRO_DEVICE_ID_JOYPAD_A,		BTN_ID_A},
	{"B",		RETRO_DEVICE_ID_JOYPAD_B,		BTN_ID_B},
	{"X",		RETRO_DEVICE_ID_JOYPAD_X,		BTN_ID_X},
	{"Y",		RETRO_DEVICE_ID_JOYPAD_Y,		BTN_ID_Y},
	{"START",	RETRO_DEVICE_ID_JOYPAD_START,	BTN_ID_START},
	{"SELECT",	RETRO_DEVICE_ID_JOYPAD_SELECT,	BTN_ID_SELECT},
	{"L1",		RETRO_DEVICE_ID_JOYPAD_L,		BTN_ID_L1},
	{"R1",		RETRO_DEVICE_ID_JOYPAD_R,		BTN_ID_R1},
	{"L2",		RETRO_DEVICE_ID_JOYPAD_L2,		BTN_ID_L2},
	{"R2",		RETRO_DEVICE_ID_JOYPAD_R2,		BTN_ID_R2},
	{"L3",		RETRO_DEVICE_ID_JOYPAD_L3,		BTN_ID_L3},
	{"R3",		RETRO_DEVICE_ID_JOYPAD_R3,		BTN_ID_R3},
	{NULL,0,0}
};
static ButtonMapping core_button_mapping[RETRO_BUTTON_COUNT+1] = {0};

static const char* device_button_names[MAX_CORE_BUTTONS] = {
	[BTN_ID_UP]		= "UP",
	[BTN_ID_DOWN]	= "DOWN",
	[BTN_ID_LEFT]	= "LEFT",
	[BTN_ID_RIGHT]	= "RIGHT",
	[BTN_ID_SELECT]	= "SELECT",
	[BTN_ID_START]	= "START",
	[BTN_ID_Y]		= "Y",
	[BTN_ID_X]		= "X",
	[BTN_ID_B]		= "B",
	[BTN_ID_A]		= "A",
	[BTN_ID_L1]		= "L1",
	[BTN_ID_R1]		= "R1",
	[BTN_ID_L2]		= "L2",
	[BTN_ID_R2]		= "R2",
	[BTN_ID_L3]		= "L3",
	[BTN_ID_R3]		= "R3",
};


// NOTE: these must be in BTN_ID_ order also off by 1 because of NONE (which is -1 in BTN_ID_ land)
static char* button_labels[] = {
	"NONE", // displayed by default
	"UP",
	"DOWN",
	"LEFT",
	"RIGHT",
	"A",
	"B",
	"X",
	"Y",
	"START",
	"SELECT",
	"L1",
	"R1",
	"L2",
	"R2",
	"L3",
	"R3",
	"MENU+UP",
	"MENU+DOWN",
	"MENU+LEFT",
	"MENU+RIGHT",
	"MENU+A",
	"MENU+B",
	"MENU+X",
	"MENU+Y",
	"MENU+START",
	"MENU+SELECT",
	"MENU+L1",
	"MENU+R1",
	"MENU+L2",
	"MENU+R2",
	"MENU+L3",
	"MENU+R3",
	NULL,
};
static char* overclock_labels[] = {
	"Powersave",
	"Normal",
	"Performance",
	NULL,
};
enum {
	CONFIG_NONE,
	CONFIG_CONSOLE,
	CONFIG_GAME,
};

struct Config {
	char* system_cfg; // system.cfg based on system limitations
	char* default_cfg; // pak.cfg based on platform limitations
	char* user_cfg; // minarch.cfg or game.cfg based on user preference
	OptionList frontend;
	OptionList core;
	ButtonMapping* controls;
	ButtonMapping* shortcuts;
	int loaded;
	int initialized;
} config = {
	.frontend = { // (OptionList)
		.count = FE_OPT_COUNT,
		.options = (Option[]){
			[FE_OPT_SCALING] = {
				.key	= "minarch_screen_scaling", 
				.name	= "FE_SCALING",               // ← ключ для локализации
		#ifdef CROP_OVERSCAN
				.desc	= "FE_SCALING_DESC_CROP",     // ← отдельный ключ, если нужно
		#else
				.desc	= "FE_SCALING_DESC",          // ← или общий
		#endif
				.default_value = 1,
				.value = 1,
				.count = SCALE_COUNT,
				.values = scaling_values,
				.labels = scaling_labels,
			},
			[FE_OPT_SHARPNESS] = {
				.key	= "minarch_screen_sharpness",
				.name	= "FE_SHARPNESS",
				.desc	= "FE_SHARPNESS_DESC",
				.default_value = 2,
				.value = 2,
				.count = ARRAY_SIZE(sharpness_values),
				.values = sharpness_values,
				.labels = sharpness_labels,
			},
			[FE_OPT_DEBUG] = {
				.key    = "minarch_debug_hud",
				.name   = "FE_DEBUG",
				.desc   = "FE_DEBUG_DESC",
				.default_value = DEBUG_OFF,
				.value = DEBUG_OFF,
				.count = DEBUG_COUNT,
				.values = debug_values,
				.labels = debug_labels,
			},
			[FE_OPT_MAXFF] = {
				.key	= "minarch_max_ff_speed",
				.name	= "FE_MAXFF",
				.desc	= "FE_MAXFF_DESC",
				.default_value = 3,
				.value = 3,
				.count = 8,
				.values = max_ff_labels,
				.labels = max_ff_labels,
			},
			[FE_OPT_CPU_CORES] = {
				.key    = "minarch_cpu_cores",
				.name   = "FE_CPU_CORES",
				.desc   = "FE_CPU_CORES_DESC",
				.default_value = 0,
				.value = 0,
				.count = 4,
				.values = cpu_cores_values,
				.labels = cpu_cores_labels,
			},
			[FE_OPT_THREAD] = {
				.key    = "minarch_thread_video",
				.name   = "FE_THREAD",
				.desc   = "FE_THREAD_DESC",
				.default_value = 0,
				.value = 0,
				.count = 2,
				.values = thread_values,
				.labels = thread_labels,
			},
			[FE_OPT_REWIND] = {
    			.key = "minarch_rewind",
    			.name = "REWIND",
    			.desc = "REWIND_DESC",
    			.default_value = 0,
    			.value = 0,
    			.count = 2,
    			.values = rewind_values,
    			.labels = rewind_labels,
			},
			[FE_OPT_FRAMESKIP] = {
    			.key    = "minarch_frame_skip",
    			.name   = "FRAME_SKIP",
    			.desc   = "FRAME_SKIP_DESC",
    			.default_value = 0,
    			.value = 0,
    			.count = 2,
    			.values = frameskip_values,
    			.labels = frameskip_labels,
			},
			[FE_OPT_RENDER_MODE] = {
    			.key    = "minarch_render_mode",
    			.name   = "RENDER_MODE",
    			.desc   = "RENDER_MODE_DESC",
    			.default_value = 0,
    			.value  = 0,
    			.count  = 2,
    			.values = render_mode_values,
    			.labels = render_mode_labels,
			},
			[FE_OPT_COUNT] = {NULL}
		}
	},
	.core = { // (OptionList)
		.count = 0,
		.options = (Option[]){
			{NULL},
		},
	},
	.controls = default_button_mapping,
	.shortcuts = (ButtonMapping[]){
    	[SHORTCUT_SAVE_STATE]        = {"SHORTCUT_SAVE_STATE",       -1, BTN_ID_NONE, 0},
    	[SHORTCUT_LOAD_STATE]        = {"SHORTCUT_LOAD_STATE",       -1, BTN_ID_NONE, 0},
    	[SHORTCUT_RESET_GAME]        = {"SHORTCUT_RESET_GAME",       -1, BTN_ID_NONE, 0},
    	[SHORTCUT_CYCLE_SCALE]       = {"SHORTCUT_CYCLE_SCALE",      -1, BTN_ID_NONE, 0},
    	[SHORTCUT_TOGGLE_FF]         = {"SHORTCUT_TOGGLE_FF",        -1, BTN_ID_NONE, 0},
    	[SHORTCUT_HOLD_FF]           = {"SHORTCUT_HOLD_FF",          -1, BTN_ID_NONE, 0},
    	[SHORTCUT_SCREENSHOT]        = {"SHORTCUT_SCREENSHOT",       -1, BTN_ID_NONE, 0},
    	[SHORTCUT_REWIND_HOLD]       = {"SHORTCUT_REWIND_HOLD",      -1, BTN_ID_NONE, 0}, // Новая
    	{NULL}
	},
};

static const char* shortcuts_key[] = {
	"SAVE",
	"LOAD",
	"RESET",
	"CYCLE_SCALE",
	"TOGGLE_FF",
	"HOLD_FF",
	"SCREENSHOT",
	"REWIND",
    "REWIND_HOLD"
};
static void* coreThread(void *arg);
static void toggle_threading(int enable);
static void video_refresh_callback_main(const void *data, unsigned width, unsigned height, size_t pitch);
static void Menu_loop(void);
void selectScaler(int src_w, int src_h, int src_p);
static void trackFPS(void);
static void limitFF(void);
static int Core_updateAVInfo(void);
static void resetFPSCounter(void);
static void chooseSyncRef(void);
static void resetFPSCounter(void);
static  int Option_getValueIndex(Option* item, const char* value);
static void chooseSyncRef(void) {
#if defined(NO_VSYNC)
    // Ничего не делаем
#else
    // Во втором файле `sync_ref` и `core.get_region()` не используются, поэтому можно оставить заглушку
    // Или, если используете — реализуйте по аналогии с первым файлом.
    // Пока оставим пустой, чтобы компилировалось.
#endif
}
static void log_cpu_detailed_status(void) {
    LOG_info("Детальный статус CPU:\n");
    
    for (int i = 0; i < 8; i++) {
        char path[256];
        snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d", i);
        
        if (access(path, F_OK) == 0) {
            char online_path[256];
            snprintf(online_path, sizeof(online_path), "%s/online", path);
            
            if (access(online_path, F_OK) == 0) {
                FILE* fp = fopen(online_path, "r");
                if (fp) {
                    char status[2];
                    if (fread(status, 1, 1, fp) == 1) {
                        LOG_info("  CPU%d: %s", i, status[0] == '1' ? "ONLINE" : "OFFLINE");
                        
                        // Проверяем на каком CPU работают потоки
                        cpu_set_t cpuset;
                        CPU_ZERO(&cpuset);
                        
                        if (pthread_getaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset) == 0) {
                            if (CPU_ISSET(i, &cpuset)) {
                                LOG_info(" (основной поток)");
                            }
                        }
                        if (coreThreadStarted && pthread_getaffinity_np(core_pt, sizeof(cpu_set_t), &cpuset) == 0) {
                            if (CPU_ISSET(i, &cpuset)) {
                                LOG_info(" (поток эмуляции)");
                            }
                        }
                        LOG_info("\n");
                    }
                    fclose(fp);
                }
            } else {
                LOG_info("  CPU%d: всегда онлайн\n", i);
            }
        }
    }
}
static int Config_getValue(char* cfg, const char* key, char* out_value, int* lock) {
	char* tmp = cfg;
	while ((tmp = strstr(tmp, key))) {
		if (lock!=NULL && tmp>cfg && *(tmp-1)=='-') *lock = 1; // prefixed with a `-` means lock
		tmp += strlen(key);
		if (!strncmp(tmp, " = ", 3)) break;
	};
	if (!tmp) return 0;
	tmp += 3;
	
	strncpy(out_value, tmp, 256);
	out_value[256 - 1] = '\0';
	tmp = strchr(out_value, '\n');
	if (!tmp) tmp = strchr(out_value, '\r');
	if (tmp) *tmp = '\0';

	// LOG_info("\t%s = %s (%s)\n", key, out_value, (lock && *lock) ? "hidden":"shown");
	return 1;
}

static int set_thread_affinity(pthread_t thread, int cpu_id) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    
    // Проверяем, доступно ли это ядро
    char online_path[64];
    snprintf(online_path, sizeof(online_path), "/sys/devices/system/cpu/cpu%d/online", cpu_id);
    
    if (access(online_path, F_OK) == 0) {
        FILE* fp = fopen(online_path, "r");
        if (fp) {
            char status;
            if (fread(&status, 1, 1, fp) == 1 && status == '0') {
                LOG_warn("CPU%d отключен, пробуем следующее ядро\n", cpu_id);
                fclose(fp);
                
                // Ищем следующее доступное ядро
                for (int i = 0; i < 8; i++) {
                    snprintf(online_path, sizeof(online_path), "/sys/devices/system/cpu/cpu%d/online", i);
                    if (access(online_path, F_OK) == 0) {
                        fp = fopen(online_path, "r");
                        if (fp && fread(&status, 1, 1, fp) == 1 && status == '1') {
                            cpu_id = i;
                            fclose(fp);
                            LOG_info("Найдено доступное ядро: CPU%d\n", cpu_id);
                            break;
                        }
                        if (fp) fclose(fp);
                    }
                }
            } else {
                fclose(fp);
            }
        }
    }
    
    CPU_SET(cpu_id, &cpuset);
    int rc = pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
    if (rc != 0) {
        LOG_error("Ошибка привязки потока к CPU %d: %s\n", cpu_id, strerror(rc));
        return -1;
    }
    
    // Проверяем, на каком ядре реально работает поток
    cpu_set_t actual_cpuset;
    CPU_ZERO(&actual_cpuset);
    if (pthread_getaffinity_np(thread, sizeof(cpu_set_t), &actual_cpuset) == 0) {
        for (int i = 0; i < CPU_SETSIZE; i++) {
            if (CPU_ISSET(i, &actual_cpuset)) {
                LOG_info("Поток реально работает на CPU%d\n", i);
            }
        }
    }
    
    LOG_info("Поток привязан к CPU %d\n", cpu_id);
    return 0;
}

static void setOverclock(int i) {
	overclock = i;
	switch (i) {
		case 0: PWR_setCPUSpeed(CPU_SPEED_POWERSAVE); break;
		case 1: PWR_setCPUSpeed(CPU_SPEED_NORMAL); break;
		case 2: PWR_setCPUSpeed(CPU_SPEED_PERFORMANCE); break;
	}
}

// Читает одно строковое значение из INI-файла по ключу
static int read_ini_int_value(const char* filepath, const char* key, int default_value) {
    if (!exists((char*)filepath)) return default_value;

    FILE* f = fopen(filepath, "r");
    if (!f) return default_value;

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        // Убираем \r\n
        char* nl = strchr(line, '\n');
        if (nl) *nl = '\0';
        nl = strchr(line, '\r');
        if (nl) *nl = '\0';

        // Пропускаем пустые строки и комментарии
        if (line[0] == '\0' || line[0] == '#' || line[0] == ';') continue;

        // Ищем совпадение по ключу
        if (strncmp(line, key, strlen(key)) == 0) {
            char* eq = strchr(line, '=');
            if (eq) {
                char* val = eq + 1;
                while (*val == ' ') val++;

                // Поддержка строковых значений
                if (strcmp(val, "Framebuffer") == 0) {
                    fclose(f);
                    return 1;
                } else if (strcmp(val, "SDL") == 0) {
                    fclose(f);
                    return 0;
                }
                // Поддержка числовых значений (на случай старых версий)
                int num = atoi(val);
                fclose(f);
                return (num != 0) ? 1 : 0;
            }
        }
    }
    fclose(f);
    return default_value;
}

static void Config_syncFrontend(char* key, int value) {
    int i = -1;
    
    // Флаг для отслеживания, идёт ли загрузка конфига
    static int is_loading = 1;
    
    // При загрузке конфига откладываем тяжёлые графические операции
    if (is_loading && key && !config_load_done) {
        if (exactMatch(key,config.frontend.options[FE_OPT_SCALING].key)) {
            screen_scaling  = value;
            i = FE_OPT_SCALING;
        }
        else if (exactMatch(key,config.frontend.options[FE_OPT_SHARPNESS].key)) {
            screen_sharpness = value;
            i = FE_OPT_SHARPNESS;
        }
        else if (exactMatch(key,config.frontend.options[FE_OPT_DEBUG].key)) {
            show_debug = value;
            i = FE_OPT_DEBUG;
        }
        else if (exactMatch(key,config.frontend.options[FE_OPT_MAXFF].key)) {
            max_ff_speed = value;
            i = FE_OPT_MAXFF;
        }
        else if (exactMatch(key, config.frontend.options[FE_OPT_REWIND].key)) {
    		rewind_enabled = value;
    		i = FE_OPT_REWIND;
		}
        else if (exactMatch(key,config.frontend.options[FE_OPT_THREAD].key)) {
            // Просто запоминаем значение — переключение отложим
            thread_video = value;  // ← временно
            i = FE_OPT_THREAD;
            // Не вызываем toggle_threading здесь!
        }
        else if (exactMatch(key,config.frontend.options[FE_OPT_CPU_CORES].key)) {
            // Новая обработка для количества CPU ядер
            int cores_to_keep = value; // 0=все, 1=1 ядро, 2=2 ядра и т.д.
            
            // При загрузке просто сохраняем значение, применение будет позже
            i = FE_OPT_CPU_CORES;
        }
        else if (exactMatch(key, config.frontend.options[FE_OPT_REWIND].key)) {
        	int old_value = rewind_enabled; // ← НОВОЕ: читаем через макрос
        	int new_value = value;
	
        	if (new_value == 0 && old_value == 1) {
            	// Перемотка выключена → немедленно освобождаем память!
            	if (rewind_buffer) {
                	for (int i = 0; i < rewind_buffer_size; i++) {
                    	free(rewind_buffer[i].data);
                    	free(rewind_buffer[i].preview);
                	}
                	free(rewind_buffer);
                	rewind_buffer = NULL;
                	rewind_buffer_size = 0;
                	rewind_initialized = 0;
                	rewind_count = 0;
                	rewind_index = 0;
                	rewind_start = 0;
                	LOG_info("Rewind buffer freed");
            	}
        	}
        	// Присваиваем через Config — макрос сам прочитает
        	config.frontend.options[FE_OPT_REWIND].value = new_value;
        	i = FE_OPT_REWIND;
    	}
    	else if (exactMatch(key, config.frontend.options[FE_OPT_FRAMESKIP].key)) {
    		frame_skip_enabled = value;
    		i = FE_OPT_FRAMESKIP;
		}
		else if (exactMatch(key, config.frontend.options[FE_OPT_RENDER_MODE].key)) {
    		int render_mode = value; // 0 = SDL, 1 = Framebuffer
    		i = FE_OPT_RENDER_MODE;
		}
        
        // Сохраняем значение в опции
        if (i != -1) {
            Option* option = &config.frontend.options[i];
            option->value = value;
        }
        
        return; // Выходим, не выполняя тяжёлых операций
    }
    
    // После загрузки конфига выполняем реальные изменения
    is_loading = 0;
    
    if (exactMatch(key,config.frontend.options[FE_OPT_SCALING].key)) {
        screen_scaling  = value;
        
        if (screen_scaling==SCALE_NATIVE) {
            GFX_setSharpness(SHARPNESS_SHARP);
        }
        else {
            GFX_setSharpness(screen_sharpness);
        }
        
        // Отмечаем, что нужно пересоздать рендерер
        renderer.dst_p = 0;
        
        // Пересоздаём скалер только если игра уже загружена
        if (game.is_open && renderer.true_w > 0 && renderer.true_h > 0) {
            selectScaler(renderer.true_w, renderer.true_h, renderer.src_p);
        }
        
        i = FE_OPT_SCALING;
    }
    else if (exactMatch(key,config.frontend.options[FE_OPT_SHARPNESS].key)) {
        screen_sharpness = value;
        
        // Применяем шарпнесс только если не в нативном режиме
        if (screen_scaling != SCALE_NATIVE) {
            GFX_setSharpness(value);
        }
        
        // Пересоздаём рендерер только если нужно
        if (renderer.dst_p != 0) {
            renderer.dst_p = 0;
            if (game.is_open && renderer.true_w > 0 && renderer.true_h > 0) {
                selectScaler(renderer.true_w, renderer.true_h, renderer.src_p);
            }
        }
        
        i = FE_OPT_SHARPNESS;
    }
    else if (exactMatch(key,config.frontend.options[FE_OPT_DEBUG].key)) {
        show_debug = value;
        i = FE_OPT_DEBUG;
    }
    else if (exactMatch(key,config.frontend.options[FE_OPT_MAXFF].key)) {
        max_ff_speed = value;
        i = FE_OPT_MAXFF;
    }
    else if (exactMatch(key,config.frontend.options[FE_OPT_THREAD].key)) {
        int old_value = thread_video;
        toggle_thread = old_value != value;
        waitforthread = value;
        i = FE_OPT_THREAD;
    }
    else if (exactMatch(key,config.frontend.options[FE_OPT_CPU_CORES].key)) {
        // Новая обработка для количества CPU ядер
        int cores_to_keep = value; // 0=все, 1=1 ядро, 2=2 ядра и т.д.
        
        // Применяем настройку ядер CPU
        if (config_load_done) {
            LOG_info("Немедленно применяем CPU cores: %d\n", cores_to_keep);
            set_active_cpu_cores(cores_to_keep);
            
            // Ждём немного для стабилизации
            usleep(200000); // 200ms
            
            // Пере-привязываем потоки к ядрам
            int total_cores = sysconf(_SC_NPROCESSORS_ONLN);
            LOG_info("После настройки: %d онлайн ядер\n", total_cores);
            
            if (total_cores >= 2 && coreThreadStarted) {
                set_thread_affinity(core_pt, 1 % total_cores);
            }
        }
        i = FE_OPT_CPU_CORES;
    }
    else if (exactMatch(key, config.frontend.options[FE_OPT_REWIND].key)) {
    	rewind_enabled = value;
    	i = FE_OPT_REWIND;
	}
	else if (exactMatch(key, config.frontend.options[FE_OPT_FRAMESKIP].key)) {
    	frame_skip_enabled = value;
    	i = FE_OPT_FRAMESKIP;
	}
	else if (exactMatch(key, config.frontend.options[FE_OPT_RENDER_MODE].key)) {
    	int render_mode = value; // 0 = SDL, 1 = Framebuffer
    	i = FE_OPT_RENDER_MODE;
	}
    
    if (i==-1) return;
    
    // Обновляем значение в структуре опции
    Option* option = &config.frontend.options[i];
    option->value = value;
}

// Добавьте эту функцию для применения отложенных настроек после загрузки
static void ApplyDeferredGraphicsSettings(void) {
    static int applied = 0;
    if (applied) return;
    
    LOG_info("Применяем отложенные настройки графики...\n");
    
    // 1. Применяем шарпнесс
    if (screen_scaling == SCALE_NATIVE) {
        GFX_setSharpness(SHARPNESS_SHARP);
    } else {
        GFX_setSharpness(screen_sharpness);
    }
    
    // 2. Применяем настройки CPU ядер
    Option* cpu_option = &config.frontend.options[FE_OPT_CPU_CORES];
    int cores_to_keep = cpu_option->value;
    
    LOG_info("Применяем настройки CPU ядер: %d ядер\n", cores_to_keep);
    
    // Применяем настройки ядер
    int result = set_active_cpu_cores(cores_to_keep);
    if (result >= 0) {
        LOG_info("Установлено %d активных ядер CPU\n", cores_to_keep);
    } else {
        LOG_info("Ошибка настройки CPU ядер\n");
    }
    
    // 3. Применяем vsync
    GFX_setVsync(prevent_tearing);
    
    // 4. Применяем разгон
    setOverclock(overclock);
    
    // 5. НЕ применяем многопоточность здесь - она будет применена позже
    // в основном цикле после создания потоков
    
    // Применяем отложенные настройки перемотки
	Option* rewind_option = &config.frontend.options[FE_OPT_REWIND];
	rewind_enabled = rewind_option->value;
	LOG_info("Применена настройка перемотки: %s\n",
         	rewind_enabled ? "On" : "Off");
    
    applied = 1;
}

static void ShowLoadingProgress(int step, int total, const char* message) {
    GFX_startFrame();
    
    // Очистка экрана
    SDL_FillRect(screen, &(SDL_Rect){0, 0, DEVICE_WIDTH, DEVICE_HEIGHT}, 
                 SDL_MapRGB(screen->format, color_triad_black_r, color_triad_black_g, color_triad_black_b));
    
    // Текст сообщения
    SDL_Surface* text = TTF_RenderUTF8_Blended(font.large, message, COLOR_WHITE);
    if (text) {
        SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
            (DEVICE_WIDTH - text->w) / 2,
            DEVICE_HEIGHT / 2 - text->h - 10,
            text->w,
            text->h
        });
        SDL_FreeSurface(text);
    }
    
    // Прогресс-бар
    int bar_width = DEVICE_WIDTH - 40;
    int bar_height = 8;
    int bar_x = 20;
    int bar_y = DEVICE_HEIGHT / 2 + 10;
    
    // Фон прогресс-бара
    SDL_Rect bg_rect = {bar_x, bar_y, bar_width, bar_height};
    SDL_FillRect(screen, &bg_rect, SDL_MapRGB(screen->format, 64, 64, 64));
    
    // Заполненная часть
    int progress_width = (bar_width * step) / total;
    if (progress_width > 0) {
        SDL_Rect fg_rect = {bar_x, bar_y, progress_width, bar_height};
        SDL_FillRect(screen, &fg_rect, SDL_MapRGB(screen->format, 255, 255, 255));
    }
    
    // Процент
    char percent_text[32];
    snprintf(percent_text, sizeof(percent_text), "%d%%", (step * 100) / total);
    text = TTF_RenderUTF8_Blended(font.medium, percent_text, COLOR_WHITE);
    if (text) {
        SDL_BlitSurface(text, NULL, screen, &(SDL_Rect){
            (DEVICE_WIDTH - text->w) / 2,
            bar_y + bar_height + 5,
            text->w,
            text->h
        });
        SDL_FreeSurface(text);
    }
    
    GFX_flip(screen);
}

static void OptionList_setOptionValue(OptionList* list, const char* key, const char* value);
enum {
	CONFIG_WRITE_ALL,
	CONFIG_WRITE_GAME,
};
static void Config_getPath(char* filename, int override) {
    if (override) {
        if (g_clean_rom_name[0] != '\0') {
            snprintf(filename, MAX_PATH, "%s/%s.cfg", core.config_dir, g_clean_rom_name);
        } else {
            // fallback на minarch.cfg, если имя не задано
            snprintf(filename, MAX_PATH, "%s/minarch.cfg", core.config_dir);
            return;
        }
    } else {
        snprintf(filename, MAX_PATH, "%s/minarch.cfg", core.config_dir);
    }
}
static void Config_init(void) {
    if (!config.default_cfg || config.initialized) return;
    LOG_info("Config_init");

    char* tmp = config.default_cfg;
    int i = 0;

    LOG_info("=== SIMPLE DEBUG: Starting to parse bindings ===");
    while ((tmp = strstr(tmp, "bind ")) && i < MAX_CORE_BUTTONS - 1) {
        tmp += 5; // skip "bind "
        char* key_start = tmp;
        char* eq = strstr(tmp, " = ");
        if (!eq) break;

        // Extract button name
        int name_len = eq - key_start;
        if (name_len >= 128) name_len = 127;
        char button_name[128];
        strncpy(button_name, key_start, name_len);
        button_name[name_len] = '\0';

        // Skip shortcuts — they are handled separately
        if (strncmp(button_name, "SHORTCUT_", 9) == 0) {
            tmp = eq + 3; // move past " = "
            continue;
        }

        // Parse value
        tmp = eq + 3;
        char button_id[128];
        strncpy(button_id, tmp, 127);
        button_id[127] = '\0';
        char* nl = strchr(button_id, '\n');
        if (nl) *nl = '\0';
        nl = strchr(button_id, '\r');
        if (nl) *nl = '\0';

        LOG_info("Parsed: name='%s', id='%s'", button_name, button_id);

        // Find retro_id and local_id
        int retro_id = -1;
        int local_id = -1;
        char* mod_part = strrchr(button_id, ':');
        if (mod_part) {
            *mod_part = '\0';
            for (int j = 0; button_label_mapping[j].name; j++) {
                if (strcmp(mod_part + 1, button_label_mapping[j].name) == 0) {
                    retro_id = button_label_mapping[j].retro;
                    break;
                }
            }
        }

        for (int j = 0; button_label_mapping[j].name; j++) {
            if (strcmp(button_id, button_label_mapping[j].name) == 0) {
                local_id = button_label_mapping[j].local;
                if (retro_id == -1) retro_id = button_label_mapping[j].retro;
                break;
            }
        }

        LOG_info("\tbind %s (%s) %i:%i", button_name, button_id, local_id, retro_id);

        // Allocate and store
        char* name_copy = calloc(strlen(button_name) + 1, sizeof(char));
        strcpy(name_copy, button_name);

        ButtonMapping* button = &core_button_mapping[i++];
        button->name = name_copy;
        button->retro = retro_id;
        button->local = local_id;
        LOG_info("Button %d initialized", i - 1);

        // Move tmp past this line
        tmp = strchr(tmp, '\n');
        if (!tmp) break;
    }

    LOG_info("=== SIMPLE DEBUG: Parsed %d buttons ===", i);
    if (i < MAX_CORE_BUTTONS) {
        core_button_mapping[i].name = NULL;
        LOG_info("Set NULL terminator at index %d", i);
    }

    // Set controls pointer
    config.controls = core_button_mapping[0].name ? core_button_mapping : default_button_mapping;
    config.initialized = 1;
    LOG_info("=== SIMPLE DEBUG: Config_init completed ===");
}
static void Config_quit(void) {
	if (!config.initialized) return;
	for (int i=0; core_button_mapping[i].name; i++) {
		free(core_button_mapping[i].name);
	}
}
static void Config_readOptionsString(char* cfg) {
    if (!cfg) {
        LOG_warn("Config_readOptionsString: cfg is NULL");
        return;
    }
    LOG_info("Config_readOptionsString");

    char value[256];

    // === ЧТЕНИЕ FRONTEND ОПЦИЙ ===
    for (int i = 0; i < FE_OPT_COUNT; i++) {
        Option* option = &config.frontend.options[i];
        if (!option->key) {
            LOG_warn("Skipping frontend option %d: key is NULL", i);
            continue;
        }

        int lock = 0;
        if (!Config_getValue(cfg, option->key, value, &lock)) {
            LOG_info("Option not found: %s (using default: %s)",
                     option->key,
                     (option->values && option->default_value < option->count)
                         ? option->values[option->default_value]
                         : "N/A");
            option->lock = lock;
            continue;
        }

        LOG_info("Found %s = %s", option->key, value);
        option->lock = lock;

        // === СПЕЦИАЛЬНЫЙ ОТЛАДОЧНЫЙ ВЫВОД ДЛЯ ПРОБЛЕМНЫХ ПАРАМЕТРОВ ===
        if (strcmp(option->key, "minarch_debug_hud") == 0 ||
            strcmp(option->key, "minarch_cpu_cores") == 0 ||
            strcmp(option->key, "minarch_thread_video") == 0) {
            LOG_info("DEBUG: Parsing %s = '%s'", option->key, value);
        }

        // НАХОДИМ ИНДЕКС ЗНАЧЕНИЯ
        int new_value = Option_getValueIndex(option, value);
        if (new_value >= option->count) {
            LOG_error("Invalid value '%s' for option '%s' (max index: %d). Using default.",
                      value, option->key, option->count - 1);
            new_value = option->default_value;
        }

        LOG_info("DEBUG: %s parsed as index %d (value='%s')",
                 option->key, new_value,
                 (new_value < option->count) ? option->values[new_value] : "INVALID");

        // УСТАНАВЛИВАЕМ ЗНАЧЕНИЕ
        option->value = new_value;

        // ПРИМЕНЯЕМ НАСТРОЙКУ
        Config_syncFrontend(option->key, option->value);

        // ПОДТВЕРЖДЕНИЕ
        LOG_info("DEBUG: After Config_syncFrontend → %s = index %d ('%s')",
                 option->key, option->value,
                 (option->value < option->count) ? option->values[option->value] : "INVALID");
    }

    // === ЧТЕНИЕ CORE ОПЦИЙ ===
    for (int i = 0; i < config.core.count; i++) {
        Option* option = &config.core.options[i];
        if (!option->key) continue;

        if (!Config_getValue(cfg, option->key, value, NULL)) {
            continue;
        }

        LOG_info("Found core option %s = %s", option->key, value);
        OptionList_setOptionValue(&config.core, option->key, value);
    }
}
static void Config_readOptions(void) {
    // Батчинг: собираем все изменения, потом применяем
    int changes[FE_OPT_COUNT];
    char* keys[FE_OPT_COUNT];
    int change_count = 0;
    
    Config_readOptionsString(config.system_cfg);
    Config_readOptionsString(config.default_cfg);
    Config_readOptionsString(config.user_cfg);

    // Применяем все изменения одним пакетом
    for (int i = 0; i < FE_OPT_COUNT; i++) {
        Option* option = &config.frontend.options[i];
        if (option->value != option->default_value) {
            // Откладываем тяжелые операции
            if (i == FE_OPT_SCALING || i == FE_OPT_SHARPNESS) {
                // Просто сохраняем значения
                if (i == FE_OPT_SCALING) screen_scaling = option->value;
                if (i == FE_OPT_SHARPNESS) screen_sharpness = option->value;
            } else {
                // Немедленно применяем легкие настройки
                Config_syncFrontend(option->key, option->value);
            }
        }
    }
}
static void Config_readControlsString(char* cfg) {
    if (!cfg) return;
    LOG_info("=== DEBUG: Entering Config_readControlsString ===");

    char key[256];
    char value[256];

    // === Чтение controls ===
    for (int i = 0; config.controls && config.controls[i].name; i++) {
        ButtonMapping* mapping = &config.controls[i];
        snprintf(key, sizeof(key), "bind %s", mapping->name);
        if (!Config_getValue(cfg, key, value, NULL)) {
            // Оставляем текущее значение (уже инициализировано)
            continue;
        }

        int id = -1;
        for (int j = 0; button_labels[j]; j++) {
            if (strcmp(button_labels[j], value) == 0) {
                id = j - 1;
                break;
            }
        }

        int mod = 0;
        if (id >= LOCAL_BUTTON_COUNT) {
            id -= LOCAL_BUTTON_COUNT;
            mod = 1;
        }

        // === ЗАЩИТА: проверяем диапазон ===
        if (id < -1 || id >= LOCAL_BUTTON_COUNT) {
            LOG_warn("Invalid control binding '%s' = '%s' → ignoring", key, value);
            id = BTN_ID_NONE;
            mod = 0;
        }

        mapping->local = id;
        mapping->mod = mod;
    }

    // === Чтение shortcuts ===
    for (int i = 0; i < SHORTCUT_COUNT; i++) {
        if (!config.shortcuts[i].name) break;

        ButtonMapping* mapping = &config.shortcuts[i];
        snprintf(key, sizeof(key), "bind %s", mapping->name);
        if (!Config_getValue(cfg, key, value, NULL)) {
            // Сохраняем значение по умолчанию (-1, 0)
            continue;
        }

        int id = -1;
        for (int j = 0; button_labels[j]; j++) {
            if (strcmp(button_labels[j], value) == 0) {
                id = j - 1;
                break;
            }
        }

        int mod = 0;
        if (id >= LOCAL_BUTTON_COUNT) {
            id -= LOCAL_BUTTON_COUNT;
            mod = 1;
        }

        // === КРИТИЧЕСКАЯ ЗАЩИТА ===
        if (id < -1 || id >= LOCAL_BUTTON_COUNT) {
            LOG_warn("Invalid shortcut binding '%s' = '%s' → resetting to NONE", key, value);
            id = BTN_ID_NONE;
            mod = 0;
        }

        mapping->local = id;
        mapping->mod = mod;
    }

    LOG_info("=== DEBUG: Config_readControlsString completed ===");
}
static void Config_load(void) {
    LOG_info("Config_load");
    char* system_path = SYSTEM_PATH "/system.cfg";
    if (exists(system_path)) config.system_cfg = allocFile(system_path);
    else config.system_cfg = NULL;

    char default_path[MAX_PATH];
    getEmuPath((char *)core.tag, default_path);
    char* tmp = strrchr(default_path, '/');
    strcpy(tmp,"/default.cfg");
    if (exists(default_path)) config.default_cfg = allocFile(default_path);
    else config.default_cfg = NULL;

    char path[MAX_PATH];
    config.loaded = CONFIG_NONE;
    int override = 0;

    // Проверяем ИГРОВОЙ конфиг с ОЧИЩЕННЫМ именем
    Config_getPath(path, CONFIG_WRITE_GAME);
    LOG_info("Trying game config: %s", path);
    if (exists(path)) {
        override = 1;
        LOG_info("Game config FOUND");
    } else {
        LOG_info("Game config NOT found");
    }

    if (!override) {
        Config_getPath(path, CONFIG_WRITE_ALL);
        LOG_info("Trying global config: %s", path);
    }

    config.user_cfg = allocFile(path);
    if (!config.user_cfg) {
        LOG_error("FAILED to load config file: %s", path);
        config.loaded = CONFIG_NONE;
        return;
    }

    config.loaded = override ? CONFIG_GAME : CONFIG_CONSOLE;
    LOG_info("Successfully loaded config: %s", path);
}
static void Config_free(void) {
	if (config.system_cfg) free(config.system_cfg);
	if (config.default_cfg) free(config.default_cfg);
	if (config.user_cfg) free(config.user_cfg);
}
static void Config_readControls(void) {
	Config_readControlsString(config.default_cfg);
	Config_readControlsString(config.user_cfg);
}
static void Config_write(int override) {
	// Ждем завершения операций с диском
    usleep(100000); // 100ms задержка
    char path[MAX_PATH];
    Config_getPath(path, override ? CONFIG_WRITE_GAME : CONFIG_WRITE_ALL);
    config.loaded = override ? CONFIG_GAME : CONFIG_CONSOLE;

    LOG_info("Opening config file for writing: %s", path);
    
    FILE *file = fopen(path, "wb");
    if (!file) {
        LOG_error("Failed to open config file for writing: %s (errno: %d, %s)", 
                 path, errno, strerror(errno));
        return;
    }
    
    // === FRONTEND OPTIONS ===
    for (int i = 0; i < FE_OPT_COUNT; i++) {
        Option* option = &config.frontend.options[i];
        if (!option->key || !option->values) continue;
        if (option->value < 0 || option->value >= option->count) {
            option->value = option->default_value;
        }
        if (fprintf(file, "%s = %s\n", option->key, option->values[option->value]) < 0) {
            LOG_error("Write error for option %s", option->key);
            fclose(file);
            return;
        }
    }

    // === CORE OPTIONS ===
    for (int i = 0; i < config.core.count; i++) {
        Option* option = &config.core.options[i];
        if (!option->key || !option->values) continue;
        if (option->value < 0 || option->value >= option->count) {
            option->value = option->default_value;
        }
        if (fprintf(file, "%s = %s\n", option->key, option->values[option->value]) < 0) {
            LOG_error("Write error for core option %s", option->key);
            fclose(file);
            return;
        }
    }

    // === CONTROLS ===
    for (int i = 0; config.controls && config.controls[i].name; i++) {
        ButtonMapping* mapping = &config.controls[i];
        int j = mapping->local + 1;
        if (mapping->mod) j += LOCAL_BUTTON_COUNT;

        if (j < 0 || j >= (int)(sizeof(button_labels)/sizeof(button_labels[0])) || !button_labels[j]) {
            LOG_error("Invalid control binding for '%s': local=%d, mod=%d → index=%d",
                      mapping->name, mapping->local, mapping->mod, j);
            fprintf(file, "bind %s = NONE\n", mapping->name);
            continue;
        }
        if (fprintf(file, "bind %s = %s\n", mapping->name, button_labels[j]) < 0) {
            LOG_error("Write error for control %s", mapping->name);
            fclose(file);
            return;
        }
    }

    // === SHORTCUTS ===
    for (int i = 0; i < SHORTCUT_COUNT; i++) {
        if (!config.shortcuts[i].name) break;

        ButtonMapping* mapping = &config.shortcuts[i];
        int j = mapping->local + 1;
        if (mapping->mod) j += LOCAL_BUTTON_COUNT;

        if (j < 0 || j >= (int)(sizeof(button_labels)/sizeof(button_labels[0])) || !button_labels[j]) {
            LOG_error("Invalid shortcut binding for '%s': local=%d, mod=%d → index=%d",
                      mapping->name, mapping->local, mapping->mod, j);
            fprintf(file, "bind %s = NONE\n", mapping->name);
            continue;
        }
        if (fprintf(file, "bind %s = %s\n", mapping->name, button_labels[j]) < 0) {
            LOG_error("Write error for shortcut %s", mapping->name);
            fclose(file);
            return;
        }
    }

    int result = fclose(file);
    if (result != 0) {
        LOG_error("Failed to close config file: %s (errno: %d, %s)", 
                 path, errno, strerror(errno));
    } else {
        sync();
        LOG_info("Config saved successfully to: %s", path);
    }
}
static void Config_restore(void) {
	char path[MAX_PATH];
	if (config.loaded==CONFIG_GAME) {
		sprintf(path, "%s/%s.cfg", core.config_dir, game.name);
		unlink(path);
	}
	else if (config.loaded==CONFIG_CONSOLE) {
		sprintf(path, "%s/minarch.cfg", core.config_dir);
		unlink(path);
	}
	config.loaded = CONFIG_NONE;
	
	for (int i=0; config.frontend.options[i].key; i++) {
		Option* option = &config.frontend.options[i];
		option->value = option->default_value;
		Config_syncFrontend(option->key, option->value);
	}
	for (int i=0; config.core.options[i].key; i++) {
		Option* option = &config.core.options[i];
		option->value = option->default_value;
	}
	config.core.changed = 1; // let the core know
	/*
	if (has_custom_controllers) {
		gamepad_type = 0;
		core.set_controller_port_device(0, RETRO_DEVICE_JOYPAD);
	}
	*/
	for (int i=0; config.controls[i].name; i++) {
		ButtonMapping* mapping = &config.controls[i];
		mapping->local = mapping->default_;
		mapping->mod = 0;
	}
	for (int i=0; config.shortcuts[i].name; i++) {
		ButtonMapping* mapping = &config.shortcuts[i];
		mapping->local = BTN_ID_NONE;
		mapping->mod = 0;
	}
	
	Config_load();
	Config_readOptions();
	Config_readControls();
	Config_free();
	
	renderer.dst_p = 0;
}

///////////////////////////////

static  int Option_getValueIndex(Option* item, const char* value) {
	if (!value) return 0;
	for (int i=0; i<item->count; i++) {
		if (!strcmp(item->values[i], value)) return i;
	}
	return 0;
}
static void Option_setValue(Option* item, const char* value) {
	// TODO: store previous value?
	item->value = Option_getValueIndex(item, value);
}

// TODO: does this also need to be applied to OptionList_vars()?
static const char* option_key_name[] = {
	"pcsx_rearmed_analog_combo", "DualShock Toggle Combo",
	NULL
};
static const char* getOptionNameFromKey(const char* key, const char* name) {
	char* _key = NULL;
	for (int i=0; (_key = (char*)option_key_name[i]); i+=2) {
		if (exactMatch((char*)key,_key)) return option_key_name[i+1];
	}
	return name;
}

// the following 3 functions always touch config.core, the rest can operate on arbitrary OptionLists
static void OptionList_init(const struct retro_core_option_definition *defs) {
	LOG_info("OptionList_init\n");
	int count;
	for (count=0; defs[count].key; count++);
	
	// LOG_info("count: %i\n", count);
	
	// TODO: add frontend options to this? so the can use the same override method? eg. minarch_*
	
	config.core.count = count;
	if (count) {
		config.core.options = calloc(count+1, sizeof(Option));
		
		for (int i=0; i<config.core.count; i++) {
			int len;
			const struct retro_core_option_definition *def = &defs[i];
			Option* item = &config.core.options[i];
			len = strlen(def->key) + 1;
		
			item->key = calloc(len, sizeof(char));
			strcpy(item->key, def->key);
			
			len = strlen(def->desc) + 1;
			item->name = calloc(len, sizeof(char));
			strcpy(item->name, getOptionNameFromKey(def->key,def->desc));
			
			if (def->info) {
				len = strlen(def->info) + 1;
				item->desc = calloc(len, sizeof(char));
				strncpy(item->desc, def->info, len);

				item->full = calloc(len, sizeof(char));
				strncpy(item->full, item->desc, len);
				// item->desc[len-1] = '\0';
				
				// these magic numbers are more about chars per line than pixel width 
				// so it's not going to be relative to the screen size, only the scale
				// what does that even mean?
				GFX_wrapText(font.tiny, item->desc, SCALE1(240), 2); // TODO magic number!
				GFX_wrapText(font.medium, item->full, SCALE1(240), 7); // TODO: magic number!
			}
		
			for (count=0; def->values[count].value; count++);
		
			item->count = count;
			item->values = calloc(count+1, sizeof(char*));
			item->labels = calloc(count+1, sizeof(char*));
	
			for (int j=0; j<count; j++) {
				const char* value = def->values[j].value;
				const char* label = def->values[j].label;
		
				len = strlen(value) + 1;
				item->values[j] = calloc(len, sizeof(char));
				strcpy(item->values[j], value);
		
				if (label) {
					len = strlen(label) + 1;
					item->labels[j] = calloc(len, sizeof(char));
					strcpy(item->labels[j], label);
				}
				else {
					item->labels[j] = item->values[j];
				}
				// printf("\t%s\n", item->labels[j]);
			}
			
			item->value = Option_getValueIndex(item, def->default_value);
			item->default_value = item->value;
			
			LOG_info("\tINIT %s (%s) TO %s (%s)\n", item->name, item->key, item->labels[item->value], item->values[item->value]);
		}
	}
	// fflush(stdout);
}
static void OptionList_vars(const struct retro_variable *vars) {
	LOG_info("OptionList_vars\n");
	int count;
	for (count=0; vars[count].key; count++);
	
	config.core.count = count;
	if (count) {
		config.core.options = calloc(count+1, sizeof(Option));
	
		for (int i=0; i<config.core.count; i++) {
			int len;
			const struct retro_variable *var = &vars[i];
			Option* item = &config.core.options[i];

			len = strlen(var->key) + 1;
			item->key = calloc(len, sizeof(char));
			strcpy(item->key, var->key);
			
			len = strlen(var->value) + 1;
			item->var = calloc(len, sizeof(char));
			strcpy(item->var, var->value);
			
			char* tmp = strchr(item->var, ';');
			if (tmp && *(tmp+1)==' ') {
				*tmp = '\0';
				item->name = item->var;
				tmp += 2;
			}
			
			char* opt = tmp;
			for (count=0; (tmp=strchr(tmp, '|')); tmp++, count++);
			count += 1; // last entry after final '|'
		
			item->count = count;
			item->values = calloc(count+1, sizeof(char*));
			item->labels = calloc(count+1, sizeof(char*));

			tmp = opt;
			int j;
			for (j=0; (tmp=strchr(tmp, '|')); j++) {
				item->values[j] = opt;
				item->labels[j] = opt;
				*tmp = '\0';
				tmp += 1;
				opt = tmp; 
			}
			item->values[j] = opt;
			item->labels[j] = opt;
			
			// no native default_value support for retro vars
			item->value = 0;
			item->default_value = item->value;
			// printf("SET %s to %s (%i)\n", item->key, default_value, item->value); fflush(stdout);
		}
	}
	// fflush(stdout);
}
static void OptionList_reset(void) {
	if (!config.core.count) return;
	
	for (int i=0; i<config.core.count; i++) {
		Option* item = &config.core.options[i];
		if (item->var) {
			// values/labels are all points to var
			// so no need to free individually
			free(item->var);
		}
		else {
			if (item->desc) free(item->desc);
			if (item->full) free(item->full);
			for (int j=0; j<item->count; j++) {
				char* value = item->values[j];
				char* label = item->labels[j];
				if (label!=value) free(label);
				free(value);
			}
		}
		free(item->values);
		free(item->labels);
		free(item->key);
		free(item->name);
	}
	if (config.core.enabled_options) free(config.core.enabled_options);
	config.core.enabled_count = 0;
	free(config.core.options);
}

static Option* OptionList_getOption(OptionList* list, const char* key) {
	for (int i=0; i<list->count; i++) {
		Option* item = &list->options[i];
		if (!strcmp(item->key, key)) return item;
	}
	return NULL;
}
static char* OptionList_getOptionValue(OptionList* list, const char* key) {
	Option* item = OptionList_getOption(list, key);
	if (item) LOG_info("\tGET %s (%s) = %s (%s)\n", item->name, item->key, item->labels[item->value], item->values[item->value]);
	
	if (item) return item->values[item->value];
	else LOG_warn("unknown option %s \n", key);
	return NULL;
}
static void OptionList_setOptionRawValue(OptionList* list, const char* key, int value) {
	Option* item = OptionList_getOption(list, key);
	if (item) {
		item->value = value;
		list->changed = 1;
		LOG_info("\tRAW SET %s (%s) TO %s (%s)\n", item->name, item->key, item->labels[item->value], item->values[item->value]);
		// if (list->on_set) list->on_set(list, key);
	}
	else LOG_info("unknown option %s \n", key);
}
static void OptionList_setOptionValue(OptionList* list, const char* key, const char* value) {
	Option* item = OptionList_getOption(list, key);
	if (item) {
		Option_setValue(item, value);
		list->changed = 1;
		LOG_info("\tSET %s (%s) TO %s (%s)\n", item->name, item->key, item->labels[item->value], item->values[item->value]);
		// if (list->on_set) list->on_set(list, key);
	}
	else LOG_info("unknown option %s \n", key);
}
// static void OptionList_setOptionVisibility(OptionList* list, const char* key, int visible) {
// 	Option* item = OptionList_getOption(list, key);
// 	if (item) item->visible = visible;
// 	else printf("unknown option %s \n", key); fflush(stdout);
// }
