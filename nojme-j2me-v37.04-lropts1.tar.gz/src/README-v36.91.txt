════════════════════════════════════════════════════════════════════
 NOJME v36.91 — [MON-EXIT-FREE] + [JOIN-CAP] + [MIDI-GAIN]
 (поверх v36.90; адресует репорт по Metal Slug 6 (I-Play) + «midi
  намного тише чем pcm»)
════════════════════════════════════════════════════════════════════

ЧТО ЭТО
-------
Патч-релиз поверх v36.90. Адресует полевой репорт: «Metal Slug 6
зависает (лог приложен), и почему в midi звук намного тише чем в pcm».

ЧТО ПОКАЗАЛ ЛОГ (build v36.88-homefix1, Metal Slug 6)
-----------------------------------------------------
1) ИГРА ЗАВИСАЕТ НА ВЫХОДЕ (главный симптом):
   - выход из игры: l.destroyApp@0 -> java/lang/Thread.join на игровой
     поток t2 — и ВЕЧНОЕ ожидание (age=517 -> 1518 -> 2517+ мс);
   - t2 зациклен в обработчике исключения synchronized-блока:
       [EX-THROW] java/lang/IllegalMonitorStateException at at.run PC=708
       [SPIN-BREAK] tid=2 pure-Java spin 1501 ms (site at.run@708) ...
         «catch recovers» — фактически НЕ выздоравливает
   - декомпиляция игры (scripts/disasm.py): at.run() — synchronized
     блок на мониторе ключей (at.a), таблица исключений [606,709) -> 704,
     обработчик = astore; aload; monitorexit@708; athrow. Классическая
     петля: monitorexit бросает IMS -> таблица [606,709) ловит ЕГО ЖЕ ->
     handler снова monitorexit -> IMS -> ... бесконечно. Поток никогда
     не умирает, join не возвращается, игра не выходит (только kill).
2) ФРИЗ НА 20 С В ГЕЙМПЛЕЕ (16.8-37 с, stage=timers):
   - td m: monenter 1..5 c — главный поток стоит на monitorenter(at.a)
     в at.h(II)@196 (доставка keyReleased);
   - владелец монитора — t2 (owner_tid=2), сам он жив и крутится;
   - через 20 c отработал MON-STEAL (v34.99) — ввод вернулся, фриз
     «рассосался» (с 37 с KEYDIAG снова живые). Т.е. страховка уже
     была, но 20 с мёртвого экрана пользователь видит как «зависла».
3) АУДИО РЕСУРСЫ ИГРЫ ОТСУТСТВУЮТ В JAR: musicStage*.mid и sfx*.wav
   (16 штук) в этом репаке ФИЗИЧЕСКИ НЕТ (только ding.mid) — отсюда
   каскад [JAR-READ] FAILED -> MediaException -> NPE в at.a. Это не
   баг эмулятора: MediaException корректна, игра её глотает и идёт
   дальше (без музыки/звуков этого репака). Полная версия игры со
   звуками будет играть и звук.

ИЗМЕНЕНИЯ
---------
[A] [MON-EXIT-FREE] op_monitorexit (src/jvm/opcodes.c) больше не даёт
    породить вечную IMS-петлю:
    - monitorexit на УЖЕ СВОБОДНОМ мониторе (никто не владеет) —
      считается успешным no-op (лог [MON-EXIT-FREE], первые 4 события,
      далее 1/1024). Именно этот случай возникал после MON-STEAL:
      владелец выходит из блока по-своему, а монитор уже слит.
    - Серия из 256 ПОДРЯД идущих IMS на monitorexit (сбрасывается
      любым успешным monitor-оператором потока) — принудительный слив
      монитора [MON-EXIT-FORCE] и нормальное завершение monitorexit:
      петля «catch внутри synchronized» рвётся, unwind заканчивается,
      join освобождается. Легитимный код 256 IMS подряд без единого
      успешного monitor-оператора не исполняет.
    - помощники monitor_is_free/monitor_force_release — threads.c,
      объявлены в include/threads.h.
[B] [JOIN-CAP] join() БЕЗ таймаута в окне destroyApp ограничен:
    native_thread_join (join()V — ровно тот, что звал Metal Slug) и
    native_thread_join_millis (join(J)V). Правило: в живой VM join(0)
    остаётся безграничным (игры вольны ждать свои потоки), НО пока
    midp_destroy_app_in_flight() или VM останавливается — ожидание
    ограничено NOJME_JOIN_CAP_MS (по умолчанию 5000 мс), после чего
    [JOIN-CAP] и возврат: teardown всё равно гасит раннеры
    (jvm->running останавливает interpret-циклы). Сессия рвётся
    ГАРАНТИРОВАННО, даже если игровой поток зациклен по-настоящему.
[C] [SPIN-BREAK-MON] SPIN-BREAK (v36.57) бьёт поток, ВЛАДЕЮЩИЙ
    мониторами, только с порогом x8 (12 с при дефолте 1.5 с): исклю-
    чение, влетевшее в поток внутри его synchronized-блока, — лишний
    риск для протокола мониторов (класс Metal Slug). Потоки без
    мониторов (чистые спины) — без изменений; с живым свободным
    соседом — прежний x8 (правила складываются в максимум).
[D] [MIDI-GAIN] ГРОМКОСТЬ: почему midi тише pcm и что сделано.
    Sonivox рендерит СИСТЕМНО тише полного масштаба, а PCM/WAV путь
    играет сэмплы как есть. Замер (scripts/measure_midi_level.c,
    GoF_InGame.MID, 20 c, x86):
      EAS vol 0.90 (дефолт):  peak -8.8 dBFS, RMS -25.2 dBFS
      EAS vol 1.00          :  ВНУТРЕННИЙ САТУРАТОР синтезатора
                               (peak в clamp на плотных аккордах)
      EAS 0.90 + пост-гейн x2:  peak -2.8 dBFS, RMS -19.2 dBFS (+6 дБ)
    Типичный игровой WAV: RMS -12..-18 dBFS. ИТОГ: поднимать EAS-
    громкость НЕЛЬЗЯ (клиппирует сам синтезатор), поэтому добавлен
    ПОСТ-РЕНДЕРНЫЙ цифровой гейн в midi_generate_samples (единая
    точка: SMF-файлы, device://tone и device://midi сырые потоки):
      - дефолт x2.0 (+6 дБ) — MIDI выравнивается с PCM без клипа;
      - settings.ini: midi_gain=200   # проценты 100..400 (100 = v36.90)
      - env: NOJME_MIDI_GAIN (проценты);
      - API: midi_set_gain/midi_get_gain (include/midi.h), диапазон
        0.25..4.0, сатурация на месте применения.
    Player.setVolume по-прежнему работает ПОВЕРХ гейна.

НАСТРОЙКИ (settings.ini): midi_gain=200 (новый ключ, миграция мягкая:
нет ключа = дефолт). Env: NOJME_JOIN_CAP_MS (0 = отключить cap),
NOJME_MIDI_GAIN.

ПРОВЕРКА
--------
  make headless, make platform=linux — чисто (-Wall -Wextra: только
  2 старых unused-function warning в midi.c, не из правок).
  make -n switch парсится (до ожидаемой ошибки отсутствия devkitPro).
  НОВЫЙ E2E-ТЕСТ scripts/imsloop (MonIMSLoopTest.jar, по образцу
  monleak): поток держит монитор 25 c, второй блокируется — MON-STEAL
  на 20 c; владелец выходит -> monitorexit на слитом мониторе ->
  [MON-EXIT-FREE] -> IMSLOOP:RECOVERED (до фикса: IMS-петля, поток
  вечно жив, RECOVERED не печатается); далее destroyApp делает
  join() на вечный поток -> [JOIN-CAP] -> IMSLOOP:DESTROYED -> чистый
  выход. Прогон: NOJME_LOG=1 NOJME_LOGGING=1 NOJME_SYSOUT_TRACE=1
  NOJME_HEADLESS_IDLE=100000 NOJME_HEADLESS_MAX_MS=60000
  ./bin/j2me-headless --headless scripts/imsloop/MonIMSLoopTest.jar
  Регрессии: monleak — n=120 PASSED; Metal Slug 6 headless — рендер/
  тайминги идентичны v36.90 (13.59 с, 6.1M инстр, 95.5% пикселей).
  Замер громкости: scripts/measure_midi_level.c (таблица выше).

ПРИМЕЧАНИЕ ПО САМОЙ ИГРЕ
------------------------
«Metal Slug 6» с этим jar — репак Metal Slug 4 (I-Play) (manifest:
MIDlet-2 class com.iplay.game.metalslug4.M). Аудио в репаке вырезано
(см. выше) — для звука нужен полный jar. Независимо от этого релиз
гарантирует: игра теперь ЗАВЕРШАЕТСЯ при выходе, а 20-секундный фриз
класса MON-STEAL конвертируется в глитч, как и раньше.

СОВМЕСТИМОСТЬ
-------------
midi.h: +2 прототипа (midi_set_gain/midi_get_gain). threads.h: +2
помощника мониторов. Структуры JavaThread/JavaFrame/MidiFile не
менялись. settings.ini/env — обратно совместимы. libretro API не
менялся.

ЛИЦЕНЗИИ — без изменений (Apache 2.0 для sonivox-частей).
