v36.95-midiloop1 (2026-10-08)
=============================

ПОЛЕВОЙ РЕПОРТ: «в каждой игре, где есть закольцованный звук, он в
итоге прерывается и наступает тишина» (репро: Brick Breaker Revolution
3D [Eng], Digital Chocolate).

КОРЕНЬ (не в играх — в MIDI-движке).
Sonivox EAS_Render() после конца SMF-файла ПРОДОЛЖАЕТ возвращать
EAS_SUCCESS с полным буфером (тишина + хвосты голосов). Единственный
детектор конца файла в midi_generate_samples сидел внутри ветки
«r != EAS_SUCCESS || generated <= 0», которая при нормальном EOF не
вызывается НИКОГДА. Секвенсор оставался playing=true навсегда, ветка
луп-рестарта в mix_midi_player (media.c) была мёртвым кодом с самого
перехода на Sonivox (v36.89), и любой MIDI-саундтрек с setLoopCount(-1)
играл ОДИН проход и уходил в вечную тишину. У BBR3D треки 32-55 с —
поэтому «в итоге» = через полминуты-минуту после старта музыки.
Тем же путём были мертвы END_OF_MEDIA для нелупящихся плееров: игры,
которые перезапускают музыку по PlayerListener (пустой листенер у BBR3D
— она рассчитана на setLoopCount), события не получали тоже.

ИГРА (декомпиляция BBR3D): i.a(III) — createPlayer(InputStream,"audio/midi")
+ setLoopCount(n2) + start(); музыка запускается i.a(n2,-1) — setLoopCount(-1),
т.е. луп целиком на совести плеера эмулятора. MIDI лежат в DCHOC-паках
r5/r6/r7 (MThd, format 0, 5060/5465/8538 байт).

ФИКСЫ.
(A) [MIDI-EOF-POLL] midi.c midi_generate_samples: после каждого
    успешного refill-рендера (~5.8 мс аудио) опрос EAS_State() — только
    для SMF-файлов (is_midi_stream=false) и только пока playing:
    STOPPING (все треки дошли до EndOfTrack, голоса дожимаются) /
    STOPPED (голоса слились) / EMPTY -> end_reached=true, playing=false.
    Дальше работает штатная политика микшера mix_midi_player:
    midi_play() (Locate(0)+Resume) для лупа / стоп+END_OF_MEDIA для
    одиночного прохода. device://tone и MIDIControl-стримы
    (is_midi_stream=true) не кончаются — не опрашиваются.
    Учёт loop_count (бесконечный/конечный) и события не менялись —
    просто перестали быть мёртвым кодом.
(B) [MIDI-START-REWIND] media.c native_player_start: убрано затирание
    end_reached=false перед midi_play(). Флаг является ТРИГГЕРОМ отката
    на начало (EAS_Locate(0)) внутри midi_play(); затирание заставляло
    start() после естественного EOF или stop() продолжать С КОНЦА файла
    (мгновенная тишина / мгновенный повторный END_OF_MEDIA).

ТЕСТЫ (scripts/midiloop/test_midi_loop.c — реплика драйвера микшера
media.c сэмпл-в-сэмпл, 221 сэмпл/цикл).
- Синтетический SMF 0.5 с (NoteOn/NoteOff/EndOfTrack):
  * фаза 1 setLoopCount(-1), 4 с аудио: рестартов 7, RMS последней
    секунды 24033 (до фикса: рестартов 0, RMS 0.0 — вечная тишина);
  * фаза 2 без лупа: стоп в EOF + ровно один END_OF_MEDIA (до фикса:
    игрок не останавливался никогда);
  * фаза 3 setLoopCount(2): ровно 2 прохода, стоп, один END_OF_MEDIA.
  До фикса 8 FAIL, после — PASSED 0 failures.
- Реальные MIDI BBR3D из JAR (r5_menu 32 c, r6_music1 35 c,
  r7_music2 55 c + jingle 1.6 c): 3 прохода каждый, рестарты по 3,
  хвостовой RMS 249-52208 — луп живой.
- Регрессии: MonKeyBudgetTest (22 ребоза/доставки/0 MON-WAIT),
  MonIMSLoopTest (RECOVERED catches=0), MonStealGateTest
  (A-SUPPRESSED + B-STEAL-OK + OWNER-EXIT-CLEAN), MonLeakTest n=120
  PASSED; measure_midi_level — цифры без изменений (RMS -19.2 dBFS на
  дефолте, пост-гейн не тронут); MS6 headless 45 c — 0 исключений,
  0 MON-WAIT; BBR3D headless — 0 исключений; make platform=linux +
  headless + libretro .so чисто, make -n switch парсится.

ПОЛЕВАЯ ПРОВЕРКА.
1. Пересборка (make switchui / platform=linux), признак
   build=v36.95-midiloop1-2026-10-08.
2. Любая игра с зацикленной музыкой (Brick Breaker Revolution 3D,
   Galaxy on Fire меню и т.д.): музыка теперь крутится бесконечно,
   тишины после первого прохода нет. Обратный признак в логе при
   NOJME_SONIVOX_TRACE=1: строки «midi EOF: parser state=2/4»
   (STOPPING/STOPPED) на каждом стыке лупа.
3. Игры, перезапускающие музыку по END_OF_MEDIA, тоже оживают:
   событие теперь доходит.
