nojme (J2ME emulator) — v37.03-armalign1-2026-10-11
===================================================

ЧТО ЭТО
-------
ФИКС полевого отчёта M17 (armv7, libretro core): «каждая игра показывает
NullPointerException внутри случайного <init> на pc=1, возможно некоторые
оптимизации нужно отключать для armv7».

ОТВЕТ НА ГИПОТЕЗУ ПОЛЬЗОВАТЕЛЯ: оптимизации НЕ виноваты — все рубильники
(NOJME_FAST_INVOKES=0, NOJME_THREADED_DISPATCH=0, NOJME_SPECIAL_IC=0,
NOJME_FRAME_ZERO=1) НЕ лечили симптом. Виновата РАЗРЯДНОСТЬ: баг уровня
раскладки структур, невидимый на x86-64/aarch64 и фатальный только на
32-бит ARM.

КОРЕНЬ (воспроизведён локально, см. ниже)
-----------------------------------------
sizeof(GCObjectHeader) на 32-бит = 36 байт (4 mod 8). Комментарий в
heap.h утверждал «32 bytes» — арифметика была неверна: next(4)+size(4)+
type(4)+flags(4)+_align_pad(8)+clazz(4)+magic(4)+_magic_pad(4) = 36.
Блоки кучи 8-выровнены (OBJECT_ALIGNMENT=8), указатель Java-объекта =
block_start + sizeof(GCObjectHeader) => КАЖДЫЙ объект на armv7 выходил
4 mod 8 (bump и TLAB шагают на sizeof(header)+round8(payload), так что
старты блоков и объекты чередуют 0/4 mod 8 — «случайность» симптома).

argguard_bad_ptr() (v36.49, include/heap.h) — валидатор ссылок,
вшитый в бинарь: «мусорный ref = не-каноничный (>= 2^48) и/или не
выровнен на 8; настоящие ссылки выровнены минимум на 8 на всех целях
(x86-64, aarch64, armv7)». На 64-бит всё так; на armv7 инвариант был
ЛОЖНЫМ: [ARGGUARD] признавал валидный this мусором и заменял его NULL.
Итог: this == NULL примерно в половине вызовов конструкторов =>
invokesuper на pc=1 (первый invokespecial любого <init>) кидал NPE в
«случайном» <init> в КАЖДОЙ игре. На x86-64/aarch64 заголовок 48 байт
(кратен 8) — платформы не страдали. Байт-кода, оптимизаций v36.99-
v36.104 и Java-логики это не касалось вовсе.

ФИКСЫ
-----
1. [ARM-ALIGN] (include/heap.h) — ГЛАВНЫЙ. Хвостовой uint32_t _pad_arm8
   на 32-бит: sizeof(GCObjectHeader) 36 -> 40, кратность 8 восстановлена
   на ВСЕХ путях аллокации (bump, TLAB fast/refill, free-list, emergency)
   — они все используют runtime sizeof. Добавлен _Static_assert(
   sizeof(GCObjectHeader) % 8 == 0) — регрессия невозможна молча.
   64-бит раскладка БАЙТ-В-БАЙТ неизменна (48 -> 48): ветка #if
   UINTPTR_MAX < 2^64 не компилирует паддинг на 64-бит.
   ПОБОЧНАЯ ПОЛЬЗА: double/long ПОЛЯ объектов на armv7 теперь тоже
   8-выровнены (раньше — 4 mod 8, потенциально UNPREDICTABLE для
   жёстко-плавающих VLDR.64/NEON на Cortex-A7).

2. [WILDGUARD-TYPEFIX] (src/include/wildguard.h) — не-каноничность
   (>= 2^48) теперь #if UINTPTR_MAX > 0xFFFFFFFF: на 32-бит проверка
   вечно false + -Wtype-limits на каждом включении. Семантика 64-бит
   не изменена.

3. [ARGGUARD-TYPEFIX] (include/heap.h, argguard_bad_ptr) — то же самое
   для проверки raw > 0x0000FFFFFFFFFFF8. На 32-бит остаётся только
   проверка выравнивания (raw & 7) — теперь корректная ПОСЛЕ фикса 1.
   Семантика 64-бит не изменена.

4. [SONIVOX-TYPEFIX] (src/midi/sonivox/host_src/eas_config.c) — 6
   extern-деклараций (EAS_SMF/XMF/OTA/iMelody/RTTTL_Parser, EAS_Reverb)
   получили реальные типы (const S_FILE_PARSER_INTERFACE /
   const S_EFFECTS_INTERFACE, заголовки eas_parser.h/eas_effects.h).
   Убраны ВСЕ -Wlto-type-mismatch предупреждения сборки M17 из
   предыдущего отчёта. Не-LTO сборки толерировали несовпадение
   (везде берётся только адрес), LTO — нет.

ВОСПРОИЗВЕДЕНИЕ И ВЕРИФИКАЦИЯ (локально, qemu-arm)
--------------------------------------------------
Окружение: bootlin armv7-eabihf glibc stable-2024.05-1 (gcc 13.3,
arm-buildroot-linux-gnueabihf-, hard-float) + qemu-user-static 7.2 +
ТОЧНЫЙ m17-флаг-коктейль из Makefile (включая -flto и ARM_OPT_CFLAGS:
-ftree-vectorize -fipa-cp-clone -finline-functions-called-once, БЕЗ
-fno-strict-aliasing-семейства). Инструменты сохранены в дереве:
scripts/armv7_repro.sh (сборка/запуск), scripts/armv7_battery.sh
(батарея), scripts/aarch64_sweep.sh (sweep Switch-флагами).

ДО фикса:
  - RetBench.jar: [J2ME UNCAUGHT EXCEPTION] java/lang/NullPointerException
    + verbose: «[EXCEPTION] ... occurred at PC=1 in RetBench.<init>»
    + «[ARGGUARD] this-слот #0 мусор в RetBench.<init>()V:
    raw=0x000000003bfbe34c» (адрес 4 mod 8!) — ТОЧНО полевой симптом.
  - То же и БЕЗ LTO => НЕ компиляторная оптимизация, а код.
  - Ни один рубильник оптимизаций не лечил.

ПОСЛЕ фикса (всё бит-в-бит к золотым v36.100-v36.104):
  - headless-armv7-LTO:    RB SUM-L 5597742076056351744,
    SUM-D 3.999979998000101, SUM-F NaN, SUM-M -3739709241755009701,
    RB DONE.
  - headless-armv7-noLTO:  те же 4 суммы + RB DONE.
  - НАСТОЯЩИЙ bin/nojme_libretro.so (make platform=m17, полный m17
    коктейль) под libretro-фронтендом lr_run (scripts/lr_run.c):
    те же 4 суммы + RB DONE; TestBattery.jar: [TB] done, 0 исключений.
  - Батарея qemu x8 (scripts/armv7_battery.sh): retbench OK,
    testbat OK ([TB] done), bench OK, callbench OK (3.4M инстр/с в
    qemu), densebench OK (acc растёт), ifbench OK (fix=1529307776),
    recbench OK (d1500/d2000/i2000/v1500 OK, d5000 чистый
    StackOverflowError, DONE bad=0), effbench OK (EFF DONE
    acc=14891816583). 0 исключений, 0 [ARGGUARD] во всей батарее.

РЕГРЕССИЯ ХОСТА (x86-64, layout не менялся):
  - make switchui-verify: 0 предупреждений.
  - test_retbench.sh: SUM-L/D/F/M OK (4/4).
  - TestVector: 9 PASS; TestConcat: 8 PASS (как у v36.104).
  - fenceslow (дефолт + NOJME_SPIN_BREAK_PAINT=0), fencewait,
    spinbreak: ALL CHECKS PASSED — фиксы v36.98 НЕ тронуты.
  - aarch64 sweep (gcc 14.2, полный Switch-набор флагов): 68 файлов,
    0 предупреждений.

ПРИМЕЧАНИЕ ПО СБОРКЕ M17
------------------------
- gcc >= 13/14 + LTO на .so может упереться в R_ARM_TLS_LE32 (TLS
  local-exec в shared object; воспроизведено на bootlin gcc 13.3).
  Это ДОКУМЕНТИРОВАННО в Makefile (v34.80): спасает NOJME_M17_NO_LTO=1.
  Тулчейн пользователя, судя по отчёту, линкуется без этого.
- Оставшиеся предупреждения m17-сборки (eas_dlssynth fallthrough,
  неиспользуемые nojme_loc_* в midi.c) — pre-existing, безобидные,
  не связаны с фиксами.
- MODULE_LOG_TS (ошибка линковки из прошлого отчёта) — правка
  локального дерева пользователя v37.x, в этом дереве (v36.104-базе)
  такого символа нет; патч его не касается.

ПАТЧ ДЛЯ ДЕРЕВА v37.02
----------------------
v37.03-armalign1.patch — только функциональные файлы (heap.h,
wildguard.h, eas_config.c), применяется patch -p1 из корня дерева.
База патча v36.104; на v37.02 те же места должны примениться (файлы
стабильны), при дрейфе контекста — вручную по комментариям [ARM-ALIGN].

ВЕРСИЯ
------
CORE_BUILD_ID -> v37.03-armalign1-2026-10-11 (include/core_version.h,
полный некролог там же). Признак в логе: «nojme libretro core BUILD:
v37.03-armalign1-2026-10-11 (Corax89)».
