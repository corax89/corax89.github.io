════════════════════════════════════════════════════════════════════
 NOJME v36.94 — [KEY-BUDGET] + [STALLSTACK-REMOTE] (поверх v36.93)
════════════════════════════════════════════════════════════════════

ЧТО ЭТО
-------
Патч-релиз поверх v36.93. Адресует полевой лог v36.93-ms6fix3
(Metal Slug 6 (I-Play)(1.0.1), 2473 строк): «в конце лога удалось
попасть сразу на два очень длительных зависания».

ЧТО ПОКАЗАЛ ПОЛЕВОЙ ЛОГ v36.93
------------------------------
Сессия Metal Slug 6 (t=5..150 c), конец СТАДИИ 1 (t≈100 c — 81k
стрим-ридов tally-фазы, sfx-файлы отсутствуют в репаке). Далее ДВА
фриза фронтенда:

  Фриз A: t=122.6..125.1 (2.5 c)
  Фриз B: t=126.3..148.9 (22.5 c !!)

    [MON-WAIT] site=block at.h@197 waited=2000/7003/12005/17008/22010 ms
               owner_tid=2 owner_nat=java/lang/System.arraycopy
    td m:  monenter=1s..21s js=at.keyReleased@0   ← насос в keyReleased
    td t2: run nat=(idle) age=-1 jsite=at.bl@14630 ← иГРОВОЙ поток стоит
    [PUMP-GAP] 22565 ms between input pumps       ← фронтенд мёртв целиком
    diag: ... mx=22560 tj=22539 ...

КЛЮЧЕВОЕ ОТКРЫТИЕ (дизассемблер at.class): trylock v36.93 закрить эту
гонку НЕ МОГ, потому что у игры ВТОРОЙ замок:
  • at.run() [605..700] держит synchronized(поле at.a) — отдельный
    lock-ОБЪЕКТ состояния ввода (внутри: System.arraycopy(b,c,23) —
    тот самый «arraycopy» в owner_nat — и слияние 23 байт клавиш);
  • at.h(II) (путь keyReleased) делает monitorenter на ТОТ ЖЕ at.a
    (PC 188-196: aload_0; getfield at.a; monitorenter);
  • trylock v36.93 проверяет КАНАВУ (current_displayable_obj) — другой
    объект! Канва свободна (t2 вне bl) → tryenter УСПЕШЕН → насос
    входит в keyReleased → monenter at.a → ВИСИТ, пока t2 держит at.a.

ЧЕМ СТОЯЛ t2 (важно для диагностики)
------------------------------------
Во время фриза B (22.5 c) игровой поток:
  • последний натив — arraycopy key-sync секции (t≈126.3), ДАЛЬШЕ
    НИ ОДНОГО натива (td: nat=(idle) во всех 40+ сэмплах);
  • НОЛЬ yield-ов (1024 инструкции на yield): нет [STALLSTACK],
    нет [SPIN-GATE], нет выстрела спин-брейкера, jsite ЗАМЕР на
    at.bl@14630 (обновление раз в 64k инструкций — не достигнуто);
  • state=run, НЕ в мониторе (нет флага monenter), park_why пуст,
    GC не запускался (gc=0).
То есть t2 выполнил МЕНЬШЕ 1024 инструкций за 22.5 c, стоя внутри/после
key-sync секции. ТОЧНЫЙ опкод/метод не назван — свидетелей не было:
[STALLSTACK] v36.92 печатает САМ поток на ближайшем yield, а yield-ов
не было. Диагностика этого класса добавлена (см. (B)); корень стояния —
следующий шаг по свежему логу с v36.94.

ИЗМЕНЕНИЯ (v36.94)
------------------
[A] [KEY-BUDGET] (src/midp/display.c) — ГЛАВНЫЙ ФИКС, убирает видимый
    фриз фронтенда:
    • Доставка клавиш НА ФРОНТЕНДЕ (fallback midp_pump_deferred_keys
      и tid-1 путь midp_process_pending_keys) идёт с БЮДЖЕТОМ монитора:
      NOJME_KEY_BUDGET_MS (дефолт 1000 мс, 0 = выкл).
    • Механизм переиспользует PAINT-BUDGET v36.57: monitor_enter по
      истечении бюджета выходит JNI_ERR, op_monitorenter бросает
      RuntimeException, доставка РАЗМАТЫВАЕТСЯ чисто через
      Java-обработчики (MONITOR-UNWIND v34.99 освобождает мониторы
      кадра), ключ возвращается в ГОЛОВУ очереди и доставляется на
      следующей попытке (когда игра отпустит свой замок).
    • Лог: [KEY-BUDGET] key delivery exceeded N ms on release(-4) —
      requeued (game holds its input lock); frontend loop alive.
    • Игровые потоки (VM-раннеры) дренажируют БЕЗ бюджета — их
      ожидания это игровая логика, их фриз это фриз игры.
    ЭФФЕКТ: фронтенд замирает максимум ~1 c за попытку ВМЕСТО 22.5 c.
    Present, таймеры, меню паузы, сторожа, HOME — живы всегда.
    Клавиша теряется только если игра держит замок дольше бюджета
    КАЖДУЮ попытку — и то остаётся в очереди до оживления игры.
[B] [STALLSTACK-REMOTE] (include/jvm.h, src/jvm/execute.c,
    src/jvm/native.c, src/switch/switch_trace.c) — диагностика класса
    «стояние без yield-ов»:
    • JavaThread.frame_seq — seqlock, bump в push_frame/pop_frame.
    • JavaThread.stall_ring_op/pc[16] — кольцо последних (op,pc),
      пишется на slow-check (каждые 64 инструкции, рядом со
      spin_instr).
    • jvm_threads_dump_stall_frames(tid) — beat печатает цепочку
      кадров ЗАСТРЯВШЕГО потока БЕЗ его участия: [STALLSTACK-REMOTE]
      (кадры + jsite + in_native + park_why + spin_instr + native_age)
      и [STALL-RING] (op/pc-дорожка: движется ли pc или стоит в одном
      опкоде). Безопасность: seqlock-конвергенция (живой/мутирующий
      поток уводит frame_seq — дамп молча отменяется); кадры
      возвращаются в пул (не free) — указатели остаются читаемы.
    • Вызывается из [STALL-PROBE] (switch_trace.c) одновременно с
      запросом self-serve [STALLSTACK]: теперь свидетель есть в ЛЮБОМ
      случае — дошёл поток до yield или нет.
[C] [SPIN-GATE] (src/jvm/execute.c): подавление выстрела брейкера
    логируется каждые 255 пожаров вместо 1023 — «тихое» подавление
    оставляет хотя бы один след за эпизод.

ЧТО ЭТО НЕ ДЕЛАЕТ
-----------------
Стояние t2 на 2.5-22.5 c — это по-прежнему код игры/репака, который
на телефоне занимает доли секунды. v36.94 НЕ ускоряет его, но (1)
фронтенд больше не умирает на это время ВООБЩЕ, (2) [STALLSTACK-REMOTE]
+[STALL-RING] в свежем логе назовут ТОЧНОЕ место стояния (метод, pc,
опкод-дорожка) — и следующим шагом делается точечный фикс/шорткат.

ТЕСТЫ
-----
• make headless / make platform=linux — чисто, без новых warnings.
• НОВЫЙ e2e scripts/keybudget (MonKeyBudgetTest): гонка воспроизведена
  детерминированно (игровой поток держит замок ввода 4 c с arraycopy
  внутри synchronized, канва свободна; KEYSCRIPT-ключи). Результат:
  22× [KEY-BUDGET] requeue, 0× [MON-WAIT]>=2s, все ключи доставлены в
  окна освобождения замка, canvas красится на протяжении всего эпизода.
  До v36.94: доставка висла на весь hold (4 c) — точная форма полевого
  фриза.
• Регрессии мониторов: imsloop (MonIMSLoopTest) — RECOVERED catches=0,
  JOIN-CAP, DESTROYED: PASSED. stealgate (MonStealGateTest) — фаза A
  GATE:A-SUPPRESSED-OK waited=25019, фаза B GATE:B-STEAL-OK +
  REACQUIRED + OWNER-EXIT-CLEAN: PASSED. monleak n=120: PASSED.
• Headless-прогон Metal Slug 6 (30 c, инъекции клавиш): чисто,
  ключи delivered ret=0, EX-THROW=0 на меню, 13.76M инструкций.

РУБИЛЬНИКИ
----------
NOJME_KEY_BUDGET_MS=1000 — бюджет доставки клавиш на фронтенде, мс
  (0 = выкл = поведение v36.93). Дефолт 1000.
NOJME_DEFER_KEYS=0 — старый inline-путь доставки (НЕ рекомендуется).
NOJME_SPIN_BREAK_MS / NOJME_SPIN_BREAK_INSTR — без изменений.

ПАКЕТ
-----
nojme-j2me-v36.94-sonivox.tar.gz — полное дерево исходников.
v36.94-key-budget-stalldiag.patch — дифф поверх чистой v36.93
  (include/jvm.h, src/jvm/execute.c, src/jvm/native.c,
  src/midp/display.c, src/switch/switch_trace.c, +scripts/keybudget/).
