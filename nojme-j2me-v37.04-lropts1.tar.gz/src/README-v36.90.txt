════════════════════════════════════════════════════════════════════
 NOJME v36.90 — [MIDI-PERF] + [RAW-MIDI-CRASH] (поверх v36.89-sonivox)
════════════════════════════════════════════════════════════════════

ЧТО ЭТО
-------
Патч-релиз поверх v36.89 (интеграция Sonivox). Адресует полевой
репорт: «очень низкая производительность после добавления нового midi
движка, особенно в Galaxy on Fire; возможно звук генерируется в
основном потоке или происходит ожидание генерации? можно уменьшить
полифонию и отключить filter + reverb».

КРАТКИЙ ОТВЕТ НА ВОПРОСЫ РЕПОРТА
--------------------------------
1) «Звук генерируется в основном потоке / есть ожидание генерации?»
   - Standalone (Switch/SDL): НЕТ, рендер MIDI идёт в фоновом
     аудио-потоке (audio_thread_func, media.c), основной поток его НЕ
     ждёт. НО: все вызовы Player API из Java (start/stop/getState/
     getMediaTime/setVolume) берут ТОТ ЖЕ g_audio_mutex, что и миксер,
     поэтому любой долгий участок под мьютексом в аудио-потоке
     тормозит Java-потоки (эффект «ожидания генерации»). В v36.89 под
     мьютексом случались: безусловный SONIVOX_TRACE (SD I/O при
     logging=on) и рендер с filter+reverb+64 голосами.
   - libretro (RetroArch): ДА, media_generate_audio_samples() зовётся
     синхронно на потоке эмуляции каждый кадр — там аудио честно
     отнимает время кадра.
2) «Уменьшить полифонию и отключить filter+reverb» — СДЕЛАНО, теперь
   это РАНТАЙМ-настройки (см. ниже), дефолт — «быстрая» конфигурация.

ИЗМЕНЕНИЯ
---------
[A] [RAW-MIDI-CRASH] КРИТИЧЕСКИЙ ФИКС: EAS_OpenMIDIStream
    (src/midi/sonivox/eas_host_nojme.c) ставил в слот потока маркер
    pParserModule = (void*)1. EAS_Render/EAS_SetVolume/
    EAS_StreamReady/EAS_Shutdown разыменовывают этот указатель как
    S_FILE_PARSER_INTERFACE* → дикий вызов → SEGV. Воспроизводится на
    хосте стопроцентно: midi_load_empty() падала ещё до первого NoteOn
    (ASAN: SEGV 0x21 в EAS_StreamReady, eas_public.c:149). ПОД УДАРОМ
    БЫЛИ ВСЕ device://tone и device://midi плееры (ToneControl,
    MIDIControl, Manager.createPlayer("device://tone")). ФИКС: в слот
    ставится настоящий константный S_FILE_PARSER_INTERFACE
    (EAS_NOJME_MIDIStream_Parser) с pfTime == NULL — на это явно
    рассчитан EAS_ParseEvents в AOSP («live stream» ветка: время
    двигается, парсить в рендере нечего, голоса рендерит VMRender).
    NM_Close корректно освобождает wrapper при EAS_Shutdown,
    EAS_CloseMIDIStream чистит слот — двойного free нет (проверено
    ASAN c detect_leaks=1). NM_SetData/NM_GetData дают рантайм-
    полифонию и synth-handle для raw-стримов.

[B] [MIDI-PERF] Рантайм-конфигурация синтезатора (вместо пересборки):
    - midi_set_polyphony(0..32) — через AOSP EAS_IntSetStrmParam(
      PARSER_DATA_POLYPHONY) → VMSetPolyphony. Применяется к живым
      инстансам (реестр в midi.c, свой мьютекс) и ко всем будущим
      midi_load/midi_load_empty.
    - midi_set_filter_enabled(on) — гейт WT_VoiceFilter в
      eas_wtengine.c (самый дорогой per-sample блок WT-движка).
    - midi_set_reverb_enabled(on) — гейт Schroeder reverb в
      eas_mixer.c (обрабатывает всю выходную шину каждый блок).
    - КОМПИЛЯЦИОННЫЕ ДЕФАЙНЫ НЕ ТРОНУТЫ: код фильтра/реверба собирается
      как раньше, решают флаги. Дефолты — БЫСТРАЯ конфигурация:
      полифония 24, filter OFF, reverb OFF (эпоха J2ME: dry mix).
    - MAX_SYNTH_VOICES в Makefile 64 → 32 (меньше голосового пула и
      scan-ов VMFindVoice; реальные SMF эпохи — ≤16-20 нот).
    - mix_midi_player (media.c): убран двойной memset temp_buf —
      midi_generate_samples всегда сам очищает буфер.

[C] [TRACE-GATE] SONIVOX_TRACE больше не безусловный: гейтится env
    NOJME_SONIVOX_TRACE=1 (на Switch sw_trace дополнительно гейтится
    своим logging-тумблером, как и раньше). Убрано SD I/O и пик-скан
    буфера из горячего пути аудио-потока (2 записи/сек под
    g_audio_mutex в v36.89).

[D] НАСТРОЙКИ (settings.ini Switch-фронта):
      midi_polyphony=24      # 0..32 (0 = максимум сборки)
      midi_filter=off        # on = резонансный фильтр голоса
      midi_reverb=off        # on = Schroeder reverb на шине
    Разбираются/сохраняются switch_ui.c (parse_ini_line + save),
    применяются в main.c ДО старта сессии. Env-эквиваленты (headless/
    desktop/libretro): NOJME_MIDI_POLYPHONY, NOJME_MIDI_FILTER,
    NOJME_MIDI_REVERB. Публичное API — в include/midi.h.

КАК ЭТО ВЛИЯЕТ НА ПРОИЗВОДИТЕЛЬНОСТЬ (факты, не догадки)
--------------------------------------------------------
Хост-бенчмарк (x86, GoF_InGame.MID, рендер 30 с аудио порциями 5 мс
как в audio_thread_func):
  - v36.89 конфиг (64 голоса + filter + reverb):  895x realtime
  - v36.90 дефолт (24 голоса, dry):               945x realtime
  - polyphony 16:                                1057x realtime
Т.е. сам синтез даже в худшей конфигурации занимает ~0.1-0.2% CPU
хоста; на A57 Switch это ~1-3% одного ядра. ВЫВОД: «очень низкая
производительность» в GoF НЕ объясняется стоимостью EAS_Render. Что
реально могло давать фризы/потерю кадров в v36.89:
  - SEGV/abort на device://tone|MIDIControl у части игр (краш);
  - SD I/O (sw_trace) из-под аудио-мьютекса при logging=on — блоки
    на 1-10+ мс дважды в секунду, все Player-вызовы из Java ждут;
  - накопительный фон filter+reverb+64 голосов на слабом CPU.
Все три устранены/перекрыты этим релизом. Если в конкретной игре
остаются тормоза — это уже JVM-бюджет/графика, а не MIDI: смотреть
[BENCH]/AUDIOPROF (NOJME_AUDIOPROF=1) и vm_speed.

ПРОВЕРКА
--------
  make platform=linux   # чисто, 3 старых warning'а (не из правок)
  make headless         # чисто
  Гейм-регрессия: j2me-headless --headless GoF.jar — пиксели/инструкции/
  тайминги идентичны v36.89 (13.59 с / 13.9M инстр.).
  Raw-стрим тест (midi_load_empty + NoteOn + 1 c рендера): SEGV до
  фикса, после — peak=1834, ASAN чистый.
  Авторский smoke-тест scripts/test_sonivox.c: ожидание теста
  (peak>1000) не достигается И НА ИСХОДНОЙ v36.89 (peak 396-576) —
  калибровка теста, не регрессия; сам рендер звука работает.

СОВМЕСТИМОСТЬ
-------------
midi.h: добавлены 6 прототипов midi_(get/set)_*; структура MidiFile и
все существующие вызовы не менялись. settings.ini: новые ключи
мигрируют мягко (нет ключа = дефолт). libretro API не менялся.

ЛИЦЕНЗИИ — без изменений (Apache 2.0 для sonivox-частей).
