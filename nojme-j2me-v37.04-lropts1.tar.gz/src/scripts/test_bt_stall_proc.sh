#!/bin/bash
# BT-STALL: /proc-форензика в момент зависания m (без gdb).
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/Bounce Tales (240x320).jar"
D=/tmp/tbtproc
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/bt.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=off
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:3000"
export NOJME_FRONT_KEYS="A:6000,A:25000,A:40000"
BIN="$PWD/bin/switchui-verify"
( cd "$D" && exec "$BIN" > out.log 2> err.log ) &
MAINPID=$!
sleep 45
echo "== threads (comm state wchan) =="
for t in /proc/$MAINPID/task/*; do
  tid=${t##*/}
  state=$(awk '{print $3}' "$t/stat" 2>/dev/null)
  wchan=$(cat "$t/wchan" 2>/dev/null)
  comm=$(cat "$t/comm" 2>/dev/null)
  utime=$(awk '{print $14}' "$t/stat" 2>/dev/null)
  sys=$(awk '{print $3, $14, $15}' "$t/stat" 2>/dev/null)
  echo "tid=$tid comm=$comm state=$state wchan=$wchan utime=$utime"
done
echo "== main thread syscall =="
cat /proc/$MAINPID/syscall 2>/dev/null
echo "== /proc/$MAINPID/stack =="
sudo -n cat /proc/$MAINPID/stack 2>/dev/null || cat /proc/$MAINPID/stack 2>/dev/null || echo "(stack unavailable)"
echo "== log tail (stall active?) =="
tail -6 "$D/sdmc:/switch/j2me/log.txt" 2>/dev/null
sleep 5
echo "== again after 5s: state changes =="
for t in /proc/$MAINPID/task/*; do
  tid=${t##*/}
  state=$(awk '{print $3}' "$t/stat" 2>/dev/null)
  wchan=$(cat "$t/wchan" 2>/dev/null)
  comm=$(cat "$t/comm" 2>/dev/null)
  echo "tid=$tid comm=$comm state=$state wchan=$wchan"
done
kill $MAINPID 2>/dev/null; sleep 1; kill -9 $MAINPID 2>/dev/null
