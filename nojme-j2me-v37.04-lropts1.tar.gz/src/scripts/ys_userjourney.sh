#!/bin/bash
# [YS-USERJOURNEY] (yetifix3) Полный путь пользователя с реальными кнопками:
#   диалог звука: X (LSK "On") СРАЗУ подтверждает (фикс [SOFT-GAMEACTION]);
#   сплэш: A ('5'); меню: стик '8' вниз x3 -> Options -> A; Options: вниз x3 ->
#   Change player name -> A; редактор имени: '2'/'8' буквы, '5' ввод, X (ABC),
#   B (Back). Дампы 1/с + VLM-разбор ключевых кадров.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ys_journey
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/saves" "$D/cd"
YS="${YS_JAR:-/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar}"
cp "$YS" "$D/roms/Yeti Sports (00.02.51)[240x320].jar"
cp -r /tmp/ys_nameflow/saves/* "$D/saves/" 2>/dev/null || { echo "нет opt-состояния"; exit 1; }

cat > "$D/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=off
keyhint=off
saves_dir=$D/saves
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"

export NOJME_COMPOSITE_DUMP_DIR="$D/cd" NOJME_COMPOSITE_DUMP_MAX=60
#                диалог(12с)+X | сплэш+A | меню внизx3+A | Options внизx3+A |
export NOJME_GAME_KEYS="W:12000,-6:400,W:2500,53:300,W:3000,56:300,W:600,56:300,W:600,56:300,W:800,53:300,W:1800,56:300,W:600,56:300,W:600,56:300,W:800,53:300,W:2500,50:300,W:800,50:300,W:800,53:300,W:1200,-6:400,W:1500,-7:400,W:3000"
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:52000"
timeout -k 5 56 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
echo "дампов: $(ls "$D/cd" | wc -l)"
echo "=== GAMEKEYS (stderr) ==="; grep -ac GAMEKEYS "$D/err.log"
echo "=== исключения ==="; grep -aE "EX-THROW|ATHROW" "$D/log.txt" | head -5 || echo "нет"
