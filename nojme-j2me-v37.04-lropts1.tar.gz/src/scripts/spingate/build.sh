#!/bin/bash
# Build SpinGateTest.jar — v36.88 [SPIN-BREAK-ICOUNT] selftest.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
STUBS="$D/../keysjar/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/SpinGateTest.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: SG, , SpinGateTest\r\nMIDlet-Name: SpinGateTest\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/SpinGateTest*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/SpinGateTest.jar" META-INF && zip -q "$D/SpinGateTest.jar" *.class )
echo "built: $D/SpinGateTest.jar"
