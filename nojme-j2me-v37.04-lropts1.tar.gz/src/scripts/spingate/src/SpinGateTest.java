/* v36.88 [SPIN-BREAK-ICOUNT] selftest: гейт «работа подтверждает спин».
 *
 * ПОЛЕВОЙ КОРЕНЬ (v36.87, Zombie Infection, кнопка HOME): сон консоли
 * замораживает весь процесс; после возврата WALL-возраст потока с
 * последнего натива состарен на длительность сна, а ИНСТРУКЦИЙ исполнилось
 * считанные сотни. Спин-брейкер v36.57 сравнивал только возраст — и
 * стрелял в живой кадр; Gameloft-каркас ловил исключение и замирал
 * навсегда («зависла, осталась работать только музыка»).
 *
 * Метод (детерминированный, без сигналов): порог возраста опускается
 * до 1 мс (NOJME_SPIN_BREAK_MS=1) — тогда «высокий возраст при малой
 * работе» достигается обычным коротким чисто-Java участком (~30-80 тыс.
 * команд без нативов), ровно как после сна ОС. Гейт при этом должен
 * ПОДАВЛЯТЬ выстрел (работа < NOJME_SPIN_BREAK_INSTR), а настоящий спин
 * (миллионы команд) — ПРОБИВАТЬ.
 *
 * Фазы (startApp, синхронно, main-файбер — без бюджетного throttling):
 *  A) phaseA_work: 20000 итераций чистой арифметики (~380k команд при
 *     ~19 инстр/итерацию; замер хоста-verify ~200M команд/с -> ~2 мс
 *     wall, возраст > NOJME_SPIN_BREAK_MS=1). Работа остаётся НИЖЕ
 *     порога гейта прогона 1 (1000000): выстрел ПОДАВЛЕН -> SG:A-OK.
 *     Гейт ВЫКЛ (INSTR=0): ложный выстрел, как v36.87 -> SG:A-CAUGHT.
 *     Дефолтный порог 200k на этой скорости пересекается за 1 мс —
 *     потому прогон 1 задаёт порог явно; ДЕФОЛТЫ (1500 мс + 200k)
 *     упражняет регрессионный test_spinbreak (настоящий GD-спин).
 *  B) phaseB_spin: 3 млн итераций (~57M команд): работа пересекает
 *     любой разумный порог за единицы мс -> выстрел ПО МЕСТУ ->
 *     SG:B-CAUGHT. При гигантском пороге (INSTR=200M) — ни одного
 *     выстрела, цикл доходит до конца -> SG:B-NOSPIN.
 * Маркеры в System.out, [SPIN-BREAK]/[SPIN-GATE] в логе; сайт выстрела
 * (jsite) различает фазы: у phaseA выстрела быть не должно (гейт ВКЛ),
 * у phaseB — должен. */
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class SpinGateTest extends MIDlet {
    public SpinGateTest() { System.out.println("SG:ctor"); }

    static long phaseA_work(long seed) {
        long sink = seed;
        for (int i = 0; i < 20000; i++) {
            sink = sink * 1103515245L + 12345L + (long) i;
            sink ^= sink >> 3;
        }
        return sink;
    }

    static long phaseB_spin(long seed) {
        long sink = seed;
        for (int i = 0; i < 3000000; i++) {
            sink = sink * 1103515245L + 12345L + (long) i;
            sink ^= sink >> 3;
        }
        return sink;
    }

    public void startApp() {
        final Canvas c = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0, 0, 0);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        Display.getDisplay(this).setCurrent(c);
        System.out.println("SG:begin");
        long r = 0;
        try {
            r = phaseA_work(12345L);
            System.out.println("SG:A-OK " + r);
        } catch (RuntimeException e) {
            System.out.println("SG:A-CAUGHT: " + e.getMessage());
        }
        try {
            r = phaseB_spin(r);
            System.out.println("SG:B-NOSPIN " + r);
        } catch (RuntimeException e) {
            System.out.println("SG:B-CAUGHT: " + e.getMessage());
        }
        System.out.println("SG:done");
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
