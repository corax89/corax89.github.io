#!/bin/bash
# v37.03: ARMv7 (M17 flags) qemu battery — run the core VM test jars on the
# cross-built headless binary and report pass/fail per jar.
# Usage: armv7_battery.sh <binary>
set -u
BIN="${1:-/home/z/my-project/src/bin/j2me-headless-armv7-lto}"
Q=/home/z/my-project/work/armtc/qemu-arm-static
cd "$(dirname "$0")/.." || exit 1
R="$(pwd)"
declare -A RESULTS

run_jar() {  # $1=name $2=jar $3=ms $4=grep-pattern (optional)
    local name="$1" jar="$2" ms="$3" pat="${4:-}"
    local log="/tmp/armbat_$name.log"
    NOJME_HEADLESS_MAX_MS="$ms" NOJME_LOG=1 NOJME_LOGGING=1 \
        timeout -k 5 $((ms/1000 + 20)) $Q "$BIN" "$jar" > "$log" 2>&1
    local exc=$(rg -c "UNCAUGHT EXCEPTION|ARGGUARD" "$log" 2>/dev/null || echo 0)
    local out=$(rg "\[SYSOUT\]" "$log" 2>/dev/null | tail -6 | tr '\n' '|' | head -c 300)
    local verdict="OK"
    [ "$exc" != "0" ] && verdict="EXC($exc)"
    if [ -n "$pat" ] && ! rg -q "$pat" "$log" 2>/dev/null; then verdict="$verdict PATTERN-MISS($pat)"; fi
    printf "%-14s %-10s sysout: %s\n" "$name" "$verdict" "$out"
    RESULTS[$name]="$verdict"
}

echo "=== ARMv7 qemu battery: $BIN ==="
run_jar retbench  scripts/retbench/RetBench.jar        60000 "RB DONE"
run_jar testbat   scripts/battjar/TestBattery.jar      60000
run_jar bench     scripts/benchjar/Bench.jar           60000
run_jar callbench scripts/callbench/CallBench.jar      60000
run_jar densebench scripts/densebench/DenseBench.jar   60000
run_jar ifbench   scripts/ifbench/IfaceBench.jar       90000 "fix=1529307776"
run_jar recbench  scripts/recbench-jar/RecBench.jar    90000
run_jar effbench  scripts/effbench/EffBench.jar        90000
echo "=== done ==="
