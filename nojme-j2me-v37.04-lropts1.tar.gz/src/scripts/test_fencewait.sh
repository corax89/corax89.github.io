#!/bin/bash
# v36.83 [ZFENCE-PAINT] e2e: TestFenceWait.jar на switchui-verify.
# paint() чистой Java ждёт флага от второго потока (Gameloft-загрузка).
# PASS: WAIT-OK, SURVIVED-ALL, НИ ОДНОГО SPIN-BREAK, WAIT-OK раньше 2.5с.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tfw
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/fencejar/TestFenceWait.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:600,EXIT:20000"
timeout -k 5 40 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

ok=1
grep -aq "TFW:WAIT-OK" "$D/err.log" || { echo "FAIL: нет TFW:WAIT-OK (спин не вышел)"; ok=0; }
grep -aq "TFW:WAIT-DEAD" "$D/err.log" && { echo "FAIL: TFW:WAIT-DEAD (воркер не дошёл до флага)"; ok=0; }
grep -aq "TFW:SURVIVED-ALL" "$D/err.log" || { echo "FAIL: нет TFW:SURVIVED-ALL"; ok=0; }
n_break=$(grep -ac "SPIN-BREAK\]" "$D/err.log")
[ "$n_break" -eq 0 ] || { echo "FAIL: SPIN-BREAK сработал $n_break раз (fence заморозил воркера в paint)"; ok=0; }
grep -aq "TFW:flag-set" "$D/err.log" || { echo "FAIL: нет TFW:flag-set (воркер не жил)"; ok=0; }
echo "WAIT-OK: $(grep -ac 'TFW:WAIT-OK' "$D/err.log"); frames: $(grep -ao 'TFW:SURVIVED-ALL frames=[0-9]*' "$D/err.log"); SPIN-BREAK: $n_break"
grep -a "TFW:\|SPIN-BREAK\|paint() threw" "$D/err.log" | head -10
[ $ok -eq 1 ] && echo "FENCEWAIT E2E: ALL CHECKS PASSED" || echo "FENCEWAIT E2E: FAILED"
exit $((1-ok))
