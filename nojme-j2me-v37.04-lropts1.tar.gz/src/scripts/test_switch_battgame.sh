#!/bin/bash
# [BATT-GAME]+[PRESENT-GLASS] v36.43 E2E: индикатор заряда в КАДРЕ ИГРЫ —
# теперь ПИКСЕЛЬНО (композит-дамп SDL_RenderReadPixels), а не только трассой.
#
# Полевой отчёт v36.42: «аккумулятор если его показ включен должен
# показываться и во время работы игры» — трасса оверлея при этом в логе
# БЫЛА, т.е. код работал, а видимости в поле не было. Новый тест читает
# ФИНАЛЬНЫЙ композит экрана (все слои: блюр-фон + вид игры + бейдж) и
# проверяет пикселями, что бейдж действительно в кадре, стоит на тех же
# пикселях, что и в меню, и НЕ содержит удалённой молнии [BATT-DEBOLT].
#
# Заодно проверяются новые приборы [PRESENT-GLASS]: [RND] renderer= в
# логе, utf=0 rcf=0 в diag (отказов SDL нет) и ch>=1 (композит на экране
# реально менялся).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_battgame
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/cdump"
cp scripts/battjar/TestBattery.jar "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=icon
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_BATTERY_MOCK=63:c
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_COMPOSITE_DUMP_DIR="$D/cdump"
export NOJME_COMPOSITE_DUMP_MAX=30
export XDG_DATA_HOME="$D/xdg"
# A@1200 (браузер), A@500 (запуск TestBattery), выход по EXIT после конца
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:16000"

timeout -k 5 40 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"

# --- 1) сессия прошла и оверлей игрового кадра включился (режим значок) ---
grep -ahq "TB] done" $ALL || { echo "FAIL: TestBattery не дошёл до [TB] done"; ok=0; }
grep -ahq "battery: overlay icon 63% charging=1 src=env" "$D/log.txt" || {
  echo "FAIL: нет трассы «battery: overlay icon 63% charging=1 src=env»"; ok=0; }

# --- 2) приборы [PRESENT-GLASS] ---
grep -ahq "\[RND\] renderer=" "$D/log.txt" || {
  echo "FAIL: нет трейса [RND] renderer= (имя рендерера)"; ok=0; }
grep -ahq "PRESENT-FAIL" $ALL && {
  echo "FAIL: в логе есть [PRESENT-FAIL] — отказы SDL в чистом стенде:"; grep -ah "PRESENT-FAIL" $ALL | head -3; ok=0; }
# utf/rcf обязаны быть 0 в каждой diag-строке; ch хоть раз > 0
DIAGS=$(grep -aE "^[0-9]+ diag: " "$D/log.txt")
if echo "$DIAGS" | grep -qv "utf=0 rcf=0"; then
  echo "FAIL: не во всех diag utf=0 rcf=0:"; echo "$DIAGS" | grep -v "utf=0 rcf=0" | head -3; ok=0
fi
CH_SUM=$(echo "$DIAGS" | grep -o "ch=[0-9]*" | cut -d= -f2 | awk '{s+=$1} END {print s+0}')
[ "$CH_SUM" -ge 1 ] || {
  echo "FAIL: композит-проба не увидела НИ ОДНОГО изменения кадра (ch сумма=$CH_SUM)"; ok=0; }

# --- 3) пиксельная проверка КОМПОЗИТА (кадр игры, все слои) ---
# Геометрия (fit_blur, 240x320 в 1280x720): вид игры x=370..910, блюр-поля
# по бокам. Бейдж (icon, [BATT-DEBOLT]): плашка 48+2*12=72 =>
# px=1280-72-16=1192, py=8..51; корпус cx=1204, заливка 63% => зелёная.
python3 - "$D/cdump" <<'PYEOF'
import sys, glob, os
d = sys.argv[1]
files = sorted(glob.glob(os.path.join(d, "comp_*.ppm")))
if not files:
    print("FAIL: нет композит-дампов (NOJME_COMPOSITE_DUMP_DIR) — present_game не работал?")
    sys.exit(1)
f = files[-1]  # последний кадр — игра уже нарисовала текст
with open(f, "rb") as fh:
    data = fh.read()
parts = data.split(b"\n", 3)
w, h = map(int, parts[1].split())
assert (w, h) == (1280, 720), (w, h)
px = parts[3]

def pix(x, y):
    o = (y * w + x) * 3
    return (px[o], px[o+1], px[o+2])

ok = True
# (а) вид игры: в игровом прямоугольнике есть НЕ-чёрные пиксели (текст)
game = sum(1 for x in range(380, 900, 8) for y in range(40, 700, 8)
           if pix(x, y) != (0, 0, 0))
if game < 20:
    print("FAIL: вид игры пуст/чёрен (не-чёрных сэмплов %d) — кадр игры не в композите?" % game); ok = False
# (б) блюр-фон: левое поле несёт ОСМЫСЛЕННУЮ картинку (не чёрный, не пустой)
blur = sum(1 for x in range(4, 360, 8) for y in range(4, 716, 16)
           if pix(x, y) != (0, 0, 0))
if blur < 20:
    print("FAIL: блюр-фон пуст/чёрен (сэмплов %d) — фон FIT_BLUR не в композите?" % blur); ok = False
# (в) бейдж: рамка плашки + тёмная подложка + белая рамка корпуса + зелёная
# заливка 63% — РОВНО на тех же пикселях, что и в меню (v36.43 [BATT-GAME])
if pix(1192, 8) != (42, 48, 64):
    print("FAIL: рамка плашки бейджа не на (1192,8): %s" % (pix(1192, 8),)); ok = False
if pix(1194, 30) != (16, 19, 26):
    print("FAIL: подложка плашки не тёмная: %s" % (pix(1194, 30),)); ok = False
if pix(1204, 19) != (232, 236, 244):
    print("FAIL: рамка корпуса значка не на (1204,19): %s" % (pix(1204, 19),)); ok = False
green = any(pix(x, y) == (61, 220, 132)
            for x in range(1206, 1232) for y in range(21, 39))
if not green:
    print("FAIL: в значке нет зелёной заливки 63%"); ok = False
# (г) [BATT-DEBOLT]: чисто-БЕЛЫХ пикселей (255,255,255 — молния) в плашке нет;
# рамка корпуса (232,236,244) — не чистый белый, различима
white = any(pix(x, y) == (255, 255, 255)
            for x in range(1193, 1263) for y in range(9, 51))
if white:
    print("FAIL: в плашке бейджа есть чисто-белые пиксели — молния не удалена?"); ok = False
print(("composite pixels: OK (%s, слои: игра=%d блюр=%d)" % (os.path.basename(f), game, blur))
      if ok else "composite pixels: FAIL")
sys.exit(0 if ok else 1)
PYEOF
[ $? -eq 0 ] || ok=0

grep -ahqi "segfault\|SIGSEGV" $ALL && { echo "FAIL: краш"; ok=0; }

echo ""
if [ "$ok" = "1" ]; then
    echo "BATT-GAME COMPOSITE E2E: ALL PASSED"
else
    echo "BATT-GAME COMPOSITE E2E: FAILED — детали выше"
    exit 1
fi
