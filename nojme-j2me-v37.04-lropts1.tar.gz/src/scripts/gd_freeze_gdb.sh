#!/bin/bash
# Запуск GD-репро в ФОНЕ + ожидание фриза (STUCK в err.log) + gdb-дамп потоков.
# Использование: bash scripts/gd_freeze_gdb.sh <суффикс>
set -u
SUF=${1:-gdb}
D=/tmp/gd_repro_$SUF
cd "$(dirname "$0")/.." || exit 1
rm -rf "$D"; mkdir -p "$D/roms"
cp "/home/z/my-project/gd/Gravity Defied[240x320].jar" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:600"
RIDE="UP:1400,DOWN:500"
FRONT="A:4500,A:3000,A:2600"
for i in 1 2 3 4 5 6 7 8 9 10 11 12; do FRONT="$FRONT,$RIDE"; done
FRONT="$FRONT,UP:3000,DOWN:3000,UP:3000,DOWN:3000"
export NOJME_FRONT_KEYS="$FRONT"
# Базовая линия: фиксы выключены
export NOJME_SPIN_BREAK_MS=0 NOJME_PAINT_LOCK_MS=0
export NOJME_SELF_STACK_EVERY=1

./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" &
PID=$!
echo "PID=$PID — ждём фриз (STUCK в логе)..."
FROZEN=0
for i in $(seq 1 100); do
    sleep 1
    if grep -aq "STUCK:" "$D/err.log" 2>/dev/null; then FROZEN=1; break; fi
    if ! kill -0 $PID 2>/dev/null; then echo "процесс умер"; break; fi
done
if [ "$FROZEN" = "1" ]; then
    echo "=== ФРИЗ ОБНАРУЖЕН — ждём 3с и цепляем gdb ==="
    sleep 3
    gdb -p $PID -batch \
        -ex "set pagination off" \
        -ex "thread apply all bt 25" \
        > "$D/gdb.txt" 2>&1
    echo "gdb done -> $D/gdb.txt"
    # позволяем процессу ещё поработать под фризом для второго дампа
    sleep 3
    kill -9 $PID 2>/dev/null
else
    echo "фриз не пойман за 100с"; kill -9 $PID 2>/dev/null
fi
grep -a "STUCK:\|MON-WAIT" "$D/err.log" | tail -6
