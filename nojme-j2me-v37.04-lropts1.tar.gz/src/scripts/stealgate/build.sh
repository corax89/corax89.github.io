#!/bin/bash
# Build MonStealGateTest.jar — v36.92 [STEAL-GATE] selftest.
# Run:  NOJME_HEADLESS_MAX_MS=180000 timeout 150 ./bin/j2me-headless \
#        scripts/stealgate/MonStealGateTest.jar
# Expect: phase A — NO [MON-STEAL] for the alive (sleep-loop) owner, only
#         [STEAL-GATE] "steal suppressed" lines, then GATE:A-SUPPRESSED-OK
#         (~25 s). Phase B — [MON-STEAL] at 20 s for the silent pure-Java
#         owner, GATE:B-STEAL-OK, GATE:B-IMS-RECOVERED. Then GATE:PHASES-DONE,
#         GATE:DESTROYED, clean exit.
# Pre-v36.92 behavior: GATE:A-FAIL-STOLEN (steal at 20 s into the live owner).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/MonStealGateTest.java" \
    "$D/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: M, , MonStealGateTest\r\nMIDlet-Name: M\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/MonStealGateTest"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/MonStealGateTest.jar" META-INF && zip -q "$D/MonStealGateTest.jar" *.class )
echo "built: $D/MonStealGateTest.jar"
