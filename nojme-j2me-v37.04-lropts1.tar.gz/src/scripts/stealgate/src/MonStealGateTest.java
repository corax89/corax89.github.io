import javax.microedition.midlet.MIDlet;

/**
 * v36.92 [STEAL-GATE] e2e selftest — the Metal Slug 6 monitor-steal family.
 *
 * Field evidence (two logs, same game):
 *   v36.91: ONE at.bl call held the game monitor for 12.5 s while DISPATCHING
 *           natives in bursts every 2.5-5 s (System.arraycopy inside a long
 *           convergent computation). The owner was alive and working.
 *   v36.88: the same computation ran 20.2 s and the UNCONDITIONAL [MON-STEAL]
 *           (20 s) force-released the monitor at the peak, dragging the
 *           waiter INSIDE the owner's synchronized block — game state
 *           corrupted ("зависает/глючит" report).
 *
 * v36.92 policy: steal only from a SILENT owner (no native dispatch for the
 * whole 20 s window: pure-Java infinite spin, wedge inside a never-returning
 * native, or monitor leak after unwind). An owner that keeps dispatching
 * natives (age < 6 s) is doing convergent work — the steal is SUPPRESSED and
 * the waiter keeps waiting. A 90 s backstop force-steals if the owner keeps
 * "working" for that long without ever leaving the block.
 *
 * Phase A — alive owner (gate must SUPPRESS the steal):
 *   ownerA holds LOCK_A for 25 s, dispatching Thread.sleep(100) +
 *   currentTimeMillis every ~100 ms (native age never exceeds ~100 ms).
 *   waiterA blocks on LOCK_A. Pre-v36.92: stolen at 20 s (A-ACQUIRED at
 *   ~20000 ms = FAIL). v36.92: no steal, waiterA acquires only after the
 *   owner exits (~25 s) -> GATE:A-SUPPRESSED-OK.
 *
 * Phase B — silent owner (steal must still FIRE):
 *   ownerB holds LOCK_B and spins in PURE JAVA (a long add-loop, zero
 *   native calls) for ~10M iterations (~30 s on the headless interpreter).
 *   waiterB blocks on LOCK_B; at 20 s the owner's native age exceeds the
 *   threshold while its last_native_ms is ancient -> [MON-STEAL] fires,
 *   waiterB acquires -> GATE:B-STEAL-OK. ownerB's eventual monitorexit on
 *   the STOLEN monitor throws IllegalMonitorStateException — ownerB wraps
 *   its whole body in try/catch and reports GATE:B-IMS-RECOVERED (this
 *   exercises the v36.91 [MON-EXIT-FREE] semantics from the owner side).
 *
 * PASS: GATE:A-SUPPRESSED-OK + GATE:B-STEAL-OK + GATE:B-IMS-RECOVERED +
 * GATE:DESTROYED + clean process exit. Log must contain [STEAL-GATE]
 * suppressed lines (phase A) and [MON-STEAL] (phase B).
 */
public class MonStealGateTest extends MIDlet {
    static final Object LOCK_A = new Object();
    static final Object LOCK_B = new Object();
    volatile boolean aDone = false;
    volatile boolean bDone = false;
    volatile boolean stop = false;

    protected void startApp() {
        /* Phase A: ALIVE owner — sleep loop inside synchronized (natives
         * every ~100 ms). */
        new Thread(new Runnable() { public void run() {
            long t0 = System.currentTimeMillis();
            try {
                synchronized (LOCK_A) {
                    while (System.currentTimeMillis() - t0 < 25000 && !stop) {
                        try { Thread.sleep(100); }
                        catch (InterruptedException ie) {}
                    }
                }
                System.out.println("GATE:A-OWNER-EXIT at " +
                                   (System.currentTimeMillis() - t0));
            } catch (Throwable t) {
                System.out.println("GATE:A-OWNER-THREW " + t);
            }
        }}, "ownerA").start();

        new Thread(new Runnable() { public void run() {
            long t0 = System.currentTimeMillis();
            synchronized (LOCK_A) {
                long waited = System.currentTimeMillis() - t0;
                /* A steal at 20 s would land here at ~20000 ms. */
                if (waited >= 24000) {
                    System.out.println("GATE:A-SUPPRESSED-OK waited=" + waited);
                } else {
                    System.out.println("GATE:A-FAIL-STOLEN waited=" + waited);
                }
            }
            aDone = true;
        }}, "waiterA").start();

        /* Phase B: SILENT owner — pure-Java spin, ZERO natives while held.
         * The whole body is wrapped in try/catch: if [MON-STEAL] released
         * the monitor mid-spin, the block-exit monitorexit throws
         * IllegalMonitorStateException — the catch prints the marker and
         * the thread survives (no IMS loop: single catch, no nested
         * synchronized re-entry). */
        new Thread(new Runnable() { public void run() {
            try {
                synchronized (LOCK_B) {
                    long x = 0;
                    for (long i = 0; i < 10000000L; i++) {
                        x += i * 3;
                    }
                    if (x == 42) System.out.println("GATE:impossible");
                }
                System.out.println("GATE:B-OWNER-EXIT-CLEAN");
            } catch (Throwable t) {
                System.out.println("GATE:B-IMS-RECOVERED " + t.getClass().getName());
            }
        }}, "ownerB").start();

        new Thread(new Runnable() { public void run() {
            long t0 = System.currentTimeMillis();
            synchronized (LOCK_B) {
                System.out.println("GATE:B-STEAL-OK waited=" +
                                   (System.currentTimeMillis() - t0));
            }
            bDone = true;
        }}, "waiterB").start();

        /* Post-steal protocol witness: re-acquire LOCK_B after everything
         * settled and exit cleanly. */
        new Thread(new Runnable() { public void run() {
            try {
                Thread.sleep(30000);
            } catch (InterruptedException ie) { return; }
            long t0 = System.currentTimeMillis();
            synchronized (LOCK_B) {
                System.out.println("GATE:B-REACQUIRED post-steal at " +
                                   (System.currentTimeMillis() - t0));
            }
        }}, "witnessB").start();

        new Thread(new Runnable() { public void run() {
            while (!stop) {
                try { Thread.sleep(500); }
                catch (InterruptedException ie) { return; }
                if (aDone && bDone) {
                    System.out.println("GATE:PHASES-DONE");
                    try { Thread.sleep(3000); }
                    catch (InterruptedException ie) {}
                    notifyDestroyed();
                    return;
                }
            }
        }}, "driver").start();

        System.out.println("GATE: started");
    }

    protected void pauseApp() {}

    protected void destroyApp(boolean unconditional) {
        stop = true;
        System.out.println("GATE:DESTROYED");
    }
}
