/*
 * switch.h — МИНИМАЛЬНЫЙ СТАБ libnx для ЛОКАЛЬНОЙ проверки кода, который
 * виден ТОЛЬКО настоящей devkitPro-сборке (гвард __has_include(<switch.h>)
 * в battery.c / sdl_graphics.c / main.c). Ни headless, ни switchui-verify
 * эти ветки не парсят — именно так в v36.41 ушли на устройство ошибки
 * «psmGetBatteryChargePercentage(s32*)» и «PsmChargerType_None undeclared»:
 * сигнатуры были написаны по памяти, а не по заголовку.
 *
 * Сигнатуры/имена ниже — ДОСЛОВНО из libnx (devkitPro/libnx, libnx
 * Authors; сверено с doxygen-документацией switchbrew.github.io/libnx,
 * файлы psm_8h_source.html и hid_8h_source.html):
 *   psm.h:106  Result psmGetBatteryChargePercentage(u32 *out);
 *   psm.h:112  Result psmGetChargerType(PsmChargerType *out);
 *   hid.h:1595 u32 hidGetNpadStyleSet(HidNpadIdType id);
 *   hid.h:1624 u32 hidGetNpadDeviceType(HidNpadIdType id);
 *
 * Тест: scripts/test_libnx_api.sh (проваливается и на предупреждения).
 * Стаб предназначен только для -fsyntax-only; реализаций нет.
 * При обновлении devkitPro/libnx — сначала сверить этот файл с новыми
 * заголовками, потом править прикладной код.
 */
#ifndef NOJME_LIBNX_STUB_SWITCH_H
#define NOJME_LIBNX_STUB_SWITCH_H

#include <stdint.h>
#include <stdbool.h>

/* --- switch/types.h (необходимый минимум) --- */
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   s8;
typedef int16_t  s16;
typedef int32_t  s32;
typedef int64_t  s64;
typedef u32      Result;

#define BIT(n) (1U << (n))
#define R_SUCCEEDED(res) ((res) == 0)

/* --- switch/services/psm.h (дословно, psm.h:12-18, 94, 106, 112) --- */
Result psmInitialize(void);
void psmExit(void);

typedef enum {
    PsmChargerType_Unconnected = 0,  ///< No charger
    PsmChargerType_EnoughPower = 1,  ///< Full supported power
    PsmChargerType_LowPower = 2,     ///< Lower power supported USB-PD mode
    PsmChargerType_NotSupported = 3, ///< No common supported USB-PD modes
} PsmChargerType;

Result psmGetBatteryChargePercentage(u32 *out);
Result psmGetChargerType(PsmChargerType *out);

/* --- switch/hid.h (дословно, hid.h:213-225, 227-246, 404-424,
 *     1595, 1624; включены только используемые деревом части) --- */

/// HID controller IDs (hid.h:213)
typedef enum {
    HidNpadIdType_No1      = 0,    ///< Player 1 controller
    HidNpadIdType_No2      = 1,    ///< Player 2 controller
    HidNpadIdType_No3      = 2,    ///< Player 3 controller
    HidNpadIdType_No4      = 3,    ///< Player 4 controller
    HidNpadIdType_No5      = 4,    ///< Player 5 controller
    HidNpadIdType_No6      = 5,    ///< Player 6 controller
    HidNpadIdType_No7      = 6,    ///< Player 7 controller
    HidNpadIdType_No8      = 7,    ///< Player 8 controller
    HidNpadIdType_Other    = 0x10, ///< Other controller
    HidNpadIdType_Handheld = 0x20, ///< Handheld mode controls
} HidNpadIdType;

/// HID controller styles (hid.h:227)
typedef enum {
    HidNpadStyleTag_NpadFullKey       = BIT(0),       ///< Pro Controller
    HidNpadStyleTag_NpadHandheld      = BIT(1),       ///< Joy-Con controller in handheld mode
    HidNpadStyleTag_NpadJoyDual       = BIT(2),       ///< Joy-Con controller in dual mode
    HidNpadStyleTag_NpadJoyLeft       = BIT(3),       ///< Joy-Con left controller in single mode
    HidNpadStyleTag_NpadJoyRight      = BIT(4),       ///< Joy-Con right controller in single mode
} HidNpadStyleTag;

/// Device types (hid.h:404, включены используемые биты)
typedef enum {
    HidDeviceTypeBits_FullKey     = BIT(0),  ///< Pro Controller and Gc controller.
    HidDeviceTypeBits_HandheldLeft  = BIT(2), ///< Joy-Con/Famicom/NES left controller in handheld mode.
    HidDeviceTypeBits_HandheldRight = BIT(3), ///< Joy-Con/Famicom/NES right controller in handheld mode.
    HidDeviceTypeBits_JoyLeft     = BIT(4),  ///< Joy-Con left controller.
    HidDeviceTypeBits_JoyRight    = BIT(5),  ///< Joy-Con right controller.
    HidDeviceTypeBits_System      = BIT(31), ///< Generic controller.
} HidDeviceTypeBits;

u32 hidGetNpadStyleSet(HidNpadIdType id);
u32 hidGetNpadDeviceType(HidNpadIdType id);

/* --- switch/kernel/svc.h (svc wrappers used by the app) ---
 * svc.h: Real Result svcSetMemoryPermission(void* addr, u64 size, u32 perm);
 * perm bits: Perm_None=0, Perm_R=BIT(0), Perm_W=BIT(1), Perm_X=BIT(2).
 * Used by threadpool.c [MMAN-GUARD] for the precise pthread-stack guard
 * page (libnx has no <sys/mman.h>/mprotect). */
Result svcSetMemoryPermission(void* addr, u64 size, u32 perm);

#endif /* NOJME_LIBNX_STUB_SWITCH_H */
