/*
 * jar_reader.h — single canonical in-memory JAR/ZIP reader (v19).
 *
 * Replaces the four divergent hand-rolled ZIP scanners that used to live in
 * main.c, jvm.c, libretro/libretro.c and libretro/sdl_backend_stubs.c.
 * Built on miniz; see src/utils/jar_reader.c for the rationale.
 */

#ifndef JAR_READER_H
#define JAR_READER_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Read one file from an in-memory JAR/ZIP image.
 *
 *   jar_data/jar_size  — the JAR image (as loaded into memory)
 *   name               — entry name, e.g. "res/bin/texture.res"
 *   out_size           — receives the exact byte count (may be NULL)
 *
 * Returns a malloc'd buffer of *out_size + 1 bytes (the extra byte is a NUL
 * terminator, not counted in *out_size) or NULL if the archive is not a
 * readable ZIP, the entry is absent, or extraction fails. Free with free().
 *
 * Lookup: exact case-sensitive match first, then a case-insensitive pass
 * (jars repacked on Windows often change letter case).
 */
uint8_t* jar_read_file(const void* jar_data, size_t jar_size,
                       const char* name, size_t* out_size);

#ifdef __cplusplus
}
#endif

#endif /* JAR_READER_H */
