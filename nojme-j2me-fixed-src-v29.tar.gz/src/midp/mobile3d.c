/*
 * J2ME Emulator - JSR 184 Mobile 3D Graphics API (Software Implementation)
 * 
 * This implements the M3G (Mobile 3D Graphics) API in pure software mode.
 * JSR 184 provides a retained-mode 3D graphics API for mobile devices.
 * 
 * Implemented features:
 * - Graphics3D rendering context
 * - Transform (4x4 matrix operations)
 * - VertexArray (vertex data storage)
 * - IndexBuffer (triangle indices)
 * - Mesh (renderable 3D objects)
 * - Camera (view/projection)
 * - Light (directional, point, spot)
 * - Material and Texture2D
 * - Background
 * - World (scene graph)
 * - Software rasterization with Z-buffer
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup */
#endif

#include <stdio.h>
#include "debug.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#if defined(_WIN32)
/* No <pthread.h> on plain MinGW targets — use the Win32 shim */
#include "win_thread_shim.h"
#else
#include <pthread.h>
#endif

/* MinGW build fix: windows.h (pulled in via win_thread_shim.h on MinGW)
 * defines `near` and `far` as EMPTY legacy macros (Win16 pointer keywords).
 * This file uses `near`/`far` as ordinary identifiers (M3G camera plane
 * distances, m3g_transform_perspective parameters), so strip the macros
 * for the rest of this translation unit. Harmless no-op on POSIX builds. */
#undef near
#undef far

/* FIX(mt-race): M3G software-renderer state (g_m3g.* buffers, texture cache,
 * pending-render queue) is shared between the MIDP paint pump (which runs both
 * on the main thread and inside game threads via thread_yield -> repaints)
 * and the game's own Graphics3D calls. Concurrent m3g_context_init() freed
 * color/depth buffers while another thread was rasterizing into them:
 * heap-use-after-free in m3g_rasterize_triangle followed by double free.
 * Serialize the whole pipeline with one RECURSIVE mutex held for the entire
 * public entry point (force_render / bindTarget / releaseTarget / clear /
 * renderWorld / render(node)). Recursive because internal helpers may be
 * invoked again from within an already-held region. */
static pthread_mutex_t g_m3g_pipeline_lock;
static pthread_once_t g_m3g_pipeline_lock_once = PTHREAD_ONCE_INIT;

static pthread_mutex_t g_m3g_ui_lock;
static pthread_once_t g_m3g_ui_once = PTHREAD_ONCE_INIT;
static void m3g_pipeline_lock_init_impl(void);

static void m3g_pipeline_lock_init_impl(void) {
    pthread_mutexattr_t uattr;
    pthread_mutexattr_init(&uattr);
    pthread_mutexattr_settype(&uattr, PTHREAD_MUTEX_RECURSIVE);
#ifdef PTHREAD_PRIO_NONE
    pthread_mutexattr_setprotocol(&uattr, PTHREAD_PRIO_NONE);
#endif
    pthread_mutex_init(&g_m3g_ui_lock, &uattr);
    pthread_mutexattr_destroy(&uattr);

    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    /* FIX(tpp): explicit RECURSIVE + PRIO_NONE. The previous
     * PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP default-initialised mutex was
     * implicated in sporadic glibc "tpp.c:86" assertions when many game
     * threads contended here; explicit PRIO_NONE keeps the kernel out of
     * priority-inheritance bookkeeping entirely. */
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
#ifdef PTHREAD_PRIO_NONE
    pthread_mutexattr_setprotocol(&attr, PTHREAD_PRIO_NONE);
#endif
    pthread_mutex_init(&g_m3g_pipeline_lock, &attr);
    pthread_mutexattr_destroy(&attr);
}

static inline void m3g_pipeline_lock_acquire(void) {
    pthread_once(&g_m3g_pipeline_lock_once, m3g_pipeline_lock_init_impl);
    pthread_mutex_lock(&g_m3g_pipeline_lock);
}

/* FIX(cleanup-semantics) — REAL ROOT CAUSE of the sporadic glibc
 * "Fatal glibc error: tpp.c:86 (__pthread_tpp_change_priority)" abort:
 * GCC's __attribute__((cleanup(fn))) calls fn() with the ADDRESS OF THE
 * GUARD VARIABLE, not with its value. The previous m3g_lock_cleanup()
 * treated that address as the mutex itself, so EVERY M3G entry executed
 * pthread_mutex_unlock() on STACK GARBAGE:
 *   - the real g_m3g_ui_lock was locked and NEVER unlocked (ui depth
 *     counter leaked +1 per call),
 *   - the real g_m3g_pipeline_lock stayed held forever (recursive
 *     re-locks masked it single-threaded),
 *   - the garbage "kind" field occasionally contained priority-
 *     inheritance bits -> glibc tpp.c assertion (ASLR lottery, which is
 *     why -O2 runs looked clean while -O0/ASAN aborted).
 * The guards below now live until the END OF THE ENCLOSING BLOCK and
 * release exactly the mutex they acquired: one balanced unlock per
 * acquired guard, on every exit path, no manual release needed. */
static inline void m3g_guard_release(void* guard_ptr) {
    pthread_mutex_unlock(*(pthread_mutex_t**)guard_ptr);
}

static inline void m3g_ui_lock_count_acquire(void) {
    pthread_once(&g_m3g_ui_once, m3g_pipeline_lock_init_impl);
    pthread_mutex_lock(&g_m3g_ui_lock);
}

#define M3G_PASTE_IMPL(a, b) a##b
#define M3G_PASTE(a, b) M3G_PASTE_IMPL(a, b)

/* --- Shared UI/pipeline ordering --------------------------------------
 * All public render entries must take BOTH locks in the same order
 * (ui -> pipeline) and HOLD them until the end of the enclosing block.
 * Place as FIRST statement of an entry point; the cleanup attributes
 * unlock in reverse order (pipeline, then ui) on every exit path.
 * The repaint pump takes only the UI lock; force_render takes only the
 * pipeline lock but runs exclusively inside a UI owner. Consistent
 * ordering removes cross-thread interleaving windows. */
#define M3G_PIPELINE_LOCK() \
    pthread_mutex_t* M3G_PASTE(_m3g_ui_guard_, __LINE__) \
        __attribute__((cleanup(m3g_guard_release))) = \
        (m3g_ui_lock_count_acquire(), &g_m3g_ui_lock); \
    pthread_mutex_t* M3G_PASTE(_m3g_pipe_guard_, __LINE__) \
        __attribute__((cleanup(m3g_guard_release))) = \
        (m3g_pipeline_lock_acquire(), &g_m3g_pipeline_lock)

#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"  /* For T_* array type constants */
#include "midp.h"     /* For load_jar_resource */
#include "sdl_backend.h"  /* For SdlContext, sdl_get_global_context, get_graphics_from_object */

/* ARM-specific optimization hints for hot-path functions */
#if defined(__ARM_ARCH_7A__) || defined(__arm__)
#define M3G_INLINE __attribute__((always_inline)) static inline
#define M3G_HOT __attribute__((hot))
#else
#define M3G_INLINE static inline
#define M3G_HOT
#endif

/* JSR-184 Light mode constants (as stored in M3G binary files and Java Light class) */
#define M3G_LIGHT_MODE_AMBIENT       128
#define M3G_LIGHT_MODE_DIRECTIONAL   129
#define M3G_LIGHT_MODE_OMNI          130
#define M3G_LIGHT_MODE_SPOT          131

/* Internal light type constants (used by the rasterizer) */
#define M3G_LIGHT_AMBIENT       1
#define M3G_LIGHT_DIRECTIONAL   2  
#define M3G_LIGHT_OMNI          4
#define M3G_LIGHT_SPOT          8

/* Map JSR-184 light mode to internal light type. Accepts the file/API
 * encoding 128..131 AND the stub constant block 0..3 (Light.AMBIENT=0 etc.
 * registered in stubs.c v20). */
static int m3g_light_mode_to_type(int mode) {
    switch (mode) {
        case M3G_LIGHT_MODE_AMBIENT:     return M3G_LIGHT_AMBIENT;
        case M3G_LIGHT_MODE_DIRECTIONAL: return M3G_LIGHT_DIRECTIONAL;
        case M3G_LIGHT_MODE_OMNI:        return M3G_LIGHT_OMNI;
        case M3G_LIGHT_MODE_SPOT:        return M3G_LIGHT_SPOT;
        case 0: return M3G_LIGHT_AMBIENT;     /* stub Light.AMBIENT */
        case 1: return M3G_LIGHT_DIRECTIONAL; /* stub Light.DIRECTIONAL */
        case 2: return M3G_LIGHT_OMNI;        /* stub Light.OMNI */
        case 3: return M3G_LIGHT_SPOT;        /* stub Light.SPOT */
        default: return M3G_LIGHT_DIRECTIONAL; /* fallback */
    }
}

/* ============================================================================
 * HELPER FUNCTIONS FOR FIELD ACCESS
 * ============================================================================ */

/* Find the slot index for a named field in an object.
 * This correctly traverses the class hierarchy from Object down to the actual class,
 * calculating the cumulative slot index for instance fields.
 * Returns -1 if field not found or slot is out of bounds. */
/* v26 PERF (audit item: string field lookup in the hot path): every
 * m3g_get/set_*_field walked the full class hierarchy with strcmp per field.
 * The render path calls this thousands of times per frame for a handful of
 * stable names (translation, vertexBuffer, renderingEnable, ...).
 * Class layouts are immutable after load, so (class, name) -> slot is a pure
 * function: memoized in an insert-only open-addressed table. Insert-only
 * means entries are never overwritten, so the cooperative scheduler (natives
 * are never preempted mid-call) makes races impossible by construction. */
typedef struct {
    JavaClass* clazz;   /* key 1 (NULL = empty slot) */
    const char* name;   /* key 2, verified by strcmp (literals differ per site) */
    int slot;           /* memoized result (may be -1: negative caching OK) */
} M3GFieldSlotCacheEnt;
#define M3G_FIELD_SLOT_CACHE_SIZE 4096
static M3GFieldSlotCacheEnt g_m3g_field_slot_cache[M3G_FIELD_SLOT_CACHE_SIZE];
static unsigned m3g_field_slot_hash(JavaClass* c, const char* n) {
    unsigned h = (unsigned)(uintptr_t)c;
    for (const char* p = n; *p; p++) h = h * 31u + (unsigned char)*p;
    return h;
}

static int m3g_find_field_slot(JavaObject* obj, const char* field_name) {
    if (!obj || !field_name) return -1;

    /* v15 CRITICAL FIX: validate the object is still a live GC object.
     * Native M3G structures (object registry, pending-render queue,
     * cached World/Camera pointers) keep RAW JavaObject* pointers the
     * garbage collector cannot see. After a collection (e.g. the
     * System.gc() in M3GTest's scene switch) these may point to freed
     * and reused memory; dereferencing obj->header.clazz then walks a
     * GARBAGE class pointer (observed: "Field 'vertexBuffer' not found
     * in class ?" followed by a native crash on Windows after the last
     * test scene). Reject dead pointers before any dereference. */
    if (!heap_java_object_valid(obj)) {
        static int dead_obj_warn = 0;
        if (dead_obj_warn < 10) {
            dead_obj_warn++;
            fprintf(stderr, "[M3G-WARN] field lookup '%s' on DEAD object %p (skipped)\n",
                    field_name, (void*)obj);
        }
        return -1;
    }

    JavaClass* clazz = obj->header.clazz;
    if (!clazz) return -1;

    /* v26: memoized lookup — O(1) hit path (hash -> verify key -> return). */
    {
        unsigned h = m3g_field_slot_hash(clazz, field_name) & (M3G_FIELD_SLOT_CACHE_SIZE - 1);
        M3GFieldSlotCacheEnt* e = &g_m3g_field_slot_cache[h];
        if (e->clazz == clazz && e->name && strcmp(e->name, field_name) == 0) {
            return e->slot;
        }
    }

    /* Calculate maximum valid slot from instance_size.
     * Guard against corrupted instance_size that could be smaller than
     * ObjectHeader, which would cause max_slots to go negative (as int). */
    size_t header_size = sizeof(ObjectHeader);
    int max_slots;
    if (clazz->instance_size <= header_size) {
        return -1;  /* Object too small to have any fields */
    }
    max_slots = (int)((clazz->instance_size - header_size) / sizeof(JavaValue));
    if (max_slots <= 0) return -1;

    /* Build class hierarchy from Object to actual class */
    JavaClass* hierarchy[64];
    int depth = 0;
    JavaClass* c = clazz;
    while (c && depth < 64) {
        hierarchy[depth++] = c;
        c = c->super_class;
    }

    /* Search for field and calculate slot from Object down to actual class */
    int slot = 0;
    int found = -1;
    int saw_unresolved = 0;  /* v26: a NULL field name = lazy-resolved class:
                              * a negative result now may turn positive later,
                              * so such walks must NOT be negative-cached. */
    for (int h = depth - 1; h >= 0; h--) {
        JavaClass* current = hierarchy[h];
        if (!current->fields) continue;

        for (int i = 0; i < current->fields_count; i++) {
            JavaField* field = &current->fields[i];

            /* Skip static fields */
            if (field->access_flags & ACC_STATIC) continue;

            if (!field->name) { saw_unresolved = 1; }

            if (field->name && strcmp(field->name, field_name) == 0) {
                /* Validate slot is within bounds */
                if (slot >= max_slots) {
                    GFX_DEBUG("M3G: Field '%s' slot %d exceeds object capacity %d",
                             field_name, slot, max_slots);
                    return -1;
                }
                found = slot;
                break;
            }

            slot++;
            /* Long and double take 2 slots */
            if (field->descriptor &&
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                slot++;
            }
        }
        if (found >= 0) break;
    }

    /* v26: store memo (insert-only; on table-full just skip caching).
     * Unresolved-name walks are never cached (result not final yet). */
    if (!saw_unresolved) {
        unsigned h = m3g_field_slot_hash(clazz, field_name) & (M3G_FIELD_SLOT_CACHE_SIZE - 1);
        M3GFieldSlotCacheEnt* e = &g_m3g_field_slot_cache[h];
        if (!e->clazz) {
            /* Write order matters: name+slot BEFORE clazz (the valid flag),
             * so a concurrent reader can never match the key while the value
             * is still unset. */
            e->name = field_name;
            e->slot = found;
            e->clazz = clazz;
        }
    }

    return found;  /* Field not found (-1) or memoized slot */
}

/* Rate-limited warning for missing fields - max 1 per second per field */
#define M3G_FIELD_WARN_MAX 200
static struct { const char* field; const char* cls; int count; } m3g_field_warns[M3G_FIELD_WARN_MAX];
static int m3g_field_warn_count = 0;

static void m3g_warn_missing_field(const char* field_name, const char* class_name) {
    /* Check if already warned for this class+field combo */
    for (int i = 0; i < m3g_field_warn_count && i < M3G_FIELD_WARN_MAX; i++) {
        if (m3g_field_warns[i].field == field_name && m3g_field_warns[i].cls == class_name) {
            m3g_field_warns[i].count++;
            if (m3g_field_warns[i].count <= 3) {
                fprintf(stderr, "[M3G-WARN] Field '%s' not found in %s (repeat #%d)\n",
                        field_name, class_name ? class_name : "?", m3g_field_warns[i].count);
            }
            return;
        }
    }
    /* First time warning */
    if (m3g_field_warn_count < M3G_FIELD_WARN_MAX) {
        fprintf(stderr, "[M3G-WARN] Field '%s' not found in class %s\n",
                field_name, class_name ? class_name : "?");
        m3g_field_warns[m3g_field_warn_count].field = field_name;
        m3g_field_warns[m3g_field_warn_count].cls = class_name;
        m3g_field_warns[m3g_field_warn_count].count = 1;
        m3g_field_warn_count++;
    }
}

/* Helper to get an int field value by name */
static jint m3g_get_int_field(JavaObject* obj, const char* field_name, jint default_val) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return obj->fields[slot].i;
    }
    m3g_warn_missing_field(field_name, obj && obj->header.clazz ? obj->header.clazz->class_name : NULL);
    return default_val;
}

/* Helper to set an int field value by name */
static void m3g_set_int_field(JavaObject* obj, const char* field_name, jint value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].i = value;
        return;
    }
    m3g_warn_missing_field(field_name, obj && obj->header.clazz ? obj->header.clazz->class_name : NULL);
}

/* Helper to get a float field value by name */
static jfloat m3g_get_float_field(JavaObject* obj, const char* field_name, jfloat default_val) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return obj->fields[slot].f;
    }
    m3g_warn_missing_field(field_name, obj && obj->header.clazz ? obj->header.clazz->class_name : NULL);
    return default_val;
}

/* Helper to set a float field value by name */
static void m3g_set_float_field(JavaObject* obj, const char* field_name, jfloat value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].f = value;
        return;
    }
    m3g_warn_missing_field(field_name, obj && obj->header.clazz ? obj->header.clazz->class_name : NULL);
}

static JavaObject* m3g_registry_get(int i);

/* Helper to get a reference field value by name */
static JavaObject* m3g_get_ref_field(JavaObject* obj, const char* field_name) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        JavaObject* ref = (JavaObject*)obj->fields[slot].ref;
        /* v15 CRITICAL FIX: reject garbage references. Ref slots may hold
         * stale pointers after a GC freed the referenced object (C-side
         * registries keep raw pointers invisible to the collector), or
         * raw values written by partially-initialised parsers. Passing
         * such a pointer to the renderer crashed SU-30 (SEGV in
         * m3g_force_render on World.activeCamera) and is the same
         * use-after-free class seen on M3GTest scene switches. */
        if (ref && !heap_java_object_valid(ref)) {
            static int bad_ref_warns = 0;
            if (bad_ref_warns < 10) {
                bad_ref_warns++;
                fprintf(stderr, "[M3G-WARN] field '%s' returned DEAD ref %p — treating as NULL\n",
                        field_name, (void*)ref);
            }
            return NULL;
        }
        return ref;
    }
    /* v15 DIAG: dump the raw GC header of the object when a lookup fails
     * with an unidentifiable class — identifies dead/reused objects. */
    if (obj && (!obj->header.clazz || !obj->header.clazz->class_name)) {
        static int diag_count = 0;
        if (diag_count < 2) {
            diag_count++;
            GCObjectHeader* gh = ((GCObjectHeader*)obj) - 1;
            fprintf(stderr, "[M3G-DIAG] field '%s' on obj=%p: ObjHdr.clazz=%p GC{magic=0x%08X type=%d size=%u clazz=%p}\n",
                    field_name, (void*)obj, (void*)obj->header.clazz,
                    gh->magic, gh->type, gh->size, (void*)gh->clazz);
            /* hexdump 96 bytes before and 64 after the object header */
            uint8_t* base = (uint8_t*)gh - 96;
            for (int row = 0; row < 10; row++) {
                char line[200]; int pos = 0;
                pos += snprintf(line + pos, sizeof(line) - pos, "[M3G-DIAG]   %p:", (void*)(base + row * 16));
                for (int b = 0; b < 16; b++) {
                    pos += snprintf(line + pos, sizeof(line) - pos, " %02X", base[row * 16 + b]);
                }
                fprintf(stderr, "%s\n", line);
            }
        }
    }
    m3g_warn_missing_field(field_name, obj && obj->header.clazz ? obj->header.clazz->class_name : NULL);
    return NULL;
}

/* Helper to set a reference field value by name */
static void m3g_set_ref_field(JavaObject* obj, const char* field_name, JavaObject* value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].ref = value;
        return;
    }
    m3g_warn_missing_field(field_name, obj && obj->header.clazz ? obj->header.clazz->class_name : NULL);
}

/* ============================================================================
 * M3G Constants (from JSR 184 specification)
 * ============================================================================ */


/* Material components */
#define M3G_MATERIAL_AMBIENT    1
#define M3G_MATERIAL_DIFFUSE    2
#define M3G_MATERIAL_EMISSIVE   4
#define M3G_MATERIAL_SPECULAR   8

/* Rendering hints */
#define M3G_ANTIALIAS           1
#define M3G_DITHER              2
#define M3G_TRUE_COLOR          4

/* Compositing modes */
#define M3G_ALPHA_BLEND         64
#define M3G_ALPHA_ADDITIVE      65
#define M3G_ALPHA_MULTIPLY      66
#define M3G_ALPHA_REPLACE       67

/* Polygon modes */
#define M3G_POLYGON_MODE_SOLID          64
#define M3G_POLYGON_MODE_WIREFRAME      65
#define M3G_POLYGON_MODE_POINT          66
#define M3G_POLYGON_MODE_POINT_SPRITE   67

/* Crop modes */
#define M3G_CROP_CENTER        96
#define M3G_CROP_STRETCH       97
#define M3G_CROP_FILL          98

/* Maximum dimensions for Image2D and render targets to prevent OOM.
 * J2ME M3G typically supports 256x256 or 512x512 textures.
 * Allow up to 1024x1024 for compatibility with newer devices. */
#define M3G_MAX_IMAGE_DIMENSION 1024
#define M3G_MAX_IMAGE_PIXELS (M3G_MAX_IMAGE_DIMENSION * M3G_MAX_IMAGE_DIMENSION)

/* Maximum vertex count for VertexArray to prevent OOM */
#define M3G_MAX_VERTEX_COUNT 65536
#define M3G_MAX_INDEX_COUNT  65536

/* ============================================================================
 * M3G Internal Data Structures
 * ============================================================================ */

/* 4x4 Transformation Matrix (column-major, OpenGL style) */
typedef struct {
    float m[16];  /* Column-major: m[col*4+row] */
} M3GTransform;

/* Vertex data */
typedef struct {
    float* positions;     /* XYZ positions */
    float* normals;       /* XYZ normals (optional) */
    float* texcoords;     /* UV coordinates (optional) */
    uint8_t* colors;      /* RGBA colors (optional) */
    int vertex_count;
    int vertex_stride;    /* Components per vertex */
} M3GVertexArray;

/* Triangle indices */
typedef struct {
    uint16_t* indices;
    int index_count;
    int primitive_type;   /* TRIANGLES=4, LINES=3, POINTS=2 */
} M3GIndexBuffer;

/* Material properties */
typedef struct {
    float ambient[4];     /* RGBA */
    float diffuse[4];
    float specular[4];
    float emissive[4];
    float shininess;
} M3GMaterial;

/* Texture data */
typedef struct {
    uint32_t* pixels;     /* ARGB pixels */
    int width;
    int height;
    int blend_s, blend_t; /* Wrapping mode */
    int filter_level;
    /* v14: cache-refresh bookkeeping — the source Image2D content can change
     * at any time (Image2D.set, releaseTarget into an Image2D target), so
     * each built texture remembers where it came from and the global
     * "image content generation" it was built at. */
    JavaObject* source_image;
    uint32_t generation;
    int blend_color;      /* Texture2D.setBlendColor for FUNC_BLEND (ARGB) */
    int has_uv_transform; /* Texture2D.setTransform applied */
    float uv_transform[16]; /* row-major 4x4 from Texture2D.getTransform */
} M3GTexture2D;

/* Light source */
typedef struct {
    JavaObject* obj;     /* Java Light object that owns this slot */
    int type;             /* AMBIENT, DIRECTIONAL, OMNI, SPOT (internal 1/2/4/8) */
    float color[4];       /* RGBA intensity */
    float direction[4];   /* Local direction (Light.setDirection / explicit dir) */
    float position[4];    /* For omni/spot */
    float attenuation[3]; /* Constant, linear, quadratic */
    float spot_angle;     /* Spot cone angle (degrees) */
    float spot_exponent;
    /* Task 16-a (lighting): per-render evaluated view-space state plus the
     * immediate-mode transform captured by Graphics3D.addLight/setLight. */
    M3GTransform transform; /* World transform given to addLight (immediate mode) */
    int has_transform;      /* 1 = transform valid */
    int g3d_registered;     /* 1 = added via Graphics3D.addLight/setLight */
    float view_pos[3];      /* Evaluated view-space position (omni/spot) */
    float view_dir[3];      /* Evaluated view-space direction (directional/spot) */
} M3GLight;

/* Appearance state */
typedef struct {
    M3GMaterial* material;
    M3GTexture2D* texture;
    int compositing_mode;
    int polygon_mode;
    int layer;
    int winding;              /* 0 = CCW (default), 1 = CW */
    int two_sided_lighting;   /* 0 = one-sided, 1 = two-sided (no culling) */
    int cull_front;           /* 1 = CULL_FRONT (cull front faces), 0 = CULL_BACK */
    int blend_mode;           /* CompositingMode blending, -1 = use default */
    int alpha_threshold;      /* CompositingMode alphaThreshold * 255, -1 = use default */
    int texture_blend;        /* Texture2D blending mode */
    /* Task 16-a: fog / write masks / alpha factor / second texture unit.
     * All defaults keep the previous (v22) unlit, no-fog behavior bit-for-bit. */
    int fog_enabled;          /* 0 = no Fog on this Appearance (default) */
    int fog_mode;             /* internal: 0 = EXPONENTIAL, 1 = LINEAR */
    float fog_density;
    float fog_near;
    float fog_far;
    int fog_color;            /* ARGB */
    int alpha_write;          /* CompositingMode alphaWriteEnable (default 1) */
    int color_write;          /* CompositingMode colorWriteEnable (default 1) */
    float alpha_factor;       /* Node.alphaFactor (default 1.0) */
    M3GTexture2D* texture1;   /* Texture2D unit 1 (modulate), NULL = disabled */
} M3GAppearance;

/* Mesh object */
typedef struct {
    M3GVertexArray* vertices;
    M3GIndexBuffer* indices;
    M3GAppearance* appearance;
    int submesh_count;
} M3GMesh;

/* Camera */
typedef struct {
    float position[3];
    float look_at[3];
    float up[3];
    float fov;            /* Field of view in degrees */
    float aspect;         /* Width / Height */
    float near_plane;
    float far_plane;
    int projection_type;  /* 0=perspective, 1=parallel */
} M3GCamera;

/* Render buffer pool for object reuse - avoids per-frame allocations */
#define M3G_VERTEX_POOL_SIZE (64 * 1024)  /* 64K floats = ~21K vertices */
#define M3G_INDEX_POOL_SIZE (32 * 1024)   /* 32K indices */

typedef struct {
    float* vertex_pool;
    size_t vertex_pool_capacity;  /* in floats */
    size_t vertex_pool_used;
    
    uint16_t* index_pool;
    size_t index_pool_capacity;  /* in indices */
    size_t index_pool_used;
    
    int initialized;
} M3GRenderPool;

/* Rendering context */
typedef struct {
    /* Viewport */
    int viewport_x, viewport_y;
    int viewport_width, viewport_height;
    
    /* Target buffer */
    uint32_t* color_buffer;
    float* depth_buffer;
    int buffer_width, buffer_height;
    int buffers_allocated;  /* Track if buffers are allocated */
    
    /* Target for releaseTarget */
    JavaObject* target_image;       /* Image2D or Graphics Java object */
    MidpGraphics* target_gfx;       /* Native graphics context when target is Graphics */
    int target_is_graphics;         /* 1 if target is a Graphics object, 0 if Image2D */
    
    /* Current transformation */
    M3GTransform modelview;
    M3GTransform projection;
    M3GTransform mvp;     /* ModelView * Projection */
    
    /* Lights (max 8) */
    M3GLight lights[8];
    int light_count;
    float depth_range_near;  /* v24: Graphics3D.setDepthRange */
    float depth_range_far;   /* default 0.0/1.0 -> identity */
    
    /* Global ambient */
    float ambient_light[4];
    
    /* Render states */
    int depth_test_enabled;
    int depth_write_enabled;
    int blending_enabled;
    int culling_enabled;    /* Back-face culling */
    
    /* Render buffer pool */
    M3GRenderPool render_pool;
    
    /* Camera state for setCamera/render(Node,Transform) flow */
    JavaObject* camera;
    M3GTransform camera_transform;     /* Camera's composite transform (world space) */
    M3GTransform camera_inverse;       /* Inverse of camera transform (view matrix) */
    int camera_set;                    /* Flag: camera has been set via setCamera */
    
    /* Statistics */
    int triangles_rendered;
    int vertices_processed;
} M3GContext;

/* Global M3G context */
static M3GContext g_m3g;

/* Task 16-a (lighting): per-render light list evaluated during scene
 * traversal. Kept separate from g_m3g.lights (the immediate-mode
 * registration slots) so that render(World) can seed it from
 * Graphics3D.addLight/setLight registrations and then append the Light
 * nodes found in the world graph without double counting.
 * With count == 0 the rasterizer takes the legacy unlit path untouched
 * (byte-identical output — Nescube/M3GTest regression guard). */
#define M3G_MAX_ACTIVE_LIGHTS 8
static M3GLight g_m3g_active_lights[M3G_MAX_ACTIVE_LIGHTS];
static int g_m3g_active_light_count = 0;

/* Task 16-a (lighting): the modelview (object -> view) matrix of the mesh
 * currently being rendered. m3g_render_single_mesh only receives the full
 * MVP, but Gouraud lighting needs eye-space positions/normals, so every
 * render entry stores the pre-projection modelview here. */
static M3GTransform g_m3g_current_modelview;

/* Force-render tracking: some games (SU-30) do M3G scene setup
 * (setCamera, setActiveCamera, etc.) from a game thread, then call
 * repaint()/serviceRepaints() from paint(). But the actual bindTarget/render/
 * releaseTarget calls never happen - the game expects the emulator to handle
 * rendering of the scene graph.
 *
 * These flags are NOT reset per-paint. They track global M3G state.
 * When the game calls bindTarget/render, g_m3g_bindtarget_called is set,
 * which suppresses force-rendering. Otherwise, if scene setup was done but
 * no render happened, we force a render after the next paint() call.
 *
 * NOTE: volatile ensures compiler doesn't cache values in registers, but
 * does NOT provide atomicity or memory ordering. This is acceptable here
 * because: (a) the worst case is one extra/missed force-render, (b) the
 * game thread and paint thread are synchronized by the JVM's repaint queue.
 * __atomic_thread_fence provides the required memory ordering guarantee. */
static volatile bool g_m3g_scene_setup_done = false;   /* setCamera/setActiveCamera called */
static volatile bool g_m3g_bindtarget_called = false;   /* bindTarget called (suppresses force-render) */

/* v29: true while a Graphics3D bind/release cycle is open (target bound).
 * Read by the presenters (headless snapshot / libretro end_frame) to skip
 * mid-frame canvas states ("background -> 3D -> background" flicker). */
volatile int g_m3g_target_bound_flag = 0;
static volatile bool g_m3g_render_done = false;       /* render() called this frame */
static JavaObject* g_m3g_last_world = NULL;             /* Last World set via setActiveCamera */

/* Pending render queue: records render(Node, Transform) calls when bindTarget
 * hasn't been called. During force-render, these are replayed with proper
 * transforms instead of scanning the registry with identity modelview. */
#define M3G_MAX_PENDING_RENDERS 64
typedef struct {
    JavaObject* node;
    JavaObject* transform;  /* Java Transform object - matrix stored as float[16] */
} M3GPendingRender;
static M3GPendingRender g_m3g_pending_renders[M3G_MAX_PENDING_RENDERS];
static volatile int g_m3g_pending_render_count = 0;

/* Memory barrier helper for cross-thread flag visibility.
 * Ensures writes to M3G state (world, camera) are visible to the paint thread. */
static inline void m3g_thread_fence(void) {
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
}

/* Reset force-render tracking at start of each paint() cycle.
 * Only resets the per-frame render flags, NOT the scene setup flag. */
void m3g_reset_paint_tracking(void) {
    g_m3g_bindtarget_called = false;
    g_m3g_render_done = false;
    g_m3g_pending_render_count = 0;  /* Clear stale pending renders each frame */
    m3g_thread_fence();
}

/* Forward declarations needed by m3g_replay_pending_render (defined here,
 * but the actual functions are defined later in the file). */
static void m3g_transform_multiply(M3GTransform* result, const M3GTransform* a, const M3GTransform* b);
static void m3g_read_java_transform(JavaObject* transform, M3GTransform* out);
static void m3g_build_node_transform(JavaObject* node, M3GTransform* out);
static void m3g_render_mesh_with_mvp(JVM* jvm, JavaObject* mesh, M3GTransform* modelview);
static void m3g_render_sprite3d(JVM* jvm, JavaObject* sprite, const M3GTransform* mvp);

/* v26 FIX (audit item: hardcoded traversal depth): the old implementation
 * hand-rolled nested loops that only reached Group > Group > Mesh (3 levels);
 * deeper scene graphs were silently truncated (inner Groups + their meshes
 * invisible in the force-render path). Replaced with true recursion of
 * arbitrary depth. Semantics preserved for the depths the old code handled:
 *   Mesh      : view = camera_inverse * parent_tf * node_transform
 *   Group/World: parent_tf' = parent_tf * group_node_transform, recurse.
 * Children that are neither Mesh nor Group/World (Sprite3D, Light, Camera)
 * are skipped exactly as before — this is the replay path, not the main
 * renderer (m3g_render_node_recursive handles the full node set). */
static void m3g_replay_render_node(JVM* jvm, JavaObject* node, const M3GTransform* parent_tf);

static void m3g_replay_pending_render(JVM* jvm, JavaObject* node, JavaObject* transform) {
    if (!node) return;
    /* v15: pending renders may reference nodes the GC freed while the
     * render call sat in the queue (bindTarget never arrived). */
    if (!heap_java_object_valid(node)) {
        fprintf(stderr, "[M3G] replay_pending_render: node %p is DEAD (GC'd), skipped\n", (void*)node);
        return;
    }

    M3GTransform input_transform;
    m3g_read_java_transform(transform, &input_transform);

    /* v26: recurse at ANY Group depth (was: 2 nested for-loops = depth 3 max) */
    m3g_replay_render_node(jvm, node, &input_transform);
}

static void m3g_replay_render_node(JVM* jvm, JavaObject* node, const M3GTransform* parent_tf) {
    if (!node || !heap_java_object_valid(node)) return;
    JavaClass* clazz = node->header.clazz;
    if (!clazz || !clazz->class_name) return;
    const char* class_name = clazz->class_name;

    if (strstr(class_name, "Sprite3D") != NULL) {
        /* v29 FIX (Brick Breaker paddle): render(Node, Transform) silently
         * dropped Sprite3D nodes — the game's paddle is a Sprite3D rendered
         * per-node, so it never appeared. Same view composition as Mesh:
         * mvp = projection * (camera_inverse * (parent_tf * node_transform)). */
        int render_enable = m3g_get_int_field(node, "renderingEnable", 1);
        if (render_enable) {
            M3GTransform node_transform, full_modelview, view, mvp;
            m3g_build_node_transform(node, &node_transform);
            m3g_transform_multiply(&full_modelview, parent_tf, &node_transform);
            m3g_transform_multiply(&view, &g_m3g.camera_inverse, &full_modelview);
            m3g_transform_multiply(&mvp, &g_m3g.projection, &view);
            m3g_render_sprite3d(jvm, node, &mvp);
        }
        return;
    }

    if (strstr(class_name, "Mesh") != NULL) {
        int render_enable = m3g_get_int_field(node, "renderingEnable", 1);
        if (render_enable) {
            M3GTransform node_transform, full_modelview;
            m3g_build_node_transform(node, &node_transform);
            m3g_transform_multiply(&full_modelview, parent_tf, &node_transform);
            M3GTransform view;
            m3g_transform_multiply(&view, &g_m3g.camera_inverse, &full_modelview);
            m3g_render_mesh_with_mvp(jvm, node, &view);
        }
        return;
    }

    if (strstr(class_name, "Group") != NULL || strstr(class_name, "World") != NULL) {
        JavaArray* children = (JavaArray*)m3g_get_ref_field(node, "children");
        if (!children || children->length <= 0 || children->element_type != DESC_OBJECT) return;
        JavaObject** child_arr = (JavaObject**)array_data(children);
        /* v10 semantics kept: iterate the FULL array (childCount is not
         * maintained by addChild); NULLs are skipped. */
        for (jsize c = 0; c < children->length; c++) {
            JavaObject* child = child_arr[c];
            if (!child || !child->header.clazz || !child->header.clazz->class_name) continue;
            const char* child_name = child->header.clazz->class_name;
            /* v29 FIX: Sprite3D children are renderable leaves — previously the
             * filter dropped them here too (paddle inside a Group never drew). */
            if (strstr(child_name, "Mesh") == NULL &&
                strstr(child_name, "Group") == NULL &&
                strstr(child_name, "World") == NULL &&
                strstr(child_name, "Sprite3D") == NULL) {
                continue;
            }
            M3GTransform child_transform, combined;
            m3g_build_node_transform(child, &child_transform);
            m3g_transform_multiply(&combined, parent_tf, &child_transform);
            /* Recurse — arbitrary depth; recursion bounded by scene graph
             * height (games: <= 8); a corrupt cyclic graph would only be
             * truncated by the render pool, same as the main renderer. */
            m3g_replay_render_node(jvm, child, &combined);
        }
    }
}

/* Check if M3G scene was set up but not rendered - caller should force render.
 * This works even when the scene setup happens from a game thread while
 * paint() only draws 2D overlay. */
bool m3g_needs_force_render(void) {
    return g_m3g_scene_setup_done && !g_m3g_bindtarget_called && !g_m3g_render_done;
}

/* Forward declarations for force-render (defined after rasterizer) */
static void m3g_context_init(int width, int height);
static void m3g_seed_color_buffer_from_gfx(void);
static void m3g_clear_ex(float r, float g, float b, float a, float depth,
                         int clear_color, int clear_depth);
static void m3g_render_pool_reset(void);
static void m3g_transform_identity(M3GTransform* t);
static void m3g_transform_look_at(M3GTransform* t,
                                   float eye_x, float eye_y, float eye_z,
                                   float at_x, float at_y, float at_z,
                                   float up_x, float up_y, float up_z);
static void m3g_transform_point(float* result, const M3GTransform* t, const float* v);
static void m3g_render_node_recursive(JVM* jvm, JavaObject* node, M3GTransform* parent_modelview);
static void m3g_transform_from_rowmajor(M3GTransform* out, const float* rowmajor);
static void m3g_transform_perspective(M3GTransform* t, float fov, float aspect, float near, float far);
static void m3g_render_single_mesh(JVM* jvm, JavaObject* mesh, M3GTransform* mvp);
/* m3g_transform_multiply, m3g_render_mesh_with_mvp, m3g_build_node_transform,
 * m3g_read_java_transform — forward-declared above (before m3g_replay_pending_render) */

/* Forward declaration for M3G Object Registry (defined later in file) */
typedef struct {
    JavaObject* objects[4096];
    int userIDs[4096];
    int count;
} M3GObjectRegistry;
extern M3GObjectRegistry g_m3g_registry;

/* C-side Texture2D -> Image2D mapping.
 * The Texture2D Java class from the game JAR may not have an 'image' or 'imageRef'
 * field (or the fields have obfuscated names), so Java field lookup silently fails.
 * This table stores the mapping directly from the M3G file parser, bypassing the
 * Java field mechanism entirely. */
#define M3G_MAX_TEX_IMAGE_MAPS 256
typedef struct {
    JavaObject* texture_obj;   /* Texture2D Java object */
    JavaObject* image_obj;     /* Image2D Java object (resolved during linking) */
    uint32_t image_ref;        /* M3G image reference ID (set during parsing) */
} M3GTexImageMap;
static M3GTexImageMap g_m3g_tex_image_map[M3G_MAX_TEX_IMAGE_MAPS];
static int g_m3g_tex_image_map_count = 0;

/* Texture build cache — avoid rebuilding the same texture every frame.
 * Keyed by Texture2D object pointer. Each entry holds a fully-built M3GTexture2D. */
#define M3G_MAX_TEXTURE_CACHE 64
typedef struct {
    JavaObject* texture_obj;   /* Texture2D Java object (cache key) */
    M3GTexture2D* built_tex;   /* Built native texture (NULL if build failed) */
    int build_attempted;       /* 1 if we tried building (even if failed) */
} M3GTextureCacheEntry;
static M3GTextureCacheEntry g_m3g_texture_cache[M3G_MAX_TEXTURE_CACHE];
static int g_m3g_texture_cache_count = 0;

/* Clear texture cache when a new M3G file is loaded */
static void m3g_clear_texture_cache(void) {
    for (int i = 0; i < g_m3g_texture_cache_count; i++) {
        if (g_m3g_texture_cache[i].built_tex) {
            if (g_m3g_texture_cache[i].built_tex->pixels)
                free(g_m3g_texture_cache[i].built_tex->pixels);
            free(g_m3g_texture_cache[i].built_tex);
        }
    }
    g_m3g_texture_cache_count = 0;
}

/* Look up a built texture from the cache */
static M3GTexture2D* m3g_lookup_texture_cache(JavaObject* texture_obj) {
    for (int i = 0; i < g_m3g_texture_cache_count; i++) {
        if (g_m3g_texture_cache[i].texture_obj == texture_obj) {
            return g_m3g_texture_cache[i].built_tex;
        }
    }
    return NULL;
}

/* Store a built texture in the cache */
static void m3g_store_texture_cache(JavaObject* texture_obj, M3GTexture2D* built_tex) {
    for (int i = 0; i < g_m3g_texture_cache_count; i++) {
        if (g_m3g_texture_cache[i].texture_obj == texture_obj) {
            g_m3g_texture_cache[i].built_tex = built_tex;
            g_m3g_texture_cache[i].build_attempted = 1;
            return;
        }
    }
    if (g_m3g_texture_cache_count < M3G_MAX_TEXTURE_CACHE) {
        g_m3g_texture_cache[g_m3g_texture_cache_count].texture_obj = texture_obj;
        g_m3g_texture_cache[g_m3g_texture_cache_count].built_tex = built_tex;
        g_m3g_texture_cache[g_m3g_texture_cache_count].build_attempted = 1;
        g_m3g_texture_cache_count++;
    } else {
        /* v26 FIX (audit item: cache overflow degraded to per-frame rebuilds):
         * with the table full every NEW texture missed forever and its pixels
         * were re-copied/re-converted EVERY frame (visible as FPS collapse in
         * games that spawn many Texture2D at runtime). Round-robin replacement
         * keeps 64 entries always cached — worst case (alive textures > 64)
         * degenerates to the old behavior only for the evicted slot. */
        static int rr_next = 0;
        M3GTextureCacheEntry* e = &g_m3g_texture_cache[rr_next % M3G_MAX_TEXTURE_CACHE];
        rr_next++;
        e->texture_obj = texture_obj;
        e->built_tex = built_tex;
        e->build_attempted = 1;
    }
}

/* Check if we already attempted building this texture (even if it failed) */
static int m3g_texture_build_attempted(JavaObject* texture_obj) {
    for (int i = 0; i < g_m3g_texture_cache_count; i++) {
        if (g_m3g_texture_cache[i].texture_obj == texture_obj) {
            return g_m3g_texture_cache[i].build_attempted;
        }
    }
    return 0;
}

/* ==========================================================================
 * v14: Image2D content generation tracking.
 * Mutable Image2D content changes at runtime (Image2D.set per frame in
 * Nescube, releaseTarget rendering into an Image2D). The texture cache used
 * to build each Texture2D exactly ONCE, freezing the first (usually black)
 * frame content forever. A global generation counter is bumped whenever an
 * Image2D changes; m3g_build_texture2d re-copies pixels from the source
 * image when the cached texture was built at an older generation.
 * ======================================================================== */
static uint32_t g_m3g_tex_generation = 1;

/* Forward declaration (defined below, near the texture build) */
static void m3g_refresh_cached_textures_for_image(JavaObject* image);

/* Called by native_image2d_set and releaseTarget(Image2D) after the pixel
 * content of an Image2D object changed. */
static void m3g_mark_image2d_updated(JavaObject* image) {
    if (!image) return;
    g_m3g_tex_generation++;
    m3g_thread_fence();
    m3g_refresh_cached_textures_for_image(image);
}

/* C-side texture-image mapping functions */
__attribute__((unused))
static void m3g_store_tex_image_ref(JavaObject* texture_obj, uint32_t image_ref) {
    if (!texture_obj) return;
    if (g_m3g_tex_image_map_count >= M3G_MAX_TEX_IMAGE_MAPS) return;
    for (int i = 0; i < g_m3g_tex_image_map_count; i++) {
        if (g_m3g_tex_image_map[i].texture_obj == texture_obj) {
            g_m3g_tex_image_map[i].image_ref = image_ref;
            return;
        }
    }
    g_m3g_tex_image_map[g_m3g_tex_image_map_count].texture_obj = texture_obj;
    g_m3g_tex_image_map[g_m3g_tex_image_map_count].image_obj = NULL;
    g_m3g_tex_image_map[g_m3g_tex_image_map_count].image_ref = image_ref;
    g_m3g_tex_image_map_count++;
}

/* Resolve deferred image references after all M3G objects are parsed */
__attribute__((unused)) static void m3g_resolve_tex_image_refs(JavaObject** objects, int object_count) {
    for (int i = 0; i < g_m3g_tex_image_map_count; i++) {
        if (g_m3g_tex_image_map[i].image_obj) continue;
        uint32_t ref = g_m3g_tex_image_map[i].image_ref;
        if (ref > 0) {
            int idx = (int)ref - 2;
            if (idx >= 0 && idx < object_count && objects[idx]) {
                g_m3g_tex_image_map[i].image_obj = objects[idx];
            } else {
                for (int r = 0; r < g_m3g_registry.count; r++) {
                    if (g_m3g_registry.userIDs[r] == (int)ref) {
                        g_m3g_tex_image_map[i].image_obj = m3g_registry_get(r);
                        break;
                    }
                }
            }
            if (g_m3g_tex_image_map[i].image_obj) {
                fprintf(stderr, "[M3G-TEX-RESOLVE] Texture2D %p -> Image2D %p (ref=%u)\n",
                        (void*)g_m3g_tex_image_map[i].texture_obj,
                        (void*)g_m3g_tex_image_map[i].image_obj, ref);
            }
        }
    }
}

/* Store a resolved Texture2D -> Image2D mapping */
static void m3g_store_tex_image_map(JavaObject* texture_obj, JavaObject* image_obj) {
    if (!texture_obj || !image_obj) return;
    if (g_m3g_tex_image_map_count >= M3G_MAX_TEX_IMAGE_MAPS) return;
    for (int i = 0; i < g_m3g_tex_image_map_count; i++) {
        if (g_m3g_tex_image_map[i].texture_obj == texture_obj) {
            g_m3g_tex_image_map[i].image_obj = image_obj;
            return;
        }
    }
    g_m3g_tex_image_map[g_m3g_tex_image_map_count].texture_obj = texture_obj;
    g_m3g_tex_image_map[g_m3g_tex_image_map_count].image_obj = image_obj;
    g_m3g_tex_image_map[g_m3g_tex_image_map_count].image_ref = 0;
    g_m3g_tex_image_map_count++;
}

/* Look up the Image2D for a Texture2D from the C-side mapping */
static JavaObject* m3g_lookup_tex_image(JavaObject* texture_obj) {
    if (!texture_obj) return NULL;
    for (int i = 0; i < g_m3g_tex_image_map_count; i++) {
        if (g_m3g_tex_image_map[i].texture_obj == texture_obj) {
            return g_m3g_tex_image_map[i].image_obj;
        }
    }
    return NULL;
}

/* Clear the texture-image mapping (called when loading a new M3G file) */
static void m3g_clear_tex_image_map(void) {
    g_m3g_tex_image_map_count = 0;
}

/* Force-render the last M3G world onto the screen framebuffer.
 * Called from midp_process_repaints() after paint() when the game
 * did scene setup but never called bindTarget/render/releaseTarget. */
void m3g_force_render(JVM* jvm, MidpGraphics* screen_gfx) {
    M3G_PIPELINE_LOCK();
    if (!g_m3g_scene_setup_done || g_m3g_bindtarget_called) return;
    if (!g_m3g_last_world || !screen_gfx || !screen_gfx->pixels) return;

    /* v15 CRITICAL FIX: the cached World is a raw pointer the GC cannot
     * see. If the game dropped it and a collection ran (M3GTest calls
     * System.gc() on every scene switch), the pointer dangles — drawing
     * through it dereferences reused memory and crashes on Windows.
     * Drop the whole force-render scene instead of crashing. */
    if (!heap_java_object_valid(g_m3g_last_world)) {
        fprintf(stderr, "[M3G] Force-render: cached World %p is DEAD (GC'd), clearing force-render state\n",
                (void*)g_m3g_last_world);
        g_m3g_last_world = NULL;
        g_m3g_scene_setup_done = false;
        return;
    }

    LOG_SAFE( "[M3G] Force-rendering World %p (game didn't call bindTarget)\n", 
            (void*)g_m3g_last_world);
    
    /* DON'T reset scene_done here — let force-render repeat every frame
     * until the game calls bindTarget (which sets bindtarget_called=true
     * and suppresses force-render via m3g_needs_force_render).
     * Previously resetting here caused force-render to run only once,
     * missing subsequent transform updates from the game. */
    /* g_m3g_scene_setup_done = false; */
    
    /* Initialize M3G context for screen rendering */
    m3g_context_init(screen_gfx->width, screen_gfx->height);
    if (!g_m3g.buffers_allocated) return;
    
    /* Reset render pool for this frame to prevent pool exhaustion across
     * multiple force-render calls (the pool is never reset otherwise,
     * causing OOM when large M3G files are force-rendered repeatedly). */
    m3g_render_pool_reset();
    
    g_m3g.target_gfx = screen_gfx;
    g_m3g.target_is_graphics = 1;

    /* v25: start the 3D buffer from the canvas content (2D bg survives) */
    m3g_seed_color_buffer_from_gfx();
    
    /* FIX: Enable depth testing for force-render. The m3g_context_init resets
     * render states to defaults, but we need to ensure depth test and write
     * are enabled for correct 3D rendering. Previously, some code paths
     * (e.g., in Appearance processing) might disable depth testing. */
    g_m3g.depth_test_enabled = 1;
    g_m3g.depth_write_enabled = 1;
    
    /* FIX 30: Set viewport to full screen BEFORE recomputing projection */
    g_m3g.viewport_x = 0;
    g_m3g.viewport_y = 0;
    g_m3g.viewport_width = screen_gfx->width;
    g_m3g.viewport_height = screen_gfx->height;
    
    /* FIX 30: Recompute projection with CORRECT viewport aspect ratio.
     * The game called setPerspective(fov, 0, near, far) with aspect=0,
     * and setCamera used aspect=1.0 (fallback). Now that we have the real
     * viewport dimensions, recompute projection for correct FOV scaling.
     * Also prefer World's activeCamera over g_m3g.camera (which is NULL
     * when the game uses World.setActiveCamera() instead of G3D.setCamera()). */
    {
        float correct_aspect = (float)screen_gfx->width / (float)screen_gfx->height;
        /* Check if current projection has wrong aspect (identity-like or aspect=1.0) */
        float cur_m0 = g_m3g.projection.m[0];
        float cur_m5 = g_m3g.projection.m[5];
        int is_identity_like = (fabsf(cur_m0 - 1.0f) < 0.01f && fabsf(cur_m5 - 1.0f) < 0.01f);
        if (is_identity_like || cur_m0 <= 0.0f) {
            /* Projection is identity or wrong - recompute with correct aspect */
            float fov = 60.0f, near = 1.0f, far = 1000.0f;
            /* FIX 33: Try World's activeCamera first, then g_m3g.camera fallback */
            JavaObject* cam = m3g_get_ref_field(g_m3g_last_world, "activeCamera");
            if (!cam) cam = g_m3g.camera;
            if (cam) {
                fov = m3g_get_float_field(cam, "fov", 60.0f);
                near = m3g_get_float_field(cam, "near", 1.0f);
                far = m3g_get_float_field(cam, "far", 1000.0f);
            }
            m3g_transform_perspective(&g_m3g.projection, fov, correct_aspect, near, far);
            fprintf(stderr, "[M3G-FORCE] Recomputed projection: fov=%.1f aspect=%.2f near=%.1f far=%.1f\n",
                    fov, correct_aspect, near, far);
        }
    }
    
    /* Get background color from World */
    JavaObject* background = m3g_get_ref_field(g_m3g_last_world, "background");
    if (!background) {
        /* v20 FIX (JSR-184 §World.render / Graphics3D.render(World)): if the
         * World has NO Background, the buffer is NOT cleared — the previous
         * frame's contents stay (games rely on painting every pixel or on
         * additively stacked retained renders). */
        /* fall through: no clear, keep old framebuffer + depth */
    } else {
    float bg_r = 0.0f, bg_g = 0.0f, bg_b = 0.0f, bg_a = 1.0f;
    int cc_enable = 1, dc_enable = 1;
    {
        int clear_color = m3g_get_int_field(background, "clearColor", 0xFF000000);
        bg_a = ((clear_color >> 24) & 0xFF) / 255.0f;
        bg_r = ((clear_color >> 16) & 0xFF) / 255.0f;
        bg_g = ((clear_color >> 8) & 0xFF) / 255.0f;
        bg_b = (clear_color & 0xFF) / 255.0f;
        cc_enable = m3g_get_int_field(background, "colorClearEnable", 1) != 0;
        dc_enable = m3g_get_int_field(background, "depthClearEnable", 1) != 0;
    }
    m3g_clear_ex(bg_r, bg_g, bg_b, bg_a, 1.0f, cc_enable, dc_enable);
    }
    
    /* FIX 36: Render Background image as fullscreen quad (sky/ground).
     * M3G Background can have an image that should be displayed behind the 3D scene.
     * Previously we only used Background.clearColor for clearing, ignoring the image.
     * Many games (including SU-30) store the sky/ground texture in Background.image.
     * We blit it directly to the framebuffer as a fullscreen image. */
    if (background) {
        JavaObject* bg_image = m3g_get_ref_field(background, "image");
        if (bg_image) {
            int bg_width = m3g_get_int_field(bg_image, "width", 0);
            int bg_height = m3g_get_int_field(bg_image, "height", 0);
            JavaArray* bg_pixels = (JavaArray*)m3g_get_ref_field(bg_image, "pixels");
            
            if (bg_width > 0 && bg_height > 0 && bg_pixels &&
                bg_pixels->element_type == T_INT &&
                (int)bg_pixels->length >= bg_width * bg_height) {
                
                /* Blit background image stretched to fill the framebuffer.
                 * Use nearest-neighbor sampling for pixel-perfect scaling. */
                jint* src_px = (jint*)array_data(bg_pixels);
                int fb_w = g_m3g.buffer_width;
                int fb_h = g_m3g.buffer_height;
                uint32_t* dst = g_m3g.color_buffer;
                
                for (int py = 0; py < fb_h; py++) {
                    int src_y = (py * bg_height) / fb_h;
                    if (src_y >= bg_height) src_y = bg_height - 1;
                    int src_row_off = src_y * bg_width;
                    int dst_row_off = py * fb_w;
                    
                    for (int px = 0; px < fb_w; px++) {
                        int src_x = (px * bg_width) / fb_w;
                        if (src_x >= bg_width) src_x = bg_width - 1;
                        uint32_t pixel = (uint32_t)src_px[src_row_off + src_x];
                        /* Skip fully transparent pixels */
                        if ((pixel >> 24) != 0) {
                            dst[dst_row_off + px] = pixel;
                        }
                    }
                }
                fprintf(stderr, "[M3G-BG] Rendered background image %dx%d -> %dx%d framebuffer\n",
                        bg_width, bg_height, fb_w, fb_h);
            } else {
                fprintf(stderr, "[M3G-BG] Background image has invalid params: %dx%d pixels=%p len=%d\n",
                        bg_width, bg_height, (void*)bg_pixels,
                        bg_pixels ? (int)bg_pixels->length : -1);
            }
        }
    }
    
    /* DIAG: Log World's class hierarchy and field layout for debugging */
    {
        JavaObject* w = g_m3g_last_world;
        if (w && w->header.clazz) {
            JavaClass* wc = w->header.clazz;
            int max_slots_w = (int)((wc->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue));
            fprintf(stderr, "[M3G-FORCE-DIAG] World class=%s instance_size=%zu max_slots=%d fields_count=%d\n",
                    wc->class_name ? wc->class_name : "?", wc->instance_size, max_slots_w,
                    wc->fields_count);
            /* Dump all fields in hierarchy to find children slot */
            JavaClass* chain[64]; int depth_w = 0;
            JavaClass* cc = wc;
            while (cc && depth_w < 64) { chain[depth_w++] = cc; cc = cc->super_class; }
            int slot_w = 0;
            for (int h = depth_w - 1; h >= 0; h--) {
                JavaClass* cur = chain[h];
                if (!cur->fields) continue;
                for (int i = 0; i < cur->fields_count; i++) {
                    JavaField* f = &cur->fields[i];
                    if (f->access_flags & ACC_STATIC) continue;
                    if (f->name) {
                        fprintf(stderr, "[M3G-FORCE-DIAG]   slot %d: %s %s (ref=%p)\n",
                                slot_w, f->name, f->descriptor ? f->descriptor : "?",
                                (void*)w->fields[slot_w].ref);
                    }
                    slot_w++;
                    if (f->descriptor && (f->descriptor[0] == 'J' || f->descriptor[0] == 'D')) slot_w++;
                }
            }
        }
    }

    /* Set up camera from World */
    float cam_near_val = 1.0f, cam_far_val = 1000.0f; /* corrected values */
    JavaObject* camera = m3g_get_ref_field(g_m3g_last_world, "activeCamera");
    if (camera) {
        float fov = m3g_get_float_field(camera, "fov", 0.0f);
        float aspect = (float)screen_gfx->width / (float)screen_gfx->height;
        float near = m3g_get_float_field(camera, "near", 0.0f);
        float far = m3g_get_float_field(camera, "far", 0.0f);
        int proj_type = m3g_get_int_field(camera, "projectionType", 48);
        
        /* FIX 34: Many games set camera params lazily (after first frame).
         * When fov/near/far are all 0, the camera hasn't been configured yet.
         * Use sensible defaults instead of producing NaN projections. */
        if (fov <= 0.0f || fov > 170.0f) fov = 60.0f;  /* reject garbage fov */
        if (near <= 0.0f) near = 1.0f;
        if (far <= near) far = 1000.0f;
        cam_near_val = near; cam_far_val = far; /* save corrected */
        
        if (proj_type == 48) { /* GENERIC */
            /* FIX: Read generic projection matrix from "genericMatrix" field,
             * NOT from "transform" field. The "transform" field stores the
             * camera's world-space position/orientation (Node transform),
             * while "genericMatrix" stores the 4x4 projection matrix.
             * Previously we read "transform" and used it as projection,
             * causing wildly wrong projection (since it's the camera's
             * world position, not a projection matrix). */
            JavaArray* gen_matrix = (JavaArray*)m3g_get_ref_field(camera, "genericMatrix");
            if (gen_matrix && gen_matrix->element_type == T_FLOAT && gen_matrix->length >= 16) {
                float* gm = (float*)array_data(gen_matrix);
                /* Generic matrix from M3G file is row-major; convert to column-major */
                m3g_transform_from_rowmajor(&g_m3g.projection, gm);
                fprintf(stderr, "[M3G-FORCE] Using generic projection matrix from camera\n");
                /* For generic projection, compute fov from the matrix for logging */
                if (fabsf(gm[0]) > 0.001f) {
                    float implied_fov = 2.0f * atanf(1.0f / gm[0]) * 57.2958f;
                    fprintf(stderr, "[M3G-FORCE] Generic matrix implies fov=%.1f\n", implied_fov);
                }
            } else {
                /* Fallback to perspective if genericMatrix not available */
                m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
                fprintf(stderr, "[M3G-FORCE] GENERIC camera but no genericMatrix, using perspective fov=%.1f\n", fov);
            }
        } else {
            /* PERSPECTIVE or PARALLEL */
            /* FIX: Validate fov to prevent garbage projections.
             * Some M3G files or game code may set absurd fov values
             * (e.g., 6351.8 degrees). Clamp to reasonable range. */
            float clamped_fov = fov;
            if (clamped_fov < 10.0f) clamped_fov = 10.0f;
            if (clamped_fov > 170.0f) clamped_fov = 60.0f;
            if (clamped_fov != fov) {
                fprintf(stderr, "[M3G-FORCE] Clamped fov from %.1f to %.1f\n", fov, clamped_fov);
            }
            m3g_transform_perspective(&g_m3g.projection, clamped_fov, aspect, near, far);
        }
        
        fprintf(stderr, "[M3G] Force-render camera: fov=%.1f aspect=%.2f near=%.1f far=%.1f\n",
                fov, aspect, near, far);
    } else {
        /* Default perspective projection */
        float aspect = (float)screen_gfx->width / (float)screen_gfx->height;
        m3g_transform_perspective(&g_m3g.projection, 60.0f, aspect, 1.0f, 1000.0f);
    }
    
    /* FIX 45: Force-render must ALWAYS use auto-camera, ignoring the game's
     * camera_inverse. The game's camera is positioned for its own coordinate
     * system (e.g., camera at millions of units). When force-rendering from
     * the registry, the game's camera_inverse places scene meshes at clip.w=0
     * or clip.w<0 (behind camera), causing ALL triangles to be clipped.
     * Instead, compute the scene bounding box from registry meshes and
     * place the camera to actually see the scene. */
    g_m3g.camera_set = 0;  /* Force auto-camera path */
    
    if (0) {  /* g_m3g.camera_set — disabled for force-render */
        g_m3g.modelview = g_m3g.camera_inverse;
        fprintf(stderr, "[M3G-FORCE] Using camera_inverse: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
            g_m3g.camera_inverse.m[0], g_m3g.camera_inverse.m[4], g_m3g.camera_inverse.m[8], g_m3g.camera_inverse.m[12],
            g_m3g.camera_inverse.m[1], g_m3g.camera_inverse.m[5], g_m3g.camera_inverse.m[9], g_m3g.camera_inverse.m[13]);
    } else if (camera) {
        /* FIX 33: The game uses World.setActiveCamera() instead of calling
         * Graphics3D.setCamera(), so g_m3g.camera_set is never true.
         * Compute the camera's view matrix from its transform (position/orientation
         * set by the game or from the M3G file). Without this, the modelview is
         * identity, placing the camera at origin looking down -Z, while all scene
         * objects are at positive Z — behind the camera — causing all triangles
         * to be clipped to 0. */
        M3GTransform cam_transform;
        m3g_build_node_transform(camera, &cam_transform);
        
        /* DIAG: Log camera's raw transform for debugging */
        fprintf(stderr, "[M3G-FORCE] Camera %p transform: tx=%.1f ty=%.1f tz=%.1f ang=%.1f ax=%.1f ay=%.1f az=%.1f\n",
                (void*)camera,
                cam_transform.m[12], cam_transform.m[13], cam_transform.m[14],
                m3g_get_float_field(camera, "orientationAngle", 0.0f),
                m3g_get_float_field(camera, "orientationX", 0.0f),
                m3g_get_float_field(camera, "orientationY", 0.0f),
                m3g_get_float_field(camera, "orientationZ", 0.0f));
        
        /* Check if the camera has a non-identity transform.
         * If identity, the camera is at origin looking down -Z, and we need
         * to check if the scene objects are in front of it.
         *
         * FIX: Also check if the camera transform has GARBAGE values
         * (very large translations, typical when M3G file parsing is
         * partially wrong). If camera translation is unreasonably large
         * (>10000 units), the scene is clearly not designed for this
         * camera position — fall through to auto-camera. */
        float cam_tx = fabsf(cam_transform.m[12]);
        float cam_ty = fabsf(cam_transform.m[13]);
        float cam_tz = fabsf(cam_transform.m[14]);
        int cam_has_transform = (cam_tx > 0.001f || cam_ty > 0.001f || cam_tz > 0.001f ||
                                fabsf(cam_transform.m[0] - 1.0f) > 0.001f ||
                                fabsf(cam_transform.m[5] - 1.0f) > 0.001f ||
                                fabsf(cam_transform.m[10] - 1.0f) > 0.001f);
        
        /* Detect garbage camera transform: if translation is huge (>100K),
         * the camera is clearly positioned incorrectly for our force-render.
         * Fall through to auto-camera which computes proper position. */
        int cam_has_garbage_transform = (cam_tx > 100000.0f || cam_ty > 100000.0f || cam_tz > 100000.0f);
        if (cam_has_garbage_transform) {
            fprintf(stderr, "[M3G-FORCE] Camera has GARBAGE transform (%.0f, %.0f, %.0f), falling through to auto-camera\\n",
                    cam_transform.m[12], cam_transform.m[13], cam_transform.m[14]);
            cam_has_transform = 0;  /* Force auto-camera path */
        }
        
        if (cam_has_transform) {
            /* Compute inverse of camera's world transform for view matrix.
             * For a rigid body transform (rotation + translation only, no scale),
             * inverse = transpose rotation * negate translation. */
            M3GTransform cam_inv;
            m3g_transform_identity(&cam_inv);
            
            /* Transpose rotation part (upper-left 3x3) */
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    cam_inv.m[row * 4 + col] = cam_transform.m[col * 4 + row];
                }
            }
            
            /* Apply inverse translation: -R^T * T */
            float tx = -cam_transform.m[12];
            float ty = -cam_transform.m[13];
            float tz = -cam_transform.m[14];
            cam_inv.m[12] = cam_inv.m[0] * tx + cam_inv.m[4] * ty + cam_inv.m[8] * tz;
            cam_inv.m[13] = cam_inv.m[1] * tx + cam_inv.m[5] * ty + cam_inv.m[9] * tz;
            cam_inv.m[14] = cam_inv.m[2] * tx + cam_inv.m[6] * ty + cam_inv.m[10] * tz;
            
            g_m3g.camera_inverse = cam_inv;
            g_m3g.camera_transform = cam_transform;
            g_m3g.modelview = cam_inv;
            g_m3g.camera = camera;
            g_m3g.camera_set = 1;
            fprintf(stderr, "[M3G-FORCE] Computed camera view matrix from World's activeCamera:\n");
            fprintf(stderr, "[M3G-FORCE]   cam_pos=(%.1f, %.1f, %.1f)\n",
                    cam_transform.m[12], cam_transform.m[13], cam_transform.m[14]);
            fprintf(stderr, "[M3G-FORCE]   view: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
                    cam_inv.m[0], cam_inv.m[4], cam_inv.m[8], cam_inv.m[12],
                    cam_inv.m[1], cam_inv.m[5], cam_inv.m[9], cam_inv.m[13]);
            
            /* NOTE: Camera adaptation removed. The M3G World's activeCamera already
             * has the correct position/orientation set by the game. Previously, this
             * code computed scene bounds from LOCAL-SPACE vertices (ignoring Group
             * transforms), concluded the scene was at millions of units, and repositioned
             * the camera to absurd coordinates — causing NaN UV coords and crashes.
             * The game's camera is the authoritative view; just use it as-is. */
        } else {
            /* Camera has identity transform - place it at a default position
             * that can see the scene. Scan actual mesh vertex positions from
             * the M3G registry for an accurate bounding box (top-level children
             * are usually Groups at origin, not the actual Mesh geometry). */
            fprintf(stderr, "[M3G-FORCE] Camera has identity transform, computing view from mesh vertex bounds\n");
            
            /* Compute scene bounding box from actual mesh vertex positions */
            float scene_min[3] = {1e30f, 1e30f, 1e30f};
            float scene_max[3] = {-1e30f, -1e30f, -1e30f};
            int meshes_scanned = 0;
            
            /* First: scan meshes from the M3G registry (contains all loaded objects).
             * Include ALL meshes (comp=2 and comp=3) for bounding box computation.
             * Some games (like SU-30) only have comp=2 meshes that represent the
             * main scene geometry in world-space coordinates. */
            for (int i = 0; i < g_m3g_registry.count && meshes_scanned < 30; i++) {
                JavaObject* obj = m3g_registry_get(i);
                if (!obj || !obj->header.clazz || !obj->header.clazz->class_name) continue;
                const char* cn = obj->header.clazz->class_name;
                if (strstr(cn, "Mesh") == NULL) continue;
                
                JavaObject* vb = m3g_get_ref_field(obj, "vertexBuffer");
                if (!vb) continue;
                JavaObject* positions = m3g_get_ref_field(vb, "positions");
                if (!positions) continue;
                
                int vc = m3g_get_int_field(positions, "vertexCount", 0);
                int comp = m3g_get_int_field(positions, "componentCount", 3);
                if (vc <= 0 || comp < 1) continue;
                
                float scale = m3g_get_float_field(vb, "positionScale", 1.0f);
                float bx = m3g_get_float_field(vb, "biasX", 0.0f);
                float by = m3g_get_float_field(vb, "biasY", 0.0f);
                float bz = m3g_get_float_field(vb, "biasZ", 0.0f);
                
                JavaArray* pos_data = (JavaArray*)m3g_get_ref_field(positions, "data");
                if (!pos_data) continue;
                
                /* Sample up to 20 vertices per mesh for bounding box */
                int sample_count = vc < 20 ? vc : 20;
                int step = vc > 20 ? vc / 20 : 1;
                
                if (pos_data->element_type == T_SHORT || pos_data->element_type == T_BYTE) {
                    int is_short = (pos_data->element_type == T_SHORT);
                    for (int vi = 0; vi < sample_count; vi++) {
                        int idx = vi * step * comp;
                        /* v10 FIX: bound by comp (was idx+2, which both read the
                         * NEXT vertex's x as z for comp=2 arrays and broke out
                         * one vertex early). */
                        if (idx + comp - 1 >= (int)pos_data->length) break;
                        float px, py, pz = 0.0f;
                        if (is_short) {
                            int16_t* src = (int16_t*)array_data(pos_data);
                            px = (float)src[idx] * scale + bx;
                            py = (float)src[idx+1] * scale + by;
                            pz = (comp >= 3) ? (float)src[idx+2] * scale + bz : 0.0f;
                        } else {
                            int8_t* src = (int8_t*)array_data(pos_data);
                            px = (float)src[idx] * scale + bx;
                            py = (float)src[idx+1] * scale + by;
                            pz = (comp >= 3) ? (float)src[idx+2] * scale + bz : 0.0f;
                        }
                        /* Include all vertices for bounding box */
                        if (px < scene_min[0]) scene_min[0] = px;
                        if (py < scene_min[1]) scene_min[1] = py;
                        if (pz < scene_min[2]) scene_min[2] = pz;
                        if (px > scene_max[0]) scene_max[0] = px;
                        if (py > scene_max[1]) scene_max[1] = py;
                        if (pz > scene_max[2]) scene_max[2] = pz;
                    }
                }
                meshes_scanned++;
            }
            
            /* FIX 36: Handle empty registry (no meshes loaded yet).
             * When meshes_scanned=0, bbox was never updated and contains
             * 1e30/-1e30 defaults. Use a reasonable default scene. */
            int has_valid_bbox = (scene_min[0] < scene_max[0]);
            if (!has_valid_bbox || meshes_scanned == 0) {
                /* No meshes in registry — use a default view position.
                 * The scene might load later; this is just for initial frames. */
                float eye[3] = { 0.0f, 0.0f, 200.0f };
                float at[3]  = { 0.0f, 0.0f, 0.0f };
                float up[3]  = { 0.0f, 1.0f, 0.0f };
                
                m3g_transform_look_at(&g_m3g.modelview,
                                      eye[0], eye[1], eye[2],
                                      at[0], at[1], at[2],
                                      up[0], up[1], up[2]);
                g_m3g.camera_inverse = g_m3g.modelview;
                g_m3g.camera_set = 1;
                fprintf(stderr, "[M3G-FORCE] Auto-camera: no meshes found, using default eye=(0,0,200)\n");
            } else {
            
            fprintf(stderr, "[M3G-FORCE] Scanned %d meshes, bbox: (%.1f,%.1f,%.1f)-(%.1f,%.1f,%.1f)\n",
                    meshes_scanned, scene_min[0], scene_min[1], scene_min[2],
                    scene_max[0], scene_max[1], scene_max[2]);
            
            float center[3] = {
                (scene_min[0] + scene_max[0]) * 0.5f,
                (scene_min[1] + scene_max[1]) * 0.5f,
                (scene_min[2] + scene_max[2]) * 0.5f
            };
            float extent = 0.0f;
            for (int i = 0; i < 3; i++) {
                float d = scene_max[i] - scene_min[i];
                if (d > extent) extent = d;
            }
            if (extent < 1.0f) extent = 100.0f;
            
            /* Place camera behind the scene center, looking at it.
             * FIX 39: When scene extent is much larger than camera near/far
             * (e.g., comp=2 meshes with world-space coords in the millions),
             * adapt near/far to the actual view distance. The M3G camera's
             * near/far are tuned for the game's own camera position, not for
             * our auto-positioned camera millions of units away. */
            float view_dist = extent * 1.2f;
            float cam_near = cam_near_val;
            float cam_far = cam_far_val;
            
            /* Adapt near/far when view_dist is much larger than far plane */
            if (view_dist > cam_far * 1.5f) {
                cam_near = view_dist * 0.01f;
                cam_far = view_dist * 3.0f;
                /* Recompute perspective projection with corrected near/far */
                float correct_aspect = (float)g_m3g.buffer_width / (float)g_m3g.buffer_height;
                if (correct_aspect <= 0.001f) correct_aspect = 0.75f;
                float fov = m3g_get_float_field(camera, "fov", 45.0f);
                if (fov <= 0.0f || fov > 170.0f) fov = 45.0f;  /* reject garbage fov */
                m3g_transform_perspective(&g_m3g.projection, fov, correct_aspect, cam_near, cam_far);
                fprintf(stderr, "[M3G-FORCE] Auto-camera: adapted near/far to (%.1f, %.1f) for view_dist=%.1f\n",
                        cam_near, cam_far, view_dist);
            }
            
            /* Clamp view_dist to be within camera's frustum */
            if (view_dist < cam_near + 1.0f) view_dist = cam_near + (cam_far - cam_near) * 0.1f;
            if (view_dist > cam_far * 0.9f) view_dist = cam_far * 0.9f;
            
            float eye[3] = { center[0], center[1], center[2] + view_dist };
            float at[3]  = { center[0], center[1], center[2] };
            float up[3]  = { 0.0f, 1.0f, 0.0f };
            
            m3g_transform_look_at(&g_m3g.modelview,
                                  eye[0], eye[1], eye[2],
                                  at[0], at[1], at[2],
                                  up[0], up[1], up[2]);
            g_m3g.camera_inverse = g_m3g.modelview;
            g_m3g.camera_set = 1;
            fprintf(stderr, "[M3G-FORCE] Auto-camera: eye=(%.1f,%.1f,%.1f) at=(%.1f,%.1f,%.1f) extent=%.1f view_dist=%.1f near=%.1f far=%.1f\n",
                    eye[0], eye[1], eye[2], at[0], at[1], at[2], extent, view_dist, cam_near, cam_far);
            }
        }
    } else {
        m3g_transform_identity(&g_m3g.modelview);
        fprintf(stderr, "[M3G-FORCE] camera_set=false, no camera found, using identity modelview\n");
    }
    
    /* NOTE: FIX40 scene-bbox adaptation removed. It computed LOCAL-SPACE vertex
     * bounds (ignoring Group/Node transforms in the scene graph), incorrectly
     * concluded the scene was millions of units away, and recomputed projection
     * with absurd near/far. The game's camera projection is already correct;
     * the Group transforms place local vertices into the camera's view frustum. */
    
    /* Collect lights from World's children */
    g_m3g.light_count = 0;
    
    /* Render the world using camera modelview */
    g_m3g.triangles_rendered = 0;
    g_m3g.vertices_processed = 0;
    
    m3g_render_node_recursive(jvm, g_m3g_last_world, &g_m3g.modelview);
    
    /* Replay any pending render(Node, Transform) calls that were queued when
     * the game called render() without bindTarget. These use the game's own
     * transforms and node tree, giving much better results than the registry
     * fallback (which uses identity modelview). */
    if (g_m3g.triangles_rendered == 0 && g_m3g_pending_render_count > 0) {
        LOG_SAFE( "[M3G] Force-render: replaying %d pending render() calls\n",
                g_m3g_pending_render_count);
        for (int i = 0; i < g_m3g_pending_render_count && i < M3G_MAX_PENDING_RENDERS; i++) {
            JavaObject* node = g_m3g_pending_renders[i].node;
            JavaObject* transform = g_m3g_pending_renders[i].transform;
            if (node && transform) {
                LOG_SAFE( "[M3G] Force-render: replaying pending render[%d] node=%p class=%s\n",
                        i, (void*)node,
                        node->header.clazz ? node->header.clazz->class_name : "?");
                m3g_replay_pending_render(jvm, node, transform);
            }
        }
        fprintf(stderr, "[M3G] Force-render: pending renders done, total triangles=%d\n",
                g_m3g.triangles_rendered);
    }
    
    /* If World render AND pending renders produced 0 triangles, scan the M3G registry
     * for ALL Mesh objects and render them directly. This is the last-resort fallback
     * that uses the mesh's own transform (no game-supplied transform). */
    if (g_m3g.triangles_rendered == 0 && g_m3g_registry.count > 0) {
        fprintf(stderr, "[M3G] Force-render: World gave 0 triangles, scanning registry for Meshes (%d objects)\n",
                g_m3g_registry.count);
        
        /* FIX: Set up auto-camera from registry mesh bounding box.
         * When World is NULL, the camera setup from the World path is skipped.
         * Compute scene bbox from registry meshes and position camera. */
        if (!g_m3g.camera_set) {
            float scene_min[3] = {1e30f, 1e30f, 1e30f};
            float scene_max[3] = {-1e30f, -1e30f, -1e30f};
            int meshes_scanned = 0;
            
            for (int i = 0; i < g_m3g_registry.count && meshes_scanned < 30; i++) {
                JavaObject* obj = m3g_registry_get(i);
                if (!obj || !obj->header.clazz || !obj->header.clazz->class_name) continue;
                if (strstr(obj->header.clazz->class_name, "Mesh") == NULL) continue;
                
                JavaObject* vb = m3g_get_ref_field(obj, "vertexBuffer");
                if (!vb) continue;
                JavaObject* positions = m3g_get_ref_field(vb, "positions");
                if (!positions) continue;
                
                int vc = m3g_get_int_field(positions, "vertexCount", 0);
                int comp = m3g_get_int_field(positions, "componentCount", 3);
                if (vc <= 0 || comp < 1) continue;
                
                float scale = m3g_get_float_field(vb, "positionScale", 1.0f);
                float bx = m3g_get_float_field(vb, "biasX", 0.0f);
                float by = m3g_get_float_field(vb, "biasY", 0.0f);
                float bz = m3g_get_float_field(vb, "biasZ", 0.0f);
                
                JavaArray* pos_data = (JavaArray*)m3g_get_ref_field(positions, "data");
                if (!pos_data) continue;
                
                int sample_count = vc < 20 ? vc : 20;
                int step = vc > 20 ? vc / 20 : 1;
                
                if (pos_data->element_type == T_SHORT || pos_data->element_type == T_BYTE) {
                    int is_short = (pos_data->element_type == T_SHORT);
                    for (int vi = 0; vi < sample_count; vi++) {
                        int idx = vi * step * comp;
                        /* v10 FIX: bound by comp (was idx+2, which both read the
                         * NEXT vertex's x as z for comp=2 arrays and broke out
                         * one vertex early). */
                        if (idx + comp - 1 >= (int)pos_data->length) break;
                        float px, py, pz = 0.0f;
                        if (is_short) {
                            int16_t* src = (int16_t*)array_data(pos_data);
                            px = (float)src[idx] * scale + bx;
                            py = (float)src[idx+1] * scale + by;
                            pz = (comp >= 3) ? (float)src[idx+2] * scale + bz : 0.0f;
                        } else {
                            int8_t* src = (int8_t*)array_data(pos_data);
                            px = (float)src[idx] * scale + bx;
                            py = (float)src[idx+1] * scale + by;
                            pz = (comp >= 3) ? (float)src[idx+2] * scale + bz : 0.0f;
                        }
                        if (px < scene_min[0]) scene_min[0] = px;
                        if (py < scene_min[1]) scene_min[1] = py;
                        if (pz < scene_min[2]) scene_min[2] = pz;
                        if (px > scene_max[0]) scene_max[0] = px;
                        if (py > scene_max[1]) scene_max[1] = py;
                        if (pz > scene_max[2]) scene_max[2] = pz;
                    }
                }
                meshes_scanned++;
            }
            
            if (scene_min[0] < scene_max[0]) {
                float center[3] = {
                    (scene_min[0] + scene_max[0]) * 0.5f,
                    (scene_min[1] + scene_max[1]) * 0.5f,
                    (scene_min[2] + scene_max[2]) * 0.5f
                };
                float extent = 0.0f;
                for (int i = 0; i < 3; i++) {
                    float d = scene_max[i] - scene_min[i];
                    if (d > extent) extent = d;
                }
                if (extent < 1.0f) extent = 100.0f;
                
                float view_dist = extent * 1.2f;
                float cam_near = view_dist * 0.01f;
                float cam_far = view_dist * 3.0f;
                
                float correct_aspect = (float)g_m3g.buffer_width / (float)g_m3g.buffer_height;
                if (correct_aspect <= 0.001f) correct_aspect = 0.75f;
                m3g_transform_perspective(&g_m3g.projection, 45.0f, correct_aspect, cam_near, cam_far);
                
                float eye[3] = { center[0], center[1], center[2] + view_dist };
                float at[3]  = { center[0], center[1], center[2] };
                float up[3]  = { 0.0f, 1.0f, 0.0f };
                
                m3g_transform_look_at(&g_m3g.modelview,
                                      eye[0], eye[1], eye[2],
                                      at[0], at[1], at[2],
                                      up[0], up[1], up[2]);
                g_m3g.camera_inverse = g_m3g.modelview;
                g_m3g.camera_set = 1;
                
                fprintf(stderr, "[M3G-FORCE] Registry auto-camera: bbox=(%.0f,%.0f,%.0f)-(%.0f,%.0f,%.0f) extent=%.0f\n",
                        scene_min[0], scene_min[1], scene_min[2],
                        scene_max[0], scene_max[1], scene_max[2], extent);
                fprintf(stderr, "[M3G-FORCE] Registry auto-camera: eye=(%.0f,%.0f,%.0f) near=%.1f far=%.1f\n",
                        eye[0], eye[1], eye[2], cam_near, cam_far);
            }
        }
        
        int mesh_rendered = 0;
        for (int i = 0; i < g_m3g_registry.count && mesh_rendered < 50; i++) {
            JavaObject* obj = g_m3g_registry.objects[i];
            /* v15 CRITICAL FIX: prune DEAD registry entries. The registry
             * keeps raw JavaObject* pointers; after a GC frees the old
             * scene (M3GTest switches scenes and calls System.gc()) the
             * entry dangles. Dereferencing obj->header.clazz on freed and
             * reused memory crashed the process (Windows "вылет" after
             * the last test scene). Validate before ANY dereference. */
            if (obj && !heap_java_object_valid(obj)) {
                fprintf(stderr, "[M3G-REG] registry[%d] %p is DEAD (freed by GC), pruning\n",
                        i, (void*)obj);
                g_m3g_registry.objects[i] = NULL;
                g_m3g_registry.userIDs[i] = 0;
                obj = NULL;
            }
            if (!obj || !obj->header.clazz || !obj->header.clazz->class_name) continue;
            const char* cn = obj->header.clazz->class_name;
            /* Log ALL registry entries to understand what's there */
            fprintf(stderr, "[M3G-REG] registry[%d] %p class=%s\n", i, (void*)obj, cn);
            if (strstr(cn, "Mesh") != NULL) {
                int render_enable = m3g_get_int_field(obj, "renderingEnable", 1);
                fprintf(stderr, "[M3G-REG] Mesh[%d]: render_enable=%d\n", i, render_enable);
                if (!render_enable) continue;
                
                /* Check if this mesh has a vertexBuffer */
                JavaObject* vb = m3g_get_ref_field(obj, "vertexBuffer");
                fprintf(stderr, "[M3G-REG] Mesh[%d]: vb=%p\n", i, (void*)vb);
                if (!vb) continue;
                JavaObject* positions = m3g_get_ref_field(vb, "positions");
                fprintf(stderr, "[M3G-REG] Mesh[%d]: positions=%p\n", i, (void*)positions);
                if (!positions) continue;
                
                fprintf(stderr, "[M3G] Force-render: rendering registry Mesh[%d] %p (userID=%d)\n",
                        i, (void*)obj, g_m3g_registry.userIDs[i]);
                
                /* Log vertex format details */
                int pos_comp = m3g_get_int_field(positions, "componentCount", -1);
                float scale = m3g_get_float_field(vb, "positionScale", 1.0f);
                float bx = m3g_get_float_field(vb, "biasX", 0.0f);
                float by = m3g_get_float_field(vb, "biasY", 0.0f);
                float bz = m3g_get_float_field(vb, "biasZ", 0.0f);
                int vc = m3g_get_int_field(positions, "vertexCount", 0);
                fprintf(stderr, "[M3G]   pos: comp=%d, verts=%d, scale=%.4f, bias=(%.1f,%.1f,%.1f)\n",
                        pos_comp, vc, scale, bx, by, bz);
                
                /* Build proper MVP using the mesh's own transform instead of identity.
                 * Previously used &g_m3g.mvp (identity modelview * projection), causing
                 * all meshes to be at origin without proper transforms. */
                M3GTransform node_transform;
                m3g_build_node_transform(obj, &node_transform);
                
                /* Combine: modelview = camera_inverse * node_transform */
                M3GTransform modelview;
                if (g_m3g.camera_set) {
                    m3g_transform_multiply(&modelview, &g_m3g.camera_inverse, &node_transform);
                } else {
                    modelview = node_transform;
                }
                
                /* Build MVP = projection * modelview (OpenGL convention) */
                M3GTransform mesh_mvp;
                m3g_transform_multiply(&mesh_mvp, &g_m3g.projection, &modelview);
                
                /* DIAG: log node_transform, modelview, projection for first mesh */
                if (mesh_rendered == 0) {
                    fprintf(stderr, "[M3G-FORCE-DIAG] node_transform: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
                        node_transform.m[0], node_transform.m[4], node_transform.m[8], node_transform.m[12],
                        node_transform.m[1], node_transform.m[5], node_transform.m[9], node_transform.m[13],
                        node_transform.m[2], node_transform.m[6], node_transform.m[10], node_transform.m[14],
                        node_transform.m[3], node_transform.m[7], node_transform.m[11], node_transform.m[15]);
                    fprintf(stderr, "[M3G-FORCE-DIAG] projection: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
                        g_m3g.projection.m[0], g_m3g.projection.m[4], g_m3g.projection.m[8], g_m3g.projection.m[12],
                        g_m3g.projection.m[1], g_m3g.projection.m[5], g_m3g.projection.m[9], g_m3g.projection.m[13],
                        g_m3g.projection.m[2], g_m3g.projection.m[6], g_m3g.projection.m[10], g_m3g.projection.m[14],
                        g_m3g.projection.m[3], g_m3g.projection.m[7], g_m3g.projection.m[11], g_m3g.projection.m[15]);
                    fprintf(stderr, "[M3G-FORCE-DIAG] MVP: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
                        mesh_mvp.m[0], mesh_mvp.m[4], mesh_mvp.m[8], mesh_mvp.m[12],
                        mesh_mvp.m[1], mesh_mvp.m[5], mesh_mvp.m[9], mesh_mvp.m[13],
                        mesh_mvp.m[2], mesh_mvp.m[6], mesh_mvp.m[10], mesh_mvp.m[14],
                        mesh_mvp.m[3], mesh_mvp.m[7], mesh_mvp.m[11], mesh_mvp.m[15]);
                }
                
                m3g_render_single_mesh(jvm, obj, &mesh_mvp);
                mesh_rendered++;
            }
        }
        LOG_SAFE( "[M3G] Force-render: rendered %d Meshes from registry\n", mesh_rendered);
    }
    
    /* Copy rendered M3G buffer to screen framebuffer */
    if (g_m3g.color_buffer && g_m3g.buffers_allocated) {
        int copy_w = screen_gfx->width < g_m3g.buffer_width ? screen_gfx->width : g_m3g.buffer_width;
        int copy_h = screen_gfx->height < g_m3g.buffer_height ? screen_gfx->height : g_m3g.buffer_height;
        for (int y = 0; y < copy_h; y++) {
            for (int x = 0; x < copy_w; x++) {
                uint32_t m3g_pixel = g_m3g.color_buffer[y * g_m3g.buffer_width + x];
                int sx = x;
                int sy = y;
                if (sx >= 0 && sx < screen_gfx->width && sy >= 0 && sy < screen_gfx->height) {
                    screen_gfx->pixels[sy * screen_gfx->width + sx] = m3g_pixel;
                }
            }
        }
        LOG_SAFE( "[M3G] Force-render complete: %d triangles, %d vertices\n",
                g_m3g.triangles_rendered, g_m3g.vertices_processed);
        
        /* Save frame as BMP for visual diagnosis.
         * Controlled by M3G_CAPTURE env var:
         *   M3G_CAPTURE=N     - save first N frames (default: 10)
         *   M3G_CAPTURE=0     - disable capture
         *   M3G_CAPTURE=every  - save every 100th frame */
        {
            static int force_render_count = 0;
            static int capture_limit = -1; /* -1 = not yet initialized */
            force_render_count++;

            if (capture_limit < 0) {
                const char* env_cap = getenv("M3G_CAPTURE");
                if (env_cap) {
                    if (strcmp(env_cap, "every") == 0) capture_limit = 999999;
                    else capture_limit = atoi(env_cap);
                } else {
                    /* v18: capture is now OPT-IN (was 10 — polluted download/
                     * with m3g_frame_*.bmp on every M3GTest run) */
                    capture_limit = 0;
                }
                if (capture_limit > 0) {
                    fprintf(stderr, "[M3G-CAP] Frame capture enabled: limit=%d (set M3G_CAPTURE to change)\n", capture_limit);
                }
            }

            int should_capture = 0;
            if (capture_limit == 999999) {
                should_capture = (force_render_count % 100 == 0); /* every 100th frame */
            } else if (capture_limit > 0) {
                should_capture = (force_render_count <= capture_limit);
            }

            if (should_capture && screen_gfx->pixels) {
                char fname[256];
                snprintf(fname, sizeof(fname), "/home/z/my-project/download/m3g_frame_%05d.bmp", force_render_count);
                int w = screen_gfx->width;
                int h = screen_gfx->height;
                int row_size = (w * 3 + 3) & ~3; /* BMP rows padded to 4 bytes */
                int pixel_data_size = row_size * h;
                int file_size = 54 + pixel_data_size;

                FILE* f = fopen(fname, "wb");
                if (f) {
                    /* BMP Header (14 bytes) */
                    uint8_t hdr[14] = {'B','M'};
                    hdr[2] = file_size & 0xFF; hdr[3] = (file_size>>8) & 0xFF;
                    hdr[4] = (file_size>>16) & 0xFF; hdr[5] = (file_size>>24) & 0xFF;
                    hdr[10] = 54; /* pixel data offset */
                    fwrite(hdr, 1, 14, f);

                    /* DIB Header (40 bytes) */
                    uint8_t dib[40] = {0};
                    dib[0] = 40; /* header size */
                    dib[4] = w & 0xFF; dib[5] = (w>>8) & 0xFF; dib[6] = (w>>16) & 0xFF; dib[7] = (w>>24) & 0xFF;
                    dib[8] = h & 0xFF; dib[9] = (h>>8) & 0xFF; dib[10] = (h>>16) & 0xFF; dib[11] = (h>>24) & 0xFF;
                    dib[12] = 1; /* color planes */
                    dib[14] = 24; /* bits per pixel */
                    dib[20] = pixel_data_size & 0xFF; dib[21] = (pixel_data_size>>8) & 0xFF;
                    dib[22] = (pixel_data_size>>16) & 0xFF; dib[23] = (pixel_data_size>>24) & 0xFF;
                    fwrite(dib, 1, 40, f);

                    /* Pixel data - BMP stores bottom-to-top, BGR order */
                    uint8_t* row_buf = (uint8_t*)calloc(row_size, 1);
                    if (row_buf) {
                        for (int y = h - 1; y >= 0; y--) {
                            memset(row_buf, 0, row_size);
                            for (int x = 0; x < w; x++) {
                                uint32_t p = screen_gfx->pixels[y * w + x];
                                row_buf[x * 3 + 0] = p & 0xFF;         /* B */
                                row_buf[x * 3 + 1] = (p >> 8) & 0xFF;  /* G */
                                row_buf[x * 3 + 2] = (p >> 16) & 0xFF; /* R */
                            }
                            fwrite(row_buf, 1, row_size, f);
                        }
                        free(row_buf);
                    }
                    fclose(f);
                    fprintf(stderr, "[M3G-CAP] Saved frame #%d to %s (%dx%d)\n", force_render_count, fname, w, h);
                }
            }
        }
    }
    
    g_m3g.target_gfx = NULL;
    g_m3g.target_is_graphics = 0;
    g_m3g_render_done = true;
    /* FIX 32b: Don't reset scene_done if we have a valid World.
     * The game loads M3G files once (in Loader.load) and expects rendering
     * every frame. Resetting scene_done here would prevent force-render from
     * running on subsequent frames after the first successful render. */
    if (!g_m3g_last_world) {
        g_m3g_scene_setup_done = false;
    }
}

/* Called from midp_process_repaints() after paint() to check if M3G force-render
 * produced output that needs to be blitted to the screen framebuffer.
 * Returns true if blit was performed (screen was modified). */
bool m3g_blit_to_screen_if_needed(JVM* jvm, MidpGraphics* screen_gfx) {
    (void)jvm;
    (void)screen_gfx;
    /* If force-render was performed this frame, the pixels are already
     * written into the framebuffer by m3g_rasterize_triangle() via the
     * render callback. No separate blit step is needed. */
    /* This function exists as a hook for display.c to call; the actual
     * pixel writing happens inside m3g_force_render() → m3g_render_node_recursive()
     * → m3g_rasterize_triangle() which writes directly to the screen buffer. */
    return false;
}

/* Global M3G Object Registry for find() - stores all loaded M3G objects by userID */
/* (typedef and forward decl at top of file, definition here) */
M3GObjectRegistry g_m3g_registry = {0};

/* Register an M3G object for global find() lookup */
static void m3g_registry_register(JavaObject* obj, jint userID) {
    if (!obj || userID < 0) return;
    if (g_m3g_registry.count >= 4096) return;  /* Increased from 1024 to handle large scenes */
    
    /* Check if already registered */
    for (int i = 0; i < g_m3g_registry.count; i++) {
        if (g_m3g_registry.objects[i] == obj) {
            g_m3g_registry.userIDs[i] = userID;  /* Update userID */
            return;
        }
    }
    
    /* Add new entry */
    g_m3g_registry.objects[g_m3g_registry.count] = obj;
    g_m3g_registry.userIDs[g_m3g_registry.count] = userID;
    g_m3g_registry.count++;
}

/* Find an M3G object by userID in the global registry */
static JavaObject* m3g_registry_find(jint userID) {
    for (int i = 0; i < g_m3g_registry.count; i++) {
        if (g_m3g_registry.userIDs[i] == userID) {
            return g_m3g_registry.objects[i];
        }
    }
    return NULL;
}

/* Clear the global registry (call when loading a new M3G file) */
static void m3g_registry_clear(void) {
    g_m3g_registry.count = 0;
}

/* Helper: Set userID on an object and register it for global find() */
static void m3g_set_userID(JavaObject* obj, jint user_id) {
    if (!obj) return;
    m3g_set_int_field(obj, "userID", user_id);
    if (user_id > 0) {
        m3g_registry_register(obj, user_id);
    }
}

/* GC ROOT SUPPORT: Export M3G registry for garbage collection marking.
 * The GC needs to mark these objects as roots to prevent them from being
 * collected while they're still referenced by the registry.
 * Returns: pointer to the objects array and sets *out_count to the number of objects.
 */
JavaObject** m3g_registry_get_objects(int* out_count) {
    if (out_count) {
        *out_count = g_m3g_registry.count;
    }
    return g_m3g_registry.objects;
}

/* ============================================================================
 * M3G Math Functions
 * ============================================================================ */

/* Transpose a 4x4 matrix from row-major (Java/M3G binary format) to column-major (OpenGL/C internal).
 * Java Transform stores: mat[row*4+col]. C M3GTransform stores: m[col*4+row].
 * This function converts in-place. */
__attribute__((unused)) static void m3g_transform_transpose_inplace(M3GTransform* t) {
    float tmp;
    /* Swap off-diagonal elements */
    tmp = t->m[1];  t->m[1]  = t->m[4];  t->m[4]  = tmp;
    tmp = t->m[2];  t->m[2]  = t->m[8];  t->m[8]  = tmp;
    tmp = t->m[3];  t->m[3]  = t->m[12]; t->m[12] = tmp;
    tmp = t->m[6];  t->m[6]  = t->m[9];  t->m[9]  = tmp;
    tmp = t->m[7];  t->m[7]  = t->m[13]; t->m[13] = tmp;
    tmp = t->m[11]; t->m[11] = t->m[14]; t->m[14] = tmp;
}

/* Convert a 16-float array from row-major to column-major, storing into M3GTransform */
static void m3g_transform_from_rowmajor(M3GTransform* out, const float* rowmajor) {
    /* v12 CRITICAL FIX: JSR-184 Transform matrices use the ROW-VECTOR
     * convention (v' = v·M): the translation lives in the BOTTOM ROW,
     * which in row-major flat indexing is m[12],m[13],m[14].
     * Our M3GTransform is COLUMN-VECTOR convention (v' = M·v) stored
     * column-major: translation lives at m[12],m[13],m[14] too.
     * Converting row-major(row-vector) -> column-major(column-vector)
     * is therefore a FLAT-IDENTICAL copy (both are the transpose of each
     * other mathematically, but the flat layouts coincide).
     *
     * The old code swapped indices (out->m[col*4+row] = in[row*4+col]),
     * which MATHEMATICALLY TRANSPOSED the matrix: every translation read
     * back from m[12..14] was ZERO (it landed at m[3],m[7],m[11]) and
     * rotations were inverted. Symptom: Nescube's setCamera(translate
     * z=25) produced camera_inverse=(0,0,0) → the cube rendered "behind
     * the camera" (clip w<0) and vanished.
     *
     * v24 FIX (Brick Breaker): some games (OpenGL-port style) pass
     * COLUMN-VECTOR matrices (v' = M·v) stored ROW-major — their
     * translation sits at flat[3],flat[7],flat[11] and their bottom row
     * [12..14] is zero. A flat-identical copy then TRANSPOSES every such
     * matrix: the camera position was lost and the camera looked into a
     * side wall. Auto-detect the layout per matrix: when the standard
     * translation slots [12..14] are all zero AND the transposed-layout
     * slots [3,7,11] are not (and w-row == 0,0,0,1 — rigid/gl-style
     * affine), transpose on copy. Spec-conformant matrices (Nescube,
     * M3G files) keep the flat-identical path, so this cannot regress
     * them: for them [12..14] is non-zero or [3,7,11] is zero. */
    float t_std  = fabsf(rowmajor[12]) + fabsf(rowmajor[13]) + fabsf(rowmajor[14]);
    float t_alt  = fabsf(rowmajor[3])  + fabsf(rowmajor[7])  + fabsf(rowmajor[11]);
    int wrow_zero = (rowmajor[12] == 0.0f && rowmajor[13] == 0.0f &&
                     rowmajor[14] == 0.0f);
    int w_one = fabsf(rowmajor[15] - 1.0f) < 1e-5f;
    if (t_std == 0.0f && t_alt > 0.0f && wrow_zero && w_one) {
        /* Row-major column-vector layout: transpose into our column-major. */
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 4; c++) {
                out->m[c * 4 + r] = rowmajor[r * 4 + c];
            }
        }
        return;
    }
    for (int i = 0; i < 16; i++) {
        out->m[i] = rowmajor[i];
    }
}

/* Create identity matrix */
static void m3g_transform_identity(M3GTransform* t) {
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = 1.0f;   t->m[5] = 1.0f;   t->m[10] = 1.0f;  t->m[15] = 1.0f;
}

/* Multiply two matrices: result = a * b */
M3G_INLINE void m3g_transform_multiply(M3GTransform* result, 
                                    const M3GTransform* a, 
                                    const M3GTransform* b) {
    float r[16];
    for (int col = 0; col < 4; col++) {
        for (int row = 0; row < 4; row++) {
            float sum = 0.0f;
            for (int k = 0; k < 4; k++) {
                sum += a->m[k * 4 + row] * b->m[col * 4 + k];
            }
            r[col * 4 + row] = sum;
        }
    }
    memcpy(result->m, r, sizeof(r));
}

/* Translate */
static void m3g_transform_translate(M3GTransform* t, float x, float y, float z) {
    M3GTransform trans;
    m3g_transform_identity(&trans);
    trans.m[12] = x;  trans.m[13] = y;  trans.m[14] = z;
    m3g_transform_multiply(t, t, &trans);
}

/* Scale */
static void m3g_transform_scale(M3GTransform* t, float x, float y, float z) {
    M3GTransform scale;
    m3g_transform_identity(&scale);
    scale.m[0] = x;  scale.m[5] = y;  scale.m[10] = z;
    m3g_transform_multiply(t, t, &scale);
}

/* Rotate around axis (angle in radians) */
static void m3g_transform_rotate(M3GTransform* t, float angle, 
                                  float ax, float ay, float az) {
    /* Normalize axis */
    float len = sqrtf(ax*ax + ay*ay + az*az);
    if (len < 0.0001f) return;
    ax /= len;  ay /= len;  az /= len;
    
    float c = cosf(angle);
    float s = sinf(angle);
    float omc = 1.0f - c;
    
    M3GTransform rot;
    m3g_transform_identity(&rot);
    
    rot.m[0] = ax*ax*omc + c;
    rot.m[1] = ax*ay*omc + az*s;
    rot.m[2] = ax*az*omc - ay*s;
    
    rot.m[4] = ax*ay*omc - az*s;
    rot.m[5] = ay*ay*omc + c;
    rot.m[6] = ay*az*omc + ax*s;
    
    rot.m[8] = ax*az*omc + ay*s;
    rot.m[9] = ay*az*omc - ax*s;
    rot.m[10] = az*az*omc + c;
    
    m3g_transform_multiply(t, t, &rot);
}

/* Set perspective projection */
static void m3g_transform_perspective(M3GTransform* t, float fov, 
                                       float aspect, float near, float far) {
    /* FIX 29: Guard against degenerate parameters that produce NaN/Infinity.
     * The game calls Camera.setPerspective(fov, 0, near, far) with aspect=0,
     * meaning "use viewport aspect ratio". Default to 0.75 (typical 240x320)
     * instead of 1.0 which gives wrong horizontal FOV.
     * Also guard near<=0 which would flip the depth range. */
    if (aspect <= 0.001f) aspect = 0.75f;
    if (near <= 0.001f) near = 0.001f;
    if (far <= near + 0.001f) far = near + 1.0f;
    if (fov <= 0.0f || fov >= 180.0f) fov = 60.0f;
    
    float f = 1.0f / tanf(fov * 3.14159f / 360.0f);
    float range = 1.0f / (near - far);
    
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = f / aspect;
    t->m[5] = f;
    t->m[10] = (near + far) * range;
    t->m[11] = -1.0f;
    t->m[14] = 2.0f * near * far * range;
}

/* Set orthographic projection */
static void m3g_transform_ortho(M3GTransform* t, float left, float right,
                                 float bottom, float top, float near, float far) {
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = 2.0f / (right - left);
    t->m[5] = 2.0f / (top - bottom);
    t->m[10] = 2.0f / (near - far);
    t->m[12] = -(right + left) / (right - left);
    t->m[13] = -(top + bottom) / (top - bottom);
    t->m[14] = (near + far) / (near - far);
    t->m[15] = 1.0f;
}

/* Set look-at matrix */
static void m3g_transform_look_at(M3GTransform* t,
                                   float eye_x, float eye_y, float eye_z,
                                   float at_x, float at_y, float at_z,
                                   float up_x, float up_y, float up_z) {
    /* Forward vector (Z) */
    float fx = at_x - eye_x;
    float fy = at_y - eye_y;
    float fz = at_z - eye_z;
    float flen = sqrtf(fx*fx + fy*fy + fz*fz);
    fx /= flen; fy /= flen; fz /= flen;
    
    /* Side vector (X) = forward x up */
    float sx = fy * up_z - fz * up_y;
    float sy = fz * up_x - fx * up_z;
    float sz = fx * up_y - fy * up_x;
    float slen = sqrtf(sx*sx + sy*sy + sz*sz);
    sx /= slen; sy /= slen; sz /= slen;
    
    /* Recalculate up (Y) = side x forward */
    float ux = sy * fz - sz * fy;
    float uy = sz * fx - sx * fz;
    float uz = sx * fy - sy * fx;
    
    /* Build rotation matrix */
    t->m[0] = sx;   t->m[4] = ux;   t->m[8]  = -fx;  t->m[12] = 0;
    t->m[1] = sy;   t->m[5] = uy;   t->m[9]  = -fy;  t->m[13] = 0;
    t->m[2] = sz;   t->m[6] = uz;   t->m[10] = -fz;  t->m[14] = 0;
    t->m[3] = 0;    t->m[7] = 0;    t->m[11] = 0;    t->m[15] = 1;
    
    /* Apply translation */
    M3GTransform trans;
    m3g_transform_identity(&trans);
    trans.m[12] = -eye_x;
    trans.m[13] = -eye_y;
    trans.m[14] = -eye_z;
    m3g_transform_multiply(t, t, &trans);
}

/* Transform a point by matrix */
static void m3g_transform_point(float* result, const M3GTransform* t, 
                                 const float* point) {
    float x = point[0], y = point[1], z = point[2], w = point[3];
    result[0] = t->m[0]*x + t->m[4]*y + t->m[8]*z + t->m[12]*w;
    result[1] = t->m[1]*x + t->m[5]*y + t->m[9]*z + t->m[13]*w;
    result[2] = t->m[2]*x + t->m[6]*y + t->m[10]*z + t->m[14]*w;
    result[3] = t->m[3]*x + t->m[7]*y + t->m[11]*z + t->m[15]*w;
}

/* Transform a vector (no translation) */
__attribute__((unused)) static void m3g_transform_vector(float* result, const M3GTransform* t,
                                  const float* vec) {
    float x = vec[0], y = vec[1], z = vec[2];
    result[0] = t->m[0]*x + t->m[4]*y + t->m[8]*z;
    result[1] = t->m[1]*x + t->m[5]*y + t->m[9]*z;
    result[2] = t->m[2]*x + t->m[6]*y + t->m[10]*z;
}

/* Vector operations */
static void m3g_vec3_normalize(float* v) {
    float len = sqrtf(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    if (len > 0.0001f) {
        v[0] /= len; v[1] /= len; v[2] /= len;
    }
}

__attribute__((unused))
static void m3g_vec3_cross(float* result, const float* a, const float* b) {
    result[0] = a[1]*b[2] - a[2]*b[1];
    result[1] = a[2]*b[0] - a[0]*b[2];
    result[2] = a[0]*b[1] - a[1]*b[0];
}

static float m3g_vec3_dot(const float* a, const float* b) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

/* ============================================================================
 * M3G Software Rasterizer
 * ============================================================================ */

/* Free existing context buffers - call before reinitializing */
static void m3g_context_free_buffers(void) {
    if (g_m3g.color_buffer) {
        free(g_m3g.color_buffer);
        g_m3g.color_buffer = NULL;
    }
    if (g_m3g.depth_buffer) {
        free(g_m3g.depth_buffer);
        g_m3g.depth_buffer = NULL;
    }
    g_m3g.buffers_allocated = 0;
}

/* Initialize render pool for object reuse */
static void m3g_render_pool_init(void) {
    if (g_m3g.render_pool.initialized) {
        return;  /* Already initialized */
    }
    
    g_m3g.render_pool.vertex_pool = (float*)malloc(M3G_VERTEX_POOL_SIZE * sizeof(float));
    g_m3g.render_pool.vertex_pool_capacity = g_m3g.render_pool.vertex_pool ? M3G_VERTEX_POOL_SIZE : 0;
    g_m3g.render_pool.vertex_pool_used = 0;
    
    g_m3g.render_pool.index_pool = (uint16_t*)malloc(M3G_INDEX_POOL_SIZE * sizeof(uint16_t));
    g_m3g.render_pool.index_pool_capacity = g_m3g.render_pool.index_pool ? M3G_INDEX_POOL_SIZE : 0;
    g_m3g.render_pool.index_pool_used = 0;
    
    g_m3g.render_pool.initialized = 1;
    GFX_DEBUG("Render pool initialized: vertices=%zu, indices=%zu", 
             g_m3g.render_pool.vertex_pool_capacity, g_m3g.render_pool.index_pool_capacity);
}

/* Reset render pool for new frame */
static void m3g_render_pool_reset(void) {
    g_m3g.render_pool.vertex_pool_used = 0;
    g_m3g.render_pool.index_pool_used = 0;
}

/* Allocate from vertex pool (returns NULL if pool exhausted) */
static float* m3g_render_pool_alloc_vertices(size_t count) {
    if (g_m3g.render_pool.vertex_pool_used + count > g_m3g.render_pool.vertex_pool_capacity) {
        /* v26 (audit item: silent disappearance): loud rate-limited warning —
         * a NULL here means the mesh is SKIPPED silently, which historically
         * looked like "parts of the picture vanish with no trace in the log". */
        static int pool_warn = 0;
        if (pool_warn < 5) {
            pool_warn++;
            fprintf(stderr, "[M3G-WARN] vertex pool exhausted: need %zu, have %zu — mesh DROPPED this frame\n",
                    count, g_m3g.render_pool.vertex_pool_capacity - g_m3g.render_pool.vertex_pool_used);
        }
        GFX_DEBUG("Vertex pool exhausted: need %zu, have %zu",
                 count, g_m3g.render_pool.vertex_pool_capacity - g_m3g.render_pool.vertex_pool_used);
        return NULL;
    }
    float* ptr = g_m3g.render_pool.vertex_pool + g_m3g.render_pool.vertex_pool_used;
    g_m3g.render_pool.vertex_pool_used += count;
    return ptr;
}

/* Allocate from index pool (returns NULL if pool exhausted) */
__attribute__((unused)) static uint16_t* m3g_render_pool_alloc_indices(size_t count) {
    if (g_m3g.render_pool.index_pool_used + count > g_m3g.render_pool.index_pool_capacity) {
        GFX_DEBUG("Index pool exhausted: need %zu, have %zu", 
                 count, g_m3g.render_pool.index_pool_capacity - g_m3g.render_pool.index_pool_used);
        return NULL;
    }
    uint16_t* ptr = g_m3g.render_pool.index_pool + g_m3g.render_pool.index_pool_used;
    g_m3g.render_pool.index_pool_used += count;
    return ptr;
}

/* Initialize M3G context */
static void m3g_context_init(int width, int height) {
    /* FIX: Free existing buffers before allocating new ones to prevent memory leak */
    m3g_context_free_buffers();
    
    /* Preserve render pool and camera state across reinit */
    M3GRenderPool saved_pool = g_m3g.render_pool;
    JavaObject* saved_camera = g_m3g.camera;
    M3GTransform saved_cam_transform = g_m3g.camera_transform;
    M3GTransform saved_cam_inverse = g_m3g.camera_inverse;
    int saved_camera_set = g_m3g.camera_set;
    
    /* Clear context (zeroes all fields including target_image, target_gfx, target_is_graphics) */
    memset(&g_m3g, 0, sizeof(g_m3g));
    
    /* Restore render pool — only if it was previously initialized.
     * If saved_pool.initialized == 0, all pointers are NULL and the pool
     * will be re-initialized by m3g_render_pool_init() below. */
    if (saved_pool.initialized) {
        g_m3g.render_pool = saved_pool;
        /* v15 CRITICAL FIX: reset the pool usage counters for the new frame.
         * m3g_context_init() runs at the START of every rendered frame
         * (bindTarget 1-arg/3-arg and force-render are the only callers),
         * but previously the used counters were preserved across frames —
         * only m3g_force_render() reset them. The 64K-float vertex pool
         * (M3G_VERTEX_POOL_SIZE) was therefore a ONE-SHOT budget for the
         * whole session: every mesh of every frame bump-allocated its
         * vertices and nothing ever freed them. Once exhausted,
         * m3g_render_pool_alloc_vertices() returned NULL and
         * m3g_render_single_mesh() silently skipped the mesh (no log!),
         * so all M3G content progressively vanished mid-session —
         * M3GTest scenes 3+ rendered only the clear color ("black
         * screen after test 2" on Windows). Resetting here makes the
         * pool frame-scoped as intended. */
        g_m3g.render_pool.vertex_pool_used = 0;
        g_m3g.render_pool.index_pool_used = 0;
    }
    
    /* Restore camera state (preserved across buffer reallocation) */
    g_m3g.camera = saved_camera;
    g_m3g.camera_transform = saved_cam_transform;
    g_m3g.camera_inverse = saved_cam_inverse;
    g_m3g.camera_set = saved_camera_set;
    
    g_m3g.buffer_width = width;
    g_m3g.buffer_height = height;
    g_m3g.viewport_width = width;
    g_m3g.viewport_height = height;
    
    g_m3g.color_buffer = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    g_m3g.depth_buffer = (float*)calloc(width * height, sizeof(float));
    
    if (g_m3g.color_buffer && g_m3g.depth_buffer) {
        g_m3g.buffers_allocated = 1;
    }
    
    /* Initialize transforms */
    m3g_transform_identity(&g_m3g.modelview);
    m3g_transform_identity(&g_m3g.projection);
    m3g_transform_identity(&g_m3g.mvp);
    
    /* Default render state */
    g_m3g.depth_test_enabled = 1;
    g_m3g.depth_write_enabled = 1;
    g_m3g.culling_enabled = 1;
    
    /* Default ambient */
    g_m3g.ambient_light[0] = 0.2f;
    g_m3g.ambient_light[1] = 0.2f;
    g_m3g.ambient_light[2] = 0.2f;
    g_m3g.ambient_light[3] = 1.0f;
    
    /* Initialize render pool if not already done */
    m3g_render_pool_init();
    
    GFX_DEBUG("Context initialized: %dx%d, buffers=%d", width, height, g_m3g.buffers_allocated);
}

/* v25 FIX (Brick Breaker background flicker): seed the fresh 3D color buffer
 * with the CURRENT content of the bound Graphics surface.
 *
 * JSR-184 bindTarget(Graphics) means "render the 3D scene ONTO this
 * surface": on real phones the 3D pipeline draws directly over whatever 2D
 * content the game has already drawn (background image, HUD). Our software
 * pipeline renders into a separate g_m3g.color_buffer and releaseTarget()
 * blits the WHOLE buffer back over gfx->pixels. With a calloc'd (black)
 * buffer that blit ERASED the game's 2D background every frame, and where no
 * geometry was drawn (or with alpha-blended pixels) stale BLACK showed
 * instead of the background — the reported "background appears over the 3D /
 * background missing" flicker (which pixels win alternates per frame with
 * alpha blending / depth-cleared passes).
 *
 * Seeding at bind time makes the color buffer start as a copy of the canvas,
 * so 3D renders on top of the real 2D content and the releaseTarget blit
 * restores "2D background + 3D scene" exactly like real hardware. */
static void m3g_seed_color_buffer_from_gfx(void) {
    if (!g_m3g.color_buffer || !g_m3g.target_is_graphics || !g_m3g.target_gfx) return;
    MidpGraphics* gfx = g_m3g.target_gfx;
    if (!gfx->pixels || gfx->width <= 0 || gfx->height <= 0) return;
    int w = g_m3g.buffer_width < gfx->width ? g_m3g.buffer_width : gfx->width;
    int h = g_m3g.buffer_height < gfx->height ? g_m3g.buffer_height : gfx->height;
    for (int y = 0; y < h; y++) {
        memcpy(g_m3g.color_buffer + (size_t)y * g_m3g.buffer_width,
               gfx->pixels + (size_t)y * gfx->width,
               (size_t)w * sizeof(uint32_t));
    }
}

/* Clear buffers - optimized to avoid per-iteration multiplication */
M3G_HOT static void m3g_clear_ex(float r, float g, float b, float a, float depth,
                                 int clear_color, int clear_depth) {
    /* v20 FIX (JSR-184 Background / FIX-21 semantics): Graphics3D.clear must
     * honor Background.colorClearEnable / depthClearEnable instead of
     * unconditionally overwriting both buffers. */
    if (!clear_color && !clear_depth) return;
    uint32_t color = ((uint32_t)(a * 255) << 24) |
                     ((uint32_t)(r * 255) << 16) |
                     ((uint32_t)(g * 255) << 8) |
                     ((uint32_t)(b * 255));
    
    int total = g_m3g.buffer_width * g_m3g.buffer_height;
    uint32_t* cb = g_m3g.color_buffer;
    float* db = g_m3g.depth_buffer;
    if (clear_color && clear_depth) {
        for (int i = 0; i < total; i++) {
            cb[i] = color;
            db[i] = depth;
        }
    } else if (clear_color) {
        for (int i = 0; i < total; i++) cb[i] = color;
    } else {
        for (int i = 0; i < total; i++) db[i] = depth;
    }
}

/* Convert clip coordinates to screen coordinates.
 * Returns 0 on success, -1 if vertex is behind near plane (w <= 0). */
static int m3g_clip_to_screen(float* screen, const float* clip) {
    /* Perspective divide - reject vertices behind camera.
     * v24 FIX (Brick Breaker black screen): also reject on the REAL near-plane
     * criterion z + w < 0 (OpenGL convention: -w <= z <= w). Vertices between
     * the eye and the near plane have w > 0 but z + w < 0; with the old
     * w-only test they passed here and produced NDC z ~ -300000 garbage
     * depths that made the rasterizer discard whole corridor walls when the
     * camera sat inside the geometry. */
    float w = clip[3];
    if (w < 0.001f) return -1;  /* Behind the eye */
    if (clip[2] + w < 0.0f) return -1;  /* v24: in front of eye but before near plane */
    
    float ndc_x = clip[0] / w;
    float ndc_y = clip[1] / w;
    float ndc_z = clip[2] / w;
    
    /* NDC to screen */
    screen[0] = (ndc_x + 1.0f) * 0.5f * g_m3g.viewport_width + g_m3g.viewport_x;
    screen[1] = (1.0f - ndc_y) * 0.5f * g_m3g.viewport_height + g_m3g.viewport_y;  /* Y-flip */
    screen[2] = (ndc_z + 1.0f) * 0.5f;  /* Depth to [0,1] */
    screen[3] = 1.0f / w;  /* 1/w for perspective correction */
    return 0;
}

/* Near-plane clip threshold: the near plane is the OpenGL set { z + w >= 0 }.
 * v24 FIX: the old threshold tested w alone (w >= 0.001), which let vertices
 * between the eye and the near plane (w > 0, z + w < 0) through unclipped.
 * We keep a small positive w floor as a degenerate-sliver guard on top of the
 * exact plane test. */
#define M3G_NEAR_CLIP_W  0.001f
#define M3G_NEAR_CLIP_ZW 0.0f

/* Interpolate between two clip-space vertices (linearly in clip space).
 * Used by Sutherland-Hodgman clipping. Also interpolates colors and texcoords. */
static void m3g_lerp_clip(float* out_clip, uint8_t* out_color, float* out_tex,
                           const float* in_clip0, const uint8_t* in_color0, const float* in_tex0,
                           const float* in_clip1, const uint8_t* in_color1, const float* in_tex1,
                           float t) {
    float s = 1.0f - t;
    out_clip[0] = s * in_clip0[0] + t * in_clip1[0];
    out_clip[1] = s * in_clip0[1] + t * in_clip1[1];
    out_clip[2] = s * in_clip0[2] + t * in_clip1[2];
    out_clip[3] = s * in_clip0[3] + t * in_clip1[3];
    if (out_color && in_color0 && in_color1) {
        out_color[0] = (uint8_t)(s * in_color0[0] + t * in_color1[0] + 0.5f);
        out_color[1] = (uint8_t)(s * in_color0[1] + t * in_color1[1] + 0.5f);
        out_color[2] = (uint8_t)(s * in_color0[2] + t * in_color1[2] + 0.5f);
        out_color[3] = (uint8_t)(s * in_color0[3] + t * in_color1[3] + 0.5f);
    }
    if (out_tex && in_tex0 && in_tex1) {
        out_tex[0] = s * in_tex0[0] + t * in_tex1[0];
        out_tex[1] = s * in_tex0[1] + t * in_tex1[1];
    }
}

/* Clip a triangle against the eye plane (w >= M3G_NEAR_CLIP_W) AND the near
 * plane (z + w >= M3G_NEAR_CLIP_ZW).
 *
 * v25 FIX (Brick Breaker missing wedges / background flicker): the v24 code
 * clipped against z + w >= 0 ONLY. A triangle spanning the EYE plane can have
 * its z + w = 0 crossing point BEHIND the eye (w < 0):
 *   A=(z=-5, w=6) inside, B=(z=900, w=-1000) outside
 *   -> t = d_A/(d_A - d_B) = 1/101 -> crossing w = 6 + (1/101)(-1006) < 0.
 * The crossing vertex was emitted, m3g_clip_to_screen() rejected it
 * (w < 0.001) and the WHOLE clipped triangle was dropped from inside
 * m3g_rasterize_triangle: large fan/wall triangles near the camera vanished
 * as rotating wedges -> frame-to-frame background flicker.
 *
 * Correct pipeline: Sutherland-Hodgman against BOTH planes — first the eye
 * plane (w >= eps), then the near plane (z + w >= 0). After the eye-plane
 * pass every surviving vertex has w >= eps, so near-plane crossing points are
 * guaranteed w >= eps and clip_to_screen accepts them. The clipped polygon
 * (up to 5 vertices) is fan-triangulated (max 3 output triangles).
 * Winding order is preserved by both the S-H clip and the fan triangulation,
 * so back-face culling stays correct. */
static int m3g_clip_triangle_near(const float* in_clip[3], const uint8_t* in_color[3], const float* in_tex[3],
                                    float out_clip[9][4], uint8_t out_color[9][4], float out_tex[9][2]) {
    float poly_c[8][4];
    uint8_t poly_col[8][4];
    float poly_tex[8][2];
    float tmp_c[8][4];
    uint8_t tmp_col[8][4];
    float tmp_tex[8][2];
    int has_color = (in_color[0] != NULL);
    int has_tex = (in_tex[0] != NULL);

    /* Seed the working polygon with the input triangle (cyclic order kept) */
    int n = 3;
    for (int i = 0; i < 3; i++) {
        memcpy(poly_c[i], in_clip[i], 4 * sizeof(float));
        if (has_color) memcpy(poly_col[i], in_color[i], 4);
        if (has_tex) memcpy(poly_tex[i], in_tex[i], 2 * sizeof(float));
    }

    /* Pass 0: eye plane  d = w - eps >= 0   (kills w < eps geometry)
     * Pass 1: near plane d = z + w - 0 >= 0 (true near-plane test) */
    for (int pass = 0; pass < 2; pass++) {
        float eps = (pass == 0) ? M3G_NEAR_CLIP_W : M3G_NEAR_CLIP_ZW;
        int m = 0;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            const float* a = poly_c[i];
            const float* b = poly_c[j];
            float da = (pass == 0) ? (a[3] - eps) : (a[2] + a[3] - eps);
            float db = (pass == 0) ? (b[3] - eps) : (b[2] + b[3] - eps);
            int a_in = (da >= 0.0f);
            int b_in = (db >= 0.0f);
            if (a_in) {
                memcpy(tmp_c[m], a, 4 * sizeof(float));
                if (has_color) memcpy(tmp_col[m], poly_col[i], 4);
                if (has_tex) memcpy(tmp_tex[m], poly_tex[i], 2 * sizeof(float));
                m++;
            }
            if (a_in != b_in) {
                float t = da / (da - db);
                m3g_lerp_clip(tmp_c[m],
                              has_color ? tmp_col[m] : NULL,
                              has_tex ? tmp_tex[m] : NULL,
                              a, has_color ? poly_col[i] : NULL, has_tex ? poly_tex[i] : NULL,
                              b, has_color ? poly_col[j] : NULL, has_tex ? poly_tex[j] : NULL,
                              t);
                m++;
            }
            if (m >= 8) return 0;  /* unreachable for <=2 passes; safety */
        }
        if (m == 0) return 0;
        memcpy(poly_c, tmp_c, sizeof(float) * 4 * m);
        if (has_color) memcpy(poly_col, tmp_col, 4 * m);
        if (has_tex) memcpy(poly_tex, tmp_tex, sizeof(float) * 2 * m);
        n = m;
    }

    /* Fan-triangulate the clipped polygon: (p0, pi, pi+1) */
    int num_tris = n - 2;
    for (int ct = 0; ct < num_tris; ct++) {
        memcpy(out_clip[ct * 3 + 0], poly_c[0], 4 * sizeof(float));
        memcpy(out_clip[ct * 3 + 1], poly_c[ct + 1], 4 * sizeof(float));
        memcpy(out_clip[ct * 3 + 2], poly_c[ct + 2], 4 * sizeof(float));
        if (has_color) {
            memcpy(out_color[ct * 3 + 0], poly_col[0], 4);
            memcpy(out_color[ct * 3 + 1], poly_col[ct + 1], 4);
            memcpy(out_color[ct * 3 + 2], poly_col[ct + 2], 4);
        }
        if (has_tex) {
            memcpy(out_tex[ct * 3 + 0], poly_tex[0], 2 * sizeof(float));
            memcpy(out_tex[ct * 3 + 1], poly_tex[ct + 1], 2 * sizeof(float));
            memcpy(out_tex[ct * 3 + 2], poly_tex[ct + 2], 2 * sizeof(float));
        }
    }
    return num_tris;
}

/* Diagnostic counter for debugging */
static int g_m3g_clip_triangles_in = 0;
static int g_m3g_clip_triangles_out = 0;
static int g_m3g_raster_pixels_written = 0;

/* Edge function for triangle rasterization */
static inline float m3g_edge_function(const float* a, const float* b, const float* c) {
    return (c[0] - a[0]) * (b[1] - a[1]) - (c[1] - a[1]) * (b[0] - a[0]);
}

/* Compute barycentric coordinates */
__attribute__((unused))
static void m3g_barycentric(float* bary, const float* v0, const float* v1, 
                            const float* v2, float x, float y) {
    float area = m3g_edge_function(v0, v1, v2);
    if (fabsf(area) < 0.0001f) {
        bary[0] = bary[1] = bary[2] = 0;
        return;
    }
    
    float p[2] = {x, y};
    bary[0] = m3g_edge_function(v1, v2, p) / area;
    bary[1] = m3g_edge_function(v2, v0, p) / area;
    bary[2] = m3g_edge_function(v0, v1, p) / area;
}

/* Simple color interpolation.
 * v14 FIX: perspective-correct — colors are interpolated as c/w divided by
 * interpolated 1/w. Screen-linear color interpolation caused visible color
 * distortion across large faces spanning depth (M3GTest scenes). */
static void m3g_interpolate_color(uint8_t* result,
                                   const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                   float w0, float w1, float w2,
                                   float iw0, float iw1, float iw2) {
    float denom = iw0 * w0 + iw1 * w1 + iw2 * w2;
    if (denom <= 1e-9f) {
        /* Degenerate (shouldn't happen: all iw > 0, barycentrics >= 0) */
        for (int i = 0; i < 4; i++) {
            result[i] = (uint8_t)(c0[i] * w0 + c1[i] * w1 + c2[i] * w2);
        }
        return;
    }
    for (int i = 0; i < 4; i++) {
        float v = (c0[i] * iw0 * w0 + c1[i] * iw1 * w1 + c2[i] * iw2 * w2) / denom;
        if (v < 0.0f) v = 0.0f;
        if (v > 255.0f) v = 255.0f;
        result[i] = (uint8_t)(v + 0.5f);
    }
}

/* Interpolate texture coordinates.
 * v14 CRITICAL FIX: this was the root cause of "black cube" (Nescube) and
 * wrong/stretched textures (SU30, M3GTest scene 4). The old code
 * interpolated RAW u,v linearly in SCREEN space and then multiplied by the
 * interpolated 1/w:  u = (Σ bary_i*u_i) * (Σ bary_i*1/W_i)  — which both
 * scales the whole UV set by ~1/W (at view distance 30 the entire texture
 * collapsed into the first 3% of texels) and distorts it nonlinearly
 * across the face ("back faces look bigger than front faces").
 *
 * Correct perspective-correct interpolation:
 *   u = (Σ bary_i * u_i/W_i) / (Σ bary_i * 1/W_i)
 * where iw0/iw1/iw2 are the per-vertex 1/w_clip values (screen[3] from
 * m3g_clip_to_screen). */
static void m3g_interpolate_texcoord(float* result,
                                      const float* t0, const float* t1, const float* t2,
                                      float w0, float w1, float w2,
                                      float iw0, float iw1, float iw2) {
    float denom = iw0 * w0 + iw1 * w1 + iw2 * w2;
    if (denom <= 1e-9f) {
        result[0] = t0[0];
        result[1] = t0[1];
        return;
    }
    result[0] = (t0[0] * iw0 * w0 + t1[0] * iw1 * w1 + t2[0] * iw2 * w2) / denom;
    result[1] = (t0[1] * iw0 * w0 + t1[1] * iw1 * w1 + t2[1] * iw2 * w2) / denom;
}

/* Sample texture (bilinear filtering) */
static uint32_t m3g_sample_texture(M3GTexture2D* tex, float u, float v) {
    if (!tex || !tex->pixels || tex->width <= 0 || tex->height <= 0) return 0xFFFFFFFF;
    
    /* Guard against NaN / Inf from extreme perspective division.
     * When w is near zero or negative, UV interpolation produces NaN,
     * and (int)NaN is undefined behavior (typically INT_MIN on x86),
     * leading to out-of-bounds access and SIGSEGV. */
    if (u != u || v != v ||           /* isnan */
        u == 1.0f/0.0f || u == -1.0f/0.0f ||  /* isinf */
        v == 1.0f/0.0f || v == -1.0f/0.0f) {
        return 0xFFFFFFFF;  /* Return white for invalid coords */
    }
    
    /* v23: wrap modes — internal blend_s/blend_t: 1 = WRAP_CLAMP(240),
     * 0 = WRAP_REPEAT(241, legacy default). */
    if (tex->blend_s) {
        if (u < 0.0f) u = 0.0f;
        if (u > 1.0f) u = 0.999999f;
    } else {
        u = u - floorf(u);
        if (u < 0) u += 1.0f;
        if (u >= 1.0f) u = 0.999999f;
    }
    if (tex->blend_t) {
        if (v < 0.0f) v = 0.0f;
        if (v > 1.0f) v = 0.999999f;
    } else {
        v = v - floorf(v);
        if (v < 0) v += 1.0f;
        if (v >= 1.0f) v = 0.999999f;
    }
    
    /* v23: FILTER_LINEAR(209)/FILTER_TRILINEAR(211) → bilinear on the base
     * level; FILTER_BASE_LEVEL(208)/legacy → nearest (unchanged path). */
    if (tex->filter_level == 209 || tex->filter_level == 211) {
        float fx = u * (float)tex->width - 0.5f;
        float fy = v * (float)tex->height - 0.5f;
        if (fx < 0.0f) fx = 0.0f;
        if (fy < 0.0f) fy = 0.0f;
        int x0 = (int)fx;
        int y0 = (int)fy;
        int x1 = x0 + 1;
        int y1 = y0 + 1;
        if (x0 >= tex->width) x0 = tex->width - 1;
        if (y0 >= tex->height) y0 = tex->height - 1;
        if (x1 >= tex->width) x1 = tex->width - 1;
        if (y1 >= tex->height) y1 = tex->height - 1;
        float frac_x = fx - (float)x0;
        float frac_y = fy - (float)y0;
        if (frac_x < 0.0f) frac_x = 0.0f;
        if (frac_x > 1.0f) frac_x = 1.0f;
        if (frac_y < 0.0f) frac_y = 0.0f;
        if (frac_y > 1.0f) frac_y = 1.0f;

        const uint32_t* px = tex->pixels;
        uint32_t t00 = px[y0 * tex->width + x0];
        uint32_t t10 = px[y0 * tex->width + x1];
        uint32_t t01 = px[y1 * tex->width + x0];
        uint32_t t11 = px[y1 * tex->width + x1];

        float r0 = (float)(t00 & 0xFF) + ((float)(t10 & 0xFF) - (float)(t00 & 0xFF)) * frac_x;
        float g0 = (float)((t00 >> 8) & 0xFF) + ((float)((t10 >> 8) & 0xFF) - (float)((t00 >> 8) & 0xFF)) * frac_x;
        float b0 = (float)((t00 >> 16) & 0xFF) + ((float)((t10 >> 16) & 0xFF) - (float)((t00 >> 16) & 0xFF)) * frac_x;
        float a0 = (float)((t00 >> 24) & 0xFF) + ((float)((t10 >> 24) & 0xFF) - (float)((t00 >> 24) & 0xFF)) * frac_x;
        float r1 = (float)(t01 & 0xFF) + ((float)(t11 & 0xFF) - (float)(t01 & 0xFF)) * frac_x;
        float g1 = (float)((t01 >> 8) & 0xFF) + ((float)((t11 >> 8) & 0xFF) - (float)((t01 >> 8) & 0xFF)) * frac_x;
        float b1 = (float)((t01 >> 16) & 0xFF) + ((float)((t11 >> 16) & 0xFF) - (float)((t01 >> 16) & 0xFF)) * frac_x;
        float a1 = (float)((t01 >> 24) & 0xFF) + ((float)((t11 >> 24) & 0xFF) - (float)((t01 >> 24) & 0xFF)) * frac_x;

        int r = (int)(r0 + (r1 - r0) * frac_y + 0.5f);
        int g = (int)(g0 + (g1 - g0) * frac_y + 0.5f);
        int b = (int)(b0 + (b1 - b0) * frac_y + 0.5f);
        int a = (int)(a0 + (a1 - a0) * frac_y + 0.5f);
        if (r < 0) r = 0;
        if (r > 255) r = 255;
        if (g < 0) g = 0;
        if (g > 255) g = 255;
        if (b < 0) b = 0;
        if (b > 255) b = 255;
        if (a < 0) a = 0;
        if (a > 255) a = 255;
        /* Texture pixel layout is ARGB (A<<24 | R<<16 | G<<8 | B) — same as
         * the Image2D builders above. */
        return ((uint32_t)a << 24) | ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
    }
    
    /* Nearest neighbor (simple version) */
    int x = (int)(u * tex->width);
    int y = (int)(v * tex->height);
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x >= tex->width) x = tex->width - 1;
    if (y >= tex->height) y = tex->height - 1;
    
    return tex->pixels[y * tex->width + x];
}

/* Fast specular approximation using exp2(log2(x) * y).
 * On ARMv7 without FPU, powf() costs ~50+ cycles calling into libm.
 * exp2f(log2f(x) * y) compiles to ~6 VFP instructions.
 * Returns 0 for non-positive inputs (no negative specular highlights). */
M3G_INLINE float m3g_fast_specular(float ndh, float shininess) {
    if (ndh <= 0.0f) return 0.0f;
    if (shininess <= 1.0f) return ndh;
    /* Use exp2(log2(x) * y) — much cheaper than powf on ARM */
    return exp2f(log2f(ndh) * shininess);
}

/* Task 16-a: Gouraud (per-vertex) lighting, JSR-184 §Light/Material semantics.
 * position/normal are in VIEW (eye) space; V is (0,0,1).
 *   result = emissive
 *          + sum(AMBIENT lights) * material.ambient
 *          + sum(other lights) * [ diffuse * max(0,N.L) + specular * max(0,N.H)^shininess ]
 *            * lightColor * intensity * distanceAttenuation [ * spotFactor ]
 * Only called when g_m3g_active_light_count > 0 (see the unlit-path guard in
 * m3g_render_single_mesh) — with no lights the legacy vertex color path is
 * used untouched, keeping Nescube/M3GTest output byte-identical. */
static void m3g_light_vertex(float* result, const float* position,
                              const float* normal, const M3GMaterial* mat,
                              int two_sided) {
    /* Start with emissive; AMBIENT-type lights add material.ambient below. */
    result[0] = mat->emissive[0];
    result[1] = mat->emissive[1];
    result[2] = mat->emissive[2];

    float N[3] = {normal[0], normal[1], normal[2]};
    m3g_vec3_normalize(N);

    for (int i = 0; i < g_m3g_active_light_count && i < M3G_MAX_ACTIVE_LIGHTS; i++) {
        const M3GLight* light = &g_m3g_active_lights[i];

        float lr = light->color[0] * light->color[3]; /* color * intensity */
        float lg = light->color[1] * light->color[3];
        float lb = light->color[2] * light->color[3];

        if (light->type == M3G_LIGHT_AMBIENT) {
            result[0] += lr * mat->ambient[0];
            result[1] += lg * mat->ambient[1];
            result[2] += lb * mat->ambient[2];
            continue;
        }

        float L[3];        /* Unit vector towards the light (view space) */
        float attenuation = 1.0f;
        float spot_factor = 1.0f;

        if (light->type == M3G_LIGHT_DIRECTIONAL) {
            L[0] = -light->view_dir[0];
            L[1] = -light->view_dir[1];
            L[2] = -light->view_dir[2];
            m3g_vec3_normalize(L);
        } else if (light->type == M3G_LIGHT_OMNI || light->type == M3G_LIGHT_SPOT) {
            L[0] = light->view_pos[0] - position[0];
            L[1] = light->view_pos[1] - position[1];
            L[2] = light->view_pos[2] - position[2];
            float dist = sqrtf(L[0]*L[0] + L[1]*L[1] + L[2]*L[2]);
            if (dist > 0.0001f) {
                L[0] /= dist; L[1] /= dist; L[2] /= dist;
            } else {
                continue;
            }
            /* JSR-184 distance attenuation 1/(kc + kl*d + kq*d^2) */
            float kc = light->attenuation[0];
            float kl = light->attenuation[1];
            float kq = light->attenuation[2];
            float denom = kc + kl * dist + kq * dist * dist;
            if (denom <= 0.0001f) denom = 1.0f; /* all-zero params: no falloff */
            attenuation = 1.0f / denom;

            if (light->type == M3G_LIGHT_SPOT) {
                /* Spot cone: light shines along view_dir; only fragments
                 * within spotAngle of the axis are lit (degrees). */
                float spot_dir[3] = { light->view_dir[0], light->view_dir[1], light->view_dir[2] };
                m3g_vec3_normalize(spot_dir);
                float cos_axis = -(L[0]*spot_dir[0] + L[1]*spot_dir[1] + L[2]*spot_dir[2]);
                float half_angle = light->spot_angle * 0.5f * 3.14159265f / 180.0f;
                float cos_cutoff = cosf(half_angle);
                if (cos_axis < cos_cutoff) {
                    continue; /* Outside the cone */
                }
                if (light->spot_exponent > 0.0f && cos_axis > 0.0f) {
                    spot_factor = m3g_fast_specular(cos_axis, light->spot_exponent);
                }
            }
        } else {
            continue; /* Unknown type */
        }

        /* Diffuse */
        float NdotL = m3g_vec3_dot(N, L);
        if (two_sided && NdotL < 0.0f) NdotL = -NdotL;
        if (NdotL > 0.0f) {
            result[0] += lr * mat->diffuse[0] * NdotL * attenuation * spot_factor;
            result[1] += lg * mat->diffuse[1] * NdotL * attenuation * spot_factor;
            result[2] += lb * mat->diffuse[2] * NdotL * attenuation * spot_factor;
        }

        /* Specular (Blinn half-vector with V=(0,0,1) in view space) */
        float V[3] = {0, 0, 1};
        float H[3];
        H[0] = L[0] + V[0];
        H[1] = L[1] + V[1];
        H[2] = L[2] + V[2];
        m3g_vec3_normalize(H);

        float NdotH = m3g_vec3_dot(N, H);
        if (two_sided && NdotH < 0.0f) NdotH = -NdotH;
        if (NdotH > 0.0f) {
            float spec = m3g_fast_specular(NdotH, mat->shininess);
            result[0] += lr * mat->specular[0] * spec * attenuation * spot_factor;
            result[1] += lg * mat->specular[1] * spec * attenuation * spot_factor;
            result[2] += lb * mat->specular[2] * spec * attenuation * spot_factor;
        }
    }

    /* Clamp */
    result[0] = result[0] < 0.0f ? 0.0f : (result[0] > 1.0f ? 1.0f : result[0]);
    result[1] = result[1] < 0.0f ? 0.0f : (result[1] > 1.0f ? 1.0f : result[1]);
    result[2] = result[2] < 0.0f ? 0.0f : (result[2] > 1.0f ? 1.0f : result[2]);
}

/* ============================================================================
 * Task 16-a: light collection (scene traversal + immediate-mode seeding)
 * ============================================================================ */

/* Evaluate a light's view-space position/direction from its world transform
 * (light->transform when set by addLight, or the Light node's composed
 * transform during traversal). Direction convention: a Light shines along
 * its local -Z axis (JSR-184 §Light); an explicit Light.setDirection value
 * (stored in dirX/dirY/dirZ) overrides the axis. */
static void m3g_light_eval_view(M3GLight* light, const M3GTransform* view) {
    const M3GTransform* w = light->has_transform ? &light->transform : view;
    if (!w) {
        light->view_pos[0] = light->view_pos[1] = 0.0f;
        light->view_pos[2] = 0.0f;
        light->view_dir[0] = 0.0f; light->view_dir[1] = 0.0f; light->view_dir[2] = -1.0f;
        return;
    }
    /* View-space position = view * world * origin */
    light->view_pos[0] = w->m[12];
    light->view_pos[1] = w->m[13];
    light->view_pos[2] = w->m[14];
    /* Local direction -> view space via the rotation part */
    float dx = light->direction[0], dy = light->direction[1], dz = light->direction[2];
    if (dx == 0.0f && dy == 0.0f && dz == 0.0f) {
        /* Default: local -Z axis */
        light->view_dir[0] = -w->m[2];
        light->view_dir[1] = -w->m[6];
        light->view_dir[2] = -w->m[10];
    } else {
        light->view_dir[0] = w->m[0] * dx + w->m[4] * dy + w->m[8]  * dz;
        light->view_dir[1] = w->m[1] * dx + w->m[5] * dy + w->m[9]  * dz;
        light->view_dir[2] = w->m[2] * dx + w->m[6] * dy + w->m[10] * dz;
    }
    m3g_vec3_normalize(light->view_dir);
}

/* Seed the per-render active light list from the immediate-mode
 * Graphics3D.addLight/setLight registrations (g3d_registered slots). */
/* TODO(v24): per FIXES «СЕССИЯ 17в» the immediate-mode render path should
 * seed Graphics3D slot lights here; not wired yet — callers pending. */
__attribute__((unused))
static void m3g_seed_active_lights(void) {
    g_m3g_active_light_count = 0;
    for (int i = 0; i < g_m3g.light_count && g_m3g_active_light_count < M3G_MAX_ACTIVE_LIGHTS; i++) {
        M3GLight* src = &g_m3g.lights[i];
        if (!src->g3d_registered) continue;
        int dst = g_m3g_active_light_count++;
        g_m3g_active_lights[dst] = *src;
        /* view = camera_inverse * light_world_transform */
        M3GTransform view_tf;
        if (src->has_transform) {
            m3g_transform_multiply(&view_tf, &g_m3g.camera_inverse, &src->transform);
            m3g_light_eval_view(&g_m3g_active_lights[dst], &view_tf);
        } else {
            m3g_light_eval_view(&g_m3g_active_lights[dst], &g_m3g.camera_inverse);
        }
    }
}

/* Collect one Light node found during scene traversal. view_tf maps the
 * light's object space to view space (parent modelview * node transform). */
static void m3g_collect_scene_light(JavaObject* light_node, const M3GTransform* view_tf) {
    if (!light_node || g_m3g_active_light_count >= M3G_MAX_ACTIVE_LIGHTS) return;
    if (view_tf && !heap_java_object_valid(light_node)) return;

    /* Skip lights with rendering disabled */
    if (!m3g_get_int_field(light_node, "renderingEnable", 1)) return;

    /* De-duplicate: a Light registered via Graphics3D.addLight AND parented
     * into the scene must not light twice. */
    for (int i = 0; i < g_m3g_active_light_count; i++) {
        if (g_m3g_active_lights[i].obj == light_node) return;
    }

    M3GLight* dst = &g_m3g_active_lights[g_m3g_active_light_count];
    memset(dst, 0, sizeof(M3GLight));
    dst->obj = light_node;

    /* mode: M3G/file encoding 128..131; tolerate our stub API values 0..3 */
    int mode = m3g_get_int_field(light_node, "mode", M3G_LIGHT_MODE_DIRECTIONAL);
    dst->type = m3g_light_mode_to_type(mode);

    jint color_val = m3g_get_int_field(light_node, "color", 0x00FFFFFF);
    dst->color[0] = ((color_val >> 16) & 0xFF) / 255.0f;
    dst->color[1] = ((color_val >> 8) & 0xFF) / 255.0f;
    dst->color[2] = (color_val & 0xFF) / 255.0f;
    dst->color[3] = m3g_get_float_field(light_node, "intensity", 1.0f);

    dst->attenuation[0] = m3g_get_float_field(light_node, "constantAttenuation", 1.0f);
    dst->attenuation[1] = m3g_get_float_field(light_node, "linearAttenuation", 0.0f);
    dst->attenuation[2] = m3g_get_float_field(light_node, "quadraticAttenuation", 0.0f);
    dst->spot_angle = m3g_get_float_field(light_node, "spotAngle", 180.0f);
    dst->spot_exponent = m3g_get_float_field(light_node, "spotExponent", 0.0f);

    /* Explicit direction (Light.setDirection writes dirX/dirY/dirZ) */
    dst->direction[0] = m3g_get_float_field(light_node, "dirX", 0.0f);
    dst->direction[1] = m3g_get_float_field(light_node, "dirY", 0.0f);
    dst->direction[2] = m3g_get_float_field(light_node, "dirZ", 0.0f);

    m3g_light_eval_view(dst, view_tf);
    g_m3g_active_light_count++;
}

/* Build the native lighting material from a Java Appearance's Material.
 * Follows JSR-184 Material defaults: ambient 0x03333333, diffuse 0xFFFFFFFF,
 * specular 0x00000000, emissive 0x00000000, shininess 0. The diffuse==0
 * heuristic maps a zero-initialized stub field to the spec default (an
 * explicitly black diffuse material is essentially never used because it
 * renders invisible). */
static void m3g_build_material_from_java(JavaObject* appearance, M3GMaterial* mat) {
    jint ambient  = 0x03333333;
    jint diffuse  = 0x00FFFFFF;
    jint specular = 0x00000000;
    jint emissive = 0x00000000;

    JavaObject* material = appearance ? m3g_get_ref_field(appearance, "material") : NULL;
    if (material) {
        jint a = m3g_get_int_field(material, "ambient", -1);
        jint d = m3g_get_int_field(material, "diffuse", -1);
        jint s = m3g_get_int_field(material, "specular", -1);
        jint e = m3g_get_int_field(material, "emissive", -1);
        if (a >= 0) ambient = a;
        if (d > 0) diffuse = d;      /* 0 (unset) -> spec default white */
        if (s >= 0) specular = s;
        if (e >= 0) emissive = e;
        mat->shininess = m3g_get_float_field(material, "shininess", 0.0f);
        if (mat->shininess < 0.0f) mat->shininess = 0.0f;
    } else {
        mat->shininess = 0.0f;
    }

    mat->ambient[0] = ((ambient >> 16) & 0xFF) / 255.0f;
    mat->ambient[1] = ((ambient >> 8) & 0xFF) / 255.0f;
    mat->ambient[2] = (ambient & 0xFF) / 255.0f;
    mat->ambient[3] = 1.0f;
    mat->diffuse[0] = ((diffuse >> 16) & 0xFF) / 255.0f;
    mat->diffuse[1] = ((diffuse >> 8) & 0xFF) / 255.0f;
    mat->diffuse[2] = (diffuse & 0xFF) / 255.0f;
    mat->diffuse[3] = 1.0f;
    mat->specular[0] = ((specular >> 16) & 0xFF) / 255.0f;
    mat->specular[1] = ((specular >> 8) & 0xFF) / 255.0f;
    mat->specular[2] = (specular & 0xFF) / 255.0f;
    mat->specular[3] = 1.0f;
    mat->emissive[0] = ((emissive >> 16) & 0xFF) / 255.0f;
    mat->emissive[1] = ((emissive >> 8) & 0xFF) / 255.0f;
    mat->emissive[2] = (emissive & 0xFF) / 255.0f;
    mat->emissive[3] = 1.0f;
}

/* ============================================================================
 * M3G Scene Graph Rendering Helpers
 * ============================================================================ */

/* Build an M3GTransform from a Node's component transform fields.
 * Nodes loaded from M3G files store translation/scale/orientation as individual
 * float fields (set by m3g_read_transformable_data). */
static void m3g_build_node_transform(JavaObject* node, M3GTransform* out) {
    m3g_transform_identity(out);

    if (!node) return;

    /* Check for a general 4x4 transform matrix (stored as float[] in "transform" field) */
    JavaArray* matrix_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (matrix_arr && matrix_arr->element_type == T_FLOAT && matrix_arr->length >= 16) {
        float* m = (float*)array_data(matrix_arr);
        /* DIAG: log for Mesh nodes */
        const char* cn = node->header.clazz && node->header.clazz->class_name ? node->header.clazz->class_name : "?";
        if (strstr(cn, "Mesh") != NULL) {
            fprintf(stderr, "[M3G-NODE-TF] Mesh transform float[16]: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
                m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);
        }
        /* Matrix from M3G file/Java is row-major; convert to column-major */
        m3g_transform_from_rowmajor(out, m);
        return;
    } else if (matrix_arr) {
        const char* cn = node->header.clazz && node->header.clazz->class_name ? node->header.clazz->class_name : "?";
        if (strstr(cn, "Mesh") != NULL) {
            fprintf(stderr, "[M3G-NODE-TF] Mesh transform field type=%d len=%d (not float[16])\n",
                    matrix_arr->element_type, matrix_arr->length);
        }
    }

    /* Build from component transform: T * R * S */
    float tx = m3g_get_float_field(node, "translationX", 0.0f);
    float ty = m3g_get_float_field(node, "translationY", 0.0f);
    float tz = m3g_get_float_field(node, "translationZ", 0.0f);
    float sx = m3g_get_float_field(node, "scaleX", 1.0f);
    float sy = m3g_get_float_field(node, "scaleY", 1.0f);
    float sz = m3g_get_float_field(node, "scaleZ", 1.0f);
    float angle = m3g_get_float_field(node, "orientationAngle", 0.0f);
    float ax = m3g_get_float_field(node, "orientationX", 0.0f);
    float ay = m3g_get_float_field(node, "orientationY", 0.0f);
    float az = m3g_get_float_field(node, "orientationZ", 1.0f);

    /* FIX: M3G files often leave scale at 0.0 when not explicitly set (Java default).
     * Treat scale(0,0,0) as identity (1,1,1) to avoid collapsing the transform.
     * A zero scale is degenerate and would make the entire mesh invisible. */
    if (sx == 0.0f && sy == 0.0f && sz == 0.0f) {
        sx = sy = sz = 1.0f;
    }

    /* Only apply transforms if they differ from defaults */
    int has_transform = (tx != 0.0f || ty != 0.0f || tz != 0.0f ||
                         sx != 1.0f || sy != 1.0f || sz != 1.0f ||
                         angle != 0.0f);

    if (!has_transform) return;

    /* Apply: Scale first, then Rotate, then Translate (post-multiply order) */
    if (sx != 1.0f || sy != 1.0f || sz != 1.0f) {
        m3g_transform_scale(out, sx, sy, sz);
    }
    if (angle != 0.0f) {
        m3g_transform_rotate(out, angle, ax, ay, az);
    }
    if (tx != 0.0f || ty != 0.0f || tz != 0.0f) {
        m3g_transform_translate(out, tx, ty, tz);
    }
    
    /* DIAG: for Mesh nodes, log the final transform */
    {
        const char* cn = node->header.clazz && node->header.clazz->class_name ? node->header.clazz->class_name : "?";
        if (strstr(cn, "Mesh") != NULL) {
            static int mesh_tf_diag = 0;
            if (mesh_tf_diag < 3) {
                mesh_tf_diag++;
                fprintf(stderr, "[M3G-NODE-TF] Mesh final transform: m[0]=%.3f m[5]=%.3f m[10]=%.3f m[15]=%.3f (tx=%.1f ty=%.1f tz=%.1f sx=%.1f sy=%.1f sz=%.1f ang=%.1f has_transform=%d)\n",
                    out->m[0], out->m[5], out->m[10], out->m[15], tx, ty, tz, sx, sy, sz, angle, has_transform);
            }
        }
    }
}

/* ==========================================================================
 * v14: texture pixel (re)load helpers.
 * Mutable Image2D content changes at runtime, so the pixel copy used to
 * happen exactly once per Texture2D. These helpers allow re-copying fresh
 * pixels from the source Image2D into an already-built M3GTexture2D.
 * ======================================================================== */

/* (Re)copy pixel data from a Java Image2D object into a built texture.
 * Handles int[] ARGB arrays (API-created images and parser RGBA/RGB565)
 * and byte[] arrays (parser non-RGBA formats, converted per format field).
 * Returns 1 on successful copy, 0 if there was nothing usable. */
static int m3g_texture_reload_pixels(M3GTexture2D* tex) {
    if (!tex || !tex->source_image) return 0;
    JavaObject* image = tex->source_image;

    int width = m3g_get_int_field(image, "width", tex->width);
    int height = m3g_get_int_field(image, "height", tex->height);
    if (width <= 0 || height <= 0 ||
        width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) return 0;
    int pixel_count = width * height;
    if (pixel_count > M3G_MAX_IMAGE_PIXELS) return 0;

    /* Reallocate if dimensions changed since the last build */
    if (width != tex->width || height != tex->height || !tex->pixels) {
        uint32_t* np = (uint32_t*)realloc(tex->pixels, (size_t)pixel_count * sizeof(uint32_t));
        if (!np) return 0;
        tex->pixels = np;
        tex->width = width;
        tex->height = height;
    }

    JavaArray* pixels = (JavaArray*)m3g_get_ref_field(image, "pixels");
    if (!pixels || pixels->length <= 0) {
        tex->generation = g_m3g_tex_generation;
        return 0;
    }

    if (pixels->element_type == T_INT) {
        jint* src = (jint*)array_data(pixels);
        int copy = (int)pixels->length < pixel_count ? (int)pixels->length : pixel_count;
        for (int i = 0; i < copy; i++) {
            tex->pixels[i] = (uint32_t)src[i];
        }
        /* Zero-fill the rest (if array shrank) so no stale garbage shows */
        for (int i = copy; i < pixel_count; i++) tex->pixels[i] = 0;
    } else if (pixels->element_type == T_BYTE) {
        /* Convert per the Image2D format (M3G binary 0x10-0x14, Java API
         * 0x60-0x64 — same order ALPHA/LUM/LUMA/RGB/RGBA). */
        int fmt = m3g_get_int_field(image, "format", 0x13) & 0xFF;
        int cpp = (fmt == 0x10 || fmt == 0x60) ? 1 :
                  (fmt == 0x12 || fmt == 0x62) ? 2 :
                  (fmt == 0x14 || fmt == 0x64) ? 4 : 3;
        uint8_t* src = (uint8_t*)array_data(pixels);
        int alpha_fmt = (fmt == 0x10 || fmt == 0x60);
        int luma_fmt = (fmt == 0x11 || fmt == 0x61);
        int rgb_fmt = (fmt == 0x13 || fmt == 0x63);
        int rgba_fmt = (fmt == 0x14 || fmt == 0x64);
        (void)luma_fmt;  /* used only for documentation symmetry */
        for (int i = 0; i < pixel_count; i++) {
            int sidx = i * cpp;
            if (sidx + cpp > (int)pixels->length) { tex->pixels[i] = 0; continue; }
            if (rgba_fmt) {
                tex->pixels[i] = ((uint32_t)src[sidx + 3] << 24) |
                                 ((uint32_t)src[sidx] << 16) |
                                 ((uint32_t)src[sidx + 1] << 8) | src[sidx + 2];
            } else if (rgb_fmt) {
                tex->pixels[i] = 0xFF000000u | ((uint32_t)src[sidx] << 16) |
                                 ((uint32_t)src[sidx + 1] << 8) | src[sidx + 2];
            } else if (luma_fmt) {
                uint32_t v = src[sidx];
                tex->pixels[i] = 0xFF000000u | (v << 16) | (v << 8) | v;
            } else if (alpha_fmt) {
                tex->pixels[i] = ((uint32_t)src[sidx] << 24) | 0x00FFFFFFu;
            } else {
                tex->pixels[i] = 0xFF000000u | ((uint32_t)src[sidx] << 16) |
                                 ((uint32_t)src[sidx + 1] << 8) | src[sidx + 2];
            }
        }
    } else {
        tex->generation = g_m3g_tex_generation;
        return 0;
    }

    tex->generation = g_m3g_tex_generation;
    return 1;
}

/* Walk the texture cache and refresh every entry whose source Image2D is
 * the one that just changed (called from m3g_mark_image2d_updated). */
static void m3g_refresh_cached_textures_for_image(JavaObject* image) {
    if (!image) return;
    for (int i = 0; i < g_m3g_texture_cache_count; i++) {
        M3GTexture2D* tex = g_m3g_texture_cache[i].built_tex;
        if (tex && tex->source_image == image && tex->generation != g_m3g_tex_generation) {
            m3g_texture_reload_pixels(tex);
        }
    }
}

/* Build an M3GTexture2D from a Java Texture2D object for the rasterizer */
static M3GTexture2D* m3g_build_texture2d(JavaObject* texture_obj) {
    if (!texture_obj) return NULL;

    /* CACHE CHECK: Return cached texture if available.
     * v14: if the cached texture was built from a mutable Image2D whose
     * content changed since (generation mismatch), refresh its pixels
     * before returning (Nescube updates its cube texture every frame). */
    M3GTexture2D* cached = m3g_lookup_texture_cache(texture_obj);
    if (cached) {
        if (cached->source_image && cached->generation != g_m3g_tex_generation) {
            m3g_texture_reload_pixels(cached);
        }
        return cached;
    }
    if (m3g_texture_build_attempted(texture_obj)) return NULL; /* Already failed */

    const char* tex_class = texture_obj->header.clazz ? texture_obj->header.clazz->class_name : "?";
    static int tex_diag_count = 0;

    /* PRIMARY: Look up Image2D from C-side mapping table.
     * This was populated during M3G file parsing and brute-force pairing,
     * reliable regardless of the Texture2D Java class's field layout. */
    JavaObject* image = m3g_lookup_tex_image(texture_obj);
    int lookup_tier = image ? 1 : 0;

    /* SECONDARY: Try Java field lookup (works if Texture2D class has 'image' field) */
    if (!image) {
        image = m3g_get_ref_field(texture_obj, "image");
        if (image) lookup_tier = 2;
    }

    /* TERTIARY: Try 'imageRef' int field + registry lookup */
    if (!image) {
        int image_ref = m3g_get_int_field(texture_obj, "imageRef", 0);
        if (image_ref > 0) {
            for (int r = 0; r < g_m3g_registry.count; r++) {
                if (g_m3g_registry.userIDs[r] == image_ref) {
                    image = m3g_registry_get(r);
                    if (image) break;
                }
            }
            if (image) {
                lookup_tier = 3;
                fprintf(stderr, "[M3G-TEX] Found Image2D via imageRef=%d -> %p (tier=%d)\n",
                        image_ref, (void*)image, lookup_tier);
            }
        }
    }

    /* QUATERNARY: Direct field scan — look for non-NULL ref fields pointing to Image2D */
    if (!image) {
        int max_slots = OBJECT_NUM_FIELDS(texture_obj);
        for (int s = 0; s < max_slots && s < 24; s++) {
            JavaObject* ref = texture_obj->fields[s].ref;
            if (ref && ref->header.clazz && ref->header.clazz->class_name &&
                strstr(ref->header.clazz->class_name, "Image2D")) {
                image = ref;
                lookup_tier = 4;
                if (tex_diag_count < 10) {
                    tex_diag_count++;
                    fprintf(stderr, "[M3G-TEX] Found Image2D %p via field scan slot %d (tier=%d)\n",
                            (void*)ref, s, lookup_tier);
                }
                break;
            }
        }
    }

    if (!image) {
        if (tex_diag_count < 5) {
            tex_diag_count++;
            fprintf(stderr, "[M3G-TEXBUILD-FAIL] Texture2D %p class=%s inst_size=%d\n",
                    (void*)texture_obj, tex_class,
                    texture_obj->header.clazz ? (int)texture_obj->header.clazz->instance_size : -1);
        }
        m3g_store_texture_cache(texture_obj, NULL); /* Cache the failure */
        return NULL;
    }

    const char* img_class = image->header.clazz ? image->header.clazz->class_name : "?";
    int width = m3g_get_int_field(image, "width", 0);
    int height = m3g_get_int_field(image, "height", 0);

    if (tex_diag_count <= 5) {
        tex_diag_count++;
        fprintf(stderr, "[M3G-TEXBUILD] Texture2D %p -> Image2D %p class=%s %dx%d (tier=%d)\n",
                (void*)texture_obj, (void*)image, img_class, width, height, lookup_tier);
    }

    /* FALLBACK: If dimensions look wrong, scan all slots for reasonable pairs */
    if (width <= 0 || height <= 0 || width > 2048 || height > 2048) {
        int img_slots = OBJECT_NUM_FIELDS(image);
        int best_w = 0, best_h = 0;
        int best_dist = 999999999;
        for (int try_h = 2; try_h < img_slots; try_h++) {
            for (int try_w = 2; try_w < try_h; try_w++) {
                int vw = image->fields[try_w].i;
                int vh = image->fields[try_h].i;
                if (vw > 0 && vw <= 2048 && vh > 0 && vh <= 2048) {
                    int dist = (vw - 64) * (vw - 64) + (vh - 64) * (vh - 64);
                    if (dist < best_dist) {
                        best_dist = dist;
                        best_w = vw;
                        best_h = vh;
                    }
                }
            }
        }
        if (best_w > 0 && best_h > 0) {
            static int fb_count = 0;
            if (fb_count < 3) {
                fb_count++;
                fprintf(stderr, "[M3G-TEXBUILD] Fallback: found plausible dims %dx%d (was %dx%d)\n",
                        best_w, best_h, width, height);
            }
            width = best_w;
            height = best_h;
        }
    }

    /* GUESS: Try to compute from pixels array if still unknown */
    if (width <= 0 || height <= 0) {
        JavaArray* pixels_arr = (JavaArray*)m3g_get_ref_field(image, "pixels");
        if (pixels_arr && pixels_arr->length > 0) {
            int total = (int)pixels_arr->length;
            int side = (int)sqrtf((float)total);
            if (side * side == total) { width = side; height = side; }
            else if (total % 256 == 0) { width = 256; height = total / 256; }
            else if (total % 128 == 0) { width = 128; height = total / 128; }
            else if (total % 64 == 0) { width = 64; height = total / 64; }
            else { width = side; height = total / width; }
            fprintf(stderr, "[M3G-TEXBUILD] Guessed dimensions: %dx%d\n", width, height);
        }
    }

    if (width <= 0 || height <= 0 || width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        fprintf(stderr, "[M3G-TEXBUILD-FAIL] Image2D %s: invalid dimensions %dx%d\n",
                img_class, width, height);
        m3g_store_texture_cache(texture_obj, NULL);
        return NULL;
    }

    int pixel_count = width * height;
    if (pixel_count > M3G_MAX_IMAGE_PIXELS) {
        m3g_store_texture_cache(texture_obj, NULL);
        return NULL;
    }

    M3GTexture2D* tex = (M3GTexture2D*)calloc(1, sizeof(M3GTexture2D));
    if (!tex) {
        m3g_store_texture_cache(texture_obj, NULL);
        return NULL;
    }

    tex->width = width;
    tex->height = height;
    tex->pixels = (uint32_t*)malloc(pixel_count * sizeof(uint32_t));
    if (!tex->pixels) { free(tex); m3g_store_texture_cache(texture_obj, NULL); return NULL; }

    /* v14: remember the source Image2D so its content can be refreshed
     * later (mutable textures — Image2D.set / render-into-Image2D). */
    tex->source_image = image;
    tex->generation = g_m3g_tex_generation;
    tex->blend_color = m3g_get_int_field(texture_obj, "blendColor", 0);
    tex->has_uv_transform = 0;
    /* v23: pick up filter/wrap state from the Java object (defaults = spec:
     * FILTER_BASE_LEVEL → nearest, WRAP_REPEAT — identical to the legacy
     * behavior, so un-configured textures render byte-identically). */
    tex->filter_level = m3g_get_int_field(texture_obj, "filtering", 208);
    tex->blend_s = (m3g_get_int_field(texture_obj, "blendS", 241) == 240) ? 1 : 0;
    tex->blend_t = (m3g_get_int_field(texture_obj, "blendT", 241) == 240) ? 1 : 0;
    {
        static const float I16[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
        memcpy(tex->uv_transform, I16, sizeof(I16));
    }
    /* v14: Texture2D.setTransform stores a row-major 4x4 matrix on the
     * Java object ("transform" float[16]); pick it up for UV scrolling. */
    {
        JavaArray* tmat = (JavaArray*)m3g_get_ref_field(texture_obj, "transform");
        if (tmat && tmat->element_type == T_FLOAT && tmat->length >= 16) {
            float* m = (float*)array_data(tmat);
            int identity = 1;
            for (int i = 0; i < 16; i++) {
                if (m[i] != ((i % 5 == 0) ? 1.0f : 0.0f)) { identity = 0; break; }
            }
            memcpy(tex->uv_transform, m, 16 * sizeof(float));
            tex->has_uv_transform = !identity;
        }
    }

    if (m3g_texture_reload_pixels(tex) == 0) {
        /* No pixel array yet — leave the zero-filled (black) buffer, but
         * keep the texture registered so later Image2D updates refresh it. */
        tex->generation = g_m3g_tex_generation;
    }

    m3g_store_texture_cache(texture_obj, tex);
    return tex;
}

/* Forward declaration for recursive mesh rendering */
static void m3g_render_node_recursive(JVM* jvm, JavaObject* node, M3GTransform* parent_modelview);

/* Render a Sprite3D node as a billboard image at its projected 3D position.
 * Sprite3D always faces the camera and is drawn as a screen-aligned quad.
 * The image is scaled by the sprite's scale factors and perspective.
 */
static void m3g_render_sprite3d(JVM* jvm, JavaObject* sprite, const M3GTransform* mvp) {
    (void)jvm;
    if (!sprite || !mvp || !g_m3g.color_buffer) return;
    
    /* Check rendering enabled */
    int render_enable = m3g_get_int_field(sprite, "renderingEnable", 1);
    if (!render_enable) return;
    
    /* Get the Sprite3D's 3D position from its transform matrix.
     * The translation is in the 4th column of the transform (column-major).
     * But the sprite's position is already in world space; we need to apply MVP. */
    float pos[4] = {0.0f, 0.0f, 0.0f, 1.0f};
    
    /* Get the translation from the node's float fields (more reliable) */
    pos[0] = m3g_get_float_field(sprite, "translationX", 0.0f);
    pos[1] = m3g_get_float_field(sprite, "translationY", 0.0f);
    pos[2] = m3g_get_float_field(sprite, "translationZ", 0.0f);
    
    /* Transform position by MVP to get clip coordinates */
    float clip[4];
    m3g_transform_point(clip, mvp, pos);
    
    /* Check if behind camera (w <= 0 means behind near plane) */
    if (clip[3] <= 0.001f) return;
    
    /* Perspective divide to NDC */
    float ndc_x = clip[0] / clip[3];
    float ndc_y = clip[1] / clip[3];
    
    /* Skip if outside NDC [-1, 1] with margin */
    float margin = 2.0f;
    if (ndc_x < -margin || ndc_x > margin || ndc_y < -margin || ndc_y > margin) return;
    
    /* Convert to screen coordinates */
    float screen_x = (ndc_x + 1.0f) * 0.5f * g_m3g.viewport_width + g_m3g.viewport_x;
    float screen_y = (1.0f - ndc_y) * 0.5f * g_m3g.viewport_height + g_m3g.viewport_y;
    
    /* Get scale factors for the sprite */
    float scale_x = m3g_get_float_field(sprite, "scaleX", 1.0f);
    float scale_y = m3g_get_float_field(sprite, "scaleY", 1.0f);

    /* Get the sprite's image */
    JavaObject* image = m3g_get_ref_field(sprite, "image");
    if (!image) return;

    int img_width = m3g_get_int_field(image, "width", 0);
    int img_height = m3g_get_int_field(image, "height", 0);
    if (img_width <= 0 || img_height <= 0) return;

    /* v23b REVERT: the world-offset projection sizing from v23 broke SU-30
     * (its ~50k sprites/frame were tuned against the base_size heuristic —
     * the screen went mostly black). Restored the v22 sizing verbatim; the
     * crop rectangle below only remaps the SOURCE UVs. */
    float perspective_scale = 1.0f / clip[3];
    float base_size = 50.0f;  /* Base size in world units - adjusted by perspective */

    float half_w = base_size * scale_x * perspective_scale * g_m3g.viewport_width * 0.5f;
    float half_h = base_size * scale_y * perspective_scale * g_m3g.viewport_height * 0.5f;
    
    /* Use image dimensions for aspect ratio if available */
    if (half_w > 0 && half_h > 0) {
        float img_aspect = (float)img_width / (float)img_height;
        if (img_aspect > 1.0f) {
            half_h = half_w / img_aspect;
        } else {
            half_w = half_h * img_aspect;
        }
    }
    
    /* v23b: crop rectangle (Sprite3D.setCrop) — applied ONLY when the game
     * set an explicit crop (see the UV remap below; the <init> marker is
     * cropWidth/cropHeight == -1). */
    int crop_x = m3g_get_int_field(sprite, "cropX", 0);
    int crop_y = m3g_get_int_field(sprite, "cropY", 0);
    int crop_w = m3g_get_int_field(sprite, "cropWidth", -1);
    int crop_h = m3g_get_int_field(sprite, "cropHeight", -1);
    int crop_active = (crop_w != -1 || crop_h != -1);
    
    /* Clamp size to prevent huge sprites */
    float max_dim = g_m3g.viewport_width * 0.5f;
    if (half_w > max_dim) half_w = max_dim;
    if (half_h > max_dim) half_h = max_dim;
    
    /* Get pixel data from Image2D */
    JavaArray* pixels = (JavaArray*)m3g_get_ref_field(image, "pixels");
    if (!pixels || pixels->element_type != T_INT) return;
    
    jint* src_pixels = (jint*)array_data(pixels);
    int src_count = (int)pixels->length;
    if (!src_pixels || src_count < img_width * img_height) return;
    
    /* Draw the sprite image to the color buffer with alpha blending.
     * screen_x, screen_y is the CENTER of the sprite on screen. */
    int dst_left = (int)(screen_x - half_w);
    int dst_top = (int)(screen_y - half_h);
    int dst_right = (int)(screen_x + half_w);
    int dst_bottom = (int)(screen_y + half_h);
    
    /* Clip to viewport */
    if (dst_left < 0) dst_left = 0;
    if (dst_top < 0) dst_top = 0;
    if (dst_right >= g_m3g.buffer_width) dst_right = g_m3g.buffer_width - 1;
    if (dst_bottom >= g_m3g.buffer_height) dst_bottom = g_m3g.buffer_height - 1;
    
    if (dst_right <= dst_left || dst_bottom <= dst_top) return;
    
    int draw_w = dst_right - dst_left;
    int draw_h = dst_bottom - dst_top;
    
    /* Source UV coordinates — v23b: full-image UVs by default; an explicit
     * Sprite3D.setCrop (marker -1 = no crop) remaps them below. Exactly the
     * v22 behavior for uncropped sprites. */
    float u_start = (float)(dst_left - (int)(screen_x - half_w)) / (2.0f * half_w);
    float v_start = (float)(dst_top - (int)(screen_y - half_h)) / (2.0f * half_h);
    float u_end = (float)(dst_right - (int)(screen_x - half_w)) / (2.0f * half_w);
    float v_end = (float)(dst_bottom - (int)(screen_y - half_h)) / (2.0f * half_h);

    if (crop_active) {
        int flip_x = (crop_w < 0); if (flip_x) crop_w = -crop_w;
        int flip_y = (crop_h < 0); if (flip_y) crop_h = -crop_h;
        if (crop_w > 0 && crop_h > 0) {
            /* Map [0..1] onto the crop rect in source-image pixel space */
            float cu0, cu1, cv0, cv1;
            if (flip_x) {
                cu0 = (float)(crop_x + crop_w) / (float)img_width;
                cu1 = (float)crop_x / (float)img_width;
            } else {
                cu0 = (float)crop_x / (float)img_width;
                cu1 = (float)(crop_x + crop_w) / (float)img_width;
            }
            if (flip_y) {
                cv0 = (float)(crop_y + crop_h) / (float)img_height;
                cv1 = (float)crop_y / (float)img_height;
            } else {
                cv0 = (float)crop_y / (float)img_height;
                cv1 = (float)(crop_y + crop_h) / (float)img_height;
            }
            u_start = cu0 + (cu1 - cu0) * u_start;
            u_end   = cu0 + (cu1 - cu0) * u_end;
            v_start = cv0 + (cv1 - cv0) * v_start;
            v_end   = cv0 + (cv1 - cv0) * v_end;
        }
    }
    
    /* v24: honor the sprite's Appearance compositing mode: ALPHA_ADD(65)
     * renders additively (fire/glows), REPLACE(67) overwrites. Default
     * (no CM or ALPHA) keeps the v22 source-alpha blend. */
    int sp_blend = 0;  /* 0=alpha, 1=additive, 2=opaque */
    {
        JavaObject* sp_app = m3g_get_ref_field(sprite, "appearance");
        if (sp_app) {
            JavaObject* sp_cm = m3g_get_ref_field(sp_app, "compositingMode");
            if (sp_cm) {
                int bm = m3g_get_int_field(sp_cm, "blending", 64);
                if (bm == 65) sp_blend = 1;
                else if (bm == 67) sp_blend = 2;
            }
        }
    }

    /* Blit with alpha blending */
    uint32_t* dst = g_m3g.color_buffer;
    for (int dy = 0; dy < draw_h; dy++) {
        float v = v_start + (v_end - v_start) * (float)dy / (float)draw_h;
        int src_y = (int)(v * img_height);
        if (src_y < 0) src_y = 0;
        if (src_y >= img_height) src_y = img_height - 1;
        
        int dst_y = dst_top + dy;
        for (int dx = 0; dx < draw_w; dx++) {
            float u = u_start + (u_end - u_start) * (float)dx / (float)draw_w;
            int src_x = (int)(u * img_width);
            if (src_x < 0) src_x = 0;
            if (src_x >= img_width) src_x = img_width - 1;
            
            int dst_x = dst_left + dx;
            uint32_t fg = (uint32_t)src_pixels[src_y * img_width + src_x];
            int fgA = (fg >> 24) & 0xFF;
            
            if (fgA == 0 && sp_blend != 1) continue;  /* Fully transparent */
            if (sp_blend == 1) {
                /* Additive: dst + src*alpha */
                uint32_t bgc = dst[dst_y * g_m3g.buffer_width + dst_x];
                int r = (int)(((fg >> 16) & 0xFF) * fgA / 255) + ((bgc >> 16) & 0xFF);
                int g = (int)(((fg >> 8) & 0xFF) * fgA / 255) + ((bgc >> 8) & 0xFF);
                int b = (int)((fg & 0xFF) * fgA / 255) + (bgc & 0xFF);
                if (r > 255) r = 255;
                if (g > 255) g = 255;
                if (b > 255) b = 255;
                dst[dst_y * g_m3g.buffer_width + dst_x] =
                    ((uint32_t)(((fg >> 24) & 0xFF)) << 24) | ((uint32_t)r << 16) |
                    ((uint32_t)g << 8) | (uint32_t)b;
            } else if (fgA == 255 || sp_blend == 2) {
                /* Fully opaque */
                dst[dst_y * g_m3g.buffer_width + dst_x] = fg;
            } else {
                /* Alpha blend */
                uint32_t bg = dst[dst_y * g_m3g.buffer_width + dst_x];
                int bgR = (bg >> 16) & 0xFF;
                int bgG = (bg >> 8) & 0xFF;
                int bgB = bg & 0xFF;
                int fgR = (fg >> 16) & 0xFF;
                int fgG = (fg >> 8) & 0xFF;
                int fgB = fg & 0xFF;
                int invA = 255 - fgA;
                int outR = (fgR * fgA + bgR * invA) / 255;
                int outG = (fgG * fgA + bgG * invA) / 255;
                int outB = (fgB * fgA + bgB * invA) / 255;
                int outA = fgA + ((bg >> 24) & 0xFF) * invA / 255;
                dst[dst_y * g_m3g.buffer_width + dst_x] = 
                    ((uint32_t)((outA & 0xFF)) <<  24) | ((outR & 0xFF) << 16) | ((outG & 0xFF) << 8) | (outB & 0xFF);
            }
        }
    }
    
    g_m3g.triangles_rendered += 2;  /* Count as 2 triangles */
}

/* Render a single Mesh with the given model-view-projection matrix */
/* Forward declaration */
static void m3g_rasterize_triangle(const float* v0, const float* v1, const float* v2,
                                   const float* tc0, const float* tc1, const float* tc2,
                                   const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                   M3GAppearance* appearance);

/* Task 16-a item 1 (lighting): read one vertex color from a VertexArray.
 * Mirrors the READ_VCOLOR logic inside m3g_render_single_mesh (component
 * size 1/2, 3 or 4 components, alpha forced to 255 for 3-component data)
 * so the per-vertex lighting pre-pass can use the same base colors. */
static void m3g_read_vertex_color(JavaObject* color_va, int vertex_index, uint8_t* out) {
    memset(out, 0, 4);
    if (!color_va) return;
    JavaArray* color_data = (JavaArray*)m3g_get_ref_field(color_va, "data");
    if (!color_data) return;
    int color_components = m3g_get_int_field(color_va, "componentCount", 4);
    int color_size = m3g_get_int_field(color_va, "componentSize", 1);
    int base = vertex_index * color_components;
    if (base + color_components - 1 >= (int)color_data->length) return;
    if (color_size == 1) {
        uint8_t* cd = (uint8_t*)array_data(color_data);
        out[0] = cd[base];
        out[1] = cd[base + 1];
        out[2] = cd[base + 2];
        out[3] = (color_components == 3) ? 255 : cd[base + 3];
    } else {
        int16_t* cd = (int16_t*)array_data(color_data);
        out[0] = (uint8_t)cd[base];
        out[1] = (uint8_t)cd[base + 1];
        out[2] = (uint8_t)cd[base + 2];
        out[3] = (color_components == 3) ? 255 : (uint8_t)cd[base + 3];
    }
}

/* Appearance render state - holds per-draw compositing/fog params read from Java objects.
 * v23: moved here from below — m3g_render_single_mesh (fog/wire state) uses it. */
typedef struct {
    int blend_mode;         /* CompositingMode blending */
    int depth_test;         /* CompositingMode depth test enabled */
    int depth_write;        /* CompositingMode depth write enabled */
    float alpha_threshold;  /* CompositingMode alpha threshold 0.0-1.0 */
    int fog_enabled;
    int fog_mode;           /* 0=exponential, 1=linear */
    float fog_density;
    float fog_near;
    float fog_far;
    int fog_color;          /* ARGB */
    int texture_blend;      /* Texture2D blending mode */
    /* Task 16-a: write masks honoured in the pixel output stage (defaults on) */
    int alpha_write;        /* CompositingMode alphaWriteEnable */
    int color_write;        /* CompositingMode colorWriteEnable */
} M3GRenderState;

static void m3g_read_render_state(M3GRenderState* state, JavaObject* appearance);

static void m3g_render_single_mesh(JVM* jvm, JavaObject* mesh, M3GTransform* mvp_matrix) {
    (void)jvm;

    /* DIAG: log MVP matrix for first call */
    static int mvp_diag_count = 0;
    if (mvp_diag_count < 2) {
        mvp_diag_count++;
        fprintf(stderr, "[M3G-MVP] MVP matrix row0=(%.3f,%.3f,%.3f,%.3f)\n", mvp_matrix->m[0], mvp_matrix->m[4], mvp_matrix->m[8], mvp_matrix->m[12]);
        fprintf(stderr, "[M3G-MVP] MVP matrix row1=(%.3f,%.3f,%.3f,%.3f)\n", mvp_matrix->m[1], mvp_matrix->m[5], mvp_matrix->m[9], mvp_matrix->m[13]);
        fprintf(stderr, "[M3G-MVP] MVP matrix row2=(%.3f,%.3f,%.3f,%.3f)\n", mvp_matrix->m[2], mvp_matrix->m[6], mvp_matrix->m[10], mvp_matrix->m[14]);
        fprintf(stderr, "[M3G-MVP] MVP matrix row3=(%.3f,%.3f,%.3f,%.3f)\n", mvp_matrix->m[3], mvp_matrix->m[7], mvp_matrix->m[11], mvp_matrix->m[15]);
    }

    JavaObject* vertexBuffer = m3g_get_ref_field(mesh, "vertexBuffer");
    JavaObject* indexBuffer = m3g_get_ref_field(mesh, "indexBuffer");

    if (!vertexBuffer || !indexBuffer) {
        fprintf(stderr, "[M3G] renderMesh: missing vertexBuffer=%p or indexBuffer=%p\n", 
                (void*)vertexBuffer, (void*)indexBuffer);
        return;
    }

    /* Get position array from vertex buffer */
    JavaObject* positions = m3g_get_ref_field(vertexBuffer, "positions");
    if (!positions) {
        fprintf(stderr, "[M3G] renderMesh: missing positions\n");
        return;
    }

    int vertex_count = m3g_get_int_field(positions, "vertexCount", 0);
    int pos_components = m3g_get_int_field(positions, "componentCount", 3);
    int pos_size = m3g_get_int_field(positions, "componentSize", 1);
    float pos_scale = m3g_get_float_field(vertexBuffer, "positionScale", 1.0f);
    float bias_x = m3g_get_float_field(vertexBuffer, "biasX", 0.0f);
    float bias_y = m3g_get_float_field(vertexBuffer, "biasY", 0.0f);
    float bias_z = m3g_get_float_field(vertexBuffer, "biasZ", 0.0f);

    if (vertex_count == 0) return;
    if (vertex_count > M3G_MAX_VERTEX_COUNT) {
        fprintf(stderr, "[M3G] renderMesh: vertex_count=%d exceeds max %d\n", vertex_count, M3G_MAX_VERTEX_COUNT);
        return;
    }

    JavaArray* pos_data = (JavaArray*)m3g_get_ref_field(positions, "data");
    if (!pos_data) {
        fprintf(stderr, "[M3G] renderMesh: missing position data array\n");
        return;
    }

    /* Validate pos_data length against expected size */
    {
        int expected_len = vertex_count * pos_components;
        if (expected_len > (int)pos_data->length) {
            fprintf(stderr, "[M3G] renderMesh: pos_data len=%d < expected=%d (verts=%d, comp=%d)\n",
                    (int)pos_data->length, expected_len, vertex_count, pos_components);
        }
    }

    /* Get index data - use array length as fallback for indexCount */
    JavaArray* idx_data = (JavaArray*)m3g_get_ref_field(indexBuffer, "indices");
    if (!idx_data) {
        fprintf(stderr, "[M3G] renderMesh: missing indices array on indexBuffer %p\n", (void*)indexBuffer);
        return;
    }
    int index_count = m3g_get_int_field(indexBuffer, "indexCount", 0);

    /* v29 DIAG (NOJME_SMALLMESH_TRACE): project the vertex-bbox center of
     * small meshes to screen — identifies what the paddle/ball-sized objects
     * are and where they land. */
    {
        static int sm_trace = -1;
        if (sm_trace < 0) sm_trace = getenv("NOJME_SMALLMESH_TRACE") ? 1 : 0;
        if (sm_trace && index_count / 3 <= 8) {
            jint* pd = (jint*)array_data(pos_data);
            if (pd && vertex_count > 0) {
                float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f};
                for (int vi = 0; vi < vertex_count; vi++) {
                    float v[3];
                    for (int ci = 0; ci < pos_components && ci < 3; ci++) {
                        float val = (pos_size == 1) ? ((jbyte*)pd)[vi * pos_components + ci] * pos_scale
                                    : (pos_size == 2) ? ((jshort*)pd)[vi * pos_components + ci] * pos_scale
                                                      : ((float*)pd)[vi * pos_components + ci];
                        v[ci] = val + (ci == 0 ? bias_x : ci == 1 ? bias_y : bias_z);
                        if (v[ci] < mn[ci]) mn[ci] = v[ci];
                        if (v[ci] > mx[ci]) mx[ci] = v[ci];
                    }
                }
                float ctr[4] = {(mn[0]+mx[0])*0.5f, (mn[1]+mx[1])*0.5f, (mn[2]+mx[2])*0.5f, 1.0f};
                float clip[4];
                m3g_transform_point(clip, mvp_matrix, ctr);
                float sz[3] = {mx[0]-mn[0], mx[1]-mn[1], mx[2]-mn[2]};
                if (clip[3] > 0.001f) {
                    float sx = (clip[0]/clip[3] + 1.0f) * 0.5f * g_m3g.viewport_width + g_m3g.viewport_x;
                    float sy = (1.0f - clip[1]/clip[3]) * 0.5f * g_m3g.viewport_height + g_m3g.viewport_y;
                    fprintf(stderr, "[M3G-SMALL] ib=%p v=%d tris=%d size=(%.1f,%.1f,%.1f) screen=(%.0f,%.0f) w=%.2f\n",
                            (void*)indexBuffer, vertex_count, index_count/3, sz[0], sz[1], sz[2], sx, sy, clip[3]);
                } else {
                    fprintf(stderr, "[M3G-SMALL] ib=%p v=%d tris=%d size=(%.1f,%.1f,%.1f) BEHIND w=%.2f\n",
                            (void*)indexBuffer, vertex_count, index_count/3, sz[0], sz[1], sz[2], clip[3]);
                }
            }
        }
    }
    /* Fallback: if indexCount field not set or 0, use the indices array length */
    if (index_count <= 0) {
        index_count = (int)idx_data->length;
    }
    if (index_count == 0) {
        fprintf(stderr, "[M3G] renderMesh: index_count=0 (indices array len=%d)\n", (int)idx_data->length);
        return;
    }
    if (index_count > M3G_MAX_INDEX_COUNT) return;

    GFX_DEBUG("m3g_render_single_mesh: %d verts, %d indices", vertex_count, index_count);
    EXEC_DEBUG("M3G renderMesh: mesh=%p vb=%p pos=%p (class=%s), %d verts (comp=%d, size=%d, scale=%.3f, bias=%.1f,%.1f,%.1f), %d indices",
            (void*)mesh, (void*)vertexBuffer, (void*)positions,
            positions && positions->header.clazz ? positions->header.clazz->class_name : "?",
            vertex_count, pos_components, pos_size, pos_scale,
            bias_x, bias_y, bias_z, index_count);

    /* Convert positions to float array - use render pool to avoid per-frame malloc */
    /* ALWAYS expand to 3 components per vertex (X, Y, Z) regardless of source comp.
     * M3G position VertexArrays should have comp=3, but some files use comp=2.
     * When comp < 3, missing components default to 0 (then bias is applied). */
    float* vertices = m3g_render_pool_alloc_vertices(vertex_count * 3);
    if (!vertices) return;

    /* Zero-fill the entire vertices array so missing Z components are 0.0f */
    memset(vertices, 0, vertex_count * 3 * sizeof(float));

    /* Pre-compute loop limit and scale for position conversion.
     * Use size_t arithmetic to prevent int overflow when vertex_count * pos_components
     * exceeds INT_MAX (e.g., vertex_count=200000, pos_components=3 → 600000 fits,
     * but vertex_count=INT_MAX, pos_components=4 → overflow). */
    size_t pos_total_safe = (size_t)vertex_count * (size_t)pos_components;
    if (pos_total_safe > (size_t)pos_data->length) pos_total_safe = (size_t)pos_data->length;

    if (pos_components == 3) {
        /* Fast path: source has exactly 3 components — copy directly */
        if (pos_size == 1) {
            int8_t* src = (int8_t*)array_data(pos_data);
            float* dst = vertices;
            int count = (int)pos_total_safe;
            int i = 0;
            while (i + 3 <= count) {
                dst[0] = (float)src[0] * pos_scale + bias_x;
                dst[1] = (float)src[1] * pos_scale + bias_y;
                dst[2] = (float)src[2] * pos_scale + bias_z;
                src += 3; dst += 3; i += 3;
            }
            while (i < count) {
                *dst++ = (float)*src++ * pos_scale;
                i++;
            }
        } else {
            int16_t* src = (int16_t*)array_data(pos_data);
            float* dst = vertices;
            int count = (int)pos_total_safe;
            int i = 0;
            while (i + 3 <= count) {
                dst[0] = (float)src[0] * pos_scale + bias_x;
                dst[1] = (float)src[1] * pos_scale + bias_y;
                dst[2] = (float)src[2] * pos_scale + bias_z;
                src += 3; dst += 3; i += 3;
            }
            while (i < count) {
                *dst++ = (float)*src++ * pos_scale;
                i++;
            }
        }
    } else {
        /* Slow path: expand N-component source to 3-component output.
         * Source layout: [v0_c0, v0_c1, ..., v1_c0, v1_c1, ...]
         * Output layout: [v0_x, v0_y, v0_z, v1_x, v1_y, v1_z, ...] */
        int comp = pos_components < 1 ? 1 : (pos_components > 4 ? 4 : pos_components);
        if (pos_size == 1) {
            int8_t* src = (int8_t*)array_data(pos_data);
            for (int i = 0; i < vertex_count; i++) {
                int base = i * comp;
                if (base + comp <= (int)pos_data->length) {
                    vertices[i*3 + 0] = (float)src[base + 0] * pos_scale + bias_x;
                    if (comp >= 2) vertices[i*3 + 1] = (float)src[base + 1] * pos_scale + bias_y;
                    if (comp >= 3) vertices[i*3 + 2] = (float)src[base + 2] * pos_scale + bias_z;
                    else vertices[i*3 + 2] = 0.0f;
                }
            }
        } else {
            int16_t* src = (int16_t*)array_data(pos_data);
            for (int i = 0; i < vertex_count; i++) {
                int base = i * comp;
                if (base + comp <= (int)pos_data->length) {
                    vertices[i*3 + 0] = (float)src[base + 0] * pos_scale + bias_x;
                    if (comp >= 2) vertices[i*3 + 1] = (float)src[base + 1] * pos_scale + bias_y;
                    if (comp >= 3) vertices[i*3 + 2] = (float)src[base + 2] * pos_scale + bias_z;
                    else vertices[i*3 + 2] = 0.0f;
                }
            }
        }
    }

    /* NOTE: Bias was already applied during vertex conversion above
     * (each src[i] * scale + bias). Do NOT apply it again here.
     * Previous code had a double-bias bug that shifted all vertices. */

    /* =====================================================================
     * v14: MORPHING MESH SUPPORT
     * =====================================================================
     * MorphingMesh stores morph target VertexBuffers in "morphTargets" and
     * the animated weights in "morphWeights". Blended position:
     *   p = p_base * (1 - Σw) + Σ (p_target_i * w_i)
     * Without this, a MorphingMesh rendered as its base shape forever and
     * (before the constructor existed at all) did not render at all
     * (M3GTest scene 6). Only positions are blended — normals are unused
     * by our unlit rasterizer.
     * ===================================================================== */
    {
        const char* mesh_class = mesh->header.clazz && mesh->header.clazz->class_name
                               ? mesh->header.clazz->class_name : "";
        if (strstr(mesh_class, "MorphingMesh") != NULL) {
            JavaArray* targets = (JavaArray*)m3g_get_ref_field(mesh, "morphTargets");
            JavaArray* weights = (JavaArray*)m3g_get_ref_field(mesh, "morphWeights");
            int target_count = m3g_get_int_field(mesh, "morphTargetCount", 0);
            if (targets && targets->element_type == DESC_OBJECT &&
                weights && weights->element_type == T_FLOAT && target_count > 0 &&
                targets->length >= target_count) {
                jfloat* w = (jfloat*)array_data(weights);
                int max_targets = target_count < (int)weights->length
                                ? target_count : (int)weights->length;
                for (int ti = 0; ti < max_targets; ti++) {
                    float wt = w[ti];
                    if (wt == 0.0f) continue;
                    JavaObject* tvb = ((JavaObject**)array_data(targets))[ti];
                    if (!tvb) continue;
                    JavaObject* tpos = m3g_get_ref_field(tvb, "positions");
                    if (!tpos) continue;
                    JavaArray* tdata = (JavaArray*)m3g_get_ref_field(tpos, "data");
                    if (!tdata) continue;
                    int tcomp = m3g_get_int_field(tpos, "componentCount", 3);
                    int tsize = m3g_get_int_field(tpos, "componentSize", 1);
                    float tscale = m3g_get_float_field(tvb, "positionScale", 1.0f);
                    float tbx = m3g_get_float_field(tvb, "biasX", 0.0f);
                    float tby = m3g_get_float_field(tvb, "biasY", 0.0f);
                    float tbz = m3g_get_float_field(tvb, "biasZ", 0.0f);
                    if (tcomp < 1) tcomp = 1;
                    if (tcomp > 3) tcomp = 3;
                    for (int vi = 0; vi < vertex_count; vi++) {
                        for (int c = 0; c < tcomp; c++) {
                            int sidx = vi * tcomp + c;
                            float tv;
                            if (sidx >= (int)tdata->length) continue;
                            if (tsize == 1) {
                                int8_t* s8 = (int8_t*)array_data(tdata);
                                tv = (float)s8[sidx] * tscale +
                                     (c == 0 ? tbx : (c == 1 ? tby : tbz));
                            } else {
                                int16_t* s16 = (int16_t*)array_data(tdata);
                                tv = (float)s16[sidx] * tscale +
                                     (c == 0 ? tbx : (c == 1 ? tby : tbz));
                            }
                            /* p = p*(1-w) + t*w  (incremental per target) */
                            vertices[vi * 3 + c] =
                                vertices[vi * 3 + c] * (1.0f - wt) + tv * wt;
                        }
                    }
                }
            }
        }
    }

    /* =====================================================================
     * v22: SKINNED MESH SUPPORT (rigid vertex-range binding per JSR-184)
     * =====================================================================
     * A SkinnedMesh binds bones to vertex RANGES ((bone, firstVertex,
     * vertexCount) triples, parsed from the file into boneNodeRefs/
     * boneFirstVertex/boneVertexCount + resolved "bones" array). Each
     * covering bone transforms its vertices rigidly; vertices covered by
     * several bones get the average of the bone transforms (JSR-184
     * SkinnedMesh.addTransform semantics).
     *
     * Bone matrices are composed by DFS from the skeleton root (skeleton
     * root local transform included), i.e. they map bind-pose skeleton
     * space into the SkinnedMesh's local space; the regular MVP (which
     * already contains the mesh/parent transforms) applies afterwards.
     * Without skinning the plane here rendered its raw bind-pose vertices,
     * which sit ~5000 units from the chase camera -> invisible plane with
     * visible 2D effects (the SU-30 bug report).
     * ===================================================================== */
    {
        const char* mesh_class_sk = mesh->header.clazz && mesh->header.clazz->class_name
                                  ? mesh->header.clazz->class_name : "";
        if (strstr(mesh_class_sk, "SkinnedMesh") != NULL) {
            JavaObject* skeleton = m3g_get_ref_field(mesh, "skeleton");
            JavaArray* bones = (JavaArray*)m3g_get_ref_field(mesh, "bones");
            JavaArray* bfirst = (JavaArray*)m3g_get_ref_field(mesh, "boneFirstVertex");
            JavaArray* bcnt = (JavaArray*)m3g_get_ref_field(mesh, "boneVertexCount");
            JavaArray* bwgt = (JavaArray*)m3g_get_ref_field(mesh, "boneWeights");
            if (skeleton && bones && bfirst && bcnt &&
                bones->element_type == DESC_OBJECT &&
                bfirst->element_type == T_INT &&
                bcnt->element_type == T_INT &&
                bones->length == bfirst->length &&
                bones->length == bcnt->length && bones->length > 0) {

                static M3GTransform bone_mats[64];
                int nb = bones->length < 64 ? bones->length : 64;
                JavaObject** bone_nodes = (JavaObject**)array_data(bones);
                jint* vfirst = (jint*)array_data(bfirst);
                jint* vcount = (jint*)array_data(bcnt);
                jint* vwgt = (bwgt && bwgt->element_type == T_INT &&
                              bwgt->length >= bones->length)
                                ? (jint*)array_data(bwgt) : NULL;

                /* DFS from skeleton root composing local transforms; record
                 * the combined matrix for each bound bone found. */
                M3GTransform identity;
                m3g_transform_identity(&identity);
                int found = 0;
                /* iterative stack DFS (node, transform) - depth cap 32 */
                struct { JavaObject* node; M3GTransform tf; int depth; } stack[64];
                int sp = 0;
                stack[sp].node = skeleton; stack[sp].tf = identity; stack[sp].depth = 0; sp++;
                while (sp > 0 && found < nb) {
                    sp--;
                    JavaObject* n = stack[sp].node;
                    M3GTransform* ptf = &stack[sp].tf;
                    int depth = stack[sp].depth;
                    if (!n || depth > 32) continue;
                    M3GTransform local, combined;
                    m3g_build_node_transform(n, &local);
                    m3g_transform_multiply(&combined, ptf, &local);
                    for (int i = 0; i < nb; i++) {
                        if (bone_nodes[i] == n) {
                            bone_mats[i] = combined;
                            found++;
                        }
                    }
                    JavaArray* ch = (JavaArray*)m3g_get_ref_field(n, "children");
                    if (ch && ch->element_type == DESC_OBJECT && sp < 60) {
                        JavaObject** cd = (JavaObject**)array_data(ch);
                        for (jsize c = 0; c < ch->length && sp < 60; c++) {
                            if (!cd[c]) continue;
                            stack[sp].node = cd[c];
                            stack[sp].tf = combined;
                            stack[sp].depth = depth + 1;
                            sp++;
                        }
                    }
                }

                /* v22 DIAG: report bones not located under the skeleton */
                if (found < nb) {
                    static int missing_diag = 0;
                    if (missing_diag < 3) {
                        missing_diag++;
                        fprintf(stderr, "[M3G-SKIN] skeleton=%p visited; %d/%d bones found; missing:\n",
                                (void*)skeleton, found, nb);
                        for (int i = 0; i < nb && i < 16; i++) {
                            JavaObject* bn = bone_nodes[i];
                            fprintf(stderr, "[M3G-SKIN]   bone[%d]=%p class=%s range=[%d..%d)%s\n",
                                    i, (void*)bn,
                                    (bn && bn->header.clazz && bn->header.clazz->class_name)
                                        ? bn->header.clazz->class_name : "?",
                                    (int)vfirst[i], (int)(vfirst[i] + vcount[i]),
                                    bn ? "" : " (NULL)");
                        }
                    }
                }

                if (found > 0) {
                    /* Accumulation buffers (grown on demand, reused per frame) */
                    static float* skin_acc = NULL;
                    static float* skin_wsum = NULL;
                    static int skin_cap = 0;
                    if (skin_cap < vertex_count) {
                        free(skin_acc); free(skin_wsum);
                        skin_acc = (float*)malloc(sizeof(float) * vertex_count * 3);
                        skin_wsum = (float*)malloc(sizeof(float) * vertex_count);
                        skin_cap = vertex_count;
                    }
                    if (skin_acc && skin_wsum) {
                        memset(skin_acc, 0, sizeof(float) * vertex_count * 3);
                        memset(skin_wsum, 0, sizeof(float) * vertex_count);

                        /* Per-vertex weighted sum (JSR-184 m3gAddTransform):
                         * acc += w_i * M_i * v, wsum += w_i;
                         * final = acc / wsum (weight<=0 counts as 1). */
                        for (int i = 0; i < nb; i++) {
                            if (!bone_nodes[i]) continue;
                            float bw = 1.0f;
                            if (vwgt) {
                                jint raw = vwgt[i];
                                bw = raw > 0 ? (float)raw : 1.0f;
                            }
                            int lo = vfirst[i];
                            int cnt = vcount[i];
                            if (lo < 0) lo = 0;
                            if (lo + cnt > vertex_count) cnt = vertex_count - lo;
                            for (int vi = lo; vi < lo + cnt; vi++) {
                                float p[4];
                                float pv[4] = { vertices[vi * 3 + 0],
                                                vertices[vi * 3 + 1],
                                                vertices[vi * 3 + 2], 1.0f };
                                m3g_transform_point(p, &bone_mats[i], pv);
                                skin_acc[vi * 3 + 0] += p[0] * bw;
                                skin_acc[vi * 3 + 1] += p[1] * bw;
                                skin_acc[vi * 3 + 2] += p[2] * bw;
                                skin_wsum[vi] += bw;
                            }
                        }
                        int skinned_any = 0;
                        for (int vi = 0; vi < vertex_count; vi++) {
                            if (skin_wsum[vi] > 0.000001f) {
                                float inv = 1.0f / skin_wsum[vi];
                                vertices[vi * 3 + 0] = skin_acc[vi * 3 + 0] * inv;
                                vertices[vi * 3 + 1] = skin_acc[vi * 3 + 1] * inv;
                                vertices[vi * 3 + 2] = skin_acc[vi * 3 + 2] * inv;
                                skinned_any++;
                            }
                        }
                        static int skin_diag = 0;
                        if (skin_diag < 4) {
                            skin_diag++;
                            fprintf(stderr,
                                    "[M3G-SKIN] mesh=%p bones=%d found=%d "
                                    "skinned=%d/%d verts, v0=(%.1f,%.1f,%.1f)\n",
                                    (void*)mesh, bones->length, found, skinned_any,
                                    vertex_count, vertices[0], vertices[1], vertices[2]);
                        }
                    }
                }
            }
        }
    }

    /* =====================================================================
     * COMP=2 VERTEX HANDLING
     * =====================================================================
     * M3G comp=2 vertices store (X,Y) only with no Z. After scale+bias,
     * they are in object space. We expand to (X, Y, Z_eps, 1.0) where
     * Z_eps = 0.01 prevents clip.w = 0 after perspective projection
     * (which would cause divide-by-zero in perspective divide).
     *
     * IMPORTANT: comp=2 vertices are NOT in screen space. They have
     * world-space coordinates and MUST go through the normal 3D MVP
     * pipeline. The Z=0 after modelview would put them at the camera
     * plane, giving clip.w ≈ 0. Adding a small Z offset fixes this.
     *
     * Previous approaches that used orthographic screen-space MVP were
     * WRONG because they assumed comp=2 = pixel coordinates, but games
     * like SU-30 use comp=2 for 2D geometry in world space.
     * ============================================================ */
    /* Comp=2 vertices will use normal MVP but with Z expanded to 0.01 */
    
    /* Get indices */
    uint16_t* indices = NULL;
    int need_free_indices = 0;

    /* Handle different index element types */
    if (idx_data->element_type == T_INT) {
        /* int[] indices - need to downcast to uint16_t */
        jint* src = (jint*)array_data(idx_data);
        indices = (uint16_t*)malloc(index_count * sizeof(uint16_t));
        need_free_indices = 1;
        if (indices) {
            int copy_count = index_count < (int)idx_data->length ? index_count : (int)idx_data->length;
            for (int i = 0; i < copy_count; i++) {
                indices[i] = (uint16_t)(src[i] & 0xFFFF);
            }
        }
    } else if (idx_data->element_type == T_SHORT) {
        /* short[] indices - cast directly */
        indices = (uint16_t*)array_data(idx_data);
    } else if (idx_data->element_type == T_BYTE) {
        /* byte[] indices - need to expand to uint16_t */
        int8_t* src = (int8_t*)array_data(idx_data);
        indices = (uint16_t*)malloc(index_count * sizeof(uint16_t));
        need_free_indices = 1;
        if (indices) {
            int copy_count = index_count < (int)idx_data->length ? index_count : (int)idx_data->length;
            for (int i = 0; i < copy_count; i++) {
                indices[i] = (uint16_t)(src[i] & 0xFF);
            }
        }
    } else {
        /* Unknown index type - log and skip */
        fprintf(stderr, "[M3G] renderMesh: unsupported index element_type=%d (mesh=%p)\n",
                idx_data->element_type, (void*)mesh);
    }

    if (!indices) {
        /* vertices is pool-allocated, no free needed */
        return;
    }

    /* Resolve material diffuse color as default.
     * In M3G, the diffuse color is 0xAARRGGBB but many files store it as 0x00RRGGBB
     * where the alpha byte is 0 (not transparent — alpha is controlled by
     * CompositingMode, not the material color). Always set alpha=255 for visibility. */
    uint8_t default_color[4] = {200, 200, 200, 255};
    JavaObject* appearance = m3g_get_ref_field(mesh, "appearance");
    if (appearance) {
        JavaObject* material = m3g_get_ref_field(appearance, "material");
        if (material) {
            jint diffuse_argb = m3g_get_int_field(material, "diffuse", 0x00CCCCCC);
            default_color[0] = (diffuse_argb >> 16) & 0xFF;
            default_color[1] = (diffuse_argb >> 8) & 0xFF;
            default_color[2] = diffuse_argb & 0xFF;
            default_color[3] = 255;  /* Always opaque — M3G uses CompositingMode for transparency */
            GFX_DEBUG("M3G: material diffuse=0x%08X -> color=(%d,%d,%d,%d)",
                     diffuse_argb, default_color[0], default_color[1], default_color[2], default_color[3]);
        }
    }

    /* Task 16-a item 5: VertexBuffer.setDefaultColor — when the VertexBuffer
     * carries a default color and has NO per-vertex color array, that color
     * is the vertex color default (JSR-184 §VertexBuffer.setDefaultColor).
     * defaultColor==0 means "not set" (stub zero-init / never configured). */
    {
        jint vb_default_color = m3g_get_int_field(vertexBuffer, "defaultColor", 0);
        if (vb_default_color != 0 && !m3g_get_ref_field(vertexBuffer, "colors")) {
            default_color[0] = (vb_default_color >> 16) & 0xFF;
            default_color[1] = (vb_default_color >> 8) & 0xFF;
            default_color[2] = vb_default_color & 0xFF;
            default_color[3] = (vb_default_color >> 24) & 0xFF;
            if (default_color[3] == 0) default_color[3] = 255;
        }
    }

    /* Check for per-vertex colors */
    JavaObject* color_va = m3g_get_ref_field(vertexBuffer, "colors");

    /* Check for texture coordinates and build texture */
    JavaObject* texcoord_va = m3g_get_ref_field(vertexBuffer, "texCoords");
    float tex_coord_scale = m3g_get_float_field(vertexBuffer, "texCoordScale", 1.0f);

    /* Build texture from Appearance's Texture2D */
    M3GTexture2D* texture = NULL;
    M3GAppearance m3g_appearance;
    memset(&m3g_appearance, 0, sizeof(m3g_appearance));

    /* FIX 41: Read PolygonMode and CompositingMode from Appearance.
     * Previously these were discarded during M3G parsing (references not saved).
     * Now they're properly parsed and linked. Read them per-mesh to control
     * culling, winding, depth test/write, and blending for each mesh. */
    int mesh_culling = -1;       /* -1 = use global default */
    int mesh_winding = 0;        /* 0 = CCW (default), 1 = CW */
    int mesh_depth_test = -1;    /* -1 = use global default */
    int mesh_depth_write = -1;
    int mesh_blend_mode = -1;
    int mesh_alpha_threshold = -1;
    (void)mesh_blend_mode; (void)mesh_alpha_threshold;  /* applied via global pipeline state */
    int mesh_two_sided = 0;

    if (appearance) {
        JavaObject* texture_obj = m3g_get_ref_field(appearance, "texture");
        if (texture_obj) {
            texture = m3g_build_texture2d(texture_obj);
            m3g_appearance.texture = texture;
        } else {
            /* v18 TRACE (once): which mesh renders textureless */
            static int no_tex_warned = 0;
            if (!no_tex_warned) {
                no_tex_warned = 1;
                LOG_SAFE("[M3G-TRACE] render: Appearance %p has NO texture (mesh=%p)\n",
                         (void*)appearance, (void*)mesh);
            }
        }

        /* Read PolygonMode */
        JavaObject* polygon_mode = m3g_get_ref_field(appearance, "polygonMode");
        if (polygon_mode) {
            int culling_val = m3g_get_int_field(polygon_mode, "culling", -1);
            int winding_val = m3g_get_int_field(polygon_mode, "winding", 0);
            int two_sided_val = m3g_get_int_field(polygon_mode, "twoSidedLighting", 0);
            /* Map culling: accept both Java API enums (160-162) and raw M3G bytes (0-2).
             * Java API: CULL_NONE=160, CULL_BACK=161, CULL_FRONT=162
             * M3G binary: 0=NONE, 1=BACK, 2=FRONT */
            int cull_raw = culling_val;
            if (cull_raw >= 160 && cull_raw <= 162) cull_raw -= 160; /* Java enum → 0-2 */
            if (cull_raw == 0) mesh_culling = 0;      /* CULL_NONE */
            else if (cull_raw == 1) mesh_culling = 1;  /* CULL_BACK */
            else if (cull_raw == 2) mesh_culling = 2;  /* CULL_FRONT */
            else mesh_culling = (cull_raw > 0) ? 1 : 0;
            /* Map winding: accept both Java API enums (163-164) and raw bytes (0-1) */
            int wind_raw = winding_val;
            if (wind_raw >= 163 && wind_raw <= 164) wind_raw -= 163; /* Java enum → 0-1 */
            mesh_winding = (wind_raw == 1) ? 1 : 0;  /* CW if 1, else CCW */
            mesh_two_sided = (two_sided_val != 0) ? 1 : 0;
            LOG_SAFE( "[M3G-POLY] mesh=%p: culling_raw=%d->%d winding_raw=%d->%d twoSided=%d\n",
                    (void*)mesh, culling_val, mesh_culling, winding_val, mesh_winding, two_sided_val);
        }

        /* Read CompositingMode */
        JavaObject* comp_mode = m3g_get_ref_field(appearance, "compositingMode");
        if (comp_mode) {
            /* Parser now reads in correct M3G binary order:
             * DepthTest(u8), DepthWrite(u8), ColorWrite(u8),
             * Blending(u8), AlphaThreshold(f32), Dithering(u8) */
            int blending_val = m3g_get_int_field(comp_mode, "blending", 64);
            int depth_test_val = m3g_get_int_field(comp_mode, "depthTest", 1);
            int depth_write_val = m3g_get_int_field(comp_mode, "depthWrite", 1);
            float alpha_thresh = m3g_get_float_field(comp_mode, "alphaThreshold", 0.0f);
            if (alpha_thresh < 0.0f) alpha_thresh = 0.0f;
            if (alpha_thresh > 1.0f) alpha_thresh = 0.0f; /* Invalid, disable */
            
            /* Map blending: M3G binary uses 0-4, renderer uses 64-68.
             * M3G: 0=REPLACE, 1=ALPHA, 2=ALPHA_ADD, 3=MODULATE, 4=MODULATE_X2
             * Renderer: 64=ALPHA, 65=ALPHA_ADD, 67=REPLACE, 68=MODULATE */
            int blend_raw = blending_val;
            if (blend_raw == 0) {
                /* v23b: 0 means "unset" (stub zero-init, no <init> default
                 * applied or the game relies on the spec default) — use the
                 * JSR-184 default ALPHA. Mapping it to REPLACE (v23a) killed
                 * blending in every scene that never called setBlending. */
                blend_raw = 64;
            } else if (blend_raw >= 160) {
                /* Java API enum: REPLACE=192, ALPHA=193, etc. → internal */
                if (blend_raw == 192) blend_raw = 67;      /* REPLACE */
                else if (blend_raw == 193) blend_raw = 64;  /* ALPHA */
                else if (blend_raw == 194) blend_raw = 65;  /* ALPHA_ADD */
                else if (blend_raw == 195) blend_raw = 68;  /* MODULATE */
                else blend_raw = 64; /* fallback to ALPHA */
            } else {
                /* M3G binary: 0=REPLACE, 1=ALPHA, 2=ALPHA_ADD, 3=MODULATE */
                if (blend_raw == 1) blend_raw = 64;  /* ALPHA */
                else if (blend_raw == 2) blend_raw = 65;  /* ALPHA_ADD */
                else if (blend_raw == 3) blend_raw = 68;  /* MODULATE */
                else blend_raw = 64; /* fallback to ALPHA */
            }
            mesh_blend_mode = blend_raw;
            
            /* Use actual depth test/write values from the (now correctly parsed) CompositingMode */
            mesh_depth_test = (depth_test_val != 0) ? 1 : 0;
            mesh_depth_write = (depth_write_val != 0) ? 1 : 0;
            mesh_alpha_threshold = (int)(alpha_thresh * 255.0f);
            LOG_SAFE( "[M3G-COMP] mesh=%p: blending=%d depthTest=%d depthWrite=%d alphaThresh=%.2f\n",
                    (void*)mesh, blending_val, depth_test_val, depth_write_val, alpha_thresh);
        }

        /* Read texture blend mode from Texture2D */
        if (texture_obj) {
            /* Texture2D blending: FUNC_REPLACE=160, FUNC_MODULATE=161, FUNC_DECAL=162,
             * FUNC_ADD=163, FUNC_BLEND=164 (Java API constants).
             * v14 FIX: API constants were passed through unmapped — they hit
             * the default branch of m3g_blend_pixels ("return background"),
             * so EVERY textured mesh with vertex colors painted background
             * color ("invisible paint" #2). Map to internal codes:
             * 67=REPLACE 68=MODULATE 70=DECAL 71=ADD 64=BLEND. */
            int tex_blend = m3g_get_int_field(texture_obj, "blending", 161);
            if (tex_blend >= 160 && tex_blend <= 164) {
                static const uint8_t tmap[5] = { 67, 68, 70, 71, 64 };
                tex_blend = tmap[tex_blend - 160];
            } else if (tex_blend >= 224 && tex_blend <= 228) {
                /* v14: Nokia-era 0xE0 constant block (FUNC_REPLACE=224 ..
                 * FUNC_BLEND=228) used by midlets targeting early JSR-184
                 * handsets (Nescube passes 224/225...). Same order as the
                 * 0xA0 block. */
                static const uint8_t tmap_e0[5] = { 67, 68, 70, 71, 64 };
                tex_blend = tmap_e0[tex_blend - 224];
            } else if (tex_blend <= 0) {
                tex_blend = 68;  /* no value set — JSR-184 default FUNC_MODULATE */
            }
            m3g_appearance.texture_blend = tex_blend;
        }
    }

    /* Save and override global render state for this mesh */
    int saved_culling = g_m3g.culling_enabled;
    int saved_depth_test = g_m3g.depth_test_enabled;
    int saved_depth_write = g_m3g.depth_write_enabled;

    /* mesh_culling: 0=CULL_NONE, 1=CULL_BACK, 2=CULL_FRONT */
    if (mesh_culling >= 0) g_m3g.culling_enabled = (mesh_culling != 0) ? 1 : 0;
    if (mesh_depth_test >= 0) g_m3g.depth_test_enabled = mesh_depth_test;
    if (mesh_depth_write >= 0) g_m3g.depth_write_enabled = mesh_depth_write;

    /* Store mesh-level winding/culling in appearance struct for rasterizer */
    m3g_appearance.winding = mesh_winding;
    m3g_appearance.two_sided_lighting = mesh_two_sided;
    m3g_appearance.cull_front = (mesh_culling == 2);  /* CULL_FRONT */
    /* v12 CRITICAL FIX: blend_mode was NEVER assigned — memset left it 0,
     * and the rasterizer's `blend_mode >= 0` check passed 0 down to
     * m3g_blend_pixels(), whose switch has no case 0 and DEFAULTS to
     * "return background" — every triangle was painted INVISIBLE
     * (Nescube cube rasterized 19k pixels that exactly matched the
     * clear color). Explicitly assign the real blend mode here. */
    m3g_appearance.blend_mode = (mesh_blend_mode >= 0) ? mesh_blend_mode : 64;

    /* =====================================================================
     * Task 16-a: fog / write masks / alphaFactor / second texture unit.
     * All fields default to the v22 behavior (no fog, writes on, alpha 1,
     * no unit-1 texture) and are only enabled by corresponding scene state.
     * ===================================================================== */
    m3g_appearance.alpha_write = 1;
    m3g_appearance.color_write = 1;
    m3g_appearance.fog_enabled = 0;
    m3g_appearance.alpha_factor = 1.0f;

    /* CompositingMode write masks (item 13). The CompositingMode <init>
     * native sets the JSR-184 defaults (all enables true), so a stored 0 is
     * a real "disabled" from either the API or the M3G file parser. */
    {
        JavaObject* comp_mode_mask = m3g_get_ref_field(appearance, "compositingMode");
        if (comp_mode_mask) {
            m3g_appearance.alpha_write = m3g_get_int_field(comp_mode_mask, "alphaWrite", 1) ? 1 : 0;
            m3g_appearance.color_write = m3g_get_int_field(comp_mode_mask, "colorWrite", 1) ? 1 : 0;
        }
    }

    /* Fog (item 2): m3g_read_render_state reads the Fog object attached to
     * the Appearance and normalizes the mode encoding; previously its output
     * was never propagated into the rasterizer, so fog was dead code. */
    {
        M3GRenderState app_state;
        m3g_read_render_state(&app_state, appearance);
        m3g_appearance.fog_enabled = app_state.fog_enabled;
        m3g_appearance.fog_mode = app_state.fog_mode;
        m3g_appearance.fog_density = app_state.fog_density;
        m3g_appearance.fog_near = app_state.fog_near;
        m3g_appearance.fog_far = app_state.fog_far;
        m3g_appearance.fog_color = app_state.fog_color;
    }

    /* Node.alphaFactor (item 4) — multiplies fragment alpha during blending.
     * Zero-init guard: JSR-184 default is 1.0, stub fields start at 0. */
    {
        float af = m3g_get_float_field(mesh, "alphaFactor", 1.0f);
        if (af <= 0.0f || af > 1.0f) {
            if (af > 1.0f) af = 1.0f;
            else af = 1.0f;  /* 0 (unset) -> spec default */
        }
        m3g_appearance.alpha_factor = af;
    }

    /* Second texture unit (item 12): if the Appearance has a texture1 and
     * the VertexBuffer carries texCoords1, build it — the rasterizer then
     * modulates the unit-0 result with it. NULL keeps the v22 path. */
    {
        JavaObject* texture1_obj = m3g_get_ref_field(appearance, "texture1");
        if (texture1_obj) {
            M3GTexture2D* tex1 = m3g_build_texture2d(texture1_obj);
            if (tex1) m3g_appearance.texture1 = tex1;
        }
    }

    /* =====================================================================
     * Task 16-a item 1: GOURAUD LIGHTING PRE-PASS
     * =====================================================================
     * Only active when the scene contains lights (g_m3g_active_light_count
     * > 0) — with no lights the legacy unlit vertex-color path below runs
     * untouched, keeping Nescube/M3GTest output byte-identical.
     * When the VertexBuffer has normals, all vertices are lit here (true
     * Gouraud); without normals the per-triangle loop falls back to flat
     * lighting with the object-space face normal. */
    M3GMaterial lit_material;
    float* normal_data = NULL;   /* decoded object-space normals, may stay NULL */
    float* lit_colors = NULL;    /* per-vertex lit RGBA (pool), normals path */
    int use_lighting = (g_m3g_active_light_count > 0);
    if (use_lighting) {
        m3g_build_material_from_java(appearance, &lit_material);

        JavaObject* normals_va = m3g_get_ref_field(vertexBuffer, "normals");
        if (normals_va) {
            JavaArray* ndata = (JavaArray*)m3g_get_ref_field(normals_va, "data");
            if (ndata && ndata->length >= (jsize)(vertex_count * 3)) {
                normal_data = m3g_render_pool_alloc_vertices(vertex_count * 3);
                if (normal_data) {
                    int ncomp = m3g_get_int_field(normals_va, "componentCount", 3);
                    if (ncomp < 1) ncomp = 1;
                    for (int v = 0; v < vertex_count; v++) {
                        int base = v * ncomp;
                        float nx = 0.0f, ny = 0.0f, nz = 1.0f;
                        if (base + 2 < (int)ndata->length) {
                            if (ndata->element_type == T_BYTE) {
                                int8_t* s = (int8_t*)array_data(ndata);
                                nx = (float)s[base] / 127.0f;
                                ny = (float)s[base + 1] / 127.0f;
                                nz = (float)s[base + 2] / 127.0f;
                            } else if (ndata->element_type == T_SHORT) {
                                int16_t* s = (int16_t*)array_data(ndata);
                                nx = (float)s[base] / 32767.0f;
                                ny = (float)s[base + 1] / 32767.0f;
                                nz = (float)s[base + 2] / 32767.0f;
                            } else if (ndata->element_type == T_FLOAT) {
                                float* s = (float*)array_data(ndata);
                                nx = s[base]; ny = s[base + 1]; nz = s[base + 2];
                            } else { /* T_INT: fixed-point 1/2^31 — rare */
                                jint* s = (jint*)array_data(ndata);
                                nx = (float)((double)s[base] / 2147483647.0);
                                ny = (float)((double)s[base + 1] / 2147483647.0);
                                nz = (float)((double)s[base + 2] / 2147483647.0);
                            }
                        }
                        normal_data[v * 3 + 0] = nx;
                        normal_data[v * 3 + 1] = ny;
                        normal_data[v * 3 + 2] = nz;
                    }
                }
            }
        }

        if (normal_data) {
            /* True Gouraud: light every vertex once in view space. */
            lit_colors = m3g_render_pool_alloc_vertices(vertex_count * 4);
            if (lit_colors) {
                for (int v = 0; v < vertex_count; v++) {
                    float pv[4] = { vertices[v * 3 + 0], vertices[v * 3 + 1],
                                    vertices[v * 3 + 2], 1.0f };
                    float pos_view[4];
                    m3g_transform_point(pos_view, &g_m3g_current_modelview, pv);

                    float nv[3] = { normal_data[v * 3 + 0],
                                    normal_data[v * 3 + 1],
                                    normal_data[v * 3 + 2] };
                    /* Normals rotate with the modelview (upper-left 3x3) */
                    float n_view[3];
                    const M3GTransform* mv = &g_m3g_current_modelview;
                    n_view[0] = mv->m[0] * nv[0] + mv->m[4] * nv[1] + mv->m[8]  * nv[2];
                    n_view[1] = mv->m[1] * nv[0] + mv->m[5] * nv[1] + mv->m[9]  * nv[2];
                    n_view[2] = mv->m[2] * nv[0] + mv->m[6] * nv[1] + mv->m[10] * nv[2];

                    /* Base color: per-vertex color when present, else default */
                    uint8_t base[4];
                    if (color_va) {
                        m3g_read_vertex_color(color_va, v, base);
                    } else {
                        memcpy(base, default_color, 4);
                    }

                    float lit[3];
                    m3g_light_vertex(lit, pos_view, n_view, &lit_material,
                                     m3g_appearance.two_sided_lighting);
                    lit_colors[v * 4 + 0] = lit[0] * 255.0f;
                    lit_colors[v * 4 + 1] = lit[1] * 255.0f;
                    lit_colors[v * 4 + 2] = lit[2] * 255.0f;
                    lit_colors[v * 4 + 3] = (float)base[3];
                }
            } else {
                use_lighting = 0; /* pool exhausted — render unlit (safe) */
            }
        }
    }

    /* Read texcoord data if available */
    float* tex_coords = NULL;
    int tex_components = 2;
    if (texcoord_va && texture) {
        int tex_vert_count = m3g_get_int_field(texcoord_va, "vertexCount", 0);
        tex_components = m3g_get_int_field(texcoord_va, "componentCount", 2);
        int tex_comp_size = m3g_get_int_field(texcoord_va, "componentSize", 1);
        JavaArray* tex_data = (JavaArray*)m3g_get_ref_field(texcoord_va, "data");
        /* v14: texture coordinate scale+bias (JSR-184: uv = v*scale + bias).
         * The bias used to be dropped by setTexCoords and ignored here. */
        float tc_bias_x = m3g_get_float_field(vertexBuffer, "texCoordBiasX", 0.0f);
        float tc_bias_y = m3g_get_float_field(vertexBuffer, "texCoordBiasY", 0.0f);

        if (tex_data && tex_vert_count > 0 && tex_vert_count == vertex_count) {
            tex_coords = (float*)malloc(vertex_count * 2 * sizeof(float));
            if (tex_coords) {
                if (tex_comp_size == 1) {
                    int8_t* src = (int8_t*)array_data(tex_data);
                    for (int i = 0; i + 1 < vertex_count * tex_components && i + 1 < (int)tex_data->length; i += tex_components) {
                        tex_coords[i] = (float)src[i] * tex_coord_scale + tc_bias_x;
                        tex_coords[i + 1] = (float)src[i + 1] * tex_coord_scale + tc_bias_y;
                    }
                } else {
                    int16_t* src = (int16_t*)array_data(tex_data);
                    for (int i = 0; i + 1 < vertex_count * tex_components && i + 1 < (int)tex_data->length; i += tex_components) {
                        tex_coords[i] = (float)src[i] * tex_coord_scale + tc_bias_x;
                        tex_coords[i + 1] = (float)src[i + 1] * tex_coord_scale + tc_bias_y;
                    }
                }
                /* v14 DIAG: log the UV range of the first textured meshes to
                 * trace black-cube / wrong-texture reports */
                {
                    static int uv_diag = 0;
                    if (uv_diag < 6) {
                        uv_diag++;
                        float umin = tex_coords[0], umax = tex_coords[0];
                        float vmin = tex_coords[1], vmax = tex_coords[1];
                        for (int i = 0; i + 1 < vertex_count * 2; i += 2) {
                            if (tex_coords[i] < umin) umin = tex_coords[i];
                            if (tex_coords[i] > umax) umax = tex_coords[i];
                            if (tex_coords[i+1] < vmin) vmin = tex_coords[i+1];
                            if (tex_coords[i+1] > vmax) vmax = tex_coords[i+1];
                        }
                        fprintf(stderr, "[M3G-UV] mesh=%p n=%d u=[%.3f..%.3f] v=[%.3f..%.3f] scale=%.3f bias=(%.3f,%.3f) tex=%dx%d\n",
                                (void*)mesh, vertex_count, umin, umax, vmin, vmax,
                                tex_coord_scale, tc_bias_x, tc_bias_y,
                                texture->width, texture->height);
                        /* v14 DIAG: how many non-black texels does the built
                         * texture actually hold? Distinguishes "texture empty"
                         * from "UV/sampling bug". */
                        {
                            int total = texture->width * texture->height;
                            int nonblack = 0;
                            for (int pi = 0; pi < total; pi++) {
                                if ((texture->pixels[pi] & 0x00FFFFFF) != 0) nonblack++;
                            }
                            fprintf(stderr, "[M3G-UV] texture content: %d/%d non-black texels (%.1f%%)\n",
                                    nonblack, total, 100.0f * nonblack / (total ? total : 1));
                        }
                    }
                }
            }
        }
    }

    /* Render triangles — vertices are now ALWAYS 3-component (X,Y,Z) */
    int mesh_triangles = 0;
    for (int t = 0; t + 2 < index_count; t += 3) {
        float v0[4], v1[4], v2[4];
        float clip0[4], clip1[4], clip2[4];

        int i0 = indices[t];
        int i1 = indices[t+1];
        int i2 = indices[t+2];

        /* Validate vertex indices */
        if (i0 >= 0 && i0 < vertex_count &&
            i1 >= 0 && i1 < vertex_count &&
            i2 >= 0 && i2 < vertex_count) {

            /* Load vertex positions (always 3-component X,Y,Z) */
            v0[0] = vertices[i0*3]; v0[1] = vertices[i0*3+1]; v0[2] = vertices[i0*3+2]; v0[3] = 1.0f;
            v1[0] = vertices[i1*3]; v1[1] = vertices[i1*3+1]; v1[2] = vertices[i1*3+2]; v1[3] = 1.0f;
            v2[0] = vertices[i2*3]; v2[1] = vertices[i2*3+1]; v2[2] = vertices[i2*3+2]; v2[3] = 1.0f;

            /* For comp=2 vertices, Z is always 0 (no Z component in data).
             * The auto-camera places the camera looking at Z=0 from a positive Z,
             * so vertices at Z=0 will be at view_z = -view_dist (in front of camera).
             * No special Z offset needed — the auto-camera handles this correctly.
             * Previously we set Z=0.01 which put vertices BEHIND the camera
             * (clip.w < 0) when the camera looked along -Z from positive Z. */
            /* (no Z hack needed for comp=2 — auto-camera handles Z=0 correctly) */

            /* Apply MVP transformation */
            m3g_transform_point(clip0, mvp_matrix, v0);
            m3g_transform_point(clip1, mvp_matrix, v1);
            m3g_transform_point(clip2, mvp_matrix, v2);

            /* DIAG: log first triangle clip coords per mesh */
            if (mesh_triangles == 0 && g_m3g_clip_triangles_in == 0) {
                fprintf(stderr, "[M3G-CLIP] comp=%d v0=(%.3f,%.3f,%.3f) v1=(%.3f,%.3f,%.3f) v2=(%.3f,%.3f,%.3f)\n",
                        pos_components, v0[0], v0[1], v0[2], v1[0], v1[1], v1[2], v2[0], v2[1], v2[2]);
                fprintf(stderr, "[M3G-CLIP] clip0=(%.3f,%.3f,%.3f,w=%.3f) clip1=(%.3f,%.3f,%.3f,w=%.3f) clip2=(%.3f,%.3f,%.3f,w=%.3f)\n",
                        clip0[0], clip0[1], clip0[2], clip0[3],
                        clip1[0], clip1[1], clip1[2], clip1[3],
                        clip2[0], clip2[1], clip2[2], clip2[3]);
                /* v22 DIAG: full MVP rows so the math can be verified offline
                 * (row-major print, m[col*4+row] like the internal layout). */
                {
                    static int mvp_dumps = 0;
                    if (mvp_dumps++ < 6) {
                        fprintf(stderr, "[M3G-MVP2] MV rows:\n");
                        for (int r = 0; r < 4; r++) {
                            fprintf(stderr, "[M3G-MVP2]   %.3f %.3f %.3f %.3f\n",
                                    mvp_matrix->m[r], mvp_matrix->m[4 + r],
                                    mvp_matrix->m[8 + r], mvp_matrix->m[12 + r]);
                        }
                    }
                }
                /* Compute predicted screen coords for diagnosis */
                if (clip0[3] > 0.001f) {
                    float sw = clip0[3];
                    float sx = (clip0[0]/sw + 1.0f) * 0.5f * g_m3g.viewport_width;
                    float sy = (1.0f - clip0[1]/sw) * 0.5f * g_m3g.viewport_height;
                    fprintf(stderr, "[M3G-CLIP] Predicted screen0=(%.1f,%.1f) depth=%.3f\n", sx, sy, clip0[2]/sw);
                } else {
                    fprintf(stderr, "[M3G-CLIP] clip0.w=%.3f BEHIND CAMERA (w < 0.001)\n", clip0[3]);
                }
            }

            /* Determine per-vertex colors */
            uint8_t c0[4], c1[4], c2[4];
            uint8_t* pc0 = NULL, *pc1 = NULL, *pc2 = NULL;

            if (color_va) {
                JavaArray* color_data = (JavaArray*)m3g_get_ref_field(color_va, "data");
                int color_components = m3g_get_int_field(color_va, "componentCount", 4);
                int color_size = m3g_get_int_field(color_va, "componentSize", 1);

                if (color_data) {
                    #define READ_VCOLOR(out, vert_idx) do { \
                        memset(out, 0, 4); \
                        if (color_size == 1) { \
                            uint8_t* cd = (uint8_t*)array_data(color_data); \
                            int base = (vert_idx) * color_components; \
                            if (base + color_components - 1 < (int)color_data->length) { \
                                if (color_components == 3) { \
                                    out[0] = cd[base]; out[1] = cd[base+1]; out[2] = cd[base+2]; out[3] = 255; \
                                } else { \
                                    out[0] = cd[base]; out[1] = cd[base+1]; out[2] = cd[base+2]; out[3] = cd[base+3]; \
                                } \
                            } \
                        } else { \
                            int16_t* cd = (int16_t*)array_data(color_data); \
                            int base = (vert_idx) * color_components; \
                            if (base + color_components - 1 < (int)color_data->length) { \
                                if (color_components == 3) { \
                                    out[0] = (uint8_t)cd[base]; out[1] = (uint8_t)cd[base+1]; out[2] = (uint8_t)cd[base+2]; out[3] = 255; \
                                } else { \
                                    out[0] = (uint8_t)cd[base]; out[1] = (uint8_t)cd[base+1]; out[2] = (uint8_t)cd[base+2]; out[3] = (uint8_t)cd[base+3]; \
                                } \
                            } \
                        } \
                    } while(0)

                    READ_VCOLOR(c0, indices[t]);
                    READ_VCOLOR(c1, indices[t+1]);
                    READ_VCOLOR(c2, indices[t+2]);
                    pc0 = c0; pc1 = c1; pc2 = c2;
                }
            }

            /* If no vertex colors, use material default color */
            if (!pc0) {
                memcpy(c0, default_color, 4);
                memcpy(c1, default_color, 4);
                memcpy(c2, default_color, 4);
                pc0 = c0; pc1 = c1; pc2 = c2;
            }

            /* Task 16-a item 1: Gouraud lighting (guarded by light count —
             * with no lights these blocks are compiled-out no-ops and the
             * colors above flow to the rasterizer exactly as in v22). */
            if (use_lighting && lit_colors) {
                /* Normals path: per-vertex colors computed in the pre-pass */
                c0[0] = (uint8_t)lit_colors[i0 * 4 + 0];
                c0[1] = (uint8_t)lit_colors[i0 * 4 + 1];
                c0[2] = (uint8_t)lit_colors[i0 * 4 + 2];
                c0[3] = (uint8_t)lit_colors[i0 * 4 + 3];
                c1[0] = (uint8_t)lit_colors[i1 * 4 + 0];
                c1[1] = (uint8_t)lit_colors[i1 * 4 + 1];
                c1[2] = (uint8_t)lit_colors[i1 * 4 + 2];
                c1[3] = (uint8_t)lit_colors[i1 * 4 + 3];
                c2[0] = (uint8_t)lit_colors[i2 * 4 + 0];
                c2[1] = (uint8_t)lit_colors[i2 * 4 + 1];
                c2[2] = (uint8_t)lit_colors[i2 * 4 + 2];
                c2[3] = (uint8_t)lit_colors[i2 * 4 + 3];
            } else if (use_lighting && !normal_data) {
                /* No normals: flat light with the object-space face normal */
                float e1[3] = { v1[0] - v0[0], v1[1] - v0[1], v1[2] - v0[2] };
                float e2[3] = { v2[0] - v0[0], v2[1] - v0[1], v2[2] - v0[2] };
                float fn[3] = {
                    e1[1] * e2[2] - e1[2] * e2[1],
                    e1[2] * e2[0] - e1[0] * e2[2],
                    e1[0] * e2[1] - e1[1] * e2[0]
                };
                const M3GTransform* mv = &g_m3g_current_modelview;
                float n_view[3];
                n_view[0] = mv->m[0] * fn[0] + mv->m[4] * fn[1] + mv->m[8]  * fn[2];
                n_view[1] = mv->m[1] * fn[0] + mv->m[5] * fn[1] + mv->m[9]  * fn[2];
                n_view[2] = mv->m[2] * fn[0] + mv->m[6] * fn[1] + mv->m[10] * fn[2];
                /* Lighting needs a view-space position; use the face centre
                 * (constant across the face for directional lights anyway). */
                float centre_obj[4] = {
                    (v0[0] + v1[0] + v2[0]) / 3.0f,
                    (v0[1] + v1[1] + v2[1]) / 3.0f,
                    (v0[2] + v1[2] + v2[2]) / 3.0f, 1.0f };
                float centre_view[4];
                m3g_transform_point(centre_view, &g_m3g_current_modelview, centre_obj);
                float lit[3];
                m3g_light_vertex(lit, centre_view, n_view, &lit_material,
                                 m3g_appearance.two_sided_lighting);
                /* Per-vertex colors modulate the lit face color (JSR-184
                 * vertex-color tracking style). Without a color array the
                 * material term alone is the color. */
                float k0[3] = {1,1,1}, k1[3] = {1,1,1}, k2[3] = {1,1,1};
                if (color_va) {
                    k0[0] = c0[0] / 255.0f; k0[1] = c0[1] / 255.0f; k0[2] = c0[2] / 255.0f;
                    k1[0] = c1[0] / 255.0f; k1[1] = c1[1] / 255.0f; k1[2] = c1[2] / 255.0f;
                    k2[0] = c2[0] / 255.0f; k2[1] = c2[1] / 255.0f; k2[2] = c2[2] / 255.0f;
                }
                c0[0] = (uint8_t)(lit[0] * k0[0] * 255.0f + 0.5f);
                c0[1] = (uint8_t)(lit[1] * k0[1] * 255.0f + 0.5f);
                c0[2] = (uint8_t)(lit[2] * k0[2] * 255.0f + 0.5f);
                c1[0] = (uint8_t)(lit[0] * k1[0] * 255.0f + 0.5f);
                c1[1] = (uint8_t)(lit[1] * k1[1] * 255.0f + 0.5f);
                c1[2] = (uint8_t)(lit[2] * k1[2] * 255.0f + 0.5f);
                c2[0] = (uint8_t)(lit[0] * k2[0] * 255.0f + 0.5f);
                c2[1] = (uint8_t)(lit[1] * k2[1] * 255.0f + 0.5f);
                c2[2] = (uint8_t)(lit[2] * k2[2] * 255.0f + 0.5f);
            }

            /* Get texture coordinates for this triangle */
            float tc0[2] = {0, 0}, tc1[2] = {0, 0}, tc2[2] = {0, 0};
            float* ptc0 = NULL, *ptc1 = NULL, *ptc2 = NULL;

            if (tex_coords && texture) {
                int ti0 = indices[t] * tex_components;
                int ti1 = indices[t+1] * tex_components;
                int ti2 = indices[t+2] * tex_components;
                if (ti0 + 1 < vertex_count * tex_components &&
                    ti1 + 1 < vertex_count * tex_components &&
                    ti2 + 1 < vertex_count * tex_components) {
                    tc0[0] = tex_coords[ti0]; tc0[1] = tex_coords[ti0+1];
                    tc1[0] = tex_coords[ti1]; tc1[1] = tex_coords[ti1+1];
                    tc2[0] = tex_coords[ti2]; tc2[1] = tex_coords[ti2+1];
                    ptc0 = tc0; ptc1 = tc1; ptc2 = tc2;
                }
            }

            /* Near-plane clipping using Sutherland-Hodgman (v25: eye plane
             * w>=eps FIRST, then the true near plane z+w>=0 — a clipped
             * polygon can fan out to 3 triangles, hence the [9] buffers). */
            g_m3g_clip_triangles_in++;
            {
                const float* clip_in[3] = { clip0, clip1, clip2 };
                const uint8_t* color_in[3] = { pc0, pc1, pc2 };
                const float* tex_in[3] = { ptc0, ptc1, ptc2 };
                float clip_out[9][4];
                uint8_t color_out[9][4];
                float tex_out[9][2];

                int num_tris = m3g_clip_triangle_near(clip_in, color_in, tex_in,
                                                       clip_out, color_out, tex_out);

                for (int ct = 0; ct < num_tris; ct++) {
                    int base = ct * 3;
                    m3g_rasterize_triangle(clip_out[base], clip_out[base+1], clip_out[base+2],
                                           ptc0 ? tex_out[base] : NULL,
                                           ptc0 ? tex_out[base+1] : NULL,
                                           ptc0 ? tex_out[base+2] : NULL,
                                           color_out[base], color_out[base+1], color_out[base+2],
                                           &m3g_appearance);  /* FIX 44: Always pass appearance for culling/blending */
                }
                g_m3g_clip_triangles_out += num_tris;
            }
        }
    }

    LOG_SAFE( "[M3G] renderMesh: clipped %d→%d triangles (total rendered=%d, pixels=%d)\n",
            g_m3g_clip_triangles_in, g_m3g_clip_triangles_out,
            g_m3g.triangles_rendered, g_m3g_raster_pixels_written);

    /* Restore global render state after this mesh */
    g_m3g.culling_enabled = saved_culling;
    g_m3g.depth_test_enabled = saved_depth_test;
    g_m3g.depth_write_enabled = saved_depth_write;

    if (need_free_indices) free(indices);
    /* vertices is pool-allocated, no free needed */
    if (tex_coords) free(tex_coords);
    /* FIX(uaf): 'texture' comes from g_m3g_texture_cache (m3g_build_texture2d
     * always stores its result there before returning) and the cache OWNS all
     * built M3GTexture2D instances. Freeing it here left a dangling pointer in
     * the cache: next frame m3g_lookup_texture_cache() handed out freed memory
     * (heap-use-after-free read at line ~3259) and m3g_clear_texture_cache()
     * later freed it AGAIN -> "double free or corruption" abort. Textures are
     * released exclusively by m3g_clear_texture_cache(). */
}

/* Recursively render a node and its children, applying transforms */
static void m3g_render_node_recursive(JVM* jvm, JavaObject* node, M3GTransform* parent_modelview) {
    if (!node) return;

    /* v15: nodes can arrive from C-side caches (g_m3g_last_world,
     * pending-render queue). Skip dead objects instead of crashing. */
    if (!heap_java_object_valid(node)) {
        fprintf(stderr, "[M3G] renderNode: node %p is DEAD (GC'd), skipped\n", (void*)node);
        return;
    }

    JavaClass* clazz = node->header.clazz;
    if (!clazz || !clazz->class_name) return;

    const char* class_name = clazz->class_name;

    /* Build this node's transform */
    M3GTransform node_transform;
    m3g_build_node_transform(node, &node_transform);

    /* Combine with parent: modelview = parent * node */
    M3GTransform combined_modelview;
    m3g_transform_multiply(&combined_modelview, parent_modelview, &node_transform);

    /* Build MVP = projection * modelview (OpenGL convention) */
    M3GTransform mvp;
    m3g_transform_multiply(&mvp, &g_m3g.projection, &combined_modelview);

    /* If this node is a Mesh, render it */
    if (strstr(class_name, "Mesh") != NULL) {
        /* Check rendering enable */
        int render_enable = m3g_get_int_field(node, "renderingEnable", 1);
        LOG_SAFE( "[M3G] renderNode: class=%s, enable=%d\n", class_name, render_enable);
        if (render_enable) {
            /* Task 16-a: store the pre-projection modelview for the Gouraud
             * lighting path (m3g_render_single_mesh only sees the MVP). */
            g_m3g_current_modelview = combined_modelview;
            m3g_render_single_mesh(jvm, node, &mvp);
        }
        return;
    }

    /* If this node is a Light, collect it for the Gouraud lighting pass.
     * Task 16-a item 1: previously Light nodes were silently ignored, so
     * scene-graph lighting was dead. Lights never render themselves. */
    if (strstr(class_name, "Light") != NULL) {
        m3g_collect_scene_light(node, &combined_modelview);
        return;
    }

    /* If this node is a Sprite3D, render it as a billboard */
    if (strstr(class_name, "Sprite3D") != NULL) {
        /* v22: throttled - SU-30 renders ~50k Sprite3D nodes/frame, the
         * unconditional log flooded 2.4M lines/run and starved the game. */
        static int spr3d_logs = 0;
        if (spr3d_logs++ < 48) {
            fprintf(stderr, "[M3G] renderNode: Sprite3D at (%.1f, %.1f, %.1f)\n",
                    m3g_get_float_field(node, "translationX", 0),
                    m3g_get_float_field(node, "translationY", 0),
                    m3g_get_float_field(node, "translationZ", 0));
        }
        /* Task 16-a item 14: camera/screen alignment — an aligned Sprite3D is
         * rendered as a view-space billboard (node orientation dropped, the
         * sprite always faces the camera). Unaligned sprites keep the exact
         * v22 path. */
        if (m3g_get_ref_field(node, "alignZRef") != NULL ||
            m3g_get_int_field(node, "alignZTarget", 0) != 0) {
            M3GTransform billboard;
            m3g_transform_identity(&billboard);
            m3g_transform_scale(&billboard,
                    m3g_get_float_field(node, "scaleX", 1.0f),
                    m3g_get_float_field(node, "scaleY", 1.0f),
                    m3g_get_float_field(node, "scaleZ", 1.0f));
            m3g_transform_translate(&billboard,
                    m3g_get_float_field(node, "translationX", 0.0f),
                    m3g_get_float_field(node, "translationY", 0.0f),
                    m3g_get_float_field(node, "translationZ", 0.0f));
            M3GTransform aligned_mvp;
            m3g_transform_multiply(&combined_modelview, parent_modelview, &billboard);
            m3g_transform_multiply(&aligned_mvp, &g_m3g.projection, &combined_modelview);
            m3g_render_sprite3d(jvm, node, &aligned_mvp);
            return;
        }
        m3g_render_sprite3d(jvm, node, &mvp);
        return;
    }

    /* If this node is a Group or World, recurse into children */
    if (strstr(class_name, "Group") != NULL || strstr(class_name, "World") != NULL) {
        int children_slot = m3g_find_field_slot(node, "children");
        JavaArray* children = (JavaArray*)m3g_get_ref_field(node, "children");
        LOG_SAFE( "[M3G] renderNode: class=%s, children_slot=%d, children=%p, count=%d, elemType=%d\n",
                class_name, children_slot,
                (void*)children, children ? (int)children->length : -1,
                children ? (int)children->element_type : -1);
        if (children && children->length > 0 && children->element_type == DESC_OBJECT) {
            JavaObject** child_arr = (JavaObject**)array_data(children);
            int non_null = 0;
            if (!child_arr) return;
            /* v10 FIX: iterate the FULL array instead of trusting the
             * childCount field. Group.addChild()/World.addChild() never
             * incremented it, so game-built scenes reported childCount=0
             * and every reader saw "all children NULL" (SU-30 force-render
             * gave 0 triangles from the World). NULLs are skipped below. */
            int safe_count = (int)children->length;
            for (jsize c = 0; c < safe_count; c++) {
                if (child_arr[c] && child_arr[c]->header.clazz) {
                    non_null++;
                    /* v22: throttled child dump */
                    static int child_logs = 0;
                    if (child_logs++ < 64) {
                        fprintf(stderr, "[M3G] renderNode: child[%d]=%p class=%s\n",
                                c, (void*)child_arr[c],
                                child_arr[c]->header.clazz ? child_arr[c]->header.clazz->class_name : "?");
                    }
                    m3g_render_node_recursive(jvm, child_arr[c], &combined_modelview);
                }
            }
            if (non_null == 0) {
                static int null_logs = 0;
                if (null_logs++ < 16) {
                    fprintf(stderr, "[M3G] renderNode: all %d children are NULL\n", (int)children->length);
                }
            }
        } else if (children && children->element_type != DESC_OBJECT) {
            static int type_logs = 0;
            if (type_logs++ < 8) {
                fprintf(stderr, "[M3G] renderNode: children array has wrong element_type=%d (expected DESC_OBJECT=%d)\n",
                        (int)children->element_type, (int)DESC_OBJECT);
            }
        }
    }
}

/* Pixel blending modes matching FreeJ2ME Graphics3D.blendPixels */
static uint32_t m3g_blend_pixels(uint32_t bg, uint32_t fg, int alpha, int blend_mode) {
    int bgA = (bg >> 24) & 0xFF;
    int bgR = (bg >> 16) & 0xFF;
    int bgG = (bg >> 8) & 0xFF;
    int bgB = bg & 0xFF;

    int fgA = (fg >> 24) & 0xFF;
    int fgR = (fg >> 16) & 0xFF;
    int fgG = (fg >> 8) & 0xFF;
    int fgB = fg & 0xFF;

    int outR, outG, outB, outA;
    float alphaNorm = alpha / 255.0f;

    #define CLAMP8(v) ((v) < 0 ? 0 : ((v) > 255 ? 255 : (v)))

    switch (blend_mode) {
        /* CompositingMode.REPLACE / Texture2D.FUNC_REPLACE */
        case 67:
            outA = CLAMP8((int)(fgA + bgA * (1 - fgA / 255.0f)));
            outR = CLAMP8((int)(fgR * (fgA / 255.0f) + bgR * (1 - fgA / 255.0f)));
            outG = CLAMP8((int)(fgG * (fgA / 255.0f) + bgG * (1 - fgA / 255.0f)));
            outB = CLAMP8((int)(fgB * (fgA / 255.0f) + bgB * (1 - fgA / 255.0f)));
            return ((uint32_t)(outA) <<  24) | (outR << 16) | (outG << 8) | outB;

        /* CompositingMode.ALPHA_ADD */
        case 65:
            outR = (int)fminf(255.0f, fgR * alphaNorm + bgR);
            outG = (int)fminf(255.0f, fgG * alphaNorm + bgG);
            outB = (int)fminf(255.0f, fgB * alphaNorm + bgB);
            outA = (int)fminf(255.0f, bgA + (int)(alpha * (1 - bgA / 255.0f)));
            return ((uint32_t)(outA) <<  24) | (outR << 16) | (outG << 8) | outB;

        /* CompositingMode.ALPHA / Texture2D.FUNC_BLEND */
        case 64:
            outR = CLAMP8((int)((fgR * alphaNorm) + (bgR * (1 - alphaNorm))));
            outG = CLAMP8((int)((fgG * alphaNorm) + (bgG * (1 - alphaNorm))));
            outB = CLAMP8((int)((fgB * alphaNorm) + (bgB * (1 - alphaNorm))));
            outA = CLAMP8((int)(bgA * (1 - alphaNorm) + fgA * alphaNorm));
            return ((uint32_t)(outA) <<  24) | (outR << 16) | (outG << 8) | outB;

        /* CompositingMode.MODULATE / Texture2D.FUNC_MODULATE */
        case 68:
            outR = (fgR * bgR) / 255;
            outG = (fgG * bgG) / 255;
            outB = (fgB * bgB) / 255;
            outA = bgA > fgA ? bgA : fgA;
            return ((uint32_t)(CLAMP8(outA)) <<  24) | (CLAMP8(outR) << 16) | (CLAMP8(outG) << 8) | CLAMP8(outB);

        /* CompositingMode.MODULATE_X2 */
        case 69:
            outR = (2 * fgR * bgR) / 255;
            outG = (2 * fgG * bgG) / 255;
            outB = (2 * fgB * bgB) / 255;
            outA = bgA > fgA ? bgA : fgA;
            return ((uint32_t)(CLAMP8(outA)) <<  24) | (CLAMP8(outR) << 16) | (CLAMP8(outG) << 8) | CLAMP8(outB);

        /* Texture2D.FUNC_DECAL */
        case 70:
            outR = (fgR * fgA / 255) + (bgR * (255 - fgA) / 255);
            outG = (fgG * fgA / 255) + (bgG * (255 - fgA) / 255);
            outB = (fgB * fgA / 255) + (bgB * (255 - fgA) / 255);
            outA = fgA;
            return ((uint32_t)(CLAMP8(outA)) <<  24) | (CLAMP8(outR) << 16) | (CLAMP8(outG) << 8) | CLAMP8(outB);

        /* Texture2D.FUNC_ADD */
        case 71:
            outR = bgR + fgR < 255 ? bgR + fgR : 255;
            outG = bgG + fgG < 255 ? bgG + fgG : 255;
            outB = bgB + fgB < 255 ? bgB + fgB : 255;
            outA = bgA > fgA ? bgA : fgA;
            return ((uint32_t)(CLAMP8(outA)) <<  24) | (outR << 16) | (outG << 8) | outB;

        default:
            return bg;
    }
    #undef CLAMP8
}

/* Fog blending matching FreeJ2ME Graphics3D.blendFog */
static uint32_t m3g_blend_fog(uint32_t pixel_color, int fog_color, float fog_factor) {
    int r = (int)(((pixel_color >> 16) & 0xFF) * fog_factor + ((fog_color >> 16) & 0xFF) * (1 - fog_factor));
    int g = (int)(((pixel_color >> 8) & 0xFF) * fog_factor + ((fog_color >> 8) & 0xFF) * (1 - fog_factor));
    int b = (int)((pixel_color & 0xFF) * fog_factor + (fog_color & 0xFF) * (1 - fog_factor));
    /* Fog is always fully opaque */
    return ((uint32_t)(255) <<  24) | (r << 16) | (g << 8) | b;
}

/* v23: M3GRenderState moved above m3g_render_single_mesh (it was defined
 * below its first use, which never compiled). */

/* Read render state from Appearance object (CompositingMode, Fog, etc.)
 * Task 16-a item 2: now actually used — m3g_render_single_mesh propagates
 * the fog block into the per-mesh M3GAppearance so the rasterizer's fog
 * math runs when an Appearance carries a Fog. */
static void m3g_read_render_state(M3GRenderState* state, JavaObject* appearance) {
    memset(state, 0, sizeof(M3GRenderState));
    state->depth_test = 1;   /* Default: depth test ON */
    state->depth_write = 1;  /* Default: depth write ON */
    state->alpha_threshold = 0.0f;
    state->blend_mode = 64;  /* Default: ALPHA */
    state->texture_blend = 70; /* Default: FUNC_DECAL */

    if (!appearance) return;

    /* Read CompositingMode */
    JavaObject* compositing = m3g_get_ref_field(appearance, "compositingMode");
    if (compositing) {
        state->blend_mode = m3g_get_int_field(compositing, "blending", 64);
        /* v12: defensive mapping — if the value is a raw M3G file index
         * (0..5, e.g. set by game code or older save paths), convert it.
         * API constants are 64..70, so 0..5 is unambiguous. */
        if (state->blend_mode >= 0 && state->blend_mode <= 5) {
            static const uint8_t map[6] = { 64, 65, 68, 69, 67, 70 };
            state->blend_mode = map[state->blend_mode];
        }
        state->depth_test = m3g_get_int_field(compositing, "depthTest", 1);
        state->depth_write = m3g_get_int_field(compositing, "depthWrite", 1);
        state->alpha_threshold = m3g_get_float_field(compositing, "alphaThreshold", 0.0f);
    }

    /* Read Fog */
    JavaObject* fog = m3g_get_ref_field(appearance, "fog");
    if (fog) {
        state->fog_enabled = 1;
        state->fog_color = m3g_get_int_field(fog, "color", 0);
        /* Task 16-a item 2: mode normalization. Two encodings reach the
         * field: M3G binary/API constants (Fog.LINEAR=80, EXPONENTIAL=81)
         * and the rasterizer's internal 0/1 (0=EXP, 1=LINEAR). Accept both. */
        int raw_mode = m3g_get_int_field(fog, "mode", 0);
        if (raw_mode == 80 || raw_mode == 1) state->fog_mode = 1;      /* LINEAR */
        else if (raw_mode == 81 || raw_mode == 0) state->fog_mode = 0; /* EXPONENTIAL */
        else state->fog_mode = 0;
        state->fog_density = m3g_get_float_field(fog, "density", 1.0f);
        state->fog_near = m3g_get_float_field(fog, "nearDistance", 0.0f);
        state->fog_far = m3g_get_float_field(fog, "farDistance", 1.0f);
    }

    /* Read texture blend mode from Texture2D */
    JavaObject* texture = m3g_get_ref_field(appearance, "texture");
    if (texture) {
        state->texture_blend = m3g_get_int_field(texture, "blending", 70);
    }
}

/* Rasterize a single triangle - matches FreeJ2ME Graphics3D scanline rendering
 * Optimized for ARMv7: incremental edge functions, pre-computed row pointers,
 * cached inverse area, and local buffer stride to avoid repeated struct access. */
M3G_HOT static void m3g_rasterize_triangle(const float* v0, const float* v1, const float* v2,
                                    const float* t0, const float* t1, const float* t2,
                                    const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                    M3GAppearance* appearance) {
    /* Screen coordinates */
    float s0[4], s1[4], s2[4];
    if (m3g_clip_to_screen(s0, v0) < 0) return;
    if (m3g_clip_to_screen(s1, v1) < 0) return;
    if (m3g_clip_to_screen(s2, v2) < 0) return;
    
    /* Skip triangles outside viewport (depth-based) */
    if (s0[2] < 0 && s1[2] < 0 && s2[2] < 0) return;
    if (s0[2] > 1 && s1[2] > 1 && s2[2] > 1) return;
    
    /* Back-face culling
     * FIX 42: Respect winding order and culling mode from PolygonMode.
     * M3G default front face is CCW (winding=0). Our screen space is
     * Y-DOWN (m3g_clip_to_screen flips Y), so a front-facing (CCW in
     * eye space) triangle arrives CLOCKWISE on screen, and this edge
     * function E(a,b,c) = (c-a)×(b-a) yields a NEGATIVE value for it.
     * v24 FIX (Brick Breaker): the sign was inverted (front = e >= 0),
     * which culled 100% of the spec-correct CCW meshes and rendered
     * only their back faces (nothing, for one-sided walls). So:
     *   - winding=0 (CCW): negative e = front face
     *   - winding=1 (CW):  positive e = front face
     * CULL_BACK (default): cull back faces (keep front)
     * CULL_FRONT: cull front faces (keep back)
     * twoSidedLighting: disables all culling */
    if (g_m3g.culling_enabled) {
        int is_two_sided = 0;
        if (appearance && appearance->two_sided_lighting) is_two_sided = 1;
        if (!is_two_sided) {
            float e = m3g_edge_function(s0, s1, s2);
            int winding = appearance ? appearance->winding : 0;
            int is_front;
            if (winding == 0) { /* CCW front face (Y-down screen): negative e = front */
                is_front = (e < 0);
            } else { /* CW front face: positive e = front */
                is_front = (e >= 0);
            }
            int cull_front = appearance ? appearance->cull_front : 0;
            if (cull_front) {
                /* CULL_FRONT: discard front-facing triangles */
                if (is_front) return;
            } else {
                /* CULL_BACK: discard back-facing triangles */
                if (!is_front) return;
            }
        }
    }
    
    /* Bounding box */
    float fmin_x = s0[0] < s1[0] ? (s0[0] < s2[0] ? s0[0] : s2[0]) : (s1[0] < s2[0] ? s1[0] : s2[0]);
    float fmax_x = s0[0] > s1[0] ? (s0[0] > s2[0] ? s0[0] : s2[0]) : (s1[0] > s2[0] ? s1[0] : s2[0]);
    float fmin_y = s0[1] < s1[1] ? (s0[1] < s2[1] ? s0[1] : s2[1]) : (s1[1] < s2[1] ? s1[1] : s2[1]);
    float fmax_y = s0[1] > s1[1] ? (s0[1] > s2[1] ? s0[1] : s2[1]) : (s1[1] > s2[1] ? s1[1] : s2[1]);
    
    int min_x = (int)fmin_x;
    int max_x = (int)fmax_x;
    int min_y = (int)fmin_y;
    int max_y = (int)fmax_y;
    
    /* Clip to viewport - cache dimensions locally */
    int buf_w = g_m3g.buffer_width;
    int buf_h = g_m3g.buffer_height;
    
    /* Early exit for fully offscreen triangles */
    if (max_x < 0 || min_x >= buf_w || max_y < 0 || min_y >= buf_h) return;
    
    if (min_x < 0) min_x = 0;
    if (max_x >= buf_w) max_x = buf_w - 1;
    if (min_y < 0) min_y = 0;
    if (max_y >= buf_h) max_y = buf_h - 1;
    
    /* Area for barycentric - pre-compute inverse to avoid division per pixel */
    float area = m3g_edge_function(s0, s1, s2);
    if (fabsf(area) < 0.001f) return;
    float inv_area = 1.0f / area;
    
    /* Read render state from appearance for blending/depth/fog control
     * FIX 43: Use per-mesh settings from CompositingMode (read during mesh render)
     * instead of hardcoded defaults. Fall back to globals when appearance is NULL. */
    M3GRenderState rstate;
    memset(&rstate, 0, sizeof(rstate));
    rstate.depth_test = g_m3g.depth_test_enabled;
    rstate.depth_write = g_m3g.depth_write_enabled;
    rstate.alpha_threshold = 0.0f;
    rstate.blend_mode = 64;  /* ALPHA */
    rstate.texture_blend = 70; /* FUNC_DECAL */
    if (appearance) {
        if (appearance->blend_mode >= 0) {
            rstate.blend_mode = appearance->blend_mode;
            /* v12: defensive file-index mapping (see CompositingMode parser fix) */
            if (rstate.blend_mode >= 0 && rstate.blend_mode <= 5) {
                static const uint8_t blend_map[6] = { 64, 65, 68, 69, 67, 70 };
                rstate.blend_mode = blend_map[rstate.blend_mode];
            }
        }
        if (appearance->alpha_threshold >= 0) rstate.alpha_threshold = (float)appearance->alpha_threshold / 255.0f;
        if (appearance->texture_blend > 0) rstate.texture_blend = appearance->texture_blend;
    }
    
    /* Cache buffer pointers locally for the inner loop - avoids repeated g_m3g dereference */
    uint32_t* color_buf = g_m3g.color_buffer;
    float* depth_buf = g_m3g.depth_buffer;
    int stride = buf_w;  /* pixels per row */
    
    /* Pre-compute edge function increments for scanline optimization.
     * The edge function E(a, b, p) = (p.x - a.x)*(b.y - a.y) - (p.y - a.y)*(b.x - a.x)
     * When moving from pixel (x,y) to (x+1,y), the increment is: (b.y - a.y)
     * When moving from row y to y+1, the decrement is: (b.x - a.x) */
    float row0_step_x = s2[1] - s1[1];  /* dw0/dx */
    float row0_step_y = -(s2[0] - s1[0]); /* dw0/dy */
    float row1_step_x = s0[1] - s2[1];  /* dw1/dx */
    float row1_step_y = -(s0[0] - s2[0]); /* dw1/dy */
    float row2_step_x = s1[1] - s0[1];  /* dw2/dx */
    float row2_step_y = -(s1[0] - s0[0]); /* dw2/dy */
    
    /* Pre-compute edge function at top-left corner (min_x + 0.5, min_y + 0.5) */
    float start_px = min_x + 0.5f;
    float start_py = min_y + 0.5f;
    float row_w0 = ((start_px - s1[0]) * (s2[1] - s1[1]) - (start_py - s1[1]) * (s2[0] - s1[0]));
    float row_w1 = ((start_px - s2[0]) * (s0[1] - s2[1]) - (start_py - s2[1]) * (s0[0] - s2[0]));
    float row_w2 = ((start_px - s0[0]) * (s1[1] - s0[1]) - (start_py - s0[1]) * (s1[0] - s0[0]));
    
    /* Has vertex colors flag - hoisted out of inner loop */
    int has_vertex_colors = (c0 && c1 && c2);
    int has_texture = (appearance && appearance->texture && t0 && t1 && t2);
    int has_fog = rstate.fog_enabled;
    int do_depth_test = rstate.depth_test;
    int do_depth_write = rstate.depth_write;
    int blend_mode = rstate.blend_mode;
    int texture_blend = rstate.texture_blend;
    float alpha_threshold = rstate.alpha_threshold;
    int fog_mode = rstate.fog_mode;
    float fog_density = rstate.fog_density;
    float fog_near = rstate.fog_near;
    float fog_far = rstate.fog_far;
    int fog_color = rstate.fog_color;
    
    /* Rasterize - incremental edge functions avoid redundant multiplications per pixel */
    int pixels_this_tri = 0;
    for (int y = min_y; y <= max_y; y++) {
        /* Reset w0/w1/w2 for this row using incremental step from previous row */
        float w0 = row_w0 * inv_area;
        float w1 = row_w1 * inv_area;
        float w2 = row_w2 * inv_area;
        
        int row_idx = y * stride;
        
        for (int x = min_x; x <= max_x; x++) {
            /* Inside triangle? (all barycentric >= 0) */
            if (w0 >= 0 && w1 >= 0 && w2 >= 0) {
                /* Depth test */
                float z = s0[2] * w0 + s1[2] * w1 + s2[2] * w2;
                int idx = row_idx + x;
                
                if (do_depth_test && depth_buf[idx] < z) {
                    /* Existing pixel is closer, skip */
                } else {
                    /* Perspective correction; 1/w interpolated here is also
                     * the fog distance proxy: w_clip = view distance for the
                     * standard perspective projection (v14 fog fix). */
                    float one_over_w = s0[3] * w0 + s1[3] * w1 + s2[3] * w2;
                    float fog_dist = (one_over_w > 1e-9f) ? (1.0f / one_over_w) : 0.0f;
                    
                    /* Interpolate color (v14: perspective-correct) */
                    uint8_t color[4] = {255, 255, 255, 255};
                    if (has_vertex_colors) {
                        m3g_interpolate_color(color, c0, c1, c2, w0, w1, w2,
                                              s0[3], s1[3], s2[3]);
                    }
                    
                    /* Determine the paint pixel */
                    uint32_t paint_pixel;
                    
                    /* Texture sampling */
                    if (has_texture) {
                        float uv[2];
                        /* v14 FIX: pass per-vertex 1/w (screen[3]) for true
                         * perspective-correct UV interpolation. The old code
                         * multiplied screen-linear UV by the interpolated 1/w,
                         * collapsing the whole texture into a few texels
                         * (Nescube black cube) and stretching it nonlinearly
                         * across faces (SU30 / M3GTest scene 4). */
                        m3g_interpolate_texcoord(uv, t0, t1, t2, w0, w1, w2,
                                                 s0[3], s1[3], s2[3]);
                        /* v14: Texture2D.setTransform — affine UV transform
                         * (row-major 4x4; typical usage is UV scrolling). */
                        if (appearance->texture->has_uv_transform) {
                            const float* M = appearance->texture->uv_transform;
                            float tu = M[0] * uv[0] + M[1] * uv[1] + M[3];
                            float tv = M[4] * uv[0] + M[5] * uv[1] + M[7];
                            uv[0] = tu;
                            uv[1] = tv;
                        }
                        uint32_t tex_color = m3g_sample_texture(appearance->texture, uv[0], uv[1]);
                        /* v14 DIAG: first texture samples per run */
                        {
                            static int sample_diag = 0;
                            if (sample_diag < 10) {
                                sample_diag++;
                                fprintf(stderr, "[M3G-SAMP] uv=(%.4f,%.4f) texel=%08X tblend=%d cblend=%d vcol=%d\n",
                                        uv[0], uv[1], tex_color, texture_blend, blend_mode,
                                        has_vertex_colors ? 1 : 0);
                            }
                        }
                        
                        paint_pixel = tex_color;
                        
                        /* Check alpha threshold */
                        int tex_alpha = (tex_color >> 24) & 0xFF;
                        if (tex_alpha < (int)(alpha_threshold * 255)) {
                            /* Skip transparent pixels below threshold */
                        } else if (has_vertex_colors) {
                            uint32_t vert_color = ((uint32_t)(color[3]) <<  24) | (color[0] << 16) | (color[1] << 8) | color[2];
                            if (texture_blend == 64) {
                                /* v14: Texture2D.FUNC_BLEND (API 164):
                                 * Cs*(1-Ct_a) + Cblend*Ct_a. Value 64 here can
                                 * only come from FUNC_BLEND — CompositingMode
                                 * blending never flows through texture_blend. */
                                int bc = appearance->texture ? appearance->texture->blend_color : 0;
                                uint32_t blend_rgb = ((uint32_t)(bc >> 16) & 0xFF) << 16 |
                                                     ((uint32_t)(bc >> 8) & 0xFF) << 8 |
                                                     (bc & 0xFF);
                                paint_pixel = m3g_blend_pixels(vert_color, blend_rgb, tex_alpha, 64);
                            } else {
                                paint_pixel = m3g_blend_pixels(vert_color, tex_color, tex_alpha, texture_blend);
                            }
                            
                            int paint_alpha = (paint_pixel >> 24) & 0xFF;
                            
                            if (has_fog) {
                                float fog_factor = 0.0f;
                                if (fog_mode == 1) { /* LINEAR */
                                    float range = fog_far - fog_near;
                                    if (range > 0.0001f) {
                                        /* v14 FIX: use VIEW distance (1/interp 1/w),
                                         * not NDC depth (0..1). NDC z made fog
                                         * distances meaningless. */
                                        fog_factor = (fog_far - fog_dist) / range;
                                        if (fog_factor < 0.0f) fog_factor = 0.0f;
                                        if (fog_factor > 1.0f) fog_factor = 1.0f;
                                    }
                                } else { /* EXPONENTIAL */
                                    fog_factor = expf(-fog_density * fog_dist);
                                    if (fog_factor < 0.0f) fog_factor = 0.0f;
                                    if (fog_factor > 1.0f) fog_factor = 1.0f;
                                }
                                paint_pixel = m3g_blend_fog(paint_pixel, fog_color, fog_factor);
                            }
                            
                            uint32_t bg_pixel = color_buf[idx];
                            uint32_t final_pixel = m3g_blend_pixels(bg_pixel, paint_pixel, paint_alpha, blend_mode);
                            color_buf[idx] = final_pixel;
                            if (do_depth_write) depth_buf[idx] = z;
                            pixels_this_tri++;
                        } else {
                            int paint_alpha = (paint_pixel >> 24) & 0xFF;
                            if (has_fog) {
                                float fog_factor = 0.0f;
                                if (fog_mode == 1) {
                                    float range = fog_far - fog_near;
                                    if (range > 0.0001f) {
                                        fog_factor = (fog_far - fog_dist) / range; /* v14: view distance */
                                        if (fog_factor < 0.0f) fog_factor = 0.0f;
                                        if (fog_factor > 1.0f) fog_factor = 1.0f;
                                    }
                                } else {
                                    fog_factor = expf(-fog_density * fog_dist); /* v14 */
                                    if (fog_factor < 0.0f) fog_factor = 0.0f;
                                    if (fog_factor > 1.0f) fog_factor = 1.0f;
                                }
                                paint_pixel = m3g_blend_fog(paint_pixel, fog_color, fog_factor);
                            }
                            uint32_t bg_pixel = color_buf[idx];
                            uint32_t final_pixel = m3g_blend_pixels(bg_pixel, paint_pixel, paint_alpha, blend_mode);
                            color_buf[idx] = final_pixel;
                            if (do_depth_write) depth_buf[idx] = z;
                            pixels_this_tri++;
                        }
                    } else {
                        /* No texture - use vertex color directly */
                        paint_pixel = ((uint32_t)(color[3]) <<  24) | (color[0] << 16) | (color[1] << 8) | color[2];
                        int paint_alpha = (paint_pixel >> 24) & 0xFF;
                        
                        if (has_fog) {
                            float fog_factor = 0.0f;
                            if (fog_mode == 1) {
                                float range = fog_far - fog_near;
                                if (range > 0.0001f) {
                                    fog_factor = (fog_far - fog_dist) / range; /* v14: view distance */
                                    if (fog_factor < 0.0f) fog_factor = 0.0f;
                                    if (fog_factor > 1.0f) fog_factor = 1.0f;
                                }
                            } else {
                                fog_factor = expf(-fog_density * fog_dist); /* v14 */
                                if (fog_factor < 0.0f) fog_factor = 0.0f;
                                if (fog_factor > 1.0f) fog_factor = 1.0f;
                            }
                            paint_pixel = m3g_blend_fog(paint_pixel, fog_color, fog_factor);
                        }
                        
                        uint32_t bg_pixel = color_buf[idx];
                        uint32_t final_pixel = m3g_blend_pixels(bg_pixel, paint_pixel, paint_alpha, blend_mode);
                        /* v14 DIAG: first untextured writes — trace bg-colored
                         * mesh paints (scene 7 / black-cube reports) */
                        {
                            static int wc = 0;
                            wc++;
                            if (wc <= 8 || (wc % 40000) < 3) {
                                fprintf(stderr, "[M3G-WPIX] #%d paint=%08X alpha=%d bg=%08X final=%08X cblend=%d vcol=%d\n",
                                        wc, paint_pixel, paint_alpha, bg_pixel, final_pixel, blend_mode,
                                        has_vertex_colors ? 1 : 0);
                            }
                        }
                        color_buf[idx] = final_pixel;
                        if (do_depth_write) depth_buf[idx] = z;
                        pixels_this_tri++;
                    }
                }
            }
            
            /* Incremental edge function step for x+1 */
            w0 += row0_step_x * inv_area;
            w1 += row1_step_x * inv_area;
            w2 += row2_step_x * inv_area;
        }
        
        /* Incremental edge function step for next scanline (y+1) */
        row_w0 += row0_step_y;
        row_w1 += row1_step_y;
        row_w2 += row2_step_y;
    }
    
    g_m3g.triangles_rendered++;
    g_m3g_raster_pixels_written += pixels_this_tri;
    
    /* Diagnostic: log first 3 triangles with screen coords */
    static int diag_count = 0;
    if (diag_count < 3) {
        diag_count++;
        fprintf(stderr, "[M3G-RAST] tri#%d: s0=(%.1f,%.1f,z=%.3f) s1=(%.1f,%.1f,z=%.3f) s2=(%.1f,%.1f,z=%.3f) bbox=(%d,%d)-(%d,%d) c0=[%d,%d,%d,%d] pixels=%d\n",
                diag_count, s0[0], s0[1], s0[2], s1[0], s1[1], s1[2], s2[0], s2[1], s2[2],
                min_x, min_y, max_x, max_y, c0[0], c0[1], c0[2], c0[3], pixels_this_tri);
    }
}

/* ============================================================================
 * Java Object <-> Native Object Mapping
 * ============================================================================ */

/* Alternating temp buffers for get_native_transform - handles the common
 * case of needing two transforms simultaneously (e.g. postMultiply). */
static M3GTransform g_transform_temp_a, g_transform_temp_b;
static int g_transform_temp_idx = 0;

/* Copy native transform data from Java Transform object into caller-provided storage */
static void get_native_transform_into(JavaObject* obj, M3GTransform* out) {
    if (!obj || !out) return;
    
    memset(out, 0, sizeof(M3GTransform));
    
    /* Ensure object has fields */
    if (!OBJECT_HAS_FIELDS(obj, 1)) return;
    
    /* Transform stores 16 floats in a float[] field */
    JavaArray* arr = (JavaArray*)obj->fields[0].ref;
    if (!arr) return;
    if (arr->element_type != T_FLOAT || arr->length < 16) return;
    
    float* data = (float*)array_data(arr);
    memcpy(out->m, data, 16 * sizeof(float));
}

/* Get native transform from Java Transform object.
 * Returns a pointer to an internal temp buffer that alternates between two slots.
 * Only safe for up to 2 simultaneous transforms; callers needing more should
 * use get_native_transform_into() directly. */
static M3GTransform* get_native_transform(JavaObject* obj) {
    if (!obj) return NULL;
    
    M3GTransform* out = (g_transform_temp_idx++ & 1) ? &g_transform_temp_b : &g_transform_temp_a;
    g_transform_temp_idx &= 1;  /* keep it cycling 0,1,0,1,... */
    get_native_transform_into(obj, out);
    return out;
}

/* Set native transform to Java Transform object */
static void set_native_transform(JavaObject* obj, M3GTransform* t) {
    if (!obj || !t) return;
    
    /* Ensure object has fields */
    if (!OBJECT_HAS_FIELDS(obj, 1)) return;
    
    JavaArray* arr = (JavaArray*)obj->fields[0].ref;
    
    /* If no array exists, we cannot set - caller should ensure array exists */
    if (!arr) return;
    
    if (arr->element_type != T_FLOAT || arr->length < 16) return;
    
    float* data = (float*)array_data(arr);
    memcpy(data, t->m, 16 * sizeof(float));
}

/* Get VertexArray data */
__attribute__((unused)) static M3GVertexArray* get_vertex_array(JavaObject* obj, M3GVertexArray* temp) {
    if (!obj || !temp) return NULL;
    
    memset(temp, 0, sizeof(M3GVertexArray));
    
    /* VertexArray fields: data (byte[]/short[]), componentCount, componentSize, count */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    int component_count = m3g_get_int_field(obj, "componentCount", 3);
    int component_size = m3g_get_int_field(obj, "componentSize", 1);
    int vertex_count = m3g_get_int_field(obj, "vertexCount", 0);
    
    if (!data || vertex_count <= 0) return NULL;
    
    /* Sanity checks to prevent OOM */
    if (vertex_count > M3G_MAX_VERTEX_COUNT) {
        GFX_DEBUG("get_vertex_array: vertex_count %d exceeds max %d", vertex_count, M3G_MAX_VERTEX_COUNT);
        return NULL;
    }
    if (component_count > 4 || component_count < 2) {
        GFX_DEBUG("get_vertex_array: invalid component_count %d", component_count);
        return NULL;
    }
    
    /* Convert to float positions */
    temp->positions = (float*)malloc(vertex_count * 3 * sizeof(float));
    if (!temp->positions) return NULL;
    
    temp->vertex_count = vertex_count;
    temp->vertex_stride = component_count;
    
    if (component_size == 1) {
        int8_t* src = (int8_t*)array_data(data);
        for (int i = 0; i < vertex_count * component_count; i++) {
            temp->positions[i] = (float)src[i];
        }
    } else {
        int16_t* src = (int16_t*)array_data(data);
        for (int i = 0; i < vertex_count * component_count; i++) {
            temp->positions[i] = (float)src[i];
        }
    }
    
    return temp;
}

/* ============================================================================
 * Native Method Implementations
 * ============================================================================ */

/* Graphics3D.getInstance() */
/* v15: fetch a registry object only if it is still a live GC object.
 * The registry keeps raw JavaObject* pointers invisible to the GC; after a
 * collection they may dangle (freed + coalesced into a free block). */
static JavaObject* m3g_registry_get(int i) {
    if (i < 0 || i >= g_m3g_registry.count) return NULL;
    JavaObject* obj = g_m3g_registry.objects[i];
    if (!obj) return NULL;
    if (!heap_java_object_valid(obj)) {
        g_m3g_registry.objects[i] = NULL;
        g_m3g_registry.userIDs[i] = 0;
        return NULL;
    }
    return obj;
}

static JavaValue native_graphics3d_getInstance(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    (void)jvm;
    
    /* Find Graphics3D class */
    JavaClass* g3d_class = jvm_load_class(jvm, "javax/microedition/m3g/Graphics3D");
    if (!g3d_class) {
        GFX_DEBUG("Graphics3D class not found");
        return NATIVE_RETURN_NULL();
    }
    
    /* Check for static instance field */
    for (int i = 0; i < g3d_class->static_fields_count; i++) {
        if (strcmp(g3d_class->static_fields[i].name, "instance") == 0) {
            if (g3d_class->static_fields[i].value.ref) {
                return NATIVE_RETURN_OBJECT(g3d_class->static_fields[i].value.ref);
            }
            break;
        }
    }
    
    /* Create new instance */
    JavaObject* instance = jvm_new_object(jvm, g3d_class);
    if (!instance) {
        GFX_DEBUG("Failed to create Graphics3D instance");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store as static field */
    for (int i = 0; i < g3d_class->static_fields_count; i++) {
        if (strcmp(g3d_class->static_fields[i].name, "instance") == 0) {
            g3d_class->static_fields[i].value.ref = instance;
            break;
        }
    }
    
    fprintf(stderr, "[M3G] Graphics3D.getInstance() -> %p\n", (void*)instance);
    return NATIVE_RETURN_OBJECT(instance);
}

/* Graphics3D.bindTarget(Image2D) - 1-arg form */
/* Graphics3D.bindTarget(Object target, boolean depthBuffering, int hints) - 3-arg form used by games */
static JavaValue native_graphics3d_bindTarget_3arg(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)thread; (void)arg_count;
    (void)jvm;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* target = (JavaObject*)args[1].ref;
    /* args[2] = depthBuffering hint (boolean), args[3] = hints */
    (void)g3d;
    
    g_m3g_bindtarget_called = true;  /* Track that bindTarget was called */
    g_m3g_pending_render_count = 0; /* Clear pending renders - game took over */
    m3g_thread_fence();
    
    g_m3g.target_image = NULL;
    g_m3g_target_bound_flag = 0;
    g_m3g.target_gfx = NULL;
    g_m3g.target_is_graphics = 0;
    
    fprintf(stderr, "[M3G] bindTarget_3arg: target=%p (class=%s)\n", (void*)target,
            target && target->header.clazz && target->header.clazz->class_name ? target->header.clazz->class_name : "?");
    
    if (!target) {
        /* v10: spec returns the bound target (null here) */
        return NATIVE_RETURN_NULL();
    }
    
    /* Determine if target is Image2D or Graphics by checking class name */
    JavaClass* target_class = target->header.clazz;
    const char* target_class_name = target_class ? target_class->class_name : NULL;
    int is_image2d = (target_class_name && strstr(target_class_name, "Image2D") != NULL);
    int is_graphics = (target_class_name && strstr(target_class_name, "Graphics") != NULL);
    
    int width = 0, height = 0;
    
    if (is_image2d) {
        /* Image2D target - read dimensions from its fields */
        width = m3g_get_int_field(target, "width", 0);
        height = m3g_get_int_field(target, "height", 0);
        g_m3g.target_is_graphics = 0;
        g_m3g.target_image = target;
        g_m3g_target_bound_flag = 1;
    } else if (is_graphics) {
        /* Graphics target - get dimensions from the native MidpGraphics context */
        g_m3g.target_is_graphics = 1;
        g_m3g.target_image = target;
        g_m3g_target_bound_flag = 1;
        
        extern MidpGraphics* get_graphics_from_object(JavaObject* obj);
        MidpGraphics* gfx = get_graphics_from_object(target);
        if (gfx && gfx->pixels) {
            g_m3g.target_gfx = gfx;
            width = gfx->width;
            height = gfx->height;
            fprintf(stderr, "[M3G] bindTarget(3arg): Graphics target, MidpGraphics=%p, %dx%d\n",
                    (void*)gfx, width, height);
        } else {
            /* Fallback: try to get from the screen context */
            SdlContext* sdl = sdl_get_global_context();
            if (sdl && sdl->width > 0 && sdl->height > 0) {
                width = sdl->width;
                height = sdl->height;
            }
            fprintf(stderr, "[M3G] bindTarget(3arg): Graphics target, no MidpGraphics, using screen %dx%d\n",
                    width, height);
        }
    } else {
        /* Unknown target type - try as Image2D */
        width = m3g_get_int_field(target, "width", 0);
        height = m3g_get_int_field(target, "height", 0);
        g_m3g.target_is_graphics = 0;
        g_m3g.target_image = target;
        g_m3g_target_bound_flag = 1;
    }
    
    /* Fallback dimensions */
    if (width <= 0 || height <= 0) {
        width = m3g_get_int_field(target, "width", 0);
        height = m3g_get_int_field(target, "height", 0);
    }
    if (width <= 0 || height <= 0) {
        width = m3g_get_int_field(target, "viewportWidth", 240);
        height = m3g_get_int_field(target, "viewportHeight", 320);
    }
    if (width <= 0) width = 240;
    if (height <= 0) height = 320;
    if (width > M3G_MAX_IMAGE_DIMENSION) width = M3G_MAX_IMAGE_DIMENSION;
    if (height > M3G_MAX_IMAGE_DIMENSION) height = M3G_MAX_IMAGE_DIMENSION;
    
    int pixel_count = width * height;
    if (pixel_count <= 0 || pixel_count > M3G_MAX_IMAGE_PIXELS) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Save target info before context_init (which zeros g_m3g) */
    JavaObject* saved_target = g_m3g.target_image;
    MidpGraphics* saved_gfx = g_m3g.target_gfx;
    int saved_is_graphics = g_m3g.target_is_graphics;
    
    m3g_context_init(width, height);
    
    /* Restore target info after context_init */
    g_m3g.target_image = saved_target;
    g_m3g_target_bound_flag = 1;
    g_m3g.target_gfx = saved_gfx;
    g_m3g.target_is_graphics = saved_is_graphics;

    /* v25: start the 3D buffer from the canvas content (2D bg survives) */
    m3g_seed_color_buffer_from_gfx();

    EXEC_DEBUG("[M3G] bindTarget(3arg): %dx%d, buffers=%d", width, height, g_m3g.buffers_allocated);
    /* v10 FIX: JSR-184 bindTarget returns the bound target object. Returning
     * it is harmless for void-descriptor call sites (result discarded) and
     * REQUIRED for the spec descriptors (...)Ljava/lang/Object;. */
    return NATIVE_RETURN_OBJECT(target);
}

static JavaValue native_graphics3d_bindTarget(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* target = (JavaObject*)args[1].ref;
    
    (void)g3d;  /* Instance not used in this simple impl */
    
    g_m3g_bindtarget_called = true;  /* Track that bindTarget was called */
    g_m3g_pending_render_count = 0; /* Clear pending renders - game took over */
    m3g_thread_fence();
    
    if (!target) {
        GFX_DEBUG("bindTarget: null target");
        g_m3g.target_image = NULL;
        g_m3g_target_bound_flag = 0;
        return NATIVE_RETURN_VOID();
    }
    
    /* Get image dimensions from target */
    int width = m3g_get_int_field(target, "width", 240);
    int height = m3g_get_int_field(target, "height", 320);
    
    /* Sanity check: prevent OOM from unreasonable dimensions */
    if (width <= 0 || height <= 0) {
        GFX_DEBUG("bindTarget: Invalid dimensions %dx%d, using defaults", width, height);
        width = 240;
        height = 320;
    }
    if (width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        GFX_DEBUG("bindTarget: Dimensions too large %dx%d, clamping to %d", 
                width, height, M3G_MAX_IMAGE_DIMENSION);
        if (width > M3G_MAX_IMAGE_DIMENSION) width = M3G_MAX_IMAGE_DIMENSION;
        if (height > M3G_MAX_IMAGE_DIMENSION) height = M3G_MAX_IMAGE_DIMENSION;
    }
    
    /* Check for integer overflow */
    int pixel_count = width * height;
    if (pixel_count <= 0 || pixel_count > M3G_MAX_IMAGE_PIXELS) {
        GFX_DEBUG("bindTarget: Pixel count overflow or invalid: %d", pixel_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize or reinitialize context (m3g_context_init internally calls
     * m3g_context_free_buffers to release old buffers before allocating new ones) */
    m3g_context_init(width, height);
    
    /* Save target image for releaseTarget */
    g_m3g.target_image = target;
    g_m3g_target_bound_flag = 1;
    
    fprintf(stderr, "[M3G] bindTarget: %dx%d, image=%p, buffers=%d\n", width, height, (void*)target, g_m3g.buffers_allocated);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.releaseTarget() */
static JavaValue native_graphics3d_releaseTarget(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    EXEC_DEBUG("[M3G] releaseTarget: triangles=%d, target=%p, is_graphics=%d",
            g_m3g.triangles_rendered, (void*)g_m3g.target_image, g_m3g.target_is_graphics);
    
    if (!g_m3g.target_image || !g_m3g.color_buffer) {
        g_m3g.target_image = NULL;
        g_m3g_target_bound_flag = 0;
        g_m3g.target_gfx = NULL;
        g_m3g.target_is_graphics = 0;
        return NATIVE_RETURN_VOID();
    }
    
    if (g_m3g.target_is_graphics && g_m3g.target_gfx) {
        /* Target is a Graphics object - blit rendered pixels to the Graphics pixel buffer.
         * This is the common case for games: g3d.bindTarget(getGraphics(), true, 0); */
        MidpGraphics* gfx = g_m3g.target_gfx;
        int copy_w = g_m3g.buffer_width < gfx->width ? g_m3g.buffer_width : gfx->width;
        int copy_h = g_m3g.buffer_height < gfx->height ? g_m3g.buffer_height : gfx->height;
        
        /* v14 DIAG: rasterized-pixel count for THIS bind/release cycle */
        {
            static int rt_diag = 0;
            rt_diag++;
            if (rt_diag <= 6 || (rt_diag % 60) == 0) {
                fprintf(stderr, "[M3G-RT] pass=%d tris=%d pix=%d gfx=%p buf0=%08X\n",
                        rt_diag, g_m3g.triangles_rendered, g_m3g_raster_pixels_written,
                        (void*)gfx, g_m3g.color_buffer ? g_m3g.color_buffer[0] : 0);
            }
        }
        for (int y = 0; y < copy_h; y++) {
            for (int x = 0; x < copy_w; x++) {
                int src_idx = y * g_m3g.buffer_width + x;
                int dst_idx = y * gfx->width + x;
                gfx->pixels[dst_idx] = g_m3g.color_buffer[src_idx];
            }
        }
        EXEC_DEBUG("[M3G] releaseTarget: copied %dx%d pixels to Graphics buffer", copy_w, copy_h);
        
        /* Frame capture from releaseTarget path (bindTarget→render→releaseTarget) */
        {
            static int rt_capture_count = 0;
            static int rt_capture_limit = -1;
            rt_capture_count++;
            
            if (rt_capture_limit < 0) {
                const char* env_cap = getenv("M3G_CAPTURE");
                if (env_cap) {
                    if (strcmp(env_cap, "every") == 0) rt_capture_limit = 999999;
                    else rt_capture_limit = atoi(env_cap);
                } else {
                    /* FIX(default-off): unconditional per-frame BMP dumping to
                     * download/ flooded the user's delivery folder and added
                     * heavy fopen/fwrite traffic inside the render path.
                     * Enable explicitly with M3G_CAPTURE=<n|every>. */
                    rt_capture_limit = 0;
                }
            }
            
            int should_capture = 0;
            if (rt_capture_limit == 999999) {
                should_capture = (rt_capture_count % 100 == 0);
            } else if (rt_capture_limit > 0) {
                should_capture = (rt_capture_count <= rt_capture_limit);
            }
            
            if (should_capture && gfx->pixels) {
                char fname[256];
                snprintf(fname, sizeof(fname), "/home/z/my-project/download/m3g_rt_%05d.bmp", rt_capture_count);
                int w = gfx->width;
                int h = gfx->height;
                int row_size = (w * 3 + 3) & ~3;
                int pixel_data_size = row_size * h;
                int file_size = 54 + pixel_data_size;
                
                FILE* f = fopen(fname, "wb");
                if (f) {
                    uint8_t hdr[14] = {'B','M'};
                    hdr[2] = file_size & 0xFF; hdr[3] = (file_size>>8) & 0xFF;
                    hdr[4] = (file_size>>16) & 0xFF; hdr[5] = (file_size>>24) & 0xFF;
                    hdr[10] = 54;
                    fwrite(hdr, 1, 14, f);
                    
                    uint8_t dib[40] = {0};
                    dib[0] = 40;
                    dib[4] = w & 0xFF; dib[5] = (w>>8) & 0xFF; dib[6] = (w>>16) & 0xFF; dib[7] = (w>>24) & 0xFF;
                    dib[8] = h & 0xFF; dib[9] = (h>>8) & 0xFF; dib[10] = (h>>16) & 0xFF; dib[11] = (h>>24) & 0xFF;
                    dib[12] = 1;
                    dib[14] = 24;
                    dib[20] = pixel_data_size & 0xFF; dib[21] = (pixel_data_size>>8) & 0xFF;
                    dib[22] = (pixel_data_size>>16) & 0xFF; dib[23] = (pixel_data_size>>24) & 0xFF;
                    fwrite(dib, 1, 40, f);
                    
                    uint8_t* row_buf = (uint8_t*)calloc(row_size, 1);
                    if (row_buf) {
                        for (int cy = h - 1; cy >= 0; cy--) {
                            memset(row_buf, 0, row_size);
                            for (int cx = 0; cx < w; cx++) {
                                uint32_t p = gfx->pixels[cy * w + cx];
                                row_buf[cx * 3 + 0] = p & 0xFF;
                                row_buf[cx * 3 + 1] = (p >> 8) & 0xFF;
                                row_buf[cx * 3 + 2] = (p >> 16) & 0xFF;
                            }
                            fwrite(row_buf, 1, row_size, f);
                        }
                        free(row_buf);
                    }
                    fclose(f);
                    fprintf(stderr, "[M3G-CAP] releaseTarget frame #%d saved to %s (%dx%d, tris=%d)\n", 
                            rt_capture_count, fname, w, h, g_m3g.triangles_rendered);
                }
            }
        }
    } else {
        /* Target is an Image2D object - copy pixels to its pixel array */
        JavaObject* image2d = g_m3g.target_image;
        JavaArray* pixels = (JavaArray*)m3g_get_ref_field(image2d, "pixels");
        
        if (pixels && pixels->element_type == T_INT) {
            int width = m3g_get_int_field(image2d, "width", g_m3g.buffer_width);
            int height = m3g_get_int_field(image2d, "height", g_m3g.buffer_height);
            int pixel_count = width * height;
            
            jint* dst = (jint*)array_data(pixels);
            if (dst && pixel_count > 0) {
                int copy_count = pixel_count < (g_m3g.buffer_width * g_m3g.buffer_height) 
                               ? pixel_count 
                               : g_m3g.buffer_width * g_m3g.buffer_height;
                
                for (int i = 0; i < copy_count; i++) {
                    dst[i] = (jint)g_m3g.color_buffer[i];
                }
                /* v14: the Image2D content just changed (render-into-Image2D
                 * target, Nescube renders the NES screen this way) — refresh
                 * any cached textures built from it. */
                m3g_mark_image2d_updated(image2d);
                fprintf(stderr, "[M3G] releaseTarget: copied %d pixels to Image2D\n", copy_count);
            }
        }
    }
    
    g_m3g.target_image = NULL;
    g_m3g_target_bound_flag = 0;
    g_m3g.target_gfx = NULL;
    g_m3g.target_is_graphics = 0;
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.clear(Background) */
static JavaValue native_graphics3d_clear(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* background = (JavaObject*)args[1].ref;
    
    float r = 0.0f, g = 0.0f, b = 0.0f, a = 0.0f;
    float depth = 1.0f;
    int clear_color = 1, clear_depth = 1;
    
    if (background) {
        /* Background has clearColor field (int ARGB) */
        int argb = m3g_get_int_field(background, "clearColor", 0);
        a = ((argb >> 24) & 0xFF) / 255.0f;
        r = ((argb >> 16) & 0xFF) / 255.0f;
        g = ((argb >> 8) & 0xFF) / 255.0f;
        b = (argb & 0xFF) / 255.0f;
        /* v20: honor the enable flags (JSR-184 §Background) */
        clear_color = m3g_get_int_field(background, "colorClearEnable", 1) != 0;
        clear_depth = m3g_get_int_field(background, "depthClearEnable", 1) != 0;
    } else {
        /* JSR-184 §Graphics3D.clear: null Background clears the color buffer
         * to FULLY TRANSPARENT black, depth to 1.0. */
        a = 0.0f; r = 0.0f; g = 0.0f; b = 0.0f;
    }
    
    m3g_clear_ex(r, g, b, a, depth, clear_color, clear_depth);
    
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setViewport(int x, int y, int width, int height) */
static JavaValue native_graphics3d_setViewport(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    (void)g3d;
    
    g_m3g.viewport_x = args[1].i;
    g_m3g.viewport_y = args[2].i;
    g_m3g.viewport_width = args[3].i;
    g_m3g.viewport_height = args[4].i;
    
    /* FIX-19y: unconditional throttled log - a wrong viewport shrinks the
     * whole 3D scene into a corner (SU-30 sound screen rendered ~60x60
     * fragment at the right side instead of fullscreen). */
    {
        static int vp_log_count = 0;
        if (vp_log_count < 25) {
            vp_log_count++;
            fprintf(stderr, "[M3G-VP] setViewport(%d,%d %dx%d)\n",
                    g_m3g.viewport_x, g_m3g.viewport_y,
                    g_m3g.viewport_width, g_m3g.viewport_height);
        }
    }
    
    GFX_DEBUG("setViewport: %d,%d %dx%d", 
            g_m3g.viewport_x, g_m3g.viewport_y, 
            g_m3g.viewport_width, g_m3g.viewport_height);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.setIdentity() */
/* Transform.<init>() - default constructor, creates identity matrix */
static JavaValue native_transform_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    GFX_DEBUG("Transform.<init>() called, obj=%p", (void*)obj);
    
    if (!obj) {
        GFX_DEBUG("Transform.<init>: NULL object!");
        return NATIVE_RETURN_VOID();
    }
    
    /* Verify the object has fields */
    JavaClass* clazz = obj->header.clazz;
    if (!clazz) {
        GFX_DEBUG("Transform.<init>: NULL class!");
        return NATIVE_RETURN_VOID();
    }
    
    int max_slots = (clazz->instance_size - (int)sizeof(ObjectHeader)) / (int)sizeof(JavaValue);
    GFX_DEBUG("Transform.<init>: clazz=%s, instance_size=%d, max_slots=%d, fields_count=%d",
              clazz->class_name ? clazz->class_name : "?", 
              (int)clazz->instance_size, max_slots, clazz->fields_count);
    
    if (max_slots < 1) {
        GFX_DEBUG("Transform.<init>: ERROR - no space for matrix field! instance_size=%d", (int)clazz->instance_size);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create float[16] array for the matrix */
    JavaArray* arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
    if (!arr) {
        GFX_DEBUG("Transform.<init>: failed to create float array");
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize to identity matrix */
    float* data = (float*)array_data(arr);
    memset(data, 0, 16 * sizeof(float));
    data[0] = 1.0f;   /* m[0][0] */
    data[5] = 1.0f;   /* m[1][1] */
    data[10] = 1.0f;  /* m[2][2] */
    data[15] = 1.0f;  /* m[3][3] */
    
    /* Store in Transform's first field */
    obj->fields[0].ref = arr;
    
    GFX_DEBUG("Transform.<init>(): created identity transform, arr=%p", (void*)arr);
    return NATIVE_RETURN_VOID();
}

/* Transform.<init>(Transform) - copy constructor */
static JavaValue native_transform_init_copy(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* other = (JavaObject*)args[1].ref;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Create float[16] array for the matrix */
    JavaArray* arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
    if (!arr) {
        GFX_DEBUG("Transform.<init>(Transform): failed to create float array");
        return NATIVE_RETURN_VOID();
    }
    
    float* data = (float*)array_data(arr);
    
    if (other && OBJECT_HAS_FIELDS(other, 1)) {
        /* Copy from other transform */
        JavaArray* other_arr = (JavaArray*)other->fields[0].ref;
        if (other_arr && other_arr->element_type == T_FLOAT && other_arr->length >= 16) {
            float* other_data = (float*)array_data(other_arr);
            memcpy(data, other_data, 16 * sizeof(float));
            GFX_DEBUG("Transform.<init>(Transform): copied transform");
        } else {
            /* Other transform has invalid data, use identity */
            memset(data, 0, 16 * sizeof(float));
            data[0] = 1.0f;
            data[5] = 1.0f;
            data[10] = 1.0f;
            data[15] = 1.0f;
            GFX_DEBUG("Transform.<init>(Transform): other has invalid data, using identity");
        }
    } else {
        /* Other is null, use identity */
        memset(data, 0, 16 * sizeof(float));
        data[0] = 1.0f;
        data[5] = 1.0f;
        data[10] = 1.0f;
        data[15] = 1.0f;
        GFX_DEBUG("Transform.<init>(Transform): other is null, using identity");
    }
    
    /* Store in Transform's first field */
    obj->fields[0].ref = arr;
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_transform_setIdentity(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    M3GTransform t;
    m3g_transform_identity(&t);
    set_native_transform(obj, &t);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postMultiply(Transform) */
static JavaValue native_transform_postMultiply(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* other_obj = (JavaObject*)args[1].ref;
    
    M3GTransform this_t, other_t;
    get_native_transform_into(this_obj, &this_t);
    get_native_transform_into(other_obj, &other_t);
    
    /* Check if either transform is all-zero (indicating invalid/null) */
    int this_valid = 0, other_valid = 0;
    for (int i = 0; i < 16; i++) {
        if (this_t.m[i] != 0.0f) this_valid = 1;
        if (other_t.m[i] != 0.0f) other_valid = 1;
    }
    if (!this_valid || !other_valid) {
        return NATIVE_RETURN_VOID();
    }
    
    M3GTransform result;
    m3g_transform_multiply(&result, &this_t, &other_t);
    set_native_transform(this_obj, &result);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postTranslate(float x, float y, float z) */
static JavaValue native_transform_postTranslate(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_translate(&temp, x, y, z);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postRotate(float angle, float ax, float ay, float az) */
static JavaValue native_transform_postRotate(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float angle = args[1].f * 3.14159f / 180.0f;  /* Degrees to radians */
    float ax = args[2].f;
    float ay = args[3].f;
    float az = args[4].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_rotate(&temp, angle, ax, ay, az);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postScale(float sx, float sy, float sz) */
static JavaValue native_transform_postScale(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float sx = args[1].f;
    float sy = args[2].f;
    float sz = args[3].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_scale(&temp, sx, sy, sz);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* v23: Transform.transpose() */
static JavaValue native_transform_transpose(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;

    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                temp.m[c * 4 + r] = t->m[r * 4 + c];
            }
        }
        set_native_transform(obj, &temp);
    }

    return NATIVE_RETURN_VOID();
}

/* v23: Transform.postRotateQuat(float qx, qy, qz, qw) — right-multiply by
 * the rotation matrix built from a unit quaternion. */
static JavaValue native_transform_postRotateQuat(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float qx = args[1].f;
    float qy = args[2].f;
    float qz = args[3].f;
    float qw = args[4].f;

    M3GTransform* t = get_native_transform(obj);
    if (t) {
        /* Quaternion to 3x3 rotation matrix (standard formula) */
        M3GTransform q;
        memset(&q, 0, sizeof(q));
        q.m[0 * 4 + 0] = 1.0f - 2.0f * (qy * qy + qz * qz);
        q.m[0 * 4 + 1] = 2.0f * (qx * qy + qz * qw);
        q.m[0 * 4 + 2] = 2.0f * (qx * qz - qy * qw);
        q.m[1 * 4 + 0] = 2.0f * (qx * qy - qz * qw);
        q.m[1 * 4 + 1] = 1.0f - 2.0f * (qx * qx + qz * qz);
        q.m[1 * 4 + 2] = 2.0f * (qy * qz + qx * qw);
        q.m[2 * 4 + 0] = 2.0f * (qx * qz + qy * qw);
        q.m[2 * 4 + 1] = 2.0f * (qy * qz - qx * qw);
        q.m[2 * 4 + 2] = 1.0f - 2.0f * (qx * qx + qy * qy);
        q.m[3 * 4 + 3] = 1.0f;

        M3GTransform temp;
        m3g_transform_multiply(&temp, t, &q);
        set_native_transform(obj, &temp);
    }

    return NATIVE_RETURN_VOID();
}

/* v23: Transform.postSkew(float fx, fy, fz, qx, qy, qz).
 * Matches the de-facto reference implementation (m3g_loader/FreeJ2ME): the
 * skew matrix is the affine shear |I  f; 0  1| with the factors in the
 * fourth column; the quaternion part carries no additional factors there. */
static JavaValue native_transform_postSkew(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float fx = args[1].f;
    float fy = args[2].f;
    float fz = args[3].f;

    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform s;
        memset(&s, 0, sizeof(s));
        s.m[0 * 4 + 0] = 1.0f;
        s.m[1 * 4 + 1] = 1.0f;
        s.m[2 * 4 + 2] = 1.0f;
        s.m[3 * 4 + 3] = 1.0f;
        s.m[0 * 4 + 3] = fx;
        s.m[1 * 4 + 3] = fy;
        s.m[2 * 4 + 3] = fz;

        M3GTransform temp;
        m3g_transform_multiply(&temp, t, &s);
        set_native_transform(obj, &temp);
    }

    return NATIVE_RETURN_VOID();
}

/* v23: Transform.set(float[] m) / get(float[] m) — direct 16-float access.
 * JSR-184 stores the matrix in column-major order: m[1 + 4*r] etc. */
static JavaValue native_transform_setArray(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* arr = (JavaArray*)args[1].ref;

    if (obj && arr && arr->element_type == T_FLOAT && arr->length >= 16) {
        M3GTransform t;
        float* m = (float*)array_data(arr);
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                t.m[c * 4 + r] = m[c * 4 + r];
            }
        }
        set_native_transform(obj, &t);
    }

    return NATIVE_RETURN_VOID();
}

static JavaValue native_transform_getArray(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* arr = (JavaArray*)args[1].ref;

    if (obj && arr && arr->element_type == T_FLOAT && arr->length >= 16) {
        M3GTransform* t = get_native_transform(obj);
        if (t) {
            float* m = (float*)array_data(arr);
            for (int c = 0; c < 4; c++) {
                for (int r = 0; r < 4; r++) {
                    m[c * 4 + r] = t->m[c * 4 + r];
                }
            }
        }
    }

    return NATIVE_RETURN_VOID();
}

/* VertexArray.<init>(int numVertices, int numComponents, int componentSize) */
static JavaValue native_vertexarray_init(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint num_vertices = args[1].i;
    jint num_components = args[2].i;
    jint component_size = args[3].i;
    
    if (!obj || num_vertices <= 0 || num_components < 2 || num_components > 4) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Register in M3G registry */
    m3g_registry_register(obj, 0);
    
    /* Sanity check: limit vertex count to prevent OOM */
    if (num_vertices > M3G_MAX_VERTEX_COUNT) {
        GFX_DEBUG("VertexArray: num_vertices %d exceeds max %d", num_vertices, M3G_MAX_VERTEX_COUNT);
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for integer overflow in data_size calculation */
    int data_size = num_vertices * num_components * component_size;
    if (data_size <= 0 || data_size > M3G_MAX_VERTEX_COUNT * 4 * 2) {
        GFX_DEBUG("VertexArray: data_size overflow or invalid: %d", data_size);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create data array */
    JavaArray* data = jvm_new_array(jvm, component_size == 1 ? T_BYTE : T_SHORT, data_size, NULL);
    if (!data) {
        GFX_DEBUG("VertexArray: failed to allocate data array");
        return NATIVE_RETURN_VOID();
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "data", (JavaObject*)data);
    m3g_set_int_field(obj, "componentCount", num_components);
    m3g_set_int_field(obj, "componentSize", component_size);
    m3g_set_int_field(obj, "vertexCount", num_vertices);
    
    GFX_DEBUG("VertexArray.init: %d vertices, %d components, %d bytes",
            num_vertices, num_components, component_size);
    
    return NATIVE_RETURN_VOID();
}

/* Camera.setPerspective(float fov, float aspectRatio, float near, float far) */
static JavaValue native_camera_setPerspective(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float fov = args[1].f;
    float aspect = args[2].f;
    float near = args[3].f;
    float far = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store parameters on the camera object for force-render path.
     * v24 FIX: also persist projectionType (JSR-184: PERSPECTIVE=2) so
     * Camera.getProjection(Transform)/([F)I return the real type — the stub
     * field zero-initializes to GENERIC(0) and the old code returned an
     * identity/empty projection for perspective cameras. */
    m3g_set_int_field(obj, "projectionType", 2);
    m3g_set_float_field(obj, "fov", fov);
    m3g_set_float_field(obj, "aspect", aspect);
    m3g_set_float_field(obj, "near", near);
    m3g_set_float_field(obj, "far", far);
    
    /* Update projection matrix */
    m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
    
    /* v25 FIX (Brick Breaker / SU-30 wrong projection scale): cache the EXACT
     * matrix that was just built in the camera's genericMatrix slot.
     * Graphics3D.setCamera previously REBUILT the projection from the raw
     * fields every frame — and the PARALLEL rebuild read the 'fov' field
     * (degrees!) as the world-space ortho height instead of the 'height'
     * field (world units). A camera that ever called setPerspective and then
     * switched to setParallel (Brick Breaker's map pass: setParallel(h,1,0,f))
     * rendered with h=75° as if the world were 75 units tall — everything
     * several times too big (NDC ±2.7, off-screen walls, "back faces look
     * bigger than front faces" in every such game). With the cache, setCamera
     * just uses the real matrix — no field-rebuild drift is possible. */
    {
        JavaArray* cache = (JavaArray*)m3g_get_ref_field(obj, "genericMatrix");
        if (!cache || cache->length < 16 || cache->element_type != T_FLOAT) {
            cache = jvm_new_array(jvm, T_FLOAT, 16, NULL);
            if (cache) m3g_set_ref_field(obj, "genericMatrix", (JavaObject*)cache);
        }
        if (cache && cache->element_type == T_FLOAT && cache->length >= 16) {
            memcpy(array_data(cache), g_m3g.projection.m, 16 * sizeof(float));
        }
    }
    
    GFX_DEBUG("Camera.setPerspective: fov=%.1f, aspect=%.2f, near=%.2f, far=%.2f",
            fov, aspect, near, far);
    
    return NATIVE_RETURN_VOID();
}

/* Camera.setParallel(float height, float aspectRatio, float near, float far) */
static JavaValue native_camera_setParallel(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float height = args[1].f;
    float aspect = args[2].f;
    float near = args[3].f;
    float far = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    float half_h = height / 2.0f;
    float half_w = half_h * aspect;
    
    /* v24 FIX: persist parameters + projectionType (JSR-184: PARALLEL=1).
     * getProjection needs 'height', which was never stored before. */
    m3g_set_int_field(obj, "projectionType", 1);
    m3g_set_float_field(obj, "height", height);
    m3g_set_float_field(obj, "aspect", aspect);
    m3g_set_float_field(obj, "near", near);
    m3g_set_float_field(obj, "far", far);
    
    m3g_transform_ortho(&g_m3g.projection, -half_w, half_w, -half_h, half_h, near, far);
    
    /* v25: cache the exact ortho matrix too — see setPerspective comment.
     * JSR-184 semantic: height/aspect/near/far describe the projection ONCE;
     * setCamera must not re-derive it (the old rebuild used the fov field as
     * the ortho height -> several-times-too-big world / off-screen walls). */
    {
        JavaArray* cache = (JavaArray*)m3g_get_ref_field(obj, "genericMatrix");
        if (!cache || cache->length < 16 || cache->element_type != T_FLOAT) {
            cache = jvm_new_array(jvm, T_FLOAT, 16, NULL);
            if (cache) m3g_set_ref_field(obj, "genericMatrix", (JavaObject*)cache);
        }
        if (cache && cache->element_type == T_FLOAT && cache->length >= 16) {
            memcpy(array_data(cache), g_m3g.projection.m, 16 * sizeof(float));
        }
    }
    
    GFX_DEBUG("Camera.setParallel: height=%.1f, aspect=%.2f", height, aspect);
    
    return NATIVE_RETURN_VOID();
}

/* Find light index for a given Light Java object, or -1 if not found */
static int find_light_for_object(JavaObject* light_obj) {
    for (int i = 0; i < g_m3g.light_count; i++) {
        if (g_m3g.lights[i].obj == light_obj) return i;
    }
    return -1;
}

/* Light.setType(int type) */
static JavaValue native_light_setType(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint type = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Check if this object already has a light slot */
    int light_idx = find_light_for_object(obj);
    
    if (light_idx < 0) {
        /* Add new light slot */
        if (g_m3g.light_count < 8) {
            light_idx = g_m3g.light_count++;
            memset(&g_m3g.lights[light_idx], 0, sizeof(M3GLight));
            g_m3g.lights[light_idx].obj = obj;
            g_m3g.lights[light_idx].attenuation[0] = 1.0f;  /* constant */
            g_m3g.lights[light_idx].color[3] = 1.0f;       /* default alpha */
        } else {
            GFX_DEBUG("Light.setType: max lights reached (8)");
            return NATIVE_RETURN_VOID();
        }
    }
    
    /* Task 16-a: store the internal type (mode may be file-encoded 128..131
     * or the stub API block 0..3) and keep the raw mode on the object so the
     * scene-traversal light collector sees the same type for lights parented
     * into the scene graph. */
    g_m3g.lights[light_idx].type = m3g_light_mode_to_type(type);
    m3g_set_int_field(obj, "mode", type);
    m3g_set_int_field(obj, "lightType", type);
    
    GFX_DEBUG("Light.setType: %d (idx=%d)", type, light_idx);
    
    return NATIVE_RETURN_VOID();
}

/* World.addCamera(Camera) */
static JavaValue native_world_addCamera(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* camera = (JavaObject*)args[1].ref;
    (void)world; (void)camera;
    
    GFX_DEBUG("World.addCamera");
    return NATIVE_RETURN_VOID();
}

/* World.setBackground(Background) */
static JavaValue native_world_setBackground(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* background = (JavaObject*)args[1].ref;
    
    if (world && background) {
        m3g_set_ref_field(world, "background", background);
    }
    
    GFX_DEBUG("World.setBackground");
    return NATIVE_RETURN_VOID();
}

/* World.render(World) - Render a 3D scene */
static JavaValue native_graphics3d_renderWorld(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* world = (JavaObject*)args[1].ref;
    (void)g3d;
    
    LOG_SAFE( "[M3G] renderWorld: world=%p\n", (void*)world);
    
    g_m3g_render_done = true;  /* Track that render was called this frame */
    m3g_thread_fence();
    
    /* NOTE: Do NOT reset triangles_rendered here - the game may have already
     * rendered triangles via render(Node,Transform) before calling render(World).
     * Resetting would lose the count and m3g_clear() would overwrite them. */
    
    if (!world) {
        return NATIVE_RETURN_VOID();
    }
    
    /* NOTE: Do NOT call m3g_clear() here!
     * The game already called clear(Background) explicitly after bindTarget.
     * Calling m3g_clear() here would overwrite any triangles already rendered
     * via render(Node,Transform) before this render(World) call.
     * The JSR-184 spec says render(World) replaces the content, but many games
     * call both render(Node,Transform) and render(World) in sequence, expecting
     * the Node renders to persist. */
    
    /* Get active camera from world */
    JavaObject* camera = (JavaObject*)m3g_get_ref_field(world, "activeCamera");
    if (camera) {
        /* Get camera projection parameters */
        float fov = m3g_get_float_field(camera, "fov", 60.0f);
        /* Don't read aspect from camera - it's not in the stub.
         * The aspect ratio is computed from viewport during render. */
        float aspect = 1.0f;
        float near = m3g_get_float_field(camera, "near", 1.0f);
        float far = m3g_get_float_field(camera, "far", 1000.0f);
        
        /* Compute aspect ratio from viewport */
        if (g_m3g.viewport_height > 0) {
            aspect = (float)g_m3g.viewport_width / (float)g_m3g.viewport_height;
        }
        
        m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
    } else {
        /* Default projection if no camera */
        float aspect = 1.0f;
        if (g_m3g.viewport_height > 0) {
            aspect = (float)g_m3g.viewport_width / (float)g_m3g.viewport_height;
        }
        m3g_transform_perspective(&g_m3g.projection, 60.0f, aspect, 1.0f, 1000.0f);
    }
    
    /* Build modelview from camera transform.
     * v14 FIX: render(World) must use the WORLD'S ACTIVE CAMERA scene-graph
     * transform (JSR-184 §Graphics3D.render(World)). The old code let a stale
     * g_m3g.camera_set/camera_inverse — left over from an IMMEDIATE-mode
     * setCamera call, quite possibly of a DIFFERENT scene — override it, so
     * after any immediate-mode scene every retained World rendered with a
     * foreign view matrix (M3GTest scene 7 drew nothing; scenes 3/5/6 used a
     * wrong camera). The camera_inverse set by setCamera is immediate-mode
     * state only. */
    m3g_transform_identity(&g_m3g.modelview);
    if (camera) {
        M3GTransform camera_transform;
        m3g_build_node_transform(camera, &camera_transform);
        
        /* Check if camera has a non-identity transform */
        int has_cam_transform = 0;
        for (int i = 0; i < 16; i++) {
            if (camera_transform.m[i] != ((i % 5 == 0) ? 1.0f : 0.0f)) {
                has_cam_transform = 1;
                break;
            }
        }
        
        if (has_cam_transform) {
            /* Invert camera transform for view matrix */
            M3GTransform cam_inv;
            m3g_transform_identity(&cam_inv);
            
            /* Transpose rotation part (upper-left 3x3) */
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    cam_inv.m[row * 4 + col] = camera_transform.m[col * 4 + row];
                }
            }
            
            /* Apply inverse translation: -R^T * T */
            float cam_tx = -camera_transform.m[12];
            float cam_ty = -camera_transform.m[13];
            float cam_tz = -camera_transform.m[14];
            cam_inv.m[12] = cam_inv.m[0] * cam_tx + cam_inv.m[4] * cam_ty + cam_inv.m[8] * cam_tz;
            cam_inv.m[13] = cam_inv.m[1] * cam_tx + cam_inv.m[5] * cam_ty + cam_inv.m[9] * cam_tz;
            cam_inv.m[14] = cam_inv.m[2] * cam_tx + cam_inv.m[6] * cam_ty + cam_inv.m[10] * cam_tz;
            
            g_m3g.modelview = cam_inv;
            /* Also store in camera_inverse for render(Node,Transform) */
            g_m3g.camera_inverse = cam_inv;
            g_m3g.camera_set = 1;
        }
    }
    
    /* Reset lights for new frame (matching reference's resetLights() in render(World)) */
    g_m3g.light_count = 0;
    /* v14 DIAG: per-renderWorld reset so [M3G-CLIP] fires for retained scenes */
    g_m3g_clip_triangles_in = 0;
    g_m3g_raster_pixels_written = 0;
    
    /* Use recursive rendering to traverse the scene graph with transforms */
    fprintf(stderr, "[M3G] renderWorld: camera=%p, viewport=%dx%d\n", 
            (void*)camera, g_m3g.viewport_width, g_m3g.viewport_height);
    m3g_render_node_recursive(jvm, world, &g_m3g.modelview);
    
    fprintf(stderr, "[M3G] renderWorld: DONE, triangles=%d\n", g_m3g.triangles_rendered);
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.render(World, Transform) — v10 FIX: this overload was NOT
 * registered at all, so games calling it got a silent no-op.
 * Semantics follow FreeJ2ME: the given Transform overrides the camera's
 * world transform for this render call. */
static JavaValue native_graphics3d_renderWorld_transform(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    JavaObject* transform = (JavaObject*)args[2].ref;
    
    if (transform) {
        JavaArray* matrix_arr = (JavaArray*)m3g_get_ref_field(transform, "matrix");
        if (matrix_arr && matrix_arr->element_type == T_FLOAT && matrix_arr->length >= 16) {
            M3GTransform cam_trans, cam_inv;
            m3g_transform_from_rowmajor(&cam_trans, (float*)array_data(matrix_arr));
            m3g_transform_identity(&cam_inv);
            /* Transpose rotation part (upper-left 3x3) */
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    cam_inv.m[row * 4 + col] = cam_trans.m[col * 4 + row];
                }
            }
            /* Apply inverse translation: -R^T * T */
            float tx = -cam_trans.m[12];
            float ty = -cam_trans.m[13];
            float tz = -cam_trans.m[14];
            cam_inv.m[12] = cam_inv.m[0] * tx + cam_inv.m[4] * ty + cam_inv.m[8] * tz;
            cam_inv.m[13] = cam_inv.m[1] * tx + cam_inv.m[5] * ty + cam_inv.m[9] * tz;
            cam_inv.m[14] = cam_inv.m[2] * tx + cam_inv.m[6] * ty + cam_inv.m[10] * tz;
            
            g_m3g.camera_transform = cam_trans;
            g_m3g.camera_inverse = cam_inv;
            g_m3g.camera_set = 1;
            fprintf(stderr, "[M3G] renderWorld(Transform): using transform as camera view\n");
        }
    }
    
    /* Delegate to the plain render(World) path (args[0]=g3d, args[1]=world) */
    return native_graphics3d_renderWorld(jvm, thread, args, arg_count);
}

/* Graphics3D.render(VertexBuffer, IndexBuffer, Appearance, Transform[, scope]) —
 * v11 FIX: the IMMEDIATE-MODE render was never registered. This is the most
 * commonly used M3G drawing call (Nescube used it: bindTarget+setCamera arrived,
 * then the actual draw was a silent no-op → empty 3D). Reuses the existing
 * single-mesh pipeline through a transient Mesh bridge object. */
static JavaValue native_graphics3d_render_immediate(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)thread;
    JavaObject* vb  = (JavaObject*)args[1].ref;
    JavaObject* ib  = (JavaObject*)args[2].ref;
    JavaObject* app = (JavaObject*)args[3].ref;
    /* 4-arg form: args[4]=Transform; 5-arg form: args[4]=Transform, args[5]=scope */
    JavaObject* tr  = (arg_count >= 5) ? (JavaObject*)args[4].ref : NULL;
    
    g_m3g_render_done = true;
    m3g_thread_fence();
    
    if (!vb || !ib) return NATIVE_RETURN_VOID();
    
    static int imm_log_count = 0;
    static int imm_log_count2 = 0;
    if (imm_log_count < 10) {
        imm_log_count++;
        fprintf(stderr, "[M3G] render(vb,ib,app,t): vb=%p ib=%p app=%p t=%p bound=%d\n",
                (void*)vb, (void*)ib, (void*)app, (void*)tr, (int)g_m3g_bindtarget_called);
    }
    /* v29 DIAG: per-call identity trace (env NOJME_IMM_TRACE=1 -> first 400) */
    {
        static int imm_trace = -1;
        if (imm_trace < 0) imm_trace = getenv("NOJME_IMM_TRACE") ? 1 : 0;
        if (imm_trace && imm_log_count2 < 1000000) {
            imm_log_count2++;
            if (tr) {
                M3GTransform tt;
                m3g_read_java_transform(tr, &tt);
                /* v29: + geometry identity (vertex count / index count) to
                 * pinpoint small objects (paddle/ball) in the call stream. */
                int vcount = 0, icount = 0;
                JavaObject* tpos = m3g_get_ref_field(vb, "positions");
                if (tpos) {
                    JavaArray* pa = (JavaArray*)m3g_get_ref_field(tpos, "array");
                    if (pa) vcount = (int)pa->length / 3;
                }
                JavaArray* tidx = (JavaArray*)m3g_get_ref_field(ib, "indices");
                if (tidx) icount = (int)tidx->length / 3;
                fprintf(stderr, "[M3G-IMM] #%d vb=%p ib=%p v=%d tris=%d t=(%.1f,%.1f,%.1f) m00=%.2f m11=%.2f m22=%.2f\n",
                        imm_log_count2, (void*)vb, (void*)ib, vcount, icount,
                        tt.m[12], tt.m[13], tt.m[14], tt.m[0], tt.m[5], tt.m[10]);
                if (icount <= 8) {
                    fprintf(stderr, "[M3G-IMM-M]   | %6.2f %6.2f %6.2f %6.2f |\n"
                                    "[M3G-IMM-M]   | %6.2f %6.2f %6.2f %6.2f |\n"
                                    "[M3G-IMM-M]   | %6.2f %6.2f %6.2f %6.2f |\n"
                                    "[M3G-IMM-M]   | %6.2f %6.2f %6.2f %6.2f |\n",
                            tt.m[0], tt.m[4], tt.m[8],  tt.m[12],
                            tt.m[1], tt.m[5], tt.m[9],  tt.m[13],
                            tt.m[2], tt.m[6], tt.m[10], tt.m[14],
                            tt.m[3], tt.m[7], tt.m[11], tt.m[15]);
                }
            } else {
                fprintf(stderr, "[M3G-IMM] #%d vb=%p ib=%p t=NULL\n",
                        imm_log_count2, (void*)vb, (void*)ib);
            }
        }
    }
    
    /* Per spec, immediate render requires a bound target. If the game renders
     * before bindTarget we cannot draw yet (pending queue only stores Mesh
     * nodes) — mark scene setup so force-render can pick the world up. */
    if (!g_m3g_bindtarget_called) {
        g_m3g_scene_setup_done = true;
        m3g_thread_fence();
        return NATIVE_RETURN_VOID();
    }
    
    /* view*model; m3g_render_mesh_with_mvp prepends the projection */
    M3GTransform input_transform;
    m3g_read_java_transform(tr, &input_transform);
    M3GTransform combined;
    m3g_transform_multiply(&combined, &g_m3g.camera_inverse, &input_transform);

    /* v29 DIAG: paddle-sized quad -> dump view/projection matrices once per
     * state change so the off-screen placement can be verified by hand. */
    {
        static int pd_trace = -1;
        if (pd_trace < 0) pd_trace = getenv("NOJME_SMALLMESH_TRACE") ? 1 : 0;
        if (pd_trace) {
            static JavaObject* s_pd_ib = NULL;
            JavaObject* pd_ib = (JavaObject*)args[2].ref;
            /* identify the 4-vertex paddle quad by its index buffer */
            JavaArray* pd_idx = pd_ib ? (JavaArray*)m3g_get_ref_field(pd_ib, "indices") : NULL;
            if (pd_idx && pd_idx->length == 6 && pd_ib != s_pd_ib) {
                s_pd_ib = pd_ib;
                fprintf(stderr, "[M3G-PADDLE] ib=%p model->world rows:\n", (void*)pd_ib);
                fprintf(stderr, "[M3G-PADDLE]   | %8.1f %8.1f %8.1f %8.1f |\n"
                                "[M3G-PADDLE]   | %8.1f %8.1f %8.1f %8.1f |\n"
                                "[M3G-PADDLE]   | %8.1f %8.1f %8.1f %8.1f |\n"
                                "[M3G-PADDLE]   | %8.1f %8.1f %8.1f %8.1f |\n",
                        input_transform.m[0], input_transform.m[4], input_transform.m[8],  input_transform.m[12],
                        input_transform.m[1], input_transform.m[5], input_transform.m[9],  input_transform.m[13],
                        input_transform.m[2], input_transform.m[6], input_transform.m[10], input_transform.m[14],
                        input_transform.m[3], input_transform.m[7], input_transform.m[11], input_transform.m[15]);
                fprintf(stderr, "[M3G-PADDLE] camera_inverse rows:\n");
                fprintf(stderr, "[M3G-PADDLE]   | %8.4f %8.4f %8.4f %8.1f |\n"
                                "[M3G-PADDLE]   | %8.4f %8.4f %8.4f %8.1f |\n"
                                "[M3G-PADDLE]   | %8.4f %8.4f %8.4f %8.1f |\n"
                                "[M3G-PADDLE]   | %8.4f %8.4f %8.4f %8.4f |\n",
                        g_m3g.camera_inverse.m[0], g_m3g.camera_inverse.m[4], g_m3g.camera_inverse.m[8],  g_m3g.camera_inverse.m[12],
                        g_m3g.camera_inverse.m[1], g_m3g.camera_inverse.m[5], g_m3g.camera_inverse.m[9],  g_m3g.camera_inverse.m[13],
                        g_m3g.camera_inverse.m[2], g_m3g.camera_inverse.m[6], g_m3g.camera_inverse.m[10], g_m3g.camera_inverse.m[14],
                        g_m3g.camera_inverse.m[3], g_m3g.camera_inverse.m[7], g_m3g.camera_inverse.m[11], g_m3g.camera_inverse.m[15]);
                fprintf(stderr, "[M3G-PADDLE] proj rows: r0=(%g %g %g %g) r1=(%g %g %g %g) r2=(%g %g %g %g) r3=(%g %g %g %g) vp=(%d,%d %dx%d)\n",
                        g_m3g.projection.m[0], g_m3g.projection.m[4], g_m3g.projection.m[8],  g_m3g.projection.m[12],
                        g_m3g.projection.m[1], g_m3g.projection.m[5], g_m3g.projection.m[9],  g_m3g.projection.m[13],
                        g_m3g.projection.m[2], g_m3g.projection.m[6], g_m3g.projection.m[10], g_m3g.projection.m[14],
                        g_m3g.projection.m[3], g_m3g.projection.m[7], g_m3g.projection.m[11], g_m3g.projection.m[15],
                        g_m3g.viewport_x, g_m3g.viewport_y,
                        g_m3g.viewport_width, g_m3g.viewport_height);
            }
        }
    }
    
    /* Transient Mesh bridge: m3g_render_single_mesh reads exactly these
     * three fields from the mesh object. Cached — allocated once, reused
     * every call (avoids GC/allocation churn inside the render path). */
    {
        static JavaObject* s_m3g_imm_bridge = NULL;
        static bool s_m3g_imm_bridge_rooted = false;
        /* v15 CRITICAL FIX: the cached bridge is a raw C-side pointer the
         * garbage collector cannot see. The FIRST collection after its
         * creation (e.g. the System.gc() in M3GTest's scene switch) freed
         * it, and from then on EVERY immediate-mode render(vb,ib,ap,t)
         * silently failed its field lookups — all immediate-mode content
         * vanished (black scenes). Root it so the GC keeps it alive, and
         * recreate it if it ever dies anyway. */
        if (s_m3g_imm_bridge && !heap_java_object_valid(s_m3g_imm_bridge)) {
            fprintf(stderr, "[M3G] render(vb,ib,app,t): bridge mesh %p is DEAD (GC'd), recreating\n",
                    (void*)s_m3g_imm_bridge);
            s_m3g_imm_bridge = NULL;
        }
        if (!s_m3g_imm_bridge) {
            JavaClass* mesh_class = jvm_load_class(jvm, "javax/microedition/m3g/Mesh");
            if (!mesh_class) return NATIVE_RETURN_VOID();
            s_m3g_imm_bridge = jvm_new_object(jvm, mesh_class);
            if (!s_m3g_imm_bridge) return NATIVE_RETURN_VOID();
            fprintf(stderr, "[M3G] render(vb,ib,app,t): created Mesh bridge %p\n",
                    (void*)s_m3g_imm_bridge);
            if (!s_m3g_imm_bridge_rooted) {
                extern void gc_add_root(JVM* jvm, void** root);
                gc_add_root(jvm, (void**)&s_m3g_imm_bridge);
                s_m3g_imm_bridge_rooted = true;
            }
        }
        m3g_set_ref_field(s_m3g_imm_bridge, "vertexBuffer", vb);
        m3g_set_ref_field(s_m3g_imm_bridge, "indexBuffer", ib);
        m3g_set_ref_field(s_m3g_imm_bridge, "appearance", app);
        
        m3g_render_mesh_with_mvp(jvm, s_m3g_imm_bridge, &combined);
        
    }
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Extended M3G Native Methods - Additional JSR 184 Support
 * ============================================================================ */

/* VertexArray.set(int firstVertex, int numVertices, byte[] src) */
static JavaValue native_vertexarray_set_byte(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint count = args[2].i;
    JavaArray* src = (JavaArray*)args[3].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get internal data array using helper functions */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    int component_size = m3g_get_int_field(obj, "componentSize", 1);
    int component_count = m3g_get_int_field(obj, "componentCount", 1);
    
    if (!data) return NATIVE_RETURN_VOID();
    
    /* v14 FIX: 'first'/'count' are in VERTICES, but the data array is in
     * ELEMENTS (vertex * component). The old code copied only
     * count*component_size elements instead of
     * count*component_count*component_size — for a 24-vertex 3-component
     * color array only the first third was filled and the remaining
     * vertices rendered BLACK (Nescube cube). */
    int8_t* dst_data = (int8_t*)array_data(data);
    int8_t* src_data = (int8_t*)array_data(src);
    
    int dst_off = first * component_count;
    int copy_elems = count * component_count;
    if (copy_elems > (int)src->length) copy_elems = (int)src->length;
    if (dst_off + copy_elems > (int)data->length) copy_elems = (int)data->length - dst_off;
    
    if (copy_elems > 0) {
        memcpy(dst_data + dst_off, src_data, (size_t)copy_elems * component_size);
    }
    
    GFX_DEBUG("VertexArray.set: first=%d, count=%d, elems=%d@%d", first, count, copy_elems, dst_off);
    return NATIVE_RETURN_VOID();
}

/* VertexArray.set(int firstVertex, int numVertices, short[] src) */
static JavaValue native_vertexarray_set_short(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint count = args[2].i;
    JavaArray* src = (JavaArray*)args[3].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get internal data array using helper function */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    
    if (!data || data->element_type != T_SHORT) return NATIVE_RETURN_VOID();
    
    /* v14 FIX: same vertex-vs-element confusion as the byte[] version —
     * only 1/componentCount of the data was copied per set() call. */
    int16_t* dst_data = (int16_t*)array_data(data);
    int16_t* src_data = (int16_t*)array_data(src);
    
    int comp_cnt_s = m3g_get_int_field(obj, "componentCount", 1);
    int dst_off_s = first * comp_cnt_s;
    int copy_elems_s = count * comp_cnt_s;
    if (copy_elems_s > (int)src->length) copy_elems_s = (int)src->length;
    if (dst_off_s + copy_elems_s > (int)data->length) copy_elems_s = (int)data->length - dst_off_s;
    
    if (copy_elems_s > 0) {
        memcpy(dst_data + dst_off_s, src_data, (size_t)copy_elems_s * sizeof(int16_t));
    }
    
    GFX_DEBUG("VertexArray.set(short[]): first=%d, count=%d, elems=%d@%d",
              first, count, copy_elems_s, dst_off_s);
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * VertexBuffer Native Methods
 * ============================================================================ */

/* VertexBuffer.<init>() */
static JavaValue native_vertexbuffer_init(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Register in M3G registry */
    m3g_registry_register(obj, 0);
    
    m3g_set_int_field(obj, "vertexCount", 0);
    m3g_set_ref_field(obj, "positions", NULL);
    m3g_set_ref_field(obj, "normals", NULL);
    m3g_set_ref_field(obj, "texCoords", NULL);
    m3g_set_ref_field(obj, "colors", NULL);
    m3g_set_float_field(obj, "positionScale", 1.0f);
    
    GFX_DEBUG("VertexBuffer.<init>");
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setPositions(VertexArray positions, float scale, float[] bias) */
static JavaValue native_vertexbuffer_setPositions(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* positions = (JavaObject*)args[1].ref;
    float scale = args[2].f;
    JavaArray* bias = (JavaArray*)args[3].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "positions", positions);
    m3g_set_float_field(obj, "positionScale", scale);
    
    if (positions) {
        int count = m3g_get_int_field(positions, "vertexCount", 0);
        m3g_set_int_field(obj, "vertexCount", count);
    }
    
    if (bias && bias->element_type == T_FLOAT && bias->length >= 3) {
        float* bias_data = (float*)array_data(bias);
        m3g_set_float_field(obj, "biasX", bias_data[0]);
        m3g_set_float_field(obj, "biasY", bias_data[1]);
        m3g_set_float_field(obj, "biasZ", bias_data[2]);
    }
    
    GFX_DEBUG("VertexBuffer.setPositions: scale=%.2f", scale);
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setNormals(VertexArray normals) */
static JavaValue native_vertexbuffer_setNormals(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* normals = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "normals", normals);
    
    GFX_DEBUG("VertexBuffer.setNormals");
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setTexCoords(int index, VertexArray texCoords, float scale, float[] bias) */
static JavaValue native_vertexbuffer_setTexCoords(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* texCoords = (JavaObject*)args[2].ref;
    float scale = args[3].f;
    JavaArray* bias = (JavaArray*)args[4].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    if (index == 0) {
        m3g_set_ref_field(obj, "texCoords", texCoords);
        m3g_set_float_field(obj, "texCoordScale", scale);
        /* v14 FIX: the bias array used to be silently dropped — games using
         * a non-zero texture coordinate bias sampled the wrong texel region
         * (black areas of the atlas). JSR-184: uv = value*scale + bias. */
        float bx = 0.0f, by = 0.0f;
        if (bias && bias->element_type == T_FLOAT && bias->length >= 2) {
            jfloat* b = (jfloat*)array_data(bias);
            bx = b[0];
            by = b[1];
        }
        m3g_set_float_field(obj, "texCoordBiasX", bx);
        m3g_set_float_field(obj, "texCoordBiasY", by);
        GFX_DEBUG("VertexBuffer.setTexCoords: index=%d scale=%.3f bias=(%.3f,%.3f)",
                  index, scale, bx, by);
    }
    
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setColors(VertexArray colors) */
static JavaValue native_vertexbuffer_setColors(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* colors = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "colors", colors);
    
    GFX_DEBUG("VertexBuffer.setColors");
    return NATIVE_RETURN_VOID();
}

/* Transform.invert() */
static JavaValue native_transform_invert(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    M3GTransform* t = get_native_transform(obj);
    if (!t) return NATIVE_RETURN_VOID();
    
    /* 4x4 matrix inversion using Gauss-Jordan elimination */
    float m[16], inv[16];
    memcpy(m, t->m, sizeof(m));
    memset(inv, 0, sizeof(inv));
    inv[0] = inv[5] = inv[10] = inv[15] = 1.0f;
    
    for (int col = 0; col < 4; col++) {
        /* Find pivot */
        int pivot = col;
        for (int row = col + 1; row < 4; row++) {
            if (fabsf(m[row * 4 + col]) > fabsf(m[pivot * 4 + col])) {
                pivot = row;
            }
        }
        
        /* Swap rows */
        if (pivot != col) {
            for (int i = 0; i < 4; i++) {
                float tmp = m[col * 4 + i];
                m[col * 4 + i] = m[pivot * 4 + i];
                m[pivot * 4 + i] = tmp;
                
                tmp = inv[col * 4 + i];
                inv[col * 4 + i] = inv[pivot * 4 + i];
                inv[pivot * 4 + i] = tmp;
            }
        }
        
        /* Check for singular matrix */
        if (fabsf(m[col * 4 + col]) < 0.00001f) {
            GFX_DEBUG("Transform.invert: singular matrix");
            return NATIVE_RETURN_VOID();
        }
        
        /* Scale pivot row */
        float scale = m[col * 4 + col];
        for (int i = 0; i < 4; i++) {
            m[col * 4 + i] /= scale;
            inv[col * 4 + i] /= scale;
        }
        
        /* Eliminate column */
        for (int row = 0; row < 4; row++) {
            if (row != col) {
                float factor = m[row * 4 + col];
                for (int i = 0; i < 4; i++) {
                    m[row * 4 + i] -= factor * m[col * 4 + i];
                    inv[row * 4 + i] -= factor * inv[col * 4 + i];
                }
            }
        }
    }
    
    set_native_transform(obj, &(M3GTransform){.m = {inv[0], inv[1], inv[2], inv[3],
                                                    inv[4], inv[5], inv[6], inv[7],
                                                    inv[8], inv[9], inv[10], inv[11],
                                                    inv[12], inv[13], inv[14], inv[15]}});
    
    GFX_DEBUG("Transform.invert");
    return NATIVE_RETURN_VOID();
}

/* Transform.transform(float[] vectors) */
static JavaValue native_transform_transform(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* vectors = (JavaArray*)args[1].ref;
    
    if (!obj || !vectors || vectors->element_type != T_FLOAT) {
        return NATIVE_RETURN_VOID();
    }
    
    M3GTransform* t = get_native_transform(obj);
    if (!t) return NATIVE_RETURN_VOID();
    
    float* data = (float*)array_data(vectors);
    int count = vectors->length / 4;
    
    for (int i = 0; i < count; i++) {
        float x = data[i * 4 + 0];
        float y = data[i * 4 + 1];
        float z = data[i * 4 + 2];
        float w = data[i * 4 + 3];
        
        data[i * 4 + 0] = t->m[0]*x + t->m[4]*y + t->m[8]*z + t->m[12]*w;
        data[i * 4 + 1] = t->m[1]*x + t->m[5]*y + t->m[9]*z + t->m[13]*w;
        data[i * 4 + 2] = t->m[2]*x + t->m[6]*y + t->m[10]*z + t->m[14]*w;
        data[i * 4 + 3] = t->m[3]*x + t->m[7]*y + t->m[11]*z + t->m[15]*w;
    }
    
    GFX_DEBUG("Transform.transform: %d vectors", count);
    return NATIVE_RETURN_VOID();
}

/* Light.setColor(int ARGB) */
static JavaValue native_light_setColor(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Find the correct light slot for this object */
    int light_idx = find_light_for_object(obj);
    if (light_idx < 0) {
        /* Auto-register if not found */
        if (g_m3g.light_count < 8) {
            light_idx = g_m3g.light_count++;
            memset(&g_m3g.lights[light_idx], 0, sizeof(M3GLight));
            g_m3g.lights[light_idx].obj = obj;
            g_m3g.lights[light_idx].color[3] = 1.0f;
        } else {
            return NATIVE_RETURN_VOID();
        }
    }
    
    M3GLight* light = &g_m3g.lights[light_idx];
    light->color[0] = ((argb >> 16) & 0xFF) / 255.0f;
    light->color[1] = ((argb >> 8) & 0xFF) / 255.0f;
    light->color[2] = (argb & 0xFF) / 255.0f;
    light->color[3] = ((argb >> 24) & 0xFF) / 255.0f;
    
    GFX_DEBUG("Light.setColor: 0x%08X", argb);
    return NATIVE_RETURN_VOID();
}

/* Light.setIntensity(float intensity) */
static JavaValue native_light_setIntensity(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float intensity = args[1].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Find the correct light slot for this object */
    int light_idx = find_light_for_object(obj);
    if (light_idx < 0) {
        /* Auto-register if not found */
        if (g_m3g.light_count < 8) {
            light_idx = g_m3g.light_count++;
            memset(&g_m3g.lights[light_idx], 0, sizeof(M3GLight));
            g_m3g.lights[light_idx].obj = obj;
        } else {
            return NATIVE_RETURN_VOID();
        }
    }
    
    M3GLight* light = &g_m3g.lights[light_idx];
    light->color[3] = intensity;
    
    GFX_DEBUG("Light.setIntensity: %.2f", intensity);
    return NATIVE_RETURN_VOID();
}

/* Light.setDirection(float x, float y, float z) */
static JavaValue native_light_setDirection(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Find the correct light slot for this object */
    int light_idx = find_light_for_object(obj);
    if (light_idx < 0) {
        /* Auto-register if not found */
        if (g_m3g.light_count < 8) {
            light_idx = g_m3g.light_count++;
            memset(&g_m3g.lights[light_idx], 0, sizeof(M3GLight));
            g_m3g.lights[light_idx].obj = obj;
        } else {
            return NATIVE_RETURN_VOID();
        }
    }
    
    M3GLight* light = &g_m3g.lights[light_idx];
    light->direction[0] = x;
    light->direction[1] = y;
    light->direction[2] = z;
    light->direction[3] = 0.0f;  /* Direction, not position */
    /* Task 16-a: mirror onto the object so the scene-traversal light
     * collector honors an explicit direction for lights parented in a graph. */
    m3g_set_float_field(obj, "dirX", x);
    m3g_set_float_field(obj, "dirY", y);
    m3g_set_float_field(obj, "dirZ", z);
    
    GFX_DEBUG("Light.setDirection: (%.2f, %.2f, %.2f)", x, y, z);
    return NATIVE_RETURN_VOID();
}

/* Material.setColor(int target, int ARGB) */
static JavaValue native_material_setColor(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint target = args[1].i;
    jint argb = args[2].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store in fields using helper functions */
    if (target & M3G_MATERIAL_AMBIENT) {
        m3g_set_int_field(obj, "ambient", argb);
    }
    if (target & M3G_MATERIAL_DIFFUSE) {
        m3g_set_int_field(obj, "diffuse", argb);
    }
    if (target & M3G_MATERIAL_SPECULAR) {
        m3g_set_int_field(obj, "specular", argb);
    }
    if (target & M3G_MATERIAL_EMISSIVE) {
        m3g_set_int_field(obj, "emissive", argb);
    }
    
    GFX_DEBUG("Material.setColor: target=%d, ARGB=0x%08X", target, argb);
    return NATIVE_RETURN_VOID();
}

/* Material.setShininess(float shininess) */
static JavaValue native_material_setShininess(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float shininess = args[1].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store shininess using helper function */
    m3g_set_float_field(obj, "shininess", shininess);
    
    GFX_DEBUG("Material.setShininess: %.2f", shininess);
    return NATIVE_RETURN_VOID();
}

/* Appearance.setMaterial(Material) */
static JavaValue native_appearance_setMaterial(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* material = (JavaObject*)args[1].ref;
    
    if (obj) {
        m3g_set_ref_field(obj, "material", material);
    }
    
    GFX_DEBUG("Appearance.setMaterial: material=%p", (void*)material);
    return NATIVE_RETURN_VOID();
}

/* Appearance.getMaterial() */
static JavaValue native_appearance_getMaterial(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        return NATIVE_RETURN_NULL();
    }
    
    JavaObject* material = m3g_get_ref_field(obj, "material");
    GFX_DEBUG("Appearance.getMaterial: material=%p", (void*)material);
    return NATIVE_RETURN_OBJECT(material);
}

/* Appearance.setTexture(int index, Texture2D) */
static JavaValue native_appearance_setTexture(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* texture = (JavaObject*)args[2].ref;
    
    if (obj && index == 0) {
        m3g_set_ref_field(obj, "texture", texture);
    }
    /* v18 TRACE: prove setTexture links the texture (throttled) */
    {
        static int trace_count = 0;
        if (trace_count < 32) {
            trace_count++;
            LOG_SAFE("[M3G-TRACE] Appearance.setTexture #%d index=%d texture=%p\n",
                     trace_count, index, (void*)texture);
        }
    }

    GFX_DEBUG("Appearance.setTexture: index=%d, texture=%p", index, (void*)texture);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.<init>(Image2D) */
static JavaValue native_texture2d_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;

    if (!obj) return NATIVE_RETURN_VOID();

    /* v18 TRACE: prove the texture ctor runs (throttled to first 32 calls) */
    {
        static int trace_count = 0;
        if (trace_count < 32) {
            trace_count++;
            LOG_SAFE("[M3G-TRACE] Texture2D.<init>(Image2D) #%d obj=%p image=%p\n",
                     trace_count, (void*)obj, (void*)image);
        }
    }

    /* Get image data using helper functions */
    if (image) {
        m3g_set_ref_field(obj, "pixels", m3g_get_ref_field(image, "pixels"));
        m3g_set_int_field(obj, "width", m3g_get_int_field(image, "width", 64));
        m3g_set_int_field(obj, "height", m3g_get_int_field(image, "height", 64));
        /* v14 FIX: the constructor used to DROP the reference to the Image2D
         * itself. m3g_build_texture2d resolves the image via the tex-image
         * map or the "image" field; without either it hit TEXBUILD-FAIL and
         * every API-created Texture2D rendered textureless (M3GTest scene 4).
         * Register the image both ways. */
        m3g_set_ref_field(obj, "image", image);
        m3g_store_tex_image_map(obj, image);
    }
    
    GFX_DEBUG("Texture2D.<init>: image=%p", (void*)image);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.setFiltering(int level) — v23: real implementation.
 * level = FILTER_BASE_LEVEL(208) → nearest, FILTER_LINEAR(209) → bilinear,
 * FILTER_TRILINEAR(211) → bilinear on base level (no mips in software raster). */
static JavaValue native_texture2d_setFiltering(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint level = args[1].i;

    if (obj) {
        m3g_set_int_field(obj, "filtering", level);
        /* Refresh a texture that is already built so the change is visible */
        M3GTexture2D* tex = m3g_lookup_texture_cache(obj);
        if (tex) tex->filter_level = (int)level;
    }

    GFX_DEBUG("Texture2D.setFiltering: level=%d", level);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.setWrapping(int wrapS, int wrapT) — v23: real implementation.
 * wrap = WRAP_CLAMP(240) / WRAP_REPEAT(241). */
static JavaValue native_texture2d_setWrapping(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint wrap_s = args[1].i;
    jint wrap_t = args[2].i;

    if (obj) {
        m3g_set_int_field(obj, "blendS", wrap_s);
        m3g_set_int_field(obj, "blendT", wrap_t);
        M3GTexture2D* tex = m3g_lookup_texture_cache(obj);
        if (tex) {
            tex->blend_s = (wrap_s == 240) ? 1 : 0;  /* internal: 1 = clamp */
            tex->blend_t = (wrap_t == 240) ? 1 : 0;
        }
    }

    GFX_DEBUG("Texture2D.setWrapping: s=%d, t=%d", wrap_s, wrap_t);
    return NATIVE_RETURN_VOID();
}

/* Mesh.<init>(VertexArray, IndexBuffer, Appearance) */
static JavaValue native_mesh_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* vertices = (JavaObject*)args[1].ref;
    JavaObject* indices = (JavaObject*)args[2].ref;
    JavaObject* appearance = (JavaObject*)args[3].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Register in M3G registry for force-render fallback.
     * Games that create M3G objects via Java code (not our M3G binary parser)
     * need their objects tracked here so we can render them even if the
     * game's scene graph setup is incomplete. */
    m3g_registry_register(obj, 0);
    
    /* Store references using helper functions */
    m3g_set_ref_field(obj, "vertexBuffer", vertices);
    m3g_set_ref_field(obj, "indices", indices);
    m3g_set_ref_field(obj, "appearance", appearance);
    /* v14 FIX: the Mesh stub class has NO "indices" ref field (that belongs
     * to IndexBuffer) — the reference was silently dropped and every
     * API-created Mesh failed to render retained-mode with "missing
     * indexBuffer" (M3GTest scenes 3/5). The renderer reads "indexBuffer". */
    m3g_set_ref_field(obj, "indexBuffer", indices);
    /* v14 FIX: Node stub fields are zero-initialized, which overrode the
     * JSR-184 default renderingEnable=true — every API-created Mesh had
     * enable=0 and renderNode skipped it. */
    m3g_set_int_field(obj, "renderingEnable", 1);
    m3g_set_int_field(obj, "submeshCount", 1);
    
    GFX_DEBUG("Mesh.<init>: vertices=%p, indices=%p, appearance=%p",
            (void*)vertices, (void*)indices, (void*)appearance);
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * v14: constructors and accessors that M3GTest (and most games) rely on.
 * Previously unregistered, these constructors were silent no-ops, which
 * collapsed the whole animation system and MorphingMesh rendering.
 * ============================================================================ */

/* KeyframeSequence.<init>(int numKeyframes, int numComponents, int interpolation) */
static JavaValue native_keyframesequence_init(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint num_kf = args[1].i;
    jint num_comp = args[2].i;
    jint interpolation = args[3].i;

    if (!obj) return NATIVE_RETURN_VOID();
    if (num_kf < 1 || num_comp < 1 || num_comp > 16) return NATIVE_RETURN_VOID();

    m3g_set_int_field(obj, "numKeyframes", num_kf);
    m3g_set_int_field(obj, "numComponents", num_comp);
    m3g_set_int_field(obj, "componentCount", num_comp);
    m3g_set_int_field(obj, "interpolation", interpolation);
    m3g_set_int_field(obj, "duration", 0);
    m3g_set_int_field(obj, "repeatMode", 192);  /* CONSTANT (JSR-184 default) */
    m3g_set_int_field(obj, "firstValid", 0);
    m3g_set_int_field(obj, "lastValid", num_kf - 1);
    m3g_set_int_field(obj, "validRangeFirst", 0);
    m3g_set_int_field(obj, "validRangeLast", num_kf - 1);

    /* Preallocate the keyframe storage — setKeyframe fills it in */
    JavaArray* times = jvm_new_array(jvm, T_INT, num_kf, NULL);
    JavaArray* values = jvm_new_array(jvm, T_FLOAT, num_kf * num_comp, NULL);
    if (times) m3g_set_ref_field(obj, "keyframeTimes", (JavaObject*)times);
    if (values) m3g_set_ref_field(obj, "keyframeValues", (JavaObject*)values);

    GFX_DEBUG("KeyframeSequence.<init>: kf=%d comp=%d interp=%d", num_kf, num_comp, interpolation);
    return NATIVE_RETURN_VOID();
}

/* AnimationTrack.<init>(KeyframeSequence sequence, int targetProperty) */
static JavaValue native_animationtrack_init(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* sequence = (JavaObject*)args[1].ref;
    jint property = args[2].i;

    if (!obj) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(obj, "sequence", sequence);
    m3g_set_int_field(obj, "propertyId", property);

    GFX_DEBUG("AnimationTrack.<init>: seq=%p property=%d", (void*)sequence, property);
    return NATIVE_RETURN_VOID();
}

/* AnimationController.<init>() — JSR-184 defaults: weight 1.0, speed 1.0,
 * active interval [0, 0) meaning "always active" in our evaluator. */
static JavaValue native_animationcontroller_init(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;

    if (!obj) return NATIVE_RETURN_VOID();
    m3g_set_float_field(obj, "speed", 1.0f);
    m3g_set_float_field(obj, "weight", 1.0f);
    m3g_set_int_field(obj, "activationTime", 0);
    m3g_set_int_field(obj, "deactivationTime", 0);
    m3g_set_float_field(obj, "refSequenceTime", 0.0f);
    m3g_set_int_field(obj, "refWorldTime", 0);

    GFX_DEBUG("AnimationController.<init>");
    return NATIVE_RETURN_VOID();
}

/* MorphingMesh.<init>(VertexBuffer base, VertexBuffer[] targets,
 *                     IndexBuffer[] triangles, Appearance[] appearances) */
static JavaValue native_morphingmesh_init(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* base = (JavaObject*)args[1].ref;
    JavaArray* targets = (JavaArray*)args[2].ref;
    JavaArray* tris = (JavaArray*)args[3].ref;
    JavaArray* apps = (JavaArray*)args[4].ref;

    if (!obj) return NATIVE_RETURN_VOID();

    /* Mirror Mesh.<init> with the base buffers (index 0) */
    m3g_registry_register(obj, 0);
    m3g_set_ref_field(obj, "vertexBuffer", base);
    JavaObject* ib0 = (tris && tris->length > 0)
                    ? ((JavaObject**)array_data(tris))[0] : NULL;
    JavaObject* app0 = (apps && apps->length > 0)
                     ? ((JavaObject**)array_data(apps))[0] : NULL;
    m3g_set_ref_field(obj, "indices", ib0);
    m3g_set_ref_field(obj, "indexBuffer", ib0);   /* v14: renderer reads this */
    m3g_set_ref_field(obj, "appearance", app0);

    if (targets) {
        m3g_set_ref_field(obj, "morphTargets", (JavaObject*)targets);
        m3g_set_int_field(obj, "morphTargetCount", targets->length);
    } else {
        m3g_set_int_field(obj, "morphTargetCount", 0);
    }
    m3g_set_int_field(obj, "renderingEnable", 1);  /* v14: Node zero-init guard */
    m3g_set_int_field(obj, "submeshCount", 1);

    GFX_DEBUG("MorphingMesh.<init>: base=%p targets=%d", (void*)base,
              targets ? (int)targets->length : 0);
    return NATIVE_RETURN_VOID();
}

/* MorphingMesh.setWeights(float[] weights) */
static JavaValue native_morphingmesh_setWeights(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* weights = (JavaArray*)args[1].ref;

    if (!obj) return NATIVE_RETURN_VOID();

    JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "morphWeights");
    int target_count = m3g_get_int_field(obj, "morphTargetCount", 0);
    if (!weights) return NATIVE_RETURN_VOID();

    if (!dst || dst->length < target_count) {
        dst = jvm_new_array(jvm, T_FLOAT, target_count > 0 ? target_count : weights->length, NULL);
        if (dst) m3g_set_ref_field(obj, "morphWeights", (JavaObject*)dst);
    }
    if (dst) {
        jfloat* d = (jfloat*)array_data(dst);
        jfloat* s = (jfloat*)array_data(weights);
        int n = (int)dst->length < (int)weights->length ? (int)dst->length : (int)weights->length;
        for (int i = 0; i < n; i++) d[i] = s[i];
        /* JSR-184: weights beyond target count are ignored; fewer weights
         * leave the remaining targets at 0 (already zero-initialized). */
    }

    GFX_DEBUG("MorphingMesh.setWeights: n=%d", weights ? (int)weights->length : 0);
    return NATIVE_RETURN_VOID();
}

/* MorphingMesh.getWeights() — returns the internal weight array */
static JavaValue native_morphingmesh_getWeights(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_NULL();

    JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "morphWeights");
    if (!dst) {
        int target_count = m3g_get_int_field(obj, "morphTargetCount", 0);
        dst = jvm_new_array(jvm, T_FLOAT, target_count > 0 ? target_count : 1, NULL);
        if (dst) m3g_set_ref_field(obj, "morphWeights", (JavaObject*)dst);
    }
    return NATIVE_RETURN_OBJECT(dst);
}

/* Texture2D.setBlending(int func) — FUNC_REPLACE=160 .. FUNC_ADD=163, FUNC_BLEND=164 */
static JavaValue native_texture2d_setBlending(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint func = args[1].i;
    if (obj) m3g_set_int_field(obj, "blending", func);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_texture2d_getBlending(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(161);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "blending", 161));
}

/* Texture2D.setBlendColor(int ARGB) — used by FUNC_BLEND */
static JavaValue native_texture2d_setBlendColor(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    if (obj) {
        m3g_set_int_field(obj, "blendColor", argb);
        /* Keep the cached built texture in sync if it exists already */
        M3GTexture2D* cached = m3g_lookup_texture_cache(obj);
        if (cached) cached->blend_color = argb;
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_texture2d_getBlendColor(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "blendColor", 0));
}

/* Texture2D.setTransform(Transform) — stores a row-major 4x4 matrix copy */
static JavaValue native_texture2d_setTransform(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    if (!obj) return NATIVE_RETURN_VOID();

    JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "transform");
    if (!dst) {
        dst = jvm_new_array(jvm, T_FLOAT, 16, NULL);
        if (dst) m3g_set_ref_field(obj, "transform", (JavaObject*)dst);
    }
    if (dst && dst->element_type == T_FLOAT && dst->length >= 16) {
        float* d = (float*)array_data(dst);
        int has_matrix = 0;
        JavaArray* marr = transform ? (JavaArray*)m3g_get_ref_field(transform, "matrix") : NULL;
        if (marr && marr->element_type == T_FLOAT && marr->length >= 16) {
            float* m = (float*)array_data(marr);
            memcpy(d, m, 16 * sizeof(float));
            has_matrix = 1;
        }
        if (!has_matrix) {
            /* Null transform or missing matrix — reset to identity */
            static const float I16[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
            memcpy(d, I16, sizeof(I16));
        }
        /* Invalidate the cached texture's UV transform stamp so the next
         * build picks the new matrix up */
        M3GTexture2D* cached = m3g_lookup_texture_cache(obj);
        if (cached) {
            int identity = 1;
            for (int i = 0; i < 16; i++) {
                if (d[i] != ((i % 5 == 0) ? 1.0f : 0.0f)) { identity = 0; break; }
            }
            memcpy(cached->uv_transform, d, 16 * sizeof(float));
            cached->has_uv_transform = !identity;
        }
    }
    return NATIVE_RETURN_VOID();
}

/* Material.setVertexColorTrackingEnable(boolean) */
static JavaValue native_material_setVertexColorTrackingEnable(JVM* jvm, JavaThread* thread,
                                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint enable = args[1].i;
    if (obj) m3g_set_int_field(obj, "vertexColorTracking", enable ? 1 : 0);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_material_getVertexColorTrackingEnable(JVM* jvm, JavaThread* thread,
                                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "vertexColorTracking", 0));
}

/* TriangleStripArray.<init>(int firstIndex, int[] stripLengths) */
static JavaValue native_trianglestrip_init(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    JavaArray* lengths = (JavaArray*)args[2].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Calculate total indices needed */
    int total_indices = 0;
    int strip_count = lengths ? lengths->length : 0;
    jint* len_data = lengths ? (jint*)array_data(lengths) : NULL;
    
    /* Sanity check: limit strip count */
    if (strip_count > 1024) {
        GFX_DEBUG("TriangleStripArray: strip_count %d exceeds max 1024", strip_count);
        strip_count = 1024;
    }
    
    for (int i = 0; i < strip_count; i++) {
        int strip_len = len_data[i];
        /* Skip invalid strips (need at least 3 vertices for a triangle) */
        if (strip_len < 3) continue;
        /* Each strip of n vertices produces (n-2) triangles */
        int strip_indices = (strip_len - 2) * 3;
        /* Check for overflow */
        if (total_indices + strip_indices > M3G_MAX_INDEX_COUNT) {
            GFX_DEBUG("TriangleStripArray: total_indices overflow, clamping");
            break;
        }
        total_indices += strip_indices;
    }
    
    /* Validate total_indices before allocation */
    if (total_indices <= 0 || total_indices > M3G_MAX_INDEX_COUNT) {
        GFX_DEBUG("TriangleStripArray: invalid total_indices %d", total_indices);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create index buffer */
    JavaArray* indices = jvm_new_array(jvm, T_SHORT, total_indices, NULL);
    if (indices) {
        int idx = 0;
        int vertex = first;
        
        for (int strip = 0; strip < strip_count && idx < total_indices; strip++) {
            int strip_len = len_data[strip];
            if (strip_len < 3) continue;
            
            /* Generate triangle strip indices */
            for (int t = 0; t < strip_len - 2 && idx + 2 < total_indices; t++) {
                int16_t* data = (int16_t*)array_data(indices);
                if (t % 2 == 0) {
                    data[idx++] = vertex + t;
                    data[idx++] = vertex + t + 1;
                    data[idx++] = vertex + t + 2;
                } else {
                    /* Swap last two for correct winding */
                    data[idx++] = vertex + t;
                    data[idx++] = vertex + t + 2;
                    data[idx++] = vertex + t + 1;
                }
            }
            vertex += strip_len;
        }
        
        /* Store index buffer using helper function */
        m3g_set_ref_field(obj, "indices", (JavaObject*)indices);
    }
    
    GFX_DEBUG("TriangleStripArray.<init>: first=%d, strips=%d, indices=%d",
            first, strip_count, total_indices);
    return NATIVE_RETURN_VOID();
}

/* TriangleStripArray.<init>(int[] indices, int[] stripLengths).
 * v14 FIX: this constructor was completely unregistered — every
 * explicitly-indexed mesh (M3GTest Geom.ib, most retained-mode games) got a
 * TriangleStripArray with NO index data ("missing indices array") and
 * rendered nothing. Store an explicit index copy instead of expanding
 * strips. */
static JavaValue native_trianglestrip_init_explicit(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* idx_src = (JavaArray*)args[1].ref;
    JavaArray* lengths = (JavaArray*)args[2].ref;

    if (!obj || !idx_src) return NATIVE_RETURN_VOID();

    int n = (int)idx_src->length;
    if (n <= 0 || n > M3G_MAX_INDEX_COUNT) return NATIVE_RETURN_VOID();

    /* Expand the explicit index list into the (triangulated) strip layout
     * the renderer expects: every 3 consecutive indices form one triangle,
     * which is exactly the source layout here (stripLengths are all 3 in
     * this usage, but honour them when provided). */
    JavaArray* indices = jvm_new_array(jvm, T_SHORT, n, NULL);
    if (!indices) return NATIVE_RETURN_VOID();
    jint* src = (jint*)array_data(idx_src);
    int16_t* dst = (int16_t*)array_data(indices);
    for (int i = 0; i < n; i++) {
        dst[i] = (int16_t)(src[i] & 0xFFFF);
    }
    m3g_set_ref_field(obj, "indices", (JavaObject*)indices);
    if (lengths) {
        /* record strip lengths for completeness */
        JavaArray* sl = jvm_new_array(jvm, T_INT, lengths->length, NULL);
        if (sl) {
            jint* s = (jint*)array_data(sl);
            jint* l = (jint*)array_data(lengths);
            for (int i = 0; i < (int)lengths->length; i++) s[i] = l[i];
            m3g_set_ref_field(obj, "stripLengths", (JavaObject*)sl);
        }
    }
    m3g_set_int_field(obj, "indexCount", n);

    GFX_DEBUG("TriangleStripArray.<init>([I[I): n=%d", n);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setCamera(Camera, Transform) */
static JavaValue native_graphics3d_setCamera(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* camera = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d;
    
    g_m3g_scene_setup_done = true;  /* Track that scene setup is happening */
    m3g_thread_fence();
    g_m3g.camera = camera;
    
    LOG_SAFE( "[M3G-SETCAM] camera=%p transform=%p\n", (void*)camera, (void*)transform);
    
    if (camera) {
        /* Build camera's composite transform */
        M3GTransform cam_trans;
        if (transform) {
            /* Read transform from the Java Transform object */
            JavaArray* matrix_arr = (JavaArray*)m3g_get_ref_field(transform, "matrix");
            LOG_SAFE( "[M3G-SETCAM] transform.matrix=%p type=%d len=%d\n",
                    (void*)matrix_arr, matrix_arr ? matrix_arr->element_type : -1, matrix_arr ? matrix_arr->length : -1);
            if (matrix_arr && matrix_arr->element_type == T_FLOAT && matrix_arr->length >= 16) {
                float* m = (float*)array_data(matrix_arr);
                fprintf(stderr, "[M3G-SETCAM] matrix raw: %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f / %.3f,%.3f,%.3f,%.3f\n",
                    m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);
                /* Java Transform stores row-major; convert to column-major */
                m3g_transform_from_rowmajor(&cam_trans, m);
            } else {
                m3g_transform_identity(&cam_trans);
                fprintf(stderr, "[M3G-SETCAM] Using identity (matrix field missing or wrong type)\n");
            }
        } else {
            m3g_transform_identity(&cam_trans);
            fprintf(stderr, "[M3G-SETCAM] Using identity (transform arg is null)\n");
        }
        
        g_m3g.camera_transform = cam_trans;
        
        /* Compute inverse for view matrix */
        M3GTransform cam_inv;
        m3g_transform_identity(&cam_inv);
        
        /* Transpose rotation part (upper-left 3x3) */
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                cam_inv.m[row * 4 + col] = cam_trans.m[col * 4 + row];
            }
        }
        
        /* Apply inverse translation: -R^T * T */
        float tx = -cam_trans.m[12];
        float ty = -cam_trans.m[13];
        float tz = -cam_trans.m[14];
        cam_inv.m[12] = cam_inv.m[0] * tx + cam_inv.m[4] * ty + cam_inv.m[8] * tz;
        cam_inv.m[13] = cam_inv.m[1] * tx + cam_inv.m[5] * ty + cam_inv.m[9] * tz;
        cam_inv.m[14] = cam_inv.m[2] * tx + cam_inv.m[6] * ty + cam_inv.m[10] * tz;
        
        g_m3g.camera_inverse = cam_inv;
        
        /* Build projection from camera parameters */
        float fov = m3g_get_float_field(camera, "fov", 60.0f);
        /* FIX 31: Compute aspect from viewport. If viewport not set yet (0x0),
         * use 0.75 as fallback for typical 240x320 screen. */
        float aspect = 0.75f;
        float near = m3g_get_float_field(camera, "near", 1.0f);
        float far = m3g_get_float_field(camera, "far", 1000.0f);
        /* v18 DIAG: log the camera projection parameters actually used */
        {
            int ptype = m3g_get_int_field(camera, "projectionType", 0);
            fprintf(stderr, "[M3G-PROJ] fov=%.2f aspect=%.4f near=%.3f far=%.3f type=%d viewport=%dx%d\n",
                    fov, aspect, near, far, ptype,
                    g_m3g.viewport_width, g_m3g.viewport_height);
        }
        
        if (g_m3g.viewport_width > 0 && g_m3g.viewport_height > 0) {
            aspect = (float)g_m3g.viewport_width / (float)g_m3g.viewport_height;
        }
        
        /* v25: use the EXACT projection matrix cached on the camera object.
         * setPerspective/setParallel/setGeneric (and the M3G file loader)
         * all keep 'genericMatrix' in sync with the real matrix, so setCamera
         * must not REBUILD it from raw fields: the old PARALLEL rebuild read
         * the 'fov' field (degrees) as the world-space ortho height instead
         * of the 'height' field (world units) — every game that mixed
         * perspective and parallel cameras rendered its parallel pass with a
         * several-times-wrong scale (Brick Breaker walls off-screen at NDC
         * ±2.7, "back faces look bigger than front faces"). */
        int projection_type = m3g_get_int_field(camera, "projectionType", 0);
        (void)projection_type;
        JavaArray* gen_check = (JavaArray*)m3g_get_ref_field(camera, "genericMatrix");
        if (gen_check && gen_check->element_type == T_FLOAT && gen_check->length >= 16) {
            float* m = (float*)array_data(gen_check);
            /* v25 DIAG: dump raw generic matrix + auto-detect decision */
            {
                static int gen_dump = 0;
                if (gen_dump++ < 8) {
                    float t_std = fabsf(m[12]) + fabsf(m[13]) + fabsf(m[14]);
                    float t_alt = fabsf(m[3]) + fabsf(m[7]) + fabsf(m[11]);
                    fprintf(stderr, "[M3G-GEN] raw: %.4f,%.4f,%.4f,%.4f / %.4f,%.4f,%.4f,%.4f / %.4f,%.4f,%.4f,%.4f / %.4f,%.4f,%.4f,%.4f t_std=%.5f t_alt=%.5f\n",
                        m[0],m[1],m[2],m[3], m[4],m[5],m[6],m[7],
                        m[8],m[9],m[10],m[11], m[12],m[13],m[14],m[15], t_std, t_alt);
                }
            }
            m3g_transform_from_rowmajor(&g_m3g.projection, m);
        } else {
            /* Never-configured camera (no setter ever ran, no loader matrix):
             * legacy default perspective fallback — same as v24. */
            m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
        }
        
        /* Set modelview = camera inverse */
        g_m3g.modelview = cam_inv;
    } else {
        m3g_transform_identity(&g_m3g.camera_transform);
        m3g_transform_identity(&g_m3g.camera_inverse);
        m3g_transform_identity(&g_m3g.modelview);
    }
    
    g_m3g.camera_set = 1;
    
    /* Reset clip diagnostic counter so next renderMesh will log with new camera */
    g_m3g_clip_triangles_in = 0;
    g_m3g_clip_triangles_out = 0;  /* v25: was never reset -> bogus 24→399148 logs */
    g_m3g_raster_pixels_written = 0;
    
    GFX_DEBUG("setCamera: camera=%p", (void*)camera);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.resetLights() */
static JavaValue native_graphics3d_resetLights(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    (void)args;
    
    g_m3g.light_count = 0;
    /* Task 16-a: clear the per-render active list as well */
    g_m3g_active_light_count = 0;
    memset(g_m3g.lights, 0, sizeof(g_m3g.lights));
    
    return NATIVE_RETURN_VOID();
}

/* Helper: Build a Transform from a Java Transform object.
 * Java Transform stores matrix in row-major order; C M3GTransform uses column-major.
 * We must transpose when copying. */
static void m3g_read_java_transform(JavaObject* transform_obj, M3GTransform* out) {
    m3g_transform_identity(out);
    if (!transform_obj) return;
    
    JavaArray* matrix_arr = (JavaArray*)m3g_get_ref_field(transform_obj, "matrix");
    if (matrix_arr && matrix_arr->element_type == T_FLOAT && matrix_arr->length >= 16) {
        float* m = (float*)array_data(matrix_arr);
        /* Java stores row-major; convert to column-major */
        m3g_transform_from_rowmajor(out, m);
    }
}

/* Helper: Render a Mesh node with the given modelview-projection matrix */
static void m3g_render_mesh_with_mvp(JVM* jvm, JavaObject* mesh, M3GTransform* modelview) {
    if (!mesh) return;
    
    /* Build MVP = projection * modelview (OpenGL convention) */
    M3GTransform mvp;
    m3g_transform_multiply(&mvp, &g_m3g.projection, modelview);
    
    m3g_render_single_mesh(jvm, mesh, &mvp);
}

/* Graphics3D.render(Node, Transform) - Matches FreeJ2ME reference implementation */
static JavaValue native_graphics3d_render_node(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    M3G_PIPELINE_LOCK();
    (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* node = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d;
    
    if (!node) return NATIVE_RETURN_VOID();
    
    fprintf(stderr, "[M3G-RENDER-NODE] node=%p class=%s\n", (void*)node,
            node->header.clazz ? node->header.clazz->class_name : "?");
    
    /* If bindTarget hasn't been called (no framebuffer), record this render call
     * for later replay during force-render. This handles games that call render()
     * before bindTarget or never call bindTarget at all.
     *
     * IMPORTANT: Must check g_m3g_bindtarget_called (reset each paint cycle), NOT
     * buffers_allocated (persists forever after first allocation). Using buffers_allocated
     * would stop queuing after the first force-render allocates buffers. */
    if (!g_m3g_bindtarget_called && g_m3g_pending_render_count < M3G_MAX_PENDING_RENDERS) {
        int idx = g_m3g_pending_render_count;
        g_m3g_pending_renders[idx].node = node;
        g_m3g_pending_renders[idx].transform = transform;
        g_m3g_pending_render_count++;
        g_m3g_scene_setup_done = true;
        m3g_thread_fence();
        fprintf(stderr, "[M3G-RENDER-NODE] Queued pending render #%d (node=%p, total pending=%d)\n",
                idx, (void*)node, g_m3g_pending_render_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Read the incoming transform */
    M3GTransform input_transform;
    m3g_read_java_transform(transform, &input_transform);
    
    JavaClass* clazz = node->header.clazz;
    if (!clazz || !clazz->class_name) return NATIVE_RETURN_VOID();
    
    const char* class_name = clazz->class_name;
    
    /* v29 DIAG: per-node class trace (env NOJME_NODE_TRACE=1) */
    {
        static int node_trace = -1;
        if (node_trace < 0) node_trace = getenv("NOJME_NODE_TRACE") ? 1 : 0;
        if (node_trace) {
            static int node_traced = 0;
            if (node_traced < 3000) {
                node_traced++;
                fprintf(stderr, "[M3G-NODE] #%d class=%s enable=%d\n",
                        node_traced, class_name,
                        m3g_get_int_field(node, "renderingEnable", 1));
            }
        }
    }
    
    /* v29 FIX (Brick Breaker paddle): Sprite3D nodes were silently dropped by
     * render(Node, Transform) — neither the top-level dispatch (fell through
     * to a "not implemented" debug note) nor the child filter (fell into the
     * Group recursion, recursing into a leaf's non-existent children) ever
     * reached m3g_render_sprite3d. */
    if (strstr(class_name, "Sprite3D") != NULL) {
        int render_enable = m3g_get_int_field(node, "renderingEnable", 1);
        {
            static int rn_spr_logs = -1;
            if (rn_spr_logs < 0) rn_spr_logs = getenv("NOJME_SPRITE_TRACE") ? 48 : 0;
            if (rn_spr_logs > 0 && rn_spr_logs-- > 1) {
                fprintf(stderr,
                        "[M3G-SPRITE-RN] sprite=%p enable=%d t=(%.1f,%.1f,%.1f) scale=(%.2f,%.2f)\n",
                        (void*)node, render_enable,
                        m3g_get_float_field(node, "translationX", 0),
                        m3g_get_float_field(node, "translationY", 0),
                        m3g_get_float_field(node, "translationZ", 0),
                        m3g_get_float_field(node, "scaleX", 1),
                        m3g_get_float_field(node, "scaleY", 1));
            }
        }
        if (render_enable) {
            M3GTransform node_transform, combined, full_modelview, mvp;
            m3g_build_node_transform(node, &node_transform);
            m3g_transform_multiply(&combined, &g_m3g.camera_inverse, &input_transform);
            m3g_transform_multiply(&full_modelview, &combined, &node_transform);
            m3g_transform_multiply(&mvp, &g_m3g.projection, &full_modelview);
            m3g_render_sprite3d(jvm, node, &mvp);
        }
        return NATIVE_RETURN_VOID();
    }
    
    /* Handle Mesh nodes */
    if (strstr(class_name, "Mesh") != NULL) {
        /* Check rendering enabled */
        int render_enable = m3g_get_int_field(node, "renderingEnable", 1);
        if (render_enable) {
            /* Build the node's local transform and combine */
            M3GTransform node_transform;
            m3g_build_node_transform(node, &node_transform);
            
            /* Full modelview = (camera_inverse * input) * node_transform */
            M3GTransform combined, full_modelview;
            m3g_transform_multiply(&combined, &g_m3g.camera_inverse, &input_transform);
            m3g_transform_multiply(&full_modelview, &combined, &node_transform);
            
            m3g_render_mesh_with_mvp(jvm, node, &full_modelview);
        }
        return NATIVE_RETURN_VOID();
    }
    
    /* Handle Group/World nodes — v29: delegate to the single recursive
     * dispatcher (handles Mesh/Sprite3D/Group at ANY depth). Previously this
     * was a hand-rolled 3-level traversal that (a) truncated deeper scene
     * graphs and (b) misrouted Sprite3D children into the Group branch where
     * they recursed into leaf nodes' non-existent children — invisible. */
    if (strstr(class_name, "Group") != NULL || strstr(class_name, "World") != NULL) {
        m3g_replay_render_node(jvm, node, &input_transform);
        return NATIVE_RETURN_VOID();
    }
    
    /* Other node types (Light, Camera, ...) have no direct visual output */
    return NATIVE_RETURN_VOID();
}

/* Node.setScale(float sx, float sy, float sz) */
static JavaValue native_node_setScale(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float sx = args[1].f;
    float sy = args[2].f;
    float sz = args[3].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store decomposed scale values */
    m3g_set_float_field(obj, "scaleX", sx);
    m3g_set_float_field(obj, "scaleY", sy);
    m3g_set_float_field(obj, "scaleZ", sz);
    
    /* Rebuild the composite transform matrix from decomposed values.
     * The M3G Transformable composes as: Translation * Rotation * Scale.
     * Build S, R, T matrices and compute T * R * S. */
    float tx = m3g_get_float_field(obj, "translationX", 0.0f);
    float ty = m3g_get_float_field(obj, "translationY", 0.0f);
    float tz = m3g_get_float_field(obj, "translationZ", 0.0f);
    float angle = m3g_get_float_field(obj, "orientationAngle", 0.0f);
    float ax = m3g_get_float_field(obj, "orientationX", 0.0f);
    float ay = m3g_get_float_field(obj, "orientationY", 0.0f);
    float az = m3g_get_float_field(obj, "orientationZ", 1.0f);
    
    /* Start with scale */
    M3GTransform result;
    m3g_transform_identity(&result);
    m3g_transform_scale(&result, sx, sy, sz);
    
    /* Apply rotation */
    float angle_rad = angle * 3.14159f / 180.0f;
    m3g_transform_rotate(&result, angle_rad, ax, ay, az);
    
    /* Apply translation */
    m3g_transform_translate(&result, tx, ty, tz);
    
    /* Store back into the node's transform matrix field */
    JavaArray* matrix = (JavaArray*)m3g_get_ref_field(obj, "transform");
    if (matrix && matrix->element_type == T_FLOAT && matrix->length >= 16) {
        float* m = (float*)array_data(matrix);
        memcpy(m, result.m, 16 * sizeof(float));
    }
    
    GFX_DEBUG("Node.setScale: (%.2f, %.2f, %.2f)", sx, sy, sz);
    return NATIVE_RETURN_VOID();
}

/* Node.setTranslation(float x, float y, float z) */
static JavaValue native_node_setTranslation(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store decomposed translation values */
    m3g_set_float_field(obj, "translationX", x);
    m3g_set_float_field(obj, "translationY", y);
    m3g_set_float_field(obj, "translationZ", z);
    
    /* Rebuild the composite transform matrix from decomposed values */
    float sx = m3g_get_float_field(obj, "scaleX", 1.0f);
    float sy = m3g_get_float_field(obj, "scaleY", 1.0f);
    float sz = m3g_get_float_field(obj, "scaleZ", 1.0f);
    float angle = m3g_get_float_field(obj, "orientationAngle", 0.0f);
    float ax = m3g_get_float_field(obj, "orientationX", 0.0f);
    float ay = m3g_get_float_field(obj, "orientationY", 0.0f);
    float az = m3g_get_float_field(obj, "orientationZ", 1.0f);
    
    /* Start with scale */
    M3GTransform result;
    m3g_transform_identity(&result);
    m3g_transform_scale(&result, sx, sy, sz);
    
    /* Apply rotation */
    float angle_rad = angle * 3.14159f / 180.0f;
    m3g_transform_rotate(&result, angle_rad, ax, ay, az);
    
    /* Apply translation */
    m3g_transform_translate(&result, x, y, z);
    
    /* Store back into the node's transform matrix field */
    JavaArray* matrix = (JavaArray*)m3g_get_ref_field(obj, "transform");
    if (matrix && matrix->element_type == T_FLOAT && matrix->length >= 16) {
        float* m = (float*)array_data(matrix);
        memcpy(m, result.m, 16 * sizeof(float));
    }
    
    GFX_DEBUG("Node.setTranslation: (%.2f, %.2f, %.2f)", x, y, z);
    return NATIVE_RETURN_VOID();
}

/* Node.setRotation(float angle, float ax, float ay, float az) */
static JavaValue native_node_setRotation(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float angle = args[1].f;
    float ax = args[2].f;
    float ay = args[3].f;
    float az = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store decomposed rotation values */
    m3g_set_float_field(obj, "orientationAngle", angle);
    m3g_set_float_field(obj, "orientationX", ax);
    m3g_set_float_field(obj, "orientationY", ay);
    m3g_set_float_field(obj, "orientationZ", az);
    
    /* Rebuild the composite transform matrix from decomposed values */
    float tx = m3g_get_float_field(obj, "translationX", 0.0f);
    float ty = m3g_get_float_field(obj, "translationY", 0.0f);
    float tz = m3g_get_float_field(obj, "translationZ", 0.0f);
    float sx = m3g_get_float_field(obj, "scaleX", 1.0f);
    float sy = m3g_get_float_field(obj, "scaleY", 1.0f);
    float sz = m3g_get_float_field(obj, "scaleZ", 1.0f);
    
    /* Start with scale */
    M3GTransform result;
    m3g_transform_identity(&result);
    m3g_transform_scale(&result, sx, sy, sz);
    
    /* Apply rotation */
    float angle_rad = angle * 3.14159f / 180.0f;
    m3g_transform_rotate(&result, angle_rad, ax, ay, az);
    
    /* Apply translation */
    m3g_transform_translate(&result, tx, ty, tz);
    
    /* Store back into the node's transform matrix field */
    JavaArray* matrix = (JavaArray*)m3g_get_ref_field(obj, "transform");
    if (matrix && matrix->element_type == T_FLOAT && matrix->length >= 16) {
        float* m = (float*)array_data(matrix);
        memcpy(m, result.m, 16 * sizeof(float));
    }
    
    GFX_DEBUG("Node.setRotation: angle=%.1f, axis=(%.2f, %.2f, %.2f)", angle, ax, ay, az);
    return NATIVE_RETURN_VOID();
}

/* Camera.setGeneric(Transform) — v23: real implementation. Copies the
 * caller's 4x4 straight into the projection (column-major internal layout
 * matches Transform), mirrors setPerspective's behavior of updating
 * g_m3g.projection immediately, and stores the matrix + GENERIC type on
 * the camera object for the force-render path. */
static JavaValue native_camera_setGeneric(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;

    if (!obj || !transform) return NATIVE_RETURN_VOID();

    M3GTransform t;
    get_native_transform_into(transform, &t);

    /* Store on the camera object (projectionType = GENERIC = 0) */
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(obj, "genericMatrix");
    if (!arr || arr->length < 16 || arr->element_type != T_FLOAT) {
        arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
        if (arr) m3g_set_ref_field(obj, "genericMatrix", (JavaObject*)arr);
    }
    if (arr && arr->element_type == T_FLOAT && arr->length >= 16) {
        memcpy(array_data(arr), t.m, 16 * sizeof(float));
    }
    m3g_set_int_field(obj, "projectionType", 0);  /* GENERIC */

    /* Immediate: same global-projection update the other setters do */
    memcpy(g_m3g.projection.m, t.m, 16 * sizeof(float));

    GFX_DEBUG("Camera.setGeneric");
    return NATIVE_RETURN_VOID();
}

/* v23: Camera.getProjection(float params) — fills the projection parameters
 * and returns the type (GENERIC=0, PARALLEL=1, PERSPECTIVE=2). */
static JavaValue native_camera_getProjection(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* params = (JavaArray*)args[1].ref;

    if (!obj) return NATIVE_RETURN_INT(0);

    int type = m3g_get_int_field(obj, "projectionType", 2);

    if (params && params->element_type == T_FLOAT && params->length >= 4) {
        float* p = (float*)array_data(params);
        if (type == 1) {  /* PARALLEL: height, aspect, near, far */
            p[0] = m3g_get_float_field(obj, "height", 2.0f);
            p[1] = m3g_get_float_field(obj, "aspect", 1.0f);
            p[2] = m3g_get_float_field(obj, "near", 0.1f);
            p[3] = m3g_get_float_field(obj, "far", 1000.0f);
        } else if (type == 2) {  /* PERSPECTIVE: fovy, aspect, near, far */
            p[0] = m3g_get_float_field(obj, "fov", 60.0f);
            p[1] = m3g_get_float_field(obj, "aspect", 1.0f);
            p[2] = m3g_get_float_field(obj, "near", 0.1f);
            p[3] = m3g_get_float_field(obj, "far", 1000.0f);
        } else {  /* GENERIC: copy the stored matrix (first 16) */
            JavaArray* arr = (JavaArray*)m3g_get_ref_field(obj, "genericMatrix");
            /* v25 FIX: JSR-184 requires >=16 floats in params for GENERIC;
             * memcpy 16 floats into a shorter array = heap overflow. */
            if (arr && arr->element_type == T_FLOAT && arr->length >= 16 &&
                params->length >= 16) {
                memcpy(p, array_data(arr), 16 * sizeof(float));
            }
        }
    }

    return NATIVE_RETURN_INT(type);
}

/* Background.setColor(int ARGB) */
/* v20 FIX: JSR-184 §Background — a NEW Background has colorClearEnable=true,
 * depthClearEnable=true. The stub fields zero-initialize to false, so games
 * that only call setColor() (Nescube) silently disabled BOTH clears once the
 * clear path started honoring the flags (cube rendered 0 pixels: depth never
 * cleared, all fragments depth-rejected). */
static JavaValue native_background_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_VOID();
    JavaValue v;
    v.raw = 0; v.i = 1;
    m3g_set_int_field(bg, "colorClearEnable", 1);
    m3g_set_int_field(bg, "depthClearEnable", 1);
    m3g_set_int_field(bg, "clearColor", 0x00000000);
    (void)v;
    return NATIVE_RETURN_VOID();
}

static JavaValue native_background_setColor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store color using helper function */
    m3g_set_int_field(obj, "clearColor", argb);
    
    GFX_DEBUG("Background.setColor: 0x%08X", argb);
    return NATIVE_RETURN_VOID();
}

/* Image2D.<init>(int format, int width, int height) */
static JavaValue native_image2d_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint format = args[1].i;
    jint width = args[2].i;
    jint height = args[3].i;
    
    if (!obj || width <= 0 || height <= 0) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for oversized images to prevent OOM errors from malformed M3G files */
    if (width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        GFX_DEBUG("Image2D.<init>: REJECTED - dimensions too large: %dx%d (max %d)", 
                width, height, M3G_MAX_IMAGE_DIMENSION);
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for integer overflow in width * height calculation */
    jint pixel_count = width * height;
    if (pixel_count > M3G_MAX_IMAGE_PIXELS || pixel_count <= 0) {
        GFX_DEBUG("Image2D.<init>: REJECTED - pixel count overflow: %d", pixel_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create pixel array (ARGB format) */
    JavaArray* pixels = jvm_new_array(jvm, T_INT, pixel_count, NULL);
    if (!pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "pixels", (JavaObject*)pixels);
    m3g_set_int_field(obj, "width", width);
    m3g_set_int_field(obj, "height", height);
    m3g_set_int_field(obj, "format", format);
    
    GFX_DEBUG("Image2D.<init>: format=%d, %dx%d", format, width, height);
    return NATIVE_RETURN_VOID();
}

/* Image2D.<init>(int format, Object image) - creates Image2D from LCDUI Image */
static JavaValue native_image2d_init_from_image(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint format = args[1].i;
    JavaObject* image = (JavaObject*)args[2].ref;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    GFX_DEBUG("Image2D.<init>(int, Object): format=%d, image=%p", format, (void*)image);
    
    int width = 0, height = 0;
    JavaArray* src_pixels = NULL;
    MidpImage* native_img = NULL;
    
    /* Try to get image data from LCDUI Image object using helper functions */
    if (image) {
        width = m3g_get_int_field(image, "width", 0);
        height = m3g_get_int_field(image, "height", 0);
        src_pixels = (JavaArray*)m3g_get_ref_field(image, "pixels");
        if (!src_pixels) src_pixels = (JavaArray*)m3g_get_ref_field(image, "data");
        if (!src_pixels) src_pixels = (JavaArray*)m3g_get_ref_field(image, "imageData");
    }
    
    /* v14 FIX: LCDUI Images in this emulator keep their pixels in the NATIVE
     * MidpImage struct stored behind the "nativePeer" field — such objects
     * have NO Java-side width/height/pixels fields, so the field lookups
     * above always failed and every Image2D built from an lcdui Image
     * silently became a 64x64 BLACK placeholder (M3GTest scene 4 "no
     * textures visible", Nescube cube texture, any game converting its
     * 2D assets via new Image2D(RGB, image)). Read real dimensions and
     * pixel data from the native peer when present. */
    if (image) {
        extern MidpImage* get_image_from_object(JavaObject* obj);
        native_img = get_image_from_object(image);
        if (native_img && native_img->width > 0 && native_img->height > 0) {
            width = native_img->width;
            height = native_img->height;
        }
    }
    
    /* If no valid dimensions, use defaults */
    if (width <= 0) width = 64;
    if (height <= 0) height = 64;
    
    /* Check for oversized images to prevent OOM errors */
    if (width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        GFX_DEBUG("Image2D.<init>(Object): REJECTED - dimensions too large: %dx%d (max %d)", 
                width, height, M3G_MAX_IMAGE_DIMENSION);
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for integer overflow in width * height calculation */
    int pixel_count = width * height;
    if (pixel_count > M3G_MAX_IMAGE_PIXELS || pixel_count <= 0) {
        GFX_DEBUG("Image2D.<init>(Object): REJECTED - pixel count overflow: %d", pixel_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create pixel array (ARGB format) */
    JavaArray* pixels = jvm_new_array(jvm, T_INT, pixel_count, NULL);
    if (!pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Copy source pixels if available */
    if (native_img && native_img->pixels) {
        /* v14: lcdui Image native peer — pixels are uint32 ARGB, same
         * layout as our internal Image2D int[] (0xAARRGGBB). */
        jint* dst_data = (jint*)array_data(pixels);
        int src_count = native_img->width * native_img->height;
        int copy_count = src_count < pixel_count ? src_count : pixel_count;
        for (int i = 0; i < copy_count; i++) {
            dst_data[i] = (jint)native_img->pixels[i];
        }
    } else if (src_pixels && src_pixels->length > 0 &&
               src_pixels->element_type == T_INT) {
        /* int[] source (e.g. another Image2D's pixel array) */
        int copy_count = src_pixels->length < pixel_count ? src_pixels->length : pixel_count;
        jint* dst_data = (jint*)array_data(pixels);
        jint* src_data = (jint*)array_data(src_pixels);
        for (int i = 0; i < copy_count; i++) {
            dst_data[i] = src_data[i];
        }
    } else if (src_pixels && src_pixels->length > 0 &&
               src_pixels->element_type == T_BYTE) {
        /* v14: byte[] source (game-created RGB/RGBA buffers). Interpret
         * according to the requested format instead of copying raw bytes
         * into int slots (the old code read the byte array as jint* and
         * produced garbage for the first quarter of the image). */
        jint* dst_data = (jint*)array_data(pixels);
        uint8_t* src_data = (uint8_t*)array_data(src_pixels);
        int cpp = (format == 100) ? 4 : (format == 99) ? 3 :
                  (format == 98) ? 2 : 1;  /* RGBA/RGB/LUM_ALPHA/other */
        int rows = height, cols = width;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                int sidx = (row * cols + col) * cpp;
                int didx = row * width + col;
                if (didx >= pixel_count) break;
                if (sidx + cpp > (int)src_pixels->length) continue;
                uint32_t out;
                switch (format) {
                case 99:  /* RGB */
                    out = 0xFF000000u | ((uint32_t)src_data[sidx] << 16) |
                          ((uint32_t)src_data[sidx + 1] << 8) | src_data[sidx + 2];
                    break;
                case 100: /* RGBA */
                    out = ((uint32_t)src_data[sidx + 3] << 24) |
                          ((uint32_t)src_data[sidx] << 16) |
                          ((uint32_t)src_data[sidx + 1] << 8) | src_data[sidx + 2];
                    break;
                case 98: { /* LUMINANCE_ALPHA */
                    uint32_t v = src_data[sidx];
                    out = ((uint32_t)src_data[sidx + 1] << 24) | (v << 16) | (v << 8) | v;
                    break; }
                case 97: { /* LUMINANCE */
                    uint32_t v = src_data[sidx];
                    out = 0xFF000000u | (v << 16) | (v << 8) | v;
                    break; }
                case 96: /* ALPHA */
                    out = ((uint32_t)src_data[sidx] << 24) | 0x00FFFFFFu;
                    break;
                default: /* Unknown format — opaque magenta so it is visible */
                    out = 0xFFFF00FFu;
                    break;
                }
                dst_data[didx] = (jint)out;
            }
        }
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "pixels", (JavaObject*)pixels);
    m3g_set_int_field(obj, "width", width);
    m3g_set_int_field(obj, "height", height);
    m3g_set_int_field(obj, "format", format);
    
    return NATIVE_RETURN_VOID();
}

/* Image2D.set(int x, int y, int width, int height, byte[] pixels) */
static JavaValue native_image2d_set(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    JavaArray* src = (JavaArray*)args[5].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get destination pixel array using helper functions */
    JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "pixels");
    int img_width = m3g_get_int_field(obj, "width", 0);
    int img_format = m3g_get_int_field(obj, "format", 99);
    
    if (!dst) return NATIVE_RETURN_VOID();
    
    uint8_t* src_data = (uint8_t*)array_data(src);
    uint32_t* dst_data = (uint32_t*)array_data(dst);
    
    /* v14 FIX: bytes-per-pixel depends on the Image2D format.
     * The old code ALWAYS assumed 4-byte RGBA and read the buffer with a
     * fixed stride — RGB (3 bytes/px), LUMINANCE, ALPHA and
     * LUMINANCE_ALPHA uploads were decoded with wrong offsets (broken
     * textures in Nescube and any game using non-RGBA mutable Image2D). */
    int cpp;
    switch (img_format) {
    case 100: cpp = 4; break;              /* RGBA */
    case 99:  cpp = 3; break;              /* RGB */
    case 98:  cpp = 2; break;              /* LUMINANCE_ALPHA */
    case 97:  cpp = 1; break;              /* LUMINANCE */
    case 96:  cpp = 1; break;              /* ALPHA */
    default:  cpp = 4; break;              /* Unknown — keep old behaviour */
    }
    
    /* Copy and convert to ARGB */
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) {
            int src_idx = (row * w + col) * cpp;
            int dst_idx = (y + row) * img_width + (x + col);
            
            if (dst_idx < 0 || dst_idx >= (int)dst->length) continue;
            if (src_idx + cpp > (int)src->length) continue;
            
            uint32_t out;
            switch (img_format) {
            case 99:  /* RGB — opaque */
                out = 0xFF000000u | ((uint32_t)src_data[src_idx] << 16) |
                      ((uint32_t)src_data[src_idx + 1] << 8) | src_data[src_idx + 2];
                break;
            case 100: /* RGBA */
                out = ((uint32_t)src_data[src_idx + 3] << 24) |
                      ((uint32_t)src_data[src_idx] << 16) |
                      ((uint32_t)src_data[src_idx + 1] << 8) | src_data[src_idx + 2];
                break;
            case 98: { /* LUMINANCE_ALPHA */
                uint32_t v = src_data[src_idx];
                out = ((uint32_t)src_data[src_idx + 1] << 24) | (v << 16) | (v << 8) | v;
                break; }
            case 97: { /* LUMINANCE — opaque */
                uint32_t v = src_data[src_idx];
                out = 0xFF000000u | (v << 16) | (v << 8) | v;
                break; }
            case 96: /* ALPHA — white RGB, alpha from data */
                out = ((uint32_t)src_data[src_idx] << 24) | 0x00FFFFFFu;
                break;
            default: /* Unknown — keep RGBA interpretation */
                out = 0xFF000000u | ((uint32_t)src_data[src_idx] << 16) |
                      ((uint32_t)src_data[src_idx + 1] << 8) | src_data[src_idx + 2];
                break;
            }
            dst_data[dst_idx] = out;
        }
    }
    
    /* v14: notify the texture cache that this Image2D's content changed so
     * cached M3GTexture2D instances built from it get refreshed (Nescube
     * updates its cube texture every frame via Image2D.set). */
    m3g_mark_image2d_updated(obj);
    
    GFX_DEBUG("Image2D.set: (%d,%d) %dx%d fmt=%d cpp=%d", x, y, w, h, img_format, cpp);
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Extended JSR 184 Implementation - Additional Features
 * ============================================================================ */

/* World.addChild(Node) */
static JavaValue native_world_addChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!world || !child) return NATIVE_RETURN_VOID();
    
    /* Get children array using helper function */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children) {
        /* Add child to array - find empty slot */
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j] == NULL) {
                arr[j] = child;
                GFX_DEBUG("World.addChild: added child %p at index %d", (void*)child, j);
                break;
            }
        }
        /* v10 FIX: keep childCount in sync (see Group.addChild comment). */
        {
            int n = 0;
            for (jsize j = 0; j < children->length; j++) if (arr[j]) n++;
            m3g_set_int_field(world, "childCount", n);
        }
    } else {
        /* No children array yet - create one */
        children = jvm_new_array(jvm, DESC_OBJECT, 16, NULL);
        if (children) {
            m3g_set_ref_field(world, "children", (JavaObject*)children);
            JavaObject** arr = (JavaObject**)array_data(children);
            arr[0] = child;
            m3g_set_int_field(world, "childCount", 1);  /* v10 FIX: maintain count */
            GFX_DEBUG("World.addChild: created children array, added child %p", (void*)child);
        }
    }
    
    /* Mark scene as set up for force-render detection */
    g_m3g_scene_setup_done = true;
    m3g_thread_fence();
    
    return NATIVE_RETURN_VOID();
}

/* World.setActiveCamera(Camera) */
static JavaValue native_world_setActiveCamera(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* camera = (JavaObject*)args[1].ref;
    
    if (world && camera) {
        m3g_set_ref_field(world, "activeCamera", camera);
        g_m3g_last_world = world;  /* Track last World for force-render */
        g_m3g_scene_setup_done = true;  /* Scene has been set up */
        m3g_thread_fence();
    }
    
    GFX_DEBUG("World.setActiveCamera: world=%p camera=%p", (void*)world, (void*)camera);
    return NATIVE_RETURN_VOID();
}

/* World.getActiveCamera() */
static JavaValue native_world_getActiveCamera(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    
    if (!world) return NATIVE_RETURN_NULL();
    
    /* Get active camera from World using helper function */
    JavaObject* camera = m3g_get_ref_field(world, "activeCamera");
    if (camera) {
        return NATIVE_RETURN_OBJECT(camera);
    }
    
    /* Try to find camera in children */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children && children->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j]) {
                JavaClass* child_class = arr[j]->header.clazz;
                if (child_class && child_class->class_name && 
                    strstr(child_class->class_name, "Camera")) {
                    return NATIVE_RETURN_OBJECT(arr[j]);
                }
            }
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* Helper: Recursively search for object with userID in scene graph */
static JavaObject* m3g_find_recursive(JavaObject* obj, jint user_id) {
    if (!obj) return NULL;

    /* Check if this object matches */
    jint obj_user_id = m3g_get_int_field(obj, "userID", -1);
    if (obj_user_id == user_id) {
        return obj;
    }

    /* Check if this is a Group (has children) - World extends Group */
    JavaClass* clazz = obj->header.clazz;
    if (!clazz || !clazz->class_name) return NULL;

    /* Group, World, and Mesh can have children */
    if (strstr(clazz->class_name, "Group") || strstr(clazz->class_name, "World")) {
        JavaArray* children = (JavaArray*)m3g_get_ref_field(obj, "children");
        if (children && children->element_type == DESC_OBJECT) {
            JavaObject** arr = (JavaObject**)array_data(children);
            for (jsize i = 0; i < children->length; i++) {
                if (arr[i]) {
                    JavaObject* found = m3g_find_recursive(arr[i], user_id);
                    if (found) return found;
                }
            }
        }
    }

    return NULL;
}

/* v12: Object3D.getReferences(Object3D[]) — JSR-184 scene-graph traversal.
 * Games use it to enumerate/prune scene branches; the missing native made
 * such traversals see nothing (SU-30). Generic implementation: collect all
 * non-null fields whose values are M3G objects. Passing null returns the
 * count (the documented way to size the array). */
static bool m3g_is_m3g_object(JavaObject* o) {
    /* v15 CRITICAL FIX: getReferences() walks RAW field slots — many of
     * them hold raw ints/floats (handles, sizes), not references.
     * Dereferencing such a value as an object crashed SU-30 (SEGV on
     * address 0x66). Validate liveness via the GC header first. */
    if (!o || !heap_java_object_valid(o)) return false;
    JavaClass* c = o->header.clazz;
    return c && c->class_name &&
           strncmp(c->class_name, "javax/microedition/m3g/", 23) == 0;
}

static JavaValue native_object3d_getReferences(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* out_arr = (JavaArray*)args[1].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    
    JavaObject* refs[64];
    int count = 0;
    
    /* Walk every instance slot; any reference to an M3G object is a
     * component reference (children, buffers, appearances, images...). */
    JavaClass* clazz = obj->header.clazz;
    if (clazz && clazz->instance_size > sizeof(ObjectHeader)) {
        int max_slots = (int)((clazz->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue));
        if (max_slots > 256) max_slots = 256;
        for (int s = 0; s < max_slots && count < 64; s++) {
            JavaObject* r = (JavaObject*)obj->fields[s].ref;
            if (m3g_is_m3g_object(r) && r != obj) {
                refs[count++] = r;
            }
        }
    }
    
    if (!out_arr) return NATIVE_RETURN_INT(count);
    
    int fill = count;
    if ((int)out_arr->length < fill) fill = (int)out_arr->length;
    JavaObject** dst = (JavaObject**)array_data(out_arr);
    for (int i = 0; i < fill; i++) dst[i] = refs[i];
    return NATIVE_RETURN_INT(fill);
}

/* Object3D.find(int userID) */
static JavaValue native_object3d_find(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint user_id = args[1].i;

    if (!obj) return NATIVE_RETURN_NULL();

    GFX_DEBUG("Object3D.find: searching for userID=%d", user_id);
    fprintf(stderr, "[M3G-FIND] searching userID=%d in obj=%p (registry has %d objects)\n",
            user_id, (void*)obj, g_m3g_registry.count);

    /* Recursively search this object and its children */
    JavaObject* found = m3g_find_recursive(obj, user_id);
    if (found) {
        fprintf(stderr, "[M3G-FIND] found userID=%d at %p (recursive)\n", user_id, (void*)found);
        return NATIVE_RETURN_OBJECT(found);
    }

    /* Fallback: search in global registry */
    found = m3g_registry_find(user_id);
    if (found) {
        fprintf(stderr, "[M3G-FIND] found userID=%d at %p (registry)\n", user_id, (void*)found);
        return NATIVE_RETURN_OBJECT(found);
    }

    fprintf(stderr, "[M3G-FIND] userID=%d NOT FOUND\n", user_id);
    return NATIVE_RETURN_NULL();
}

/* Object3D.getUserID() */
static JavaValue native_object3d_getUserID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_INT(0);
    
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "userID", 0));
}

/* Object3D.setUserID(int id) */
static JavaValue native_object3d_setUserID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint user_id = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_userID(obj, user_id);
    
    GFX_DEBUG("Object3D.setUserID: %d", user_id);
    return NATIVE_RETURN_VOID();
}

/* Object3D.duplicate() - creates a copy of the object */
static JavaValue native_object3d_duplicate(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        GFX_DEBUG("Object3D.duplicate: null object");
        return NATIVE_RETURN_NULL();
    }
    
    GFX_DEBUG("Object3D.duplicate: duplicating %p", (void*)obj);
    
    /* For simplicity, return the same object (shallow copy) */
    /* A full implementation would create a deep copy */
    return NATIVE_RETURN_OBJECT(obj);
}

/* Node.getTransform(Transform) */
static JavaValue native_node_getTransform(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    
    if (!node || !transform) return NATIVE_RETURN_VOID();
    
    /* Copy node's transform to the provided Transform object using helper functions */
    JavaArray* node_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (node_arr && node_arr->element_type == T_FLOAT) {
        float* node_matrix = (float*)array_data(node_arr);
        
        JavaArray* trans_arr = (JavaArray*)m3g_get_ref_field(transform, "matrix");
        if (trans_arr && trans_arr->element_type == T_FLOAT) {
            float* trans_matrix = (float*)array_data(trans_arr);
            memcpy(trans_matrix, node_matrix, 16 * sizeof(float));
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Node.setTransform(Transform) */
static JavaValue native_node_setTransform(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    
    if (!node || !transform) return NATIVE_RETURN_VOID();
    
    /* Copy transform to node's transform field */
    M3GTransform* t = get_native_transform(transform);
    if (!t) return NATIVE_RETURN_VOID();
    
    JavaArray* node_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (node_arr && node_arr->element_type == T_FLOAT) {
        float* node_matrix = (float*)array_data(node_arr);
        memcpy(node_matrix, t->m, 16 * sizeof(float));
    }
    
    GFX_DEBUG("Node.setTransform");
    return NATIVE_RETURN_VOID();
}

/* Node.setAlphaFactor(float factor) */
static JavaValue native_node_setAlphaFactor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    float factor = args[1].f;
    
    if (!node) return NATIVE_RETURN_VOID();
    
    m3g_set_float_field(node, "alphaFactor", factor);
    
    GFX_DEBUG("Node.setAlphaFactor: %.2f", factor);
    return NATIVE_RETURN_VOID();
}

/* Group.addChild(Node) */
static JavaValue native_group_addChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!group || !child) return NATIVE_RETURN_VOID();
    
    /* Validate that child is actually a Node subclass */
    if (!child->header.clazz || !child->header.clazz->class_name) return NATIVE_RETURN_VOID();
    
    int children_slot = m3g_find_field_slot(group, "children");
    fprintf(stderr, "[M3G-ADDCHILD] Group %p class=%s, children_slot=%d, instance_size=%zu\n",
            (void*)group, 
            group->header.clazz ? group->header.clazz->class_name : "?",
            children_slot,
            group->header.clazz ? group->header.clazz->instance_size : 0);
    JavaArray* children = (JavaArray*)m3g_get_ref_field(group, "children");
    if (children && children->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(children);
        /* Find empty slot */
        int added = 0;
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j] == NULL) {
                arr[j] = child;
                added = 1;
                GFX_DEBUG("Group.addChild: added child %p at index %d (class=%s)",
                         (void*)child, j,
                         group->header.clazz ? group->header.clazz->class_name : "?");
                break;
            }
        }
        /* If no empty slot found, expand the array */
        if (!added && children->length < 256) {
            jsize new_len = children->length * 2;
            if (new_len > 256) new_len = 256;
            JavaArray* new_children = jvm_new_array(jvm, DESC_OBJECT, new_len, NULL);
            if (new_children) {
                JavaObject** new_arr = (JavaObject**)array_data(new_children);
                /* Copy existing children */
                for (jsize j = 0; j < children->length; j++) {
                    new_arr[j] = arr[j];
                }
                /* Add new child at the end */
                new_arr[children->length] = child;
                m3g_set_ref_field(group, "children", (JavaObject*)new_children);
                GFX_DEBUG("Group.addChild: expanded array %d->%d, added child %p at index %d",
                         (int)children->length, (int)new_len, (void*)child, (int)children->length);
            }
        }
    } else {
        /* No children array yet - create one */
        children = jvm_new_array(jvm, DESC_OBJECT, 16, NULL);
        if (children) {
            m3g_set_ref_field(group, "children", (JavaObject*)children);
            JavaObject** arr = (JavaObject**)array_data(children);
            arr[0] = child;
            GFX_DEBUG("Group.addChild: created children array, added child %p at index 0", (void*)child);
        }
    }
    
    /* v10 FIX: keep the childCount field in sync with the array contents.
     * It was never maintained, so game-built scenes reported childCount=0
     * while children existed — every childCount-limited reader saw an
     * empty scene (SU-30 rendered nothing from its World). */
    {
        JavaArray* ch = (JavaArray*)m3g_get_ref_field(group, "children");
        if (ch && ch->element_type == DESC_OBJECT) {
            JavaObject** a = (JavaObject**)array_data(ch);
            int n = 0;
            for (jsize j = 0; j < ch->length; j++) if (a[j]) n++;
            m3g_set_int_field(group, "childCount", n);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Group.removeChild(Node) */
static JavaValue native_group_removeChild(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!group || !child) return NATIVE_RETURN_VOID();
    
    /* FIX: Use m3g_get_ref_field instead of wrong clazz->fields[i] access */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(group, "children");
    if (children && children->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j] == child) {
                arr[j] = NULL;
                GFX_DEBUG("Group.removeChild: removed child at index %d", j);
                break;
            }
        }
        /* v10 FIX: keep childCount in sync (see Group.addChild comment). */
        {
            int n = 0;
            for (jsize j = 0; j < children->length; j++) if (arr[j]) n++;
            m3g_set_int_field(group, "childCount", n);
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Group.getChildCount() */
static JavaValue native_group_getChildCount(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    
    if (!group) return NATIVE_RETURN_INT(0);
    
    JavaArray* children = (JavaArray*)m3g_get_ref_field(group, "children");
    if (children && children->element_type == DESC_OBJECT) {
        /* Count non-null children */
        JavaObject** arr = (JavaObject**)array_data(children);
        int count = 0;
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j]) count++;
        }
        return NATIVE_RETURN_INT(count);
    }
    
    return NATIVE_RETURN_INT(0);
}

/* Group.getChild(int index) */
static JavaValue native_group_getChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    if (!group || index < 0) return NATIVE_RETURN_NULL();
    
    /* FIX: Use m3g_get_ref_field instead of wrong clazz->fields[i] access */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(group, "children");
    if (children && children->element_type == DESC_OBJECT && index < (jint)children->length) {
        JavaObject** arr = (JavaObject**)array_data(children);
        return NATIVE_RETURN_OBJECT(arr[index]);
    }
    
    return NATIVE_RETURN_NULL();
}

/* CompositingMode.setBlending(int mode) */
static JavaValue native_compositingmode_setBlending(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "blending") == 0) {
            obj->fields[i].i = mode;
            break;
        }
    }
    
    GFX_DEBUG("CompositingMode.setBlending: %d", mode);
    return NATIVE_RETURN_VOID();
}

/* v23: CompositingMode.setAlphaWriteEnable(boolean) — JSR-184 §CompositingMode.
 * The rasterizer already honors the field (alpha_write in M3GAppearance). */
static JavaValue native_compositingmode_setAlphaWriteEnable(JVM* jvm, JavaThread* thread,
                                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint enable = args[1].i ? 1 : 0;

    if (obj) {
        m3g_set_int_field(obj, "alphaWrite", enable);
    }

    GFX_DEBUG("CompositingMode.setAlphaWriteEnable: %d", enable);
    return NATIVE_RETURN_VOID();
}

/* v23: CompositingMode.setColorWriteEnable(boolean) */
static JavaValue native_compositingmode_setColorWriteEnable(JVM* jvm, JavaThread* thread,
                                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint enable = args[1].i ? 1 : 0;

    if (obj) {
        m3g_set_int_field(obj, "colorWrite", enable);
    }

    GFX_DEBUG("CompositingMode.setColorWriteEnable: %d", enable);
    return NATIVE_RETURN_VOID();
}

/* v23: CompositingMode.setDithering(boolean) — stored; the software
 * rasterizer does not dither, the field is kept for parity. */
static JavaValue native_compositingmode_setDithering(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint enable = args[1].i ? 1 : 0;

    if (obj) {
        m3g_set_int_field(obj, "dithering", enable);
    }

    GFX_DEBUG("CompositingMode.setDithering: %d", enable);
    return NATIVE_RETURN_VOID();
}

/* v23b: CompositingMode.<init>() — the interrupted session added the stub
 * fields but never the constructor native, so every API-created
 * CompositingMode had ZERO fields: blending=0 was mapped to REPLACE (no
 * blending — M3GTest scene 4/7 showed two opaque rectangles instead of
 * semi-transparent textures), and the write masks read 0. */
static JavaValue native_compositingmode_init(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (obj) {
        /* JSR-184 §CompositingMode() defaults */
        m3g_set_int_field(obj, "blending", 64);       /* ALPHA */
        m3g_set_int_field(obj, "depthTest", 1);
        m3g_set_int_field(obj, "depthWrite", 1);
        m3g_set_int_field(obj, "alphaWrite", 1);
        m3g_set_int_field(obj, "colorWrite", 1);
        m3g_set_int_field(obj, "dithering", 1);
        m3g_set_float_field(obj, "alphaThreshold", 0.0f);
    }
    return NATIVE_RETURN_VOID();
}

/* v23b: PolygonMode.<init>() — spec defaults */
static JavaValue native_polygonmode_init(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (obj) {
        m3g_set_int_field(obj, "culling", 161);   /* CULL_BACK */
        m3g_set_int_field(obj, "shading", 165);   /* SHADE_SMOOTH */
        m3g_set_int_field(obj, "winding", 168);   /* WINDING_CW */
    }
    return NATIVE_RETURN_VOID();
}

/* PolygonMode.setCulling(int mode) */
static JavaValue native_polygonmode_setCulling(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    g_m3g.culling_enabled = (mode != 0);
    
    GFX_DEBUG("PolygonMode.setCulling: %d", mode);
    return NATIVE_RETURN_VOID();
}

/* Mesh.setVertexBuffer(int index, VertexArray) */
static JavaValue native_mesh_setVertexBuffer(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* mesh = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* va = (JavaObject*)args[2].ref;
    
    if (!mesh) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = mesh->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "vertexBuffers") == 0) {
            JavaArray* buffers = (JavaArray*)mesh->fields[i].ref;
            if (buffers && buffers->element_type == DESC_OBJECT && index >= 0 && index < (jint)buffers->length) {
                JavaObject** arr = (JavaObject**)array_data(buffers);
                arr[index] = va;
            }
            break;
        }
    }
    
    GFX_DEBUG("Mesh.setVertexBuffer: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* Camera.lookAt(float x, float y, float z, float atX, float atY, float atZ, float upX, float upY, float upZ) */
static JavaValue native_camera_lookAt(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float eye_x = args[1].f;
    float eye_y = args[2].f;
    float eye_z = args[3].f;
    float at_x = args[4].f;
    float at_y = args[5].f;
    float at_z = args[6].f;
    float up_x = args[7].f;
    float up_y = args[8].f;
    float up_z = args[9].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Update modelview matrix */
    m3g_transform_look_at(&g_m3g.modelview, eye_x, eye_y, eye_z, at_x, at_y, at_z, up_x, up_y, up_z);
    
    GFX_DEBUG("Camera.lookAt: eye=(%.2f,%.2f,%.2f), at=(%.2f,%.2f,%.2f)", 
            eye_x, eye_y, eye_z, at_x, at_y, at_z);
    return NATIVE_RETURN_VOID();
}

/* M3G file format constants */
#define M3G_MAGIC1 0xAB
#define M3G_MAGIC2 0xBB
#define M3G_VERSION_MIN 2
#define M3G_VERSION_MAX 3

/* M3G object type codes (from JSR-184 specification) */
#define M3G_OBJ_HEADER              0
#define M3G_OBJ_ANIMATIONCONTROLLER 1
#define M3G_OBJ_ANIMATIONTRACK      2
#define M3G_OBJ_APPEARANCE          3
#define M3G_OBJ_BACKGROUND          4
#define M3G_OBJ_CAMERA              5
#define M3G_OBJ_COMPOSITINGMODE     6
#define M3G_OBJ_FOG                 7
#define M3G_OBJ_POLYGONMODE         8
#define M3G_OBJ_GROUP               9
#define M3G_OBJ_IMAGE2D             10
#define M3G_OBJ_TRIANGLESTRIPARRAY  11   /* IndexBuffer */
#define M3G_OBJ_LIGHT               12
#define M3G_OBJ_MATERIAL            13
#define M3G_OBJ_MESH                14
#define M3G_OBJ_MORPHINGMESH        15
#define M3G_OBJ_SKINNEDMESH         16
#define M3G_OBJ_TEXTURE2D           17
#define M3G_OBJ_SPRITE3D            18
#define M3G_OBJ_KEYFRAMESEQUENCE    19
#define M3G_OBJ_VERTEXARRAY         20
#define M3G_OBJ_VERTEXBUFFER        21
#define M3G_OBJ_WORLD               22
#define M3G_OBJ_EXTERNALREF         255

#include "miniz.h"  /* Use miniz for zlib decompression - single file implementation */

/* Helper: Parse M3G file and extract objects */
/* M3G reference system: ref 0 = null, ref N = objects[N] (direct index)
 * Objects are stored at their file position (0=header, 1=first object, etc.)
 * This preserves reference indices for correct linking.
 */
typedef struct {
    JavaObject** objects;      /* Objects stored at file position index */
    int object_count;          /* Number of objects stored */
    int object_capacity;       /* Capacity of objects array */
    JavaObject* world;
    JavaObject* camera;
    JavaObject* background;
    JavaObject* light;
    int external_links;        /* Header flag */
    int current_section;       /* Current section number */
    int header_seen;           /* Track if header was already parsed */
    int objects_start_index;   /* Starting index for objects (after header) */
    /* Temporary storage for parsing - used during linking */
    JavaObject* mesh;
    JavaObject* vertex_buffer;
    JavaObject* index_buffer;
    JavaObject* appearance;
    /* v14: animation track linkage requests collected from Object3D headers
     * (track refs are back-resolved after the whole file is parsed) */
    struct { JavaObject* target; uint32_t track_ref; } *track_links;
    int track_link_count;
    int track_link_capacity;
} M3GParseContext;

/* Decompress zlib data - FIX: Use two-pass approach to determine exact size */
static uint8_t* m3g_decompress(const uint8_t* data, size_t data_size, size_t* out_size) {
    if (!data || data_size < 2) return NULL;

    /* Check for zlib header (0x78 0x9C or similar) */
    if (data[0] != 0x78 || (data[1] != 0x9C && data[1] != 0xDA && data[1] != 0x01)) {
        /* Not compressed, return copy */
        GFX_DEBUG("M3G: Data not zlib compressed, returning copy");
        uint8_t* result = malloc(data_size);
        if (result) {
            memcpy(result, data, data_size);
            *out_size = data_size;
        }
        return result;
    }

    GFX_DEBUG("M3G: Decompressing zlib data, input size=%zu", data_size);

    z_stream strm;
    memset(&strm, 0, sizeof(strm));

    if (inflateInit(&strm) != Z_OK) {
        GFX_DEBUG("M3G: inflateInit failed");
        return NULL;
    }

    strm.next_in = (Bytef*)data;
    strm.avail_in = data_size;

    /* FIX: Two-pass decompression - first determine exact size needed */
    /* Use a small stack buffer for the first pass to estimate size */
    #define PROBE_BUF_SIZE 4096
    uint8_t probe_buf[PROBE_BUF_SIZE];
    size_t total_out_estimate = 0;
    
    /* First pass: decompress in chunks to count total output size */
    int ret = Z_OK;
    while (ret == Z_OK) {
        strm.next_out = probe_buf;
        strm.avail_out = PROBE_BUF_SIZE;
        ret = inflate(&strm, Z_NO_FLUSH);
        if (ret == Z_OK || ret == Z_STREAM_END) {
            total_out_estimate += (PROBE_BUF_SIZE - strm.avail_out);
        }
    }
    
    if (ret != Z_STREAM_END) {
        GFX_DEBUG("M3G: First pass inflate failed with code %d", ret);
        inflateEnd(&strm);
        return NULL;
    }
    
    *out_size = strm.total_out;
    inflateEnd(&strm);
    
    /* Sanity check: reject unreasonably large decompressed output.
     * M3G files for J2ME are typically < 2MB; anything > 64MB is certainly corrupt. */
    #define M3G_MAX_DECOMPRESSED_SIZE (64 * 1024 * 1024)
    if (*out_size == 0 || *out_size > M3G_MAX_DECOMPRESSED_SIZE) {
        GFX_DEBUG("M3G: Decompressed size %zu is out of range (max=%d)", *out_size, M3G_MAX_DECOMPRESSED_SIZE);
        return NULL;
    }
    
    GFX_DEBUG("M3G: First pass complete, exact output size=%zu bytes", *out_size);

    /* Second pass: allocate exact size and decompress */
    uint8_t* result = malloc(*out_size);
    if (!result) {
        GFX_DEBUG("M3G: Failed to allocate exact buffer of %zu bytes", *out_size);
        return NULL;
    }

    /* Reinitialize for second pass */
    memset(&strm, 0, sizeof(strm));
    if (inflateInit(&strm) != Z_OK) {
        GFX_DEBUG("M3G: inflateInit failed on second pass");
        free(result);
        return NULL;
    }

    strm.next_in = (Bytef*)data;
    strm.avail_in = data_size;
    strm.next_out = result;
    strm.avail_out = *out_size;

    ret = inflate(&strm, Z_FINISH);
    if (ret != Z_STREAM_END && ret != Z_OK) {
        GFX_DEBUG("M3G: Second pass inflate failed with code %d", ret);
        inflateEnd(&strm);
        free(result);
        return NULL;
    }

    inflateEnd(&strm);
    GFX_DEBUG("M3G: Successfully decompressed %zu bytes to %zu bytes", data_size, *out_size);
    
    return result;
}

/* Align position to 4-byte boundary per M3G spec (JSR-184 §6.2.1):
 * "All data fields that are 2 or more bytes in size are aligned to
 *  4-byte boundaries. If the current byte position is not a multiple
 *  of 4 at the start of reading a field of 2 or more bytes, 1-3
 *  zero padding bytes are inserted."
 * NOTE: The object type (1 byte) + length (4 bytes) at the start of
 * each M3G object are NOT aligned (packed as 5 bytes total). Alignment
 * only applies WITHIN each object's data, after those 5 header bytes.
 */
#define M3G_ALIGN4(pos) do { *(pos) = (*(pos) + 3) & ~(size_t)3; } while(0)

/* Read a 32-bit little-endian value (NO auto-align — caller must align if needed) */
static uint32_t m3g_read_u32(const uint8_t* data, size_t* pos, size_t max) {
    if (*pos + 4 > max) return 0;
    uint32_t val = data[*pos] | (data[*pos+1] << 8) | (data[*pos+2] << 16) | ((uint32_t)(data[*pos+3]) <<  24);
    *pos += 4;
    return val;
}

/* Read a 16-bit little-endian value (NO auto-align — caller must align if needed) */
static uint16_t m3g_read_u16(const uint8_t* data, size_t* pos, size_t max) {
    if (*pos + 2 > max) return 0;
    uint16_t val = data[*pos] | (data[*pos+1] << 8);
    *pos += 2;
    return val;
}

/* Read a byte (NO alignment — u8 fields are 1 byte) */
static uint8_t m3g_read_u8(const uint8_t* data, size_t* pos, size_t max) {
    if (*pos >= max) return 0;
    return data[(*pos)++];
}

/* Read a float (32-bit IEEE 754, NO auto-align — caller must align if needed) */
static float m3g_read_float(const uint8_t* data, size_t* pos, size_t max) {
    union { uint32_t i; float f; } u;
    u.i = m3g_read_u32(data, pos, max);
    return u.f;
}

/* ============================================================================
 * M3G Object Data Reading Helpers (per JSR-184 spec)
 * ============================================================================ */

/* Skip Object3D base data: userID already read, then animationTrackCount + refs, userObjectCount + data */
__attribute__((unused))
static void m3g_skip_object3d_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* Animation tracks count and references */
    uint32_t track_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < track_count; i++) {
        m3g_read_u32(data, pos, data_size);  /* Skip track reference */
    }

    /* User object count and data */
    uint32_t user_object_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < user_object_count; i++) {
        uint32_t key = m3g_read_u32(data, pos, data_size);
        (void)key;
        uint32_t value_len = m3g_read_u32(data, pos, data_size);
        *pos += value_len;  /* Skip value bytes */
    }
}

/* Skip Transformable data after Object3D data */
__attribute__((unused))
static void m3g_skip_transformable_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* hasComponentTransform (boolean) */
    uint8_t has_component = m3g_read_u8(data, pos, data_size);
    if (has_component) {
        M3G_ALIGN4(pos);
        /* translation: 3 floats */
        *pos += 12;
        /* scale: 3 floats */
        *pos += 12;
        /* orientation: angle + 3 axis floats */
        *pos += 16;
    }

    /* hasGeneralTransform (boolean) */
    uint8_t has_general = m3g_read_u8(data, pos, data_size);
    if (has_general) {
        /* 4x4 matrix = 16 floats = 64 bytes */
        *pos += 64;
    }
}

/* Skip Node data after Transformable data */
__attribute__((unused))
static void m3g_skip_node_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* renderingEnable (boolean) */
    m3g_read_u8(data, pos, data_size);
    /* pickingEnable (boolean) */
    m3g_read_u8(data, pos, data_size);
    /* alphaFactor (byte) */
    m3g_read_u8(data, pos, data_size);
    /* scope (uint32) */
    m3g_read_u32(data, pos, data_size);

    /* hasAlignment (boolean) */
    uint8_t has_alignment = m3g_read_u8(data, pos, data_size);
    if (has_alignment) {
        /* alignmentTarget for Z, Y */
        m3g_read_u8(data, pos, data_size);
        m3g_read_u8(data, pos, data_size);
        /* reference indices */
        m3g_read_u32(data, pos, data_size);
        m3g_read_u32(data, pos, data_size);
    }
}

/* Skip Group data after Node data */
__attribute__((unused))
static void m3g_skip_group_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* child count */
    uint32_t child_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < child_count; i++) {
        m3g_read_u32(data, pos, data_size);  /* Skip child reference */
    }
}

/* Read and store Object3D data, return userID */
static uint32_t m3g_read_object3d_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos, M3GParseContext* ctx) {
    /* userID already read by caller */
    uint32_t user_id = 0;  /* Caller should pass this */

    /* Animation tracks count and references.
     * v14 FIX: the track references used to be read and DISCARDED, so
     * animation data inside M3G files (every game's cut-scenes / unit
     * animations / M3GTest scene 7) never reached the scene graph. Record
     * (target, track_ref) pairs and resolve them after parsing. */
    uint32_t track_count = m3g_read_u32(data, pos, data_size);
    fprintf(stderr, "[M3G-O3D] obj=%p pos=%zu track_count=%u\n", (void*)obj, *pos - 4, track_count);
    if (track_count > 0 && track_count < 4096 && ctx) {
        if (ctx->track_link_count + (int)track_count > ctx->track_link_capacity) {
            int new_cap = ctx->track_link_capacity ? ctx->track_link_capacity * 2 : 64;
            while (new_cap < ctx->track_link_count + (int)track_count) new_cap *= 2;
            void* np = realloc(ctx->track_links, (size_t)new_cap * sizeof(*ctx->track_links));
            if (np) {
                ctx->track_links = np;
                ctx->track_link_capacity = new_cap;
            }
        }
    }
    for (uint32_t i = 0; i < track_count; i++) {
        uint32_t tref = m3g_read_u32(data, pos, data_size);
        if (tref > 0 && ctx && ctx->track_links &&
            ctx->track_link_count < ctx->track_link_capacity) {
            ctx->track_links[ctx->track_link_count].target = obj;
            ctx->track_links[ctx->track_link_count].track_ref = tref;
            ctx->track_link_count++;
        }
    }

    /* User object count and data */
    uint32_t user_object_count = m3g_read_u32(data, pos, data_size);
    fprintf(stderr, "[M3G-O3D] obj=%p pos=%zu user_obj_count=%u\n", (void*)obj, *pos - 4, user_object_count);
    for (uint32_t i = 0; i < user_object_count; i++) {
        uint32_t key = m3g_read_u32(data, pos, data_size);
        (void)key;
        uint32_t value_len = m3g_read_u32(data, pos, data_size);
        *pos += value_len;
    }

    return user_id;
}

/* Read Transformable data after Object3D data */
static void m3g_read_transformable_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos, JVM* jvm) {
    /* hasComponentTransform (boolean) */
    uint8_t has_component = m3g_read_u8(data, pos, data_size);
    if (has_component) {
        /* translation: 3 floats */
        float tx = m3g_read_float(data, pos, data_size);
        float ty = m3g_read_float(data, pos, data_size);
        float tz = m3g_read_float(data, pos, data_size);
        /* scale: 3 floats */
        float sx = m3g_read_float(data, pos, data_size);
        float sy = m3g_read_float(data, pos, data_size);
        float sz = m3g_read_float(data, pos, data_size);
        /* orientation: angle + 3 axis floats */
        float angle = m3g_read_float(data, pos, data_size);
        float ax = m3g_read_float(data, pos, data_size);
        float ay = m3g_read_float(data, pos, data_size);
        float az = m3g_read_float(data, pos, data_size);

        /* Store transform data */
        m3g_set_float_field(obj, "translationX", tx);
        m3g_set_float_field(obj, "translationY", ty);
        m3g_set_float_field(obj, "translationZ", tz);
        m3g_set_float_field(obj, "scaleX", sx);
        m3g_set_float_field(obj, "scaleY", sy);
        m3g_set_float_field(obj, "scaleZ", sz);
        m3g_set_float_field(obj, "orientationAngle", angle);
        m3g_set_float_field(obj, "orientationX", ax);
        m3g_set_float_field(obj, "orientationY", ay);
        m3g_set_float_field(obj, "orientationZ", az);

        GFX_DEBUG("M3G: Transform tx=%.2f ty=%.2f tz=%.2f sx=%.2f sy=%.2f sz=%.2f",
                 tx, ty, tz, sx, sy, sz);
    }

    /* hasGeneralTransform (boolean) */
    uint8_t has_general = m3g_read_u8(data, pos, data_size);
    if (has_general) {
        /* 4x4 matrix = 16 floats = 64 bytes */
        /* Store in transform matrix field */
        JavaArray* matrix = jvm_new_array(jvm, T_FLOAT, 16, NULL);
        if (matrix) {
            float* m = (float*)array_data(matrix);
            for (int i = 0; i < 16; i++) {
                m[i] = m3g_read_float(data, pos, data_size);
            }
            m3g_set_ref_field(obj, "transform", (JavaObject*)matrix);
        } else {
            *pos += 64;  /* Skip if can't allocate */
        }
    }
}

/* Read Node data after Transformable data */
static void m3g_read_node_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos) {
    /* renderingEnable (boolean) */
    uint8_t rendering_enable = m3g_read_u8(data, pos, data_size);
    m3g_set_int_field(obj, "renderingEnable", rendering_enable);

    /* pickingEnable (boolean) */
    uint8_t picking_enable = m3g_read_u8(data, pos, data_size);
    m3g_set_int_field(obj, "pickingEnable", picking_enable);

    /* alphaFactor (byte) - stored as float 0.0-1.0 */
    uint8_t alpha_factor = m3g_read_u8(data, pos, data_size);
    m3g_set_float_field(obj, "alphaFactor", alpha_factor / 255.0f);

    /* scope (uint32) */
    uint32_t scope = m3g_read_u32(data, pos, data_size);
    m3g_set_int_field(obj, "scope", scope);

    /* hasAlignment (boolean) */
    uint8_t has_alignment = m3g_read_u8(data, pos, data_size);
    if (has_alignment) {
        /* Skip alignment for now */
        m3g_read_u8(data, pos, data_size);  /* zTarget */
        m3g_read_u8(data, pos, data_size);  /* yTarget */
        m3g_read_u32(data, pos, data_size); /* zReference */
        m3g_read_u32(data, pos, data_size); /* yReference */
    }

    GFX_DEBUG("M3G: Node rendering=%d picking=%d alpha=%.2f scope=%u",
             rendering_enable, picking_enable, alpha_factor / 255.0f, scope);
}

/* Read Group data after Node data, store child refs for later linking */
static void m3g_read_group_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos, JVM* jvm) {
    /* child count */
    uint32_t child_count = m3g_read_u32(data, pos, data_size);

    /* Store child count for linking */
    m3g_set_int_field(obj, "childCount", child_count);

    /* Create children array to store refs temporarily */
    if (child_count > 0) {
        JavaArray* child_refs = jvm_new_array(jvm, T_INT, child_count, NULL);
        if (child_refs) {
            jint* refs = (jint*)array_data(child_refs);
            for (uint32_t i = 0; i < child_count; i++) {
                refs[i] = (jint)m3g_read_u32(data, pos, data_size);
            }
            /* Store _childRefs — try by name first, then use direct slot */
            int slot = m3g_find_field_slot(obj, "_childRefs");
            if (slot >= 0) {
                obj->fields[slot].ref = (JavaObject*)child_refs;
                fprintf(stderr, "[M3G] Group %p: stored _childRefs[%d] at slot %d\n",
                        (void*)obj, child_count, slot);
            } else {
                /* Fallback: try slot 19 (_childRefs is 3rd Group field: children=17, childCount=18, _childRefs=19) */
                int max_slots = (obj->header.clazz->instance_size - (int)sizeof(ObjectHeader)) / (int)sizeof(JavaValue);
                fprintf(stderr, "[M3G] Group %p: _childRefs NOT FOUND by name, max_slots=%d, trying slot 19\n",
                        (void*)obj, max_slots);
                if (max_slots > 19) {
                    obj->fields[19].ref = (JavaObject*)child_refs;
                    fprintf(stderr, "[M3G] Group %p: stored _childRefs at fallback slot 19\n", (void*)obj);
                } else {
                    /* Last resort: store on children slot and use childCount to distinguish */
                    fprintf(stderr, "[M3G] Group %p: max_slots=%d too small for _childRefs!\n", (void*)obj, max_slots);
                }
            }
        }
    }

    fprintf(stderr, "[M3G] Group %p childCount=%u\n", (void*)obj, child_count);
}

/* Parse a single M3G object (obj_type already read, read data only) */
/* Returns object or NULL (for unimplemented/failed parsing) */
/* Objects are stored at their file position index; reference N = objects[N] */
static JavaObject* m3g_parse_object(JVM* jvm, M3GParseContext* ctx,
                                    const uint8_t* data, size_t data_size,
                                    size_t* pos, uint8_t obj_type, uint32_t obj_length) {
    if (*pos >= data_size) return NULL;

    (void)obj_length;  /* Used by caller to skip; read by KF layout detect below */
    GFX_DEBUG("M3G: Parsing object type=%d at pos=%zu", obj_type, *pos);

    /* Read userID first - ALL M3G objects start with this (4 bytes) */
    uint32_t user_id = m3g_read_u32(data, pos, data_size);
    GFX_DEBUG("M3G: Object type=%d userID=%u", obj_type, user_id);

    switch (obj_type) {
        case M3G_OBJ_HEADER: {
            /* Header object - version info (already read in section parsing) */
            /* Skip rest of header - it was already processed */
            GFX_DEBUG("M3G: Header object (internal, not stored)");
            return NULL;  /* Header is NOT stored in objects array */
        }

        /* =================================================================
         * v14: FILE ANIMATION OBJECTS — previously skipped entirely, so any
         * animation stored in an .m3g file (M3GTest scene 7, game cut-scenes)
         * was silently dropped and animated scenes collapsed to their
         * authored (usually origin) transforms.
         * ================================================================= */
        case M3G_OBJ_ANIMATIONCONTROLLER: {
            JavaClass* ac_class = jvm_load_class(jvm, "javax/microedition/m3g/AnimationController");
            if (!ac_class) return NULL;
            JavaObject* ctrl = jvm_new_object(jvm, ac_class);
            if (!ctrl) return NULL;
            m3g_set_userID(ctrl, user_id);
            m3g_read_object3d_data(ctrl, data, data_size, pos, ctx);
            float speed = m3g_read_float(data, pos, data_size);
            float weight = m3g_read_float(data, pos, data_size);
            int32_t act_start = (int32_t)m3g_read_u32(data, pos, data_size);
            int32_t act_end = (int32_t)m3g_read_u32(data, pos, data_size);
            float ref_seq = m3g_read_float(data, pos, data_size);
            int32_t ref_world = (int32_t)m3g_read_u32(data, pos, data_size);
            m3g_set_float_field(ctrl, "speed", speed);
            m3g_set_float_field(ctrl, "weight", weight);
            m3g_set_int_field(ctrl, "activationTime", act_start);
            m3g_set_int_field(ctrl, "deactivationTime", act_end);
            m3g_set_float_field(ctrl, "refSequenceTime", ref_seq);
            m3g_set_int_field(ctrl, "refWorldTime", ref_world);
            fprintf(stderr, "[M3G-ANIM] AnimationController userID=%u speed=%.2f weight=%.2f interval=[%d,%d)\n",
                    user_id, speed, weight, act_start, act_end);
            return ctrl;
        }

        case M3G_OBJ_ANIMATIONTRACK: {
            JavaClass* at_class = jvm_load_class(jvm, "javax/microedition/m3g/AnimationTrack");
            if (!at_class) return NULL;
            JavaObject* track = jvm_new_object(jvm, at_class);
            if (!track) return NULL;
            m3g_set_userID(track, user_id);
            m3g_read_object3d_data(track, data, data_size, pos, ctx);
            uint32_t seq_ref = m3g_read_u32(data, pos, data_size);
            uint32_t ctrl_ref = m3g_read_u32(data, pos, data_size);
            uint32_t property = m3g_read_u32(data, pos, data_size);
            m3g_set_int_field(track, "sequenceRef", (jint)seq_ref);
            m3g_set_int_field(track, "controllerRef", (jint)ctrl_ref);
            m3g_set_int_field(track, "propertyId", (jint)property);
            /* Resolve backward refs immediately (they are already parsed) */
            int seq_idx = (int)seq_ref - 2;
            if (seq_ref > 0 && seq_idx >= 0 && seq_idx < ctx->object_count && ctx->objects[seq_idx]) {
                m3g_set_ref_field(track, "sequence", ctx->objects[seq_idx]);
            }
            int ctrl_idx = (int)ctrl_ref - 2;
            if (ctrl_ref > 0 && ctrl_idx >= 0 && ctrl_idx < ctx->object_count && ctx->objects[ctrl_idx]) {
                m3g_set_ref_field(track, "controller", ctx->objects[ctrl_idx]);
            }
            fprintf(stderr, "[M3G-ANIM] AnimationTrack userID=%u property=%u seqRef=%u ctrlRef=%u\n",
                    user_id, property, seq_ref, ctrl_ref);
            return track;
        }

        case M3G_OBJ_KEYFRAMESEQUENCE: {
            JavaClass* kf_class = jvm_load_class(jvm, "javax/microedition/m3g/KeyframeSequence");
            if (!kf_class) return NULL;
            JavaObject* seq = jvm_new_object(jvm, kf_class);
            if (!seq) return NULL;
            m3g_set_userID(seq, user_id);
            m3g_read_object3d_data(seq, data, data_size, pos, ctx);

            uint8_t interpolation = m3g_read_u8(data, pos, data_size);
            uint8_t repeat_mode = m3g_read_u8(data, pos, data_size);
            uint8_t encoding = m3g_read_u8(data, pos, data_size);
            uint32_t duration = m3g_read_u32(data, pos, data_size);
            uint32_t vr_first = m3g_read_u32(data, pos, data_size);
            uint32_t vr_last = m3g_read_u32(data, pos, data_size);
            uint32_t comp_count = m3g_read_u32(data, pos, data_size);

            /* Layout detection. Official JSR-184 files carry a componentSize
             * byte before keyframeCount; some exporters (incl. M3GTest's
             * m3gtool) omit it and always store float32 components.
             * Peek the next 4 bytes: spec layout reads them as
             * (kfCount<<8)|componentSize (little-endian), so the low byte is
             * 1/2/4 AND the high part is a plausible keyframe count. */
            uint32_t peek = 0;
            if (*pos + 4 <= data_size) {
                memcpy(&peek, &data[*pos], 4);
            }
            int spec_layout = 0;
            uint8_t comp_size = 4;
            uint32_t kf_count = 0;
            if ((peek & 0xFF) == 1 || (peek & 0xFF) == 2 || (peek & 0xFF) == 4) {
                uint32_t kf_hi = peek >> 8;
                if (kf_hi >= 1 && kf_hi < 65536) {
                    spec_layout = 1;
                    comp_size = (uint8_t)(peek & 0xFF);
                    kf_count = kf_hi;
                }
            }
            if (!spec_layout) {
                kf_count = peek;
                comp_size = 4;
            }
            *pos += 4;  /* consumed the peeked u32 */

            if (kf_count < 1 || kf_count > 65536 || comp_count < 1 || comp_count > 16) {
                fprintf(stderr, "[M3G-ANIM] KeyframeSequence: invalid dims kf=%u comp=%u — skipped\n",
                        kf_count, comp_count);
                return NULL;
            }

            int interp_api = 176 + (interpolation & 3);  /* byte0: 0 LINEAR..3 SQUAD (JSR-184 §KeyframeSequence; m3gtool reads the same order) */
            int repeat_api = (repeat_mode == 1) ? 193 : 192;
            (void)encoding;  /* raw(0) assumed; delta encodings not produced by modern exporters */

            JavaArray* times = jvm_new_array(jvm, T_INT, kf_count, NULL);
            JavaArray* values = jvm_new_array(jvm, T_FLOAT, kf_count * comp_count, NULL);
            jint* t_arr = times ? (jint*)array_data(times) : NULL;
            jfloat* v_arr = values ? (jfloat*)array_data(values) : NULL;

            for (uint32_t k = 0; k < kf_count; k++) {
                int32_t ktime = (int32_t)m3g_read_u32(data, pos, data_size);
                if (t_arr) t_arr[k] = ktime;
                for (uint32_t c = 0; c < comp_count; c++) {
                    float val = 0.0f;
                    if (comp_size == 4) {
                        val = m3g_read_float(data, pos, data_size);
                    } else if (comp_size == 2) {
                        val = (float)m3g_read_u16(data, pos, data_size);
                    } else {
                        val = (float)m3g_read_u8(data, pos, data_size);
                    }
                    if (v_arr) v_arr[k * comp_count + c] = val;
                }
            }

            m3g_set_int_field(seq, "numKeyframes", (jint)kf_count);
            m3g_set_int_field(seq, "numComponents", (jint)comp_count);
            m3g_set_int_field(seq, "componentCount", (jint)comp_count);
            m3g_set_int_field(seq, "interpolation", interp_api);
            m3g_set_int_field(seq, "duration", (jint)duration);
            m3g_set_int_field(seq, "repeatMode", repeat_api);
            m3g_set_int_field(seq, "firstValid", (jint)vr_first);
            m3g_set_int_field(seq, "lastValid", (jint)vr_last);
            m3g_set_int_field(seq, "validRangeFirst", (jint)vr_first);
            m3g_set_int_field(seq, "validRangeLast", (jint)vr_last);
            if (times) m3g_set_ref_field(seq, "keyframeTimes", (JavaObject*)times);
            if (values) m3g_set_ref_field(seq, "keyframeValues", (JavaObject*)values);

            fprintf(stderr, "[M3G-ANIM] KeyframeSequence userID=%u kf=%u comp=%u dur=%u interp=%d repeat=%d layout=%s\n",
                    user_id, kf_count, comp_count, duration, interp_api, repeat_api,
                    spec_layout ? "spec" : "flat");
            return seq;
        }

        case M3G_OBJ_WORLD: {
            JavaClass* world_class = jvm_load_class(jvm, "javax/microedition/m3g/World");
            if (!world_class) return NULL;

            JavaObject* world = jvm_new_object(jvm, world_class);
            if (world) {
                m3g_set_userID(world, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Group -> World */
                m3g_read_object3d_data(world, data, data_size, pos, ctx);
                m3g_read_transformable_data(world, data, data_size, pos, jvm);
                m3g_read_node_data(world, data, data_size, pos);
                m3g_read_group_data(world, data, data_size, pos, jvm);

                /* World-specific: activeCamera and background references */
                uint32_t camera_ref = m3g_read_u32(data, pos, data_size);
                uint32_t bg_ref = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(world, "activeCameraRef", camera_ref);
                m3g_set_int_field(world, "backgroundRef", bg_ref);

                ctx->world = world;
                GFX_DEBUG("M3G: Created World userID=%u cameraRef=%u bgRef=%u", user_id, camera_ref, bg_ref);
            }
            return world;
        }

        case M3G_OBJ_CAMERA: {
            JavaClass* camera_class = jvm_load_class(jvm, "javax/microedition/m3g/Camera");
            if (!camera_class) return NULL;

            JavaObject* camera = jvm_new_object(jvm, camera_class);
            if (camera) {
                m3g_set_userID(camera, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Camera */
                m3g_read_object3d_data(camera, data, data_size, pos, ctx);
                m3g_read_transformable_data(camera, data, data_size, pos, jvm);
                m3g_read_node_data(camera, data, data_size, pos);

                /* Camera-specific: projection */
                uint8_t proj_type = m3g_read_u8(data, pos, data_size);
                m3g_set_int_field(camera, "projectionType", proj_type);

                if (proj_type == 48) { /* GENERIC */
                    /* 4x4 matrix = 16 floats - stored in row-major in M3G file */
                    float rowmajor[16];
                    for (int i = 0; i < 16; i++) {
                        rowmajor[i] = m3g_read_float(data, pos, data_size);
                    }
                    /* Store as a float[] field in row-major (Java convention) */
                    JavaArray* gen_matrix = jvm_new_array(jvm, T_FLOAT, 16, NULL);
                    if (gen_matrix) {
                        float* dst = (float*)array_data(gen_matrix);
                        memcpy(dst, rowmajor, 16 * sizeof(float));
                        m3g_set_ref_field(camera, "genericMatrix", (JavaObject*)gen_matrix);
                    }
                } else if (proj_type == 50) { /* PERSPECTIVE */
                    float fov = m3g_read_float(data, pos, data_size);
                    float aspect = m3g_read_float(data, pos, data_size);
                    float near = m3g_read_float(data, pos, data_size);
                    float far = m3g_read_float(data, pos, data_size);
                    m3g_set_float_field(camera, "fov", fov);
                    m3g_set_float_field(camera, "aspect", aspect);
                    m3g_set_float_field(camera, "near", near);
                    m3g_set_float_field(camera, "far", far);
                } else if (proj_type == 49) { /* PARALLEL */
                    float fovy = m3g_read_float(data, pos, data_size);
                    float aspect = m3g_read_float(data, pos, data_size);
                    float near = m3g_read_float(data, pos, data_size);
                    float far = m3g_read_float(data, pos, data_size);
                    m3g_set_float_field(camera, "fov", fovy);
                    m3g_set_float_field(camera, "aspect", aspect);
                    m3g_set_float_field(camera, "near", near);
                    m3g_set_float_field(camera, "far", far);
                }

                ctx->camera = camera;
                GFX_DEBUG("M3G: Created Camera userID=%u proj=%d", user_id, proj_type);
            }
            return camera;
        }

        case M3G_OBJ_LIGHT: {
            JavaClass* light_class = jvm_load_class(jvm, "javax/microedition/m3g/Light");
            if (!light_class) return NULL;

            JavaObject* light = jvm_new_object(jvm, light_class);
            if (light) {
                m3g_set_userID(light, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Light */
                m3g_read_object3d_data(light, data, data_size, pos, ctx);
                m3g_read_transformable_data(light, data, data_size, pos, jvm);
                m3g_read_node_data(light, data, data_size, pos);

                /* Light-specific: attenuation, color, mode, intensity, spot */
                float att0 = m3g_read_float(data, pos, data_size);
                float att1 = m3g_read_float(data, pos, data_size);
                float att2 = m3g_read_float(data, pos, data_size);
                uint32_t color = m3g_read_u32(data, pos, data_size);
                uint8_t mode = m3g_read_u8(data, pos, data_size);
                float intensity = m3g_read_float(data, pos, data_size);
                float spot_angle = m3g_read_float(data, pos, data_size);
                float spot_exp = m3g_read_float(data, pos, data_size);

                m3g_set_int_field(light, "mode", mode);
                m3g_set_int_field(light, "color", color);
                m3g_set_float_field(light, "intensity", intensity);
                m3g_set_float_field(light, "constantAttenuation", att0);
                m3g_set_float_field(light, "linearAttenuation", att1);
                m3g_set_float_field(light, "quadraticAttenuation", att2);
                m3g_set_float_field(light, "spotAngle", spot_angle);
                m3g_set_float_field(light, "spotExponent", spot_exp);

                ctx->light = light;
                GFX_DEBUG("M3G: Created Light userID=%u mode=%d color=0x%08X", user_id, mode, color);
            }
            return light;
        }

        case M3G_OBJ_BACKGROUND: {
            JavaClass* bg_class = jvm_load_class(jvm, "javax/microedition/m3g/Background");
            if (!bg_class) return NULL;

            JavaObject* bg = jvm_new_object(jvm, bg_class);
            if (bg) {
                m3g_set_userID(bg, user_id);

                /* Object3D data */
                m3g_read_object3d_data(bg, data, data_size, pos, ctx);

                /* Background-specific */
                uint32_t bg_color = m3g_read_u32(data, pos, data_size);
                uint32_t image_ref = m3g_read_u32(data, pos, data_size);
                uint8_t mode_x = m3g_read_u8(data, pos, data_size);
                uint8_t mode_y = m3g_read_u8(data, pos, data_size);
                int32_t crop_x = m3g_read_u32(data, pos, data_size);  /* signed */
                int32_t crop_y = m3g_read_u32(data, pos, data_size);
                int32_t crop_w = m3g_read_u32(data, pos, data_size);
                int32_t crop_h = m3g_read_u32(data, pos, data_size);
                uint8_t depth_clear = m3g_read_u8(data, pos, data_size);
                uint8_t color_clear = m3g_read_u8(data, pos, data_size);

                m3g_set_int_field(bg, "clearColor", bg_color);
                m3g_set_int_field(bg, "imageRef", image_ref);
                m3g_set_int_field(bg, "depthClearEnable", depth_clear);
                m3g_set_int_field(bg, "colorClearEnable", color_clear);
                m3g_set_int_field(bg, "imageModeX", mode_x);
                m3g_set_int_field(bg, "imageModeY", mode_y);
                m3g_set_int_field(bg, "cropX", crop_x);
                m3g_set_int_field(bg, "cropY", crop_y);
                m3g_set_int_field(bg, "cropWidth", crop_w);
                m3g_set_int_field(bg, "cropHeight", crop_h);

                ctx->background = bg;
                GFX_DEBUG("M3G: Created Background userID=%u color=0x%08X", user_id, bg_color);
            }
            return bg;
        }

        case M3G_OBJ_MESH: {
            JavaClass* mesh_class = jvm_load_class(jvm, "javax/microedition/m3g/Mesh");
            if (!mesh_class) return NULL;

            JavaObject* mesh = jvm_new_object(jvm, mesh_class);
            if (mesh) {
                m3g_set_userID(mesh, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Mesh */
                m3g_read_object3d_data(mesh, data, data_size, pos, ctx);
                m3g_read_transformable_data(mesh, data, data_size, pos, jvm);
                m3g_read_node_data(mesh, data, data_size, pos);

                /* Mesh-specific: vertexBuffer ref, then submeshCount, indexBuffer/appearance refs */
                uint32_t vb_ref = m3g_read_u32(data, pos, data_size);
                uint32_t submesh_count = m3g_read_u32(data, pos, data_size);

                m3g_set_int_field(mesh, "vertexBufferRef", vb_ref);
                m3g_set_int_field(mesh, "submeshCount", submesh_count);

                /* Read index buffer and appearance refs for each submesh */
                /* Store first submesh refs for linking */
                uint32_t ib_ref = 0, app_ref = 0;
                for (uint32_t i = 0; i < submesh_count; i++) {
                    uint32_t this_ib = m3g_read_u32(data, pos, data_size);
                    uint32_t this_app = m3g_read_u32(data, pos, data_size);
                    if (i == 0) {
                        ib_ref = this_ib;
                        app_ref = this_app;
                    }
                }
                m3g_set_int_field(mesh, "indexBufferRef", ib_ref);
                m3g_set_int_field(mesh, "appearanceRef", app_ref);

                ctx->mesh = mesh;
                GFX_DEBUG("M3G: Created Mesh userID=%u vbRef=%u ibRef=%u appRef=%u submeshCount=%u",
                         user_id, vb_ref, ib_ref, app_ref, submesh_count);
            }
            return mesh;
        }

        case M3G_OBJ_VERTEXBUFFER: {
            JavaClass* vb_class = jvm_load_class(jvm, "javax/microedition/m3g/VertexBuffer");
            if (!vb_class) return NULL;

            JavaObject* vb = jvm_new_object(jvm, vb_class);
            if (vb) {
                m3g_set_userID(vb, user_id);

                /* Object3D data */
                m3g_read_object3d_data(vb, data, data_size, pos, ctx);

                /* VertexBuffer-specific */
                uint32_t default_color = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(vb, "defaultColor", default_color);

                /* Positions: ref + scale + bias */
                uint32_t pos_ref = m3g_read_u32(data, pos, data_size);
                /* v14 FIX: file order is positionBias (3×f32) THEN
                 * positionScale (JSR-184 §VertexBuffer, m3gtool/Blender
                 * exporters agree). The old code read scale first — the
                 * scale got bias[0] (typically 0), so EVERY file-loaded
                 * mesh collapsed to a point (M3GTest scene 7: all vertices
                 * (0,0,0)). */
                float bias_x = m3g_read_float(data, pos, data_size);
                float bias_y = m3g_read_float(data, pos, data_size);
                float bias_z = m3g_read_float(data, pos, data_size);
                float scale = m3g_read_float(data, pos, data_size);

                m3g_set_int_field(vb, "positionsRef", pos_ref);
                m3g_set_float_field(vb, "positionScale", scale);
                m3g_set_float_field(vb, "biasX", bias_x);
                m3g_set_float_field(vb, "biasY", bias_y);
                m3g_set_float_field(vb, "biasZ", bias_z);

                /* Normals ref */
                uint32_t norm_ref = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(vb, "normalsRef", norm_ref);

                /* Colors ref */
                uint32_t color_ref = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(vb, "colorsRef", color_ref);

                /* TexCoord arrays.
                 * v14 FIX: per-array file order is ref, bias (3×f32), scale
                 * — the old code read scale first (same swap as positions). */
                uint32_t tex_count = m3g_read_u32(data, pos, data_size);
                uint32_t tex_coord_ref = 0;
                float tex_coord_scale = 1.0f;
                for (uint32_t i = 0; i < tex_count; i++) {
                    uint32_t this_tex_ref = m3g_read_u32(data, pos, data_size);  /* texCoord ref */
                    m3g_read_float(data, pos, data_size);  /* bias x */
                    m3g_read_float(data, pos, data_size);  /* bias y */
                    m3g_read_float(data, pos, data_size);  /* bias z (usually 0) */
                    float this_tex_scale = m3g_read_float(data, pos, data_size);  /* scale */
                    if (i == 0) {
                        tex_coord_ref = this_tex_ref;
                        tex_coord_scale = this_tex_scale;
                    }
                }
                m3g_set_int_field(vb, "texCoordsRef", tex_coord_ref);
                m3g_set_float_field(vb, "texCoordScale", tex_coord_scale);

                ctx->vertex_buffer = vb;
                GFX_DEBUG("M3G: Created VertexBuffer userID=%u posRef=%u normRef=%u colorRef=%u texRef=%u",
                         user_id, pos_ref, norm_ref, color_ref, tex_coord_ref);
            }
            return vb;
        }

        case M3G_OBJ_VERTEXARRAY: {
            JavaClass* va_class = jvm_load_class(jvm, "javax/microedition/m3g/VertexArray");
            if (!va_class) return NULL;

            JavaObject* va = jvm_new_object(jvm, va_class);
            if (va) {
                m3g_set_userID(va, user_id);

                /* Object3D data */
                m3g_read_object3d_data(va, data, data_size, pos, ctx);

                /* VertexArray-specific.
                 * v14 FIX: file order is componentSize, componentCount,
                 * encoding, vertexCount (JSR-184 §VertexArray). The old code
                 * read componentCount first, swapping the two — byte arrays
                 * with 2 components (file texcoords) were reinterpreted as
                 * short arrays with 1 component (garbage UVs). */
                uint8_t component_size = m3g_read_u8(data, pos, data_size);
                uint8_t component_count = m3g_read_u8(data, pos, data_size);
                uint8_t encoding = m3g_read_u8(data, pos, data_size);
                uint16_t vertex_count = m3g_read_u16(data, pos, data_size);

                /* Sanity checks */
                if (component_count > 4) component_count = 4;
                if (component_size > 2) component_size = 2;

                int data_size_total = (int)vertex_count * component_count * component_size;
                if (data_size_total <= 0 || data_size_total > M3G_MAX_VERTEX_COUNT * 4 * 2) {
                    GFX_DEBUG("M3G: VertexArray data_size invalid: %d", data_size_total);
                    return va;
                }

                m3g_set_int_field(va, "componentCount", component_count);
                m3g_set_int_field(va, "componentSize", component_size);
                m3g_set_int_field(va, "vertexCount", vertex_count);

                /* Create data array */
                JavaArray* arr = jvm_new_array(jvm, component_size == 1 ? T_BYTE : T_SHORT,
                                                data_size_total, NULL);
                if (arr) {
                    m3g_set_ref_field(va, "data", (JavaObject*)arr);
                    void* dst = array_data(arr);

                    if (encoding == 0) { /* Raw */
                        memcpy(dst, &data[*pos], data_size_total);
                    } else { /* Delta encoding: each value = previous + diff */
                        if (component_size == 1) {
                            uint8_t last = 0;
                            uint8_t* d = (uint8_t*)dst;
                            for (int i = 0; i < data_size_total; i++) {
                                last += data[*pos + i];
                                d[i] = last;
                            }
                        } else {
                            int16_t last = 0;
                            int16_t* d = (int16_t*)dst;
                            for (int i = 0; i < data_size_total; i += 2) {
                                int16_t diff = (int16_t)(data[*pos + i] | (data[*pos + i + 1] << 8));
                                last += diff;
                                d[i / 2] = last;
                            }
                        }
                    }
                }
                *pos += data_size_total;

                GFX_DEBUG("M3G: Created VertexArray userID=%u %d vertices, %d components",
                         user_id, vertex_count, component_count);
            }
            return va;
        }

        case M3G_OBJ_TRIANGLESTRIPARRAY: {
            JavaClass* ib_class = jvm_load_class(jvm, "javax/microedition/m3g/TriangleStripArray");
            if (!ib_class) return NULL;

            JavaObject* ib = jvm_new_object(jvm, ib_class);
            if (ib) {
                m3g_set_userID(ib, user_id);

                /* Object3D data */
                m3g_read_object3d_data(ib, data, data_size, pos, ctx);

                /* TriangleStripArray-specific: encoding, then indices */
                uint8_t encoding = m3g_read_u8(data, pos, data_size);

                uint32_t first_index = 0;
                uint32_t strip_count = 0;
                int32_t* explicit_indices = NULL;
                uint32_t explicit_count = 0;

                switch (encoding) {
                    case 0:  /* Explicit first index */
                        first_index = m3g_read_u32(data, pos, data_size);
                        break;
                    case 1:
                        first_index = m3g_read_u8(data, pos, data_size);
                        break;
                    case 2:
                        first_index = m3g_read_u16(data, pos, data_size);
                        break;
                    case 128: /* Explicit array indices */
                    case 129:
                    case 130:
                        {
                            explicit_count = m3g_read_u32(data, pos, data_size);
                            if (explicit_count > 0 && explicit_count < M3G_MAX_INDEX_COUNT) {
                                explicit_indices = (int32_t*)malloc(explicit_count * sizeof(int32_t));
                                if (explicit_indices) {
                                    for (uint32_t i = 0; i < explicit_count; i++) {
                                        if (encoding == 128)
                                            explicit_indices[i] = (int32_t)m3g_read_u32(data, pos, data_size);
                                        else if (encoding == 129)
                                            explicit_indices[i] = (int32_t)m3g_read_u8(data, pos, data_size);
                                        else
                                            explicit_indices[i] = (int32_t)m3g_read_u16(data, pos, data_size);
                                    }
                                } else {
                                    /* Skip indices if allocation failed */
                                    for (uint32_t i = 0; i < explicit_count; i++) {
                                        if (encoding == 128) m3g_read_u32(data, pos, data_size);
                                        else if (encoding == 129) m3g_read_u8(data, pos, data_size);
                                        else m3g_read_u16(data, pos, data_size);
                                    }
                                }
                            } else {
                                /* Skip invalid index count */
                                for (uint32_t i = 0; i < explicit_count && i < M3G_MAX_INDEX_COUNT; i++) {
                                    if (encoding == 128) m3g_read_u32(data, pos, data_size);
                                    else if (encoding == 129) m3g_read_u8(data, pos, data_size);
                                    else m3g_read_u16(data, pos, data_size);
                                }
                                explicit_count = 0;
                            }
                        }
                        break;
                }

                /* Read strip lengths */
                strip_count = m3g_read_u32(data, pos, data_size);
                uint32_t* strip_lengths = NULL;
                if (strip_count > 0 && strip_count < 1024) {
                    strip_lengths = (uint32_t*)malloc(strip_count * sizeof(uint32_t));
                    for (uint32_t i = 0; i < strip_count; i++) {
                        strip_lengths[i] = m3g_read_u32(data, pos, data_size);
                    }
                } else {
                    for (uint32_t i = 0; i < strip_count && i < 1024; i++) {
                        m3g_read_u32(data, pos, data_size);
                    }
                    strip_count = 0;
                }

                /* Generate expanded triangle indices from strip data */
                int total_tri_indices = 0;
                for (uint32_t s = 0; s < strip_count; s++) {
                    int slen = (int)strip_lengths[s];
                    if (slen < 3) continue;
                    total_tri_indices += (slen - 2) * 3;
                }

                if (total_tri_indices > 0 && total_tri_indices <= M3G_MAX_INDEX_COUNT) {
                    JavaArray* indices = jvm_new_array(jvm, T_SHORT, total_tri_indices, NULL);
                    if (indices) {
                        int16_t* dst = (int16_t*)array_data(indices);
                        int idx = 0;
                        int vertex_offset = 0;

                        for (uint32_t s = 0; s < strip_count && idx + 2 < total_tri_indices; s++) {
                            int slen = (int)strip_lengths[s];
                            if (slen < 3) {
                                vertex_offset += slen;
                                continue;
                            }

                            for (int t = 0; t < slen - 2 && idx + 2 < total_tri_indices; t++) {
                                int i0, i1, i2;
                                if (explicit_indices) {
                                    /* Use explicit vertex indices from the M3G binary */
                                    i0 = explicit_indices[vertex_offset + t];
                                    i1 = explicit_indices[vertex_offset + t + 1];
                                    i2 = explicit_indices[vertex_offset + t + 2];
                                } else {
                                    /* Implicit indices: first_index + vertex_offset + t */
                                    i0 = (int)first_index + vertex_offset + t;
                                    i1 = (int)first_index + vertex_offset + t + 1;
                                    i2 = (int)first_index + vertex_offset + t + 2;
                                }

                                if (t % 2 == 0) {
                                    dst[idx++] = (int16_t)i0;
                                    dst[idx++] = (int16_t)i1;
                                    dst[idx++] = (int16_t)i2;
                                } else {
                                    /* Swap last two for correct winding order */
                                    dst[idx++] = (int16_t)i0;
                                    dst[idx++] = (int16_t)i2;
                                    dst[idx++] = (int16_t)i1;
                                }
                            }
                            vertex_offset += slen;
                        }

                        m3g_set_ref_field(ib, "indices", (JavaObject*)indices);
                        m3g_set_int_field(ib, "indexCount", idx);
                        fprintf(stderr, "[M3G] TriangleStripArray: %d strips, %d tri-indices, encoding=%d\n",
                                strip_count, idx, encoding);
                    }
                } else {
                    fprintf(stderr, "[M3G] TriangleStripArray: invalid total_tri_indices=%d (strips=%u)\n",
                            total_tri_indices, strip_count);
                }

                if (explicit_indices) free(explicit_indices);
                if (strip_lengths) free(strip_lengths);

                ctx->index_buffer = ib;
            }
            return ib;
        }

        case M3G_OBJ_APPEARANCE: {
            JavaClass* app_class = jvm_load_class(jvm, "javax/microedition/m3g/Appearance");
            if (!app_class) return NULL;

            JavaObject* app = jvm_new_object(jvm, app_class);
            if (app) {
                m3g_set_userID(app, user_id);

                /* Object3D data */
                m3g_read_object3d_data(app, data, data_size, pos, ctx);

                /* Appearance-specific */
                uint8_t layer = m3g_read_u8(data, pos, data_size);
                m3g_set_int_field(app, "layer", layer);

                /* References: compositingMode, fog, polygonMode, material */
                uint32_t comp_mode_ref = m3g_read_u32(data, pos, data_size);  /* compositingMode */
                uint32_t fog_ref = m3g_read_u32(data, pos, data_size);       /* fog */
                uint32_t poly_mode_ref = m3g_read_u32(data, pos, data_size); /* polygonMode */
                uint32_t material_ref = m3g_read_u32(data, pos, data_size);  /* material */
                m3g_set_int_field(app, "materialRef", material_ref);
                m3g_set_int_field(app, "compositingModeRef", comp_mode_ref);
                m3g_set_int_field(app, "fogRef", fog_ref);
                m3g_set_int_field(app, "polygonModeRef", poly_mode_ref);

                /* Textures */
                uint32_t tex_count = m3g_read_u32(data, pos, data_size);
                uint32_t texture_ref = 0;
                for (uint32_t i = 0; i < tex_count; i++) {
                    uint32_t this_tex_ref = m3g_read_u32(data, pos, data_size);  /* texture ref */
                    if (i == 0) texture_ref = this_tex_ref;
                }
                m3g_set_int_field(app, "textureRef", texture_ref);

                ctx->appearance = app;
                GFX_DEBUG("M3G: Created Appearance userID=%u layer=%d texCount=%u",
                         user_id, layer, tex_count);
            }
            return app;
        }

        case M3G_OBJ_MATERIAL: {
            JavaClass* mat_class = jvm_load_class(jvm, "javax/microedition/m3g/Material");
            if (!mat_class) return NULL;

            JavaObject* mat = jvm_new_object(jvm, mat_class);
            if (mat) {
                m3g_set_userID(mat, user_id);

                /* Object3D data */
                m3g_read_object3d_data(mat, data, data_size, pos, ctx);

                /* Material-specific per JSR-184 spec */
                uint32_t ambient = m3g_read_u32(data, pos, data_size);
                uint32_t diffuse = m3g_read_u32(data, pos, data_size);
                uint32_t emissive = m3g_read_u32(data, pos, data_size);
                uint32_t specular = m3g_read_u32(data, pos, data_size);
                float shininess = m3g_read_float(data, pos, data_size);
                uint8_t vertex_color_tracking = m3g_read_u8(data, pos, data_size);

                m3g_set_int_field(mat, "ambient", ambient);
                m3g_set_int_field(mat, "diffuse", diffuse);
                m3g_set_int_field(mat, "emissive", emissive);
                m3g_set_int_field(mat, "specular", specular);
                m3g_set_float_field(mat, "shininess", shininess);
                m3g_set_int_field(mat, "vertexColorTracking", vertex_color_tracking);

                GFX_DEBUG("M3G: Created Material userID=%u shin=%.1f", user_id, shininess);
            }
            return mat;
        }

        case M3G_OBJ_COMPOSITINGMODE: {
            JavaClass* cm_class = jvm_load_class(jvm, "javax/microedition/m3g/CompositingMode");
            if (!cm_class) return NULL;

            JavaObject* cm = jvm_new_object(jvm, cm_class);
            if (cm) {
                m3g_set_userID(cm, user_id);

                /* Object3D data */
                m3g_read_object3d_data(cm, data, data_size, pos, ctx);

                /* CompositingMode-specific per JSR-184 M3G binary format.
                 * The M3G spec stores properties in this order:
                 *   DepthTest(u8), DepthWrite(u8), ColorWrite(u8),
                 *   Blending(u8), AlphaThreshold(f32), Dithering(u8)
                 * Previous parser read Blending first (wrong order). */
                uint8_t depth_test = m3g_read_u8(data, pos, data_size);
                uint8_t depth_write = m3g_read_u8(data, pos, data_size);
                uint8_t color_write = m3g_read_u8(data, pos, data_size);
                uint8_t blending = m3g_read_u8(data, pos, data_size);
                float alpha_threshold = m3g_read_float(data, pos, data_size);
                uint8_t dithering = m3g_read_u8(data, pos, data_size);

                /* v12 CRITICAL FIX: the M3G FILE stores blending as an INDEX
                 * (0=ALPHA, 1=ALPHA_ADD, 2=MODULATE, 3=MODULATE_X2,
                 *  4=REPLACE, 5=DECAL), while the RENDERER expects the
                 * JSR-184 API constants (64=ALPHA, 65=ALPHA_ADD, 67=REPLACE,
                 * 68=MODULATE, 69=MODULATE_X2, 70=DECAL). Storing the raw
                 * byte made blend_mode=0 fall into the switch DEFAULT in
                 * m3g_blend_pixels() which RETURNS THE BACKGROUND — every
                 * triangle was painted in the clear color (invisible cube
                 * in Nescube, invisible everything everywhere else!). */
                static const uint8_t blending_file_to_api[6] = {
                    64, /* 0 = ALPHA       */
                    65, /* 1 = ALPHA_ADD   */
                    68, /* 2 = MODULATE    */
                    69, /* 3 = MODULATE_X2 */
                    67, /* 4 = REPLACE     */
                    70  /* 5 = DECAL       */
                };
                int blending_api = (blending < 6) ? blending_file_to_api[blending] : 64;

                m3g_set_int_field(cm, "blending", blending_api);
                m3g_set_float_field(cm, "alphaThreshold", alpha_threshold);
                m3g_set_int_field(cm, "depthTest", depth_test);
                m3g_set_int_field(cm, "depthWrite", depth_write);
                m3g_set_int_field(cm, "colorWrite", color_write);
                m3g_set_int_field(cm, "dithering", dithering);

                /* DIAG: Log class info and verify */
                fprintf(stderr, "[M3G-PARSE-CM] userID=%u class=%s inst_size=%d fields_count=%d\n",
                        user_id, cm_class->class_name, (int)cm_class->instance_size, cm_class->fields_count);
                fprintf(stderr, "[M3G-PARSE-CM] raw: blend=%u(0x%02x) alphaT=%.3f depthT=%u depthW=%u\n",
                        blending, blending, alpha_threshold, depth_test, depth_write);
                jint verify_blend = m3g_get_int_field(cm, "blending", -999);
                jfloat verify_alpha = m3g_get_float_field(cm, "alphaThreshold", -999.0f);
                fprintf(stderr, "[M3G-PARSE-CM] verify: blend=%d alpha=%.3f (expected %d, %.3f)\n",
                        verify_blend, verify_alpha, blending, alpha_threshold);

                GFX_DEBUG("M3G: Created CompositingMode userID=%u blend=%d depth=%d/%d",
                         user_id, blending, depth_test, depth_write);
            }
            return cm;
        }

        case M3G_OBJ_FOG: {
            JavaClass* fog_class = jvm_load_class(jvm, "javax/microedition/m3g/Fog");
            if (!fog_class) return NULL;

            JavaObject* fog = jvm_new_object(jvm, fog_class);
            if (fog) {
                m3g_set_userID(fog, user_id);

                /* Object3D data */
                m3g_read_object3d_data(fog, data, data_size, pos, ctx);

                /* Fog-specific per JSR-184 spec */
                uint8_t mode = m3g_read_u8(data, pos, data_size);
                /* Color: 3 floats (R, G, B) */
                float cr = m3g_read_float(data, pos, data_size);
                float cg = m3g_read_float(data, pos, data_size);
                float cb = m3g_read_float(data, pos, data_size);
                float density = m3g_read_float(data, pos, data_size);
                float near_dist = m3g_read_float(data, pos, data_size);
                float far_dist = m3g_read_float(data, pos, data_size);

                m3g_set_int_field(fog, "mode", mode);
                m3g_set_float_field(fog, "density", density);
                m3g_set_float_field(fog, "nearDistance", near_dist);
                m3g_set_float_field(fog, "farDistance", far_dist);
                /* Store color as packed ARGB int for convenience */
                uint32_t packed_color = 0xFF000000 |
                    (((uint32_t)(cr * 255.0f) & 0xFF)) |
                    (((uint32_t)(cg * 255.0f) & 0xFF) << 8) |
                    (((uint32_t)(cb * 255.0f) & 0xFF) << 16);
                m3g_set_int_field(fog, "color", packed_color);

                GFX_DEBUG("M3G: Created Fog userID=%u mode=%d density=%.3f near=%.1f far=%.1f",
                         user_id, mode, density, near_dist, far_dist);
            }
            return fog;
        }

        case M3G_OBJ_POLYGONMODE: {
            JavaClass* pm_class = jvm_load_class(jvm, "javax/microedition/m3g/PolygonMode");
            if (!pm_class) return NULL;

            JavaObject* pm = jvm_new_object(jvm, pm_class);
            if (pm) {
                m3g_set_userID(pm, user_id);

                /* Object3D data */
                size_t pos_before = *pos;
                m3g_read_object3d_data(pm, data, data_size, pos, ctx);

                /* PolygonMode-specific per JSR-184 spec */
                uint8_t culling = m3g_read_u8(data, pos, data_size);
                uint8_t shading = m3g_read_u8(data, pos, data_size);
                uint8_t two_sided_lighting = m3g_read_u8(data, pos, data_size);
                uint8_t local_camera_lighting = m3g_read_u8(data, pos, data_size);
                (void)m3g_read_u8(data, pos, data_size); /* perspectiveCorrection */

                /* DIAG: Log class info and field details */
                fprintf(stderr, "[M3G-PARSE-PM] userID=%u class=%s inst_size=%zu fields_count=%d\n",
                        user_id, pm_class->class_name, pm_class->instance_size, pm_class->fields_count);
                fprintf(stderr, "[M3G-PARSE-PM] pos_before_o3d=%zu pos_after_o3d=%zu (o3d consumed %zu bytes)\n",
                        pos_before, *pos, *pos - pos_before);
                fprintf(stderr, "[M3G-PARSE-PM] raw bytes at pos=%zu: culling=%u(0x%02x) shading=%u(0x%02x) twoSided=%u(0x%02x) localCam=%u(0x%02x)\n",
                        pos_before, culling, culling, shading, shading, two_sided_lighting, two_sided_lighting, local_camera_lighting, local_camera_lighting);

                m3g_set_int_field(pm, "culling", culling);
                m3g_set_int_field(pm, "shading", shading);
                m3g_set_int_field(pm, "twoSidedLighting", two_sided_lighting);
                m3g_set_int_field(pm, "winding", 0); /* default: CCW */
                m3g_set_int_field(pm, "localCameraLighting", local_camera_lighting);

                /* DIAG: Verify fields were set correctly */
                jint verify_culling = m3g_get_int_field(pm, "culling", -999);
                jint verify_two_sided = m3g_get_int_field(pm, "twoSidedLighting", -999);
                fprintf(stderr, "[M3G-PARSE-PM] verify: culling=%d twoSided=%d (expected %d, %d)\n",
                        verify_culling, verify_two_sided, culling, two_sided_lighting);

                GFX_DEBUG("M3G: Created PolygonMode userID=%u cull=%d shade=%d twoSide=%d",
                         user_id, culling, shading, two_sided_lighting);
            }
            return pm;
        }

        case M3G_OBJ_IMAGE2D: {
            JavaClass* img_class = jvm_load_class(jvm, "javax/microedition/m3g/Image2D");
            if (!img_class) return NULL;

            JavaObject* img = jvm_new_object(jvm, img_class);
            if (img) {
                m3g_set_userID(img, user_id);

                /* Object3D data */
                m3g_read_object3d_data(img, data, data_size, pos, ctx);

                /* Image2D-specific per JSR-184 spec §5.7:
                 * format      : UnsignedByte  (1 byte)
                 * isMutable   : Boolean       (1 byte)
                 * width       : UnsignedInt   (4 bytes LE)
                 * height      : UnsignedInt   (4 bytes LE)
                 * [pixel data follows]
                 *
                 * BUG FIX: Previously read format as u32 (4 bytes), shifting
                 * width/height reads by 3 bytes → height read from pixel data → 0.
                 * Also: Nokia H3T exporter writes Java API constants (0x60-0x64)
                 * instead of M3G binary constants (0x10-0x14). */
                uint32_t format = m3g_read_u8(data, pos, data_size);  /* u8, not u32! */
                (void)m3g_read_u8(data, pos, data_size);              /* skip isMutable */
                int32_t width = (int32_t)m3g_read_u32(data, pos, data_size);
                int32_t height = (int32_t)m3g_read_u32(data, pos, data_size);

                m3g_set_int_field(img, "format", format);
                m3g_set_int_field(img, "width", width);
                m3g_set_int_field(img, "height", height);

                /* Sanity check dimensions */
                if (width > 0 && height > 0 && width <= 2048 && height <= 2048) {
                    /* Calculate pixel data size based on format */
                    int bytes_per_pixel = 0;
                    switch (format) {
                        /* M3G binary format constants */
                        case 0x10: bytes_per_pixel = 1; break;              /* ALPHA */
                        case 0x11: bytes_per_pixel = 1; break;              /* LUMINANCE */
                        case 0x12: bytes_per_pixel = 2; break;              /* LUMINANCE_ALPHA */
                        case 0x13: bytes_per_pixel = 3; break;              /* RGB */
                        case 0x14: bytes_per_pixel = 4; break;              /* RGBA */
                        /* Java API constants (Nokia H3T exporter) */
                        case 0x60: bytes_per_pixel = 1; break;              /* ALPHA */
                        case 0x61: bytes_per_pixel = 1; break;              /* LUMINANCE */
                        case 0x62: bytes_per_pixel = 2; break;              /* LUMINANCE_ALPHA */
                        case 0x63: bytes_per_pixel = 3; break;              /* RGB */
                        case 0x64: bytes_per_pixel = 4; break;              /* RGBA */
                        /* Packed formats */
                        case 0x90: case 0x91: bytes_per_pixel = 2; break;  /* RGB565, RGB555 */
                        case 0x92: bytes_per_pixel = 2; break;              /* RGBA4444 */
                        default:
                            fprintf(stderr, "[M3G-IMG] Unknown format 0x%02x, assuming 4 bpp\n", format);
                            bytes_per_pixel = 4; break;
                    }
                    int pixel_data_size = width * height * bytes_per_pixel;

                    /* Check for palette (format >= 0x80 && format <= 0x8F) */
                    if (format >= 0x80 && format <= 0x8F) {
                        /* Has palette: 3 or 4 byte entries */
                        if (*pos + 1 <= data_size) {
                            uint8_t palette_size_flag = m3g_read_u8(data, pos, data_size);
                            int palette_entry_size = (palette_size_flag & 1) ? 4 : 3;
                            int palette_entries = (palette_size_flag >> 1);
                            if (palette_entries <= 0) palette_entries = 256;
                            int palette_bytes = palette_entries * palette_entry_size;
                            pixel_data_size = palette_bytes + width * height; /* indexed: 1 byte per pixel */

                            /* Store palette data */
                            if (palette_bytes > 0 && palette_bytes < 65536 && *pos + palette_bytes <= data_size) {
                                JavaArray* palette_arr = jvm_new_array(jvm, T_BYTE, palette_bytes, NULL);
                                if (palette_arr) {
                                    void* dst = array_data(palette_arr);
                                    memcpy(dst, &data[*pos], palette_bytes);
                                    m3g_set_ref_field(img, "palette", (JavaObject*)palette_arr);
                                }
                            }
                            *pos += palette_bytes;
                        }
                    }

                    /* Read pixel data */
                    if (pixel_data_size > 0 && pixel_data_size < 16 * 1024 * 1024) {
                        size_t remaining = data_size - *pos;
                        if ((int)remaining >= pixel_data_size) {
                            /* Store as int[] for RGBA, or byte[] for other formats */
                            if (format == 0x14 || format == 0x64) { /* RGBA (M3G or Java API) */
                                JavaArray* pixels = jvm_new_array(jvm, T_INT, width * height, NULL);
                                if (pixels) {
                                    jint* dst = (jint*)array_data(pixels);
                                    uint8_t* src = (uint8_t*)&data[*pos];
                                    for (int p = 0; p < width * height; p++) {
                                        dst[p] = 0xFF000000 |
                                            (src[p * 4] << 16) |
                                            (src[p * 4 + 1] << 8) |
                                            src[p * 4 + 2];
                                        /* Use alpha from source */
                                        dst[p] = ((uint32_t)(src[p * 4 + 3]) <<  24) | (dst[p] & 0x00FFFFFF);
                                    }
                                    m3g_set_ref_field(img, "pixels", (JavaObject*)pixels);
                                }
                            } else if (format == 0x90) { /* RGB565 */
                                JavaArray* pixels = jvm_new_array(jvm, T_INT, width * height, NULL);
                                if (pixels) {
                                    jint* dst = (jint*)array_data(pixels);
                                    uint16_t* src = (uint16_t*)&data[*pos];
                                    for (int p = 0; p < width * height; p++) {
                                        uint16_t c = src[p];
                                        int r = ((c >> 11) & 0x1F) * 255 / 31;
                                        int g = ((c >> 5) & 0x3F) * 255 / 63;
                                        int b = (c & 0x1F) * 255 / 31;
                                        dst[p] = 0xFF000000 | (r << 16) | (g << 8) | b;
                                    }
                                    m3g_set_ref_field(img, "pixels", (JavaObject*)pixels);
                                }
                            } else if (format == 0x92) { /* RGBA4444 */
                                JavaArray* pixels = jvm_new_array(jvm, T_INT, width * height, NULL);
                                if (pixels) {
                                    jint* dst = (jint*)array_data(pixels);
                                    uint16_t* src = (uint16_t*)&data[*pos];
                                    for (int p = 0; p < width * height; p++) {
                                        uint16_t c = src[p];
                                        int a = ((c >> 12) & 0xF) * 255 / 15;
                                        int r = ((c >> 8) & 0xF) * 255 / 15;
                                        int g = ((c >> 4) & 0xF) * 255 / 15;
                                        int b = (c & 0xF) * 255 / 15;
                                        dst[p] = ((uint32_t)(a) <<  24) | (r << 16) | (g << 8) | b;
                                    }
                                    m3g_set_ref_field(img, "pixels", (JavaObject*)pixels);
                                }
                            } else if (format == 0x13 || format == 0x63) { /* RGB (M3G or Java API) */
                                JavaArray* pixels = jvm_new_array(jvm, T_INT, width * height, NULL);
                                if (pixels) {
                                    jint* dst = (jint*)array_data(pixels);
                                    uint8_t* src = (uint8_t*)&data[*pos];
                                    for (int p = 0; p < width * height; p++) {
                                        dst[p] = 0xFF000000 |
                                            (src[p * 3] << 16) |
                                            (src[p * 3 + 1] << 8) |
                                            src[p * 3 + 2];
                                    }
                                    m3g_set_ref_field(img, "pixels", (JavaObject*)pixels);
                                }
                            } else {
                                /* Generic: store raw bytes */
                                JavaArray* pixels = jvm_new_array(jvm, T_BYTE, pixel_data_size, NULL);
                                if (pixels) {
                                    void* dst = array_data(pixels);
                                    memcpy(dst, &data[*pos], pixel_data_size);
                                    m3g_set_ref_field(img, "pixels", (JavaObject*)pixels);
                                }
                            }
                        }
                    }
                    /* For palette-based formats, pos was already advanced above
                     * (palette_bytes + pixel data). pixel_data_size includes palette,
                     * so only advance by the non-palette part. */
                    if (format >= 0x80 && format <= 0x8F) {
                        *pos += width * height;  /* only pixel indices */
                    } else {
                        *pos += pixel_data_size;
                    }
                }

                GFX_DEBUG("M3G: Created Image2D userID=%u fmt=0x%02X %dx%d",
                         user_id, format, width, height);
            }
            return img;
        }

        case M3G_OBJ_TEXTURE2D: {
            JavaClass* tex_class = jvm_load_class(jvm, "javax/microedition/m3g/Texture2D");
            if (!tex_class) return NULL;

            JavaObject* tex = jvm_new_object(jvm, tex_class);
            if (tex) {
                m3g_set_userID(tex, user_id);

                size_t pos_before_obj3d = *pos;
                /* Object3D data */
                m3g_read_object3d_data(tex, data, data_size, pos, ctx);
                size_t pos_after_obj3d = *pos;

                /* Texture2D-specific per JSR-184 spec */
                size_t pos_before_imgref = *pos;
                uint32_t image_ref = m3g_read_u32(data, pos, data_size);
                uint8_t blend_s = m3g_read_u8(data, pos, data_size);
                uint8_t blend_t = m3g_read_u8(data, pos, data_size);
                (void)m3g_read_u8(data, pos, data_size); /* wrappingS */
                (void)m3g_read_u8(data, pos, data_size); /* wrappingT */
                uint8_t level_filter = m3g_read_u8(data, pos, data_size);
                uint8_t image_filter = m3g_read_u8(data, pos, data_size);

                /* DIAG: Log full hex dump of this Texture2D object for debugging */
                fprintf(stderr, "[M3G-TEX-PARSE] Texture2D userID=%u: obj3d_bytes=%zu, imgRef_pos=%zu\n",
                        user_id, pos_after_obj3d - pos_before_obj3d, pos_before_imgref);
                fprintf(stderr, "[M3G-TEX-PARSE]   imageRef_LE=%u (0x%08x), blend=%d/%d, filter=%d/%d\n",
                        image_ref, image_ref, blend_s, blend_t, level_filter, image_filter);
                /* Dump 32 bytes starting from pos_before_obj3d (the Object3D data start) */
                fprintf(stderr, "[M3G-TEX-PARSE]   hex dump from obj3d start (pos=%zu):\n    ", pos_before_obj3d);
                for (int rb = 0; rb < 32 && pos_before_obj3d + rb < data_size; rb++) {
                    fprintf(stderr, "%02x ", data[pos_before_obj3d + rb]);
                    if ((rb + 1) % 16 == 0) fprintf(stderr, "\n    ");
                }
                fprintf(stderr, "\n");

                /* Store image reference as int for later linking */
                m3g_set_int_field(tex, "imageRef", image_ref);
                m3g_set_int_field(tex, "blendS", blend_s);
                m3g_set_int_field(tex, "blendT", blend_t);
                m3g_set_int_field(tex, "filtering", level_filter | (image_filter << 4));
            }
            return tex;
        }

        case M3G_OBJ_SPRITE3D: {
            JavaClass* sprite_class = jvm_load_class(jvm, "javax/microedition/m3g/Sprite3D");
            if (!sprite_class) return NULL;

            JavaObject* sprite = jvm_new_object(jvm, sprite_class);
            if (sprite) {
                m3g_set_userID(sprite, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Sprite3D */
                m3g_read_object3d_data(sprite, data, data_size, pos, ctx);
                m3g_read_transformable_data(sprite, data, data_size, pos, jvm);
                m3g_read_node_data(sprite, data, data_size, pos);

                /* Sprite3D-specific per JSR-184 spec */
                uint8_t scaled = m3g_read_u8(data, pos, data_size);
                uint32_t image_ref = m3g_read_u32(data, pos, data_size);
                int32_t crop_x = (int32_t)m3g_read_u32(data, pos, data_size);
                int32_t crop_y = (int32_t)m3g_read_u32(data, pos, data_size);
                int32_t crop_w = (int32_t)m3g_read_u32(data, pos, data_size);
                int32_t crop_h = (int32_t)m3g_read_u32(data, pos, data_size);

                m3g_set_int_field(sprite, "scaled", scaled);
                m3g_set_int_field(sprite, "imageRef", image_ref);
                m3g_set_int_field(sprite, "cropX", crop_x);
                m3g_set_int_field(sprite, "cropY", crop_y);
                m3g_set_int_field(sprite, "cropWidth", crop_w);
                m3g_set_int_field(sprite, "cropHeight", crop_h);

                GFX_DEBUG("M3G: Created Sprite3D userID=%u scaled=%d crop=(%d,%d,%d,%d)",
                         user_id, scaled, crop_x, crop_y, crop_w, crop_h);
            }
            return sprite;
        }

        case M3G_OBJ_MORPHINGMESH: {
            /* MorphingMesh extends Mesh - parse like Mesh, then add morph targets */
            JavaClass* mm_class = jvm_load_class(jvm, "javax/microedition/m3g/MorphingMesh");
            if (!mm_class) {
                /* Fallback: use Mesh class */
                mm_class = jvm_load_class(jvm, "javax/microedition/m3g/Mesh");
            }
            if (!mm_class) return NULL;

            JavaObject* mm = jvm_new_object(jvm, mm_class);
            if (mm) {
                m3g_set_userID(mm, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Mesh */
                m3g_read_object3d_data(mm, data, data_size, pos, ctx);
                m3g_read_transformable_data(mm, data, data_size, pos, jvm);
                m3g_read_node_data(mm, data, data_size, pos);

                /* Mesh-specific data */
                uint32_t vb_ref = m3g_read_u32(data, pos, data_size);
                uint32_t submesh_count = m3g_read_u32(data, pos, data_size);
                uint32_t ib_ref = 0, app_ref = 0;
                for (uint32_t i = 0; i < submesh_count; i++) {
                    uint32_t this_ib = m3g_read_u32(data, pos, data_size);
                    uint32_t this_app = m3g_read_u32(data, pos, data_size);
                    if (i == 0) { ib_ref = this_ib; app_ref = this_app; }
                }
                m3g_set_int_field(mm, "vertexBufferRef", vb_ref);
                m3g_set_int_field(mm, "submeshCount", submesh_count);
                m3g_set_int_field(mm, "indexBufferRef", ib_ref);
                m3g_set_int_field(mm, "appearanceRef", app_ref);

                /* MorphingMesh-specific: morph target count and references */
                uint32_t morph_target_count = m3g_read_u32(data, pos, data_size);
                for (uint32_t i = 0; i < morph_target_count; i++) {
                    m3g_read_u32(data, pos, data_size); /* morph target VertexBuffer ref */
                }
                /* Morph weights: startWeight + endWeight per morph target */
                float start_weight = m3g_read_float(data, pos, data_size);
                float end_weight = m3g_read_float(data, pos, data_size);
                (void)start_weight; (void)end_weight;

                ctx->mesh = mm;
                GFX_DEBUG("M3G: Created MorphingMesh userID=%u submeshes=%u morphTargets=%u",
                         user_id, submesh_count, morph_target_count);
            }
            return mm;
        }

        case M3G_OBJ_SKINNEDMESH: {
            /* SkinnedMesh extends Mesh - parse like Mesh, then add skeleton/bones */
            JavaClass* sm_class = jvm_load_class(jvm, "javax/microedition/m3g/SkinnedMesh");
            if (!sm_class) {
                /* Fallback: use Mesh class */
                sm_class = jvm_load_class(jvm, "javax/microedition/m3g/Mesh");
            }
            if (!sm_class) return NULL;

            JavaObject* sm = jvm_new_object(jvm, sm_class);
            if (sm) {
                m3g_set_userID(sm, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Mesh */
                m3g_read_object3d_data(sm, data, data_size, pos, ctx);
                m3g_read_transformable_data(sm, data, data_size, pos, jvm);
                m3g_read_node_data(sm, data, data_size, pos);

                /* Mesh-specific data */
                uint32_t vb_ref = m3g_read_u32(data, pos, data_size);
                uint32_t submesh_count = m3g_read_u32(data, pos, data_size);
                uint32_t ib_ref = 0, app_ref = 0;
                for (uint32_t i = 0; i < submesh_count; i++) {
                    uint32_t this_ib = m3g_read_u32(data, pos, data_size);
                    uint32_t this_app = m3g_read_u32(data, pos, data_size);
                    if (i == 0) { ib_ref = this_ib; app_ref = this_app; }
                }
                m3g_set_int_field(sm, "vertexBufferRef", vb_ref);
                m3g_set_int_field(sm, "submeshCount", submesh_count);
                m3g_set_int_field(sm, "indexBufferRef", ib_ref);
                m3g_set_int_field(sm, "appearanceRef", app_ref);

                uint32_t skeleton_ref = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(sm, "skeletonRef", skeleton_ref);

                /* Weighted bone->vertex-range bindings per the reference m3g
                 * loader (J2ME-Loader m3g_loader.c m3gLoadSkinnedMesh):
                 * transformReferenceCount, then per binding (boneRef,
                 * firstVertex, vertexCount, weight) as 4×u32. The old code
                 * read a bogus bone_count (actually the first bone ref) then
                 * 2×u32 per "bone" - derailing the stream and discarding the
                 * skin binding, which left every SkinnedMesh rendering
                 * unskinned bind-pose vertices (SU-30: plane invisible
                 * ~5000 units from the chase camera). */
                uint32_t ref_count = m3g_read_u32(data, pos, data_size);
                if (ref_count > 256) ref_count = 256;

                uint32_t bone_refs[256];
                uint32_t bone_first[256];
                uint32_t bone_ranges[256];
                uint32_t bone_weights[256];
                for (uint32_t i = 0; i < ref_count; i++) {
                    bone_refs[i]    = m3g_read_u32(data, pos, data_size);
                    bone_first[i]   = m3g_read_u32(data, pos, data_size);
                    bone_ranges[i]  = m3g_read_u32(data, pos, data_size);
                    bone_weights[i] = m3g_read_u32(data, pos, data_size);
                }
                uint32_t nbones = ref_count;

                /* Persist bindings on the stub for the renderer/linker */
                JavaArray* refs_arr = nbones ? jvm_new_array(jvm, T_INT, (jsize)nbones, NULL) : NULL;
                JavaArray* first_arr = nbones ? jvm_new_array(jvm, T_INT, (jsize)nbones, NULL) : NULL;
                JavaArray* cnt_arr = nbones ? jvm_new_array(jvm, T_INT, (jsize)nbones, NULL) : NULL;
                JavaArray* wgt_arr = nbones ? jvm_new_array(jvm, T_INT, (jsize)nbones, NULL) : NULL;
                if (refs_arr) memcpy(array_data(refs_arr), bone_refs, nbones * sizeof(jint));
                if (first_arr) memcpy(array_data(first_arr), bone_first, nbones * sizeof(jint));
                if (cnt_arr) memcpy(array_data(cnt_arr), bone_ranges, nbones * sizeof(jint));
                if (wgt_arr) memcpy(array_data(wgt_arr), bone_weights, nbones * sizeof(jint));
                if (refs_arr) m3g_set_ref_field(sm, "boneNodeRefs", (JavaObject*)refs_arr);
                if (first_arr) m3g_set_ref_field(sm, "boneFirstVertex", (JavaObject*)first_arr);
                if (cnt_arr) m3g_set_ref_field(sm, "boneVertexCount", (JavaObject*)cnt_arr);
                if (wgt_arr) m3g_set_ref_field(sm, "boneWeights", (JavaObject*)wgt_arr);

                ctx->mesh = sm;
                GFX_DEBUG("M3G: Created SkinnedMesh userID=%u submeshes=%u bones=%u skelRef=%u",
                         user_id, submesh_count, nbones, skeleton_ref);
            }
            return sm;
        }

        case M3G_OBJ_GROUP: {
            JavaClass* group_class = jvm_load_class(jvm, "javax/microedition/m3g/Group");
            if (!group_class) return NULL;

            JavaObject* group = jvm_new_object(jvm, group_class);
            if (group) {
                m3g_set_userID(group, user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Group */
                m3g_read_object3d_data(group, data, data_size, pos, ctx);
                m3g_read_transformable_data(group, data, data_size, pos, jvm);
                m3g_read_node_data(group, data, data_size, pos);
                m3g_read_group_data(group, data, data_size, pos, jvm);

                GFX_DEBUG("M3G: Created Group userID=%u", user_id);
            }
            return group;
        }

        default:
            /* Skip unknown object types */
            GFX_DEBUG("M3G: Skipping unknown object type %d userID=%u", obj_type, user_id);
            return NULL;
    }
}

/* Loader.load(String name) - M3G file loading with correct section parsing */
/* ========================================================================
 * v14: resolve the (target, trackRef) pairs collected from Object3D
 * headers: append every AnimationTrack to its owner's "animTracks" array
 * and make sure each track's sequence/controller references are set.
 * This is what makes keyframe animation stored inside .m3g files actually
 * run (M3GTest scene 7, game cut-scene/unit animation).
 * ======================================================================== */
static void m3g_link_animation_tracks(JVM* jvm, M3GParseContext* ctx) {
    if (!ctx || !ctx->track_links || ctx->track_link_count == 0) return;

    int linked = 0;
    for (int i = 0; i < ctx->track_link_count; i++) {
        JavaObject* target = ctx->track_links[i].target;
        uint32_t tref = ctx->track_links[i].track_ref;
        int tidx = (int)tref - 2;
        if (!target || tref == 0 || tidx < 0 || tidx >= ctx->object_count) continue;
        JavaObject* track = ctx->objects[tidx];
        if (!track || !track->header.clazz) continue;

        /* Late-resolve the track's sequence/controller if the immediate
         * resolution in the parser missed (forward refs, order quirks) */
        if (!m3g_get_ref_field(track, "sequence")) {
            int sref = m3g_get_int_field(track, "sequenceRef", 0);
            int sidx = sref - 2;
            if (sref > 0 && sidx >= 0 && sidx < ctx->object_count && ctx->objects[sidx]) {
                m3g_set_ref_field(track, "sequence", ctx->objects[sidx]);
            }
        }
        if (!m3g_get_ref_field(track, "controller")) {
            int cref = m3g_get_int_field(track, "controllerRef", 0);
            int cidx = cref - 2;
            if (cref > 0 && cidx >= 0 && cidx < ctx->object_count && ctx->objects[cidx]) {
                m3g_set_ref_field(track, "controller", ctx->objects[cidx]);
            }
        }

        /* Append the track to the target's animTracks array (same layout
         * as native_object3d_addAnimationTrack: Object[] with empty slots) */
        JavaArray* tracks = (JavaArray*)m3g_get_ref_field(target, "animTracks");
        if (!tracks || tracks->element_type != DESC_OBJECT) {
            tracks = jvm_new_array(jvm, DESC_OBJECT, 8, NULL);
            if (tracks) m3g_set_ref_field(target, "animTracks", (JavaObject*)tracks);
        }
        if (tracks && tracks->element_type == DESC_OBJECT) {
            JavaObject** arr = (JavaObject**)array_data(tracks);
            int placed = 0;
            /* Skip duplicate links (same track twice) */
            for (jsize s = 0; s < tracks->length; s++) {
                if (arr[s] == track) { placed = 1; break; }
            }
            if (!placed) {
                for (jsize s = 0; s < tracks->length; s++) {
                    if (arr[s] == NULL) { arr[s] = track; placed = 1; break; }
                }
            }
            if (placed) linked++;
        }
    }
    fprintf(stderr, "[M3G-ANIM] animation tracks linked: %d/%d\n",
            linked, ctx->track_link_count);
    free(ctx->track_links);
    ctx->track_links = NULL;
    ctx->track_link_count = 0;
    ctx->track_link_capacity = 0;
}

/* FIX: Completely rewritten to match JSR-184 M3G specification */
static JavaValue native_loader_load(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* name_str = (JavaString*)args[0].ref;

    /* Resources that need cleanup */
    uint8_t* data = NULL;
    uint8_t* decompressed = NULL;
    JavaObject** objects = NULL;
    JavaArray* result = NULL;

    /* Result variables */
    JavaClass* world_class = NULL;
    JavaClass* camera_class = NULL;
    JavaClass* bg_class = NULL;
    JavaClass* light_class = NULL;

    /* Parse context - objects stored sequentially, M3G refs are: ref-2 = array index */
    M3GParseContext ctx = {0};
    ctx.object_count = 0;     /* Objects stored sequentially starting at index 0 */
    ctx.header_seen = 0;       /* Will be set to 0 when header is seen */
    ctx.objects_start_index = 0;  /* Index where actual objects start */
    ctx.object_capacity = 512;
    ctx.objects = calloc(ctx.object_capacity, sizeof(JavaObject*));
    objects = ctx.objects;  /* Track for cleanup */

    /* Helper: ensure objects array has capacity for one more entry */
    #define M3G_ENSURE_CAPACITY(ctx) do { \
        if ((ctx)->object_count >= (ctx)->object_capacity) { \
            int new_cap = (ctx)->object_capacity * 2; \
            JavaObject** new_arr = realloc((ctx)->objects, new_cap * sizeof(JavaObject*)); \
            if (new_arr) { \
                memset(new_arr + (ctx)->object_capacity, 0, (new_cap - (ctx)->object_capacity) * sizeof(JavaObject*)); \
                (ctx)->objects = new_arr; \
                (ctx)->object_capacity = new_cap; \
                objects = new_arr; \
                fprintf(stderr, "[M3G] Expanded objects array to %d\n", new_cap); \
            } \
        } \
    } while(0)

    /* NOTE: Do NOT clear the global M3G object registry here!
     * Games load multiple M3G files (su30.m3g, models.m3g, models_add.m3g)
     * and use find(userID) to locate objects across files.
     * Clearing the registry on each load causes find() to fail for objects
     * from previously loaded files. */

    if (!ctx.objects) {
        GFX_DEBUG("Loader.load: Failed to allocate objects array");
        goto cleanup_error;
    }

    if (!name_str) {
        GFX_DEBUG("Loader.load: null name string");
        goto cleanup_error;
    }

    const char* name = string_utf8(jvm, name_str);
    fprintf(stderr, "[M3G] Loader.load: '%s'\n", name ? name : "NULL");

    if (!name) {
        goto cleanup_error;
    }

    /* Skip leading slash if present */
    const char* resource_name = name;
    if (resource_name[0] == '/') {
        resource_name++;
    }

    /* Try to load from JAR */
    size_t data_size;
    data = load_jar_resource(resource_name, &data_size);

    if (!data) {
        fprintf(stderr, "[M3G] Loader.load: file '%s' not found in JAR\n", resource_name);
        /* Still create a World even if file not found - game might use default */
    } else {
        GFX_DEBUG("Loader.load: loaded %zu bytes from '%s'", data_size, resource_name);
        fprintf(stderr, "[M3G] Loaded '%s' (%zu bytes)\n", resource_name, data_size);
    }

    /* =====================================================================
     * v14: JSR-184 §Loader.load — PNG images load as Image2D[1].
     * Nescube stores its cube texture (res/bin/texture.res) as a PLAIN PNG
     * and does `(Image2D) Loader.load(...)[0]`. Without this branch the
     * load threw IOException, the game fell back to a black material and
     * the cube rendered BLACK. Decode via the MIDP image decoder.
     * ===================================================================== */
    if (data && data_size >= 8 &&
        data[0] == 0x89 && data[1] == 0x50 && data[2] == 0x4E && data[3] == 0x47) {
        extern MidpImage* midp_image_create_from_data(const uint8_t* data, int offset, int length);
        MidpImage* pimg = midp_image_create_from_data(data, 0, (int)data_size);
        free(data);
        data = NULL;
        if (!pimg || pimg->width <= 0 || pimg->height <= 0) {
            fprintf(stderr, "[M3G] Loader.load: PNG decode failed\n");
            jvm_throw_by_name(jvm, "java/io/IOException", "Invalid PNG image");
            goto cleanup_error;
        }
        {
            JavaClass* i2d_class = jvm_load_class(jvm, "javax/microedition/m3g/Image2D");
            if (!i2d_class) {
                midp_image_destroy(pimg);
                goto cleanup_error;
            }
            JavaObject* i2d = jvm_new_object(jvm, i2d_class);
            if (!i2d) {
                midp_image_destroy(pimg);
                goto cleanup_error;
            }
            int pw = pimg->width, ph = pimg->height;
            JavaArray* px = jvm_new_array(jvm, T_INT, pw * ph, NULL);
            if (px) {
                jint* dst = (jint*)array_data(px);
                for (int i = 0; i < pw * ph; i++) {
                    dst[i] = (jint)pimg->pixels[i];  /* ARGB == ARGB */
                }
                m3g_set_ref_field(i2d, "pixels", (JavaObject*)px);
                m3g_set_int_field(i2d, "width", pw);
                m3g_set_int_field(i2d, "height", ph);
                m3g_set_int_field(i2d, "format", 100 /* RGBA (Java API constant) */);
            }
            midp_image_destroy(pimg);

            result = jvm_new_array(jvm, DESC_OBJECT, 1, NULL);
            if (result) {
                ((JavaObject**)array_data(result))[0] = i2d;
            }
            fprintf(stderr, "[M3G] Loader.load: PNG '%s' loaded as Image2D %dx%d\n",
                    resource_name, pw, ph);
        }
        if (result) {
            if (objects) free(objects);
            return NATIVE_RETURN_OBJECT(result);
        }
        goto cleanup_error;
    }

    /* Parse M3G file if we have data */
    if (data && data_size >= 12) {
        /* Check M3G magic: 0xAB 'J' 'S' 'R' '1' '8' '4' 0xBB 0x0D 0x0A 0x1A 0x0A */
        if (data[0] == M3G_MAGIC1 && 
            strncmp((char*)&data[1], "JSR184", 6) == 0 && 
            data[7] == M3G_MAGIC2 &&
            data[8] == 0x0D && data[9] == 0x0A &&
            data[10] == 0x1A && data[11] == 0x0A) {
            
            fprintf(stderr, "[M3G] Loader.load: Valid M3G file, size=%zu\n", data_size);
            
            /* Clear texture caches before parsing new M3G file */
            m3g_clear_tex_image_map();
            m3g_clear_texture_cache();
            
            size_t file_pos = 12;  /* Start after magic identifier */
            int section_count = 0;
            int current_section = 0;
            uint32_t total_file_size = 0;
            
            /* Parse sections according to M3G spec */
            while (file_pos + 13 <= data_size && section_count < 100) {
                /* Read section header */
                uint8_t compression_scheme = data[file_pos++];
                uint32_t total_section_length = data[file_pos] | (data[file_pos+1] << 8) | 
                                                (data[file_pos+2] << 16) | ((uint32_t)(data[file_pos+3]) <<  24);
                file_pos += 4;
                uint32_t uncompressed_length = data[file_pos] | (data[file_pos+1] << 8) | 
                                               (data[file_pos+2] << 16) | ((uint32_t)(data[file_pos+3]) <<  24);
                file_pos += 4;
                
                GFX_DEBUG("M3G: Section %d: compression=%d, totalLen=%u, uncompressedLen=%u",
                         section_count, compression_scheme, total_section_length, uncompressed_length);
                
                /* Store current section in context for object parsing */
                ctx.current_section = current_section;
                
                /* Sanity check: section length must be reasonable */
                if (total_section_length < 13 || total_section_length > data_size) {
                    GFX_DEBUG("M3G: Invalid section length %u, stopping", total_section_length);
                    break;
                }
                
                /* Calculate section data boundaries */
                size_t section_data_start = file_pos;
                size_t section_data_size = total_section_length - 13;  /* Minus header and checksum */
                
                /* Get section data (decompress if needed) */
                uint8_t* section_data;
                size_t section_data_len;
                
                if (compression_scheme == 0) {
                    /* Uncompressed section */
                    section_data = &data[section_data_start];
                    section_data_len = section_data_size;
                } else if (compression_scheme == 1) {
                    /* Zlib compressed section */
                    section_data = m3g_decompress(&data[section_data_start], section_data_size, &section_data_len);
                    decompressed = section_data;  /* Track for cleanup */
                    
                    if (!section_data || section_data_len != uncompressed_length) {
                        GFX_DEBUG("M3G: Decompression failed or size mismatch (got %zu, expected %u)",
                                 section_data_len, uncompressed_length);
                        if (section_data) {
                            free(section_data);
                            decompressed = NULL;
                        }
                        goto next_section;
                    }
                } else {
                    GFX_DEBUG("M3G: Unknown compression scheme %d", compression_scheme);
                    goto next_section;
                }
                
                /* Parse objects within section */
                if (section_data && section_data_len > 0) {
                    size_t obj_pos = 0;
                    
                    while (obj_pos < section_data_len) {
                        /* Read object type and length */
                        if (obj_pos + 5 > section_data_len) break;
                        
                        uint8_t obj_type = section_data[obj_pos++];
                        uint32_t obj_length = section_data[obj_pos] | (section_data[obj_pos+1] << 8) |
                                            (section_data[obj_pos+2] << 16) | ((uint32_t)(section_data[obj_pos+3]) <<  24);
                        obj_pos += 4;
                        
                        GFX_DEBUG("M3G: Object type=%d length=%u at pos=%zu", 
                                 obj_type, obj_length, obj_pos - 5);
                        
                        /* Validate object length */
                        if (obj_length == 0 || obj_pos + obj_length > section_data_len) {
                            GFX_DEBUG("M3G: Invalid object length %u, skipping", obj_length);
                            break;
                        }
                        
                        /* Parse object based on type */
                        size_t obj_start = obj_pos;
                        
                        GFX_DEBUG("M3G: Object type=%d len=%u at offset %zu", 
                                 obj_type, obj_length, obj_start);
                        
                        switch (obj_type) {
                            case 0:  /* Header Object (inside first section) */
                                /* FIX: Header must only be in section 0 */
                                if (current_section != 0) {
                                    GFX_DEBUG("M3G ERROR: Header object in wrong section %d!", current_section);
                                    fprintf(stderr, "[M3G] ERROR: Header in wrong section %d\n", current_section);
                                    obj_pos += obj_length;
                                    break;
                                }
                                if (ctx.header_seen) {
                                    GFX_DEBUG("M3G ERROR: Duplicate header!");
                                    fprintf(stderr, "[M3G] ERROR: Duplicate header\n");
                                    obj_pos += obj_length;
                                    break;
                                }
                                ctx.header_seen = 1;
                                
                                if (obj_length >= 7) {
                                    uint8_t version_major = section_data[obj_pos++];
                                    uint8_t version_minor = section_data[obj_pos++];
                                    /* hasExternalReferences */ uint8_t has_ext_refs = section_data[obj_pos++];
                                    ctx.external_links = has_ext_refs;
                                    total_file_size = section_data[obj_pos] | (section_data[obj_pos+1] << 8) |
                                                     (section_data[obj_pos+2] << 16) | ((uint32_t)(section_data[obj_pos+3]) <<  24);
                                    obj_pos += 4;
                                    /* approximateContentSize */ obj_pos += 4;
                                    /* authoringField (string) - skip null-terminated string */
                                    while (obj_pos < section_data_len && section_data[obj_pos] != 0) {
                                        obj_pos++;
                                    }
                                    if (obj_pos < section_data_len) obj_pos++;  /* Skip null terminator */
                                    
                                    GFX_DEBUG("M3G: Header v%d.%d totalSize=%u hasExternalRefs=%d",
                                             version_major, version_minor, total_file_size, has_ext_refs);
                                    fprintf(stderr, "[M3G] Header v%d.%d totalSize=%u\n", 
                                            version_major, version_minor, total_file_size);
                                }
                                /* FIX: Do NOT store NULL for header - this breaks indexing! */
                                /* According to JSR-184: ref 0 = null, ref N = objects[N-2] */
                                /* So we don't increment object_count for header */
                                GFX_DEBUG("M3G: Header parsed, objects will start at index 0");
                                break;
                                
                            case 255:  /* External Reference */
                                /* FIX: External reference must only be in section 1 */
                                if (current_section != 1) {
                                    GFX_DEBUG("M3G ERROR: External reference in wrong section %d!", current_section);
                                    fprintf(stderr, "[M3G] ERROR: External reference in wrong section %d\n", current_section);
                                }
                                GFX_DEBUG("M3G: External reference, skipping %u bytes", obj_length);
                                obj_pos += obj_length;
                                /* External references are NOT stored in the objects array */
                                /* They don't increment object_count */
                                break;

                            /* v14: M3G_OBJ_ANIMATIONCONTROLLER / _TRACK /
                             * _KEYFRAMESEQUENCE are no longer skipped here —
                             * they fall through to the default case and are
                             * parsed by m3g_parse_object, preserving file
                             * animation (M3GTest scene 7, game cut-scenes). */

                            default: {
                                /* Parse object - returns object or NULL */
                                size_t saved_pos = obj_pos;
                                JavaObject* parsed = m3g_parse_object(jvm, &ctx, section_data, section_data_len, &obj_pos, obj_type, obj_length);
                                if (!parsed) {
                                    /* If parsing failed, skip the object data */
                                    obj_pos = saved_pos + obj_length;
                                }
                                /* CRITICAL: Always increment count to preserve indices */
                                /* Store object (or NULL if parsing failed) */
                                M3G_ENSURE_CAPACITY(&ctx);
                                ctx.objects[ctx.object_count] = parsed;  /* May be NULL */
                                ctx.object_count++;
                                GFX_DEBUG("M3G: Stored %s at array[%d] (M3G ref=%d) -> %p",
                                         parsed ? "object" : "NULL", ctx.object_count - 1, 
                                         ctx.object_count + 1, (void*)parsed);
                                break;
                            }
                        }
                        
                        /* Always ensure we move past this object */
                        obj_pos = obj_start + obj_length;
                        
                        /* Safety check */
                        if (obj_pos > section_data_len) {
                            GFX_DEBUG("M3G: obj_pos %zu > section_data_len %zu, breaking", 
                                     obj_pos, section_data_len);
                            break;
                        }
                    }
                }
                
                /* Free decompressed data if we allocated it */
                if (compression_scheme == 1 && section_data) {
                    free(section_data);
                    decompressed = NULL;
                }
                
            next_section:
                /* Move to next section (skip checksum at end) */
                file_pos = section_data_start + section_data_size + 4;  /* +4 for checksum */
                section_count++;
                current_section++;
            }
            
            fprintf(stderr, "[M3G] Parsed %d sections, %d objects\n", section_count, ctx.object_count);
        } else {
            fprintf(stderr, "[M3G] Loader.load: Invalid M3G magic\n");
            /* FIX(spec): JSR-184 §Loader requires IOException for non-M3G data.
             * Nescube feeds a custom texture.res blob through Loader.load and
             * REQUIRES the exception path (catch Throwable -> printStackTrace);
             * fabricating a default World here leaked it into a Texture2D cast,
             * killing the title thread with ClassCastException. */
            jvm_throw_by_name(jvm, "java/io/IOException", "Not a valid M3G file");
            goto cleanup_error;
        }
    } else if (data) {
            fprintf(stderr, "[M3G] Data too small (%zu bytes)\n", data_size);
            jvm_throw_by_name(jvm, "java/io/IOException", "Truncated M3G file");
            goto cleanup_error;
    } else {
        /* v19 FIX (JSR-184 §9.6): Loader.load throws IOException when the
         * resource cannot be FOUND. Fabricating a default World here leaked
         * a World object into code that casts the result to Image2D
         * (Nescube: "(Image2D) Loader.load(\"/res/bin/texture.res\")[0]"),
         * producing ClassCastException in the title thread. Games already
         * catch Throwable around Loader.load — give them the spec exception
         * instead of a wrong-typed return. */
        fprintf(stderr, "[M3G] Loader.load: resource not found, throwing IOException (JSR-184)\n");
        jvm_throw_by_name(jvm, "java/io/IOException", "Resource not found");
        goto cleanup_error;
    }

    /* Link objects by indices */
    /* FIX: M3G reference system per JSR-184 specification:
     *   ref 0 = null
     *   ref N = objects[N-2]  (NOT objects[N]!)
     * 
     * This is because Header (file position 0) is not stored,
     * and objects start at file position 2 (after header).
     * So when file says "reference 5", it means the object at file position 5,
     * which is stored at array index 5-2=3.
     */
    GFX_DEBUG("Loader.load: Linking %d objects...", ctx.object_count);
    for (int i = 0; i < ctx.object_count; i++) {
        JavaObject* obj = ctx.objects[i];
        if (!obj || !obj->header.clazz) continue;

        const char* class_name = obj->header.clazz->class_name;

        /* Link Mesh (and subclasses SkinnedMesh/MorphingMesh) to VertexBuffer, IndexBuffer, Appearance */
        if (strstr(class_name, "Mesh")) {
            int vb_ref = m3g_get_int_field(obj, "vertexBufferRef", 0);
            int ib_ref = m3g_get_int_field(obj, "indexBufferRef", 0);
            int app_ref = m3g_get_int_field(obj, "appearanceRef", 0);

            /* FIX: M3G reference: ref N = objects[N-2] */
            int vb_idx = vb_ref - 2;
            int ib_idx = ib_ref - 2;
            int app_idx = app_ref - 2;
            
            if (vb_ref > 0 && vb_idx >= 0 && vb_idx < ctx.object_count && ctx.objects[vb_idx]) {
                m3g_set_ref_field(obj, "vertexBuffer", ctx.objects[vb_idx]);
                GFX_DEBUG("M3G: Linked Mesh VB[ref=%d idx=%d] -> %p", vb_ref, vb_idx, ctx.objects[vb_idx]);
            } else if (vb_ref > 0) {
                GFX_DEBUG("M3G: WARNING: Mesh VB ref=%d idx=%d not found (count=%d)", vb_ref, vb_idx, ctx.object_count);
            }
            
            if (ib_ref > 0 && ib_idx >= 0 && ib_idx < ctx.object_count && ctx.objects[ib_idx]) {
                m3g_set_ref_field(obj, "indexBuffer", ctx.objects[ib_idx]);
                GFX_DEBUG("M3G: Linked Mesh IB[ref=%d idx=%d] -> %p", ib_ref, ib_idx, ctx.objects[ib_idx]);
            }
            
            if (app_ref > 0 && app_idx >= 0 && app_idx < ctx.object_count && ctx.objects[app_idx]) {
                m3g_set_ref_field(obj, "appearance", ctx.objects[app_idx]);
                GFX_DEBUG("M3G: Linked Mesh App[ref=%d idx=%d] -> %p", app_ref, app_idx, ctx.objects[app_idx]);
            }
        }

        /* Link VertexBuffer to VertexArrays */
        if (strstr(class_name, "VertexBuffer")) {
            int pos_ref = m3g_get_int_field(obj, "positionsRef", 0);
            int norm_ref = m3g_get_int_field(obj, "normalsRef", 0);
            int color_ref = m3g_get_int_field(obj, "colorsRef", 0);
            int tex_ref = m3g_get_int_field(obj, "texCoordsRef", 0);

            /* FIX: M3G reference: ref N = objects[N-2] */
            int pos_idx = pos_ref - 2;
            int norm_idx = norm_ref - 2;
            int color_idx = color_ref - 2;
            int tex_idx = tex_ref - 2;
            
            if (pos_ref > 0 && pos_idx >= 0 && pos_idx < ctx.object_count && ctx.objects[pos_idx]) {
                JavaObject* pos_obj = ctx.objects[pos_idx];
                int pos_comp = m3g_get_int_field(pos_obj, "componentCount", -1);
                int pos_vc = m3g_get_int_field(pos_obj, "vertexCount", -1);
                m3g_set_ref_field(obj, "positions", pos_obj);
                fprintf(stderr, "[M3G-LINK] VB %p: positions[ref=%d idx=%d] -> %p (comp=%d, verts=%d)\n",
                        (void*)obj, pos_ref, pos_idx, (void*)pos_obj, pos_comp, pos_vc);
                GFX_DEBUG("M3G: Linked VertexBuffer positions[ref=%d idx=%d]", pos_ref, pos_idx);
            }
            if (norm_ref > 0 && norm_idx >= 0 && norm_idx < ctx.object_count && ctx.objects[norm_idx]) {
                m3g_set_ref_field(obj, "normals", ctx.objects[norm_idx]);
                GFX_DEBUG("M3G: Linked VertexBuffer normals[ref=%d idx=%d]", norm_ref, norm_idx);
            }
            if (color_ref > 0 && color_idx >= 0 && color_idx < ctx.object_count && ctx.objects[color_idx]) {
                m3g_set_ref_field(obj, "colors", ctx.objects[color_idx]);
                GFX_DEBUG("M3G: Linked VertexBuffer colors[ref=%d idx=%d]", color_ref, color_idx);
            }
            if (tex_ref > 0 && tex_idx >= 0 && tex_idx < ctx.object_count && ctx.objects[tex_idx]) {
                m3g_set_ref_field(obj, "texCoords", ctx.objects[tex_idx]);
                GFX_DEBUG("M3G: Linked VertexBuffer texCoords[ref=%d idx=%d]", tex_ref, tex_idx);
            }
        }

        /* Link Appearance to Material, Texture2D, CompositingMode, Fog, PolygonMode */
        if (strstr(class_name, "Appearance")) {
            int mat_ref = m3g_get_int_field(obj, "materialRef", 0);
            int tex_ref = m3g_get_int_field(obj, "textureRef", 0);
            int comp_ref = m3g_get_int_field(obj, "compositingModeRef", 0);
            int fog_ref_val = m3g_get_int_field(obj, "fogRef", 0);
            int poly_ref = m3g_get_int_field(obj, "polygonModeRef", 0);

            int mat_idx = mat_ref - 2;
            int tex_idx = tex_ref - 2;
            int comp_idx = comp_ref - 2;
            int fog_idx = fog_ref_val - 2;
            int poly_idx = poly_ref - 2;

            if (mat_ref > 0 && mat_idx >= 0 && mat_idx < ctx.object_count && ctx.objects[mat_idx]) {
                m3g_set_ref_field(obj, "material", ctx.objects[mat_idx]);
                GFX_DEBUG("M3G: Linked Appearance material[ref=%d idx=%d] -> %p", mat_ref, mat_idx, ctx.objects[mat_idx]);
            }
            if (tex_ref > 0 && tex_idx >= 0 && tex_idx < ctx.object_count && ctx.objects[tex_idx]) {
                m3g_set_ref_field(obj, "texture", ctx.objects[tex_idx]);
                GFX_DEBUG("M3G: Linked Appearance texture[ref=%d idx=%d] -> %p", tex_ref, tex_idx, ctx.objects[tex_idx]);
            }
            if (comp_ref > 0 && comp_idx >= 0 && comp_idx < ctx.object_count && ctx.objects[comp_idx]) {
                m3g_set_ref_field(obj, "compositingMode", ctx.objects[comp_idx]);
                GFX_DEBUG("M3G: Linked Appearance compositingMode[ref=%d idx=%d] -> %p", comp_ref, comp_idx, ctx.objects[comp_idx]);
            }
            if (fog_ref_val > 0 && fog_idx >= 0 && fog_idx < ctx.object_count && ctx.objects[fog_idx]) {
                m3g_set_ref_field(obj, "fog", ctx.objects[fog_idx]);
                GFX_DEBUG("M3G: Linked Appearance fog[ref=%d idx=%d] -> %p", fog_ref_val, fog_idx, ctx.objects[fog_idx]);
            }
            if (poly_ref > 0 && poly_idx >= 0 && poly_idx < ctx.object_count && ctx.objects[poly_idx]) {
                m3g_set_ref_field(obj, "polygonMode", ctx.objects[poly_idx]);
                GFX_DEBUG("M3G: Linked Appearance polygonMode[ref=%d idx=%d] -> %p", poly_ref, poly_idx, ctx.objects[poly_idx]);
            }
        }

        /* Link Texture2D to Image2D */
        if (strstr(class_name, "Texture2D")) {
            int img_ref = m3g_get_int_field(obj, "imageRef", 0);

            /* FIX: Nokia H3T format stores ObjectIndex with byte-swapped words.
             * The value 0x00030000 should be 0x00000003 (section index 3).
             * Detect this by checking if upper 16 bits contain a valid ref
             * while lower 16 bits are zero (or both zero). */
            int img_ref_hi = (img_ref >> 16) & 0xFFFF;
            int img_ref_lo = img_ref & 0xFFFF;
            int obj_count_plus2 = ctx.object_count + 2;
            if (img_ref_hi > 0 && img_ref_hi < obj_count_plus2 && img_ref_lo == 0) {
                fprintf(stderr, "[M3G-LINK-TEX] Fixing byte-swapped imageRef: 0x%08x -> %d\n",
                        img_ref, img_ref_hi);
                img_ref = img_ref_hi;
                m3g_set_int_field(obj, "imageRef", img_ref);
            } else if (img_ref >= obj_count_plus2) {
                /* Also try: maybe the ref is stored as u16 at +2 offset */
                fprintf(stderr, "[M3G-LINK-TEX] imageRef=%d out of range (count+2=%d), trying byte extraction\n",
                        img_ref, obj_count_plus2);
            }

            int img_idx = img_ref - 2;

            fprintf(stderr, "[M3G-LINK-TEX] Texture2D %p: imageRef=%d, img_idx=%d, obj_count=%d\n",
                    (void*)obj, img_ref, img_idx, ctx.object_count);
            if (img_ref > 0 && img_idx >= 0 && img_idx < ctx.object_count) {
                if (ctx.objects[img_idx]) {
                    const char* target_cls = ctx.objects[img_idx]->header.clazz ? ctx.objects[img_idx]->header.clazz->class_name : "?";
                    fprintf(stderr, "[M3G-LINK-TEX] Linking Texture2D -> %s %p (ref=%d idx=%d)\n",
                            target_cls, (void*)ctx.objects[img_idx], img_ref, img_idx);
                    m3g_set_ref_field(obj, "image", ctx.objects[img_idx]);
                    /* Also store in C-side texture-image mapping table for
                     * reliable texture lookup even when Java field names are obfuscated */
                    m3g_store_tex_image_map(obj, ctx.objects[img_idx]);
                } else {
                    fprintf(stderr, "[M3G-LINK-TEX] WARNING: ctx.objects[%d] is NULL for Texture2D imageRef=%d\n", img_idx, img_ref);
                }
            } else if (img_ref > 0) {
                fprintf(stderr, "[M3G-LINK-TEX] WARNING: imageRef=%d out of range (idx=%d, count=%d)\n", img_ref, img_idx, ctx.object_count);
            }
        }

        /* Link Background to Image2D */
        if (strstr(class_name, "Background")) {
            int img_ref = m3g_get_int_field(obj, "imageRef", 0);
            int img_idx = img_ref - 2;

            if (img_ref > 0 && img_idx >= 0 && img_idx < ctx.object_count && ctx.objects[img_idx]) {
                m3g_set_ref_field(obj, "image", ctx.objects[img_idx]);
                GFX_DEBUG("M3G: Linked Background image[ref=%d idx=%d] -> %p", img_ref, img_idx, ctx.objects[img_idx]);
            }
        }

        /* Link Sprite3D to Image2D */
        if (strstr(class_name, "Sprite3D")) {
            int img_ref = m3g_get_int_field(obj, "imageRef", 0);
            int img_idx = img_ref - 2;

            if (img_ref > 0 && img_idx >= 0 && img_idx < ctx.object_count && ctx.objects[img_idx]) {
                m3g_set_ref_field(obj, "image", ctx.objects[img_idx]);
                GFX_DEBUG("M3G: Linked Sprite3D image[ref=%d idx=%d] -> %p", img_ref, img_idx, ctx.objects[img_idx]);
            }
        }

        /* Link SkinnedMesh to skeleton Group */
        if (strstr(class_name, "SkinnedMesh")) {
            int skel_ref = m3g_get_int_field(obj, "skeletonRef", 0);
            int skel_idx = skel_ref - 2;

            if (skel_ref > 0 && skel_idx >= 0 && skel_idx < ctx.object_count && ctx.objects[skel_idx]) {
                m3g_set_ref_field(obj, "skeleton", ctx.objects[skel_idx]);
                GFX_DEBUG("M3G: Linked SkinnedMesh skeleton[ref=%d idx=%d] -> %p", skel_ref, skel_idx, ctx.objects[skel_idx]);
            }

            /* v22: resolve rigid bone bindings (boneNodeRefs -> bone Nodes).
             * SU-30's plane is a SkinnedMesh; without this the renderer has
             * no bones to place the vertices with. */
            JavaArray* brefs = (JavaArray*)m3g_get_ref_field(obj, "boneNodeRefs");
            if (brefs && brefs->length > 0 && brefs->element_type == T_INT) {
                jint* br = (jint*)array_data(brefs);
                jsize nb = brefs->length;
                JavaClass* node_class = jvm_load_class(jvm, "javax/microedition/m3g/Node");
                JavaArray* bones = jvm_new_array(jvm, DESC_OBJECT, nb, node_class);
                if (bones) {
                    JavaObject** bd = (JavaObject**)array_data(bones);
                    int linked = 0;
                    for (jsize i = 0; i < nb; i++) {
                        jint r = br[i];
                        int idx = r - 2;
                        bd[i] = (r > 0 && idx >= 0 && idx < ctx.object_count) ? ctx.objects[idx] : NULL;
                        if (bd[i]) linked++;
                    }
                    m3g_set_ref_field(obj, "bones", (JavaObject*)bones);
                    GFX_DEBUG("M3G: Linked SkinnedMesh %d/%d bones", linked, (int)nb);
                }
            }
        }

        /* Resolve Group child references from _childRefs */
        if (strstr(class_name, "Group") || strstr(class_name, "World")) {
            /* Try to read _childRefs by name, then by direct slot 19 */
            JavaArray* child_refs = (JavaArray*)m3g_get_ref_field(obj, "_childRefs");
            fprintf(stderr, "[M3G-LINK] %s %p: _childRefs=%p (max_slots=%d, inst_size=%zu)\n",
                    class_name, (void*)obj, (void*)child_refs,
                    (int)((obj->header.clazz->instance_size - sizeof(ObjectHeader)) / sizeof(JavaValue)),
                    obj->header.clazz->instance_size);
            if (!child_refs) {
                /* Fallback: try direct slot 19 */
                int max_slots = (obj->header.clazz->instance_size - (int)sizeof(ObjectHeader)) / (int)sizeof(JavaValue);
                if (max_slots > 19) {
                    child_refs = (JavaArray*)obj->fields[19].ref;
                    if (child_refs) {
                        fprintf(stderr, "[M3G-LINK] %s: _childRefs found at fallback slot 19\n", class_name);
                    }
                }
            }
            if (child_refs && child_refs->element_type == T_INT) {
                jint* refs = (jint*)array_data(child_refs);
                int child_count = child_refs->length;

                /* Create children array if needed */
                JavaArray* children = (JavaArray*)m3g_get_ref_field(obj, "children");
                int children_slot = m3g_find_field_slot(obj, "children");
                fprintf(stderr, "[M3G-LINK] %s %p: childRefs len=%d, children=%p, children_slot=%d\n",
                        class_name, (void*)obj, child_count, (void*)children, children_slot);
                if (!children) {
                    children = jvm_new_array(jvm, DESC_OBJECT, child_count > 0 ? child_count : 16, NULL);
                    if (children) {
                        m3g_set_ref_field(obj, "children", (JavaObject*)children);
                        fprintf(stderr, "[M3G-LINK] %s %p: created children array %p (len=%d)\n",
                                class_name, (void*)obj, (void*)children, (int)children->length);
                    }
                }

                if (children && children->element_type == DESC_OBJECT) {
                    JavaObject** child_arr = (JavaObject**)array_data(children);
                    int added = 0;

                    for (int c = 0; c < child_count && added < children->length; c++) {
                        int child_ref = refs[c];
                        /* FIX: M3G reference: ref N = objects[N-2] */
                        int child_idx = child_ref - 2;
                        
                        if (child_ref > 0 && child_idx >= 0 && child_idx < ctx.object_count && ctx.objects[child_idx]) {
                            child_arr[added++] = ctx.objects[child_idx];
                            fprintf(stderr, "[M3G-LINK] %s %p: child[%d] = ref %d idx=%d -> %p\n",
                                    class_name, (void*)obj, added - 1, child_ref, child_idx, ctx.objects[child_idx]);
                        } else {
                            fprintf(stderr, "[M3G-LINK] %s %p: child ref %d idx=%d NOT RESOLVED (count=%d)\n",
                                    class_name, (void*)obj, child_ref, child_idx, ctx.object_count);
                        }
                    }
                    fprintf(stderr, "[M3G-LINK] %s %p: resolved %d/%d children\n",
                            class_name, (void*)obj, added, child_count);
                }

                /* Clear temporary storage */
                m3g_set_ref_field(obj, "_childRefs", NULL);
            } else if (child_refs) {
                fprintf(stderr, "[M3G-LINK] %s %p: _childRefs element_type=%d, expected T_INT=%d\n",
                        class_name, (void*)obj, child_refs->element_type, T_INT);
            }
        }

        /* Add Mesh to World if we have both */
        if (strstr(class_name, "Mesh") && ctx.world) {
            /* Add to World's children array */
            JavaArray* children = (JavaArray*)m3g_get_ref_field(ctx.world, "children");
            if (!children) {
                children = jvm_new_array(jvm, DESC_OBJECT, 16, NULL);
                if (children) {
                    m3g_set_ref_field(ctx.world, "children", (JavaObject*)children);
                }
            }
            if (children) {
                /* Find empty slot */
                JavaObject** arr = (JavaObject**)array_data(children);
                for (jsize j = 0; j < children->length; j++) {
                    if (!arr[j]) {
                        arr[j] = obj;
                        GFX_DEBUG("M3G: Added Mesh to World children[%d]", j);
                        break;
                    }
                }
            }
        }
    }

    /* Resolve World's activeCamera and background references */
    if (ctx.world) {
        int camera_ref = m3g_get_int_field(ctx.world, "activeCameraRef", 0);
        int bg_ref = m3g_get_int_field(ctx.world, "backgroundRef", 0);

        /* FIX: M3G reference: ref N = objects[N-2] */
        int camera_idx = camera_ref - 2;
        int bg_idx = bg_ref - 2;

        if (camera_ref > 0 && camera_idx >= 0 && camera_idx < ctx.object_count && ctx.objects[camera_idx]) {
            m3g_set_ref_field(ctx.world, "activeCamera", ctx.objects[camera_idx]);
            GFX_DEBUG("M3G: Linked World activeCamera[ref=%d idx=%d] -> %p", camera_ref, camera_idx, ctx.objects[camera_idx]);
        }
        if (bg_ref > 0 && bg_idx >= 0 && bg_idx < ctx.object_count && ctx.objects[bg_idx]) {
            m3g_set_ref_field(ctx.world, "background", ctx.objects[bg_idx]);
            GFX_DEBUG("M3G: Linked World background[ref=%d idx=%d] -> %p", bg_ref, bg_idx, ctx.objects[bg_idx]);
        }
    }

    /* v14: link animation tracks collected from Object3D headers */
    m3g_link_animation_tracks(jvm, &ctx);

    /* Create World object if not found during parsing */
    world_class = jvm_load_class(jvm, "javax/microedition/m3g/World");
    if (!world_class) {
        GFX_DEBUG("Loader.load: World class not found");
        goto cleanup_error;
    }

    if (!ctx.world) {
        ctx.world = jvm_new_object(jvm, world_class);
        if (ctx.world) {
            m3g_set_int_field(ctx.world, "scope", -1);
        }
    }

    if (!ctx.world) {
        GFX_DEBUG("Loader.load: failed to create World");
        goto cleanup_error;
    }

    /* Create and attach Camera if not found during parsing */
    if (!ctx.camera) {
        camera_class = jvm_load_class(jvm, "javax/microedition/m3g/Camera");
        if (camera_class) {
            ctx.camera = jvm_new_object(jvm, camera_class);
            if (ctx.camera) {
                m3g_set_int_field(ctx.camera, "projectionType", 1);  /* Perspective */
                m3g_set_float_field(ctx.camera, "fov", 60.0f);
                m3g_set_float_field(ctx.camera, "near", 1.0f);
                m3g_set_float_field(ctx.camera, "far", 1000.0f);
                GFX_DEBUG("Loader.load: created default Camera");
            }
        }
    }

    /* Set active camera on world */
    if (ctx.camera) {
        m3g_set_ref_field(ctx.world, "activeCamera", ctx.camera);
    }

    /* Create Background if not found */
    if (!ctx.background) {
        bg_class = jvm_load_class(jvm, "javax/microedition/m3g/Background");
        if (bg_class) {
            ctx.background = jvm_new_object(jvm, bg_class);
            if (ctx.background) {
                m3g_set_int_field(ctx.background, "clearColor", 0xFF202020);
            }
        }
    }

    if (ctx.background) {
        m3g_set_ref_field(ctx.world, "background", ctx.background);
    }

    /* Create default Light if not found */
    if (!ctx.light) {
        light_class = jvm_load_class(jvm, "javax/microedition/m3g/Light");
        if (light_class) {
            ctx.light = jvm_new_object(jvm, light_class);
            if (ctx.light) {
                m3g_set_int_field(ctx.light, "lightType", 2);  /* Directional */
                m3g_set_int_field(ctx.light, "color", 0xFFFFFFFF);
                m3g_set_float_field(ctx.light, "intensity", 1.0f);
                GFX_DEBUG("Loader.load: created default Light");
            }
        }
    }

    /* Success: prepare result */
    /* The returned array should contain only non-null objects for game compatibility.
     * Reference resolution is done internally using ctx.objects[] with correct indices.
     * Games typically access objects[0] as World, or use World.find(userID).
     */

    /* Count non-null objects for result array */
    int valid_count = 0;
    for (int i = 0; i < ctx.object_count; i++) {
        if (ctx.objects[i]) valid_count++;
    }

    /* Ensure we include World */
    bool world_in_objects = false;
    for (int i = 0; i < ctx.object_count; i++) {
        if (ctx.objects[i] == ctx.world) {
            world_in_objects = true;
            break;
        }
    }
    if (ctx.world && !world_in_objects) valid_count++;

    /* Ensure at least 1 slot if we have a world */
    if (valid_count == 0 && ctx.world) valid_count = 1;

    GFX_DEBUG("Loader.load: %d objects stored, %d valid, world=%p",
             ctx.object_count, valid_count, (void*)ctx.world);

    result = jvm_new_array(jvm, DESC_OBJECT, valid_count, NULL);
    if (result) {
        JavaObject** arr = (JavaObject**)array_data(result);
        int idx = 0;

        /* Add non-null objects to result array */
        for (int i = 0; i < ctx.object_count && idx < valid_count; i++) {
            if (ctx.objects[i]) {
                arr[idx++] = ctx.objects[i];
                GFX_DEBUG("Loader.load: result[%d] = %p (file index %d)",
                         idx - 1, (void*)ctx.objects[i], i);
            }
        }

        /* Add world if not already included */
        if (ctx.world && !world_in_objects && idx < valid_count) {
            arr[idx++] = ctx.world;
            GFX_DEBUG("Loader.load: result[%d] = %p (created World)",
                     idx - 1, (void*)ctx.world);
        }
    }

    fprintf(stderr, "[M3G] Returning array[%d] with World=%p\n", valid_count, (void*)ctx.world);

    /* FIX 32: Track last World for force-render.
     * Many games (like SU-30) load M3G files and manipulate World objects
     * directly without ever calling Graphics3D.bindTarget/render/releaseTarget.
     * They set up the scene via World.setActiveCamera and Node transforms,
     * then expect the emulator to render it. By tracking the last loaded World,
     * we enable force-render to detect and render the scene. */
    if (ctx.world) {
        g_m3g_last_world = ctx.world;
        g_m3g_scene_setup_done = true;
        m3g_thread_fence();
        fprintf(stderr, "[M3G-FORCE] Loader.load: tracked World %p for force-render\n", (void*)ctx.world);
    }

    /* Cleanup and return success */
    if (data) free(data);
    if (objects) free(objects);
    return NATIVE_RETURN_OBJECT(result);

cleanup_error:
    /* FIX: Centralized cleanup for all error paths */
    if (data) free(data);
    if (decompressed) free(decompressed);
    if (objects) free(objects);
    if (ctx.track_links) { free(ctx.track_links); ctx.track_links = NULL; } /* v14 */
    return NATIVE_RETURN_NULL();
}

/* Loader.load(World, String) - Load M3G file into existing World */
static JavaValue native_loader_load_into_world(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    /* args[0] = World (ignored, we create new objects), args[1] = String name */
    /* Delegate to the regular load() - the loaded objects are added to the scene graph */
    JavaValue new_args[1];
    new_args[0] = args[1];  /* Pass the name string */
    return native_loader_load(jvm, thread, new_args, 1);
}

/* Loader.load(byte[] data, int offset) - Load from byte array */
static JavaValue native_loader_load_bytes(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaArray* data = (JavaArray*)args[0].ref;
    jint offset = args[1].i;
    
    if (!data) {
        GFX_DEBUG("Loader.load: null data");
        return NATIVE_RETURN_NULL();
    }
    
    /* Calculate effective data range */
    int effective_length = data->length - offset;
    if (effective_length <= 0 || offset < 0 || offset >= data->length) {
        GFX_DEBUG("Loader.load: invalid offset=%d, length=%d", offset, data->length);
        return NATIVE_RETURN_NULL();
    }
    
    GFX_DEBUG("Loader.load(byte[]): %d bytes at offset %d", effective_length, offset);
    fprintf(stderr, "[M3G] Loader.load(byte[]): %d bytes at offset %d\n", effective_length, offset);
    
    /* Copy byte array data directly into memory - no temp file needed.
     * The data is already in the Java byte[] array, just memcpy it. */
    uint8_t* src_data = (uint8_t*)array_data(data);
    if (!src_data) {
        GFX_DEBUG("Loader.load(byte[]): null array data");
        return NATIVE_RETURN_NULL();
    }
    
    long file_size = (long)effective_length;
    
    uint8_t* file_data = (uint8_t*)malloc(file_size);
    if (!file_data) {
        GFX_DEBUG("Loader.load(byte[]): failed to allocate %ld bytes", file_size);
        return NATIVE_RETURN_NULL();
    }
    
    memcpy(file_data, src_data + offset, file_size);
    
    /* --- Inline M3G parsing (same structure as native_loader_load) --- */
    
    /* Resources that need cleanup */
    uint8_t* decompressed = NULL;
    JavaObject** objects = NULL;
    JavaArray* result = NULL;
    
    /* Result variables */
    JavaClass* world_class = NULL;
    JavaClass* camera_class = NULL;
    JavaClass* bg_class = NULL;
    JavaClass* light_class = NULL;
    
    /* Parse context */
    M3GParseContext ctx = {0};
    ctx.object_count = 0;
    ctx.header_seen = 0;
    ctx.objects_start_index = 0;
    ctx.object_capacity = 256;
    ctx.objects = calloc(ctx.object_capacity, sizeof(JavaObject*));
    objects = ctx.objects;
    
    /* Clear the global M3G object registry */
    m3g_registry_clear();
    
    if (!ctx.objects) {
        free(file_data);
        goto load_bytes_cleanup;
    }
    
    /* Check M3G magic header */
    if (file_size >= 12 &&
        file_data[0] == 0xAB && 
        strncmp((char*)&file_data[1], "JSR184", 6) == 0 && 
        file_data[7] == 0xBB &&
        file_data[8] == 0x0D && file_data[9] == 0x0A &&
        file_data[10] == 0x1A && file_data[11] == 0x0A) {
        
        GFX_DEBUG("Loader.load(byte[]): Valid M3G file detected, size=%ld", file_size);
        fprintf(stderr, "[M3G] Valid M3G file from byte array (%ld bytes)\n", file_size);
        
        /* Clear texture caches before parsing new M3G file */
        m3g_clear_tex_image_map();
        m3g_clear_texture_cache();
        
        size_t fpos = 12;
        int section_count = 0;
        int current_section = 0;
        
        while (fpos + 13 <= (size_t)file_size && section_count < 100) {
            uint8_t compression_scheme = file_data[fpos++];
            uint32_t total_section_length = file_data[fpos] | (file_data[fpos+1] << 8) | 
                                            (file_data[fpos+2] << 16) | ((uint32_t)(file_data[fpos+3]) <<  24);
            fpos += 4;
            uint32_t uncompressed_length = file_data[fpos] | (file_data[fpos+1] << 8) | 
                                           (file_data[fpos+2] << 16) | ((uint32_t)(file_data[fpos+3]) <<  24);
            fpos += 4;
            
            if (total_section_length < 13 || total_section_length > (size_t)file_size) break;
            
            size_t section_data_start = fpos;
            size_t section_data_size = total_section_length - 13;
            
            uint8_t* section_data;
            size_t section_data_len;
            
            if (compression_scheme == 0) {
                section_data = &file_data[section_data_start];
                section_data_len = section_data_size;
            } else if (compression_scheme == 1) {
                section_data = m3g_decompress(&file_data[section_data_start], section_data_size, &section_data_len);
                decompressed = section_data;
                if (!section_data || section_data_len != uncompressed_length) {
                    if (section_data) { free(section_data); decompressed = NULL; }
                    goto load_bytes_next_section;
                }
            } else {
                goto load_bytes_next_section;
            }
            
            /* Parse objects within section */
            if (section_data && section_data_len > 0) {
                size_t obj_pos = 0;
                while (obj_pos < section_data_len) {
                    if (obj_pos + 5 > section_data_len) break;
                    
                    uint8_t obj_type = section_data[obj_pos++];
                    uint32_t obj_length = section_data[obj_pos] | (section_data[obj_pos+1] << 8) |
                                        (section_data[obj_pos+2] << 16) | ((uint32_t)(section_data[obj_pos+3]) <<  24);
                    obj_pos += 4;
                    
                    if (obj_length == 0 || obj_pos + obj_length > section_data_len) break;
                    
                    size_t obj_start = obj_pos;
                    
                    /* Allocate space for this object */
                    if (ctx.object_count >= ctx.object_capacity) {
                        ctx.object_capacity *= 2;
                        ctx.objects = realloc(ctx.objects, ctx.object_capacity * sizeof(JavaObject*));
                        objects = ctx.objects;
                        if (!ctx.objects) goto load_bytes_cleanup;
                    }
                    
                    /* Store NULL placeholder (header at position 0) */
                    JavaObject* parsed = m3g_parse_object(jvm, &ctx, section_data, section_data_len, &obj_pos, obj_type, obj_length);
                    
                    if (obj_type == 0) {
                        /* Header object - do NOT store in array, do NOT increment count.
                         * M3G refs: ref 0 = null, ref N = objects[N-2].
                         * Header is at file position 0/1 but not in the objects array.
                         * Storing it breaks all reference lookups by off-by-one. */
                    } else if (parsed) {
                        ctx.objects[ctx.object_count++] = parsed;
                    } else {
                        /* Unknown/unparsed object - store NULL placeholder */
                        ctx.objects[ctx.object_count++] = NULL;
                    }
                    
                    /* Ensure we advance past the object data */
                    if (obj_pos < obj_start + obj_length) {
                        obj_pos = obj_start + obj_length;
                    }
                }
            }
            
            load_bytes_next_section:
            /* Advance past this section + 4-byte checksum at end */
            fpos = section_data_start + section_data_size + 4;
            section_count++;
            current_section++;
        }
    } else {
        GFX_DEBUG("Loader.load(byte[]): Not a valid M3G file, creating default World");
        fprintf(stderr, "[M3G] Byte array is not valid M3G format, creating default World\n");
    }
    
    /* Link objects (same as in native_loader_load) */
    GFX_DEBUG("Loader.load(byte[]): Linking %d objects...", ctx.object_count);
    for (int i = 0; i < ctx.object_count; i++) {
        JavaObject* obj = ctx.objects[i];
        if (!obj || !obj->header.clazz) continue;
        const char* cn = obj->header.clazz->class_name;
        
        /* Link Mesh */
        if (strstr(cn, "Mesh")) {
            int vb_ref = m3g_get_int_field(obj, "vertexBufferRef", 0);
            int ib_ref = m3g_get_int_field(obj, "indexBufferRef", 0);
            int app_ref = m3g_get_int_field(obj, "appearanceRef", 0);
            int vb_idx = vb_ref - 2, ib_idx = ib_ref - 2, app_idx = app_ref - 2;
            if (vb_ref > 0 && vb_idx >= 0 && vb_idx < ctx.object_count && ctx.objects[vb_idx])
                m3g_set_ref_field(obj, "vertexBuffer", ctx.objects[vb_idx]);
            if (ib_ref > 0 && ib_idx >= 0 && ib_idx < ctx.object_count && ctx.objects[ib_idx])
                m3g_set_ref_field(obj, "indexBuffer", ctx.objects[ib_idx]);
            if (app_ref > 0 && app_idx >= 0 && app_idx < ctx.object_count && ctx.objects[app_idx])
                m3g_set_ref_field(obj, "appearance", ctx.objects[app_idx]);
        }
        /* Link VertexBuffer */
        if (strstr(cn, "VertexBuffer")) {
            int pos_ref = m3g_get_int_field(obj, "positionsRef", 0);
            int norm_ref = m3g_get_int_field(obj, "normalsRef", 0);
            int color_ref = m3g_get_int_field(obj, "colorsRef", 0);
            int tex_ref = m3g_get_int_field(obj, "texCoordsRef", 0);
            if (pos_ref > 0 && pos_ref-2 >= 0 && pos_ref-2 < ctx.object_count && ctx.objects[pos_ref-2]) {
                JavaObject* pobj = ctx.objects[pos_ref-2];
                int pc = m3g_get_int_field(pobj, "componentCount", -1);
                int pvc = m3g_get_int_field(pobj, "vertexCount", -1);
                m3g_set_ref_field(obj, "positions", pobj);
                fprintf(stderr, "[M3G-LINK2] VB %p: positions[ref=%d] -> %p (comp=%d, verts=%d)\n",
                        (void*)obj, pos_ref, (void*)pobj, pc, pvc);
            }
            if (norm_ref > 0 && norm_ref-2 >= 0 && norm_ref-2 < ctx.object_count && ctx.objects[norm_ref-2])
                m3g_set_ref_field(obj, "normals", ctx.objects[norm_ref-2]);
            if (color_ref > 0 && color_ref-2 >= 0 && color_ref-2 < ctx.object_count && ctx.objects[color_ref-2])
                m3g_set_ref_field(obj, "colors", ctx.objects[color_ref-2]);
            if (tex_ref > 0 && tex_ref-2 >= 0 && tex_ref-2 < ctx.object_count && ctx.objects[tex_ref-2])
                m3g_set_ref_field(obj, "texCoords", ctx.objects[tex_ref-2]);
        }
        /* Link Appearance */
        if (strstr(cn, "Appearance")) {
            int mat_ref = m3g_get_int_field(obj, "materialRef", 0);
            int tex_ref = m3g_get_int_field(obj, "textureRef", 0);
            int comp_ref = m3g_get_int_field(obj, "compositingModeRef", 0);
            int fog_ref_val = m3g_get_int_field(obj, "fogRef", 0);
            int poly_ref = m3g_get_int_field(obj, "polygonModeRef", 0);
            if (mat_ref > 0 && mat_ref-2 >= 0 && mat_ref-2 < ctx.object_count && ctx.objects[mat_ref-2])
                m3g_set_ref_field(obj, "material", ctx.objects[mat_ref-2]);
            if (tex_ref > 0 && tex_ref-2 >= 0 && tex_ref-2 < ctx.object_count && ctx.objects[tex_ref-2])
                m3g_set_ref_field(obj, "texture", ctx.objects[tex_ref-2]);
            if (comp_ref > 0 && comp_ref-2 >= 0 && comp_ref-2 < ctx.object_count && ctx.objects[comp_ref-2])
                m3g_set_ref_field(obj, "compositingMode", ctx.objects[comp_ref-2]);
            if (fog_ref_val > 0 && fog_ref_val-2 >= 0 && fog_ref_val-2 < ctx.object_count && ctx.objects[fog_ref_val-2])
                m3g_set_ref_field(obj, "fog", ctx.objects[fog_ref_val-2]);
            if (poly_ref > 0 && poly_ref-2 >= 0 && poly_ref-2 < ctx.object_count && ctx.objects[poly_ref-2])
                m3g_set_ref_field(obj, "polygonMode", ctx.objects[poly_ref-2]);
        }
        /* Link Group/World children */
        if (strstr(cn, "Group") || strstr(cn, "World")) {
            JavaArray* child_refs = (JavaArray*)m3g_get_ref_field(obj, "_childRefs");
            fprintf(stderr, "[M3G-LINK2] %s %p: _childRefs=%p\n", cn, (void*)obj, (void*)child_refs);
            if (child_refs && child_refs->element_type == T_INT) {
                jint* refs = (jint*)array_data(child_refs);
                int child_count = child_refs->length;
                JavaArray* children = (JavaArray*)m3g_get_ref_field(obj, "children");
                if (!children) {
                    children = jvm_new_array(jvm, DESC_OBJECT, child_count > 0 ? child_count : 16, NULL);
                    if (children) m3g_set_ref_field(obj, "children", (JavaObject*)children);
                }
                if (children && children->element_type == DESC_OBJECT) {
                    JavaObject** ca = (JavaObject**)array_data(children);
                    int added = 0;
                    for (int c = 0; c < child_count && added < children->length; c++) {
                        int cr = refs[c];
                        int ci = cr - 2;
                        if (cr > 0 && ci >= 0 && ci < ctx.object_count && ctx.objects[ci]) {
                            ca[added++] = ctx.objects[ci];
                            fprintf(stderr, "[M3G-LINK2] %s %p: child[%d] ref=%d -> %p\n",
                                    cn, (void*)obj, added-1, cr, (void*)ctx.objects[ci]);
                        }
                    }
                    fprintf(stderr, "[M3G-LINK2] %s %p: resolved %d/%d children\n", cn, (void*)obj, added, child_count);
                }
                m3g_set_ref_field(obj, "_childRefs", NULL);
            }
        }
        /* Add Mesh to World */
        if (strstr(cn, "Mesh") && ctx.world) {
            JavaArray* children = (JavaArray*)m3g_get_ref_field(ctx.world, "children");
            if (!children) {
                children = jvm_new_array(jvm, DESC_OBJECT, 16, NULL);
                if (children) m3g_set_ref_field(ctx.world, "children", (JavaObject*)children);
            }
            if (children) {
                JavaObject** ca = (JavaObject**)array_data(children);
                for (jsize j = 0; j < children->length; j++) {
                    if (!ca[j]) { ca[j] = obj; break; }
                }
            }
        }
    }
    
    /* Resolve World camera and background */
    if (ctx.world) {
        int camera_ref = m3g_get_int_field(ctx.world, "activeCameraRef", 0);
        int bg_ref = m3g_get_int_field(ctx.world, "backgroundRef", 0);
        if (camera_ref > 0 && camera_ref-2 >= 0 && camera_ref-2 < ctx.object_count && ctx.objects[camera_ref-2])
            m3g_set_ref_field(ctx.world, "activeCamera", ctx.objects[camera_ref-2]);
        if (bg_ref > 0 && bg_ref-2 >= 0 && bg_ref-2 < ctx.object_count && ctx.objects[bg_ref-2])
            m3g_set_ref_field(ctx.world, "background", ctx.objects[bg_ref-2]);
    }
    
    /* Create World if needed */
    world_class = jvm_load_class(jvm, "javax/microedition/m3g/World");
    if (!world_class) goto load_bytes_cleanup;
    
    if (!ctx.world) {
        ctx.world = jvm_new_object(jvm, world_class);
        if (ctx.world) m3g_set_int_field(ctx.world, "scope", -1);
    }
    if (!ctx.world) goto load_bytes_cleanup;
    
    /* Create default Camera if not found */
    if (!ctx.camera) {
        camera_class = jvm_load_class(jvm, "javax/microedition/m3g/Camera");
        if (camera_class) {
            ctx.camera = jvm_new_object(jvm, camera_class);
            if (ctx.camera) {
                m3g_set_int_field(ctx.camera, "projectionType", 1);
                m3g_set_float_field(ctx.camera, "fov", 60.0f);
                m3g_set_float_field(ctx.camera, "near", 1.0f);
                m3g_set_float_field(ctx.camera, "far", 1000.0f);
            }
        }
    }
    if (ctx.camera) m3g_set_ref_field(ctx.world, "activeCamera", ctx.camera);
    
    /* Create default Background if not found */
    if (!ctx.background) {
        bg_class = jvm_load_class(jvm, "javax/microedition/m3g/Background");
        if (bg_class) {
            ctx.background = jvm_new_object(jvm, bg_class);
            if (ctx.background) m3g_set_int_field(ctx.background, "clearColor", 0xFF202020);
        }
    }
    if (ctx.background) m3g_set_ref_field(ctx.world, "background", ctx.background);
    
    /* Create default Light if not found */
    if (!ctx.light) {
        light_class = jvm_load_class(jvm, "javax/microedition/m3g/Light");
        if (light_class) {
            ctx.light = jvm_new_object(jvm, light_class);
            if (ctx.light) {
                m3g_set_int_field(ctx.light, "lightType", 2);
                m3g_set_int_field(ctx.light, "color", 0xFFFFFFFF);
                m3g_set_float_field(ctx.light, "intensity", 1.0f);
            }
        }
    }
    
    /* v14: link animation tracks collected from Object3D headers */
    m3g_link_animation_tracks(jvm, &ctx);

    /* Build result array */
    int valid_count = 0;
    for (int i = 0; i < ctx.object_count; i++) {
        if (ctx.objects[i]) valid_count++;
    }
    bool world_in_objects = false;
    for (int i = 0; i < ctx.object_count; i++) {
        if (ctx.objects[i] == ctx.world) { world_in_objects = true; break; }
    }
    if (ctx.world && !world_in_objects) valid_count++;
    if (valid_count == 0 && ctx.world) valid_count = 1;
    
    result = jvm_new_array(jvm, DESC_OBJECT, valid_count, NULL);
    if (result) {
        JavaObject** arr = (JavaObject**)array_data(result);
        int idx = 0;
        for (int i = 0; i < ctx.object_count && idx < valid_count; i++) {
            if (ctx.objects[i]) arr[idx++] = ctx.objects[i];
        }
        if (idx < valid_count && ctx.world) arr[idx] = ctx.world;
    }
    
    GFX_DEBUG("Loader.load(byte[]): returning array[%d]", valid_count);
    fprintf(stderr, "[M3G] Loader.load(byte[]): returning array[%d]\n", valid_count);
    
    /* Cleanup */
    free(file_data);
    if (decompressed) free(decompressed);
    if (objects) free(objects);
    return NATIVE_RETURN_OBJECT(result);

load_bytes_cleanup:
    if (file_data) free(file_data);
    if (decompressed) free(decompressed);
    if (objects) free(objects);
    if (ctx.track_links) { free(ctx.track_links); ctx.track_links = NULL; } /* v14 */
    return NATIVE_RETURN_NULL();
}

/* RayIntersection methods for picking */
static JavaValue native_rayintersection_getDistance(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_FLOAT(0.0f);
    
    /* Get distance from field */
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "distance") == 0) {
            return NATIVE_RETURN_FLOAT(obj->fields[i].f);
        }
    }
    
    return NATIVE_RETURN_FLOAT(0.0f);
}

static JavaValue native_rayintersection_getIntersected(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "intersected") == 0) {
            return NATIVE_RETURN_OBJECT(obj->fields[i].ref);
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* Graphics3D.addLight(Light, Transform) */
static JavaValue native_graphics3d_addLight(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* light = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d;
    
    if (!light) return NATIVE_RETURN_INT(-1);
    
    /* Auto-register light slot */
    int light_idx = find_light_for_object(light);
    if (light_idx < 0) {
        if (g_m3g.light_count < 8) {
            light_idx = g_m3g.light_count++;
            memset(&g_m3g.lights[light_idx], 0, sizeof(M3GLight));
            g_m3g.lights[light_idx].obj = light;
            g_m3g.lights[light_idx].attenuation[0] = 1.0f;
            g_m3g.lights[light_idx].color[3] = 1.0f;
        } else {
            return NATIVE_RETURN_INT(-1);
        }
    }
    
    /* Task 16-a: capture the light's world transform and flag the slot as
     * Graphics3D-registered so it is seeded into the per-render active list
     * (g_m3g_seed_active_lights) instead of being wiped by render(World). */
    if (transform) {
        m3g_read_java_transform(transform, &g_m3g.lights[light_idx].transform);
        g_m3g.lights[light_idx].has_transform = 1;
    } else {
        g_m3g.lights[light_idx].has_transform = 0;
    }
    g_m3g.lights[light_idx].g3d_registered = 1;
    
    return NATIVE_RETURN_INT(light_idx);
}

/* Graphics3D.setLight(int index, Light, Transform) */
static JavaValue native_graphics3d_setLight(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* light = (JavaObject*)args[2].ref;
    JavaObject* transform = (JavaObject*)args[3].ref;
    (void)g3d;
    
    if (index < 0 || index >= 8) return NATIVE_RETURN_VOID();
    
    if (light) {
        /* Update light at index */
        memset(&g_m3g.lights[index], 0, sizeof(M3GLight));
        g_m3g.lights[index].obj = light;
        
        /* Read light mode (field name "mode" in Java Light, JSR-184 value 128-131) */
        int light_mode = m3g_get_int_field(light, "mode", 129);
        g_m3g.lights[index].type = m3g_light_mode_to_type(light_mode);
        
        /* Read color */
        jint color_val = m3g_get_int_field(light, "color", 0x00FFFFFF);
        g_m3g.lights[index].color[0] = ((color_val >> 16) & 0xFF) / 255.0f;
        g_m3g.lights[index].color[1] = ((color_val >> 8) & 0xFF) / 255.0f;
        g_m3g.lights[index].color[2] = (color_val & 0xFF) / 255.0f;
        
        float intensity = m3g_get_float_field(light, "intensity", 1.0f);
        g_m3g.lights[index].color[3] = intensity;
        
        g_m3g.lights[index].attenuation[0] = m3g_get_float_field(light, "constantAttenuation", 1.0f);
        g_m3g.lights[index].attenuation[1] = m3g_get_float_field(light, "linearAttenuation", 0.0f);
        g_m3g.lights[index].attenuation[2] = m3g_get_float_field(light, "quadraticAttenuation", 0.0f);
        g_m3g.lights[index].spot_angle = m3g_get_float_field(light, "spotAngle", 180.0f);
        g_m3g.lights[index].spot_exponent = m3g_get_float_field(light, "spotExponent", 0.0f);
        
        /* Task 16-a: capture the transform and flag the slot as
         * Graphics3D-registered (see native_graphics3d_addLight). */
        if (transform) {
            m3g_read_java_transform(transform, &g_m3g.lights[index].transform);
            g_m3g.lights[index].has_transform = 1;
        } else {
            g_m3g.lights[index].has_transform = 0;
        }
        g_m3g.lights[index].g3d_registered = 1;
        
        GFX_DEBUG("Graphics3D.setLight: index=%d mode=%d type=%d", index, light_mode, g_m3g.lights[index].type);
    } else {
        /* Remove light */
        if (index < g_m3g.light_count) {
            g_m3g.lights[index].type = 0;
            g_m3g.lights[index].g3d_registered = 0;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Animation System (JSR-184)
 * 
 * Implements the M3G animation system:
 * - KeyframeSequence: stores keyframe times and values with interpolation
 * - AnimationController: controls playback speed, position, active interval, weight
 * - AnimationTrack: links a KeyframeSequence to a property of an Object3D
 * - Object3D.animate(worldTime): evaluates all tracks and applies values
 * ============================================================================ */

/* Animation property constants (from JSR-184 AnimationTrack) */
#define M3G_ANIM_ALPHA              256
#define M3G_ANIM_AMBIENT_COLOR     257
#define M3G_ANIM_COLOR             258
#define M3G_ANIM_CROP              259
#define M3G_ANIM_DENSITY           260
#define M3G_ANIM_DIFFUSE_COLOR     261
#define M3G_ANIM_EMISSIVE_COLOR    262
#define M3G_ANIM_FAR_DISTANCE      263
#define M3G_ANIM_FIELD_OF_VIEW     264
#define M3G_ANIM_INTENSITY         265
#define M3G_ANIM_MORPH_WEIGHTS     266
#define M3G_ANIM_NEAR_DISTANCE     267
#define M3G_ANIM_ORIENTATION       268
#define M3G_ANIM_PICKABILITY       269
#define M3G_ANIM_SCALE             270
#define M3G_ANIM_SHININESS         271
#define M3G_ANIM_SPECULAR_COLOR    272
#define M3G_ANIM_SPOT_ANGLE        273
#define M3G_ANIM_SPOT_EXPONENT     274
#define M3G_ANIM_TRANSLATION       275
#define M3G_ANIM_VISIBILITY        276

/* KeyframeSequence interpolation modes */
#define M3G_KF_LINEAR              176
#define M3G_KF_SLERP               177
#define M3G_KF_SPLINE              178
#define M3G_KF_SQUAD               179
#define M3G_KF_STEP                180

/* v20: normalize the interpolation encoding to the M3G-file values used by
 * the evaluator. Two encodings reach the `interpolation` field:
 *   - Loader.load (M3G binary): 176..180 directly (see m3g_read at the
 *     KeyframeSequence section),
 *   - Java API constructor (v20 constants): KeyframeSequence.CONSTANT=0,
 *     LINEAR=1, SPLINE=2, SQUAD=3 (JSR-184 javadoc values).
 * API->file mapping: CONSTANT(0)=hold value -> STEP(180); LINEAR(1)->176;
 * SPLINE(2)->178; SQUAD(3)->179. */
static jint m3g_normalize_interpolation(jint v) {
    switch (v) {
        case 0: return M3G_KF_STEP;    /* KeyframeSequence.CONSTANT */
        case 1: return M3G_KF_LINEAR;  /* KeyframeSequence.LINEAR   */
        case 2: return M3G_KF_SPLINE;  /* KeyframeSequence.SPLINE   */
        case 3: return M3G_KF_SQUAD;   /* KeyframeSequence.SQUAD    */
        default: return v;             /* already file-encoded (176..180) */
    }
}

/* KeyframeSequence repeat modes */
#define M3G_REPEAT_CONSTANT        192
#define M3G_REPEAT_LOOP            193

/* ---- Internal animation helpers ---- */

/* Check if an AnimationController is active at the given world time */
static int m3g_anim_is_active(JavaObject* controller, jint world_time) {
    jint act_start = m3g_get_int_field(controller, "activationTime", 0);
    jint act_end = m3g_get_int_field(controller, "deactivationTime", 0);
    
    if (act_start == act_end) return 1;  /* Always active if interval is zero */
    return (world_time >= act_start && world_time < act_end);
}

/* Get the current sequence time from an AnimationController */
static jfloat m3g_anim_get_position(JavaObject* controller, jint world_time) {
    jfloat speed = m3g_get_float_field(controller, "speed", 1.0f);
    jint ref_world_time = m3g_get_int_field(controller, "refWorldTime", 0);
    jfloat ref_seq_time = m3g_get_float_field(controller, "refSequenceTime", 0.0f);
    
    return ref_seq_time + speed * ((jfloat)world_time - (jfloat)ref_world_time);
}

/* Get time remaining until controller deactivation */
static jint m3g_anim_time_to_deactivation(JavaObject* controller, jint world_time) {
    jint deact = m3g_get_int_field(controller, "deactivationTime", 0x7FFFFFFF);
    if (world_time < deact) return deact - world_time;
    return 0x7FFFFFFF;
}

/* Sample a KeyframeSequence at the given sequence time using LINEAR interpolation.
 * Returns 1 on success, 0 on error. */
static int m3g_anim_sample_linear(JavaObject* sequence, jint seq_time,
                                   jfloat* out_sample, int max_components) {
    jint num_kf = m3g_get_int_field(sequence, "numKeyframes", 0);
    jint num_comp = m3g_get_int_field(sequence, "numComponents", 0);
    jint duration = m3g_get_int_field(sequence, "duration", 0);
    jint repeat = m3g_get_int_field(sequence, "repeatMode", M3G_REPEAT_CONSTANT);
    jint first_valid = m3g_get_int_field(sequence, "firstValid", 0);
    jint last_valid = m3g_get_int_field(sequence, "lastValid", 0);
    jint interpolation = m3g_normalize_interpolation(
        m3g_get_int_field(sequence, "interpolation", M3G_KF_LINEAR));
    
    if (num_kf <= 0 || num_comp <= 0 || num_comp > max_components) return 0;
    
    JavaArray* kf_times = (JavaArray*)m3g_get_ref_field(sequence, "keyframeTimes");
    JavaArray* kf_values = (JavaArray*)m3g_get_ref_field(sequence, "keyframeValues");
    if (!kf_times || !kf_values) return 0;
    
    jint* times = (jint*)array_data(kf_times);
    jfloat* values = (jfloat*)array_data(kf_values);
    if (!times || !values) return 0;
    
    int closed = (repeat == M3G_REPEAT_LOOP);
    
    /* Map time for closed (looping) sequences */
    jint time = seq_time;
    if (closed && duration > 0) {
        if (time < 0) time = (time % duration) + duration;
        else time = time % duration;
        /* Adjust if before first valid keyframe time */
        if (time < times[first_valid]) time += duration;
    } else {
        /* Open (constant) sequence: clamp to valid range */
        if (time < times[first_valid]) {
            for (int i = 0; i < num_comp; i++) out_sample[i] = values[first_valid * num_comp + i];
            return 1;
        }
        if (time >= times[last_valid]) {
            for (int i = 0; i < num_comp; i++) out_sample[i] = values[last_valid * num_comp + i];
            return 1;
        }
    }
    
    /* Find the keyframe segment */
    int start_kf = first_valid;
    /* Search forward for the segment containing 'time' */
    while (start_kf < last_valid && times[start_kf + 1] <= time) {
        start_kf++;
    }
    
    /* STEP interpolation: just use the start keyframe */
    if (interpolation == M3G_KF_STEP || time == times[start_kf]) {
        for (int i = 0; i < num_comp; i++) out_sample[i] = values[start_kf * num_comp + i];
        return 1;
    }
    
    /* Calculate interpolation factor */
    int end_kf = start_kf + 1;
    if (end_kf >= num_kf) end_kf = 0;  /* Wrap for closed sequences (shouldn't happen for open) */
    
    jint delta = times[end_kf] - times[start_kf];
    if (delta <= 0) {
        /* Coincident keyframes, just use start */
        for (int i = 0; i < num_comp; i++) out_sample[i] = values[start_kf * num_comp + i];
        return 1;
    }
    
    jfloat s = (jfloat)(time - times[start_kf]) / (jfloat)delta;
    
    /* Interpolate based on interpolation mode */
    const jfloat* v_start = &values[start_kf * num_comp];
    const jfloat* v_end = &values[end_kf * num_comp];
    
    switch (interpolation) {
    case M3G_KF_LINEAR: {
        /* Linear interpolation */
        for (int i = 0; i < num_comp; i++) {
            out_sample[i] = v_start[i] + s * (v_end[i] - v_start[i]);
        }
        break;
    }
    case M3G_KF_SLERP: {
    slerp_path:
        /* Spherical linear interpolation for quaternions (4 components) */
        if (num_comp == 4) {
            /* Compute dot product */
            jfloat dot = 0.0f;
            for (int i = 0; i < 4; i++) dot += v_start[i] * v_end[i];
            
            /* If dot is negative, negate one quaternion to take shorter path */
            jfloat sign = 1.0f;
            if (dot < 0.0f) { sign = -1.0f; dot = -dot; }
            
            /* Clamp dot to avoid numerical issues with acos */
            if (dot > 1.0f) dot = 1.0f;
            
            if (dot < 0.0001f) {
                /* Quaternions are nearly opposite; use simple lerp */
                for (int i = 0; i < 4; i++) {
                    out_sample[i] = v_start[i] + s * (sign * v_end[i] - v_start[i]);
                }
            } else {
                /* Standard SLERP */
                jfloat omega = acosf(dot);
                jfloat sin_omega = sinf(omega);
                jfloat a = sinf((1.0f - s) * omega) / sin_omega;
                jfloat b = sinf(s * omega) / sin_omega * sign;
                for (int i = 0; i < 4; i++) {
                    out_sample[i] = a * v_start[i] + b * v_end[i];
                }
            }
            /* Normalize result */
            jfloat len = sqrtf(out_sample[0]*out_sample[0] + out_sample[1]*out_sample[1] +
                              out_sample[2]*out_sample[2] + out_sample[3]*out_sample[3]);
            if (len > 0.0001f) {
                for (int i = 0; i < 4; i++) out_sample[i] /= len;
            }
        } else {
            /* Fallback to linear for non-4-component */
            for (int i = 0; i < num_comp; i++) {
                out_sample[i] = v_start[i] + s * (v_end[i] - v_start[i]);
            }
        }
        break;
    }
    case M3G_KF_SPLINE: {
        /* v26 FIX (audit item: SPLINE fell back to LINEAR): JSR-184 SPLINE
         * is Catmull-Rom (cubic Hermite with neighbor-averaged tangents).
         * Chunky per-keyframe velocity jumps ("stepped" camera flyovers,
         * pulsing morph/scaling ramps) are gone; ends clamp to the boundary
         * keys so one-sided segments stay well-behaved. For 4-component
         * (quaternion) tracks components are Catmull-Rom'd then normalized —
         * an accepted approximation of SQUAD-quality orientation blending. */
        int i0 = start_kf > first_valid ? start_kf - 1 : first_valid;                 /* p0 */
        int i3 = end_kf + 1 <= last_valid ? end_kf + 1 : last_valid; /* p3 */
        const jfloat* p0 = &values[i0 * num_comp];
        const jfloat* p1 = v_start;
        const jfloat* p2 = v_end;
        const jfloat* p3 = &values[i3 * num_comp];
        jfloat s2 = s * s;
        jfloat s3 = s2 * s;
        /* Catmull-Rom tangents (uniform parameterization, tension 0) */
        for (int i = 0; i < num_comp; i++) {
            jfloat m1 = 0.5f * (p2[i] - p0[i]);
            jfloat m2 = 0.5f * (p3[i] - p1[i]);
            out_sample[i] = (2.0f * s3 - 3.0f * s2 + 1.0f) * p1[i]
                          + (s3 - 2.0f * s2 + s) * m1
                          + (-2.0f * s3 + 3.0f * s2) * p2[i]
                          + (s3 - s2) * m2;
        }
        if (num_comp == 4) {
            /* Quaternion track: renormalize the blended components */
            jfloat len = sqrtf(out_sample[0]*out_sample[0] + out_sample[1]*out_sample[1] +
                               out_sample[2]*out_sample[2] + out_sample[3]*out_sample[3]);
            if (len > 0.0001f) {
                for (int i = 0; i < 4; i++) out_sample[i] /= len;
            } else {
                for (int i = 0; i < 4; i++) out_sample[i] = v_start[i];
            }
        }
        break;
    }
    case M3G_KF_SQUAD:
    default:
        /* SQUAD: fall back to SLERP for quaternions (orientation tracks stay
         * on the short arc), LINEAR otherwise. Full SQUAD needs inner-quaternion
         * midpoints — deferred; SLERP is the accepted approximation. */
        if (interpolation == M3G_KF_SQUAD && num_comp == 4) {
            goto slerp_path;
        }
        for (int i = 0; i < num_comp; i++) {
            out_sample[i] = v_start[i] + s * (v_end[i] - v_start[i]);
        }
        break;
    }
    
    return 1;
}

/* Apply an animated property value to an Object3D/Node.
 * The values are already weighted and accumulated by the caller. */
static void m3g_anim_apply_property(JVM* jvm, JavaObject* obj, jint property,
                                     jint num_components, const jfloat* values) {
    if (!obj) return;
    
    const char* class_name = obj->header.clazz ? obj->header.clazz->class_name : NULL;
    if (!class_name) return;
    
    /* Check if this is a Node (or subclass) for transform properties */
    int is_node = (strstr(class_name, "m3g/Node") != NULL ||
                   strstr(class_name, "m3g/Group") != NULL ||
                   strstr(class_name, "m3g/World") != NULL ||
                   strstr(class_name, "m3g/Camera") != NULL ||
                   strstr(class_name, "m3g/Mesh") != NULL ||
                   strstr(class_name, "m3g/Sprite3D") != NULL ||
                   strstr(class_name, "m3g/Light") != NULL ||
                   strstr(class_name, "m3g/MorphingMesh") != NULL ||
                   strstr(class_name, "m3g/SkinnedMesh") != NULL);
    
    (void)jvm;
    
    switch (property) {
    case M3G_ANIM_TRANSLATION:
        if (!is_node) {
            static int diag_nonnode = 0;
            if (diag_nonnode++ < 8)
                fprintf(stderr, "[ANIM-DIAG] TRANSLATION track on non-Node %s (dropped)\n",
                        (obj && obj->header.clazz && obj->header.clazz->class_name)
                            ? obj->header.clazz->class_name : "?");
        }
        if (is_node && num_components >= 3) {
            /* v14 FIX: animation used to write into a float[] field named
             * "translation" that DOES NOT EXIST on the Node stubs (silently
             * dropped by m3g_set_ref_field) — animated nodes never moved and
             * stayed at the origin (M3GTest scene 5 "objects in one point",
             * scene 7 collapse). The renderer builds node transforms from
             * the scalar fields, so write those. */
            m3g_set_float_field(obj, "translationX", values[0]);
            m3g_set_float_field(obj, "translationY", values[1]);
            m3g_set_float_field(obj, "translationZ", values[2]);
        }
        break;
        
    case M3G_ANIM_ORIENTATION:
        if (is_node && num_components >= 4) {
            /* v14: the keyframe value is a quaternion (x, y, z, w) — convert
             * to the angle+axis form used by the renderer fields. */
            float qx = values[0], qy = values[1], qz = values[2], qw = values[3];
            float qn = sqrtf(qx*qx + qy*qy + qz*qz + qw*qw);
            if (qn > 1e-6f) { qx /= qn; qy /= qn; qz /= qn; qw /= qn; }
            if (qw < 0.0f) { /* shortest arc */
                qx = -qx; qy = -qy; qz = -qz; qw = -qw;
            }
            float half_sin = sqrtf(qx*qx + qy*qy + qz*qz);
            float angle_deg;
            if (half_sin < 1e-6f) {
                angle_deg = 0.0f;
                m3g_set_float_field(obj, "orientationAngle", 0.0f);
                m3g_set_float_field(obj, "orientationX", 0.0f);
                m3g_set_float_field(obj, "orientationY", 0.0f);
                m3g_set_float_field(obj, "orientationZ", 1.0f);
            } else {
                angle_deg = 2.0f * acosf(qw) * (180.0f / 3.14159265f);
                m3g_set_float_field(obj, "orientationAngle", angle_deg);
                m3g_set_float_field(obj, "orientationX", qx / half_sin);
                m3g_set_float_field(obj, "orientationY", qy / half_sin);
                m3g_set_float_field(obj, "orientationZ", qz / half_sin);
            }
        }
        break;
        
    case M3G_ANIM_SCALE:
        if (is_node && num_components >= 1) {
            /* v14 FIX: write scalar scale fields (see TRANSLATION comment) */
            if (num_components == 1) {
                m3g_set_float_field(obj, "scaleX", values[0]);
                m3g_set_float_field(obj, "scaleY", values[0]);
                m3g_set_float_field(obj, "scaleZ", values[0]);
            } else {
                m3g_set_float_field(obj, "scaleX", values[0]);
                if (num_components >= 3) {
                    m3g_set_float_field(obj, "scaleY", values[1]);
                    m3g_set_float_field(obj, "scaleZ", values[2]);
                } else {
                    m3g_set_float_field(obj, "scaleY", values[1]);
                    m3g_set_float_field(obj, "scaleZ", 1.0f);
                }
            }
        }
        break;
        
    case M3G_ANIM_ALPHA:
        if (is_node && num_components >= 1) {
            m3g_set_float_field(obj, "alphaFactor", values[0]);
        }
        break;
        
    case M3G_ANIM_VISIBILITY:
        /* v26 FIX (audit item: visibility tracks were no-ops): JSR-184 VISIBILITY
         * tracks animate Node rendering enable state. The renderer consults the
         * 'renderingEnable' field, so drive it directly: sample < 0.5 = hidden. */
        if (is_node && num_components >= 1) {
            m3g_set_int_field(obj, "renderingEnable", values[0] >= 0.5f ? 1 : 0);
        }
        break;
        
    case M3G_ANIM_PICKABILITY:
        /* Similar to visibility */
        break;
        
    case M3G_ANIM_FIELD_OF_VIEW:
        if (strstr(class_name, "m3g/Camera") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "fov", values[0]);
        }
        break;

    case M3G_ANIM_COLOR:
        /* v14: Background COLOR animation (M3GTest scene 5 animates the
         * background hue) — values are (r, g, b, a) floats 0..1. */
        if (strstr(class_name, "m3g/Background") != NULL && num_components >= 3) {
            int r = (int)(values[0] * 255.0f + 0.5f);
            int g = (int)(values[1] * 255.0f + 0.5f);
            int b = (int)(values[2] * 255.0f + 0.5f);
            int a = (num_components >= 4) ? (int)(values[3] * 255.0f + 0.5f) : 255;
            if (r < 0) r = 0;
            if (r > 255) r = 255;
            if (g < 0) g = 0;
            if (g > 255) g = 255;
            if (b < 0) b = 0;
            if (b > 255) b = 255;
            if (a < 0) a = 0;
            if (a > 255) a = 255;
            m3g_set_int_field(obj, "clearColor",
                              ((uint32_t)a << 24) | ((uint32_t)r << 16) |
                              ((uint32_t)g << 8) | (uint32_t)b);
        }
        break;
        
    case M3G_ANIM_INTENSITY:
        if (strstr(class_name, "m3g/Light") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "intensity", values[0]);
        }
        break;

    /* v23: the remaining 12 JSR-184 animation targets — previously every
     * one of these landed in [ANIM-DIAG] "unsupported" and was dropped. */
    case M3G_ANIM_AMBIENT_COLOR:
        if (strstr(class_name, "m3g/Material") != NULL && num_components >= 3) {
            int r = (int)(values[0] * 255.0f + 0.5f);
            int g = (int)(values[1] * 255.0f + 0.5f);
            int b = (int)(values[2] * 255.0f + 0.5f);
            jint a = m3g_get_int_field(obj, "ambient", 0x00333333);
            m3g_set_int_field(obj, "ambient",
                              (a & 0xFF000000u) |
                              (((uint32_t)r & 0xFF) << 16) |
                              (((uint32_t)g & 0xFF) << 8) | ((uint32_t)b & 0xFF));
        }
        break;

    case M3G_ANIM_DIFFUSE_COLOR:
        if (strstr(class_name, "m3g/Material") != NULL && num_components >= 3) {
            int r = (int)(values[0] * 255.0f + 0.5f);
            int g = (int)(values[1] * 255.0f + 0.5f);
            int b = (int)(values[2] * 255.0f + 0.5f);
            jint a = m3g_get_int_field(obj, "diffuse", 0xFFCCCCCC);
            m3g_set_int_field(obj, "diffuse",
                              (a & 0xFF000000u) |
                              (((uint32_t)r & 0xFF) << 16) |
                              (((uint32_t)g & 0xFF) << 8) | ((uint32_t)b & 0xFF));
        }
        break;

    case M3G_ANIM_EMISSIVE_COLOR:
        if (strstr(class_name, "m3g/Material") != NULL && num_components >= 3) {
            int r = (int)(values[0] * 255.0f + 0.5f);
            int g = (int)(values[1] * 255.0f + 0.5f);
            int b = (int)(values[2] * 255.0f + 0.5f);
            jint a = m3g_get_int_field(obj, "emissive", 0xFF000000);
            m3g_set_int_field(obj, "emissive",
                              (a & 0xFF000000u) |
                              (((uint32_t)r & 0xFF) << 16) |
                              (((uint32_t)g & 0xFF) << 8) | ((uint32_t)b & 0xFF));
        }
        break;

    case M3G_ANIM_SPECULAR_COLOR:
        if (strstr(class_name, "m3g/Material") != NULL && num_components >= 3) {
            int r = (int)(values[0] * 255.0f + 0.5f);
            int g = (int)(values[1] * 255.0f + 0.5f);
            int b = (int)(values[2] * 255.0f + 0.5f);
            jint a = m3g_get_int_field(obj, "specular", 0xFF000000);
            m3g_set_int_field(obj, "specular",
                              (a & 0xFF000000u) |
                              (((uint32_t)r & 0xFF) << 16) |
                              (((uint32_t)g & 0xFF) << 8) | ((uint32_t)b & 0xFF));
        }
        break;

    case M3G_ANIM_SHININESS:
        if (strstr(class_name, "m3g/Material") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "shininess", values[0]);
        }
        break;

    case M3G_ANIM_DENSITY:
        if (strstr(class_name, "m3g/Fog") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "density", values[0]);
        }
        break;

    case M3G_ANIM_FAR_DISTANCE:
        if (strstr(class_name, "m3g/Fog") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "farDistance", values[0]);
        }
        break;

    case M3G_ANIM_NEAR_DISTANCE:
        if ((strstr(class_name, "m3g/Fog") != NULL ||
             strstr(class_name, "m3g/Camera") != NULL) && num_components >= 1) {
            /* Fog stores nearDistance; Camera stores near */
            if (strstr(class_name, "m3g/Camera") != NULL) {
                m3g_set_float_field(obj, "near", values[0]);
            } else {
                m3g_set_float_field(obj, "nearDistance", values[0]);
            }
        }
        break;

    case M3G_ANIM_SPOT_ANGLE:
        if (strstr(class_name, "m3g/Light") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "spotAngle", values[0]);
        }
        break;

    case M3G_ANIM_SPOT_EXPONENT:
        if (strstr(class_name, "m3g/Light") != NULL && num_components >= 1) {
            m3g_set_float_field(obj, "spotExponent", values[0]);
        }
        break;

    case M3G_ANIM_CROP:
        /* Sprite3D / Sprite / Background crop animation:
         * values = (cropX, cropY, cropWidth, cropHeight). */
        if (num_components >= 2) {
            int cx = (int)(values[0] + (values[0] >= 0.0f ? 0.5f : -0.5f));
            int cy = (int)(values[1] + (values[1] >= 0.0f ? 0.5f : -0.5f));
            m3g_set_int_field(obj, "cropX", cx);
            m3g_set_int_field(obj, "cropY", cy);
            if (num_components >= 4) {
                int cw = (int)(values[2] + (values[2] >= 0.0f ? 0.5f : -0.5f));
                int ch = (int)(values[3] + (values[3] >= 0.0f ? 0.5f : -0.5f));
                m3g_set_int_field(obj, "cropWidth", cw);
                m3g_set_int_field(obj, "cropHeight", ch);
            }
        }
        break;

    case M3G_ANIM_MORPH_WEIGHTS:
        /* MorphingMesh weight animation — the morph renderer reads the
         * "morphWeights" float[] every frame, so animating it is enough. */
        if (strstr(class_name, "m3g/MorphingMesh") != NULL && num_components >= 1) {
            JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "morphWeights");
            int target_count = m3g_get_int_field(obj, "morphTargetCount", 0);
            if (!dst || dst->length < target_count) {
                dst = jvm_new_array(jvm, T_FLOAT,
                                    target_count > 0 ? target_count : num_components, NULL);
                if (dst) m3g_set_ref_field(obj, "morphWeights", (JavaObject*)dst);
            }
            if (dst && dst->element_type == T_FLOAT) {
                jfloat* d = (jfloat*)array_data(dst);
                int n = (int)dst->length < num_components ? (int)dst->length : num_components;
                for (int i = 0; i < n; i++) {
                    d[i] = values[i];
                }
            }
        }
        break;

    default:
        /* Other properties not yet implemented.
         * v20 [ANIM-DIAG]: silently dropped animation properties were
         * invisible; log each distinct (class,property) pair once so losses
         * show up in game logs. */
        {
            static uint64_t diag_mask[4] = {0, 0, 0, 0};  /* 256 property bits */
            if (property >= 256 && property < 256 + 256) {
                uint64_t bit = 1ULL << (property - 256);
                if (!(diag_mask[(property - 256) >> 6] & bit)) {
                    diag_mask[(property - 256) >> 6] |= bit;
                    fprintf(stderr,
                            "[ANIM-DIAG] unsupported animation property %d on %s (dropped)\n",
                            property,
                            (obj && obj->header.clazz && obj->header.clazz->class_name)
                                ? obj->header.clazz->class_name : "?");
                }
            }
        }
        break;
    }
}

/* Recursively animate an Object3D and its children.
 * Returns the minimum validity (time until animation state may change), or 0x7FFFFFFF if inactive. */
static jint m3g_animate_object(JVM* jvm, JavaObject* obj, jint world_time) {
    if (!obj) return 0x7FFFFFFF;
    
    jint min_validity = 0x7FFFFFFF;
    
    /* Get animation tracks for this object */
    JavaArray* tracks = (JavaArray*)m3g_get_ref_field(obj, "animTracks");
    if (tracks && tracks->element_type == DESC_OBJECT) {
        jsize track_count = tracks->length;
        JavaObject** track_arr = (JavaObject**)array_data(tracks);
        
        /* Process tracks grouped by property for blending */
        int ti = 0;
        while (ti < track_count) {
            JavaObject* track = track_arr[ti];
            if (!track) { ti++; continue; }
            
            JavaObject* controller = (JavaObject*)m3g_get_ref_field(track, "controller");
            jint property = m3g_get_int_field(track, "propertyId", -1);
            JavaObject* sequence = (JavaObject*)m3g_get_ref_field(track, "sequence");
            
            if (!sequence || property < 0) { ti++; continue; }
            
            jint num_comp = m3g_get_int_field(sequence, "numComponents", 0);
            if (num_comp <= 0 || num_comp > 16) { ti++; continue; }
            
            jfloat accum[16];
            memset(accum, 0, sizeof(accum));
            jfloat sum_weights = 0.0f;
            
            /* Accumulate contributions from all tracks targeting the same property */
            do {
                if (!track) { ti++; break; }
                
                controller = (JavaObject*)m3g_get_ref_field(track, "controller");
                property = m3g_get_int_field(track, "propertyId", -1);
                sequence = (JavaObject*)m3g_get_ref_field(track, "sequence");
                
                if (controller && sequence && m3g_anim_is_active(controller, world_time)) {
                    jfloat weight = m3g_get_float_field(controller, "weight", 1.0f);
                    /* v24: AnimationTrack.setWeight scales the track contribution */
                    weight *= m3g_get_float_field(track, "weight", 1.0f);
                    
                    if (weight > 0.0f) {
                        jfloat sample[16];
                        jint seq_time = (jint)m3g_anim_get_position(controller, world_time);
                        
                        if (m3g_anim_sample_linear(sequence, seq_time, sample, num_comp)) {
                            for (int c = 0; c < num_comp; c++) {
                                accum[c] += sample[c] * weight;
                            }
                            sum_weights += weight;
                        }
                    }
                    
                    jint validity = m3g_anim_time_to_deactivation(controller, world_time);
                    if (validity < min_validity) min_validity = validity;
                }
                
                ti++;
                if (ti < track_count) track = track_arr[ti];
            } while (ti < track_count && track &&
                     m3g_get_int_field(track, "propertyId", -1) == property);
            
            /* Apply the accumulated value */
            if (sum_weights > 0.0f) {
                m3g_anim_apply_property(jvm, obj, property, num_comp, accum);
            }
        }
    }
    
    /* Recurse into children if this is a Group/World */
    const char* class_name = obj->header.clazz ? obj->header.clazz->class_name : "";
    int is_group = (strstr(class_name, "m3g/Group") != NULL || strstr(class_name, "m3g/World") != NULL);
    
    if (is_group) {
        JavaArray* children = (JavaArray*)m3g_get_ref_field(obj, "children");
        if (children && children->element_type == DESC_OBJECT) {
            JavaObject** child_arr = (JavaObject**)array_data(children);
            int ani_safe = m3g_get_int_field(obj, "childCount", (int)children->length);
            if (ani_safe > (int)children->length) ani_safe = (int)children->length;
            for (jsize ci = 0; ci < ani_safe; ci++) {
                JavaObject* child = child_arr[ci];
                if (child) {
                    jint child_validity = m3g_animate_object(jvm, child, world_time);
                    if (child_validity < min_validity) min_validity = child_validity;
                }
            }
        }
    }
    
    return min_validity;
}

/* ---- AnimationTrack native methods ---- */

static JavaValue native_animationtrack_setController(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* track = (JavaObject*)args[0].ref;
    JavaObject* controller = (JavaObject*)args[1].ref;
    
    if (track) {
        m3g_set_ref_field(track, "controller", controller);
        GFX_DEBUG("AnimationTrack.setController: track=%p controller=%p", (void*)track, (void*)controller);
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_animationtrack_getTargetProperty(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* track = (JavaObject*)args[0].ref;
    
    if (!track) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(track, "propertyId", 0));
}

/* ---- KeyframeSequence native methods ---- */

static JavaValue native_keyframesequence_setKeyframe(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    jint time = args[2].i;
    JavaArray* value_arr = (JavaArray*)args[3].ref;
    
    if (!seq || !value_arr) return NATIVE_RETURN_VOID();
    
    jint num_kf = m3g_get_int_field(seq, "numKeyframes", 0);
    jint num_comp = m3g_get_int_field(seq, "numComponents", 0);
    
    if (index < 0 || index >= num_kf) return NATIVE_RETURN_VOID();
    
    /* Get or create the keyframe times and values arrays */
    JavaArray* kf_times = (JavaArray*)m3g_get_ref_field(seq, "keyframeTimes");
    JavaArray* kf_values = (JavaArray*)m3g_get_ref_field(seq, "keyframeValues");
    
    if (!kf_times) {
        kf_times = jvm_new_array(jvm, T_INT, num_kf, NULL);
        m3g_set_ref_field(seq, "keyframeTimes", (JavaObject*)kf_times);
    }
    if (!kf_values) {
        kf_values = jvm_new_array(jvm, T_FLOAT, num_kf * num_comp, NULL);
        m3g_set_ref_field(seq, "keyframeValues", (JavaObject*)kf_values);
    }
    
    if (kf_times && kf_values) {
        jint* times = (jint*)array_data(kf_times);
        jfloat* values = (jfloat*)array_data(kf_values);
        
        times[index] = time;
        
        jint copy_count = value_arr->length < num_comp ? value_arr->length : num_comp;
        if (value_arr->element_type == T_FLOAT) {
            jfloat* src = (jfloat*)array_data(value_arr);
            for (jint i = 0; i < copy_count; i++) {
                values[index * num_comp + i] = src[i];
            }
        }
        
        /* For SLERP/SQUAD, normalize quaternion keyframes */
        jint interpolation = m3g_normalize_interpolation(m3g_get_int_field(seq, "interpolation", M3G_KF_LINEAR));
        if ((interpolation == M3G_KF_SLERP || interpolation == M3G_KF_SQUAD) && num_comp == 4) {
            jfloat* q = &values[index * 4];
            jfloat len = sqrtf(q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3]);
            if (len > 0.0001f) {
                q[0] /= len; q[1] /= len; q[2] /= len; q[3] /= len;
            }
        }
    }
    
    GFX_DEBUG("KeyframeSequence.setKeyframe: index=%d, time=%d", index, time);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_keyframesequence_getDuration(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "duration", 0));
}

static JavaValue native_keyframesequence_setDuration(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint duration = args[1].i;
    if (!seq) return NATIVE_RETURN_VOID();
    m3g_set_int_field(seq, "duration", duration);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_keyframesequence_getRepeatMode(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(M3G_REPEAT_CONSTANT);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "repeatMode", M3G_REPEAT_CONSTANT));
}

static JavaValue native_keyframesequence_setRepeatMode(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    if (!seq) return NATIVE_RETURN_VOID();
    m3g_set_int_field(seq, "repeatMode", mode);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_keyframesequence_getComponentCount(JVM* jvm, JavaThread* thread,
                                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "numComponents", 0));
}

static JavaValue native_keyframesequence_getKeyframeCount(JVM* jvm, JavaThread* thread,
                                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "numKeyframes", 0));
}

static JavaValue native_keyframesequence_getInterpolationType(JVM* jvm, JavaThread* thread,
                                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(M3G_KF_LINEAR);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "interpolation", M3G_KF_LINEAR));
}

static JavaValue native_keyframesequence_getKeyframe(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)thread;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint frame_index = args[1].i;
    JavaArray* value_arr = (JavaArray*)args[2].ref;
    
    if (!seq) return NATIVE_RETURN_INT(0);
    
    jint num_kf = m3g_get_int_field(seq, "numKeyframes", 0);
    jint num_comp = m3g_get_int_field(seq, "numComponents", 0);
    
    if (frame_index < 0 || frame_index >= num_kf) return NATIVE_RETURN_INT(0);
    
    /* Get the time */
    JavaArray* kf_times = (JavaArray*)m3g_get_ref_field(seq, "keyframeTimes");
    jint time = 0;
    if (kf_times) {
        jint* times = (jint*)array_data(kf_times);
        time = times[frame_index];
    }
    
    /* Copy values to output array */
    if (value_arr && value_arr->element_type == T_FLOAT) {
        JavaArray* kf_values = (JavaArray*)m3g_get_ref_field(seq, "keyframeValues");
        if (kf_values) {
            jfloat* values = (jfloat*)array_data(kf_values);
            jfloat* out = (jfloat*)array_data(value_arr);
            jint copy_count = value_arr->length < num_comp ? value_arr->length : num_comp;
            for (jint i = 0; i < copy_count; i++) {
                out[i] = values[frame_index * num_comp + i];
            }
        }
    }
    
    (void)jvm; (void)arg_count;
    return NATIVE_RETURN_INT(time);
}

static JavaValue native_keyframesequence_setValidRange(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint last = args[2].i;
    if (!seq) return NATIVE_RETURN_VOID();
    m3g_set_int_field(seq, "firstValid", first);
    m3g_set_int_field(seq, "lastValid", last);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_keyframesequence_getValidRangeFirst(JVM* jvm, JavaThread* thread,
                                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "firstValid", 0));
}

static JavaValue native_keyframesequence_getValidRangeLast(JVM* jvm, JavaThread* thread,
                                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    if (!seq) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(seq, "lastValid", 0));
}

/* ---- AnimationController native methods ---- */

static JavaValue native_animationcontroller_setActiveInterval(JVM* jvm, JavaThread* thread,
                                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    jint start = args[1].i;
    jint end = args[2].i;
    if (!ctrl) return NATIVE_RETURN_VOID();
    m3g_set_int_field(ctrl, "activationTime", start);
    m3g_set_int_field(ctrl, "deactivationTime", end);
    GFX_DEBUG("AnimationController.setActiveInterval: %d - %d", start, end);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_animationcontroller_getActiveIntervalStart(JVM* jvm, JavaThread* thread,
                                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    if (!ctrl) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(ctrl, "activationTime", 0));
}

static JavaValue native_animationcontroller_getActiveIntervalEnd(JVM* jvm, JavaThread* thread,
                                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    if (!ctrl) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(ctrl, "deactivationTime", 0));
}

static JavaValue native_animationcontroller_setSpeed(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    jfloat factor = args[1].f;
    jint world_time = args[2].i;
    if (!ctrl) return NATIVE_RETURN_VOID();
    
    /* Update ref time so position remains continuous */
    jfloat old_pos = m3g_anim_get_position(ctrl, world_time);
    m3g_set_int_field(ctrl, "refWorldTime", world_time);
    m3g_set_float_field(ctrl, "refSequenceTime", old_pos);
    m3g_set_float_field(ctrl, "speed", factor);
    
    GFX_DEBUG("AnimationController.setSpeed: %.2f at worldTime=%d", factor, world_time);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_animationcontroller_getSpeed(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    if (!ctrl) return NATIVE_RETURN_FLOAT(1.0f);
    return NATIVE_RETURN_FLOAT(m3g_get_float_field(ctrl, "speed", 1.0f));
}

static JavaValue native_animationcontroller_setPosition(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    jfloat seq_time = args[1].f;
    jint world_time = args[2].i;
    if (!ctrl) return NATIVE_RETURN_VOID();
    m3g_set_int_field(ctrl, "refWorldTime", world_time);
    m3g_set_float_field(ctrl, "refSequenceTime", seq_time);
    GFX_DEBUG("AnimationController.setPosition: seqTime=%.2f at worldTime=%d", seq_time, world_time);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_animationcontroller_getPosition(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    jint world_time = args[1].i;
    if (!ctrl) return NATIVE_RETURN_FLOAT(0.0f);
    return NATIVE_RETURN_FLOAT(m3g_anim_get_position(ctrl, world_time));
}

static JavaValue native_animationcontroller_setWeight(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    jfloat weight = args[1].f;
    if (!ctrl) return NATIVE_RETURN_VOID();
    m3g_set_float_field(ctrl, "weight", weight);
    GFX_DEBUG("AnimationController.setWeight: %.2f", weight);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_animationcontroller_getWeight(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    if (!ctrl) return NATIVE_RETURN_FLOAT(1.0f);
    return NATIVE_RETURN_FLOAT(m3g_get_float_field(ctrl, "weight", 1.0f));
}

static JavaValue native_animationcontroller_getRefWorldTime(JVM* jvm, JavaThread* thread,
                                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* ctrl = (JavaObject*)args[0].ref;
    if (!ctrl) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(ctrl, "refWorldTime", 0));
}

/* ---- Object3D animation native methods ---- */

static JavaValue native_object3d_addAnimationTrack(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* track = (JavaObject*)args[1].ref;
    
    if (!obj || !track) return NATIVE_RETURN_VOID();
    
    /* Get or create the animTracks array */
    JavaArray* tracks = (JavaArray*)m3g_get_ref_field(obj, "animTracks");
    if (!tracks) {
        /* Allocate initial array for up to 8 tracks */
        tracks = jvm_new_array(jvm, DESC_OBJECT, 8, NULL);
        m3g_set_ref_field(obj, "animTracks", (JavaObject*)tracks);
    }
    
    if (tracks && tracks->element_type == DESC_OBJECT) {
        /* Find empty slot or expand */
        JavaObject** arr = (JavaObject**)array_data(tracks);
        jsize len = tracks->length;
        jsize empty = -1;
        for (jsize i = 0; i < len; i++) {
            if (arr[i] == NULL) { empty = i; break; }
        }
        
        if (empty >= 0) {
            arr[empty] = track;
        } else {
            /* Expand array (simple realloc) */
            /* For now, just print warning if full */
            GFX_DEBUG("Object3D.addAnimationTrack: track array full (max %d)", len);
        }
    }
    
    GFX_DEBUG("Object3D.addAnimationTrack: obj=%p track=%p", (void*)obj, (void*)track);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_object3d_removeAnimationTrack(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* track = (JavaObject*)args[1].ref;
    
    if (!obj || !track) return NATIVE_RETURN_VOID();
    
    JavaArray* tracks = (JavaArray*)m3g_get_ref_field(obj, "animTracks");
    if (tracks && tracks->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(tracks);
        for (jsize i = 0; i < tracks->length; i++) {
            if (arr[i] == track) {
                arr[i] = NULL;
                break;
            }
        }
    }
    
    GFX_DEBUG("Object3D.removeAnimationTrack");
    return NATIVE_RETURN_VOID();
}

static JavaValue native_object3d_getAnimationTrackCount(JVM* jvm, JavaThread* thread,
                                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    
    jint count = 0;
    JavaArray* tracks = (JavaArray*)m3g_get_ref_field(obj, "animTracks");
    if (tracks && tracks->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(tracks);
        for (jsize i = 0; i < tracks->length; i++) {
            if (arr[i] != NULL) count++;
        }
    }
    return NATIVE_RETURN_INT(count);
}

static JavaValue native_object3d_getAnimationTrack(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    JavaArray* tracks = (JavaArray*)m3g_get_ref_field(obj, "animTracks");
    if (tracks && tracks->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(tracks);
        /* Count non-null entries to find by index */
        jint count = 0;
        for (jsize i = 0; i < tracks->length; i++) {
            if (arr[i] != NULL) {
                if (count == index) return NATIVE_RETURN_OBJECT(arr[i]);
                count++;
            }
        }
    }
    return NATIVE_RETURN_NULL();
}

static JavaValue native_object3d_animate(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint world_time = args[1].i;
    
    if (!obj) return NATIVE_RETURN_INT(0x7FFFFFFF);
    
    jint validity = m3g_animate_object(jvm, obj, world_time);
    
    GFX_DEBUG("Object3D.animate: worldTime=%d validity=%d", world_time, validity);
    return NATIVE_RETURN_INT(validity);
}

/* Sprite3D methods */
static JavaValue native_sprite3d_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jboolean scaled = args[1].i;
    JavaObject* image = (JavaObject*)args[2].ref;
    JavaObject* appearance = (JavaObject*)args[3].ref;
    
    /* v12 FIX: was an empty stub — the image/appearance/scaled were silently
     * dropped, so Sprite3D.getImage() later returned NULL and games crashed
     * with NPE on Image2D.getWidth() (SU-30 lost its 3D this way). */
    if (obj) {
        m3g_set_ref_field(obj, "image", image);
        m3g_set_ref_field(obj, "appearance", appearance);
        m3g_set_int_field(obj, "scaled", scaled ? 1 : 0);
        m3g_set_int_field(obj, "cropX", 0);
        m3g_set_int_field(obj, "cropY", 0);
        m3g_set_int_field(obj, "cropWidth", -1);
        m3g_set_int_field(obj, "cropHeight", -1);
        m3g_set_int_field(obj, "renderingEnable", 1);  /* v14: Node zero-init guard */
    }
    GFX_DEBUG("Sprite3D.<init>: image=%p scaled=%d", (void*)image, scaled ? 1 : 0);
        {
        static int spr_create_logs = -1;
        if (spr_create_logs < 0) spr_create_logs = getenv("NOJME_SPRITE_TRACE") ? 24 : 0;
        if (spr_create_logs > 0 && spr_create_logs-- > 0) {
            JavaObject* self = (JavaObject*)args[0].ref;
            fprintf(stderr, "[SPRITE3D-CREATE] sprite=%p scaled=%d img=%p app=%p\n",
                    (void*)self, args[1].i,
                    args[2].ref, arg_count > 3 ? args[3].ref : NULL);
        }
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sprite3d_setImage(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    
    /* v12 FIX: store the image (was an empty stub) */
    if (obj) m3g_set_ref_field(obj, "image", image);
    GFX_DEBUG("Sprite3D.setImage: %p", (void*)image);
    return NATIVE_RETURN_VOID();
}

/* v12: Sprite3D.getImage() — JSR-184 accessor; games call it right after
 * building sprites (SU-30: getImage().getWidth() → NPE on NULL before). */
static JavaValue native_sprite3d_getImage(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_NULL();
    return NATIVE_RETURN_OBJECT(m3g_get_ref_field(obj, "image"));
}

static JavaValue native_sprite3d_isScaled(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "scaled", 0));
}

static JavaValue native_sprite3d_setScaled(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (obj) m3g_set_int_field(obj, "scaled", args[1].i ? 1 : 0);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sprite3d_setCrop(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (obj) {
        m3g_set_int_field(obj, "cropX", args[1].i);
        m3g_set_int_field(obj, "cropY", args[2].i);
        m3g_set_int_field(obj, "cropWidth", args[3].i);
        m3g_set_int_field(obj, "cropHeight", args[4].i);
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sprite3d_getCropX(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "cropX", 0));
}

static JavaValue native_sprite3d_getCropY(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "cropY", 0));
}

static JavaValue native_sprite3d_getCropWidth(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "cropWidth", -1));
}

static JavaValue native_sprite3d_getCropHeight(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "cropHeight", -1));
}

/* ============================================================================
 * Stub Class Registration for M3G Classes
 * ============================================================================ */

/* Helper: Add an instance field to a JavaClass (for M3G stub classes) */
static void m3g_add_instance_field(JavaClass* clazz, const char* name,
                                    const char* descriptor, uint16_t access_flags) {
    if (!clazz || !name || !descriptor) return;

    /* GUARD: Skip if a field with this name already exists (prevent duplicates).
     * stubs.c:init_stub_classes() used to add the same fields, causing duplicates
     * that doubled instance_size and shifted all slot indices. */
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, name) == 0) {
            return;  /* Field already exists — skip */
        }
    }

    /* Allocate or extend fields array */
    int new_count = clazz->fields_count + 1;
    JavaField* new_fields = (JavaField*)realloc(clazz->fields, new_count * sizeof(JavaField));
    if (!new_fields) return;

    clazz->fields = new_fields;
    JavaField* field = &clazz->fields[clazz->fields_count];
    memset(field, 0, sizeof(JavaField));
    field->name = strdup(name);
    field->descriptor = strdup(descriptor);
    field->access_flags = access_flags;
    clazz->fields_count = new_count;
}

/* Recalculate instance_size for an M3G class including inherited fields.
 * Must be called after adding fields and after superclass is loaded.
 * IMPORTANT: processes classes in parent-before-child order. */
static void m3g_recalc_instance_size(JVM* jvm, JavaClass* clazz) {
    if (!clazz) return;

    /* Ensure superclass is loaded */
    if (clazz->super_class_name && !clazz->super_class) {
        clazz->super_class = jvm_load_class(jvm, clazz->super_class_name);
    }

    /* Start with superclass size */
    size_t size = sizeof(ObjectHeader);
    if (clazz->super_class) {
        m3g_recalc_instance_size(jvm, clazz->super_class);
        if (clazz->super_class->instance_size >= sizeof(ObjectHeader)) {
            size = clazz->super_class->instance_size;
        }
    }

    /* Add own instance fields */
    if (clazz->fields) {
        for (int i = 0; i < clazz->fields_count; i++) {
            JavaField* field = &clazz->fields[i];
            if (field->access_flags & ACC_STATIC) continue;
            size += sizeof(JavaValue);
            if (field->descriptor &&
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                size += sizeof(JavaValue);
            }
        }
    }

    clazz->instance_size = size;
}

/* Register M3G stub classes WITH their instance fields.
 *
 * CRITICAL FIX: M3G stub classes created by get_or_create_stub_class() have
 * NO Java fields (fields_count=0, instance_size=sizeof(ObjectHeader)). This
 * means m3g_find_field_slot() always returns -1, and ALL m3g_get/set_field
 * calls silently do nothing. This is the root cause of:
 *   - addChild() children not persisting (m3g_set_ref_field("children") no-op)
 *   - renderNode finding children=NULL, count=-1
 *   - bindTarget/render never working properly
 *   - All M3G state being lost between calls
 *
 * The fix: explicitly add the instance fields needed by the M3G native code
 * to each stub class, then recalculate instance_size so jvm_new_object()
 * allocates enough space for the fields array.
 */
int init_m3g_stub_classes(JVM* jvm) {
    if (!jvm) return 0;

    extern JavaClass* get_or_create_stub_class(JVM* jvm, const char* class_name);

    JavaClass* stub;
    int count = 0;

    /* ========================================================================
     * CRITICAL FIX: Proper M3G class hierarchy setup
     * ========================================================================
     * get_or_create_stub_class() defaults super_class to java/lang/Object
     * for all classes not in its hardcoded switch. This causes:
     *   - m3g_find_field_slot() to compute wrong slot indices (flat hierarchy)
     *   - m3g_recalc_instance_size() to compute wrong instance_size
     *   - Objects allocated too small → heap corruption when writing fields
     *   - "Free Heap block modified after freed" crashes
     *
     * The fix: create all stubs FIRST, then set correct super_class pointers,
     * then add fields and recalc sizes. The hierarchy is:
     *   java/lang/Object
     *     → Object3D
     *       → Transformable
     *       → Node (includes Transformable fields, skips Transformable class)
     *         → Group
     *           → World
     *         → Camera
     *         → Light
     *         → Mesh
     *           → MorphingMesh
     *           → SkinnedMesh
     *         → Sprite3D
     *       → Background
     *       → Material
     *       → Texture2D
     *       → Image2D
     *     → VertexArray
     *     → VertexBuffer
     *     → IndexBuffer
     *       → TriangleStripArray
     *     → AnimationTrack
     *     → AnimationController
     *     → KeyframeSequence
     *     → CompositingMode
     *     → Fog
     *     → Appearance
     *     → Transform
     *     → RayIntersection
     *     → Graphics3D
     *     → Loader
     * ======================================================================== */

    /* === Phase 1: Create all M3G stub classes === */
    JavaClass* cls_object3d       = get_or_create_stub_class(jvm, "javax/microedition/m3g/Object3D");
    JavaClass* cls_transformable  = get_or_create_stub_class(jvm, "javax/microedition/m3g/Transformable");
    JavaClass* cls_node           = get_or_create_stub_class(jvm, "javax/microedition/m3g/Node");
    JavaClass* cls_group          = get_or_create_stub_class(jvm, "javax/microedition/m3g/Group");
    JavaClass* cls_world          = get_or_create_stub_class(jvm, "javax/microedition/m3g/World");
    JavaClass* cls_camera         = get_or_create_stub_class(jvm, "javax/microedition/m3g/Camera");
    JavaClass* cls_light          = get_or_create_stub_class(jvm, "javax/microedition/m3g/Light");
    JavaClass* cls_mesh           = get_or_create_stub_class(jvm, "javax/microedition/m3g/Mesh");
    JavaClass* cls_morphing_mesh  = get_or_create_stub_class(jvm, "javax/microedition/m3g/MorphingMesh");
    JavaClass* cls_skinned_mesh   = get_or_create_stub_class(jvm, "javax/microedition/m3g/SkinnedMesh");
    JavaClass* cls_sprite3d       = get_or_create_stub_class(jvm, "javax/microedition/m3g/Sprite3D");
    JavaClass* cls_background     = get_or_create_stub_class(jvm, "javax/microedition/m3g/Background");
    JavaClass* cls_material       = get_or_create_stub_class(jvm, "javax/microedition/m3g/Material");
    JavaClass* cls_texture2d      = get_or_create_stub_class(jvm, "javax/microedition/m3g/Texture2D");
    JavaClass* cls_image2d        = get_or_create_stub_class(jvm, "javax/microedition/m3g/Image2D");
    JavaClass* cls_vertex_array   = get_or_create_stub_class(jvm, "javax/microedition/m3g/VertexArray");
    JavaClass* cls_vertex_buffer  = get_or_create_stub_class(jvm, "javax/microedition/m3g/VertexBuffer");
    JavaClass* cls_index_buffer   = get_or_create_stub_class(jvm, "javax/microedition/m3g/IndexBuffer");
    JavaClass* cls_tri_strip_arr  = get_or_create_stub_class(jvm, "javax/microedition/m3g/TriangleStripArray");
    JavaClass* cls_anim_track     = get_or_create_stub_class(jvm, "javax/microedition/m3g/AnimationTrack");
    JavaClass* cls_anim_ctrl      = get_or_create_stub_class(jvm, "javax/microedition/m3g/AnimationController");
    JavaClass* cls_keyframe_seq   = get_or_create_stub_class(jvm, "javax/microedition/m3g/KeyframeSequence");
    JavaClass* cls_compositing    = get_or_create_stub_class(jvm, "javax/microedition/m3g/CompositingMode");
    JavaClass* cls_fog            = get_or_create_stub_class(jvm, "javax/microedition/m3g/Fog");
    JavaClass* cls_appearance     = get_or_create_stub_class(jvm, "javax/microedition/m3g/Appearance");
    JavaClass* cls_transform      = get_or_create_stub_class(jvm, "javax/microedition/m3g/Transform");
    JavaClass* cls_ray_intersect  = get_or_create_stub_class(jvm, "javax/microedition/m3g/RayIntersection");
    JavaClass* cls_graphics3d     = get_or_create_stub_class(jvm, "javax/microedition/m3g/Graphics3D");
    JavaClass* cls_loader         = get_or_create_stub_class(jvm, "javax/microedition/m3g/Loader");

    /* === Phase 2: Set up correct M3G class hierarchy === */
    /* Object3D extends java/lang/Object (keep default) */

    /* Transformable extends Object3D */
    if (cls_transformable && cls_object3d) {
        cls_transformable->super_class = cls_object3d;
    }

    /* Node extends Object3D (not Transformable — Node incorporates
     * Transformable's fields directly to match the JVM class layout) */
    if (cls_node && cls_object3d) {
        cls_node->super_class = cls_object3d;
    }

    /* Group extends Node */
    if (cls_group && cls_node) {
        cls_group->super_class = cls_node;
    }

    /* World extends Group */
    if (cls_world && cls_group) {
        cls_world->super_class = cls_group;
    }

    /* Camera extends Node */
    if (cls_camera && cls_node) {
        cls_camera->super_class = cls_node;
    }

    /* Light extends Node */
    if (cls_light && cls_node) {
        cls_light->super_class = cls_node;
    }

    /* Mesh extends Node */
    if (cls_mesh && cls_node) {
        cls_mesh->super_class = cls_node;
    }

    /* MorphingMesh extends Mesh */
    if (cls_morphing_mesh && cls_mesh) {
        cls_morphing_mesh->super_class = cls_mesh;
    }

    /* SkinnedMesh extends Mesh */
    if (cls_skinned_mesh && cls_mesh) {
        cls_skinned_mesh->super_class = cls_mesh;
    }

    /* Sprite3D extends Node */
    if (cls_sprite3d && cls_node) {
        cls_sprite3d->super_class = cls_node;
    }

    /* Background extends Object3D */
    if (cls_background && cls_object3d) {
        cls_background->super_class = cls_object3d;
    }

    /* Material extends Object3D */
    if (cls_material && cls_object3d) {
        cls_material->super_class = cls_object3d;
    }

    /* Texture2D extends Object3D */
    if (cls_texture2d && cls_object3d) {
        cls_texture2d->super_class = cls_object3d;
    }

    /* Image2D extends Object3D */
    if (cls_image2d && cls_object3d) {
        cls_image2d->super_class = cls_object3d;
    }

    /* TriangleStripArray extends IndexBuffer */
    if (cls_tri_strip_arr && cls_index_buffer) {
        cls_tri_strip_arr->super_class = cls_index_buffer;
    }

    /* Appearance extends Object3D */
    if (cls_appearance && cls_object3d) {
        cls_appearance->super_class = cls_object3d;
    }

    /* CompositingMode extends Object3D */
    if (cls_compositing && cls_object3d) {
        cls_compositing->super_class = cls_object3d;
    }

    /* Fog extends Object3D */
    if (cls_fog && cls_object3d) {
        cls_fog->super_class = cls_object3d;
    }

    /* VertexArray extends Object3D */
    if (cls_vertex_array && cls_object3d) {
        cls_vertex_array->super_class = cls_object3d;
    }

    /* VertexBuffer extends Object3D */
    if (cls_vertex_buffer && cls_object3d) {
        cls_vertex_buffer->super_class = cls_object3d;
    }

    /* IndexBuffer extends Object3D */
    if (cls_index_buffer && cls_object3d) {
        cls_index_buffer->super_class = cls_object3d;
    }

    /* AnimationTrack extends Object3D */
    if (cls_anim_track && cls_object3d) {
        cls_anim_track->super_class = cls_object3d;
    }

    /* AnimationController extends Object3D */
    if (cls_anim_ctrl && cls_object3d) {
        cls_anim_ctrl->super_class = cls_object3d;
    }

    /* KeyframeSequence extends Object3D */
    if (cls_keyframe_seq && cls_object3d) {
        cls_keyframe_seq->super_class = cls_object3d;
    }

    /* Log the hierarchy for debugging */
    fprintf(stderr, "[M3G] Class hierarchy:\n");
    if (cls_object3d) fprintf(stderr, "  Object3D → %s (instance_size=%zu, fields=%d)\n",
        cls_object3d->super_class ? cls_object3d->super_class->class_name : "none",
        cls_object3d->instance_size, cls_object3d->fields_count);
    if (cls_node) fprintf(stderr, "  Node → %s (instance_size=%zu, fields=%d)\n",
        cls_node->super_class ? cls_node->super_class->class_name : "none",
        cls_node->instance_size, cls_node->fields_count);
    if (cls_group) fprintf(stderr, "  Group → %s (instance_size=%zu, fields=%d)\n",
        cls_group->super_class ? cls_group->super_class->class_name : "none",
        cls_group->instance_size, cls_group->fields_count);
    if (cls_world) fprintf(stderr, "  World → %s (instance_size=%zu, fields=%d)\n",
        cls_world->super_class ? cls_world->super_class->class_name : "none",
        cls_world->instance_size, cls_world->fields_count);

    /* === Phase 3: Add instance fields (from root to leaves) === */

    /* === 1. Object3D (parent: java/lang/Object) === */
    stub = cls_object3d;
    if (stub) {
        m3g_add_instance_field(stub, "userID",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "animTracks", "[Ljavax/microedition/m3g/AnimationTrack;", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 2. Transformable (parent: Object3D) ===
     * Note: Node in stubs extends Object3D directly (not Transformable),
     * so Transformable's fields go onto Node below. But we still create
     * the class for getReferences()/duplicate() support. */
    stub = cls_transformable;
    if (stub) {
        m3g_add_instance_field(stub, "transform",      "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "translationX",    "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "translationY",    "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "translationZ",    "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaleX",          "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaleY",          "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaleZ",          "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationAngle", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationX",    "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationY",    "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationZ",    "F", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 3. Node (parent: Object3D) - includes Transformable fields === */
    stub = cls_node;
    if (stub) {
        /* Transformable fields (since Node skips Transformable in stubs) */
        m3g_add_instance_field(stub, "transform",       "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "translationX",     "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "translationY",     "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "translationZ",     "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaleX",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaleY",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaleZ",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationAngle", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationX",     "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationY",     "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "orientationZ",     "F", ACC_PUBLIC);
        /* Node own fields */
        m3g_add_instance_field(stub, "renderingEnable",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "pickingEnable",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "alphaFactor",      "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scope",            "I", ACC_PUBLIC);
        /* Task 16-a item 14: Node.setAlignment state (camera/screen alignment).
         * Zero-initialized = no alignment → rendering takes the legacy path. */
        m3g_add_instance_field(stub, "alignZRef",    "Ljavax/microedition/m3g/Node;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "alignZTarget", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "alignYRef",    "Ljavax/microedition/m3g/Node;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "alignYTarget", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 4. Group (parent: Node) === */
    stub = cls_group;
    if (stub) {
        m3g_add_instance_field(stub, "children",    "[Ljavax/microedition/m3g/Node;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "childCount",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "_childRefs",  "[I", ACC_PUBLIC);  /* Temporary: int array of child refs from M3G binary */
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 5. World (parent: Group) === */
    stub = cls_world;
    if (stub) {
        m3g_add_instance_field(stub, "activeCamera",     "Ljavax/microedition/m3g/Camera;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "background",       "Ljavax/microedition/m3g/Background;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "activeCameraRef",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "backgroundRef",    "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 6. Camera (parent: Node) === */
    stub = cls_camera;
    if (stub) {
        m3g_add_instance_field(stub, "projectionType",  "I",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "fov",             "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "aspect",          "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "near",            "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "far",             "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "genericMatrix",   "[F", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 7. Mesh (parent: Node) === */
    stub = cls_mesh;
    if (stub) {
        m3g_add_instance_field(stub, "vertexBuffer",    "Ljavax/microedition/m3g/VertexBuffer;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "indexBuffer",     "Ljavax/microedition/m3g/IndexBuffer;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "submeshCount",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "appearance",      "Ljavax/microedition/m3g/Appearance;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "morphTargets",    "[Ljavax/microedition/m3g/VertexBuffer;", ACC_PUBLIC);
        /* Temporary: M3G binary parser writes refs as ints, linker resolves to objects above */
        m3g_add_instance_field(stub, "vertexBufferRef",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "indexBufferRef",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "appearanceRef",    "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 8. MorphingMesh (parent: Mesh) === */
    stub = cls_morphing_mesh;
    if (stub) {
        m3g_add_instance_field(stub, "morphTargets",  "[Ljavax/microedition/m3g/VertexBuffer;", ACC_PUBLIC);
        /* v14: morph state — count and animated weights (M3GTest scene 6) */
        m3g_add_instance_field(stub, "morphTargetCount", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "morphWeights", "[F", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 9. SkinnedMesh (parent: Mesh) === */
    stub = cls_skinned_mesh;
    if (stub) {
        m3g_add_instance_field(stub, "skeleton", "Ljavax/microedition/m3g/Group;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "skeletonRef", "I", ACC_PUBLIC);
        /* v22: rigid skin bindings parsed from the file (see SkinnedMesh
         * loader case) plus the resolved bone Nodes. */
        m3g_add_instance_field(stub, "boneNodeRefs", "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "boneFirstVertex", "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "boneVertexCount", "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "boneWeights", "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "bones", "[Ljavax/microedition/m3g/Node;", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 10. Sprite3D (parent: Node) === */
    stub = cls_sprite3d;
    if (stub) {
        m3g_add_instance_field(stub, "image",      "Ljavax/microedition/m3g/Image2D;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "cropX",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "cropY",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "cropWidth",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "cropHeight", "I", ACC_PUBLIC);
        /* Task 16-a item 11: the ctor writes appearance/scaled — the slots
         * were missing entirely, so the references were silently dropped. */
        m3g_add_instance_field(stub, "appearance", "Ljavax/microedition/m3g/Appearance;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "scaled",     "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 11. Light (parent: Node) === */
    stub = cls_light;
    if (stub) {
        m3g_add_instance_field(stub, "mode",                "I",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "lightType",           "I",  ACC_PUBLIC);  /* Alias used by M3G parser */
        m3g_add_instance_field(stub, "intensity",           "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "color",               "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "spotAngle",           "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "spotExponent",        "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "constantAttenuation", "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "linearAttenuation",   "F",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "quadraticAttenuation","F",  ACC_PUBLIC);
        /* Task 16-a: explicit direction (Light.setDirection) — slots used by
         * the scene light collector; defaults 0 = local -Z axis. */
        m3g_add_instance_field(stub, "dirX", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "dirY", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "dirZ", "F", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 12. Material (parent: Object3D) === */
    stub = cls_material;
    if (stub) {
        m3g_add_instance_field(stub, "ambient",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "diffuse",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "emissive",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "specular",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "shininess", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "vertexColorTracking", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 13. Appearance (parent: Object3D) === */
    stub = cls_appearance;
    if (stub) {
        m3g_add_instance_field(stub, "material",        "Ljavax/microedition/m3g/Material;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texture",         "Ljavax/microedition/m3g/Texture2D;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "compositingMode", "Ljavax/microedition/m3g/CompositingMode;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "polygonMode",     "Ljavax/microedition/m3g/PolygonMode;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "fog",             "Ljavax/microedition/m3g/Fog;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "layer",           "I", ACC_PUBLIC);
        /* Task 16-a item 12: second texture unit (multitexturing) */
        m3g_add_instance_field(stub, "texture1",        "Ljavax/microedition/m3g/Texture2D;", ACC_PUBLIC);
        /* Temporary: M3G binary parser writes refs as ints, linker resolves to objects above */
        m3g_add_instance_field(stub, "materialRef",         "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "textureRef",          "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "textureRef1",         "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "compositingModeRef",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "fogRef",              "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "polygonModeRef",      "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 14. CompositingMode (parent: Object3D) === */
    stub = cls_compositing;
    if (stub) {
        m3g_add_instance_field(stub, "blending",        "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "alphaThreshold",  "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "depthTest",       "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "depthWrite",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "colorWrite",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "dithering",       "I", ACC_PUBLIC);
        /* Task 16-a item 13: alphaWriteEnable (JSR-184 default true; the
         * <init> native sets the spec defaults explicitly). */
        m3g_add_instance_field(stub, "alphaWrite",      "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 15. PolygonMode (parent: Object3D) === */
    stub = get_or_create_stub_class(jvm, "javax/microedition/m3g/PolygonMode");  /* not pre-created */
    if (stub) {
        m3g_add_instance_field(stub, "culling",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "shading",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "winding",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "twoSidedLighting", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "localCameraLighting", "I", ACC_PUBLIC);
        /* v19: missing field produced "[M3G-WARN] Field 'perspectiveCorrection'
         * not found" on every Nescube boot (setPerspectiveCorrection native
         * stores the flag via m3g_set_int_field). Hint-only for the software
         * rasterizer, but the slot must exist. */
        m3g_add_instance_field(stub, "perspectiveCorrection", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 16. Fog (parent: Object3D) === */
    stub = cls_fog;
    if (stub) {
        m3g_add_instance_field(stub, "density",    "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "nearDistance","F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "farDistance", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "mode",       "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "color",      "I", ACC_PUBLIC);  /* int ARGB, not float array */
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 17. Texture2D (parent: Object3D) === */
    stub = cls_texture2d;
    if (stub) {
        m3g_add_instance_field(stub, "image",     "Ljavax/microedition/m3g/Image2D;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "blendS",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "blendT",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "imageModeX","I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "imageModeY","I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "filtering", "I", ACC_PUBLIC);
        /* Temporary: M3G binary parser writes image ref as int, linker resolves to Image2D object */
        m3g_add_instance_field(stub, "imageRef",  "I", ACC_PUBLIC);
        /* v14 FIX: fields written by the constructor and the newly registered
         * setBlending/setBlendColor/setTransform natives. They used to be
         * missing entirely — every write landed in m3g_warn_missing_field and
         * the render pipeline saw default values (textured meshes drew
         * untextured/black). */
        m3g_add_instance_field(stub, "pixels",    "[I", ACC_PUBLIC); /* int[] copy of image pixels */
        m3g_add_instance_field(stub, "width",     "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "height",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "blending",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "blendColor","I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "transform", "[F", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 18. Image2D (parent: Object3D) === */
    stub = cls_image2d;
    if (stub) {
        m3g_add_instance_field(stub, "width",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "height",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "format",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "pixels",  "Ljava/lang/Object;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "imageRef","I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "mutable", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 19. Background (parent: Object3D) === */
    stub = cls_background;
    if (stub) {
        m3g_add_instance_field(stub, "clearColor",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "colorClearEnable", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "depthClearEnable", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "image",           "Ljavax/microedition/m3g/Image2D;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "imageModeX",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "imageModeY",      "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 20. VertexArray (parent: Object3D) === */
    stub = cls_vertex_array;
    if (stub) {
        m3g_add_instance_field(stub, "data",           "[B", ACC_PUBLIC);
        m3g_add_instance_field(stub, "componentCount",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "componentSize",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "vertexCount",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "numComponents",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "encoding",         "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 21. VertexBuffer (parent: Object3D) === */
    stub = cls_vertex_buffer;
    if (stub) {
        m3g_add_instance_field(stub, "positions",       "Ljavax/microedition/m3g/VertexArray;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "normals",         "Ljavax/microedition/m3g/VertexArray;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoords",       "Ljavax/microedition/m3g/VertexArray;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "colors",          "Ljavax/microedition/m3g/VertexArray;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "defaultColor",    "I", ACC_PUBLIC);
        /* v14: vertexCount was missing — setPositions/setColors wrote it into
         * a missing field and diagnostics read 0 */
        m3g_add_instance_field(stub, "vertexCount",     "I", ACC_PUBLIC);
        /* Permanent fields: scale and bias used by renderMesh every frame */
        m3g_add_instance_field(stub, "positionScale",   "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "biasX",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "biasY",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "biasZ",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoordScale",   "F", ACC_PUBLIC);
        /* v14: texture coordinate bias (setTexCoords 4th arg was dropped) */
        m3g_add_instance_field(stub, "texCoordBiasX",   "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoordBiasY",   "F", ACC_PUBLIC);
        /* Task 16-a item 12: second texture-coordinate unit (multitexturing) */
        m3g_add_instance_field(stub, "texCoords1",       "Ljavax/microedition/m3g/VertexArray;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoordScale1",   "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoordBiasX1",   "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoordBiasY1",   "F", ACC_PUBLIC);
        /* Temporary: M3G binary parser writes refs as ints, linker resolves to objects above */
        m3g_add_instance_field(stub, "positionsRef",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "normalsRef",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "colorsRef",       "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "texCoordsRef",    "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 22. IndexBuffer (parent: Object3D) === */
    stub = cls_index_buffer;
    if (stub) {
        m3g_add_instance_field(stub, "indices", "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "indexCount", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 23. TriangleStripArray (parent: IndexBuffer) === */
    stub = cls_tri_strip_arr;
    if (stub) {
        m3g_add_instance_field(stub, "stripLengths", "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "indexCount",    "I",  ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 24. AnimationTrack (parent: Object3D) === */
    stub = cls_anim_track;
    if (stub) {
        m3g_add_instance_field(stub, "propertyId",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "sequence",    "Ljavax/microedition/m3g/KeyframeSequence;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "controller",  "Ljavax/microedition/m3g/AnimationController;", ACC_PUBLIC);
        /* v14: raw refs from the M3G file parser (late resolution) */
        m3g_add_instance_field(stub, "sequenceRef",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "controllerRef", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 25. AnimationController (parent: Object3D) === */
    stub = cls_anim_ctrl;
    if (stub) {
        m3g_add_instance_field(stub, "activationTime", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "deactivationTime","I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "speed",           "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "weight",          "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "refSequenceTime", "F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "refWorldTime",    "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 26. KeyframeSequence (parent: Object3D) === */
    stub = cls_keyframe_seq;
    if (stub) {
        m3g_add_instance_field(stub, "componentCount",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "interpolation",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "duration",        "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "repeatMode",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "keyframeTimes",   "[I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "keyframeValues",  "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "numKeyframes",    "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "validRangeFirst", "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "validRangeLast",  "I", ACC_PUBLIC);
        /* v14 FIX: field-name aliases. The API-side animation code
         * (setKeyframe / setValidRange / the sampler) consistently uses
         * "numComponents"/"firstValid"/"lastValid", while the stub only had
         * "componentCount"/"validRangeFirst"/"validRangeLast" — every lookup
         * silently returned 0, so keyframes were never stored and animation
         * sampling always failed (M3GTest scenes 5 & 7 static). Adding the
         * aliases keeps both name families working. */
        m3g_add_instance_field(stub, "numComponents",   "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "firstValid",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "lastValid",       "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 27. Transform (parent: java/lang/Object) === */
    stub = cls_transform;
    if (stub) {
        m3g_add_instance_field(stub, "matrix", "[F", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 28. Graphics3D (parent: java/lang/Object) === */
    stub = cls_graphics3d;
    if (stub) {
        m3g_add_instance_field(stub, "fog",        "Ljavax/microedition/m3g/Fog;", ACC_PUBLIC);
        m3g_add_instance_field(stub, "viewX",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "viewY",      "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "viewWidth",  "I", ACC_PUBLIC);
        m3g_add_instance_field(stub, "viewHeight", "I", ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* === 29. Loader (parent: java/lang/Object) === */
    stub = cls_loader;
    if (stub) {
        count++;
    }

    /* === 30. RayIntersection (parent: java/lang/Object) === */
    stub = cls_ray_intersect;
    if (stub) {
        m3g_add_instance_field(stub, "textureS",     "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "textureT",     "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "normal",       "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "submeshIndex", "I",  ACC_PUBLIC);
        m3g_add_instance_field(stub, "ray",          "[F", ACC_PUBLIC);
        m3g_add_instance_field(stub, "intersected",  "Ljavax/microedition/m3g/Node;", ACC_PUBLIC);
        /* Task 16-a item 9: getDistance() read a non-existent field and
         * always returned 0.0 — the slot must exist for pick results. */
        m3g_add_instance_field(stub, "distance",     "F",  ACC_PUBLIC);
        m3g_recalc_instance_size(jvm, stub);
        count++;
    }

    /* Log summary with instance_size for key classes */
    fprintf(stderr, "[M3G] Initialized %d stub classes with instance fields\n", count);
    if (cls_world) fprintf(stderr, "[M3G]   World:  instance_size=%zu, fields=%d, super=%s\n",
        cls_world->instance_size, cls_world->fields_count,
        cls_world->super_class ? cls_world->super_class->class_name : "none");
    if (cls_group) fprintf(stderr, "[M3G]   Group:  instance_size=%zu, fields=%d, super=%s\n",
        cls_group->instance_size, cls_group->fields_count,
        cls_group->super_class ? cls_group->super_class->class_name : "none");
    if (cls_node) fprintf(stderr, "[M3G]   Node:   instance_size=%zu, fields=%d, super=%s\n",
        cls_node->instance_size, cls_node->fields_count,
        cls_node->super_class ? cls_node->super_class->class_name : "none");
    if (cls_object3d) fprintf(stderr, "[M3G]   Object3D: instance_size=%zu, fields=%d, super=%s\n",
        cls_object3d->instance_size, cls_object3d->fields_count,
        cls_object3d->super_class ? cls_object3d->super_class->class_name : "none");

    return count;
}

/* ============================================================================
 * Missing JSR-184 Methods - Added for completeness
 * ============================================================================ */

/* Appearance.getFog() */
static JavaValue native_appearance_getFog(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    if (!app) return NATIVE_RETURN_NULL();
    return NATIVE_RETURN_OBJECT(m3g_get_ref_field(app, "fog"));
}

/* Appearance.setFog(Fog) */
static JavaValue native_appearance_setFog(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    JavaObject* fog = (JavaObject*)args[1].ref;
    if (!app) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(app, "fog", fog);
    return NATIVE_RETURN_VOID();
}

/* Appearance.getCompositingMode() */
static JavaValue native_appearance_getCompositingMode(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    if (!app) return NATIVE_RETURN_NULL();
    return NATIVE_RETURN_OBJECT(m3g_get_ref_field(app, "compositingMode"));
}

/* Appearance.setCompositingMode(CompositingMode) */
static JavaValue native_appearance_setCompositingMode(JVM* jvm, JavaThread* thread,
                                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    JavaObject* cm = (JavaObject*)args[1].ref;
    if (!app) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(app, "compositingMode", cm);
    return NATIVE_RETURN_VOID();
}

/* Appearance.getPolygonMode() */
static JavaValue native_appearance_getPolygonMode(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    if (!app) return NATIVE_RETURN_NULL();
    return NATIVE_RETURN_OBJECT(m3g_get_ref_field(app, "polygonMode"));
}

/* Appearance.setPolygonMode(PolygonMode) */
static JavaValue native_appearance_setPolygonMode(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    JavaObject* pm = (JavaObject*)args[1].ref;
    if (!app) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(app, "polygonMode", pm);
    return NATIVE_RETURN_VOID();
}

/* Appearance.getLayer() */
static JavaValue native_appearance_getLayer(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    if (!app) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(app, "layer", 0));
}

/* Appearance.setLayer(int) */
static JavaValue native_appearance_setLayer(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    if (!app) return NATIVE_RETURN_VOID();
    m3g_set_int_field(app, "layer", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setFog(Fog) */
static JavaValue native_graphics3d_setFog(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* fog = (JavaObject*)args[1].ref;
    if (!g3d) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(g3d, "fog", fog);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.getFog() */
static JavaValue native_graphics3d_getFog(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    if (!g3d) return NATIVE_RETURN_NULL();
    return NATIVE_RETURN_OBJECT(m3g_get_ref_field(g3d, "fog"));
}

/* Graphics3D.getViewport(int[]) */
static JavaValue native_graphics3d_getViewport(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaArray* viewport = (JavaArray*)args[1].ref;
    if (!g3d || !viewport) return NATIVE_RETURN_VOID();
    jint* data = (jint*)array_data(viewport);
    if (!data || viewport->length < 4) return NATIVE_RETURN_VOID();
    data[0] = m3g_get_int_field(g3d, "viewX", 0);
    data[1] = m3g_get_int_field(g3d, "viewY", 0);
    data[2] = m3g_get_int_field(g3d, "viewWidth", 0);
    data[3] = m3g_get_int_field(g3d, "viewHeight", 0);
    return NATIVE_RETURN_VOID();
}

/* Background.setImage(Image2D) */
static JavaValue native_background_setImage(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    if (!bg) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(bg, "image", image);
    return NATIVE_RETURN_VOID();
}

/* Background.getImage() */
static JavaValue native_background_getImage(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_NULL();
    return NATIVE_RETURN_OBJECT(m3g_get_ref_field(bg, "image"));
}

/* Background.setColorEnable(boolean) */
/* v15: Object3D.getParent() / Node.getParent() and Sprite3D.isRenderingEnabled()
 * (SU-30 scene traversal). getParent returns the node's parent ref if the
 * parser/stub keeps one; otherwise NULL (legal per spec: root nodes). */
static JavaValue native_node_getParent(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_NULL();
    int slot = m3g_find_field_slot(node, "parent");
    if (slot >= 0) {
        JavaObject* p = (JavaObject*)node->fields[slot].ref;
        if (p && !heap_java_object_valid(p)) p = NULL;
        return NATIVE_RETURN_OBJECT(p);
    }
    return NATIVE_RETURN_NULL();
}

static JavaValue native_sprite3d_isRenderingEnabled(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(node, "renderingEnable", 1));
}

/* v15: JSR-184 spec names for the Background clear flags (SU-30 calls these) */
static JavaValue native_background_setColorClearEnable(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_VOID();
    m3g_set_int_field(bg, "colorClearEnable", args[1].i);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_background_setDepthClearEnable(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_VOID();
    m3g_set_int_field(bg, "depthClearEnable", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* v15: Node/Group.setRenderingEnable(Z)V — mesh visibility toggle used by
 * SU-30; previously unresolved, so per-mesh enable flags never applied. */
static JavaValue native_node_setRenderingEnable(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_VOID();
    m3g_set_int_field(node, "renderingEnable", args[1].i ? 1 : 0);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_background_setColorEnable(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_VOID();
    m3g_set_int_field(bg, "colorClearEnable", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* Background.getColorEnable() */
static JavaValue native_background_getColorEnable(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(bg, "colorClearEnable", 1));
}

/* Background.getColor() */
static JavaValue native_background_getColor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (!bg) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(bg, "clearColor", 0));
}

/* Object3D.clone() - calls duplicate() */
static JavaValue native_object3d_clone(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    if (!obj) return NATIVE_RETURN_NULL();
    return native_object3d_duplicate(jvm, thread, args, 1);
}

/* Image2D.getWidth() */
static JavaValue native_image2d_getWidth(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* img = (JavaObject*)args[0].ref;
    if (!img) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(img, "width", 0));
}

/* Image2D.getHeight() */
static JavaValue native_image2d_getHeight(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* img = (JavaObject*)args[0].ref;
    if (!img) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(img, "height", 0));
}

/* Image2D.isMutable() */
static JavaValue native_image2d_isMutable(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* img = (JavaObject*)args[0].ref;
    if (!img) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(img, "mutable", 0));
}

/* Image2D.getFormat() */
static JavaValue native_image2d_getFormat(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* img = (JavaObject*)args[0].ref;
    if (!img) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(img, "format", 0));
}

/* PolygonMode.getCulling() */
static JavaValue native_polygonmode_getCulling(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(pm, "culling", 0));
}

/* PolygonMode.setShading(int) */
static JavaValue native_polygonmode_setShading(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_VOID();
    m3g_set_int_field(pm, "shading", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* PolygonMode.getShading() */
static JavaValue native_polygonmode_getShading(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(pm, "shading", 0));
}

/* PolygonMode.setWinding(int) */
static JavaValue native_polygonmode_setWinding(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_VOID();
    m3g_set_int_field(pm, "winding", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* PolygonMode.getWinding() */
static JavaValue native_polygonmode_getWinding(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(pm, "winding", 0));
}

/* v11: PerspectiveCorrectionEnable — hint only; the software rasterizer
 * always uses perspective-correct texture mapping, but store the flag so
 * the getters round-trip the game's value. */
static JavaValue native_polygonmode_setPerspectiveCorrection(JVM* jvm, JavaThread* thread,
                                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_VOID();
    m3g_set_int_field(pm, "perspectiveCorrection", args[1].i);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_polygonmode_getPerspectiveCorrection(JVM* jvm, JavaThread* thread,
                                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(pm, "perspectiveCorrection", 0));
}

/* v12: TwoSidedLightingEnable — found by [M3G-MISSING] on SU-30 */
static JavaValue native_polygonmode_setTwoSidedLighting(JVM* jvm, JavaThread* thread,
                                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_VOID();
    m3g_set_int_field(pm, "twoSidedLighting", args[1].i ? 1 : 0);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_polygonmode_getTwoSidedLighting(JVM* jvm, JavaThread* thread,
                                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* pm = (JavaObject*)args[0].ref;
    if (!pm) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(pm, "twoSidedLighting", 0));
}

/* CompositingMode.setDepthTestEnable(boolean) */
static JavaValue native_cm_setDepthTestEnable(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_VOID();
    m3g_set_int_field(cm, "depthTest", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* CompositingMode.getDepthTestEnable() */
static JavaValue native_cm_getDepthTestEnable(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_INT(1);
    return NATIVE_RETURN_INT(m3g_get_int_field(cm, "depthTest", 1));
}

/* CompositingMode.setDepthWriteEnable(boolean) */
static JavaValue native_cm_setDepthWriteEnable(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_VOID();
    m3g_set_int_field(cm, "depthWrite", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* CompositingMode.getDepthWriteEnable() */
static JavaValue native_cm_getDepthWriteEnable(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_INT(1);
    return NATIVE_RETURN_INT(m3g_get_int_field(cm, "depthWrite", 1));
}

/* CompositingMode.getBlending() */
static JavaValue native_cm_getBlending(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(cm, "blending", 64));
}

/* CompositingMode.setAlphaThreshold(float) */
static JavaValue native_cm_setAlphaThreshold(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_VOID();
    m3g_set_float_field(cm, "alphaThreshold", args[1].f);
    return NATIVE_RETURN_VOID();
}

/* CompositingMode.getAlphaThreshold() */
static JavaValue native_cm_getAlphaThreshold(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cm = (JavaObject*)args[0].ref;
    if (!cm) return NATIVE_RETURN_FLOAT(0.0f);
    return NATIVE_RETURN_FLOAT(m3g_get_float_field(cm, "alphaThreshold", 0.0f));
}

/* Fog.setColor(int) */
static JavaValue native_fog_setColor(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_VOID();
    m3g_set_int_field(fog, "color", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* Fog.getColor() */
static JavaValue native_fog_getColor(JVM* jvm, JavaThread* thread,
                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(fog, "color", 0));
}

/* Fog.setMode(int) */
static JavaValue native_fog_setMode(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_VOID();
    m3g_set_int_field(fog, "mode", args[1].i);
    return NATIVE_RETURN_VOID();
}

/* Fog.getMode() */
static JavaValue native_fog_getMode(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(fog, "mode", 0));
}

/* Fog.setDensity(float) */
static JavaValue native_fog_setDensity(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_VOID();
    m3g_set_float_field(fog, "density", args[1].f);
    return NATIVE_RETURN_VOID();
}

/* Fog.getDensity() */
static JavaValue native_fog_getDensity(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_FLOAT(1.0f);
    return NATIVE_RETURN_FLOAT(m3g_get_float_field(fog, "density", 1.0f));
}

/* Fog.setLinear(float, float) */
static JavaValue native_fog_setLinear(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_VOID();
    m3g_set_float_field(fog, "nearDistance", args[1].f);
    m3g_set_float_field(fog, "farDistance", args[2].f);
    return NATIVE_RETURN_VOID();
}

/* Fog.getLinearNear() */
static JavaValue native_fog_getLinearNear(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_FLOAT(0.0f);
    return NATIVE_RETURN_FLOAT(m3g_get_float_field(fog, "nearDistance", 0.0f));
}

/* Fog.getLinearFar() */
static JavaValue native_fog_getLinearFar(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* fog = (JavaObject*)args[0].ref;
    if (!fog) return NATIVE_RETURN_FLOAT(1.0f);
    return NATIVE_RETURN_FLOAT(m3g_get_float_field(fog, "farDistance", 1.0f));
}

/* ============================================================================
 * Native Method Registration
 * ============================================================================ */

JavaValue native_graphics3d_getProperties(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count);  /* defined in native.c */

/* =========================================================================
 * v24: JSR-184 completeness batch — the audit backlog (FIXES «СЕССИЯ 17в»).
 * All natives registered on Node are inherited by Mesh/Group/Sprite3D/etc.
 * through the native_find superclass walk.
 * ========================================================================= */

/* ---- Transformable ops on Node: compose on the current node transform
 * (explicit "transform" float[16] wins over TRS, matching the renderer's
 * m3g_build_node_transform) and store back flat (row-vector JSR-184
 * convention is flat-identical to our internal layout). ---- */
static void m3g_node_apply_composed(JVM* jvm, JavaObject* node, const M3GTransform* op) {
    M3GTransform cur;
    m3g_build_node_transform(node, &cur);
    M3GTransform res;
    m3g_transform_multiply(&res, &cur, op);
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (!arr || arr->element_type != T_FLOAT || arr->length < 16) {
        arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
        if (arr) m3g_set_ref_field(node, "transform", (JavaObject*)arr);
    }
    if (arr && arr->element_type == T_FLOAT && arr->length >= 16) {
        memcpy(array_data(arr), res.m, 16 * sizeof(float));
    }
}

static JavaValue native_node_postRotate(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_VOID();
    float angle = args[1].f * (float)M_PI / 180.0f;
    M3GTransform op;
    m3g_transform_rotate(&op, angle, args[2].f, args[3].f, args[4].f);
    m3g_node_apply_composed(jvm, node, &op);
    return NATIVE_RETURN_VOID();
}

/* preRotate: op is applied on the LEFT (world side) */
static JavaValue native_node_preRotate(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_VOID();
    float angle = args[1].f * (float)M_PI / 180.0f;
    M3GTransform op, cur;
    m3g_transform_rotate(&op, angle, args[2].f, args[3].f, args[4].f);
    m3g_build_node_transform(node, &cur);
    M3GTransform res;
    m3g_transform_multiply(&res, &op, &cur);
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (!arr || arr->element_type != T_FLOAT || arr->length < 16) {
        arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
        if (arr) m3g_set_ref_field(node, "transform", (JavaObject*)arr);
    }
    if (arr && arr->element_type == T_FLOAT && arr->length >= 16) {
        memcpy(array_data(arr), res.m, 16 * sizeof(float));
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_rotateQuat(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_VOID();
    float qx = args[1].f, qy = args[2].f, qz = args[3].f, qw = args[4].f;
    M3GTransform q;
    memset(&q, 0, sizeof(q));
    q.m[0*4+0] = 1.0f - 2.0f * (qy*qy + qz*qz);
    q.m[0*4+1] = 2.0f * (qx*qy + qz*qw);
    q.m[0*4+2] = 2.0f * (qx*qz - qy*qw);
    q.m[1*4+0] = 2.0f * (qx*qy - qz*qw);
    q.m[1*4+1] = 1.0f - 2.0f * (qx*qx + qz*qz);
    q.m[1*4+2] = 2.0f * (qy*qz + qx*qw);
    q.m[2*4+0] = 2.0f * (qx*qz + qy*qw);
    q.m[2*4+1] = 2.0f * (qy*qz - qx*qw);
    q.m[2*4+2] = 1.0f - 2.0f * (qx*qx + qy*qy);
    q.m[3*4+3] = 1.0f;
    m3g_node_apply_composed(jvm, node, &q);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_translate(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_VOID();
    M3GTransform op;
    m3g_transform_identity(&op);
    op.m[0*4+3] = args[1].f; op.m[1*4+3] = args[2].f; op.m[2*4+3] = args[3].f;
    m3g_node_apply_composed(jvm, node, &op);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_scale(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (!node) return NATIVE_RETURN_VOID();
    M3GTransform op;
    m3g_transform_identity(&op);
    op.m[0*4+0] = args[1].f; op.m[1*4+1] = args[2].f; op.m[2*4+2] = args[3].f;
    m3g_node_apply_composed(jvm, node, &op);
    return NATIVE_RETURN_VOID();
}

/* Transformable getters — read the component fields */
static JavaValue native_node_getOrientation(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaArray* arr = (JavaArray*)args[1].ref;
    if (node && arr && arr->element_type == T_FLOAT && arr->length >= 4) {
        float* v = (float*)array_data(arr);
        v[0] = m3g_get_float_field(node, "orientationAngle", 0.0f);
        v[1] = m3g_get_float_field(node, "orientationX", 0.0f);
        v[2] = m3g_get_float_field(node, "orientationY", 0.0f);
        v[3] = m3g_get_float_field(node, "orientationZ", 1.0f);
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_getScale(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaArray* arr = (JavaArray*)args[1].ref;
    if (node && arr && arr->element_type == T_FLOAT && arr->length >= 3) {
        float* v = (float*)array_data(arr);
        v[0] = m3g_get_float_field(node, "scaleX", 1.0f);
        v[1] = m3g_get_float_field(node, "scaleY", 1.0f);
        v[2] = m3g_get_float_field(node, "scaleZ", 1.0f);
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_getTranslation(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaArray* arr = (JavaArray*)args[1].ref;
    if (node && arr && arr->element_type == T_FLOAT && arr->length >= 3) {
        float* v = (float*)array_data(arr);
        v[0] = m3g_get_float_field(node, "translationX", 0.0f);
        v[1] = m3g_get_float_field(node, "translationY", 0.0f);
        v[2] = m3g_get_float_field(node, "translationZ", 0.0f);
    }
    return NATIVE_RETURN_VOID();
}

/* Node.getTransformTo(Transform target) — true if this node's transform
 * relative to `target` was written. Walks both ancestor chains to the
 * common ancestor; result = (node->LCA) x (target->LCA)^-1. */
static JavaValue native_node_getTransformTo(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* target = (JavaObject*)args[1].ref;
    if (!node || !target) return NATIVE_RETURN_INT(0);

    M3GTransform up_node, up_target, tmp;
    m3g_transform_identity(&up_node);
    m3g_transform_identity(&up_target);

    /* node -> root */
    JavaObject* a = node;
    while (a) {
        M3GTransform t;
        m3g_build_node_transform(a, &t);
        m3g_transform_multiply(&up_node, &up_node, &t);
        a = (JavaObject*)m3g_get_ref_field(a, "parent");
        if (a == node) break;  /* cycle guard */
    }
    /* target -> root */
    JavaObject* b = target;
    while (b) {
        M3GTransform t;
        m3g_build_node_transform(b, &t);
        m3g_transform_multiply(&up_target, &up_target, &t);
        b = (JavaObject*)m3g_get_ref_field(b, "parent");
        if (b == target) break;
    }

    /* LCA check: target must be an ancestor of node (or node itself) */
    a = node;
    int related = (a == target);
    while (a && !related) {
        a = (JavaObject*)m3g_get_ref_field(a, "parent");
        if (a == target) related = 1;
        if (a == node) break;
    }
    if (!related) return NATIVE_RETURN_INT(0);

    /* result = up_node x inverse(up_target) */
    M3GTransform inv;
    memcpy(&inv, &up_target, sizeof(inv));
    /* Gauss-Jordan invert 4x4 */
    float invm[16];
    {
        float m[16], id[16];
        memcpy(m, up_target.m, sizeof(m));
        for (int i = 0; i < 16; i++) id[i] = (i % 4 == i / 4) ? 1.0f : 0.0f;
        for (int col = 0; col < 4; col++) {
            int piv = col;
            for (int r = col + 1; r < 4; r++)
                if (fabsf(m[r*4+col]) > fabsf(m[piv*4+col])) piv = r;
            if (fabsf(m[piv*4+col]) < 1e-12f) return NATIVE_RETURN_INT(0);
            if (piv != col)
                for (int k = 0; k < 4; k++) {
                    float tm = m[col*4+k]; m[col*4+k] = m[piv*4+k]; m[piv*4+k] = tm;
                    float ti = id[col*4+k]; id[col*4+k] = id[piv*4+k]; id[piv*4+k] = ti;
                }
            float d = m[col*4+col];
            for (int k = 0; k < 4; k++) { m[col*4+k] /= d; id[col*4+k] /= d; }
            for (int r = 0; r < 4; r++) {
                if (r == col) continue;
                float f = m[r*4+col];
                if (f != 0.0f)
                    for (int k = 0; k < 4; k++) { m[r*4+k] -= f*m[col*4+k]; id[r*4+k] -= f*id[col*4+k]; }
            }
        }
        memcpy(invm, id, sizeof(invm));
    }
    (void)tmp;
    M3GTransform invt, res;
    memcpy(&invt.m, invm, sizeof(invt.m));
    m3g_transform_multiply(&res, &up_node, &invt);

    JavaObject* to = target;
    (void)to;
    /* Write into the Transform object */
    {
        /* getTransformTo's argument is a Transform object; store result */
        JavaArray* arr = (JavaArray*)m3g_get_ref_field(target, "matrix");
        if (!arr && target) {
            /* Transform stores its matrix natively; use the helper */
            set_native_transform(target, &res);
            return NATIVE_RETURN_INT(1);
        }
    }
    return NATIVE_RETURN_INT(0);
}

/* Node misc getters/setters */
static JavaValue native_node_getAlphaFactor(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    float f = node ? m3g_get_float_field(node, "alphaFactor", 0.0f) : 0.0f;
    if (f <= 0.0f || f > 1.0f) f = 1.0f;  /* unset (0) -> spec default */
    return NATIVE_RETURN_FLOAT(f);
}

static JavaValue native_node_getScope(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(node ? m3g_get_int_field(node, "scope", 0) : 0);
}

static JavaValue native_node_setScope(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (node) m3g_set_int_field(node, "scope", args[1].i);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_setPickingEnable(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    if (node) m3g_set_int_field(node, "pickingEnable", args[1].i ? 1 : 0);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_node_isPickingEnabled(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(node ? (m3g_get_int_field(node, "pickingEnable", 1) ? 1 : 0) : 0);
}

static JavaValue native_node_isRenderingEnabled(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(node ? (m3g_get_int_field(node, "renderingEnable", 1) ? 1 : 0) : 0);
}

/* ---- Texture2D Transformable completion ---- */
static JavaValue native_texture2d_getTransform(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* tex = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    if (!tex || !transform) return NATIVE_RETURN_VOID();
    M3GTransform t;
    m3g_transform_identity(&t);
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(tex, "transform");
    if (arr && arr->element_type == T_FLOAT && arr->length >= 16) {
        memcpy(t.m, array_data(arr), 16 * sizeof(float));
    }
    set_native_transform(transform, &t);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_texture2d_setImage(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* tex = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    if (!tex) return NATIVE_RETURN_VOID();
    m3g_set_ref_field(tex, "image", image);
    /* Invalidate the built texture so the next render re-uploads pixels */
    M3GTexture2D* built = m3g_lookup_texture_cache(tex);
    if (built) {
        built->source_image = image;
        built->generation = 0;  /* force refresh on next use */
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_texture2d_getImage(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* tex = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_OBJECT(tex ? m3g_get_ref_field(tex, "image") : NULL);
}

/* ---- Light getters + spot/attenuation setters (fields already consumed
 * by the light collector with the same names) ---- */
static JavaValue native_light_getColor(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(l ? m3g_get_int_field(l, "color", 0x00FFFFFF) : 0);
}
static JavaValue native_light_getIntensity(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_FLOAT(l ? m3g_get_float_field(l, "intensity", 1.0f) : 1.0f);
}
static JavaValue native_light_getMode(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(l ? m3g_get_int_field(l, "mode", 0) : 0);
}
static JavaValue native_light_getSpotAngle(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_FLOAT(l ? m3g_get_float_field(l, "spotAngle", 180.0f) : 180.0f);
}
static JavaValue native_light_getSpotExponent(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_FLOAT(l ? m3g_get_float_field(l, "spotExponent", 0.0f) : 0.0f);
}
static JavaValue native_light_setSpotAngle(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    if (l) m3g_set_float_field(l, "spotAngle", args[1].f);
    return NATIVE_RETURN_VOID();
}
static JavaValue native_light_setSpotExponent(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    if (l) m3g_set_float_field(l, "spotExponent", args[1].f);
    return NATIVE_RETURN_VOID();
}
static JavaValue native_light_setAttenuation(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    if (l) {
        m3g_set_float_field(l, "constantAttenuation", args[1].f);
        m3g_set_float_field(l, "linearAttenuation", args[2].f);
        m3g_set_float_field(l, "quadraticAttenuation", args[3].f);
    }
    return NATIVE_RETURN_VOID();
}
static JavaValue native_light_getAttenuation(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* l = (JavaObject*)args[0].ref;
    JavaArray* arr = (JavaArray*)args[1].ref;
    if (l && arr && arr->element_type == T_FLOAT && arr->length >= 3) {
        float* v = (float*)array_data(arr);
        v[0] = m3g_get_float_field(l, "constantAttenuation", 1.0f);
        v[1] = m3g_get_float_field(l, "linearAttenuation", 0.0f);
        v[2] = m3g_get_float_field(l, "quadraticAttenuation", 0.0f);
    }
    return NATIVE_RETURN_VOID();
}

/* ---- Material getColor(I)/getShininess ---- */
static JavaValue native_material_getColor(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    jint target = args[1].i;
    if (!m) return NATIVE_RETURN_INT(0);
    const char* f = (target == 1) ? "ambient" : (target == 2) ? "diffuse"
                 : (target == 3) ? "emissive" : (target == 4) ? "specular" : NULL;
    if (!f) return NATIVE_RETURN_INT(0);
    return NATIVE_RETURN_INT(m3g_get_int_field(m, f, 0));
}
static JavaValue native_material_getShininess(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_FLOAT(m ? m3g_get_float_field(m, "shininess", 0.0f) : 0.0f);
}

/* ---- Graphics3D depth range / camera / lights ---- */
static JavaValue native_g3d_setDepthRange(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    g_m3g.depth_range_near = args[1].f;
    g_m3g.depth_range_far = args[2].f;
    return NATIVE_RETURN_VOID();
}
static JavaValue native_g3d_getDepthRange(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaArray* arr = (JavaArray*)args[1].ref;
    if (arr && arr->element_type == T_FLOAT && arr->length >= 2) {
        float* v = (float*)array_data(arr);
        v[0] = g_m3g.depth_range_near;
        v[1] = g_m3g.depth_range_far;
    }
    return NATIVE_RETURN_VOID();
}
static JavaValue native_g3d_getCamera(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    if (transform) {
        M3GTransform t;
        memcpy(&t, &g_m3g.modelview, sizeof(t));
        set_native_transform(transform, &t);
    }
    return NATIVE_RETURN_OBJECT(g3d ? m3g_get_ref_field(g3d, "camera") : NULL);
}
static JavaValue native_g3d_getLightCount(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(g_m3g.light_count);
}
static JavaValue native_g3d_getLight(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    jint index = args[1].i;
    JavaObject* transform = (JavaObject*)args[2].ref;
    if (index < 0 || index >= g_m3g.light_count) return NATIVE_RETURN_NULL();
    JavaObject* l = g_m3g.lights[index].obj;
    if (transform && l) {
        M3GTransform t;
        memcpy(&t, &g_m3g.lights[index].transform, sizeof(t));
        set_native_transform(transform, &t);
    }
    return NATIVE_RETURN_OBJECT(l);
}
static JavaValue native_g3d_isDepthBufferEnabled(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    return NATIVE_RETURN_INT(1);
}

/* ---- Background crop + image modes ---- */
static JavaValue native_bg_setImageMode(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (bg) {
        m3g_set_int_field(bg, "imageModeX", args[1].i);
        m3g_set_int_field(bg, "imageModeY", args[2].i);
    }
    return NATIVE_RETURN_VOID();
}
static JavaValue native_bg_getImageModeX(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(bg ? m3g_get_int_field(bg, "imageModeX", 32) : 32);
}
static JavaValue native_bg_getImageModeY(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(bg ? m3g_get_int_field(bg, "imageModeY", 32) : 32);
}
static JavaValue native_bg_setCrop(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    if (bg) {
        m3g_set_int_field(bg, "cropX", args[1].i);
        m3g_set_int_field(bg, "cropY", args[2].i);
        m3g_set_int_field(bg, "cropWidth", args[3].i);
        m3g_set_int_field(bg, "cropHeight", args[4].i);
    }
    return NATIVE_RETURN_VOID();
}
static JavaValue native_bg_getCropX(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(bg ? m3g_get_int_field(bg, "cropX", 0) : 0);
}
static JavaValue native_bg_getCropY(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(bg ? m3g_get_int_field(bg, "cropY", 0) : 0);
}
static JavaValue native_bg_getCropWidth(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(bg ? m3g_get_int_field(bg, "cropWidth", -1) : -1);
}
static JavaValue native_bg_getCropHeight(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* bg = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(bg ? m3g_get_int_field(bg, "cropHeight", -1) : -1);
}

/* ---- Appearance.getTexture(I) ---- */
static JavaValue native_appearance_getTexture(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* app = (JavaObject*)args[0].ref;
    jint unit = args[1].i;
    if (!app) return NATIVE_RETURN_NULL();
    if (unit == 0) return NATIVE_RETURN_OBJECT(m3g_get_ref_field(app, "texture"));
    if (unit == 1) return NATIVE_RETURN_OBJECT(m3g_get_ref_field(app, "texture1"));
    return NATIVE_RETURN_NULL();
}

/* ---- VertexArray.get(I,I,[B) and get(I,I,[I) ---- */
static JavaValue native_vertexarray_get_bytes(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* va = (JavaObject*)args[0].ref;
    jint first = args[1].i, count = args[2].i;
    JavaArray* dst = (JavaArray*)args[3].ref;
    if (!va || !dst) return NATIVE_RETURN_VOID();
    JavaArray* data = (JavaArray*)m3g_get_ref_field(va, "data");
    int comps = m3g_get_int_field(va, "componentCount", 0);
    if (!data || comps <= 0) return NATIVE_RETURN_VOID();
    int src_type = data->element_type;
    uint8_t* out = (uint8_t*)array_data(dst);
    jsize cap = dst->length;
    for (int i = 0; i < count; i++) {
        for (int c = 0; c < comps; c++) {
            int idx = (first + i) * comps + c;
            int oi = i * comps + c;
            if (oi >= cap) return NATIVE_RETURN_VOID();
            if (src_type == T_BYTE) {
                int8_t* s = (int8_t*)array_data(data);
                out[oi] = (uint8_t)s[idx];
            } else {
                int16_t* s = (int16_t*)array_data(data);
                out[oi] = (uint8_t)(s[idx] & 0xFF);
            }
        }
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_vertexarray_get_ints(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* va = (JavaObject*)args[0].ref;
    jint first = args[1].i, count = args[2].i;
    JavaArray* dst = (JavaArray*)args[3].ref;
    if (!va || !dst) return NATIVE_RETURN_VOID();
    JavaArray* data = (JavaArray*)m3g_get_ref_field(va, "data");
    int comps = m3g_get_int_field(va, "componentCount", 0);
    if (!data || comps <= 0) return NATIVE_RETURN_VOID();
    jint* out = (jint*)array_data(dst);
    jsize cap = dst->length;
    for (int i = 0; i < count; i++) {
        for (int c = 0; c < comps; c++) {
            int idx = (first + i) * comps + c;
            int oi = i * comps + c;
            if (oi >= cap) return NATIVE_RETURN_VOID();
            if (data->element_type == T_BYTE) {
                int8_t* s = (int8_t*)array_data(data);
                out[oi] = s[idx];
            } else {
                int16_t* s = (int16_t*)array_data(data);
                out[oi] = s[idx];
            }
        }
    }
    return NATIVE_RETURN_VOID();
}

/* ---- VertexBuffer getters + setDefaultColor/getDefaultColor ---- */
static JavaValue native_vb_setDefaultColor(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    if (vb) m3g_set_int_field(vb, "defaultColor", args[1].i);
    return NATIVE_RETURN_VOID();
}
static JavaValue native_vb_getDefaultColor(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_INT(vb ? m3g_get_int_field(vb, "defaultColor", 0) : 0);
}
static JavaValue native_vb_getColors(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_OBJECT(vb ? m3g_get_ref_field(vb, "colors") : NULL);
}
static JavaValue native_vb_getNormals(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_OBJECT(vb ? m3g_get_ref_field(vb, "normals") : NULL);
}
static JavaValue native_vb_getPositions(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    JavaArray* scale = (JavaArray*)args[1].ref;
    if (vb && scale && scale->element_type == T_FLOAT && scale->length >= 1) {
        ((float*)array_data(scale))[0] = m3g_get_float_field(vb, "positionScale", 1.0f);
    }
    return NATIVE_RETURN_OBJECT(vb ? m3g_get_ref_field(vb, "positions") : NULL);
}
static JavaValue native_vb_getTexCoords(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaArray* scale = (JavaArray*)args[2].ref;
    if (!vb) return NATIVE_RETURN_NULL();
    if (index == 0) {
        if (scale && scale->element_type == T_FLOAT && scale->length >= 1) {
            ((float*)array_data(scale))[0] = m3g_get_float_field(vb, "texCoordScale", 1.0f);
        }
        return NATIVE_RETURN_OBJECT(m3g_get_ref_field(vb, "texCoords"));
    }
    return NATIVE_RETURN_NULL();
}
static JavaValue native_vb_getVertexCount(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* vb = (JavaObject*)args[0].ref;
    if (!vb) return NATIVE_RETURN_INT(0);
    JavaObject* pos = m3g_get_ref_field(vb, "positions");
    if (pos) return NATIVE_RETURN_INT(m3g_get_int_field(pos, "vertexCount", 0));
    return NATIVE_RETURN_INT(0);
}
static JavaValue native_vb_setTexCoords3(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    /* 3-arg variant delegates to the 4-arg with a null bias map:
     * args = (this, index, va, scale) -> 4-arg(this, index, va, scale, null) */
    (void)jvm; (void)thread; (void)arg_count;
    JavaValue xargs[5];
    xargs[0] = args[0]; xargs[1] = args[1]; xargs[2] = args[2]; xargs[3] = args[3];
    xargs[4].ref = NULL;
    return native_vertexbuffer_setTexCoords(jvm, thread, xargs, 5);
}

/* ---- Mesh/MorphingMesh getters ---- */
static JavaValue native_mesh_getVertexBuffer(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_OBJECT(m ? m3g_get_ref_field(m, "vertexBuffer") : NULL);
}
static JavaValue native_mesh_getIndexBuffer(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    jint sub = args[1].i;
    if (!m) return NATIVE_RETURN_NULL();
    if (sub == 0) return NATIVE_RETURN_OBJECT(m3g_get_ref_field(m, "indexBuffer"));
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(m, "indexBuffers");
    if (arr && sub < arr->length)
        return NATIVE_RETURN_OBJECT(((JavaObject**)array_data(arr))[sub]);
    return NATIVE_RETURN_NULL();
}
static JavaValue native_mesh_getAppearance(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    jint sub = args[1].i;
    if (!m) return NATIVE_RETURN_NULL();
    if (sub == 0) return NATIVE_RETURN_OBJECT(m3g_get_ref_field(m, "appearance"));
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(m, "appearances");
    if (arr && sub < arr->length)
        return NATIVE_RETURN_OBJECT(((JavaObject**)array_data(arr))[sub]);
    return NATIVE_RETURN_NULL();
}
static JavaValue native_mesh_getSubmeshCount(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    if (!m) return NATIVE_RETURN_INT(0);
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(m, "appearances");
    return NATIVE_RETURN_INT(arr ? arr->length : 1);
}
static JavaValue native_morph_getMorphTarget(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    jint i = args[1].i;
    if (!m) return NATIVE_RETURN_NULL();
    JavaArray* arr = (JavaArray*)m3g_get_ref_field(m, "morphTargets");
    if (arr && i >= 0 && i < arr->length)
        return NATIVE_RETURN_OBJECT(((JavaObject**)array_data(arr))[i]);
    return NATIVE_RETURN_NULL();
}
static JavaValue native_morph_getMorphTargetCount(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    JavaArray* arr = m ? (JavaArray*)m3g_get_ref_field(m, "morphTargets") : NULL;
    return NATIVE_RETURN_INT(arr ? arr->length : 0);
}
static JavaValue native_morph_getWeights(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* m = (JavaObject*)args[0].ref;
    JavaArray* dst = (JavaArray*)args[1].ref;
    if (m && dst) {
        JavaArray* w = (JavaArray*)m3g_get_ref_field(m, "morphWeights");
        if (w && w->element_type == T_FLOAT) {
            jfloat* s = (jfloat*)array_data(w);
            jfloat* d = (jfloat*)array_data(dst);
            int n = w->length < dst->length ? w->length : dst->length;
            for (int i = 0; i < n; i++) d[i] = s[i];
            return NATIVE_RETURN_INT(n);
        }
    }
    return NATIVE_RETURN_INT(0);
}

/* ---- Sprite3D appearance ---- */
static JavaValue native_sprite3d_getAppearance(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* s = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_OBJECT(s ? m3g_get_ref_field(s, "appearance") : NULL);
}
static JavaValue native_sprite3d_setAppearance(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* s = (JavaObject*)args[0].ref;
    if (s) m3g_set_ref_field(s, "appearance", (JavaObject*)args[1].ref);
    return NATIVE_RETURN_VOID();
}

/* ---- AnimationTrack weight/controller getters ---- */
static JavaValue native_animtrack_getController(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* t = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_OBJECT(t ? m3g_get_ref_field(t, "controller") : NULL);
}
static JavaValue native_animtrack_getWeight(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* t = (JavaObject*)args[0].ref;
    return NATIVE_RETURN_FLOAT(t ? m3g_get_float_field(t, "weight", 1.0f) : 1.0f);
}
static JavaValue native_animtrack_setWeight(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* t = (JavaObject*)args[0].ref;
    if (t) m3g_set_float_field(t, "weight", args[1].f);
    return NATIVE_RETURN_VOID();
}

/* ---- Camera.getProjection(Transform) ---- */
static JavaValue native_camera_getProjectionT(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* cam = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    if (!cam) return NATIVE_RETURN_INT(0);
    int type = m3g_get_int_field(cam, "projectionType", 2);
    /* v24 FIX: normalize M3G FILE-format constants to the JSR-184 API ones.
     * The file parser stores Generic=48 / Parallel=49 / Perspective=50; the
     * API returns GENERIC=0 / PARALLEL=1 / PERSPECTIVE=2. */
    if (type == 48) type = 0;
    else if (type == 49) type = 1;
    else if (type == 50) type = 2;
    if (transform) {
        M3GTransform t;
        /* v25: prefer the EXACT cached matrix (kept in sync by
         * setPerspective/setParallel/setGeneric) over field-based rebuilds —
         * the rebuilds cannot know e.g. the guarded aspect=0->0.75 or the
         * real ortho extents, and historically drifted (fov-as-height bug). */
        JavaArray* cache = (JavaArray*)m3g_get_ref_field(cam, "genericMatrix");
        if (cache && cache->element_type == T_FLOAT && cache->length >= 16) {
            m3g_transform_identity(&t);
            memcpy(t.m, array_data(cache), 16 * sizeof(float));
        } else if (type == 0) {
            m3g_transform_identity(&t);
        } else if (type == 2) {
            m3g_transform_perspective(&t,
                m3g_get_float_field(cam, "fov", 60.0f),
                m3g_get_float_field(cam, "aspect", 1.0f),
                m3g_get_float_field(cam, "near", 0.1f),
                m3g_get_float_field(cam, "far", 1000.0f));
        } else {
            float h = m3g_get_float_field(cam, "height", 2.0f);
            float asp = m3g_get_float_field(cam, "aspect", 1.0f);
            m3g_transform_ortho(&t, -h*asp/2.0f, h*asp/2.0f, -h/2.0f, h/2.0f,
                m3g_get_float_field(cam, "near", 0.1f),
                m3g_get_float_field(cam, "far", 1000.0f));
        }
        set_native_transform(transform, &t);
    }
    return NATIVE_RETURN_INT(type);
}

/* ---- Node.pick + RayIntersection filling (basic ray-triangle/quad) ---- */
static JavaValue native_node_pick(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    /* args: (this, scope, ox,oy,oz, dx,dy,dz, rayIntersection) */
    JavaObject* node = (JavaObject*)args[0].ref;
    jint scope = args[1].i;
    float ro[3] = { args[2].f, args[3].f, args[4].f };
    float rd[3] = { args[5].f, args[6].f, args[7].f };
    JavaObject* ri = (JavaObject*)args[8].ref;
    if (!node || !ri) return NATIVE_RETURN_VOID();

    float best = 1e30f;
    JavaObject* best_node = NULL;

    /* iterative stack walk (depth-first), transforming the ray into each
     * child's local space via the inverse node transform */
    #define PICK_STACK_MAX 64
    JavaObject* stack[PICK_STACK_MAX];
    float rox[PICK_STACK_MAX][3], rdx[PICK_STACK_MAX][3];
    int sp = 0;
    stack[sp] = node;
    rox[sp][0]=ro[0]; rox[sp][1]=ro[1]; rox[sp][2]=ro[2];
    rdx[sp][0]=rd[0]; rdx[sp][1]=rd[1]; rdx[sp][2]=rd[2];
    sp++;

    while (sp > 0) {
        sp--;
        JavaObject* n = stack[sp];
        if (!n) continue;
        float o[3] = { rox[sp][0], rox[sp][1], rox[sp][2] };
        float d[3] = { rdx[sp][0], rdx[sp][1], rdx[sp][2] };

        JavaClass* cn = n->header.clazz;
        const char* nm = (cn && cn->class_name) ? cn->class_name : "";
        int node_scope = m3g_get_int_field(n, "scope", 0);
        if (node_scope != 0 && (scope & node_scope) == 0) continue;
        int pickable = m3g_get_int_field(n, "pickingEnable", 1);

        if (pickable && strstr(nm, "Mesh") != NULL && !strstr(nm, "SkinnedMesh") && !strstr(nm, "MorphingMesh")) {
            /* ray vs triangles in local space */
            JavaObject* vb = m3g_get_ref_field(n, "vertexBuffer");
            JavaObject* ib = m3g_get_ref_field(n, "indexBuffer");
            JavaObject* pos_va = vb ? m3g_get_ref_field(vb, "positions") : NULL;
            JavaArray* pos_data = pos_va ? (JavaArray*)m3g_get_ref_field(pos_va, "data") : NULL;
            JavaArray* ib_data = ib ? (JavaArray*)m3g_get_ref_field(ib, "data") : NULL;
            if (pos_data && ib_data) {
                float scale = m3g_get_float_field(vb, "positionScale", 1.0f);
                int comps = m3g_get_int_field(pos_va, "componentCount", 3);
                int nv = m3g_get_int_field(pos_va, "vertexCount", 0);
                int nt = (int)ib_data->length / 3;
                float* px = (float*)malloc((size_t)nv * 3 * sizeof(float));
                int have_px = 0;
                if (px) {
                    have_px = 1;
                    if (pos_data->element_type == T_FLOAT) {
                        float* s = (float*)array_data(pos_data);
                        for (int i = 0; i < nv; i++)
                            for (int c = 0; c < 3; c++)
                                px[i*3+c] = s[i*comps+c] * scale;
                    } else {
                        int16_t* s = (int16_t*)array_data(pos_data);
                        for (int i = 0; i < nv; i++)
                            for (int c = 0; c < 3; c++)
                                px[i*3+c] = (float)s[i*comps+c] * scale;
                    }
                }
                jint* idx = (jint*)array_data(ib_data);
                for (int t = 0; t < nt && have_px; t++) {
                    int i0 = idx[t*3], i1 = idx[t*3+1], i2 = idx[t*3+2];
                    if (i0 < 0 || i1 < 0 || i2 < 0 || i0 >= nv || i1 >= nv || i2 >= nv) continue;
                    /* Moller-Trumbore */
                    float e1[3] = { px[i1*3]-px[i0*3], px[i1*3+1]-px[i0*3+1], px[i1*3+2]-px[i0*3+2] };
                    float e2[3] = { px[i2*3]-px[i0*3], px[i2*3+1]-px[i0*3+1], px[i2*3+2]-px[i0*3+2] };
                    float p[3] = { d[1]*e2[2]-d[2]*e2[1], d[2]*e2[0]-d[0]*e2[2], d[0]*e2[1]-d[1]*e2[0] };
                    float det = e1[0]*p[0]+e1[1]*p[1]+e1[2]*p[2];
                    if (fabsf(det) < 1e-12f) continue;
                    float inv = 1.0f/det;
                    float tv[3] = { o[0]-px[i0*3], o[1]-px[i0*3+1], o[2]-px[i0*3+2] };
                    float u = (tv[0]*p[0]+tv[1]*p[1]+tv[2]*p[2]) * inv;
                    if (u < 0.0f || u > 1.0f) continue;
                    float q[3] = { tv[1]*e1[2]-tv[2]*e1[1], tv[2]*e1[0]-tv[0]*e1[2], tv[0]*e1[1]-tv[1]*e1[0] };
                    float v = (d[0]*q[0]+d[1]*q[1]+d[2]*q[2]) * inv;
                    if (v < 0.0f || u+v > 1.0f) continue;
                    float dist = (e2[0]*q[0]+e2[1]*q[1]+e2[2]*q[2]) * inv;
                    if (dist >= 0.0f && dist < best) {
                        best = dist; best_node = n;
                    }
                }
                if (px) free(px);
            }
        } else if (pickable && strstr(nm, "Sprite3D") != NULL) {
            /* ray vs XY-plane billboard in local space */
            JavaObject* img = m3g_get_ref_field(n, "image");
            if (img) {
                float iw = m3g_get_float_field(img, "width", 0.0f);
                float ih = m3g_get_float_field(img, "height", 0.0f);
                if (iw > 0.0f && ih > 0.0f && fabsf(d[2]) > 1e-9f) {
                    float t = -o[2] / d[2];
                    if (t >= 0.0f) {
                        float hx = o[0] + d[0]*t, hy = o[1] + d[1]*t;
                        if (hx >= 0.0f && hx <= iw && hy >= 0.0f && hy <= ih && t < best) {
                            best = t; best_node = n;
                        }
                    }
                }
            }
        }

        /* recurse into Groups */
        if (strstr(nm, "Group") != NULL || strstr(nm, "World") != NULL) {
            JavaArray* children = (JavaArray*)m3g_get_ref_field(n, "children");
            if (children && children->element_type == DESC_OBJECT) {
                JavaObject** ch = (JavaObject**)array_data(children);
                for (jsize c = 0; c < children->length && sp < PICK_STACK_MAX; c++) {
                    JavaObject* child = ch[c];
                    if (!child) continue;
                    /* transform ray into child local space */
                    M3GTransform ct;
                    m3g_build_node_transform(child, &ct);
                    /* invert ct (cofactor method, small helper inline) */
                    M3GTransform inv;
                    {
                        float m[16], idn[16];
                        memcpy(m, ct.m, sizeof(m));
                        for (int i = 0; i < 16; i++) idn[i] = (i % 4 == i / 4) ? 1.0f : 0.0f;
                        int ok = 1;
                        for (int col = 0; col < 4 && ok; col++) {
                            int piv = col;
                            for (int r = col + 1; r < 4; r++)
                                if (fabsf(m[r*4+col]) > fabsf(m[piv*4+col])) piv = r;
                            if (fabsf(m[piv*4+col]) < 1e-12f) { ok = 0; break; }
                            if (piv != col)
                                for (int k = 0; k < 4; k++) {
                                    float tm = m[col*4+k]; m[col*4+k] = m[piv*4+k]; m[piv*4+k] = tm;
                                    float ti = idn[col*4+k]; idn[col*4+k] = idn[piv*4+k]; idn[piv*4+k] = ti;
                                }
                            float dv = m[col*4+col];
                            for (int k = 0; k < 4; k++) { m[col*4+k] /= dv; idn[col*4+k] /= dv; }
                            for (int r = 0; r < 4; r++) {
                                if (r == col) continue;
                                float f = m[r*4+col];
                                if (f != 0.0f)
                                    for (int k = 0; k < 4; k++) { m[r*4+k] -= f*m[col*4+k]; idn[r*4+k] -= f*idn[col*4+k]; }
                            }
                        }
                        if (ok) memcpy(inv.m, idn, sizeof(inv.m));
                        else m3g_transform_identity(&inv);
                    }
                    float* next_ro = rox[sp];
                    float* next_rd = rdx[sp];
                    for (int a3 = 0; a3 < 3; a3++) {
                        next_ro[a3] = inv.m[a3*4+0]*o[0] + inv.m[a3*4+1]*o[1] + inv.m[a3*4+2]*o[2] + inv.m[a3*4+3];
                        next_rd[a3] = inv.m[a3*4+0]*d[0] + inv.m[a3*4+1]*d[1] + inv.m[a3*4+2]*d[2];
                    }
                    stack[sp] = child;
                    sp++;
                }
            }
        }
    }
    #undef PICK_STACK_MAX

    if (best_node) {
        m3g_set_float_field(ri, "distance", best);
        m3g_set_ref_field(ri, "intersected", best_node);
    }
    return NATIVE_RETURN_VOID();
}

/* ---- SkinnedMesh Java API over the v22 binding storage ---- */
static JavaValue native_skinnedmesh_init(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    /* (VB, IB, App, bonesVB, bonesIB) or (VB, [IB, [App, bonesVB, bonesIB) */
    JavaObject* sm = (JavaObject*)args[0].ref;
    JavaObject* vb = (JavaObject*)args[1].ref;
    JavaObject* ib = (JavaObject*)args[2].ref;
    JavaObject* app = (JavaObject*)args[3].ref;
    JavaObject* bones_vb = (JavaObject*)args[4].ref;
    JavaObject* bones_ib = (JavaObject*)args[5].ref;
    if (!sm) return NATIVE_RETURN_VOID();

    m3g_set_ref_field(sm, "vertexBuffer", vb);
    m3g_set_ref_field(sm, "indexBuffer", ib);
    m3g_set_ref_field(sm, "appearance", app);
    m3g_set_ref_field(sm, "bones", bones_vb);
    m3g_set_ref_field(sm, "boneIndices", bones_ib);
    m3g_set_int_field(sm, "renderingEnable", 1);

    /* Derive bindings from the skeleton: each bone position is a 4-tuple
     * (boneNodeIndex placeholder, firstVertex, vertexCount, weight) and
     * boneIndices groups them in triples — mirrored from the M3G file
     * layout the v22 parser fills. Node references are linked lazily via
     * addTransform. */
    JavaArray* bone_ib = bones_ib ? (JavaArray*)m3g_get_ref_field(bones_ib, "data") : NULL;
    JavaObject* bones_va = bones_vb ? m3g_get_ref_field(bones_vb, "positions") : NULL;
    JavaArray* bone_pos = bones_va ? (JavaArray*)m3g_get_ref_field(bones_va, "data") : NULL;
    if (!bone_ib || !bone_pos) return NATIVE_RETURN_VOID();

    int nbones = (int)bone_ib->length / 3;
    if (nbones <= 0) return NATIVE_RETURN_VOID();
    int comps = m3g_get_int_field(bones_va, "componentCount", 4);
    jint* idx = (jint*)array_data(bone_ib);

    JavaArray* refs = jvm_new_array(jvm, DESC_OBJECT, nbones, NULL);
    JavaArray* first = jvm_new_array(jvm, T_INT, nbones, NULL);
    JavaArray* cnt = jvm_new_array(jvm, T_INT, nbones, NULL);
    JavaArray* wgt = jvm_new_array(jvm, T_INT, nbones, NULL);
    if (refs) m3g_set_ref_field(sm, "boneNodeRefs", (JavaObject*)refs);
    if (first) m3g_set_ref_field(sm, "boneFirstVertex", (JavaObject*)first);
    if (cnt) m3g_set_ref_field(sm, "boneVertexCount", (JavaObject*)cnt);
    if (wgt) m3g_set_ref_field(sm, "boneWeights", (JavaObject*)wgt);

    jint* fv = first ? (jint*)array_data(first) : NULL;
    jint* vc = cnt ? (jint*)array_data(cnt) : NULL;
    jint* wt = wgt ? (jint*)array_data(wgt) : NULL;

    for (int b = 0; b < nbones; b++) {
        int vi = idx[b*3];  /* first vertex of the triple */
        if (fv) fv[b] = (comps >= 2 && bone_pos->element_type == T_FLOAT)
            ? (jint)((float*)array_data(bone_pos))[vi*comps+1] : 0;
        if (vc) vc[b] = (comps >= 3 && bone_pos->element_type == T_FLOAT)
            ? (jint)((float*)array_data(bone_pos))[vi*comps+2] : 0;
        if (wt) wt[b] = (comps >= 4 && bone_pos->element_type == T_FLOAT)
            ? (jint)((float*)array_data(bone_pos))[vi*comps+3] : 255;
    }
    return NATIVE_RETURN_VOID();
}

static JavaValue native_skinnedmesh_addTransform(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    /* addTransform(Node bone, int firstVertex, int numVertices, int weight) */
    JavaObject* sm = (JavaObject*)args[0].ref;
    JavaObject* bone = (JavaObject*)args[1].ref;
    jint first = args[2].i, count = args[3].i, weight = args[4].i;
    if (!sm || !bone) return NATIVE_RETURN_VOID();

    JavaArray* refs = (JavaArray*)m3g_get_ref_field(sm, "boneNodeRefs");
    JavaArray* firsta = (JavaArray*)m3g_get_ref_field(sm, "boneFirstVertex");
    JavaArray* cnta = (JavaArray*)m3g_get_ref_field(sm, "boneVertexCount");
    JavaArray* wgta = (JavaArray*)m3g_get_ref_field(sm, "boneWeights");
    if (!refs || !firsta || !cnta || !wgta) return NATIVE_RETURN_VOID();

    int old = refs->length;
    JavaArray* nrefs = jvm_new_array(jvm, DESC_OBJECT, old + 1, NULL);
    JavaArray* nfirst = jvm_new_array(jvm, T_INT, old + 1, NULL);
    JavaArray* ncnt = jvm_new_array(jvm, T_INT, old + 1, NULL);
    JavaArray* nwgt = jvm_new_array(jvm, T_INT, old + 1, NULL);
    if (!nrefs || !nfirst || !ncnt || !nwgt) return NATIVE_RETURN_VOID();
    if (old) {
        memcpy(array_data(nrefs), array_data(refs), (size_t)old * sizeof(void*));
        memcpy(array_data(nfirst), array_data(firsta), (size_t)old * sizeof(jint));
        memcpy(array_data(ncnt), array_data(cnta), (size_t)old * sizeof(jint));
        memcpy(array_data(nwgt), array_data(wgta), (size_t)old * sizeof(jint));
    }
    ((JavaObject**)array_data(nrefs))[old] = bone;
    ((jint*)array_data(nfirst))[old] = first;
    ((jint*)array_data(ncnt))[old] = count;
    ((jint*)array_data(nwgt))[old] = weight;
    m3g_set_ref_field(sm, "boneNodeRefs", (JavaObject*)nrefs);
    m3g_set_ref_field(sm, "boneFirstVertex", (JavaObject*)nfirst);
    m3g_set_ref_field(sm, "boneVertexCount", (JavaObject*)ncnt);
    m3g_set_ref_field(sm, "boneWeights", (JavaObject*)nwgt);
    return NATIVE_RETURN_VOID();
}

static JavaValue native_skinnedmesh_getBoneTransform(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* sm = (JavaObject*)args[0].ref;
    JavaObject* bone = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    if (bone && transform) {
        M3GTransform t;
        m3g_build_node_transform(bone, &t);
        set_native_transform(transform, &t);
    }
    (void)sm;
    return NATIVE_RETURN_VOID();
}

static JavaValue native_skinnedmesh_getSkeleton(JVM* jvm, JavaThread* thread, JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* sm = (JavaObject*)args[0].ref;
    JavaArray* refs = sm ? (JavaArray*)m3g_get_ref_field(sm, "boneNodeRefs") : NULL;
    if (refs && refs->length > 0)
        return NATIVE_RETURN_OBJECT(((JavaObject**)array_data(refs))[0]);
    JavaObject* bones_vb = sm ? m3g_get_ref_field(sm, "bones") : NULL;
    return NATIVE_RETURN_OBJECT(bones_vb);
}

void init_javax_microedition_m3g(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Graphics3D */
        {"javax/microedition/m3g/Graphics3D", "getInstance", "()Ljavax/microedition/m3g/Graphics3D;", native_graphics3d_getInstance},
        {"javax/microedition/m3g/Graphics3D", "getProperties", "()Ljava/util/Hashtable;", native_graphics3d_getProperties},
        {"javax/microedition/m3g/Graphics3D", "bindTarget", "(Ljava/lang/Object;ZI)V", native_graphics3d_bindTarget_3arg},
        /* v10 FIX: JSR-184 spec signatures that were missing — the game's
         * calls resolved to silent no-ops (descriptor-exact native lookup):
         *   bindTarget(Object) returns Object; 3-arg form returns Object too;
         *   render(World, Transform) was not registered at all. */
        {"javax/microedition/m3g/Graphics3D", "bindTarget", "(Ljava/lang/Object;)Ljava/lang/Object;", native_graphics3d_bindTarget_3arg},
        {"javax/microedition/m3g/Graphics3D", "bindTarget", "(Ljava/lang/Object;ZI)Ljava/lang/Object;", native_graphics3d_bindTarget_3arg},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/World;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_renderWorld_transform},
        /* v11 FIX: immediate-mode render — was NEVER registered (silent no-op!) */
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/VertexBuffer;Ljavax/microedition/m3g/IndexBuffer;Ljavax/microedition/m3g/Appearance;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_render_immediate},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/VertexBuffer;Ljavax/microedition/m3g/IndexBuffer;Ljavax/microedition/m3g/Appearance;Ljavax/microedition/m3g/Transform;I)V", native_graphics3d_render_immediate},
        {"javax/microedition/m3g/Graphics3D", "bindTarget", "(Ljavax/microedition/m3g/Image2D;)V", native_graphics3d_bindTarget},
        {"javax/microedition/m3g/Graphics3D", "releaseTarget", "()V", native_graphics3d_releaseTarget},
        {"javax/microedition/m3g/Graphics3D", "clear", "(Ljavax/microedition/m3g/Background;)V", native_graphics3d_clear},
        {"javax/microedition/m3g/Graphics3D", "setViewport", "(IIII)V", native_graphics3d_setViewport},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/World;)V", native_graphics3d_renderWorld},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/Node;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_render_node},
        {"javax/microedition/m3g/Graphics3D", "addLight", "(Ljavax/microedition/m3g/Light;Ljavax/microedition/m3g/Transform;)I", native_graphics3d_addLight},
        {"javax/microedition/m3g/Graphics3D", "setLight", "(ILjavax/microedition/m3g/Light;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_setLight},
        {"javax/microedition/m3g/Graphics3D", "setCamera", "(Ljavax/microedition/m3g/Camera;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_setCamera},
        {"javax/microedition/m3g/Graphics3D", "resetLights", "()V", native_graphics3d_resetLights},
        
        /* Transform */
        {"javax/microedition/m3g/Transform", "<init>", "()V", native_transform_init},
        {"javax/microedition/m3g/Transform", "<init>", "(Ljavax/microedition/m3g/Transform;)V", native_transform_init_copy},
        {"javax/microedition/m3g/Transform", "setIdentity", "()V", native_transform_setIdentity},
        {"javax/microedition/m3g/Transform", "postMultiply", "(Ljavax/microedition/m3g/Transform;)V", native_transform_postMultiply},
        {"javax/microedition/m3g/Transform", "postTranslate", "(FFF)V", native_transform_postTranslate},
        {"javax/microedition/m3g/Transform", "postRotate", "(FFFF)V", native_transform_postRotate},
        {"javax/microedition/m3g/Transform", "postScale", "(FFF)V", native_transform_postScale},
        {"javax/microedition/m3g/Transform", "invert", "()V", native_transform_invert},
        /* v23: remaining Transform API */
        {"javax/microedition/m3g/Transform", "transpose", "()V", native_transform_transpose},
        {"javax/microedition/m3g/Transform", "postRotateQuat", "(FFFF)V", native_transform_postRotateQuat},
        {"javax/microedition/m3g/Transform", "postSkew", "(FFFFFF)V", native_transform_postSkew},
        {"javax/microedition/m3g/Transform", "set", "([F)V", native_transform_setArray},
        {"javax/microedition/m3g/Transform", "get", "([F)V", native_transform_getArray},
        {"javax/microedition/m3g/Transform", "transform", "([F)V", native_transform_transform},
        
        /* VertexArray */
        {"javax/microedition/m3g/VertexArray", "<init>", "(III)V", native_vertexarray_init},
        {"javax/microedition/m3g/VertexArray", "set", "(II[B)V", native_vertexarray_set_byte},
        {"javax/microedition/m3g/VertexArray", "set", "(II[S)V", native_vertexarray_set_short},
        
        /* VertexBuffer */
        {"javax/microedition/m3g/VertexBuffer", "<init>", "()V", native_vertexbuffer_init},
        {"javax/microedition/m3g/VertexBuffer", "setPositions", "(Ljavax/microedition/m3g/VertexArray;F[F)V", native_vertexbuffer_setPositions},
        {"javax/microedition/m3g/VertexBuffer", "setNormals", "(Ljavax/microedition/m3g/VertexArray;)V", native_vertexbuffer_setNormals},
        {"javax/microedition/m3g/VertexBuffer", "setTexCoords", "(ILjavax/microedition/m3g/VertexArray;F[F)V", native_vertexbuffer_setTexCoords},
        {"javax/microedition/m3g/VertexBuffer", "setColors", "(Ljavax/microedition/m3g/VertexArray;)V", native_vertexbuffer_setColors},
        
        /* Camera */
        {"javax/microedition/m3g/Camera", "setPerspective", "(FFFF)V", native_camera_setPerspective},
        {"javax/microedition/m3g/Camera", "setParallel", "(FFFF)V", native_camera_setParallel},
        {"javax/microedition/m3g/Camera", "setGeneric", "(Ljavax/microedition/m3g/Transform;)V", native_camera_setGeneric},
        {"javax/microedition/m3g/Camera", "getProjection", "([F)I", native_camera_getProjection},
        {"javax/microedition/m3g/Camera", "lookAt", "(FFFFFFFFF)V", native_camera_lookAt},
        
        /* Light */
        {"javax/microedition/m3g/Light", "setType", "(I)V", native_light_setType},
        {"javax/microedition/m3g/Light", "setMode", "(I)V", native_light_setType}, /* same handler */
        {"javax/microedition/m3g/Light", "setColor", "(I)V", native_light_setColor},
        {"javax/microedition/m3g/Light", "setIntensity", "(F)V", native_light_setIntensity},
        {"javax/microedition/m3g/Light", "setDirection", "(FFF)V", native_light_setDirection},
        
        /* Material */
        {"javax/microedition/m3g/Material", "setColor", "(II)V", native_material_setColor},
        {"javax/microedition/m3g/Material", "setShininess", "(F)V", native_material_setShininess},
        /* v14: vertex color tracking (M3GTest unlit appearances) */
        {"javax/microedition/m3g/Material", "setVertexColorTrackingEnable", "(Z)V", native_material_setVertexColorTrackingEnable},
        {"javax/microedition/m3g/Material", "getVertexColorTrackingEnable", "()Z", native_material_getVertexColorTrackingEnable},
        
        /* Appearance */
        {"javax/microedition/m3g/Appearance", "setMaterial", "(Ljavax/microedition/m3g/Material;)V", native_appearance_setMaterial},
        {"javax/microedition/m3g/Appearance", "getMaterial", "()Ljavax/microedition/m3g/Material;", native_appearance_getMaterial},
        {"javax/microedition/m3g/Appearance", "setTexture", "(ILjavax/microedition/m3g/Texture2D;)V", native_appearance_setTexture},
        
        /* Texture2D */
        {"javax/microedition/m3g/Texture2D", "<init>", "(Ljavax/microedition/m3g/Image2D;)V", native_texture2d_init},
        {"javax/microedition/m3g/Texture2D", "setFiltering", "(I)V", native_texture2d_setFiltering},
        /* v14: the real JSR-184 signature is setFiltering(levelFilter, imageFilter) */
        {"javax/microedition/m3g/Texture2D", "setFiltering", "(II)V", native_texture2d_setFiltering},
        {"javax/microedition/m3g/Texture2D", "setWrapping", "(II)V", native_texture2d_setWrapping},
        /* v14: texture blending / blend color / UV transform */
        {"javax/microedition/m3g/Texture2D", "setBlending", "(I)V", native_texture2d_setBlending},
        {"javax/microedition/m3g/Texture2D", "getBlending", "()I", native_texture2d_getBlending},
        {"javax/microedition/m3g/Texture2D", "setBlendColor", "(I)V", native_texture2d_setBlendColor},
        {"javax/microedition/m3g/Texture2D", "getBlendColor", "()I", native_texture2d_getBlendColor},
        {"javax/microedition/m3g/Texture2D", "setTransform", "(Ljavax/microedition/m3g/Transform;)V", native_texture2d_setTransform},
        
        /* Mesh */
        {"javax/microedition/m3g/Mesh", "<init>", "(Ljavax/microedition/m3g/VertexBuffer;Ljavax/microedition/m3g/IndexBuffer;Ljavax/microedition/m3g/Appearance;)V", native_mesh_init},
        {"javax/microedition/m3g/Mesh", "setVertexBuffer", "(ILjavax/microedition/m3g/VertexArray;)V", native_mesh_setVertexBuffer},
        
        /* v14: MorphingMesh — previously COMPLETELY unregistered: the
         * constructor returned a null-like object and setWeights crashed
         * with NPE, killing the canvas (M3GTest scene 6 "black screen") */
        {"javax/microedition/m3g/MorphingMesh", "<init>", "(Ljavax/microedition/m3g/VertexBuffer;[Ljavax/microedition/m3g/VertexBuffer;[Ljavax/microedition/m3g/IndexBuffer;[Ljavax/microedition/m3g/Appearance;)V", native_morphingmesh_init},
        {"javax/microedition/m3g/MorphingMesh", "setWeights", "([F)V", native_morphingmesh_setWeights},
        {"javax/microedition/m3g/MorphingMesh", "getWeights", "()[F", native_morphingmesh_getWeights},
        
        /* TriangleStripArray */
        {"javax/microedition/m3g/TriangleStripArray", "<init>", "(I[I)V", native_trianglestrip_init},
        /* v14: explicit-index constructor — was unregistered entirely */
        {"javax/microedition/m3g/TriangleStripArray", "<init>", "([I[I)V", native_trianglestrip_init_explicit},
        
        /* Node */
        {"javax/microedition/m3g/Node", "setScale", "(FFF)V", native_node_setScale},
        {"javax/microedition/m3g/Node", "setTranslation", "(FFF)V", native_node_setTranslation},
        {"javax/microedition/m3g/Node", "setRotation", "(FFFF)V", native_node_setRotation},
        {"javax/microedition/m3g/Node", "setOrientation", "(FFFF)V", native_node_setRotation}, /* v14: alias — M3GTest/SceneLights/Nescube */
        {"javax/microedition/m3g/Node", "getTransform", "(Ljavax/microedition/m3g/Transform;)V", native_node_getTransform},
        {"javax/microedition/m3g/Node", "setTransform", "(Ljavax/microedition/m3g/Transform;)V", native_node_setTransform},
        {"javax/microedition/m3g/Node", "setAlphaFactor", "(F)V", native_node_setAlphaFactor},
        
        /* Group */
        {"javax/microedition/m3g/Group", "addChild", "(Ljavax/microedition/m3g/Node;)V", native_group_addChild},
        {"javax/microedition/m3g/Group", "removeChild", "(Ljavax/microedition/m3g/Node;)V", native_group_removeChild},
        {"javax/microedition/m3g/Group", "getChildCount", "()I", native_group_getChildCount},
        {"javax/microedition/m3g/Group", "getChild", "(I)Ljavax/microedition/m3g/Node;", native_group_getChild},
        
        /* World */
        {"javax/microedition/m3g/World", "addCamera", "(Ljavax/microedition/m3g/Camera;)V", native_world_addCamera},
        {"javax/microedition/m3g/World", "setBackground", "(Ljavax/microedition/m3g/Background;)V", native_world_setBackground},
        {"javax/microedition/m3g/World", "addChild", "(Ljavax/microedition/m3g/Node;)V", native_world_addChild},
        {"javax/microedition/m3g/World", "setActiveCamera", "(Ljavax/microedition/m3g/Camera;)V", native_world_setActiveCamera},
        {"javax/microedition/m3g/World", "getActiveCamera", "()Ljavax/microedition/m3g/Camera;", native_world_getActiveCamera},
        
        /* Object3D */
        {"javax/microedition/m3g/Object3D", "find", "(I)Ljavax/microedition/m3g/Object3D;", native_object3d_find},
        {"javax/microedition/m3g/Object3D", "getUserID", "()I", native_object3d_getUserID},
        {"javax/microedition/m3g/Object3D", "setUserID", "(I)V", native_object3d_setUserID},
        {"javax/microedition/m3g/Object3D", "duplicate", "()Ljavax/microedition/m3g/Object3D;", native_object3d_duplicate},
        
        /* Background */
        {"javax/microedition/m3g/Background", "setColor", "(I)V", native_background_setColor},
        {"javax/microedition/m3g/Background", "<init>", "()V", native_background_init},
        
        /* Image2D */
        {"javax/microedition/m3g/Image2D", "<init>", "(III)V", native_image2d_init},
        {"javax/microedition/m3g/Image2D", "<init>", "(ILjava/lang/Object;)V", native_image2d_init_from_image},
        {"javax/microedition/m3g/Image2D", "set", "(IIII[B)V", native_image2d_set},
        
        /* CompositingMode */
        {"javax/microedition/m3g/CompositingMode", "<init>", "()V", native_compositingmode_init},
        {"javax/microedition/m3g/CompositingMode", "setBlending", "(I)V", native_compositingmode_setBlending},
        /* v23: write masks / dithering (JSR-184 §CompositingMode) */
        {"javax/microedition/m3g/CompositingMode", "setAlphaWriteEnable", "(Z)V", native_compositingmode_setAlphaWriteEnable},
        {"javax/microedition/m3g/CompositingMode", "setColorWriteEnable", "(Z)V", native_compositingmode_setColorWriteEnable},
        {"javax/microedition/m3g/CompositingMode", "setDithering", "(Z)V", native_compositingmode_setDithering},
        
        /* PolygonMode */
        {"javax/microedition/m3g/PolygonMode", "<init>", "()V", native_polygonmode_init},
        {"javax/microedition/m3g/PolygonMode", "setCulling", "(I)V", native_polygonmode_setCulling},
        
        /* v24: JSR-184 completeness batch (audit backlog) */
        /* Node Transformable ops + misc (inherited by all Node subclasses) */
        {"javax/microedition/m3g/Node", "postRotate", "(FFFF)V", native_node_postRotate},
        {"javax/microedition/m3g/Node", "preRotate", "(FFFF)V", native_node_preRotate},
        {"javax/microedition/m3g/Node", "rotateQuat", "(FFFF)V", native_node_rotateQuat},
        {"javax/microedition/m3g/Node", "translate", "(FFF)V", native_node_translate},
        {"javax/microedition/m3g/Node", "scale", "(FFF)V", native_node_scale},
        {"javax/microedition/m3g/Node", "getOrientation", "([F)V", native_node_getOrientation},
        {"javax/microedition/m3g/Node", "getScale", "([F)V", native_node_getScale},
        {"javax/microedition/m3g/Node", "getTranslation", "([F)V", native_node_getTranslation},
        {"javax/microedition/m3g/Node", "getTransformTo", "(Ljavax/microedition/m3g/Transform;)Z", native_node_getTransformTo},
        {"javax/microedition/m3g/Node", "getAlphaFactor", "()F", native_node_getAlphaFactor},
        {"javax/microedition/m3g/Node", "getScope", "()I", native_node_getScope},
        {"javax/microedition/m3g/Node", "setScope", "(I)V", native_node_setScope},
        {"javax/microedition/m3g/Node", "setPickingEnable", "(Z)V", native_node_setPickingEnable},
        {"javax/microedition/m3g/Node", "isPickingEnabled", "()Z", native_node_isPickingEnabled},
        {"javax/microedition/m3g/Node", "isRenderingEnable", "()Z", native_node_isRenderingEnabled},
        {"javax/microedition/m3g/Node", "pick", "(IFFFFFFFLjavax/microedition/m3g/RayIntersection;)V", native_node_pick},
        /* Texture2D completion */
        {"javax/microedition/m3g/Texture2D", "getTransform", "(Ljavax/microedition/m3g/Transform;)V", native_texture2d_getTransform},
        {"javax/microedition/m3g/Texture2D", "setImage", "(Ljavax/microedition/m3g/Image2D;)V", native_texture2d_setImage},
        {"javax/microedition/m3g/Texture2D", "getImage", "()Ljavax/microedition/m3g/Image2D;", native_texture2d_getImage},
        /* Light completion */
        {"javax/microedition/m3g/Light", "getColor", "()I", native_light_getColor},
        {"javax/microedition/m3g/Light", "getIntensity", "()F", native_light_getIntensity},
        {"javax/microedition/m3g/Light", "getMode", "()I", native_light_getMode},
        {"javax/microedition/m3g/Light", "getSpotAngle", "()F", native_light_getSpotAngle},
        {"javax/microedition/m3g/Light", "getSpotExponent", "()F", native_light_getSpotExponent},
        {"javax/microedition/m3g/Light", "setSpotAngle", "(F)V", native_light_setSpotAngle},
        {"javax/microedition/m3g/Light", "setSpotExponent", "(F)V", native_light_setSpotExponent},
        {"javax/microedition/m3g/Light", "setAttenuation", "(FFF)V", native_light_setAttenuation},
        {"javax/microedition/m3g/Light", "getAttenuation", "([F)V", native_light_getAttenuation},
        /* Material completion */
        {"javax/microedition/m3g/Material", "getColor", "(I)I", native_material_getColor},
        {"javax/microedition/m3g/Material", "getShininess", "()F", native_material_getShininess},
        /* Graphics3D completion */
        {"javax/microedition/m3g/Graphics3D", "setDepthRange", "(FF)V", native_g3d_setDepthRange},
        {"javax/microedition/m3g/Graphics3D", "getDepthRange", "([F)V", native_g3d_getDepthRange},
        {"javax/microedition/m3g/Graphics3D", "getCamera", "(Ljavax/microedition/m3g/Transform;)Ljavax/microedition/m3g/Camera;", native_g3d_getCamera},
        {"javax/microedition/m3g/Graphics3D", "getLightCount", "()I", native_g3d_getLightCount},
        {"javax/microedition/m3g/Graphics3D", "getLight", "(ILjavax/microedition/m3g/Transform;)Ljavax/microedition/m3g/Light;", native_g3d_getLight},
        {"javax/microedition/m3g/Graphics3D", "isDepthBufferEnabled", "()Z", native_g3d_isDepthBufferEnabled},
        /* Background crop/image modes */
        {"javax/microedition/m3g/Background", "setImageMode", "(II)V", native_bg_setImageMode},
        {"javax/microedition/m3g/Background", "getImageModeX", "()I", native_bg_getImageModeX},
        {"javax/microedition/m3g/Background", "getImageModeY", "()I", native_bg_getImageModeY},
        {"javax/microedition/m3g/Background", "setCrop", "(IIII)V", native_bg_setCrop},
        {"javax/microedition/m3g/Background", "getCropX", "()I", native_bg_getCropX},
        {"javax/microedition/m3g/Background", "getCropY", "()I", native_bg_getCropY},
        {"javax/microedition/m3g/Background", "getCropWidth", "()I", native_bg_getCropWidth},
        {"javax/microedition/m3g/Background", "getCropHeight", "()I", native_bg_getCropHeight},
        /* Appearance.getTexture */
        {"javax/microedition/m3g/Appearance", "getTexture", "(I)Ljavax/microedition/m3g/Texture2D;", native_appearance_getTexture},
        /* VertexArray get */
        {"javax/microedition/m3g/VertexArray", "get", "(II[B)V", native_vertexarray_get_bytes},
        {"javax/microedition/m3g/VertexArray", "get", "(II[I)V", native_vertexarray_get_ints},
        /* VertexBuffer completion */
        {"javax/microedition/m3g/VertexBuffer", "setDefaultColor", "(I)V", native_vb_setDefaultColor},
        {"javax/microedition/m3g/VertexBuffer", "getDefaultColor", "(I)I", native_vb_getDefaultColor},
        {"javax/microedition/m3g/VertexBuffer", "getColors", "()Ljavax/microedition/m3g/VertexArray;", native_vb_getColors},
        {"javax/microedition/m3g/VertexBuffer", "getNormals", "()Ljavax/microedition/m3g/VertexArray;", native_vb_getNormals},
        {"javax/microedition/m3g/VertexBuffer", "getPositions", "([F)Ljavax/microedition/m3g/VertexArray;", native_vb_getPositions},
        {"javax/microedition/m3g/VertexBuffer", "getTexCoords", "(I[F)Ljavax/microedition/m3g/VertexArray;", native_vb_getTexCoords},
        {"javax/microedition/m3g/VertexBuffer", "getVertexCount", "()I", native_vb_getVertexCount},
        {"javax/microedition/m3g/VertexBuffer", "setTexCoords", "(ILjavax/microedition/m3g/VertexArray;F)V", native_vb_setTexCoords3},
        /* Mesh/MorphingMesh getters */
        {"javax/microedition/m3g/Mesh", "getVertexBuffer", "()Ljavax/microedition/m3g/VertexBuffer;", native_mesh_getVertexBuffer},
        {"javax/microedition/m3g/Mesh", "getIndexBuffer", "(I)Ljavax/microedition/m3g/IndexBuffer;", native_mesh_getIndexBuffer},
        {"javax/microedition/m3g/Mesh", "getAppearance", "(I)Ljavax/microedition/m3g/Appearance;", native_mesh_getAppearance},
        {"javax/microedition/m3g/Mesh", "getSubmeshCount", "()I", native_mesh_getSubmeshCount},
        {"javax/microedition/m3g/MorphingMesh", "getMorphTarget", "(I)Ljavax/microedition/m3g/VertexBuffer;", native_morph_getMorphTarget},
        {"javax/microedition/m3g/MorphingMesh", "getMorphTargetCount", "()I", native_morph_getMorphTargetCount},
        {"javax/microedition/m3g/MorphingMesh", "getWeights", "([F)I", native_morph_getWeights},
        /* Sprite3D appearance */
        {"javax/microedition/m3g/Sprite3D", "getAppearance", "()Ljavax/microedition/m3g/Appearance;", native_sprite3d_getAppearance},
        {"javax/microedition/m3g/Sprite3D", "setAppearance", "(Ljavax/microedition/m3g/Appearance;)V", native_sprite3d_setAppearance},
        /* AnimationTrack weight/controller */
        {"javax/microedition/m3g/AnimationTrack", "getController", "()Ljavax/microedition/m3g/AnimationController;", native_animtrack_getController},
        {"javax/microedition/m3g/AnimationTrack", "getWeight", "()F", native_animtrack_getWeight},
        {"javax/microedition/m3g/AnimationTrack", "setWeight", "(F)V", native_animtrack_setWeight},
        /* Camera.getProjection(Transform) */
        {"javax/microedition/m3g/Camera", "getProjection", "(Ljavax/microedition/m3g/Transform;)I", native_camera_getProjectionT},
        /* SkinnedMesh Java API */
        {"javax/microedition/m3g/SkinnedMesh", "<init>", "(Ljavax/microedition/m3g/VertexBuffer;Ljavax/microedition/m3g/IndexBuffer;Ljavax/microedition/m3g/Appearance;Ljavax/microedition/m3g/VertexBuffer;Ljavax/microedition/m3g/IndexBuffer;)V", native_skinnedmesh_init},
        {"javax/microedition/m3g/SkinnedMesh", "addTransform", "(Ljavax/microedition/m3g/Node;III)V", native_skinnedmesh_addTransform},
        {"javax/microedition/m3g/SkinnedMesh", "getBoneTransform", "(Ljavax/microedition/m3g/Node;Ljavax/microedition/m3g/Transform;)V", native_skinnedmesh_getBoneTransform},
        {"javax/microedition/m3g/SkinnedMesh", "getSkeleton", "()Ljavax/microedition/m3g/Node;", native_skinnedmesh_getSkeleton},

        /* Loader */
        {"javax/microedition/m3g/Loader", "load", "(Ljava/lang/String;)[Ljavax/microedition/m3g/Object3D;", native_loader_load},
        {"javax/microedition/m3g/Loader", "load", "(Ljavax/microedition/m3g/World;Ljava/lang/String;)[Ljavax/microedition/m3g/Object3D;", native_loader_load_into_world},
        {"javax/microedition/m3g/Loader", "load", "([BI)[Ljavax/microedition/m3g/Object3D;", native_loader_load_bytes},
        
        /* RayIntersection */
        {"javax/microedition/m3g/RayIntersection", "getDistance", "()F", native_rayintersection_getDistance},
        {"javax/microedition/m3g/RayIntersection", "getIntersected", "()Ljavax/microedition/m3g/Node;", native_rayintersection_getIntersected},
        
        /* Appearance - added missing methods */
        {"javax/microedition/m3g/Appearance", "getFog", "()Ljavax/microedition/m3g/Fog;", native_appearance_getFog},
        {"javax/microedition/m3g/Appearance", "setFog", "(Ljavax/microedition/m3g/Fog;)V", native_appearance_setFog},
        {"javax/microedition/m3g/Appearance", "getCompositingMode", "()Ljavax/microedition/m3g/CompositingMode;", native_appearance_getCompositingMode},
        {"javax/microedition/m3g/Appearance", "setCompositingMode", "(Ljavax/microedition/m3g/CompositingMode;)V", native_appearance_setCompositingMode},
        {"javax/microedition/m3g/Appearance", "getPolygonMode", "()Ljavax/microedition/m3g/PolygonMode;", native_appearance_getPolygonMode},
        {"javax/microedition/m3g/Appearance", "setPolygonMode", "(Ljavax/microedition/m3g/PolygonMode;)V", native_appearance_setPolygonMode},
        {"javax/microedition/m3g/Appearance", "getLayer", "()I", native_appearance_getLayer},
        {"javax/microedition/m3g/Appearance", "setLayer", "(I)V", native_appearance_setLayer},
        
        /* Graphics3D - added fog and viewport methods */
        {"javax/microedition/m3g/Graphics3D", "setFog", "(Ljavax/microedition/m3g/Fog;)V", native_graphics3d_setFog},
        {"javax/microedition/m3g/Graphics3D", "getFog", "()Ljavax/microedition/m3g/Fog;", native_graphics3d_getFog},
        {"javax/microedition/m3g/Graphics3D", "getViewport", "([I)V", native_graphics3d_getViewport},
        
        /* Background - added image and color methods */
        {"javax/microedition/m3g/Background", "setImage", "(Ljavax/microedition/m3g/Image2D;)V", native_background_setImage},
        {"javax/microedition/m3g/Background", "getImage", "()Ljavax/microedition/m3g/Image2D;", native_background_getImage},
        {"javax/microedition/m3g/Background", "setColorEnable", "(Z)V", native_background_setColorEnable},
        {"javax/microedition/m3g/Light", "getParent", "()Ljavax/microedition/m3g/Node;", native_node_getParent},
        {"javax/microedition/m3g/Group", "getParent", "()Ljavax/microedition/m3g/Node;", native_node_getParent},
        {"javax/microedition/m3g/Mesh", "getParent", "()Ljavax/microedition/m3g/Node;", native_node_getParent},
        {"javax/microedition/m3g/Node", "getParent", "()Ljavax/microedition/m3g/Node;", native_node_getParent},
        {"javax/microedition/m3g/Sprite3D", "isRenderingEnabled", "()Z", native_sprite3d_isRenderingEnabled},
        {"javax/microedition/m3g/Background", "setColorClearEnable", "(Z)V", native_background_setColorClearEnable},
        {"javax/microedition/m3g/Background", "setDepthClearEnable", "(Z)V", native_background_setDepthClearEnable},
        {"javax/microedition/m3g/Node", "setRenderingEnable", "(Z)V", native_node_setRenderingEnable},
        {"javax/microedition/m3g/Group", "setRenderingEnable", "(Z)V", native_node_setRenderingEnable},
        {"javax/microedition/m3g/Mesh", "setRenderingEnable", "(Z)V", native_node_setRenderingEnable},
        {"javax/microedition/m3g/Sprite3D", "setRenderingEnable", "(Z)V", native_node_setRenderingEnable},
        {"javax/microedition/m3g/Background", "getColorEnable", "()Z", native_background_getColorEnable},
        {"javax/microedition/m3g/Background", "getColor", "()I", native_background_getColor},
        
        /* Object3D.clone() */
        {"javax/microedition/m3g/Object3D", "clone", "()Ljavax/microedition/m3g/Object3D;", native_object3d_clone},
        
        /* Image2D - added getter methods */
        {"javax/microedition/m3g/Image2D", "getWidth", "()I", native_image2d_getWidth},
        {"javax/microedition/m3g/Image2D", "getHeight", "()I", native_image2d_getHeight},
        {"javax/microedition/m3g/Image2D", "isMutable", "()Z", native_image2d_isMutable},
        {"javax/microedition/m3g/Image2D", "getFormat", "()I", native_image2d_getFormat},
        
        /* PolygonMode - added missing methods */
        {"javax/microedition/m3g/PolygonMode", "getCulling", "()I", native_polygonmode_getCulling},
        {"javax/microedition/m3g/PolygonMode", "setShading", "(I)V", native_polygonmode_setShading},
        {"javax/microedition/m3g/PolygonMode", "getShading", "()I", native_polygonmode_getShading},
        {"javax/microedition/m3g/PolygonMode", "setWinding", "(I)V", native_polygonmode_setWinding},
        {"javax/microedition/m3g/PolygonMode", "getWinding", "()I", native_polygonmode_getWinding},
        /* v11: perspective-correction hint — found by the [M3G-MISSING]
         * diagnostic (Nescube). Store it so getters see the value; the
         * software rasterizer always uses perspective-correct mapping. */
        {"javax/microedition/m3g/PolygonMode", "setPerspectiveCorrectionEnable", "(Z)V", native_polygonmode_setPerspectiveCorrection},
        {"javax/microedition/m3g/PolygonMode", "getPerspectiveCorrectionEnable", "()Z", native_polygonmode_getPerspectiveCorrection},
        /* v12: found by [M3G-MISSING] on SU-30 */
        {"javax/microedition/m3g/PolygonMode", "setTwoSidedLightingEnable", "(Z)V", native_polygonmode_setTwoSidedLighting},
        {"javax/microedition/m3g/PolygonMode", "getTwoSidedLightingEnable", "()Z", native_polygonmode_getTwoSidedLighting},
        
        /* CompositingMode - added missing methods */
        {"javax/microedition/m3g/CompositingMode", "setDepthTestEnable", "(Z)V", native_cm_setDepthTestEnable},
        {"javax/microedition/m3g/CompositingMode", "getDepthTestEnable", "()Z", native_cm_getDepthTestEnable},
        {"javax/microedition/m3g/CompositingMode", "setDepthWriteEnable", "(Z)V", native_cm_setDepthWriteEnable},
        {"javax/microedition/m3g/CompositingMode", "getDepthWriteEnable", "()Z", native_cm_getDepthWriteEnable},
        {"javax/microedition/m3g/CompositingMode", "getBlending", "()I", native_cm_getBlending},
        {"javax/microedition/m3g/CompositingMode", "setAlphaThreshold", "(F)V", native_cm_setAlphaThreshold},
        {"javax/microedition/m3g/CompositingMode", "getAlphaThreshold", "()F", native_cm_getAlphaThreshold},
        
        /* Fog - added getter/setter methods */
        {"javax/microedition/m3g/Fog", "setColor", "(I)V", native_fog_setColor},
        {"javax/microedition/m3g/Fog", "getColor", "()I", native_fog_getColor},
        {"javax/microedition/m3g/Fog", "setMode", "(I)V", native_fog_setMode},
        {"javax/microedition/m3g/Fog", "getMode", "()I", native_fog_getMode},
        {"javax/microedition/m3g/Fog", "setDensity", "(F)V", native_fog_setDensity},
        {"javax/microedition/m3g/Fog", "getDensity", "()F", native_fog_getDensity},
        {"javax/microedition/m3g/Fog", "setLinear", "(FF)V", native_fog_setLinear},
        {"javax/microedition/m3g/Fog", "getLinearNear", "()F", native_fog_getLinearNear},
        {"javax/microedition/m3g/Fog", "getLinearFar", "()F", native_fog_getLinearFar},
        
        /* AnimationTrack */
        {"javax/microedition/m3g/AnimationTrack", "setController", "(Ljavax/microedition/m3g/AnimationController;)V", native_animationtrack_setController},
        /* v14: AnimationTrack/KeyframeSequence/AnimationController constructors
         * were never registered — all three were silent no-ops, so every
         * programmatically-built animation was dead on arrival. */
        {"javax/microedition/m3g/AnimationTrack", "<init>", "(Ljavax/microedition/m3g/KeyframeSequence;I)V", native_animationtrack_init},
        {"javax/microedition/m3g/AnimationTrack", "getTargetProperty", "()I", native_animationtrack_getTargetProperty},
        
        /* AnimationController */
        {"javax/microedition/m3g/AnimationController", "setActiveInterval", "(II)V", native_animationcontroller_setActiveInterval},
        {"javax/microedition/m3g/AnimationController", "getActiveIntervalStart", "()I", native_animationcontroller_getActiveIntervalStart},
        {"javax/microedition/m3g/AnimationController", "getActiveIntervalEnd", "()I", native_animationcontroller_getActiveIntervalEnd},
        {"javax/microedition/m3g/AnimationController", "setSpeed", "(FI)V", native_animationcontroller_setSpeed},
        {"javax/microedition/m3g/AnimationController", "getSpeed", "()F", native_animationcontroller_getSpeed},
        {"javax/microedition/m3g/AnimationController", "setPosition", "(FI)V", native_animationcontroller_setPosition},
        {"javax/microedition/m3g/AnimationController", "getPosition", "(I)F", native_animationcontroller_getPosition},
        {"javax/microedition/m3g/AnimationController", "setWeight", "(F)V", native_animationcontroller_setWeight},
        {"javax/microedition/m3g/AnimationController", "getWeight", "()F", native_animationcontroller_getWeight},
        {"javax/microedition/m3g/AnimationController", "getRefWorldTime", "()I", native_animationcontroller_getRefWorldTime},
        
        /* KeyframeSequence */
        {"javax/microedition/m3g/KeyframeSequence", "setKeyframe", "(II[F)V", native_keyframesequence_setKeyframe},
        /* v14: KeyframeSequence.<init>(int, int, int) — was unregistered */
        {"javax/microedition/m3g/KeyframeSequence", "<init>", "(III)V", native_keyframesequence_init},
        /* v14: AnimationController.<init>() — was unregistered */
        {"javax/microedition/m3g/AnimationController", "<init>", "()V", native_animationcontroller_init},
        {"javax/microedition/m3g/KeyframeSequence", "getDuration", "()I", native_keyframesequence_getDuration},
        {"javax/microedition/m3g/KeyframeSequence", "setDuration", "(I)V", native_keyframesequence_setDuration},
        {"javax/microedition/m3g/KeyframeSequence", "getRepeatMode", "()I", native_keyframesequence_getRepeatMode},
        {"javax/microedition/m3g/KeyframeSequence", "setRepeatMode", "(I)V", native_keyframesequence_setRepeatMode},
        {"javax/microedition/m3g/KeyframeSequence", "getComponentCount", "()I", native_keyframesequence_getComponentCount},
        {"javax/microedition/m3g/KeyframeSequence", "getKeyframeCount", "()I", native_keyframesequence_getKeyframeCount},
        {"javax/microedition/m3g/KeyframeSequence", "getInterpolationType", "()I", native_keyframesequence_getInterpolationType},
        {"javax/microedition/m3g/KeyframeSequence", "getKeyframe", "(I[F)I", native_keyframesequence_getKeyframe},
        {"javax/microedition/m3g/KeyframeSequence", "setValidRange", "(II)V", native_keyframesequence_setValidRange},
        {"javax/microedition/m3g/KeyframeSequence", "getValidRangeFirst", "()I", native_keyframesequence_getValidRangeFirst},
        {"javax/microedition/m3g/KeyframeSequence", "getValidRangeLast", "()I", native_keyframesequence_getValidRangeLast},
        
        /* Object3D animation */
        {"javax/microedition/m3g/Object3D", "animate", "(I)I", native_object3d_animate},
        {"javax/microedition/m3g/Object3D", "addAnimationTrack", "(Ljavax/microedition/m3g/AnimationTrack;)V", native_object3d_addAnimationTrack},
        /* v14: some JSR-184 stub libraries (incl. the one M3GTest was built
         * against) declare addAnimationTrack returning int — same handler. */
        {"javax/microedition/m3g/Object3D", "addAnimationTrack", "(Ljavax/microedition/m3g/AnimationTrack;)I", native_object3d_addAnimationTrack},
        {"javax/microedition/m3g/Object3D", "removeAnimationTrack", "(Ljavax/microedition/m3g/AnimationTrack;)V", native_object3d_removeAnimationTrack},
        {"javax/microedition/m3g/Object3D", "getAnimationTrackCount", "()I", native_object3d_getAnimationTrackCount},
        {"javax/microedition/m3g/Object3D", "getAnimationTrack", "(I)Ljavax/microedition/m3g/AnimationTrack;", native_object3d_getAnimationTrack},
        /* v12: JSR-184 scene-graph traversal (SU-30 uses it) */
        {"javax/microedition/m3g/Object3D", "getReferences", "([Ljavax/microedition/m3g/Object3D;)I", native_object3d_getReferences},
        
        /* Sprite3D */
        {"javax/microedition/m3g/Sprite3D", "<init>", "(ZLjavax/microedition/m3g/Image2D;Ljavax/microedition/m3g/Appearance;)V", native_sprite3d_init},
        {"javax/microedition/m3g/Sprite3D", "setImage", "(Ljavax/microedition/m3g/Image2D;)V", native_sprite3d_setImage},
        /* v12: full Sprite3D accessors — getImage() was missing entirely and
         * games NPE'd on getImage().getWidth() (SU-30); init/setImage were
         * empty stubs that dropped the image. */
        {"javax/microedition/m3g/Sprite3D", "getImage", "()Ljavax/microedition/m3g/Image2D;", native_sprite3d_getImage},
        {"javax/microedition/m3g/Sprite3D", "isScaled", "()Z", native_sprite3d_isScaled},
        {"javax/microedition/m3g/Sprite3D", "setScaled", "(Z)V", native_sprite3d_setScaled},
        {"javax/microedition/m3g/Sprite3D", "setCrop", "(IIII)V", native_sprite3d_setCrop},
        {"javax/microedition/m3g/Sprite3D", "getCropX", "()I", native_sprite3d_getCropX},
        {"javax/microedition/m3g/Sprite3D", "getCropY", "()I", native_sprite3d_getCropY},
        {"javax/microedition/m3g/Sprite3D", "getCropWidth", "()I", native_sprite3d_getCropWidth},
        {"javax/microedition/m3g/Sprite3D", "getCropHeight", "()I", native_sprite3d_getCropHeight},
    };
    
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    
    /* Register stub classes */
    init_m3g_stub_classes(jvm);
    
    GFX_DEBUG("Registered %zu native methods for JSR 184", 
            sizeof(methods) / sizeof(methods[0]));
}
