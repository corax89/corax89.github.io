/* c4.js — точный порт компилятора c4 для JavaScript/браузера.
 * Логика парсинга и генерации байт-кода полностью синхронизирована с 
 * предоставленным C-кодом (порт для N2600-OS, Robert Swierczek).
 */

const OP = {
    LEA:0, IMM:1, JMP:2, JSR:3, BZ:4, BNZ:5, ENT:6, ADJ:7, LEV:8,
    LI:9, LC:10, SI:11, SC:12, PSH:13,
    OR:14, XOR:15, AND:16, EQ:17, NE:18, LT:19, GT:20, LE:21, GE:22,
    SHL:23, SHR:24, ADD:25, SUB:26, MUL:27, DIV:28, MOD:29,
    OPEN:30, READ:31, CLOS:32, PRTF:33, MALC:34, FREE:35, MSET:36, MCMP:37, EXIT:38,
    KINIT:39, KQUIT:40, KDELAY:41, KFILL:42, KTEXT:43, KFLIP:44, KRGB:45,
    KEVENT:46, KCLEAR:47, KW:48, KH:49, KMTIME:50,
    STRLEN:51, STRCPY:52, STRCMP:53
};

const TK = {
    Num:128, Fun:129, Sys:130, Glo:131, Loc:132, Id:133,
    Char:134, Else:135, Enum:136, If:137, Int:138, Return:139, Sizeof:140, While:141,
    For:142, Do:143, Break:144, Continue:145,
    Assign:146, Cond:147, Lor:148, Lan:149, Or:150, Xor:151, And:152, Eq:153, Ne:154,
    Lt:155, Gt:156, Le:157, Ge:158, Shl:159, Shr:160, Add:161, Sub:162, Mul:163, Div:164, Mod:165,
    Inc:166, Dec:167, Brak:168
};

class C4Compiler {
    constructor() {
        this.src = "";
        this.p = 0;
        this.line = 1;
        this.tk = 0;
        this.ival = 0;
        this.ty = 0;
        this.text = [0]; 
        this.data = [];
        this.sym = [];
        this.symNameMap = {};
        this.idIdx = -1;
        this.loc = 0;
        
        this.breakFixups = [];
        this.contFixups = [];
        this.loopDepth = 0;
        this.breakSave = [];
        this.contSave = [];
    }

    getSym(field) { return this.sym[this.idIdx + field]; }
    setSym(field, val) { this.sym[this.idIdx + field] = val; }

    emit(op, arg) {
        this.text.push(op);
        if (arg !== undefined) this.text.push(arg);
    }

    next() {
        while (this.p < this.src.length) {
            let c = this.src[this.p];
            if (c === '\n') { this.line++; this.p++; continue; }
            if (c === ' ' || c === '\t' || c === '\r') { this.p++; continue; }
            
            if (c === '#') {
                if (this.src.startsWith('define ', this.p + 1)) {
                    this.p += 8;
                    while (this.p < this.src.length && ' \t'.includes(this.src[this.p])) this.p++;
                    let dp = this.p;
                    let dh = 0;
                    while (this.p < this.src.length && /[a-zA-Z0-9_]/.test(this.src[this.p])) {
                        dh = dh * 147 + this.src.charCodeAt(this.p);
                        this.p++;
                    }
                    dh = (dh << 6) + (this.p - dp);
                    let dlen = this.p - dp;
                    
                    while (this.p < this.src.length && ' \t'.includes(this.src[this.p])) this.p++;
                    let dv = 0, dsign = 1;
                    if (this.p < this.src.length && this.src[this.p] === '-') { dsign = -1; this.p++; }
                    while (this.p < this.src.length && /[0-9]/.test(this.src[this.p])) {
                        dv = dv * 10 + (this.src.charCodeAt(this.p) - 48);
                        this.p++;
                    }
                    dv *= dsign;
                    
                    this.idIdx = -1;
                    for (let i = 0; i < this.sym.length; i += 10) {
                        if (this.sym[i] !== 0) {
                            if (dh === this.sym[i+1]) {
                                let symName = this.symNameMap[this.sym[i+2]] || "";
                                if (symName === this.src.substring(dp, dp + dlen)) {
                                    this.sym[i] = TK.Num;
                                    this.sym[i+3] = 1; 
                                    this.sym[i+4] = 1; 
                                    this.sym[i+5] = dv;
                                    this.idIdx = i;
                                    break;
                                }
                            }
                        }
                    }
                    if (this.idIdx === -1) {
                        let nameStr = this.src.substring(dp, dp + dlen);
                        this.symNameMap[nameStr] = nameStr;
                        this.idIdx = this.sym.length;
                        this.sym.push(TK.Num, dh, nameStr, 1, 1, dv, 0, 0, 0, 0);
                    }
                    while (this.p < this.src.length && this.src[this.p] !== '\n') this.p++;
                    continue;
                }
                while (this.p < this.src.length && this.src[this.p] !== '\n') this.p++;
                continue;
            }
            
            if (c === '/' && this.src[this.p+1] === '/') {
                while (this.p < this.src.length && this.src[this.p] !== '\n') this.p++;
                continue;
            }
            if (c === '/' && this.src[this.p+1] === '*') {
                this.p += 2;
                while (this.p < this.src.length) {
                    if (this.src[this.p] === '*' && this.src[this.p+1] === '/') { this.p += 2; break; }
                    if (this.src[this.p] === '\n') this.line++;
                    this.p++;
                }
                continue;
            }
            
            if (/[a-zA-Z_]/.test(c)) {
                let pp = this.p;
                let th = 0;
                while (this.p < this.src.length && /[a-zA-Z0-9_]/.test(this.src[this.p])) {
                    th = th * 147 + this.src.charCodeAt(this.p);
                    this.p++;
                }
                th = (th << 6) + (this.p - pp);
                let nameStr = this.src.substring(pp, this.p);

                this.idIdx = -1;
                for (let i = 0; i < this.sym.length; i += 10) {
                    if (this.sym[i] !== 0) {
                        if (th === this.sym[i+1]) {
                            let symName = this.symNameMap[this.sym[i+2]] || "";
                            if (symName === nameStr) {
                                this.tk = this.sym[i];
                                this.idIdx = i;
                                if (this.tk === TK.Num) this.ival = this.sym[i+5];
                                return;
                            }
                        }
                    }
                }
                this.symNameMap[nameStr] = nameStr;
                this.idIdx = this.sym.length;
                this.sym.push(TK.Id, th, nameStr, 0, 0, 0, 0, 0, 0, 0);
                this.tk = TK.Id;
                return;
            }
            
            if (/[0-9]/.test(c)) {
                this.ival = c.charCodeAt(0) - 48;
                this.p++;
                if (this.ival > 0) {
                    while (this.p < this.src.length && /[0-9]/.test(this.src[this.p])) {
                        this.ival = this.ival * 10 + (this.src.charCodeAt(this.p) - 48);
                        this.p++;
                    }
                } else if (this.p < this.src.length && (this.src[this.p] === 'x' || this.src[this.p] === 'X')) {
                    this.p++;
                    while (this.p < this.src.length && /[0-9a-fA-F]/.test(this.src[this.p])) {
                        let ch = this.src.charCodeAt(this.p);
                        let val = ch >= 97 ? ch - 87 : (ch >= 65 ? ch - 55 : ch - 48);
                        this.ival = this.ival * 16 + val;
                        this.p++;
                    }
                } else {
                    while (this.p < this.src.length && /[0-7]/.test(this.src[this.p])) {
                        this.ival = this.ival * 8 + (this.src.charCodeAt(this.p) - 48);
                        this.p++;
                    }
                }
                this.tk = TK.Num;
                return;
            }
            
            if (c === '"' || c === "'") {
                this.p++;
                let pp = this.data.length;
                while (this.p < this.src.length && this.src[this.p] !== c) {
                    let ival = this.src.charCodeAt(this.p++);
                    if (ival === 92) { 
                        ival = this.src.charCodeAt(this.p++);
                        if (ival === 110) ival = 10; 
                    }
                    if (c === '"') this.data.push(ival);
                }
                this.p++; 
                if (c === '"') {
                    this.data.push(0);
                    while (this.data.length % 4 !== 0) this.data.push(0);
                    this.ival = pp;
                    this.tk = 34; // Возвращаем '"' (34) как в оригинальном c4.c
                } else {
                    this.ival = this.data[pp] || 0;
                    this.tk = TK.Num;
                }
                return;
            }
            
            this.p++;
            let two = c + (this.src[this.p] || '');
            if (two === '==') { this.tk = TK.Eq; return; }
            if (two === '!=') { this.tk = TK.Ne; return; }
            if (two === '<=') { this.tk = TK.Le; return; }
            if (two === '>=') { this.tk = TK.Ge; return; }
            if (two === '<<') { this.tk = TK.Shl; return; }
            if (two === '>>') { this.tk = TK.Shr; return; }
            if (two === '&&') { this.tk = TK.Lan; return; }
            if (two === '||') { this.tk = TK.Lor; return; }
            if (two === '++') { this.tk = TK.Inc; return; }
            if (two === '--') { this.tk = TK.Dec; return; }
            
            if (c === '!') {
                if (this.src[this.p] === '=') { this.p++; this.tk = TK.Ne; return; }
                this.tk = 33; return;
            }
            if (c === '~') { this.tk = 126; return; }
            
            const map = {'=':TK.Assign,'?':TK.Cond,'|':TK.Or,'^':TK.Xor,'&':TK.And,
                '<':TK.Lt,'>':TK.Gt,'+':TK.Add,'-':TK.Sub,'*':TK.Mul,
                '/':TK.Div,'%':TK.Mod,'[':TK.Brak,'(':171,')':172,
                ']':173,',':174,';':175,'{':176,'}':177,':':179};
            if (map[c] !== undefined) { this.tk = map[c]; return; }
        }
        this.tk = 0;
    }

    static get CHAR() { return 0; }
    static get INT() { return 1; }
    static get PTR() { return 2; }
    static get ARR() { return 0x80; }

    expr(lev) {
        let t;
        if (!this.tk) throw new Error(`${this.line}: unexpected eof in expression`);
        
        if (this.tk === TK.Num) {
            this.emit(OP.IMM, this.ival);
            this.next();
            this.ty = C4Compiler.INT;
        } else if (this.tk === 34) { // Строковый литерал '"'
            this.emit(OP.IMM, this.ival);
            this.next();
            while (this.tk === 34) this.next(); // Смежные строки
            this.ty = C4Compiler.PTR;
        } else if (this.tk === TK.Sizeof) {
            this.next();
            if (this.tk === 171) this.next();
            this.ty = C4Compiler.INT;
            if (this.tk === TK.Int) this.next();
            else if (this.tk === TK.Char) { this.next(); this.ty = C4Compiler.CHAR; }
            while (this.tk === TK.Mul) { this.next(); this.ty += C4Compiler.PTR; }
            if (this.tk === 172) this.next();
            this.emit(OP.IMM, this.ty === C4Compiler.CHAR ? 1 : 4);
            this.ty = C4Compiler.INT;
        } else if (this.tk === TK.Id) {
            let dIdx = this.idIdx;
            this.next();
            if (this.tk === 171) {
                this.next();
                t = 0;
                while (this.tk !== 172) {
                    this.expr(TK.Assign);
                    this.emit(OP.PSH);
                    t++;
                    if (this.tk === 174) this.next();
                }
                this.next();
                if (this.getSym(3) === 130) {
                    this.emit(this.getSym(5));
                } else if (this.getSym(3) === 129) {
                    this.emit(OP.JSR, this.getSym(5));
                } else {
                    throw new Error(`${this.line}: bad function call`);
                }
                if (t) { this.emit(OP.ADJ, t); }
                this.ty = this.getSym(4);
            } else if (this.getSym(3) === 128) {
                this.emit(OP.IMM, this.getSym(5));
                this.ty = C4Compiler.INT;
            } else {
                if (this.getSym(3) === 132) {
                    this.emit(OP.LEA, this.loc - this.getSym(5));
                } else if (this.getSym(3) === 131) {
                    this.emit(OP.IMM, this.getSym(5));
                } else {
                    throw new Error(`${this.line}: undefined variable`);
                }
                if (this.getSym(4) & C4Compiler.ARR) {
                    this.ty = (this.getSym(4) & ~C4Compiler.ARR) + C4Compiler.PTR;
                } else {
                    this.ty = this.getSym(4);
                    this.emit(this.ty === C4Compiler.CHAR ? OP.LC : OP.LI);
                }
            }
        } else if (this.tk === 171) {
            this.next();
            if (this.tk === TK.Int || this.tk === TK.Char) {
                t = (this.tk === TK.Int) ? C4Compiler.INT : C4Compiler.CHAR;
                this.next();
                while (this.tk === TK.Mul) { this.next(); t += C4Compiler.PTR; }
                if (this.tk === 172) this.next();
                else throw new Error(`${this.line}: bad cast`);
                this.expr(TK.Inc);
                this.ty = t;
            } else {
                this.expr(TK.Assign);
                if (this.tk === 172) this.next();
                else throw new Error(`${this.line}: close paren expected`);
            }
        } else if (this.tk === TK.Mul) {
            this.next(); this.expr(TK.Inc);
            if (this.ty > C4Compiler.INT) this.ty -= C4Compiler.PTR;
            else throw new Error(`${this.line}: bad dereference`);
            this.emit(this.ty === C4Compiler.CHAR ? OP.LC : OP.LI);
        } else if (this.tk === TK.And) {
            this.next(); this.expr(TK.Inc);
            let last = this.text[this.text.length - 1];
            if (last === OP.LC || last === OP.LI) {
                this.text.pop();
            } else {
                throw new Error(`${this.line}: bad address-of`);
            }
            this.ty += C4Compiler.PTR;
        } else if (this.tk === 33) {
            this.next(); this.expr(TK.Inc);
            this.emit(OP.PSH);
            this.emit(OP.IMM, 0);
            this.emit(OP.EQ);
            this.ty = C4Compiler.INT;
        } else if (this.tk === 126) {
            this.next(); this.expr(TK.Inc);
            this.emit(OP.PSH);
            this.emit(OP.IMM, -1);
            this.emit(OP.XOR);
            this.ty = C4Compiler.INT;
        } else if (this.tk === TK.Add) {
            this.next(); this.expr(TK.Inc); this.ty = C4Compiler.INT;
        } else if (this.tk === TK.Sub) {
            this.next();
            if (this.tk === TK.Num) { this.emit(OP.IMM, -this.ival); this.next(); }
            else { this.emit(OP.IMM, -1); this.emit(OP.PSH); this.expr(TK.Inc); this.emit(OP.MUL); }
            this.ty = C4Compiler.INT;
        } else if (this.tk === TK.Inc || this.tk === TK.Dec) {
            let t_op = this.tk;
            this.next(); this.expr(TK.Inc);
            let last = this.text[this.text.length - 1];
            if (last === OP.LC) { this.text[this.text.length - 1] = OP.PSH; this.emit(OP.LC); }
            else if (last === OP.LI) { this.text[this.text.length - 1] = OP.PSH; this.emit(OP.LI); }
            else throw new Error(`${this.line}: bad lvalue in pre-increment`);
            this.emit(OP.PSH);
            this.emit(OP.IMM, this.ty > C4Compiler.PTR ? 4 : 1);
            this.emit(t_op === TK.Inc ? OP.ADD : OP.SUB);
            this.emit(this.ty === C4Compiler.CHAR ? OP.SC : OP.SI);
        } else if (this.tk === TK.Brak) {
            this.next();
            this.emit(OP.PSH);
            this.expr(TK.Assign);
            if (this.tk === 173) this.next();
            else throw new Error(`${this.line}: close bracket expected`);
            
            if (t > C4Compiler.PTR) {
                this.emit(OP.PSH);
                this.emit(OP.IMM, 4);
                this.emit(OP.MUL);
                this.emit(OP.ADD);
                this.ty = t - C4Compiler.PTR;
                this.emit(this.ty === C4Compiler.CHAR ? OP.LC : OP.LI);
            } else if (t === C4Compiler.PTR) {
                this.emit(OP.ADD);
                this.ty = C4Compiler.INT;
                this.emit(this.ty === C4Compiler.CHAR ? OP.LC : OP.LI);
            } else {
                throw new Error(`${this.line}: can't index subptr`);
            }
        } else {
            throw new Error(`${this.line}: bad expression (unexpected token ${this.tk})`);
        }

        while (this.tk >= lev) {
            t = this.ty;
            if (this.tk === TK.Assign) {
                this.next();
                let last = this.text[this.text.length - 1];
                if (last === OP.LC || last === OP.LI) {
                    this.text[this.text.length - 1] = OP.PSH;
                } else {
                    throw new Error(`${this.line}: bad lvalue in assignment`);
                }
                this.expr(TK.Assign);
                this.emit(this.ty === C4Compiler.CHAR ? OP.SC : OP.SI);
                this.ty = t;
            } else if (this.tk === TK.Cond) {
                this.next();
                this.emit(OP.BZ, 0);
                let d_idx = this.text.length - 1;
                this.expr(TK.Assign);
                if (this.tk === 179) this.next();
                else throw new Error(`${this.line}: conditional missing colon`);
                this.text[d_idx] = this.text.length + 2;
                this.emit(OP.JMP, 0);
                let d2_idx = this.text.length - 1;
                this.expr(TK.Cond);
                this.text[d2_idx] = this.text.length;
                this.ty = t;
            } else if (this.tk === TK.Lor) {
                this.next();
                this.emit(OP.BNZ, 0);
                let d_idx = this.text.length - 1;
                this.expr(TK.Lan);
                this.text[d_idx] = this.text.length;
                this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Lan) {
                this.next();
                this.emit(OP.BZ, 0);
                let d_idx = this.text.length - 1;
                this.expr(TK.Or);
                this.text[d_idx] = this.text.length;
                this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Or) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Xor); this.emit(OP.OR); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Xor) {
                this.next(); this.emit(OP.PSH); this.expr(TK.And); this.emit(OP.XOR); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.And) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Eq); this.emit(OP.AND); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Eq) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Lt); this.emit(OP.EQ); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Ne) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Lt); this.emit(OP.NE); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Lt) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Shl); this.emit(OP.LT); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Gt) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Shl); this.emit(OP.GT); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Le) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Shl); this.emit(OP.LE); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Ge) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Shl); this.emit(OP.GE); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Shl) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Add); this.emit(OP.SHL); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Shr) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Add); this.emit(OP.SHR); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Add) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Mul);
                if (t > C4Compiler.PTR) { this.emit(OP.PSH); this.emit(OP.IMM, 4); this.emit(OP.MUL); }
                this.emit(OP.ADD);
                this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Sub) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Mul);
                if (t === this.ty && this.ty > C4Compiler.INT) {
                    this.emit(OP.SUB); this.emit(OP.PSH); this.emit(OP.IMM, 4); this.emit(OP.DIV); this.ty = C4Compiler.INT;
                } else if (t > C4Compiler.PTR) {
                    this.emit(OP.PSH); this.emit(OP.IMM, 4); this.emit(OP.MUL); this.emit(OP.SUB);
                } else {
                    this.emit(OP.SUB);
                }
            } else if (this.tk === TK.Mul) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Inc); this.emit(OP.MUL); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Div) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Inc); this.emit(OP.DIV); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Mod) {
                this.next(); this.emit(OP.PSH); this.expr(TK.Inc); this.emit(OP.MOD); this.ty = C4Compiler.INT;
            } else if (this.tk === TK.Inc || this.tk === TK.Dec) {
                let last = this.text[this.text.length - 1];
                if (last === OP.LC) { this.text[this.text.length - 1] = OP.PSH; this.emit(OP.LC); }
                else if (last === OP.LI) { this.text[this.text.length - 1] = OP.PSH; this.emit(OP.LI); }
                else throw new Error(`${this.line}: bad lvalue in post-increment`);
                this.emit(OP.PSH);
                this.emit(OP.IMM, t > C4Compiler.PTR ? 4 : 1);
                this.emit(this.tk === TK.Inc ? OP.ADD : OP.SUB);
                this.emit(t === C4Compiler.CHAR ? OP.SC : OP.SI);
                this.next();
            } else {
                break;
            }
        }
    }

    stmt() {
        let a, b, c, d;
        if (this.tk === TK.If) {
            this.next();
            if (this.tk === 171) this.next(); else throw new Error(`${this.line}: open paren expected`);
            this.expr(TK.Assign);
            if (this.tk === 172) this.next(); else throw new Error(`${this.line}: close paren expected`);
            this.emit(OP.BZ, 0); b = this.text.length - 1;
            this.stmt();
            if (this.tk === TK.Else) {
                this.next();
                this.emit(OP.JMP, 0); a = this.text.length - 1;
                this.text[b] = this.text.length;
                this.stmt();
                this.text[a] = this.text.length;
            } else {
                this.text[b] = this.text.length;
            }
        } else if (this.tk === TK.While) {
            this.next();
            a = this.text.length + 1;
            if (this.tk === 171) this.next(); else throw new Error(`${this.line}: open paren expected`);
            this.expr(TK.Assign);
            if (this.tk === 172) this.next(); else throw new Error(`${this.line}: close paren expected`);
            this.emit(OP.BZ, 0); b = this.text.length - 1;
            this.pushLoop();
            this.stmt();
            this.patchContinue(a);
            this.emit(OP.JMP, a);
            this.text[b] = this.text.length;
            this.popLoop(this.text.length);
        } else if (this.tk === TK.For) {
            this.next();
            if (this.tk === 171) this.next(); else throw new Error(`${this.line}: open paren expected`);
            if (this.tk !== 175) this.expr(TK.Assign);
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
            
            a = this.text.length + 1;
            b = 0;
            if (this.tk !== 175) {
                this.expr(TK.Assign);
                this.emit(OP.BZ, 0);
                b = this.text.length - 1;
            }
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
            
            c = 0; d = 0;
            if (this.tk !== 172) {
                this.emit(OP.JMP, 0);
                d = this.text.length - 1;
                let c_addr = this.text.length + 1;
                this.expr(TK.Assign);
                this.emit(OP.JMP, a);
                this.text[d] = this.text.length;
                c = c_addr;
            }
            if (this.tk === 172) this.next(); else throw new Error(`${this.line}: close paren expected`);
            
            this.pushLoop();
            this.stmt();
            if (c) { this.emit(OP.JMP, c); }
            else { this.emit(OP.JMP, a); }
            
            if (b) this.text[b] = this.text.length;
            if (c) this.patchContinue(c); else this.patchContinue(a);
            this.popLoop(this.text.length);
        } else if (this.tk === TK.Do) {
            this.next();
            a = this.text.length + 1;
            this.pushLoop();
            this.stmt();
            this.patchContinue(a);
            if (this.tk === TK.While) this.next(); else throw new Error(`${this.line}: while expected`);
            if (this.tk === 171) this.next(); else throw new Error(`${this.line}: open paren expected`);
            this.expr(TK.Assign);
            if (this.tk === 172) this.next(); else throw new Error(`${this.line}: close paren expected`);
            this.emit(OP.BNZ, a);
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
            this.popLoop(this.text.length);
        } else if (this.tk === TK.Break) {
            this.next();
            this.emit(OP.JMP, 0);
            if (this.loopDepth > 0) {
                this.breakFixups.push(this.text.length - 1);
            }
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
        } else if (this.tk === TK.Continue) {
            this.next();
            this.emit(OP.JMP, 0);
            if (this.loopDepth > 0) {
                this.contFixups.push(this.text.length - 1);
            }
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
        } else if (this.tk === TK.Return) {
            this.next();
            if (this.tk !== 175) this.expr(TK.Assign);
            this.emit(OP.LEV);
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
        } else if (this.tk === 176) {
            this.next();
            while (this.tk !== 177) this.stmt();
            this.next();
        } else if (this.tk === 175) {
            this.next();
        } else {
            this.expr(TK.Assign);
            if (this.tk === 175) this.next(); else throw new Error(`${this.line}: semicolon expected`);
        }
    }

    pushLoop() {
        if (this.loopDepth >= 32) return;
        this.breakSave[this.loopDepth] = this.breakFixups.length;
        this.contSave[this.loopDepth] = this.contFixups.length;
        this.loopDepth++;
    }

    patchContinue(loopTop) {
        if (this.loopDepth === 0) return;
        for (let i = this.contSave[this.loopDepth - 1]; i < this.contFixups.length; i++) {
            this.text[this.contFixups[i]] = loopTop;
        }
    }

    popLoop(loopEnd) {
        if (this.loopDepth === 0) return;
        this.loopDepth--;
        for (let i = this.breakSave[this.loopDepth]; i < this.breakFixups.length; i++) {
            this.text[this.breakFixups[i]] = loopEnd;
        }
        this.breakFixups.length = this.breakSave[this.loopDepth];
        this.contFixups.length = this.contSave[this.loopDepth];
    }

    compile(src) {
        this.src = src;
        this.p = 0;
        this.line = 1;
        this.text = [0];
        this.data = [];
        this.sym = [];
        this.symNameMap = {};
        this.breakFixups = [];
        this.contFixups = [];
        this.loopDepth = 0;

        const calcHash = (name) => {
            let h = 0;
            for (let i = 0; i < name.length; i++) h = h * 147 + name.charCodeAt(i);
            return (h << 6) + name.length;
        };

        const keywords = [
            ['char', TK.Char], ['else', TK.Else], ['enum', TK.Enum], ['if', TK.If],
            ['int', TK.Int], ['return', TK.Return], ['sizeof', TK.Sizeof], ['while', TK.While],
            ['for', TK.For], ['do', TK.Do], ['break', TK.Break], ['continue', TK.Continue]
        ];
        for (let [name, tk] of keywords) {
            this.symNameMap[name] = name;
            this.sym.push(tk, calcHash(name), name, 0, 0, 0, 0, 0, 0, 0);
        }

        const syscalls = [
            ['printf', OP.PRTF], ['malloc', OP.MALC], ['free', OP.FREE],
            ['memset', OP.MSET], ['memcmp', OP.MCMP], ['exit', OP.EXIT],
            ['kinit', OP.KINIT], ['kquit', OP.KQUIT], ['kdelay', OP.KDELAY],
            ['kfill', OP.KFILL], ['ktext', OP.KTEXT], ['kflip', OP.KFLIP],
            ['krgb', OP.KRGB], ['kevent', OP.KEVENT], ['kclear', OP.KCLEAR],
            ['kw', OP.KW], ['kh', OP.KH], ['kmtime', OP.KMTIME],
            ['strlen', OP.STRLEN], ['strcpy', OP.STRCPY], ['strcmp', OP.STRCMP]
        ];
        for (let [name, val] of syscalls) {
            this.symNameMap[name] = name;
            this.sym.push(val, calcHash(name), name, 130, C4Compiler.INT, val, 0, 0, 0, 0);
        }

        this.symNameMap['void'] = 'void';
        this.sym.push(TK.Char, calcHash('void'), 'void', 0, 0, 0, 0, 0, 0, 0);
        
        this.symNameMap['main'] = 'main';
        this.sym.push(TK.Id, calcHash('main'), 'main', 0, 0, 0, 0, 0, 0, 0);
        let idmainIdx = this.sym.length - 10;

        this.next();

        let bt = C4Compiler.INT;
        let i = 0;

        while (this.tk) {
            bt = C4Compiler.INT;
            if (this.tk === TK.Int) { this.next(); }
            else if (this.tk === TK.Char) { this.next(); bt = C4Compiler.CHAR; }
            else if (this.tk === TK.Enum) {
                this.next();
                if (this.tk !== 176) this.next();
                if (this.tk === 176) {
                    this.next();
                    i = 0;
                    while (this.tk !== 177) {
                        if (this.tk !== TK.Id) throw new Error(`${this.line}: bad enum identifier`);
                        this.next();
                        if (this.tk === TK.Assign) {
                            this.next();
                            if (this.tk !== TK.Num) throw new Error(`${this.line}: bad enum initializer`);
                            i = this.ival;
                            this.next();
                        }
                        this.setSym(3, 128); 
                        this.setSym(4, C4Compiler.INT);
                        this.setSym(5, i++);
                        if (this.tk === 174) this.next();
                    }
                    this.next();
                }
            }
            
            while (this.tk !== 175 && this.tk !== 177) {
                let ty = bt;
                while (this.tk === TK.Mul) { this.next(); ty += C4Compiler.PTR; }
                if (this.tk !== TK.Id) throw new Error(`${this.line}: bad global declaration`);
                
                if (this.getSym(3) !== 0) throw new Error(`${this.line}: duplicate global definition`);

                this.next();
                this.setSym(4, ty);
                
                if (this.tk === 171) {
                    this.setSym(3, 129); 
                    this.setSym(5, this.text.length);
                    this.next();
                    i = 0;
                    while (this.tk !== 172) {
                        let pty = C4Compiler.INT;
                        if (this.tk === TK.Int) this.next();
                        else if (this.tk === TK.Char) { this.next(); pty = C4Compiler.CHAR; }
                        while (this.tk === TK.Mul) { this.next(); pty += C4Compiler.PTR; }
                        if (this.tk !== TK.Id) throw new Error(`${this.line}: bad parameter declaration`);
                        if (this.getSym(3) === 132) throw new Error(`${this.line}: duplicate parameter definition`);
                        
                        this.setSym(6, this.getSym(3)); 
                        this.setSym(3, 132); 
                        this.setSym(7, this.getSym(4)); 
                        this.setSym(4, pty); 
                        this.setSym(8, this.getSym(5)); 
                        this.setSym(5, i++); 
                        this.next();
                        if (this.tk === 174) this.next();
                    }
                    this.next();
                    if (this.tk !== 176) throw new Error(`${this.line}: bad function definition`);
                    this.loc = ++i;
                    this.next();
                    
                    while (this.tk === TK.Int || this.tk === TK.Char) {
                        let lbt = (this.tk === TK.Int) ? C4Compiler.INT : C4Compiler.CHAR;
                        this.next();
                        while (this.tk !== 175) {
                            let lty = lbt;
                            while (this.tk === TK.Mul) { this.next(); lty += C4Compiler.PTR; }
                            if (this.tk !== TK.Id) throw new Error(`${this.line}: bad local declaration`);
                            if (this.getSym(3) === 132) throw new Error(`${this.line}: duplicate local definition`);
                            
                            this.setSym(6, this.getSym(3));
                            this.setSym(3, 132);
                            this.setSym(7, this.getSym(4));
                            this.setSym(4, lty);
                            this.setSym(8, this.getSym(5));
                            this.setSym(5, ++i);
                            
                            let arrIdIdx = this.idIdx;
                            this.next();
                            
                            if (this.tk === TK.Brak) {
                                this.next();
                                if (this.tk === TK.Num) { i += this.ival - 1; this.next(); }
                                if (this.tk === 173) this.next();
                                this.sym[arrIdIdx + 4] = lty | C4Compiler.ARR;
                            }
                            
                            if (this.tk === TK.Assign) {
                                let offset = this.loc - i;
                                this.next();
                                this.emit(OP.LEA, offset);
                                this.expr(TK.Assign);
                                this.emit(OP.SI);
                            }
                            
                            if (this.tk === 174) this.next();
                        }
                        this.next();
                    }
                    
                    this.emit(OP.ENT, i - this.loc);
                    while (this.tk !== 177) this.stmt();
                    this.emit(OP.LEV);
                    
                    for (let j = 0; j < this.sym.length; j += 10) {
                        if (this.sym[j+3] === 132) {
                            this.sym[j+3] = this.sym[j+6];
                            this.sym[j+4] = this.sym[j+7];
                            this.sym[j+5] = this.sym[j+8];
                        }
                    }
                } else {
                    this.setSym(3, 131); 
                    this.setSym(5, this.data.length);
                    
                    let gloIdIdx = this.idIdx;
                    if (this.tk === TK.Brak) {
                        this.next();
                        if (this.tk === TK.Num) {
                            for (let j = 0; j < this.ival; j++) this.data.push(0);
                            this.next();
                        }
                        if (this.tk === 173) this.next();
                        this.sym[gloIdIdx + 4] = ty | C4Compiler.ARR;
                    } else {
                        this.data.push(0);
                    }
                }
                if (this.tk === 174) this.next();
            }
            this.next();
        }

        return {
            text: this.text,
            data: this.data,
            entry: this.sym[idmainIdx + 5]
        };
    }
}

if (typeof window !== 'undefined') {
    window.C4Compiler = C4Compiler;
    window.C4OP = OP;
}