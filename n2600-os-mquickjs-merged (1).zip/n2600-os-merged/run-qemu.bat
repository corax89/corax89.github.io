@echo off
rem N2600-OS: запуск в QEMU.
rem Нужен QEMU (https://qemu.weilnetz.de/w64/) — добавьте его bin в PATH.
where qemu-system-i386 >nul 2>nul || (
  echo [ОШИБКА] qemu-system-i386 не найден в PATH. Установите QEMU для Windows.
  exit /b 1
)
qemu-system-i386 -m 512 -cdrom prebuilt\os.iso -vga std -name N2600-OS
