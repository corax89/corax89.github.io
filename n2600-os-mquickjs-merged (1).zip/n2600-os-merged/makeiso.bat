@echo off
rem N2600-OS: сборка os.iso на Windows.
rem grub-mkimage/xorriso под Windows ставить неудобно, поэтому два пути:
rem
rem  1) РЕКОМЕНДУЕТСЯ: используйте готовый prebuilt\os.iso из архива.
rem
rem  2) Либо соберите ISO в WSL (Ubuntu):
rem       wsl bash -c "sudo apt install -y grub-pc-bin xorriso mtools && \
rem         cd /mnt/c/<путь-к-n2600-os> && sh makeiso.sh"
rem
rem  (этот файл — заглушка-подсказка, сборки тут не происходит)
echo Смотрите комментарии внутри makeiso.bat
exit /b 0
