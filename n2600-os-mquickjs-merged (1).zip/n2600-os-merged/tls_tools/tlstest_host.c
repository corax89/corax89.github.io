/* tlstest_host.c — хост-тест амальгамации bearssl.c (N2600-OS).
 *
 * Схема официального сэмпла BearSSL: br_sslio_* (внутри — корректный насос
 * engine<->socket). Сидер реализует br_prng_seeder_system — интерфейс,
 * который в ядре будет реализован поверх rdtsc/RTC.
 *
 * Использование: tlstest <host> <port> [servername]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "bearssl.h"
#include "ta_test.h"     /* TAs / TAs_NUM — сгенерировано brssl ta */

/* ---- сидер для движка (в ядре будет rdtsc-версия, интерфейс тот же) ---- */
static int
seeder_urandom(const br_prng_class **ctx)
{
	FILE *f = fopen("/dev/urandom", "rb");
	unsigned char tmp[32];
	size_t u;
	if (f == NULL) {
		return 0;
	}
	u = fread(tmp, 1, sizeof tmp, f);
	fclose(f);
	if (u != sizeof tmp) {
		return 0;
	}
	(*ctx)->update(ctx, tmp, sizeof tmp);
	return 1;
}

br_prng_seeder
br_prng_seeder_system(const char **name)
{
	if (name != NULL) {
		*name = "urandom";
	}
	return &seeder_urandom;
}

/* ---- TCP (POSIX) ---- */
static int
tcp_connect(const char *host, const char *port)
{
	struct addrinfo hints, *res = NULL;
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	int rc = getaddrinfo(host, port, &hints, &res);
	if (rc != 0 || res == NULL) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rc));
		return -1;
	}
	int fd = socket(res->ai_family, res->ai_socktype, 0);
	if (fd < 0) {
		perror("socket");
		return -1;
	}
	if (connect(fd, res->ai_addr, res->ai_addrlen) != 0) {
		perror("connect");
		close(fd);
		return -1;
	}
	freeaddrinfo(res);
	return fd;
}

static int
sock_read(void *ctx, unsigned char *buf, size_t len)
{
	for (;;) {
		ssize_t rlen = read(*(int *)ctx, buf, len);
		if (rlen <= 0) {
			if (rlen < 0 && errno == EINTR) {
				continue;
			}
			return -1;
		}
		return (int)rlen;
	}
}

static int
sock_write(void *ctx, const unsigned char *buf, size_t len)
{
	for (;;) {
		ssize_t wlen = write(*(int *)ctx, buf, len);
		if (wlen <= 0) {
			if (wlen < 0 && errno == EINTR) {
				continue;
			}
			return -1;
		}
		return (int)wlen;
	}
}

static const char *
err_name(unsigned err)
{
	switch (err) {
	case BR_ERR_OK: return "OK";
	case BR_ERR_IO: return "IO";
	case BR_ERR_BAD_PARAM: return "BAD_PARAM";
	case BR_ERR_BAD_STATE: return "BAD_STATE";
	case BR_ERR_UNSUPPORTED_VERSION: return "UNSUPPORTED_VERSION";
	case BR_ERR_BAD_CIPHER_SUITE: return "BAD_CIPHER_SUITE";
	case BR_ERR_LIMIT_EXCEEDED: return "LIMIT_EXCEEDED";
	case BR_ERR_BAD_MAC: return "BAD_MAC";
	case BR_ERR_NO_RANDOM: return "NO_RANDOM";
	case BR_ERR_UNEXPECTED: return "UNEXPECTED";
	case BR_ERR_TOO_LARGE: return "TOO_LARGE";
	case BR_ERR_BAD_SIGNATURE: return "BAD_SIGNATURE";
	case BR_ERR_INVALID_ALGORITHM: return "INVALID_ALGORITHM";
	case BR_ERR_X509_EXPIRED: return "X509_EXPIRED";
	case BR_ERR_X509_DN_MISMATCH: return "X509_DN_MISMATCH";
	case BR_ERR_X509_BAD_SERVER_NAME: return "X509_BAD_SERVER_NAME";
	case BR_ERR_X509_NOT_TRUSTED: return "X509_NOT_TRUSTED";
	case BR_ERR_X509_UNSUPPORTED: return "X509_UNSUPPORTED";
	case BR_ERR_X509_BAD_TIME: return "X509_BAD_TIME";
	case BR_ERR_X509_TRUNCATED: return "X509_TRUNCATED";
	default: return "?";
	}
}

int
main(int argc, char **argv)
{
	if (argc < 3) {
		fprintf(stderr, "use: %s <host> <port> [servername]\n", argv[0]);
		return 2;
	}
	const char *host = argv[1];
	const char *port = argv[2];
	const char *srvname = argc > 3 ? argv[3] : host;

	signal(SIGPIPE, SIG_IGN);

	int fd = tcp_connect(host, port);
	if (fd < 0) {
		return 2;
	}
	fprintf(stderr, "[t] TCP connected\n");

	br_ssl_client_context sc;
	br_x509_minimal_context xc;
	unsigned char iobuf[BR_SSL_BUFSIZE_BIDI];
	br_sslio_context ioc;

	br_ssl_client_init_full(&sc, &xc, TAs, TAs_NUM);
	br_ssl_engine_set_buffer(&sc.eng, iobuf, sizeof iobuf, 1);

	/* время для проверки сертификатов: дни от нулевой эры + секунды суток */
	time_t now = time(NULL);
	br_x509_minimal_set_time(&xc,
		(uint32_t)(now / 86400) + 719528,
		(uint32_t)(now % 86400));

	if (!br_ssl_client_reset(&sc, srvname, 0)) {
		fprintf(stderr, "[t] client_reset failed\n");
		return 2;
	}

	br_sslio_init(&ioc, &sc.eng, sock_read, &fd, sock_write, &fd);

	char reqbuf[512];
	snprintf(reqbuf, sizeof reqbuf,
		"GET / HTTP/1.0\r\n"
		"Host: %s\r\n"
		"User-Agent: N2600-TLS-test/1.0\r\n"
		"Connection: close\r\n\r\n",
		srvname);
	br_sslio_write_all(&ioc, reqbuf, strlen(reqbuf));
	br_sslio_flush(&ioc);

	/* рукопожатие к этому моменту уже прошло; узнаём параметры сессии */
	br_ssl_session_parameters sp;
	br_ssl_engine_get_session_parameters(&sc.eng, &sp);
	fprintf(stderr, "[t] HANDSHAKE OK: version=0x%04x suite=0x%04x\n",
		sp.version, sp.cipher_suite);

	static unsigned char resp[262144];
	size_t resp_len = 0;
	for (;;) {
		unsigned char tmp[4096];
		int rlen = br_sslio_read(&ioc, tmp, sizeof tmp);
		if (rlen < 0) {
			break;
		}
		if (resp_len + (size_t)rlen <= sizeof resp) {
			memcpy(resp + resp_len, tmp, (size_t)rlen);
			resp_len += (size_t)rlen;
		}
	}

	close(fd);
	if (br_ssl_engine_current_state(&sc.eng) == BR_SSL_CLOSED) {
		int err = br_ssl_engine_last_error(&sc.eng);
		fprintf(stderr, "[t] engine closed, err=%d (%s)\n", err, err_name((unsigned)err));
	} else {
		fprintf(stderr, "[t] socket closed without SSL termination\n");
	}

	if (resp_len > 0) {
		printf("%.*s", (int)(resp_len > 8192 ? 8192 : resp_len), (char *)resp);
		fprintf(stderr, "[t] decrypted %zu bytes total\n", resp_len);
		return 0;
	}
	return 1;
}
