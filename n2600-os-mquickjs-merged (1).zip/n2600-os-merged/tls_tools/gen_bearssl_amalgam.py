#!/usr/bin/env python3
# gen_bearssl_amalgam.py — сборка BearSSL 0.6 в ОДИН си-файл (bearssl.c + bearssl.h)
# для N2600-OS (32-bit x86, freestanding, без libc).
#
# Метод: компилируем все подходящие модули BearSSL в объектники, по nm строим
# карту "символ -> файл", берём транзитивное замыкание от точек входа TLS-клиента.
# Лишнее (TLS-сервер, client-certs, sysrng с /dev/urandom, декодер X.509 и т.п.)
# в замыкание не попадает.
#
# Результат:
#   out/bearssl.h  — все публичные заголовки в одном (порядок из inc/bearssl.h)
#   out/bearssl.c  — вся реализация одним файлом (config-пины + inner.h + модули)
import os, re, subprocess, sys, glob

BEAR = '/home/z/my-project/work/tls/bearssl-0.6'
OUT  = '/home/z/my-project/work/tls/out'
WORK = '/home/z/my-project/work/tls/objs'
os.makedirs(OUT, exist_ok=True)
os.makedirs(WORK, exist_ok=True)

# --- что НЕ включаем ---
BLACKLIST = {
    'src/settings.c',                    # интроспекция конфига, не нужна
    'src/rand/sysrng.c',                 # ОС-зависимый сидер; свой делаем в net_tls.c
    'src/rand/aesctr_drbg.c',            # не используется клиентом
    'src/ssl/ssl_hs_server.c',           # серверная часть TLS
    'src/ssl/ssl_server.c',
    'src/ssl/ssl_server_full_ec.c', 'src/ssl/ssl_server_full_rsa.c',
    'src/ssl/ssl_server_mine2c.c', 'src/ssl/ssl_server_mine2g.c',
    'src/ssl/ssl_server_minf2c.c', 'src/ssl/ssl_server_minf2g.c',
    'src/ssl/ssl_server_minr2g.c', 'src/ssl/ssl_server_minu2g.c',
    'src/ssl/ssl_server_minv2g.c',
    'src/ssl/ssl_scert_single_ec.c', 'src/ssl/ssl_scert_single_rsa.c',
    'src/ssl/ssl_ccert_single_ec.c', 'src/ssl/ssl_ccert_single_rsa.c',
    'src/ssl/ssl_keyexport.c',           # RFC 5705 key export, не нужен
    'src/ssl/ssl_lru.c',                 # кэш сессий не используем
    'src/x509/x509_decoder.c',           # полный ASN.1-декодер не нужен
    'src/x509/x509_knownkey.c',
}

# --- точки входа (вызовы из нашего кода интеграции) ---
ENTRY = [
    'br_ssl_client_init_full',
    'br_ssl_client_zero',
    'br_ssl_client_reset',
    'br_ssl_client_set_client_suites',
    'br_ssl_engine_set_buffer',
    'br_ssl_engine_inject_entropy',
    'br_ssl_engine_flush',
    'br_ssl_engine_close',
    'br_ssl_engine_last_error',
    'br_x509_minimal_zero',
    'br_x509_minimal_set_time',
    'br_sslio_init',
]

# --- пины конфигурации: ОДИНАКОВЫ для компиляции кандидатов и в амальгаме,
# чтобы замыкание точно соответствовало тому, на что будет ссылаться bearssl.c ---
PINS = {
    'BR_USE_UNIX_TIME': 0, 'BR_USE_WIN32_TIME': 0,
    'BR_USE_URANDOM': 0, 'BR_USE_WIN32_RAND': 0, 'BR_RDRAND': 0,
    'BR_AES_X86NI': 0, 'BR_SSE2': 0, 'BR_POWER8': 0,
    'BR_INT128': 0, 'BR_UMUL128': 0,
    'BR_64': 0,   # 32-битные пути: rsa i31, aes ct, ghash ctmul32
}
PIN_FLAGS = ' '.join(f'-D{k}={v}' for k, v in PINS.items())

# --- символы, предоставляемые СНАРУЖИ (наш код) или libc/libgcc ---
PROVIDED = ['br_prng_seeder_system']
IGNORE_RE = re.compile(r'^(?:'
    r'memcpy|memset|memmove|memcmp|memchr|strlen|strcmp|strncmp|strcpy|strncpy'
    r'|strcat|strchr|strstr|snprintf|abort'
    r'|__u?div(?:di)?3|__u?mod(?:di)?3|__muldi3|__udivmoddi4|__divmoddi4'
    r'|__stack_chk.*|__.*_chk|__x86.*|__libc.*|_GLOBAL__.*'
    r')$')

# --- порядок директорий в склейке (src/ecdsa нет: файлы ecdsa_* лежат в src/ec) ---
DIR_ORDER = ['codec', 'hash', 'hmac', 'kdf', 'rand', 'mac', 'aead',
             'symcipher', 'int', 'rsa', 'ec', 'ssl', 'x509']

def sh(cmd, **kw):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)
    return r.returncode, r.stdout, r.stderr

# 1) перечень кандидатов
cands = []
for path in sorted(glob.glob(BEAR + '/src/**/*.c', recursive=True)):
    rel = os.path.relpath(path, BEAR)
    if rel in BLACKLIST:
        continue
    cands.append(rel)
print(f'кандидатов: {len(cands)}')

# 2) компиляция в объектники (хост gcc; -DBR_* не задаём — пины в амальгаме)
objmap = {}   # rel -> obj path
for rel in cands:
    obj = os.path.join(WORK, rel.replace('/', '__') + '.o')
    rc, _, err = sh(f'gcc -c -O1 {PIN_FLAGS} -I{BEAR}/src -I{BEAR}/inc "{BEAR}/{rel}" -o "{obj}"')
    if rc != 0:
        print(f'[!] компиляция не удалась: {rel}\n{err[:800]}', file=sys.stderr)
        sys.exit(1)
    objmap[rel] = obj

# 3) карта символов
def nm_syms(obj):
    rc, out, _ = sh(f'nm "{obj}"')
    defined, undefined = set(), set()
    for line in out.splitlines():
        parts = line.split()
        if len(parts) == 2:          # формат «U имя» (без адреса)
            typ, name = parts
        elif len(parts) >= 3:        # формат «адрес T имя»
            typ, name = parts[1], parts[-1]
        else:
            continue
        if name in ('', '.hidden'): continue
        if typ == 'U':
            undefined.add(name)
        elif typ in 'TtDdBbRrVvWwGg':
            defined.add(name)
    return defined, undefined

defs = {}      # symbol -> rel
undefs = {}    # rel -> set(symbols)
for rel, obj in objmap.items():
    d, u = nm_syms(obj)
    for s in d:
        defs.setdefault(s, rel)
    undefs[rel] = u

# 4) замыкание
selected = set()
needed = list(ENTRY)
unresolved = set()
while needed:
    s = needed.pop()
    if not s.startswith('br_') and IGNORE_RE.match(s):
        continue
    if s in PROVIDED:
        continue
    rel = defs.get(s)
    if rel is None:
        unresolved.add(s)
        continue
    if rel in selected:
        continue
    selected.add(rel)
    needed.extend(undefs[rel])

print(f'выбрано файлов: {len(selected)} (из {len(cands)})')
if unresolved:
    print('[!] неразрешённые символы:', sorted(unresolved), file=sys.stderr)

# 5) сортировка выбранных по каталогам
def dirkey(rel):
    d = rel.split('/')[1]
    return (DIR_ORDER.index(d), rel) if d in DIR_ORDER else (99, rel)
ordered = sorted(selected, key=dirkey)

LIC = BEAR + '/LICENSE'
lic_txt = ''
try:
    with open(LIC) as f: lic_txt = f.read()
except OSError:
    lic_txt = '(см. LICENSE в исходниках BearSSL)'

# 6) bearssl.h — все публичные заголовки (порядок самодостаточный: перекрёстные
# include вырезаны; rand требует block, ssl требует x509)
HDR_ORDER = ['bearssl_hash.h','bearssl_hmac.h','bearssl_kdf.h','bearssl_prf.h',
             'bearssl_block.h','bearssl_rand.h','bearssl_aead.h','bearssl_rsa.h',
             'bearssl_ec.h','bearssl_x509.h','bearssl_ssl.h','bearssl_pem.h']
hdr = []
hdr.append('/* bearssl.h — ЕДИНЫЙ публичный заголовок BearSSL 0.6 (амальгамация).\n'
           ' * Сгенерировано scripts/gen_bearssl_amalgam.py из inc (все подзаголовки).\n'
           ' * Порядок подзаголовков — как в оригинальном inc/bearssl.h.\n'
           ' * Лицензия: MIT, (c) 2016-2020 Thomas Pornin — https://www.bearssl.org/\n'
           ' */\n')
hdr.append('#ifndef BEARSSL_AMALGAM_H\n#define BEARSSL_AMALGAM_H\n\n')
hdr.append('#include <stddef.h>\n#include <stdint.h>\n')
for h in HDR_ORDER:
    with open(f'{BEAR}/inc/{h}') as f:
        txt = f.read()
    # убираем собственные #include <...> (уже подключены выше) и защитный гард —
    # оставляем содержимое как есть, гард не мешает, но чистим включения
    txt = re.sub(r'#include\s+<(stddef|stdint|string)\.h>\s*\n', '', txt)
    # перекрёстные включения подзаголовков не нужны — всё уже в одном файле
    txt = re.sub(r'#include\s+"bearssl_[a-z0-9_]+\.h"\s*\n', '', txt)
    hdr.append(f'\n/* ==== {h} ==== */\n')
    hdr.append(txt)
hdr.append('\n#endif /* BEARSSL_AMALGAM_H */\n')
with open(f'{OUT}/bearssl.h', 'w') as f:
    f.write(''.join(hdr))

# 7) bearssl.c — вся реализация
#
# ВАЖНО: при склейке нескольких .c в ОДИН файл одноимённые файлово-локальные
# (static) сущности конфликтуют («conflicting types for 'K'» и т.п.).
# Проход ниже: находим top-level static-декларации в каждом файле, имена,
# встречающиеся в >= 2 файлах (или конфликтующие с внешними символами),
# переименовываем в каждом файле (по слову) с уникальным суффиксом.
C_KW = set('void char short int long unsigned signed const static inline struct union enum extern volatile typedef'.split())

def file_statics(text):
    """Имена top-level static-деклараций (column-0 'static')."""
    names = []
    for m in re.finditer(r'^static\b', text, re.M):
        seg = text[m.start():]
        nxt = re.search(r'[=;\[{(]', seg)
        if not nxt:
            continue
        head = seg[:nxt.start()]
        ids = [w for w in re.findall(r'[A-Za-z_][A-Za-z0-9_]*', head)
               if w not in C_KW]
        if ids:
            names.append(ids[-1])
    return names

def file_typedefs(text):
    """Имена top-level typedef'ов (column-0 'typedef').
    Учитывает фигурные скобки: 'typedef struct { ... } имя;' — имя после '}'."""
    names = []
    for m in re.finditer(r'^typedef\b', text, re.M):
        start = m.start()
        depth, end, last_brace = 0, -1, -1
        k = start
        while k < len(text):
            c = text[k]
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                last_brace = k
            elif c == ';' and depth <= 0:
                end = k
                break
            k += 1
        if end < 0:
            continue
        decl = text[start:end]
        # имя ищем после последней '}' (если была), иначе во всём decl
        scan_from = last_brace + 1 if last_brace > start else start
        tail = decl[scan_from - start:]
        last = None
        for im in re.finditer(r'[A-Za-z_][A-Za-z0-9_]*', tail):
            w = im.group(0)
            if w in C_KW:
                continue
            nxt = tail[im.end():].lstrip()[:1]
            if nxt == '(':
                continue
            last = w
        if last:
            names.append(last)
    return names

file_texts = {}
for rel in ordered:
    with open(f'{BEAR}/{rel}') as f:
        txt = f.read()
    txt = txt.replace('#include "inner.h"\n', '')
    txt = re.sub(r'#define BR_ENABLE_INTRINSICS\s+1\s*\n', '', txt)
    file_texts[rel] = txt

# внешние (не static) символы — из nm-карты
ext_names = set()
for s, r0 in defs.items():
    if r0 in selected:
        ext_names.add(s)

from collections import defaultdict
st_files = defaultdict(set)
for rel, txt in file_texts.items():
    for n in file_statics(txt) + file_typedefs(txt):
        st_files[n].add(rel)

rename = {}   # rel -> {old: new}
for n, files in st_files.items():
    collide = len(files) >= 2 or (n in ext_names and n in file_texts.get(next(iter(files)), ''))
    # статик в одном файле, но имя совпадает с внешним символом другого файла —
    # тоже конфликт в одном TU: переименовываем
    if len(files) == 1 and n in ext_names:
        collide = True
    if not collide:
        continue
    for k, rel in enumerate(sorted(files)):
        rename.setdefault(rel, {})[n] = f'{n}_am{k}'

n_ren = sum(len(v) for v in rename.values())
print(f'переименовано static-символов: {n_ren}')
for rel in ordered:
    for old, new in rename.get(rel, {}).items():
        file_texts[rel] = re.sub(rf'\b{re.escape(old)}\b', new, file_texts[rel])

# Макросы, определённые в файле, НЕ должны протекать в следующие файлы
# (в оригинале каждый .c — отдельная единица трансляции; при склейке
# «#define t1 6» из ec_prime_i31.c ломает locals t1/t2 в ecdsa-файле).
# В конце каждого файла выдаём #undef всех его top-level #define.
MACRO_RE = re.compile(r'^[ \t]*#[ \t]*define[ \t]+([A-Za-z_][A-Za-z0-9_]*)', re.M)
undef_tail = {}
for rel, txt in file_texts.items():
    names = []
    seen = set()
    for m in MACRO_RE.finditer(txt):
        n = m.group(1)
        if n not in seen:
            seen.add(n)
            names.append(n)
    if names:
        undef_tail[rel] = names
n_undef = sum(len(v) for v in undef_tail.values())
print(f'макросов под #undef в конце файлов: {n_undef}')
src = []
src.append('/* bearssl.c — BearSSL 0.6, собранный в ОДИН си-файл для N2600-OS.\n'
           ' * Сгенерировано scripts/gen_bearssl_amalgam.py (замыкание по символам\n'
           ' * от точек входа TLS-клиента; серверная часть и ОС-зависимый RNG удалены).\n'
           ' * Профиль: TLS 1.0-1.2 клиент, RSA (i31), ECDHE P-256/384, ECDSA,\n'
           ' * AES-CBC/GCM/CCM, ChaCha20-Poly1305, X.509 minimal validator.\n'
           ' * Freestanding: нужны только memcpy/memset/memmove/memcmp/strlen/memchr.\n'
           ' *\n'
           ' * Лицензия MIT, (c) 2016-2020 Thomas Pornin. Полный текст LICENSE —\n'
           ' * в исходном архиве bearssl-0.6.tar.gz (https://www.bearssl.org/).\n'
           ' */\n\n')
# пины конфигурации (как для ядра, так и для хост-теста — единообразно)
src.append('''/* ---- фиксированная конфигурация (пины; иначе inner.h автодетектит).
     ДОЛЖНЫ совпадать с пинами, которыми компилировались кандидаты при
     генерации замыкания (см. scripts/gen_bearssl_amalgam.py) ---- */
#define BR_USE_UNIX_TIME    0   /* время задаём сами: br_x509_minimal_set_time */
#define BR_USE_WIN32_TIME   0
#define BR_USE_URANDOM      0   /* сидер свой: br_prng_seeder_system */
#define BR_USE_WIN32_RAND   0
#define BR_RDRAND           0   /* Atom N2600 не умеет RDRAND */
#define BR_AES_X86NI        0   /* без SSE в ядре */
#define BR_SSE2             0
#define BR_POWER8           0
#define BR_INT128           0
#define BR_UMUL128          0
#define BR_64               0   /* 32-битные пути (как в ядре -m32) */

''')
with open(f'{BEAR}/src/inner.h') as f:
    inner = f.read()
inner = inner.replace('#include "config.h"\n', '/* config.h: пины заданы выше */\n')
# freestanding: limits.h тянет системные заголовки (г GCC -m32/Linux) —
# заменяем на единственный реально используемый макрос ULONG_MAX
inner = inner.replace('#include <limits.h>\n', '''/* limits.h заменён: нужен только ULONG_MAX (проверка разрядности long) */
#ifndef ULONG_MAX
#ifdef __LP64__
#define ULONG_MAX 0xFFFFFFFFFFFFFFFFUL
#else
#define ULONG_MAX 0xFFFFFFFFUL
#endif
#endif
''')
src.append('/* ==== src/inner.h (внутренний заголовок) ==== */\n')
src.append(inner)
src.append('\n')
for rel in ordered:
    src.append(f'\n/* ==== {rel} ==== */\n')
    src.append(file_texts[rel])
    if rel in undef_tail:
        src.append('\n/* — откат макросов этого файла (изоляция TU при склейке) — */\n')
        src.append(' '.join(f'#undef {n}\n' for n in undef_tail[rel]))
with open(f'{OUT}/bearssl.c', 'w') as f:
    f.write(''.join(src))

n_lines_c = sum(1 for _ in open(f'{OUT}/bearssl.c'))
n_lines_h = sum(1 for _ in open(f'{OUT}/bearssl.h'))
print(f'OK: {OUT}/bearssl.c  ({n_lines_c} строк)')
print(f'OK: {OUT}/bearssl.h  ({n_lines_h} строк)')
for rel in ordered:
    print('  +', rel)
