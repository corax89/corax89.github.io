#!/usr/bin/env python3
# gen_tls_anchors.py — сводный tls_anchors.h из roots/*.pem (brssl ta).
# Берёт тело якоря ИЗ вывода brssl (кривая EC/тип ключа уже правильные),
# переименовывает TA{n}_ -> TA{k}_ и собирает общий массив TAs[].
import subprocess, re, glob, os, sys

BEAR = '/home/z/my-project/work/tls/bearssl-0.6'
BRSSL = BEAR + '/build/brssl'
ROOTS = '/home/z/my-project/work/tls/roots'
OUT = '/home/z/my-project/work/tls/test/tls_anchors.h'

pems = sorted(p for p in glob.glob(ROOTS + '/*.pem')
              if os.path.basename(p) not in ('tmp.pem', 'cacert.pem'))
print('pem-файлов:', len(pems))

def extract_object(txt):
    """Из вывода 'brssl ta' достать ЕДИНСТВЕННЫЙ объект якоря { ... }.
    Глубина: 1 = сам массив TAs[n] = { ... }, 2 = объект якоря."""
    i = txt.index('TAs[')
    i = txt.index('{', i)          # открывающая скобка МАССИВА
    depth = 0
    obj_start = None
    for k in range(i, len(txt)):
        c = txt[k]
        if c == '{':
            depth += 1
            if depth == 2 and obj_start is None:
                obj_start = k
        elif c == '}':
            if depth == 2 and obj_start is not None:
                return txt[obj_start:k + 1]
            depth -= 1
            if depth == 0:
                break
    raise ValueError('объект якоря не найден')

def subj_of(pem):
    return subprocess.run(['openssl', 'x509', '-in', pem, '-noout', '-subject'],
                          capture_output=True, text=True).stdout.strip()

def key_info(pem):
    txt = subprocess.run(['openssl', 'x509', '-in', pem, '-noout', '-text'],
                         capture_output=True, text=True).stdout
    alg = (re.search(r'Public Key Algorithm:\s*(\S+)', txt) or [None, '?'])[1]
    bits = (re.search(r'Public-Key:\s*\((\d+)\)', txt) or [None, '?'])[1]
    return alg, bits

parts = []
parts.append('/* tls_anchors.h — доверенные корневые CA для N2600-OS.\n'
             ' * Формат: br_x509_trust_anchor (BearSSL). Сгенерировано\n'
             ' * scripts/gen_tls_anchors.py из корней Mozilla CA store (curl.se/ca)\n'
             ' * инструментом brssl ta. Тот же файл используется и хост-тестом.\n'
             ' *\n'
             ' * Добавление нового корня: сохранить PEM в work/tls/roots/, запустить\n'
             ' * python3 scripts/gen_tls_anchors.py, перенести файл в src/ ядра.\n'
             ' */\n'
             '#ifndef TLS_ANCHORS_H\n'
             '#define TLS_ANCHORS_H\n\n'
             '#include "bearssl.h"\n')

idx = 0
objects = []
subjects = []
for pem in pems:
    r = subprocess.run([BRSSL, 'ta', pem], capture_output=True, text=True)
    if r.returncode != 0:
        print('FAIL', pem, r.stderr[:200], file=sys.stderr)
        continue
    txt = re.sub(r'\bTA\d+_', f'TA{idx}_', r.stdout)
    obj = extract_object(txt)
    lines = [ln.strip() for ln in obj.splitlines() if ln.strip()]
    norm = '\n'.join('                ' + ln for ln in lines)
    # norm УЖЕ содержит скобки объекта { ... } — дополнительная обёртка не нужна
    alg, bits = key_info(pem)
    subj = subj_of(pem).replace('subject=', '')
    parts.append(f'\n/* ---- {subj} ({alg} {bits} bit) ---- */\n')
    # массивы данных якоря (DN/ключи)
    body = re.sub(r'static const br_x509_trust_anchor TAs\[\d*\] = \{.*?\};\s*', '', txt,
                  flags=re.S)
    body = re.sub(r'#define TAs_NUM.*\n', '', body)
    parts.append(body)
    objects.append(norm + ',')
    subjects.append(subj)
    idx += 1

parts.append('\n/* ---- сводный массив доверенных якорей ---- */\n')
parts.append('static const br_x509_trust_anchor TAs[] = {\n')
for o, s in zip(objects, subjects):
    parts.append(o + f'  /* {s[:70]} */\n')
parts.append('};\n\n')
parts.append('#define TAs_NUM   %d\n\n' % len(objects))
parts.append('#endif /* TLS_ANCHORS_H */\n')

with open(OUT, 'w') as f:
    f.write(''.join(parts))
print('OK:', OUT, 'якорей:', len(objects))
for i, s in enumerate(subjects):
    print(f'  TA{i}: {s[:75]}')
