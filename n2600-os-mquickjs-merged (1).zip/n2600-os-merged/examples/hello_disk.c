/* hello_disk.c — пример приложения, загружаемого с RAM-диска.
 *
 * Компилируется в flat-binary командой:
 *   i686-w64-mingw32-gcc -m32 -ffreestanding -nostdlib -fno-pic \
 *       -Wl,--oformat=binary -Wl,-Ttext=0x400000 \
 *       hello_disk.c -o hello.bin
 *
 * Затем в N2600-OS:
 *   ramwrite hello.bin <содержимое файла>
 *   run hello.bin
 *
 * Точка входа получает таблицу API ядра (kapi_t) первым аргументом.
 * В примере рисуем простое окно-приветствие в (50,50).
 */
#include "kapi.h"

void entry(kapi_t *k, void *win)
{
    (void)win;

    u32 bg   = k->fb_rgb(0x10, 0x40, 0x80);
    u32 fg   = k->fb_rgb(0xFF, 0xFF, 0xFF);
    u32 dim  = k->fb_rgb(0xC6, 0xCD, 0xD5);

    k->fb_fill_rect(50, 50, 300, 100, bg);
    k->fb_rect(50, 50, 300, 100, k->fb_rgb(0x3E, 0x7D, 0xBF));

    k->fb_text(60, 60, "Hello from disk!", fg, -1);
    k->fb_text(60, 80, "Loaded from RAMFS", dim, -1);
    k->fb_text(60, 96, "Runs in own task.", dim, -1);
    k->fb_text(60, 116, "Wait 3s...", dim, -1);

    for (volatile int i = 0; i < 300000; i++)
        k->task_yield();
}
