/* example.c4.c — пример программы для встроенного компилятора c4.
 *
 * Этот текст можно вставить в «Редактор C» и нажать F9.
 * c4 поддерживает: int/char/указатели, if/while/return, функции,
 * выражения, printf (%d %s %c %x), malloc/free/memset/memcmp/exit.
 *
 * Подмножество C НЕ поддерживает: for, struct, float, #include, #define,
 * многомерные массивы.
 */

int fib(int n) {
    if (n < 2) return n;
    return fib(n - 1) + fib(n - 2);
}

int main() {
    int i;
    printf("Fibonacci 1..10:\n");
    i = 1;
    while (i <= 10) {
        printf("fib(%d) = %d\n", i, fib(i));
        i = i + 1;
    }
    printf("Total = %d\n", fib(11));
    return 0;
}
