/* IMG.JS — картинки из QuickJS (порт IMG.CS с CMScript).
 *
 * Host-функции (см. mqjs_os.h):
 *   img_load(path)          -> дескриптор или -1 (RAM disk или http(s)://)
 *   img_w(id) / img_h(id)   -> размеры
 *   img_pixel(id,x,y)       -> 0xRRGGBB
 *   img_draw(id,x,y)        — в текущую цель fb (как fill_rect)
 *   img_draw_scaled(id,x,y,w,h)
 *   win_img(id,pic,x,y)     — картинка в окно
 *   win_img_scaled(id,pic,x,y,w,h)
 *   img_free(id)            — освободить
 *
 * Запуск: `js img.js` в терминале.
 */

var pic = img_load("LOGO.PNG");
if (pic < 0) {
    print("img_load(LOGO.PNG) не удался (файл есть в RAM disk?)");
} else {

print("LOGO.PNG:", img_w(pic) + "x" + img_h(pic));
print("пиксель (0,0):", img_pixel(pic, 0, 0));
print("пиксель (120,45):", img_pixel(pic, 120, 45));

/* окно с картинкой: оригинал + анимация билинейного масштаба */
var win = win_open("IMG.JS", 90, 70, 280, 170);
if (win >= 0) {
    var iw = img_w(pic);
    var ih = img_h(pic);
    for (var s = 60; s <= 240; s += 30) {
        if (!win_alive(win)) break;
        win_clear(win, get_color(24, 28, 36));
        win_img(win, pic, 12, 8);
        var dh = (s * ih / iw) | 0;
        win_img_scaled(win, pic, 12 + ((240 - s) / 2 | 0), 96 + ((48 - dh) / 2 | 0), s, dh);
        win_text(win, 12, 148, "масштаб: " + s + "px", get_color(200, 214, 228));
        win_update(win);
        delay(90);
    }
}

img_free(pic);
print("готово");
}
