/* apps_settings.c — приложение «Настройки» (сессия 11, переработано 12/15/27).
*
Сессия 27: вкладка «Сеть» ПЕРЕРАБОТАНА:
- исправлен баг «полос»: подсветка выделения рисовалась ПОВЕРХ текста
  строки (set_row_hl заливала прямоугольник после set_row) — строки
  приоритета/адаптеров «прятались» под цветной полосой; теперь выделение
  рисуется ПОД текстом (set_row_ex);
- добавлены настройки IP: режим DHCP/статический, поля IP/Маска/Шлюз/DNS
  (клик мыши — фокус, цифры/точка/Backspace — ввод, Enter/S — применить),
  сохранение в SETTINGS.CFG (netmode/ip/mask/gw/dns) и применение через
  netcfg_set_static() (netmon). Если DHCP молчит (например, в 86Box
  выбран режим «хаб» — он адреса не раздаёт), можно задать адрес вручную.
Сессия 15: ТРИ ВКЛАДКИ — «Сеть», «Диски», «Тема»:
Сеть: адаптеры/линк/приоритет/DHCP/WiFi + IP-настройки (см. выше);
Диски: накопители, формат FAT32 (режим — РАДИОБОКСЫ, получающие
клики мыши от WM — сессия 15);
Тема: цвет ОКОН / ТЕКСТА / ЗАГОЛОВКОВ (3 полосы по 32 современных цвета 
на выбор из палитры Material Design; клик = установить значение; применяется 
ко ВСЕМ приложениям сразу, сохраняется в THEME.CFG на RAM disk, автозагрузка 
при старте).
Новая вкладка [4] «Система» (настройки интерфейса, WM.CFG):
- чекбокс «Рисовать содержимое окна при перетаскивании» — выключенный
  даёт быстрый режим для медленных CPU (тело окна при перетаскивании
  заливается фоном, канвас возвращается при отпускании);
- чекбокс «Анимации (меню и разворачивание окон)».
Настройки сети сохраняются в RAM disk (SETTINGS.CFG), интерфейса — WM.CFG.
Клавиши: Tab / 1 / 2 / 3 / 4 — вкладки; Сеть: Up/Dn — выбор адаптера или
поля IP (когда поле в фокусе), цифры/точка/Backspace — ввод, Enter —
приоритет/применить, A — авто, R — DHCP, S — применить статику,
W/D — WiFi; Диски: F — формат, Q/P — режим, Enter — подтвердить,
Esc — отмена/выход; Тема: Up/Dn — выбор полосы, Left/Right — выбор
цвета, C — сброс; Система: D — содержимое при перетаскивании,
A — анимации.
Мышь: клики по вкладкам, строкам, полям IP, палитре, виджетам и чекбоксам.
*/
#include  "apps.h"
#include  "wm.h"
#include  "fb.h"
#include  "kbd.h"
#include  "mouse.h"
#include  "mem.h"
#include  "string.h"
#include  "net.h"
#include  "ne2000.h"
#include  "ath9k_wifi.h"
#include  "net_httpd.h"
#include  "disk.h"
#include  "fat32.h"
#include  "fat32_format.h"
#include  "ntfs.h"
#include  "kernel.h"
#include  "ramfs.h"
#include  "timer.h"
#include  "task.h"
#include  "iso9660.h"
extern void serial_puts(const char *s);
#include "usb_ehci.h"

#define SET_COLS     66
#define SET_ROW_H    18
#define SET_HDR_H    24
#define SET_TABS_H   26

typedef struct {
    int  tab;              /* 0 = Сеть, 1 = Диски, 2 = Тема */
    int  sel;              /* выбранная строка-адаптер */
    int  hover;            /* подсветка мыши */
    u32  dhcp_ticks;       /* мигание статуса DHCP */

    /* ---- Диски / форматирование ---- */
    int  confirm;          /* 1 = ждём подтверждение формата */
    int  deny;             /* 1 = формат запрещён (NTFS) — сообщение */
    int  fmt_full;         /* 0 = быстрое (оглавление), 1 = полное (очистка) */
    int  formatting;       /* 1 = формат идёт (рисуем прогресс) */
    int  fmt_done, fmt_total;
    int  fmt_last_result;  /* 0 = ок, <0 = ошибка, -100 = не было */
    char fmt_err[96];

    /* ---- Сессия 15: радиобоксы режима форматирования ---- */
    wm_widget_t fmt_w[2];

    /* ---- Сессия 15: вкладка «Тема» ---- */
    int  theme_sel;        /* выбранная полоса: 0..2 (окна/текст/заголовок) */
    int  theme_swatch;     /* выбранный цвет в палитре: 0..31 */

    /* ---- Сессия 27: IP-настройки (режим + поля) ---- */
    int  edit;             /* поле в фокусе: 0=IP 1=маска 2=шлюз 3=DNS,
                            * -1 = редактирование выключено */
    char f_ip[16], f_mask[16], f_gw[16], f_dns[16];
    int  net_st;           /* статус-строка: 0=подсказка 1=ок 2=ошибка */
    char net_err[96];

    /* кликабельные зоны (заполняются при отрисовке; тот же поток) */
    struct { int x, y, w, h, action; } hot[20];
    int  hot_n;

    /* Сессия 62: Y чекбокса веб-сервера (заполняется при отрисовке
     * вкладки «Сеть»; -1000 = ещё не рисовался — клики не ловить) */
    int  websrv_y;
} set_t;

/* действия кликов */
#define ACT_TAB_NET   0
#define ACT_TAB_DISK  1
#define ACT_AUTO      2
#define ACT_DHCP      3
#define ACT_WIFI_W    4
#define ACT_WIFI_D    5
#define ACT_THEME_RESET 6
#define ACT_TAB_SYS   7    /* вкладка [4] «Система» (настройки интерфейса) */
#define ACT_ADAPTER   8    /* + индекс */
#define ACT_FMT       20
#define ACT_FMT_YES   21
#define ACT_FMT_NO    22
#define ACT_NET_DHCP   30  /* сессия 27: режим DHCP (клик по строке) */
#define ACT_NET_STATIC 31  /* сессия 27: применить статический IP */
#define ACT_NET_FIELD  32  /* сессия 27: фокус в поле + 0..3 */
#define ACT_WEBSRV     40  /* сессия 58: галочка веб-сервера (:80, /www); НЕ 33 — конфликт с ACT_NET_FIELD+1 */

/* ============ сохранение настроек (RAM disk SETTINGS.CFG) ============ */
#define SETTINGS_FILE "SETTINGS.CFG"
/* Сессия 27: один файл для ВСЕХ сетевых настроек — приоритет адаптера
 * (сессия 11) + режим IP и статические адреса (сессия 27). Файл
 * перезаписывается целиком при любом изменении. */
static void settings_net_save(int adapter_mode /* 0=auto, 1..N=manual */)
{
    if (!ramfs_ready()) return;
    char buf[224];
    int L;
    if (adapter_mode == 0)
        L = snprintf(buf, sizeof(buf), "adapter=auto\n");
    else
        L = snprintf(buf, sizeof(buf), "adapter=%s\n",
                     net_adapter_name(adapter_mode - 1));
    u32 ip, mask, gw, dns;
    netcfg_static_get(&ip, &mask, &gw, &dns);
    if (L > 0 && L < (int)sizeof(buf))
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "netmode=%s\n",
                      netcfg_static_mode() ? "static" : "dhcp");
    char a[16];
    if (ip   && L < (int)sizeof(buf)) {
        net_ntoa(ip, a, sizeof(a));
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "ip=%s\n", a);
    }
    if (mask && L < (int)sizeof(buf)) {
        net_ntoa(mask, a, sizeof(a));
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "mask=%s\n", a);
    }
    if (gw   && L < (int)sizeof(buf)) {
        net_ntoa(gw, a, sizeof(a));
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "gw=%s\n", a);
    }
    if (dns  && L < (int)sizeof(buf)) {
        net_ntoa(dns, a, sizeof(a));
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "dns=%s\n", a);
    }
    /* Сессия 58: состояние веб-сервера (по умолчанию включён) */
    if (L > 0 && L < (int)sizeof(buf))
        L += snprintf(buf + L, sizeof(buf) - (u32)L, "httpd=%d\n",
                      net_httpd_wanted() ? 1 : 0);
    if (L <= 0 || L >= (int)sizeof(buf)) return;
    ramfs_delete(SETTINGS_FILE);
    if (ramfs_create(SETTINGS_FILE, (u32)L + 1))
        ramfs_write(SETTINGS_FILE, buf, (u32)L + 1);
}

/* ============ вспомогательная отрисовка ============ */
static void set_hot(set_t *d, int x, int y, int w, int h, int action)
{
    if (d->hot_n < 20) {
        d->hot[d->hot_n].x = x; d->hot[d->hot_n].y = y;
        d->hot[d->hot_n].w = w; d->hot[d->hot_n].h = h;
        d->hot[d->hot_n].action = action;
        d->hot_n++;
    }
}

/* Сессия 27: строка с ВЫДЕЛЕНИЕМ. Раньше (set_row_hl) подсветка
 * рисовалась ПОСЛЕ текста и закрывала строку сплошной полосой —
 * «настройки приоритета спрятаны за какими-то полосами». Теперь
 * заливка идёт ДО текста: полоса — фон, текст — поверх. */
static void set_row_ex(set_t *d, int y, int hot_action, int hl,
                       const char *left, const char *right,
                       u32 lcol, u32 rcol)
{
    int w = 62 * 8 + 8;
    if (hl)
        fb_fill_rect(2, y - 2, w, SET_ROW_H - 2, wm_theme_sel_bg());
    if (hot_action >= 0)
        set_hot(d, 2, y - 2, w, SET_ROW_H - 2, hot_action);
    fb_text(8, y, left, lcol, -1);
    int rw = (int)fb_text_w(right);   /* сессия 20: по СИМВОЛАМ, не по байтам */
    if (right[0])
        fb_text(8 + 62 * 8 - rw, y, right, rcol, -1);
}

static void set_row(set_t *d, int y, int hot_action, const char *left,
                    const char *right, u32 lcol, u32 rcol)
{
    set_row_ex(d, y, hot_action, 0, left, right, lcol, rcol);
}

static void fmt_human_size(u64 sectors, char *out, int max)
{
    u64 mib = sectors / 2048u;
    if (mib >= 1024u * 100u)
        snprintf(out, (u32)max, "%u ГиБ", (unsigned)(mib / 1024u));
    else
        snprintf(out, (u32)max, "%u МиБ", (unsigned)mib);
}

/* ============ вкладка «Диски» ============ */
#define FMT_BOX_H 96

static int set_fmt_box_y(void)
{
    int y = SET_TABS_H + 4;
    y += 15;
    y += 15;
    int np = disk_part_count();
    int plines = (np > 0) ? (np < 8 ? np : 8) : 1;
    y += plines * 15;
    return y + 8 - 4;
}

static int set_disk_has_ntfs(void)
{
    if (ntfs_ready()) return 1;
    int np = disk_part_count();
    for (int i = 0; i < np; i++) {
        if (disk_part(i)->type == 0x07) return 1;
        if (strcmp(disk_part_fstype(i), "NTFS") == 0) return 1;
    }
    return 0;
}

static void draw_disk_tab(window_t *w, set_t *d)
{
    int cw = win_content_w(w);
    char line[160];
    int y = SET_TABS_H + 4;

    if (disk_hdd_present()) {
        char sz[24];
        fmt_human_size(disk_hdd_sectors(), sz, sizeof(sz));
        const char *fs = fat32_ready() ? "FAT32" : (ntfs_ready() ? "NTFS" : NULL);
        snprintf(line, sizeof(line), "НЖМД [%s]: %s (%s)",
                 disk_hdd_bus(), disk_hdd_model(), sz);
        fb_text(8, y, line, wm_theme_text(), -1);
        y += 15;
        snprintf(line, sizeof(line), "ФС: %s%s",
                 fs ? fs : "не распознана",
                 sata_pending() ? "  (инициализация...)" :
                 (fs ? "  [доступна]" : "  [нет поддерживаемой]"));
        fb_text(8, y, line,
                fs ? fb_rgb(0x90, 0xEE, 0x90) : fb_rgb(0xE0, 0x9A, 0x9A), -1);
        y += 15;

        int np = disk_part_count();
        if (np > 0) {
            for (int i = 0; i < np && i < 8; i++) {
                const disk_part_t *p = disk_part(i);
                char psz[24];
                fmt_human_size(p->nsectors, psz, sizeof(psz));
                snprintf(line, sizeof(line), "  раздел %d%s: %s %s  LBA %u",
                         i + 1, p->gpt ? " (GPT)" : "",
                         disk_part_fstype(i)[0] ? disk_part_fstype(i) : "?",
                         psz, (unsigned)p->start_lba);
                if (p->label[0]) {
                    char tmp[160];
                    snprintf(tmp, sizeof(tmp), "%s \"%s\"", line, p->label);
                    snprintf(line, sizeof(line), "%s", tmp);
                }
                fb_text(8, y, line, wm_theme_text_dim(), -1);
                y += 15;
            }
        } else {
            fb_text(8, y, "  разделов MBR нет (весь диск — одна ФС)",
                    wm_theme_text_dim(), -1);
            y += 15;
        }

        y += 8;
        if (d->formatting) {
            fb_text(8, y, "Форматирование...", fb_rgb(0xFF, 0xC0, 0x40), -1);
            y += SET_ROW_H;
        } else if (d->deny) {
            int bw = cw - 16;
            int by = set_fmt_box_y();
            fb_fill_rect(6, by, bw, FMT_BOX_H, fb_rgb(0x40, 0x14, 0x14));
            fb_rect(6, by, bw, FMT_BOX_H, fb_rgb(0xE0, 0x50, 0x50));
            fb_text(14, by + 8, "Форматирование ЗАПРЕЩЕНО:",
                    fb_rgb(0xFF, 0x90, 0x90), -1);
            fb_text(14, by + 24, "на этом диске есть NTFS (Windows).",
                    fb_rgb(0xE0, 0xA0, 0xA0), -1);
            fb_text(14, by + 40, "NTFS-разделы защищены от удаления;",
                    fb_rgb(0xE0, 0xA0, 0xA0), -1);
            fb_text(14, by + 56, "Esc — закрыть",
                    wm_theme_text(), -1);
            y = by + FMT_BOX_H + 4;
        } else if (d->confirm) {
            int bw = cw - 16;
            int by = set_fmt_box_y();
            fb_fill_rect(6, by, bw, FMT_BOX_H, fb_rgb(0x40, 0x14, 0x14));
            fb_rect(6, by, bw, FMT_BOX_H, fb_rgb(0xE0, 0x50, 0x50));
            fb_text(14, by + 8, "ВНИМАНИЕ! Форматирование УДАЛИТ ВСЕ ДАННЫЕ",
                    fb_rgb(0xFF, 0x90, 0x90), -1);
            fb_text(14, by + 24, "на диске (разделы, файлы, Windows — всё).",
                    fb_rgb(0xE0, 0xA0, 0xA0), -1);

            d->fmt_w[0].x = 20;  d->fmt_w[0].y = by + 42;
            d->fmt_w[1].x = 300; d->fmt_w[1].y = by + 42;
            wm_widgets_draw(w);
            snprintf(line, sizeof(line), "Выбрано: %s", d->fmt_full
                     ? "ПОЛНОЕ — структуры ФС + очистка всех данных нулями"
                     : "БЫСТРОЕ — только структуры ФС (данные не стираются)");
            fb_text(14, by + 64, line, fb_rgb(0x8A, 0xC8, 0xE8), -1);
            fb_text(14, by + 80, "Enter — ДА, форматировать    Esc — отмена",
                    wm_theme_text(), -1);
            set_hot(d, 6, by + 76, bw / 2 - 10, 18, ACT_FMT_YES);
            set_hot(d, 6 + bw / 2, by + 76, bw / 2 - 10, 18, ACT_FMT_NO);
            y = by + FMT_BOX_H + 4;
        } else {
            set_row(d, y, ACT_FMT, "[F] Форматировать диск в FAT32", "",
                    fb_rgb(0xE0, 0x9A, 0x9A), 0);
            y += SET_ROW_H;
            if (d->fmt_last_result == 0) {
                fb_text(8, y, "Форматирование завершено — FAT32 готова.",
                        fb_rgb(0x90, 0xEE, 0x90), -1);
                y += 15;
            } else if (d->fmt_last_result < 0 && d->fmt_last_result != -100) {
                snprintf(line, sizeof(line), "Ошибка формата: %s",
                         d->fmt_err[0] ? d->fmt_err : "запись не удалась");
                fb_text(8, y, line, fb_rgb(0xE0, 0x9A, 0x9A), -1);
                y += 15;
            }
        }
    } else {
        const char *st = sata_pending() ? "инициализация в фоне..." : "не найден";
        snprintf(line, sizeof(line), "НЖМД: %s", st);
        fb_text(8, y, line, wm_theme_text_dim(), -1);
        y += SET_ROW_H;
    }

    y += 8;
    fb_text(8, y, "Прочие накопители:", wm_theme_text_info(), -1);
    y += 15;
    snprintf(line, sizeof(line), "  CD: %s", disk_cd_present() ? "есть (ISO9660)" : "нет");
    fb_text(8, y, line, wm_theme_text(), -1);
    y += 15;
    {
        const char *ust = !usb_ehci_storage_ready() ? "нет"
            : (fat32_ready() && fat32_is_usb() ? "есть, FAT32" : "есть (ФС?)");
        snprintf(line, sizeof(line), "  USB: %s", ust);
        fb_text(8, y, line, wm_theme_text(), -1);
        y += 15;
    }
    snprintf(line, sizeof(line), "  RAM disk: %s",
             ramfs_ready() ? "готов" : "нет");
    fb_text(8, y, line, wm_theme_text(), -1);
}

/* ============ вкладка «Сеть» (сессия 27: IP-настройки) ============ */
#define SET_FIELD_H   16     /* высота строки поля IP */
static const char *set_fname[4] = { "IP", "Маска", "Шлюз", "DNS" };

/* Сессия 62: подпись чекбокса веб-сервера — ОДИН литерал для отрисовки
 * и hit-теста (как SET_OPTLBL_* в «Системе»; ширина зоны считается по
 * символам UTF-8 в wm_checkbox_hit). */
#define SET_NETLBL_WEBSRV "Веб-сервер файлов (:80, папка www)"

static char *set_field_buf(set_t *d, int i)
{
    char *fv[4] = { d->f_ip, d->f_mask, d->f_gw, d->f_dns };
    return fv[i];
}

static void draw_net_tab(window_t *w, set_t *d)
{
    int cw = win_content_w(w);
    char line[160];
    int y = SET_TABS_H + 4;
    fb_text(8, y, "Адреса:", wm_theme_text_info(), -1);
    y += 15;
    {
        char ipbuf[16];
        u32 ip = net_get_ip();
        if (ip)
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
        else
            strcpy(ipbuf, "нет");
        snprintf(line, sizeof(line), "IP: %s   DHCP: %s   TX %u / RX %u",
                 ipbuf,
                 netcfg_static_mode() ? "выкл (статика)"
                 : (net_dhcp_state() == DHCP_BOUND ? "BOUND" : "wait"),
                 (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
        fb_text(16, y, line, fb_rgb(0x8A, 0xC8, 0xE8), -1);
        y += SET_ROW_H;
    }
    /* Сессия 22: диагностика ne2000-кольца (состояние карточки, а не
     * стека). Если TX растёт, а RX=0 и pkts=0 — кадры не доходят от
     * эмулятора до карты (86Box: сеть отключена / null-драйвер / PCap
     * смотрит не в тот адаптер). Если pkts>0, а RX=0 — проблема в стеке. */
    if (ne2000_present()) {
        char ring[128];
        ne2000_diag(ring, (int) sizeof(ring));
        fb_text(16, y, ring, wm_theme_text_dim(), -1);
        y += SET_ROW_H;
    }

    /* --- Режим IP (сессия 27) --- */
    fb_text(8, y, "Режим IP:", wm_theme_text_info(), -1);
    y += 15;
    {
        int stat = netcfg_static_mode();
        set_row_ex(d, y, ACT_NET_DHCP, !stat,
                   "[R] DHCP (адрес от сервера/эмулятора)", "",
                   wm_theme_text(), 0);
        y += SET_ROW_H;
        set_row_ex(d, y, ACT_NET_STATIC, stat,
                   "[S] Статический — применить поля ниже", "",
                   wm_theme_text(), 0);
        y += SET_ROW_H;
    }

    /* --- поля статических адресов (клик — фокус, цифры — ввод) --- */
    for (int i = 0; i < 4; i++) {
        int focus = (d->edit == i);
        int bw = 13 * 8 + 8;             /* ширина окошка поля: "255.255.255.0" */
        int bx = 96;
        set_hot(d, 2, y - 2, cw - 6, SET_FIELD_H, ACT_NET_FIELD + i);
        snprintf(line, sizeof(line), "%s:", set_fname[i]);
        fb_text(16, y, line,
                focus ? wm_theme_text() : wm_theme_text_dim(), -1);
        if (focus)
            fb_fill_rect(bx - 3, y - 2, bw + 6, SET_FIELD_H,
                         wm_theme_sel_bg());
        fb_rect(bx - 3, y - 2, bw + 6, SET_FIELD_H,
                focus ? wm_theme_accent() : fb_rgb(0x2C, 0x31, 0x38));
        fb_text(bx, y, set_field_buf(d, i), fb_rgb(0x8A, 0xC8, 0xE8), -1);
        if (focus) {
            int tw = (int)fb_text_w(set_field_buf(d, i));
            fb_fill_rect(bx + tw + 2, y, 6, 10, wm_theme_text());
        }
        y += SET_FIELD_H;
    }

    /* статус применения / подсказка про эмулятор */
    {
        const char *hint =
            "DHCP молчит? 86Box: NIC -> SLiRP; хаб адреса не раздаёт";
        u32 col = wm_theme_text_dim();
        if (d->net_st == 1)      { hint = d->net_err; col = fb_rgb(0x90, 0xEE, 0x90); }
        else if (d->net_st == 2) { hint = d->net_err; col = fb_rgb(0xE0, 0x9A, 0x9A); }
        fb_text(8, y, hint, col, -1);
    }
    y += 15;

    y += 6;
    fb_text(8, y, "Приоритетный адаптер:", wm_theme_text_info(), -1);
    y += SET_ROW_H;
    {
        int manual = net_adapter_mode();
        char right[48];
        int any_link = 0;
        for (int i = 0; i < 5; i++)
            if (net_adapter_present(i) && net_adapter_link(i)) any_link = 1;
        snprintf(right, sizeof(right), "%s",
                 manual == 0 ? "<включён>" : (any_link ? "" : ""));
        /* сессия 27: set_row_ex — выделение ПОД текстом (раньше полоса
         * set_row_hl закрывала строку целиком) */
        set_row_ex(d, y, ACT_AUTO, manual == 0,
                   "[A] Авто (кабель > WiFi по линку)", right,
                   wm_theme_text(), fb_rgb(0x90, 0xEE, 0x90));
        y += SET_ROW_H;
    }

    int shown = 0;
    for (int i = 0; i < 5 && shown < 4; i++) {
        if (!net_adapter_present(i)) continue;
        const char *nm = net_adapter_name(i);
        int act = (net_adapter_active() == i);
        int link = net_adapter_link(i);
        char right[48];
        if (i == 4 && wifi_present()) {
            const char *st = wifi_conn_state_name();
            snprintf(right, sizeof(right), "%s%s", st,
                     act ? "  [АКТИВЕН]" : "");
        } else {
            snprintf(right, sizeof(right), "link: %s%s",
                     link ? "up" : "down", act ? "  [АКТИВЕН]" : "");
        }
        char left[48];
        snprintf(left, sizeof(left), "     %s", nm);
        set_row_ex(d, y, ACT_ADAPTER + i, d->sel == i, left, right,
                   act ? fb_rgb(0x90, 0xEE, 0x90) : wm_theme_text(),
                   act ? fb_rgb(0x90, 0xEE, 0x90) :
                         (link ? fb_rgb(0x8A, 0xC8, 0xE8) : fb_rgb(0xE0, 0x9A, 0x9A)));
        y += SET_ROW_H;
        shown++;
    }

    /* --- сессия 62: веб-сервер — ТАКИМ ЖЕ чекбоксом, как настройки
     * анимаций в «Системе» (wm_checkbox, компонент WM сессии 14).
     * Раньше была строка «[X] Веб-сервер…» через set_row_ex.
     * Галочка показывает ЖЕЛАЕМОЕ состояние (wanted, сохраняется в
     * SETTINGS.CFG), статус-строка — фактическое (running). */
    y += 4;
    d->websrv_y = y;
    wm_checkbox_draw(8, y, SET_NETLBL_WEBSRV,
                     net_httpd_wanted(), wm_theme_text());
    y += 20;
    snprintf(line, sizeof(line), "        Статус: %s",
             net_httpd_running() ? "работает (все интерфейсы)"
                                 : "остановлен");
    fb_text(8, y, line, wm_theme_text_dim(), -1);
    y += 15;

    y += 6;
    fb_fill_rect(0, y - 4, cw, SET_HDR_H, wm_theme_title());
    fb_text(8, y, "WIFI", wm_theme_text(), -1);
    y += SET_HDR_H;
    if (wifi_present()) {
        char prof[33];
        int has_prof = wifi_profile_load(prof, sizeof(prof));
        snprintf(line, sizeof(line), "%s: %s%s",
                 wifi_chip_name(),
                 wifi_conn_state_name(),
                 wifi_conn_ssid()[0] ? ": \"" : "");
        fb_text(8, y, line, wm_theme_text(), -1);
        if (wifi_conn_ssid()[0]) {
            snprintf(line, sizeof(line), "\"%s\"  ch %d  RSSI %d dBm%s",
                     wifi_conn_ssid(), wifi_conn_channel(), wifi_conn_rssi(),
                     wifi_conn_state() == WIFI_CONN_CONNECTED ? "" : " ...");
            fb_text(8, y += 15, line, fb_rgb(0x8A, 0xC8, 0xE8), -1);
        }
        snprintf(line, sizeof(line), "Профиль: %s%s",
                 has_prof ? prof : "(не задан)",
                 wifi_conn_secured() ? "  [WPA2]" : "");
        fb_text(8, y += 15, line, wm_theme_text_dim(), -1);
        y += SET_ROW_H - 15 + 6;
        if (has_prof) {
            set_row(d, y, ACT_WIFI_W, "[W] Переподключиться", "",
                    wm_theme_text(), 0);
            y += SET_ROW_H;
        }
        set_row(d, y, ACT_WIFI_D, "[D] Отключиться", "",
                wm_theme_text(), 0);
        y += SET_ROW_H;
    } else {
        fb_text(8, y, wifi_pending()
                ? "инициализация адаптера (фон)..."
                : "Адаптер не найден (AR9285/9287/9485)",
                wm_theme_text_dim(), -1);
        y += SET_ROW_H;
    }
}

/* ============ вкладка «Тема» (Обновлено: 3 полосы по 32 цвета) ============ */
/* Современная палитра (Material Design / Flat UI) */
static const u32 palette32[32] = {
    0x121212, 0x1E1E1E, 0x2D2D2D, 0x3E3E3E, 0x555555, 0x777777, 0x9E9E9E, 0xBDBDBD,
    0xE0E0E0, 0xF5F5F5, 0xFFFFFF, 0x000000, 0xE53935, 0xD81B60, 0x8E24AA, 0x5E35B1,
    0x3949AB, 0x1E88E5, 0x039BE5, 0x00ACC1, 0x00897B, 0x43A047, 0x7CB342, 0xC0CA33,
    0xFDD835, 0xFFB300, 0xFB8C00, 0xF4511E, 0x6D4C41, 0x546E7A, 0x263238, 0x37474F
};

#define THEME_STRIP_Y0   (SET_TABS_H + 30)
#define THEME_STRIP_STEP 34
#define THEME_SWATCH_W   16
#define THEME_SWATCH_H   20

static const char *theme_strip_name(int r)
{
    static const char *names[3] = {
        "Цвет окон:   ",
        "Цвет текста: ",
        "Заголовок:   "
    };
    return names[r];
}

static void draw_theme_tab(window_t *w, set_t *d)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_text(8, SET_TABS_H + 6, "Тема оформления (применяется ко всем окнам):",
             wm_theme_text_info(), -1);
    
    u32 bg, tx, ti;
    wm_theme_get_rgb(&bg, &tx, &ti);
    u32 bases[3] = { bg, tx, ti };

    /* --- 3 полосы-палитры --- */
    for (int r = 0; r < 3; r++) {
        int y = THEME_STRIP_Y0 + r * THEME_STRIP_STEP;
        int sel = (d->theme_sel == r);
        
        if (sel) {
            fb_fill_rect(4, y - 2, 120, 24, wm_theme_sel_bg());
        }
        fb_text(8, y, theme_strip_name(r),
                sel ? wm_theme_text() : wm_theme_text_dim(), -1);
        
        for (int i = 0; i < 32; i++) {
            int x = 130 + i * THEME_SWATCH_W;
            u32 c = palette32[i];
            fb_fill_rect(x, y, THEME_SWATCH_W - 1, THEME_SWATCH_H, c);
            
            /* Тонкая рамка вокруг каждого цвета для аккуратности */
            fb_rect(x, y, THEME_SWATCH_W - 1, THEME_SWATCH_H, wm_theme_text_dim());
            
            if (bases[r] == c) {
                fb_rect(x, y, THEME_SWATCH_W - 1, THEME_SWATCH_H, wm_theme_accent());
            }
            if (sel && d->theme_swatch == i) {
                fb_rect(x - 1, y - 1, THEME_SWATCH_W + 1, THEME_SWATCH_H + 2, wm_theme_text());
            }
        }
    }

    /* --- живое мини-предпросмотр --- */
    {
        int px = cw - 200, py = THEME_STRIP_Y0 + 3 * THEME_STRIP_STEP + 10;
        int pw = 184, ph = 96;
        if (py + ph < ch - 20) {
            fb_rect(px, py, pw, ph, wm_theme_accent());
            fb_fill_rect(px + 1, py + 1, pw - 2, TITLE_H - 2, wm_theme_title());
            fb_text(px + 8, py + 4, "Заголовок окна", wm_theme_title_text(), -1);
            fb_fill_rect(px + 1, py + TITLE_H, pw - 2, ph - TITLE_H - 1,
                         wm_theme_win_bg());
            fb_text(px + 8, py + TITLE_H + 6, "Обычный текст",
                    wm_theme_text(), -1);
            fb_text(px + 8, py + TITLE_H + 24, "Приглушённый",
                    wm_theme_text_dim(), -1);
            fb_text(px + 8, py + TITLE_H + 42, "Акцентный текст",
                    wm_theme_text_info(), -1);
            fb_text(px + 8, py + TITLE_H + 62, "выделено",
                    wm_theme_text(), wm_theme_sel_bg());
        }
    }

    /* --- сброс --- */
    {
        int y = THEME_STRIP_Y0 + 3 * THEME_STRIP_STEP + 10;
        set_row(d, y, ACT_THEME_RESET, "[C] Сбросить стандартную тему", "",
                wm_theme_text(), 0);
        y += SET_ROW_H;
        fb_text(8, y, "Цвета сохраняются в THEME.CFG (RAM disk)",
                wm_theme_text_dim(), -1);
    }
    (void)w;
}

/* ============ вкладка «Система»: настройки интерфейса (WM.CFG) ============
 * Два переключателя оконного менеджера (запрос пользователя):
 *   - «рисовать содержимое окна при перетаскивании» — выключенный
 *     включает быстрый режим для медленных CPU (Atom): тело окна при
 *     перетаскивании заливается однотонным фоном вместо blit канваса;
 *   - «анимации» — плавное раскрытие меню Пуск и разворачивание окон.
 * Одинаковые литералы подписей для отрисовки и hit-теста (ширина зоны
 * считается по СИМВОЛАМ UTF-8 в wm_checkbox_hit). */
#define SET_OPTLBL_DRAG "Рисовать содержимое окна при перетаскивании"
#define SET_OPTLBL_ANIM "Анимации (меню и разворачивание окон)"
#define SET_OPT_Y1   (SET_TABS_H + 34)
#define SET_OPT_Y2   (SET_TABS_H + 68)

static void draw_system_tab(window_t *w, set_t *d)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    (void)d;
    (void)cw;

    fb_text(8, SET_TABS_H + 6, "Интерфейс (сохраняется в WM.CFG):",
            wm_theme_text_info(), -1);

    wm_checkbox_draw(8, SET_OPT_Y1, SET_OPTLBL_DRAG,
                     wm_opt_drag_content(), wm_theme_text());
    wm_checkbox_draw(8, SET_OPT_Y2, SET_OPTLBL_ANIM,
                     wm_opt_animations(), wm_theme_text());

    fb_text(8, SET_OPT_Y2 + 34,
            "На слабой машине выключите обе опции —",
            wm_theme_text_dim(), -1);
    fb_text(8, SET_OPT_Y2 + 50,
            "перетаскивание станет заметно плавнее.",
            wm_theme_text_dim(), -1);
    (void)ch;
}

static void set_draw(window_t *w)
{
    set_t *d = (set_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    d->hot_n = 0;

    d->fmt_w[0].hidden = d->fmt_w[1].hidden = !(d->confirm && !d->deny);
    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    {
        static const char *names[4] = {
            "[1] Сеть", "[2] Диски", "[3] Тема", "[4] Система"
        };
        int tw = (cw - 16) / 4;
        for (int i = 0; i < 4; i++) {
            int bx = 4 + i * (tw + 4);
            int on = (d->tab == i);
            fb_fill_rect(bx, 2, tw, SET_TABS_H - 6,
                         on ? wm_theme_title() : wm_theme_win_bg_alt());
            fb_rect(bx, 2, tw, SET_TABS_H - 6,
                    on ? wm_theme_accent() : fb_rgb(0x2C, 0x31, 0x38));
            fb_text(bx + 10, 6, names[i],
                    on ? wm_theme_text() : wm_theme_text_dim(), -1);
            set_hot(d, bx, 2, tw, SET_TABS_H - 6,
                    i == 0 ? ACT_TAB_NET
                    : (i == 1 ? ACT_TAB_DISK
                       : (i == 2 ? ACT_THEME_RESET + 100 : ACT_TAB_SYS)));
        }
        fb_hline(0, cw - 1, SET_TABS_H - 1, fb_rgb(0x2C, 0x31, 0x38));
    }

    if (d->tab == 0)
        draw_net_tab(w, d);
    else if (d->tab == 1)
        draw_disk_tab(w, d);
    else if (d->tab == 2)
        draw_theme_tab(w, d);
    else
        draw_system_tab(w, d);

    fb_fill_rect(0, ch - 16, cw, 16, wm_theme_win_bg_alt());
    fb_text(6, ch - 13,
            d->tab == 0
            ? "Tab: вкладки  E: поле  цифры  Enter: применить  R: DHCP  S: статика  X: веб-сервер"
            : d->tab == 1
            ? "Tab: вкладки   F: формат FAT32   Q/P: режим   Esc: нет/выход"
            : d->tab == 2
            ? "Клик по цвету = применить   Up/Dn: полоса   Left/Right: выбор   C: сброс"
            : "D: содержимое при перетаскивании   A: анимации   клик по галочке",
            wm_theme_accent(), -1);
}

/* ============ форматирование ============ */
static window_t *g_fmt_win;
static void fmt_progress_cb(u32 done, u32 total, void *ctx)
{
    set_t *d = (set_t *)ctx;
    window_t *w = g_fmt_win;
    if (!w || !w->canvas) return;
    d->fmt_done = (int)done;
    d->fmt_total = (int)total;

    int cw = win_content_w(w);
    int ch = win_content_h(w);
    fb_set_clip(0, 0, cw - 1, ch - 1);
    fb_set_origin(0, 0);
    int by = set_fmt_box_y();
    int bw = cw - 16;
    if (by + FMT_BOX_H > ch) by = ch - FMT_BOX_H - 2;
    if (by < 0) by = 0;
    fb_fill_rect(6, by, bw, FMT_BOX_H, fb_rgb(0x40, 0x14, 0x14));
    fb_rect(6, by, bw, FMT_BOX_H, fb_rgb(0xE0, 0x50, 0x50));
    fb_text(14, by + 8, d->fmt_full
            ? "ПОЛНОЕ форматирование (с очисткой данных)..."
            : "БЫСТРОЕ форматирование (создание оглавления)...",
            fb_rgb(0xFF, 0xC0, 0x40), -1);

    int bar_y = by + 30;
    int bar_x = 14, bar_w = cw - 28;
    fb_fill_rect(bar_x, bar_y, bar_w, 14, fb_rgb(0x1B, 0x21, 0x27));
    fb_rect(bar_x, bar_y, bar_w, 14, fb_rgb(0x2C, 0x31, 0x38));
    if (total > 0) {
        int fill = (int)(((u64)done * (u64)(bar_w - 4)) / total);
        if (fill > bar_w - 4) fill = bar_w - 4;
        if (fill > 0)
            fb_fill_rect(bar_x + 2, bar_y + 2, fill, 10, fb_rgb(0x3E, 0x7D, 0xBF));
    }

    char b[80];
    snprintf(b, sizeof(b), "%s: %u / %u секторов",
             d->fmt_full ? "Полное" : "Быстрое",
             (unsigned)done, (unsigned)total);
    fb_text(14, by + 52, b, fb_rgb(0xFF, 0xC0, 0x40), -1);
    fb_touch(w->x, w->y, w->w, w->h);
}

static void set_run_format(window_t *w, set_t *d)
{
    d->formatting = 1;
    d->fmt_last_result = -100;
    g_fmt_win = w;
    fmt_progress_cb(0, 1, d);
    int rc = fat32_format_hdd(fmt_progress_cb, d, d->fmt_full);
    d->formatting = 0;
    if (rc == FAT32_FMT_OK) {
        d->fmt_last_result = 0;
        fat32_deinit();
        ntfs_invalidate();
        disk_part_rescan();
        if (fat32_init())
            serial_puts("[fmt] FAT32 смонтирована после форматирования\n");
        else
            serial_puts("[fmt] ВНИМАНИЕ: FAT32 не смонтировалась после формата\n");
    } else {
        d->fmt_last_result = rc;
        const char *why =
            rc == FAT32_FMT_NO_DISK  ? "диск не найден" :
            rc == FAT32_FMT_TOO_SMALL ? "диск слишком мал для FAT32" :
                                        "ошибка записи";
        strncpy(d->fmt_err, why, sizeof(d->fmt_err) - 1);
        d->fmt_err[sizeof(d->fmt_err) - 1] = 0;
    }
    win_invalidate(w);
}

/* ============ события ============ */
/* Сессия 27: ввод в поле IP (цифры/точка). Backspace обрабатывается
 * отдельно. Возвращает 1, если символ поглощён полем. */
static int set_field_char(set_t *d, char ch)
{
    if (d->edit < 0) return 0;
    if (ch == '.' || (ch >= '0' && ch <= '9')) {
        char *b = set_field_buf(d, d->edit);
        int n = (int)strlen(b);
        if (n < 15) {
            b[n] = ch;
            b[n + 1] = 0;
        }
        return 1;
    }
    return 0;
}

/* Клавиша/клик «R»: вернуться к DHCP (из статики) или перезапросить адрес */
static void set_do_dhcp(set_t *d)
{
    if (netcfg_static_mode())
        netcfg_use_static(0);       /* смена режима + перезапуск DHCP */
    else
        net_request_dhcp();         /* просто перезапросить */
    settings_net_save(net_adapter_mode());
    snprintf(d->net_err, sizeof(d->net_err),
             "Режим DHCP: адрес выдаст сервер/эмулятор");
    d->net_st = 1;
    d->dhcp_ticks = timer_ticks();
}

/* Клавиша/клик «S»: применить статические адреса из полей */
static void set_apply_static(set_t *d)
{
    u32 ip = 0, mask = 0, gw = 0, dns = 0;
    d->net_st = 2;
    if (!net_aton(d->f_ip, &ip)) {
        snprintf(d->net_err, sizeof(d->net_err),
                 "IP: четыре числа через точку (напр. 10.0.2.15)");
        return;
    }
    if (d->f_mask[0] && !net_aton(d->f_mask, &mask)) {
        snprintf(d->net_err, sizeof(d->net_err),
                 "Маска: неверный адрес (можно оставить пустой — /24)");
        return;
    }
    if (d->f_gw[0] && !net_aton(d->f_gw, &gw)) {
        snprintf(d->net_err, sizeof(d->net_err),
                 "Шлюз: неверный адрес (можно оставить пустым)");
        return;
    }
    if (d->f_dns[0] && !net_aton(d->f_dns, &dns)) {
        snprintf(d->net_err, sizeof(d->net_err),
                 "DNS: неверный адрес (можно оставить пустым)");
        return;
    }
    if (!mask) mask = 0xFFFFFF00u;   /* пустая маска = /24 (дубль защиты
                                      * netcfg_set_static на случай будущих
                                      * вызывающих) */
    netcfg_set_static(ip, mask, gw, dns);
    settings_net_save(net_adapter_mode());
    d->net_st = 1;
    {
        char b[16];
        net_ntoa(ip, b, sizeof(b));
        snprintf(d->net_err, sizeof(d->net_err),
                 "Статический IP %s применён и сохранён", b);
    }
}

static void set_apply_mode(set_t *d, int mode)
{
    if (net_adapter_set_mode(mode)) {
    }
    settings_net_save(mode);
    d->dhcp_ticks = timer_ticks();
}

static void set_action(window_t *w, set_t *d, int action)
{
    switch (action) {
    case ACT_TAB_NET:  d->tab = 0; break;
    case ACT_TAB_DISK: d->tab = 1; break;
    case ACT_THEME_RESET + 100: d->tab = 2; break;
    case ACT_TAB_SYS:  d->tab = 3; break;
    case ACT_AUTO:     set_apply_mode(d, 0); break;
    case ACT_DHCP:                                   /* строка удалена — остался клавиатурный сценарий */
    case ACT_NET_DHCP:
        set_do_dhcp(d);
        break;
    case ACT_NET_STATIC:
        set_apply_static(d);
        break;
    case ACT_THEME_RESET:
        wm_theme_reset();
        break;
    case ACT_WIFI_W: {
        char ssid[33];
        if (wifi_profile_load(ssid, sizeof(ssid)))
            wifi_connect(ssid);
        break;
    }
    case ACT_WIFI_D:
        wifi_disconnect();
        break;
    case ACT_WEBSRV:
        /* Сессия 58: галочка веб-сервера — вкл/выкл + сохранить в
         * SETTINGS.CFG (строка httpd=0|1; по умолчанию включён) */
        net_httpd_set_enabled(!net_httpd_wanted());
        settings_net_save(net_adapter_mode());
        break;
    case ACT_FMT:
        if (disk_hdd_present() && !d->formatting) {
            if (set_disk_has_ntfs()) {
                d->deny = 1;
                d->confirm = 0;
            } else {
                d->confirm = 1;
                d->deny = 0;
            }
        }
        break;
    case ACT_FMT_YES:
        if (d->confirm) {
            d->confirm = 0;
            set_run_format(w, d);
        }
        break;
    case ACT_FMT_NO:
        d->confirm = 0;
        break;
    default:
        if (action >= ACT_ADAPTER && action < ACT_ADAPTER + 5) {
            d->sel = action - ACT_ADAPTER;
            if (net_adapter_present(d->sel))
                set_apply_mode(d, d->sel + 1);
        } else if (action >= ACT_NET_FIELD && action < ACT_NET_FIELD + 4) {
            d->edit = action - ACT_NET_FIELD;   /* клик по полю — фокус */
        }
        break;
    }
}

static void set_key(window_t *w, const key_event_t *ev)
{
    set_t *d = (set_t *)w->data;
    int editing = (d->tab == 0 && d->edit >= 0);
    if (ev->flags & KF_RELEASED) return;

    if (ev->ch == 0x1B || ev->code == 0x01) {
        if (editing) { d->edit = -1; win_invalidate(w); return; }  /* Esc — выйти из поля */
        if (d->confirm) { d->confirm = 0; win_invalidate(w); return; }
        if (d->deny)    { d->deny = 0;    win_invalidate(w); return; }
        win_close(w);
        return;
    }

    /* Tab/1/2/3/4 — вкладки; но во время ввода IP цифры 1/2/3/4 —
     * СИМВОЛЫ поля, а не переключение вкладок */
    if (!editing &&
        (ev->code == 0x0F || ev->ch == '1' || ev->ch == '2' ||
         ev->ch == '3' || ev->ch == '4')) {
        if (ev->code == 0x0F)
            d->tab = (d->tab + 1) % 4;
        else
            d->tab = (ev->ch == '1') ? 0
                   : (ev->ch == '2') ? 1
                   : (ev->ch == '3') ? 2 : 3;
        win_invalidate(w);
        return;
    }

    if (d->confirm) {
        if (ev->ch == 'q' || ev->ch == 'Q') { d->fmt_full = 0; win_invalidate(w); return; }
        if (ev->ch == 'p' || ev->ch == 'P') { d->fmt_full = 1; win_invalidate(w); return; }
        if (ev->code == 0x1C || ev->ch == '\n') {
            d->confirm = 0;
            set_run_format(w, d);
            return;
        }
    }
    if (d->deny && (ev->code == 0x1C || ev->ch == '\n')) {
        d->deny = 0;
        win_invalidate(w);
        return;
    }

    if (d->tab == 0) {
        /* --- ввод в поле IP (сессия 27) --- */
        if (editing) {
            if (ev->code == 0x0E || ev->ch == '\b') {           /* Backspace */
                char *b = set_field_buf(d, d->edit);
                int n = (int)strlen(b);
                if (n > 0) b[n - 1] = 0;
                win_invalidate(w);
                return;
            }
            if (set_field_char(d, ev->ch)) { win_invalidate(w); return; }
            if (ev->code == KBD_UP || ev->code == KBD_DOWN) {
                d->edit = (d->edit + (ev->code == KBD_DOWN ? 1 : 3)) % 4;
                win_invalidate(w);
                return;
            }
            if (ev->code == 0x1C || ev->ch == '\n') {           /* Enter — применить */
                set_apply_static(d);
                win_invalidate(w);
                return;
            }
            /* буквы-горячие клавиши работают и во время ввода */
        }
        if (ev->ch == 'a' || ev->ch == 'A') {
            set_apply_mode(d, 0);
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'r' || ev->ch == 'R') {
            set_do_dhcp(d);
            win_invalidate(w);
            return;
        }
        if (ev->ch == 's' || ev->ch == 'S') {                    /* применить статику */
            set_apply_static(d);
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'e' || ev->ch == 'E') {                    /* войти в редактирование */
            d->edit = (d->edit < 0) ? 0 : -1;
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'w' || ev->ch == 'W') {
            char ssid[33];
            if (wifi_profile_load(ssid, sizeof(ssid)))
                wifi_connect(ssid);
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'd' || ev->ch == 'D') {
            wifi_disconnect();
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'x' || ev->ch == 'X') {
            /* Сессия 58: галочка веб-сервера */
            net_httpd_set_enabled(!net_httpd_wanted());
            settings_net_save(net_adapter_mode());
            win_invalidate(w);
            return;
        }
        if (ev->code == KBD_UP) {
            int cur = d->sel;
            for (int step = 0; step < 5; step++) {
                cur--;
                if (cur < 0) cur = 4;
                if (net_adapter_present(cur)) { d->sel = cur; break; }
            }
            win_invalidate(w);
        }
        if (ev->code == KBD_DOWN) {
            int cur = d->sel;
            for (int step = 0; step < 5; step++) {
                cur++;
                if (cur > 4) cur = 0;
                if (net_adapter_present(cur)) { d->sel = cur; break; }
            }
            win_invalidate(w);
        }
        if (ev->code == 0x1C || ev->ch == '\n') {
            if (net_adapter_present(d->sel))
                set_apply_mode(d, d->sel + 1);
            win_invalidate(w);
        }
    } else if (d->tab == 1) {
        if ((ev->ch == 'f' || ev->ch == 'F') && disk_hdd_present() &&
            !d->formatting) {
            if (set_disk_has_ntfs()) d->deny = 1;
            else d->confirm = 1;
            win_invalidate(w);
        }
    } else if (d->tab == 2) {
        /* ===== Тема ===== */
        if (ev->ch == 'c' || ev->ch == 'C') {
            wm_theme_reset();
            win_invalidate(w);
            return;
        }
        if (ev->code == KBD_UP) {
            if (--d->theme_sel < 0) d->theme_sel = 2;
            win_invalidate(w);
            return;
        }
        if (ev->code == KBD_DOWN) {
            if (++d->theme_sel > 2) d->theme_sel = 0;
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x4B /* Left */ || ev->code == 0x4D /* Right */) {
            int delta = (ev->code == 0x4D) ? 1 : -1;
            d->theme_swatch = (d->theme_swatch + delta + 32) % 32;
            u32 bg, tx, ti;
            wm_theme_get_rgb(&bg, &tx, &ti);
            u32 bases[3] = { bg, tx, ti };
            bases[d->theme_sel] = palette32[d->theme_swatch];
            wm_theme_set(bases[0], bases[1], bases[2]);
            win_invalidate(w);
            return;
        }
    } else if (d->tab == 3) {
        /* ===== Система: настройки интерфейса ===== */
        if (ev->ch == 'd' || ev->ch == 'D') {
            wm_opt_set_drag_content(!wm_opt_drag_content());
            win_invalidate(w);
            return;
        }
        if (ev->ch == 'a' || ev->ch == 'A') {
            wm_opt_set_animations(!wm_opt_animations());
            win_invalidate(w);
            return;
        }
    }
}

static void set_tick(window_t *w)
{
    set_t *d = (set_t *)w->data;
    wifi_conn_state_t cs = wifi_conn_state();
    int need = 0;
    static int was_pending = -1;
    int p = wifi_pending();
    if (p != was_pending) { was_pending = p; need = 1; }
    if (d->tab == 0) {
        /* статический режим: DHCP никогда не BOUND — не молотить
         * перерисовку; обновляемся по смене режима/IP (сессия 27) */
        static int snap_stat = -1;
        static u32 snap_ip = 0;
        int st = netcfg_static_mode();
        if (st != snap_stat || net_get_ip() != snap_ip) {
            snap_stat = st;
            snap_ip = net_get_ip();
            need = 1;
        }
        if ((!st && net_dhcp_state() != DHCP_BOUND) ||
            cs == WIFI_CONN_SCAN || cs == WIFI_CONN_AUTH ||
            cs == WIFI_CONN_ASSOC)
            need = 1;
    } else if (d->tab == 1) {
        static int snap = -1;
        int cur = (disk_hdd_present() ? 1 : 0) |
                  (fat32_ready() ? 2 : 0) | (ntfs_ready() ? 4 : 0) |
                  (sata_pending() ? 8 : 0);
        if (cur != snap) { snap = cur; need = 1; }
    }
    /* вкладки 2 (Тема) и 3 (Система) статичны — тик не нужен */
    if (need)
        win_invalidate(w);
}

static void set_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    set_t *d = (set_t *)w->data;

    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        if (d->tab == 0) {
            /* сессия 62: чекбокс веб-сервера — тот же виджет, что в
             * «Системе»; до hot-зон строк, т.к. зона шире строки */
            if (wm_checkbox_hit(mx, my, 8, d->websrv_y,
                                SET_NETLBL_WEBSRV)) {
                set_action(w, d, ACT_WEBSRV);
                win_invalidate(w);
                return;
            }
        }
        if (d->tab == 2) {
            for (int r = 0; r < 3; r++) {
                int y = THEME_STRIP_Y0 + r * THEME_STRIP_STEP;
                if (my >= y && my < y + THEME_SWATCH_H) {
                    if (mx >= 4 && mx < 130) {
                        d->theme_sel = r;
                        win_invalidate(w);
                        return;
                    }
                    int idx = (mx - 130) / THEME_SWATCH_W;
                    if (idx >= 0 && idx < 32) {
                        d->theme_sel = r;
                        d->theme_swatch = idx;
                        u32 bg, tx, ti;
                        wm_theme_get_rgb(&bg, &tx, &ti);
                        u32 bases[3] = { bg, tx, ti };
                        bases[r] = palette32[idx];
                        wm_theme_set(bases[0], bases[1], bases[2]);
                        win_invalidate(w);
                        return;
                    }
                }
            }
        }
        if (d->tab == 3) {
            /* чекбоксы настроек интерфейса (компонент WM, сессия 14) */
            if (wm_checkbox_hit(mx, my, 8, SET_OPT_Y1, SET_OPTLBL_DRAG)) {
                wm_opt_set_drag_content(!wm_opt_drag_content());
                win_invalidate(w);
                return;
            }
            if (wm_checkbox_hit(mx, my, 8, SET_OPT_Y2, SET_OPTLBL_ANIM)) {
                wm_opt_set_animations(!wm_opt_animations());
                win_invalidate(w);
                return;
            }
        }
        for (int i = 0; i < d->hot_n; i++) {
            if (mx >= d->hot[i].x && mx < d->hot[i].x + d->hot[i].w &&
                my >= d->hot[i].y && my < d->hot[i].y + d->hot[i].h) {
                set_action(w, d, d->hot[i].action);
                win_invalidate(w);
                return;
            }
        }
    }
    (void)d;
}

static void set_close(window_t *w)
{
    win_widgets_clear(w);
    free(w->data);
}

void app_settings_open(void)
{
    set_t *d = (set_t *)malloc(sizeof(set_t));
    if (!d) return;
    memset(d, 0, sizeof(set_t));
    d->sel = net_adapter_active() >= 0 ? net_adapter_active() : 0;
    d->hover = -1;
    d->tab = 0;
    d->websrv_y = -1000;       /* чекбокс ещё не отрисован */
    d->fmt_last_result = -100;
    d->theme_sel = 0;          /* старт: цвет окон */
    d->theme_swatch = 0;

    /* --- Сессия 27: поля IP — из сохранённой статики или умолчания --- */
    {
        u32 ip, mask, gw, dns;
        netcfg_static_get(&ip, &mask, &gw, &dns);
        if (ip)   net_ntoa(ip, d->f_ip, sizeof(d->f_ip));
        else      strcpy(d->f_ip, "10.0.2.15");
        if (mask) net_ntoa(mask, d->f_mask, sizeof(d->f_mask));
        else      strcpy(d->f_mask, "255.255.255.0");
        if (gw)   net_ntoa(gw, d->f_gw, sizeof(d->f_gw));
        else      strcpy(d->f_gw, "10.0.2.2");
        if (dns)  net_ntoa(dns, d->f_dns, sizeof(d->f_dns));
        /* DNS по умолчанию пустой — не обязателен */
    }
    d->edit = -1;              /* редактирование выключено */
    d->net_st = 0;

    d->fmt_w[0].type = WM_WIDGET_RADIO;
    d->fmt_w[0].enabled = 1;
    d->fmt_w[0].hidden = 1;
    strcpy(d->fmt_w[0].label, "Быстрое (оглавление)");
    d->fmt_w[0].value = &d->fmt_full;
    d->fmt_w[0].radio_value = 0;
    d->fmt_w[1].type = WM_WIDGET_RADIO;
    d->fmt_w[1].enabled = 1;
    d->fmt_w[1].hidden = 1;
    strcpy(d->fmt_w[1].label, "Полное (очистка)");
    d->fmt_w[1].value = &d->fmt_full;
    d->fmt_w[1].radio_value = 1;

    u32 W = fb_width(), H = fb_height();
    int ww = SET_COLS * 8 + 16;
    int wh = 500;   /* сессия 27: выше — место под IP-поля (win_create сам клампит) */
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    window_t *w = win_create("Настройки", 60, 40, ww, wh,
                             set_draw, set_key, set_mouse, set_tick,
                             set_close, d);
    if (w)
        win_widgets_set(w, d->fmt_w, 2);
}