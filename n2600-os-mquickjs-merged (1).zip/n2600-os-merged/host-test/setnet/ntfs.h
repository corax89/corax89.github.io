/* ntfs.h — чтение NTFS-раздела (read-only, сессия 11).
 *
 * Поддерживается:
 *   - MBR-таблица разделов (первичный + один уровень extended)
 *   - boot-сектор NTFS, $MFT ($MFTMirr не используется)
 *   - записи MFT с fixup (update sequence array)
 *   - атрибуты $FILE_NAME, $DATA (resident + non-resident data runs,
 *     sparse-дыры), $INDEX_ROOT + $INDEX_ALLOCATION (каталоги любого
 *     размера), $ATTRIBUTE_LIST (внешние атрибуты), $VOLUME_NAME
 *   - LZNT1-декомпрессия сжатых файлов
 *   - имена UTF-16LE -> ASCII с транслитерацией кириллицы
 *
 * Не поддерживается: запись, шифрование (EFS), журналирование.
 */
#ifndef NTFS_H
#define NTFS_H

#include "types.h"

#define NTFS_NAME_MAX 63

typedef struct {
    char name[NTFS_NAME_MAX + 1];   /* ASCII (транслит кириллицы) */
    u32  size;                      /* реальный размер, байт */
    int  is_dir;
} ntfs_dirent_t;

/* Смонтировать первый NTFS-раздел на НЖМД (через disk-слой).
 * Возвращает 1 при успехе. */
int  ntfs_init(void);
int  ntfs_init_part(int part_index); /* сессия 25: конкретный раздел disk_part() */
int  ntfs_ready(void);
void ntfs_invalidate(void);   /* сессия 12: забыть раздел (формат) */
const char *ntfs_label(void);       /* метка тома (или "NTFS") */
const char *ntfs_error(void);       /* причина последней ошибки */

/* Перечислить каталог по полному пути ("/" — корень), до max записей.
 * Возвращает число записей или -1 (путь не найден). */
int  ntfs_list(const char *path, ntfs_dirent_t *out, int max);

/* Прочитать файл по полному пути (до max байт).
 * Возвращает число прочитанных байт (0 = не найден/ошибка). */
u32  ntfs_read_file(const char *path, void *buf, u32 max);

/* Размер файла по пути (или -1). */
int  ntfs_file_size(const char *path);

#endif /* NTFS_H */
