/* ramfs.h — виртуальная файловая система в оперативной памяти */
#ifndef RAMFS_H
#define RAMFS_H

#include "types.h"

#define RAMFS_NAME_MAX 64
#define RAMFS_MAX_FILES 256

typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    u32  size;
    u32  offset;  /* смещение в области данных */
    u8   is_dir;  /* 1 = каталог, 0 = файл */
} ramfs_dirent_t;

/* Инициализация RAM disk (10% от доступной памяти) */
int  ramfs_init(void);
int  ramfs_ready(void);

/* Создать файл (возвращает 1 при успехе) */
int  ramfs_create(const char *name, u32 size);

/* Записать данные в файл */
int  ramfs_write(const char *name, const void *buf, u32 size);

/* Прочитать файл (возвращает количество прочитанных байт) */
u32  ramfs_read(const char *name, void *buf, u32 max);

/* Удалить файл */
int  ramfs_delete(const char *name);

/* Список файлов в корневом каталоге (плоский: ВСЕ записи, полными путями) */
int  ramfs_list(ramfs_dirent_t *out, int max);

/* ==================== каталоги (сессия 13) ====================
 * Иерархия: имена хранятся ПОЛНЫМИ путями без ведущего слэша
 * ("dir1", "dir1/file.txt"). Корневые файлы — как раньше, простым
 * именем: СТАРЫЕ вызовы (create/read/write/delete по имени из корня)
 * работают без изменений. */
/* Создать каталог (путь без ведущего '/'; родитель должен существовать). */
int  ramfs_mkdir(const char *path);
/* Список НЕПОСРЕДСТЕННЫХ детей каталога (dir="/": корень). e->name —
 * базовое имя ребёнка; полный путь = dir + "/" + name (для read/delete). */
int  ramfs_list_dir(const char *dir, ramfs_dirent_t *out, int max);

/* Сессия 60: stat файла по имени БЕЗ УЧЁТА РЕГИСТРА (httpd).
 * out получает копию записи (имя/размер/is_dir). 1 = найден. */
int  ramfs_stat_ci(const char *name, ramfs_dirent_t *out);

/* Получить размер свободного места */
u32  ramfs_free_space(void);

/* Получить общий размер RAM disk */
u32  ramfs_total_space(void);

/* ================= ramfs как отдельный процесс ================= */
/* Породить задачу-сервер «ramfs» (видна в диспетчере задач, владеет
 * памятью ramdisk). Вызывается из kmain ПОСЛЕ task_init(). До вызова
 * (фаза загрузки) операции идут напрямую. Возвращает 1 при успехе. */
int  ramfs_server_start(void);

/* Индекс задачи-сервера ramfs или -1, если ещё не запущена. */
int  ramfs_server_task(void);

/* Число файлов в RAM disk. */
int  ramfs_file_count(void);

#endif