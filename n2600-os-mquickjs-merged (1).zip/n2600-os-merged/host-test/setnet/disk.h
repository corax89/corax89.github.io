/* disk.h — единый слой НЖМД: AHCI (SATA) приоритетнее, затем легаси ATA.
 * Приложения (fat32/ntfs/iso9660/fileman/disks) работают через эти функции
 * и не обязаны знать, где физически живёт диск.
 *
 * Сессия 11: слой разделов MBR — таблица читается один раз (disk_part_scan
 * вызывается лениво из disk_part_count/…), разделы отдаются драйверам ФС
 * (fat32.c пробует FAT32-разделы, ntfs.c — NTFS). */
#ifndef DISK_H
#define DISK_H

#include "types.h"

int  disk_hdd_init(void);       /* пробует AHCI и ATA (фоновая задача sata) */
int  disk_hdd_present(void);    /* найден НЖМД (любой бэкенд) */
u32  disk_hdd_sectors(void);
const char *disk_hdd_model(void);
const char *disk_hdd_bus(void); /* "AHCI" или "ATA" */

/* Чтение секторов по 512 байт. 1 = успех. */
int  disk_hdd_read(u32 lba, u8 count, void *buf);

/* Запись секторов НЖМД (сессия 12: форматирование FAT32). 1 = успех. */
int  disk_hdd_write(u32 lba, u8 count, const void *buf);

/* CD: AHCI ATAPI приоритетнее легаси ATAPI. 1 = успех (2048 байт). */
int  disk_cd_read(u32 lba, void *buf);
int  disk_cd_present(void);

/* ================= разделы MBR / GPT (сессии 11/25) ================= */

typedef struct {
    u8   type;          /* код типа MBR (0x07 = NTFS, 0x0B/0x0C = FAT32...);
                         * для GPT: 0x07 = данные/ОС, 0xEF = EFI-системный */
    u32  start_lba;     /* абсолютный LBA начала */
    u32  nsectors;
    u8   gpt;           /* 1 = раздел из GPT, 0 = MBR/EBR (сессия 25) */
    char label[24];     /* имя раздела GPT (UTF-8, обрезано) или "" для MBR */
} disk_part_t;

/* Число найденных разделов (сканирует MBR/GPT при первом вызове).
 * Сессия 25: читается ВСЯ таблица — первичные + логические (EBR-цепочка)
 * + GPT (в т.ч. защитная схема «GPT поверх MBR»). */
int  disk_part_count(void);
/* Раздел по индексу или NULL. */
void disk_part_rescan(void);   /* сессия 12: после форматирования */
const disk_part_t *disk_part(int i);
/* Тип ФС раздела по загрузочному сектору: "NTFS" / "FAT32" / "". */
const char *disk_part_fstype(int i);

#endif /* DISK_H */
