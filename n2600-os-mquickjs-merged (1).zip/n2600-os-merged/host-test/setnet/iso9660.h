/* iso9660.h — начальная поддержка файловой системы ISO 9660 (только чтение) */
#ifndef ISO9660_H
#define ISO9660_H

#include "types.h"

/* FIX [I2]: 255 → 64. Имена PVD-дерева короткие (8.3), а dirent на
 * 264 байта делал три массива в ramfs_seed_from_iso на ~43 КиБ стека. */
#define ISO9660_NAME_MAX 64

typedef struct {
    char name[ISO9660_NAME_MAX + 1];
    u8   is_dir;      /* 1 = каталог, 0 = файл */
    u32  size;
    u32  first_lba;   /* Логический адрес (LBA) первого блока (2048 байт) */
} iso9660_dirent_t;

/* Инициализация ISO 9660. Читает PVD и проверяет сигнатуру "CD001". */
int  iso9660_init(void);
int  iso9660_ready(void);

/* Прочитать корневой каталог. Возвращает количество найденных записей. */
int  iso9660_list_root(iso9660_dirent_t *out, int max);

/* Прочитать ЛЮБОЙ каталог по его LBA/размеру (из list_root или из
 * другой записи). keep_ext=1 — сохранять расширение имени
 * (readme.md), обрезая только ';1' и хвостовые пробелы; keep_ext=0 —
 * прежнее поведение (обрезать на '.'). Нужен рамфс-сидингу /boot/ramdisk. */
int  iso9660_list_dir(u32 dir_lba, u32 dir_size, int keep_ext,
                      iso9660_dirent_t *out, int max);

/* Прочитать файл в буфер. Возвращает количество прочитанных байт. */
u32  iso9660_read_file(u32 first_lba, u32 size, void *buf, u32 max);

#endif