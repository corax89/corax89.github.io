/* ath9k_wifi.h — СОВМЕСТИМОСТЬ (сессия 28).
 * Весь WiFi-стек переехал в wifi_core.h/wifi_core.c; публичный API
 * прежний (wifi_*). Драйвер Atheros — ath9k_wifi.c, подключается
 * через wifi_init() (диспетчер в wifi_core.c). */
#ifndef ATH9K_WIFI_H
#define ATH9K_WIFI_H

#include "wifi_core.h"

#endif /* ATH9K_WIFI_H */
