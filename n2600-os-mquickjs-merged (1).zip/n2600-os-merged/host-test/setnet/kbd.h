/* kbd.h — клавиатура PS/2 */
#ifndef KBD_H
#define KBD_H

#include "types.h"

/* виртуальные коды для не-ASCII клавиш */
#define KBD_UP     0x80
#define KBD_DOWN   0x81
#define KBD_LEFT   0x82
#define KBD_RIGHT  0x83

#define KF_RELEASED 0x01
#define KF_SHIFT    0x02
#define KF_CTRL     0x04
#define KF_ALT      0x08

typedef struct {
    u8  code;    /* скан-код или виртуальный код */
    char ch;     /* ASCII-символ (0 если нет) */
    u8  flags;
} key_event_t;

void kbd_init(void);              /* IRQ1 */
int  kbd_pop(key_event_t *out);   /* 1 = событие получено */
void kbd_push_event(u8 code, char ch, u8 flags);  /* программно пушить событие (для USB) */

#endif
