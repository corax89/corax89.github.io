/* mouse.h — мышь PS/2 (тачпад нетбука работает в PS/2-совместимом режиме) */
#ifndef MOUSE_H
#define MOUSE_H

#include "types.h"

#define MSB_LEFT  0x01
#define MSB_RIGHT 0x02
#define MSB_MID   0x04

void mouse_init(void);               /* инициализация до включения прерываний */
void mouse_install_irq(void);        /* регистрация обработчика IRQ12 */
int  mouse_present(void);

extern volatile int ms_x, ms_y;      /* позиция курсора */
extern volatile u8  ms_buttons;      /* MSB_* */
extern volatile int ms_event;        /* было движение/нажатие с прошлого опроса */
extern volatile int ms_wheel;        /* колёсико: +1 = вверх, -1 = вниз */
extern volatile int ms_wheel_event;  /* было вращение колёсика */

/* Сессия 31, «клики теряются при обильной перерисовке»: IRQ фиксирует
 * РЕБРО нажатия (0->1) в latch. Если нажатие+отпускание полностью уложились
 * между двумя опросами (wm_mouse_poll), уровень вернулся в исходный —
 * старый код на «btn ^ prev_btn» такой клик НЕ видел вовсе. Теперь WM
 * забирает latch (ms_click_take) и доставляет приложению гарантированный
 * press-edge. */
extern volatile u8  ms_click_latch;  /* биты MSB_*: нажатие с прошлого опроса */
u8  ms_click_take(void);             /* забрать и очистить latch (для WM) */

#endif
