/* setnet_test.c — хост-тест приложения «Настройки» N2600-OS (сессия 27).
 *
 * Компилирует НАСТОЯЩИЙ src/apps_settings.c (#include) против заглушек,
 * заголовки — НАСТОЯЩИЕ (копируются run_setnet.sh), поэтому прототипы
 * не могут разойтись с реальностью. Проверяет:
 *   1. РЕГРЕССИЯ «полос»: подсветка выделения строки рисуется ДО текста
 *      (раньше set_row_hl заливал строку ПОСЛЕ текста — приоритет/
 *      адаптеры «прятались» под цветной полосой);
 *   2. 'S': статический IP применяется (netcfg_set_static с верными
 *      значениями) и сохраняется в SETTINGS.CFG (netmode/ip/mask/gw);
 *   3. 'R': возврат к DHCP (netcfg_use_static(0)) + сохранение;
 *   4. Редактор полей: цифры/точка/Backspace, лимит буфера, Up/Dn
 *      между полями, Esc выходит из поля НЕ закрывая окно,
 *      цифра '1' во время ввода НЕ переключает вкладку;
 *   5. Валидация: кривой IP → ошибка, netcfg_set_static НЕ зовётся;
 *   6. Пустые маска/шлюз/DNS: маска = /24 по умолчанию, gw/dns = 0;
 *   7. Мышь: клик по строке поля даёт фокус, клик по строкам режима
 *      DHCP/статический выполняет те же действия, что клавиши.
 *
 * Сборка: run_setnet.sh (обычный | asan)
 */
#include <stdio.h>
#include <string.h>
/* NOTE: <stdlib.h> НЕ включаем — настоящий mem.h объявляет malloc(u32);
 * связывается с libc malloc (как в tmfmt). */

/* настоящие заголовки ОС (свежие копии из src/, кладёт run_setnet.sh):
 * типы и прототипы не могут разойтись с реальностью */
#include "types.h"
#include "kbd.h"
#include "mouse.h"
#include "wm.h"
#include "net.h"
#include "ath9k_wifi.h"
#include "disk.h"
#include "fat32.h"
#include "fat32_format.h"
#include "kernel.h"

/* =================== захват вызовов fb_/wm_/ramfs_/netcfg_ =================== */
#define CAP_MAX 2048
typedef struct { int kind; int x, y, w, h; char text[128]; u32 color; } cap_ev_t;
/* kind: 0 = fb_text, 1 = fb_fill_rect, 2 = fb_rect */
static cap_ev_t cap[CAP_MAX];
static int cap_n;

static void cap_add(int kind, int x, int y, int w, int h, const char *s, u32 c)
{
    if (cap_n < CAP_MAX) {
        cap[cap_n].kind = kind; cap[cap_n].x = x; cap[cap_n].y = y;
        cap[cap_n].w = w; cap[cap_n].h = h;
        if (s) snprintf(cap[cap_n].text, sizeof(cap[cap_n].text), "%s", s);
        else   cap[cap_n].text[0] = 0;
        cap[cap_n].color = c;
        cap_n++;
    }
}
static void cap_reset(void) { cap_n = 0; }

static int cap_find_text(const char *needle)
{
    for (int i = 0; i < cap_n; i++)
        if (cap[i].kind == 0 && strstr(cap[i].text, needle)) return i;
    return -1;
}

/* последний fill_rect ПОД текстом (y текста внутри полосы) */
static int cap_last_fill_under(int text_idx)
{
    if (text_idx < 0) return -1;
    int ty = cap[text_idx].y;
    int found = -1;
    for (int i = 0; i < cap_n; i++)
        if (cap[i].kind == 1 && ty >= cap[i].y && ty < cap[i].y + cap[i].h)
            found = i;
    return found;
}

/* ---- захваченные сетевые вызовы ---- */
static struct { int called; u32 ip, mask, gw, dns; } cap_set_static;
static struct { int called; int on; } cap_use_static;
static int cap_dhcp_req;                 /* net_request_dhcp */
static u32 cap_timer;
static int cap_closed;                   /* win_close */
static int cap_invalidated;

/* ---- захваченный SETTINGS.CFG ---- */
static char cfg_file[256];
static int  cfg_valid;
static int  ramfs_ready_flag = 1;

/* ---- фальшивый netcfg (вместо kernel.c): реальные значения режима ---- */
static int  g_t_static;
static u32  g_t_sip, g_t_smask, g_t_sgw, g_t_sdns;

int  netcfg_static_mode(void) { return g_t_static; }
void netcfg_static_get(u32 *ip, u32 *mask, u32 *gw, u32 *dns)
{
    if (ip)   *ip   = g_t_sip;
    if (mask) *mask = g_t_smask;
    if (gw)   *gw   = g_t_sgw;
    if (dns)  *dns  = g_t_sdns;
}
void netcfg_use_static(int on)
{
    cap_use_static.called = 1;
    cap_use_static.on = on;
    g_t_static = on;
}
void netcfg_set_static(u32 ip, u32 mask, u32 gw, u32 dns)
{
    cap_set_static.called = 1;
    cap_set_static.ip = ip; cap_set_static.mask = mask;
    cap_set_static.gw = gw; cap_set_static.dns = dns;
    g_t_static = 1;
    g_t_sip = ip; g_t_smask = mask; g_t_sgw = gw; g_t_sdns = dns;
}

/* =================== заглушки ОС =================== */
void serial_puts(const char *s) { (void)s; }
u32  timer_ticks(void) { return ++cap_timer; }

/* ---- fb ---- */
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r << 16) | ((u32)g << 8) | b; }
void fb_fill_rect(int x, int y, int w, int h, u32 color) { cap_add(1, x, y, w, h, NULL, color); }
void fb_rect(int x, int y, int w, int h, u32 color)      { cap_add(2, x, y, w, h, NULL, color); }
void fb_hline(int x0, int x1, int y, u32 c) { (void)x0;(void)x1;(void)y;(void)c; }
void fb_text(int x, int y, const char *s, u32 color, int bg) { (void)bg; cap_add(0, x, y, 0, 0, s, color); }
/* как в fb.c: ширина по СИМВОЛАМ UTF-8 * 8 */
static int st_utf8_chars(const char *s)
{
    int n = 0;
    while (*s) { if (((*s) & 0xC0) != 0x80) n++; s++; }
    return n;
}
u32 fb_text_w(const char *s) { return (u32)st_utf8_chars(s) * 8; }
u32 fb_width(void)  { return 1024; }
u32 fb_height(void) { return 600; }
void fb_touch(int x, int y, int w, int h) { (void)x;(void)y;(void)w;(void)h; }
void fb_set_clip(int x0, int y0, int x1, int y1) { (void)x0;(void)y0;(void)x1;(void)y1; }
void fb_set_origin(int ox, int oy) { (void)ox;(void)oy; }

/* ---- wm / окна ---- */
static u32 t_theme_bg = 0x202020, t_theme_tx = 0xE0E0E0, t_theme_ti = 0x4090D0;
static u32 t_sel_bg = 0x3050A0, t_accent = 0x60A0FF;
u32 wm_theme_text(void)        { return t_theme_tx; }
u32 wm_theme_text_dim(void)    { return 0x909090; }
u32 wm_theme_text_info(void)   { return t_theme_ti; }
u32 wm_theme_sel_bg(void)      { return t_sel_bg; }
u32 wm_theme_title(void)       { return 0x303030; }
u32 wm_theme_title_text(void)  { return 0xFFFFFF; }
u32 wm_theme_win_bg(void)      { return t_theme_bg; }
u32 wm_theme_win_bg_alt(void)  { return 0x282828; }
u32 wm_theme_accent(void)      { return t_accent; }
void wm_theme_get_rgb(u32 *bg, u32 *tx, u32 *ti) { *bg = t_theme_bg; *tx = t_theme_tx; *ti = t_theme_ti; }
void wm_theme_set(u32 bg, u32 tx, u32 ti) { t_theme_bg = bg; t_theme_tx = tx; t_theme_ti = ti; }
void wm_theme_reset(void) { t_theme_bg = 0x202020; t_theme_tx = 0xE0E0E0; t_theme_ti = 0x4090D0; }

static window_t t_win;                    /* единственное окно теста */
static int t_content_h = 460;             /* win_content_h */
int win_content_w(window_t *w) { return w ? w->w : 0; }
int win_content_h(window_t *w) { (void)w; return t_content_h; }
void win_invalidate(window_t *w) { (void)w; cap_invalidated++; }
void win_close(window_t *w) { (void)w; cap_closed++; }
void wm_widgets_draw(window_t *w) { (void)w; }
void win_widgets_clear(window_t *w) { (void)w; }
/* СЕССИЯ 32/34: опции WM + геометрия чекбокса (настоящие в wm.c) */
int  wm_opt_drag_content(void) { return 1; }
void wm_opt_set_drag_content(int on) { (void)on; }
int  wm_opt_animations(void) { return 1; }
void wm_opt_set_animations(int on) { (void)on; }
void wm_checkbox_draw(int x, int y, const char *label, int checked, u32 text_color)
{
    /* как в wm.c: коробка 12x12 + подпись */
    cap_add(2, x, y, 12, 12, NULL, checked ? t_accent : 0x404040);
    if (label) fb_text(x + 20, y + 1, label, text_color, 0);
    (void)y;
}
int  wm_checkbox_hit(int mx, int my, int x, int y, const char *label)
{
    /* как в wm.c: зона клика = квадрат 14x14 + подпись (8 px/символ) */
    if (!label) label = "";
    int w = 14 + 8 * (int)strlen(label) + 8;
    return mx >= x && mx < x + w && my >= y && my < y + 14;
}
static wm_widget_t t_widgets[2];
void win_widgets_set(window_t *w, wm_widget_t *arr, int n)
{ (void)w; for (int i = 0; i < n && i < 2; i++) t_widgets[i] = arr[i]; }

window_t *win_create(const char *title, int x, int y, int w, int h,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data)
{
    memset(&t_win, 0, sizeof(t_win));
    snprintf(t_win.title, sizeof(t_win.title), "%s", title);
    t_win.x = x; t_win.y = y; t_win.w = w; t_win.h = h;
    t_win.draw = draw; t_win.on_key = on_key; t_win.on_mouse = on_mouse;
    t_win.on_tick = on_tick; t_win.on_close = on_close; t_win.data = data;
    return &t_win;
}

/* ---- net (реестр/стек) ---- */
static u32 t_ip = 0x0A00020F;             /* 10.0.2.15 */
static int t_mode = 0;                    /* авто */
static int t_present[5], t_link[5], t_active = -1;
static const char *t_names[5] = { "e1000", "virtio", "ne2000", "atl1c", "wifi" };
u32  net_get_ip(void) { return t_ip; }
u32  net_tx_packets(void) { return 11; }
u32  net_rx_packets(void) { return 7; }
dhcp_state_t net_dhcp_state(void) { return DHCP_INIT; }   /* не BOUND — как в баге пользователя */
/* net_aton/net_ntoa — как в net.c (семантика хост-порядка) */
int net_aton(const char *str, u32 *out_ip)
{
    u32 vals[4]; int idx = 0; u32 cur = 0; int any = 0;
    const char *p = str;
    while (*p && idx < 4) {
        if (*p >= '0' && *p <= '9') {
            cur = cur * 10 + (u32)(*p - '0'); any = 1;
            if (cur > 255) return 0;
        } else if (*p == '.') {
            if (!any) return 0;
            vals[idx++] = cur; cur = 0; any = 0;
        } else return 0;
        p++;
    }
    if (!any || idx != 3) return 0;
    vals[idx++] = cur;
    *out_ip = (vals[0] << 24) | (vals[1] << 16) | (vals[2] << 8) | vals[3];
    return 1;
}
int net_ntoa(u32 ip, char *out, u32 out_max)
{
    if (out_max < 16) return 0;
    snprintf(out, 16, "%u.%u.%u.%u",
             (unsigned)((ip >> 24) & 0xFF), (unsigned)((ip >> 16) & 0xFF),
             (unsigned)((ip >> 8) & 0xFF), (unsigned)(ip & 0xFF));
    return (int)strlen(out);
}
int  net_adapter_count(void) { int n = 0; for (int i = 0; i < 5; i++) n += t_present[i]; return n; }
int  net_adapter_present(int i) { return (i >= 0 && i < 5) ? t_present[i] : 0; }
const char *net_adapter_name(int i) { return (i >= 0 && i < 5) ? t_names[i] : "?"; }
int  net_adapter_link(int i) { return (i >= 0 && i < 5) ? t_link[i] : 0; }
int  net_adapter_active(void) { return t_active; }
int  net_adapter_mode(void) { return t_mode; }
int  net_adapter_manual_idx(void) { return t_mode - 1; }
int  net_adapter_set_mode(int mode)
{
    if (mode < 0 || mode > 5) return 0;
    if (mode > 0 && !t_present[mode - 1]) return 0;
    t_mode = mode;
    int old = t_active;
    t_active = (mode == 0) ? 2 : mode - 1;
    return t_active != old;
}
void net_request_dhcp(void) { cap_dhcp_req++; }

/* ---- ne2000 ---- */
static int t_ne2000;
int  ne2000_present(void) { return t_ne2000; }
int  ne2000_diag(char *out, int max)
{ snprintf(out, (u32)max, "ne2000: tx=%u rx=%u pkts=%u", 5u, 0u, 3u); return (int)strlen(out); }

/* ---- wifi ---- */
static int t_wifi;
int  wifi_present(void) { return t_wifi; }
int  wifi_pending(void) { return 0; }
const char *wifi_conn_state_name(void) { return "off"; }
const char *wifi_conn_ssid(void) { return ""; }
int  wifi_conn_channel(void) { return 0; }
int  wifi_conn_rssi(void) { return 0; }
int  wifi_conn_secured(void) { return 0; }
wifi_conn_state_t wifi_conn_state(void) { return WIFI_CONN_OFF; }
const char *wifi_chip_name(void) { return "Atheros"; }
int  wifi_profile_load(char *out_ssid, int max) { (void)out_ssid; (void)max; return 0; }
int  wifi_connect(const char *ssid) { (void)ssid; return 1; }
void wifi_disconnect(void) {}

/* ---- net_httpd (сессия 58: галочка веб-сервера в настройках) ---- */
static int t_httpd;
void net_httpd_start(void) { t_httpd = 1; }
void net_httpd_stop(void)  { t_httpd = 0; }
void net_httpd_set_enabled(int on) { t_httpd = on ? 1 : 0; }
int  net_httpd_running(void) { return t_httpd; }
int  net_httpd_wanted(void)  { return t_httpd; }

/* ---- диски/ФС ---- */
static int t_hdd;
int  disk_hdd_present(void) { return t_hdd; }
u32  disk_hdd_sectors(void) { return 0; }
const char *disk_hdd_model(void) { return "TEST"; }
const char *disk_hdd_bus(void) { return "ATA"; }
int  disk_cd_present(void) { return 0; }
int  disk_part_count(void) { return 0; }
const disk_part_t *disk_part(int i) { (void)i; static disk_part_t p; return &p; }
const char *disk_part_fstype(int i) { (void)i; return ""; }
void disk_part_rescan(void) {}
int  fat32_ready(void) { return 0; }
int  fat32_is_usb(void) { return 0; }
int  fat32_init(void) { return 0; }
void fat32_deinit(void) {}
int  fat32_format_hdd(fat32_fmt_progress_t cb, void *ctx, int full)
{ (void)cb; (void)ctx; (void)full; return FAT32_FMT_NO_DISK; }
int  ntfs_ready(void) { return 0; }
void ntfs_invalidate(void) {}
int  sata_pending(void) { return 0; }
int  usb_ehci_storage_ready(void) { return 0; }

/* ---- ramfs ---- */
int  ramfs_ready(void) { return ramfs_ready_flag; }
int  ramfs_delete(const char *name) { (void)name; cfg_valid = 0; return 1; }
int  ramfs_create(const char *name, u32 size)
{ (void)name; (void)size; cfg_valid = 0; return 1; }
int  ramfs_write(const char *name, const void *buf, u32 len)
{ (void)name; if (len < sizeof(cfg_file)) { memcpy(cfg_file, buf, len); cfg_file[len] = 0; cfg_valid = 1; } return 1; }
u32  ramfs_read(const char *name, void *buf, u32 max) { (void)name; (void)buf; (void)max; return 0; }

/* =================== ТЕСТИРУЕМЫЙ КОД ОС =================== */
#include "apps_settings.c"

/* =================== утилиты тестов =================== */
static int fails;
#define CHECK(cond, name) do { \
    if (cond) printf("  ok  %s\n", name); \
    else { printf("  FAIL %s\n", name); fails++; } \
} while (0)

static set_t *t_d(void) { return (set_t *)t_win.data; }

static void keych(char ch)                  /* нажатие символа */
{
    key_event_t ev; memset(&ev, 0, sizeof(ev));
    ev.code = 0x00; ev.ch = ch; ev.flags = 0;
    if (t_win.on_key) t_win.on_key(&t_win, &ev);
}
static void keycode(u8 code, char ch)       /* нажатие спец-клавиши */
{
    key_event_t ev; memset(&ev, 0, sizeof(ev));
    ev.code = code; ev.ch = ch; ev.flags = 0;
    if (t_win.on_key) t_win.on_key(&t_win, &ev);
}
static void click(int mx, int my)           /* ЛКМ */
{
    if (t_win.on_mouse) t_win.on_mouse(&t_win, mx, my, MSB_LEFT, MSB_LEFT);
}

static void app_reopen(void)
{
    if (t_win.data && t_win.on_close)
        t_win.on_close(&t_win);     /* честно освобождаем прошлый set_t */
    cap_closed = 0; cap_invalidated = 0;
    app_settings_open();
}

int main(void)
{
    t_present[2] = 1; t_link[2] = 1; t_active = 2;   /* ne2000 есть */
    t_ne2000 = 1;

    printf("== setnet: настройки «Сеть» (сессия 27) ==\n");

    /* ---------- 1. РЕГРЕССИЯ «полос»: текст ПОВЕРХ выделения ---------- */
    app_reopen();
    cap_reset();
    t_win.draw(&t_win);
    {
        int ti = cap_find_text("[A] Авто");
        CHECK(ti >= 0, "строка «[A] Авто» нарисована");
        int fi = cap_last_fill_under(ti);
        CHECK(fi >= 0, "выделение строки приоритета нарисовано");
        CHECK(fi < ti, "выделение ДО текста (полоса не закрывает строку)");
        /* адаптер: выбран d->sel == активный */
        ti = cap_find_text("ne2000");
        CHECK(ti >= 0, "строка адаптера нарисована");
        fi = cap_last_fill_under(ti);
        CHECK(fi < ti, "у адаптера выделение тоже под текстом");
        /* строка статического режима выделена только в статике: в DHCP — нет заливки строки режима DHCP */
        ti = cap_find_text("[R] DHCP");
        fi = cap_last_fill_under(ti);
        CHECK(fi < 0 || fi < ti, "в DHCP-режиме строка [R] без полосы поверх");
    }

    /* ---------- 2. 'S': применить статический IP ---------- */
    {
        set_t *d = t_d();
        strcpy(d->f_ip, "10.0.2.15");
        strcpy(d->f_mask, "255.255.255.0");
        strcpy(d->f_gw, "10.0.2.2");
        d->f_dns[0] = 0;
        cap_set_static.called = 0; cfg_valid = 0; cfg_file[0] = 0;
        keych('S');
        CHECK(cap_set_static.called, "S: netcfg_set_static вызван");
        CHECK(cap_set_static.ip == 0x0A00020Fu, "S: ip = 10.0.2.15");
        CHECK(cap_set_static.mask == 0xFFFFFF00u, "S: mask = 255.255.255.0");
        CHECK(cap_set_static.gw == 0x0A000202u, "S: gw = 10.0.2.2");
        CHECK(cap_set_static.dns == 0, "S: dns пустой = 0");
        CHECK(g_t_static == 1, "S: режим статический включён");
        CHECK(cfg_valid && strstr(cfg_file, "netmode=static") != NULL,
              "S: SETTINGS.CFG содержит netmode=static");
        CHECK(cfg_valid && strstr(cfg_file, "ip=10.0.2.15") != NULL,
              "S: SETTINGS.CFG содержит ip=10.0.2.15");
        CHECK(cfg_valid && strstr(cfg_file, "gw=10.0.2.2") != NULL,
              "S: SETTINGS.CFG содержит gw=10.0.2.2");
        CHECK(cfg_valid && strstr(cfg_file, "dns=") == NULL,
              "S: пустой DNS не пишется в файл");
        CHECK(d->net_st == 1, "S: статус «применено»");
    }

    /* ---------- 3. 'R': вернуться к DHCP ---------- */
    {
        set_t *d = t_d();
        cap_use_static.called = 0; cfg_valid = 0; cfg_file[0] = 0;
        keych('R');
        CHECK(cap_use_static.called && cap_use_static.on == 0,
              "R: netcfg_use_static(0) вызван");
        CHECK(cfg_valid && strstr(cfg_file, "netmode=dhcp") != NULL,
              "R: SETTINGS.CFG содержит netmode=dhcp");
        CHECK(d->net_st == 1, "R: статус-строка обновлена");
    }

    /* ---------- 4. редактор полей ---------- */
    {
        set_t *d = t_d();
        d->f_ip[0] = 0; d->edit = 0;
        cap_invalidated = 0;
        keych('1'); keych('0'); keych('.'); keych('0');
        CHECK(strcmp(d->f_ip, "10.0") == 0, "ввод цифр/точки: «10.0»");
        CHECK(d->tab == 0, "цифра «1» при вводе НЕ переключает вкладку");
        keycode(0x0E, '\b');                    /* Backspace */
        CHECK(strcmp(d->f_ip, "10.") == 0, "Backspace стирает символ");
        keych('2');
        CHECK(strcmp(d->f_ip, "10.2") == 0, "ввод после Backspace");
        /* лимит буфера (15 символов) */
        d->f_ip[0] = 0;
        for (int i = 0; i < 30; i++) keych('9');
        CHECK(strlen(d->f_ip) == 15, "буфер поля не переполняется (15)");
        /* Up/Down между полями */
        d->f_ip[0] = 0;
        d->edit = 0;
        keycode(KBD_DOWN, 0);
        CHECK(d->edit == 1, "Down: следующее поле (маска)");
        keycode(KBD_UP, 0);
        CHECK(d->edit == 0, "Up: предыдущее поле (IP)");
        keycode(KBD_UP, 0);
        CHECK(d->edit == 3, "Up с первого поля уходит на DNS (цикл)");
        /* Esc выходит из поля и НЕ закрывает окно */
        d->edit = 2;
        cap_closed = 0;
        keych(0x1B);
        CHECK(d->edit == -1 && cap_closed == 0,
              "Esc в поле: выход из редактирования, окно живо");
        /* Esc вне поля закрывает окно */
        keych(0x1B);
        CHECK(cap_closed == 1, "Esc вне поля закрывает окно");
        /* '1' вне редактирования переключает вкладку */
        app_reopen();
        keych('2');
        CHECK(t_d()->tab == 1, "цифра «2» вне поля: вкладка «Диски»");
        keych('1');
        CHECK(t_d()->tab == 0, "цифра «1» вне поля: вкладка «Сеть»");
        /* 'E' включает/выключает редактирование */
        keych('E');
        CHECK(t_d()->edit == 0, "E: фокус в поле IP");
        keych('E');
        CHECK(t_d()->edit == -1, "E повторно: редактирование выключено");
    }

    /* ---------- 5. валидация ---------- */
    {
        set_t *d = t_d();
        strcpy(d->f_ip, "abc");
        cap_set_static.called = 0;
        keych('S');
        CHECK(!cap_set_static.called, "кривой IP: set_static НЕ вызван");
        CHECK(d->net_st == 2, "кривой IP: статус ошибки");
        CHECK(cap_closed == 0, "ошибка не закрывает окно");
    }

    /* ---------- 6. пустая маска = /24 ---------- */
    {
        set_t *d = t_d();
        strcpy(d->f_ip, "192.168.1.50");
        d->f_mask[0] = 0;
        d->f_gw[0] = 0;
        d->f_dns[0] = 0;
        cap_set_static.called = 0;
        keych('S');
        CHECK(cap_set_static.called, "пустая маска: применение прошло");
        CHECK(cap_set_static.mask == 0xFFFFFF00u, "пустая маска = 255.255.255.0");
        CHECK(cap_set_static.gw == 0 && cap_set_static.dns == 0,
              "пустые шлюз/DNS = 0");
        CHECK(cap_set_static.ip == 0xC0A80132u, "ip = 192.168.1.50");
    }

    /* ---------- 7. мышь ---------- */
    {
        app_reopen();
        set_t *d = t_d();
        cap_reset();
        t_win.draw(&t_win);
        /* клик по полю «Маска» (action ACT_NET_FIELD+1) */
        int found = 0;
        for (int i = 0; i < d->hot_n; i++)
            if (d->hot[i].action == ACT_NET_FIELD + 1) {
                d->edit = -1;
                click(d->hot[i].x + 2, d->hot[i].y + 2);
                found = 1;
                break;
            }
        CHECK(found, "горячая зона поля «Маска» существует");
        CHECK(d->edit == 1, "клик по полю даёт фокус");
        /* клик по строке DHCP-режима */
        for (int i = 0; i < d->hot_n; i++)
            if (d->hot[i].action == ACT_NET_DHCP) {
                cap_use_static.called = 0;
                click(d->hot[i].x + 2, d->hot[i].y + 2);
                break;
            }
        CHECK(cap_use_static.called && cap_use_static.on == 0,
              "клик «[R] DHCP» = возврат к DHCP");
        /* клик по строке «Статический» = применить */
        for (int i = 0; i < d->hot_n; i++)
            if (d->hot[i].action == ACT_NET_STATIC) {
                cap_set_static.called = 0;
                strcpy(d->f_ip, "10.0.2.99");
                click(d->hot[i].x + 2, d->hot[i].y + 2);
                break;
            }
        CHECK(cap_set_static.called && cap_set_static.ip == 0x0A000263u,
              "клик «[S] Статический» применяет поля");
    }

    /* ---------- 8. Enter в поле применяет статику ---------- */
    {
        set_t *d = t_d();
        strcpy(d->f_ip, "10.9.9.9");
        strcpy(d->f_mask, "255.255.0.0");
        d->edit = 0;
        cap_set_static.called = 0;
        keycode(0x1C, '\n');
        CHECK(cap_set_static.called && cap_set_static.ip == 0x0A090909u,
              "Enter в поле = применить");
        CHECK(cap_set_static.mask == 0xFFFF0000u, "маска 255.255.0.0 принята");
    }

    /* ---------- 9. подсказка про 86Box на вкладке ---------- */
    {
        app_reopen();               /* net_st=0 — видна именно подсказка */
        cap_reset();
        t_win.draw(&t_win);
        int ti = cap_find_text("86Box");
        CHECK(ti >= 0, "подсказка про 86Box/SLiRP присутствует");
    }

    /* ---------- 10. окно влезает: последняя строка не ниже контента ---------- */
    {
        cap_reset();
        t_content_h = 500 - 24 - 16;    /* wh=500 минус заголовок и статус */
        t_win.draw(&t_win);
        int below = 0;
        for (int i = 0; i < cap_n; i++)
            if (cap[i].kind == 0 && cap[i].y > t_content_h - 15 && cap[i].y < t_content_h)
                below++;
        (void)below;
        /* главное: строка WIFI-статуса не уехала за статус-бар */
        int ti = cap_find_text("Адаптер не найден");
        CHECK(ti < 0 || cap[ti].y < t_content_h,
              "WIFI-блок укладывается в окно 500px");
        t_content_h = 460;
    }

    /* ---------- 11. сессия 62: чекбокс веб-сервера на вкладке «Сеть» ---------- */
    {
        app_reopen();
        set_t *d = t_d();
        cap_reset();
        t_win.draw(&t_win);
        CHECK(d->websrv_y > 0, "чекбокс веб-сервера получил Y при отрисовке");
        CHECK(cap_find_text("Статус:") >= 0,
              "статусная строка веб-сервера отрисована");
        /* клик по чекбоксу (зона от x=8, ширина квадрат+подпись) */
        t_httpd = 0;                    /* сервер выключен */
        click(8 + 4, d->websrv_y + 2);
        CHECK(t_httpd == 1, "клик по выключенному чекбоксу включает сервер");
        click(8 + 4, d->websrv_y + 2);
        CHECK(t_httpd == 0, "повторный клик выключает сервер");
        /* до первой отрисовки чекбокс не ловит клики (Y = -1000,
         * реальные my >= 0 в зону [-1002,-986) не попадают) */
        app_reopen();
        d = t_d();
        CHECK(d->websrv_y <= -1000, "до отрисовки Y чекбокса = -1000");
        cap_reset();
        click(8 + 4, 0);                /* реальная координата у верхней кромки */
        CHECK(t_httpd == 0, "клик до первой отрисовки не переключает сервер");
    }

    printf("\n== итог: %s (провалов: %d) ==\n", fails ? "ЕСТЬ ПРОВАЛЫ" : "все проверки пройдены", fails);
    return fails ? 1 : 0;
}
