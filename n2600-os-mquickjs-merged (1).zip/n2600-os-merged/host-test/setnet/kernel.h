/* kernel.h — глобальные службы ядра */
#ifndef KERNEL_H
#define KERNEL_H

#include "types.h"
#include "boot.h"

const mb_info_t *mb_info(void);
void sys_reboot(void);
void sys_poweroff(void);

/* Журнал загрузки (klog): кольцевой буфер строк. Каждая строка dbg()/
 * dbg_err() + ключевые вехи kmain попадают сюда; команда dmesg в
 * терминале выводит журнал целиком («процесс загрузки»). */
void        klog_puts(const char *s);       /* добавить строку (без \n) */
const char *klog_get(void);                 /* весь журнал, '\n'-разделённый */
int         klog_line_count(void);

/* Сессия 11: 0/1 = фоновая инициализация SATA идёт/не идёт (fileman
 * показывает «инициализация...» вместо пустого списка до готовности). */
int sata_pending(void);

/* Сессия 15: 0/1 = фоновая инициализация WiFi идёт/не идёт (нетбук
 * больше НЕ ждёт адаптер при загрузке: PCI-скан + сброс + калибровки
 * AR9485 занимали секунды — рабочий стол поднимается сразу, адаптер
 * «доезжает» позже; WiFi-приложение и Настройки показывают статус). */
int wifi_pending(void);

/* Сессия 11: перезапросить DHCP на активном адаптере (netmon). */
void net_request_dhcp(void);

/* Сессия 27: статическая настройка IP (Настройки → Сеть, SETTINGS.CFG).
 * Пока включён статический режим, netmon НЕ запускает DHCP, а применяет
 * сохранённые адреса к активному адаптеру (повторно — после его смены). */
int  netcfg_static_mode(void);                 /* 1 = статический, 0 = DHCP */
void netcfg_use_static(int on);                /* переключить режим */
void netcfg_set_static(u32 ip, u32 mask, u32 gw, u32 dns); /* применить */
void netcfg_static_get(u32 *ip, u32 *mask, u32 *gw, u32 *dns); /* для UI */

#endif
