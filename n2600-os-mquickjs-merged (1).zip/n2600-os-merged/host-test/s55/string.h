/* string.h — хост-заглушка: libc + snprintf (в ядре — из string.c) */
#ifndef STRING_H
#define STRING_H
#include_next <string.h>
#include <stdio.h>
#endif
