/* ramfs.h — хост-заглушка: RAM disk = каталог "ramfs_test/" рядом с тестом.
 *
 * Сессия 67: раньше RAM disk был полностью пуст (img_decode_url можно
 * было проверить только на resolve-уровне). Промежуточный вариант с
 * таблицей файлов в static-переменных заголовка НЕ работает: заголовок
 * включается в ДВА блока трансляции (s55_test.c и imgsvc.c) — у каждого
 * своя копия состояния. Каталог на файловой системе даёт ОБЕИМ сторонам
 * одно состояние (ramfs_list/ramfs_read читают диск).
 * Имена — полные пути без ведущего '/', как в ядре ("LOGO.PNG",
 * "docs/pic.png"). POSIX-only: это хост-заглушка, ядро её не включает. */
#ifndef RAMFS_H
#define RAMFS_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#define RAMFS_NAME_MAX 64

typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    unsigned size;
    unsigned offset;
    unsigned char is_dir;
} ramfs_dirent_t;

#define RAMFS_TEST_ROOT "ramfs_test"

/* Положить файл в тестовый RAM disk (каталоги создаются автоматически).
 * Возвращает 1 при успехе. */
static inline int ramfs_test_put(const char *name, const unsigned char *data,
                                 unsigned len)
{
    char path[512];
    /* "ramfs_test/" — слэш-разделитель обязателен, иначе имя склеится
     * с корнем ("ramfs_testLOGO.PNG" рядом с каталогом) */
    int n = snprintf(path, sizeof(path), "%s/", RAMFS_TEST_ROOT);
    if (n < 0) return 0;
    mkdir(path, 0755);
    for (const char *q = name; *q; q++) {
        if (*q == '/' && q != name) {
            path[n] = 0;
            mkdir(path, 0755);
        }
        if (n < (int)sizeof(path) - 1) path[n++] = *q;
    }
    path[n] = 0;
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    if (len) fwrite(data, 1, len, f);
    fclose(f);
    return 1;
}

/* Рекурсивный обход: полные пути ("docs/pic.png") в out[]. */
static inline int ramfs__walk(const char *prefix, ramfs_dirent_t *out,
                              int max, int count)
{
    char dpath[512];
    snprintf(dpath, sizeof(dpath), "%s/%s", RAMFS_TEST_ROOT, prefix);
    DIR *d = opendir(dpath);
    if (!d) return count;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && count < max) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        char full[512];   /* имя обрежется до RAMFS_NAME_MAX при записи */
        snprintf(full, sizeof(full), "%s%s%s", prefix,
                 prefix[0] ? "/" : "", e->d_name);
        char fpath[512];
        snprintf(fpath, sizeof(fpath), "%s/%s", RAMFS_TEST_ROOT, full);
        struct stat st;
        if (stat(fpath, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) {
            count = ramfs__walk(full, out, max, count);
        } else {
            memset(&out[count], 0, sizeof(out[count]));
            strncpy(out[count].name, full, RAMFS_NAME_MAX);
            out[count].name[RAMFS_NAME_MAX] = 0;
            out[count].size = (unsigned)st.st_size;
            out[count].is_dir = 0;
            count++;
        }
    }
    closedir(d);
    return count;
}

static inline int ramfs_init(void) { return 1; }
static inline int ramfs_ready(void) { return 1; }

static inline int ramfs_list(ramfs_dirent_t *out, int max)
{
    return ramfs__walk("", out, max, 0);
}

static inline unsigned ramfs_read(const char *nm, void *b, unsigned m)
{
    char path[512];
    snprintf(path, sizeof(path), "%s/%s", RAMFS_TEST_ROOT, nm);
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    unsigned n = (unsigned)fread(b, 1, m, f);
    fclose(f);
    return n;
}

#endif
