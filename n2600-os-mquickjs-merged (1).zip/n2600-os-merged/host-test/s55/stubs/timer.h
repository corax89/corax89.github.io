#ifndef TIMER_H
#define TIMER_H
static inline unsigned timer_ticks(void) { return 0; }
#endif
