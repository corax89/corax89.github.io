#ifndef TASK_H
#define TASK_H
static inline int task_current(void) { return 0; }
static inline void task_yield(void) {}
#endif
