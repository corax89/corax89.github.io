/* mem.h — хост-заглушка: куча = libc */
#ifndef MEM_H
#define MEM_H
#include_next <stdlib.h>
#endif
