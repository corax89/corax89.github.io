/* stb_image.c — единственная единица трансляции stb_image.h в ядре
 * N2600-OS (Session 55: картинки в браузере/интерпретаторе).
 *
 * Конфигурация для freestanding-ядра (-m32, без libc, без SSE):
 *   STBI_NO_STDIO        — чтение только из памяти (ramfs/сеть);
 *   STBI_NO_SIMD         — ядро не включает SSE, целевой x87;
 *   STBI_NO_HDR/NO_LINEAR— float-путь HDR не нужен (и <math.h> не нужен);
 *   STBI_ONLY_PNG/JPEG/BMP/GIF — форматы веба (zlib встроен в stb);
 *   STBI_MAX_DIMENSIONS 8192 — защита от декомпрессионных бомб;
 *   STBI_MALLOC/REALLOC_SIZED/FREE — куча ядра (mem.h). realloc в ядре
 *     нет: реализуем через malloc+memcpy+free (STBI_REALLOC_SIZED даёт
 *     старый размер — этого достаточно, stb больше нигде realloc не
 *     зовёт);
 *   STBI_ASSERT — отключён (assert.h libc недоступен).
 *
 * Все обращения извне — через imgsvc.c/imgsvc.h (глобальный лок: stb
 * не реентерабелен, а x87-состояние ядра не сохраняется планировщиком).
 */
#include "types.h"
#include "mem.h"
#include "string.h"

#define STBI_NO_STDIO
#define STBI_NO_SIMD
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_ONLY_BMP
#define STBI_ONLY_GIF
#define STBI_MAX_DIMENSIONS 8192

/* Сессия 62: ЗАПРЕТ thread_local в stb (stbi__g_failure_reason,
 * stbi__vertically_flip_on_load и др.). Причины:
 *  1) MinGW i686 (сборка build.bat, PE-цель) реализует _Thread_local
 *     через emutls — каждая переменная тянет вызов __emutls_get_address
 *     из libgcc, а линковка идёт с -nostdlib БЕЗ -lgcc => undefined
 *     reference to `__emutls_get_address` (ошибка сборки на Windows);
 *  2) в ядре нет и не может быть TLS-рантайма: GS = селектор 0x10
 *     (flat, base 0), поэтому даже ELF-сборка gcc -m32 обращалась бы
 *     через %gs:смещение к НИЖНЕЙ памяти (запись портила бы её).
 * С STBI_NO_THREAD_LOCALS все переменные stb — обычные static:
 * imgsvc сериализует декодирование общим FPU-локом, гонок нет. */
#define STBI_NO_THREAD_LOCALS

#define STBI_MALLOC(sz)       malloc((u32)(sz))
#define STBI_FREE(p)          free(p)
#define STBI_REALLOC_SIZED(p, oldsz, newsz) \
                              stbi_krealloc((p), (oldsz), (newsz))
#define STBI_ASSERT(x)        ((void)0)

/* stb (BMP-загрузчик) зовёт abs(); во freestanding libc-функции нет —
 * раскрываем во встроенную операцию GCC. */
#define abs(x) __builtin_abs(x)

/* realloc в ядре нет: новый блок + перенос min(oldsz,newsz).
 * Определён ДО включения stb_image.h — используется его кодом. */
static void *stbi_krealloc(void *p, u32 oldsz, u32 newsz)
{
    void *q;
    if (newsz == 0) { if (p) free(p); return NULL; }
    q = malloc((u32)newsz);
    if (!q) return NULL;
    if (p) {
        if (oldsz > newsz) oldsz = newsz;
        if (oldsz) memcpy(q, p, oldsz);
        free(p);
    }
    return q;
}

/* stb содержит избыточные проверки (предупреждения -Wextra) и локальные
 * переменные-тени; функциональность проверена upstream-тестами — шум
 * диагностики для этой единицы отключаем. */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wall"
#pragma GCC diagnostic ignored "-Wextra"
#pragma GCC diagnostic ignored "-Wsign-compare"
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#pragma GCC diagnostic ignored "-Wtype-limits"
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#pragma GCC diagnostic pop
