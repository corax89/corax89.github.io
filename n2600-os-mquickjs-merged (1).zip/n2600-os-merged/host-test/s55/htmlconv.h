/* htmlconv.h — HTML -> Markdown конвертер N2600-OS.
 *
 * Выделен из apps_browser.c в отдельный модуль:
 *   1) конвертер нужен и браузеру, и терминалу (curl), и хостовому тесту
 *      (scripts/test_htmlconv.c) — единая точка правды;
 *   2) буфер результата передаётся ВЫЗЫВАЮЩИМ (раньше был static char
 *      md[8192] внутри браузера — общий на все окна, см. FIX [H2]).
 *
 * Соглашения:
 *   html_to_md(html, html_len, md, md_max) — все границы проверяются,
 *   результат НЕ выходит за md_max-2, всегда NUL-терминирован (md[len]=0).
 *   Возвращает длину результата. При нехватке места — обрезка.
 */
#ifndef HTMLCONV_H
#define HTMLCONV_H

#ifdef __cplusplus
extern "C" {
#endif

int html_to_md(const char *html, int html_len, char *md, int md_max);

#ifdef __cplusplus
}
#endif

#endif /* HTMLCONV_H */
