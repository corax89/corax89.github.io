#!/bin/sh
# run_s55.sh — хост-тест сессии 55: htmlconv/brpage/brlines/imgsvc(stb).
# Схема как в host-test/rtlwifi: НАСТОЯЩИЕ исходники копируются в каталог
# харнесса, где их quote-включения затеняются заглушками окружения (stubs/).
# Использование: ./run_s55.sh [asan]
set -e
cd "$(dirname "$0")"

# работает и из host-test/s55 (внутри дерева), и из work/test/s55
SRC=../../src
RAMD=../../ramdisk
[ -d "$SRC" ] || { SRC=../../n2600/src; RAMD=../../n2600/ramdisk; }

# 1) свежие копии настоящих исходников/заголовков
for f in imgsvc.c imgsvc.h stb_image.c stb_image.h htmlconv.c htmlconv.h \
         brlines.h brpage.h types.h utf8.h; do
    cp $SRC/$f .
done

# 2) демо-картинка (та же, что в RAM disk)
cp $RAMD/LOGO.PNG sample.png

FLAGS="-std=c99 -g -Wall -Wextra -Wno-unused-parameter"
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address -fno-omit-frame-pointer"
    BIN=s55_test_asan
else
    BIN=s55_test
fi

# 3) htmlconv — хостовой вариант (libc <string.h>, без -I: системные)
gcc $FLAGS -DHOST_TEST -c htmlconv.c -o htmlconv_h.o
# 4) stb + imgsvc (заглушки mem/sync/ramfs/net/timer/task — в каталоге stubs,
#    копируются рядом, чтобы затенять одноимённые заголовки ядра)
cp stubs/*.h .
gcc $FLAGS -c stb_image.c -o stb_image_h.o
gcc $FLAGS -c imgsvc.c    -o imgsvc_h.o
# 5) сам тест
gcc $FLAGS s55_test.c htmlconv_h.o stb_image_h.o imgsvc_h.o -o $BIN -lm

echo "== Запуск $BIN =="
./$BIN sample.png
