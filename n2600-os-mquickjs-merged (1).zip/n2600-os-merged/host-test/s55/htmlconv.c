/* htmlconv.c — HTML -> Markdown конвертер (упрощённый) для N2600-OS.
 *
 * Поддерживаемые теги:
 *   <h1>-<h6>      -> # .. ###### (+ пробел), закрывающие теги дают перевод строки
 *   <p>            -> пустая строка, </p> -> перевод строки
 *   <br>           -> \n
 *   <hr>           -> ---
 *   <b>/<strong>   -> **      </b>/<strong> -> **
 *   <i>/<em>       -> *       </i>/<em>     -> *
 *   <code>         -> `       </code>       -> `
 *   <pre>          -> ``` \n  </pre>        -> ``` \n
 *   <ul>/<ol>      -> блочный вход в список, </ul>/</ol> -> выход из списка
 *   <li>           -> - или N. (с новой строки, с отступом при вложенности)
 *   <a href=...>   -> [       </a>          -> ](href) — ПОЛНАЯ markdown-
 *                     ссылка: браузер делает её кликабельной (сессия 55);
 *                     <a> без href даёт ]() как раньше
 *   <img src=...>  -> СТРОКА-МАРКЕР ![alt](src) собственным абзацем —
 *                     браузер грузит и показывает картинку (сессия 55);
 *                     <img> без src пропускается
 *   <script>/<style> и их содержимое пропускаются до соответствующего тега
 *   комментарии, DOCTYPE, processing instructions пропускаются
 *   прочие теги удаляются, содержимое сохраняется
 *
 * Entities:
 *   &amp; &lt; &gt; &quot; &nbsp; &#39; &apos;
 *   числовые: &#65; &#x41; и т.п. (не-ASCII печатается как '?')
 *
 * Примечание:
 *   Эта версия сознательно не делает полную поддержку ссылок с href,
 *   таблиц, blockquote и всех HTML-сущностей, чтобы не сильно раздувать код.
 */

#ifdef HOST_TEST
#include <string.h>   /* хостовой тест: стандартная библиотека */
#else
#include "string.h"   /* ядро: freestanding-версия (src/string.c) */
#include "types.h"
#endif

#include "htmlconv.h"

#define HTML_LIST_MAX 8

/* Значение атрибута name в области атрибутов тега html[s..e)
 * (name в любом регистре). Значение — в кавычках или до пробела.
 * Возвращает длину значения (0 = атрибут не найден). */
static int html_attr(const char *html, int s, int e, const char *name,
                     char *out, int out_max)
{
    int i = s;
    int nl = 0;
    while (name[nl]) nl++;
    out[0] = 0;
    if (out_max <= 0) return 0;
    out[out_max - 1] = 0;

    while (i < e) {
        /* пропуск разделителей */
        while (i < e && (html[i] == ' ' || html[i] == '\t' ||
                         html[i] == '\n' || html[i] == '\r' ||
                         html[i] == '/'))
            i++;
        if (i >= e) break;

        /* имя атрибута */
        int ns = i;
        while (i < e && html[i] != '=' && html[i] != ' ' &&
               html[i] != '\t' && html[i] != '\n' && html[i] != '\r' &&
               html[i] != '>' && html[i] != '/')
            i++;

        /* сравнить с name (без регистра) */
        int match = (i - ns) == nl;
        if (match) {
            for (int j = 0; j < nl; j++) {
                char a = html[ns + j], b = name[j];
                if (a >= 'A' && a <= 'Z') a += 32;
                if (b >= 'A' && b <= 'Z') b += 32;
                if (a != b) { match = 0; break; }
            }
        }

        /* до '=' или к следующему атрибуту */
        int j2 = i;
        while (j2 < e && html[j2] != '=' && html[j2] != ' ' &&
               html[j2] != '\t' && html[j2] != '\n' && html[j2] != '\r')
            j2++;

        if (match && j2 < e && html[j2] == '=') {
            int vs = j2 + 1;
            while (vs < e && (html[vs] == ' ' || html[vs] == '\t')) vs++;
            int ve;
            if (vs < e && (html[vs] == '"' || html[vs] == '\'')) {
                char q = html[vs++];
                ve = vs;
                while (ve < e && html[ve] != q) ve++;
            } else {
                ve = vs;
                while (ve < e && html[ve] != ' ' && html[ve] != '\t' &&
                       html[ve] != '\n' && html[ve] != '\r' && html[ve] != '>')
                    ve++;
            }
            int len = ve - vs;
            if (len > out_max - 1) len = out_max - 1;
            if (len < 0) len = 0;
            if (len) memcpy(out, html + vs, (unsigned)len);
            out[len] = 0;
            return len;
        }

        /* не наш атрибут: продвинуться ЗА '=' и его значение (иначе
         * i залипает на '=' — бесконечный цикл; FIX сессии 55). */
        i = j2;
        if (i < e && html[i] == '=') {
            i++;
            if (i < e && (html[i] == '"' || html[i] == '\'')) {
                char q = html[i++];
                while (i < e && html[i] != q) i++;
                if (i < e) i++;          /* закрывающая кавычка */
            } else {
                while (i < e && html[i] != ' ' && html[i] != '\t' &&
                       html[i] != '\n' && html[i] != '\r' && html[i] != '>')
                    i++;
            }
        }
    }
    return 0;
}

/* Макросы безопасного вывода.
 *
 * ВНИМАНИЕ: они используют локальные переменные функции:
 *   md, md_max, mi
 * и метку:
 *   finish
 *
 * ENSURE(n) проверяет, что в буфере есть место под ещё как минимум n байт.
 * PUT(c) безопасно пишет один байт.
 */
#define ENSURE(n) \
    do { \
        if ((md_max - 1 - mi) < (n)) \
            goto finish; \
    } while (0)

#define PUT(c) \
    do { \
        if (mi >= md_max - 1) \
            goto finish; \
        md[mi++] = (c); \
    } while (0)

#define PUT_STR(s) \
    do { \
        const char *_ps = (s); \
        while (*_ps) { \
            PUT(*_ps); \
            _ps++; \
        } \
    } while (0)

/* Удалить пробелы перед переводом строки, чтобы не было " \n". */
#define TRIM_SPACES() \
    do { \
        while (mi > 0 && md[mi - 1] == ' ') \
            --mi; \
    } while (0)

/* Перевод строки с удалением хвостовых пробелов. */
#define EMIT_NL() \
    do { \
        TRIM_SPACES(); \
        PUT('\n'); \
    } while (0)

/* Гарантировать хотя бы один перевод строки в конце вывода. */
#define ENSURE_NL() \
    do { \
        if (mi == 0 || md[mi - 1] != '\n') \
            EMIT_NL(); \
    } while (0)

/* Гарантировать пустую строку (два перевода строки в конце), но не
 * создавать пустые блоки в самом начале вывода.
 */
#define ENSURE_BLANK() \
    do { \
        if (mi > 0) { \
            ENSURE_NL(); \
            if (mi < 2 || md[mi - 2] != '\n') \
                PUT('\n'); \
        } \
    } while (0)

/* Как ENSURE_NL, но не удаляет хвостовые пробелы.
 * Нужно для закрытия <pre>, чтобы не потерять пробелы в коде.
 */
#define ENSURE_NL_RAW() \
    do { \
        if (mi == 0 || md[mi - 1] != '\n') \
            PUT('\n'); \
    } while (0)

int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    int mi = 0;
    int i = 0;

    int pre_mode = 0;
    int pre_first = 0;

    char tag[32];
    int tag_i;

    int t;
    char c;
    char a;
    char q;

    int list_depth = 0;
    unsigned char list_type[HTML_LIST_MAX];   /* 0 = ul, 1 = ol */
    int list_count[HTML_LIST_MAX];

    int is_script;
    int is_style;
    const char *name;
    int nlen;
    int j;
    int k;
    char lc;
    char delim;

    int rem;
    int base;
    int start;
    int val;
    int digit;
    char e;

    char num[12];
    int v;
    int n;
    int depth;

    /* сессия 55: href последней открытой <a> и область атрибутов тега */
    char last_href[220];
    int  attr_s;
    int  attr_e;

    if (!html || !md || html_len <= 0 || md_max < 4) {
        if (md && md_max > 0)
            md[0] = 0;
        return 0;
    }

    last_href[0] = 0;

    while (i < html_len) {
        if (mi >= md_max - 1)
            break;

        c = html[i];

        /* ------------------------------------------------------------
         * Обработка тегов.
         * ------------------------------------------------------------ */
        if (c == '<') {
            /* HTML-комментарий: <!-- ... -->
             * Пропускаем до -->.
             */
            if (html_len - i >= 4 &&
                html[i + 1] == '!' &&
                html[i + 2] == '-' &&
                html[i + 3] == '-') {

                i += 4;

                while (html_len - i >= 3 &&
                       !(html[i] == '-' &&
                         html[i + 1] == '-' &&
                         html[i + 2] == '>')) {
                    i++;
                }

                if (html_len - i >= 3)
                    i += 3;
                else
                    i = html_len;

                continue;
            }

            /* DOCTYPE, declaration, processing instruction:
             * <!DOCTYPE html>, <?xml ...?> и т.п.
             * Упрощённо пропускаем до '>'.
             */
            if (html_len - i >= 2 &&
                (html[i + 1] == '!' || html[i + 1] == '?')) {
                while (i < html_len && html[i] != '>')
                    i++;
                if (i < html_len)
                    i++;
                continue;
            }

            /* Читаем имя тега.
             * '/' в начале — часть имени закрывающего тега.
             * Пробельный символ или '/' после имени — начало атрибутов.
             */
            tag_i = 0;
            i++;

            while (i < html_len && html[i] != '>' && tag_i < 31) {
                if (html[i] == ' ' ||
                    html[i] == '\t' ||
                    html[i] == '\n' ||
                    html[i] == '\r') {
                    break;
                }

                if (html[i] == '/' && tag_i > 0)
                    break;

                tag[tag_i++] = html[i++];
            }

            tag[tag_i] = 0;

            /* Приводим имя тега к нижнему регистру.
             * Это убирает необходимость писать пары "h1"/"H1".
             */
            for (t = 0; t < tag_i; ++t) {
                if (tag[t] >= 'A' && tag[t] <= 'Z')
                    tag[t] = (char)(tag[t] | 0x20);
            }

            /* Область атрибутов: от конца имени до '>' (сессия 55:
             * нужна html_attr для href/src тегов <a> и <img>). */
            attr_s = i;

            /* Пропускаем атрибуты до '>'.
             * Учитываем кавычки, чтобы атрибут вида:
             *   title="foo > bar"
             * не ломал разбор.
             */
            q = 0;

            while (i < html_len) {
                a = html[i];

                if (q) {
                    if (a == q)
                        q = 0;
                } else if (a == '"' || a == '\'') {
                    q = a;
                } else if (a == '>') {
                    break;
                }

                i++;
            }

            attr_e = i;                    /* позиция '>' или конца html */

            if (i < html_len)
                i++;

            /* Пустой тег <> — просто пропускаем. */
            if (tag_i == 0)
                continue;

            /* Внутри <pre> игнорируем все теги, кроме </pre>.
             * Это заставляет <pre><code>...</code></pre> работать
             * как нормальный fenced code block без лишних `.
             */
            if (pre_mode && strcmp(tag, "/pre") != 0)
                continue;

            /* Пропуск содержимого <script> и <style>.
             *
             * Старая версия останавливалась на любом закрывающем теге.
             * Теперь ищем именно </script> или </style>.
             */
            is_script = !strcmp(tag, "script");
            is_style  = !strcmp(tag, "style");

            if (is_script || is_style) {
                name = is_script ? "script" : "style";
                nlen = is_script ? 6 : 5;

                while (i < html_len) {
                    if (html[i] == '<' &&
                        i + 1 < html_len &&
                        html[i + 1] == '/') {

                        j = i + 2;
                        k = 0;

                        while (j < html_len && k < nlen) {
                            lc = html[j];

                            if (lc >= 'A' && lc <= 'Z')
                                lc = (char)(lc | 0x20);

                            if (lc != name[k])
                                break;

                            j++;
                            k++;
                        }

                        if (k == nlen) {
                            delim = (j < html_len) ? html[j] : '>';

                            if (delim == '>' ||
                                delim == ' ' ||
                                delim == '\t' ||
                                delim == '\n' ||
                                delim == '\r' ||
                                delim == '/') {

                                while (j < html_len && html[j] != '>')
                                    j++;

                                if (j < html_len)
                                    j++;

                                i = j;
                                break;
                            }
                        }
                    }

                    i++;
                }

                continue;
            }

            /* --------------------------------------------------------
             * Преобразование тегов в Markdown.
             * -------------------------------------------------------- */

            /* Заголовки <h1> ... <h6> */
            if (tag[0] == 'h' &&
                tag[1] >= '1' &&
                tag[1] <= '6' &&
                tag[2] == 0) {

                v = tag[1] - '0';

                if (mi > 0)
                    ENSURE_NL();

                ENSURE(v + 1);

                while (v--)
                    PUT('#');

                PUT(' ');
            }

            /* Закрывающие заголовки </h1> ... </h6> */
            else if (tag[0] == '/' &&
                     tag[1] == 'h' &&
                     tag[2] >= '1' &&
                     tag[2] <= '6' &&
                     tag[3] == 0) {
                if (mi > 0)
                    ENSURE_NL();
            }

            /* Параграфы */
            else if (!strcmp(tag, "p")) {
                ENSURE_BLANK();
            } else if (!strcmp(tag, "/p")) {
                if (mi > 0)
                    ENSURE_NL();
            }

            /* <br> */
            else if (!strcmp(tag, "br")) {
                EMIT_NL();
            }

            /* <hr> */
            else if (!strcmp(tag, "hr")) {
                if (mi > 0)
                    ENSURE_NL();

                ENSURE(4);
                PUT('-');
                PUT('-');
                PUT('-');
                PUT('\n');
            }

            /* Жирный */
            else if (!strcmp(tag, "b") || !strcmp(tag, "strong")) {
                ENSURE(2);
                PUT('*');
                PUT('*');
            }

            /* Курсив */
            else if (!strcmp(tag, "i") || !strcmp(tag, "em")) {
                PUT('*');
            }

            /* Инлайн код */
            else if (!strcmp(tag, "code")) {
                PUT('`');
            }

            /* Открытие preformatted / code block */
            else if (!strcmp(tag, "pre")) {
                if (!pre_mode) {
                    if (mi > 0)
                        ENSURE_NL();

                    ENSURE(4);
                    PUT('`');
                    PUT('`');
                    PUT('`');
                    PUT('\n');

                    pre_mode = 1;
                    pre_first = 1;
                }
            }

            /* Закрытие pre */
            else if (!strcmp(tag, "/pre")) {
                if (pre_mode) {
                    ENSURE_NL_RAW();

                    ENSURE(4);
                    PUT('`');
                    PUT('`');
                    PUT('`');
                    PUT('\n');

                    pre_mode = 0;
                    pre_first = 0;
                }
            }

            /* Списки */
            else if (!strcmp(tag, "ul") || !strcmp(tag, "ol")) {
                if (mi > 0)
                    ENSURE_NL();

                if (list_depth < HTML_LIST_MAX) {
                    list_type[list_depth] = (unsigned char)
                        (!strcmp(tag, "ol") ? 1 : 0);
                    list_count[list_depth] = 0;
                    list_depth++;
                }
            }

            else if (!strcmp(tag, "/ul") || !strcmp(tag, "/ol")) {
                if (list_depth > 0)
                    list_depth--;

                if (mi > 0)
                    ENSURE_NL();
            }

            else if (!strcmp(tag, "li")) {
                if (mi > 0)
                    ENSURE_NL();

                /* Отступ для вложенных списков: 2 пробела на уровень. */
                for (depth = 1; depth < list_depth; ++depth) {
                    ENSURE(2);
                    PUT(' ');
                    PUT(' ');
                }

                /* Нумерация, если внутри <ol>. */
                if (list_depth > 0 && list_type[list_depth - 1]) {
                    v = ++list_count[list_depth - 1];
                    n = 0;

                    if (v == 0) {
                        PUT('0');
                    } else {
                        while (v > 0 && n < (int)sizeof(num)) {
                            num[n++] = (char)('0' + (v % 10));
                            v /= 10;
                        }

                        while (n > 0)
                            PUT(num[--n]);
                    }

                    PUT('.');
                    PUT(' ');
                } else {
                    ENSURE(2);
                    PUT('-');
                    PUT(' ');
                }
            }

            else if (!strcmp(tag, "/li")) {
                if (mi > 0)
                    ENSURE_NL();
            }

            /* Ссылки: с href (сессия 55) — браузер делает кликабельными.
             * ')' внутри href обрезается — маркер markdown ](url) кончается
             * первой скобкой (документированное ограничение). */
            else if (!strcmp(tag, "a")) {
                last_href[0] = 0;
                html_attr(html, attr_s, attr_e, "href",
                          last_href, (int)sizeof(last_href));
                PUT('[');
            } else if (!strcmp(tag, "/a")) {
                ENSURE(3);
                PUT(']');
                if (last_href[0]) {
                    PUT('(');
                    for (const char *u = last_href; *u; u++) {
                        if (*u == ')') break;
                        /* &amp; в атрибуте — это '&' в реальном URL */
                        if (*u == '&' && !strncmp(u, "&amp;", 5)) {
                            PUT('&');
                            u += 4;
                            continue;
                        }
                        PUT(*u);
                    }
                    PUT(')');
                } else {
                    PUT('(');
                    PUT(')');
                }
                last_href[0] = 0;
            }

            /* Картинки (сессия 55): маркер ![alt](src) отдельной строкой —
             * браузер распознаёт, грузит и показывает. Без src — пропуск. */
            else if (!strcmp(tag, "img")) {
                char src[220];
                char alt[64];
                if (html_attr(html, attr_s, attr_e, "src",
                              src, (int)sizeof(src)) > 0) {
                    alt[0] = 0;
                    html_attr(html, attr_s, attr_e, "alt",
                              alt, (int)sizeof(alt));
                    ENSURE_NL();
                    ENSURE(6);
                    PUT('!');
                    PUT('[');
                    for (const char *u = alt; *u; u++) {
                        if (*u == ']' || *u == '\n' || *u == '\r') break;
                        if (u - alt >= 48) break;
                        PUT(*u);
                    }
                    PUT(']');
                    PUT('(');
                    for (const char *u = src; *u; u++) {
                        if (*u == ')' || *u == '\n' || *u == '\r' ||
                            *u == '"' || *u == '<')
                            break;
                        if (*u == '&' && !strncmp(u, "&amp;", 5)) {
                            PUT('&');
                            u += 4;
                            continue;
                        }
                        PUT(*u);
                    }
                    PUT(')');
                    EMIT_NL();
                }
            }

            /* Закрывающие теги форматирования */
            else if (!strcmp(tag, "/b") || !strcmp(tag, "/strong")) {
                ENSURE(2);
                PUT('*');
                PUT('*');
            } else if (!strcmp(tag, "/i") || !strcmp(tag, "/em")) {
                PUT('*');
            } else if (!strcmp(tag, "/code")) {
                PUT('`');
            }

            /* Неизвестные теги просто удаляем. */

            continue;
        }

        /* ------------------------------------------------------------
         * Обработка HTML-entities.
         * ------------------------------------------------------------ */
        if (c == '&') {
            rem = html_len - i;

            if (rem >= 5 && !strncmp(html + i, "&amp;", 5)) {
                PUT('&');
                i += 5;
                continue;
            }

            if (rem >= 4 && !strncmp(html + i, "&lt;", 4)) {
                PUT('<');
                i += 4;
                continue;
            }

            if (rem >= 4 && !strncmp(html + i, "&gt;", 4)) {
                PUT('>');
                i += 4;
                continue;
            }

            if (rem >= 6 && !strncmp(html + i, "&quot;", 6)) {
                PUT('"');
                i += 6;
                continue;
            }

            if (rem >= 6 && !strncmp(html + i, "&nbsp;", 6)) {
                /* Выводим пробел, но избегаем дублей. */
                if (mi > 0 &&
                    md[mi - 1] != ' ' &&
                    md[mi - 1] != '\n') {
                    PUT(' ');
                }

                i += 6;
                continue;
            }

            if (rem >= 5 && !strncmp(html + i, "&#39;", 5)) {
                PUT('\'');
                i += 5;
                continue;
            }

            if (rem >= 6 && !strncmp(html + i, "&apos;", 6)) {
                PUT('\'');
                i += 6;
                continue;
            }

            /* Числовые сущности: &#65; &#x41; и т.п.
             *
             * Полноценный Unicode здесь не делаем:
             * - 32..126 печатаем как есть;
             * - пробельные коды превращаем в пробел;
             * - остальное печатаем как '?'.
             */
            if (rem >= 3 && html[i + 1] == '#') {
                j = i + 2;
                base = 10;

                if (j < html_len &&
                    (html[j] == 'x' || html[j] == 'X')) {
                    base = 16;
                    j++;
                }

                start = j;
                val = 0;

                while (j < html_len) {
                    e = html[j];
                    digit = -1;

                    if (e >= '0' && e <= '9') {
                        digit = e - '0';
                    } else if (base == 16 && e >= 'a' && e <= 'f') {
                        digit = e - 'a' + 10;
                    } else if (base == 16 && e >= 'A' && e <= 'F') {
                        digit = e - 'A' + 10;
                    }

                    if (digit < 0)
                        break;

                    if (val <= 0x110000) {
                        val = val * base + digit;
                        if (val > 0x110000)
                            val = 0x110000;
                    }

                    j++;
                }

                if (j > start && j < html_len && html[j] == ';') {
                    if (val == 9 || val == 10 || val == 13 || val == 160) {
                        if (mi > 0 &&
                            md[mi - 1] != ' ' &&
                            md[mi - 1] != '\n') {
                            PUT(' ');
                        }
                    } else if (val == 39) {
                        PUT('\'');
                    } else if (val >= 32 && val <= 126) {
                        PUT((char)val);
                    } else if (val != 0) {
                        PUT('?');
                    }

                    i = j + 1;
                    continue;
                }
            }

            /* Не распознали — ниже '&' будет выведен как обычный символ. */
        }

        /* ------------------------------------------------------------
         * Внутри <pre> сохраняем текст как есть.
         * ------------------------------------------------------------ */
        if (pre_mode) {
            /* HTML часто игнорирует самый первый перевод строки сразу
             * после <pre>. Поступаем так же.
             */
            if (pre_first) {
                pre_first = 0;

                if (c == '\n') {
                    i++;
                    continue;
                }

                if (c == '\r') {
                    i++;
                    if (i < html_len && html[i] == '\n')
                        i++;
                    continue;
                }
            }

            PUT(c);
            i++;
            continue;
        }

        /* ------------------------------------------------------------
         * Сжатие пробелов и переводов строк вне <pre>.
         * ------------------------------------------------------------ */

        if (c == '\n' || c == '\r') {
            if (mi > 0 &&
                md[mi - 1] != '\n' &&
                md[mi - 1] != ' ') {
                PUT(' ');
            }

            i++;
            continue;
        }

        if (c == '\t') {
            if (mi > 0 && md[mi - 1] != ' ')
                PUT(' ');

            i++;
            continue;
        }

        /* Пропускаем пробел:
         * - в самом начале;
         * - если уже есть пробел;
         * - если он сразу после перевода строки.
         */
        if (c == ' ' &&
            (mi == 0 ||
             md[mi - 1] == ' ' ||
             md[mi - 1] == '\n')) {
            i++;
            continue;
        }

        /* Обычный символ. */
        PUT(c);
        i++;
    }

finish:
    md[mi] = 0;
    return mi;
}

#undef ENSURE
#undef PUT
#undef PUT_STR
#undef TRIM_SPACES
#undef EMIT_NL
#undef ENSURE_NL
#undef ENSURE_BLANK
#undef ENSURE_NL_RAW