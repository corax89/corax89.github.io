/* imgsvc.c — сервис изображений N2600-OS (см. imgsvc.h).
 *
 * Session 55. Декодирование — stb_image (src/stb_image.c), форматы
 * PNG/JPEG/BMP/GIF. Все long-running операции (stb-декодирование,
 * билинейное масштабирование) — под глобальным спящим локом: stb не
 * реентерабелен, x87-состояние ядра не сохраняется планировщиком.
 */
#include "types.h"
#include "mem.h"
#include "string.h"
#include "sync.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "task.h"
#include "imgsvc.h"

/* stb_image.h — только объявления (реализация в stb_image.c) */
#define STBI_NO_STDIO
#define STBI_NO_SIMD
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_ONLY_BMP
#define STBI_ONLY_GIF
#include "stb_image.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

/* ---------------- глобальный лок (спящий, sync.h) ---------------- */

static volatile int img_lock_v = 0;

static void img_lk(void)    { s_lock(&img_lock_v); }
static void img_unlk(void)  { s_unlock(&img_lock_v); }

/* Сессия 60: общий FPU-лок для всех float-библиотек ядра
 * (stb_image — здесь, dr_mp3 — в mp3svc). См. imgsvc.h. */
void img_fpu_lock(void)   { img_lk(); }
void img_fpu_unlock(void) { img_unlk(); }

/* ---------------- ошибки ---------------- */

static char img_err[96];

static void img_seterr(const char *msg)
{
    if (msg) {
        strncpy(img_err, msg, sizeof(img_err) - 1);
        img_err[sizeof(img_err) - 1] = 0;
    }
}

const char *img_errstr(void) { return img_err[0] ? img_err : "unknown"; }

/* ---------------- декодирование ---------------- */

void img_dispose(img_t *t)
{
    if (!t) return;
    if (t->rgba) { free(t->rgba); t->rgba = NULL; }
    t->w = 0; t->h = 0;
}

int img_decode_mem(const u8 *data, u32 len, img_t *out)
{
    int w = 0, h = 0, comp = 0;
    u8 *px;
    u32 npix;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!data || len < 8) { img_seterr("img: пустые данные"); return -1; }

    img_lk();
    /* 4 компоненты (RGBA): альфа нужна GIF/PNG с прозрачностью
     * (fb_blit_rgba пропускает прозрачные пиксели); в остальных
     * случаях stb сам дольёт 0xFF. */
    px = stbi_load_from_memory(data, (int)len, &w, &h, &comp, 4);
    img_unlk();

    if (!px) { img_seterr("img: формат не распознан/битый"); return -1; }
    if (w <= 0 || h <= 0) { free(px); img_seterr("img: нулевые размеры"); return -1; }

    npix = (u32)w * (u32)h;
    if (npix > IMG_MAX_PIXELS) {
        free(px);
        img_seterr("img: слишком большая картинка");
        return -1;
    }

    out->w = w;
    out->h = h;
    out->rgba = px;
    return 0;
}

/* Поиск в RAM disk без учёта регистра (как apps_browser.c ramfs_lookup) */
static int img_ramfs_lookup(const char *name, u32 *out_size)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        const char *a = ents[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) {
            if (out_size) *out_size = ents[i].size;
            return 1;
        }
    }
    return 0;
}

int img_decode_file(const char *ramfs_name, img_t *out)
{
    u32 fsize = 0;
    u8 *buf;
    u32 got;
    int rc;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!ramfs_name || !ramfs_name[0]) { img_seterr("img: пустое имя файла"); return -1; }
    if (!img_ramfs_lookup(ramfs_name, &fsize)) {
        img_seterr("img: файла нет в RAM disk");
        return -1;
    }
    if (fsize == 0 || fsize > IMG_FETCH_MAX) {
        img_seterr("img: размер файла вне лимита");
        return -1;
    }
    buf = (u8 *)malloc(fsize);
    if (!buf) { img_seterr("img: нет памяти под файл"); return -1; }
    got = ramfs_read(ramfs_name, buf, fsize);
    if (got == 0) { free(buf); img_seterr("img: ошибка чтения RAM disk"); return -1; }
    rc = img_decode_mem(buf, got, out);
    free(buf);
    return rc;
}

/* ---------- разбор ссылок ---------- */

static int ci_starts_with(const char *s, const char *pre)
{
    while (*pre) {
        char a = *s, b = *pre;
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a != b) return 0;
        s++; pre++;
    }
    return 1;
}

/* host[:port] -> host, port; path = остаток (начинается с '/'). */
static int img_parse_http(const char *p, int https, char *host, int host_max,
                          u16 *port, char *path, int path_max)
{
    int hi = 0;
    *port = https ? 443 : 80;
    while (*p && *p != '/' && hi < host_max - 1) host[hi++] = *p++;
    host[hi] = 0;
    {
        char *colon = strchr(host, ':');
        if (colon) {
            u32 pv = 0;
            *colon = 0;
            for (const char *q = colon + 1; *q; q++) {
                if (*q < '0' || *q > '9') return 0;
                pv = pv * 10 + (u32)(*q - '0');
                if (pv > 65535) return 0;
            }
            if (pv == 0) return 0;
            *port = (u16)pv;
        }
    }
    if (!host[0]) return 0;
    if (!*p) p = "/";
    if ((int)strlen(p) >= path_max) return 0;
    strcpy(path, p);
    return 1;
}

/* СЕССИЯ 67: нормализовать путь НА МЕСТЕ: выкинуть сегменты "./",
 * разрешить "../" (за корнем — остаться в корне), свернуть "//",
 * срезать хвостовой '/'. Возвращает новую длину.
 * Используется для имён RAM disk (они хранятся БЕЗ ведущего '/'),
 * поэтому ведущий '/' тоже "съедается" как сегмент-пустышка. */
static int img_norm_inplace(char *p)
{
    char *w = p, *r = p;
    while (*r) {
        if (r[0] == '/' && r[1] == '/') { r++; continue; }        /* // */
        if (r[0] == '.' && (r[1] == '/' || r[1] == 0)) {          /* ./  */
            r += (r[1] ? 2 : 1);
            continue;
        }
        if (r[0] == '.' && r[1] == '.' && (r[2] == '/' || r[2] == 0)) {
            /* ../ — съесть предыдущий сегмент; за корнем — остаться */
            if (w > p) {
                w--;
                while (w > p && w[-1] != '/') w--;
            }
            r += (r[2] == '/') ? 3 : 2;
            continue;
        }
        *w++ = *r++;
    }
    while (w > p && w[-1] == '/') w--;      /* хвостовой '/' */
    *w = 0;
    return (int)(w - p);
}

/* СЕССИЯ 67: нормализовать ПУТЬ полного http(s)-URL (подстрока после
 * "scheme://host"): "./", "../", "//". Строгие серверы (в т.ч. наш
 * httpd) "dir/./x.png" и "dir/a/../x.png" не разворачивают — 404.
 * Схему не трогаем: нормализация с первого '/' ПОСЛЕ хоста (иначе
 * свернулась бы "//" в "://"). */
static void img_norm_http_path(char *url)
{
    char *ps = strstr(url, "://");
    if (!ps) return;
    ps = strchr(ps + 3, '/');
    if (ps) img_norm_inplace(ps);
}

/* СЕССИЯ 67: соединить каталог страницы base[0..dlen) с rel-ссылкой
 * и нормализовать (./ ../ //). Выход — имя RAM disk без ведущего '/'.
 * 1 = успех (out заполнен), 0 = не влезло/пусто. */
static int img_join_norm(const char *base, int dlen, const char *rel,
                         char *out, int out_max)
{
    char tmp[RAMFS_NAME_MAX * 2 + 8];
    int n = 0;

    if (dlen < 0) dlen = 0;
    for (int i = 0; i < dlen && n < (int)sizeof(tmp) - 2; i++)
        tmp[n++] = base[i];
    if (n > 0 && tmp[n - 1] != '/' && rel[0] && rel[0] != '/')
        tmp[n++] = '/';
    for (const char *q = rel; *q && n < (int)sizeof(tmp) - 1; q++)
        tmp[n++] = *q;
    tmp[n] = 0;

    img_norm_inplace(tmp);
    if (!tmp[0] || (int)strlen(tmp) >= out_max) return 0;
    strcpy(out, tmp);
    return 1;
}

/* СЕССИЯ 67: последний шанс после НЕУДАЧНОЙ сетевой загрузки картинки —
 * путь из URL как имя RAM disk. Локальный httpd раздаёт файлы ramdisk,
 * и если сервер уже не отвечает (а страница осталась открытой/сохранны
 * ссылки), картинка всё равно может лежать в RAM disk. При неудаче
 * ВОССТАНАВЛИВАЕТ prev_err — статус должен показывать сетевую причину,
 * а не "файла нет в RAM disk". */
static int img_ramfs_url_fallback(const char *path, img_t *out)
{
    char prev[96];
    char cand[RAMFS_NAME_MAX + 4];
    int n = 0;

    /* снимок сетевой ошибки: при неудаче fallback вернём её в статус */
    snprintf(prev, sizeof(prev), "%s", img_err[0] ? img_err : "unknown");

    /* срезаем ведущие '/', "./", "../" (path может быть "/LOGO.PNG",
 * "./x.png", "../dir/x.png") */
    const char *q = path;
    for (;;) {
        if (*q == '/') q++;
        else if (q[0] == '.' && q[1] == '/') q += 2;
        else if (q[0] == '.' && q[1] == '.' && q[2] == '/') q += 3;
        else break;
    }
    for (; *q && n < RAMFS_NAME_MAX; q++) cand[n++] = *q;
    cand[n] = 0;
    if (!cand[0]) { img_seterr(prev); return -1; }
    if (!img_ramfs_lookup(cand, NULL)) { img_seterr(prev); return -1; }
    {
        int rc = img_decode_file(cand, out);
        if (rc != 0) img_seterr(prev);
        return rc;
    }
}

/* Относительная ссылка -> абсолютная (наивно): тот же хост;
 * "/..." — от корня, иначе — каталог текущей страницы.
 * Публичная (imgsvc.h): браузер разрешает ею и ссылки, и картинки.
 * СЕССИЯ 67: для ЛОКАЛЬНОЙ страницы (base_url без "://" — имя файла
 * RAM disk) rel теперь разрешается относительно КАТАЛОГА страницы с
 * нормализацией "./"/"../" ("docs/page.md" + "img/x.png" ->
 * "docs/img/x.png"), а rel с ведущим '/' — от корня RAM disk (без
 * ведущего '/'). Прежде rel копировался как есть: картинки и ссылки
 * рядом с локальной страницей в подкаталоге, "./x" и "/x" не работали. */
void img_url_resolve(const char *base_url, const char *rel,
                     char *out, int out_max)
{
    const char *h, *hend, *slash;
    int pos = 0;

    out[0] = 0;
    if (!rel || !rel[0]) {
        if (base_url) { strncpy(out, base_url, (u32)out_max - 1); out[out_max - 1] = 0; }
        return;
    }

    /* Сессия 56: АБСОЛЮТНЫЙ адрес в rel — вернуть как есть. Раньше
     * клик по <a href="http://другой.хост/"> со сетевой страницы
     * склеивался с хостом страницы ("http://страница/http://другой")
     * и вёл в никуда; то же с Location: из 302-ответов. */
    if (!strncmp(rel, "http://", 7) || !strncmp(rel, "https://", 8)) {
        strncpy(out, rel, (u32)out_max - 1);
        out[out_max - 1] = 0;
        img_norm_http_path(out);
        return;
    }
    if (rel[0] == '/' && rel[1] == '/') {
        /* схемо-относительный //host/path -> http://host/path */
        char tmp[300];
        snprintf(tmp, sizeof(tmp), "http:%s", rel);
        strncpy(out, tmp, (u32)out_max - 1);
        out[out_max - 1] = 0;
        img_norm_http_path(out);
        return;
    }

    if (!base_url || !base_url[0]) {
        /* нет базы — считаем имя файла RAM disk (нормализуем "/", "./") */
        char tmp[RAMFS_NAME_MAX + 8];
        if ((int)strlen(rel) < (int)sizeof(tmp)) {
            strcpy(tmp, rel);
            img_norm_inplace(tmp);
            if (tmp[0]) { strncpy(out, tmp, (u32)out_max - 1); out[out_max - 1] = 0; return; }
        }
        strncpy(out + pos, rel, (u32)out_max - 1 - (u32)pos);
        out[out_max - 1] = 0;
        return;
    }

    h = strstr(base_url, "://");
    if (!h) {
        /* СЕССИЯ 67: ЛОКАЛЬНАЯ страница (имя RAM disk, без "://"). */
        if (rel[0] == '/') {
            /* от корня RAM disk: срезаем ведущие '/' */
            const char *q = rel;
            while (*q == '/') q++;
            strncpy(out, q, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return;
        }
        {
            const char *slash = strrchr(base_url, '/');
            if (slash && slash != base_url &&
                img_join_norm(base_url, (int)(slash - base_url), rel,
                              out, out_max))
                return;                     /* рядом со страницей */
        }
        strncpy(out, rel, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return;
    }
    h += 3;
    hend = h;
    while (*hend && *hend != '/') hend++;

    for (const char *q = base_url; q < hend && pos < out_max - 1; q++)
        out[pos++] = *q;

    if (*rel == '/') {
        /* от корня */
    } else {
        /* каталог страницы: обрезаем path после последнего '/' */
        slash = strrchr(hend, '/');
        if (slash) {
            for (const char *q = hend; q <= slash && pos < out_max - 1; q++)
                out[pos++] = *q;
        } else if (pos < out_max - 1) {
            out[pos++] = '/';
        }
    }
    for (const char *q = rel; *q && pos < out_max - 1; q++)
        out[pos++] = *q;
    out[pos] = 0;
    img_norm_http_path(out);
}

int img_decode_url(const char *url, const char *base_url, img_t *out)
{
    char clean[300];
    int ci = 0;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!url || !url[0]) { img_seterr("img: пустой адрес"); return -1; }

    /* фрагменты #... отбрасываем, пробелы убираем */
    for (const char *q = url; *q && ci < (int)sizeof(clean) - 1; q++) {
        if (*q == '#') break;
        if (*q != ' ') clean[ci++] = *q;
    }
    clean[ci] = 0;
    if (!clean[0]) { img_seterr("img: пустой адрес"); return -1; }

    if (ci_starts_with(clean, "http://") || ci_starts_with(clean, "https://")) {
        int https = (clean[4] == 's');
        const char *p = clean + (https ? 8 : 7);
        char host[128], path[256];
        u16 port;
        char *resp;
        int n, rc;
        const char *body;
        int blen;
        const char *enc;

        if (!img_parse_http(p, https, host, (int)sizeof(host), &port,
                            path, (int)sizeof(path))) {
            img_seterr("img: неверный адрес");
            return -1;
        }
        /* СЕССИЯ 63: картинки с loopback (страница с 127.0.0.1, картинки
         * с localhost) грузим без NIC/IP — стек замыкает соединение сам. */
        if (!net_host_is_loopback(host) &&
            (!net_nic_present() || net_get_ip() == 0)) {
            img_seterr("img: сеть не настроена");
            /* СЕССИЯ 67: сети нет — но картинка может лежать в RAM disk
             * (локальный httpd раздаёт ramdisk): путь как имя файла. */
            return img_ramfs_url_fallback(path, out);
        }
        resp = (char *)malloc(IMG_FETCH_MAX);
        if (!resp) { img_seterr("img: нет памяти под ответ"); return -1; }
        n = net_http_get(host, port, path, resp, IMG_FETCH_MAX, 15000);
        if (n <= 0) {
            snprintf(img_err, sizeof(img_err), "img: сеть: %s",
                     net_http_errstr());
            free(resp);
            /* СЕССИЯ 67: сеть не удалась — последний шанс: RAM disk */
            return img_ramfs_url_fallback(path, out);
        }
        /* gzip/deflate не умеем — честно отказываемся */
        enc = NULL;
        for (const char *q = resp; q < resp + n - 20; q++) {
            if ((*q == 'C' || *q == 'c') &&
                !strncmp(q, "ontent-encoding:", 16)) {
                enc = q + 16;
                break;
            }
        }
        if (enc) {
            while (enc < resp + n && (*enc == ' ' || *enc == '\t')) enc++;
            if (!strncmp(enc, "gzip", 4) || !strncmp(enc, "deflate", 7)) {
                img_seterr("img: сжатый ответ (gzip) не поддержан");
                free(resp);
                return img_ramfs_url_fallback(path, out);
            }
        }
        /* тело: после \r\n\r\n (или \n\n) */
        body = resp;
        blen = n;
        for (int i = 0; i < n && i < 4096; i++) {
            if (i + 3 < n && resp[i] == '\r' && resp[i+1] == '\n' &&
                resp[i+2] == '\r' && resp[i+3] == '\n') {
                body = resp + i + 4;
                blen = n - (i + 4);
                break;
            }
            if (i + 1 < n && resp[i] == '\n' && resp[i+1] == '\n') {
                body = resp + i + 2;
                blen = n - (i + 2);
                break;
            }
        }
        if (blen <= 0) {
            img_seterr("img: пустое тело ответа");
            free(resp);
            return img_ramfs_url_fallback(path, out);
        }
        rc = img_decode_mem((const u8 *)body, (u32)blen, out);
        free(resp);
        if (rc != 0) {
            /* декод не удался (404-страница, битый файл) — RAM disk */
            return img_ramfs_url_fallback(path, out);
        }
        return 0;
    }

    if (ci_starts_with(clean, "file://")) {
        /* СЕССИЯ 67: "file:///LOGO.PNG" и "file://dir/x.png" — ramfs имена
 * хранятся без ведущего '/': нормализуем (раньше "/LOGO.PNG" искался
 * буквально и не находился). */
        const char *nm = clean + 7;
        for (;;) {
            if (*nm == '/') nm++;
            else if (nm[0] == '.' && nm[1] == '/') nm += 2;
            else if (nm[0] == '.' && nm[1] == '.' && nm[2] == '/') nm += 3;
            else break;
        }
        return img_decode_file(nm[0] ? nm : clean + 7, out);
    }

    /* без схемы: ЛОКАЛЬНАЯ страница — RAM disk. СЕССИЯ 67: rel
 * разрешается относительно каталога страницы (см. img_url_resolve),
 * затем нормализуется: ramfs имена хранятся без ведущего '/'. */
    if (!base_url || !base_url[0] || !strstr(base_url, "://")) {
        char cand[RAMFS_NAME_MAX + 8];
        img_url_resolve(base_url ? base_url : "", clean, cand,
                        (int)sizeof(cand));
        if (cand[0]) {
            const char *nm = cand;
            for (;;) {
                if (*nm == '/') nm++;
                else if (nm[0] == '.' && nm[1] == '/') nm += 2;
                else if (nm[0] == '.' && nm[1] == '.' && nm[2] == '/') nm += 3;
                else break;
            }
            if (nm[0] && img_decode_file(nm, out) == 0) return 0;
        }
        /* кандидат 2: имя от КОРНЯ (страница из подкаталога может
 * ссылаться на картинку в корне; старое поведение — поиск "как
 * есть" — сохранён здесь же). */
        {
            const char *nm = clean;
            for (;;) {
                if (*nm == '/') nm++;
                else if (nm[0] == '.' && nm[1] == '/') nm += 2;
                else if (nm[0] == '.' && nm[1] == '.' && nm[2] == '/') nm += 3;
                else break;
            }
            if (nm[0] && img_decode_file(nm, out) == 0) return 0;
        }
        img_seterr("img: файла нет в RAM disk");
        return -1;
    }
    {
        char abs[400];
        img_url_resolve(base_url, clean, abs, (int)sizeof(abs));
        return img_decode_url(abs, NULL, out);
    }
}

/* ---------------- масштабирование (билинейное, float, под локом) ---------------- */

int img_scale(const img_t *src, int dw, int dh, img_t *out)
{
    u8 *dst;
    int sw, sh;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!src || !src->rgba || src->w <= 0 || src->h <= 0) {
        img_seterr("img: пустой источник");
        return -1;
    }
    if (dw <= 0 || dh <= 0 || dw > 4096 || dh > 4096) {
        img_seterr("img: неверные размеры");
        return -1;
    }
    sw = src->w; sh = src->h;
    dst = (u8 *)malloc((u32)dw * (u32)dh * 4);
    if (!dst) { img_seterr("img: нет памяти под масштаб"); return -1; }

    img_lk();
    if (dw == sw && dh == sh) {
        memcpy(dst, src->rgba, (u32)dw * (u32)dh * 4);
    } else {
        for (int dy = 0; dy < dh; dy++) {
            /* центр исходного пикселя по вертикали */
            float fy = ((float)dy + 0.5f) * (float)sh / (float)dh - 0.5f;
            int y0 = (int)fy;
            float wy = fy - (float)y0;
            if (y0 < 0) { y0 = 0; wy = 0.0f; }
            if (y0 >= sh - 1) { y0 = sh - 1; wy = 0.0f; }
            int y1 = (y0 + 1 < sh) ? y0 + 1 : y0;

            u8 *drow = dst + (u32)dy * (u32)dw * 4;
            for (int dx = 0; dx < dw; dx++) {
                float fx = ((float)dx + 0.5f) * (float)sw / (float)dw - 0.5f;
                int x0 = (int)fx;
                float wx = fx - (float)x0;
                if (x0 < 0) { x0 = 0; wx = 0.0f; }
                if (x0 >= sw - 1) { x0 = sw - 1; wx = 0.0f; }
                int x1 = (x0 + 1 < sw) ? x0 + 1 : x0;

                const u8 *p00 = src->rgba + ((u32)y0 * (u32)sw + (u32)x0) * 4;
                const u8 *p10 = src->rgba + ((u32)y0 * (u32)sw + (u32)x1) * 4;
                const u8 *p01 = src->rgba + ((u32)y1 * (u32)sw + (u32)x0) * 4;
                const u8 *p11 = src->rgba + ((u32)y1 * (u32)sw + (u32)x1) * 4;
                float w00 = (1.0f - wx) * (1.0f - wy);
                float w10 = wx * (1.0f - wy);
                float w01 = (1.0f - wx) * wy;
                float w11 = wx * wy;

                drow[dx * 4 + 0] = (u8)(p00[0] * w00 + p10[0] * w10 +
                                        p01[0] * w01 + p11[0] * w11);
                drow[dx * 4 + 1] = (u8)(p00[1] * w00 + p10[1] * w10 +
                                        p01[1] * w01 + p11[1] * w11);
                drow[dx * 4 + 2] = (u8)(p00[2] * w00 + p10[2] * w10 +
                                        p01[2] * w01 + p11[2] * w11);
                drow[dx * 4 + 3] = (u8)(p00[3] * w00 + p10[3] * w10 +
                                        p01[3] * w01 + p11[3] * w11);
            }
        }
    }
    img_unlk();

    out->w = dw;
    out->h = dh;
    out->rgba = dst;
    return 0;
}

/* ---------------- дескрипторы ---------------- */

typedef struct {
    int   used;
    int   ref;
    img_t t;
} img_handle_t;

static img_handle_t g_handles[IMG_MAX_HANDLES];

int img_open(const img_t *t)
{
    int id = -1;
    if (!t || !t->rgba || t->w <= 0 || t->h <= 0) {
        img_seterr("img: пустая картинка для img_open");
        return -1;
    }
    img_lk();
    for (int i = 0; i < IMG_MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            g_handles[i].used = 1;
            g_handles[i].ref = 1;
            g_handles[i].t = *t;
            id = i + 1;
            break;
        }
    }
    img_unlk();
    if (id < 0) img_seterr("img: таблица дескрипторов полна");
    return id;
}

int img_retain(int id)
{
    int rc = -1;
    if (id <= 0 || id > IMG_MAX_HANDLES) return -1;
    img_lk();
    if (g_handles[id - 1].used) {
        g_handles[id - 1].ref++;
        rc = 0;
    }
    img_unlk();
    return rc;
}

void img_release(int id)
{
    if (id <= 0 || id > IMG_MAX_HANDLES) return;
    img_lk();
    if (g_handles[id - 1].used && g_handles[id - 1].ref > 0) {
        g_handles[id - 1].ref--;
        if (g_handles[id - 1].ref == 0) {
            img_dispose(&g_handles[id - 1].t);
            g_handles[id - 1].used = 0;
        }
    }
    img_unlk();
}

int img_get(int id, img_t *out)
{
    int rc = -1;
    if (!out || id <= 0 || id > IMG_MAX_HANDLES) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    img_lk();
    if (g_handles[id - 1].used) {
        *out = g_handles[id - 1].t;
        rc = 0;
    }
    img_unlk();
    return rc;
}
