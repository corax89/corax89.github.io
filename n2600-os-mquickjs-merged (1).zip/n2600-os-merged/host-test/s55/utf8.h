/* utf8.h — общие праймитивы UTF-8 для N2600-OS (header-only).
 *
 * Зачем: шрифт ОС моноширинный 8x16, КАЖДЫЙ СИМВОЛ (включая кириллицу)
 * рисуется одним глифом 8 px, но в UTF-8 русская буква занимает 2 БАЙТА.
 * Любая обрезка/ширина, посчитанная по байтам (strlen), режет символы
 * пополам — «строки обрезаются неправильно» (браузер, редактор).
 *
 * Все функции самодостаточны (никаких зависимостей), поэтому работают
 * и в ядре (freestanding), и в хост-тестах. Правило:
 *   - ШИРИНА на экране = число СИМВОЛОВ * 8 px (utf8_count_chars);
 *   - ОБРЕЗКА по числу СИМВОЛОВ = utf8_take_bytes;
 *   - ОБРЕЗКА по числу БАЙТ    = utf8_clamp_bytes (не рвёт символ);
 *   - шаг по строке            = utf8_seq_len / utf8_align_back.
 */
#ifndef UTF8_H
#define UTF8_H

#ifdef __cplusplus
extern "C" {
#endif

/* Длина последовательности UTF-8 по ведущему байту: 1..3; для
 * испорченных/неожиданных ведущих байтов (0xF8..0xFF, 0x80..0xBF) — 1,
 * чтобы шаг никогда не «проглатывал» часть строки. */
static inline int utf8_seq_len(unsigned char lead)
{
    if (lead < 0x80) return 1;
    if ((lead & 0xE0) == 0xC0) return 2;
    if ((lead & 0xF0) == 0xE0) return 3;
    return 1;
}

/* Если s[off] — ПРОДОЛЖАЮЩИЙ байт (0x80..0xBF), откатиться к началу
 * его последовательности (не дальше 0). Граница символа = позиция
 * ведущего байта. Корректно для 2- и 3-байтовых последовательностей:
 * скан идёт от off назад до первого ведущего байта (не более 3 шагов
 * — cap от зацикливания на испорченных данных). */
static inline int utf8_align_back(const char *s, int off)
{
    if (off > 0 && ((unsigned char)s[off] & 0xC0) == 0x80) {
        int back = off;
        int lim = off > 3 ? off - 3 : 0;
        while (back > lim && ((unsigned char)s[back] & 0xC0) == 0x80)
            back--;
        return back;
    }
    return off;
}

/* Сколько БАЙТ занимают первые max_chars СИМВОЛОВ из s[0..len)
 * (len — байтовая длина; если len < 0 — до '\0'). Не рвёт символы:
 * последний неполный символ не включается. */
static inline int utf8_take_bytes(const char *s, int len, int max_chars)
{
    if (len < 0) {
        len = 0;
        while (s[len]) len++;
    }
    const char *p = s;
    const char *end = s + len;
    for (int i = 0; i < max_chars && p < end && *p; i++) {
        int adv = utf8_seq_len((unsigned char)*p);
        if (p + adv > end) break;      /* символ обрезан концом строки */
        p += adv;
    }
    return (int)(p - s);
}

/* Обрезать len байт до max байт по границе символа (не разрывать
 * UTF-8). Если max сам попадает на продолжающий байт — откат. */
static inline int utf8_clamp_bytes(const char *s, int len, int max)
{
    if (len <= max) return len;
    int take = utf8_align_back(s, max);
    return take > 0 ? take : 1;   /* хотя бы 1 байт, чтобы не зациклиться */
}

/* Число видимых СИМВОЛОВ в s[0..len) (len < 0 — до '\0'). */
static inline int utf8_count_chars(const char *s, int len)
{
    int n = 0;
    const char *p = s;
    if (len < 0) {
        while (*p) { p += utf8_seq_len((unsigned char)*p); n++; }
    } else {
        const char *end = s + len;
        while (p < end && *p) {
            int adv = utf8_seq_len((unsigned char)*p);
            if (p + adv > end) break;
            p += adv;
            n++;
        }
    }
    return n;
}

#ifdef __cplusplus
}
#endif

#endif /* UTF8_H */
