/* mp3svc_test.c — хост-тест MP3-сервиса (сессия 60).
 *
 * Проверяет обвязку dr_mp3 (mp3svc.c) на РЕАЛЬНОМ mp3-файле:
 *   - mp3_open_mem / channels / rate;
 *   - mp3_read_s16 декодирует фреймы (не тишина, не мусор);
 *   - mp3_tell / mp3_seek (позиционирование);
 *   - mp3_total_frames_estimate — правдоподобная оценка длительности;
 *   - STATIC_ASSERT sizeof(drmp3) <= MP3_CTX_SIZE ловится на этапе сборки.
 *
 * Файл передаётся аргументом (обычный mp3, напр. из gradio-ассетов).
 * Сборка: ./run_mp3svc.sh <путь-к-mp3> */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
#include "mp3svc.h"

static int g_fail = 0;
#define CHECK(cond, ...) do { \
        if (cond) { printf("  ok  " __VA_ARGS__); printf("\n"); } \
        else { printf("  FAIL " __VA_ARGS__); printf("\n"); g_fail++; } \
    } while (0)

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: mp3svc_test <file.mp3>\n"); return 2; }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open"); return 2; }
    fseek(f, 0, SEEK_END);
    long fsz = ftell(f);
    fseek(f, 0, SEEK_SET);
    u8 *data = (u8 *)malloc((u32)fsz);
    size_t rd = fread(data, 1, (size_t)fsz, f);
    fclose(f);
    CHECK(rd == (size_t)fsz && fsz > 1024, "файл прочитан: %ld байт", fsz);

    printf("[1] открытие\n");
    void *ctx = malloc(MP3_CTX_SIZE);
    CHECK(ctx != NULL, "контекст %u байт выделен", (u32)MP3_CTX_SIZE);
    CHECK(mp3_open_mem(data, (u32)fsz, ctx) == 1, "mp3_open_mem");
    u32 ch = mp3_channels(ctx), rate = mp3_rate(ctx);
    CHECK(ch == 1 || ch == 2, "каналы %u", ch);
    CHECK(rate >= 8000 && rate <= 48000, "частота %u Гц", rate);

    printf("[2] декодирование\n");
    i16 pcm[1152 * 2];
    u32 got = mp3_read_s16(ctx, pcm, 1152);
    CHECK(got == 1152, "прочитан фрейм: %u фреймов", got);
    long long sum = 0;
    for (u32 i = 0; i < got * ch; i++) sum += pcm[i] < 0 ? -pcm[i] : pcm[i];
    CHECK(sum > 1000, "не тишина (средняя амплитуда %lld)", sum / (got * ch));

    printf("[3] позиция/поиск\n");
    u64 t0 = mp3_tell(ctx);
    CHECK(t0 == 1152, "tell = %llu", (unsigned long long)t0);
    CHECK(mp3_seek(ctx, 0) == 1, "seek(0)");
    CHECK(mp3_tell(ctx) == 0, "после seek tell = 0");
    got = mp3_read_s16(ctx, pcm, 1152);
    CHECK(got == 1152, "после seek снова читается фрейм (%u)", got);

    printf("[4] оценка длительности\n");
    u64 total = mp3_total_frames_estimate(ctx);
    CHECK(total > 0, "total = %llu фреймов", (unsigned long long)total);
    if (total && rate) {
        u64 sec = total / rate;
        CHECK(sec >= 1 && sec <= 3600, "оценка длительности ~%llu c",
              (unsigned long long)sec);
    }

    printf("[5] закрытие и мусорный файл\n");
    mp3_close(ctx);
    free(ctx);
    void *ctx2 = malloc(MP3_CTX_SIZE);
    CHECK(mp3_open_mem("это не mp3", 10, ctx2) == 0, "битый файл отклонён");
    CHECK(mp3_errstr()[0] != 0, "есть текст ошибки: %s", mp3_errstr());
    free(ctx2);

    free(data);
    printf("\n====\n");
    if (g_fail == 0) printf("MP3SVC: ВСЕ ПРОВЕРКИ ЗЕЛЁНЫЕ\n");
    else             printf("MP3SVC: ПРОВАЛОВ: %d\n", g_fail);
    return g_fail ? 1 : 0;
}
