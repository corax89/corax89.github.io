/* mp3svc.c — сервис MP3-декодирования (реализация, сессия 60).
 *
 * ЕДИНСТВЕННАЯ единица трансляции с DR_MP3_IMPLEMENTATION (см. dr_mp3.h).
 * Конфигурация dr_mp3 под freestanding-ядро:
 *   - assert'ы выключены (нет <assert.h>);
 *   - malloc/free — куча ядра; realloc в ядре нет, поэтому все вызовы
 *     dr_mp3 идут с явными allocation callbacks (onRealloc = NULL),
 *     внутри dr_mp3 realloc эмулируется через malloc+копию+free;
 *   - stdio выключен (DR_MP3_NO_STDIO в dr_mp3.h).
 *
 * FPU: синтезатор dr_mp3 — float. Каждая операция декодирования берёт
 * ОБЩИЙ FPU-лок imgsvc (тот же, что у stb_image): планировщик не
 * сохраняет x87-состояние, конкурент просто спит в hlt. */
#include "mp3svc.h"
#include "mem.h"
#include "string.h"
#include "imgsvc.h"
#include <stddef.h>   /* size_t (dr_mp3 и прототипы ниже) */

#ifndef NULL
#define NULL ((void *)0)
#endif

/* Прямые объявления ДО include с реализацией: макросы DRMP3_MALLOC/
 * DRMP3_REALLOC используются внутри dr_mp3_impl.h. */
static void *mp3__kmalloc(size_t sz);
static void *mp3__krealloc(void *p, size_t sz);

#define DR_MP3_IMPLEMENTATION
#define DRMP3_ASSERT(e)          ((void)(e))
#define DRMP3_MALLOC(sz)         mp3__kmalloc((sz))
#define DRMP3_REALLOC(p, sz)     mp3__krealloc((p), (sz))
#define DRMP3_FREE(p)            free((p))
#define DRMP3_COPY_MEMORY(d,s,n) memcpy((d), (s), (n))
#define DRMP3_MOVE_MEMORY(d,s,n) memmove((d), (s), (n))
#define DRMP3_ZERO_MEMORY(p,n)   memset((p), 0, (n))

#include "dr_mp3.h"

/* sizeof(drmp3) = 32376 байт (синтезаторные буферы minimp3).
 * Если апгрейд dr_mp3 раздует структуру — сборка упадёт ЗДЕСЬ,
 * а не молча в рантайме. */
STATIC_ASSERT(sizeof(drmp3) <= MP3_CTX_SIZE, mp3_ctx_fits);

/* ---------------- куча ядра как allocation callbacks ---------------- */

static void *mp3__kmalloc(size_t sz)
{
    return malloc((u32)sz);
}

/* В ядре нет realloc: dr_mp3 вызывает его только через
 * allocation callbacks, а мы передаём onRealloc = NULL — тогда
 * dr_mp3 сам эмулирует realloc через malloc+memcpy+free. Сюда
 * управление попасть не должно; на всякий случай — NULL (без порчи). */
static void *mp3__krealloc(void *p, size_t sz)
{
    (void)p; (void)sz;
    return NULL;
}

static void *mp3__cb_malloc(size_t sz, void *ud)
{
    (void)ud;
    return mp3__kmalloc(sz);
}

static void mp3__cb_free(void *p, void *ud)
{
    (void)ud;
    free(p);
}

static const drmp3_allocation_callbacks mp3__cb = {
    NULL,               /* pUserData */
    mp3__cb_malloc,
    NULL,               /* onRealloc — dr_mp3 эмулирует сам */
    mp3__cb_free
};

/* ---------------- ошибки ---------------- */

static char g_mp3_err[96] = "";

static void mp3__seterr(const char *msg)
{
    if (msg) {
        strncpy(g_mp3_err, msg, sizeof(g_mp3_err) - 1);
        g_mp3_err[sizeof(g_mp3_err) - 1] = 0;
    }
}

const char *mp3_errstr(void) { return g_mp3_err; }

/* ---------------- API ---------------- */

int mp3_open_mem(const void *data, u32 len, void *ctx)
{
    if (!data || !ctx || len == 0) { mp3__seterr("нет данных"); return 0; }
    if (len > 512u * 1024u * 1024u) { mp3__seterr("файл слишком велик"); return 0; }

    img_fpu_lock();
    drmp3_bool32 ok = drmp3_init_memory((drmp3 *)ctx, data, (size_t)len, &mp3__cb);
    img_fpu_unlock();
    if (!ok) { mp3__seterr("не MP3 / битый файл"); return 0; }
    g_mp3_err[0] = 0;
    return 1;
}

void mp3_close(void *ctx)
{
    if (!ctx) return;
    img_fpu_lock();
    drmp3_uninit((drmp3 *)ctx);
    img_fpu_unlock();
}

u32 mp3_channels(const void *ctx)
{
    const drmp3 *m = (const drmp3 *)ctx;
    return m ? (u32)m->channels : 0;
}

u32 mp3_rate(const void *ctx)
{
    const drmp3 *m = (const drmp3 *)ctx;
    return m ? (u32)m->sampleRate : 0;
}

u64 mp3_tell(const void *ctx)
{
    const drmp3 *m = (const drmp3 *)ctx;
    return m ? (u64)m->currentPCMFrame : 0;
}

int mp3_seek(void *ctx, u64 frame)
{
    if (!ctx) return 0;
    img_fpu_lock();
    drmp3_bool32 ok = drmp3_seek_to_pcm_frame((drmp3 *)ctx, (drmp3_uint64)frame);
    img_fpu_unlock();
    return ok ? 1 : 0;
}

u32 mp3_read_s16(void *ctx, i16 *pcm, u32 frames)
{
    if (!ctx || !pcm || frames == 0) return 0;
    img_fpu_lock();
    drmp3_uint64 n = drmp3_read_pcm_frames_s16((drmp3 *)ctx,
                                               (drmp3_uint64)frames, pcm);
    img_fpu_unlock();
    return (u32)n;
}

/* Оценка длительности: ID3v2-пропуск + первый MPEG-заголовок (таблицы
 * битрейтов), затем CBR-формула audio_bytes * 8 * rate / (kbps*1000).
 * VBR без Xing даёт грубую оценку — для ползунка прогресса достаточно
 * (точный подсчёт требует полного прохода — секунды CPU). */
u64 mp3_total_frames_estimate(const void *ctx)
{
    static const u16 br_v1[16] = { 0, 32, 40, 48, 56, 64, 80, 96, 112,
                                   128, 160, 192, 224, 256, 320, 0 };
    static const u16 br_v2[16] = { 0, 8, 16, 24, 32, 40, 48, 56, 64,
                                   80, 96, 112, 128, 144, 160, 0 };
    const drmp3 *m = (const drmp3 *)ctx;
    if (!m || !m->sampleRate) return 0;
    u32 rate = (u32)m->sampleRate;

    const u8 *p   = (const u8 *)m->memory.pData;
    u32 len       = (u32)m->memory.dataSize;
    if (!p || len < 8) return 0;

    u32 off = 0;
    if (len >= 10 && p[0] == 'I' && p[1] == 'D' && p[2] == '3') {
        u32 sz = ((u32)(p[6] & 0x7F) << 21) | ((u32)(p[7] & 0x7F) << 14) |
                 ((u32)(p[8] & 0x7F) << 7)  |  (u32)(p[9] & 0x7F);
        off = 10 + sz;
        if (off >= len) return 0;
    }

    /* синхрослово 0xFFE (11 единиц) в первых 64 КиБ после тега */
    u32 lim = off + 65536;
    if (lim > len - 4) lim = len - 4;
    for (u32 i = off; i < lim; i++) {
        u32 h = ((u32)p[i] << 24) | ((u32)p[i + 1] << 16) |
                ((u32)p[i + 2] << 8) |  (u32)p[i + 3];
        if ((h & 0xFFE00000u) != 0xFFE00000u) continue;
        u32 ver   = (h >> 19) & 3;    /* 3 = MPEG1, 2 = MPEG2, 0 = MPEG2.5 */
        u32 layer = (h >> 17) & 3;    /* 1 = Layer III */
        u32 bri   = (h >> 12) & 0xF;
        u32 sri   = (h >> 10) & 3;
        if (ver == 1 || layer != 1 || bri == 0 || bri == 0xF || sri == 3)
            continue;
        u32 kbps = (ver == 3) ? br_v1[bri] : br_v2[bri];
        if (!kbps) continue;
        u64 audio = (u64)(len - i);
        return audio * 8u * rate / ((u64)kbps * 1000u);
    }
    return 0;
}

/* ---------------- kapi-обёртки (сессия 60, см. mp3svc.h) ---------------- */

int kapi_mp3_open_mem(const void *data, u32 len, void *ctx)
{
    return mp3_open_mem(data, len, ctx);
}

void kapi_mp3_close(void *ctx)
{
    mp3_close(ctx);
}

u32 kapi_mp3_channels(const void *ctx)
{
    return mp3_channels(ctx);
}

u32 kapi_mp3_rate(const void *ctx)
{
    return mp3_rate(ctx);
}

u32 kapi_mp3_read_s16(void *ctx, i16 *pcm, u32 frames)
{
    return mp3_read_s16(ctx, pcm, frames);
}

u32 kapi_mp3_seek(void *ctx, u32 frame)
{
    return (u32)mp3_seek(ctx, (u64)frame);
}

u32 kapi_mp3_total(const void *ctx)
{
    return (u32)mp3_total_frames_estimate(ctx);
}
