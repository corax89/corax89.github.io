#ifndef TEST_IMGSVC_H
#define TEST_IMGSVC_H
/* хост: FPU-лок не нужен (одна нить) */
void img_fpu_lock(void);
void img_fpu_unlock(void);
#endif
