/* dr_mp3.h — MP3-декодер N2600-OS (сессия 60).
 *
 * Основная библиотека декодирования MP3 для ВСЕХ приложений ОС:
 * нативный MP3-плеер (apps_mp3.c), kapi-функции mp3_* для c4/CMScript
 * приложений (см. kapi.h), будущие приложения.
 *
 * Вендор dr_libs/dr_mp3 v0.7.4 (public domain / MIT-0, автор David Reid,
 * ядро — minimp3 от Lieff). Полный исходник — src/dr_mp3_impl.h;
 * единственная единица трансляции с DR_MP3_IMPLEMENTATION — src/mp3svc.c.
 *
 * Конфигурация для freestanding-ядра (в духе stb_image):
 *   - DR_MP3_NO_STDIO   — без файлов/stdio/wchar/errno;
 *   - DRMP3_ASSERT      — без <assert.h> (нет в src/);
 *   - DRMP3_MALLOC/FREE — куча ядра (mem.c), DRMP3_REALLOC — в ядре нет
 *     realloc; все вызовы идут с явными allocation callbacks
 *     (onRealloc = NULL), поэтому дефолтный realloc не вызывается
 *     никогда, а при прямом вызове вернёт NULL (без порчи данных);
 *   - SIMD не активируется: сборка без __SSE2__ → скалярный путь.
 *
 * ВАЖНО (FPU): внутренний синтезатор dr_mp3 работает во float (x87).
 * Планировщик ядра НЕ сохраняет FPU-состояние между задачами — любое
 * декодирование выполнять под ОБЩИМ FPU-локом imgsvc
 * (img_fpu_lock/img_fpu_unlock), как и stb_image. Это делает mp3svc. */
#ifndef DR_MP3_H_N2600
#define DR_MP3_H_N2600

#define DR_MP3_NO_STDIO 1

#include "dr_mp3_impl.h"

#endif /* DR_MP3_H_N2600 */
