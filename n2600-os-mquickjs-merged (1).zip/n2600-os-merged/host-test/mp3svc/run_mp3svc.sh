#!/bin/sh
# run_mp3svc.sh — хост-тест mp3svc (dr_mp3) на реальном mp3-файле.
# Схема rtlwifi/s55: настоящий mp3svc.c копируется в каталог харнесса,
# где его quote-включения затеняются libc-заглушками.
set -e
cd "$(dirname "$0")"
SRC=/home/z/my-project/work/n2600/src
MP3="${1:-/home/z/.venv/lib/python3.12/site-packages/gradio/media_assets/audio/cate_blanch.mp3}"

for f in mp3svc.c mp3svc.h dr_mp3.h dr_mp3_impl.h; do cp $SRC/$f .; done

gcc -std=c99 -g -O1 -Wall -Wextra -Wno-unused-parameter     mp3svc_test.c mp3svc_host.c mp3svc.c -o mp3svc_test
./mp3svc_test "$MP3"

if gcc -std=c99 -g -O1 -fsanitize=address,undefined     mp3svc_test.c mp3svc_host.c mp3svc.c -o mp3svc_test_asan 2>/dev/null; then
    ./mp3svc_test_asan "$MP3" >/dev/null 2>asan_mp3.log
    if grep -q "AddressSanitizer\|runtime error" asan_mp3.log; then
        echo "=== ASAN/UBSAN НАШЁЛ ПРОБЛЕМЫ ==="; head -20 asan_mp3.log; exit 1
    fi
    echo "ASan/UBSan: чисто"
fi
