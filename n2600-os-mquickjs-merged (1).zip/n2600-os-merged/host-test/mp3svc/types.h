#ifndef TEST_TYPES_H
#define TEST_TYPES_H
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned long long u64;
typedef signed char    i8;
typedef short          i16;
typedef int            i32;
typedef long long      i64;
#define STATIC_ASSERT(cond, name) _Static_assert(cond, #name)
#endif
