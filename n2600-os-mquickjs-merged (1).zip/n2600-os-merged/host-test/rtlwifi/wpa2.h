/* wpa2.h — криптография и EAPOL для WPA2-PSK (CCMP) — сессия 12.
 * См. комментарий в wpa2.c. Файл не зависит от остального ядра
 * (только types.h/string.h) — компилируется и на хосте для тестов. */
#ifndef WPA2_H
#define WPA2_H

#include "types.h"

/* --- примитивы --- */
void wpa2_sha1(const void *data, u32 len, u8 out[20]);
void wpa2_hmac_sha1(const u8 *key, u32 key_len,
                    const u8 *data, u32 data_len, u8 out[20]);
void wpa2_hmac_md5(const u8 *key, u32 key_len,
                   const u8 *data, u32 data_len, u8 out[16]);
/* RC4 со смещением потока (WPA-группа ver 1: skip = 256) */
void wpa2_rc4_skip(const u8 *key, u32 key_len, u32 skip,
                   u8 *data, u32 data_len);
void wpa2_pbkdf2_sha1(const u8 *pass, u32 pass_len,
                      const u8 *salt, u32 salt_len,
                      u32 iters, u8 *out, u32 out_len);
void wpa2_prf(const u8 *key, u32 key_len, const char *label,
              const u8 *data, u32 data_len, u8 *buf, u32 buf_len);

/* WPA2-PSK: PMK = PBKDF2(парольная фраза, SSID, 4096, 32);
 * PTK = PRF(PMK, "Pairwise key expansion", min/max AA/SPA,
 * min/max ANonce/SNonce) → KCK[16] + KEK[16] + TK[16]. Порядок min/max
 * ОДИН И ТОТ ЖЕ для RSN (2) и WPA (254) — wpa_pmk_to_ptk() в hostap
 * сортирует безусловно (проверено по 0.5.5 и текущему master). */
void wpa2_derive_ptk_ex(const u8 pmk[32],
                        const u8 aa[6], const u8 spa[6],
                        const u8 anonce[32], const u8 snonce[32],
                        u8 *ptk, u32 ptk_len);
/* CCMP-пара: 48 б (KCK16+KEK16+TK16). TKIP-пара: 64 б
 * (+ MIC AP→STA на 48, MIC STA→AP на 56) — wpa2_derive_ptk. */
void wpa2_derive_ptk(const u8 pmk[32],
                     const u8 aa[6], const u8 spa[6],
                     const u8 anonce[32], const u8 snonce[32],
                     u8 ptk[48]);

/* --- AES-128 --- */
void wpa2_aes128_encrypt(const u8 key[16], const u8 in[16], u8 out[16]);
void wpa2_aes128_decrypt(const u8 key[16], const u8 in[16], u8 out[16]);

/* RFC 3394: key wrap/unwrap (KEK). unwrap: 1 = успех (IV сошёлся). */
int  wpa2_aes_unwrap(const u8 kek[16], const u8 *in, u32 in_len, u8 *out);
void wpa2_aes_wrap(const u8 kek[16], const u8 *in, u32 in_len, u8 *out);

/* --- EAPOL-Key --- */
typedef struct {
    u8  ver;              /* EAPOL version */
    u8  desc_type;        /* 2 = RSN, 254 = WPA */
    u16 key_info;         /* host order */
    u16 key_len;
    const u8 *replay;     /* 8 байт */
    const u8 *nonce;      /* 32 (ANonce/SNonce) */
    const u8 *iv;         /* 16 */
    const u8 *rsc;        /* 8 */
    const u8 *reserved;   /* 8 */
    const u8 *mic;        /* 16 */
    u16 key_data_len;
    const u8 *key_data;
    const u8 *frame;      /* весь Ethernet-кадр */
    u32 frame_len;
} eapol_key_t;

/* Биты Key Info (host order) */
#define WPA2_KI_VER_MASK   0x0007
#define WPA2_KI_VER_AES    0x0002   /* HMAC-SHA1 + AES key wrap (CCMP) */
#define WPA2_KI_KEY_TYPE   0x0008   /* 1 = pairwise */
#define WPA2_KI_KEY_INDEX  0x0030
#define WPA2_KI_INSTALL    0x0040
#define WPA2_KI_ACK        0x0080
#define WPA2_KI_MIC        0x0100
#define WPA2_KI_SECURE     0x0200
#define WPA2_KI_ERROR      0x0400
#define WPA2_KI_REQUEST    0x0800
#define WPA2_KI_ENCR_DATA  0x1000

/* Разобрать EAPOL-Key из Ethernet-кадра (ethertype 0x888E). 1 = ок.
 * Дескриптор 2 (RSN) и 254 (WPA). */
int  wpa2_parse_eapol_key(const u8 *eth, u32 len, eapol_key_t *k);

/* MIC = HMAC-SHA1(KCK, кадр от EAPOL-version до конца, MIC=0)[0..15].
 * eapol_mic вычисляет, eapol_set_mic вписывает в кадр.
 * eapol_mic2 — по версии дескриптора: 1 = HMAC-MD5, 2/3 = HMAC-SHA1. */
void wpa2_eapol_mic(const u8 kck[16], const u8 *frame, u32 frame_len,
                    u8 mic[16]);
void wpa2_eapol_mic2(u8 ver, const u8 kck[16], const u8 *frame,
                     u32 frame_len, u8 mic[16]);
/* Сравнение за константное время: 1 = равны. */
int  wpa2_ct_equal(const void *a, const void *b, u32 n);
void wpa2_eapol_set_mic(u8 *frame, const u8 mic[16]);

/* Michael MIC (TKIP): key = 8-байтный TX/RX MIC-ключ, DA/SA — адреса
 * MSDU, msdu — LLC/SNAP+payload. Выход 8 байт (LE). СЕССИЯ 51: на
 * 8192EU Michael считается в софте (железо — только RC4). */
void wpa2_tkip_michael(const u8 key[8], const u8 da[6], const u8 sa[6],
                       const u8 *msdu, u32 msdu_len, u8 out[8]);

/* Собрать Ethernet-кадр EAPOL-Key (MIC нулевой). Возвращает длину.
 * _ex — с типом дескриптора и полем Key Length (WPA: эхо точки,
 * RSN: 0 — как в wpa_supplicant send_2_of_4 / send_4_of_4). */
u32  wpa2_build_eapol_key_ex(u8 *frame, const u8 dst[6], const u8 src[6],
                             u8 desc_type, u16 key_info, u16 key_len,
                             const u8 *nonce, const u8 *replay,
                             const u8 *key_data, u16 key_data_len);
u32  wpa2_build_eapol_key(u8 *frame, const u8 dst[6], const u8 src[6],
                          u16 key_info, const u8 *nonce /* 32 или NULL */,
                          const u8 *replay /* 8 */,
                          const u8 *key_data, u16 key_data_len);

/* RSN IE (Association Request / M2): CCMP pairwise, PSK AKM.
 * Пишет ie_len+2 байт, возвращает длину (22). */
u32  wpa2_build_rsn_ie(u8 *out, int group_tkip, int pairwise_tkip);

/* WPA IE (Microsoft 00:50:F2, тип 01) для СМЕШАННЫХ точек WPA+WPA2 —
 * реальный клиент шлёт ОБА IE. Группа — от точки (TKIP/CCMP).
 * Возвращает длину (26). */
u32  wpa2_build_wpa_ie(u8 *out, int group_tkip, int pairwise_tkip);

#endif /* WPA2_H */
