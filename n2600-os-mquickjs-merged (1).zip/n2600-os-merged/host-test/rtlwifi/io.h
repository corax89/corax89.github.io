#ifndef IO_H
#define IO_H
static inline unsigned char inb(unsigned short p)  { (void)p; return 0xff; }
static inline void outb(unsigned short p, unsigned char v) { (void)p; (void)v; }
#endif
