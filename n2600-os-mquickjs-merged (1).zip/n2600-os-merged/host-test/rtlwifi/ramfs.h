#ifndef RAMFS_H
#define RAMFS_H
#include "types.h"
int  ramfs_ready(void);
int  ramfs_create(const char *name, u32 size);
int  ramfs_write(const char *name, const void *buf, u32 size);
u32  ramfs_read(const char *name, void *buf, u32 max);
int  ramfs_delete(const char *name);
#endif
