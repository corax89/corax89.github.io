#ifndef KERNEL_H
#define KERNEL_H
void klog_puts(const char *s);
#endif
