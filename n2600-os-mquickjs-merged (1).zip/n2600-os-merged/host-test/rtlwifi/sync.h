#ifndef SYNC_H
#define SYNC_H
static inline void s_lock(volatile int *l)   { (void)l; }
static inline void s_unlock(volatile int *l) { (void)l; }
#endif
