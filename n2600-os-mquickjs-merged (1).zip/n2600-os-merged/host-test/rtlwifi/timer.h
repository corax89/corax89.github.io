#ifndef TIMER_H
#define TIMER_H
#include "types.h"
u32 timer_ticks(void);
#endif
