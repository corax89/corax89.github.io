#ifndef TEST_STRING_H
#define TEST_STRING_H
#include <string.h>
#define snprintf test_snprintf
#define vsnprintf test_vsnprintf
#endif
