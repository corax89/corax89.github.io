/* usb_ehci.h — драйвер EHCI (USB 2.0) для N2600-OS.
 *
 * Реализовано:
 *   - PCI-сканирование на EHCI (class 0x0C0320).
 *   - Захват контроллера у BIOS (USBLEGSUP).
 *   - Сброс HC (USBCMD.HCRESET).
 *   - Инициализация periodic list и async list.
 *   - Структуры QH (Queue Head) и qTD (queue element TD) с 32-байтным выравниванием.
 *   - Control-трансферы: SETUP + DATA + STATUS через async schedule.
 *   - Bulk-трансферы (для mass-storage).
 *
 * Что НЕ реализовано:
 *   - Periodic schedule (interrupt transfers для HID). UHCI покрывает HID на low/full-speed.
 *   - Split transactions (TT) для low/full-speed устройств на EHCI-портах.
 *     Драйвер EHCI работает только с hi-speed устройствами (флешки).
 *
 * Взаимодействие с другими модулями:
 *   usb_ehci_init() — вызывается из usb_init() после UHCI.
 *   usb_ehci_read_sector(lba, buf) — чтение сектора 512 байт с USB-флешки.
 */
#ifndef USB_EHCI_H
#define USB_EHCI_H

#include "types.h"

void usb_ehci_init(void);
int  usb_ehci_present(void);
int  usb_ehci_storage_ready(void);

/* Сессия 30: горячее подключение EHCI. Гасит CSC на всех портах,
 * отдаёт FS/LS устройства companion-контроллеру, перечисляет новые
 * hi-speed устройства (RTL8192EU/флешки). Возвращает 1, если был
 * event подключения или перечислено новое устройство.
 * Сессия 35: вызывается из фоновой скан-задачи (спавнится главным
 * циклом по CSC), НЕ из wifi-задачи — та может застрять в probe-фазе. */
int  usb_ehci_hotplug_service(void);

/* СЕССИЯ 35: быстрые предикаты для главного цикла (только чтение
 * PORTSC, состояние не меняют) — решить, спавнить ли скан-задачу. */
int  usb_ehci_csc_pending(void);   /* есть непогашенный CSC хоть на одном порту */
int  usb_ehci_work_pending(void);  /* CSC или есть живой необслуженный порт */

/* Чтение сектора 512 байт с USB-флешки.
 * Возвращает 1 при успехе, 0 при ошибке. */
int  usb_ehci_read_sector(u32 lba, void *buf);

/* Запись сектора 512 байт на USB-флешку (WRITE 10 + CBW с OUT data).
 * Возвращает 1 при успехе, 0 при ошибке. */
int  usb_ehci_write_sector(u32 lba, const void *buf);

/* ---- сессия 28: сервис для class-драйверов WiFi (rtl8192eu.c) ---- */

/* Control-трансфер с произвольной запрос-парой (vendor-регистры
 * Realtek 0xC5/0x45 + bRequest 0x05). data_in=1 — IN. */
int usb_ehci_ctrl_xfer(int addr, u8 bmReqType, u8 bReq,
                       u16 wValue, u16 wIndex, void *data, int len, int data_in);

/* Сессия 41: CLEAR_FEATURE(ENDPOINT_HALT) — сброс halt/toggle endpoint'а
 * на стороне устройства (wIndex = номер EP | 0x80 для IN). */
int usb_ehci_clear_halt(int addr, int ep_addr);

/* Bulk-трансфер (RX/TX кадры 802.11). Возвращает len или -1.
 * Таймаут по умолчанию — 2 с (сектора, длинные кадры). */
int usb_ehci_bulk_xfer(int addr, int ep, int ep_size, int data_in,
                       void *buf, int len);

/* Сессия 32: bulk с ЯВНЫМ таймаутом (микросекунды). Для RX-поллинга
 * WiFi: пустой endpoint NAK-ится — не нужно ждать 2 с, десятки мс
 * достаточно. Ожидание внутри — hlt-пауза, CPU другим задачам. */
int usb_ehci_bulk_xfer_to(int addr, int ep, int ep_size, int data_in,
                          void *buf, int len, u32 timeout_us);

/* ---- Сессия 40: постоянная RX-очередь (bulk IN) для WiFi ----
 * RX-трансфер ставится в async-кольцо ОДИН РАЗ и живёт там, пока не
 * придут данные: НИКАКИХ таймаутов/абортов (abort по таймауту на
 * середине DMA клинит прошивку RTL8192EU — EP0 и EP4 молчали навсегда
 * после первого полного скана). */

/* Поставить RX-трансфер в кольцо (idempotent: если уже стоит — 1). */
int  usb_ehci_rx_arm(int addr, int ep, int ep_size, void *buf, int len);

/* Неблокирующий опрос:
 *   -1  — данных ещё нет (очередь ждёт, нулевая цена);
 *  0..n — принято n байт (очередь пуста — нужен rearm);
 *   -2  — ошибка транзакции (очередь снята — rearm/arm поставит заново). */
int  usb_ehci_rx_poll(void);

/* Поставить qTD обратно в очередь после успешного poll. */
int  usb_ehci_rx_rearm(void);

/* Снять RX-очередь с кольца (detach/recovery; с doorbell). */
int  usb_ehci_rx_disarm(void);

/* Сессия 40: сброс ПОРТА, на котором перечислено устройство addr,
 * + забыть порт (перечисление hot-plug пройдёт заново). Для
 * восстановления адаптера, переставшего отвечать по USB. */
int  usb_ehci_reset_wifi_device(int addr);

#endif /* USB_EHCI_H */
