/* СИНТАКС/ХОСТ-ЗАГЛУШКИ для теста диспетчера задач (НЕ для ОС!).
 * Воспроизводят API, который apps_taskmgr.c реально использует. */
#ifndef TM_STUBS_H
#define TM_STUBS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef signed char        i8;
typedef unsigned char      u8;
typedef short              i16;
typedef unsigned short     u16;
typedef int                i32;
typedef unsigned int       u32;
typedef long long          i64;
typedef unsigned long long u64;
typedef unsigned int       size_k;

/* ---------------- task.h ---------------- */
#define MAX_TASKS 16
int  task_spawn(const char *name, void (*fn)(void *), void *arg);
int  task_used(int idx);
int  task_finished(int idx);
int  task_is_system(int idx);
const char *task_name(int idx);
u32  task_uptime(int idx);
int  task_current(void);
int  task_count(void);
int  task_kill(int idx);

/* ---------------- mem.h ---------------- */
u32  mem_used(void);
u32  mem_heap_size(void);
u32  mem_task_used(int slot);

/* ---------------- timer.h ---------------- */
u32  uptime_sec(void);

/* ---------------- net.h (только нужное диспетчеру) ---------------- */
u32  net_tx_bytes(void);
u32  net_rx_bytes(void);

/* ---------------- fb.h ---------------- */
u32  fb_rgb(u8 r, u8 g, u8 b);
void fb_fill_rect(int x, int y, int w, int h, u32 color);
void fb_rect(int x, int y, int w, int h, u32 color);
void fb_hline(int x0, int x1, int y, u32 color);
void fb_vline(int x, int y0, int y1, u32 color);
void fb_text(int x, int y, const char *s, u32 color, int bg);
u32  fb_text_w(const char *s);
int  fb_width(void);
int  fb_height(void);

/* ---------------- kbd.h ---------------- */
#define KF_RELEASED 0x01
#define KBD_UP   0x48
#define KBD_DOWN 0x50
typedef struct { u8 code; char ch; u8 flags; } key_event_t;

/* ---------------- mouse.h ---------------- */
#define MSB_LEFT  0x01
#define MSB_RIGHT 0x02

/* ---------------- wm.h (минимум для диспетчера) ---------------- */
#define TBAR_H  28
#define TITLE_H 24

struct window;
typedef void (*win_draw_fn)(struct window *);
typedef void (*win_key_fn)(struct window *, const key_event_t *);
typedef void (*win_mouse_fn)(struct window *, int mx, int my, u8 buttons, u8 changed);
typedef void (*win_tick_fn)(struct window *);
typedef void (*win_close_fn)(struct window *);

typedef struct window {
    void *data;
    int   cw, ch;          /* размер содержимого */
} window_t;

window_t *win_create(const char *title, int x, int y, int w, int h,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data);
void win_invalidate(window_t *w);
void win_close(window_t *w);
int  win_content_w(window_t *w);
int  win_content_h(window_t *w);
void wm_request_kill(int task_idx);

typedef struct { const char *label; int id; u8 disabled; } wm_menu_item_t;
typedef void (*wm_menu_fn)(int id, void *uctx);
void wm_menu_open(window_t *owner, int content_x, int content_y,
                  const wm_menu_item_t *items, int n, wm_menu_fn cb, void *uctx);
int  wm_menu_active(void);
int  wm_text_fit(int x, int y, const char *s, int max_w, u32 color, int center);

u32 wm_theme_win_bg(void);
u32 wm_theme_win_bg_alt(void);
u32 wm_theme_text(void);
u32 wm_theme_text_info(void);
u32 wm_theme_title(void);
u32 wm_theme_accent(void);
u32 wm_theme_sel_bg(void);

/* ---------------- apps.h ---------------- */
void app_taskmgr_open(void);

#endif
