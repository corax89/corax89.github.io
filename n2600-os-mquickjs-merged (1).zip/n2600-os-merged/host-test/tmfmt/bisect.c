#include <stdio.h>
static void a(void){ printf("A\n"); }
int main(void){ printf("start\n"); a(); return 0; }
