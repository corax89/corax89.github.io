/* test_mem59.c — сессия 59: проверка укреплённого аллокатора mem.c
 * (реальный src/mem.c, 64-битный хост, куча на фиксированном mmap
 * ниже 4 ГиБ, чтобы u32-усечение указателей было корректным).
 *
 * Сборка: gcc -std=c99 -g -O1 -fsanitize=address,undefined \
 *           -o test_mem59 test_mem59.c ../src/mem.c -I../src
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include "types.h"
#include "mem.h"

/* --- стабы того, что mem.c ожидает от ядра --- */
static int g_task = 0;
int task_current(void) { return g_task; }
void serial_puts(const char *s) { fputs(s, stdout); }
int snprintf(char*, u32, const char*, ...);   /* libc */

/* mem.c ожидает linker-символ bss_end; на хосте даём определение */
unsigned char bss_end[1];

extern void mem_init(const mb_info_t *mb);   /* реальный */

static int PASS = 0, FAIL = 0;
#define CHECK(name, cond) do { \
    if (cond) { PASS++; printf("  [ok] %s\n", name); } \
    else      { FAIL++; printf("  [FAIL] %s\n", name); } } while (0)

#define HEAP_ADDR 0x10000000u
#define HEAP_LEN  (4u * 1024 * 1024)

int main(void)
{
    printf("== test_mem59: укреплённый аллокатор ==\n");

    void *ram = mmap((void *)(unsigned long)HEAP_ADDR, HEAP_LEN,
                     PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (ram == MAP_FAILED) { perror("mmap"); return 2; }
    memset(ram, 0, HEAP_LEN);

    /* фейковая карта multiboot: один регион type=1 ровно по mmap */
    struct { u32 size; u64 addr; u64 len; u32 type; } ent = {
        24, HEAP_ADDR, HEAP_LEN, 1
    };
    struct {
        u32 flags;
        u32 dummy[6];
        u32 mmap_addr; u32 mmap_length;
    } mb = { 0, {0,0,0,0,0,0}, (u32)(unsigned long)&ent, sizeof(ent) };
    /* MBIF_MMAP = бит 6 (см. boot.h) */
    mb.flags = (1u << 6);

    mem_init((const mb_info_t *)&mb);
    CHECK("куча поднята", mem_heap_size() > 0);

    /* --- 1. нормальные аллокации --- */
    void *a = malloc(100);
    void *b = malloc(1000);
    CHECK("malloc 100/1000", a && b);
    memset(a, 0xAB, 100);
    memset(b, 0xCD, 1000);
    free(a);
    free(b);
    CHECK("free без ошибок", 1);

    /* --- 2. дикий free (мимо кучи) не пишет в память --- */
    static u8 scratch[64];
    memset(scratch, 0x77, sizeof(scratch));
    free(scratch + 16);           /* не указатель из кучи */
    int intact = 1;
    for (int i = 0; i < 64; i++) if (scratch[i] != 0x77) intact = 0;
    CHECK("дикий free не портит память", intact);

    /* --- 3. двойной free не ломает соседей --- */
    void *c = malloc(64);
    free(c);
    free(c);                      /* дубль */
    void *d = malloc(64);
    CHECK("после двойного free аллокация жива", d != NULL);
    free(d);

    /* --- 4. нулевой/гигантский запрос (ALIGN8-wrap раньше давал need=4!) --- */
    CHECK("malloc(0) = NULL", malloc(0) == NULL);
    void *huge = malloc(0xFFFFFFF0u);
    CHECK("malloc(0xFFFFFFF0) отказ (не порча)", huge == NULL);
    void *e = malloc(32);
    CHECK("куча жива после гигантского запроса", e != NULL);
    free(e);

    /* --- 5. порча заголовка: walk останавливается, отказ без шторма --- */
    void *f = malloc(128);
    CHECK("malloc 128 перед порчей", f != NULL);
    /* порча: гигантский запрос уже был отклонён — вручную ломаем блок:
     * пишем size=4 в заголовок выделенного блока (как в логе fixed58) */
    {
        unsigned char *hdr = (unsigned char *)f - 8;
        hdr[0] = 4; hdr[1] = 0; hdr[2] = 0; hdr[3] = 0;   /* size=4 */
        hdr[4] = 0; hdr[5] = 0; hdr[6] = 0; hdr[7] = 0;   /* used=0 */
    }
    CHECK("mem_check_corrupt ловит size=4", mem_check_corrupt() == 1);
    void *g = malloc(4096);
    CHECK("malloc после порчи отказ (без зависания)", g == NULL);
    free(f);   /* дикий free теперь отклоняется заголовком — не пишет */

    printf("\nИтого: %d ok, %d fail\n", PASS, FAIL);
    return FAIL ? 1 : 0;
}
