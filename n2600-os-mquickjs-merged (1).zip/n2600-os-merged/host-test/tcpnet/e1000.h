#ifndef e1000_H
#define e1000_H
#include "types.h"
static inline int e1000_present(void) { return 0; }
static inline int e1000_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
static inline u32 e1000_recv(void *b, u32 m) { (void)b; (void)m; return 0; }
static inline int e1000_link_up(void) { return 0; }
static inline void e1000_get_mac(u8 *m) { (void)m; }
#endif
