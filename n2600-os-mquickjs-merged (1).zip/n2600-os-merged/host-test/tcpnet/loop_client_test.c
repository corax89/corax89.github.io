/* loop_client_test.c — репро «localhost ничего не отдаёт» (сессия 61):
 * клиент — ЧЕРЕЗ net_http_get_impl (как браузер ОС), сервер —
 * net_httpd, транспорт — loopback-пара net.c. Виртуальное время
 * двигается task_yield (1 тик), между ожиданиями крутится net_poll —
 * как в ОС. Сборка как у httpd60_test. */
#include <stdio.h>
#include <string.h>

#include "net.h"
#include "net_httpd.h"
#include "ramfs.h"
#include "timer.h"
#include "task.h"
#include "mem.h"

extern void fake_nic_up(void);
/* TLS/DHCP-заглушки — общие: stubs_net/tls_stubs.c */

static int g_fail = 0;
#define CHECK(cond, ...) do { \
        if (cond) { printf("  OK  " __VA_ARGS__); printf("\n"); } \
        else { printf("  FAIL " __VA_ARGS__); printf("\n"); g_fail++; } \
    } while (0)

/* ---------------- RAM disk-заглушка (как в httpd60_test) ---------------- */

#define SF_MAX 16
typedef struct { char name[80]; u32 size; u8 *data; int is_dir; } sfile_t;
static sfile_t g_sf[SF_MAX];
static int g_sf_n = 0;

static void sf_reset(void)
{
    for (int i = 0; i < g_sf_n; i++) free(g_sf[i].data);
    g_sf_n = 0;
}

static int sf_find_ci(const char *name)
{
    for (int i = 0; i < g_sf_n; i++) {
        const char *a = g_sf[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) return i;
    }
    return -1;
}

int ramfs_ready(void) { return 1; }

/* ---- МОДЕЛЬ IPC RAMFS: пока задача-обработчик httpd «спит» на
 * очереди ramfs-сервера, kmain ЖИВЁТ и крутит net_poll +
 * net_httpd_poll (FSM сессии 60). Эмулируем: заглушки ramfs
 * прокачивают net_httpd_poll перед ответом. На НЕисправленном коде
 * это убивает обработку запроса (слот закрывается из-под
 * обработчика), на исправленном (in_handler) — проходит. ---- */
static int g_ipc_sim = 0;
static void ipc_sim_kmain_alive(void)
{
    if (!g_ipc_sim) return;
    for (int i = 0; i < 4; i++) {
        net_poll();          /* kmain: приём/таймеры */
        net_httpd_poll();    /* kmain: FSM httpd (сессия 60) */
    }
}

int ramfs_mkdir(const char *path)
{
    if (sf_find_ci(path) >= 0) return 0;
    if (g_sf_n >= SF_MAX) return 0;
    sfile_t *f = &g_sf[g_sf_n++];
    memset(f, 0, sizeof(*f));
    snprintf(f->name, sizeof(f->name), "%s", path);
    f->is_dir = 1;
    return 1;
}

int ramfs_create(const char *name, u32 size)
{
    if (sf_find_ci(name) >= 0) return 0;
    if (g_sf_n >= SF_MAX) return 0;
    sfile_t *f = &g_sf[g_sf_n++];
    memset(f, 0, sizeof(*f));
    snprintf(f->name, sizeof(f->name), "%s", name);
    f->data = (u8 *)malloc(size ? size : 1);
    if (f->data) memset(f->data, 0, size ? size : 1);
    f->size = size;
    return 1;
}

int ramfs_write(const char *name, const void *buf, u32 size)
{
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    u32 n = size < g_sf[i].size ? size : g_sf[i].size;
    memcpy(g_sf[i].data, buf, n);
    g_sf[i].size = n;
    return 1;
}

u32 ramfs_read(const char *name, void *buf, u32 max)
{
    ipc_sim_kmain_alive();       /* и здесь */
    int i = sf_find_ci(name);
    if (i < 0 || g_sf[i].is_dir) return 0;
    u32 n = g_sf[i].size < max ? g_sf[i].size : max;
    memcpy(buf, g_sf[i].data, n);
    return n;
}

int ramfs_stat_ci(const char *name, ramfs_dirent_t *out)
{
    ipc_sim_kmain_alive();       /* обработчик «спит» в IPC — kmain живёт */
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    memset(out, 0, sizeof(*out));
    snprintf(out->name, sizeof(out->name), "%s", g_sf[i].name);
    out->size = g_sf[i].size;
    out->is_dir = (u8)g_sf[i].is_dir;
    return 1;
}

int ramfs_file_count(void) { return g_sf_n; }

/* ---------------- тест ---------------- */

int main(void)
{
    sf_reset();
    fake_nic_up();
    net_init();
    net_set_ip(0x0A5C3CC7u);
    net_set_netmask(0xFFFFFF00u);
    net_set_gateway(0x0A050001u);
    net_httpd_start();
    CHECK(net_httpd_running(), "httpd слушает :80");

    static char resp[16384];
    int rc = net_http_get("127.0.0.1", 80, "/hello", resp, sizeof(resp), 10000);
    printf("net_http_get /hello rc=%d err=%s\n", rc, net_http_errstr());
    CHECK(rc > 0 && strstr(resp, "Hello from N2600-OS") != NULL, "базовый запрос");

    /* С IPC-паузами (kmain прокручивает httpd_poll, пока обработчик
     * «спит» в ramfs): "/" идёт через ramfs_stat_ci+read */
    g_ipc_sim = 1;
    rc = net_http_get("127.0.0.1", 80, "/", resp, sizeof(resp), 10000);
    printf("net_http_get / (IPC-пауза) rc=%d err=%s\n", rc, net_http_errstr());
    CHECK(rc > 60, "ответ получен при паузах IPC (%d)", rc);
    if (rc > 0) CHECK(strstr(resp, "HTTP/1.0 200") != NULL, "код 200");

    /* повтор — слот должен освободиться корректно */
    rc = net_http_get("127.0.0.1", 80, "/", resp, sizeof(resp), 10000);
    printf("net_http_get / повтор rc=%d err=%s\n", rc, net_http_errstr());
    CHECK(rc > 60, "повторный запрос при паузах IPC (%d)", rc);

    printf("\n========================================\n");
    if (g_fail == 0) printf("LOOP-CLIENT: ВСЕ ПРОВЕРКИ ЗЕЛЁНЫЕ\n");
    else             printf("LOOP-CLIENT: ПРОВАЛОВ: %d\n", g_fail);
    return g_fail ? 1 : 0;
}
