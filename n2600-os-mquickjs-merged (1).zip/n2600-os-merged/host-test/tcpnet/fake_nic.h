/* fake_nic.h — интерфейс обвязки, общей для fake_nic.c и tcpnet_test.c */
#ifndef FAKE_NIC_H
#define FAKE_NIC_H
#include "types.h"
void fake_server_on_tx(const u8 *frame, u32 len);  /* модель сервера */
void fake_check_tx_checksums(const u8 *f, u32 len);
const char *fake_serial_get(void);
void fake_serial_clear(void);
#endif