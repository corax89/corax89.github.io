#ifndef ATH9K_WIFI_H
#define ATH9K_WIFI_H
#include "types.h"
int  wifi_present(void);
int  wifi_ready(void);
int  wifi_net_link(void);
void wifi_net_get_mac(u8 *m);
int  wifi_net_send(const void *buf, u32 len);
u32  wifi_net_recv(void *buf, u32 max);
#endif
