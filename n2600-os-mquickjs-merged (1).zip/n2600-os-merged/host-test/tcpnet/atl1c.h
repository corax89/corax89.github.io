#ifndef atl1c_H
#define atl1c_H
#include "types.h"
static inline int atl1c_present(void) { return 0; }
static inline int atl1c_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
static inline u32 atl1c_recv(void *b, u32 m) { (void)b; (void)m; return 0; }
static inline int atl1c_link_up(void) { return 0; }
static inline void atl1c_get_mac(u8 *m) { (void)m; }
#endif
