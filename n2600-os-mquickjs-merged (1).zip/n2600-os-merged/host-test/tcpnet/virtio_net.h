#ifndef virtio_net_H
#define virtio_net_H
#include "types.h"
static inline int virtio_net_present(void) { return 0; }
static inline int virtio_net_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
static inline u32 virtio_net_recv(void *b, u32 m) { (void)b; (void)m; return 0; }
static inline int virtio_net_link_up(void) { return 0; }
static inline void virtio_net_get_mac(u8 *m) { (void)m; }
#endif
