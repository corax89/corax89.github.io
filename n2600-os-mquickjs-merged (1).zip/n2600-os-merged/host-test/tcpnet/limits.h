/* limits.h — freestanding-заглушка для ядра N2600-OS.
 *
 * Зачем: stb_image.h (src/stb_image.h) делает #include <limits.h>.
 * Встроенный limits.h GCC в hosted-режиме делает include_next в
 * libc-версию (/usr/include/limits.h), которой в freestanding-сборке
 * с -m32 нет (нет 32-битных glibc-хедеров). Этот файл перехватывает
 * <limits.h> (сборка идёт с -Isrc) и определяет всё нужное напрямую.
 *
 * Макрос _LIBC_LIMITS_H_ дополнительно блокирует include_next внутри
 * встроенного limits.h GCC, если он подключается раньше (поэтому
 * заглушка корректно работает и при вложенных включениях).
 */
#ifndef LIMITS_H
#define LIMITS_H

#ifndef _LIBC_LIMITS_H_
#define _LIBC_LIMITS_H_    /* блокирует include_next libc-версии в GCC */

#ifndef CHAR_BIT
#define CHAR_BIT   8
#endif

/* signed char */
#define SCHAR_MIN  (-128)
#define SCHAR_MAX  127
/* unsigned char */
#define UCHAR_MAX  255
/* char */
#ifdef __CHAR_UNSIGNED__
#define CHAR_MIN   0
#define CHAR_MAX   UCHAR_MAX
#else
#define CHAR_MIN   SCHAR_MIN
#define CHAR_MAX   SCHAR_MAX
#endif
/* short */
#define SHRT_MIN   (-32768)
#define SHRT_MAX   32767
#define USHRT_MAX  65535
/* int (i386/i686: 32 бита) */
#define INT_MIN    (-2147483647 - 1)
#define INT_MAX    2147483647
#define UINT_MAX   4294967295u
/* long (i386: 32 бита) */
#define LONG_MIN   (-2147483647L - 1L)
#define LONG_MAX   2147483647L
#define ULONG_MAX  4294967295ul
/* long long (GCC x86) */
#define LLONG_MIN  (-9223372036854775807LL - 1LL)
#define LLONG_MAX  9223372036854775807LL
#define ULLONG_MAX 18446744073709551615ull

#endif /* _LIBC_LIMITS_H_ */
#endif /* LIMITS_H */
