/* sync_host.h — хост-версия sync.h для тестов (однозадачная модель).
 * API совпадает с ядром; в однопоточном хост-тесте блокировки
 * никогда не оспариваются (task_yield не вытесняет). */
#ifndef SYNC_HOST_H
#define SYNC_HOST_H
#include "types.h"
#include "task.h"
#include "timer.h"

#define SLOCK_STALE_TICKS 2000

static inline int slock_owner_of(int v) { return v > 0 ? v - 1 : -1; }
static inline void s_unlock(volatile int *l)
{
    int me = task_current() + 1;
    if (*l == me) *l = 0;
    __asm__ __volatile__("" ::: "memory");
}
static inline void s_lock(volatile int *l)
{
    if (*l == 0) { *l = task_current() + 1; return; }
    while (*l) { /* однозадачно: не должно случиться */ }
    *l = task_current() + 1;
}
static inline int s_trylock(volatile int *l)
{
    if (*l == 0) { *l = task_current() + 1; return 1; }
    return 0;
}
#endif
