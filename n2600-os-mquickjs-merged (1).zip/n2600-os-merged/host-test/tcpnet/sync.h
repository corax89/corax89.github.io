#ifndef SYNC_H
#define SYNC_H
#include "types.h"
static inline void s_lock(volatile int *l) { while (*l) { } *l = 1; }
static inline void s_unlock(volatile int *l) { *l = 0; }
static inline int s_trylock(volatile int *l) { if (*l) return 0; *l = 1; return 1; }
static inline int slock_owner_of(int v) { return v > 0; }
#endif
