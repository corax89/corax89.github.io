#ifndef ne2000_H
#define ne2000_H
#include "types.h"
static inline int ne2000_present(void) { return 0; }
static inline int ne2000_send(const void *b, u32 l) { (void)b; (void)l; return -1; }
static inline u32 ne2000_recv(void *b, u32 m) { (void)b; (void)m; return 0; }
static inline int ne2000_link_up(void) { return 0; }
static inline void ne2000_get_mac(u8 *m) { (void)m; }
#endif
