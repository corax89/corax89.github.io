/* tls_stubs.c — общие заглушки net_tls для хост-харнессов (сессия 60).
 *
 * TLS-модуль (bearssl) в хост-тесты не линкуется; net_http.c ссылается
 * на его API — здесь пустые реализации. DHCP не тестируется —
 * net_dhcp_state() отвечает DHCP_BOUND. */
#include "types.h"
#include "net.h"

void tls_set_sink(void (*sink)(const void *data, u32 len))
{
    (void)sink;
}

int tls_start(int sock, const char *hostname, u32 max_ms)
{
    (void)sock; (void)hostname; (void)max_ms;
    return 0;
}

int tls_send_all(const void *data, u32 len)
{
    (void)data; (void)len;
    return 0;
}

void tls_pump(void) {}
void tls_shutdown(int sock) { (void)sock; }

const char *tls_errstr(void) { return "tls: недоступно в харнессе"; }

void tls_tcp_recv(int sock, u32 src_ip, u16 src_port,
                  const void *data, u32 len)
{
    (void)sock; (void)src_ip; (void)src_port; (void)data; (void)len;
}

dhcp_state_t net_dhcp_state(void) { return DHCP_BOUND; }
