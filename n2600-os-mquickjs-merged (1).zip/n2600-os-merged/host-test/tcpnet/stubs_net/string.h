/* ЗАГЛУШКА string.h для хост-тестов: только объявления —
 * реализации даст libc при линковке. Файл называется string.h,
 * поэтому #include <string.h> здесь использовать нельзя:
 * "string.h" резолвится обратно в этот же файл. */
#ifndef STUB_STRING_H
#define STUB_STRING_H
#include <stddef.h>
void  *memcpy(void *d, const void *s, size_t n);
void  *memmove(void *d, const void *s, size_t n);
void  *memset(void *d, int c, size_t n);
int    memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
char  *strcpy(char *d, const char *s);
char  *strncpy(char *d, const char *s, size_t n);
char  *strcat(char *d, const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, size_t n);
char  *strstr(const char *h, const char *n);
char  *strchr(const char *s, int c);
int    snprintf(char *d, size_t n, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));
#endif
