/* ЗАГЛУШКА virtio_net.h для хост-тестов */
#ifndef STUB_VIRTIO_H
#define STUB_VIRTIO_H
#include "types.h"
int  virtio_net_present(void);
int  virtio_net_get_mac(u8 out_mac[6]);
int  virtio_net_send(const void *buf, u32 len);
u32  virtio_net_recv(void *out_buf, u32 out_max);
const char *virtio_net_chip_name(void);
#endif
