/* ЗАГЛУШКА atl1c.h для хост-тестов */
#ifndef STUB_ATL1C_H
#define STUB_ATL1C_H
#include "types.h"
int  atl1c_present(void);
int  atl1c_link_up(void);
int  atl1c_get_mac(u8 out_mac[6]);
int  atl1c_send(const void *buf, u32 len);
u32  atl1c_recv(void *out_buf, u32 out_max);
#endif
