/* ЗАГЛУШКА timer.h для хост-тестов: ВИРТУАЛЬНОЕ время.
 * 1 тик = 10 мс (как в ОС, 100 Гц). Продвигается из task_yield()
 * (см. stub в task.h) — так циклы ожидания клиента живут в модельном
 * времени и таймауты «проигрываются» мгновенно. */
#ifndef STUB_TIMER_H
#define STUB_TIMER_H
#include "types.h"
u32 timer_ticks(void);
extern u32 g_vticks;          /* модельное время (тики) */
extern u32 g_yield_per_call;  /* тиков на один task_yield (по умолчанию 1) */
#endif
