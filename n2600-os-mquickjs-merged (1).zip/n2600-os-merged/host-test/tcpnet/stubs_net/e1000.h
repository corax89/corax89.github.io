/* ЗАГЛУШКА e1000.h для хост-тестов: интерфейс фейкового драйвера.
 * Реализация — fake_nic.c (кольцо приёма + журнал передач +
 * хук fake_server_on_tx, в котором живёт модель сервера). */
#ifndef STUB_E1000_H
#define STUB_E1000_H
#include "types.h"
int  e1000_init(void);
int  e1000_present(void);
int  e1000_link_up(void);
const char *e1000_chip_name(void);
int  e1000_get_mac(u8 out_mac[6]);
void e1000_set_dest_mac(const u8 mac[6]);
int  e1000_send(const void *buf, u32 len);
u32  e1000_recv(void *out_buf, u32 out_max);
void e1000_poll(void);
void e1000_debug_dump(void);

/* --- тестовая обвязка (fake_nic.c) --- */
void fake_nic_up(void);
void fake_inject(const void *frame, u32 len);      /* кадр «из провода» ОС */
void fake_tx_clear(void);
int  fake_tx_count(void);
const u8 *fake_tx_frame(int i, u32 *len);
u32  fake_tx_time(int i);          /* виртуальное время кадра */
extern int g_tx_tcp_cs_bad;    /* некорректные TCP-чексуммы ОС */
extern int g_tx_ip_cs_bad;     /* некорректные IP-чексуммы ОС */
#endif
