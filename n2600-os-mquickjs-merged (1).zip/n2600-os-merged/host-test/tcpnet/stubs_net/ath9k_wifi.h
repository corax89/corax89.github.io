/* ЗАГЛУШКА ath9k_wifi.h для хост-тестов */
#ifndef STUB_WIFI_H
#define STUB_WIFI_H
#include "types.h"
int  wifi_present(void);
int  wifi_ready(void);
int  wifi_net_link(void);
int  wifi_net_get_mac(u8 out_mac[6]);
int  wifi_net_send(const void *buf, u32 len);
u32  wifi_net_recv(void *out_buf, u32 out_max);
#endif
