/* ЗАГЛУШКА mem.h для хост-тестов: куча — хостовая.
 * Сигнатуры совпадают с ядром (malloc(u32), free). */
#ifndef STUB_MEM_H
#define STUB_MEM_H
#include "types.h"
void *malloc(u32 n);
void  free(void *p);
u32   mem_used(void);
u32   mem_heap_size(void);
#endif
