/* ЗАГЛУШКА ne2000.h для хост-тестов */
#ifndef STUB_NE2000_H
#define STUB_NE2000_H
#include "types.h"
int  ne2000_present(void);
int  ne2000_get_mac(u8 out_mac[6]);
int  ne2000_send(const void *buf, u32 len);
u32  ne2000_recv(void *out_buf, u32 out_max);
#endif
