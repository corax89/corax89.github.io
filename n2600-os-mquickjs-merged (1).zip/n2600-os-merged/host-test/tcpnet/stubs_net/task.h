/* ЗАГЛУШКА task.h для хост-тестов: однозадачная модель.
 * task_yield() продвигает виртуальное время (g_yield_per_call тиков,
 * по умолчанию 1 = 10 мс) — этим «живут» все таймауты клиента. */
#ifndef STUB_TASK_H
#define STUB_TASK_H
void task_yield(void);
int  task_spawn(const char *name, void (*fn)(void *), void *arg);
void task_exit(void);
int  task_current(void);
int  task_finished(int idx);
void task_wake(int idx);
void task_set_lockwait_me(int on);
#endif
