/* httpd60_test.c — хост-репро httpd N2600-OS (сессия 60).
 *
 * Проверяет исправления по отчёту аудита на РЕАЛЬНОМ net.c +
 * новом net_httpd.c через loopback-пару стека (127.0.0.1):
 *   1. /hello            — 200, Content-Length == фактической длине тела;
 *   2. /                 — файл www/index.html из RAM (ramfs-заглушка);
 *   3. /INDEX.HTML       — поиск без учёта регистра (ramfs_stat_ci);
 *   4. HEAD /hello       — только заголовки, CL тот же, тела нет;
 *   5. GETTER /hello     — 501 (метод с p[3] != ' ' больше не GET);
 *   6. /../x             — 404 (path-safe);
 *   7. /big.bin 16 КиБ   — FSM отправки: ровно CL байт, содержимое целое;
 *   8. /sysinfo          — статусная страница собирается без выхода за
 *                          границы (ASan), CL честный;
 *   9. idle-таймаут      — «молчаливый» клиент выкидывается через 30 с
 *                          (Slowloris), слот освобождается;
 *  10. переполнение слотов — 5-е соединение при 4 занятых отклоняется;
 *  11. SETTINGS.CFG      — "httpd=1" читается целиком (load_cfg).
 *
 * RAM disk — заглушка в этом файле (плоские имена, без учёта регистра);
 * остальное — канонические исходники ОС (симлинки в build_host). */
#include <stdio.h>
#include <string.h>
#include "net.h"
#include "net_httpd.h"
#include "ramfs.h"
#include "timer.h"
#include "task.h"
#include "mem.h"
#include "fake_nic.h"

/* fake_nic.c: обвязка NIC (заголовок не объявляет — объявления тут) */
extern void fake_nic_up(void);
extern void fake_tx_clear(void);
/* TLS/DHCP-заглушки — общие: stubs_net/tls_stubs.c */

/* без <stdlib.h> (конфликт с mem.h): свои минимумы */
static int t_atoi(const char *s)
{
    int v = 0, neg = 0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return neg ? -v : v;
}

/* ---- модель сети: кадры никуда не уходят (loopback-тесты) ---- */
void fake_server_on_tx(const u8 *frame, u32 len) { (void)frame; (void)len; }

static int g_fail = 0;
#define CHECK(cond, ...) do { \
        if (cond) { printf("  OK  " __VA_ARGS__); printf("\n"); } \
        else { printf("  FAIL " __VA_ARGS__); printf("\n"); g_fail++; } \
    } while (0)

/* ---------------- RAM disk-заглушка ---------------- */

#define SF_MAX 16
typedef struct { char name[80]; u32 size; u8 *data; int is_dir; } sfile_t;
static sfile_t g_sf[SF_MAX];
static int g_sf_n = 0;

static void sf_reset(void)
{
    for (int i = 0; i < g_sf_n; i++) free(g_sf[i].data);
    g_sf_n = 0;
}

static int sf_find_ci(const char *name)
{
    for (int i = 0; i < g_sf_n; i++) {
        const char *a = g_sf[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) return i;
    }
    return -1;
}

int ramfs_ready(void) { return 1; }

int ramfs_mkdir(const char *path)
{
    if (sf_find_ci(path) >= 0) return 0;
    if (g_sf_n >= SF_MAX) return 0;
    sfile_t *f = &g_sf[g_sf_n++];
    memset(f, 0, sizeof(*f));
    snprintf(f->name, sizeof(f->name), "%s", path);
    f->is_dir = 1;
    return 1;
}

int ramfs_create(const char *name, u32 size)
{
    if (sf_find_ci(name) >= 0) return 0;
    if (g_sf_n >= SF_MAX) return 0;
    sfile_t *f = &g_sf[g_sf_n++];
    memset(f, 0, sizeof(*f));
    snprintf(f->name, sizeof(f->name), "%s", name);
    f->data = (u8 *)malloc(size ? size : 1);
    if (f->data) memset(f->data, 0, size ? size : 1);
    f->size = size;
    return 1;
}

int ramfs_write(const char *name, const void *buf, u32 size)
{
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    u32 n = size < g_sf[i].size ? size : g_sf[i].size;
    memcpy(g_sf[i].data, buf, n);
    g_sf[i].size = n;
    return 1;
}

u32 ramfs_read(const char *name, void *buf, u32 max)
{
    int i = sf_find_ci(name);
    if (i < 0 || g_sf[i].is_dir) return 0;
    u32 n = g_sf[i].size < max ? g_sf[i].size : max;
    memcpy(buf, g_sf[i].data, n);
    return n;
}

int ramfs_stat_ci(const char *name, ramfs_dirent_t *out)
{
    int i = sf_find_ci(name);
    if (i < 0) return 0;
    memset(out, 0, sizeof(*out));
    snprintf(out->name, sizeof(out->name), "%s", g_sf[i].name);
    out->size = g_sf[i].size;
    out->is_dir = (u8)g_sf[i].is_dir;
    return 1;
}

int ramfs_file_count(void) { return g_sf_n; }

/* ---------------- приём ответа клиентом ---------------- */

static char g_rx[262144];
static u32  g_rx_len = 0;
static int  g_cli_sock = -1;
static int  g_cli_port = 40000;

static void cli_recv(int sock, u32 ip, u16 port, const void *data, u32 len)
{
    (void)ip; (void)port;
    if (sock != g_cli_sock) return;
    if (g_rx_len + len <= sizeof(g_rx)) {
        memcpy(g_rx + g_rx_len, data, len);
        g_rx_len += len;
    }
}

/* Выполнить запрос; возвращает статус-код или -1. */
static int http_fetch(const char *req, const char **body, u32 *body_len,
                      const char **hdrs, u32 *hdr_len)
{
    g_rx_len = 0;
    g_cli_sock = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    if (g_cli_sock < 0) return -1;

    net_tcp_send(g_cli_sock, req, (u32)strlen(req));

    /* крутим стек: loopback доставляет всё инлайн, но даём FIN доехать */
    for (int i = 0; i < 500 && net_tcp_state(g_cli_sock) == TCP_ESTABLISHED;
         i++) {
        net_poll();
        net_httpd_poll();
        g_vticks += 10;
    }
    net_tcp_close(g_cli_sock);
    net_poll();

    /* разбор ответа */
    char *sep = NULL;
    for (u32 i = 0; i + 3 < g_rx_len; i++) {
        if (g_rx[i] == '\r' && g_rx[i+1] == '\n' &&
            g_rx[i+2] == '\r' && g_rx[i+3] == '\n') { sep = g_rx + i; break; }
    }
    if (!sep) return -2;
    *hdr_len = (u32)(sep - g_rx) + 4;
    *hdrs = g_rx;
    *body = sep + 4;
    *body_len = g_rx_len - *hdr_len;

    int code = 0;
    if (g_rx_len >= 12 && strncmp(g_rx, "HTTP/1.0 ", 9) == 0)
        code = t_atoi(g_rx + 9);
    return code;
}

/* CL из заголовков (u32, 0 если нет) */
static u32 cl_of(const char *hdrs, u32 hdr_len)
{
    char tmp[256];
    u32 n = hdr_len < sizeof(tmp) - 1 ? hdr_len : (u32)sizeof(tmp) - 1;
    memcpy(tmp, hdrs, n);
    tmp[n] = 0;
    char *p = strstr(tmp, "Content-Length:");
    if (!p) {
        printf("  [dbg] CL не найден в [%.140s]\n", tmp);
        return 0;
    }
    return (u32)t_atoi(p + 15);
}

/* ---------------- сценарии ---------------- */

static void t1_hello(void)
{
    printf("[t1] GET /hello: 200, честный Content-Length\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(bl == 33 && memcmp(b, "Hello from N2600-OS local httpd!\n", 33) == 0,
          "тело %u байт", bl);
    CHECK(cl_of(h, hl) == bl, "CL == телу (%u)", cl_of(h, hl));
}

static void t2_index(void)
{
    printf("[t2] GET /: файл www/index.html из RAM\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET / HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    int i = sf_find_ci("www/index.html");
    CHECK(i >= 0, "демо-страница создана");
    if (i >= 0) {
        CHECK(bl == g_sf[i].size && memcmp(b, g_sf[i].data, bl) == 0,
              "тело == файлу (%u)", bl);
        CHECK(cl_of(h, hl) == bl, "CL == телу");
        /* NUL не должен уйти в файл (FIX LOW: sizeof-1) */
        CHECK(g_sf[i].data[g_sf[i].size] == 0 && bl > 0 &&
              g_sf[i].data[bl - 1] != 0,
              "файл без хвостового NUL");
    }
}

static void t3_caseins(void)
{
    printf("[t3] GET /INDEX.HTML: без учёта регистра\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /INDEX.HTML HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    (void)b; (void)h; (void)hl;
}

static void t4_head(void)
{
    printf("[t4] HEAD /hello: заголовки без тела\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("HEAD /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(cl_of(h, hl) == 33, "CL = 33 (как у GET)");
    CHECK(bl == 0, "тела нет (%u)", bl);
}

static void t5_getter(void)
{
    printf("[t5] GETTER /hello: 501 (метод не GET)\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GETTER /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 501, "код %d", code);
    CHECK(cl_of(h, hl) == bl, "CL == телу");
}

static void t6_traversal(void)
{
    printf("[t6] GET /../x: 404 (выход из www запрещён)\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /../x HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 404, "код %d", code);
    (void)b; (void)h; (void)hl;
}

static void t7_bigfile(void)
{
    printf("[t7] GET /big.bin (16 КиБ): FSM отправки, байт ровно CL\n");
    if (sf_find_ci("www/big.bin") < 0) {
        ramfs_create("www/big.bin", 16384);
        u8 *pat = (u8 *)malloc(16384);
        for (u32 i = 0; i < 16384; i++) pat[i] = (u8)(i * 7 + i / 251);
        ramfs_write("www/big.bin", pat, 16384);
        free(pat);
    }
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /big.bin HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(cl_of(h, hl) == 16384, "CL = 16384 (%u)", cl_of(h, hl));
    CHECK(bl == 16384, "получено %u байт", bl);
    if (bl == 16384) {
        int bad = 0;
        for (u32 i = 0; i < 16384; i++)
            if ((u8)b[i] != (u8)(i * 7 + i / 251)) { bad = 1; break; }
        CHECK(!bad, "содержимое целое");
    }
}

static void t8_sysinfo(void)
{
    printf("[t8] GET /sysinfo: статусная страница без порчи памяти\n");
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /sysinfo HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "код %d", code);
    CHECK(bl > 200 && bl < 1400, "разумный размер тела: %u", bl);
    CHECK(cl_of(h, hl) == bl, "CL == телу (%u == %u)", cl_of(h, hl), bl);
}

static void t9_idle(void)
{
    printf("[t9] idle-таймаут: молчаливый клиент выкидывается\n");
    int s = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    CHECK(s >= 0 && net_tcp_state(s) == TCP_ESTABLISHED, "соединение открыто");
    if (s < 0) return;
    g_cli_sock = s;

    /* 30 с тишины (1 тик = 1 мс) — по шагам, чтобы poll шёл */
    for (int i = 0; i < 3200; i++) {
        g_vticks += 10;
        net_poll();
        net_httpd_poll();
    }
    CHECK(net_tcp_state(s) != TCP_ESTABLISHED,
          "сокет закрыт сервером по таймауту");

    /* слот освободился — новое соединение работает */
    const char *b, *h; u32 bl, hl;
    int code = http_fetch("GET /hello HTTP/1.0\r\n\r\n", &b, &bl, &h, &hl);
    CHECK(code == 200, "после таймаута сервер жив (код %d)", code);
}

static void t10_slots(void)
{
    printf("[t10] 4 молчаливых клиента: 5-й отклоняется\n");
    int socks[4];
    int ok = 1;
    for (int i = 0; i < 4; i++) {
        socks[i] = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
        if (socks[i] < 0 || net_tcp_state(socks[i]) != TCP_ESTABLISHED) ok = 0;
    }
    CHECK(ok, "4 соединения принято");

    int s5 = net_tcp_connect(0x7F000001u, 80, (u16)(++g_cli_port));
    CHECK(s5 < 0 || net_tcp_state(s5) != TCP_ESTABLISHED,
          "5-е соединение отклонено");

    for (int i = 0; i < 4; i++)
        if (socks[i] >= 0) net_tcp_close(socks[i]);
    if (s5 >= 0) net_tcp_close(s5);
    net_poll();
}

static void t11_cfg(void)
{
    printf("[t11] SETTINGS.CFG читается целиком (httpd=1)\n");
    /* сервер уже работает; настройка "httpd=1" в конце файла не должна
     * ломать автостарт (раньше читались только первые 255 байт) */
    if (sf_find_ci("SETTINGS.CFG") < 0) {
        const char *cfg =
            "adapter=auto\n"
            "wifi=1\n"
            ";\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "pad0123456789012345678901234567890123456789012345678901234567890\n"
            "httpd=1\n";
        ramfs_create("SETTINGS.CFG", (u32)strlen(cfg));
        ramfs_write("SETTINGS.CFG", cfg, (u32)strlen(cfg));
    }
    /* сам запуск проверяется в main() сразу после net_httpd_start() */
}

int main(void)
{
    net_tcp_set_callback(cli_recv);

    sf_reset();
    fake_nic_up();
    net_init();
    net_set_ip(0x0A5C3CC7u);
    net_set_netmask(0xFFFFFF00u);
    net_set_gateway(0x0A050001u);

    t11_cfg();          /* SETTINGS.CFG кладём ДО старта сервера */
    net_httpd_start();
    CHECK(net_httpd_running(), "httpd слушает :80");

    t1_hello();
    t2_index();
    t3_caseins();
    t4_head();
    t5_getter();
    t6_traversal();
    t7_bigfile();
    t8_sysinfo();
    t9_idle();
    t10_slots();

    printf("\n========================================\n");
    if (g_fail == 0) printf("HTTPD60: ВСЕ ПРОВЕРКИ ЗЕЛЁНЫЕ\n");
    else             printf("HTTPD60: ПРОВАЛОВ: %d\n", g_fail);
    return g_fail ? 1 : 0;
}
