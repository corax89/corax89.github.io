/* net_tls.h — TLS (HTTPS) поверх TCP-стека N2600-OS.
 *
 * Реализация: BearSSL 0.6 (тот же движок, что в Arduino-ядрах ESP8266/ESP32),
 * собранный в один файл bearssl.c (см. scripts/gen_bearssl_amalgam.py).
 * Профиль: TLS 1.0-1.2 клиент, RSA (i31) + ECDHE P-256/384 + ECDSA,
 * AES-GCM/CBC + ChaCha20-Poly1305, проверка цепочек через X.509 minimal
 * validator с захардкоженными корнями (tls_anchors.h).
 *
 * Порядок использования (внутри net_http.c):
 *   1. net_tcp_set_callback(tls_tcp_recv)  — шифротекст в staging-ring
 *   2. tls_start(sock, host, max_ms)       — рукопожатие (блокирует с
 *                                            net_poll()/task_yield внутри)
 *   3. tls_set_sink(http_tcp_recv_adapter) — куда класть расшифрованное
 *   4. tls_send_all(req, len)              — отправка запроса
 *   5. в цикле ожидания: tls_pump()        — двигает данные
 *   6. tls_shutdown()                      — close_notify (best-effort)
 *
 * Ошибки: tls_errstr() — текст последней ошибки ("tls: ..." для статуса).
 */
#ifndef NET_TLS_H
#define NET_TLS_H

#include "types.h"

/* Рукопожатие TLS. hostname — для SNI и проверки сертификата.
 * Возвращает 1 при успехе, 0 при ошибке (см. tls_errstr). */
int  tls_start(int sock, const char *hostname, u32 max_ms);

/* Зашифровать и отправить len байт (полностью). 1 = ок. */
int  tls_send_all(const void *data, u32 len);

/* Приёмник расшифрованных данных (вызывается из tls_pump). */
void tls_set_sink(void (*sink)(const void *data, u32 len));

/* Продвинуть машину состояний: шифротекст из ring -> engine -> sink,
 * записи engine -> TCP. Вызывать в цикле ожидания ответа. */
void tls_pump(void);

/* Корректное закрытие (close_notify, best-effort) и сброс сессии. */
void tls_shutdown(void);

/* Активна ли TLS-сессия. */
int  tls_is_active(void);

/* Текст последней ошибки ("ok" если нет). */
const char *tls_errstr(void);

/* TCP recv-callback на время TLS-сессии (см. net_tcp_set_callback). */
void tls_tcp_recv(int sock, u32 src_ip, u16 src_port,
                  const void *data, u32 len);

#endif /* NET_TLS_H */
