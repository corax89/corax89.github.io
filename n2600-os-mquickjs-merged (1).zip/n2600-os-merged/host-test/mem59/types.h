/* types.h — базовые типы ядра N2600-OS (чистый C, freestanding) */
#ifndef TYPES_H
#define TYPES_H

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned long long u64;
typedef signed char    i8;
typedef short          i16;
typedef int            i32;
typedef long long      i64;

#ifndef NULL
#define NULL ((void*)0)
#endif

#define STATIC_ASSERT(cond, name) _Static_assert(cond, #name)

#endif /* TYPES_H */
