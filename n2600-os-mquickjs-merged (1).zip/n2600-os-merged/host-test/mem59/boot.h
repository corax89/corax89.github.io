/* boot.h — структуры Multiboot 0.6.96 (то, что GRUB передает ядру) */
#ifndef BOOT_H
#define BOOT_H

#include "types.h"

#define MB_MAGIC        0x1BADB002u
#define MB_FLAG_ALIGN   0x00000001u
#define MB_FLAG_MEMINFO 0x00000002u
#define MB_FLAG_VIDEO_MODE 0x00000004u
#define MB_FLAG_AOUT_KLUDGE 0x00010000u
#define MB_BOOTLOADER_MAGIC 0x2BADB002u

/* флаги-биты в mb_info->flags */
#define MBIF_MEM        (1u << 0)
#define MBIF_BOOTDEV    (1u << 1)
#define MBIF_CMDLINE    (1u << 2)
#define MBIF_MODS       (1u << 3)
#define MBIF_AOUT_SYMS  (1u << 4)
#define MBIF_ELF_SHDR   (1u << 5)
#define MBIF_MMAP       (1u << 6)
#define MBIF_DRIVE      (1u << 7)
#define MBIF_CFGTABLE   (1u << 8)
#define MBIF_BOOTLDR    (1u << 9)
#define MBIF_APM        (1u << 10)
#define MBIF_VBE        (1u << 11)
#define MBIF_FRAMEBUFFER (1u << 12)

typedef struct {
    u32 size;   /* размер записи ПОСЛЕ этого поля */
    u64 addr;
    u64 len;
    u32 type;   /* 1 = доступная память */
} __attribute__((packed)) mb_mmap_t;

STATIC_ASSERT(sizeof(mb_mmap_t) == 24, mmap_entry_size);

typedef struct {
    u32 flags;              /* 0  */
    u32 mem_lower;          /* 4  КБ ниже 1М */
    u32 mem_upper;          /* 8  КБ выше 1М */
    u32 boot_device;        /* 12 */
    u32 cmdline;            /* 16 */
    u32 mods_count;         /* 20 */
    u32 mods_addr;          /* 24 */
    u32 syms[4];            /* 28..43 */
    u32 mmap_length;        /* 44 */
    u32 mmap_addr;          /* 48 */
    u32 drives_length;      /* 52 */
    u32 drives_addr;        /* 56 */
    u32 config_table;       /* 60 */
    u32 boot_loader_name;   /* 64 */
    u32 apm_table;          /* 68 */
    u32 vbe_control_info;   /* 72 */
    u32 vbe_mode_info;      /* 76 */
    u16 vbe_mode;           /* 80 */
    u16 vbe_interface_seg;  /* 82 */
    u16 vbe_interface_off;  /* 84 */
    u16 vbe_interface_len;  /* 86 */
    u64 framebuffer_addr;   /* 88 */
    u32 framebuffer_pitch;  /* 96 */
    u32 framebuffer_width;  /* 100 */
    u32 framebuffer_height; /* 104 */
    u8  framebuffer_bpp;    /* 108 */
    u8  framebuffer_type;   /* 109: 1 = RGB */
    u8  color_info[6];      /* 110..115 */
} mb_info_t;

STATIC_ASSERT(__builtin_offsetof(mb_info_t, mmap_addr) == 48, mb_mmap_addr_off);
STATIC_ASSERT(__builtin_offsetof(mb_info_t, framebuffer_addr) == 88, mb_fb_addr_off);
STATIC_ASSERT(__builtin_offsetof(mb_info_t, framebuffer_type) == 109, mb_fb_type_off);

/* тип цветности фреймбуфера */
#define MB_FT_INDEXED 0
#define MB_FT_RGB     1
#define MB_FT_TEXT    2

#endif /* BOOT_H */
