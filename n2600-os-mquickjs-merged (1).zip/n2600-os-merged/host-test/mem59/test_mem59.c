/* test_mem59.c — сессия 59: проверка укреплённого аллокатора mem.c
 * (реальный src/mem.c, 64-битный хост, куча на фиксированном mmap
 * ниже 4 ГиБ, чтобы u32-усечение указателей было корректным).
 *
 * Сборка: gcc -std=c99 -g -O1 -fsanitize=address,undefined \
 *           -o test_mem59 test_mem59.c ../src/mem.c -I../src
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include "types.h"
#include "boot.h"


u32   mem_heap_size(void);
int   mem_check_corrupt(void);
void  mem_init(const mb_info_t *mb);
void *mem_malloc(u32 n);
void  mem_free(void *p);

/* --- стабы того, что mem.c ожидает от ядра --- */
static int g_task = 0;
int task_current(void) { return g_task; }
void serial_puts(const char *s) { fputs(s, stdout); }




#include "boot.h"

static int PASS = 0, FAIL = 0;
#define CHECK(name, cond) do { \
    if (cond) { PASS++; printf("  [ok] %s\n", name); } \
    else      { FAIL++; printf("  [FAIL] %s\n", name); } } while (0)

#define HEAP_ADDR 0x10000000u
#define HEAP_LEN  (4u * 1024 * 1024)

int main(void)
{
    printf("== test_mem59: укреплённый аллокатор ==\n");

    void *ram = mmap((void *)(unsigned long)HEAP_ADDR, HEAP_LEN,
                     PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (ram == MAP_FAILED) { perror("mmap"); return 2; }
    memset(ram, 0, HEAP_LEN);

    /* фейковая карта multiboot: РЕАЛЬНАЯ mb_info_t; mmap-запись кладём
 * ВНУТТЬ фиксированного mmap (адрес < 4 ГиБ — u32-усечение корректно) */
    struct __attribute__((packed)) { u32 size; u64 addr; u64 len; u32 type; } ent = {
        24, HEAP_ADDR, HEAP_LEN, 1
    };
    memcpy((void *)(unsigned long)(HEAP_ADDR + 0x1000), &ent, sizeof(ent));
    static mb_info_t mb;
    memset(&mb, 0, sizeof(mb));
    mb.flags = (1u << 6);                     /* MBIF_MMAP */
    mb.mmap_addr = HEAP_ADDR + 0x1000;
    mb.mmap_length = sizeof(ent);
    mb.mem_upper = 0;
mem_init((const mb_info_t *)&mb);
    CHECK("куча поднята", mem_heap_size() > 0);

    /* --- 1. нормальные аллокации --- */
    void *a = mem_malloc(100);
    void *b = mem_malloc(1000);
    CHECK("malloc 100/1000", a && b);
    memset(a, 0xAB, 100);
    memset(b, 0xCD, 1000);
    mem_free(a);
    mem_free(b);
    CHECK("free без ошибок", 1);

    /* --- 2. дикий free (мимо кучи) не пишет в память --- */
    static u8 scratch[64];
    memset(scratch, 0x77, sizeof(scratch));
    mem_free(scratch + 16);           /* не указатель из кучи */
    int intact = 1;
    for (int i = 0; i < 64; i++) if (scratch[i] != 0x77) intact = 0;
    CHECK("дикий free не портит память", intact);

    /* --- 3. двойной free не ломает соседей --- */
    void *c = mem_malloc(64);
    mem_free(c);
    mem_free(c);                      /* дубль */
    void *d = mem_malloc(64);
    CHECK("после двойного free аллокация жива", d != NULL);
    mem_free(d);

    /* --- 4. нулевой/гигантский запрос (ALIGN8-wrap раньше давал need=4!) --- */
    CHECK("mem_malloc(0) = NULL", mem_malloc(0) == NULL);
    void *huge = mem_malloc(0xFFFFFFF0u);
    CHECK("mem_malloc(0xFFFFFFF0) отказ (не порча)", huge == NULL);
    void *e = mem_malloc(32);
    CHECK("куча жива после гигантского запроса", e != NULL);
    mem_free(e);

    /* --- 5. порча заголовка: walk останавливается, отказ без шторма --- */
    void *f = mem_malloc(128);
    CHECK("malloc 128 перед порчей", f != NULL);
    /* порча: гигантский запрос уже был отклонён — вручную ломаем блок:
     * пишем size=4 в заголовок выделенного блока (как в логе fixed58) */
    {
        unsigned char *hdr = (unsigned char *)f - 8;
        hdr[0] = 4; hdr[1] = 0; hdr[2] = 0; hdr[3] = 0;   /* size=4 */
        hdr[4] = 0; hdr[5] = 0; hdr[6] = 0; hdr[7] = 0;   /* used=0 */
    }
    CHECK("mem_check_corrupt ловит size=4", mem_check_corrupt() == 1);
    void *g = mem_malloc(4096);
    CHECK("malloc после порчи отказ (без зависания)", g == NULL);
    mem_free(f);   /* дикий free теперь отклоняется заголовком — не пишет */

    printf("\nИтого: %d ok, %d fail\n", PASS, FAIL);
    return FAIL ? 1 : 0;
}
