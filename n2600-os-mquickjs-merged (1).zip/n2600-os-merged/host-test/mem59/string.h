#ifndef SHIM_STR_H
#define SHIM_STR_H
#include_next <string.h>
#include_next <stdio.h>
#include_next <stdlib.h>
#endif
