#ifndef TASK_H
#define TASK_H
int task_current(void);
#endif
