/* mem.h — физическая память (по карте Multiboot) и куча */
#ifndef MEM_H
#define MEM_H

#include "types.h"
#include "boot.h"

void  mem_init(const mb_info_t *mb);
void *malloc(u32 n);
void  free(void *p);
u32   mem_used(void);      /* байт занято кучей */
u32   mem_heap_size(void); /* размер кучи, байт */
u32   mem_debug_walk(u32 *largest, u32 *nfree); /* сессия 13: диагностика */
void  mem_dump_blocks(void);                    /* сессия 13: дамп в serial */
int   mem_check_corrupt(void);                  /* сессия 13: сторож порчи */
u32   mem_ram_mib(void);   /* всего доступной RAM, МиБ (по карте) */

/* Учёт памяти по задачам (диспетчер задач): */
void  mem_reassign(void *p, int task_idx); /* сменить владельца блока */
u32   mem_task_used(int task_idx);          /* байт, занято задачей */

#endif /* MEM_H */
