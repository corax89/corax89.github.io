#include <stdio.h>

/* Пример для редактора C (F9 — скомпилировать и запустить).
   Откройте этот файл из RAM disk: editor -> F4 -> hello.c */

int main(void)
{
    int i;
    int sum = 0;
    for (i = 1; i <= 10; i = i + 1) {
        sum = sum + i;
    }
    printf("1+2+...+10 = %d\n", sum);
    return 0;
}
