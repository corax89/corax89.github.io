/* Тест 4: циклы (for/while), сумма 1..10 = 55 */
int main() {
    int i;
    int sum;
    sum = 0;
    for (i = 1; i <= 10; i = i + 1) {
        sum = sum + i;
    }
    printf("sum=%d\n", sum);
    while (sum > 50) {
        sum = sum - 1;
    }
    printf("after=%d\n", sum);
    return sum;
}
