/* Тест 5: глобалы, массивы, деление/остаток, вызов функции */
int g;
int arr[6];

int sq(int x) {
    return x * x;
}

int main() {
    int i;
    g = 0;
    for (i = 0; i < 6; i = i + 1) {
        arr[i] = sq(i + 1);
        g = g + arr[i];
    }
    printf("g=%d\n", g);
    printf("arr[3]=%d arr[5]=%d\n", arr[3], arr[5]);
    printf("div=%d mod=%d\n", g / 7, g % 7);
    return g;
}
