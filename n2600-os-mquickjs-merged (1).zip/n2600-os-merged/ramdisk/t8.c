/* Тест 8: песочница — malloc/строки работают внутри региона.
 * malloc возвращает СМЕЩЕНИЕ региона; memset/strcpy/strcmp/strlen
 * идут через kapi-обёртки (перевод смещений в абсолютные адреса). */
int main() {
    char *a;
    char *b;
    a = malloc(32);
    b = malloc(32);
    if (a == 0) {
        printf("t8: malloc провалился\n");
        return 1;
    }
    memset(a, 'A', 5);
    a[5] = 0;
    printf("t8: %s\n", a);
    strcpy(b, "sandbox");
    printf("t8: strcpy %s len=%d\n", b, strlen(b));
    if (strcmp(b, "sandbox") == 0) {
        printf("t8: strcmp ok\n");
        return 8;
    }
    printf("t8: strcmp FAIL\n");
    return 2;
}
