/* Тест 6: графика kfill/ktext/krgb/kdelay (финитная анимация) */
int main() {
    kfill(560, 0, 240, 90, krgb(255, 0, 0));
    kflip();
    printf("red band\n");
    kdelay(300);
    kfill(560, 90, 240, 90, krgb(0, 200, 0));
    kflip();
    kdelay(300);
    kfill(560, 180, 240, 90, krgb(0, 80, 255));
    ktext(570, 200, "C4 OK", 0xFFFFFF, -1);
    kflip();
    kdelay(300);
    printf("graphics done\n");
    return 6;
}
