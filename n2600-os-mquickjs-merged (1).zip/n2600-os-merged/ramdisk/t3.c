/* Тест 3: printf: %d, %s, %c + строки (сегмент данных) */
int main() {
    printf("privet %d\n", 42);
    printf("%s-%s\n", "stroka", "test");
    printf("char: %c%c%c\n", 65, 66, 67);
    return 3;
}
