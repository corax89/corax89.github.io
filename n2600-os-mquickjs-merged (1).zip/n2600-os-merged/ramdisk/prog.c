/* Пример для c4: for, #define, массивы, блочные комментарии */
#define MAX 10

int fib(int n) {
    if (n < 2) return n;
    return fib(n - 1) + fib(n - 2);
}

int main() {
    int i;
    int sum = 0;
    int arr[MAX];

    for (i = 0; i < MAX; i = i + 1) {
        arr[i] = fib(i + 1);
        sum = sum + arr[i];
    }
    for (i = 0; i < MAX; i = i + 1) {
        printf("fib(%d) = %d\n", i + 1, arr[i]);
    }
    printf("sum = %d\n", sum);
    return 0;
}
