/* snd_es1371.c — драйвер Ensoniq/Creative ES1371/ES1373 (AudioPCI 97).
 *
 * Виртуальная звуковая карта VMware (sound.virtualDev="es1371",
 * «Sound Blaster AudioPCI»), «Sound Blaster PCI 128» в 86Box/PCem
 * (это тот же PCI-чип ES1371/ES1373 — 1274:1371) и реальные чипы
 * 1274:1371 / 1274:5880 (CT5880) / 1102:8938.
 *
 * Сессия 58 — ИСПРАВЛЕНА ТИШИНА («звука я не слышу»). Две причины по
 * даташиту/ALSA sound/pci/ens1370.c (snd_ensoniq_playback2_prepare):
 *   1) дескриптор буфера писался НЕ В ТЕ регистры: ES_REG_MEM_ADDR(0x34)
 *      и ES_REG_MEM_DATA(0x38) — а это DAC1_SIZE и DAC2_FRAME. Физический
 *      адрес буфера вообще не попадал в DAC2_FRAME, вместо него туда
 *      писался размер! DAC2 читал мусор с адреса ~0x3FF — тишина.
 *      Правильно (страница MEM_PAGE=0x0c): DAC2_FRAME = I/O 0x38 (адрес),
 *      DAC2_SIZE = I/O 0x3c (размер в dword - 1).
 *   2) set_dac2_rate оставлял бит SRC_DDAC2 (отключение SRC-конвертера
 *      DAC2) выставленным ПОСЛЕ программирования частоты — конвертер
 *      оставался выключен. ALSA в конце snd_es1371_dac2_rate СБРАСЫВАЕТ
 *      DIS_P2 (r = ready & (DISABLE|DIS_P1|DIS_R1)).
 *   3) не задавались SCTRL_P2ENDINC (шаг инкремента адреса на конце
 *      блока: 2 dword для 16-bit stereo) — по ALSA ES_P2_END_INCO(mode&2?2:1).
 *
 * Последовательность prepare/start — 1:1 с ALSA (CHIP1371):
 *   ctrl &= ~DAC2_EN; MEM_PAGE=0x0c; DAC2_FRAME=addr; DAC2_SIZE=(dwords-1);
 *   SCTRL: clear LOOP_SEL|PAUSE|DAC_SEN|INT_EN|MODEM|END_INCM|ST_INCM,
 *          set MODEO(3=16-bit stereo) | END_INCO(2) | ST_INCO(0);
 *   DAC2_COUNT = frames-1; snd_es1371_dac2_rate(rate);
 *   ctrl |= DAC2_EN (старт).
 *
 * Без прерываний: длительность воспроизведения ждём по PIT (простой API
 * для теста звука по кнопке); DAC2 в loop-режиме, останавливаем снятием
 * DAC2_EN.
 */
#include "types.h"
#include "io.h"
#include "pci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sound.h"

extern void serial_puts(const char *s);

/* ---------- регистры (I/O BAR0, 0x40 байт) — по ALSA ens1370.c ---------- */
#define ES_REG_CONTROL   0x00
#define ES_REG_STATUS    0x04
#define ES_REG_MEMPAGE   0x0c
#define ES_REG_SRCONV    0x10   /* ES_REG_1371_SMPRATE */
#define ES_REG_CODEC     0x14   /* ES_REG_1371_CODEC */
#define ES_REG_LEGACY    0x18
#define ES_REG_SCTRL     0x20   /* ES_REG_SERIAL */
#define ES_REG_DAC1_SCNT 0x24
#define ES_REG_DAC2_SCNT 0x28   /* ES_REG_DAC2_COUNT */
#define ES_REG_ADC_SCNT  0x2c
/* страница MEM_PAGE=0x0c (ES_PAGE_DAC): фреймы DAC1/DAC2 */
#define ES_REG_DAC1_FRAME 0x30
#define ES_REG_DAC1_SIZE  0x34
#define ES_REG_DAC2_FRAME 0x38
#define ES_REG_DAC2_SIZE  0x3c

/* CONTROL */
#define CTRL_SYNCRES  0x00004000u   /* (1<<14) warm AC97 reset — ES_1371_SYNC_RES */
#define CTRL_CCB_INTRM 0x00000400u
#define CTRL_DAC1_EN  0x00000040u   /* (1<<6) */
#define CTRL_DAC2_EN  0x00000020u   /* (1<<5) — ES_DAC2_EN */
#define CTRL_ADC_EN   0x00000010u
/* SCTRL (ES_REG_SERIAL) */
#define SCTRL_P2ENDINC 0x00380000u  /* (7<<19) END_INCM */
#define SCTRL_P2STINC  0x00070000u  /* (7<<16) ST_INCM */
#define SCTRL_P2LOOPSEL 0x00004000u /* (1<<14) 0 = loop (кольцо) */
#define SCTRL_P2PAUSE   0x00001000u /* (1<<12) */
#define SCTRL_P2INTEN   0x00000200u /* (1<<9) */
#define SCTRL_P2DACSEN  0x00000040u /* (1<<6) */
#define SCTRL_P2FMT     0x0000000cu /* MODEM: (3<<2) */
#define SCTRL_P2SEB     0x00000008u /* 16-bit (MODEO бит1) */
#define SCTRL_P2SMB     0x00000004u /* stereo (MODEO бит0) */
/* CODEC */
#define CODEC_WIP 0x40000000u       /* (1<<30) */
#define CODEC_RDY 0x80000000u       /* (1<<31) */
/* SRC (ES_REG_1371_SMPRATE) */
#define SRC_RAMADDR_SHIFT 25        /* ES_1371_SRC_RAM_ADDRO */
#define SRC_WE      0x01000000u     /* (1<<24) */
#define SRC_BUSY    0x00800000u     /* (1<<23) */
#define SRC_DIS     0x00400000u     /* (1<<22) */
#define SRC_DDAC1   0x00200000u     /* (1<<21) DIS_P1 */
#define SRC_DDAC2   0x00100000u     /* (1<<20) DIS_P2 */
#define SRC_DADC    0x00080000u     /* (1<<19) DIS_R1 */
#define SRC_CTLMASK (SRC_DIS | SRC_DDAC1 | SRC_DDAC2 | SRC_DADC)
#define SRCREG_TRUNC_N    0x00
#define SRCREG_INT_REGS   0x01
#define SRCREG_VFREQ_FRAC 0x03
#define SRCREG_DAC1 0x70
#define SRCREG_DAC2 0x74
#define SRCREG_VOL_DAC1 0x7c
#define SRCREG_VOL_DAC2 0x7e
#define SRCREG_VOL_ADC  0x6c

/* страница дескрипторов (MEMPAGE) */
#define ES_PAGE_DAC 0x0c

static struct {
    u16 io;
    u32 ctrl;
    int ok;
} g_es;

static char es_name[40] = "ES1371 (AudioPCI)";

static u32 es_in(u32 reg) { return inl((u16)(g_es.io + reg)); }
static void es_out(u32 reg, u32 v) { outl((u16)(g_es.io + reg), v); }

static void es_delay(u32 us)
{
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, us)) { }
}

/* ---------- SRC ---------- */
static u32 src_wait_ready(void)
{
    u32 r = 0;
    for (int t = 0; t < 4096; t++) {
        r = es_in(ES_REG_SRCONV);
        if (!(r & SRC_BUSY)) return r;
        es_delay(1);
    }
    return r;
}

static void src_write(u32 reg, u32 data)
{
    u32 r = src_wait_ready() & SRC_CTLMASK;
    r |= (reg << SRC_RAMADDR_SHIFT);
    r |= (data & 0xFFFF);
    es_out(ES_REG_SRCONV, r | SRC_WE);
}

static u32 src_read(u32 reg)
{
    u32 temp = src_wait_ready();
    u32 orig = temp & SRC_CTLMASK;
    es_out(ES_REG_SRCONV, orig | (reg << SRC_RAMADDR_SHIFT) | 0x10000u);
    temp = src_wait_ready();
    if ((temp & 0x00870000u) != (1u << 16)) {
        for (int i = 0; i < 4096; i++) {
            temp = es_in(ES_REG_SRCONV);
            if ((temp & 0x00870000u) == (1u << 16)) break;
        }
    }
    es_out(ES_REG_SRCONV, orig | (reg << SRC_RAMADDR_SHIFT));
    return temp & 0xFFFF;
}

/* freq = (rate<<15 + 1500)/3000; по ALSA snd_es1371_dac2_rate */
static void set_dac2_rate(u32 rate)
{
    if (rate > 48000) rate = 48000;
    if (rate < 4000) rate = 4000;
    u32 freq = ((rate << 15) + 1500) / 3000;
    /* отключить конвертер DAC2 на время программирования */
    u32 r = (src_wait_ready() & (SRC_DIS | SRC_DDAC1 | SRC_DADC)) | SRC_DDAC2;
    es_out(ES_REG_SRCONV, r);
    src_write(SRCREG_DAC2 + SRCREG_INT_REGS,
              (src_read(SRCREG_DAC2 + SRCREG_INT_REGS) & 0x00FF) |
              ((freq >> 5) & 0xFC00));
    src_write(SRCREG_DAC2 + SRCREG_VFREQ_FRAC, freq & 0x7FFF);
    /* FIX сессии 58: в конце СБРОСИТЬ SRC_DDAC2 (ALSA: r = ready &
     * (SRC_DISABLE | DIS_P1 | DIS_R1) — без DIS_P2), иначе конвертер
     * DAC2 остаётся выключен — тишина */
    r = src_wait_ready() & (SRC_DIS | SRC_DDAC1 | SRC_DADC);
    es_out(ES_REG_SRCONV, r);
}

/* ---------- AC97 через регистр CODEC (с SRC-окном записи) ---------- */
static int ac97_wip_wait(void)
{
    for (int t = 0; t < 8192; t++)
        if (!(es_in(ES_REG_CODEC) & CODEC_WIP)) return 1;
    return 0;
}

static void ac97_write(u8 addr, u16 data)
{
    if (!ac97_wip_wait()) return;
    u32 x = src_wait_ready();
    es_out(ES_REG_SRCONV, (x & SRC_CTLMASK) | 0x10000u);
    for (int t = 0; t < 4096; t++)
        if ((es_in(ES_REG_SRCONV) & 0x00870000u) == 0) break;
    for (int t = 0; t < 4096; t++)
        if ((es_in(ES_REG_SRCONV) & 0x00870000u) == 0x10000u) break;
    es_out(ES_REG_CODEC,
           (((u32)addr << 16) & 0x007F0000u) | (u32)data);
    src_wait_ready();
    es_out(ES_REG_SRCONV, x);
    /* WIP после записи */
    for (int t = 0; t < 8192; t++)
        if (!(es_in(ES_REG_CODEC) & CODEC_WIP)) break;
}

/* ---------- init SRC RAM (по Linux/ALSA src_init) ---------- */
static void src_init(void)
{
    src_wait_ready();
    es_out(ES_REG_SRCONV, SRC_DIS);
    for (u32 i = 0; i < 0x80; i++) src_write(i, 0);
    src_write(SRCREG_DAC1 + SRCREG_TRUNC_N, 16 << 4);
    src_write(SRCREG_DAC1 + SRCREG_INT_REGS, 16 << 10);
    src_write(SRCREG_DAC2 + SRCREG_TRUNC_N, 16 << 4);
    src_write(SRCREG_DAC2 + SRCREG_INT_REGS, 16 << 10);
    src_write(SRCREG_VOL_ADC, 1 << 12);
    src_write(SRCREG_VOL_ADC + 1, 1 << 12);
    src_write(SRCREG_VOL_DAC1, 1 << 12);
    src_write(SRCREG_VOL_DAC1 + 1, 1 << 12);
    src_write(SRCREG_VOL_DAC2, 1 << 12);
    src_write(SRCREG_VOL_DAC2 + 1, 1 << 12);
    src_wait_ready();
    es_out(ES_REG_SRCONV, 0);   /* включить все конвертеры */
}

/* Имя по VID:DID и ревизии (ревизия — байт 0x08 PCI config):
 * ES1371REV_ES1373_A/B/8 = 0x04/0x06/0x08, ES1371REV_ES1371_B = 0x09,
 * CT5880 = 0x07 (ALSA ens1370.c). Sound Blaster PCI 128 — это ES1373. */
static void es_pick_name(u16 vid, u16 did, u8 rev)
{
    if (vid == 0x1274 && did == 0x1371) {
        if (rev == 0x04 || rev == 0x06 || rev == 0x08)
            snprintf(es_name, sizeof(es_name),
                     "ES1373 (Sound Blaster PCI 128)");
        else if (rev == 0x07)
            snprintf(es_name, sizeof(es_name),
                     "CT5880 (Sound Blaster PCI 128)");
        else
            snprintf(es_name, sizeof(es_name), "ES1371 (AudioPCI)");
    } else if (vid == 0x1102 && did == 0x8938) {
        snprintf(es_name, sizeof(es_name), "Creative SB PCI 128 (8938)");
    } else if (vid == 0x1102 && did == 0x5880) {
        snprintf(es_name, sizeof(es_name), "Creative EV1938");
    } else {
        snprintf(es_name, sizeof(es_name), "AudioPCI %04x:%04x", vid, did);
    }
}

int snd_es1371_probe(void)
{
    g_es.ok = 0;
    g_es.io = 0;
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid == 0xFFFF) continue;
                int hit = (vid == 0x1274 && did == 0x1371) ||
                          (vid == 0x1274 && did == 0x5880) ||
                          (vid == 0x1102 && did == 0x8938) ||
                          (vid == 0x1102 && did == 0x5880);
                if (!hit) continue;
                u32 bar0 = pci_read32(bus, dev, fn, 0x10);
                if (!(bar0 & 1)) continue;          /* нужен I/O BAR */
                u16 io = (u16)(bar0 & 0xFFFCu);
                if (!io) continue;
                u16 cmd = pci_read16(bus, dev, fn, 0x04);
                pci_write16(bus, dev, fn, 0x04, (u16)(cmd | 0x5)); /* IO+BME */
                u8 rev = (u8)(pci_read32(bus, dev, fn, 0x08) & 0xFF);
                g_es.io = io;
                g_es.ok = 1;
                es_pick_name(vid, did, rev);
                {
                    char b[96];
                    snprintf(b, sizeof(b), "[es1371] %04x:%04x rev=%02x io=%x — %s\n",
                             vid, did, rev, io, es_name);
                    serial_puts(b);
                }
                return 1;
            }
        }
    }
    return 0;
}

const char *snd_es1371_name(void) { return es_name; }

/* Воспроизведение: samples = frames * 2 (stereo) int16, rate, ms.
 * Последовательность — 1:1 с ALSA snd_ensoniq_playback2_prepare + trigger. */
int snd_es1371_play(const i16 *samples, u32 frames, u32 rate, u32 ms)
{
    if (!g_es.ok) return -1;
    if (!samples || frames < 8) return -1;
    u32 bytes = frames * 4;
    if (bytes > 0x10000) { bytes = 0x10000; frames = bytes >> 2; }

    u32 phys = (u32)(unsigned long)samples;
    if (phys & 3u) return -1;

    /* 1. DAC2 выключен */
    u32 ctrl = es_in(ES_REG_CONTROL);
    ctrl &= ~CTRL_DAC2_EN;
    es_out(ES_REG_CONTROL, ctrl);

    /* 2. Дескриптор (FIX сессии 58): страница 0x0c, адрес DAC2_FRAME=0x38,
     * размер в dword-1 DAC2_SIZE=0x3c */
    es_out(ES_REG_MEMPAGE, ES_PAGE_DAC);
    es_out(ES_REG_DAC2_FRAME, phys);
    es_out(ES_REG_DAC2_SIZE, (bytes >> 2) - 1);

    /* 3. Формат: 16-bit stereo (MODEO(3)), loop-кольцо, без паузы,
     * END_INC=2 (16-bit), ST_INC=0 */
    u32 sctrl = es_in(ES_REG_SCTRL);
    sctrl &= ~(SCTRL_P2LOOPSEL | SCTRL_P2PAUSE | SCTRL_P2DACSEN |
               SCTRL_P2INTEN | SCTRL_P2FMT | SCTRL_P2ENDINC | SCTRL_P2STINC);
    sctrl |= SCTRL_P2SEB | SCTRL_P2SMB;     /* 16-bit stereo */
    sctrl |= (2u << 19);                    /* END_INCO(2): 16-bit */
    es_out(ES_REG_SCTRL, sctrl);

    /* 4. Счётчик сэмплов: во ФРЕЙМАХ, frames-1 */
    es_out(ES_REG_DAC2_SCNT, frames - 1);

    /* 5. Частота SRC (по окончании конвертер DAC2 включён) */
    set_dac2_rate(rate);

    /* 6. Старт */
    ctrl = es_in(ES_REG_CONTROL);
    ctrl |= CTRL_DAC2_EN;
    es_out(ES_REG_CONTROL, ctrl);

    /* ждём (PIT, 1 тик = 1 мс); кольцо крутится само */
    u32 t0 = timer_ticks();
    while ((timer_ticks() - t0) < ms) task_msleep(5);

    /* стоп */
    ctrl = es_in(ES_REG_CONTROL);
    ctrl &= ~CTRL_DAC2_EN;
    es_out(ES_REG_CONTROL, ctrl);
    return 0;
}

/* Инициализация кодека (вызывается после probe, при sound_init) */
void snd_es1371_codec_init(void)
{
    if (!g_es.ok) return;
    /* warm reset AC97 */
    u32 ctrl = es_in(ES_REG_CONTROL);
    ctrl |= CTRL_SYNCRES;
    es_out(ES_REG_CONTROL, ctrl);
    es_delay(2000);
    ctrl &= ~CTRL_SYNCRES;
    es_out(ES_REG_CONTROL, ctrl);
    es_delay(20000);

    /* AC97: полный сброс + громкости (0x0808 = -12 дБ, без mute) */
    ac97_write(0x00, 0x0000);     /* reset */
    es_delay(10000);
    ac97_write(0x02, 0x0808);     /* master volume */
    ac97_write(0x18, 0x0808);     /* PCM out volume */
    ac97_write(0x26, 0x0000);     /* power: всё включено */

    src_init();
}

/* ================= потоковое воспроизведение (сессия 60) =================
 * Модель для MP3-плеера: приложение держит ДВА куска и поочерёдно
 * передаёт их в snd_es1371_stream(). Кусок DMA-циклится, пока не
 * поступит следующий: переключение = пауза DAC2 → новый дескриптор →
 * снятие паузы (микросекунды, без щелчка). Пока играет кусок,
 * приложение декодирует следующий. При задержке приложения кольцо
 * крутится по кругу — короткий повтор хвоста вместо тишины/треска.
 * Буфер вызывающего должен оставаться валидным до СЛЕДУЮЩЕГО вызова
 * stream() (DMA читает его напрямую). */

int snd_es1371_stream(const i16 *samples, u32 frames, u32 rate)
{
    if (!g_es.ok || !samples || frames < 8) return -1;
    u32 bytes = frames * 4;
    if (bytes > 0x10000) bytes = 0x10000;
    frames = bytes >> 2;

    u32 phys = (u32)(unsigned long)samples;
    if (phys & 3u) return -1;

    int running = (es_in(ES_REG_CONTROL) & CTRL_DAC2_EN) != 0;

    if (running) {
        /* пауза DAC2 — переключение кольца без щелчка */
        es_out(ES_REG_SCTRL, es_in(ES_REG_SCTRL) | SCTRL_P2PAUSE);
    } else {
        es_out(ES_REG_CONTROL, es_in(ES_REG_CONTROL) & ~CTRL_DAC2_EN);
    }

    /* новый дескриптор */
    es_out(ES_REG_MEMPAGE, ES_PAGE_DAC);
    es_out(ES_REG_DAC2_FRAME, phys);
    es_out(ES_REG_DAC2_SIZE, (bytes >> 2) - 1);

    /* формат 16-bit stereo (форматные биты — без P2PAUSE) */
    u32 sctrl = es_in(ES_REG_SCTRL);
    sctrl &= ~(SCTRL_P2LOOPSEL | SCTRL_P2DACSEN | SCTRL_P2INTEN |
               SCTRL_P2FMT | SCTRL_P2ENDINC | SCTRL_P2STINC);
    sctrl |= SCTRL_P2SEB | SCTRL_P2SMB | (2u << 19);
    es_out(ES_REG_SCTRL, sctrl);

    es_out(ES_REG_DAC2_SCNT, frames - 1);
    if (rate) set_dac2_rate(rate);

    if (running) {
        es_out(ES_REG_SCTRL, es_in(ES_REG_SCTRL) & ~SCTRL_P2PAUSE);
    } else {
        es_out(ES_REG_CONTROL, es_in(ES_REG_CONTROL) | CTRL_DAC2_EN);
    }
    return 0;
}

/* Пауза с сохранением позиции (кнопка «Пауза» плеера). */
void snd_es1371_stream_pause(int on)
{
    if (!g_es.ok) return;
    u32 sctrl = es_in(ES_REG_SCTRL);
    if (on) es_out(ES_REG_SCTRL, sctrl | SCTRL_P2PAUSE);
    else    es_out(ES_REG_SCTRL, sctrl & ~SCTRL_P2PAUSE);
}

/* Полный стоп (конец файла / закрытие плеера). */
void snd_es1371_stream_stop(void)
{
    if (!g_es.ok) return;
    es_out(ES_REG_CONTROL, es_in(ES_REG_CONTROL) & ~CTRL_DAC2_EN);
}
