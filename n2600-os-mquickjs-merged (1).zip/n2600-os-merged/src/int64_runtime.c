/* int64_runtime.c — реализации __divdi3/__moddi3 для freestanding (32-bit x86).
 *
 * MinGW gcc на x86-32 не имеет встроенных инструкций для 64-битного
 * деления/остатка, и использует runtime-функции __divdi3/__moddi3.
 * В freestanding-режиме они недоступны — здесь их простые реализации.
 */
#include "types.h"

/* Простой алгоритм деления для беззнаковых 64-битных чисел. */
static u64 udiv64(u64 a, u64 b) {
    if (b == 0) return 0;
    if (a < b) return 0;
    u64 q = 0, bit = 1;
    while ((b << 1) <= a && !(b & 0x8000000000000000ULL)) {
        b <<= 1; bit <<= 1;
    }
    while (bit) {
        if (a >= b) { a -= b; q |= bit; }
        b >>= 1; bit >>= 1;
    }
    return q;
}

long long __divdi3(long long a, long long b) {
    int neg = 0;
    u64 ua, ub, q;
    if (a < 0) { neg = !neg; ua = (u64)(-(a)); }
    else ua = (u64)a;
    if (b < 0) { neg = !neg; ub = (u64)(-(b)); }
    else ub = (u64)b;
    q = udiv64(ua, ub);
    return neg ? -(long long)q : (long long)q;
}

long long __moddi3(long long a, long long b) {
    if (b == 0) return 0;
    int neg = (a < 0);
    u64 ua = (a < 0) ? (u64)(-(a)) : (u64)a;
    u64 ub = (b < 0) ? (u64)(-(b)) : (u64)b;
    u64 q = udiv64(ua, ub);
    u64 r = ua - q * ub;
    return neg ? -(long long)r : (long long)r;
}

/* Беззнаковые варианты (gcc генерирует __udivdi3/__umoddi3 для
 * (u64)/(u32) — например в калибровке задержек WiFi-драйвера). */
unsigned long long __udivdi3(unsigned long long a, unsigned long long b) {
    return udiv64(a, b);
}

unsigned long long __umoddi3(unsigned long long a, unsigned long long b) {
    if (b == 0) return 0;
    u64 q = udiv64(a, b);
    return a - q * b;
}

/* СЕССИЯ 61: gcc объединяет пары (x/y, x%y) с одинаковыми операндами в
 * ОДИН вызов __udivmoddi4 (vsnprintf: десятичная печать u64 из %lld и
 * новых %f/%e/%g). Без неё — ошибка линковки ядра. */
unsigned long long __udivmoddi4(unsigned long long a, unsigned long long b,
                                unsigned long long *rem) {
    if (b == 0) {
        if (rem) *rem = 0;
        return 0;
    }
    u64 q = udiv64(a, b);
    if (rem) *rem = a - q * b;
    return q;
}
