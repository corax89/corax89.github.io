/* virtio_net.h — драйвер VirtIO-network для N2600-OS.
 *
 * VirtIO — стандарт виртуальных устройств QEMU/KVM.
 * Vendor ID 0x1AF4 (Red Hat / QEMU).
 *
 * Поддержка:
 *   - Legacy VirtIO-net (device 0x1000, I/O port)
 *   - Modern VirtIO-net (device 0x1041, MMIO) — базово
 *   - Приём/передача через virtqueues (ring buffers)
 *   - MAC из device config
 */
#ifndef VIRTIO_NET_H
#define VIRTIO_NET_H

#include "types.h"

int  virtio_net_init(void);
int  virtio_net_present(void);
const char *virtio_net_chip_name(void);
int  virtio_net_get_mac(u8 out_mac[6]);
int  virtio_net_send(const void *buf, u32 len);
u32  virtio_net_recv(void *out_buf, u32 out_max);

#endif
