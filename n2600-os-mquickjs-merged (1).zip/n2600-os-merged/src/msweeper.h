/* msweeper.h — «Сапёр»: ЧИСТАЯ логика игры (header-only, без fb/wm).
 *
 * Порт логики minesweeper.c (vietanhdev, Minesweeper Terminal Version,
 * https://github.com/vietanhdev/minesweeper-in-c): поле p[][] с минами
 * (9) и числами (1..8), открытие с заливкой пустых областей, флаги и
 * знаки вопроса, три уровня. Консольная обвязка (getch/termios/печать)
 * заменена вызовами из GUI (apps_mines.c), рекурсия open_empty_pos —
 * явным стеком (глубина рекурсии до 441 кадра — стек потока окна
 * небольшой).
 *
 * Отличия от оригинала (осознанные):
 *  - генератор случайных чисел — xorshift32 с seed от вызывающего
 *    (в ядре нет srand/time), одинаковый seed → одинаковое поле;
 *  - ограничение плотности оригинала (не больше 4 мин вокруг клетки)
 *    сохранено, но после 20000 неудачных попыток подряд смягчается,
 *    чтобы генерация не зациклилась;
 *  - победа — классическая: открыты все клетки без мин (вариант
 *    оригинала «флаги расставлены верно» убран);
 *  - клетки вне поля не открываются/не флагаются (в оригинале код
 *    это допускал только благодаря границам ввода).
 *
 * Хост-тест: work/test/ms_test.c (логика без GUI, ASan-чисто).
 */
#ifndef MSWEEPER_H
#define MSWEEPER_H

#include "types.h"

#define MS_MAX 21              /* максимальная сторона (уровень 3) */

/* содержимое клетки: p[][] */
#define MS_EMPTY 0
#define MS_MINE  9

/* пометка клетки: flag[][] */
#define MS_FLAG_NONE     0
#define MS_FLAG_BOMB     1
#define MS_FLAG_QUESTION 2

/* состояние игры */
#define MS_PLAY 0
#define MS_LOSE 1
#define MS_WIN  2

typedef struct {
    int rows, cols;            /* размер поля (клетки 0..rows-1/cols-1) */
    int mines;                 /* число мин */
    u8  p[MS_MAX][MS_MAX];     /* MS_EMPTY / 1..8 / MS_MINE */
    u8  opened[MS_MAX][MS_MAX];
    u8  flag[MS_MAX][MS_MAX];
    int flags_used;            /* число расставленных флагов (без «?»); */
    int state;                 /* MS_PLAY / MS_LOSE / MS_WIN */
    int boom_r, boom_c;        /* клетка, на которой подорвались */
    u32 rng;                   /* xorshift32 (seed != 0) */
} ms_game_t;

/* Уровни оригинала: 1 = 13x13/20, 2 = 16x16/30, 3 = 21x21/60. */
static inline void ms_level(int level, int *rows, int *cols, int *mines)
{
    switch (level) {
    case 1:  if (rows) *rows = 13; if (cols) *cols = 13; if (mines) *mines = 20; break;
    case 2:  if (rows) *rows = 16; if (cols) *cols = 16; if (mines) *mines = 30; break;
    default: if (rows) *rows = 21; if (cols) *cols = 21; if (mines) *mines = 60; break;
    }
}

static inline int ms_in_board(const ms_game_t *g, int r, int c)
{
    return r >= 0 && r < g->rows && c >= 0 && c < g->cols;
}

static inline u32 ms_rand(ms_game_t *g)
{
    g->rng ^= g->rng << 13;
    g->rng ^= g->rng >> 17;
    g->rng ^= g->rng << 5;
    return g->rng;
}

/* оригинал: mi_count() — мины вокруг клетки */
static inline int ms_neighbors(const ms_game_t *g, int row, int col)
{
    int near_minum = 0;
    for (int i = -1; i < 2; i++)
        for (int j = -1; j < 2; j++)
            if (row + i >= 0 && row + i < g->rows &&
                col + j >= 0 && col + j < g->cols)
                if (g->p[row + i][col + j] == MS_MINE)
                    near_minum++;
    return near_minum;
}

/* Генерация мин (оригинал: gen_mine() + ограничение плотности ≤4).
 * После 20000 отказов подряд ограничение смягчается — иначе на
 * тесных полях цикл может не сойтись. */
static inline void ms_gen_mines(ms_game_t *g)
{
    int placed = 0, rejects = 0;
    int cells = g->rows * g->cols;
    int cap = g->mines < cells / 3 ? g->mines : cells / 3;  /* санитарный предел */
    while (placed < cap) {
        int r = (int)(ms_rand(g) % (u32)g->rows);
        int c = (int)(ms_rand(g) % (u32)g->cols);
        if (g->p[r][c] == MS_MINE) continue;
        if (rejects < 20000) {
            int ok = 1;
            for (int i = -1; i < 2 && ok; i++)
                for (int j = -1; j < 2 && ok; j++) {
                    int rr = r + i, cc = c + j;
                    if (rr >= 0 && rr < g->rows && cc >= 0 && cc < g->cols &&
                        g->p[rr][cc] != MS_MINE &&
                        ms_neighbors(g, rr, cc) > 3)
                        ok = 0;
                }
            if (!ok) { rejects++; continue; }
        }
        g->p[r][c] = MS_MINE;
        placed++;
        rejects = 0;
    }
    g->mines = placed;   /* санитарный предел мог урезать запрос */
}

/* Числа вокруг мин (оригинал: gen_num()) */
static inline void ms_gen_numbers(ms_game_t *g)
{
    for (int i = 0; i < g->rows; i++)
        for (int j = 0; j < g->cols; j++)
            if (g->p[i][j] == MS_EMPTY)
                g->p[i][j] = (u8)ms_neighbors(g, i, j);
}

/* Новая игра. seed != 0 (xorshift32 вырождается на нуле). */
static inline void ms_init(ms_game_t *g, int level, u32 seed)
{
    ms_level(level, &g->rows, &g->cols, &g->mines);
    for (int i = 0; i < MS_MAX; i++)
        for (int j = 0; j < MS_MAX; j++) {
            g->p[i][j] = MS_EMPTY;
            g->opened[i][j] = 0;
            g->flag[i][j] = MS_FLAG_NONE;
        }
    g->flags_used = 0;
    g->state = MS_PLAY;
    g->boom_r = g->boom_c = -1;
    g->rng = seed ? seed : 0x9E3779B9u;
    ms_gen_mines(g);
    ms_gen_numbers(g);
}

/* Число закрытых клеток (оригинал: unopened_count(), там был неинициа-
 * лизированный счётчик — здесь корректно). */
static inline int ms_unopened(const ms_game_t *g)
{
    int n = 0;
    for (int i = 0; i < g->rows; i++)
        for (int j = 0; j < g->cols; j++)
            if (!g->opened[i][j]) n++;
    return n;
}

static inline void ms_check_win(ms_game_t *g)
{
    if (g->state != MS_PLAY) return;
    if (ms_unopened(g) == g->mines) {
        g->state = MS_WIN;
        /* оставшиеся мины помечаем флагами (как в классических реализациях) */
        for (int i = 0; i < g->rows; i++)
            for (int j = 0; j < g->cols; j++)
                if (g->p[i][j] == MS_MINE && !g->opened[i][j] &&
                    g->flag[i][j] != MS_FLAG_BOMB) {
                    g->flag[i][j] = MS_FLAG_BOMB;
                    g->flags_used++;
                }
    }
}

/* Открыть клетку (оригинал: open() + open_empty_pos()).
 * Возвращает 1, если состояние изменилось. */
static inline int ms_open(ms_game_t *g, int r, int c)
{
    if (g->state != MS_PLAY || !ms_in_board(g, r, c)) return 0;

    if (g->p[r][c] == MS_MINE) {
        /* подрыв: показать все мины (оригинал делал это в check_win) */
        g->opened[r][c] = 1;
        g->boom_r = r; g->boom_c = c;
        for (int i = 0; i < g->rows; i++)
            for (int j = 0; j < g->cols; j++)
                if (g->p[i][j] == MS_MINE) g->opened[i][j] = 1;
        g->state = MS_LOSE;
        return 1;
    }

    if (g->opened[r][c]) return 0;

    /* заливка пустой области явным стеком вместо рекурсии оригинала */
    u16 stack[MS_MAX * MS_MAX];
    int sp = 0;
    stack[sp++] = (u16)(r * MS_MAX + c);
    g->opened[r][c] = 1;
    while (sp > 0) {
        int cur = stack[--sp];
        int cr = cur / MS_MAX, cc = cur % MS_MAX;
        if (g->p[cr][cc] != MS_EMPTY) continue;   /* число — не расширяется */
        for (int i = -1; i < 2; i++)
            for (int j = -1; j < 2; j++) {
                int rr = cr + i, cc2 = cc + j;
                if (rr < 0 || rr >= g->rows || cc2 < 0 || cc2 >= g->cols)
                    continue;
                if (g->opened[rr][cc2] || g->p[rr][cc2] == MS_MINE) continue;
                g->opened[rr][cc2] = 1;
                stack[sp++] = (u16)(rr * MS_MAX + cc2);
            }
    }
    ms_check_win(g);
    return 1;
}

/* Цикл пометки: нет → флаг → вопрос → нет (оригинал: bomb_flag/question).
 * Возвращает 1, если состояние изменилось. */
static inline int ms_flag(ms_game_t *g, int r, int c)
{
    if (g->state != MS_PLAY || !ms_in_board(g, r, c)) return 0;
    if (g->opened[r][c]) return 0;

    switch (g->flag[r][c]) {
    case MS_FLAG_NONE:
        g->flag[r][c] = MS_FLAG_BOMB;
        g->flags_used++;
        break;
    case MS_FLAG_BOMB:
        g->flag[r][c] = MS_FLAG_QUESTION;
        g->flags_used--;
        break;
    default:
        g->flag[r][c] = MS_FLAG_NONE;
        break;
    }
    return 1;
}

#endif /* MSWEEPER_H */
