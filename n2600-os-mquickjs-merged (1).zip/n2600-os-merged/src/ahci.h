/* ahci.h — AHCI/SATA-драйвер: HDD + ATAPI CD (для VMware SATA и совр. железа). */
#ifndef AHCI_H
#define AHCI_H

#include "types.h"

int  ahci_init(void);            /* 1 = AHCI-контроллер найден */
int  ahci_present(void);         /* контроллер есть */
int  ahci_hdd_present(void);     /* найден SATA-диск */
int  ahci_cd_present(void);      /* найден SATA ATAPI-привод */
u32  ahci_hdd_sectors(void);
const char *ahci_hdd_model(void);

/* Чтение секторов (512 байт) SATA-диска; 1 = успех */
int  ahci_read_hdd(u32 lba, u8 count, void *buf);

/* Запись секторов SATA-диска (WRITE DMA EXT) — сессия 12 (форматирование) */
int  ahci_write_hdd(u32 lba, u8 count, const void *buf);

/* Чтение сектора ATAPI-привода (2048 байт); 1 = успех */
int  ahci_read_cd(u32 lba, void *buf);

#endif /* AHCI_H */

/* Сессия 11: фоновая инициализация SATA — миллисекундные ожидания
 * выполняются через планировщик (task_msleep), пока диск раскручивается. */
void ahci_set_async(int on);
