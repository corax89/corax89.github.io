/* apps_mines.c — «Сапёр» для N2600-OS (GUI-порт).
 *
 * Логика — src/msweeper.h: порт minesweeper.c (vietanhdev,
 * https://github.com/vietanhdev/minesweeper-in-c) с консоли на GUI.
 * Что заменило консоль оригинала:
 *   - поле рисуется клетками 24x24 (fb_*), а не символами терминала;
 *   - мышь: ЛКМ — открыть (open), ПКМ — цикл пометки флаг/вопрос
 *     (bomb_flag/question оригинала);
 *   - клавиатура оригинала сохранена: стрелки — курсор, Enter/Space —
 *     открыть, F — пометка, N — новая игра; Esc — закрыть окно;
 *   - уровни оригинала: 13x13/20, 16x16/30, 21x21/60 (кнопки в шапке:
 *     окно пересоздаётся под размер поля);
 *   - счётчик мин в шапке (mines - flags_used), статус-строка внизу.
 *
 * Состояние игры — ms_game_t внутри mines_t (malloc окна).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "msweeper.h"

#define CELL      24            /* размер клетки, px */
#define BOARD_X   8             /* отступ поля слева */
#define BOARD_Y   34            /* отступ поля сверху (под шапкой) */
#define BAR_H     26            /* ширина шапки с кнопками */
#define STATUS_H  18            /* статус-строка */

/* цвета клеток (фиксированные — как кнопки калькулятора; поле читается
 * одинаково при любой теме) */
#define C_TILE      fb_rgb(0x39, 0x43, 0x4F)
#define C_TILE_HI   fb_rgb(0x57, 0x63, 0x70)
#define C_TILE_LO   fb_rgb(0x1F, 0x25, 0x2D)
#define C_OPEN      fb_rgb(0x19, 0x1F, 0x26)
#define C_GRID      fb_rgb(0x24, 0x2B, 0x34)
#define C_MINE      fb_rgb(0x12, 0x15, 0x1A)
#define C_BOOM      fb_rgb(0x7A, 0x28, 0x20)
#define C_KB_CUR    fb_rgb(0xFF, 0xE0, 0x60)

static u32 num_color(int n)
{
    static const u32 cols[9] = {
        0,                              /* 0 — не рисуется */
        0xFF6FC6FFu,                    /* 1 синий    */
        0xFF7FC866u,                    /* 2 зелёный  */
        0xFFE06C50u,                    /* 3 красный  */
        0xFF8FB4E8u,                    /* 4 голубой  */
        0xFFE8B44Au,                    /* 5 янтарный */
        0xFF60E0D0u,                    /* 6 бирюзовый*/
        0xFFE6EAEEu,                    /* 7 белый    */
        0xFF8A929Eu                     /* 8 серый    */
    };
    return (n >= 1 && n <= 8) ? cols[n] : wm_theme_text();
}

typedef struct {
    ms_game_t g;
    int level;                 /* 1..3 */
    int kr, kc;                /* клавиатурный курсор */
    u32 seed_ctr;              /* вариация seed между партиями */
} mines_t;

/* seed партии: тики PIT + счётчик (два клика в один тик — разные поля) */
static u32 mines_seed(mines_t *m)
{
    m->seed_ctr += 0x9E3779B9u;
    return (timer_ticks() * 1664525u + m->seed_ctr) | 1u;
}

static void mines_reset(mines_t *m, int level)
{
    m->level = level;
    ms_init(&m->g, level, mines_seed(m));
    m->kr = m->g.rows / 2;
    m->kc = m->g.cols / 2;
}

/* ------------------ кнопки шапки ------------------ */
enum { BTN_NEW = 0, BTN_L1, BTN_L2, BTN_L3, BTN_COUNT };
static const char *btn_label[BTN_COUNT] = { "Новая", "13x13", "16x16", "21x21" };
static const int  btn_level[BTN_COUNT]  = { 0, 1, 2, 3 };

static void btn_rect(int i, int *x, int *y, int *w, int *h)
{
    static const int bw[BTN_COUNT] = { 58, 56, 56, 56 };
    static const int bx[BTN_COUNT] = { 6, 68, 128, 188 };
    *x = bx[i]; *y = 4; *w = bw[i]; *h = BAR_H - 8;
}

/* ------------------ отрисовка ------------------ */

/* мина 12x12 в клетке (x,y — угол клетки) */
static void draw_mine(int x, int y)
{
    fb_fill_rect(x + 7, y + 8, 10, 8, C_MINE);    /* тело */
    fb_fill_rect(x + 9, y + 6, 6, 12, C_MINE);
    fb_fill_rect(x + 8, y + 7, 8, 10, C_MINE);
    fb_hline(x + 4, x + 19, y + 12, C_MINE);      /* шипы */
    fb_vline(x + 12, y + 4, y + 19, C_MINE);
    fb_hline(x + 5, x + 7, y + 7, C_MINE);        /* диагонали */
    fb_hline(x + 6, x + 8, y + 6, C_MINE);
    fb_hline(x + 16, x + 18, y + 7, C_MINE);
    fb_hline(x + 15, x + 17, y + 6, C_MINE);
    fb_hline(x + 5, x + 7, y + 17, C_MINE);
    fb_hline(x + 6, x + 8, y + 18, C_MINE);
    fb_hline(x + 16, x + 18, y + 17, C_MINE);
    fb_hline(x + 15, x + 17, y + 18, C_MINE);
    fb_fill_rect(x + 9, y + 8, 2, 2, fb_rgb(0xC8, 0xD2, 0xDC));  /* блик */
}

static void draw_flag(int x, int y)
{
    fb_vline(x + 10, y + 4, y + 17, fb_rgb(0xC8, 0xD2, 0xDC));   /* древко */
    fb_fill_rect(x + 11, y + 4, 7, 3, fb_rgb(0xE0, 0x50, 0x40)); /* флажок */
    fb_fill_rect(x + 11, y + 7, 5, 2, fb_rgb(0xE0, 0x50, 0x40));
    fb_fill_rect(x + 7, y + 17, 8, 2, fb_rgb(0xC8, 0xD2, 0xDC)); /* база */
}

static void draw_cell(const mines_t *m, int r, int c, int bx, int by)
{
    int x = bx + c * CELL, y = by + r * CELL;
    const ms_game_t *g = &m->g;

    if (!g->opened[r][c]) {
        /* закрытая: «выпуклая» плитка */
        fb_fill_rect(x, y, CELL, CELL, C_TILE);
        fb_hline(x, x + CELL - 1, y, C_TILE_HI);
        fb_vline(x, y, y + CELL - 1, C_TILE_HI);
        fb_hline(x, x + CELL - 1, y + CELL - 1, C_TILE_LO);
        fb_vline(x + CELL - 1, y, y + CELL - 1, C_TILE_LO);

        if (g->flag[r][c] == MS_FLAG_BOMB)
            draw_flag(x, y);
        else if (g->flag[r][c] == MS_FLAG_QUESTION) {
            fb_char(x + CELL / 2 - 4, y + 4, '?', wm_theme_text(), -1);
        }
        return;
    }

    /* открытая: плоская + сетка */
    u32 bg = C_OPEN;
    if (g->p[r][c] == MS_MINE)
        bg = (r == g->boom_r && c == g->boom_c) ? C_BOOM : C_OPEN;
    fb_fill_rect(x, y, CELL, CELL, bg);
    fb_hline(x, x + CELL - 1, y, C_GRID);
    fb_vline(x, y, y + CELL - 1, C_GRID);

    if (g->p[r][c] == MS_MINE) {
        draw_mine(x, y);
    } else if (g->p[r][c] >= 1) {
        char b[2] = { (char)('0' + g->p[r][c]), 0 };
        fb_text(x + CELL / 2 - 4, y + 4, b, num_color(g->p[r][c]), -1);
    }
}

static void mines_draw(window_t *w)
{
    mines_t *m = (mines_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* шапка */
    fb_fill_rect(0, 0, cw, BAR_H, wm_theme_win_bg_alt());
    fb_hline(0, cw - 1, BAR_H - 1, wm_theme_border());

    for (int i = 0; i < BTN_COUNT; i++) {
        int x, y, bw, bh;
        btn_rect(i, &x, &y, &bw, &bh);
        int active = (btn_level[i] != 0 && btn_level[i] == m->level);
        /* сессия 20: wm_button_draw центрует подпись по ВИДИМЫМ СИМВОЛАМ
         * и гарантирует, что текст не выйдет за пределы кнопки (раньше
         * центровка по strlen считала кириллицу дважды — «Новая»
         * вылезала за кнопку влево) */
        wm_button_draw(x, y, bw, bh, btn_label[i],
                       active ? wm_theme_sel_bg() : wm_theme_title(),
                       wm_theme_title_text(), wm_theme_border());
    }

    /* счётчик мин справа (ширина — по СИМВОЛАМ, не по байтам) */
    char mc[40];
    snprintf(mc, sizeof(mc), "Мины: %d", m->g.mines - m->g.flags_used);
    fb_text(cw - 4 - (int)fb_text_w(mc), 5, mc, wm_theme_text_info(), -1);

    /* поле */
    int bw = m->g.cols * CELL, bh = m->g.rows * CELL;
    fb_fill_rect(BOARD_X - 2, BOARD_Y - 2, bw + 4, bh + 4, C_TILE_LO);
    for (int r = 0; r < m->g.rows; r++)
        for (int c = 0; c < m->g.cols; c++)
            draw_cell(m, r, c, BOARD_X, BOARD_Y);

    /* клавиатурный курсор (рамка поверх клетки) */
    if (m->g.state == MS_PLAY) {
        int x = BOARD_X + m->kc * CELL, y = BOARD_Y + m->kr * CELL;
        fb_rect(x + 1, y + 1, CELL - 2, CELL - 2, C_KB_CUR);
        fb_rect(x + 2, y + 2, CELL - 4, CELL - 4, C_KB_CUR);
    }

    /* статус-строка */
    fb_fill_rect(0, ch - STATUS_H, cw, STATUS_H, wm_theme_win_bg_alt());
    const char *hint;
    if (m->g.state == MS_WIN)  hint = "Победа! «Новая» — заново";
    else if (m->g.state == MS_LOSE) hint = "Взрыв! «Новая» — заново";
    else hint = "ЛКМ — открыть, ПКМ — флаг";
    fb_text(4, ch - STATUS_H + 2, hint, wm_theme_text_dim(), -1);
}

/* ------------------ ввод ------------------ */

/* клетка под мышью (координаты содержимого); 0 = мимо */
static int mines_cell_at(const mines_t *m, int mx, int my, int *r, int *c)
{
    int cc = (mx - BOARD_X) / CELL;
    int rr = (my - BOARD_Y) / CELL;
    if (cc < 0 || rr < 0 || cc >= m->g.cols || rr >= m->g.rows) return 0;
    *r = rr; *c = cc;
    return 1;
}

static void mines_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    mines_t *m = (mines_t *)w->data;
    if (mx < 0 || my < 0) return;

    /* кнопки шапки */
    if (my < BAR_H && (changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        for (int i = 0; i < BTN_COUNT; i++) {
            int x, y, bw, bh;
            btn_rect(i, &x, &y, &bw, &bh);
            if (mx >= x && mx < x + bw && my >= y && my < y + bh) {
                if (btn_level[i] == 0) {
                    mines_reset(m, m->level);        /* новая партия */
                    win_invalidate(w);
                } else if (btn_level[i] != m->level) {
                    /* окно пересоздаётся под размер поля */
                    int level = btn_level[i];
                    win_close(w);
                    app_mines_open_at(level);
                }
                return;
            }
        }
        return;
    }

    /* поле */
    int r, c;
    if (m->g.state != MS_PLAY) return;
    if (!mines_cell_at(m, mx, my, &r, &c)) return;
    m->kr = r; m->kc = c;

    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        ms_open(&m->g, r, c);
        win_invalidate(w);
    } else if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
        ms_flag(&m->g, r, c);
        win_invalidate(w);
    }
}

static void mines_key(window_t *w, const key_event_t *ev)
{
    mines_t *m = (mines_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }

    if (m->g.state != MS_PLAY) {
        if (ev->ch == 'n' || ev->ch == 'N' || ev->ch == ' ') {
            mines_reset(m, m->level);
            win_invalidate(w);
        }
        return;
    }

    switch (ev->code) {
    case KBD_UP:    if (m->kr > 0) m->kr--; break;
    case KBD_DOWN:  if (m->kr < m->g.rows - 1) m->kr++; break;
    case KBD_LEFT:  if (m->kc > 0) m->kc--; break;
    case KBD_RIGHT: if (m->kc < m->g.cols - 1) m->kc++; break;
    default:
        if (ev->ch == 'n' || ev->ch == 'N') {
            mines_reset(m, m->level);
        } else if (ev->code == 0x1C || ev->ch == ' ') {
            ms_open(&m->g, m->kr, m->kc);
        } else if (ev->ch == 'f' || ev->ch == 'F' ||
                   ev->ch == 'b' || ev->ch == 'B') {
            ms_flag(&m->g, m->kr, m->kc);
        } else {
            return;
        }
        break;
    }
    win_invalidate(w);
}

static void mines_close(window_t *w)
{
    free(w->data);
}

/* Открыть окно сапёра. level 1..3 (по умолчанию 1). */
void app_mines_open_at(int level)
{
    if (level < 1 || level > 3) level = 1;

    mines_t *m = (mines_t *)malloc(sizeof(mines_t));
    if (!m) return;
    memset(m, 0, sizeof(*m));
    mines_reset(m, level);

    int ww = BOARD_X * 2 + m->g.cols * CELL;
    int wh = BOARD_Y + m->g.rows * CELL + STATUS_H + 4;
    u32 W = fb_width(), H = fb_height();
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    int wx = (int)W / 2 - ww / 2;
    int wy = (int)(H - TBAR_H) / 2 - wh / 2;
    if (wx < 0) wx = 0;
    if (wy < 0) wy = 0;

    window_t *w = win_create("Сапёр", wx, wy, ww, wh,
                             mines_draw, mines_key, mines_mouse,
                             NULL, mines_close, m);
    if (!w) free(m);
}

void app_mines_open(void)
{
    app_mines_open_at(1);
}
