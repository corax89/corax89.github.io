/* ne2000.c — драйвер NE2000 (8390) PCI Ethernet для N2600-OS.
 *
 * ПЕРЕПИСАН (сессия 7). Прежняя версия НЕ РАБОТАЛА ВООБЩЕ (из-за неё
 * «DHCP не ответил» и «ARP 7040 мс, сокет -1» из HTTP Trace):
 *
 *   БАГ-1 [DCR=word vs byte-доступ]: DCR программировался как 0x01
 *        (word-wide DMA), а данные гонялись ПОБАЙТНО (inb/outb).
 *        В remote-write каждый байт попадал в буфер через 16-битную
 *        запись: mem[rsar]=байт, mem[rsar+1]=0, rsar+=2 → КАДР
 *        ПЕРЕМЕЖАЛСЯ НУЛЯМИ и обрезался пополам (RBCR сгорал вдвое
 *        быстрее). На приёме — каждый второй байта пропускался.
 *        Ни один кадр не уходил в сеть корректным → slirp молчал на
 *        DISCOVER и ARP. Теперь DMA побайтовый (DCR WTS=0) и весь
 *        обмен побайтовый — режим и доступ согласованы.
 *        Сессия 21: DCR = 0x48 — добавлены биты 3 (ОБЯЗАТЕЛЕН в
 *        Bochs/86Box — их dp8390_rx() при «чистом» DCR молча
 *        выбрасывает ВСЕ входящие кадры: «DHCP no OFFER received»
 *        в 86Box) и 6 (FT1, значение Linux). См. ne2000_init.
 *
 *   БАГ-2 [кольцо приёма off-by-one]: пакет лежит на странице
 *        BNRY+1, а после чтения граница ставится на next_page-1
 *        (с wrap на PSTOP-1). Прежний код читал пакет со страницы
 *        BNRY (первый — мимо), ставил BNRY=next_page и определял
 *        «пусто» как bnry==curr — рассинхрон с первого же пакета.
 *
 *   БАГ-3 [пустой check]: корректное условие пустого кольца —
 *        (BNRY+1)==CURR (с wrap), а не BNRY==CURR.
 *
 * Реализация выверена по исходникам эмуляции QEMU hw/net/ne2000.c
 * (та же версия, что у пользователя) и по Linux drivers/net/ethernet/
 * 8390 (ne.c/8390.c):
 *   - регистры: CR стр.0/1 = 0x00/0x40, NODMA=0x20, RREAD=0x08,
 *     RWRITE=0x10, TRANS=0x04 (Linux 8390.h, QEMU ne2000.c);
 *   - remote DMA у QEMU НЕ зависит от битов CR (порт 0x10 читает/
 *     пишет mem[RSAR] с шириной по DCR; rcnt уменьшается сам);
 *   - заголовок пакета в кольце: {rsr, next_page, len_lo, len_hi},
 *     len = кадр + 4 байта заголовка, без CRC (сессия 22: проверено
 *     харнессом против net_dp8390.c 86Box и ne2000.c QEMU);
 *   - адресный фильтр unicast в QEMU сравнивает с ПЗУ-копией MAC в
 *     mem[0..10] (не с PAR) — наш MAC проходит всегда; broadcast
 *     требует RCR.AB (бит 2); PAR всё равно программируем (железо).
 *
 * Раскладка буферов (страницы по 256 байт):
 *   TX: страница 0x40 (адрес 0x4000, 1536 байт — кадр до 1514)
 *   RX: кольцо 0x46..0x80 (адреса 0x4600..0x8000 = 16К..32К) —
 *       влезает и в QEMU (PMEM 0x4000..0xC000), и в реальные
 *       16КБ-карты NE2000.
 */
#include "ne2000.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* ---------- Регистры 8390 (страница 0) ---------- */
#define NE_CR     0x00
#define NE_PSTART 0x01
#define NE_PSTOP  0x02
#define NE_BNRY   0x03
#define NE_TPDR   0x04   /* TPSR: transmit page start */
#define NE_TBCR0  0x05
#define NE_TBCR1  0x06
#define NE_ISR    0x07
#define NE_RSAR0  0x08
#define NE_RSAR1  0x09
#define NE_RBCR0  0x0A
#define NE_RBCR1  0x0B
#define NE_RCR    0x0C
#define NE_TCR    0x0D
#define NE_DCR    0x0E
#define NE_IMR    0x0F
#define NE_DATA   0x10   /* порт данных remote DMA */
#define NE_RESET  0x1F

/* CR: STP=0x01 STA=0x02 TXP=0x04 RD0(RREAD)=0x08 RD1(RWRITE)=0x10
 *     RD2(NODMA)=0x20, страницы: PG0=0x00 PG1=0x40 PG2=0x80 */
#define CR_STOP   0x01
#define CR_START  0x02
#define CR_TXP    0x04
#define CR_RREAD  0x08
#define CR_RWRITE 0x10
#define CR_NODMA  0x20
#define CR_PAGE0  0x00
#define CR_PAGE1  0x40

#define ISR_RX    0x01
#define ISR_TX    0x02
#define ISR_OVER  0x10
#define ISR_RDC   0x40

#define RSR_RXOK  0x01

/* Кольцо: TX на странице 0x40, RX 0x46..0x80 */
#define NE_TX_PAGE  0x40
#define NE_RX_START 0x46
#define NE_RX_STOP  0x80

/* FIX (аудит): PCI-идентификация только по БЕЛОМУ СПИСКУ известных
 * NE2000-клонов. Прежняя логика «любой класс 0x0200 с I/O-BAR, кроме
 * четырёх вендоров» захватывала ЧУЖИЕ карты и ne_reset() писал в их
 * регистры. Список — из Linux drivers/net/ethernet/8390/ne2k-pci.c;
 * QEMU -device ne2k_pci = 10EC:8029. */
typedef struct { u16 vendor, device; const char *name; } ne_pci_id_t;
static const ne_pci_id_t ne_pci_ids[] = {
    { 0x10EC, 0x8029, "Realtek RTL8029" },   /* QEMU ne2k_pci */
    { 0x1050, 0x0940, "Winbond W89C940" },
    { 0x8C4A, 0x1980, "Winbond W89C940F" },
    { 0x11F6, 0x1401, "Compex RL2000" },
    { 0x1106, 0x0926, "VIA VT86C926" },
    { 0x10BD, 0x0E34, "SureCom NE34" },
    { 0x4A14, 0x5000, "Netvin NV5000SC" },
    { 0,      0,      NULL }
};

typedef struct {
    int  present;
    u32  io_base;
    u8   mac[6];
    char chip_name[40];
    /* Сессия 12: диагностика «сеть по ne2000 рвётся / RX всегда 0» —
     * счётчики и последнее состояние кольца, доступные из терминала
     * (команда ne2000). Если у пользователя в эмуляторе кадры не
     * приходят, эти числа покажут, видит ли драйвер прерывание RX и
     * что происходит с указателями кольца (BNRY/CURR). */
    u32  diag_recv_calls;
    u32  diag_pkts;
    u32  diag_over;
    u32  diag_resync;
    u8   diag_bnry, diag_curr, diag_isr;
    u8   hint_silent;          /* подсказка «rx=0 от хоста» уже дана */
} ne2000_t;

static ne2000_t g_ne;

static inline u8  ne_r(u8 reg) { return inb(g_ne.io_base + reg); }
static inline void ne_w(u8 reg, u8 val) { outb(g_ne.io_base + reg, val); }

static void ne_delay(void)
{
    for (volatile int i = 0; i < 200; i++) (void)inb(0x80);
}

/* Выбрать страницу + режим (значение CR целиком) */
static inline void ne_cmd(u8 val) { ne_w(NE_CR, val); }

/* Сброс: запись в 0x1F. В QEMU чтение 0x1F — тоже сброс (лишний, но
 * безвредный: регистры не трогает, только isr=RESET и копию ПЗУ);
 * на реальном железе чтение снимает reset-latch. Делаем оба. */
static void ne_reset(void)
{
    outb(g_ne.io_base + NE_RESET, 0xFF);
    ne_delay();
    (void)inb(g_ne.io_base + NE_RESET);
    ne_delay();
}

/* ---------- Remote DMA (byte-wide, DCR=0x00) ----------
 * QEMU: порт 0x10 читает/пишет mem[RSAR], ширина по DCR; rcnt
 * уменьшается на 1 за байт, при 0 на записи данные игнорируются,
 * на чтении — читается всё равно (но мы ставим rcnt точно). */
static void ne_remote_read(u16 addr, void *out, u16 n)
{
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_RSAR0, (u8)(addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(addr >> 8));
    ne_w(NE_RBCR0, (u8)(n & 0xFF));
    ne_w(NE_RBCR1, (u8)(n >> 8));
    ne_cmd(CR_START | CR_RREAD | CR_PAGE0);
    u8 *p = (u8 *)out;
    for (u16 i = 0; i < n; i++)
        p[i] = inb(g_ne.io_base + NE_DATA);
    /* завершение DMA: сбросить RDC (QEMU ставит его на последнем байте) */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_ISR, ISR_RDC);
}

static void ne_remote_write(u16 addr, const void *src, u16 n)
{
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_RSAR0, (u8)(addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(addr >> 8));
    ne_w(NE_RBCR0, (u8)(n & 0xFF));
    ne_w(NE_RBCR1, (u8)(n >> 8));
    ne_cmd(CR_START | CR_RWRITE | CR_PAGE0);
    const u8 *p = (const u8 *)src;
    for (u16 i = 0; i < n; i++)
        outb(g_ne.io_base + NE_DATA, p[i]);
    /* дождаться RDC — ПО РЕАЛЬНОМУ ВРЕМЕНИ (FIX аудита: прежние
     * 20000 итераций ne_delay — до сотен мс; на зависшем/чужом
     * железе блокировали систему надолго) */
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            if (ne_r(NE_ISR) & ISR_RDC) break;
            if (timer_poll_expired(dl, 50000)) break;   /* 50 мс */
        }
    }
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_ISR, ISR_RDC);
}

/* ---------- Инициализация ---------- */
int ne2000_init(void)
{
    g_ne.present = 0;
    g_ne.io_base = 0;

    serial_puts("[ne2000] init...\n");

    /* PCI: ТОЛЬКО известные NE2000-клоны из белого списка (FIX аудита).
     * Прежняя логика «любой класс 0x0200 с I/O-BAR, кроме четырёх
     * вендоров» захватывала ЧУЖИЕ карты, и ne_reset() писал в их
     * регистры (сессия 11 — тот же класс проблемы). Класс 0x0200
     * остаётся быстрой проверкой, но решают vendor/device. Сканируем
     * ВСЕ шины (FIX: прежде — ранний выход на bus>2, карта за мостом
     * осталась бы незамеченной). */
    int found = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            u8 hdr = pci_read8(bus, dev, 0, 0x0E);
            int max_func = (hdr & 0x80) ? 8 : 1;
            for (int func = 0; func < max_func && !found; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor == 0xFFFF) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                /* Совпадение ТОЛЬКО по белому списку (ne_pci_ids выше):
                 * QEMU -device ne2k_pci = 10EC:8029; чужие устройства
                 * со своими драйверами (virtio 1AF4, atheros 1969/168C,
                 * intel 8086) в списке ОТСУТСТВУЮТ — не тронем. */
                const char *id_name = NULL;
                for (int k = 0; ne_pci_ids[k].name; k++) {
                    if (ne_pci_ids[k].vendor == vendor &&
                        ne_pci_ids[k].device == device) {
                        id_name = ne_pci_ids[k].name;
                        break;
                    }
                }
                if (!id_name) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                u32 classcc = pci_read32(bus, dev, func, 0x08);
                u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                u8 cc_sub  = (u8)((classcc >> 16) & 0xFF);
                if (cc_base != 0x02 || cc_sub != 0x00) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                u32 bar0 = pci_read32(bus, dev, func, 0x10);
                if (!(bar0 & 1)) {          /* ждём I/O-пространство */
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }
                g_ne.io_base = bar0 & 0xFFFC;

                u16 cmd = pci_read16(bus, dev, func, 0x04);
                cmd |= 0x05;  /* I/O Space + Bus Master */
                pci_write16(bus, dev, func, 0x04, cmd);

                strcpy(g_ne.chip_name, id_name);
                found = 1;
            }
        }
    }

    if (!found) {
        serial_puts("[ne2000] no NE2000-compatible card found\n");
        return 0;
    }

    serial_puts("[ne2000] found: ");
    serial_puts(g_ne.chip_name);
    serial_puts("\n");

    /* --- Сброс и базовая настройка (по Linux NS8390_init) --- */
    ne_reset();

    ne_cmd(CR_STOP | CR_NODMA | CR_PAGE0);   /* стоп, страница 0 */
    ne_delay();

    /* FIX БАГ-1: DCR = 0x00 — BYTE-wide DMA (было 0x01=word при
     * побайтовом доступе: кадры перемежались нулями/теряли байты).
     *
     * СЕССИЯ 21 (86Box: «DHCP no OFFER received»): байт-DMA остаётся, но
     * добавлены биты 3 и 6 -> DCR = 0x48 (то же значение, что у Linux
     * 8390.c для 8-битного режима; для word было бы 0x49).
     *   Бит 3 (0x08) ОБЯЗАТЕЛЕН в эмуляции Bochs/86Box: их DP8390-ядро
     *   гейтит приём через dev->DCR.loop = ((DCR & 0x08) != 0), и при
     *   «чистом» 0x00 dp8390_rx() молча выбрасывает КАЖДЫЙ входящий кадр
     *   (в т.ч. DHCP OFFER) — при этом TX работает, поэтому симптом был
     *   ровно «DISCOVER уходит, ответа нет». На реальном железе бит 3 —
     *   часть значения, которое десятилетиями пишет Linux, безопасно.
     *   Бит 6 (FT1) — порог FIFO, стандартное значение Linux. */
    ne_w(NE_DCR, 0x48);

    ne_w(NE_RBCR0, 0);
    ne_w(NE_RBCR1, 0);

    /* RCR: AB (бит 2) — broadcast (ARP/DHCP), AM (бит 3) — multicast
     * по хэшу MAR0-7 (программируем 0xFF — принимаем все группы;
     * сессия 21: прежде MAR были нулями и AM выключен — multicast
     * отбрасывался, на эмуляторах с «строгим» фильтром это ещё и
     * риск для будущих протоколов). Unicast себе — всегда. */
    ne_w(NE_RCR, 0x0C);
    /* TCR: loopback на время инициализации (железо), QEMU игнорирует */
    ne_w(NE_TCR, 0x02);

    /* Кольцо приёма */
    ne_w(NE_PSTART, NE_RX_START);
    ne_w(NE_PSTOP,  NE_RX_STOP);
    /* FIX БАГ-2: BNRY = PSTART-1 — первый пакет лежит на PSTART,
     * читаем со страницы BNRY+1 */
    ne_w(NE_BNRY, NE_RX_START - 1);

    /* MAC из ПЗУ. QEMU (и настоящий NE2000 в 16-битном режиме) хранит
     * ПЗУ УДВОЕННЫМ: mem[2i] = mem[2i+1] = mac[i] — берём каждый второй
     * байт (prom[0],prom[2],...). Но НЕ все эмуляторы так делают: часть
     * (VirtualBox, Bochs, реальные карты в 8-битном режиме) кладёт MAC
     * ПОДРЯД в prom[0..5]. Сессия 12: определяем раскладку автоматически —
     * если байты НЕ удвоены (prom[2i] != prom[2i+1]), читаем подряд.
     * Раньше на «несудвоенном» ПЗУ MAC читался как мусор (52:00:34:...)
     * и юникаст-кадры молча отбрасывались фильтром NIC.
     * FIX (аудит): прежняя эвристика могла ошибиться на «последовательном»
     * ПЗУ со случайно совпавшими парами. Теперь собираем ОБОА кандидата,
     * валидируем каждый (не-мультикаст, не-нули, не-FF) и берём удвоенный
     * только если он прошёл проверку; иначе — последовательный. Дополнительно
     * сверяем сигнатуру NE2000-PROM 0x57 0x57 (байты 14-15) — она отличает
     * настоящий ПЗУ 8390 от мусора чужой карты. */
    {
        u8 prom[32];
        ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
        ne_remote_read(0, prom, 32);
        /* сигнатура (диагностика; в удвоенной раскладке QEMU 57-байты
         * тоже удвоены, в последовательной идут парой 57 57) */
        int sig_ok = (prom[14] == 0x57 && prom[15] == 0x57);

        /* валидность кандидата MAC: unicast, не нулевой, не FF */
        #define NE_MAC_MCAST(m) ( ((m)[0] & 1) != 0 )
        u8 mac_d[6], mac_s[6];
        for (int i = 0; i < 6; i++) {
            mac_d[i] = prom[2 * i];
            mac_s[i] = prom[i];
        }
        u8 or_d = 0, and_d = 0xFF, or_s = 0, and_s = 0xFF;
        for (int i = 0; i < 6; i++) {
            or_d |= mac_d[i]; and_d &= mac_d[i];
            or_s |= mac_s[i]; and_s &= mac_s[i];
        }
        int d_ok = !NE_MAC_MCAST(mac_d) && or_d != 0 && and_d != 0xFF;
        int s_ok = !NE_MAC_MCAST(mac_s) && or_s != 0 && and_s != 0xFF;

        int doubled;
        if (d_ok && s_ok) {
            /* оба кандидата формально валидны — верим раскладке пар
             * (как прежде; QEMU/16-битные карты — удвоенные) */
            doubled = 1;
            for (int i = 0; i < 6; i++)
                if (prom[2 * i] != prom[2 * i + 1]) { doubled = 0; break; }
            /* но если пары «последовательные», а удвоенный кандидат
             * валиден лишь случайно — тоже берём его (совпадают) */
        } else if (d_ok) {
            doubled = 1;
        } else if (s_ok) {
            doubled = 0;   /* FIX: резервный путь, прежде детект падал */
        } else {
            doubled = 1;   /* оба мусор — сообщим ниже и выйдем */
        }
        memcpy(g_ne.mac, doubled ? mac_d : mac_s, 6);
        {
            char b[80];
            snprintf(b, sizeof(b),
                     "[ne2000] PROM: %s раскладка, сигнатура 0x57 %s\n",
                     doubled ? "удвоенная" : "последовательная",
                     sig_ok ? "есть" : "ОТСУТСТВУЕТ (подозрительно!)");
            serial_puts(b);
        }
        /* Сессия 11: мусорный MAC (все FF / групповой / нулевой) — карта
         * не отвечает, детект ложный. Не регистрируем. */
        {
            int bad = (g_ne.mac[0] & 1) != 0;
            u8 or_all = 0, and_all = 0xFF;
            for (int i = 0; i < 6; i++) {
                or_all |= g_ne.mac[i];
                and_all &= g_ne.mac[i];
            }
            if (or_all == 0 || and_all == 0xFF) bad = 1;
            if (bad) {
                serial_puts("[ne2000] MAC невалиден — ложный детект, пропуск\n");
                g_ne.io_base = 0;
                return 0;
            }
        }
        #undef NE_MAC_MCAST
    }
    serial_puts("[ne2000] MAC: ");
    {
        const char *h = "0123456789abcdef";
        char buf[4];
        for (int i = 0; i < 6; i++) {
            buf[0] = h[(g_ne.mac[i] >> 4) & 0xF];
            buf[1] = h[g_ne.mac[i] & 0xF];
            buf[2] = (i < 5) ? ':' : 0;
            buf[3] = 0;
            serial_puts(buf);
        }
    }
    serial_puts("\n");

    /* Страница 1: физический адрес (PAR0-5), multicast-хэш (MAR0-7),
     * CURR = PSTART (первый пакет будет записан на PSTART) */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE1);
    for (int i = 0; i < 6; i++)
        ne_w(0x01 + i, g_ne.mac[i]);
    /* MAR0-7 = 0xFF: хэш-фильтр принимает ЛЮБОЙ multicast —
     * согласовано с RCR.AM (см. выше) */
    for (int i = 0; i < 8; i++)
        ne_w(0x08 + i, 0xFF);
    ne_w(0x07, NE_RX_START);   /* CURR */

    /* Пуск: страница 0, режим START */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_delay();

    ne_w(NE_ISR, 0xFF);        /* сброс всех флагов */
    ne_w(NE_IMR, 0x00);        /* прерываний нет — поллинг из net_poll */
    ne_w(NE_TCR, 0x00);        /* нормальная передача (без loopback) */

    g_ne.present = 1;

    serial_puts("[ne2000] ready (byte DMA, ring 0x46-0x80)\n");
    return 1;
}

int ne2000_present(void) { return g_ne.present; }
const char *ne2000_chip_name(void) { return g_ne.chip_name; }

/* Сессия 12: диагностика для терминала (команда ne2000) — состояние
 * кольца приёма и счётчики. Возвращает число записанных символов. */
int ne2000_diag(char *out, int max)
{
    if (!g_ne.present) {
        if (max > 0) out[0] = 0;
        return 0;
    }
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    u8 bnry = ne_r(NE_BNRY);
    u8 isr  = ne_r(NE_ISR);
    ne_cmd(CR_START | CR_NODMA | CR_PAGE1);
    u8 curr = ne_r(0x07);
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    g_ne.diag_bnry = bnry;
    g_ne.diag_curr = curr;
    g_ne.diag_isr = isr;
    /* Сессия 23: к диагностике — подсказка, если передачи есть, а приёма
     * нет (типичный кейс 86Box: линк/backend отключены, TX при этом
     * мигает). Хост-харнесс dhcp86 доказал, что стек/драйвер/ядро 86Box
     * корректны, значит причина всегда выше dp8390. */
    const char *tail = "";
    if (g_ne.diag_pkts == 0 && g_ne.diag_recv_calls >= 3000)
        tail = "  <- rx=0: от хоста нет ни одного кадра (сеть эмулятора?)";
    return snprintf(out, (u32)max,
                    "ne2000: BNRY=%02x CURR=%02x ISR=%02x RXisr=%d "
                    "pkts=%u recv=%u over=%u resync=%u%s",
                    bnry, curr, isr, (isr & ISR_RX) ? 1 : 0,
                    (unsigned)g_ne.diag_pkts, (unsigned)g_ne.diag_recv_calls,
                    (unsigned)g_ne.diag_over, (unsigned)g_ne.diag_resync,
                    tail);
}

/* Кольцо живо? (для авто-диагностики: RX-бит в ISR при «пустом» кольце
 * означает, что кадры ПРИХОДЯТ, но указатели рассинхронизированы) */
u32 ne2000_diag_pkts(void) { return g_ne.diag_pkts; }

int ne2000_get_mac(u8 out_mac[6])
{
    if (!g_ne.present) return 0;
    memcpy(out_mac, g_ne.mac, 6);
    return 1;
}

/* ---------- Передача ---------- */
int ne2000_send(const void *buf, u32 len)
{
    if (!g_ne.present) return -1;
    if (len == 0) return -1;   /* FIX аудита: пустой кадр не отправляем */
    if (len > 1514) len = 1514;

    /* FIX (аудит): у 8390 ОДИН TX-буфер. Прежде можно было затереть кадр,
     * который ещё уходит: при двух подряд send() второй remote_write
     * писал в страницу 0x40 во время передачи первого. Дожидаемся
     * готовности: CR.TXP сброшен и/или ISR_TX поднят (дедлайн 50 мс,
     * чтобы зависшая карта не замораживала систему). */
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
            u8 cr  = ne_r(NE_CR);
            u8 isr = ne_r(NE_ISR);
            if (!(cr & CR_TXP)) {
                if (isr & ISR_TX) ne_w(NE_ISR, ISR_TX);   /* сбросить флаг */
                break;
            }
            if (timer_poll_expired(dl, 50000)) break;   /* 50 мс — не ждём вечно */
        }
    }

    /* Минимальный Ethernet-кадр — 60 байт (без CRC): добиваем нулями.
     * QEMU шлёт ровно TBCR байт; реальное железо тоже допускает,
     * а короткие ARP (42 байта) на живых сетях часто отбрасываются.
     * FIX аудита: буфер на стеке (был static — не реентерабельно). */
    u8 tmp[60];
    if (len < 60) {
        memcpy(tmp, buf, len);
        memset(tmp + len, 0, 60 - len);
        buf = tmp;
        len = 60;
    }

    /* Кадр → буфер NIC (страница 0x40, адрес 0x4000) */
    ne_remote_write(NE_TX_PAGE * 256, buf, (u16)len);

    /* Пуск передачи */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    ne_w(NE_TPDR, NE_TX_PAGE);
    ne_w(NE_TBCR0, (u8)(len & 0xFF));
    ne_w(NE_TBCR1, (u8)(len >> 8));
    ne_cmd(CR_START | CR_TXP | CR_PAGE0);

    return (int)len;
}

/* ---------- Приём (один пакет за вызов; net_poll зовёт до 8 раз) ---------- */
u32 ne2000_recv(void *out_buf, u32 out_max)
{
    if (!g_ne.present) return 0;
    g_ne.diag_recv_calls++;

    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
    u8 bnry = ne_r(NE_BNRY);
    ne_cmd(CR_START | CR_NODMA | CR_PAGE1);
    u8 curr = ne_r(0x07);              /* CURR */
    ne_cmd(CR_START | CR_NODMA | CR_PAGE0);

    /* Переполнение кольца (реальное железо) — восстановление по процедуре
     * 8390 (FIX аудита: прежде ne_w(NE_ISR, 0xFF) стирал ВЕСЬ ISR — вместе
     * с ожидающими флагами RX/TX; и NIC не останавливался). Минимальный
     * корректный выход: STOP → сброс remote-DMA счётчиков → дождаться
     * завершения TX → чистить ТОЛЬКО ISR_OVER → ресинхрон BNRY → START. */
    if (ne_r(NE_ISR) & ISR_OVER) {
        g_ne.diag_over++;
        ne_cmd(CR_STOP | CR_NODMA | CR_PAGE0);
        ne_w(NE_RBCR0, 0);
        ne_w(NE_RBCR1, 0);
        {
            u32 dl = timer_poll_deadline();
            for (;;) {
                if (!(ne_r(NE_CR) & CR_TXP)) break;
                if (timer_poll_expired(dl, 50000)) break;
            }
        }
        ne_w(NE_ISR, ISR_OVER);   /* только переполнение, не весь ISR */
        u8 b = (u8)(curr - 1);
        if (b < NE_RX_START) b = NE_RX_STOP - 1;
        ne_w(NE_BNRY, b);
        ne_cmd(CR_START | CR_NODMA | CR_PAGE0);
        return 0;
    }

    /* FIX БАГ-2/3: непрочитанный пакет — на странице BNRY+1 (с wrap);
     * кольцо пусто, когда BNRY+1 == CURR */
    u8 pkt_page = (u8)(bnry + 1);
    if (pkt_page >= NE_RX_STOP) pkt_page = NE_RX_START;
    if (pkt_page == curr) {
        /* Сессия 12: диагностика «RX всегда 0» — кадры реально приходят
         * (бит RX в ISR), но кольцо «пусто»? Значит указатели синхронны,
         * а карта кадры НЕ записывает — например, фильтр RCR или чужой
         * MAC. Пишем состояние в serial РАЗ (не спамим).
         * FIX аудита: сбрасываем ISR_RX — иначе бит висит постоянно,
         * и диагностика врёт «ISR.RX=1» на каждом вызове. */
        if (ne_r(NE_ISR) & ISR_RX) {
            ne_w(NE_ISR, ISR_RX);
            if ((g_ne.diag_pkts == 0) && (g_ne.diag_recv_calls & 0x3FF) == 0) {
                char b[96];
                snprintf(b, sizeof(b),
                         "[ne2000] ВНИМАНИЕ: ISR.RX=1, но кольцо пусто "
                         "(BNRY=%02x CURR=%02x) — кадры фильтруются?\n",
                         bnry, curr);
                serial_puts(b);
            }
        } else if (g_ne.diag_pkts == 0 && !g_ne.hint_silent &&
                   g_ne.diag_recv_calls >= 0x0C00) {
            /* Сессия 22 (харнесс ne2k86): карта и dp8390-ядро 86Box
             * совместимы с нашим драйвером ПОЛНОСТЬЮ (приём/кольцо/передача
             * проверены против НАСТОЯЩЕГО net_dp8390.c). Сессия 23
             * (харнесс dhcp86): ПОЛНЫЙ цикл DHCP (DISCOVER -> OFFER ->
             * REQUEST -> ACK -> BOUND 10.0.2.15) проходит через наш
             * стек, ne2000.c и ядро 86Box — все гейты libslirp
             * (ethertype/IP-чексумма/длины/UDP/bootp) ПРОЙДЕНЫ.
             * Если при тысячах опросов не пришло НИ ОДНОГО кадра
             * (ISR.RX ни разу не поднялся, BNRY/CURR стоят на месте) —
             * кадры теряются ВЫШЕ dp8390: в 86Box это «сеть отключена»
             * в статус-баре, null/не запустившийся backend или PCap,
             * смотрящий не в тот адаптер. Кадры ОС при этом уходят
             * (ISR.TX поднимается) — tx-счётчик растёт как ни в чём
             * не бывало. */
            g_ne.hint_silent = 1;
            serial_puts("[ne2000] rx=0: NIC не принял НИ ОДНОГО кадра от "
                        "хоста, при этом передача ОС работает (ISR.TX). "
                        "Проблема в сети эмулятора, а не в ОС. Проверьте в "
                        "86Box: 1) значок сети в статус-баре — не "
                        "перечёркнут (ПКМ -> Connection = connected); "
                        "2) Settings -> Network: Network type = SLiRP, "
                        "карта Realtek RTL8029AS; 3) не было ли окна ошибки "
                        "сети при старте эмулятора.\n");
        }
        return 0;
    }

    /* Заголовок пакета: {rsr, next_page, len_lo, len_hi}. Семантика длины
     * ПРОВЕРЕНА харнессом против НАСТОЯЩИХ net_dp8390.c 86Box и ne2000.c
     * QEMU (сессия 22): len = кадр + 4 байта заголовка, БЕЗ CRC (QEMU:
     * total_len = size + 4, кадр пишется как есть; 86Box: pkthdr len =
     * io_len + sizeof(pkthdr)). frame_len = len - 4 — кадр целиком,
     * как и от e1000. */
    u8 hdr[4];
    ne_remote_read((u16)pkt_page << 8, hdr, 4);
    u8 status = hdr[0];
    u8 next   = hdr[1];
    u16 len   = (u16)hdr[2] | ((u16)hdr[3] << 8);

    if (!(status & RSR_RXOK) || len < 4 || len > 1522 ||
        next < NE_RX_START || next >= NE_RX_STOP) {
        /* битый заголовок = рассинхрон; догоняем CURR */
        g_ne.diag_resync++;
        u8 b = (u8)(curr - 1);
        if (b < NE_RX_START) b = NE_RX_STOP - 1;
        ne_w(NE_BNRY, b);
        return 0;
    }

    u16 frame_len = (u16)(len - 4);
    if ((u32)frame_len > out_max) frame_len = (u16)out_max;
    if (frame_len == 0) {
        u8 b = (u8)(next - 1);
        if (b < NE_RX_START) b = NE_RX_STOP - 1;
        ne_w(NE_BNRY, b);
        return 0;
    }

    /* Данные пакета. FIX (аудит): пакет может ПЕРЕХОДИТЬ через конец
     * кольца (PSTOP → PSTART) — remote DMA 8390 читает ЛИНЕЙНО и сам
     * НЕ заворачивает RSAR на границу приёма (это делала только
     * локальная DMA NIC при ЗАПИСИ пакета). Линейное чтение через
     * границу возвращало мусор из-за кольца. Режем на две части. */
    {
        u32 pos    = ((u32)pkt_page << 8) + 4;
        u32 to_end = (u32)NE_RX_STOP * 256 - pos;   /* байт до конца кольца */
        if ((u32)frame_len <= to_end) {
            ne_remote_read((u16)pos, out_buf, frame_len);
        } else {
            ne_remote_read((u16)pos, out_buf, (u16)to_end);
            ne_remote_read((u16)((u32)NE_RX_START << 8),
                           (u8 *)out_buf + to_end,
                           (u16)((u32)frame_len - to_end));
        }
    }

    /* Продвинуть границу: BNRY = next-1 (wrap → PSTOP-1) */
    u8 b = (u8)(next - 1);
    if (b < NE_RX_START) b = NE_RX_STOP - 1;
    ne_w(NE_BNRY, b);

    ne_w(NE_ISR, ISR_RX);   /* FIX аудита: флаг обработан — сбросим, чтобы
                             * диагностика не показывала вечный RX=1 */
    g_ne.diag_pkts++;
    return frame_len;
}
