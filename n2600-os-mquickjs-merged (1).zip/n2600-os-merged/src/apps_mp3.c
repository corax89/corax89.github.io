/* apps_mp3.c — MP3-плеер N2600-OS (сессия 60).
 *
 * Компактный проигрыватель: игра/пауза и ползунок позиции (перетаскивание
 * = поиск). Декодирование — dr_mp3 (src/dr_mp3.h, основная библиотека
 * ОС, см. mp3svc.c), вывод — потоковое воспроизведение
 * sound_stream_chunk() (DMA-кольцо драйвера переключается по кускам,
 * щелчков нет; см. sound.h).
 *
 * Архитектура: окно работает в СВОЕМ потоке WM (колбэки draw/key/mouse),
 * декодирование+подача звука — отдельная задача «mp3play» (task_spawn).
 * Обмен — только атомарные флаги/счётчики u32 в состоянии mp3p_t
 * (playing/quit/seek_req/played_out): u32 на i386 атомарен, u64 между
 * потоками не передаётся.
 *
 * FPU: декодирование dr_mp3 идёт под общим FPU-локом imgsvc (внутри
 * mp3svc); ресэмплер и вся остальная логика — целочисленные.
 *
 * Открытие: файловый менеджер → двойной клик по .mp3 —
 * app_mp3_open_with(имя, данные, длина) с ПЕРЕДАЧЕЙ ВЛАДЕНИЯ буфером
 * (плеер сам его освобождает). Из лаунчера — подсказка. */
#include "types.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "apps.h"
#include "mp3svc.h"
#include "sound.h"
#include "mouse.h"
#include "kbd.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

#define MP3P_W 460
#define MP3P_H 172

#define OUT_CHUNK 8192   /* выходных стерео-фреймов на кусок
                          * (186 мс @ 44.1 кГц / 171 мс @ 48 кГц;
                          * лимиты колец: ES137x 16384, HDA 8192) */
#define IN_CHUNK  4608   /* входных фреймов за декод (4 × 1152) */

typedef struct {
    char     name[64];
    char    *data;             /* файл MP3 (владелец — плеер) */
    u32      len;
    void    *ctx;              /* opaque drmp3 (MP3_CTX_SIZE) */
    u32      chans;            /* каналов в файле: 1..2 */
    u32      rate;             /* частота файла, Гц */
    u32      total_frames;     /* оценка длительности, фреймов файла */
    u32      total_sec;        /* оценка длительности, секунд */
    /* --- разделяемое с задачей воспроизведения (только u32!) --- */
    volatile int  playing;
    volatile int  finished;     /* файл доигран до конца */
    volatile int  quit;
    volatile int  task_alive;
    volatile int  task_spawned; /* защита от двойного task_spawn */
    volatile int  stop_req;
    volatile int  seek_req;
    volatile u32  seek_frame;   /* цель поиска, фреймов файла */
    volatile u32  played_out;   /* выходных фреймов воспроизведено */
    int           dragging;     /* ползунок тащат (только поток окна) */
    window_t     *w;
} mp3p_t;

/* ---------------- утилиты ---------------- */

static void mp3p_fmt_time(char *out, u32 n, u32 sec)
{
    snprintf(out, n, "%u:%02u", sec / 60u, sec % 60u);
}

/* Заполнить выходной кусок РОВНО out_frames стерео-фреймов:
 * mono→stereo + линейный ресэмплер 16.16 (целочисленный, без FPU).
 * Если входа не хватило (конец файла) — добить тишиной. */
static void mp3p_fill_out(const i16 *in, u32 in_got, u32 chans,
                          u32 srate, u32 orate,
                          i16 *out, u32 out_frames)
{
    if (srate == orate) {
        for (u32 i = 0; i < out_frames; i++) {
            i16 l = 0, r = 0;
            if (in_got) {
                u32 j = (i < in_got) ? i : (in_got - 1);
                l = in[j * chans];
                r = (chans == 2) ? in[j * 2 + 1] : l;
            }
            out[2 * i]     = l;
            out[2 * i + 1] = r;
        }
        return;
    }
    u32 step = (u32)(((u64)srate << 16) / orate);
    u32 pos = 0;
    for (u32 i = 0; i < out_frames; i++) {
        i16 l = 0, r = 0;
        if (in_got) {
            u32 idx  = pos >> 16;
            u32 frac = pos & 0xFFFF;
            u32 j0 = (idx < in_got) ? idx : (in_got - 1);
            u32 j1 = (idx + 1 < in_got) ? idx + 1 : j0;
            i32 l0 = in[j0 * chans], l1 = in[j1 * chans];
            i32 r0 = (chans == 2) ? in[j0 * 2 + 1] : l0;
            i32 r1 = (chans == 2) ? in[j1 * 2 + 1] : l0;
            l = (i16)(l0 + (((l1 - l0) * (i32)frac) >> 16));
            r = (i16)(r0 + (((r1 - r0) * (i32)frac) >> 16));
            pos += step;
        }
        out[2 * i]     = l;
        out[2 * i + 1] = r;
    }
}

/* ---------------- задача воспроизведения ---------------- */

static void mp3p_task(void *arg)
{
    mp3p_t *p = (mp3p_t *)arg;
    p->task_alive = 1;

    u32 orate = sound_stream_rate();
    if (!orate) { p->task_alive = 0; return; }

    i16 *stage = (i16 *)malloc((u32)IN_CHUNK * 2 * (u32)sizeof(i16));
    i16 *bufa  = (i16 *)malloc((u32)OUT_CHUNK * 2 * (u32)sizeof(i16));
    i16 *bufb  = (i16 *)malloc((u32)OUT_CHUNK * 2 * (u32)sizeof(i16));
    if (!stage || !bufa || !bufb) {
        if (stage) free(stage);
        if (bufa)  free(bufa);
        if (bufb)  free(bufb);
        p->task_alive = 0;
        return;
    }

    int cur = 0;        /* какой из двух кусков готовится */
    int stream_on = 0;  /* DAC активен (не на паузе) */
    u32 chunk_ms = (u32)(((u64)OUT_CHUNK * 1000u) / orate);
    u32 next_t = 0;

    while (!p->quit) {
        if (p->stop_req) {
            p->stop_req = 0;
            p->playing = 0;
            p->finished = 0;
            p->played_out = 0;
            mp3_seek(p->ctx, 0);
            if (stream_on) { sound_stream_stop(); stream_on = 0; }
            if (p->w) win_invalidate(p->w);
            continue;
        }
        if (p->seek_req) {
            p->seek_req = 0;
            mp3_seek(p->ctx, p->seek_frame);
            p->played_out = (u32)(((u64)p->seek_frame * orate) /
                                  (p->rate ? p->rate : orate));
            if (p->w) win_invalidate(p->w);
        }
        if (!p->playing) {
            if (stream_on) { sound_stream_pause(1); stream_on = 0; }
            task_msleep(30);
            next_t = 0;                       /* после паузы — заново */
            continue;
        }

        if (!stream_on) {
            if (p->finished) { p->playing = 0; continue; }
            sound_stream_pause(0);
            stream_on = 1;
            next_t = 0;
        }

        /* темп: кусок стартует каждые ~90% chunk_ms — 10% запаса под
         * джиттер планировщика, при опоздании кольцо просто долистает */
        if (!next_t) next_t = timer_ticks();
        if ((i32)(timer_ticks() - next_t) < 0) {
            task_msleep(1);
            continue;
        }
        next_t += chunk_ms - chunk_ms / 10;
        if ((i32)(timer_ticks() - next_t) > (i32)chunk_ms)
            next_t = timer_ticks();           /* сильно отстали — заново */

        u32 got = mp3_read_s16(p->ctx, stage, IN_CHUNK);
        if (got == 0) {
            p->finished = 1;
            p->playing = 0;
            if (stream_on) { sound_stream_stop(); stream_on = 0; }
            if (p->w) win_invalidate(p->w);
            continue;
        }
        mp3p_fill_out(stage, got, p->chans, p->rate, orate,
                      cur ? bufb : bufa, OUT_CHUNK);
        if (sound_stream_chunk(cur ? bufb : bufa, OUT_CHUNK) == 0)
            stream_on = 1;
        p->played_out += OUT_CHUNK;
        cur ^= 1;
    }

    if (stream_on) sound_stream_stop();
    free(stage);
    free(bufa);
    free(bufb);
    p->task_alive = 0;
}

static void mp3p_ensure_task(mp3p_t *p)
{
    /* task_spawned ставится ДО spawn: два быстрых клика не должны
     * породить вторую задачу над тем же состоянием (двойной free) */
    if (!p->task_alive && !p->task_spawned && sound_stream_rate()) {
        p->task_spawned = 1;
        task_spawn("mp3play", mp3p_task, p);
    }
}

static void mp3p_toggle(mp3p_t *p)
{
    if (p->finished) {                       /* повтор с начала */
        p->finished = 0;
        p->played_out = 0;
        p->seek_frame = 0;
        p->seek_req = 1;
        p->playing = 1;
        mp3p_ensure_task(p);
        return;
    }
    p->playing = !p->playing;
    mp3p_ensure_task(p);
}

static void mp3p_do_stop(mp3p_t *p)
{
    p->playing = 0;
    p->finished = 0;
    p->played_out = 0;
    if (p->task_alive) {
        p->stop_req = 1;                     /* остановит DAC и задачу */
    } else {
        mp3_seek(p->ctx, 0);                 /* задача не бежит — сами */
        sound_stream_stop();
    }
}

/* ---------------- окно плеера ---------------- */

static void mp3p_draw(window_t *w)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    u32 bg = wm_theme_win_bg();
    fb_fill_rect(0, 0, cw, ch, bg);

    /* имя файла */
    wm_text_fit(10, 8, p->name, cw - 20, wm_theme_text_dim(), 0);

    /* время */
    u32 orate = sound_stream_rate();
    u32 played_sec = orate ? p->played_out / orate : 0;
    if (p->total_sec && played_sec > p->total_sec) played_sec = p->total_sec;
    char t1[16], t2[16], line[40];
    mp3p_fmt_time(t1, sizeof(t1), played_sec);
    mp3p_fmt_time(t2, sizeof(t2), p->total_sec);
    snprintf(line, sizeof(line), "%s / %s", t1, t2);
    fb_text(cw / 2 - (int)fb_text_w(line) / 2, 32, line, wm_theme_text(), -1);

    /* ползунок позиции */
    int tx = 24, tw = cw - 48, ty = 64, th = 8;
    fb_fill_rect(tx, ty, tw, th, wm_theme_win_bg_alt());
    fb_rect(tx, ty, tw, th, wm_theme_text_dim());
    if (p->total_sec) {
        int fw = (int)(((u64)tw * played_sec) / p->total_sec);
        if (fw > tw) fw = tw;
        if (fw > 0) fb_fill_rect(tx, ty, fw, th, wm_theme_accent());
        int kx = tx + fw - 5;
        if (kx < tx) kx = tx;
        if (kx > tx + tw - 10) kx = tx + tw - 10;
        fb_fill_rect(kx, ty - 4, 10, th + 8, wm_theme_accent());
        fb_rect(kx, ty - 4, 10, th + 8, wm_theme_text());
    }

    /* кнопки: игра/пауза + стоп */
    wm_button_draw(24, 100, 120, 30, p->playing ? "Пауза" : "Играть",
                   wm_theme_win_bg_alt(), wm_theme_text(), wm_theme_text_dim());
    wm_button_draw(160, 100, 90, 30, "Стоп",
                   wm_theme_win_bg_alt(), wm_theme_text(), wm_theme_text_dim());

    /* статусная строка */
    char st[96];
    if (!orate)
        snprintf(st, sizeof(st), "Звуковое устройство не найдено");
    else if (p->finished)
        snprintf(st, sizeof(st), "Готово. «Играть» — ещё раз");
    else
        snprintf(st, sizeof(st), "dr_mp3 • файл %u Гц %s • выход %u Гц",
                 p->rate, p->chans == 2 ? "stereo" : "mono", orate);
    wm_text_fit(24, 144, st, cw - 48, wm_theme_text_dim(), 0);
}

static void mp3p_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    if (mx < 0 || my < 0) { p->dragging = 0; return; }

    int cw = win_content_w(w);
    int tx = 24, tw = cw - 48, ty = 64, th = 8;

    /* ползунок: клик и перетаскивание по дорожке (с допуском по вертикали) */
    if (my >= ty - 6 && my <= ty + th + 6 && mx >= tx && mx <= tx + tw) {
        if (btn & MSB_LEFT) {
            p->dragging = 1;
            if (p->total_frames && !p->finished) {
                int rel = mx - tx;
                if (rel < 0) rel = 0;
                if (rel > tw) rel = tw;
                p->seek_frame = (u32)(((u64)(u32)rel * p->total_frames) / (u32)tw);
                p->seek_req = 1;
            }
            win_invalidate(w);
        }
    } else if (p->dragging && !(btn & MSB_LEFT)) {
        p->dragging = 0;
    }

    if (changed & MSB_LEFT) {
        if (wm_button_hit(mx, my, 24, 100, 120, 30)) {
            mp3p_toggle(p);
            win_invalidate(w);
        } else if (wm_button_hit(mx, my, 160, 100, 90, 30)) {
            mp3p_do_stop(p);
            win_invalidate(w);
        }
    }
}

static void mp3p_key(window_t *w, const key_event_t *ev)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == 0x39) {                     /* Space: игра/пауза */
        mp3p_toggle(p);
        win_invalidate(w);
    }
}

static void mp3p_tick(window_t *w)
{
    win_invalidate(w);          /* 2 Гц: ход ползунка/времени */
}

static void mp3p_close(window_t *w)
{
    mp3p_t *p = (mp3p_t *)w->data;
    if (!p) return;
    p->quit = 1;
    int waited = 0;
    while (p->task_alive && waited < 1500) { task_msleep(5); waited += 5; }
    if (p->ctx) { mp3_close(p->ctx); free(p->ctx); }
    if (p->data) free(p->data);
    free(p);
}

/* ---------------- точки входа ---------------- */

/* Открыть MP3 из памяти (владение буфером data переходит плееру). */
void app_mp3_open_with(const char *name, const char *data, u32 len)
{
    if (!data || len == 0) {
        if (data) free((void *)data);
        app_outwin_open("MP3 плеер", "Файл пуст.\n", 11);
        return;
    }

    mp3p_t *p = (mp3p_t *)malloc(sizeof(mp3p_t));
    if (!p) { free((void *)data); return; }
    memset(p, 0, sizeof(mp3p_t));

    if (name && name[0]) {
        strncpy(p->name, name, sizeof(p->name) - 1);
        p->name[sizeof(p->name) - 1] = 0;
    } else {
        strcpy(p->name, "track.mp3");
    }
    p->data = (char *)data;      /* владение буфером — у плеера */
    p->len = len;

    p->ctx = malloc(MP3_CTX_SIZE);
    if (!p->ctx || !mp3_open_mem(data, len, p->ctx)) {
        const char *err = mp3_errstr();
        char msg[128];
        int n = snprintf(msg, sizeof(msg), "%s: %s\n", p->name,
                         err ? err : "не удалось открыть");
        if (p->ctx) free(p->ctx);
        free(p->data);
        free(p);
        app_outwin_open("MP3 плеер", msg, (u32)(n > 0 ? n : 0));
        return;
    }

    p->chans = mp3_channels(p->ctx);
    p->rate = mp3_rate(p->ctx);
    u64 tf = mp3_total_frames_estimate(p->ctx);
    p->total_frames = (u32)tf;
    p->total_sec = p->rate ? (u32)(tf / p->rate) : 0;

    char title[80];
    snprintf(title, sizeof(title), "MP3: %s", p->name);
    u32 W = fb_width(), H = fb_height();
    int ww = MP3P_W, wh = MP3P_H;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - 28) wh = (int)H - 28;
    p->w = win_create(title, 80, 60, ww, wh,
                      mp3p_draw, mp3p_key, mp3p_mouse, mp3p_tick, mp3p_close, p);
}

/* Из лаунчера: подсказка, как открыть файл. */
void app_mp3_open(void)
{
    const char *msg =
        "MP3-плеер N2600-OS (dr_mp3).\n\n"
        "Откройте .mp3 двойным кликом в приложении «Файлы»\n"
        "(RAM disk / HDD / USB / CD).\n"
        "Управление: игра/пауза, ползунок — поиск по файлу,\n"
        "пробел — игра/пауза, Esc — закрыть.\n";
    app_outwin_open("MP3 плеер", msg, (u32)strlen(msg));
}
