/* string.h — минимальная freestanding-библиотека строк (GCC сам вызывает
 * memcpy/memset/memmove даже в freestanding-режиме, поэтому имена стандартные).
 *
 * hosted-сборки (тесты движка/моста на Linux): <string.h> libc здесь НЕ
 * подключается через include_next — заголовок может быть найден через
 * кавычный include из его же каталога, где include_next не доходит до
 * системных путей. Вместо этого объявляем функции с __SIZE_TYPE__ —
 * типы совпадают с libc и конфликтов нет.
 *
 * __HOST_TEST__ (сессия 12): сборка wpa2.c на хосте для тест-векторов. */
#ifndef STRING_H
#define STRING_H

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__

/* hosted: те же имена, size_t = __SIZE_TYPE__ (совпадает с libc) */
typedef __SIZE_TYPE__ mq_size_t;
void  *memset(void *dst, int c, mq_size_t n);
void  *memcpy(void *dst, const void *src, mq_size_t n);
void  *memmove(void *dst, const void *src, mq_size_t n);
int    memcmp(const void *a, const void *b, mq_size_t n);
void  *memchr(const void *s, int c, mq_size_t n);
mq_size_t strlen(const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, mq_size_t n);
char  *strcpy(char *dst, const char *src);
char  *strncpy(char *dst, const char *src, mq_size_t n);
char  *strchr(const char *s, int c);
char  *strrchr(const char *s, int c);
char  *strstr(const char *hay, const char *needle);
int    snprintf(char *out, mq_size_t n, const char *fmt, ...);
int    vsnprintf(char *out, mq_size_t n, const char *fmt, __builtin_va_list ap);

#else /* freestanding ядро N2600-OS */

#include "types.h"

void  *memset(void *dst, int c, u32 n);
void  *memcpy(void *dst, const void *src, u32 n);
void  *memmove(void *dst, const void *src, u32 n);
int    memcmp(const void *a, const void *b, u32 n);
void  *memchr(const void *s, int c, u32 n);
u32    strlen(const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, u32 n);
char  *strcpy(char *dst, const char *src);
char  *strncpy(char *dst, const char *src, u32 n);
char *strchr(const char *s, int c);
char *strrchr(const char *s, int c);   /* сессия 13: ramfs mkdir */
char *strstr(const char *hay, const char *needle);

int    snprintf(char *out, u32 n, const char *fmt, ...);
int    vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

#endif /* hosted */

/* чтение следующего UTF-8 символа (1-2 байта; 3+ байта -> '?').
   Возвращает кодовую позицию, сдвигает *ps. */
unsigned utf8_next(const char **ps);

#endif /* STRING_H */
