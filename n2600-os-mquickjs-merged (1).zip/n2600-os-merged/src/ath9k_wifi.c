/* ath9k_wifi.c — драйвер Atheros WiFi (порт Linux ath9k, GPLv2) для N2600-OS.
 *
 * Поддерживаемые чипы (PCI vendor 0x168c):
 *   AR9285 (002b), AR9287 (002e) — семейство Owl
 *   AR9485 (0032)                — семейство Sowl (AR9003)
 *
 * СЕССИЯ 28: чипо-независимая часть (журнал, скан, beacon-парсер,
 * машина подключения, WPA2-PSK, мост 802.11<->Ethernet) вынесена в
 * wifi_core.c — здесь остался только «железный» код: probe PCI,
 * bring-up (reset/PLL/ini/калибровки), DMA RX, TX-дескрипторы,
 * keycache, смена канала. Драйвер регистрирует wifi_hw_ops_t через
 * wifi_core_bind() (см. ath9k_wifi_probe в конце файла).
 *
 * Приём — polling (без прерываний): wifi_poll() из главного цикла.
 * Подробный журнал этапов доступен приложению WiFi и dmesg (wifi_log_tail).
 *
 * Источник: Linux (GPLv2) drivers/net/wireless/ath/ath9k/. Лицензия GPL.
 */
#include "ath9k_wifi.h"
#include "wifi_core.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "kernel.h"
#include "sync.h"
#include "ath9k_ini_data.h"
#include "wpa2.h"

extern void serial_puts(const char *s);
extern int  snprintf(char *out, u32 n, const char *fmt, ...);
extern int  vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* ================= регистры (сверены с reg.h/mac.h Linux ath9k) ================= */

/* MAC DMA / global */
#define AR_CR               0x0008
#define AR_CR_RXE_OWL       0x00000004    /* pre-AR9003 */
#define AR_CR_RXE_SOWL      0x0000000C    /* AR9003+ */
#define AR_CR_RXD           0x00000020
#define AR_RXDP             0x000C        /* RX desc pointer (owl) */
#define AR_HP_RXDP          0x0074        /* EDMA HP FIFO (sowl) */
#define AR_LP_RXDP          0x0078        /* EDMA LP FIFO (sowl) */
#define AR_CFG              0x0014
#define AR_CFG_AP_ADHOC_IND 0x00000020
#define AR_IER              0x0024        /* global int enable (0 = тишина) */
#define AR_ISR              0x0080
#define AR_TXCFG            0x0030
#define AR_RXCFG            0x0034
#define AR_DATABUF_SIZE     0x0060
#define AR_GTXTO            0x0064
#define AR_CST              0x006C
#define AR_RXFIFO_CFG       0x8114
#define AR_D0_QCUMASK       0x1000

#define AR_RC               0x4000        /* bus reset (pre-AR9003) */
#define AR_RC_AHB           0x00000001
#define AR_WA               0x4004        /* AR9003+ work-around */
#define AR_SREV_REG         0x4020
#define AR_AHB_MODE         0x4024
#define AR_AHB_PREFETCH     0x00000004
#define AR_GPIO_IN_EN_VAL   0x4054
#define AR_GPIO_JTAG_DIS    0x00020000
#define AR_OBS              0x4080

/* RTC (Owl/AR9003 merged MAC: absolute offset от BAR0) */
#define AR_RTC_RC           0x7000
#define AR_RTC_RC_MAC_WARM  0x00000001
#define AR_RTC_RC_MAC_COLD  0x00000002
#define AR_RTC_PLL_CONTROL  0x7014
#define AR_RTC_RESET        0x7040
#define AR_RTC_RESET_EN     0x00000001
#define AR_RTC_STATUS       0x7044
#define AR_RTC_STATUS_M     0x0000000f
#define AR_RTC_STATUS_ON    0x00000002
#define AR_RTC_SLEEP_CLK    0x7048
#define AR_RTC_FORCE_DERIVED_CLK 0x2
#define AR_RTC_FORCE_WAKE   0x704c
#define AR_RTC_FORCE_WAKE_EN     0x00000001
#define AR_RTC_FORCE_WAKE_ON_INT 0x00000002

/* PCU */
#define AR_STA_ID0          0x8000
#define AR_STA_ID1          0x8004
#define AR_STA_ID1_STA_AP       0x00010000
#define AR_STA_ID1_ADHOC        0x00020000
#define AR_STA_ID1_PWR_SAV      0x00040000
#define AR_STA_ID1_KSRCH_MODE   0x10000000
#define AR_STA_ID1_PRES_SEQNUM  0x20000000
#define AR_BSS_ID0          0x8008
#define AR_BSS_ID1          0x800C
#define AR_RX_FILTER        0x803C
#define AR_MCAST_FIL0       0x8040
#define AR_MCAST_FIL1       0x8044
#define AR_DIAG_SW          0x8048
#define AR_DIAG_RX_DIS      0x00000020
#define AR_DIAG_RX_ABORT    0x02000000
#define AR_DEF_ANTENNA      0x8058
#define AR_2040_MODE        0x8318
#define AR_SELFGEN_MASK     0x832c
#define AR_PCU_MISC_MODE2   0x8344
#define AR_PCU_MM2_ADHOC_KEYID  0x00000040
#define AR_PCU_MM2_CFP_IGNORE   0x00000080
#define AR_PCU_MM2_HWWAR1       0x00100000
#define AR_AGG_WEP_ENABLE_FIX   0x00000008
#define AR_AGG_WEP_ENABLE       0x00020000

#define RXF_UCAST   0x00000001
#define RXF_MCAST   0x00000002
#define RXF_BCAST   0x00000004
#define RXF_CONTROL 0x00000008
#define RXF_BEACON  0x00000010
#define RXF_PROM    0x00000020

/* PHY (Owl) */
#define AR_PHY_TURBO        0x9804
#define AR_PHY_FC_DYN2040_EN    0x00000008
#define AR_PHY_FC_HT_EN         0x00000040
#define AR_PHY_FC_SHORT_GI_40   0x00000080
#define AR_PHY_FC_WALSH         0x00000100
#define AR_PHY_FC_SINGLE_LTF1   0x00000200
#define AR_PHY_FC_DAC_FIFO      0x00000800
#define AR_PHY_TIMING3      0x9814
#define AR_PHY_TIMING3_DSC_MAN  0xFFFE0000
#define AR_PHY_TIMING3_DSC_MAN_S 17
#define AR_PHY_TIMING3_DSC_EXP  0x0001E000
#define AR_PHY_TIMING3_DSC_EXP_S 13
#define AR_PHY_ACTIVE       0x981C
#define AR_PHY_ACTIVE_EN    0x00000001
#define AR_PHY_ADC_CTL      0x982C
#define AR_PHY_ADC_OFF_PWDADC 0x00008000
#define AR_PHY_ADC_SERIAL_CTL 0x9830
#define AR_PHY_SEL_EXT_RADIO  0x00000001
#define AR_AGC_CTL_OWL      0x9860
#define AR_PHY_CCA          0x9864
#define AR_PHY_SYNTH_CONTROL 0x9874
#define AR_PHY_RX_DELAY     0x9914
#define AR_PHY_RX_DELAY_MSK 0x00003FFF
#define AR_PHY_HALFGI       0x99D0
#define AR_PHY_HALFGI_DSC_MAN 0x0007FFF0
#define AR_PHY_HALFGI_DSC_MAN_S 4
#define AR_PHY_HALFGI_DSC_EXP 0x0000000F
#define AR_PHY_HALFGI_DSC_EXP_S 0
#define AR_PHY_RFBUS_REQ   0x997C
#define AR_PHY_RFBUS_GRANT 0x9C20
#define AR_PHY_RX_CHAINMASK 0x99a4
#define AR_PHY_MODE         0xA200
#define AR_PHY_MODE_DYNAMIC 0x04
#define AR_PHY_CCK_TX_CTRL  0xA204
#define AR_PHY_CCK_JAPAN    0x00000010
#define AR_PHY_FORCE_CLKEN_CCK 0xA22C
#define AR_PHY_CCK_MRC_MUX  0x00000040
#define AR_PHY_TPCRG1       0xA258
#define AR_PHY_TPCRG1_PD_CAL 0x00400000
#define AR_PHY_CL_CAL_CTL   0xA358
#define AR_PHY_CL_CAL_EN    0x00000002
#define AR_PHY_PAR_CAL_EN   0x00000001
#define AR_PHY_CAL_CHAINMASK 0xA39C

/* AGC_CONTROL bits (общие для семейств) */
#define AGC_CAL         0x00000001
#define AGC_NF          0x00000002
#define AGC_ENABLE_NF   0x00008000
#define AGC_FLTR_CAL    0x00010000
#define AGC_NO_UPDATE_NF 0x00020000

/* PHY (AR9003/Sowl) */
#define AR_AGC_CTL_SOWL    0xa2c4
#define AR_PHY_GEN_CTRL    0xa204   /* AR_SM_BASE(0xa200)+4 — в Owl тут CCK_TX_CTRL */
#define AR_PHY_GC_GF_DETECT 0x00000400
#define AR_PHY_CCA_0_SOWL  0x9e1c   /* AR_AGC_BASE(0x9e00)+0x1c */
#define AR_PHY_65NM_SYNTH4 0x1608c
#define AR_PHY_65NM_SYNTH7 0x16098
#define AR_PHY_SYNTH4_LONG_SHIFT 0x00000002  /* bit 1 (AR9485) */

/* BB DPLL (Sowl) */
#define AR_CH0_BB_DPLL1    0x16180
#define AR_DPLL1_REFDIV    0xF8000000
#define AR_DPLL1_REFDIV_S  27
#define AR_DPLL1_NINI      0x07FC0000
#define AR_DPLL1_NINI_S    18
#define AR_DPLL1_NFRAC     0x0003FFFF
#define AR_CH0_BB_DPLL2    0x16184
#define AR_DPLL2_LOCAL_PLL 0x40000000
#define AR_DPLL2_LOCAL_S   30
#define AR_DPLL2_KI        0x3C000000
#define AR_DPLL2_KI_S      26
#define AR_DPLL2_KD        0x03F80000
#define AR_DPLL2_KD_S      19
#define AR_DPLL2_EN_NEGTRIG 0x00040000
#define AR_DPLL2_EN_NEGTRIG_S 18
#define AR_DPLL2_PLL_PWD   0x00010000
#define AR_DPLL2_PLL_PWD_S 16
#define AR_DPLL2_OUTDIV    0x0000E000
#define AR_DPLL2_OUTDIV_S  13
#define AR_CH0_BB_DPLL3    0x16188
#define AR_DPLL3_PHASE     0x3F800000
#define AR_DPLL3_PHASE_S   23

/* ================= конфигурация драйвера ================= */

#define WIFI_NUM_RXDESC   16        /* кольцо дескрипторов (owl) */
#define WIFI_RXBUF_SZ     2408      /* 2344 (max 802.11) + запас */
#define WIFI_EDMA_ST_LEN  44        /* sizeof(ar9003_rxs) */
#define WIFI_EDMA_BUFS    4         /* буферов на очередь (sowl) */
#define WIFI_TS_RING      8         /* записей TX-статуса (sowl, сессия 15) */
#define WIFI_EDMA_QUEUES  2         /* HP + LP */
#define WIFI_SCAN_DWELL   110       /* мс на канал (сессия 33: 1 тик = 1 мс) */
#define WIFI_LOG_LINES    28
#define WIFI_LOG_LINE     96
#define AH_WAIT_TIMEOUT_US 10000    /* как AH_WAIT_TIMEOUT в ath9k */

/* ---- TX (сессия 11): очередь QCU/DCU 0 + дескрипторы AR5416 ---- */
#define AR_Q0_TXDP          0x0800
#define AR_QTXDP(q)         (AR_Q0_TXDP + ((u32)(q) << 2))
#define AR_Q_TXE            0x0840
#define AR_Q_TXE_M          0x000003FF
#define AR_Q_TXD            0x0880
#define AR_Q0_MISC          0x09c0
#define AR_QMISC(q)         (AR_Q0_MISC + ((u32)(q) << 2))
#define AR_Q_MISC_DCU_EARLY_TERM_REQ 0x00000800

#define AR_D0_QCUMASK       0x1000
#define AR_DQCUMASK(q)      (AR_D0_QCUMASK + ((u32)(q) << 2))
#define AR_D_QCUMASK        0x000003FF
#define AR_D0_LCL_IFS       0x1040
#define AR_DLCL_IFS(q)      (AR_D0_LCL_IFS + ((u32)(q) << 2))
#define AR_D_LCL_IFS_CWMIN      0x000003FF
#define AR_D_LCL_IFS_CWMIN_S    0
#define AR_D_LCL_IFS_CWMAX      0x000FFC00
#define AR_D_LCL_IFS_CWMAX_S    10
#define AR_D_LCL_IFS_AIFS       0x0FF00000
#define AR_D_LCL_IFS_AIFS_S     20
#define AR_D0_RETRY_LIMIT   0x1080
#define AR_DRETRY_LIMIT(q)  (AR_D0_RETRY_LIMIT + ((u32)(q) << 2))
#define AR_D_RETRY_LIMIT_FR_SH       0x0000000F
#define AR_D_RETRY_LIMIT_FR_SH_S     0
#define AR_D_RETRY_LIMIT_STA_SH      0x00003F00
#define AR_D_RETRY_LIMIT_STA_SH_S    8
#define AR_D_RETRY_LIMIT_STA_LG      0x000FC000
#define AR_D_RETRY_LIMIT_STA_LG_S    14
#define AR_D0_MISC          0x1100
#define AR_DMISC(q)         (AR_D0_MISC + ((u32)(q) << 2))
#define AR_D_MISC_FRAG_WAIT_EN      0x00000100
#define AR_D_MISC_CW_BKOFF_EN       0x00001000
#define AR_D_MISC_BKOFF_THRESH      0x0000003F

/* INIT-константы mac.h эталона: AIFS=2, CWMIN=15, CWMAX=1023, SSH=32, SLG=32 */
#define AT_INIT_AIFS      2
#define AT_INIT_CWMIN     15
#define AT_INIT_CWMAX     1023
#define AT_INIT_SSH_RETRY 32
#define AT_INIT_SLG_RETRY 32

/* ---- дескриптор AR5416 (owl): layout 1:1 из mac.h struct ar5416_desc ---- */
typedef struct {
    u32 link;
    u32 data;
    u32 ctl0, ctl1, ctl2, ctl3, ctl4, ctl5, ctl6, ctl7, ctl8, ctl9, ctl10, ctl11;
    u32 st[10];    /* tx status 0..9 (пишет железо) */
} owl_txdesc_t;    /* 96 байт */

/* ===================== TX для AR9003/AR9485 (СЕССИЯ 15) =====================
 * AR9485 (sowl) — семейство ar9003: ДРУГОЙ формат TX-дескриптора
 * (24 слова + pad до кэш-линии 128 байт) и статусное КОЛЬЦО вместо
 * статуса в самом дескрипторе. Layout 1:1 из ar9003_mac.h эталона
 * (struct ar9003_txc / struct ar9003_txs):
 *   info  = (0x168c<<16) | TxRxDesc(15) | CtrlStat(14) | (qcu<<8) | 0x17
 *   ctl3  = buf_len << 16;  ctl10 = чексумма (info+link+data0+ctl3+...)
 *   ctl11 = FrameLen | XmitPower0 | DestIdxValid | RTS/CTS
 *   ctl12 = DestIdx | FrameType | NoAck
 *   ctl13 = tries 0..3;  ctl14 = rate 0..3;  ctl17 = EncrType (биты 26-27)
 *   ctl19 = Not_Sounding (всегда — не TxBF)
 * Статус: железо пишет sowl_txs_t в кольцо [AR_Q_STATUS_RING_START..END),
 * готовность = status8 bit0 (AR_TxDone), успех = status3 bit0
 * (AR_FrmXmitOK); после чтения запись чистится (как
 * ath9k_hw_clear_txstatus). Кольцо программируется ДО включения
 * очередей: ath9k_hw_reset_txstatus_ring. */
typedef struct {
    u32 info;     /* дескриптор: DescId|TxRxDesc|CtrlStat|TxQcuNum|desc_len */
    u32 link;     /* 0 = конец списка */
    u32 data0;    /* буфер кадра (физ. = лин. адрес) */
    u32 ctl3;     /* buf_len[27:16] */
    u32 data1, ctl5, data2, ctl7, data3, ctl9;   /* 0: один буфер на кадр */
    u32 ctl10;    /* контрольная сумма указателей (16 бит) */
    u32 ctl11;    /* FrameLen | XmitPower0 | DestIdxValid | RTS/CTS */
    u32 ctl12;    /* DestIdx | FrameType | NoAck */
    u32 ctl13;    /* XmitDataTries 0..3 | DurUpdateEna */
    u32 ctl14;    /* XmitRate 0..3 */
    u32 ctl15, ctl16;  /* PacketDur 0..3 (RTS/CTS; без RTS = 0) */
    u32 ctl17;    /* EncrType (биты 26-27): 0=CLR, 2=AES(CCMP) */
    u32 ctl18;    /* rate flags / ChainSel / RTSCTSRate (0 = legacy) */
    u32 ctl19;    /* Not_Sounding */
    u32 ctl20, ctl21, ctl22, ctl23;   /* XmitPower 1..3 (0) */
    u32 pad[8];   /* до 128 байт (кэш-линия) */
} sowl_txdesc_t;   /* 128 байт */

typedef struct {
    u32 info;     /* DescId|TxRxDesc|TxQcuNum */
    u32 status1;  /* TxDescId */
    u32 status2;  /* RSSI ctl0-2 / BaStatus */
    u32 status3;  /* FrmXmitOK | ExcessiveRetries | Filtered | DataFailCnt */
    u32 status4;  /* timestamp */
    u32 status5, status6;   /* BA bitmap low/high */
    u32 status7;  /* RSSI combined */
    u32 status8;  /* TxDone | FinalTxIdx | SeqNum | TxTid */
} sowl_txs_t;     /* 36 байт */

/* биты TX-статуса ar9003 (mac.h эталона; имена TXS_* не конфликтуют) */
#define TXS3_FrmXmitOK        0x00000001u
#define TXS3_ExcessiveRetries 0x00000002u
#define TXS3_Filtered         0x00000008u
#define TXS8_TxDone           0x00000001u
/* AR_Q_STATUS_RING_START/END (reg.h эталона, 0x830/0x834):
 * END = адрес ЗА последней записью кольца */
#define AR_Q_STATUS_RING_START 0x0830
#define AR_Q_STATUS_RING_END   0x0834

/* ctl0 */
#define TXD_FrameLen       0x00000FFF
#define TXD_XmitPower0     0x003F0000
#define TXD_XmitPower0_S   16
/* ctl1 */
#define TXD_TxMore         0x00001000
#define TXD_FrameType      0x00F00000
#define TXD_FrameType_S    20
#define TXD_NoAck          0x01000000
/* ctl2 */
#define TXD_XmitDataTries0 0x000F0000
#define TXD_XmitDataTries0_S 16
#define TXD_XmitDataTries1 0x00F00000
#define TXD_XmitDataTries1_S 20
#define TXD_XmitDataTries2 0x0F000000
#define TXD_XmitDataTries2_S 24
#define TXD_XmitDataTries3 0xF0000000
#define TXD_XmitDataTries3_S 28
#define TXD_DurUpdateEna   0x00008000
/* ctl3 */
#define TXD_XmitRate0      0x000000FF
#define TXD_XmitRate0_S    0
#define TXD_XmitRate1      0x0000FF00
#define TXD_XmitRate1_S    8
#define TXD_XmitRate2      0x00FF0000
#define TXD_XmitRate2_S    16
#define TXD_XmitRate3      0xFF000000
#define TXD_XmitRate3_S    24
/* status */
#define TXS_FrmXmitOK      0x00000001   /* st[1] */
#define TXS_ExcessiveRetries 0x00000002
#define TXS_Filtered       0x00000008
#define TXS_TxDone         0x00000001   /* st[9] */
/* сессия 12 (WPA2): шифрование в TX-дескрипторе (mac.h эталона):
 * ctl1: DestIdx (биты 13-17) + DestIdxValid (бит 30) — запись keycache;
 * ctl6: EncrType (биты 26-27): 0=CLR, 1=WEP, 2=AES(CCMP), 3=TKIP */
#define TXD_DestIdx        0x000FE000
#define TXD_DestIdx_S      13
#define TXD_DestIdxValid   0x40000000
#define TXD_EncrType       0x0C000000   /* ctl6 */
#define TXD_EncrType_S     26
#define TXD_ENCR_AES       2
#define TXD_ENCR_TKIP      3   /* ctl6 EncrType: 3 = TKIP (сессия 25) */

/* ---- keycache (сессия 12: WPA2-CCMP, рег. 0x8800+n*32) ----
 * Раскладка как в ath_key.c (hostap): KEY0..KEY4 — ключ с
 * «рваными» словами (KEY1/KEY3 — 16-битные!), TYPE = CCM(6),
 * MAC0/MAC1 — адрес, сдвинутый вправо на бит, + VALID(0x8000).
 * Парный ключ (PTK): запись 4 с MAC = BSSID (декодирует юникаст
 * по TA). Групповой (GTK): запись = keyid, MAC = 0 + VALID
 * (default-key: выбирается по keyid из CCMP-заголовка кадра). */
#define KC_PTK_ENTRY   4
#define AR_KEYTABLE_BASE      0x8800u
#define AR_KEYTABLE_TYPE_CCM  6u
#define AR_KEYTABLE_VALID     0x8000u

/* ---- legacy-рейты (rc.c эталона, hw-коды 5416) ---- */
#define RATE_CCK_1M        0x1B
#define RATE_CCK_2M        0x1A
#define RATE_CCK_5_5M      0x19
#define RATE_CCK_11M       0x18
#define RATE_OFDM_6M       0x0B

/* ---- EEPROM (PCI: косвенный доступ, [pci.c: ath_pci_eeprom_read]) ---- */
#define AR5416_EEPROM_OFFSET  0x2000
#define AR5416_EEPROM_S       2
#define AR_EEPROM_STAT_OWL    0x407C
#define AR_EEPROM_STAT_SOWL   0x4084
#define EEST_BUSY             0x00010000
#define EEST_PROT_ACCESS      0x00040000
#define EEST_VAL              0x0000FFFF

/* ---- 802.11 ---- */
#define WIFI_TX_QUEUE      0          /* QCU/DCU 0 (данные) */
#define WIFI_TXBUF_SZ      2360       /* 24 hdr + LLC/SNAP 8 + 1500 + запас */
#define WIFI_NET_RXQ       8          /* кадров Ethernet в кольце к net.c */
#define WIFI_NET_RXSZ      1600
/* тайминги ассоциации (тики = мс при 1000 Гц, сессия 33) */
#define CONN_4WAY_TO     5000  /* 5 с на шаг рукопожатия */
#define CONN_MAX_4WAY    3     /* попыток рукопожатия */
#define CONN_AUTH_TO       600         /* 600 мс на попытку AUTH/ASSOC */
#define CONN_MAX_ATTEMPTS  3
#define CONN_SCAN_TRIES    3          /* проходов скана при поиске сети */
#define CONN_BEACON_LOST   6000       /* 6 с без маяков = связь потеряна */

typedef enum { CHIP_NONE = 0, CHIP_AR9285, CHIP_AR9287, CHIP_AR9485 } wifi_chip_t;

/* RX-дескриптор AR5416 (owl): layout 1:1 из mac.h struct ar5416_desc.
 * status: st[0]=RSSIAnt00/01/02+rate, st[1]=DataLen+More, st[4]=RSSICombined,
 * st[8]=Done/FrameOK/CRCErr/PHYErr... */
typedef struct {
    u32 link;    /* следующий дескриптор (физ. адрес) */
    u32 data;    /* буфер (физ. адрес) */
    u32 ctl0;
    u32 ctl1;    /* BufLen (0xFFF) */
    u32 st[9];   /* RX status 0..8 (пишет железо) */
} owl_rxdesc_t;  /* 52 байта */

typedef struct {
    int      present;
    u32      mmio_base;
    u16      pci_devid;
    wifi_chip_t chip;
    u32      srev_raw;
    int      ready;          /* bring-up завершён успешно */
    int      clk25;          /* AR9485: опорник 25 МГц (влияет на synth) */
    int      is_sowl;        /* семейство AR9003 */
    u8       mac[6];         /* наш MAC (из EEPROM) */

    /* ---- TX (owl): один дескриптор + буфер, передача по одному кадру ---- */
    void        *txdesc_raw;
    owl_txdesc_t *txdesc;    /* выровненный */
    u8          *txbuf;      /* буфер кадра 802.11 (без статуса) */
    volatile int tx_lock;

    /* ---- TX (sowl/AR9485): дескриптор ar9003 + статусное кольцо ---- */
    void          *stxdesc_raw;
    sowl_txdesc_t *stxdesc;          /* выровнен до 128 (кэш-линия) */
    u8            *stxbuf;
    void          *tsring_raw;
    sowl_txs_t    *tsring;           /* WIFI_TS_RING записей, выровнено */
    int            ts_tail;          /* след. запись статуса (наша) */

    /* RX (owl): кольцо дескрипторов */
    void         *rxdesc_raw;
    owl_rxdesc_t *rxdesc;                  /* выровненная база */
    void         *rxbuf_raw[WIFI_NUM_RXDESC];
    u8           *rxbuf[WIFI_NUM_RXDESC];  /* выровненные буферы */
    int           rx_head;

    /* RX (sowl): EDMA FIFO — буферы, буфер = [статус 44 б][кадр] */
    u8 *edbuf[WIFI_EDMA_QUEUES][WIFI_EDMA_BUFS];
    int ed_head[WIFI_EDMA_QUEUES];

    /* rx-арбитраж: kmain и приложение читают одновременно */
    volatile int rx_lock;
} ath9k_t;

static ath9k_t ath;

static const char *ath_bringup(void);
static int ath_fastcc(int ch_idx);
static int ath_gtk_is_tkip;   /* GTK TKIP -> EncrType TX-дескриптора (set в keys_install) */

/* частоты 2.4 ГГц — общий wc_channel_freq (wifi_core.h) */
#define channel_freq wc_channel_freq
#define NUM_CHANNELS WC_NUM_CHANNELS

/* ================= MMIO / задержки ================= */

static inline u32 reg32(u32 addr) {
    return *(volatile u32 *)(unsigned long)(ath.mmio_base + addr);
}
static inline void regw(u32 addr, u32 val) {
    *(volatile u32 *)(unsigned long)(ath.mmio_base + addr) = val;
}
static inline void reg_set(u32 addr, u32 bits) { regw(addr, reg32(addr) | bits); }
static inline void reg_clr(u32 addr, u32 bits) { regw(addr, reg32(addr) & ~bits); }
static inline void reg_rmw(u32 addr, u32 set, u32 clr) {
    regw(addr, (reg32(addr) & ~clr) | set);
}
static inline void reg_rmw_field(u32 addr, u32 mask, u32 shift, u32 val) {
    regw(addr, (reg32(addr) & ~mask) | ((val << shift) & mask));
}

/* io-задержка через порт 0x80. Скорость inb(0x80) сильно зависит от
 * платформы (от ~150 нс на современных чипсетах до ~1 мкс на старых),
 * а аналоговые сдвиговые регистры 0x7800..0x78a0 требуют честные
 * 100 мкс между записями — иначе радио запрограммировано «частично»
 * и приёмник глухой. Поэтому задержка КАЛИБРУЕТСЯ по PIT каналу 2
 * (свободен; тикает с фиксированной частотой 1.193182 МГц).
 * Калибровка работает и до sti() — нужен только latch-чтение счётчика. */
static volatile u32 g_io_per_us = 3;   /* итераций inb(0x80) на 1 мкс */

static u16 pit2_count(void) {
    outb(0x43, 0x80);                  /* latch канал 2 */
    return (u16)(inb(0x42) | (inb(0x42) << 8));
}

static void w_udelay_calibrate(void) {
    u8 p61 = inb(0x61);
    outb(0x61, (p61 | 0x01) & ~0x02);  /* GATE2=1, динамик выкл */
    outb(0x43, 0xB4);                  /* канал 2, режим 2, binary */
    outb(0x42, 0xFF); outb(0x42, 0xFF);/* делитель 65535 */

    u32 best = 0;
    for (int s = 0; s < 4; s++) {
        u32 n = 2000;
        u16 t0 = pit2_count();
        for (u32 i = 0; i < n; i++) (void)inb(0x80);
        u16 t1 = pit2_count();
        u32 dt = (u32)((t0 - t1) & 0xFFFF);
        if (dt < 8 || dt > 60000) continue;   /* глюк чтения */
        /* dt тиков * 0.838 нс/тик = прошло мкс; итераций/мкс = n/dt*1.193 */
        u32 per_us = (u32)(((u64)n * 1193182u) / 1000000u / dt);
        if (per_us > best) best = per_us;
    }
    outb(0x61, p61);                   /* вернуть GATE2 */

    if (best == 0) best = 8;           /* PIT молчит — консервативно */
    if (best > 2000) best = 2000;
    g_io_per_us = best + 1;            /* +1: небольшой запас */
    {
        char b[64];
        snprintf(b, sizeof(b), "калибровка задержек: %u итераций/мкс", (unsigned)best);
        wifi_log("%s", b);
    }
}

static void w_udelay(int us) {
    if (us <= 0) return;
    volatile u32 n = (u32)us * g_io_per_us;
    while (n-- > 0) (void)inb(0x80);
}

/* ожидание условия в регистре (аналог ath9k_hw_wait) */
static int hw_wait(u32 addr, u32 mask, u32 val, u32 timeout_us) {
    u32 t = 0;
    while ((reg32(addr) & mask) != val) {
        w_udelay(10);
        t += 10;
        if (t >= timeout_us) return 0;
    }
    return 1;
}

/* задержка стабилизации синтезатора: RX_DELAY в единицах 100 нс
 * [hw.c: ath9k_hw_synth_delay — hw_delay/10 + BASE_ACTIVATE_DELAY(100)] */
static void synth_delay_wait(void) {
    u32 d = reg32(AR_PHY_RX_DELAY) & AR_PHY_RX_DELAY_MSK;
    w_udelay((int)d / 10 + 100);
}

/* ================= power-on / reset (RTC) ================= */

/* Пробуждение RTC + cold/warm reset MAC [hw.c: ath9k_hw_set_reset_power_on
 * и ath9k_hw_set_reset]. Возвращает 0 при успехе, иначе код-строка. */
static const char *ath_reset(int cold) {
    /* AR9003+: регистр work-around перед сбросом */
    if (ath.is_sowl) {
        u32 wa = reg32(AR_WA) | (1 << 14) | (1 << 17);
        regw(AR_WA, wa);
        w_udelay(10);
    }

    regw(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN | AR_RTC_FORCE_WAKE_ON_INT);
    if (!ath.is_sowl) {
        regw(AR_RC, AR_RC_AHB);       /* AHB reset (pre-AR9003) */
        regw(AR_RTC_RESET, 0);
        w_udelay(2);
        regw(AR_RC, 0);
        regw(AR_RTC_RESET, AR_RTC_RESET_EN);
        if (!hw_wait(AR_RTC_STATUS, AR_RTC_STATUS_M, AR_RTC_STATUS_ON,
                     AH_WAIT_TIMEOUT_US))
            return "RTC не просыпается (power-on)";
    }

    /* warm/cold reset через RTC_RC */
    regw(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN | AR_RTC_FORCE_WAKE_ON_INT);
    if (!ath.is_sowl) regw(AR_RC, AR_RC_AHB);
    u32 rst = AR_RTC_RC_MAC_WARM | (cold ? AR_RTC_RC_MAC_COLD : 0);
    regw(AR_RTC_RC, rst);
    w_udelay(ath.is_sowl ? 50 : 100);
    regw(AR_RTC_RC, 0);
    if (!hw_wait(AR_RTC_RC, 0x3, 0, AH_WAIT_TIMEOUT_US))
        return "RTC_RC залип в reset";
    if (!ath.is_sowl) regw(AR_RC, 0);
    return 0;
}

/* [hw.c: ath9k_hw_set_power_awake] */
static const char *ath_power_awake(void) {
    reg_set(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN);
    w_udelay(50);
    for (int i = 0; i < 200; i++) {           /* до 10 мс */
        if ((reg32(AR_RTC_STATUS) & AR_RTC_STATUS_M) == AR_RTC_STATUS_ON)
            break;
        w_udelay(50);
        reg_set(AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN);
    }
    if ((reg32(AR_RTC_STATUS) & AR_RTC_STATUS_M) != AR_RTC_STATUS_ON)
        return "не выходит из sleep";
    reg_clr(AR_STA_ID1, AR_STA_ID1_PWR_SAV);
    return 0;
}

/* [hw.c: ath9k_hw_init_pll] — 2.4 ГГц, HT20 */
static void ath_init_pll(void) {
    if (ath.chip == CHIP_AR9485) {
        /* BB DPLL: ki=0x4, kd=0x40, refdiv=5, nini=0x58, nfrac=0,
         * outdiv=1, local_pll=1, en_negtrig=1, phase=0x6 */
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_PLL_PWD, AR_DPLL2_PLL_PWD_S, 1);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_KD, AR_DPLL2_KD_S, 0x40);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_KI, AR_DPLL2_KI_S, 0x4);
        reg_rmw_field(AR_CH0_BB_DPLL1, AR_DPLL1_REFDIV, AR_DPLL1_REFDIV_S, 0x5);
        reg_rmw_field(AR_CH0_BB_DPLL1, AR_DPLL1_NINI, AR_DPLL1_NINI_S, 0x58);
        reg_rmw_field(AR_CH0_BB_DPLL1, AR_DPLL1_NFRAC, 0, 0);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_OUTDIV, AR_DPLL2_OUTDIV_S, 0x1);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_LOCAL_PLL, AR_DPLL2_LOCAL_S, 0x1);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_EN_NEGTRIG, AR_DPLL2_EN_NEGTRIG_S, 0x1);
        reg_rmw_field(AR_CH0_BB_DPLL3, AR_DPLL3_PHASE, AR_DPLL3_PHASE_S, 0x6);
        reg_rmw_field(AR_CH0_BB_DPLL2, AR_DPLL2_PLL_PWD, AR_DPLL2_PLL_PWD_S, 0);
        w_udelay(1000);
    }
    /* PLL 2.4 ГГц: refdiv=5, div=0x2c → 0x142C (формула одинакова для
     * ar9002 [ar9002_hw_compute_pll_control] и ar9003) */
    regw(AR_RTC_PLL_CONTROL, (5u << 10) | 0x2cu);
    if (ath.chip == CHIP_AR9485) w_udelay(1000);
    w_udelay(100);
    regw(AR_RTC_SLEEP_CLK, AR_RTC_FORCE_DERIVED_CLK);
}

/* ================= применение ini-массивов ================= */

/* Запись массива с задержками как в эталоне: DO_DELAY (каждые 64 записи
 * udelay(1)) и 100 мкс на аналоговые регистры 0x7800..0x78a0
 * (analog shift reg — Owl). [ar5008_phy.c: ar5008_hw_process_ini] */
#define INI_WRITE(arr, col) \
    ini_write((const u32 *)(arr), \
              (int)(sizeof(arr) / sizeof((arr)[0])), \
              (int)(sizeof((arr)[0]) / sizeof(u32)), (col))

static void ini_write(const u32 *arr, int rows, int ncols, int col) {
    int writes = 0;
    for (int i = 0; i < rows; i++) {
        u32 r = arr[i * ncols];
        u32 v = arr[i * ncols + col];
        regw(r, v);
        if (r >= 0x7800 && r < 0x78a0) w_udelay(100);   /* analog shift */
        if (++writes % 64 == 0) w_udelay(1);
    }
}

/* Owl (AR9285/AR9287): process_ini для 2.4 ГГц HT20 → колонка 4.
 * ADDAC-массив для AR9285/9287 не используется (только до AR9160),
 * но финальное состояние ADC_SERIAL_CTL — как в эталоне: INTERNAL_ADDAC. */
static const char *owl_process_ini(void) {
    regw(0x9800, 0x00000007);              /* AR_PHY(0): доступ к аналог. чипам */
    regw(AR_PHY_ADC_SERIAL_CTL, AR_PHY_SEL_EXT_RADIO);
    regw(AR_PHY_ADC_SERIAL_CTL, 0);        /* SEL_INTERNAL_ADDAC (как эталон) */

    if (ath.chip == CHIP_AR9285) {
        INI_WRITE(ar9285Modes_9285_1_2, 4);
        INI_WRITE(ar9285Modes_original_tx_gain_9285_1_2, 4);
        INI_WRITE(ar9285Common_9285_1_2, 1);
    } else {
        /* AR9287: modes + common + RX gain + TX gain (колонка 4) */
        INI_WRITE(ar9287Modes_9287_1_1, 4);
        INI_WRITE(ar9287Modes_rx_gain_9287_1_1, 4);
        INI_WRITE(ar9287Modes_tx_gain_9287_1_1, 4);
        INI_WRITE(ar9287Common_9287_1_1, 1);
        /* CCK FIR коэффициенты: обычные (2412-2472) / Япония (2484)
         * ставятся при выборе канала — по умолчанию normal */
        INI_WRITE(ar9287Common_normal_cck_fir_coeff_9287_1_1, 1);
    }
    return 0;
}

/* Sowl (AR9485): порядок ar9003_hw_process_ini — цикл по группам
 * PRE→CORE→POST, в каждой SOC→MAC→BB→RADIO [ar9003_hw.c: init_mode_regs
 * + ar9003_phy.c: process_ini]. Колонка 4 = 2.4 ГГц HT20. */
static const char *sowl_process_ini(void) {
    /* PRE: SOC preamble + BB pre */
    INI_WRITE(ar9485_1_1_soc_preamble, 1);
    INI_WRITE(ar9485_1_1, 1);
    /* CORE: MAC + BB + Radio */
    INI_WRITE(ar9485_1_1_mac_core, 1);
    INI_WRITE(ar9485_1_1_baseband_core, 1);
    INI_WRITE(ar9485_1_1_radio_core, 1);
    /* POST: MAC + BB + Radio postamble */
    INI_WRITE(ar9331_1p1_mac_postamble, 4);
    INI_WRITE(ar9485_1_1_baseband_postamble, 4);
    INI_WRITE(ar9485_1_1_radio_postamble, 1);
    /* RX gain (кол.1) + TX gain (кол.4) + PCIe PHY */
    INI_WRITE(ar9485Common_wo_xlna_rx_gain_1_1, 1);
    INI_WRITE(ar9485Modes_low_ob_db_tx_gain_1_1, 4);
    INI_WRITE(ar9485_1_1_pcie_phy_clkreq_disable_L1, 1);
    return 0;
}

/* ================= канал / PHY ================= */

/* [ar5008_phy.c: ar5008_hw_override_ini] — RX_DIS/RX_ABORT ставим до RXE,
 * PCU_MISC_MODE2: без multicast-keyid поиска, CFP_IGNORE */
static void ath_override_ini(void) {
    reg_set(AR_DIAG_SW, AR_DIAG_RX_DIS | AR_DIAG_RX_ABORT);
    if (ath.is_sowl) {
        u32 val = reg32(AR_PCU_MISC_MODE2) & ~AR_PCU_MM2_ADHOC_KEYID;
        val |= AR_AGG_WEP_ENABLE_FIX | AR_AGG_WEP_ENABLE | AR_PCU_MM2_CFP_IGNORE;
        regw(AR_PCU_MISC_MODE2, val);
    } else {
        u32 val = reg32(AR_PCU_MISC_MODE2) & ~AR_PCU_MM2_ADHOC_KEYID;
        val &= ~AR_PCU_MM2_HWWAR1;
        val |= AR_PCU_MM2_CFP_IGNORE;
        regw(AR_PCU_MISC_MODE2, val);
    }
}

/* [ar5008_phy.c: ar5008_hw_set_channel_regs / ar9003: set_channel_regs]
 * 2.4 ГГц HT20: TURBO/GEN_CTRL = HT_EN|SHORT_GI_40|SINGLE_LTF1|WALSH */
static void ath_set_channel_regs(void) {
    if (ath.is_sowl) {
        /* сохранить INI-настройки, выключить Green Field detection */
        u32 phymode = reg32(AR_PHY_GEN_CTRL);
        phymode |= AR_PHY_FC_HT_EN | AR_PHY_FC_SHORT_GI_40 |
                   AR_PHY_FC_SINGLE_LTF1;
        phymode &= ~AR_PHY_GC_GF_DETECT;
        regw(AR_PHY_GEN_CTRL, phymode);
    } else {
        u32 phymode = AR_PHY_FC_HT_EN | AR_PHY_FC_SHORT_GI_40 |
                      AR_PHY_FC_SINGLE_LTF1 | AR_PHY_FC_WALSH;
        if (ath.chip == CHIP_AR9285) {   /* DAC FIFO бит из INI [owl-специфика] */
            phymode |= reg32(AR_PHY_TURBO) & AR_PHY_FC_DAC_FIFO;
        }
        regw(AR_PHY_TURBO, phymode);
    }
    regw(AR_2040_MODE, 0);               /* HT20 */
    regw(AR_GTXTO, 25u << 16);
    regw(AR_CST, 0xFu << 16);
}

/* [ar5008/ar9003: init_chain_masks] — AR9285/AR9485 = 1T1R.
 * СЕССИЯ 15: AR_SELFGEN_MASK пишется и для ar9003 (эталон
 * ar9003_hw_set_chain_masks пишет TX-маску в SELFGEN) — раньше для
 * sowl пропуск (RX работало и так), для TX нужна. */
static void ath_chain_masks(void) {
    regw(AR_PHY_RX_CHAINMASK, 1);
    regw(AR_PHY_CAL_CHAINMASK, 1);
    regw(AR_SELFGEN_MASK, 1);
}

/* [ar5008/ar9003: set_rfmode] — 2.4 ГГц → DYNAMIC (CCK+OFDM) */
static void ath_set_rfmode(void) {
    regw(AR_PHY_MODE, AR_PHY_MODE_DYNAMIC);
}

/* [hw.c: ath9k_hw_set_delta_slope] — целочисленно, как в эталоне */
static void ath_delta_slope(int freq) {
    u32 clock_mhz_scaled = 0x64000000u;      /* 100 МГц << 25 */
    u32 coef = clock_mhz_scaled / (u32)freq;

    /* get_delta_slope_vals */
    u32 exp;
    for (exp = 31; exp > 0; exp--)
        if ((coef >> exp) & 1) break;
    exp = 14 - (exp - 24);                  /* COEF_SCALE_S = 24 */
    u32 man = coef + (1u << (24 - exp - 1));
    man >>= (24 - exp);
    u32 ds_exp = exp - 16;
    reg_rmw_field(AR_PHY_TIMING3, AR_PHY_TIMING3_DSC_MAN, AR_PHY_TIMING3_DSC_MAN_S, man);
    reg_rmw_field(AR_PHY_TIMING3, AR_PHY_TIMING3_DSC_EXP, AR_PHY_TIMING3_DSC_EXP_S, ds_exp);

    coef = (9u * coef) / 10u;               /* short GI */
    for (exp = 31; exp > 0; exp--)
        if ((coef >> exp) & 1) break;
    exp = 14 - (exp - 24);
    man = coef + (1u << (24 - exp - 1));
    man >>= (24 - exp);
    ds_exp = exp - 16;
    reg_rmw_field(AR_PHY_HALFGI, AR_PHY_HALFGI_DSC_MAN, AR_PHY_HALFGI_DSC_MAN_S, man);
    reg_rmw_field(AR_PHY_HALFGI, AR_PHY_HALFGI_DSC_EXP, AR_PHY_HALFGI_DSC_EXP_S, ds_exp);
}

/* синтезатор: Owl [ar9002_hw_set_channel] / Sowl [ar9003_hw_set_channel] */
static void ath_set_synth(int ch_idx) {
    u32 freq = channel_freq[ch_idx];

    if (!ath.is_sowl) {
        /* CHANSEL_2G(freq) = freq * 0x10000 / CHANSEL_DIV, CHANSEL_DIV = 15
         * [phy.h: #define CHANSEL_DIV 15 — одинаково во всех ядрах v3.2..v6.1].
         * Формула: F = (3/4)*40МГц*(chansel/2^17) → chansel = F*0x10000/15.
         * ВАЖНО: раньше делили на 10 — синтезатор настраивался на 1.5× частоты
         * (канал 1 = 2412 МГц уходил на 3618 МГц!). Приёмник был ГЛУХ на
         * всех каналах: 0 кадров, 0 маяков, 0 CRC — при полностью исправной
         * остальной инициализации. */
        u32 chan_sel = (u32)freq * 0x10000u / 15u;
        u32 reg = reg32(AR_PHY_SYNTH_CONTROL) & 0xc0000000u;
        reg |= (1u << 29)        /* bMode (2 ГГц) */
             | (1u << 28)        /* fracMode */
             | (0u << 26)        /* aModeRefSel */
             | chan_sel;
        regw(AR_PHY_SYNTH_CONTROL, reg);
        /* канал 14 (Япония): channel spreading. AR9285 — бит CCK_JAPAN,
        * AR9287 — свой cckfir-массив (как в эталоне, бит не трогаем) */
        if (ath.chip == CHIP_AR9287) {
            if (freq == 2484)
                INI_WRITE(ar9287Common_japan_2484_cck_fir_coeff_9287_1_1, 1);
            else
                INI_WRITE(ar9287Common_normal_cck_fir_coeff_9287_1_1, 1);
        } else {
            if (freq == 2484) reg_set(AR_PHY_CCK_TX_CTRL, AR_PHY_CCK_JAPAN);
            else              reg_clr(AR_PHY_CCK_TX_CTRL, AR_PHY_CCK_JAPAN);
        }
    } else {
        /* AR9485: div = 120 (опорник 40 МГц) или 75 (25 МГц) */
        u32 div = ath.clk25 ? 75u : 120u;
        u32 f4 = (u32)freq * 4u;
        u32 chan_sel = (f4 / div) << 17;
        chan_sel |= ((f4 % div) * 0x20000u) / div;
        regw(AR_PHY_SYNTH_CONTROL, 1u << 29);              /* bMode */
        reg_set(AR_PHY_65NM_SYNTH4, AR_PHY_SYNTH4_LONG_SHIFT);
        u32 v = (chan_sel << 2) | (1u << 30);              /* fracMode */
        regw(AR_PHY_65NM_SYNTH7, v);
        regw(AR_PHY_65NM_SYNTH7, v | (1u << 31));          /* load synth */
    }
}

/* [ar5008/ar9003: init_bb] — активация PHY + ожидание синтезатора */
static void ath_init_bb(void) {
    regw(AR_PHY_ACTIVE, AR_PHY_ACTIVE_EN);
    synth_delay_wait();
}

/* ================= калибровки ================= */

/* CL-калибровка AR9285 [ar9002_calib.c: ar9285_hw_cl_cal, ветка HT20] */
static const char *owl_cl_cal(void) {
    reg_set(AR_PHY_CL_CAL_CTL, AR_PHY_CL_CAL_EN | AR_PHY_PAR_CAL_EN);
    reg_set(AR_PHY_TURBO, AR_PHY_FC_DYN2040_EN);
    reg_clr(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_FLTR_CAL);
    reg_clr(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_CAL);
    reg_set(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL);
    if (!hw_wait(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL, 0,
                 AH_WAIT_TIMEOUT_US))
        return "CL-калибровка (1) не завершается";
    reg_clr(AR_PHY_TURBO, AR_PHY_FC_DYN2040_EN);
    reg_clr(AR_PHY_CL_CAL_CTL, AR_PHY_PAR_CAL_EN);
    reg_clr(AR_PHY_CL_CAL_CTL, AR_PHY_CL_CAL_EN);  /* [эталон: HT20-ветка
        * снимает CL_CAL_ENABLE сразу после первой калибровки — вторая
        * (FLTR/AGC) идёт уже без carrier-leakage-триггера] */
    reg_clr(AR_PHY_ADC_CTL, AR_PHY_ADC_OFF_PWDADC);
    reg_set(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_FLTR_CAL);
    reg_set(AR_PHY_TPCRG1, AR_PHY_TPCRG1_PD_CAL);
    reg_set(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL);
    if (!hw_wait(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_CAL, 0,
                 AH_WAIT_TIMEOUT_US))
        return "CL-калибровка (2) не завершается";
    reg_set(AR_PHY_ADC_CTL, AR_PHY_ADC_OFF_PWDADC);
    reg_clr(AR_PHY_CL_CAL_CTL, AR_PHY_CL_CAL_EN);
    reg_clr(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL, AGC_FLTR_CAL);
    return 0;
}

/* AGC-калибровка AR9287 [ar9002_calib.c: ar9002_hw_init_cal, ветка 9287:
 * FLTR_CAL + AGC (без PWDADC-переключений — они не для 9287_11+)] */
static const char *kite_agc_cal(void) {
    u32 agc = AR_AGC_CTL_OWL;
    reg_set(agc, AGC_FLTR_CAL);
    reg_set(agc, AGC_CAL);
    if (!hw_wait(agc, AGC_CAL, 0, AH_WAIT_TIMEOUT_US))
        return "AGC-калибровка (9287) не завершается";
    reg_clr(agc, AGC_FLTR_CAL);
    return 0;
}

/* AGC-калибровка Sowl [ar9003_calib.c: ar9003_hw_init_cal_pcoem,
 * только RX-существенная часть: CL-toggle + AGC] */
static const char *sowl_agc_cal(void) {
    u32 agc = ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL;
    u32 rx_delay = 0;
    int have_cl = (reg32(AR_PHY_CL_CAL_CTL) & AR_PHY_CL_CAL_EN) != 0;

    ath_chain_masks();               /* для калибровки — аппаратная маска (1) */
    if (have_cl) {
        rx_delay = reg32(AR_PHY_RX_DELAY);
        regw(AR_PHY_ACTIVE, 0);      /* BB off/on вокруг CL cal [эталон] */
        w_udelay(5);
        regw(AR_PHY_RX_DELAY, AR_PHY_RX_DELAY_MSK);
        regw(AR_PHY_ACTIVE, AR_PHY_ACTIVE_EN);
    }
    reg_set(agc, AGC_CAL);
    if (!hw_wait(agc, AGC_CAL, 0, AH_WAIT_TIMEOUT_US)) {
        ath_chain_masks();
        return "AGC-калибровка не завершается";
    }
    if (have_cl) {
        regw(AR_PHY_RX_DELAY, rx_delay);
        w_udelay(5);
    }
    ath_chain_masks();               /* вернуть рабочую маску (та же 1) */
    return 0;
}

/* Запись NF (dBm) в поле [8:0] CCA-регистра — ПОЛНОСТЬЮ как в эталоне:
 * reg = (reg & ~0x1ff) | ((nfval << 1) & 0x1ff)  [calib.c: loadnf].
 * ВНИМАНИЕ: раньше здесь был двойной сдвиг (reg_rmw_field уже сдвигает,
 * а значение ещё раз умножалось на 2) — вместо -50 дБм писалось
 * -100 дБм, вместо номинала -118 — вообще +20 дБм. Порог CCA
 * оказывался НИЖЕ реального шума → CCA постоянно busy → приёмник
 * ГЛУХОЙ на всех каналах (0 кадров, 0 маяков, 0 CRC). */
static void nf_set(u32 cca_reg, int dbm) {
    regw(cca_reg, (reg32(cca_reg) & ~0x1ffu) |
                  (((u32)(i32)dbm << 1) & 0x1ffu));
}

/* Чтение NF (dBm) — поле MINCCA_PWR [28:20], 9-битное со знаком.
 * [ar9002_phy.c: ar9002_hw_do_getnf: MS(reg, AR9280_PHY_MINCCA_PWR=0x1FF00000,
 * shift 20) + sign_extend32(nf, 8); ar9003 — то же поле AR_PHY_CH_MINCCA_PWR].
 * ВАЖНО: поле [8:0] — write-only загрузка номинала (loadnf пишет туда
 * значение<<1), а железо отдаёт ИЗМЕРЕННЫЙ NF именно в [28:20], причём
 * уже в dBm — делить на 2 НЕЛЬЗЯ. Раньше читались биты [8:0] — т.е.
 * возвращалось то, что сами записали (постоянно -50), и это ещё и
 * делилось на 2. */
static int nf_get(u32 cca_reg) {
    i32 v = (i32)((reg32(cca_reg) >> 20) & 0x1ffu);
    if (v & 0x100) v -= 0x200;
    /* санитизация как в эталоне [calib.c: ath9k_hw_nf_sanitize]:
     * значения вне разумного диапазона → номинал (калибровка ещё
     * не завершилась / регистр не обновился) */
    if (v > -60 || v < -127) {
        if (ath.is_sowl) return -110;
        return (ath.chip == CHIP_AR9287) ? -112 : -118;
    }
    return v;
}

/* noise floor: загрузка номинала + запуск калибровки
 * [calib.c: ath9k_hw_loadnf + ath9k_hw_start_nfcal].
 * Для 1T1R HT20 используется только цепь 0 (CCA / CCA_0). */
static void ath_nf_load_start(void) {
    u32 agc = ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL;
    u32 cca = ath.is_sowl ? AR_PHY_CCA_0_SOWL : AR_PHY_CCA;
    int nominal = -118;                       /* AR9285 */
    if (ath.chip == CHIP_AR9287) nominal = -112;
    if (ath.is_sowl) nominal = -110;          /* AR9003 */

    u32 agc_ctl = reg32(agc);
    nf_set(cca, nominal);
    if (agc_ctl & AGC_NF) reg_clr(agc, AGC_NF);       /* прервать текущую */
    reg_clr(agc, AGC_ENABLE_NF);
    reg_clr(agc, AGC_NO_UPDATE_NF);
    reg_set(agc, AGC_NF);
    int timed_out = 1;
    for (int j = 0; j < 22200; j++) {         /* ≤ 222 мс, как в эталоне */
        if (!(reg32(agc) & AGC_NF)) { timed_out = 0; break; }
        w_udelay(10);
    }
    if (timed_out)
        wifi_log("ВНИМАНИЕ: загрузка NF не завершилась (AGC=%x)",
                 (unsigned)reg32(agc));

    /* «Вернуть максимум»: maxCCAPower = -50 дБм — это начальное (и
     * максимальное) значение следующей NF-калибровки железа. Не путать
     * с порогом CCA: именно -50 (как в эталоне), НЕ ниже! */
    nf_set(cca, -50);

    /* start_nfcal */
    reg_set(agc, AGC_ENABLE_NF);
    reg_clr(agc, AGC_NO_UPDATE_NF);
    reg_set(agc, AGC_NF);
}

/* ================= MAC / DMA конфигурация ================= */

/* [hw.c: ath9k_hw_set_dma] + init_queues (только DCU-маски) +
 * reset_opmode [hw.c: ath9k_hw_reset_opmode упрощённо для станции] */
static void ath_mac_dma_config(void) {
    /* прерывания не используем: polling; линия IRQ держится тихой */
    regw(AR_IER, 0);
    regw(AR_ISR, 0xFFFFFFFFu);

    /* режим станции: поиск станций, сохранение seqnum */
    reg_rmw(AR_STA_ID1,
            AR_STA_ID1_KSRCH_MODE | AR_STA_ID1_PRES_SEQNUM,
            AR_STA_ID1_STA_AP | AR_STA_ID1_ADHOC | AR_STA_ID1_PWR_SAV);
    reg_clr(AR_CFG, AR_CFG_AP_ADHOC_IND);
    regw(AR_DEF_ANTENNA, 1);

    /* BSSID = broadcast (сканируем все сети), multicast-фильтр открыт */
    regw(AR_BSS_ID0, 0xFFFFFFFFu);
    regw(AR_BSS_ID1, 0x0000FFFFu);
    regw(AR_MCAST_FIL0, 0xFFFFFFFFu);
    regw(AR_MCAST_FIL1, 0xFFFFFFFFu);

    /* DMA: AHB без prefetch, burst 128 байт, RX FIFO threshold */
    reg_set(AR_AHB_MODE, AR_AHB_PREFETCH);
    reg_rmw(AR_TXCFG, 5, 7);          /* DMASZ_128B */
    reg_rmw(AR_RXCFG, 5, 7);          /* DMASZ_128B */
    if (!ath.is_sowl) regw(AR_RXFIFO_CFG, 0x200);
    for (int i = 0; i < 10; i++)      /* DQCUMASK */
        regw(AR_D0_QCUMASK + (u32)i * 4, 1u << i);
    regw(AR_OBS, 8);
}

/* ================= приём: DMA RX ================= */

/* Owl: кольцо из WIFI_NUM_RXDESC дескрипторов, замкнутое само на себя
 * (HAL-стиль; BA-проблема 11n для сканера неактуальна). */
static int owl_rx_arm(void) {
    if (!ath.rxdesc) {
        ath.rxdesc_raw = malloc(sizeof(owl_rxdesc_t) * WIFI_NUM_RXDESC + 16);
        if (!ath.rxdesc_raw) return 0;
        ath.rxdesc = (owl_rxdesc_t *)
            (((u32)(unsigned long)ath.rxdesc_raw + 15) & ~15u);
        for (int i = 0; i < WIFI_NUM_RXDESC; i++) {
            ath.rxbuf_raw[i] = malloc(WIFI_RXBUF_SZ + 16);
            if (!ath.rxbuf_raw[i]) return 0;
            ath.rxbuf[i] = (u8 *)
                (((u32)(unsigned long)ath.rxbuf_raw[i] + 15) & ~15u);
        }
    }
    if (!ath.rxdesc) return 0;
    for (int i = 0; i < WIFI_NUM_RXDESC; i++) {
        owl_rxdesc_t *d = &ath.rxdesc[i];
        u8 *buf = ath.rxbuf[i];
        memset(d, 0, sizeof(*d));
        d->data = (u32)(unsigned long)buf;
        d->ctl1 = WIFI_RXBUF_SZ;
        owl_rxdesc_t *next = &ath.rxdesc[(i + 1) % WIFI_NUM_RXDESC];
        d->link = (u32)(unsigned long)next;
    }
    ath.rx_head = 0;
    regw(AR_RXDP, (u32)(unsigned long)&ath.rxdesc[0]);
    return 1;
}

/* Sowl: EDMA FIFO — адреса буферов пишутся в HP/LP RXDP, кадр приходит
 * в буфер с 44-байтовым статусным префиксом [recv.c + ar9003_mac.c]. */
static int sowl_rx_arm(void) {
    regw(AR_DATABUF_SIZE, WIFI_RXBUF_SZ & 0xFFF);
    for (int q = 0; q < WIFI_EDMA_QUEUES; q++) {
        u32 rxdp = (q == 0) ? AR_HP_RXDP : AR_LP_RXDP;
        for (int i = 0; i < WIFI_EDMA_BUFS; i++) {
            if (!ath.edbuf[q][i]) {
                u8 *raw = (u8 *)malloc(WIFI_EDMA_ST_LEN + WIFI_RXBUF_SZ + 16);
                if (!raw) return 0;
                ath.edbuf[q][i] = (u8 *)(((u32)(unsigned long)raw + 15) & ~15u);
            }
            u8 *buf = ath.edbuf[q][i];
            memset(buf, 0, WIFI_EDMA_ST_LEN);
            regw(rxdp, (u32)(unsigned long)buf);
        }
        ath.ed_head[q] = 0;
    }
    return 1;
}

/* фильтр приёма: всё + маяки + promiscuous (сканер) + запуск DMA RX */
static int ath_rx_start(void) {
    if (ath.is_sowl && !sowl_rx_arm()) return 0;
    if (!ath.is_sowl && !owl_rx_arm()) return 0;

    regw(AR_RX_FILTER, RXF_UCAST | RXF_MCAST | RXF_BCAST |
                       RXF_BEACON | RXF_PROM);
    /* снимать RX_DIS/RX_ABORT только ПОСЛЕ включения RXE [эталон:
     * override_ini + ar9002_hw_rx_enable + startpcureceive] */
    regw(AR_CR, ath.is_sowl ? AR_CR_RXE_SOWL : AR_CR_RXE_OWL);
    reg_clr(AR_DIAG_SW, AR_DIAG_RX_DIS | AR_DIAG_RX_ABORT);
    return 1;
}

/* ================= опрос RX (из wifi_poll -> ops->poll_rx) ================= */

/* Owl: обходим дескрипторы по порядку, пока не встретим незавершённый. */
static void owl_rx_poll(void) {
    if (!ath.rxdesc) return;
    int budget = 16;
    while (budget-- > 0) {
        owl_rxdesc_t *d = &ath.rxdesc[ath.rx_head];
        if (!(d->st[8] & 0x00000001)) break;    /* не Done */
        u32 flags = d->st[8];
        u32 dlen = d->st[1] & 0x00000FFF;
        i8 rssi = (i8)(d->st[4] >> 24);
        if (flags & 0x00000002) {               /* FrameOK */
            if (dlen >= 2 && dlen <= WIFI_RXBUF_SZ)
                wc_rx_frame((const u8 *)(unsigned long)d->data, (int)dlen, rssi);
        } else if (flags & 0x00000004) {
            wc_rx_err(1);                       /* CRC/PHY */
        } else {
            wc_rx_err(0);
        }
        /* перевзвести дескриптор (HW ушёл дальше по кольцу) */
        d->st[0] = d->st[1] = d->st[2] = d->st[3] = d->st[4] = 0;
        d->st[5] = d->st[6] = d->st[7] = d->st[8] = 0;
        d->ctl1 = WIFI_RXBUF_SZ;
        ath.rx_head = (ath.rx_head + 1) % WIFI_NUM_RXDESC;
    }
}

/* Sowl: буферы в FIFO по порядку; статусный префикс 44 б. */
static void sowl_rx_poll(void) {
    static const u32 rxdp_reg[WIFI_EDMA_QUEUES] = { AR_HP_RXDP, AR_LP_RXDP };
    for (int q = 0; q < WIFI_EDMA_QUEUES; q++) {
        if (!ath.edbuf[q][0]) continue;
        int budget = 4;
        while (budget-- > 0) {
            int h = ath.ed_head[q];
            u8 *base = ath.edbuf[q][h];
            volatile u32 *st = (volatile u32 *)base;
            if (!(st[10] & 0x00000001)) break;          /* не Done */
            if (((st[0] >> 16) & 0xFFFF) != 0x168c) break; /* не RX-статус */
            u32 dlen = st[2] & 0x00000FFF;
            i8 rssi = (i8)(st[5] >> 24);
            if (st[10] & 0x00000002) {                  /* FrameOK */
                if (dlen >= 2 && dlen <= WIFI_RXBUF_SZ)
                    wc_rx_frame(base + WIFI_EDMA_ST_LEN, (int)dlen, rssi);
            } else if (st[10] & 0x00000004) {
                wc_rx_err(1);
            } else {
                wc_rx_err(0);
            }
            /* вернуть буфер в FIFO */
            memset(base, 0, WIFI_EDMA_ST_LEN);
            regw(rxdp_reg[q], (u32)(unsigned long)base);
            ath.ed_head[q] = (h + 1) % WIFI_EDMA_BUFS;
        }
    }
}

/* ================= сканирование ================= */

/* быстрая смена канала (RFBUS) [hw.c: ath9k_hw_channel_change,
 * без смены полосы: только regs+synth+delta+BB+NF] */
static int ath_fastcc(int ch_idx) {
    regw(AR_PHY_RFBUS_REQ, 0x00000001);
    if (!hw_wait(AR_PHY_RFBUS_GRANT, 0x1, 0x1, AH_WAIT_TIMEOUT_US))
        return 0;

    ath_set_channel_regs();
    ath_set_synth(ch_idx);
    ath_delta_slope(wc_channel_freq[ch_idx]);
    reg_clr(AR_PHY_FORCE_CLKEN_CCK, AR_PHY_CCK_MRC_MUX);   /* no spur */
    ath_init_bb();
    synth_delay_wait();
    regw(AR_PHY_RFBUS_REQ, 0);
    ath_nf_load_start();
    return 1;
}

/* ---- ops->set_channel: fastcc, при неудаче полный bring-up ---- */
static int ath_ops_set_channel(int ch_idx) {
    if (ch_idx < 0 || ch_idx >= WC_NUM_CHANNELS) return 0;
    if (ath_fastcc(ch_idx)) return 1;
    wifi_log("смена канала не удалась — полный init");
    return ath_bringup() == 0;
}

/* ===================== TX + подключение (сессия 11) ===================== */

/* ---- чтение EEPROM (PCI, косвенный доступ) [pci.c: ath_pci_eeprom_read] ----
 * Запрос: чтение регистра по адресу AR5416_EEPROM_OFFSET + (word << 2),
 * ожидание снятия BUSY|PROT_ACCESS в статусе, данные — младшие 16 бит. */
static int eeprom_read_word(int word, u16 *out) {
    u32 stat_reg = ath.is_sowl ? AR_EEPROM_STAT_SOWL : AR_EEPROM_STAT_OWL;
    (void)reg32(AR5416_EEPROM_OFFSET + ((u32)word << AR5416_EEPROM_S));
    for (int t = 0; t < 20000; t += 20) {      /* до 20 мс */
        u32 v = reg32(stat_reg);
        if (!(v & (EEST_BUSY | EEST_PROT_ACCESS))) {
            *out = (u16)(v & EEST_VAL);
            return 1;
        }
        w_udelay(20);
    }
    return 0;
}

/* MAC-адрес из EEPROM:
 *  - Owl (AR9285/AR9287, формат 4K): слова 4-6 [base_eep_header_4k.macAddr]
 *  - Sowl (AR9485, формат AR9300): слова 1-3 [ar9300_eeprom.macAddr]
 * При неудаче — локально-администрируемый адрес 02:1A:2B:...:CPU-зависимый. */
static void read_mac_from_eeprom(void) {
    u16 w[3] = {0, 0, 0};
    int ok = 0;
    int base = ath.is_sowl ? 1 : 4;
    for (int i = 0; i < 3; i++)
        if (!eeprom_read_word(base + i, &w[i])) { ok = 0; break; } else ok = 1;
    if (ok) {
        /* 4K-формат: macAddr[0] — старший байт слова */
        ath.mac[0] = (u8)(w[0] >> 8); ath.mac[1] = (u8)(w[0] & 0xFF);
        ath.mac[2] = (u8)(w[1] >> 8); ath.mac[3] = (u8)(w[1] & 0xFF);
        ath.mac[4] = (u8)(w[2] >> 8); ath.mac[5] = (u8)(w[2] & 0xFF);
        if ((ath.mac[0] & 1) || (ath.mac[0] | ath.mac[1] | ath.mac[2] |
                                  ath.mac[3] | ath.mac[4] | ath.mac[5]) == 0)
            ok = 0;    /* групповой/нулевой адрес — мусор */
    }
    if (!ok) {
        /* запасной адрес: локально-администрируемый, детерминированный */
        ath.mac[0] = 0x02;
        ath.mac[1] = 0x1A;
        ath.mac[2] = 0x2B;
        ath.mac[3] = (u8)(ath.srev_raw >> 16);
        ath.mac[4] = (u8)(ath.srev_raw >> 8);
        ath.mac[5] = (u8)(ath.pci_devid);
        wifi_log("EEPROM MAC не читается — локальный адрес 02:1a:2b:..");
    }
    wifi_log("MAC %02x:%02x:%02x:%02x:%02x:%02x (EEPROM%s)",
             ath.mac[0], ath.mac[1], ath.mac[2],
             ath.mac[3], ath.mac[4], ath.mac[5], ok ? "" : ", fallback");
}

/* ---- настройка TX-очереди QCU/DCU 0 [mac.c: ath9k_hw_resettxqueue] ---- */
static void ath_tx_queue_setup(void) {
    int q = WIFI_TX_QUEUE;
    regw(AR_DQCUMASK(q), 1u << q);                    /* QCU q -> DCU q */
    regw(AR_DLCL_IFS(q),
         ((u32)AT_INIT_AIFS  << AR_D_LCL_IFS_AIFS_S) |
         ((u32)AT_INIT_CWMIN << AR_D_LCL_IFS_CWMIN_S) |
         ((u32)AT_INIT_CWMAX << AR_D_LCL_IFS_CWMAX_S));
    regw(AR_DRETRY_LIMIT(q),
         ((u32)AT_INIT_SSH_RETRY << AR_D_RETRY_LIMIT_STA_SH_S) |
         ((u32)AT_INIT_SLG_RETRY << AR_D_RETRY_LIMIT_STA_LG_S) |
         (10u << AR_D_RETRY_LIMIT_FR_SH_S));          /* INIT_SH_RETRY */
    regw(AR_QMISC(q), AR_Q_MISC_DCU_EARLY_TERM_REQ);
    regw(AR_DMISC(q), AR_D_MISC_CW_BKOFF_EN |
                      AR_D_MISC_FRAG_WAIT_EN |
                      (2u & AR_D_MISC_BKOFF_THRESH));
    regw(AR_Q_TXE, 0);                                /* очереди стоят */
    regw(AR_QTXDP(q), 0);

    if (!ath.is_sowl) {
        if (!ath.txdesc) {
            ath.txdesc_raw = malloc(sizeof(owl_txdesc_t) + 31);
            if (ath.txdesc_raw) {
                ath.txdesc = (owl_txdesc_t *)
                    (((u32)(unsigned long)ath.txdesc_raw + 15) & ~15u);
                memset(ath.txdesc, 0, sizeof(owl_txdesc_t));
            }
            ath.txbuf = (u8 *)malloc(WIFI_TXBUF_SZ);
        }
        return;
    }

    /* ---- СЕССИЯ 15: TX для AR9003/AR9485 — дескриптор ar9003 +
     * статусное кольцо. Порядок как в эталоне: память кольца чистится,
     * затем программируются AR_Q_STATUS_RING_START/END (до включения
     * очередей — ath9k_hw_reset_txstatus_ring). */
    if (!ath.stxdesc) {
        ath.stxdesc_raw = malloc(sizeof(sowl_txdesc_t) + 127);
        if (ath.stxdesc_raw) {
            ath.stxdesc = (sowl_txdesc_t *)
                (((u32)(unsigned long)ath.stxdesc_raw + 127) & ~127u);
            memset(ath.stxdesc, 0, sizeof(sowl_txdesc_t));
        }
        ath.stxbuf = (u8 *)malloc(WIFI_TXBUF_SZ);
    }
    if (!ath.tsring) {
        ath.tsring_raw = malloc(sizeof(sowl_txs_t) * WIFI_TS_RING + 31);
        if (ath.tsring_raw) {
            ath.tsring = (sowl_txs_t *)
                (((u32)(unsigned long)ath.tsring_raw + 31) & ~31u);
            for (int i = 0; i < WIFI_TS_RING; i++)
                memset(&ath.tsring[i], 0, sizeof(sowl_txs_t));
        }
    }
    if (!ath.stxdesc || !ath.stxbuf || !ath.tsring) {
        wifi_log("TX(sowl): нет памяти под дескриптор/статус-кольцо");
        return;
    }
    ath.ts_tail = 0;
    regw(AR_Q_STATUS_RING_START, (u32)(unsigned long)ath.tsring);
    regw(AR_Q_STATUS_RING_END,
         (u32)(unsigned long)ath.tsring +
         (u32)sizeof(sowl_txs_t) * WIFI_TS_RING);
}

/* Записать наш MAC в STA_ID0/1 (нужно для аппаратных ACK и RX-фильтра) */
static void ath_set_sta_id(void) {
    regw(AR_STA_ID0, (u32)ath.mac[0] | ((u32)ath.mac[1] << 8) |
                     ((u32)ath.mac[2] << 16) | ((u32)ath.mac[3] << 24));
    u32 v = reg32(AR_STA_ID1) & 0xFFFF0000u;   /* конфиг-биты не трогаем */
    v |= (u32)ath.mac[4] | ((u32)ath.mac[5] << 8);
    regw(AR_STA_ID1, v);
}

/* ---- передача одного кадра 802.11 (семейство Owl) ----
 * rates[4]/tries[4] — серия рейтов с падением; rate[i]==0 — серия не задана.
 * noack = 1 для broadcast/multicast (ACK не ждём).
 * keyidx = -1 — без шифрования; 0..127 — запись keycache (WPA2, сессия 12):
 * железо само строит CCMP-заголовок с PN и шифрует кадр.
 * Возвращает 1 при подтверждении (ACK получен / кадр ушёл). */
static int owl_tx_frame(const u8 *frame, u32 len, u8 hw_rate,
                        int tries, int noack, int keyidx)
{
    if (!ath.txdesc || !ath.txbuf) return 0;
    if (len > WIFI_TXBUF_SZ) return 0;

    s_lock(&ath.tx_lock);
    memcpy(ath.txbuf, frame, len);

    owl_txdesc_t *d = ath.txdesc;
    memset(d, 0, sizeof(*d));
    d->link = 0;                                   /* конец списка */
    d->data = (u32)(unsigned long)ath.txbuf;
    d->ctl0 = (len & TXD_FrameLen) | (30u << TXD_XmitPower0_S);  /* 15 dBm */
    d->ctl1 = (len & TXD_FrameLen) | TXD_TxMore |   /* буфер = кадр целиком */
              (noack ? TXD_NoAck : 0) |             /* FrameType NORMAL = 0 */
              (keyidx >= 0 ? (TXD_DestIdxValid |
                              (((u32)keyidx << TXD_DestIdx_S) & TXD_DestIdx)) : 0);
    d->ctl2 = ((u32)(tries & 0xF) << TXD_XmitDataTries0_S);
    d->ctl3 = (u32)hw_rate;
    /* сессия 12/25: тип шифрования в ctl6 (0=CLR по умолчанию — memset).
     * PTK — всегда CCMP; GTK — CCMP или TKIP (смешанный режим). */
    if (keyidx >= 0) {
        u32 encr = TXD_ENCR_AES;
        if (keyidx != KC_PTK_ENTRY && ath_gtk_is_tkip)
            encr = TXD_ENCR_TKIP;                  /* 3 */
        d->ctl6 |= (encr << TXD_EncrType_S);
    }

    regw(AR_QTXDP(WIFI_TX_QUEUE), (u32)(unsigned long)d);
    regw(AR_Q_TXE, 1u << WIFI_TX_QUEUE);

    /* ждём TxDone (status9.0): кадр ≤1500 б на 1 Мбит с ретраями < 100 мс */
    int done = 0, ok = 0;
    for (int t = 0; t < 30000; t += 50) {          /* до 30 мс... */
        if (d->st[9] & TXS_TxDone) { done = 1; break; }
        w_udelay(50);
    }
    if (!done) {   /* щедрый запас: 150 мс (ретраи 11Mx4) */
        for (int t = 30; t < 150; t += 5) {
            if (d->st[9] & TXS_TxDone) { done = 1; break; }
            w_udelay(5000);
        }
    }
    if (done) ok = (d->st[1] & TXS_FrmXmitOK) ? 1 : 0;
    else ok = noack;      /* noack-кадр могли передать, статуса не дождались */
    regw(AR_Q_TXE, 0);
    s_unlock(&ath.tx_lock);
    return ok;
}

/* ---- передача одного кадра 802.11 (AR9003/AR9485, СЕССИЯ 15) ----
 * Та же семантика, что owl_tx_frame, но дескриптор ar9003 (24 слова +
 * чексумма указателей) и статус приходит в КОЛЬЦЕ (не в дескрипторе).
 * Запрос пользователя: «нужно реализовать WPA2» — на нетбуке ASUS
 * X101CH стоит AR9485, и до этой сессии подключение было запрещено
 * («TX пока не поддержан»): без TX нет ни AUTH/ASSOC, ни 4-way
 * рукопожатия. Формат — 1:1 из ar9003_mac.c эталона (ar9003_set_txdesc). */
static int sowl_tx_frame(const u8 *frame, u32 len, u8 hw_rate,
                         int tries, int noack, int keyidx)
{
    if (!ath.stxdesc || !ath.stxbuf || !ath.tsring) return 0;
    if (len > WIFI_TXBUF_SZ) return 0;

    s_lock(&ath.tx_lock);
    memcpy(ath.stxbuf, frame, len);

    sowl_txdesc_t *d = ath.stxdesc;
    memset(d, 0, sizeof(*d));
    d->info = (0x168cu << 16) |            /* DescId = Atheros */
              (1u << 15) |                 /* TxRxDesc = TX */
              (1u << 14) |                 /* CtrlStat = контрольный */
              ((u32)WIFI_TX_QUEUE << 8) |  /* TxQcuNum */
              0x17u;                       /* desc_len (в словах) */
    d->link = 0;                           /* конец списка */
    d->data0 = (u32)(unsigned long)ath.stxbuf;
    d->ctl3 = ((u32)len << 16) & 0x0FFF0000u;
    {
        u32 sum = d->info + d->link + d->data0 + d->ctl3 +
                  d->data1 + d->ctl5 + d->data2 + d->ctl7 +
                  d->data3 + d->ctl9;
        d->ctl10 = ((sum & 0xFFFFu) + (sum >> 16)) & 0xFFFFu;
    }
    /* ctl11: FrameLen | XmitPower0 (30 = 15 dBm) | DestIdxValid */
    d->ctl11 = (len & 0x0FFFu) | (30u << 16) |
               (keyidx >= 0 ? 0x40000000u : 0);
    /* ctl12: DestIdx | FrameType(NORMAL=0) | NoAck */
    d->ctl12 = (keyidx >= 0 ? (((u32)keyidx << 13) & 0x000FE000u) : 0) |
               (noack ? 0x01000000u : 0);
    /* ctl13: попытки (основной рейт); DurUpdateEna не нужен —
     * duration в заголовке кадра ставим сами (owl-путь работает так) */
    d->ctl13 = ((u32)(tries & 0xF) << 16);
    /* ctl14: серия из одного рейта */
    d->ctl14 = (u32)hw_rate;
    /* ctl17: EncrType (биты 26-27): 2 = AES/CCMP, 3 = TKIP — как owl ctl6 */
    if (keyidx >= 0) {
        u32 encr = 2u;
        if (keyidx != KC_PTK_ENTRY && ath_gtk_is_tkip)
            encr = 3u;
        d->ctl17 |= (encr << 26);
    }
    d->ctl19 = 0x20000000u;                /* Not_Sounding (всегда) */

    regw(AR_QTXDP(WIFI_TX_QUEUE), (u32)(unsigned long)d);
    regw(AR_Q_TXE, 1u << WIFI_TX_QUEUE);

    /* ждём TxDone в статусном кольце (status8 bit0); записи выдаются
     * по порядку отправок — TX сериализован tx_lock + один дескриптор */
    sowl_txs_t *ts = &ath.tsring[ath.ts_tail];
    int done = 0, ok = 0;
    for (int t = 0; t < 30000; t += 50) {          /* до 30 мс... */
        if (ts->status8 & TXS8_TxDone) { done = 1; break; }
        w_udelay(50);
    }
    if (!done) {   /* щедрый запас: 150 мс (ретраи 11Mx4) */
        for (int t = 30; t < 150; t += 5) {
            if (ts->status8 & TXS8_TxDone) { done = 1; break; }
            w_udelay(5000);
        }
    }
    if (done) {
        ok = (ts->status3 & TXS3_FrmXmitOK) ? 1 : 0;
        /* очистить запись и подвинуть хвост (ath9k_hw_clear_txstatus) */
        memset(ts, 0, sizeof(*ts));
        ath.ts_tail = (ath.ts_tail + 1) % WIFI_TS_RING;
    } else {
        ok = noack;   /* noack-кадр могли передать, статуса не дождались */
    }
    regw(AR_Q_TXE, 0);
    s_unlock(&ath.tx_lock);
    return ok;
}

/* ДИСПЕТЧЕР: путь TX по семейству чипа (owl = AR9285/9287, sowl = AR9485) */

/* логический CCK-рейт -> hw-код 5416 [rc.c эталона] */
static u8 ath_rate_hw(wc_rate_t r) {
    static const u8 map[4] = { RATE_CCK_1M, RATE_CCK_2M, RATE_CCK_5_5M, RATE_CCK_11M };
    return map[(int)r];
}

static int ath_ops_tx_frame(const u8 *frame, u32 len, wc_rate_t rate,
                            int tries, int noack, int keyidx) {
    u8 hw = ath_rate_hw(rate);
    if (ath.is_sowl)
        return sowl_tx_frame(frame, len, hw, tries, noack, keyidx);
    return owl_tx_frame(frame, len, hw, tries, noack, keyidx);
}

/* ---- RX-фильтры (ops) ---- */
static void ath_rx_filter_promisc(void) {
    regw(AR_RX_FILTER, RXF_UCAST | RXF_MCAST | RXF_BCAST |
                       RXF_BEACON | RXF_PROM);
}

static void ath_rx_filter_bss(void) {
    regw(AR_RX_FILTER, RXF_UCAST | RXF_MCAST | RXF_BCAST | RXF_BEACON);
    regw(AR_MCAST_FIL0, 0);
    regw(AR_MCAST_FIL1, 0);
}

/* ================= keycache (сессия 12: WPA2) =================
 * Раскладка как в ath_key.c (hostap): KEY0..KEY4 — ключ с «рваными»
 * словами (KEY1/KEY3 — 16-битные!), TYPE (base+20) = CCM(6)/TKIP(2),
 * MAC0/MAC1 (base+24/28) — адрес, сдвинутый вправо на бит,
 * + VALID(0x8000). Парный ключ (PTK): запись 4 с MAC = BSSID
 * (декодирует юникаст по TA). Групповой (GTK): запись = keyid,
 * MAC = 0 + VALID (default key: выбор по keyid из кадра). */
#define AR_KEYTABLE_TYPE_TKIP  2u

static int ath_gtk_is_tkip = 0;   /* GTK TKIP -> EncrType TX-дескриптора */

/* MAC-часть записи: mac_or_null != 0 — юникаст (матч по TA),
 * NULL — default key (выбор по keyid из заголовка кадра). */
static void ath_keycache_mac(int entry, const u8 *mac_or_null)
{
    u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
    u32 mac0 = 0, mac1 = 0;
    if (mac_or_null) {
        mac0 = (u32)mac_or_null[0] | ((u32)mac_or_null[1] << 8) |
               ((u32)mac_or_null[2] << 16) | ((u32)mac_or_null[3] << 24);
        mac1 = (u32)mac_or_null[4] | ((u32)mac_or_null[5] << 8);
        mac0 >>= 1;                            /* MAC сдвинут вправо на бит */
        mac0 |= (mac1 & 1) << 31;
        mac1 >>= 1;
        mac1 |= AR_KEYTABLE_VALID;             /* unicast: матч по TA */
    } else {
        mac1 = AR_KEYTABLE_VALID;              /* default key (по keyid) */
    }
    regw(base + 24, mac0);
    regw(base + 28, mac1);
}

/* Запись ключа CCMP (16 б) в keycache. */
static void ath_keycache_write(int entry, const u8 *key16, const u8 *mac_or_null) {
    u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
    /* «рваные» слова — как ath_hw_set_keycache_entry (hostap):
     * KEY0=le32(k[0..3]) KEY1=le16(k[4..5]) KEY2=le32(k[6..9])
     * KEY3=le16(k[10..11]) KEY4=le32(k[12..15]) */
    regw(base + 0,  (u32)key16[0] | ((u32)key16[1] << 8) |
                    ((u32)key16[2] << 16) | ((u32)key16[3] << 24));
    regw(base + 4,  (u32)key16[4] | ((u32)key16[5] << 8));
    regw(base + 8,  (u32)key16[6] | ((u32)key16[7] << 8) |
                    ((u32)key16[8] << 16) | ((u32)key16[9] << 24));
    regw(base + 12, (u32)key16[10] | ((u32)key16[11] << 8));
    regw(base + 16, (u32)key16[12] | ((u32)key16[13] << 8) |
                    ((u32)key16[14] << 16) | ((u32)key16[15] << 24));
    regw(base + 20, AR_KEYTABLE_TYPE_CCM);    /* TYPE = AES-CCM */
    ath_keycache_mac(entry, mac_or_null);
}

/* Сессия 25: ключ TKIP в keycache. Раскладка Atheros HAL (ath_key.c):
 * запись entry — 16-байтный временный ключ (TK) с TYPE=TKIP; запись
 * entry+1 — MIC-ключи: KEY0/KEY1 = RX-MIC (байты 16..23), KEY2/KEY3 =
 * TX-MIC (24..31), TYPE=TKIP, MAC1=VALID. Нужна для сетей с групповым
 * TKIP (смешанный режим WPA/WPA2): без неё не расшифровываются
 * широковещательные кадры (DHCP OFFER/NAK, ARP). */
static void ath_keycache_write_tkip(int entry, const u8 *key32,
                                    const u8 *mac_or_null)
{
    u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
    regw(base + 0,  (u32)key32[0] | ((u32)key32[1] << 8) |
                    ((u32)key32[2] << 16) | ((u32)key32[3] << 24));
    regw(base + 4,  (u32)key32[4] | ((u32)key32[5] << 8));
    regw(base + 8,  (u32)key32[6] | ((u32)key32[7] << 8) |
                    ((u32)key32[8] << 16) | ((u32)key32[9] << 24));
    regw(base + 12, (u32)key32[10] | ((u32)key32[11] << 8));
    regw(base + 16, (u32)key32[12] | ((u32)key32[13] << 8) |
                    ((u32)key32[14] << 16) | ((u32)key32[15] << 24));
    regw(base + 20, AR_KEYTABLE_TYPE_TKIP);
    ath_keycache_mac(entry, mac_or_null);

    /* MIC-запись (entry+1): RX-MIC -> KEY0/KEY1, TX-MIC -> KEY2/KEY3 */
    u32 mbase = AR_KEYTABLE_BASE + (u32)(entry + 1) * 32;
    regw(mbase + 0,  (u32)key32[16] | ((u32)key32[17] << 8) |
                     ((u32)key32[18] << 16) | ((u32)key32[19] << 24));
    regw(mbase + 4,  (u32)key32[20] | ((u32)key32[21] << 8));
    regw(mbase + 8,  (u32)key32[24] | ((u32)key32[25] << 8) |
                     ((u32)key32[26] << 16) | ((u32)key32[27] << 24));
    regw(mbase + 12, (u32)key32[28] | ((u32)key32[29] << 8));
    regw(mbase + 16, 0);
    regw(mbase + 20, AR_KEYTABLE_TYPE_TKIP);
    regw(mbase + 24, 0);
    regw(mbase + 28, AR_KEYTABLE_VALID);
}

/* ---- ops->keys_install / keys_clear ---- */
static int ath_keys_install(const u8 *bssid, const u8 *ptk, int ptk_is_tkip,
                            const u8 *gtk, int gtk_is_tkip, int gtk_keyid) {
    ath_gtk_is_tkip = gtk_is_tkip;
    /* PTK: CCMP — TK (ptk+32, 16 б); TKIP-пара (СЕССИЯ 48) — ptk+32 как
     * [TK16][RX MIC8][TX MIC8] (PRF-порядок: RX на +48, TX на +56),
     * ровно формат ath_keycache_write_tkip */
    if (ptk_is_tkip) {
        ath_keycache_write_tkip(KC_PTK_ENTRY, ptk + 32, bssid);
        wifi_log("PTK TKIP (64 б) -> запись %d+MIC", KC_PTK_ENTRY);
    } else {
        ath_keycache_write(KC_PTK_ENTRY, ptk + 32, bssid);
    }
    if (gtk_is_tkip) {
        if ((gtk_keyid & 3) == 3) {
            wifi_log("GTK keyid=3 + TKIP: MIC-запись занята PTK — "
                     "конфликт записей");
        }
        ath_keycache_write_tkip(gtk_keyid & 3, gtk, NULL);
        wifi_log("GTK TKIP (32 б) -> запись %d+MIC", gtk_keyid & 3);
    } else {
        ath_keycache_write(gtk_keyid & 3, gtk, NULL);
    }
    return 1;
}

static void ath_keys_clear(void) {
    if (!ath.ready) return;
    for (int entry = 0; entry < 8; entry++) {
        u32 base = AR_KEYTABLE_BASE + (u32)entry * 32;
        for (int w = 0; w < 7; w++)
            regw(base + (u32)w * 4, 0);
        regw(base + 20, 7 /* CLR */);
    }
    ath_gtk_is_tkip = 0;
}

/* ---- AR9485: скан увидел 0 кадров — попробовать опорник 25 МГц ---- */
static int ath_scan_retry(u32 frames_seen) {
    (void)frames_seen;
    if (ath.is_sowl && !ath.clk25) {
        wifi_log("ни одного кадра — AR9485: пробую опорник 25 МГц");
        ath.clk25 = 1;
        if (ath_bringup()) {
            wifi_log("повторный init не удался");
            ath.clk25 = 0;
            ath_bringup();            /* вернуть рабочую конфигурацию */
            return 0;
        }
        return 1;
    }
    return 0;
}

/* ================= полный bring-up =================
 * Порядок — как ath9k_hw_reset для 2.4 ГГц HT20 станции (TX-очередь
 * и MAC из EEPROM добавлены в сессии 11 для ассоциации). */
static const char *ath_bringup(void) {
    const char *err;
    static char errbuf[64];
    int nf;

    if ((err = ath_reset(1))) { snprintf(errbuf, sizeof(errbuf), "reset: %s", err); return errbuf; }
    wifi_log("reset ok (RTC status=%x)", reg32(AR_RTC_STATUS) & 0xF);

    if ((err = ath_power_awake())) { snprintf(errbuf, sizeof(errbuf), "power: %s", err); return errbuf; }

    ath_init_pll();
    wifi_log("PLL настроен (0x%x)", reg32(AR_RTC_PLL_CONTROL));

    reg_set(AR_GPIO_IN_EN_VAL, AR_GPIO_JTAG_DIS);
    regw(AR_PHY_ACTIVE, 0);                       /* mark_phy_inactive */

    if (ath.is_sowl) sowl_process_ini();
    else             owl_process_ini();
    wifi_log("ini-массивы записаны (%s)", ath.is_sowl ? "AR9485" : ath.chip == CHIP_AR9285 ? "AR9285" : "AR9287");

    ath_override_ini();
    ath_set_channel_regs();
    ath_chain_masks();
    ath_set_rfmode();
    ath_delta_slope(wc_channel_freq[0]);

    ath_mac_dma_config();
    ath_set_sta_id();               /* наш MAC (EEPROM) — ACK + RX-фильтр */
    ath_tx_queue_setup();           /* QCU/DCU 0: данные + mgmt */
    ath_set_synth(0);
    ath_init_bb();

    if (ath.is_sowl)      err = sowl_agc_cal();
    else if (ath.chip == CHIP_AR9287) err = kite_agc_cal();
    else                  err = owl_cl_cal();
    if (err) { snprintf(errbuf, sizeof(errbuf), "%s", err); return errbuf; }
    wifi_log("калибровка ok (AGC=%x)", reg32(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL));

    ath_nf_load_start();

    if (!ath_rx_start()) {
        snprintf(errbuf, sizeof(errbuf), "нет памяти под RX-буферы");
        return errbuf;
    }

    /* диагностика в журнал: значения ключевых регистров после init */
    {
        u32 cca = ath.is_sowl ? AR_PHY_CCA_0_SOWL : AR_PHY_CCA;
        nf = nf_get(cca);
        wifi_log("RX поднят: SREV=%x RXDP=%x FILT=%x",
                 reg32(AR_SREV_REG),
                 reg32(AR_RXDP),
                 reg32(AR_RX_FILTER));
        wifi_log("NF после калибровки: %d dBm (CCA=%x), AGC=%x",
                 nf, (unsigned)reg32(cca),
                 (unsigned)reg32(ath.is_sowl ? AR_AGC_CTL_SOWL : AR_AGC_CTL_OWL));
    }
    ath.ready = 1;
    wc_set_state(1, 1);
    return 0;
}

/* ================= probe (PCI) + привязка к wifi_core ================= */

static void ath_poll_rx_dispatch(void);
static void ath_full_reset(void);
static int ath_scan_retry(u32 frames_seen);
static int ath_keys_install(const u8 *bssid, const u8 *ptk, int ptk_is_tkip,
                            const u8 *gtk, int gtk_is_tkip, int gtk_keyid);
static void ath_keys_clear(void);
static void ath_rx_filter_promisc(void);
static void ath_rx_filter_bss(void);
static int ath_ops_set_channel(int ch_idx);
static int ath_ops_tx_frame(const u8 *frame, u32 len, wc_rate_t rate,
                            int tries, int noack, int keyidx);

static const wifi_hw_ops_t ath_ops = {
    .poll_rx           = ath_poll_rx_dispatch,
    .set_channel       = ath_ops_set_channel,
    .tx_frame          = ath_ops_tx_frame,
    .rx_filter_promisc = ath_rx_filter_promisc,
    .rx_filter_bss     = ath_rx_filter_bss,
    .keys_install      = ath_keys_install,
    .keys_clear        = ath_keys_clear,
    .full_reset        = ath_full_reset,
    .scan_retry        = ath_scan_retry,
};

static void ath_poll_rx_dispatch(void) {
    if (ath.is_sowl) sowl_rx_poll();
    else             owl_rx_poll();
}

static void ath_full_reset(void) {
    ath_bringup();
}

int ath9k_wifi_probe(void) {
    memset(&ath, 0, sizeof(ath));

    serial_puts("[wifi] init: поиск Atheros (168c:002b/002e/0032)...\n");

    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                if ((id & 0xFFFF) != 0x168c) {
                    if (func == 0) {
                        u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                        if (!(hdr & 0x80)) break;
                    }
                    continue;
                }
                u32 devid = (id >> 16) & 0xFFFF;
                if (devid != 0x002b && devid != 0x002e && devid != 0x0032)
                    continue;

                ath.pci_devid = (u16)devid;
                ath.present = 1;
                char cname[36];
                if (devid == 0x002b)      { ath.chip = CHIP_AR9285; strcpy(cname, "Atheros AR9285"); }
                else if (devid == 0x002e) { ath.chip = CHIP_AR9287; strcpy(cname, "Atheros AR9287"); }
                else                      { ath.chip = CHIP_AR9485; ath.is_sowl = 1; strcpy(cname, "Atheros AR9485"); }
                wc_set_chip_name(cname);

                u32 bar0 = pci_read32(bus, dev, func, 0x10);
                ath.mmio_base = bar0 & 0xFFFFFFF0u;

                u16 cmd = pci_read16(bus, dev, func, 0x04);
                cmd |= 0x0006;                     /* Bus Master + Memory Space */
                pci_write16(bus, dev, func, 0x04, cmd);

                wifi_log("%s на шине %d:%d.%d, MMIO=%x",
                         cname, bus, dev, func, (unsigned)ath.mmio_base);

                if (!ath.mmio_base) {
                    wifi_log("BAR0 пуст — карта не активна BIOS'ом");
                    return 0;
                }

                ath.srev_raw = reg32(AR_SREV_REG);
                {
                    u32 v = ath.srev_raw & 0xFF;
                    u32 ver, rev;
                    if (v == 0xFF) {                    /* Owl+: версия в старших битах */
                        ver = (ath.srev_raw & 0xFFFC0000u) >> 12;
                        rev = (ath.srev_raw & 0x00000F00u) >> 8;
                    } else {                             /* ранние чипы */
                        ver = (v & 0xF0) >> 4;
                        rev = v & 0x7;
                    }
                    wifi_log("SREV=%x (MAC %x.%d)",
                             (unsigned)ath.srev_raw, (unsigned)ver, (int)rev);
                }

                w_udelay_calibrate();       /* честные мкс до первого сброса */

                read_mac_from_eeprom();     /* MAC нужен для STA_ID и TX */
                wc_set_mac(ath.mac);

                const char *err = ath_bringup();
                if (err) {
                    ath.ready = 0;
                    wc_set_state(1, 0);
                    wifi_log("INIT FAILED: %s", err);
                    return 0;               /* карта есть, но не поднялась */
                }
                wifi_core_bind(&ath_ops);
                return 1;               /* одно WiFi-устройство достаточно */
            }
        }
    }
    return 0;    /* адаптер Atheros не найден */
}
