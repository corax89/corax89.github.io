/* gdt.h — Global Descriptor Table + сегменты-песочницы задач */
#ifndef GDT_H
#define GDT_H

#include "types.h"

void gdt_init(void);

/* --- защита памяти задач (flat-модель без MMU) --- */
/* Селектор сегмента данных задачи tid (0x18+tid*8).
 * Если регион не назначен — используйте 0x10 (ядро, 4 ГБ). */
u16 gdt_task_selector(int tid);

/* Назначить/прочитать регион задачи [base, base+size).
 * Задача с таким DS/ES/SS не может выйти за пределы региона:
 * запись мимо — #GP, приложение погибает, ядро живёт. */
void gdt_set_task_region(int tid, u32 base, u32 size);
void gdt_clear_task_region(int tid);
int  gdt_task_region(int tid, u32 *base, u32 *limit);   /* 0 если не задан */

#endif
