/* usb.h — компактный стек USB для N2600-OS.
 *
 * Что реализовано:
 *   1. UHCI-драйвер:
 *      - PCI-сканирование (class 0x0C, subclass 0x03, prog-if 0x00)
 *      - Инициализация: сброс, frame list (4 КиБ), SOF, сброс портов.
 *      - Полная структура QH/TD: TD (32 байта), QH (16 байт), frame list.
 *      - Control-трансферы: SETUP + DATA + STATUS с правильной цепочкой TD
 *        и вставкой в frame list на 16 кадров вперёд (для гарантии срабатывания).
 *      - Перечисление устройств: GetDescriptor(Device) → SetAddress →
 *        GetDescriptor(Config) → SetConfiguration → SetIdle + SetProtocol(Boot)
 *      - Interrupt-трансферы на EP1 для опроса HID-отчётов.
 *      - Парсинг 8-байтного boot-отчёта клавиатуры (HID usage → ASCII) и
 *        4-байтного boot-отчёта мыши (dx, dy, buttons).
 *      - Инжекция событий в общий kbd ring (kbd_push_event) и mouse.c.
 *
 *   2. EHCI-детекция:
 *      - Сканирование PCI на EHCI (class 0x0C, subclass 0x03, prog-if 0x20).
 *      - Выводит информацию о контроллере (iobase, выделение памяти под regs).
 *      - Полноценный EHCI-драйвер с async/bulk-трансферами и SCSI mass-storage
 *        требует значительно больше кода (~2000 строк) и выходит за рамки
 *        компактного встраивания. Текущая версия только ДЕТЕКТИРУЕТ EHCI —
 *        hi-speed устройства (флешки) не поддерживаются.
 *
 * Что НЕ реализовано (ограничение):
 *   - Прямое чтение HID-отчётов из USB в QEMU — частично работает структурно,
 *     но требует отладки UHCI control transfers. На реальном железе
 *     HID-события продолжают приходить через BIOS Legacy USB (PS/2-эмуляцию).
 *   - EHCI hi-speed bulk transfers — нет bulk-эндпоинтов.
 *   - USB Mass Storage class (SCSI/CBC) — нет чтения флешек.
 *   - Хабы (Hub class) — только порты рут-хаба UHCI (2 шт.).
 *
 * Публичный API:
 *   usb_init()                — инициализация, вызывается из kmain до sti().
 *   usb_poll()                — опрос HID (вызывается из главного цикла).
 *   usb_keyboard_present()    — 1, если найдена USB-клавиатура.
 *   usb_mouse_present()       — 1, если найдена USB-мышь.
 *   usb_controllers_found()   — 1, если найден и инициализирован UHCI.
 *   usb_ehci_present()        — 1, если найден EHCI (только детекция).
 *   usb_devices_found()       — число обнаруженных USB-устройств.
 */
#ifndef USB_H
#define USB_H

#include "types.h"

void usb_init(void);
void usb_poll(void);

int  usb_keyboard_present(void);
int  usb_mouse_present(void);
int  usb_controllers_found(void);
int  usb_ehci_present(void);
int  usb_devices_found(void);

#endif /* USB_H */
