/* ata.h — чтение секторов через ATA PIO и ATAPI */
#ifndef ATA_H
#define ATA_H

#include "types.h"

int   ata_init(void);          /* 1 = диск найден */
int   ata_present(void);
int   ata_is_cdrom(void);      /* 1 = это ATAPI CD-ROM (ISO-образ) */

/* Для HDD count = кол-во секторов по 512 байт. 
   Для CD-ROM count = кол-во блоков по 2048 байт. */
int   ata_read(u32 lba, u8 count, void *buf); /* ИСПРАВЛЕНО: добавлена * */

u32   ata_sectors(void);       /* полный размер в секторах (для HDD) */
const char *ata_model(void);

u16   ata_base_port(void);     /* реальный порт найденного устройства (0x1F0/0x170) */
u8    ata_drive_sel(void);     /* 0xA0=master, 0xB0=slave — селектор найденного устройства */

/* ---- отдельный ATA HDD (FIX [A1]) ----
 * ata_init() пробует ВСЕ IDE-каналы и запоминает HDD отдельно от CD.
 * Активное устройство (ata_read) — ATAPI CD, если он есть; НЖМД доступен
 * всегда через эти функции (нужен fat32 на машинах с HDD+CD). */
int   ata_hdd_present(void);   /* 1 = найден ATA HDD (не активное устройство) */
int   ata_is_hdd_active(void); /* 1 = активное устройство ata_read() — HDD */
u32   ata_hdd_sectors(void);
const char *ata_hdd_model(void);
int   ata_read_hdd(u32 lba, u8 count, void *buf);  /* секторы 512 байт */
int   ata_write_hdd(u32 lba, u8 count, const void *buf); /* сессия 12: запись (форматирование) */

/* Сессия 13: дамп регистров IDE (команда ataprobe). */
void ata_probe_diag(void);

#endif