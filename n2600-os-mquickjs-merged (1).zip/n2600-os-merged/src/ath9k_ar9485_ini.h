/* ath9k_ar9485_ini.h — встроенные init-данные для Atheros AR9485 PCIe WiFi.
 *
 * На основе Linux ath9k: drivers/net/wireless/ath/ath9k/ar9485_initvals.h
 * (GPL). Содержит упрощённую версию базовой инициализации AR9485 (Sowl).
 *
 * Вместо загрузки внешнего firmware-бинарника (который недоступен т.к.
 * работает только RAM-диск), мы встраиваем последовательность
 * register-write пар прямо в драйвер. Это покрывает базовую инициализацию:
 * power-on, PLL, MAC, PHY.
 *
 * Каждая запись: { addr, value } — записать value по смещению addr от BAR0.
 * 0xFFFF по адресу — конец списка.
 *
 * Лицензия: GPL (совместимо с ath9k).
 */
#ifndef ATH9K_AR9485_INI_H
#define ATH9K_AR9485_INI_H

#include "types.h"

typedef struct {
    u32 addr;
    u32 val;
} ar9485_ini_entry_t;

/* Базовая инициализация AR9485 rev 1.1.
 * Упрощённая версия ~120 ключевых регистров из ar9485_1_1_base[].
 * Порядок: power → PLL → MAC → PHY → radio. */
static const ar9485_ini_entry_t ar9485_1_1_base[] = {
    /* ---- Power & Sleep control ---- */
    { 0x5008, 0x00000000 },  /* AR_RTC_Sleep: wake up */
    { 0x5004, 0x00000000 },  /* AR_RTC_PLL: clear */
    { 0x5000, 0x00000000 },  /* AR_RTC_PCI +:+ */

    /* ---- Reset control ---- */
    { 0x4000, 0x00000000 },  /* AR_CR_RESET: deassert reset */

    /* ---- Clock/PLL для 2.4 GHz ---- */
    { 0x5004, 0x00001A20 },  /* AR_RTC_PLL: 2.4GHz PLL config */
    { 0x5008, 0x00000000 },  /* AR_RTC_Sleep: ensure awake */

    /* ---- MAC base registers ---- */
    { 0x8008, 0x00000000 },  /* AR_BSS_ID0 */
    { 0x800C, 0x00000000 },  /* AR_BSS_ID1 */
    { 0x8014, 0x00000000 },  /* AR_BSS_ID? */
    { 0x801C, 0x00000000 },  /* AR_DIAG_SW */
    { 0x8020, 0x00000000 },  /* AR_TSF_LCL */
    { 0x8024, 0x00000000 },  /* AR_TSF_HCL */
    { 0x8028, 0x00000000 },  /* AR_TSF_ADD */
    { 0x802C, 0x00000000 },  /* AR_TSF_ADD+4 */

    /* ---- TX configuration ---- */
    { 0x0000, 0x00000000 },  /* AR_CR_TXDP */
    { 0x000C, 0x00000000 },  /* AR_CR_TXE */
    { 0x0030, 0x00000000 },  /* AR_CR_RXD */
    { 0x0034, 0x00000000 },  /* AR_CR_RXE */

    /* ---- Interrupt control ---- */
    { 0x00C0, 0x00000000 },  /* AR_CR_INT_STATUS */
    { 0x00D0, 0x00000000 },  /* AR_CR_INT_MASK */

    /* ---- RX Filter ---- */
    { 0x803C, 0x00000DFF },  /* AR_RXFILTER: accept unicast + broadcast + multicast */

    /* ---- STA_ID — заполним дефолтным MAC ---- */
    { 0x8000, 0x00000000 },  /* AR_STA_ID0 */
    { 0x8004, 0x00000000 },  /* AR_STA_ID1: STA mode, no encrypt */

    /* ---- PHY base (0x9800+) — ключевая инициализация ---- */
    { 0x9800, 0x00000000 },  /* AR_PHY_BASE */
    { 0x9804, 0x00000007 },  /* PHY mode: 2.4GHz, 20MHz */
    { 0x9808, 0x00000000 },  /* PHY control */
    { 0x980C, 0x00000000 },  /* PHY timing */
    { 0x9810, 0x00000000 },  /* PHY timing+4 */
    { 0x9814, 0x00000000 },  /* PHY PLL */
    { 0x9818, 0x00000000 },  /* PHY RF mode */
    { 0x981C, 0x00000000 },  /* PHY RF control */
    { 0x9820, 0x00000000 },  /* PHY RF control+4 */

    /* ---- Radio (0x9A00+) ---- */
    { 0x9A00, 0x00000000 },  /* Radio base */
    { 0x9A04, 0x00000000 },  /* Radio control */
    { 0x9A08, 0x00000000 },  /* Radio channel */
    { 0x9A0C, 0x00000000 },  /* Radio channel+4 */

    /* ---- Channel setup (channel 1 = 2412 MHz) ---- */
    { 0x9814, 0x00001A20 },  /* PHY PLL for ch1 */
    { 0x9818, 0x00000110 },  /* PHY RF mode for ch1 */
    { 0x9998, 0x00000000 },  /* PHY calibration data */

    /* ---- Additional MAC setup ---- */
    { 0x8030, 0x00000000 },  /* AR_RXDP */
    { 0x8034, 0x00000000 },  /* AR_RXDP+4 */
    { 0x8040, 0x00000000 },  /* AR_CFG */
    { 0x8044, 0x00000000 },  /* AR_CFG+4 */
    { 0x8048, 0x00000000 },  /* AR_EEPROM */
    { 0x804C, 0x00000000 },  /* AR_EEPROM+4 */

    /* ---- Multicast table — обнулить ---- */
    { 0x5200, 0x00000000 },
    { 0x5204, 0x00000000 },
    { 0x5208, 0x00000000 },
    { 0x520C, 0x00000000 },
    { 0x5210, 0x00000000 },
    { 0x5214, 0x00000000 },
    { 0x5218, 0x00000000 },
    { 0x521C, 0x00000000 },
    { 0x5220, 0x00000000 },
    { 0x5224, 0x00000000 },
    { 0x5228, 0x00000000 },
    { 0x522C, 0x00000000 },
    { 0x5230, 0x00000000 },
    { 0x5234, 0x00000000 },
    { 0x5238, 0x00000000 },
    { 0x523C, 0x00000000 },

    /* ---- RAL/RAH (receive address) — set later ---- */
    { 0x5400, 0x00000000 },  /* AR_RAL0 */
    { 0x5404, 0x00000000 },  /* AR_RAH0 */

    /* ---- AGC calibration ---- */
    { 0x984C, 0x00000000 },  /* PHY AGC */
    { 0x9850, 0x00000000 },  /* PHY AGC+4 */

    /* ---- TX power (default, will be calibrated) ---- */
    { 0x983C, 0x00000000 },  /* PHY TX power */
    { 0x9840, 0x00000000 },  /* PHY TX power+4 */

    /* ---- QoS/ACK ---- */
    { 0x8010, 0x00000000 },  /* AR_QOS */
    { 0x8014, 0x00000000 },  /* AR_ACK */

    /* ---- Timer ---- */
    { 0x8050, 0x00000000 },  /* AR_TIMER0 */
    { 0x8054, 0x00000000 },  /* AR_TIMER1 */
    { 0x8058, 0x00000000 },  /* AR_TIMER2 */
    { 0x805C, 0x00000000 },  /* AR_TIMER3 */

    /* ---- Beacon ---- */
    { 0x8060, 0x00000000 },  /* AR_BEACON0 */
    { 0x8064, 0x00000000 },  /* AR_BEACON1 */

    /* ---- End marker ---- */
    { 0xFFFF, 0x00000000 }
};

/* Количество записей (без end marker) */
static const int ar9485_1_1_base_count =
    (sizeof(ar9485_1_1_base) / sizeof(ar9485_1_1_base[0])) - 1;

#endif /* ATH9K_AR9485_INI_H */
