/* pci.h — минимальный доступ к PCI конфигурационному пространству.
 *
 * Реализация функций находится в usb.c (они используются обоими USB-драйверами).
 * Заголовок делает их видимыми для usb_ehci.c.
 */
#ifndef PCI_H
#define PCI_H

#include "types.h"

u32  pci_read32(int bus, int dev, int func, int reg);
u16  pci_read16(int bus, int dev, int func, int reg);
u8   pci_read8(int bus, int dev, int func, int reg);
void pci_write32(int bus, int dev, int func, int reg, u32 val);
void pci_write16(int bus, int dev, int func, int reg, u16 val);

#endif /* PCI_H */
