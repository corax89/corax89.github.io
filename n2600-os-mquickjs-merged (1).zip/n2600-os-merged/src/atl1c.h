/* atl1c.h — Atheros L1c/L2c PCI-E Ethernet (порт Linux atl1c, GPLv2).
 *
 * Чипы: AR8132/L2C (1969:1062), AR8131/L1C (1969:1063),
 *       AR8152/L2CB v2.x (1969:2062) — сетевая карта ASUS X101CH,
 *       AR8151/L1D (1969:1073), AR8151 v2/L1D_2 (1969:1083).
 */
#ifndef ATL1C_H
#define ATL1C_H

#include "types.h"

int  atl1c_init(void);
int  atl1c_present(void);
int  atl1c_link_up(void);        /* 1 = кабель вставлен (PHY BMSR) */
void atl1c_get_mac(u8 *out6);
const char *atl1c_chip_name(void);
int  atl1c_send(const void *buf, u32 len);
u32  atl1c_recv(void *out_buf, u32 out_max);

#endif
