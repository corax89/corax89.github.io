/* iso9660.c — базовый парсер ISO 9660 (чтение PVD и корневого каталога)
 *
 * FIX [I1] (пустой ramfs при загрузке НЕ с ATAPI CD): раньше требовался
 * ATAPI CD-ROM. Теперь, если CD нет, но есть ATA HDD, пробуем читать
 * ISO9660 прямо с НЖМД (секторы 512 байт → 4 сектора на блок 2048):
 * так работает isohybrid-запись образа на флешку/диск (dd) и QEMU с
 * образом, подключённым как HDD. Если на диске не ISO (проверка CD001
 * на LBA 16) — честно возвращаем 0.
 *
 * FIX [I2]: ISO9660_NAME_MAX 255 → 64: записи каталога PVD-дерева
 * короткие (уровень 1 — 8.3, Joliet ОС не читает), а три массива
 * iso9660_dirent_t в ramfs_seed_from_iso ели ~43 КиБ стека kmain —
 * теперь ~12 КиБ. */
#include "iso9660.h"
#include "ata.h"
#include "ahci.h"
#include "disk.h"
#include "mem.h"
#include "string.h"

#define ISO_SECTOR_SIZE 2048

static int ready = 0;
static u32 root_lba = 0;
static u32 root_size = 0;
static u8 *iso_buf = NULL;
static int iso_on_hdd = 0;   /* 1 = ISO читается с ATA HDD (512-б секторы) */

static u32 read_le32(const u8 *p) {
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

/* Прочитать один ISO-блок 2048 байт по ISO-LBA с активного устройства:
 * ATAPI CD — напрямую; ATA HDD — 4 сектора по 512 байт. */
static int iso_read_block(u32 lba, u8 *buf)
{
    if (iso_on_hdd) {
        if (lba > 0x3FFFFFFFu) return 0;      /* 4*lba не переполнится */
        return disk_hdd_read(lba * 4, 4, buf); /* 4×512 = 2048 */
    }
    /* CD: AHCI ATAPI (SATA-привод) приоритетнее легаси ATAPI */
    if (ahci_cd_present())
        return ahci_read_cd(lba, buf);
    return ata_read(lba, 1, buf);
}

int iso9660_init(void) {
    ready = 0;

    /* Путь 1: CD-ROM — AHCI ATAPI или легаси ATAPI */
    if (ahci_cd_present() || (ata_present() && ata_is_cdrom())) {
        iso_on_hdd = 0;
    } else if (disk_hdd_present()) {
        /* FIX [I1]: НЖМД без CD — вероятно isohybrid-образ, пробуем */
        iso_on_hdd = 1;
    } else {
        return 0;
    }

    if (iso_buf) { free(iso_buf); iso_buf = NULL; }
    iso_buf = (u8 *)malloc(ISO_SECTOR_SIZE);
    if (!iso_buf) return 0;

    /* Primary Volume Descriptor (PVD) всегда находится на LBA 16 */
    if (!iso_read_block(16, iso_buf)) return 0;

    /* Проверка сигнатуры: байты 1..5 должны быть "CD001" */
    if (memcmp(iso_buf + 1, "CD001", 5) != 0) return 0;

    /* Тип тома должен быть 1 (Primary Volume Descriptor) */
    if (iso_buf[0] != 1) return 0;

    /* Запись корневого каталога находится по смещению 156 */
    u8 *root_rec = iso_buf + 156;

    root_lba  = read_le32(root_rec + 2);
    root_size = read_le32(root_rec + 10);

    if (root_lba == 0 || root_size == 0) return 0;

    ready = 1;
    return 1;
}

int iso9660_ready(void) { return ready; }

static void clean_iso_name(char *dst, const char *src, int len) {
    int i = 0;
    while (i < len && src[i] != ';' && src[i] != '.' && src[i] != 0) {
        dst[i] = src[i];
        i++;
    }
    while (i > 0 && dst[i-1] == ' ') i--;
    dst[i] = 0;
}

int iso9660_list_root(iso9660_dirent_t *out, int max) {
    if (!ready || !iso_buf) return 0;

    int count = 0;
    u32 current_lba = root_lba;
    u32 bytes_read = 0;

    while (bytes_read < root_size && count < max) {
        if (!iso_read_block(current_lba, iso_buf)) break;

        u32 offset = 0;
        while (offset < ISO_SECTOR_SIZE && bytes_read + offset < root_size) {
            u8 rec_len = iso_buf[offset];
            if (rec_len == 0) break; 

            u8 name_len = iso_buf[offset + 32];
            u8 name_id  = iso_buf[offset + 33];
            
            if (name_len > 0 && name_id != 0x00 && name_id != 0x01) {
                iso9660_dirent_t *e = &out[count];
                memset(e, 0, sizeof(*e));

                e->first_lba = read_le32(iso_buf + offset + 2);
                e->size      = read_le32(iso_buf + offset + 10);
                e->is_dir    = (iso_buf[offset + 25] & 0x02) ? 1 : 0;

                clean_iso_name(e->name, (const char *)(iso_buf + offset + 33), name_len);
                count++;
                if (count >= max) break;
            }
            offset += rec_len;
        }
        current_lba++;
        bytes_read += ISO_SECTOR_SIZE;
    }
    return count;
}

/* Имя с сохранением расширения: обрезаем только ';1' и пробелы.
 * Нужно рамфс-сидингу: /boot/ramdisk/HELP.MD -> ramfs "help.md". */
static void clean_iso_name_full(char *dst, const char *src, int len) {
    int i = 0;
    while (i < len && src[i] != ';' && src[i] != 0) {
        dst[i] = src[i];
        i++;
    }
    while (i > 0 && dst[i-1] == ' ') i--;
    dst[i] = 0;
}

/* Общий листинг каталога PVD-дерева по его LBA/размеру. */
int iso9660_list_dir(u32 dir_lba, u32 dir_size, int keep_ext,
                     iso9660_dirent_t *out, int max) {
    if (!ready || !iso_buf) return 0;

    int count = 0;
    u32 current_lba = dir_lba;
    u32 bytes_read = 0;

    while (bytes_read < dir_size && count < max) {
        if (!iso_read_block(current_lba, iso_buf)) break;

        u32 offset = 0;
        while (offset < ISO_SECTOR_SIZE && bytes_read + offset < dir_size) {
            u8 rec_len = iso_buf[offset];
            if (rec_len == 0) break;

            u8 name_len = iso_buf[offset + 32];
            u8 name_id  = iso_buf[offset + 33];

            if (name_len > 0 && name_id != 0x00 && name_id != 0x01) {
                iso9660_dirent_t *e = &out[count];
                memset(e, 0, sizeof(*e));

                e->first_lba = read_le32(iso_buf + offset + 2);
                e->size      = read_le32(iso_buf + offset + 10);
                e->is_dir    = (iso_buf[offset + 25] & 0x02) ? 1 : 0;

                if (keep_ext)
                    clean_iso_name_full(e->name,
                        (const char *)(iso_buf + offset + 33), name_len);
                else
                    clean_iso_name(e->name,
                        (const char *)(iso_buf + offset + 33), name_len);
                count++;
                if (count >= max) break;
            }
            offset += rec_len;
        }
        current_lba++;
        bytes_read += ISO_SECTOR_SIZE;
    }
    return count;
}

u32 iso9660_read_file(u32 first_lba, u32 size, void *buf, u32 max) {
    if (!ready || !iso_buf || size == 0) return 0;
    if (size > max) size = max;

    u8 *p = (u8 *)buf;
    u32 left = size;
    u32 current_lba = first_lba;

    while (left > 0) {
        if (!iso_read_block(current_lba, iso_buf)) break;

        u32 to_copy = (left > ISO_SECTOR_SIZE) ? ISO_SECTOR_SIZE : left;
        memcpy(p, iso_buf, to_copy);
        
        p += to_copy;
        left -= to_copy;
        current_lba++;
    }
    return size - left;
}