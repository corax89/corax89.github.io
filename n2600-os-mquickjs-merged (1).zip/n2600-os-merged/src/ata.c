/* ata.c — безопасный ATA PIO + ATAPI (CD-ROM) с запоминанием порта/диска.
 *
 * ГЛАВНОЕ ИСПРАВЛЕНИЕ: раньше драйвер искал устройство на 4 каналах
 * (primary/secondary × master/slave), но функции чтения всегда обращались
 * по жёстко заданным адресам 0x1F0/0x3F6 (Primary Master). Если CD-ROM
 * оказывался на Secondary канале (как в QEMU по умолчанию и на большинстве
 * реальных BIOS), чтение шло не в тот порт — поэтому «CD не читается».
 *
 * Теперь найденные base_port и drive_sel запоминаются и используются
 * во всех операциях чтения. Дополнительно:
 *   - перед пробой посылается Software Reset (SRST), чтобы ATAPI-сигнатура
 *     (0x14/0xEB) гарантированно стояла в регистрах LBA_MID/LO;
 *   - ata_read_cd корректно дочитывает данные при нескольких DRQ-фазах;
 *   - статус-временки ждут BSY=0, а не DRDY (у ATAPI DRDY часто не ставится).
 */
#include "ata.h"
#include "io.h"
#include "string.h"

extern void serial_puts(const char *s);
extern void serial_putc(char c);

/* --- Стандартные порты IDE-каналов --- */
#define ATA_DATA    0x1F0
#define ATA_SECCNT  0x1F2
#define ATA_LBA0    0x1F3
#define ATA_LBA1    0x1F4
#define ATA_LBA2    0x1F5
#define ATA_DRIVE   0x1F6
#define ATA_CMD     0x1F7
#define ATA_STATUS  0x1F7
#define ATA_ALTSTAT 0x3F6

#define ST_BSY  0x80
#define ST_DRDY 0x40
#define ST_DRQ  0x08
#define ST_ERR  0x01
#define ST_DF   0x20

/* ЗДЕСЬ хранится реальный порт и селектор найденного устройства.
 * До тех пор пока (present==0), значения не используются.
 *
 * FIX [A1] (пустой ramfs при загрузке с HDD+CD): раньше ata_init()
 * останавливался на ПЕРВОМ найденном устройстве. На машинах, где HDD
 * стоит на Primary Master, а CD-ROM — на Secondary (типичная раскладка
 * реального железа), активным становился HDD: iso9660_init() требовал
 * ATAPI и молча проваливался, ramfs-сидинг пропускался. Теперь пробуем
 * ВСЕ 4 канала и запоминаем HDD и CD отдельно:
 *   - ata_read()      — «активное» устройство (CD приоритетнее: с него
 *                       грузились) — для iso9660;
 *   - ata_read_hdd()  — НЖМД независимо от наличия CD — для fat32.
 */
static int  present     = 0;
static int  is_cdrom    = 0;       /* 1 = активное устройство — ATAPI CD */
static u32  total_sectors = 0;
static u16  cur_base    = 0x1F0;   /* реальный порт найденного устройства */
static u8   cur_drive   = 0xA0;    /* 0xA0=master, 0xB0=slave */
static u16  cur_altstat = 0x3F6;  /* ALTSTAT/Control для найденного канала */
static char model[41];

/* Отдельный НЖМД (ATA HDD), если найден — не зависит от активного */
static int  hdd_present   = 0;
static u16  hdd_base      = 0x1F0;
static u8   hdd_drive     = 0xA0;
static u32  hdd_sectors   = 0;
static char hdd_model[41];

int ata_is_hdd_active(void) { return present && !is_cdrom; }

/* Первый найденный ATAPI CD-ROM (кандидат на активное устройство) */
static int  cd_present = 0;
static u16  cd_base    = 0x170;
static u8   cd_drive   = 0xA0;
static char cd_model[41];

#define TRY 50000     /* достаточно для QEMU; на реальном железе может потребоваться больше */

static inline u16 p_data(u16 base)    { return base + 0; }
static inline u16 p_seccnt(u16 base)   { return base + 2; }
static inline u16 p_lba0(u16 base)    { return base + 3; }
static inline u16 p_lba1(u16 base)    { return base + 4; }
static inline u16 p_lba2(u16 base)    { return base + 5; }
static inline u16 p_drive(u16 base)   { return base + 6; }
static inline u16 p_cmd(u16 base)     { return base + 7; }
static inline u16 p_status(u16 base) { return base + 7; }
static inline u16 p_altstat(u16 base){ return base + 0x206; }

static void io_delay4(void) { for (int i = 0; i < 4; i++) (void)inb(0x80); }

/* Ждать снятия BSY. В отличие от обычного ATA, у ATAPI-устройств статус
 * может быть 0x00 (без DRDY/DRQ) в покое — это НЕ признак отсутствия
 * устройства. Поэтому не считаем 0x00/0xFF отсутствием здесь. */
static int wait_not_busy(u16 base) {
    for (u32 i = 0; i < TRY; i++) {
        u8 s = inb(p_status(base));
        if (!(s & ST_BSY)) return 1;
    }
    return 0;
}

static int wait_drq(u16 base) {
    for (u32 i = 0; i < TRY; i++) {
        u8 s = inb(p_status(base));
        if (s == 0x00 || s == 0xFF) return 0;
        if (s & ST_ERR) return 0;
        if (s & ST_DF)   return 0;
        if (!(s & ST_BSY) && (s & ST_DRQ)) return 1;
    }
    return 0;
}

static void copy_ident(char *dst, const u16 *src, int words) {
    int j = 0;
    for (int i = 0; i < words; i++) {
        dst[j++] = (char)(src[i] >> 8);
        dst[j++] = (char)(src[i] & 0xFF);
    }
    dst[j] = 0;
    while (j > 0 && (dst[j-1] == ' ' || dst[j-1] == 0)) dst[--j] = 0;
}

/* Software Reset (SRST) теперь выполняется прямо в probe_drive
 * (см. шаг 3 ниже). Раньше это была отдельная функция, но inline
 * оказалась проще и понятнее. */

/* Проверка устройства на указанном порту и селекторе */
static int probe_drive(u16 base_port, u8 drive_sel) {
    /* Шаг 1: маскируем IRQ канала и выбираем устройство. */
    outb(p_altstat(base_port), 0x02);        /* маскируем IRQ канала */
    outb(p_drive(base_port), drive_sel);
    io_delay4();
    for (int i = 0; i < 4; i++) (void)inb(p_status(base_port));

    u8 s = inb(p_status(base_port));
    {
        /* Сессия 13: трассировка пробы (Bochs: CD не находится). */
        extern void serial_puts(const char *s_);
        extern int  snprintf(char *o, u32 n, const char *f, ...);
        char dbg_l[72];
        snprintf(dbg_l, sizeof(dbg_l), "[probe %04x/%02x] st=%02x l1=%02x l2=%02x\n",
                 (unsigned)base_port, (unsigned)drive_sel, (unsigned)s,
                 (unsigned)inb(p_lba1(base_port)), (unsigned)inb(p_lba2(base_port)));
        serial_puts(dbg_l);
    }
    if (s == 0x00 || s == 0xFF) return 0;

    /* Шаг 2: проверить сигнатуру ATAPI без SRST — этого достаточно на
     * реальном железе после BIOS-инициализации. */
    u8 lba_mid  = inb(p_lba1(base_port));
    u8 lba_high = inb(p_lba2(base_port));

    if (lba_mid == 0x14 && lba_high == 0xEB) {
        is_cdrom = 1;
        strcpy(model, "ATAPI CD-ROM");
        cur_base    = base_port;
        cur_drive   = drive_sel;
        cur_altstat = p_altstat(base_port);
        return 1; /* Это CD-ROM */
    }

    /* Шаг 3: если ATAPI-сигнатуры нет, но статус готовности устройства есть —
     * выполняем Software Reset (SRST) и повторяем проверку.
     * SRST необходим: без него LBA_MID/HIGH могут содержать «мусор»,
     * оставшийся после BIOS-инициализации (например, 0x08 в QEMU). */

    /* SRST: поднимаем бит 2 в регистре Device Control (0x206). */
    outb(p_altstat(base_port), 0x06);   /* nIEN=1, SRST=1 */
    io_delay4();
    /* Удерживаем SRST минимум 5 µs (16 inb даёт запас на QEMU и реальном железе). */
    for (int i = 0; i < 16; i++) (void)inb(p_altstat(base_port));
    outb(p_altstat(base_port), 0x04);   /* nIEN=1, SRST=0 */
    io_delay4();

    /* После SRST устройство устанавливает BSY=1, потом снимает. Ждём. */
    outb(p_drive(base_port), drive_sel);
    io_delay4();
    for (u32 i = 0; i < TRY; i++) {
        u8 st = inb(p_status(base_port));
        if (st == 0x00 || st == 0xFF) break;
        if (!(st & ST_BSY)) break;
    }
    /* Дочитываем статус 4 раза для устойчивости на медленных устройствах. */
    (void)inb(p_status(base_port)); (void)inb(p_status(base_port));
    (void)inb(p_status(base_port)); (void)inb(p_status(base_port));

    /* Шаг 4: повторная проверка сигнатуры ATAPI после SRST. */
    lba_mid  = inb(p_lba1(base_port));
    lba_high = inb(p_lba2(base_port));

    if (lba_mid == 0x14 && lba_high == 0xEB) {
        is_cdrom = 1;
        strcpy(model, "ATAPI CD-ROM");
        cur_base    = base_port;
        cur_drive   = drive_sel;
        cur_altstat = p_altstat(base_port);
        return 1; /* Это CD-ROM */
    }

    if (lba_mid != 0x00 || lba_high != 0x00) return 0;

    /* Отправляем IDENTIFY */
    outb(p_seccnt(base_port), 0);
    outb(p_lba0(base_port),    0);
    outb(p_lba1(base_port),    0);
    outb(p_lba2(base_port),    0);
    outb(p_cmd(base_port),     0xEC);
    io_delay4();

    s = inb(p_status(base_port));
    if (s == 0x00 || s == 0xFF) return 0;
    if (s & (ST_ERR | ST_DF)) return 0;
    if (!wait_drq(base_port)) return 0;

    u16 id[256];
    for (int i = 0; i < 256; i++) id[i] = inw(p_data(base_port));

    copy_ident(model, id + 27, 20);

    total_sectors = ((u32)id[61] << 16) | id[60];
    if (total_sectors == 0) total_sectors = ((u32)id[101] << 16) | id[100];
    if (total_sectors > 0x0FFFFFFF) total_sectors = 0x0FFFFFFF;
    if (total_sectors == 0) return 0;

    is_cdrom = 0;
    cur_base    = base_port;
    cur_drive   = drive_sel;
    cur_altstat = p_altstat(base_port);
    return 1;
}

int ata_init(void) {
    present = 0;
    is_cdrom = 0;
    total_sectors = 0;
    model[0] = 0;
    cur_base = 0x1F0;
    cur_drive = 0xA0;
    cur_altstat = 0x3F6;
    hdd_present = 0;
    hdd_sectors = 0;
    hdd_model[0] = 0;

    /* probe_drive пишет в глобальные cur_base/cur_drive/model/
     * total_sectors/is_cdrom — поэтому контекст каждого найденного
     * устройства сохраняем сразу (cd_/hdd_), а активное фиксируем
     * после обхода всех каналов. */

    /* Таблица всех 4 возможных IDE-каналов */
    struct {
        u16 port;
        u8 drive;
        const char *name;
    } configs[4] = {
        { 0x1F0, 0xA0, "Primary Master"   },
        { 0x1F0, 0xB0, "Primary Slave"    },
        { 0x170, 0xA0, "Secondary Master" },
        { 0x170, 0xB0, "Secondary Slave"  }
    };

    int found_cd = 0, found_hdd = 0;

    for (int i = 0; i < 4; i++) {
        serial_puts("[ata] probing ");
        serial_puts(configs[i].name);
        serial_puts("...\n");

        if (probe_drive(configs[i].port, configs[i].drive)) {
            present = 1;
            serial_puts("[ata] FOUND on ");
            serial_puts(configs[i].name);
            if (is_cdrom) {
                serial_puts(" (ATAPI CD-ROM)\n");
                if (!found_cd) {
                    /* запоминаем ПЕРВЫЙ CD (probe_drive затирает cur_*) */
                    cd_present = 1;
                    cd_base = cur_base;
                    cd_drive = cur_drive;
                    strcpy(cd_model, model);
                    found_cd = 1;
                }
            } else {
                serial_puts(" (ATA HDD)\n");
                if (!found_hdd) {
                    /* запоминаем ПЕРВЫЙ HDD (probe_drive затирает cur_*) */
                    hdd_present = 1;
                    hdd_base = cur_base;
                    hdd_drive = cur_drive;
                    hdd_sectors = total_sectors;
                    strcpy(hdd_model, model);
                    found_hdd = 1;
                }
            }
        }
    }

    /* FIX [A1]: пройдя все каналы, фиксируем АКТИВНОЕ устройство:
     * ATAPI CD приоритетнее (с него грузится ОС — iso9660 его и ждёт).
     * Если CD нет, а HDD есть — активный HDD (как раньше). */
    if (found_cd) {
        is_cdrom = 1;
        cur_base = cd_base;
        cur_drive = cd_drive;
        cur_altstat = (u16)(cd_base == 0x1F0 ? 0x3F6 : 0x376);
        total_sectors = 0;
        strcpy(model, cd_model);
    } else if (found_hdd) {
        is_cdrom = 0;
        cur_base = hdd_base;
        cur_drive = hdd_drive;
        cur_altstat = (u16)(hdd_base == 0x1F0 ? 0x3F6 : 0x376);
        total_sectors = hdd_sectors;
        strcpy(model, hdd_model);
    }

    if (!present) {
        serial_puts("[ata] no device found on any IDE channel\n");
        return 0;
    }
    return 1;
}

int ata_present(void)         { return present; }
int ata_is_cdrom(void)       { return is_cdrom; }
u32  ata_sectors(void)       { return total_sectors; }
const char *ata_model(void)  { return model; }

/* Есть ли отдельный ATA HDD (независимо от активного устройства)? */
int ata_hdd_present(void)    { return hdd_present; }
u32  ata_hdd_sectors(void)   { return hdd_sectors; }
const char *ata_hdd_model(void) { return hdd_model; }

/* Чтение секторов (512 байт/сектор) с отдельного ATA HDD.
 * Нужно fat32: на машинах с HDD+CD активным является CD, но FAT32
 * живёт на НЖМД. Если HDD нет — ошибка (0). */
int ata_read_hdd(u32 lba, u8 count, void *buf)
{
    if (!hdd_present) return 0;
    if (lba >= hdd_sectors) return 0;
    u16 b = hdd_base;
    u16 alt = (u16)(hdd_base == 0x1F0 ? 0x3F6 : 0x376);
    outb(alt, 0x02);
    if (!wait_not_busy(b)) return 0;
    /* FIX [A2]: 0xE0|slave-бит|lba>>24 — с битом LBA (0x40);
     * раньше 0xA0 без бита LBA → CHS-режим → чтение сектора 0 падало */
    outb(p_drive(b), (u8)(0xE0 | (hdd_drive & 0x10) | ((lba >> 24) & 0x0F)));
    io_delay4();
    outb(p_seccnt(b), count);
    outb(p_lba0(b),   (u8)( lba        & 0xFF));
    outb(p_lba1(b),   (u8)((lba >> 8)  & 0xFF));
    outb(p_lba2(b),   (u8)((lba >> 16) & 0xFF));
    outb(p_cmd(b),     0x20);
    io_delay4();
    u16 *out = (u16 *)buf;
    for (int s = 0; s < count; s++) {
        if (!wait_drq(b)) return 0;
        for (int i = 0; i < 256; i++) *out++ = inw(p_data(b));
    }
    return 1;
}

/* Запись секторов ATA-НЖМД (PIO WRITE SECTORS 0x30) — сессия 12.
 * Нужна для форматирования диска в FAT32 из «Настроек» (QEMU IDE-диски
 * и старое железо без AHCI). Зеркальна ata_read_hdd. */
int ata_write_hdd(u32 lba, u8 count, const void *buf)
{
    if (!hdd_present) return 0;
    if (lba >= hdd_sectors) return 0;
    u16 b = hdd_base;
    u16 alt = (u16)(hdd_base == 0x1F0 ? 0x3F6 : 0x376);
    outb(alt, 0x02);                       /* nIEN: без прерываний */
    if (!wait_not_busy(b)) return 0;
    outb(p_drive(b), (u8)(0xE0 | (hdd_drive & 0x10) | ((lba >> 24) & 0x0F)));
    io_delay4();
    outb(p_seccnt(b), count);
    outb(p_lba0(b),   (u8)( lba        & 0xFF));
    outb(p_lba1(b),   (u8)((lba >> 8)  & 0xFF));
    outb(p_lba2(b),   (u8)((lba >> 16) & 0xFF));
    outb(p_cmd(b),     0x30);              /* WRITE SECTORS (PIO) */
    io_delay4();
    const u16 *in = (const u16 *)buf;
    for (int s = 0; s < count; s++) {
        if (!wait_drq(b)) return 0;
        for (int i = 0; i < 256; i++) outw(p_data(b), *in++);
    }
    /* дождаться завершения записи (BSY снимается после сброса буферов
     * на носитель) — иначе следующий сектор затрёт незавершённую запись */
    return wait_not_busy(b);
}

u16  ata_base_port(void)     { return cur_base; }
u8   ata_drive_sel(void)     { return cur_drive; }

/* --- Чтение секторов АКТИВНОГО устройства, если это HDD (для ata_read) --- */
static int ata_read_active_hdd(u32 lba, u8 count, void *buf) {
    if (lba >= total_sectors) return 0;
    u16 b = cur_base;
    outb(cur_altstat, 0x02);
    if (!wait_not_busy(b)) return 0;
    /* FIX [A2]: бит 6 (0x40) в регистре устройства = режим LBA. Раньше
     * писался селектор 0xA0 без него → контроллер работал в CHS:
     * сектор 0 (наш LBA-регистр 0) в CHS не существует → ошибка чтения.
     * FAT32/жёсткий диск были недоступны ВСЕГДА. */
    outb(p_drive(b), (u8)(0xE0 | (cur_drive & 0x10) | ((lba >> 24) & 0x0F)));
    io_delay4();
    outb(p_seccnt(b), count);
    outb(p_lba0(b),   (u8)( lba        & 0xFF));
    outb(p_lba1(b),   (u8)((lba >> 8)  & 0xFF));
    outb(p_lba2(b),   (u8)((lba >> 16) & 0xFF));
    outb(p_cmd(b),     0x20);
    io_delay4();
    u16 *out = (u16 *)buf;
    for (int s = 0; s < count; s++) {
        if (!wait_drq(b)) return 0;
        for (int i = 0; i < 256; i++) *out++ = inw(p_data(b));
    }
    return 1;
}

/* --- Чтение секторов CD-ROM (ATAPI). Дочитывает все DRQ-фазы. --- */
static int ata_read_cd(u32 lba, u32 count, void *buf) {
    u16 b = cur_base;
    if (!wait_not_busy(b)) return 0;
    outb(p_drive(b), cur_drive);
    io_delay4();

    /* feature=0, sector count=0, byte count limit = 0xFFFF (дадим максимум) */
    outb(p_seccnt(b), 0x00);
    outb(p_lba0(b),    0xFE);    /* feature: PIO */
    outb(p_lba1(b),    0xFF);    /* byte count low  (младший байт byte_count_limit) */
    outb(p_lba2(b),    0xFF);    /* byte count high (старший байт byte_count_limit) */
    outb(p_cmd(b),     0xA0);    /* PACKET */
    io_delay4();
    if (!wait_drq(b)) return 0;

    u8 cdb[12] = {0};
    cdb[0] = 0x28;                       /* READ 10 */
    cdb[2] = (u8)((lba >> 24) & 0xFF);
    cdb[3] = (u8)((lba >> 16) & 0xFF);
    cdb[4] = (u8)((lba >> 8)  & 0xFF);
    cdb[5] = (u8)( lba        & 0xFF);
    cdb[7] = (u8)((count >> 8) & 0xFF);
    cdb[8] = (u8)( count       & 0xFF);
    u16 *cdb_w = (u16 *)cdb;
    for (int i = 0; i < 6; i++) outw(p_data(b), cdb_w[i]);

    /* Цикл по всем DRQ-фазам, пока устройство не вернёт статус без DRQ
     * или пока не дочитаем запрошенный объём. */
    u8  *p = (u8 *)buf;
    u32  total_expected = count * 2048u;
    u32  got = 0;

    while (got < total_expected) {
        if (!wait_drq(b)) {
            /* Если что-то уже прочитали — считаем успешным */
            return got > 0 ? 1 : 0;
        }

        u16 byte_count = (u16)inb(p_lba1(b)) | ((u16)inb(p_lba2(b)) << 8);
        if (byte_count == 0) {
            /* Устройство закончило без новых данных */
            break;
        }

        u32 words_to_read = (u32)byte_count / 2u;
        for (u32 i = 0; i < words_to_read; i++) {
            *(u16 *)p = inw(p_data(b));
            p += 2;
            got += 2;
            if (got >= total_expected) break;
        }
    }
    return 1;
}

/* --- Универсальная функция чтения (активное устройство) --- */
int ata_read(u32 lba, u8 count, void *buf) {
    if (!present || count == 0 || !buf) return 0;
    if (is_cdrom) {
        return ata_read_cd(lba, (u32)count, buf);
    } else {
        return ata_read_active_hdd(lba, count, buf);
    }
}


/* ================== диагностика ataprobe (сессия 13) ==================
 * Дамп регистров всех 4 IDE-каналов после выбора устройства и после
 * SRST — для разбора «почему ATAPI CD не найден» в Bochs/на железе.
 * Вызывается командой терминала ataprobe и cmdline-параметром ataprobe. */
void ata_probe_diag(void)
{
    extern void serial_puts(const char *s);
    extern int  snprintf(char *o, u32 n, const char *f, ...);
    static const u16 bases[2] = { 0x1F0, 0x170 };
    char line[96];
    serial_puts("[ataprobe] --- ATA register dump ---\n");
    for (int ch = 0; ch < 2; ch++) {
        u16 base = bases[ch];
        for (int dv = 0; dv < 2; dv++) {
            u8 sel = dv ? 0xB0 : 0xA0;
            outb(base + 6, sel);
            io_delay4();
            for (int i = 0; i < 4; i++) (void)inb(base + 7);
            u8 st = inb(base + 7);
            u8 l1 = inb(base + 4);
            u8 l2 = inb(base + 5);
            snprintf(line, sizeof(line),
                     "ch%d %s: status=%02x err=%02x lba1=%02x lba2=%02x\n",
                     ch, dv ? "slave " : "master", st, inb(base + 1), l1, l2);
            serial_puts(line);
        }
    }
    serial_puts("[ataprobe] --- конец ---\n");
}
